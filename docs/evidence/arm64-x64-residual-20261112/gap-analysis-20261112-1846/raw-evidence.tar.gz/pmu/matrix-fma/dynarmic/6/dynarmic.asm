000070404d1ce69b  nop [rax+rax*1], eax
000070404d1ce6a0  vmovaps xmm1, [0x000070404CDFE010]
000070404d1ce6a8  movq xmm1, xmm1
000070404d1ce6ac  movaps [r15+0x110], xmm1
000070404d1ce6b4  vmovaps xmm1, [0x000070404CDFE020]
000070404d1ce6bc  movq xmm1, xmm1
000070404d1ce6c0  movaps [r15+0x120], xmm1
000070404d1ce6c8  mov eax, 0x420470
000070404d1ce6cd  mov r14, [r13+rax*1]
000070404d1ce6d2  movq xmm1, r14
000070404d1ce6d7  movaps [r15+0x130], xmm1
000070404d1ce6df  vmovaps xmm1, [0x000070404CDFE030]
000070404d1ce6e7  vpbroadcastq xmm1, xmm1
000070404d1ce6ec  movaps [r15+0x140], xmm1
000070404d1ce6f4  mov qword ptr [r15+0x40], 0x02
000070404d1ce6fc  vmovaps xmm15, [0x000070404CDFE040]
000070404d1ce704  movq xmm15, xmm15
000070404d1ce709  movaps [r15+0x150], xmm15
000070404d1ce711  mov qword ptr [r15+0x58], 0x420000
000070404d1ce719  vmovaps xmm15, [0x000070404CDFE050]
000070404d1ce721  vpbroadcastq xmm15, xmm15
000070404d1ce726  movaps [r15+0x160], xmm15
000070404d1ce72e  mov rax, [r15+0x40]
000070404d1ce732  vmovq xmm14, rax
000070404d1ce737  vpbroadcastq xmm14, xmm14
000070404d1ce73c  movaps [r15+0x170], xmm14
000070404d1ce744  mov eax, 0x420480
000070404d1ce749  movups xmm13, [r13+rax*1]
000070404d1ce74f  mov qword ptr [r15+0x40], 0x4304C8
000070404d1ce757  mov qword ptr [r15+0x50], 0x4306D0
000070404d1ce75f  vpmovqd xmm12, xmm13
000070404d1ce765  pxor xmm11, xmm11
000070404d1ce76a  punpcklqdq xmm12, xmm11
000070404d1ce76f  movaps [r15+0x210], xmm12
000070404d1ce777  movq xmm12, qword ptr [r15+0x120]
000070404d1ce780  movq xmm11, qword ptr [r15+0x130]
000070404d1ce789  psubd xmm12, xmm11
000070404d1ce78e  movq xmm12, xmm12
000070404d1ce793  paddq xmm13, xmm14
000070404d1ce798  movaps [r15+0x180], xmm13
000070404d1ce7a0  movq xmm14, qword ptr [r15+0x150]
000070404d1ce7a9  paddd xmm11, xmm14
000070404d1ce7ae  movq xmm11, xmm11
000070404d1ce7b3  movq xmm11, xmm11
000070404d1ce7b8  movaps [r15+0x130], xmm11
000070404d1ce7c0  pmovzxdq xmm12, xmm12
000070404d1ce7c6  psllq xmm12, 0x00
000070404d1ce7cc  movq xmm14, qword ptr [r15+0x210]
000070404d1ce7d5  movq xmm13, qword ptr [r15+0x110]
000070404d1ce7de  paddd xmm14, xmm13
000070404d1ce7e3  movq xmm14, xmm14
000070404d1ce7e8  vcvtuqq2pd xmm12, xmm12
000070404d1ce7ee  pmovzxdq xmm14, xmm14
000070404d1ce7f4  psllq xmm14, 0x00
000070404d1ce7fa  vcvtuqq2pd xmm14, xmm14
000070404d1ce800  movaps xmm13, xmm12
000070404d1ce804  mulpd xmm13, xmm1
000070404d1ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000070404d1ce80f  ptest xmm11, xmm11
000070404d1ce815  jnz 0x000070404D1CE8FF
000070404d1ce81b  movaps [r15+0x220], xmm13
000070404d1ce823  mov eax, 0x4306D0
000070404d1ce828  movups [r13+rax*1], xmm13
000070404d1ce82e  movaps xmm1, xmm14
000070404d1ce832  mulpd xmm1, xmm15
000070404d1ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000070404d1ce83c  ptest xmm13, xmm13
000070404d1ce842  jnz 0x000070404D1CEA4C
000070404d1ce848  movaps [r15+0x210], xmm1
000070404d1ce850  mov eax, 0x4304C8
000070404d1ce855  movups [r13+rax*1], xmm1
000070404d1ce85b  mov qword ptr [r15+0x48], 0x10
000070404d1ce863  xor eax, eax
000070404d1ce865  mov r14d, 0x10
000070404d1ce86b  mov r12d, 0x200
000070404d1ce871  cmp r14, r12
000070404d1ce874  cmc
000070404d1ce875  lahf
000070404d1ce876  seto al
000070404d1ce879  mov [r15+0x108], eax
000070404d1ce880  mov eax, [r15+0x108]
000070404d1ce887  sahf
000070404d1ce888  jnz 0x000070404D1CE8BA
000070404d1ce88a  cmp dword ptr [r15+0x318], 0x00
000070404d1ce892  jz 0x000070404D1CEFF0
000070404d1ce898  nop [rax+rax*1], ax
000070404d1ce8a1  nop [rax+rax*1], eax
000070404d1ce8a9  mov eax, 0x4101EC
000070404d1ce8ae  mov [r15+0x100], rax
000070404d1ce8b5  jmp 0x000070404CFFE110
000070404d1ce8ba  cmp dword ptr [r15+0x318], 0x00
000070404d1ce8c2  jz 0x000070404D1CEBA0
000070404d1ce8c8  nop [rax+rax*1], ax
000070404d1ce8d1  nop [rax+rax*1], eax
000070404d1ce8d9  mov eax, 0x4101AC
000070404d1ce8de  mov [r15+0x100], rax
000070404d1ce8e5  jmp 0x000070404CFFE110
000070404d1ce8ea  int3
000070404d1ce8eb  call 0x000070404D00DC20
000070404d1ce8f0  jmp 0x000070404D1CE6D2
000070404d1ce8f5  call 0x000070404D00C260
000070404d1ce8fa  jmp 0x000070404D1CE74F
000070404d1ce8ff  sub rsp, 0x08
000070404d1ce903  push rax
000070404d1ce904  push rcx
000070404d1ce905  push rdx
000070404d1ce906  push rdi
000070404d1ce907  push rsi
000070404d1ce908  push r8
000070404d1ce90a  push r9
000070404d1ce90c  push r10
000070404d1ce90e  push r11
000070404d1ce910  sub rsp, 0xF0
000070404d1ce917  vmovaps [rsp], xmm0
000070404d1ce91c  vmovaps [rsp+0x10], xmm1
000070404d1ce922  vmovaps [rsp+0x20], xmm2
000070404d1ce928  vmovaps [rsp+0x30], xmm3
000070404d1ce92e  vmovaps [rsp+0x40], xmm4
000070404d1ce934  vmovaps [rsp+0x50], xmm5
000070404d1ce93a  vmovaps [rsp+0x60], xmm6
000070404d1ce940  vmovaps [rsp+0x70], xmm7
000070404d1ce946  vmovaps [rsp+0x80], xmm8
000070404d1ce94f  vmovaps [rsp+0x90], xmm9
000070404d1ce958  vmovaps [rsp+0xA0], xmm10
000070404d1ce961  vmovaps [rsp+0xB0], xmm11
000070404d1ce96a  vmovaps [rsp+0xC0], xmm12
000070404d1ce973  vmovaps [rsp+0xD0], xmm14
000070404d1ce97c  vmovaps [rsp+0xE0], xmm15
000070404d1ce985  sub rsp, 0x30
000070404d1ce989  movaps [rsp], xmm13
000070404d1ce98e  movaps [rsp+0x10], xmm12
000070404d1ce994  movaps [rsp+0x20], xmm1
000070404d1ce999  lea rdi, [rsp]
000070404d1ce99d  mov esi, 0x00
000070404d1ce9a2  mov rax, 0x607928F07530
000070404d1ce9ac  call rax
000070404d1ce9ae  movaps xmm13, [rsp]
000070404d1ce9b3  add rsp, 0x30
000070404d1ce9b7  vmovaps xmm0, [rsp]
000070404d1ce9bc  vmovaps xmm1, [rsp+0x10]
000070404d1ce9c2  vmovaps xmm2, [rsp+0x20]
000070404d1ce9c8  vmovaps xmm3, [rsp+0x30]
000070404d1ce9ce  vmovaps xmm4, [rsp+0x40]
000070404d1ce9d4  vmovaps xmm5, [rsp+0x50]
000070404d1ce9da  vmovaps xmm6, [rsp+0x60]
000070404d1ce9e0  vmovaps xmm7, [rsp+0x70]
000070404d1ce9e6  vmovaps xmm8, [rsp+0x80]
000070404d1ce9ef  vmovaps xmm9, [rsp+0x90]
000070404d1ce9f8  vmovaps xmm10, [rsp+0xA0]
000070404d1cea01  vmovaps xmm11, [rsp+0xB0]
000070404d1cea0a  vmovaps xmm12, [rsp+0xC0]
000070404d1cea13  vmovaps xmm14, [rsp+0xD0]
000070404d1cea1c  vmovaps xmm15, [rsp+0xE0]
000070404d1cea25  add rsp, 0xF0
000070404d1cea2c  pop r11
000070404d1cea2e  pop r10
000070404d1cea30  pop r9
000070404d1cea32  pop r8
000070404d1cea34  pop rsi
000070404d1cea35  pop rdi
000070404d1cea36  pop rdx
000070404d1cea37  pop rcx
000070404d1cea38  pop rax
000070404d1cea39  add rsp, 0x08
000070404d1cea3d  jmp 0x000070404D1CE81B
000070404d1cea42  call 0x000070404D00C380
000070404d1cea47  jmp 0x000070404D1CE82E
000070404d1cea4c  sub rsp, 0x08
000070404d1cea50  push rax
000070404d1cea51  push rcx
000070404d1cea52  push rdx
000070404d1cea53  push rdi
000070404d1cea54  push rsi
000070404d1cea55  push r8
000070404d1cea57  push r9
000070404d1cea59  push r10
000070404d1cea5b  push r11
000070404d1cea5d  sub rsp, 0xF0
000070404d1cea64  vmovaps [rsp], xmm0
000070404d1cea69  vmovaps [rsp+0x10], xmm2
000070404d1cea6f  vmovaps [rsp+0x20], xmm3
000070404d1cea75  vmovaps [rsp+0x30], xmm4
000070404d1cea7b  vmovaps [rsp+0x40], xmm5
000070404d1cea81  vmovaps [rsp+0x50], xmm6
000070404d1cea87  vmovaps [rsp+0x60], xmm7
000070404d1cea8d  vmovaps [rsp+0x70], xmm8
000070404d1cea93  vmovaps [rsp+0x80], xmm9
000070404d1cea9c  vmovaps [rsp+0x90], xmm10
000070404d1ceaa5  vmovaps [rsp+0xA0], xmm11
000070404d1ceaae  vmovaps [rsp+0xB0], xmm12
000070404d1ceab7  vmovaps [rsp+0xC0], xmm13
000070404d1ceac0  vmovaps [rsp+0xD0], xmm14
000070404d1ceac9  vmovaps [rsp+0xE0], xmm15
000070404d1cead2  sub rsp, 0x30
000070404d1cead6  movaps [rsp], xmm1
000070404d1ceada  movaps [rsp+0x10], xmm14
000070404d1ceae0  movaps [rsp+0x20], xmm15
000070404d1ceae6  lea rdi, [rsp]
000070404d1ceaea  mov esi, 0x00
000070404d1ceaef  mov rax, 0x607928F07530
000070404d1ceaf9  call rax
000070404d1ceafb  movaps xmm1, [rsp]
000070404d1ceaff  add rsp, 0x30
000070404d1ceb03  vmovaps xmm0, [rsp]
000070404d1ceb08  vmovaps xmm2, [rsp+0x10]
000070404d1ceb0e  vmovaps xmm3, [rsp+0x20]
000070404d1ceb14  vmovaps xmm4, [rsp+0x30]
000070404d1ceb1a  vmovaps xmm5, [rsp+0x40]
000070404d1ceb20  vmovaps xmm6, [rsp+0x50]
000070404d1ceb26  vmovaps xmm7, [rsp+0x60]
000070404d1ceb2c  vmovaps xmm8, [rsp+0x70]
000070404d1ceb32  vmovaps xmm9, [rsp+0x80]
000070404d1ceb3b  vmovaps xmm10, [rsp+0x90]
000070404d1ceb44  vmovaps xmm11, [rsp+0xA0]
000070404d1ceb4d  vmovaps xmm12, [rsp+0xB0]
000070404d1ceb56  vmovaps xmm13, [rsp+0xC0]
000070404d1ceb5f  vmovaps xmm14, [rsp+0xD0]
000070404d1ceb68  vmovaps xmm15, [rsp+0xE0]
000070404d1ceb71  add rsp, 0xF0
000070404d1ceb78  pop r11
000070404d1ceb7a  pop r10
000070404d1ceb7c  pop r9
000070404d1ceb7e  pop r8
000070404d1ceb80  pop rsi
000070404d1ceb81  pop rdi
000070404d1ceb82  pop rdx
000070404d1ceb83  pop rcx
000070404d1ceb84  pop rax
000070404d1ceb85  add rsp, 0x08
000070404d1ceb89  jmp 0x000070404D1CE848
000070404d1ceb8e  call 0x000070404CFFF540
000070404d1ceb93  jmp 0x000070404D1CE85B
000070404d1ceb98  int3
000070404d1ceb99  nop [rax], eax
000070404d1ceba0  movaps xmm1, [r15+0x180]
000070404d1ceba8  vpmovqd xmm15, xmm1
000070404d1cebae  pxor xmm14, xmm14
000070404d1cebb3  punpcklqdq xmm15, xmm14
000070404d1cebb8  movaps [r15+0x210], xmm15
000070404d1cebc0  movq xmm15, qword ptr [r15+0x120]
000070404d1cebc9  movq xmm14, qword ptr [r15+0x130]
000070404d1cebd2  psubd xmm15, xmm14
000070404d1cebd7  movq xmm15, xmm15
000070404d1cebdc  movaps xmm13, [r15+0x170]
000070404d1cebe4  paddq xmm1, xmm13
000070404d1cebe9  movaps [r15+0x180], xmm1
000070404d1cebf1  movq xmm1, qword ptr [r15+0x150]
000070404d1cebfa  paddd xmm14, xmm1
000070404d1cebff  movq xmm14, xmm14
000070404d1cec04  movq xmm14, xmm14
000070404d1cec09  movaps [r15+0x130], xmm14
000070404d1cec11  pmovzxdq xmm15, xmm15
000070404d1cec17  psllq xmm15, 0x00
000070404d1cec1d  movq xmm1, qword ptr [r15+0x210]
000070404d1cec26  movq xmm14, qword ptr [r15+0x110]
000070404d1cec2f  paddd xmm1, xmm14
000070404d1cec34  movq xmm1, xmm1
000070404d1cec38  vcvtuqq2pd xmm15, xmm15
000070404d1cec3e  pmovzxdq xmm1, xmm1
000070404d1cec43  psllq xmm1, 0x00
000070404d1cec48  vcvtuqq2pd xmm1, xmm1
000070404d1cec4e  movaps xmm14, [r15+0x140]
000070404d1cec56  movaps xmm13, xmm15
000070404d1cec5a  mulpd xmm13, xmm14
000070404d1cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1cec65  ptest xmm12, xmm12
000070404d1cec6b  jnz 0x000070404D1CED4E
000070404d1cec71  movaps [r15+0x220], xmm13
000070404d1cec79  mov rax, [r15+0x48]
000070404d1cec7d  mov r14, [r15+0x50]
000070404d1cec81  lea r12, [r14+rax*1]
000070404d1cec85  movups [r13+r12*1], xmm13
000070404d1cec8b  movaps xmm15, [r15+0x160]
000070404d1cec93  movaps xmm14, xmm1
000070404d1cec97  mulpd xmm14, xmm15
000070404d1cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000070404d1ceca2  ptest xmm13, xmm13
000070404d1ceca8  jnz 0x000070404D1CEE9C
000070404d1cecae  movaps [r15+0x210], xmm14
000070404d1cecb6  mov r14, [r15+0x40]
000070404d1cecba  lea r12, [r14+rax*1]
000070404d1cecbe  movups [r13+r12*1], xmm14
000070404d1cecc4  lea r14, [rax+0x10]
000070404d1cecc8  mov [r15+0x48], r14
000070404d1ceccc  xor eax, eax
000070404d1cecce  mov r12d, 0x200
000070404d1cecd4  cmp r14, r12
000070404d1cecd7  cmc
000070404d1cecd8  lahf
000070404d1cecd9  seto al
000070404d1cecdc  mov [r15+0x108], eax
000070404d1cece3  mov eax, [r15+0x108]
000070404d1cecea  sahf
000070404d1ceceb  jnz 0x000070404D1CED1D
000070404d1ceced  cmp dword ptr [r15+0x318], 0x00
000070404d1cecf5  jz 0x000070404D1CEFF0
000070404d1cecfb  nop [rax+rax*1], ax
000070404d1ced04  nop [rax+rax*1], eax
000070404d1ced0c  mov eax, 0x4101EC
000070404d1ced11  mov [r15+0x100], rax
000070404d1ced18  jmp 0x000070404CFFE110
000070404d1ced1d  cmp dword ptr [r15+0x318], 0x00
000070404d1ced25  jz 0x000070404D1CEBA0
000070404d1ced2b  nop [rax+rax*1], ax
000070404d1ced34  nop [rax+rax*1], eax
000070404d1ced3c  mov eax, 0x4101AC
000070404d1ced41  mov [r15+0x100], rax
000070404d1ced48  jmp 0x000070404CFFE110
000070404d1ced4d  int3
000070404d1ced4e  sub rsp, 0x08
000070404d1ced52  push rax
000070404d1ced53  push rcx
000070404d1ced54  push rdx
000070404d1ced55  push rdi
000070404d1ced56  push rsi
000070404d1ced57  push r8
000070404d1ced59  push r9
000070404d1ced5b  push r10
000070404d1ced5d  push r11
000070404d1ced5f  sub rsp, 0xF0
000070404d1ced66  vmovaps [rsp], xmm0
000070404d1ced6b  vmovaps [rsp+0x10], xmm1
000070404d1ced71  vmovaps [rsp+0x20], xmm2
000070404d1ced77  vmovaps [rsp+0x30], xmm3
000070404d1ced7d  vmovaps [rsp+0x40], xmm4
000070404d1ced83  vmovaps [rsp+0x50], xmm5
000070404d1ced89  vmovaps [rsp+0x60], xmm6
000070404d1ced8f  vmovaps [rsp+0x70], xmm7
000070404d1ced95  vmovaps [rsp+0x80], xmm8
000070404d1ced9e  vmovaps [rsp+0x90], xmm9
000070404d1ceda7  vmovaps [rsp+0xA0], xmm10
000070404d1cedb0  vmovaps [rsp+0xB0], xmm11
000070404d1cedb9  vmovaps [rsp+0xC0], xmm12
000070404d1cedc2  vmovaps [rsp+0xD0], xmm14
000070404d1cedcb  vmovaps [rsp+0xE0], xmm15
000070404d1cedd4  sub rsp, 0x30
000070404d1cedd8  movaps [rsp], xmm13
000070404d1ceddd  movaps [rsp+0x10], xmm15
000070404d1cede3  movaps [rsp+0x20], xmm14
000070404d1cede9  lea rdi, [rsp]
000070404d1ceded  mov esi, 0x00
000070404d1cedf2  mov rax, 0x607928F07530
000070404d1cedfc  call rax
000070404d1cedfe  movaps xmm13, [rsp]
000070404d1cee03  add rsp, 0x30
000070404d1cee07  vmovaps xmm0, [rsp]
000070404d1cee0c  vmovaps xmm1, [rsp+0x10]
000070404d1cee12  vmovaps xmm2, [rsp+0x20]
000070404d1cee18  vmovaps xmm3, [rsp+0x30]
000070404d1cee1e  vmovaps xmm4, [rsp+0x40]
000070404d1cee24  vmovaps xmm5, [rsp+0x50]
000070404d1cee2a  vmovaps xmm6, [rsp+0x60]
000070404d1cee30  vmovaps xmm7, [rsp+0x70]
000070404d1cee36  vmovaps xmm8, [rsp+0x80]
000070404d1cee3f  vmovaps xmm9, [rsp+0x90]
000070404d1cee48  vmovaps xmm10, [rsp+0xA0]
000070404d1cee51  vmovaps xmm11, [rsp+0xB0]
000070404d1cee5a  vmovaps xmm12, [rsp+0xC0]
000070404d1cee63  vmovaps xmm14, [rsp+0xD0]
000070404d1cee6c  vmovaps xmm15, [rsp+0xE0]
000070404d1cee75  add rsp, 0xF0
000070404d1cee7c  pop r11
000070404d1cee7e  pop r10
000070404d1cee80  pop r9
000070404d1cee82  pop r8
000070404d1cee84  pop rsi
000070404d1cee85  pop rdi
000070404d1cee86  pop rdx
000070404d1cee87  pop rcx
000070404d1cee88  pop rax
000070404d1cee89  add rsp, 0x08
000070404d1cee8d  jmp 0x000070404D1CEC71
000070404d1cee92  call 0x000070404D0C2240
000070404d1cee97  jmp 0x000070404D1CEC8B
000070404d1cee9c  sub rsp, 0x08
000070404d1ceea0  push rax
000070404d1ceea1  push rcx
000070404d1ceea2  push rdx
000070404d1ceea3  push rdi
000070404d1ceea4  push rsi
000070404d1ceea5  push r8
000070404d1ceea7  push r9
000070404d1ceea9  push r10
000070404d1ceeab  push r11
000070404d1ceead  sub rsp, 0xF0
000070404d1ceeb4  vmovaps [rsp], xmm0
000070404d1ceeb9  vmovaps [rsp+0x10], xmm1
000070404d1ceebf  vmovaps [rsp+0x20], xmm2
000070404d1ceec5  vmovaps [rsp+0x30], xmm3
000070404d1ceecb  vmovaps [rsp+0x40], xmm4
000070404d1ceed1  vmovaps [rsp+0x50], xmm5
000070404d1ceed7  vmovaps [rsp+0x60], xmm6
000070404d1ceedd  vmovaps [rsp+0x70], xmm7
000070404d1ceee3  vmovaps [rsp+0x80], xmm8
000070404d1ceeec  vmovaps [rsp+0x90], xmm9
000070404d1ceef5  vmovaps [rsp+0xA0], xmm10
000070404d1ceefe  vmovaps [rsp+0xB0], xmm11
000070404d1cef07  vmovaps [rsp+0xC0], xmm12
000070404d1cef10  vmovaps [rsp+0xD0], xmm13
000070404d1cef19  vmovaps [rsp+0xE0], xmm15
000070404d1cef22  sub rsp, 0x30
000070404d1cef26  movaps [rsp], xmm14
000070404d1cef2b  movaps [rsp+0x10], xmm1
000070404d1cef30  movaps [rsp+0x20], xmm15
000070404d1cef36  lea rdi, [rsp]
000070404d1cef3a  mov esi, 0x00
000070404d1cef3f  mov rax, 0x607928F07530
000070404d1cef49  call rax
000070404d1cef4b  movaps xmm14, [rsp]
000070404d1cef50  add rsp, 0x30
000070404d1cef54  vmovaps xmm0, [rsp]
000070404d1cef59  vmovaps xmm1, [rsp+0x10]
000070404d1cef5f  vmovaps xmm2, [rsp+0x20]
000070404d1cef65  vmovaps xmm3, [rsp+0x30]
000070404d1cef6b  vmovaps xmm4, [rsp+0x40]
000070404d1cef71  vmovaps xmm5, [rsp+0x50]
000070404d1cef77  vmovaps xmm6, [rsp+0x60]
000070404d1cef7d  vmovaps xmm7, [rsp+0x70]
000070404d1cef83  vmovaps xmm8, [rsp+0x80]
000070404d1cef8c  vmovaps xmm9, [rsp+0x90]
000070404d1cef95  vmovaps xmm10, [rsp+0xA0]
000070404d1cef9e  vmovaps xmm11, [rsp+0xB0]
000070404d1cefa7  vmovaps xmm12, [rsp+0xC0]
000070404d1cefb0  vmovaps xmm13, [rsp+0xD0]
000070404d1cefb9  vmovaps xmm15, [rsp+0xE0]
000070404d1cefc2  add rsp, 0xF0
000070404d1cefc9  pop r11
000070404d1cefcb  pop r10
000070404d1cefcd  pop r9
000070404d1cefcf  pop r8
000070404d1cefd1  pop rsi
000070404d1cefd2  pop rdi
000070404d1cefd3  pop rdx
000070404d1cefd4  pop rcx
000070404d1cefd5  pop rax
000070404d1cefd6  add rsp, 0x08
000070404d1cefda  jmp 0x000070404D1CECAE
000070404d1cefdf  call 0x000070404D0C34C0
000070404d1cefe4  jmp 0x000070404D1CECC4
000070404d1cefe9  int3
000070404d1cefea  nop [rax+rax*1], ax
000070404d1ceff0  mov rax, [r15+0xF8]
000070404d1ceff7  lea r14, [rax-0x120]
000070404d1ceffe  mov [r15+0xF8], r14
000070404d1cf005  mov rax, [r15+0x50]
000070404d1cf009  movups xmm1, [r13+rax*1]
000070404d1cf00f  lea r12, [rax+0x10]
000070404d1cf013  movups xmm15, [r13+r12*1]
000070404d1cf019  mov qword ptr [r15+0x48], 0x00
000070404d1cf021  lea r12, [r14+0xD0]
000070404d1cf028  movq xmm14, qword ptr [r15+0x200]
000070404d1cf031  movq xmm13, qword ptr [r15+0x1F0]
000070404d1cf03a  movq r11, xmm14
000070404d1cf03f  movq r10, xmm13
000070404d1cf044  mov [r13+r12*1], r11
000070404d1cf049  lea r12, [r14+0xD8]
000070404d1cf050  mov [r13+r12*1], r10
000070404d1cf055  lea r12, [rax+0x80]
000070404d1cf05c  movups xmm14, [r13+r12*1]
000070404d1cf062  lea r12, [rax+0x90]
000070404d1cf069  movups xmm13, [r13+r12*1]
000070404d1cf06f  lea r12, [r14+0xE0]
000070404d1cf076  movq xmm12, qword ptr [r15+0x1E0]
000070404d1cf07f  movq xmm11, qword ptr [r15+0x1D0]
000070404d1cf088  movq r11, xmm12
000070404d1cf08d  movq r10, xmm11
000070404d1cf092  mov [r13+r12*1], r11
000070404d1cf097  lea r12, [r14+0xE8]
000070404d1cf09e  mov [r13+r12*1], r10
000070404d1cf0a3  lea r12, [rax+0xC0]
000070404d1cf0aa  movups xmm12, [r13+r12*1]
000070404d1cf0b0  lea r12, [rax+0xD0]
000070404d1cf0b7  movups xmm11, [r13+r12*1]
000070404d1cf0bd  movups [r13+r14*1], xmm1
000070404d1cf0c3  lea r12, [rax+0x20]
000070404d1cf0c7  movups xmm1, [r13+r12*1]
000070404d1cf0cd  lea r12, [rax+0x30]
000070404d1cf0d1  movups xmm10, [r13+r12*1]
000070404d1cf0d7  lea r12, [r14+0xF0]
000070404d1cf0de  movq xmm9, qword ptr [r15+0x1C0]
000070404d1cf0e7  movq xmm8, qword ptr [r15+0x1B0]
000070404d1cf0f0  movq r11, xmm9
000070404d1cf0f5  movq r10, xmm8
000070404d1cf0fa  mov [r13+r12*1], r11
000070404d1cf0ff  lea r12, [r14+0xF8]
000070404d1cf106  mov [r13+r12*1], r10
000070404d1cf10b  lea r12, [rax+0x40]
000070404d1cf10f  movups xmm9, [r13+r12*1]
000070404d1cf115  lea r12, [rax+0x50]
000070404d1cf119  movups xmm8, [r13+r12*1]
000070404d1cf11f  lea r12, [r14+0x100]
000070404d1cf126  movq xmm7, qword ptr [r15+0x1A0]
000070404d1cf12f  movq xmm6, qword ptr [r15+0x190]
000070404d1cf138  movq r11, xmm7
000070404d1cf13d  movq r10, xmm6
000070404d1cf142  mov [r13+r12*1], r11
000070404d1cf147  lea r12, [r14+0x108]
000070404d1cf14e  mov [r13+r12*1], r10
000070404d1cf153  lea r12, [rax+0x100]
000070404d1cf15a  movups xmm7, [r13+r12*1]
000070404d1cf160  lea r12, [rax+0x110]
000070404d1cf167  movups xmm6, [r13+r12*1]
000070404d1cf16d  lea r12, [r14+0xB0]
000070404d1cf174  movups [r13+r12*1], xmm10
000070404d1cf17a  lea r12, [r14+0xC0]
000070404d1cf181  movups [r13+r12*1], xmm1
000070404d1cf187  lea r12, [rax+0x140]
000070404d1cf18e  movups xmm1, [r13+r12*1]
000070404d1cf194  lea r12, [rax+0x150]
000070404d1cf19b  movups xmm10, [r13+r12*1]
000070404d1cf1a1  lea r12, [r14+0x110]
000070404d1cf1a8  mov r11, [r15+0xE8]
000070404d1cf1af  mov [r13+r12*1], r11
000070404d1cf1b4  lea r12, [rax+0x180]
000070404d1cf1bb  movups xmm5, [r13+r12*1]
000070404d1cf1c1  lea r12, [rax+0x190]
000070404d1cf1c8  movups xmm4, [r13+r12*1]
000070404d1cf1ce  lea r12, [rax+0x1C0]
000070404d1cf1d5  movups xmm3, [r13+r12*1]
000070404d1cf1db  lea r12, [rax+0x1D0]
000070404d1cf1e2  movups xmm2, [r13+r12*1]
000070404d1cf1e8  lea r12, [rax+0x60]
000070404d1cf1ec  vmovaps [rsp+0x10], xmm1
000070404d1cf1f2  movups xmm1, [r13+r12*1]
000070404d1cf1f8  lea r12, [rax+0x70]
000070404d1cf1fc  vmovaps [rsp+0x20], xmm1
000070404d1cf202  movups xmm1, [r13+r12*1]
000070404d1cf208  lea r12, [r14+0x70]
000070404d1cf20c  movups [r13+r12*1], xmm4
000070404d1cf212  lea r12, [r14+0x80]
000070404d1cf219  movups [r13+r12*1], xmm5
000070404d1cf21f  lea r12, [rax+0xA0]
000070404d1cf226  movups xmm5, [r13+r12*1]
000070404d1cf22c  lea r12, [rax+0xB0]
000070404d1cf233  movups xmm4, [r13+r12*1]
000070404d1cf239  lea r12, [r14+0x90]
000070404d1cf240  movups [r13+r12*1], xmm2
000070404d1cf246  lea r12, [r14+0xA0]
000070404d1cf24d  movups [r13+r12*1], xmm3
000070404d1cf253  lea r12, [rax+0xE0]
000070404d1cf25a  movups xmm3, [r13+r12*1]
000070404d1cf260  lea r12, [rax+0xF0]
000070404d1cf267  movups xmm2, [r13+r12*1]
000070404d1cf26d  lea r12, [rax+0x120]
000070404d1cf274  vmovaps [rsp+0x30], xmm1
000070404d1cf27a  movups xmm1, [r13+r12*1]
000070404d1cf280  lea r12, [rax+0x130]
000070404d1cf287  vmovaps [rsp+0x40], xmm1
000070404d1cf28d  movups xmm1, [r13+r12*1]
000070404d1cf293  lea r12, [rax+0x160]
000070404d1cf29a  vmovaps [rsp+0x50], xmm1
000070404d1cf2a0  movups xmm1, [r13+r12*1]
000070404d1cf2a6  lea r12, [rax+0x170]
000070404d1cf2ad  vmovaps [rsp+0x60], xmm1
000070404d1cf2b3  movups xmm1, [r13+r12*1]
000070404d1cf2b9  lea r12, [rax+0x1A0]
000070404d1cf2c0  vmovaps [rsp+0x70], xmm1
000070404d1cf2c6  movups xmm1, [r13+r12*1]
000070404d1cf2cc  lea r12, [rax+0x1B0]
000070404d1cf2d3  vmovaps [rsp+0x80], xmm1
000070404d1cf2dc  movups xmm1, [r13+r12*1]
000070404d1cf2e2  lea r12, [rax+0x1E0]
000070404d1cf2e9  vmovaps [rsp+0x90], xmm1
000070404d1cf2f2  movups xmm1, [r13+r12*1]
000070404d1cf2f8  lea r12, [rax+0x1F0]
000070404d1cf2ff  vmovaps [rsp+0xA0], xmm1
000070404d1cf308  movups xmm1, [r13+r12*1]
000070404d1cf30e  mov qword ptr [r15+0x50], 0x4308D0
000070404d1cf316  lea rax, [r14+0x50]
000070404d1cf31a  vmovaps [rsp+0xB0], xmm1
000070404d1cf323  vmovaps xmm1, [rsp+0x60]
000070404d1cf329  movups [r13+rax*1], xmm1
000070404d1cf32f  lea rax, [r14+0x60]
000070404d1cf333  vmovaps xmm1, [rsp+0x10]
000070404d1cf339  movups [r13+rax*1], xmm1
000070404d1cf33f  lea rax, [r14+0x40]
000070404d1cf343  vmovaps xmm1, [rsp+0x70]
000070404d1cf349  movups [r13+rax*1], xmm1
000070404d1cf34f  lea rax, [r14+0x20]
000070404d1cf353  vmovaps xmm1, [rsp+0xA0]
000070404d1cf35c  movups [r13+rax*1], xmm1
000070404d1cf362  lea rax, [r14+0x30]
000070404d1cf366  vmovaps xmm1, [rsp+0x90]
000070404d1cf36f  movups [r13+rax*1], xmm1
000070404d1cf375  lea rax, [r14+0x10]
000070404d1cf379  vmovaps xmm1, [rsp+0xB0]
000070404d1cf382  movups [r13+rax*1], xmm1
000070404d1cf388  mov rax, [r15+0x40]
000070404d1cf38c  vxorps xmm1, xmm1, xmm1
000070404d1cf390  vpbroadcastq xmm1, xmm1
000070404d1cf395  vmovaps [rsp+0x10], xmm1
000070404d1cf39b  vxorps xmm1, xmm1, xmm1
000070404d1cf39f  vpbroadcastq xmm1, xmm1
000070404d1cf3a4  lea r12, [rax+0x30]
000070404d1cf3a8  mov r11, [r13+r12*1]
000070404d1cf3ad  lea r12, [rax+0x38]
000070404d1cf3b1  mov r10, [r13+r12*1]
000070404d1cf3b6  vmovaps [rsp+0x60], xmm1
000070404d1cf3bc  movq xmm1, r11
000070404d1cf3c1  vmovaps [rsp+0x70], xmm1
000070404d1cf3c7  movq xmm1, r10
000070404d1cf3cc  vmovaps [rsp+0x90], xmm1
000070404d1cf3d5  vmovaps xmm1, [rsp+0x70]
000070404d1cf3db  movq xmm1, xmm1
000070404d1cf3df  vmovaps [rsp+0x70], xmm1
000070404d1cf3e5  vmovaps xmm1, [rsp+0x90]
000070404d1cf3ee  movq xmm1, xmm1
000070404d1cf3f2  vmovaps [rsp+0x90], xmm1
000070404d1cf3fb  movq xmm1, xmm1
000070404d1cf3ff  movaps [r15+0x270], xmm1
000070404d1cf407  vmovaps [rsp+0xA0], xmm7
000070404d1cf410  vmovaps xmm1, [rsp+0xA0]
000070404d1cf419  por xmm7, xmm1
000070404d1cf41d  lea r12, [rax+0x20]
000070404d1cf421  mov r11, [r13+r12*1]
000070404d1cf426  lea r12, [rax+0x28]
000070404d1cf42a  mov r10, [r13+r12*1]
000070404d1cf42f  movq xmm1, r11
000070404d1cf434  vmovaps [rsp+0xA0], xmm1
000070404d1cf43d  movq xmm1, r10
000070404d1cf442  vmovaps [rsp+0xB0], xmm1
000070404d1cf44b  vmovaps xmm1, [rsp+0xA0]
000070404d1cf454  movq xmm1, xmm1
000070404d1cf458  vmovaps [rsp+0xA0], xmm1
000070404d1cf461  vmovaps xmm1, [rsp+0xB0]
000070404d1cf46a  movq xmm1, xmm1
000070404d1cf46e  vmovaps [rsp+0xB0], xmm2
000070404d1cf477  vmovaps [rsp+0xC0], xmm1
000070404d1cf480  vmovaps xmm1, [rsp+0xB0]
000070404d1cf489  por xmm2, xmm1
000070404d1cf48d  vmovaps xmm1, [rsp+0x40]
000070404d1cf493  vmovaps [rsp+0xB0], xmm15
000070404d1cf49c  vmovaps xmm15, [rsp+0x40]
000070404d1cf4a2  por xmm1, xmm15
000070404d1cf4a7  vmovaps [rsp+0x40], xmm3
000070404d1cf4ad  vmovaps xmm15, [rsp+0x40]
000070404d1cf4b3  por xmm3, xmm15
000070404d1cf4b8  vmovaps [rsp+0x40], xmm10
000070404d1cf4be  vmovaps xmm15, [rsp+0x40]
000070404d1cf4c4  por xmm10, xmm15
000070404d1cf4c9  vmovaps [rsp+0x40], xmm12
000070404d1cf4cf  vmovaps xmm15, [rsp+0x40]
000070404d1cf4d5  por xmm12, xmm15
000070404d1cf4da  lea r12, [rax+0x10]
000070404d1cf4de  mov r11, [r13+r12*1]
000070404d1cf4e3  lea r12, [rax+0x18]
000070404d1cf4e7  mov r10, [r13+r12*1]
000070404d1cf4ec  movq xmm15, r11
000070404d1cf4f1  vmovaps [rsp+0x40], xmm1
000070404d1cf4f7  movq xmm1, r10
000070404d1cf4fc  movq xmm15, xmm15
000070404d1cf501  movq xmm1, xmm1
000070404d1cf505  vmovaps [rsp+0xD0], xmm1
000070404d1cf50e  vmovaps xmm1, [rsp+0x80]
000070404d1cf517  vmovaps [rsp+0xE0], xmm15
000070404d1cf520  vmovaps xmm15, [rsp+0x80]
000070404d1cf529  por xmm1, xmm15
000070404d1cf52e  vmovaps xmm15, [rsp+0x30]
000070404d1cf534  vmovaps [rsp+0x80], xmm1
000070404d1cf53d  vmovaps xmm1, [rsp+0x30]
000070404d1cf543  por xmm15, xmm1
000070404d1cf548  vmovaps xmm1, [rsp+0x20]
000070404d1cf54e  vmovaps [rsp+0x30], xmm15
000070404d1cf554  vmovaps xmm15, [rsp+0x20]
000070404d1cf55a  por xmm1, xmm15
000070404d1cf55f  vmovaps [rsp+0x20], xmm6
000070404d1cf565  vmovaps xmm15, [rsp+0x20]
000070404d1cf56b  por xmm6, xmm15
000070404d1cf570  vmovaps [rsp+0x20], xmm13
000070404d1cf576  vmovaps xmm15, [rsp+0x20]
000070404d1cf57c  por xmm13, xmm15
000070404d1cf581  vmovaps [rsp+0x20], xmm8
000070404d1cf587  vmovaps xmm15, [rsp+0x20]
000070404d1cf58d  por xmm8, xmm15
000070404d1cf592  vmovaps [rsp+0x20], xmm9
000070404d1cf598  vmovaps xmm15, [rsp+0x20]
000070404d1cf59e  por xmm9, xmm15
000070404d1cf5a3  mov r12, [r13+rax*1]
000070404d1cf5a8  vmovq xmm15, r12
000070404d1cf5ad  vpbroadcastq xmm15, xmm15
000070404d1cf5b2  vmovaps [rsp+0x20], xmm1
000070404d1cf5b8  vxorps xmm1, xmm1, xmm1
000070404d1cf5bc  vpbroadcastq xmm1, xmm1
000070404d1cf5c1  vmovaps [rsp+0xF0], xmm1
000070404d1cf5ca  movups xmm1, [r13+r14*1]
000070404d1cf5d0  vmovaps [rsp+0x100], xmm1
000070404d1cf5d9  vxorps xmm1, xmm1, xmm1
000070404d1cf5dd  vpbroadcastq xmm1, xmm1
000070404d1cf5e2  lea r12, [rax+0x08]
000070404d1cf5e6  mov rax, [r13+r12*1]
000070404d1cf5eb  vmovaps [rsp+0x110], xmm1
000070404d1cf5f4  movq xmm1, rax
000070404d1cf5f9  movaps [r15+0x240], xmm1
000070404d1cf601  mov qword ptr [r15+0x60], 0x4308D0
000070404d1cf609  mov qword ptr [r15+0x58], 0x40
000070404d1cf611  vmovaps xmm1, [rsp+0x10]
000070404d1cf617  vmovaps [rsp+0x10], xmm15
000070404d1cf61d  vmovaps xmm15, [rsp+0x100]
000070404d1cf626  vmovaps [rsp+0x100], xmm14
000070404d1cf62f  vmovaps xmm14, [rsp+0x10]
000070404d1cf635  vmovaps [rsp+0x10], xmm13
000070404d1cf63b  vmovaps [rsp+0x120], xmm12
000070404d1cf644  movaps xmm13, xmm1
000070404d1cf648  vfmadd231pd xmm13, xmm15, xmm14
000070404d1cf64d  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1cf653  vptest xmm12, xmm12
000070404d1cf658  jnz 0x000070404D1D0283
000070404d1cf65e  vmovaps xmm1, [rsp+0x60]
000070404d1cf664  vmovaps xmm15, [rsp+0xB0]
000070404d1cf66d  vmovaps [rsp+0x60], xmm13
000070404d1cf673  movaps xmm12, xmm1
000070404d1cf677  vfmadd231pd xmm12, xmm15, xmm14
000070404d1cf67c  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1cf682  vptest xmm13, xmm13
000070404d1cf687  jnz 0x000070404D1D03DC
000070404d1cf68d  vmovaps xmm1, [rsp+0x50]
000070404d1cf693  vmovaps xmm13, [rsp+0x50]
000070404d1cf699  por xmm1, xmm13
000070404d1cf69e  vmovaps [rsp+0x50], xmm4
000070404d1cf6a4  vmovaps xmm13, [rsp+0x50]
000070404d1cf6aa  por xmm4, xmm13
000070404d1cf6af  vmovaps [rsp+0x50], xmm5
000070404d1cf6b5  vmovaps xmm13, [rsp+0x50]
000070404d1cf6bb  por xmm5, xmm13
000070404d1cf6c0  vmovaps [rsp+0x50], xmm11
000070404d1cf6c6  vmovaps xmm13, [rsp+0x50]
000070404d1cf6cc  por xmm11, xmm13
000070404d1cf6d1  vmovaps xmm13, [rsp+0x100]
000070404d1cf6da  vmovaps [rsp+0x50], xmm1
000070404d1cf6e0  vmovaps xmm1, [rsp+0x100]
000070404d1cf6e9  por xmm13, xmm1
000070404d1cf6ee  vmovaps [rsp+0xB0], xmm15
000070404d1cf6f7  vmovaps xmm1, [rsp+0xB0]
000070404d1cf700  por xmm15, xmm1
000070404d1cf705  lea rax, [r14+0xC0]
000070404d1cf70c  movups xmm1, [r13+rax*1]
000070404d1cf712  xor eax, eax
000070404d1cf714  mov r12d, 0x40
000070404d1cf71a  mov r11d, 0x200
000070404d1cf720  cmp r12, r11
000070404d1cf723  cmc
000070404d1cf724  lahf
000070404d1cf725  seto al
000070404d1cf728  mov [r15+0x108], eax
000070404d1cf72f  vmovaps [rsp+0xB0], xmm1
000070404d1cf738  vmovaps xmm1, [rsp+0xF0]
000070404d1cf741  vmovaps [rsp+0xF0], xmm15
000070404d1cf74a  vmovaps xmm15, [rsp+0xB0]
000070404d1cf753  vmovaps [rsp+0xB0], xmm13
000070404d1cf75c  vmovaps [rsp+0x100], xmm12
000070404d1cf765  movaps xmm13, xmm1
000070404d1cf769  vfmadd231pd xmm13, xmm15, xmm14
000070404d1cf76e  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1cf774  vptest xmm12, xmm12
000070404d1cf779  jnz 0x000070404D1D053F
000070404d1cf77f  lea rax, [r14+0xB0]
000070404d1cf786  movups xmm1, [r13+rax*1]
000070404d1cf78c  vmovaps xmm15, [rsp+0x110]
000070404d1cf795  vmovaps [rsp+0x110], xmm13
000070404d1cf79e  movaps xmm12, xmm15
000070404d1cf7a2  vfmadd231pd xmm12, xmm1, xmm14
000070404d1cf7a7  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1cf7ad  vptest xmm13, xmm13
000070404d1cf7b2  jnz 0x000070404D1D06A2
000070404d1cf7b8  vmovaps [rsp+0x130], xmm9
000070404d1cf7c1  vmovaps xmm1, [rsp+0x130]
000070404d1cf7ca  por xmm9, xmm1
000070404d1cf7cf  movaps [r15+0x210], xmm9
000070404d1cf7d7  vmovaps [rsp+0x130], xmm8
000070404d1cf7e0  vmovaps xmm1, [rsp+0x130]
000070404d1cf7e9  por xmm8, xmm1
000070404d1cf7ee  movaps [r15+0x1C0], xmm8
000070404d1cf7f6  vmovaps xmm1, [rsp+0x10]
000070404d1cf7fc  vmovaps xmm15, [rsp+0x10]
000070404d1cf802  por xmm1, xmm15
000070404d1cf807  movaps [r15+0x280], xmm1
000070404d1cf80f  vmovaps [rsp+0x10], xmm6
000070404d1cf815  vmovaps xmm14, [rsp+0x10]
000070404d1cf81b  por xmm6, xmm14
000070404d1cf820  movaps [r15+0x2A0], xmm6
000070404d1cf828  vmovaps xmm15, [rsp+0x20]
000070404d1cf82e  vmovaps xmm14, [rsp+0x20]
000070404d1cf834  por xmm15, xmm14
000070404d1cf839  movaps [r15+0x2E0], xmm15
000070404d1cf841  vmovaps xmm14, [rsp+0x30]
000070404d1cf847  vmovaps xmm13, [rsp+0x30]
000070404d1cf84d  por xmm14, xmm13
000070404d1cf852  movaps [r15+0x1F0], xmm14
000070404d1cf85a  vmovaps xmm13, [rsp+0xF0]
000070404d1cf863  vmovaps [rsp+0x10], xmm1
000070404d1cf869  vmovaps xmm1, [rsp+0xF0]
000070404d1cf872  por xmm13, xmm1
000070404d1cf877  movaps [r15+0x250], xmm13
000070404d1cf87f  vmovaps xmm1, [rsp+0xB0]
000070404d1cf888  vmovaps xmm13, [rsp+0xB0]
000070404d1cf891  por xmm1, xmm13
000070404d1cf896  movaps [r15+0x260], xmm1
000070404d1cf89e  vmovaps [rsp+0x20], xmm11
000070404d1cf8a4  vmovaps xmm13, [rsp+0x20]
000070404d1cf8aa  por xmm11, xmm13
000070404d1cf8af  movaps [r15+0x290], xmm11
000070404d1cf8b7  vmovaps [rsp+0x20], xmm5
000070404d1cf8bd  vmovaps xmm13, [rsp+0x20]
000070404d1cf8c3  por xmm5, xmm13
000070404d1cf8c8  movaps [r15+0x2C0], xmm5
000070404d1cf8d0  movq xmm13, qword ptr [r15+0x240]
000070404d1cf8d9  vmovaps [rsp+0x20], xmm13
000070404d1cf8df  vpermilpd xmm13, xmm13, 0x00
000070404d1cf8e5  vmovaps [rsp+0x30], xmm1
000070404d1cf8eb  vmovaps xmm1, [rsp+0x60]
000070404d1cf8f1  vmovaps [rsp+0x60], xmm15
000070404d1cf8f7  vmovaps [rsp+0xB0], xmm14
000070404d1cf900  movaps xmm15, xmm1
000070404d1cf904  vfmadd231pd xmm15, xmm9, xmm13
000070404d1cf909  vcmppd xmm14, xmm15, xmm15, 0x03
000070404d1cf90f  vptest xmm14, xmm14
000070404d1cf914  jnz 0x000070404D1D07FB
000070404d1cf91a  vmovaps xmm1, [rsp+0x20]
000070404d1cf920  vpermilpd xmm1, xmm1, 0x00
000070404d1cf926  vmovaps xmm14, [rsp+0x110]
000070404d1cf92f  vmovaps xmm13, [rsp+0x60]
000070404d1cf935  vmovaps [rsp+0x60], xmm15
000070404d1cf93b  movaps xmm9, xmm14
000070404d1cf93f  vfmadd231pd xmm9, xmm13, xmm1
000070404d1cf944  vcmppd xmm15, xmm9, xmm9, 0x03
000070404d1cf94a  vptest xmm15, xmm15
000070404d1cf94f  jnz 0x000070404D1D0954
000070404d1cf955  vmovaps xmm1, [rsp+0x20]
000070404d1cf95b  vpermilpd xmm1, xmm1, 0x00
000070404d1cf961  vmovaps xmm15, [rsp+0x100]
000070404d1cf96a  movaps xmm14, xmm15
000070404d1cf96e  vfmadd231pd xmm14, xmm8, xmm1
000070404d1cf973  vcmppd xmm13, xmm14, xmm14, 0x03
000070404d1cf979  vptest xmm13, xmm13
000070404d1cf97e  jnz 0x000070404D1D0AAD
000070404d1cf984  vmovaps [rsp+0xF0], xmm4
000070404d1cf98d  vmovaps xmm1, [rsp+0xF0]
000070404d1cf996  por xmm4, xmm1
000070404d1cf99a  movaps [r15+0x1D0], xmm4
000070404d1cf9a2  vmovaps xmm1, [rsp+0x20]
000070404d1cf9a8  vpermilpd xmm1, xmm1, 0x00
000070404d1cf9ae  vmovaps xmm13, [rsp+0xB0]
000070404d1cf9b7  movaps xmm15, xmm12
000070404d1cf9bb  vfmadd231pd xmm15, xmm13, xmm1
000070404d1cf9c0  vcmppd xmm8, xmm15, xmm15, 0x03
000070404d1cf9c6  vptest xmm8, xmm8
000070404d1cf9cb  jnz 0x000070404D1D0C06
000070404d1cf9d1  vmovaps xmm1, [rsp+0x80]
000070404d1cf9da  vmovaps xmm13, [rsp+0x80]
000070404d1cf9e3  por xmm1, xmm13
000070404d1cf9e8  movaps [r15+0x200], xmm1
000070404d1cf9f0  vmovaps xmm13, [rsp+0x50]
000070404d1cf9f6  vmovaps xmm12, [rsp+0x50]
000070404d1cf9fc  por xmm13, xmm12
000070404d1cfa01  movaps [r15+0x1E0], xmm13
000070404d1cfa09  vmovaps [rsp+0x20], xmm10
000070404d1cfa0f  vmovaps xmm13, [rsp+0x20]
000070404d1cfa15  por xmm10, xmm13
000070404d1cfa1a  movaps [r15+0x2B0], xmm10
000070404d1cfa22  vmovaps [rsp+0x20], xmm3
000070404d1cfa28  vmovaps xmm13, [rsp+0x20]
000070404d1cfa2e  por xmm3, xmm13
000070404d1cfa33  movaps [r15+0x300], xmm3
000070404d1cfa3b  vmovaps xmm8, [rsp+0xE0]
000070404d1cfa44  vpermilpd xmm8, xmm8, 0x00
000070404d1cfa4a  vmovaps xmm3, [rsp+0x60]
000070404d1cfa50  vmovaps [rsp+0x20], xmm1
000070404d1cfa56  vmovaps xmm1, [rsp+0x30]
000070404d1cfa5c  vmovaps [rsp+0x30], xmm15
000070404d1cfa62  vmovaps [rsp+0x50], xmm14
000070404d1cfa68  movaps xmm15, xmm3
000070404d1cfa6c  vfmadd231pd xmm15, xmm1, xmm8
000070404d1cfa71  vcmppd xmm14, xmm15, xmm15, 0x03
000070404d1cfa77  vptest xmm14, xmm14
000070404d1cfa7c  jnz 0x000070404D1D0D5F
000070404d1cfa82  vmovaps xmm1, [rsp+0xE0]
000070404d1cfa8b  vpermilpd xmm1, xmm1, 0x00
000070404d1cfa91  movaps xmm8, xmm9
000070404d1cfa95  vfmadd231pd xmm8, xmm5, xmm1
000070404d1cfa9a  vcmppd xmm14, xmm8, xmm8, 0x03
000070404d1cfaa0  vptest xmm14, xmm14
000070404d1cfaa5  jnz 0x000070404D1D0EB7
000070404d1cfaab  vmovaps xmm1, [rsp+0xE0]
000070404d1cfab4  vpermilpd xmm1, xmm1, 0x00
000070404d1cfaba  vmovaps xmm14, [rsp+0x50]
000070404d1cfac0  vmovaps xmm9, [rsp+0x10]
000070404d1cfac6  movaps xmm5, xmm14
000070404d1cfaca  vfmadd231pd xmm5, xmm9, xmm1
000070404d1cfacf  vcmppd xmm3, xmm5, xmm5, 0x03
000070404d1cfad4  vptest xmm3, xmm3
000070404d1cfad9  jnz 0x000070404D1D100F
000070404d1cfadf  vmovaps xmm1, [rsp+0xE0]
000070404d1cfae8  vpermilpd xmm1, xmm1, 0x00
000070404d1cfaee  vmovaps xmm14, [rsp+0x30]
000070404d1cfaf4  movaps xmm9, xmm14
000070404d1cfaf8  vfmadd231pd xmm9, xmm4, xmm1
000070404d1cfafd  vcmppd xmm3, xmm9, xmm9, 0x03
000070404d1cfb03  vptest xmm3, xmm3
000070404d1cfb08  jnz 0x000070404D1D1166
000070404d1cfb0e  vmovaps xmm1, [rsp+0x120]
000070404d1cfb17  vmovaps xmm14, [rsp+0x120]
000070404d1cfb20  por xmm1, xmm14
000070404d1cfb25  movaps [r15+0x180], xmm1
000070404d1cfb2d  vmovaps xmm14, [rsp+0x40]
000070404d1cfb33  vmovaps xmm4, [rsp+0x40]
000070404d1cfb39  por xmm14, xmm4
000070404d1cfb3e  movaps [r15+0x2D0], xmm14
000070404d1cfb46  vmovaps [rsp+0x10], xmm2
000070404d1cfb4c  vmovaps xmm4, [rsp+0x10]
000070404d1cfb52  por xmm2, xmm4
000070404d1cfb56  movaps [r15+0x2F0], xmm2
000070404d1cfb5e  vmovaps xmm3, [rsp+0xD0]
000070404d1cfb67  vpermilpd xmm3, xmm3, 0x00
000070404d1cfb6d  vmovaps [rsp+0x10], xmm1
000070404d1cfb73  movaps xmm2, xmm8
000070404d1cfb77  vfmadd231pd xmm2, xmm13, xmm3
000070404d1cfb7c  vcmppd xmm1, xmm2, xmm2, 0x03
000070404d1cfb81  vptest xmm1, xmm1
000070404d1cfb86  jnz 0x000070404D1D12BE
000070404d1cfb8c  vmovaps xmm1, [rsp+0xD0]
000070404d1cfb95  vpermilpd xmm1, xmm1, 0x00
000070404d1cfb9b  vmovaps xmm13, [rsp+0x10]
000070404d1cfba1  movaps xmm8, xmm15
000070404d1cfba5  vfmadd231pd xmm8, xmm13, xmm1
000070404d1cfbaa  vcmppd xmm3, xmm8, xmm8, 0x03
000070404d1cfbb0  vptest xmm3, xmm3
000070404d1cfbb5  jnz 0x000070404D1D1415
000070404d1cfbbb  lea rax, [r14+0x80]
000070404d1cfbc2  movups xmm1, [r13+rax*1]
000070404d1cfbc8  movaps [r15+0x190], xmm1
000070404d1cfbd0  vmovaps xmm15, [rsp+0xD0]
000070404d1cfbd9  vpermilpd xmm15, xmm15, 0x00
000070404d1cfbdf  movaps xmm13, xmm5
000070404d1cfbe3  vfmadd231pd xmm13, xmm11, xmm15
000070404d1cfbe8  vcmppd xmm3, xmm13, xmm13, 0x03
000070404d1cfbee  vptest xmm3, xmm3
000070404d1cfbf3  jnz 0x000070404D1D1578
000070404d1cfbf9  vmovaps xmm15, [rsp+0xD0]
000070404d1cfc02  vpermilpd xmm15, xmm15, 0x00
000070404d1cfc08  movaps xmm11, xmm9
000070404d1cfc0c  vfmadd231pd xmm11, xmm4, xmm15
000070404d1cfc11  vcmppd xmm5, xmm11, xmm11, 0x03
000070404d1cfc17  vptest xmm5, xmm5
000070404d1cfc1c  jnz 0x000070404D1D16D1
000070404d1cfc22  vmovaps [rsp+0x10], xmm7
000070404d1cfc28  vmovaps xmm9, [rsp+0x10]
000070404d1cfc2e  por xmm7, xmm9
000070404d1cfc33  movaps [r15+0x160], xmm7
000070404d1cfc3b  lea rax, [r14+0x40]
000070404d1cfc3f  movups xmm15, [r13+rax*1]
000070404d1cfc45  lea rax, [r14+0x50]
000070404d1cfc49  movups xmm9, [r13+rax*1]
000070404d1cfc4f  movaps [r15+0x1B0], xmm15
000070404d1cfc57  movaps [r15+0x1A0], xmm9
000070404d1cfc5f  vmovaps xmm5, [rsp+0xA0]
000070404d1cfc68  vpermilpd xmm5, xmm5, 0x00
000070404d1cfc6e  movaps xmm4, xmm2
000070404d1cfc71  vfmadd231pd xmm4, xmm14, xmm5
000070404d1cfc76  vcmppd xmm3, xmm4, xmm4, 0x03
000070404d1cfc7b  vptest xmm3, xmm3
000070404d1cfc80  jnz 0x000070404D1D183E
000070404d1cfc86  vmovaps xmm14, [rsp+0xA0]
000070404d1cfc8f  vpermilpd xmm14, xmm14, 0x00
000070404d1cfc95  movaps xmm5, xmm8
000070404d1cfc99  vfmadd231pd xmm5, xmm7, xmm14
000070404d1cfc9e  vcmppd xmm3, xmm5, xmm5, 0x03
000070404d1cfca3  vptest xmm3, xmm3
000070404d1cfca8  jnz 0x000070404D1D1994
000070404d1cfcae  vmovaps xmm14, [rsp+0xA0]
000070404d1cfcb7  vpermilpd xmm14, xmm14, 0x00
000070404d1cfcbd  movaps xmm8, xmm13
000070404d1cfcc1  vfmadd231pd xmm8, xmm6, xmm14
000070404d1cfcc6  vcmppd xmm7, xmm8, xmm8, 0x03
000070404d1cfccc  vptest xmm7, xmm7
000070404d1cfcd1  jnz 0x000070404D1D1AEB
000070404d1cfcd7  vmovaps xmm14, [rsp+0xA0]
000070404d1cfce0  vpermilpd xmm14, xmm14, 0x00
000070404d1cfce6  movaps xmm13, xmm11
000070404d1cfcea  vfmadd231pd xmm13, xmm12, xmm14
000070404d1cfcef  vcmppd xmm7, xmm13, xmm13, 0x03
000070404d1cfcf5  vptest xmm7, xmm7
000070404d1cfcfa  jnz 0x000070404D1D1C44
000070404d1cfd00  lea rax, [r14+0x60]
000070404d1cfd04  movups xmm14, [r13+rax*1]
000070404d1cfd0a  lea rax, [r14+0x70]
000070404d1cfd0e  movups xmm12, [r13+rax*1]
000070404d1cfd14  movaps [r15+0x150], xmm14
000070404d1cfd1c  movaps [r15+0x120], xmm12
000070404d1cfd24  vmovaps xmm11, [rsp+0xC0]
000070404d1cfd2d  vpermilpd xmm11, xmm11, 0x00
000070404d1cfd33  movaps xmm7, xmm4
000070404d1cfd36  vfmadd231pd xmm7, xmm9, xmm11
000070404d1cfd3b  vcmppd xmm6, xmm7, xmm7, 0x03
000070404d1cfd40  vptest xmm6, xmm6
000070404d1cfd45  jnz 0x000070404D1D1DB2
000070404d1cfd4b  vmovaps xmm11, [rsp+0xC0]
000070404d1cfd54  vpermilpd xmm11, xmm11, 0x00
000070404d1cfd5a  movaps xmm9, xmm5
000070404d1cfd5e  vfmadd231pd xmm9, xmm14, xmm11
000070404d1cfd63  vcmppd xmm6, xmm9, xmm9, 0x03
000070404d1cfd69  vptest xmm6, xmm6
000070404d1cfd6e  jnz 0x000070404D1D1F09
000070404d1cfd74  vmovaps xmm14, [rsp+0xC0]
000070404d1cfd7d  vpermilpd xmm14, xmm14, 0x00
000070404d1cfd83  movaps xmm11, xmm8
000070404d1cfd87  vfmadd231pd xmm11, xmm10, xmm14
000070404d1cfd8c  vcmppd xmm6, xmm11, xmm11, 0x03
000070404d1cfd92  vptest xmm6, xmm6
000070404d1cfd97  jnz 0x000070404D1D2062
000070404d1cfd9d  vmovaps xmm14, [rsp+0xC0]
000070404d1cfda6  vpermilpd xmm14, xmm14, 0x00
000070404d1cfdac  movaps xmm10, xmm13
000070404d1cfdb0  vfmadd231pd xmm10, xmm15, xmm14
000070404d1cfdb5  vcmppd xmm8, xmm10, xmm10, 0x03
000070404d1cfdbb  vptest xmm8, xmm8
000070404d1cfdc0  jnz 0x000070404D1D21BC
000070404d1cfdc6  lea rax, [r14+0x20]
000070404d1cfdca  movups xmm15, [r13+rax*1]
000070404d1cfdd0  lea rax, [r14+0x30]
000070404d1cfdd4  movups xmm14, [r13+rax*1]
000070404d1cfdda  vmovaps xmm13, [rsp+0x70]
000070404d1cfde0  vpermilpd xmm13, xmm13, 0x00
000070404d1cfde6  vmovaps xmm8, [rsp+0x20]
000070404d1cfdec  movaps xmm6, xmm7
000070404d1cfdef  vfmadd231pd xmm6, xmm8, xmm13
000070404d1cfdf4  vcmppd xmm5, xmm6, xmm6, 0x03
000070404d1cfdf9  vptest xmm5, xmm5
000070404d1cfdfe  jnz 0x000070404D1D232A
000070404d1cfe04  vmovaps xmm13, [rsp+0x70]
000070404d1cfe0a  vpermilpd xmm13, xmm13, 0x00
000070404d1cfe10  movaps xmm8, xmm9
000070404d1cfe14  vfmadd231pd xmm8, xmm1, xmm13
000070404d1cfe19  vcmppd xmm7, xmm8, xmm8, 0x03
000070404d1cfe1f  vptest xmm7, xmm7
000070404d1cfe24  jnz 0x000070404D1D2481
000070404d1cfe2a  vmovaps xmm1, [rsp+0x70]
000070404d1cfe30  vpermilpd xmm1, xmm1, 0x00
000070404d1cfe36  movaps xmm13, xmm11
000070404d1cfe3a  vfmadd231pd xmm13, xmm12, xmm1
000070404d1cfe3f  vcmppd xmm9, xmm13, xmm13, 0x03
000070404d1cfe45  vptest xmm9, xmm9
000070404d1cfe4a  jnz 0x000070404D1D25DA
000070404d1cfe50  vmovaps xmm1, [rsp+0x70]
000070404d1cfe56  vpermilpd xmm1, xmm1, 0x00
000070404d1cfe5c  movaps xmm12, xmm10
000070404d1cfe60  vfmadd231pd xmm12, xmm14, xmm1
000070404d1cfe65  vcmppd xmm11, xmm12, xmm12, 0x03
000070404d1cfe6b  vptest xmm11, xmm11
000070404d1cfe70  jnz 0x000070404D1D2733
000070404d1cfe76  lea rax, [r14+0x90]
000070404d1cfe7d  movups xmm1, [r13+rax*1]
000070404d1cfe83  lea rax, [r14+0xA0]
000070404d1cfe8a  movups xmm14, [r13+rax*1]
000070404d1cfe90  movaps [r15+0x140], xmm1
000070404d1cfe98  movaps [r15+0x130], xmm14
000070404d1cfea0  vmovaps xmm11, [rsp+0x90]
000070404d1cfea9  vpermilpd xmm11, xmm11, 0x00
000070404d1cfeaf  movaps xmm10, xmm6
000070404d1cfeb3  vfmadd231pd xmm10, xmm15, xmm11
000070404d1cfeb8  vcmppd xmm9, xmm10, xmm10, 0x03
000070404d1cfebe  vptest xmm9, xmm9
000070404d1cfec3  jnz 0x000070404D1D28A0
000070404d1cfec9  movaps [r15+0x220], xmm10
000070404d1cfed1  lea rax, [r14+0x10]
000070404d1cfed5  movups xmm15, [r13+rax*1]
000070404d1cfedb  movaps [r15+0x240], xmm15
000070404d1cfee3  vmovaps xmm11, [rsp+0x90]
000070404d1cfeec  vpermilpd xmm11, xmm11, 0x00
000070404d1cfef2  movaps xmm9, xmm8
000070404d1cfef6  vfmadd231pd xmm9, xmm14, xmm11
000070404d1cfefb  vcmppd xmm7, xmm9, xmm9, 0x03
000070404d1cff01  vptest xmm7, xmm7
000070404d1cff06  jnz 0x000070404D1D2A03
000070404d1cff0c  movaps [r15+0x110], xmm9
000070404d1cff14  vmovaps xmm14, [rsp+0x90]
000070404d1cff1d  vpermilpd xmm14, xmm14, 0x00
000070404d1cff23  movaps xmm11, xmm13
000070404d1cff27  vfmadd231pd xmm11, xmm1, xmm14
000070404d1cff2c  vcmppd xmm8, xmm11, xmm11, 0x03
000070404d1cff32  vptest xmm8, xmm8
000070404d1cff37  jnz 0x000070404D1D2B5D
000070404d1cff3d  movaps [r15+0x170], xmm11
000070404d1cff45  vmovaps xmm1, [rsp+0x90]
000070404d1cff4e  vpermilpd xmm1, xmm1, 0x00
000070404d1cff54  movaps xmm14, xmm12
000070404d1cff58  vfmadd231pd xmm14, xmm15, xmm1
000070404d1cff5d  vcmppd xmm13, xmm14, xmm14, 0x03
000070404d1cff63  vptest xmm13, xmm13
000070404d1cff68  jnz 0x000070404D1D2CB6
000070404d1cff6e  movaps [r15+0x230], xmm14
000070404d1cff76  mov eax, 0x4308D0
000070404d1cff7b  movups [r13+rax*1], xmm9
000070404d1cff81  mov eax, 0x4308E0
000070404d1cff86  movups [r13+rax*1], xmm11
000070404d1cff8c  mov eax, 0x4308F0
000070404d1cff91  movups [r13+rax*1], xmm10
000070404d1cff97  mov eax, 0x430900
000070404d1cff9c  movups [r13+rax*1], xmm14
000070404d1cffa2  mov eax, [r15+0x108]
000070404d1cffa9  sahf
000070404d1cffaa  jnz 0x000070404D1CFFDC
000070404d1cffac  cmp dword ptr [r15+0x318], 0x00
000070404d1cffb4  jz 0x000070404D1D67A0
000070404d1cffba  nop [rax+rax*1], ax
000070404d1cffc3  nop [rax+rax*1], eax
000070404d1cffcb  mov eax, 0x4103F0
000070404d1cffd0  mov [r15+0x100], rax
000070404d1cffd7  jmp 0x000070404CFFE110
000070404d1cffdc  cmp dword ptr [r15+0x318], 0x00
000070404d1cffe4  jz 0x000070404D1D2E40
000070404d1cffea  nop [rax+rax*1], ax
000070404d1cfff3  nop [rax+rax*1], eax
000070404d1cfffb  mov eax, 0x410274
000070404d1d0000  mov [r15+0x100], rax
000070404d1d0007  jmp 0x000070404CFFE110
000070404d1d000c  int3
000070404d1d000d  call 0x000070404CFFF430
000070404d1d0012  jmp 0x000070404D1CF00F
000070404d1d0017  call 0x000070404D0C4620
000070404d1d001c  jmp 0x000070404D1CF019
000070404d1d0021  call 0x000070404D0C0860
000070404d1d0026  jmp 0x000070404D1CF049
000070404d1d002b  call 0x000070404D0BF5F0
000070404d1d0030  jmp 0x000070404D1CF055
000070404d1d0035  call 0x000070404D0C33A0
000070404d1d003a  jmp 0x000070404D1CF062
000070404d1d003f  call 0x000070404D0C2120
000070404d1d0044  jmp 0x000070404D1CF06F
000070404d1d0049  call 0x000070404D0C0860
000070404d1d004e  jmp 0x000070404D1CF097
000070404d1d0053  call 0x000070404D0BF5F0
000070404d1d0058  jmp 0x000070404D1CF0A3
000070404d1d005d  call 0x000070404D0C0EA0
000070404d1d0062  jmp 0x000070404D1CF0B0
000070404d1d0067  call 0x000070404D0BFC30
000070404d1d006c  jmp 0x000070404D1CF0BD
000070404d1d0071  call 0x000070404D0D6600
000070404d1d0076  jmp 0x000070404D1CF0C3
000070404d1d007b  call 0x000070404D0B52F0
000070404d1d0080  jmp 0x000070404D1CF0CD
000070404d1d0085  call 0x000070404D0BE9C0
000070404d1d008a  jmp 0x000070404D1CF0D7
000070404d1d008f  call 0x000070404D0C0860
000070404d1d0094  jmp 0x000070404D1CF0FF
000070404d1d0099  call 0x000070404D0BF5F0
000070404d1d009e  jmp 0x000070404D1CF10B
000070404d1d00a3  call 0x000070404D0BD750
000070404d1d00a8  jmp 0x000070404D1CF115
000070404d1d00ad  call 0x000070404D0BC4E0
000070404d1d00b2  jmp 0x000070404D1CF11F
000070404d1d00b7  call 0x000070404D0C0860
000070404d1d00bc  jmp 0x000070404D1CF147
000070404d1d00c1  call 0x000070404D0BF5F0
000070404d1d00c6  jmp 0x000070404D1CF153
000070404d1d00cb  call 0x000070404D0BB270
000070404d1d00d0  jmp 0x000070404D1CF160
000070404d1d00d5  call 0x000070404D0BA000
000070404d1d00da  jmp 0x000070404D1CF16D
000070404d1d00df  call 0x000070404D0BEAE0
000070404d1d00e4  jmp 0x000070404D1CF17A
000070404d1d00e9  call 0x000070404D0B5400
000070404d1d00ee  jmp 0x000070404D1CF187
000070404d1d00f3  call 0x000070404D0B52F0
000070404d1d00f8  jmp 0x000070404D1CF194
000070404d1d00fd  call 0x000070404D0BE9C0
000070404d1d0102  jmp 0x000070404D1CF1A1
000070404d1d0107  call 0x000070404D0C0860
000070404d1d010c  jmp 0x000070404D1CF1B4
000070404d1d0111  call 0x000070404D0B8D90
000070404d1d0116  jmp 0x000070404D1CF1C1
000070404d1d011b  call 0x000070404D0B8A20
000070404d1d0120  jmp 0x000070404D1CF1CE
000070404d1d0125  call 0x000070404D0B77B0
000070404d1d012a  jmp 0x000070404D1CF1DB
000070404d1d012f  call 0x000070404D0B6550
000070404d1d0134  jmp 0x000070404D1CF1E8
000070404d1d0139  call 0x000070404D0B52F0
000070404d1d013e  jmp 0x000070404D1CF1F8
000070404d1d0143  call 0x000070404D0B52F0
000070404d1d0148  jmp 0x000070404D1CF208
000070404d1d014d  call 0x000070404D0B8B30
000070404d1d0152  jmp 0x000070404D1CF212
000070404d1d0157  call 0x000070404D0B8EA0
000070404d1d015c  jmp 0x000070404D1CF21F
000070404d1d0161  call 0x000070404D0B8D90
000070404d1d0166  jmp 0x000070404D1CF22C
000070404d1d016b  call 0x000070404D0B8A20
000070404d1d0170  jmp 0x000070404D1CF239
000070404d1d0175  call 0x000070404D0B6660
000070404d1d017a  jmp 0x000070404D1CF246
000070404d1d017f  call 0x000070404D0B78C0
000070404d1d0184  jmp 0x000070404D1CF253
000070404d1d0189  call 0x000070404D0B77B0
000070404d1d018e  jmp 0x000070404D1CF260
000070404d1d0193  call 0x000070404D0B6550
000070404d1d0198  jmp 0x000070404D1CF26D
000070404d1d019d  call 0x000070404D0B52F0
000070404d1d01a2  jmp 0x000070404D1CF280
000070404d1d01a7  call 0x000070404D0B52F0
000070404d1d01ac  jmp 0x000070404D1CF293
000070404d1d01b1  call 0x000070404D0B52F0
000070404d1d01b6  jmp 0x000070404D1CF2A6
000070404d1d01bb  call 0x000070404D0B52F0
000070404d1d01c0  jmp 0x000070404D1CF2B9
000070404d1d01c5  call 0x000070404D0B52F0
000070404d1d01ca  jmp 0x000070404D1CF2CC
000070404d1d01cf  call 0x000070404D0B52F0
000070404d1d01d4  jmp 0x000070404D1CF2E2
000070404d1d01d9  call 0x000070404D0B52F0
000070404d1d01de  jmp 0x000070404D1CF2F8
000070404d1d01e3  call 0x000070404D0B52F0
000070404d1d01e8  jmp 0x000070404D1CF30E
000070404d1d01ed  call 0x000070404CFFF540
000070404d1d01f2  jmp 0x000070404D1CF32F
000070404d1d01f7  call 0x000070404CFFF540
000070404d1d01fc  jmp 0x000070404D1CF33F
000070404d1d0201  call 0x000070404CFFF540
000070404d1d0206  jmp 0x000070404D1CF34F
000070404d1d020b  call 0x000070404CFFF540
000070404d1d0210  jmp 0x000070404D1CF362
000070404d1d0215  call 0x000070404CFFF540
000070404d1d021a  jmp 0x000070404D1CF375
000070404d1d021f  call 0x000070404CFFF540
000070404d1d0224  jmp 0x000070404D1CF388
000070404d1d0229  call 0x000070404D0C0370
000070404d1d022e  jmp 0x000070404D1CF3AD
000070404d1d0233  call 0x000070404D0BF100
000070404d1d0238  jmp 0x000070404D1CF3B6
000070404d1d023d  call 0x000070404D0C0370
000070404d1d0242  jmp 0x000070404D1CF426
000070404d1d0247  call 0x000070404D0BF100
000070404d1d024c  jmp 0x000070404D1CF42F
000070404d1d0251  call 0x000070404D0C0370
000070404d1d0256  jmp 0x000070404D1CF4E3
000070404d1d025b  call 0x000070404D0BF100
000070404d1d0260  jmp 0x000070404D1CF4EC
000070404d1d0265  call 0x000070404D00B720
000070404d1d026a  jmp 0x000070404D1CF5A8
000070404d1d026f  call 0x000070404D0D64F0
000070404d1d0274  jmp 0x000070404D1CF5D0
000070404d1d0279  call 0x000070404D0B47C0
000070404d1d027e  jmp 0x000070404D1CF5EB
000070404d1d0283  sub rsp, 0x08
000070404d1d0287  push rax
000070404d1d0288  push rcx
000070404d1d0289  push rdx
000070404d1d028a  push rdi
000070404d1d028b  push rsi
000070404d1d028c  push r8
000070404d1d028e  push r9
000070404d1d0290  push r10
000070404d1d0292  push r11
000070404d1d0294  sub rsp, 0xF0
000070404d1d029b  vmovaps [rsp], xmm0
000070404d1d02a0  vmovaps [rsp+0x10], xmm1
000070404d1d02a6  vmovaps [rsp+0x20], xmm2
000070404d1d02ac  vmovaps [rsp+0x30], xmm3
000070404d1d02b2  vmovaps [rsp+0x40], xmm4
000070404d1d02b8  vmovaps [rsp+0x50], xmm5
000070404d1d02be  vmovaps [rsp+0x60], xmm6
000070404d1d02c4  vmovaps [rsp+0x70], xmm7
000070404d1d02ca  vmovaps [rsp+0x80], xmm8
000070404d1d02d3  vmovaps [rsp+0x90], xmm9
000070404d1d02dc  vmovaps [rsp+0xA0], xmm10
000070404d1d02e5  vmovaps [rsp+0xB0], xmm11
000070404d1d02ee  vmovaps [rsp+0xC0], xmm12
000070404d1d02f7  vmovaps [rsp+0xD0], xmm14
000070404d1d0300  vmovaps [rsp+0xE0], xmm15
000070404d1d0309  sub rsp, 0x40
000070404d1d030d  lea rdi, [rsp]
000070404d1d0311  lea rsi, [rsp+0x10]
000070404d1d0316  lea rdx, [rsp+0x20]
000070404d1d031b  lea rcx, [rsp+0x30]
000070404d1d0320  mov r8d, 0x00
000070404d1d0326  lea r9, [r15+0x3A8]
000070404d1d032d  movaps [rdi], xmm13
000070404d1d0331  movaps [rsi], xmm1
000070404d1d0334  movaps [rdx], xmm15
000070404d1d0338  movaps [rcx], xmm14
000070404d1d033c  mov rax, 0x607928F07A50
000070404d1d0346  call rax
000070404d1d0348  movaps xmm13, [rsp]
000070404d1d034d  add rsp, 0x40
000070404d1d0351  vmovaps xmm0, [rsp]
000070404d1d0356  vmovaps xmm1, [rsp+0x10]
000070404d1d035c  vmovaps xmm2, [rsp+0x20]
000070404d1d0362  vmovaps xmm3, [rsp+0x30]
000070404d1d0368  vmovaps xmm4, [rsp+0x40]
000070404d1d036e  vmovaps xmm5, [rsp+0x50]
000070404d1d0374  vmovaps xmm6, [rsp+0x60]
000070404d1d037a  vmovaps xmm7, [rsp+0x70]
000070404d1d0380  vmovaps xmm8, [rsp+0x80]
000070404d1d0389  vmovaps xmm9, [rsp+0x90]
000070404d1d0392  vmovaps xmm10, [rsp+0xA0]
000070404d1d039b  vmovaps xmm11, [rsp+0xB0]
000070404d1d03a4  vmovaps xmm12, [rsp+0xC0]
000070404d1d03ad  vmovaps xmm14, [rsp+0xD0]
000070404d1d03b6  vmovaps xmm15, [rsp+0xE0]
000070404d1d03bf  add rsp, 0xF0
000070404d1d03c6  pop r11
000070404d1d03c8  pop r10
000070404d1d03ca  pop r9
000070404d1d03cc  pop r8
000070404d1d03ce  pop rsi
000070404d1d03cf  pop rdi
000070404d1d03d0  pop rdx
000070404d1d03d1  pop rcx
000070404d1d03d2  pop rax
000070404d1d03d3  add rsp, 0x08
000070404d1d03d7  jmp 0x000070404D1CF65E
000070404d1d03dc  sub rsp, 0x08
000070404d1d03e0  push rax
000070404d1d03e1  push rcx
000070404d1d03e2  push rdx
000070404d1d03e3  push rdi
000070404d1d03e4  push rsi
000070404d1d03e5  push r8
000070404d1d03e7  push r9
000070404d1d03e9  push r10
000070404d1d03eb  push r11
000070404d1d03ed  sub rsp, 0xF0
000070404d1d03f4  vmovaps [rsp], xmm0
000070404d1d03f9  vmovaps [rsp+0x10], xmm1
000070404d1d03ff  vmovaps [rsp+0x20], xmm2
000070404d1d0405  vmovaps [rsp+0x30], xmm3
000070404d1d040b  vmovaps [rsp+0x40], xmm4
000070404d1d0411  vmovaps [rsp+0x50], xmm5
000070404d1d0417  vmovaps [rsp+0x60], xmm6
000070404d1d041d  vmovaps [rsp+0x70], xmm7
000070404d1d0423  vmovaps [rsp+0x80], xmm8
000070404d1d042c  vmovaps [rsp+0x90], xmm9
000070404d1d0435  vmovaps [rsp+0xA0], xmm10
000070404d1d043e  vmovaps [rsp+0xB0], xmm11
000070404d1d0447  vmovaps [rsp+0xC0], xmm13
000070404d1d0450  vmovaps [rsp+0xD0], xmm14
000070404d1d0459  vmovaps [rsp+0xE0], xmm15
000070404d1d0462  sub rsp, 0x40
000070404d1d0466  lea rdi, [rsp]
000070404d1d046a  lea rsi, [rsp+0x10]
000070404d1d046f  lea rdx, [rsp+0x20]
000070404d1d0474  lea rcx, [rsp+0x30]
000070404d1d0479  mov r8d, 0x00
000070404d1d047f  lea r9, [r15+0x3A8]
000070404d1d0486  movaps [rdi], xmm12
000070404d1d048a  movaps [rsi], xmm1
000070404d1d048d  movaps [rdx], xmm15
000070404d1d0491  movaps [rcx], xmm14
000070404d1d0495  mov rax, 0x607928F07A50
000070404d1d049f  call rax
000070404d1d04a1  movaps xmm12, [rsp]
000070404d1d04a6  add rsp, 0x40
000070404d1d04aa  vmovaps xmm0, [rsp]
000070404d1d04af  vmovaps xmm1, [rsp+0x10]
000070404d1d04b5  vmovaps xmm2, [rsp+0x20]
000070404d1d04bb  vmovaps xmm3, [rsp+0x30]
000070404d1d04c1  vmovaps xmm4, [rsp+0x40]
000070404d1d04c7  vmovaps xmm5, [rsp+0x50]
000070404d1d04cd  vmovaps xmm6, [rsp+0x60]
000070404d1d04d3  vmovaps xmm7, [rsp+0x70]
000070404d1d04d9  vmovaps xmm8, [rsp+0x80]
000070404d1d04e2  vmovaps xmm9, [rsp+0x90]
000070404d1d04eb  vmovaps xmm10, [rsp+0xA0]
000070404d1d04f4  vmovaps xmm11, [rsp+0xB0]
000070404d1d04fd  vmovaps xmm13, [rsp+0xC0]
000070404d1d0506  vmovaps xmm14, [rsp+0xD0]
000070404d1d050f  vmovaps xmm15, [rsp+0xE0]
000070404d1d0518  add rsp, 0xF0
000070404d1d051f  pop r11
000070404d1d0521  pop r10
000070404d1d0523  pop r9
000070404d1d0525  pop r8
000070404d1d0527  pop rsi
000070404d1d0528  pop rdi
000070404d1d0529  pop rdx
000070404d1d052a  pop rcx
000070404d1d052b  pop rax
000070404d1d052c  add rsp, 0x08
000070404d1d0530  jmp 0x000070404D1CF68D
000070404d1d0535  call 0x000070404CFFF430
000070404d1d053a  jmp 0x000070404D1CF712
000070404d1d053f  sub rsp, 0x08
000070404d1d0543  push rax
000070404d1d0544  push rcx
000070404d1d0545  push rdx
000070404d1d0546  push rdi
000070404d1d0547  push rsi
000070404d1d0548  push r8
000070404d1d054a  push r9
000070404d1d054c  push r10
000070404d1d054e  push r11
000070404d1d0550  sub rsp, 0xF0
000070404d1d0557  vmovaps [rsp], xmm0
000070404d1d055c  vmovaps [rsp+0x10], xmm1
000070404d1d0562  vmovaps [rsp+0x20], xmm2
000070404d1d0568  vmovaps [rsp+0x30], xmm3
000070404d1d056e  vmovaps [rsp+0x40], xmm4
000070404d1d0574  vmovaps [rsp+0x50], xmm5
000070404d1d057a  vmovaps [rsp+0x60], xmm6
000070404d1d0580  vmovaps [rsp+0x70], xmm7
000070404d1d0586  vmovaps [rsp+0x80], xmm8
000070404d1d058f  vmovaps [rsp+0x90], xmm9
000070404d1d0598  vmovaps [rsp+0xA0], xmm10
000070404d1d05a1  vmovaps [rsp+0xB0], xmm11
000070404d1d05aa  vmovaps [rsp+0xC0], xmm12
000070404d1d05b3  vmovaps [rsp+0xD0], xmm14
000070404d1d05bc  vmovaps [rsp+0xE0], xmm15
000070404d1d05c5  sub rsp, 0x40
000070404d1d05c9  lea rdi, [rsp]
000070404d1d05cd  lea rsi, [rsp+0x10]
000070404d1d05d2  lea rdx, [rsp+0x20]
000070404d1d05d7  lea rcx, [rsp+0x30]
000070404d1d05dc  mov r8d, 0x00
000070404d1d05e2  lea r9, [r15+0x3A8]
000070404d1d05e9  movaps [rdi], xmm13
000070404d1d05ed  movaps [rsi], xmm1
000070404d1d05f0  movaps [rdx], xmm15
000070404d1d05f4  movaps [rcx], xmm14
000070404d1d05f8  mov rax, 0x607928F07A50
000070404d1d0602  call rax
000070404d1d0604  movaps xmm13, [rsp]
000070404d1d0609  add rsp, 0x40
000070404d1d060d  vmovaps xmm0, [rsp]
000070404d1d0612  vmovaps xmm1, [rsp+0x10]
000070404d1d0618  vmovaps xmm2, [rsp+0x20]
000070404d1d061e  vmovaps xmm3, [rsp+0x30]
000070404d1d0624  vmovaps xmm4, [rsp+0x40]
000070404d1d062a  vmovaps xmm5, [rsp+0x50]
000070404d1d0630  vmovaps xmm6, [rsp+0x60]
000070404d1d0636  vmovaps xmm7, [rsp+0x70]
000070404d1d063c  vmovaps xmm8, [rsp+0x80]
000070404d1d0645  vmovaps xmm9, [rsp+0x90]
000070404d1d064e  vmovaps xmm10, [rsp+0xA0]
000070404d1d0657  vmovaps xmm11, [rsp+0xB0]
000070404d1d0660  vmovaps xmm12, [rsp+0xC0]
000070404d1d0669  vmovaps xmm14, [rsp+0xD0]
000070404d1d0672  vmovaps xmm15, [rsp+0xE0]
000070404d1d067b  add rsp, 0xF0
000070404d1d0682  pop r11
000070404d1d0684  pop r10
000070404d1d0686  pop r9
000070404d1d0688  pop r8
000070404d1d068a  pop rsi
000070404d1d068b  pop rdi
000070404d1d068c  pop rdx
000070404d1d068d  pop rcx
000070404d1d068e  pop rax
000070404d1d068f  add rsp, 0x08
000070404d1d0693  jmp 0x000070404D1CF77F
000070404d1d0698  call 0x000070404CFFF430
000070404d1d069d  jmp 0x000070404D1CF78C
000070404d1d06a2  sub rsp, 0x08
000070404d1d06a6  push rax
000070404d1d06a7  push rcx
000070404d1d06a8  push rdx
000070404d1d06a9  push rdi
000070404d1d06aa  push rsi
000070404d1d06ab  push r8
000070404d1d06ad  push r9
000070404d1d06af  push r10
000070404d1d06b1  push r11
000070404d1d06b3  sub rsp, 0xF0
000070404d1d06ba  vmovaps [rsp], xmm0
000070404d1d06bf  vmovaps [rsp+0x10], xmm1
000070404d1d06c5  vmovaps [rsp+0x20], xmm2
000070404d1d06cb  vmovaps [rsp+0x30], xmm3
000070404d1d06d1  vmovaps [rsp+0x40], xmm4
000070404d1d06d7  vmovaps [rsp+0x50], xmm5
000070404d1d06dd  vmovaps [rsp+0x60], xmm6
000070404d1d06e3  vmovaps [rsp+0x70], xmm7
000070404d1d06e9  vmovaps [rsp+0x80], xmm8
000070404d1d06f2  vmovaps [rsp+0x90], xmm9
000070404d1d06fb  vmovaps [rsp+0xA0], xmm10
000070404d1d0704  vmovaps [rsp+0xB0], xmm11
000070404d1d070d  vmovaps [rsp+0xC0], xmm13
000070404d1d0716  vmovaps [rsp+0xD0], xmm14
000070404d1d071f  vmovaps [rsp+0xE0], xmm15
000070404d1d0728  sub rsp, 0x40
000070404d1d072c  lea rdi, [rsp]
000070404d1d0730  lea rsi, [rsp+0x10]
000070404d1d0735  lea rdx, [rsp+0x20]
000070404d1d073a  lea rcx, [rsp+0x30]
000070404d1d073f  mov r8d, 0x00
000070404d1d0745  lea r9, [r15+0x3A8]
000070404d1d074c  movaps [rdi], xmm12
000070404d1d0750  movaps [rsi], xmm15
000070404d1d0754  movaps [rdx], xmm1
000070404d1d0757  movaps [rcx], xmm14
000070404d1d075b  mov rax, 0x607928F07A50
000070404d1d0765  call rax
000070404d1d0767  movaps xmm12, [rsp]
000070404d1d076c  add rsp, 0x40
000070404d1d0770  vmovaps xmm0, [rsp]
000070404d1d0775  vmovaps xmm1, [rsp+0x10]
000070404d1d077b  vmovaps xmm2, [rsp+0x20]
000070404d1d0781  vmovaps xmm3, [rsp+0x30]
000070404d1d0787  vmovaps xmm4, [rsp+0x40]
000070404d1d078d  vmovaps xmm5, [rsp+0x50]
000070404d1d0793  vmovaps xmm6, [rsp+0x60]
000070404d1d0799  vmovaps xmm7, [rsp+0x70]
000070404d1d079f  vmovaps xmm8, [rsp+0x80]
000070404d1d07a8  vmovaps xmm9, [rsp+0x90]
000070404d1d07b1  vmovaps xmm10, [rsp+0xA0]
000070404d1d07ba  vmovaps xmm11, [rsp+0xB0]
000070404d1d07c3  vmovaps xmm13, [rsp+0xC0]
000070404d1d07cc  vmovaps xmm14, [rsp+0xD0]
000070404d1d07d5  vmovaps xmm15, [rsp+0xE0]
000070404d1d07de  add rsp, 0xF0
000070404d1d07e5  pop r11
000070404d1d07e7  pop r10
000070404d1d07e9  pop r9
000070404d1d07eb  pop r8
000070404d1d07ed  pop rsi
000070404d1d07ee  pop rdi
000070404d1d07ef  pop rdx
000070404d1d07f0  pop rcx
000070404d1d07f1  pop rax
000070404d1d07f2  add rsp, 0x08
000070404d1d07f6  jmp 0x000070404D1CF7B8
000070404d1d07fb  sub rsp, 0x08
000070404d1d07ff  push rax
000070404d1d0800  push rcx
000070404d1d0801  push rdx
000070404d1d0802  push rdi
000070404d1d0803  push rsi
000070404d1d0804  push r8
000070404d1d0806  push r9
000070404d1d0808  push r10
000070404d1d080a  push r11
000070404d1d080c  sub rsp, 0xF0
000070404d1d0813  vmovaps [rsp], xmm0
000070404d1d0818  vmovaps [rsp+0x10], xmm1
000070404d1d081e  vmovaps [rsp+0x20], xmm2
000070404d1d0824  vmovaps [rsp+0x30], xmm3
000070404d1d082a  vmovaps [rsp+0x40], xmm4
000070404d1d0830  vmovaps [rsp+0x50], xmm5
000070404d1d0836  vmovaps [rsp+0x60], xmm6
000070404d1d083c  vmovaps [rsp+0x70], xmm7
000070404d1d0842  vmovaps [rsp+0x80], xmm8
000070404d1d084b  vmovaps [rsp+0x90], xmm9
000070404d1d0854  vmovaps [rsp+0xA0], xmm10
000070404d1d085d  vmovaps [rsp+0xB0], xmm11
000070404d1d0866  vmovaps [rsp+0xC0], xmm12
000070404d1d086f  vmovaps [rsp+0xD0], xmm13
000070404d1d0878  vmovaps [rsp+0xE0], xmm14
000070404d1d0881  sub rsp, 0x40
000070404d1d0885  lea rdi, [rsp]
000070404d1d0889  lea rsi, [rsp+0x10]
000070404d1d088e  lea rdx, [rsp+0x20]
000070404d1d0893  lea rcx, [rsp+0x30]
000070404d1d0898  mov r8d, 0x00
000070404d1d089e  lea r9, [r15+0x3A8]
000070404d1d08a5  movaps [rdi], xmm15
000070404d1d08a9  movaps [rsi], xmm1
000070404d1d08ac  movaps [rdx], xmm9
000070404d1d08b0  movaps [rcx], xmm13
000070404d1d08b4  mov rax, 0x607928F07A50
000070404d1d08be  call rax
000070404d1d08c0  movaps xmm15, [rsp]
000070404d1d08c5  add rsp, 0x40
000070404d1d08c9  vmovaps xmm0, [rsp]
000070404d1d08ce  vmovaps xmm1, [rsp+0x10]
000070404d1d08d4  vmovaps xmm2, [rsp+0x20]
000070404d1d08da  vmovaps xmm3, [rsp+0x30]
000070404d1d08e0  vmovaps xmm4, [rsp+0x40]
000070404d1d08e6  vmovaps xmm5, [rsp+0x50]
000070404d1d08ec  vmovaps xmm6, [rsp+0x60]
000070404d1d08f2  vmovaps xmm7, [rsp+0x70]
000070404d1d08f8  vmovaps xmm8, [rsp+0x80]
000070404d1d0901  vmovaps xmm9, [rsp+0x90]
000070404d1d090a  vmovaps xmm10, [rsp+0xA0]
000070404d1d0913  vmovaps xmm11, [rsp+0xB0]
000070404d1d091c  vmovaps xmm12, [rsp+0xC0]
000070404d1d0925  vmovaps xmm13, [rsp+0xD0]
000070404d1d092e  vmovaps xmm14, [rsp+0xE0]
000070404d1d0937  add rsp, 0xF0
000070404d1d093e  pop r11
000070404d1d0940  pop r10
000070404d1d0942  pop r9
000070404d1d0944  pop r8
000070404d1d0946  pop rsi
000070404d1d0947  pop rdi
000070404d1d0948  pop rdx
000070404d1d0949  pop rcx
000070404d1d094a  pop rax
000070404d1d094b  add rsp, 0x08
000070404d1d094f  jmp 0x000070404D1CF91A
000070404d1d0954  sub rsp, 0x08
000070404d1d0958  push rax
000070404d1d0959  push rcx
000070404d1d095a  push rdx
000070404d1d095b  push rdi
000070404d1d095c  push rsi
000070404d1d095d  push r8
000070404d1d095f  push r9
000070404d1d0961  push r10
000070404d1d0963  push r11
000070404d1d0965  sub rsp, 0xF0
000070404d1d096c  vmovaps [rsp], xmm0
000070404d1d0971  vmovaps [rsp+0x10], xmm1
000070404d1d0977  vmovaps [rsp+0x20], xmm2
000070404d1d097d  vmovaps [rsp+0x30], xmm3
000070404d1d0983  vmovaps [rsp+0x40], xmm4
000070404d1d0989  vmovaps [rsp+0x50], xmm5
000070404d1d098f  vmovaps [rsp+0x60], xmm6
000070404d1d0995  vmovaps [rsp+0x70], xmm7
000070404d1d099b  vmovaps [rsp+0x80], xmm8
000070404d1d09a4  vmovaps [rsp+0x90], xmm10
000070404d1d09ad  vmovaps [rsp+0xA0], xmm11
000070404d1d09b6  vmovaps [rsp+0xB0], xmm12
000070404d1d09bf  vmovaps [rsp+0xC0], xmm13
000070404d1d09c8  vmovaps [rsp+0xD0], xmm14
000070404d1d09d1  vmovaps [rsp+0xE0], xmm15
000070404d1d09da  sub rsp, 0x40
000070404d1d09de  lea rdi, [rsp]
000070404d1d09e2  lea rsi, [rsp+0x10]
000070404d1d09e7  lea rdx, [rsp+0x20]
000070404d1d09ec  lea rcx, [rsp+0x30]
000070404d1d09f1  mov r8d, 0x00
000070404d1d09f7  lea r9, [r15+0x3A8]
000070404d1d09fe  movaps [rdi], xmm9
000070404d1d0a02  movaps [rsi], xmm14
000070404d1d0a06  movaps [rdx], xmm13
000070404d1d0a0a  movaps [rcx], xmm1
000070404d1d0a0d  mov rax, 0x607928F07A50
000070404d1d0a17  call rax
000070404d1d0a19  movaps xmm9, [rsp]
000070404d1d0a1e  add rsp, 0x40
000070404d1d0a22  vmovaps xmm0, [rsp]
000070404d1d0a27  vmovaps xmm1, [rsp+0x10]
000070404d1d0a2d  vmovaps xmm2, [rsp+0x20]
000070404d1d0a33  vmovaps xmm3, [rsp+0x30]
000070404d1d0a39  vmovaps xmm4, [rsp+0x40]
000070404d1d0a3f  vmovaps xmm5, [rsp+0x50]
000070404d1d0a45  vmovaps xmm6, [rsp+0x60]
000070404d1d0a4b  vmovaps xmm7, [rsp+0x70]
000070404d1d0a51  vmovaps xmm8, [rsp+0x80]
000070404d1d0a5a  vmovaps xmm10, [rsp+0x90]
000070404d1d0a63  vmovaps xmm11, [rsp+0xA0]
000070404d1d0a6c  vmovaps xmm12, [rsp+0xB0]
000070404d1d0a75  vmovaps xmm13, [rsp+0xC0]
000070404d1d0a7e  vmovaps xmm14, [rsp+0xD0]
000070404d1d0a87  vmovaps xmm15, [rsp+0xE0]
000070404d1d0a90  add rsp, 0xF0
000070404d1d0a97  pop r11
000070404d1d0a99  pop r10
000070404d1d0a9b  pop r9
000070404d1d0a9d  pop r8
000070404d1d0a9f  pop rsi
000070404d1d0aa0  pop rdi
000070404d1d0aa1  pop rdx
000070404d1d0aa2  pop rcx
000070404d1d0aa3  pop rax
000070404d1d0aa4  add rsp, 0x08
000070404d1d0aa8  jmp 0x000070404D1CF955
000070404d1d0aad  sub rsp, 0x08
000070404d1d0ab1  push rax
000070404d1d0ab2  push rcx
000070404d1d0ab3  push rdx
000070404d1d0ab4  push rdi
000070404d1d0ab5  push rsi
000070404d1d0ab6  push r8
000070404d1d0ab8  push r9
000070404d1d0aba  push r10
000070404d1d0abc  push r11
000070404d1d0abe  sub rsp, 0xF0
000070404d1d0ac5  vmovaps [rsp], xmm0
000070404d1d0aca  vmovaps [rsp+0x10], xmm1
000070404d1d0ad0  vmovaps [rsp+0x20], xmm2
000070404d1d0ad6  vmovaps [rsp+0x30], xmm3
000070404d1d0adc  vmovaps [rsp+0x40], xmm4
000070404d1d0ae2  vmovaps [rsp+0x50], xmm5
000070404d1d0ae8  vmovaps [rsp+0x60], xmm6
000070404d1d0aee  vmovaps [rsp+0x70], xmm7
000070404d1d0af4  vmovaps [rsp+0x80], xmm8
000070404d1d0afd  vmovaps [rsp+0x90], xmm9
000070404d1d0b06  vmovaps [rsp+0xA0], xmm10
000070404d1d0b0f  vmovaps [rsp+0xB0], xmm11
000070404d1d0b18  vmovaps [rsp+0xC0], xmm12
000070404d1d0b21  vmovaps [rsp+0xD0], xmm13
000070404d1d0b2a  vmovaps [rsp+0xE0], xmm15
000070404d1d0b33  sub rsp, 0x40
000070404d1d0b37  lea rdi, [rsp]
000070404d1d0b3b  lea rsi, [rsp+0x10]
000070404d1d0b40  lea rdx, [rsp+0x20]
000070404d1d0b45  lea rcx, [rsp+0x30]
000070404d1d0b4a  mov r8d, 0x00
000070404d1d0b50  lea r9, [r15+0x3A8]
000070404d1d0b57  movaps [rdi], xmm14
000070404d1d0b5b  movaps [rsi], xmm15
000070404d1d0b5f  movaps [rdx], xmm8
000070404d1d0b63  movaps [rcx], xmm1
000070404d1d0b66  mov rax, 0x607928F07A50
000070404d1d0b70  call rax
000070404d1d0b72  movaps xmm14, [rsp]
000070404d1d0b77  add rsp, 0x40
000070404d1d0b7b  vmovaps xmm0, [rsp]
000070404d1d0b80  vmovaps xmm1, [rsp+0x10]
000070404d1d0b86  vmovaps xmm2, [rsp+0x20]
000070404d1d0b8c  vmovaps xmm3, [rsp+0x30]
000070404d1d0b92  vmovaps xmm4, [rsp+0x40]
000070404d1d0b98  vmovaps xmm5, [rsp+0x50]
000070404d1d0b9e  vmovaps xmm6, [rsp+0x60]
000070404d1d0ba4  vmovaps xmm7, [rsp+0x70]
000070404d1d0baa  vmovaps xmm8, [rsp+0x80]
000070404d1d0bb3  vmovaps xmm9, [rsp+0x90]
000070404d1d0bbc  vmovaps xmm10, [rsp+0xA0]
000070404d1d0bc5  vmovaps xmm11, [rsp+0xB0]
000070404d1d0bce  vmovaps xmm12, [rsp+0xC0]
000070404d1d0bd7  vmovaps xmm13, [rsp+0xD0]
000070404d1d0be0  vmovaps xmm15, [rsp+0xE0]
000070404d1d0be9  add rsp, 0xF0
000070404d1d0bf0  pop r11
000070404d1d0bf2  pop r10
000070404d1d0bf4  pop r9
000070404d1d0bf6  pop r8
000070404d1d0bf8  pop rsi
000070404d1d0bf9  pop rdi
000070404d1d0bfa  pop rdx
000070404d1d0bfb  pop rcx
000070404d1d0bfc  pop rax
000070404d1d0bfd  add rsp, 0x08
000070404d1d0c01  jmp 0x000070404D1CF984
000070404d1d0c06  sub rsp, 0x08
000070404d1d0c0a  push rax
000070404d1d0c0b  push rcx
000070404d1d0c0c  push rdx
000070404d1d0c0d  push rdi
000070404d1d0c0e  push rsi
000070404d1d0c0f  push r8
000070404d1d0c11  push r9
000070404d1d0c13  push r10
000070404d1d0c15  push r11
000070404d1d0c17  sub rsp, 0xF0
000070404d1d0c1e  vmovaps [rsp], xmm0
000070404d1d0c23  vmovaps [rsp+0x10], xmm1
000070404d1d0c29  vmovaps [rsp+0x20], xmm2
000070404d1d0c2f  vmovaps [rsp+0x30], xmm3
000070404d1d0c35  vmovaps [rsp+0x40], xmm4
000070404d1d0c3b  vmovaps [rsp+0x50], xmm5
000070404d1d0c41  vmovaps [rsp+0x60], xmm6
000070404d1d0c47  vmovaps [rsp+0x70], xmm7
000070404d1d0c4d  vmovaps [rsp+0x80], xmm8
000070404d1d0c56  vmovaps [rsp+0x90], xmm9
000070404d1d0c5f  vmovaps [rsp+0xA0], xmm10
000070404d1d0c68  vmovaps [rsp+0xB0], xmm11
000070404d1d0c71  vmovaps [rsp+0xC0], xmm12
000070404d1d0c7a  vmovaps [rsp+0xD0], xmm13
000070404d1d0c83  vmovaps [rsp+0xE0], xmm14
000070404d1d0c8c  sub rsp, 0x40
000070404d1d0c90  lea rdi, [rsp]
000070404d1d0c94  lea rsi, [rsp+0x10]
000070404d1d0c99  lea rdx, [rsp+0x20]
000070404d1d0c9e  lea rcx, [rsp+0x30]
000070404d1d0ca3  mov r8d, 0x00
000070404d1d0ca9  lea r9, [r15+0x3A8]
000070404d1d0cb0  movaps [rdi], xmm15
000070404d1d0cb4  movaps [rsi], xmm12
000070404d1d0cb8  movaps [rdx], xmm13
000070404d1d0cbc  movaps [rcx], xmm1
000070404d1d0cbf  mov rax, 0x607928F07A50
000070404d1d0cc9  call rax
000070404d1d0ccb  movaps xmm15, [rsp]
000070404d1d0cd0  add rsp, 0x40
000070404d1d0cd4  vmovaps xmm0, [rsp]
000070404d1d0cd9  vmovaps xmm1, [rsp+0x10]
000070404d1d0cdf  vmovaps xmm2, [rsp+0x20]
000070404d1d0ce5  vmovaps xmm3, [rsp+0x30]
000070404d1d0ceb  vmovaps xmm4, [rsp+0x40]
000070404d1d0cf1  vmovaps xmm5, [rsp+0x50]
000070404d1d0cf7  vmovaps xmm6, [rsp+0x60]
000070404d1d0cfd  vmovaps xmm7, [rsp+0x70]
000070404d1d0d03  vmovaps xmm8, [rsp+0x80]
000070404d1d0d0c  vmovaps xmm9, [rsp+0x90]
000070404d1d0d15  vmovaps xmm10, [rsp+0xA0]
000070404d1d0d1e  vmovaps xmm11, [rsp+0xB0]
000070404d1d0d27  vmovaps xmm12, [rsp+0xC0]
000070404d1d0d30  vmovaps xmm13, [rsp+0xD0]
000070404d1d0d39  vmovaps xmm14, [rsp+0xE0]
000070404d1d0d42  add rsp, 0xF0
000070404d1d0d49  pop r11
000070404d1d0d4b  pop r10
000070404d1d0d4d  pop r9
000070404d1d0d4f  pop r8
000070404d1d0d51  pop rsi
000070404d1d0d52  pop rdi
000070404d1d0d53  pop rdx
000070404d1d0d54  pop rcx
000070404d1d0d55  pop rax
000070404d1d0d56  add rsp, 0x08
000070404d1d0d5a  jmp 0x000070404D1CF9D1
000070404d1d0d5f  sub rsp, 0x08
000070404d1d0d63  push rax
000070404d1d0d64  push rcx
000070404d1d0d65  push rdx
000070404d1d0d66  push rdi
000070404d1d0d67  push rsi
000070404d1d0d68  push r8
000070404d1d0d6a  push r9
000070404d1d0d6c  push r10
000070404d1d0d6e  push r11
000070404d1d0d70  sub rsp, 0xF0
000070404d1d0d77  vmovaps [rsp], xmm0
000070404d1d0d7c  vmovaps [rsp+0x10], xmm1
000070404d1d0d82  vmovaps [rsp+0x20], xmm2
000070404d1d0d88  vmovaps [rsp+0x30], xmm3
000070404d1d0d8e  vmovaps [rsp+0x40], xmm4
000070404d1d0d94  vmovaps [rsp+0x50], xmm5
000070404d1d0d9a  vmovaps [rsp+0x60], xmm6
000070404d1d0da0  vmovaps [rsp+0x70], xmm7
000070404d1d0da6  vmovaps [rsp+0x80], xmm8
000070404d1d0daf  vmovaps [rsp+0x90], xmm9
000070404d1d0db8  vmovaps [rsp+0xA0], xmm10
000070404d1d0dc1  vmovaps [rsp+0xB0], xmm11
000070404d1d0dca  vmovaps [rsp+0xC0], xmm12
000070404d1d0dd3  vmovaps [rsp+0xD0], xmm13
000070404d1d0ddc  vmovaps [rsp+0xE0], xmm14
000070404d1d0de5  sub rsp, 0x40
000070404d1d0de9  lea rdi, [rsp]
000070404d1d0ded  lea rsi, [rsp+0x10]
000070404d1d0df2  lea rdx, [rsp+0x20]
000070404d1d0df7  lea rcx, [rsp+0x30]
000070404d1d0dfc  mov r8d, 0x00
000070404d1d0e02  lea r9, [r15+0x3A8]
000070404d1d0e09  movaps [rdi], xmm15
000070404d1d0e0d  movaps [rsi], xmm3
000070404d1d0e10  movaps [rdx], xmm1
000070404d1d0e13  movaps [rcx], xmm8
000070404d1d0e17  mov rax, 0x607928F07A50
000070404d1d0e21  call rax
000070404d1d0e23  movaps xmm15, [rsp]
000070404d1d0e28  add rsp, 0x40
000070404d1d0e2c  vmovaps xmm0, [rsp]
000070404d1d0e31  vmovaps xmm1, [rsp+0x10]
000070404d1d0e37  vmovaps xmm2, [rsp+0x20]
000070404d1d0e3d  vmovaps xmm3, [rsp+0x30]
000070404d1d0e43  vmovaps xmm4, [rsp+0x40]
000070404d1d0e49  vmovaps xmm5, [rsp+0x50]
000070404d1d0e4f  vmovaps xmm6, [rsp+0x60]
000070404d1d0e55  vmovaps xmm7, [rsp+0x70]
000070404d1d0e5b  vmovaps xmm8, [rsp+0x80]
000070404d1d0e64  vmovaps xmm9, [rsp+0x90]
000070404d1d0e6d  vmovaps xmm10, [rsp+0xA0]
000070404d1d0e76  vmovaps xmm11, [rsp+0xB0]
000070404d1d0e7f  vmovaps xmm12, [rsp+0xC0]
000070404d1d0e88  vmovaps xmm13, [rsp+0xD0]
000070404d1d0e91  vmovaps xmm14, [rsp+0xE0]
000070404d1d0e9a  add rsp, 0xF0
000070404d1d0ea1  pop r11
000070404d1d0ea3  pop r10
000070404d1d0ea5  pop r9
000070404d1d0ea7  pop r8
000070404d1d0ea9  pop rsi
000070404d1d0eaa  pop rdi
000070404d1d0eab  pop rdx
000070404d1d0eac  pop rcx
000070404d1d0ead  pop rax
000070404d1d0eae  add rsp, 0x08
000070404d1d0eb2  jmp 0x000070404D1CFA82
000070404d1d0eb7  sub rsp, 0x08
000070404d1d0ebb  push rax
000070404d1d0ebc  push rcx
000070404d1d0ebd  push rdx
000070404d1d0ebe  push rdi
000070404d1d0ebf  push rsi
000070404d1d0ec0  push r8
000070404d1d0ec2  push r9
000070404d1d0ec4  push r10
000070404d1d0ec6  push r11
000070404d1d0ec8  sub rsp, 0xF0
000070404d1d0ecf  vmovaps [rsp], xmm0
000070404d1d0ed4  vmovaps [rsp+0x10], xmm1
000070404d1d0eda  vmovaps [rsp+0x20], xmm2
000070404d1d0ee0  vmovaps [rsp+0x30], xmm3
000070404d1d0ee6  vmovaps [rsp+0x40], xmm4
000070404d1d0eec  vmovaps [rsp+0x50], xmm5
000070404d1d0ef2  vmovaps [rsp+0x60], xmm6
000070404d1d0ef8  vmovaps [rsp+0x70], xmm7
000070404d1d0efe  vmovaps [rsp+0x80], xmm9
000070404d1d0f07  vmovaps [rsp+0x90], xmm10
000070404d1d0f10  vmovaps [rsp+0xA0], xmm11
000070404d1d0f19  vmovaps [rsp+0xB0], xmm12
000070404d1d0f22  vmovaps [rsp+0xC0], xmm13
000070404d1d0f2b  vmovaps [rsp+0xD0], xmm14
000070404d1d0f34  vmovaps [rsp+0xE0], xmm15
000070404d1d0f3d  sub rsp, 0x40
000070404d1d0f41  lea rdi, [rsp]
000070404d1d0f45  lea rsi, [rsp+0x10]
000070404d1d0f4a  lea rdx, [rsp+0x20]
000070404d1d0f4f  lea rcx, [rsp+0x30]
000070404d1d0f54  mov r8d, 0x00
000070404d1d0f5a  lea r9, [r15+0x3A8]
000070404d1d0f61  movaps [rdi], xmm8
000070404d1d0f65  movaps [rsi], xmm9
000070404d1d0f69  movaps [rdx], xmm5
000070404d1d0f6c  movaps [rcx], xmm1
000070404d1d0f6f  mov rax, 0x607928F07A50
000070404d1d0f79  call rax
000070404d1d0f7b  movaps xmm8, [rsp]
000070404d1d0f80  add rsp, 0x40
000070404d1d0f84  vmovaps xmm0, [rsp]
000070404d1d0f89  vmovaps xmm1, [rsp+0x10]
000070404d1d0f8f  vmovaps xmm2, [rsp+0x20]
000070404d1d0f95  vmovaps xmm3, [rsp+0x30]
000070404d1d0f9b  vmovaps xmm4, [rsp+0x40]
000070404d1d0fa1  vmovaps xmm5, [rsp+0x50]
000070404d1d0fa7  vmovaps xmm6, [rsp+0x60]
000070404d1d0fad  vmovaps xmm7, [rsp+0x70]
000070404d1d0fb3  vmovaps xmm9, [rsp+0x80]
000070404d1d0fbc  vmovaps xmm10, [rsp+0x90]
000070404d1d0fc5  vmovaps xmm11, [rsp+0xA0]
000070404d1d0fce  vmovaps xmm12, [rsp+0xB0]
000070404d1d0fd7  vmovaps xmm13, [rsp+0xC0]
000070404d1d0fe0  vmovaps xmm14, [rsp+0xD0]
000070404d1d0fe9  vmovaps xmm15, [rsp+0xE0]
000070404d1d0ff2  add rsp, 0xF0
000070404d1d0ff9  pop r11
000070404d1d0ffb  pop r10
000070404d1d0ffd  pop r9
000070404d1d0fff  pop r8
000070404d1d1001  pop rsi
000070404d1d1002  pop rdi
000070404d1d1003  pop rdx
000070404d1d1004  pop rcx
000070404d1d1005  pop rax
000070404d1d1006  add rsp, 0x08
000070404d1d100a  jmp 0x000070404D1CFAAB
000070404d1d100f  sub rsp, 0x08
000070404d1d1013  push rax
000070404d1d1014  push rcx
000070404d1d1015  push rdx
000070404d1d1016  push rdi
000070404d1d1017  push rsi
000070404d1d1018  push r8
000070404d1d101a  push r9
000070404d1d101c  push r10
000070404d1d101e  push r11
000070404d1d1020  sub rsp, 0xF0
000070404d1d1027  vmovaps [rsp], xmm0
000070404d1d102c  vmovaps [rsp+0x10], xmm1
000070404d1d1032  vmovaps [rsp+0x20], xmm2
000070404d1d1038  vmovaps [rsp+0x30], xmm3
000070404d1d103e  vmovaps [rsp+0x40], xmm4
000070404d1d1044  vmovaps [rsp+0x50], xmm6
000070404d1d104a  vmovaps [rsp+0x60], xmm7
000070404d1d1050  vmovaps [rsp+0x70], xmm8
000070404d1d1056  vmovaps [rsp+0x80], xmm9
000070404d1d105f  vmovaps [rsp+0x90], xmm10
000070404d1d1068  vmovaps [rsp+0xA0], xmm11
000070404d1d1071  vmovaps [rsp+0xB0], xmm12
000070404d1d107a  vmovaps [rsp+0xC0], xmm13
000070404d1d1083  vmovaps [rsp+0xD0], xmm14
000070404d1d108c  vmovaps [rsp+0xE0], xmm15
000070404d1d1095  sub rsp, 0x40
000070404d1d1099  lea rdi, [rsp]
000070404d1d109d  lea rsi, [rsp+0x10]
000070404d1d10a2  lea rdx, [rsp+0x20]
000070404d1d10a7  lea rcx, [rsp+0x30]
000070404d1d10ac  mov r8d, 0x00
000070404d1d10b2  lea r9, [r15+0x3A8]
000070404d1d10b9  movaps [rdi], xmm5
000070404d1d10bc  movaps [rsi], xmm14
000070404d1d10c0  movaps [rdx], xmm9
000070404d1d10c4  movaps [rcx], xmm1
000070404d1d10c7  mov rax, 0x607928F07A50
000070404d1d10d1  call rax
000070404d1d10d3  movaps xmm5, [rsp]
000070404d1d10d7  add rsp, 0x40
000070404d1d10db  vmovaps xmm0, [rsp]
000070404d1d10e0  vmovaps xmm1, [rsp+0x10]
000070404d1d10e6  vmovaps xmm2, [rsp+0x20]
000070404d1d10ec  vmovaps xmm3, [rsp+0x30]
000070404d1d10f2  vmovaps xmm4, [rsp+0x40]
000070404d1d10f8  vmovaps xmm6, [rsp+0x50]
000070404d1d10fe  vmovaps xmm7, [rsp+0x60]
000070404d1d1104  vmovaps xmm8, [rsp+0x70]
000070404d1d110a  vmovaps xmm9, [rsp+0x80]
000070404d1d1113  vmovaps xmm10, [rsp+0x90]
000070404d1d111c  vmovaps xmm11, [rsp+0xA0]
000070404d1d1125  vmovaps xmm12, [rsp+0xB0]
000070404d1d112e  vmovaps xmm13, [rsp+0xC0]
000070404d1d1137  vmovaps xmm14, [rsp+0xD0]
000070404d1d1140  vmovaps xmm15, [rsp+0xE0]
000070404d1d1149  add rsp, 0xF0
000070404d1d1150  pop r11
000070404d1d1152  pop r10
000070404d1d1154  pop r9
000070404d1d1156  pop r8
000070404d1d1158  pop rsi
000070404d1d1159  pop rdi
000070404d1d115a  pop rdx
000070404d1d115b  pop rcx
000070404d1d115c  pop rax
000070404d1d115d  add rsp, 0x08
000070404d1d1161  jmp 0x000070404D1CFADF
000070404d1d1166  sub rsp, 0x08
000070404d1d116a  push rax
000070404d1d116b  push rcx
000070404d1d116c  push rdx
000070404d1d116d  push rdi
000070404d1d116e  push rsi
000070404d1d116f  push r8
000070404d1d1171  push r9
000070404d1d1173  push r10
000070404d1d1175  push r11
000070404d1d1177  sub rsp, 0xF0
000070404d1d117e  vmovaps [rsp], xmm0
000070404d1d1183  vmovaps [rsp+0x10], xmm1
000070404d1d1189  vmovaps [rsp+0x20], xmm2
000070404d1d118f  vmovaps [rsp+0x30], xmm3
000070404d1d1195  vmovaps [rsp+0x40], xmm4
000070404d1d119b  vmovaps [rsp+0x50], xmm5
000070404d1d11a1  vmovaps [rsp+0x60], xmm6
000070404d1d11a7  vmovaps [rsp+0x70], xmm7
000070404d1d11ad  vmovaps [rsp+0x80], xmm8
000070404d1d11b6  vmovaps [rsp+0x90], xmm10
000070404d1d11bf  vmovaps [rsp+0xA0], xmm11
000070404d1d11c8  vmovaps [rsp+0xB0], xmm12
000070404d1d11d1  vmovaps [rsp+0xC0], xmm13
000070404d1d11da  vmovaps [rsp+0xD0], xmm14
000070404d1d11e3  vmovaps [rsp+0xE0], xmm15
000070404d1d11ec  sub rsp, 0x40
000070404d1d11f0  lea rdi, [rsp]
000070404d1d11f4  lea rsi, [rsp+0x10]
000070404d1d11f9  lea rdx, [rsp+0x20]
000070404d1d11fe  lea rcx, [rsp+0x30]
000070404d1d1203  mov r8d, 0x00
000070404d1d1209  lea r9, [r15+0x3A8]
000070404d1d1210  movaps [rdi], xmm9
000070404d1d1214  movaps [rsi], xmm14
000070404d1d1218  movaps [rdx], xmm4
000070404d1d121b  movaps [rcx], xmm1
000070404d1d121e  mov rax, 0x607928F07A50
000070404d1d1228  call rax
000070404d1d122a  movaps xmm9, [rsp]
000070404d1d122f  add rsp, 0x40
000070404d1d1233  vmovaps xmm0, [rsp]
000070404d1d1238  vmovaps xmm1, [rsp+0x10]
000070404d1d123e  vmovaps xmm2, [rsp+0x20]
000070404d1d1244  vmovaps xmm3, [rsp+0x30]
000070404d1d124a  vmovaps xmm4, [rsp+0x40]
000070404d1d1250  vmovaps xmm5, [rsp+0x50]
000070404d1d1256  vmovaps xmm6, [rsp+0x60]
000070404d1d125c  vmovaps xmm7, [rsp+0x70]
000070404d1d1262  vmovaps xmm8, [rsp+0x80]
000070404d1d126b  vmovaps xmm10, [rsp+0x90]
000070404d1d1274  vmovaps xmm11, [rsp+0xA0]
000070404d1d127d  vmovaps xmm12, [rsp+0xB0]
000070404d1d1286  vmovaps xmm13, [rsp+0xC0]
000070404d1d128f  vmovaps xmm14, [rsp+0xD0]
000070404d1d1298  vmovaps xmm15, [rsp+0xE0]
000070404d1d12a1  add rsp, 0xF0
000070404d1d12a8  pop r11
000070404d1d12aa  pop r10
000070404d1d12ac  pop r9
000070404d1d12ae  pop r8
000070404d1d12b0  pop rsi
000070404d1d12b1  pop rdi
000070404d1d12b2  pop rdx
000070404d1d12b3  pop rcx
000070404d1d12b4  pop rax
000070404d1d12b5  add rsp, 0x08
000070404d1d12b9  jmp 0x000070404D1CFB0E
000070404d1d12be  sub rsp, 0x08
000070404d1d12c2  push rax
000070404d1d12c3  push rcx
000070404d1d12c4  push rdx
000070404d1d12c5  push rdi
000070404d1d12c6  push rsi
000070404d1d12c7  push r8
000070404d1d12c9  push r9
000070404d1d12cb  push r10
000070404d1d12cd  push r11
000070404d1d12cf  sub rsp, 0xF0
000070404d1d12d6  vmovaps [rsp], xmm0
000070404d1d12db  vmovaps [rsp+0x10], xmm1
000070404d1d12e1  vmovaps [rsp+0x20], xmm3
000070404d1d12e7  vmovaps [rsp+0x30], xmm4
000070404d1d12ed  vmovaps [rsp+0x40], xmm5
000070404d1d12f3  vmovaps [rsp+0x50], xmm6
000070404d1d12f9  vmovaps [rsp+0x60], xmm7
000070404d1d12ff  vmovaps [rsp+0x70], xmm8
000070404d1d1305  vmovaps [rsp+0x80], xmm9
000070404d1d130e  vmovaps [rsp+0x90], xmm10
000070404d1d1317  vmovaps [rsp+0xA0], xmm11
000070404d1d1320  vmovaps [rsp+0xB0], xmm12
000070404d1d1329  vmovaps [rsp+0xC0], xmm13
000070404d1d1332  vmovaps [rsp+0xD0], xmm14
000070404d1d133b  vmovaps [rsp+0xE0], xmm15
000070404d1d1344  sub rsp, 0x40
000070404d1d1348  lea rdi, [rsp]
000070404d1d134c  lea rsi, [rsp+0x10]
000070404d1d1351  lea rdx, [rsp+0x20]
000070404d1d1356  lea rcx, [rsp+0x30]
000070404d1d135b  mov r8d, 0x00
000070404d1d1361  lea r9, [r15+0x3A8]
000070404d1d1368  movaps [rdi], xmm2
000070404d1d136b  movaps [rsi], xmm8
000070404d1d136f  movaps [rdx], xmm13
000070404d1d1373  movaps [rcx], xmm3
000070404d1d1376  mov rax, 0x607928F07A50
000070404d1d1380  call rax
000070404d1d1382  movaps xmm2, [rsp]
000070404d1d1386  add rsp, 0x40
000070404d1d138a  vmovaps xmm0, [rsp]
000070404d1d138f  vmovaps xmm1, [rsp+0x10]
000070404d1d1395  vmovaps xmm3, [rsp+0x20]
000070404d1d139b  vmovaps xmm4, [rsp+0x30]
000070404d1d13a1  vmovaps xmm5, [rsp+0x40]
000070404d1d13a7  vmovaps xmm6, [rsp+0x50]
000070404d1d13ad  vmovaps xmm7, [rsp+0x60]
000070404d1d13b3  vmovaps xmm8, [rsp+0x70]
000070404d1d13b9  vmovaps xmm9, [rsp+0x80]
000070404d1d13c2  vmovaps xmm10, [rsp+0x90]
000070404d1d13cb  vmovaps xmm11, [rsp+0xA0]
000070404d1d13d4  vmovaps xmm12, [rsp+0xB0]
000070404d1d13dd  vmovaps xmm13, [rsp+0xC0]
000070404d1d13e6  vmovaps xmm14, [rsp+0xD0]
000070404d1d13ef  vmovaps xmm15, [rsp+0xE0]
000070404d1d13f8  add rsp, 0xF0
000070404d1d13ff  pop r11
000070404d1d1401  pop r10
000070404d1d1403  pop r9
000070404d1d1405  pop r8
000070404d1d1407  pop rsi
000070404d1d1408  pop rdi
000070404d1d1409  pop rdx
000070404d1d140a  pop rcx
000070404d1d140b  pop rax
000070404d1d140c  add rsp, 0x08
000070404d1d1410  jmp 0x000070404D1CFB8C
000070404d1d1415  sub rsp, 0x08
000070404d1d1419  push rax
000070404d1d141a  push rcx
000070404d1d141b  push rdx
000070404d1d141c  push rdi
000070404d1d141d  push rsi
000070404d1d141e  push r8
000070404d1d1420  push r9
000070404d1d1422  push r10
000070404d1d1424  push r11
000070404d1d1426  sub rsp, 0xF0
000070404d1d142d  vmovaps [rsp], xmm0
000070404d1d1432  vmovaps [rsp+0x10], xmm1
000070404d1d1438  vmovaps [rsp+0x20], xmm2
000070404d1d143e  vmovaps [rsp+0x30], xmm3
000070404d1d1444  vmovaps [rsp+0x40], xmm4
000070404d1d144a  vmovaps [rsp+0x50], xmm5
000070404d1d1450  vmovaps [rsp+0x60], xmm6
000070404d1d1456  vmovaps [rsp+0x70], xmm7
000070404d1d145c  vmovaps [rsp+0x80], xmm9
000070404d1d1465  vmovaps [rsp+0x90], xmm10
000070404d1d146e  vmovaps [rsp+0xA0], xmm11
000070404d1d1477  vmovaps [rsp+0xB0], xmm12
000070404d1d1480  vmovaps [rsp+0xC0], xmm13
000070404d1d1489  vmovaps [rsp+0xD0], xmm14
000070404d1d1492  vmovaps [rsp+0xE0], xmm15
000070404d1d149b  sub rsp, 0x40
000070404d1d149f  lea rdi, [rsp]
000070404d1d14a3  lea rsi, [rsp+0x10]
000070404d1d14a8  lea rdx, [rsp+0x20]
000070404d1d14ad  lea rcx, [rsp+0x30]
000070404d1d14b2  mov r8d, 0x00
000070404d1d14b8  lea r9, [r15+0x3A8]
000070404d1d14bf  movaps [rdi], xmm8
000070404d1d14c3  movaps [rsi], xmm15
000070404d1d14c7  movaps [rdx], xmm13
000070404d1d14cb  movaps [rcx], xmm1
000070404d1d14ce  mov rax, 0x607928F07A50
000070404d1d14d8  call rax
000070404d1d14da  movaps xmm8, [rsp]
000070404d1d14df  add rsp, 0x40
000070404d1d14e3  vmovaps xmm0, [rsp]
000070404d1d14e8  vmovaps xmm1, [rsp+0x10]
000070404d1d14ee  vmovaps xmm2, [rsp+0x20]
000070404d1d14f4  vmovaps xmm3, [rsp+0x30]
000070404d1d14fa  vmovaps xmm4, [rsp+0x40]
000070404d1d1500  vmovaps xmm5, [rsp+0x50]
000070404d1d1506  vmovaps xmm6, [rsp+0x60]
000070404d1d150c  vmovaps xmm7, [rsp+0x70]
000070404d1d1512  vmovaps xmm9, [rsp+0x80]
000070404d1d151b  vmovaps xmm10, [rsp+0x90]
000070404d1d1524  vmovaps xmm11, [rsp+0xA0]
000070404d1d152d  vmovaps xmm12, [rsp+0xB0]
000070404d1d1536  vmovaps xmm13, [rsp+0xC0]
000070404d1d153f  vmovaps xmm14, [rsp+0xD0]
000070404d1d1548  vmovaps xmm15, [rsp+0xE0]
000070404d1d1551  add rsp, 0xF0
000070404d1d1558  pop r11
000070404d1d155a  pop r10
000070404d1d155c  pop r9
000070404d1d155e  pop r8
000070404d1d1560  pop rsi
000070404d1d1561  pop rdi
000070404d1d1562  pop rdx
000070404d1d1563  pop rcx
000070404d1d1564  pop rax
000070404d1d1565  add rsp, 0x08
000070404d1d1569  jmp 0x000070404D1CFBBB
000070404d1d156e  call 0x000070404CFFF430
000070404d1d1573  jmp 0x000070404D1CFBC8
000070404d1d1578  sub rsp, 0x08
000070404d1d157c  push rax
000070404d1d157d  push rcx
000070404d1d157e  push rdx
000070404d1d157f  push rdi
000070404d1d1580  push rsi
000070404d1d1581  push r8
000070404d1d1583  push r9
000070404d1d1585  push r10
000070404d1d1587  push r11
000070404d1d1589  sub rsp, 0xF0
000070404d1d1590  vmovaps [rsp], xmm0
000070404d1d1595  vmovaps [rsp+0x10], xmm1
000070404d1d159b  vmovaps [rsp+0x20], xmm2
000070404d1d15a1  vmovaps [rsp+0x30], xmm3
000070404d1d15a7  vmovaps [rsp+0x40], xmm4
000070404d1d15ad  vmovaps [rsp+0x50], xmm5
000070404d1d15b3  vmovaps [rsp+0x60], xmm6
000070404d1d15b9  vmovaps [rsp+0x70], xmm7
000070404d1d15bf  vmovaps [rsp+0x80], xmm8
000070404d1d15c8  vmovaps [rsp+0x90], xmm9
000070404d1d15d1  vmovaps [rsp+0xA0], xmm10
000070404d1d15da  vmovaps [rsp+0xB0], xmm11
000070404d1d15e3  vmovaps [rsp+0xC0], xmm12
000070404d1d15ec  vmovaps [rsp+0xD0], xmm14
000070404d1d15f5  vmovaps [rsp+0xE0], xmm15
000070404d1d15fe  sub rsp, 0x40
000070404d1d1602  lea rdi, [rsp]
000070404d1d1606  lea rsi, [rsp+0x10]
000070404d1d160b  lea rdx, [rsp+0x20]
000070404d1d1610  lea rcx, [rsp+0x30]
000070404d1d1615  mov r8d, 0x00
000070404d1d161b  lea r9, [r15+0x3A8]
000070404d1d1622  movaps [rdi], xmm13
000070404d1d1626  movaps [rsi], xmm5
000070404d1d1629  movaps [rdx], xmm11
000070404d1d162d  movaps [rcx], xmm15
000070404d1d1631  mov rax, 0x607928F07A50
000070404d1d163b  call rax
000070404d1d163d  movaps xmm13, [rsp]
000070404d1d1642  add rsp, 0x40
000070404d1d1646  vmovaps xmm0, [rsp]
000070404d1d164b  vmovaps xmm1, [rsp+0x10]
000070404d1d1651  vmovaps xmm2, [rsp+0x20]
000070404d1d1657  vmovaps xmm3, [rsp+0x30]
000070404d1d165d  vmovaps xmm4, [rsp+0x40]
000070404d1d1663  vmovaps xmm5, [rsp+0x50]
000070404d1d1669  vmovaps xmm6, [rsp+0x60]
000070404d1d166f  vmovaps xmm7, [rsp+0x70]
000070404d1d1675  vmovaps xmm8, [rsp+0x80]
000070404d1d167e  vmovaps xmm9, [rsp+0x90]
000070404d1d1687  vmovaps xmm10, [rsp+0xA0]
000070404d1d1690  vmovaps xmm11, [rsp+0xB0]
000070404d1d1699  vmovaps xmm12, [rsp+0xC0]
000070404d1d16a2  vmovaps xmm14, [rsp+0xD0]
000070404d1d16ab  vmovaps xmm15, [rsp+0xE0]
000070404d1d16b4  add rsp, 0xF0
000070404d1d16bb  pop r11
000070404d1d16bd  pop r10
000070404d1d16bf  pop r9
000070404d1d16c1  pop r8
000070404d1d16c3  pop rsi
000070404d1d16c4  pop rdi
000070404d1d16c5  pop rdx
000070404d1d16c6  pop rcx
000070404d1d16c7  pop rax
000070404d1d16c8  add rsp, 0x08
000070404d1d16cc  jmp 0x000070404D1CFBF9
000070404d1d16d1  sub rsp, 0x08
000070404d1d16d5  push rax
000070404d1d16d6  push rcx
000070404d1d16d7  push rdx
000070404d1d16d8  push rdi
000070404d1d16d9  push rsi
000070404d1d16da  push r8
000070404d1d16dc  push r9
000070404d1d16de  push r10
000070404d1d16e0  push r11
000070404d1d16e2  sub rsp, 0xF0
000070404d1d16e9  vmovaps [rsp], xmm0
000070404d1d16ee  vmovaps [rsp+0x10], xmm1
000070404d1d16f4  vmovaps [rsp+0x20], xmm2
000070404d1d16fa  vmovaps [rsp+0x30], xmm3
000070404d1d1700  vmovaps [rsp+0x40], xmm4
000070404d1d1706  vmovaps [rsp+0x50], xmm5
000070404d1d170c  vmovaps [rsp+0x60], xmm6
000070404d1d1712  vmovaps [rsp+0x70], xmm7
000070404d1d1718  vmovaps [rsp+0x80], xmm8
000070404d1d1721  vmovaps [rsp+0x90], xmm9
000070404d1d172a  vmovaps [rsp+0xA0], xmm10
000070404d1d1733  vmovaps [rsp+0xB0], xmm12
000070404d1d173c  vmovaps [rsp+0xC0], xmm13
000070404d1d1745  vmovaps [rsp+0xD0], xmm14
000070404d1d174e  vmovaps [rsp+0xE0], xmm15
000070404d1d1757  sub rsp, 0x40
000070404d1d175b  lea rdi, [rsp]
000070404d1d175f  lea rsi, [rsp+0x10]
000070404d1d1764  lea rdx, [rsp+0x20]
000070404d1d1769  lea rcx, [rsp+0x30]
000070404d1d176e  mov r8d, 0x00
000070404d1d1774  lea r9, [r15+0x3A8]
000070404d1d177b  movaps [rdi], xmm11
000070404d1d177f  movaps [rsi], xmm9
000070404d1d1783  movaps [rdx], xmm4
000070404d1d1786  movaps [rcx], xmm15
000070404d1d178a  mov rax, 0x607928F07A50
000070404d1d1794  call rax
000070404d1d1796  movaps xmm11, [rsp]
000070404d1d179b  add rsp, 0x40
000070404d1d179f  vmovaps xmm0, [rsp]
000070404d1d17a4  vmovaps xmm1, [rsp+0x10]
000070404d1d17aa  vmovaps xmm2, [rsp+0x20]
000070404d1d17b0  vmovaps xmm3, [rsp+0x30]
000070404d1d17b6  vmovaps xmm4, [rsp+0x40]
000070404d1d17bc  vmovaps xmm5, [rsp+0x50]
000070404d1d17c2  vmovaps xmm6, [rsp+0x60]
000070404d1d17c8  vmovaps xmm7, [rsp+0x70]
000070404d1d17ce  vmovaps xmm8, [rsp+0x80]
000070404d1d17d7  vmovaps xmm9, [rsp+0x90]
000070404d1d17e0  vmovaps xmm10, [rsp+0xA0]
000070404d1d17e9  vmovaps xmm12, [rsp+0xB0]
000070404d1d17f2  vmovaps xmm13, [rsp+0xC0]
000070404d1d17fb  vmovaps xmm14, [rsp+0xD0]
000070404d1d1804  vmovaps xmm15, [rsp+0xE0]
000070404d1d180d  add rsp, 0xF0
000070404d1d1814  pop r11
000070404d1d1816  pop r10
000070404d1d1818  pop r9
000070404d1d181a  pop r8
000070404d1d181c  pop rsi
000070404d1d181d  pop rdi
000070404d1d181e  pop rdx
000070404d1d181f  pop rcx
000070404d1d1820  pop rax
000070404d1d1821  add rsp, 0x08
000070404d1d1825  jmp 0x000070404D1CFC22
000070404d1d182a  call 0x000070404D00E760
000070404d1d182f  jmp 0x000070404D1CFC45
000070404d1d1834  call 0x000070404D007890
000070404d1d1839  jmp 0x000070404D1CFC4F
000070404d1d183e  sub rsp, 0x08
000070404d1d1842  push rax
000070404d1d1843  push rcx
000070404d1d1844  push rdx
000070404d1d1845  push rdi
000070404d1d1846  push rsi
000070404d1d1847  push r8
000070404d1d1849  push r9
000070404d1d184b  push r10
000070404d1d184d  push r11
000070404d1d184f  sub rsp, 0xF0
000070404d1d1856  vmovaps [rsp], xmm0
000070404d1d185b  vmovaps [rsp+0x10], xmm1
000070404d1d1861  vmovaps [rsp+0x20], xmm2
000070404d1d1867  vmovaps [rsp+0x30], xmm3
000070404d1d186d  vmovaps [rsp+0x40], xmm5
000070404d1d1873  vmovaps [rsp+0x50], xmm6
000070404d1d1879  vmovaps [rsp+0x60], xmm7
000070404d1d187f  vmovaps [rsp+0x70], xmm8
000070404d1d1885  vmovaps [rsp+0x80], xmm9
000070404d1d188e  vmovaps [rsp+0x90], xmm10
000070404d1d1897  vmovaps [rsp+0xA0], xmm11
000070404d1d18a0  vmovaps [rsp+0xB0], xmm12
000070404d1d18a9  vmovaps [rsp+0xC0], xmm13
000070404d1d18b2  vmovaps [rsp+0xD0], xmm14
000070404d1d18bb  vmovaps [rsp+0xE0], xmm15
000070404d1d18c4  sub rsp, 0x40
000070404d1d18c8  lea rdi, [rsp]
000070404d1d18cc  lea rsi, [rsp+0x10]
000070404d1d18d1  lea rdx, [rsp+0x20]
000070404d1d18d6  lea rcx, [rsp+0x30]
000070404d1d18db  mov r8d, 0x00
000070404d1d18e1  lea r9, [r15+0x3A8]
000070404d1d18e8  movaps [rdi], xmm4
000070404d1d18eb  movaps [rsi], xmm2
000070404d1d18ee  movaps [rdx], xmm14
000070404d1d18f2  movaps [rcx], xmm5
000070404d1d18f5  mov rax, 0x607928F07A50
000070404d1d18ff  call rax
000070404d1d1901  movaps xmm4, [rsp]
000070404d1d1905  add rsp, 0x40
000070404d1d1909  vmovaps xmm0, [rsp]
000070404d1d190e  vmovaps xmm1, [rsp+0x10]
000070404d1d1914  vmovaps xmm2, [rsp+0x20]
000070404d1d191a  vmovaps xmm3, [rsp+0x30]
000070404d1d1920  vmovaps xmm5, [rsp+0x40]
000070404d1d1926  vmovaps xmm6, [rsp+0x50]
000070404d1d192c  vmovaps xmm7, [rsp+0x60]
000070404d1d1932  vmovaps xmm8, [rsp+0x70]
000070404d1d1938  vmovaps xmm9, [rsp+0x80]
000070404d1d1941  vmovaps xmm10, [rsp+0x90]
000070404d1d194a  vmovaps xmm11, [rsp+0xA0]
000070404d1d1953  vmovaps xmm12, [rsp+0xB0]
000070404d1d195c  vmovaps xmm13, [rsp+0xC0]
000070404d1d1965  vmovaps xmm14, [rsp+0xD0]
000070404d1d196e  vmovaps xmm15, [rsp+0xE0]
000070404d1d1977  add rsp, 0xF0
000070404d1d197e  pop r11
000070404d1d1980  pop r10
000070404d1d1982  pop r9
000070404d1d1984  pop r8
000070404d1d1986  pop rsi
000070404d1d1987  pop rdi
000070404d1d1988  pop rdx
000070404d1d1989  pop rcx
000070404d1d198a  pop rax
000070404d1d198b  add rsp, 0x08
000070404d1d198f  jmp 0x000070404D1CFC86
000070404d1d1994  sub rsp, 0x08
000070404d1d1998  push rax
000070404d1d1999  push rcx
000070404d1d199a  push rdx
000070404d1d199b  push rdi
000070404d1d199c  push rsi
000070404d1d199d  push r8
000070404d1d199f  push r9
000070404d1d19a1  push r10
000070404d1d19a3  push r11
000070404d1d19a5  sub rsp, 0xF0
000070404d1d19ac  vmovaps [rsp], xmm0
000070404d1d19b1  vmovaps [rsp+0x10], xmm1
000070404d1d19b7  vmovaps [rsp+0x20], xmm2
000070404d1d19bd  vmovaps [rsp+0x30], xmm3
000070404d1d19c3  vmovaps [rsp+0x40], xmm4
000070404d1d19c9  vmovaps [rsp+0x50], xmm6
000070404d1d19cf  vmovaps [rsp+0x60], xmm7
000070404d1d19d5  vmovaps [rsp+0x70], xmm8
000070404d1d19db  vmovaps [rsp+0x80], xmm9
000070404d1d19e4  vmovaps [rsp+0x90], xmm10
000070404d1d19ed  vmovaps [rsp+0xA0], xmm11
000070404d1d19f6  vmovaps [rsp+0xB0], xmm12
000070404d1d19ff  vmovaps [rsp+0xC0], xmm13
000070404d1d1a08  vmovaps [rsp+0xD0], xmm14
000070404d1d1a11  vmovaps [rsp+0xE0], xmm15
000070404d1d1a1a  sub rsp, 0x40
000070404d1d1a1e  lea rdi, [rsp]
000070404d1d1a22  lea rsi, [rsp+0x10]
000070404d1d1a27  lea rdx, [rsp+0x20]
000070404d1d1a2c  lea rcx, [rsp+0x30]
000070404d1d1a31  mov r8d, 0x00
000070404d1d1a37  lea r9, [r15+0x3A8]
000070404d1d1a3e  movaps [rdi], xmm5
000070404d1d1a41  movaps [rsi], xmm8
000070404d1d1a45  movaps [rdx], xmm7
000070404d1d1a48  movaps [rcx], xmm14
000070404d1d1a4c  mov rax, 0x607928F07A50
000070404d1d1a56  call rax
000070404d1d1a58  movaps xmm5, [rsp]
000070404d1d1a5c  add rsp, 0x40
000070404d1d1a60  vmovaps xmm0, [rsp]
000070404d1d1a65  vmovaps xmm1, [rsp+0x10]
000070404d1d1a6b  vmovaps xmm2, [rsp+0x20]
000070404d1d1a71  vmovaps xmm3, [rsp+0x30]
000070404d1d1a77  vmovaps xmm4, [rsp+0x40]
000070404d1d1a7d  vmovaps xmm6, [rsp+0x50]
000070404d1d1a83  vmovaps xmm7, [rsp+0x60]
000070404d1d1a89  vmovaps xmm8, [rsp+0x70]
000070404d1d1a8f  vmovaps xmm9, [rsp+0x80]
000070404d1d1a98  vmovaps xmm10, [rsp+0x90]
000070404d1d1aa1  vmovaps xmm11, [rsp+0xA0]
000070404d1d1aaa  vmovaps xmm12, [rsp+0xB0]
000070404d1d1ab3  vmovaps xmm13, [rsp+0xC0]
000070404d1d1abc  vmovaps xmm14, [rsp+0xD0]
000070404d1d1ac5  vmovaps xmm15, [rsp+0xE0]
000070404d1d1ace  add rsp, 0xF0
000070404d1d1ad5  pop r11
000070404d1d1ad7  pop r10
000070404d1d1ad9  pop r9
000070404d1d1adb  pop r8
000070404d1d1add  pop rsi
000070404d1d1ade  pop rdi
000070404d1d1adf  pop rdx
000070404d1d1ae0  pop rcx
000070404d1d1ae1  pop rax
000070404d1d1ae2  add rsp, 0x08
000070404d1d1ae6  jmp 0x000070404D1CFCAE
000070404d1d1aeb  sub rsp, 0x08
000070404d1d1aef  push rax
000070404d1d1af0  push rcx
000070404d1d1af1  push rdx
000070404d1d1af2  push rdi
000070404d1d1af3  push rsi
000070404d1d1af4  push r8
000070404d1d1af6  push r9
000070404d1d1af8  push r10
000070404d1d1afa  push r11
000070404d1d1afc  sub rsp, 0xF0
000070404d1d1b03  vmovaps [rsp], xmm0
000070404d1d1b08  vmovaps [rsp+0x10], xmm1
000070404d1d1b0e  vmovaps [rsp+0x20], xmm2
000070404d1d1b14  vmovaps [rsp+0x30], xmm3
000070404d1d1b1a  vmovaps [rsp+0x40], xmm4
000070404d1d1b20  vmovaps [rsp+0x50], xmm5
000070404d1d1b26  vmovaps [rsp+0x60], xmm6
000070404d1d1b2c  vmovaps [rsp+0x70], xmm7
000070404d1d1b32  vmovaps [rsp+0x80], xmm9
000070404d1d1b3b  vmovaps [rsp+0x90], xmm10
000070404d1d1b44  vmovaps [rsp+0xA0], xmm11
000070404d1d1b4d  vmovaps [rsp+0xB0], xmm12
000070404d1d1b56  vmovaps [rsp+0xC0], xmm13
000070404d1d1b5f  vmovaps [rsp+0xD0], xmm14
000070404d1d1b68  vmovaps [rsp+0xE0], xmm15
000070404d1d1b71  sub rsp, 0x40
000070404d1d1b75  lea rdi, [rsp]
000070404d1d1b79  lea rsi, [rsp+0x10]
000070404d1d1b7e  lea rdx, [rsp+0x20]
000070404d1d1b83  lea rcx, [rsp+0x30]
000070404d1d1b88  mov r8d, 0x00
000070404d1d1b8e  lea r9, [r15+0x3A8]
000070404d1d1b95  movaps [rdi], xmm8
000070404d1d1b99  movaps [rsi], xmm13
000070404d1d1b9d  movaps [rdx], xmm6
000070404d1d1ba0  movaps [rcx], xmm14
000070404d1d1ba4  mov rax, 0x607928F07A50
000070404d1d1bae  call rax
000070404d1d1bb0  movaps xmm8, [rsp]
000070404d1d1bb5  add rsp, 0x40
000070404d1d1bb9  vmovaps xmm0, [rsp]
000070404d1d1bbe  vmovaps xmm1, [rsp+0x10]
000070404d1d1bc4  vmovaps xmm2, [rsp+0x20]
000070404d1d1bca  vmovaps xmm3, [rsp+0x30]
000070404d1d1bd0  vmovaps xmm4, [rsp+0x40]
000070404d1d1bd6  vmovaps xmm5, [rsp+0x50]
000070404d1d1bdc  vmovaps xmm6, [rsp+0x60]
000070404d1d1be2  vmovaps xmm7, [rsp+0x70]
000070404d1d1be8  vmovaps xmm9, [rsp+0x80]
000070404d1d1bf1  vmovaps xmm10, [rsp+0x90]
000070404d1d1bfa  vmovaps xmm11, [rsp+0xA0]
000070404d1d1c03  vmovaps xmm12, [rsp+0xB0]
000070404d1d1c0c  vmovaps xmm13, [rsp+0xC0]
000070404d1d1c15  vmovaps xmm14, [rsp+0xD0]
000070404d1d1c1e  vmovaps xmm15, [rsp+0xE0]
000070404d1d1c27  add rsp, 0xF0
000070404d1d1c2e  pop r11
000070404d1d1c30  pop r10
000070404d1d1c32  pop r9
000070404d1d1c34  pop r8
000070404d1d1c36  pop rsi
000070404d1d1c37  pop rdi
000070404d1d1c38  pop rdx
000070404d1d1c39  pop rcx
000070404d1d1c3a  pop rax
000070404d1d1c3b  add rsp, 0x08
000070404d1d1c3f  jmp 0x000070404D1CFCD7
000070404d1d1c44  sub rsp, 0x08
000070404d1d1c48  push rax
000070404d1d1c49  push rcx
000070404d1d1c4a  push rdx
000070404d1d1c4b  push rdi
000070404d1d1c4c  push rsi
000070404d1d1c4d  push r8
000070404d1d1c4f  push r9
000070404d1d1c51  push r10
000070404d1d1c53  push r11
000070404d1d1c55  sub rsp, 0xF0
000070404d1d1c5c  vmovaps [rsp], xmm0
000070404d1d1c61  vmovaps [rsp+0x10], xmm1
000070404d1d1c67  vmovaps [rsp+0x20], xmm2
000070404d1d1c6d  vmovaps [rsp+0x30], xmm3
000070404d1d1c73  vmovaps [rsp+0x40], xmm4
000070404d1d1c79  vmovaps [rsp+0x50], xmm5
000070404d1d1c7f  vmovaps [rsp+0x60], xmm6
000070404d1d1c85  vmovaps [rsp+0x70], xmm7
000070404d1d1c8b  vmovaps [rsp+0x80], xmm8
000070404d1d1c94  vmovaps [rsp+0x90], xmm9
000070404d1d1c9d  vmovaps [rsp+0xA0], xmm10
000070404d1d1ca6  vmovaps [rsp+0xB0], xmm11
000070404d1d1caf  vmovaps [rsp+0xC0], xmm12
000070404d1d1cb8  vmovaps [rsp+0xD0], xmm14
000070404d1d1cc1  vmovaps [rsp+0xE0], xmm15
000070404d1d1cca  sub rsp, 0x40
000070404d1d1cce  lea rdi, [rsp]
000070404d1d1cd2  lea rsi, [rsp+0x10]
000070404d1d1cd7  lea rdx, [rsp+0x20]
000070404d1d1cdc  lea rcx, [rsp+0x30]
000070404d1d1ce1  mov r8d, 0x00
000070404d1d1ce7  lea r9, [r15+0x3A8]
000070404d1d1cee  movaps [rdi], xmm13
000070404d1d1cf2  movaps [rsi], xmm11
000070404d1d1cf6  movaps [rdx], xmm12
000070404d1d1cfa  movaps [rcx], xmm14
000070404d1d1cfe  mov rax, 0x607928F07A50
000070404d1d1d08  call rax
000070404d1d1d0a  movaps xmm13, [rsp]
000070404d1d1d0f  add rsp, 0x40
000070404d1d1d13  vmovaps xmm0, [rsp]
000070404d1d1d18  vmovaps xmm1, [rsp+0x10]
000070404d1d1d1e  vmovaps xmm2, [rsp+0x20]
000070404d1d1d24  vmovaps xmm3, [rsp+0x30]
000070404d1d1d2a  vmovaps xmm4, [rsp+0x40]
000070404d1d1d30  vmovaps xmm5, [rsp+0x50]
000070404d1d1d36  vmovaps xmm6, [rsp+0x60]
000070404d1d1d3c  vmovaps xmm7, [rsp+0x70]
000070404d1d1d42  vmovaps xmm8, [rsp+0x80]
000070404d1d1d4b  vmovaps xmm9, [rsp+0x90]
000070404d1d1d54  vmovaps xmm10, [rsp+0xA0]
000070404d1d1d5d  vmovaps xmm11, [rsp+0xB0]
000070404d1d1d66  vmovaps xmm12, [rsp+0xC0]
000070404d1d1d6f  vmovaps xmm14, [rsp+0xD0]
000070404d1d1d78  vmovaps xmm15, [rsp+0xE0]
000070404d1d1d81  add rsp, 0xF0
000070404d1d1d88  pop r11
000070404d1d1d8a  pop r10
000070404d1d1d8c  pop r9
000070404d1d1d8e  pop r8
000070404d1d1d90  pop rsi
000070404d1d1d91  pop rdi
000070404d1d1d92  pop rdx
000070404d1d1d93  pop rcx
000070404d1d1d94  pop rax
000070404d1d1d95  add rsp, 0x08
000070404d1d1d99  jmp 0x000070404D1CFD00
000070404d1d1d9e  call 0x000070404D00D4E0
000070404d1d1da3  jmp 0x000070404D1CFD0A
000070404d1d1da8  call 0x000070404D00AFE0
000070404d1d1dad  jmp 0x000070404D1CFD14
000070404d1d1db2  sub rsp, 0x08
000070404d1d1db6  push rax
000070404d1d1db7  push rcx
000070404d1d1db8  push rdx
000070404d1d1db9  push rdi
000070404d1d1dba  push rsi
000070404d1d1dbb  push r8
000070404d1d1dbd  push r9
000070404d1d1dbf  push r10
000070404d1d1dc1  push r11
000070404d1d1dc3  sub rsp, 0xF0
000070404d1d1dca  vmovaps [rsp], xmm0
000070404d1d1dcf  vmovaps [rsp+0x10], xmm1
000070404d1d1dd5  vmovaps [rsp+0x20], xmm2
000070404d1d1ddb  vmovaps [rsp+0x30], xmm3
000070404d1d1de1  vmovaps [rsp+0x40], xmm4
000070404d1d1de7  vmovaps [rsp+0x50], xmm5
000070404d1d1ded  vmovaps [rsp+0x60], xmm6
000070404d1d1df3  vmovaps [rsp+0x70], xmm8
000070404d1d1df9  vmovaps [rsp+0x80], xmm9
000070404d1d1e02  vmovaps [rsp+0x90], xmm10
000070404d1d1e0b  vmovaps [rsp+0xA0], xmm11
000070404d1d1e14  vmovaps [rsp+0xB0], xmm12
000070404d1d1e1d  vmovaps [rsp+0xC0], xmm13
000070404d1d1e26  vmovaps [rsp+0xD0], xmm14
000070404d1d1e2f  vmovaps [rsp+0xE0], xmm15
000070404d1d1e38  sub rsp, 0x40
000070404d1d1e3c  lea rdi, [rsp]
000070404d1d1e40  lea rsi, [rsp+0x10]
000070404d1d1e45  lea rdx, [rsp+0x20]
000070404d1d1e4a  lea rcx, [rsp+0x30]
000070404d1d1e4f  mov r8d, 0x00
000070404d1d1e55  lea r9, [r15+0x3A8]
000070404d1d1e5c  movaps [rdi], xmm7
000070404d1d1e5f  movaps [rsi], xmm4
000070404d1d1e62  movaps [rdx], xmm9
000070404d1d1e66  movaps [rcx], xmm11
000070404d1d1e6a  mov rax, 0x607928F07A50
000070404d1d1e74  call rax
000070404d1d1e76  movaps xmm7, [rsp]
000070404d1d1e7a  add rsp, 0x40
000070404d1d1e7e  vmovaps xmm0, [rsp]
000070404d1d1e83  vmovaps xmm1, [rsp+0x10]
000070404d1d1e89  vmovaps xmm2, [rsp+0x20]
000070404d1d1e8f  vmovaps xmm3, [rsp+0x30]
000070404d1d1e95  vmovaps xmm4, [rsp+0x40]
000070404d1d1e9b  vmovaps xmm5, [rsp+0x50]
000070404d1d1ea1  vmovaps xmm6, [rsp+0x60]
000070404d1d1ea7  vmovaps xmm8, [rsp+0x70]
000070404d1d1ead  vmovaps xmm9, [rsp+0x80]
000070404d1d1eb6  vmovaps xmm10, [rsp+0x90]
000070404d1d1ebf  vmovaps xmm11, [rsp+0xA0]
000070404d1d1ec8  vmovaps xmm12, [rsp+0xB0]
000070404d1d1ed1  vmovaps xmm13, [rsp+0xC0]
000070404d1d1eda  vmovaps xmm14, [rsp+0xD0]
000070404d1d1ee3  vmovaps xmm15, [rsp+0xE0]
000070404d1d1eec  add rsp, 0xF0
000070404d1d1ef3  pop r11
000070404d1d1ef5  pop r10
000070404d1d1ef7  pop r9
000070404d1d1ef9  pop r8
000070404d1d1efb  pop rsi
000070404d1d1efc  pop rdi
000070404d1d1efd  pop rdx
000070404d1d1efe  pop rcx
000070404d1d1eff  pop rax
000070404d1d1f00  add rsp, 0x08
000070404d1d1f04  jmp 0x000070404D1CFD4B
000070404d1d1f09  sub rsp, 0x08
000070404d1d1f0d  push rax
000070404d1d1f0e  push rcx
000070404d1d1f0f  push rdx
000070404d1d1f10  push rdi
000070404d1d1f11  push rsi
000070404d1d1f12  push r8
000070404d1d1f14  push r9
000070404d1d1f16  push r10
000070404d1d1f18  push r11
000070404d1d1f1a  sub rsp, 0xF0
000070404d1d1f21  vmovaps [rsp], xmm0
000070404d1d1f26  vmovaps [rsp+0x10], xmm1
000070404d1d1f2c  vmovaps [rsp+0x20], xmm2
000070404d1d1f32  vmovaps [rsp+0x30], xmm3
000070404d1d1f38  vmovaps [rsp+0x40], xmm4
000070404d1d1f3e  vmovaps [rsp+0x50], xmm5
000070404d1d1f44  vmovaps [rsp+0x60], xmm6
000070404d1d1f4a  vmovaps [rsp+0x70], xmm7
000070404d1d1f50  vmovaps [rsp+0x80], xmm8
000070404d1d1f59  vmovaps [rsp+0x90], xmm10
000070404d1d1f62  vmovaps [rsp+0xA0], xmm11
000070404d1d1f6b  vmovaps [rsp+0xB0], xmm12
000070404d1d1f74  vmovaps [rsp+0xC0], xmm13
000070404d1d1f7d  vmovaps [rsp+0xD0], xmm14
000070404d1d1f86  vmovaps [rsp+0xE0], xmm15
000070404d1d1f8f  sub rsp, 0x40
000070404d1d1f93  lea rdi, [rsp]
000070404d1d1f97  lea rsi, [rsp+0x10]
000070404d1d1f9c  lea rdx, [rsp+0x20]
000070404d1d1fa1  lea rcx, [rsp+0x30]
000070404d1d1fa6  mov r8d, 0x00
000070404d1d1fac  lea r9, [r15+0x3A8]
000070404d1d1fb3  movaps [rdi], xmm9
000070404d1d1fb7  movaps [rsi], xmm5
000070404d1d1fba  movaps [rdx], xmm14
000070404d1d1fbe  movaps [rcx], xmm11
000070404d1d1fc2  mov rax, 0x607928F07A50
000070404d1d1fcc  call rax
000070404d1d1fce  movaps xmm9, [rsp]
000070404d1d1fd3  add rsp, 0x40
000070404d1d1fd7  vmovaps xmm0, [rsp]
000070404d1d1fdc  vmovaps xmm1, [rsp+0x10]
000070404d1d1fe2  vmovaps xmm2, [rsp+0x20]
000070404d1d1fe8  vmovaps xmm3, [rsp+0x30]
000070404d1d1fee  vmovaps xmm4, [rsp+0x40]
000070404d1d1ff4  vmovaps xmm5, [rsp+0x50]
000070404d1d1ffa  vmovaps xmm6, [rsp+0x60]
000070404d1d2000  vmovaps xmm7, [rsp+0x70]
000070404d1d2006  vmovaps xmm8, [rsp+0x80]
000070404d1d200f  vmovaps xmm10, [rsp+0x90]
000070404d1d2018  vmovaps xmm11, [rsp+0xA0]
000070404d1d2021  vmovaps xmm12, [rsp+0xB0]
000070404d1d202a  vmovaps xmm13, [rsp+0xC0]
000070404d1d2033  vmovaps xmm14, [rsp+0xD0]
000070404d1d203c  vmovaps xmm15, [rsp+0xE0]
000070404d1d2045  add rsp, 0xF0
000070404d1d204c  pop r11
000070404d1d204e  pop r10
000070404d1d2050  pop r9
000070404d1d2052  pop r8
000070404d1d2054  pop rsi
000070404d1d2055  pop rdi
000070404d1d2056  pop rdx
000070404d1d2057  pop rcx
000070404d1d2058  pop rax
000070404d1d2059  add rsp, 0x08
000070404d1d205d  jmp 0x000070404D1CFD74
000070404d1d2062  sub rsp, 0x08
000070404d1d2066  push rax
000070404d1d2067  push rcx
000070404d1d2068  push rdx
000070404d1d2069  push rdi
000070404d1d206a  push rsi
000070404d1d206b  push r8
000070404d1d206d  push r9
000070404d1d206f  push r10
000070404d1d2071  push r11
000070404d1d2073  sub rsp, 0xF0
000070404d1d207a  vmovaps [rsp], xmm0
000070404d1d207f  vmovaps [rsp+0x10], xmm1
000070404d1d2085  vmovaps [rsp+0x20], xmm2
000070404d1d208b  vmovaps [rsp+0x30], xmm3
000070404d1d2091  vmovaps [rsp+0x40], xmm4
000070404d1d2097  vmovaps [rsp+0x50], xmm5
000070404d1d209d  vmovaps [rsp+0x60], xmm6
000070404d1d20a3  vmovaps [rsp+0x70], xmm7
000070404d1d20a9  vmovaps [rsp+0x80], xmm8
000070404d1d20b2  vmovaps [rsp+0x90], xmm9
000070404d1d20bb  vmovaps [rsp+0xA0], xmm10
000070404d1d20c4  vmovaps [rsp+0xB0], xmm12
000070404d1d20cd  vmovaps [rsp+0xC0], xmm13
000070404d1d20d6  vmovaps [rsp+0xD0], xmm14
000070404d1d20df  vmovaps [rsp+0xE0], xmm15
000070404d1d20e8  sub rsp, 0x40
000070404d1d20ec  lea rdi, [rsp]
000070404d1d20f0  lea rsi, [rsp+0x10]
000070404d1d20f5  lea rdx, [rsp+0x20]
000070404d1d20fa  lea rcx, [rsp+0x30]
000070404d1d20ff  mov r8d, 0x00
000070404d1d2105  lea r9, [r15+0x3A8]
000070404d1d210c  movaps [rdi], xmm11
000070404d1d2110  movaps [rsi], xmm8
000070404d1d2114  movaps [rdx], xmm10
000070404d1d2118  movaps [rcx], xmm14
000070404d1d211c  mov rax, 0x607928F07A50
000070404d1d2126  call rax
000070404d1d2128  movaps xmm11, [rsp]
000070404d1d212d  add rsp, 0x40
000070404d1d2131  vmovaps xmm0, [rsp]
000070404d1d2136  vmovaps xmm1, [rsp+0x10]
000070404d1d213c  vmovaps xmm2, [rsp+0x20]
000070404d1d2142  vmovaps xmm3, [rsp+0x30]
000070404d1d2148  vmovaps xmm4, [rsp+0x40]
000070404d1d214e  vmovaps xmm5, [rsp+0x50]
000070404d1d2154  vmovaps xmm6, [rsp+0x60]
000070404d1d215a  vmovaps xmm7, [rsp+0x70]
000070404d1d2160  vmovaps xmm8, [rsp+0x80]
000070404d1d2169  vmovaps xmm9, [rsp+0x90]
000070404d1d2172  vmovaps xmm10, [rsp+0xA0]
000070404d1d217b  vmovaps xmm12, [rsp+0xB0]
000070404d1d2184  vmovaps xmm13, [rsp+0xC0]
000070404d1d218d  vmovaps xmm14, [rsp+0xD0]
000070404d1d2196  vmovaps xmm15, [rsp+0xE0]
000070404d1d219f  add rsp, 0xF0
000070404d1d21a6  pop r11
000070404d1d21a8  pop r10
000070404d1d21aa  pop r9
000070404d1d21ac  pop r8
000070404d1d21ae  pop rsi
000070404d1d21af  pop rdi
000070404d1d21b0  pop rdx
000070404d1d21b1  pop rcx
000070404d1d21b2  pop rax
000070404d1d21b3  add rsp, 0x08
000070404d1d21b7  jmp 0x000070404D1CFD9D
000070404d1d21bc  sub rsp, 0x08
000070404d1d21c0  push rax
000070404d1d21c1  push rcx
000070404d1d21c2  push rdx
000070404d1d21c3  push rdi
000070404d1d21c4  push rsi
000070404d1d21c5  push r8
000070404d1d21c7  push r9
000070404d1d21c9  push r10
000070404d1d21cb  push r11
000070404d1d21cd  sub rsp, 0xF0
000070404d1d21d4  vmovaps [rsp], xmm0
000070404d1d21d9  vmovaps [rsp+0x10], xmm1
000070404d1d21df  vmovaps [rsp+0x20], xmm2
000070404d1d21e5  vmovaps [rsp+0x30], xmm3
000070404d1d21eb  vmovaps [rsp+0x40], xmm4
000070404d1d21f1  vmovaps [rsp+0x50], xmm5
000070404d1d21f7  vmovaps [rsp+0x60], xmm6
000070404d1d21fd  vmovaps [rsp+0x70], xmm7
000070404d1d2203  vmovaps [rsp+0x80], xmm8
000070404d1d220c  vmovaps [rsp+0x90], xmm9
000070404d1d2215  vmovaps [rsp+0xA0], xmm11
000070404d1d221e  vmovaps [rsp+0xB0], xmm12
000070404d1d2227  vmovaps [rsp+0xC0], xmm13
000070404d1d2230  vmovaps [rsp+0xD0], xmm14
000070404d1d2239  vmovaps [rsp+0xE0], xmm15
000070404d1d2242  sub rsp, 0x40
000070404d1d2246  lea rdi, [rsp]
000070404d1d224a  lea rsi, [rsp+0x10]
000070404d1d224f  lea rdx, [rsp+0x20]
000070404d1d2254  lea rcx, [rsp+0x30]
000070404d1d2259  mov r8d, 0x00
000070404d1d225f  lea r9, [r15+0x3A8]
000070404d1d2266  movaps [rdi], xmm10
000070404d1d226a  movaps [rsi], xmm13
000070404d1d226e  movaps [rdx], xmm15
000070404d1d2272  movaps [rcx], xmm14
000070404d1d2276  mov rax, 0x607928F07A50
000070404d1d2280  call rax
000070404d1d2282  movaps xmm10, [rsp]
000070404d1d2287  add rsp, 0x40
000070404d1d228b  vmovaps xmm0, [rsp]
000070404d1d2290  vmovaps xmm1, [rsp+0x10]
000070404d1d2296  vmovaps xmm2, [rsp+0x20]
000070404d1d229c  vmovaps xmm3, [rsp+0x30]
000070404d1d22a2  vmovaps xmm4, [rsp+0x40]
000070404d1d22a8  vmovaps xmm5, [rsp+0x50]
000070404d1d22ae  vmovaps xmm6, [rsp+0x60]
000070404d1d22b4  vmovaps xmm7, [rsp+0x70]
000070404d1d22ba  vmovaps xmm8, [rsp+0x80]
000070404d1d22c3  vmovaps xmm9, [rsp+0x90]
000070404d1d22cc  vmovaps xmm11, [rsp+0xA0]
000070404d1d22d5  vmovaps xmm12, [rsp+0xB0]
000070404d1d22de  vmovaps xmm13, [rsp+0xC0]
000070404d1d22e7  vmovaps xmm14, [rsp+0xD0]
000070404d1d22f0  vmovaps xmm15, [rsp+0xE0]
000070404d1d22f9  add rsp, 0xF0
000070404d1d2300  pop r11
000070404d1d2302  pop r10
000070404d1d2304  pop r9
000070404d1d2306  pop r8
000070404d1d2308  pop rsi
000070404d1d2309  pop rdi
000070404d1d230a  pop rdx
000070404d1d230b  pop rcx
000070404d1d230c  pop rax
000070404d1d230d  add rsp, 0x08
000070404d1d2311  jmp 0x000070404D1CFDC6
000070404d1d2316  call 0x000070404D00E760
000070404d1d231b  jmp 0x000070404D1CFDD0
000070404d1d2320  call 0x000070404D00D4E0
000070404d1d2325  jmp 0x000070404D1CFDDA
000070404d1d232a  sub rsp, 0x08
000070404d1d232e  push rax
000070404d1d232f  push rcx
000070404d1d2330  push rdx
000070404d1d2331  push rdi
000070404d1d2332  push rsi
000070404d1d2333  push r8
000070404d1d2335  push r9
000070404d1d2337  push r10
000070404d1d2339  push r11
000070404d1d233b  sub rsp, 0xF0
000070404d1d2342  vmovaps [rsp], xmm0
000070404d1d2347  vmovaps [rsp+0x10], xmm1
000070404d1d234d  vmovaps [rsp+0x20], xmm2
000070404d1d2353  vmovaps [rsp+0x30], xmm3
000070404d1d2359  vmovaps [rsp+0x40], xmm4
000070404d1d235f  vmovaps [rsp+0x50], xmm5
000070404d1d2365  vmovaps [rsp+0x60], xmm7
000070404d1d236b  vmovaps [rsp+0x70], xmm8
000070404d1d2371  vmovaps [rsp+0x80], xmm9
000070404d1d237a  vmovaps [rsp+0x90], xmm10
000070404d1d2383  vmovaps [rsp+0xA0], xmm11
000070404d1d238c  vmovaps [rsp+0xB0], xmm12
000070404d1d2395  vmovaps [rsp+0xC0], xmm13
000070404d1d239e  vmovaps [rsp+0xD0], xmm14
000070404d1d23a7  vmovaps [rsp+0xE0], xmm15
000070404d1d23b0  sub rsp, 0x40
000070404d1d23b4  lea rdi, [rsp]
000070404d1d23b8  lea rsi, [rsp+0x10]
000070404d1d23bd  lea rdx, [rsp+0x20]
000070404d1d23c2  lea rcx, [rsp+0x30]
000070404d1d23c7  mov r8d, 0x00
000070404d1d23cd  lea r9, [r15+0x3A8]
000070404d1d23d4  movaps [rdi], xmm6
000070404d1d23d7  movaps [rsi], xmm7
000070404d1d23da  movaps [rdx], xmm8
000070404d1d23de  movaps [rcx], xmm13
000070404d1d23e2  mov rax, 0x607928F07A50
000070404d1d23ec  call rax
000070404d1d23ee  movaps xmm6, [rsp]
000070404d1d23f2  add rsp, 0x40
000070404d1d23f6  vmovaps xmm0, [rsp]
000070404d1d23fb  vmovaps xmm1, [rsp+0x10]
000070404d1d2401  vmovaps xmm2, [rsp+0x20]
000070404d1d2407  vmovaps xmm3, [rsp+0x30]
000070404d1d240d  vmovaps xmm4, [rsp+0x40]
000070404d1d2413  vmovaps xmm5, [rsp+0x50]
000070404d1d2419  vmovaps xmm7, [rsp+0x60]
000070404d1d241f  vmovaps xmm8, [rsp+0x70]
000070404d1d2425  vmovaps xmm9, [rsp+0x80]
000070404d1d242e  vmovaps xmm10, [rsp+0x90]
000070404d1d2437  vmovaps xmm11, [rsp+0xA0]
000070404d1d2440  vmovaps xmm12, [rsp+0xB0]
000070404d1d2449  vmovaps xmm13, [rsp+0xC0]
000070404d1d2452  vmovaps xmm14, [rsp+0xD0]
000070404d1d245b  vmovaps xmm15, [rsp+0xE0]
000070404d1d2464  add rsp, 0xF0
000070404d1d246b  pop r11
000070404d1d246d  pop r10
000070404d1d246f  pop r9
000070404d1d2471  pop r8
000070404d1d2473  pop rsi
000070404d1d2474  pop rdi
000070404d1d2475  pop rdx
000070404d1d2476  pop rcx
000070404d1d2477  pop rax
000070404d1d2478  add rsp, 0x08
000070404d1d247c  jmp 0x000070404D1CFE04
000070404d1d2481  sub rsp, 0x08
000070404d1d2485  push rax
000070404d1d2486  push rcx
000070404d1d2487  push rdx
000070404d1d2488  push rdi
000070404d1d2489  push rsi
000070404d1d248a  push r8
000070404d1d248c  push r9
000070404d1d248e  push r10
000070404d1d2490  push r11
000070404d1d2492  sub rsp, 0xF0
000070404d1d2499  vmovaps [rsp], xmm0
000070404d1d249e  vmovaps [rsp+0x10], xmm1
000070404d1d24a4  vmovaps [rsp+0x20], xmm2
000070404d1d24aa  vmovaps [rsp+0x30], xmm3
000070404d1d24b0  vmovaps [rsp+0x40], xmm4
000070404d1d24b6  vmovaps [rsp+0x50], xmm5
000070404d1d24bc  vmovaps [rsp+0x60], xmm6
000070404d1d24c2  vmovaps [rsp+0x70], xmm7
000070404d1d24c8  vmovaps [rsp+0x80], xmm9
000070404d1d24d1  vmovaps [rsp+0x90], xmm10
000070404d1d24da  vmovaps [rsp+0xA0], xmm11
000070404d1d24e3  vmovaps [rsp+0xB0], xmm12
000070404d1d24ec  vmovaps [rsp+0xC0], xmm13
000070404d1d24f5  vmovaps [rsp+0xD0], xmm14
000070404d1d24fe  vmovaps [rsp+0xE0], xmm15
000070404d1d2507  sub rsp, 0x40
000070404d1d250b  lea rdi, [rsp]
000070404d1d250f  lea rsi, [rsp+0x10]
000070404d1d2514  lea rdx, [rsp+0x20]
000070404d1d2519  lea rcx, [rsp+0x30]
000070404d1d251e  mov r8d, 0x00
000070404d1d2524  lea r9, [r15+0x3A8]
000070404d1d252b  movaps [rdi], xmm8
000070404d1d252f  movaps [rsi], xmm9
000070404d1d2533  movaps [rdx], xmm1
000070404d1d2536  movaps [rcx], xmm13
000070404d1d253a  mov rax, 0x607928F07A50
000070404d1d2544  call rax
000070404d1d2546  movaps xmm8, [rsp]
000070404d1d254b  add rsp, 0x40
000070404d1d254f  vmovaps xmm0, [rsp]
000070404d1d2554  vmovaps xmm1, [rsp+0x10]
000070404d1d255a  vmovaps xmm2, [rsp+0x20]
000070404d1d2560  vmovaps xmm3, [rsp+0x30]
000070404d1d2566  vmovaps xmm4, [rsp+0x40]
000070404d1d256c  vmovaps xmm5, [rsp+0x50]
000070404d1d2572  vmovaps xmm6, [rsp+0x60]
000070404d1d2578  vmovaps xmm7, [rsp+0x70]
000070404d1d257e  vmovaps xmm9, [rsp+0x80]
000070404d1d2587  vmovaps xmm10, [rsp+0x90]
000070404d1d2590  vmovaps xmm11, [rsp+0xA0]
000070404d1d2599  vmovaps xmm12, [rsp+0xB0]
000070404d1d25a2  vmovaps xmm13, [rsp+0xC0]
000070404d1d25ab  vmovaps xmm14, [rsp+0xD0]
000070404d1d25b4  vmovaps xmm15, [rsp+0xE0]
000070404d1d25bd  add rsp, 0xF0
000070404d1d25c4  pop r11
000070404d1d25c6  pop r10
000070404d1d25c8  pop r9
000070404d1d25ca  pop r8
000070404d1d25cc  pop rsi
000070404d1d25cd  pop rdi
000070404d1d25ce  pop rdx
000070404d1d25cf  pop rcx
000070404d1d25d0  pop rax
000070404d1d25d1  add rsp, 0x08
000070404d1d25d5  jmp 0x000070404D1CFE2A
000070404d1d25da  sub rsp, 0x08
000070404d1d25de  push rax
000070404d1d25df  push rcx
000070404d1d25e0  push rdx
000070404d1d25e1  push rdi
000070404d1d25e2  push rsi
000070404d1d25e3  push r8
000070404d1d25e5  push r9
000070404d1d25e7  push r10
000070404d1d25e9  push r11
000070404d1d25eb  sub rsp, 0xF0
000070404d1d25f2  vmovaps [rsp], xmm0
000070404d1d25f7  vmovaps [rsp+0x10], xmm1
000070404d1d25fd  vmovaps [rsp+0x20], xmm2
000070404d1d2603  vmovaps [rsp+0x30], xmm3
000070404d1d2609  vmovaps [rsp+0x40], xmm4
000070404d1d260f  vmovaps [rsp+0x50], xmm5
000070404d1d2615  vmovaps [rsp+0x60], xmm6
000070404d1d261b  vmovaps [rsp+0x70], xmm7
000070404d1d2621  vmovaps [rsp+0x80], xmm8
000070404d1d262a  vmovaps [rsp+0x90], xmm9
000070404d1d2633  vmovaps [rsp+0xA0], xmm10
000070404d1d263c  vmovaps [rsp+0xB0], xmm11
000070404d1d2645  vmovaps [rsp+0xC0], xmm12
000070404d1d264e  vmovaps [rsp+0xD0], xmm14
000070404d1d2657  vmovaps [rsp+0xE0], xmm15
000070404d1d2660  sub rsp, 0x40
000070404d1d2664  lea rdi, [rsp]
000070404d1d2668  lea rsi, [rsp+0x10]
000070404d1d266d  lea rdx, [rsp+0x20]
000070404d1d2672  lea rcx, [rsp+0x30]
000070404d1d2677  mov r8d, 0x00
000070404d1d267d  lea r9, [r15+0x3A8]
000070404d1d2684  movaps [rdi], xmm13
000070404d1d2688  movaps [rsi], xmm11
000070404d1d268c  movaps [rdx], xmm12
000070404d1d2690  movaps [rcx], xmm1
000070404d1d2693  mov rax, 0x607928F07A50
000070404d1d269d  call rax
000070404d1d269f  movaps xmm13, [rsp]
000070404d1d26a4  add rsp, 0x40
000070404d1d26a8  vmovaps xmm0, [rsp]
000070404d1d26ad  vmovaps xmm1, [rsp+0x10]
000070404d1d26b3  vmovaps xmm2, [rsp+0x20]
000070404d1d26b9  vmovaps xmm3, [rsp+0x30]
000070404d1d26bf  vmovaps xmm4, [rsp+0x40]
000070404d1d26c5  vmovaps xmm5, [rsp+0x50]
000070404d1d26cb  vmovaps xmm6, [rsp+0x60]
000070404d1d26d1  vmovaps xmm7, [rsp+0x70]
000070404d1d26d7  vmovaps xmm8, [rsp+0x80]
000070404d1d26e0  vmovaps xmm9, [rsp+0x90]
000070404d1d26e9  vmovaps xmm10, [rsp+0xA0]
000070404d1d26f2  vmovaps xmm11, [rsp+0xB0]
000070404d1d26fb  vmovaps xmm12, [rsp+0xC0]
000070404d1d2704  vmovaps xmm14, [rsp+0xD0]
000070404d1d270d  vmovaps xmm15, [rsp+0xE0]
000070404d1d2716  add rsp, 0xF0
000070404d1d271d  pop r11
000070404d1d271f  pop r10
000070404d1d2721  pop r9
000070404d1d2723  pop r8
000070404d1d2725  pop rsi
000070404d1d2726  pop rdi
000070404d1d2727  pop rdx
000070404d1d2728  pop rcx
000070404d1d2729  pop rax
000070404d1d272a  add rsp, 0x08
000070404d1d272e  jmp 0x000070404D1CFE50
000070404d1d2733  sub rsp, 0x08
000070404d1d2737  push rax
000070404d1d2738  push rcx
000070404d1d2739  push rdx
000070404d1d273a  push rdi
000070404d1d273b  push rsi
000070404d1d273c  push r8
000070404d1d273e  push r9
000070404d1d2740  push r10
000070404d1d2742  push r11
000070404d1d2744  sub rsp, 0xF0
000070404d1d274b  vmovaps [rsp], xmm0
000070404d1d2750  vmovaps [rsp+0x10], xmm1
000070404d1d2756  vmovaps [rsp+0x20], xmm2
000070404d1d275c  vmovaps [rsp+0x30], xmm3
000070404d1d2762  vmovaps [rsp+0x40], xmm4
000070404d1d2768  vmovaps [rsp+0x50], xmm5
000070404d1d276e  vmovaps [rsp+0x60], xmm6
000070404d1d2774  vmovaps [rsp+0x70], xmm7
000070404d1d277a  vmovaps [rsp+0x80], xmm8
000070404d1d2783  vmovaps [rsp+0x90], xmm9
000070404d1d278c  vmovaps [rsp+0xA0], xmm10
000070404d1d2795  vmovaps [rsp+0xB0], xmm11
000070404d1d279e  vmovaps [rsp+0xC0], xmm13
000070404d1d27a7  vmovaps [rsp+0xD0], xmm14
000070404d1d27b0  vmovaps [rsp+0xE0], xmm15
000070404d1d27b9  sub rsp, 0x40
000070404d1d27bd  lea rdi, [rsp]
000070404d1d27c1  lea rsi, [rsp+0x10]
000070404d1d27c6  lea rdx, [rsp+0x20]
000070404d1d27cb  lea rcx, [rsp+0x30]
000070404d1d27d0  mov r8d, 0x00
000070404d1d27d6  lea r9, [r15+0x3A8]
000070404d1d27dd  movaps [rdi], xmm12
000070404d1d27e1  movaps [rsi], xmm10
000070404d1d27e5  movaps [rdx], xmm14
000070404d1d27e9  movaps [rcx], xmm1
000070404d1d27ec  mov rax, 0x607928F07A50
000070404d1d27f6  call rax
000070404d1d27f8  movaps xmm12, [rsp]
000070404d1d27fd  add rsp, 0x40
000070404d1d2801  vmovaps xmm0, [rsp]
000070404d1d2806  vmovaps xmm1, [rsp+0x10]
000070404d1d280c  vmovaps xmm2, [rsp+0x20]
000070404d1d2812  vmovaps xmm3, [rsp+0x30]
000070404d1d2818  vmovaps xmm4, [rsp+0x40]
000070404d1d281e  vmovaps xmm5, [rsp+0x50]
000070404d1d2824  vmovaps xmm6, [rsp+0x60]
000070404d1d282a  vmovaps xmm7, [rsp+0x70]
000070404d1d2830  vmovaps xmm8, [rsp+0x80]
000070404d1d2839  vmovaps xmm9, [rsp+0x90]
000070404d1d2842  vmovaps xmm10, [rsp+0xA0]
000070404d1d284b  vmovaps xmm11, [rsp+0xB0]
000070404d1d2854  vmovaps xmm13, [rsp+0xC0]
000070404d1d285d  vmovaps xmm14, [rsp+0xD0]
000070404d1d2866  vmovaps xmm15, [rsp+0xE0]
000070404d1d286f  add rsp, 0xF0
000070404d1d2876  pop r11
000070404d1d2878  pop r10
000070404d1d287a  pop r9
000070404d1d287c  pop r8
000070404d1d287e  pop rsi
000070404d1d287f  pop rdi
000070404d1d2880  pop rdx
000070404d1d2881  pop rcx
000070404d1d2882  pop rax
000070404d1d2883  add rsp, 0x08
000070404d1d2887  jmp 0x000070404D1CFE76
000070404d1d288c  call 0x000070404CFFF430
000070404d1d2891  jmp 0x000070404D1CFE83
000070404d1d2896  call 0x000070404D00D4E0
000070404d1d289b  jmp 0x000070404D1CFE90
000070404d1d28a0  sub rsp, 0x08
000070404d1d28a4  push rax
000070404d1d28a5  push rcx
000070404d1d28a6  push rdx
000070404d1d28a7  push rdi
000070404d1d28a8  push rsi
000070404d1d28a9  push r8
000070404d1d28ab  push r9
000070404d1d28ad  push r10
000070404d1d28af  push r11
000070404d1d28b1  sub rsp, 0xF0
000070404d1d28b8  vmovaps [rsp], xmm0
000070404d1d28bd  vmovaps [rsp+0x10], xmm1
000070404d1d28c3  vmovaps [rsp+0x20], xmm2
000070404d1d28c9  vmovaps [rsp+0x30], xmm3
000070404d1d28cf  vmovaps [rsp+0x40], xmm4
000070404d1d28d5  vmovaps [rsp+0x50], xmm5
000070404d1d28db  vmovaps [rsp+0x60], xmm6
000070404d1d28e1  vmovaps [rsp+0x70], xmm7
000070404d1d28e7  vmovaps [rsp+0x80], xmm8
000070404d1d28f0  vmovaps [rsp+0x90], xmm9
000070404d1d28f9  vmovaps [rsp+0xA0], xmm11
000070404d1d2902  vmovaps [rsp+0xB0], xmm12
000070404d1d290b  vmovaps [rsp+0xC0], xmm13
000070404d1d2914  vmovaps [rsp+0xD0], xmm14
000070404d1d291d  vmovaps [rsp+0xE0], xmm15
000070404d1d2926  sub rsp, 0x40
000070404d1d292a  lea rdi, [rsp]
000070404d1d292e  lea rsi, [rsp+0x10]
000070404d1d2933  lea rdx, [rsp+0x20]
000070404d1d2938  lea rcx, [rsp+0x30]
000070404d1d293d  mov r8d, 0x00
000070404d1d2943  lea r9, [r15+0x3A8]
000070404d1d294a  movaps [rdi], xmm10
000070404d1d294e  movaps [rsi], xmm6
000070404d1d2951  movaps [rdx], xmm15
000070404d1d2955  movaps [rcx], xmm11
000070404d1d2959  mov rax, 0x607928F07A50
000070404d1d2963  call rax
000070404d1d2965  movaps xmm10, [rsp]
000070404d1d296a  add rsp, 0x40
000070404d1d296e  vmovaps xmm0, [rsp]
000070404d1d2973  vmovaps xmm1, [rsp+0x10]
000070404d1d2979  vmovaps xmm2, [rsp+0x20]
000070404d1d297f  vmovaps xmm3, [rsp+0x30]
000070404d1d2985  vmovaps xmm4, [rsp+0x40]
000070404d1d298b  vmovaps xmm5, [rsp+0x50]
000070404d1d2991  vmovaps xmm6, [rsp+0x60]
000070404d1d2997  vmovaps xmm7, [rsp+0x70]
000070404d1d299d  vmovaps xmm8, [rsp+0x80]
000070404d1d29a6  vmovaps xmm9, [rsp+0x90]
000070404d1d29af  vmovaps xmm11, [rsp+0xA0]
000070404d1d29b8  vmovaps xmm12, [rsp+0xB0]
000070404d1d29c1  vmovaps xmm13, [rsp+0xC0]
000070404d1d29ca  vmovaps xmm14, [rsp+0xD0]
000070404d1d29d3  vmovaps xmm15, [rsp+0xE0]
000070404d1d29dc  add rsp, 0xF0
000070404d1d29e3  pop r11
000070404d1d29e5  pop r10
000070404d1d29e7  pop r9
000070404d1d29e9  pop r8
000070404d1d29eb  pop rsi
000070404d1d29ec  pop rdi
000070404d1d29ed  pop rdx
000070404d1d29ee  pop rcx
000070404d1d29ef  pop rax
000070404d1d29f0  add rsp, 0x08
000070404d1d29f4  jmp 0x000070404D1CFEC9
000070404d1d29f9  call 0x000070404D00E760
000070404d1d29fe  jmp 0x000070404D1CFEDB
000070404d1d2a03  sub rsp, 0x08
000070404d1d2a07  push rax
000070404d1d2a08  push rcx
000070404d1d2a09  push rdx
000070404d1d2a0a  push rdi
000070404d1d2a0b  push rsi
000070404d1d2a0c  push r8
000070404d1d2a0e  push r9
000070404d1d2a10  push r10
000070404d1d2a12  push r11
000070404d1d2a14  sub rsp, 0xF0
000070404d1d2a1b  vmovaps [rsp], xmm0
000070404d1d2a20  vmovaps [rsp+0x10], xmm1
000070404d1d2a26  vmovaps [rsp+0x20], xmm2
000070404d1d2a2c  vmovaps [rsp+0x30], xmm3
000070404d1d2a32  vmovaps [rsp+0x40], xmm4
000070404d1d2a38  vmovaps [rsp+0x50], xmm5
000070404d1d2a3e  vmovaps [rsp+0x60], xmm6
000070404d1d2a44  vmovaps [rsp+0x70], xmm7
000070404d1d2a4a  vmovaps [rsp+0x80], xmm8
000070404d1d2a53  vmovaps [rsp+0x90], xmm10
000070404d1d2a5c  vmovaps [rsp+0xA0], xmm11
000070404d1d2a65  vmovaps [rsp+0xB0], xmm12
000070404d1d2a6e  vmovaps [rsp+0xC0], xmm13
000070404d1d2a77  vmovaps [rsp+0xD0], xmm14
000070404d1d2a80  vmovaps [rsp+0xE0], xmm15
000070404d1d2a89  sub rsp, 0x40
000070404d1d2a8d  lea rdi, [rsp]
000070404d1d2a91  lea rsi, [rsp+0x10]
000070404d1d2a96  lea rdx, [rsp+0x20]
000070404d1d2a9b  lea rcx, [rsp+0x30]
000070404d1d2aa0  mov r8d, 0x00
000070404d1d2aa6  lea r9, [r15+0x3A8]
000070404d1d2aad  movaps [rdi], xmm9
000070404d1d2ab1  movaps [rsi], xmm8
000070404d1d2ab5  movaps [rdx], xmm14
000070404d1d2ab9  movaps [rcx], xmm11
000070404d1d2abd  mov rax, 0x607928F07A50
000070404d1d2ac7  call rax
000070404d1d2ac9  movaps xmm9, [rsp]
000070404d1d2ace  add rsp, 0x40
000070404d1d2ad2  vmovaps xmm0, [rsp]
000070404d1d2ad7  vmovaps xmm1, [rsp+0x10]
000070404d1d2add  vmovaps xmm2, [rsp+0x20]
000070404d1d2ae3  vmovaps xmm3, [rsp+0x30]
000070404d1d2ae9  vmovaps xmm4, [rsp+0x40]
000070404d1d2aef  vmovaps xmm5, [rsp+0x50]
000070404d1d2af5  vmovaps xmm6, [rsp+0x60]
000070404d1d2afb  vmovaps xmm7, [rsp+0x70]
000070404d1d2b01  vmovaps xmm8, [rsp+0x80]
000070404d1d2b0a  vmovaps xmm10, [rsp+0x90]
000070404d1d2b13  vmovaps xmm11, [rsp+0xA0]
000070404d1d2b1c  vmovaps xmm12, [rsp+0xB0]
000070404d1d2b25  vmovaps xmm13, [rsp+0xC0]
000070404d1d2b2e  vmovaps xmm14, [rsp+0xD0]
000070404d1d2b37  vmovaps xmm15, [rsp+0xE0]
000070404d1d2b40  add rsp, 0xF0
000070404d1d2b47  pop r11
000070404d1d2b49  pop r10
000070404d1d2b4b  pop r9
000070404d1d2b4d  pop r8
000070404d1d2b4f  pop rsi
000070404d1d2b50  pop rdi
000070404d1d2b51  pop rdx
000070404d1d2b52  pop rcx
000070404d1d2b53  pop rax
000070404d1d2b54  add rsp, 0x08
000070404d1d2b58  jmp 0x000070404D1CFF0C
000070404d1d2b5d  sub rsp, 0x08
000070404d1d2b61  push rax
000070404d1d2b62  push rcx
000070404d1d2b63  push rdx
000070404d1d2b64  push rdi
000070404d1d2b65  push rsi
000070404d1d2b66  push r8
000070404d1d2b68  push r9
000070404d1d2b6a  push r10
000070404d1d2b6c  push r11
000070404d1d2b6e  sub rsp, 0xF0
000070404d1d2b75  vmovaps [rsp], xmm0
000070404d1d2b7a  vmovaps [rsp+0x10], xmm1
000070404d1d2b80  vmovaps [rsp+0x20], xmm2
000070404d1d2b86  vmovaps [rsp+0x30], xmm3
000070404d1d2b8c  vmovaps [rsp+0x40], xmm4
000070404d1d2b92  vmovaps [rsp+0x50], xmm5
000070404d1d2b98  vmovaps [rsp+0x60], xmm6
000070404d1d2b9e  vmovaps [rsp+0x70], xmm7
000070404d1d2ba4  vmovaps [rsp+0x80], xmm8
000070404d1d2bad  vmovaps [rsp+0x90], xmm9
000070404d1d2bb6  vmovaps [rsp+0xA0], xmm10
000070404d1d2bbf  vmovaps [rsp+0xB0], xmm12
000070404d1d2bc8  vmovaps [rsp+0xC0], xmm13
000070404d1d2bd1  vmovaps [rsp+0xD0], xmm14
000070404d1d2bda  vmovaps [rsp+0xE0], xmm15
000070404d1d2be3  sub rsp, 0x40
000070404d1d2be7  lea rdi, [rsp]
000070404d1d2beb  lea rsi, [rsp+0x10]
000070404d1d2bf0  lea rdx, [rsp+0x20]
000070404d1d2bf5  lea rcx, [rsp+0x30]
000070404d1d2bfa  mov r8d, 0x00
000070404d1d2c00  lea r9, [r15+0x3A8]
000070404d1d2c07  movaps [rdi], xmm11
000070404d1d2c0b  movaps [rsi], xmm13
000070404d1d2c0f  movaps [rdx], xmm1
000070404d1d2c12  movaps [rcx], xmm14
000070404d1d2c16  mov rax, 0x607928F07A50
000070404d1d2c20  call rax
000070404d1d2c22  movaps xmm11, [rsp]
000070404d1d2c27  add rsp, 0x40
000070404d1d2c2b  vmovaps xmm0, [rsp]
000070404d1d2c30  vmovaps xmm1, [rsp+0x10]
000070404d1d2c36  vmovaps xmm2, [rsp+0x20]
000070404d1d2c3c  vmovaps xmm3, [rsp+0x30]
000070404d1d2c42  vmovaps xmm4, [rsp+0x40]
000070404d1d2c48  vmovaps xmm5, [rsp+0x50]
000070404d1d2c4e  vmovaps xmm6, [rsp+0x60]
000070404d1d2c54  vmovaps xmm7, [rsp+0x70]
000070404d1d2c5a  vmovaps xmm8, [rsp+0x80]
000070404d1d2c63  vmovaps xmm9, [rsp+0x90]
000070404d1d2c6c  vmovaps xmm10, [rsp+0xA0]
000070404d1d2c75  vmovaps xmm12, [rsp+0xB0]
000070404d1d2c7e  vmovaps xmm13, [rsp+0xC0]
000070404d1d2c87  vmovaps xmm14, [rsp+0xD0]
000070404d1d2c90  vmovaps xmm15, [rsp+0xE0]
000070404d1d2c99  add rsp, 0xF0
000070404d1d2ca0  pop r11
000070404d1d2ca2  pop r10
000070404d1d2ca4  pop r9
000070404d1d2ca6  pop r8
000070404d1d2ca8  pop rsi
000070404d1d2ca9  pop rdi
000070404d1d2caa  pop rdx
000070404d1d2cab  pop rcx
000070404d1d2cac  pop rax
000070404d1d2cad  add rsp, 0x08
000070404d1d2cb1  jmp 0x000070404D1CFF3D
000070404d1d2cb6  sub rsp, 0x08
000070404d1d2cba  push rax
000070404d1d2cbb  push rcx
000070404d1d2cbc  push rdx
000070404d1d2cbd  push rdi
000070404d1d2cbe  push rsi
000070404d1d2cbf  push r8
000070404d1d2cc1  push r9
000070404d1d2cc3  push r10
000070404d1d2cc5  push r11
000070404d1d2cc7  sub rsp, 0xF0
000070404d1d2cce  vmovaps [rsp], xmm0
000070404d1d2cd3  vmovaps [rsp+0x10], xmm1
000070404d1d2cd9  vmovaps [rsp+0x20], xmm2
000070404d1d2cdf  vmovaps [rsp+0x30], xmm3
000070404d1d2ce5  vmovaps [rsp+0x40], xmm4
000070404d1d2ceb  vmovaps [rsp+0x50], xmm5
000070404d1d2cf1  vmovaps [rsp+0x60], xmm6
000070404d1d2cf7  vmovaps [rsp+0x70], xmm7
000070404d1d2cfd  vmovaps [rsp+0x80], xmm8
000070404d1d2d06  vmovaps [rsp+0x90], xmm9
000070404d1d2d0f  vmovaps [rsp+0xA0], xmm10
000070404d1d2d18  vmovaps [rsp+0xB0], xmm11
000070404d1d2d21  vmovaps [rsp+0xC0], xmm12
000070404d1d2d2a  vmovaps [rsp+0xD0], xmm13
000070404d1d2d33  vmovaps [rsp+0xE0], xmm15
000070404d1d2d3c  sub rsp, 0x40
000070404d1d2d40  lea rdi, [rsp]
000070404d1d2d44  lea rsi, [rsp+0x10]
000070404d1d2d49  lea rdx, [rsp+0x20]
000070404d1d2d4e  lea rcx, [rsp+0x30]
000070404d1d2d53  mov r8d, 0x00
000070404d1d2d59  lea r9, [r15+0x3A8]
000070404d1d2d60  movaps [rdi], xmm14
000070404d1d2d64  movaps [rsi], xmm12
000070404d1d2d68  movaps [rdx], xmm15
000070404d1d2d6c  movaps [rcx], xmm1
000070404d1d2d6f  mov rax, 0x607928F07A50
000070404d1d2d79  call rax
000070404d1d2d7b  movaps xmm14, [rsp]
000070404d1d2d80  add rsp, 0x40
000070404d1d2d84  vmovaps xmm0, [rsp]
000070404d1d2d89  vmovaps xmm1, [rsp+0x10]
000070404d1d2d8f  vmovaps xmm2, [rsp+0x20]
000070404d1d2d95  vmovaps xmm3, [rsp+0x30]
000070404d1d2d9b  vmovaps xmm4, [rsp+0x40]
000070404d1d2da1  vmovaps xmm5, [rsp+0x50]
000070404d1d2da7  vmovaps xmm6, [rsp+0x60]
000070404d1d2dad  vmovaps xmm7, [rsp+0x70]
000070404d1d2db3  vmovaps xmm8, [rsp+0x80]
000070404d1d2dbc  vmovaps xmm9, [rsp+0x90]
000070404d1d2dc5  vmovaps xmm10, [rsp+0xA0]
000070404d1d2dce  vmovaps xmm11, [rsp+0xB0]
000070404d1d2dd7  vmovaps xmm12, [rsp+0xC0]
000070404d1d2de0  vmovaps xmm13, [rsp+0xD0]
000070404d1d2de9  vmovaps xmm15, [rsp+0xE0]
000070404d1d2df2  add rsp, 0xF0
000070404d1d2df9  pop r11
000070404d1d2dfb  pop r10
000070404d1d2dfd  pop r9
000070404d1d2dff  pop r8
000070404d1d2e01  pop rsi
000070404d1d2e02  pop rdi
000070404d1d2e03  pop rdx
000070404d1d2e04  pop rcx
000070404d1d2e05  pop rax
000070404d1d2e06  add rsp, 0x08
000070404d1d2e0a  jmp 0x000070404D1CFF6E
000070404d1d2e0f  call 0x000070404D0079B0
000070404d1d2e14  jmp 0x000070404D1CFF81
000070404d1d2e19  call 0x000070404D009E90
000070404d1d2e1e  jmp 0x000070404D1CFF8C
000070404d1d2e23  call 0x000070404D008C20
000070404d1d2e28  jmp 0x000070404D1CFF97
000070404d1d2e2d  call 0x000070404D00D600
000070404d1d2e32  jmp 0x000070404D1CFFA2
000070404d1d2e37  int3
000070404d1d2e38  nop [rax+rax*1], eax
000070404d1d2e40  mov rax, [r15+0x40]
000070404d1d2e44  mov r14, [r15+0x58]
000070404d1d2e48  lea r12, [rax+r14*1]
000070404d1d2e4c  vxorps xmm1, xmm1, xmm1
000070404d1d2e50  vpbroadcastq xmm1, xmm1
000070404d1d2e55  vxorps xmm15, xmm15, xmm15
000070404d1d2e5a  vpbroadcastq xmm15, xmm15
000070404d1d2e5f  lea rax, [r12+0x30]
000070404d1d2e64  mov r11, [r13+rax*1]
000070404d1d2e69  lea rax, [r12+0x38]
000070404d1d2e6e  mov r10, [r13+rax*1]
000070404d1d2e73  movq xmm14, r11
000070404d1d2e78  movq xmm13, r10
000070404d1d2e7d  movq xmm14, xmm14
000070404d1d2e82  movq xmm13, xmm13
000070404d1d2e87  vmovaps [rsp+0x10], xmm13
000070404d1d2e8d  movq xmm13, xmm13
000070404d1d2e92  movaps [r15+0x270], xmm13
000070404d1d2e9a  movaps xmm13, [r15+0x160]
000070404d1d2ea2  vmovaps [rsp+0x20], xmm13
000070404d1d2ea8  vmovaps xmm12, [rsp+0x20]
000070404d1d2eae  por xmm13, xmm12
000070404d1d2eb3  lea rax, [r12+0x20]
000070404d1d2eb8  mov r11, [r13+rax*1]
000070404d1d2ebd  lea rax, [r12+0x28]
000070404d1d2ec2  mov r10, [r13+rax*1]
000070404d1d2ec7  movq xmm12, r11
000070404d1d2ecc  movq xmm11, r10
000070404d1d2ed1  movq xmm12, xmm12
000070404d1d2ed6  movq xmm11, xmm11
000070404d1d2edb  movaps xmm10, [r15+0x2F0]
000070404d1d2ee3  vmovaps [rsp+0x20], xmm10
000070404d1d2ee9  vmovaps xmm9, [rsp+0x20]
000070404d1d2eef  por xmm10, xmm9
000070404d1d2ef4  movaps xmm9, [r15+0x2D0]
000070404d1d2efc  vmovaps [rsp+0x20], xmm9
000070404d1d2f02  vmovaps xmm8, [rsp+0x20]
000070404d1d2f08  por xmm9, xmm8
000070404d1d2f0d  movaps xmm8, [r15+0x300]
000070404d1d2f15  vmovaps [rsp+0x20], xmm8
000070404d1d2f1b  vmovaps xmm7, [rsp+0x20]
000070404d1d2f21  por xmm8, xmm7
000070404d1d2f26  movaps xmm7, [r15+0x2B0]
000070404d1d2f2e  vmovaps [rsp+0x20], xmm7
000070404d1d2f34  vmovaps xmm6, [rsp+0x20]
000070404d1d2f3a  por xmm7, xmm6
000070404d1d2f3e  movaps xmm6, [r15+0x180]
000070404d1d2f46  vmovaps [rsp+0x20], xmm6
000070404d1d2f4c  vmovaps xmm5, [rsp+0x20]
000070404d1d2f52  por xmm6, xmm5
000070404d1d2f56  lea rax, [r12+0x10]
000070404d1d2f5b  mov r11, [r13+rax*1]
000070404d1d2f60  lea rax, [r12+0x18]
000070404d1d2f65  mov r10, [r13+rax*1]
000070404d1d2f6a  movq xmm5, r11
000070404d1d2f6f  movq xmm4, r10
000070404d1d2f74  movq xmm5, xmm5
000070404d1d2f78  movq xmm4, xmm4
000070404d1d2f7c  movaps xmm3, [r15+0x200]
000070404d1d2f84  vmovaps [rsp+0x20], xmm3
000070404d1d2f8a  vmovaps xmm2, [rsp+0x20]
000070404d1d2f90  por xmm3, xmm2
000070404d1d2f94  movaps xmm2, [r15+0x1F0]
000070404d1d2f9c  vmovaps [rsp+0x20], xmm2
000070404d1d2fa2  vmovaps [rsp+0x30], xmm1
000070404d1d2fa8  vmovaps xmm1, [rsp+0x20]
000070404d1d2fae  por xmm2, xmm1
000070404d1d2fb2  movaps xmm1, [r15+0x2E0]
000070404d1d2fba  vmovaps [rsp+0x20], xmm1
000070404d1d2fc0  vmovaps [rsp+0x40], xmm15
000070404d1d2fc6  vmovaps xmm15, [rsp+0x20]
000070404d1d2fcc  por xmm1, xmm15
000070404d1d2fd1  movaps xmm15, [r15+0x2A0]
000070404d1d2fd9  vmovaps [rsp+0x20], xmm15
000070404d1d2fdf  vmovaps [rsp+0x50], xmm1
000070404d1d2fe5  vmovaps xmm1, [rsp+0x20]
000070404d1d2feb  por xmm15, xmm1
000070404d1d2ff0  movaps xmm1, [r15+0x280]
000070404d1d2ff8  vmovaps [rsp+0x20], xmm1
000070404d1d2ffe  vmovaps [rsp+0x60], xmm15
000070404d1d3004  vmovaps xmm15, [rsp+0x20]
000070404d1d300a  por xmm1, xmm15
000070404d1d300f  movaps xmm15, [r15+0x1C0]
000070404d1d3017  vmovaps [rsp+0x20], xmm15
000070404d1d301d  vmovaps [rsp+0x70], xmm1
000070404d1d3023  vmovaps xmm1, [rsp+0x20]
000070404d1d3029  por xmm15, xmm1
000070404d1d302e  movaps xmm1, [r15+0x210]
000070404d1d3036  vmovaps [rsp+0x20], xmm1
000070404d1d303c  vmovaps [rsp+0x80], xmm15
000070404d1d3045  vmovaps xmm15, [rsp+0x20]
000070404d1d304b  por xmm1, xmm15
000070404d1d3050  mov rax, [r13+r12*1]
000070404d1d3055  vmovq xmm15, rax
000070404d1d305a  vpbroadcastq xmm15, xmm15
000070404d1d305f  vmovaps [rsp+0x20], xmm1
000070404d1d3065  vxorps xmm1, xmm1, xmm1
000070404d1d3069  vpbroadcastq xmm1, xmm1
000070404d1d306e  mov rax, [r15+0xF8]
000070404d1d3075  vmovaps [rsp+0x90], xmm1
000070404d1d307e  movups xmm1, [r13+rax*1]
000070404d1d3084  vmovaps [rsp+0xA0], xmm1
000070404d1d308d  vxorps xmm1, xmm1, xmm1
000070404d1d3091  vpbroadcastq xmm1, xmm1
000070404d1d3096  lea r11, [r12+0x08]
000070404d1d309b  mov r12, [r13+r11*1]
000070404d1d30a0  vmovaps [rsp+0xB0], xmm1
000070404d1d30a9  movq xmm1, r12
000070404d1d30ae  movaps [r15+0x240], xmm1
000070404d1d30b6  mov r12, [r15+0x50]
000070404d1d30ba  lea r11, [r12+r14*1]
000070404d1d30be  mov [r15+0x60], r11
000070404d1d30c2  lea r12, [r14+0x40]
000070404d1d30c6  mov [r15+0x58], r12
000070404d1d30ca  vmovaps xmm1, [rsp+0x30]
000070404d1d30d0  vmovaps [rsp+0x30], xmm15
000070404d1d30d6  vmovaps xmm15, [rsp+0xA0]
000070404d1d30df  vmovaps [rsp+0xA0], xmm14
000070404d1d30e8  vmovaps xmm14, [rsp+0x30]
000070404d1d30ee  vmovaps [rsp+0x30], xmm13
000070404d1d30f4  vmovaps [rsp+0xC0], xmm12
000070404d1d30fd  movaps xmm13, xmm1
000070404d1d3101  vfmadd231pd xmm13, xmm15, xmm14
000070404d1d3106  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1d310c  vptest xmm12, xmm12
000070404d1d3111  jnz 0x000070404D1D3BEA
000070404d1d3117  movaps xmm1, [r15+0x250]
000070404d1d311f  vmovaps xmm15, [rsp+0x40]
000070404d1d3125  vmovaps [rsp+0x40], xmm13
000070404d1d312b  movaps xmm12, xmm15
000070404d1d312f  vfmadd231pd xmm12, xmm1, xmm14
000070404d1d3134  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1d313a  vptest xmm13, xmm13
000070404d1d313f  jnz 0x000070404D1D3D43
000070404d1d3145  movaps xmm15, [r15+0x1E0]
000070404d1d314d  vmovaps [rsp+0xD0], xmm15
000070404d1d3156  vmovaps xmm13, [rsp+0xD0]
000070404d1d315f  por xmm15, xmm13
000070404d1d3164  movaps xmm13, [r15+0x1D0]
000070404d1d316c  vmovaps [rsp+0xD0], xmm13
000070404d1d3175  vmovaps [rsp+0xE0], xmm1
000070404d1d317e  vmovaps xmm1, [rsp+0xD0]
000070404d1d3187  por xmm13, xmm1
000070404d1d318c  movaps xmm1, [r15+0x2C0]
000070404d1d3194  vmovaps [rsp+0xD0], xmm1
000070404d1d319d  vmovaps [rsp+0xF0], xmm15
000070404d1d31a6  vmovaps xmm15, [rsp+0xD0]
000070404d1d31af  por xmm1, xmm15
000070404d1d31b4  movaps xmm15, [r15+0x290]
000070404d1d31bc  vmovaps [rsp+0xD0], xmm15
000070404d1d31c5  vmovaps [rsp+0x100], xmm1
000070404d1d31ce  vmovaps xmm1, [rsp+0xD0]
000070404d1d31d7  por xmm15, xmm1
000070404d1d31dc  movaps xmm1, [r15+0x260]
000070404d1d31e4  vmovaps [rsp+0xD0], xmm1
000070404d1d31ed  vmovaps [rsp+0x110], xmm15
000070404d1d31f6  vmovaps xmm15, [rsp+0xD0]
000070404d1d31ff  por xmm1, xmm15
000070404d1d3204  vmovaps xmm15, [rsp+0xE0]
000070404d1d320d  vmovaps [rsp+0xD0], xmm1
000070404d1d3216  vmovaps xmm1, [rsp+0xE0]
000070404d1d321f  por xmm15, xmm1
000070404d1d3224  lea r14, [rax+0xC0]
000070404d1d322b  movups xmm1, [r13+r14*1]
000070404d1d3231  mov [rsp+0xE0], rax
000070404d1d3239  xor eax, eax
000070404d1d323b  mov r14d, 0x200
000070404d1d3241  cmp r12, r14
000070404d1d3244  cmc
000070404d1d3245  lahf
000070404d1d3246  seto al
000070404d1d3249  mov [r15+0x108], eax
000070404d1d3250  vmovaps [rsp+0x120], xmm1
000070404d1d3259  vmovaps xmm1, [rsp+0x90]
000070404d1d3262  vmovaps [rsp+0x90], xmm15
000070404d1d326b  vmovaps xmm15, [rsp+0x120]
000070404d1d3274  vmovaps [rsp+0x120], xmm13
000070404d1d327d  vmovaps [rsp+0x130], xmm12
000070404d1d3286  movaps xmm13, xmm1
000070404d1d328a  vfmadd231pd xmm13, xmm15, xmm14
000070404d1d328f  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1d3295  vptest xmm12, xmm12
000070404d1d329a  jnz 0x000070404D1D3EA6
000070404d1d32a0  mov rax, [rsp+0xE0]
000070404d1d32a8  lea r14, [rax+0xB0]
000070404d1d32af  movups xmm1, [r13+r14*1]
000070404d1d32b5  vmovaps xmm15, [rsp+0xB0]
000070404d1d32be  vmovaps [rsp+0xB0], xmm13
000070404d1d32c7  movaps xmm12, xmm15
000070404d1d32cb  vfmadd231pd xmm12, xmm1, xmm14
000070404d1d32d0  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1d32d6  vptest xmm13, xmm13
000070404d1d32db  jnz 0x000070404D1D4009
000070404d1d32e1  vmovaps xmm1, [rsp+0x20]
000070404d1d32e7  vmovaps xmm15, [rsp+0x20]
000070404d1d32ed  por xmm1, xmm15
000070404d1d32f2  movaps [r15+0x210], xmm1
000070404d1d32fa  vmovaps xmm15, [rsp+0x80]
000070404d1d3303  vmovaps xmm14, [rsp+0x80]
000070404d1d330c  por xmm15, xmm14
000070404d1d3311  movaps [r15+0x1C0], xmm15
000070404d1d3319  vmovaps xmm14, [rsp+0x70]
000070404d1d331f  vmovaps xmm13, [rsp+0x70]
000070404d1d3325  por xmm14, xmm13
000070404d1d332a  movaps [r15+0x280], xmm14
000070404d1d3332  vmovaps xmm13, [rsp+0x60]
000070404d1d3338  vmovaps [rsp+0x20], xmm1
000070404d1d333e  vmovaps xmm1, [rsp+0x60]
000070404d1d3344  por xmm13, xmm1
000070404d1d3349  movaps [r15+0x2A0], xmm13
000070404d1d3351  vmovaps xmm1, [rsp+0x50]
000070404d1d3357  vmovaps [rsp+0x60], xmm15
000070404d1d335d  vmovaps xmm15, [rsp+0x50]
000070404d1d3363  por xmm1, xmm15
000070404d1d3368  movaps [r15+0x2E0], xmm1
000070404d1d3370  vmovaps [rsp+0x50], xmm2
000070404d1d3376  vmovaps xmm15, [rsp+0x50]
000070404d1d337c  por xmm2, xmm15
000070404d1d3381  movaps [r15+0x1F0], xmm2
000070404d1d3389  vmovaps xmm15, [rsp+0x90]
000070404d1d3392  vmovaps [rsp+0x50], xmm1
000070404d1d3398  vmovaps xmm1, [rsp+0x90]
000070404d1d33a1  por xmm15, xmm1
000070404d1d33a6  movaps [r15+0x250], xmm15
000070404d1d33ae  vmovaps xmm1, [rsp+0xD0]
000070404d1d33b7  vmovaps xmm15, [rsp+0xD0]
000070404d1d33c0  por xmm1, xmm15
000070404d1d33c5  movaps [r15+0x260], xmm1
000070404d1d33cd  vmovaps xmm15, [rsp+0x110]
000070404d1d33d6  vmovaps [rsp+0x70], xmm1
000070404d1d33dc  vmovaps xmm1, [rsp+0x110]
000070404d1d33e5  por xmm15, xmm1
000070404d1d33ea  movaps [r15+0x290], xmm15
000070404d1d33f2  vmovaps xmm1, [rsp+0x100]
000070404d1d33fb  vmovaps [rsp+0x80], xmm15
000070404d1d3404  vmovaps xmm15, [rsp+0x100]
000070404d1d340d  por xmm1, xmm15
000070404d1d3412  movaps [r15+0x2C0], xmm1
000070404d1d341a  movq xmm15, qword ptr [r15+0x240]
000070404d1d3423  vmovaps [rsp+0x90], xmm15
000070404d1d342c  vpermilpd xmm15, xmm15, 0x00
000070404d1d3432  vmovaps [rsp+0xD0], xmm1
000070404d1d343b  vmovaps xmm1, [rsp+0x40]
000070404d1d3441  vmovaps [rsp+0x40], xmm15
000070404d1d3447  vmovaps xmm15, [rsp+0x20]
000070404d1d344d  vmovaps [rsp+0x20], xmm14
000070404d1d3453  vmovaps xmm14, [rsp+0x40]
000070404d1d3459  vmovaps [rsp+0x40], xmm13
000070404d1d345f  vmovaps [rsp+0xE0], xmm12
000070404d1d3468  movaps xmm13, xmm1
000070404d1d346c  vfmadd231pd xmm13, xmm15, xmm14
000070404d1d3471  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1d3477  vptest xmm12, xmm12
000070404d1d347c  jnz 0x000070404D1D4162
000070404d1d3482  vmovaps xmm1, [rsp+0x90]
000070404d1d348b  vpermilpd xmm1, xmm1, 0x00
000070404d1d3491  vmovaps xmm15, [rsp+0xB0]
000070404d1d349a  vmovaps xmm14, [rsp+0x50]
000070404d1d34a0  vmovaps [rsp+0x50], xmm13
000070404d1d34a6  movaps xmm12, xmm15
000070404d1d34aa  vfmadd231pd xmm12, xmm14, xmm1
000070404d1d34af  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1d34b5  vptest xmm13, xmm13
000070404d1d34ba  jnz 0x000070404D1D42BB
000070404d1d34c0  vmovaps xmm1, [rsp+0x90]
000070404d1d34c9  vpermilpd xmm1, xmm1, 0x00
000070404d1d34cf  vmovaps xmm15, [rsp+0x130]
000070404d1d34d8  vmovaps xmm14, [rsp+0x60]
000070404d1d34de  vmovaps [rsp+0x60], xmm12
000070404d1d34e4  movaps xmm13, xmm15
000070404d1d34e8  vfmadd231pd xmm13, xmm14, xmm1
000070404d1d34ed  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1d34f3  vptest xmm12, xmm12
000070404d1d34f8  jnz 0x000070404D1D4414
000070404d1d34fe  vmovaps xmm1, [rsp+0x120]
000070404d1d3507  vmovaps xmm15, [rsp+0x120]
000070404d1d3510  por xmm1, xmm15
000070404d1d3515  movaps [r15+0x1D0], xmm1
000070404d1d351d  vmovaps xmm15, [rsp+0x90]
000070404d1d3526  vpermilpd xmm15, xmm15, 0x00
000070404d1d352c  vmovaps xmm14, [rsp+0xE0]
000070404d1d3535  vmovaps [rsp+0x90], xmm1
000070404d1d353e  movaps xmm12, xmm14
000070404d1d3542  vfmadd231pd xmm12, xmm2, xmm15
000070404d1d3547  vcmppd xmm1, xmm12, xmm12, 0x03
000070404d1d354d  vptest xmm1, xmm1
000070404d1d3552  jnz 0x000070404D1D456D
000070404d1d3558  vmovaps [rsp+0xB0], xmm3
000070404d1d3561  vmovaps xmm1, [rsp+0xB0]
000070404d1d356a  por xmm3, xmm1
000070404d1d356e  movaps [r15+0x200], xmm3
000070404d1d3576  vmovaps xmm1, [rsp+0xF0]
000070404d1d357f  vmovaps xmm15, [rsp+0xF0]
000070404d1d3588  por xmm1, xmm15
000070404d1d358d  movaps [r15+0x1E0], xmm1
000070404d1d3595  vmovaps [rsp+0xB0], xmm7
000070404d1d359e  vmovaps xmm1, [rsp+0xB0]
000070404d1d35a7  por xmm7, xmm1
000070404d1d35ab  movaps [r15+0x2B0], xmm7
000070404d1d35b3  vmovaps [rsp+0xB0], xmm8
000070404d1d35bc  vmovaps xmm1, [rsp+0xB0]
000070404d1d35c5  por xmm8, xmm1
000070404d1d35ca  movaps [r15+0x300], xmm8
000070404d1d35d2  vmovaps [rsp+0xB0], xmm5
000070404d1d35db  vpermilpd xmm5, xmm5, 0x00
000070404d1d35e1  vmovaps xmm14, [rsp+0x50]
000070404d1d35e7  vmovaps xmm8, [rsp+0x70]
000070404d1d35ed  vmovaps [rsp+0x50], xmm1
000070404d1d35f3  movaps xmm2, xmm14
000070404d1d35f7  vfmadd231pd xmm2, xmm8, xmm5
000070404d1d35fc  vcmppd xmm1, xmm2, xmm2, 0x03
000070404d1d3601  vptest xmm1, xmm1
000070404d1d3606  jnz 0x000070404D1D46C6
000070404d1d360c  vmovaps xmm1, [rsp+0xB0]
000070404d1d3615  vpermilpd xmm1, xmm1, 0x00
000070404d1d361b  vmovaps xmm14, [rsp+0x60]
000070404d1d3621  vmovaps xmm8, [rsp+0xD0]
000070404d1d362a  vmovaps [rsp+0x60], xmm15
000070404d1d3630  movaps xmm5, xmm14
000070404d1d3634  vfmadd231pd xmm5, xmm8, xmm1
000070404d1d3639  vcmppd xmm15, xmm5, xmm5, 0x03
000070404d1d363e  vptest xmm15, xmm15
000070404d1d3643  jnz 0x000070404D1D481D
000070404d1d3649  vmovaps xmm1, [rsp+0xB0]
000070404d1d3652  vpermilpd xmm1, xmm1, 0x00
000070404d1d3658  vmovaps xmm14, [rsp+0x20]
000070404d1d365e  movaps xmm15, xmm13
000070404d1d3662  vfmadd231pd xmm15, xmm14, xmm1
000070404d1d3667  vcmppd xmm8, xmm15, xmm15, 0x03
000070404d1d366d  vptest xmm8, xmm8
000070404d1d3672  jnz 0x000070404D1D4974
000070404d1d3678  vmovaps xmm1, [rsp+0xB0]
000070404d1d3681  vpermilpd xmm1, xmm1, 0x00
000070404d1d3687  vmovaps xmm14, [rsp+0x90]
000070404d1d3690  movaps xmm13, xmm12
000070404d1d3694  vfmadd231pd xmm13, xmm14, xmm1
000070404d1d3699  vcmppd xmm8, xmm13, xmm13, 0x03
000070404d1d369f  vptest xmm8, xmm8
000070404d1d36a4  jnz 0x000070404D1D4ACD
000070404d1d36aa  vmovaps [rsp+0x20], xmm6
000070404d1d36b0  vmovaps xmm1, [rsp+0x20]
000070404d1d36b6  por xmm6, xmm1
000070404d1d36ba  movaps [r15+0x180], xmm6
000070404d1d36c2  vmovaps [rsp+0x20], xmm9
000070404d1d36c8  vmovaps xmm1, [rsp+0x20]
000070404d1d36ce  por xmm9, xmm1
000070404d1d36d3  movaps [r15+0x2D0], xmm9
000070404d1d36db  vmovaps [rsp+0x20], xmm10
000070404d1d36e1  vmovaps xmm1, [rsp+0x20]
000070404d1d36e7  por xmm10, xmm1
000070404d1d36ec  movaps [r15+0x2F0], xmm10
000070404d1d36f4  vmovaps [rsp+0x20], xmm4
000070404d1d36fa  vpermilpd xmm4, xmm4, 0x00
000070404d1d3700  vmovaps xmm14, [rsp+0x50]
000070404d1d3706  movaps xmm12, xmm5
000070404d1d370a  vfmadd231pd xmm12, xmm14, xmm4
000070404d1d370f  vcmppd xmm10, xmm12, xmm12, 0x03
000070404d1d3715  vptest xmm10, xmm10
000070404d1d371a  jnz 0x000070404D1D4C26
000070404d1d3720  vmovaps xmm14, [rsp+0x20]
000070404d1d3726  vpermilpd xmm14, xmm14, 0x00
000070404d1d372c  movaps xmm10, xmm2
000070404d1d3730  vfmadd231pd xmm10, xmm6, xmm14
000070404d1d3735  vcmppd xmm8, xmm10, xmm10, 0x03
000070404d1d373b  vptest xmm8, xmm8
000070404d1d3740  jnz 0x000070404D1D4D7E
000070404d1d3746  lea r14, [rax+0x80]
000070404d1d374d  movups xmm14, [r13+r14*1]
000070404d1d3753  movaps [r15+0x190], xmm14
000070404d1d375b  vmovaps xmm8, [rsp+0x20]
000070404d1d3761  vpermilpd xmm8, xmm8, 0x00
000070404d1d3767  vmovaps xmm6, [rsp+0x80]
000070404d1d3770  movaps xmm5, xmm15
000070404d1d3774  vfmadd231pd xmm5, xmm6, xmm8
000070404d1d3779  vcmppd xmm4, xmm5, xmm5, 0x03
000070404d1d377e  vptest xmm4, xmm4
000070404d1d3783  jnz 0x000070404D1D4EE0
000070404d1d3789  vmovaps xmm15, [rsp+0x20]
000070404d1d378f  vpermilpd xmm15, xmm15, 0x00
000070404d1d3795  movaps xmm8, xmm13
000070404d1d3799  vfmadd231pd xmm8, xmm1, xmm15
000070404d1d379e  vcmppd xmm6, xmm8, xmm8, 0x03
000070404d1d37a4  vptest xmm6, xmm6
000070404d1d37a9  jnz 0x000070404D1D5037
000070404d1d37af  vmovaps xmm1, [rsp+0x30]
000070404d1d37b5  vmovaps xmm15, [rsp+0x30]
000070404d1d37bb  por xmm1, xmm15
000070404d1d37c0  movaps [r15+0x160], xmm1
000070404d1d37c8  lea r14, [rax+0x40]
000070404d1d37cc  movups xmm15, [r13+r14*1]
000070404d1d37d2  lea r14, [rax+0x50]
000070404d1d37d6  movups xmm13, [r13+r14*1]
000070404d1d37dc  movaps [r15+0x1B0], xmm15
000070404d1d37e4  movaps [r15+0x1A0], xmm13
000070404d1d37ec  vmovaps xmm6, [rsp+0xC0]
000070404d1d37f5  vpermilpd xmm6, xmm6, 0x00
000070404d1d37fb  movaps xmm4, xmm12
000070404d1d37ff  vfmadd231pd xmm4, xmm9, xmm6
000070404d1d3804  vcmppd xmm2, xmm4, xmm4, 0x03
000070404d1d3809  vptest xmm2, xmm2
000070404d1d380e  jnz 0x000070404D1D51A4
000070404d1d3814  vmovaps xmm12, [rsp+0xC0]
000070404d1d381d  vpermilpd xmm12, xmm12, 0x00
000070404d1d3823  movaps xmm9, xmm10
000070404d1d3827  vfmadd231pd xmm9, xmm1, xmm12
000070404d1d382c  vcmppd xmm6, xmm9, xmm9, 0x03
000070404d1d3832  vptest xmm6, xmm6
000070404d1d3837  jnz 0x000070404D1D52FB
000070404d1d383d  vmovaps xmm1, [rsp+0xC0]
000070404d1d3846  vpermilpd xmm1, xmm1, 0x00
000070404d1d384c  vmovaps xmm12, [rsp+0x40]
000070404d1d3852  movaps xmm10, xmm5
000070404d1d3856  vfmadd231pd xmm10, xmm12, xmm1
000070404d1d385b  vcmppd xmm6, xmm10, xmm10, 0x03
000070404d1d3861  vptest xmm6, xmm6
000070404d1d3866  jnz 0x000070404D1D5454
000070404d1d386c  vmovaps xmm1, [rsp+0xC0]
000070404d1d3875  vpermilpd xmm1, xmm1, 0x00
000070404d1d387b  vmovaps xmm12, [rsp+0x60]
000070404d1d3881  movaps xmm6, xmm8
000070404d1d3885  vfmadd231pd xmm6, xmm12, xmm1
000070404d1d388a  vcmppd xmm5, xmm6, xmm6, 0x03
000070404d1d388f  vptest xmm5, xmm5
000070404d1d3894  jnz 0x000070404D1D55AC
000070404d1d389a  lea r14, [rax+0x60]
000070404d1d389e  movups xmm1, [r13+r14*1]
000070404d1d38a4  lea r14, [rax+0x70]
000070404d1d38a8  movups xmm12, [r13+r14*1]
000070404d1d38ae  movaps [r15+0x150], xmm1
000070404d1d38b6  movaps [r15+0x120], xmm12
000070404d1d38be  vmovaps [rsp+0x20], xmm11
000070404d1d38c4  vpermilpd xmm11, xmm11, 0x00
000070404d1d38ca  movaps xmm8, xmm4
000070404d1d38ce  vfmadd231pd xmm8, xmm13, xmm11
000070404d1d38d3  vcmppd xmm5, xmm8, xmm8, 0x03
000070404d1d38d9  vptest xmm5, xmm5
000070404d1d38de  jnz 0x000070404D1D5717
000070404d1d38e4  vmovaps xmm13, [rsp+0x20]
000070404d1d38ea  vpermilpd xmm13, xmm13, 0x00
000070404d1d38f0  movaps xmm11, xmm9
000070404d1d38f4  vfmadd231pd xmm11, xmm1, xmm13
000070404d1d38f9  vcmppd xmm5, xmm11, xmm11, 0x03
000070404d1d38ff  vptest xmm5, xmm5
000070404d1d3904  jnz 0x000070404D1D5870
000070404d1d390a  vmovaps xmm1, [rsp+0x20]
000070404d1d3910  vpermilpd xmm1, xmm1, 0x00
000070404d1d3916  movaps xmm13, xmm10
000070404d1d391a  vfmadd231pd xmm13, xmm7, xmm1
000070404d1d391f  vcmppd xmm9, xmm13, xmm13, 0x03
000070404d1d3925  vptest xmm9, xmm9
000070404d1d392a  jnz 0x000070404D1D59C9
000070404d1d3930  vmovaps xmm1, [rsp+0x20]
000070404d1d3936  vpermilpd xmm1, xmm1, 0x00
000070404d1d393c  movaps xmm10, xmm6
000070404d1d3940  vfmadd231pd xmm10, xmm15, xmm1
000070404d1d3945  vcmppd xmm9, xmm10, xmm10, 0x03
000070404d1d394b  vptest xmm9, xmm9
000070404d1d3950  jnz 0x000070404D1D5B21
000070404d1d3956  lea r14, [rax+0x20]
000070404d1d395a  movups xmm1, [r13+r14*1]
000070404d1d3960  lea r14, [rax+0x30]
000070404d1d3964  movups xmm15, [r13+r14*1]
000070404d1d396a  vmovaps xmm9, [rsp+0xA0]
000070404d1d3973  vpermilpd xmm9, xmm9, 0x00
000070404d1d3979  movaps xmm7, xmm8
000070404d1d397d  vfmadd231pd xmm7, xmm3, xmm9
000070404d1d3982  vcmppd xmm6, xmm7, xmm7, 0x03
000070404d1d3987  vptest xmm6, xmm6
000070404d1d398c  jnz 0x000070404D1D5C8D
000070404d1d3992  vmovaps xmm9, [rsp+0xA0]
000070404d1d399b  vpermilpd xmm9, xmm9, 0x00
000070404d1d39a1  movaps xmm8, xmm11
000070404d1d39a5  vfmadd231pd xmm8, xmm14, xmm9
000070404d1d39aa  vcmppd xmm6, xmm8, xmm8, 0x03
000070404d1d39b0  vptest xmm6, xmm6
000070404d1d39b5  jnz 0x000070404D1D5DE4
000070404d1d39bb  vmovaps xmm14, [rsp+0xA0]
000070404d1d39c4  vpermilpd xmm14, xmm14, 0x00
000070404d1d39ca  movaps xmm11, xmm13
000070404d1d39ce  vfmadd231pd xmm11, xmm12, xmm14
000070404d1d39d3  vcmppd xmm9, xmm11, xmm11, 0x03
000070404d1d39d9  vptest xmm9, xmm9
000070404d1d39de  jnz 0x000070404D1D5F3E
000070404d1d39e4  vmovaps xmm14, [rsp+0xA0]
000070404d1d39ed  vpermilpd xmm14, xmm14, 0x00
000070404d1d39f3  movaps xmm12, xmm10
000070404d1d39f7  vfmadd231pd xmm12, xmm15, xmm14
000070404d1d39fc  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1d3a02  vptest xmm13, xmm13
000070404d1d3a07  jnz 0x000070404D1D6098
000070404d1d3a0d  lea r14, [rax+0x90]
000070404d1d3a14  movups xmm15, [r13+r14*1]
000070404d1d3a1a  lea r14, [rax+0xA0]
000070404d1d3a21  movups xmm14, [r13+r14*1]
000070404d1d3a27  movaps [r15+0x140], xmm15
000070404d1d3a2f  movaps [r15+0x130], xmm14
000070404d1d3a37  vmovaps xmm13, [rsp+0x10]
000070404d1d3a3d  vpermilpd xmm13, xmm13, 0x00
000070404d1d3a43  movaps xmm10, xmm7
000070404d1d3a47  vfmadd231pd xmm10, xmm1, xmm13
000070404d1d3a4c  vcmppd xmm9, xmm10, xmm10, 0x03
000070404d1d3a52  vptest xmm9, xmm9
000070404d1d3a57  jnz 0x000070404D1D6206
000070404d1d3a5d  movaps [r15+0x220], xmm10
000070404d1d3a65  lea r14, [rax+0x10]
000070404d1d3a69  movups xmm1, [r13+r14*1]
000070404d1d3a6f  movaps [r15+0x240], xmm1
000070404d1d3a77  vmovaps xmm13, [rsp+0x10]
000070404d1d3a7d  vpermilpd xmm13, xmm13, 0x00
000070404d1d3a83  movaps xmm9, xmm8
000070404d1d3a87  vfmadd231pd xmm9, xmm14, xmm13
000070404d1d3a8c  vcmppd xmm7, xmm9, xmm9, 0x03
000070404d1d3a92  vptest xmm7, xmm7
000070404d1d3a97  jnz 0x000070404D1D6368
000070404d1d3a9d  movaps [r15+0x110], xmm9
000070404d1d3aa5  vmovaps xmm14, [rsp+0x10]
000070404d1d3aab  vpermilpd xmm14, xmm14, 0x00
000070404d1d3ab1  movaps xmm13, xmm11
000070404d1d3ab5  vfmadd231pd xmm13, xmm15, xmm14
000070404d1d3aba  vcmppd xmm8, xmm13, xmm13, 0x03
000070404d1d3ac0  vptest xmm8, xmm8
000070404d1d3ac5  jnz 0x000070404D1D64C2
000070404d1d3acb  movaps [r15+0x170], xmm13
000070404d1d3ad3  vmovaps xmm15, [rsp+0x10]
000070404d1d3ad9  vpermilpd xmm15, xmm15, 0x00
000070404d1d3adf  movaps xmm14, xmm12
000070404d1d3ae3  vfmadd231pd xmm14, xmm1, xmm15
000070404d1d3ae8  vcmppd xmm11, xmm14, xmm14, 0x03
000070404d1d3aee  vptest xmm11, xmm11
000070404d1d3af3  jnz 0x000070404D1D661C
000070404d1d3af9  movaps [r15+0x230], xmm14
000070404d1d3b01  movups [r13+r11*1], xmm9
000070404d1d3b07  lea rax, [r11+0x10]
000070404d1d3b0b  movups [r13+rax*1], xmm13
000070404d1d3b11  lea rax, [r11+0x20]
000070404d1d3b15  movups [r13+rax*1], xmm10
000070404d1d3b1b  lea rax, [r11+0x30]
000070404d1d3b1f  movups [r13+rax*1], xmm14
000070404d1d3b25  mov eax, [r15+0x108]
000070404d1d3b2c  sahf
000070404d1d3b2d  jnz 0x000070404D1D3B5F
000070404d1d3b2f  cmp dword ptr [r15+0x318], 0x00
000070404d1d3b37  jz 0x000070404D1D67A0
000070404d1d3b3d  nop [rax+rax*1], ax
000070404d1d3b46  nop [rax+rax*1], eax
000070404d1d3b4e  mov eax, 0x4103F0
000070404d1d3b53  mov [r15+0x100], rax
000070404d1d3b5a  jmp 0x000070404CFFE110
000070404d1d3b5f  cmp dword ptr [r15+0x318], 0x00
000070404d1d3b67  jz 0x000070404D1D2E40
000070404d1d3b6d  nop [rax+rax*1], ax
000070404d1d3b76  nop [rax+rax*1], eax
000070404d1d3b7e  mov eax, 0x410274
000070404d1d3b83  mov [r15+0x100], rax
000070404d1d3b8a  jmp 0x000070404CFFE110
000070404d1d3b8f  int3
000070404d1d3b90  call 0x000070404D00A4B0
000070404d1d3b95  jmp 0x000070404D1D2E69
000070404d1d3b9a  call 0x000070404D009240
000070404d1d3b9f  jmp 0x000070404D1D2E73
000070404d1d3ba4  call 0x000070404D00A4B0
000070404d1d3ba9  jmp 0x000070404D1D2EBD
000070404d1d3bae  call 0x000070404D009240
000070404d1d3bb3  jmp 0x000070404D1D2EC7
000070404d1d3bb8  call 0x000070404D00A4B0
000070404d1d3bbd  jmp 0x000070404D1D2F60
000070404d1d3bc2  call 0x000070404D009240
000070404d1d3bc7  jmp 0x000070404D1D2F6A
000070404d1d3bcc  call 0x000070404D0B47C0
000070404d1d3bd1  jmp 0x000070404D1D3055
000070404d1d3bd6  call 0x000070404CFFF430
000070404d1d3bdb  jmp 0x000070404D1D3084
000070404d1d3be0  call 0x000070404D0B0CE0
000070404d1d3be5  jmp 0x000070404D1D30A0
000070404d1d3bea  sub rsp, 0x08
000070404d1d3bee  push rax
000070404d1d3bef  push rcx
000070404d1d3bf0  push rdx
000070404d1d3bf1  push rdi
000070404d1d3bf2  push rsi
000070404d1d3bf3  push r8
000070404d1d3bf5  push r9
000070404d1d3bf7  push r10
000070404d1d3bf9  push r11
000070404d1d3bfb  sub rsp, 0xF0
000070404d1d3c02  vmovaps [rsp], xmm0
000070404d1d3c07  vmovaps [rsp+0x10], xmm1
000070404d1d3c0d  vmovaps [rsp+0x20], xmm2
000070404d1d3c13  vmovaps [rsp+0x30], xmm3
000070404d1d3c19  vmovaps [rsp+0x40], xmm4
000070404d1d3c1f  vmovaps [rsp+0x50], xmm5
000070404d1d3c25  vmovaps [rsp+0x60], xmm6
000070404d1d3c2b  vmovaps [rsp+0x70], xmm7
000070404d1d3c31  vmovaps [rsp+0x80], xmm8
000070404d1d3c3a  vmovaps [rsp+0x90], xmm9
000070404d1d3c43  vmovaps [rsp+0xA0], xmm10
000070404d1d3c4c  vmovaps [rsp+0xB0], xmm11
000070404d1d3c55  vmovaps [rsp+0xC0], xmm12
000070404d1d3c5e  vmovaps [rsp+0xD0], xmm14
000070404d1d3c67  vmovaps [rsp+0xE0], xmm15
000070404d1d3c70  sub rsp, 0x40
000070404d1d3c74  lea rdi, [rsp]
000070404d1d3c78  lea rsi, [rsp+0x10]
000070404d1d3c7d  lea rdx, [rsp+0x20]
000070404d1d3c82  lea rcx, [rsp+0x30]
000070404d1d3c87  mov r8d, 0x00
000070404d1d3c8d  lea r9, [r15+0x3A8]
000070404d1d3c94  movaps [rdi], xmm13
000070404d1d3c98  movaps [rsi], xmm1
000070404d1d3c9b  movaps [rdx], xmm15
000070404d1d3c9f  movaps [rcx], xmm14
000070404d1d3ca3  mov rax, 0x607928F07A50
000070404d1d3cad  call rax
000070404d1d3caf  movaps xmm13, [rsp]
000070404d1d3cb4  add rsp, 0x40
000070404d1d3cb8  vmovaps xmm0, [rsp]
000070404d1d3cbd  vmovaps xmm1, [rsp+0x10]
000070404d1d3cc3  vmovaps xmm2, [rsp+0x20]
000070404d1d3cc9  vmovaps xmm3, [rsp+0x30]
000070404d1d3ccf  vmovaps xmm4, [rsp+0x40]
000070404d1d3cd5  vmovaps xmm5, [rsp+0x50]
000070404d1d3cdb  vmovaps xmm6, [rsp+0x60]
000070404d1d3ce1  vmovaps xmm7, [rsp+0x70]
000070404d1d3ce7  vmovaps xmm8, [rsp+0x80]
000070404d1d3cf0  vmovaps xmm9, [rsp+0x90]
000070404d1d3cf9  vmovaps xmm10, [rsp+0xA0]
000070404d1d3d02  vmovaps xmm11, [rsp+0xB0]
000070404d1d3d0b  vmovaps xmm12, [rsp+0xC0]
000070404d1d3d14  vmovaps xmm14, [rsp+0xD0]
000070404d1d3d1d  vmovaps xmm15, [rsp+0xE0]
000070404d1d3d26  add rsp, 0xF0
000070404d1d3d2d  pop r11
000070404d1d3d2f  pop r10
000070404d1d3d31  pop r9
000070404d1d3d33  pop r8
000070404d1d3d35  pop rsi
000070404d1d3d36  pop rdi
000070404d1d3d37  pop rdx
000070404d1d3d38  pop rcx
000070404d1d3d39  pop rax
000070404d1d3d3a  add rsp, 0x08
000070404d1d3d3e  jmp 0x000070404D1D3117
000070404d1d3d43  sub rsp, 0x08
000070404d1d3d47  push rax
000070404d1d3d48  push rcx
000070404d1d3d49  push rdx
000070404d1d3d4a  push rdi
000070404d1d3d4b  push rsi
000070404d1d3d4c  push r8
000070404d1d3d4e  push r9
000070404d1d3d50  push r10
000070404d1d3d52  push r11
000070404d1d3d54  sub rsp, 0xF0
000070404d1d3d5b  vmovaps [rsp], xmm0
000070404d1d3d60  vmovaps [rsp+0x10], xmm1
000070404d1d3d66  vmovaps [rsp+0x20], xmm2
000070404d1d3d6c  vmovaps [rsp+0x30], xmm3
000070404d1d3d72  vmovaps [rsp+0x40], xmm4
000070404d1d3d78  vmovaps [rsp+0x50], xmm5
000070404d1d3d7e  vmovaps [rsp+0x60], xmm6
000070404d1d3d84  vmovaps [rsp+0x70], xmm7
000070404d1d3d8a  vmovaps [rsp+0x80], xmm8
000070404d1d3d93  vmovaps [rsp+0x90], xmm9
000070404d1d3d9c  vmovaps [rsp+0xA0], xmm10
000070404d1d3da5  vmovaps [rsp+0xB0], xmm11
000070404d1d3dae  vmovaps [rsp+0xC0], xmm13
000070404d1d3db7  vmovaps [rsp+0xD0], xmm14
000070404d1d3dc0  vmovaps [rsp+0xE0], xmm15
000070404d1d3dc9  sub rsp, 0x40
000070404d1d3dcd  lea rdi, [rsp]
000070404d1d3dd1  lea rsi, [rsp+0x10]
000070404d1d3dd6  lea rdx, [rsp+0x20]
000070404d1d3ddb  lea rcx, [rsp+0x30]
000070404d1d3de0  mov r8d, 0x00
000070404d1d3de6  lea r9, [r15+0x3A8]
000070404d1d3ded  movaps [rdi], xmm12
000070404d1d3df1  movaps [rsi], xmm15
000070404d1d3df5  movaps [rdx], xmm1
000070404d1d3df8  movaps [rcx], xmm14
000070404d1d3dfc  mov rax, 0x607928F07A50
000070404d1d3e06  call rax
000070404d1d3e08  movaps xmm12, [rsp]
000070404d1d3e0d  add rsp, 0x40
000070404d1d3e11  vmovaps xmm0, [rsp]
000070404d1d3e16  vmovaps xmm1, [rsp+0x10]
000070404d1d3e1c  vmovaps xmm2, [rsp+0x20]
000070404d1d3e22  vmovaps xmm3, [rsp+0x30]
000070404d1d3e28  vmovaps xmm4, [rsp+0x40]
000070404d1d3e2e  vmovaps xmm5, [rsp+0x50]
000070404d1d3e34  vmovaps xmm6, [rsp+0x60]
000070404d1d3e3a  vmovaps xmm7, [rsp+0x70]
000070404d1d3e40  vmovaps xmm8, [rsp+0x80]
000070404d1d3e49  vmovaps xmm9, [rsp+0x90]
000070404d1d3e52  vmovaps xmm10, [rsp+0xA0]
000070404d1d3e5b  vmovaps xmm11, [rsp+0xB0]
000070404d1d3e64  vmovaps xmm13, [rsp+0xC0]
000070404d1d3e6d  vmovaps xmm14, [rsp+0xD0]
000070404d1d3e76  vmovaps xmm15, [rsp+0xE0]
000070404d1d3e7f  add rsp, 0xF0
000070404d1d3e86  pop r11
000070404d1d3e88  pop r10
000070404d1d3e8a  pop r9
000070404d1d3e8c  pop r8
000070404d1d3e8e  pop rsi
000070404d1d3e8f  pop rdi
000070404d1d3e90  pop rdx
000070404d1d3e91  pop rcx
000070404d1d3e92  pop rax
000070404d1d3e93  add rsp, 0x08
000070404d1d3e97  jmp 0x000070404D1D3145
000070404d1d3e9c  call 0x000070404D0D64F0
000070404d1d3ea1  jmp 0x000070404D1D3231
000070404d1d3ea6  sub rsp, 0x08
000070404d1d3eaa  push rax
000070404d1d3eab  push rcx
000070404d1d3eac  push rdx
000070404d1d3ead  push rdi
000070404d1d3eae  push rsi
000070404d1d3eaf  push r8
000070404d1d3eb1  push r9
000070404d1d3eb3  push r10
000070404d1d3eb5  push r11
000070404d1d3eb7  sub rsp, 0xF0
000070404d1d3ebe  vmovaps [rsp], xmm0
000070404d1d3ec3  vmovaps [rsp+0x10], xmm1
000070404d1d3ec9  vmovaps [rsp+0x20], xmm2
000070404d1d3ecf  vmovaps [rsp+0x30], xmm3
000070404d1d3ed5  vmovaps [rsp+0x40], xmm4
000070404d1d3edb  vmovaps [rsp+0x50], xmm5
000070404d1d3ee1  vmovaps [rsp+0x60], xmm6
000070404d1d3ee7  vmovaps [rsp+0x70], xmm7
000070404d1d3eed  vmovaps [rsp+0x80], xmm8
000070404d1d3ef6  vmovaps [rsp+0x90], xmm9
000070404d1d3eff  vmovaps [rsp+0xA0], xmm10
000070404d1d3f08  vmovaps [rsp+0xB0], xmm11
000070404d1d3f11  vmovaps [rsp+0xC0], xmm12
000070404d1d3f1a  vmovaps [rsp+0xD0], xmm14
000070404d1d3f23  vmovaps [rsp+0xE0], xmm15
000070404d1d3f2c  sub rsp, 0x40
000070404d1d3f30  lea rdi, [rsp]
000070404d1d3f34  lea rsi, [rsp+0x10]
000070404d1d3f39  lea rdx, [rsp+0x20]
000070404d1d3f3e  lea rcx, [rsp+0x30]
000070404d1d3f43  mov r8d, 0x00
000070404d1d3f49  lea r9, [r15+0x3A8]
000070404d1d3f50  movaps [rdi], xmm13
000070404d1d3f54  movaps [rsi], xmm1
000070404d1d3f57  movaps [rdx], xmm15
000070404d1d3f5b  movaps [rcx], xmm14
000070404d1d3f5f  mov rax, 0x607928F07A50
000070404d1d3f69  call rax
000070404d1d3f6b  movaps xmm13, [rsp]
000070404d1d3f70  add rsp, 0x40
000070404d1d3f74  vmovaps xmm0, [rsp]
000070404d1d3f79  vmovaps xmm1, [rsp+0x10]
000070404d1d3f7f  vmovaps xmm2, [rsp+0x20]
000070404d1d3f85  vmovaps xmm3, [rsp+0x30]
000070404d1d3f8b  vmovaps xmm4, [rsp+0x40]
000070404d1d3f91  vmovaps xmm5, [rsp+0x50]
000070404d1d3f97  vmovaps xmm6, [rsp+0x60]
000070404d1d3f9d  vmovaps xmm7, [rsp+0x70]
000070404d1d3fa3  vmovaps xmm8, [rsp+0x80]
000070404d1d3fac  vmovaps xmm9, [rsp+0x90]
000070404d1d3fb5  vmovaps xmm10, [rsp+0xA0]
000070404d1d3fbe  vmovaps xmm11, [rsp+0xB0]
000070404d1d3fc7  vmovaps xmm12, [rsp+0xC0]
000070404d1d3fd0  vmovaps xmm14, [rsp+0xD0]
000070404d1d3fd9  vmovaps xmm15, [rsp+0xE0]
000070404d1d3fe2  add rsp, 0xF0
000070404d1d3fe9  pop r11
000070404d1d3feb  pop r10
000070404d1d3fed  pop r9
000070404d1d3fef  pop r8
000070404d1d3ff1  pop rsi
000070404d1d3ff2  pop rdi
000070404d1d3ff3  pop rdx
000070404d1d3ff4  pop rcx
000070404d1d3ff5  pop rax
000070404d1d3ff6  add rsp, 0x08
000070404d1d3ffa  jmp 0x000070404D1D32A0
000070404d1d3fff  call 0x000070404D0D64F0
000070404d1d4004  jmp 0x000070404D1D32B5
000070404d1d4009  sub rsp, 0x08
000070404d1d400d  push rax
000070404d1d400e  push rcx
000070404d1d400f  push rdx
000070404d1d4010  push rdi
000070404d1d4011  push rsi
000070404d1d4012  push r8
000070404d1d4014  push r9
000070404d1d4016  push r10
000070404d1d4018  push r11
000070404d1d401a  sub rsp, 0xF0
000070404d1d4021  vmovaps [rsp], xmm0
000070404d1d4026  vmovaps [rsp+0x10], xmm1
000070404d1d402c  vmovaps [rsp+0x20], xmm2
000070404d1d4032  vmovaps [rsp+0x30], xmm3
000070404d1d4038  vmovaps [rsp+0x40], xmm4
000070404d1d403e  vmovaps [rsp+0x50], xmm5
000070404d1d4044  vmovaps [rsp+0x60], xmm6
000070404d1d404a  vmovaps [rsp+0x70], xmm7
000070404d1d4050  vmovaps [rsp+0x80], xmm8
000070404d1d4059  vmovaps [rsp+0x90], xmm9
000070404d1d4062  vmovaps [rsp+0xA0], xmm10
000070404d1d406b  vmovaps [rsp+0xB0], xmm11
000070404d1d4074  vmovaps [rsp+0xC0], xmm13
000070404d1d407d  vmovaps [rsp+0xD0], xmm14
000070404d1d4086  vmovaps [rsp+0xE0], xmm15
000070404d1d408f  sub rsp, 0x40
000070404d1d4093  lea rdi, [rsp]
000070404d1d4097  lea rsi, [rsp+0x10]
000070404d1d409c  lea rdx, [rsp+0x20]
000070404d1d40a1  lea rcx, [rsp+0x30]
000070404d1d40a6  mov r8d, 0x00
000070404d1d40ac  lea r9, [r15+0x3A8]
000070404d1d40b3  movaps [rdi], xmm12
000070404d1d40b7  movaps [rsi], xmm15
000070404d1d40bb  movaps [rdx], xmm1
000070404d1d40be  movaps [rcx], xmm14
000070404d1d40c2  mov rax, 0x607928F07A50
000070404d1d40cc  call rax
000070404d1d40ce  movaps xmm12, [rsp]
000070404d1d40d3  add rsp, 0x40
000070404d1d40d7  vmovaps xmm0, [rsp]
000070404d1d40dc  vmovaps xmm1, [rsp+0x10]
000070404d1d40e2  vmovaps xmm2, [rsp+0x20]
000070404d1d40e8  vmovaps xmm3, [rsp+0x30]
000070404d1d40ee  vmovaps xmm4, [rsp+0x40]
000070404d1d40f4  vmovaps xmm5, [rsp+0x50]
000070404d1d40fa  vmovaps xmm6, [rsp+0x60]
000070404d1d4100  vmovaps xmm7, [rsp+0x70]
000070404d1d4106  vmovaps xmm8, [rsp+0x80]
000070404d1d410f  vmovaps xmm9, [rsp+0x90]
000070404d1d4118  vmovaps xmm10, [rsp+0xA0]
000070404d1d4121  vmovaps xmm11, [rsp+0xB0]
000070404d1d412a  vmovaps xmm13, [rsp+0xC0]
000070404d1d4133  vmovaps xmm14, [rsp+0xD0]
000070404d1d413c  vmovaps xmm15, [rsp+0xE0]
000070404d1d4145  add rsp, 0xF0
000070404d1d414c  pop r11
000070404d1d414e  pop r10
000070404d1d4150  pop r9
000070404d1d4152  pop r8
000070404d1d4154  pop rsi
000070404d1d4155  pop rdi
000070404d1d4156  pop rdx
000070404d1d4157  pop rcx
000070404d1d4158  pop rax
000070404d1d4159  add rsp, 0x08
000070404d1d415d  jmp 0x000070404D1D32E1
000070404d1d4162  sub rsp, 0x08
000070404d1d4166  push rax
000070404d1d4167  push rcx
000070404d1d4168  push rdx
000070404d1d4169  push rdi
000070404d1d416a  push rsi
000070404d1d416b  push r8
000070404d1d416d  push r9
000070404d1d416f  push r10
000070404d1d4171  push r11
000070404d1d4173  sub rsp, 0xF0
000070404d1d417a  vmovaps [rsp], xmm0
000070404d1d417f  vmovaps [rsp+0x10], xmm1
000070404d1d4185  vmovaps [rsp+0x20], xmm2
000070404d1d418b  vmovaps [rsp+0x30], xmm3
000070404d1d4191  vmovaps [rsp+0x40], xmm4
000070404d1d4197  vmovaps [rsp+0x50], xmm5
000070404d1d419d  vmovaps [rsp+0x60], xmm6
000070404d1d41a3  vmovaps [rsp+0x70], xmm7
000070404d1d41a9  vmovaps [rsp+0x80], xmm8
000070404d1d41b2  vmovaps [rsp+0x90], xmm9
000070404d1d41bb  vmovaps [rsp+0xA0], xmm10
000070404d1d41c4  vmovaps [rsp+0xB0], xmm11
000070404d1d41cd  vmovaps [rsp+0xC0], xmm12
000070404d1d41d6  vmovaps [rsp+0xD0], xmm14
000070404d1d41df  vmovaps [rsp+0xE0], xmm15
000070404d1d41e8  sub rsp, 0x40
000070404d1d41ec  lea rdi, [rsp]
000070404d1d41f0  lea rsi, [rsp+0x10]
000070404d1d41f5  lea rdx, [rsp+0x20]
000070404d1d41fa  lea rcx, [rsp+0x30]
000070404d1d41ff  mov r8d, 0x00
000070404d1d4205  lea r9, [r15+0x3A8]
000070404d1d420c  movaps [rdi], xmm13
000070404d1d4210  movaps [rsi], xmm1
000070404d1d4213  movaps [rdx], xmm15
000070404d1d4217  movaps [rcx], xmm14
000070404d1d421b  mov rax, 0x607928F07A50
000070404d1d4225  call rax
000070404d1d4227  movaps xmm13, [rsp]
000070404d1d422c  add rsp, 0x40
000070404d1d4230  vmovaps xmm0, [rsp]
000070404d1d4235  vmovaps xmm1, [rsp+0x10]
000070404d1d423b  vmovaps xmm2, [rsp+0x20]
000070404d1d4241  vmovaps xmm3, [rsp+0x30]
000070404d1d4247  vmovaps xmm4, [rsp+0x40]
000070404d1d424d  vmovaps xmm5, [rsp+0x50]
000070404d1d4253  vmovaps xmm6, [rsp+0x60]
000070404d1d4259  vmovaps xmm7, [rsp+0x70]
000070404d1d425f  vmovaps xmm8, [rsp+0x80]
000070404d1d4268  vmovaps xmm9, [rsp+0x90]
000070404d1d4271  vmovaps xmm10, [rsp+0xA0]
000070404d1d427a  vmovaps xmm11, [rsp+0xB0]
000070404d1d4283  vmovaps xmm12, [rsp+0xC0]
000070404d1d428c  vmovaps xmm14, [rsp+0xD0]
000070404d1d4295  vmovaps xmm15, [rsp+0xE0]
000070404d1d429e  add rsp, 0xF0
000070404d1d42a5  pop r11
000070404d1d42a7  pop r10
000070404d1d42a9  pop r9
000070404d1d42ab  pop r8
000070404d1d42ad  pop rsi
000070404d1d42ae  pop rdi
000070404d1d42af  pop rdx
000070404d1d42b0  pop rcx
000070404d1d42b1  pop rax
000070404d1d42b2  add rsp, 0x08
000070404d1d42b6  jmp 0x000070404D1D3482
000070404d1d42bb  sub rsp, 0x08
000070404d1d42bf  push rax
000070404d1d42c0  push rcx
000070404d1d42c1  push rdx
000070404d1d42c2  push rdi
000070404d1d42c3  push rsi
000070404d1d42c4  push r8
000070404d1d42c6  push r9
000070404d1d42c8  push r10
000070404d1d42ca  push r11
000070404d1d42cc  sub rsp, 0xF0
000070404d1d42d3  vmovaps [rsp], xmm0
000070404d1d42d8  vmovaps [rsp+0x10], xmm1
000070404d1d42de  vmovaps [rsp+0x20], xmm2
000070404d1d42e4  vmovaps [rsp+0x30], xmm3
000070404d1d42ea  vmovaps [rsp+0x40], xmm4
000070404d1d42f0  vmovaps [rsp+0x50], xmm5
000070404d1d42f6  vmovaps [rsp+0x60], xmm6
000070404d1d42fc  vmovaps [rsp+0x70], xmm7
000070404d1d4302  vmovaps [rsp+0x80], xmm8
000070404d1d430b  vmovaps [rsp+0x90], xmm9
000070404d1d4314  vmovaps [rsp+0xA0], xmm10
000070404d1d431d  vmovaps [rsp+0xB0], xmm11
000070404d1d4326  vmovaps [rsp+0xC0], xmm13
000070404d1d432f  vmovaps [rsp+0xD0], xmm14
000070404d1d4338  vmovaps [rsp+0xE0], xmm15
000070404d1d4341  sub rsp, 0x40
000070404d1d4345  lea rdi, [rsp]
000070404d1d4349  lea rsi, [rsp+0x10]
000070404d1d434e  lea rdx, [rsp+0x20]
000070404d1d4353  lea rcx, [rsp+0x30]
000070404d1d4358  mov r8d, 0x00
000070404d1d435e  lea r9, [r15+0x3A8]
000070404d1d4365  movaps [rdi], xmm12
000070404d1d4369  movaps [rsi], xmm15
000070404d1d436d  movaps [rdx], xmm14
000070404d1d4371  movaps [rcx], xmm1
000070404d1d4374  mov rax, 0x607928F07A50
000070404d1d437e  call rax
000070404d1d4380  movaps xmm12, [rsp]
000070404d1d4385  add rsp, 0x40
000070404d1d4389  vmovaps xmm0, [rsp]
000070404d1d438e  vmovaps xmm1, [rsp+0x10]
000070404d1d4394  vmovaps xmm2, [rsp+0x20]
000070404d1d439a  vmovaps xmm3, [rsp+0x30]
000070404d1d43a0  vmovaps xmm4, [rsp+0x40]
000070404d1d43a6  vmovaps xmm5, [rsp+0x50]
000070404d1d43ac  vmovaps xmm6, [rsp+0x60]
000070404d1d43b2  vmovaps xmm7, [rsp+0x70]
000070404d1d43b8  vmovaps xmm8, [rsp+0x80]
000070404d1d43c1  vmovaps xmm9, [rsp+0x90]
000070404d1d43ca  vmovaps xmm10, [rsp+0xA0]
000070404d1d43d3  vmovaps xmm11, [rsp+0xB0]
000070404d1d43dc  vmovaps xmm13, [rsp+0xC0]
000070404d1d43e5  vmovaps xmm14, [rsp+0xD0]
000070404d1d43ee  vmovaps xmm15, [rsp+0xE0]
000070404d1d43f7  add rsp, 0xF0
000070404d1d43fe  pop r11
000070404d1d4400  pop r10
000070404d1d4402  pop r9
000070404d1d4404  pop r8
000070404d1d4406  pop rsi
000070404d1d4407  pop rdi
000070404d1d4408  pop rdx
000070404d1d4409  pop rcx
000070404d1d440a  pop rax
000070404d1d440b  add rsp, 0x08
000070404d1d440f  jmp 0x000070404D1D34C0
000070404d1d4414  sub rsp, 0x08
000070404d1d4418  push rax
000070404d1d4419  push rcx
000070404d1d441a  push rdx
000070404d1d441b  push rdi
000070404d1d441c  push rsi
000070404d1d441d  push r8
000070404d1d441f  push r9
000070404d1d4421  push r10
000070404d1d4423  push r11
000070404d1d4425  sub rsp, 0xF0
000070404d1d442c  vmovaps [rsp], xmm0
000070404d1d4431  vmovaps [rsp+0x10], xmm1
000070404d1d4437  vmovaps [rsp+0x20], xmm2
000070404d1d443d  vmovaps [rsp+0x30], xmm3
000070404d1d4443  vmovaps [rsp+0x40], xmm4
000070404d1d4449  vmovaps [rsp+0x50], xmm5
000070404d1d444f  vmovaps [rsp+0x60], xmm6
000070404d1d4455  vmovaps [rsp+0x70], xmm7
000070404d1d445b  vmovaps [rsp+0x80], xmm8
000070404d1d4464  vmovaps [rsp+0x90], xmm9
000070404d1d446d  vmovaps [rsp+0xA0], xmm10
000070404d1d4476  vmovaps [rsp+0xB0], xmm11
000070404d1d447f  vmovaps [rsp+0xC0], xmm12
000070404d1d4488  vmovaps [rsp+0xD0], xmm14
000070404d1d4491  vmovaps [rsp+0xE0], xmm15
000070404d1d449a  sub rsp, 0x40
000070404d1d449e  lea rdi, [rsp]
000070404d1d44a2  lea rsi, [rsp+0x10]
000070404d1d44a7  lea rdx, [rsp+0x20]
000070404d1d44ac  lea rcx, [rsp+0x30]
000070404d1d44b1  mov r8d, 0x00
000070404d1d44b7  lea r9, [r15+0x3A8]
000070404d1d44be  movaps [rdi], xmm13
000070404d1d44c2  movaps [rsi], xmm15
000070404d1d44c6  movaps [rdx], xmm14
000070404d1d44ca  movaps [rcx], xmm1
000070404d1d44cd  mov rax, 0x607928F07A50
000070404d1d44d7  call rax
000070404d1d44d9  movaps xmm13, [rsp]
000070404d1d44de  add rsp, 0x40
000070404d1d44e2  vmovaps xmm0, [rsp]
000070404d1d44e7  vmovaps xmm1, [rsp+0x10]
000070404d1d44ed  vmovaps xmm2, [rsp+0x20]
000070404d1d44f3  vmovaps xmm3, [rsp+0x30]
000070404d1d44f9  vmovaps xmm4, [rsp+0x40]
000070404d1d44ff  vmovaps xmm5, [rsp+0x50]
000070404d1d4505  vmovaps xmm6, [rsp+0x60]
000070404d1d450b  vmovaps xmm7, [rsp+0x70]
000070404d1d4511  vmovaps xmm8, [rsp+0x80]
000070404d1d451a  vmovaps xmm9, [rsp+0x90]
000070404d1d4523  vmovaps xmm10, [rsp+0xA0]
000070404d1d452c  vmovaps xmm11, [rsp+0xB0]
000070404d1d4535  vmovaps xmm12, [rsp+0xC0]
000070404d1d453e  vmovaps xmm14, [rsp+0xD0]
000070404d1d4547  vmovaps xmm15, [rsp+0xE0]
000070404d1d4550  add rsp, 0xF0
000070404d1d4557  pop r11
000070404d1d4559  pop r10
000070404d1d455b  pop r9
000070404d1d455d  pop r8
000070404d1d455f  pop rsi
000070404d1d4560  pop rdi
000070404d1d4561  pop rdx
000070404d1d4562  pop rcx
000070404d1d4563  pop rax
000070404d1d4564  add rsp, 0x08
000070404d1d4568  jmp 0x000070404D1D34FE
000070404d1d456d  sub rsp, 0x08
000070404d1d4571  push rax
000070404d1d4572  push rcx
000070404d1d4573  push rdx
000070404d1d4574  push rdi
000070404d1d4575  push rsi
000070404d1d4576  push r8
000070404d1d4578  push r9
000070404d1d457a  push r10
000070404d1d457c  push r11
000070404d1d457e  sub rsp, 0xF0
000070404d1d4585  vmovaps [rsp], xmm0
000070404d1d458a  vmovaps [rsp+0x10], xmm1
000070404d1d4590  vmovaps [rsp+0x20], xmm2
000070404d1d4596  vmovaps [rsp+0x30], xmm3
000070404d1d459c  vmovaps [rsp+0x40], xmm4
000070404d1d45a2  vmovaps [rsp+0x50], xmm5
000070404d1d45a8  vmovaps [rsp+0x60], xmm6
000070404d1d45ae  vmovaps [rsp+0x70], xmm7
000070404d1d45b4  vmovaps [rsp+0x80], xmm8
000070404d1d45bd  vmovaps [rsp+0x90], xmm9
000070404d1d45c6  vmovaps [rsp+0xA0], xmm10
000070404d1d45cf  vmovaps [rsp+0xB0], xmm11
000070404d1d45d8  vmovaps [rsp+0xC0], xmm13
000070404d1d45e1  vmovaps [rsp+0xD0], xmm14
000070404d1d45ea  vmovaps [rsp+0xE0], xmm15
000070404d1d45f3  sub rsp, 0x40
000070404d1d45f7  lea rdi, [rsp]
000070404d1d45fb  lea rsi, [rsp+0x10]
000070404d1d4600  lea rdx, [rsp+0x20]
000070404d1d4605  lea rcx, [rsp+0x30]
000070404d1d460a  mov r8d, 0x00
000070404d1d4610  lea r9, [r15+0x3A8]
000070404d1d4617  movaps [rdi], xmm12
000070404d1d461b  movaps [rsi], xmm14
000070404d1d461f  movaps [rdx], xmm2
000070404d1d4622  movaps [rcx], xmm15
000070404d1d4626  mov rax, 0x607928F07A50
000070404d1d4630  call rax
000070404d1d4632  movaps xmm12, [rsp]
000070404d1d4637  add rsp, 0x40
000070404d1d463b  vmovaps xmm0, [rsp]
000070404d1d4640  vmovaps xmm1, [rsp+0x10]
000070404d1d4646  vmovaps xmm2, [rsp+0x20]
000070404d1d464c  vmovaps xmm3, [rsp+0x30]
000070404d1d4652  vmovaps xmm4, [rsp+0x40]
000070404d1d4658  vmovaps xmm5, [rsp+0x50]
000070404d1d465e  vmovaps xmm6, [rsp+0x60]
000070404d1d4664  vmovaps xmm7, [rsp+0x70]
000070404d1d466a  vmovaps xmm8, [rsp+0x80]
000070404d1d4673  vmovaps xmm9, [rsp+0x90]
000070404d1d467c  vmovaps xmm10, [rsp+0xA0]
000070404d1d4685  vmovaps xmm11, [rsp+0xB0]
000070404d1d468e  vmovaps xmm13, [rsp+0xC0]
000070404d1d4697  vmovaps xmm14, [rsp+0xD0]
000070404d1d46a0  vmovaps xmm15, [rsp+0xE0]
000070404d1d46a9  add rsp, 0xF0
000070404d1d46b0  pop r11
000070404d1d46b2  pop r10
000070404d1d46b4  pop r9
000070404d1d46b6  pop r8
000070404d1d46b8  pop rsi
000070404d1d46b9  pop rdi
000070404d1d46ba  pop rdx
000070404d1d46bb  pop rcx
000070404d1d46bc  pop rax
000070404d1d46bd  add rsp, 0x08
000070404d1d46c1  jmp 0x000070404D1D3558
000070404d1d46c6  sub rsp, 0x08
000070404d1d46ca  push rax
000070404d1d46cb  push rcx
000070404d1d46cc  push rdx
000070404d1d46cd  push rdi
000070404d1d46ce  push rsi
000070404d1d46cf  push r8
000070404d1d46d1  push r9
000070404d1d46d3  push r10
000070404d1d46d5  push r11
000070404d1d46d7  sub rsp, 0xF0
000070404d1d46de  vmovaps [rsp], xmm0
000070404d1d46e3  vmovaps [rsp+0x10], xmm1
000070404d1d46e9  vmovaps [rsp+0x20], xmm3
000070404d1d46ef  vmovaps [rsp+0x30], xmm4
000070404d1d46f5  vmovaps [rsp+0x40], xmm5
000070404d1d46fb  vmovaps [rsp+0x50], xmm6
000070404d1d4701  vmovaps [rsp+0x60], xmm7
000070404d1d4707  vmovaps [rsp+0x70], xmm8
000070404d1d470d  vmovaps [rsp+0x80], xmm9
000070404d1d4716  vmovaps [rsp+0x90], xmm10
000070404d1d471f  vmovaps [rsp+0xA0], xmm11
000070404d1d4728  vmovaps [rsp+0xB0], xmm12
000070404d1d4731  vmovaps [rsp+0xC0], xmm13
000070404d1d473a  vmovaps [rsp+0xD0], xmm14
000070404d1d4743  vmovaps [rsp+0xE0], xmm15
000070404d1d474c  sub rsp, 0x40
000070404d1d4750  lea rdi, [rsp]
000070404d1d4754  lea rsi, [rsp+0x10]
000070404d1d4759  lea rdx, [rsp+0x20]
000070404d1d475e  lea rcx, [rsp+0x30]
000070404d1d4763  mov r8d, 0x00
000070404d1d4769  lea r9, [r15+0x3A8]
000070404d1d4770  movaps [rdi], xmm2
000070404d1d4773  movaps [rsi], xmm14
000070404d1d4777  movaps [rdx], xmm8
000070404d1d477b  movaps [rcx], xmm5
000070404d1d477e  mov rax, 0x607928F07A50
000070404d1d4788  call rax
000070404d1d478a  movaps xmm2, [rsp]
000070404d1d478e  add rsp, 0x40
000070404d1d4792  vmovaps xmm0, [rsp]
000070404d1d4797  vmovaps xmm1, [rsp+0x10]
000070404d1d479d  vmovaps xmm3, [rsp+0x20]
000070404d1d47a3  vmovaps xmm4, [rsp+0x30]
000070404d1d47a9  vmovaps xmm5, [rsp+0x40]
000070404d1d47af  vmovaps xmm6, [rsp+0x50]
000070404d1d47b5  vmovaps xmm7, [rsp+0x60]
000070404d1d47bb  vmovaps xmm8, [rsp+0x70]
000070404d1d47c1  vmovaps xmm9, [rsp+0x80]
000070404d1d47ca  vmovaps xmm10, [rsp+0x90]
000070404d1d47d3  vmovaps xmm11, [rsp+0xA0]
000070404d1d47dc  vmovaps xmm12, [rsp+0xB0]
000070404d1d47e5  vmovaps xmm13, [rsp+0xC0]
000070404d1d47ee  vmovaps xmm14, [rsp+0xD0]
000070404d1d47f7  vmovaps xmm15, [rsp+0xE0]
000070404d1d4800  add rsp, 0xF0
000070404d1d4807  pop r11
000070404d1d4809  pop r10
000070404d1d480b  pop r9
000070404d1d480d  pop r8
000070404d1d480f  pop rsi
000070404d1d4810  pop rdi
000070404d1d4811  pop rdx
000070404d1d4812  pop rcx
000070404d1d4813  pop rax
000070404d1d4814  add rsp, 0x08
000070404d1d4818  jmp 0x000070404D1D360C
000070404d1d481d  sub rsp, 0x08
000070404d1d4821  push rax
000070404d1d4822  push rcx
000070404d1d4823  push rdx
000070404d1d4824  push rdi
000070404d1d4825  push rsi
000070404d1d4826  push r8
000070404d1d4828  push r9
000070404d1d482a  push r10
000070404d1d482c  push r11
000070404d1d482e  sub rsp, 0xF0
000070404d1d4835  vmovaps [rsp], xmm0
000070404d1d483a  vmovaps [rsp+0x10], xmm1
000070404d1d4840  vmovaps [rsp+0x20], xmm2
000070404d1d4846  vmovaps [rsp+0x30], xmm3
000070404d1d484c  vmovaps [rsp+0x40], xmm4
000070404d1d4852  vmovaps [rsp+0x50], xmm6
000070404d1d4858  vmovaps [rsp+0x60], xmm7
000070404d1d485e  vmovaps [rsp+0x70], xmm8
000070404d1d4864  vmovaps [rsp+0x80], xmm9
000070404d1d486d  vmovaps [rsp+0x90], xmm10
000070404d1d4876  vmovaps [rsp+0xA0], xmm11
000070404d1d487f  vmovaps [rsp+0xB0], xmm12
000070404d1d4888  vmovaps [rsp+0xC0], xmm13
000070404d1d4891  vmovaps [rsp+0xD0], xmm14
000070404d1d489a  vmovaps [rsp+0xE0], xmm15
000070404d1d48a3  sub rsp, 0x40
000070404d1d48a7  lea rdi, [rsp]
000070404d1d48ab  lea rsi, [rsp+0x10]
000070404d1d48b0  lea rdx, [rsp+0x20]
000070404d1d48b5  lea rcx, [rsp+0x30]
000070404d1d48ba  mov r8d, 0x00
000070404d1d48c0  lea r9, [r15+0x3A8]
000070404d1d48c7  movaps [rdi], xmm5
000070404d1d48ca  movaps [rsi], xmm14
000070404d1d48ce  movaps [rdx], xmm8
000070404d1d48d2  movaps [rcx], xmm1
000070404d1d48d5  mov rax, 0x607928F07A50
000070404d1d48df  call rax
000070404d1d48e1  movaps xmm5, [rsp]
000070404d1d48e5  add rsp, 0x40
000070404d1d48e9  vmovaps xmm0, [rsp]
000070404d1d48ee  vmovaps xmm1, [rsp+0x10]
000070404d1d48f4  vmovaps xmm2, [rsp+0x20]
000070404d1d48fa  vmovaps xmm3, [rsp+0x30]
000070404d1d4900  vmovaps xmm4, [rsp+0x40]
000070404d1d4906  vmovaps xmm6, [rsp+0x50]
000070404d1d490c  vmovaps xmm7, [rsp+0x60]
000070404d1d4912  vmovaps xmm8, [rsp+0x70]
000070404d1d4918  vmovaps xmm9, [rsp+0x80]
000070404d1d4921  vmovaps xmm10, [rsp+0x90]
000070404d1d492a  vmovaps xmm11, [rsp+0xA0]
000070404d1d4933  vmovaps xmm12, [rsp+0xB0]
000070404d1d493c  vmovaps xmm13, [rsp+0xC0]
000070404d1d4945  vmovaps xmm14, [rsp+0xD0]
000070404d1d494e  vmovaps xmm15, [rsp+0xE0]
000070404d1d4957  add rsp, 0xF0
000070404d1d495e  pop r11
000070404d1d4960  pop r10
000070404d1d4962  pop r9
000070404d1d4964  pop r8
000070404d1d4966  pop rsi
000070404d1d4967  pop rdi
000070404d1d4968  pop rdx
000070404d1d4969  pop rcx
000070404d1d496a  pop rax
000070404d1d496b  add rsp, 0x08
000070404d1d496f  jmp 0x000070404D1D3649
000070404d1d4974  sub rsp, 0x08
000070404d1d4978  push rax
000070404d1d4979  push rcx
000070404d1d497a  push rdx
000070404d1d497b  push rdi
000070404d1d497c  push rsi
000070404d1d497d  push r8
000070404d1d497f  push r9
000070404d1d4981  push r10
000070404d1d4983  push r11
000070404d1d4985  sub rsp, 0xF0
000070404d1d498c  vmovaps [rsp], xmm0
000070404d1d4991  vmovaps [rsp+0x10], xmm1
000070404d1d4997  vmovaps [rsp+0x20], xmm2
000070404d1d499d  vmovaps [rsp+0x30], xmm3
000070404d1d49a3  vmovaps [rsp+0x40], xmm4
000070404d1d49a9  vmovaps [rsp+0x50], xmm5
000070404d1d49af  vmovaps [rsp+0x60], xmm6
000070404d1d49b5  vmovaps [rsp+0x70], xmm7
000070404d1d49bb  vmovaps [rsp+0x80], xmm8
000070404d1d49c4  vmovaps [rsp+0x90], xmm9
000070404d1d49cd  vmovaps [rsp+0xA0], xmm10
000070404d1d49d6  vmovaps [rsp+0xB0], xmm11
000070404d1d49df  vmovaps [rsp+0xC0], xmm12
000070404d1d49e8  vmovaps [rsp+0xD0], xmm13
000070404d1d49f1  vmovaps [rsp+0xE0], xmm14
000070404d1d49fa  sub rsp, 0x40
000070404d1d49fe  lea rdi, [rsp]
000070404d1d4a02  lea rsi, [rsp+0x10]
000070404d1d4a07  lea rdx, [rsp+0x20]
000070404d1d4a0c  lea rcx, [rsp+0x30]
000070404d1d4a11  mov r8d, 0x00
000070404d1d4a17  lea r9, [r15+0x3A8]
000070404d1d4a1e  movaps [rdi], xmm15
000070404d1d4a22  movaps [rsi], xmm13
000070404d1d4a26  movaps [rdx], xmm14
000070404d1d4a2a  movaps [rcx], xmm1
000070404d1d4a2d  mov rax, 0x607928F07A50
000070404d1d4a37  call rax
000070404d1d4a39  movaps xmm15, [rsp]
000070404d1d4a3e  add rsp, 0x40
000070404d1d4a42  vmovaps xmm0, [rsp]
000070404d1d4a47  vmovaps xmm1, [rsp+0x10]
000070404d1d4a4d  vmovaps xmm2, [rsp+0x20]
000070404d1d4a53  vmovaps xmm3, [rsp+0x30]
000070404d1d4a59  vmovaps xmm4, [rsp+0x40]
000070404d1d4a5f  vmovaps xmm5, [rsp+0x50]
000070404d1d4a65  vmovaps xmm6, [rsp+0x60]
000070404d1d4a6b  vmovaps xmm7, [rsp+0x70]
000070404d1d4a71  vmovaps xmm8, [rsp+0x80]
000070404d1d4a7a  vmovaps xmm9, [rsp+0x90]
000070404d1d4a83  vmovaps xmm10, [rsp+0xA0]
000070404d1d4a8c  vmovaps xmm11, [rsp+0xB0]
000070404d1d4a95  vmovaps xmm12, [rsp+0xC0]
000070404d1d4a9e  vmovaps xmm13, [rsp+0xD0]
000070404d1d4aa7  vmovaps xmm14, [rsp+0xE0]
000070404d1d4ab0  add rsp, 0xF0
000070404d1d4ab7  pop r11
000070404d1d4ab9  pop r10
000070404d1d4abb  pop r9
000070404d1d4abd  pop r8
000070404d1d4abf  pop rsi
000070404d1d4ac0  pop rdi
000070404d1d4ac1  pop rdx
000070404d1d4ac2  pop rcx
000070404d1d4ac3  pop rax
000070404d1d4ac4  add rsp, 0x08
000070404d1d4ac8  jmp 0x000070404D1D3678
000070404d1d4acd  sub rsp, 0x08
000070404d1d4ad1  push rax
000070404d1d4ad2  push rcx
000070404d1d4ad3  push rdx
000070404d1d4ad4  push rdi
000070404d1d4ad5  push rsi
000070404d1d4ad6  push r8
000070404d1d4ad8  push r9
000070404d1d4ada  push r10
000070404d1d4adc  push r11
000070404d1d4ade  sub rsp, 0xF0
000070404d1d4ae5  vmovaps [rsp], xmm0
000070404d1d4aea  vmovaps [rsp+0x10], xmm1
000070404d1d4af0  vmovaps [rsp+0x20], xmm2
000070404d1d4af6  vmovaps [rsp+0x30], xmm3
000070404d1d4afc  vmovaps [rsp+0x40], xmm4
000070404d1d4b02  vmovaps [rsp+0x50], xmm5
000070404d1d4b08  vmovaps [rsp+0x60], xmm6
000070404d1d4b0e  vmovaps [rsp+0x70], xmm7
000070404d1d4b14  vmovaps [rsp+0x80], xmm8
000070404d1d4b1d  vmovaps [rsp+0x90], xmm9
000070404d1d4b26  vmovaps [rsp+0xA0], xmm10
000070404d1d4b2f  vmovaps [rsp+0xB0], xmm11
000070404d1d4b38  vmovaps [rsp+0xC0], xmm12
000070404d1d4b41  vmovaps [rsp+0xD0], xmm14
000070404d1d4b4a  vmovaps [rsp+0xE0], xmm15
000070404d1d4b53  sub rsp, 0x40
000070404d1d4b57  lea rdi, [rsp]
000070404d1d4b5b  lea rsi, [rsp+0x10]
000070404d1d4b60  lea rdx, [rsp+0x20]
000070404d1d4b65  lea rcx, [rsp+0x30]
000070404d1d4b6a  mov r8d, 0x00
000070404d1d4b70  lea r9, [r15+0x3A8]
000070404d1d4b77  movaps [rdi], xmm13
000070404d1d4b7b  movaps [rsi], xmm12
000070404d1d4b7f  movaps [rdx], xmm14
000070404d1d4b83  movaps [rcx], xmm1
000070404d1d4b86  mov rax, 0x607928F07A50
000070404d1d4b90  call rax
000070404d1d4b92  movaps xmm13, [rsp]
000070404d1d4b97  add rsp, 0x40
000070404d1d4b9b  vmovaps xmm0, [rsp]
000070404d1d4ba0  vmovaps xmm1, [rsp+0x10]
000070404d1d4ba6  vmovaps xmm2, [rsp+0x20]
000070404d1d4bac  vmovaps xmm3, [rsp+0x30]
000070404d1d4bb2  vmovaps xmm4, [rsp+0x40]
000070404d1d4bb8  vmovaps xmm5, [rsp+0x50]
000070404d1d4bbe  vmovaps xmm6, [rsp+0x60]
000070404d1d4bc4  vmovaps xmm7, [rsp+0x70]
000070404d1d4bca  vmovaps xmm8, [rsp+0x80]
000070404d1d4bd3  vmovaps xmm9, [rsp+0x90]
000070404d1d4bdc  vmovaps xmm10, [rsp+0xA0]
000070404d1d4be5  vmovaps xmm11, [rsp+0xB0]
000070404d1d4bee  vmovaps xmm12, [rsp+0xC0]
000070404d1d4bf7  vmovaps xmm14, [rsp+0xD0]
000070404d1d4c00  vmovaps xmm15, [rsp+0xE0]
000070404d1d4c09  add rsp, 0xF0
000070404d1d4c10  pop r11
000070404d1d4c12  pop r10
000070404d1d4c14  pop r9
000070404d1d4c16  pop r8
000070404d1d4c18  pop rsi
000070404d1d4c19  pop rdi
000070404d1d4c1a  pop rdx
000070404d1d4c1b  pop rcx
000070404d1d4c1c  pop rax
000070404d1d4c1d  add rsp, 0x08
000070404d1d4c21  jmp 0x000070404D1D36AA
000070404d1d4c26  sub rsp, 0x08
000070404d1d4c2a  push rax
000070404d1d4c2b  push rcx
000070404d1d4c2c  push rdx
000070404d1d4c2d  push rdi
000070404d1d4c2e  push rsi
000070404d1d4c2f  push r8
000070404d1d4c31  push r9
000070404d1d4c33  push r10
000070404d1d4c35  push r11
000070404d1d4c37  sub rsp, 0xF0
000070404d1d4c3e  vmovaps [rsp], xmm0
000070404d1d4c43  vmovaps [rsp+0x10], xmm1
000070404d1d4c49  vmovaps [rsp+0x20], xmm2
000070404d1d4c4f  vmovaps [rsp+0x30], xmm3
000070404d1d4c55  vmovaps [rsp+0x40], xmm4
000070404d1d4c5b  vmovaps [rsp+0x50], xmm5
000070404d1d4c61  vmovaps [rsp+0x60], xmm6
000070404d1d4c67  vmovaps [rsp+0x70], xmm7
000070404d1d4c6d  vmovaps [rsp+0x80], xmm8
000070404d1d4c76  vmovaps [rsp+0x90], xmm9
000070404d1d4c7f  vmovaps [rsp+0xA0], xmm10
000070404d1d4c88  vmovaps [rsp+0xB0], xmm11
000070404d1d4c91  vmovaps [rsp+0xC0], xmm13
000070404d1d4c9a  vmovaps [rsp+0xD0], xmm14
000070404d1d4ca3  vmovaps [rsp+0xE0], xmm15
000070404d1d4cac  sub rsp, 0x40
000070404d1d4cb0  lea rdi, [rsp]
000070404d1d4cb4  lea rsi, [rsp+0x10]
000070404d1d4cb9  lea rdx, [rsp+0x20]
000070404d1d4cbe  lea rcx, [rsp+0x30]
000070404d1d4cc3  mov r8d, 0x00
000070404d1d4cc9  lea r9, [r15+0x3A8]
000070404d1d4cd0  movaps [rdi], xmm12
000070404d1d4cd4  movaps [rsi], xmm5
000070404d1d4cd7  movaps [rdx], xmm14
000070404d1d4cdb  movaps [rcx], xmm4
000070404d1d4cde  mov rax, 0x607928F07A50
000070404d1d4ce8  call rax
000070404d1d4cea  movaps xmm12, [rsp]
000070404d1d4cef  add rsp, 0x40
000070404d1d4cf3  vmovaps xmm0, [rsp]
000070404d1d4cf8  vmovaps xmm1, [rsp+0x10]
000070404d1d4cfe  vmovaps xmm2, [rsp+0x20]
000070404d1d4d04  vmovaps xmm3, [rsp+0x30]
000070404d1d4d0a  vmovaps xmm4, [rsp+0x40]
000070404d1d4d10  vmovaps xmm5, [rsp+0x50]
000070404d1d4d16  vmovaps xmm6, [rsp+0x60]
000070404d1d4d1c  vmovaps xmm7, [rsp+0x70]
000070404d1d4d22  vmovaps xmm8, [rsp+0x80]
000070404d1d4d2b  vmovaps xmm9, [rsp+0x90]
000070404d1d4d34  vmovaps xmm10, [rsp+0xA0]
000070404d1d4d3d  vmovaps xmm11, [rsp+0xB0]
000070404d1d4d46  vmovaps xmm13, [rsp+0xC0]
000070404d1d4d4f  vmovaps xmm14, [rsp+0xD0]
000070404d1d4d58  vmovaps xmm15, [rsp+0xE0]
000070404d1d4d61  add rsp, 0xF0
000070404d1d4d68  pop r11
000070404d1d4d6a  pop r10
000070404d1d4d6c  pop r9
000070404d1d4d6e  pop r8
000070404d1d4d70  pop rsi
000070404d1d4d71  pop rdi
000070404d1d4d72  pop rdx
000070404d1d4d73  pop rcx
000070404d1d4d74  pop rax
000070404d1d4d75  add rsp, 0x08
000070404d1d4d79  jmp 0x000070404D1D3720
000070404d1d4d7e  sub rsp, 0x08
000070404d1d4d82  push rax
000070404d1d4d83  push rcx
000070404d1d4d84  push rdx
000070404d1d4d85  push rdi
000070404d1d4d86  push rsi
000070404d1d4d87  push r8
000070404d1d4d89  push r9
000070404d1d4d8b  push r10
000070404d1d4d8d  push r11
000070404d1d4d8f  sub rsp, 0xF0
000070404d1d4d96  vmovaps [rsp], xmm0
000070404d1d4d9b  vmovaps [rsp+0x10], xmm1
000070404d1d4da1  vmovaps [rsp+0x20], xmm2
000070404d1d4da7  vmovaps [rsp+0x30], xmm3
000070404d1d4dad  vmovaps [rsp+0x40], xmm4
000070404d1d4db3  vmovaps [rsp+0x50], xmm5
000070404d1d4db9  vmovaps [rsp+0x60], xmm6
000070404d1d4dbf  vmovaps [rsp+0x70], xmm7
000070404d1d4dc5  vmovaps [rsp+0x80], xmm8
000070404d1d4dce  vmovaps [rsp+0x90], xmm9
000070404d1d4dd7  vmovaps [rsp+0xA0], xmm11
000070404d1d4de0  vmovaps [rsp+0xB0], xmm12
000070404d1d4de9  vmovaps [rsp+0xC0], xmm13
000070404d1d4df2  vmovaps [rsp+0xD0], xmm14
000070404d1d4dfb  vmovaps [rsp+0xE0], xmm15
000070404d1d4e04  sub rsp, 0x40
000070404d1d4e08  lea rdi, [rsp]
000070404d1d4e0c  lea rsi, [rsp+0x10]
000070404d1d4e11  lea rdx, [rsp+0x20]
000070404d1d4e16  lea rcx, [rsp+0x30]
000070404d1d4e1b  mov r8d, 0x00
000070404d1d4e21  lea r9, [r15+0x3A8]
000070404d1d4e28  movaps [rdi], xmm10
000070404d1d4e2c  movaps [rsi], xmm2
000070404d1d4e2f  movaps [rdx], xmm6
000070404d1d4e32  movaps [rcx], xmm14
000070404d1d4e36  mov rax, 0x607928F07A50
000070404d1d4e40  call rax
000070404d1d4e42  movaps xmm10, [rsp]
000070404d1d4e47  add rsp, 0x40
000070404d1d4e4b  vmovaps xmm0, [rsp]
000070404d1d4e50  vmovaps xmm1, [rsp+0x10]
000070404d1d4e56  vmovaps xmm2, [rsp+0x20]
000070404d1d4e5c  vmovaps xmm3, [rsp+0x30]
000070404d1d4e62  vmovaps xmm4, [rsp+0x40]
000070404d1d4e68  vmovaps xmm5, [rsp+0x50]
000070404d1d4e6e  vmovaps xmm6, [rsp+0x60]
000070404d1d4e74  vmovaps xmm7, [rsp+0x70]
000070404d1d4e7a  vmovaps xmm8, [rsp+0x80]
000070404d1d4e83  vmovaps xmm9, [rsp+0x90]
000070404d1d4e8c  vmovaps xmm11, [rsp+0xA0]
000070404d1d4e95  vmovaps xmm12, [rsp+0xB0]
000070404d1d4e9e  vmovaps xmm13, [rsp+0xC0]
000070404d1d4ea7  vmovaps xmm14, [rsp+0xD0]
000070404d1d4eb0  vmovaps xmm15, [rsp+0xE0]
000070404d1d4eb9  add rsp, 0xF0
000070404d1d4ec0  pop r11
000070404d1d4ec2  pop r10
000070404d1d4ec4  pop r9
000070404d1d4ec6  pop r8
000070404d1d4ec8  pop rsi
000070404d1d4ec9  pop rdi
000070404d1d4eca  pop rdx
000070404d1d4ecb  pop rcx
000070404d1d4ecc  pop rax
000070404d1d4ecd  add rsp, 0x08
000070404d1d4ed1  jmp 0x000070404D1D3746
000070404d1d4ed6  call 0x000070404D0E45A0
000070404d1d4edb  jmp 0x000070404D1D3753
000070404d1d4ee0  sub rsp, 0x08
000070404d1d4ee4  push rax
000070404d1d4ee5  push rcx
000070404d1d4ee6  push rdx
000070404d1d4ee7  push rdi
000070404d1d4ee8  push rsi
000070404d1d4ee9  push r8
000070404d1d4eeb  push r9
000070404d1d4eed  push r10
000070404d1d4eef  push r11
000070404d1d4ef1  sub rsp, 0xF0
000070404d1d4ef8  vmovaps [rsp], xmm0
000070404d1d4efd  vmovaps [rsp+0x10], xmm1
000070404d1d4f03  vmovaps [rsp+0x20], xmm2
000070404d1d4f09  vmovaps [rsp+0x30], xmm3
000070404d1d4f0f  vmovaps [rsp+0x40], xmm4
000070404d1d4f15  vmovaps [rsp+0x50], xmm6
000070404d1d4f1b  vmovaps [rsp+0x60], xmm7
000070404d1d4f21  vmovaps [rsp+0x70], xmm8
000070404d1d4f27  vmovaps [rsp+0x80], xmm9
000070404d1d4f30  vmovaps [rsp+0x90], xmm10
000070404d1d4f39  vmovaps [rsp+0xA0], xmm11
000070404d1d4f42  vmovaps [rsp+0xB0], xmm12
000070404d1d4f4b  vmovaps [rsp+0xC0], xmm13
000070404d1d4f54  vmovaps [rsp+0xD0], xmm14
000070404d1d4f5d  vmovaps [rsp+0xE0], xmm15
000070404d1d4f66  sub rsp, 0x40
000070404d1d4f6a  lea rdi, [rsp]
000070404d1d4f6e  lea rsi, [rsp+0x10]
000070404d1d4f73  lea rdx, [rsp+0x20]
000070404d1d4f78  lea rcx, [rsp+0x30]
000070404d1d4f7d  mov r8d, 0x00
000070404d1d4f83  lea r9, [r15+0x3A8]
000070404d1d4f8a  movaps [rdi], xmm5
000070404d1d4f8d  movaps [rsi], xmm15
000070404d1d4f91  movaps [rdx], xmm6
000070404d1d4f94  movaps [rcx], xmm8
000070404d1d4f98  mov rax, 0x607928F07A50
000070404d1d4fa2  call rax
000070404d1d4fa4  movaps xmm5, [rsp]
000070404d1d4fa8  add rsp, 0x40
000070404d1d4fac  vmovaps xmm0, [rsp]
000070404d1d4fb1  vmovaps xmm1, [rsp+0x10]
000070404d1d4fb7  vmovaps xmm2, [rsp+0x20]
000070404d1d4fbd  vmovaps xmm3, [rsp+0x30]
000070404d1d4fc3  vmovaps xmm4, [rsp+0x40]
000070404d1d4fc9  vmovaps xmm6, [rsp+0x50]
000070404d1d4fcf  vmovaps xmm7, [rsp+0x60]
000070404d1d4fd5  vmovaps xmm8, [rsp+0x70]
000070404d1d4fdb  vmovaps xmm9, [rsp+0x80]
000070404d1d4fe4  vmovaps xmm10, [rsp+0x90]
000070404d1d4fed  vmovaps xmm11, [rsp+0xA0]
000070404d1d4ff6  vmovaps xmm12, [rsp+0xB0]
000070404d1d4fff  vmovaps xmm13, [rsp+0xC0]
000070404d1d5008  vmovaps xmm14, [rsp+0xD0]
000070404d1d5011  vmovaps xmm15, [rsp+0xE0]
000070404d1d501a  add rsp, 0xF0
000070404d1d5021  pop r11
000070404d1d5023  pop r10
000070404d1d5025  pop r9
000070404d1d5027  pop r8
000070404d1d5029  pop rsi
000070404d1d502a  pop rdi
000070404d1d502b  pop rdx
000070404d1d502c  pop rcx
000070404d1d502d  pop rax
000070404d1d502e  add rsp, 0x08
000070404d1d5032  jmp 0x000070404D1D3789
000070404d1d5037  sub rsp, 0x08
000070404d1d503b  push rax
000070404d1d503c  push rcx
000070404d1d503d  push rdx
000070404d1d503e  push rdi
000070404d1d503f  push rsi
000070404d1d5040  push r8
000070404d1d5042  push r9
000070404d1d5044  push r10
000070404d1d5046  push r11
000070404d1d5048  sub rsp, 0xF0
000070404d1d504f  vmovaps [rsp], xmm0
000070404d1d5054  vmovaps [rsp+0x10], xmm1
000070404d1d505a  vmovaps [rsp+0x20], xmm2
000070404d1d5060  vmovaps [rsp+0x30], xmm3
000070404d1d5066  vmovaps [rsp+0x40], xmm4
000070404d1d506c  vmovaps [rsp+0x50], xmm5
000070404d1d5072  vmovaps [rsp+0x60], xmm6
000070404d1d5078  vmovaps [rsp+0x70], xmm7
000070404d1d507e  vmovaps [rsp+0x80], xmm9
000070404d1d5087  vmovaps [rsp+0x90], xmm10
000070404d1d5090  vmovaps [rsp+0xA0], xmm11
000070404d1d5099  vmovaps [rsp+0xB0], xmm12
000070404d1d50a2  vmovaps [rsp+0xC0], xmm13
000070404d1d50ab  vmovaps [rsp+0xD0], xmm14
000070404d1d50b4  vmovaps [rsp+0xE0], xmm15
000070404d1d50bd  sub rsp, 0x40
000070404d1d50c1  lea rdi, [rsp]
000070404d1d50c5  lea rsi, [rsp+0x10]
000070404d1d50ca  lea rdx, [rsp+0x20]
000070404d1d50cf  lea rcx, [rsp+0x30]
000070404d1d50d4  mov r8d, 0x00
000070404d1d50da  lea r9, [r15+0x3A8]
000070404d1d50e1  movaps [rdi], xmm8
000070404d1d50e5  movaps [rsi], xmm13
000070404d1d50e9  movaps [rdx], xmm1
000070404d1d50ec  movaps [rcx], xmm15
000070404d1d50f0  mov rax, 0x607928F07A50
000070404d1d50fa  call rax
000070404d1d50fc  movaps xmm8, [rsp]
000070404d1d5101  add rsp, 0x40
000070404d1d5105  vmovaps xmm0, [rsp]
000070404d1d510a  vmovaps xmm1, [rsp+0x10]
000070404d1d5110  vmovaps xmm2, [rsp+0x20]
000070404d1d5116  vmovaps xmm3, [rsp+0x30]
000070404d1d511c  vmovaps xmm4, [rsp+0x40]
000070404d1d5122  vmovaps xmm5, [rsp+0x50]
000070404d1d5128  vmovaps xmm6, [rsp+0x60]
000070404d1d512e  vmovaps xmm7, [rsp+0x70]
000070404d1d5134  vmovaps xmm9, [rsp+0x80]
000070404d1d513d  vmovaps xmm10, [rsp+0x90]
000070404d1d5146  vmovaps xmm11, [rsp+0xA0]
000070404d1d514f  vmovaps xmm12, [rsp+0xB0]
000070404d1d5158  vmovaps xmm13, [rsp+0xC0]
000070404d1d5161  vmovaps xmm14, [rsp+0xD0]
000070404d1d516a  vmovaps xmm15, [rsp+0xE0]
000070404d1d5173  add rsp, 0xF0
000070404d1d517a  pop r11
000070404d1d517c  pop r10
000070404d1d517e  pop r9
000070404d1d5180  pop r8
000070404d1d5182  pop rsi
000070404d1d5183  pop rdi
000070404d1d5184  pop rdx
000070404d1d5185  pop rcx
000070404d1d5186  pop rax
000070404d1d5187  add rsp, 0x08
000070404d1d518b  jmp 0x000070404D1D37AF
000070404d1d5190  call 0x000070404D0E5820
000070404d1d5195  jmp 0x000070404D1D37D2
000070404d1d519a  call 0x000070404D0E3320
000070404d1d519f  jmp 0x000070404D1D37DC
000070404d1d51a4  sub rsp, 0x08
000070404d1d51a8  push rax
000070404d1d51a9  push rcx
000070404d1d51aa  push rdx
000070404d1d51ab  push rdi
000070404d1d51ac  push rsi
000070404d1d51ad  push r8
000070404d1d51af  push r9
000070404d1d51b1  push r10
000070404d1d51b3  push r11
000070404d1d51b5  sub rsp, 0xF0
000070404d1d51bc  vmovaps [rsp], xmm0
000070404d1d51c1  vmovaps [rsp+0x10], xmm1
000070404d1d51c7  vmovaps [rsp+0x20], xmm2
000070404d1d51cd  vmovaps [rsp+0x30], xmm3
000070404d1d51d3  vmovaps [rsp+0x40], xmm5
000070404d1d51d9  vmovaps [rsp+0x50], xmm6
000070404d1d51df  vmovaps [rsp+0x60], xmm7
000070404d1d51e5  vmovaps [rsp+0x70], xmm8
000070404d1d51eb  vmovaps [rsp+0x80], xmm9
000070404d1d51f4  vmovaps [rsp+0x90], xmm10
000070404d1d51fd  vmovaps [rsp+0xA0], xmm11
000070404d1d5206  vmovaps [rsp+0xB0], xmm12
000070404d1d520f  vmovaps [rsp+0xC0], xmm13
000070404d1d5218  vmovaps [rsp+0xD0], xmm14
000070404d1d5221  vmovaps [rsp+0xE0], xmm15
000070404d1d522a  sub rsp, 0x40
000070404d1d522e  lea rdi, [rsp]
000070404d1d5232  lea rsi, [rsp+0x10]
000070404d1d5237  lea rdx, [rsp+0x20]
000070404d1d523c  lea rcx, [rsp+0x30]
000070404d1d5241  mov r8d, 0x00
000070404d1d5247  lea r9, [r15+0x3A8]
000070404d1d524e  movaps [rdi], xmm4
000070404d1d5251  movaps [rsi], xmm12
000070404d1d5255  movaps [rdx], xmm9
000070404d1d5259  movaps [rcx], xmm6
000070404d1d525c  mov rax, 0x607928F07A50
000070404d1d5266  call rax
000070404d1d5268  movaps xmm4, [rsp]
000070404d1d526c  add rsp, 0x40
000070404d1d5270  vmovaps xmm0, [rsp]
000070404d1d5275  vmovaps xmm1, [rsp+0x10]
000070404d1d527b  vmovaps xmm2, [rsp+0x20]
000070404d1d5281  vmovaps xmm3, [rsp+0x30]
000070404d1d5287  vmovaps xmm5, [rsp+0x40]
000070404d1d528d  vmovaps xmm6, [rsp+0x50]
000070404d1d5293  vmovaps xmm7, [rsp+0x60]
000070404d1d5299  vmovaps xmm8, [rsp+0x70]
000070404d1d529f  vmovaps xmm9, [rsp+0x80]
000070404d1d52a8  vmovaps xmm10, [rsp+0x90]
000070404d1d52b1  vmovaps xmm11, [rsp+0xA0]
000070404d1d52ba  vmovaps xmm12, [rsp+0xB0]
000070404d1d52c3  vmovaps xmm13, [rsp+0xC0]
000070404d1d52cc  vmovaps xmm14, [rsp+0xD0]
000070404d1d52d5  vmovaps xmm15, [rsp+0xE0]
000070404d1d52de  add rsp, 0xF0
000070404d1d52e5  pop r11
000070404d1d52e7  pop r10
000070404d1d52e9  pop r9
000070404d1d52eb  pop r8
000070404d1d52ed  pop rsi
000070404d1d52ee  pop rdi
000070404d1d52ef  pop rdx
000070404d1d52f0  pop rcx
000070404d1d52f1  pop rax
000070404d1d52f2  add rsp, 0x08
000070404d1d52f6  jmp 0x000070404D1D3814
000070404d1d52fb  sub rsp, 0x08
000070404d1d52ff  push rax
000070404d1d5300  push rcx
000070404d1d5301  push rdx
000070404d1d5302  push rdi
000070404d1d5303  push rsi
000070404d1d5304  push r8
000070404d1d5306  push r9
000070404d1d5308  push r10
000070404d1d530a  push r11
000070404d1d530c  sub rsp, 0xF0
000070404d1d5313  vmovaps [rsp], xmm0
000070404d1d5318  vmovaps [rsp+0x10], xmm1
000070404d1d531e  vmovaps [rsp+0x20], xmm2
000070404d1d5324  vmovaps [rsp+0x30], xmm3
000070404d1d532a  vmovaps [rsp+0x40], xmm4
000070404d1d5330  vmovaps [rsp+0x50], xmm5
000070404d1d5336  vmovaps [rsp+0x60], xmm6
000070404d1d533c  vmovaps [rsp+0x70], xmm7
000070404d1d5342  vmovaps [rsp+0x80], xmm8
000070404d1d534b  vmovaps [rsp+0x90], xmm10
000070404d1d5354  vmovaps [rsp+0xA0], xmm11
000070404d1d535d  vmovaps [rsp+0xB0], xmm12
000070404d1d5366  vmovaps [rsp+0xC0], xmm13
000070404d1d536f  vmovaps [rsp+0xD0], xmm14
000070404d1d5378  vmovaps [rsp+0xE0], xmm15
000070404d1d5381  sub rsp, 0x40
000070404d1d5385  lea rdi, [rsp]
000070404d1d5389  lea rsi, [rsp+0x10]
000070404d1d538e  lea rdx, [rsp+0x20]
000070404d1d5393  lea rcx, [rsp+0x30]
000070404d1d5398  mov r8d, 0x00
000070404d1d539e  lea r9, [r15+0x3A8]
000070404d1d53a5  movaps [rdi], xmm9
000070404d1d53a9  movaps [rsi], xmm10
000070404d1d53ad  movaps [rdx], xmm1
000070404d1d53b0  movaps [rcx], xmm12
000070404d1d53b4  mov rax, 0x607928F07A50
000070404d1d53be  call rax
000070404d1d53c0  movaps xmm9, [rsp]
000070404d1d53c5  add rsp, 0x40
000070404d1d53c9  vmovaps xmm0, [rsp]
000070404d1d53ce  vmovaps xmm1, [rsp+0x10]
000070404d1d53d4  vmovaps xmm2, [rsp+0x20]
000070404d1d53da  vmovaps xmm3, [rsp+0x30]
000070404d1d53e0  vmovaps xmm4, [rsp+0x40]
000070404d1d53e6  vmovaps xmm5, [rsp+0x50]
000070404d1d53ec  vmovaps xmm6, [rsp+0x60]
000070404d1d53f2  vmovaps xmm7, [rsp+0x70]
000070404d1d53f8  vmovaps xmm8, [rsp+0x80]
000070404d1d5401  vmovaps xmm10, [rsp+0x90]
000070404d1d540a  vmovaps xmm11, [rsp+0xA0]
000070404d1d5413  vmovaps xmm12, [rsp+0xB0]
000070404d1d541c  vmovaps xmm13, [rsp+0xC0]
000070404d1d5425  vmovaps xmm14, [rsp+0xD0]
000070404d1d542e  vmovaps xmm15, [rsp+0xE0]
000070404d1d5437  add rsp, 0xF0
000070404d1d543e  pop r11
000070404d1d5440  pop r10
000070404d1d5442  pop r9
000070404d1d5444  pop r8
000070404d1d5446  pop rsi
000070404d1d5447  pop rdi
000070404d1d5448  pop rdx
000070404d1d5449  pop rcx
000070404d1d544a  pop rax
000070404d1d544b  add rsp, 0x08
000070404d1d544f  jmp 0x000070404D1D383D
000070404d1d5454  sub rsp, 0x08
000070404d1d5458  push rax
000070404d1d5459  push rcx
000070404d1d545a  push rdx
000070404d1d545b  push rdi
000070404d1d545c  push rsi
000070404d1d545d  push r8
000070404d1d545f  push r9
000070404d1d5461  push r10
000070404d1d5463  push r11
000070404d1d5465  sub rsp, 0xF0
000070404d1d546c  vmovaps [rsp], xmm0
000070404d1d5471  vmovaps [rsp+0x10], xmm1
000070404d1d5477  vmovaps [rsp+0x20], xmm2
000070404d1d547d  vmovaps [rsp+0x30], xmm3
000070404d1d5483  vmovaps [rsp+0x40], xmm4
000070404d1d5489  vmovaps [rsp+0x50], xmm5
000070404d1d548f  vmovaps [rsp+0x60], xmm6
000070404d1d5495  vmovaps [rsp+0x70], xmm7
000070404d1d549b  vmovaps [rsp+0x80], xmm8
000070404d1d54a4  vmovaps [rsp+0x90], xmm9
000070404d1d54ad  vmovaps [rsp+0xA0], xmm11
000070404d1d54b6  vmovaps [rsp+0xB0], xmm12
000070404d1d54bf  vmovaps [rsp+0xC0], xmm13
000070404d1d54c8  vmovaps [rsp+0xD0], xmm14
000070404d1d54d1  vmovaps [rsp+0xE0], xmm15
000070404d1d54da  sub rsp, 0x40
000070404d1d54de  lea rdi, [rsp]
000070404d1d54e2  lea rsi, [rsp+0x10]
000070404d1d54e7  lea rdx, [rsp+0x20]
000070404d1d54ec  lea rcx, [rsp+0x30]
000070404d1d54f1  mov r8d, 0x00
000070404d1d54f7  lea r9, [r15+0x3A8]
000070404d1d54fe  movaps [rdi], xmm10
000070404d1d5502  movaps [rsi], xmm5
000070404d1d5505  movaps [rdx], xmm12
000070404d1d5509  movaps [rcx], xmm1
000070404d1d550c  mov rax, 0x607928F07A50
000070404d1d5516  call rax
000070404d1d5518  movaps xmm10, [rsp]
000070404d1d551d  add rsp, 0x40
000070404d1d5521  vmovaps xmm0, [rsp]
000070404d1d5526  vmovaps xmm1, [rsp+0x10]
000070404d1d552c  vmovaps xmm2, [rsp+0x20]
000070404d1d5532  vmovaps xmm3, [rsp+0x30]
000070404d1d5538  vmovaps xmm4, [rsp+0x40]
000070404d1d553e  vmovaps xmm5, [rsp+0x50]
000070404d1d5544  vmovaps xmm6, [rsp+0x60]
000070404d1d554a  vmovaps xmm7, [rsp+0x70]
000070404d1d5550  vmovaps xmm8, [rsp+0x80]
000070404d1d5559  vmovaps xmm9, [rsp+0x90]
000070404d1d5562  vmovaps xmm11, [rsp+0xA0]
000070404d1d556b  vmovaps xmm12, [rsp+0xB0]
000070404d1d5574  vmovaps xmm13, [rsp+0xC0]
000070404d1d557d  vmovaps xmm14, [rsp+0xD0]
000070404d1d5586  vmovaps xmm15, [rsp+0xE0]
000070404d1d558f  add rsp, 0xF0
000070404d1d5596  pop r11
000070404d1d5598  pop r10
000070404d1d559a  pop r9
000070404d1d559c  pop r8
000070404d1d559e  pop rsi
000070404d1d559f  pop rdi
000070404d1d55a0  pop rdx
000070404d1d55a1  pop rcx
000070404d1d55a2  pop rax
000070404d1d55a3  add rsp, 0x08
000070404d1d55a7  jmp 0x000070404D1D386C
000070404d1d55ac  sub rsp, 0x08
000070404d1d55b0  push rax
000070404d1d55b1  push rcx
000070404d1d55b2  push rdx
000070404d1d55b3  push rdi
000070404d1d55b4  push rsi
000070404d1d55b5  push r8
000070404d1d55b7  push r9
000070404d1d55b9  push r10
000070404d1d55bb  push r11
000070404d1d55bd  sub rsp, 0xF0
000070404d1d55c4  vmovaps [rsp], xmm0
000070404d1d55c9  vmovaps [rsp+0x10], xmm1
000070404d1d55cf  vmovaps [rsp+0x20], xmm2
000070404d1d55d5  vmovaps [rsp+0x30], xmm3
000070404d1d55db  vmovaps [rsp+0x40], xmm4
000070404d1d55e1  vmovaps [rsp+0x50], xmm5
000070404d1d55e7  vmovaps [rsp+0x60], xmm7
000070404d1d55ed  vmovaps [rsp+0x70], xmm8
000070404d1d55f3  vmovaps [rsp+0x80], xmm9
000070404d1d55fc  vmovaps [rsp+0x90], xmm10
000070404d1d5605  vmovaps [rsp+0xA0], xmm11
000070404d1d560e  vmovaps [rsp+0xB0], xmm12
000070404d1d5617  vmovaps [rsp+0xC0], xmm13
000070404d1d5620  vmovaps [rsp+0xD0], xmm14
000070404d1d5629  vmovaps [rsp+0xE0], xmm15
000070404d1d5632  sub rsp, 0x40
000070404d1d5636  lea rdi, [rsp]
000070404d1d563a  lea rsi, [rsp+0x10]
000070404d1d563f  lea rdx, [rsp+0x20]
000070404d1d5644  lea rcx, [rsp+0x30]
000070404d1d5649  mov r8d, 0x00
000070404d1d564f  lea r9, [r15+0x3A8]
000070404d1d5656  movaps [rdi], xmm6
000070404d1d5659  movaps [rsi], xmm8
000070404d1d565d  movaps [rdx], xmm12
000070404d1d5661  movaps [rcx], xmm1
000070404d1d5664  mov rax, 0x607928F07A50
000070404d1d566e  call rax
000070404d1d5670  movaps xmm6, [rsp]
000070404d1d5674  add rsp, 0x40
000070404d1d5678  vmovaps xmm0, [rsp]
000070404d1d567d  vmovaps xmm1, [rsp+0x10]
000070404d1d5683  vmovaps xmm2, [rsp+0x20]
000070404d1d5689  vmovaps xmm3, [rsp+0x30]
000070404d1d568f  vmovaps xmm4, [rsp+0x40]
000070404d1d5695  vmovaps xmm5, [rsp+0x50]
000070404d1d569b  vmovaps xmm7, [rsp+0x60]
000070404d1d56a1  vmovaps xmm8, [rsp+0x70]
000070404d1d56a7  vmovaps xmm9, [rsp+0x80]
000070404d1d56b0  vmovaps xmm10, [rsp+0x90]
000070404d1d56b9  vmovaps xmm11, [rsp+0xA0]
000070404d1d56c2  vmovaps xmm12, [rsp+0xB0]
000070404d1d56cb  vmovaps xmm13, [rsp+0xC0]
000070404d1d56d4  vmovaps xmm14, [rsp+0xD0]
000070404d1d56dd  vmovaps xmm15, [rsp+0xE0]
000070404d1d56e6  add rsp, 0xF0
000070404d1d56ed  pop r11
000070404d1d56ef  pop r10
000070404d1d56f1  pop r9
000070404d1d56f3  pop r8
000070404d1d56f5  pop rsi
000070404d1d56f6  pop rdi
000070404d1d56f7  pop rdx
000070404d1d56f8  pop rcx
000070404d1d56f9  pop rax
000070404d1d56fa  add rsp, 0x08
000070404d1d56fe  jmp 0x000070404D1D389A
000070404d1d5703  call 0x000070404D0D64F0
000070404d1d5708  jmp 0x000070404D1D38A4
000070404d1d570d  call 0x000070404D0E20A0
000070404d1d5712  jmp 0x000070404D1D38AE
000070404d1d5717  sub rsp, 0x08
000070404d1d571b  push rax
000070404d1d571c  push rcx
000070404d1d571d  push rdx
000070404d1d571e  push rdi
000070404d1d571f  push rsi
000070404d1d5720  push r8
000070404d1d5722  push r9
000070404d1d5724  push r10
000070404d1d5726  push r11
000070404d1d5728  sub rsp, 0xF0
000070404d1d572f  vmovaps [rsp], xmm0
000070404d1d5734  vmovaps [rsp+0x10], xmm1
000070404d1d573a  vmovaps [rsp+0x20], xmm2
000070404d1d5740  vmovaps [rsp+0x30], xmm3
000070404d1d5746  vmovaps [rsp+0x40], xmm4
000070404d1d574c  vmovaps [rsp+0x50], xmm5
000070404d1d5752  vmovaps [rsp+0x60], xmm6
000070404d1d5758  vmovaps [rsp+0x70], xmm7
000070404d1d575e  vmovaps [rsp+0x80], xmm9
000070404d1d5767  vmovaps [rsp+0x90], xmm10
000070404d1d5770  vmovaps [rsp+0xA0], xmm11
000070404d1d5779  vmovaps [rsp+0xB0], xmm12
000070404d1d5782  vmovaps [rsp+0xC0], xmm13
000070404d1d578b  vmovaps [rsp+0xD0], xmm14
000070404d1d5794  vmovaps [rsp+0xE0], xmm15
000070404d1d579d  sub rsp, 0x40
000070404d1d57a1  lea rdi, [rsp]
000070404d1d57a5  lea rsi, [rsp+0x10]
000070404d1d57aa  lea rdx, [rsp+0x20]
000070404d1d57af  lea rcx, [rsp+0x30]
000070404d1d57b4  mov r8d, 0x00
000070404d1d57ba  lea r9, [r15+0x3A8]
000070404d1d57c1  movaps [rdi], xmm8
000070404d1d57c5  movaps [rsi], xmm4
000070404d1d57c8  movaps [rdx], xmm13
000070404d1d57cc  movaps [rcx], xmm11
000070404d1d57d0  mov rax, 0x607928F07A50
000070404d1d57da  call rax
000070404d1d57dc  movaps xmm8, [rsp]
000070404d1d57e1  add rsp, 0x40
000070404d1d57e5  vmovaps xmm0, [rsp]
000070404d1d57ea  vmovaps xmm1, [rsp+0x10]
000070404d1d57f0  vmovaps xmm2, [rsp+0x20]
000070404d1d57f6  vmovaps xmm3, [rsp+0x30]
000070404d1d57fc  vmovaps xmm4, [rsp+0x40]
000070404d1d5802  vmovaps xmm5, [rsp+0x50]
000070404d1d5808  vmovaps xmm6, [rsp+0x60]
000070404d1d580e  vmovaps xmm7, [rsp+0x70]
000070404d1d5814  vmovaps xmm9, [rsp+0x80]
000070404d1d581d  vmovaps xmm10, [rsp+0x90]
000070404d1d5826  vmovaps xmm11, [rsp+0xA0]
000070404d1d582f  vmovaps xmm12, [rsp+0xB0]
000070404d1d5838  vmovaps xmm13, [rsp+0xC0]
000070404d1d5841  vmovaps xmm14, [rsp+0xD0]
000070404d1d584a  vmovaps xmm15, [rsp+0xE0]
000070404d1d5853  add rsp, 0xF0
000070404d1d585a  pop r11
000070404d1d585c  pop r10
000070404d1d585e  pop r9
000070404d1d5860  pop r8
000070404d1d5862  pop rsi
000070404d1d5863  pop rdi
000070404d1d5864  pop rdx
000070404d1d5865  pop rcx
000070404d1d5866  pop rax
000070404d1d5867  add rsp, 0x08
000070404d1d586b  jmp 0x000070404D1D38E4
000070404d1d5870  sub rsp, 0x08
000070404d1d5874  push rax
000070404d1d5875  push rcx
000070404d1d5876  push rdx
000070404d1d5877  push rdi
000070404d1d5878  push rsi
000070404d1d5879  push r8
000070404d1d587b  push r9
000070404d1d587d  push r10
000070404d1d587f  push r11
000070404d1d5881  sub rsp, 0xF0
000070404d1d5888  vmovaps [rsp], xmm0
000070404d1d588d  vmovaps [rsp+0x10], xmm1
000070404d1d5893  vmovaps [rsp+0x20], xmm2
000070404d1d5899  vmovaps [rsp+0x30], xmm3
000070404d1d589f  vmovaps [rsp+0x40], xmm4
000070404d1d58a5  vmovaps [rsp+0x50], xmm5
000070404d1d58ab  vmovaps [rsp+0x60], xmm6
000070404d1d58b1  vmovaps [rsp+0x70], xmm7
000070404d1d58b7  vmovaps [rsp+0x80], xmm8
000070404d1d58c0  vmovaps [rsp+0x90], xmm9
000070404d1d58c9  vmovaps [rsp+0xA0], xmm10
000070404d1d58d2  vmovaps [rsp+0xB0], xmm12
000070404d1d58db  vmovaps [rsp+0xC0], xmm13
000070404d1d58e4  vmovaps [rsp+0xD0], xmm14
000070404d1d58ed  vmovaps [rsp+0xE0], xmm15
000070404d1d58f6  sub rsp, 0x40
000070404d1d58fa  lea rdi, [rsp]
000070404d1d58fe  lea rsi, [rsp+0x10]
000070404d1d5903  lea rdx, [rsp+0x20]
000070404d1d5908  lea rcx, [rsp+0x30]
000070404d1d590d  mov r8d, 0x00
000070404d1d5913  lea r9, [r15+0x3A8]
000070404d1d591a  movaps [rdi], xmm11
000070404d1d591e  movaps [rsi], xmm9
000070404d1d5922  movaps [rdx], xmm1
000070404d1d5925  movaps [rcx], xmm13
000070404d1d5929  mov rax, 0x607928F07A50
000070404d1d5933  call rax
000070404d1d5935  movaps xmm11, [rsp]
000070404d1d593a  add rsp, 0x40
000070404d1d593e  vmovaps xmm0, [rsp]
000070404d1d5943  vmovaps xmm1, [rsp+0x10]
000070404d1d5949  vmovaps xmm2, [rsp+0x20]
000070404d1d594f  vmovaps xmm3, [rsp+0x30]
000070404d1d5955  vmovaps xmm4, [rsp+0x40]
000070404d1d595b  vmovaps xmm5, [rsp+0x50]
000070404d1d5961  vmovaps xmm6, [rsp+0x60]
000070404d1d5967  vmovaps xmm7, [rsp+0x70]
000070404d1d596d  vmovaps xmm8, [rsp+0x80]
000070404d1d5976  vmovaps xmm9, [rsp+0x90]
000070404d1d597f  vmovaps xmm10, [rsp+0xA0]
000070404d1d5988  vmovaps xmm12, [rsp+0xB0]
000070404d1d5991  vmovaps xmm13, [rsp+0xC0]
000070404d1d599a  vmovaps xmm14, [rsp+0xD0]
000070404d1d59a3  vmovaps xmm15, [rsp+0xE0]
000070404d1d59ac  add rsp, 0xF0
000070404d1d59b3  pop r11
000070404d1d59b5  pop r10
000070404d1d59b7  pop r9
000070404d1d59b9  pop r8
000070404d1d59bb  pop rsi
000070404d1d59bc  pop rdi
000070404d1d59bd  pop rdx
000070404d1d59be  pop rcx
000070404d1d59bf  pop rax
000070404d1d59c0  add rsp, 0x08
000070404d1d59c4  jmp 0x000070404D1D390A
000070404d1d59c9  sub rsp, 0x08
000070404d1d59cd  push rax
000070404d1d59ce  push rcx
000070404d1d59cf  push rdx
000070404d1d59d0  push rdi
000070404d1d59d1  push rsi
000070404d1d59d2  push r8
000070404d1d59d4  push r9
000070404d1d59d6  push r10
000070404d1d59d8  push r11
000070404d1d59da  sub rsp, 0xF0
000070404d1d59e1  vmovaps [rsp], xmm0
000070404d1d59e6  vmovaps [rsp+0x10], xmm1
000070404d1d59ec  vmovaps [rsp+0x20], xmm2
000070404d1d59f2  vmovaps [rsp+0x30], xmm3
000070404d1d59f8  vmovaps [rsp+0x40], xmm4
000070404d1d59fe  vmovaps [rsp+0x50], xmm5
000070404d1d5a04  vmovaps [rsp+0x60], xmm6
000070404d1d5a0a  vmovaps [rsp+0x70], xmm7
000070404d1d5a10  vmovaps [rsp+0x80], xmm8
000070404d1d5a19  vmovaps [rsp+0x90], xmm9
000070404d1d5a22  vmovaps [rsp+0xA0], xmm10
000070404d1d5a2b  vmovaps [rsp+0xB0], xmm11
000070404d1d5a34  vmovaps [rsp+0xC0], xmm12
000070404d1d5a3d  vmovaps [rsp+0xD0], xmm14
000070404d1d5a46  vmovaps [rsp+0xE0], xmm15
000070404d1d5a4f  sub rsp, 0x40
000070404d1d5a53  lea rdi, [rsp]
000070404d1d5a57  lea rsi, [rsp+0x10]
000070404d1d5a5c  lea rdx, [rsp+0x20]
000070404d1d5a61  lea rcx, [rsp+0x30]
000070404d1d5a66  mov r8d, 0x00
000070404d1d5a6c  lea r9, [r15+0x3A8]
000070404d1d5a73  movaps [rdi], xmm13
000070404d1d5a77  movaps [rsi], xmm10
000070404d1d5a7b  movaps [rdx], xmm7
000070404d1d5a7e  movaps [rcx], xmm1
000070404d1d5a81  mov rax, 0x607928F07A50
000070404d1d5a8b  call rax
000070404d1d5a8d  movaps xmm13, [rsp]
000070404d1d5a92  add rsp, 0x40
000070404d1d5a96  vmovaps xmm0, [rsp]
000070404d1d5a9b  vmovaps xmm1, [rsp+0x10]
000070404d1d5aa1  vmovaps xmm2, [rsp+0x20]
000070404d1d5aa7  vmovaps xmm3, [rsp+0x30]
000070404d1d5aad  vmovaps xmm4, [rsp+0x40]
000070404d1d5ab3  vmovaps xmm5, [rsp+0x50]
000070404d1d5ab9  vmovaps xmm6, [rsp+0x60]
000070404d1d5abf  vmovaps xmm7, [rsp+0x70]
000070404d1d5ac5  vmovaps xmm8, [rsp+0x80]
000070404d1d5ace  vmovaps xmm9, [rsp+0x90]
000070404d1d5ad7  vmovaps xmm10, [rsp+0xA0]
000070404d1d5ae0  vmovaps xmm11, [rsp+0xB0]
000070404d1d5ae9  vmovaps xmm12, [rsp+0xC0]
000070404d1d5af2  vmovaps xmm14, [rsp+0xD0]
000070404d1d5afb  vmovaps xmm15, [rsp+0xE0]
000070404d1d5b04  add rsp, 0xF0
000070404d1d5b0b  pop r11
000070404d1d5b0d  pop r10
000070404d1d5b0f  pop r9
000070404d1d5b11  pop r8
000070404d1d5b13  pop rsi
000070404d1d5b14  pop rdi
000070404d1d5b15  pop rdx
000070404d1d5b16  pop rcx
000070404d1d5b17  pop rax
000070404d1d5b18  add rsp, 0x08
000070404d1d5b1c  jmp 0x000070404D1D3930
000070404d1d5b21  sub rsp, 0x08
000070404d1d5b25  push rax
000070404d1d5b26  push rcx
000070404d1d5b27  push rdx
000070404d1d5b28  push rdi
000070404d1d5b29  push rsi
000070404d1d5b2a  push r8
000070404d1d5b2c  push r9
000070404d1d5b2e  push r10
000070404d1d5b30  push r11
000070404d1d5b32  sub rsp, 0xF0
000070404d1d5b39  vmovaps [rsp], xmm0
000070404d1d5b3e  vmovaps [rsp+0x10], xmm1
000070404d1d5b44  vmovaps [rsp+0x20], xmm2
000070404d1d5b4a  vmovaps [rsp+0x30], xmm3
000070404d1d5b50  vmovaps [rsp+0x40], xmm4
000070404d1d5b56  vmovaps [rsp+0x50], xmm5
000070404d1d5b5c  vmovaps [rsp+0x60], xmm6
000070404d1d5b62  vmovaps [rsp+0x70], xmm7
000070404d1d5b68  vmovaps [rsp+0x80], xmm8
000070404d1d5b71  vmovaps [rsp+0x90], xmm9
000070404d1d5b7a  vmovaps [rsp+0xA0], xmm11
000070404d1d5b83  vmovaps [rsp+0xB0], xmm12
000070404d1d5b8c  vmovaps [rsp+0xC0], xmm13
000070404d1d5b95  vmovaps [rsp+0xD0], xmm14
000070404d1d5b9e  vmovaps [rsp+0xE0], xmm15
000070404d1d5ba7  sub rsp, 0x40
000070404d1d5bab  lea rdi, [rsp]
000070404d1d5baf  lea rsi, [rsp+0x10]
000070404d1d5bb4  lea rdx, [rsp+0x20]
000070404d1d5bb9  lea rcx, [rsp+0x30]
000070404d1d5bbe  mov r8d, 0x00
000070404d1d5bc4  lea r9, [r15+0x3A8]
000070404d1d5bcb  movaps [rdi], xmm10
000070404d1d5bcf  movaps [rsi], xmm6
000070404d1d5bd2  movaps [rdx], xmm15
000070404d1d5bd6  movaps [rcx], xmm1
000070404d1d5bd9  mov rax, 0x607928F07A50
000070404d1d5be3  call rax
000070404d1d5be5  movaps xmm10, [rsp]
000070404d1d5bea  add rsp, 0x40
000070404d1d5bee  vmovaps xmm0, [rsp]
000070404d1d5bf3  vmovaps xmm1, [rsp+0x10]
000070404d1d5bf9  vmovaps xmm2, [rsp+0x20]
000070404d1d5bff  vmovaps xmm3, [rsp+0x30]
000070404d1d5c05  vmovaps xmm4, [rsp+0x40]
000070404d1d5c0b  vmovaps xmm5, [rsp+0x50]
000070404d1d5c11  vmovaps xmm6, [rsp+0x60]
000070404d1d5c17  vmovaps xmm7, [rsp+0x70]
000070404d1d5c1d  vmovaps xmm8, [rsp+0x80]
000070404d1d5c26  vmovaps xmm9, [rsp+0x90]
000070404d1d5c2f  vmovaps xmm11, [rsp+0xA0]
000070404d1d5c38  vmovaps xmm12, [rsp+0xB0]
000070404d1d5c41  vmovaps xmm13, [rsp+0xC0]
000070404d1d5c4a  vmovaps xmm14, [rsp+0xD0]
000070404d1d5c53  vmovaps xmm15, [rsp+0xE0]
000070404d1d5c5c  add rsp, 0xF0
000070404d1d5c63  pop r11
000070404d1d5c65  pop r10
000070404d1d5c67  pop r9
000070404d1d5c69  pop r8
000070404d1d5c6b  pop rsi
000070404d1d5c6c  pop rdi
000070404d1d5c6d  pop rdx
000070404d1d5c6e  pop rcx
000070404d1d5c6f  pop rax
000070404d1d5c70  add rsp, 0x08
000070404d1d5c74  jmp 0x000070404D1D3956
000070404d1d5c79  call 0x000070404D0D64F0
000070404d1d5c7e  jmp 0x000070404D1D3960
000070404d1d5c83  call 0x000070404D0E5820
000070404d1d5c88  jmp 0x000070404D1D396A
000070404d1d5c8d  sub rsp, 0x08
000070404d1d5c91  push rax
000070404d1d5c92  push rcx
000070404d1d5c93  push rdx
000070404d1d5c94  push rdi
000070404d1d5c95  push rsi
000070404d1d5c96  push r8
000070404d1d5c98  push r9
000070404d1d5c9a  push r10
000070404d1d5c9c  push r11
000070404d1d5c9e  sub rsp, 0xF0
000070404d1d5ca5  vmovaps [rsp], xmm0
000070404d1d5caa  vmovaps [rsp+0x10], xmm1
000070404d1d5cb0  vmovaps [rsp+0x20], xmm2
000070404d1d5cb6  vmovaps [rsp+0x30], xmm3
000070404d1d5cbc  vmovaps [rsp+0x40], xmm4
000070404d1d5cc2  vmovaps [rsp+0x50], xmm5
000070404d1d5cc8  vmovaps [rsp+0x60], xmm6
000070404d1d5cce  vmovaps [rsp+0x70], xmm8
000070404d1d5cd4  vmovaps [rsp+0x80], xmm9
000070404d1d5cdd  vmovaps [rsp+0x90], xmm10
000070404d1d5ce6  vmovaps [rsp+0xA0], xmm11
000070404d1d5cef  vmovaps [rsp+0xB0], xmm12
000070404d1d5cf8  vmovaps [rsp+0xC0], xmm13
000070404d1d5d01  vmovaps [rsp+0xD0], xmm14
000070404d1d5d0a  vmovaps [rsp+0xE0], xmm15
000070404d1d5d13  sub rsp, 0x40
000070404d1d5d17  lea rdi, [rsp]
000070404d1d5d1b  lea rsi, [rsp+0x10]
000070404d1d5d20  lea rdx, [rsp+0x20]
000070404d1d5d25  lea rcx, [rsp+0x30]
000070404d1d5d2a  mov r8d, 0x00
000070404d1d5d30  lea r9, [r15+0x3A8]
000070404d1d5d37  movaps [rdi], xmm7
000070404d1d5d3a  movaps [rsi], xmm8
000070404d1d5d3e  movaps [rdx], xmm3
000070404d1d5d41  movaps [rcx], xmm9
000070404d1d5d45  mov rax, 0x607928F07A50
000070404d1d5d4f  call rax
000070404d1d5d51  movaps xmm7, [rsp]
000070404d1d5d55  add rsp, 0x40
000070404d1d5d59  vmovaps xmm0, [rsp]
000070404d1d5d5e  vmovaps xmm1, [rsp+0x10]
000070404d1d5d64  vmovaps xmm2, [rsp+0x20]
000070404d1d5d6a  vmovaps xmm3, [rsp+0x30]
000070404d1d5d70  vmovaps xmm4, [rsp+0x40]
000070404d1d5d76  vmovaps xmm5, [rsp+0x50]
000070404d1d5d7c  vmovaps xmm6, [rsp+0x60]
000070404d1d5d82  vmovaps xmm8, [rsp+0x70]
000070404d1d5d88  vmovaps xmm9, [rsp+0x80]
000070404d1d5d91  vmovaps xmm10, [rsp+0x90]
000070404d1d5d9a  vmovaps xmm11, [rsp+0xA0]
000070404d1d5da3  vmovaps xmm12, [rsp+0xB0]
000070404d1d5dac  vmovaps xmm13, [rsp+0xC0]
000070404d1d5db5  vmovaps xmm14, [rsp+0xD0]
000070404d1d5dbe  vmovaps xmm15, [rsp+0xE0]
000070404d1d5dc7  add rsp, 0xF0
000070404d1d5dce  pop r11
000070404d1d5dd0  pop r10
000070404d1d5dd2  pop r9
000070404d1d5dd4  pop r8
000070404d1d5dd6  pop rsi
000070404d1d5dd7  pop rdi
000070404d1d5dd8  pop rdx
000070404d1d5dd9  pop rcx
000070404d1d5dda  pop rax
000070404d1d5ddb  add rsp, 0x08
000070404d1d5ddf  jmp 0x000070404D1D3992
000070404d1d5de4  sub rsp, 0x08
000070404d1d5de8  push rax
000070404d1d5de9  push rcx
000070404d1d5dea  push rdx
000070404d1d5deb  push rdi
000070404d1d5dec  push rsi
000070404d1d5ded  push r8
000070404d1d5def  push r9
000070404d1d5df1  push r10
000070404d1d5df3  push r11
000070404d1d5df5  sub rsp, 0xF0
000070404d1d5dfc  vmovaps [rsp], xmm0
000070404d1d5e01  vmovaps [rsp+0x10], xmm1
000070404d1d5e07  vmovaps [rsp+0x20], xmm2
000070404d1d5e0d  vmovaps [rsp+0x30], xmm3
000070404d1d5e13  vmovaps [rsp+0x40], xmm4
000070404d1d5e19  vmovaps [rsp+0x50], xmm5
000070404d1d5e1f  vmovaps [rsp+0x60], xmm6
000070404d1d5e25  vmovaps [rsp+0x70], xmm7
000070404d1d5e2b  vmovaps [rsp+0x80], xmm9
000070404d1d5e34  vmovaps [rsp+0x90], xmm10
000070404d1d5e3d  vmovaps [rsp+0xA0], xmm11
000070404d1d5e46  vmovaps [rsp+0xB0], xmm12
000070404d1d5e4f  vmovaps [rsp+0xC0], xmm13
000070404d1d5e58  vmovaps [rsp+0xD0], xmm14
000070404d1d5e61  vmovaps [rsp+0xE0], xmm15
000070404d1d5e6a  sub rsp, 0x40
000070404d1d5e6e  lea rdi, [rsp]
000070404d1d5e72  lea rsi, [rsp+0x10]
000070404d1d5e77  lea rdx, [rsp+0x20]
000070404d1d5e7c  lea rcx, [rsp+0x30]
000070404d1d5e81  mov r8d, 0x00
000070404d1d5e87  lea r9, [r15+0x3A8]
000070404d1d5e8e  movaps [rdi], xmm8
000070404d1d5e92  movaps [rsi], xmm11
000070404d1d5e96  movaps [rdx], xmm14
000070404d1d5e9a  movaps [rcx], xmm9
000070404d1d5e9e  mov rax, 0x607928F07A50
000070404d1d5ea8  call rax
000070404d1d5eaa  movaps xmm8, [rsp]
000070404d1d5eaf  add rsp, 0x40
000070404d1d5eb3  vmovaps xmm0, [rsp]
000070404d1d5eb8  vmovaps xmm1, [rsp+0x10]
000070404d1d5ebe  vmovaps xmm2, [rsp+0x20]
000070404d1d5ec4  vmovaps xmm3, [rsp+0x30]
000070404d1d5eca  vmovaps xmm4, [rsp+0x40]
000070404d1d5ed0  vmovaps xmm5, [rsp+0x50]
000070404d1d5ed6  vmovaps xmm6, [rsp+0x60]
000070404d1d5edc  vmovaps xmm7, [rsp+0x70]
000070404d1d5ee2  vmovaps xmm9, [rsp+0x80]
000070404d1d5eeb  vmovaps xmm10, [rsp+0x90]
000070404d1d5ef4  vmovaps xmm11, [rsp+0xA0]
000070404d1d5efd  vmovaps xmm12, [rsp+0xB0]
000070404d1d5f06  vmovaps xmm13, [rsp+0xC0]
000070404d1d5f0f  vmovaps xmm14, [rsp+0xD0]
000070404d1d5f18  vmovaps xmm15, [rsp+0xE0]
000070404d1d5f21  add rsp, 0xF0
000070404d1d5f28  pop r11
000070404d1d5f2a  pop r10
000070404d1d5f2c  pop r9
000070404d1d5f2e  pop r8
000070404d1d5f30  pop rsi
000070404d1d5f31  pop rdi
000070404d1d5f32  pop rdx
000070404d1d5f33  pop rcx
000070404d1d5f34  pop rax
000070404d1d5f35  add rsp, 0x08
000070404d1d5f39  jmp 0x000070404D1D39BB
000070404d1d5f3e  sub rsp, 0x08
000070404d1d5f42  push rax
000070404d1d5f43  push rcx
000070404d1d5f44  push rdx
000070404d1d5f45  push rdi
000070404d1d5f46  push rsi
000070404d1d5f47  push r8
000070404d1d5f49  push r9
000070404d1d5f4b  push r10
000070404d1d5f4d  push r11
000070404d1d5f4f  sub rsp, 0xF0
000070404d1d5f56  vmovaps [rsp], xmm0
000070404d1d5f5b  vmovaps [rsp+0x10], xmm1
000070404d1d5f61  vmovaps [rsp+0x20], xmm2
000070404d1d5f67  vmovaps [rsp+0x30], xmm3
000070404d1d5f6d  vmovaps [rsp+0x40], xmm4
000070404d1d5f73  vmovaps [rsp+0x50], xmm5
000070404d1d5f79  vmovaps [rsp+0x60], xmm6
000070404d1d5f7f  vmovaps [rsp+0x70], xmm7
000070404d1d5f85  vmovaps [rsp+0x80], xmm8
000070404d1d5f8e  vmovaps [rsp+0x90], xmm9
000070404d1d5f97  vmovaps [rsp+0xA0], xmm10
000070404d1d5fa0  vmovaps [rsp+0xB0], xmm12
000070404d1d5fa9  vmovaps [rsp+0xC0], xmm13
000070404d1d5fb2  vmovaps [rsp+0xD0], xmm14
000070404d1d5fbb  vmovaps [rsp+0xE0], xmm15
000070404d1d5fc4  sub rsp, 0x40
000070404d1d5fc8  lea rdi, [rsp]
000070404d1d5fcc  lea rsi, [rsp+0x10]
000070404d1d5fd1  lea rdx, [rsp+0x20]
000070404d1d5fd6  lea rcx, [rsp+0x30]
000070404d1d5fdb  mov r8d, 0x00
000070404d1d5fe1  lea r9, [r15+0x3A8]
000070404d1d5fe8  movaps [rdi], xmm11
000070404d1d5fec  movaps [rsi], xmm13
000070404d1d5ff0  movaps [rdx], xmm12
000070404d1d5ff4  movaps [rcx], xmm14
000070404d1d5ff8  mov rax, 0x607928F07A50
000070404d1d6002  call rax
000070404d1d6004  movaps xmm11, [rsp]
000070404d1d6009  add rsp, 0x40
000070404d1d600d  vmovaps xmm0, [rsp]
000070404d1d6012  vmovaps xmm1, [rsp+0x10]
000070404d1d6018  vmovaps xmm2, [rsp+0x20]
000070404d1d601e  vmovaps xmm3, [rsp+0x30]
000070404d1d6024  vmovaps xmm4, [rsp+0x40]
000070404d1d602a  vmovaps xmm5, [rsp+0x50]
000070404d1d6030  vmovaps xmm6, [rsp+0x60]
000070404d1d6036  vmovaps xmm7, [rsp+0x70]
000070404d1d603c  vmovaps xmm8, [rsp+0x80]
000070404d1d6045  vmovaps xmm9, [rsp+0x90]
000070404d1d604e  vmovaps xmm10, [rsp+0xA0]
000070404d1d6057  vmovaps xmm12, [rsp+0xB0]
000070404d1d6060  vmovaps xmm13, [rsp+0xC0]
000070404d1d6069  vmovaps xmm14, [rsp+0xD0]
000070404d1d6072  vmovaps xmm15, [rsp+0xE0]
000070404d1d607b  add rsp, 0xF0
000070404d1d6082  pop r11
000070404d1d6084  pop r10
000070404d1d6086  pop r9
000070404d1d6088  pop r8
000070404d1d608a  pop rsi
000070404d1d608b  pop rdi
000070404d1d608c  pop rdx
000070404d1d608d  pop rcx
000070404d1d608e  pop rax
000070404d1d608f  add rsp, 0x08
000070404d1d6093  jmp 0x000070404D1D39E4
000070404d1d6098  sub rsp, 0x08
000070404d1d609c  push rax
000070404d1d609d  push rcx
000070404d1d609e  push rdx
000070404d1d609f  push rdi
000070404d1d60a0  push rsi
000070404d1d60a1  push r8
000070404d1d60a3  push r9
000070404d1d60a5  push r10
000070404d1d60a7  push r11
000070404d1d60a9  sub rsp, 0xF0
000070404d1d60b0  vmovaps [rsp], xmm0
000070404d1d60b5  vmovaps [rsp+0x10], xmm1
000070404d1d60bb  vmovaps [rsp+0x20], xmm2
000070404d1d60c1  vmovaps [rsp+0x30], xmm3
000070404d1d60c7  vmovaps [rsp+0x40], xmm4
000070404d1d60cd  vmovaps [rsp+0x50], xmm5
000070404d1d60d3  vmovaps [rsp+0x60], xmm6
000070404d1d60d9  vmovaps [rsp+0x70], xmm7
000070404d1d60df  vmovaps [rsp+0x80], xmm8
000070404d1d60e8  vmovaps [rsp+0x90], xmm9
000070404d1d60f1  vmovaps [rsp+0xA0], xmm10
000070404d1d60fa  vmovaps [rsp+0xB0], xmm11
000070404d1d6103  vmovaps [rsp+0xC0], xmm13
000070404d1d610c  vmovaps [rsp+0xD0], xmm14
000070404d1d6115  vmovaps [rsp+0xE0], xmm15
000070404d1d611e  sub rsp, 0x40
000070404d1d6122  lea rdi, [rsp]
000070404d1d6126  lea rsi, [rsp+0x10]
000070404d1d612b  lea rdx, [rsp+0x20]
000070404d1d6130  lea rcx, [rsp+0x30]
000070404d1d6135  mov r8d, 0x00
000070404d1d613b  lea r9, [r15+0x3A8]
000070404d1d6142  movaps [rdi], xmm12
000070404d1d6146  movaps [rsi], xmm10
000070404d1d614a  movaps [rdx], xmm15
000070404d1d614e  movaps [rcx], xmm14
000070404d1d6152  mov rax, 0x607928F07A50
000070404d1d615c  call rax
000070404d1d615e  movaps xmm12, [rsp]
000070404d1d6163  add rsp, 0x40
000070404d1d6167  vmovaps xmm0, [rsp]
000070404d1d616c  vmovaps xmm1, [rsp+0x10]
000070404d1d6172  vmovaps xmm2, [rsp+0x20]
000070404d1d6178  vmovaps xmm3, [rsp+0x30]
000070404d1d617e  vmovaps xmm4, [rsp+0x40]
000070404d1d6184  vmovaps xmm5, [rsp+0x50]
000070404d1d618a  vmovaps xmm6, [rsp+0x60]
000070404d1d6190  vmovaps xmm7, [rsp+0x70]
000070404d1d6196  vmovaps xmm8, [rsp+0x80]
000070404d1d619f  vmovaps xmm9, [rsp+0x90]
000070404d1d61a8  vmovaps xmm10, [rsp+0xA0]
000070404d1d61b1  vmovaps xmm11, [rsp+0xB0]
000070404d1d61ba  vmovaps xmm13, [rsp+0xC0]
000070404d1d61c3  vmovaps xmm14, [rsp+0xD0]
000070404d1d61cc  vmovaps xmm15, [rsp+0xE0]
000070404d1d61d5  add rsp, 0xF0
000070404d1d61dc  pop r11
000070404d1d61de  pop r10
000070404d1d61e0  pop r9
000070404d1d61e2  pop r8
000070404d1d61e4  pop rsi
000070404d1d61e5  pop rdi
000070404d1d61e6  pop rdx
000070404d1d61e7  pop rcx
000070404d1d61e8  pop rax
000070404d1d61e9  add rsp, 0x08
000070404d1d61ed  jmp 0x000070404D1D3A0D
000070404d1d61f2  call 0x000070404D0E5820
000070404d1d61f7  jmp 0x000070404D1D3A1A
000070404d1d61fc  call 0x000070404D0E45A0
000070404d1d6201  jmp 0x000070404D1D3A27
000070404d1d6206  sub rsp, 0x08
000070404d1d620a  push rax
000070404d1d620b  push rcx
000070404d1d620c  push rdx
000070404d1d620d  push rdi
000070404d1d620e  push rsi
000070404d1d620f  push r8
000070404d1d6211  push r9
000070404d1d6213  push r10
000070404d1d6215  push r11
000070404d1d6217  sub rsp, 0xF0
000070404d1d621e  vmovaps [rsp], xmm0
000070404d1d6223  vmovaps [rsp+0x10], xmm1
000070404d1d6229  vmovaps [rsp+0x20], xmm2
000070404d1d622f  vmovaps [rsp+0x30], xmm3
000070404d1d6235  vmovaps [rsp+0x40], xmm4
000070404d1d623b  vmovaps [rsp+0x50], xmm5
000070404d1d6241  vmovaps [rsp+0x60], xmm6
000070404d1d6247  vmovaps [rsp+0x70], xmm7
000070404d1d624d  vmovaps [rsp+0x80], xmm8
000070404d1d6256  vmovaps [rsp+0x90], xmm9
000070404d1d625f  vmovaps [rsp+0xA0], xmm11
000070404d1d6268  vmovaps [rsp+0xB0], xmm12
000070404d1d6271  vmovaps [rsp+0xC0], xmm13
000070404d1d627a  vmovaps [rsp+0xD0], xmm14
000070404d1d6283  vmovaps [rsp+0xE0], xmm15
000070404d1d628c  sub rsp, 0x40
000070404d1d6290  lea rdi, [rsp]
000070404d1d6294  lea rsi, [rsp+0x10]
000070404d1d6299  lea rdx, [rsp+0x20]
000070404d1d629e  lea rcx, [rsp+0x30]
000070404d1d62a3  mov r8d, 0x00
000070404d1d62a9  lea r9, [r15+0x3A8]
000070404d1d62b0  movaps [rdi], xmm10
000070404d1d62b4  movaps [rsi], xmm7
000070404d1d62b7  movaps [rdx], xmm1
000070404d1d62ba  movaps [rcx], xmm13
000070404d1d62be  mov rax, 0x607928F07A50
000070404d1d62c8  call rax
000070404d1d62ca  movaps xmm10, [rsp]
000070404d1d62cf  add rsp, 0x40
000070404d1d62d3  vmovaps xmm0, [rsp]
000070404d1d62d8  vmovaps xmm1, [rsp+0x10]
000070404d1d62de  vmovaps xmm2, [rsp+0x20]
000070404d1d62e4  vmovaps xmm3, [rsp+0x30]
000070404d1d62ea  vmovaps xmm4, [rsp+0x40]
000070404d1d62f0  vmovaps xmm5, [rsp+0x50]
000070404d1d62f6  vmovaps xmm6, [rsp+0x60]
000070404d1d62fc  vmovaps xmm7, [rsp+0x70]
000070404d1d6302  vmovaps xmm8, [rsp+0x80]
000070404d1d630b  vmovaps xmm9, [rsp+0x90]
000070404d1d6314  vmovaps xmm11, [rsp+0xA0]
000070404d1d631d  vmovaps xmm12, [rsp+0xB0]
000070404d1d6326  vmovaps xmm13, [rsp+0xC0]
000070404d1d632f  vmovaps xmm14, [rsp+0xD0]
000070404d1d6338  vmovaps xmm15, [rsp+0xE0]
000070404d1d6341  add rsp, 0xF0
000070404d1d6348  pop r11
000070404d1d634a  pop r10
000070404d1d634c  pop r9
000070404d1d634e  pop r8
000070404d1d6350  pop rsi
000070404d1d6351  pop rdi
000070404d1d6352  pop rdx
000070404d1d6353  pop rcx
000070404d1d6354  pop rax
000070404d1d6355  add rsp, 0x08
000070404d1d6359  jmp 0x000070404D1D3A5D
000070404d1d635e  call 0x000070404D0D64F0
000070404d1d6363  jmp 0x000070404D1D3A6F
000070404d1d6368  sub rsp, 0x08
000070404d1d636c  push rax
000070404d1d636d  push rcx
000070404d1d636e  push rdx
000070404d1d636f  push rdi
000070404d1d6370  push rsi
000070404d1d6371  push r8
000070404d1d6373  push r9
000070404d1d6375  push r10
000070404d1d6377  push r11
000070404d1d6379  sub rsp, 0xF0
000070404d1d6380  vmovaps [rsp], xmm0
000070404d1d6385  vmovaps [rsp+0x10], xmm1
000070404d1d638b  vmovaps [rsp+0x20], xmm2
000070404d1d6391  vmovaps [rsp+0x30], xmm3
000070404d1d6397  vmovaps [rsp+0x40], xmm4
000070404d1d639d  vmovaps [rsp+0x50], xmm5
000070404d1d63a3  vmovaps [rsp+0x60], xmm6
000070404d1d63a9  vmovaps [rsp+0x70], xmm7
000070404d1d63af  vmovaps [rsp+0x80], xmm8
000070404d1d63b8  vmovaps [rsp+0x90], xmm10
000070404d1d63c1  vmovaps [rsp+0xA0], xmm11
000070404d1d63ca  vmovaps [rsp+0xB0], xmm12
000070404d1d63d3  vmovaps [rsp+0xC0], xmm13
000070404d1d63dc  vmovaps [rsp+0xD0], xmm14
000070404d1d63e5  vmovaps [rsp+0xE0], xmm15
000070404d1d63ee  sub rsp, 0x40
000070404d1d63f2  lea rdi, [rsp]
000070404d1d63f6  lea rsi, [rsp+0x10]
000070404d1d63fb  lea rdx, [rsp+0x20]
000070404d1d6400  lea rcx, [rsp+0x30]
000070404d1d6405  mov r8d, 0x00
000070404d1d640b  lea r9, [r15+0x3A8]
000070404d1d6412  movaps [rdi], xmm9
000070404d1d6416  movaps [rsi], xmm8
000070404d1d641a  movaps [rdx], xmm14
000070404d1d641e  movaps [rcx], xmm13
000070404d1d6422  mov rax, 0x607928F07A50
000070404d1d642c  call rax
000070404d1d642e  movaps xmm9, [rsp]
000070404d1d6433  add rsp, 0x40
000070404d1d6437  vmovaps xmm0, [rsp]
000070404d1d643c  vmovaps xmm1, [rsp+0x10]
000070404d1d6442  vmovaps xmm2, [rsp+0x20]
000070404d1d6448  vmovaps xmm3, [rsp+0x30]
000070404d1d644e  vmovaps xmm4, [rsp+0x40]
000070404d1d6454  vmovaps xmm5, [rsp+0x50]
000070404d1d645a  vmovaps xmm6, [rsp+0x60]
000070404d1d6460  vmovaps xmm7, [rsp+0x70]
000070404d1d6466  vmovaps xmm8, [rsp+0x80]
000070404d1d646f  vmovaps xmm10, [rsp+0x90]
000070404d1d6478  vmovaps xmm11, [rsp+0xA0]
000070404d1d6481  vmovaps xmm12, [rsp+0xB0]
000070404d1d648a  vmovaps xmm13, [rsp+0xC0]
000070404d1d6493  vmovaps xmm14, [rsp+0xD0]
000070404d1d649c  vmovaps xmm15, [rsp+0xE0]
000070404d1d64a5  add rsp, 0xF0
000070404d1d64ac  pop r11
000070404d1d64ae  pop r10
000070404d1d64b0  pop r9
000070404d1d64b2  pop r8
000070404d1d64b4  pop rsi
000070404d1d64b5  pop rdi
000070404d1d64b6  pop rdx
000070404d1d64b7  pop rcx
000070404d1d64b8  pop rax
000070404d1d64b9  add rsp, 0x08
000070404d1d64bd  jmp 0x000070404D1D3A9D
000070404d1d64c2  sub rsp, 0x08
000070404d1d64c6  push rax
000070404d1d64c7  push rcx
000070404d1d64c8  push rdx
000070404d1d64c9  push rdi
000070404d1d64ca  push rsi
000070404d1d64cb  push r8
000070404d1d64cd  push r9
000070404d1d64cf  push r10
000070404d1d64d1  push r11
000070404d1d64d3  sub rsp, 0xF0
000070404d1d64da  vmovaps [rsp], xmm0
000070404d1d64df  vmovaps [rsp+0x10], xmm1
000070404d1d64e5  vmovaps [rsp+0x20], xmm2
000070404d1d64eb  vmovaps [rsp+0x30], xmm3
000070404d1d64f1  vmovaps [rsp+0x40], xmm4
000070404d1d64f7  vmovaps [rsp+0x50], xmm5
000070404d1d64fd  vmovaps [rsp+0x60], xmm6
000070404d1d6503  vmovaps [rsp+0x70], xmm7
000070404d1d6509  vmovaps [rsp+0x80], xmm8
000070404d1d6512  vmovaps [rsp+0x90], xmm9
000070404d1d651b  vmovaps [rsp+0xA0], xmm10
000070404d1d6524  vmovaps [rsp+0xB0], xmm11
000070404d1d652d  vmovaps [rsp+0xC0], xmm12
000070404d1d6536  vmovaps [rsp+0xD0], xmm14
000070404d1d653f  vmovaps [rsp+0xE0], xmm15
000070404d1d6548  sub rsp, 0x40
000070404d1d654c  lea rdi, [rsp]
000070404d1d6550  lea rsi, [rsp+0x10]
000070404d1d6555  lea rdx, [rsp+0x20]
000070404d1d655a  lea rcx, [rsp+0x30]
000070404d1d655f  mov r8d, 0x00
000070404d1d6565  lea r9, [r15+0x3A8]
000070404d1d656c  movaps [rdi], xmm13
000070404d1d6570  movaps [rsi], xmm11
000070404d1d6574  movaps [rdx], xmm15
000070404d1d6578  movaps [rcx], xmm14
000070404d1d657c  mov rax, 0x607928F07A50
000070404d1d6586  call rax
000070404d1d6588  movaps xmm13, [rsp]
000070404d1d658d  add rsp, 0x40
000070404d1d6591  vmovaps xmm0, [rsp]
000070404d1d6596  vmovaps xmm1, [rsp+0x10]
000070404d1d659c  vmovaps xmm2, [rsp+0x20]
000070404d1d65a2  vmovaps xmm3, [rsp+0x30]
000070404d1d65a8  vmovaps xmm4, [rsp+0x40]
000070404d1d65ae  vmovaps xmm5, [rsp+0x50]
000070404d1d65b4  vmovaps xmm6, [rsp+0x60]
000070404d1d65ba  vmovaps xmm7, [rsp+0x70]
000070404d1d65c0  vmovaps xmm8, [rsp+0x80]
000070404d1d65c9  vmovaps xmm9, [rsp+0x90]
000070404d1d65d2  vmovaps xmm10, [rsp+0xA0]
000070404d1d65db  vmovaps xmm11, [rsp+0xB0]
000070404d1d65e4  vmovaps xmm12, [rsp+0xC0]
000070404d1d65ed  vmovaps xmm14, [rsp+0xD0]
000070404d1d65f6  vmovaps xmm15, [rsp+0xE0]
000070404d1d65ff  add rsp, 0xF0
000070404d1d6606  pop r11
000070404d1d6608  pop r10
000070404d1d660a  pop r9
000070404d1d660c  pop r8
000070404d1d660e  pop rsi
000070404d1d660f  pop rdi
000070404d1d6610  pop rdx
000070404d1d6611  pop rcx
000070404d1d6612  pop rax
000070404d1d6613  add rsp, 0x08
000070404d1d6617  jmp 0x000070404D1D3ACB
000070404d1d661c  sub rsp, 0x08
000070404d1d6620  push rax
000070404d1d6621  push rcx
000070404d1d6622  push rdx
000070404d1d6623  push rdi
000070404d1d6624  push rsi
000070404d1d6625  push r8
000070404d1d6627  push r9
000070404d1d6629  push r10
000070404d1d662b  push r11
000070404d1d662d  sub rsp, 0xF0
000070404d1d6634  vmovaps [rsp], xmm0
000070404d1d6639  vmovaps [rsp+0x10], xmm1
000070404d1d663f  vmovaps [rsp+0x20], xmm2
000070404d1d6645  vmovaps [rsp+0x30], xmm3
000070404d1d664b  vmovaps [rsp+0x40], xmm4
000070404d1d6651  vmovaps [rsp+0x50], xmm5
000070404d1d6657  vmovaps [rsp+0x60], xmm6
000070404d1d665d  vmovaps [rsp+0x70], xmm7
000070404d1d6663  vmovaps [rsp+0x80], xmm8
000070404d1d666c  vmovaps [rsp+0x90], xmm9
000070404d1d6675  vmovaps [rsp+0xA0], xmm10
000070404d1d667e  vmovaps [rsp+0xB0], xmm11
000070404d1d6687  vmovaps [rsp+0xC0], xmm12
000070404d1d6690  vmovaps [rsp+0xD0], xmm13
000070404d1d6699  vmovaps [rsp+0xE0], xmm15
000070404d1d66a2  sub rsp, 0x40
000070404d1d66a6  lea rdi, [rsp]
000070404d1d66aa  lea rsi, [rsp+0x10]
000070404d1d66af  lea rdx, [rsp+0x20]
000070404d1d66b4  lea rcx, [rsp+0x30]
000070404d1d66b9  mov r8d, 0x00
000070404d1d66bf  lea r9, [r15+0x3A8]
000070404d1d66c6  movaps [rdi], xmm14
000070404d1d66ca  movaps [rsi], xmm12
000070404d1d66ce  movaps [rdx], xmm1
000070404d1d66d1  movaps [rcx], xmm15
000070404d1d66d5  mov rax, 0x607928F07A50
000070404d1d66df  call rax
000070404d1d66e1  movaps xmm14, [rsp]
000070404d1d66e6  add rsp, 0x40
000070404d1d66ea  vmovaps xmm0, [rsp]
000070404d1d66ef  vmovaps xmm1, [rsp+0x10]
000070404d1d66f5  vmovaps xmm2, [rsp+0x20]
000070404d1d66fb  vmovaps xmm3, [rsp+0x30]
000070404d1d6701  vmovaps xmm4, [rsp+0x40]
000070404d1d6707  vmovaps xmm5, [rsp+0x50]
000070404d1d670d  vmovaps xmm6, [rsp+0x60]
000070404d1d6713  vmovaps xmm7, [rsp+0x70]
000070404d1d6719  vmovaps xmm8, [rsp+0x80]
000070404d1d6722  vmovaps xmm9, [rsp+0x90]
000070404d1d672b  vmovaps xmm10, [rsp+0xA0]
000070404d1d6734  vmovaps xmm11, [rsp+0xB0]
000070404d1d673d  vmovaps xmm12, [rsp+0xC0]
000070404d1d6746  vmovaps xmm13, [rsp+0xD0]
000070404d1d674f  vmovaps xmm15, [rsp+0xE0]
000070404d1d6758  add rsp, 0xF0
000070404d1d675f  pop r11
000070404d1d6761  pop r10
000070404d1d6763  pop r9
000070404d1d6765  pop r8
000070404d1d6767  pop rsi
000070404d1d6768  pop rdi
000070404d1d6769  pop rdx
000070404d1d676a  pop rcx
000070404d1d676b  pop rax
000070404d1d676c  add rsp, 0x08
000070404d1d6770  jmp 0x000070404D1D3AF9
000070404d1d6775  call 0x000070404D0ACF70
000070404d1d677a  jmp 0x000070404D1D3B07
000070404d1d677f  call 0x000070404D00C380
000070404d1d6784  jmp 0x000070404D1D3B11
000070404d1d6789  call 0x000070404D008C20
000070404d1d678e  jmp 0x000070404D1D3B1B
000070404d1d6793  call 0x000070404D00D600
000070404d1d6798  jmp 0x000070404D1D3B25
000070404d1d679d  int3
000070404d1d679e  nop
000070404d1d67a0  mov eax, [r15+0x48]
000070404d1d67a4  lea r14d, [eax+0x01]
000070404d1d67a9  mov [rsp+0x10], r14d
000070404d1d67ae  mov r14d, r14d
000070404d1d67b1  mov [r15+0x48], r14
000070404d1d67b5  xor eax, eax
000070404d1d67b7  mov r14d, [rsp+0x10]
000070404d1d67bc  cmp r14d, 0x1F4
000070404d1d67c3  cmc
000070404d1d67c4  lahf
000070404d1d67c5  seto al
000070404d1d67c8  mov [r15+0x108], eax
000070404d1d67cf  mov eax, [r15+0x108]
000070404d1d67d6  sahf
000070404d1d67d7  jnz 0x000070404D1D6809
000070404d1d67d9  cmp dword ptr [r15+0x318], 0x00
000070404d1d67e1  jz 0x000070404D1DA1A0
000070404d1d67e7  nop [rax+rax*1], ax
000070404d1d67f0  nop [rax+rax*1], eax
000070404d1d67f8  mov eax, 0x4103FC
000070404d1d67fd  mov [r15+0x100], rax
000070404d1d6804  jmp 0x000070404CFFE110
000070404d1d6809  cmp dword ptr [r15+0x318], 0x00
000070404d1d6811  jz 0x000070404D1D6840
000070404d1d6817  nop [rax+rax*1], ax
000070404d1d6820  nop [rax+rax*1], eax
000070404d1d6828  mov eax, 0x410270
000070404d1d682d  mov [r15+0x100], rax
000070404d1d6834  jmp 0x000070404CFFE110
000070404d1d6839  int3
000070404d1d683a  int3
000070404d1d683b  nop [rax+rax*1], eax
000070404d1d6840  mov rax, [r15+0x40]
000070404d1d6844  vxorps xmm1, xmm1, xmm1
000070404d1d6848  vpbroadcastq xmm1, xmm1
000070404d1d684d  vxorps xmm15, xmm15, xmm15
000070404d1d6852  vpbroadcastq xmm15, xmm15
000070404d1d6857  lea r14, [rax+0x30]
000070404d1d685b  mov r12, [r13+r14*1]
000070404d1d6860  lea r14, [rax+0x38]
000070404d1d6864  mov r11, [r13+r14*1]
000070404d1d6869  movq xmm14, r12
000070404d1d686e  movq xmm13, r11
000070404d1d6873  movq xmm14, xmm14
000070404d1d6878  movq xmm13, xmm13
000070404d1d687d  vmovaps [rsp+0x10], xmm13
000070404d1d6883  movq xmm13, xmm13
000070404d1d6888  movaps [r15+0x270], xmm13
000070404d1d6890  movaps xmm13, [r15+0x160]
000070404d1d6898  vmovaps [rsp+0x20], xmm13
000070404d1d689e  vmovaps xmm12, [rsp+0x20]
000070404d1d68a4  por xmm13, xmm12
000070404d1d68a9  lea r14, [rax+0x20]
000070404d1d68ad  mov r12, [r13+r14*1]
000070404d1d68b2  lea r14, [rax+0x28]
000070404d1d68b6  mov r11, [r13+r14*1]
000070404d1d68bb  movq xmm12, r12
000070404d1d68c0  movq xmm11, r11
000070404d1d68c5  movq xmm12, xmm12
000070404d1d68ca  movq xmm11, xmm11
000070404d1d68cf  movaps xmm10, [r15+0x2F0]
000070404d1d68d7  vmovaps [rsp+0x20], xmm10
000070404d1d68dd  vmovaps xmm9, [rsp+0x20]
000070404d1d68e3  por xmm10, xmm9
000070404d1d68e8  movaps xmm9, [r15+0x2D0]
000070404d1d68f0  vmovaps [rsp+0x20], xmm9
000070404d1d68f6  vmovaps xmm8, [rsp+0x20]
000070404d1d68fc  por xmm9, xmm8
000070404d1d6901  movaps xmm8, [r15+0x300]
000070404d1d6909  vmovaps [rsp+0x20], xmm8
000070404d1d690f  vmovaps xmm7, [rsp+0x20]
000070404d1d6915  por xmm8, xmm7
000070404d1d691a  movaps xmm7, [r15+0x2B0]
000070404d1d6922  vmovaps [rsp+0x20], xmm7
000070404d1d6928  vmovaps xmm6, [rsp+0x20]
000070404d1d692e  por xmm7, xmm6
000070404d1d6932  movaps xmm6, [r15+0x180]
000070404d1d693a  vmovaps [rsp+0x20], xmm6
000070404d1d6940  vmovaps xmm5, [rsp+0x20]
000070404d1d6946  por xmm6, xmm5
000070404d1d694a  lea r14, [rax+0x10]
000070404d1d694e  mov r12, [r13+r14*1]
000070404d1d6953  lea r14, [rax+0x18]
000070404d1d6957  mov r11, [r13+r14*1]
000070404d1d695c  movq xmm5, r12
000070404d1d6961  movq xmm4, r11
000070404d1d6966  movq xmm5, xmm5
000070404d1d696a  movq xmm4, xmm4
000070404d1d696e  movaps xmm3, [r15+0x200]
000070404d1d6976  vmovaps [rsp+0x20], xmm3
000070404d1d697c  vmovaps xmm2, [rsp+0x20]
000070404d1d6982  por xmm3, xmm2
000070404d1d6986  movaps xmm2, [r15+0x1F0]
000070404d1d698e  vmovaps [rsp+0x20], xmm2
000070404d1d6994  vmovaps [rsp+0x30], xmm1
000070404d1d699a  vmovaps xmm1, [rsp+0x20]
000070404d1d69a0  por xmm2, xmm1
000070404d1d69a4  movaps xmm1, [r15+0x2E0]
000070404d1d69ac  vmovaps [rsp+0x20], xmm1
000070404d1d69b2  vmovaps [rsp+0x40], xmm15
000070404d1d69b8  vmovaps xmm15, [rsp+0x20]
000070404d1d69be  por xmm1, xmm15
000070404d1d69c3  movaps xmm15, [r15+0x2A0]
000070404d1d69cb  vmovaps [rsp+0x20], xmm15
000070404d1d69d1  vmovaps [rsp+0x50], xmm1
000070404d1d69d7  vmovaps xmm1, [rsp+0x20]
000070404d1d69dd  por xmm15, xmm1
000070404d1d69e2  movaps xmm1, [r15+0x280]
000070404d1d69ea  vmovaps [rsp+0x20], xmm1
000070404d1d69f0  vmovaps [rsp+0x60], xmm15
000070404d1d69f6  vmovaps xmm15, [rsp+0x20]
000070404d1d69fc  por xmm1, xmm15
000070404d1d6a01  movaps xmm15, [r15+0x1C0]
000070404d1d6a09  vmovaps [rsp+0x20], xmm15
000070404d1d6a0f  vmovaps [rsp+0x70], xmm1
000070404d1d6a15  vmovaps xmm1, [rsp+0x20]
000070404d1d6a1b  por xmm15, xmm1
000070404d1d6a20  movaps xmm1, [r15+0x210]
000070404d1d6a28  vmovaps [rsp+0x20], xmm1
000070404d1d6a2e  vmovaps [rsp+0x80], xmm15
000070404d1d6a37  vmovaps xmm15, [rsp+0x20]
000070404d1d6a3d  por xmm1, xmm15
000070404d1d6a42  mov r14, [r13+rax*1]
000070404d1d6a47  vmovq xmm15, r14
000070404d1d6a4c  vpbroadcastq xmm15, xmm15
000070404d1d6a51  vmovaps [rsp+0x20], xmm1
000070404d1d6a57  vxorps xmm1, xmm1, xmm1
000070404d1d6a5b  vpbroadcastq xmm1, xmm1
000070404d1d6a60  mov r14, [r15+0xF8]
000070404d1d6a67  vmovaps [rsp+0x90], xmm1
000070404d1d6a70  movups xmm1, [r13+r14*1]
000070404d1d6a76  vmovaps [rsp+0xA0], xmm1
000070404d1d6a7f  vxorps xmm1, xmm1, xmm1
000070404d1d6a83  vpbroadcastq xmm1, xmm1
000070404d1d6a88  lea r12, [rax+0x08]
000070404d1d6a8c  mov rax, [r13+r12*1]
000070404d1d6a91  vmovaps [rsp+0xB0], xmm1
000070404d1d6a9a  movq xmm1, rax
000070404d1d6a9f  movaps [r15+0x240], xmm1
000070404d1d6aa7  mov rax, [r15+0x50]
000070404d1d6aab  mov [r15+0x60], rax
000070404d1d6aaf  mov qword ptr [r15+0x58], 0x40
000070404d1d6ab7  vmovaps xmm1, [rsp+0x30]
000070404d1d6abd  vmovaps [rsp+0x30], xmm15
000070404d1d6ac3  vmovaps xmm15, [rsp+0xA0]
000070404d1d6acc  vmovaps [rsp+0xA0], xmm14
000070404d1d6ad5  vmovaps xmm14, [rsp+0x30]
000070404d1d6adb  vmovaps [rsp+0x30], xmm13
000070404d1d6ae1  vmovaps [rsp+0xC0], xmm12
000070404d1d6aea  movaps xmm13, xmm1
000070404d1d6aee  vfmadd231pd xmm13, xmm15, xmm14
000070404d1d6af3  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1d6af9  vptest xmm12, xmm12
000070404d1d6afe  jnz 0x000070404D1D75DD
000070404d1d6b04  movaps xmm1, [r15+0x250]
000070404d1d6b0c  vmovaps xmm15, [rsp+0x40]
000070404d1d6b12  vmovaps [rsp+0x40], xmm13
000070404d1d6b18  movaps xmm12, xmm15
000070404d1d6b1c  vfmadd231pd xmm12, xmm1, xmm14
000070404d1d6b21  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1d6b27  vptest xmm13, xmm13
000070404d1d6b2c  jnz 0x000070404D1D7736
000070404d1d6b32  movaps xmm15, [r15+0x1E0]
000070404d1d6b3a  vmovaps [rsp+0xD0], xmm15
000070404d1d6b43  vmovaps xmm13, [rsp+0xD0]
000070404d1d6b4c  por xmm15, xmm13
000070404d1d6b51  movaps xmm13, [r15+0x1D0]
000070404d1d6b59  vmovaps [rsp+0xD0], xmm13
000070404d1d6b62  vmovaps [rsp+0xE0], xmm1
000070404d1d6b6b  vmovaps xmm1, [rsp+0xD0]
000070404d1d6b74  por xmm13, xmm1
000070404d1d6b79  movaps xmm1, [r15+0x2C0]
000070404d1d6b81  vmovaps [rsp+0xD0], xmm1
000070404d1d6b8a  vmovaps [rsp+0xF0], xmm15
000070404d1d6b93  vmovaps xmm15, [rsp+0xD0]
000070404d1d6b9c  por xmm1, xmm15
000070404d1d6ba1  movaps xmm15, [r15+0x290]
000070404d1d6ba9  vmovaps [rsp+0xD0], xmm15
000070404d1d6bb2  vmovaps [rsp+0x100], xmm1
000070404d1d6bbb  vmovaps xmm1, [rsp+0xD0]
000070404d1d6bc4  por xmm15, xmm1
000070404d1d6bc9  movaps xmm1, [r15+0x260]
000070404d1d6bd1  vmovaps [rsp+0xD0], xmm1
000070404d1d6bda  vmovaps [rsp+0x110], xmm15
000070404d1d6be3  vmovaps xmm15, [rsp+0xD0]
000070404d1d6bec  por xmm1, xmm15
000070404d1d6bf1  vmovaps xmm15, [rsp+0xE0]
000070404d1d6bfa  vmovaps [rsp+0xD0], xmm1
000070404d1d6c03  vmovaps xmm1, [rsp+0xE0]
000070404d1d6c0c  por xmm15, xmm1
000070404d1d6c11  lea r12, [r14+0xC0]
000070404d1d6c18  movups xmm1, [r13+r12*1]
000070404d1d6c1e  mov [rsp+0xE0], rax
000070404d1d6c26  xor eax, eax
000070404d1d6c28  mov r12d, 0x40
000070404d1d6c2e  mov r11d, 0x200
000070404d1d6c34  cmp r12, r11
000070404d1d6c37  cmc
000070404d1d6c38  lahf
000070404d1d6c39  seto al
000070404d1d6c3c  mov [r15+0x108], eax
000070404d1d6c43  vmovaps [rsp+0x120], xmm1
000070404d1d6c4c  vmovaps xmm1, [rsp+0x90]
000070404d1d6c55  vmovaps [rsp+0x90], xmm15
000070404d1d6c5e  vmovaps xmm15, [rsp+0x120]
000070404d1d6c67  vmovaps [rsp+0x120], xmm13
000070404d1d6c70  vmovaps [rsp+0x130], xmm12
000070404d1d6c79  movaps xmm13, xmm1
000070404d1d6c7d  vfmadd231pd xmm13, xmm15, xmm14
000070404d1d6c82  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1d6c88  vptest xmm12, xmm12
000070404d1d6c8d  jnz 0x000070404D1D7899
000070404d1d6c93  lea rax, [r14+0xB0]
000070404d1d6c9a  movups xmm1, [r13+rax*1]
000070404d1d6ca0  vmovaps xmm15, [rsp+0xB0]
000070404d1d6ca9  vmovaps [rsp+0xB0], xmm13
000070404d1d6cb2  movaps xmm12, xmm15
000070404d1d6cb6  vfmadd231pd xmm12, xmm1, xmm14
000070404d1d6cbb  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1d6cc1  vptest xmm13, xmm13
000070404d1d6cc6  jnz 0x000070404D1D79FC
000070404d1d6ccc  vmovaps xmm1, [rsp+0x20]
000070404d1d6cd2  vmovaps xmm15, [rsp+0x20]
000070404d1d6cd8  por xmm1, xmm15
000070404d1d6cdd  movaps [r15+0x210], xmm1
000070404d1d6ce5  vmovaps xmm15, [rsp+0x80]
000070404d1d6cee  vmovaps xmm14, [rsp+0x80]
000070404d1d6cf7  por xmm15, xmm14
000070404d1d6cfc  movaps [r15+0x1C0], xmm15
000070404d1d6d04  vmovaps xmm14, [rsp+0x70]
000070404d1d6d0a  vmovaps xmm13, [rsp+0x70]
000070404d1d6d10  por xmm14, xmm13
000070404d1d6d15  movaps [r15+0x280], xmm14
000070404d1d6d1d  vmovaps xmm13, [rsp+0x60]
000070404d1d6d23  vmovaps [rsp+0x20], xmm1
000070404d1d6d29  vmovaps xmm1, [rsp+0x60]
000070404d1d6d2f  por xmm13, xmm1
000070404d1d6d34  movaps [r15+0x2A0], xmm13
000070404d1d6d3c  vmovaps xmm1, [rsp+0x50]
000070404d1d6d42  vmovaps [rsp+0x60], xmm15
000070404d1d6d48  vmovaps xmm15, [rsp+0x50]
000070404d1d6d4e  por xmm1, xmm15
000070404d1d6d53  movaps [r15+0x2E0], xmm1
000070404d1d6d5b  vmovaps [rsp+0x50], xmm2
000070404d1d6d61  vmovaps xmm15, [rsp+0x50]
000070404d1d6d67  por xmm2, xmm15
000070404d1d6d6c  movaps [r15+0x1F0], xmm2
000070404d1d6d74  vmovaps xmm15, [rsp+0x90]
000070404d1d6d7d  vmovaps [rsp+0x50], xmm1
000070404d1d6d83  vmovaps xmm1, [rsp+0x90]
000070404d1d6d8c  por xmm15, xmm1
000070404d1d6d91  movaps [r15+0x250], xmm15
000070404d1d6d99  vmovaps xmm1, [rsp+0xD0]
000070404d1d6da2  vmovaps xmm15, [rsp+0xD0]
000070404d1d6dab  por xmm1, xmm15
000070404d1d6db0  movaps [r15+0x260], xmm1
000070404d1d6db8  vmovaps xmm15, [rsp+0x110]
000070404d1d6dc1  vmovaps [rsp+0x70], xmm1
000070404d1d6dc7  vmovaps xmm1, [rsp+0x110]
000070404d1d6dd0  por xmm15, xmm1
000070404d1d6dd5  movaps [r15+0x290], xmm15
000070404d1d6ddd  vmovaps xmm1, [rsp+0x100]
000070404d1d6de6  vmovaps [rsp+0x80], xmm15
000070404d1d6def  vmovaps xmm15, [rsp+0x100]
000070404d1d6df8  por xmm1, xmm15
000070404d1d6dfd  movaps [r15+0x2C0], xmm1
000070404d1d6e05  movq xmm15, qword ptr [r15+0x240]
000070404d1d6e0e  vmovaps [rsp+0x90], xmm15
000070404d1d6e17  vpermilpd xmm15, xmm15, 0x00
000070404d1d6e1d  vmovaps [rsp+0xD0], xmm1
000070404d1d6e26  vmovaps xmm1, [rsp+0x40]
000070404d1d6e2c  vmovaps [rsp+0x40], xmm15
000070404d1d6e32  vmovaps xmm15, [rsp+0x20]
000070404d1d6e38  vmovaps [rsp+0x20], xmm14
000070404d1d6e3e  vmovaps xmm14, [rsp+0x40]
000070404d1d6e44  vmovaps [rsp+0x40], xmm13
000070404d1d6e4a  vmovaps [rsp+0x100], xmm12
000070404d1d6e53  movaps xmm13, xmm1
000070404d1d6e57  vfmadd231pd xmm13, xmm15, xmm14
000070404d1d6e5c  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1d6e62  vptest xmm12, xmm12
000070404d1d6e67  jnz 0x000070404D1D7B55
000070404d1d6e6d  vmovaps xmm1, [rsp+0x90]
000070404d1d6e76  vpermilpd xmm1, xmm1, 0x00
000070404d1d6e7c  vmovaps xmm15, [rsp+0xB0]
000070404d1d6e85  vmovaps xmm14, [rsp+0x50]
000070404d1d6e8b  vmovaps [rsp+0x50], xmm13
000070404d1d6e91  movaps xmm12, xmm15
000070404d1d6e95  vfmadd231pd xmm12, xmm14, xmm1
000070404d1d6e9a  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1d6ea0  vptest xmm13, xmm13
000070404d1d6ea5  jnz 0x000070404D1D7CAE
000070404d1d6eab  vmovaps xmm1, [rsp+0x90]
000070404d1d6eb4  vpermilpd xmm1, xmm1, 0x00
000070404d1d6eba  vmovaps xmm15, [rsp+0x130]
000070404d1d6ec3  vmovaps xmm14, [rsp+0x60]
000070404d1d6ec9  vmovaps [rsp+0x60], xmm12
000070404d1d6ecf  movaps xmm13, xmm15
000070404d1d6ed3  vfmadd231pd xmm13, xmm14, xmm1
000070404d1d6ed8  vcmppd xmm12, xmm13, xmm13, 0x03
000070404d1d6ede  vptest xmm12, xmm12
000070404d1d6ee3  jnz 0x000070404D1D7E07
000070404d1d6ee9  vmovaps xmm1, [rsp+0x120]
000070404d1d6ef2  vmovaps xmm15, [rsp+0x120]
000070404d1d6efb  por xmm1, xmm15
000070404d1d6f00  movaps [r15+0x1D0], xmm1
000070404d1d6f08  vmovaps xmm15, [rsp+0x90]
000070404d1d6f11  vpermilpd xmm15, xmm15, 0x00
000070404d1d6f17  vmovaps xmm14, [rsp+0x100]
000070404d1d6f20  vmovaps [rsp+0x90], xmm1
000070404d1d6f29  movaps xmm12, xmm14
000070404d1d6f2d  vfmadd231pd xmm12, xmm2, xmm15
000070404d1d6f32  vcmppd xmm1, xmm12, xmm12, 0x03
000070404d1d6f38  vptest xmm1, xmm1
000070404d1d6f3d  jnz 0x000070404D1D7F60
000070404d1d6f43  vmovaps [rsp+0xB0], xmm3
000070404d1d6f4c  vmovaps xmm1, [rsp+0xB0]
000070404d1d6f55  por xmm3, xmm1
000070404d1d6f59  movaps [r15+0x200], xmm3
000070404d1d6f61  vmovaps xmm1, [rsp+0xF0]
000070404d1d6f6a  vmovaps xmm15, [rsp+0xF0]
000070404d1d6f73  por xmm1, xmm15
000070404d1d6f78  movaps [r15+0x1E0], xmm1
000070404d1d6f80  vmovaps [rsp+0xB0], xmm7
000070404d1d6f89  vmovaps xmm1, [rsp+0xB0]
000070404d1d6f92  por xmm7, xmm1
000070404d1d6f96  movaps [r15+0x2B0], xmm7
000070404d1d6f9e  vmovaps [rsp+0xB0], xmm8
000070404d1d6fa7  vmovaps xmm1, [rsp+0xB0]
000070404d1d6fb0  por xmm8, xmm1
000070404d1d6fb5  movaps [r15+0x300], xmm8
000070404d1d6fbd  vmovaps [rsp+0xB0], xmm5
000070404d1d6fc6  vpermilpd xmm5, xmm5, 0x00
000070404d1d6fcc  vmovaps xmm14, [rsp+0x50]
000070404d1d6fd2  vmovaps xmm8, [rsp+0x70]
000070404d1d6fd8  vmovaps [rsp+0x50], xmm1
000070404d1d6fde  movaps xmm2, xmm14
000070404d1d6fe2  vfmadd231pd xmm2, xmm8, xmm5
000070404d1d6fe7  vcmppd xmm1, xmm2, xmm2, 0x03
000070404d1d6fec  vptest xmm1, xmm1
000070404d1d6ff1  jnz 0x000070404D1D80B9
000070404d1d6ff7  vmovaps xmm1, [rsp+0xB0]
000070404d1d7000  vpermilpd xmm1, xmm1, 0x00
000070404d1d7006  vmovaps xmm14, [rsp+0x60]
000070404d1d700c  vmovaps xmm8, [rsp+0xD0]
000070404d1d7015  vmovaps [rsp+0x60], xmm15
000070404d1d701b  movaps xmm5, xmm14
000070404d1d701f  vfmadd231pd xmm5, xmm8, xmm1
000070404d1d7024  vcmppd xmm15, xmm5, xmm5, 0x03
000070404d1d7029  vptest xmm15, xmm15
000070404d1d702e  jnz 0x000070404D1D8210
000070404d1d7034  vmovaps xmm1, [rsp+0xB0]
000070404d1d703d  vpermilpd xmm1, xmm1, 0x00
000070404d1d7043  vmovaps xmm14, [rsp+0x20]
000070404d1d7049  movaps xmm15, xmm13
000070404d1d704d  vfmadd231pd xmm15, xmm14, xmm1
000070404d1d7052  vcmppd xmm8, xmm15, xmm15, 0x03
000070404d1d7058  vptest xmm8, xmm8
000070404d1d705d  jnz 0x000070404D1D8367
000070404d1d7063  vmovaps xmm1, [rsp+0xB0]
000070404d1d706c  vpermilpd xmm1, xmm1, 0x00
000070404d1d7072  vmovaps xmm14, [rsp+0x90]
000070404d1d707b  movaps xmm13, xmm12
000070404d1d707f  vfmadd231pd xmm13, xmm14, xmm1
000070404d1d7084  vcmppd xmm8, xmm13, xmm13, 0x03
000070404d1d708a  vptest xmm8, xmm8
000070404d1d708f  jnz 0x000070404D1D84C0
000070404d1d7095  vmovaps [rsp+0x20], xmm6
000070404d1d709b  vmovaps xmm1, [rsp+0x20]
000070404d1d70a1  por xmm6, xmm1
000070404d1d70a5  movaps [r15+0x180], xmm6
000070404d1d70ad  vmovaps [rsp+0x20], xmm9
000070404d1d70b3  vmovaps xmm1, [rsp+0x20]
000070404d1d70b9  por xmm9, xmm1
000070404d1d70be  movaps [r15+0x2D0], xmm9
000070404d1d70c6  vmovaps [rsp+0x20], xmm10
000070404d1d70cc  vmovaps xmm1, [rsp+0x20]
000070404d1d70d2  por xmm10, xmm1
000070404d1d70d7  movaps [r15+0x2F0], xmm10
000070404d1d70df  vmovaps [rsp+0x20], xmm4
000070404d1d70e5  vpermilpd xmm4, xmm4, 0x00
000070404d1d70eb  vmovaps xmm14, [rsp+0x50]
000070404d1d70f1  movaps xmm12, xmm5
000070404d1d70f5  vfmadd231pd xmm12, xmm14, xmm4
000070404d1d70fa  vcmppd xmm10, xmm12, xmm12, 0x03
000070404d1d7100  vptest xmm10, xmm10
000070404d1d7105  jnz 0x000070404D1D8619
000070404d1d710b  vmovaps xmm14, [rsp+0x20]
000070404d1d7111  vpermilpd xmm14, xmm14, 0x00
000070404d1d7117  movaps xmm10, xmm2
000070404d1d711b  vfmadd231pd xmm10, xmm6, xmm14
000070404d1d7120  vcmppd xmm8, xmm10, xmm10, 0x03
000070404d1d7126  vptest xmm8, xmm8
000070404d1d712b  jnz 0x000070404D1D8771
000070404d1d7131  lea rax, [r14+0x80]
000070404d1d7138  movups xmm14, [r13+rax*1]
000070404d1d713e  movaps [r15+0x190], xmm14
000070404d1d7146  vmovaps xmm8, [rsp+0x20]
000070404d1d714c  vpermilpd xmm8, xmm8, 0x00
000070404d1d7152  vmovaps xmm6, [rsp+0x80]
000070404d1d715b  movaps xmm5, xmm15
000070404d1d715f  vfmadd231pd xmm5, xmm6, xmm8
000070404d1d7164  vcmppd xmm4, xmm5, xmm5, 0x03
000070404d1d7169  vptest xmm4, xmm4
000070404d1d716e  jnz 0x000070404D1D88D3
000070404d1d7174  vmovaps xmm15, [rsp+0x20]
000070404d1d717a  vpermilpd xmm15, xmm15, 0x00
000070404d1d7180  movaps xmm8, xmm13
000070404d1d7184  vfmadd231pd xmm8, xmm1, xmm15
000070404d1d7189  vcmppd xmm6, xmm8, xmm8, 0x03
000070404d1d718f  vptest xmm6, xmm6
000070404d1d7194  jnz 0x000070404D1D8A2A
000070404d1d719a  vmovaps xmm1, [rsp+0x30]
000070404d1d71a0  vmovaps xmm15, [rsp+0x30]
000070404d1d71a6  por xmm1, xmm15
000070404d1d71ab  movaps [r15+0x160], xmm1
000070404d1d71b3  lea rax, [r14+0x40]
000070404d1d71b7  movups xmm15, [r13+rax*1]
000070404d1d71bd  lea rax, [r14+0x50]
000070404d1d71c1  movups xmm13, [r13+rax*1]
000070404d1d71c7  movaps [r15+0x1B0], xmm15
000070404d1d71cf  movaps [r15+0x1A0], xmm13
000070404d1d71d7  vmovaps xmm6, [rsp+0xC0]
000070404d1d71e0  vpermilpd xmm6, xmm6, 0x00
000070404d1d71e6  movaps xmm4, xmm12
000070404d1d71ea  vfmadd231pd xmm4, xmm9, xmm6
000070404d1d71ef  vcmppd xmm2, xmm4, xmm4, 0x03
000070404d1d71f4  vptest xmm2, xmm2
000070404d1d71f9  jnz 0x000070404D1D8B97
000070404d1d71ff  vmovaps xmm12, [rsp+0xC0]
000070404d1d7208  vpermilpd xmm12, xmm12, 0x00
000070404d1d720e  movaps xmm9, xmm10
000070404d1d7212  vfmadd231pd xmm9, xmm1, xmm12
000070404d1d7217  vcmppd xmm6, xmm9, xmm9, 0x03
000070404d1d721d  vptest xmm6, xmm6
000070404d1d7222  jnz 0x000070404D1D8CEE
000070404d1d7228  vmovaps xmm1, [rsp+0xC0]
000070404d1d7231  vpermilpd xmm1, xmm1, 0x00
000070404d1d7237  vmovaps xmm12, [rsp+0x40]
000070404d1d723d  movaps xmm10, xmm5
000070404d1d7241  vfmadd231pd xmm10, xmm12, xmm1
000070404d1d7246  vcmppd xmm6, xmm10, xmm10, 0x03
000070404d1d724c  vptest xmm6, xmm6
000070404d1d7251  jnz 0x000070404D1D8E47
000070404d1d7257  vmovaps xmm1, [rsp+0xC0]
000070404d1d7260  vpermilpd xmm1, xmm1, 0x00
000070404d1d7266  vmovaps xmm12, [rsp+0x60]
000070404d1d726c  movaps xmm6, xmm8
000070404d1d7270  vfmadd231pd xmm6, xmm12, xmm1
000070404d1d7275  vcmppd xmm5, xmm6, xmm6, 0x03
000070404d1d727a  vptest xmm5, xmm5
000070404d1d727f  jnz 0x000070404D1D8F9F
000070404d1d7285  lea rax, [r14+0x60]
000070404d1d7289  movups xmm1, [r13+rax*1]
000070404d1d728f  lea rax, [r14+0x70]
000070404d1d7293  movups xmm12, [r13+rax*1]
000070404d1d7299  movaps [r15+0x150], xmm1
000070404d1d72a1  movaps [r15+0x120], xmm12
000070404d1d72a9  vmovaps [rsp+0x20], xmm11
000070404d1d72af  vpermilpd xmm11, xmm11, 0x00
000070404d1d72b5  movaps xmm8, xmm4
000070404d1d72b9  vfmadd231pd xmm8, xmm13, xmm11
000070404d1d72be  vcmppd xmm5, xmm8, xmm8, 0x03
000070404d1d72c4  vptest xmm5, xmm5
000070404d1d72c9  jnz 0x000070404D1D910A
000070404d1d72cf  vmovaps xmm13, [rsp+0x20]
000070404d1d72d5  vpermilpd xmm13, xmm13, 0x00
000070404d1d72db  movaps xmm11, xmm9
000070404d1d72df  vfmadd231pd xmm11, xmm1, xmm13
000070404d1d72e4  vcmppd xmm5, xmm11, xmm11, 0x03
000070404d1d72ea  vptest xmm5, xmm5
000070404d1d72ef  jnz 0x000070404D1D9263
000070404d1d72f5  vmovaps xmm1, [rsp+0x20]
000070404d1d72fb  vpermilpd xmm1, xmm1, 0x00
000070404d1d7301  movaps xmm13, xmm10
000070404d1d7305  vfmadd231pd xmm13, xmm7, xmm1
000070404d1d730a  vcmppd xmm9, xmm13, xmm13, 0x03
000070404d1d7310  vptest xmm9, xmm9
000070404d1d7315  jnz 0x000070404D1D93BC
000070404d1d731b  vmovaps xmm1, [rsp+0x20]
000070404d1d7321  vpermilpd xmm1, xmm1, 0x00
000070404d1d7327  movaps xmm10, xmm6
000070404d1d732b  vfmadd231pd xmm10, xmm15, xmm1
000070404d1d7330  vcmppd xmm9, xmm10, xmm10, 0x03
000070404d1d7336  vptest xmm9, xmm9
000070404d1d733b  jnz 0x000070404D1D9514
000070404d1d7341  lea rax, [r14+0x20]
000070404d1d7345  movups xmm1, [r13+rax*1]
000070404d1d734b  lea rax, [r14+0x30]
000070404d1d734f  movups xmm15, [r13+rax*1]
000070404d1d7355  vmovaps xmm9, [rsp+0xA0]
000070404d1d735e  vpermilpd xmm9, xmm9, 0x00
000070404d1d7364  movaps xmm7, xmm8
000070404d1d7368  vfmadd231pd xmm7, xmm3, xmm9
000070404d1d736d  vcmppd xmm6, xmm7, xmm7, 0x03
000070404d1d7372  vptest xmm6, xmm6
000070404d1d7377  jnz 0x000070404D1D9680
000070404d1d737d  vmovaps xmm9, [rsp+0xA0]
000070404d1d7386  vpermilpd xmm9, xmm9, 0x00
000070404d1d738c  movaps xmm8, xmm11
000070404d1d7390  vfmadd231pd xmm8, xmm14, xmm9
000070404d1d7395  vcmppd xmm6, xmm8, xmm8, 0x03
000070404d1d739b  vptest xmm6, xmm6
000070404d1d73a0  jnz 0x000070404D1D97D7
000070404d1d73a6  vmovaps xmm14, [rsp+0xA0]
000070404d1d73af  vpermilpd xmm14, xmm14, 0x00
000070404d1d73b5  movaps xmm11, xmm13
000070404d1d73b9  vfmadd231pd xmm11, xmm12, xmm14
000070404d1d73be  vcmppd xmm9, xmm11, xmm11, 0x03
000070404d1d73c4  vptest xmm9, xmm9
000070404d1d73c9  jnz 0x000070404D1D9931
000070404d1d73cf  vmovaps xmm14, [rsp+0xA0]
000070404d1d73d8  vpermilpd xmm14, xmm14, 0x00
000070404d1d73de  movaps xmm12, xmm10
000070404d1d73e2  vfmadd231pd xmm12, xmm15, xmm14
000070404d1d73e7  vcmppd xmm13, xmm12, xmm12, 0x03
000070404d1d73ed  vptest xmm13, xmm13
000070404d1d73f2  jnz 0x000070404D1D9A8B
000070404d1d73f8  lea rax, [r14+0x90]
000070404d1d73ff  movups xmm15, [r13+rax*1]
000070404d1d7405  lea rax, [r14+0xA0]
000070404d1d740c  movups xmm14, [r13+rax*1]
000070404d1d7412  movaps [r15+0x140], xmm15
000070404d1d741a  movaps [r15+0x130], xmm14
000070404d1d7422  vmovaps xmm13, [rsp+0x10]
000070404d1d7428  vpermilpd xmm13, xmm13, 0x00
000070404d1d742e  movaps xmm10, xmm7
000070404d1d7432  vfmadd231pd xmm10, xmm1, xmm13
000070404d1d7437  vcmppd xmm9, xmm10, xmm10, 0x03
000070404d1d743d  vptest xmm9, xmm9
000070404d1d7442  jnz 0x000070404D1D9BF9
000070404d1d7448  movaps [r15+0x220], xmm10
000070404d1d7450  lea rax, [r14+0x10]
000070404d1d7454  movups xmm1, [r13+rax*1]
000070404d1d745a  movaps [r15+0x240], xmm1
000070404d1d7462  vmovaps xmm13, [rsp+0x10]
000070404d1d7468  vpermilpd xmm13, xmm13, 0x00
000070404d1d746e  movaps xmm9, xmm8
000070404d1d7472  vfmadd231pd xmm9, xmm14, xmm13
000070404d1d7477  vcmppd xmm7, xmm9, xmm9, 0x03
000070404d1d747d  vptest xmm7, xmm7
000070404d1d7482  jnz 0x000070404D1D9D5B
000070404d1d7488  movaps [r15+0x110], xmm9
000070404d1d7490  vmovaps xmm14, [rsp+0x10]
000070404d1d7496  vpermilpd xmm14, xmm14, 0x00
000070404d1d749c  movaps xmm13, xmm11
000070404d1d74a0  vfmadd231pd xmm13, xmm15, xmm14
000070404d1d74a5  vcmppd xmm8, xmm13, xmm13, 0x03
000070404d1d74ab  vptest xmm8, xmm8
000070404d1d74b0  jnz 0x000070404D1D9EB5
000070404d1d74b6  movaps [r15+0x170], xmm13
000070404d1d74be  vmovaps xmm15, [rsp+0x10]
000070404d1d74c4  vpermilpd xmm15, xmm15, 0x00
000070404d1d74ca  movaps xmm14, xmm12
000070404d1d74ce  vfmadd231pd xmm14, xmm1, xmm15
000070404d1d74d3  vcmppd xmm11, xmm14, xmm14, 0x03
000070404d1d74d9  vptest xmm11, xmm11
000070404d1d74de  jnz 0x000070404D1DA00F
000070404d1d74e4  movaps [r15+0x230], xmm14
000070404d1d74ec  mov rax, [rsp+0xE0]
000070404d1d74f4  movups [r13+rax*1], xmm9
000070404d1d74fa  lea r14, [rax+0x10]
000070404d1d74fe  movups [r13+r14*1], xmm13
000070404d1d7504  lea r14, [rax+0x20]
000070404d1d7508  movups [r13+r14*1], xmm10
000070404d1d750e  lea r14, [rax+0x30]
000070404d1d7512  movups [r13+r14*1], xmm14
000070404d1d7518  mov eax, [r15+0x108]
000070404d1d751f  sahf
000070404d1d7520  jnz 0x000070404D1D7552
000070404d1d7522  cmp dword ptr [r15+0x318], 0x00
000070404d1d752a  jz 0x000070404D1D67A0
000070404d1d7530  nop [rax+rax*1], ax
000070404d1d7539  nop [rax+rax*1], eax
000070404d1d7541  mov eax, 0x4103F0
000070404d1d7546  mov [r15+0x100], rax
000070404d1d754d  jmp 0x000070404CFFE110
000070404d1d7552  cmp dword ptr [r15+0x318], 0x00
000070404d1d755a  jz 0x000070404D1D2E40
000070404d1d7560  nop [rax+rax*1], ax
000070404d1d7569  nop [rax+rax*1], eax
000070404d1d7571  mov eax, 0x410274
000070404d1d7576  mov [r15+0x100], rax
000070404d1d757d  jmp 0x000070404CFFE110
000070404d1d7582  int3
000070404d1d7583  call 0x000070404D0E27E0
000070404d1d7588  jmp 0x000070404D1D6860
000070404d1d758d  call 0x000070404D0E1570
000070404d1d7592  jmp 0x000070404D1D6869
000070404d1d7597  call 0x000070404D0E27E0
000070404d1d759c  jmp 0x000070404D1D68B2
000070404d1d75a1  call 0x000070404D0E1570
000070404d1d75a6  jmp 0x000070404D1D68BB
000070404d1d75ab  call 0x000070404D0E27E0
000070404d1d75b0  jmp 0x000070404D1D6953
000070404d1d75b5  call 0x000070404D0E1570
000070404d1d75ba  jmp 0x000070404D1D695C
000070404d1d75bf  call 0x000070404D00DC20
000070404d1d75c4  jmp 0x000070404D1D6A47
000070404d1d75c9  call 0x000070404D0D64F0
000070404d1d75ce  jmp 0x000070404D1D6A76
000070404d1d75d3  call 0x000070404D0B47C0
000070404d1d75d8  jmp 0x000070404D1D6A91
000070404d1d75dd  sub rsp, 0x08
000070404d1d75e1  push rax
000070404d1d75e2  push rcx
000070404d1d75e3  push rdx
000070404d1d75e4  push rdi
000070404d1d75e5  push rsi
000070404d1d75e6  push r8
000070404d1d75e8  push r9
000070404d1d75ea  push r10
000070404d1d75ec  push r11
000070404d1d75ee  sub rsp, 0xF0
000070404d1d75f5  vmovaps [rsp], xmm0
000070404d1d75fa  vmovaps [rsp+0x10], xmm1
000070404d1d7600  vmovaps [rsp+0x20], xmm2
000070404d1d7606  vmovaps [rsp+0x30], xmm3
000070404d1d760c  vmovaps [rsp+0x40], xmm4
000070404d1d7612  vmovaps [rsp+0x50], xmm5
000070404d1d7618  vmovaps [rsp+0x60], xmm6
000070404d1d761e  vmovaps [rsp+0x70], xmm7
000070404d1d7624  vmovaps [rsp+0x80], xmm8
000070404d1d762d  vmovaps [rsp+0x90], xmm9
000070404d1d7636  vmovaps [rsp+0xA0], xmm10
000070404d1d763f  vmovaps [rsp+0xB0], xmm11
000070404d1d7648  vmovaps [rsp+0xC0], xmm12
000070404d1d7651  vmovaps [rsp+0xD0], xmm14
000070404d1d765a  vmovaps [rsp+0xE0], xmm15
000070404d1d7663  sub rsp, 0x40
000070404d1d7667  lea rdi, [rsp]
000070404d1d766b  lea rsi, [rsp+0x10]
000070404d1d7670  lea rdx, [rsp+0x20]
000070404d1d7675  lea rcx, [rsp+0x30]
000070404d1d767a  mov r8d, 0x00
000070404d1d7680  lea r9, [r15+0x3A8]
000070404d1d7687  movaps [rdi], xmm13
000070404d1d768b  movaps [rsi], xmm1
000070404d1d768e  movaps [rdx], xmm15
000070404d1d7692  movaps [rcx], xmm14
000070404d1d7696  mov rax, 0x607928F07A50
000070404d1d76a0  call rax
000070404d1d76a2  movaps xmm13, [rsp]
000070404d1d76a7  add rsp, 0x40
000070404d1d76ab  vmovaps xmm0, [rsp]
000070404d1d76b0  vmovaps xmm1, [rsp+0x10]
000070404d1d76b6  vmovaps xmm2, [rsp+0x20]
000070404d1d76bc  vmovaps xmm3, [rsp+0x30]
000070404d1d76c2  vmovaps xmm4, [rsp+0x40]
000070404d1d76c8  vmovaps xmm5, [rsp+0x50]
000070404d1d76ce  vmovaps xmm6, [rsp+0x60]
000070404d1d76d4  vmovaps xmm7, [rsp+0x70]
000070404d1d76da  vmovaps xmm8, [rsp+0x80]
000070404d1d76e3  vmovaps xmm9, [rsp+0x90]
000070404d1d76ec  vmovaps xmm10, [rsp+0xA0]
000070404d1d76f5  vmovaps xmm11, [rsp+0xB0]
000070404d1d76fe  vmovaps xmm12, [rsp+0xC0]
000070404d1d7707  vmovaps xmm14, [rsp+0xD0]
000070404d1d7710  vmovaps xmm15, [rsp+0xE0]
000070404d1d7719  add rsp, 0xF0
000070404d1d7720  pop r11
000070404d1d7722  pop r10
000070404d1d7724  pop r9
000070404d1d7726  pop r8
000070404d1d7728  pop rsi
000070404d1d7729  pop rdi
000070404d1d772a  pop rdx
000070404d1d772b  pop rcx
000070404d1d772c  pop rax
000070404d1d772d  add rsp, 0x08
000070404d1d7731  jmp 0x000070404D1D6B04
000070404d1d7736  sub rsp, 0x08
000070404d1d773a  push rax
000070404d1d773b  push rcx
000070404d1d773c  push rdx
000070404d1d773d  push rdi
000070404d1d773e  push rsi
000070404d1d773f  push r8
000070404d1d7741  push r9
000070404d1d7743  push r10
000070404d1d7745  push r11
000070404d1d7747  sub rsp, 0xF0
000070404d1d774e  vmovaps [rsp], xmm0
000070404d1d7753  vmovaps [rsp+0x10], xmm1
000070404d1d7759  vmovaps [rsp+0x20], xmm2
000070404d1d775f  vmovaps [rsp+0x30], xmm3
000070404d1d7765  vmovaps [rsp+0x40], xmm4
000070404d1d776b  vmovaps [rsp+0x50], xmm5
000070404d1d7771  vmovaps [rsp+0x60], xmm6
000070404d1d7777  vmovaps [rsp+0x70], xmm7
000070404d1d777d  vmovaps [rsp+0x80], xmm8
000070404d1d7786  vmovaps [rsp+0x90], xmm9
000070404d1d778f  vmovaps [rsp+0xA0], xmm10
000070404d1d7798  vmovaps [rsp+0xB0], xmm11
000070404d1d77a1  vmovaps [rsp+0xC0], xmm13
000070404d1d77aa  vmovaps [rsp+0xD0], xmm14
000070404d1d77b3  vmovaps [rsp+0xE0], xmm15
000070404d1d77bc  sub rsp, 0x40
000070404d1d77c0  lea rdi, [rsp]
000070404d1d77c4  lea rsi, [rsp+0x10]
000070404d1d77c9  lea rdx, [rsp+0x20]
000070404d1d77ce  lea rcx, [rsp+0x30]
000070404d1d77d3  mov r8d, 0x00
000070404d1d77d9  lea r9, [r15+0x3A8]
000070404d1d77e0  movaps [rdi], xmm12
000070404d1d77e4  movaps [rsi], xmm15
000070404d1d77e8  movaps [rdx], xmm1
000070404d1d77eb  movaps [rcx], xmm14
000070404d1d77ef  mov rax, 0x607928F07A50
000070404d1d77f9  call rax
000070404d1d77fb  movaps xmm12, [rsp]
000070404d1d7800  add rsp, 0x40
000070404d1d7804  vmovaps xmm0, [rsp]
000070404d1d7809  vmovaps xmm1, [rsp+0x10]
000070404d1d780f  vmovaps xmm2, [rsp+0x20]
000070404d1d7815  vmovaps xmm3, [rsp+0x30]
000070404d1d781b  vmovaps xmm4, [rsp+0x40]
000070404d1d7821  vmovaps xmm5, [rsp+0x50]
000070404d1d7827  vmovaps xmm6, [rsp+0x60]
000070404d1d782d  vmovaps xmm7, [rsp+0x70]
000070404d1d7833  vmovaps xmm8, [rsp+0x80]
000070404d1d783c  vmovaps xmm9, [rsp+0x90]
000070404d1d7845  vmovaps xmm10, [rsp+0xA0]
000070404d1d784e  vmovaps xmm11, [rsp+0xB0]
000070404d1d7857  vmovaps xmm13, [rsp+0xC0]
000070404d1d7860  vmovaps xmm14, [rsp+0xD0]
000070404d1d7869  vmovaps xmm15, [rsp+0xE0]
000070404d1d7872  add rsp, 0xF0
000070404d1d7879  pop r11
000070404d1d787b  pop r10
000070404d1d787d  pop r9
000070404d1d787f  pop r8
000070404d1d7881  pop rsi
000070404d1d7882  pop rdi
000070404d1d7883  pop rdx
000070404d1d7884  pop rcx
000070404d1d7885  pop rax
000070404d1d7886  add rsp, 0x08
000070404d1d788a  jmp 0x000070404D1D6B32
000070404d1d788f  call 0x000070404D0B52F0
000070404d1d7894  jmp 0x000070404D1D6C1E
000070404d1d7899  sub rsp, 0x08
000070404d1d789d  push rax
000070404d1d789e  push rcx
000070404d1d789f  push rdx
000070404d1d78a0  push rdi
000070404d1d78a1  push rsi
000070404d1d78a2  push r8
000070404d1d78a4  push r9
000070404d1d78a6  push r10
000070404d1d78a8  push r11
000070404d1d78aa  sub rsp, 0xF0
000070404d1d78b1  vmovaps [rsp], xmm0
000070404d1d78b6  vmovaps [rsp+0x10], xmm1
000070404d1d78bc  vmovaps [rsp+0x20], xmm2
000070404d1d78c2  vmovaps [rsp+0x30], xmm3
000070404d1d78c8  vmovaps [rsp+0x40], xmm4
000070404d1d78ce  vmovaps [rsp+0x50], xmm5
000070404d1d78d4  vmovaps [rsp+0x60], xmm6
000070404d1d78da  vmovaps [rsp+0x70], xmm7
000070404d1d78e0  vmovaps [rsp+0x80], xmm8
000070404d1d78e9  vmovaps [rsp+0x90], xmm9
000070404d1d78f2  vmovaps [rsp+0xA0], xmm10
000070404d1d78fb  vmovaps [rsp+0xB0], xmm11
000070404d1d7904  vmovaps [rsp+0xC0], xmm12
000070404d1d790d  vmovaps [rsp+0xD0], xmm14
000070404d1d7916  vmovaps [rsp+0xE0], xmm15
000070404d1d791f  sub rsp, 0x40
000070404d1d7923  lea rdi, [rsp]
000070404d1d7927  lea rsi, [rsp+0x10]
000070404d1d792c  lea rdx, [rsp+0x20]
000070404d1d7931  lea rcx, [rsp+0x30]
000070404d1d7936  mov r8d, 0x00
000070404d1d793c  lea r9, [r15+0x3A8]
000070404d1d7943  movaps [rdi], xmm13
000070404d1d7947  movaps [rsi], xmm1
000070404d1d794a  movaps [rdx], xmm15
000070404d1d794e  movaps [rcx], xmm14
000070404d1d7952  mov rax, 0x607928F07A50
000070404d1d795c  call rax
000070404d1d795e  movaps xmm13, [rsp]
000070404d1d7963  add rsp, 0x40
000070404d1d7967  vmovaps xmm0, [rsp]
000070404d1d796c  vmovaps xmm1, [rsp+0x10]
000070404d1d7972  vmovaps xmm2, [rsp+0x20]
000070404d1d7978  vmovaps xmm3, [rsp+0x30]
000070404d1d797e  vmovaps xmm4, [rsp+0x40]
000070404d1d7984  vmovaps xmm5, [rsp+0x50]
000070404d1d798a  vmovaps xmm6, [rsp+0x60]
000070404d1d7990  vmovaps xmm7, [rsp+0x70]
000070404d1d7996  vmovaps xmm8, [rsp+0x80]
000070404d1d799f  vmovaps xmm9, [rsp+0x90]
000070404d1d79a8  vmovaps xmm10, [rsp+0xA0]
000070404d1d79b1  vmovaps xmm11, [rsp+0xB0]
000070404d1d79ba  vmovaps xmm12, [rsp+0xC0]
000070404d1d79c3  vmovaps xmm14, [rsp+0xD0]
000070404d1d79cc  vmovaps xmm15, [rsp+0xE0]
000070404d1d79d5  add rsp, 0xF0
000070404d1d79dc  pop r11
000070404d1d79de  pop r10
000070404d1d79e0  pop r9
000070404d1d79e2  pop r8
000070404d1d79e4  pop rsi
000070404d1d79e5  pop rdi
000070404d1d79e6  pop rdx
000070404d1d79e7  pop rcx
000070404d1d79e8  pop rax
000070404d1d79e9  add rsp, 0x08
000070404d1d79ed  jmp 0x000070404D1D6C93
000070404d1d79f2  call 0x000070404CFFF430
000070404d1d79f7  jmp 0x000070404D1D6CA0
000070404d1d79fc  sub rsp, 0x08
000070404d1d7a00  push rax
000070404d1d7a01  push rcx
000070404d1d7a02  push rdx
000070404d1d7a03  push rdi
000070404d1d7a04  push rsi
000070404d1d7a05  push r8
000070404d1d7a07  push r9
000070404d1d7a09  push r10
000070404d1d7a0b  push r11
000070404d1d7a0d  sub rsp, 0xF0
000070404d1d7a14  vmovaps [rsp], xmm0
000070404d1d7a19  vmovaps [rsp+0x10], xmm1
000070404d1d7a1f  vmovaps [rsp+0x20], xmm2
000070404d1d7a25  vmovaps [rsp+0x30], xmm3
000070404d1d7a2b  vmovaps [rsp+0x40], xmm4
000070404d1d7a31  vmovaps [rsp+0x50], xmm5
000070404d1d7a37  vmovaps [rsp+0x60], xmm6
000070404d1d7a3d  vmovaps [rsp+0x70], xmm7
000070404d1d7a43  vmovaps [rsp+0x80], xmm8
000070404d1d7a4c  vmovaps [rsp+0x90], xmm9
000070404d1d7a55  vmovaps [rsp+0xA0], xmm10
000070404d1d7a5e  vmovaps [rsp+0xB0], xmm11
000070404d1d7a67  vmovaps [rsp+0xC0], xmm13
000070404d1d7a70  vmovaps [rsp+0xD0], xmm14
000070404d1d7a79  vmovaps [rsp+0xE0], xmm15
000070404d1d7a82  sub rsp, 0x40
000070404d1d7a86  lea rdi, [rsp]
000070404d1d7a8a  lea rsi, [rsp+0x10]
000070404d1d7a8f  lea rdx, [rsp+0x20]
000070404d1d7a94  lea rcx, [rsp+0x30]
000070404d1d7a99  mov r8d, 0x00
000070404d1d7a9f  lea r9, [r15+0x3A8]
000070404d1d7aa6  movaps [rdi], xmm12
000070404d1d7aaa  movaps [rsi], xmm15
000070404d1d7aae  movaps [rdx], xmm1
000070404d1d7ab1  movaps [rcx], xmm14
000070404d1d7ab5  mov rax, 0x607928F07A50
000070404d1d7abf  call rax
000070404d1d7ac1  movaps xmm12, [rsp]
000070404d1d7ac6  add rsp, 0x40
000070404d1d7aca  vmovaps xmm0, [rsp]
000070404d1d7acf  vmovaps xmm1, [rsp+0x10]
000070404d1d7ad5  vmovaps xmm2, [rsp+0x20]
000070404d1d7adb  vmovaps xmm3, [rsp+0x30]
000070404d1d7ae1  vmovaps xmm4, [rsp+0x40]
000070404d1d7ae7  vmovaps xmm5, [rsp+0x50]
000070404d1d7aed  vmovaps xmm6, [rsp+0x60]
000070404d1d7af3  vmovaps xmm7, [rsp+0x70]
000070404d1d7af9  vmovaps xmm8, [rsp+0x80]
000070404d1d7b02  vmovaps xmm9, [rsp+0x90]
000070404d1d7b0b  vmovaps xmm10, [rsp+0xA0]
000070404d1d7b14  vmovaps xmm11, [rsp+0xB0]
000070404d1d7b1d  vmovaps xmm13, [rsp+0xC0]
000070404d1d7b26  vmovaps xmm14, [rsp+0xD0]
000070404d1d7b2f  vmovaps xmm15, [rsp+0xE0]
000070404d1d7b38  add rsp, 0xF0
000070404d1d7b3f  pop r11
000070404d1d7b41  pop r10
000070404d1d7b43  pop r9
000070404d1d7b45  pop r8
000070404d1d7b47  pop rsi
000070404d1d7b48  pop rdi
000070404d1d7b49  pop rdx
000070404d1d7b4a  pop rcx
000070404d1d7b4b  pop rax
000070404d1d7b4c  add rsp, 0x08
000070404d1d7b50  jmp 0x000070404D1D6CCC
000070404d1d7b55  sub rsp, 0x08
000070404d1d7b59  push rax
000070404d1d7b5a  push rcx
000070404d1d7b5b  push rdx
000070404d1d7b5c  push rdi
000070404d1d7b5d  push rsi
000070404d1d7b5e  push r8
000070404d1d7b60  push r9
000070404d1d7b62  push r10
000070404d1d7b64  push r11
000070404d1d7b66  sub rsp, 0xF0
000070404d1d7b6d  vmovaps [rsp], xmm0
000070404d1d7b72  vmovaps [rsp+0x10], xmm1
000070404d1d7b78  vmovaps [rsp+0x20], xmm2
000070404d1d7b7e  vmovaps [rsp+0x30], xmm3
000070404d1d7b84  vmovaps [rsp+0x40], xmm4
000070404d1d7b8a  vmovaps [rsp+0x50], xmm5
000070404d1d7b90  vmovaps [rsp+0x60], xmm6
000070404d1d7b96  vmovaps [rsp+0x70], xmm7
000070404d1d7b9c  vmovaps [rsp+0x80], xmm8
000070404d1d7ba5  vmovaps [rsp+0x90], xmm9
000070404d1d7bae  vmovaps [rsp+0xA0], xmm10
000070404d1d7bb7  vmovaps [rsp+0xB0], xmm11
000070404d1d7bc0  vmovaps [rsp+0xC0], xmm12
000070404d1d7bc9  vmovaps [rsp+0xD0], xmm14
000070404d1d7bd2  vmovaps [rsp+0xE0], xmm15
000070404d1d7bdb  sub rsp, 0x40
000070404d1d7bdf  lea rdi, [rsp]
000070404d1d7be3  lea rsi, [rsp+0x10]
000070404d1d7be8  lea rdx, [rsp+0x20]
000070404d1d7bed  lea rcx, [rsp+0x30]
000070404d1d7bf2  mov r8d, 0x00
000070404d1d7bf8  lea r9, [r15+0x3A8]
000070404d1d7bff  movaps [rdi], xmm13
000070404d1d7c03  movaps [rsi], xmm1
000070404d1d7c06  movaps [rdx], xmm15
000070404d1d7c0a  movaps [rcx], xmm14
000070404d1d7c0e  mov rax, 0x607928F07A50
000070404d1d7c18  call rax
000070404d1d7c1a  movaps xmm13, [rsp]
000070404d1d7c1f  add rsp, 0x40
000070404d1d7c23  vmovaps xmm0, [rsp]
000070404d1d7c28  vmovaps xmm1, [rsp+0x10]
000070404d1d7c2e  vmovaps xmm2, [rsp+0x20]
000070404d1d7c34  vmovaps xmm3, [rsp+0x30]
000070404d1d7c3a  vmovaps xmm4, [rsp+0x40]
000070404d1d7c40  vmovaps xmm5, [rsp+0x50]
000070404d1d7c46  vmovaps xmm6, [rsp+0x60]
000070404d1d7c4c  vmovaps xmm7, [rsp+0x70]
000070404d1d7c52  vmovaps xmm8, [rsp+0x80]
000070404d1d7c5b  vmovaps xmm9, [rsp+0x90]
000070404d1d7c64  vmovaps xmm10, [rsp+0xA0]
000070404d1d7c6d  vmovaps xmm11, [rsp+0xB0]
000070404d1d7c76  vmovaps xmm12, [rsp+0xC0]
000070404d1d7c7f  vmovaps xmm14, [rsp+0xD0]
000070404d1d7c88  vmovaps xmm15, [rsp+0xE0]
000070404d1d7c91  add rsp, 0xF0
000070404d1d7c98  pop r11
000070404d1d7c9a  pop r10
000070404d1d7c9c  pop r9
000070404d1d7c9e  pop r8
000070404d1d7ca0  pop rsi
000070404d1d7ca1  pop rdi
000070404d1d7ca2  pop rdx
000070404d1d7ca3  pop rcx
000070404d1d7ca4  pop rax
000070404d1d7ca5  add rsp, 0x08
000070404d1d7ca9  jmp 0x000070404D1D6E6D
000070404d1d7cae  sub rsp, 0x08
000070404d1d7cb2  push rax
000070404d1d7cb3  push rcx
000070404d1d7cb4  push rdx
000070404d1d7cb5  push rdi
000070404d1d7cb6  push rsi
000070404d1d7cb7  push r8
000070404d1d7cb9  push r9
000070404d1d7cbb  push r10
000070404d1d7cbd  push r11
000070404d1d7cbf  sub rsp, 0xF0
000070404d1d7cc6  vmovaps [rsp], xmm0
000070404d1d7ccb  vmovaps [rsp+0x10], xmm1
000070404d1d7cd1  vmovaps [rsp+0x20], xmm2
000070404d1d7cd7  vmovaps [rsp+0x30], xmm3
000070404d1d7cdd  vmovaps [rsp+0x40], xmm4
000070404d1d7ce3  vmovaps [rsp+0x50], xmm5
000070404d1d7ce9  vmovaps [rsp+0x60], xmm6
000070404d1d7cef  vmovaps [rsp+0x70], xmm7
000070404d1d7cf5  vmovaps [rsp+0x80], xmm8
000070404d1d7cfe  vmovaps [rsp+0x90], xmm9
000070404d1d7d07  vmovaps [rsp+0xA0], xmm10
000070404d1d7d10  vmovaps [rsp+0xB0], xmm11
000070404d1d7d19  vmovaps [rsp+0xC0], xmm13
000070404d1d7d22  vmovaps [rsp+0xD0], xmm14
000070404d1d7d2b  vmovaps [rsp+0xE0], xmm15
000070404d1d7d34  sub rsp, 0x40
000070404d1d7d38  lea rdi, [rsp]
000070404d1d7d3c  lea rsi, [rsp+0x10]
000070404d1d7d41  lea rdx, [rsp+0x20]
000070404d1d7d46  lea rcx, [rsp+0x30]
000070404d1d7d4b  mov r8d, 0x00
000070404d1d7d51  lea r9, [r15+0x3A8]
000070404d1d7d58  movaps [rdi], xmm12
000070404d1d7d5c  movaps [rsi], xmm15
000070404d1d7d60  movaps [rdx], xmm14
000070404d1d7d64  movaps [rcx], xmm1
000070404d1d7d67  mov rax, 0x607928F07A50
000070404d1d7d71  call rax
000070404d1d7d73  movaps xmm12, [rsp]
000070404d1d7d78  add rsp, 0x40
000070404d1d7d7c  vmovaps xmm0, [rsp]
000070404d1d7d81  vmovaps xmm1, [rsp+0x10]
000070404d1d7d87  vmovaps xmm2, [rsp+0x20]
000070404d1d7d8d  vmovaps xmm3, [rsp+0x30]
000070404d1d7d93  vmovaps xmm4, [rsp+0x40]
000070404d1d7d99  vmovaps xmm5, [rsp+0x50]
000070404d1d7d9f  vmovaps xmm6, [rsp+0x60]
000070404d1d7da5  vmovaps xmm7, [rsp+0x70]
000070404d1d7dab  vmovaps xmm8, [rsp+0x80]
000070404d1d7db4  vmovaps xmm9, [rsp+0x90]
000070404d1d7dbd  vmovaps xmm10, [rsp+0xA0]
000070404d1d7dc6  vmovaps xmm11, [rsp+0xB0]
000070404d1d7dcf  vmovaps xmm13, [rsp+0xC0]
000070404d1d7dd8  vmovaps xmm14, [rsp+0xD0]
000070404d1d7de1  vmovaps xmm15, [rsp+0xE0]
000070404d1d7dea  add rsp, 0xF0
000070404d1d7df1  pop r11
000070404d1d7df3  pop r10
000070404d1d7df5  pop r9
000070404d1d7df7  pop r8
000070404d1d7df9  pop rsi
000070404d1d7dfa  pop rdi
000070404d1d7dfb  pop rdx
000070404d1d7dfc  pop rcx
000070404d1d7dfd  pop rax
000070404d1d7dfe  add rsp, 0x08
000070404d1d7e02  jmp 0x000070404D1D6EAB
000070404d1d7e07  sub rsp, 0x08
000070404d1d7e0b  push rax
000070404d1d7e0c  push rcx
000070404d1d7e0d  push rdx
000070404d1d7e0e  push rdi
000070404d1d7e0f  push rsi
000070404d1d7e10  push r8
000070404d1d7e12  push r9
000070404d1d7e14  push r10
000070404d1d7e16  push r11
000070404d1d7e18  sub rsp, 0xF0
000070404d1d7e1f  vmovaps [rsp], xmm0
000070404d1d7e24  vmovaps [rsp+0x10], xmm1
000070404d1d7e2a  vmovaps [rsp+0x20], xmm2
000070404d1d7e30  vmovaps [rsp+0x30], xmm3
000070404d1d7e36  vmovaps [rsp+0x40], xmm4
000070404d1d7e3c  vmovaps [rsp+0x50], xmm5
000070404d1d7e42  vmovaps [rsp+0x60], xmm6
000070404d1d7e48  vmovaps [rsp+0x70], xmm7
000070404d1d7e4e  vmovaps [rsp+0x80], xmm8
000070404d1d7e57  vmovaps [rsp+0x90], xmm9
000070404d1d7e60  vmovaps [rsp+0xA0], xmm10
000070404d1d7e69  vmovaps [rsp+0xB0], xmm11
000070404d1d7e72  vmovaps [rsp+0xC0], xmm12
000070404d1d7e7b  vmovaps [rsp+0xD0], xmm14
000070404d1d7e84  vmovaps [rsp+0xE0], xmm15
000070404d1d7e8d  sub rsp, 0x40
000070404d1d7e91  lea rdi, [rsp]
000070404d1d7e95  lea rsi, [rsp+0x10]
000070404d1d7e9a  lea rdx, [rsp+0x20]
000070404d1d7e9f  lea rcx, [rsp+0x30]
000070404d1d7ea4  mov r8d, 0x00
000070404d1d7eaa  lea r9, [r15+0x3A8]
000070404d1d7eb1  movaps [rdi], xmm13
000070404d1d7eb5  movaps [rsi], xmm15
000070404d1d7eb9  movaps [rdx], xmm14
000070404d1d7ebd  movaps [rcx], xmm1
000070404d1d7ec0  mov rax, 0x607928F07A50
000070404d1d7eca  call rax
000070404d1d7ecc  movaps xmm13, [rsp]
000070404d1d7ed1  add rsp, 0x40
000070404d1d7ed5  vmovaps xmm0, [rsp]
000070404d1d7eda  vmovaps xmm1, [rsp+0x10]
000070404d1d7ee0  vmovaps xmm2, [rsp+0x20]
000070404d1d7ee6  vmovaps xmm3, [rsp+0x30]
000070404d1d7eec  vmovaps xmm4, [rsp+0x40]
000070404d1d7ef2  vmovaps xmm5, [rsp+0x50]
000070404d1d7ef8  vmovaps xmm6, [rsp+0x60]
000070404d1d7efe  vmovaps xmm7, [rsp+0x70]
000070404d1d7f04  vmovaps xmm8, [rsp+0x80]
000070404d1d7f0d  vmovaps xmm9, [rsp+0x90]
000070404d1d7f16  vmovaps xmm10, [rsp+0xA0]
000070404d1d7f1f  vmovaps xmm11, [rsp+0xB0]
000070404d1d7f28  vmovaps xmm12, [rsp+0xC0]
000070404d1d7f31  vmovaps xmm14, [rsp+0xD0]
000070404d1d7f3a  vmovaps xmm15, [rsp+0xE0]
000070404d1d7f43  add rsp, 0xF0
000070404d1d7f4a  pop r11
000070404d1d7f4c  pop r10
000070404d1d7f4e  pop r9
000070404d1d7f50  pop r8
000070404d1d7f52  pop rsi
000070404d1d7f53  pop rdi
000070404d1d7f54  pop rdx
000070404d1d7f55  pop rcx
000070404d1d7f56  pop rax
000070404d1d7f57  add rsp, 0x08
000070404d1d7f5b  jmp 0x000070404D1D6EE9
000070404d1d7f60  sub rsp, 0x08
000070404d1d7f64  push rax
000070404d1d7f65  push rcx
000070404d1d7f66  push rdx
000070404d1d7f67  push rdi
000070404d1d7f68  push rsi
000070404d1d7f69  push r8
000070404d1d7f6b  push r9
000070404d1d7f6d  push r10
000070404d1d7f6f  push r11
000070404d1d7f71  sub rsp, 0xF0
000070404d1d7f78  vmovaps [rsp], xmm0
000070404d1d7f7d  vmovaps [rsp+0x10], xmm1
000070404d1d7f83  vmovaps [rsp+0x20], xmm2
000070404d1d7f89  vmovaps [rsp+0x30], xmm3
000070404d1d7f8f  vmovaps [rsp+0x40], xmm4
000070404d1d7f95  vmovaps [rsp+0x50], xmm5
000070404d1d7f9b  vmovaps [rsp+0x60], xmm6
000070404d1d7fa1  vmovaps [rsp+0x70], xmm7
000070404d1d7fa7  vmovaps [rsp+0x80], xmm8
000070404d1d7fb0  vmovaps [rsp+0x90], xmm9
000070404d1d7fb9  vmovaps [rsp+0xA0], xmm10
000070404d1d7fc2  vmovaps [rsp+0xB0], xmm11
000070404d1d7fcb  vmovaps [rsp+0xC0], xmm13
000070404d1d7fd4  vmovaps [rsp+0xD0], xmm14
000070404d1d7fdd  vmovaps [rsp+0xE0], xmm15
000070404d1d7fe6  sub rsp, 0x40
000070404d1d7fea  lea rdi, [rsp]
000070404d1d7fee  lea rsi, [rsp+0x10]
000070404d1d7ff3  lea rdx, [rsp+0x20]
000070404d1d7ff8  lea rcx, [rsp+0x30]
000070404d1d7ffd  mov r8d, 0x00
000070404d1d8003  lea r9, [r15+0x3A8]
000070404d1d800a  movaps [rdi], xmm12
000070404d1d800e  movaps [rsi], xmm14
000070404d1d8012  movaps [rdx], xmm2
000070404d1d8015  movaps [rcx], xmm15
000070404d1d8019  mov rax, 0x607928F07A50
000070404d1d8023  call rax
000070404d1d8025  movaps xmm12, [rsp]
000070404d1d802a  add rsp, 0x40
000070404d1d802e  vmovaps xmm0, [rsp]
000070404d1d8033  vmovaps xmm1, [rsp+0x10]
000070404d1d8039  vmovaps xmm2, [rsp+0x20]
000070404d1d803f  vmovaps xmm3, [rsp+0x30]
000070404d1d8045  vmovaps xmm4, [rsp+0x40]
000070404d1d804b  vmovaps xmm5, [rsp+0x50]
000070404d1d8051  vmovaps xmm6, [rsp+0x60]
000070404d1d8057  vmovaps xmm7, [rsp+0x70]
000070404d1d805d  vmovaps xmm8, [rsp+0x80]
000070404d1d8066  vmovaps xmm9, [rsp+0x90]
000070404d1d806f  vmovaps xmm10, [rsp+0xA0]
000070404d1d8078  vmovaps xmm11, [rsp+0xB0]
000070404d1d8081  vmovaps xmm13, [rsp+0xC0]
000070404d1d808a  vmovaps xmm14, [rsp+0xD0]
000070404d1d8093  vmovaps xmm15, [rsp+0xE0]
000070404d1d809c  add rsp, 0xF0
000070404d1d80a3  pop r11
000070404d1d80a5  pop r10
000070404d1d80a7  pop r9
000070404d1d80a9  pop r8
000070404d1d80ab  pop rsi
000070404d1d80ac  pop rdi
000070404d1d80ad  pop rdx
000070404d1d80ae  pop rcx
000070404d1d80af  pop rax
000070404d1d80b0  add rsp, 0x08
000070404d1d80b4  jmp 0x000070404D1D6F43
000070404d1d80b9  sub rsp, 0x08
000070404d1d80bd  push rax
000070404d1d80be  push rcx
000070404d1d80bf  push rdx
000070404d1d80c0  push rdi
000070404d1d80c1  push rsi
000070404d1d80c2  push r8
000070404d1d80c4  push r9
000070404d1d80c6  push r10
000070404d1d80c8  push r11
000070404d1d80ca  sub rsp, 0xF0
000070404d1d80d1  vmovaps [rsp], xmm0
000070404d1d80d6  vmovaps [rsp+0x10], xmm1
000070404d1d80dc  vmovaps [rsp+0x20], xmm3
000070404d1d80e2  vmovaps [rsp+0x30], xmm4
000070404d1d80e8  vmovaps [rsp+0x40], xmm5
000070404d1d80ee  vmovaps [rsp+0x50], xmm6
000070404d1d80f4  vmovaps [rsp+0x60], xmm7
000070404d1d80fa  vmovaps [rsp+0x70], xmm8
000070404d1d8100  vmovaps [rsp+0x80], xmm9
000070404d1d8109  vmovaps [rsp+0x90], xmm10
000070404d1d8112  vmovaps [rsp+0xA0], xmm11
000070404d1d811b  vmovaps [rsp+0xB0], xmm12
000070404d1d8124  vmovaps [rsp+0xC0], xmm13
000070404d1d812d  vmovaps [rsp+0xD0], xmm14
000070404d1d8136  vmovaps [rsp+0xE0], xmm15
000070404d1d813f  sub rsp, 0x40
000070404d1d8143  lea rdi, [rsp]
000070404d1d8147  lea rsi, [rsp+0x10]
000070404d1d814c  lea rdx, [rsp+0x20]
000070404d1d8151  lea rcx, [rsp+0x30]
000070404d1d8156  mov r8d, 0x00
000070404d1d815c  lea r9, [r15+0x3A8]
000070404d1d8163  movaps [rdi], xmm2
000070404d1d8166  movaps [rsi], xmm14
000070404d1d816a  movaps [rdx], xmm8
000070404d1d816e  movaps [rcx], xmm5
000070404d1d8171  mov rax, 0x607928F07A50
000070404d1d817b  call rax
000070404d1d817d  movaps xmm2, [rsp]
000070404d1d8181  add rsp, 0x40
000070404d1d8185  vmovaps xmm0, [rsp]
000070404d1d818a  vmovaps xmm1, [rsp+0x10]
000070404d1d8190  vmovaps xmm3, [rsp+0x20]
000070404d1d8196  vmovaps xmm4, [rsp+0x30]
000070404d1d819c  vmovaps xmm5, [rsp+0x40]
000070404d1d81a2  vmovaps xmm6, [rsp+0x50]
000070404d1d81a8  vmovaps xmm7, [rsp+0x60]
000070404d1d81ae  vmovaps xmm8, [rsp+0x70]
000070404d1d81b4  vmovaps xmm9, [rsp+0x80]
000070404d1d81bd  vmovaps xmm10, [rsp+0x90]
000070404d1d81c6  vmovaps xmm11, [rsp+0xA0]
000070404d1d81cf  vmovaps xmm12, [rsp+0xB0]
000070404d1d81d8  vmovaps xmm13, [rsp+0xC0]
000070404d1d81e1  vmovaps xmm14, [rsp+0xD0]
000070404d1d81ea  vmovaps xmm15, [rsp+0xE0]
000070404d1d81f3  add rsp, 0xF0
000070404d1d81fa  pop r11
000070404d1d81fc  pop r10
000070404d1d81fe  pop r9
000070404d1d8200  pop r8
000070404d1d8202  pop rsi
000070404d1d8203  pop rdi
000070404d1d8204  pop rdx
000070404d1d8205  pop rcx
000070404d1d8206  pop rax
000070404d1d8207  add rsp, 0x08
000070404d1d820b  jmp 0x000070404D1D6FF7
000070404d1d8210  sub rsp, 0x08
000070404d1d8214  push rax
000070404d1d8215  push rcx
000070404d1d8216  push rdx
000070404d1d8217  push rdi
000070404d1d8218  push rsi
000070404d1d8219  push r8
000070404d1d821b  push r9
000070404d1d821d  push r10
000070404d1d821f  push r11
000070404d1d8221  sub rsp, 0xF0
000070404d1d8228  vmovaps [rsp], xmm0
000070404d1d822d  vmovaps [rsp+0x10], xmm1
000070404d1d8233  vmovaps [rsp+0x20], xmm2
000070404d1d8239  vmovaps [rsp+0x30], xmm3
000070404d1d823f  vmovaps [rsp+0x40], xmm4
000070404d1d8245  vmovaps [rsp+0x50], xmm6
000070404d1d824b  vmovaps [rsp+0x60], xmm7
000070404d1d8251  vmovaps [rsp+0x70], xmm8
000070404d1d8257  vmovaps [rsp+0x80], xmm9
000070404d1d8260  vmovaps [rsp+0x90], xmm10
000070404d1d8269  vmovaps [rsp+0xA0], xmm11
000070404d1d8272  vmovaps [rsp+0xB0], xmm12
000070404d1d827b  vmovaps [rsp+0xC0], xmm13
000070404d1d8284  vmovaps [rsp+0xD0], xmm14
000070404d1d828d  vmovaps [rsp+0xE0], xmm15
000070404d1d8296  sub rsp, 0x40
000070404d1d829a  lea rdi, [rsp]
000070404d1d829e  lea rsi, [rsp+0x10]
000070404d1d82a3  lea rdx, [rsp+0x20]
000070404d1d82a8  lea rcx, [rsp+0x30]
000070404d1d82ad  mov r8d, 0x00
000070404d1d82b3  lea r9, [r15+0x3A8]
000070404d1d82ba  movaps [rdi], xmm5
000070404d1d82bd  movaps [rsi], xmm14
000070404d1d82c1  movaps [rdx], xmm8
000070404d1d82c5  movaps [rcx], xmm1
000070404d1d82c8  mov rax, 0x607928F07A50
000070404d1d82d2  call rax
000070404d1d82d4  movaps xmm5, [rsp]
000070404d1d82d8  add rsp, 0x40
000070404d1d82dc  vmovaps xmm0, [rsp]
000070404d1d82e1  vmovaps xmm1, [rsp+0x10]
000070404d1d82e7  vmovaps xmm2, [rsp+0x20]
000070404d1d82ed  vmovaps xmm3, [rsp+0x30]
000070404d1d82f3  vmovaps xmm4, [rsp+0x40]
000070404d1d82f9  vmovaps xmm6, [rsp+0x50]
000070404d1d82ff  vmovaps xmm7, [rsp+0x60]
000070404d1d8305  vmovaps xmm8, [rsp+0x70]
000070404d1d830b  vmovaps xmm9, [rsp+0x80]
000070404d1d8314  vmovaps xmm10, [rsp+0x90]
000070404d1d831d  vmovaps xmm11, [rsp+0xA0]
000070404d1d8326  vmovaps xmm12, [rsp+0xB0]
000070404d1d832f  vmovaps xmm13, [rsp+0xC0]
000070404d1d8338  vmovaps xmm14, [rsp+0xD0]
000070404d1d8341  vmovaps xmm15, [rsp+0xE0]
000070404d1d834a  add rsp, 0xF0
000070404d1d8351  pop r11
000070404d1d8353  pop r10
000070404d1d8355  pop r9
000070404d1d8357  pop r8
000070404d1d8359  pop rsi
000070404d1d835a  pop rdi
000070404d1d835b  pop rdx
000070404d1d835c  pop rcx
000070404d1d835d  pop rax
000070404d1d835e  add rsp, 0x08
000070404d1d8362  jmp 0x000070404D1D7034
000070404d1d8367  sub rsp, 0x08
000070404d1d836b  push rax
000070404d1d836c  push rcx
000070404d1d836d  push rdx
000070404d1d836e  push rdi
000070404d1d836f  push rsi
000070404d1d8370  push r8
000070404d1d8372  push r9
000070404d1d8374  push r10
000070404d1d8376  push r11
000070404d1d8378  sub rsp, 0xF0
000070404d1d837f  vmovaps [rsp], xmm0
000070404d1d8384  vmovaps [rsp+0x10], xmm1
000070404d1d838a  vmovaps [rsp+0x20], xmm2
000070404d1d8390  vmovaps [rsp+0x30], xmm3
000070404d1d8396  vmovaps [rsp+0x40], xmm4
000070404d1d839c  vmovaps [rsp+0x50], xmm5
000070404d1d83a2  vmovaps [rsp+0x60], xmm6
000070404d1d83a8  vmovaps [rsp+0x70], xmm7
000070404d1d83ae  vmovaps [rsp+0x80], xmm8
000070404d1d83b7  vmovaps [rsp+0x90], xmm9
000070404d1d83c0  vmovaps [rsp+0xA0], xmm10
000070404d1d83c9  vmovaps [rsp+0xB0], xmm11
000070404d1d83d2  vmovaps [rsp+0xC0], xmm12
000070404d1d83db  vmovaps [rsp+0xD0], xmm13
000070404d1d83e4  vmovaps [rsp+0xE0], xmm14
000070404d1d83ed  sub rsp, 0x40
000070404d1d83f1  lea rdi, [rsp]
000070404d1d83f5  lea rsi, [rsp+0x10]
000070404d1d83fa  lea rdx, [rsp+0x20]
000070404d1d83ff  lea rcx, [rsp+0x30]
000070404d1d8404  mov r8d, 0x00
000070404d1d840a  lea r9, [r15+0x3A8]
000070404d1d8411  movaps [rdi], xmm15
000070404d1d8415  movaps [rsi], xmm13
000070404d1d8419  movaps [rdx], xmm14
000070404d1d841d  movaps [rcx], xmm1
000070404d1d8420  mov rax, 0x607928F07A50
000070404d1d842a  call rax
000070404d1d842c  movaps xmm15, [rsp]
000070404d1d8431  add rsp, 0x40
000070404d1d8435  vmovaps xmm0, [rsp]
000070404d1d843a  vmovaps xmm1, [rsp+0x10]
000070404d1d8440  vmovaps xmm2, [rsp+0x20]
000070404d1d8446  vmovaps xmm3, [rsp+0x30]
000070404d1d844c  vmovaps xmm4, [rsp+0x40]
000070404d1d8452  vmovaps xmm5, [rsp+0x50]
000070404d1d8458  vmovaps xmm6, [rsp+0x60]
000070404d1d845e  vmovaps xmm7, [rsp+0x70]
000070404d1d8464  vmovaps xmm8, [rsp+0x80]
000070404d1d846d  vmovaps xmm9, [rsp+0x90]
000070404d1d8476  vmovaps xmm10, [rsp+0xA0]
000070404d1d847f  vmovaps xmm11, [rsp+0xB0]
000070404d1d8488  vmovaps xmm12, [rsp+0xC0]
000070404d1d8491  vmovaps xmm13, [rsp+0xD0]
000070404d1d849a  vmovaps xmm14, [rsp+0xE0]
000070404d1d84a3  add rsp, 0xF0
000070404d1d84aa  pop r11
000070404d1d84ac  pop r10
000070404d1d84ae  pop r9
000070404d1d84b0  pop r8
000070404d1d84b2  pop rsi
000070404d1d84b3  pop rdi
000070404d1d84b4  pop rdx
000070404d1d84b5  pop rcx
000070404d1d84b6  pop rax
000070404d1d84b7  add rsp, 0x08
000070404d1d84bb  jmp 0x000070404D1D7063
000070404d1d84c0  sub rsp, 0x08
000070404d1d84c4  push rax
000070404d1d84c5  push rcx
000070404d1d84c6  push rdx
000070404d1d84c7  push rdi
000070404d1d84c8  push rsi
000070404d1d84c9  push r8
000070404d1d84cb  push r9
000070404d1d84cd  push r10
000070404d1d84cf  push r11
000070404d1d84d1  sub rsp, 0xF0
000070404d1d84d8  vmovaps [rsp], xmm0
000070404d1d84dd  vmovaps [rsp+0x10], xmm1
000070404d1d84e3  vmovaps [rsp+0x20], xmm2
000070404d1d84e9  vmovaps [rsp+0x30], xmm3
000070404d1d84ef  vmovaps [rsp+0x40], xmm4
000070404d1d84f5  vmovaps [rsp+0x50], xmm5
000070404d1d84fb  vmovaps [rsp+0x60], xmm6
000070404d1d8501  vmovaps [rsp+0x70], xmm7
000070404d1d8507  vmovaps [rsp+0x80], xmm8
000070404d1d8510  vmovaps [rsp+0x90], xmm9
000070404d1d8519  vmovaps [rsp+0xA0], xmm10
000070404d1d8522  vmovaps [rsp+0xB0], xmm11
000070404d1d852b  vmovaps [rsp+0xC0], xmm12
000070404d1d8534  vmovaps [rsp+0xD0], xmm14
000070404d1d853d  vmovaps [rsp+0xE0], xmm15
000070404d1d8546  sub rsp, 0x40
000070404d1d854a  lea rdi, [rsp]
000070404d1d854e  lea rsi, [rsp+0x10]
000070404d1d8553  lea rdx, [rsp+0x20]
000070404d1d8558  lea rcx, [rsp+0x30]
000070404d1d855d  mov r8d, 0x00
000070404d1d8563  lea r9, [r15+0x3A8]
000070404d1d856a  movaps [rdi], xmm13
000070404d1d856e  movaps [rsi], xmm12
000070404d1d8572  movaps [rdx], xmm14
000070404d1d8576  movaps [rcx], xmm1
000070404d1d8579  mov rax, 0x607928F07A50
000070404d1d8583  call rax
000070404d1d8585  movaps xmm13, [rsp]
000070404d1d858a  add rsp, 0x40
000070404d1d858e  vmovaps xmm0, [rsp]
000070404d1d8593  vmovaps xmm1, [rsp+0x10]
000070404d1d8599  vmovaps xmm2, [rsp+0x20]
000070404d1d859f  vmovaps xmm3, [rsp+0x30]
000070404d1d85a5  vmovaps xmm4, [rsp+0x40]
000070404d1d85ab  vmovaps xmm5, [rsp+0x50]
000070404d1d85b1  vmovaps xmm6, [rsp+0x60]
000070404d1d85b7  vmovaps xmm7, [rsp+0x70]
000070404d1d85bd  vmovaps xmm8, [rsp+0x80]
000070404d1d85c6  vmovaps xmm9, [rsp+0x90]
000070404d1d85cf  vmovaps xmm10, [rsp+0xA0]
000070404d1d85d8  vmovaps xmm11, [rsp+0xB0]
000070404d1d85e1  vmovaps xmm12, [rsp+0xC0]
000070404d1d85ea  vmovaps xmm14, [rsp+0xD0]
000070404d1d85f3  vmovaps xmm15, [rsp+0xE0]
000070404d1d85fc  add rsp, 0xF0
000070404d1d8603  pop r11
000070404d1d8605  pop r10
000070404d1d8607  pop r9
000070404d1d8609  pop r8
000070404d1d860b  pop rsi
000070404d1d860c  pop rdi
000070404d1d860d  pop rdx
000070404d1d860e  pop rcx
000070404d1d860f  pop rax
000070404d1d8610  add rsp, 0x08
000070404d1d8614  jmp 0x000070404D1D7095
000070404d1d8619  sub rsp, 0x08
000070404d1d861d  push rax
000070404d1d861e  push rcx
000070404d1d861f  push rdx
000070404d1d8620  push rdi
000070404d1d8621  push rsi
000070404d1d8622  push r8
000070404d1d8624  push r9
000070404d1d8626  push r10
000070404d1d8628  push r11
000070404d1d862a  sub rsp, 0xF0
000070404d1d8631  vmovaps [rsp], xmm0
000070404d1d8636  vmovaps [rsp+0x10], xmm1
000070404d1d863c  vmovaps [rsp+0x20], xmm2
000070404d1d8642  vmovaps [rsp+0x30], xmm3
000070404d1d8648  vmovaps [rsp+0x40], xmm4
000070404d1d864e  vmovaps [rsp+0x50], xmm5
000070404d1d8654  vmovaps [rsp+0x60], xmm6
000070404d1d865a  vmovaps [rsp+0x70], xmm7
000070404d1d8660  vmovaps [rsp+0x80], xmm8
000070404d1d8669  vmovaps [rsp+0x90], xmm9
000070404d1d8672  vmovaps [rsp+0xA0], xmm10
000070404d1d867b  vmovaps [rsp+0xB0], xmm11
000070404d1d8684  vmovaps [rsp+0xC0], xmm13
000070404d1d868d  vmovaps [rsp+0xD0], xmm14
000070404d1d8696  vmovaps [rsp+0xE0], xmm15
000070404d1d869f  sub rsp, 0x40
000070404d1d86a3  lea rdi, [rsp]
000070404d1d86a7  lea rsi, [rsp+0x10]
000070404d1d86ac  lea rdx, [rsp+0x20]
000070404d1d86b1  lea rcx, [rsp+0x30]
000070404d1d86b6  mov r8d, 0x00
000070404d1d86bc  lea r9, [r15+0x3A8]
000070404d1d86c3  movaps [rdi], xmm12
000070404d1d86c7  movaps [rsi], xmm5
000070404d1d86ca  movaps [rdx], xmm14
000070404d1d86ce  movaps [rcx], xmm4
000070404d1d86d1  mov rax, 0x607928F07A50
000070404d1d86db  call rax
000070404d1d86dd  movaps xmm12, [rsp]
000070404d1d86e2  add rsp, 0x40
000070404d1d86e6  vmovaps xmm0, [rsp]
000070404d1d86eb  vmovaps xmm1, [rsp+0x10]
000070404d1d86f1  vmovaps xmm2, [rsp+0x20]
000070404d1d86f7  vmovaps xmm3, [rsp+0x30]
000070404d1d86fd  vmovaps xmm4, [rsp+0x40]
000070404d1d8703  vmovaps xmm5, [rsp+0x50]
000070404d1d8709  vmovaps xmm6, [rsp+0x60]
000070404d1d870f  vmovaps xmm7, [rsp+0x70]
000070404d1d8715  vmovaps xmm8, [rsp+0x80]
000070404d1d871e  vmovaps xmm9, [rsp+0x90]
000070404d1d8727  vmovaps xmm10, [rsp+0xA0]
000070404d1d8730  vmovaps xmm11, [rsp+0xB0]
000070404d1d8739  vmovaps xmm13, [rsp+0xC0]
000070404d1d8742  vmovaps xmm14, [rsp+0xD0]
000070404d1d874b  vmovaps xmm15, [rsp+0xE0]
000070404d1d8754  add rsp, 0xF0
000070404d1d875b  pop r11
000070404d1d875d  pop r10
000070404d1d875f  pop r9
000070404d1d8761  pop r8
000070404d1d8763  pop rsi
000070404d1d8764  pop rdi
000070404d1d8765  pop rdx
000070404d1d8766  pop rcx
000070404d1d8767  pop rax
000070404d1d8768  add rsp, 0x08
000070404d1d876c  jmp 0x000070404D1D710B
000070404d1d8771  sub rsp, 0x08
000070404d1d8775  push rax
000070404d1d8776  push rcx
000070404d1d8777  push rdx
000070404d1d8778  push rdi
000070404d1d8779  push rsi
000070404d1d877a  push r8
000070404d1d877c  push r9
000070404d1d877e  push r10
000070404d1d8780  push r11
000070404d1d8782  sub rsp, 0xF0
000070404d1d8789  vmovaps [rsp], xmm0
000070404d1d878e  vmovaps [rsp+0x10], xmm1
000070404d1d8794  vmovaps [rsp+0x20], xmm2
000070404d1d879a  vmovaps [rsp+0x30], xmm3
000070404d1d87a0  vmovaps [rsp+0x40], xmm4
000070404d1d87a6  vmovaps [rsp+0x50], xmm5
000070404d1d87ac  vmovaps [rsp+0x60], xmm6
000070404d1d87b2  vmovaps [rsp+0x70], xmm7
000070404d1d87b8  vmovaps [rsp+0x80], xmm8
000070404d1d87c1  vmovaps [rsp+0x90], xmm9
000070404d1d87ca  vmovaps [rsp+0xA0], xmm11
000070404d1d87d3  vmovaps [rsp+0xB0], xmm12
000070404d1d87dc  vmovaps [rsp+0xC0], xmm13
000070404d1d87e5  vmovaps [rsp+0xD0], xmm14
000070404d1d87ee  vmovaps [rsp+0xE0], xmm15
000070404d1d87f7  sub rsp, 0x40
000070404d1d87fb  lea rdi, [rsp]
000070404d1d87ff  lea rsi, [rsp+0x10]
000070404d1d8804  lea rdx, [rsp+0x20]
000070404d1d8809  lea rcx, [rsp+0x30]
000070404d1d880e  mov r8d, 0x00
000070404d1d8814  lea r9, [r15+0x3A8]
000070404d1d881b  movaps [rdi], xmm10
000070404d1d881f  movaps [rsi], xmm2
000070404d1d8822  movaps [rdx], xmm6
000070404d1d8825  movaps [rcx], xmm14
000070404d1d8829  mov rax, 0x607928F07A50
000070404d1d8833  call rax
000070404d1d8835  movaps xmm10, [rsp]
000070404d1d883a  add rsp, 0x40
000070404d1d883e  vmovaps xmm0, [rsp]
000070404d1d8843  vmovaps xmm1, [rsp+0x10]
000070404d1d8849  vmovaps xmm2, [rsp+0x20]
000070404d1d884f  vmovaps xmm3, [rsp+0x30]
000070404d1d8855  vmovaps xmm4, [rsp+0x40]
000070404d1d885b  vmovaps xmm5, [rsp+0x50]
000070404d1d8861  vmovaps xmm6, [rsp+0x60]
000070404d1d8867  vmovaps xmm7, [rsp+0x70]
000070404d1d886d  vmovaps xmm8, [rsp+0x80]
000070404d1d8876  vmovaps xmm9, [rsp+0x90]
000070404d1d887f  vmovaps xmm11, [rsp+0xA0]
000070404d1d8888  vmovaps xmm12, [rsp+0xB0]
000070404d1d8891  vmovaps xmm13, [rsp+0xC0]
000070404d1d889a  vmovaps xmm14, [rsp+0xD0]
000070404d1d88a3  vmovaps xmm15, [rsp+0xE0]
000070404d1d88ac  add rsp, 0xF0
000070404d1d88b3  pop r11
000070404d1d88b5  pop r10
000070404d1d88b7  pop r9
000070404d1d88b9  pop r8
000070404d1d88bb  pop rsi
000070404d1d88bc  pop rdi
000070404d1d88bd  pop rdx
000070404d1d88be  pop rcx
000070404d1d88bf  pop rax
000070404d1d88c0  add rsp, 0x08
000070404d1d88c4  jmp 0x000070404D1D7131
000070404d1d88c9  call 0x000070404D00D4E0
000070404d1d88ce  jmp 0x000070404D1D713E
000070404d1d88d3  sub rsp, 0x08
000070404d1d88d7  push rax
000070404d1d88d8  push rcx
000070404d1d88d9  push rdx
000070404d1d88da  push rdi
000070404d1d88db  push rsi
000070404d1d88dc  push r8
000070404d1d88de  push r9
000070404d1d88e0  push r10
000070404d1d88e2  push r11
000070404d1d88e4  sub rsp, 0xF0
000070404d1d88eb  vmovaps [rsp], xmm0
000070404d1d88f0  vmovaps [rsp+0x10], xmm1
000070404d1d88f6  vmovaps [rsp+0x20], xmm2
000070404d1d88fc  vmovaps [rsp+0x30], xmm3
000070404d1d8902  vmovaps [rsp+0x40], xmm4
000070404d1d8908  vmovaps [rsp+0x50], xmm6
000070404d1d890e  vmovaps [rsp+0x60], xmm7
000070404d1d8914  vmovaps [rsp+0x70], xmm8
000070404d1d891a  vmovaps [rsp+0x80], xmm9
000070404d1d8923  vmovaps [rsp+0x90], xmm10
000070404d1d892c  vmovaps [rsp+0xA0], xmm11
000070404d1d8935  vmovaps [rsp+0xB0], xmm12
000070404d1d893e  vmovaps [rsp+0xC0], xmm13
000070404d1d8947  vmovaps [rsp+0xD0], xmm14
000070404d1d8950  vmovaps [rsp+0xE0], xmm15
000070404d1d8959  sub rsp, 0x40
000070404d1d895d  lea rdi, [rsp]
000070404d1d8961  lea rsi, [rsp+0x10]
000070404d1d8966  lea rdx, [rsp+0x20]
000070404d1d896b  lea rcx, [rsp+0x30]
000070404d1d8970  mov r8d, 0x00
000070404d1d8976  lea r9, [r15+0x3A8]
000070404d1d897d  movaps [rdi], xmm5
000070404d1d8980  movaps [rsi], xmm15
000070404d1d8984  movaps [rdx], xmm6
000070404d1d8987  movaps [rcx], xmm8
000070404d1d898b  mov rax, 0x607928F07A50
000070404d1d8995  call rax
000070404d1d8997  movaps xmm5, [rsp]
000070404d1d899b  add rsp, 0x40
000070404d1d899f  vmovaps xmm0, [rsp]
000070404d1d89a4  vmovaps xmm1, [rsp+0x10]
000070404d1d89aa  vmovaps xmm2, [rsp+0x20]
000070404d1d89b0  vmovaps xmm3, [rsp+0x30]
000070404d1d89b6  vmovaps xmm4, [rsp+0x40]
000070404d1d89bc  vmovaps xmm6, [rsp+0x50]
000070404d1d89c2  vmovaps xmm7, [rsp+0x60]
000070404d1d89c8  vmovaps xmm8, [rsp+0x70]
000070404d1d89ce  vmovaps xmm9, [rsp+0x80]
000070404d1d89d7  vmovaps xmm10, [rsp+0x90]
000070404d1d89e0  vmovaps xmm11, [rsp+0xA0]
000070404d1d89e9  vmovaps xmm12, [rsp+0xB0]
000070404d1d89f2  vmovaps xmm13, [rsp+0xC0]
000070404d1d89fb  vmovaps xmm14, [rsp+0xD0]
000070404d1d8a04  vmovaps xmm15, [rsp+0xE0]
000070404d1d8a0d  add rsp, 0xF0
000070404d1d8a14  pop r11
000070404d1d8a16  pop r10
000070404d1d8a18  pop r9
000070404d1d8a1a  pop r8
000070404d1d8a1c  pop rsi
000070404d1d8a1d  pop rdi
000070404d1d8a1e  pop rdx
000070404d1d8a1f  pop rcx
000070404d1d8a20  pop rax
000070404d1d8a21  add rsp, 0x08
000070404d1d8a25  jmp 0x000070404D1D7174
000070404d1d8a2a  sub rsp, 0x08
000070404d1d8a2e  push rax
000070404d1d8a2f  push rcx
000070404d1d8a30  push rdx
000070404d1d8a31  push rdi
000070404d1d8a32  push rsi
000070404d1d8a33  push r8
000070404d1d8a35  push r9
000070404d1d8a37  push r10
000070404d1d8a39  push r11
000070404d1d8a3b  sub rsp, 0xF0
000070404d1d8a42  vmovaps [rsp], xmm0
000070404d1d8a47  vmovaps [rsp+0x10], xmm1
000070404d1d8a4d  vmovaps [rsp+0x20], xmm2
000070404d1d8a53  vmovaps [rsp+0x30], xmm3
000070404d1d8a59  vmovaps [rsp+0x40], xmm4
000070404d1d8a5f  vmovaps [rsp+0x50], xmm5
000070404d1d8a65  vmovaps [rsp+0x60], xmm6
000070404d1d8a6b  vmovaps [rsp+0x70], xmm7
000070404d1d8a71  vmovaps [rsp+0x80], xmm9
000070404d1d8a7a  vmovaps [rsp+0x90], xmm10
000070404d1d8a83  vmovaps [rsp+0xA0], xmm11
000070404d1d8a8c  vmovaps [rsp+0xB0], xmm12
000070404d1d8a95  vmovaps [rsp+0xC0], xmm13
000070404d1d8a9e  vmovaps [rsp+0xD0], xmm14
000070404d1d8aa7  vmovaps [rsp+0xE0], xmm15
000070404d1d8ab0  sub rsp, 0x40
000070404d1d8ab4  lea rdi, [rsp]
000070404d1d8ab8  lea rsi, [rsp+0x10]
000070404d1d8abd  lea rdx, [rsp+0x20]
000070404d1d8ac2  lea rcx, [rsp+0x30]
000070404d1d8ac7  mov r8d, 0x00
000070404d1d8acd  lea r9, [r15+0x3A8]
000070404d1d8ad4  movaps [rdi], xmm8
000070404d1d8ad8  movaps [rsi], xmm13
000070404d1d8adc  movaps [rdx], xmm1
000070404d1d8adf  movaps [rcx], xmm15
000070404d1d8ae3  mov rax, 0x607928F07A50
000070404d1d8aed  call rax
000070404d1d8aef  movaps xmm8, [rsp]
000070404d1d8af4  add rsp, 0x40
000070404d1d8af8  vmovaps xmm0, [rsp]
000070404d1d8afd  vmovaps xmm1, [rsp+0x10]
000070404d1d8b03  vmovaps xmm2, [rsp+0x20]
000070404d1d8b09  vmovaps xmm3, [rsp+0x30]
000070404d1d8b0f  vmovaps xmm4, [rsp+0x40]
000070404d1d8b15  vmovaps xmm5, [rsp+0x50]
000070404d1d8b1b  vmovaps xmm6, [rsp+0x60]
000070404d1d8b21  vmovaps xmm7, [rsp+0x70]
000070404d1d8b27  vmovaps xmm9, [rsp+0x80]
000070404d1d8b30  vmovaps xmm10, [rsp+0x90]
000070404d1d8b39  vmovaps xmm11, [rsp+0xA0]
000070404d1d8b42  vmovaps xmm12, [rsp+0xB0]
000070404d1d8b4b  vmovaps xmm13, [rsp+0xC0]
000070404d1d8b54  vmovaps xmm14, [rsp+0xD0]
000070404d1d8b5d  vmovaps xmm15, [rsp+0xE0]
000070404d1d8b66  add rsp, 0xF0
000070404d1d8b6d  pop r11
000070404d1d8b6f  pop r10
000070404d1d8b71  pop r9
000070404d1d8b73  pop r8
000070404d1d8b75  pop rsi
000070404d1d8b76  pop rdi
000070404d1d8b77  pop rdx
000070404d1d8b78  pop rcx
000070404d1d8b79  pop rax
000070404d1d8b7a  add rsp, 0x08
000070404d1d8b7e  jmp 0x000070404D1D719A
000070404d1d8b83  call 0x000070404D00E760
000070404d1d8b88  jmp 0x000070404D1D71BD
000070404d1d8b8d  call 0x000070404D00C260
000070404d1d8b92  jmp 0x000070404D1D71C7
000070404d1d8b97  sub rsp, 0x08
000070404d1d8b9b  push rax
000070404d1d8b9c  push rcx
000070404d1d8b9d  push rdx
000070404d1d8b9e  push rdi
000070404d1d8b9f  push rsi
000070404d1d8ba0  push r8
000070404d1d8ba2  push r9
000070404d1d8ba4  push r10
000070404d1d8ba6  push r11
000070404d1d8ba8  sub rsp, 0xF0
000070404d1d8baf  vmovaps [rsp], xmm0
000070404d1d8bb4  vmovaps [rsp+0x10], xmm1
000070404d1d8bba  vmovaps [rsp+0x20], xmm2
000070404d1d8bc0  vmovaps [rsp+0x30], xmm3
000070404d1d8bc6  vmovaps [rsp+0x40], xmm5
000070404d1d8bcc  vmovaps [rsp+0x50], xmm6
000070404d1d8bd2  vmovaps [rsp+0x60], xmm7
000070404d1d8bd8  vmovaps [rsp+0x70], xmm8
000070404d1d8bde  vmovaps [rsp+0x80], xmm9
000070404d1d8be7  vmovaps [rsp+0x90], xmm10
000070404d1d8bf0  vmovaps [rsp+0xA0], xmm11
000070404d1d8bf9  vmovaps [rsp+0xB0], xmm12
000070404d1d8c02  vmovaps [rsp+0xC0], xmm13
000070404d1d8c0b  vmovaps [rsp+0xD0], xmm14
000070404d1d8c14  vmovaps [rsp+0xE0], xmm15
000070404d1d8c1d  sub rsp, 0x40
000070404d1d8c21  lea rdi, [rsp]
000070404d1d8c25  lea rsi, [rsp+0x10]
000070404d1d8c2a  lea rdx, [rsp+0x20]
000070404d1d8c2f  lea rcx, [rsp+0x30]
000070404d1d8c34  mov r8d, 0x00
000070404d1d8c3a  lea r9, [r15+0x3A8]
000070404d1d8c41  movaps [rdi], xmm4
000070404d1d8c44  movaps [rsi], xmm12
000070404d1d8c48  movaps [rdx], xmm9
000070404d1d8c4c  movaps [rcx], xmm6
000070404d1d8c4f  mov rax, 0x607928F07A50
000070404d1d8c59  call rax
000070404d1d8c5b  movaps xmm4, [rsp]
000070404d1d8c5f  add rsp, 0x40
000070404d1d8c63  vmovaps xmm0, [rsp]
000070404d1d8c68  vmovaps xmm1, [rsp+0x10]
000070404d1d8c6e  vmovaps xmm2, [rsp+0x20]
000070404d1d8c74  vmovaps xmm3, [rsp+0x30]
000070404d1d8c7a  vmovaps xmm5, [rsp+0x40]
000070404d1d8c80  vmovaps xmm6, [rsp+0x50]
000070404d1d8c86  vmovaps xmm7, [rsp+0x60]
000070404d1d8c8c  vmovaps xmm8, [rsp+0x70]
000070404d1d8c92  vmovaps xmm9, [rsp+0x80]
000070404d1d8c9b  vmovaps xmm10, [rsp+0x90]
000070404d1d8ca4  vmovaps xmm11, [rsp+0xA0]
000070404d1d8cad  vmovaps xmm12, [rsp+0xB0]
000070404d1d8cb6  vmovaps xmm13, [rsp+0xC0]
000070404d1d8cbf  vmovaps xmm14, [rsp+0xD0]
000070404d1d8cc8  vmovaps xmm15, [rsp+0xE0]
000070404d1d8cd1  add rsp, 0xF0
000070404d1d8cd8  pop r11
000070404d1d8cda  pop r10
000070404d1d8cdc  pop r9
000070404d1d8cde  pop r8
000070404d1d8ce0  pop rsi
000070404d1d8ce1  pop rdi
000070404d1d8ce2  pop rdx
000070404d1d8ce3  pop rcx
000070404d1d8ce4  pop rax
000070404d1d8ce5  add rsp, 0x08
000070404d1d8ce9  jmp 0x000070404D1D71FF
000070404d1d8cee  sub rsp, 0x08
000070404d1d8cf2  push rax
000070404d1d8cf3  push rcx
000070404d1d8cf4  push rdx
000070404d1d8cf5  push rdi
000070404d1d8cf6  push rsi
000070404d1d8cf7  push r8
000070404d1d8cf9  push r9
000070404d1d8cfb  push r10
000070404d1d8cfd  push r11
000070404d1d8cff  sub rsp, 0xF0
000070404d1d8d06  vmovaps [rsp], xmm0
000070404d1d8d0b  vmovaps [rsp+0x10], xmm1
000070404d1d8d11  vmovaps [rsp+0x20], xmm2
000070404d1d8d17  vmovaps [rsp+0x30], xmm3
000070404d1d8d1d  vmovaps [rsp+0x40], xmm4
000070404d1d8d23  vmovaps [rsp+0x50], xmm5
000070404d1d8d29  vmovaps [rsp+0x60], xmm6
000070404d1d8d2f  vmovaps [rsp+0x70], xmm7
000070404d1d8d35  vmovaps [rsp+0x80], xmm8
000070404d1d8d3e  vmovaps [rsp+0x90], xmm10
000070404d1d8d47  vmovaps [rsp+0xA0], xmm11
000070404d1d8d50  vmovaps [rsp+0xB0], xmm12
000070404d1d8d59  vmovaps [rsp+0xC0], xmm13
000070404d1d8d62  vmovaps [rsp+0xD0], xmm14
000070404d1d8d6b  vmovaps [rsp+0xE0], xmm15
000070404d1d8d74  sub rsp, 0x40
000070404d1d8d78  lea rdi, [rsp]
000070404d1d8d7c  lea rsi, [rsp+0x10]
000070404d1d8d81  lea rdx, [rsp+0x20]
000070404d1d8d86  lea rcx, [rsp+0x30]
000070404d1d8d8b  mov r8d, 0x00
000070404d1d8d91  lea r9, [r15+0x3A8]
000070404d1d8d98  movaps [rdi], xmm9
000070404d1d8d9c  movaps [rsi], xmm10
000070404d1d8da0  movaps [rdx], xmm1
000070404d1d8da3  movaps [rcx], xmm12
000070404d1d8da7  mov rax, 0x607928F07A50
000070404d1d8db1  call rax
000070404d1d8db3  movaps xmm9, [rsp]
000070404d1d8db8  add rsp, 0x40
000070404d1d8dbc  vmovaps xmm0, [rsp]
000070404d1d8dc1  vmovaps xmm1, [rsp+0x10]
000070404d1d8dc7  vmovaps xmm2, [rsp+0x20]
000070404d1d8dcd  vmovaps xmm3, [rsp+0x30]
000070404d1d8dd3  vmovaps xmm4, [rsp+0x40]
000070404d1d8dd9  vmovaps xmm5, [rsp+0x50]
000070404d1d8ddf  vmovaps xmm6, [rsp+0x60]
000070404d1d8de5  vmovaps xmm7, [rsp+0x70]
000070404d1d8deb  vmovaps xmm8, [rsp+0x80]
000070404d1d8df4  vmovaps xmm10, [rsp+0x90]
000070404d1d8dfd  vmovaps xmm11, [rsp+0xA0]
000070404d1d8e06  vmovaps xmm12, [rsp+0xB0]
000070404d1d8e0f  vmovaps xmm13, [rsp+0xC0]
000070404d1d8e18  vmovaps xmm14, [rsp+0xD0]
000070404d1d8e21  vmovaps xmm15, [rsp+0xE0]
000070404d1d8e2a  add rsp, 0xF0
000070404d1d8e31  pop r11
000070404d1d8e33  pop r10
000070404d1d8e35  pop r9
000070404d1d8e37  pop r8
000070404d1d8e39  pop rsi
000070404d1d8e3a  pop rdi
000070404d1d8e3b  pop rdx
000070404d1d8e3c  pop rcx
000070404d1d8e3d  pop rax
000070404d1d8e3e  add rsp, 0x08
000070404d1d8e42  jmp 0x000070404D1D7228
000070404d1d8e47  sub rsp, 0x08
000070404d1d8e4b  push rax
000070404d1d8e4c  push rcx
000070404d1d8e4d  push rdx
000070404d1d8e4e  push rdi
000070404d1d8e4f  push rsi
000070404d1d8e50  push r8
000070404d1d8e52  push r9
000070404d1d8e54  push r10
000070404d1d8e56  push r11
000070404d1d8e58  sub rsp, 0xF0
000070404d1d8e5f  vmovaps [rsp], xmm0
000070404d1d8e64  vmovaps [rsp+0x10], xmm1
000070404d1d8e6a  vmovaps [rsp+0x20], xmm2
000070404d1d8e70  vmovaps [rsp+0x30], xmm3
000070404d1d8e76  vmovaps [rsp+0x40], xmm4
000070404d1d8e7c  vmovaps [rsp+0x50], xmm5
000070404d1d8e82  vmovaps [rsp+0x60], xmm6
000070404d1d8e88  vmovaps [rsp+0x70], xmm7
000070404d1d8e8e  vmovaps [rsp+0x80], xmm8
000070404d1d8e97  vmovaps [rsp+0x90], xmm9
000070404d1d8ea0  vmovaps [rsp+0xA0], xmm11
000070404d1d8ea9  vmovaps [rsp+0xB0], xmm12
000070404d1d8eb2  vmovaps [rsp+0xC0], xmm13
000070404d1d8ebb  vmovaps [rsp+0xD0], xmm14
000070404d1d8ec4  vmovaps [rsp+0xE0], xmm15
000070404d1d8ecd  sub rsp, 0x40
000070404d1d8ed1  lea rdi, [rsp]
000070404d1d8ed5  lea rsi, [rsp+0x10]
000070404d1d8eda  lea rdx, [rsp+0x20]
000070404d1d8edf  lea rcx, [rsp+0x30]
000070404d1d8ee4  mov r8d, 0x00
000070404d1d8eea  lea r9, [r15+0x3A8]
000070404d1d8ef1  movaps [rdi], xmm10
000070404d1d8ef5  movaps [rsi], xmm5
000070404d1d8ef8  movaps [rdx], xmm12
000070404d1d8efc  movaps [rcx], xmm1
000070404d1d8eff  mov rax, 0x607928F07A50
000070404d1d8f09  call rax
000070404d1d8f0b  movaps xmm10, [rsp]
000070404d1d8f10  add rsp, 0x40
000070404d1d8f14  vmovaps xmm0, [rsp]
000070404d1d8f19  vmovaps xmm1, [rsp+0x10]
000070404d1d8f1f  vmovaps xmm2, [rsp+0x20]
000070404d1d8f25  vmovaps xmm3, [rsp+0x30]
000070404d1d8f2b  vmovaps xmm4, [rsp+0x40]
000070404d1d8f31  vmovaps xmm5, [rsp+0x50]
000070404d1d8f37  vmovaps xmm6, [rsp+0x60]
000070404d1d8f3d  vmovaps xmm7, [rsp+0x70]
000070404d1d8f43  vmovaps xmm8, [rsp+0x80]
000070404d1d8f4c  vmovaps xmm9, [rsp+0x90]
000070404d1d8f55  vmovaps xmm11, [rsp+0xA0]
000070404d1d8f5e  vmovaps xmm12, [rsp+0xB0]
000070404d1d8f67  vmovaps xmm13, [rsp+0xC0]
000070404d1d8f70  vmovaps xmm14, [rsp+0xD0]
000070404d1d8f79  vmovaps xmm15, [rsp+0xE0]
000070404d1d8f82  add rsp, 0xF0
000070404d1d8f89  pop r11
000070404d1d8f8b  pop r10
000070404d1d8f8d  pop r9
000070404d1d8f8f  pop r8
000070404d1d8f91  pop rsi
000070404d1d8f92  pop rdi
000070404d1d8f93  pop rdx
000070404d1d8f94  pop rcx
000070404d1d8f95  pop rax
000070404d1d8f96  add rsp, 0x08
000070404d1d8f9a  jmp 0x000070404D1D7257
000070404d1d8f9f  sub rsp, 0x08
000070404d1d8fa3  push rax
000070404d1d8fa4  push rcx
000070404d1d8fa5  push rdx
000070404d1d8fa6  push rdi
000070404d1d8fa7  push rsi
000070404d1d8fa8  push r8
000070404d1d8faa  push r9
000070404d1d8fac  push r10
000070404d1d8fae  push r11
000070404d1d8fb0  sub rsp, 0xF0
000070404d1d8fb7  vmovaps [rsp], xmm0
000070404d1d8fbc  vmovaps [rsp+0x10], xmm1
000070404d1d8fc2  vmovaps [rsp+0x20], xmm2
000070404d1d8fc8  vmovaps [rsp+0x30], xmm3
000070404d1d8fce  vmovaps [rsp+0x40], xmm4
000070404d1d8fd4  vmovaps [rsp+0x50], xmm5
000070404d1d8fda  vmovaps [rsp+0x60], xmm7
000070404d1d8fe0  vmovaps [rsp+0x70], xmm8
000070404d1d8fe6  vmovaps [rsp+0x80], xmm9
000070404d1d8fef  vmovaps [rsp+0x90], xmm10
000070404d1d8ff8  vmovaps [rsp+0xA0], xmm11
000070404d1d9001  vmovaps [rsp+0xB0], xmm12
000070404d1d900a  vmovaps [rsp+0xC0], xmm13
000070404d1d9013  vmovaps [rsp+0xD0], xmm14
000070404d1d901c  vmovaps [rsp+0xE0], xmm15
000070404d1d9025  sub rsp, 0x40
000070404d1d9029  lea rdi, [rsp]
000070404d1d902d  lea rsi, [rsp+0x10]
000070404d1d9032  lea rdx, [rsp+0x20]
000070404d1d9037  lea rcx, [rsp+0x30]
000070404d1d903c  mov r8d, 0x00
000070404d1d9042  lea r9, [r15+0x3A8]
000070404d1d9049  movaps [rdi], xmm6
000070404d1d904c  movaps [rsi], xmm8
000070404d1d9050  movaps [rdx], xmm12
000070404d1d9054  movaps [rcx], xmm1
000070404d1d9057  mov rax, 0x607928F07A50
000070404d1d9061  call rax
000070404d1d9063  movaps xmm6, [rsp]
000070404d1d9067  add rsp, 0x40
000070404d1d906b  vmovaps xmm0, [rsp]
000070404d1d9070  vmovaps xmm1, [rsp+0x10]
000070404d1d9076  vmovaps xmm2, [rsp+0x20]
000070404d1d907c  vmovaps xmm3, [rsp+0x30]
000070404d1d9082  vmovaps xmm4, [rsp+0x40]
000070404d1d9088  vmovaps xmm5, [rsp+0x50]
000070404d1d908e  vmovaps xmm7, [rsp+0x60]
000070404d1d9094  vmovaps xmm8, [rsp+0x70]
000070404d1d909a  vmovaps xmm9, [rsp+0x80]
000070404d1d90a3  vmovaps xmm10, [rsp+0x90]
000070404d1d90ac  vmovaps xmm11, [rsp+0xA0]
000070404d1d90b5  vmovaps xmm12, [rsp+0xB0]
000070404d1d90be  vmovaps xmm13, [rsp+0xC0]
000070404d1d90c7  vmovaps xmm14, [rsp+0xD0]
000070404d1d90d0  vmovaps xmm15, [rsp+0xE0]
000070404d1d90d9  add rsp, 0xF0
000070404d1d90e0  pop r11
000070404d1d90e2  pop r10
000070404d1d90e4  pop r9
000070404d1d90e6  pop r8
000070404d1d90e8  pop rsi
000070404d1d90e9  pop rdi
000070404d1d90ea  pop rdx
000070404d1d90eb  pop rcx
000070404d1d90ec  pop rax
000070404d1d90ed  add rsp, 0x08
000070404d1d90f1  jmp 0x000070404D1D7285
000070404d1d90f6  call 0x000070404CFFF430
000070404d1d90fb  jmp 0x000070404D1D728F
000070404d1d9100  call 0x000070404D00AFE0
000070404d1d9105  jmp 0x000070404D1D7299
000070404d1d910a  sub rsp, 0x08
000070404d1d910e  push rax
000070404d1d910f  push rcx
000070404d1d9110  push rdx
000070404d1d9111  push rdi
000070404d1d9112  push rsi
000070404d1d9113  push r8
000070404d1d9115  push r9
000070404d1d9117  push r10
000070404d1d9119  push r11
000070404d1d911b  sub rsp, 0xF0
000070404d1d9122  vmovaps [rsp], xmm0
000070404d1d9127  vmovaps [rsp+0x10], xmm1
000070404d1d912d  vmovaps [rsp+0x20], xmm2
000070404d1d9133  vmovaps [rsp+0x30], xmm3
000070404d1d9139  vmovaps [rsp+0x40], xmm4
000070404d1d913f  vmovaps [rsp+0x50], xmm5
000070404d1d9145  vmovaps [rsp+0x60], xmm6
000070404d1d914b  vmovaps [rsp+0x70], xmm7
000070404d1d9151  vmovaps [rsp+0x80], xmm9
000070404d1d915a  vmovaps [rsp+0x90], xmm10
000070404d1d9163  vmovaps [rsp+0xA0], xmm11
000070404d1d916c  vmovaps [rsp+0xB0], xmm12
000070404d1d9175  vmovaps [rsp+0xC0], xmm13
000070404d1d917e  vmovaps [rsp+0xD0], xmm14
000070404d1d9187  vmovaps [rsp+0xE0], xmm15
000070404d1d9190  sub rsp, 0x40
000070404d1d9194  lea rdi, [rsp]
000070404d1d9198  lea rsi, [rsp+0x10]
000070404d1d919d  lea rdx, [rsp+0x20]
000070404d1d91a2  lea rcx, [rsp+0x30]
000070404d1d91a7  mov r8d, 0x00
000070404d1d91ad  lea r9, [r15+0x3A8]
000070404d1d91b4  movaps [rdi], xmm8
000070404d1d91b8  movaps [rsi], xmm4
000070404d1d91bb  movaps [rdx], xmm13
000070404d1d91bf  movaps [rcx], xmm11
000070404d1d91c3  mov rax, 0x607928F07A50
000070404d1d91cd  call rax
000070404d1d91cf  movaps xmm8, [rsp]
000070404d1d91d4  add rsp, 0x40
000070404d1d91d8  vmovaps xmm0, [rsp]
000070404d1d91dd  vmovaps xmm1, [rsp+0x10]
000070404d1d91e3  vmovaps xmm2, [rsp+0x20]
000070404d1d91e9  vmovaps xmm3, [rsp+0x30]
000070404d1d91ef  vmovaps xmm4, [rsp+0x40]
000070404d1d91f5  vmovaps xmm5, [rsp+0x50]
000070404d1d91fb  vmovaps xmm6, [rsp+0x60]
000070404d1d9201  vmovaps xmm7, [rsp+0x70]
000070404d1d9207  vmovaps xmm9, [rsp+0x80]
000070404d1d9210  vmovaps xmm10, [rsp+0x90]
000070404d1d9219  vmovaps xmm11, [rsp+0xA0]
000070404d1d9222  vmovaps xmm12, [rsp+0xB0]
000070404d1d922b  vmovaps xmm13, [rsp+0xC0]
000070404d1d9234  vmovaps xmm14, [rsp+0xD0]
000070404d1d923d  vmovaps xmm15, [rsp+0xE0]
000070404d1d9246  add rsp, 0xF0
000070404d1d924d  pop r11
000070404d1d924f  pop r10
000070404d1d9251  pop r9
000070404d1d9253  pop r8
000070404d1d9255  pop rsi
000070404d1d9256  pop rdi
000070404d1d9257  pop rdx
000070404d1d9258  pop rcx
000070404d1d9259  pop rax
000070404d1d925a  add rsp, 0x08
000070404d1d925e  jmp 0x000070404D1D72CF
000070404d1d9263  sub rsp, 0x08
000070404d1d9267  push rax
000070404d1d9268  push rcx
000070404d1d9269  push rdx
000070404d1d926a  push rdi
000070404d1d926b  push rsi
000070404d1d926c  push r8
000070404d1d926e  push r9
000070404d1d9270  push r10
000070404d1d9272  push r11
000070404d1d9274  sub rsp, 0xF0
000070404d1d927b  vmovaps [rsp], xmm0
000070404d1d9280  vmovaps [rsp+0x10], xmm1
000070404d1d9286  vmovaps [rsp+0x20], xmm2
000070404d1d928c  vmovaps [rsp+0x30], xmm3
000070404d1d9292  vmovaps [rsp+0x40], xmm4
000070404d1d9298  vmovaps [rsp+0x50], xmm5
000070404d1d929e  vmovaps [rsp+0x60], xmm6
000070404d1d92a4  vmovaps [rsp+0x70], xmm7
000070404d1d92aa  vmovaps [rsp+0x80], xmm8
000070404d1d92b3  vmovaps [rsp+0x90], xmm9
000070404d1d92bc  vmovaps [rsp+0xA0], xmm10
000070404d1d92c5  vmovaps [rsp+0xB0], xmm12
000070404d1d92ce  vmovaps [rsp+0xC0], xmm13
000070404d1d92d7  vmovaps [rsp+0xD0], xmm14
000070404d1d92e0  vmovaps [rsp+0xE0], xmm15
000070404d1d92e9  sub rsp, 0x40
000070404d1d92ed  lea rdi, [rsp]
000070404d1d92f1  lea rsi, [rsp+0x10]
000070404d1d92f6  lea rdx, [rsp+0x20]
000070404d1d92fb  lea rcx, [rsp+0x30]
000070404d1d9300  mov r8d, 0x00
000070404d1d9306  lea r9, [r15+0x3A8]
000070404d1d930d  movaps [rdi], xmm11
000070404d1d9311  movaps [rsi], xmm9
000070404d1d9315  movaps [rdx], xmm1
000070404d1d9318  movaps [rcx], xmm13
000070404d1d931c  mov rax, 0x607928F07A50
000070404d1d9326  call rax
000070404d1d9328  movaps xmm11, [rsp]
000070404d1d932d  add rsp, 0x40
000070404d1d9331  vmovaps xmm0, [rsp]
000070404d1d9336  vmovaps xmm1, [rsp+0x10]
000070404d1d933c  vmovaps xmm2, [rsp+0x20]
000070404d1d9342  vmovaps xmm3, [rsp+0x30]
000070404d1d9348  vmovaps xmm4, [rsp+0x40]
000070404d1d934e  vmovaps xmm5, [rsp+0x50]
000070404d1d9354  vmovaps xmm6, [rsp+0x60]
000070404d1d935a  vmovaps xmm7, [rsp+0x70]
000070404d1d9360  vmovaps xmm8, [rsp+0x80]
000070404d1d9369  vmovaps xmm9, [rsp+0x90]
000070404d1d9372  vmovaps xmm10, [rsp+0xA0]
000070404d1d937b  vmovaps xmm12, [rsp+0xB0]
000070404d1d9384  vmovaps xmm13, [rsp+0xC0]
000070404d1d938d  vmovaps xmm14, [rsp+0xD0]
000070404d1d9396  vmovaps xmm15, [rsp+0xE0]
000070404d1d939f  add rsp, 0xF0
000070404d1d93a6  pop r11
000070404d1d93a8  pop r10
000070404d1d93aa  pop r9
000070404d1d93ac  pop r8
000070404d1d93ae  pop rsi
000070404d1d93af  pop rdi
000070404d1d93b0  pop rdx
000070404d1d93b1  pop rcx
000070404d1d93b2  pop rax
000070404d1d93b3  add rsp, 0x08
000070404d1d93b7  jmp 0x000070404D1D72F5
000070404d1d93bc  sub rsp, 0x08
000070404d1d93c0  push rax
000070404d1d93c1  push rcx
000070404d1d93c2  push rdx
000070404d1d93c3  push rdi
000070404d1d93c4  push rsi
000070404d1d93c5  push r8
000070404d1d93c7  push r9
000070404d1d93c9  push r10
000070404d1d93cb  push r11
000070404d1d93cd  sub rsp, 0xF0
000070404d1d93d4  vmovaps [rsp], xmm0
000070404d1d93d9  vmovaps [rsp+0x10], xmm1
000070404d1d93df  vmovaps [rsp+0x20], xmm2
000070404d1d93e5  vmovaps [rsp+0x30], xmm3
000070404d1d93eb  vmovaps [rsp+0x40], xmm4
000070404d1d93f1  vmovaps [rsp+0x50], xmm5
000070404d1d93f7  vmovaps [rsp+0x60], xmm6
000070404d1d93fd  vmovaps [rsp+0x70], xmm7
000070404d1d9403  vmovaps [rsp+0x80], xmm8
000070404d1d940c  vmovaps [rsp+0x90], xmm9
000070404d1d9415  vmovaps [rsp+0xA0], xmm10
000070404d1d941e  vmovaps [rsp+0xB0], xmm11
000070404d1d9427  vmovaps [rsp+0xC0], xmm12
000070404d1d9430  vmovaps [rsp+0xD0], xmm14
000070404d1d9439  vmovaps [rsp+0xE0], xmm15
000070404d1d9442  sub rsp, 0x40
000070404d1d9446  lea rdi, [rsp]
000070404d1d944a  lea rsi, [rsp+0x10]
000070404d1d944f  lea rdx, [rsp+0x20]
000070404d1d9454  lea rcx, [rsp+0x30]
000070404d1d9459  mov r8d, 0x00
000070404d1d945f  lea r9, [r15+0x3A8]
000070404d1d9466  movaps [rdi], xmm13
000070404d1d946a  movaps [rsi], xmm10
000070404d1d946e  movaps [rdx], xmm7
000070404d1d9471  movaps [rcx], xmm1
000070404d1d9474  mov rax, 0x607928F07A50
000070404d1d947e  call rax
000070404d1d9480  movaps xmm13, [rsp]
000070404d1d9485  add rsp, 0x40
000070404d1d9489  vmovaps xmm0, [rsp]
000070404d1d948e  vmovaps xmm1, [rsp+0x10]
000070404d1d9494  vmovaps xmm2, [rsp+0x20]
000070404d1d949a  vmovaps xmm3, [rsp+0x30]
000070404d1d94a0  vmovaps xmm4, [rsp+0x40]
000070404d1d94a6  vmovaps xmm5, [rsp+0x50]
000070404d1d94ac  vmovaps xmm6, [rsp+0x60]
000070404d1d94b2  vmovaps xmm7, [rsp+0x70]
000070404d1d94b8  vmovaps xmm8, [rsp+0x80]
000070404d1d94c1  vmovaps xmm9, [rsp+0x90]
000070404d1d94ca  vmovaps xmm10, [rsp+0xA0]
000070404d1d94d3  vmovaps xmm11, [rsp+0xB0]
000070404d1d94dc  vmovaps xmm12, [rsp+0xC0]
000070404d1d94e5  vmovaps xmm14, [rsp+0xD0]
000070404d1d94ee  vmovaps xmm15, [rsp+0xE0]
000070404d1d94f7  add rsp, 0xF0
000070404d1d94fe  pop r11
000070404d1d9500  pop r10
000070404d1d9502  pop r9
000070404d1d9504  pop r8
000070404d1d9506  pop rsi
000070404d1d9507  pop rdi
000070404d1d9508  pop rdx
000070404d1d9509  pop rcx
000070404d1d950a  pop rax
000070404d1d950b  add rsp, 0x08
000070404d1d950f  jmp 0x000070404D1D731B
000070404d1d9514  sub rsp, 0x08
000070404d1d9518  push rax
000070404d1d9519  push rcx
000070404d1d951a  push rdx
000070404d1d951b  push rdi
000070404d1d951c  push rsi
000070404d1d951d  push r8
000070404d1d951f  push r9
000070404d1d9521  push r10
000070404d1d9523  push r11
000070404d1d9525  sub rsp, 0xF0
000070404d1d952c  vmovaps [rsp], xmm0
000070404d1d9531  vmovaps [rsp+0x10], xmm1
000070404d1d9537  vmovaps [rsp+0x20], xmm2
000070404d1d953d  vmovaps [rsp+0x30], xmm3
000070404d1d9543  vmovaps [rsp+0x40], xmm4
000070404d1d9549  vmovaps [rsp+0x50], xmm5
000070404d1d954f  vmovaps [rsp+0x60], xmm6
000070404d1d9555  vmovaps [rsp+0x70], xmm7
000070404d1d955b  vmovaps [rsp+0x80], xmm8
000070404d1d9564  vmovaps [rsp+0x90], xmm9
000070404d1d956d  vmovaps [rsp+0xA0], xmm11
000070404d1d9576  vmovaps [rsp+0xB0], xmm12
000070404d1d957f  vmovaps [rsp+0xC0], xmm13
000070404d1d9588  vmovaps [rsp+0xD0], xmm14
000070404d1d9591  vmovaps [rsp+0xE0], xmm15
000070404d1d959a  sub rsp, 0x40
000070404d1d959e  lea rdi, [rsp]
000070404d1d95a2  lea rsi, [rsp+0x10]
000070404d1d95a7  lea rdx, [rsp+0x20]
000070404d1d95ac  lea rcx, [rsp+0x30]
000070404d1d95b1  mov r8d, 0x00
000070404d1d95b7  lea r9, [r15+0x3A8]
000070404d1d95be  movaps [rdi], xmm10
000070404d1d95c2  movaps [rsi], xmm6
000070404d1d95c5  movaps [rdx], xmm15
000070404d1d95c9  movaps [rcx], xmm1
000070404d1d95cc  mov rax, 0x607928F07A50
000070404d1d95d6  call rax
000070404d1d95d8  movaps xmm10, [rsp]
000070404d1d95dd  add rsp, 0x40
000070404d1d95e1  vmovaps xmm0, [rsp]
000070404d1d95e6  vmovaps xmm1, [rsp+0x10]
000070404d1d95ec  vmovaps xmm2, [rsp+0x20]
000070404d1d95f2  vmovaps xmm3, [rsp+0x30]
000070404d1d95f8  vmovaps xmm4, [rsp+0x40]
000070404d1d95fe  vmovaps xmm5, [rsp+0x50]
000070404d1d9604  vmovaps xmm6, [rsp+0x60]
000070404d1d960a  vmovaps xmm7, [rsp+0x70]
000070404d1d9610  vmovaps xmm8, [rsp+0x80]
000070404d1d9619  vmovaps xmm9, [rsp+0x90]
000070404d1d9622  vmovaps xmm11, [rsp+0xA0]
000070404d1d962b  vmovaps xmm12, [rsp+0xB0]
000070404d1d9634  vmovaps xmm13, [rsp+0xC0]
000070404d1d963d  vmovaps xmm14, [rsp+0xD0]
000070404d1d9646  vmovaps xmm15, [rsp+0xE0]
000070404d1d964f  add rsp, 0xF0
000070404d1d9656  pop r11
000070404d1d9658  pop r10
000070404d1d965a  pop r9
000070404d1d965c  pop r8
000070404d1d965e  pop rsi
000070404d1d965f  pop rdi
000070404d1d9660  pop rdx
000070404d1d9661  pop rcx
000070404d1d9662  pop rax
000070404d1d9663  add rsp, 0x08
000070404d1d9667  jmp 0x000070404D1D7341
000070404d1d966c  call 0x000070404CFFF430
000070404d1d9671  jmp 0x000070404D1D734B
000070404d1d9676  call 0x000070404D00E760
000070404d1d967b  jmp 0x000070404D1D7355
000070404d1d9680  sub rsp, 0x08
000070404d1d9684  push rax
000070404d1d9685  push rcx
000070404d1d9686  push rdx
000070404d1d9687  push rdi
000070404d1d9688  push rsi
000070404d1d9689  push r8
000070404d1d968b  push r9
000070404d1d968d  push r10
000070404d1d968f  push r11
000070404d1d9691  sub rsp, 0xF0
000070404d1d9698  vmovaps [rsp], xmm0
000070404d1d969d  vmovaps [rsp+0x10], xmm1
000070404d1d96a3  vmovaps [rsp+0x20], xmm2
000070404d1d96a9  vmovaps [rsp+0x30], xmm3
000070404d1d96af  vmovaps [rsp+0x40], xmm4
000070404d1d96b5  vmovaps [rsp+0x50], xmm5
000070404d1d96bb  vmovaps [rsp+0x60], xmm6
000070404d1d96c1  vmovaps [rsp+0x70], xmm8
000070404d1d96c7  vmovaps [rsp+0x80], xmm9
000070404d1d96d0  vmovaps [rsp+0x90], xmm10
000070404d1d96d9  vmovaps [rsp+0xA0], xmm11
000070404d1d96e2  vmovaps [rsp+0xB0], xmm12
000070404d1d96eb  vmovaps [rsp+0xC0], xmm13
000070404d1d96f4  vmovaps [rsp+0xD0], xmm14
000070404d1d96fd  vmovaps [rsp+0xE0], xmm15
000070404d1d9706  sub rsp, 0x40
000070404d1d970a  lea rdi, [rsp]
000070404d1d970e  lea rsi, [rsp+0x10]
000070404d1d9713  lea rdx, [rsp+0x20]
000070404d1d9718  lea rcx, [rsp+0x30]
000070404d1d971d  mov r8d, 0x00
000070404d1d9723  lea r9, [r15+0x3A8]
000070404d1d972a  movaps [rdi], xmm7
000070404d1d972d  movaps [rsi], xmm8
000070404d1d9731  movaps [rdx], xmm3
000070404d1d9734  movaps [rcx], xmm9
000070404d1d9738  mov rax, 0x607928F07A50
000070404d1d9742  call rax
000070404d1d9744  movaps xmm7, [rsp]
000070404d1d9748  add rsp, 0x40
000070404d1d974c  vmovaps xmm0, [rsp]
000070404d1d9751  vmovaps xmm1, [rsp+0x10]
000070404d1d9757  vmovaps xmm2, [rsp+0x20]
000070404d1d975d  vmovaps xmm3, [rsp+0x30]
000070404d1d9763  vmovaps xmm4, [rsp+0x40]
000070404d1d9769  vmovaps xmm5, [rsp+0x50]
000070404d1d976f  vmovaps xmm6, [rsp+0x60]
000070404d1d9775  vmovaps xmm8, [rsp+0x70]
000070404d1d977b  vmovaps xmm9, [rsp+0x80]
000070404d1d9784  vmovaps xmm10, [rsp+0x90]
000070404d1d978d  vmovaps xmm11, [rsp+0xA0]
000070404d1d9796  vmovaps xmm12, [rsp+0xB0]
000070404d1d979f  vmovaps xmm13, [rsp+0xC0]
000070404d1d97a8  vmovaps xmm14, [rsp+0xD0]
000070404d1d97b1  vmovaps xmm15, [rsp+0xE0]
000070404d1d97ba  add rsp, 0xF0
000070404d1d97c1  pop r11
000070404d1d97c3  pop r10
000070404d1d97c5  pop r9
000070404d1d97c7  pop r8
000070404d1d97c9  pop rsi
000070404d1d97ca  pop rdi
000070404d1d97cb  pop rdx
000070404d1d97cc  pop rcx
000070404d1d97cd  pop rax
000070404d1d97ce  add rsp, 0x08
000070404d1d97d2  jmp 0x000070404D1D737D
000070404d1d97d7  sub rsp, 0x08
000070404d1d97db  push rax
000070404d1d97dc  push rcx
000070404d1d97dd  push rdx
000070404d1d97de  push rdi
000070404d1d97df  push rsi
000070404d1d97e0  push r8
000070404d1d97e2  push r9
000070404d1d97e4  push r10
000070404d1d97e6  push r11
000070404d1d97e8  sub rsp, 0xF0
000070404d1d97ef  vmovaps [rsp], xmm0
000070404d1d97f4  vmovaps [rsp+0x10], xmm1
000070404d1d97fa  vmovaps [rsp+0x20], xmm2
000070404d1d9800  vmovaps [rsp+0x30], xmm3
000070404d1d9806  vmovaps [rsp+0x40], xmm4
000070404d1d980c  vmovaps [rsp+0x50], xmm5
000070404d1d9812  vmovaps [rsp+0x60], xmm6
000070404d1d9818  vmovaps [rsp+0x70], xmm7
000070404d1d981e  vmovaps [rsp+0x80], xmm9
000070404d1d9827  vmovaps [rsp+0x90], xmm10
000070404d1d9830  vmovaps [rsp+0xA0], xmm11
000070404d1d9839  vmovaps [rsp+0xB0], xmm12
000070404d1d9842  vmovaps [rsp+0xC0], xmm13
000070404d1d984b  vmovaps [rsp+0xD0], xmm14
000070404d1d9854  vmovaps [rsp+0xE0], xmm15
000070404d1d985d  sub rsp, 0x40
000070404d1d9861  lea rdi, [rsp]
000070404d1d9865  lea rsi, [rsp+0x10]
000070404d1d986a  lea rdx, [rsp+0x20]
000070404d1d986f  lea rcx, [rsp+0x30]
000070404d1d9874  mov r8d, 0x00
000070404d1d987a  lea r9, [r15+0x3A8]
000070404d1d9881  movaps [rdi], xmm8
000070404d1d9885  movaps [rsi], xmm11
000070404d1d9889  movaps [rdx], xmm14
000070404d1d988d  movaps [rcx], xmm9
000070404d1d9891  mov rax, 0x607928F07A50
000070404d1d989b  call rax
000070404d1d989d  movaps xmm8, [rsp]
000070404d1d98a2  add rsp, 0x40
000070404d1d98a6  vmovaps xmm0, [rsp]
000070404d1d98ab  vmovaps xmm1, [rsp+0x10]
000070404d1d98b1  vmovaps xmm2, [rsp+0x20]
000070404d1d98b7  vmovaps xmm3, [rsp+0x30]
000070404d1d98bd  vmovaps xmm4, [rsp+0x40]
000070404d1d98c3  vmovaps xmm5, [rsp+0x50]
000070404d1d98c9  vmovaps xmm6, [rsp+0x60]
000070404d1d98cf  vmovaps xmm7, [rsp+0x70]
000070404d1d98d5  vmovaps xmm9, [rsp+0x80]
000070404d1d98de  vmovaps xmm10, [rsp+0x90]
000070404d1d98e7  vmovaps xmm11, [rsp+0xA0]
000070404d1d98f0  vmovaps xmm12, [rsp+0xB0]
000070404d1d98f9  vmovaps xmm13, [rsp+0xC0]
000070404d1d9902  vmovaps xmm14, [rsp+0xD0]
000070404d1d990b  vmovaps xmm15, [rsp+0xE0]
000070404d1d9914  add rsp, 0xF0
000070404d1d991b  pop r11
000070404d1d991d  pop r10
000070404d1d991f  pop r9
000070404d1d9921  pop r8
000070404d1d9923  pop rsi
000070404d1d9924  pop rdi
000070404d1d9925  pop rdx
000070404d1d9926  pop rcx
000070404d1d9927  pop rax
000070404d1d9928  add rsp, 0x08
000070404d1d992c  jmp 0x000070404D1D73A6
000070404d1d9931  sub rsp, 0x08
000070404d1d9935  push rax
000070404d1d9936  push rcx
000070404d1d9937  push rdx
000070404d1d9938  push rdi
000070404d1d9939  push rsi
000070404d1d993a  push r8
000070404d1d993c  push r9
000070404d1d993e  push r10
000070404d1d9940  push r11
000070404d1d9942  sub rsp, 0xF0
000070404d1d9949  vmovaps [rsp], xmm0
000070404d1d994e  vmovaps [rsp+0x10], xmm1
000070404d1d9954  vmovaps [rsp+0x20], xmm2
000070404d1d995a  vmovaps [rsp+0x30], xmm3
000070404d1d9960  vmovaps [rsp+0x40], xmm4
000070404d1d9966  vmovaps [rsp+0x50], xmm5
000070404d1d996c  vmovaps [rsp+0x60], xmm6
000070404d1d9972  vmovaps [rsp+0x70], xmm7
000070404d1d9978  vmovaps [rsp+0x80], xmm8
000070404d1d9981  vmovaps [rsp+0x90], xmm9
000070404d1d998a  vmovaps [rsp+0xA0], xmm10
000070404d1d9993  vmovaps [rsp+0xB0], xmm12
000070404d1d999c  vmovaps [rsp+0xC0], xmm13
000070404d1d99a5  vmovaps [rsp+0xD0], xmm14
000070404d1d99ae  vmovaps [rsp+0xE0], xmm15
000070404d1d99b7  sub rsp, 0x40
000070404d1d99bb  lea rdi, [rsp]
000070404d1d99bf  lea rsi, [rsp+0x10]
000070404d1d99c4  lea rdx, [rsp+0x20]
000070404d1d99c9  lea rcx, [rsp+0x30]
000070404d1d99ce  mov r8d, 0x00
000070404d1d99d4  lea r9, [r15+0x3A8]
000070404d1d99db  movaps [rdi], xmm11
000070404d1d99df  movaps [rsi], xmm13
000070404d1d99e3  movaps [rdx], xmm12
000070404d1d99e7  movaps [rcx], xmm14
000070404d1d99eb  mov rax, 0x607928F07A50
000070404d1d99f5  call rax
000070404d1d99f7  movaps xmm11, [rsp]
000070404d1d99fc  add rsp, 0x40
000070404d1d9a00  vmovaps xmm0, [rsp]
000070404d1d9a05  vmovaps xmm1, [rsp+0x10]
000070404d1d9a0b  vmovaps xmm2, [rsp+0x20]
000070404d1d9a11  vmovaps xmm3, [rsp+0x30]
000070404d1d9a17  vmovaps xmm4, [rsp+0x40]
000070404d1d9a1d  vmovaps xmm5, [rsp+0x50]
000070404d1d9a23  vmovaps xmm6, [rsp+0x60]
000070404d1d9a29  vmovaps xmm7, [rsp+0x70]
000070404d1d9a2f  vmovaps xmm8, [rsp+0x80]
000070404d1d9a38  vmovaps xmm9, [rsp+0x90]
000070404d1d9a41  vmovaps xmm10, [rsp+0xA0]
000070404d1d9a4a  vmovaps xmm12, [rsp+0xB0]
000070404d1d9a53  vmovaps xmm13, [rsp+0xC0]
000070404d1d9a5c  vmovaps xmm14, [rsp+0xD0]
000070404d1d9a65  vmovaps xmm15, [rsp+0xE0]
000070404d1d9a6e  add rsp, 0xF0
000070404d1d9a75  pop r11
000070404d1d9a77  pop r10
000070404d1d9a79  pop r9
000070404d1d9a7b  pop r8
000070404d1d9a7d  pop rsi
000070404d1d9a7e  pop rdi
000070404d1d9a7f  pop rdx
000070404d1d9a80  pop rcx
000070404d1d9a81  pop rax
000070404d1d9a82  add rsp, 0x08
000070404d1d9a86  jmp 0x000070404D1D73CF
000070404d1d9a8b  sub rsp, 0x08
000070404d1d9a8f  push rax
000070404d1d9a90  push rcx
000070404d1d9a91  push rdx
000070404d1d9a92  push rdi
000070404d1d9a93  push rsi
000070404d1d9a94  push r8
000070404d1d9a96  push r9
000070404d1d9a98  push r10
000070404d1d9a9a  push r11
000070404d1d9a9c  sub rsp, 0xF0
000070404d1d9aa3  vmovaps [rsp], xmm0
000070404d1d9aa8  vmovaps [rsp+0x10], xmm1
000070404d1d9aae  vmovaps [rsp+0x20], xmm2
000070404d1d9ab4  vmovaps [rsp+0x30], xmm3
000070404d1d9aba  vmovaps [rsp+0x40], xmm4
000070404d1d9ac0  vmovaps [rsp+0x50], xmm5
000070404d1d9ac6  vmovaps [rsp+0x60], xmm6
000070404d1d9acc  vmovaps [rsp+0x70], xmm7
000070404d1d9ad2  vmovaps [rsp+0x80], xmm8
000070404d1d9adb  vmovaps [rsp+0x90], xmm9
000070404d1d9ae4  vmovaps [rsp+0xA0], xmm10
000070404d1d9aed  vmovaps [rsp+0xB0], xmm11
000070404d1d9af6  vmovaps [rsp+0xC0], xmm13
000070404d1d9aff  vmovaps [rsp+0xD0], xmm14
000070404d1d9b08  vmovaps [rsp+0xE0], xmm15
000070404d1d9b11  sub rsp, 0x40
000070404d1d9b15  lea rdi, [rsp]
000070404d1d9b19  lea rsi, [rsp+0x10]
000070404d1d9b1e  lea rdx, [rsp+0x20]
000070404d1d9b23  lea rcx, [rsp+0x30]
000070404d1d9b28  mov r8d, 0x00
000070404d1d9b2e  lea r9, [r15+0x3A8]
000070404d1d9b35  movaps [rdi], xmm12
000070404d1d9b39  movaps [rsi], xmm10
000070404d1d9b3d  movaps [rdx], xmm15
000070404d1d9b41  movaps [rcx], xmm14
000070404d1d9b45  mov rax, 0x607928F07A50
000070404d1d9b4f  call rax
000070404d1d9b51  movaps xmm12, [rsp]
000070404d1d9b56  add rsp, 0x40
000070404d1d9b5a  vmovaps xmm0, [rsp]
000070404d1d9b5f  vmovaps xmm1, [rsp+0x10]
000070404d1d9b65  vmovaps xmm2, [rsp+0x20]
000070404d1d9b6b  vmovaps xmm3, [rsp+0x30]
000070404d1d9b71  vmovaps xmm4, [rsp+0x40]
000070404d1d9b77  vmovaps xmm5, [rsp+0x50]
000070404d1d9b7d  vmovaps xmm6, [rsp+0x60]
000070404d1d9b83  vmovaps xmm7, [rsp+0x70]
000070404d1d9b89  vmovaps xmm8, [rsp+0x80]
000070404d1d9b92  vmovaps xmm9, [rsp+0x90]
000070404d1d9b9b  vmovaps xmm10, [rsp+0xA0]
000070404d1d9ba4  vmovaps xmm11, [rsp+0xB0]
000070404d1d9bad  vmovaps xmm13, [rsp+0xC0]
000070404d1d9bb6  vmovaps xmm14, [rsp+0xD0]
000070404d1d9bbf  vmovaps xmm15, [rsp+0xE0]
000070404d1d9bc8  add rsp, 0xF0
000070404d1d9bcf  pop r11
000070404d1d9bd1  pop r10
000070404d1d9bd3  pop r9
000070404d1d9bd5  pop r8
000070404d1d9bd7  pop rsi
000070404d1d9bd8  pop rdi
000070404d1d9bd9  pop rdx
000070404d1d9bda  pop rcx
000070404d1d9bdb  pop rax
000070404d1d9bdc  add rsp, 0x08
000070404d1d9be0  jmp 0x000070404D1D73F8
000070404d1d9be5  call 0x000070404D00E760
000070404d1d9bea  jmp 0x000070404D1D7405
000070404d1d9bef  call 0x000070404D00D4E0
000070404d1d9bf4  jmp 0x000070404D1D7412
000070404d1d9bf9  sub rsp, 0x08
000070404d1d9bfd  push rax
000070404d1d9bfe  push rcx
000070404d1d9bff  push rdx
000070404d1d9c00  push rdi
000070404d1d9c01  push rsi
000070404d1d9c02  push r8
000070404d1d9c04  push r9
000070404d1d9c06  push r10
000070404d1d9c08  push r11
000070404d1d9c0a  sub rsp, 0xF0
000070404d1d9c11  vmovaps [rsp], xmm0
000070404d1d9c16  vmovaps [rsp+0x10], xmm1
000070404d1d9c1c  vmovaps [rsp+0x20], xmm2
000070404d1d9c22  vmovaps [rsp+0x30], xmm3
000070404d1d9c28  vmovaps [rsp+0x40], xmm4
000070404d1d9c2e  vmovaps [rsp+0x50], xmm5
000070404d1d9c34  vmovaps [rsp+0x60], xmm6
000070404d1d9c3a  vmovaps [rsp+0x70], xmm7
000070404d1d9c40  vmovaps [rsp+0x80], xmm8
000070404d1d9c49  vmovaps [rsp+0x90], xmm9
000070404d1d9c52  vmovaps [rsp+0xA0], xmm11
000070404d1d9c5b  vmovaps [rsp+0xB0], xmm12
000070404d1d9c64  vmovaps [rsp+0xC0], xmm13
000070404d1d9c6d  vmovaps [rsp+0xD0], xmm14
000070404d1d9c76  vmovaps [rsp+0xE0], xmm15
000070404d1d9c7f  sub rsp, 0x40
000070404d1d9c83  lea rdi, [rsp]
000070404d1d9c87  lea rsi, [rsp+0x10]
000070404d1d9c8c  lea rdx, [rsp+0x20]
000070404d1d9c91  lea rcx, [rsp+0x30]
000070404d1d9c96  mov r8d, 0x00
000070404d1d9c9c  lea r9, [r15+0x3A8]
000070404d1d9ca3  movaps [rdi], xmm10
000070404d1d9ca7  movaps [rsi], xmm7
000070404d1d9caa  movaps [rdx], xmm1
000070404d1d9cad  movaps [rcx], xmm13
000070404d1d9cb1  mov rax, 0x607928F07A50
000070404d1d9cbb  call rax
000070404d1d9cbd  movaps xmm10, [rsp]
000070404d1d9cc2  add rsp, 0x40
000070404d1d9cc6  vmovaps xmm0, [rsp]
000070404d1d9ccb  vmovaps xmm1, [rsp+0x10]
000070404d1d9cd1  vmovaps xmm2, [rsp+0x20]
000070404d1d9cd7  vmovaps xmm3, [rsp+0x30]
000070404d1d9cdd  vmovaps xmm4, [rsp+0x40]
000070404d1d9ce3  vmovaps xmm5, [rsp+0x50]
000070404d1d9ce9  vmovaps xmm6, [rsp+0x60]
000070404d1d9cef  vmovaps xmm7, [rsp+0x70]
000070404d1d9cf5  vmovaps xmm8, [rsp+0x80]
000070404d1d9cfe  vmovaps xmm9, [rsp+0x90]
000070404d1d9d07  vmovaps xmm11, [rsp+0xA0]
000070404d1d9d10  vmovaps xmm12, [rsp+0xB0]
000070404d1d9d19  vmovaps xmm13, [rsp+0xC0]
000070404d1d9d22  vmovaps xmm14, [rsp+0xD0]
000070404d1d9d2b  vmovaps xmm15, [rsp+0xE0]
000070404d1d9d34  add rsp, 0xF0
000070404d1d9d3b  pop r11
000070404d1d9d3d  pop r10
000070404d1d9d3f  pop r9
000070404d1d9d41  pop r8
000070404d1d9d43  pop rsi
000070404d1d9d44  pop rdi
000070404d1d9d45  pop rdx
000070404d1d9d46  pop rcx
000070404d1d9d47  pop rax
000070404d1d9d48  add rsp, 0x08
000070404d1d9d4c  jmp 0x000070404D1D7448
000070404d1d9d51  call 0x000070404CFFF430
000070404d1d9d56  jmp 0x000070404D1D745A
000070404d1d9d5b  sub rsp, 0x08
000070404d1d9d5f  push rax
000070404d1d9d60  push rcx
000070404d1d9d61  push rdx
000070404d1d9d62  push rdi
000070404d1d9d63  push rsi
000070404d1d9d64  push r8
000070404d1d9d66  push r9
000070404d1d9d68  push r10
000070404d1d9d6a  push r11
000070404d1d9d6c  sub rsp, 0xF0
000070404d1d9d73  vmovaps [rsp], xmm0
000070404d1d9d78  vmovaps [rsp+0x10], xmm1
000070404d1d9d7e  vmovaps [rsp+0x20], xmm2
000070404d1d9d84  vmovaps [rsp+0x30], xmm3
000070404d1d9d8a  vmovaps [rsp+0x40], xmm4
000070404d1d9d90  vmovaps [rsp+0x50], xmm5
000070404d1d9d96  vmovaps [rsp+0x60], xmm6
000070404d1d9d9c  vmovaps [rsp+0x70], xmm7
000070404d1d9da2  vmovaps [rsp+0x80], xmm8
000070404d1d9dab  vmovaps [rsp+0x90], xmm10
000070404d1d9db4  vmovaps [rsp+0xA0], xmm11
000070404d1d9dbd  vmovaps [rsp+0xB0], xmm12
000070404d1d9dc6  vmovaps [rsp+0xC0], xmm13
000070404d1d9dcf  vmovaps [rsp+0xD0], xmm14
000070404d1d9dd8  vmovaps [rsp+0xE0], xmm15
000070404d1d9de1  sub rsp, 0x40
000070404d1d9de5  lea rdi, [rsp]
000070404d1d9de9  lea rsi, [rsp+0x10]
000070404d1d9dee  lea rdx, [rsp+0x20]
000070404d1d9df3  lea rcx, [rsp+0x30]
000070404d1d9df8  mov r8d, 0x00
000070404d1d9dfe  lea r9, [r15+0x3A8]
000070404d1d9e05  movaps [rdi], xmm9
000070404d1d9e09  movaps [rsi], xmm8
000070404d1d9e0d  movaps [rdx], xmm14
000070404d1d9e11  movaps [rcx], xmm13
000070404d1d9e15  mov rax, 0x607928F07A50
000070404d1d9e1f  call rax
000070404d1d9e21  movaps xmm9, [rsp]
000070404d1d9e26  add rsp, 0x40
000070404d1d9e2a  vmovaps xmm0, [rsp]
000070404d1d9e2f  vmovaps xmm1, [rsp+0x10]
000070404d1d9e35  vmovaps xmm2, [rsp+0x20]
000070404d1d9e3b  vmovaps xmm3, [rsp+0x30]
000070404d1d9e41  vmovaps xmm4, [rsp+0x40]
000070404d1d9e47  vmovaps xmm5, [rsp+0x50]
000070404d1d9e4d  vmovaps xmm6, [rsp+0x60]
000070404d1d9e53  vmovaps xmm7, [rsp+0x70]
000070404d1d9e59  vmovaps xmm8, [rsp+0x80]
000070404d1d9e62  vmovaps xmm10, [rsp+0x90]
000070404d1d9e6b  vmovaps xmm11, [rsp+0xA0]
000070404d1d9e74  vmovaps xmm12, [rsp+0xB0]
000070404d1d9e7d  vmovaps xmm13, [rsp+0xC0]
000070404d1d9e86  vmovaps xmm14, [rsp+0xD0]
000070404d1d9e8f  vmovaps xmm15, [rsp+0xE0]
000070404d1d9e98  add rsp, 0xF0
000070404d1d9e9f  pop r11
000070404d1d9ea1  pop r10
000070404d1d9ea3  pop r9
000070404d1d9ea5  pop r8
000070404d1d9ea7  pop rsi
000070404d1d9ea8  pop rdi
000070404d1d9ea9  pop rdx
000070404d1d9eaa  pop rcx
000070404d1d9eab  pop rax
000070404d1d9eac  add rsp, 0x08
000070404d1d9eb0  jmp 0x000070404D1D7488
000070404d1d9eb5  sub rsp, 0x08
000070404d1d9eb9  push rax
000070404d1d9eba  push rcx
000070404d1d9ebb  push rdx
000070404d1d9ebc  push rdi
000070404d1d9ebd  push rsi
000070404d1d9ebe  push r8
000070404d1d9ec0  push r9
000070404d1d9ec2  push r10
000070404d1d9ec4  push r11
000070404d1d9ec6  sub rsp, 0xF0
000070404d1d9ecd  vmovaps [rsp], xmm0
000070404d1d9ed2  vmovaps [rsp+0x10], xmm1
000070404d1d9ed8  vmovaps [rsp+0x20], xmm2
000070404d1d9ede  vmovaps [rsp+0x30], xmm3
000070404d1d9ee4  vmovaps [rsp+0x40], xmm4
000070404d1d9eea  vmovaps [rsp+0x50], xmm5
000070404d1d9ef0  vmovaps [rsp+0x60], xmm6
000070404d1d9ef6  vmovaps [rsp+0x70], xmm7
000070404d1d9efc  vmovaps [rsp+0x80], xmm8
000070404d1d9f05  vmovaps [rsp+0x90], xmm9
000070404d1d9f0e  vmovaps [rsp+0xA0], xmm10
000070404d1d9f17  vmovaps [rsp+0xB0], xmm11
000070404d1d9f20  vmovaps [rsp+0xC0], xmm12
000070404d1d9f29  vmovaps [rsp+0xD0], xmm14
000070404d1d9f32  vmovaps [rsp+0xE0], xmm15
000070404d1d9f3b  sub rsp, 0x40
000070404d1d9f3f  lea rdi, [rsp]
000070404d1d9f43  lea rsi, [rsp+0x10]
000070404d1d9f48  lea rdx, [rsp+0x20]
000070404d1d9f4d  lea rcx, [rsp+0x30]
000070404d1d9f52  mov r8d, 0x00
000070404d1d9f58  lea r9, [r15+0x3A8]
000070404d1d9f5f  movaps [rdi], xmm13
000070404d1d9f63  movaps [rsi], xmm11
000070404d1d9f67  movaps [rdx], xmm15
000070404d1d9f6b  movaps [rcx], xmm14
000070404d1d9f6f  mov rax, 0x607928F07A50
000070404d1d9f79  call rax
000070404d1d9f7b  movaps xmm13, [rsp]
000070404d1d9f80  add rsp, 0x40
000070404d1d9f84  vmovaps xmm0, [rsp]
000070404d1d9f89  vmovaps xmm1, [rsp+0x10]
000070404d1d9f8f  vmovaps xmm2, [rsp+0x20]
000070404d1d9f95  vmovaps xmm3, [rsp+0x30]
000070404d1d9f9b  vmovaps xmm4, [rsp+0x40]
000070404d1d9fa1  vmovaps xmm5, [rsp+0x50]
000070404d1d9fa7  vmovaps xmm6, [rsp+0x60]
000070404d1d9fad  vmovaps xmm7, [rsp+0x70]
000070404d1d9fb3  vmovaps xmm8, [rsp+0x80]
000070404d1d9fbc  vmovaps xmm9, [rsp+0x90]
000070404d1d9fc5  vmovaps xmm10, [rsp+0xA0]
000070404d1d9fce  vmovaps xmm11, [rsp+0xB0]
000070404d1d9fd7  vmovaps xmm12, [rsp+0xC0]
000070404d1d9fe0  vmovaps xmm14, [rsp+0xD0]
000070404d1d9fe9  vmovaps xmm15, [rsp+0xE0]
000070404d1d9ff2  add rsp, 0xF0
000070404d1d9ff9  pop r11
000070404d1d9ffb  pop r10
000070404d1d9ffd  pop r9
000070404d1d9fff  pop r8
000070404d1da001  pop rsi
000070404d1da002  pop rdi
000070404d1da003  pop rdx
000070404d1da004  pop rcx
000070404d1da005  pop rax
000070404d1da006  add rsp, 0x08
000070404d1da00a  jmp 0x000070404D1D74B6
000070404d1da00f  sub rsp, 0x08
000070404d1da013  push rax
000070404d1da014  push rcx
000070404d1da015  push rdx
000070404d1da016  push rdi
000070404d1da017  push rsi
000070404d1da018  push r8
000070404d1da01a  push r9
000070404d1da01c  push r10
000070404d1da01e  push r11
000070404d1da020  sub rsp, 0xF0
000070404d1da027  vmovaps [rsp], xmm0
000070404d1da02c  vmovaps [rsp+0x10], xmm1
000070404d1da032  vmovaps [rsp+0x20], xmm2
000070404d1da038  vmovaps [rsp+0x30], xmm3
000070404d1da03e  vmovaps [rsp+0x40], xmm4
000070404d1da044  vmovaps [rsp+0x50], xmm5
000070404d1da04a  vmovaps [rsp+0x60], xmm6
000070404d1da050  vmovaps [rsp+0x70], xmm7
000070404d1da056  vmovaps [rsp+0x80], xmm8
000070404d1da05f  vmovaps [rsp+0x90], xmm9
000070404d1da068  vmovaps [rsp+0xA0], xmm10
000070404d1da071  vmovaps [rsp+0xB0], xmm11
000070404d1da07a  vmovaps [rsp+0xC0], xmm12
000070404d1da083  vmovaps [rsp+0xD0], xmm13
000070404d1da08c  vmovaps [rsp+0xE0], xmm15
000070404d1da095  sub rsp, 0x40
000070404d1da099  lea rdi, [rsp]
000070404d1da09d  lea rsi, [rsp+0x10]
000070404d1da0a2  lea rdx, [rsp+0x20]
000070404d1da0a7  lea rcx, [rsp+0x30]
000070404d1da0ac  mov r8d, 0x00
000070404d1da0b2  lea r9, [r15+0x3A8]
000070404d1da0b9  movaps [rdi], xmm14
000070404d1da0bd  movaps [rsi], xmm12
000070404d1da0c1  movaps [rdx], xmm1
000070404d1da0c4  movaps [rcx], xmm15
000070404d1da0c8  mov rax, 0x607928F07A50
000070404d1da0d2  call rax
000070404d1da0d4  movaps xmm14, [rsp]
000070404d1da0d9  add rsp, 0x40
000070404d1da0dd  vmovaps xmm0, [rsp]
000070404d1da0e2  vmovaps xmm1, [rsp+0x10]
000070404d1da0e8  vmovaps xmm2, [rsp+0x20]
000070404d1da0ee  vmovaps xmm3, [rsp+0x30]
000070404d1da0f4  vmovaps xmm4, [rsp+0x40]
000070404d1da0fa  vmovaps xmm5, [rsp+0x50]
000070404d1da100  vmovaps xmm6, [rsp+0x60]
000070404d1da106  vmovaps xmm7, [rsp+0x70]
000070404d1da10c  vmovaps xmm8, [rsp+0x80]
000070404d1da115  vmovaps xmm9, [rsp+0x90]
000070404d1da11e  vmovaps xmm10, [rsp+0xA0]
000070404d1da127  vmovaps xmm11, [rsp+0xB0]
000070404d1da130  vmovaps xmm12, [rsp+0xC0]
000070404d1da139  vmovaps xmm13, [rsp+0xD0]
000070404d1da142  vmovaps xmm15, [rsp+0xE0]
000070404d1da14b  add rsp, 0xF0
000070404d1da152  pop r11
000070404d1da154  pop r10
000070404d1da156  pop r9
000070404d1da158  pop r8
000070404d1da15a  pop rsi
000070404d1da15b  pop rdi
000070404d1da15c  pop rdx
000070404d1da15d  pop rcx
000070404d1da15e  pop rax
000070404d1da15f  add rsp, 0x08
000070404d1da163  jmp 0x000070404D1D74E4
000070404d1da168  call 0x000070404D0079B0
000070404d1da16d  jmp 0x000070404D1D74FA
000070404d1da172  call 0x000070404D0E3440
000070404d1da177  jmp 0x000070404D1D7504
000070404d1da17c  call 0x000070404D0DFCE0
000070404d1da181  jmp 0x000070404D1D750E
000070404d1da186  call 0x000070404D0E46C0
000070404d1da18b  jmp 0x000070404D1D7518
000070404d1da190  int3
000070404d1da191  nop [rax+rax*1], ax
000070404d1da19a  nop [rax+rax*1], ax
000070404d1da1a0  mov rax, [r15+0xF8]
000070404d1da1a7  lea r14, [rax+0x110]
000070404d1da1ae  mov r12, [r13+r14*1]
000070404d1da1b3  mov [r15+0xE8], r12
000070404d1da1ba  lea r14, [rax+0x100]
000070404d1da1c1  mov r12, [r13+r14*1]
000070404d1da1c6  lea r14, [rax+0x108]
000070404d1da1cd  mov r11, [r13+r14*1]
000070404d1da1d2  movq xmm1, r12
000070404d1da1d7  movq xmm15, r11
000070404d1da1dc  movq xmm1, xmm1
000070404d1da1e0  movq xmm1, xmm1
000070404d1da1e4  movaps [r15+0x1A0], xmm1
000070404d1da1ec  movq xmm15, xmm15
000070404d1da1f1  movq xmm15, xmm15
000070404d1da1f6  movaps [r15+0x190], xmm15
000070404d1da1fe  lea r14, [rax+0xF0]
000070404d1da205  mov r12, [r13+r14*1]
000070404d1da20a  lea r14, [rax+0xF8]
000070404d1da211  mov r11, [r13+r14*1]
000070404d1da216  movq xmm1, r12
000070404d1da21b  movq xmm15, r11
000070404d1da220  movq xmm1, xmm1
000070404d1da224  movq xmm1, xmm1
000070404d1da228  movaps [r15+0x1C0], xmm1
000070404d1da230  movq xmm15, xmm15
000070404d1da235  movq xmm15, xmm15
000070404d1da23a  movaps [r15+0x1B0], xmm15
000070404d1da242  lea r14, [rax+0xE0]
000070404d1da249  mov r12, [r13+r14*1]
000070404d1da24e  lea r14, [rax+0xE8]
000070404d1da255  mov r11, [r13+r14*1]
000070404d1da25a  movq xmm1, r12
000070404d1da25f  movq xmm15, r11
000070404d1da264  movq xmm1, xmm1
000070404d1da268  movq xmm1, xmm1
000070404d1da26c  movaps [r15+0x1E0], xmm1
000070404d1da274  movq xmm15, xmm15
000070404d1da279  movq xmm15, xmm15
000070404d1da27e  movaps [r15+0x1D0], xmm15
000070404d1da286  lea r14, [rax+0xD0]
000070404d1da28d  mov r12, [r13+r14*1]
000070404d1da292  lea r14, [rax+0xD8]
000070404d1da299  mov r11, [r13+r14*1]
000070404d1da29e  movq xmm1, r12
000070404d1da2a3  movq xmm15, r11
000070404d1da2a8  movq xmm1, xmm1
000070404d1da2ac  movq xmm1, xmm1
000070404d1da2b0  movaps [r15+0x200], xmm1
000070404d1da2b8  movq xmm15, xmm15
000070404d1da2bd  movq xmm15, xmm15
000070404d1da2c2  movaps [r15+0x1F0], xmm15
000070404d1da2ca  mov qword ptr [r15+0x40], 0x430000
000070404d1da2d2  mov r14d, 0x4304C0
000070404d1da2d8  mov r12, [r13+r14*1]
000070404d1da2dd  movq xmm1, r12
000070404d1da2e2  lea r14, [rax+0x120]
000070404d1da2e9  mov [r15+0xF8], r14
000070404d1da2f0  mov rax, [r15+0x50]
000070404d1da2f4  movups xmm15, [r13+rax*1]
000070404d1da2fa  movaps [r15+0x120], xmm15
000070404d1da302  mov qword ptr [r15+0x48], 0x10
000070404d1da30a  xor eax, eax
000070404d1da30c  mov r14d, 0x10
000070404d1da312  mov r12d, 0x200
000070404d1da318  cmp r14, r12
000070404d1da31b  cmc
000070404d1da31c  lahf
000070404d1da31d  seto al
000070404d1da320  mov [r15+0x108], eax
000070404d1da327  pextrq rax, xmm15, 0x01
000070404d1da32e  movq xmm14, rax
000070404d1da333  movaps [r15+0x130], xmm14
000070404d1da33b  movq rax, xmm1
000070404d1da340  movq r14, xmm15
000070404d1da345  vmovq xmm1, rax
000070404d1da34a  vmovq xmm15, r14
000070404d1da34f  movaps xmm13, xmm1
000070404d1da353  addsd xmm13, xmm15
000070404d1da358  ucomisd xmm13, xmm13
000070404d1da35d  jp 0x000070404D1DA476
000070404d1da363  movq xmm13, xmm13
000070404d1da368  movq rax, xmm13
000070404d1da36d  movq r14, xmm14
000070404d1da372  vmovq xmm1, rax
000070404d1da377  vmovq xmm15, r14
000070404d1da37c  movaps xmm14, xmm1
000070404d1da380  addsd xmm14, xmm15
000070404d1da385  ucomisd xmm14, xmm14
000070404d1da38a  jp 0x000070404D1DA4BE
000070404d1da390  movq xmm14, xmm14
000070404d1da395  movaps [r15+0x110], xmm14
000070404d1da39d  mov eax, [r15+0x108]
000070404d1da3a4  sahf
000070404d1da3a5  jnz 0x000070404D1DA3D7
000070404d1da3a7  cmp dword ptr [r15+0x318], 0x00
000070404d1da3af  jz 0x000070404D1DA6D0
000070404d1da3b5  nop [rax+rax*1], ax
000070404d1da3be  nop [rax+rax*1], eax
000070404d1da3c6  mov eax, 0x41043C
000070404d1da3cb  mov [r15+0x100], rax
000070404d1da3d2  jmp 0x000070404CFFE110
000070404d1da3d7  cmp dword ptr [r15+0x318], 0x00
000070404d1da3df  jz 0x000070404D1DA510
000070404d1da3e5  nop [rax+rax*1], ax
000070404d1da3ee  nop [rax+rax*1], eax
000070404d1da3f6  mov eax, 0x410420
000070404d1da3fb  mov [r15+0x100], rax
000070404d1da402  jmp 0x000070404CFFE110
000070404d1da407  int3
000070404d1da408  call 0x000070404D0E27E0
000070404d1da40d  jmp 0x000070404D1DA1B3
000070404d1da412  call 0x000070404D0E27E0
000070404d1da417  jmp 0x000070404D1DA1C6
000070404d1da41c  call 0x000070404D0E1570
000070404d1da421  jmp 0x000070404D1DA1D2
000070404d1da426  call 0x000070404D0E27E0
000070404d1da42b  jmp 0x000070404D1DA20A
000070404d1da430  call 0x000070404D0E1570
000070404d1da435  jmp 0x000070404D1DA216
000070404d1da43a  call 0x000070404D0E27E0
000070404d1da43f  jmp 0x000070404D1DA24E
000070404d1da444  call 0x000070404D0E1570
000070404d1da449  jmp 0x000070404D1DA25A
000070404d1da44e  call 0x000070404D0E27E0
000070404d1da453  jmp 0x000070404D1DA292
000070404d1da458  call 0x000070404D0E1570
000070404d1da45d  jmp 0x000070404D1DA29E
000070404d1da462  call 0x000070404D0E27E0
000070404d1da467  jmp 0x000070404D1DA2DD
000070404d1da46c  call 0x000070404D00E760
000070404d1da471  jmp 0x000070404D1DA2FA
000070404d1da476  ucomisd xmm1, xmm15
000070404d1da47b  jp 0x000070404D1DA48A
000070404d1da47d  movaps xmm13, [0x000070404CDFE060]
000070404d1da485  jmp 0x000070404D1DA363
000070404d1da48a  vxorps xmm0, xmm1, xmm15
000070404d1da48f  pextrw eax, xmm0, 0x03
000070404d1da494  and eax, 0x7FF8
000070404d1da499  cmp eax, 0x08
000070404d1da49c  jnz 0x000070404D1DA363
000070404d1da4a2  movq rax, xmm15
000070404d1da4a7  shl rax, 0x0D
000070404d1da4ab  jbe 0x000070404D1DA363
000070404d1da4b1  vorps xmm13, xmm15, [0x000070404CDFE070]
000070404d1da4b9  jmp 0x000070404D1DA363
000070404d1da4be  ucomisd xmm1, xmm15
000070404d1da4c3  jp 0x000070404D1DA4D2
000070404d1da4c5  movaps xmm14, [0x000070404CDFE060]
000070404d1da4cd  jmp 0x000070404D1DA390
000070404d1da4d2  vxorps xmm0, xmm1, xmm15
000070404d1da4d7  pextrw eax, xmm0, 0x03
000070404d1da4dc  and eax, 0x7FF8
000070404d1da4e1  cmp eax, 0x08
000070404d1da4e4  jnz 0x000070404D1DA390
000070404d1da4ea  movq rax, xmm15
000070404d1da4ef  shl rax, 0x0D
000070404d1da4f3  jbe 0x000070404D1DA390
000070404d1da4f9  vorps xmm14, xmm15, [0x000070404CDFE070]
000070404d1da501  jmp 0x000070404D1DA390
000070404d1da506  int3
000070404d1da507  nop [rax+rax*1], ax
000070404d1da510  mov rax, [r15+0x48]
000070404d1da514  mov r14, [r15+0x50]
000070404d1da518  lea r12, [r14+rax*1]
000070404d1da51c  movups xmm1, [r13+r12*1]
000070404d1da522  movaps [r15+0x120], xmm1
000070404d1da52a  lea r14, [rax+0x10]
000070404d1da52e  mov [r15+0x48], r14
000070404d1da532  xor eax, eax
000070404d1da534  mov r12d, 0x200
000070404d1da53a  cmp r14, r12
000070404d1da53d  cmc
000070404d1da53e  lahf
000070404d1da53f  seto al
000070404d1da542  mov [r15+0x108], eax
000070404d1da549  pextrq rax, xmm1, 0x01
000070404d1da550  movq xmm15, rax
000070404d1da555  movaps [r15+0x130], xmm15
000070404d1da55d  movaps xmm14, [r15+0x110]
000070404d1da565  movq rax, xmm14
000070404d1da56a  movq r14, xmm1
000070404d1da56f  vmovq xmm1, rax
000070404d1da574  vmovq xmm14, r14
000070404d1da579  movaps xmm13, xmm1
000070404d1da57d  addsd xmm13, xmm14
000070404d1da582  ucomisd xmm13, xmm13
000070404d1da587  jp 0x000070404D1DA63C
000070404d1da58d  movq xmm13, xmm13
000070404d1da592  movq rax, xmm13
000070404d1da597  movq r14, xmm15
000070404d1da59c  vmovq xmm1, rax
000070404d1da5a1  vmovq xmm15, r14
000070404d1da5a6  movaps xmm14, xmm1
000070404d1da5aa  addsd xmm14, xmm15
000070404d1da5af  ucomisd xmm14, xmm14
000070404d1da5b4  jp 0x000070404D1DA684
000070404d1da5ba  movq xmm14, xmm14
000070404d1da5bf  movaps [r15+0x110], xmm14
000070404d1da5c7  mov eax, [r15+0x108]
000070404d1da5ce  sahf
000070404d1da5cf  jnz 0x000070404D1DA601
000070404d1da5d1  cmp dword ptr [r15+0x318], 0x00
000070404d1da5d9  jz 0x000070404D1DA6D0
000070404d1da5df  nop [rax+rax*1], ax
000070404d1da5e8  nop [rax+rax*1], eax
000070404d1da5f0  mov eax, 0x41043C
000070404d1da5f5  mov [r15+0x100], rax
000070404d1da5fc  jmp 0x000070404CFFE110
000070404d1da601  cmp dword ptr [r15+0x318], 0x00
000070404d1da609  jz 0x000070404D1DA510
000070404d1da60f  nop [rax+rax*1], ax
000070404d1da618  nop [rax+rax*1], eax
000070404d1da620  mov eax, 0x410420
000070404d1da625  mov [r15+0x100], rax
000070404d1da62c  jmp 0x000070404CFFE110
000070404d1da631  int3
000070404d1da632  call 0x000070404D0B52F0
000070404d1da637  jmp 0x000070404D1DA522
000070404d1da63c  ucomisd xmm1, xmm14
000070404d1da641  jp 0x000070404D1DA650
000070404d1da643  movaps xmm13, [0x000070404CDFE060]
000070404d1da64b  jmp 0x000070404D1DA58D
000070404d1da650  vxorps xmm0, xmm1, xmm14
000070404d1da655  pextrw eax, xmm0, 0x03
000070404d1da65a  and eax, 0x7FF8
000070404d1da65f  cmp eax, 0x08
000070404d1da662  jnz 0x000070404D1DA58D
000070404d1da668  movq rax, xmm14
000070404d1da66d  shl rax, 0x0D
000070404d1da671  jbe 0x000070404D1DA58D
000070404d1da677  vorps xmm13, xmm14, [0x000070404CDFE070]
000070404d1da67f  jmp 0x000070404D1DA58D
000070404d1da684  ucomisd xmm1, xmm15
000070404d1da689  jp 0x000070404D1DA698
000070404d1da68b  movaps xmm14, [0x000070404CDFE060]
000070404d1da693  jmp 0x000070404D1DA5BA
000070404d1da698  vxorps xmm0, xmm1, xmm15
000070404d1da69d  pextrw eax, xmm0, 0x03
000070404d1da6a2  and eax, 0x7FF8
000070404d1da6a7  cmp eax, 0x08
000070404d1da6aa  jnz 0x000070404D1DA5BA
000070404d1da6b0  movq rax, xmm15
000070404d1da6b5  shl rax, 0x0D
000070404d1da6b9  jbe 0x000070404D1DA5BA
000070404d1da6bf  vorps xmm14, xmm15, [0x000070404CDFE070]
000070404d1da6c7  jmp 0x000070404D1DA5BA
000070404d1da6cc  int3
000070404d1da6cd  nop [rax], eax
000070404d1da6d0  mov rax, [r15+0x40]
000070404d1da6d4  lea r14, [rax+0x4C0]
000070404d1da6db  movaps xmm1, [r15+0x110]
000070404d1da6e3  movq rax, xmm1
000070404d1da6e8  mov [r13+r14*1], rax
000070404d1da6ed  mov rax, [r15+0xF0]
000070404d1da6f4  mov [r15+0x100], rax
000070404d1da6fb  jmp 0x000070404D1CE5C0
000070404d1da700  int3
000070404d1da701  call 0x000070404D0D5EB0
000070404d1da706  jmp 0x000070404D1DA6ED
000070404d1da70b  int3
000070404d1da70c  nop [rax], eax
000070404d1da710  mov qword ptr [r15+0x100], 0x04
000070404d1da71b  mov esi, 0x00
000070404d1da720  mov edx, 0x09
000070404d1da725  mov rdi, 0x7FFCF0ACD5A0
000070404d1da72f  mov rax, 0x607928D9A970
000070404d1da739  call rax
000070404d1da73b  cmp dword ptr [r15+0x318], 0x00
000070404d1da743  jnz 0x000070404CFFE110
000070404d1da749  jmp 0x000070404CFFE0A0
000070404d1da74e  int3
000070404d1da74f  int3
