00007eefba3ce69b  nop [rax+rax*1], eax
00007eefba3ce6a0  mov rax, [r15+0xF8]
00007eefba3ce6a7  lea r14, [rax-0xA0]
00007eefba3ce6ae  mov [r15+0xF8], r14
00007eefba3ce6b5  lea rax, [r14+0x90]
00007eefba3ce6bc  mov r12, [r15+0xA0]
00007eefba3ce6c3  mov r11, [r15+0x98]
00007eefba3ce6ca  mov [r13+rax*1], r12
00007eefba3ce6cf  lea rax, [r14+0x98]
00007eefba3ce6d6  mov [r13+rax*1], r11
00007eefba3ce6db  mov eax, 0x420670
00007eefba3ce6e0  movups xmm1, [r13+rax*1]
00007eefba3ce6e6  mov eax, 0x420610
00007eefba3ce6eb  movups xmm15, [r13+rax*1]
00007eefba3ce6f1  mov eax, 0x420690
00007eefba3ce6f6  movups xmm14, [r13+rax*1]
00007eefba3ce6fc  mov eax, 0x420630
00007eefba3ce701  movups xmm13, [r13+rax*1]
00007eefba3ce707  mov qword ptr [r15+0x98], 0x4308A0
00007eefba3ce712  mov eax, 0x4206A0
00007eefba3ce717  movups xmm12, [r13+rax*1]
00007eefba3ce71d  mov eax, 0x4308A0
00007eefba3ce722  movups [r13+rax*1], xmm1
00007eefba3ce728  mov eax, 0x4308B0
00007eefba3ce72d  movups [r13+rax*1], xmm15
00007eefba3ce733  mov eax, 0x4308C0
00007eefba3ce738  movups [r13+rax*1], xmm14
00007eefba3ce73e  mov eax, 0x4308D0
00007eefba3ce743  movups [r13+rax*1], xmm13
00007eefba3ce749  mov eax, 0x420600
00007eefba3ce74e  movups xmm14, [r13+rax*1]
00007eefba3ce754  mov eax, 0x4205F0
00007eefba3ce759  movups xmm13, [r13+rax*1]
00007eefba3ce75f  mov eax, 0x4309A0
00007eefba3ce764  movups [r13+rax*1], xmm1
00007eefba3ce76a  mov eax, 0x4309B0
00007eefba3ce76f  movups [r13+rax*1], xmm15
00007eefba3ce775  mov eax, 0x4308E0
00007eefba3ce77a  movups [r13+rax*1], xmm12
00007eefba3ce780  mov eax, 0x4308F0
00007eefba3ce785  movups [r13+rax*1], xmm14
00007eefba3ce78b  mov eax, 0x4205E0
00007eefba3ce790  movups xmm1, [r13+rax*1]
00007eefba3ce796  mov eax, 0x420640
00007eefba3ce79b  movups xmm15, [r13+rax*1]
00007eefba3ce7a1  mov eax, 0x430900
00007eefba3ce7a6  movups [r13+rax*1], xmm13
00007eefba3ce7ac  mov eax, 0x430910
00007eefba3ce7b1  movups [r13+rax*1], xmm1
00007eefba3ce7b7  mov eax, 0x420650
00007eefba3ce7bc  movups xmm1, [r13+rax*1]
00007eefba3ce7c2  mov eax, 0x420620
00007eefba3ce7c7  movups xmm14, [r13+rax*1]
00007eefba3ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007eefba3ce7d5  mov eax, 0x430920
00007eefba3ce7da  movups [r13+rax*1], xmm15
00007eefba3ce7e0  mov eax, 0x430930
00007eefba3ce7e5  movups [r13+rax*1], xmm1
00007eefba3ce7eb  mov eax, 0x4206C0
00007eefba3ce7f0  movups xmm1, [r13+rax*1]
00007eefba3ce7f6  mov eax, 0x4206D0
00007eefba3ce7fb  movups xmm15, [r13+rax*1]
00007eefba3ce801  movaps [r15+0x150], xmm15
00007eefba3ce809  mov qword ptr [r15+0xA0], 0x3E8
00007eefba3ce814  mov eax, 0x430940
00007eefba3ce819  movups [r13+rax*1], xmm14
00007eefba3ce81f  mov eax, 0x430950
00007eefba3ce824  movups [r13+rax*1], xmm1
00007eefba3ce82a  mov eax, 0x4206B0
00007eefba3ce82f  movups xmm1, [r13+rax*1]
00007eefba3ce835  mov eax, 0x420660
00007eefba3ce83a  movups xmm14, [r13+rax*1]
00007eefba3ce840  movaps [r15+0x140], xmm14
00007eefba3ce848  lea rax, [r14+0x80]
00007eefba3ce84f  mov r12, [r15+0xF0]
00007eefba3ce856  mov [r13+rax*1], r12
00007eefba3ce85b  mov eax, 0x430960
00007eefba3ce860  movups [r13+rax*1], xmm15
00007eefba3ce866  mov eax, 0x430970
00007eefba3ce86b  movups [r13+rax*1], xmm1
00007eefba3ce871  mov eax, 0x420680
00007eefba3ce876  movups xmm1, [r13+rax*1]
00007eefba3ce87c  mov eax, 0x4206E0
00007eefba3ce881  mov r12, [r13+rax*1]
00007eefba3ce886  movq xmm15, r12
00007eefba3ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007eefba3ce893  mov eax, 0x430980
00007eefba3ce898  movups [r13+rax*1], xmm14
00007eefba3ce89e  mov eax, 0x430990
00007eefba3ce8a3  movups [r13+rax*1], xmm1
00007eefba3ce8a9  mov eax, 0x420748
00007eefba3ce8ae  movups xmm1, [r13+rax*1]
00007eefba3ce8b4  movq rax, xmm15
00007eefba3ce8b9  mov r12d, 0x4309C0
00007eefba3ce8bf  mov [r13+r12*1], rax
00007eefba3ce8c4  mov eax, 0x420728
00007eefba3ce8c9  movups xmm15, [r13+rax*1]
00007eefba3ce8cf  mov eax, 0x420738
00007eefba3ce8d4  movups xmm14, [r13+rax*1]
00007eefba3ce8da  lea rax, [r14+0x60]
00007eefba3ce8de  movups [r13+rax*1], xmm1
00007eefba3ce8e4  mov eax, 0x4309C8
00007eefba3ce8e9  mov r12d, 0x421DF8D3
00007eefba3ce8ef  mov [r13+rax*1], r12d
00007eefba3ce8f4  lea rax, [r14+0x40]
00007eefba3ce8f8  movups [r13+rax*1], xmm15
00007eefba3ce8fe  lea rax, [r14+0x50]
00007eefba3ce902  movups [r13+rax*1], xmm14
00007eefba3ce908  mov eax, 0x4206E8
00007eefba3ce90d  movups xmm1, [r13+rax*1]
00007eefba3ce913  mov eax, 0x4206F8
00007eefba3ce918  movups xmm15, [r13+rax*1]
00007eefba3ce91e  movaps [r15+0x120], xmm15
00007eefba3ce926  movups [r13+r14*1], xmm1
00007eefba3ce92c  lea rax, [r14+0x10]
00007eefba3ce930  movups [r13+rax*1], xmm15
00007eefba3ce936  mov eax, 0x420708
00007eefba3ce93b  movups xmm1, [r13+rax*1]
00007eefba3ce941  mov eax, 0x420718
00007eefba3ce946  movups xmm15, [r13+rax*1]
00007eefba3ce94c  movaps [r15+0x110], xmm1
00007eefba3ce954  movaps [r15+0x130], xmm15
00007eefba3ce95c  lea rax, [r14+0x20]
00007eefba3ce960  movups [r13+rax*1], xmm1
00007eefba3ce966  lea rax, [r14+0x30]
00007eefba3ce96a  movups [r13+rax*1], xmm15
00007eefba3ce970  mov [r15], r14
00007eefba3ce973  mov qword ptr [r15+0x08], 0x4308A0
00007eefba3ce97b  mov qword ptr [r15+0x10], 0x12C
00007eefba3ce983  mov qword ptr [r15+0xF0], 0x410274
00007eefba3ce98e  mov r14d, [r15+0x320]
00007eefba3ce995  mov eax, 0x410274
00007eefba3ce99a  mov rcx, 0x7EEFBA3D0670
00007eefba3ce9a4  mov [r15+r14*8+0x328], rax
00007eefba3ce9ac  mov [r15+r14*8+0x368], rcx
00007eefba3ce9b4  add r14d, 0x01
00007eefba3ce9b8  and r14d, 0x07
00007eefba3ce9bc  mov [r15+0x320], r14d
00007eefba3ce9c3  cmp dword ptr [r15+0x318], 0x00
00007eefba3ce9cb  jz 0x00007EEFBA3CEC20
00007eefba3ce9d1  nop [rax+rax*1], ax
00007eefba3ce9da  nop [rax+rax*1], eax
00007eefba3ce9e2  mov eax, 0x410338
00007eefba3ce9e7  mov [r15+0x100], rax
00007eefba3ce9ee  jmp 0x00007EEFBA1FE110
00007eefba3ce9f3  int3
00007eefba3ce9f4  call 0x00007EEFBA20BC20
00007eefba3ce9f9  jmp 0x00007EEFBA3CE6CF
00007eefba3ce9fe  call 0x00007EEFBA20A9A0
00007eefba3cea03  jmp 0x00007EEFBA3CE6DB
00007eefba3cea08  call 0x00007EEFBA1FF430
00007eefba3cea0d  jmp 0x00007EEFBA3CE6E6
00007eefba3cea12  call 0x00007EEFBA20E760
00007eefba3cea17  jmp 0x00007EEFBA3CE6F1
00007eefba3cea1c  call 0x00007EEFBA20D4E0
00007eefba3cea21  jmp 0x00007EEFBA3CE6FC
00007eefba3cea26  call 0x00007EEFBA20C260
00007eefba3cea2b  jmp 0x00007EEFBA3CE707
00007eefba3cea30  call 0x00007EEFBA20AFE0
00007eefba3cea35  jmp 0x00007EEFBA3CE71D
00007eefba3cea3a  call 0x00007EEFBA1FF540
00007eefba3cea3f  jmp 0x00007EEFBA3CE728
00007eefba3cea44  call 0x00007EEFBA20E880
00007eefba3cea49  jmp 0x00007EEFBA3CE733
00007eefba3cea4e  call 0x00007EEFBA20D600
00007eefba3cea53  jmp 0x00007EEFBA3CE73E
00007eefba3cea58  call 0x00007EEFBA20C380
00007eefba3cea5d  jmp 0x00007EEFBA3CE749
00007eefba3cea62  call 0x00007EEFBA20D4E0
00007eefba3cea67  jmp 0x00007EEFBA3CE754
00007eefba3cea6c  call 0x00007EEFBA20C260
00007eefba3cea71  jmp 0x00007EEFBA3CE75F
00007eefba3cea76  call 0x00007EEFBA1FF540
00007eefba3cea7b  jmp 0x00007EEFBA3CE76A
00007eefba3cea80  call 0x00007EEFBA20E880
00007eefba3cea85  jmp 0x00007EEFBA3CE775
00007eefba3cea8a  call 0x00007EEFBA20B100
00007eefba3cea8f  jmp 0x00007EEFBA3CE780
00007eefba3cea94  call 0x00007EEFBA20D600
00007eefba3cea99  jmp 0x00007EEFBA3CE78B
00007eefba3cea9e  call 0x00007EEFBA1FF430
00007eefba3ceaa3  jmp 0x00007EEFBA3CE796
00007eefba3ceaa8  call 0x00007EEFBA20E760
00007eefba3ceaad  jmp 0x00007EEFBA3CE7A1
00007eefba3ceab2  call 0x00007EEFBA20C380
00007eefba3ceab7  jmp 0x00007EEFBA3CE7AC
00007eefba3ceabc  call 0x00007EEFBA1FF540
00007eefba3ceac1  jmp 0x00007EEFBA3CE7B7
00007eefba3ceac6  call 0x00007EEFBA1FF430
00007eefba3ceacb  jmp 0x00007EEFBA3CE7C2
00007eefba3cead0  call 0x00007EEFBA20D4E0
00007eefba3cead5  jmp 0x00007EEFBA3CE7CD
00007eefba3ceada  call 0x00007EEFBA20E880
00007eefba3ceadf  jmp 0x00007EEFBA3CE7E0
00007eefba3ceae4  call 0x00007EEFBA1FF540
00007eefba3ceae9  jmp 0x00007EEFBA3CE7EB
00007eefba3ceaee  call 0x00007EEFBA1FF430
00007eefba3ceaf3  jmp 0x00007EEFBA3CE7F6
00007eefba3ceaf8  call 0x00007EEFBA20E760
00007eefba3ceafd  jmp 0x00007EEFBA3CE801
00007eefba3ceb02  call 0x00007EEFBA20D600
00007eefba3ceb07  jmp 0x00007EEFBA3CE81F
00007eefba3ceb0c  call 0x00007EEFBA1FF540
00007eefba3ceb11  jmp 0x00007EEFBA3CE82A
00007eefba3ceb16  call 0x00007EEFBA1FF430
00007eefba3ceb1b  jmp 0x00007EEFBA3CE835
00007eefba3ceb20  call 0x00007EEFBA20D4E0
00007eefba3ceb25  jmp 0x00007EEFBA3CE840
00007eefba3ceb2a  call 0x00007EEFBA20BC20
00007eefba3ceb2f  jmp 0x00007EEFBA3CE85B
00007eefba3ceb34  call 0x00007EEFBA20E880
00007eefba3ceb39  jmp 0x00007EEFBA3CE866
00007eefba3ceb3e  call 0x00007EEFBA1FF540
00007eefba3ceb43  jmp 0x00007EEFBA3CE871
00007eefba3ceb48  call 0x00007EEFBA1FF430
00007eefba3ceb4d  jmp 0x00007EEFBA3CE87C
00007eefba3ceb52  call 0x00007EEFBA20B720
00007eefba3ceb57  jmp 0x00007EEFBA3CE886
00007eefba3ceb5c  call 0x00007EEFBA20D600
00007eefba3ceb61  jmp 0x00007EEFBA3CE89E
00007eefba3ceb66  call 0x00007EEFBA1FF540
00007eefba3ceb6b  jmp 0x00007EEFBA3CE8A9
00007eefba3ceb70  call 0x00007EEFBA1FF430
00007eefba3ceb75  jmp 0x00007EEFBA3CE8B4
00007eefba3ceb7a  call 0x00007EEFBA2B4CB0
00007eefba3ceb7f  jmp 0x00007EEFBA3CE8C4
00007eefba3ceb84  call 0x00007EEFBA20E760
00007eefba3ceb89  jmp 0x00007EEFBA3CE8CF
00007eefba3ceb8e  call 0x00007EEFBA20D4E0
00007eefba3ceb93  jmp 0x00007EEFBA3CE8DA
00007eefba3ceb98  call 0x00007EEFBA1FF540
00007eefba3ceb9d  jmp 0x00007EEFBA3CE8E4
00007eefba3ceba2  call 0x00007EEFBA20BAE0
00007eefba3ceba7  jmp 0x00007EEFBA3CE8F4
00007eefba3cebac  call 0x00007EEFBA20E880
00007eefba3cebb1  jmp 0x00007EEFBA3CE8FE
00007eefba3cebb6  call 0x00007EEFBA20D600
00007eefba3cebbb  jmp 0x00007EEFBA3CE908
00007eefba3cebc0  call 0x00007EEFBA1FF430
00007eefba3cebc5  jmp 0x00007EEFBA3CE913
00007eefba3cebca  call 0x00007EEFBA20E760
00007eefba3cebcf  jmp 0x00007EEFBA3CE91E
00007eefba3cebd4  call 0x00007EEFBA2D6600
00007eefba3cebd9  jmp 0x00007EEFBA3CE92C
00007eefba3cebde  call 0x00007EEFBA20E880
00007eefba3cebe3  jmp 0x00007EEFBA3CE936
00007eefba3cebe8  call 0x00007EEFBA1FF430
00007eefba3cebed  jmp 0x00007EEFBA3CE941
00007eefba3cebf2  call 0x00007EEFBA20E760
00007eefba3cebf7  jmp 0x00007EEFBA3CE94C
00007eefba3cebfc  call 0x00007EEFBA1FF540
00007eefba3cec01  jmp 0x00007EEFBA3CE966
00007eefba3cec06  call 0x00007EEFBA20E880
00007eefba3cec0b  jmp 0x00007EEFBA3CE970
00007eefba3cec10  int3
00007eefba3cec11  nop [rax+rax*1], ax
00007eefba3cec1a  nop [rax+rax*1], ax
00007eefba3cec20  mov rax, [r15]
00007eefba3cec23  lea r14, [rax+0x20]
00007eefba3cec27  mov r12, [r13+r14*1]
00007eefba3cec2c  mov r14, [r15+0x10]
00007eefba3cec30  lea r11, [r12+r14*1]
00007eefba3cec34  mov [r15+0x40], r11
00007eefba3cec38  lea r12, [rax+0x20]
00007eefba3cec3c  mov [r13+r12*1], r11
00007eefba3cec41  test r14, r14
00007eefba3cec44  setz r14b
00007eefba3cec48  movzx r14, r14b
00007eefba3cec4c  mov [rsp+0x414], r14b
00007eefba3cec54  cmp byte ptr [rsp+0x414], 0x00
00007eefba3cec5c  jz 0x00007EEFBA3CEC8E
00007eefba3cec5e  cmp dword ptr [r15+0x318], 0x00
00007eefba3cec66  mov eax, 0x4105B0
00007eefba3cec6b  mov [r15+0x100], rax
00007eefba3cec72  jz 0x00007EEFBA1FE0A0
00007eefba3cec78  nop [rax+rax*1], eax
00007eefba3cec7d  mov eax, 0x4105B0
00007eefba3cec82  mov [r15+0x100], rax
00007eefba3cec89  jmp 0x00007EEFBA1FE110
00007eefba3cec8e  cmp dword ptr [r15+0x318], 0x00
00007eefba3cec96  jz 0x00007EEFBA3CECE0
00007eefba3cec9c  nop [rax+rax*1], ax
00007eefba3ceca5  nop [rax+rax*1], eax
00007eefba3cecad  mov eax, 0x410348
00007eefba3cecb2  mov [r15+0x100], rax
00007eefba3cecb9  jmp 0x00007EEFBA1FE110
00007eefba3cecbe  int3
00007eefba3cecbf  call 0x00007EEFBA2E27E0
00007eefba3cecc4  jmp 0x00007EEFBA3CEC2C
00007eefba3cecc9  call 0x00007EEFBA2C0860
00007eefba3cecce  jmp 0x00007EEFBA3CEC41
00007eefba3cecd3  int3
00007eefba3cecd4  nop [rax+rax*1], ax
00007eefba3cecdd  nop [rax], eax
00007eefba3cece0  mov rax, [r15+0xF8]
00007eefba3cece7  lea r14, [rax-0x150]
00007eefba3cecee  mov [r15+0xF8], r14
00007eefba3cecf5  mov rax, [r15]
00007eefba3cecf8  lea r12, [rax+0x68]
00007eefba3cecfc  mov r11, [r13+r12*1]
00007eefba3ced01  mov [r15+0x88], r11
00007eefba3ced08  lea r12, [rax+0x28]
00007eefba3ced0c  mov [r15+0x40], r12
00007eefba3ced10  mov [r15+0x48], r14
00007eefba3ced14  mov qword ptr [r15+0x50], 0x420758
00007eefba3ced1c  lea rax, [r14+0x100]
00007eefba3ced23  mov r12, [r15+0xE8]
00007eefba3ced2a  mov r11, [r15+0xD8]
00007eefba3ced31  mov [r13+rax*1], r12
00007eefba3ced36  lea rax, [r14+0x108]
00007eefba3ced3d  mov [r13+rax*1], r11
00007eefba3ced42  lea rax, [r14+0x110]
00007eefba3ced49  mov r12, [r15+0xD0]
00007eefba3ced50  mov r11, [r15+0xC8]
00007eefba3ced57  mov [r13+rax*1], r12
00007eefba3ced5c  lea rax, [r14+0x118]
00007eefba3ced63  mov [r13+rax*1], r11
00007eefba3ced68  lea rax, [r14+0x120]
00007eefba3ced6f  mov r12, [r15+0xC0]
00007eefba3ced76  mov r11, [r15+0xB8]
00007eefba3ced7d  mov [r13+rax*1], r12
00007eefba3ced82  lea rax, [r14+0x128]
00007eefba3ced89  mov [r13+rax*1], r11
00007eefba3ced8e  lea rax, [r14+0x130]
00007eefba3ced95  mov r12, [r15+0xB0]
00007eefba3ced9c  mov r11, [r15+0xA8]
00007eefba3ceda3  mov [r13+rax*1], r12
00007eefba3ceda8  lea rax, [r14+0x138]
00007eefba3cedaf  mov [r13+rax*1], r11
00007eefba3cedb4  lea rax, [r14+0x140]
00007eefba3cedbb  mov r12, [r15+0xA0]
00007eefba3cedc2  mov r11, [r15+0x98]
00007eefba3cedc9  mov [r13+rax*1], r12
00007eefba3cedce  lea rax, [r14+0x148]
00007eefba3cedd5  mov [r13+rax*1], r11
00007eefba3cedda  cmp dword ptr [r15+0x318], 0x00
00007eefba3cede2  jz 0x00007EEFBA3CEE80
00007eefba3cede8  nop [rax+rax*1], ax
00007eefba3cedf1  nop [rax+rax*1], eax
00007eefba3cedf9  mov eax, 0x410380
00007eefba3cedfe  mov [r15+0x100], rax
00007eefba3cee05  jmp 0x00007EEFBA1FE110
00007eefba3cee0a  int3
00007eefba3cee0b  call 0x00007EEFBA2C0370
00007eefba3cee10  jmp 0x00007EEFBA3CED01
00007eefba3cee15  call 0x00007EEFBA20BC20
00007eefba3cee1a  jmp 0x00007EEFBA3CED36
00007eefba3cee1f  call 0x00007EEFBA20A9A0
00007eefba3cee24  jmp 0x00007EEFBA3CED42
00007eefba3cee29  call 0x00007EEFBA20BC20
00007eefba3cee2e  jmp 0x00007EEFBA3CED5C
00007eefba3cee33  call 0x00007EEFBA20A9A0
00007eefba3cee38  jmp 0x00007EEFBA3CED68
00007eefba3cee3d  call 0x00007EEFBA20BC20
00007eefba3cee42  jmp 0x00007EEFBA3CED82
00007eefba3cee47  call 0x00007EEFBA20A9A0
00007eefba3cee4c  jmp 0x00007EEFBA3CED8E
00007eefba3cee51  call 0x00007EEFBA20BC20
00007eefba3cee56  jmp 0x00007EEFBA3CEDA8
00007eefba3cee5b  call 0x00007EEFBA20A9A0
00007eefba3cee60  jmp 0x00007EEFBA3CEDB4
00007eefba3cee65  call 0x00007EEFBA20BC20
00007eefba3cee6a  jmp 0x00007EEFBA3CEDCE
00007eefba3cee6f  call 0x00007EEFBA20A9A0
00007eefba3cee74  jmp 0x00007EEFBA3CEDDA
00007eefba3cee79  int3
00007eefba3cee7a  nop [rax+rax*1], ax
00007eefba3cee80  mov rax, [r15+0x08]
00007eefba3cee84  movzx r14d, byte ptr [r13+rax*1]
00007eefba3cee8a  movzx r14d, r14b
00007eefba3cee8e  mov [rsp+0x10], r14d
00007eefba3cee93  mov r14d, r14d
00007eefba3cee96  mov [r15+0x58], r14
00007eefba3cee9a  lea r14, [rax+0x01]
00007eefba3cee9e  mov [r15+0x08], r14
00007eefba3ceea2  mov rax, [r15+0x88]
00007eefba3ceea9  lea r14, [rax+0x01]
00007eefba3ceead  mov r12, [r15]
00007eefba3ceeb0  lea r11, [r12+0x68]
00007eefba3ceeb5  mov [r13+r11*1], r14
00007eefba3ceeba  lea r14, [r12+rax*1]
00007eefba3ceebe  mov [r15+0x60], r14
00007eefba3ceec2  lea rax, [r14+0x28]
00007eefba3ceec6  mov r11d, [rsp+0x10]
00007eefba3ceecb  movzx r14d, r11b
00007eefba3ceecf  mov [r13+rax*1], r14b
00007eefba3ceed4  lea rax, [r12+0x68]
00007eefba3ceed9  mov r14, [r13+rax*1]
00007eefba3ceede  mov [r15+0x88], r14
00007eefba3ceee5  xor eax, eax
00007eefba3ceee7  mov r12d, 0x40
00007eefba3ceeed  cmp r14, r12
00007eefba3ceef0  cmc
00007eefba3ceef1  lahf
00007eefba3ceef2  seto al
00007eefba3ceef5  mov [r15+0x108], eax
00007eefba3ceefc  mov eax, [r15+0x108]
00007eefba3cef03  sahf
00007eefba3cef04  jnz 0x00007EEFBA3CEF36
00007eefba3cef06  cmp dword ptr [r15+0x318], 0x00
00007eefba3cef0e  jz 0x00007EEFBA3CF020
00007eefba3cef14  nop [rax+rax*1], ax
00007eefba3cef1d  nop [rax+rax*1], eax
00007eefba3cef25  mov eax, 0x4103A0
00007eefba3cef2a  mov [r15+0x100], rax
00007eefba3cef31  jmp 0x00007EEFBA1FE110
00007eefba3cef36  cmp dword ptr [r15+0x318], 0x00
00007eefba3cef3e  jz 0x00007EEFBA3CEF90
00007eefba3cef44  nop [rax+rax*1], ax
00007eefba3cef4d  nop [rax+rax*1], eax
00007eefba3cef55  mov eax, 0x410378
00007eefba3cef5a  mov [r15+0x100], rax
00007eefba3cef61  jmp 0x00007EEFBA1FE110
00007eefba3cef66  int3
00007eefba3cef67  call 0x00007EEFBA20D860
00007eefba3cef6c  jmp 0x00007EEFBA3CEE8A
00007eefba3cef71  call 0x00007EEFBA2B36E0
00007eefba3cef76  jmp 0x00007EEFBA3CEEBA
00007eefba3cef7b  call 0x00007EEFBA20DD60
00007eefba3cef80  jmp 0x00007EEFBA3CEED4
00007eefba3cef85  call 0x00007EEFBA20DC20
00007eefba3cef8a  jmp 0x00007EEFBA3CEEDE
00007eefba3cef8f  int3
00007eefba3cef90  mov rax, [r15+0x10]
00007eefba3cef94  lea r14, [rax-0x01]
00007eefba3cef98  mov [r15+0x10], r14
00007eefba3cef9c  test r14, r14
00007eefba3cef9f  setz r14b
00007eefba3cefa3  movzx r14, r14b
00007eefba3cefa7  mov [rsp+0x414], r14b
00007eefba3cefaf  cmp byte ptr [rsp+0x414], 0x00
00007eefba3cefb7  jz 0x00007EEFBA3CEFE9
00007eefba3cefb9  cmp dword ptr [r15+0x318], 0x00
00007eefba3cefc1  jz 0x00007EEFBA3D0520
00007eefba3cefc7  nop [rax+rax*1], ax
00007eefba3cefd0  nop [rax+rax*1], eax
00007eefba3cefd8  mov eax, 0x410598
00007eefba3cefdd  mov [r15+0x100], rax
00007eefba3cefe4  jmp 0x00007EEFBA1FE110
00007eefba3cefe9  cmp dword ptr [r15+0x318], 0x00
00007eefba3ceff1  jz 0x00007EEFBA3CEE80
00007eefba3ceff7  nop [rax+rax*1], ax
00007eefba3cf000  nop [rax+rax*1], eax
00007eefba3cf008  mov eax, 0x410380
00007eefba3cf00d  mov [r15+0x100], rax
00007eefba3cf014  jmp 0x00007EEFBA1FE110
00007eefba3cf019  int3
00007eefba3cf01a  int3
00007eefba3cf01b  nop [rax+rax*1], eax
00007eefba3cf020  mov rax, [r15+0x40]
00007eefba3cf024  movzx r14d, byte ptr [r13+rax*1]
00007eefba3cf02a  movaps xmm1, [r15+0x110]
00007eefba3cf032  pinsrb xmm1, r14d, 0x00
00007eefba3cf039  lea r14, [rax+0x01]
00007eefba3cf03d  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf043  movaps xmm15, [r15+0x120]
00007eefba3cf04b  pinsrb xmm15, r12d, 0x00
00007eefba3cf052  lea r14, [rax+0x02]
00007eefba3cf056  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf05c  movaps xmm14, [r15+0x130]
00007eefba3cf064  pinsrb xmm14, r12d, 0x00
00007eefba3cf06b  lea r14, [rax+0x03]
00007eefba3cf06f  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf075  movaps xmm13, [r15+0x140]
00007eefba3cf07d  pinsrb xmm13, r12d, 0x00
00007eefba3cf084  lea r14, [rax+0x04]
00007eefba3cf088  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf08e  pinsrb xmm1, r12d, 0x01
00007eefba3cf095  lea r14, [rax+0x05]
00007eefba3cf099  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf09f  pinsrb xmm15, r12d, 0x01
00007eefba3cf0a6  lea r14, [rax+0x06]
00007eefba3cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf0b0  pinsrb xmm14, r12d, 0x01
00007eefba3cf0b7  lea r14, [rax+0x07]
00007eefba3cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf0c1  pinsrb xmm13, r12d, 0x01
00007eefba3cf0c8  lea r14, [rax+0x08]
00007eefba3cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf0d2  pinsrb xmm1, r12d, 0x02
00007eefba3cf0d9  lea r14, [rax+0x09]
00007eefba3cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf0e3  pinsrb xmm15, r12d, 0x02
00007eefba3cf0ea  lea r14, [rax+0x0A]
00007eefba3cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf0f4  pinsrb xmm14, r12d, 0x02
00007eefba3cf0fb  lea r14, [rax+0x0B]
00007eefba3cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf105  pinsrb xmm13, r12d, 0x02
00007eefba3cf10c  lea r14, [rax+0x0C]
00007eefba3cf110  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf116  pinsrb xmm1, r12d, 0x03
00007eefba3cf11d  lea r14, [rax+0x0D]
00007eefba3cf121  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf127  pinsrb xmm15, r12d, 0x03
00007eefba3cf12e  lea r14, [rax+0x0E]
00007eefba3cf132  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf138  pinsrb xmm14, r12d, 0x03
00007eefba3cf13f  lea r14, [rax+0x0F]
00007eefba3cf143  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf149  pinsrb xmm13, r12d, 0x03
00007eefba3cf150  lea r14, [rax+0x10]
00007eefba3cf154  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf15a  pinsrb xmm1, r12d, 0x04
00007eefba3cf161  lea r14, [rax+0x11]
00007eefba3cf165  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf16b  pinsrb xmm15, r12d, 0x04
00007eefba3cf172  lea r14, [rax+0x12]
00007eefba3cf176  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf17c  pinsrb xmm14, r12d, 0x04
00007eefba3cf183  lea r14, [rax+0x13]
00007eefba3cf187  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf18d  pinsrb xmm13, r12d, 0x04
00007eefba3cf194  lea r14, [rax+0x14]
00007eefba3cf198  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf19e  pinsrb xmm1, r12d, 0x05
00007eefba3cf1a5  lea r14, [rax+0x15]
00007eefba3cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf1af  pinsrb xmm15, r12d, 0x05
00007eefba3cf1b6  lea r14, [rax+0x16]
00007eefba3cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf1c0  pinsrb xmm14, r12d, 0x05
00007eefba3cf1c7  lea r14, [rax+0x17]
00007eefba3cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf1d1  pinsrb xmm13, r12d, 0x05
00007eefba3cf1d8  lea r14, [rax+0x18]
00007eefba3cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf1e2  pinsrb xmm1, r12d, 0x06
00007eefba3cf1e9  lea r14, [rax+0x19]
00007eefba3cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf1f3  pinsrb xmm15, r12d, 0x06
00007eefba3cf1fa  lea r14, [rax+0x1A]
00007eefba3cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf204  pinsrb xmm14, r12d, 0x06
00007eefba3cf20b  lea r14, [rax+0x1B]
00007eefba3cf20f  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf215  pinsrb xmm13, r12d, 0x06
00007eefba3cf21c  lea r14, [rax+0x1C]
00007eefba3cf220  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf226  pinsrb xmm1, r12d, 0x07
00007eefba3cf22d  lea r14, [rax+0x1D]
00007eefba3cf231  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf237  pinsrb xmm15, r12d, 0x07
00007eefba3cf23e  lea r14, [rax+0x1E]
00007eefba3cf242  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf248  pinsrb xmm14, r12d, 0x07
00007eefba3cf24f  lea r14, [rax+0x1F]
00007eefba3cf253  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf259  pinsrb xmm13, r12d, 0x07
00007eefba3cf260  lea r14, [rax+0x20]
00007eefba3cf264  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf26a  pinsrb xmm1, r12d, 0x08
00007eefba3cf271  lea r14, [rax+0x21]
00007eefba3cf275  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf27b  pinsrb xmm15, r12d, 0x08
00007eefba3cf282  lea r14, [rax+0x22]
00007eefba3cf286  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf28c  pinsrb xmm14, r12d, 0x08
00007eefba3cf293  lea r14, [rax+0x23]
00007eefba3cf297  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf29d  pinsrb xmm13, r12d, 0x08
00007eefba3cf2a4  lea r14, [rax+0x24]
00007eefba3cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf2ae  pinsrb xmm1, r12d, 0x09
00007eefba3cf2b5  lea r14, [rax+0x25]
00007eefba3cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf2bf  pinsrb xmm15, r12d, 0x09
00007eefba3cf2c6  lea r14, [rax+0x26]
00007eefba3cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf2d0  pinsrb xmm14, r12d, 0x09
00007eefba3cf2d7  lea r14, [rax+0x27]
00007eefba3cf2db  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf2e1  pinsrb xmm13, r12d, 0x09
00007eefba3cf2e8  lea r14, [rax+0x28]
00007eefba3cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf2f2  pinsrb xmm1, r12d, 0x0A
00007eefba3cf2f9  lea r14, [rax+0x29]
00007eefba3cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf303  pinsrb xmm15, r12d, 0x0A
00007eefba3cf30a  lea r14, [rax+0x2A]
00007eefba3cf30e  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf314  pinsrb xmm14, r12d, 0x0A
00007eefba3cf31b  lea r14, [rax+0x2B]
00007eefba3cf31f  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf325  pinsrb xmm13, r12d, 0x0A
00007eefba3cf32c  lea r14, [rax+0x2C]
00007eefba3cf330  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf336  pinsrb xmm1, r12d, 0x0B
00007eefba3cf33d  lea r14, [rax+0x2D]
00007eefba3cf341  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf347  pinsrb xmm15, r12d, 0x0B
00007eefba3cf34e  lea r14, [rax+0x2E]
00007eefba3cf352  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf358  pinsrb xmm14, r12d, 0x0B
00007eefba3cf35f  lea r14, [rax+0x2F]
00007eefba3cf363  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf369  pinsrb xmm13, r12d, 0x0B
00007eefba3cf370  lea r14, [rax+0x30]
00007eefba3cf374  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf37a  pinsrb xmm1, r12d, 0x0C
00007eefba3cf381  lea r14, [rax+0x31]
00007eefba3cf385  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf38b  pinsrb xmm15, r12d, 0x0C
00007eefba3cf392  lea r14, [rax+0x32]
00007eefba3cf396  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf39c  pinsrb xmm14, r12d, 0x0C
00007eefba3cf3a3  lea r14, [rax+0x33]
00007eefba3cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf3ad  pinsrb xmm13, r12d, 0x0C
00007eefba3cf3b4  lea r14, [rax+0x34]
00007eefba3cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf3be  pinsrb xmm1, r12d, 0x0D
00007eefba3cf3c5  lea r14, [rax+0x35]
00007eefba3cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf3cf  pinsrb xmm15, r12d, 0x0D
00007eefba3cf3d6  lea r14, [rax+0x36]
00007eefba3cf3da  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf3e0  pinsrb xmm14, r12d, 0x0D
00007eefba3cf3e7  lea r14, [rax+0x37]
00007eefba3cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf3f1  pinsrb xmm13, r12d, 0x0D
00007eefba3cf3f8  lea r14, [rax+0x38]
00007eefba3cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf402  pinsrb xmm1, r12d, 0x0E
00007eefba3cf409  lea r14, [rax+0x39]
00007eefba3cf40d  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf413  pinsrb xmm15, r12d, 0x0E
00007eefba3cf41a  lea r14, [rax+0x3A]
00007eefba3cf41e  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf424  pinsrb xmm14, r12d, 0x0E
00007eefba3cf42b  lea r14, [rax+0x3B]
00007eefba3cf42f  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf435  pinsrb xmm13, r12d, 0x0E
00007eefba3cf43c  lea r14, [rax+0x3C]
00007eefba3cf440  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf446  pinsrb xmm1, r12d, 0x0F
00007eefba3cf44d  movaps [r15+0x110], xmm1
00007eefba3cf455  lea r14, [rax+0x3D]
00007eefba3cf459  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf45f  pinsrb xmm15, r12d, 0x0F
00007eefba3cf466  movaps [r15+0x120], xmm15
00007eefba3cf46e  lea r14, [rax+0x3E]
00007eefba3cf472  movzx r12d, byte ptr [r13+r14*1]
00007eefba3cf478  pinsrb xmm14, r12d, 0x0F
00007eefba3cf47f  movaps [r15+0x130], xmm14
00007eefba3cf487  lea r14, [rax+0x3F]
00007eefba3cf48b  movzx eax, byte ptr [r13+r14*1]
00007eefba3cf491  pinsrb xmm13, eax, 0x0F
00007eefba3cf498  movaps [r15+0x140], xmm13
00007eefba3cf4a0  movq xmm1, qword ptr [r15+0x120]
00007eefba3cf4a9  pmovzxbw xmm1, xmm1
00007eefba3cf4ae  psllw xmm1, 0x00
00007eefba3cf4b3  movaps [r15+0x150], xmm1
00007eefba3cf4bb  movq xmm1, qword ptr [r15+0x130]
00007eefba3cf4c4  pmovzxbw xmm1, xmm1
00007eefba3cf4c9  psllw xmm1, 0x00
00007eefba3cf4ce  movaps [r15+0x160], xmm1
00007eefba3cf4d6  movq xmm1, qword ptr [r15+0x110]
00007eefba3cf4df  pmovzxbw xmm1, xmm1
00007eefba3cf4e4  psllw xmm1, 0x00
00007eefba3cf4e9  movaps [r15+0x170], xmm1
00007eefba3cf4f1  movaps xmm15, [r15+0x110]
00007eefba3cf4f9  pextrq rax, xmm15, 0x01
00007eefba3cf500  movq xmm15, rax
00007eefba3cf505  pmovzxbw xmm15, xmm15
00007eefba3cf50b  psllw xmm15, 0x00
00007eefba3cf511  movaps [r15+0x180], xmm15
00007eefba3cf519  movaps xmm14, [r15+0x120]
00007eefba3cf521  pextrq rax, xmm14, 0x01
00007eefba3cf528  movq xmm14, rax
00007eefba3cf52d  pmovzxbw xmm14, xmm14
00007eefba3cf533  psllw xmm14, 0x00
00007eefba3cf539  movaps [r15+0x210], xmm14
00007eefba3cf541  movaps xmm13, [r15+0x130]
00007eefba3cf549  pextrq rax, xmm13, 0x01
00007eefba3cf550  movq xmm13, rax
00007eefba3cf555  pmovzxbw xmm13, xmm13
00007eefba3cf55b  psllw xmm13, 0x00
00007eefba3cf561  movaps [r15+0x220], xmm13
00007eefba3cf569  movq xmm12, qword ptr [r15+0x140]
00007eefba3cf572  pmovzxbw xmm12, xmm12
00007eefba3cf578  psllw xmm12, 0x00
00007eefba3cf57e  movaps [r15+0x250], xmm12
00007eefba3cf586  movaps xmm12, [r15+0x140]
00007eefba3cf58e  pextrq rax, xmm12, 0x01
00007eefba3cf595  movq xmm12, rax
00007eefba3cf59a  pmovzxbw xmm12, xmm12
00007eefba3cf5a0  psllw xmm12, 0x00
00007eefba3cf5a6  movaps [r15+0x110], xmm12
00007eefba3cf5ae  movq xmm11, qword ptr [r15+0x150]
00007eefba3cf5b7  pmovzxwd xmm11, xmm11
00007eefba3cf5bd  pslld xmm11, 0x10
00007eefba3cf5c3  movq xmm10, qword ptr [r15+0x160]
00007eefba3cf5cc  pmovzxwd xmm10, xmm10
00007eefba3cf5d2  pslld xmm10, 0x08
00007eefba3cf5d8  pextrq rax, xmm1, 0x01
00007eefba3cf5df  movq xmm1, rax
00007eefba3cf5e4  pmovzxwd xmm1, xmm1
00007eefba3cf5e9  pslld xmm1, 0x00
00007eefba3cf5ee  movaps [r15+0x260], xmm1
00007eefba3cf5f6  pextrq rax, xmm15, 0x01
00007eefba3cf5fd  movq xmm15, rax
00007eefba3cf602  pmovzxwd xmm15, xmm15
00007eefba3cf608  pslld xmm15, 0x00
00007eefba3cf60e  movaps [r15+0x270], xmm15
00007eefba3cf616  movq xmm9, qword ptr [r15+0x170]
00007eefba3cf61f  pmovzxwd xmm9, xmm9
00007eefba3cf625  pslld xmm9, 0x00
00007eefba3cf62b  pextrq rax, xmm14, 0x01
00007eefba3cf632  movq xmm14, rax
00007eefba3cf637  pmovzxwd xmm14, xmm14
00007eefba3cf63d  pslld xmm14, 0x10
00007eefba3cf643  movaps [r15+0x280], xmm14
00007eefba3cf64b  movq xmm8, qword ptr [r15+0x180]
00007eefba3cf654  pmovzxwd xmm8, xmm8
00007eefba3cf65a  pslld xmm8, 0x00
00007eefba3cf660  movq xmm7, qword ptr [r15+0x210]
00007eefba3cf669  pmovzxwd xmm7, xmm7
00007eefba3cf66e  pslld xmm7, 0x10
00007eefba3cf673  movaps xmm6, [r15+0x150]
00007eefba3cf67b  pextrq rax, xmm6, 0x01
00007eefba3cf682  movq xmm6, rax
00007eefba3cf687  pmovzxwd xmm6, xmm6
00007eefba3cf68c  pslld xmm6, 0x10
00007eefba3cf691  por xmm11, xmm10
00007eefba3cf696  movaps [r15+0x230], xmm11
00007eefba3cf69e  pextrq rax, xmm13, 0x01
00007eefba3cf6a5  movq xmm13, rax
00007eefba3cf6aa  pmovzxwd xmm13, xmm13
00007eefba3cf6b0  pslld xmm13, 0x08
00007eefba3cf6b6  movaps [r15+0x240], xmm13
00007eefba3cf6be  movq xmm10, qword ptr [r15+0x220]
00007eefba3cf6c7  pmovzxwd xmm10, xmm10
00007eefba3cf6cd  pslld xmm10, 0x08
00007eefba3cf6d3  movaps xmm5, [r15+0x160]
00007eefba3cf6db  pextrq rax, xmm5, 0x01
00007eefba3cf6e2  movq xmm5, rax
00007eefba3cf6e7  pmovzxwd xmm5, xmm5
00007eefba3cf6ec  pslld xmm5, 0x08
00007eefba3cf6f1  pslld xmm9, 0x18
00007eefba3cf6f7  pslld xmm15, 0x18
00007eefba3cf6fd  pslld xmm8, 0x18
00007eefba3cf703  movq xmm4, qword ptr [r15+0x250]
00007eefba3cf70c  pmovzxwd xmm4, xmm4
00007eefba3cf711  pslld xmm4, 0x00
00007eefba3cf716  por xmm14, xmm13
00007eefba3cf71b  por xmm7, xmm10
00007eefba3cf720  movaps [r15+0x210], xmm7
00007eefba3cf728  pslld xmm1, 0x18
00007eefba3cf72d  movaps [r15+0x220], xmm1
00007eefba3cf735  por xmm6, xmm5
00007eefba3cf739  por xmm11, xmm9
00007eefba3cf73e  movaps [r15+0x160], xmm11
00007eefba3cf746  pextrq rax, xmm12, 0x01
00007eefba3cf74d  movq xmm13, rax
00007eefba3cf752  pmovzxwd xmm13, xmm13
00007eefba3cf758  pslld xmm13, 0x00
00007eefba3cf75e  movaps [r15+0x170], xmm13
00007eefba3cf766  movq xmm12, qword ptr [r15+0x110]
00007eefba3cf76f  pmovzxwd xmm12, xmm12
00007eefba3cf775  pslld xmm12, 0x00
00007eefba3cf77b  por xmm14, xmm15
00007eefba3cf780  por xmm7, xmm8
00007eefba3cf785  movaps xmm15, [r15+0x250]
00007eefba3cf78d  pextrq rax, xmm15, 0x01
00007eefba3cf794  movq xmm15, rax
00007eefba3cf799  pmovzxwd xmm15, xmm15
00007eefba3cf79f  pslld xmm15, 0x00
00007eefba3cf7a5  movaps [r15+0x180], xmm15
00007eefba3cf7ad  por xmm6, xmm1
00007eefba3cf7b1  movaps [r15+0x150], xmm6
00007eefba3cf7b9  por xmm11, xmm4
00007eefba3cf7be  movaps [r15+0x140], xmm11
00007eefba3cf7c6  por xmm7, xmm12
00007eefba3cf7cb  movaps [r15+0x110], xmm7
00007eefba3cf7d3  por xmm14, xmm13
00007eefba3cf7d8  movaps [r15+0x120], xmm14
00007eefba3cf7e0  por xmm6, xmm15
00007eefba3cf7e5  movaps [r15+0x130], xmm6
00007eefba3cf7ed  mov rax, [r15+0xF8]
00007eefba3cf7f4  lea r14, [rax+0x20]
00007eefba3cf7f8  movups [r13+r14*1], xmm7
00007eefba3cf7fe  lea r14, [rax+0x30]
00007eefba3cf802  movups [r13+r14*1], xmm14
00007eefba3cf808  movups [r13+rax*1], xmm11
00007eefba3cf80e  lea r14, [rax+0x10]
00007eefba3cf812  movups [r13+r14*1], xmm6
00007eefba3cf818  mov r14d, [r13+rax*1]
00007eefba3cf81d  mov rax, [r15+0x48]
00007eefba3cf821  mov [r15+0x68], rax
00007eefba3cf825  mov qword ptr [r15+0x58], 0x04
00007eefba3cf82d  lea r12, [rax+0x04]
00007eefba3cf831  mov r11d, [r13+r12*1]
00007eefba3cf836  mov [rsp+0x10], r11d
00007eefba3cf83b  mov r11d, r11d
00007eefba3cf83e  mov [r15+0x70], r11
00007eefba3cf842  lea r12, [rax+0x38]
00007eefba3cf846  mov r11d, [r13+r12*1]
00007eefba3cf84b  lea r12, [rax+0x24]
00007eefba3cf84f  mov r10d, [r13+r12*1]
00007eefba3cf854  mov [rsp+0x20], r10d
00007eefba3cf859  mov r10d, r10d
00007eefba3cf85c  mov [r15+0x90], r10
00007eefba3cf863  mov [rsp+0x30], rax
00007eefba3cf868  xor eax, eax
00007eefba3cf86a  mov r12d, 0x04
00007eefba3cf870  mov r10d, 0xC0
00007eefba3cf876  cmp r12, r10
00007eefba3cf879  cmc
00007eefba3cf87a  lahf
00007eefba3cf87b  seto al
00007eefba3cf87e  mov [r15+0x108], eax
00007eefba3cf885  mov eax, [rsp+0x10]
00007eefba3cf889  mov r12d, [rsp+0x10]
00007eefba3cf88e  shrd eax, r12d, 0x07
00007eefba3cf893  mov [rsp+0x10], r11d
00007eefba3cf898  mov r10d, [rsp+0x10]
00007eefba3cf89d  shrd r11d, r10d, 0x11
00007eefba3cf8a2  mov r9d, [rsp+0x20]
00007eefba3cf8a7  lea r8d, [r9d+r14d*1]
00007eefba3cf8ac  rorx r14d, r12d, 0x12
00007eefba3cf8b2  xor eax, r14d
00007eefba3cf8b5  rorx r14d, r10d, 0x13
00007eefba3cf8bb  xor r11d, r14d
00007eefba3cf8be  mov [rsp+0x10], r11d
00007eefba3cf8c3  mov r11d, r11d
00007eefba3cf8c6  mov [r15+0x88], r11
00007eefba3cf8cd  mov [rsp+0x20], r12d
00007eefba3cf8d2  shr r12d, 0x03
00007eefba3cf8d6  xor eax, r12d
00007eefba3cf8d9  mov [rsp+0x40], eax
00007eefba3cf8dd  mov eax, eax
00007eefba3cf8df  mov [r15+0x80], rax
00007eefba3cf8e6  shr r10d, 0x0A
00007eefba3cf8ea  mov eax, [rsp+0x10]
00007eefba3cf8ee  xor eax, r10d
00007eefba3cf8f1  mov [rsp+0x10], eax
00007eefba3cf8f5  mov eax, eax
00007eefba3cf8f7  mov [r15+0x78], rax
00007eefba3cf8fb  mov eax, [rsp+0x40]
00007eefba3cf8ff  lea r14d, [r8d+eax*1]
00007eefba3cf904  mov eax, [rsp+0x10]
00007eefba3cf908  lea r12d, [r14d+eax*1]
00007eefba3cf90d  mov rax, [rsp+0x30]
00007eefba3cf912  lea r14, [rax+0x40]
00007eefba3cf916  mov [r13+r14*1], r12d
00007eefba3cf91b  mov eax, [rsp+0x20]
00007eefba3cf91f  mov eax, eax
00007eefba3cf921  mov [r15+0x60], rax
00007eefba3cf925  mov eax, [r15+0x108]
00007eefba3cf92c  sahf
00007eefba3cf92d  jnz 0x00007EEFBA3CF95F
00007eefba3cf92f  cmp dword ptr [r15+0x318], 0x00
00007eefba3cf937  jz 0x00007EEFBA3CFE20
00007eefba3cf93d  nop [rax+rax*1], ax
00007eefba3cf946  nop [rax+rax*1], eax
00007eefba3cf94e  mov eax, 0x41049C
00007eefba3cf953  mov [r15+0x100], rax
00007eefba3cf95a  jmp 0x00007EEFBA1FE110
00007eefba3cf95f  cmp dword ptr [r15+0x318], 0x00
00007eefba3cf967  jz 0x00007EEFBA3CFC70
00007eefba3cf96d  nop [rax+rax*1], ax
00007eefba3cf976  nop [rax+rax*1], eax
00007eefba3cf97e  mov eax, 0x410454
00007eefba3cf983  mov [r15+0x100], rax
00007eefba3cf98a  jmp 0x00007EEFBA1FE110
00007eefba3cf98f  int3
00007eefba3cf990  call 0x00007EEFBA20D860
00007eefba3cf995  jmp 0x00007EEFBA3CF02A
00007eefba3cf99a  call 0x00007EEFBA2E2420
00007eefba3cf99f  jmp 0x00007EEFBA3CF043
00007eefba3cf9a4  call 0x00007EEFBA2E2420
00007eefba3cf9a9  jmp 0x00007EEFBA3CF05C
00007eefba3cf9ae  call 0x00007EEFBA2E2420
00007eefba3cf9b3  jmp 0x00007EEFBA3CF075
00007eefba3cf9b8  call 0x00007EEFBA2E2420
00007eefba3cf9bd  jmp 0x00007EEFBA3CF08E
00007eefba3cf9c2  call 0x00007EEFBA2E2420
00007eefba3cf9c7  jmp 0x00007EEFBA3CF09F
00007eefba3cf9cc  call 0x00007EEFBA2E2420
00007eefba3cf9d1  jmp 0x00007EEFBA3CF0B0
00007eefba3cf9d6  call 0x00007EEFBA2E2420
00007eefba3cf9db  jmp 0x00007EEFBA3CF0C1
00007eefba3cf9e0  call 0x00007EEFBA2E2420
00007eefba3cf9e5  jmp 0x00007EEFBA3CF0D2
00007eefba3cf9ea  call 0x00007EEFBA2E2420
00007eefba3cf9ef  jmp 0x00007EEFBA3CF0E3
00007eefba3cf9f4  call 0x00007EEFBA2E2420
00007eefba3cf9f9  jmp 0x00007EEFBA3CF0F4
00007eefba3cf9fe  call 0x00007EEFBA2E2420
00007eefba3cfa03  jmp 0x00007EEFBA3CF105
00007eefba3cfa08  call 0x00007EEFBA2E2420
00007eefba3cfa0d  jmp 0x00007EEFBA3CF116
00007eefba3cfa12  call 0x00007EEFBA2E2420
00007eefba3cfa17  jmp 0x00007EEFBA3CF127
00007eefba3cfa1c  call 0x00007EEFBA2E2420
00007eefba3cfa21  jmp 0x00007EEFBA3CF138
00007eefba3cfa26  call 0x00007EEFBA2E2420
00007eefba3cfa2b  jmp 0x00007EEFBA3CF149
00007eefba3cfa30  call 0x00007EEFBA2E2420
00007eefba3cfa35  jmp 0x00007EEFBA3CF15A
00007eefba3cfa3a  call 0x00007EEFBA2E2420
00007eefba3cfa3f  jmp 0x00007EEFBA3CF16B
00007eefba3cfa44  call 0x00007EEFBA2E2420
00007eefba3cfa49  jmp 0x00007EEFBA3CF17C
00007eefba3cfa4e  call 0x00007EEFBA2E2420
00007eefba3cfa53  jmp 0x00007EEFBA3CF18D
00007eefba3cfa58  call 0x00007EEFBA2E2420
00007eefba3cfa5d  jmp 0x00007EEFBA3CF19E
00007eefba3cfa62  call 0x00007EEFBA2E2420
00007eefba3cfa67  jmp 0x00007EEFBA3CF1AF
00007eefba3cfa6c  call 0x00007EEFBA2E2420
00007eefba3cfa71  jmp 0x00007EEFBA3CF1C0
00007eefba3cfa76  call 0x00007EEFBA2E2420
00007eefba3cfa7b  jmp 0x00007EEFBA3CF1D1
00007eefba3cfa80  call 0x00007EEFBA2E2420
00007eefba3cfa85  jmp 0x00007EEFBA3CF1E2
00007eefba3cfa8a  call 0x00007EEFBA2E2420
00007eefba3cfa8f  jmp 0x00007EEFBA3CF1F3
00007eefba3cfa94  call 0x00007EEFBA2E2420
00007eefba3cfa99  jmp 0x00007EEFBA3CF204
00007eefba3cfa9e  call 0x00007EEFBA2E2420
00007eefba3cfaa3  jmp 0x00007EEFBA3CF215
00007eefba3cfaa8  call 0x00007EEFBA2E2420
00007eefba3cfaad  jmp 0x00007EEFBA3CF226
00007eefba3cfab2  call 0x00007EEFBA2E2420
00007eefba3cfab7  jmp 0x00007EEFBA3CF237
00007eefba3cfabc  call 0x00007EEFBA2E2420
00007eefba3cfac1  jmp 0x00007EEFBA3CF248
00007eefba3cfac6  call 0x00007EEFBA2E2420
00007eefba3cfacb  jmp 0x00007EEFBA3CF259
00007eefba3cfad0  call 0x00007EEFBA2E2420
00007eefba3cfad5  jmp 0x00007EEFBA3CF26A
00007eefba3cfada  call 0x00007EEFBA2E2420
00007eefba3cfadf  jmp 0x00007EEFBA3CF27B
00007eefba3cfae4  call 0x00007EEFBA2E2420
00007eefba3cfae9  jmp 0x00007EEFBA3CF28C
00007eefba3cfaee  call 0x00007EEFBA2E2420
00007eefba3cfaf3  jmp 0x00007EEFBA3CF29D
00007eefba3cfaf8  call 0x00007EEFBA2E2420
00007eefba3cfafd  jmp 0x00007EEFBA3CF2AE
00007eefba3cfb02  call 0x00007EEFBA2E2420
00007eefba3cfb07  jmp 0x00007EEFBA3CF2BF
00007eefba3cfb0c  call 0x00007EEFBA2E2420
00007eefba3cfb11  jmp 0x00007EEFBA3CF2D0
00007eefba3cfb16  call 0x00007EEFBA2E2420
00007eefba3cfb1b  jmp 0x00007EEFBA3CF2E1
00007eefba3cfb20  call 0x00007EEFBA2E2420
00007eefba3cfb25  jmp 0x00007EEFBA3CF2F2
00007eefba3cfb2a  call 0x00007EEFBA2E2420
00007eefba3cfb2f  jmp 0x00007EEFBA3CF303
00007eefba3cfb34  call 0x00007EEFBA2E2420
00007eefba3cfb39  jmp 0x00007EEFBA3CF314
00007eefba3cfb3e  call 0x00007EEFBA2E2420
00007eefba3cfb43  jmp 0x00007EEFBA3CF325
00007eefba3cfb48  call 0x00007EEFBA2E2420
00007eefba3cfb4d  jmp 0x00007EEFBA3CF336
00007eefba3cfb52  call 0x00007EEFBA2E2420
00007eefba3cfb57  jmp 0x00007EEFBA3CF347
00007eefba3cfb5c  call 0x00007EEFBA2E2420
00007eefba3cfb61  jmp 0x00007EEFBA3CF358
00007eefba3cfb66  call 0x00007EEFBA2E2420
00007eefba3cfb6b  jmp 0x00007EEFBA3CF369
00007eefba3cfb70  call 0x00007EEFBA2E2420
00007eefba3cfb75  jmp 0x00007EEFBA3CF37A
00007eefba3cfb7a  call 0x00007EEFBA2E2420
00007eefba3cfb7f  jmp 0x00007EEFBA3CF38B
00007eefba3cfb84  call 0x00007EEFBA2E2420
00007eefba3cfb89  jmp 0x00007EEFBA3CF39C
00007eefba3cfb8e  call 0x00007EEFBA2E2420
00007eefba3cfb93  jmp 0x00007EEFBA3CF3AD
00007eefba3cfb98  call 0x00007EEFBA2E2420
00007eefba3cfb9d  jmp 0x00007EEFBA3CF3BE
00007eefba3cfba2  call 0x00007EEFBA2E2420
00007eefba3cfba7  jmp 0x00007EEFBA3CF3CF
00007eefba3cfbac  call 0x00007EEFBA2E2420
00007eefba3cfbb1  jmp 0x00007EEFBA3CF3E0
00007eefba3cfbb6  call 0x00007EEFBA2E2420
00007eefba3cfbbb  jmp 0x00007EEFBA3CF3F1
00007eefba3cfbc0  call 0x00007EEFBA2E2420
00007eefba3cfbc5  jmp 0x00007EEFBA3CF402
00007eefba3cfbca  call 0x00007EEFBA2E2420
00007eefba3cfbcf  jmp 0x00007EEFBA3CF413
00007eefba3cfbd4  call 0x00007EEFBA2E2420
00007eefba3cfbd9  jmp 0x00007EEFBA3CF424
00007eefba3cfbde  call 0x00007EEFBA2E2420
00007eefba3cfbe3  jmp 0x00007EEFBA3CF435
00007eefba3cfbe8  call 0x00007EEFBA2E2420
00007eefba3cfbed  jmp 0x00007EEFBA3CF446
00007eefba3cfbf2  call 0x00007EEFBA2E2420
00007eefba3cfbf7  jmp 0x00007EEFBA3CF45F
00007eefba3cfbfc  call 0x00007EEFBA2E2420
00007eefba3cfc01  jmp 0x00007EEFBA3CF478
00007eefba3cfc06  call 0x00007EEFBA2D5610
00007eefba3cfc0b  jmp 0x00007EEFBA3CF491
00007eefba3cfc10  call 0x00007EEFBA2DC580
00007eefba3cfc15  jmp 0x00007EEFBA3CF7FE
00007eefba3cfc1a  call 0x00007EEFBA2E46C0
00007eefba3cfc1f  jmp 0x00007EEFBA3CF808
00007eefba3cfc24  call 0x00007EEFBA209E90
00007eefba3cfc29  jmp 0x00007EEFBA3CF80E
00007eefba3cfc2e  call 0x00007EEFBA2DB310
00007eefba3cfc33  jmp 0x00007EEFBA3CF818
00007eefba3cfc38  call 0x00007EEFBA20DAE0
00007eefba3cfc3d  jmp 0x00007EEFBA3CF81D
00007eefba3cfc42  call 0x00007EEFBA2C0230
00007eefba3cfc47  jmp 0x00007EEFBA3CF836
00007eefba3cfc4c  call 0x00007EEFBA2C0230
00007eefba3cfc51  jmp 0x00007EEFBA3CF84B
00007eefba3cfc56  call 0x00007EEFBA2BEFC0
00007eefba3cfc5b  jmp 0x00007EEFBA3CF854
00007eefba3cfc60  call 0x00007EEFBA2E2BA0
00007eefba3cfc65  jmp 0x00007EEFBA3CF91B
00007eefba3cfc6a  int3
00007eefba3cfc6b  nop [rax+rax*1], eax
00007eefba3cfc70  mov rax, [r15+0x48]
00007eefba3cfc74  mov r14, [r15+0x58]
00007eefba3cfc78  lea r12, [rax+r14*1]
00007eefba3cfc7c  mov [r15+0x68], r12
00007eefba3cfc80  lea rax, [r14+0x04]
00007eefba3cfc84  mov [r15+0x58], rax
00007eefba3cfc88  lea r14, [r12+0x04]
00007eefba3cfc8d  mov r11d, [r13+r14*1]
00007eefba3cfc92  mov [rsp+0x10], r11d
00007eefba3cfc97  mov r11d, r11d
00007eefba3cfc9a  mov [r15+0x70], r11
00007eefba3cfc9e  lea r14, [r12+0x38]
00007eefba3cfca3  mov r11d, [r13+r14*1]
00007eefba3cfca8  lea r14, [r12+0x24]
00007eefba3cfcad  mov r10d, [r13+r14*1]
00007eefba3cfcb2  mov [rsp+0x20], r10d
00007eefba3cfcb7  mov r10d, r10d
00007eefba3cfcba  mov [r15+0x90], r10
00007eefba3cfcc1  mov [rsp+0x30], rax
00007eefba3cfcc6  xor eax, eax
00007eefba3cfcc8  mov r14, [rsp+0x30]
00007eefba3cfccd  mov r10d, 0xC0
00007eefba3cfcd3  cmp r14, r10
00007eefba3cfcd6  cmc
00007eefba3cfcd7  lahf
00007eefba3cfcd8  seto al
00007eefba3cfcdb  mov [r15+0x108], eax
00007eefba3cfce2  mov eax, [rsp+0x10]
00007eefba3cfce6  mov r14d, [rsp+0x10]
00007eefba3cfceb  shrd eax, r14d, 0x07
00007eefba3cfcf0  mov [rsp+0x10], r11d
00007eefba3cfcf5  mov r10d, [rsp+0x10]
00007eefba3cfcfa  shrd r11d, r10d, 0x11
00007eefba3cfcff  mov r9d, [r15+0x60]
00007eefba3cfd03  mov r8d, [rsp+0x20]
00007eefba3cfd08  lea ebp, [r8d+r9d*1]
00007eefba3cfd0d  rorx r9d, r14d, 0x12
00007eefba3cfd13  xor eax, r9d
00007eefba3cfd16  rorx r9d, r10d, 0x13
00007eefba3cfd1c  xor r11d, r9d
00007eefba3cfd1f  mov [rsp+0x10], r11d
00007eefba3cfd24  mov r11d, r11d
00007eefba3cfd27  mov [r15+0x88], r11
00007eefba3cfd2e  mov [rsp+0x20], r14d
00007eefba3cfd33  shr r14d, 0x03
00007eefba3cfd37  xor eax, r14d
00007eefba3cfd3a  mov [rsp+0x30], eax
00007eefba3cfd3e  mov eax, eax
00007eefba3cfd40  mov [r15+0x80], rax
00007eefba3cfd47  shr r10d, 0x0A
00007eefba3cfd4b  mov eax, [rsp+0x10]
00007eefba3cfd4f  xor eax, r10d
00007eefba3cfd52  mov [rsp+0x10], eax
00007eefba3cfd56  mov eax, eax
00007eefba3cfd58  mov [r15+0x78], rax
00007eefba3cfd5c  mov eax, [rsp+0x30]
00007eefba3cfd60  lea r14d, [ebp+eax*1]
00007eefba3cfd66  mov eax, [rsp+0x10]
00007eefba3cfd6a  lea r11d, [r14d+eax*1]
00007eefba3cfd6f  lea rax, [r12+0x40]
00007eefba3cfd74  mov [r13+rax*1], r11d
00007eefba3cfd79  mov eax, [rsp+0x20]
00007eefba3cfd7d  mov eax, eax
00007eefba3cfd7f  mov [r15+0x60], rax
00007eefba3cfd83  mov eax, [r15+0x108]
00007eefba3cfd8a  sahf
00007eefba3cfd8b  jnz 0x00007EEFBA3CFDBD
00007eefba3cfd8d  cmp dword ptr [r15+0x318], 0x00
00007eefba3cfd95  jz 0x00007EEFBA3CFE20
00007eefba3cfd9b  nop [rax+rax*1], ax
00007eefba3cfda4  nop [rax+rax*1], eax
00007eefba3cfdac  mov eax, 0x41049C
00007eefba3cfdb1  mov [r15+0x100], rax
00007eefba3cfdb8  jmp 0x00007EEFBA1FE110
00007eefba3cfdbd  cmp dword ptr [r15+0x318], 0x00
00007eefba3cfdc5  jz 0x00007EEFBA3CFC70
00007eefba3cfdcb  nop [rax+rax*1], ax
00007eefba3cfdd4  nop [rax+rax*1], eax
00007eefba3cfddc  mov eax, 0x410454
00007eefba3cfde1  mov [r15+0x100], rax
00007eefba3cfde8  jmp 0x00007EEFBA1FE110
00007eefba3cfded  int3
00007eefba3cfdee  call 0x00007EEFBA2E1430
00007eefba3cfdf3  jmp 0x00007EEFBA3CFC92
00007eefba3cfdf8  call 0x00007EEFBA2E1430
00007eefba3cfdfd  jmp 0x00007EEFBA3CFCA8
00007eefba3cfe02  call 0x00007EEFBA2E01C0
00007eefba3cfe07  jmp 0x00007EEFBA3CFCB2
00007eefba3cfe0c  call 0x00007EEFBA20A860
00007eefba3cfe11  jmp 0x00007EEFBA3CFD79
00007eefba3cfe16  int3
00007eefba3cfe17  nop [rax+rax*1], ax
00007eefba3cfe20  mov rax, [r15]
00007eefba3cfe23  mov r14d, [r13+rax*1]
00007eefba3cfe28  lea r12, [rax+0x04]
00007eefba3cfe2c  mov r11d, [r13+r12*1]
00007eefba3cfe31  mov [rsp+0x10], r14d
00007eefba3cfe36  mov r14d, r14d
00007eefba3cfe39  mov [r15+0x78], r14
00007eefba3cfe3d  mov [rsp+0x20], r11d
00007eefba3cfe42  mov r11d, r11d
00007eefba3cfe45  mov [r15+0x80], r11
00007eefba3cfe4c  lea r14, [rax+0x08]
00007eefba3cfe50  mov r12d, [r13+r14*1]
00007eefba3cfe55  lea r14, [rax+0x0C]
00007eefba3cfe59  mov r11d, [r13+r14*1]
00007eefba3cfe5e  mov [rsp+0x30], r12d
00007eefba3cfe63  mov r12d, r12d
00007eefba3cfe66  mov [r15+0x70], r12
00007eefba3cfe6a  mov [rsp+0x40], r11d
00007eefba3cfe6f  mov r11d, r11d
00007eefba3cfe72  mov [r15+0x68], r11
00007eefba3cfe76  lea r14, [rax+0x18]
00007eefba3cfe7a  mov r12d, [r13+r14*1]
00007eefba3cfe7f  lea r14, [rax+0x1C]
00007eefba3cfe83  mov r11d, [r13+r14*1]
00007eefba3cfe88  mov [rsp+0x50], r12d
00007eefba3cfe8d  mov r12d, r12d
00007eefba3cfe90  mov [r15+0x58], r12
00007eefba3cfe94  mov [rsp+0x60], r11d
00007eefba3cfe99  mov r11d, r11d
00007eefba3cfe9c  mov [r15+0x60], r11
00007eefba3cfea0  lea r14, [rax+0x10]
00007eefba3cfea4  mov r12d, [r13+r14*1]
00007eefba3cfea9  lea r14, [rax+0x14]
00007eefba3cfead  mov eax, [r13+r14*1]
00007eefba3cfeb2  mov [rsp+0x70], r12d
00007eefba3cfeb7  mov r12d, r12d
00007eefba3cfeba  mov [r15+0x18], r12
00007eefba3cfebe  mov [rsp+0x80], eax
00007eefba3cfec5  mov eax, eax
00007eefba3cfec7  mov [r15+0x90], rax
00007eefba3cfece  mov eax, [rsp+0x70]
00007eefba3cfed2  mov eax, eax
00007eefba3cfed4  mov [r15+0x30], rax
00007eefba3cfed8  mov eax, [rsp+0x50]
00007eefba3cfedc  mov eax, eax
00007eefba3cfede  mov [r15+0xA0], rax
00007eefba3cfee5  mov eax, [rsp+0x30]
00007eefba3cfee9  mov eax, eax
00007eefba3cfeeb  mov [r15+0x28], rax
00007eefba3cfeef  mov eax, [rsp+0x20]
00007eefba3cfef3  mov eax, eax
00007eefba3cfef5  mov [r15+0x98], rax
00007eefba3cfefc  mov eax, [rsp+0x10]
00007eefba3cff00  mov eax, eax
00007eefba3cff02  mov [r15+0x38], rax
00007eefba3cff06  mov eax, [rsp+0x70]
00007eefba3cff0a  mov r14d, [rsp+0x70]
00007eefba3cff0f  shrd eax, r14d, 0x06
00007eefba3cff14  mov [rsp+0x70], r14d
00007eefba3cff19  mov r12d, [rsp+0x80]
00007eefba3cff21  and r14d, r12d
00007eefba3cff24  mov r11d, [rsp+0x10]
00007eefba3cff29  mov r10d, [rsp+0x10]
00007eefba3cff2e  shrd r11d, r10d, 0x02
00007eefba3cff33  mov [rsp+0x10], r12d
00007eefba3cff38  mov r12d, r12d
00007eefba3cff3b  mov [r15+0x20], r12
00007eefba3cff3f  mov r12, [r15+0x50]
00007eefba3cff43  mov r9d, [r13+r12*1]
00007eefba3cff48  mov r12d, [rsp+0x50]
00007eefba3cff4d  mov r8d, [rsp+0x70]
00007eefba3cff52  andn ebp, r8d, r12d
00007eefba3cff57  mov edi, [rsp+0x60]
00007eefba3cff5b  lea esi, [r14d+edi*1]
00007eefba3cff60  rorx r14d, r8d, 0x0B
00007eefba3cff66  xor eax, r14d
00007eefba3cff69  rorx r14d, r10d, 0x0D
00007eefba3cff6f  xor r11d, r14d
00007eefba3cff72  lea edi, [esi+ebp*1]
00007eefba3cff76  mov r14, [r15+0x48]
00007eefba3cff7a  mov ebp, [r13+r14*1]
00007eefba3cff7f  mov r14d, [rsp+0x30]
00007eefba3cff84  mov esi, [rsp+0x20]
00007eefba3cff88  and r14d, esi
00007eefba3cff8b  mov [rsp+0x20], r14d
00007eefba3cff90  mov r14d, r14d
00007eefba3cff93  mov [r15+0xD8], r14
00007eefba3cff9a  lea r14d, [edi+r9d*1]
00007eefba3cff9f  mov r9d, [rsp+0x30]
00007eefba3cffa4  xor r9d, esi
00007eefba3cffa7  rorx edi, r8d, 0x19
00007eefba3cffad  xor eax, edi
00007eefba3cffaf  and r9d, r10d
00007eefba3cffb2  rorx edi, r10d, 0x16
00007eefba3cffb8  xor r11d, edi
00007eefba3cffbb  mov [rsp+0x30], r11d
00007eefba3cffc0  mov r11d, r11d
00007eefba3cffc3  mov [r15+0xD0], r11
00007eefba3cffca  lea r11d, [r14d+ebp*1]
00007eefba3cffcf  mov r10d, [rsp+0x20]
00007eefba3cffd4  xor r9d, r10d
00007eefba3cffd7  lea r14d, [r11d+eax*1]
00007eefba3cffdc  mov qword ptr [r15+0x88], 0x04
00007eefba3cffe7  mov eax, [rsp+0x30]
00007eefba3cffeb  lea r11d, [r9d+eax*1]
00007eefba3cfff0  mov eax, [rsp+0x40]
00007eefba3cfff4  lea r10d, [r14d+eax*1]
00007eefba3cfff9  mov r10d, r10d
00007eefba3cfffc  mov [r15+0xB8], r10
00007eefba3d0003  xor eax, eax
00007eefba3d0005  mov r10d, 0x04
00007eefba3d000b  mov r9d, 0x100
00007eefba3d0011  cmp r10, r9
00007eefba3d0014  cmc
00007eefba3d0015  lahf
00007eefba3d0016  seto al
00007eefba3d0019  mov [r15+0x108], eax
00007eefba3d0020  lea eax, [r11d+r14d*1]
00007eefba3d0025  mov eax, eax
00007eefba3d0027  mov [r15+0xA8], rax
00007eefba3d002e  mov r12d, r12d
00007eefba3d0031  mov [r15+0xB0], r12
00007eefba3d0038  mov eax, [rsp+0x10]
00007eefba3d003c  mov eax, eax
00007eefba3d003e  mov [r15+0xC0], rax
00007eefba3d0045  mov r8d, r8d
00007eefba3d0048  mov [r15+0xC8], r8
00007eefba3d004f  mov eax, [r15+0x108]
00007eefba3d0056  sahf
00007eefba3d0057  jnz 0x00007EEFBA3D0089
00007eefba3d0059  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0061  jz 0x00007EEFBA3D0350
00007eefba3d0067  nop [rax+rax*1], ax
00007eefba3d0070  nop [rax+rax*1], eax
00007eefba3d0078  mov eax, 0x41055C
00007eefba3d007d  mov [r15+0x100], rax
00007eefba3d0084  jmp 0x00007EEFBA1FE110
00007eefba3d0089  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0091  jz 0x00007EEFBA3D0120
00007eefba3d0097  nop [rax+rax*1], ax
00007eefba3d00a0  nop [rax+rax*1], eax
00007eefba3d00a8  mov eax, 0x4104D0
00007eefba3d00ad  mov [r15+0x100], rax
00007eefba3d00b4  jmp 0x00007EEFBA1FE110
00007eefba3d00b9  int3
00007eefba3d00ba  call 0x00007EEFBA20DAE0
00007eefba3d00bf  jmp 0x00007EEFBA3CFE28
00007eefba3d00c4  call 0x00007EEFBA2C0230
00007eefba3d00c9  jmp 0x00007EEFBA3CFE31
00007eefba3d00ce  call 0x00007EEFBA2E26A0
00007eefba3d00d3  jmp 0x00007EEFBA3CFE55
00007eefba3d00d8  call 0x00007EEFBA2E1430
00007eefba3d00dd  jmp 0x00007EEFBA3CFE5E
00007eefba3d00e2  call 0x00007EEFBA2E26A0
00007eefba3d00e7  jmp 0x00007EEFBA3CFE7F
00007eefba3d00ec  call 0x00007EEFBA2E1430
00007eefba3d00f1  jmp 0x00007EEFBA3CFE88
00007eefba3d00f6  call 0x00007EEFBA2E26A0
00007eefba3d00fb  jmp 0x00007EEFBA3CFEA9
00007eefba3d0100  call 0x00007EEFBA2D5890
00007eefba3d0105  jmp 0x00007EEFBA3CFEB2
00007eefba3d010a  call 0x00007EEFBA2BDD50
00007eefba3d010f  jmp 0x00007EEFBA3CFF48
00007eefba3d0114  call 0x00007EEFBA2DA580
00007eefba3d0119  jmp 0x00007EEFBA3CFF7F
00007eefba3d011e  int3
00007eefba3d011f  nop
00007eefba3d0120  mov eax, [r15+0xB8]
00007eefba3d0127  mov [rsp+0x10], eax
00007eefba3d012b  mov eax, eax
00007eefba3d012d  mov [r15+0x30], rax
00007eefba3d0131  mov eax, [r15+0xC0]
00007eefba3d0138  mov [rsp+0x20], eax
00007eefba3d013c  mov eax, eax
00007eefba3d013e  mov [r15+0xA0], rax
00007eefba3d0145  mov eax, [r15+0x28]
00007eefba3d0149  mov r14d, [r15+0x98]
00007eefba3d0150  mov [rsp+0x30], r14d
00007eefba3d0155  mov r14d, r14d
00007eefba3d0158  mov [r15+0x28], r14
00007eefba3d015c  mov r14d, [r15+0x38]
00007eefba3d0160  mov [rsp+0x40], r14d
00007eefba3d0165  mov r14d, r14d
00007eefba3d0168  mov [r15+0x98], r14
00007eefba3d016f  mov r14d, [r15+0xA8]
00007eefba3d0176  mov [rsp+0x50], r14d
00007eefba3d017b  mov r14d, r14d
00007eefba3d017e  mov [r15+0x38], r14
00007eefba3d0182  mov r14d, [rsp+0x10]
00007eefba3d0187  mov r12d, [rsp+0x10]
00007eefba3d018c  shrd r14d, r12d, 0x06
00007eefba3d0191  mov r11d, [r15+0xC8]
00007eefba3d0198  mov [rsp+0x10], r12d
00007eefba3d019d  and r12d, r11d
00007eefba3d01a0  mov r10d, [rsp+0x50]
00007eefba3d01a5  mov r9d, [rsp+0x50]
00007eefba3d01aa  shrd r10d, r9d, 0x02
00007eefba3d01af  mov [rsp+0x50], r11d
00007eefba3d01b4  mov r11d, r11d
00007eefba3d01b7  mov [r15+0x20], r11
00007eefba3d01bb  mov r11, [r15+0x88]
00007eefba3d01c2  mov r8, [r15+0x50]
00007eefba3d01c6  lea rbp, [r8+r11*1]
00007eefba3d01ca  mov r8d, [r13+rbp*1]
00007eefba3d01cf  mov ebp, [rsp+0x20]
00007eefba3d01d3  mov edi, [rsp+0x10]
00007eefba3d01d7  andn esi, edi, ebp
00007eefba3d01dc  mov edx, [r15+0xB0]
00007eefba3d01e3  lea ecx, [r12d+edx*1]
00007eefba3d01e8  rorx r12d, edi, 0x0B
00007eefba3d01ee  xor r14d, r12d
00007eefba3d01f1  rorx r12d, r9d, 0x0D
00007eefba3d01f7  xor r10d, r12d
00007eefba3d01fa  lea r12d, [ecx+esi*1]
00007eefba3d01ff  mov rsi, [r15+0x48]
00007eefba3d0203  lea rdx, [rsi+r11*1]
00007eefba3d0207  mov esi, [r13+rdx*1]
00007eefba3d020c  mov edx, [rsp+0x30]
00007eefba3d0210  mov ecx, [rsp+0x40]
00007eefba3d0214  and edx, ecx
00007eefba3d0216  mov [rsp+0x10], edx
00007eefba3d021a  mov edx, edx
00007eefba3d021c  mov [r15+0xD8], rdx
00007eefba3d0223  lea edx, [r12d+r8d*1]
00007eefba3d0228  mov r12d, [rsp+0x30]
00007eefba3d022d  xor r12d, ecx
00007eefba3d0230  rorx r8d, edi, 0x19
00007eefba3d0236  xor r14d, r8d
00007eefba3d0239  and r12d, r9d
00007eefba3d023c  rorx r8d, r9d, 0x16
00007eefba3d0242  xor r10d, r8d
00007eefba3d0245  mov [rsp+0x20], r10d
00007eefba3d024a  mov r10d, r10d
00007eefba3d024d  mov [r15+0xD0], r10
00007eefba3d0254  lea r10d, [edx+esi*1]
00007eefba3d0259  mov r9d, [rsp+0x10]
00007eefba3d025e  xor r12d, r9d
00007eefba3d0261  lea r9d, [r10d+r14d*1]
00007eefba3d0266  lea r14, [r11+0x04]
00007eefba3d026a  mov [r15+0x88], r14
00007eefba3d0271  mov r11d, [rsp+0x20]
00007eefba3d0276  lea r10d, [r12d+r11d*1]
00007eefba3d027b  lea r11d, [r9d+eax*1]
00007eefba3d0280  mov r11d, r11d
00007eefba3d0283  mov [r15+0xB8], r11
00007eefba3d028a  xor eax, eax
00007eefba3d028c  mov r12d, 0x100
00007eefba3d0292  cmp r14, r12
00007eefba3d0295  cmc
00007eefba3d0296  lahf
00007eefba3d0297  seto al
00007eefba3d029a  mov [r15+0x108], eax
00007eefba3d02a1  lea eax, [r10d+r9d*1]
00007eefba3d02a6  mov eax, eax
00007eefba3d02a8  mov [r15+0xA8], rax
00007eefba3d02af  mov ebp, ebp
00007eefba3d02b1  mov [r15+0xB0], rbp
00007eefba3d02b8  mov eax, [rsp+0x50]
00007eefba3d02bc  mov eax, eax
00007eefba3d02be  mov [r15+0xC0], rax
00007eefba3d02c5  mov edi, edi
00007eefba3d02c7  mov [r15+0xC8], rdi
00007eefba3d02ce  mov eax, [r15+0x108]
00007eefba3d02d5  sahf
00007eefba3d02d6  jnz 0x00007EEFBA3D0308
00007eefba3d02d8  cmp dword ptr [r15+0x318], 0x00
00007eefba3d02e0  jz 0x00007EEFBA3D0350
00007eefba3d02e6  nop [rax+rax*1], ax
00007eefba3d02ef  nop [rax+rax*1], eax
00007eefba3d02f7  mov eax, 0x41055C
00007eefba3d02fc  mov [r15+0x100], rax
00007eefba3d0303  jmp 0x00007EEFBA1FE110
00007eefba3d0308  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0310  jz 0x00007EEFBA3D0120
00007eefba3d0316  nop [rax+rax*1], ax
00007eefba3d031f  nop [rax+rax*1], eax
00007eefba3d0327  mov eax, 0x4104D0
00007eefba3d032c  mov [r15+0x100], rax
00007eefba3d0333  jmp 0x00007EEFBA1FE110
00007eefba3d0338  int3
00007eefba3d0339  call 0x00007EEFBA249010
00007eefba3d033e  jmp 0x00007EEFBA3D01CF
00007eefba3d0343  call 0x00007EEFBA225930
00007eefba3d0348  jmp 0x00007EEFBA3D020C
00007eefba3d034d  int3
00007eefba3d034e  nop
00007eefba3d0350  mov eax, [r15+0x98]
00007eefba3d0357  mov r14d, [r15+0x70]
00007eefba3d035b  lea r12d, [eax+r14d*1]
00007eefba3d0360  mov eax, [r15+0x28]
00007eefba3d0364  mov r14d, [r15+0x68]
00007eefba3d0368  lea r11d, [eax+r14d*1]
00007eefba3d036d  mov qword ptr [r15+0x88], 0x00
00007eefba3d0378  mov eax, [r15+0xA8]
00007eefba3d037f  mov r14d, [r15+0x78]
00007eefba3d0383  lea r10d, [eax+r14d*1]
00007eefba3d0388  mov [rsp+0x10], r10d
00007eefba3d038d  mov r10d, r10d
00007eefba3d0390  mov [r15+0x78], r10
00007eefba3d0394  mov eax, [r15+0x38]
00007eefba3d0398  mov r14d, [r15+0x80]
00007eefba3d039f  lea r10d, [eax+r14d*1]
00007eefba3d03a4  mov [rsp+0x20], r10d
00007eefba3d03a9  mov r10d, r10d
00007eefba3d03ac  mov [r15+0x80], r10
00007eefba3d03b3  mov rax, [r15]
00007eefba3d03b6  lea r14, [rax+0x08]
00007eefba3d03ba  mov [r13+r14*1], r12d
00007eefba3d03bf  lea r14, [rax+0x0C]
00007eefba3d03c3  mov [r13+r14*1], r11d
00007eefba3d03c8  mov r14d, [r15+0xB8]
00007eefba3d03cf  mov r12d, [r15+0x18]
00007eefba3d03d3  lea r11d, [r14d+r12d*1]
00007eefba3d03d8  mov [rsp+0x30], r11d
00007eefba3d03dd  mov r11d, r11d
00007eefba3d03e0  mov [r15+0x68], r11
00007eefba3d03e4  mov r14d, [r15+0x30]
00007eefba3d03e8  mov r12d, [r15+0x90]
00007eefba3d03ef  lea r11d, [r14d+r12d*1]
00007eefba3d03f4  mov [rsp+0x40], r11d
00007eefba3d03f9  mov r11d, r11d
00007eefba3d03fc  mov [r15+0x70], r11
00007eefba3d0400  mov r14d, [r15+0x20]
00007eefba3d0404  mov r12d, [r15+0x58]
00007eefba3d0408  lea r11d, [r14d+r12d*1]
00007eefba3d040d  mov [rsp+0x50], r11d
00007eefba3d0412  mov r11d, r11d
00007eefba3d0415  mov [r15+0x58], r11
00007eefba3d0419  mov r14d, [r15+0xA0]
00007eefba3d0420  mov r12d, [r15+0x60]
00007eefba3d0424  lea r11d, [r14d+r12d*1]
00007eefba3d0429  mov [rsp+0x60], r11d
00007eefba3d042e  mov r11d, r11d
00007eefba3d0431  mov [r15+0x60], r11
00007eefba3d0435  mov r14d, [rsp+0x10]
00007eefba3d043a  mov [r13+rax*1], r14d
00007eefba3d043f  lea r14, [rax+0x04]
00007eefba3d0443  mov r12d, [rsp+0x20]
00007eefba3d0448  mov [r13+r14*1], r12d
00007eefba3d044d  lea r14, [rax+0x10]
00007eefba3d0451  mov r12d, [rsp+0x30]
00007eefba3d0456  mov [r13+r14*1], r12d
00007eefba3d045b  lea r14, [rax+0x14]
00007eefba3d045f  mov r12d, [rsp+0x40]
00007eefba3d0464  mov [r13+r14*1], r12d
00007eefba3d0469  lea r14, [rax+0x18]
00007eefba3d046d  mov r12d, [rsp+0x50]
00007eefba3d0472  mov [r13+r14*1], r12d
00007eefba3d0477  lea r14, [rax+0x1C]
00007eefba3d047b  mov r12d, [rsp+0x60]
00007eefba3d0480  mov [r13+r14*1], r12d
00007eefba3d0485  lea r14, [rax+0x68]
00007eefba3d0489  xor eax, eax
00007eefba3d048b  mov [r13+r14*1], rax
00007eefba3d0490  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0498  jz 0x00007EEFBA3CEF90
00007eefba3d049e  nop [rax+rax*1], ax
00007eefba3d04a7  nop [rax+rax*1], eax
00007eefba3d04af  mov eax, 0x410378
00007eefba3d04b4  mov [r15+0x100], rax
00007eefba3d04bb  jmp 0x00007EEFBA1FE110
00007eefba3d04c0  int3
00007eefba3d04c1  call 0x00007EEFBA2E2BA0
00007eefba3d04c6  jmp 0x00007EEFBA3D03BF
00007eefba3d04cb  call 0x00007EEFBA2E1920
00007eefba3d04d0  jmp 0x00007EEFBA3D03C8
00007eefba3d04d5  call 0x00007EEFBA20DFE0
00007eefba3d04da  jmp 0x00007EEFBA3D043F
00007eefba3d04df  call 0x00007EEFBA2E2BA0
00007eefba3d04e4  jmp 0x00007EEFBA3D044D
00007eefba3d04e9  call 0x00007EEFBA2E2BA0
00007eefba3d04ee  jmp 0x00007EEFBA3D045B
00007eefba3d04f3  call 0x00007EEFBA2E2BA0
00007eefba3d04f8  jmp 0x00007EEFBA3D0469
00007eefba3d04fd  call 0x00007EEFBA2E2BA0
00007eefba3d0502  jmp 0x00007EEFBA3D0477
00007eefba3d0507  call 0x00007EEFBA2E2BA0
00007eefba3d050c  jmp 0x00007EEFBA3D0485
00007eefba3d0511  call 0x00007EEFBA2D5EB0
00007eefba3d0516  jmp 0x00007EEFBA3D0490
00007eefba3d051b  int3
00007eefba3d051c  nop [rax], eax
00007eefba3d0520  mov rax, [r15+0xF8]
00007eefba3d0527  lea r14, [rax+0x140]
00007eefba3d052e  mov r12, [r13+r14*1]
00007eefba3d0533  lea r14, [rax+0x148]
00007eefba3d053a  mov r11, [r13+r14*1]
00007eefba3d053f  mov [r15+0xA0], r12
00007eefba3d0546  mov [r15+0x98], r11
00007eefba3d054d  lea r14, [rax+0x130]
00007eefba3d0554  mov r12, [r13+r14*1]
00007eefba3d0559  lea r14, [rax+0x138]
00007eefba3d0560  mov r11, [r13+r14*1]
00007eefba3d0565  mov [r15+0xB0], r12
00007eefba3d056c  mov [r15+0xA8], r11
00007eefba3d0573  lea r14, [rax+0x120]
00007eefba3d057a  mov r12, [r13+r14*1]
00007eefba3d057f  lea r14, [rax+0x128]
00007eefba3d0586  mov r11, [r13+r14*1]
00007eefba3d058b  mov [r15+0xC0], r12
00007eefba3d0592  mov [r15+0xB8], r11
00007eefba3d0599  lea r14, [rax+0x110]
00007eefba3d05a0  mov r12, [r13+r14*1]
00007eefba3d05a5  lea r14, [rax+0x118]
00007eefba3d05ac  mov r11, [r13+r14*1]
00007eefba3d05b1  mov [r15+0xD0], r12
00007eefba3d05b8  mov [r15+0xC8], r11
00007eefba3d05bf  lea r14, [rax+0x100]
00007eefba3d05c6  mov r12, [r13+r14*1]
00007eefba3d05cb  lea r14, [rax+0x108]
00007eefba3d05d2  mov r11, [r13+r14*1]
00007eefba3d05d7  mov [r15+0xE8], r12
00007eefba3d05de  mov [r15+0xD8], r11
00007eefba3d05e5  lea r14, [rax+0x150]
00007eefba3d05ec  mov [r15+0xF8], r14
00007eefba3d05f3  mov rax, [r15+0xF0]
00007eefba3d05fa  mov [r15+0x100], rax
00007eefba3d0601  jmp 0x00007EEFBA3CE5C0
00007eefba3d0606  int3
00007eefba3d0607  call 0x00007EEFBA2E27E0
00007eefba3d060c  jmp 0x00007EEFBA3D0533
00007eefba3d0611  call 0x00007EEFBA2E1570
00007eefba3d0616  jmp 0x00007EEFBA3D053F
00007eefba3d061b  call 0x00007EEFBA2E27E0
00007eefba3d0620  jmp 0x00007EEFBA3D0559
00007eefba3d0625  call 0x00007EEFBA2E1570
00007eefba3d062a  jmp 0x00007EEFBA3D0565
00007eefba3d062f  call 0x00007EEFBA2E27E0
00007eefba3d0634  jmp 0x00007EEFBA3D057F
00007eefba3d0639  call 0x00007EEFBA2E1570
00007eefba3d063e  jmp 0x00007EEFBA3D058B
00007eefba3d0643  call 0x00007EEFBA2E27E0
00007eefba3d0648  jmp 0x00007EEFBA3D05A5
00007eefba3d064d  call 0x00007EEFBA2E1570
00007eefba3d0652  jmp 0x00007EEFBA3D05B1
00007eefba3d0657  call 0x00007EEFBA2E27E0
00007eefba3d065c  jmp 0x00007EEFBA3D05CB
00007eefba3d0661  call 0x00007EEFBA2E1570
00007eefba3d0666  jmp 0x00007EEFBA3D05D7
00007eefba3d066b  int3
00007eefba3d066c  nop [rax], eax
00007eefba3d0670  mov eax, [r15+0xA0]
00007eefba3d0677  mov [rsp+0x10], eax
00007eefba3d067b  xor eax, eax
00007eefba3d067d  mov r14d, [rsp+0x10]
00007eefba3d0682  sub r14d, 0x01
00007eefba3d0686  cmc
00007eefba3d0687  lahf
00007eefba3d0688  seto al
00007eefba3d068b  mov [r15+0x108], eax
00007eefba3d0692  mov r14d, r14d
00007eefba3d0695  mov [r15+0xA0], r14
00007eefba3d069c  mov eax, [r15+0x108]
00007eefba3d06a3  sahf
00007eefba3d06a4  jnz 0x00007EEFBA3D06D6
00007eefba3d06a6  cmp dword ptr [r15+0x318], 0x00
00007eefba3d06ae  jz 0x00007EEFBA3D07A0
00007eefba3d06b4  nop [rax+rax*1], ax
00007eefba3d06bd  nop [rax+rax*1], eax
00007eefba3d06c5  mov eax, 0x41027C
00007eefba3d06ca  mov [r15+0x100], rax
00007eefba3d06d1  jmp 0x00007EEFBA1FE110
00007eefba3d06d6  cmp dword ptr [r15+0x318], 0x00
00007eefba3d06de  jz 0x00007EEFBA3D0710
00007eefba3d06e4  nop [rax+rax*1], ax
00007eefba3d06ed  nop [rax+rax*1], eax
00007eefba3d06f5  mov eax, 0x410264
00007eefba3d06fa  mov [r15+0x100], rax
00007eefba3d0701  jmp 0x00007EEFBA1FE110
00007eefba3d0706  int3
00007eefba3d0707  int3
00007eefba3d0708  nop [rax+rax*1], eax
00007eefba3d0710  mov rax, [r15+0xF8]
00007eefba3d0717  mov [r15], rax
00007eefba3d071a  mov rax, [r15+0x98]
00007eefba3d0721  mov [r15+0x08], rax
00007eefba3d0725  mov qword ptr [r15+0x10], 0x12C
00007eefba3d072d  mov qword ptr [r15+0xF0], 0x410274
00007eefba3d0738  mov r14d, [r15+0x320]
00007eefba3d073f  mov eax, 0x410274
00007eefba3d0744  mov rcx, 0x7EEFBA3D0670
00007eefba3d074e  mov [r15+r14*8+0x328], rax
00007eefba3d0756  mov [r15+r14*8+0x368], rcx
00007eefba3d075e  add r14d, 0x01
00007eefba3d0762  and r14d, 0x07
00007eefba3d0766  mov [r15+0x320], r14d
00007eefba3d076d  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0775  jz 0x00007EEFBA3CEC20
00007eefba3d077b  nop [rax+rax*1], ax
00007eefba3d0784  nop [rax+rax*1], eax
00007eefba3d078c  mov eax, 0x410338
00007eefba3d0791  mov [r15+0x100], rax
00007eefba3d0798  jmp 0x00007EEFBA1FE110
00007eefba3d079d  int3
00007eefba3d079e  int3
00007eefba3d079f  nop
00007eefba3d07a0  mov rax, [r15+0xF8]
00007eefba3d07a7  lea r14, [rax+0x20]
00007eefba3d07ab  mov r12, [r13+r14*1]
00007eefba3d07b0  mov [r15+0x98], r12
00007eefba3d07b7  mov qword ptr [r15+0x40], 0x80
00007eefba3d07bf  mov [r15], rax
00007eefba3d07c2  lea r14, [rax+0x8C]
00007eefba3d07c9  mov [r15+0x08], r14
00007eefba3d07cd  mov qword ptr [r15+0x10], 0x01
00007eefba3d07d5  lea r14, [rax+0x8C]
00007eefba3d07dc  mov eax, 0x80
00007eefba3d07e1  mov [r13+r14*1], al
00007eefba3d07e6  mov qword ptr [r15+0xF0], 0x410298
00007eefba3d07f1  mov r14d, [r15+0x320]
00007eefba3d07f8  mov eax, 0x410298
00007eefba3d07fd  mov rcx, 0x7EEFBA3D0870
00007eefba3d0807  mov [r15+r14*8+0x328], rax
00007eefba3d080f  mov [r15+r14*8+0x368], rcx
00007eefba3d0817  add r14d, 0x01
00007eefba3d081b  and r14d, 0x07
00007eefba3d081f  mov [r15+0x320], r14d
00007eefba3d0826  cmp dword ptr [r15+0x318], 0x00
00007eefba3d082e  jz 0x00007EEFBA3CEC20
00007eefba3d0834  nop [rax+rax*1], ax
00007eefba3d083d  nop [rax+rax*1], eax
00007eefba3d0845  mov eax, 0x410338
00007eefba3d084a  mov [r15+0x100], rax
00007eefba3d0851  jmp 0x00007EEFBA1FE110
00007eefba3d0856  int3
00007eefba3d0857  call 0x00007EEFBA2E27E0
00007eefba3d085c  jmp 0x00007EEFBA3D07B0
00007eefba3d0861  call 0x00007EEFBA2D5AF0
00007eefba3d0866  jmp 0x00007EEFBA3D07E6
00007eefba3d086b  int3
00007eefba3d086c  nop [rax], eax
00007eefba3d0870  mov rax, [r15+0xF8]
00007eefba3d0877  lea r14, [rax+0x68]
00007eefba3d087b  mov r12, [r13+r14*1]
00007eefba3d0880  mov [r15+0x40], r12
00007eefba3d0884  lea r14, [rax+0x88]
00007eefba3d088b  xor eax, eax
00007eefba3d088d  mov [r13+r14*1], al
00007eefba3d0892  xor eax, eax
00007eefba3d0894  mov r14d, 0x38
00007eefba3d089a  cmp r12, r14
00007eefba3d089d  cmc
00007eefba3d089e  lahf
00007eefba3d089f  seto al
00007eefba3d08a2  mov [r15+0x108], eax
00007eefba3d08a9  mov eax, [r15+0x108]
00007eefba3d08b0  sahf
00007eefba3d08b1  jz 0x00007EEFBA3D08E3
00007eefba3d08b3  cmp dword ptr [r15+0x318], 0x00
00007eefba3d08bb  jz 0x00007EEFBA3D0930
00007eefba3d08c1  nop [rax+rax*1], ax
00007eefba3d08ca  nop [rax+rax*1], eax
00007eefba3d08d2  mov eax, 0x4102A8
00007eefba3d08d7  mov [r15+0x100], rax
00007eefba3d08de  jmp 0x00007EEFBA1FE110
00007eefba3d08e3  cmp dword ptr [r15+0x318], 0x00
00007eefba3d08eb  jz 0x00007EEFBA3D0A70
00007eefba3d08f1  nop [rax+rax*1], ax
00007eefba3d08fa  nop [rax+rax*1], eax
00007eefba3d0902  mov eax, 0x4102C4
00007eefba3d0907  mov [r15+0x100], rax
00007eefba3d090e  jmp 0x00007EEFBA1FE110
00007eefba3d0913  int3
00007eefba3d0914  call 0x00007EEFBA2E27E0
00007eefba3d0919  jmp 0x00007EEFBA3D0880
00007eefba3d091e  call 0x00007EEFBA2D5AF0
00007eefba3d0923  jmp 0x00007EEFBA3D0892
00007eefba3d0928  int3
00007eefba3d0929  nop [rax], eax
00007eefba3d0930  mov rax, [r15+0xF8]
00007eefba3d0937  mov [r15], rax
00007eefba3d093a  lea r14, [rax+0x88]
00007eefba3d0941  mov [r15+0x08], r14
00007eefba3d0945  mov qword ptr [r15+0x10], 0x01
00007eefba3d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007eefba3d0958  mov r14d, [r15+0x320]
00007eefba3d095f  mov eax, 0x4102B8
00007eefba3d0964  mov rcx, 0x7EEFBA3D09C0
00007eefba3d096e  mov [r15+r14*8+0x328], rax
00007eefba3d0976  mov [r15+r14*8+0x368], rcx
00007eefba3d097e  add r14d, 0x01
00007eefba3d0982  and r14d, 0x07
00007eefba3d0986  mov [r15+0x320], r14d
00007eefba3d098d  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0995  jz 0x00007EEFBA3CEC20
00007eefba3d099b  nop [rax+rax*1], ax
00007eefba3d09a4  nop [rax+rax*1], eax
00007eefba3d09ac  mov eax, 0x410338
00007eefba3d09b1  mov [r15+0x100], rax
00007eefba3d09b8  jmp 0x00007EEFBA1FE110
00007eefba3d09bd  int3
00007eefba3d09be  int3
00007eefba3d09bf  nop
00007eefba3d09c0  mov rax, [r15+0xF8]
00007eefba3d09c7  lea r14, [rax+0x68]
00007eefba3d09cb  mov rax, [r13+r14*1]
00007eefba3d09d0  mov [r15+0x40], rax
00007eefba3d09d4  mov [rsp+0x10], rax
00007eefba3d09d9  xor eax, eax
00007eefba3d09db  mov r14, [rsp+0x10]
00007eefba3d09e0  mov r12d, 0x38
00007eefba3d09e6  cmp r14, r12
00007eefba3d09e9  cmc
00007eefba3d09ea  lahf
00007eefba3d09eb  seto al
00007eefba3d09ee  mov [r15+0x108], eax
00007eefba3d09f5  mov eax, [r15+0x108]
00007eefba3d09fc  sahf
00007eefba3d09fd  jnz 0x00007EEFBA3D0A2F
00007eefba3d09ff  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0a07  jz 0x00007EEFBA3D0A70
00007eefba3d0a0d  nop [rax+rax*1], ax
00007eefba3d0a16  nop [rax+rax*1], eax
00007eefba3d0a1e  mov eax, 0x4102C4
00007eefba3d0a23  mov [r15+0x100], rax
00007eefba3d0a2a  jmp 0x00007EEFBA1FE110
00007eefba3d0a2f  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0a37  jz 0x00007EEFBA3D0930
00007eefba3d0a3d  nop [rax+rax*1], ax
00007eefba3d0a46  nop [rax+rax*1], eax
00007eefba3d0a4e  mov eax, 0x4102A8
00007eefba3d0a53  mov [r15+0x100], rax
00007eefba3d0a5a  jmp 0x00007EEFBA1FE110
00007eefba3d0a5f  int3
00007eefba3d0a60  call 0x00007EEFBA2D59C0
00007eefba3d0a65  jmp 0x00007EEFBA3D09D0
00007eefba3d0a6a  int3
00007eefba3d0a6b  nop [rax+rax*1], eax
00007eefba3d0a70  mov rax, [r15+0x98]
00007eefba3d0a77  rorx r14, rax, 0x3D
00007eefba3d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007eefba3d0a81  mov rax, [r15+0xF8]
00007eefba3d0a88  mov [r15], rax
00007eefba3d0a8b  lea r12, [rax+0x78]
00007eefba3d0a8f  mov [r15+0x08], r12
00007eefba3d0a93  mov qword ptr [r15+0x10], 0x08
00007eefba3d0a9b  bswap r14
00007eefba3d0a9e  mov [r15+0x40], r14
00007eefba3d0aa2  lea r12, [rax+0x78]
00007eefba3d0aa6  mov [r13+r12*1], r14
00007eefba3d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007eefba3d0ab6  mov r14d, [r15+0x320]
00007eefba3d0abd  mov eax, 0x4102E0
00007eefba3d0ac2  mov rcx, 0x7EEFBA3D0B30
00007eefba3d0acc  mov [r15+r14*8+0x328], rax
00007eefba3d0ad4  mov [r15+r14*8+0x368], rcx
00007eefba3d0adc  add r14d, 0x01
00007eefba3d0ae0  and r14d, 0x07
00007eefba3d0ae4  mov [r15+0x320], r14d
00007eefba3d0aeb  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0af3  jz 0x00007EEFBA3CEC20
00007eefba3d0af9  nop [rax+rax*1], ax
00007eefba3d0b02  nop [rax+rax*1], eax
00007eefba3d0b0a  mov eax, 0x410338
00007eefba3d0b0f  mov [r15+0x100], rax
00007eefba3d0b16  jmp 0x00007EEFBA1FE110
00007eefba3d0b1b  int3
00007eefba3d0b1c  call 0x00007EEFBA2C3FE0
00007eefba3d0b21  jmp 0x00007EEFBA3D0AAB
00007eefba3d0b26  int3
00007eefba3d0b27  nop [rax+rax*1], ax
00007eefba3d0b30  mov rax, [r15+0xF8]
00007eefba3d0b37  mov r14d, [r13+rax*1]
00007eefba3d0b3c  lea r12, [rax+0x04]
00007eefba3d0b40  mov r11d, [r13+r12*1]
00007eefba3d0b45  lea r12, [rax+0x08]
00007eefba3d0b49  mov r10d, [r13+r12*1]
00007eefba3d0b4e  lea r12, [rax+0x0C]
00007eefba3d0b52  mov r9d, [r13+r12*1]
00007eefba3d0b57  mov qword ptr [r15+0x48], 0x430860
00007eefba3d0b5f  lea r12, [rax+0x80]
00007eefba3d0b66  mov r8, [r13+r12*1]
00007eefba3d0b6b  mov [r15+0xF0], r8
00007eefba3d0b72  bswap r14d
00007eefba3d0b75  bswap r11d
00007eefba3d0b78  mov r12d, 0x430860
00007eefba3d0b7e  mov [r13+r12*1], r14d
00007eefba3d0b83  mov r14d, 0x430864
00007eefba3d0b89  mov [r13+r14*1], r11d
00007eefba3d0b8e  bswap r10d
00007eefba3d0b91  bswap r9d
00007eefba3d0b94  lea r14, [rax+0x10]
00007eefba3d0b98  mov r12d, [r13+r14*1]
00007eefba3d0b9d  lea r14, [rax+0x14]
00007eefba3d0ba1  mov r11d, [r13+r14*1]
00007eefba3d0ba6  mov r14d, 0x430868
00007eefba3d0bac  mov [r13+r14*1], r10d
00007eefba3d0bb1  mov r14d, 0x43086C
00007eefba3d0bb7  mov [r13+r14*1], r9d
00007eefba3d0bbc  lea r14, [rax+0x90]
00007eefba3d0bc3  mov r10, [r13+r14*1]
00007eefba3d0bc8  lea r14, [rax+0x98]
00007eefba3d0bcf  mov r9, [r13+r14*1]
00007eefba3d0bd4  mov [r15+0xA0], r10
00007eefba3d0bdb  mov [r15+0x98], r9
00007eefba3d0be2  bswap r12d
00007eefba3d0be5  bswap r11d
00007eefba3d0be8  mov [rsp+0x10], r11d
00007eefba3d0bed  mov r11d, r11d
00007eefba3d0bf0  mov [r15+0x58], r11
00007eefba3d0bf4  lea r14, [rax+0x18]
00007eefba3d0bf8  mov r11d, [r13+r14*1]
00007eefba3d0bfd  lea r14, [rax+0x1C]
00007eefba3d0c01  mov r10d, [r13+r14*1]
00007eefba3d0c06  mov [rsp+0x20], r10d
00007eefba3d0c0b  mov r10d, r10d
00007eefba3d0c0e  mov [r15+0x60], r10
00007eefba3d0c12  mov r14d, 0x430870
00007eefba3d0c18  mov [r13+r14*1], r12d
00007eefba3d0c1d  mov r14d, 0x430874
00007eefba3d0c23  mov r12d, [rsp+0x10]
00007eefba3d0c28  mov [r13+r14*1], r12d
00007eefba3d0c2d  bswap r11d
00007eefba3d0c30  mov [rsp+0x10], r11d
00007eefba3d0c35  mov r11d, r11d
00007eefba3d0c38  mov [r15+0x40], r11
00007eefba3d0c3c  mov r14d, [rsp+0x20]
00007eefba3d0c41  bswap r14d
00007eefba3d0c44  mov [rsp+0x20], r14d
00007eefba3d0c49  mov r14d, r14d
00007eefba3d0c4c  mov [r15+0x50], r14
00007eefba3d0c50  mov r14d, 0x430878
00007eefba3d0c56  mov r12d, [rsp+0x10]
00007eefba3d0c5b  mov [r13+r14*1], r12d
00007eefba3d0c60  mov r14d, 0x43087C
00007eefba3d0c66  mov r12d, [rsp+0x20]
00007eefba3d0c6b  mov [r13+r14*1], r12d
00007eefba3d0c70  lea r14, [rax+0xA0]
00007eefba3d0c77  mov [r15+0xF8], r14
00007eefba3d0c7e  mov [r15+0x100], r8
00007eefba3d0c85  jmp 0x00007EEFBA3CE5C0
00007eefba3d0c8a  int3
00007eefba3d0c8b  call 0x00007EEFBA20DAE0
00007eefba3d0c90  jmp 0x00007EEFBA3D0B3C
00007eefba3d0c95  call 0x00007EEFBA2C0230
00007eefba3d0c9a  jmp 0x00007EEFBA3D0B45
00007eefba3d0c9f  call 0x00007EEFBA2BEFC0
00007eefba3d0ca4  jmp 0x00007EEFBA3D0B4E
00007eefba3d0ca9  call 0x00007EEFBA2BDD50
00007eefba3d0cae  jmp 0x00007EEFBA3D0B57
00007eefba3d0cb3  call 0x00007EEFBA2BCC20
00007eefba3d0cb8  jmp 0x00007EEFBA3D0B6B
00007eefba3d0cbd  call 0x00007EEFBA2C3EA0
00007eefba3d0cc2  jmp 0x00007EEFBA3D0B83
00007eefba3d0cc7  call 0x00007EEFBA2E1920
00007eefba3d0ccc  jmp 0x00007EEFBA3D0B8E
00007eefba3d0cd1  call 0x00007EEFBA2E26A0
00007eefba3d0cd6  jmp 0x00007EEFBA3D0B9D
00007eefba3d0cdb  call 0x00007EEFBA2E1430
00007eefba3d0ce0  jmp 0x00007EEFBA3D0BA6
00007eefba3d0ce5  call 0x00007EEFBA2E06B0
00007eefba3d0cea  jmp 0x00007EEFBA3D0BB1
00007eefba3d0cef  call 0x00007EEFBA2DF440
00007eefba3d0cf4  jmp 0x00007EEFBA3D0BBC
00007eefba3d0cf9  call 0x00007EEFBA2E0300
00007eefba3d0cfe  jmp 0x00007EEFBA3D0BC8
00007eefba3d0d03  call 0x00007EEFBA2DF090
00007eefba3d0d08  jmp 0x00007EEFBA3D0BD4
00007eefba3d0d0d  call 0x00007EEFBA2E1430
00007eefba3d0d12  jmp 0x00007EEFBA3D0BFD
00007eefba3d0d17  call 0x00007EEFBA2E01C0
00007eefba3d0d1c  jmp 0x00007EEFBA3D0C06
00007eefba3d0d21  call 0x00007EEFBA2E2BA0
00007eefba3d0d26  jmp 0x00007EEFBA3D0C1D
00007eefba3d0d2b  call 0x00007EEFBA2E2BA0
00007eefba3d0d30  jmp 0x00007EEFBA3D0C2D
00007eefba3d0d35  call 0x00007EEFBA2E2BA0
00007eefba3d0d3a  jmp 0x00007EEFBA3D0C60
00007eefba3d0d3f  call 0x00007EEFBA2E2BA0
00007eefba3d0d44  jmp 0x00007EEFBA3D0C70
00007eefba3d0d49  int3
00007eefba3d0d4a  nop [rax+rax*1], ax
00007eefba3d0d50  mov qword ptr [r15+0x100], 0x04
00007eefba3d0d5b  mov esi, 0x00
00007eefba3d0d60  mov edx, 0x09
00007eefba3d0d65  mov rdi, 0x7FFD09A07F60
00007eefba3d0d6f  mov rax, 0x5F502286C970
00007eefba3d0d79  call rax
00007eefba3d0d7b  cmp dword ptr [r15+0x318], 0x00
00007eefba3d0d83  jnz 0x00007EEFBA1FE110
00007eefba3d0d89  jmp 0x00007EEFBA1FE0A0
00007eefba3d0d8e  int3
00007eefba3d0d8f  int3
