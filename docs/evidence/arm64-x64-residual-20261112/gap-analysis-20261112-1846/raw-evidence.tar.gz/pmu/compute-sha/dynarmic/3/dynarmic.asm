00007d6f6a1ce69b  nop [rax+rax*1], eax
00007d6f6a1ce6a0  mov rax, [r15+0xF8]
00007d6f6a1ce6a7  lea r14, [rax-0xA0]
00007d6f6a1ce6ae  mov [r15+0xF8], r14
00007d6f6a1ce6b5  lea rax, [r14+0x90]
00007d6f6a1ce6bc  mov r12, [r15+0xA0]
00007d6f6a1ce6c3  mov r11, [r15+0x98]
00007d6f6a1ce6ca  mov [r13+rax*1], r12
00007d6f6a1ce6cf  lea rax, [r14+0x98]
00007d6f6a1ce6d6  mov [r13+rax*1], r11
00007d6f6a1ce6db  mov eax, 0x420670
00007d6f6a1ce6e0  movups xmm1, [r13+rax*1]
00007d6f6a1ce6e6  mov eax, 0x420610
00007d6f6a1ce6eb  movups xmm15, [r13+rax*1]
00007d6f6a1ce6f1  mov eax, 0x420690
00007d6f6a1ce6f6  movups xmm14, [r13+rax*1]
00007d6f6a1ce6fc  mov eax, 0x420630
00007d6f6a1ce701  movups xmm13, [r13+rax*1]
00007d6f6a1ce707  mov qword ptr [r15+0x98], 0x4308A0
00007d6f6a1ce712  mov eax, 0x4206A0
00007d6f6a1ce717  movups xmm12, [r13+rax*1]
00007d6f6a1ce71d  mov eax, 0x4308A0
00007d6f6a1ce722  movups [r13+rax*1], xmm1
00007d6f6a1ce728  mov eax, 0x4308B0
00007d6f6a1ce72d  movups [r13+rax*1], xmm15
00007d6f6a1ce733  mov eax, 0x4308C0
00007d6f6a1ce738  movups [r13+rax*1], xmm14
00007d6f6a1ce73e  mov eax, 0x4308D0
00007d6f6a1ce743  movups [r13+rax*1], xmm13
00007d6f6a1ce749  mov eax, 0x420600
00007d6f6a1ce74e  movups xmm14, [r13+rax*1]
00007d6f6a1ce754  mov eax, 0x4205F0
00007d6f6a1ce759  movups xmm13, [r13+rax*1]
00007d6f6a1ce75f  mov eax, 0x4309A0
00007d6f6a1ce764  movups [r13+rax*1], xmm1
00007d6f6a1ce76a  mov eax, 0x4309B0
00007d6f6a1ce76f  movups [r13+rax*1], xmm15
00007d6f6a1ce775  mov eax, 0x4308E0
00007d6f6a1ce77a  movups [r13+rax*1], xmm12
00007d6f6a1ce780  mov eax, 0x4308F0
00007d6f6a1ce785  movups [r13+rax*1], xmm14
00007d6f6a1ce78b  mov eax, 0x4205E0
00007d6f6a1ce790  movups xmm1, [r13+rax*1]
00007d6f6a1ce796  mov eax, 0x420640
00007d6f6a1ce79b  movups xmm15, [r13+rax*1]
00007d6f6a1ce7a1  mov eax, 0x430900
00007d6f6a1ce7a6  movups [r13+rax*1], xmm13
00007d6f6a1ce7ac  mov eax, 0x430910
00007d6f6a1ce7b1  movups [r13+rax*1], xmm1
00007d6f6a1ce7b7  mov eax, 0x420650
00007d6f6a1ce7bc  movups xmm1, [r13+rax*1]
00007d6f6a1ce7c2  mov eax, 0x420620
00007d6f6a1ce7c7  movups xmm14, [r13+rax*1]
00007d6f6a1ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007d6f6a1ce7d5  mov eax, 0x430920
00007d6f6a1ce7da  movups [r13+rax*1], xmm15
00007d6f6a1ce7e0  mov eax, 0x430930
00007d6f6a1ce7e5  movups [r13+rax*1], xmm1
00007d6f6a1ce7eb  mov eax, 0x4206C0
00007d6f6a1ce7f0  movups xmm1, [r13+rax*1]
00007d6f6a1ce7f6  mov eax, 0x4206D0
00007d6f6a1ce7fb  movups xmm15, [r13+rax*1]
00007d6f6a1ce801  movaps [r15+0x150], xmm15
00007d6f6a1ce809  mov qword ptr [r15+0xA0], 0x3E8
00007d6f6a1ce814  mov eax, 0x430940
00007d6f6a1ce819  movups [r13+rax*1], xmm14
00007d6f6a1ce81f  mov eax, 0x430950
00007d6f6a1ce824  movups [r13+rax*1], xmm1
00007d6f6a1ce82a  mov eax, 0x4206B0
00007d6f6a1ce82f  movups xmm1, [r13+rax*1]
00007d6f6a1ce835  mov eax, 0x420660
00007d6f6a1ce83a  movups xmm14, [r13+rax*1]
00007d6f6a1ce840  movaps [r15+0x140], xmm14
00007d6f6a1ce848  lea rax, [r14+0x80]
00007d6f6a1ce84f  mov r12, [r15+0xF0]
00007d6f6a1ce856  mov [r13+rax*1], r12
00007d6f6a1ce85b  mov eax, 0x430960
00007d6f6a1ce860  movups [r13+rax*1], xmm15
00007d6f6a1ce866  mov eax, 0x430970
00007d6f6a1ce86b  movups [r13+rax*1], xmm1
00007d6f6a1ce871  mov eax, 0x420680
00007d6f6a1ce876  movups xmm1, [r13+rax*1]
00007d6f6a1ce87c  mov eax, 0x4206E0
00007d6f6a1ce881  mov r12, [r13+rax*1]
00007d6f6a1ce886  movq xmm15, r12
00007d6f6a1ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007d6f6a1ce893  mov eax, 0x430980
00007d6f6a1ce898  movups [r13+rax*1], xmm14
00007d6f6a1ce89e  mov eax, 0x430990
00007d6f6a1ce8a3  movups [r13+rax*1], xmm1
00007d6f6a1ce8a9  mov eax, 0x420748
00007d6f6a1ce8ae  movups xmm1, [r13+rax*1]
00007d6f6a1ce8b4  movq rax, xmm15
00007d6f6a1ce8b9  mov r12d, 0x4309C0
00007d6f6a1ce8bf  mov [r13+r12*1], rax
00007d6f6a1ce8c4  mov eax, 0x420728
00007d6f6a1ce8c9  movups xmm15, [r13+rax*1]
00007d6f6a1ce8cf  mov eax, 0x420738
00007d6f6a1ce8d4  movups xmm14, [r13+rax*1]
00007d6f6a1ce8da  lea rax, [r14+0x60]
00007d6f6a1ce8de  movups [r13+rax*1], xmm1
00007d6f6a1ce8e4  mov eax, 0x4309C8
00007d6f6a1ce8e9  mov r12d, 0x421DF8D3
00007d6f6a1ce8ef  mov [r13+rax*1], r12d
00007d6f6a1ce8f4  lea rax, [r14+0x40]
00007d6f6a1ce8f8  movups [r13+rax*1], xmm15
00007d6f6a1ce8fe  lea rax, [r14+0x50]
00007d6f6a1ce902  movups [r13+rax*1], xmm14
00007d6f6a1ce908  mov eax, 0x4206E8
00007d6f6a1ce90d  movups xmm1, [r13+rax*1]
00007d6f6a1ce913  mov eax, 0x4206F8
00007d6f6a1ce918  movups xmm15, [r13+rax*1]
00007d6f6a1ce91e  movaps [r15+0x120], xmm15
00007d6f6a1ce926  movups [r13+r14*1], xmm1
00007d6f6a1ce92c  lea rax, [r14+0x10]
00007d6f6a1ce930  movups [r13+rax*1], xmm15
00007d6f6a1ce936  mov eax, 0x420708
00007d6f6a1ce93b  movups xmm1, [r13+rax*1]
00007d6f6a1ce941  mov eax, 0x420718
00007d6f6a1ce946  movups xmm15, [r13+rax*1]
00007d6f6a1ce94c  movaps [r15+0x110], xmm1
00007d6f6a1ce954  movaps [r15+0x130], xmm15
00007d6f6a1ce95c  lea rax, [r14+0x20]
00007d6f6a1ce960  movups [r13+rax*1], xmm1
00007d6f6a1ce966  lea rax, [r14+0x30]
00007d6f6a1ce96a  movups [r13+rax*1], xmm15
00007d6f6a1ce970  mov [r15], r14
00007d6f6a1ce973  mov qword ptr [r15+0x08], 0x4308A0
00007d6f6a1ce97b  mov qword ptr [r15+0x10], 0x12C
00007d6f6a1ce983  mov qword ptr [r15+0xF0], 0x410274
00007d6f6a1ce98e  mov r14d, [r15+0x320]
00007d6f6a1ce995  mov eax, 0x410274
00007d6f6a1ce99a  mov rcx, 0x7D6F6A1D0670
00007d6f6a1ce9a4  mov [r15+r14*8+0x328], rax
00007d6f6a1ce9ac  mov [r15+r14*8+0x368], rcx
00007d6f6a1ce9b4  add r14d, 0x01
00007d6f6a1ce9b8  and r14d, 0x07
00007d6f6a1ce9bc  mov [r15+0x320], r14d
00007d6f6a1ce9c3  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1ce9cb  jz 0x00007D6F6A1CEC20
00007d6f6a1ce9d1  nop [rax+rax*1], ax
00007d6f6a1ce9da  nop [rax+rax*1], eax
00007d6f6a1ce9e2  mov eax, 0x410338
00007d6f6a1ce9e7  mov [r15+0x100], rax
00007d6f6a1ce9ee  jmp 0x00007D6F69FFE110
00007d6f6a1ce9f3  int3
00007d6f6a1ce9f4  call 0x00007D6F6A00BC20
00007d6f6a1ce9f9  jmp 0x00007D6F6A1CE6CF
00007d6f6a1ce9fe  call 0x00007D6F6A00A9A0
00007d6f6a1cea03  jmp 0x00007D6F6A1CE6DB
00007d6f6a1cea08  call 0x00007D6F69FFF430
00007d6f6a1cea0d  jmp 0x00007D6F6A1CE6E6
00007d6f6a1cea12  call 0x00007D6F6A00E760
00007d6f6a1cea17  jmp 0x00007D6F6A1CE6F1
00007d6f6a1cea1c  call 0x00007D6F6A00D4E0
00007d6f6a1cea21  jmp 0x00007D6F6A1CE6FC
00007d6f6a1cea26  call 0x00007D6F6A00C260
00007d6f6a1cea2b  jmp 0x00007D6F6A1CE707
00007d6f6a1cea30  call 0x00007D6F6A00AFE0
00007d6f6a1cea35  jmp 0x00007D6F6A1CE71D
00007d6f6a1cea3a  call 0x00007D6F69FFF540
00007d6f6a1cea3f  jmp 0x00007D6F6A1CE728
00007d6f6a1cea44  call 0x00007D6F6A00E880
00007d6f6a1cea49  jmp 0x00007D6F6A1CE733
00007d6f6a1cea4e  call 0x00007D6F6A00D600
00007d6f6a1cea53  jmp 0x00007D6F6A1CE73E
00007d6f6a1cea58  call 0x00007D6F6A00C380
00007d6f6a1cea5d  jmp 0x00007D6F6A1CE749
00007d6f6a1cea62  call 0x00007D6F6A00D4E0
00007d6f6a1cea67  jmp 0x00007D6F6A1CE754
00007d6f6a1cea6c  call 0x00007D6F6A00C260
00007d6f6a1cea71  jmp 0x00007D6F6A1CE75F
00007d6f6a1cea76  call 0x00007D6F69FFF540
00007d6f6a1cea7b  jmp 0x00007D6F6A1CE76A
00007d6f6a1cea80  call 0x00007D6F6A00E880
00007d6f6a1cea85  jmp 0x00007D6F6A1CE775
00007d6f6a1cea8a  call 0x00007D6F6A00B100
00007d6f6a1cea8f  jmp 0x00007D6F6A1CE780
00007d6f6a1cea94  call 0x00007D6F6A00D600
00007d6f6a1cea99  jmp 0x00007D6F6A1CE78B
00007d6f6a1cea9e  call 0x00007D6F69FFF430
00007d6f6a1ceaa3  jmp 0x00007D6F6A1CE796
00007d6f6a1ceaa8  call 0x00007D6F6A00E760
00007d6f6a1ceaad  jmp 0x00007D6F6A1CE7A1
00007d6f6a1ceab2  call 0x00007D6F6A00C380
00007d6f6a1ceab7  jmp 0x00007D6F6A1CE7AC
00007d6f6a1ceabc  call 0x00007D6F69FFF540
00007d6f6a1ceac1  jmp 0x00007D6F6A1CE7B7
00007d6f6a1ceac6  call 0x00007D6F69FFF430
00007d6f6a1ceacb  jmp 0x00007D6F6A1CE7C2
00007d6f6a1cead0  call 0x00007D6F6A00D4E0
00007d6f6a1cead5  jmp 0x00007D6F6A1CE7CD
00007d6f6a1ceada  call 0x00007D6F6A00E880
00007d6f6a1ceadf  jmp 0x00007D6F6A1CE7E0
00007d6f6a1ceae4  call 0x00007D6F69FFF540
00007d6f6a1ceae9  jmp 0x00007D6F6A1CE7EB
00007d6f6a1ceaee  call 0x00007D6F69FFF430
00007d6f6a1ceaf3  jmp 0x00007D6F6A1CE7F6
00007d6f6a1ceaf8  call 0x00007D6F6A00E760
00007d6f6a1ceafd  jmp 0x00007D6F6A1CE801
00007d6f6a1ceb02  call 0x00007D6F6A00D600
00007d6f6a1ceb07  jmp 0x00007D6F6A1CE81F
00007d6f6a1ceb0c  call 0x00007D6F69FFF540
00007d6f6a1ceb11  jmp 0x00007D6F6A1CE82A
00007d6f6a1ceb16  call 0x00007D6F69FFF430
00007d6f6a1ceb1b  jmp 0x00007D6F6A1CE835
00007d6f6a1ceb20  call 0x00007D6F6A00D4E0
00007d6f6a1ceb25  jmp 0x00007D6F6A1CE840
00007d6f6a1ceb2a  call 0x00007D6F6A00BC20
00007d6f6a1ceb2f  jmp 0x00007D6F6A1CE85B
00007d6f6a1ceb34  call 0x00007D6F6A00E880
00007d6f6a1ceb39  jmp 0x00007D6F6A1CE866
00007d6f6a1ceb3e  call 0x00007D6F69FFF540
00007d6f6a1ceb43  jmp 0x00007D6F6A1CE871
00007d6f6a1ceb48  call 0x00007D6F69FFF430
00007d6f6a1ceb4d  jmp 0x00007D6F6A1CE87C
00007d6f6a1ceb52  call 0x00007D6F6A00B720
00007d6f6a1ceb57  jmp 0x00007D6F6A1CE886
00007d6f6a1ceb5c  call 0x00007D6F6A00D600
00007d6f6a1ceb61  jmp 0x00007D6F6A1CE89E
00007d6f6a1ceb66  call 0x00007D6F69FFF540
00007d6f6a1ceb6b  jmp 0x00007D6F6A1CE8A9
00007d6f6a1ceb70  call 0x00007D6F69FFF430
00007d6f6a1ceb75  jmp 0x00007D6F6A1CE8B4
00007d6f6a1ceb7a  call 0x00007D6F6A0B4CB0
00007d6f6a1ceb7f  jmp 0x00007D6F6A1CE8C4
00007d6f6a1ceb84  call 0x00007D6F6A00E760
00007d6f6a1ceb89  jmp 0x00007D6F6A1CE8CF
00007d6f6a1ceb8e  call 0x00007D6F6A00D4E0
00007d6f6a1ceb93  jmp 0x00007D6F6A1CE8DA
00007d6f6a1ceb98  call 0x00007D6F69FFF540
00007d6f6a1ceb9d  jmp 0x00007D6F6A1CE8E4
00007d6f6a1ceba2  call 0x00007D6F6A00BAE0
00007d6f6a1ceba7  jmp 0x00007D6F6A1CE8F4
00007d6f6a1cebac  call 0x00007D6F6A00E880
00007d6f6a1cebb1  jmp 0x00007D6F6A1CE8FE
00007d6f6a1cebb6  call 0x00007D6F6A00D600
00007d6f6a1cebbb  jmp 0x00007D6F6A1CE908
00007d6f6a1cebc0  call 0x00007D6F69FFF430
00007d6f6a1cebc5  jmp 0x00007D6F6A1CE913
00007d6f6a1cebca  call 0x00007D6F6A00E760
00007d6f6a1cebcf  jmp 0x00007D6F6A1CE91E
00007d6f6a1cebd4  call 0x00007D6F6A0D6600
00007d6f6a1cebd9  jmp 0x00007D6F6A1CE92C
00007d6f6a1cebde  call 0x00007D6F6A00E880
00007d6f6a1cebe3  jmp 0x00007D6F6A1CE936
00007d6f6a1cebe8  call 0x00007D6F69FFF430
00007d6f6a1cebed  jmp 0x00007D6F6A1CE941
00007d6f6a1cebf2  call 0x00007D6F6A00E760
00007d6f6a1cebf7  jmp 0x00007D6F6A1CE94C
00007d6f6a1cebfc  call 0x00007D6F69FFF540
00007d6f6a1cec01  jmp 0x00007D6F6A1CE966
00007d6f6a1cec06  call 0x00007D6F6A00E880
00007d6f6a1cec0b  jmp 0x00007D6F6A1CE970
00007d6f6a1cec10  int3
00007d6f6a1cec11  nop [rax+rax*1], ax
00007d6f6a1cec1a  nop [rax+rax*1], ax
00007d6f6a1cec20  mov rax, [r15]
00007d6f6a1cec23  lea r14, [rax+0x20]
00007d6f6a1cec27  mov r12, [r13+r14*1]
00007d6f6a1cec2c  mov r14, [r15+0x10]
00007d6f6a1cec30  lea r11, [r12+r14*1]
00007d6f6a1cec34  mov [r15+0x40], r11
00007d6f6a1cec38  lea r12, [rax+0x20]
00007d6f6a1cec3c  mov [r13+r12*1], r11
00007d6f6a1cec41  test r14, r14
00007d6f6a1cec44  setz r14b
00007d6f6a1cec48  movzx r14, r14b
00007d6f6a1cec4c  mov [rsp+0x414], r14b
00007d6f6a1cec54  cmp byte ptr [rsp+0x414], 0x00
00007d6f6a1cec5c  jz 0x00007D6F6A1CEC8E
00007d6f6a1cec5e  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cec66  mov eax, 0x4105B0
00007d6f6a1cec6b  mov [r15+0x100], rax
00007d6f6a1cec72  jz 0x00007D6F69FFE0A0
00007d6f6a1cec78  nop [rax+rax*1], eax
00007d6f6a1cec7d  mov eax, 0x4105B0
00007d6f6a1cec82  mov [r15+0x100], rax
00007d6f6a1cec89  jmp 0x00007D6F69FFE110
00007d6f6a1cec8e  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cec96  jz 0x00007D6F6A1CECE0
00007d6f6a1cec9c  nop [rax+rax*1], ax
00007d6f6a1ceca5  nop [rax+rax*1], eax
00007d6f6a1cecad  mov eax, 0x410348
00007d6f6a1cecb2  mov [r15+0x100], rax
00007d6f6a1cecb9  jmp 0x00007D6F69FFE110
00007d6f6a1cecbe  int3
00007d6f6a1cecbf  call 0x00007D6F6A0E27E0
00007d6f6a1cecc4  jmp 0x00007D6F6A1CEC2C
00007d6f6a1cecc9  call 0x00007D6F6A0C0860
00007d6f6a1cecce  jmp 0x00007D6F6A1CEC41
00007d6f6a1cecd3  int3
00007d6f6a1cecd4  nop [rax+rax*1], ax
00007d6f6a1cecdd  nop [rax], eax
00007d6f6a1cece0  mov rax, [r15+0xF8]
00007d6f6a1cece7  lea r14, [rax-0x150]
00007d6f6a1cecee  mov [r15+0xF8], r14
00007d6f6a1cecf5  mov rax, [r15]
00007d6f6a1cecf8  lea r12, [rax+0x68]
00007d6f6a1cecfc  mov r11, [r13+r12*1]
00007d6f6a1ced01  mov [r15+0x88], r11
00007d6f6a1ced08  lea r12, [rax+0x28]
00007d6f6a1ced0c  mov [r15+0x40], r12
00007d6f6a1ced10  mov [r15+0x48], r14
00007d6f6a1ced14  mov qword ptr [r15+0x50], 0x420758
00007d6f6a1ced1c  lea rax, [r14+0x100]
00007d6f6a1ced23  mov r12, [r15+0xE8]
00007d6f6a1ced2a  mov r11, [r15+0xD8]
00007d6f6a1ced31  mov [r13+rax*1], r12
00007d6f6a1ced36  lea rax, [r14+0x108]
00007d6f6a1ced3d  mov [r13+rax*1], r11
00007d6f6a1ced42  lea rax, [r14+0x110]
00007d6f6a1ced49  mov r12, [r15+0xD0]
00007d6f6a1ced50  mov r11, [r15+0xC8]
00007d6f6a1ced57  mov [r13+rax*1], r12
00007d6f6a1ced5c  lea rax, [r14+0x118]
00007d6f6a1ced63  mov [r13+rax*1], r11
00007d6f6a1ced68  lea rax, [r14+0x120]
00007d6f6a1ced6f  mov r12, [r15+0xC0]
00007d6f6a1ced76  mov r11, [r15+0xB8]
00007d6f6a1ced7d  mov [r13+rax*1], r12
00007d6f6a1ced82  lea rax, [r14+0x128]
00007d6f6a1ced89  mov [r13+rax*1], r11
00007d6f6a1ced8e  lea rax, [r14+0x130]
00007d6f6a1ced95  mov r12, [r15+0xB0]
00007d6f6a1ced9c  mov r11, [r15+0xA8]
00007d6f6a1ceda3  mov [r13+rax*1], r12
00007d6f6a1ceda8  lea rax, [r14+0x138]
00007d6f6a1cedaf  mov [r13+rax*1], r11
00007d6f6a1cedb4  lea rax, [r14+0x140]
00007d6f6a1cedbb  mov r12, [r15+0xA0]
00007d6f6a1cedc2  mov r11, [r15+0x98]
00007d6f6a1cedc9  mov [r13+rax*1], r12
00007d6f6a1cedce  lea rax, [r14+0x148]
00007d6f6a1cedd5  mov [r13+rax*1], r11
00007d6f6a1cedda  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cede2  jz 0x00007D6F6A1CEE80
00007d6f6a1cede8  nop [rax+rax*1], ax
00007d6f6a1cedf1  nop [rax+rax*1], eax
00007d6f6a1cedf9  mov eax, 0x410380
00007d6f6a1cedfe  mov [r15+0x100], rax
00007d6f6a1cee05  jmp 0x00007D6F69FFE110
00007d6f6a1cee0a  int3
00007d6f6a1cee0b  call 0x00007D6F6A0C0370
00007d6f6a1cee10  jmp 0x00007D6F6A1CED01
00007d6f6a1cee15  call 0x00007D6F6A00BC20
00007d6f6a1cee1a  jmp 0x00007D6F6A1CED36
00007d6f6a1cee1f  call 0x00007D6F6A00A9A0
00007d6f6a1cee24  jmp 0x00007D6F6A1CED42
00007d6f6a1cee29  call 0x00007D6F6A00BC20
00007d6f6a1cee2e  jmp 0x00007D6F6A1CED5C
00007d6f6a1cee33  call 0x00007D6F6A00A9A0
00007d6f6a1cee38  jmp 0x00007D6F6A1CED68
00007d6f6a1cee3d  call 0x00007D6F6A00BC20
00007d6f6a1cee42  jmp 0x00007D6F6A1CED82
00007d6f6a1cee47  call 0x00007D6F6A00A9A0
00007d6f6a1cee4c  jmp 0x00007D6F6A1CED8E
00007d6f6a1cee51  call 0x00007D6F6A00BC20
00007d6f6a1cee56  jmp 0x00007D6F6A1CEDA8
00007d6f6a1cee5b  call 0x00007D6F6A00A9A0
00007d6f6a1cee60  jmp 0x00007D6F6A1CEDB4
00007d6f6a1cee65  call 0x00007D6F6A00BC20
00007d6f6a1cee6a  jmp 0x00007D6F6A1CEDCE
00007d6f6a1cee6f  call 0x00007D6F6A00A9A0
00007d6f6a1cee74  jmp 0x00007D6F6A1CEDDA
00007d6f6a1cee79  int3
00007d6f6a1cee7a  nop [rax+rax*1], ax
00007d6f6a1cee80  mov rax, [r15+0x08]
00007d6f6a1cee84  movzx r14d, byte ptr [r13+rax*1]
00007d6f6a1cee8a  movzx r14d, r14b
00007d6f6a1cee8e  mov [rsp+0x10], r14d
00007d6f6a1cee93  mov r14d, r14d
00007d6f6a1cee96  mov [r15+0x58], r14
00007d6f6a1cee9a  lea r14, [rax+0x01]
00007d6f6a1cee9e  mov [r15+0x08], r14
00007d6f6a1ceea2  mov rax, [r15+0x88]
00007d6f6a1ceea9  lea r14, [rax+0x01]
00007d6f6a1ceead  mov r12, [r15]
00007d6f6a1ceeb0  lea r11, [r12+0x68]
00007d6f6a1ceeb5  mov [r13+r11*1], r14
00007d6f6a1ceeba  lea r14, [r12+rax*1]
00007d6f6a1ceebe  mov [r15+0x60], r14
00007d6f6a1ceec2  lea rax, [r14+0x28]
00007d6f6a1ceec6  mov r11d, [rsp+0x10]
00007d6f6a1ceecb  movzx r14d, r11b
00007d6f6a1ceecf  mov [r13+rax*1], r14b
00007d6f6a1ceed4  lea rax, [r12+0x68]
00007d6f6a1ceed9  mov r14, [r13+rax*1]
00007d6f6a1ceede  mov [r15+0x88], r14
00007d6f6a1ceee5  xor eax, eax
00007d6f6a1ceee7  mov r12d, 0x40
00007d6f6a1ceeed  cmp r14, r12
00007d6f6a1ceef0  cmc
00007d6f6a1ceef1  lahf
00007d6f6a1ceef2  seto al
00007d6f6a1ceef5  mov [r15+0x108], eax
00007d6f6a1ceefc  mov eax, [r15+0x108]
00007d6f6a1cef03  sahf
00007d6f6a1cef04  jnz 0x00007D6F6A1CEF36
00007d6f6a1cef06  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cef0e  jz 0x00007D6F6A1CF020
00007d6f6a1cef14  nop [rax+rax*1], ax
00007d6f6a1cef1d  nop [rax+rax*1], eax
00007d6f6a1cef25  mov eax, 0x4103A0
00007d6f6a1cef2a  mov [r15+0x100], rax
00007d6f6a1cef31  jmp 0x00007D6F69FFE110
00007d6f6a1cef36  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cef3e  jz 0x00007D6F6A1CEF90
00007d6f6a1cef44  nop [rax+rax*1], ax
00007d6f6a1cef4d  nop [rax+rax*1], eax
00007d6f6a1cef55  mov eax, 0x410378
00007d6f6a1cef5a  mov [r15+0x100], rax
00007d6f6a1cef61  jmp 0x00007D6F69FFE110
00007d6f6a1cef66  int3
00007d6f6a1cef67  call 0x00007D6F6A00D860
00007d6f6a1cef6c  jmp 0x00007D6F6A1CEE8A
00007d6f6a1cef71  call 0x00007D6F6A0B36E0
00007d6f6a1cef76  jmp 0x00007D6F6A1CEEBA
00007d6f6a1cef7b  call 0x00007D6F6A00DD60
00007d6f6a1cef80  jmp 0x00007D6F6A1CEED4
00007d6f6a1cef85  call 0x00007D6F6A00DC20
00007d6f6a1cef8a  jmp 0x00007D6F6A1CEEDE
00007d6f6a1cef8f  int3
00007d6f6a1cef90  mov rax, [r15+0x10]
00007d6f6a1cef94  lea r14, [rax-0x01]
00007d6f6a1cef98  mov [r15+0x10], r14
00007d6f6a1cef9c  test r14, r14
00007d6f6a1cef9f  setz r14b
00007d6f6a1cefa3  movzx r14, r14b
00007d6f6a1cefa7  mov [rsp+0x414], r14b
00007d6f6a1cefaf  cmp byte ptr [rsp+0x414], 0x00
00007d6f6a1cefb7  jz 0x00007D6F6A1CEFE9
00007d6f6a1cefb9  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cefc1  jz 0x00007D6F6A1D0520
00007d6f6a1cefc7  nop [rax+rax*1], ax
00007d6f6a1cefd0  nop [rax+rax*1], eax
00007d6f6a1cefd8  mov eax, 0x410598
00007d6f6a1cefdd  mov [r15+0x100], rax
00007d6f6a1cefe4  jmp 0x00007D6F69FFE110
00007d6f6a1cefe9  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1ceff1  jz 0x00007D6F6A1CEE80
00007d6f6a1ceff7  nop [rax+rax*1], ax
00007d6f6a1cf000  nop [rax+rax*1], eax
00007d6f6a1cf008  mov eax, 0x410380
00007d6f6a1cf00d  mov [r15+0x100], rax
00007d6f6a1cf014  jmp 0x00007D6F69FFE110
00007d6f6a1cf019  int3
00007d6f6a1cf01a  int3
00007d6f6a1cf01b  nop [rax+rax*1], eax
00007d6f6a1cf020  mov rax, [r15+0x40]
00007d6f6a1cf024  movzx r14d, byte ptr [r13+rax*1]
00007d6f6a1cf02a  movaps xmm1, [r15+0x110]
00007d6f6a1cf032  pinsrb xmm1, r14d, 0x00
00007d6f6a1cf039  lea r14, [rax+0x01]
00007d6f6a1cf03d  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf043  movaps xmm15, [r15+0x120]
00007d6f6a1cf04b  pinsrb xmm15, r12d, 0x00
00007d6f6a1cf052  lea r14, [rax+0x02]
00007d6f6a1cf056  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf05c  movaps xmm14, [r15+0x130]
00007d6f6a1cf064  pinsrb xmm14, r12d, 0x00
00007d6f6a1cf06b  lea r14, [rax+0x03]
00007d6f6a1cf06f  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf075  movaps xmm13, [r15+0x140]
00007d6f6a1cf07d  pinsrb xmm13, r12d, 0x00
00007d6f6a1cf084  lea r14, [rax+0x04]
00007d6f6a1cf088  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf08e  pinsrb xmm1, r12d, 0x01
00007d6f6a1cf095  lea r14, [rax+0x05]
00007d6f6a1cf099  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf09f  pinsrb xmm15, r12d, 0x01
00007d6f6a1cf0a6  lea r14, [rax+0x06]
00007d6f6a1cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf0b0  pinsrb xmm14, r12d, 0x01
00007d6f6a1cf0b7  lea r14, [rax+0x07]
00007d6f6a1cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf0c1  pinsrb xmm13, r12d, 0x01
00007d6f6a1cf0c8  lea r14, [rax+0x08]
00007d6f6a1cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf0d2  pinsrb xmm1, r12d, 0x02
00007d6f6a1cf0d9  lea r14, [rax+0x09]
00007d6f6a1cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf0e3  pinsrb xmm15, r12d, 0x02
00007d6f6a1cf0ea  lea r14, [rax+0x0A]
00007d6f6a1cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf0f4  pinsrb xmm14, r12d, 0x02
00007d6f6a1cf0fb  lea r14, [rax+0x0B]
00007d6f6a1cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf105  pinsrb xmm13, r12d, 0x02
00007d6f6a1cf10c  lea r14, [rax+0x0C]
00007d6f6a1cf110  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf116  pinsrb xmm1, r12d, 0x03
00007d6f6a1cf11d  lea r14, [rax+0x0D]
00007d6f6a1cf121  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf127  pinsrb xmm15, r12d, 0x03
00007d6f6a1cf12e  lea r14, [rax+0x0E]
00007d6f6a1cf132  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf138  pinsrb xmm14, r12d, 0x03
00007d6f6a1cf13f  lea r14, [rax+0x0F]
00007d6f6a1cf143  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf149  pinsrb xmm13, r12d, 0x03
00007d6f6a1cf150  lea r14, [rax+0x10]
00007d6f6a1cf154  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf15a  pinsrb xmm1, r12d, 0x04
00007d6f6a1cf161  lea r14, [rax+0x11]
00007d6f6a1cf165  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf16b  pinsrb xmm15, r12d, 0x04
00007d6f6a1cf172  lea r14, [rax+0x12]
00007d6f6a1cf176  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf17c  pinsrb xmm14, r12d, 0x04
00007d6f6a1cf183  lea r14, [rax+0x13]
00007d6f6a1cf187  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf18d  pinsrb xmm13, r12d, 0x04
00007d6f6a1cf194  lea r14, [rax+0x14]
00007d6f6a1cf198  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf19e  pinsrb xmm1, r12d, 0x05
00007d6f6a1cf1a5  lea r14, [rax+0x15]
00007d6f6a1cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf1af  pinsrb xmm15, r12d, 0x05
00007d6f6a1cf1b6  lea r14, [rax+0x16]
00007d6f6a1cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf1c0  pinsrb xmm14, r12d, 0x05
00007d6f6a1cf1c7  lea r14, [rax+0x17]
00007d6f6a1cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf1d1  pinsrb xmm13, r12d, 0x05
00007d6f6a1cf1d8  lea r14, [rax+0x18]
00007d6f6a1cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf1e2  pinsrb xmm1, r12d, 0x06
00007d6f6a1cf1e9  lea r14, [rax+0x19]
00007d6f6a1cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf1f3  pinsrb xmm15, r12d, 0x06
00007d6f6a1cf1fa  lea r14, [rax+0x1A]
00007d6f6a1cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf204  pinsrb xmm14, r12d, 0x06
00007d6f6a1cf20b  lea r14, [rax+0x1B]
00007d6f6a1cf20f  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf215  pinsrb xmm13, r12d, 0x06
00007d6f6a1cf21c  lea r14, [rax+0x1C]
00007d6f6a1cf220  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf226  pinsrb xmm1, r12d, 0x07
00007d6f6a1cf22d  lea r14, [rax+0x1D]
00007d6f6a1cf231  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf237  pinsrb xmm15, r12d, 0x07
00007d6f6a1cf23e  lea r14, [rax+0x1E]
00007d6f6a1cf242  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf248  pinsrb xmm14, r12d, 0x07
00007d6f6a1cf24f  lea r14, [rax+0x1F]
00007d6f6a1cf253  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf259  pinsrb xmm13, r12d, 0x07
00007d6f6a1cf260  lea r14, [rax+0x20]
00007d6f6a1cf264  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf26a  pinsrb xmm1, r12d, 0x08
00007d6f6a1cf271  lea r14, [rax+0x21]
00007d6f6a1cf275  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf27b  pinsrb xmm15, r12d, 0x08
00007d6f6a1cf282  lea r14, [rax+0x22]
00007d6f6a1cf286  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf28c  pinsrb xmm14, r12d, 0x08
00007d6f6a1cf293  lea r14, [rax+0x23]
00007d6f6a1cf297  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf29d  pinsrb xmm13, r12d, 0x08
00007d6f6a1cf2a4  lea r14, [rax+0x24]
00007d6f6a1cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf2ae  pinsrb xmm1, r12d, 0x09
00007d6f6a1cf2b5  lea r14, [rax+0x25]
00007d6f6a1cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf2bf  pinsrb xmm15, r12d, 0x09
00007d6f6a1cf2c6  lea r14, [rax+0x26]
00007d6f6a1cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf2d0  pinsrb xmm14, r12d, 0x09
00007d6f6a1cf2d7  lea r14, [rax+0x27]
00007d6f6a1cf2db  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf2e1  pinsrb xmm13, r12d, 0x09
00007d6f6a1cf2e8  lea r14, [rax+0x28]
00007d6f6a1cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf2f2  pinsrb xmm1, r12d, 0x0A
00007d6f6a1cf2f9  lea r14, [rax+0x29]
00007d6f6a1cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf303  pinsrb xmm15, r12d, 0x0A
00007d6f6a1cf30a  lea r14, [rax+0x2A]
00007d6f6a1cf30e  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf314  pinsrb xmm14, r12d, 0x0A
00007d6f6a1cf31b  lea r14, [rax+0x2B]
00007d6f6a1cf31f  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf325  pinsrb xmm13, r12d, 0x0A
00007d6f6a1cf32c  lea r14, [rax+0x2C]
00007d6f6a1cf330  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf336  pinsrb xmm1, r12d, 0x0B
00007d6f6a1cf33d  lea r14, [rax+0x2D]
00007d6f6a1cf341  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf347  pinsrb xmm15, r12d, 0x0B
00007d6f6a1cf34e  lea r14, [rax+0x2E]
00007d6f6a1cf352  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf358  pinsrb xmm14, r12d, 0x0B
00007d6f6a1cf35f  lea r14, [rax+0x2F]
00007d6f6a1cf363  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf369  pinsrb xmm13, r12d, 0x0B
00007d6f6a1cf370  lea r14, [rax+0x30]
00007d6f6a1cf374  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf37a  pinsrb xmm1, r12d, 0x0C
00007d6f6a1cf381  lea r14, [rax+0x31]
00007d6f6a1cf385  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf38b  pinsrb xmm15, r12d, 0x0C
00007d6f6a1cf392  lea r14, [rax+0x32]
00007d6f6a1cf396  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf39c  pinsrb xmm14, r12d, 0x0C
00007d6f6a1cf3a3  lea r14, [rax+0x33]
00007d6f6a1cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf3ad  pinsrb xmm13, r12d, 0x0C
00007d6f6a1cf3b4  lea r14, [rax+0x34]
00007d6f6a1cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf3be  pinsrb xmm1, r12d, 0x0D
00007d6f6a1cf3c5  lea r14, [rax+0x35]
00007d6f6a1cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf3cf  pinsrb xmm15, r12d, 0x0D
00007d6f6a1cf3d6  lea r14, [rax+0x36]
00007d6f6a1cf3da  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf3e0  pinsrb xmm14, r12d, 0x0D
00007d6f6a1cf3e7  lea r14, [rax+0x37]
00007d6f6a1cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf3f1  pinsrb xmm13, r12d, 0x0D
00007d6f6a1cf3f8  lea r14, [rax+0x38]
00007d6f6a1cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf402  pinsrb xmm1, r12d, 0x0E
00007d6f6a1cf409  lea r14, [rax+0x39]
00007d6f6a1cf40d  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf413  pinsrb xmm15, r12d, 0x0E
00007d6f6a1cf41a  lea r14, [rax+0x3A]
00007d6f6a1cf41e  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf424  pinsrb xmm14, r12d, 0x0E
00007d6f6a1cf42b  lea r14, [rax+0x3B]
00007d6f6a1cf42f  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf435  pinsrb xmm13, r12d, 0x0E
00007d6f6a1cf43c  lea r14, [rax+0x3C]
00007d6f6a1cf440  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf446  pinsrb xmm1, r12d, 0x0F
00007d6f6a1cf44d  movaps [r15+0x110], xmm1
00007d6f6a1cf455  lea r14, [rax+0x3D]
00007d6f6a1cf459  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf45f  pinsrb xmm15, r12d, 0x0F
00007d6f6a1cf466  movaps [r15+0x120], xmm15
00007d6f6a1cf46e  lea r14, [rax+0x3E]
00007d6f6a1cf472  movzx r12d, byte ptr [r13+r14*1]
00007d6f6a1cf478  pinsrb xmm14, r12d, 0x0F
00007d6f6a1cf47f  movaps [r15+0x130], xmm14
00007d6f6a1cf487  lea r14, [rax+0x3F]
00007d6f6a1cf48b  movzx eax, byte ptr [r13+r14*1]
00007d6f6a1cf491  pinsrb xmm13, eax, 0x0F
00007d6f6a1cf498  movaps [r15+0x140], xmm13
00007d6f6a1cf4a0  movq xmm1, qword ptr [r15+0x120]
00007d6f6a1cf4a9  pmovzxbw xmm1, xmm1
00007d6f6a1cf4ae  psllw xmm1, 0x00
00007d6f6a1cf4b3  movaps [r15+0x150], xmm1
00007d6f6a1cf4bb  movq xmm1, qword ptr [r15+0x130]
00007d6f6a1cf4c4  pmovzxbw xmm1, xmm1
00007d6f6a1cf4c9  psllw xmm1, 0x00
00007d6f6a1cf4ce  movaps [r15+0x160], xmm1
00007d6f6a1cf4d6  movq xmm1, qword ptr [r15+0x110]
00007d6f6a1cf4df  pmovzxbw xmm1, xmm1
00007d6f6a1cf4e4  psllw xmm1, 0x00
00007d6f6a1cf4e9  movaps [r15+0x170], xmm1
00007d6f6a1cf4f1  movaps xmm15, [r15+0x110]
00007d6f6a1cf4f9  pextrq rax, xmm15, 0x01
00007d6f6a1cf500  movq xmm15, rax
00007d6f6a1cf505  pmovzxbw xmm15, xmm15
00007d6f6a1cf50b  psllw xmm15, 0x00
00007d6f6a1cf511  movaps [r15+0x180], xmm15
00007d6f6a1cf519  movaps xmm14, [r15+0x120]
00007d6f6a1cf521  pextrq rax, xmm14, 0x01
00007d6f6a1cf528  movq xmm14, rax
00007d6f6a1cf52d  pmovzxbw xmm14, xmm14
00007d6f6a1cf533  psllw xmm14, 0x00
00007d6f6a1cf539  movaps [r15+0x210], xmm14
00007d6f6a1cf541  movaps xmm13, [r15+0x130]
00007d6f6a1cf549  pextrq rax, xmm13, 0x01
00007d6f6a1cf550  movq xmm13, rax
00007d6f6a1cf555  pmovzxbw xmm13, xmm13
00007d6f6a1cf55b  psllw xmm13, 0x00
00007d6f6a1cf561  movaps [r15+0x220], xmm13
00007d6f6a1cf569  movq xmm12, qword ptr [r15+0x140]
00007d6f6a1cf572  pmovzxbw xmm12, xmm12
00007d6f6a1cf578  psllw xmm12, 0x00
00007d6f6a1cf57e  movaps [r15+0x250], xmm12
00007d6f6a1cf586  movaps xmm12, [r15+0x140]
00007d6f6a1cf58e  pextrq rax, xmm12, 0x01
00007d6f6a1cf595  movq xmm12, rax
00007d6f6a1cf59a  pmovzxbw xmm12, xmm12
00007d6f6a1cf5a0  psllw xmm12, 0x00
00007d6f6a1cf5a6  movaps [r15+0x110], xmm12
00007d6f6a1cf5ae  movq xmm11, qword ptr [r15+0x150]
00007d6f6a1cf5b7  pmovzxwd xmm11, xmm11
00007d6f6a1cf5bd  pslld xmm11, 0x10
00007d6f6a1cf5c3  movq xmm10, qword ptr [r15+0x160]
00007d6f6a1cf5cc  pmovzxwd xmm10, xmm10
00007d6f6a1cf5d2  pslld xmm10, 0x08
00007d6f6a1cf5d8  pextrq rax, xmm1, 0x01
00007d6f6a1cf5df  movq xmm1, rax
00007d6f6a1cf5e4  pmovzxwd xmm1, xmm1
00007d6f6a1cf5e9  pslld xmm1, 0x00
00007d6f6a1cf5ee  movaps [r15+0x260], xmm1
00007d6f6a1cf5f6  pextrq rax, xmm15, 0x01
00007d6f6a1cf5fd  movq xmm15, rax
00007d6f6a1cf602  pmovzxwd xmm15, xmm15
00007d6f6a1cf608  pslld xmm15, 0x00
00007d6f6a1cf60e  movaps [r15+0x270], xmm15
00007d6f6a1cf616  movq xmm9, qword ptr [r15+0x170]
00007d6f6a1cf61f  pmovzxwd xmm9, xmm9
00007d6f6a1cf625  pslld xmm9, 0x00
00007d6f6a1cf62b  pextrq rax, xmm14, 0x01
00007d6f6a1cf632  movq xmm14, rax
00007d6f6a1cf637  pmovzxwd xmm14, xmm14
00007d6f6a1cf63d  pslld xmm14, 0x10
00007d6f6a1cf643  movaps [r15+0x280], xmm14
00007d6f6a1cf64b  movq xmm8, qword ptr [r15+0x180]
00007d6f6a1cf654  pmovzxwd xmm8, xmm8
00007d6f6a1cf65a  pslld xmm8, 0x00
00007d6f6a1cf660  movq xmm7, qword ptr [r15+0x210]
00007d6f6a1cf669  pmovzxwd xmm7, xmm7
00007d6f6a1cf66e  pslld xmm7, 0x10
00007d6f6a1cf673  movaps xmm6, [r15+0x150]
00007d6f6a1cf67b  pextrq rax, xmm6, 0x01
00007d6f6a1cf682  movq xmm6, rax
00007d6f6a1cf687  pmovzxwd xmm6, xmm6
00007d6f6a1cf68c  pslld xmm6, 0x10
00007d6f6a1cf691  por xmm11, xmm10
00007d6f6a1cf696  movaps [r15+0x230], xmm11
00007d6f6a1cf69e  pextrq rax, xmm13, 0x01
00007d6f6a1cf6a5  movq xmm13, rax
00007d6f6a1cf6aa  pmovzxwd xmm13, xmm13
00007d6f6a1cf6b0  pslld xmm13, 0x08
00007d6f6a1cf6b6  movaps [r15+0x240], xmm13
00007d6f6a1cf6be  movq xmm10, qword ptr [r15+0x220]
00007d6f6a1cf6c7  pmovzxwd xmm10, xmm10
00007d6f6a1cf6cd  pslld xmm10, 0x08
00007d6f6a1cf6d3  movaps xmm5, [r15+0x160]
00007d6f6a1cf6db  pextrq rax, xmm5, 0x01
00007d6f6a1cf6e2  movq xmm5, rax
00007d6f6a1cf6e7  pmovzxwd xmm5, xmm5
00007d6f6a1cf6ec  pslld xmm5, 0x08
00007d6f6a1cf6f1  pslld xmm9, 0x18
00007d6f6a1cf6f7  pslld xmm15, 0x18
00007d6f6a1cf6fd  pslld xmm8, 0x18
00007d6f6a1cf703  movq xmm4, qword ptr [r15+0x250]
00007d6f6a1cf70c  pmovzxwd xmm4, xmm4
00007d6f6a1cf711  pslld xmm4, 0x00
00007d6f6a1cf716  por xmm14, xmm13
00007d6f6a1cf71b  por xmm7, xmm10
00007d6f6a1cf720  movaps [r15+0x210], xmm7
00007d6f6a1cf728  pslld xmm1, 0x18
00007d6f6a1cf72d  movaps [r15+0x220], xmm1
00007d6f6a1cf735  por xmm6, xmm5
00007d6f6a1cf739  por xmm11, xmm9
00007d6f6a1cf73e  movaps [r15+0x160], xmm11
00007d6f6a1cf746  pextrq rax, xmm12, 0x01
00007d6f6a1cf74d  movq xmm13, rax
00007d6f6a1cf752  pmovzxwd xmm13, xmm13
00007d6f6a1cf758  pslld xmm13, 0x00
00007d6f6a1cf75e  movaps [r15+0x170], xmm13
00007d6f6a1cf766  movq xmm12, qword ptr [r15+0x110]
00007d6f6a1cf76f  pmovzxwd xmm12, xmm12
00007d6f6a1cf775  pslld xmm12, 0x00
00007d6f6a1cf77b  por xmm14, xmm15
00007d6f6a1cf780  por xmm7, xmm8
00007d6f6a1cf785  movaps xmm15, [r15+0x250]
00007d6f6a1cf78d  pextrq rax, xmm15, 0x01
00007d6f6a1cf794  movq xmm15, rax
00007d6f6a1cf799  pmovzxwd xmm15, xmm15
00007d6f6a1cf79f  pslld xmm15, 0x00
00007d6f6a1cf7a5  movaps [r15+0x180], xmm15
00007d6f6a1cf7ad  por xmm6, xmm1
00007d6f6a1cf7b1  movaps [r15+0x150], xmm6
00007d6f6a1cf7b9  por xmm11, xmm4
00007d6f6a1cf7be  movaps [r15+0x140], xmm11
00007d6f6a1cf7c6  por xmm7, xmm12
00007d6f6a1cf7cb  movaps [r15+0x110], xmm7
00007d6f6a1cf7d3  por xmm14, xmm13
00007d6f6a1cf7d8  movaps [r15+0x120], xmm14
00007d6f6a1cf7e0  por xmm6, xmm15
00007d6f6a1cf7e5  movaps [r15+0x130], xmm6
00007d6f6a1cf7ed  mov rax, [r15+0xF8]
00007d6f6a1cf7f4  lea r14, [rax+0x20]
00007d6f6a1cf7f8  movups [r13+r14*1], xmm7
00007d6f6a1cf7fe  lea r14, [rax+0x30]
00007d6f6a1cf802  movups [r13+r14*1], xmm14
00007d6f6a1cf808  movups [r13+rax*1], xmm11
00007d6f6a1cf80e  lea r14, [rax+0x10]
00007d6f6a1cf812  movups [r13+r14*1], xmm6
00007d6f6a1cf818  mov r14d, [r13+rax*1]
00007d6f6a1cf81d  mov rax, [r15+0x48]
00007d6f6a1cf821  mov [r15+0x68], rax
00007d6f6a1cf825  mov qword ptr [r15+0x58], 0x04
00007d6f6a1cf82d  lea r12, [rax+0x04]
00007d6f6a1cf831  mov r11d, [r13+r12*1]
00007d6f6a1cf836  mov [rsp+0x10], r11d
00007d6f6a1cf83b  mov r11d, r11d
00007d6f6a1cf83e  mov [r15+0x70], r11
00007d6f6a1cf842  lea r12, [rax+0x38]
00007d6f6a1cf846  mov r11d, [r13+r12*1]
00007d6f6a1cf84b  lea r12, [rax+0x24]
00007d6f6a1cf84f  mov r10d, [r13+r12*1]
00007d6f6a1cf854  mov [rsp+0x20], r10d
00007d6f6a1cf859  mov r10d, r10d
00007d6f6a1cf85c  mov [r15+0x90], r10
00007d6f6a1cf863  mov [rsp+0x30], rax
00007d6f6a1cf868  xor eax, eax
00007d6f6a1cf86a  mov r12d, 0x04
00007d6f6a1cf870  mov r10d, 0xC0
00007d6f6a1cf876  cmp r12, r10
00007d6f6a1cf879  cmc
00007d6f6a1cf87a  lahf
00007d6f6a1cf87b  seto al
00007d6f6a1cf87e  mov [r15+0x108], eax
00007d6f6a1cf885  mov eax, [rsp+0x10]
00007d6f6a1cf889  mov r12d, [rsp+0x10]
00007d6f6a1cf88e  shrd eax, r12d, 0x07
00007d6f6a1cf893  mov [rsp+0x10], r11d
00007d6f6a1cf898  mov r10d, [rsp+0x10]
00007d6f6a1cf89d  shrd r11d, r10d, 0x11
00007d6f6a1cf8a2  mov r9d, [rsp+0x20]
00007d6f6a1cf8a7  lea r8d, [r9d+r14d*1]
00007d6f6a1cf8ac  rorx r14d, r12d, 0x12
00007d6f6a1cf8b2  xor eax, r14d
00007d6f6a1cf8b5  rorx r14d, r10d, 0x13
00007d6f6a1cf8bb  xor r11d, r14d
00007d6f6a1cf8be  mov [rsp+0x10], r11d
00007d6f6a1cf8c3  mov r11d, r11d
00007d6f6a1cf8c6  mov [r15+0x88], r11
00007d6f6a1cf8cd  mov [rsp+0x20], r12d
00007d6f6a1cf8d2  shr r12d, 0x03
00007d6f6a1cf8d6  xor eax, r12d
00007d6f6a1cf8d9  mov [rsp+0x40], eax
00007d6f6a1cf8dd  mov eax, eax
00007d6f6a1cf8df  mov [r15+0x80], rax
00007d6f6a1cf8e6  shr r10d, 0x0A
00007d6f6a1cf8ea  mov eax, [rsp+0x10]
00007d6f6a1cf8ee  xor eax, r10d
00007d6f6a1cf8f1  mov [rsp+0x10], eax
00007d6f6a1cf8f5  mov eax, eax
00007d6f6a1cf8f7  mov [r15+0x78], rax
00007d6f6a1cf8fb  mov eax, [rsp+0x40]
00007d6f6a1cf8ff  lea r14d, [r8d+eax*1]
00007d6f6a1cf904  mov eax, [rsp+0x10]
00007d6f6a1cf908  lea r12d, [r14d+eax*1]
00007d6f6a1cf90d  mov rax, [rsp+0x30]
00007d6f6a1cf912  lea r14, [rax+0x40]
00007d6f6a1cf916  mov [r13+r14*1], r12d
00007d6f6a1cf91b  mov eax, [rsp+0x20]
00007d6f6a1cf91f  mov eax, eax
00007d6f6a1cf921  mov [r15+0x60], rax
00007d6f6a1cf925  mov eax, [r15+0x108]
00007d6f6a1cf92c  sahf
00007d6f6a1cf92d  jnz 0x00007D6F6A1CF95F
00007d6f6a1cf92f  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cf937  jz 0x00007D6F6A1CFE20
00007d6f6a1cf93d  nop [rax+rax*1], ax
00007d6f6a1cf946  nop [rax+rax*1], eax
00007d6f6a1cf94e  mov eax, 0x41049C
00007d6f6a1cf953  mov [r15+0x100], rax
00007d6f6a1cf95a  jmp 0x00007D6F69FFE110
00007d6f6a1cf95f  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cf967  jz 0x00007D6F6A1CFC70
00007d6f6a1cf96d  nop [rax+rax*1], ax
00007d6f6a1cf976  nop [rax+rax*1], eax
00007d6f6a1cf97e  mov eax, 0x410454
00007d6f6a1cf983  mov [r15+0x100], rax
00007d6f6a1cf98a  jmp 0x00007D6F69FFE110
00007d6f6a1cf98f  int3
00007d6f6a1cf990  call 0x00007D6F6A00D860
00007d6f6a1cf995  jmp 0x00007D6F6A1CF02A
00007d6f6a1cf99a  call 0x00007D6F6A0E2420
00007d6f6a1cf99f  jmp 0x00007D6F6A1CF043
00007d6f6a1cf9a4  call 0x00007D6F6A0E2420
00007d6f6a1cf9a9  jmp 0x00007D6F6A1CF05C
00007d6f6a1cf9ae  call 0x00007D6F6A0E2420
00007d6f6a1cf9b3  jmp 0x00007D6F6A1CF075
00007d6f6a1cf9b8  call 0x00007D6F6A0E2420
00007d6f6a1cf9bd  jmp 0x00007D6F6A1CF08E
00007d6f6a1cf9c2  call 0x00007D6F6A0E2420
00007d6f6a1cf9c7  jmp 0x00007D6F6A1CF09F
00007d6f6a1cf9cc  call 0x00007D6F6A0E2420
00007d6f6a1cf9d1  jmp 0x00007D6F6A1CF0B0
00007d6f6a1cf9d6  call 0x00007D6F6A0E2420
00007d6f6a1cf9db  jmp 0x00007D6F6A1CF0C1
00007d6f6a1cf9e0  call 0x00007D6F6A0E2420
00007d6f6a1cf9e5  jmp 0x00007D6F6A1CF0D2
00007d6f6a1cf9ea  call 0x00007D6F6A0E2420
00007d6f6a1cf9ef  jmp 0x00007D6F6A1CF0E3
00007d6f6a1cf9f4  call 0x00007D6F6A0E2420
00007d6f6a1cf9f9  jmp 0x00007D6F6A1CF0F4
00007d6f6a1cf9fe  call 0x00007D6F6A0E2420
00007d6f6a1cfa03  jmp 0x00007D6F6A1CF105
00007d6f6a1cfa08  call 0x00007D6F6A0E2420
00007d6f6a1cfa0d  jmp 0x00007D6F6A1CF116
00007d6f6a1cfa12  call 0x00007D6F6A0E2420
00007d6f6a1cfa17  jmp 0x00007D6F6A1CF127
00007d6f6a1cfa1c  call 0x00007D6F6A0E2420
00007d6f6a1cfa21  jmp 0x00007D6F6A1CF138
00007d6f6a1cfa26  call 0x00007D6F6A0E2420
00007d6f6a1cfa2b  jmp 0x00007D6F6A1CF149
00007d6f6a1cfa30  call 0x00007D6F6A0E2420
00007d6f6a1cfa35  jmp 0x00007D6F6A1CF15A
00007d6f6a1cfa3a  call 0x00007D6F6A0E2420
00007d6f6a1cfa3f  jmp 0x00007D6F6A1CF16B
00007d6f6a1cfa44  call 0x00007D6F6A0E2420
00007d6f6a1cfa49  jmp 0x00007D6F6A1CF17C
00007d6f6a1cfa4e  call 0x00007D6F6A0E2420
00007d6f6a1cfa53  jmp 0x00007D6F6A1CF18D
00007d6f6a1cfa58  call 0x00007D6F6A0E2420
00007d6f6a1cfa5d  jmp 0x00007D6F6A1CF19E
00007d6f6a1cfa62  call 0x00007D6F6A0E2420
00007d6f6a1cfa67  jmp 0x00007D6F6A1CF1AF
00007d6f6a1cfa6c  call 0x00007D6F6A0E2420
00007d6f6a1cfa71  jmp 0x00007D6F6A1CF1C0
00007d6f6a1cfa76  call 0x00007D6F6A0E2420
00007d6f6a1cfa7b  jmp 0x00007D6F6A1CF1D1
00007d6f6a1cfa80  call 0x00007D6F6A0E2420
00007d6f6a1cfa85  jmp 0x00007D6F6A1CF1E2
00007d6f6a1cfa8a  call 0x00007D6F6A0E2420
00007d6f6a1cfa8f  jmp 0x00007D6F6A1CF1F3
00007d6f6a1cfa94  call 0x00007D6F6A0E2420
00007d6f6a1cfa99  jmp 0x00007D6F6A1CF204
00007d6f6a1cfa9e  call 0x00007D6F6A0E2420
00007d6f6a1cfaa3  jmp 0x00007D6F6A1CF215
00007d6f6a1cfaa8  call 0x00007D6F6A0E2420
00007d6f6a1cfaad  jmp 0x00007D6F6A1CF226
00007d6f6a1cfab2  call 0x00007D6F6A0E2420
00007d6f6a1cfab7  jmp 0x00007D6F6A1CF237
00007d6f6a1cfabc  call 0x00007D6F6A0E2420
00007d6f6a1cfac1  jmp 0x00007D6F6A1CF248
00007d6f6a1cfac6  call 0x00007D6F6A0E2420
00007d6f6a1cfacb  jmp 0x00007D6F6A1CF259
00007d6f6a1cfad0  call 0x00007D6F6A0E2420
00007d6f6a1cfad5  jmp 0x00007D6F6A1CF26A
00007d6f6a1cfada  call 0x00007D6F6A0E2420
00007d6f6a1cfadf  jmp 0x00007D6F6A1CF27B
00007d6f6a1cfae4  call 0x00007D6F6A0E2420
00007d6f6a1cfae9  jmp 0x00007D6F6A1CF28C
00007d6f6a1cfaee  call 0x00007D6F6A0E2420
00007d6f6a1cfaf3  jmp 0x00007D6F6A1CF29D
00007d6f6a1cfaf8  call 0x00007D6F6A0E2420
00007d6f6a1cfafd  jmp 0x00007D6F6A1CF2AE
00007d6f6a1cfb02  call 0x00007D6F6A0E2420
00007d6f6a1cfb07  jmp 0x00007D6F6A1CF2BF
00007d6f6a1cfb0c  call 0x00007D6F6A0E2420
00007d6f6a1cfb11  jmp 0x00007D6F6A1CF2D0
00007d6f6a1cfb16  call 0x00007D6F6A0E2420
00007d6f6a1cfb1b  jmp 0x00007D6F6A1CF2E1
00007d6f6a1cfb20  call 0x00007D6F6A0E2420
00007d6f6a1cfb25  jmp 0x00007D6F6A1CF2F2
00007d6f6a1cfb2a  call 0x00007D6F6A0E2420
00007d6f6a1cfb2f  jmp 0x00007D6F6A1CF303
00007d6f6a1cfb34  call 0x00007D6F6A0E2420
00007d6f6a1cfb39  jmp 0x00007D6F6A1CF314
00007d6f6a1cfb3e  call 0x00007D6F6A0E2420
00007d6f6a1cfb43  jmp 0x00007D6F6A1CF325
00007d6f6a1cfb48  call 0x00007D6F6A0E2420
00007d6f6a1cfb4d  jmp 0x00007D6F6A1CF336
00007d6f6a1cfb52  call 0x00007D6F6A0E2420
00007d6f6a1cfb57  jmp 0x00007D6F6A1CF347
00007d6f6a1cfb5c  call 0x00007D6F6A0E2420
00007d6f6a1cfb61  jmp 0x00007D6F6A1CF358
00007d6f6a1cfb66  call 0x00007D6F6A0E2420
00007d6f6a1cfb6b  jmp 0x00007D6F6A1CF369
00007d6f6a1cfb70  call 0x00007D6F6A0E2420
00007d6f6a1cfb75  jmp 0x00007D6F6A1CF37A
00007d6f6a1cfb7a  call 0x00007D6F6A0E2420
00007d6f6a1cfb7f  jmp 0x00007D6F6A1CF38B
00007d6f6a1cfb84  call 0x00007D6F6A0E2420
00007d6f6a1cfb89  jmp 0x00007D6F6A1CF39C
00007d6f6a1cfb8e  call 0x00007D6F6A0E2420
00007d6f6a1cfb93  jmp 0x00007D6F6A1CF3AD
00007d6f6a1cfb98  call 0x00007D6F6A0E2420
00007d6f6a1cfb9d  jmp 0x00007D6F6A1CF3BE
00007d6f6a1cfba2  call 0x00007D6F6A0E2420
00007d6f6a1cfba7  jmp 0x00007D6F6A1CF3CF
00007d6f6a1cfbac  call 0x00007D6F6A0E2420
00007d6f6a1cfbb1  jmp 0x00007D6F6A1CF3E0
00007d6f6a1cfbb6  call 0x00007D6F6A0E2420
00007d6f6a1cfbbb  jmp 0x00007D6F6A1CF3F1
00007d6f6a1cfbc0  call 0x00007D6F6A0E2420
00007d6f6a1cfbc5  jmp 0x00007D6F6A1CF402
00007d6f6a1cfbca  call 0x00007D6F6A0E2420
00007d6f6a1cfbcf  jmp 0x00007D6F6A1CF413
00007d6f6a1cfbd4  call 0x00007D6F6A0E2420
00007d6f6a1cfbd9  jmp 0x00007D6F6A1CF424
00007d6f6a1cfbde  call 0x00007D6F6A0E2420
00007d6f6a1cfbe3  jmp 0x00007D6F6A1CF435
00007d6f6a1cfbe8  call 0x00007D6F6A0E2420
00007d6f6a1cfbed  jmp 0x00007D6F6A1CF446
00007d6f6a1cfbf2  call 0x00007D6F6A0E2420
00007d6f6a1cfbf7  jmp 0x00007D6F6A1CF45F
00007d6f6a1cfbfc  call 0x00007D6F6A0E2420
00007d6f6a1cfc01  jmp 0x00007D6F6A1CF478
00007d6f6a1cfc06  call 0x00007D6F6A0D5610
00007d6f6a1cfc0b  jmp 0x00007D6F6A1CF491
00007d6f6a1cfc10  call 0x00007D6F6A0DC580
00007d6f6a1cfc15  jmp 0x00007D6F6A1CF7FE
00007d6f6a1cfc1a  call 0x00007D6F6A0E46C0
00007d6f6a1cfc1f  jmp 0x00007D6F6A1CF808
00007d6f6a1cfc24  call 0x00007D6F6A009E90
00007d6f6a1cfc29  jmp 0x00007D6F6A1CF80E
00007d6f6a1cfc2e  call 0x00007D6F6A0DB310
00007d6f6a1cfc33  jmp 0x00007D6F6A1CF818
00007d6f6a1cfc38  call 0x00007D6F6A00DAE0
00007d6f6a1cfc3d  jmp 0x00007D6F6A1CF81D
00007d6f6a1cfc42  call 0x00007D6F6A0C0230
00007d6f6a1cfc47  jmp 0x00007D6F6A1CF836
00007d6f6a1cfc4c  call 0x00007D6F6A0C0230
00007d6f6a1cfc51  jmp 0x00007D6F6A1CF84B
00007d6f6a1cfc56  call 0x00007D6F6A0BEFC0
00007d6f6a1cfc5b  jmp 0x00007D6F6A1CF854
00007d6f6a1cfc60  call 0x00007D6F6A0E2BA0
00007d6f6a1cfc65  jmp 0x00007D6F6A1CF91B
00007d6f6a1cfc6a  int3
00007d6f6a1cfc6b  nop [rax+rax*1], eax
00007d6f6a1cfc70  mov rax, [r15+0x48]
00007d6f6a1cfc74  mov r14, [r15+0x58]
00007d6f6a1cfc78  lea r12, [rax+r14*1]
00007d6f6a1cfc7c  mov [r15+0x68], r12
00007d6f6a1cfc80  lea rax, [r14+0x04]
00007d6f6a1cfc84  mov [r15+0x58], rax
00007d6f6a1cfc88  lea r14, [r12+0x04]
00007d6f6a1cfc8d  mov r11d, [r13+r14*1]
00007d6f6a1cfc92  mov [rsp+0x10], r11d
00007d6f6a1cfc97  mov r11d, r11d
00007d6f6a1cfc9a  mov [r15+0x70], r11
00007d6f6a1cfc9e  lea r14, [r12+0x38]
00007d6f6a1cfca3  mov r11d, [r13+r14*1]
00007d6f6a1cfca8  lea r14, [r12+0x24]
00007d6f6a1cfcad  mov r10d, [r13+r14*1]
00007d6f6a1cfcb2  mov [rsp+0x20], r10d
00007d6f6a1cfcb7  mov r10d, r10d
00007d6f6a1cfcba  mov [r15+0x90], r10
00007d6f6a1cfcc1  mov [rsp+0x30], rax
00007d6f6a1cfcc6  xor eax, eax
00007d6f6a1cfcc8  mov r14, [rsp+0x30]
00007d6f6a1cfccd  mov r10d, 0xC0
00007d6f6a1cfcd3  cmp r14, r10
00007d6f6a1cfcd6  cmc
00007d6f6a1cfcd7  lahf
00007d6f6a1cfcd8  seto al
00007d6f6a1cfcdb  mov [r15+0x108], eax
00007d6f6a1cfce2  mov eax, [rsp+0x10]
00007d6f6a1cfce6  mov r14d, [rsp+0x10]
00007d6f6a1cfceb  shrd eax, r14d, 0x07
00007d6f6a1cfcf0  mov [rsp+0x10], r11d
00007d6f6a1cfcf5  mov r10d, [rsp+0x10]
00007d6f6a1cfcfa  shrd r11d, r10d, 0x11
00007d6f6a1cfcff  mov r9d, [r15+0x60]
00007d6f6a1cfd03  mov r8d, [rsp+0x20]
00007d6f6a1cfd08  lea ebp, [r8d+r9d*1]
00007d6f6a1cfd0d  rorx r9d, r14d, 0x12
00007d6f6a1cfd13  xor eax, r9d
00007d6f6a1cfd16  rorx r9d, r10d, 0x13
00007d6f6a1cfd1c  xor r11d, r9d
00007d6f6a1cfd1f  mov [rsp+0x10], r11d
00007d6f6a1cfd24  mov r11d, r11d
00007d6f6a1cfd27  mov [r15+0x88], r11
00007d6f6a1cfd2e  mov [rsp+0x20], r14d
00007d6f6a1cfd33  shr r14d, 0x03
00007d6f6a1cfd37  xor eax, r14d
00007d6f6a1cfd3a  mov [rsp+0x30], eax
00007d6f6a1cfd3e  mov eax, eax
00007d6f6a1cfd40  mov [r15+0x80], rax
00007d6f6a1cfd47  shr r10d, 0x0A
00007d6f6a1cfd4b  mov eax, [rsp+0x10]
00007d6f6a1cfd4f  xor eax, r10d
00007d6f6a1cfd52  mov [rsp+0x10], eax
00007d6f6a1cfd56  mov eax, eax
00007d6f6a1cfd58  mov [r15+0x78], rax
00007d6f6a1cfd5c  mov eax, [rsp+0x30]
00007d6f6a1cfd60  lea r14d, [ebp+eax*1]
00007d6f6a1cfd66  mov eax, [rsp+0x10]
00007d6f6a1cfd6a  lea r11d, [r14d+eax*1]
00007d6f6a1cfd6f  lea rax, [r12+0x40]
00007d6f6a1cfd74  mov [r13+rax*1], r11d
00007d6f6a1cfd79  mov eax, [rsp+0x20]
00007d6f6a1cfd7d  mov eax, eax
00007d6f6a1cfd7f  mov [r15+0x60], rax
00007d6f6a1cfd83  mov eax, [r15+0x108]
00007d6f6a1cfd8a  sahf
00007d6f6a1cfd8b  jnz 0x00007D6F6A1CFDBD
00007d6f6a1cfd8d  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cfd95  jz 0x00007D6F6A1CFE20
00007d6f6a1cfd9b  nop [rax+rax*1], ax
00007d6f6a1cfda4  nop [rax+rax*1], eax
00007d6f6a1cfdac  mov eax, 0x41049C
00007d6f6a1cfdb1  mov [r15+0x100], rax
00007d6f6a1cfdb8  jmp 0x00007D6F69FFE110
00007d6f6a1cfdbd  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1cfdc5  jz 0x00007D6F6A1CFC70
00007d6f6a1cfdcb  nop [rax+rax*1], ax
00007d6f6a1cfdd4  nop [rax+rax*1], eax
00007d6f6a1cfddc  mov eax, 0x410454
00007d6f6a1cfde1  mov [r15+0x100], rax
00007d6f6a1cfde8  jmp 0x00007D6F69FFE110
00007d6f6a1cfded  int3
00007d6f6a1cfdee  call 0x00007D6F6A0E1430
00007d6f6a1cfdf3  jmp 0x00007D6F6A1CFC92
00007d6f6a1cfdf8  call 0x00007D6F6A0E1430
00007d6f6a1cfdfd  jmp 0x00007D6F6A1CFCA8
00007d6f6a1cfe02  call 0x00007D6F6A0E01C0
00007d6f6a1cfe07  jmp 0x00007D6F6A1CFCB2
00007d6f6a1cfe0c  call 0x00007D6F6A00A860
00007d6f6a1cfe11  jmp 0x00007D6F6A1CFD79
00007d6f6a1cfe16  int3
00007d6f6a1cfe17  nop [rax+rax*1], ax
00007d6f6a1cfe20  mov rax, [r15]
00007d6f6a1cfe23  mov r14d, [r13+rax*1]
00007d6f6a1cfe28  lea r12, [rax+0x04]
00007d6f6a1cfe2c  mov r11d, [r13+r12*1]
00007d6f6a1cfe31  mov [rsp+0x10], r14d
00007d6f6a1cfe36  mov r14d, r14d
00007d6f6a1cfe39  mov [r15+0x78], r14
00007d6f6a1cfe3d  mov [rsp+0x20], r11d
00007d6f6a1cfe42  mov r11d, r11d
00007d6f6a1cfe45  mov [r15+0x80], r11
00007d6f6a1cfe4c  lea r14, [rax+0x08]
00007d6f6a1cfe50  mov r12d, [r13+r14*1]
00007d6f6a1cfe55  lea r14, [rax+0x0C]
00007d6f6a1cfe59  mov r11d, [r13+r14*1]
00007d6f6a1cfe5e  mov [rsp+0x30], r12d
00007d6f6a1cfe63  mov r12d, r12d
00007d6f6a1cfe66  mov [r15+0x70], r12
00007d6f6a1cfe6a  mov [rsp+0x40], r11d
00007d6f6a1cfe6f  mov r11d, r11d
00007d6f6a1cfe72  mov [r15+0x68], r11
00007d6f6a1cfe76  lea r14, [rax+0x18]
00007d6f6a1cfe7a  mov r12d, [r13+r14*1]
00007d6f6a1cfe7f  lea r14, [rax+0x1C]
00007d6f6a1cfe83  mov r11d, [r13+r14*1]
00007d6f6a1cfe88  mov [rsp+0x50], r12d
00007d6f6a1cfe8d  mov r12d, r12d
00007d6f6a1cfe90  mov [r15+0x58], r12
00007d6f6a1cfe94  mov [rsp+0x60], r11d
00007d6f6a1cfe99  mov r11d, r11d
00007d6f6a1cfe9c  mov [r15+0x60], r11
00007d6f6a1cfea0  lea r14, [rax+0x10]
00007d6f6a1cfea4  mov r12d, [r13+r14*1]
00007d6f6a1cfea9  lea r14, [rax+0x14]
00007d6f6a1cfead  mov eax, [r13+r14*1]
00007d6f6a1cfeb2  mov [rsp+0x70], r12d
00007d6f6a1cfeb7  mov r12d, r12d
00007d6f6a1cfeba  mov [r15+0x18], r12
00007d6f6a1cfebe  mov [rsp+0x80], eax
00007d6f6a1cfec5  mov eax, eax
00007d6f6a1cfec7  mov [r15+0x90], rax
00007d6f6a1cfece  mov eax, [rsp+0x70]
00007d6f6a1cfed2  mov eax, eax
00007d6f6a1cfed4  mov [r15+0x30], rax
00007d6f6a1cfed8  mov eax, [rsp+0x50]
00007d6f6a1cfedc  mov eax, eax
00007d6f6a1cfede  mov [r15+0xA0], rax
00007d6f6a1cfee5  mov eax, [rsp+0x30]
00007d6f6a1cfee9  mov eax, eax
00007d6f6a1cfeeb  mov [r15+0x28], rax
00007d6f6a1cfeef  mov eax, [rsp+0x20]
00007d6f6a1cfef3  mov eax, eax
00007d6f6a1cfef5  mov [r15+0x98], rax
00007d6f6a1cfefc  mov eax, [rsp+0x10]
00007d6f6a1cff00  mov eax, eax
00007d6f6a1cff02  mov [r15+0x38], rax
00007d6f6a1cff06  mov eax, [rsp+0x70]
00007d6f6a1cff0a  mov r14d, [rsp+0x70]
00007d6f6a1cff0f  shrd eax, r14d, 0x06
00007d6f6a1cff14  mov [rsp+0x70], r14d
00007d6f6a1cff19  mov r12d, [rsp+0x80]
00007d6f6a1cff21  and r14d, r12d
00007d6f6a1cff24  mov r11d, [rsp+0x10]
00007d6f6a1cff29  mov r10d, [rsp+0x10]
00007d6f6a1cff2e  shrd r11d, r10d, 0x02
00007d6f6a1cff33  mov [rsp+0x10], r12d
00007d6f6a1cff38  mov r12d, r12d
00007d6f6a1cff3b  mov [r15+0x20], r12
00007d6f6a1cff3f  mov r12, [r15+0x50]
00007d6f6a1cff43  mov r9d, [r13+r12*1]
00007d6f6a1cff48  mov r12d, [rsp+0x50]
00007d6f6a1cff4d  mov r8d, [rsp+0x70]
00007d6f6a1cff52  andn ebp, r8d, r12d
00007d6f6a1cff57  mov edi, [rsp+0x60]
00007d6f6a1cff5b  lea esi, [r14d+edi*1]
00007d6f6a1cff60  rorx r14d, r8d, 0x0B
00007d6f6a1cff66  xor eax, r14d
00007d6f6a1cff69  rorx r14d, r10d, 0x0D
00007d6f6a1cff6f  xor r11d, r14d
00007d6f6a1cff72  lea edi, [esi+ebp*1]
00007d6f6a1cff76  mov r14, [r15+0x48]
00007d6f6a1cff7a  mov ebp, [r13+r14*1]
00007d6f6a1cff7f  mov r14d, [rsp+0x30]
00007d6f6a1cff84  mov esi, [rsp+0x20]
00007d6f6a1cff88  and r14d, esi
00007d6f6a1cff8b  mov [rsp+0x20], r14d
00007d6f6a1cff90  mov r14d, r14d
00007d6f6a1cff93  mov [r15+0xD8], r14
00007d6f6a1cff9a  lea r14d, [edi+r9d*1]
00007d6f6a1cff9f  mov r9d, [rsp+0x30]
00007d6f6a1cffa4  xor r9d, esi
00007d6f6a1cffa7  rorx edi, r8d, 0x19
00007d6f6a1cffad  xor eax, edi
00007d6f6a1cffaf  and r9d, r10d
00007d6f6a1cffb2  rorx edi, r10d, 0x16
00007d6f6a1cffb8  xor r11d, edi
00007d6f6a1cffbb  mov [rsp+0x30], r11d
00007d6f6a1cffc0  mov r11d, r11d
00007d6f6a1cffc3  mov [r15+0xD0], r11
00007d6f6a1cffca  lea r11d, [r14d+ebp*1]
00007d6f6a1cffcf  mov r10d, [rsp+0x20]
00007d6f6a1cffd4  xor r9d, r10d
00007d6f6a1cffd7  lea r14d, [r11d+eax*1]
00007d6f6a1cffdc  mov qword ptr [r15+0x88], 0x04
00007d6f6a1cffe7  mov eax, [rsp+0x30]
00007d6f6a1cffeb  lea r11d, [r9d+eax*1]
00007d6f6a1cfff0  mov eax, [rsp+0x40]
00007d6f6a1cfff4  lea r10d, [r14d+eax*1]
00007d6f6a1cfff9  mov r10d, r10d
00007d6f6a1cfffc  mov [r15+0xB8], r10
00007d6f6a1d0003  xor eax, eax
00007d6f6a1d0005  mov r10d, 0x04
00007d6f6a1d000b  mov r9d, 0x100
00007d6f6a1d0011  cmp r10, r9
00007d6f6a1d0014  cmc
00007d6f6a1d0015  lahf
00007d6f6a1d0016  seto al
00007d6f6a1d0019  mov [r15+0x108], eax
00007d6f6a1d0020  lea eax, [r11d+r14d*1]
00007d6f6a1d0025  mov eax, eax
00007d6f6a1d0027  mov [r15+0xA8], rax
00007d6f6a1d002e  mov r12d, r12d
00007d6f6a1d0031  mov [r15+0xB0], r12
00007d6f6a1d0038  mov eax, [rsp+0x10]
00007d6f6a1d003c  mov eax, eax
00007d6f6a1d003e  mov [r15+0xC0], rax
00007d6f6a1d0045  mov r8d, r8d
00007d6f6a1d0048  mov [r15+0xC8], r8
00007d6f6a1d004f  mov eax, [r15+0x108]
00007d6f6a1d0056  sahf
00007d6f6a1d0057  jnz 0x00007D6F6A1D0089
00007d6f6a1d0059  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0061  jz 0x00007D6F6A1D0350
00007d6f6a1d0067  nop [rax+rax*1], ax
00007d6f6a1d0070  nop [rax+rax*1], eax
00007d6f6a1d0078  mov eax, 0x41055C
00007d6f6a1d007d  mov [r15+0x100], rax
00007d6f6a1d0084  jmp 0x00007D6F69FFE110
00007d6f6a1d0089  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0091  jz 0x00007D6F6A1D0120
00007d6f6a1d0097  nop [rax+rax*1], ax
00007d6f6a1d00a0  nop [rax+rax*1], eax
00007d6f6a1d00a8  mov eax, 0x4104D0
00007d6f6a1d00ad  mov [r15+0x100], rax
00007d6f6a1d00b4  jmp 0x00007D6F69FFE110
00007d6f6a1d00b9  int3
00007d6f6a1d00ba  call 0x00007D6F6A00DAE0
00007d6f6a1d00bf  jmp 0x00007D6F6A1CFE28
00007d6f6a1d00c4  call 0x00007D6F6A0C0230
00007d6f6a1d00c9  jmp 0x00007D6F6A1CFE31
00007d6f6a1d00ce  call 0x00007D6F6A0E26A0
00007d6f6a1d00d3  jmp 0x00007D6F6A1CFE55
00007d6f6a1d00d8  call 0x00007D6F6A0E1430
00007d6f6a1d00dd  jmp 0x00007D6F6A1CFE5E
00007d6f6a1d00e2  call 0x00007D6F6A0E26A0
00007d6f6a1d00e7  jmp 0x00007D6F6A1CFE7F
00007d6f6a1d00ec  call 0x00007D6F6A0E1430
00007d6f6a1d00f1  jmp 0x00007D6F6A1CFE88
00007d6f6a1d00f6  call 0x00007D6F6A0E26A0
00007d6f6a1d00fb  jmp 0x00007D6F6A1CFEA9
00007d6f6a1d0100  call 0x00007D6F6A0D5890
00007d6f6a1d0105  jmp 0x00007D6F6A1CFEB2
00007d6f6a1d010a  call 0x00007D6F6A0BDD50
00007d6f6a1d010f  jmp 0x00007D6F6A1CFF48
00007d6f6a1d0114  call 0x00007D6F6A0DA580
00007d6f6a1d0119  jmp 0x00007D6F6A1CFF7F
00007d6f6a1d011e  int3
00007d6f6a1d011f  nop
00007d6f6a1d0120  mov eax, [r15+0xB8]
00007d6f6a1d0127  mov [rsp+0x10], eax
00007d6f6a1d012b  mov eax, eax
00007d6f6a1d012d  mov [r15+0x30], rax
00007d6f6a1d0131  mov eax, [r15+0xC0]
00007d6f6a1d0138  mov [rsp+0x20], eax
00007d6f6a1d013c  mov eax, eax
00007d6f6a1d013e  mov [r15+0xA0], rax
00007d6f6a1d0145  mov eax, [r15+0x28]
00007d6f6a1d0149  mov r14d, [r15+0x98]
00007d6f6a1d0150  mov [rsp+0x30], r14d
00007d6f6a1d0155  mov r14d, r14d
00007d6f6a1d0158  mov [r15+0x28], r14
00007d6f6a1d015c  mov r14d, [r15+0x38]
00007d6f6a1d0160  mov [rsp+0x40], r14d
00007d6f6a1d0165  mov r14d, r14d
00007d6f6a1d0168  mov [r15+0x98], r14
00007d6f6a1d016f  mov r14d, [r15+0xA8]
00007d6f6a1d0176  mov [rsp+0x50], r14d
00007d6f6a1d017b  mov r14d, r14d
00007d6f6a1d017e  mov [r15+0x38], r14
00007d6f6a1d0182  mov r14d, [rsp+0x10]
00007d6f6a1d0187  mov r12d, [rsp+0x10]
00007d6f6a1d018c  shrd r14d, r12d, 0x06
00007d6f6a1d0191  mov r11d, [r15+0xC8]
00007d6f6a1d0198  mov [rsp+0x10], r12d
00007d6f6a1d019d  and r12d, r11d
00007d6f6a1d01a0  mov r10d, [rsp+0x50]
00007d6f6a1d01a5  mov r9d, [rsp+0x50]
00007d6f6a1d01aa  shrd r10d, r9d, 0x02
00007d6f6a1d01af  mov [rsp+0x50], r11d
00007d6f6a1d01b4  mov r11d, r11d
00007d6f6a1d01b7  mov [r15+0x20], r11
00007d6f6a1d01bb  mov r11, [r15+0x88]
00007d6f6a1d01c2  mov r8, [r15+0x50]
00007d6f6a1d01c6  lea rbp, [r8+r11*1]
00007d6f6a1d01ca  mov r8d, [r13+rbp*1]
00007d6f6a1d01cf  mov ebp, [rsp+0x20]
00007d6f6a1d01d3  mov edi, [rsp+0x10]
00007d6f6a1d01d7  andn esi, edi, ebp
00007d6f6a1d01dc  mov edx, [r15+0xB0]
00007d6f6a1d01e3  lea ecx, [r12d+edx*1]
00007d6f6a1d01e8  rorx r12d, edi, 0x0B
00007d6f6a1d01ee  xor r14d, r12d
00007d6f6a1d01f1  rorx r12d, r9d, 0x0D
00007d6f6a1d01f7  xor r10d, r12d
00007d6f6a1d01fa  lea r12d, [ecx+esi*1]
00007d6f6a1d01ff  mov rsi, [r15+0x48]
00007d6f6a1d0203  lea rdx, [rsi+r11*1]
00007d6f6a1d0207  mov esi, [r13+rdx*1]
00007d6f6a1d020c  mov edx, [rsp+0x30]
00007d6f6a1d0210  mov ecx, [rsp+0x40]
00007d6f6a1d0214  and edx, ecx
00007d6f6a1d0216  mov [rsp+0x10], edx
00007d6f6a1d021a  mov edx, edx
00007d6f6a1d021c  mov [r15+0xD8], rdx
00007d6f6a1d0223  lea edx, [r12d+r8d*1]
00007d6f6a1d0228  mov r12d, [rsp+0x30]
00007d6f6a1d022d  xor r12d, ecx
00007d6f6a1d0230  rorx r8d, edi, 0x19
00007d6f6a1d0236  xor r14d, r8d
00007d6f6a1d0239  and r12d, r9d
00007d6f6a1d023c  rorx r8d, r9d, 0x16
00007d6f6a1d0242  xor r10d, r8d
00007d6f6a1d0245  mov [rsp+0x20], r10d
00007d6f6a1d024a  mov r10d, r10d
00007d6f6a1d024d  mov [r15+0xD0], r10
00007d6f6a1d0254  lea r10d, [edx+esi*1]
00007d6f6a1d0259  mov r9d, [rsp+0x10]
00007d6f6a1d025e  xor r12d, r9d
00007d6f6a1d0261  lea r9d, [r10d+r14d*1]
00007d6f6a1d0266  lea r14, [r11+0x04]
00007d6f6a1d026a  mov [r15+0x88], r14
00007d6f6a1d0271  mov r11d, [rsp+0x20]
00007d6f6a1d0276  lea r10d, [r12d+r11d*1]
00007d6f6a1d027b  lea r11d, [r9d+eax*1]
00007d6f6a1d0280  mov r11d, r11d
00007d6f6a1d0283  mov [r15+0xB8], r11
00007d6f6a1d028a  xor eax, eax
00007d6f6a1d028c  mov r12d, 0x100
00007d6f6a1d0292  cmp r14, r12
00007d6f6a1d0295  cmc
00007d6f6a1d0296  lahf
00007d6f6a1d0297  seto al
00007d6f6a1d029a  mov [r15+0x108], eax
00007d6f6a1d02a1  lea eax, [r10d+r9d*1]
00007d6f6a1d02a6  mov eax, eax
00007d6f6a1d02a8  mov [r15+0xA8], rax
00007d6f6a1d02af  mov ebp, ebp
00007d6f6a1d02b1  mov [r15+0xB0], rbp
00007d6f6a1d02b8  mov eax, [rsp+0x50]
00007d6f6a1d02bc  mov eax, eax
00007d6f6a1d02be  mov [r15+0xC0], rax
00007d6f6a1d02c5  mov edi, edi
00007d6f6a1d02c7  mov [r15+0xC8], rdi
00007d6f6a1d02ce  mov eax, [r15+0x108]
00007d6f6a1d02d5  sahf
00007d6f6a1d02d6  jnz 0x00007D6F6A1D0308
00007d6f6a1d02d8  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d02e0  jz 0x00007D6F6A1D0350
00007d6f6a1d02e6  nop [rax+rax*1], ax
00007d6f6a1d02ef  nop [rax+rax*1], eax
00007d6f6a1d02f7  mov eax, 0x41055C
00007d6f6a1d02fc  mov [r15+0x100], rax
00007d6f6a1d0303  jmp 0x00007D6F69FFE110
00007d6f6a1d0308  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0310  jz 0x00007D6F6A1D0120
00007d6f6a1d0316  nop [rax+rax*1], ax
00007d6f6a1d031f  nop [rax+rax*1], eax
00007d6f6a1d0327  mov eax, 0x4104D0
00007d6f6a1d032c  mov [r15+0x100], rax
00007d6f6a1d0333  jmp 0x00007D6F69FFE110
00007d6f6a1d0338  int3
00007d6f6a1d0339  call 0x00007D6F6A049010
00007d6f6a1d033e  jmp 0x00007D6F6A1D01CF
00007d6f6a1d0343  call 0x00007D6F6A025930
00007d6f6a1d0348  jmp 0x00007D6F6A1D020C
00007d6f6a1d034d  int3
00007d6f6a1d034e  nop
00007d6f6a1d0350  mov eax, [r15+0x98]
00007d6f6a1d0357  mov r14d, [r15+0x70]
00007d6f6a1d035b  lea r12d, [eax+r14d*1]
00007d6f6a1d0360  mov eax, [r15+0x28]
00007d6f6a1d0364  mov r14d, [r15+0x68]
00007d6f6a1d0368  lea r11d, [eax+r14d*1]
00007d6f6a1d036d  mov qword ptr [r15+0x88], 0x00
00007d6f6a1d0378  mov eax, [r15+0xA8]
00007d6f6a1d037f  mov r14d, [r15+0x78]
00007d6f6a1d0383  lea r10d, [eax+r14d*1]
00007d6f6a1d0388  mov [rsp+0x10], r10d
00007d6f6a1d038d  mov r10d, r10d
00007d6f6a1d0390  mov [r15+0x78], r10
00007d6f6a1d0394  mov eax, [r15+0x38]
00007d6f6a1d0398  mov r14d, [r15+0x80]
00007d6f6a1d039f  lea r10d, [eax+r14d*1]
00007d6f6a1d03a4  mov [rsp+0x20], r10d
00007d6f6a1d03a9  mov r10d, r10d
00007d6f6a1d03ac  mov [r15+0x80], r10
00007d6f6a1d03b3  mov rax, [r15]
00007d6f6a1d03b6  lea r14, [rax+0x08]
00007d6f6a1d03ba  mov [r13+r14*1], r12d
00007d6f6a1d03bf  lea r14, [rax+0x0C]
00007d6f6a1d03c3  mov [r13+r14*1], r11d
00007d6f6a1d03c8  mov r14d, [r15+0xB8]
00007d6f6a1d03cf  mov r12d, [r15+0x18]
00007d6f6a1d03d3  lea r11d, [r14d+r12d*1]
00007d6f6a1d03d8  mov [rsp+0x30], r11d
00007d6f6a1d03dd  mov r11d, r11d
00007d6f6a1d03e0  mov [r15+0x68], r11
00007d6f6a1d03e4  mov r14d, [r15+0x30]
00007d6f6a1d03e8  mov r12d, [r15+0x90]
00007d6f6a1d03ef  lea r11d, [r14d+r12d*1]
00007d6f6a1d03f4  mov [rsp+0x40], r11d
00007d6f6a1d03f9  mov r11d, r11d
00007d6f6a1d03fc  mov [r15+0x70], r11
00007d6f6a1d0400  mov r14d, [r15+0x20]
00007d6f6a1d0404  mov r12d, [r15+0x58]
00007d6f6a1d0408  lea r11d, [r14d+r12d*1]
00007d6f6a1d040d  mov [rsp+0x50], r11d
00007d6f6a1d0412  mov r11d, r11d
00007d6f6a1d0415  mov [r15+0x58], r11
00007d6f6a1d0419  mov r14d, [r15+0xA0]
00007d6f6a1d0420  mov r12d, [r15+0x60]
00007d6f6a1d0424  lea r11d, [r14d+r12d*1]
00007d6f6a1d0429  mov [rsp+0x60], r11d
00007d6f6a1d042e  mov r11d, r11d
00007d6f6a1d0431  mov [r15+0x60], r11
00007d6f6a1d0435  mov r14d, [rsp+0x10]
00007d6f6a1d043a  mov [r13+rax*1], r14d
00007d6f6a1d043f  lea r14, [rax+0x04]
00007d6f6a1d0443  mov r12d, [rsp+0x20]
00007d6f6a1d0448  mov [r13+r14*1], r12d
00007d6f6a1d044d  lea r14, [rax+0x10]
00007d6f6a1d0451  mov r12d, [rsp+0x30]
00007d6f6a1d0456  mov [r13+r14*1], r12d
00007d6f6a1d045b  lea r14, [rax+0x14]
00007d6f6a1d045f  mov r12d, [rsp+0x40]
00007d6f6a1d0464  mov [r13+r14*1], r12d
00007d6f6a1d0469  lea r14, [rax+0x18]
00007d6f6a1d046d  mov r12d, [rsp+0x50]
00007d6f6a1d0472  mov [r13+r14*1], r12d
00007d6f6a1d0477  lea r14, [rax+0x1C]
00007d6f6a1d047b  mov r12d, [rsp+0x60]
00007d6f6a1d0480  mov [r13+r14*1], r12d
00007d6f6a1d0485  lea r14, [rax+0x68]
00007d6f6a1d0489  xor eax, eax
00007d6f6a1d048b  mov [r13+r14*1], rax
00007d6f6a1d0490  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0498  jz 0x00007D6F6A1CEF90
00007d6f6a1d049e  nop [rax+rax*1], ax
00007d6f6a1d04a7  nop [rax+rax*1], eax
00007d6f6a1d04af  mov eax, 0x410378
00007d6f6a1d04b4  mov [r15+0x100], rax
00007d6f6a1d04bb  jmp 0x00007D6F69FFE110
00007d6f6a1d04c0  int3
00007d6f6a1d04c1  call 0x00007D6F6A0E2BA0
00007d6f6a1d04c6  jmp 0x00007D6F6A1D03BF
00007d6f6a1d04cb  call 0x00007D6F6A0E1920
00007d6f6a1d04d0  jmp 0x00007D6F6A1D03C8
00007d6f6a1d04d5  call 0x00007D6F6A00DFE0
00007d6f6a1d04da  jmp 0x00007D6F6A1D043F
00007d6f6a1d04df  call 0x00007D6F6A0E2BA0
00007d6f6a1d04e4  jmp 0x00007D6F6A1D044D
00007d6f6a1d04e9  call 0x00007D6F6A0E2BA0
00007d6f6a1d04ee  jmp 0x00007D6F6A1D045B
00007d6f6a1d04f3  call 0x00007D6F6A0E2BA0
00007d6f6a1d04f8  jmp 0x00007D6F6A1D0469
00007d6f6a1d04fd  call 0x00007D6F6A0E2BA0
00007d6f6a1d0502  jmp 0x00007D6F6A1D0477
00007d6f6a1d0507  call 0x00007D6F6A0E2BA0
00007d6f6a1d050c  jmp 0x00007D6F6A1D0485
00007d6f6a1d0511  call 0x00007D6F6A0D5EB0
00007d6f6a1d0516  jmp 0x00007D6F6A1D0490
00007d6f6a1d051b  int3
00007d6f6a1d051c  nop [rax], eax
00007d6f6a1d0520  mov rax, [r15+0xF8]
00007d6f6a1d0527  lea r14, [rax+0x140]
00007d6f6a1d052e  mov r12, [r13+r14*1]
00007d6f6a1d0533  lea r14, [rax+0x148]
00007d6f6a1d053a  mov r11, [r13+r14*1]
00007d6f6a1d053f  mov [r15+0xA0], r12
00007d6f6a1d0546  mov [r15+0x98], r11
00007d6f6a1d054d  lea r14, [rax+0x130]
00007d6f6a1d0554  mov r12, [r13+r14*1]
00007d6f6a1d0559  lea r14, [rax+0x138]
00007d6f6a1d0560  mov r11, [r13+r14*1]
00007d6f6a1d0565  mov [r15+0xB0], r12
00007d6f6a1d056c  mov [r15+0xA8], r11
00007d6f6a1d0573  lea r14, [rax+0x120]
00007d6f6a1d057a  mov r12, [r13+r14*1]
00007d6f6a1d057f  lea r14, [rax+0x128]
00007d6f6a1d0586  mov r11, [r13+r14*1]
00007d6f6a1d058b  mov [r15+0xC0], r12
00007d6f6a1d0592  mov [r15+0xB8], r11
00007d6f6a1d0599  lea r14, [rax+0x110]
00007d6f6a1d05a0  mov r12, [r13+r14*1]
00007d6f6a1d05a5  lea r14, [rax+0x118]
00007d6f6a1d05ac  mov r11, [r13+r14*1]
00007d6f6a1d05b1  mov [r15+0xD0], r12
00007d6f6a1d05b8  mov [r15+0xC8], r11
00007d6f6a1d05bf  lea r14, [rax+0x100]
00007d6f6a1d05c6  mov r12, [r13+r14*1]
00007d6f6a1d05cb  lea r14, [rax+0x108]
00007d6f6a1d05d2  mov r11, [r13+r14*1]
00007d6f6a1d05d7  mov [r15+0xE8], r12
00007d6f6a1d05de  mov [r15+0xD8], r11
00007d6f6a1d05e5  lea r14, [rax+0x150]
00007d6f6a1d05ec  mov [r15+0xF8], r14
00007d6f6a1d05f3  mov rax, [r15+0xF0]
00007d6f6a1d05fa  mov [r15+0x100], rax
00007d6f6a1d0601  jmp 0x00007D6F6A1CE5C0
00007d6f6a1d0606  int3
00007d6f6a1d0607  call 0x00007D6F6A0E27E0
00007d6f6a1d060c  jmp 0x00007D6F6A1D0533
00007d6f6a1d0611  call 0x00007D6F6A0E1570
00007d6f6a1d0616  jmp 0x00007D6F6A1D053F
00007d6f6a1d061b  call 0x00007D6F6A0E27E0
00007d6f6a1d0620  jmp 0x00007D6F6A1D0559
00007d6f6a1d0625  call 0x00007D6F6A0E1570
00007d6f6a1d062a  jmp 0x00007D6F6A1D0565
00007d6f6a1d062f  call 0x00007D6F6A0E27E0
00007d6f6a1d0634  jmp 0x00007D6F6A1D057F
00007d6f6a1d0639  call 0x00007D6F6A0E1570
00007d6f6a1d063e  jmp 0x00007D6F6A1D058B
00007d6f6a1d0643  call 0x00007D6F6A0E27E0
00007d6f6a1d0648  jmp 0x00007D6F6A1D05A5
00007d6f6a1d064d  call 0x00007D6F6A0E1570
00007d6f6a1d0652  jmp 0x00007D6F6A1D05B1
00007d6f6a1d0657  call 0x00007D6F6A0E27E0
00007d6f6a1d065c  jmp 0x00007D6F6A1D05CB
00007d6f6a1d0661  call 0x00007D6F6A0E1570
00007d6f6a1d0666  jmp 0x00007D6F6A1D05D7
00007d6f6a1d066b  int3
00007d6f6a1d066c  nop [rax], eax
00007d6f6a1d0670  mov eax, [r15+0xA0]
00007d6f6a1d0677  mov [rsp+0x10], eax
00007d6f6a1d067b  xor eax, eax
00007d6f6a1d067d  mov r14d, [rsp+0x10]
00007d6f6a1d0682  sub r14d, 0x01
00007d6f6a1d0686  cmc
00007d6f6a1d0687  lahf
00007d6f6a1d0688  seto al
00007d6f6a1d068b  mov [r15+0x108], eax
00007d6f6a1d0692  mov r14d, r14d
00007d6f6a1d0695  mov [r15+0xA0], r14
00007d6f6a1d069c  mov eax, [r15+0x108]
00007d6f6a1d06a3  sahf
00007d6f6a1d06a4  jnz 0x00007D6F6A1D06D6
00007d6f6a1d06a6  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d06ae  jz 0x00007D6F6A1D07A0
00007d6f6a1d06b4  nop [rax+rax*1], ax
00007d6f6a1d06bd  nop [rax+rax*1], eax
00007d6f6a1d06c5  mov eax, 0x41027C
00007d6f6a1d06ca  mov [r15+0x100], rax
00007d6f6a1d06d1  jmp 0x00007D6F69FFE110
00007d6f6a1d06d6  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d06de  jz 0x00007D6F6A1D0710
00007d6f6a1d06e4  nop [rax+rax*1], ax
00007d6f6a1d06ed  nop [rax+rax*1], eax
00007d6f6a1d06f5  mov eax, 0x410264
00007d6f6a1d06fa  mov [r15+0x100], rax
00007d6f6a1d0701  jmp 0x00007D6F69FFE110
00007d6f6a1d0706  int3
00007d6f6a1d0707  int3
00007d6f6a1d0708  nop [rax+rax*1], eax
00007d6f6a1d0710  mov rax, [r15+0xF8]
00007d6f6a1d0717  mov [r15], rax
00007d6f6a1d071a  mov rax, [r15+0x98]
00007d6f6a1d0721  mov [r15+0x08], rax
00007d6f6a1d0725  mov qword ptr [r15+0x10], 0x12C
00007d6f6a1d072d  mov qword ptr [r15+0xF0], 0x410274
00007d6f6a1d0738  mov r14d, [r15+0x320]
00007d6f6a1d073f  mov eax, 0x410274
00007d6f6a1d0744  mov rcx, 0x7D6F6A1D0670
00007d6f6a1d074e  mov [r15+r14*8+0x328], rax
00007d6f6a1d0756  mov [r15+r14*8+0x368], rcx
00007d6f6a1d075e  add r14d, 0x01
00007d6f6a1d0762  and r14d, 0x07
00007d6f6a1d0766  mov [r15+0x320], r14d
00007d6f6a1d076d  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0775  jz 0x00007D6F6A1CEC20
00007d6f6a1d077b  nop [rax+rax*1], ax
00007d6f6a1d0784  nop [rax+rax*1], eax
00007d6f6a1d078c  mov eax, 0x410338
00007d6f6a1d0791  mov [r15+0x100], rax
00007d6f6a1d0798  jmp 0x00007D6F69FFE110
00007d6f6a1d079d  int3
00007d6f6a1d079e  int3
00007d6f6a1d079f  nop
00007d6f6a1d07a0  mov rax, [r15+0xF8]
00007d6f6a1d07a7  lea r14, [rax+0x20]
00007d6f6a1d07ab  mov r12, [r13+r14*1]
00007d6f6a1d07b0  mov [r15+0x98], r12
00007d6f6a1d07b7  mov qword ptr [r15+0x40], 0x80
00007d6f6a1d07bf  mov [r15], rax
00007d6f6a1d07c2  lea r14, [rax+0x8C]
00007d6f6a1d07c9  mov [r15+0x08], r14
00007d6f6a1d07cd  mov qword ptr [r15+0x10], 0x01
00007d6f6a1d07d5  lea r14, [rax+0x8C]
00007d6f6a1d07dc  mov eax, 0x80
00007d6f6a1d07e1  mov [r13+r14*1], al
00007d6f6a1d07e6  mov qword ptr [r15+0xF0], 0x410298
00007d6f6a1d07f1  mov r14d, [r15+0x320]
00007d6f6a1d07f8  mov eax, 0x410298
00007d6f6a1d07fd  mov rcx, 0x7D6F6A1D0870
00007d6f6a1d0807  mov [r15+r14*8+0x328], rax
00007d6f6a1d080f  mov [r15+r14*8+0x368], rcx
00007d6f6a1d0817  add r14d, 0x01
00007d6f6a1d081b  and r14d, 0x07
00007d6f6a1d081f  mov [r15+0x320], r14d
00007d6f6a1d0826  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d082e  jz 0x00007D6F6A1CEC20
00007d6f6a1d0834  nop [rax+rax*1], ax
00007d6f6a1d083d  nop [rax+rax*1], eax
00007d6f6a1d0845  mov eax, 0x410338
00007d6f6a1d084a  mov [r15+0x100], rax
00007d6f6a1d0851  jmp 0x00007D6F69FFE110
00007d6f6a1d0856  int3
00007d6f6a1d0857  call 0x00007D6F6A0E27E0
00007d6f6a1d085c  jmp 0x00007D6F6A1D07B0
00007d6f6a1d0861  call 0x00007D6F6A0D5AF0
00007d6f6a1d0866  jmp 0x00007D6F6A1D07E6
00007d6f6a1d086b  int3
00007d6f6a1d086c  nop [rax], eax
00007d6f6a1d0870  mov rax, [r15+0xF8]
00007d6f6a1d0877  lea r14, [rax+0x68]
00007d6f6a1d087b  mov r12, [r13+r14*1]
00007d6f6a1d0880  mov [r15+0x40], r12
00007d6f6a1d0884  lea r14, [rax+0x88]
00007d6f6a1d088b  xor eax, eax
00007d6f6a1d088d  mov [r13+r14*1], al
00007d6f6a1d0892  xor eax, eax
00007d6f6a1d0894  mov r14d, 0x38
00007d6f6a1d089a  cmp r12, r14
00007d6f6a1d089d  cmc
00007d6f6a1d089e  lahf
00007d6f6a1d089f  seto al
00007d6f6a1d08a2  mov [r15+0x108], eax
00007d6f6a1d08a9  mov eax, [r15+0x108]
00007d6f6a1d08b0  sahf
00007d6f6a1d08b1  jz 0x00007D6F6A1D08E3
00007d6f6a1d08b3  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d08bb  jz 0x00007D6F6A1D0930
00007d6f6a1d08c1  nop [rax+rax*1], ax
00007d6f6a1d08ca  nop [rax+rax*1], eax
00007d6f6a1d08d2  mov eax, 0x4102A8
00007d6f6a1d08d7  mov [r15+0x100], rax
00007d6f6a1d08de  jmp 0x00007D6F69FFE110
00007d6f6a1d08e3  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d08eb  jz 0x00007D6F6A1D0A70
00007d6f6a1d08f1  nop [rax+rax*1], ax
00007d6f6a1d08fa  nop [rax+rax*1], eax
00007d6f6a1d0902  mov eax, 0x4102C4
00007d6f6a1d0907  mov [r15+0x100], rax
00007d6f6a1d090e  jmp 0x00007D6F69FFE110
00007d6f6a1d0913  int3
00007d6f6a1d0914  call 0x00007D6F6A0E27E0
00007d6f6a1d0919  jmp 0x00007D6F6A1D0880
00007d6f6a1d091e  call 0x00007D6F6A0D5AF0
00007d6f6a1d0923  jmp 0x00007D6F6A1D0892
00007d6f6a1d0928  int3
00007d6f6a1d0929  nop [rax], eax
00007d6f6a1d0930  mov rax, [r15+0xF8]
00007d6f6a1d0937  mov [r15], rax
00007d6f6a1d093a  lea r14, [rax+0x88]
00007d6f6a1d0941  mov [r15+0x08], r14
00007d6f6a1d0945  mov qword ptr [r15+0x10], 0x01
00007d6f6a1d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007d6f6a1d0958  mov r14d, [r15+0x320]
00007d6f6a1d095f  mov eax, 0x4102B8
00007d6f6a1d0964  mov rcx, 0x7D6F6A1D09C0
00007d6f6a1d096e  mov [r15+r14*8+0x328], rax
00007d6f6a1d0976  mov [r15+r14*8+0x368], rcx
00007d6f6a1d097e  add r14d, 0x01
00007d6f6a1d0982  and r14d, 0x07
00007d6f6a1d0986  mov [r15+0x320], r14d
00007d6f6a1d098d  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0995  jz 0x00007D6F6A1CEC20
00007d6f6a1d099b  nop [rax+rax*1], ax
00007d6f6a1d09a4  nop [rax+rax*1], eax
00007d6f6a1d09ac  mov eax, 0x410338
00007d6f6a1d09b1  mov [r15+0x100], rax
00007d6f6a1d09b8  jmp 0x00007D6F69FFE110
00007d6f6a1d09bd  int3
00007d6f6a1d09be  int3
00007d6f6a1d09bf  nop
00007d6f6a1d09c0  mov rax, [r15+0xF8]
00007d6f6a1d09c7  lea r14, [rax+0x68]
00007d6f6a1d09cb  mov rax, [r13+r14*1]
00007d6f6a1d09d0  mov [r15+0x40], rax
00007d6f6a1d09d4  mov [rsp+0x10], rax
00007d6f6a1d09d9  xor eax, eax
00007d6f6a1d09db  mov r14, [rsp+0x10]
00007d6f6a1d09e0  mov r12d, 0x38
00007d6f6a1d09e6  cmp r14, r12
00007d6f6a1d09e9  cmc
00007d6f6a1d09ea  lahf
00007d6f6a1d09eb  seto al
00007d6f6a1d09ee  mov [r15+0x108], eax
00007d6f6a1d09f5  mov eax, [r15+0x108]
00007d6f6a1d09fc  sahf
00007d6f6a1d09fd  jnz 0x00007D6F6A1D0A2F
00007d6f6a1d09ff  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0a07  jz 0x00007D6F6A1D0A70
00007d6f6a1d0a0d  nop [rax+rax*1], ax
00007d6f6a1d0a16  nop [rax+rax*1], eax
00007d6f6a1d0a1e  mov eax, 0x4102C4
00007d6f6a1d0a23  mov [r15+0x100], rax
00007d6f6a1d0a2a  jmp 0x00007D6F69FFE110
00007d6f6a1d0a2f  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0a37  jz 0x00007D6F6A1D0930
00007d6f6a1d0a3d  nop [rax+rax*1], ax
00007d6f6a1d0a46  nop [rax+rax*1], eax
00007d6f6a1d0a4e  mov eax, 0x4102A8
00007d6f6a1d0a53  mov [r15+0x100], rax
00007d6f6a1d0a5a  jmp 0x00007D6F69FFE110
00007d6f6a1d0a5f  int3
00007d6f6a1d0a60  call 0x00007D6F6A0D59C0
00007d6f6a1d0a65  jmp 0x00007D6F6A1D09D0
00007d6f6a1d0a6a  int3
00007d6f6a1d0a6b  nop [rax+rax*1], eax
00007d6f6a1d0a70  mov rax, [r15+0x98]
00007d6f6a1d0a77  rorx r14, rax, 0x3D
00007d6f6a1d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007d6f6a1d0a81  mov rax, [r15+0xF8]
00007d6f6a1d0a88  mov [r15], rax
00007d6f6a1d0a8b  lea r12, [rax+0x78]
00007d6f6a1d0a8f  mov [r15+0x08], r12
00007d6f6a1d0a93  mov qword ptr [r15+0x10], 0x08
00007d6f6a1d0a9b  bswap r14
00007d6f6a1d0a9e  mov [r15+0x40], r14
00007d6f6a1d0aa2  lea r12, [rax+0x78]
00007d6f6a1d0aa6  mov [r13+r12*1], r14
00007d6f6a1d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007d6f6a1d0ab6  mov r14d, [r15+0x320]
00007d6f6a1d0abd  mov eax, 0x4102E0
00007d6f6a1d0ac2  mov rcx, 0x7D6F6A1D0B30
00007d6f6a1d0acc  mov [r15+r14*8+0x328], rax
00007d6f6a1d0ad4  mov [r15+r14*8+0x368], rcx
00007d6f6a1d0adc  add r14d, 0x01
00007d6f6a1d0ae0  and r14d, 0x07
00007d6f6a1d0ae4  mov [r15+0x320], r14d
00007d6f6a1d0aeb  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0af3  jz 0x00007D6F6A1CEC20
00007d6f6a1d0af9  nop [rax+rax*1], ax
00007d6f6a1d0b02  nop [rax+rax*1], eax
00007d6f6a1d0b0a  mov eax, 0x410338
00007d6f6a1d0b0f  mov [r15+0x100], rax
00007d6f6a1d0b16  jmp 0x00007D6F69FFE110
00007d6f6a1d0b1b  int3
00007d6f6a1d0b1c  call 0x00007D6F6A0C3FE0
00007d6f6a1d0b21  jmp 0x00007D6F6A1D0AAB
00007d6f6a1d0b26  int3
00007d6f6a1d0b27  nop [rax+rax*1], ax
00007d6f6a1d0b30  mov rax, [r15+0xF8]
00007d6f6a1d0b37  mov r14d, [r13+rax*1]
00007d6f6a1d0b3c  lea r12, [rax+0x04]
00007d6f6a1d0b40  mov r11d, [r13+r12*1]
00007d6f6a1d0b45  lea r12, [rax+0x08]
00007d6f6a1d0b49  mov r10d, [r13+r12*1]
00007d6f6a1d0b4e  lea r12, [rax+0x0C]
00007d6f6a1d0b52  mov r9d, [r13+r12*1]
00007d6f6a1d0b57  mov qword ptr [r15+0x48], 0x430860
00007d6f6a1d0b5f  lea r12, [rax+0x80]
00007d6f6a1d0b66  mov r8, [r13+r12*1]
00007d6f6a1d0b6b  mov [r15+0xF0], r8
00007d6f6a1d0b72  bswap r14d
00007d6f6a1d0b75  bswap r11d
00007d6f6a1d0b78  mov r12d, 0x430860
00007d6f6a1d0b7e  mov [r13+r12*1], r14d
00007d6f6a1d0b83  mov r14d, 0x430864
00007d6f6a1d0b89  mov [r13+r14*1], r11d
00007d6f6a1d0b8e  bswap r10d
00007d6f6a1d0b91  bswap r9d
00007d6f6a1d0b94  lea r14, [rax+0x10]
00007d6f6a1d0b98  mov r12d, [r13+r14*1]
00007d6f6a1d0b9d  lea r14, [rax+0x14]
00007d6f6a1d0ba1  mov r11d, [r13+r14*1]
00007d6f6a1d0ba6  mov r14d, 0x430868
00007d6f6a1d0bac  mov [r13+r14*1], r10d
00007d6f6a1d0bb1  mov r14d, 0x43086C
00007d6f6a1d0bb7  mov [r13+r14*1], r9d
00007d6f6a1d0bbc  lea r14, [rax+0x90]
00007d6f6a1d0bc3  mov r10, [r13+r14*1]
00007d6f6a1d0bc8  lea r14, [rax+0x98]
00007d6f6a1d0bcf  mov r9, [r13+r14*1]
00007d6f6a1d0bd4  mov [r15+0xA0], r10
00007d6f6a1d0bdb  mov [r15+0x98], r9
00007d6f6a1d0be2  bswap r12d
00007d6f6a1d0be5  bswap r11d
00007d6f6a1d0be8  mov [rsp+0x10], r11d
00007d6f6a1d0bed  mov r11d, r11d
00007d6f6a1d0bf0  mov [r15+0x58], r11
00007d6f6a1d0bf4  lea r14, [rax+0x18]
00007d6f6a1d0bf8  mov r11d, [r13+r14*1]
00007d6f6a1d0bfd  lea r14, [rax+0x1C]
00007d6f6a1d0c01  mov r10d, [r13+r14*1]
00007d6f6a1d0c06  mov [rsp+0x20], r10d
00007d6f6a1d0c0b  mov r10d, r10d
00007d6f6a1d0c0e  mov [r15+0x60], r10
00007d6f6a1d0c12  mov r14d, 0x430870
00007d6f6a1d0c18  mov [r13+r14*1], r12d
00007d6f6a1d0c1d  mov r14d, 0x430874
00007d6f6a1d0c23  mov r12d, [rsp+0x10]
00007d6f6a1d0c28  mov [r13+r14*1], r12d
00007d6f6a1d0c2d  bswap r11d
00007d6f6a1d0c30  mov [rsp+0x10], r11d
00007d6f6a1d0c35  mov r11d, r11d
00007d6f6a1d0c38  mov [r15+0x40], r11
00007d6f6a1d0c3c  mov r14d, [rsp+0x20]
00007d6f6a1d0c41  bswap r14d
00007d6f6a1d0c44  mov [rsp+0x20], r14d
00007d6f6a1d0c49  mov r14d, r14d
00007d6f6a1d0c4c  mov [r15+0x50], r14
00007d6f6a1d0c50  mov r14d, 0x430878
00007d6f6a1d0c56  mov r12d, [rsp+0x10]
00007d6f6a1d0c5b  mov [r13+r14*1], r12d
00007d6f6a1d0c60  mov r14d, 0x43087C
00007d6f6a1d0c66  mov r12d, [rsp+0x20]
00007d6f6a1d0c6b  mov [r13+r14*1], r12d
00007d6f6a1d0c70  lea r14, [rax+0xA0]
00007d6f6a1d0c77  mov [r15+0xF8], r14
00007d6f6a1d0c7e  mov [r15+0x100], r8
00007d6f6a1d0c85  jmp 0x00007D6F6A1CE5C0
00007d6f6a1d0c8a  int3
00007d6f6a1d0c8b  call 0x00007D6F6A00DAE0
00007d6f6a1d0c90  jmp 0x00007D6F6A1D0B3C
00007d6f6a1d0c95  call 0x00007D6F6A0C0230
00007d6f6a1d0c9a  jmp 0x00007D6F6A1D0B45
00007d6f6a1d0c9f  call 0x00007D6F6A0BEFC0
00007d6f6a1d0ca4  jmp 0x00007D6F6A1D0B4E
00007d6f6a1d0ca9  call 0x00007D6F6A0BDD50
00007d6f6a1d0cae  jmp 0x00007D6F6A1D0B57
00007d6f6a1d0cb3  call 0x00007D6F6A0BCC20
00007d6f6a1d0cb8  jmp 0x00007D6F6A1D0B6B
00007d6f6a1d0cbd  call 0x00007D6F6A0C3EA0
00007d6f6a1d0cc2  jmp 0x00007D6F6A1D0B83
00007d6f6a1d0cc7  call 0x00007D6F6A0E1920
00007d6f6a1d0ccc  jmp 0x00007D6F6A1D0B8E
00007d6f6a1d0cd1  call 0x00007D6F6A0E26A0
00007d6f6a1d0cd6  jmp 0x00007D6F6A1D0B9D
00007d6f6a1d0cdb  call 0x00007D6F6A0E1430
00007d6f6a1d0ce0  jmp 0x00007D6F6A1D0BA6
00007d6f6a1d0ce5  call 0x00007D6F6A0E06B0
00007d6f6a1d0cea  jmp 0x00007D6F6A1D0BB1
00007d6f6a1d0cef  call 0x00007D6F6A0DF440
00007d6f6a1d0cf4  jmp 0x00007D6F6A1D0BBC
00007d6f6a1d0cf9  call 0x00007D6F6A0E0300
00007d6f6a1d0cfe  jmp 0x00007D6F6A1D0BC8
00007d6f6a1d0d03  call 0x00007D6F6A0DF090
00007d6f6a1d0d08  jmp 0x00007D6F6A1D0BD4
00007d6f6a1d0d0d  call 0x00007D6F6A0E1430
00007d6f6a1d0d12  jmp 0x00007D6F6A1D0BFD
00007d6f6a1d0d17  call 0x00007D6F6A0E01C0
00007d6f6a1d0d1c  jmp 0x00007D6F6A1D0C06
00007d6f6a1d0d21  call 0x00007D6F6A0E2BA0
00007d6f6a1d0d26  jmp 0x00007D6F6A1D0C1D
00007d6f6a1d0d2b  call 0x00007D6F6A0E2BA0
00007d6f6a1d0d30  jmp 0x00007D6F6A1D0C2D
00007d6f6a1d0d35  call 0x00007D6F6A0E2BA0
00007d6f6a1d0d3a  jmp 0x00007D6F6A1D0C60
00007d6f6a1d0d3f  call 0x00007D6F6A0E2BA0
00007d6f6a1d0d44  jmp 0x00007D6F6A1D0C70
00007d6f6a1d0d49  int3
00007d6f6a1d0d4a  nop [rax+rax*1], ax
00007d6f6a1d0d50  mov qword ptr [r15+0x100], 0x04
00007d6f6a1d0d5b  mov esi, 0x00
00007d6f6a1d0d60  mov edx, 0x09
00007d6f6a1d0d65  mov rdi, 0x7FFFC3942480
00007d6f6a1d0d6f  mov rax, 0x598894F98970
00007d6f6a1d0d79  call rax
00007d6f6a1d0d7b  cmp dword ptr [r15+0x318], 0x00
00007d6f6a1d0d83  jnz 0x00007D6F69FFE110
00007d6f6a1d0d89  jmp 0x00007D6F69FFE0A0
00007d6f6a1d0d8e  int3
00007d6f6a1d0d8f  int3
