00007fa0f61ce69b  nop [rax+rax*1], eax
00007fa0f61ce6a0  mov rax, [r15+0xF8]
00007fa0f61ce6a7  lea r14, [rax-0xA0]
00007fa0f61ce6ae  mov [r15+0xF8], r14
00007fa0f61ce6b5  lea rax, [r14+0x90]
00007fa0f61ce6bc  mov r12, [r15+0xA0]
00007fa0f61ce6c3  mov r11, [r15+0x98]
00007fa0f61ce6ca  mov [r13+rax*1], r12
00007fa0f61ce6cf  lea rax, [r14+0x98]
00007fa0f61ce6d6  mov [r13+rax*1], r11
00007fa0f61ce6db  mov eax, 0x420670
00007fa0f61ce6e0  movups xmm1, [r13+rax*1]
00007fa0f61ce6e6  mov eax, 0x420610
00007fa0f61ce6eb  movups xmm15, [r13+rax*1]
00007fa0f61ce6f1  mov eax, 0x420690
00007fa0f61ce6f6  movups xmm14, [r13+rax*1]
00007fa0f61ce6fc  mov eax, 0x420630
00007fa0f61ce701  movups xmm13, [r13+rax*1]
00007fa0f61ce707  mov qword ptr [r15+0x98], 0x4308A0
00007fa0f61ce712  mov eax, 0x4206A0
00007fa0f61ce717  movups xmm12, [r13+rax*1]
00007fa0f61ce71d  mov eax, 0x4308A0
00007fa0f61ce722  movups [r13+rax*1], xmm1
00007fa0f61ce728  mov eax, 0x4308B0
00007fa0f61ce72d  movups [r13+rax*1], xmm15
00007fa0f61ce733  mov eax, 0x4308C0
00007fa0f61ce738  movups [r13+rax*1], xmm14
00007fa0f61ce73e  mov eax, 0x4308D0
00007fa0f61ce743  movups [r13+rax*1], xmm13
00007fa0f61ce749  mov eax, 0x420600
00007fa0f61ce74e  movups xmm14, [r13+rax*1]
00007fa0f61ce754  mov eax, 0x4205F0
00007fa0f61ce759  movups xmm13, [r13+rax*1]
00007fa0f61ce75f  mov eax, 0x4309A0
00007fa0f61ce764  movups [r13+rax*1], xmm1
00007fa0f61ce76a  mov eax, 0x4309B0
00007fa0f61ce76f  movups [r13+rax*1], xmm15
00007fa0f61ce775  mov eax, 0x4308E0
00007fa0f61ce77a  movups [r13+rax*1], xmm12
00007fa0f61ce780  mov eax, 0x4308F0
00007fa0f61ce785  movups [r13+rax*1], xmm14
00007fa0f61ce78b  mov eax, 0x4205E0
00007fa0f61ce790  movups xmm1, [r13+rax*1]
00007fa0f61ce796  mov eax, 0x420640
00007fa0f61ce79b  movups xmm15, [r13+rax*1]
00007fa0f61ce7a1  mov eax, 0x430900
00007fa0f61ce7a6  movups [r13+rax*1], xmm13
00007fa0f61ce7ac  mov eax, 0x430910
00007fa0f61ce7b1  movups [r13+rax*1], xmm1
00007fa0f61ce7b7  mov eax, 0x420650
00007fa0f61ce7bc  movups xmm1, [r13+rax*1]
00007fa0f61ce7c2  mov eax, 0x420620
00007fa0f61ce7c7  movups xmm14, [r13+rax*1]
00007fa0f61ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007fa0f61ce7d5  mov eax, 0x430920
00007fa0f61ce7da  movups [r13+rax*1], xmm15
00007fa0f61ce7e0  mov eax, 0x430930
00007fa0f61ce7e5  movups [r13+rax*1], xmm1
00007fa0f61ce7eb  mov eax, 0x4206C0
00007fa0f61ce7f0  movups xmm1, [r13+rax*1]
00007fa0f61ce7f6  mov eax, 0x4206D0
00007fa0f61ce7fb  movups xmm15, [r13+rax*1]
00007fa0f61ce801  movaps [r15+0x150], xmm15
00007fa0f61ce809  mov qword ptr [r15+0xA0], 0x3E8
00007fa0f61ce814  mov eax, 0x430940
00007fa0f61ce819  movups [r13+rax*1], xmm14
00007fa0f61ce81f  mov eax, 0x430950
00007fa0f61ce824  movups [r13+rax*1], xmm1
00007fa0f61ce82a  mov eax, 0x4206B0
00007fa0f61ce82f  movups xmm1, [r13+rax*1]
00007fa0f61ce835  mov eax, 0x420660
00007fa0f61ce83a  movups xmm14, [r13+rax*1]
00007fa0f61ce840  movaps [r15+0x140], xmm14
00007fa0f61ce848  lea rax, [r14+0x80]
00007fa0f61ce84f  mov r12, [r15+0xF0]
00007fa0f61ce856  mov [r13+rax*1], r12
00007fa0f61ce85b  mov eax, 0x430960
00007fa0f61ce860  movups [r13+rax*1], xmm15
00007fa0f61ce866  mov eax, 0x430970
00007fa0f61ce86b  movups [r13+rax*1], xmm1
00007fa0f61ce871  mov eax, 0x420680
00007fa0f61ce876  movups xmm1, [r13+rax*1]
00007fa0f61ce87c  mov eax, 0x4206E0
00007fa0f61ce881  mov r12, [r13+rax*1]
00007fa0f61ce886  movq xmm15, r12
00007fa0f61ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007fa0f61ce893  mov eax, 0x430980
00007fa0f61ce898  movups [r13+rax*1], xmm14
00007fa0f61ce89e  mov eax, 0x430990
00007fa0f61ce8a3  movups [r13+rax*1], xmm1
00007fa0f61ce8a9  mov eax, 0x420748
00007fa0f61ce8ae  movups xmm1, [r13+rax*1]
00007fa0f61ce8b4  movq rax, xmm15
00007fa0f61ce8b9  mov r12d, 0x4309C0
00007fa0f61ce8bf  mov [r13+r12*1], rax
00007fa0f61ce8c4  mov eax, 0x420728
00007fa0f61ce8c9  movups xmm15, [r13+rax*1]
00007fa0f61ce8cf  mov eax, 0x420738
00007fa0f61ce8d4  movups xmm14, [r13+rax*1]
00007fa0f61ce8da  lea rax, [r14+0x60]
00007fa0f61ce8de  movups [r13+rax*1], xmm1
00007fa0f61ce8e4  mov eax, 0x4309C8
00007fa0f61ce8e9  mov r12d, 0x421DF8D3
00007fa0f61ce8ef  mov [r13+rax*1], r12d
00007fa0f61ce8f4  lea rax, [r14+0x40]
00007fa0f61ce8f8  movups [r13+rax*1], xmm15
00007fa0f61ce8fe  lea rax, [r14+0x50]
00007fa0f61ce902  movups [r13+rax*1], xmm14
00007fa0f61ce908  mov eax, 0x4206E8
00007fa0f61ce90d  movups xmm1, [r13+rax*1]
00007fa0f61ce913  mov eax, 0x4206F8
00007fa0f61ce918  movups xmm15, [r13+rax*1]
00007fa0f61ce91e  movaps [r15+0x120], xmm15
00007fa0f61ce926  movups [r13+r14*1], xmm1
00007fa0f61ce92c  lea rax, [r14+0x10]
00007fa0f61ce930  movups [r13+rax*1], xmm15
00007fa0f61ce936  mov eax, 0x420708
00007fa0f61ce93b  movups xmm1, [r13+rax*1]
00007fa0f61ce941  mov eax, 0x420718
00007fa0f61ce946  movups xmm15, [r13+rax*1]
00007fa0f61ce94c  movaps [r15+0x110], xmm1
00007fa0f61ce954  movaps [r15+0x130], xmm15
00007fa0f61ce95c  lea rax, [r14+0x20]
00007fa0f61ce960  movups [r13+rax*1], xmm1
00007fa0f61ce966  lea rax, [r14+0x30]
00007fa0f61ce96a  movups [r13+rax*1], xmm15
00007fa0f61ce970  mov [r15], r14
00007fa0f61ce973  mov qword ptr [r15+0x08], 0x4308A0
00007fa0f61ce97b  mov qword ptr [r15+0x10], 0x12C
00007fa0f61ce983  mov qword ptr [r15+0xF0], 0x410274
00007fa0f61ce98e  mov r14d, [r15+0x320]
00007fa0f61ce995  mov eax, 0x410274
00007fa0f61ce99a  mov rcx, 0x7FA0F61D0670
00007fa0f61ce9a4  mov [r15+r14*8+0x328], rax
00007fa0f61ce9ac  mov [r15+r14*8+0x368], rcx
00007fa0f61ce9b4  add r14d, 0x01
00007fa0f61ce9b8  and r14d, 0x07
00007fa0f61ce9bc  mov [r15+0x320], r14d
00007fa0f61ce9c3  cmp dword ptr [r15+0x318], 0x00
00007fa0f61ce9cb  jz 0x00007FA0F61CEC20
00007fa0f61ce9d1  nop [rax+rax*1], ax
00007fa0f61ce9da  nop [rax+rax*1], eax
00007fa0f61ce9e2  mov eax, 0x410338
00007fa0f61ce9e7  mov [r15+0x100], rax
00007fa0f61ce9ee  jmp 0x00007FA0F5FFE110
00007fa0f61ce9f3  int3
00007fa0f61ce9f4  call 0x00007FA0F600BC20
00007fa0f61ce9f9  jmp 0x00007FA0F61CE6CF
00007fa0f61ce9fe  call 0x00007FA0F600A9A0
00007fa0f61cea03  jmp 0x00007FA0F61CE6DB
00007fa0f61cea08  call 0x00007FA0F5FFF430
00007fa0f61cea0d  jmp 0x00007FA0F61CE6E6
00007fa0f61cea12  call 0x00007FA0F600E760
00007fa0f61cea17  jmp 0x00007FA0F61CE6F1
00007fa0f61cea1c  call 0x00007FA0F600D4E0
00007fa0f61cea21  jmp 0x00007FA0F61CE6FC
00007fa0f61cea26  call 0x00007FA0F600C260
00007fa0f61cea2b  jmp 0x00007FA0F61CE707
00007fa0f61cea30  call 0x00007FA0F600AFE0
00007fa0f61cea35  jmp 0x00007FA0F61CE71D
00007fa0f61cea3a  call 0x00007FA0F5FFF540
00007fa0f61cea3f  jmp 0x00007FA0F61CE728
00007fa0f61cea44  call 0x00007FA0F600E880
00007fa0f61cea49  jmp 0x00007FA0F61CE733
00007fa0f61cea4e  call 0x00007FA0F600D600
00007fa0f61cea53  jmp 0x00007FA0F61CE73E
00007fa0f61cea58  call 0x00007FA0F600C380
00007fa0f61cea5d  jmp 0x00007FA0F61CE749
00007fa0f61cea62  call 0x00007FA0F600D4E0
00007fa0f61cea67  jmp 0x00007FA0F61CE754
00007fa0f61cea6c  call 0x00007FA0F600C260
00007fa0f61cea71  jmp 0x00007FA0F61CE75F
00007fa0f61cea76  call 0x00007FA0F5FFF540
00007fa0f61cea7b  jmp 0x00007FA0F61CE76A
00007fa0f61cea80  call 0x00007FA0F600E880
00007fa0f61cea85  jmp 0x00007FA0F61CE775
00007fa0f61cea8a  call 0x00007FA0F600B100
00007fa0f61cea8f  jmp 0x00007FA0F61CE780
00007fa0f61cea94  call 0x00007FA0F600D600
00007fa0f61cea99  jmp 0x00007FA0F61CE78B
00007fa0f61cea9e  call 0x00007FA0F5FFF430
00007fa0f61ceaa3  jmp 0x00007FA0F61CE796
00007fa0f61ceaa8  call 0x00007FA0F600E760
00007fa0f61ceaad  jmp 0x00007FA0F61CE7A1
00007fa0f61ceab2  call 0x00007FA0F600C380
00007fa0f61ceab7  jmp 0x00007FA0F61CE7AC
00007fa0f61ceabc  call 0x00007FA0F5FFF540
00007fa0f61ceac1  jmp 0x00007FA0F61CE7B7
00007fa0f61ceac6  call 0x00007FA0F5FFF430
00007fa0f61ceacb  jmp 0x00007FA0F61CE7C2
00007fa0f61cead0  call 0x00007FA0F600D4E0
00007fa0f61cead5  jmp 0x00007FA0F61CE7CD
00007fa0f61ceada  call 0x00007FA0F600E880
00007fa0f61ceadf  jmp 0x00007FA0F61CE7E0
00007fa0f61ceae4  call 0x00007FA0F5FFF540
00007fa0f61ceae9  jmp 0x00007FA0F61CE7EB
00007fa0f61ceaee  call 0x00007FA0F5FFF430
00007fa0f61ceaf3  jmp 0x00007FA0F61CE7F6
00007fa0f61ceaf8  call 0x00007FA0F600E760
00007fa0f61ceafd  jmp 0x00007FA0F61CE801
00007fa0f61ceb02  call 0x00007FA0F600D600
00007fa0f61ceb07  jmp 0x00007FA0F61CE81F
00007fa0f61ceb0c  call 0x00007FA0F5FFF540
00007fa0f61ceb11  jmp 0x00007FA0F61CE82A
00007fa0f61ceb16  call 0x00007FA0F5FFF430
00007fa0f61ceb1b  jmp 0x00007FA0F61CE835
00007fa0f61ceb20  call 0x00007FA0F600D4E0
00007fa0f61ceb25  jmp 0x00007FA0F61CE840
00007fa0f61ceb2a  call 0x00007FA0F600BC20
00007fa0f61ceb2f  jmp 0x00007FA0F61CE85B
00007fa0f61ceb34  call 0x00007FA0F600E880
00007fa0f61ceb39  jmp 0x00007FA0F61CE866
00007fa0f61ceb3e  call 0x00007FA0F5FFF540
00007fa0f61ceb43  jmp 0x00007FA0F61CE871
00007fa0f61ceb48  call 0x00007FA0F5FFF430
00007fa0f61ceb4d  jmp 0x00007FA0F61CE87C
00007fa0f61ceb52  call 0x00007FA0F600B720
00007fa0f61ceb57  jmp 0x00007FA0F61CE886
00007fa0f61ceb5c  call 0x00007FA0F600D600
00007fa0f61ceb61  jmp 0x00007FA0F61CE89E
00007fa0f61ceb66  call 0x00007FA0F5FFF540
00007fa0f61ceb6b  jmp 0x00007FA0F61CE8A9
00007fa0f61ceb70  call 0x00007FA0F5FFF430
00007fa0f61ceb75  jmp 0x00007FA0F61CE8B4
00007fa0f61ceb7a  call 0x00007FA0F60B4CB0
00007fa0f61ceb7f  jmp 0x00007FA0F61CE8C4
00007fa0f61ceb84  call 0x00007FA0F600E760
00007fa0f61ceb89  jmp 0x00007FA0F61CE8CF
00007fa0f61ceb8e  call 0x00007FA0F600D4E0
00007fa0f61ceb93  jmp 0x00007FA0F61CE8DA
00007fa0f61ceb98  call 0x00007FA0F5FFF540
00007fa0f61ceb9d  jmp 0x00007FA0F61CE8E4
00007fa0f61ceba2  call 0x00007FA0F600BAE0
00007fa0f61ceba7  jmp 0x00007FA0F61CE8F4
00007fa0f61cebac  call 0x00007FA0F600E880
00007fa0f61cebb1  jmp 0x00007FA0F61CE8FE
00007fa0f61cebb6  call 0x00007FA0F600D600
00007fa0f61cebbb  jmp 0x00007FA0F61CE908
00007fa0f61cebc0  call 0x00007FA0F5FFF430
00007fa0f61cebc5  jmp 0x00007FA0F61CE913
00007fa0f61cebca  call 0x00007FA0F600E760
00007fa0f61cebcf  jmp 0x00007FA0F61CE91E
00007fa0f61cebd4  call 0x00007FA0F60D6600
00007fa0f61cebd9  jmp 0x00007FA0F61CE92C
00007fa0f61cebde  call 0x00007FA0F600E880
00007fa0f61cebe3  jmp 0x00007FA0F61CE936
00007fa0f61cebe8  call 0x00007FA0F5FFF430
00007fa0f61cebed  jmp 0x00007FA0F61CE941
00007fa0f61cebf2  call 0x00007FA0F600E760
00007fa0f61cebf7  jmp 0x00007FA0F61CE94C
00007fa0f61cebfc  call 0x00007FA0F5FFF540
00007fa0f61cec01  jmp 0x00007FA0F61CE966
00007fa0f61cec06  call 0x00007FA0F600E880
00007fa0f61cec0b  jmp 0x00007FA0F61CE970
00007fa0f61cec10  int3
00007fa0f61cec11  nop [rax+rax*1], ax
00007fa0f61cec1a  nop [rax+rax*1], ax
00007fa0f61cec20  mov rax, [r15]
00007fa0f61cec23  lea r14, [rax+0x20]
00007fa0f61cec27  mov r12, [r13+r14*1]
00007fa0f61cec2c  mov r14, [r15+0x10]
00007fa0f61cec30  lea r11, [r12+r14*1]
00007fa0f61cec34  mov [r15+0x40], r11
00007fa0f61cec38  lea r12, [rax+0x20]
00007fa0f61cec3c  mov [r13+r12*1], r11
00007fa0f61cec41  test r14, r14
00007fa0f61cec44  setz r14b
00007fa0f61cec48  movzx r14, r14b
00007fa0f61cec4c  mov [rsp+0x414], r14b
00007fa0f61cec54  cmp byte ptr [rsp+0x414], 0x00
00007fa0f61cec5c  jz 0x00007FA0F61CEC8E
00007fa0f61cec5e  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cec66  mov eax, 0x4105B0
00007fa0f61cec6b  mov [r15+0x100], rax
00007fa0f61cec72  jz 0x00007FA0F5FFE0A0
00007fa0f61cec78  nop [rax+rax*1], eax
00007fa0f61cec7d  mov eax, 0x4105B0
00007fa0f61cec82  mov [r15+0x100], rax
00007fa0f61cec89  jmp 0x00007FA0F5FFE110
00007fa0f61cec8e  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cec96  jz 0x00007FA0F61CECE0
00007fa0f61cec9c  nop [rax+rax*1], ax
00007fa0f61ceca5  nop [rax+rax*1], eax
00007fa0f61cecad  mov eax, 0x410348
00007fa0f61cecb2  mov [r15+0x100], rax
00007fa0f61cecb9  jmp 0x00007FA0F5FFE110
00007fa0f61cecbe  int3
00007fa0f61cecbf  call 0x00007FA0F60E27E0
00007fa0f61cecc4  jmp 0x00007FA0F61CEC2C
00007fa0f61cecc9  call 0x00007FA0F60C0860
00007fa0f61cecce  jmp 0x00007FA0F61CEC41
00007fa0f61cecd3  int3
00007fa0f61cecd4  nop [rax+rax*1], ax
00007fa0f61cecdd  nop [rax], eax
00007fa0f61cece0  mov rax, [r15+0xF8]
00007fa0f61cece7  lea r14, [rax-0x150]
00007fa0f61cecee  mov [r15+0xF8], r14
00007fa0f61cecf5  mov rax, [r15]
00007fa0f61cecf8  lea r12, [rax+0x68]
00007fa0f61cecfc  mov r11, [r13+r12*1]
00007fa0f61ced01  mov [r15+0x88], r11
00007fa0f61ced08  lea r12, [rax+0x28]
00007fa0f61ced0c  mov [r15+0x40], r12
00007fa0f61ced10  mov [r15+0x48], r14
00007fa0f61ced14  mov qword ptr [r15+0x50], 0x420758
00007fa0f61ced1c  lea rax, [r14+0x100]
00007fa0f61ced23  mov r12, [r15+0xE8]
00007fa0f61ced2a  mov r11, [r15+0xD8]
00007fa0f61ced31  mov [r13+rax*1], r12
00007fa0f61ced36  lea rax, [r14+0x108]
00007fa0f61ced3d  mov [r13+rax*1], r11
00007fa0f61ced42  lea rax, [r14+0x110]
00007fa0f61ced49  mov r12, [r15+0xD0]
00007fa0f61ced50  mov r11, [r15+0xC8]
00007fa0f61ced57  mov [r13+rax*1], r12
00007fa0f61ced5c  lea rax, [r14+0x118]
00007fa0f61ced63  mov [r13+rax*1], r11
00007fa0f61ced68  lea rax, [r14+0x120]
00007fa0f61ced6f  mov r12, [r15+0xC0]
00007fa0f61ced76  mov r11, [r15+0xB8]
00007fa0f61ced7d  mov [r13+rax*1], r12
00007fa0f61ced82  lea rax, [r14+0x128]
00007fa0f61ced89  mov [r13+rax*1], r11
00007fa0f61ced8e  lea rax, [r14+0x130]
00007fa0f61ced95  mov r12, [r15+0xB0]
00007fa0f61ced9c  mov r11, [r15+0xA8]
00007fa0f61ceda3  mov [r13+rax*1], r12
00007fa0f61ceda8  lea rax, [r14+0x138]
00007fa0f61cedaf  mov [r13+rax*1], r11
00007fa0f61cedb4  lea rax, [r14+0x140]
00007fa0f61cedbb  mov r12, [r15+0xA0]
00007fa0f61cedc2  mov r11, [r15+0x98]
00007fa0f61cedc9  mov [r13+rax*1], r12
00007fa0f61cedce  lea rax, [r14+0x148]
00007fa0f61cedd5  mov [r13+rax*1], r11
00007fa0f61cedda  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cede2  jz 0x00007FA0F61CEE80
00007fa0f61cede8  nop [rax+rax*1], ax
00007fa0f61cedf1  nop [rax+rax*1], eax
00007fa0f61cedf9  mov eax, 0x410380
00007fa0f61cedfe  mov [r15+0x100], rax
00007fa0f61cee05  jmp 0x00007FA0F5FFE110
00007fa0f61cee0a  int3
00007fa0f61cee0b  call 0x00007FA0F60C0370
00007fa0f61cee10  jmp 0x00007FA0F61CED01
00007fa0f61cee15  call 0x00007FA0F600BC20
00007fa0f61cee1a  jmp 0x00007FA0F61CED36
00007fa0f61cee1f  call 0x00007FA0F600A9A0
00007fa0f61cee24  jmp 0x00007FA0F61CED42
00007fa0f61cee29  call 0x00007FA0F600BC20
00007fa0f61cee2e  jmp 0x00007FA0F61CED5C
00007fa0f61cee33  call 0x00007FA0F600A9A0
00007fa0f61cee38  jmp 0x00007FA0F61CED68
00007fa0f61cee3d  call 0x00007FA0F600BC20
00007fa0f61cee42  jmp 0x00007FA0F61CED82
00007fa0f61cee47  call 0x00007FA0F600A9A0
00007fa0f61cee4c  jmp 0x00007FA0F61CED8E
00007fa0f61cee51  call 0x00007FA0F600BC20
00007fa0f61cee56  jmp 0x00007FA0F61CEDA8
00007fa0f61cee5b  call 0x00007FA0F600A9A0
00007fa0f61cee60  jmp 0x00007FA0F61CEDB4
00007fa0f61cee65  call 0x00007FA0F600BC20
00007fa0f61cee6a  jmp 0x00007FA0F61CEDCE
00007fa0f61cee6f  call 0x00007FA0F600A9A0
00007fa0f61cee74  jmp 0x00007FA0F61CEDDA
00007fa0f61cee79  int3
00007fa0f61cee7a  nop [rax+rax*1], ax
00007fa0f61cee80  mov rax, [r15+0x08]
00007fa0f61cee84  movzx r14d, byte ptr [r13+rax*1]
00007fa0f61cee8a  movzx r14d, r14b
00007fa0f61cee8e  mov [rsp+0x10], r14d
00007fa0f61cee93  mov r14d, r14d
00007fa0f61cee96  mov [r15+0x58], r14
00007fa0f61cee9a  lea r14, [rax+0x01]
00007fa0f61cee9e  mov [r15+0x08], r14
00007fa0f61ceea2  mov rax, [r15+0x88]
00007fa0f61ceea9  lea r14, [rax+0x01]
00007fa0f61ceead  mov r12, [r15]
00007fa0f61ceeb0  lea r11, [r12+0x68]
00007fa0f61ceeb5  mov [r13+r11*1], r14
00007fa0f61ceeba  lea r14, [r12+rax*1]
00007fa0f61ceebe  mov [r15+0x60], r14
00007fa0f61ceec2  lea rax, [r14+0x28]
00007fa0f61ceec6  mov r11d, [rsp+0x10]
00007fa0f61ceecb  movzx r14d, r11b
00007fa0f61ceecf  mov [r13+rax*1], r14b
00007fa0f61ceed4  lea rax, [r12+0x68]
00007fa0f61ceed9  mov r14, [r13+rax*1]
00007fa0f61ceede  mov [r15+0x88], r14
00007fa0f61ceee5  xor eax, eax
00007fa0f61ceee7  mov r12d, 0x40
00007fa0f61ceeed  cmp r14, r12
00007fa0f61ceef0  cmc
00007fa0f61ceef1  lahf
00007fa0f61ceef2  seto al
00007fa0f61ceef5  mov [r15+0x108], eax
00007fa0f61ceefc  mov eax, [r15+0x108]
00007fa0f61cef03  sahf
00007fa0f61cef04  jnz 0x00007FA0F61CEF36
00007fa0f61cef06  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cef0e  jz 0x00007FA0F61CF020
00007fa0f61cef14  nop [rax+rax*1], ax
00007fa0f61cef1d  nop [rax+rax*1], eax
00007fa0f61cef25  mov eax, 0x4103A0
00007fa0f61cef2a  mov [r15+0x100], rax
00007fa0f61cef31  jmp 0x00007FA0F5FFE110
00007fa0f61cef36  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cef3e  jz 0x00007FA0F61CEF90
00007fa0f61cef44  nop [rax+rax*1], ax
00007fa0f61cef4d  nop [rax+rax*1], eax
00007fa0f61cef55  mov eax, 0x410378
00007fa0f61cef5a  mov [r15+0x100], rax
00007fa0f61cef61  jmp 0x00007FA0F5FFE110
00007fa0f61cef66  int3
00007fa0f61cef67  call 0x00007FA0F600D860
00007fa0f61cef6c  jmp 0x00007FA0F61CEE8A
00007fa0f61cef71  call 0x00007FA0F60B36E0
00007fa0f61cef76  jmp 0x00007FA0F61CEEBA
00007fa0f61cef7b  call 0x00007FA0F600DD60
00007fa0f61cef80  jmp 0x00007FA0F61CEED4
00007fa0f61cef85  call 0x00007FA0F600DC20
00007fa0f61cef8a  jmp 0x00007FA0F61CEEDE
00007fa0f61cef8f  int3
00007fa0f61cef90  mov rax, [r15+0x10]
00007fa0f61cef94  lea r14, [rax-0x01]
00007fa0f61cef98  mov [r15+0x10], r14
00007fa0f61cef9c  test r14, r14
00007fa0f61cef9f  setz r14b
00007fa0f61cefa3  movzx r14, r14b
00007fa0f61cefa7  mov [rsp+0x414], r14b
00007fa0f61cefaf  cmp byte ptr [rsp+0x414], 0x00
00007fa0f61cefb7  jz 0x00007FA0F61CEFE9
00007fa0f61cefb9  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cefc1  jz 0x00007FA0F61D0520
00007fa0f61cefc7  nop [rax+rax*1], ax
00007fa0f61cefd0  nop [rax+rax*1], eax
00007fa0f61cefd8  mov eax, 0x410598
00007fa0f61cefdd  mov [r15+0x100], rax
00007fa0f61cefe4  jmp 0x00007FA0F5FFE110
00007fa0f61cefe9  cmp dword ptr [r15+0x318], 0x00
00007fa0f61ceff1  jz 0x00007FA0F61CEE80
00007fa0f61ceff7  nop [rax+rax*1], ax
00007fa0f61cf000  nop [rax+rax*1], eax
00007fa0f61cf008  mov eax, 0x410380
00007fa0f61cf00d  mov [r15+0x100], rax
00007fa0f61cf014  jmp 0x00007FA0F5FFE110
00007fa0f61cf019  int3
00007fa0f61cf01a  int3
00007fa0f61cf01b  nop [rax+rax*1], eax
00007fa0f61cf020  mov rax, [r15+0x40]
00007fa0f61cf024  movzx r14d, byte ptr [r13+rax*1]
00007fa0f61cf02a  movaps xmm1, [r15+0x110]
00007fa0f61cf032  pinsrb xmm1, r14d, 0x00
00007fa0f61cf039  lea r14, [rax+0x01]
00007fa0f61cf03d  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf043  movaps xmm15, [r15+0x120]
00007fa0f61cf04b  pinsrb xmm15, r12d, 0x00
00007fa0f61cf052  lea r14, [rax+0x02]
00007fa0f61cf056  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf05c  movaps xmm14, [r15+0x130]
00007fa0f61cf064  pinsrb xmm14, r12d, 0x00
00007fa0f61cf06b  lea r14, [rax+0x03]
00007fa0f61cf06f  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf075  movaps xmm13, [r15+0x140]
00007fa0f61cf07d  pinsrb xmm13, r12d, 0x00
00007fa0f61cf084  lea r14, [rax+0x04]
00007fa0f61cf088  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf08e  pinsrb xmm1, r12d, 0x01
00007fa0f61cf095  lea r14, [rax+0x05]
00007fa0f61cf099  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf09f  pinsrb xmm15, r12d, 0x01
00007fa0f61cf0a6  lea r14, [rax+0x06]
00007fa0f61cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf0b0  pinsrb xmm14, r12d, 0x01
00007fa0f61cf0b7  lea r14, [rax+0x07]
00007fa0f61cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf0c1  pinsrb xmm13, r12d, 0x01
00007fa0f61cf0c8  lea r14, [rax+0x08]
00007fa0f61cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf0d2  pinsrb xmm1, r12d, 0x02
00007fa0f61cf0d9  lea r14, [rax+0x09]
00007fa0f61cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf0e3  pinsrb xmm15, r12d, 0x02
00007fa0f61cf0ea  lea r14, [rax+0x0A]
00007fa0f61cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf0f4  pinsrb xmm14, r12d, 0x02
00007fa0f61cf0fb  lea r14, [rax+0x0B]
00007fa0f61cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf105  pinsrb xmm13, r12d, 0x02
00007fa0f61cf10c  lea r14, [rax+0x0C]
00007fa0f61cf110  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf116  pinsrb xmm1, r12d, 0x03
00007fa0f61cf11d  lea r14, [rax+0x0D]
00007fa0f61cf121  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf127  pinsrb xmm15, r12d, 0x03
00007fa0f61cf12e  lea r14, [rax+0x0E]
00007fa0f61cf132  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf138  pinsrb xmm14, r12d, 0x03
00007fa0f61cf13f  lea r14, [rax+0x0F]
00007fa0f61cf143  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf149  pinsrb xmm13, r12d, 0x03
00007fa0f61cf150  lea r14, [rax+0x10]
00007fa0f61cf154  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf15a  pinsrb xmm1, r12d, 0x04
00007fa0f61cf161  lea r14, [rax+0x11]
00007fa0f61cf165  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf16b  pinsrb xmm15, r12d, 0x04
00007fa0f61cf172  lea r14, [rax+0x12]
00007fa0f61cf176  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf17c  pinsrb xmm14, r12d, 0x04
00007fa0f61cf183  lea r14, [rax+0x13]
00007fa0f61cf187  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf18d  pinsrb xmm13, r12d, 0x04
00007fa0f61cf194  lea r14, [rax+0x14]
00007fa0f61cf198  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf19e  pinsrb xmm1, r12d, 0x05
00007fa0f61cf1a5  lea r14, [rax+0x15]
00007fa0f61cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf1af  pinsrb xmm15, r12d, 0x05
00007fa0f61cf1b6  lea r14, [rax+0x16]
00007fa0f61cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf1c0  pinsrb xmm14, r12d, 0x05
00007fa0f61cf1c7  lea r14, [rax+0x17]
00007fa0f61cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf1d1  pinsrb xmm13, r12d, 0x05
00007fa0f61cf1d8  lea r14, [rax+0x18]
00007fa0f61cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf1e2  pinsrb xmm1, r12d, 0x06
00007fa0f61cf1e9  lea r14, [rax+0x19]
00007fa0f61cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf1f3  pinsrb xmm15, r12d, 0x06
00007fa0f61cf1fa  lea r14, [rax+0x1A]
00007fa0f61cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf204  pinsrb xmm14, r12d, 0x06
00007fa0f61cf20b  lea r14, [rax+0x1B]
00007fa0f61cf20f  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf215  pinsrb xmm13, r12d, 0x06
00007fa0f61cf21c  lea r14, [rax+0x1C]
00007fa0f61cf220  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf226  pinsrb xmm1, r12d, 0x07
00007fa0f61cf22d  lea r14, [rax+0x1D]
00007fa0f61cf231  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf237  pinsrb xmm15, r12d, 0x07
00007fa0f61cf23e  lea r14, [rax+0x1E]
00007fa0f61cf242  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf248  pinsrb xmm14, r12d, 0x07
00007fa0f61cf24f  lea r14, [rax+0x1F]
00007fa0f61cf253  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf259  pinsrb xmm13, r12d, 0x07
00007fa0f61cf260  lea r14, [rax+0x20]
00007fa0f61cf264  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf26a  pinsrb xmm1, r12d, 0x08
00007fa0f61cf271  lea r14, [rax+0x21]
00007fa0f61cf275  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf27b  pinsrb xmm15, r12d, 0x08
00007fa0f61cf282  lea r14, [rax+0x22]
00007fa0f61cf286  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf28c  pinsrb xmm14, r12d, 0x08
00007fa0f61cf293  lea r14, [rax+0x23]
00007fa0f61cf297  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf29d  pinsrb xmm13, r12d, 0x08
00007fa0f61cf2a4  lea r14, [rax+0x24]
00007fa0f61cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf2ae  pinsrb xmm1, r12d, 0x09
00007fa0f61cf2b5  lea r14, [rax+0x25]
00007fa0f61cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf2bf  pinsrb xmm15, r12d, 0x09
00007fa0f61cf2c6  lea r14, [rax+0x26]
00007fa0f61cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf2d0  pinsrb xmm14, r12d, 0x09
00007fa0f61cf2d7  lea r14, [rax+0x27]
00007fa0f61cf2db  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf2e1  pinsrb xmm13, r12d, 0x09
00007fa0f61cf2e8  lea r14, [rax+0x28]
00007fa0f61cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf2f2  pinsrb xmm1, r12d, 0x0A
00007fa0f61cf2f9  lea r14, [rax+0x29]
00007fa0f61cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf303  pinsrb xmm15, r12d, 0x0A
00007fa0f61cf30a  lea r14, [rax+0x2A]
00007fa0f61cf30e  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf314  pinsrb xmm14, r12d, 0x0A
00007fa0f61cf31b  lea r14, [rax+0x2B]
00007fa0f61cf31f  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf325  pinsrb xmm13, r12d, 0x0A
00007fa0f61cf32c  lea r14, [rax+0x2C]
00007fa0f61cf330  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf336  pinsrb xmm1, r12d, 0x0B
00007fa0f61cf33d  lea r14, [rax+0x2D]
00007fa0f61cf341  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf347  pinsrb xmm15, r12d, 0x0B
00007fa0f61cf34e  lea r14, [rax+0x2E]
00007fa0f61cf352  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf358  pinsrb xmm14, r12d, 0x0B
00007fa0f61cf35f  lea r14, [rax+0x2F]
00007fa0f61cf363  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf369  pinsrb xmm13, r12d, 0x0B
00007fa0f61cf370  lea r14, [rax+0x30]
00007fa0f61cf374  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf37a  pinsrb xmm1, r12d, 0x0C
00007fa0f61cf381  lea r14, [rax+0x31]
00007fa0f61cf385  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf38b  pinsrb xmm15, r12d, 0x0C
00007fa0f61cf392  lea r14, [rax+0x32]
00007fa0f61cf396  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf39c  pinsrb xmm14, r12d, 0x0C
00007fa0f61cf3a3  lea r14, [rax+0x33]
00007fa0f61cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf3ad  pinsrb xmm13, r12d, 0x0C
00007fa0f61cf3b4  lea r14, [rax+0x34]
00007fa0f61cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf3be  pinsrb xmm1, r12d, 0x0D
00007fa0f61cf3c5  lea r14, [rax+0x35]
00007fa0f61cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf3cf  pinsrb xmm15, r12d, 0x0D
00007fa0f61cf3d6  lea r14, [rax+0x36]
00007fa0f61cf3da  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf3e0  pinsrb xmm14, r12d, 0x0D
00007fa0f61cf3e7  lea r14, [rax+0x37]
00007fa0f61cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf3f1  pinsrb xmm13, r12d, 0x0D
00007fa0f61cf3f8  lea r14, [rax+0x38]
00007fa0f61cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf402  pinsrb xmm1, r12d, 0x0E
00007fa0f61cf409  lea r14, [rax+0x39]
00007fa0f61cf40d  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf413  pinsrb xmm15, r12d, 0x0E
00007fa0f61cf41a  lea r14, [rax+0x3A]
00007fa0f61cf41e  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf424  pinsrb xmm14, r12d, 0x0E
00007fa0f61cf42b  lea r14, [rax+0x3B]
00007fa0f61cf42f  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf435  pinsrb xmm13, r12d, 0x0E
00007fa0f61cf43c  lea r14, [rax+0x3C]
00007fa0f61cf440  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf446  pinsrb xmm1, r12d, 0x0F
00007fa0f61cf44d  movaps [r15+0x110], xmm1
00007fa0f61cf455  lea r14, [rax+0x3D]
00007fa0f61cf459  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf45f  pinsrb xmm15, r12d, 0x0F
00007fa0f61cf466  movaps [r15+0x120], xmm15
00007fa0f61cf46e  lea r14, [rax+0x3E]
00007fa0f61cf472  movzx r12d, byte ptr [r13+r14*1]
00007fa0f61cf478  pinsrb xmm14, r12d, 0x0F
00007fa0f61cf47f  movaps [r15+0x130], xmm14
00007fa0f61cf487  lea r14, [rax+0x3F]
00007fa0f61cf48b  movzx eax, byte ptr [r13+r14*1]
00007fa0f61cf491  pinsrb xmm13, eax, 0x0F
00007fa0f61cf498  movaps [r15+0x140], xmm13
00007fa0f61cf4a0  movq xmm1, qword ptr [r15+0x120]
00007fa0f61cf4a9  pmovzxbw xmm1, xmm1
00007fa0f61cf4ae  psllw xmm1, 0x00
00007fa0f61cf4b3  movaps [r15+0x150], xmm1
00007fa0f61cf4bb  movq xmm1, qword ptr [r15+0x130]
00007fa0f61cf4c4  pmovzxbw xmm1, xmm1
00007fa0f61cf4c9  psllw xmm1, 0x00
00007fa0f61cf4ce  movaps [r15+0x160], xmm1
00007fa0f61cf4d6  movq xmm1, qword ptr [r15+0x110]
00007fa0f61cf4df  pmovzxbw xmm1, xmm1
00007fa0f61cf4e4  psllw xmm1, 0x00
00007fa0f61cf4e9  movaps [r15+0x170], xmm1
00007fa0f61cf4f1  movaps xmm15, [r15+0x110]
00007fa0f61cf4f9  pextrq rax, xmm15, 0x01
00007fa0f61cf500  movq xmm15, rax
00007fa0f61cf505  pmovzxbw xmm15, xmm15
00007fa0f61cf50b  psllw xmm15, 0x00
00007fa0f61cf511  movaps [r15+0x180], xmm15
00007fa0f61cf519  movaps xmm14, [r15+0x120]
00007fa0f61cf521  pextrq rax, xmm14, 0x01
00007fa0f61cf528  movq xmm14, rax
00007fa0f61cf52d  pmovzxbw xmm14, xmm14
00007fa0f61cf533  psllw xmm14, 0x00
00007fa0f61cf539  movaps [r15+0x210], xmm14
00007fa0f61cf541  movaps xmm13, [r15+0x130]
00007fa0f61cf549  pextrq rax, xmm13, 0x01
00007fa0f61cf550  movq xmm13, rax
00007fa0f61cf555  pmovzxbw xmm13, xmm13
00007fa0f61cf55b  psllw xmm13, 0x00
00007fa0f61cf561  movaps [r15+0x220], xmm13
00007fa0f61cf569  movq xmm12, qword ptr [r15+0x140]
00007fa0f61cf572  pmovzxbw xmm12, xmm12
00007fa0f61cf578  psllw xmm12, 0x00
00007fa0f61cf57e  movaps [r15+0x250], xmm12
00007fa0f61cf586  movaps xmm12, [r15+0x140]
00007fa0f61cf58e  pextrq rax, xmm12, 0x01
00007fa0f61cf595  movq xmm12, rax
00007fa0f61cf59a  pmovzxbw xmm12, xmm12
00007fa0f61cf5a0  psllw xmm12, 0x00
00007fa0f61cf5a6  movaps [r15+0x110], xmm12
00007fa0f61cf5ae  movq xmm11, qword ptr [r15+0x150]
00007fa0f61cf5b7  pmovzxwd xmm11, xmm11
00007fa0f61cf5bd  pslld xmm11, 0x10
00007fa0f61cf5c3  movq xmm10, qword ptr [r15+0x160]
00007fa0f61cf5cc  pmovzxwd xmm10, xmm10
00007fa0f61cf5d2  pslld xmm10, 0x08
00007fa0f61cf5d8  pextrq rax, xmm1, 0x01
00007fa0f61cf5df  movq xmm1, rax
00007fa0f61cf5e4  pmovzxwd xmm1, xmm1
00007fa0f61cf5e9  pslld xmm1, 0x00
00007fa0f61cf5ee  movaps [r15+0x260], xmm1
00007fa0f61cf5f6  pextrq rax, xmm15, 0x01
00007fa0f61cf5fd  movq xmm15, rax
00007fa0f61cf602  pmovzxwd xmm15, xmm15
00007fa0f61cf608  pslld xmm15, 0x00
00007fa0f61cf60e  movaps [r15+0x270], xmm15
00007fa0f61cf616  movq xmm9, qword ptr [r15+0x170]
00007fa0f61cf61f  pmovzxwd xmm9, xmm9
00007fa0f61cf625  pslld xmm9, 0x00
00007fa0f61cf62b  pextrq rax, xmm14, 0x01
00007fa0f61cf632  movq xmm14, rax
00007fa0f61cf637  pmovzxwd xmm14, xmm14
00007fa0f61cf63d  pslld xmm14, 0x10
00007fa0f61cf643  movaps [r15+0x280], xmm14
00007fa0f61cf64b  movq xmm8, qword ptr [r15+0x180]
00007fa0f61cf654  pmovzxwd xmm8, xmm8
00007fa0f61cf65a  pslld xmm8, 0x00
00007fa0f61cf660  movq xmm7, qword ptr [r15+0x210]
00007fa0f61cf669  pmovzxwd xmm7, xmm7
00007fa0f61cf66e  pslld xmm7, 0x10
00007fa0f61cf673  movaps xmm6, [r15+0x150]
00007fa0f61cf67b  pextrq rax, xmm6, 0x01
00007fa0f61cf682  movq xmm6, rax
00007fa0f61cf687  pmovzxwd xmm6, xmm6
00007fa0f61cf68c  pslld xmm6, 0x10
00007fa0f61cf691  por xmm11, xmm10
00007fa0f61cf696  movaps [r15+0x230], xmm11
00007fa0f61cf69e  pextrq rax, xmm13, 0x01
00007fa0f61cf6a5  movq xmm13, rax
00007fa0f61cf6aa  pmovzxwd xmm13, xmm13
00007fa0f61cf6b0  pslld xmm13, 0x08
00007fa0f61cf6b6  movaps [r15+0x240], xmm13
00007fa0f61cf6be  movq xmm10, qword ptr [r15+0x220]
00007fa0f61cf6c7  pmovzxwd xmm10, xmm10
00007fa0f61cf6cd  pslld xmm10, 0x08
00007fa0f61cf6d3  movaps xmm5, [r15+0x160]
00007fa0f61cf6db  pextrq rax, xmm5, 0x01
00007fa0f61cf6e2  movq xmm5, rax
00007fa0f61cf6e7  pmovzxwd xmm5, xmm5
00007fa0f61cf6ec  pslld xmm5, 0x08
00007fa0f61cf6f1  pslld xmm9, 0x18
00007fa0f61cf6f7  pslld xmm15, 0x18
00007fa0f61cf6fd  pslld xmm8, 0x18
00007fa0f61cf703  movq xmm4, qword ptr [r15+0x250]
00007fa0f61cf70c  pmovzxwd xmm4, xmm4
00007fa0f61cf711  pslld xmm4, 0x00
00007fa0f61cf716  por xmm14, xmm13
00007fa0f61cf71b  por xmm7, xmm10
00007fa0f61cf720  movaps [r15+0x210], xmm7
00007fa0f61cf728  pslld xmm1, 0x18
00007fa0f61cf72d  movaps [r15+0x220], xmm1
00007fa0f61cf735  por xmm6, xmm5
00007fa0f61cf739  por xmm11, xmm9
00007fa0f61cf73e  movaps [r15+0x160], xmm11
00007fa0f61cf746  pextrq rax, xmm12, 0x01
00007fa0f61cf74d  movq xmm13, rax
00007fa0f61cf752  pmovzxwd xmm13, xmm13
00007fa0f61cf758  pslld xmm13, 0x00
00007fa0f61cf75e  movaps [r15+0x170], xmm13
00007fa0f61cf766  movq xmm12, qword ptr [r15+0x110]
00007fa0f61cf76f  pmovzxwd xmm12, xmm12
00007fa0f61cf775  pslld xmm12, 0x00
00007fa0f61cf77b  por xmm14, xmm15
00007fa0f61cf780  por xmm7, xmm8
00007fa0f61cf785  movaps xmm15, [r15+0x250]
00007fa0f61cf78d  pextrq rax, xmm15, 0x01
00007fa0f61cf794  movq xmm15, rax
00007fa0f61cf799  pmovzxwd xmm15, xmm15
00007fa0f61cf79f  pslld xmm15, 0x00
00007fa0f61cf7a5  movaps [r15+0x180], xmm15
00007fa0f61cf7ad  por xmm6, xmm1
00007fa0f61cf7b1  movaps [r15+0x150], xmm6
00007fa0f61cf7b9  por xmm11, xmm4
00007fa0f61cf7be  movaps [r15+0x140], xmm11
00007fa0f61cf7c6  por xmm7, xmm12
00007fa0f61cf7cb  movaps [r15+0x110], xmm7
00007fa0f61cf7d3  por xmm14, xmm13
00007fa0f61cf7d8  movaps [r15+0x120], xmm14
00007fa0f61cf7e0  por xmm6, xmm15
00007fa0f61cf7e5  movaps [r15+0x130], xmm6
00007fa0f61cf7ed  mov rax, [r15+0xF8]
00007fa0f61cf7f4  lea r14, [rax+0x20]
00007fa0f61cf7f8  movups [r13+r14*1], xmm7
00007fa0f61cf7fe  lea r14, [rax+0x30]
00007fa0f61cf802  movups [r13+r14*1], xmm14
00007fa0f61cf808  movups [r13+rax*1], xmm11
00007fa0f61cf80e  lea r14, [rax+0x10]
00007fa0f61cf812  movups [r13+r14*1], xmm6
00007fa0f61cf818  mov r14d, [r13+rax*1]
00007fa0f61cf81d  mov rax, [r15+0x48]
00007fa0f61cf821  mov [r15+0x68], rax
00007fa0f61cf825  mov qword ptr [r15+0x58], 0x04
00007fa0f61cf82d  lea r12, [rax+0x04]
00007fa0f61cf831  mov r11d, [r13+r12*1]
00007fa0f61cf836  mov [rsp+0x10], r11d
00007fa0f61cf83b  mov r11d, r11d
00007fa0f61cf83e  mov [r15+0x70], r11
00007fa0f61cf842  lea r12, [rax+0x38]
00007fa0f61cf846  mov r11d, [r13+r12*1]
00007fa0f61cf84b  lea r12, [rax+0x24]
00007fa0f61cf84f  mov r10d, [r13+r12*1]
00007fa0f61cf854  mov [rsp+0x20], r10d
00007fa0f61cf859  mov r10d, r10d
00007fa0f61cf85c  mov [r15+0x90], r10
00007fa0f61cf863  mov [rsp+0x30], rax
00007fa0f61cf868  xor eax, eax
00007fa0f61cf86a  mov r12d, 0x04
00007fa0f61cf870  mov r10d, 0xC0
00007fa0f61cf876  cmp r12, r10
00007fa0f61cf879  cmc
00007fa0f61cf87a  lahf
00007fa0f61cf87b  seto al
00007fa0f61cf87e  mov [r15+0x108], eax
00007fa0f61cf885  mov eax, [rsp+0x10]
00007fa0f61cf889  mov r12d, [rsp+0x10]
00007fa0f61cf88e  shrd eax, r12d, 0x07
00007fa0f61cf893  mov [rsp+0x10], r11d
00007fa0f61cf898  mov r10d, [rsp+0x10]
00007fa0f61cf89d  shrd r11d, r10d, 0x11
00007fa0f61cf8a2  mov r9d, [rsp+0x20]
00007fa0f61cf8a7  lea r8d, [r9d+r14d*1]
00007fa0f61cf8ac  rorx r14d, r12d, 0x12
00007fa0f61cf8b2  xor eax, r14d
00007fa0f61cf8b5  rorx r14d, r10d, 0x13
00007fa0f61cf8bb  xor r11d, r14d
00007fa0f61cf8be  mov [rsp+0x10], r11d
00007fa0f61cf8c3  mov r11d, r11d
00007fa0f61cf8c6  mov [r15+0x88], r11
00007fa0f61cf8cd  mov [rsp+0x20], r12d
00007fa0f61cf8d2  shr r12d, 0x03
00007fa0f61cf8d6  xor eax, r12d
00007fa0f61cf8d9  mov [rsp+0x40], eax
00007fa0f61cf8dd  mov eax, eax
00007fa0f61cf8df  mov [r15+0x80], rax
00007fa0f61cf8e6  shr r10d, 0x0A
00007fa0f61cf8ea  mov eax, [rsp+0x10]
00007fa0f61cf8ee  xor eax, r10d
00007fa0f61cf8f1  mov [rsp+0x10], eax
00007fa0f61cf8f5  mov eax, eax
00007fa0f61cf8f7  mov [r15+0x78], rax
00007fa0f61cf8fb  mov eax, [rsp+0x40]
00007fa0f61cf8ff  lea r14d, [r8d+eax*1]
00007fa0f61cf904  mov eax, [rsp+0x10]
00007fa0f61cf908  lea r12d, [r14d+eax*1]
00007fa0f61cf90d  mov rax, [rsp+0x30]
00007fa0f61cf912  lea r14, [rax+0x40]
00007fa0f61cf916  mov [r13+r14*1], r12d
00007fa0f61cf91b  mov eax, [rsp+0x20]
00007fa0f61cf91f  mov eax, eax
00007fa0f61cf921  mov [r15+0x60], rax
00007fa0f61cf925  mov eax, [r15+0x108]
00007fa0f61cf92c  sahf
00007fa0f61cf92d  jnz 0x00007FA0F61CF95F
00007fa0f61cf92f  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cf937  jz 0x00007FA0F61CFE20
00007fa0f61cf93d  nop [rax+rax*1], ax
00007fa0f61cf946  nop [rax+rax*1], eax
00007fa0f61cf94e  mov eax, 0x41049C
00007fa0f61cf953  mov [r15+0x100], rax
00007fa0f61cf95a  jmp 0x00007FA0F5FFE110
00007fa0f61cf95f  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cf967  jz 0x00007FA0F61CFC70
00007fa0f61cf96d  nop [rax+rax*1], ax
00007fa0f61cf976  nop [rax+rax*1], eax
00007fa0f61cf97e  mov eax, 0x410454
00007fa0f61cf983  mov [r15+0x100], rax
00007fa0f61cf98a  jmp 0x00007FA0F5FFE110
00007fa0f61cf98f  int3
00007fa0f61cf990  call 0x00007FA0F600D860
00007fa0f61cf995  jmp 0x00007FA0F61CF02A
00007fa0f61cf99a  call 0x00007FA0F60E2420
00007fa0f61cf99f  jmp 0x00007FA0F61CF043
00007fa0f61cf9a4  call 0x00007FA0F60E2420
00007fa0f61cf9a9  jmp 0x00007FA0F61CF05C
00007fa0f61cf9ae  call 0x00007FA0F60E2420
00007fa0f61cf9b3  jmp 0x00007FA0F61CF075
00007fa0f61cf9b8  call 0x00007FA0F60E2420
00007fa0f61cf9bd  jmp 0x00007FA0F61CF08E
00007fa0f61cf9c2  call 0x00007FA0F60E2420
00007fa0f61cf9c7  jmp 0x00007FA0F61CF09F
00007fa0f61cf9cc  call 0x00007FA0F60E2420
00007fa0f61cf9d1  jmp 0x00007FA0F61CF0B0
00007fa0f61cf9d6  call 0x00007FA0F60E2420
00007fa0f61cf9db  jmp 0x00007FA0F61CF0C1
00007fa0f61cf9e0  call 0x00007FA0F60E2420
00007fa0f61cf9e5  jmp 0x00007FA0F61CF0D2
00007fa0f61cf9ea  call 0x00007FA0F60E2420
00007fa0f61cf9ef  jmp 0x00007FA0F61CF0E3
00007fa0f61cf9f4  call 0x00007FA0F60E2420
00007fa0f61cf9f9  jmp 0x00007FA0F61CF0F4
00007fa0f61cf9fe  call 0x00007FA0F60E2420
00007fa0f61cfa03  jmp 0x00007FA0F61CF105
00007fa0f61cfa08  call 0x00007FA0F60E2420
00007fa0f61cfa0d  jmp 0x00007FA0F61CF116
00007fa0f61cfa12  call 0x00007FA0F60E2420
00007fa0f61cfa17  jmp 0x00007FA0F61CF127
00007fa0f61cfa1c  call 0x00007FA0F60E2420
00007fa0f61cfa21  jmp 0x00007FA0F61CF138
00007fa0f61cfa26  call 0x00007FA0F60E2420
00007fa0f61cfa2b  jmp 0x00007FA0F61CF149
00007fa0f61cfa30  call 0x00007FA0F60E2420
00007fa0f61cfa35  jmp 0x00007FA0F61CF15A
00007fa0f61cfa3a  call 0x00007FA0F60E2420
00007fa0f61cfa3f  jmp 0x00007FA0F61CF16B
00007fa0f61cfa44  call 0x00007FA0F60E2420
00007fa0f61cfa49  jmp 0x00007FA0F61CF17C
00007fa0f61cfa4e  call 0x00007FA0F60E2420
00007fa0f61cfa53  jmp 0x00007FA0F61CF18D
00007fa0f61cfa58  call 0x00007FA0F60E2420
00007fa0f61cfa5d  jmp 0x00007FA0F61CF19E
00007fa0f61cfa62  call 0x00007FA0F60E2420
00007fa0f61cfa67  jmp 0x00007FA0F61CF1AF
00007fa0f61cfa6c  call 0x00007FA0F60E2420
00007fa0f61cfa71  jmp 0x00007FA0F61CF1C0
00007fa0f61cfa76  call 0x00007FA0F60E2420
00007fa0f61cfa7b  jmp 0x00007FA0F61CF1D1
00007fa0f61cfa80  call 0x00007FA0F60E2420
00007fa0f61cfa85  jmp 0x00007FA0F61CF1E2
00007fa0f61cfa8a  call 0x00007FA0F60E2420
00007fa0f61cfa8f  jmp 0x00007FA0F61CF1F3
00007fa0f61cfa94  call 0x00007FA0F60E2420
00007fa0f61cfa99  jmp 0x00007FA0F61CF204
00007fa0f61cfa9e  call 0x00007FA0F60E2420
00007fa0f61cfaa3  jmp 0x00007FA0F61CF215
00007fa0f61cfaa8  call 0x00007FA0F60E2420
00007fa0f61cfaad  jmp 0x00007FA0F61CF226
00007fa0f61cfab2  call 0x00007FA0F60E2420
00007fa0f61cfab7  jmp 0x00007FA0F61CF237
00007fa0f61cfabc  call 0x00007FA0F60E2420
00007fa0f61cfac1  jmp 0x00007FA0F61CF248
00007fa0f61cfac6  call 0x00007FA0F60E2420
00007fa0f61cfacb  jmp 0x00007FA0F61CF259
00007fa0f61cfad0  call 0x00007FA0F60E2420
00007fa0f61cfad5  jmp 0x00007FA0F61CF26A
00007fa0f61cfada  call 0x00007FA0F60E2420
00007fa0f61cfadf  jmp 0x00007FA0F61CF27B
00007fa0f61cfae4  call 0x00007FA0F60E2420
00007fa0f61cfae9  jmp 0x00007FA0F61CF28C
00007fa0f61cfaee  call 0x00007FA0F60E2420
00007fa0f61cfaf3  jmp 0x00007FA0F61CF29D
00007fa0f61cfaf8  call 0x00007FA0F60E2420
00007fa0f61cfafd  jmp 0x00007FA0F61CF2AE
00007fa0f61cfb02  call 0x00007FA0F60E2420
00007fa0f61cfb07  jmp 0x00007FA0F61CF2BF
00007fa0f61cfb0c  call 0x00007FA0F60E2420
00007fa0f61cfb11  jmp 0x00007FA0F61CF2D0
00007fa0f61cfb16  call 0x00007FA0F60E2420
00007fa0f61cfb1b  jmp 0x00007FA0F61CF2E1
00007fa0f61cfb20  call 0x00007FA0F60E2420
00007fa0f61cfb25  jmp 0x00007FA0F61CF2F2
00007fa0f61cfb2a  call 0x00007FA0F60E2420
00007fa0f61cfb2f  jmp 0x00007FA0F61CF303
00007fa0f61cfb34  call 0x00007FA0F60E2420
00007fa0f61cfb39  jmp 0x00007FA0F61CF314
00007fa0f61cfb3e  call 0x00007FA0F60E2420
00007fa0f61cfb43  jmp 0x00007FA0F61CF325
00007fa0f61cfb48  call 0x00007FA0F60E2420
00007fa0f61cfb4d  jmp 0x00007FA0F61CF336
00007fa0f61cfb52  call 0x00007FA0F60E2420
00007fa0f61cfb57  jmp 0x00007FA0F61CF347
00007fa0f61cfb5c  call 0x00007FA0F60E2420
00007fa0f61cfb61  jmp 0x00007FA0F61CF358
00007fa0f61cfb66  call 0x00007FA0F60E2420
00007fa0f61cfb6b  jmp 0x00007FA0F61CF369
00007fa0f61cfb70  call 0x00007FA0F60E2420
00007fa0f61cfb75  jmp 0x00007FA0F61CF37A
00007fa0f61cfb7a  call 0x00007FA0F60E2420
00007fa0f61cfb7f  jmp 0x00007FA0F61CF38B
00007fa0f61cfb84  call 0x00007FA0F60E2420
00007fa0f61cfb89  jmp 0x00007FA0F61CF39C
00007fa0f61cfb8e  call 0x00007FA0F60E2420
00007fa0f61cfb93  jmp 0x00007FA0F61CF3AD
00007fa0f61cfb98  call 0x00007FA0F60E2420
00007fa0f61cfb9d  jmp 0x00007FA0F61CF3BE
00007fa0f61cfba2  call 0x00007FA0F60E2420
00007fa0f61cfba7  jmp 0x00007FA0F61CF3CF
00007fa0f61cfbac  call 0x00007FA0F60E2420
00007fa0f61cfbb1  jmp 0x00007FA0F61CF3E0
00007fa0f61cfbb6  call 0x00007FA0F60E2420
00007fa0f61cfbbb  jmp 0x00007FA0F61CF3F1
00007fa0f61cfbc0  call 0x00007FA0F60E2420
00007fa0f61cfbc5  jmp 0x00007FA0F61CF402
00007fa0f61cfbca  call 0x00007FA0F60E2420
00007fa0f61cfbcf  jmp 0x00007FA0F61CF413
00007fa0f61cfbd4  call 0x00007FA0F60E2420
00007fa0f61cfbd9  jmp 0x00007FA0F61CF424
00007fa0f61cfbde  call 0x00007FA0F60E2420
00007fa0f61cfbe3  jmp 0x00007FA0F61CF435
00007fa0f61cfbe8  call 0x00007FA0F60E2420
00007fa0f61cfbed  jmp 0x00007FA0F61CF446
00007fa0f61cfbf2  call 0x00007FA0F60E2420
00007fa0f61cfbf7  jmp 0x00007FA0F61CF45F
00007fa0f61cfbfc  call 0x00007FA0F60E2420
00007fa0f61cfc01  jmp 0x00007FA0F61CF478
00007fa0f61cfc06  call 0x00007FA0F60D5610
00007fa0f61cfc0b  jmp 0x00007FA0F61CF491
00007fa0f61cfc10  call 0x00007FA0F60DC580
00007fa0f61cfc15  jmp 0x00007FA0F61CF7FE
00007fa0f61cfc1a  call 0x00007FA0F60E46C0
00007fa0f61cfc1f  jmp 0x00007FA0F61CF808
00007fa0f61cfc24  call 0x00007FA0F6009E90
00007fa0f61cfc29  jmp 0x00007FA0F61CF80E
00007fa0f61cfc2e  call 0x00007FA0F60DB310
00007fa0f61cfc33  jmp 0x00007FA0F61CF818
00007fa0f61cfc38  call 0x00007FA0F600DAE0
00007fa0f61cfc3d  jmp 0x00007FA0F61CF81D
00007fa0f61cfc42  call 0x00007FA0F60C0230
00007fa0f61cfc47  jmp 0x00007FA0F61CF836
00007fa0f61cfc4c  call 0x00007FA0F60C0230
00007fa0f61cfc51  jmp 0x00007FA0F61CF84B
00007fa0f61cfc56  call 0x00007FA0F60BEFC0
00007fa0f61cfc5b  jmp 0x00007FA0F61CF854
00007fa0f61cfc60  call 0x00007FA0F60E2BA0
00007fa0f61cfc65  jmp 0x00007FA0F61CF91B
00007fa0f61cfc6a  int3
00007fa0f61cfc6b  nop [rax+rax*1], eax
00007fa0f61cfc70  mov rax, [r15+0x48]
00007fa0f61cfc74  mov r14, [r15+0x58]
00007fa0f61cfc78  lea r12, [rax+r14*1]
00007fa0f61cfc7c  mov [r15+0x68], r12
00007fa0f61cfc80  lea rax, [r14+0x04]
00007fa0f61cfc84  mov [r15+0x58], rax
00007fa0f61cfc88  lea r14, [r12+0x04]
00007fa0f61cfc8d  mov r11d, [r13+r14*1]
00007fa0f61cfc92  mov [rsp+0x10], r11d
00007fa0f61cfc97  mov r11d, r11d
00007fa0f61cfc9a  mov [r15+0x70], r11
00007fa0f61cfc9e  lea r14, [r12+0x38]
00007fa0f61cfca3  mov r11d, [r13+r14*1]
00007fa0f61cfca8  lea r14, [r12+0x24]
00007fa0f61cfcad  mov r10d, [r13+r14*1]
00007fa0f61cfcb2  mov [rsp+0x20], r10d
00007fa0f61cfcb7  mov r10d, r10d
00007fa0f61cfcba  mov [r15+0x90], r10
00007fa0f61cfcc1  mov [rsp+0x30], rax
00007fa0f61cfcc6  xor eax, eax
00007fa0f61cfcc8  mov r14, [rsp+0x30]
00007fa0f61cfccd  mov r10d, 0xC0
00007fa0f61cfcd3  cmp r14, r10
00007fa0f61cfcd6  cmc
00007fa0f61cfcd7  lahf
00007fa0f61cfcd8  seto al
00007fa0f61cfcdb  mov [r15+0x108], eax
00007fa0f61cfce2  mov eax, [rsp+0x10]
00007fa0f61cfce6  mov r14d, [rsp+0x10]
00007fa0f61cfceb  shrd eax, r14d, 0x07
00007fa0f61cfcf0  mov [rsp+0x10], r11d
00007fa0f61cfcf5  mov r10d, [rsp+0x10]
00007fa0f61cfcfa  shrd r11d, r10d, 0x11
00007fa0f61cfcff  mov r9d, [r15+0x60]
00007fa0f61cfd03  mov r8d, [rsp+0x20]
00007fa0f61cfd08  lea ebp, [r8d+r9d*1]
00007fa0f61cfd0d  rorx r9d, r14d, 0x12
00007fa0f61cfd13  xor eax, r9d
00007fa0f61cfd16  rorx r9d, r10d, 0x13
00007fa0f61cfd1c  xor r11d, r9d
00007fa0f61cfd1f  mov [rsp+0x10], r11d
00007fa0f61cfd24  mov r11d, r11d
00007fa0f61cfd27  mov [r15+0x88], r11
00007fa0f61cfd2e  mov [rsp+0x20], r14d
00007fa0f61cfd33  shr r14d, 0x03
00007fa0f61cfd37  xor eax, r14d
00007fa0f61cfd3a  mov [rsp+0x30], eax
00007fa0f61cfd3e  mov eax, eax
00007fa0f61cfd40  mov [r15+0x80], rax
00007fa0f61cfd47  shr r10d, 0x0A
00007fa0f61cfd4b  mov eax, [rsp+0x10]
00007fa0f61cfd4f  xor eax, r10d
00007fa0f61cfd52  mov [rsp+0x10], eax
00007fa0f61cfd56  mov eax, eax
00007fa0f61cfd58  mov [r15+0x78], rax
00007fa0f61cfd5c  mov eax, [rsp+0x30]
00007fa0f61cfd60  lea r14d, [ebp+eax*1]
00007fa0f61cfd66  mov eax, [rsp+0x10]
00007fa0f61cfd6a  lea r11d, [r14d+eax*1]
00007fa0f61cfd6f  lea rax, [r12+0x40]
00007fa0f61cfd74  mov [r13+rax*1], r11d
00007fa0f61cfd79  mov eax, [rsp+0x20]
00007fa0f61cfd7d  mov eax, eax
00007fa0f61cfd7f  mov [r15+0x60], rax
00007fa0f61cfd83  mov eax, [r15+0x108]
00007fa0f61cfd8a  sahf
00007fa0f61cfd8b  jnz 0x00007FA0F61CFDBD
00007fa0f61cfd8d  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cfd95  jz 0x00007FA0F61CFE20
00007fa0f61cfd9b  nop [rax+rax*1], ax
00007fa0f61cfda4  nop [rax+rax*1], eax
00007fa0f61cfdac  mov eax, 0x41049C
00007fa0f61cfdb1  mov [r15+0x100], rax
00007fa0f61cfdb8  jmp 0x00007FA0F5FFE110
00007fa0f61cfdbd  cmp dword ptr [r15+0x318], 0x00
00007fa0f61cfdc5  jz 0x00007FA0F61CFC70
00007fa0f61cfdcb  nop [rax+rax*1], ax
00007fa0f61cfdd4  nop [rax+rax*1], eax
00007fa0f61cfddc  mov eax, 0x410454
00007fa0f61cfde1  mov [r15+0x100], rax
00007fa0f61cfde8  jmp 0x00007FA0F5FFE110
00007fa0f61cfded  int3
00007fa0f61cfdee  call 0x00007FA0F60E1430
00007fa0f61cfdf3  jmp 0x00007FA0F61CFC92
00007fa0f61cfdf8  call 0x00007FA0F60E1430
00007fa0f61cfdfd  jmp 0x00007FA0F61CFCA8
00007fa0f61cfe02  call 0x00007FA0F60E01C0
00007fa0f61cfe07  jmp 0x00007FA0F61CFCB2
00007fa0f61cfe0c  call 0x00007FA0F600A860
00007fa0f61cfe11  jmp 0x00007FA0F61CFD79
00007fa0f61cfe16  int3
00007fa0f61cfe17  nop [rax+rax*1], ax
00007fa0f61cfe20  mov rax, [r15]
00007fa0f61cfe23  mov r14d, [r13+rax*1]
00007fa0f61cfe28  lea r12, [rax+0x04]
00007fa0f61cfe2c  mov r11d, [r13+r12*1]
00007fa0f61cfe31  mov [rsp+0x10], r14d
00007fa0f61cfe36  mov r14d, r14d
00007fa0f61cfe39  mov [r15+0x78], r14
00007fa0f61cfe3d  mov [rsp+0x20], r11d
00007fa0f61cfe42  mov r11d, r11d
00007fa0f61cfe45  mov [r15+0x80], r11
00007fa0f61cfe4c  lea r14, [rax+0x08]
00007fa0f61cfe50  mov r12d, [r13+r14*1]
00007fa0f61cfe55  lea r14, [rax+0x0C]
00007fa0f61cfe59  mov r11d, [r13+r14*1]
00007fa0f61cfe5e  mov [rsp+0x30], r12d
00007fa0f61cfe63  mov r12d, r12d
00007fa0f61cfe66  mov [r15+0x70], r12
00007fa0f61cfe6a  mov [rsp+0x40], r11d
00007fa0f61cfe6f  mov r11d, r11d
00007fa0f61cfe72  mov [r15+0x68], r11
00007fa0f61cfe76  lea r14, [rax+0x18]
00007fa0f61cfe7a  mov r12d, [r13+r14*1]
00007fa0f61cfe7f  lea r14, [rax+0x1C]
00007fa0f61cfe83  mov r11d, [r13+r14*1]
00007fa0f61cfe88  mov [rsp+0x50], r12d
00007fa0f61cfe8d  mov r12d, r12d
00007fa0f61cfe90  mov [r15+0x58], r12
00007fa0f61cfe94  mov [rsp+0x60], r11d
00007fa0f61cfe99  mov r11d, r11d
00007fa0f61cfe9c  mov [r15+0x60], r11
00007fa0f61cfea0  lea r14, [rax+0x10]
00007fa0f61cfea4  mov r12d, [r13+r14*1]
00007fa0f61cfea9  lea r14, [rax+0x14]
00007fa0f61cfead  mov eax, [r13+r14*1]
00007fa0f61cfeb2  mov [rsp+0x70], r12d
00007fa0f61cfeb7  mov r12d, r12d
00007fa0f61cfeba  mov [r15+0x18], r12
00007fa0f61cfebe  mov [rsp+0x80], eax
00007fa0f61cfec5  mov eax, eax
00007fa0f61cfec7  mov [r15+0x90], rax
00007fa0f61cfece  mov eax, [rsp+0x70]
00007fa0f61cfed2  mov eax, eax
00007fa0f61cfed4  mov [r15+0x30], rax
00007fa0f61cfed8  mov eax, [rsp+0x50]
00007fa0f61cfedc  mov eax, eax
00007fa0f61cfede  mov [r15+0xA0], rax
00007fa0f61cfee5  mov eax, [rsp+0x30]
00007fa0f61cfee9  mov eax, eax
00007fa0f61cfeeb  mov [r15+0x28], rax
00007fa0f61cfeef  mov eax, [rsp+0x20]
00007fa0f61cfef3  mov eax, eax
00007fa0f61cfef5  mov [r15+0x98], rax
00007fa0f61cfefc  mov eax, [rsp+0x10]
00007fa0f61cff00  mov eax, eax
00007fa0f61cff02  mov [r15+0x38], rax
00007fa0f61cff06  mov eax, [rsp+0x70]
00007fa0f61cff0a  mov r14d, [rsp+0x70]
00007fa0f61cff0f  shrd eax, r14d, 0x06
00007fa0f61cff14  mov [rsp+0x70], r14d
00007fa0f61cff19  mov r12d, [rsp+0x80]
00007fa0f61cff21  and r14d, r12d
00007fa0f61cff24  mov r11d, [rsp+0x10]
00007fa0f61cff29  mov r10d, [rsp+0x10]
00007fa0f61cff2e  shrd r11d, r10d, 0x02
00007fa0f61cff33  mov [rsp+0x10], r12d
00007fa0f61cff38  mov r12d, r12d
00007fa0f61cff3b  mov [r15+0x20], r12
00007fa0f61cff3f  mov r12, [r15+0x50]
00007fa0f61cff43  mov r9d, [r13+r12*1]
00007fa0f61cff48  mov r12d, [rsp+0x50]
00007fa0f61cff4d  mov r8d, [rsp+0x70]
00007fa0f61cff52  andn ebp, r8d, r12d
00007fa0f61cff57  mov edi, [rsp+0x60]
00007fa0f61cff5b  lea esi, [r14d+edi*1]
00007fa0f61cff60  rorx r14d, r8d, 0x0B
00007fa0f61cff66  xor eax, r14d
00007fa0f61cff69  rorx r14d, r10d, 0x0D
00007fa0f61cff6f  xor r11d, r14d
00007fa0f61cff72  lea edi, [esi+ebp*1]
00007fa0f61cff76  mov r14, [r15+0x48]
00007fa0f61cff7a  mov ebp, [r13+r14*1]
00007fa0f61cff7f  mov r14d, [rsp+0x30]
00007fa0f61cff84  mov esi, [rsp+0x20]
00007fa0f61cff88  and r14d, esi
00007fa0f61cff8b  mov [rsp+0x20], r14d
00007fa0f61cff90  mov r14d, r14d
00007fa0f61cff93  mov [r15+0xD8], r14
00007fa0f61cff9a  lea r14d, [edi+r9d*1]
00007fa0f61cff9f  mov r9d, [rsp+0x30]
00007fa0f61cffa4  xor r9d, esi
00007fa0f61cffa7  rorx edi, r8d, 0x19
00007fa0f61cffad  xor eax, edi
00007fa0f61cffaf  and r9d, r10d
00007fa0f61cffb2  rorx edi, r10d, 0x16
00007fa0f61cffb8  xor r11d, edi
00007fa0f61cffbb  mov [rsp+0x30], r11d
00007fa0f61cffc0  mov r11d, r11d
00007fa0f61cffc3  mov [r15+0xD0], r11
00007fa0f61cffca  lea r11d, [r14d+ebp*1]
00007fa0f61cffcf  mov r10d, [rsp+0x20]
00007fa0f61cffd4  xor r9d, r10d
00007fa0f61cffd7  lea r14d, [r11d+eax*1]
00007fa0f61cffdc  mov qword ptr [r15+0x88], 0x04
00007fa0f61cffe7  mov eax, [rsp+0x30]
00007fa0f61cffeb  lea r11d, [r9d+eax*1]
00007fa0f61cfff0  mov eax, [rsp+0x40]
00007fa0f61cfff4  lea r10d, [r14d+eax*1]
00007fa0f61cfff9  mov r10d, r10d
00007fa0f61cfffc  mov [r15+0xB8], r10
00007fa0f61d0003  xor eax, eax
00007fa0f61d0005  mov r10d, 0x04
00007fa0f61d000b  mov r9d, 0x100
00007fa0f61d0011  cmp r10, r9
00007fa0f61d0014  cmc
00007fa0f61d0015  lahf
00007fa0f61d0016  seto al
00007fa0f61d0019  mov [r15+0x108], eax
00007fa0f61d0020  lea eax, [r11d+r14d*1]
00007fa0f61d0025  mov eax, eax
00007fa0f61d0027  mov [r15+0xA8], rax
00007fa0f61d002e  mov r12d, r12d
00007fa0f61d0031  mov [r15+0xB0], r12
00007fa0f61d0038  mov eax, [rsp+0x10]
00007fa0f61d003c  mov eax, eax
00007fa0f61d003e  mov [r15+0xC0], rax
00007fa0f61d0045  mov r8d, r8d
00007fa0f61d0048  mov [r15+0xC8], r8
00007fa0f61d004f  mov eax, [r15+0x108]
00007fa0f61d0056  sahf
00007fa0f61d0057  jnz 0x00007FA0F61D0089
00007fa0f61d0059  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0061  jz 0x00007FA0F61D0350
00007fa0f61d0067  nop [rax+rax*1], ax
00007fa0f61d0070  nop [rax+rax*1], eax
00007fa0f61d0078  mov eax, 0x41055C
00007fa0f61d007d  mov [r15+0x100], rax
00007fa0f61d0084  jmp 0x00007FA0F5FFE110
00007fa0f61d0089  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0091  jz 0x00007FA0F61D0120
00007fa0f61d0097  nop [rax+rax*1], ax
00007fa0f61d00a0  nop [rax+rax*1], eax
00007fa0f61d00a8  mov eax, 0x4104D0
00007fa0f61d00ad  mov [r15+0x100], rax
00007fa0f61d00b4  jmp 0x00007FA0F5FFE110
00007fa0f61d00b9  int3
00007fa0f61d00ba  call 0x00007FA0F600DAE0
00007fa0f61d00bf  jmp 0x00007FA0F61CFE28
00007fa0f61d00c4  call 0x00007FA0F60C0230
00007fa0f61d00c9  jmp 0x00007FA0F61CFE31
00007fa0f61d00ce  call 0x00007FA0F60E26A0
00007fa0f61d00d3  jmp 0x00007FA0F61CFE55
00007fa0f61d00d8  call 0x00007FA0F60E1430
00007fa0f61d00dd  jmp 0x00007FA0F61CFE5E
00007fa0f61d00e2  call 0x00007FA0F60E26A0
00007fa0f61d00e7  jmp 0x00007FA0F61CFE7F
00007fa0f61d00ec  call 0x00007FA0F60E1430
00007fa0f61d00f1  jmp 0x00007FA0F61CFE88
00007fa0f61d00f6  call 0x00007FA0F60E26A0
00007fa0f61d00fb  jmp 0x00007FA0F61CFEA9
00007fa0f61d0100  call 0x00007FA0F60D5890
00007fa0f61d0105  jmp 0x00007FA0F61CFEB2
00007fa0f61d010a  call 0x00007FA0F60BDD50
00007fa0f61d010f  jmp 0x00007FA0F61CFF48
00007fa0f61d0114  call 0x00007FA0F60DA580
00007fa0f61d0119  jmp 0x00007FA0F61CFF7F
00007fa0f61d011e  int3
00007fa0f61d011f  nop
00007fa0f61d0120  mov eax, [r15+0xB8]
00007fa0f61d0127  mov [rsp+0x10], eax
00007fa0f61d012b  mov eax, eax
00007fa0f61d012d  mov [r15+0x30], rax
00007fa0f61d0131  mov eax, [r15+0xC0]
00007fa0f61d0138  mov [rsp+0x20], eax
00007fa0f61d013c  mov eax, eax
00007fa0f61d013e  mov [r15+0xA0], rax
00007fa0f61d0145  mov eax, [r15+0x28]
00007fa0f61d0149  mov r14d, [r15+0x98]
00007fa0f61d0150  mov [rsp+0x30], r14d
00007fa0f61d0155  mov r14d, r14d
00007fa0f61d0158  mov [r15+0x28], r14
00007fa0f61d015c  mov r14d, [r15+0x38]
00007fa0f61d0160  mov [rsp+0x40], r14d
00007fa0f61d0165  mov r14d, r14d
00007fa0f61d0168  mov [r15+0x98], r14
00007fa0f61d016f  mov r14d, [r15+0xA8]
00007fa0f61d0176  mov [rsp+0x50], r14d
00007fa0f61d017b  mov r14d, r14d
00007fa0f61d017e  mov [r15+0x38], r14
00007fa0f61d0182  mov r14d, [rsp+0x10]
00007fa0f61d0187  mov r12d, [rsp+0x10]
00007fa0f61d018c  shrd r14d, r12d, 0x06
00007fa0f61d0191  mov r11d, [r15+0xC8]
00007fa0f61d0198  mov [rsp+0x10], r12d
00007fa0f61d019d  and r12d, r11d
00007fa0f61d01a0  mov r10d, [rsp+0x50]
00007fa0f61d01a5  mov r9d, [rsp+0x50]
00007fa0f61d01aa  shrd r10d, r9d, 0x02
00007fa0f61d01af  mov [rsp+0x50], r11d
00007fa0f61d01b4  mov r11d, r11d
00007fa0f61d01b7  mov [r15+0x20], r11
00007fa0f61d01bb  mov r11, [r15+0x88]
00007fa0f61d01c2  mov r8, [r15+0x50]
00007fa0f61d01c6  lea rbp, [r8+r11*1]
00007fa0f61d01ca  mov r8d, [r13+rbp*1]
00007fa0f61d01cf  mov ebp, [rsp+0x20]
00007fa0f61d01d3  mov edi, [rsp+0x10]
00007fa0f61d01d7  andn esi, edi, ebp
00007fa0f61d01dc  mov edx, [r15+0xB0]
00007fa0f61d01e3  lea ecx, [r12d+edx*1]
00007fa0f61d01e8  rorx r12d, edi, 0x0B
00007fa0f61d01ee  xor r14d, r12d
00007fa0f61d01f1  rorx r12d, r9d, 0x0D
00007fa0f61d01f7  xor r10d, r12d
00007fa0f61d01fa  lea r12d, [ecx+esi*1]
00007fa0f61d01ff  mov rsi, [r15+0x48]
00007fa0f61d0203  lea rdx, [rsi+r11*1]
00007fa0f61d0207  mov esi, [r13+rdx*1]
00007fa0f61d020c  mov edx, [rsp+0x30]
00007fa0f61d0210  mov ecx, [rsp+0x40]
00007fa0f61d0214  and edx, ecx
00007fa0f61d0216  mov [rsp+0x10], edx
00007fa0f61d021a  mov edx, edx
00007fa0f61d021c  mov [r15+0xD8], rdx
00007fa0f61d0223  lea edx, [r12d+r8d*1]
00007fa0f61d0228  mov r12d, [rsp+0x30]
00007fa0f61d022d  xor r12d, ecx
00007fa0f61d0230  rorx r8d, edi, 0x19
00007fa0f61d0236  xor r14d, r8d
00007fa0f61d0239  and r12d, r9d
00007fa0f61d023c  rorx r8d, r9d, 0x16
00007fa0f61d0242  xor r10d, r8d
00007fa0f61d0245  mov [rsp+0x20], r10d
00007fa0f61d024a  mov r10d, r10d
00007fa0f61d024d  mov [r15+0xD0], r10
00007fa0f61d0254  lea r10d, [edx+esi*1]
00007fa0f61d0259  mov r9d, [rsp+0x10]
00007fa0f61d025e  xor r12d, r9d
00007fa0f61d0261  lea r9d, [r10d+r14d*1]
00007fa0f61d0266  lea r14, [r11+0x04]
00007fa0f61d026a  mov [r15+0x88], r14
00007fa0f61d0271  mov r11d, [rsp+0x20]
00007fa0f61d0276  lea r10d, [r12d+r11d*1]
00007fa0f61d027b  lea r11d, [r9d+eax*1]
00007fa0f61d0280  mov r11d, r11d
00007fa0f61d0283  mov [r15+0xB8], r11
00007fa0f61d028a  xor eax, eax
00007fa0f61d028c  mov r12d, 0x100
00007fa0f61d0292  cmp r14, r12
00007fa0f61d0295  cmc
00007fa0f61d0296  lahf
00007fa0f61d0297  seto al
00007fa0f61d029a  mov [r15+0x108], eax
00007fa0f61d02a1  lea eax, [r10d+r9d*1]
00007fa0f61d02a6  mov eax, eax
00007fa0f61d02a8  mov [r15+0xA8], rax
00007fa0f61d02af  mov ebp, ebp
00007fa0f61d02b1  mov [r15+0xB0], rbp
00007fa0f61d02b8  mov eax, [rsp+0x50]
00007fa0f61d02bc  mov eax, eax
00007fa0f61d02be  mov [r15+0xC0], rax
00007fa0f61d02c5  mov edi, edi
00007fa0f61d02c7  mov [r15+0xC8], rdi
00007fa0f61d02ce  mov eax, [r15+0x108]
00007fa0f61d02d5  sahf
00007fa0f61d02d6  jnz 0x00007FA0F61D0308
00007fa0f61d02d8  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d02e0  jz 0x00007FA0F61D0350
00007fa0f61d02e6  nop [rax+rax*1], ax
00007fa0f61d02ef  nop [rax+rax*1], eax
00007fa0f61d02f7  mov eax, 0x41055C
00007fa0f61d02fc  mov [r15+0x100], rax
00007fa0f61d0303  jmp 0x00007FA0F5FFE110
00007fa0f61d0308  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0310  jz 0x00007FA0F61D0120
00007fa0f61d0316  nop [rax+rax*1], ax
00007fa0f61d031f  nop [rax+rax*1], eax
00007fa0f61d0327  mov eax, 0x4104D0
00007fa0f61d032c  mov [r15+0x100], rax
00007fa0f61d0333  jmp 0x00007FA0F5FFE110
00007fa0f61d0338  int3
00007fa0f61d0339  call 0x00007FA0F6049010
00007fa0f61d033e  jmp 0x00007FA0F61D01CF
00007fa0f61d0343  call 0x00007FA0F6025930
00007fa0f61d0348  jmp 0x00007FA0F61D020C
00007fa0f61d034d  int3
00007fa0f61d034e  nop
00007fa0f61d0350  mov eax, [r15+0x98]
00007fa0f61d0357  mov r14d, [r15+0x70]
00007fa0f61d035b  lea r12d, [eax+r14d*1]
00007fa0f61d0360  mov eax, [r15+0x28]
00007fa0f61d0364  mov r14d, [r15+0x68]
00007fa0f61d0368  lea r11d, [eax+r14d*1]
00007fa0f61d036d  mov qword ptr [r15+0x88], 0x00
00007fa0f61d0378  mov eax, [r15+0xA8]
00007fa0f61d037f  mov r14d, [r15+0x78]
00007fa0f61d0383  lea r10d, [eax+r14d*1]
00007fa0f61d0388  mov [rsp+0x10], r10d
00007fa0f61d038d  mov r10d, r10d
00007fa0f61d0390  mov [r15+0x78], r10
00007fa0f61d0394  mov eax, [r15+0x38]
00007fa0f61d0398  mov r14d, [r15+0x80]
00007fa0f61d039f  lea r10d, [eax+r14d*1]
00007fa0f61d03a4  mov [rsp+0x20], r10d
00007fa0f61d03a9  mov r10d, r10d
00007fa0f61d03ac  mov [r15+0x80], r10
00007fa0f61d03b3  mov rax, [r15]
00007fa0f61d03b6  lea r14, [rax+0x08]
00007fa0f61d03ba  mov [r13+r14*1], r12d
00007fa0f61d03bf  lea r14, [rax+0x0C]
00007fa0f61d03c3  mov [r13+r14*1], r11d
00007fa0f61d03c8  mov r14d, [r15+0xB8]
00007fa0f61d03cf  mov r12d, [r15+0x18]
00007fa0f61d03d3  lea r11d, [r14d+r12d*1]
00007fa0f61d03d8  mov [rsp+0x30], r11d
00007fa0f61d03dd  mov r11d, r11d
00007fa0f61d03e0  mov [r15+0x68], r11
00007fa0f61d03e4  mov r14d, [r15+0x30]
00007fa0f61d03e8  mov r12d, [r15+0x90]
00007fa0f61d03ef  lea r11d, [r14d+r12d*1]
00007fa0f61d03f4  mov [rsp+0x40], r11d
00007fa0f61d03f9  mov r11d, r11d
00007fa0f61d03fc  mov [r15+0x70], r11
00007fa0f61d0400  mov r14d, [r15+0x20]
00007fa0f61d0404  mov r12d, [r15+0x58]
00007fa0f61d0408  lea r11d, [r14d+r12d*1]
00007fa0f61d040d  mov [rsp+0x50], r11d
00007fa0f61d0412  mov r11d, r11d
00007fa0f61d0415  mov [r15+0x58], r11
00007fa0f61d0419  mov r14d, [r15+0xA0]
00007fa0f61d0420  mov r12d, [r15+0x60]
00007fa0f61d0424  lea r11d, [r14d+r12d*1]
00007fa0f61d0429  mov [rsp+0x60], r11d
00007fa0f61d042e  mov r11d, r11d
00007fa0f61d0431  mov [r15+0x60], r11
00007fa0f61d0435  mov r14d, [rsp+0x10]
00007fa0f61d043a  mov [r13+rax*1], r14d
00007fa0f61d043f  lea r14, [rax+0x04]
00007fa0f61d0443  mov r12d, [rsp+0x20]
00007fa0f61d0448  mov [r13+r14*1], r12d
00007fa0f61d044d  lea r14, [rax+0x10]
00007fa0f61d0451  mov r12d, [rsp+0x30]
00007fa0f61d0456  mov [r13+r14*1], r12d
00007fa0f61d045b  lea r14, [rax+0x14]
00007fa0f61d045f  mov r12d, [rsp+0x40]
00007fa0f61d0464  mov [r13+r14*1], r12d
00007fa0f61d0469  lea r14, [rax+0x18]
00007fa0f61d046d  mov r12d, [rsp+0x50]
00007fa0f61d0472  mov [r13+r14*1], r12d
00007fa0f61d0477  lea r14, [rax+0x1C]
00007fa0f61d047b  mov r12d, [rsp+0x60]
00007fa0f61d0480  mov [r13+r14*1], r12d
00007fa0f61d0485  lea r14, [rax+0x68]
00007fa0f61d0489  xor eax, eax
00007fa0f61d048b  mov [r13+r14*1], rax
00007fa0f61d0490  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0498  jz 0x00007FA0F61CEF90
00007fa0f61d049e  nop [rax+rax*1], ax
00007fa0f61d04a7  nop [rax+rax*1], eax
00007fa0f61d04af  mov eax, 0x410378
00007fa0f61d04b4  mov [r15+0x100], rax
00007fa0f61d04bb  jmp 0x00007FA0F5FFE110
00007fa0f61d04c0  int3
00007fa0f61d04c1  call 0x00007FA0F60E2BA0
00007fa0f61d04c6  jmp 0x00007FA0F61D03BF
00007fa0f61d04cb  call 0x00007FA0F60E1920
00007fa0f61d04d0  jmp 0x00007FA0F61D03C8
00007fa0f61d04d5  call 0x00007FA0F600DFE0
00007fa0f61d04da  jmp 0x00007FA0F61D043F
00007fa0f61d04df  call 0x00007FA0F60E2BA0
00007fa0f61d04e4  jmp 0x00007FA0F61D044D
00007fa0f61d04e9  call 0x00007FA0F60E2BA0
00007fa0f61d04ee  jmp 0x00007FA0F61D045B
00007fa0f61d04f3  call 0x00007FA0F60E2BA0
00007fa0f61d04f8  jmp 0x00007FA0F61D0469
00007fa0f61d04fd  call 0x00007FA0F60E2BA0
00007fa0f61d0502  jmp 0x00007FA0F61D0477
00007fa0f61d0507  call 0x00007FA0F60E2BA0
00007fa0f61d050c  jmp 0x00007FA0F61D0485
00007fa0f61d0511  call 0x00007FA0F60D5EB0
00007fa0f61d0516  jmp 0x00007FA0F61D0490
00007fa0f61d051b  int3
00007fa0f61d051c  nop [rax], eax
00007fa0f61d0520  mov rax, [r15+0xF8]
00007fa0f61d0527  lea r14, [rax+0x140]
00007fa0f61d052e  mov r12, [r13+r14*1]
00007fa0f61d0533  lea r14, [rax+0x148]
00007fa0f61d053a  mov r11, [r13+r14*1]
00007fa0f61d053f  mov [r15+0xA0], r12
00007fa0f61d0546  mov [r15+0x98], r11
00007fa0f61d054d  lea r14, [rax+0x130]
00007fa0f61d0554  mov r12, [r13+r14*1]
00007fa0f61d0559  lea r14, [rax+0x138]
00007fa0f61d0560  mov r11, [r13+r14*1]
00007fa0f61d0565  mov [r15+0xB0], r12
00007fa0f61d056c  mov [r15+0xA8], r11
00007fa0f61d0573  lea r14, [rax+0x120]
00007fa0f61d057a  mov r12, [r13+r14*1]
00007fa0f61d057f  lea r14, [rax+0x128]
00007fa0f61d0586  mov r11, [r13+r14*1]
00007fa0f61d058b  mov [r15+0xC0], r12
00007fa0f61d0592  mov [r15+0xB8], r11
00007fa0f61d0599  lea r14, [rax+0x110]
00007fa0f61d05a0  mov r12, [r13+r14*1]
00007fa0f61d05a5  lea r14, [rax+0x118]
00007fa0f61d05ac  mov r11, [r13+r14*1]
00007fa0f61d05b1  mov [r15+0xD0], r12
00007fa0f61d05b8  mov [r15+0xC8], r11
00007fa0f61d05bf  lea r14, [rax+0x100]
00007fa0f61d05c6  mov r12, [r13+r14*1]
00007fa0f61d05cb  lea r14, [rax+0x108]
00007fa0f61d05d2  mov r11, [r13+r14*1]
00007fa0f61d05d7  mov [r15+0xE8], r12
00007fa0f61d05de  mov [r15+0xD8], r11
00007fa0f61d05e5  lea r14, [rax+0x150]
00007fa0f61d05ec  mov [r15+0xF8], r14
00007fa0f61d05f3  mov rax, [r15+0xF0]
00007fa0f61d05fa  mov [r15+0x100], rax
00007fa0f61d0601  jmp 0x00007FA0F61CE5C0
00007fa0f61d0606  int3
00007fa0f61d0607  call 0x00007FA0F60E27E0
00007fa0f61d060c  jmp 0x00007FA0F61D0533
00007fa0f61d0611  call 0x00007FA0F60E1570
00007fa0f61d0616  jmp 0x00007FA0F61D053F
00007fa0f61d061b  call 0x00007FA0F60E27E0
00007fa0f61d0620  jmp 0x00007FA0F61D0559
00007fa0f61d0625  call 0x00007FA0F60E1570
00007fa0f61d062a  jmp 0x00007FA0F61D0565
00007fa0f61d062f  call 0x00007FA0F60E27E0
00007fa0f61d0634  jmp 0x00007FA0F61D057F
00007fa0f61d0639  call 0x00007FA0F60E1570
00007fa0f61d063e  jmp 0x00007FA0F61D058B
00007fa0f61d0643  call 0x00007FA0F60E27E0
00007fa0f61d0648  jmp 0x00007FA0F61D05A5
00007fa0f61d064d  call 0x00007FA0F60E1570
00007fa0f61d0652  jmp 0x00007FA0F61D05B1
00007fa0f61d0657  call 0x00007FA0F60E27E0
00007fa0f61d065c  jmp 0x00007FA0F61D05CB
00007fa0f61d0661  call 0x00007FA0F60E1570
00007fa0f61d0666  jmp 0x00007FA0F61D05D7
00007fa0f61d066b  int3
00007fa0f61d066c  nop [rax], eax
00007fa0f61d0670  mov eax, [r15+0xA0]
00007fa0f61d0677  mov [rsp+0x10], eax
00007fa0f61d067b  xor eax, eax
00007fa0f61d067d  mov r14d, [rsp+0x10]
00007fa0f61d0682  sub r14d, 0x01
00007fa0f61d0686  cmc
00007fa0f61d0687  lahf
00007fa0f61d0688  seto al
00007fa0f61d068b  mov [r15+0x108], eax
00007fa0f61d0692  mov r14d, r14d
00007fa0f61d0695  mov [r15+0xA0], r14
00007fa0f61d069c  mov eax, [r15+0x108]
00007fa0f61d06a3  sahf
00007fa0f61d06a4  jnz 0x00007FA0F61D06D6
00007fa0f61d06a6  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d06ae  jz 0x00007FA0F61D07A0
00007fa0f61d06b4  nop [rax+rax*1], ax
00007fa0f61d06bd  nop [rax+rax*1], eax
00007fa0f61d06c5  mov eax, 0x41027C
00007fa0f61d06ca  mov [r15+0x100], rax
00007fa0f61d06d1  jmp 0x00007FA0F5FFE110
00007fa0f61d06d6  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d06de  jz 0x00007FA0F61D0710
00007fa0f61d06e4  nop [rax+rax*1], ax
00007fa0f61d06ed  nop [rax+rax*1], eax
00007fa0f61d06f5  mov eax, 0x410264
00007fa0f61d06fa  mov [r15+0x100], rax
00007fa0f61d0701  jmp 0x00007FA0F5FFE110
00007fa0f61d0706  int3
00007fa0f61d0707  int3
00007fa0f61d0708  nop [rax+rax*1], eax
00007fa0f61d0710  mov rax, [r15+0xF8]
00007fa0f61d0717  mov [r15], rax
00007fa0f61d071a  mov rax, [r15+0x98]
00007fa0f61d0721  mov [r15+0x08], rax
00007fa0f61d0725  mov qword ptr [r15+0x10], 0x12C
00007fa0f61d072d  mov qword ptr [r15+0xF0], 0x410274
00007fa0f61d0738  mov r14d, [r15+0x320]
00007fa0f61d073f  mov eax, 0x410274
00007fa0f61d0744  mov rcx, 0x7FA0F61D0670
00007fa0f61d074e  mov [r15+r14*8+0x328], rax
00007fa0f61d0756  mov [r15+r14*8+0x368], rcx
00007fa0f61d075e  add r14d, 0x01
00007fa0f61d0762  and r14d, 0x07
00007fa0f61d0766  mov [r15+0x320], r14d
00007fa0f61d076d  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0775  jz 0x00007FA0F61CEC20
00007fa0f61d077b  nop [rax+rax*1], ax
00007fa0f61d0784  nop [rax+rax*1], eax
00007fa0f61d078c  mov eax, 0x410338
00007fa0f61d0791  mov [r15+0x100], rax
00007fa0f61d0798  jmp 0x00007FA0F5FFE110
00007fa0f61d079d  int3
00007fa0f61d079e  int3
00007fa0f61d079f  nop
00007fa0f61d07a0  mov rax, [r15+0xF8]
00007fa0f61d07a7  lea r14, [rax+0x20]
00007fa0f61d07ab  mov r12, [r13+r14*1]
00007fa0f61d07b0  mov [r15+0x98], r12
00007fa0f61d07b7  mov qword ptr [r15+0x40], 0x80
00007fa0f61d07bf  mov [r15], rax
00007fa0f61d07c2  lea r14, [rax+0x8C]
00007fa0f61d07c9  mov [r15+0x08], r14
00007fa0f61d07cd  mov qword ptr [r15+0x10], 0x01
00007fa0f61d07d5  lea r14, [rax+0x8C]
00007fa0f61d07dc  mov eax, 0x80
00007fa0f61d07e1  mov [r13+r14*1], al
00007fa0f61d07e6  mov qword ptr [r15+0xF0], 0x410298
00007fa0f61d07f1  mov r14d, [r15+0x320]
00007fa0f61d07f8  mov eax, 0x410298
00007fa0f61d07fd  mov rcx, 0x7FA0F61D0870
00007fa0f61d0807  mov [r15+r14*8+0x328], rax
00007fa0f61d080f  mov [r15+r14*8+0x368], rcx
00007fa0f61d0817  add r14d, 0x01
00007fa0f61d081b  and r14d, 0x07
00007fa0f61d081f  mov [r15+0x320], r14d
00007fa0f61d0826  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d082e  jz 0x00007FA0F61CEC20
00007fa0f61d0834  nop [rax+rax*1], ax
00007fa0f61d083d  nop [rax+rax*1], eax
00007fa0f61d0845  mov eax, 0x410338
00007fa0f61d084a  mov [r15+0x100], rax
00007fa0f61d0851  jmp 0x00007FA0F5FFE110
00007fa0f61d0856  int3
00007fa0f61d0857  call 0x00007FA0F60E27E0
00007fa0f61d085c  jmp 0x00007FA0F61D07B0
00007fa0f61d0861  call 0x00007FA0F60D5AF0
00007fa0f61d0866  jmp 0x00007FA0F61D07E6
00007fa0f61d086b  int3
00007fa0f61d086c  nop [rax], eax
00007fa0f61d0870  mov rax, [r15+0xF8]
00007fa0f61d0877  lea r14, [rax+0x68]
00007fa0f61d087b  mov r12, [r13+r14*1]
00007fa0f61d0880  mov [r15+0x40], r12
00007fa0f61d0884  lea r14, [rax+0x88]
00007fa0f61d088b  xor eax, eax
00007fa0f61d088d  mov [r13+r14*1], al
00007fa0f61d0892  xor eax, eax
00007fa0f61d0894  mov r14d, 0x38
00007fa0f61d089a  cmp r12, r14
00007fa0f61d089d  cmc
00007fa0f61d089e  lahf
00007fa0f61d089f  seto al
00007fa0f61d08a2  mov [r15+0x108], eax
00007fa0f61d08a9  mov eax, [r15+0x108]
00007fa0f61d08b0  sahf
00007fa0f61d08b1  jz 0x00007FA0F61D08E3
00007fa0f61d08b3  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d08bb  jz 0x00007FA0F61D0930
00007fa0f61d08c1  nop [rax+rax*1], ax
00007fa0f61d08ca  nop [rax+rax*1], eax
00007fa0f61d08d2  mov eax, 0x4102A8
00007fa0f61d08d7  mov [r15+0x100], rax
00007fa0f61d08de  jmp 0x00007FA0F5FFE110
00007fa0f61d08e3  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d08eb  jz 0x00007FA0F61D0A70
00007fa0f61d08f1  nop [rax+rax*1], ax
00007fa0f61d08fa  nop [rax+rax*1], eax
00007fa0f61d0902  mov eax, 0x4102C4
00007fa0f61d0907  mov [r15+0x100], rax
00007fa0f61d090e  jmp 0x00007FA0F5FFE110
00007fa0f61d0913  int3
00007fa0f61d0914  call 0x00007FA0F60E27E0
00007fa0f61d0919  jmp 0x00007FA0F61D0880
00007fa0f61d091e  call 0x00007FA0F60D5AF0
00007fa0f61d0923  jmp 0x00007FA0F61D0892
00007fa0f61d0928  int3
00007fa0f61d0929  nop [rax], eax
00007fa0f61d0930  mov rax, [r15+0xF8]
00007fa0f61d0937  mov [r15], rax
00007fa0f61d093a  lea r14, [rax+0x88]
00007fa0f61d0941  mov [r15+0x08], r14
00007fa0f61d0945  mov qword ptr [r15+0x10], 0x01
00007fa0f61d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007fa0f61d0958  mov r14d, [r15+0x320]
00007fa0f61d095f  mov eax, 0x4102B8
00007fa0f61d0964  mov rcx, 0x7FA0F61D09C0
00007fa0f61d096e  mov [r15+r14*8+0x328], rax
00007fa0f61d0976  mov [r15+r14*8+0x368], rcx
00007fa0f61d097e  add r14d, 0x01
00007fa0f61d0982  and r14d, 0x07
00007fa0f61d0986  mov [r15+0x320], r14d
00007fa0f61d098d  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0995  jz 0x00007FA0F61CEC20
00007fa0f61d099b  nop [rax+rax*1], ax
00007fa0f61d09a4  nop [rax+rax*1], eax
00007fa0f61d09ac  mov eax, 0x410338
00007fa0f61d09b1  mov [r15+0x100], rax
00007fa0f61d09b8  jmp 0x00007FA0F5FFE110
00007fa0f61d09bd  int3
00007fa0f61d09be  int3
00007fa0f61d09bf  nop
00007fa0f61d09c0  mov rax, [r15+0xF8]
00007fa0f61d09c7  lea r14, [rax+0x68]
00007fa0f61d09cb  mov rax, [r13+r14*1]
00007fa0f61d09d0  mov [r15+0x40], rax
00007fa0f61d09d4  mov [rsp+0x10], rax
00007fa0f61d09d9  xor eax, eax
00007fa0f61d09db  mov r14, [rsp+0x10]
00007fa0f61d09e0  mov r12d, 0x38
00007fa0f61d09e6  cmp r14, r12
00007fa0f61d09e9  cmc
00007fa0f61d09ea  lahf
00007fa0f61d09eb  seto al
00007fa0f61d09ee  mov [r15+0x108], eax
00007fa0f61d09f5  mov eax, [r15+0x108]
00007fa0f61d09fc  sahf
00007fa0f61d09fd  jnz 0x00007FA0F61D0A2F
00007fa0f61d09ff  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0a07  jz 0x00007FA0F61D0A70
00007fa0f61d0a0d  nop [rax+rax*1], ax
00007fa0f61d0a16  nop [rax+rax*1], eax
00007fa0f61d0a1e  mov eax, 0x4102C4
00007fa0f61d0a23  mov [r15+0x100], rax
00007fa0f61d0a2a  jmp 0x00007FA0F5FFE110
00007fa0f61d0a2f  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0a37  jz 0x00007FA0F61D0930
00007fa0f61d0a3d  nop [rax+rax*1], ax
00007fa0f61d0a46  nop [rax+rax*1], eax
00007fa0f61d0a4e  mov eax, 0x4102A8
00007fa0f61d0a53  mov [r15+0x100], rax
00007fa0f61d0a5a  jmp 0x00007FA0F5FFE110
00007fa0f61d0a5f  int3
00007fa0f61d0a60  call 0x00007FA0F60D59C0
00007fa0f61d0a65  jmp 0x00007FA0F61D09D0
00007fa0f61d0a6a  int3
00007fa0f61d0a6b  nop [rax+rax*1], eax
00007fa0f61d0a70  mov rax, [r15+0x98]
00007fa0f61d0a77  rorx r14, rax, 0x3D
00007fa0f61d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007fa0f61d0a81  mov rax, [r15+0xF8]
00007fa0f61d0a88  mov [r15], rax
00007fa0f61d0a8b  lea r12, [rax+0x78]
00007fa0f61d0a8f  mov [r15+0x08], r12
00007fa0f61d0a93  mov qword ptr [r15+0x10], 0x08
00007fa0f61d0a9b  bswap r14
00007fa0f61d0a9e  mov [r15+0x40], r14
00007fa0f61d0aa2  lea r12, [rax+0x78]
00007fa0f61d0aa6  mov [r13+r12*1], r14
00007fa0f61d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007fa0f61d0ab6  mov r14d, [r15+0x320]
00007fa0f61d0abd  mov eax, 0x4102E0
00007fa0f61d0ac2  mov rcx, 0x7FA0F61D0B30
00007fa0f61d0acc  mov [r15+r14*8+0x328], rax
00007fa0f61d0ad4  mov [r15+r14*8+0x368], rcx
00007fa0f61d0adc  add r14d, 0x01
00007fa0f61d0ae0  and r14d, 0x07
00007fa0f61d0ae4  mov [r15+0x320], r14d
00007fa0f61d0aeb  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0af3  jz 0x00007FA0F61CEC20
00007fa0f61d0af9  nop [rax+rax*1], ax
00007fa0f61d0b02  nop [rax+rax*1], eax
00007fa0f61d0b0a  mov eax, 0x410338
00007fa0f61d0b0f  mov [r15+0x100], rax
00007fa0f61d0b16  jmp 0x00007FA0F5FFE110
00007fa0f61d0b1b  int3
00007fa0f61d0b1c  call 0x00007FA0F60C3FE0
00007fa0f61d0b21  jmp 0x00007FA0F61D0AAB
00007fa0f61d0b26  int3
00007fa0f61d0b27  nop [rax+rax*1], ax
00007fa0f61d0b30  mov rax, [r15+0xF8]
00007fa0f61d0b37  mov r14d, [r13+rax*1]
00007fa0f61d0b3c  lea r12, [rax+0x04]
00007fa0f61d0b40  mov r11d, [r13+r12*1]
00007fa0f61d0b45  lea r12, [rax+0x08]
00007fa0f61d0b49  mov r10d, [r13+r12*1]
00007fa0f61d0b4e  lea r12, [rax+0x0C]
00007fa0f61d0b52  mov r9d, [r13+r12*1]
00007fa0f61d0b57  mov qword ptr [r15+0x48], 0x430860
00007fa0f61d0b5f  lea r12, [rax+0x80]
00007fa0f61d0b66  mov r8, [r13+r12*1]
00007fa0f61d0b6b  mov [r15+0xF0], r8
00007fa0f61d0b72  bswap r14d
00007fa0f61d0b75  bswap r11d
00007fa0f61d0b78  mov r12d, 0x430860
00007fa0f61d0b7e  mov [r13+r12*1], r14d
00007fa0f61d0b83  mov r14d, 0x430864
00007fa0f61d0b89  mov [r13+r14*1], r11d
00007fa0f61d0b8e  bswap r10d
00007fa0f61d0b91  bswap r9d
00007fa0f61d0b94  lea r14, [rax+0x10]
00007fa0f61d0b98  mov r12d, [r13+r14*1]
00007fa0f61d0b9d  lea r14, [rax+0x14]
00007fa0f61d0ba1  mov r11d, [r13+r14*1]
00007fa0f61d0ba6  mov r14d, 0x430868
00007fa0f61d0bac  mov [r13+r14*1], r10d
00007fa0f61d0bb1  mov r14d, 0x43086C
00007fa0f61d0bb7  mov [r13+r14*1], r9d
00007fa0f61d0bbc  lea r14, [rax+0x90]
00007fa0f61d0bc3  mov r10, [r13+r14*1]
00007fa0f61d0bc8  lea r14, [rax+0x98]
00007fa0f61d0bcf  mov r9, [r13+r14*1]
00007fa0f61d0bd4  mov [r15+0xA0], r10
00007fa0f61d0bdb  mov [r15+0x98], r9
00007fa0f61d0be2  bswap r12d
00007fa0f61d0be5  bswap r11d
00007fa0f61d0be8  mov [rsp+0x10], r11d
00007fa0f61d0bed  mov r11d, r11d
00007fa0f61d0bf0  mov [r15+0x58], r11
00007fa0f61d0bf4  lea r14, [rax+0x18]
00007fa0f61d0bf8  mov r11d, [r13+r14*1]
00007fa0f61d0bfd  lea r14, [rax+0x1C]
00007fa0f61d0c01  mov r10d, [r13+r14*1]
00007fa0f61d0c06  mov [rsp+0x20], r10d
00007fa0f61d0c0b  mov r10d, r10d
00007fa0f61d0c0e  mov [r15+0x60], r10
00007fa0f61d0c12  mov r14d, 0x430870
00007fa0f61d0c18  mov [r13+r14*1], r12d
00007fa0f61d0c1d  mov r14d, 0x430874
00007fa0f61d0c23  mov r12d, [rsp+0x10]
00007fa0f61d0c28  mov [r13+r14*1], r12d
00007fa0f61d0c2d  bswap r11d
00007fa0f61d0c30  mov [rsp+0x10], r11d
00007fa0f61d0c35  mov r11d, r11d
00007fa0f61d0c38  mov [r15+0x40], r11
00007fa0f61d0c3c  mov r14d, [rsp+0x20]
00007fa0f61d0c41  bswap r14d
00007fa0f61d0c44  mov [rsp+0x20], r14d
00007fa0f61d0c49  mov r14d, r14d
00007fa0f61d0c4c  mov [r15+0x50], r14
00007fa0f61d0c50  mov r14d, 0x430878
00007fa0f61d0c56  mov r12d, [rsp+0x10]
00007fa0f61d0c5b  mov [r13+r14*1], r12d
00007fa0f61d0c60  mov r14d, 0x43087C
00007fa0f61d0c66  mov r12d, [rsp+0x20]
00007fa0f61d0c6b  mov [r13+r14*1], r12d
00007fa0f61d0c70  lea r14, [rax+0xA0]
00007fa0f61d0c77  mov [r15+0xF8], r14
00007fa0f61d0c7e  mov [r15+0x100], r8
00007fa0f61d0c85  jmp 0x00007FA0F61CE5C0
00007fa0f61d0c8a  int3
00007fa0f61d0c8b  call 0x00007FA0F600DAE0
00007fa0f61d0c90  jmp 0x00007FA0F61D0B3C
00007fa0f61d0c95  call 0x00007FA0F60C0230
00007fa0f61d0c9a  jmp 0x00007FA0F61D0B45
00007fa0f61d0c9f  call 0x00007FA0F60BEFC0
00007fa0f61d0ca4  jmp 0x00007FA0F61D0B4E
00007fa0f61d0ca9  call 0x00007FA0F60BDD50
00007fa0f61d0cae  jmp 0x00007FA0F61D0B57
00007fa0f61d0cb3  call 0x00007FA0F60BCC20
00007fa0f61d0cb8  jmp 0x00007FA0F61D0B6B
00007fa0f61d0cbd  call 0x00007FA0F60C3EA0
00007fa0f61d0cc2  jmp 0x00007FA0F61D0B83
00007fa0f61d0cc7  call 0x00007FA0F60E1920
00007fa0f61d0ccc  jmp 0x00007FA0F61D0B8E
00007fa0f61d0cd1  call 0x00007FA0F60E26A0
00007fa0f61d0cd6  jmp 0x00007FA0F61D0B9D
00007fa0f61d0cdb  call 0x00007FA0F60E1430
00007fa0f61d0ce0  jmp 0x00007FA0F61D0BA6
00007fa0f61d0ce5  call 0x00007FA0F60E06B0
00007fa0f61d0cea  jmp 0x00007FA0F61D0BB1
00007fa0f61d0cef  call 0x00007FA0F60DF440
00007fa0f61d0cf4  jmp 0x00007FA0F61D0BBC
00007fa0f61d0cf9  call 0x00007FA0F60E0300
00007fa0f61d0cfe  jmp 0x00007FA0F61D0BC8
00007fa0f61d0d03  call 0x00007FA0F60DF090
00007fa0f61d0d08  jmp 0x00007FA0F61D0BD4
00007fa0f61d0d0d  call 0x00007FA0F60E1430
00007fa0f61d0d12  jmp 0x00007FA0F61D0BFD
00007fa0f61d0d17  call 0x00007FA0F60E01C0
00007fa0f61d0d1c  jmp 0x00007FA0F61D0C06
00007fa0f61d0d21  call 0x00007FA0F60E2BA0
00007fa0f61d0d26  jmp 0x00007FA0F61D0C1D
00007fa0f61d0d2b  call 0x00007FA0F60E2BA0
00007fa0f61d0d30  jmp 0x00007FA0F61D0C2D
00007fa0f61d0d35  call 0x00007FA0F60E2BA0
00007fa0f61d0d3a  jmp 0x00007FA0F61D0C60
00007fa0f61d0d3f  call 0x00007FA0F60E2BA0
00007fa0f61d0d44  jmp 0x00007FA0F61D0C70
00007fa0f61d0d49  int3
00007fa0f61d0d4a  nop [rax+rax*1], ax
00007fa0f61d0d50  mov qword ptr [r15+0x100], 0x04
00007fa0f61d0d5b  mov esi, 0x00
00007fa0f61d0d60  mov edx, 0x09
00007fa0f61d0d65  mov rdi, 0x7FFD56CEE3E0
00007fa0f61d0d6f  mov rax, 0x5C28A7A55970
00007fa0f61d0d79  call rax
00007fa0f61d0d7b  cmp dword ptr [r15+0x318], 0x00
00007fa0f61d0d83  jnz 0x00007FA0F5FFE110
00007fa0f61d0d89  jmp 0x00007FA0F5FFE0A0
00007fa0f61d0d8e  int3
00007fa0f61d0d8f  int3
