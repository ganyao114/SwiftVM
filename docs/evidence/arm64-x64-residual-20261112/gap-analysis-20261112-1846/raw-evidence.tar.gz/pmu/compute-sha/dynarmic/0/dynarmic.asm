00007ea2ca7ce69b  nop [rax+rax*1], eax
00007ea2ca7ce6a0  mov rax, [r15+0xF8]
00007ea2ca7ce6a7  lea r14, [rax-0xA0]
00007ea2ca7ce6ae  mov [r15+0xF8], r14
00007ea2ca7ce6b5  lea rax, [r14+0x90]
00007ea2ca7ce6bc  mov r12, [r15+0xA0]
00007ea2ca7ce6c3  mov r11, [r15+0x98]
00007ea2ca7ce6ca  mov [r13+rax*1], r12
00007ea2ca7ce6cf  lea rax, [r14+0x98]
00007ea2ca7ce6d6  mov [r13+rax*1], r11
00007ea2ca7ce6db  mov eax, 0x420670
00007ea2ca7ce6e0  movups xmm1, [r13+rax*1]
00007ea2ca7ce6e6  mov eax, 0x420610
00007ea2ca7ce6eb  movups xmm15, [r13+rax*1]
00007ea2ca7ce6f1  mov eax, 0x420690
00007ea2ca7ce6f6  movups xmm14, [r13+rax*1]
00007ea2ca7ce6fc  mov eax, 0x420630
00007ea2ca7ce701  movups xmm13, [r13+rax*1]
00007ea2ca7ce707  mov qword ptr [r15+0x98], 0x4308A0
00007ea2ca7ce712  mov eax, 0x4206A0
00007ea2ca7ce717  movups xmm12, [r13+rax*1]
00007ea2ca7ce71d  mov eax, 0x4308A0
00007ea2ca7ce722  movups [r13+rax*1], xmm1
00007ea2ca7ce728  mov eax, 0x4308B0
00007ea2ca7ce72d  movups [r13+rax*1], xmm15
00007ea2ca7ce733  mov eax, 0x4308C0
00007ea2ca7ce738  movups [r13+rax*1], xmm14
00007ea2ca7ce73e  mov eax, 0x4308D0
00007ea2ca7ce743  movups [r13+rax*1], xmm13
00007ea2ca7ce749  mov eax, 0x420600
00007ea2ca7ce74e  movups xmm14, [r13+rax*1]
00007ea2ca7ce754  mov eax, 0x4205F0
00007ea2ca7ce759  movups xmm13, [r13+rax*1]
00007ea2ca7ce75f  mov eax, 0x4309A0
00007ea2ca7ce764  movups [r13+rax*1], xmm1
00007ea2ca7ce76a  mov eax, 0x4309B0
00007ea2ca7ce76f  movups [r13+rax*1], xmm15
00007ea2ca7ce775  mov eax, 0x4308E0
00007ea2ca7ce77a  movups [r13+rax*1], xmm12
00007ea2ca7ce780  mov eax, 0x4308F0
00007ea2ca7ce785  movups [r13+rax*1], xmm14
00007ea2ca7ce78b  mov eax, 0x4205E0
00007ea2ca7ce790  movups xmm1, [r13+rax*1]
00007ea2ca7ce796  mov eax, 0x420640
00007ea2ca7ce79b  movups xmm15, [r13+rax*1]
00007ea2ca7ce7a1  mov eax, 0x430900
00007ea2ca7ce7a6  movups [r13+rax*1], xmm13
00007ea2ca7ce7ac  mov eax, 0x430910
00007ea2ca7ce7b1  movups [r13+rax*1], xmm1
00007ea2ca7ce7b7  mov eax, 0x420650
00007ea2ca7ce7bc  movups xmm1, [r13+rax*1]
00007ea2ca7ce7c2  mov eax, 0x420620
00007ea2ca7ce7c7  movups xmm14, [r13+rax*1]
00007ea2ca7ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007ea2ca7ce7d5  mov eax, 0x430920
00007ea2ca7ce7da  movups [r13+rax*1], xmm15
00007ea2ca7ce7e0  mov eax, 0x430930
00007ea2ca7ce7e5  movups [r13+rax*1], xmm1
00007ea2ca7ce7eb  mov eax, 0x4206C0
00007ea2ca7ce7f0  movups xmm1, [r13+rax*1]
00007ea2ca7ce7f6  mov eax, 0x4206D0
00007ea2ca7ce7fb  movups xmm15, [r13+rax*1]
00007ea2ca7ce801  movaps [r15+0x150], xmm15
00007ea2ca7ce809  mov qword ptr [r15+0xA0], 0x3E8
00007ea2ca7ce814  mov eax, 0x430940
00007ea2ca7ce819  movups [r13+rax*1], xmm14
00007ea2ca7ce81f  mov eax, 0x430950
00007ea2ca7ce824  movups [r13+rax*1], xmm1
00007ea2ca7ce82a  mov eax, 0x4206B0
00007ea2ca7ce82f  movups xmm1, [r13+rax*1]
00007ea2ca7ce835  mov eax, 0x420660
00007ea2ca7ce83a  movups xmm14, [r13+rax*1]
00007ea2ca7ce840  movaps [r15+0x140], xmm14
00007ea2ca7ce848  lea rax, [r14+0x80]
00007ea2ca7ce84f  mov r12, [r15+0xF0]
00007ea2ca7ce856  mov [r13+rax*1], r12
00007ea2ca7ce85b  mov eax, 0x430960
00007ea2ca7ce860  movups [r13+rax*1], xmm15
00007ea2ca7ce866  mov eax, 0x430970
00007ea2ca7ce86b  movups [r13+rax*1], xmm1
00007ea2ca7ce871  mov eax, 0x420680
00007ea2ca7ce876  movups xmm1, [r13+rax*1]
00007ea2ca7ce87c  mov eax, 0x4206E0
00007ea2ca7ce881  mov r12, [r13+rax*1]
00007ea2ca7ce886  movq xmm15, r12
00007ea2ca7ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007ea2ca7ce893  mov eax, 0x430980
00007ea2ca7ce898  movups [r13+rax*1], xmm14
00007ea2ca7ce89e  mov eax, 0x430990
00007ea2ca7ce8a3  movups [r13+rax*1], xmm1
00007ea2ca7ce8a9  mov eax, 0x420748
00007ea2ca7ce8ae  movups xmm1, [r13+rax*1]
00007ea2ca7ce8b4  movq rax, xmm15
00007ea2ca7ce8b9  mov r12d, 0x4309C0
00007ea2ca7ce8bf  mov [r13+r12*1], rax
00007ea2ca7ce8c4  mov eax, 0x420728
00007ea2ca7ce8c9  movups xmm15, [r13+rax*1]
00007ea2ca7ce8cf  mov eax, 0x420738
00007ea2ca7ce8d4  movups xmm14, [r13+rax*1]
00007ea2ca7ce8da  lea rax, [r14+0x60]
00007ea2ca7ce8de  movups [r13+rax*1], xmm1
00007ea2ca7ce8e4  mov eax, 0x4309C8
00007ea2ca7ce8e9  mov r12d, 0x421DF8D3
00007ea2ca7ce8ef  mov [r13+rax*1], r12d
00007ea2ca7ce8f4  lea rax, [r14+0x40]
00007ea2ca7ce8f8  movups [r13+rax*1], xmm15
00007ea2ca7ce8fe  lea rax, [r14+0x50]
00007ea2ca7ce902  movups [r13+rax*1], xmm14
00007ea2ca7ce908  mov eax, 0x4206E8
00007ea2ca7ce90d  movups xmm1, [r13+rax*1]
00007ea2ca7ce913  mov eax, 0x4206F8
00007ea2ca7ce918  movups xmm15, [r13+rax*1]
00007ea2ca7ce91e  movaps [r15+0x120], xmm15
00007ea2ca7ce926  movups [r13+r14*1], xmm1
00007ea2ca7ce92c  lea rax, [r14+0x10]
00007ea2ca7ce930  movups [r13+rax*1], xmm15
00007ea2ca7ce936  mov eax, 0x420708
00007ea2ca7ce93b  movups xmm1, [r13+rax*1]
00007ea2ca7ce941  mov eax, 0x420718
00007ea2ca7ce946  movups xmm15, [r13+rax*1]
00007ea2ca7ce94c  movaps [r15+0x110], xmm1
00007ea2ca7ce954  movaps [r15+0x130], xmm15
00007ea2ca7ce95c  lea rax, [r14+0x20]
00007ea2ca7ce960  movups [r13+rax*1], xmm1
00007ea2ca7ce966  lea rax, [r14+0x30]
00007ea2ca7ce96a  movups [r13+rax*1], xmm15
00007ea2ca7ce970  mov [r15], r14
00007ea2ca7ce973  mov qword ptr [r15+0x08], 0x4308A0
00007ea2ca7ce97b  mov qword ptr [r15+0x10], 0x12C
00007ea2ca7ce983  mov qword ptr [r15+0xF0], 0x410274
00007ea2ca7ce98e  mov r14d, [r15+0x320]
00007ea2ca7ce995  mov eax, 0x410274
00007ea2ca7ce99a  mov rcx, 0x7EA2CA7D0670
00007ea2ca7ce9a4  mov [r15+r14*8+0x328], rax
00007ea2ca7ce9ac  mov [r15+r14*8+0x368], rcx
00007ea2ca7ce9b4  add r14d, 0x01
00007ea2ca7ce9b8  and r14d, 0x07
00007ea2ca7ce9bc  mov [r15+0x320], r14d
00007ea2ca7ce9c3  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7ce9cb  jz 0x00007EA2CA7CEC20
00007ea2ca7ce9d1  nop [rax+rax*1], ax
00007ea2ca7ce9da  nop [rax+rax*1], eax
00007ea2ca7ce9e2  mov eax, 0x410338
00007ea2ca7ce9e7  mov [r15+0x100], rax
00007ea2ca7ce9ee  jmp 0x00007EA2CA5FE110
00007ea2ca7ce9f3  int3
00007ea2ca7ce9f4  call 0x00007EA2CA60BC20
00007ea2ca7ce9f9  jmp 0x00007EA2CA7CE6CF
00007ea2ca7ce9fe  call 0x00007EA2CA60A9A0
00007ea2ca7cea03  jmp 0x00007EA2CA7CE6DB
00007ea2ca7cea08  call 0x00007EA2CA5FF430
00007ea2ca7cea0d  jmp 0x00007EA2CA7CE6E6
00007ea2ca7cea12  call 0x00007EA2CA60E760
00007ea2ca7cea17  jmp 0x00007EA2CA7CE6F1
00007ea2ca7cea1c  call 0x00007EA2CA60D4E0
00007ea2ca7cea21  jmp 0x00007EA2CA7CE6FC
00007ea2ca7cea26  call 0x00007EA2CA60C260
00007ea2ca7cea2b  jmp 0x00007EA2CA7CE707
00007ea2ca7cea30  call 0x00007EA2CA60AFE0
00007ea2ca7cea35  jmp 0x00007EA2CA7CE71D
00007ea2ca7cea3a  call 0x00007EA2CA5FF540
00007ea2ca7cea3f  jmp 0x00007EA2CA7CE728
00007ea2ca7cea44  call 0x00007EA2CA60E880
00007ea2ca7cea49  jmp 0x00007EA2CA7CE733
00007ea2ca7cea4e  call 0x00007EA2CA60D600
00007ea2ca7cea53  jmp 0x00007EA2CA7CE73E
00007ea2ca7cea58  call 0x00007EA2CA60C380
00007ea2ca7cea5d  jmp 0x00007EA2CA7CE749
00007ea2ca7cea62  call 0x00007EA2CA60D4E0
00007ea2ca7cea67  jmp 0x00007EA2CA7CE754
00007ea2ca7cea6c  call 0x00007EA2CA60C260
00007ea2ca7cea71  jmp 0x00007EA2CA7CE75F
00007ea2ca7cea76  call 0x00007EA2CA5FF540
00007ea2ca7cea7b  jmp 0x00007EA2CA7CE76A
00007ea2ca7cea80  call 0x00007EA2CA60E880
00007ea2ca7cea85  jmp 0x00007EA2CA7CE775
00007ea2ca7cea8a  call 0x00007EA2CA60B100
00007ea2ca7cea8f  jmp 0x00007EA2CA7CE780
00007ea2ca7cea94  call 0x00007EA2CA60D600
00007ea2ca7cea99  jmp 0x00007EA2CA7CE78B
00007ea2ca7cea9e  call 0x00007EA2CA5FF430
00007ea2ca7ceaa3  jmp 0x00007EA2CA7CE796
00007ea2ca7ceaa8  call 0x00007EA2CA60E760
00007ea2ca7ceaad  jmp 0x00007EA2CA7CE7A1
00007ea2ca7ceab2  call 0x00007EA2CA60C380
00007ea2ca7ceab7  jmp 0x00007EA2CA7CE7AC
00007ea2ca7ceabc  call 0x00007EA2CA5FF540
00007ea2ca7ceac1  jmp 0x00007EA2CA7CE7B7
00007ea2ca7ceac6  call 0x00007EA2CA5FF430
00007ea2ca7ceacb  jmp 0x00007EA2CA7CE7C2
00007ea2ca7cead0  call 0x00007EA2CA60D4E0
00007ea2ca7cead5  jmp 0x00007EA2CA7CE7CD
00007ea2ca7ceada  call 0x00007EA2CA60E880
00007ea2ca7ceadf  jmp 0x00007EA2CA7CE7E0
00007ea2ca7ceae4  call 0x00007EA2CA5FF540
00007ea2ca7ceae9  jmp 0x00007EA2CA7CE7EB
00007ea2ca7ceaee  call 0x00007EA2CA5FF430
00007ea2ca7ceaf3  jmp 0x00007EA2CA7CE7F6
00007ea2ca7ceaf8  call 0x00007EA2CA60E760
00007ea2ca7ceafd  jmp 0x00007EA2CA7CE801
00007ea2ca7ceb02  call 0x00007EA2CA60D600
00007ea2ca7ceb07  jmp 0x00007EA2CA7CE81F
00007ea2ca7ceb0c  call 0x00007EA2CA5FF540
00007ea2ca7ceb11  jmp 0x00007EA2CA7CE82A
00007ea2ca7ceb16  call 0x00007EA2CA5FF430
00007ea2ca7ceb1b  jmp 0x00007EA2CA7CE835
00007ea2ca7ceb20  call 0x00007EA2CA60D4E0
00007ea2ca7ceb25  jmp 0x00007EA2CA7CE840
00007ea2ca7ceb2a  call 0x00007EA2CA60BC20
00007ea2ca7ceb2f  jmp 0x00007EA2CA7CE85B
00007ea2ca7ceb34  call 0x00007EA2CA60E880
00007ea2ca7ceb39  jmp 0x00007EA2CA7CE866
00007ea2ca7ceb3e  call 0x00007EA2CA5FF540
00007ea2ca7ceb43  jmp 0x00007EA2CA7CE871
00007ea2ca7ceb48  call 0x00007EA2CA5FF430
00007ea2ca7ceb4d  jmp 0x00007EA2CA7CE87C
00007ea2ca7ceb52  call 0x00007EA2CA60B720
00007ea2ca7ceb57  jmp 0x00007EA2CA7CE886
00007ea2ca7ceb5c  call 0x00007EA2CA60D600
00007ea2ca7ceb61  jmp 0x00007EA2CA7CE89E
00007ea2ca7ceb66  call 0x00007EA2CA5FF540
00007ea2ca7ceb6b  jmp 0x00007EA2CA7CE8A9
00007ea2ca7ceb70  call 0x00007EA2CA5FF430
00007ea2ca7ceb75  jmp 0x00007EA2CA7CE8B4
00007ea2ca7ceb7a  call 0x00007EA2CA6B4CB0
00007ea2ca7ceb7f  jmp 0x00007EA2CA7CE8C4
00007ea2ca7ceb84  call 0x00007EA2CA60E760
00007ea2ca7ceb89  jmp 0x00007EA2CA7CE8CF
00007ea2ca7ceb8e  call 0x00007EA2CA60D4E0
00007ea2ca7ceb93  jmp 0x00007EA2CA7CE8DA
00007ea2ca7ceb98  call 0x00007EA2CA5FF540
00007ea2ca7ceb9d  jmp 0x00007EA2CA7CE8E4
00007ea2ca7ceba2  call 0x00007EA2CA60BAE0
00007ea2ca7ceba7  jmp 0x00007EA2CA7CE8F4
00007ea2ca7cebac  call 0x00007EA2CA60E880
00007ea2ca7cebb1  jmp 0x00007EA2CA7CE8FE
00007ea2ca7cebb6  call 0x00007EA2CA60D600
00007ea2ca7cebbb  jmp 0x00007EA2CA7CE908
00007ea2ca7cebc0  call 0x00007EA2CA5FF430
00007ea2ca7cebc5  jmp 0x00007EA2CA7CE913
00007ea2ca7cebca  call 0x00007EA2CA60E760
00007ea2ca7cebcf  jmp 0x00007EA2CA7CE91E
00007ea2ca7cebd4  call 0x00007EA2CA6D6600
00007ea2ca7cebd9  jmp 0x00007EA2CA7CE92C
00007ea2ca7cebde  call 0x00007EA2CA60E880
00007ea2ca7cebe3  jmp 0x00007EA2CA7CE936
00007ea2ca7cebe8  call 0x00007EA2CA5FF430
00007ea2ca7cebed  jmp 0x00007EA2CA7CE941
00007ea2ca7cebf2  call 0x00007EA2CA60E760
00007ea2ca7cebf7  jmp 0x00007EA2CA7CE94C
00007ea2ca7cebfc  call 0x00007EA2CA5FF540
00007ea2ca7cec01  jmp 0x00007EA2CA7CE966
00007ea2ca7cec06  call 0x00007EA2CA60E880
00007ea2ca7cec0b  jmp 0x00007EA2CA7CE970
00007ea2ca7cec10  int3
00007ea2ca7cec11  nop [rax+rax*1], ax
00007ea2ca7cec1a  nop [rax+rax*1], ax
00007ea2ca7cec20  mov rax, [r15]
00007ea2ca7cec23  lea r14, [rax+0x20]
00007ea2ca7cec27  mov r12, [r13+r14*1]
00007ea2ca7cec2c  mov r14, [r15+0x10]
00007ea2ca7cec30  lea r11, [r12+r14*1]
00007ea2ca7cec34  mov [r15+0x40], r11
00007ea2ca7cec38  lea r12, [rax+0x20]
00007ea2ca7cec3c  mov [r13+r12*1], r11
00007ea2ca7cec41  test r14, r14
00007ea2ca7cec44  setz r14b
00007ea2ca7cec48  movzx r14, r14b
00007ea2ca7cec4c  mov [rsp+0x414], r14b
00007ea2ca7cec54  cmp byte ptr [rsp+0x414], 0x00
00007ea2ca7cec5c  jz 0x00007EA2CA7CEC8E
00007ea2ca7cec5e  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cec66  mov eax, 0x4105B0
00007ea2ca7cec6b  mov [r15+0x100], rax
00007ea2ca7cec72  jz 0x00007EA2CA5FE0A0
00007ea2ca7cec78  nop [rax+rax*1], eax
00007ea2ca7cec7d  mov eax, 0x4105B0
00007ea2ca7cec82  mov [r15+0x100], rax
00007ea2ca7cec89  jmp 0x00007EA2CA5FE110
00007ea2ca7cec8e  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cec96  jz 0x00007EA2CA7CECE0
00007ea2ca7cec9c  nop [rax+rax*1], ax
00007ea2ca7ceca5  nop [rax+rax*1], eax
00007ea2ca7cecad  mov eax, 0x410348
00007ea2ca7cecb2  mov [r15+0x100], rax
00007ea2ca7cecb9  jmp 0x00007EA2CA5FE110
00007ea2ca7cecbe  int3
00007ea2ca7cecbf  call 0x00007EA2CA6E27E0
00007ea2ca7cecc4  jmp 0x00007EA2CA7CEC2C
00007ea2ca7cecc9  call 0x00007EA2CA6C0860
00007ea2ca7cecce  jmp 0x00007EA2CA7CEC41
00007ea2ca7cecd3  int3
00007ea2ca7cecd4  nop [rax+rax*1], ax
00007ea2ca7cecdd  nop [rax], eax
00007ea2ca7cece0  mov rax, [r15+0xF8]
00007ea2ca7cece7  lea r14, [rax-0x150]
00007ea2ca7cecee  mov [r15+0xF8], r14
00007ea2ca7cecf5  mov rax, [r15]
00007ea2ca7cecf8  lea r12, [rax+0x68]
00007ea2ca7cecfc  mov r11, [r13+r12*1]
00007ea2ca7ced01  mov [r15+0x88], r11
00007ea2ca7ced08  lea r12, [rax+0x28]
00007ea2ca7ced0c  mov [r15+0x40], r12
00007ea2ca7ced10  mov [r15+0x48], r14
00007ea2ca7ced14  mov qword ptr [r15+0x50], 0x420758
00007ea2ca7ced1c  lea rax, [r14+0x100]
00007ea2ca7ced23  mov r12, [r15+0xE8]
00007ea2ca7ced2a  mov r11, [r15+0xD8]
00007ea2ca7ced31  mov [r13+rax*1], r12
00007ea2ca7ced36  lea rax, [r14+0x108]
00007ea2ca7ced3d  mov [r13+rax*1], r11
00007ea2ca7ced42  lea rax, [r14+0x110]
00007ea2ca7ced49  mov r12, [r15+0xD0]
00007ea2ca7ced50  mov r11, [r15+0xC8]
00007ea2ca7ced57  mov [r13+rax*1], r12
00007ea2ca7ced5c  lea rax, [r14+0x118]
00007ea2ca7ced63  mov [r13+rax*1], r11
00007ea2ca7ced68  lea rax, [r14+0x120]
00007ea2ca7ced6f  mov r12, [r15+0xC0]
00007ea2ca7ced76  mov r11, [r15+0xB8]
00007ea2ca7ced7d  mov [r13+rax*1], r12
00007ea2ca7ced82  lea rax, [r14+0x128]
00007ea2ca7ced89  mov [r13+rax*1], r11
00007ea2ca7ced8e  lea rax, [r14+0x130]
00007ea2ca7ced95  mov r12, [r15+0xB0]
00007ea2ca7ced9c  mov r11, [r15+0xA8]
00007ea2ca7ceda3  mov [r13+rax*1], r12
00007ea2ca7ceda8  lea rax, [r14+0x138]
00007ea2ca7cedaf  mov [r13+rax*1], r11
00007ea2ca7cedb4  lea rax, [r14+0x140]
00007ea2ca7cedbb  mov r12, [r15+0xA0]
00007ea2ca7cedc2  mov r11, [r15+0x98]
00007ea2ca7cedc9  mov [r13+rax*1], r12
00007ea2ca7cedce  lea rax, [r14+0x148]
00007ea2ca7cedd5  mov [r13+rax*1], r11
00007ea2ca7cedda  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cede2  jz 0x00007EA2CA7CEE80
00007ea2ca7cede8  nop [rax+rax*1], ax
00007ea2ca7cedf1  nop [rax+rax*1], eax
00007ea2ca7cedf9  mov eax, 0x410380
00007ea2ca7cedfe  mov [r15+0x100], rax
00007ea2ca7cee05  jmp 0x00007EA2CA5FE110
00007ea2ca7cee0a  int3
00007ea2ca7cee0b  call 0x00007EA2CA6C0370
00007ea2ca7cee10  jmp 0x00007EA2CA7CED01
00007ea2ca7cee15  call 0x00007EA2CA60BC20
00007ea2ca7cee1a  jmp 0x00007EA2CA7CED36
00007ea2ca7cee1f  call 0x00007EA2CA60A9A0
00007ea2ca7cee24  jmp 0x00007EA2CA7CED42
00007ea2ca7cee29  call 0x00007EA2CA60BC20
00007ea2ca7cee2e  jmp 0x00007EA2CA7CED5C
00007ea2ca7cee33  call 0x00007EA2CA60A9A0
00007ea2ca7cee38  jmp 0x00007EA2CA7CED68
00007ea2ca7cee3d  call 0x00007EA2CA60BC20
00007ea2ca7cee42  jmp 0x00007EA2CA7CED82
00007ea2ca7cee47  call 0x00007EA2CA60A9A0
00007ea2ca7cee4c  jmp 0x00007EA2CA7CED8E
00007ea2ca7cee51  call 0x00007EA2CA60BC20
00007ea2ca7cee56  jmp 0x00007EA2CA7CEDA8
00007ea2ca7cee5b  call 0x00007EA2CA60A9A0
00007ea2ca7cee60  jmp 0x00007EA2CA7CEDB4
00007ea2ca7cee65  call 0x00007EA2CA60BC20
00007ea2ca7cee6a  jmp 0x00007EA2CA7CEDCE
00007ea2ca7cee6f  call 0x00007EA2CA60A9A0
00007ea2ca7cee74  jmp 0x00007EA2CA7CEDDA
00007ea2ca7cee79  int3
00007ea2ca7cee7a  nop [rax+rax*1], ax
00007ea2ca7cee80  mov rax, [r15+0x08]
00007ea2ca7cee84  movzx r14d, byte ptr [r13+rax*1]
00007ea2ca7cee8a  movzx r14d, r14b
00007ea2ca7cee8e  mov [rsp+0x10], r14d
00007ea2ca7cee93  mov r14d, r14d
00007ea2ca7cee96  mov [r15+0x58], r14
00007ea2ca7cee9a  lea r14, [rax+0x01]
00007ea2ca7cee9e  mov [r15+0x08], r14
00007ea2ca7ceea2  mov rax, [r15+0x88]
00007ea2ca7ceea9  lea r14, [rax+0x01]
00007ea2ca7ceead  mov r12, [r15]
00007ea2ca7ceeb0  lea r11, [r12+0x68]
00007ea2ca7ceeb5  mov [r13+r11*1], r14
00007ea2ca7ceeba  lea r14, [r12+rax*1]
00007ea2ca7ceebe  mov [r15+0x60], r14
00007ea2ca7ceec2  lea rax, [r14+0x28]
00007ea2ca7ceec6  mov r11d, [rsp+0x10]
00007ea2ca7ceecb  movzx r14d, r11b
00007ea2ca7ceecf  mov [r13+rax*1], r14b
00007ea2ca7ceed4  lea rax, [r12+0x68]
00007ea2ca7ceed9  mov r14, [r13+rax*1]
00007ea2ca7ceede  mov [r15+0x88], r14
00007ea2ca7ceee5  xor eax, eax
00007ea2ca7ceee7  mov r12d, 0x40
00007ea2ca7ceeed  cmp r14, r12
00007ea2ca7ceef0  cmc
00007ea2ca7ceef1  lahf
00007ea2ca7ceef2  seto al
00007ea2ca7ceef5  mov [r15+0x108], eax
00007ea2ca7ceefc  mov eax, [r15+0x108]
00007ea2ca7cef03  sahf
00007ea2ca7cef04  jnz 0x00007EA2CA7CEF36
00007ea2ca7cef06  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cef0e  jz 0x00007EA2CA7CF020
00007ea2ca7cef14  nop [rax+rax*1], ax
00007ea2ca7cef1d  nop [rax+rax*1], eax
00007ea2ca7cef25  mov eax, 0x4103A0
00007ea2ca7cef2a  mov [r15+0x100], rax
00007ea2ca7cef31  jmp 0x00007EA2CA5FE110
00007ea2ca7cef36  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cef3e  jz 0x00007EA2CA7CEF90
00007ea2ca7cef44  nop [rax+rax*1], ax
00007ea2ca7cef4d  nop [rax+rax*1], eax
00007ea2ca7cef55  mov eax, 0x410378
00007ea2ca7cef5a  mov [r15+0x100], rax
00007ea2ca7cef61  jmp 0x00007EA2CA5FE110
00007ea2ca7cef66  int3
00007ea2ca7cef67  call 0x00007EA2CA60D860
00007ea2ca7cef6c  jmp 0x00007EA2CA7CEE8A
00007ea2ca7cef71  call 0x00007EA2CA6B36E0
00007ea2ca7cef76  jmp 0x00007EA2CA7CEEBA
00007ea2ca7cef7b  call 0x00007EA2CA60DD60
00007ea2ca7cef80  jmp 0x00007EA2CA7CEED4
00007ea2ca7cef85  call 0x00007EA2CA60DC20
00007ea2ca7cef8a  jmp 0x00007EA2CA7CEEDE
00007ea2ca7cef8f  int3
00007ea2ca7cef90  mov rax, [r15+0x10]
00007ea2ca7cef94  lea r14, [rax-0x01]
00007ea2ca7cef98  mov [r15+0x10], r14
00007ea2ca7cef9c  test r14, r14
00007ea2ca7cef9f  setz r14b
00007ea2ca7cefa3  movzx r14, r14b
00007ea2ca7cefa7  mov [rsp+0x414], r14b
00007ea2ca7cefaf  cmp byte ptr [rsp+0x414], 0x00
00007ea2ca7cefb7  jz 0x00007EA2CA7CEFE9
00007ea2ca7cefb9  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cefc1  jz 0x00007EA2CA7D0520
00007ea2ca7cefc7  nop [rax+rax*1], ax
00007ea2ca7cefd0  nop [rax+rax*1], eax
00007ea2ca7cefd8  mov eax, 0x410598
00007ea2ca7cefdd  mov [r15+0x100], rax
00007ea2ca7cefe4  jmp 0x00007EA2CA5FE110
00007ea2ca7cefe9  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7ceff1  jz 0x00007EA2CA7CEE80
00007ea2ca7ceff7  nop [rax+rax*1], ax
00007ea2ca7cf000  nop [rax+rax*1], eax
00007ea2ca7cf008  mov eax, 0x410380
00007ea2ca7cf00d  mov [r15+0x100], rax
00007ea2ca7cf014  jmp 0x00007EA2CA5FE110
00007ea2ca7cf019  int3
00007ea2ca7cf01a  int3
00007ea2ca7cf01b  nop [rax+rax*1], eax
00007ea2ca7cf020  mov rax, [r15+0x40]
00007ea2ca7cf024  movzx r14d, byte ptr [r13+rax*1]
00007ea2ca7cf02a  movaps xmm1, [r15+0x110]
00007ea2ca7cf032  pinsrb xmm1, r14d, 0x00
00007ea2ca7cf039  lea r14, [rax+0x01]
00007ea2ca7cf03d  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf043  movaps xmm15, [r15+0x120]
00007ea2ca7cf04b  pinsrb xmm15, r12d, 0x00
00007ea2ca7cf052  lea r14, [rax+0x02]
00007ea2ca7cf056  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf05c  movaps xmm14, [r15+0x130]
00007ea2ca7cf064  pinsrb xmm14, r12d, 0x00
00007ea2ca7cf06b  lea r14, [rax+0x03]
00007ea2ca7cf06f  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf075  movaps xmm13, [r15+0x140]
00007ea2ca7cf07d  pinsrb xmm13, r12d, 0x00
00007ea2ca7cf084  lea r14, [rax+0x04]
00007ea2ca7cf088  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf08e  pinsrb xmm1, r12d, 0x01
00007ea2ca7cf095  lea r14, [rax+0x05]
00007ea2ca7cf099  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf09f  pinsrb xmm15, r12d, 0x01
00007ea2ca7cf0a6  lea r14, [rax+0x06]
00007ea2ca7cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf0b0  pinsrb xmm14, r12d, 0x01
00007ea2ca7cf0b7  lea r14, [rax+0x07]
00007ea2ca7cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf0c1  pinsrb xmm13, r12d, 0x01
00007ea2ca7cf0c8  lea r14, [rax+0x08]
00007ea2ca7cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf0d2  pinsrb xmm1, r12d, 0x02
00007ea2ca7cf0d9  lea r14, [rax+0x09]
00007ea2ca7cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf0e3  pinsrb xmm15, r12d, 0x02
00007ea2ca7cf0ea  lea r14, [rax+0x0A]
00007ea2ca7cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf0f4  pinsrb xmm14, r12d, 0x02
00007ea2ca7cf0fb  lea r14, [rax+0x0B]
00007ea2ca7cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf105  pinsrb xmm13, r12d, 0x02
00007ea2ca7cf10c  lea r14, [rax+0x0C]
00007ea2ca7cf110  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf116  pinsrb xmm1, r12d, 0x03
00007ea2ca7cf11d  lea r14, [rax+0x0D]
00007ea2ca7cf121  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf127  pinsrb xmm15, r12d, 0x03
00007ea2ca7cf12e  lea r14, [rax+0x0E]
00007ea2ca7cf132  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf138  pinsrb xmm14, r12d, 0x03
00007ea2ca7cf13f  lea r14, [rax+0x0F]
00007ea2ca7cf143  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf149  pinsrb xmm13, r12d, 0x03
00007ea2ca7cf150  lea r14, [rax+0x10]
00007ea2ca7cf154  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf15a  pinsrb xmm1, r12d, 0x04
00007ea2ca7cf161  lea r14, [rax+0x11]
00007ea2ca7cf165  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf16b  pinsrb xmm15, r12d, 0x04
00007ea2ca7cf172  lea r14, [rax+0x12]
00007ea2ca7cf176  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf17c  pinsrb xmm14, r12d, 0x04
00007ea2ca7cf183  lea r14, [rax+0x13]
00007ea2ca7cf187  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf18d  pinsrb xmm13, r12d, 0x04
00007ea2ca7cf194  lea r14, [rax+0x14]
00007ea2ca7cf198  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf19e  pinsrb xmm1, r12d, 0x05
00007ea2ca7cf1a5  lea r14, [rax+0x15]
00007ea2ca7cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf1af  pinsrb xmm15, r12d, 0x05
00007ea2ca7cf1b6  lea r14, [rax+0x16]
00007ea2ca7cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf1c0  pinsrb xmm14, r12d, 0x05
00007ea2ca7cf1c7  lea r14, [rax+0x17]
00007ea2ca7cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf1d1  pinsrb xmm13, r12d, 0x05
00007ea2ca7cf1d8  lea r14, [rax+0x18]
00007ea2ca7cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf1e2  pinsrb xmm1, r12d, 0x06
00007ea2ca7cf1e9  lea r14, [rax+0x19]
00007ea2ca7cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf1f3  pinsrb xmm15, r12d, 0x06
00007ea2ca7cf1fa  lea r14, [rax+0x1A]
00007ea2ca7cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf204  pinsrb xmm14, r12d, 0x06
00007ea2ca7cf20b  lea r14, [rax+0x1B]
00007ea2ca7cf20f  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf215  pinsrb xmm13, r12d, 0x06
00007ea2ca7cf21c  lea r14, [rax+0x1C]
00007ea2ca7cf220  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf226  pinsrb xmm1, r12d, 0x07
00007ea2ca7cf22d  lea r14, [rax+0x1D]
00007ea2ca7cf231  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf237  pinsrb xmm15, r12d, 0x07
00007ea2ca7cf23e  lea r14, [rax+0x1E]
00007ea2ca7cf242  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf248  pinsrb xmm14, r12d, 0x07
00007ea2ca7cf24f  lea r14, [rax+0x1F]
00007ea2ca7cf253  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf259  pinsrb xmm13, r12d, 0x07
00007ea2ca7cf260  lea r14, [rax+0x20]
00007ea2ca7cf264  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf26a  pinsrb xmm1, r12d, 0x08
00007ea2ca7cf271  lea r14, [rax+0x21]
00007ea2ca7cf275  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf27b  pinsrb xmm15, r12d, 0x08
00007ea2ca7cf282  lea r14, [rax+0x22]
00007ea2ca7cf286  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf28c  pinsrb xmm14, r12d, 0x08
00007ea2ca7cf293  lea r14, [rax+0x23]
00007ea2ca7cf297  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf29d  pinsrb xmm13, r12d, 0x08
00007ea2ca7cf2a4  lea r14, [rax+0x24]
00007ea2ca7cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf2ae  pinsrb xmm1, r12d, 0x09
00007ea2ca7cf2b5  lea r14, [rax+0x25]
00007ea2ca7cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf2bf  pinsrb xmm15, r12d, 0x09
00007ea2ca7cf2c6  lea r14, [rax+0x26]
00007ea2ca7cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf2d0  pinsrb xmm14, r12d, 0x09
00007ea2ca7cf2d7  lea r14, [rax+0x27]
00007ea2ca7cf2db  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf2e1  pinsrb xmm13, r12d, 0x09
00007ea2ca7cf2e8  lea r14, [rax+0x28]
00007ea2ca7cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf2f2  pinsrb xmm1, r12d, 0x0A
00007ea2ca7cf2f9  lea r14, [rax+0x29]
00007ea2ca7cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf303  pinsrb xmm15, r12d, 0x0A
00007ea2ca7cf30a  lea r14, [rax+0x2A]
00007ea2ca7cf30e  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf314  pinsrb xmm14, r12d, 0x0A
00007ea2ca7cf31b  lea r14, [rax+0x2B]
00007ea2ca7cf31f  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf325  pinsrb xmm13, r12d, 0x0A
00007ea2ca7cf32c  lea r14, [rax+0x2C]
00007ea2ca7cf330  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf336  pinsrb xmm1, r12d, 0x0B
00007ea2ca7cf33d  lea r14, [rax+0x2D]
00007ea2ca7cf341  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf347  pinsrb xmm15, r12d, 0x0B
00007ea2ca7cf34e  lea r14, [rax+0x2E]
00007ea2ca7cf352  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf358  pinsrb xmm14, r12d, 0x0B
00007ea2ca7cf35f  lea r14, [rax+0x2F]
00007ea2ca7cf363  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf369  pinsrb xmm13, r12d, 0x0B
00007ea2ca7cf370  lea r14, [rax+0x30]
00007ea2ca7cf374  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf37a  pinsrb xmm1, r12d, 0x0C
00007ea2ca7cf381  lea r14, [rax+0x31]
00007ea2ca7cf385  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf38b  pinsrb xmm15, r12d, 0x0C
00007ea2ca7cf392  lea r14, [rax+0x32]
00007ea2ca7cf396  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf39c  pinsrb xmm14, r12d, 0x0C
00007ea2ca7cf3a3  lea r14, [rax+0x33]
00007ea2ca7cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf3ad  pinsrb xmm13, r12d, 0x0C
00007ea2ca7cf3b4  lea r14, [rax+0x34]
00007ea2ca7cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf3be  pinsrb xmm1, r12d, 0x0D
00007ea2ca7cf3c5  lea r14, [rax+0x35]
00007ea2ca7cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf3cf  pinsrb xmm15, r12d, 0x0D
00007ea2ca7cf3d6  lea r14, [rax+0x36]
00007ea2ca7cf3da  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf3e0  pinsrb xmm14, r12d, 0x0D
00007ea2ca7cf3e7  lea r14, [rax+0x37]
00007ea2ca7cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf3f1  pinsrb xmm13, r12d, 0x0D
00007ea2ca7cf3f8  lea r14, [rax+0x38]
00007ea2ca7cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf402  pinsrb xmm1, r12d, 0x0E
00007ea2ca7cf409  lea r14, [rax+0x39]
00007ea2ca7cf40d  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf413  pinsrb xmm15, r12d, 0x0E
00007ea2ca7cf41a  lea r14, [rax+0x3A]
00007ea2ca7cf41e  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf424  pinsrb xmm14, r12d, 0x0E
00007ea2ca7cf42b  lea r14, [rax+0x3B]
00007ea2ca7cf42f  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf435  pinsrb xmm13, r12d, 0x0E
00007ea2ca7cf43c  lea r14, [rax+0x3C]
00007ea2ca7cf440  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf446  pinsrb xmm1, r12d, 0x0F
00007ea2ca7cf44d  movaps [r15+0x110], xmm1
00007ea2ca7cf455  lea r14, [rax+0x3D]
00007ea2ca7cf459  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf45f  pinsrb xmm15, r12d, 0x0F
00007ea2ca7cf466  movaps [r15+0x120], xmm15
00007ea2ca7cf46e  lea r14, [rax+0x3E]
00007ea2ca7cf472  movzx r12d, byte ptr [r13+r14*1]
00007ea2ca7cf478  pinsrb xmm14, r12d, 0x0F
00007ea2ca7cf47f  movaps [r15+0x130], xmm14
00007ea2ca7cf487  lea r14, [rax+0x3F]
00007ea2ca7cf48b  movzx eax, byte ptr [r13+r14*1]
00007ea2ca7cf491  pinsrb xmm13, eax, 0x0F
00007ea2ca7cf498  movaps [r15+0x140], xmm13
00007ea2ca7cf4a0  movq xmm1, qword ptr [r15+0x120]
00007ea2ca7cf4a9  pmovzxbw xmm1, xmm1
00007ea2ca7cf4ae  psllw xmm1, 0x00
00007ea2ca7cf4b3  movaps [r15+0x150], xmm1
00007ea2ca7cf4bb  movq xmm1, qword ptr [r15+0x130]
00007ea2ca7cf4c4  pmovzxbw xmm1, xmm1
00007ea2ca7cf4c9  psllw xmm1, 0x00
00007ea2ca7cf4ce  movaps [r15+0x160], xmm1
00007ea2ca7cf4d6  movq xmm1, qword ptr [r15+0x110]
00007ea2ca7cf4df  pmovzxbw xmm1, xmm1
00007ea2ca7cf4e4  psllw xmm1, 0x00
00007ea2ca7cf4e9  movaps [r15+0x170], xmm1
00007ea2ca7cf4f1  movaps xmm15, [r15+0x110]
00007ea2ca7cf4f9  pextrq rax, xmm15, 0x01
00007ea2ca7cf500  movq xmm15, rax
00007ea2ca7cf505  pmovzxbw xmm15, xmm15
00007ea2ca7cf50b  psllw xmm15, 0x00
00007ea2ca7cf511  movaps [r15+0x180], xmm15
00007ea2ca7cf519  movaps xmm14, [r15+0x120]
00007ea2ca7cf521  pextrq rax, xmm14, 0x01
00007ea2ca7cf528  movq xmm14, rax
00007ea2ca7cf52d  pmovzxbw xmm14, xmm14
00007ea2ca7cf533  psllw xmm14, 0x00
00007ea2ca7cf539  movaps [r15+0x210], xmm14
00007ea2ca7cf541  movaps xmm13, [r15+0x130]
00007ea2ca7cf549  pextrq rax, xmm13, 0x01
00007ea2ca7cf550  movq xmm13, rax
00007ea2ca7cf555  pmovzxbw xmm13, xmm13
00007ea2ca7cf55b  psllw xmm13, 0x00
00007ea2ca7cf561  movaps [r15+0x220], xmm13
00007ea2ca7cf569  movq xmm12, qword ptr [r15+0x140]
00007ea2ca7cf572  pmovzxbw xmm12, xmm12
00007ea2ca7cf578  psllw xmm12, 0x00
00007ea2ca7cf57e  movaps [r15+0x250], xmm12
00007ea2ca7cf586  movaps xmm12, [r15+0x140]
00007ea2ca7cf58e  pextrq rax, xmm12, 0x01
00007ea2ca7cf595  movq xmm12, rax
00007ea2ca7cf59a  pmovzxbw xmm12, xmm12
00007ea2ca7cf5a0  psllw xmm12, 0x00
00007ea2ca7cf5a6  movaps [r15+0x110], xmm12
00007ea2ca7cf5ae  movq xmm11, qword ptr [r15+0x150]
00007ea2ca7cf5b7  pmovzxwd xmm11, xmm11
00007ea2ca7cf5bd  pslld xmm11, 0x10
00007ea2ca7cf5c3  movq xmm10, qword ptr [r15+0x160]
00007ea2ca7cf5cc  pmovzxwd xmm10, xmm10
00007ea2ca7cf5d2  pslld xmm10, 0x08
00007ea2ca7cf5d8  pextrq rax, xmm1, 0x01
00007ea2ca7cf5df  movq xmm1, rax
00007ea2ca7cf5e4  pmovzxwd xmm1, xmm1
00007ea2ca7cf5e9  pslld xmm1, 0x00
00007ea2ca7cf5ee  movaps [r15+0x260], xmm1
00007ea2ca7cf5f6  pextrq rax, xmm15, 0x01
00007ea2ca7cf5fd  movq xmm15, rax
00007ea2ca7cf602  pmovzxwd xmm15, xmm15
00007ea2ca7cf608  pslld xmm15, 0x00
00007ea2ca7cf60e  movaps [r15+0x270], xmm15
00007ea2ca7cf616  movq xmm9, qword ptr [r15+0x170]
00007ea2ca7cf61f  pmovzxwd xmm9, xmm9
00007ea2ca7cf625  pslld xmm9, 0x00
00007ea2ca7cf62b  pextrq rax, xmm14, 0x01
00007ea2ca7cf632  movq xmm14, rax
00007ea2ca7cf637  pmovzxwd xmm14, xmm14
00007ea2ca7cf63d  pslld xmm14, 0x10
00007ea2ca7cf643  movaps [r15+0x280], xmm14
00007ea2ca7cf64b  movq xmm8, qword ptr [r15+0x180]
00007ea2ca7cf654  pmovzxwd xmm8, xmm8
00007ea2ca7cf65a  pslld xmm8, 0x00
00007ea2ca7cf660  movq xmm7, qword ptr [r15+0x210]
00007ea2ca7cf669  pmovzxwd xmm7, xmm7
00007ea2ca7cf66e  pslld xmm7, 0x10
00007ea2ca7cf673  movaps xmm6, [r15+0x150]
00007ea2ca7cf67b  pextrq rax, xmm6, 0x01
00007ea2ca7cf682  movq xmm6, rax
00007ea2ca7cf687  pmovzxwd xmm6, xmm6
00007ea2ca7cf68c  pslld xmm6, 0x10
00007ea2ca7cf691  por xmm11, xmm10
00007ea2ca7cf696  movaps [r15+0x230], xmm11
00007ea2ca7cf69e  pextrq rax, xmm13, 0x01
00007ea2ca7cf6a5  movq xmm13, rax
00007ea2ca7cf6aa  pmovzxwd xmm13, xmm13
00007ea2ca7cf6b0  pslld xmm13, 0x08
00007ea2ca7cf6b6  movaps [r15+0x240], xmm13
00007ea2ca7cf6be  movq xmm10, qword ptr [r15+0x220]
00007ea2ca7cf6c7  pmovzxwd xmm10, xmm10
00007ea2ca7cf6cd  pslld xmm10, 0x08
00007ea2ca7cf6d3  movaps xmm5, [r15+0x160]
00007ea2ca7cf6db  pextrq rax, xmm5, 0x01
00007ea2ca7cf6e2  movq xmm5, rax
00007ea2ca7cf6e7  pmovzxwd xmm5, xmm5
00007ea2ca7cf6ec  pslld xmm5, 0x08
00007ea2ca7cf6f1  pslld xmm9, 0x18
00007ea2ca7cf6f7  pslld xmm15, 0x18
00007ea2ca7cf6fd  pslld xmm8, 0x18
00007ea2ca7cf703  movq xmm4, qword ptr [r15+0x250]
00007ea2ca7cf70c  pmovzxwd xmm4, xmm4
00007ea2ca7cf711  pslld xmm4, 0x00
00007ea2ca7cf716  por xmm14, xmm13
00007ea2ca7cf71b  por xmm7, xmm10
00007ea2ca7cf720  movaps [r15+0x210], xmm7
00007ea2ca7cf728  pslld xmm1, 0x18
00007ea2ca7cf72d  movaps [r15+0x220], xmm1
00007ea2ca7cf735  por xmm6, xmm5
00007ea2ca7cf739  por xmm11, xmm9
00007ea2ca7cf73e  movaps [r15+0x160], xmm11
00007ea2ca7cf746  pextrq rax, xmm12, 0x01
00007ea2ca7cf74d  movq xmm13, rax
00007ea2ca7cf752  pmovzxwd xmm13, xmm13
00007ea2ca7cf758  pslld xmm13, 0x00
00007ea2ca7cf75e  movaps [r15+0x170], xmm13
00007ea2ca7cf766  movq xmm12, qword ptr [r15+0x110]
00007ea2ca7cf76f  pmovzxwd xmm12, xmm12
00007ea2ca7cf775  pslld xmm12, 0x00
00007ea2ca7cf77b  por xmm14, xmm15
00007ea2ca7cf780  por xmm7, xmm8
00007ea2ca7cf785  movaps xmm15, [r15+0x250]
00007ea2ca7cf78d  pextrq rax, xmm15, 0x01
00007ea2ca7cf794  movq xmm15, rax
00007ea2ca7cf799  pmovzxwd xmm15, xmm15
00007ea2ca7cf79f  pslld xmm15, 0x00
00007ea2ca7cf7a5  movaps [r15+0x180], xmm15
00007ea2ca7cf7ad  por xmm6, xmm1
00007ea2ca7cf7b1  movaps [r15+0x150], xmm6
00007ea2ca7cf7b9  por xmm11, xmm4
00007ea2ca7cf7be  movaps [r15+0x140], xmm11
00007ea2ca7cf7c6  por xmm7, xmm12
00007ea2ca7cf7cb  movaps [r15+0x110], xmm7
00007ea2ca7cf7d3  por xmm14, xmm13
00007ea2ca7cf7d8  movaps [r15+0x120], xmm14
00007ea2ca7cf7e0  por xmm6, xmm15
00007ea2ca7cf7e5  movaps [r15+0x130], xmm6
00007ea2ca7cf7ed  mov rax, [r15+0xF8]
00007ea2ca7cf7f4  lea r14, [rax+0x20]
00007ea2ca7cf7f8  movups [r13+r14*1], xmm7
00007ea2ca7cf7fe  lea r14, [rax+0x30]
00007ea2ca7cf802  movups [r13+r14*1], xmm14
00007ea2ca7cf808  movups [r13+rax*1], xmm11
00007ea2ca7cf80e  lea r14, [rax+0x10]
00007ea2ca7cf812  movups [r13+r14*1], xmm6
00007ea2ca7cf818  mov r14d, [r13+rax*1]
00007ea2ca7cf81d  mov rax, [r15+0x48]
00007ea2ca7cf821  mov [r15+0x68], rax
00007ea2ca7cf825  mov qword ptr [r15+0x58], 0x04
00007ea2ca7cf82d  lea r12, [rax+0x04]
00007ea2ca7cf831  mov r11d, [r13+r12*1]
00007ea2ca7cf836  mov [rsp+0x10], r11d
00007ea2ca7cf83b  mov r11d, r11d
00007ea2ca7cf83e  mov [r15+0x70], r11
00007ea2ca7cf842  lea r12, [rax+0x38]
00007ea2ca7cf846  mov r11d, [r13+r12*1]
00007ea2ca7cf84b  lea r12, [rax+0x24]
00007ea2ca7cf84f  mov r10d, [r13+r12*1]
00007ea2ca7cf854  mov [rsp+0x20], r10d
00007ea2ca7cf859  mov r10d, r10d
00007ea2ca7cf85c  mov [r15+0x90], r10
00007ea2ca7cf863  mov [rsp+0x30], rax
00007ea2ca7cf868  xor eax, eax
00007ea2ca7cf86a  mov r12d, 0x04
00007ea2ca7cf870  mov r10d, 0xC0
00007ea2ca7cf876  cmp r12, r10
00007ea2ca7cf879  cmc
00007ea2ca7cf87a  lahf
00007ea2ca7cf87b  seto al
00007ea2ca7cf87e  mov [r15+0x108], eax
00007ea2ca7cf885  mov eax, [rsp+0x10]
00007ea2ca7cf889  mov r12d, [rsp+0x10]
00007ea2ca7cf88e  shrd eax, r12d, 0x07
00007ea2ca7cf893  mov [rsp+0x10], r11d
00007ea2ca7cf898  mov r10d, [rsp+0x10]
00007ea2ca7cf89d  shrd r11d, r10d, 0x11
00007ea2ca7cf8a2  mov r9d, [rsp+0x20]
00007ea2ca7cf8a7  lea r8d, [r9d+r14d*1]
00007ea2ca7cf8ac  rorx r14d, r12d, 0x12
00007ea2ca7cf8b2  xor eax, r14d
00007ea2ca7cf8b5  rorx r14d, r10d, 0x13
00007ea2ca7cf8bb  xor r11d, r14d
00007ea2ca7cf8be  mov [rsp+0x10], r11d
00007ea2ca7cf8c3  mov r11d, r11d
00007ea2ca7cf8c6  mov [r15+0x88], r11
00007ea2ca7cf8cd  mov [rsp+0x20], r12d
00007ea2ca7cf8d2  shr r12d, 0x03
00007ea2ca7cf8d6  xor eax, r12d
00007ea2ca7cf8d9  mov [rsp+0x40], eax
00007ea2ca7cf8dd  mov eax, eax
00007ea2ca7cf8df  mov [r15+0x80], rax
00007ea2ca7cf8e6  shr r10d, 0x0A
00007ea2ca7cf8ea  mov eax, [rsp+0x10]
00007ea2ca7cf8ee  xor eax, r10d
00007ea2ca7cf8f1  mov [rsp+0x10], eax
00007ea2ca7cf8f5  mov eax, eax
00007ea2ca7cf8f7  mov [r15+0x78], rax
00007ea2ca7cf8fb  mov eax, [rsp+0x40]
00007ea2ca7cf8ff  lea r14d, [r8d+eax*1]
00007ea2ca7cf904  mov eax, [rsp+0x10]
00007ea2ca7cf908  lea r12d, [r14d+eax*1]
00007ea2ca7cf90d  mov rax, [rsp+0x30]
00007ea2ca7cf912  lea r14, [rax+0x40]
00007ea2ca7cf916  mov [r13+r14*1], r12d
00007ea2ca7cf91b  mov eax, [rsp+0x20]
00007ea2ca7cf91f  mov eax, eax
00007ea2ca7cf921  mov [r15+0x60], rax
00007ea2ca7cf925  mov eax, [r15+0x108]
00007ea2ca7cf92c  sahf
00007ea2ca7cf92d  jnz 0x00007EA2CA7CF95F
00007ea2ca7cf92f  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cf937  jz 0x00007EA2CA7CFE20
00007ea2ca7cf93d  nop [rax+rax*1], ax
00007ea2ca7cf946  nop [rax+rax*1], eax
00007ea2ca7cf94e  mov eax, 0x41049C
00007ea2ca7cf953  mov [r15+0x100], rax
00007ea2ca7cf95a  jmp 0x00007EA2CA5FE110
00007ea2ca7cf95f  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cf967  jz 0x00007EA2CA7CFC70
00007ea2ca7cf96d  nop [rax+rax*1], ax
00007ea2ca7cf976  nop [rax+rax*1], eax
00007ea2ca7cf97e  mov eax, 0x410454
00007ea2ca7cf983  mov [r15+0x100], rax
00007ea2ca7cf98a  jmp 0x00007EA2CA5FE110
00007ea2ca7cf98f  int3
00007ea2ca7cf990  call 0x00007EA2CA60D860
00007ea2ca7cf995  jmp 0x00007EA2CA7CF02A
00007ea2ca7cf99a  call 0x00007EA2CA6E2420
00007ea2ca7cf99f  jmp 0x00007EA2CA7CF043
00007ea2ca7cf9a4  call 0x00007EA2CA6E2420
00007ea2ca7cf9a9  jmp 0x00007EA2CA7CF05C
00007ea2ca7cf9ae  call 0x00007EA2CA6E2420
00007ea2ca7cf9b3  jmp 0x00007EA2CA7CF075
00007ea2ca7cf9b8  call 0x00007EA2CA6E2420
00007ea2ca7cf9bd  jmp 0x00007EA2CA7CF08E
00007ea2ca7cf9c2  call 0x00007EA2CA6E2420
00007ea2ca7cf9c7  jmp 0x00007EA2CA7CF09F
00007ea2ca7cf9cc  call 0x00007EA2CA6E2420
00007ea2ca7cf9d1  jmp 0x00007EA2CA7CF0B0
00007ea2ca7cf9d6  call 0x00007EA2CA6E2420
00007ea2ca7cf9db  jmp 0x00007EA2CA7CF0C1
00007ea2ca7cf9e0  call 0x00007EA2CA6E2420
00007ea2ca7cf9e5  jmp 0x00007EA2CA7CF0D2
00007ea2ca7cf9ea  call 0x00007EA2CA6E2420
00007ea2ca7cf9ef  jmp 0x00007EA2CA7CF0E3
00007ea2ca7cf9f4  call 0x00007EA2CA6E2420
00007ea2ca7cf9f9  jmp 0x00007EA2CA7CF0F4
00007ea2ca7cf9fe  call 0x00007EA2CA6E2420
00007ea2ca7cfa03  jmp 0x00007EA2CA7CF105
00007ea2ca7cfa08  call 0x00007EA2CA6E2420
00007ea2ca7cfa0d  jmp 0x00007EA2CA7CF116
00007ea2ca7cfa12  call 0x00007EA2CA6E2420
00007ea2ca7cfa17  jmp 0x00007EA2CA7CF127
00007ea2ca7cfa1c  call 0x00007EA2CA6E2420
00007ea2ca7cfa21  jmp 0x00007EA2CA7CF138
00007ea2ca7cfa26  call 0x00007EA2CA6E2420
00007ea2ca7cfa2b  jmp 0x00007EA2CA7CF149
00007ea2ca7cfa30  call 0x00007EA2CA6E2420
00007ea2ca7cfa35  jmp 0x00007EA2CA7CF15A
00007ea2ca7cfa3a  call 0x00007EA2CA6E2420
00007ea2ca7cfa3f  jmp 0x00007EA2CA7CF16B
00007ea2ca7cfa44  call 0x00007EA2CA6E2420
00007ea2ca7cfa49  jmp 0x00007EA2CA7CF17C
00007ea2ca7cfa4e  call 0x00007EA2CA6E2420
00007ea2ca7cfa53  jmp 0x00007EA2CA7CF18D
00007ea2ca7cfa58  call 0x00007EA2CA6E2420
00007ea2ca7cfa5d  jmp 0x00007EA2CA7CF19E
00007ea2ca7cfa62  call 0x00007EA2CA6E2420
00007ea2ca7cfa67  jmp 0x00007EA2CA7CF1AF
00007ea2ca7cfa6c  call 0x00007EA2CA6E2420
00007ea2ca7cfa71  jmp 0x00007EA2CA7CF1C0
00007ea2ca7cfa76  call 0x00007EA2CA6E2420
00007ea2ca7cfa7b  jmp 0x00007EA2CA7CF1D1
00007ea2ca7cfa80  call 0x00007EA2CA6E2420
00007ea2ca7cfa85  jmp 0x00007EA2CA7CF1E2
00007ea2ca7cfa8a  call 0x00007EA2CA6E2420
00007ea2ca7cfa8f  jmp 0x00007EA2CA7CF1F3
00007ea2ca7cfa94  call 0x00007EA2CA6E2420
00007ea2ca7cfa99  jmp 0x00007EA2CA7CF204
00007ea2ca7cfa9e  call 0x00007EA2CA6E2420
00007ea2ca7cfaa3  jmp 0x00007EA2CA7CF215
00007ea2ca7cfaa8  call 0x00007EA2CA6E2420
00007ea2ca7cfaad  jmp 0x00007EA2CA7CF226
00007ea2ca7cfab2  call 0x00007EA2CA6E2420
00007ea2ca7cfab7  jmp 0x00007EA2CA7CF237
00007ea2ca7cfabc  call 0x00007EA2CA6E2420
00007ea2ca7cfac1  jmp 0x00007EA2CA7CF248
00007ea2ca7cfac6  call 0x00007EA2CA6E2420
00007ea2ca7cfacb  jmp 0x00007EA2CA7CF259
00007ea2ca7cfad0  call 0x00007EA2CA6E2420
00007ea2ca7cfad5  jmp 0x00007EA2CA7CF26A
00007ea2ca7cfada  call 0x00007EA2CA6E2420
00007ea2ca7cfadf  jmp 0x00007EA2CA7CF27B
00007ea2ca7cfae4  call 0x00007EA2CA6E2420
00007ea2ca7cfae9  jmp 0x00007EA2CA7CF28C
00007ea2ca7cfaee  call 0x00007EA2CA6E2420
00007ea2ca7cfaf3  jmp 0x00007EA2CA7CF29D
00007ea2ca7cfaf8  call 0x00007EA2CA6E2420
00007ea2ca7cfafd  jmp 0x00007EA2CA7CF2AE
00007ea2ca7cfb02  call 0x00007EA2CA6E2420
00007ea2ca7cfb07  jmp 0x00007EA2CA7CF2BF
00007ea2ca7cfb0c  call 0x00007EA2CA6E2420
00007ea2ca7cfb11  jmp 0x00007EA2CA7CF2D0
00007ea2ca7cfb16  call 0x00007EA2CA6E2420
00007ea2ca7cfb1b  jmp 0x00007EA2CA7CF2E1
00007ea2ca7cfb20  call 0x00007EA2CA6E2420
00007ea2ca7cfb25  jmp 0x00007EA2CA7CF2F2
00007ea2ca7cfb2a  call 0x00007EA2CA6E2420
00007ea2ca7cfb2f  jmp 0x00007EA2CA7CF303
00007ea2ca7cfb34  call 0x00007EA2CA6E2420
00007ea2ca7cfb39  jmp 0x00007EA2CA7CF314
00007ea2ca7cfb3e  call 0x00007EA2CA6E2420
00007ea2ca7cfb43  jmp 0x00007EA2CA7CF325
00007ea2ca7cfb48  call 0x00007EA2CA6E2420
00007ea2ca7cfb4d  jmp 0x00007EA2CA7CF336
00007ea2ca7cfb52  call 0x00007EA2CA6E2420
00007ea2ca7cfb57  jmp 0x00007EA2CA7CF347
00007ea2ca7cfb5c  call 0x00007EA2CA6E2420
00007ea2ca7cfb61  jmp 0x00007EA2CA7CF358
00007ea2ca7cfb66  call 0x00007EA2CA6E2420
00007ea2ca7cfb6b  jmp 0x00007EA2CA7CF369
00007ea2ca7cfb70  call 0x00007EA2CA6E2420
00007ea2ca7cfb75  jmp 0x00007EA2CA7CF37A
00007ea2ca7cfb7a  call 0x00007EA2CA6E2420
00007ea2ca7cfb7f  jmp 0x00007EA2CA7CF38B
00007ea2ca7cfb84  call 0x00007EA2CA6E2420
00007ea2ca7cfb89  jmp 0x00007EA2CA7CF39C
00007ea2ca7cfb8e  call 0x00007EA2CA6E2420
00007ea2ca7cfb93  jmp 0x00007EA2CA7CF3AD
00007ea2ca7cfb98  call 0x00007EA2CA6E2420
00007ea2ca7cfb9d  jmp 0x00007EA2CA7CF3BE
00007ea2ca7cfba2  call 0x00007EA2CA6E2420
00007ea2ca7cfba7  jmp 0x00007EA2CA7CF3CF
00007ea2ca7cfbac  call 0x00007EA2CA6E2420
00007ea2ca7cfbb1  jmp 0x00007EA2CA7CF3E0
00007ea2ca7cfbb6  call 0x00007EA2CA6E2420
00007ea2ca7cfbbb  jmp 0x00007EA2CA7CF3F1
00007ea2ca7cfbc0  call 0x00007EA2CA6E2420
00007ea2ca7cfbc5  jmp 0x00007EA2CA7CF402
00007ea2ca7cfbca  call 0x00007EA2CA6E2420
00007ea2ca7cfbcf  jmp 0x00007EA2CA7CF413
00007ea2ca7cfbd4  call 0x00007EA2CA6E2420
00007ea2ca7cfbd9  jmp 0x00007EA2CA7CF424
00007ea2ca7cfbde  call 0x00007EA2CA6E2420
00007ea2ca7cfbe3  jmp 0x00007EA2CA7CF435
00007ea2ca7cfbe8  call 0x00007EA2CA6E2420
00007ea2ca7cfbed  jmp 0x00007EA2CA7CF446
00007ea2ca7cfbf2  call 0x00007EA2CA6E2420
00007ea2ca7cfbf7  jmp 0x00007EA2CA7CF45F
00007ea2ca7cfbfc  call 0x00007EA2CA6E2420
00007ea2ca7cfc01  jmp 0x00007EA2CA7CF478
00007ea2ca7cfc06  call 0x00007EA2CA6D5610
00007ea2ca7cfc0b  jmp 0x00007EA2CA7CF491
00007ea2ca7cfc10  call 0x00007EA2CA6DC580
00007ea2ca7cfc15  jmp 0x00007EA2CA7CF7FE
00007ea2ca7cfc1a  call 0x00007EA2CA6E46C0
00007ea2ca7cfc1f  jmp 0x00007EA2CA7CF808
00007ea2ca7cfc24  call 0x00007EA2CA609E90
00007ea2ca7cfc29  jmp 0x00007EA2CA7CF80E
00007ea2ca7cfc2e  call 0x00007EA2CA6DB310
00007ea2ca7cfc33  jmp 0x00007EA2CA7CF818
00007ea2ca7cfc38  call 0x00007EA2CA60DAE0
00007ea2ca7cfc3d  jmp 0x00007EA2CA7CF81D
00007ea2ca7cfc42  call 0x00007EA2CA6C0230
00007ea2ca7cfc47  jmp 0x00007EA2CA7CF836
00007ea2ca7cfc4c  call 0x00007EA2CA6C0230
00007ea2ca7cfc51  jmp 0x00007EA2CA7CF84B
00007ea2ca7cfc56  call 0x00007EA2CA6BEFC0
00007ea2ca7cfc5b  jmp 0x00007EA2CA7CF854
00007ea2ca7cfc60  call 0x00007EA2CA6E2BA0
00007ea2ca7cfc65  jmp 0x00007EA2CA7CF91B
00007ea2ca7cfc6a  int3
00007ea2ca7cfc6b  nop [rax+rax*1], eax
00007ea2ca7cfc70  mov rax, [r15+0x48]
00007ea2ca7cfc74  mov r14, [r15+0x58]
00007ea2ca7cfc78  lea r12, [rax+r14*1]
00007ea2ca7cfc7c  mov [r15+0x68], r12
00007ea2ca7cfc80  lea rax, [r14+0x04]
00007ea2ca7cfc84  mov [r15+0x58], rax
00007ea2ca7cfc88  lea r14, [r12+0x04]
00007ea2ca7cfc8d  mov r11d, [r13+r14*1]
00007ea2ca7cfc92  mov [rsp+0x10], r11d
00007ea2ca7cfc97  mov r11d, r11d
00007ea2ca7cfc9a  mov [r15+0x70], r11
00007ea2ca7cfc9e  lea r14, [r12+0x38]
00007ea2ca7cfca3  mov r11d, [r13+r14*1]
00007ea2ca7cfca8  lea r14, [r12+0x24]
00007ea2ca7cfcad  mov r10d, [r13+r14*1]
00007ea2ca7cfcb2  mov [rsp+0x20], r10d
00007ea2ca7cfcb7  mov r10d, r10d
00007ea2ca7cfcba  mov [r15+0x90], r10
00007ea2ca7cfcc1  mov [rsp+0x30], rax
00007ea2ca7cfcc6  xor eax, eax
00007ea2ca7cfcc8  mov r14, [rsp+0x30]
00007ea2ca7cfccd  mov r10d, 0xC0
00007ea2ca7cfcd3  cmp r14, r10
00007ea2ca7cfcd6  cmc
00007ea2ca7cfcd7  lahf
00007ea2ca7cfcd8  seto al
00007ea2ca7cfcdb  mov [r15+0x108], eax
00007ea2ca7cfce2  mov eax, [rsp+0x10]
00007ea2ca7cfce6  mov r14d, [rsp+0x10]
00007ea2ca7cfceb  shrd eax, r14d, 0x07
00007ea2ca7cfcf0  mov [rsp+0x10], r11d
00007ea2ca7cfcf5  mov r10d, [rsp+0x10]
00007ea2ca7cfcfa  shrd r11d, r10d, 0x11
00007ea2ca7cfcff  mov r9d, [r15+0x60]
00007ea2ca7cfd03  mov r8d, [rsp+0x20]
00007ea2ca7cfd08  lea ebp, [r8d+r9d*1]
00007ea2ca7cfd0d  rorx r9d, r14d, 0x12
00007ea2ca7cfd13  xor eax, r9d
00007ea2ca7cfd16  rorx r9d, r10d, 0x13
00007ea2ca7cfd1c  xor r11d, r9d
00007ea2ca7cfd1f  mov [rsp+0x10], r11d
00007ea2ca7cfd24  mov r11d, r11d
00007ea2ca7cfd27  mov [r15+0x88], r11
00007ea2ca7cfd2e  mov [rsp+0x20], r14d
00007ea2ca7cfd33  shr r14d, 0x03
00007ea2ca7cfd37  xor eax, r14d
00007ea2ca7cfd3a  mov [rsp+0x30], eax
00007ea2ca7cfd3e  mov eax, eax
00007ea2ca7cfd40  mov [r15+0x80], rax
00007ea2ca7cfd47  shr r10d, 0x0A
00007ea2ca7cfd4b  mov eax, [rsp+0x10]
00007ea2ca7cfd4f  xor eax, r10d
00007ea2ca7cfd52  mov [rsp+0x10], eax
00007ea2ca7cfd56  mov eax, eax
00007ea2ca7cfd58  mov [r15+0x78], rax
00007ea2ca7cfd5c  mov eax, [rsp+0x30]
00007ea2ca7cfd60  lea r14d, [ebp+eax*1]
00007ea2ca7cfd66  mov eax, [rsp+0x10]
00007ea2ca7cfd6a  lea r11d, [r14d+eax*1]
00007ea2ca7cfd6f  lea rax, [r12+0x40]
00007ea2ca7cfd74  mov [r13+rax*1], r11d
00007ea2ca7cfd79  mov eax, [rsp+0x20]
00007ea2ca7cfd7d  mov eax, eax
00007ea2ca7cfd7f  mov [r15+0x60], rax
00007ea2ca7cfd83  mov eax, [r15+0x108]
00007ea2ca7cfd8a  sahf
00007ea2ca7cfd8b  jnz 0x00007EA2CA7CFDBD
00007ea2ca7cfd8d  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cfd95  jz 0x00007EA2CA7CFE20
00007ea2ca7cfd9b  nop [rax+rax*1], ax
00007ea2ca7cfda4  nop [rax+rax*1], eax
00007ea2ca7cfdac  mov eax, 0x41049C
00007ea2ca7cfdb1  mov [r15+0x100], rax
00007ea2ca7cfdb8  jmp 0x00007EA2CA5FE110
00007ea2ca7cfdbd  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7cfdc5  jz 0x00007EA2CA7CFC70
00007ea2ca7cfdcb  nop [rax+rax*1], ax
00007ea2ca7cfdd4  nop [rax+rax*1], eax
00007ea2ca7cfddc  mov eax, 0x410454
00007ea2ca7cfde1  mov [r15+0x100], rax
00007ea2ca7cfde8  jmp 0x00007EA2CA5FE110
00007ea2ca7cfded  int3
00007ea2ca7cfdee  call 0x00007EA2CA6E1430
00007ea2ca7cfdf3  jmp 0x00007EA2CA7CFC92
00007ea2ca7cfdf8  call 0x00007EA2CA6E1430
00007ea2ca7cfdfd  jmp 0x00007EA2CA7CFCA8
00007ea2ca7cfe02  call 0x00007EA2CA6E01C0
00007ea2ca7cfe07  jmp 0x00007EA2CA7CFCB2
00007ea2ca7cfe0c  call 0x00007EA2CA60A860
00007ea2ca7cfe11  jmp 0x00007EA2CA7CFD79
00007ea2ca7cfe16  int3
00007ea2ca7cfe17  nop [rax+rax*1], ax
00007ea2ca7cfe20  mov rax, [r15]
00007ea2ca7cfe23  mov r14d, [r13+rax*1]
00007ea2ca7cfe28  lea r12, [rax+0x04]
00007ea2ca7cfe2c  mov r11d, [r13+r12*1]
00007ea2ca7cfe31  mov [rsp+0x10], r14d
00007ea2ca7cfe36  mov r14d, r14d
00007ea2ca7cfe39  mov [r15+0x78], r14
00007ea2ca7cfe3d  mov [rsp+0x20], r11d
00007ea2ca7cfe42  mov r11d, r11d
00007ea2ca7cfe45  mov [r15+0x80], r11
00007ea2ca7cfe4c  lea r14, [rax+0x08]
00007ea2ca7cfe50  mov r12d, [r13+r14*1]
00007ea2ca7cfe55  lea r14, [rax+0x0C]
00007ea2ca7cfe59  mov r11d, [r13+r14*1]
00007ea2ca7cfe5e  mov [rsp+0x30], r12d
00007ea2ca7cfe63  mov r12d, r12d
00007ea2ca7cfe66  mov [r15+0x70], r12
00007ea2ca7cfe6a  mov [rsp+0x40], r11d
00007ea2ca7cfe6f  mov r11d, r11d
00007ea2ca7cfe72  mov [r15+0x68], r11
00007ea2ca7cfe76  lea r14, [rax+0x18]
00007ea2ca7cfe7a  mov r12d, [r13+r14*1]
00007ea2ca7cfe7f  lea r14, [rax+0x1C]
00007ea2ca7cfe83  mov r11d, [r13+r14*1]
00007ea2ca7cfe88  mov [rsp+0x50], r12d
00007ea2ca7cfe8d  mov r12d, r12d
00007ea2ca7cfe90  mov [r15+0x58], r12
00007ea2ca7cfe94  mov [rsp+0x60], r11d
00007ea2ca7cfe99  mov r11d, r11d
00007ea2ca7cfe9c  mov [r15+0x60], r11
00007ea2ca7cfea0  lea r14, [rax+0x10]
00007ea2ca7cfea4  mov r12d, [r13+r14*1]
00007ea2ca7cfea9  lea r14, [rax+0x14]
00007ea2ca7cfead  mov eax, [r13+r14*1]
00007ea2ca7cfeb2  mov [rsp+0x70], r12d
00007ea2ca7cfeb7  mov r12d, r12d
00007ea2ca7cfeba  mov [r15+0x18], r12
00007ea2ca7cfebe  mov [rsp+0x80], eax
00007ea2ca7cfec5  mov eax, eax
00007ea2ca7cfec7  mov [r15+0x90], rax
00007ea2ca7cfece  mov eax, [rsp+0x70]
00007ea2ca7cfed2  mov eax, eax
00007ea2ca7cfed4  mov [r15+0x30], rax
00007ea2ca7cfed8  mov eax, [rsp+0x50]
00007ea2ca7cfedc  mov eax, eax
00007ea2ca7cfede  mov [r15+0xA0], rax
00007ea2ca7cfee5  mov eax, [rsp+0x30]
00007ea2ca7cfee9  mov eax, eax
00007ea2ca7cfeeb  mov [r15+0x28], rax
00007ea2ca7cfeef  mov eax, [rsp+0x20]
00007ea2ca7cfef3  mov eax, eax
00007ea2ca7cfef5  mov [r15+0x98], rax
00007ea2ca7cfefc  mov eax, [rsp+0x10]
00007ea2ca7cff00  mov eax, eax
00007ea2ca7cff02  mov [r15+0x38], rax
00007ea2ca7cff06  mov eax, [rsp+0x70]
00007ea2ca7cff0a  mov r14d, [rsp+0x70]
00007ea2ca7cff0f  shrd eax, r14d, 0x06
00007ea2ca7cff14  mov [rsp+0x70], r14d
00007ea2ca7cff19  mov r12d, [rsp+0x80]
00007ea2ca7cff21  and r14d, r12d
00007ea2ca7cff24  mov r11d, [rsp+0x10]
00007ea2ca7cff29  mov r10d, [rsp+0x10]
00007ea2ca7cff2e  shrd r11d, r10d, 0x02
00007ea2ca7cff33  mov [rsp+0x10], r12d
00007ea2ca7cff38  mov r12d, r12d
00007ea2ca7cff3b  mov [r15+0x20], r12
00007ea2ca7cff3f  mov r12, [r15+0x50]
00007ea2ca7cff43  mov r9d, [r13+r12*1]
00007ea2ca7cff48  mov r12d, [rsp+0x50]
00007ea2ca7cff4d  mov r8d, [rsp+0x70]
00007ea2ca7cff52  andn ebp, r8d, r12d
00007ea2ca7cff57  mov edi, [rsp+0x60]
00007ea2ca7cff5b  lea esi, [r14d+edi*1]
00007ea2ca7cff60  rorx r14d, r8d, 0x0B
00007ea2ca7cff66  xor eax, r14d
00007ea2ca7cff69  rorx r14d, r10d, 0x0D
00007ea2ca7cff6f  xor r11d, r14d
00007ea2ca7cff72  lea edi, [esi+ebp*1]
00007ea2ca7cff76  mov r14, [r15+0x48]
00007ea2ca7cff7a  mov ebp, [r13+r14*1]
00007ea2ca7cff7f  mov r14d, [rsp+0x30]
00007ea2ca7cff84  mov esi, [rsp+0x20]
00007ea2ca7cff88  and r14d, esi
00007ea2ca7cff8b  mov [rsp+0x20], r14d
00007ea2ca7cff90  mov r14d, r14d
00007ea2ca7cff93  mov [r15+0xD8], r14
00007ea2ca7cff9a  lea r14d, [edi+r9d*1]
00007ea2ca7cff9f  mov r9d, [rsp+0x30]
00007ea2ca7cffa4  xor r9d, esi
00007ea2ca7cffa7  rorx edi, r8d, 0x19
00007ea2ca7cffad  xor eax, edi
00007ea2ca7cffaf  and r9d, r10d
00007ea2ca7cffb2  rorx edi, r10d, 0x16
00007ea2ca7cffb8  xor r11d, edi
00007ea2ca7cffbb  mov [rsp+0x30], r11d
00007ea2ca7cffc0  mov r11d, r11d
00007ea2ca7cffc3  mov [r15+0xD0], r11
00007ea2ca7cffca  lea r11d, [r14d+ebp*1]
00007ea2ca7cffcf  mov r10d, [rsp+0x20]
00007ea2ca7cffd4  xor r9d, r10d
00007ea2ca7cffd7  lea r14d, [r11d+eax*1]
00007ea2ca7cffdc  mov qword ptr [r15+0x88], 0x04
00007ea2ca7cffe7  mov eax, [rsp+0x30]
00007ea2ca7cffeb  lea r11d, [r9d+eax*1]
00007ea2ca7cfff0  mov eax, [rsp+0x40]
00007ea2ca7cfff4  lea r10d, [r14d+eax*1]
00007ea2ca7cfff9  mov r10d, r10d
00007ea2ca7cfffc  mov [r15+0xB8], r10
00007ea2ca7d0003  xor eax, eax
00007ea2ca7d0005  mov r10d, 0x04
00007ea2ca7d000b  mov r9d, 0x100
00007ea2ca7d0011  cmp r10, r9
00007ea2ca7d0014  cmc
00007ea2ca7d0015  lahf
00007ea2ca7d0016  seto al
00007ea2ca7d0019  mov [r15+0x108], eax
00007ea2ca7d0020  lea eax, [r11d+r14d*1]
00007ea2ca7d0025  mov eax, eax
00007ea2ca7d0027  mov [r15+0xA8], rax
00007ea2ca7d002e  mov r12d, r12d
00007ea2ca7d0031  mov [r15+0xB0], r12
00007ea2ca7d0038  mov eax, [rsp+0x10]
00007ea2ca7d003c  mov eax, eax
00007ea2ca7d003e  mov [r15+0xC0], rax
00007ea2ca7d0045  mov r8d, r8d
00007ea2ca7d0048  mov [r15+0xC8], r8
00007ea2ca7d004f  mov eax, [r15+0x108]
00007ea2ca7d0056  sahf
00007ea2ca7d0057  jnz 0x00007EA2CA7D0089
00007ea2ca7d0059  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0061  jz 0x00007EA2CA7D0350
00007ea2ca7d0067  nop [rax+rax*1], ax
00007ea2ca7d0070  nop [rax+rax*1], eax
00007ea2ca7d0078  mov eax, 0x41055C
00007ea2ca7d007d  mov [r15+0x100], rax
00007ea2ca7d0084  jmp 0x00007EA2CA5FE110
00007ea2ca7d0089  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0091  jz 0x00007EA2CA7D0120
00007ea2ca7d0097  nop [rax+rax*1], ax
00007ea2ca7d00a0  nop [rax+rax*1], eax
00007ea2ca7d00a8  mov eax, 0x4104D0
00007ea2ca7d00ad  mov [r15+0x100], rax
00007ea2ca7d00b4  jmp 0x00007EA2CA5FE110
00007ea2ca7d00b9  int3
00007ea2ca7d00ba  call 0x00007EA2CA60DAE0
00007ea2ca7d00bf  jmp 0x00007EA2CA7CFE28
00007ea2ca7d00c4  call 0x00007EA2CA6C0230
00007ea2ca7d00c9  jmp 0x00007EA2CA7CFE31
00007ea2ca7d00ce  call 0x00007EA2CA6E26A0
00007ea2ca7d00d3  jmp 0x00007EA2CA7CFE55
00007ea2ca7d00d8  call 0x00007EA2CA6E1430
00007ea2ca7d00dd  jmp 0x00007EA2CA7CFE5E
00007ea2ca7d00e2  call 0x00007EA2CA6E26A0
00007ea2ca7d00e7  jmp 0x00007EA2CA7CFE7F
00007ea2ca7d00ec  call 0x00007EA2CA6E1430
00007ea2ca7d00f1  jmp 0x00007EA2CA7CFE88
00007ea2ca7d00f6  call 0x00007EA2CA6E26A0
00007ea2ca7d00fb  jmp 0x00007EA2CA7CFEA9
00007ea2ca7d0100  call 0x00007EA2CA6D5890
00007ea2ca7d0105  jmp 0x00007EA2CA7CFEB2
00007ea2ca7d010a  call 0x00007EA2CA6BDD50
00007ea2ca7d010f  jmp 0x00007EA2CA7CFF48
00007ea2ca7d0114  call 0x00007EA2CA6DA580
00007ea2ca7d0119  jmp 0x00007EA2CA7CFF7F
00007ea2ca7d011e  int3
00007ea2ca7d011f  nop
00007ea2ca7d0120  mov eax, [r15+0xB8]
00007ea2ca7d0127  mov [rsp+0x10], eax
00007ea2ca7d012b  mov eax, eax
00007ea2ca7d012d  mov [r15+0x30], rax
00007ea2ca7d0131  mov eax, [r15+0xC0]
00007ea2ca7d0138  mov [rsp+0x20], eax
00007ea2ca7d013c  mov eax, eax
00007ea2ca7d013e  mov [r15+0xA0], rax
00007ea2ca7d0145  mov eax, [r15+0x28]
00007ea2ca7d0149  mov r14d, [r15+0x98]
00007ea2ca7d0150  mov [rsp+0x30], r14d
00007ea2ca7d0155  mov r14d, r14d
00007ea2ca7d0158  mov [r15+0x28], r14
00007ea2ca7d015c  mov r14d, [r15+0x38]
00007ea2ca7d0160  mov [rsp+0x40], r14d
00007ea2ca7d0165  mov r14d, r14d
00007ea2ca7d0168  mov [r15+0x98], r14
00007ea2ca7d016f  mov r14d, [r15+0xA8]
00007ea2ca7d0176  mov [rsp+0x50], r14d
00007ea2ca7d017b  mov r14d, r14d
00007ea2ca7d017e  mov [r15+0x38], r14
00007ea2ca7d0182  mov r14d, [rsp+0x10]
00007ea2ca7d0187  mov r12d, [rsp+0x10]
00007ea2ca7d018c  shrd r14d, r12d, 0x06
00007ea2ca7d0191  mov r11d, [r15+0xC8]
00007ea2ca7d0198  mov [rsp+0x10], r12d
00007ea2ca7d019d  and r12d, r11d
00007ea2ca7d01a0  mov r10d, [rsp+0x50]
00007ea2ca7d01a5  mov r9d, [rsp+0x50]
00007ea2ca7d01aa  shrd r10d, r9d, 0x02
00007ea2ca7d01af  mov [rsp+0x50], r11d
00007ea2ca7d01b4  mov r11d, r11d
00007ea2ca7d01b7  mov [r15+0x20], r11
00007ea2ca7d01bb  mov r11, [r15+0x88]
00007ea2ca7d01c2  mov r8, [r15+0x50]
00007ea2ca7d01c6  lea rbp, [r8+r11*1]
00007ea2ca7d01ca  mov r8d, [r13+rbp*1]
00007ea2ca7d01cf  mov ebp, [rsp+0x20]
00007ea2ca7d01d3  mov edi, [rsp+0x10]
00007ea2ca7d01d7  andn esi, edi, ebp
00007ea2ca7d01dc  mov edx, [r15+0xB0]
00007ea2ca7d01e3  lea ecx, [r12d+edx*1]
00007ea2ca7d01e8  rorx r12d, edi, 0x0B
00007ea2ca7d01ee  xor r14d, r12d
00007ea2ca7d01f1  rorx r12d, r9d, 0x0D
00007ea2ca7d01f7  xor r10d, r12d
00007ea2ca7d01fa  lea r12d, [ecx+esi*1]
00007ea2ca7d01ff  mov rsi, [r15+0x48]
00007ea2ca7d0203  lea rdx, [rsi+r11*1]
00007ea2ca7d0207  mov esi, [r13+rdx*1]
00007ea2ca7d020c  mov edx, [rsp+0x30]
00007ea2ca7d0210  mov ecx, [rsp+0x40]
00007ea2ca7d0214  and edx, ecx
00007ea2ca7d0216  mov [rsp+0x10], edx
00007ea2ca7d021a  mov edx, edx
00007ea2ca7d021c  mov [r15+0xD8], rdx
00007ea2ca7d0223  lea edx, [r12d+r8d*1]
00007ea2ca7d0228  mov r12d, [rsp+0x30]
00007ea2ca7d022d  xor r12d, ecx
00007ea2ca7d0230  rorx r8d, edi, 0x19
00007ea2ca7d0236  xor r14d, r8d
00007ea2ca7d0239  and r12d, r9d
00007ea2ca7d023c  rorx r8d, r9d, 0x16
00007ea2ca7d0242  xor r10d, r8d
00007ea2ca7d0245  mov [rsp+0x20], r10d
00007ea2ca7d024a  mov r10d, r10d
00007ea2ca7d024d  mov [r15+0xD0], r10
00007ea2ca7d0254  lea r10d, [edx+esi*1]
00007ea2ca7d0259  mov r9d, [rsp+0x10]
00007ea2ca7d025e  xor r12d, r9d
00007ea2ca7d0261  lea r9d, [r10d+r14d*1]
00007ea2ca7d0266  lea r14, [r11+0x04]
00007ea2ca7d026a  mov [r15+0x88], r14
00007ea2ca7d0271  mov r11d, [rsp+0x20]
00007ea2ca7d0276  lea r10d, [r12d+r11d*1]
00007ea2ca7d027b  lea r11d, [r9d+eax*1]
00007ea2ca7d0280  mov r11d, r11d
00007ea2ca7d0283  mov [r15+0xB8], r11
00007ea2ca7d028a  xor eax, eax
00007ea2ca7d028c  mov r12d, 0x100
00007ea2ca7d0292  cmp r14, r12
00007ea2ca7d0295  cmc
00007ea2ca7d0296  lahf
00007ea2ca7d0297  seto al
00007ea2ca7d029a  mov [r15+0x108], eax
00007ea2ca7d02a1  lea eax, [r10d+r9d*1]
00007ea2ca7d02a6  mov eax, eax
00007ea2ca7d02a8  mov [r15+0xA8], rax
00007ea2ca7d02af  mov ebp, ebp
00007ea2ca7d02b1  mov [r15+0xB0], rbp
00007ea2ca7d02b8  mov eax, [rsp+0x50]
00007ea2ca7d02bc  mov eax, eax
00007ea2ca7d02be  mov [r15+0xC0], rax
00007ea2ca7d02c5  mov edi, edi
00007ea2ca7d02c7  mov [r15+0xC8], rdi
00007ea2ca7d02ce  mov eax, [r15+0x108]
00007ea2ca7d02d5  sahf
00007ea2ca7d02d6  jnz 0x00007EA2CA7D0308
00007ea2ca7d02d8  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d02e0  jz 0x00007EA2CA7D0350
00007ea2ca7d02e6  nop [rax+rax*1], ax
00007ea2ca7d02ef  nop [rax+rax*1], eax
00007ea2ca7d02f7  mov eax, 0x41055C
00007ea2ca7d02fc  mov [r15+0x100], rax
00007ea2ca7d0303  jmp 0x00007EA2CA5FE110
00007ea2ca7d0308  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0310  jz 0x00007EA2CA7D0120
00007ea2ca7d0316  nop [rax+rax*1], ax
00007ea2ca7d031f  nop [rax+rax*1], eax
00007ea2ca7d0327  mov eax, 0x4104D0
00007ea2ca7d032c  mov [r15+0x100], rax
00007ea2ca7d0333  jmp 0x00007EA2CA5FE110
00007ea2ca7d0338  int3
00007ea2ca7d0339  call 0x00007EA2CA649010
00007ea2ca7d033e  jmp 0x00007EA2CA7D01CF
00007ea2ca7d0343  call 0x00007EA2CA625930
00007ea2ca7d0348  jmp 0x00007EA2CA7D020C
00007ea2ca7d034d  int3
00007ea2ca7d034e  nop
00007ea2ca7d0350  mov eax, [r15+0x98]
00007ea2ca7d0357  mov r14d, [r15+0x70]
00007ea2ca7d035b  lea r12d, [eax+r14d*1]
00007ea2ca7d0360  mov eax, [r15+0x28]
00007ea2ca7d0364  mov r14d, [r15+0x68]
00007ea2ca7d0368  lea r11d, [eax+r14d*1]
00007ea2ca7d036d  mov qword ptr [r15+0x88], 0x00
00007ea2ca7d0378  mov eax, [r15+0xA8]
00007ea2ca7d037f  mov r14d, [r15+0x78]
00007ea2ca7d0383  lea r10d, [eax+r14d*1]
00007ea2ca7d0388  mov [rsp+0x10], r10d
00007ea2ca7d038d  mov r10d, r10d
00007ea2ca7d0390  mov [r15+0x78], r10
00007ea2ca7d0394  mov eax, [r15+0x38]
00007ea2ca7d0398  mov r14d, [r15+0x80]
00007ea2ca7d039f  lea r10d, [eax+r14d*1]
00007ea2ca7d03a4  mov [rsp+0x20], r10d
00007ea2ca7d03a9  mov r10d, r10d
00007ea2ca7d03ac  mov [r15+0x80], r10
00007ea2ca7d03b3  mov rax, [r15]
00007ea2ca7d03b6  lea r14, [rax+0x08]
00007ea2ca7d03ba  mov [r13+r14*1], r12d
00007ea2ca7d03bf  lea r14, [rax+0x0C]
00007ea2ca7d03c3  mov [r13+r14*1], r11d
00007ea2ca7d03c8  mov r14d, [r15+0xB8]
00007ea2ca7d03cf  mov r12d, [r15+0x18]
00007ea2ca7d03d3  lea r11d, [r14d+r12d*1]
00007ea2ca7d03d8  mov [rsp+0x30], r11d
00007ea2ca7d03dd  mov r11d, r11d
00007ea2ca7d03e0  mov [r15+0x68], r11
00007ea2ca7d03e4  mov r14d, [r15+0x30]
00007ea2ca7d03e8  mov r12d, [r15+0x90]
00007ea2ca7d03ef  lea r11d, [r14d+r12d*1]
00007ea2ca7d03f4  mov [rsp+0x40], r11d
00007ea2ca7d03f9  mov r11d, r11d
00007ea2ca7d03fc  mov [r15+0x70], r11
00007ea2ca7d0400  mov r14d, [r15+0x20]
00007ea2ca7d0404  mov r12d, [r15+0x58]
00007ea2ca7d0408  lea r11d, [r14d+r12d*1]
00007ea2ca7d040d  mov [rsp+0x50], r11d
00007ea2ca7d0412  mov r11d, r11d
00007ea2ca7d0415  mov [r15+0x58], r11
00007ea2ca7d0419  mov r14d, [r15+0xA0]
00007ea2ca7d0420  mov r12d, [r15+0x60]
00007ea2ca7d0424  lea r11d, [r14d+r12d*1]
00007ea2ca7d0429  mov [rsp+0x60], r11d
00007ea2ca7d042e  mov r11d, r11d
00007ea2ca7d0431  mov [r15+0x60], r11
00007ea2ca7d0435  mov r14d, [rsp+0x10]
00007ea2ca7d043a  mov [r13+rax*1], r14d
00007ea2ca7d043f  lea r14, [rax+0x04]
00007ea2ca7d0443  mov r12d, [rsp+0x20]
00007ea2ca7d0448  mov [r13+r14*1], r12d
00007ea2ca7d044d  lea r14, [rax+0x10]
00007ea2ca7d0451  mov r12d, [rsp+0x30]
00007ea2ca7d0456  mov [r13+r14*1], r12d
00007ea2ca7d045b  lea r14, [rax+0x14]
00007ea2ca7d045f  mov r12d, [rsp+0x40]
00007ea2ca7d0464  mov [r13+r14*1], r12d
00007ea2ca7d0469  lea r14, [rax+0x18]
00007ea2ca7d046d  mov r12d, [rsp+0x50]
00007ea2ca7d0472  mov [r13+r14*1], r12d
00007ea2ca7d0477  lea r14, [rax+0x1C]
00007ea2ca7d047b  mov r12d, [rsp+0x60]
00007ea2ca7d0480  mov [r13+r14*1], r12d
00007ea2ca7d0485  lea r14, [rax+0x68]
00007ea2ca7d0489  xor eax, eax
00007ea2ca7d048b  mov [r13+r14*1], rax
00007ea2ca7d0490  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0498  jz 0x00007EA2CA7CEF90
00007ea2ca7d049e  nop [rax+rax*1], ax
00007ea2ca7d04a7  nop [rax+rax*1], eax
00007ea2ca7d04af  mov eax, 0x410378
00007ea2ca7d04b4  mov [r15+0x100], rax
00007ea2ca7d04bb  jmp 0x00007EA2CA5FE110
00007ea2ca7d04c0  int3
00007ea2ca7d04c1  call 0x00007EA2CA6E2BA0
00007ea2ca7d04c6  jmp 0x00007EA2CA7D03BF
00007ea2ca7d04cb  call 0x00007EA2CA6E1920
00007ea2ca7d04d0  jmp 0x00007EA2CA7D03C8
00007ea2ca7d04d5  call 0x00007EA2CA60DFE0
00007ea2ca7d04da  jmp 0x00007EA2CA7D043F
00007ea2ca7d04df  call 0x00007EA2CA6E2BA0
00007ea2ca7d04e4  jmp 0x00007EA2CA7D044D
00007ea2ca7d04e9  call 0x00007EA2CA6E2BA0
00007ea2ca7d04ee  jmp 0x00007EA2CA7D045B
00007ea2ca7d04f3  call 0x00007EA2CA6E2BA0
00007ea2ca7d04f8  jmp 0x00007EA2CA7D0469
00007ea2ca7d04fd  call 0x00007EA2CA6E2BA0
00007ea2ca7d0502  jmp 0x00007EA2CA7D0477
00007ea2ca7d0507  call 0x00007EA2CA6E2BA0
00007ea2ca7d050c  jmp 0x00007EA2CA7D0485
00007ea2ca7d0511  call 0x00007EA2CA6D5EB0
00007ea2ca7d0516  jmp 0x00007EA2CA7D0490
00007ea2ca7d051b  int3
00007ea2ca7d051c  nop [rax], eax
00007ea2ca7d0520  mov rax, [r15+0xF8]
00007ea2ca7d0527  lea r14, [rax+0x140]
00007ea2ca7d052e  mov r12, [r13+r14*1]
00007ea2ca7d0533  lea r14, [rax+0x148]
00007ea2ca7d053a  mov r11, [r13+r14*1]
00007ea2ca7d053f  mov [r15+0xA0], r12
00007ea2ca7d0546  mov [r15+0x98], r11
00007ea2ca7d054d  lea r14, [rax+0x130]
00007ea2ca7d0554  mov r12, [r13+r14*1]
00007ea2ca7d0559  lea r14, [rax+0x138]
00007ea2ca7d0560  mov r11, [r13+r14*1]
00007ea2ca7d0565  mov [r15+0xB0], r12
00007ea2ca7d056c  mov [r15+0xA8], r11
00007ea2ca7d0573  lea r14, [rax+0x120]
00007ea2ca7d057a  mov r12, [r13+r14*1]
00007ea2ca7d057f  lea r14, [rax+0x128]
00007ea2ca7d0586  mov r11, [r13+r14*1]
00007ea2ca7d058b  mov [r15+0xC0], r12
00007ea2ca7d0592  mov [r15+0xB8], r11
00007ea2ca7d0599  lea r14, [rax+0x110]
00007ea2ca7d05a0  mov r12, [r13+r14*1]
00007ea2ca7d05a5  lea r14, [rax+0x118]
00007ea2ca7d05ac  mov r11, [r13+r14*1]
00007ea2ca7d05b1  mov [r15+0xD0], r12
00007ea2ca7d05b8  mov [r15+0xC8], r11
00007ea2ca7d05bf  lea r14, [rax+0x100]
00007ea2ca7d05c6  mov r12, [r13+r14*1]
00007ea2ca7d05cb  lea r14, [rax+0x108]
00007ea2ca7d05d2  mov r11, [r13+r14*1]
00007ea2ca7d05d7  mov [r15+0xE8], r12
00007ea2ca7d05de  mov [r15+0xD8], r11
00007ea2ca7d05e5  lea r14, [rax+0x150]
00007ea2ca7d05ec  mov [r15+0xF8], r14
00007ea2ca7d05f3  mov rax, [r15+0xF0]
00007ea2ca7d05fa  mov [r15+0x100], rax
00007ea2ca7d0601  jmp 0x00007EA2CA7CE5C0
00007ea2ca7d0606  int3
00007ea2ca7d0607  call 0x00007EA2CA6E27E0
00007ea2ca7d060c  jmp 0x00007EA2CA7D0533
00007ea2ca7d0611  call 0x00007EA2CA6E1570
00007ea2ca7d0616  jmp 0x00007EA2CA7D053F
00007ea2ca7d061b  call 0x00007EA2CA6E27E0
00007ea2ca7d0620  jmp 0x00007EA2CA7D0559
00007ea2ca7d0625  call 0x00007EA2CA6E1570
00007ea2ca7d062a  jmp 0x00007EA2CA7D0565
00007ea2ca7d062f  call 0x00007EA2CA6E27E0
00007ea2ca7d0634  jmp 0x00007EA2CA7D057F
00007ea2ca7d0639  call 0x00007EA2CA6E1570
00007ea2ca7d063e  jmp 0x00007EA2CA7D058B
00007ea2ca7d0643  call 0x00007EA2CA6E27E0
00007ea2ca7d0648  jmp 0x00007EA2CA7D05A5
00007ea2ca7d064d  call 0x00007EA2CA6E1570
00007ea2ca7d0652  jmp 0x00007EA2CA7D05B1
00007ea2ca7d0657  call 0x00007EA2CA6E27E0
00007ea2ca7d065c  jmp 0x00007EA2CA7D05CB
00007ea2ca7d0661  call 0x00007EA2CA6E1570
00007ea2ca7d0666  jmp 0x00007EA2CA7D05D7
00007ea2ca7d066b  int3
00007ea2ca7d066c  nop [rax], eax
00007ea2ca7d0670  mov eax, [r15+0xA0]
00007ea2ca7d0677  mov [rsp+0x10], eax
00007ea2ca7d067b  xor eax, eax
00007ea2ca7d067d  mov r14d, [rsp+0x10]
00007ea2ca7d0682  sub r14d, 0x01
00007ea2ca7d0686  cmc
00007ea2ca7d0687  lahf
00007ea2ca7d0688  seto al
00007ea2ca7d068b  mov [r15+0x108], eax
00007ea2ca7d0692  mov r14d, r14d
00007ea2ca7d0695  mov [r15+0xA0], r14
00007ea2ca7d069c  mov eax, [r15+0x108]
00007ea2ca7d06a3  sahf
00007ea2ca7d06a4  jnz 0x00007EA2CA7D06D6
00007ea2ca7d06a6  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d06ae  jz 0x00007EA2CA7D07A0
00007ea2ca7d06b4  nop [rax+rax*1], ax
00007ea2ca7d06bd  nop [rax+rax*1], eax
00007ea2ca7d06c5  mov eax, 0x41027C
00007ea2ca7d06ca  mov [r15+0x100], rax
00007ea2ca7d06d1  jmp 0x00007EA2CA5FE110
00007ea2ca7d06d6  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d06de  jz 0x00007EA2CA7D0710
00007ea2ca7d06e4  nop [rax+rax*1], ax
00007ea2ca7d06ed  nop [rax+rax*1], eax
00007ea2ca7d06f5  mov eax, 0x410264
00007ea2ca7d06fa  mov [r15+0x100], rax
00007ea2ca7d0701  jmp 0x00007EA2CA5FE110
00007ea2ca7d0706  int3
00007ea2ca7d0707  int3
00007ea2ca7d0708  nop [rax+rax*1], eax
00007ea2ca7d0710  mov rax, [r15+0xF8]
00007ea2ca7d0717  mov [r15], rax
00007ea2ca7d071a  mov rax, [r15+0x98]
00007ea2ca7d0721  mov [r15+0x08], rax
00007ea2ca7d0725  mov qword ptr [r15+0x10], 0x12C
00007ea2ca7d072d  mov qword ptr [r15+0xF0], 0x410274
00007ea2ca7d0738  mov r14d, [r15+0x320]
00007ea2ca7d073f  mov eax, 0x410274
00007ea2ca7d0744  mov rcx, 0x7EA2CA7D0670
00007ea2ca7d074e  mov [r15+r14*8+0x328], rax
00007ea2ca7d0756  mov [r15+r14*8+0x368], rcx
00007ea2ca7d075e  add r14d, 0x01
00007ea2ca7d0762  and r14d, 0x07
00007ea2ca7d0766  mov [r15+0x320], r14d
00007ea2ca7d076d  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0775  jz 0x00007EA2CA7CEC20
00007ea2ca7d077b  nop [rax+rax*1], ax
00007ea2ca7d0784  nop [rax+rax*1], eax
00007ea2ca7d078c  mov eax, 0x410338
00007ea2ca7d0791  mov [r15+0x100], rax
00007ea2ca7d0798  jmp 0x00007EA2CA5FE110
00007ea2ca7d079d  int3
00007ea2ca7d079e  int3
00007ea2ca7d079f  nop
00007ea2ca7d07a0  mov rax, [r15+0xF8]
00007ea2ca7d07a7  lea r14, [rax+0x20]
00007ea2ca7d07ab  mov r12, [r13+r14*1]
00007ea2ca7d07b0  mov [r15+0x98], r12
00007ea2ca7d07b7  mov qword ptr [r15+0x40], 0x80
00007ea2ca7d07bf  mov [r15], rax
00007ea2ca7d07c2  lea r14, [rax+0x8C]
00007ea2ca7d07c9  mov [r15+0x08], r14
00007ea2ca7d07cd  mov qword ptr [r15+0x10], 0x01
00007ea2ca7d07d5  lea r14, [rax+0x8C]
00007ea2ca7d07dc  mov eax, 0x80
00007ea2ca7d07e1  mov [r13+r14*1], al
00007ea2ca7d07e6  mov qword ptr [r15+0xF0], 0x410298
00007ea2ca7d07f1  mov r14d, [r15+0x320]
00007ea2ca7d07f8  mov eax, 0x410298
00007ea2ca7d07fd  mov rcx, 0x7EA2CA7D0870
00007ea2ca7d0807  mov [r15+r14*8+0x328], rax
00007ea2ca7d080f  mov [r15+r14*8+0x368], rcx
00007ea2ca7d0817  add r14d, 0x01
00007ea2ca7d081b  and r14d, 0x07
00007ea2ca7d081f  mov [r15+0x320], r14d
00007ea2ca7d0826  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d082e  jz 0x00007EA2CA7CEC20
00007ea2ca7d0834  nop [rax+rax*1], ax
00007ea2ca7d083d  nop [rax+rax*1], eax
00007ea2ca7d0845  mov eax, 0x410338
00007ea2ca7d084a  mov [r15+0x100], rax
00007ea2ca7d0851  jmp 0x00007EA2CA5FE110
00007ea2ca7d0856  int3
00007ea2ca7d0857  call 0x00007EA2CA6E27E0
00007ea2ca7d085c  jmp 0x00007EA2CA7D07B0
00007ea2ca7d0861  call 0x00007EA2CA6D5AF0
00007ea2ca7d0866  jmp 0x00007EA2CA7D07E6
00007ea2ca7d086b  int3
00007ea2ca7d086c  nop [rax], eax
00007ea2ca7d0870  mov rax, [r15+0xF8]
00007ea2ca7d0877  lea r14, [rax+0x68]
00007ea2ca7d087b  mov r12, [r13+r14*1]
00007ea2ca7d0880  mov [r15+0x40], r12
00007ea2ca7d0884  lea r14, [rax+0x88]
00007ea2ca7d088b  xor eax, eax
00007ea2ca7d088d  mov [r13+r14*1], al
00007ea2ca7d0892  xor eax, eax
00007ea2ca7d0894  mov r14d, 0x38
00007ea2ca7d089a  cmp r12, r14
00007ea2ca7d089d  cmc
00007ea2ca7d089e  lahf
00007ea2ca7d089f  seto al
00007ea2ca7d08a2  mov [r15+0x108], eax
00007ea2ca7d08a9  mov eax, [r15+0x108]
00007ea2ca7d08b0  sahf
00007ea2ca7d08b1  jz 0x00007EA2CA7D08E3
00007ea2ca7d08b3  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d08bb  jz 0x00007EA2CA7D0930
00007ea2ca7d08c1  nop [rax+rax*1], ax
00007ea2ca7d08ca  nop [rax+rax*1], eax
00007ea2ca7d08d2  mov eax, 0x4102A8
00007ea2ca7d08d7  mov [r15+0x100], rax
00007ea2ca7d08de  jmp 0x00007EA2CA5FE110
00007ea2ca7d08e3  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d08eb  jz 0x00007EA2CA7D0A70
00007ea2ca7d08f1  nop [rax+rax*1], ax
00007ea2ca7d08fa  nop [rax+rax*1], eax
00007ea2ca7d0902  mov eax, 0x4102C4
00007ea2ca7d0907  mov [r15+0x100], rax
00007ea2ca7d090e  jmp 0x00007EA2CA5FE110
00007ea2ca7d0913  int3
00007ea2ca7d0914  call 0x00007EA2CA6E27E0
00007ea2ca7d0919  jmp 0x00007EA2CA7D0880
00007ea2ca7d091e  call 0x00007EA2CA6D5AF0
00007ea2ca7d0923  jmp 0x00007EA2CA7D0892
00007ea2ca7d0928  int3
00007ea2ca7d0929  nop [rax], eax
00007ea2ca7d0930  mov rax, [r15+0xF8]
00007ea2ca7d0937  mov [r15], rax
00007ea2ca7d093a  lea r14, [rax+0x88]
00007ea2ca7d0941  mov [r15+0x08], r14
00007ea2ca7d0945  mov qword ptr [r15+0x10], 0x01
00007ea2ca7d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007ea2ca7d0958  mov r14d, [r15+0x320]
00007ea2ca7d095f  mov eax, 0x4102B8
00007ea2ca7d0964  mov rcx, 0x7EA2CA7D09C0
00007ea2ca7d096e  mov [r15+r14*8+0x328], rax
00007ea2ca7d0976  mov [r15+r14*8+0x368], rcx
00007ea2ca7d097e  add r14d, 0x01
00007ea2ca7d0982  and r14d, 0x07
00007ea2ca7d0986  mov [r15+0x320], r14d
00007ea2ca7d098d  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0995  jz 0x00007EA2CA7CEC20
00007ea2ca7d099b  nop [rax+rax*1], ax
00007ea2ca7d09a4  nop [rax+rax*1], eax
00007ea2ca7d09ac  mov eax, 0x410338
00007ea2ca7d09b1  mov [r15+0x100], rax
00007ea2ca7d09b8  jmp 0x00007EA2CA5FE110
00007ea2ca7d09bd  int3
00007ea2ca7d09be  int3
00007ea2ca7d09bf  nop
00007ea2ca7d09c0  mov rax, [r15+0xF8]
00007ea2ca7d09c7  lea r14, [rax+0x68]
00007ea2ca7d09cb  mov rax, [r13+r14*1]
00007ea2ca7d09d0  mov [r15+0x40], rax
00007ea2ca7d09d4  mov [rsp+0x10], rax
00007ea2ca7d09d9  xor eax, eax
00007ea2ca7d09db  mov r14, [rsp+0x10]
00007ea2ca7d09e0  mov r12d, 0x38
00007ea2ca7d09e6  cmp r14, r12
00007ea2ca7d09e9  cmc
00007ea2ca7d09ea  lahf
00007ea2ca7d09eb  seto al
00007ea2ca7d09ee  mov [r15+0x108], eax
00007ea2ca7d09f5  mov eax, [r15+0x108]
00007ea2ca7d09fc  sahf
00007ea2ca7d09fd  jnz 0x00007EA2CA7D0A2F
00007ea2ca7d09ff  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0a07  jz 0x00007EA2CA7D0A70
00007ea2ca7d0a0d  nop [rax+rax*1], ax
00007ea2ca7d0a16  nop [rax+rax*1], eax
00007ea2ca7d0a1e  mov eax, 0x4102C4
00007ea2ca7d0a23  mov [r15+0x100], rax
00007ea2ca7d0a2a  jmp 0x00007EA2CA5FE110
00007ea2ca7d0a2f  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0a37  jz 0x00007EA2CA7D0930
00007ea2ca7d0a3d  nop [rax+rax*1], ax
00007ea2ca7d0a46  nop [rax+rax*1], eax
00007ea2ca7d0a4e  mov eax, 0x4102A8
00007ea2ca7d0a53  mov [r15+0x100], rax
00007ea2ca7d0a5a  jmp 0x00007EA2CA5FE110
00007ea2ca7d0a5f  int3
00007ea2ca7d0a60  call 0x00007EA2CA6D59C0
00007ea2ca7d0a65  jmp 0x00007EA2CA7D09D0
00007ea2ca7d0a6a  int3
00007ea2ca7d0a6b  nop [rax+rax*1], eax
00007ea2ca7d0a70  mov rax, [r15+0x98]
00007ea2ca7d0a77  rorx r14, rax, 0x3D
00007ea2ca7d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007ea2ca7d0a81  mov rax, [r15+0xF8]
00007ea2ca7d0a88  mov [r15], rax
00007ea2ca7d0a8b  lea r12, [rax+0x78]
00007ea2ca7d0a8f  mov [r15+0x08], r12
00007ea2ca7d0a93  mov qword ptr [r15+0x10], 0x08
00007ea2ca7d0a9b  bswap r14
00007ea2ca7d0a9e  mov [r15+0x40], r14
00007ea2ca7d0aa2  lea r12, [rax+0x78]
00007ea2ca7d0aa6  mov [r13+r12*1], r14
00007ea2ca7d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007ea2ca7d0ab6  mov r14d, [r15+0x320]
00007ea2ca7d0abd  mov eax, 0x4102E0
00007ea2ca7d0ac2  mov rcx, 0x7EA2CA7D0B30
00007ea2ca7d0acc  mov [r15+r14*8+0x328], rax
00007ea2ca7d0ad4  mov [r15+r14*8+0x368], rcx
00007ea2ca7d0adc  add r14d, 0x01
00007ea2ca7d0ae0  and r14d, 0x07
00007ea2ca7d0ae4  mov [r15+0x320], r14d
00007ea2ca7d0aeb  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0af3  jz 0x00007EA2CA7CEC20
00007ea2ca7d0af9  nop [rax+rax*1], ax
00007ea2ca7d0b02  nop [rax+rax*1], eax
00007ea2ca7d0b0a  mov eax, 0x410338
00007ea2ca7d0b0f  mov [r15+0x100], rax
00007ea2ca7d0b16  jmp 0x00007EA2CA5FE110
00007ea2ca7d0b1b  int3
00007ea2ca7d0b1c  call 0x00007EA2CA6C3FE0
00007ea2ca7d0b21  jmp 0x00007EA2CA7D0AAB
00007ea2ca7d0b26  int3
00007ea2ca7d0b27  nop [rax+rax*1], ax
00007ea2ca7d0b30  mov rax, [r15+0xF8]
00007ea2ca7d0b37  mov r14d, [r13+rax*1]
00007ea2ca7d0b3c  lea r12, [rax+0x04]
00007ea2ca7d0b40  mov r11d, [r13+r12*1]
00007ea2ca7d0b45  lea r12, [rax+0x08]
00007ea2ca7d0b49  mov r10d, [r13+r12*1]
00007ea2ca7d0b4e  lea r12, [rax+0x0C]
00007ea2ca7d0b52  mov r9d, [r13+r12*1]
00007ea2ca7d0b57  mov qword ptr [r15+0x48], 0x430860
00007ea2ca7d0b5f  lea r12, [rax+0x80]
00007ea2ca7d0b66  mov r8, [r13+r12*1]
00007ea2ca7d0b6b  mov [r15+0xF0], r8
00007ea2ca7d0b72  bswap r14d
00007ea2ca7d0b75  bswap r11d
00007ea2ca7d0b78  mov r12d, 0x430860
00007ea2ca7d0b7e  mov [r13+r12*1], r14d
00007ea2ca7d0b83  mov r14d, 0x430864
00007ea2ca7d0b89  mov [r13+r14*1], r11d
00007ea2ca7d0b8e  bswap r10d
00007ea2ca7d0b91  bswap r9d
00007ea2ca7d0b94  lea r14, [rax+0x10]
00007ea2ca7d0b98  mov r12d, [r13+r14*1]
00007ea2ca7d0b9d  lea r14, [rax+0x14]
00007ea2ca7d0ba1  mov r11d, [r13+r14*1]
00007ea2ca7d0ba6  mov r14d, 0x430868
00007ea2ca7d0bac  mov [r13+r14*1], r10d
00007ea2ca7d0bb1  mov r14d, 0x43086C
00007ea2ca7d0bb7  mov [r13+r14*1], r9d
00007ea2ca7d0bbc  lea r14, [rax+0x90]
00007ea2ca7d0bc3  mov r10, [r13+r14*1]
00007ea2ca7d0bc8  lea r14, [rax+0x98]
00007ea2ca7d0bcf  mov r9, [r13+r14*1]
00007ea2ca7d0bd4  mov [r15+0xA0], r10
00007ea2ca7d0bdb  mov [r15+0x98], r9
00007ea2ca7d0be2  bswap r12d
00007ea2ca7d0be5  bswap r11d
00007ea2ca7d0be8  mov [rsp+0x10], r11d
00007ea2ca7d0bed  mov r11d, r11d
00007ea2ca7d0bf0  mov [r15+0x58], r11
00007ea2ca7d0bf4  lea r14, [rax+0x18]
00007ea2ca7d0bf8  mov r11d, [r13+r14*1]
00007ea2ca7d0bfd  lea r14, [rax+0x1C]
00007ea2ca7d0c01  mov r10d, [r13+r14*1]
00007ea2ca7d0c06  mov [rsp+0x20], r10d
00007ea2ca7d0c0b  mov r10d, r10d
00007ea2ca7d0c0e  mov [r15+0x60], r10
00007ea2ca7d0c12  mov r14d, 0x430870
00007ea2ca7d0c18  mov [r13+r14*1], r12d
00007ea2ca7d0c1d  mov r14d, 0x430874
00007ea2ca7d0c23  mov r12d, [rsp+0x10]
00007ea2ca7d0c28  mov [r13+r14*1], r12d
00007ea2ca7d0c2d  bswap r11d
00007ea2ca7d0c30  mov [rsp+0x10], r11d
00007ea2ca7d0c35  mov r11d, r11d
00007ea2ca7d0c38  mov [r15+0x40], r11
00007ea2ca7d0c3c  mov r14d, [rsp+0x20]
00007ea2ca7d0c41  bswap r14d
00007ea2ca7d0c44  mov [rsp+0x20], r14d
00007ea2ca7d0c49  mov r14d, r14d
00007ea2ca7d0c4c  mov [r15+0x50], r14
00007ea2ca7d0c50  mov r14d, 0x430878
00007ea2ca7d0c56  mov r12d, [rsp+0x10]
00007ea2ca7d0c5b  mov [r13+r14*1], r12d
00007ea2ca7d0c60  mov r14d, 0x43087C
00007ea2ca7d0c66  mov r12d, [rsp+0x20]
00007ea2ca7d0c6b  mov [r13+r14*1], r12d
00007ea2ca7d0c70  lea r14, [rax+0xA0]
00007ea2ca7d0c77  mov [r15+0xF8], r14
00007ea2ca7d0c7e  mov [r15+0x100], r8
00007ea2ca7d0c85  jmp 0x00007EA2CA7CE5C0
00007ea2ca7d0c8a  int3
00007ea2ca7d0c8b  call 0x00007EA2CA60DAE0
00007ea2ca7d0c90  jmp 0x00007EA2CA7D0B3C
00007ea2ca7d0c95  call 0x00007EA2CA6C0230
00007ea2ca7d0c9a  jmp 0x00007EA2CA7D0B45
00007ea2ca7d0c9f  call 0x00007EA2CA6BEFC0
00007ea2ca7d0ca4  jmp 0x00007EA2CA7D0B4E
00007ea2ca7d0ca9  call 0x00007EA2CA6BDD50
00007ea2ca7d0cae  jmp 0x00007EA2CA7D0B57
00007ea2ca7d0cb3  call 0x00007EA2CA6BCC20
00007ea2ca7d0cb8  jmp 0x00007EA2CA7D0B6B
00007ea2ca7d0cbd  call 0x00007EA2CA6C3EA0
00007ea2ca7d0cc2  jmp 0x00007EA2CA7D0B83
00007ea2ca7d0cc7  call 0x00007EA2CA6E1920
00007ea2ca7d0ccc  jmp 0x00007EA2CA7D0B8E
00007ea2ca7d0cd1  call 0x00007EA2CA6E26A0
00007ea2ca7d0cd6  jmp 0x00007EA2CA7D0B9D
00007ea2ca7d0cdb  call 0x00007EA2CA6E1430
00007ea2ca7d0ce0  jmp 0x00007EA2CA7D0BA6
00007ea2ca7d0ce5  call 0x00007EA2CA6E06B0
00007ea2ca7d0cea  jmp 0x00007EA2CA7D0BB1
00007ea2ca7d0cef  call 0x00007EA2CA6DF440
00007ea2ca7d0cf4  jmp 0x00007EA2CA7D0BBC
00007ea2ca7d0cf9  call 0x00007EA2CA6E0300
00007ea2ca7d0cfe  jmp 0x00007EA2CA7D0BC8
00007ea2ca7d0d03  call 0x00007EA2CA6DF090
00007ea2ca7d0d08  jmp 0x00007EA2CA7D0BD4
00007ea2ca7d0d0d  call 0x00007EA2CA6E1430
00007ea2ca7d0d12  jmp 0x00007EA2CA7D0BFD
00007ea2ca7d0d17  call 0x00007EA2CA6E01C0
00007ea2ca7d0d1c  jmp 0x00007EA2CA7D0C06
00007ea2ca7d0d21  call 0x00007EA2CA6E2BA0
00007ea2ca7d0d26  jmp 0x00007EA2CA7D0C1D
00007ea2ca7d0d2b  call 0x00007EA2CA6E2BA0
00007ea2ca7d0d30  jmp 0x00007EA2CA7D0C2D
00007ea2ca7d0d35  call 0x00007EA2CA6E2BA0
00007ea2ca7d0d3a  jmp 0x00007EA2CA7D0C60
00007ea2ca7d0d3f  call 0x00007EA2CA6E2BA0
00007ea2ca7d0d44  jmp 0x00007EA2CA7D0C70
00007ea2ca7d0d49  int3
00007ea2ca7d0d4a  nop [rax+rax*1], ax
00007ea2ca7d0d50  mov qword ptr [r15+0x100], 0x04
00007ea2ca7d0d5b  mov esi, 0x00
00007ea2ca7d0d60  mov edx, 0x09
00007ea2ca7d0d65  mov rdi, 0x7FFFA998F120
00007ea2ca7d0d6f  mov rax, 0x55731276F970
00007ea2ca7d0d79  call rax
00007ea2ca7d0d7b  cmp dword ptr [r15+0x318], 0x00
00007ea2ca7d0d83  jnz 0x00007EA2CA5FE110
00007ea2ca7d0d89  jmp 0x00007EA2CA5FE0A0
00007ea2ca7d0d8e  int3
00007ea2ca7d0d8f  int3
