0000755de29ce69b  nop [rax+rax*1], eax
0000755de29ce6a0  mov qword ptr [r15+0x08], 0xB71B00
0000755de29ce6a8  mov qword ptr [r15+0x20], 0x420090
0000755de29ce6b0  mov qword ptr [r15+0x10], 0x00
0000755de29ce6b8  mov qword ptr [r15], 0x01
0000755de29ce6bf  xor eax, eax
0000755de29ce6c1  mov r14d, 0x01
0000755de29ce6c7  mov r12d, 0x07
0000755de29ce6cd  cmp r14, r12
0000755de29ce6d0  cmc
0000755de29ce6d1  lahf
0000755de29ce6d2  seto al
0000755de29ce6d5  mov [r15+0x108], eax
0000755de29ce6dc  mov eax, [r15+0x108]
0000755de29ce6e3  sahf
0000755de29ce6e4  cmc
0000755de29ce6e5  jnbe 0x0000755DE29CE717
0000755de29ce6e7  cmp dword ptr [r15+0x318], 0x00
0000755de29ce6ef  jz 0x0000755DE29CE750
0000755de29ce6f5  nop [rax+rax*1], ax
0000755de29ce6fe  nop [rax+rax*1], eax
0000755de29ce706  mov eax, 0x41004C
0000755de29ce70b  mov [r15+0x100], rax
0000755de29ce712  jmp 0x0000755DE27FE110
0000755de29ce717  cmp dword ptr [r15+0x318], 0x00
0000755de29ce71f  jz 0x0000755DE29CEC10
0000755de29ce725  nop [rax+rax*1], ax
0000755de29ce72e  nop [rax+rax*1], eax
0000755de29ce736  mov eax, 0x410050
0000755de29ce73b  mov [r15+0x100], rax
0000755de29ce742  jmp 0x0000755DE27FE110
0000755de29ce747  int3
0000755de29ce748  int3
0000755de29ce749  nop [rax], eax
0000755de29ce750  mov rax, [r15+0x10]
0000755de29ce754  lea r14, [rax+0x03]
0000755de29ce758  mov [r15+0x10], r14
0000755de29ce75c  mov rax, [r15]
0000755de29ce75f  mov [rsp+0x10], rax
0000755de29ce764  xor eax, eax
0000755de29ce766  mov r14, [rsp+0x10]
0000755de29ce76b  mov r12d, 0x05
0000755de29ce771  cmp r14, r12
0000755de29ce774  cmc
0000755de29ce775  lahf
0000755de29ce776  seto al
0000755de29ce779  mov [r15+0x108], eax
0000755de29ce780  mov eax, [r15+0x108]
0000755de29ce787  cmp al, 0x81
0000755de29ce789  sahf
0000755de29ce78a  jl 0x0000755DE29CE7BC
0000755de29ce78c  cmp dword ptr [r15+0x318], 0x00
0000755de29ce794  jz 0x0000755DE29CEB70
0000755de29ce79a  nop [rax+rax*1], ax
0000755de29ce7a3  nop [rax+rax*1], eax
0000755de29ce7ab  mov eax, 0x410058
0000755de29ce7b0  mov [r15+0x100], rax
0000755de29ce7b7  jmp 0x0000755DE27FE110
0000755de29ce7bc  cmp dword ptr [r15+0x318], 0x00
0000755de29ce7c4  jz 0x0000755DE29CE7F0
0000755de29ce7ca  nop [rax+rax*1], ax
0000755de29ce7d3  nop [rax+rax*1], eax
0000755de29ce7db  mov eax, 0x41005C
0000755de29ce7e0  mov [r15+0x100], rax
0000755de29ce7e7  jmp 0x0000755DE27FE110
0000755de29ce7ec  int3
0000755de29ce7ed  int3
0000755de29ce7ee  nop
0000755de29ce7f0  mov rax, [r15]
0000755de29ce7f3  and rax, 0x01
0000755de29ce7f7  mov [r15+0x18], rax
0000755de29ce7fb  test rax, rax
0000755de29ce7fe  setz al
0000755de29ce801  movzx rax, al
0000755de29ce805  mov [rsp+0x414], al
0000755de29ce80c  cmp byte ptr [rsp+0x414], 0x00
0000755de29ce814  jz 0x0000755DE29CE846
0000755de29ce816  cmp dword ptr [r15+0x318], 0x00
0000755de29ce81e  jz 0x0000755DE29CEA50
0000755de29ce824  nop [rax+rax*1], ax
0000755de29ce82d  nop [rax+rax*1], eax
0000755de29ce835  mov eax, 0x410068
0000755de29ce83a  mov [r15+0x100], rax
0000755de29ce841  jmp 0x0000755DE27FE110
0000755de29ce846  cmp dword ptr [r15+0x318], 0x00
0000755de29ce84e  jz 0x0000755DE29CE880
0000755de29ce854  nop [rax+rax*1], ax
0000755de29ce85d  nop [rax+rax*1], eax
0000755de29ce865  mov eax, 0x410064
0000755de29ce86a  mov [r15+0x100], rax
0000755de29ce871  jmp 0x0000755DE27FE110
0000755de29ce876  int3
0000755de29ce877  int3
0000755de29ce878  nop [rax+rax*1], eax
0000755de29ce880  mov rax, [r15+0x10]
0000755de29ce884  lea r14, [rax+0x07]
0000755de29ce888  mov [r15+0x10], r14
0000755de29ce88c  mov eax, [r15]
0000755de29ce88f  mov eax, eax
0000755de29ce891  bt rax, 0x01
0000755de29ce896  setb al
0000755de29ce899  mov [rsp+0x414], al
0000755de29ce8a0  cmp byte ptr [rsp+0x414], 0x00
0000755de29ce8a8  jz 0x0000755DE29CE8DA
0000755de29ce8aa  cmp dword ptr [r15+0x318], 0x00
0000755de29ce8b2  jz 0x0000755DE29CEAD0
0000755de29ce8b8  nop [rax+rax*1], ax
0000755de29ce8c1  nop [rax+rax*1], eax
0000755de29ce8c9  mov eax, 0x410070
0000755de29ce8ce  mov [r15+0x100], rax
0000755de29ce8d5  jmp 0x0000755DE27FE110
0000755de29ce8da  cmp dword ptr [r15+0x318], 0x00
0000755de29ce8e2  jz 0x0000755DE29CE910
0000755de29ce8e8  nop [rax+rax*1], ax
0000755de29ce8f1  nop [rax+rax*1], eax
0000755de29ce8f9  mov eax, 0x41006C
0000755de29ce8fe  mov [r15+0x100], rax
0000755de29ce905  jmp 0x0000755DE27FE110
0000755de29ce90a  int3
0000755de29ce90b  int3
0000755de29ce90c  nop [rax], eax
0000755de29ce910  mov rax, [r15+0x10]
0000755de29ce914  lea r14, [rax+0x0B]
0000755de29ce918  mov [r15+0x10], r14
0000755de29ce91c  mov rax, [r15+0x08]
0000755de29ce920  mov [rsp+0x10], rax
0000755de29ce925  xor eax, eax
0000755de29ce927  mov r14, [rsp+0x10]
0000755de29ce92c  mov r12d, 0x01
0000755de29ce932  sub r14, r12
0000755de29ce935  cmc
0000755de29ce936  lahf
0000755de29ce937  seto al
0000755de29ce93a  mov [r15+0x108], eax
0000755de29ce941  mov [r15+0x08], r14
0000755de29ce945  mov eax, [r15+0x108]
0000755de29ce94c  sahf
0000755de29ce94d  jnz 0x0000755DE29CE97F
0000755de29ce94f  cmp dword ptr [r15+0x318], 0x00
0000755de29ce957  jz 0x0000755DE29CECB0
0000755de29ce95d  nop [rax+rax*1], ax
0000755de29ce966  nop [rax+rax*1], eax
0000755de29ce96e  mov eax, 0x410078
0000755de29ce973  mov [r15+0x100], rax
0000755de29ce97a  jmp 0x0000755DE27FE110
0000755de29ce97f  cmp dword ptr [r15+0x318], 0x00
0000755de29ce987  jz 0x0000755DE29CE9C0
0000755de29ce98d  nop [rax+rax*1], ax
0000755de29ce996  nop [rax+rax*1], eax
0000755de29ce99e  mov eax, 0x410040
0000755de29ce9a3  mov [r15+0x100], rax
0000755de29ce9aa  jmp 0x0000755DE27FE110
0000755de29ce9af  int3
0000755de29ce9b0  int3
0000755de29ce9b1  nop [rax+rax*1], ax
0000755de29ce9ba  nop [rax+rax*1], ax
0000755de29ce9c0  mov rax, [r15]
0000755de29ce9c3  lea r14, [rax+0x01]
0000755de29ce9c7  mov [r15], r14
0000755de29ce9ca  xor eax, eax
0000755de29ce9cc  mov r12d, 0x07
0000755de29ce9d2  cmp r14, r12
0000755de29ce9d5  cmc
0000755de29ce9d6  lahf
0000755de29ce9d7  seto al
0000755de29ce9da  mov [r15+0x108], eax
0000755de29ce9e1  mov eax, [r15+0x108]
0000755de29ce9e8  sahf
0000755de29ce9e9  cmc
0000755de29ce9ea  jnbe 0x0000755DE29CEA1C
0000755de29ce9ec  cmp dword ptr [r15+0x318], 0x00
0000755de29ce9f4  jz 0x0000755DE29CE750
0000755de29ce9fa  nop [rax+rax*1], ax
0000755de29cea03  nop [rax+rax*1], eax
0000755de29cea0b  mov eax, 0x41004C
0000755de29cea10  mov [r15+0x100], rax
0000755de29cea17  jmp 0x0000755DE27FE110
0000755de29cea1c  cmp dword ptr [r15+0x318], 0x00
0000755de29cea24  jz 0x0000755DE29CEC10
0000755de29cea2a  nop [rax+rax*1], ax
0000755de29cea33  nop [rax+rax*1], eax
0000755de29cea3b  mov eax, 0x410050
0000755de29cea40  mov [r15+0x100], rax
0000755de29cea47  jmp 0x0000755DE27FE110
0000755de29cea4c  int3
0000755de29cea4d  int3
0000755de29cea4e  nop
0000755de29cea50  mov eax, [r15]
0000755de29cea53  mov eax, eax
0000755de29cea55  bt rax, 0x01
0000755de29cea5a  setb al
0000755de29cea5d  mov [rsp+0x414], al
0000755de29cea64  cmp byte ptr [rsp+0x414], 0x00
0000755de29cea6c  jz 0x0000755DE29CEA9E
0000755de29cea6e  cmp dword ptr [r15+0x318], 0x00
0000755de29cea76  jz 0x0000755DE29CEAD0
0000755de29cea7c  nop [rax+rax*1], ax
0000755de29cea85  nop [rax+rax*1], eax
0000755de29cea8d  mov eax, 0x410070
0000755de29cea92  mov [r15+0x100], rax
0000755de29cea99  jmp 0x0000755DE27FE110
0000755de29cea9e  cmp dword ptr [r15+0x318], 0x00
0000755de29ceaa6  jz 0x0000755DE29CE910
0000755de29ceaac  nop [rax+rax*1], ax
0000755de29ceab5  nop [rax+rax*1], eax
0000755de29ceabd  mov eax, 0x41006C
0000755de29ceac2  mov [r15+0x100], rax
0000755de29ceac9  jmp 0x0000755DE27FE110
0000755de29ceace  int3
0000755de29ceacf  int3
0000755de29cead0  mov rax, [r15+0x08]
0000755de29cead4  mov [rsp+0x10], rax
0000755de29cead9  xor eax, eax
0000755de29ceadb  mov r14, [rsp+0x10]
0000755de29ceae0  mov r12d, 0x01
0000755de29ceae6  sub r14, r12
0000755de29ceae9  cmc
0000755de29ceaea  lahf
0000755de29ceaeb  seto al
0000755de29ceaee  mov [r15+0x108], eax
0000755de29ceaf5  mov [r15+0x08], r14
0000755de29ceaf9  mov eax, [r15+0x108]
0000755de29ceb00  sahf
0000755de29ceb01  jnz 0x0000755DE29CEB33
0000755de29ceb03  cmp dword ptr [r15+0x318], 0x00
0000755de29ceb0b  jz 0x0000755DE29CECB0
0000755de29ceb11  nop [rax+rax*1], ax
0000755de29ceb1a  nop [rax+rax*1], eax
0000755de29ceb22  mov eax, 0x410078
0000755de29ceb27  mov [r15+0x100], rax
0000755de29ceb2e  jmp 0x0000755DE27FE110
0000755de29ceb33  cmp dword ptr [r15+0x318], 0x00
0000755de29ceb3b  jz 0x0000755DE29CE9C0
0000755de29ceb41  nop [rax+rax*1], ax
0000755de29ceb4a  nop [rax+rax*1], eax
0000755de29ceb52  mov eax, 0x410040
0000755de29ceb57  mov [r15+0x100], rax
0000755de29ceb5e  jmp 0x0000755DE27FE110
0000755de29ceb63  int3
0000755de29ceb64  int3
0000755de29ceb65  nop [rax+rax*1], ax
0000755de29ceb6e  nop
0000755de29ceb70  mov rax, [r15+0x10]
0000755de29ceb74  lea r14, [rax+0x05]
0000755de29ceb78  mov [r15+0x10], r14
0000755de29ceb7c  mov rax, [r15]
0000755de29ceb7f  and rax, 0x01
0000755de29ceb83  mov [r15+0x18], rax
0000755de29ceb87  test rax, rax
0000755de29ceb8a  setz al
0000755de29ceb8d  movzx rax, al
0000755de29ceb91  mov [rsp+0x414], al
0000755de29ceb98  cmp byte ptr [rsp+0x414], 0x00
0000755de29ceba0  jz 0x0000755DE29CEBD2
0000755de29ceba2  cmp dword ptr [r15+0x318], 0x00
0000755de29cebaa  jz 0x0000755DE29CEA50
0000755de29cebb0  nop [rax+rax*1], ax
0000755de29cebb9  nop [rax+rax*1], eax
0000755de29cebc1  mov eax, 0x410068
0000755de29cebc6  mov [r15+0x100], rax
0000755de29cebcd  jmp 0x0000755DE27FE110
0000755de29cebd2  cmp dword ptr [r15+0x318], 0x00
0000755de29cebda  jz 0x0000755DE29CE880
0000755de29cebe0  nop [rax+rax*1], ax
0000755de29cebe9  nop [rax+rax*1], eax
0000755de29cebf1  mov eax, 0x410064
0000755de29cebf6  mov [r15+0x100], rax
0000755de29cebfd  jmp 0x0000755DE27FE110
0000755de29cec02  int3
0000755de29cec03  int3
0000755de29cec04  nop [rax+rax*1], ax
0000755de29cec0d  nop [rax], eax
0000755de29cec10  mov rax, [r15]
0000755de29cec13  mov [rsp+0x10], rax
0000755de29cec18  xor eax, eax
0000755de29cec1a  mov r14, [rsp+0x10]
0000755de29cec1f  mov r12d, 0x05
0000755de29cec25  cmp r14, r12
0000755de29cec28  cmc
0000755de29cec29  lahf
0000755de29cec2a  seto al
0000755de29cec2d  mov [r15+0x108], eax
0000755de29cec34  mov eax, [r15+0x108]
0000755de29cec3b  cmp al, 0x81
0000755de29cec3d  sahf
0000755de29cec3e  jl 0x0000755DE29CEC70
0000755de29cec40  cmp dword ptr [r15+0x318], 0x00
0000755de29cec48  jz 0x0000755DE29CEB70
0000755de29cec4e  nop [rax+rax*1], ax
0000755de29cec57  nop [rax+rax*1], eax
0000755de29cec5f  mov eax, 0x410058
0000755de29cec64  mov [r15+0x100], rax
0000755de29cec6b  jmp 0x0000755DE27FE110
0000755de29cec70  cmp dword ptr [r15+0x318], 0x00
0000755de29cec78  jz 0x0000755DE29CE7F0
0000755de29cec7e  nop [rax+rax*1], ax
0000755de29cec87  nop [rax+rax*1], eax
0000755de29cec8f  mov eax, 0x41005C
0000755de29cec94  mov [r15+0x100], rax
0000755de29cec9b  jmp 0x0000755DE27FE110
0000755de29ceca0  int3
0000755de29ceca1  int3
0000755de29ceca2  nop [rax+rax*1], ax
0000755de29cecab  nop [rax+rax*1], eax
0000755de29cecb0  mov rax, [r15+0x10]
0000755de29cecb4  mov [r15], rax
0000755de29cecb7  mov r14, [r15+0x20]
0000755de29cecbb  mov [r13+r14*1], rax
0000755de29cecc0  mov rax, [r15+0xF0]
0000755de29cecc7  mov [r15+0x100], rax
0000755de29cecce  jmp 0x0000755DE29CE5C0
0000755de29cecd3  int3
0000755de29cecd4  call 0x0000755DE28D5EB0
0000755de29cecd9  jmp 0x0000755DE29CECC0
0000755de29cecde  int3
0000755de29cecdf  nop
0000755de29cece0  mov qword ptr [r15+0x100], 0x04
0000755de29ceceb  mov esi, 0x00
0000755de29cecf0  mov edx, 0x09
0000755de29cecf5  mov rdi, 0x7FFCB46CB5C0
0000755de29cecff  mov rax, 0x5627E6E86970
0000755de29ced09  call rax
0000755de29ced0b  cmp dword ptr [r15+0x318], 0x00
0000755de29ced13  jnz 0x0000755DE27FE110
0000755de29ced19  jmp 0x0000755DE27FE0A0
0000755de29ced1e  int3
0000755de29ced1f  int3
