00007f16ffbce69b  nop [rax+rax*1], eax
00007f16ffbce6a0  mov qword ptr [r15+0x08], 0xB71B00
00007f16ffbce6a8  mov qword ptr [r15+0x20], 0x420090
00007f16ffbce6b0  mov qword ptr [r15+0x10], 0x00
00007f16ffbce6b8  mov qword ptr [r15], 0x01
00007f16ffbce6bf  xor eax, eax
00007f16ffbce6c1  mov r14d, 0x01
00007f16ffbce6c7  mov r12d, 0x07
00007f16ffbce6cd  cmp r14, r12
00007f16ffbce6d0  cmc
00007f16ffbce6d1  lahf
00007f16ffbce6d2  seto al
00007f16ffbce6d5  mov [r15+0x108], eax
00007f16ffbce6dc  mov eax, [r15+0x108]
00007f16ffbce6e3  sahf
00007f16ffbce6e4  cmc
00007f16ffbce6e5  jnbe 0x00007F16FFBCE717
00007f16ffbce6e7  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce6ef  jz 0x00007F16FFBCE750
00007f16ffbce6f5  nop [rax+rax*1], ax
00007f16ffbce6fe  nop [rax+rax*1], eax
00007f16ffbce706  mov eax, 0x41004C
00007f16ffbce70b  mov [r15+0x100], rax
00007f16ffbce712  jmp 0x00007F16FF9FE110
00007f16ffbce717  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce71f  jz 0x00007F16FFBCEC10
00007f16ffbce725  nop [rax+rax*1], ax
00007f16ffbce72e  nop [rax+rax*1], eax
00007f16ffbce736  mov eax, 0x410050
00007f16ffbce73b  mov [r15+0x100], rax
00007f16ffbce742  jmp 0x00007F16FF9FE110
00007f16ffbce747  int3
00007f16ffbce748  int3
00007f16ffbce749  nop [rax], eax
00007f16ffbce750  mov rax, [r15+0x10]
00007f16ffbce754  lea r14, [rax+0x03]
00007f16ffbce758  mov [r15+0x10], r14
00007f16ffbce75c  mov rax, [r15]
00007f16ffbce75f  mov [rsp+0x10], rax
00007f16ffbce764  xor eax, eax
00007f16ffbce766  mov r14, [rsp+0x10]
00007f16ffbce76b  mov r12d, 0x05
00007f16ffbce771  cmp r14, r12
00007f16ffbce774  cmc
00007f16ffbce775  lahf
00007f16ffbce776  seto al
00007f16ffbce779  mov [r15+0x108], eax
00007f16ffbce780  mov eax, [r15+0x108]
00007f16ffbce787  cmp al, 0x81
00007f16ffbce789  sahf
00007f16ffbce78a  jl 0x00007F16FFBCE7BC
00007f16ffbce78c  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce794  jz 0x00007F16FFBCEB70
00007f16ffbce79a  nop [rax+rax*1], ax
00007f16ffbce7a3  nop [rax+rax*1], eax
00007f16ffbce7ab  mov eax, 0x410058
00007f16ffbce7b0  mov [r15+0x100], rax
00007f16ffbce7b7  jmp 0x00007F16FF9FE110
00007f16ffbce7bc  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce7c4  jz 0x00007F16FFBCE7F0
00007f16ffbce7ca  nop [rax+rax*1], ax
00007f16ffbce7d3  nop [rax+rax*1], eax
00007f16ffbce7db  mov eax, 0x41005C
00007f16ffbce7e0  mov [r15+0x100], rax
00007f16ffbce7e7  jmp 0x00007F16FF9FE110
00007f16ffbce7ec  int3
00007f16ffbce7ed  int3
00007f16ffbce7ee  nop
00007f16ffbce7f0  mov rax, [r15]
00007f16ffbce7f3  and rax, 0x01
00007f16ffbce7f7  mov [r15+0x18], rax
00007f16ffbce7fb  test rax, rax
00007f16ffbce7fe  setz al
00007f16ffbce801  movzx rax, al
00007f16ffbce805  mov [rsp+0x414], al
00007f16ffbce80c  cmp byte ptr [rsp+0x414], 0x00
00007f16ffbce814  jz 0x00007F16FFBCE846
00007f16ffbce816  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce81e  jz 0x00007F16FFBCEA50
00007f16ffbce824  nop [rax+rax*1], ax
00007f16ffbce82d  nop [rax+rax*1], eax
00007f16ffbce835  mov eax, 0x410068
00007f16ffbce83a  mov [r15+0x100], rax
00007f16ffbce841  jmp 0x00007F16FF9FE110
00007f16ffbce846  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce84e  jz 0x00007F16FFBCE880
00007f16ffbce854  nop [rax+rax*1], ax
00007f16ffbce85d  nop [rax+rax*1], eax
00007f16ffbce865  mov eax, 0x410064
00007f16ffbce86a  mov [r15+0x100], rax
00007f16ffbce871  jmp 0x00007F16FF9FE110
00007f16ffbce876  int3
00007f16ffbce877  int3
00007f16ffbce878  nop [rax+rax*1], eax
00007f16ffbce880  mov rax, [r15+0x10]
00007f16ffbce884  lea r14, [rax+0x07]
00007f16ffbce888  mov [r15+0x10], r14
00007f16ffbce88c  mov eax, [r15]
00007f16ffbce88f  mov eax, eax
00007f16ffbce891  bt rax, 0x01
00007f16ffbce896  setb al
00007f16ffbce899  mov [rsp+0x414], al
00007f16ffbce8a0  cmp byte ptr [rsp+0x414], 0x00
00007f16ffbce8a8  jz 0x00007F16FFBCE8DA
00007f16ffbce8aa  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce8b2  jz 0x00007F16FFBCEAD0
00007f16ffbce8b8  nop [rax+rax*1], ax
00007f16ffbce8c1  nop [rax+rax*1], eax
00007f16ffbce8c9  mov eax, 0x410070
00007f16ffbce8ce  mov [r15+0x100], rax
00007f16ffbce8d5  jmp 0x00007F16FF9FE110
00007f16ffbce8da  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce8e2  jz 0x00007F16FFBCE910
00007f16ffbce8e8  nop [rax+rax*1], ax
00007f16ffbce8f1  nop [rax+rax*1], eax
00007f16ffbce8f9  mov eax, 0x41006C
00007f16ffbce8fe  mov [r15+0x100], rax
00007f16ffbce905  jmp 0x00007F16FF9FE110
00007f16ffbce90a  int3
00007f16ffbce90b  int3
00007f16ffbce90c  nop [rax], eax
00007f16ffbce910  mov rax, [r15+0x10]
00007f16ffbce914  lea r14, [rax+0x0B]
00007f16ffbce918  mov [r15+0x10], r14
00007f16ffbce91c  mov rax, [r15+0x08]
00007f16ffbce920  mov [rsp+0x10], rax
00007f16ffbce925  xor eax, eax
00007f16ffbce927  mov r14, [rsp+0x10]
00007f16ffbce92c  mov r12d, 0x01
00007f16ffbce932  sub r14, r12
00007f16ffbce935  cmc
00007f16ffbce936  lahf
00007f16ffbce937  seto al
00007f16ffbce93a  mov [r15+0x108], eax
00007f16ffbce941  mov [r15+0x08], r14
00007f16ffbce945  mov eax, [r15+0x108]
00007f16ffbce94c  sahf
00007f16ffbce94d  jnz 0x00007F16FFBCE97F
00007f16ffbce94f  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce957  jz 0x00007F16FFBCECB0
00007f16ffbce95d  nop [rax+rax*1], ax
00007f16ffbce966  nop [rax+rax*1], eax
00007f16ffbce96e  mov eax, 0x410078
00007f16ffbce973  mov [r15+0x100], rax
00007f16ffbce97a  jmp 0x00007F16FF9FE110
00007f16ffbce97f  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce987  jz 0x00007F16FFBCE9C0
00007f16ffbce98d  nop [rax+rax*1], ax
00007f16ffbce996  nop [rax+rax*1], eax
00007f16ffbce99e  mov eax, 0x410040
00007f16ffbce9a3  mov [r15+0x100], rax
00007f16ffbce9aa  jmp 0x00007F16FF9FE110
00007f16ffbce9af  int3
00007f16ffbce9b0  int3
00007f16ffbce9b1  nop [rax+rax*1], ax
00007f16ffbce9ba  nop [rax+rax*1], ax
00007f16ffbce9c0  mov rax, [r15]
00007f16ffbce9c3  lea r14, [rax+0x01]
00007f16ffbce9c7  mov [r15], r14
00007f16ffbce9ca  xor eax, eax
00007f16ffbce9cc  mov r12d, 0x07
00007f16ffbce9d2  cmp r14, r12
00007f16ffbce9d5  cmc
00007f16ffbce9d6  lahf
00007f16ffbce9d7  seto al
00007f16ffbce9da  mov [r15+0x108], eax
00007f16ffbce9e1  mov eax, [r15+0x108]
00007f16ffbce9e8  sahf
00007f16ffbce9e9  cmc
00007f16ffbce9ea  jnbe 0x00007F16FFBCEA1C
00007f16ffbce9ec  cmp dword ptr [r15+0x318], 0x00
00007f16ffbce9f4  jz 0x00007F16FFBCE750
00007f16ffbce9fa  nop [rax+rax*1], ax
00007f16ffbcea03  nop [rax+rax*1], eax
00007f16ffbcea0b  mov eax, 0x41004C
00007f16ffbcea10  mov [r15+0x100], rax
00007f16ffbcea17  jmp 0x00007F16FF9FE110
00007f16ffbcea1c  cmp dword ptr [r15+0x318], 0x00
00007f16ffbcea24  jz 0x00007F16FFBCEC10
00007f16ffbcea2a  nop [rax+rax*1], ax
00007f16ffbcea33  nop [rax+rax*1], eax
00007f16ffbcea3b  mov eax, 0x410050
00007f16ffbcea40  mov [r15+0x100], rax
00007f16ffbcea47  jmp 0x00007F16FF9FE110
00007f16ffbcea4c  int3
00007f16ffbcea4d  int3
00007f16ffbcea4e  nop
00007f16ffbcea50  mov eax, [r15]
00007f16ffbcea53  mov eax, eax
00007f16ffbcea55  bt rax, 0x01
00007f16ffbcea5a  setb al
00007f16ffbcea5d  mov [rsp+0x414], al
00007f16ffbcea64  cmp byte ptr [rsp+0x414], 0x00
00007f16ffbcea6c  jz 0x00007F16FFBCEA9E
00007f16ffbcea6e  cmp dword ptr [r15+0x318], 0x00
00007f16ffbcea76  jz 0x00007F16FFBCEAD0
00007f16ffbcea7c  nop [rax+rax*1], ax
00007f16ffbcea85  nop [rax+rax*1], eax
00007f16ffbcea8d  mov eax, 0x410070
00007f16ffbcea92  mov [r15+0x100], rax
00007f16ffbcea99  jmp 0x00007F16FF9FE110
00007f16ffbcea9e  cmp dword ptr [r15+0x318], 0x00
00007f16ffbceaa6  jz 0x00007F16FFBCE910
00007f16ffbceaac  nop [rax+rax*1], ax
00007f16ffbceab5  nop [rax+rax*1], eax
00007f16ffbceabd  mov eax, 0x41006C
00007f16ffbceac2  mov [r15+0x100], rax
00007f16ffbceac9  jmp 0x00007F16FF9FE110
00007f16ffbceace  int3
00007f16ffbceacf  int3
00007f16ffbcead0  mov rax, [r15+0x08]
00007f16ffbcead4  mov [rsp+0x10], rax
00007f16ffbcead9  xor eax, eax
00007f16ffbceadb  mov r14, [rsp+0x10]
00007f16ffbceae0  mov r12d, 0x01
00007f16ffbceae6  sub r14, r12
00007f16ffbceae9  cmc
00007f16ffbceaea  lahf
00007f16ffbceaeb  seto al
00007f16ffbceaee  mov [r15+0x108], eax
00007f16ffbceaf5  mov [r15+0x08], r14
00007f16ffbceaf9  mov eax, [r15+0x108]
00007f16ffbceb00  sahf
00007f16ffbceb01  jnz 0x00007F16FFBCEB33
00007f16ffbceb03  cmp dword ptr [r15+0x318], 0x00
00007f16ffbceb0b  jz 0x00007F16FFBCECB0
00007f16ffbceb11  nop [rax+rax*1], ax
00007f16ffbceb1a  nop [rax+rax*1], eax
00007f16ffbceb22  mov eax, 0x410078
00007f16ffbceb27  mov [r15+0x100], rax
00007f16ffbceb2e  jmp 0x00007F16FF9FE110
00007f16ffbceb33  cmp dword ptr [r15+0x318], 0x00
00007f16ffbceb3b  jz 0x00007F16FFBCE9C0
00007f16ffbceb41  nop [rax+rax*1], ax
00007f16ffbceb4a  nop [rax+rax*1], eax
00007f16ffbceb52  mov eax, 0x410040
00007f16ffbceb57  mov [r15+0x100], rax
00007f16ffbceb5e  jmp 0x00007F16FF9FE110
00007f16ffbceb63  int3
00007f16ffbceb64  int3
00007f16ffbceb65  nop [rax+rax*1], ax
00007f16ffbceb6e  nop
00007f16ffbceb70  mov rax, [r15+0x10]
00007f16ffbceb74  lea r14, [rax+0x05]
00007f16ffbceb78  mov [r15+0x10], r14
00007f16ffbceb7c  mov rax, [r15]
00007f16ffbceb7f  and rax, 0x01
00007f16ffbceb83  mov [r15+0x18], rax
00007f16ffbceb87  test rax, rax
00007f16ffbceb8a  setz al
00007f16ffbceb8d  movzx rax, al
00007f16ffbceb91  mov [rsp+0x414], al
00007f16ffbceb98  cmp byte ptr [rsp+0x414], 0x00
00007f16ffbceba0  jz 0x00007F16FFBCEBD2
00007f16ffbceba2  cmp dword ptr [r15+0x318], 0x00
00007f16ffbcebaa  jz 0x00007F16FFBCEA50
00007f16ffbcebb0  nop [rax+rax*1], ax
00007f16ffbcebb9  nop [rax+rax*1], eax
00007f16ffbcebc1  mov eax, 0x410068
00007f16ffbcebc6  mov [r15+0x100], rax
00007f16ffbcebcd  jmp 0x00007F16FF9FE110
00007f16ffbcebd2  cmp dword ptr [r15+0x318], 0x00
00007f16ffbcebda  jz 0x00007F16FFBCE880
00007f16ffbcebe0  nop [rax+rax*1], ax
00007f16ffbcebe9  nop [rax+rax*1], eax
00007f16ffbcebf1  mov eax, 0x410064
00007f16ffbcebf6  mov [r15+0x100], rax
00007f16ffbcebfd  jmp 0x00007F16FF9FE110
00007f16ffbcec02  int3
00007f16ffbcec03  int3
00007f16ffbcec04  nop [rax+rax*1], ax
00007f16ffbcec0d  nop [rax], eax
00007f16ffbcec10  mov rax, [r15]
00007f16ffbcec13  mov [rsp+0x10], rax
00007f16ffbcec18  xor eax, eax
00007f16ffbcec1a  mov r14, [rsp+0x10]
00007f16ffbcec1f  mov r12d, 0x05
00007f16ffbcec25  cmp r14, r12
00007f16ffbcec28  cmc
00007f16ffbcec29  lahf
00007f16ffbcec2a  seto al
00007f16ffbcec2d  mov [r15+0x108], eax
00007f16ffbcec34  mov eax, [r15+0x108]
00007f16ffbcec3b  cmp al, 0x81
00007f16ffbcec3d  sahf
00007f16ffbcec3e  jl 0x00007F16FFBCEC70
00007f16ffbcec40  cmp dword ptr [r15+0x318], 0x00
00007f16ffbcec48  jz 0x00007F16FFBCEB70
00007f16ffbcec4e  nop [rax+rax*1], ax
00007f16ffbcec57  nop [rax+rax*1], eax
00007f16ffbcec5f  mov eax, 0x410058
00007f16ffbcec64  mov [r15+0x100], rax
00007f16ffbcec6b  jmp 0x00007F16FF9FE110
00007f16ffbcec70  cmp dword ptr [r15+0x318], 0x00
00007f16ffbcec78  jz 0x00007F16FFBCE7F0
00007f16ffbcec7e  nop [rax+rax*1], ax
00007f16ffbcec87  nop [rax+rax*1], eax
00007f16ffbcec8f  mov eax, 0x41005C
00007f16ffbcec94  mov [r15+0x100], rax
00007f16ffbcec9b  jmp 0x00007F16FF9FE110
00007f16ffbceca0  int3
00007f16ffbceca1  int3
00007f16ffbceca2  nop [rax+rax*1], ax
00007f16ffbcecab  nop [rax+rax*1], eax
00007f16ffbcecb0  mov rax, [r15+0x10]
00007f16ffbcecb4  mov [r15], rax
00007f16ffbcecb7  mov r14, [r15+0x20]
00007f16ffbcecbb  mov [r13+r14*1], rax
00007f16ffbcecc0  mov rax, [r15+0xF0]
00007f16ffbcecc7  mov [r15+0x100], rax
00007f16ffbcecce  jmp 0x00007F16FFBCE5C0
00007f16ffbcecd3  int3
00007f16ffbcecd4  call 0x00007F16FFAD5EB0
00007f16ffbcecd9  jmp 0x00007F16FFBCECC0
00007f16ffbcecde  int3
00007f16ffbcecdf  nop
00007f16ffbcece0  mov qword ptr [r15+0x100], 0x04
00007f16ffbceceb  mov esi, 0x00
00007f16ffbcecf0  mov edx, 0x09
00007f16ffbcecf5  mov rdi, 0x7FFD85F8AA10
00007f16ffbcecff  mov rax, 0x5C8C23D18970
00007f16ffbced09  call rax
00007f16ffbced0b  cmp dword ptr [r15+0x318], 0x00
00007f16ffbced13  jnz 0x00007F16FF9FE110
00007f16ffbced19  jmp 0x00007F16FF9FE0A0
00007f16ffbced1e  int3
00007f16ffbced1f  int3
