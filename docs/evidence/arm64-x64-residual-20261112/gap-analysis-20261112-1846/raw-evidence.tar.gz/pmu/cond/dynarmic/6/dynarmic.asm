0000749d3c9ce69b  nop [rax+rax*1], eax
0000749d3c9ce6a0  mov qword ptr [r15+0x08], 0xB71B00
0000749d3c9ce6a8  mov qword ptr [r15+0x20], 0x420090
0000749d3c9ce6b0  mov qword ptr [r15+0x10], 0x00
0000749d3c9ce6b8  mov qword ptr [r15], 0x01
0000749d3c9ce6bf  xor eax, eax
0000749d3c9ce6c1  mov r14d, 0x01
0000749d3c9ce6c7  mov r12d, 0x07
0000749d3c9ce6cd  cmp r14, r12
0000749d3c9ce6d0  cmc
0000749d3c9ce6d1  lahf
0000749d3c9ce6d2  seto al
0000749d3c9ce6d5  mov [r15+0x108], eax
0000749d3c9ce6dc  mov eax, [r15+0x108]
0000749d3c9ce6e3  sahf
0000749d3c9ce6e4  cmc
0000749d3c9ce6e5  jnbe 0x0000749D3C9CE717
0000749d3c9ce6e7  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce6ef  jz 0x0000749D3C9CE750
0000749d3c9ce6f5  nop [rax+rax*1], ax
0000749d3c9ce6fe  nop [rax+rax*1], eax
0000749d3c9ce706  mov eax, 0x41004C
0000749d3c9ce70b  mov [r15+0x100], rax
0000749d3c9ce712  jmp 0x0000749D3C7FE110
0000749d3c9ce717  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce71f  jz 0x0000749D3C9CEC10
0000749d3c9ce725  nop [rax+rax*1], ax
0000749d3c9ce72e  nop [rax+rax*1], eax
0000749d3c9ce736  mov eax, 0x410050
0000749d3c9ce73b  mov [r15+0x100], rax
0000749d3c9ce742  jmp 0x0000749D3C7FE110
0000749d3c9ce747  int3
0000749d3c9ce748  int3
0000749d3c9ce749  nop [rax], eax
0000749d3c9ce750  mov rax, [r15+0x10]
0000749d3c9ce754  lea r14, [rax+0x03]
0000749d3c9ce758  mov [r15+0x10], r14
0000749d3c9ce75c  mov rax, [r15]
0000749d3c9ce75f  mov [rsp+0x10], rax
0000749d3c9ce764  xor eax, eax
0000749d3c9ce766  mov r14, [rsp+0x10]
0000749d3c9ce76b  mov r12d, 0x05
0000749d3c9ce771  cmp r14, r12
0000749d3c9ce774  cmc
0000749d3c9ce775  lahf
0000749d3c9ce776  seto al
0000749d3c9ce779  mov [r15+0x108], eax
0000749d3c9ce780  mov eax, [r15+0x108]
0000749d3c9ce787  cmp al, 0x81
0000749d3c9ce789  sahf
0000749d3c9ce78a  jl 0x0000749D3C9CE7BC
0000749d3c9ce78c  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce794  jz 0x0000749D3C9CEB70
0000749d3c9ce79a  nop [rax+rax*1], ax
0000749d3c9ce7a3  nop [rax+rax*1], eax
0000749d3c9ce7ab  mov eax, 0x410058
0000749d3c9ce7b0  mov [r15+0x100], rax
0000749d3c9ce7b7  jmp 0x0000749D3C7FE110
0000749d3c9ce7bc  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce7c4  jz 0x0000749D3C9CE7F0
0000749d3c9ce7ca  nop [rax+rax*1], ax
0000749d3c9ce7d3  nop [rax+rax*1], eax
0000749d3c9ce7db  mov eax, 0x41005C
0000749d3c9ce7e0  mov [r15+0x100], rax
0000749d3c9ce7e7  jmp 0x0000749D3C7FE110
0000749d3c9ce7ec  int3
0000749d3c9ce7ed  int3
0000749d3c9ce7ee  nop
0000749d3c9ce7f0  mov rax, [r15]
0000749d3c9ce7f3  and rax, 0x01
0000749d3c9ce7f7  mov [r15+0x18], rax
0000749d3c9ce7fb  test rax, rax
0000749d3c9ce7fe  setz al
0000749d3c9ce801  movzx rax, al
0000749d3c9ce805  mov [rsp+0x414], al
0000749d3c9ce80c  cmp byte ptr [rsp+0x414], 0x00
0000749d3c9ce814  jz 0x0000749D3C9CE846
0000749d3c9ce816  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce81e  jz 0x0000749D3C9CEA50
0000749d3c9ce824  nop [rax+rax*1], ax
0000749d3c9ce82d  nop [rax+rax*1], eax
0000749d3c9ce835  mov eax, 0x410068
0000749d3c9ce83a  mov [r15+0x100], rax
0000749d3c9ce841  jmp 0x0000749D3C7FE110
0000749d3c9ce846  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce84e  jz 0x0000749D3C9CE880
0000749d3c9ce854  nop [rax+rax*1], ax
0000749d3c9ce85d  nop [rax+rax*1], eax
0000749d3c9ce865  mov eax, 0x410064
0000749d3c9ce86a  mov [r15+0x100], rax
0000749d3c9ce871  jmp 0x0000749D3C7FE110
0000749d3c9ce876  int3
0000749d3c9ce877  int3
0000749d3c9ce878  nop [rax+rax*1], eax
0000749d3c9ce880  mov rax, [r15+0x10]
0000749d3c9ce884  lea r14, [rax+0x07]
0000749d3c9ce888  mov [r15+0x10], r14
0000749d3c9ce88c  mov eax, [r15]
0000749d3c9ce88f  mov eax, eax
0000749d3c9ce891  bt rax, 0x01
0000749d3c9ce896  setb al
0000749d3c9ce899  mov [rsp+0x414], al
0000749d3c9ce8a0  cmp byte ptr [rsp+0x414], 0x00
0000749d3c9ce8a8  jz 0x0000749D3C9CE8DA
0000749d3c9ce8aa  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce8b2  jz 0x0000749D3C9CEAD0
0000749d3c9ce8b8  nop [rax+rax*1], ax
0000749d3c9ce8c1  nop [rax+rax*1], eax
0000749d3c9ce8c9  mov eax, 0x410070
0000749d3c9ce8ce  mov [r15+0x100], rax
0000749d3c9ce8d5  jmp 0x0000749D3C7FE110
0000749d3c9ce8da  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce8e2  jz 0x0000749D3C9CE910
0000749d3c9ce8e8  nop [rax+rax*1], ax
0000749d3c9ce8f1  nop [rax+rax*1], eax
0000749d3c9ce8f9  mov eax, 0x41006C
0000749d3c9ce8fe  mov [r15+0x100], rax
0000749d3c9ce905  jmp 0x0000749D3C7FE110
0000749d3c9ce90a  int3
0000749d3c9ce90b  int3
0000749d3c9ce90c  nop [rax], eax
0000749d3c9ce910  mov rax, [r15+0x10]
0000749d3c9ce914  lea r14, [rax+0x0B]
0000749d3c9ce918  mov [r15+0x10], r14
0000749d3c9ce91c  mov rax, [r15+0x08]
0000749d3c9ce920  mov [rsp+0x10], rax
0000749d3c9ce925  xor eax, eax
0000749d3c9ce927  mov r14, [rsp+0x10]
0000749d3c9ce92c  mov r12d, 0x01
0000749d3c9ce932  sub r14, r12
0000749d3c9ce935  cmc
0000749d3c9ce936  lahf
0000749d3c9ce937  seto al
0000749d3c9ce93a  mov [r15+0x108], eax
0000749d3c9ce941  mov [r15+0x08], r14
0000749d3c9ce945  mov eax, [r15+0x108]
0000749d3c9ce94c  sahf
0000749d3c9ce94d  jnz 0x0000749D3C9CE97F
0000749d3c9ce94f  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce957  jz 0x0000749D3C9CECB0
0000749d3c9ce95d  nop [rax+rax*1], ax
0000749d3c9ce966  nop [rax+rax*1], eax
0000749d3c9ce96e  mov eax, 0x410078
0000749d3c9ce973  mov [r15+0x100], rax
0000749d3c9ce97a  jmp 0x0000749D3C7FE110
0000749d3c9ce97f  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce987  jz 0x0000749D3C9CE9C0
0000749d3c9ce98d  nop [rax+rax*1], ax
0000749d3c9ce996  nop [rax+rax*1], eax
0000749d3c9ce99e  mov eax, 0x410040
0000749d3c9ce9a3  mov [r15+0x100], rax
0000749d3c9ce9aa  jmp 0x0000749D3C7FE110
0000749d3c9ce9af  int3
0000749d3c9ce9b0  int3
0000749d3c9ce9b1  nop [rax+rax*1], ax
0000749d3c9ce9ba  nop [rax+rax*1], ax
0000749d3c9ce9c0  mov rax, [r15]
0000749d3c9ce9c3  lea r14, [rax+0x01]
0000749d3c9ce9c7  mov [r15], r14
0000749d3c9ce9ca  xor eax, eax
0000749d3c9ce9cc  mov r12d, 0x07
0000749d3c9ce9d2  cmp r14, r12
0000749d3c9ce9d5  cmc
0000749d3c9ce9d6  lahf
0000749d3c9ce9d7  seto al
0000749d3c9ce9da  mov [r15+0x108], eax
0000749d3c9ce9e1  mov eax, [r15+0x108]
0000749d3c9ce9e8  sahf
0000749d3c9ce9e9  cmc
0000749d3c9ce9ea  jnbe 0x0000749D3C9CEA1C
0000749d3c9ce9ec  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ce9f4  jz 0x0000749D3C9CE750
0000749d3c9ce9fa  nop [rax+rax*1], ax
0000749d3c9cea03  nop [rax+rax*1], eax
0000749d3c9cea0b  mov eax, 0x41004C
0000749d3c9cea10  mov [r15+0x100], rax
0000749d3c9cea17  jmp 0x0000749D3C7FE110
0000749d3c9cea1c  cmp dword ptr [r15+0x318], 0x00
0000749d3c9cea24  jz 0x0000749D3C9CEC10
0000749d3c9cea2a  nop [rax+rax*1], ax
0000749d3c9cea33  nop [rax+rax*1], eax
0000749d3c9cea3b  mov eax, 0x410050
0000749d3c9cea40  mov [r15+0x100], rax
0000749d3c9cea47  jmp 0x0000749D3C7FE110
0000749d3c9cea4c  int3
0000749d3c9cea4d  int3
0000749d3c9cea4e  nop
0000749d3c9cea50  mov eax, [r15]
0000749d3c9cea53  mov eax, eax
0000749d3c9cea55  bt rax, 0x01
0000749d3c9cea5a  setb al
0000749d3c9cea5d  mov [rsp+0x414], al
0000749d3c9cea64  cmp byte ptr [rsp+0x414], 0x00
0000749d3c9cea6c  jz 0x0000749D3C9CEA9E
0000749d3c9cea6e  cmp dword ptr [r15+0x318], 0x00
0000749d3c9cea76  jz 0x0000749D3C9CEAD0
0000749d3c9cea7c  nop [rax+rax*1], ax
0000749d3c9cea85  nop [rax+rax*1], eax
0000749d3c9cea8d  mov eax, 0x410070
0000749d3c9cea92  mov [r15+0x100], rax
0000749d3c9cea99  jmp 0x0000749D3C7FE110
0000749d3c9cea9e  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ceaa6  jz 0x0000749D3C9CE910
0000749d3c9ceaac  nop [rax+rax*1], ax
0000749d3c9ceab5  nop [rax+rax*1], eax
0000749d3c9ceabd  mov eax, 0x41006C
0000749d3c9ceac2  mov [r15+0x100], rax
0000749d3c9ceac9  jmp 0x0000749D3C7FE110
0000749d3c9ceace  int3
0000749d3c9ceacf  int3
0000749d3c9cead0  mov rax, [r15+0x08]
0000749d3c9cead4  mov [rsp+0x10], rax
0000749d3c9cead9  xor eax, eax
0000749d3c9ceadb  mov r14, [rsp+0x10]
0000749d3c9ceae0  mov r12d, 0x01
0000749d3c9ceae6  sub r14, r12
0000749d3c9ceae9  cmc
0000749d3c9ceaea  lahf
0000749d3c9ceaeb  seto al
0000749d3c9ceaee  mov [r15+0x108], eax
0000749d3c9ceaf5  mov [r15+0x08], r14
0000749d3c9ceaf9  mov eax, [r15+0x108]
0000749d3c9ceb00  sahf
0000749d3c9ceb01  jnz 0x0000749D3C9CEB33
0000749d3c9ceb03  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ceb0b  jz 0x0000749D3C9CECB0
0000749d3c9ceb11  nop [rax+rax*1], ax
0000749d3c9ceb1a  nop [rax+rax*1], eax
0000749d3c9ceb22  mov eax, 0x410078
0000749d3c9ceb27  mov [r15+0x100], rax
0000749d3c9ceb2e  jmp 0x0000749D3C7FE110
0000749d3c9ceb33  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ceb3b  jz 0x0000749D3C9CE9C0
0000749d3c9ceb41  nop [rax+rax*1], ax
0000749d3c9ceb4a  nop [rax+rax*1], eax
0000749d3c9ceb52  mov eax, 0x410040
0000749d3c9ceb57  mov [r15+0x100], rax
0000749d3c9ceb5e  jmp 0x0000749D3C7FE110
0000749d3c9ceb63  int3
0000749d3c9ceb64  int3
0000749d3c9ceb65  nop [rax+rax*1], ax
0000749d3c9ceb6e  nop
0000749d3c9ceb70  mov rax, [r15+0x10]
0000749d3c9ceb74  lea r14, [rax+0x05]
0000749d3c9ceb78  mov [r15+0x10], r14
0000749d3c9ceb7c  mov rax, [r15]
0000749d3c9ceb7f  and rax, 0x01
0000749d3c9ceb83  mov [r15+0x18], rax
0000749d3c9ceb87  test rax, rax
0000749d3c9ceb8a  setz al
0000749d3c9ceb8d  movzx rax, al
0000749d3c9ceb91  mov [rsp+0x414], al
0000749d3c9ceb98  cmp byte ptr [rsp+0x414], 0x00
0000749d3c9ceba0  jz 0x0000749D3C9CEBD2
0000749d3c9ceba2  cmp dword ptr [r15+0x318], 0x00
0000749d3c9cebaa  jz 0x0000749D3C9CEA50
0000749d3c9cebb0  nop [rax+rax*1], ax
0000749d3c9cebb9  nop [rax+rax*1], eax
0000749d3c9cebc1  mov eax, 0x410068
0000749d3c9cebc6  mov [r15+0x100], rax
0000749d3c9cebcd  jmp 0x0000749D3C7FE110
0000749d3c9cebd2  cmp dword ptr [r15+0x318], 0x00
0000749d3c9cebda  jz 0x0000749D3C9CE880
0000749d3c9cebe0  nop [rax+rax*1], ax
0000749d3c9cebe9  nop [rax+rax*1], eax
0000749d3c9cebf1  mov eax, 0x410064
0000749d3c9cebf6  mov [r15+0x100], rax
0000749d3c9cebfd  jmp 0x0000749D3C7FE110
0000749d3c9cec02  int3
0000749d3c9cec03  int3
0000749d3c9cec04  nop [rax+rax*1], ax
0000749d3c9cec0d  nop [rax], eax
0000749d3c9cec10  mov rax, [r15]
0000749d3c9cec13  mov [rsp+0x10], rax
0000749d3c9cec18  xor eax, eax
0000749d3c9cec1a  mov r14, [rsp+0x10]
0000749d3c9cec1f  mov r12d, 0x05
0000749d3c9cec25  cmp r14, r12
0000749d3c9cec28  cmc
0000749d3c9cec29  lahf
0000749d3c9cec2a  seto al
0000749d3c9cec2d  mov [r15+0x108], eax
0000749d3c9cec34  mov eax, [r15+0x108]
0000749d3c9cec3b  cmp al, 0x81
0000749d3c9cec3d  sahf
0000749d3c9cec3e  jl 0x0000749D3C9CEC70
0000749d3c9cec40  cmp dword ptr [r15+0x318], 0x00
0000749d3c9cec48  jz 0x0000749D3C9CEB70
0000749d3c9cec4e  nop [rax+rax*1], ax
0000749d3c9cec57  nop [rax+rax*1], eax
0000749d3c9cec5f  mov eax, 0x410058
0000749d3c9cec64  mov [r15+0x100], rax
0000749d3c9cec6b  jmp 0x0000749D3C7FE110
0000749d3c9cec70  cmp dword ptr [r15+0x318], 0x00
0000749d3c9cec78  jz 0x0000749D3C9CE7F0
0000749d3c9cec7e  nop [rax+rax*1], ax
0000749d3c9cec87  nop [rax+rax*1], eax
0000749d3c9cec8f  mov eax, 0x41005C
0000749d3c9cec94  mov [r15+0x100], rax
0000749d3c9cec9b  jmp 0x0000749D3C7FE110
0000749d3c9ceca0  int3
0000749d3c9ceca1  int3
0000749d3c9ceca2  nop [rax+rax*1], ax
0000749d3c9cecab  nop [rax+rax*1], eax
0000749d3c9cecb0  mov rax, [r15+0x10]
0000749d3c9cecb4  mov [r15], rax
0000749d3c9cecb7  mov r14, [r15+0x20]
0000749d3c9cecbb  mov [r13+r14*1], rax
0000749d3c9cecc0  mov rax, [r15+0xF0]
0000749d3c9cecc7  mov [r15+0x100], rax
0000749d3c9cecce  jmp 0x0000749D3C9CE5C0
0000749d3c9cecd3  int3
0000749d3c9cecd4  call 0x0000749D3C8D5EB0
0000749d3c9cecd9  jmp 0x0000749D3C9CECC0
0000749d3c9cecde  int3
0000749d3c9cecdf  nop
0000749d3c9cece0  mov qword ptr [r15+0x100], 0x04
0000749d3c9ceceb  mov esi, 0x00
0000749d3c9cecf0  mov edx, 0x09
0000749d3c9cecf5  mov rdi, 0x7FFC2E997130
0000749d3c9cecff  mov rax, 0x5E0184B10970
0000749d3c9ced09  call rax
0000749d3c9ced0b  cmp dword ptr [r15+0x318], 0x00
0000749d3c9ced13  jnz 0x0000749D3C7FE110
0000749d3c9ced19  jmp 0x0000749D3C7FE0A0
0000749d3c9ced1e  int3
0000749d3c9ced1f  int3
