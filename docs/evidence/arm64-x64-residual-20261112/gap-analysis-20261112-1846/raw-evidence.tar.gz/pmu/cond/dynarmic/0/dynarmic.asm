00007bc80c9ce69b  nop [rax+rax*1], eax
00007bc80c9ce6a0  mov qword ptr [r15+0x08], 0xB71B00
00007bc80c9ce6a8  mov qword ptr [r15+0x20], 0x420090
00007bc80c9ce6b0  mov qword ptr [r15+0x10], 0x00
00007bc80c9ce6b8  mov qword ptr [r15], 0x01
00007bc80c9ce6bf  xor eax, eax
00007bc80c9ce6c1  mov r14d, 0x01
00007bc80c9ce6c7  mov r12d, 0x07
00007bc80c9ce6cd  cmp r14, r12
00007bc80c9ce6d0  cmc
00007bc80c9ce6d1  lahf
00007bc80c9ce6d2  seto al
00007bc80c9ce6d5  mov [r15+0x108], eax
00007bc80c9ce6dc  mov eax, [r15+0x108]
00007bc80c9ce6e3  sahf
00007bc80c9ce6e4  cmc
00007bc80c9ce6e5  jnbe 0x00007BC80C9CE717
00007bc80c9ce6e7  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce6ef  jz 0x00007BC80C9CE750
00007bc80c9ce6f5  nop [rax+rax*1], ax
00007bc80c9ce6fe  nop [rax+rax*1], eax
00007bc80c9ce706  mov eax, 0x41004C
00007bc80c9ce70b  mov [r15+0x100], rax
00007bc80c9ce712  jmp 0x00007BC80C7FE110
00007bc80c9ce717  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce71f  jz 0x00007BC80C9CEC10
00007bc80c9ce725  nop [rax+rax*1], ax
00007bc80c9ce72e  nop [rax+rax*1], eax
00007bc80c9ce736  mov eax, 0x410050
00007bc80c9ce73b  mov [r15+0x100], rax
00007bc80c9ce742  jmp 0x00007BC80C7FE110
00007bc80c9ce747  int3
00007bc80c9ce748  int3
00007bc80c9ce749  nop [rax], eax
00007bc80c9ce750  mov rax, [r15+0x10]
00007bc80c9ce754  lea r14, [rax+0x03]
00007bc80c9ce758  mov [r15+0x10], r14
00007bc80c9ce75c  mov rax, [r15]
00007bc80c9ce75f  mov [rsp+0x10], rax
00007bc80c9ce764  xor eax, eax
00007bc80c9ce766  mov r14, [rsp+0x10]
00007bc80c9ce76b  mov r12d, 0x05
00007bc80c9ce771  cmp r14, r12
00007bc80c9ce774  cmc
00007bc80c9ce775  lahf
00007bc80c9ce776  seto al
00007bc80c9ce779  mov [r15+0x108], eax
00007bc80c9ce780  mov eax, [r15+0x108]
00007bc80c9ce787  cmp al, 0x81
00007bc80c9ce789  sahf
00007bc80c9ce78a  jl 0x00007BC80C9CE7BC
00007bc80c9ce78c  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce794  jz 0x00007BC80C9CEB70
00007bc80c9ce79a  nop [rax+rax*1], ax
00007bc80c9ce7a3  nop [rax+rax*1], eax
00007bc80c9ce7ab  mov eax, 0x410058
00007bc80c9ce7b0  mov [r15+0x100], rax
00007bc80c9ce7b7  jmp 0x00007BC80C7FE110
00007bc80c9ce7bc  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce7c4  jz 0x00007BC80C9CE7F0
00007bc80c9ce7ca  nop [rax+rax*1], ax
00007bc80c9ce7d3  nop [rax+rax*1], eax
00007bc80c9ce7db  mov eax, 0x41005C
00007bc80c9ce7e0  mov [r15+0x100], rax
00007bc80c9ce7e7  jmp 0x00007BC80C7FE110
00007bc80c9ce7ec  int3
00007bc80c9ce7ed  int3
00007bc80c9ce7ee  nop
00007bc80c9ce7f0  mov rax, [r15]
00007bc80c9ce7f3  and rax, 0x01
00007bc80c9ce7f7  mov [r15+0x18], rax
00007bc80c9ce7fb  test rax, rax
00007bc80c9ce7fe  setz al
00007bc80c9ce801  movzx rax, al
00007bc80c9ce805  mov [rsp+0x414], al
00007bc80c9ce80c  cmp byte ptr [rsp+0x414], 0x00
00007bc80c9ce814  jz 0x00007BC80C9CE846
00007bc80c9ce816  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce81e  jz 0x00007BC80C9CEA50
00007bc80c9ce824  nop [rax+rax*1], ax
00007bc80c9ce82d  nop [rax+rax*1], eax
00007bc80c9ce835  mov eax, 0x410068
00007bc80c9ce83a  mov [r15+0x100], rax
00007bc80c9ce841  jmp 0x00007BC80C7FE110
00007bc80c9ce846  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce84e  jz 0x00007BC80C9CE880
00007bc80c9ce854  nop [rax+rax*1], ax
00007bc80c9ce85d  nop [rax+rax*1], eax
00007bc80c9ce865  mov eax, 0x410064
00007bc80c9ce86a  mov [r15+0x100], rax
00007bc80c9ce871  jmp 0x00007BC80C7FE110
00007bc80c9ce876  int3
00007bc80c9ce877  int3
00007bc80c9ce878  nop [rax+rax*1], eax
00007bc80c9ce880  mov rax, [r15+0x10]
00007bc80c9ce884  lea r14, [rax+0x07]
00007bc80c9ce888  mov [r15+0x10], r14
00007bc80c9ce88c  mov eax, [r15]
00007bc80c9ce88f  mov eax, eax
00007bc80c9ce891  bt rax, 0x01
00007bc80c9ce896  setb al
00007bc80c9ce899  mov [rsp+0x414], al
00007bc80c9ce8a0  cmp byte ptr [rsp+0x414], 0x00
00007bc80c9ce8a8  jz 0x00007BC80C9CE8DA
00007bc80c9ce8aa  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce8b2  jz 0x00007BC80C9CEAD0
00007bc80c9ce8b8  nop [rax+rax*1], ax
00007bc80c9ce8c1  nop [rax+rax*1], eax
00007bc80c9ce8c9  mov eax, 0x410070
00007bc80c9ce8ce  mov [r15+0x100], rax
00007bc80c9ce8d5  jmp 0x00007BC80C7FE110
00007bc80c9ce8da  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce8e2  jz 0x00007BC80C9CE910
00007bc80c9ce8e8  nop [rax+rax*1], ax
00007bc80c9ce8f1  nop [rax+rax*1], eax
00007bc80c9ce8f9  mov eax, 0x41006C
00007bc80c9ce8fe  mov [r15+0x100], rax
00007bc80c9ce905  jmp 0x00007BC80C7FE110
00007bc80c9ce90a  int3
00007bc80c9ce90b  int3
00007bc80c9ce90c  nop [rax], eax
00007bc80c9ce910  mov rax, [r15+0x10]
00007bc80c9ce914  lea r14, [rax+0x0B]
00007bc80c9ce918  mov [r15+0x10], r14
00007bc80c9ce91c  mov rax, [r15+0x08]
00007bc80c9ce920  mov [rsp+0x10], rax
00007bc80c9ce925  xor eax, eax
00007bc80c9ce927  mov r14, [rsp+0x10]
00007bc80c9ce92c  mov r12d, 0x01
00007bc80c9ce932  sub r14, r12
00007bc80c9ce935  cmc
00007bc80c9ce936  lahf
00007bc80c9ce937  seto al
00007bc80c9ce93a  mov [r15+0x108], eax
00007bc80c9ce941  mov [r15+0x08], r14
00007bc80c9ce945  mov eax, [r15+0x108]
00007bc80c9ce94c  sahf
00007bc80c9ce94d  jnz 0x00007BC80C9CE97F
00007bc80c9ce94f  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce957  jz 0x00007BC80C9CECB0
00007bc80c9ce95d  nop [rax+rax*1], ax
00007bc80c9ce966  nop [rax+rax*1], eax
00007bc80c9ce96e  mov eax, 0x410078
00007bc80c9ce973  mov [r15+0x100], rax
00007bc80c9ce97a  jmp 0x00007BC80C7FE110
00007bc80c9ce97f  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce987  jz 0x00007BC80C9CE9C0
00007bc80c9ce98d  nop [rax+rax*1], ax
00007bc80c9ce996  nop [rax+rax*1], eax
00007bc80c9ce99e  mov eax, 0x410040
00007bc80c9ce9a3  mov [r15+0x100], rax
00007bc80c9ce9aa  jmp 0x00007BC80C7FE110
00007bc80c9ce9af  int3
00007bc80c9ce9b0  int3
00007bc80c9ce9b1  nop [rax+rax*1], ax
00007bc80c9ce9ba  nop [rax+rax*1], ax
00007bc80c9ce9c0  mov rax, [r15]
00007bc80c9ce9c3  lea r14, [rax+0x01]
00007bc80c9ce9c7  mov [r15], r14
00007bc80c9ce9ca  xor eax, eax
00007bc80c9ce9cc  mov r12d, 0x07
00007bc80c9ce9d2  cmp r14, r12
00007bc80c9ce9d5  cmc
00007bc80c9ce9d6  lahf
00007bc80c9ce9d7  seto al
00007bc80c9ce9da  mov [r15+0x108], eax
00007bc80c9ce9e1  mov eax, [r15+0x108]
00007bc80c9ce9e8  sahf
00007bc80c9ce9e9  cmc
00007bc80c9ce9ea  jnbe 0x00007BC80C9CEA1C
00007bc80c9ce9ec  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ce9f4  jz 0x00007BC80C9CE750
00007bc80c9ce9fa  nop [rax+rax*1], ax
00007bc80c9cea03  nop [rax+rax*1], eax
00007bc80c9cea0b  mov eax, 0x41004C
00007bc80c9cea10  mov [r15+0x100], rax
00007bc80c9cea17  jmp 0x00007BC80C7FE110
00007bc80c9cea1c  cmp dword ptr [r15+0x318], 0x00
00007bc80c9cea24  jz 0x00007BC80C9CEC10
00007bc80c9cea2a  nop [rax+rax*1], ax
00007bc80c9cea33  nop [rax+rax*1], eax
00007bc80c9cea3b  mov eax, 0x410050
00007bc80c9cea40  mov [r15+0x100], rax
00007bc80c9cea47  jmp 0x00007BC80C7FE110
00007bc80c9cea4c  int3
00007bc80c9cea4d  int3
00007bc80c9cea4e  nop
00007bc80c9cea50  mov eax, [r15]
00007bc80c9cea53  mov eax, eax
00007bc80c9cea55  bt rax, 0x01
00007bc80c9cea5a  setb al
00007bc80c9cea5d  mov [rsp+0x414], al
00007bc80c9cea64  cmp byte ptr [rsp+0x414], 0x00
00007bc80c9cea6c  jz 0x00007BC80C9CEA9E
00007bc80c9cea6e  cmp dword ptr [r15+0x318], 0x00
00007bc80c9cea76  jz 0x00007BC80C9CEAD0
00007bc80c9cea7c  nop [rax+rax*1], ax
00007bc80c9cea85  nop [rax+rax*1], eax
00007bc80c9cea8d  mov eax, 0x410070
00007bc80c9cea92  mov [r15+0x100], rax
00007bc80c9cea99  jmp 0x00007BC80C7FE110
00007bc80c9cea9e  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ceaa6  jz 0x00007BC80C9CE910
00007bc80c9ceaac  nop [rax+rax*1], ax
00007bc80c9ceab5  nop [rax+rax*1], eax
00007bc80c9ceabd  mov eax, 0x41006C
00007bc80c9ceac2  mov [r15+0x100], rax
00007bc80c9ceac9  jmp 0x00007BC80C7FE110
00007bc80c9ceace  int3
00007bc80c9ceacf  int3
00007bc80c9cead0  mov rax, [r15+0x08]
00007bc80c9cead4  mov [rsp+0x10], rax
00007bc80c9cead9  xor eax, eax
00007bc80c9ceadb  mov r14, [rsp+0x10]
00007bc80c9ceae0  mov r12d, 0x01
00007bc80c9ceae6  sub r14, r12
00007bc80c9ceae9  cmc
00007bc80c9ceaea  lahf
00007bc80c9ceaeb  seto al
00007bc80c9ceaee  mov [r15+0x108], eax
00007bc80c9ceaf5  mov [r15+0x08], r14
00007bc80c9ceaf9  mov eax, [r15+0x108]
00007bc80c9ceb00  sahf
00007bc80c9ceb01  jnz 0x00007BC80C9CEB33
00007bc80c9ceb03  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ceb0b  jz 0x00007BC80C9CECB0
00007bc80c9ceb11  nop [rax+rax*1], ax
00007bc80c9ceb1a  nop [rax+rax*1], eax
00007bc80c9ceb22  mov eax, 0x410078
00007bc80c9ceb27  mov [r15+0x100], rax
00007bc80c9ceb2e  jmp 0x00007BC80C7FE110
00007bc80c9ceb33  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ceb3b  jz 0x00007BC80C9CE9C0
00007bc80c9ceb41  nop [rax+rax*1], ax
00007bc80c9ceb4a  nop [rax+rax*1], eax
00007bc80c9ceb52  mov eax, 0x410040
00007bc80c9ceb57  mov [r15+0x100], rax
00007bc80c9ceb5e  jmp 0x00007BC80C7FE110
00007bc80c9ceb63  int3
00007bc80c9ceb64  int3
00007bc80c9ceb65  nop [rax+rax*1], ax
00007bc80c9ceb6e  nop
00007bc80c9ceb70  mov rax, [r15+0x10]
00007bc80c9ceb74  lea r14, [rax+0x05]
00007bc80c9ceb78  mov [r15+0x10], r14
00007bc80c9ceb7c  mov rax, [r15]
00007bc80c9ceb7f  and rax, 0x01
00007bc80c9ceb83  mov [r15+0x18], rax
00007bc80c9ceb87  test rax, rax
00007bc80c9ceb8a  setz al
00007bc80c9ceb8d  movzx rax, al
00007bc80c9ceb91  mov [rsp+0x414], al
00007bc80c9ceb98  cmp byte ptr [rsp+0x414], 0x00
00007bc80c9ceba0  jz 0x00007BC80C9CEBD2
00007bc80c9ceba2  cmp dword ptr [r15+0x318], 0x00
00007bc80c9cebaa  jz 0x00007BC80C9CEA50
00007bc80c9cebb0  nop [rax+rax*1], ax
00007bc80c9cebb9  nop [rax+rax*1], eax
00007bc80c9cebc1  mov eax, 0x410068
00007bc80c9cebc6  mov [r15+0x100], rax
00007bc80c9cebcd  jmp 0x00007BC80C7FE110
00007bc80c9cebd2  cmp dword ptr [r15+0x318], 0x00
00007bc80c9cebda  jz 0x00007BC80C9CE880
00007bc80c9cebe0  nop [rax+rax*1], ax
00007bc80c9cebe9  nop [rax+rax*1], eax
00007bc80c9cebf1  mov eax, 0x410064
00007bc80c9cebf6  mov [r15+0x100], rax
00007bc80c9cebfd  jmp 0x00007BC80C7FE110
00007bc80c9cec02  int3
00007bc80c9cec03  int3
00007bc80c9cec04  nop [rax+rax*1], ax
00007bc80c9cec0d  nop [rax], eax
00007bc80c9cec10  mov rax, [r15]
00007bc80c9cec13  mov [rsp+0x10], rax
00007bc80c9cec18  xor eax, eax
00007bc80c9cec1a  mov r14, [rsp+0x10]
00007bc80c9cec1f  mov r12d, 0x05
00007bc80c9cec25  cmp r14, r12
00007bc80c9cec28  cmc
00007bc80c9cec29  lahf
00007bc80c9cec2a  seto al
00007bc80c9cec2d  mov [r15+0x108], eax
00007bc80c9cec34  mov eax, [r15+0x108]
00007bc80c9cec3b  cmp al, 0x81
00007bc80c9cec3d  sahf
00007bc80c9cec3e  jl 0x00007BC80C9CEC70
00007bc80c9cec40  cmp dword ptr [r15+0x318], 0x00
00007bc80c9cec48  jz 0x00007BC80C9CEB70
00007bc80c9cec4e  nop [rax+rax*1], ax
00007bc80c9cec57  nop [rax+rax*1], eax
00007bc80c9cec5f  mov eax, 0x410058
00007bc80c9cec64  mov [r15+0x100], rax
00007bc80c9cec6b  jmp 0x00007BC80C7FE110
00007bc80c9cec70  cmp dword ptr [r15+0x318], 0x00
00007bc80c9cec78  jz 0x00007BC80C9CE7F0
00007bc80c9cec7e  nop [rax+rax*1], ax
00007bc80c9cec87  nop [rax+rax*1], eax
00007bc80c9cec8f  mov eax, 0x41005C
00007bc80c9cec94  mov [r15+0x100], rax
00007bc80c9cec9b  jmp 0x00007BC80C7FE110
00007bc80c9ceca0  int3
00007bc80c9ceca1  int3
00007bc80c9ceca2  nop [rax+rax*1], ax
00007bc80c9cecab  nop [rax+rax*1], eax
00007bc80c9cecb0  mov rax, [r15+0x10]
00007bc80c9cecb4  mov [r15], rax
00007bc80c9cecb7  mov r14, [r15+0x20]
00007bc80c9cecbb  mov [r13+r14*1], rax
00007bc80c9cecc0  mov rax, [r15+0xF0]
00007bc80c9cecc7  mov [r15+0x100], rax
00007bc80c9cecce  jmp 0x00007BC80C9CE5C0
00007bc80c9cecd3  int3
00007bc80c9cecd4  call 0x00007BC80C8D5EB0
00007bc80c9cecd9  jmp 0x00007BC80C9CECC0
00007bc80c9cecde  int3
00007bc80c9cecdf  nop
00007bc80c9cece0  mov qword ptr [r15+0x100], 0x04
00007bc80c9ceceb  mov esi, 0x00
00007bc80c9cecf0  mov edx, 0x09
00007bc80c9cecf5  mov rdi, 0x7FFCFAB46D10
00007bc80c9cecff  mov rax, 0x6554A6A21970
00007bc80c9ced09  call rax
00007bc80c9ced0b  cmp dword ptr [r15+0x318], 0x00
00007bc80c9ced13  jnz 0x00007BC80C7FE110
00007bc80c9ced19  jmp 0x00007BC80C7FE0A0
00007bc80c9ced1e  int3
00007bc80c9ced1f  int3
