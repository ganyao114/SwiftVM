00007bb363bce69b  nop [rax+rax*1], eax
00007bb363bce6a0  mov qword ptr [r15+0x08], 0xB71B00
00007bb363bce6a8  mov qword ptr [r15+0x20], 0x420090
00007bb363bce6b0  mov qword ptr [r15+0x10], 0x00
00007bb363bce6b8  mov qword ptr [r15], 0x01
00007bb363bce6bf  xor eax, eax
00007bb363bce6c1  mov r14d, 0x01
00007bb363bce6c7  mov r12d, 0x07
00007bb363bce6cd  cmp r14, r12
00007bb363bce6d0  cmc
00007bb363bce6d1  lahf
00007bb363bce6d2  seto al
00007bb363bce6d5  mov [r15+0x108], eax
00007bb363bce6dc  mov eax, [r15+0x108]
00007bb363bce6e3  sahf
00007bb363bce6e4  cmc
00007bb363bce6e5  jnbe 0x00007BB363BCE717
00007bb363bce6e7  cmp dword ptr [r15+0x318], 0x00
00007bb363bce6ef  jz 0x00007BB363BCE750
00007bb363bce6f5  nop [rax+rax*1], ax
00007bb363bce6fe  nop [rax+rax*1], eax
00007bb363bce706  mov eax, 0x41004C
00007bb363bce70b  mov [r15+0x100], rax
00007bb363bce712  jmp 0x00007BB3639FE110
00007bb363bce717  cmp dword ptr [r15+0x318], 0x00
00007bb363bce71f  jz 0x00007BB363BCEC10
00007bb363bce725  nop [rax+rax*1], ax
00007bb363bce72e  nop [rax+rax*1], eax
00007bb363bce736  mov eax, 0x410050
00007bb363bce73b  mov [r15+0x100], rax
00007bb363bce742  jmp 0x00007BB3639FE110
00007bb363bce747  int3
00007bb363bce748  int3
00007bb363bce749  nop [rax], eax
00007bb363bce750  mov rax, [r15+0x10]
00007bb363bce754  lea r14, [rax+0x03]
00007bb363bce758  mov [r15+0x10], r14
00007bb363bce75c  mov rax, [r15]
00007bb363bce75f  mov [rsp+0x10], rax
00007bb363bce764  xor eax, eax
00007bb363bce766  mov r14, [rsp+0x10]
00007bb363bce76b  mov r12d, 0x05
00007bb363bce771  cmp r14, r12
00007bb363bce774  cmc
00007bb363bce775  lahf
00007bb363bce776  seto al
00007bb363bce779  mov [r15+0x108], eax
00007bb363bce780  mov eax, [r15+0x108]
00007bb363bce787  cmp al, 0x81
00007bb363bce789  sahf
00007bb363bce78a  jl 0x00007BB363BCE7BC
00007bb363bce78c  cmp dword ptr [r15+0x318], 0x00
00007bb363bce794  jz 0x00007BB363BCEB70
00007bb363bce79a  nop [rax+rax*1], ax
00007bb363bce7a3  nop [rax+rax*1], eax
00007bb363bce7ab  mov eax, 0x410058
00007bb363bce7b0  mov [r15+0x100], rax
00007bb363bce7b7  jmp 0x00007BB3639FE110
00007bb363bce7bc  cmp dword ptr [r15+0x318], 0x00
00007bb363bce7c4  jz 0x00007BB363BCE7F0
00007bb363bce7ca  nop [rax+rax*1], ax
00007bb363bce7d3  nop [rax+rax*1], eax
00007bb363bce7db  mov eax, 0x41005C
00007bb363bce7e0  mov [r15+0x100], rax
00007bb363bce7e7  jmp 0x00007BB3639FE110
00007bb363bce7ec  int3
00007bb363bce7ed  int3
00007bb363bce7ee  nop
00007bb363bce7f0  mov rax, [r15]
00007bb363bce7f3  and rax, 0x01
00007bb363bce7f7  mov [r15+0x18], rax
00007bb363bce7fb  test rax, rax
00007bb363bce7fe  setz al
00007bb363bce801  movzx rax, al
00007bb363bce805  mov [rsp+0x414], al
00007bb363bce80c  cmp byte ptr [rsp+0x414], 0x00
00007bb363bce814  jz 0x00007BB363BCE846
00007bb363bce816  cmp dword ptr [r15+0x318], 0x00
00007bb363bce81e  jz 0x00007BB363BCEA50
00007bb363bce824  nop [rax+rax*1], ax
00007bb363bce82d  nop [rax+rax*1], eax
00007bb363bce835  mov eax, 0x410068
00007bb363bce83a  mov [r15+0x100], rax
00007bb363bce841  jmp 0x00007BB3639FE110
00007bb363bce846  cmp dword ptr [r15+0x318], 0x00
00007bb363bce84e  jz 0x00007BB363BCE880
00007bb363bce854  nop [rax+rax*1], ax
00007bb363bce85d  nop [rax+rax*1], eax
00007bb363bce865  mov eax, 0x410064
00007bb363bce86a  mov [r15+0x100], rax
00007bb363bce871  jmp 0x00007BB3639FE110
00007bb363bce876  int3
00007bb363bce877  int3
00007bb363bce878  nop [rax+rax*1], eax
00007bb363bce880  mov rax, [r15+0x10]
00007bb363bce884  lea r14, [rax+0x07]
00007bb363bce888  mov [r15+0x10], r14
00007bb363bce88c  mov eax, [r15]
00007bb363bce88f  mov eax, eax
00007bb363bce891  bt rax, 0x01
00007bb363bce896  setb al
00007bb363bce899  mov [rsp+0x414], al
00007bb363bce8a0  cmp byte ptr [rsp+0x414], 0x00
00007bb363bce8a8  jz 0x00007BB363BCE8DA
00007bb363bce8aa  cmp dword ptr [r15+0x318], 0x00
00007bb363bce8b2  jz 0x00007BB363BCEAD0
00007bb363bce8b8  nop [rax+rax*1], ax
00007bb363bce8c1  nop [rax+rax*1], eax
00007bb363bce8c9  mov eax, 0x410070
00007bb363bce8ce  mov [r15+0x100], rax
00007bb363bce8d5  jmp 0x00007BB3639FE110
00007bb363bce8da  cmp dword ptr [r15+0x318], 0x00
00007bb363bce8e2  jz 0x00007BB363BCE910
00007bb363bce8e8  nop [rax+rax*1], ax
00007bb363bce8f1  nop [rax+rax*1], eax
00007bb363bce8f9  mov eax, 0x41006C
00007bb363bce8fe  mov [r15+0x100], rax
00007bb363bce905  jmp 0x00007BB3639FE110
00007bb363bce90a  int3
00007bb363bce90b  int3
00007bb363bce90c  nop [rax], eax
00007bb363bce910  mov rax, [r15+0x10]
00007bb363bce914  lea r14, [rax+0x0B]
00007bb363bce918  mov [r15+0x10], r14
00007bb363bce91c  mov rax, [r15+0x08]
00007bb363bce920  mov [rsp+0x10], rax
00007bb363bce925  xor eax, eax
00007bb363bce927  mov r14, [rsp+0x10]
00007bb363bce92c  mov r12d, 0x01
00007bb363bce932  sub r14, r12
00007bb363bce935  cmc
00007bb363bce936  lahf
00007bb363bce937  seto al
00007bb363bce93a  mov [r15+0x108], eax
00007bb363bce941  mov [r15+0x08], r14
00007bb363bce945  mov eax, [r15+0x108]
00007bb363bce94c  sahf
00007bb363bce94d  jnz 0x00007BB363BCE97F
00007bb363bce94f  cmp dword ptr [r15+0x318], 0x00
00007bb363bce957  jz 0x00007BB363BCECB0
00007bb363bce95d  nop [rax+rax*1], ax
00007bb363bce966  nop [rax+rax*1], eax
00007bb363bce96e  mov eax, 0x410078
00007bb363bce973  mov [r15+0x100], rax
00007bb363bce97a  jmp 0x00007BB3639FE110
00007bb363bce97f  cmp dword ptr [r15+0x318], 0x00
00007bb363bce987  jz 0x00007BB363BCE9C0
00007bb363bce98d  nop [rax+rax*1], ax
00007bb363bce996  nop [rax+rax*1], eax
00007bb363bce99e  mov eax, 0x410040
00007bb363bce9a3  mov [r15+0x100], rax
00007bb363bce9aa  jmp 0x00007BB3639FE110
00007bb363bce9af  int3
00007bb363bce9b0  int3
00007bb363bce9b1  nop [rax+rax*1], ax
00007bb363bce9ba  nop [rax+rax*1], ax
00007bb363bce9c0  mov rax, [r15]
00007bb363bce9c3  lea r14, [rax+0x01]
00007bb363bce9c7  mov [r15], r14
00007bb363bce9ca  xor eax, eax
00007bb363bce9cc  mov r12d, 0x07
00007bb363bce9d2  cmp r14, r12
00007bb363bce9d5  cmc
00007bb363bce9d6  lahf
00007bb363bce9d7  seto al
00007bb363bce9da  mov [r15+0x108], eax
00007bb363bce9e1  mov eax, [r15+0x108]
00007bb363bce9e8  sahf
00007bb363bce9e9  cmc
00007bb363bce9ea  jnbe 0x00007BB363BCEA1C
00007bb363bce9ec  cmp dword ptr [r15+0x318], 0x00
00007bb363bce9f4  jz 0x00007BB363BCE750
00007bb363bce9fa  nop [rax+rax*1], ax
00007bb363bcea03  nop [rax+rax*1], eax
00007bb363bcea0b  mov eax, 0x41004C
00007bb363bcea10  mov [r15+0x100], rax
00007bb363bcea17  jmp 0x00007BB3639FE110
00007bb363bcea1c  cmp dword ptr [r15+0x318], 0x00
00007bb363bcea24  jz 0x00007BB363BCEC10
00007bb363bcea2a  nop [rax+rax*1], ax
00007bb363bcea33  nop [rax+rax*1], eax
00007bb363bcea3b  mov eax, 0x410050
00007bb363bcea40  mov [r15+0x100], rax
00007bb363bcea47  jmp 0x00007BB3639FE110
00007bb363bcea4c  int3
00007bb363bcea4d  int3
00007bb363bcea4e  nop
00007bb363bcea50  mov eax, [r15]
00007bb363bcea53  mov eax, eax
00007bb363bcea55  bt rax, 0x01
00007bb363bcea5a  setb al
00007bb363bcea5d  mov [rsp+0x414], al
00007bb363bcea64  cmp byte ptr [rsp+0x414], 0x00
00007bb363bcea6c  jz 0x00007BB363BCEA9E
00007bb363bcea6e  cmp dword ptr [r15+0x318], 0x00
00007bb363bcea76  jz 0x00007BB363BCEAD0
00007bb363bcea7c  nop [rax+rax*1], ax
00007bb363bcea85  nop [rax+rax*1], eax
00007bb363bcea8d  mov eax, 0x410070
00007bb363bcea92  mov [r15+0x100], rax
00007bb363bcea99  jmp 0x00007BB3639FE110
00007bb363bcea9e  cmp dword ptr [r15+0x318], 0x00
00007bb363bceaa6  jz 0x00007BB363BCE910
00007bb363bceaac  nop [rax+rax*1], ax
00007bb363bceab5  nop [rax+rax*1], eax
00007bb363bceabd  mov eax, 0x41006C
00007bb363bceac2  mov [r15+0x100], rax
00007bb363bceac9  jmp 0x00007BB3639FE110
00007bb363bceace  int3
00007bb363bceacf  int3
00007bb363bcead0  mov rax, [r15+0x08]
00007bb363bcead4  mov [rsp+0x10], rax
00007bb363bcead9  xor eax, eax
00007bb363bceadb  mov r14, [rsp+0x10]
00007bb363bceae0  mov r12d, 0x01
00007bb363bceae6  sub r14, r12
00007bb363bceae9  cmc
00007bb363bceaea  lahf
00007bb363bceaeb  seto al
00007bb363bceaee  mov [r15+0x108], eax
00007bb363bceaf5  mov [r15+0x08], r14
00007bb363bceaf9  mov eax, [r15+0x108]
00007bb363bceb00  sahf
00007bb363bceb01  jnz 0x00007BB363BCEB33
00007bb363bceb03  cmp dword ptr [r15+0x318], 0x00
00007bb363bceb0b  jz 0x00007BB363BCECB0
00007bb363bceb11  nop [rax+rax*1], ax
00007bb363bceb1a  nop [rax+rax*1], eax
00007bb363bceb22  mov eax, 0x410078
00007bb363bceb27  mov [r15+0x100], rax
00007bb363bceb2e  jmp 0x00007BB3639FE110
00007bb363bceb33  cmp dword ptr [r15+0x318], 0x00
00007bb363bceb3b  jz 0x00007BB363BCE9C0
00007bb363bceb41  nop [rax+rax*1], ax
00007bb363bceb4a  nop [rax+rax*1], eax
00007bb363bceb52  mov eax, 0x410040
00007bb363bceb57  mov [r15+0x100], rax
00007bb363bceb5e  jmp 0x00007BB3639FE110
00007bb363bceb63  int3
00007bb363bceb64  int3
00007bb363bceb65  nop [rax+rax*1], ax
00007bb363bceb6e  nop
00007bb363bceb70  mov rax, [r15+0x10]
00007bb363bceb74  lea r14, [rax+0x05]
00007bb363bceb78  mov [r15+0x10], r14
00007bb363bceb7c  mov rax, [r15]
00007bb363bceb7f  and rax, 0x01
00007bb363bceb83  mov [r15+0x18], rax
00007bb363bceb87  test rax, rax
00007bb363bceb8a  setz al
00007bb363bceb8d  movzx rax, al
00007bb363bceb91  mov [rsp+0x414], al
00007bb363bceb98  cmp byte ptr [rsp+0x414], 0x00
00007bb363bceba0  jz 0x00007BB363BCEBD2
00007bb363bceba2  cmp dword ptr [r15+0x318], 0x00
00007bb363bcebaa  jz 0x00007BB363BCEA50
00007bb363bcebb0  nop [rax+rax*1], ax
00007bb363bcebb9  nop [rax+rax*1], eax
00007bb363bcebc1  mov eax, 0x410068
00007bb363bcebc6  mov [r15+0x100], rax
00007bb363bcebcd  jmp 0x00007BB3639FE110
00007bb363bcebd2  cmp dword ptr [r15+0x318], 0x00
00007bb363bcebda  jz 0x00007BB363BCE880
00007bb363bcebe0  nop [rax+rax*1], ax
00007bb363bcebe9  nop [rax+rax*1], eax
00007bb363bcebf1  mov eax, 0x410064
00007bb363bcebf6  mov [r15+0x100], rax
00007bb363bcebfd  jmp 0x00007BB3639FE110
00007bb363bcec02  int3
00007bb363bcec03  int3
00007bb363bcec04  nop [rax+rax*1], ax
00007bb363bcec0d  nop [rax], eax
00007bb363bcec10  mov rax, [r15]
00007bb363bcec13  mov [rsp+0x10], rax
00007bb363bcec18  xor eax, eax
00007bb363bcec1a  mov r14, [rsp+0x10]
00007bb363bcec1f  mov r12d, 0x05
00007bb363bcec25  cmp r14, r12
00007bb363bcec28  cmc
00007bb363bcec29  lahf
00007bb363bcec2a  seto al
00007bb363bcec2d  mov [r15+0x108], eax
00007bb363bcec34  mov eax, [r15+0x108]
00007bb363bcec3b  cmp al, 0x81
00007bb363bcec3d  sahf
00007bb363bcec3e  jl 0x00007BB363BCEC70
00007bb363bcec40  cmp dword ptr [r15+0x318], 0x00
00007bb363bcec48  jz 0x00007BB363BCEB70
00007bb363bcec4e  nop [rax+rax*1], ax
00007bb363bcec57  nop [rax+rax*1], eax
00007bb363bcec5f  mov eax, 0x410058
00007bb363bcec64  mov [r15+0x100], rax
00007bb363bcec6b  jmp 0x00007BB3639FE110
00007bb363bcec70  cmp dword ptr [r15+0x318], 0x00
00007bb363bcec78  jz 0x00007BB363BCE7F0
00007bb363bcec7e  nop [rax+rax*1], ax
00007bb363bcec87  nop [rax+rax*1], eax
00007bb363bcec8f  mov eax, 0x41005C
00007bb363bcec94  mov [r15+0x100], rax
00007bb363bcec9b  jmp 0x00007BB3639FE110
00007bb363bceca0  int3
00007bb363bceca1  int3
00007bb363bceca2  nop [rax+rax*1], ax
00007bb363bcecab  nop [rax+rax*1], eax
00007bb363bcecb0  mov rax, [r15+0x10]
00007bb363bcecb4  mov [r15], rax
00007bb363bcecb7  mov r14, [r15+0x20]
00007bb363bcecbb  mov [r13+r14*1], rax
00007bb363bcecc0  mov rax, [r15+0xF0]
00007bb363bcecc7  mov [r15+0x100], rax
00007bb363bcecce  jmp 0x00007BB363BCE5C0
00007bb363bcecd3  int3
00007bb363bcecd4  call 0x00007BB363AD5EB0
00007bb363bcecd9  jmp 0x00007BB363BCECC0
00007bb363bcecde  int3
00007bb363bcecdf  nop
00007bb363bcece0  mov qword ptr [r15+0x100], 0x04
00007bb363bceceb  mov esi, 0x00
00007bb363bcecf0  mov edx, 0x09
00007bb363bcecf5  mov rdi, 0x7FFE6431CFB0
00007bb363bcecff  mov rax, 0x5C10D592B970
00007bb363bced09  call rax
00007bb363bced0b  cmp dword ptr [r15+0x318], 0x00
00007bb363bced13  jnz 0x00007BB3639FE110
00007bb363bced19  jmp 0x00007BB3639FE0A0
00007bb363bced1e  int3
00007bb363bced1f  int3
