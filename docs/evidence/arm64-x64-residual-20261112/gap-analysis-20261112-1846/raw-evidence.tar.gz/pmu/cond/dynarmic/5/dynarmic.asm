00007bb6693ce69b  nop [rax+rax*1], eax
00007bb6693ce6a0  mov qword ptr [r15+0x08], 0xB71B00
00007bb6693ce6a8  mov qword ptr [r15+0x20], 0x420090
00007bb6693ce6b0  mov qword ptr [r15+0x10], 0x00
00007bb6693ce6b8  mov qword ptr [r15], 0x01
00007bb6693ce6bf  xor eax, eax
00007bb6693ce6c1  mov r14d, 0x01
00007bb6693ce6c7  mov r12d, 0x07
00007bb6693ce6cd  cmp r14, r12
00007bb6693ce6d0  cmc
00007bb6693ce6d1  lahf
00007bb6693ce6d2  seto al
00007bb6693ce6d5  mov [r15+0x108], eax
00007bb6693ce6dc  mov eax, [r15+0x108]
00007bb6693ce6e3  sahf
00007bb6693ce6e4  cmc
00007bb6693ce6e5  jnbe 0x00007BB6693CE717
00007bb6693ce6e7  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce6ef  jz 0x00007BB6693CE750
00007bb6693ce6f5  nop [rax+rax*1], ax
00007bb6693ce6fe  nop [rax+rax*1], eax
00007bb6693ce706  mov eax, 0x41004C
00007bb6693ce70b  mov [r15+0x100], rax
00007bb6693ce712  jmp 0x00007BB6691FE110
00007bb6693ce717  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce71f  jz 0x00007BB6693CEC10
00007bb6693ce725  nop [rax+rax*1], ax
00007bb6693ce72e  nop [rax+rax*1], eax
00007bb6693ce736  mov eax, 0x410050
00007bb6693ce73b  mov [r15+0x100], rax
00007bb6693ce742  jmp 0x00007BB6691FE110
00007bb6693ce747  int3
00007bb6693ce748  int3
00007bb6693ce749  nop [rax], eax
00007bb6693ce750  mov rax, [r15+0x10]
00007bb6693ce754  lea r14, [rax+0x03]
00007bb6693ce758  mov [r15+0x10], r14
00007bb6693ce75c  mov rax, [r15]
00007bb6693ce75f  mov [rsp+0x10], rax
00007bb6693ce764  xor eax, eax
00007bb6693ce766  mov r14, [rsp+0x10]
00007bb6693ce76b  mov r12d, 0x05
00007bb6693ce771  cmp r14, r12
00007bb6693ce774  cmc
00007bb6693ce775  lahf
00007bb6693ce776  seto al
00007bb6693ce779  mov [r15+0x108], eax
00007bb6693ce780  mov eax, [r15+0x108]
00007bb6693ce787  cmp al, 0x81
00007bb6693ce789  sahf
00007bb6693ce78a  jl 0x00007BB6693CE7BC
00007bb6693ce78c  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce794  jz 0x00007BB6693CEB70
00007bb6693ce79a  nop [rax+rax*1], ax
00007bb6693ce7a3  nop [rax+rax*1], eax
00007bb6693ce7ab  mov eax, 0x410058
00007bb6693ce7b0  mov [r15+0x100], rax
00007bb6693ce7b7  jmp 0x00007BB6691FE110
00007bb6693ce7bc  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce7c4  jz 0x00007BB6693CE7F0
00007bb6693ce7ca  nop [rax+rax*1], ax
00007bb6693ce7d3  nop [rax+rax*1], eax
00007bb6693ce7db  mov eax, 0x41005C
00007bb6693ce7e0  mov [r15+0x100], rax
00007bb6693ce7e7  jmp 0x00007BB6691FE110
00007bb6693ce7ec  int3
00007bb6693ce7ed  int3
00007bb6693ce7ee  nop
00007bb6693ce7f0  mov rax, [r15]
00007bb6693ce7f3  and rax, 0x01
00007bb6693ce7f7  mov [r15+0x18], rax
00007bb6693ce7fb  test rax, rax
00007bb6693ce7fe  setz al
00007bb6693ce801  movzx rax, al
00007bb6693ce805  mov [rsp+0x414], al
00007bb6693ce80c  cmp byte ptr [rsp+0x414], 0x00
00007bb6693ce814  jz 0x00007BB6693CE846
00007bb6693ce816  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce81e  jz 0x00007BB6693CEA50
00007bb6693ce824  nop [rax+rax*1], ax
00007bb6693ce82d  nop [rax+rax*1], eax
00007bb6693ce835  mov eax, 0x410068
00007bb6693ce83a  mov [r15+0x100], rax
00007bb6693ce841  jmp 0x00007BB6691FE110
00007bb6693ce846  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce84e  jz 0x00007BB6693CE880
00007bb6693ce854  nop [rax+rax*1], ax
00007bb6693ce85d  nop [rax+rax*1], eax
00007bb6693ce865  mov eax, 0x410064
00007bb6693ce86a  mov [r15+0x100], rax
00007bb6693ce871  jmp 0x00007BB6691FE110
00007bb6693ce876  int3
00007bb6693ce877  int3
00007bb6693ce878  nop [rax+rax*1], eax
00007bb6693ce880  mov rax, [r15+0x10]
00007bb6693ce884  lea r14, [rax+0x07]
00007bb6693ce888  mov [r15+0x10], r14
00007bb6693ce88c  mov eax, [r15]
00007bb6693ce88f  mov eax, eax
00007bb6693ce891  bt rax, 0x01
00007bb6693ce896  setb al
00007bb6693ce899  mov [rsp+0x414], al
00007bb6693ce8a0  cmp byte ptr [rsp+0x414], 0x00
00007bb6693ce8a8  jz 0x00007BB6693CE8DA
00007bb6693ce8aa  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce8b2  jz 0x00007BB6693CEAD0
00007bb6693ce8b8  nop [rax+rax*1], ax
00007bb6693ce8c1  nop [rax+rax*1], eax
00007bb6693ce8c9  mov eax, 0x410070
00007bb6693ce8ce  mov [r15+0x100], rax
00007bb6693ce8d5  jmp 0x00007BB6691FE110
00007bb6693ce8da  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce8e2  jz 0x00007BB6693CE910
00007bb6693ce8e8  nop [rax+rax*1], ax
00007bb6693ce8f1  nop [rax+rax*1], eax
00007bb6693ce8f9  mov eax, 0x41006C
00007bb6693ce8fe  mov [r15+0x100], rax
00007bb6693ce905  jmp 0x00007BB6691FE110
00007bb6693ce90a  int3
00007bb6693ce90b  int3
00007bb6693ce90c  nop [rax], eax
00007bb6693ce910  mov rax, [r15+0x10]
00007bb6693ce914  lea r14, [rax+0x0B]
00007bb6693ce918  mov [r15+0x10], r14
00007bb6693ce91c  mov rax, [r15+0x08]
00007bb6693ce920  mov [rsp+0x10], rax
00007bb6693ce925  xor eax, eax
00007bb6693ce927  mov r14, [rsp+0x10]
00007bb6693ce92c  mov r12d, 0x01
00007bb6693ce932  sub r14, r12
00007bb6693ce935  cmc
00007bb6693ce936  lahf
00007bb6693ce937  seto al
00007bb6693ce93a  mov [r15+0x108], eax
00007bb6693ce941  mov [r15+0x08], r14
00007bb6693ce945  mov eax, [r15+0x108]
00007bb6693ce94c  sahf
00007bb6693ce94d  jnz 0x00007BB6693CE97F
00007bb6693ce94f  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce957  jz 0x00007BB6693CECB0
00007bb6693ce95d  nop [rax+rax*1], ax
00007bb6693ce966  nop [rax+rax*1], eax
00007bb6693ce96e  mov eax, 0x410078
00007bb6693ce973  mov [r15+0x100], rax
00007bb6693ce97a  jmp 0x00007BB6691FE110
00007bb6693ce97f  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce987  jz 0x00007BB6693CE9C0
00007bb6693ce98d  nop [rax+rax*1], ax
00007bb6693ce996  nop [rax+rax*1], eax
00007bb6693ce99e  mov eax, 0x410040
00007bb6693ce9a3  mov [r15+0x100], rax
00007bb6693ce9aa  jmp 0x00007BB6691FE110
00007bb6693ce9af  int3
00007bb6693ce9b0  int3
00007bb6693ce9b1  nop [rax+rax*1], ax
00007bb6693ce9ba  nop [rax+rax*1], ax
00007bb6693ce9c0  mov rax, [r15]
00007bb6693ce9c3  lea r14, [rax+0x01]
00007bb6693ce9c7  mov [r15], r14
00007bb6693ce9ca  xor eax, eax
00007bb6693ce9cc  mov r12d, 0x07
00007bb6693ce9d2  cmp r14, r12
00007bb6693ce9d5  cmc
00007bb6693ce9d6  lahf
00007bb6693ce9d7  seto al
00007bb6693ce9da  mov [r15+0x108], eax
00007bb6693ce9e1  mov eax, [r15+0x108]
00007bb6693ce9e8  sahf
00007bb6693ce9e9  cmc
00007bb6693ce9ea  jnbe 0x00007BB6693CEA1C
00007bb6693ce9ec  cmp dword ptr [r15+0x318], 0x00
00007bb6693ce9f4  jz 0x00007BB6693CE750
00007bb6693ce9fa  nop [rax+rax*1], ax
00007bb6693cea03  nop [rax+rax*1], eax
00007bb6693cea0b  mov eax, 0x41004C
00007bb6693cea10  mov [r15+0x100], rax
00007bb6693cea17  jmp 0x00007BB6691FE110
00007bb6693cea1c  cmp dword ptr [r15+0x318], 0x00
00007bb6693cea24  jz 0x00007BB6693CEC10
00007bb6693cea2a  nop [rax+rax*1], ax
00007bb6693cea33  nop [rax+rax*1], eax
00007bb6693cea3b  mov eax, 0x410050
00007bb6693cea40  mov [r15+0x100], rax
00007bb6693cea47  jmp 0x00007BB6691FE110
00007bb6693cea4c  int3
00007bb6693cea4d  int3
00007bb6693cea4e  nop
00007bb6693cea50  mov eax, [r15]
00007bb6693cea53  mov eax, eax
00007bb6693cea55  bt rax, 0x01
00007bb6693cea5a  setb al
00007bb6693cea5d  mov [rsp+0x414], al
00007bb6693cea64  cmp byte ptr [rsp+0x414], 0x00
00007bb6693cea6c  jz 0x00007BB6693CEA9E
00007bb6693cea6e  cmp dword ptr [r15+0x318], 0x00
00007bb6693cea76  jz 0x00007BB6693CEAD0
00007bb6693cea7c  nop [rax+rax*1], ax
00007bb6693cea85  nop [rax+rax*1], eax
00007bb6693cea8d  mov eax, 0x410070
00007bb6693cea92  mov [r15+0x100], rax
00007bb6693cea99  jmp 0x00007BB6691FE110
00007bb6693cea9e  cmp dword ptr [r15+0x318], 0x00
00007bb6693ceaa6  jz 0x00007BB6693CE910
00007bb6693ceaac  nop [rax+rax*1], ax
00007bb6693ceab5  nop [rax+rax*1], eax
00007bb6693ceabd  mov eax, 0x41006C
00007bb6693ceac2  mov [r15+0x100], rax
00007bb6693ceac9  jmp 0x00007BB6691FE110
00007bb6693ceace  int3
00007bb6693ceacf  int3
00007bb6693cead0  mov rax, [r15+0x08]
00007bb6693cead4  mov [rsp+0x10], rax
00007bb6693cead9  xor eax, eax
00007bb6693ceadb  mov r14, [rsp+0x10]
00007bb6693ceae0  mov r12d, 0x01
00007bb6693ceae6  sub r14, r12
00007bb6693ceae9  cmc
00007bb6693ceaea  lahf
00007bb6693ceaeb  seto al
00007bb6693ceaee  mov [r15+0x108], eax
00007bb6693ceaf5  mov [r15+0x08], r14
00007bb6693ceaf9  mov eax, [r15+0x108]
00007bb6693ceb00  sahf
00007bb6693ceb01  jnz 0x00007BB6693CEB33
00007bb6693ceb03  cmp dword ptr [r15+0x318], 0x00
00007bb6693ceb0b  jz 0x00007BB6693CECB0
00007bb6693ceb11  nop [rax+rax*1], ax
00007bb6693ceb1a  nop [rax+rax*1], eax
00007bb6693ceb22  mov eax, 0x410078
00007bb6693ceb27  mov [r15+0x100], rax
00007bb6693ceb2e  jmp 0x00007BB6691FE110
00007bb6693ceb33  cmp dword ptr [r15+0x318], 0x00
00007bb6693ceb3b  jz 0x00007BB6693CE9C0
00007bb6693ceb41  nop [rax+rax*1], ax
00007bb6693ceb4a  nop [rax+rax*1], eax
00007bb6693ceb52  mov eax, 0x410040
00007bb6693ceb57  mov [r15+0x100], rax
00007bb6693ceb5e  jmp 0x00007BB6691FE110
00007bb6693ceb63  int3
00007bb6693ceb64  int3
00007bb6693ceb65  nop [rax+rax*1], ax
00007bb6693ceb6e  nop
00007bb6693ceb70  mov rax, [r15+0x10]
00007bb6693ceb74  lea r14, [rax+0x05]
00007bb6693ceb78  mov [r15+0x10], r14
00007bb6693ceb7c  mov rax, [r15]
00007bb6693ceb7f  and rax, 0x01
00007bb6693ceb83  mov [r15+0x18], rax
00007bb6693ceb87  test rax, rax
00007bb6693ceb8a  setz al
00007bb6693ceb8d  movzx rax, al
00007bb6693ceb91  mov [rsp+0x414], al
00007bb6693ceb98  cmp byte ptr [rsp+0x414], 0x00
00007bb6693ceba0  jz 0x00007BB6693CEBD2
00007bb6693ceba2  cmp dword ptr [r15+0x318], 0x00
00007bb6693cebaa  jz 0x00007BB6693CEA50
00007bb6693cebb0  nop [rax+rax*1], ax
00007bb6693cebb9  nop [rax+rax*1], eax
00007bb6693cebc1  mov eax, 0x410068
00007bb6693cebc6  mov [r15+0x100], rax
00007bb6693cebcd  jmp 0x00007BB6691FE110
00007bb6693cebd2  cmp dword ptr [r15+0x318], 0x00
00007bb6693cebda  jz 0x00007BB6693CE880
00007bb6693cebe0  nop [rax+rax*1], ax
00007bb6693cebe9  nop [rax+rax*1], eax
00007bb6693cebf1  mov eax, 0x410064
00007bb6693cebf6  mov [r15+0x100], rax
00007bb6693cebfd  jmp 0x00007BB6691FE110
00007bb6693cec02  int3
00007bb6693cec03  int3
00007bb6693cec04  nop [rax+rax*1], ax
00007bb6693cec0d  nop [rax], eax
00007bb6693cec10  mov rax, [r15]
00007bb6693cec13  mov [rsp+0x10], rax
00007bb6693cec18  xor eax, eax
00007bb6693cec1a  mov r14, [rsp+0x10]
00007bb6693cec1f  mov r12d, 0x05
00007bb6693cec25  cmp r14, r12
00007bb6693cec28  cmc
00007bb6693cec29  lahf
00007bb6693cec2a  seto al
00007bb6693cec2d  mov [r15+0x108], eax
00007bb6693cec34  mov eax, [r15+0x108]
00007bb6693cec3b  cmp al, 0x81
00007bb6693cec3d  sahf
00007bb6693cec3e  jl 0x00007BB6693CEC70
00007bb6693cec40  cmp dword ptr [r15+0x318], 0x00
00007bb6693cec48  jz 0x00007BB6693CEB70
00007bb6693cec4e  nop [rax+rax*1], ax
00007bb6693cec57  nop [rax+rax*1], eax
00007bb6693cec5f  mov eax, 0x410058
00007bb6693cec64  mov [r15+0x100], rax
00007bb6693cec6b  jmp 0x00007BB6691FE110
00007bb6693cec70  cmp dword ptr [r15+0x318], 0x00
00007bb6693cec78  jz 0x00007BB6693CE7F0
00007bb6693cec7e  nop [rax+rax*1], ax
00007bb6693cec87  nop [rax+rax*1], eax
00007bb6693cec8f  mov eax, 0x41005C
00007bb6693cec94  mov [r15+0x100], rax
00007bb6693cec9b  jmp 0x00007BB6691FE110
00007bb6693ceca0  int3
00007bb6693ceca1  int3
00007bb6693ceca2  nop [rax+rax*1], ax
00007bb6693cecab  nop [rax+rax*1], eax
00007bb6693cecb0  mov rax, [r15+0x10]
00007bb6693cecb4  mov [r15], rax
00007bb6693cecb7  mov r14, [r15+0x20]
00007bb6693cecbb  mov [r13+r14*1], rax
00007bb6693cecc0  mov rax, [r15+0xF0]
00007bb6693cecc7  mov [r15+0x100], rax
00007bb6693cecce  jmp 0x00007BB6693CE5C0
00007bb6693cecd3  int3
00007bb6693cecd4  call 0x00007BB6692D5EB0
00007bb6693cecd9  jmp 0x00007BB6693CECC0
00007bb6693cecde  int3
00007bb6693cecdf  nop
00007bb6693cece0  mov qword ptr [r15+0x100], 0x04
00007bb6693ceceb  mov esi, 0x00
00007bb6693cecf0  mov edx, 0x09
00007bb6693cecf5  mov rdi, 0x7FFC8050C5F0
00007bb6693cecff  mov rax, 0x62B0B0D64970
00007bb6693ced09  call rax
00007bb6693ced0b  cmp dword ptr [r15+0x318], 0x00
00007bb6693ced13  jnz 0x00007BB6691FE110
00007bb6693ced19  jmp 0x00007BB6691FE0A0
00007bb6693ced1e  int3
00007bb6693ced1f  int3
