
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/pmu/cond/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,0x1b00
   a:	mov    r14d,0xb7
  10:	and    r14d,0xffff
  17:	mov    rax,r13
  1a:	movabs rcx,0xffffffff0000ffff
  24:	and    rax,rcx
  27:	mov    rdx,r14
  2a:	shl    rdx,0x10
  2e:	mov    ecx,0xffff0000
  33:	and    rdx,rcx
  36:	or     rax,rdx
  39:	mov    r15,rax
  3c:	mov    QWORD PTR [r12+0x8],r15
  41:	mov    r13d,0x420090
  47:	mov    QWORD PTR [r12+0x20],r13
  4c:	mov    r13d,0x0
  52:	mov    QWORD PTR [r12],r13
  56:	mov    r13d,0x0
  5c:	mov    QWORD PTR [r12+0x10],r13
  61:	jmp    0x66
  66:	mov    r13,QWORD PTR [r12]
  6a:	add    r13,0x1
  6e:	mov    QWORD PTR [r12],r13
  72:	mov    rdx,rbx
  75:	shr    rdx,0x10
  79:	and    edx,0xc000
  7f:	mov    rax,rbx
  82:	shr    rax,0x15
  86:	and    eax,0x100
  8b:	xor    eax,0x100
  90:	or     edx,eax
  92:	mov    rax,rbx
  95:	shr    rax,0x1c
  99:	and    eax,0x1
  9c:	or     edx,eax
  9e:	mov    QWORD PTR [rsp],rdx
  a2:	sub    r13,0x7
  a6:	pushf
  a7:	pop    rdx
  a8:	xor    edx,0x1
  ab:	mov    r11d,edx
  ae:	shl    edx,0x8
  b1:	and    edx,0xc100
  b7:	shr    r11d,0xb
  bb:	and    r11d,0x1
  bf:	or     edx,r11d
  c2:	and    edx,0x4100
  c8:	mov    r11,QWORD PTR [rsp]
  cc:	and    r11,0xffffffffffffbeff
  d3:	or     r11,rdx
  d6:	mov    QWORD PTR [rsp],r11
  da:	mov    r11,rax
  dd:	movzx  eax,WORD PTR [rsp]
  e1:	add    al,0x7f
  e3:	sahf
  e4:	mov    rax,r11
  e7:	cmc
  e8:	ja     0x106
  ee:	jmp    0xf3
  f3:	mov    r13,QWORD PTR [r12+0x10]
  f8:	add    r13,0x3
  fc:	mov    QWORD PTR [r12+0x10],r13
 101:	jmp    0x106
 106:	mov    r13,QWORD PTR [r12]
 10a:	mov    rdx,rbx
 10d:	shr    rdx,0x10
 111:	and    edx,0xc000
 117:	mov    rax,rbx
 11a:	shr    rax,0x15
 11e:	and    eax,0x100
 123:	xor    eax,0x100
 128:	or     edx,eax
 12a:	mov    rax,rbx
 12d:	shr    rax,0x1c
 131:	and    eax,0x1
 134:	or     edx,eax
 136:	mov    QWORD PTR [rsp],rdx
 13a:	sub    r13,0x5
 13e:	pushf
 13f:	pop    rdx
 140:	mov    r11d,edx
 143:	shl    edx,0x8
 146:	and    edx,0xc100
 14c:	shr    r11d,0xb
 150:	and    r11d,0x1
 154:	or     edx,r11d
 157:	and    edx,0x8001
 15d:	mov    r11,QWORD PTR [rsp]
 161:	and    r11,0xffffffffffff7ffe
 168:	or     r11,rdx
 16b:	mov    QWORD PTR [rsp],r11
 16f:	mov    r11,rax
 172:	movzx  eax,WORD PTR [rsp]
 176:	add    al,0x7f
 178:	sahf
 179:	mov    rax,r11
 17c:	jl     0x19a
 182:	jmp    0x187
 187:	mov    r13,QWORD PTR [r12+0x10]
 18c:	add    r13,0x5
 190:	mov    QWORD PTR [r12+0x10],r13
 195:	jmp    0x19a
 19a:	mov    r13,QWORD PTR [r12]
 19e:	and    r13,0x1
 1a2:	mov    QWORD PTR [r12+0x18],r13
 1a7:	mov    rax,r13
 1aa:	test   rax,rax
 1ad:	je     0x1cb
 1b3:	jmp    0x1b8
 1b8:	mov    r13,QWORD PTR [r12+0x10]
 1bd:	add    r13,0x7
 1c1:	mov    QWORD PTR [r12+0x10],r13
 1c6:	jmp    0x1cb
 1cb:	mov    r13,QWORD PTR [r12]
 1cf:	mov    rax,r13
 1d2:	bt     rax,0x1
 1d7:	jb     0x1f5
 1dd:	jmp    0x1e2
 1e2:	mov    r13,QWORD PTR [r12+0x10]
 1e7:	add    r13,0xb
 1eb:	mov    QWORD PTR [r12+0x10],r13
 1f0:	jmp    0x1f5
 1f5:	mov    r13,QWORD PTR [r12+0x8]
 1fa:	sub    r13,0x1
 1fe:	mov    QWORD PTR [r12+0x8],r13
 203:	mov    rcx,QWORD PTR [r12+0x380]
 20b:	jrcxz  0x212
 20d:	jmp    0x297
 212:	jne    0x66
 218:	mov    r11,rax
 21b:	lahf
 21c:	seto   al
 21f:	mov    WORD PTR [rsp],ax
 223:	mov    rax,r11
 226:	jmp    0x22b
 22b:	mov    r13d,0x0
 231:	mov    r14,QWORD PTR [r12+0x10]
 236:	or     r13,r14
 239:	mov    QWORD PTR [r12],r13
 23d:	mov    r14,QWORD PTR [r12+0x20]
 242:	mov    QWORD PTR [r14],r13
 245:	mov    r13d,0x0
 24b:	mov    DWORD PTR [r12+0x32c],r13d
 253:	mov    rcx,QWORD PTR [r12+0x380]
 25b:	jrcxz  0x262
 25d:	jmp    0x328
 262:	mov    r13,QWORD PTR [r12+0xf0]
 26a:	mov    QWORD PTR [r12+0x100],r13
 272:	mov    r11,QWORD PTR [rsp]
 276:	mov    QWORD PTR [r12+0x398],r11
 27e:	mov    rdi,QWORD PTR [r12+0x100]
 286:	add    rsp,0x10
 28a:	movabs r11,0x600de9448940
 294:	jmp    r11
 297:	mov    eax,0x410074
 29c:	mov    QWORD PTR [r12+0x100],rax
 2a4:	push   rdx
 2a5:	push   rsi
 2a6:	push   r10
 2a8:	push   r11
 2aa:	mov    r11,rax
 2ad:	lahf
 2ae:	seto   al
 2b1:	mov    WORD PTR [rsp+0x20],ax
 2b6:	mov    rax,r11
 2b9:	mov    rdx,QWORD PTR [rsp+0x20]
 2be:	mov    r10d,edx
 2c1:	and    r10d,0xc000
 2c8:	shl    r10d,0x10
 2cc:	mov    r11d,edx
 2cf:	and    r11d,0x100
 2d6:	shl    r11d,0x15
 2da:	or     r10d,r11d
 2dd:	and    edx,0x1
 2e0:	shl    edx,0x1c
 2e3:	or     r10d,edx
 2e6:	btc    r10,0x1d
 2eb:	mov    r11d,0xf0000000
 2f1:	and    r11,r10
 2f4:	movabs rsi,0xffffffff0fffffff
 2fe:	and    rbx,rsi
 301:	or     rbx,r11
 304:	pop    r11
 306:	pop    r10
 308:	pop    rsi
 309:	pop    rdx
 30a:	mov    QWORD PTR [r12+0x108],rbx
 312:	add    rsp,0x10
 316:	mov    eax,0xc
 31b:	movabs r11,0x600de9448ca0
 325:	jmp    r11
 328:	mov    eax,0x410080
 32d:	mov    QWORD PTR [r12+0x100],rax
 335:	push   rdx
 336:	push   rsi
 337:	push   r10
 339:	push   r11
 33b:	mov    rdx,QWORD PTR [rsp+0x20]
 340:	mov    r10d,edx
 343:	and    r10d,0xc000
 34a:	shl    r10d,0x10
 34e:	mov    r11d,edx
 351:	and    r11d,0x100
 358:	shl    r11d,0x15
 35c:	or     r10d,r11d
 35f:	and    edx,0x1
 362:	shl    edx,0x1c
 365:	or     r10d,edx
 368:	btc    r10,0x1d
 36d:	mov    r11d,0xf0000000
 373:	and    r11,r10
 376:	movabs rsi,0xffffffff0fffffff
 380:	and    rbx,rsi
 383:	or     rbx,r11
 386:	pop    r11
 388:	pop    r10
 38a:	pop    rsi
 38b:	pop    rdx
 38c:	mov    QWORD PTR [r12+0x108],rbx
 394:	add    rsp,0x10
 398:	mov    eax,0xc
 39d:	movabs r11,0x600de9448ca0
 3a7:	jmp    r11
 3aa:	nop    WORD PTR [rax+rax*1+0x0]
 3b0:	sub    rsp,0x10
 3b4:	jmp    0x66
 3b9:	nop    DWORD PTR [rax+0x0]
 3c0:	sub    rsp,0x10
 3c4:	jmp    0xf3
 3c9:	nop    DWORD PTR [rax+0x0]
 3d0:	sub    rsp,0x10
 3d4:	jmp    0x106
 3d9:	nop    DWORD PTR [rax+0x0]
 3e0:	sub    rsp,0x10
 3e4:	jmp    0x187
 3e9:	nop    DWORD PTR [rax+0x0]
 3f0:	sub    rsp,0x10
 3f4:	jmp    0x19a
 3f9:	nop    DWORD PTR [rax+0x0]
 400:	sub    rsp,0x10
 404:	jmp    0x1b8
 409:	nop    DWORD PTR [rax+0x0]
 410:	sub    rsp,0x10
 414:	jmp    0x1cb
 419:	nop    DWORD PTR [rax+0x0]
 420:	sub    rsp,0x10
 424:	jmp    0x1e2
 429:	nop    DWORD PTR [rax+0x0]
 430:	sub    rsp,0x10
 434:	jmp    0x1f5
 439:	nop    DWORD PTR [rax+0x0]
 440:	sub    rsp,0x10
 444:	mov    r11,QWORD PTR [r12+0x398]
 44c:	mov    QWORD PTR [rsp],r11
 450:	jmp    0x22b
 455:	nop
 456:	nop
 457:	nop
