00007ec5e11ce69b  nop [rax+rax*1], eax
00007ec5e11ce6a0  mov qword ptr [r15+0x40], 0x4201C0
00007ec5e11ce6a8  mov qword ptr [r15+0x48], 0x4203C0
00007ec5e11ce6b0  mov qword ptr [r15+0x60], 0x01
00007ec5e11ce6b8  xorps xmm1, xmm1
00007ec5e11ce6bb  mov eax, 0x41
00007ec5e11ce6c0  vcvtusi2sd xmm1, xmm1, eax
00007ec5e11ce6c6  mulsd xmm1, [0x00007EC5E0DFE010]
00007ec5e11ce6ce  movq xmm1, xmm1
00007ec5e11ce6d2  movaps [r15+0x120], xmm1
00007ec5e11ce6da  mov eax, [r15+0x60]
00007ec5e11ce6de  xorps xmm15, xmm15
00007ec5e11ce6e2  vcvtusi2sd xmm15, xmm15, eax
00007ec5e11ce6e8  mulsd xmm15, [0x00007EC5E0DFE020]
00007ec5e11ce6f1  movq xmm15, xmm15
00007ec5e11ce6f6  movaps [r15+0x110], xmm15
00007ec5e11ce6fe  mov rax, [r15+0x60]
00007ec5e11ce702  mov [rsp+0x10], rax
00007ec5e11ce707  xor eax, eax
00007ec5e11ce709  mov r14, [rsp+0x10]
00007ec5e11ce70e  mov r12d, 0x40
00007ec5e11ce714  cmp r14, r12
00007ec5e11ce717  cmc
00007ec5e11ce718  lahf
00007ec5e11ce719  seto al
00007ec5e11ce71c  mov [r15+0x108], eax
00007ec5e11ce723  mov qword ptr [r15+0x50], 0x40
00007ec5e11ce72b  movq rax, xmm1
00007ec5e11ce730  mov r12d, 0x4203C0
00007ec5e11ce736  mov [r13+r12*1], rax
00007ec5e11ce73b  movq rax, xmm15
00007ec5e11ce740  mov r12d, 0x4201C0
00007ec5e11ce746  mov [r13+r12*1], rax
00007ec5e11ce74b  mov [r15+0x58], r14
00007ec5e11ce74f  mov eax, [r15+0x108]
00007ec5e11ce756  sahf
00007ec5e11ce757  jnz 0x00007EC5E11CE789
00007ec5e11ce759  cmp dword ptr [r15+0x318], 0x00
00007ec5e11ce761  jz 0x00007EC5E11CE910
00007ec5e11ce767  nop [rax+rax*1], ax
00007ec5e11ce770  nop [rax+rax*1], eax
00007ec5e11ce778  mov eax, 0x410074
00007ec5e11ce77d  mov [r15+0x100], rax
00007ec5e11ce784  jmp 0x00007EC5E0FFE110
00007ec5e11ce789  cmp dword ptr [r15+0x318], 0x00
00007ec5e11ce791  jz 0x00007EC5E11CE7D0
00007ec5e11ce797  nop [rax+rax*1], ax
00007ec5e11ce7a0  nop [rax+rax*1], eax
00007ec5e11ce7a8  mov eax, 0x41004C
00007ec5e11ce7ad  mov [r15+0x100], rax
00007ec5e11ce7b4  jmp 0x00007EC5E0FFE110
00007ec5e11ce7b9  int3
00007ec5e11ce7ba  call 0x00007EC5E10B4CB0
00007ec5e11ce7bf  jmp 0x00007EC5E11CE73B
00007ec5e11ce7c4  call 0x00007EC5E10B4CB0
00007ec5e11ce7c9  jmp 0x00007EC5E11CE74B
00007ec5e11ce7ce  int3
00007ec5e11ce7cf  nop
00007ec5e11ce7d0  mov rax, [r15+0x58]
00007ec5e11ce7d4  lea r14, [rax+0x01]
00007ec5e11ce7d8  mov [r15+0x60], r14
00007ec5e11ce7dc  mov r14d, [r15+0x50]
00007ec5e11ce7e0  xorps xmm1, xmm1
00007ec5e11ce7e3  vcvtusi2sd xmm1, xmm1, r14d
00007ec5e11ce7e9  mulsd xmm1, [0x00007EC5E0DFE010]
00007ec5e11ce7f1  movq xmm1, xmm1
00007ec5e11ce7f5  movaps [r15+0x120], xmm1
00007ec5e11ce7fd  rorx r12, rax, 0x3D
00007ec5e11ce803  and r12, 0xFFFFFFFFFFFFFFF8
00007ec5e11ce807  mov eax, [r15+0x60]
00007ec5e11ce80b  xorps xmm15, xmm15
00007ec5e11ce80f  vcvtusi2sd xmm15, xmm15, eax
00007ec5e11ce815  mulsd xmm15, [0x00007EC5E0DFE020]
00007ec5e11ce81e  movq xmm15, xmm15
00007ec5e11ce823  movaps [r15+0x110], xmm15
00007ec5e11ce82b  mov rax, [r15+0x60]
00007ec5e11ce82f  mov [rsp+0x10], rax
00007ec5e11ce834  xor eax, eax
00007ec5e11ce836  mov r11, [rsp+0x10]
00007ec5e11ce83b  mov r10d, 0x40
00007ec5e11ce841  cmp r11, r10
00007ec5e11ce844  cmc
00007ec5e11ce845  lahf
00007ec5e11ce846  seto al
00007ec5e11ce849  mov [r15+0x108], eax
00007ec5e11ce850  lea eax, [r14d-0x01]
00007ec5e11ce855  mov eax, eax
00007ec5e11ce857  mov [r15+0x50], rax
00007ec5e11ce85b  mov rax, [r15+0x48]
00007ec5e11ce85f  lea r14, [rax+r12*1]
00007ec5e11ce863  movq rax, xmm1
00007ec5e11ce868  mov [r13+r14*1], rax
00007ec5e11ce86d  mov rax, [r15+0x40]
00007ec5e11ce871  lea r14, [rax+r12*1]
00007ec5e11ce875  movq rax, xmm15
00007ec5e11ce87a  mov [r13+r14*1], rax
00007ec5e11ce87f  mov [r15+0x58], r11
00007ec5e11ce883  mov eax, [r15+0x108]
00007ec5e11ce88a  sahf
00007ec5e11ce88b  jnz 0x00007EC5E11CE8BD
00007ec5e11ce88d  cmp dword ptr [r15+0x318], 0x00
00007ec5e11ce895  jz 0x00007EC5E11CE910
00007ec5e11ce89b  nop [rax+rax*1], ax
00007ec5e11ce8a4  nop [rax+rax*1], eax
00007ec5e11ce8ac  mov eax, 0x410074
00007ec5e11ce8b1  mov [r15+0x100], rax
00007ec5e11ce8b8  jmp 0x00007EC5E0FFE110
00007ec5e11ce8bd  cmp dword ptr [r15+0x318], 0x00
00007ec5e11ce8c5  jz 0x00007EC5E11CE7D0
00007ec5e11ce8cb  nop [rax+rax*1], ax
00007ec5e11ce8d4  nop [rax+rax*1], eax
00007ec5e11ce8dc  mov eax, 0x41004C
00007ec5e11ce8e1  mov [r15+0x100], rax
00007ec5e11ce8e8  jmp 0x00007EC5E0FFE110
00007ec5e11ce8ed  int3
00007ec5e11ce8ee  call 0x00007EC5E10D5EB0
00007ec5e11ce8f3  jmp 0x00007EC5E11CE86D
00007ec5e11ce8f8  call 0x00007EC5E10D5EB0
00007ec5e11ce8fd  jmp 0x00007EC5E11CE87F
00007ec5e11ce902  int3
00007ec5e11ce903  nop [rax+rax*1], ax
00007ec5e11ce90c  nop [rax], eax
00007ec5e11ce910  vxorps xmm1, xmm1, xmm1
00007ec5e11ce914  movq xmm1, xmm1
00007ec5e11ce918  movaps [r15+0x110], xmm1
00007ec5e11ce920  mov qword ptr [r15+0x58], 0x00
00007ec5e11ce928  mov qword ptr [r15+0x50], 0x4205C0
00007ec5e11ce930  mov qword ptr [r15+0x60], 0x00
00007ec5e11ce938  mov qword ptr [r15+0x68], 0x4205C0
00007ec5e11ce940  mov rax, [r15+0x40]
00007ec5e11ce944  mov r14, [r13+rax*1]
00007ec5e11ce949  lea r12, [rax+0x08]
00007ec5e11ce94d  mov r11, [r13+r12*1]
00007ec5e11ce952  movq xmm15, r14
00007ec5e11ce957  movq xmm14, r11
00007ec5e11ce95c  movq xmm15, xmm15
00007ec5e11ce961  movq xmm15, xmm15
00007ec5e11ce966  movaps [r15+0x120], xmm15
00007ec5e11ce96e  movq xmm14, xmm14
00007ec5e11ce973  movq xmm14, xmm14
00007ec5e11ce978  movaps [r15+0x130], xmm14
00007ec5e11ce980  lea r14, [rax+0x10]
00007ec5e11ce984  mov r12, [r13+r14*1]
00007ec5e11ce989  lea r14, [rax+0x18]
00007ec5e11ce98d  mov r11, [r13+r14*1]
00007ec5e11ce992  movq xmm15, r12
00007ec5e11ce997  movq xmm14, r11
00007ec5e11ce99c  movq xmm15, xmm15
00007ec5e11ce9a1  movq xmm15, xmm15
00007ec5e11ce9a6  movaps [r15+0x140], xmm15
00007ec5e11ce9ae  movq xmm14, xmm14
00007ec5e11ce9b3  movq xmm14, xmm14
00007ec5e11ce9b8  movaps [r15+0x150], xmm14
00007ec5e11ce9c0  lea r14, [rax+0x20]
00007ec5e11ce9c4  mov r12, [r13+r14*1]
00007ec5e11ce9c9  lea r14, [rax+0x28]
00007ec5e11ce9cd  mov r11, [r13+r14*1]
00007ec5e11ce9d2  movq xmm15, r12
00007ec5e11ce9d7  movq xmm14, r11
00007ec5e11ce9dc  movq xmm15, xmm15
00007ec5e11ce9e1  movq xmm15, xmm15
00007ec5e11ce9e6  movaps [r15+0x160], xmm15
00007ec5e11ce9ee  movq xmm14, xmm14
00007ec5e11ce9f3  movq xmm14, xmm14
00007ec5e11ce9f8  movaps [r15+0x170], xmm14
00007ec5e11cea00  lea r14, [rax+0x30]
00007ec5e11cea04  mov r12, [r13+r14*1]
00007ec5e11cea09  lea r14, [rax+0x38]
00007ec5e11cea0d  mov rax, [r13+r14*1]
00007ec5e11cea12  movq xmm15, r12
00007ec5e11cea17  movq xmm14, rax
00007ec5e11cea1c  movq xmm15, xmm15
00007ec5e11cea21  movq xmm15, xmm15
00007ec5e11cea26  movaps [r15+0x180], xmm15
00007ec5e11cea2e  movq xmm14, xmm14
00007ec5e11cea33  movq xmm14, xmm14
00007ec5e11cea38  movaps [r15+0x210], xmm14
00007ec5e11cea40  mov rax, [r15+0x48]
00007ec5e11cea44  mov [r15+0x78], rax
00007ec5e11cea48  mov r14, [r13+rax*1]
00007ec5e11cea4d  movq xmm15, r14
00007ec5e11cea52  lea r14, [rax+0x40]
00007ec5e11cea56  mov r12, [r13+r14*1]
00007ec5e11cea5b  movq xmm14, r12
00007ec5e11cea60  lea r14, [rax+0x80]
00007ec5e11cea67  mov r12, [r13+r14*1]
00007ec5e11cea6c  movq xmm13, r12
00007ec5e11cea71  movaps xmm12, [r15+0x120]
00007ec5e11cea79  movq r14, xmm12
00007ec5e11cea7e  movq r12, xmm15
00007ec5e11cea83  vmovq xmm15, r14
00007ec5e11cea88  vmovq xmm12, r12
00007ec5e11cea8d  movaps xmm11, xmm15
00007ec5e11cea91  mulsd xmm11, xmm12
00007ec5e11cea96  ucomisd xmm11, xmm11
00007ec5e11cea9b  jp 0x00007EC5E11CEEFC
00007ec5e11ceaa1  movq xmm11, xmm11
00007ec5e11ceaa6  movaps xmm15, [r15+0x130]
00007ec5e11ceaae  movq r14, xmm15
00007ec5e11ceab3  movq r12, xmm14
00007ec5e11ceab8  vmovq xmm15, r14
00007ec5e11ceabd  vmovq xmm14, r12
00007ec5e11ceac2  movaps xmm12, xmm15
00007ec5e11ceac6  mulsd xmm12, xmm14
00007ec5e11ceacb  ucomisd xmm12, xmm12
00007ec5e11cead0  jp 0x00007EC5E11CEF48
00007ec5e11cead6  movq xmm12, xmm12
00007ec5e11ceadb  movq r14, xmm11
00007ec5e11ceae0  movq r12, xmm1
00007ec5e11ceae5  vmovq xmm1, r14
00007ec5e11ceaea  vmovq xmm15, r12
00007ec5e11ceaef  movaps xmm14, xmm1
00007ec5e11ceaf3  addsd xmm14, xmm15
00007ec5e11ceaf8  ucomisd xmm14, xmm14
00007ec5e11ceafd  jp 0x00007EC5E11CEF94
00007ec5e11ceb03  movq xmm14, xmm14
00007ec5e11ceb08  movq r14, xmm14
00007ec5e11ceb0d  movq r12, xmm12
00007ec5e11ceb12  vmovq xmm1, r14
00007ec5e11ceb17  vmovq xmm15, r12
00007ec5e11ceb1c  movaps xmm14, xmm1
00007ec5e11ceb20  addsd xmm14, xmm15
00007ec5e11ceb25  ucomisd xmm14, xmm14
00007ec5e11ceb2a  jp 0x00007EC5E11CEFE0
00007ec5e11ceb30  movq xmm14, xmm14
00007ec5e11ceb35  movaps xmm1, [r15+0x140]
00007ec5e11ceb3d  movq r14, xmm1
00007ec5e11ceb42  movq r12, xmm13
00007ec5e11ceb47  vmovq xmm1, r14
00007ec5e11ceb4c  vmovq xmm15, r12
00007ec5e11ceb51  movaps xmm13, xmm1
00007ec5e11ceb55  mulsd xmm13, xmm15
00007ec5e11ceb5a  ucomisd xmm13, xmm13
00007ec5e11ceb5f  jp 0x00007EC5E11CF02C
00007ec5e11ceb65  movq xmm13, xmm13
00007ec5e11ceb6a  lea r14, [rax+0xC0]
00007ec5e11ceb71  mov r12, [r13+r14*1]
00007ec5e11ceb76  movq xmm1, r12
00007ec5e11ceb7b  movq r14, xmm14
00007ec5e11ceb80  movq r12, xmm13
00007ec5e11ceb85  vmovq xmm15, r14
00007ec5e11ceb8a  vmovq xmm14, r12
00007ec5e11ceb8f  movaps xmm13, xmm15
00007ec5e11ceb93  addsd xmm13, xmm14
00007ec5e11ceb98  ucomisd xmm13, xmm13
00007ec5e11ceb9d  jp 0x00007EC5E11CF082
00007ec5e11ceba3  movq xmm13, xmm13
00007ec5e11ceba8  movaps xmm15, [r15+0x150]
00007ec5e11cebb0  movq r14, xmm15
00007ec5e11cebb5  movq r12, xmm1
00007ec5e11cebba  vmovq xmm1, r14
00007ec5e11cebbf  vmovq xmm15, r12
00007ec5e11cebc4  movaps xmm14, xmm1
00007ec5e11cebc8  mulsd xmm14, xmm15
00007ec5e11cebcd  ucomisd xmm14, xmm14
00007ec5e11cebd2  jp 0x00007EC5E11CF0CE
00007ec5e11cebd8  movq xmm14, xmm14
00007ec5e11cebdd  lea r14, [rax+0x100]
00007ec5e11cebe4  mov r12, [r13+r14*1]
00007ec5e11cebe9  movq xmm1, r12
00007ec5e11cebee  movq r14, xmm13
00007ec5e11cebf3  movq r12, xmm14
00007ec5e11cebf8  vmovq xmm15, r14
00007ec5e11cebfd  vmovq xmm14, r12
00007ec5e11cec02  movaps xmm13, xmm15
00007ec5e11cec06  addsd xmm13, xmm14
00007ec5e11cec0b  ucomisd xmm13, xmm13
00007ec5e11cec10  jp 0x00007EC5E11CF124
00007ec5e11cec16  movq xmm13, xmm13
00007ec5e11cec1b  movaps xmm15, [r15+0x160]
00007ec5e11cec23  movq r14, xmm15
00007ec5e11cec28  movq r12, xmm1
00007ec5e11cec2d  vmovq xmm1, r14
00007ec5e11cec32  vmovq xmm15, r12
00007ec5e11cec37  movaps xmm14, xmm1
00007ec5e11cec3b  mulsd xmm14, xmm15
00007ec5e11cec40  ucomisd xmm14, xmm14
00007ec5e11cec45  jp 0x00007EC5E11CF170
00007ec5e11cec4b  movq xmm14, xmm14
00007ec5e11cec50  lea r14, [rax+0x140]
00007ec5e11cec57  mov r12, [r13+r14*1]
00007ec5e11cec5c  movq xmm1, r12
00007ec5e11cec61  movq r14, xmm13
00007ec5e11cec66  movq r12, xmm14
00007ec5e11cec6b  vmovq xmm15, r14
00007ec5e11cec70  vmovq xmm14, r12
00007ec5e11cec75  movaps xmm13, xmm15
00007ec5e11cec79  addsd xmm13, xmm14
00007ec5e11cec7e  ucomisd xmm13, xmm13
00007ec5e11cec83  jp 0x00007EC5E11CF1C6
00007ec5e11cec89  movq xmm13, xmm13
00007ec5e11cec8e  movaps xmm15, [r15+0x170]
00007ec5e11cec96  movq r14, xmm15
00007ec5e11cec9b  movq r12, xmm1
00007ec5e11ceca0  vmovq xmm1, r14
00007ec5e11ceca5  vmovq xmm15, r12
00007ec5e11cecaa  movaps xmm14, xmm1
00007ec5e11cecae  mulsd xmm14, xmm15
00007ec5e11cecb3  ucomisd xmm14, xmm14
00007ec5e11cecb8  jp 0x00007EC5E11CF212
00007ec5e11cecbe  movq xmm14, xmm14
00007ec5e11cecc3  lea r14, [rax+0x180]
00007ec5e11cecca  mov r12, [r13+r14*1]
00007ec5e11ceccf  movq xmm1, r12
00007ec5e11cecd4  movq r14, xmm13
00007ec5e11cecd9  movq r12, xmm14
00007ec5e11cecde  vmovq xmm15, r14
00007ec5e11cece3  vmovq xmm14, r12
00007ec5e11cece8  movaps xmm13, xmm15
00007ec5e11cecec  addsd xmm13, xmm14
00007ec5e11cecf1  ucomisd xmm13, xmm13
00007ec5e11cecf6  jp 0x00007EC5E11CF268
00007ec5e11cecfc  movq xmm13, xmm13
00007ec5e11ced01  movaps xmm15, [r15+0x180]
00007ec5e11ced09  movq r14, xmm15
00007ec5e11ced0e  movq r12, xmm1
00007ec5e11ced13  vmovq xmm1, r14
00007ec5e11ced18  vmovq xmm15, r12
00007ec5e11ced1d  movaps xmm14, xmm1
00007ec5e11ced21  mulsd xmm14, xmm15
00007ec5e11ced26  ucomisd xmm14, xmm14
00007ec5e11ced2b  jp 0x00007EC5E11CF2B4
00007ec5e11ced31  movq xmm14, xmm14
00007ec5e11ced36  lea r14, [rax+0x1C0]
00007ec5e11ced3d  mov rax, [r13+r14*1]
00007ec5e11ced42  movq xmm1, rax
00007ec5e11ced47  movaps [r15+0x240], xmm1
00007ec5e11ced4f  movq rax, xmm13
00007ec5e11ced54  movq r14, xmm14
00007ec5e11ced59  vmovq xmm15, rax
00007ec5e11ced5e  vmovq xmm14, r14
00007ec5e11ced63  movaps xmm13, xmm15
00007ec5e11ced67  addsd xmm13, xmm14
00007ec5e11ced6c  ucomisd xmm13, xmm13
00007ec5e11ced71  jp 0x00007EC5E11CF30A
00007ec5e11ced77  movq xmm13, xmm13
00007ec5e11ced7c  movaps xmm15, [r15+0x210]
00007ec5e11ced84  movq rax, xmm15
00007ec5e11ced89  movq r14, xmm1
00007ec5e11ced8e  vmovq xmm1, rax
00007ec5e11ced93  vmovq xmm15, r14
00007ec5e11ced98  movaps xmm14, xmm1
00007ec5e11ced9c  mulsd xmm14, xmm15
00007ec5e11ceda1  ucomisd xmm14, xmm14
00007ec5e11ceda6  jp 0x00007EC5E11CF352
00007ec5e11cedac  movq xmm14, xmm14
00007ec5e11cedb1  movaps [r15+0x230], xmm14
00007ec5e11cedb9  movq rax, xmm13
00007ec5e11cedbe  movq r14, xmm14
00007ec5e11cedc3  vmovq xmm1, rax
00007ec5e11cedc8  vmovq xmm15, r14
00007ec5e11cedcd  movaps xmm14, xmm1
00007ec5e11cedd1  addsd xmm14, xmm15
00007ec5e11cedd6  ucomisd xmm14, xmm14
00007ec5e11ceddb  jp 0x00007EC5E11CF39A
00007ec5e11cede1  movq xmm14, xmm14
00007ec5e11cede6  movaps [r15+0x220], xmm14
00007ec5e11cedee  movq rax, xmm14
00007ec5e11cedf3  mov r14d, 0x4205C0
00007ec5e11cedf9  mov [r13+r14*1], rax
00007ec5e11cedfe  mov qword ptr [r15+0x70], 0x08
00007ec5e11cee06  xor eax, eax
00007ec5e11cee08  mov r14d, 0x08
00007ec5e11cee0e  mov r12d, 0x40
00007ec5e11cee14  cmp r14, r12
00007ec5e11cee17  cmc
00007ec5e11cee18  lahf
00007ec5e11cee19  seto al
00007ec5e11cee1c  mov [r15+0x108], eax
00007ec5e11cee23  mov eax, [r15+0x108]
00007ec5e11cee2a  sahf
00007ec5e11cee2b  jnz 0x00007EC5E11CEE5D
00007ec5e11cee2d  cmp dword ptr [r15+0x318], 0x00
00007ec5e11cee35  jz 0x00007EC5E11CFD40
00007ec5e11cee3b  nop [rax+rax*1], ax
00007ec5e11cee44  nop [rax+rax*1], eax
00007ec5e11cee4c  mov eax, 0x410118
00007ec5e11cee51  mov [r15+0x100], rax
00007ec5e11cee58  jmp 0x00007EC5E0FFE110
00007ec5e11cee5d  cmp dword ptr [r15+0x318], 0x00
00007ec5e11cee65  jz 0x00007EC5E11CF3F0
00007ec5e11cee6b  nop [rax+rax*1], ax
00007ec5e11cee74  nop [rax+rax*1], eax
00007ec5e11cee7c  mov eax, 0x4100A4
00007ec5e11cee81  mov [r15+0x100], rax
00007ec5e11cee88  jmp 0x00007EC5E0FFE110
00007ec5e11cee8d  int3
00007ec5e11cee8e  call 0x00007EC5E100DC20
00007ec5e11cee93  jmp 0x00007EC5E11CE949
00007ec5e11cee98  call 0x00007EC5E10C0370
00007ec5e11cee9d  jmp 0x00007EC5E11CE952
00007ec5e11ceea2  call 0x00007EC5E10E27E0
00007ec5e11ceea7  jmp 0x00007EC5E11CE989
00007ec5e11ceeac  call 0x00007EC5E10E1570
00007ec5e11ceeb1  jmp 0x00007EC5E11CE992
00007ec5e11ceeb6  call 0x00007EC5E10E27E0
00007ec5e11ceebb  jmp 0x00007EC5E11CE9C9
00007ec5e11ceec0  call 0x00007EC5E10E1570
00007ec5e11ceec5  jmp 0x00007EC5E11CE9D2
00007ec5e11ceeca  call 0x00007EC5E10E27E0
00007ec5e11ceecf  jmp 0x00007EC5E11CEA09
00007ec5e11ceed4  call 0x00007EC5E10D59C0
00007ec5e11ceed9  jmp 0x00007EC5E11CEA12
00007ec5e11ceede  call 0x00007EC5E100DC20
00007ec5e11ceee3  jmp 0x00007EC5E11CEA4D
00007ec5e11ceee8  call 0x00007EC5E10E27E0
00007ec5e11ceeed  jmp 0x00007EC5E11CEA5B
00007ec5e11ceef2  call 0x00007EC5E10E27E0
00007ec5e11ceef7  jmp 0x00007EC5E11CEA6C
00007ec5e11ceefc  ucomisd xmm15, xmm12
00007ec5e11cef01  jp 0x00007EC5E11CEF10
00007ec5e11cef03  movaps xmm11, [0x00007EC5E0DFE030]
00007ec5e11cef0b  jmp 0x00007EC5E11CEAA1
00007ec5e11cef10  vxorps xmm0, xmm15, xmm12
00007ec5e11cef15  pextrw r14d, xmm0, 0x03
00007ec5e11cef1b  and r14d, 0x7FF8
00007ec5e11cef22  cmp r14d, 0x08
00007ec5e11cef26  jnz 0x00007EC5E11CEAA1
00007ec5e11cef2c  movq r14, xmm12
00007ec5e11cef31  shl r14, 0x0D
00007ec5e11cef35  jbe 0x00007EC5E11CEAA1
00007ec5e11cef3b  vorps xmm11, xmm12, [0x00007EC5E0DFE040]
00007ec5e11cef43  jmp 0x00007EC5E11CEAA1
00007ec5e11cef48  ucomisd xmm15, xmm14
00007ec5e11cef4d  jp 0x00007EC5E11CEF5C
00007ec5e11cef4f  movaps xmm12, [0x00007EC5E0DFE030]
00007ec5e11cef57  jmp 0x00007EC5E11CEAD6
00007ec5e11cef5c  vxorps xmm0, xmm15, xmm14
00007ec5e11cef61  pextrw r14d, xmm0, 0x03
00007ec5e11cef67  and r14d, 0x7FF8
00007ec5e11cef6e  cmp r14d, 0x08
00007ec5e11cef72  jnz 0x00007EC5E11CEAD6
00007ec5e11cef78  movq r14, xmm14
00007ec5e11cef7d  shl r14, 0x0D
00007ec5e11cef81  jbe 0x00007EC5E11CEAD6
00007ec5e11cef87  vorps xmm12, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cef8f  jmp 0x00007EC5E11CEAD6
00007ec5e11cef94  ucomisd xmm1, xmm15
00007ec5e11cef99  jp 0x00007EC5E11CEFA8
00007ec5e11cef9b  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cefa3  jmp 0x00007EC5E11CEB03
00007ec5e11cefa8  vxorps xmm0, xmm1, xmm15
00007ec5e11cefad  pextrw r14d, xmm0, 0x03
00007ec5e11cefb3  and r14d, 0x7FF8
00007ec5e11cefba  cmp r14d, 0x08
00007ec5e11cefbe  jnz 0x00007EC5E11CEB03
00007ec5e11cefc4  movq r14, xmm15
00007ec5e11cefc9  shl r14, 0x0D
00007ec5e11cefcd  jbe 0x00007EC5E11CEB03
00007ec5e11cefd3  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cefdb  jmp 0x00007EC5E11CEB03
00007ec5e11cefe0  ucomisd xmm1, xmm15
00007ec5e11cefe5  jp 0x00007EC5E11CEFF4
00007ec5e11cefe7  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cefef  jmp 0x00007EC5E11CEB30
00007ec5e11ceff4  vxorps xmm0, xmm1, xmm15
00007ec5e11ceff9  pextrw r14d, xmm0, 0x03
00007ec5e11cefff  and r14d, 0x7FF8
00007ec5e11cf006  cmp r14d, 0x08
00007ec5e11cf00a  jnz 0x00007EC5E11CEB30
00007ec5e11cf010  movq r14, xmm15
00007ec5e11cf015  shl r14, 0x0D
00007ec5e11cf019  jbe 0x00007EC5E11CEB30
00007ec5e11cf01f  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf027  jmp 0x00007EC5E11CEB30
00007ec5e11cf02c  ucomisd xmm1, xmm15
00007ec5e11cf031  jp 0x00007EC5E11CF040
00007ec5e11cf033  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf03b  jmp 0x00007EC5E11CEB65
00007ec5e11cf040  vxorps xmm0, xmm1, xmm15
00007ec5e11cf045  pextrw r14d, xmm0, 0x03
00007ec5e11cf04b  and r14d, 0x7FF8
00007ec5e11cf052  cmp r14d, 0x08
00007ec5e11cf056  jnz 0x00007EC5E11CEB65
00007ec5e11cf05c  movq r14, xmm15
00007ec5e11cf061  shl r14, 0x0D
00007ec5e11cf065  jbe 0x00007EC5E11CEB65
00007ec5e11cf06b  vorps xmm13, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf073  jmp 0x00007EC5E11CEB65
00007ec5e11cf078  call 0x00007EC5E10E27E0
00007ec5e11cf07d  jmp 0x00007EC5E11CEB76
00007ec5e11cf082  ucomisd xmm15, xmm14
00007ec5e11cf087  jp 0x00007EC5E11CF096
00007ec5e11cf089  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf091  jmp 0x00007EC5E11CEBA3
00007ec5e11cf096  vxorps xmm0, xmm15, xmm14
00007ec5e11cf09b  pextrw r14d, xmm0, 0x03
00007ec5e11cf0a1  and r14d, 0x7FF8
00007ec5e11cf0a8  cmp r14d, 0x08
00007ec5e11cf0ac  jnz 0x00007EC5E11CEBA3
00007ec5e11cf0b2  movq r14, xmm14
00007ec5e11cf0b7  shl r14, 0x0D
00007ec5e11cf0bb  jbe 0x00007EC5E11CEBA3
00007ec5e11cf0c1  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cf0c9  jmp 0x00007EC5E11CEBA3
00007ec5e11cf0ce  ucomisd xmm1, xmm15
00007ec5e11cf0d3  jp 0x00007EC5E11CF0E2
00007ec5e11cf0d5  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cf0dd  jmp 0x00007EC5E11CEBD8
00007ec5e11cf0e2  vxorps xmm0, xmm1, xmm15
00007ec5e11cf0e7  pextrw r14d, xmm0, 0x03
00007ec5e11cf0ed  and r14d, 0x7FF8
00007ec5e11cf0f4  cmp r14d, 0x08
00007ec5e11cf0f8  jnz 0x00007EC5E11CEBD8
00007ec5e11cf0fe  movq r14, xmm15
00007ec5e11cf103  shl r14, 0x0D
00007ec5e11cf107  jbe 0x00007EC5E11CEBD8
00007ec5e11cf10d  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf115  jmp 0x00007EC5E11CEBD8
00007ec5e11cf11a  call 0x00007EC5E10E27E0
00007ec5e11cf11f  jmp 0x00007EC5E11CEBE9
00007ec5e11cf124  ucomisd xmm15, xmm14
00007ec5e11cf129  jp 0x00007EC5E11CF138
00007ec5e11cf12b  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf133  jmp 0x00007EC5E11CEC16
00007ec5e11cf138  vxorps xmm0, xmm15, xmm14
00007ec5e11cf13d  pextrw r14d, xmm0, 0x03
00007ec5e11cf143  and r14d, 0x7FF8
00007ec5e11cf14a  cmp r14d, 0x08
00007ec5e11cf14e  jnz 0x00007EC5E11CEC16
00007ec5e11cf154  movq r14, xmm14
00007ec5e11cf159  shl r14, 0x0D
00007ec5e11cf15d  jbe 0x00007EC5E11CEC16
00007ec5e11cf163  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cf16b  jmp 0x00007EC5E11CEC16
00007ec5e11cf170  ucomisd xmm1, xmm15
00007ec5e11cf175  jp 0x00007EC5E11CF184
00007ec5e11cf177  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cf17f  jmp 0x00007EC5E11CEC4B
00007ec5e11cf184  vxorps xmm0, xmm1, xmm15
00007ec5e11cf189  pextrw r14d, xmm0, 0x03
00007ec5e11cf18f  and r14d, 0x7FF8
00007ec5e11cf196  cmp r14d, 0x08
00007ec5e11cf19a  jnz 0x00007EC5E11CEC4B
00007ec5e11cf1a0  movq r14, xmm15
00007ec5e11cf1a5  shl r14, 0x0D
00007ec5e11cf1a9  jbe 0x00007EC5E11CEC4B
00007ec5e11cf1af  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf1b7  jmp 0x00007EC5E11CEC4B
00007ec5e11cf1bc  call 0x00007EC5E10E27E0
00007ec5e11cf1c1  jmp 0x00007EC5E11CEC5C
00007ec5e11cf1c6  ucomisd xmm15, xmm14
00007ec5e11cf1cb  jp 0x00007EC5E11CF1DA
00007ec5e11cf1cd  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf1d5  jmp 0x00007EC5E11CEC89
00007ec5e11cf1da  vxorps xmm0, xmm15, xmm14
00007ec5e11cf1df  pextrw r14d, xmm0, 0x03
00007ec5e11cf1e5  and r14d, 0x7FF8
00007ec5e11cf1ec  cmp r14d, 0x08
00007ec5e11cf1f0  jnz 0x00007EC5E11CEC89
00007ec5e11cf1f6  movq r14, xmm14
00007ec5e11cf1fb  shl r14, 0x0D
00007ec5e11cf1ff  jbe 0x00007EC5E11CEC89
00007ec5e11cf205  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cf20d  jmp 0x00007EC5E11CEC89
00007ec5e11cf212  ucomisd xmm1, xmm15
00007ec5e11cf217  jp 0x00007EC5E11CF226
00007ec5e11cf219  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cf221  jmp 0x00007EC5E11CECBE
00007ec5e11cf226  vxorps xmm0, xmm1, xmm15
00007ec5e11cf22b  pextrw r14d, xmm0, 0x03
00007ec5e11cf231  and r14d, 0x7FF8
00007ec5e11cf238  cmp r14d, 0x08
00007ec5e11cf23c  jnz 0x00007EC5E11CECBE
00007ec5e11cf242  movq r14, xmm15
00007ec5e11cf247  shl r14, 0x0D
00007ec5e11cf24b  jbe 0x00007EC5E11CECBE
00007ec5e11cf251  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf259  jmp 0x00007EC5E11CECBE
00007ec5e11cf25e  call 0x00007EC5E10E27E0
00007ec5e11cf263  jmp 0x00007EC5E11CECCF
00007ec5e11cf268  ucomisd xmm15, xmm14
00007ec5e11cf26d  jp 0x00007EC5E11CF27C
00007ec5e11cf26f  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf277  jmp 0x00007EC5E11CECFC
00007ec5e11cf27c  vxorps xmm0, xmm15, xmm14
00007ec5e11cf281  pextrw r14d, xmm0, 0x03
00007ec5e11cf287  and r14d, 0x7FF8
00007ec5e11cf28e  cmp r14d, 0x08
00007ec5e11cf292  jnz 0x00007EC5E11CECFC
00007ec5e11cf298  movq r14, xmm14
00007ec5e11cf29d  shl r14, 0x0D
00007ec5e11cf2a1  jbe 0x00007EC5E11CECFC
00007ec5e11cf2a7  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cf2af  jmp 0x00007EC5E11CECFC
00007ec5e11cf2b4  ucomisd xmm1, xmm15
00007ec5e11cf2b9  jp 0x00007EC5E11CF2C8
00007ec5e11cf2bb  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cf2c3  jmp 0x00007EC5E11CED31
00007ec5e11cf2c8  vxorps xmm0, xmm1, xmm15
00007ec5e11cf2cd  pextrw r14d, xmm0, 0x03
00007ec5e11cf2d3  and r14d, 0x7FF8
00007ec5e11cf2da  cmp r14d, 0x08
00007ec5e11cf2de  jnz 0x00007EC5E11CED31
00007ec5e11cf2e4  movq r14, xmm15
00007ec5e11cf2e9  shl r14, 0x0D
00007ec5e11cf2ed  jbe 0x00007EC5E11CED31
00007ec5e11cf2f3  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf2fb  jmp 0x00007EC5E11CED31
00007ec5e11cf300  call 0x00007EC5E10D59C0
00007ec5e11cf305  jmp 0x00007EC5E11CED42
00007ec5e11cf30a  ucomisd xmm15, xmm14
00007ec5e11cf30f  jp 0x00007EC5E11CF31E
00007ec5e11cf311  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf319  jmp 0x00007EC5E11CED77
00007ec5e11cf31e  vxorps xmm0, xmm15, xmm14
00007ec5e11cf323  pextrw eax, xmm0, 0x03
00007ec5e11cf328  and eax, 0x7FF8
00007ec5e11cf32d  cmp eax, 0x08
00007ec5e11cf330  jnz 0x00007EC5E11CED77
00007ec5e11cf336  movq rax, xmm14
00007ec5e11cf33b  shl rax, 0x0D
00007ec5e11cf33f  jbe 0x00007EC5E11CED77
00007ec5e11cf345  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cf34d  jmp 0x00007EC5E11CED77
00007ec5e11cf352  ucomisd xmm1, xmm15
00007ec5e11cf357  jp 0x00007EC5E11CF366
00007ec5e11cf359  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cf361  jmp 0x00007EC5E11CEDAC
00007ec5e11cf366  vxorps xmm0, xmm1, xmm15
00007ec5e11cf36b  pextrw eax, xmm0, 0x03
00007ec5e11cf370  and eax, 0x7FF8
00007ec5e11cf375  cmp eax, 0x08
00007ec5e11cf378  jnz 0x00007EC5E11CEDAC
00007ec5e11cf37e  movq rax, xmm15
00007ec5e11cf383  shl rax, 0x0D
00007ec5e11cf387  jbe 0x00007EC5E11CEDAC
00007ec5e11cf38d  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf395  jmp 0x00007EC5E11CEDAC
00007ec5e11cf39a  ucomisd xmm1, xmm15
00007ec5e11cf39f  jp 0x00007EC5E11CF3AE
00007ec5e11cf3a1  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cf3a9  jmp 0x00007EC5E11CEDE1
00007ec5e11cf3ae  vxorps xmm0, xmm1, xmm15
00007ec5e11cf3b3  pextrw eax, xmm0, 0x03
00007ec5e11cf3b8  and eax, 0x7FF8
00007ec5e11cf3bd  cmp eax, 0x08
00007ec5e11cf3c0  jnz 0x00007EC5E11CEDE1
00007ec5e11cf3c6  movq rax, xmm15
00007ec5e11cf3cb  shl rax, 0x0D
00007ec5e11cf3cf  jbe 0x00007EC5E11CEDE1
00007ec5e11cf3d5  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf3dd  jmp 0x00007EC5E11CEDE1
00007ec5e11cf3e2  call 0x00007EC5E10D5EB0
00007ec5e11cf3e7  jmp 0x00007EC5E11CEDFE
00007ec5e11cf3ec  int3
00007ec5e11cf3ed  nop [rax], eax
00007ec5e11cf3f0  mov rax, [r15+0x48]
00007ec5e11cf3f4  mov r14, [r15+0x70]
00007ec5e11cf3f8  lea r12, [rax+r14*1]
00007ec5e11cf3fc  mov [r15+0x78], r12
00007ec5e11cf400  mov rax, [r13+r12*1]
00007ec5e11cf405  movq xmm1, rax
00007ec5e11cf40a  lea rax, [r12+0x40]
00007ec5e11cf40f  mov r11, [r13+rax*1]
00007ec5e11cf414  movq xmm15, r11
00007ec5e11cf419  lea rax, [r12+0x80]
00007ec5e11cf421  mov r11, [r13+rax*1]
00007ec5e11cf426  movq xmm14, r11
00007ec5e11cf42b  movaps xmm13, [r15+0x120]
00007ec5e11cf433  movq rax, xmm13
00007ec5e11cf438  movq r11, xmm1
00007ec5e11cf43d  vmovq xmm1, rax
00007ec5e11cf442  vmovq xmm13, r11
00007ec5e11cf447  movaps xmm12, xmm1
00007ec5e11cf44b  mulsd xmm12, xmm13
00007ec5e11cf450  ucomisd xmm12, xmm12
00007ec5e11cf455  jp 0x00007EC5E11CF879
00007ec5e11cf45b  movq xmm12, xmm12
00007ec5e11cf460  movaps xmm1, [r15+0x130]
00007ec5e11cf468  movq rax, xmm1
00007ec5e11cf46d  movq r11, xmm15
00007ec5e11cf472  vmovq xmm1, rax
00007ec5e11cf477  vmovq xmm15, r11
00007ec5e11cf47c  movaps xmm13, xmm1
00007ec5e11cf480  mulsd xmm13, xmm15
00007ec5e11cf485  ucomisd xmm13, xmm13
00007ec5e11cf48a  jp 0x00007EC5E11CF8C1
00007ec5e11cf490  movq xmm13, xmm13
00007ec5e11cf495  movq rax, xmm12
00007ec5e11cf49a  movaps xmm1, [r15+0x110]
00007ec5e11cf4a2  movq r11, xmm1
00007ec5e11cf4a7  vmovq xmm1, rax
00007ec5e11cf4ac  vmovq xmm15, r11
00007ec5e11cf4b1  movaps xmm12, xmm1
00007ec5e11cf4b5  addsd xmm12, xmm15
00007ec5e11cf4ba  ucomisd xmm12, xmm12
00007ec5e11cf4bf  jp 0x00007EC5E11CF909
00007ec5e11cf4c5  movq xmm12, xmm12
00007ec5e11cf4ca  movq rax, xmm12
00007ec5e11cf4cf  movq r11, xmm13
00007ec5e11cf4d4  vmovq xmm1, rax
00007ec5e11cf4d9  vmovq xmm15, r11
00007ec5e11cf4de  movaps xmm13, xmm1
00007ec5e11cf4e2  addsd xmm13, xmm15
00007ec5e11cf4e7  ucomisd xmm13, xmm13
00007ec5e11cf4ec  jp 0x00007EC5E11CF951
00007ec5e11cf4f2  movq xmm13, xmm13
00007ec5e11cf4f7  movaps xmm1, [r15+0x140]
00007ec5e11cf4ff  movq rax, xmm1
00007ec5e11cf504  movq r11, xmm14
00007ec5e11cf509  vmovq xmm1, rax
00007ec5e11cf50e  vmovq xmm15, r11
00007ec5e11cf513  movaps xmm14, xmm1
00007ec5e11cf517  mulsd xmm14, xmm15
00007ec5e11cf51c  ucomisd xmm14, xmm14
00007ec5e11cf521  jp 0x00007EC5E11CF999
00007ec5e11cf527  movq xmm14, xmm14
00007ec5e11cf52c  lea rax, [r12+0xC0]
00007ec5e11cf534  mov r11, [r13+rax*1]
00007ec5e11cf539  movq xmm1, r11
00007ec5e11cf53e  movq rax, xmm13
00007ec5e11cf543  movq r11, xmm14
00007ec5e11cf548  vmovq xmm15, rax
00007ec5e11cf54d  vmovq xmm14, r11
00007ec5e11cf552  movaps xmm13, xmm15
00007ec5e11cf556  addsd xmm13, xmm14
00007ec5e11cf55b  ucomisd xmm13, xmm13
00007ec5e11cf560  jp 0x00007EC5E11CF9EB
00007ec5e11cf566  movq xmm13, xmm13
00007ec5e11cf56b  movaps xmm15, [r15+0x150]
00007ec5e11cf573  movq rax, xmm15
00007ec5e11cf578  movq r11, xmm1
00007ec5e11cf57d  vmovq xmm1, rax
00007ec5e11cf582  vmovq xmm15, r11
00007ec5e11cf587  movaps xmm14, xmm1
00007ec5e11cf58b  mulsd xmm14, xmm15
00007ec5e11cf590  ucomisd xmm14, xmm14
00007ec5e11cf595  jp 0x00007EC5E11CFA33
00007ec5e11cf59b  movq xmm14, xmm14
00007ec5e11cf5a0  lea rax, [r12+0x100]
00007ec5e11cf5a8  mov r11, [r13+rax*1]
00007ec5e11cf5ad  movq xmm1, r11
00007ec5e11cf5b2  movq rax, xmm13
00007ec5e11cf5b7  movq r11, xmm14
00007ec5e11cf5bc  vmovq xmm15, rax
00007ec5e11cf5c1  vmovq xmm14, r11
00007ec5e11cf5c6  movaps xmm13, xmm15
00007ec5e11cf5ca  addsd xmm13, xmm14
00007ec5e11cf5cf  ucomisd xmm13, xmm13
00007ec5e11cf5d4  jp 0x00007EC5E11CFA85
00007ec5e11cf5da  movq xmm13, xmm13
00007ec5e11cf5df  movaps xmm15, [r15+0x160]
00007ec5e11cf5e7  movq rax, xmm15
00007ec5e11cf5ec  movq r11, xmm1
00007ec5e11cf5f1  vmovq xmm1, rax
00007ec5e11cf5f6  vmovq xmm15, r11
00007ec5e11cf5fb  movaps xmm14, xmm1
00007ec5e11cf5ff  mulsd xmm14, xmm15
00007ec5e11cf604  ucomisd xmm14, xmm14
00007ec5e11cf609  jp 0x00007EC5E11CFACD
00007ec5e11cf60f  movq xmm14, xmm14
00007ec5e11cf614  lea rax, [r12+0x140]
00007ec5e11cf61c  mov r11, [r13+rax*1]
00007ec5e11cf621  movq xmm1, r11
00007ec5e11cf626  movq rax, xmm13
00007ec5e11cf62b  movq r11, xmm14
00007ec5e11cf630  vmovq xmm15, rax
00007ec5e11cf635  vmovq xmm14, r11
00007ec5e11cf63a  movaps xmm13, xmm15
00007ec5e11cf63e  addsd xmm13, xmm14
00007ec5e11cf643  ucomisd xmm13, xmm13
00007ec5e11cf648  jp 0x00007EC5E11CFB1F
00007ec5e11cf64e  movq xmm13, xmm13
00007ec5e11cf653  movaps xmm15, [r15+0x170]
00007ec5e11cf65b  movq rax, xmm15
00007ec5e11cf660  movq r11, xmm1
00007ec5e11cf665  vmovq xmm1, rax
00007ec5e11cf66a  vmovq xmm15, r11
00007ec5e11cf66f  movaps xmm14, xmm1
00007ec5e11cf673  mulsd xmm14, xmm15
00007ec5e11cf678  ucomisd xmm14, xmm14
00007ec5e11cf67d  jp 0x00007EC5E11CFB67
00007ec5e11cf683  movq xmm14, xmm14
00007ec5e11cf688  lea rax, [r12+0x180]
00007ec5e11cf690  mov r11, [r13+rax*1]
00007ec5e11cf695  movq xmm1, r11
00007ec5e11cf69a  movq rax, xmm13
00007ec5e11cf69f  movq r11, xmm14
00007ec5e11cf6a4  vmovq xmm15, rax
00007ec5e11cf6a9  vmovq xmm14, r11
00007ec5e11cf6ae  movaps xmm13, xmm15
00007ec5e11cf6b2  addsd xmm13, xmm14
00007ec5e11cf6b7  ucomisd xmm13, xmm13
00007ec5e11cf6bc  jp 0x00007EC5E11CFBB9
00007ec5e11cf6c2  movq xmm13, xmm13
00007ec5e11cf6c7  movaps xmm15, [r15+0x180]
00007ec5e11cf6cf  movq rax, xmm15
00007ec5e11cf6d4  movq r11, xmm1
00007ec5e11cf6d9  vmovq xmm1, rax
00007ec5e11cf6de  vmovq xmm15, r11
00007ec5e11cf6e3  movaps xmm14, xmm1
00007ec5e11cf6e7  mulsd xmm14, xmm15
00007ec5e11cf6ec  ucomisd xmm14, xmm14
00007ec5e11cf6f1  jp 0x00007EC5E11CFC01
00007ec5e11cf6f7  movq xmm14, xmm14
00007ec5e11cf6fc  lea rax, [r12+0x1C0]
00007ec5e11cf704  mov r12, [r13+rax*1]
00007ec5e11cf709  movq xmm1, r12
00007ec5e11cf70e  movaps [r15+0x240], xmm1
00007ec5e11cf716  movq rax, xmm13
00007ec5e11cf71b  movq r12, xmm14
00007ec5e11cf720  vmovq xmm15, rax
00007ec5e11cf725  vmovq xmm14, r12
00007ec5e11cf72a  movaps xmm13, xmm15
00007ec5e11cf72e  addsd xmm13, xmm14
00007ec5e11cf733  ucomisd xmm13, xmm13
00007ec5e11cf738  jp 0x00007EC5E11CFC53
00007ec5e11cf73e  movq xmm13, xmm13
00007ec5e11cf743  movaps xmm15, [r15+0x210]
00007ec5e11cf74b  movq rax, xmm15
00007ec5e11cf750  movq r12, xmm1
00007ec5e11cf755  vmovq xmm1, rax
00007ec5e11cf75a  vmovq xmm15, r12
00007ec5e11cf75f  movaps xmm14, xmm1
00007ec5e11cf763  mulsd xmm14, xmm15
00007ec5e11cf768  ucomisd xmm14, xmm14
00007ec5e11cf76d  jp 0x00007EC5E11CFC9B
00007ec5e11cf773  movq xmm14, xmm14
00007ec5e11cf778  movaps [r15+0x230], xmm14
00007ec5e11cf780  movq rax, xmm13
00007ec5e11cf785  movq r12, xmm14
00007ec5e11cf78a  vmovq xmm1, rax
00007ec5e11cf78f  vmovq xmm15, r12
00007ec5e11cf794  movaps xmm14, xmm1
00007ec5e11cf798  addsd xmm14, xmm15
00007ec5e11cf79d  ucomisd xmm14, xmm14
00007ec5e11cf7a2  jp 0x00007EC5E11CFCE3
00007ec5e11cf7a8  movq xmm14, xmm14
00007ec5e11cf7ad  movaps [r15+0x220], xmm14
00007ec5e11cf7b5  mov rax, [r15+0x68]
00007ec5e11cf7b9  lea r12, [rax+r14*1]
00007ec5e11cf7bd  movq rax, xmm14
00007ec5e11cf7c2  mov [r13+r12*1], rax
00007ec5e11cf7c7  lea rax, [r14+0x08]
00007ec5e11cf7cb  mov [r15+0x70], rax
00007ec5e11cf7cf  mov [rsp+0x10], rax
00007ec5e11cf7d4  xor eax, eax
00007ec5e11cf7d6  mov r14, [rsp+0x10]
00007ec5e11cf7db  mov r12d, 0x40
00007ec5e11cf7e1  cmp r14, r12
00007ec5e11cf7e4  cmc
00007ec5e11cf7e5  lahf
00007ec5e11cf7e6  seto al
00007ec5e11cf7e9  mov [r15+0x108], eax
00007ec5e11cf7f0  mov eax, [r15+0x108]
00007ec5e11cf7f7  sahf
00007ec5e11cf7f8  jnz 0x00007EC5E11CF82A
00007ec5e11cf7fa  cmp dword ptr [r15+0x318], 0x00
00007ec5e11cf802  jz 0x00007EC5E11CFD40
00007ec5e11cf808  nop [rax+rax*1], ax
00007ec5e11cf811  nop [rax+rax*1], eax
00007ec5e11cf819  mov eax, 0x410118
00007ec5e11cf81e  mov [r15+0x100], rax
00007ec5e11cf825  jmp 0x00007EC5E0FFE110
00007ec5e11cf82a  cmp dword ptr [r15+0x318], 0x00
00007ec5e11cf832  jz 0x00007EC5E11CF3F0
00007ec5e11cf838  nop [rax+rax*1], ax
00007ec5e11cf841  nop [rax+rax*1], eax
00007ec5e11cf849  mov eax, 0x4100A4
00007ec5e11cf84e  mov [r15+0x100], rax
00007ec5e11cf855  jmp 0x00007EC5E0FFE110
00007ec5e11cf85a  int3
00007ec5e11cf85b  call 0x00007EC5E10B47C0
00007ec5e11cf860  jmp 0x00007EC5E11CF405
00007ec5e11cf865  call 0x00007EC5E100A4B0
00007ec5e11cf86a  jmp 0x00007EC5E11CF414
00007ec5e11cf86f  call 0x00007EC5E100A4B0
00007ec5e11cf874  jmp 0x00007EC5E11CF426
00007ec5e11cf879  ucomisd xmm1, xmm13
00007ec5e11cf87e  jp 0x00007EC5E11CF88D
00007ec5e11cf880  movaps xmm12, [0x00007EC5E0DFE030]
00007ec5e11cf888  jmp 0x00007EC5E11CF45B
00007ec5e11cf88d  vxorps xmm0, xmm1, xmm13
00007ec5e11cf892  pextrw eax, xmm0, 0x03
00007ec5e11cf897  and eax, 0x7FF8
00007ec5e11cf89c  cmp eax, 0x08
00007ec5e11cf89f  jnz 0x00007EC5E11CF45B
00007ec5e11cf8a5  movq rax, xmm13
00007ec5e11cf8aa  shl rax, 0x0D
00007ec5e11cf8ae  jbe 0x00007EC5E11CF45B
00007ec5e11cf8b4  vorps xmm12, xmm13, [0x00007EC5E0DFE040]
00007ec5e11cf8bc  jmp 0x00007EC5E11CF45B
00007ec5e11cf8c1  ucomisd xmm1, xmm15
00007ec5e11cf8c6  jp 0x00007EC5E11CF8D5
00007ec5e11cf8c8  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf8d0  jmp 0x00007EC5E11CF490
00007ec5e11cf8d5  vxorps xmm0, xmm1, xmm15
00007ec5e11cf8da  pextrw eax, xmm0, 0x03
00007ec5e11cf8df  and eax, 0x7FF8
00007ec5e11cf8e4  cmp eax, 0x08
00007ec5e11cf8e7  jnz 0x00007EC5E11CF490
00007ec5e11cf8ed  movq rax, xmm15
00007ec5e11cf8f2  shl rax, 0x0D
00007ec5e11cf8f6  jbe 0x00007EC5E11CF490
00007ec5e11cf8fc  vorps xmm13, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf904  jmp 0x00007EC5E11CF490
00007ec5e11cf909  ucomisd xmm1, xmm15
00007ec5e11cf90e  jp 0x00007EC5E11CF91D
00007ec5e11cf910  movaps xmm12, [0x00007EC5E0DFE030]
00007ec5e11cf918  jmp 0x00007EC5E11CF4C5
00007ec5e11cf91d  vxorps xmm0, xmm1, xmm15
00007ec5e11cf922  pextrw eax, xmm0, 0x03
00007ec5e11cf927  and eax, 0x7FF8
00007ec5e11cf92c  cmp eax, 0x08
00007ec5e11cf92f  jnz 0x00007EC5E11CF4C5
00007ec5e11cf935  movq rax, xmm15
00007ec5e11cf93a  shl rax, 0x0D
00007ec5e11cf93e  jbe 0x00007EC5E11CF4C5
00007ec5e11cf944  vorps xmm12, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf94c  jmp 0x00007EC5E11CF4C5
00007ec5e11cf951  ucomisd xmm1, xmm15
00007ec5e11cf956  jp 0x00007EC5E11CF965
00007ec5e11cf958  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf960  jmp 0x00007EC5E11CF4F2
00007ec5e11cf965  vxorps xmm0, xmm1, xmm15
00007ec5e11cf96a  pextrw eax, xmm0, 0x03
00007ec5e11cf96f  and eax, 0x7FF8
00007ec5e11cf974  cmp eax, 0x08
00007ec5e11cf977  jnz 0x00007EC5E11CF4F2
00007ec5e11cf97d  movq rax, xmm15
00007ec5e11cf982  shl rax, 0x0D
00007ec5e11cf986  jbe 0x00007EC5E11CF4F2
00007ec5e11cf98c  vorps xmm13, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf994  jmp 0x00007EC5E11CF4F2
00007ec5e11cf999  ucomisd xmm1, xmm15
00007ec5e11cf99e  jp 0x00007EC5E11CF9AD
00007ec5e11cf9a0  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cf9a8  jmp 0x00007EC5E11CF527
00007ec5e11cf9ad  vxorps xmm0, xmm1, xmm15
00007ec5e11cf9b2  pextrw eax, xmm0, 0x03
00007ec5e11cf9b7  and eax, 0x7FF8
00007ec5e11cf9bc  cmp eax, 0x08
00007ec5e11cf9bf  jnz 0x00007EC5E11CF527
00007ec5e11cf9c5  movq rax, xmm15
00007ec5e11cf9ca  shl rax, 0x0D
00007ec5e11cf9ce  jbe 0x00007EC5E11CF527
00007ec5e11cf9d4  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cf9dc  jmp 0x00007EC5E11CF527
00007ec5e11cf9e1  call 0x00007EC5E100A4B0
00007ec5e11cf9e6  jmp 0x00007EC5E11CF539
00007ec5e11cf9eb  ucomisd xmm15, xmm14
00007ec5e11cf9f0  jp 0x00007EC5E11CF9FF
00007ec5e11cf9f2  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cf9fa  jmp 0x00007EC5E11CF566
00007ec5e11cf9ff  vxorps xmm0, xmm15, xmm14
00007ec5e11cfa04  pextrw eax, xmm0, 0x03
00007ec5e11cfa09  and eax, 0x7FF8
00007ec5e11cfa0e  cmp eax, 0x08
00007ec5e11cfa11  jnz 0x00007EC5E11CF566
00007ec5e11cfa17  movq rax, xmm14
00007ec5e11cfa1c  shl rax, 0x0D
00007ec5e11cfa20  jbe 0x00007EC5E11CF566
00007ec5e11cfa26  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cfa2e  jmp 0x00007EC5E11CF566
00007ec5e11cfa33  ucomisd xmm1, xmm15
00007ec5e11cfa38  jp 0x00007EC5E11CFA47
00007ec5e11cfa3a  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cfa42  jmp 0x00007EC5E11CF59B
00007ec5e11cfa47  vxorps xmm0, xmm1, xmm15
00007ec5e11cfa4c  pextrw eax, xmm0, 0x03
00007ec5e11cfa51  and eax, 0x7FF8
00007ec5e11cfa56  cmp eax, 0x08
00007ec5e11cfa59  jnz 0x00007EC5E11CF59B
00007ec5e11cfa5f  movq rax, xmm15
00007ec5e11cfa64  shl rax, 0x0D
00007ec5e11cfa68  jbe 0x00007EC5E11CF59B
00007ec5e11cfa6e  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cfa76  jmp 0x00007EC5E11CF59B
00007ec5e11cfa7b  call 0x00007EC5E100A4B0
00007ec5e11cfa80  jmp 0x00007EC5E11CF5AD
00007ec5e11cfa85  ucomisd xmm15, xmm14
00007ec5e11cfa8a  jp 0x00007EC5E11CFA99
00007ec5e11cfa8c  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cfa94  jmp 0x00007EC5E11CF5DA
00007ec5e11cfa99  vxorps xmm0, xmm15, xmm14
00007ec5e11cfa9e  pextrw eax, xmm0, 0x03
00007ec5e11cfaa3  and eax, 0x7FF8
00007ec5e11cfaa8  cmp eax, 0x08
00007ec5e11cfaab  jnz 0x00007EC5E11CF5DA
00007ec5e11cfab1  movq rax, xmm14
00007ec5e11cfab6  shl rax, 0x0D
00007ec5e11cfaba  jbe 0x00007EC5E11CF5DA
00007ec5e11cfac0  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cfac8  jmp 0x00007EC5E11CF5DA
00007ec5e11cfacd  ucomisd xmm1, xmm15
00007ec5e11cfad2  jp 0x00007EC5E11CFAE1
00007ec5e11cfad4  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cfadc  jmp 0x00007EC5E11CF60F
00007ec5e11cfae1  vxorps xmm0, xmm1, xmm15
00007ec5e11cfae6  pextrw eax, xmm0, 0x03
00007ec5e11cfaeb  and eax, 0x7FF8
00007ec5e11cfaf0  cmp eax, 0x08
00007ec5e11cfaf3  jnz 0x00007EC5E11CF60F
00007ec5e11cfaf9  movq rax, xmm15
00007ec5e11cfafe  shl rax, 0x0D
00007ec5e11cfb02  jbe 0x00007EC5E11CF60F
00007ec5e11cfb08  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cfb10  jmp 0x00007EC5E11CF60F
00007ec5e11cfb15  call 0x00007EC5E100A4B0
00007ec5e11cfb1a  jmp 0x00007EC5E11CF621
00007ec5e11cfb1f  ucomisd xmm15, xmm14
00007ec5e11cfb24  jp 0x00007EC5E11CFB33
00007ec5e11cfb26  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cfb2e  jmp 0x00007EC5E11CF64E
00007ec5e11cfb33  vxorps xmm0, xmm15, xmm14
00007ec5e11cfb38  pextrw eax, xmm0, 0x03
00007ec5e11cfb3d  and eax, 0x7FF8
00007ec5e11cfb42  cmp eax, 0x08
00007ec5e11cfb45  jnz 0x00007EC5E11CF64E
00007ec5e11cfb4b  movq rax, xmm14
00007ec5e11cfb50  shl rax, 0x0D
00007ec5e11cfb54  jbe 0x00007EC5E11CF64E
00007ec5e11cfb5a  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cfb62  jmp 0x00007EC5E11CF64E
00007ec5e11cfb67  ucomisd xmm1, xmm15
00007ec5e11cfb6c  jp 0x00007EC5E11CFB7B
00007ec5e11cfb6e  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cfb76  jmp 0x00007EC5E11CF683
00007ec5e11cfb7b  vxorps xmm0, xmm1, xmm15
00007ec5e11cfb80  pextrw eax, xmm0, 0x03
00007ec5e11cfb85  and eax, 0x7FF8
00007ec5e11cfb8a  cmp eax, 0x08
00007ec5e11cfb8d  jnz 0x00007EC5E11CF683
00007ec5e11cfb93  movq rax, xmm15
00007ec5e11cfb98  shl rax, 0x0D
00007ec5e11cfb9c  jbe 0x00007EC5E11CF683
00007ec5e11cfba2  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cfbaa  jmp 0x00007EC5E11CF683
00007ec5e11cfbaf  call 0x00007EC5E100A4B0
00007ec5e11cfbb4  jmp 0x00007EC5E11CF695
00007ec5e11cfbb9  ucomisd xmm15, xmm14
00007ec5e11cfbbe  jp 0x00007EC5E11CFBCD
00007ec5e11cfbc0  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cfbc8  jmp 0x00007EC5E11CF6C2
00007ec5e11cfbcd  vxorps xmm0, xmm15, xmm14
00007ec5e11cfbd2  pextrw eax, xmm0, 0x03
00007ec5e11cfbd7  and eax, 0x7FF8
00007ec5e11cfbdc  cmp eax, 0x08
00007ec5e11cfbdf  jnz 0x00007EC5E11CF6C2
00007ec5e11cfbe5  movq rax, xmm14
00007ec5e11cfbea  shl rax, 0x0D
00007ec5e11cfbee  jbe 0x00007EC5E11CF6C2
00007ec5e11cfbf4  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cfbfc  jmp 0x00007EC5E11CF6C2
00007ec5e11cfc01  ucomisd xmm1, xmm15
00007ec5e11cfc06  jp 0x00007EC5E11CFC15
00007ec5e11cfc08  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cfc10  jmp 0x00007EC5E11CF6F7
00007ec5e11cfc15  vxorps xmm0, xmm1, xmm15
00007ec5e11cfc1a  pextrw eax, xmm0, 0x03
00007ec5e11cfc1f  and eax, 0x7FF8
00007ec5e11cfc24  cmp eax, 0x08
00007ec5e11cfc27  jnz 0x00007EC5E11CF6F7
00007ec5e11cfc2d  movq rax, xmm15
00007ec5e11cfc32  shl rax, 0x0D
00007ec5e11cfc36  jbe 0x00007EC5E11CF6F7
00007ec5e11cfc3c  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cfc44  jmp 0x00007EC5E11CF6F7
00007ec5e11cfc49  call 0x00007EC5E100B720
00007ec5e11cfc4e  jmp 0x00007EC5E11CF709
00007ec5e11cfc53  ucomisd xmm15, xmm14
00007ec5e11cfc58  jp 0x00007EC5E11CFC67
00007ec5e11cfc5a  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11cfc62  jmp 0x00007EC5E11CF73E
00007ec5e11cfc67  vxorps xmm0, xmm15, xmm14
00007ec5e11cfc6c  pextrw eax, xmm0, 0x03
00007ec5e11cfc71  and eax, 0x7FF8
00007ec5e11cfc76  cmp eax, 0x08
00007ec5e11cfc79  jnz 0x00007EC5E11CF73E
00007ec5e11cfc7f  movq rax, xmm14
00007ec5e11cfc84  shl rax, 0x0D
00007ec5e11cfc88  jbe 0x00007EC5E11CF73E
00007ec5e11cfc8e  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11cfc96  jmp 0x00007EC5E11CF73E
00007ec5e11cfc9b  ucomisd xmm1, xmm15
00007ec5e11cfca0  jp 0x00007EC5E11CFCAF
00007ec5e11cfca2  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cfcaa  jmp 0x00007EC5E11CF773
00007ec5e11cfcaf  vxorps xmm0, xmm1, xmm15
00007ec5e11cfcb4  pextrw eax, xmm0, 0x03
00007ec5e11cfcb9  and eax, 0x7FF8
00007ec5e11cfcbe  cmp eax, 0x08
00007ec5e11cfcc1  jnz 0x00007EC5E11CF773
00007ec5e11cfcc7  movq rax, xmm15
00007ec5e11cfccc  shl rax, 0x0D
00007ec5e11cfcd0  jbe 0x00007EC5E11CF773
00007ec5e11cfcd6  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cfcde  jmp 0x00007EC5E11CF773
00007ec5e11cfce3  ucomisd xmm1, xmm15
00007ec5e11cfce8  jp 0x00007EC5E11CFCF7
00007ec5e11cfcea  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11cfcf2  jmp 0x00007EC5E11CF7A8
00007ec5e11cfcf7  vxorps xmm0, xmm1, xmm15
00007ec5e11cfcfc  pextrw eax, xmm0, 0x03
00007ec5e11cfd01  and eax, 0x7FF8
00007ec5e11cfd06  cmp eax, 0x08
00007ec5e11cfd09  jnz 0x00007EC5E11CF7A8
00007ec5e11cfd0f  movq rax, xmm15
00007ec5e11cfd14  shl rax, 0x0D
00007ec5e11cfd18  jbe 0x00007EC5E11CF7A8
00007ec5e11cfd1e  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11cfd26  jmp 0x00007EC5E11CF7A8
00007ec5e11cfd2b  call 0x00007EC5E10B4CB0
00007ec5e11cfd30  jmp 0x00007EC5E11CF7C7
00007ec5e11cfd35  int3
00007ec5e11cfd36  nop [rax+rax*1], ax
00007ec5e11cfd3f  nop
00007ec5e11cfd40  mov rax, [r15+0x60]
00007ec5e11cfd44  lea r14, [rax+0x01]
00007ec5e11cfd48  mov [r15+0x60], r14
00007ec5e11cfd4c  mov rax, [r15+0x68]
00007ec5e11cfd50  lea r12, [rax+0x40]
00007ec5e11cfd54  mov [r15+0x68], r12
00007ec5e11cfd58  xor eax, eax
00007ec5e11cfd5a  mov r12d, 0x08
00007ec5e11cfd60  cmp r14, r12
00007ec5e11cfd63  cmc
00007ec5e11cfd64  lahf
00007ec5e11cfd65  seto al
00007ec5e11cfd68  mov [r15+0x108], eax
00007ec5e11cfd6f  mov eax, [r15+0x108]
00007ec5e11cfd76  sahf
00007ec5e11cfd77  jnz 0x00007EC5E11CFDA9
00007ec5e11cfd79  cmp dword ptr [r15+0x318], 0x00
00007ec5e11cfd81  jz 0x00007EC5E11D08A0
00007ec5e11cfd87  nop [rax+rax*1], ax
00007ec5e11cfd90  nop [rax+rax*1], eax
00007ec5e11cfd98  mov eax, 0x410128
00007ec5e11cfd9d  mov [r15+0x100], rax
00007ec5e11cfda4  jmp 0x00007EC5E0FFE110
00007ec5e11cfda9  cmp dword ptr [r15+0x318], 0x00
00007ec5e11cfdb1  jz 0x00007EC5E11CFDE0
00007ec5e11cfdb7  nop [rax+rax*1], ax
00007ec5e11cfdc0  nop [rax+rax*1], eax
00007ec5e11cfdc8  mov eax, 0x41008C
00007ec5e11cfdcd  mov [r15+0x100], rax
00007ec5e11cfdd4  jmp 0x00007EC5E0FFE110
00007ec5e11cfdd9  int3
00007ec5e11cfdda  int3
00007ec5e11cfddb  nop [rax+rax*1], eax
00007ec5e11cfde0  mov rax, [r15+0x40]
00007ec5e11cfde4  mov r14, [r15+0x60]
00007ec5e11cfde8  shl r14, 0x06
00007ec5e11cfdec  lea r12, [rax+r14*1]
00007ec5e11cfdf0  mov rax, [r13+r12*1]
00007ec5e11cfdf5  lea r14, [r12+0x08]
00007ec5e11cfdfa  mov r11, [r13+r14*1]
00007ec5e11cfdff  movq xmm1, rax
00007ec5e11cfe04  movq xmm15, r11
00007ec5e11cfe09  movq xmm1, xmm1
00007ec5e11cfe0d  movq xmm1, xmm1
00007ec5e11cfe11  movaps [r15+0x120], xmm1
00007ec5e11cfe19  movq xmm15, xmm15
00007ec5e11cfe1e  movq xmm15, xmm15
00007ec5e11cfe23  movaps [r15+0x130], xmm15
00007ec5e11cfe2b  lea rax, [r12+0x10]
00007ec5e11cfe30  mov r14, [r13+rax*1]
00007ec5e11cfe35  lea rax, [r12+0x18]
00007ec5e11cfe3a  mov r11, [r13+rax*1]
00007ec5e11cfe3f  movq xmm1, r14
00007ec5e11cfe44  movq xmm15, r11
00007ec5e11cfe49  movq xmm1, xmm1
00007ec5e11cfe4d  movq xmm1, xmm1
00007ec5e11cfe51  movaps [r15+0x140], xmm1
00007ec5e11cfe59  movq xmm15, xmm15
00007ec5e11cfe5e  movq xmm15, xmm15
00007ec5e11cfe63  movaps [r15+0x150], xmm15
00007ec5e11cfe6b  lea rax, [r12+0x20]
00007ec5e11cfe70  mov r14, [r13+rax*1]
00007ec5e11cfe75  lea rax, [r12+0x28]
00007ec5e11cfe7a  mov r11, [r13+rax*1]
00007ec5e11cfe7f  movq xmm1, r14
00007ec5e11cfe84  movq xmm15, r11
00007ec5e11cfe89  movq xmm1, xmm1
00007ec5e11cfe8d  movq xmm1, xmm1
00007ec5e11cfe91  movaps [r15+0x160], xmm1
00007ec5e11cfe99  movq xmm15, xmm15
00007ec5e11cfe9e  movq xmm15, xmm15
00007ec5e11cfea3  movaps [r15+0x170], xmm15
00007ec5e11cfeab  lea rax, [r12+0x30]
00007ec5e11cfeb0  mov r14, [r13+rax*1]
00007ec5e11cfeb5  lea rax, [r12+0x38]
00007ec5e11cfeba  mov r12, [r13+rax*1]
00007ec5e11cfebf  movq xmm1, r14
00007ec5e11cfec4  movq xmm15, r12
00007ec5e11cfec9  movq xmm1, xmm1
00007ec5e11cfecd  movq xmm1, xmm1
00007ec5e11cfed1  movaps [r15+0x180], xmm1
00007ec5e11cfed9  movq xmm15, xmm15
00007ec5e11cfede  movq xmm15, xmm15
00007ec5e11cfee3  movaps [r15+0x210], xmm15
00007ec5e11cfeeb  mov rax, [r15+0x48]
00007ec5e11cfeef  mov [r15+0x78], rax
00007ec5e11cfef3  mov r14, [r13+rax*1]
00007ec5e11cfef8  movq xmm1, r14
00007ec5e11cfefd  lea r14, [rax+0x40]
00007ec5e11cff01  mov r12, [r13+r14*1]
00007ec5e11cff06  movq xmm15, r12
00007ec5e11cff0b  lea r14, [rax+0x80]
00007ec5e11cff12  mov r12, [r13+r14*1]
00007ec5e11cff17  movq xmm14, r12
00007ec5e11cff1c  movaps xmm13, [r15+0x120]
00007ec5e11cff24  movq r14, xmm13
00007ec5e11cff29  movq r12, xmm1
00007ec5e11cff2e  vmovq xmm1, r14
00007ec5e11cff33  vmovq xmm13, r12
00007ec5e11cff38  movaps xmm12, xmm1
00007ec5e11cff3c  mulsd xmm12, xmm13
00007ec5e11cff41  ucomisd xmm12, xmm12
00007ec5e11cff46  jp 0x00007EC5E11D03AD
00007ec5e11cff4c  movq xmm12, xmm12
00007ec5e11cff51  movaps xmm1, [r15+0x130]
00007ec5e11cff59  movq r14, xmm1
00007ec5e11cff5e  movq r12, xmm15
00007ec5e11cff63  vmovq xmm1, r14
00007ec5e11cff68  vmovq xmm15, r12
00007ec5e11cff6d  movaps xmm13, xmm1
00007ec5e11cff71  mulsd xmm13, xmm15
00007ec5e11cff76  ucomisd xmm13, xmm13
00007ec5e11cff7b  jp 0x00007EC5E11D03F9
00007ec5e11cff81  movq xmm13, xmm13
00007ec5e11cff86  movq r14, xmm12
00007ec5e11cff8b  movaps xmm1, [r15+0x110]
00007ec5e11cff93  movq r12, xmm1
00007ec5e11cff98  vmovq xmm1, r14
00007ec5e11cff9d  vmovq xmm15, r12
00007ec5e11cffa2  movaps xmm12, xmm1
00007ec5e11cffa6  addsd xmm12, xmm15
00007ec5e11cffab  ucomisd xmm12, xmm12
00007ec5e11cffb0  jp 0x00007EC5E11D0445
00007ec5e11cffb6  movq xmm12, xmm12
00007ec5e11cffbb  movq r14, xmm12
00007ec5e11cffc0  movq r12, xmm13
00007ec5e11cffc5  vmovq xmm1, r14
00007ec5e11cffca  vmovq xmm15, r12
00007ec5e11cffcf  movaps xmm13, xmm1
00007ec5e11cffd3  addsd xmm13, xmm15
00007ec5e11cffd8  ucomisd xmm13, xmm13
00007ec5e11cffdd  jp 0x00007EC5E11D0491
00007ec5e11cffe3  movq xmm13, xmm13
00007ec5e11cffe8  movaps xmm1, [r15+0x140]
00007ec5e11cfff0  movq r14, xmm1
00007ec5e11cfff5  movq r12, xmm14
00007ec5e11cfffa  vmovq xmm1, r14
00007ec5e11cffff  vmovq xmm15, r12
00007ec5e11d0004  movaps xmm14, xmm1
00007ec5e11d0008  mulsd xmm14, xmm15
00007ec5e11d000d  ucomisd xmm14, xmm14
00007ec5e11d0012  jp 0x00007EC5E11D04DD
00007ec5e11d0018  movq xmm14, xmm14
00007ec5e11d001d  lea r14, [rax+0xC0]
00007ec5e11d0024  mov r12, [r13+r14*1]
00007ec5e11d0029  movq xmm1, r12
00007ec5e11d002e  movq r14, xmm13
00007ec5e11d0033  movq r12, xmm14
00007ec5e11d0038  vmovq xmm15, r14
00007ec5e11d003d  vmovq xmm14, r12
00007ec5e11d0042  movaps xmm13, xmm15
00007ec5e11d0046  addsd xmm13, xmm14
00007ec5e11d004b  ucomisd xmm13, xmm13
00007ec5e11d0050  jp 0x00007EC5E11D0533
00007ec5e11d0056  movq xmm13, xmm13
00007ec5e11d005b  movaps xmm15, [r15+0x150]
00007ec5e11d0063  movq r14, xmm15
00007ec5e11d0068  movq r12, xmm1
00007ec5e11d006d  vmovq xmm1, r14
00007ec5e11d0072  vmovq xmm15, r12
00007ec5e11d0077  movaps xmm14, xmm1
00007ec5e11d007b  mulsd xmm14, xmm15
00007ec5e11d0080  ucomisd xmm14, xmm14
00007ec5e11d0085  jp 0x00007EC5E11D057F
00007ec5e11d008b  movq xmm14, xmm14
00007ec5e11d0090  lea r14, [rax+0x100]
00007ec5e11d0097  mov r12, [r13+r14*1]
00007ec5e11d009c  movq xmm1, r12
00007ec5e11d00a1  movq r14, xmm13
00007ec5e11d00a6  movq r12, xmm14
00007ec5e11d00ab  vmovq xmm15, r14
00007ec5e11d00b0  vmovq xmm14, r12
00007ec5e11d00b5  movaps xmm13, xmm15
00007ec5e11d00b9  addsd xmm13, xmm14
00007ec5e11d00be  ucomisd xmm13, xmm13
00007ec5e11d00c3  jp 0x00007EC5E11D05D5
00007ec5e11d00c9  movq xmm13, xmm13
00007ec5e11d00ce  movaps xmm15, [r15+0x160]
00007ec5e11d00d6  movq r14, xmm15
00007ec5e11d00db  movq r12, xmm1
00007ec5e11d00e0  vmovq xmm1, r14
00007ec5e11d00e5  vmovq xmm15, r12
00007ec5e11d00ea  movaps xmm14, xmm1
00007ec5e11d00ee  mulsd xmm14, xmm15
00007ec5e11d00f3  ucomisd xmm14, xmm14
00007ec5e11d00f8  jp 0x00007EC5E11D0621
00007ec5e11d00fe  movq xmm14, xmm14
00007ec5e11d0103  lea r14, [rax+0x140]
00007ec5e11d010a  mov r12, [r13+r14*1]
00007ec5e11d010f  movq xmm1, r12
00007ec5e11d0114  movq r14, xmm13
00007ec5e11d0119  movq r12, xmm14
00007ec5e11d011e  vmovq xmm15, r14
00007ec5e11d0123  vmovq xmm14, r12
00007ec5e11d0128  movaps xmm13, xmm15
00007ec5e11d012c  addsd xmm13, xmm14
00007ec5e11d0131  ucomisd xmm13, xmm13
00007ec5e11d0136  jp 0x00007EC5E11D0677
00007ec5e11d013c  movq xmm13, xmm13
00007ec5e11d0141  movaps xmm15, [r15+0x170]
00007ec5e11d0149  movq r14, xmm15
00007ec5e11d014e  movq r12, xmm1
00007ec5e11d0153  vmovq xmm1, r14
00007ec5e11d0158  vmovq xmm15, r12
00007ec5e11d015d  movaps xmm14, xmm1
00007ec5e11d0161  mulsd xmm14, xmm15
00007ec5e11d0166  ucomisd xmm14, xmm14
00007ec5e11d016b  jp 0x00007EC5E11D06C3
00007ec5e11d0171  movq xmm14, xmm14
00007ec5e11d0176  lea r14, [rax+0x180]
00007ec5e11d017d  mov r12, [r13+r14*1]
00007ec5e11d0182  movq xmm1, r12
00007ec5e11d0187  movq r14, xmm13
00007ec5e11d018c  movq r12, xmm14
00007ec5e11d0191  vmovq xmm15, r14
00007ec5e11d0196  vmovq xmm14, r12
00007ec5e11d019b  movaps xmm13, xmm15
00007ec5e11d019f  addsd xmm13, xmm14
00007ec5e11d01a4  ucomisd xmm13, xmm13
00007ec5e11d01a9  jp 0x00007EC5E11D0719
00007ec5e11d01af  movq xmm13, xmm13
00007ec5e11d01b4  movaps xmm15, [r15+0x180]
00007ec5e11d01bc  movq r14, xmm15
00007ec5e11d01c1  movq r12, xmm1
00007ec5e11d01c6  vmovq xmm1, r14
00007ec5e11d01cb  vmovq xmm15, r12
00007ec5e11d01d0  movaps xmm14, xmm1
00007ec5e11d01d4  mulsd xmm14, xmm15
00007ec5e11d01d9  ucomisd xmm14, xmm14
00007ec5e11d01de  jp 0x00007EC5E11D0765
00007ec5e11d01e4  movq xmm14, xmm14
00007ec5e11d01e9  lea r14, [rax+0x1C0]
00007ec5e11d01f0  mov rax, [r13+r14*1]
00007ec5e11d01f5  movq xmm1, rax
00007ec5e11d01fa  movaps [r15+0x240], xmm1
00007ec5e11d0202  movq rax, xmm13
00007ec5e11d0207  movq r14, xmm14
00007ec5e11d020c  vmovq xmm15, rax
00007ec5e11d0211  vmovq xmm14, r14
00007ec5e11d0216  movaps xmm13, xmm15
00007ec5e11d021a  addsd xmm13, xmm14
00007ec5e11d021f  ucomisd xmm13, xmm13
00007ec5e11d0224  jp 0x00007EC5E11D07BB
00007ec5e11d022a  movq xmm13, xmm13
00007ec5e11d022f  movaps xmm15, [r15+0x210]
00007ec5e11d0237  movq rax, xmm15
00007ec5e11d023c  movq r14, xmm1
00007ec5e11d0241  vmovq xmm1, rax
00007ec5e11d0246  vmovq xmm15, r14
00007ec5e11d024b  movaps xmm14, xmm1
00007ec5e11d024f  mulsd xmm14, xmm15
00007ec5e11d0254  ucomisd xmm14, xmm14
00007ec5e11d0259  jp 0x00007EC5E11D0803
00007ec5e11d025f  movq xmm14, xmm14
00007ec5e11d0264  movaps [r15+0x230], xmm14
00007ec5e11d026c  movq rax, xmm13
00007ec5e11d0271  movq r14, xmm14
00007ec5e11d0276  vmovq xmm1, rax
00007ec5e11d027b  vmovq xmm15, r14
00007ec5e11d0280  movaps xmm14, xmm1
00007ec5e11d0284  addsd xmm14, xmm15
00007ec5e11d0289  ucomisd xmm14, xmm14
00007ec5e11d028e  jp 0x00007EC5E11D084B
00007ec5e11d0294  movq xmm14, xmm14
00007ec5e11d0299  movaps [r15+0x220], xmm14
00007ec5e11d02a1  mov rax, [r15+0x68]
00007ec5e11d02a5  movq r14, xmm14
00007ec5e11d02aa  mov [r13+rax*1], r14
00007ec5e11d02af  mov qword ptr [r15+0x70], 0x08
00007ec5e11d02b7  xor eax, eax
00007ec5e11d02b9  mov r14d, 0x08
00007ec5e11d02bf  mov r12d, 0x40
00007ec5e11d02c5  cmp r14, r12
00007ec5e11d02c8  cmc
00007ec5e11d02c9  lahf
00007ec5e11d02ca  seto al
00007ec5e11d02cd  mov [r15+0x108], eax
00007ec5e11d02d4  mov eax, [r15+0x108]
00007ec5e11d02db  sahf
00007ec5e11d02dc  jnz 0x00007EC5E11D030E
00007ec5e11d02de  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d02e6  jz 0x00007EC5E11CFD40
00007ec5e11d02ec  nop [rax+rax*1], ax
00007ec5e11d02f5  nop [rax+rax*1], eax
00007ec5e11d02fd  mov eax, 0x410118
00007ec5e11d0302  mov [r15+0x100], rax
00007ec5e11d0309  jmp 0x00007EC5E0FFE110
00007ec5e11d030e  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d0316  jz 0x00007EC5E11CF3F0
00007ec5e11d031c  nop [rax+rax*1], ax
00007ec5e11d0325  nop [rax+rax*1], eax
00007ec5e11d032d  mov eax, 0x4100A4
00007ec5e11d0332  mov [r15+0x100], rax
00007ec5e11d0339  jmp 0x00007EC5E0FFE110
00007ec5e11d033e  int3
00007ec5e11d033f  call 0x00007EC5E10B47C0
00007ec5e11d0344  jmp 0x00007EC5E11CFDF5
00007ec5e11d0349  call 0x00007EC5E10E1570
00007ec5e11d034e  jmp 0x00007EC5E11CFDFF
00007ec5e11d0353  call 0x00007EC5E100DC20
00007ec5e11d0358  jmp 0x00007EC5E11CFE35
00007ec5e11d035d  call 0x00007EC5E100A4B0
00007ec5e11d0362  jmp 0x00007EC5E11CFE3F
00007ec5e11d0367  call 0x00007EC5E100DC20
00007ec5e11d036c  jmp 0x00007EC5E11CFE75
00007ec5e11d0371  call 0x00007EC5E100A4B0
00007ec5e11d0376  jmp 0x00007EC5E11CFE7F
00007ec5e11d037b  call 0x00007EC5E100DC20
00007ec5e11d0380  jmp 0x00007EC5E11CFEB5
00007ec5e11d0385  call 0x00007EC5E100B720
00007ec5e11d038a  jmp 0x00007EC5E11CFEBF
00007ec5e11d038f  call 0x00007EC5E100DC20
00007ec5e11d0394  jmp 0x00007EC5E11CFEF8
00007ec5e11d0399  call 0x00007EC5E10E27E0
00007ec5e11d039e  jmp 0x00007EC5E11CFF06
00007ec5e11d03a3  call 0x00007EC5E10E27E0
00007ec5e11d03a8  jmp 0x00007EC5E11CFF17
00007ec5e11d03ad  ucomisd xmm1, xmm13
00007ec5e11d03b2  jp 0x00007EC5E11D03C1
00007ec5e11d03b4  movaps xmm12, [0x00007EC5E0DFE030]
00007ec5e11d03bc  jmp 0x00007EC5E11CFF4C
00007ec5e11d03c1  vxorps xmm0, xmm1, xmm13
00007ec5e11d03c6  pextrw r14d, xmm0, 0x03
00007ec5e11d03cc  and r14d, 0x7FF8
00007ec5e11d03d3  cmp r14d, 0x08
00007ec5e11d03d7  jnz 0x00007EC5E11CFF4C
00007ec5e11d03dd  movq r14, xmm13
00007ec5e11d03e2  shl r14, 0x0D
00007ec5e11d03e6  jbe 0x00007EC5E11CFF4C
00007ec5e11d03ec  vorps xmm12, xmm13, [0x00007EC5E0DFE040]
00007ec5e11d03f4  jmp 0x00007EC5E11CFF4C
00007ec5e11d03f9  ucomisd xmm1, xmm15
00007ec5e11d03fe  jp 0x00007EC5E11D040D
00007ec5e11d0400  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d0408  jmp 0x00007EC5E11CFF81
00007ec5e11d040d  vxorps xmm0, xmm1, xmm15
00007ec5e11d0412  pextrw r14d, xmm0, 0x03
00007ec5e11d0418  and r14d, 0x7FF8
00007ec5e11d041f  cmp r14d, 0x08
00007ec5e11d0423  jnz 0x00007EC5E11CFF81
00007ec5e11d0429  movq r14, xmm15
00007ec5e11d042e  shl r14, 0x0D
00007ec5e11d0432  jbe 0x00007EC5E11CFF81
00007ec5e11d0438  vorps xmm13, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d0440  jmp 0x00007EC5E11CFF81
00007ec5e11d0445  ucomisd xmm1, xmm15
00007ec5e11d044a  jp 0x00007EC5E11D0459
00007ec5e11d044c  movaps xmm12, [0x00007EC5E0DFE030]
00007ec5e11d0454  jmp 0x00007EC5E11CFFB6
00007ec5e11d0459  vxorps xmm0, xmm1, xmm15
00007ec5e11d045e  pextrw r14d, xmm0, 0x03
00007ec5e11d0464  and r14d, 0x7FF8
00007ec5e11d046b  cmp r14d, 0x08
00007ec5e11d046f  jnz 0x00007EC5E11CFFB6
00007ec5e11d0475  movq r14, xmm15
00007ec5e11d047a  shl r14, 0x0D
00007ec5e11d047e  jbe 0x00007EC5E11CFFB6
00007ec5e11d0484  vorps xmm12, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d048c  jmp 0x00007EC5E11CFFB6
00007ec5e11d0491  ucomisd xmm1, xmm15
00007ec5e11d0496  jp 0x00007EC5E11D04A5
00007ec5e11d0498  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d04a0  jmp 0x00007EC5E11CFFE3
00007ec5e11d04a5  vxorps xmm0, xmm1, xmm15
00007ec5e11d04aa  pextrw r14d, xmm0, 0x03
00007ec5e11d04b0  and r14d, 0x7FF8
00007ec5e11d04b7  cmp r14d, 0x08
00007ec5e11d04bb  jnz 0x00007EC5E11CFFE3
00007ec5e11d04c1  movq r14, xmm15
00007ec5e11d04c6  shl r14, 0x0D
00007ec5e11d04ca  jbe 0x00007EC5E11CFFE3
00007ec5e11d04d0  vorps xmm13, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d04d8  jmp 0x00007EC5E11CFFE3
00007ec5e11d04dd  ucomisd xmm1, xmm15
00007ec5e11d04e2  jp 0x00007EC5E11D04F1
00007ec5e11d04e4  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d04ec  jmp 0x00007EC5E11D0018
00007ec5e11d04f1  vxorps xmm0, xmm1, xmm15
00007ec5e11d04f6  pextrw r14d, xmm0, 0x03
00007ec5e11d04fc  and r14d, 0x7FF8
00007ec5e11d0503  cmp r14d, 0x08
00007ec5e11d0507  jnz 0x00007EC5E11D0018
00007ec5e11d050d  movq r14, xmm15
00007ec5e11d0512  shl r14, 0x0D
00007ec5e11d0516  jbe 0x00007EC5E11D0018
00007ec5e11d051c  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d0524  jmp 0x00007EC5E11D0018
00007ec5e11d0529  call 0x00007EC5E10E27E0
00007ec5e11d052e  jmp 0x00007EC5E11D0029
00007ec5e11d0533  ucomisd xmm15, xmm14
00007ec5e11d0538  jp 0x00007EC5E11D0547
00007ec5e11d053a  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d0542  jmp 0x00007EC5E11D0056
00007ec5e11d0547  vxorps xmm0, xmm15, xmm14
00007ec5e11d054c  pextrw r14d, xmm0, 0x03
00007ec5e11d0552  and r14d, 0x7FF8
00007ec5e11d0559  cmp r14d, 0x08
00007ec5e11d055d  jnz 0x00007EC5E11D0056
00007ec5e11d0563  movq r14, xmm14
00007ec5e11d0568  shl r14, 0x0D
00007ec5e11d056c  jbe 0x00007EC5E11D0056
00007ec5e11d0572  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d057a  jmp 0x00007EC5E11D0056
00007ec5e11d057f  ucomisd xmm1, xmm15
00007ec5e11d0584  jp 0x00007EC5E11D0593
00007ec5e11d0586  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d058e  jmp 0x00007EC5E11D008B
00007ec5e11d0593  vxorps xmm0, xmm1, xmm15
00007ec5e11d0598  pextrw r14d, xmm0, 0x03
00007ec5e11d059e  and r14d, 0x7FF8
00007ec5e11d05a5  cmp r14d, 0x08
00007ec5e11d05a9  jnz 0x00007EC5E11D008B
00007ec5e11d05af  movq r14, xmm15
00007ec5e11d05b4  shl r14, 0x0D
00007ec5e11d05b8  jbe 0x00007EC5E11D008B
00007ec5e11d05be  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d05c6  jmp 0x00007EC5E11D008B
00007ec5e11d05cb  call 0x00007EC5E10E27E0
00007ec5e11d05d0  jmp 0x00007EC5E11D009C
00007ec5e11d05d5  ucomisd xmm15, xmm14
00007ec5e11d05da  jp 0x00007EC5E11D05E9
00007ec5e11d05dc  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d05e4  jmp 0x00007EC5E11D00C9
00007ec5e11d05e9  vxorps xmm0, xmm15, xmm14
00007ec5e11d05ee  pextrw r14d, xmm0, 0x03
00007ec5e11d05f4  and r14d, 0x7FF8
00007ec5e11d05fb  cmp r14d, 0x08
00007ec5e11d05ff  jnz 0x00007EC5E11D00C9
00007ec5e11d0605  movq r14, xmm14
00007ec5e11d060a  shl r14, 0x0D
00007ec5e11d060e  jbe 0x00007EC5E11D00C9
00007ec5e11d0614  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d061c  jmp 0x00007EC5E11D00C9
00007ec5e11d0621  ucomisd xmm1, xmm15
00007ec5e11d0626  jp 0x00007EC5E11D0635
00007ec5e11d0628  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d0630  jmp 0x00007EC5E11D00FE
00007ec5e11d0635  vxorps xmm0, xmm1, xmm15
00007ec5e11d063a  pextrw r14d, xmm0, 0x03
00007ec5e11d0640  and r14d, 0x7FF8
00007ec5e11d0647  cmp r14d, 0x08
00007ec5e11d064b  jnz 0x00007EC5E11D00FE
00007ec5e11d0651  movq r14, xmm15
00007ec5e11d0656  shl r14, 0x0D
00007ec5e11d065a  jbe 0x00007EC5E11D00FE
00007ec5e11d0660  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d0668  jmp 0x00007EC5E11D00FE
00007ec5e11d066d  call 0x00007EC5E10E27E0
00007ec5e11d0672  jmp 0x00007EC5E11D010F
00007ec5e11d0677  ucomisd xmm15, xmm14
00007ec5e11d067c  jp 0x00007EC5E11D068B
00007ec5e11d067e  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d0686  jmp 0x00007EC5E11D013C
00007ec5e11d068b  vxorps xmm0, xmm15, xmm14
00007ec5e11d0690  pextrw r14d, xmm0, 0x03
00007ec5e11d0696  and r14d, 0x7FF8
00007ec5e11d069d  cmp r14d, 0x08
00007ec5e11d06a1  jnz 0x00007EC5E11D013C
00007ec5e11d06a7  movq r14, xmm14
00007ec5e11d06ac  shl r14, 0x0D
00007ec5e11d06b0  jbe 0x00007EC5E11D013C
00007ec5e11d06b6  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d06be  jmp 0x00007EC5E11D013C
00007ec5e11d06c3  ucomisd xmm1, xmm15
00007ec5e11d06c8  jp 0x00007EC5E11D06D7
00007ec5e11d06ca  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d06d2  jmp 0x00007EC5E11D0171
00007ec5e11d06d7  vxorps xmm0, xmm1, xmm15
00007ec5e11d06dc  pextrw r14d, xmm0, 0x03
00007ec5e11d06e2  and r14d, 0x7FF8
00007ec5e11d06e9  cmp r14d, 0x08
00007ec5e11d06ed  jnz 0x00007EC5E11D0171
00007ec5e11d06f3  movq r14, xmm15
00007ec5e11d06f8  shl r14, 0x0D
00007ec5e11d06fc  jbe 0x00007EC5E11D0171
00007ec5e11d0702  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d070a  jmp 0x00007EC5E11D0171
00007ec5e11d070f  call 0x00007EC5E10E27E0
00007ec5e11d0714  jmp 0x00007EC5E11D0182
00007ec5e11d0719  ucomisd xmm15, xmm14
00007ec5e11d071e  jp 0x00007EC5E11D072D
00007ec5e11d0720  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d0728  jmp 0x00007EC5E11D01AF
00007ec5e11d072d  vxorps xmm0, xmm15, xmm14
00007ec5e11d0732  pextrw r14d, xmm0, 0x03
00007ec5e11d0738  and r14d, 0x7FF8
00007ec5e11d073f  cmp r14d, 0x08
00007ec5e11d0743  jnz 0x00007EC5E11D01AF
00007ec5e11d0749  movq r14, xmm14
00007ec5e11d074e  shl r14, 0x0D
00007ec5e11d0752  jbe 0x00007EC5E11D01AF
00007ec5e11d0758  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d0760  jmp 0x00007EC5E11D01AF
00007ec5e11d0765  ucomisd xmm1, xmm15
00007ec5e11d076a  jp 0x00007EC5E11D0779
00007ec5e11d076c  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d0774  jmp 0x00007EC5E11D01E4
00007ec5e11d0779  vxorps xmm0, xmm1, xmm15
00007ec5e11d077e  pextrw r14d, xmm0, 0x03
00007ec5e11d0784  and r14d, 0x7FF8
00007ec5e11d078b  cmp r14d, 0x08
00007ec5e11d078f  jnz 0x00007EC5E11D01E4
00007ec5e11d0795  movq r14, xmm15
00007ec5e11d079a  shl r14, 0x0D
00007ec5e11d079e  jbe 0x00007EC5E11D01E4
00007ec5e11d07a4  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d07ac  jmp 0x00007EC5E11D01E4
00007ec5e11d07b1  call 0x00007EC5E10D59C0
00007ec5e11d07b6  jmp 0x00007EC5E11D01F5
00007ec5e11d07bb  ucomisd xmm15, xmm14
00007ec5e11d07c0  jp 0x00007EC5E11D07CF
00007ec5e11d07c2  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d07ca  jmp 0x00007EC5E11D022A
00007ec5e11d07cf  vxorps xmm0, xmm15, xmm14
00007ec5e11d07d4  pextrw eax, xmm0, 0x03
00007ec5e11d07d9  and eax, 0x7FF8
00007ec5e11d07de  cmp eax, 0x08
00007ec5e11d07e1  jnz 0x00007EC5E11D022A
00007ec5e11d07e7  movq rax, xmm14
00007ec5e11d07ec  shl rax, 0x0D
00007ec5e11d07f0  jbe 0x00007EC5E11D022A
00007ec5e11d07f6  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d07fe  jmp 0x00007EC5E11D022A
00007ec5e11d0803  ucomisd xmm1, xmm15
00007ec5e11d0808  jp 0x00007EC5E11D0817
00007ec5e11d080a  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d0812  jmp 0x00007EC5E11D025F
00007ec5e11d0817  vxorps xmm0, xmm1, xmm15
00007ec5e11d081c  pextrw eax, xmm0, 0x03
00007ec5e11d0821  and eax, 0x7FF8
00007ec5e11d0826  cmp eax, 0x08
00007ec5e11d0829  jnz 0x00007EC5E11D025F
00007ec5e11d082f  movq rax, xmm15
00007ec5e11d0834  shl rax, 0x0D
00007ec5e11d0838  jbe 0x00007EC5E11D025F
00007ec5e11d083e  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d0846  jmp 0x00007EC5E11D025F
00007ec5e11d084b  ucomisd xmm1, xmm15
00007ec5e11d0850  jp 0x00007EC5E11D085F
00007ec5e11d0852  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d085a  jmp 0x00007EC5E11D0294
00007ec5e11d085f  vxorps xmm0, xmm1, xmm15
00007ec5e11d0864  pextrw eax, xmm0, 0x03
00007ec5e11d0869  and eax, 0x7FF8
00007ec5e11d086e  cmp eax, 0x08
00007ec5e11d0871  jnz 0x00007EC5E11D0294
00007ec5e11d0877  movq rax, xmm15
00007ec5e11d087c  shl rax, 0x0D
00007ec5e11d0880  jbe 0x00007EC5E11D0294
00007ec5e11d0886  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d088e  jmp 0x00007EC5E11D0294
00007ec5e11d0893  call 0x00007EC5E100E120
00007ec5e11d0898  jmp 0x00007EC5E11D02AF
00007ec5e11d089d  int3
00007ec5e11d089e  nop
00007ec5e11d08a0  mov eax, [r15+0x58]
00007ec5e11d08a4  lea r14d, [eax+0x01]
00007ec5e11d08a9  mov [rsp+0x10], r14d
00007ec5e11d08ae  mov r14d, r14d
00007ec5e11d08b1  mov [r15+0x58], r14
00007ec5e11d08b5  xor eax, eax
00007ec5e11d08b7  mov r14d, [rsp+0x10]
00007ec5e11d08bc  cmp r14d, 0x1F4
00007ec5e11d08c3  cmc
00007ec5e11d08c4  lahf
00007ec5e11d08c5  seto al
00007ec5e11d08c8  mov [r15+0x108], eax
00007ec5e11d08cf  mov eax, [r15+0x108]
00007ec5e11d08d6  sahf
00007ec5e11d08d7  jnz 0x00007EC5E11D0909
00007ec5e11d08d9  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d08e1  jz 0x00007EC5E11D1410
00007ec5e11d08e7  nop [rax+rax*1], ax
00007ec5e11d08f0  nop [rax+rax*1], eax
00007ec5e11d08f8  mov eax, 0x410134
00007ec5e11d08fd  mov [r15+0x100], rax
00007ec5e11d0904  jmp 0x00007EC5E0FFE110
00007ec5e11d0909  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d0911  jz 0x00007EC5E11D0940
00007ec5e11d0917  nop [rax+rax*1], ax
00007ec5e11d0920  nop [rax+rax*1], eax
00007ec5e11d0928  mov eax, 0x410084
00007ec5e11d092d  mov [r15+0x100], rax
00007ec5e11d0934  jmp 0x00007EC5E0FFE110
00007ec5e11d0939  int3
00007ec5e11d093a  int3
00007ec5e11d093b  nop [rax+rax*1], eax
00007ec5e11d0940  mov qword ptr [r15+0x60], 0x00
00007ec5e11d0948  mov rax, [r15+0x50]
00007ec5e11d094c  mov [r15+0x68], rax
00007ec5e11d0950  mov r14, [r15+0x40]
00007ec5e11d0954  mov r12, [r13+r14*1]
00007ec5e11d0959  lea r11, [r14+0x08]
00007ec5e11d095d  mov r10, [r13+r11*1]
00007ec5e11d0962  movq xmm1, r12
00007ec5e11d0967  movq xmm15, r10
00007ec5e11d096c  movq xmm1, xmm1
00007ec5e11d0970  movq xmm1, xmm1
00007ec5e11d0974  movaps [r15+0x120], xmm1
00007ec5e11d097c  movq xmm15, xmm15
00007ec5e11d0981  movq xmm15, xmm15
00007ec5e11d0986  movaps [r15+0x130], xmm15
00007ec5e11d098e  lea r12, [r14+0x10]
00007ec5e11d0992  mov r11, [r13+r12*1]
00007ec5e11d0997  lea r12, [r14+0x18]
00007ec5e11d099b  mov r10, [r13+r12*1]
00007ec5e11d09a0  movq xmm1, r11
00007ec5e11d09a5  movq xmm15, r10
00007ec5e11d09aa  movq xmm1, xmm1
00007ec5e11d09ae  movq xmm1, xmm1
00007ec5e11d09b2  movaps [r15+0x140], xmm1
00007ec5e11d09ba  movq xmm15, xmm15
00007ec5e11d09bf  movq xmm15, xmm15
00007ec5e11d09c4  movaps [r15+0x150], xmm15
00007ec5e11d09cc  lea r12, [r14+0x20]
00007ec5e11d09d0  mov r11, [r13+r12*1]
00007ec5e11d09d5  lea r12, [r14+0x28]
00007ec5e11d09d9  mov r10, [r13+r12*1]
00007ec5e11d09de  movq xmm1, r11
00007ec5e11d09e3  movq xmm15, r10
00007ec5e11d09e8  movq xmm1, xmm1
00007ec5e11d09ec  movq xmm1, xmm1
00007ec5e11d09f0  movaps [r15+0x160], xmm1
00007ec5e11d09f8  movq xmm15, xmm15
00007ec5e11d09fd  movq xmm15, xmm15
00007ec5e11d0a02  movaps [r15+0x170], xmm15
00007ec5e11d0a0a  lea r12, [r14+0x30]
00007ec5e11d0a0e  mov r11, [r13+r12*1]
00007ec5e11d0a13  lea r12, [r14+0x38]
00007ec5e11d0a17  mov r14, [r13+r12*1]
00007ec5e11d0a1c  movq xmm1, r11
00007ec5e11d0a21  movq xmm15, r14
00007ec5e11d0a26  movq xmm1, xmm1
00007ec5e11d0a2a  movq xmm1, xmm1
00007ec5e11d0a2e  movaps [r15+0x180], xmm1
00007ec5e11d0a36  movq xmm15, xmm15
00007ec5e11d0a3b  movq xmm15, xmm15
00007ec5e11d0a40  movaps [r15+0x210], xmm15
00007ec5e11d0a48  mov r14, [r15+0x48]
00007ec5e11d0a4c  mov [r15+0x78], r14
00007ec5e11d0a50  mov r12, [r13+r14*1]
00007ec5e11d0a55  movq xmm1, r12
00007ec5e11d0a5a  lea r12, [r14+0x40]
00007ec5e11d0a5e  mov r11, [r13+r12*1]
00007ec5e11d0a63  movq xmm15, r11
00007ec5e11d0a68  lea r12, [r14+0x80]
00007ec5e11d0a6f  mov r11, [r13+r12*1]
00007ec5e11d0a74  movq xmm14, r11
00007ec5e11d0a79  movaps xmm13, [r15+0x120]
00007ec5e11d0a81  movq r12, xmm13
00007ec5e11d0a86  movq r11, xmm1
00007ec5e11d0a8b  vmovq xmm1, r12
00007ec5e11d0a90  vmovq xmm13, r11
00007ec5e11d0a95  movaps xmm12, xmm1
00007ec5e11d0a99  mulsd xmm12, xmm13
00007ec5e11d0a9e  ucomisd xmm12, xmm12
00007ec5e11d0aa3  jp 0x00007EC5E11D0F06
00007ec5e11d0aa9  movq xmm12, xmm12
00007ec5e11d0aae  movaps xmm1, [r15+0x130]
00007ec5e11d0ab6  movq r12, xmm1
00007ec5e11d0abb  movq r11, xmm15
00007ec5e11d0ac0  vmovq xmm1, r12
00007ec5e11d0ac5  vmovq xmm15, r11
00007ec5e11d0aca  movaps xmm13, xmm1
00007ec5e11d0ace  mulsd xmm13, xmm15
00007ec5e11d0ad3  ucomisd xmm13, xmm13
00007ec5e11d0ad8  jp 0x00007EC5E11D0F52
00007ec5e11d0ade  movq xmm13, xmm13
00007ec5e11d0ae3  movq r12, xmm12
00007ec5e11d0ae8  movaps xmm1, [r15+0x110]
00007ec5e11d0af0  movq r11, xmm1
00007ec5e11d0af5  vmovq xmm1, r12
00007ec5e11d0afa  vmovq xmm15, r11
00007ec5e11d0aff  movaps xmm12, xmm1
00007ec5e11d0b03  addsd xmm12, xmm15
00007ec5e11d0b08  ucomisd xmm12, xmm12
00007ec5e11d0b0d  jp 0x00007EC5E11D0F9E
00007ec5e11d0b13  movq xmm12, xmm12
00007ec5e11d0b18  movq r12, xmm12
00007ec5e11d0b1d  movq r11, xmm13
00007ec5e11d0b22  vmovq xmm1, r12
00007ec5e11d0b27  vmovq xmm15, r11
00007ec5e11d0b2c  movaps xmm13, xmm1
00007ec5e11d0b30  addsd xmm13, xmm15
00007ec5e11d0b35  ucomisd xmm13, xmm13
00007ec5e11d0b3a  jp 0x00007EC5E11D0FEA
00007ec5e11d0b40  movq xmm13, xmm13
00007ec5e11d0b45  movaps xmm1, [r15+0x140]
00007ec5e11d0b4d  movq r12, xmm1
00007ec5e11d0b52  movq r11, xmm14
00007ec5e11d0b57  vmovq xmm1, r12
00007ec5e11d0b5c  vmovq xmm15, r11
00007ec5e11d0b61  movaps xmm14, xmm1
00007ec5e11d0b65  mulsd xmm14, xmm15
00007ec5e11d0b6a  ucomisd xmm14, xmm14
00007ec5e11d0b6f  jp 0x00007EC5E11D1036
00007ec5e11d0b75  movq xmm14, xmm14
00007ec5e11d0b7a  lea r12, [r14+0xC0]
00007ec5e11d0b81  mov r11, [r13+r12*1]
00007ec5e11d0b86  movq xmm1, r11
00007ec5e11d0b8b  movq r12, xmm13
00007ec5e11d0b90  movq r11, xmm14
00007ec5e11d0b95  vmovq xmm15, r12
00007ec5e11d0b9a  vmovq xmm14, r11
00007ec5e11d0b9f  movaps xmm13, xmm15
00007ec5e11d0ba3  addsd xmm13, xmm14
00007ec5e11d0ba8  ucomisd xmm13, xmm13
00007ec5e11d0bad  jp 0x00007EC5E11D108C
00007ec5e11d0bb3  movq xmm13, xmm13
00007ec5e11d0bb8  movaps xmm15, [r15+0x150]
00007ec5e11d0bc0  movq r12, xmm15
00007ec5e11d0bc5  movq r11, xmm1
00007ec5e11d0bca  vmovq xmm1, r12
00007ec5e11d0bcf  vmovq xmm15, r11
00007ec5e11d0bd4  movaps xmm14, xmm1
00007ec5e11d0bd8  mulsd xmm14, xmm15
00007ec5e11d0bdd  ucomisd xmm14, xmm14
00007ec5e11d0be2  jp 0x00007EC5E11D10D8
00007ec5e11d0be8  movq xmm14, xmm14
00007ec5e11d0bed  lea r12, [r14+0x100]
00007ec5e11d0bf4  mov r11, [r13+r12*1]
00007ec5e11d0bf9  movq xmm1, r11
00007ec5e11d0bfe  movq r12, xmm13
00007ec5e11d0c03  movq r11, xmm14
00007ec5e11d0c08  vmovq xmm15, r12
00007ec5e11d0c0d  vmovq xmm14, r11
00007ec5e11d0c12  movaps xmm13, xmm15
00007ec5e11d0c16  addsd xmm13, xmm14
00007ec5e11d0c1b  ucomisd xmm13, xmm13
00007ec5e11d0c20  jp 0x00007EC5E11D112E
00007ec5e11d0c26  movq xmm13, xmm13
00007ec5e11d0c2b  movaps xmm15, [r15+0x160]
00007ec5e11d0c33  movq r12, xmm15
00007ec5e11d0c38  movq r11, xmm1
00007ec5e11d0c3d  vmovq xmm1, r12
00007ec5e11d0c42  vmovq xmm15, r11
00007ec5e11d0c47  movaps xmm14, xmm1
00007ec5e11d0c4b  mulsd xmm14, xmm15
00007ec5e11d0c50  ucomisd xmm14, xmm14
00007ec5e11d0c55  jp 0x00007EC5E11D117A
00007ec5e11d0c5b  movq xmm14, xmm14
00007ec5e11d0c60  lea r12, [r14+0x140]
00007ec5e11d0c67  mov r11, [r13+r12*1]
00007ec5e11d0c6c  movq xmm1, r11
00007ec5e11d0c71  movq r12, xmm13
00007ec5e11d0c76  movq r11, xmm14
00007ec5e11d0c7b  vmovq xmm15, r12
00007ec5e11d0c80  vmovq xmm14, r11
00007ec5e11d0c85  movaps xmm13, xmm15
00007ec5e11d0c89  addsd xmm13, xmm14
00007ec5e11d0c8e  ucomisd xmm13, xmm13
00007ec5e11d0c93  jp 0x00007EC5E11D11D0
00007ec5e11d0c99  movq xmm13, xmm13
00007ec5e11d0c9e  movaps xmm15, [r15+0x170]
00007ec5e11d0ca6  movq r12, xmm15
00007ec5e11d0cab  movq r11, xmm1
00007ec5e11d0cb0  vmovq xmm1, r12
00007ec5e11d0cb5  vmovq xmm15, r11
00007ec5e11d0cba  movaps xmm14, xmm1
00007ec5e11d0cbe  mulsd xmm14, xmm15
00007ec5e11d0cc3  ucomisd xmm14, xmm14
00007ec5e11d0cc8  jp 0x00007EC5E11D121C
00007ec5e11d0cce  movq xmm14, xmm14
00007ec5e11d0cd3  lea r12, [r14+0x180]
00007ec5e11d0cda  mov r11, [r13+r12*1]
00007ec5e11d0cdf  movq xmm1, r11
00007ec5e11d0ce4  movq r12, xmm13
00007ec5e11d0ce9  movq r11, xmm14
00007ec5e11d0cee  vmovq xmm15, r12
00007ec5e11d0cf3  vmovq xmm14, r11
00007ec5e11d0cf8  movaps xmm13, xmm15
00007ec5e11d0cfc  addsd xmm13, xmm14
00007ec5e11d0d01  ucomisd xmm13, xmm13
00007ec5e11d0d06  jp 0x00007EC5E11D1272
00007ec5e11d0d0c  movq xmm13, xmm13
00007ec5e11d0d11  movaps xmm15, [r15+0x180]
00007ec5e11d0d19  movq r12, xmm15
00007ec5e11d0d1e  movq r11, xmm1
00007ec5e11d0d23  vmovq xmm1, r12
00007ec5e11d0d28  vmovq xmm15, r11
00007ec5e11d0d2d  movaps xmm14, xmm1
00007ec5e11d0d31  mulsd xmm14, xmm15
00007ec5e11d0d36  ucomisd xmm14, xmm14
00007ec5e11d0d3b  jp 0x00007EC5E11D12BE
00007ec5e11d0d41  movq xmm14, xmm14
00007ec5e11d0d46  lea r12, [r14+0x1C0]
00007ec5e11d0d4d  mov r14, [r13+r12*1]
00007ec5e11d0d52  movq xmm1, r14
00007ec5e11d0d57  movaps [r15+0x240], xmm1
00007ec5e11d0d5f  movq r14, xmm13
00007ec5e11d0d64  movq r12, xmm14
00007ec5e11d0d69  vmovq xmm15, r14
00007ec5e11d0d6e  vmovq xmm14, r12
00007ec5e11d0d73  movaps xmm13, xmm15
00007ec5e11d0d77  addsd xmm13, xmm14
00007ec5e11d0d7c  ucomisd xmm13, xmm13
00007ec5e11d0d81  jp 0x00007EC5E11D1314
00007ec5e11d0d87  movq xmm13, xmm13
00007ec5e11d0d8c  movaps xmm15, [r15+0x210]
00007ec5e11d0d94  movq r14, xmm15
00007ec5e11d0d99  movq r12, xmm1
00007ec5e11d0d9e  vmovq xmm1, r14
00007ec5e11d0da3  vmovq xmm15, r12
00007ec5e11d0da8  movaps xmm14, xmm1
00007ec5e11d0dac  mulsd xmm14, xmm15
00007ec5e11d0db1  ucomisd xmm14, xmm14
00007ec5e11d0db6  jp 0x00007EC5E11D1360
00007ec5e11d0dbc  movq xmm14, xmm14
00007ec5e11d0dc1  movaps [r15+0x230], xmm14
00007ec5e11d0dc9  movq r14, xmm13
00007ec5e11d0dce  movq r12, xmm14
00007ec5e11d0dd3  vmovq xmm1, r14
00007ec5e11d0dd8  vmovq xmm15, r12
00007ec5e11d0ddd  movaps xmm14, xmm1
00007ec5e11d0de1  addsd xmm14, xmm15
00007ec5e11d0de6  ucomisd xmm14, xmm14
00007ec5e11d0deb  jp 0x00007EC5E11D13AC
00007ec5e11d0df1  movq xmm14, xmm14
00007ec5e11d0df6  movaps [r15+0x220], xmm14
00007ec5e11d0dfe  movq r14, xmm14
00007ec5e11d0e03  mov [r13+rax*1], r14
00007ec5e11d0e08  mov qword ptr [r15+0x70], 0x08
00007ec5e11d0e10  xor eax, eax
00007ec5e11d0e12  mov r14d, 0x08
00007ec5e11d0e18  mov r12d, 0x40
00007ec5e11d0e1e  cmp r14, r12
00007ec5e11d0e21  cmc
00007ec5e11d0e22  lahf
00007ec5e11d0e23  seto al
00007ec5e11d0e26  mov [r15+0x108], eax
00007ec5e11d0e2d  mov eax, [r15+0x108]
00007ec5e11d0e34  sahf
00007ec5e11d0e35  jnz 0x00007EC5E11D0E67
00007ec5e11d0e37  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d0e3f  jz 0x00007EC5E11CFD40
00007ec5e11d0e45  nop [rax+rax*1], ax
00007ec5e11d0e4e  nop [rax+rax*1], eax
00007ec5e11d0e56  mov eax, 0x410118
00007ec5e11d0e5b  mov [r15+0x100], rax
00007ec5e11d0e62  jmp 0x00007EC5E0FFE110
00007ec5e11d0e67  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d0e6f  jz 0x00007EC5E11CF3F0
00007ec5e11d0e75  nop [rax+rax*1], ax
00007ec5e11d0e7e  nop [rax+rax*1], eax
00007ec5e11d0e86  mov eax, 0x4100A4
00007ec5e11d0e8b  mov [r15+0x100], rax
00007ec5e11d0e92  jmp 0x00007EC5E0FFE110
00007ec5e11d0e97  int3
00007ec5e11d0e98  call 0x00007EC5E10E27E0
00007ec5e11d0e9d  jmp 0x00007EC5E11D0959
00007ec5e11d0ea2  call 0x00007EC5E10AE800
00007ec5e11d0ea7  jmp 0x00007EC5E11D0962
00007ec5e11d0eac  call 0x00007EC5E10C0370
00007ec5e11d0eb1  jmp 0x00007EC5E11D0997
00007ec5e11d0eb6  call 0x00007EC5E10BF100
00007ec5e11d0ebb  jmp 0x00007EC5E11D09A0
00007ec5e11d0ec0  call 0x00007EC5E10C0370
00007ec5e11d0ec5  jmp 0x00007EC5E11D09D5
00007ec5e11d0eca  call 0x00007EC5E10BF100
00007ec5e11d0ecf  jmp 0x00007EC5E11D09DE
00007ec5e11d0ed4  call 0x00007EC5E10C0370
00007ec5e11d0ed9  jmp 0x00007EC5E11D0A13
00007ec5e11d0ede  call 0x00007EC5E10C3AE0
00007ec5e11d0ee3  jmp 0x00007EC5E11D0A1C
00007ec5e11d0ee8  call 0x00007EC5E10E27E0
00007ec5e11d0eed  jmp 0x00007EC5E11D0A55
00007ec5e11d0ef2  call 0x00007EC5E10C0370
00007ec5e11d0ef7  jmp 0x00007EC5E11D0A63
00007ec5e11d0efc  call 0x00007EC5E10C0370
00007ec5e11d0f01  jmp 0x00007EC5E11D0A74
00007ec5e11d0f06  ucomisd xmm1, xmm13
00007ec5e11d0f0b  jp 0x00007EC5E11D0F1A
00007ec5e11d0f0d  movaps xmm12, [0x00007EC5E0DFE030]
00007ec5e11d0f15  jmp 0x00007EC5E11D0AA9
00007ec5e11d0f1a  vxorps xmm0, xmm1, xmm13
00007ec5e11d0f1f  pextrw r12d, xmm0, 0x03
00007ec5e11d0f25  and r12d, 0x7FF8
00007ec5e11d0f2c  cmp r12d, 0x08
00007ec5e11d0f30  jnz 0x00007EC5E11D0AA9
00007ec5e11d0f36  movq r12, xmm13
00007ec5e11d0f3b  shl r12, 0x0D
00007ec5e11d0f3f  jbe 0x00007EC5E11D0AA9
00007ec5e11d0f45  vorps xmm12, xmm13, [0x00007EC5E0DFE040]
00007ec5e11d0f4d  jmp 0x00007EC5E11D0AA9
00007ec5e11d0f52  ucomisd xmm1, xmm15
00007ec5e11d0f57  jp 0x00007EC5E11D0F66
00007ec5e11d0f59  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d0f61  jmp 0x00007EC5E11D0ADE
00007ec5e11d0f66  vxorps xmm0, xmm1, xmm15
00007ec5e11d0f6b  pextrw r12d, xmm0, 0x03
00007ec5e11d0f71  and r12d, 0x7FF8
00007ec5e11d0f78  cmp r12d, 0x08
00007ec5e11d0f7c  jnz 0x00007EC5E11D0ADE
00007ec5e11d0f82  movq r12, xmm15
00007ec5e11d0f87  shl r12, 0x0D
00007ec5e11d0f8b  jbe 0x00007EC5E11D0ADE
00007ec5e11d0f91  vorps xmm13, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d0f99  jmp 0x00007EC5E11D0ADE
00007ec5e11d0f9e  ucomisd xmm1, xmm15
00007ec5e11d0fa3  jp 0x00007EC5E11D0FB2
00007ec5e11d0fa5  movaps xmm12, [0x00007EC5E0DFE030]
00007ec5e11d0fad  jmp 0x00007EC5E11D0B13
00007ec5e11d0fb2  vxorps xmm0, xmm1, xmm15
00007ec5e11d0fb7  pextrw r12d, xmm0, 0x03
00007ec5e11d0fbd  and r12d, 0x7FF8
00007ec5e11d0fc4  cmp r12d, 0x08
00007ec5e11d0fc8  jnz 0x00007EC5E11D0B13
00007ec5e11d0fce  movq r12, xmm15
00007ec5e11d0fd3  shl r12, 0x0D
00007ec5e11d0fd7  jbe 0x00007EC5E11D0B13
00007ec5e11d0fdd  vorps xmm12, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d0fe5  jmp 0x00007EC5E11D0B13
00007ec5e11d0fea  ucomisd xmm1, xmm15
00007ec5e11d0fef  jp 0x00007EC5E11D0FFE
00007ec5e11d0ff1  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d0ff9  jmp 0x00007EC5E11D0B40
00007ec5e11d0ffe  vxorps xmm0, xmm1, xmm15
00007ec5e11d1003  pextrw r12d, xmm0, 0x03
00007ec5e11d1009  and r12d, 0x7FF8
00007ec5e11d1010  cmp r12d, 0x08
00007ec5e11d1014  jnz 0x00007EC5E11D0B40
00007ec5e11d101a  movq r12, xmm15
00007ec5e11d101f  shl r12, 0x0D
00007ec5e11d1023  jbe 0x00007EC5E11D0B40
00007ec5e11d1029  vorps xmm13, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d1031  jmp 0x00007EC5E11D0B40
00007ec5e11d1036  ucomisd xmm1, xmm15
00007ec5e11d103b  jp 0x00007EC5E11D104A
00007ec5e11d103d  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d1045  jmp 0x00007EC5E11D0B75
00007ec5e11d104a  vxorps xmm0, xmm1, xmm15
00007ec5e11d104f  pextrw r12d, xmm0, 0x03
00007ec5e11d1055  and r12d, 0x7FF8
00007ec5e11d105c  cmp r12d, 0x08
00007ec5e11d1060  jnz 0x00007EC5E11D0B75
00007ec5e11d1066  movq r12, xmm15
00007ec5e11d106b  shl r12, 0x0D
00007ec5e11d106f  jbe 0x00007EC5E11D0B75
00007ec5e11d1075  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d107d  jmp 0x00007EC5E11D0B75
00007ec5e11d1082  call 0x00007EC5E10C0370
00007ec5e11d1087  jmp 0x00007EC5E11D0B86
00007ec5e11d108c  ucomisd xmm15, xmm14
00007ec5e11d1091  jp 0x00007EC5E11D10A0
00007ec5e11d1093  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d109b  jmp 0x00007EC5E11D0BB3
00007ec5e11d10a0  vxorps xmm0, xmm15, xmm14
00007ec5e11d10a5  pextrw r12d, xmm0, 0x03
00007ec5e11d10ab  and r12d, 0x7FF8
00007ec5e11d10b2  cmp r12d, 0x08
00007ec5e11d10b6  jnz 0x00007EC5E11D0BB3
00007ec5e11d10bc  movq r12, xmm14
00007ec5e11d10c1  shl r12, 0x0D
00007ec5e11d10c5  jbe 0x00007EC5E11D0BB3
00007ec5e11d10cb  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d10d3  jmp 0x00007EC5E11D0BB3
00007ec5e11d10d8  ucomisd xmm1, xmm15
00007ec5e11d10dd  jp 0x00007EC5E11D10EC
00007ec5e11d10df  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d10e7  jmp 0x00007EC5E11D0BE8
00007ec5e11d10ec  vxorps xmm0, xmm1, xmm15
00007ec5e11d10f1  pextrw r12d, xmm0, 0x03
00007ec5e11d10f7  and r12d, 0x7FF8
00007ec5e11d10fe  cmp r12d, 0x08
00007ec5e11d1102  jnz 0x00007EC5E11D0BE8
00007ec5e11d1108  movq r12, xmm15
00007ec5e11d110d  shl r12, 0x0D
00007ec5e11d1111  jbe 0x00007EC5E11D0BE8
00007ec5e11d1117  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d111f  jmp 0x00007EC5E11D0BE8
00007ec5e11d1124  call 0x00007EC5E10C0370
00007ec5e11d1129  jmp 0x00007EC5E11D0BF9
00007ec5e11d112e  ucomisd xmm15, xmm14
00007ec5e11d1133  jp 0x00007EC5E11D1142
00007ec5e11d1135  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d113d  jmp 0x00007EC5E11D0C26
00007ec5e11d1142  vxorps xmm0, xmm15, xmm14
00007ec5e11d1147  pextrw r12d, xmm0, 0x03
00007ec5e11d114d  and r12d, 0x7FF8
00007ec5e11d1154  cmp r12d, 0x08
00007ec5e11d1158  jnz 0x00007EC5E11D0C26
00007ec5e11d115e  movq r12, xmm14
00007ec5e11d1163  shl r12, 0x0D
00007ec5e11d1167  jbe 0x00007EC5E11D0C26
00007ec5e11d116d  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d1175  jmp 0x00007EC5E11D0C26
00007ec5e11d117a  ucomisd xmm1, xmm15
00007ec5e11d117f  jp 0x00007EC5E11D118E
00007ec5e11d1181  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d1189  jmp 0x00007EC5E11D0C5B
00007ec5e11d118e  vxorps xmm0, xmm1, xmm15
00007ec5e11d1193  pextrw r12d, xmm0, 0x03
00007ec5e11d1199  and r12d, 0x7FF8
00007ec5e11d11a0  cmp r12d, 0x08
00007ec5e11d11a4  jnz 0x00007EC5E11D0C5B
00007ec5e11d11aa  movq r12, xmm15
00007ec5e11d11af  shl r12, 0x0D
00007ec5e11d11b3  jbe 0x00007EC5E11D0C5B
00007ec5e11d11b9  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d11c1  jmp 0x00007EC5E11D0C5B
00007ec5e11d11c6  call 0x00007EC5E10C0370
00007ec5e11d11cb  jmp 0x00007EC5E11D0C6C
00007ec5e11d11d0  ucomisd xmm15, xmm14
00007ec5e11d11d5  jp 0x00007EC5E11D11E4
00007ec5e11d11d7  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d11df  jmp 0x00007EC5E11D0C99
00007ec5e11d11e4  vxorps xmm0, xmm15, xmm14
00007ec5e11d11e9  pextrw r12d, xmm0, 0x03
00007ec5e11d11ef  and r12d, 0x7FF8
00007ec5e11d11f6  cmp r12d, 0x08
00007ec5e11d11fa  jnz 0x00007EC5E11D0C99
00007ec5e11d1200  movq r12, xmm14
00007ec5e11d1205  shl r12, 0x0D
00007ec5e11d1209  jbe 0x00007EC5E11D0C99
00007ec5e11d120f  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d1217  jmp 0x00007EC5E11D0C99
00007ec5e11d121c  ucomisd xmm1, xmm15
00007ec5e11d1221  jp 0x00007EC5E11D1230
00007ec5e11d1223  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d122b  jmp 0x00007EC5E11D0CCE
00007ec5e11d1230  vxorps xmm0, xmm1, xmm15
00007ec5e11d1235  pextrw r12d, xmm0, 0x03
00007ec5e11d123b  and r12d, 0x7FF8
00007ec5e11d1242  cmp r12d, 0x08
00007ec5e11d1246  jnz 0x00007EC5E11D0CCE
00007ec5e11d124c  movq r12, xmm15
00007ec5e11d1251  shl r12, 0x0D
00007ec5e11d1255  jbe 0x00007EC5E11D0CCE
00007ec5e11d125b  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d1263  jmp 0x00007EC5E11D0CCE
00007ec5e11d1268  call 0x00007EC5E10C0370
00007ec5e11d126d  jmp 0x00007EC5E11D0CDF
00007ec5e11d1272  ucomisd xmm15, xmm14
00007ec5e11d1277  jp 0x00007EC5E11D1286
00007ec5e11d1279  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d1281  jmp 0x00007EC5E11D0D0C
00007ec5e11d1286  vxorps xmm0, xmm15, xmm14
00007ec5e11d128b  pextrw r12d, xmm0, 0x03
00007ec5e11d1291  and r12d, 0x7FF8
00007ec5e11d1298  cmp r12d, 0x08
00007ec5e11d129c  jnz 0x00007EC5E11D0D0C
00007ec5e11d12a2  movq r12, xmm14
00007ec5e11d12a7  shl r12, 0x0D
00007ec5e11d12ab  jbe 0x00007EC5E11D0D0C
00007ec5e11d12b1  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d12b9  jmp 0x00007EC5E11D0D0C
00007ec5e11d12be  ucomisd xmm1, xmm15
00007ec5e11d12c3  jp 0x00007EC5E11D12D2
00007ec5e11d12c5  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d12cd  jmp 0x00007EC5E11D0D41
00007ec5e11d12d2  vxorps xmm0, xmm1, xmm15
00007ec5e11d12d7  pextrw r12d, xmm0, 0x03
00007ec5e11d12dd  and r12d, 0x7FF8
00007ec5e11d12e4  cmp r12d, 0x08
00007ec5e11d12e8  jnz 0x00007EC5E11D0D41
00007ec5e11d12ee  movq r12, xmm15
00007ec5e11d12f3  shl r12, 0x0D
00007ec5e11d12f7  jbe 0x00007EC5E11D0D41
00007ec5e11d12fd  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d1305  jmp 0x00007EC5E11D0D41
00007ec5e11d130a  call 0x00007EC5E10C3AE0
00007ec5e11d130f  jmp 0x00007EC5E11D0D52
00007ec5e11d1314  ucomisd xmm15, xmm14
00007ec5e11d1319  jp 0x00007EC5E11D1328
00007ec5e11d131b  movaps xmm13, [0x00007EC5E0DFE030]
00007ec5e11d1323  jmp 0x00007EC5E11D0D87
00007ec5e11d1328  vxorps xmm0, xmm15, xmm14
00007ec5e11d132d  pextrw r14d, xmm0, 0x03
00007ec5e11d1333  and r14d, 0x7FF8
00007ec5e11d133a  cmp r14d, 0x08
00007ec5e11d133e  jnz 0x00007EC5E11D0D87
00007ec5e11d1344  movq r14, xmm14
00007ec5e11d1349  shl r14, 0x0D
00007ec5e11d134d  jbe 0x00007EC5E11D0D87
00007ec5e11d1353  vorps xmm13, xmm14, [0x00007EC5E0DFE040]
00007ec5e11d135b  jmp 0x00007EC5E11D0D87
00007ec5e11d1360  ucomisd xmm1, xmm15
00007ec5e11d1365  jp 0x00007EC5E11D1374
00007ec5e11d1367  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d136f  jmp 0x00007EC5E11D0DBC
00007ec5e11d1374  vxorps xmm0, xmm1, xmm15
00007ec5e11d1379  pextrw r14d, xmm0, 0x03
00007ec5e11d137f  and r14d, 0x7FF8
00007ec5e11d1386  cmp r14d, 0x08
00007ec5e11d138a  jnz 0x00007EC5E11D0DBC
00007ec5e11d1390  movq r14, xmm15
00007ec5e11d1395  shl r14, 0x0D
00007ec5e11d1399  jbe 0x00007EC5E11D0DBC
00007ec5e11d139f  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d13a7  jmp 0x00007EC5E11D0DBC
00007ec5e11d13ac  ucomisd xmm1, xmm15
00007ec5e11d13b1  jp 0x00007EC5E11D13C0
00007ec5e11d13b3  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d13bb  jmp 0x00007EC5E11D0DF1
00007ec5e11d13c0  vxorps xmm0, xmm1, xmm15
00007ec5e11d13c5  pextrw r14d, xmm0, 0x03
00007ec5e11d13cb  and r14d, 0x7FF8
00007ec5e11d13d2  cmp r14d, 0x08
00007ec5e11d13d6  jnz 0x00007EC5E11D0DF1
00007ec5e11d13dc  movq r14, xmm15
00007ec5e11d13e1  shl r14, 0x0D
00007ec5e11d13e5  jbe 0x00007EC5E11D0DF1
00007ec5e11d13eb  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d13f3  jmp 0x00007EC5E11D0DF1
00007ec5e11d13f8  call 0x00007EC5E100E120
00007ec5e11d13fd  jmp 0x00007EC5E11D0E08
00007ec5e11d1402  int3
00007ec5e11d1403  nop [rax+rax*1], ax
00007ec5e11d140c  nop [rax], eax
00007ec5e11d1410  mov qword ptr [r15+0x40], 0x420000
00007ec5e11d1418  mov eax, 0x4201B8
00007ec5e11d141d  mov r14, [r13+rax*1]
00007ec5e11d1422  movq xmm1, r14
00007ec5e11d1427  mov rax, [r15+0x50]
00007ec5e11d142b  mov r14, [r13+rax*1]
00007ec5e11d1430  movq xmm15, r14
00007ec5e11d1435  movaps [r15+0x120], xmm15
00007ec5e11d143d  mov qword ptr [r15+0x48], 0x08
00007ec5e11d1445  xor eax, eax
00007ec5e11d1447  mov r14d, 0x08
00007ec5e11d144d  mov r12d, 0x200
00007ec5e11d1453  cmp r14, r12
00007ec5e11d1456  cmc
00007ec5e11d1457  lahf
00007ec5e11d1458  seto al
00007ec5e11d145b  mov [r15+0x108], eax
00007ec5e11d1462  movq rax, xmm1
00007ec5e11d1467  movq r14, xmm15
00007ec5e11d146c  vmovq xmm1, rax
00007ec5e11d1471  vmovq xmm15, r14
00007ec5e11d1476  movaps xmm14, xmm1
00007ec5e11d147a  addsd xmm14, xmm15
00007ec5e11d147f  ucomisd xmm14, xmm14
00007ec5e11d1484  jp 0x00007EC5E11D1516
00007ec5e11d148a  movq xmm14, xmm14
00007ec5e11d148f  movaps [r15+0x110], xmm14
00007ec5e11d1497  mov eax, [r15+0x108]
00007ec5e11d149e  sahf
00007ec5e11d149f  jnz 0x00007EC5E11D14D1
00007ec5e11d14a1  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d14a9  jz 0x00007EC5E11D16A0
00007ec5e11d14af  nop [rax+rax*1], ax
00007ec5e11d14b8  nop [rax+rax*1], eax
00007ec5e11d14c0  mov eax, 0x410154
00007ec5e11d14c5  mov [r15+0x100], rax
00007ec5e11d14cc  jmp 0x00007EC5E0FFE110
00007ec5e11d14d1  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d14d9  jz 0x00007EC5E11D1560
00007ec5e11d14df  nop [rax+rax*1], ax
00007ec5e11d14e8  nop [rax+rax*1], eax
00007ec5e11d14f0  mov eax, 0x410140
00007ec5e11d14f5  mov [r15+0x100], rax
00007ec5e11d14fc  jmp 0x00007EC5E0FFE110
00007ec5e11d1501  int3
00007ec5e11d1502  call 0x00007EC5E100DC20
00007ec5e11d1507  jmp 0x00007EC5E11D1422
00007ec5e11d150c  call 0x00007EC5E100DC20
00007ec5e11d1511  jmp 0x00007EC5E11D1430
00007ec5e11d1516  ucomisd xmm1, xmm15
00007ec5e11d151b  jp 0x00007EC5E11D152A
00007ec5e11d151d  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d1525  jmp 0x00007EC5E11D148A
00007ec5e11d152a  vxorps xmm0, xmm1, xmm15
00007ec5e11d152f  pextrw eax, xmm0, 0x03
00007ec5e11d1534  and eax, 0x7FF8
00007ec5e11d1539  cmp eax, 0x08
00007ec5e11d153c  jnz 0x00007EC5E11D148A
00007ec5e11d1542  movq rax, xmm15
00007ec5e11d1547  shl rax, 0x0D
00007ec5e11d154b  jbe 0x00007EC5E11D148A
00007ec5e11d1551  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d1559  jmp 0x00007EC5E11D148A
00007ec5e11d155e  int3
00007ec5e11d155f  nop
00007ec5e11d1560  mov rax, [r15+0x48]
00007ec5e11d1564  mov r14, [r15+0x50]
00007ec5e11d1568  lea r12, [r14+rax*1]
00007ec5e11d156c  mov r14, [r13+r12*1]
00007ec5e11d1571  movq xmm1, r14
00007ec5e11d1576  movaps [r15+0x120], xmm1
00007ec5e11d157e  lea r14, [rax+0x08]
00007ec5e11d1582  mov [r15+0x48], r14
00007ec5e11d1586  xor eax, eax
00007ec5e11d1588  mov r12d, 0x200
00007ec5e11d158e  cmp r14, r12
00007ec5e11d1591  cmc
00007ec5e11d1592  lahf
00007ec5e11d1593  seto al
00007ec5e11d1596  mov [r15+0x108], eax
00007ec5e11d159d  movaps xmm15, [r15+0x110]
00007ec5e11d15a5  movq rax, xmm15
00007ec5e11d15aa  movq r14, xmm1
00007ec5e11d15af  vmovq xmm1, rax
00007ec5e11d15b4  vmovq xmm15, r14
00007ec5e11d15b9  movaps xmm14, xmm1
00007ec5e11d15bd  addsd xmm14, xmm15
00007ec5e11d15c2  ucomisd xmm14, xmm14
00007ec5e11d15c7  jp 0x00007EC5E11D164F
00007ec5e11d15cd  movq xmm14, xmm14
00007ec5e11d15d2  movaps [r15+0x110], xmm14
00007ec5e11d15da  mov eax, [r15+0x108]
00007ec5e11d15e1  sahf
00007ec5e11d15e2  jnz 0x00007EC5E11D1614
00007ec5e11d15e4  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d15ec  jz 0x00007EC5E11D16A0
00007ec5e11d15f2  nop [rax+rax*1], ax
00007ec5e11d15fb  nop [rax+rax*1], eax
00007ec5e11d1603  mov eax, 0x410154
00007ec5e11d1608  mov [r15+0x100], rax
00007ec5e11d160f  jmp 0x00007EC5E0FFE110
00007ec5e11d1614  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d161c  jz 0x00007EC5E11D1560
00007ec5e11d1622  nop [rax+rax*1], ax
00007ec5e11d162b  nop [rax+rax*1], eax
00007ec5e11d1633  mov eax, 0x410140
00007ec5e11d1638  mov [r15+0x100], rax
00007ec5e11d163f  jmp 0x00007EC5E0FFE110
00007ec5e11d1644  int3
00007ec5e11d1645  call 0x00007EC5E10C3AE0
00007ec5e11d164a  jmp 0x00007EC5E11D1571
00007ec5e11d164f  ucomisd xmm1, xmm15
00007ec5e11d1654  jp 0x00007EC5E11D1663
00007ec5e11d1656  movaps xmm14, [0x00007EC5E0DFE030]
00007ec5e11d165e  jmp 0x00007EC5E11D15CD
00007ec5e11d1663  vxorps xmm0, xmm1, xmm15
00007ec5e11d1668  pextrw eax, xmm0, 0x03
00007ec5e11d166d  and eax, 0x7FF8
00007ec5e11d1672  cmp eax, 0x08
00007ec5e11d1675  jnz 0x00007EC5E11D15CD
00007ec5e11d167b  movq rax, xmm15
00007ec5e11d1680  shl rax, 0x0D
00007ec5e11d1684  jbe 0x00007EC5E11D15CD
00007ec5e11d168a  vorps xmm14, xmm15, [0x00007EC5E0DFE040]
00007ec5e11d1692  jmp 0x00007EC5E11D15CD
00007ec5e11d1697  int3
00007ec5e11d1698  nop [rax+rax*1], eax
00007ec5e11d16a0  mov rax, [r15+0x40]
00007ec5e11d16a4  lea r14, [rax+0x1B8]
00007ec5e11d16ab  movaps xmm1, [r15+0x110]
00007ec5e11d16b3  movq rax, xmm1
00007ec5e11d16b8  mov [r13+r14*1], rax
00007ec5e11d16bd  mov rax, [r15+0xF0]
00007ec5e11d16c4  mov [r15+0x100], rax
00007ec5e11d16cb  jmp 0x00007EC5E11CE5C0
00007ec5e11d16d0  int3
00007ec5e11d16d1  call 0x00007EC5E10D5EB0
00007ec5e11d16d6  jmp 0x00007EC5E11D16BD
00007ec5e11d16db  int3
00007ec5e11d16dc  nop [rax], eax
00007ec5e11d16e0  mov qword ptr [r15+0x100], 0x04
00007ec5e11d16eb  mov esi, 0x00
00007ec5e11d16f0  mov edx, 0x09
00007ec5e11d16f5  mov rdi, 0x7FFD768BDAD0
00007ec5e11d16ff  mov rax, 0x5FFEFA786970
00007ec5e11d1709  call rax
00007ec5e11d170b  cmp dword ptr [r15+0x318], 0x00
00007ec5e11d1713  jnz 0x00007EC5E0FFE110
00007ec5e11d1719  jmp 0x00007EC5E0FFE0A0
00007ec5e11d171e  int3
00007ec5e11d171f  int3
