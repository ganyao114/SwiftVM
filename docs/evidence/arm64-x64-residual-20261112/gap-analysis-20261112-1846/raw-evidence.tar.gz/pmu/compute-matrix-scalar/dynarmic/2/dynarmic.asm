0000757ab23ce69b  nop [rax+rax*1], eax
0000757ab23ce6a0  mov qword ptr [r15+0x40], 0x4201C0
0000757ab23ce6a8  mov qword ptr [r15+0x48], 0x4203C0
0000757ab23ce6b0  mov qword ptr [r15+0x60], 0x01
0000757ab23ce6b8  xorps xmm1, xmm1
0000757ab23ce6bb  mov eax, 0x41
0000757ab23ce6c0  vcvtusi2sd xmm1, xmm1, eax
0000757ab23ce6c6  mulsd xmm1, [0x0000757AB1FFE010]
0000757ab23ce6ce  movq xmm1, xmm1
0000757ab23ce6d2  movaps [r15+0x120], xmm1
0000757ab23ce6da  mov eax, [r15+0x60]
0000757ab23ce6de  xorps xmm15, xmm15
0000757ab23ce6e2  vcvtusi2sd xmm15, xmm15, eax
0000757ab23ce6e8  mulsd xmm15, [0x0000757AB1FFE020]
0000757ab23ce6f1  movq xmm15, xmm15
0000757ab23ce6f6  movaps [r15+0x110], xmm15
0000757ab23ce6fe  mov rax, [r15+0x60]
0000757ab23ce702  mov [rsp+0x10], rax
0000757ab23ce707  xor eax, eax
0000757ab23ce709  mov r14, [rsp+0x10]
0000757ab23ce70e  mov r12d, 0x40
0000757ab23ce714  cmp r14, r12
0000757ab23ce717  cmc
0000757ab23ce718  lahf
0000757ab23ce719  seto al
0000757ab23ce71c  mov [r15+0x108], eax
0000757ab23ce723  mov qword ptr [r15+0x50], 0x40
0000757ab23ce72b  movq rax, xmm1
0000757ab23ce730  mov r12d, 0x4203C0
0000757ab23ce736  mov [r13+r12*1], rax
0000757ab23ce73b  movq rax, xmm15
0000757ab23ce740  mov r12d, 0x4201C0
0000757ab23ce746  mov [r13+r12*1], rax
0000757ab23ce74b  mov [r15+0x58], r14
0000757ab23ce74f  mov eax, [r15+0x108]
0000757ab23ce756  sahf
0000757ab23ce757  jnz 0x0000757AB23CE789
0000757ab23ce759  cmp dword ptr [r15+0x318], 0x00
0000757ab23ce761  jz 0x0000757AB23CE910
0000757ab23ce767  nop [rax+rax*1], ax
0000757ab23ce770  nop [rax+rax*1], eax
0000757ab23ce778  mov eax, 0x410074
0000757ab23ce77d  mov [r15+0x100], rax
0000757ab23ce784  jmp 0x0000757AB21FE110
0000757ab23ce789  cmp dword ptr [r15+0x318], 0x00
0000757ab23ce791  jz 0x0000757AB23CE7D0
0000757ab23ce797  nop [rax+rax*1], ax
0000757ab23ce7a0  nop [rax+rax*1], eax
0000757ab23ce7a8  mov eax, 0x41004C
0000757ab23ce7ad  mov [r15+0x100], rax
0000757ab23ce7b4  jmp 0x0000757AB21FE110
0000757ab23ce7b9  int3
0000757ab23ce7ba  call 0x0000757AB22B4CB0
0000757ab23ce7bf  jmp 0x0000757AB23CE73B
0000757ab23ce7c4  call 0x0000757AB22B4CB0
0000757ab23ce7c9  jmp 0x0000757AB23CE74B
0000757ab23ce7ce  int3
0000757ab23ce7cf  nop
0000757ab23ce7d0  mov rax, [r15+0x58]
0000757ab23ce7d4  lea r14, [rax+0x01]
0000757ab23ce7d8  mov [r15+0x60], r14
0000757ab23ce7dc  mov r14d, [r15+0x50]
0000757ab23ce7e0  xorps xmm1, xmm1
0000757ab23ce7e3  vcvtusi2sd xmm1, xmm1, r14d
0000757ab23ce7e9  mulsd xmm1, [0x0000757AB1FFE010]
0000757ab23ce7f1  movq xmm1, xmm1
0000757ab23ce7f5  movaps [r15+0x120], xmm1
0000757ab23ce7fd  rorx r12, rax, 0x3D
0000757ab23ce803  and r12, 0xFFFFFFFFFFFFFFF8
0000757ab23ce807  mov eax, [r15+0x60]
0000757ab23ce80b  xorps xmm15, xmm15
0000757ab23ce80f  vcvtusi2sd xmm15, xmm15, eax
0000757ab23ce815  mulsd xmm15, [0x0000757AB1FFE020]
0000757ab23ce81e  movq xmm15, xmm15
0000757ab23ce823  movaps [r15+0x110], xmm15
0000757ab23ce82b  mov rax, [r15+0x60]
0000757ab23ce82f  mov [rsp+0x10], rax
0000757ab23ce834  xor eax, eax
0000757ab23ce836  mov r11, [rsp+0x10]
0000757ab23ce83b  mov r10d, 0x40
0000757ab23ce841  cmp r11, r10
0000757ab23ce844  cmc
0000757ab23ce845  lahf
0000757ab23ce846  seto al
0000757ab23ce849  mov [r15+0x108], eax
0000757ab23ce850  lea eax, [r14d-0x01]
0000757ab23ce855  mov eax, eax
0000757ab23ce857  mov [r15+0x50], rax
0000757ab23ce85b  mov rax, [r15+0x48]
0000757ab23ce85f  lea r14, [rax+r12*1]
0000757ab23ce863  movq rax, xmm1
0000757ab23ce868  mov [r13+r14*1], rax
0000757ab23ce86d  mov rax, [r15+0x40]
0000757ab23ce871  lea r14, [rax+r12*1]
0000757ab23ce875  movq rax, xmm15
0000757ab23ce87a  mov [r13+r14*1], rax
0000757ab23ce87f  mov [r15+0x58], r11
0000757ab23ce883  mov eax, [r15+0x108]
0000757ab23ce88a  sahf
0000757ab23ce88b  jnz 0x0000757AB23CE8BD
0000757ab23ce88d  cmp dword ptr [r15+0x318], 0x00
0000757ab23ce895  jz 0x0000757AB23CE910
0000757ab23ce89b  nop [rax+rax*1], ax
0000757ab23ce8a4  nop [rax+rax*1], eax
0000757ab23ce8ac  mov eax, 0x410074
0000757ab23ce8b1  mov [r15+0x100], rax
0000757ab23ce8b8  jmp 0x0000757AB21FE110
0000757ab23ce8bd  cmp dword ptr [r15+0x318], 0x00
0000757ab23ce8c5  jz 0x0000757AB23CE7D0
0000757ab23ce8cb  nop [rax+rax*1], ax
0000757ab23ce8d4  nop [rax+rax*1], eax
0000757ab23ce8dc  mov eax, 0x41004C
0000757ab23ce8e1  mov [r15+0x100], rax
0000757ab23ce8e8  jmp 0x0000757AB21FE110
0000757ab23ce8ed  int3
0000757ab23ce8ee  call 0x0000757AB22D5EB0
0000757ab23ce8f3  jmp 0x0000757AB23CE86D
0000757ab23ce8f8  call 0x0000757AB22D5EB0
0000757ab23ce8fd  jmp 0x0000757AB23CE87F
0000757ab23ce902  int3
0000757ab23ce903  nop [rax+rax*1], ax
0000757ab23ce90c  nop [rax], eax
0000757ab23ce910  vxorps xmm1, xmm1, xmm1
0000757ab23ce914  movq xmm1, xmm1
0000757ab23ce918  movaps [r15+0x110], xmm1
0000757ab23ce920  mov qword ptr [r15+0x58], 0x00
0000757ab23ce928  mov qword ptr [r15+0x50], 0x4205C0
0000757ab23ce930  mov qword ptr [r15+0x60], 0x00
0000757ab23ce938  mov qword ptr [r15+0x68], 0x4205C0
0000757ab23ce940  mov rax, [r15+0x40]
0000757ab23ce944  mov r14, [r13+rax*1]
0000757ab23ce949  lea r12, [rax+0x08]
0000757ab23ce94d  mov r11, [r13+r12*1]
0000757ab23ce952  movq xmm15, r14
0000757ab23ce957  movq xmm14, r11
0000757ab23ce95c  movq xmm15, xmm15
0000757ab23ce961  movq xmm15, xmm15
0000757ab23ce966  movaps [r15+0x120], xmm15
0000757ab23ce96e  movq xmm14, xmm14
0000757ab23ce973  movq xmm14, xmm14
0000757ab23ce978  movaps [r15+0x130], xmm14
0000757ab23ce980  lea r14, [rax+0x10]
0000757ab23ce984  mov r12, [r13+r14*1]
0000757ab23ce989  lea r14, [rax+0x18]
0000757ab23ce98d  mov r11, [r13+r14*1]
0000757ab23ce992  movq xmm15, r12
0000757ab23ce997  movq xmm14, r11
0000757ab23ce99c  movq xmm15, xmm15
0000757ab23ce9a1  movq xmm15, xmm15
0000757ab23ce9a6  movaps [r15+0x140], xmm15
0000757ab23ce9ae  movq xmm14, xmm14
0000757ab23ce9b3  movq xmm14, xmm14
0000757ab23ce9b8  movaps [r15+0x150], xmm14
0000757ab23ce9c0  lea r14, [rax+0x20]
0000757ab23ce9c4  mov r12, [r13+r14*1]
0000757ab23ce9c9  lea r14, [rax+0x28]
0000757ab23ce9cd  mov r11, [r13+r14*1]
0000757ab23ce9d2  movq xmm15, r12
0000757ab23ce9d7  movq xmm14, r11
0000757ab23ce9dc  movq xmm15, xmm15
0000757ab23ce9e1  movq xmm15, xmm15
0000757ab23ce9e6  movaps [r15+0x160], xmm15
0000757ab23ce9ee  movq xmm14, xmm14
0000757ab23ce9f3  movq xmm14, xmm14
0000757ab23ce9f8  movaps [r15+0x170], xmm14
0000757ab23cea00  lea r14, [rax+0x30]
0000757ab23cea04  mov r12, [r13+r14*1]
0000757ab23cea09  lea r14, [rax+0x38]
0000757ab23cea0d  mov rax, [r13+r14*1]
0000757ab23cea12  movq xmm15, r12
0000757ab23cea17  movq xmm14, rax
0000757ab23cea1c  movq xmm15, xmm15
0000757ab23cea21  movq xmm15, xmm15
0000757ab23cea26  movaps [r15+0x180], xmm15
0000757ab23cea2e  movq xmm14, xmm14
0000757ab23cea33  movq xmm14, xmm14
0000757ab23cea38  movaps [r15+0x210], xmm14
0000757ab23cea40  mov rax, [r15+0x48]
0000757ab23cea44  mov [r15+0x78], rax
0000757ab23cea48  mov r14, [r13+rax*1]
0000757ab23cea4d  movq xmm15, r14
0000757ab23cea52  lea r14, [rax+0x40]
0000757ab23cea56  mov r12, [r13+r14*1]
0000757ab23cea5b  movq xmm14, r12
0000757ab23cea60  lea r14, [rax+0x80]
0000757ab23cea67  mov r12, [r13+r14*1]
0000757ab23cea6c  movq xmm13, r12
0000757ab23cea71  movaps xmm12, [r15+0x120]
0000757ab23cea79  movq r14, xmm12
0000757ab23cea7e  movq r12, xmm15
0000757ab23cea83  vmovq xmm15, r14
0000757ab23cea88  vmovq xmm12, r12
0000757ab23cea8d  movaps xmm11, xmm15
0000757ab23cea91  mulsd xmm11, xmm12
0000757ab23cea96  ucomisd xmm11, xmm11
0000757ab23cea9b  jp 0x0000757AB23CEEFC
0000757ab23ceaa1  movq xmm11, xmm11
0000757ab23ceaa6  movaps xmm15, [r15+0x130]
0000757ab23ceaae  movq r14, xmm15
0000757ab23ceab3  movq r12, xmm14
0000757ab23ceab8  vmovq xmm15, r14
0000757ab23ceabd  vmovq xmm14, r12
0000757ab23ceac2  movaps xmm12, xmm15
0000757ab23ceac6  mulsd xmm12, xmm14
0000757ab23ceacb  ucomisd xmm12, xmm12
0000757ab23cead0  jp 0x0000757AB23CEF48
0000757ab23cead6  movq xmm12, xmm12
0000757ab23ceadb  movq r14, xmm11
0000757ab23ceae0  movq r12, xmm1
0000757ab23ceae5  vmovq xmm1, r14
0000757ab23ceaea  vmovq xmm15, r12
0000757ab23ceaef  movaps xmm14, xmm1
0000757ab23ceaf3  addsd xmm14, xmm15
0000757ab23ceaf8  ucomisd xmm14, xmm14
0000757ab23ceafd  jp 0x0000757AB23CEF94
0000757ab23ceb03  movq xmm14, xmm14
0000757ab23ceb08  movq r14, xmm14
0000757ab23ceb0d  movq r12, xmm12
0000757ab23ceb12  vmovq xmm1, r14
0000757ab23ceb17  vmovq xmm15, r12
0000757ab23ceb1c  movaps xmm14, xmm1
0000757ab23ceb20  addsd xmm14, xmm15
0000757ab23ceb25  ucomisd xmm14, xmm14
0000757ab23ceb2a  jp 0x0000757AB23CEFE0
0000757ab23ceb30  movq xmm14, xmm14
0000757ab23ceb35  movaps xmm1, [r15+0x140]
0000757ab23ceb3d  movq r14, xmm1
0000757ab23ceb42  movq r12, xmm13
0000757ab23ceb47  vmovq xmm1, r14
0000757ab23ceb4c  vmovq xmm15, r12
0000757ab23ceb51  movaps xmm13, xmm1
0000757ab23ceb55  mulsd xmm13, xmm15
0000757ab23ceb5a  ucomisd xmm13, xmm13
0000757ab23ceb5f  jp 0x0000757AB23CF02C
0000757ab23ceb65  movq xmm13, xmm13
0000757ab23ceb6a  lea r14, [rax+0xC0]
0000757ab23ceb71  mov r12, [r13+r14*1]
0000757ab23ceb76  movq xmm1, r12
0000757ab23ceb7b  movq r14, xmm14
0000757ab23ceb80  movq r12, xmm13
0000757ab23ceb85  vmovq xmm15, r14
0000757ab23ceb8a  vmovq xmm14, r12
0000757ab23ceb8f  movaps xmm13, xmm15
0000757ab23ceb93  addsd xmm13, xmm14
0000757ab23ceb98  ucomisd xmm13, xmm13
0000757ab23ceb9d  jp 0x0000757AB23CF082
0000757ab23ceba3  movq xmm13, xmm13
0000757ab23ceba8  movaps xmm15, [r15+0x150]
0000757ab23cebb0  movq r14, xmm15
0000757ab23cebb5  movq r12, xmm1
0000757ab23cebba  vmovq xmm1, r14
0000757ab23cebbf  vmovq xmm15, r12
0000757ab23cebc4  movaps xmm14, xmm1
0000757ab23cebc8  mulsd xmm14, xmm15
0000757ab23cebcd  ucomisd xmm14, xmm14
0000757ab23cebd2  jp 0x0000757AB23CF0CE
0000757ab23cebd8  movq xmm14, xmm14
0000757ab23cebdd  lea r14, [rax+0x100]
0000757ab23cebe4  mov r12, [r13+r14*1]
0000757ab23cebe9  movq xmm1, r12
0000757ab23cebee  movq r14, xmm13
0000757ab23cebf3  movq r12, xmm14
0000757ab23cebf8  vmovq xmm15, r14
0000757ab23cebfd  vmovq xmm14, r12
0000757ab23cec02  movaps xmm13, xmm15
0000757ab23cec06  addsd xmm13, xmm14
0000757ab23cec0b  ucomisd xmm13, xmm13
0000757ab23cec10  jp 0x0000757AB23CF124
0000757ab23cec16  movq xmm13, xmm13
0000757ab23cec1b  movaps xmm15, [r15+0x160]
0000757ab23cec23  movq r14, xmm15
0000757ab23cec28  movq r12, xmm1
0000757ab23cec2d  vmovq xmm1, r14
0000757ab23cec32  vmovq xmm15, r12
0000757ab23cec37  movaps xmm14, xmm1
0000757ab23cec3b  mulsd xmm14, xmm15
0000757ab23cec40  ucomisd xmm14, xmm14
0000757ab23cec45  jp 0x0000757AB23CF170
0000757ab23cec4b  movq xmm14, xmm14
0000757ab23cec50  lea r14, [rax+0x140]
0000757ab23cec57  mov r12, [r13+r14*1]
0000757ab23cec5c  movq xmm1, r12
0000757ab23cec61  movq r14, xmm13
0000757ab23cec66  movq r12, xmm14
0000757ab23cec6b  vmovq xmm15, r14
0000757ab23cec70  vmovq xmm14, r12
0000757ab23cec75  movaps xmm13, xmm15
0000757ab23cec79  addsd xmm13, xmm14
0000757ab23cec7e  ucomisd xmm13, xmm13
0000757ab23cec83  jp 0x0000757AB23CF1C6
0000757ab23cec89  movq xmm13, xmm13
0000757ab23cec8e  movaps xmm15, [r15+0x170]
0000757ab23cec96  movq r14, xmm15
0000757ab23cec9b  movq r12, xmm1
0000757ab23ceca0  vmovq xmm1, r14
0000757ab23ceca5  vmovq xmm15, r12
0000757ab23cecaa  movaps xmm14, xmm1
0000757ab23cecae  mulsd xmm14, xmm15
0000757ab23cecb3  ucomisd xmm14, xmm14
0000757ab23cecb8  jp 0x0000757AB23CF212
0000757ab23cecbe  movq xmm14, xmm14
0000757ab23cecc3  lea r14, [rax+0x180]
0000757ab23cecca  mov r12, [r13+r14*1]
0000757ab23ceccf  movq xmm1, r12
0000757ab23cecd4  movq r14, xmm13
0000757ab23cecd9  movq r12, xmm14
0000757ab23cecde  vmovq xmm15, r14
0000757ab23cece3  vmovq xmm14, r12
0000757ab23cece8  movaps xmm13, xmm15
0000757ab23cecec  addsd xmm13, xmm14
0000757ab23cecf1  ucomisd xmm13, xmm13
0000757ab23cecf6  jp 0x0000757AB23CF268
0000757ab23cecfc  movq xmm13, xmm13
0000757ab23ced01  movaps xmm15, [r15+0x180]
0000757ab23ced09  movq r14, xmm15
0000757ab23ced0e  movq r12, xmm1
0000757ab23ced13  vmovq xmm1, r14
0000757ab23ced18  vmovq xmm15, r12
0000757ab23ced1d  movaps xmm14, xmm1
0000757ab23ced21  mulsd xmm14, xmm15
0000757ab23ced26  ucomisd xmm14, xmm14
0000757ab23ced2b  jp 0x0000757AB23CF2B4
0000757ab23ced31  movq xmm14, xmm14
0000757ab23ced36  lea r14, [rax+0x1C0]
0000757ab23ced3d  mov rax, [r13+r14*1]
0000757ab23ced42  movq xmm1, rax
0000757ab23ced47  movaps [r15+0x240], xmm1
0000757ab23ced4f  movq rax, xmm13
0000757ab23ced54  movq r14, xmm14
0000757ab23ced59  vmovq xmm15, rax
0000757ab23ced5e  vmovq xmm14, r14
0000757ab23ced63  movaps xmm13, xmm15
0000757ab23ced67  addsd xmm13, xmm14
0000757ab23ced6c  ucomisd xmm13, xmm13
0000757ab23ced71  jp 0x0000757AB23CF30A
0000757ab23ced77  movq xmm13, xmm13
0000757ab23ced7c  movaps xmm15, [r15+0x210]
0000757ab23ced84  movq rax, xmm15
0000757ab23ced89  movq r14, xmm1
0000757ab23ced8e  vmovq xmm1, rax
0000757ab23ced93  vmovq xmm15, r14
0000757ab23ced98  movaps xmm14, xmm1
0000757ab23ced9c  mulsd xmm14, xmm15
0000757ab23ceda1  ucomisd xmm14, xmm14
0000757ab23ceda6  jp 0x0000757AB23CF352
0000757ab23cedac  movq xmm14, xmm14
0000757ab23cedb1  movaps [r15+0x230], xmm14
0000757ab23cedb9  movq rax, xmm13
0000757ab23cedbe  movq r14, xmm14
0000757ab23cedc3  vmovq xmm1, rax
0000757ab23cedc8  vmovq xmm15, r14
0000757ab23cedcd  movaps xmm14, xmm1
0000757ab23cedd1  addsd xmm14, xmm15
0000757ab23cedd6  ucomisd xmm14, xmm14
0000757ab23ceddb  jp 0x0000757AB23CF39A
0000757ab23cede1  movq xmm14, xmm14
0000757ab23cede6  movaps [r15+0x220], xmm14
0000757ab23cedee  movq rax, xmm14
0000757ab23cedf3  mov r14d, 0x4205C0
0000757ab23cedf9  mov [r13+r14*1], rax
0000757ab23cedfe  mov qword ptr [r15+0x70], 0x08
0000757ab23cee06  xor eax, eax
0000757ab23cee08  mov r14d, 0x08
0000757ab23cee0e  mov r12d, 0x40
0000757ab23cee14  cmp r14, r12
0000757ab23cee17  cmc
0000757ab23cee18  lahf
0000757ab23cee19  seto al
0000757ab23cee1c  mov [r15+0x108], eax
0000757ab23cee23  mov eax, [r15+0x108]
0000757ab23cee2a  sahf
0000757ab23cee2b  jnz 0x0000757AB23CEE5D
0000757ab23cee2d  cmp dword ptr [r15+0x318], 0x00
0000757ab23cee35  jz 0x0000757AB23CFD40
0000757ab23cee3b  nop [rax+rax*1], ax
0000757ab23cee44  nop [rax+rax*1], eax
0000757ab23cee4c  mov eax, 0x410118
0000757ab23cee51  mov [r15+0x100], rax
0000757ab23cee58  jmp 0x0000757AB21FE110
0000757ab23cee5d  cmp dword ptr [r15+0x318], 0x00
0000757ab23cee65  jz 0x0000757AB23CF3F0
0000757ab23cee6b  nop [rax+rax*1], ax
0000757ab23cee74  nop [rax+rax*1], eax
0000757ab23cee7c  mov eax, 0x4100A4
0000757ab23cee81  mov [r15+0x100], rax
0000757ab23cee88  jmp 0x0000757AB21FE110
0000757ab23cee8d  int3
0000757ab23cee8e  call 0x0000757AB220DC20
0000757ab23cee93  jmp 0x0000757AB23CE949
0000757ab23cee98  call 0x0000757AB22C0370
0000757ab23cee9d  jmp 0x0000757AB23CE952
0000757ab23ceea2  call 0x0000757AB22E27E0
0000757ab23ceea7  jmp 0x0000757AB23CE989
0000757ab23ceeac  call 0x0000757AB22E1570
0000757ab23ceeb1  jmp 0x0000757AB23CE992
0000757ab23ceeb6  call 0x0000757AB22E27E0
0000757ab23ceebb  jmp 0x0000757AB23CE9C9
0000757ab23ceec0  call 0x0000757AB22E1570
0000757ab23ceec5  jmp 0x0000757AB23CE9D2
0000757ab23ceeca  call 0x0000757AB22E27E0
0000757ab23ceecf  jmp 0x0000757AB23CEA09
0000757ab23ceed4  call 0x0000757AB22D59C0
0000757ab23ceed9  jmp 0x0000757AB23CEA12
0000757ab23ceede  call 0x0000757AB220DC20
0000757ab23ceee3  jmp 0x0000757AB23CEA4D
0000757ab23ceee8  call 0x0000757AB22E27E0
0000757ab23ceeed  jmp 0x0000757AB23CEA5B
0000757ab23ceef2  call 0x0000757AB22E27E0
0000757ab23ceef7  jmp 0x0000757AB23CEA6C
0000757ab23ceefc  ucomisd xmm15, xmm12
0000757ab23cef01  jp 0x0000757AB23CEF10
0000757ab23cef03  movaps xmm11, [0x0000757AB1FFE030]
0000757ab23cef0b  jmp 0x0000757AB23CEAA1
0000757ab23cef10  vxorps xmm0, xmm15, xmm12
0000757ab23cef15  pextrw r14d, xmm0, 0x03
0000757ab23cef1b  and r14d, 0x7FF8
0000757ab23cef22  cmp r14d, 0x08
0000757ab23cef26  jnz 0x0000757AB23CEAA1
0000757ab23cef2c  movq r14, xmm12
0000757ab23cef31  shl r14, 0x0D
0000757ab23cef35  jbe 0x0000757AB23CEAA1
0000757ab23cef3b  vorps xmm11, xmm12, [0x0000757AB1FFE040]
0000757ab23cef43  jmp 0x0000757AB23CEAA1
0000757ab23cef48  ucomisd xmm15, xmm14
0000757ab23cef4d  jp 0x0000757AB23CEF5C
0000757ab23cef4f  movaps xmm12, [0x0000757AB1FFE030]
0000757ab23cef57  jmp 0x0000757AB23CEAD6
0000757ab23cef5c  vxorps xmm0, xmm15, xmm14
0000757ab23cef61  pextrw r14d, xmm0, 0x03
0000757ab23cef67  and r14d, 0x7FF8
0000757ab23cef6e  cmp r14d, 0x08
0000757ab23cef72  jnz 0x0000757AB23CEAD6
0000757ab23cef78  movq r14, xmm14
0000757ab23cef7d  shl r14, 0x0D
0000757ab23cef81  jbe 0x0000757AB23CEAD6
0000757ab23cef87  vorps xmm12, xmm14, [0x0000757AB1FFE040]
0000757ab23cef8f  jmp 0x0000757AB23CEAD6
0000757ab23cef94  ucomisd xmm1, xmm15
0000757ab23cef99  jp 0x0000757AB23CEFA8
0000757ab23cef9b  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cefa3  jmp 0x0000757AB23CEB03
0000757ab23cefa8  vxorps xmm0, xmm1, xmm15
0000757ab23cefad  pextrw r14d, xmm0, 0x03
0000757ab23cefb3  and r14d, 0x7FF8
0000757ab23cefba  cmp r14d, 0x08
0000757ab23cefbe  jnz 0x0000757AB23CEB03
0000757ab23cefc4  movq r14, xmm15
0000757ab23cefc9  shl r14, 0x0D
0000757ab23cefcd  jbe 0x0000757AB23CEB03
0000757ab23cefd3  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cefdb  jmp 0x0000757AB23CEB03
0000757ab23cefe0  ucomisd xmm1, xmm15
0000757ab23cefe5  jp 0x0000757AB23CEFF4
0000757ab23cefe7  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cefef  jmp 0x0000757AB23CEB30
0000757ab23ceff4  vxorps xmm0, xmm1, xmm15
0000757ab23ceff9  pextrw r14d, xmm0, 0x03
0000757ab23cefff  and r14d, 0x7FF8
0000757ab23cf006  cmp r14d, 0x08
0000757ab23cf00a  jnz 0x0000757AB23CEB30
0000757ab23cf010  movq r14, xmm15
0000757ab23cf015  shl r14, 0x0D
0000757ab23cf019  jbe 0x0000757AB23CEB30
0000757ab23cf01f  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cf027  jmp 0x0000757AB23CEB30
0000757ab23cf02c  ucomisd xmm1, xmm15
0000757ab23cf031  jp 0x0000757AB23CF040
0000757ab23cf033  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf03b  jmp 0x0000757AB23CEB65
0000757ab23cf040  vxorps xmm0, xmm1, xmm15
0000757ab23cf045  pextrw r14d, xmm0, 0x03
0000757ab23cf04b  and r14d, 0x7FF8
0000757ab23cf052  cmp r14d, 0x08
0000757ab23cf056  jnz 0x0000757AB23CEB65
0000757ab23cf05c  movq r14, xmm15
0000757ab23cf061  shl r14, 0x0D
0000757ab23cf065  jbe 0x0000757AB23CEB65
0000757ab23cf06b  vorps xmm13, xmm15, [0x0000757AB1FFE040]
0000757ab23cf073  jmp 0x0000757AB23CEB65
0000757ab23cf078  call 0x0000757AB22E27E0
0000757ab23cf07d  jmp 0x0000757AB23CEB76
0000757ab23cf082  ucomisd xmm15, xmm14
0000757ab23cf087  jp 0x0000757AB23CF096
0000757ab23cf089  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf091  jmp 0x0000757AB23CEBA3
0000757ab23cf096  vxorps xmm0, xmm15, xmm14
0000757ab23cf09b  pextrw r14d, xmm0, 0x03
0000757ab23cf0a1  and r14d, 0x7FF8
0000757ab23cf0a8  cmp r14d, 0x08
0000757ab23cf0ac  jnz 0x0000757AB23CEBA3
0000757ab23cf0b2  movq r14, xmm14
0000757ab23cf0b7  shl r14, 0x0D
0000757ab23cf0bb  jbe 0x0000757AB23CEBA3
0000757ab23cf0c1  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cf0c9  jmp 0x0000757AB23CEBA3
0000757ab23cf0ce  ucomisd xmm1, xmm15
0000757ab23cf0d3  jp 0x0000757AB23CF0E2
0000757ab23cf0d5  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cf0dd  jmp 0x0000757AB23CEBD8
0000757ab23cf0e2  vxorps xmm0, xmm1, xmm15
0000757ab23cf0e7  pextrw r14d, xmm0, 0x03
0000757ab23cf0ed  and r14d, 0x7FF8
0000757ab23cf0f4  cmp r14d, 0x08
0000757ab23cf0f8  jnz 0x0000757AB23CEBD8
0000757ab23cf0fe  movq r14, xmm15
0000757ab23cf103  shl r14, 0x0D
0000757ab23cf107  jbe 0x0000757AB23CEBD8
0000757ab23cf10d  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cf115  jmp 0x0000757AB23CEBD8
0000757ab23cf11a  call 0x0000757AB22E27E0
0000757ab23cf11f  jmp 0x0000757AB23CEBE9
0000757ab23cf124  ucomisd xmm15, xmm14
0000757ab23cf129  jp 0x0000757AB23CF138
0000757ab23cf12b  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf133  jmp 0x0000757AB23CEC16
0000757ab23cf138  vxorps xmm0, xmm15, xmm14
0000757ab23cf13d  pextrw r14d, xmm0, 0x03
0000757ab23cf143  and r14d, 0x7FF8
0000757ab23cf14a  cmp r14d, 0x08
0000757ab23cf14e  jnz 0x0000757AB23CEC16
0000757ab23cf154  movq r14, xmm14
0000757ab23cf159  shl r14, 0x0D
0000757ab23cf15d  jbe 0x0000757AB23CEC16
0000757ab23cf163  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cf16b  jmp 0x0000757AB23CEC16
0000757ab23cf170  ucomisd xmm1, xmm15
0000757ab23cf175  jp 0x0000757AB23CF184
0000757ab23cf177  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cf17f  jmp 0x0000757AB23CEC4B
0000757ab23cf184  vxorps xmm0, xmm1, xmm15
0000757ab23cf189  pextrw r14d, xmm0, 0x03
0000757ab23cf18f  and r14d, 0x7FF8
0000757ab23cf196  cmp r14d, 0x08
0000757ab23cf19a  jnz 0x0000757AB23CEC4B
0000757ab23cf1a0  movq r14, xmm15
0000757ab23cf1a5  shl r14, 0x0D
0000757ab23cf1a9  jbe 0x0000757AB23CEC4B
0000757ab23cf1af  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cf1b7  jmp 0x0000757AB23CEC4B
0000757ab23cf1bc  call 0x0000757AB22E27E0
0000757ab23cf1c1  jmp 0x0000757AB23CEC5C
0000757ab23cf1c6  ucomisd xmm15, xmm14
0000757ab23cf1cb  jp 0x0000757AB23CF1DA
0000757ab23cf1cd  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf1d5  jmp 0x0000757AB23CEC89
0000757ab23cf1da  vxorps xmm0, xmm15, xmm14
0000757ab23cf1df  pextrw r14d, xmm0, 0x03
0000757ab23cf1e5  and r14d, 0x7FF8
0000757ab23cf1ec  cmp r14d, 0x08
0000757ab23cf1f0  jnz 0x0000757AB23CEC89
0000757ab23cf1f6  movq r14, xmm14
0000757ab23cf1fb  shl r14, 0x0D
0000757ab23cf1ff  jbe 0x0000757AB23CEC89
0000757ab23cf205  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cf20d  jmp 0x0000757AB23CEC89
0000757ab23cf212  ucomisd xmm1, xmm15
0000757ab23cf217  jp 0x0000757AB23CF226
0000757ab23cf219  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cf221  jmp 0x0000757AB23CECBE
0000757ab23cf226  vxorps xmm0, xmm1, xmm15
0000757ab23cf22b  pextrw r14d, xmm0, 0x03
0000757ab23cf231  and r14d, 0x7FF8
0000757ab23cf238  cmp r14d, 0x08
0000757ab23cf23c  jnz 0x0000757AB23CECBE
0000757ab23cf242  movq r14, xmm15
0000757ab23cf247  shl r14, 0x0D
0000757ab23cf24b  jbe 0x0000757AB23CECBE
0000757ab23cf251  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cf259  jmp 0x0000757AB23CECBE
0000757ab23cf25e  call 0x0000757AB22E27E0
0000757ab23cf263  jmp 0x0000757AB23CECCF
0000757ab23cf268  ucomisd xmm15, xmm14
0000757ab23cf26d  jp 0x0000757AB23CF27C
0000757ab23cf26f  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf277  jmp 0x0000757AB23CECFC
0000757ab23cf27c  vxorps xmm0, xmm15, xmm14
0000757ab23cf281  pextrw r14d, xmm0, 0x03
0000757ab23cf287  and r14d, 0x7FF8
0000757ab23cf28e  cmp r14d, 0x08
0000757ab23cf292  jnz 0x0000757AB23CECFC
0000757ab23cf298  movq r14, xmm14
0000757ab23cf29d  shl r14, 0x0D
0000757ab23cf2a1  jbe 0x0000757AB23CECFC
0000757ab23cf2a7  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cf2af  jmp 0x0000757AB23CECFC
0000757ab23cf2b4  ucomisd xmm1, xmm15
0000757ab23cf2b9  jp 0x0000757AB23CF2C8
0000757ab23cf2bb  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cf2c3  jmp 0x0000757AB23CED31
0000757ab23cf2c8  vxorps xmm0, xmm1, xmm15
0000757ab23cf2cd  pextrw r14d, xmm0, 0x03
0000757ab23cf2d3  and r14d, 0x7FF8
0000757ab23cf2da  cmp r14d, 0x08
0000757ab23cf2de  jnz 0x0000757AB23CED31
0000757ab23cf2e4  movq r14, xmm15
0000757ab23cf2e9  shl r14, 0x0D
0000757ab23cf2ed  jbe 0x0000757AB23CED31
0000757ab23cf2f3  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cf2fb  jmp 0x0000757AB23CED31
0000757ab23cf300  call 0x0000757AB22D59C0
0000757ab23cf305  jmp 0x0000757AB23CED42
0000757ab23cf30a  ucomisd xmm15, xmm14
0000757ab23cf30f  jp 0x0000757AB23CF31E
0000757ab23cf311  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf319  jmp 0x0000757AB23CED77
0000757ab23cf31e  vxorps xmm0, xmm15, xmm14
0000757ab23cf323  pextrw eax, xmm0, 0x03
0000757ab23cf328  and eax, 0x7FF8
0000757ab23cf32d  cmp eax, 0x08
0000757ab23cf330  jnz 0x0000757AB23CED77
0000757ab23cf336  movq rax, xmm14
0000757ab23cf33b  shl rax, 0x0D
0000757ab23cf33f  jbe 0x0000757AB23CED77
0000757ab23cf345  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cf34d  jmp 0x0000757AB23CED77
0000757ab23cf352  ucomisd xmm1, xmm15
0000757ab23cf357  jp 0x0000757AB23CF366
0000757ab23cf359  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cf361  jmp 0x0000757AB23CEDAC
0000757ab23cf366  vxorps xmm0, xmm1, xmm15
0000757ab23cf36b  pextrw eax, xmm0, 0x03
0000757ab23cf370  and eax, 0x7FF8
0000757ab23cf375  cmp eax, 0x08
0000757ab23cf378  jnz 0x0000757AB23CEDAC
0000757ab23cf37e  movq rax, xmm15
0000757ab23cf383  shl rax, 0x0D
0000757ab23cf387  jbe 0x0000757AB23CEDAC
0000757ab23cf38d  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cf395  jmp 0x0000757AB23CEDAC
0000757ab23cf39a  ucomisd xmm1, xmm15
0000757ab23cf39f  jp 0x0000757AB23CF3AE
0000757ab23cf3a1  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cf3a9  jmp 0x0000757AB23CEDE1
0000757ab23cf3ae  vxorps xmm0, xmm1, xmm15
0000757ab23cf3b3  pextrw eax, xmm0, 0x03
0000757ab23cf3b8  and eax, 0x7FF8
0000757ab23cf3bd  cmp eax, 0x08
0000757ab23cf3c0  jnz 0x0000757AB23CEDE1
0000757ab23cf3c6  movq rax, xmm15
0000757ab23cf3cb  shl rax, 0x0D
0000757ab23cf3cf  jbe 0x0000757AB23CEDE1
0000757ab23cf3d5  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cf3dd  jmp 0x0000757AB23CEDE1
0000757ab23cf3e2  call 0x0000757AB22D5EB0
0000757ab23cf3e7  jmp 0x0000757AB23CEDFE
0000757ab23cf3ec  int3
0000757ab23cf3ed  nop [rax], eax
0000757ab23cf3f0  mov rax, [r15+0x48]
0000757ab23cf3f4  mov r14, [r15+0x70]
0000757ab23cf3f8  lea r12, [rax+r14*1]
0000757ab23cf3fc  mov [r15+0x78], r12
0000757ab23cf400  mov rax, [r13+r12*1]
0000757ab23cf405  movq xmm1, rax
0000757ab23cf40a  lea rax, [r12+0x40]
0000757ab23cf40f  mov r11, [r13+rax*1]
0000757ab23cf414  movq xmm15, r11
0000757ab23cf419  lea rax, [r12+0x80]
0000757ab23cf421  mov r11, [r13+rax*1]
0000757ab23cf426  movq xmm14, r11
0000757ab23cf42b  movaps xmm13, [r15+0x120]
0000757ab23cf433  movq rax, xmm13
0000757ab23cf438  movq r11, xmm1
0000757ab23cf43d  vmovq xmm1, rax
0000757ab23cf442  vmovq xmm13, r11
0000757ab23cf447  movaps xmm12, xmm1
0000757ab23cf44b  mulsd xmm12, xmm13
0000757ab23cf450  ucomisd xmm12, xmm12
0000757ab23cf455  jp 0x0000757AB23CF879
0000757ab23cf45b  movq xmm12, xmm12
0000757ab23cf460  movaps xmm1, [r15+0x130]
0000757ab23cf468  movq rax, xmm1
0000757ab23cf46d  movq r11, xmm15
0000757ab23cf472  vmovq xmm1, rax
0000757ab23cf477  vmovq xmm15, r11
0000757ab23cf47c  movaps xmm13, xmm1
0000757ab23cf480  mulsd xmm13, xmm15
0000757ab23cf485  ucomisd xmm13, xmm13
0000757ab23cf48a  jp 0x0000757AB23CF8C1
0000757ab23cf490  movq xmm13, xmm13
0000757ab23cf495  movq rax, xmm12
0000757ab23cf49a  movaps xmm1, [r15+0x110]
0000757ab23cf4a2  movq r11, xmm1
0000757ab23cf4a7  vmovq xmm1, rax
0000757ab23cf4ac  vmovq xmm15, r11
0000757ab23cf4b1  movaps xmm12, xmm1
0000757ab23cf4b5  addsd xmm12, xmm15
0000757ab23cf4ba  ucomisd xmm12, xmm12
0000757ab23cf4bf  jp 0x0000757AB23CF909
0000757ab23cf4c5  movq xmm12, xmm12
0000757ab23cf4ca  movq rax, xmm12
0000757ab23cf4cf  movq r11, xmm13
0000757ab23cf4d4  vmovq xmm1, rax
0000757ab23cf4d9  vmovq xmm15, r11
0000757ab23cf4de  movaps xmm13, xmm1
0000757ab23cf4e2  addsd xmm13, xmm15
0000757ab23cf4e7  ucomisd xmm13, xmm13
0000757ab23cf4ec  jp 0x0000757AB23CF951
0000757ab23cf4f2  movq xmm13, xmm13
0000757ab23cf4f7  movaps xmm1, [r15+0x140]
0000757ab23cf4ff  movq rax, xmm1
0000757ab23cf504  movq r11, xmm14
0000757ab23cf509  vmovq xmm1, rax
0000757ab23cf50e  vmovq xmm15, r11
0000757ab23cf513  movaps xmm14, xmm1
0000757ab23cf517  mulsd xmm14, xmm15
0000757ab23cf51c  ucomisd xmm14, xmm14
0000757ab23cf521  jp 0x0000757AB23CF999
0000757ab23cf527  movq xmm14, xmm14
0000757ab23cf52c  lea rax, [r12+0xC0]
0000757ab23cf534  mov r11, [r13+rax*1]
0000757ab23cf539  movq xmm1, r11
0000757ab23cf53e  movq rax, xmm13
0000757ab23cf543  movq r11, xmm14
0000757ab23cf548  vmovq xmm15, rax
0000757ab23cf54d  vmovq xmm14, r11
0000757ab23cf552  movaps xmm13, xmm15
0000757ab23cf556  addsd xmm13, xmm14
0000757ab23cf55b  ucomisd xmm13, xmm13
0000757ab23cf560  jp 0x0000757AB23CF9EB
0000757ab23cf566  movq xmm13, xmm13
0000757ab23cf56b  movaps xmm15, [r15+0x150]
0000757ab23cf573  movq rax, xmm15
0000757ab23cf578  movq r11, xmm1
0000757ab23cf57d  vmovq xmm1, rax
0000757ab23cf582  vmovq xmm15, r11
0000757ab23cf587  movaps xmm14, xmm1
0000757ab23cf58b  mulsd xmm14, xmm15
0000757ab23cf590  ucomisd xmm14, xmm14
0000757ab23cf595  jp 0x0000757AB23CFA33
0000757ab23cf59b  movq xmm14, xmm14
0000757ab23cf5a0  lea rax, [r12+0x100]
0000757ab23cf5a8  mov r11, [r13+rax*1]
0000757ab23cf5ad  movq xmm1, r11
0000757ab23cf5b2  movq rax, xmm13
0000757ab23cf5b7  movq r11, xmm14
0000757ab23cf5bc  vmovq xmm15, rax
0000757ab23cf5c1  vmovq xmm14, r11
0000757ab23cf5c6  movaps xmm13, xmm15
0000757ab23cf5ca  addsd xmm13, xmm14
0000757ab23cf5cf  ucomisd xmm13, xmm13
0000757ab23cf5d4  jp 0x0000757AB23CFA85
0000757ab23cf5da  movq xmm13, xmm13
0000757ab23cf5df  movaps xmm15, [r15+0x160]
0000757ab23cf5e7  movq rax, xmm15
0000757ab23cf5ec  movq r11, xmm1
0000757ab23cf5f1  vmovq xmm1, rax
0000757ab23cf5f6  vmovq xmm15, r11
0000757ab23cf5fb  movaps xmm14, xmm1
0000757ab23cf5ff  mulsd xmm14, xmm15
0000757ab23cf604  ucomisd xmm14, xmm14
0000757ab23cf609  jp 0x0000757AB23CFACD
0000757ab23cf60f  movq xmm14, xmm14
0000757ab23cf614  lea rax, [r12+0x140]
0000757ab23cf61c  mov r11, [r13+rax*1]
0000757ab23cf621  movq xmm1, r11
0000757ab23cf626  movq rax, xmm13
0000757ab23cf62b  movq r11, xmm14
0000757ab23cf630  vmovq xmm15, rax
0000757ab23cf635  vmovq xmm14, r11
0000757ab23cf63a  movaps xmm13, xmm15
0000757ab23cf63e  addsd xmm13, xmm14
0000757ab23cf643  ucomisd xmm13, xmm13
0000757ab23cf648  jp 0x0000757AB23CFB1F
0000757ab23cf64e  movq xmm13, xmm13
0000757ab23cf653  movaps xmm15, [r15+0x170]
0000757ab23cf65b  movq rax, xmm15
0000757ab23cf660  movq r11, xmm1
0000757ab23cf665  vmovq xmm1, rax
0000757ab23cf66a  vmovq xmm15, r11
0000757ab23cf66f  movaps xmm14, xmm1
0000757ab23cf673  mulsd xmm14, xmm15
0000757ab23cf678  ucomisd xmm14, xmm14
0000757ab23cf67d  jp 0x0000757AB23CFB67
0000757ab23cf683  movq xmm14, xmm14
0000757ab23cf688  lea rax, [r12+0x180]
0000757ab23cf690  mov r11, [r13+rax*1]
0000757ab23cf695  movq xmm1, r11
0000757ab23cf69a  movq rax, xmm13
0000757ab23cf69f  movq r11, xmm14
0000757ab23cf6a4  vmovq xmm15, rax
0000757ab23cf6a9  vmovq xmm14, r11
0000757ab23cf6ae  movaps xmm13, xmm15
0000757ab23cf6b2  addsd xmm13, xmm14
0000757ab23cf6b7  ucomisd xmm13, xmm13
0000757ab23cf6bc  jp 0x0000757AB23CFBB9
0000757ab23cf6c2  movq xmm13, xmm13
0000757ab23cf6c7  movaps xmm15, [r15+0x180]
0000757ab23cf6cf  movq rax, xmm15
0000757ab23cf6d4  movq r11, xmm1
0000757ab23cf6d9  vmovq xmm1, rax
0000757ab23cf6de  vmovq xmm15, r11
0000757ab23cf6e3  movaps xmm14, xmm1
0000757ab23cf6e7  mulsd xmm14, xmm15
0000757ab23cf6ec  ucomisd xmm14, xmm14
0000757ab23cf6f1  jp 0x0000757AB23CFC01
0000757ab23cf6f7  movq xmm14, xmm14
0000757ab23cf6fc  lea rax, [r12+0x1C0]
0000757ab23cf704  mov r12, [r13+rax*1]
0000757ab23cf709  movq xmm1, r12
0000757ab23cf70e  movaps [r15+0x240], xmm1
0000757ab23cf716  movq rax, xmm13
0000757ab23cf71b  movq r12, xmm14
0000757ab23cf720  vmovq xmm15, rax
0000757ab23cf725  vmovq xmm14, r12
0000757ab23cf72a  movaps xmm13, xmm15
0000757ab23cf72e  addsd xmm13, xmm14
0000757ab23cf733  ucomisd xmm13, xmm13
0000757ab23cf738  jp 0x0000757AB23CFC53
0000757ab23cf73e  movq xmm13, xmm13
0000757ab23cf743  movaps xmm15, [r15+0x210]
0000757ab23cf74b  movq rax, xmm15
0000757ab23cf750  movq r12, xmm1
0000757ab23cf755  vmovq xmm1, rax
0000757ab23cf75a  vmovq xmm15, r12
0000757ab23cf75f  movaps xmm14, xmm1
0000757ab23cf763  mulsd xmm14, xmm15
0000757ab23cf768  ucomisd xmm14, xmm14
0000757ab23cf76d  jp 0x0000757AB23CFC9B
0000757ab23cf773  movq xmm14, xmm14
0000757ab23cf778  movaps [r15+0x230], xmm14
0000757ab23cf780  movq rax, xmm13
0000757ab23cf785  movq r12, xmm14
0000757ab23cf78a  vmovq xmm1, rax
0000757ab23cf78f  vmovq xmm15, r12
0000757ab23cf794  movaps xmm14, xmm1
0000757ab23cf798  addsd xmm14, xmm15
0000757ab23cf79d  ucomisd xmm14, xmm14
0000757ab23cf7a2  jp 0x0000757AB23CFCE3
0000757ab23cf7a8  movq xmm14, xmm14
0000757ab23cf7ad  movaps [r15+0x220], xmm14
0000757ab23cf7b5  mov rax, [r15+0x68]
0000757ab23cf7b9  lea r12, [rax+r14*1]
0000757ab23cf7bd  movq rax, xmm14
0000757ab23cf7c2  mov [r13+r12*1], rax
0000757ab23cf7c7  lea rax, [r14+0x08]
0000757ab23cf7cb  mov [r15+0x70], rax
0000757ab23cf7cf  mov [rsp+0x10], rax
0000757ab23cf7d4  xor eax, eax
0000757ab23cf7d6  mov r14, [rsp+0x10]
0000757ab23cf7db  mov r12d, 0x40
0000757ab23cf7e1  cmp r14, r12
0000757ab23cf7e4  cmc
0000757ab23cf7e5  lahf
0000757ab23cf7e6  seto al
0000757ab23cf7e9  mov [r15+0x108], eax
0000757ab23cf7f0  mov eax, [r15+0x108]
0000757ab23cf7f7  sahf
0000757ab23cf7f8  jnz 0x0000757AB23CF82A
0000757ab23cf7fa  cmp dword ptr [r15+0x318], 0x00
0000757ab23cf802  jz 0x0000757AB23CFD40
0000757ab23cf808  nop [rax+rax*1], ax
0000757ab23cf811  nop [rax+rax*1], eax
0000757ab23cf819  mov eax, 0x410118
0000757ab23cf81e  mov [r15+0x100], rax
0000757ab23cf825  jmp 0x0000757AB21FE110
0000757ab23cf82a  cmp dword ptr [r15+0x318], 0x00
0000757ab23cf832  jz 0x0000757AB23CF3F0
0000757ab23cf838  nop [rax+rax*1], ax
0000757ab23cf841  nop [rax+rax*1], eax
0000757ab23cf849  mov eax, 0x4100A4
0000757ab23cf84e  mov [r15+0x100], rax
0000757ab23cf855  jmp 0x0000757AB21FE110
0000757ab23cf85a  int3
0000757ab23cf85b  call 0x0000757AB22B47C0
0000757ab23cf860  jmp 0x0000757AB23CF405
0000757ab23cf865  call 0x0000757AB220A4B0
0000757ab23cf86a  jmp 0x0000757AB23CF414
0000757ab23cf86f  call 0x0000757AB220A4B0
0000757ab23cf874  jmp 0x0000757AB23CF426
0000757ab23cf879  ucomisd xmm1, xmm13
0000757ab23cf87e  jp 0x0000757AB23CF88D
0000757ab23cf880  movaps xmm12, [0x0000757AB1FFE030]
0000757ab23cf888  jmp 0x0000757AB23CF45B
0000757ab23cf88d  vxorps xmm0, xmm1, xmm13
0000757ab23cf892  pextrw eax, xmm0, 0x03
0000757ab23cf897  and eax, 0x7FF8
0000757ab23cf89c  cmp eax, 0x08
0000757ab23cf89f  jnz 0x0000757AB23CF45B
0000757ab23cf8a5  movq rax, xmm13
0000757ab23cf8aa  shl rax, 0x0D
0000757ab23cf8ae  jbe 0x0000757AB23CF45B
0000757ab23cf8b4  vorps xmm12, xmm13, [0x0000757AB1FFE040]
0000757ab23cf8bc  jmp 0x0000757AB23CF45B
0000757ab23cf8c1  ucomisd xmm1, xmm15
0000757ab23cf8c6  jp 0x0000757AB23CF8D5
0000757ab23cf8c8  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf8d0  jmp 0x0000757AB23CF490
0000757ab23cf8d5  vxorps xmm0, xmm1, xmm15
0000757ab23cf8da  pextrw eax, xmm0, 0x03
0000757ab23cf8df  and eax, 0x7FF8
0000757ab23cf8e4  cmp eax, 0x08
0000757ab23cf8e7  jnz 0x0000757AB23CF490
0000757ab23cf8ed  movq rax, xmm15
0000757ab23cf8f2  shl rax, 0x0D
0000757ab23cf8f6  jbe 0x0000757AB23CF490
0000757ab23cf8fc  vorps xmm13, xmm15, [0x0000757AB1FFE040]
0000757ab23cf904  jmp 0x0000757AB23CF490
0000757ab23cf909  ucomisd xmm1, xmm15
0000757ab23cf90e  jp 0x0000757AB23CF91D
0000757ab23cf910  movaps xmm12, [0x0000757AB1FFE030]
0000757ab23cf918  jmp 0x0000757AB23CF4C5
0000757ab23cf91d  vxorps xmm0, xmm1, xmm15
0000757ab23cf922  pextrw eax, xmm0, 0x03
0000757ab23cf927  and eax, 0x7FF8
0000757ab23cf92c  cmp eax, 0x08
0000757ab23cf92f  jnz 0x0000757AB23CF4C5
0000757ab23cf935  movq rax, xmm15
0000757ab23cf93a  shl rax, 0x0D
0000757ab23cf93e  jbe 0x0000757AB23CF4C5
0000757ab23cf944  vorps xmm12, xmm15, [0x0000757AB1FFE040]
0000757ab23cf94c  jmp 0x0000757AB23CF4C5
0000757ab23cf951  ucomisd xmm1, xmm15
0000757ab23cf956  jp 0x0000757AB23CF965
0000757ab23cf958  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf960  jmp 0x0000757AB23CF4F2
0000757ab23cf965  vxorps xmm0, xmm1, xmm15
0000757ab23cf96a  pextrw eax, xmm0, 0x03
0000757ab23cf96f  and eax, 0x7FF8
0000757ab23cf974  cmp eax, 0x08
0000757ab23cf977  jnz 0x0000757AB23CF4F2
0000757ab23cf97d  movq rax, xmm15
0000757ab23cf982  shl rax, 0x0D
0000757ab23cf986  jbe 0x0000757AB23CF4F2
0000757ab23cf98c  vorps xmm13, xmm15, [0x0000757AB1FFE040]
0000757ab23cf994  jmp 0x0000757AB23CF4F2
0000757ab23cf999  ucomisd xmm1, xmm15
0000757ab23cf99e  jp 0x0000757AB23CF9AD
0000757ab23cf9a0  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cf9a8  jmp 0x0000757AB23CF527
0000757ab23cf9ad  vxorps xmm0, xmm1, xmm15
0000757ab23cf9b2  pextrw eax, xmm0, 0x03
0000757ab23cf9b7  and eax, 0x7FF8
0000757ab23cf9bc  cmp eax, 0x08
0000757ab23cf9bf  jnz 0x0000757AB23CF527
0000757ab23cf9c5  movq rax, xmm15
0000757ab23cf9ca  shl rax, 0x0D
0000757ab23cf9ce  jbe 0x0000757AB23CF527
0000757ab23cf9d4  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cf9dc  jmp 0x0000757AB23CF527
0000757ab23cf9e1  call 0x0000757AB220A4B0
0000757ab23cf9e6  jmp 0x0000757AB23CF539
0000757ab23cf9eb  ucomisd xmm15, xmm14
0000757ab23cf9f0  jp 0x0000757AB23CF9FF
0000757ab23cf9f2  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cf9fa  jmp 0x0000757AB23CF566
0000757ab23cf9ff  vxorps xmm0, xmm15, xmm14
0000757ab23cfa04  pextrw eax, xmm0, 0x03
0000757ab23cfa09  and eax, 0x7FF8
0000757ab23cfa0e  cmp eax, 0x08
0000757ab23cfa11  jnz 0x0000757AB23CF566
0000757ab23cfa17  movq rax, xmm14
0000757ab23cfa1c  shl rax, 0x0D
0000757ab23cfa20  jbe 0x0000757AB23CF566
0000757ab23cfa26  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cfa2e  jmp 0x0000757AB23CF566
0000757ab23cfa33  ucomisd xmm1, xmm15
0000757ab23cfa38  jp 0x0000757AB23CFA47
0000757ab23cfa3a  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cfa42  jmp 0x0000757AB23CF59B
0000757ab23cfa47  vxorps xmm0, xmm1, xmm15
0000757ab23cfa4c  pextrw eax, xmm0, 0x03
0000757ab23cfa51  and eax, 0x7FF8
0000757ab23cfa56  cmp eax, 0x08
0000757ab23cfa59  jnz 0x0000757AB23CF59B
0000757ab23cfa5f  movq rax, xmm15
0000757ab23cfa64  shl rax, 0x0D
0000757ab23cfa68  jbe 0x0000757AB23CF59B
0000757ab23cfa6e  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cfa76  jmp 0x0000757AB23CF59B
0000757ab23cfa7b  call 0x0000757AB220A4B0
0000757ab23cfa80  jmp 0x0000757AB23CF5AD
0000757ab23cfa85  ucomisd xmm15, xmm14
0000757ab23cfa8a  jp 0x0000757AB23CFA99
0000757ab23cfa8c  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cfa94  jmp 0x0000757AB23CF5DA
0000757ab23cfa99  vxorps xmm0, xmm15, xmm14
0000757ab23cfa9e  pextrw eax, xmm0, 0x03
0000757ab23cfaa3  and eax, 0x7FF8
0000757ab23cfaa8  cmp eax, 0x08
0000757ab23cfaab  jnz 0x0000757AB23CF5DA
0000757ab23cfab1  movq rax, xmm14
0000757ab23cfab6  shl rax, 0x0D
0000757ab23cfaba  jbe 0x0000757AB23CF5DA
0000757ab23cfac0  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cfac8  jmp 0x0000757AB23CF5DA
0000757ab23cfacd  ucomisd xmm1, xmm15
0000757ab23cfad2  jp 0x0000757AB23CFAE1
0000757ab23cfad4  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cfadc  jmp 0x0000757AB23CF60F
0000757ab23cfae1  vxorps xmm0, xmm1, xmm15
0000757ab23cfae6  pextrw eax, xmm0, 0x03
0000757ab23cfaeb  and eax, 0x7FF8
0000757ab23cfaf0  cmp eax, 0x08
0000757ab23cfaf3  jnz 0x0000757AB23CF60F
0000757ab23cfaf9  movq rax, xmm15
0000757ab23cfafe  shl rax, 0x0D
0000757ab23cfb02  jbe 0x0000757AB23CF60F
0000757ab23cfb08  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cfb10  jmp 0x0000757AB23CF60F
0000757ab23cfb15  call 0x0000757AB220A4B0
0000757ab23cfb1a  jmp 0x0000757AB23CF621
0000757ab23cfb1f  ucomisd xmm15, xmm14
0000757ab23cfb24  jp 0x0000757AB23CFB33
0000757ab23cfb26  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cfb2e  jmp 0x0000757AB23CF64E
0000757ab23cfb33  vxorps xmm0, xmm15, xmm14
0000757ab23cfb38  pextrw eax, xmm0, 0x03
0000757ab23cfb3d  and eax, 0x7FF8
0000757ab23cfb42  cmp eax, 0x08
0000757ab23cfb45  jnz 0x0000757AB23CF64E
0000757ab23cfb4b  movq rax, xmm14
0000757ab23cfb50  shl rax, 0x0D
0000757ab23cfb54  jbe 0x0000757AB23CF64E
0000757ab23cfb5a  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cfb62  jmp 0x0000757AB23CF64E
0000757ab23cfb67  ucomisd xmm1, xmm15
0000757ab23cfb6c  jp 0x0000757AB23CFB7B
0000757ab23cfb6e  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cfb76  jmp 0x0000757AB23CF683
0000757ab23cfb7b  vxorps xmm0, xmm1, xmm15
0000757ab23cfb80  pextrw eax, xmm0, 0x03
0000757ab23cfb85  and eax, 0x7FF8
0000757ab23cfb8a  cmp eax, 0x08
0000757ab23cfb8d  jnz 0x0000757AB23CF683
0000757ab23cfb93  movq rax, xmm15
0000757ab23cfb98  shl rax, 0x0D
0000757ab23cfb9c  jbe 0x0000757AB23CF683
0000757ab23cfba2  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cfbaa  jmp 0x0000757AB23CF683
0000757ab23cfbaf  call 0x0000757AB220A4B0
0000757ab23cfbb4  jmp 0x0000757AB23CF695
0000757ab23cfbb9  ucomisd xmm15, xmm14
0000757ab23cfbbe  jp 0x0000757AB23CFBCD
0000757ab23cfbc0  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cfbc8  jmp 0x0000757AB23CF6C2
0000757ab23cfbcd  vxorps xmm0, xmm15, xmm14
0000757ab23cfbd2  pextrw eax, xmm0, 0x03
0000757ab23cfbd7  and eax, 0x7FF8
0000757ab23cfbdc  cmp eax, 0x08
0000757ab23cfbdf  jnz 0x0000757AB23CF6C2
0000757ab23cfbe5  movq rax, xmm14
0000757ab23cfbea  shl rax, 0x0D
0000757ab23cfbee  jbe 0x0000757AB23CF6C2
0000757ab23cfbf4  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cfbfc  jmp 0x0000757AB23CF6C2
0000757ab23cfc01  ucomisd xmm1, xmm15
0000757ab23cfc06  jp 0x0000757AB23CFC15
0000757ab23cfc08  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cfc10  jmp 0x0000757AB23CF6F7
0000757ab23cfc15  vxorps xmm0, xmm1, xmm15
0000757ab23cfc1a  pextrw eax, xmm0, 0x03
0000757ab23cfc1f  and eax, 0x7FF8
0000757ab23cfc24  cmp eax, 0x08
0000757ab23cfc27  jnz 0x0000757AB23CF6F7
0000757ab23cfc2d  movq rax, xmm15
0000757ab23cfc32  shl rax, 0x0D
0000757ab23cfc36  jbe 0x0000757AB23CF6F7
0000757ab23cfc3c  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cfc44  jmp 0x0000757AB23CF6F7
0000757ab23cfc49  call 0x0000757AB220B720
0000757ab23cfc4e  jmp 0x0000757AB23CF709
0000757ab23cfc53  ucomisd xmm15, xmm14
0000757ab23cfc58  jp 0x0000757AB23CFC67
0000757ab23cfc5a  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23cfc62  jmp 0x0000757AB23CF73E
0000757ab23cfc67  vxorps xmm0, xmm15, xmm14
0000757ab23cfc6c  pextrw eax, xmm0, 0x03
0000757ab23cfc71  and eax, 0x7FF8
0000757ab23cfc76  cmp eax, 0x08
0000757ab23cfc79  jnz 0x0000757AB23CF73E
0000757ab23cfc7f  movq rax, xmm14
0000757ab23cfc84  shl rax, 0x0D
0000757ab23cfc88  jbe 0x0000757AB23CF73E
0000757ab23cfc8e  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23cfc96  jmp 0x0000757AB23CF73E
0000757ab23cfc9b  ucomisd xmm1, xmm15
0000757ab23cfca0  jp 0x0000757AB23CFCAF
0000757ab23cfca2  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cfcaa  jmp 0x0000757AB23CF773
0000757ab23cfcaf  vxorps xmm0, xmm1, xmm15
0000757ab23cfcb4  pextrw eax, xmm0, 0x03
0000757ab23cfcb9  and eax, 0x7FF8
0000757ab23cfcbe  cmp eax, 0x08
0000757ab23cfcc1  jnz 0x0000757AB23CF773
0000757ab23cfcc7  movq rax, xmm15
0000757ab23cfccc  shl rax, 0x0D
0000757ab23cfcd0  jbe 0x0000757AB23CF773
0000757ab23cfcd6  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cfcde  jmp 0x0000757AB23CF773
0000757ab23cfce3  ucomisd xmm1, xmm15
0000757ab23cfce8  jp 0x0000757AB23CFCF7
0000757ab23cfcea  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23cfcf2  jmp 0x0000757AB23CF7A8
0000757ab23cfcf7  vxorps xmm0, xmm1, xmm15
0000757ab23cfcfc  pextrw eax, xmm0, 0x03
0000757ab23cfd01  and eax, 0x7FF8
0000757ab23cfd06  cmp eax, 0x08
0000757ab23cfd09  jnz 0x0000757AB23CF7A8
0000757ab23cfd0f  movq rax, xmm15
0000757ab23cfd14  shl rax, 0x0D
0000757ab23cfd18  jbe 0x0000757AB23CF7A8
0000757ab23cfd1e  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23cfd26  jmp 0x0000757AB23CF7A8
0000757ab23cfd2b  call 0x0000757AB22B4CB0
0000757ab23cfd30  jmp 0x0000757AB23CF7C7
0000757ab23cfd35  int3
0000757ab23cfd36  nop [rax+rax*1], ax
0000757ab23cfd3f  nop
0000757ab23cfd40  mov rax, [r15+0x60]
0000757ab23cfd44  lea r14, [rax+0x01]
0000757ab23cfd48  mov [r15+0x60], r14
0000757ab23cfd4c  mov rax, [r15+0x68]
0000757ab23cfd50  lea r12, [rax+0x40]
0000757ab23cfd54  mov [r15+0x68], r12
0000757ab23cfd58  xor eax, eax
0000757ab23cfd5a  mov r12d, 0x08
0000757ab23cfd60  cmp r14, r12
0000757ab23cfd63  cmc
0000757ab23cfd64  lahf
0000757ab23cfd65  seto al
0000757ab23cfd68  mov [r15+0x108], eax
0000757ab23cfd6f  mov eax, [r15+0x108]
0000757ab23cfd76  sahf
0000757ab23cfd77  jnz 0x0000757AB23CFDA9
0000757ab23cfd79  cmp dword ptr [r15+0x318], 0x00
0000757ab23cfd81  jz 0x0000757AB23D08A0
0000757ab23cfd87  nop [rax+rax*1], ax
0000757ab23cfd90  nop [rax+rax*1], eax
0000757ab23cfd98  mov eax, 0x410128
0000757ab23cfd9d  mov [r15+0x100], rax
0000757ab23cfda4  jmp 0x0000757AB21FE110
0000757ab23cfda9  cmp dword ptr [r15+0x318], 0x00
0000757ab23cfdb1  jz 0x0000757AB23CFDE0
0000757ab23cfdb7  nop [rax+rax*1], ax
0000757ab23cfdc0  nop [rax+rax*1], eax
0000757ab23cfdc8  mov eax, 0x41008C
0000757ab23cfdcd  mov [r15+0x100], rax
0000757ab23cfdd4  jmp 0x0000757AB21FE110
0000757ab23cfdd9  int3
0000757ab23cfdda  int3
0000757ab23cfddb  nop [rax+rax*1], eax
0000757ab23cfde0  mov rax, [r15+0x40]
0000757ab23cfde4  mov r14, [r15+0x60]
0000757ab23cfde8  shl r14, 0x06
0000757ab23cfdec  lea r12, [rax+r14*1]
0000757ab23cfdf0  mov rax, [r13+r12*1]
0000757ab23cfdf5  lea r14, [r12+0x08]
0000757ab23cfdfa  mov r11, [r13+r14*1]
0000757ab23cfdff  movq xmm1, rax
0000757ab23cfe04  movq xmm15, r11
0000757ab23cfe09  movq xmm1, xmm1
0000757ab23cfe0d  movq xmm1, xmm1
0000757ab23cfe11  movaps [r15+0x120], xmm1
0000757ab23cfe19  movq xmm15, xmm15
0000757ab23cfe1e  movq xmm15, xmm15
0000757ab23cfe23  movaps [r15+0x130], xmm15
0000757ab23cfe2b  lea rax, [r12+0x10]
0000757ab23cfe30  mov r14, [r13+rax*1]
0000757ab23cfe35  lea rax, [r12+0x18]
0000757ab23cfe3a  mov r11, [r13+rax*1]
0000757ab23cfe3f  movq xmm1, r14
0000757ab23cfe44  movq xmm15, r11
0000757ab23cfe49  movq xmm1, xmm1
0000757ab23cfe4d  movq xmm1, xmm1
0000757ab23cfe51  movaps [r15+0x140], xmm1
0000757ab23cfe59  movq xmm15, xmm15
0000757ab23cfe5e  movq xmm15, xmm15
0000757ab23cfe63  movaps [r15+0x150], xmm15
0000757ab23cfe6b  lea rax, [r12+0x20]
0000757ab23cfe70  mov r14, [r13+rax*1]
0000757ab23cfe75  lea rax, [r12+0x28]
0000757ab23cfe7a  mov r11, [r13+rax*1]
0000757ab23cfe7f  movq xmm1, r14
0000757ab23cfe84  movq xmm15, r11
0000757ab23cfe89  movq xmm1, xmm1
0000757ab23cfe8d  movq xmm1, xmm1
0000757ab23cfe91  movaps [r15+0x160], xmm1
0000757ab23cfe99  movq xmm15, xmm15
0000757ab23cfe9e  movq xmm15, xmm15
0000757ab23cfea3  movaps [r15+0x170], xmm15
0000757ab23cfeab  lea rax, [r12+0x30]
0000757ab23cfeb0  mov r14, [r13+rax*1]
0000757ab23cfeb5  lea rax, [r12+0x38]
0000757ab23cfeba  mov r12, [r13+rax*1]
0000757ab23cfebf  movq xmm1, r14
0000757ab23cfec4  movq xmm15, r12
0000757ab23cfec9  movq xmm1, xmm1
0000757ab23cfecd  movq xmm1, xmm1
0000757ab23cfed1  movaps [r15+0x180], xmm1
0000757ab23cfed9  movq xmm15, xmm15
0000757ab23cfede  movq xmm15, xmm15
0000757ab23cfee3  movaps [r15+0x210], xmm15
0000757ab23cfeeb  mov rax, [r15+0x48]
0000757ab23cfeef  mov [r15+0x78], rax
0000757ab23cfef3  mov r14, [r13+rax*1]
0000757ab23cfef8  movq xmm1, r14
0000757ab23cfefd  lea r14, [rax+0x40]
0000757ab23cff01  mov r12, [r13+r14*1]
0000757ab23cff06  movq xmm15, r12
0000757ab23cff0b  lea r14, [rax+0x80]
0000757ab23cff12  mov r12, [r13+r14*1]
0000757ab23cff17  movq xmm14, r12
0000757ab23cff1c  movaps xmm13, [r15+0x120]
0000757ab23cff24  movq r14, xmm13
0000757ab23cff29  movq r12, xmm1
0000757ab23cff2e  vmovq xmm1, r14
0000757ab23cff33  vmovq xmm13, r12
0000757ab23cff38  movaps xmm12, xmm1
0000757ab23cff3c  mulsd xmm12, xmm13
0000757ab23cff41  ucomisd xmm12, xmm12
0000757ab23cff46  jp 0x0000757AB23D03AD
0000757ab23cff4c  movq xmm12, xmm12
0000757ab23cff51  movaps xmm1, [r15+0x130]
0000757ab23cff59  movq r14, xmm1
0000757ab23cff5e  movq r12, xmm15
0000757ab23cff63  vmovq xmm1, r14
0000757ab23cff68  vmovq xmm15, r12
0000757ab23cff6d  movaps xmm13, xmm1
0000757ab23cff71  mulsd xmm13, xmm15
0000757ab23cff76  ucomisd xmm13, xmm13
0000757ab23cff7b  jp 0x0000757AB23D03F9
0000757ab23cff81  movq xmm13, xmm13
0000757ab23cff86  movq r14, xmm12
0000757ab23cff8b  movaps xmm1, [r15+0x110]
0000757ab23cff93  movq r12, xmm1
0000757ab23cff98  vmovq xmm1, r14
0000757ab23cff9d  vmovq xmm15, r12
0000757ab23cffa2  movaps xmm12, xmm1
0000757ab23cffa6  addsd xmm12, xmm15
0000757ab23cffab  ucomisd xmm12, xmm12
0000757ab23cffb0  jp 0x0000757AB23D0445
0000757ab23cffb6  movq xmm12, xmm12
0000757ab23cffbb  movq r14, xmm12
0000757ab23cffc0  movq r12, xmm13
0000757ab23cffc5  vmovq xmm1, r14
0000757ab23cffca  vmovq xmm15, r12
0000757ab23cffcf  movaps xmm13, xmm1
0000757ab23cffd3  addsd xmm13, xmm15
0000757ab23cffd8  ucomisd xmm13, xmm13
0000757ab23cffdd  jp 0x0000757AB23D0491
0000757ab23cffe3  movq xmm13, xmm13
0000757ab23cffe8  movaps xmm1, [r15+0x140]
0000757ab23cfff0  movq r14, xmm1
0000757ab23cfff5  movq r12, xmm14
0000757ab23cfffa  vmovq xmm1, r14
0000757ab23cffff  vmovq xmm15, r12
0000757ab23d0004  movaps xmm14, xmm1
0000757ab23d0008  mulsd xmm14, xmm15
0000757ab23d000d  ucomisd xmm14, xmm14
0000757ab23d0012  jp 0x0000757AB23D04DD
0000757ab23d0018  movq xmm14, xmm14
0000757ab23d001d  lea r14, [rax+0xC0]
0000757ab23d0024  mov r12, [r13+r14*1]
0000757ab23d0029  movq xmm1, r12
0000757ab23d002e  movq r14, xmm13
0000757ab23d0033  movq r12, xmm14
0000757ab23d0038  vmovq xmm15, r14
0000757ab23d003d  vmovq xmm14, r12
0000757ab23d0042  movaps xmm13, xmm15
0000757ab23d0046  addsd xmm13, xmm14
0000757ab23d004b  ucomisd xmm13, xmm13
0000757ab23d0050  jp 0x0000757AB23D0533
0000757ab23d0056  movq xmm13, xmm13
0000757ab23d005b  movaps xmm15, [r15+0x150]
0000757ab23d0063  movq r14, xmm15
0000757ab23d0068  movq r12, xmm1
0000757ab23d006d  vmovq xmm1, r14
0000757ab23d0072  vmovq xmm15, r12
0000757ab23d0077  movaps xmm14, xmm1
0000757ab23d007b  mulsd xmm14, xmm15
0000757ab23d0080  ucomisd xmm14, xmm14
0000757ab23d0085  jp 0x0000757AB23D057F
0000757ab23d008b  movq xmm14, xmm14
0000757ab23d0090  lea r14, [rax+0x100]
0000757ab23d0097  mov r12, [r13+r14*1]
0000757ab23d009c  movq xmm1, r12
0000757ab23d00a1  movq r14, xmm13
0000757ab23d00a6  movq r12, xmm14
0000757ab23d00ab  vmovq xmm15, r14
0000757ab23d00b0  vmovq xmm14, r12
0000757ab23d00b5  movaps xmm13, xmm15
0000757ab23d00b9  addsd xmm13, xmm14
0000757ab23d00be  ucomisd xmm13, xmm13
0000757ab23d00c3  jp 0x0000757AB23D05D5
0000757ab23d00c9  movq xmm13, xmm13
0000757ab23d00ce  movaps xmm15, [r15+0x160]
0000757ab23d00d6  movq r14, xmm15
0000757ab23d00db  movq r12, xmm1
0000757ab23d00e0  vmovq xmm1, r14
0000757ab23d00e5  vmovq xmm15, r12
0000757ab23d00ea  movaps xmm14, xmm1
0000757ab23d00ee  mulsd xmm14, xmm15
0000757ab23d00f3  ucomisd xmm14, xmm14
0000757ab23d00f8  jp 0x0000757AB23D0621
0000757ab23d00fe  movq xmm14, xmm14
0000757ab23d0103  lea r14, [rax+0x140]
0000757ab23d010a  mov r12, [r13+r14*1]
0000757ab23d010f  movq xmm1, r12
0000757ab23d0114  movq r14, xmm13
0000757ab23d0119  movq r12, xmm14
0000757ab23d011e  vmovq xmm15, r14
0000757ab23d0123  vmovq xmm14, r12
0000757ab23d0128  movaps xmm13, xmm15
0000757ab23d012c  addsd xmm13, xmm14
0000757ab23d0131  ucomisd xmm13, xmm13
0000757ab23d0136  jp 0x0000757AB23D0677
0000757ab23d013c  movq xmm13, xmm13
0000757ab23d0141  movaps xmm15, [r15+0x170]
0000757ab23d0149  movq r14, xmm15
0000757ab23d014e  movq r12, xmm1
0000757ab23d0153  vmovq xmm1, r14
0000757ab23d0158  vmovq xmm15, r12
0000757ab23d015d  movaps xmm14, xmm1
0000757ab23d0161  mulsd xmm14, xmm15
0000757ab23d0166  ucomisd xmm14, xmm14
0000757ab23d016b  jp 0x0000757AB23D06C3
0000757ab23d0171  movq xmm14, xmm14
0000757ab23d0176  lea r14, [rax+0x180]
0000757ab23d017d  mov r12, [r13+r14*1]
0000757ab23d0182  movq xmm1, r12
0000757ab23d0187  movq r14, xmm13
0000757ab23d018c  movq r12, xmm14
0000757ab23d0191  vmovq xmm15, r14
0000757ab23d0196  vmovq xmm14, r12
0000757ab23d019b  movaps xmm13, xmm15
0000757ab23d019f  addsd xmm13, xmm14
0000757ab23d01a4  ucomisd xmm13, xmm13
0000757ab23d01a9  jp 0x0000757AB23D0719
0000757ab23d01af  movq xmm13, xmm13
0000757ab23d01b4  movaps xmm15, [r15+0x180]
0000757ab23d01bc  movq r14, xmm15
0000757ab23d01c1  movq r12, xmm1
0000757ab23d01c6  vmovq xmm1, r14
0000757ab23d01cb  vmovq xmm15, r12
0000757ab23d01d0  movaps xmm14, xmm1
0000757ab23d01d4  mulsd xmm14, xmm15
0000757ab23d01d9  ucomisd xmm14, xmm14
0000757ab23d01de  jp 0x0000757AB23D0765
0000757ab23d01e4  movq xmm14, xmm14
0000757ab23d01e9  lea r14, [rax+0x1C0]
0000757ab23d01f0  mov rax, [r13+r14*1]
0000757ab23d01f5  movq xmm1, rax
0000757ab23d01fa  movaps [r15+0x240], xmm1
0000757ab23d0202  movq rax, xmm13
0000757ab23d0207  movq r14, xmm14
0000757ab23d020c  vmovq xmm15, rax
0000757ab23d0211  vmovq xmm14, r14
0000757ab23d0216  movaps xmm13, xmm15
0000757ab23d021a  addsd xmm13, xmm14
0000757ab23d021f  ucomisd xmm13, xmm13
0000757ab23d0224  jp 0x0000757AB23D07BB
0000757ab23d022a  movq xmm13, xmm13
0000757ab23d022f  movaps xmm15, [r15+0x210]
0000757ab23d0237  movq rax, xmm15
0000757ab23d023c  movq r14, xmm1
0000757ab23d0241  vmovq xmm1, rax
0000757ab23d0246  vmovq xmm15, r14
0000757ab23d024b  movaps xmm14, xmm1
0000757ab23d024f  mulsd xmm14, xmm15
0000757ab23d0254  ucomisd xmm14, xmm14
0000757ab23d0259  jp 0x0000757AB23D0803
0000757ab23d025f  movq xmm14, xmm14
0000757ab23d0264  movaps [r15+0x230], xmm14
0000757ab23d026c  movq rax, xmm13
0000757ab23d0271  movq r14, xmm14
0000757ab23d0276  vmovq xmm1, rax
0000757ab23d027b  vmovq xmm15, r14
0000757ab23d0280  movaps xmm14, xmm1
0000757ab23d0284  addsd xmm14, xmm15
0000757ab23d0289  ucomisd xmm14, xmm14
0000757ab23d028e  jp 0x0000757AB23D084B
0000757ab23d0294  movq xmm14, xmm14
0000757ab23d0299  movaps [r15+0x220], xmm14
0000757ab23d02a1  mov rax, [r15+0x68]
0000757ab23d02a5  movq r14, xmm14
0000757ab23d02aa  mov [r13+rax*1], r14
0000757ab23d02af  mov qword ptr [r15+0x70], 0x08
0000757ab23d02b7  xor eax, eax
0000757ab23d02b9  mov r14d, 0x08
0000757ab23d02bf  mov r12d, 0x40
0000757ab23d02c5  cmp r14, r12
0000757ab23d02c8  cmc
0000757ab23d02c9  lahf
0000757ab23d02ca  seto al
0000757ab23d02cd  mov [r15+0x108], eax
0000757ab23d02d4  mov eax, [r15+0x108]
0000757ab23d02db  sahf
0000757ab23d02dc  jnz 0x0000757AB23D030E
0000757ab23d02de  cmp dword ptr [r15+0x318], 0x00
0000757ab23d02e6  jz 0x0000757AB23CFD40
0000757ab23d02ec  nop [rax+rax*1], ax
0000757ab23d02f5  nop [rax+rax*1], eax
0000757ab23d02fd  mov eax, 0x410118
0000757ab23d0302  mov [r15+0x100], rax
0000757ab23d0309  jmp 0x0000757AB21FE110
0000757ab23d030e  cmp dword ptr [r15+0x318], 0x00
0000757ab23d0316  jz 0x0000757AB23CF3F0
0000757ab23d031c  nop [rax+rax*1], ax
0000757ab23d0325  nop [rax+rax*1], eax
0000757ab23d032d  mov eax, 0x4100A4
0000757ab23d0332  mov [r15+0x100], rax
0000757ab23d0339  jmp 0x0000757AB21FE110
0000757ab23d033e  int3
0000757ab23d033f  call 0x0000757AB22B47C0
0000757ab23d0344  jmp 0x0000757AB23CFDF5
0000757ab23d0349  call 0x0000757AB22E1570
0000757ab23d034e  jmp 0x0000757AB23CFDFF
0000757ab23d0353  call 0x0000757AB220DC20
0000757ab23d0358  jmp 0x0000757AB23CFE35
0000757ab23d035d  call 0x0000757AB220A4B0
0000757ab23d0362  jmp 0x0000757AB23CFE3F
0000757ab23d0367  call 0x0000757AB220DC20
0000757ab23d036c  jmp 0x0000757AB23CFE75
0000757ab23d0371  call 0x0000757AB220A4B0
0000757ab23d0376  jmp 0x0000757AB23CFE7F
0000757ab23d037b  call 0x0000757AB220DC20
0000757ab23d0380  jmp 0x0000757AB23CFEB5
0000757ab23d0385  call 0x0000757AB220B720
0000757ab23d038a  jmp 0x0000757AB23CFEBF
0000757ab23d038f  call 0x0000757AB220DC20
0000757ab23d0394  jmp 0x0000757AB23CFEF8
0000757ab23d0399  call 0x0000757AB22E27E0
0000757ab23d039e  jmp 0x0000757AB23CFF06
0000757ab23d03a3  call 0x0000757AB22E27E0
0000757ab23d03a8  jmp 0x0000757AB23CFF17
0000757ab23d03ad  ucomisd xmm1, xmm13
0000757ab23d03b2  jp 0x0000757AB23D03C1
0000757ab23d03b4  movaps xmm12, [0x0000757AB1FFE030]
0000757ab23d03bc  jmp 0x0000757AB23CFF4C
0000757ab23d03c1  vxorps xmm0, xmm1, xmm13
0000757ab23d03c6  pextrw r14d, xmm0, 0x03
0000757ab23d03cc  and r14d, 0x7FF8
0000757ab23d03d3  cmp r14d, 0x08
0000757ab23d03d7  jnz 0x0000757AB23CFF4C
0000757ab23d03dd  movq r14, xmm13
0000757ab23d03e2  shl r14, 0x0D
0000757ab23d03e6  jbe 0x0000757AB23CFF4C
0000757ab23d03ec  vorps xmm12, xmm13, [0x0000757AB1FFE040]
0000757ab23d03f4  jmp 0x0000757AB23CFF4C
0000757ab23d03f9  ucomisd xmm1, xmm15
0000757ab23d03fe  jp 0x0000757AB23D040D
0000757ab23d0400  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d0408  jmp 0x0000757AB23CFF81
0000757ab23d040d  vxorps xmm0, xmm1, xmm15
0000757ab23d0412  pextrw r14d, xmm0, 0x03
0000757ab23d0418  and r14d, 0x7FF8
0000757ab23d041f  cmp r14d, 0x08
0000757ab23d0423  jnz 0x0000757AB23CFF81
0000757ab23d0429  movq r14, xmm15
0000757ab23d042e  shl r14, 0x0D
0000757ab23d0432  jbe 0x0000757AB23CFF81
0000757ab23d0438  vorps xmm13, xmm15, [0x0000757AB1FFE040]
0000757ab23d0440  jmp 0x0000757AB23CFF81
0000757ab23d0445  ucomisd xmm1, xmm15
0000757ab23d044a  jp 0x0000757AB23D0459
0000757ab23d044c  movaps xmm12, [0x0000757AB1FFE030]
0000757ab23d0454  jmp 0x0000757AB23CFFB6
0000757ab23d0459  vxorps xmm0, xmm1, xmm15
0000757ab23d045e  pextrw r14d, xmm0, 0x03
0000757ab23d0464  and r14d, 0x7FF8
0000757ab23d046b  cmp r14d, 0x08
0000757ab23d046f  jnz 0x0000757AB23CFFB6
0000757ab23d0475  movq r14, xmm15
0000757ab23d047a  shl r14, 0x0D
0000757ab23d047e  jbe 0x0000757AB23CFFB6
0000757ab23d0484  vorps xmm12, xmm15, [0x0000757AB1FFE040]
0000757ab23d048c  jmp 0x0000757AB23CFFB6
0000757ab23d0491  ucomisd xmm1, xmm15
0000757ab23d0496  jp 0x0000757AB23D04A5
0000757ab23d0498  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d04a0  jmp 0x0000757AB23CFFE3
0000757ab23d04a5  vxorps xmm0, xmm1, xmm15
0000757ab23d04aa  pextrw r14d, xmm0, 0x03
0000757ab23d04b0  and r14d, 0x7FF8
0000757ab23d04b7  cmp r14d, 0x08
0000757ab23d04bb  jnz 0x0000757AB23CFFE3
0000757ab23d04c1  movq r14, xmm15
0000757ab23d04c6  shl r14, 0x0D
0000757ab23d04ca  jbe 0x0000757AB23CFFE3
0000757ab23d04d0  vorps xmm13, xmm15, [0x0000757AB1FFE040]
0000757ab23d04d8  jmp 0x0000757AB23CFFE3
0000757ab23d04dd  ucomisd xmm1, xmm15
0000757ab23d04e2  jp 0x0000757AB23D04F1
0000757ab23d04e4  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d04ec  jmp 0x0000757AB23D0018
0000757ab23d04f1  vxorps xmm0, xmm1, xmm15
0000757ab23d04f6  pextrw r14d, xmm0, 0x03
0000757ab23d04fc  and r14d, 0x7FF8
0000757ab23d0503  cmp r14d, 0x08
0000757ab23d0507  jnz 0x0000757AB23D0018
0000757ab23d050d  movq r14, xmm15
0000757ab23d0512  shl r14, 0x0D
0000757ab23d0516  jbe 0x0000757AB23D0018
0000757ab23d051c  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d0524  jmp 0x0000757AB23D0018
0000757ab23d0529  call 0x0000757AB22E27E0
0000757ab23d052e  jmp 0x0000757AB23D0029
0000757ab23d0533  ucomisd xmm15, xmm14
0000757ab23d0538  jp 0x0000757AB23D0547
0000757ab23d053a  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d0542  jmp 0x0000757AB23D0056
0000757ab23d0547  vxorps xmm0, xmm15, xmm14
0000757ab23d054c  pextrw r14d, xmm0, 0x03
0000757ab23d0552  and r14d, 0x7FF8
0000757ab23d0559  cmp r14d, 0x08
0000757ab23d055d  jnz 0x0000757AB23D0056
0000757ab23d0563  movq r14, xmm14
0000757ab23d0568  shl r14, 0x0D
0000757ab23d056c  jbe 0x0000757AB23D0056
0000757ab23d0572  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d057a  jmp 0x0000757AB23D0056
0000757ab23d057f  ucomisd xmm1, xmm15
0000757ab23d0584  jp 0x0000757AB23D0593
0000757ab23d0586  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d058e  jmp 0x0000757AB23D008B
0000757ab23d0593  vxorps xmm0, xmm1, xmm15
0000757ab23d0598  pextrw r14d, xmm0, 0x03
0000757ab23d059e  and r14d, 0x7FF8
0000757ab23d05a5  cmp r14d, 0x08
0000757ab23d05a9  jnz 0x0000757AB23D008B
0000757ab23d05af  movq r14, xmm15
0000757ab23d05b4  shl r14, 0x0D
0000757ab23d05b8  jbe 0x0000757AB23D008B
0000757ab23d05be  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d05c6  jmp 0x0000757AB23D008B
0000757ab23d05cb  call 0x0000757AB22E27E0
0000757ab23d05d0  jmp 0x0000757AB23D009C
0000757ab23d05d5  ucomisd xmm15, xmm14
0000757ab23d05da  jp 0x0000757AB23D05E9
0000757ab23d05dc  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d05e4  jmp 0x0000757AB23D00C9
0000757ab23d05e9  vxorps xmm0, xmm15, xmm14
0000757ab23d05ee  pextrw r14d, xmm0, 0x03
0000757ab23d05f4  and r14d, 0x7FF8
0000757ab23d05fb  cmp r14d, 0x08
0000757ab23d05ff  jnz 0x0000757AB23D00C9
0000757ab23d0605  movq r14, xmm14
0000757ab23d060a  shl r14, 0x0D
0000757ab23d060e  jbe 0x0000757AB23D00C9
0000757ab23d0614  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d061c  jmp 0x0000757AB23D00C9
0000757ab23d0621  ucomisd xmm1, xmm15
0000757ab23d0626  jp 0x0000757AB23D0635
0000757ab23d0628  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d0630  jmp 0x0000757AB23D00FE
0000757ab23d0635  vxorps xmm0, xmm1, xmm15
0000757ab23d063a  pextrw r14d, xmm0, 0x03
0000757ab23d0640  and r14d, 0x7FF8
0000757ab23d0647  cmp r14d, 0x08
0000757ab23d064b  jnz 0x0000757AB23D00FE
0000757ab23d0651  movq r14, xmm15
0000757ab23d0656  shl r14, 0x0D
0000757ab23d065a  jbe 0x0000757AB23D00FE
0000757ab23d0660  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d0668  jmp 0x0000757AB23D00FE
0000757ab23d066d  call 0x0000757AB22E27E0
0000757ab23d0672  jmp 0x0000757AB23D010F
0000757ab23d0677  ucomisd xmm15, xmm14
0000757ab23d067c  jp 0x0000757AB23D068B
0000757ab23d067e  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d0686  jmp 0x0000757AB23D013C
0000757ab23d068b  vxorps xmm0, xmm15, xmm14
0000757ab23d0690  pextrw r14d, xmm0, 0x03
0000757ab23d0696  and r14d, 0x7FF8
0000757ab23d069d  cmp r14d, 0x08
0000757ab23d06a1  jnz 0x0000757AB23D013C
0000757ab23d06a7  movq r14, xmm14
0000757ab23d06ac  shl r14, 0x0D
0000757ab23d06b0  jbe 0x0000757AB23D013C
0000757ab23d06b6  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d06be  jmp 0x0000757AB23D013C
0000757ab23d06c3  ucomisd xmm1, xmm15
0000757ab23d06c8  jp 0x0000757AB23D06D7
0000757ab23d06ca  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d06d2  jmp 0x0000757AB23D0171
0000757ab23d06d7  vxorps xmm0, xmm1, xmm15
0000757ab23d06dc  pextrw r14d, xmm0, 0x03
0000757ab23d06e2  and r14d, 0x7FF8
0000757ab23d06e9  cmp r14d, 0x08
0000757ab23d06ed  jnz 0x0000757AB23D0171
0000757ab23d06f3  movq r14, xmm15
0000757ab23d06f8  shl r14, 0x0D
0000757ab23d06fc  jbe 0x0000757AB23D0171
0000757ab23d0702  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d070a  jmp 0x0000757AB23D0171
0000757ab23d070f  call 0x0000757AB22E27E0
0000757ab23d0714  jmp 0x0000757AB23D0182
0000757ab23d0719  ucomisd xmm15, xmm14
0000757ab23d071e  jp 0x0000757AB23D072D
0000757ab23d0720  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d0728  jmp 0x0000757AB23D01AF
0000757ab23d072d  vxorps xmm0, xmm15, xmm14
0000757ab23d0732  pextrw r14d, xmm0, 0x03
0000757ab23d0738  and r14d, 0x7FF8
0000757ab23d073f  cmp r14d, 0x08
0000757ab23d0743  jnz 0x0000757AB23D01AF
0000757ab23d0749  movq r14, xmm14
0000757ab23d074e  shl r14, 0x0D
0000757ab23d0752  jbe 0x0000757AB23D01AF
0000757ab23d0758  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d0760  jmp 0x0000757AB23D01AF
0000757ab23d0765  ucomisd xmm1, xmm15
0000757ab23d076a  jp 0x0000757AB23D0779
0000757ab23d076c  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d0774  jmp 0x0000757AB23D01E4
0000757ab23d0779  vxorps xmm0, xmm1, xmm15
0000757ab23d077e  pextrw r14d, xmm0, 0x03
0000757ab23d0784  and r14d, 0x7FF8
0000757ab23d078b  cmp r14d, 0x08
0000757ab23d078f  jnz 0x0000757AB23D01E4
0000757ab23d0795  movq r14, xmm15
0000757ab23d079a  shl r14, 0x0D
0000757ab23d079e  jbe 0x0000757AB23D01E4
0000757ab23d07a4  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d07ac  jmp 0x0000757AB23D01E4
0000757ab23d07b1  call 0x0000757AB22D59C0
0000757ab23d07b6  jmp 0x0000757AB23D01F5
0000757ab23d07bb  ucomisd xmm15, xmm14
0000757ab23d07c0  jp 0x0000757AB23D07CF
0000757ab23d07c2  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d07ca  jmp 0x0000757AB23D022A
0000757ab23d07cf  vxorps xmm0, xmm15, xmm14
0000757ab23d07d4  pextrw eax, xmm0, 0x03
0000757ab23d07d9  and eax, 0x7FF8
0000757ab23d07de  cmp eax, 0x08
0000757ab23d07e1  jnz 0x0000757AB23D022A
0000757ab23d07e7  movq rax, xmm14
0000757ab23d07ec  shl rax, 0x0D
0000757ab23d07f0  jbe 0x0000757AB23D022A
0000757ab23d07f6  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d07fe  jmp 0x0000757AB23D022A
0000757ab23d0803  ucomisd xmm1, xmm15
0000757ab23d0808  jp 0x0000757AB23D0817
0000757ab23d080a  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d0812  jmp 0x0000757AB23D025F
0000757ab23d0817  vxorps xmm0, xmm1, xmm15
0000757ab23d081c  pextrw eax, xmm0, 0x03
0000757ab23d0821  and eax, 0x7FF8
0000757ab23d0826  cmp eax, 0x08
0000757ab23d0829  jnz 0x0000757AB23D025F
0000757ab23d082f  movq rax, xmm15
0000757ab23d0834  shl rax, 0x0D
0000757ab23d0838  jbe 0x0000757AB23D025F
0000757ab23d083e  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d0846  jmp 0x0000757AB23D025F
0000757ab23d084b  ucomisd xmm1, xmm15
0000757ab23d0850  jp 0x0000757AB23D085F
0000757ab23d0852  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d085a  jmp 0x0000757AB23D0294
0000757ab23d085f  vxorps xmm0, xmm1, xmm15
0000757ab23d0864  pextrw eax, xmm0, 0x03
0000757ab23d0869  and eax, 0x7FF8
0000757ab23d086e  cmp eax, 0x08
0000757ab23d0871  jnz 0x0000757AB23D0294
0000757ab23d0877  movq rax, xmm15
0000757ab23d087c  shl rax, 0x0D
0000757ab23d0880  jbe 0x0000757AB23D0294
0000757ab23d0886  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d088e  jmp 0x0000757AB23D0294
0000757ab23d0893  call 0x0000757AB220E120
0000757ab23d0898  jmp 0x0000757AB23D02AF
0000757ab23d089d  int3
0000757ab23d089e  nop
0000757ab23d08a0  mov eax, [r15+0x58]
0000757ab23d08a4  lea r14d, [eax+0x01]
0000757ab23d08a9  mov [rsp+0x10], r14d
0000757ab23d08ae  mov r14d, r14d
0000757ab23d08b1  mov [r15+0x58], r14
0000757ab23d08b5  xor eax, eax
0000757ab23d08b7  mov r14d, [rsp+0x10]
0000757ab23d08bc  cmp r14d, 0x1F4
0000757ab23d08c3  cmc
0000757ab23d08c4  lahf
0000757ab23d08c5  seto al
0000757ab23d08c8  mov [r15+0x108], eax
0000757ab23d08cf  mov eax, [r15+0x108]
0000757ab23d08d6  sahf
0000757ab23d08d7  jnz 0x0000757AB23D0909
0000757ab23d08d9  cmp dword ptr [r15+0x318], 0x00
0000757ab23d08e1  jz 0x0000757AB23D1410
0000757ab23d08e7  nop [rax+rax*1], ax
0000757ab23d08f0  nop [rax+rax*1], eax
0000757ab23d08f8  mov eax, 0x410134
0000757ab23d08fd  mov [r15+0x100], rax
0000757ab23d0904  jmp 0x0000757AB21FE110
0000757ab23d0909  cmp dword ptr [r15+0x318], 0x00
0000757ab23d0911  jz 0x0000757AB23D0940
0000757ab23d0917  nop [rax+rax*1], ax
0000757ab23d0920  nop [rax+rax*1], eax
0000757ab23d0928  mov eax, 0x410084
0000757ab23d092d  mov [r15+0x100], rax
0000757ab23d0934  jmp 0x0000757AB21FE110
0000757ab23d0939  int3
0000757ab23d093a  int3
0000757ab23d093b  nop [rax+rax*1], eax
0000757ab23d0940  mov qword ptr [r15+0x60], 0x00
0000757ab23d0948  mov rax, [r15+0x50]
0000757ab23d094c  mov [r15+0x68], rax
0000757ab23d0950  mov r14, [r15+0x40]
0000757ab23d0954  mov r12, [r13+r14*1]
0000757ab23d0959  lea r11, [r14+0x08]
0000757ab23d095d  mov r10, [r13+r11*1]
0000757ab23d0962  movq xmm1, r12
0000757ab23d0967  movq xmm15, r10
0000757ab23d096c  movq xmm1, xmm1
0000757ab23d0970  movq xmm1, xmm1
0000757ab23d0974  movaps [r15+0x120], xmm1
0000757ab23d097c  movq xmm15, xmm15
0000757ab23d0981  movq xmm15, xmm15
0000757ab23d0986  movaps [r15+0x130], xmm15
0000757ab23d098e  lea r12, [r14+0x10]
0000757ab23d0992  mov r11, [r13+r12*1]
0000757ab23d0997  lea r12, [r14+0x18]
0000757ab23d099b  mov r10, [r13+r12*1]
0000757ab23d09a0  movq xmm1, r11
0000757ab23d09a5  movq xmm15, r10
0000757ab23d09aa  movq xmm1, xmm1
0000757ab23d09ae  movq xmm1, xmm1
0000757ab23d09b2  movaps [r15+0x140], xmm1
0000757ab23d09ba  movq xmm15, xmm15
0000757ab23d09bf  movq xmm15, xmm15
0000757ab23d09c4  movaps [r15+0x150], xmm15
0000757ab23d09cc  lea r12, [r14+0x20]
0000757ab23d09d0  mov r11, [r13+r12*1]
0000757ab23d09d5  lea r12, [r14+0x28]
0000757ab23d09d9  mov r10, [r13+r12*1]
0000757ab23d09de  movq xmm1, r11
0000757ab23d09e3  movq xmm15, r10
0000757ab23d09e8  movq xmm1, xmm1
0000757ab23d09ec  movq xmm1, xmm1
0000757ab23d09f0  movaps [r15+0x160], xmm1
0000757ab23d09f8  movq xmm15, xmm15
0000757ab23d09fd  movq xmm15, xmm15
0000757ab23d0a02  movaps [r15+0x170], xmm15
0000757ab23d0a0a  lea r12, [r14+0x30]
0000757ab23d0a0e  mov r11, [r13+r12*1]
0000757ab23d0a13  lea r12, [r14+0x38]
0000757ab23d0a17  mov r14, [r13+r12*1]
0000757ab23d0a1c  movq xmm1, r11
0000757ab23d0a21  movq xmm15, r14
0000757ab23d0a26  movq xmm1, xmm1
0000757ab23d0a2a  movq xmm1, xmm1
0000757ab23d0a2e  movaps [r15+0x180], xmm1
0000757ab23d0a36  movq xmm15, xmm15
0000757ab23d0a3b  movq xmm15, xmm15
0000757ab23d0a40  movaps [r15+0x210], xmm15
0000757ab23d0a48  mov r14, [r15+0x48]
0000757ab23d0a4c  mov [r15+0x78], r14
0000757ab23d0a50  mov r12, [r13+r14*1]
0000757ab23d0a55  movq xmm1, r12
0000757ab23d0a5a  lea r12, [r14+0x40]
0000757ab23d0a5e  mov r11, [r13+r12*1]
0000757ab23d0a63  movq xmm15, r11
0000757ab23d0a68  lea r12, [r14+0x80]
0000757ab23d0a6f  mov r11, [r13+r12*1]
0000757ab23d0a74  movq xmm14, r11
0000757ab23d0a79  movaps xmm13, [r15+0x120]
0000757ab23d0a81  movq r12, xmm13
0000757ab23d0a86  movq r11, xmm1
0000757ab23d0a8b  vmovq xmm1, r12
0000757ab23d0a90  vmovq xmm13, r11
0000757ab23d0a95  movaps xmm12, xmm1
0000757ab23d0a99  mulsd xmm12, xmm13
0000757ab23d0a9e  ucomisd xmm12, xmm12
0000757ab23d0aa3  jp 0x0000757AB23D0F06
0000757ab23d0aa9  movq xmm12, xmm12
0000757ab23d0aae  movaps xmm1, [r15+0x130]
0000757ab23d0ab6  movq r12, xmm1
0000757ab23d0abb  movq r11, xmm15
0000757ab23d0ac0  vmovq xmm1, r12
0000757ab23d0ac5  vmovq xmm15, r11
0000757ab23d0aca  movaps xmm13, xmm1
0000757ab23d0ace  mulsd xmm13, xmm15
0000757ab23d0ad3  ucomisd xmm13, xmm13
0000757ab23d0ad8  jp 0x0000757AB23D0F52
0000757ab23d0ade  movq xmm13, xmm13
0000757ab23d0ae3  movq r12, xmm12
0000757ab23d0ae8  movaps xmm1, [r15+0x110]
0000757ab23d0af0  movq r11, xmm1
0000757ab23d0af5  vmovq xmm1, r12
0000757ab23d0afa  vmovq xmm15, r11
0000757ab23d0aff  movaps xmm12, xmm1
0000757ab23d0b03  addsd xmm12, xmm15
0000757ab23d0b08  ucomisd xmm12, xmm12
0000757ab23d0b0d  jp 0x0000757AB23D0F9E
0000757ab23d0b13  movq xmm12, xmm12
0000757ab23d0b18  movq r12, xmm12
0000757ab23d0b1d  movq r11, xmm13
0000757ab23d0b22  vmovq xmm1, r12
0000757ab23d0b27  vmovq xmm15, r11
0000757ab23d0b2c  movaps xmm13, xmm1
0000757ab23d0b30  addsd xmm13, xmm15
0000757ab23d0b35  ucomisd xmm13, xmm13
0000757ab23d0b3a  jp 0x0000757AB23D0FEA
0000757ab23d0b40  movq xmm13, xmm13
0000757ab23d0b45  movaps xmm1, [r15+0x140]
0000757ab23d0b4d  movq r12, xmm1
0000757ab23d0b52  movq r11, xmm14
0000757ab23d0b57  vmovq xmm1, r12
0000757ab23d0b5c  vmovq xmm15, r11
0000757ab23d0b61  movaps xmm14, xmm1
0000757ab23d0b65  mulsd xmm14, xmm15
0000757ab23d0b6a  ucomisd xmm14, xmm14
0000757ab23d0b6f  jp 0x0000757AB23D1036
0000757ab23d0b75  movq xmm14, xmm14
0000757ab23d0b7a  lea r12, [r14+0xC0]
0000757ab23d0b81  mov r11, [r13+r12*1]
0000757ab23d0b86  movq xmm1, r11
0000757ab23d0b8b  movq r12, xmm13
0000757ab23d0b90  movq r11, xmm14
0000757ab23d0b95  vmovq xmm15, r12
0000757ab23d0b9a  vmovq xmm14, r11
0000757ab23d0b9f  movaps xmm13, xmm15
0000757ab23d0ba3  addsd xmm13, xmm14
0000757ab23d0ba8  ucomisd xmm13, xmm13
0000757ab23d0bad  jp 0x0000757AB23D108C
0000757ab23d0bb3  movq xmm13, xmm13
0000757ab23d0bb8  movaps xmm15, [r15+0x150]
0000757ab23d0bc0  movq r12, xmm15
0000757ab23d0bc5  movq r11, xmm1
0000757ab23d0bca  vmovq xmm1, r12
0000757ab23d0bcf  vmovq xmm15, r11
0000757ab23d0bd4  movaps xmm14, xmm1
0000757ab23d0bd8  mulsd xmm14, xmm15
0000757ab23d0bdd  ucomisd xmm14, xmm14
0000757ab23d0be2  jp 0x0000757AB23D10D8
0000757ab23d0be8  movq xmm14, xmm14
0000757ab23d0bed  lea r12, [r14+0x100]
0000757ab23d0bf4  mov r11, [r13+r12*1]
0000757ab23d0bf9  movq xmm1, r11
0000757ab23d0bfe  movq r12, xmm13
0000757ab23d0c03  movq r11, xmm14
0000757ab23d0c08  vmovq xmm15, r12
0000757ab23d0c0d  vmovq xmm14, r11
0000757ab23d0c12  movaps xmm13, xmm15
0000757ab23d0c16  addsd xmm13, xmm14
0000757ab23d0c1b  ucomisd xmm13, xmm13
0000757ab23d0c20  jp 0x0000757AB23D112E
0000757ab23d0c26  movq xmm13, xmm13
0000757ab23d0c2b  movaps xmm15, [r15+0x160]
0000757ab23d0c33  movq r12, xmm15
0000757ab23d0c38  movq r11, xmm1
0000757ab23d0c3d  vmovq xmm1, r12
0000757ab23d0c42  vmovq xmm15, r11
0000757ab23d0c47  movaps xmm14, xmm1
0000757ab23d0c4b  mulsd xmm14, xmm15
0000757ab23d0c50  ucomisd xmm14, xmm14
0000757ab23d0c55  jp 0x0000757AB23D117A
0000757ab23d0c5b  movq xmm14, xmm14
0000757ab23d0c60  lea r12, [r14+0x140]
0000757ab23d0c67  mov r11, [r13+r12*1]
0000757ab23d0c6c  movq xmm1, r11
0000757ab23d0c71  movq r12, xmm13
0000757ab23d0c76  movq r11, xmm14
0000757ab23d0c7b  vmovq xmm15, r12
0000757ab23d0c80  vmovq xmm14, r11
0000757ab23d0c85  movaps xmm13, xmm15
0000757ab23d0c89  addsd xmm13, xmm14
0000757ab23d0c8e  ucomisd xmm13, xmm13
0000757ab23d0c93  jp 0x0000757AB23D11D0
0000757ab23d0c99  movq xmm13, xmm13
0000757ab23d0c9e  movaps xmm15, [r15+0x170]
0000757ab23d0ca6  movq r12, xmm15
0000757ab23d0cab  movq r11, xmm1
0000757ab23d0cb0  vmovq xmm1, r12
0000757ab23d0cb5  vmovq xmm15, r11
0000757ab23d0cba  movaps xmm14, xmm1
0000757ab23d0cbe  mulsd xmm14, xmm15
0000757ab23d0cc3  ucomisd xmm14, xmm14
0000757ab23d0cc8  jp 0x0000757AB23D121C
0000757ab23d0cce  movq xmm14, xmm14
0000757ab23d0cd3  lea r12, [r14+0x180]
0000757ab23d0cda  mov r11, [r13+r12*1]
0000757ab23d0cdf  movq xmm1, r11
0000757ab23d0ce4  movq r12, xmm13
0000757ab23d0ce9  movq r11, xmm14
0000757ab23d0cee  vmovq xmm15, r12
0000757ab23d0cf3  vmovq xmm14, r11
0000757ab23d0cf8  movaps xmm13, xmm15
0000757ab23d0cfc  addsd xmm13, xmm14
0000757ab23d0d01  ucomisd xmm13, xmm13
0000757ab23d0d06  jp 0x0000757AB23D1272
0000757ab23d0d0c  movq xmm13, xmm13
0000757ab23d0d11  movaps xmm15, [r15+0x180]
0000757ab23d0d19  movq r12, xmm15
0000757ab23d0d1e  movq r11, xmm1
0000757ab23d0d23  vmovq xmm1, r12
0000757ab23d0d28  vmovq xmm15, r11
0000757ab23d0d2d  movaps xmm14, xmm1
0000757ab23d0d31  mulsd xmm14, xmm15
0000757ab23d0d36  ucomisd xmm14, xmm14
0000757ab23d0d3b  jp 0x0000757AB23D12BE
0000757ab23d0d41  movq xmm14, xmm14
0000757ab23d0d46  lea r12, [r14+0x1C0]
0000757ab23d0d4d  mov r14, [r13+r12*1]
0000757ab23d0d52  movq xmm1, r14
0000757ab23d0d57  movaps [r15+0x240], xmm1
0000757ab23d0d5f  movq r14, xmm13
0000757ab23d0d64  movq r12, xmm14
0000757ab23d0d69  vmovq xmm15, r14
0000757ab23d0d6e  vmovq xmm14, r12
0000757ab23d0d73  movaps xmm13, xmm15
0000757ab23d0d77  addsd xmm13, xmm14
0000757ab23d0d7c  ucomisd xmm13, xmm13
0000757ab23d0d81  jp 0x0000757AB23D1314
0000757ab23d0d87  movq xmm13, xmm13
0000757ab23d0d8c  movaps xmm15, [r15+0x210]
0000757ab23d0d94  movq r14, xmm15
0000757ab23d0d99  movq r12, xmm1
0000757ab23d0d9e  vmovq xmm1, r14
0000757ab23d0da3  vmovq xmm15, r12
0000757ab23d0da8  movaps xmm14, xmm1
0000757ab23d0dac  mulsd xmm14, xmm15
0000757ab23d0db1  ucomisd xmm14, xmm14
0000757ab23d0db6  jp 0x0000757AB23D1360
0000757ab23d0dbc  movq xmm14, xmm14
0000757ab23d0dc1  movaps [r15+0x230], xmm14
0000757ab23d0dc9  movq r14, xmm13
0000757ab23d0dce  movq r12, xmm14
0000757ab23d0dd3  vmovq xmm1, r14
0000757ab23d0dd8  vmovq xmm15, r12
0000757ab23d0ddd  movaps xmm14, xmm1
0000757ab23d0de1  addsd xmm14, xmm15
0000757ab23d0de6  ucomisd xmm14, xmm14
0000757ab23d0deb  jp 0x0000757AB23D13AC
0000757ab23d0df1  movq xmm14, xmm14
0000757ab23d0df6  movaps [r15+0x220], xmm14
0000757ab23d0dfe  movq r14, xmm14
0000757ab23d0e03  mov [r13+rax*1], r14
0000757ab23d0e08  mov qword ptr [r15+0x70], 0x08
0000757ab23d0e10  xor eax, eax
0000757ab23d0e12  mov r14d, 0x08
0000757ab23d0e18  mov r12d, 0x40
0000757ab23d0e1e  cmp r14, r12
0000757ab23d0e21  cmc
0000757ab23d0e22  lahf
0000757ab23d0e23  seto al
0000757ab23d0e26  mov [r15+0x108], eax
0000757ab23d0e2d  mov eax, [r15+0x108]
0000757ab23d0e34  sahf
0000757ab23d0e35  jnz 0x0000757AB23D0E67
0000757ab23d0e37  cmp dword ptr [r15+0x318], 0x00
0000757ab23d0e3f  jz 0x0000757AB23CFD40
0000757ab23d0e45  nop [rax+rax*1], ax
0000757ab23d0e4e  nop [rax+rax*1], eax
0000757ab23d0e56  mov eax, 0x410118
0000757ab23d0e5b  mov [r15+0x100], rax
0000757ab23d0e62  jmp 0x0000757AB21FE110
0000757ab23d0e67  cmp dword ptr [r15+0x318], 0x00
0000757ab23d0e6f  jz 0x0000757AB23CF3F0
0000757ab23d0e75  nop [rax+rax*1], ax
0000757ab23d0e7e  nop [rax+rax*1], eax
0000757ab23d0e86  mov eax, 0x4100A4
0000757ab23d0e8b  mov [r15+0x100], rax
0000757ab23d0e92  jmp 0x0000757AB21FE110
0000757ab23d0e97  int3
0000757ab23d0e98  call 0x0000757AB22E27E0
0000757ab23d0e9d  jmp 0x0000757AB23D0959
0000757ab23d0ea2  call 0x0000757AB22AE800
0000757ab23d0ea7  jmp 0x0000757AB23D0962
0000757ab23d0eac  call 0x0000757AB22C0370
0000757ab23d0eb1  jmp 0x0000757AB23D0997
0000757ab23d0eb6  call 0x0000757AB22BF100
0000757ab23d0ebb  jmp 0x0000757AB23D09A0
0000757ab23d0ec0  call 0x0000757AB22C0370
0000757ab23d0ec5  jmp 0x0000757AB23D09D5
0000757ab23d0eca  call 0x0000757AB22BF100
0000757ab23d0ecf  jmp 0x0000757AB23D09DE
0000757ab23d0ed4  call 0x0000757AB22C0370
0000757ab23d0ed9  jmp 0x0000757AB23D0A13
0000757ab23d0ede  call 0x0000757AB22C3AE0
0000757ab23d0ee3  jmp 0x0000757AB23D0A1C
0000757ab23d0ee8  call 0x0000757AB22E27E0
0000757ab23d0eed  jmp 0x0000757AB23D0A55
0000757ab23d0ef2  call 0x0000757AB22C0370
0000757ab23d0ef7  jmp 0x0000757AB23D0A63
0000757ab23d0efc  call 0x0000757AB22C0370
0000757ab23d0f01  jmp 0x0000757AB23D0A74
0000757ab23d0f06  ucomisd xmm1, xmm13
0000757ab23d0f0b  jp 0x0000757AB23D0F1A
0000757ab23d0f0d  movaps xmm12, [0x0000757AB1FFE030]
0000757ab23d0f15  jmp 0x0000757AB23D0AA9
0000757ab23d0f1a  vxorps xmm0, xmm1, xmm13
0000757ab23d0f1f  pextrw r12d, xmm0, 0x03
0000757ab23d0f25  and r12d, 0x7FF8
0000757ab23d0f2c  cmp r12d, 0x08
0000757ab23d0f30  jnz 0x0000757AB23D0AA9
0000757ab23d0f36  movq r12, xmm13
0000757ab23d0f3b  shl r12, 0x0D
0000757ab23d0f3f  jbe 0x0000757AB23D0AA9
0000757ab23d0f45  vorps xmm12, xmm13, [0x0000757AB1FFE040]
0000757ab23d0f4d  jmp 0x0000757AB23D0AA9
0000757ab23d0f52  ucomisd xmm1, xmm15
0000757ab23d0f57  jp 0x0000757AB23D0F66
0000757ab23d0f59  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d0f61  jmp 0x0000757AB23D0ADE
0000757ab23d0f66  vxorps xmm0, xmm1, xmm15
0000757ab23d0f6b  pextrw r12d, xmm0, 0x03
0000757ab23d0f71  and r12d, 0x7FF8
0000757ab23d0f78  cmp r12d, 0x08
0000757ab23d0f7c  jnz 0x0000757AB23D0ADE
0000757ab23d0f82  movq r12, xmm15
0000757ab23d0f87  shl r12, 0x0D
0000757ab23d0f8b  jbe 0x0000757AB23D0ADE
0000757ab23d0f91  vorps xmm13, xmm15, [0x0000757AB1FFE040]
0000757ab23d0f99  jmp 0x0000757AB23D0ADE
0000757ab23d0f9e  ucomisd xmm1, xmm15
0000757ab23d0fa3  jp 0x0000757AB23D0FB2
0000757ab23d0fa5  movaps xmm12, [0x0000757AB1FFE030]
0000757ab23d0fad  jmp 0x0000757AB23D0B13
0000757ab23d0fb2  vxorps xmm0, xmm1, xmm15
0000757ab23d0fb7  pextrw r12d, xmm0, 0x03
0000757ab23d0fbd  and r12d, 0x7FF8
0000757ab23d0fc4  cmp r12d, 0x08
0000757ab23d0fc8  jnz 0x0000757AB23D0B13
0000757ab23d0fce  movq r12, xmm15
0000757ab23d0fd3  shl r12, 0x0D
0000757ab23d0fd7  jbe 0x0000757AB23D0B13
0000757ab23d0fdd  vorps xmm12, xmm15, [0x0000757AB1FFE040]
0000757ab23d0fe5  jmp 0x0000757AB23D0B13
0000757ab23d0fea  ucomisd xmm1, xmm15
0000757ab23d0fef  jp 0x0000757AB23D0FFE
0000757ab23d0ff1  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d0ff9  jmp 0x0000757AB23D0B40
0000757ab23d0ffe  vxorps xmm0, xmm1, xmm15
0000757ab23d1003  pextrw r12d, xmm0, 0x03
0000757ab23d1009  and r12d, 0x7FF8
0000757ab23d1010  cmp r12d, 0x08
0000757ab23d1014  jnz 0x0000757AB23D0B40
0000757ab23d101a  movq r12, xmm15
0000757ab23d101f  shl r12, 0x0D
0000757ab23d1023  jbe 0x0000757AB23D0B40
0000757ab23d1029  vorps xmm13, xmm15, [0x0000757AB1FFE040]
0000757ab23d1031  jmp 0x0000757AB23D0B40
0000757ab23d1036  ucomisd xmm1, xmm15
0000757ab23d103b  jp 0x0000757AB23D104A
0000757ab23d103d  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d1045  jmp 0x0000757AB23D0B75
0000757ab23d104a  vxorps xmm0, xmm1, xmm15
0000757ab23d104f  pextrw r12d, xmm0, 0x03
0000757ab23d1055  and r12d, 0x7FF8
0000757ab23d105c  cmp r12d, 0x08
0000757ab23d1060  jnz 0x0000757AB23D0B75
0000757ab23d1066  movq r12, xmm15
0000757ab23d106b  shl r12, 0x0D
0000757ab23d106f  jbe 0x0000757AB23D0B75
0000757ab23d1075  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d107d  jmp 0x0000757AB23D0B75
0000757ab23d1082  call 0x0000757AB22C0370
0000757ab23d1087  jmp 0x0000757AB23D0B86
0000757ab23d108c  ucomisd xmm15, xmm14
0000757ab23d1091  jp 0x0000757AB23D10A0
0000757ab23d1093  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d109b  jmp 0x0000757AB23D0BB3
0000757ab23d10a0  vxorps xmm0, xmm15, xmm14
0000757ab23d10a5  pextrw r12d, xmm0, 0x03
0000757ab23d10ab  and r12d, 0x7FF8
0000757ab23d10b2  cmp r12d, 0x08
0000757ab23d10b6  jnz 0x0000757AB23D0BB3
0000757ab23d10bc  movq r12, xmm14
0000757ab23d10c1  shl r12, 0x0D
0000757ab23d10c5  jbe 0x0000757AB23D0BB3
0000757ab23d10cb  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d10d3  jmp 0x0000757AB23D0BB3
0000757ab23d10d8  ucomisd xmm1, xmm15
0000757ab23d10dd  jp 0x0000757AB23D10EC
0000757ab23d10df  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d10e7  jmp 0x0000757AB23D0BE8
0000757ab23d10ec  vxorps xmm0, xmm1, xmm15
0000757ab23d10f1  pextrw r12d, xmm0, 0x03
0000757ab23d10f7  and r12d, 0x7FF8
0000757ab23d10fe  cmp r12d, 0x08
0000757ab23d1102  jnz 0x0000757AB23D0BE8
0000757ab23d1108  movq r12, xmm15
0000757ab23d110d  shl r12, 0x0D
0000757ab23d1111  jbe 0x0000757AB23D0BE8
0000757ab23d1117  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d111f  jmp 0x0000757AB23D0BE8
0000757ab23d1124  call 0x0000757AB22C0370
0000757ab23d1129  jmp 0x0000757AB23D0BF9
0000757ab23d112e  ucomisd xmm15, xmm14
0000757ab23d1133  jp 0x0000757AB23D1142
0000757ab23d1135  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d113d  jmp 0x0000757AB23D0C26
0000757ab23d1142  vxorps xmm0, xmm15, xmm14
0000757ab23d1147  pextrw r12d, xmm0, 0x03
0000757ab23d114d  and r12d, 0x7FF8
0000757ab23d1154  cmp r12d, 0x08
0000757ab23d1158  jnz 0x0000757AB23D0C26
0000757ab23d115e  movq r12, xmm14
0000757ab23d1163  shl r12, 0x0D
0000757ab23d1167  jbe 0x0000757AB23D0C26
0000757ab23d116d  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d1175  jmp 0x0000757AB23D0C26
0000757ab23d117a  ucomisd xmm1, xmm15
0000757ab23d117f  jp 0x0000757AB23D118E
0000757ab23d1181  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d1189  jmp 0x0000757AB23D0C5B
0000757ab23d118e  vxorps xmm0, xmm1, xmm15
0000757ab23d1193  pextrw r12d, xmm0, 0x03
0000757ab23d1199  and r12d, 0x7FF8
0000757ab23d11a0  cmp r12d, 0x08
0000757ab23d11a4  jnz 0x0000757AB23D0C5B
0000757ab23d11aa  movq r12, xmm15
0000757ab23d11af  shl r12, 0x0D
0000757ab23d11b3  jbe 0x0000757AB23D0C5B
0000757ab23d11b9  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d11c1  jmp 0x0000757AB23D0C5B
0000757ab23d11c6  call 0x0000757AB22C0370
0000757ab23d11cb  jmp 0x0000757AB23D0C6C
0000757ab23d11d0  ucomisd xmm15, xmm14
0000757ab23d11d5  jp 0x0000757AB23D11E4
0000757ab23d11d7  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d11df  jmp 0x0000757AB23D0C99
0000757ab23d11e4  vxorps xmm0, xmm15, xmm14
0000757ab23d11e9  pextrw r12d, xmm0, 0x03
0000757ab23d11ef  and r12d, 0x7FF8
0000757ab23d11f6  cmp r12d, 0x08
0000757ab23d11fa  jnz 0x0000757AB23D0C99
0000757ab23d1200  movq r12, xmm14
0000757ab23d1205  shl r12, 0x0D
0000757ab23d1209  jbe 0x0000757AB23D0C99
0000757ab23d120f  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d1217  jmp 0x0000757AB23D0C99
0000757ab23d121c  ucomisd xmm1, xmm15
0000757ab23d1221  jp 0x0000757AB23D1230
0000757ab23d1223  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d122b  jmp 0x0000757AB23D0CCE
0000757ab23d1230  vxorps xmm0, xmm1, xmm15
0000757ab23d1235  pextrw r12d, xmm0, 0x03
0000757ab23d123b  and r12d, 0x7FF8
0000757ab23d1242  cmp r12d, 0x08
0000757ab23d1246  jnz 0x0000757AB23D0CCE
0000757ab23d124c  movq r12, xmm15
0000757ab23d1251  shl r12, 0x0D
0000757ab23d1255  jbe 0x0000757AB23D0CCE
0000757ab23d125b  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d1263  jmp 0x0000757AB23D0CCE
0000757ab23d1268  call 0x0000757AB22C0370
0000757ab23d126d  jmp 0x0000757AB23D0CDF
0000757ab23d1272  ucomisd xmm15, xmm14
0000757ab23d1277  jp 0x0000757AB23D1286
0000757ab23d1279  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d1281  jmp 0x0000757AB23D0D0C
0000757ab23d1286  vxorps xmm0, xmm15, xmm14
0000757ab23d128b  pextrw r12d, xmm0, 0x03
0000757ab23d1291  and r12d, 0x7FF8
0000757ab23d1298  cmp r12d, 0x08
0000757ab23d129c  jnz 0x0000757AB23D0D0C
0000757ab23d12a2  movq r12, xmm14
0000757ab23d12a7  shl r12, 0x0D
0000757ab23d12ab  jbe 0x0000757AB23D0D0C
0000757ab23d12b1  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d12b9  jmp 0x0000757AB23D0D0C
0000757ab23d12be  ucomisd xmm1, xmm15
0000757ab23d12c3  jp 0x0000757AB23D12D2
0000757ab23d12c5  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d12cd  jmp 0x0000757AB23D0D41
0000757ab23d12d2  vxorps xmm0, xmm1, xmm15
0000757ab23d12d7  pextrw r12d, xmm0, 0x03
0000757ab23d12dd  and r12d, 0x7FF8
0000757ab23d12e4  cmp r12d, 0x08
0000757ab23d12e8  jnz 0x0000757AB23D0D41
0000757ab23d12ee  movq r12, xmm15
0000757ab23d12f3  shl r12, 0x0D
0000757ab23d12f7  jbe 0x0000757AB23D0D41
0000757ab23d12fd  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d1305  jmp 0x0000757AB23D0D41
0000757ab23d130a  call 0x0000757AB22C3AE0
0000757ab23d130f  jmp 0x0000757AB23D0D52
0000757ab23d1314  ucomisd xmm15, xmm14
0000757ab23d1319  jp 0x0000757AB23D1328
0000757ab23d131b  movaps xmm13, [0x0000757AB1FFE030]
0000757ab23d1323  jmp 0x0000757AB23D0D87
0000757ab23d1328  vxorps xmm0, xmm15, xmm14
0000757ab23d132d  pextrw r14d, xmm0, 0x03
0000757ab23d1333  and r14d, 0x7FF8
0000757ab23d133a  cmp r14d, 0x08
0000757ab23d133e  jnz 0x0000757AB23D0D87
0000757ab23d1344  movq r14, xmm14
0000757ab23d1349  shl r14, 0x0D
0000757ab23d134d  jbe 0x0000757AB23D0D87
0000757ab23d1353  vorps xmm13, xmm14, [0x0000757AB1FFE040]
0000757ab23d135b  jmp 0x0000757AB23D0D87
0000757ab23d1360  ucomisd xmm1, xmm15
0000757ab23d1365  jp 0x0000757AB23D1374
0000757ab23d1367  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d136f  jmp 0x0000757AB23D0DBC
0000757ab23d1374  vxorps xmm0, xmm1, xmm15
0000757ab23d1379  pextrw r14d, xmm0, 0x03
0000757ab23d137f  and r14d, 0x7FF8
0000757ab23d1386  cmp r14d, 0x08
0000757ab23d138a  jnz 0x0000757AB23D0DBC
0000757ab23d1390  movq r14, xmm15
0000757ab23d1395  shl r14, 0x0D
0000757ab23d1399  jbe 0x0000757AB23D0DBC
0000757ab23d139f  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d13a7  jmp 0x0000757AB23D0DBC
0000757ab23d13ac  ucomisd xmm1, xmm15
0000757ab23d13b1  jp 0x0000757AB23D13C0
0000757ab23d13b3  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d13bb  jmp 0x0000757AB23D0DF1
0000757ab23d13c0  vxorps xmm0, xmm1, xmm15
0000757ab23d13c5  pextrw r14d, xmm0, 0x03
0000757ab23d13cb  and r14d, 0x7FF8
0000757ab23d13d2  cmp r14d, 0x08
0000757ab23d13d6  jnz 0x0000757AB23D0DF1
0000757ab23d13dc  movq r14, xmm15
0000757ab23d13e1  shl r14, 0x0D
0000757ab23d13e5  jbe 0x0000757AB23D0DF1
0000757ab23d13eb  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d13f3  jmp 0x0000757AB23D0DF1
0000757ab23d13f8  call 0x0000757AB220E120
0000757ab23d13fd  jmp 0x0000757AB23D0E08
0000757ab23d1402  int3
0000757ab23d1403  nop [rax+rax*1], ax
0000757ab23d140c  nop [rax], eax
0000757ab23d1410  mov qword ptr [r15+0x40], 0x420000
0000757ab23d1418  mov eax, 0x4201B8
0000757ab23d141d  mov r14, [r13+rax*1]
0000757ab23d1422  movq xmm1, r14
0000757ab23d1427  mov rax, [r15+0x50]
0000757ab23d142b  mov r14, [r13+rax*1]
0000757ab23d1430  movq xmm15, r14
0000757ab23d1435  movaps [r15+0x120], xmm15
0000757ab23d143d  mov qword ptr [r15+0x48], 0x08
0000757ab23d1445  xor eax, eax
0000757ab23d1447  mov r14d, 0x08
0000757ab23d144d  mov r12d, 0x200
0000757ab23d1453  cmp r14, r12
0000757ab23d1456  cmc
0000757ab23d1457  lahf
0000757ab23d1458  seto al
0000757ab23d145b  mov [r15+0x108], eax
0000757ab23d1462  movq rax, xmm1
0000757ab23d1467  movq r14, xmm15
0000757ab23d146c  vmovq xmm1, rax
0000757ab23d1471  vmovq xmm15, r14
0000757ab23d1476  movaps xmm14, xmm1
0000757ab23d147a  addsd xmm14, xmm15
0000757ab23d147f  ucomisd xmm14, xmm14
0000757ab23d1484  jp 0x0000757AB23D1516
0000757ab23d148a  movq xmm14, xmm14
0000757ab23d148f  movaps [r15+0x110], xmm14
0000757ab23d1497  mov eax, [r15+0x108]
0000757ab23d149e  sahf
0000757ab23d149f  jnz 0x0000757AB23D14D1
0000757ab23d14a1  cmp dword ptr [r15+0x318], 0x00
0000757ab23d14a9  jz 0x0000757AB23D16A0
0000757ab23d14af  nop [rax+rax*1], ax
0000757ab23d14b8  nop [rax+rax*1], eax
0000757ab23d14c0  mov eax, 0x410154
0000757ab23d14c5  mov [r15+0x100], rax
0000757ab23d14cc  jmp 0x0000757AB21FE110
0000757ab23d14d1  cmp dword ptr [r15+0x318], 0x00
0000757ab23d14d9  jz 0x0000757AB23D1560
0000757ab23d14df  nop [rax+rax*1], ax
0000757ab23d14e8  nop [rax+rax*1], eax
0000757ab23d14f0  mov eax, 0x410140
0000757ab23d14f5  mov [r15+0x100], rax
0000757ab23d14fc  jmp 0x0000757AB21FE110
0000757ab23d1501  int3
0000757ab23d1502  call 0x0000757AB220DC20
0000757ab23d1507  jmp 0x0000757AB23D1422
0000757ab23d150c  call 0x0000757AB220DC20
0000757ab23d1511  jmp 0x0000757AB23D1430
0000757ab23d1516  ucomisd xmm1, xmm15
0000757ab23d151b  jp 0x0000757AB23D152A
0000757ab23d151d  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d1525  jmp 0x0000757AB23D148A
0000757ab23d152a  vxorps xmm0, xmm1, xmm15
0000757ab23d152f  pextrw eax, xmm0, 0x03
0000757ab23d1534  and eax, 0x7FF8
0000757ab23d1539  cmp eax, 0x08
0000757ab23d153c  jnz 0x0000757AB23D148A
0000757ab23d1542  movq rax, xmm15
0000757ab23d1547  shl rax, 0x0D
0000757ab23d154b  jbe 0x0000757AB23D148A
0000757ab23d1551  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d1559  jmp 0x0000757AB23D148A
0000757ab23d155e  int3
0000757ab23d155f  nop
0000757ab23d1560  mov rax, [r15+0x48]
0000757ab23d1564  mov r14, [r15+0x50]
0000757ab23d1568  lea r12, [r14+rax*1]
0000757ab23d156c  mov r14, [r13+r12*1]
0000757ab23d1571  movq xmm1, r14
0000757ab23d1576  movaps [r15+0x120], xmm1
0000757ab23d157e  lea r14, [rax+0x08]
0000757ab23d1582  mov [r15+0x48], r14
0000757ab23d1586  xor eax, eax
0000757ab23d1588  mov r12d, 0x200
0000757ab23d158e  cmp r14, r12
0000757ab23d1591  cmc
0000757ab23d1592  lahf
0000757ab23d1593  seto al
0000757ab23d1596  mov [r15+0x108], eax
0000757ab23d159d  movaps xmm15, [r15+0x110]
0000757ab23d15a5  movq rax, xmm15
0000757ab23d15aa  movq r14, xmm1
0000757ab23d15af  vmovq xmm1, rax
0000757ab23d15b4  vmovq xmm15, r14
0000757ab23d15b9  movaps xmm14, xmm1
0000757ab23d15bd  addsd xmm14, xmm15
0000757ab23d15c2  ucomisd xmm14, xmm14
0000757ab23d15c7  jp 0x0000757AB23D164F
0000757ab23d15cd  movq xmm14, xmm14
0000757ab23d15d2  movaps [r15+0x110], xmm14
0000757ab23d15da  mov eax, [r15+0x108]
0000757ab23d15e1  sahf
0000757ab23d15e2  jnz 0x0000757AB23D1614
0000757ab23d15e4  cmp dword ptr [r15+0x318], 0x00
0000757ab23d15ec  jz 0x0000757AB23D16A0
0000757ab23d15f2  nop [rax+rax*1], ax
0000757ab23d15fb  nop [rax+rax*1], eax
0000757ab23d1603  mov eax, 0x410154
0000757ab23d1608  mov [r15+0x100], rax
0000757ab23d160f  jmp 0x0000757AB21FE110
0000757ab23d1614  cmp dword ptr [r15+0x318], 0x00
0000757ab23d161c  jz 0x0000757AB23D1560
0000757ab23d1622  nop [rax+rax*1], ax
0000757ab23d162b  nop [rax+rax*1], eax
0000757ab23d1633  mov eax, 0x410140
0000757ab23d1638  mov [r15+0x100], rax
0000757ab23d163f  jmp 0x0000757AB21FE110
0000757ab23d1644  int3
0000757ab23d1645  call 0x0000757AB22C3AE0
0000757ab23d164a  jmp 0x0000757AB23D1571
0000757ab23d164f  ucomisd xmm1, xmm15
0000757ab23d1654  jp 0x0000757AB23D1663
0000757ab23d1656  movaps xmm14, [0x0000757AB1FFE030]
0000757ab23d165e  jmp 0x0000757AB23D15CD
0000757ab23d1663  vxorps xmm0, xmm1, xmm15
0000757ab23d1668  pextrw eax, xmm0, 0x03
0000757ab23d166d  and eax, 0x7FF8
0000757ab23d1672  cmp eax, 0x08
0000757ab23d1675  jnz 0x0000757AB23D15CD
0000757ab23d167b  movq rax, xmm15
0000757ab23d1680  shl rax, 0x0D
0000757ab23d1684  jbe 0x0000757AB23D15CD
0000757ab23d168a  vorps xmm14, xmm15, [0x0000757AB1FFE040]
0000757ab23d1692  jmp 0x0000757AB23D15CD
0000757ab23d1697  int3
0000757ab23d1698  nop [rax+rax*1], eax
0000757ab23d16a0  mov rax, [r15+0x40]
0000757ab23d16a4  lea r14, [rax+0x1B8]
0000757ab23d16ab  movaps xmm1, [r15+0x110]
0000757ab23d16b3  movq rax, xmm1
0000757ab23d16b8  mov [r13+r14*1], rax
0000757ab23d16bd  mov rax, [r15+0xF0]
0000757ab23d16c4  mov [r15+0x100], rax
0000757ab23d16cb  jmp 0x0000757AB23CE5C0
0000757ab23d16d0  int3
0000757ab23d16d1  call 0x0000757AB22D5EB0
0000757ab23d16d6  jmp 0x0000757AB23D16BD
0000757ab23d16db  int3
0000757ab23d16dc  nop [rax], eax
0000757ab23d16e0  mov qword ptr [r15+0x100], 0x04
0000757ab23d16eb  mov esi, 0x00
0000757ab23d16f0  mov edx, 0x09
0000757ab23d16f5  mov rdi, 0x7FFCD4F76D60
0000757ab23d16ff  mov rax, 0x56EBBAC67970
0000757ab23d1709  call rax
0000757ab23d170b  cmp dword ptr [r15+0x318], 0x00
0000757ab23d1713  jnz 0x0000757AB21FE110
0000757ab23d1719  jmp 0x0000757AB21FE0A0
0000757ab23d171e  int3
0000757ab23d171f  int3
