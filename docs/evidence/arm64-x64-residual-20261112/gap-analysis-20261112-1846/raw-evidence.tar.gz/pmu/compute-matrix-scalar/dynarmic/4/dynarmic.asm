00007cfd13bce69b  nop [rax+rax*1], eax
00007cfd13bce6a0  mov qword ptr [r15+0x40], 0x4201C0
00007cfd13bce6a8  mov qword ptr [r15+0x48], 0x4203C0
00007cfd13bce6b0  mov qword ptr [r15+0x60], 0x01
00007cfd13bce6b8  xorps xmm1, xmm1
00007cfd13bce6bb  mov eax, 0x41
00007cfd13bce6c0  vcvtusi2sd xmm1, xmm1, eax
00007cfd13bce6c6  mulsd xmm1, [0x00007CFD137FE010]
00007cfd13bce6ce  movq xmm1, xmm1
00007cfd13bce6d2  movaps [r15+0x120], xmm1
00007cfd13bce6da  mov eax, [r15+0x60]
00007cfd13bce6de  xorps xmm15, xmm15
00007cfd13bce6e2  vcvtusi2sd xmm15, xmm15, eax
00007cfd13bce6e8  mulsd xmm15, [0x00007CFD137FE020]
00007cfd13bce6f1  movq xmm15, xmm15
00007cfd13bce6f6  movaps [r15+0x110], xmm15
00007cfd13bce6fe  mov rax, [r15+0x60]
00007cfd13bce702  mov [rsp+0x10], rax
00007cfd13bce707  xor eax, eax
00007cfd13bce709  mov r14, [rsp+0x10]
00007cfd13bce70e  mov r12d, 0x40
00007cfd13bce714  cmp r14, r12
00007cfd13bce717  cmc
00007cfd13bce718  lahf
00007cfd13bce719  seto al
00007cfd13bce71c  mov [r15+0x108], eax
00007cfd13bce723  mov qword ptr [r15+0x50], 0x40
00007cfd13bce72b  movq rax, xmm1
00007cfd13bce730  mov r12d, 0x4203C0
00007cfd13bce736  mov [r13+r12*1], rax
00007cfd13bce73b  movq rax, xmm15
00007cfd13bce740  mov r12d, 0x4201C0
00007cfd13bce746  mov [r13+r12*1], rax
00007cfd13bce74b  mov [r15+0x58], r14
00007cfd13bce74f  mov eax, [r15+0x108]
00007cfd13bce756  sahf
00007cfd13bce757  jnz 0x00007CFD13BCE789
00007cfd13bce759  cmp dword ptr [r15+0x318], 0x00
00007cfd13bce761  jz 0x00007CFD13BCE910
00007cfd13bce767  nop [rax+rax*1], ax
00007cfd13bce770  nop [rax+rax*1], eax
00007cfd13bce778  mov eax, 0x410074
00007cfd13bce77d  mov [r15+0x100], rax
00007cfd13bce784  jmp 0x00007CFD139FE110
00007cfd13bce789  cmp dword ptr [r15+0x318], 0x00
00007cfd13bce791  jz 0x00007CFD13BCE7D0
00007cfd13bce797  nop [rax+rax*1], ax
00007cfd13bce7a0  nop [rax+rax*1], eax
00007cfd13bce7a8  mov eax, 0x41004C
00007cfd13bce7ad  mov [r15+0x100], rax
00007cfd13bce7b4  jmp 0x00007CFD139FE110
00007cfd13bce7b9  int3
00007cfd13bce7ba  call 0x00007CFD13AB4CB0
00007cfd13bce7bf  jmp 0x00007CFD13BCE73B
00007cfd13bce7c4  call 0x00007CFD13AB4CB0
00007cfd13bce7c9  jmp 0x00007CFD13BCE74B
00007cfd13bce7ce  int3
00007cfd13bce7cf  nop
00007cfd13bce7d0  mov rax, [r15+0x58]
00007cfd13bce7d4  lea r14, [rax+0x01]
00007cfd13bce7d8  mov [r15+0x60], r14
00007cfd13bce7dc  mov r14d, [r15+0x50]
00007cfd13bce7e0  xorps xmm1, xmm1
00007cfd13bce7e3  vcvtusi2sd xmm1, xmm1, r14d
00007cfd13bce7e9  mulsd xmm1, [0x00007CFD137FE010]
00007cfd13bce7f1  movq xmm1, xmm1
00007cfd13bce7f5  movaps [r15+0x120], xmm1
00007cfd13bce7fd  rorx r12, rax, 0x3D
00007cfd13bce803  and r12, 0xFFFFFFFFFFFFFFF8
00007cfd13bce807  mov eax, [r15+0x60]
00007cfd13bce80b  xorps xmm15, xmm15
00007cfd13bce80f  vcvtusi2sd xmm15, xmm15, eax
00007cfd13bce815  mulsd xmm15, [0x00007CFD137FE020]
00007cfd13bce81e  movq xmm15, xmm15
00007cfd13bce823  movaps [r15+0x110], xmm15
00007cfd13bce82b  mov rax, [r15+0x60]
00007cfd13bce82f  mov [rsp+0x10], rax
00007cfd13bce834  xor eax, eax
00007cfd13bce836  mov r11, [rsp+0x10]
00007cfd13bce83b  mov r10d, 0x40
00007cfd13bce841  cmp r11, r10
00007cfd13bce844  cmc
00007cfd13bce845  lahf
00007cfd13bce846  seto al
00007cfd13bce849  mov [r15+0x108], eax
00007cfd13bce850  lea eax, [r14d-0x01]
00007cfd13bce855  mov eax, eax
00007cfd13bce857  mov [r15+0x50], rax
00007cfd13bce85b  mov rax, [r15+0x48]
00007cfd13bce85f  lea r14, [rax+r12*1]
00007cfd13bce863  movq rax, xmm1
00007cfd13bce868  mov [r13+r14*1], rax
00007cfd13bce86d  mov rax, [r15+0x40]
00007cfd13bce871  lea r14, [rax+r12*1]
00007cfd13bce875  movq rax, xmm15
00007cfd13bce87a  mov [r13+r14*1], rax
00007cfd13bce87f  mov [r15+0x58], r11
00007cfd13bce883  mov eax, [r15+0x108]
00007cfd13bce88a  sahf
00007cfd13bce88b  jnz 0x00007CFD13BCE8BD
00007cfd13bce88d  cmp dword ptr [r15+0x318], 0x00
00007cfd13bce895  jz 0x00007CFD13BCE910
00007cfd13bce89b  nop [rax+rax*1], ax
00007cfd13bce8a4  nop [rax+rax*1], eax
00007cfd13bce8ac  mov eax, 0x410074
00007cfd13bce8b1  mov [r15+0x100], rax
00007cfd13bce8b8  jmp 0x00007CFD139FE110
00007cfd13bce8bd  cmp dword ptr [r15+0x318], 0x00
00007cfd13bce8c5  jz 0x00007CFD13BCE7D0
00007cfd13bce8cb  nop [rax+rax*1], ax
00007cfd13bce8d4  nop [rax+rax*1], eax
00007cfd13bce8dc  mov eax, 0x41004C
00007cfd13bce8e1  mov [r15+0x100], rax
00007cfd13bce8e8  jmp 0x00007CFD139FE110
00007cfd13bce8ed  int3
00007cfd13bce8ee  call 0x00007CFD13AD5EB0
00007cfd13bce8f3  jmp 0x00007CFD13BCE86D
00007cfd13bce8f8  call 0x00007CFD13AD5EB0
00007cfd13bce8fd  jmp 0x00007CFD13BCE87F
00007cfd13bce902  int3
00007cfd13bce903  nop [rax+rax*1], ax
00007cfd13bce90c  nop [rax], eax
00007cfd13bce910  vxorps xmm1, xmm1, xmm1
00007cfd13bce914  movq xmm1, xmm1
00007cfd13bce918  movaps [r15+0x110], xmm1
00007cfd13bce920  mov qword ptr [r15+0x58], 0x00
00007cfd13bce928  mov qword ptr [r15+0x50], 0x4205C0
00007cfd13bce930  mov qword ptr [r15+0x60], 0x00
00007cfd13bce938  mov qword ptr [r15+0x68], 0x4205C0
00007cfd13bce940  mov rax, [r15+0x40]
00007cfd13bce944  mov r14, [r13+rax*1]
00007cfd13bce949  lea r12, [rax+0x08]
00007cfd13bce94d  mov r11, [r13+r12*1]
00007cfd13bce952  movq xmm15, r14
00007cfd13bce957  movq xmm14, r11
00007cfd13bce95c  movq xmm15, xmm15
00007cfd13bce961  movq xmm15, xmm15
00007cfd13bce966  movaps [r15+0x120], xmm15
00007cfd13bce96e  movq xmm14, xmm14
00007cfd13bce973  movq xmm14, xmm14
00007cfd13bce978  movaps [r15+0x130], xmm14
00007cfd13bce980  lea r14, [rax+0x10]
00007cfd13bce984  mov r12, [r13+r14*1]
00007cfd13bce989  lea r14, [rax+0x18]
00007cfd13bce98d  mov r11, [r13+r14*1]
00007cfd13bce992  movq xmm15, r12
00007cfd13bce997  movq xmm14, r11
00007cfd13bce99c  movq xmm15, xmm15
00007cfd13bce9a1  movq xmm15, xmm15
00007cfd13bce9a6  movaps [r15+0x140], xmm15
00007cfd13bce9ae  movq xmm14, xmm14
00007cfd13bce9b3  movq xmm14, xmm14
00007cfd13bce9b8  movaps [r15+0x150], xmm14
00007cfd13bce9c0  lea r14, [rax+0x20]
00007cfd13bce9c4  mov r12, [r13+r14*1]
00007cfd13bce9c9  lea r14, [rax+0x28]
00007cfd13bce9cd  mov r11, [r13+r14*1]
00007cfd13bce9d2  movq xmm15, r12
00007cfd13bce9d7  movq xmm14, r11
00007cfd13bce9dc  movq xmm15, xmm15
00007cfd13bce9e1  movq xmm15, xmm15
00007cfd13bce9e6  movaps [r15+0x160], xmm15
00007cfd13bce9ee  movq xmm14, xmm14
00007cfd13bce9f3  movq xmm14, xmm14
00007cfd13bce9f8  movaps [r15+0x170], xmm14
00007cfd13bcea00  lea r14, [rax+0x30]
00007cfd13bcea04  mov r12, [r13+r14*1]
00007cfd13bcea09  lea r14, [rax+0x38]
00007cfd13bcea0d  mov rax, [r13+r14*1]
00007cfd13bcea12  movq xmm15, r12
00007cfd13bcea17  movq xmm14, rax
00007cfd13bcea1c  movq xmm15, xmm15
00007cfd13bcea21  movq xmm15, xmm15
00007cfd13bcea26  movaps [r15+0x180], xmm15
00007cfd13bcea2e  movq xmm14, xmm14
00007cfd13bcea33  movq xmm14, xmm14
00007cfd13bcea38  movaps [r15+0x210], xmm14
00007cfd13bcea40  mov rax, [r15+0x48]
00007cfd13bcea44  mov [r15+0x78], rax
00007cfd13bcea48  mov r14, [r13+rax*1]
00007cfd13bcea4d  movq xmm15, r14
00007cfd13bcea52  lea r14, [rax+0x40]
00007cfd13bcea56  mov r12, [r13+r14*1]
00007cfd13bcea5b  movq xmm14, r12
00007cfd13bcea60  lea r14, [rax+0x80]
00007cfd13bcea67  mov r12, [r13+r14*1]
00007cfd13bcea6c  movq xmm13, r12
00007cfd13bcea71  movaps xmm12, [r15+0x120]
00007cfd13bcea79  movq r14, xmm12
00007cfd13bcea7e  movq r12, xmm15
00007cfd13bcea83  vmovq xmm15, r14
00007cfd13bcea88  vmovq xmm12, r12
00007cfd13bcea8d  movaps xmm11, xmm15
00007cfd13bcea91  mulsd xmm11, xmm12
00007cfd13bcea96  ucomisd xmm11, xmm11
00007cfd13bcea9b  jp 0x00007CFD13BCEEFC
00007cfd13bceaa1  movq xmm11, xmm11
00007cfd13bceaa6  movaps xmm15, [r15+0x130]
00007cfd13bceaae  movq r14, xmm15
00007cfd13bceab3  movq r12, xmm14
00007cfd13bceab8  vmovq xmm15, r14
00007cfd13bceabd  vmovq xmm14, r12
00007cfd13bceac2  movaps xmm12, xmm15
00007cfd13bceac6  mulsd xmm12, xmm14
00007cfd13bceacb  ucomisd xmm12, xmm12
00007cfd13bcead0  jp 0x00007CFD13BCEF48
00007cfd13bcead6  movq xmm12, xmm12
00007cfd13bceadb  movq r14, xmm11
00007cfd13bceae0  movq r12, xmm1
00007cfd13bceae5  vmovq xmm1, r14
00007cfd13bceaea  vmovq xmm15, r12
00007cfd13bceaef  movaps xmm14, xmm1
00007cfd13bceaf3  addsd xmm14, xmm15
00007cfd13bceaf8  ucomisd xmm14, xmm14
00007cfd13bceafd  jp 0x00007CFD13BCEF94
00007cfd13bceb03  movq xmm14, xmm14
00007cfd13bceb08  movq r14, xmm14
00007cfd13bceb0d  movq r12, xmm12
00007cfd13bceb12  vmovq xmm1, r14
00007cfd13bceb17  vmovq xmm15, r12
00007cfd13bceb1c  movaps xmm14, xmm1
00007cfd13bceb20  addsd xmm14, xmm15
00007cfd13bceb25  ucomisd xmm14, xmm14
00007cfd13bceb2a  jp 0x00007CFD13BCEFE0
00007cfd13bceb30  movq xmm14, xmm14
00007cfd13bceb35  movaps xmm1, [r15+0x140]
00007cfd13bceb3d  movq r14, xmm1
00007cfd13bceb42  movq r12, xmm13
00007cfd13bceb47  vmovq xmm1, r14
00007cfd13bceb4c  vmovq xmm15, r12
00007cfd13bceb51  movaps xmm13, xmm1
00007cfd13bceb55  mulsd xmm13, xmm15
00007cfd13bceb5a  ucomisd xmm13, xmm13
00007cfd13bceb5f  jp 0x00007CFD13BCF02C
00007cfd13bceb65  movq xmm13, xmm13
00007cfd13bceb6a  lea r14, [rax+0xC0]
00007cfd13bceb71  mov r12, [r13+r14*1]
00007cfd13bceb76  movq xmm1, r12
00007cfd13bceb7b  movq r14, xmm14
00007cfd13bceb80  movq r12, xmm13
00007cfd13bceb85  vmovq xmm15, r14
00007cfd13bceb8a  vmovq xmm14, r12
00007cfd13bceb8f  movaps xmm13, xmm15
00007cfd13bceb93  addsd xmm13, xmm14
00007cfd13bceb98  ucomisd xmm13, xmm13
00007cfd13bceb9d  jp 0x00007CFD13BCF082
00007cfd13bceba3  movq xmm13, xmm13
00007cfd13bceba8  movaps xmm15, [r15+0x150]
00007cfd13bcebb0  movq r14, xmm15
00007cfd13bcebb5  movq r12, xmm1
00007cfd13bcebba  vmovq xmm1, r14
00007cfd13bcebbf  vmovq xmm15, r12
00007cfd13bcebc4  movaps xmm14, xmm1
00007cfd13bcebc8  mulsd xmm14, xmm15
00007cfd13bcebcd  ucomisd xmm14, xmm14
00007cfd13bcebd2  jp 0x00007CFD13BCF0CE
00007cfd13bcebd8  movq xmm14, xmm14
00007cfd13bcebdd  lea r14, [rax+0x100]
00007cfd13bcebe4  mov r12, [r13+r14*1]
00007cfd13bcebe9  movq xmm1, r12
00007cfd13bcebee  movq r14, xmm13
00007cfd13bcebf3  movq r12, xmm14
00007cfd13bcebf8  vmovq xmm15, r14
00007cfd13bcebfd  vmovq xmm14, r12
00007cfd13bcec02  movaps xmm13, xmm15
00007cfd13bcec06  addsd xmm13, xmm14
00007cfd13bcec0b  ucomisd xmm13, xmm13
00007cfd13bcec10  jp 0x00007CFD13BCF124
00007cfd13bcec16  movq xmm13, xmm13
00007cfd13bcec1b  movaps xmm15, [r15+0x160]
00007cfd13bcec23  movq r14, xmm15
00007cfd13bcec28  movq r12, xmm1
00007cfd13bcec2d  vmovq xmm1, r14
00007cfd13bcec32  vmovq xmm15, r12
00007cfd13bcec37  movaps xmm14, xmm1
00007cfd13bcec3b  mulsd xmm14, xmm15
00007cfd13bcec40  ucomisd xmm14, xmm14
00007cfd13bcec45  jp 0x00007CFD13BCF170
00007cfd13bcec4b  movq xmm14, xmm14
00007cfd13bcec50  lea r14, [rax+0x140]
00007cfd13bcec57  mov r12, [r13+r14*1]
00007cfd13bcec5c  movq xmm1, r12
00007cfd13bcec61  movq r14, xmm13
00007cfd13bcec66  movq r12, xmm14
00007cfd13bcec6b  vmovq xmm15, r14
00007cfd13bcec70  vmovq xmm14, r12
00007cfd13bcec75  movaps xmm13, xmm15
00007cfd13bcec79  addsd xmm13, xmm14
00007cfd13bcec7e  ucomisd xmm13, xmm13
00007cfd13bcec83  jp 0x00007CFD13BCF1C6
00007cfd13bcec89  movq xmm13, xmm13
00007cfd13bcec8e  movaps xmm15, [r15+0x170]
00007cfd13bcec96  movq r14, xmm15
00007cfd13bcec9b  movq r12, xmm1
00007cfd13bceca0  vmovq xmm1, r14
00007cfd13bceca5  vmovq xmm15, r12
00007cfd13bcecaa  movaps xmm14, xmm1
00007cfd13bcecae  mulsd xmm14, xmm15
00007cfd13bcecb3  ucomisd xmm14, xmm14
00007cfd13bcecb8  jp 0x00007CFD13BCF212
00007cfd13bcecbe  movq xmm14, xmm14
00007cfd13bcecc3  lea r14, [rax+0x180]
00007cfd13bcecca  mov r12, [r13+r14*1]
00007cfd13bceccf  movq xmm1, r12
00007cfd13bcecd4  movq r14, xmm13
00007cfd13bcecd9  movq r12, xmm14
00007cfd13bcecde  vmovq xmm15, r14
00007cfd13bcece3  vmovq xmm14, r12
00007cfd13bcece8  movaps xmm13, xmm15
00007cfd13bcecec  addsd xmm13, xmm14
00007cfd13bcecf1  ucomisd xmm13, xmm13
00007cfd13bcecf6  jp 0x00007CFD13BCF268
00007cfd13bcecfc  movq xmm13, xmm13
00007cfd13bced01  movaps xmm15, [r15+0x180]
00007cfd13bced09  movq r14, xmm15
00007cfd13bced0e  movq r12, xmm1
00007cfd13bced13  vmovq xmm1, r14
00007cfd13bced18  vmovq xmm15, r12
00007cfd13bced1d  movaps xmm14, xmm1
00007cfd13bced21  mulsd xmm14, xmm15
00007cfd13bced26  ucomisd xmm14, xmm14
00007cfd13bced2b  jp 0x00007CFD13BCF2B4
00007cfd13bced31  movq xmm14, xmm14
00007cfd13bced36  lea r14, [rax+0x1C0]
00007cfd13bced3d  mov rax, [r13+r14*1]
00007cfd13bced42  movq xmm1, rax
00007cfd13bced47  movaps [r15+0x240], xmm1
00007cfd13bced4f  movq rax, xmm13
00007cfd13bced54  movq r14, xmm14
00007cfd13bced59  vmovq xmm15, rax
00007cfd13bced5e  vmovq xmm14, r14
00007cfd13bced63  movaps xmm13, xmm15
00007cfd13bced67  addsd xmm13, xmm14
00007cfd13bced6c  ucomisd xmm13, xmm13
00007cfd13bced71  jp 0x00007CFD13BCF30A
00007cfd13bced77  movq xmm13, xmm13
00007cfd13bced7c  movaps xmm15, [r15+0x210]
00007cfd13bced84  movq rax, xmm15
00007cfd13bced89  movq r14, xmm1
00007cfd13bced8e  vmovq xmm1, rax
00007cfd13bced93  vmovq xmm15, r14
00007cfd13bced98  movaps xmm14, xmm1
00007cfd13bced9c  mulsd xmm14, xmm15
00007cfd13bceda1  ucomisd xmm14, xmm14
00007cfd13bceda6  jp 0x00007CFD13BCF352
00007cfd13bcedac  movq xmm14, xmm14
00007cfd13bcedb1  movaps [r15+0x230], xmm14
00007cfd13bcedb9  movq rax, xmm13
00007cfd13bcedbe  movq r14, xmm14
00007cfd13bcedc3  vmovq xmm1, rax
00007cfd13bcedc8  vmovq xmm15, r14
00007cfd13bcedcd  movaps xmm14, xmm1
00007cfd13bcedd1  addsd xmm14, xmm15
00007cfd13bcedd6  ucomisd xmm14, xmm14
00007cfd13bceddb  jp 0x00007CFD13BCF39A
00007cfd13bcede1  movq xmm14, xmm14
00007cfd13bcede6  movaps [r15+0x220], xmm14
00007cfd13bcedee  movq rax, xmm14
00007cfd13bcedf3  mov r14d, 0x4205C0
00007cfd13bcedf9  mov [r13+r14*1], rax
00007cfd13bcedfe  mov qword ptr [r15+0x70], 0x08
00007cfd13bcee06  xor eax, eax
00007cfd13bcee08  mov r14d, 0x08
00007cfd13bcee0e  mov r12d, 0x40
00007cfd13bcee14  cmp r14, r12
00007cfd13bcee17  cmc
00007cfd13bcee18  lahf
00007cfd13bcee19  seto al
00007cfd13bcee1c  mov [r15+0x108], eax
00007cfd13bcee23  mov eax, [r15+0x108]
00007cfd13bcee2a  sahf
00007cfd13bcee2b  jnz 0x00007CFD13BCEE5D
00007cfd13bcee2d  cmp dword ptr [r15+0x318], 0x00
00007cfd13bcee35  jz 0x00007CFD13BCFD40
00007cfd13bcee3b  nop [rax+rax*1], ax
00007cfd13bcee44  nop [rax+rax*1], eax
00007cfd13bcee4c  mov eax, 0x410118
00007cfd13bcee51  mov [r15+0x100], rax
00007cfd13bcee58  jmp 0x00007CFD139FE110
00007cfd13bcee5d  cmp dword ptr [r15+0x318], 0x00
00007cfd13bcee65  jz 0x00007CFD13BCF3F0
00007cfd13bcee6b  nop [rax+rax*1], ax
00007cfd13bcee74  nop [rax+rax*1], eax
00007cfd13bcee7c  mov eax, 0x4100A4
00007cfd13bcee81  mov [r15+0x100], rax
00007cfd13bcee88  jmp 0x00007CFD139FE110
00007cfd13bcee8d  int3
00007cfd13bcee8e  call 0x00007CFD13A0DC20
00007cfd13bcee93  jmp 0x00007CFD13BCE949
00007cfd13bcee98  call 0x00007CFD13AC0370
00007cfd13bcee9d  jmp 0x00007CFD13BCE952
00007cfd13bceea2  call 0x00007CFD13AE27E0
00007cfd13bceea7  jmp 0x00007CFD13BCE989
00007cfd13bceeac  call 0x00007CFD13AE1570
00007cfd13bceeb1  jmp 0x00007CFD13BCE992
00007cfd13bceeb6  call 0x00007CFD13AE27E0
00007cfd13bceebb  jmp 0x00007CFD13BCE9C9
00007cfd13bceec0  call 0x00007CFD13AE1570
00007cfd13bceec5  jmp 0x00007CFD13BCE9D2
00007cfd13bceeca  call 0x00007CFD13AE27E0
00007cfd13bceecf  jmp 0x00007CFD13BCEA09
00007cfd13bceed4  call 0x00007CFD13AD59C0
00007cfd13bceed9  jmp 0x00007CFD13BCEA12
00007cfd13bceede  call 0x00007CFD13A0DC20
00007cfd13bceee3  jmp 0x00007CFD13BCEA4D
00007cfd13bceee8  call 0x00007CFD13AE27E0
00007cfd13bceeed  jmp 0x00007CFD13BCEA5B
00007cfd13bceef2  call 0x00007CFD13AE27E0
00007cfd13bceef7  jmp 0x00007CFD13BCEA6C
00007cfd13bceefc  ucomisd xmm15, xmm12
00007cfd13bcef01  jp 0x00007CFD13BCEF10
00007cfd13bcef03  movaps xmm11, [0x00007CFD137FE030]
00007cfd13bcef0b  jmp 0x00007CFD13BCEAA1
00007cfd13bcef10  vxorps xmm0, xmm15, xmm12
00007cfd13bcef15  pextrw r14d, xmm0, 0x03
00007cfd13bcef1b  and r14d, 0x7FF8
00007cfd13bcef22  cmp r14d, 0x08
00007cfd13bcef26  jnz 0x00007CFD13BCEAA1
00007cfd13bcef2c  movq r14, xmm12
00007cfd13bcef31  shl r14, 0x0D
00007cfd13bcef35  jbe 0x00007CFD13BCEAA1
00007cfd13bcef3b  vorps xmm11, xmm12, [0x00007CFD137FE040]
00007cfd13bcef43  jmp 0x00007CFD13BCEAA1
00007cfd13bcef48  ucomisd xmm15, xmm14
00007cfd13bcef4d  jp 0x00007CFD13BCEF5C
00007cfd13bcef4f  movaps xmm12, [0x00007CFD137FE030]
00007cfd13bcef57  jmp 0x00007CFD13BCEAD6
00007cfd13bcef5c  vxorps xmm0, xmm15, xmm14
00007cfd13bcef61  pextrw r14d, xmm0, 0x03
00007cfd13bcef67  and r14d, 0x7FF8
00007cfd13bcef6e  cmp r14d, 0x08
00007cfd13bcef72  jnz 0x00007CFD13BCEAD6
00007cfd13bcef78  movq r14, xmm14
00007cfd13bcef7d  shl r14, 0x0D
00007cfd13bcef81  jbe 0x00007CFD13BCEAD6
00007cfd13bcef87  vorps xmm12, xmm14, [0x00007CFD137FE040]
00007cfd13bcef8f  jmp 0x00007CFD13BCEAD6
00007cfd13bcef94  ucomisd xmm1, xmm15
00007cfd13bcef99  jp 0x00007CFD13BCEFA8
00007cfd13bcef9b  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcefa3  jmp 0x00007CFD13BCEB03
00007cfd13bcefa8  vxorps xmm0, xmm1, xmm15
00007cfd13bcefad  pextrw r14d, xmm0, 0x03
00007cfd13bcefb3  and r14d, 0x7FF8
00007cfd13bcefba  cmp r14d, 0x08
00007cfd13bcefbe  jnz 0x00007CFD13BCEB03
00007cfd13bcefc4  movq r14, xmm15
00007cfd13bcefc9  shl r14, 0x0D
00007cfd13bcefcd  jbe 0x00007CFD13BCEB03
00007cfd13bcefd3  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcefdb  jmp 0x00007CFD13BCEB03
00007cfd13bcefe0  ucomisd xmm1, xmm15
00007cfd13bcefe5  jp 0x00007CFD13BCEFF4
00007cfd13bcefe7  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcefef  jmp 0x00007CFD13BCEB30
00007cfd13bceff4  vxorps xmm0, xmm1, xmm15
00007cfd13bceff9  pextrw r14d, xmm0, 0x03
00007cfd13bcefff  and r14d, 0x7FF8
00007cfd13bcf006  cmp r14d, 0x08
00007cfd13bcf00a  jnz 0x00007CFD13BCEB30
00007cfd13bcf010  movq r14, xmm15
00007cfd13bcf015  shl r14, 0x0D
00007cfd13bcf019  jbe 0x00007CFD13BCEB30
00007cfd13bcf01f  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcf027  jmp 0x00007CFD13BCEB30
00007cfd13bcf02c  ucomisd xmm1, xmm15
00007cfd13bcf031  jp 0x00007CFD13BCF040
00007cfd13bcf033  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf03b  jmp 0x00007CFD13BCEB65
00007cfd13bcf040  vxorps xmm0, xmm1, xmm15
00007cfd13bcf045  pextrw r14d, xmm0, 0x03
00007cfd13bcf04b  and r14d, 0x7FF8
00007cfd13bcf052  cmp r14d, 0x08
00007cfd13bcf056  jnz 0x00007CFD13BCEB65
00007cfd13bcf05c  movq r14, xmm15
00007cfd13bcf061  shl r14, 0x0D
00007cfd13bcf065  jbe 0x00007CFD13BCEB65
00007cfd13bcf06b  vorps xmm13, xmm15, [0x00007CFD137FE040]
00007cfd13bcf073  jmp 0x00007CFD13BCEB65
00007cfd13bcf078  call 0x00007CFD13AE27E0
00007cfd13bcf07d  jmp 0x00007CFD13BCEB76
00007cfd13bcf082  ucomisd xmm15, xmm14
00007cfd13bcf087  jp 0x00007CFD13BCF096
00007cfd13bcf089  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf091  jmp 0x00007CFD13BCEBA3
00007cfd13bcf096  vxorps xmm0, xmm15, xmm14
00007cfd13bcf09b  pextrw r14d, xmm0, 0x03
00007cfd13bcf0a1  and r14d, 0x7FF8
00007cfd13bcf0a8  cmp r14d, 0x08
00007cfd13bcf0ac  jnz 0x00007CFD13BCEBA3
00007cfd13bcf0b2  movq r14, xmm14
00007cfd13bcf0b7  shl r14, 0x0D
00007cfd13bcf0bb  jbe 0x00007CFD13BCEBA3
00007cfd13bcf0c1  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcf0c9  jmp 0x00007CFD13BCEBA3
00007cfd13bcf0ce  ucomisd xmm1, xmm15
00007cfd13bcf0d3  jp 0x00007CFD13BCF0E2
00007cfd13bcf0d5  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcf0dd  jmp 0x00007CFD13BCEBD8
00007cfd13bcf0e2  vxorps xmm0, xmm1, xmm15
00007cfd13bcf0e7  pextrw r14d, xmm0, 0x03
00007cfd13bcf0ed  and r14d, 0x7FF8
00007cfd13bcf0f4  cmp r14d, 0x08
00007cfd13bcf0f8  jnz 0x00007CFD13BCEBD8
00007cfd13bcf0fe  movq r14, xmm15
00007cfd13bcf103  shl r14, 0x0D
00007cfd13bcf107  jbe 0x00007CFD13BCEBD8
00007cfd13bcf10d  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcf115  jmp 0x00007CFD13BCEBD8
00007cfd13bcf11a  call 0x00007CFD13AE27E0
00007cfd13bcf11f  jmp 0x00007CFD13BCEBE9
00007cfd13bcf124  ucomisd xmm15, xmm14
00007cfd13bcf129  jp 0x00007CFD13BCF138
00007cfd13bcf12b  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf133  jmp 0x00007CFD13BCEC16
00007cfd13bcf138  vxorps xmm0, xmm15, xmm14
00007cfd13bcf13d  pextrw r14d, xmm0, 0x03
00007cfd13bcf143  and r14d, 0x7FF8
00007cfd13bcf14a  cmp r14d, 0x08
00007cfd13bcf14e  jnz 0x00007CFD13BCEC16
00007cfd13bcf154  movq r14, xmm14
00007cfd13bcf159  shl r14, 0x0D
00007cfd13bcf15d  jbe 0x00007CFD13BCEC16
00007cfd13bcf163  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcf16b  jmp 0x00007CFD13BCEC16
00007cfd13bcf170  ucomisd xmm1, xmm15
00007cfd13bcf175  jp 0x00007CFD13BCF184
00007cfd13bcf177  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcf17f  jmp 0x00007CFD13BCEC4B
00007cfd13bcf184  vxorps xmm0, xmm1, xmm15
00007cfd13bcf189  pextrw r14d, xmm0, 0x03
00007cfd13bcf18f  and r14d, 0x7FF8
00007cfd13bcf196  cmp r14d, 0x08
00007cfd13bcf19a  jnz 0x00007CFD13BCEC4B
00007cfd13bcf1a0  movq r14, xmm15
00007cfd13bcf1a5  shl r14, 0x0D
00007cfd13bcf1a9  jbe 0x00007CFD13BCEC4B
00007cfd13bcf1af  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcf1b7  jmp 0x00007CFD13BCEC4B
00007cfd13bcf1bc  call 0x00007CFD13AE27E0
00007cfd13bcf1c1  jmp 0x00007CFD13BCEC5C
00007cfd13bcf1c6  ucomisd xmm15, xmm14
00007cfd13bcf1cb  jp 0x00007CFD13BCF1DA
00007cfd13bcf1cd  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf1d5  jmp 0x00007CFD13BCEC89
00007cfd13bcf1da  vxorps xmm0, xmm15, xmm14
00007cfd13bcf1df  pextrw r14d, xmm0, 0x03
00007cfd13bcf1e5  and r14d, 0x7FF8
00007cfd13bcf1ec  cmp r14d, 0x08
00007cfd13bcf1f0  jnz 0x00007CFD13BCEC89
00007cfd13bcf1f6  movq r14, xmm14
00007cfd13bcf1fb  shl r14, 0x0D
00007cfd13bcf1ff  jbe 0x00007CFD13BCEC89
00007cfd13bcf205  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcf20d  jmp 0x00007CFD13BCEC89
00007cfd13bcf212  ucomisd xmm1, xmm15
00007cfd13bcf217  jp 0x00007CFD13BCF226
00007cfd13bcf219  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcf221  jmp 0x00007CFD13BCECBE
00007cfd13bcf226  vxorps xmm0, xmm1, xmm15
00007cfd13bcf22b  pextrw r14d, xmm0, 0x03
00007cfd13bcf231  and r14d, 0x7FF8
00007cfd13bcf238  cmp r14d, 0x08
00007cfd13bcf23c  jnz 0x00007CFD13BCECBE
00007cfd13bcf242  movq r14, xmm15
00007cfd13bcf247  shl r14, 0x0D
00007cfd13bcf24b  jbe 0x00007CFD13BCECBE
00007cfd13bcf251  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcf259  jmp 0x00007CFD13BCECBE
00007cfd13bcf25e  call 0x00007CFD13AE27E0
00007cfd13bcf263  jmp 0x00007CFD13BCECCF
00007cfd13bcf268  ucomisd xmm15, xmm14
00007cfd13bcf26d  jp 0x00007CFD13BCF27C
00007cfd13bcf26f  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf277  jmp 0x00007CFD13BCECFC
00007cfd13bcf27c  vxorps xmm0, xmm15, xmm14
00007cfd13bcf281  pextrw r14d, xmm0, 0x03
00007cfd13bcf287  and r14d, 0x7FF8
00007cfd13bcf28e  cmp r14d, 0x08
00007cfd13bcf292  jnz 0x00007CFD13BCECFC
00007cfd13bcf298  movq r14, xmm14
00007cfd13bcf29d  shl r14, 0x0D
00007cfd13bcf2a1  jbe 0x00007CFD13BCECFC
00007cfd13bcf2a7  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcf2af  jmp 0x00007CFD13BCECFC
00007cfd13bcf2b4  ucomisd xmm1, xmm15
00007cfd13bcf2b9  jp 0x00007CFD13BCF2C8
00007cfd13bcf2bb  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcf2c3  jmp 0x00007CFD13BCED31
00007cfd13bcf2c8  vxorps xmm0, xmm1, xmm15
00007cfd13bcf2cd  pextrw r14d, xmm0, 0x03
00007cfd13bcf2d3  and r14d, 0x7FF8
00007cfd13bcf2da  cmp r14d, 0x08
00007cfd13bcf2de  jnz 0x00007CFD13BCED31
00007cfd13bcf2e4  movq r14, xmm15
00007cfd13bcf2e9  shl r14, 0x0D
00007cfd13bcf2ed  jbe 0x00007CFD13BCED31
00007cfd13bcf2f3  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcf2fb  jmp 0x00007CFD13BCED31
00007cfd13bcf300  call 0x00007CFD13AD59C0
00007cfd13bcf305  jmp 0x00007CFD13BCED42
00007cfd13bcf30a  ucomisd xmm15, xmm14
00007cfd13bcf30f  jp 0x00007CFD13BCF31E
00007cfd13bcf311  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf319  jmp 0x00007CFD13BCED77
00007cfd13bcf31e  vxorps xmm0, xmm15, xmm14
00007cfd13bcf323  pextrw eax, xmm0, 0x03
00007cfd13bcf328  and eax, 0x7FF8
00007cfd13bcf32d  cmp eax, 0x08
00007cfd13bcf330  jnz 0x00007CFD13BCED77
00007cfd13bcf336  movq rax, xmm14
00007cfd13bcf33b  shl rax, 0x0D
00007cfd13bcf33f  jbe 0x00007CFD13BCED77
00007cfd13bcf345  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcf34d  jmp 0x00007CFD13BCED77
00007cfd13bcf352  ucomisd xmm1, xmm15
00007cfd13bcf357  jp 0x00007CFD13BCF366
00007cfd13bcf359  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcf361  jmp 0x00007CFD13BCEDAC
00007cfd13bcf366  vxorps xmm0, xmm1, xmm15
00007cfd13bcf36b  pextrw eax, xmm0, 0x03
00007cfd13bcf370  and eax, 0x7FF8
00007cfd13bcf375  cmp eax, 0x08
00007cfd13bcf378  jnz 0x00007CFD13BCEDAC
00007cfd13bcf37e  movq rax, xmm15
00007cfd13bcf383  shl rax, 0x0D
00007cfd13bcf387  jbe 0x00007CFD13BCEDAC
00007cfd13bcf38d  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcf395  jmp 0x00007CFD13BCEDAC
00007cfd13bcf39a  ucomisd xmm1, xmm15
00007cfd13bcf39f  jp 0x00007CFD13BCF3AE
00007cfd13bcf3a1  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcf3a9  jmp 0x00007CFD13BCEDE1
00007cfd13bcf3ae  vxorps xmm0, xmm1, xmm15
00007cfd13bcf3b3  pextrw eax, xmm0, 0x03
00007cfd13bcf3b8  and eax, 0x7FF8
00007cfd13bcf3bd  cmp eax, 0x08
00007cfd13bcf3c0  jnz 0x00007CFD13BCEDE1
00007cfd13bcf3c6  movq rax, xmm15
00007cfd13bcf3cb  shl rax, 0x0D
00007cfd13bcf3cf  jbe 0x00007CFD13BCEDE1
00007cfd13bcf3d5  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcf3dd  jmp 0x00007CFD13BCEDE1
00007cfd13bcf3e2  call 0x00007CFD13AD5EB0
00007cfd13bcf3e7  jmp 0x00007CFD13BCEDFE
00007cfd13bcf3ec  int3
00007cfd13bcf3ed  nop [rax], eax
00007cfd13bcf3f0  mov rax, [r15+0x48]
00007cfd13bcf3f4  mov r14, [r15+0x70]
00007cfd13bcf3f8  lea r12, [rax+r14*1]
00007cfd13bcf3fc  mov [r15+0x78], r12
00007cfd13bcf400  mov rax, [r13+r12*1]
00007cfd13bcf405  movq xmm1, rax
00007cfd13bcf40a  lea rax, [r12+0x40]
00007cfd13bcf40f  mov r11, [r13+rax*1]
00007cfd13bcf414  movq xmm15, r11
00007cfd13bcf419  lea rax, [r12+0x80]
00007cfd13bcf421  mov r11, [r13+rax*1]
00007cfd13bcf426  movq xmm14, r11
00007cfd13bcf42b  movaps xmm13, [r15+0x120]
00007cfd13bcf433  movq rax, xmm13
00007cfd13bcf438  movq r11, xmm1
00007cfd13bcf43d  vmovq xmm1, rax
00007cfd13bcf442  vmovq xmm13, r11
00007cfd13bcf447  movaps xmm12, xmm1
00007cfd13bcf44b  mulsd xmm12, xmm13
00007cfd13bcf450  ucomisd xmm12, xmm12
00007cfd13bcf455  jp 0x00007CFD13BCF879
00007cfd13bcf45b  movq xmm12, xmm12
00007cfd13bcf460  movaps xmm1, [r15+0x130]
00007cfd13bcf468  movq rax, xmm1
00007cfd13bcf46d  movq r11, xmm15
00007cfd13bcf472  vmovq xmm1, rax
00007cfd13bcf477  vmovq xmm15, r11
00007cfd13bcf47c  movaps xmm13, xmm1
00007cfd13bcf480  mulsd xmm13, xmm15
00007cfd13bcf485  ucomisd xmm13, xmm13
00007cfd13bcf48a  jp 0x00007CFD13BCF8C1
00007cfd13bcf490  movq xmm13, xmm13
00007cfd13bcf495  movq rax, xmm12
00007cfd13bcf49a  movaps xmm1, [r15+0x110]
00007cfd13bcf4a2  movq r11, xmm1
00007cfd13bcf4a7  vmovq xmm1, rax
00007cfd13bcf4ac  vmovq xmm15, r11
00007cfd13bcf4b1  movaps xmm12, xmm1
00007cfd13bcf4b5  addsd xmm12, xmm15
00007cfd13bcf4ba  ucomisd xmm12, xmm12
00007cfd13bcf4bf  jp 0x00007CFD13BCF909
00007cfd13bcf4c5  movq xmm12, xmm12
00007cfd13bcf4ca  movq rax, xmm12
00007cfd13bcf4cf  movq r11, xmm13
00007cfd13bcf4d4  vmovq xmm1, rax
00007cfd13bcf4d9  vmovq xmm15, r11
00007cfd13bcf4de  movaps xmm13, xmm1
00007cfd13bcf4e2  addsd xmm13, xmm15
00007cfd13bcf4e7  ucomisd xmm13, xmm13
00007cfd13bcf4ec  jp 0x00007CFD13BCF951
00007cfd13bcf4f2  movq xmm13, xmm13
00007cfd13bcf4f7  movaps xmm1, [r15+0x140]
00007cfd13bcf4ff  movq rax, xmm1
00007cfd13bcf504  movq r11, xmm14
00007cfd13bcf509  vmovq xmm1, rax
00007cfd13bcf50e  vmovq xmm15, r11
00007cfd13bcf513  movaps xmm14, xmm1
00007cfd13bcf517  mulsd xmm14, xmm15
00007cfd13bcf51c  ucomisd xmm14, xmm14
00007cfd13bcf521  jp 0x00007CFD13BCF999
00007cfd13bcf527  movq xmm14, xmm14
00007cfd13bcf52c  lea rax, [r12+0xC0]
00007cfd13bcf534  mov r11, [r13+rax*1]
00007cfd13bcf539  movq xmm1, r11
00007cfd13bcf53e  movq rax, xmm13
00007cfd13bcf543  movq r11, xmm14
00007cfd13bcf548  vmovq xmm15, rax
00007cfd13bcf54d  vmovq xmm14, r11
00007cfd13bcf552  movaps xmm13, xmm15
00007cfd13bcf556  addsd xmm13, xmm14
00007cfd13bcf55b  ucomisd xmm13, xmm13
00007cfd13bcf560  jp 0x00007CFD13BCF9EB
00007cfd13bcf566  movq xmm13, xmm13
00007cfd13bcf56b  movaps xmm15, [r15+0x150]
00007cfd13bcf573  movq rax, xmm15
00007cfd13bcf578  movq r11, xmm1
00007cfd13bcf57d  vmovq xmm1, rax
00007cfd13bcf582  vmovq xmm15, r11
00007cfd13bcf587  movaps xmm14, xmm1
00007cfd13bcf58b  mulsd xmm14, xmm15
00007cfd13bcf590  ucomisd xmm14, xmm14
00007cfd13bcf595  jp 0x00007CFD13BCFA33
00007cfd13bcf59b  movq xmm14, xmm14
00007cfd13bcf5a0  lea rax, [r12+0x100]
00007cfd13bcf5a8  mov r11, [r13+rax*1]
00007cfd13bcf5ad  movq xmm1, r11
00007cfd13bcf5b2  movq rax, xmm13
00007cfd13bcf5b7  movq r11, xmm14
00007cfd13bcf5bc  vmovq xmm15, rax
00007cfd13bcf5c1  vmovq xmm14, r11
00007cfd13bcf5c6  movaps xmm13, xmm15
00007cfd13bcf5ca  addsd xmm13, xmm14
00007cfd13bcf5cf  ucomisd xmm13, xmm13
00007cfd13bcf5d4  jp 0x00007CFD13BCFA85
00007cfd13bcf5da  movq xmm13, xmm13
00007cfd13bcf5df  movaps xmm15, [r15+0x160]
00007cfd13bcf5e7  movq rax, xmm15
00007cfd13bcf5ec  movq r11, xmm1
00007cfd13bcf5f1  vmovq xmm1, rax
00007cfd13bcf5f6  vmovq xmm15, r11
00007cfd13bcf5fb  movaps xmm14, xmm1
00007cfd13bcf5ff  mulsd xmm14, xmm15
00007cfd13bcf604  ucomisd xmm14, xmm14
00007cfd13bcf609  jp 0x00007CFD13BCFACD
00007cfd13bcf60f  movq xmm14, xmm14
00007cfd13bcf614  lea rax, [r12+0x140]
00007cfd13bcf61c  mov r11, [r13+rax*1]
00007cfd13bcf621  movq xmm1, r11
00007cfd13bcf626  movq rax, xmm13
00007cfd13bcf62b  movq r11, xmm14
00007cfd13bcf630  vmovq xmm15, rax
00007cfd13bcf635  vmovq xmm14, r11
00007cfd13bcf63a  movaps xmm13, xmm15
00007cfd13bcf63e  addsd xmm13, xmm14
00007cfd13bcf643  ucomisd xmm13, xmm13
00007cfd13bcf648  jp 0x00007CFD13BCFB1F
00007cfd13bcf64e  movq xmm13, xmm13
00007cfd13bcf653  movaps xmm15, [r15+0x170]
00007cfd13bcf65b  movq rax, xmm15
00007cfd13bcf660  movq r11, xmm1
00007cfd13bcf665  vmovq xmm1, rax
00007cfd13bcf66a  vmovq xmm15, r11
00007cfd13bcf66f  movaps xmm14, xmm1
00007cfd13bcf673  mulsd xmm14, xmm15
00007cfd13bcf678  ucomisd xmm14, xmm14
00007cfd13bcf67d  jp 0x00007CFD13BCFB67
00007cfd13bcf683  movq xmm14, xmm14
00007cfd13bcf688  lea rax, [r12+0x180]
00007cfd13bcf690  mov r11, [r13+rax*1]
00007cfd13bcf695  movq xmm1, r11
00007cfd13bcf69a  movq rax, xmm13
00007cfd13bcf69f  movq r11, xmm14
00007cfd13bcf6a4  vmovq xmm15, rax
00007cfd13bcf6a9  vmovq xmm14, r11
00007cfd13bcf6ae  movaps xmm13, xmm15
00007cfd13bcf6b2  addsd xmm13, xmm14
00007cfd13bcf6b7  ucomisd xmm13, xmm13
00007cfd13bcf6bc  jp 0x00007CFD13BCFBB9
00007cfd13bcf6c2  movq xmm13, xmm13
00007cfd13bcf6c7  movaps xmm15, [r15+0x180]
00007cfd13bcf6cf  movq rax, xmm15
00007cfd13bcf6d4  movq r11, xmm1
00007cfd13bcf6d9  vmovq xmm1, rax
00007cfd13bcf6de  vmovq xmm15, r11
00007cfd13bcf6e3  movaps xmm14, xmm1
00007cfd13bcf6e7  mulsd xmm14, xmm15
00007cfd13bcf6ec  ucomisd xmm14, xmm14
00007cfd13bcf6f1  jp 0x00007CFD13BCFC01
00007cfd13bcf6f7  movq xmm14, xmm14
00007cfd13bcf6fc  lea rax, [r12+0x1C0]
00007cfd13bcf704  mov r12, [r13+rax*1]
00007cfd13bcf709  movq xmm1, r12
00007cfd13bcf70e  movaps [r15+0x240], xmm1
00007cfd13bcf716  movq rax, xmm13
00007cfd13bcf71b  movq r12, xmm14
00007cfd13bcf720  vmovq xmm15, rax
00007cfd13bcf725  vmovq xmm14, r12
00007cfd13bcf72a  movaps xmm13, xmm15
00007cfd13bcf72e  addsd xmm13, xmm14
00007cfd13bcf733  ucomisd xmm13, xmm13
00007cfd13bcf738  jp 0x00007CFD13BCFC53
00007cfd13bcf73e  movq xmm13, xmm13
00007cfd13bcf743  movaps xmm15, [r15+0x210]
00007cfd13bcf74b  movq rax, xmm15
00007cfd13bcf750  movq r12, xmm1
00007cfd13bcf755  vmovq xmm1, rax
00007cfd13bcf75a  vmovq xmm15, r12
00007cfd13bcf75f  movaps xmm14, xmm1
00007cfd13bcf763  mulsd xmm14, xmm15
00007cfd13bcf768  ucomisd xmm14, xmm14
00007cfd13bcf76d  jp 0x00007CFD13BCFC9B
00007cfd13bcf773  movq xmm14, xmm14
00007cfd13bcf778  movaps [r15+0x230], xmm14
00007cfd13bcf780  movq rax, xmm13
00007cfd13bcf785  movq r12, xmm14
00007cfd13bcf78a  vmovq xmm1, rax
00007cfd13bcf78f  vmovq xmm15, r12
00007cfd13bcf794  movaps xmm14, xmm1
00007cfd13bcf798  addsd xmm14, xmm15
00007cfd13bcf79d  ucomisd xmm14, xmm14
00007cfd13bcf7a2  jp 0x00007CFD13BCFCE3
00007cfd13bcf7a8  movq xmm14, xmm14
00007cfd13bcf7ad  movaps [r15+0x220], xmm14
00007cfd13bcf7b5  mov rax, [r15+0x68]
00007cfd13bcf7b9  lea r12, [rax+r14*1]
00007cfd13bcf7bd  movq rax, xmm14
00007cfd13bcf7c2  mov [r13+r12*1], rax
00007cfd13bcf7c7  lea rax, [r14+0x08]
00007cfd13bcf7cb  mov [r15+0x70], rax
00007cfd13bcf7cf  mov [rsp+0x10], rax
00007cfd13bcf7d4  xor eax, eax
00007cfd13bcf7d6  mov r14, [rsp+0x10]
00007cfd13bcf7db  mov r12d, 0x40
00007cfd13bcf7e1  cmp r14, r12
00007cfd13bcf7e4  cmc
00007cfd13bcf7e5  lahf
00007cfd13bcf7e6  seto al
00007cfd13bcf7e9  mov [r15+0x108], eax
00007cfd13bcf7f0  mov eax, [r15+0x108]
00007cfd13bcf7f7  sahf
00007cfd13bcf7f8  jnz 0x00007CFD13BCF82A
00007cfd13bcf7fa  cmp dword ptr [r15+0x318], 0x00
00007cfd13bcf802  jz 0x00007CFD13BCFD40
00007cfd13bcf808  nop [rax+rax*1], ax
00007cfd13bcf811  nop [rax+rax*1], eax
00007cfd13bcf819  mov eax, 0x410118
00007cfd13bcf81e  mov [r15+0x100], rax
00007cfd13bcf825  jmp 0x00007CFD139FE110
00007cfd13bcf82a  cmp dword ptr [r15+0x318], 0x00
00007cfd13bcf832  jz 0x00007CFD13BCF3F0
00007cfd13bcf838  nop [rax+rax*1], ax
00007cfd13bcf841  nop [rax+rax*1], eax
00007cfd13bcf849  mov eax, 0x4100A4
00007cfd13bcf84e  mov [r15+0x100], rax
00007cfd13bcf855  jmp 0x00007CFD139FE110
00007cfd13bcf85a  int3
00007cfd13bcf85b  call 0x00007CFD13AB47C0
00007cfd13bcf860  jmp 0x00007CFD13BCF405
00007cfd13bcf865  call 0x00007CFD13A0A4B0
00007cfd13bcf86a  jmp 0x00007CFD13BCF414
00007cfd13bcf86f  call 0x00007CFD13A0A4B0
00007cfd13bcf874  jmp 0x00007CFD13BCF426
00007cfd13bcf879  ucomisd xmm1, xmm13
00007cfd13bcf87e  jp 0x00007CFD13BCF88D
00007cfd13bcf880  movaps xmm12, [0x00007CFD137FE030]
00007cfd13bcf888  jmp 0x00007CFD13BCF45B
00007cfd13bcf88d  vxorps xmm0, xmm1, xmm13
00007cfd13bcf892  pextrw eax, xmm0, 0x03
00007cfd13bcf897  and eax, 0x7FF8
00007cfd13bcf89c  cmp eax, 0x08
00007cfd13bcf89f  jnz 0x00007CFD13BCF45B
00007cfd13bcf8a5  movq rax, xmm13
00007cfd13bcf8aa  shl rax, 0x0D
00007cfd13bcf8ae  jbe 0x00007CFD13BCF45B
00007cfd13bcf8b4  vorps xmm12, xmm13, [0x00007CFD137FE040]
00007cfd13bcf8bc  jmp 0x00007CFD13BCF45B
00007cfd13bcf8c1  ucomisd xmm1, xmm15
00007cfd13bcf8c6  jp 0x00007CFD13BCF8D5
00007cfd13bcf8c8  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf8d0  jmp 0x00007CFD13BCF490
00007cfd13bcf8d5  vxorps xmm0, xmm1, xmm15
00007cfd13bcf8da  pextrw eax, xmm0, 0x03
00007cfd13bcf8df  and eax, 0x7FF8
00007cfd13bcf8e4  cmp eax, 0x08
00007cfd13bcf8e7  jnz 0x00007CFD13BCF490
00007cfd13bcf8ed  movq rax, xmm15
00007cfd13bcf8f2  shl rax, 0x0D
00007cfd13bcf8f6  jbe 0x00007CFD13BCF490
00007cfd13bcf8fc  vorps xmm13, xmm15, [0x00007CFD137FE040]
00007cfd13bcf904  jmp 0x00007CFD13BCF490
00007cfd13bcf909  ucomisd xmm1, xmm15
00007cfd13bcf90e  jp 0x00007CFD13BCF91D
00007cfd13bcf910  movaps xmm12, [0x00007CFD137FE030]
00007cfd13bcf918  jmp 0x00007CFD13BCF4C5
00007cfd13bcf91d  vxorps xmm0, xmm1, xmm15
00007cfd13bcf922  pextrw eax, xmm0, 0x03
00007cfd13bcf927  and eax, 0x7FF8
00007cfd13bcf92c  cmp eax, 0x08
00007cfd13bcf92f  jnz 0x00007CFD13BCF4C5
00007cfd13bcf935  movq rax, xmm15
00007cfd13bcf93a  shl rax, 0x0D
00007cfd13bcf93e  jbe 0x00007CFD13BCF4C5
00007cfd13bcf944  vorps xmm12, xmm15, [0x00007CFD137FE040]
00007cfd13bcf94c  jmp 0x00007CFD13BCF4C5
00007cfd13bcf951  ucomisd xmm1, xmm15
00007cfd13bcf956  jp 0x00007CFD13BCF965
00007cfd13bcf958  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf960  jmp 0x00007CFD13BCF4F2
00007cfd13bcf965  vxorps xmm0, xmm1, xmm15
00007cfd13bcf96a  pextrw eax, xmm0, 0x03
00007cfd13bcf96f  and eax, 0x7FF8
00007cfd13bcf974  cmp eax, 0x08
00007cfd13bcf977  jnz 0x00007CFD13BCF4F2
00007cfd13bcf97d  movq rax, xmm15
00007cfd13bcf982  shl rax, 0x0D
00007cfd13bcf986  jbe 0x00007CFD13BCF4F2
00007cfd13bcf98c  vorps xmm13, xmm15, [0x00007CFD137FE040]
00007cfd13bcf994  jmp 0x00007CFD13BCF4F2
00007cfd13bcf999  ucomisd xmm1, xmm15
00007cfd13bcf99e  jp 0x00007CFD13BCF9AD
00007cfd13bcf9a0  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcf9a8  jmp 0x00007CFD13BCF527
00007cfd13bcf9ad  vxorps xmm0, xmm1, xmm15
00007cfd13bcf9b2  pextrw eax, xmm0, 0x03
00007cfd13bcf9b7  and eax, 0x7FF8
00007cfd13bcf9bc  cmp eax, 0x08
00007cfd13bcf9bf  jnz 0x00007CFD13BCF527
00007cfd13bcf9c5  movq rax, xmm15
00007cfd13bcf9ca  shl rax, 0x0D
00007cfd13bcf9ce  jbe 0x00007CFD13BCF527
00007cfd13bcf9d4  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcf9dc  jmp 0x00007CFD13BCF527
00007cfd13bcf9e1  call 0x00007CFD13A0A4B0
00007cfd13bcf9e6  jmp 0x00007CFD13BCF539
00007cfd13bcf9eb  ucomisd xmm15, xmm14
00007cfd13bcf9f0  jp 0x00007CFD13BCF9FF
00007cfd13bcf9f2  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcf9fa  jmp 0x00007CFD13BCF566
00007cfd13bcf9ff  vxorps xmm0, xmm15, xmm14
00007cfd13bcfa04  pextrw eax, xmm0, 0x03
00007cfd13bcfa09  and eax, 0x7FF8
00007cfd13bcfa0e  cmp eax, 0x08
00007cfd13bcfa11  jnz 0x00007CFD13BCF566
00007cfd13bcfa17  movq rax, xmm14
00007cfd13bcfa1c  shl rax, 0x0D
00007cfd13bcfa20  jbe 0x00007CFD13BCF566
00007cfd13bcfa26  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcfa2e  jmp 0x00007CFD13BCF566
00007cfd13bcfa33  ucomisd xmm1, xmm15
00007cfd13bcfa38  jp 0x00007CFD13BCFA47
00007cfd13bcfa3a  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcfa42  jmp 0x00007CFD13BCF59B
00007cfd13bcfa47  vxorps xmm0, xmm1, xmm15
00007cfd13bcfa4c  pextrw eax, xmm0, 0x03
00007cfd13bcfa51  and eax, 0x7FF8
00007cfd13bcfa56  cmp eax, 0x08
00007cfd13bcfa59  jnz 0x00007CFD13BCF59B
00007cfd13bcfa5f  movq rax, xmm15
00007cfd13bcfa64  shl rax, 0x0D
00007cfd13bcfa68  jbe 0x00007CFD13BCF59B
00007cfd13bcfa6e  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcfa76  jmp 0x00007CFD13BCF59B
00007cfd13bcfa7b  call 0x00007CFD13A0A4B0
00007cfd13bcfa80  jmp 0x00007CFD13BCF5AD
00007cfd13bcfa85  ucomisd xmm15, xmm14
00007cfd13bcfa8a  jp 0x00007CFD13BCFA99
00007cfd13bcfa8c  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcfa94  jmp 0x00007CFD13BCF5DA
00007cfd13bcfa99  vxorps xmm0, xmm15, xmm14
00007cfd13bcfa9e  pextrw eax, xmm0, 0x03
00007cfd13bcfaa3  and eax, 0x7FF8
00007cfd13bcfaa8  cmp eax, 0x08
00007cfd13bcfaab  jnz 0x00007CFD13BCF5DA
00007cfd13bcfab1  movq rax, xmm14
00007cfd13bcfab6  shl rax, 0x0D
00007cfd13bcfaba  jbe 0x00007CFD13BCF5DA
00007cfd13bcfac0  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcfac8  jmp 0x00007CFD13BCF5DA
00007cfd13bcfacd  ucomisd xmm1, xmm15
00007cfd13bcfad2  jp 0x00007CFD13BCFAE1
00007cfd13bcfad4  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcfadc  jmp 0x00007CFD13BCF60F
00007cfd13bcfae1  vxorps xmm0, xmm1, xmm15
00007cfd13bcfae6  pextrw eax, xmm0, 0x03
00007cfd13bcfaeb  and eax, 0x7FF8
00007cfd13bcfaf0  cmp eax, 0x08
00007cfd13bcfaf3  jnz 0x00007CFD13BCF60F
00007cfd13bcfaf9  movq rax, xmm15
00007cfd13bcfafe  shl rax, 0x0D
00007cfd13bcfb02  jbe 0x00007CFD13BCF60F
00007cfd13bcfb08  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcfb10  jmp 0x00007CFD13BCF60F
00007cfd13bcfb15  call 0x00007CFD13A0A4B0
00007cfd13bcfb1a  jmp 0x00007CFD13BCF621
00007cfd13bcfb1f  ucomisd xmm15, xmm14
00007cfd13bcfb24  jp 0x00007CFD13BCFB33
00007cfd13bcfb26  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcfb2e  jmp 0x00007CFD13BCF64E
00007cfd13bcfb33  vxorps xmm0, xmm15, xmm14
00007cfd13bcfb38  pextrw eax, xmm0, 0x03
00007cfd13bcfb3d  and eax, 0x7FF8
00007cfd13bcfb42  cmp eax, 0x08
00007cfd13bcfb45  jnz 0x00007CFD13BCF64E
00007cfd13bcfb4b  movq rax, xmm14
00007cfd13bcfb50  shl rax, 0x0D
00007cfd13bcfb54  jbe 0x00007CFD13BCF64E
00007cfd13bcfb5a  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcfb62  jmp 0x00007CFD13BCF64E
00007cfd13bcfb67  ucomisd xmm1, xmm15
00007cfd13bcfb6c  jp 0x00007CFD13BCFB7B
00007cfd13bcfb6e  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcfb76  jmp 0x00007CFD13BCF683
00007cfd13bcfb7b  vxorps xmm0, xmm1, xmm15
00007cfd13bcfb80  pextrw eax, xmm0, 0x03
00007cfd13bcfb85  and eax, 0x7FF8
00007cfd13bcfb8a  cmp eax, 0x08
00007cfd13bcfb8d  jnz 0x00007CFD13BCF683
00007cfd13bcfb93  movq rax, xmm15
00007cfd13bcfb98  shl rax, 0x0D
00007cfd13bcfb9c  jbe 0x00007CFD13BCF683
00007cfd13bcfba2  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcfbaa  jmp 0x00007CFD13BCF683
00007cfd13bcfbaf  call 0x00007CFD13A0A4B0
00007cfd13bcfbb4  jmp 0x00007CFD13BCF695
00007cfd13bcfbb9  ucomisd xmm15, xmm14
00007cfd13bcfbbe  jp 0x00007CFD13BCFBCD
00007cfd13bcfbc0  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcfbc8  jmp 0x00007CFD13BCF6C2
00007cfd13bcfbcd  vxorps xmm0, xmm15, xmm14
00007cfd13bcfbd2  pextrw eax, xmm0, 0x03
00007cfd13bcfbd7  and eax, 0x7FF8
00007cfd13bcfbdc  cmp eax, 0x08
00007cfd13bcfbdf  jnz 0x00007CFD13BCF6C2
00007cfd13bcfbe5  movq rax, xmm14
00007cfd13bcfbea  shl rax, 0x0D
00007cfd13bcfbee  jbe 0x00007CFD13BCF6C2
00007cfd13bcfbf4  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcfbfc  jmp 0x00007CFD13BCF6C2
00007cfd13bcfc01  ucomisd xmm1, xmm15
00007cfd13bcfc06  jp 0x00007CFD13BCFC15
00007cfd13bcfc08  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcfc10  jmp 0x00007CFD13BCF6F7
00007cfd13bcfc15  vxorps xmm0, xmm1, xmm15
00007cfd13bcfc1a  pextrw eax, xmm0, 0x03
00007cfd13bcfc1f  and eax, 0x7FF8
00007cfd13bcfc24  cmp eax, 0x08
00007cfd13bcfc27  jnz 0x00007CFD13BCF6F7
00007cfd13bcfc2d  movq rax, xmm15
00007cfd13bcfc32  shl rax, 0x0D
00007cfd13bcfc36  jbe 0x00007CFD13BCF6F7
00007cfd13bcfc3c  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcfc44  jmp 0x00007CFD13BCF6F7
00007cfd13bcfc49  call 0x00007CFD13A0B720
00007cfd13bcfc4e  jmp 0x00007CFD13BCF709
00007cfd13bcfc53  ucomisd xmm15, xmm14
00007cfd13bcfc58  jp 0x00007CFD13BCFC67
00007cfd13bcfc5a  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bcfc62  jmp 0x00007CFD13BCF73E
00007cfd13bcfc67  vxorps xmm0, xmm15, xmm14
00007cfd13bcfc6c  pextrw eax, xmm0, 0x03
00007cfd13bcfc71  and eax, 0x7FF8
00007cfd13bcfc76  cmp eax, 0x08
00007cfd13bcfc79  jnz 0x00007CFD13BCF73E
00007cfd13bcfc7f  movq rax, xmm14
00007cfd13bcfc84  shl rax, 0x0D
00007cfd13bcfc88  jbe 0x00007CFD13BCF73E
00007cfd13bcfc8e  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bcfc96  jmp 0x00007CFD13BCF73E
00007cfd13bcfc9b  ucomisd xmm1, xmm15
00007cfd13bcfca0  jp 0x00007CFD13BCFCAF
00007cfd13bcfca2  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcfcaa  jmp 0x00007CFD13BCF773
00007cfd13bcfcaf  vxorps xmm0, xmm1, xmm15
00007cfd13bcfcb4  pextrw eax, xmm0, 0x03
00007cfd13bcfcb9  and eax, 0x7FF8
00007cfd13bcfcbe  cmp eax, 0x08
00007cfd13bcfcc1  jnz 0x00007CFD13BCF773
00007cfd13bcfcc7  movq rax, xmm15
00007cfd13bcfccc  shl rax, 0x0D
00007cfd13bcfcd0  jbe 0x00007CFD13BCF773
00007cfd13bcfcd6  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcfcde  jmp 0x00007CFD13BCF773
00007cfd13bcfce3  ucomisd xmm1, xmm15
00007cfd13bcfce8  jp 0x00007CFD13BCFCF7
00007cfd13bcfcea  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bcfcf2  jmp 0x00007CFD13BCF7A8
00007cfd13bcfcf7  vxorps xmm0, xmm1, xmm15
00007cfd13bcfcfc  pextrw eax, xmm0, 0x03
00007cfd13bcfd01  and eax, 0x7FF8
00007cfd13bcfd06  cmp eax, 0x08
00007cfd13bcfd09  jnz 0x00007CFD13BCF7A8
00007cfd13bcfd0f  movq rax, xmm15
00007cfd13bcfd14  shl rax, 0x0D
00007cfd13bcfd18  jbe 0x00007CFD13BCF7A8
00007cfd13bcfd1e  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bcfd26  jmp 0x00007CFD13BCF7A8
00007cfd13bcfd2b  call 0x00007CFD13AB4CB0
00007cfd13bcfd30  jmp 0x00007CFD13BCF7C7
00007cfd13bcfd35  int3
00007cfd13bcfd36  nop [rax+rax*1], ax
00007cfd13bcfd3f  nop
00007cfd13bcfd40  mov rax, [r15+0x60]
00007cfd13bcfd44  lea r14, [rax+0x01]
00007cfd13bcfd48  mov [r15+0x60], r14
00007cfd13bcfd4c  mov rax, [r15+0x68]
00007cfd13bcfd50  lea r12, [rax+0x40]
00007cfd13bcfd54  mov [r15+0x68], r12
00007cfd13bcfd58  xor eax, eax
00007cfd13bcfd5a  mov r12d, 0x08
00007cfd13bcfd60  cmp r14, r12
00007cfd13bcfd63  cmc
00007cfd13bcfd64  lahf
00007cfd13bcfd65  seto al
00007cfd13bcfd68  mov [r15+0x108], eax
00007cfd13bcfd6f  mov eax, [r15+0x108]
00007cfd13bcfd76  sahf
00007cfd13bcfd77  jnz 0x00007CFD13BCFDA9
00007cfd13bcfd79  cmp dword ptr [r15+0x318], 0x00
00007cfd13bcfd81  jz 0x00007CFD13BD08A0
00007cfd13bcfd87  nop [rax+rax*1], ax
00007cfd13bcfd90  nop [rax+rax*1], eax
00007cfd13bcfd98  mov eax, 0x410128
00007cfd13bcfd9d  mov [r15+0x100], rax
00007cfd13bcfda4  jmp 0x00007CFD139FE110
00007cfd13bcfda9  cmp dword ptr [r15+0x318], 0x00
00007cfd13bcfdb1  jz 0x00007CFD13BCFDE0
00007cfd13bcfdb7  nop [rax+rax*1], ax
00007cfd13bcfdc0  nop [rax+rax*1], eax
00007cfd13bcfdc8  mov eax, 0x41008C
00007cfd13bcfdcd  mov [r15+0x100], rax
00007cfd13bcfdd4  jmp 0x00007CFD139FE110
00007cfd13bcfdd9  int3
00007cfd13bcfdda  int3
00007cfd13bcfddb  nop [rax+rax*1], eax
00007cfd13bcfde0  mov rax, [r15+0x40]
00007cfd13bcfde4  mov r14, [r15+0x60]
00007cfd13bcfde8  shl r14, 0x06
00007cfd13bcfdec  lea r12, [rax+r14*1]
00007cfd13bcfdf0  mov rax, [r13+r12*1]
00007cfd13bcfdf5  lea r14, [r12+0x08]
00007cfd13bcfdfa  mov r11, [r13+r14*1]
00007cfd13bcfdff  movq xmm1, rax
00007cfd13bcfe04  movq xmm15, r11
00007cfd13bcfe09  movq xmm1, xmm1
00007cfd13bcfe0d  movq xmm1, xmm1
00007cfd13bcfe11  movaps [r15+0x120], xmm1
00007cfd13bcfe19  movq xmm15, xmm15
00007cfd13bcfe1e  movq xmm15, xmm15
00007cfd13bcfe23  movaps [r15+0x130], xmm15
00007cfd13bcfe2b  lea rax, [r12+0x10]
00007cfd13bcfe30  mov r14, [r13+rax*1]
00007cfd13bcfe35  lea rax, [r12+0x18]
00007cfd13bcfe3a  mov r11, [r13+rax*1]
00007cfd13bcfe3f  movq xmm1, r14
00007cfd13bcfe44  movq xmm15, r11
00007cfd13bcfe49  movq xmm1, xmm1
00007cfd13bcfe4d  movq xmm1, xmm1
00007cfd13bcfe51  movaps [r15+0x140], xmm1
00007cfd13bcfe59  movq xmm15, xmm15
00007cfd13bcfe5e  movq xmm15, xmm15
00007cfd13bcfe63  movaps [r15+0x150], xmm15
00007cfd13bcfe6b  lea rax, [r12+0x20]
00007cfd13bcfe70  mov r14, [r13+rax*1]
00007cfd13bcfe75  lea rax, [r12+0x28]
00007cfd13bcfe7a  mov r11, [r13+rax*1]
00007cfd13bcfe7f  movq xmm1, r14
00007cfd13bcfe84  movq xmm15, r11
00007cfd13bcfe89  movq xmm1, xmm1
00007cfd13bcfe8d  movq xmm1, xmm1
00007cfd13bcfe91  movaps [r15+0x160], xmm1
00007cfd13bcfe99  movq xmm15, xmm15
00007cfd13bcfe9e  movq xmm15, xmm15
00007cfd13bcfea3  movaps [r15+0x170], xmm15
00007cfd13bcfeab  lea rax, [r12+0x30]
00007cfd13bcfeb0  mov r14, [r13+rax*1]
00007cfd13bcfeb5  lea rax, [r12+0x38]
00007cfd13bcfeba  mov r12, [r13+rax*1]
00007cfd13bcfebf  movq xmm1, r14
00007cfd13bcfec4  movq xmm15, r12
00007cfd13bcfec9  movq xmm1, xmm1
00007cfd13bcfecd  movq xmm1, xmm1
00007cfd13bcfed1  movaps [r15+0x180], xmm1
00007cfd13bcfed9  movq xmm15, xmm15
00007cfd13bcfede  movq xmm15, xmm15
00007cfd13bcfee3  movaps [r15+0x210], xmm15
00007cfd13bcfeeb  mov rax, [r15+0x48]
00007cfd13bcfeef  mov [r15+0x78], rax
00007cfd13bcfef3  mov r14, [r13+rax*1]
00007cfd13bcfef8  movq xmm1, r14
00007cfd13bcfefd  lea r14, [rax+0x40]
00007cfd13bcff01  mov r12, [r13+r14*1]
00007cfd13bcff06  movq xmm15, r12
00007cfd13bcff0b  lea r14, [rax+0x80]
00007cfd13bcff12  mov r12, [r13+r14*1]
00007cfd13bcff17  movq xmm14, r12
00007cfd13bcff1c  movaps xmm13, [r15+0x120]
00007cfd13bcff24  movq r14, xmm13
00007cfd13bcff29  movq r12, xmm1
00007cfd13bcff2e  vmovq xmm1, r14
00007cfd13bcff33  vmovq xmm13, r12
00007cfd13bcff38  movaps xmm12, xmm1
00007cfd13bcff3c  mulsd xmm12, xmm13
00007cfd13bcff41  ucomisd xmm12, xmm12
00007cfd13bcff46  jp 0x00007CFD13BD03AD
00007cfd13bcff4c  movq xmm12, xmm12
00007cfd13bcff51  movaps xmm1, [r15+0x130]
00007cfd13bcff59  movq r14, xmm1
00007cfd13bcff5e  movq r12, xmm15
00007cfd13bcff63  vmovq xmm1, r14
00007cfd13bcff68  vmovq xmm15, r12
00007cfd13bcff6d  movaps xmm13, xmm1
00007cfd13bcff71  mulsd xmm13, xmm15
00007cfd13bcff76  ucomisd xmm13, xmm13
00007cfd13bcff7b  jp 0x00007CFD13BD03F9
00007cfd13bcff81  movq xmm13, xmm13
00007cfd13bcff86  movq r14, xmm12
00007cfd13bcff8b  movaps xmm1, [r15+0x110]
00007cfd13bcff93  movq r12, xmm1
00007cfd13bcff98  vmovq xmm1, r14
00007cfd13bcff9d  vmovq xmm15, r12
00007cfd13bcffa2  movaps xmm12, xmm1
00007cfd13bcffa6  addsd xmm12, xmm15
00007cfd13bcffab  ucomisd xmm12, xmm12
00007cfd13bcffb0  jp 0x00007CFD13BD0445
00007cfd13bcffb6  movq xmm12, xmm12
00007cfd13bcffbb  movq r14, xmm12
00007cfd13bcffc0  movq r12, xmm13
00007cfd13bcffc5  vmovq xmm1, r14
00007cfd13bcffca  vmovq xmm15, r12
00007cfd13bcffcf  movaps xmm13, xmm1
00007cfd13bcffd3  addsd xmm13, xmm15
00007cfd13bcffd8  ucomisd xmm13, xmm13
00007cfd13bcffdd  jp 0x00007CFD13BD0491
00007cfd13bcffe3  movq xmm13, xmm13
00007cfd13bcffe8  movaps xmm1, [r15+0x140]
00007cfd13bcfff0  movq r14, xmm1
00007cfd13bcfff5  movq r12, xmm14
00007cfd13bcfffa  vmovq xmm1, r14
00007cfd13bcffff  vmovq xmm15, r12
00007cfd13bd0004  movaps xmm14, xmm1
00007cfd13bd0008  mulsd xmm14, xmm15
00007cfd13bd000d  ucomisd xmm14, xmm14
00007cfd13bd0012  jp 0x00007CFD13BD04DD
00007cfd13bd0018  movq xmm14, xmm14
00007cfd13bd001d  lea r14, [rax+0xC0]
00007cfd13bd0024  mov r12, [r13+r14*1]
00007cfd13bd0029  movq xmm1, r12
00007cfd13bd002e  movq r14, xmm13
00007cfd13bd0033  movq r12, xmm14
00007cfd13bd0038  vmovq xmm15, r14
00007cfd13bd003d  vmovq xmm14, r12
00007cfd13bd0042  movaps xmm13, xmm15
00007cfd13bd0046  addsd xmm13, xmm14
00007cfd13bd004b  ucomisd xmm13, xmm13
00007cfd13bd0050  jp 0x00007CFD13BD0533
00007cfd13bd0056  movq xmm13, xmm13
00007cfd13bd005b  movaps xmm15, [r15+0x150]
00007cfd13bd0063  movq r14, xmm15
00007cfd13bd0068  movq r12, xmm1
00007cfd13bd006d  vmovq xmm1, r14
00007cfd13bd0072  vmovq xmm15, r12
00007cfd13bd0077  movaps xmm14, xmm1
00007cfd13bd007b  mulsd xmm14, xmm15
00007cfd13bd0080  ucomisd xmm14, xmm14
00007cfd13bd0085  jp 0x00007CFD13BD057F
00007cfd13bd008b  movq xmm14, xmm14
00007cfd13bd0090  lea r14, [rax+0x100]
00007cfd13bd0097  mov r12, [r13+r14*1]
00007cfd13bd009c  movq xmm1, r12
00007cfd13bd00a1  movq r14, xmm13
00007cfd13bd00a6  movq r12, xmm14
00007cfd13bd00ab  vmovq xmm15, r14
00007cfd13bd00b0  vmovq xmm14, r12
00007cfd13bd00b5  movaps xmm13, xmm15
00007cfd13bd00b9  addsd xmm13, xmm14
00007cfd13bd00be  ucomisd xmm13, xmm13
00007cfd13bd00c3  jp 0x00007CFD13BD05D5
00007cfd13bd00c9  movq xmm13, xmm13
00007cfd13bd00ce  movaps xmm15, [r15+0x160]
00007cfd13bd00d6  movq r14, xmm15
00007cfd13bd00db  movq r12, xmm1
00007cfd13bd00e0  vmovq xmm1, r14
00007cfd13bd00e5  vmovq xmm15, r12
00007cfd13bd00ea  movaps xmm14, xmm1
00007cfd13bd00ee  mulsd xmm14, xmm15
00007cfd13bd00f3  ucomisd xmm14, xmm14
00007cfd13bd00f8  jp 0x00007CFD13BD0621
00007cfd13bd00fe  movq xmm14, xmm14
00007cfd13bd0103  lea r14, [rax+0x140]
00007cfd13bd010a  mov r12, [r13+r14*1]
00007cfd13bd010f  movq xmm1, r12
00007cfd13bd0114  movq r14, xmm13
00007cfd13bd0119  movq r12, xmm14
00007cfd13bd011e  vmovq xmm15, r14
00007cfd13bd0123  vmovq xmm14, r12
00007cfd13bd0128  movaps xmm13, xmm15
00007cfd13bd012c  addsd xmm13, xmm14
00007cfd13bd0131  ucomisd xmm13, xmm13
00007cfd13bd0136  jp 0x00007CFD13BD0677
00007cfd13bd013c  movq xmm13, xmm13
00007cfd13bd0141  movaps xmm15, [r15+0x170]
00007cfd13bd0149  movq r14, xmm15
00007cfd13bd014e  movq r12, xmm1
00007cfd13bd0153  vmovq xmm1, r14
00007cfd13bd0158  vmovq xmm15, r12
00007cfd13bd015d  movaps xmm14, xmm1
00007cfd13bd0161  mulsd xmm14, xmm15
00007cfd13bd0166  ucomisd xmm14, xmm14
00007cfd13bd016b  jp 0x00007CFD13BD06C3
00007cfd13bd0171  movq xmm14, xmm14
00007cfd13bd0176  lea r14, [rax+0x180]
00007cfd13bd017d  mov r12, [r13+r14*1]
00007cfd13bd0182  movq xmm1, r12
00007cfd13bd0187  movq r14, xmm13
00007cfd13bd018c  movq r12, xmm14
00007cfd13bd0191  vmovq xmm15, r14
00007cfd13bd0196  vmovq xmm14, r12
00007cfd13bd019b  movaps xmm13, xmm15
00007cfd13bd019f  addsd xmm13, xmm14
00007cfd13bd01a4  ucomisd xmm13, xmm13
00007cfd13bd01a9  jp 0x00007CFD13BD0719
00007cfd13bd01af  movq xmm13, xmm13
00007cfd13bd01b4  movaps xmm15, [r15+0x180]
00007cfd13bd01bc  movq r14, xmm15
00007cfd13bd01c1  movq r12, xmm1
00007cfd13bd01c6  vmovq xmm1, r14
00007cfd13bd01cb  vmovq xmm15, r12
00007cfd13bd01d0  movaps xmm14, xmm1
00007cfd13bd01d4  mulsd xmm14, xmm15
00007cfd13bd01d9  ucomisd xmm14, xmm14
00007cfd13bd01de  jp 0x00007CFD13BD0765
00007cfd13bd01e4  movq xmm14, xmm14
00007cfd13bd01e9  lea r14, [rax+0x1C0]
00007cfd13bd01f0  mov rax, [r13+r14*1]
00007cfd13bd01f5  movq xmm1, rax
00007cfd13bd01fa  movaps [r15+0x240], xmm1
00007cfd13bd0202  movq rax, xmm13
00007cfd13bd0207  movq r14, xmm14
00007cfd13bd020c  vmovq xmm15, rax
00007cfd13bd0211  vmovq xmm14, r14
00007cfd13bd0216  movaps xmm13, xmm15
00007cfd13bd021a  addsd xmm13, xmm14
00007cfd13bd021f  ucomisd xmm13, xmm13
00007cfd13bd0224  jp 0x00007CFD13BD07BB
00007cfd13bd022a  movq xmm13, xmm13
00007cfd13bd022f  movaps xmm15, [r15+0x210]
00007cfd13bd0237  movq rax, xmm15
00007cfd13bd023c  movq r14, xmm1
00007cfd13bd0241  vmovq xmm1, rax
00007cfd13bd0246  vmovq xmm15, r14
00007cfd13bd024b  movaps xmm14, xmm1
00007cfd13bd024f  mulsd xmm14, xmm15
00007cfd13bd0254  ucomisd xmm14, xmm14
00007cfd13bd0259  jp 0x00007CFD13BD0803
00007cfd13bd025f  movq xmm14, xmm14
00007cfd13bd0264  movaps [r15+0x230], xmm14
00007cfd13bd026c  movq rax, xmm13
00007cfd13bd0271  movq r14, xmm14
00007cfd13bd0276  vmovq xmm1, rax
00007cfd13bd027b  vmovq xmm15, r14
00007cfd13bd0280  movaps xmm14, xmm1
00007cfd13bd0284  addsd xmm14, xmm15
00007cfd13bd0289  ucomisd xmm14, xmm14
00007cfd13bd028e  jp 0x00007CFD13BD084B
00007cfd13bd0294  movq xmm14, xmm14
00007cfd13bd0299  movaps [r15+0x220], xmm14
00007cfd13bd02a1  mov rax, [r15+0x68]
00007cfd13bd02a5  movq r14, xmm14
00007cfd13bd02aa  mov [r13+rax*1], r14
00007cfd13bd02af  mov qword ptr [r15+0x70], 0x08
00007cfd13bd02b7  xor eax, eax
00007cfd13bd02b9  mov r14d, 0x08
00007cfd13bd02bf  mov r12d, 0x40
00007cfd13bd02c5  cmp r14, r12
00007cfd13bd02c8  cmc
00007cfd13bd02c9  lahf
00007cfd13bd02ca  seto al
00007cfd13bd02cd  mov [r15+0x108], eax
00007cfd13bd02d4  mov eax, [r15+0x108]
00007cfd13bd02db  sahf
00007cfd13bd02dc  jnz 0x00007CFD13BD030E
00007cfd13bd02de  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd02e6  jz 0x00007CFD13BCFD40
00007cfd13bd02ec  nop [rax+rax*1], ax
00007cfd13bd02f5  nop [rax+rax*1], eax
00007cfd13bd02fd  mov eax, 0x410118
00007cfd13bd0302  mov [r15+0x100], rax
00007cfd13bd0309  jmp 0x00007CFD139FE110
00007cfd13bd030e  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd0316  jz 0x00007CFD13BCF3F0
00007cfd13bd031c  nop [rax+rax*1], ax
00007cfd13bd0325  nop [rax+rax*1], eax
00007cfd13bd032d  mov eax, 0x4100A4
00007cfd13bd0332  mov [r15+0x100], rax
00007cfd13bd0339  jmp 0x00007CFD139FE110
00007cfd13bd033e  int3
00007cfd13bd033f  call 0x00007CFD13AB47C0
00007cfd13bd0344  jmp 0x00007CFD13BCFDF5
00007cfd13bd0349  call 0x00007CFD13AE1570
00007cfd13bd034e  jmp 0x00007CFD13BCFDFF
00007cfd13bd0353  call 0x00007CFD13A0DC20
00007cfd13bd0358  jmp 0x00007CFD13BCFE35
00007cfd13bd035d  call 0x00007CFD13A0A4B0
00007cfd13bd0362  jmp 0x00007CFD13BCFE3F
00007cfd13bd0367  call 0x00007CFD13A0DC20
00007cfd13bd036c  jmp 0x00007CFD13BCFE75
00007cfd13bd0371  call 0x00007CFD13A0A4B0
00007cfd13bd0376  jmp 0x00007CFD13BCFE7F
00007cfd13bd037b  call 0x00007CFD13A0DC20
00007cfd13bd0380  jmp 0x00007CFD13BCFEB5
00007cfd13bd0385  call 0x00007CFD13A0B720
00007cfd13bd038a  jmp 0x00007CFD13BCFEBF
00007cfd13bd038f  call 0x00007CFD13A0DC20
00007cfd13bd0394  jmp 0x00007CFD13BCFEF8
00007cfd13bd0399  call 0x00007CFD13AE27E0
00007cfd13bd039e  jmp 0x00007CFD13BCFF06
00007cfd13bd03a3  call 0x00007CFD13AE27E0
00007cfd13bd03a8  jmp 0x00007CFD13BCFF17
00007cfd13bd03ad  ucomisd xmm1, xmm13
00007cfd13bd03b2  jp 0x00007CFD13BD03C1
00007cfd13bd03b4  movaps xmm12, [0x00007CFD137FE030]
00007cfd13bd03bc  jmp 0x00007CFD13BCFF4C
00007cfd13bd03c1  vxorps xmm0, xmm1, xmm13
00007cfd13bd03c6  pextrw r14d, xmm0, 0x03
00007cfd13bd03cc  and r14d, 0x7FF8
00007cfd13bd03d3  cmp r14d, 0x08
00007cfd13bd03d7  jnz 0x00007CFD13BCFF4C
00007cfd13bd03dd  movq r14, xmm13
00007cfd13bd03e2  shl r14, 0x0D
00007cfd13bd03e6  jbe 0x00007CFD13BCFF4C
00007cfd13bd03ec  vorps xmm12, xmm13, [0x00007CFD137FE040]
00007cfd13bd03f4  jmp 0x00007CFD13BCFF4C
00007cfd13bd03f9  ucomisd xmm1, xmm15
00007cfd13bd03fe  jp 0x00007CFD13BD040D
00007cfd13bd0400  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd0408  jmp 0x00007CFD13BCFF81
00007cfd13bd040d  vxorps xmm0, xmm1, xmm15
00007cfd13bd0412  pextrw r14d, xmm0, 0x03
00007cfd13bd0418  and r14d, 0x7FF8
00007cfd13bd041f  cmp r14d, 0x08
00007cfd13bd0423  jnz 0x00007CFD13BCFF81
00007cfd13bd0429  movq r14, xmm15
00007cfd13bd042e  shl r14, 0x0D
00007cfd13bd0432  jbe 0x00007CFD13BCFF81
00007cfd13bd0438  vorps xmm13, xmm15, [0x00007CFD137FE040]
00007cfd13bd0440  jmp 0x00007CFD13BCFF81
00007cfd13bd0445  ucomisd xmm1, xmm15
00007cfd13bd044a  jp 0x00007CFD13BD0459
00007cfd13bd044c  movaps xmm12, [0x00007CFD137FE030]
00007cfd13bd0454  jmp 0x00007CFD13BCFFB6
00007cfd13bd0459  vxorps xmm0, xmm1, xmm15
00007cfd13bd045e  pextrw r14d, xmm0, 0x03
00007cfd13bd0464  and r14d, 0x7FF8
00007cfd13bd046b  cmp r14d, 0x08
00007cfd13bd046f  jnz 0x00007CFD13BCFFB6
00007cfd13bd0475  movq r14, xmm15
00007cfd13bd047a  shl r14, 0x0D
00007cfd13bd047e  jbe 0x00007CFD13BCFFB6
00007cfd13bd0484  vorps xmm12, xmm15, [0x00007CFD137FE040]
00007cfd13bd048c  jmp 0x00007CFD13BCFFB6
00007cfd13bd0491  ucomisd xmm1, xmm15
00007cfd13bd0496  jp 0x00007CFD13BD04A5
00007cfd13bd0498  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd04a0  jmp 0x00007CFD13BCFFE3
00007cfd13bd04a5  vxorps xmm0, xmm1, xmm15
00007cfd13bd04aa  pextrw r14d, xmm0, 0x03
00007cfd13bd04b0  and r14d, 0x7FF8
00007cfd13bd04b7  cmp r14d, 0x08
00007cfd13bd04bb  jnz 0x00007CFD13BCFFE3
00007cfd13bd04c1  movq r14, xmm15
00007cfd13bd04c6  shl r14, 0x0D
00007cfd13bd04ca  jbe 0x00007CFD13BCFFE3
00007cfd13bd04d0  vorps xmm13, xmm15, [0x00007CFD137FE040]
00007cfd13bd04d8  jmp 0x00007CFD13BCFFE3
00007cfd13bd04dd  ucomisd xmm1, xmm15
00007cfd13bd04e2  jp 0x00007CFD13BD04F1
00007cfd13bd04e4  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd04ec  jmp 0x00007CFD13BD0018
00007cfd13bd04f1  vxorps xmm0, xmm1, xmm15
00007cfd13bd04f6  pextrw r14d, xmm0, 0x03
00007cfd13bd04fc  and r14d, 0x7FF8
00007cfd13bd0503  cmp r14d, 0x08
00007cfd13bd0507  jnz 0x00007CFD13BD0018
00007cfd13bd050d  movq r14, xmm15
00007cfd13bd0512  shl r14, 0x0D
00007cfd13bd0516  jbe 0x00007CFD13BD0018
00007cfd13bd051c  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd0524  jmp 0x00007CFD13BD0018
00007cfd13bd0529  call 0x00007CFD13AE27E0
00007cfd13bd052e  jmp 0x00007CFD13BD0029
00007cfd13bd0533  ucomisd xmm15, xmm14
00007cfd13bd0538  jp 0x00007CFD13BD0547
00007cfd13bd053a  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd0542  jmp 0x00007CFD13BD0056
00007cfd13bd0547  vxorps xmm0, xmm15, xmm14
00007cfd13bd054c  pextrw r14d, xmm0, 0x03
00007cfd13bd0552  and r14d, 0x7FF8
00007cfd13bd0559  cmp r14d, 0x08
00007cfd13bd055d  jnz 0x00007CFD13BD0056
00007cfd13bd0563  movq r14, xmm14
00007cfd13bd0568  shl r14, 0x0D
00007cfd13bd056c  jbe 0x00007CFD13BD0056
00007cfd13bd0572  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd057a  jmp 0x00007CFD13BD0056
00007cfd13bd057f  ucomisd xmm1, xmm15
00007cfd13bd0584  jp 0x00007CFD13BD0593
00007cfd13bd0586  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd058e  jmp 0x00007CFD13BD008B
00007cfd13bd0593  vxorps xmm0, xmm1, xmm15
00007cfd13bd0598  pextrw r14d, xmm0, 0x03
00007cfd13bd059e  and r14d, 0x7FF8
00007cfd13bd05a5  cmp r14d, 0x08
00007cfd13bd05a9  jnz 0x00007CFD13BD008B
00007cfd13bd05af  movq r14, xmm15
00007cfd13bd05b4  shl r14, 0x0D
00007cfd13bd05b8  jbe 0x00007CFD13BD008B
00007cfd13bd05be  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd05c6  jmp 0x00007CFD13BD008B
00007cfd13bd05cb  call 0x00007CFD13AE27E0
00007cfd13bd05d0  jmp 0x00007CFD13BD009C
00007cfd13bd05d5  ucomisd xmm15, xmm14
00007cfd13bd05da  jp 0x00007CFD13BD05E9
00007cfd13bd05dc  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd05e4  jmp 0x00007CFD13BD00C9
00007cfd13bd05e9  vxorps xmm0, xmm15, xmm14
00007cfd13bd05ee  pextrw r14d, xmm0, 0x03
00007cfd13bd05f4  and r14d, 0x7FF8
00007cfd13bd05fb  cmp r14d, 0x08
00007cfd13bd05ff  jnz 0x00007CFD13BD00C9
00007cfd13bd0605  movq r14, xmm14
00007cfd13bd060a  shl r14, 0x0D
00007cfd13bd060e  jbe 0x00007CFD13BD00C9
00007cfd13bd0614  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd061c  jmp 0x00007CFD13BD00C9
00007cfd13bd0621  ucomisd xmm1, xmm15
00007cfd13bd0626  jp 0x00007CFD13BD0635
00007cfd13bd0628  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd0630  jmp 0x00007CFD13BD00FE
00007cfd13bd0635  vxorps xmm0, xmm1, xmm15
00007cfd13bd063a  pextrw r14d, xmm0, 0x03
00007cfd13bd0640  and r14d, 0x7FF8
00007cfd13bd0647  cmp r14d, 0x08
00007cfd13bd064b  jnz 0x00007CFD13BD00FE
00007cfd13bd0651  movq r14, xmm15
00007cfd13bd0656  shl r14, 0x0D
00007cfd13bd065a  jbe 0x00007CFD13BD00FE
00007cfd13bd0660  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd0668  jmp 0x00007CFD13BD00FE
00007cfd13bd066d  call 0x00007CFD13AE27E0
00007cfd13bd0672  jmp 0x00007CFD13BD010F
00007cfd13bd0677  ucomisd xmm15, xmm14
00007cfd13bd067c  jp 0x00007CFD13BD068B
00007cfd13bd067e  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd0686  jmp 0x00007CFD13BD013C
00007cfd13bd068b  vxorps xmm0, xmm15, xmm14
00007cfd13bd0690  pextrw r14d, xmm0, 0x03
00007cfd13bd0696  and r14d, 0x7FF8
00007cfd13bd069d  cmp r14d, 0x08
00007cfd13bd06a1  jnz 0x00007CFD13BD013C
00007cfd13bd06a7  movq r14, xmm14
00007cfd13bd06ac  shl r14, 0x0D
00007cfd13bd06b0  jbe 0x00007CFD13BD013C
00007cfd13bd06b6  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd06be  jmp 0x00007CFD13BD013C
00007cfd13bd06c3  ucomisd xmm1, xmm15
00007cfd13bd06c8  jp 0x00007CFD13BD06D7
00007cfd13bd06ca  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd06d2  jmp 0x00007CFD13BD0171
00007cfd13bd06d7  vxorps xmm0, xmm1, xmm15
00007cfd13bd06dc  pextrw r14d, xmm0, 0x03
00007cfd13bd06e2  and r14d, 0x7FF8
00007cfd13bd06e9  cmp r14d, 0x08
00007cfd13bd06ed  jnz 0x00007CFD13BD0171
00007cfd13bd06f3  movq r14, xmm15
00007cfd13bd06f8  shl r14, 0x0D
00007cfd13bd06fc  jbe 0x00007CFD13BD0171
00007cfd13bd0702  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd070a  jmp 0x00007CFD13BD0171
00007cfd13bd070f  call 0x00007CFD13AE27E0
00007cfd13bd0714  jmp 0x00007CFD13BD0182
00007cfd13bd0719  ucomisd xmm15, xmm14
00007cfd13bd071e  jp 0x00007CFD13BD072D
00007cfd13bd0720  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd0728  jmp 0x00007CFD13BD01AF
00007cfd13bd072d  vxorps xmm0, xmm15, xmm14
00007cfd13bd0732  pextrw r14d, xmm0, 0x03
00007cfd13bd0738  and r14d, 0x7FF8
00007cfd13bd073f  cmp r14d, 0x08
00007cfd13bd0743  jnz 0x00007CFD13BD01AF
00007cfd13bd0749  movq r14, xmm14
00007cfd13bd074e  shl r14, 0x0D
00007cfd13bd0752  jbe 0x00007CFD13BD01AF
00007cfd13bd0758  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd0760  jmp 0x00007CFD13BD01AF
00007cfd13bd0765  ucomisd xmm1, xmm15
00007cfd13bd076a  jp 0x00007CFD13BD0779
00007cfd13bd076c  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd0774  jmp 0x00007CFD13BD01E4
00007cfd13bd0779  vxorps xmm0, xmm1, xmm15
00007cfd13bd077e  pextrw r14d, xmm0, 0x03
00007cfd13bd0784  and r14d, 0x7FF8
00007cfd13bd078b  cmp r14d, 0x08
00007cfd13bd078f  jnz 0x00007CFD13BD01E4
00007cfd13bd0795  movq r14, xmm15
00007cfd13bd079a  shl r14, 0x0D
00007cfd13bd079e  jbe 0x00007CFD13BD01E4
00007cfd13bd07a4  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd07ac  jmp 0x00007CFD13BD01E4
00007cfd13bd07b1  call 0x00007CFD13AD59C0
00007cfd13bd07b6  jmp 0x00007CFD13BD01F5
00007cfd13bd07bb  ucomisd xmm15, xmm14
00007cfd13bd07c0  jp 0x00007CFD13BD07CF
00007cfd13bd07c2  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd07ca  jmp 0x00007CFD13BD022A
00007cfd13bd07cf  vxorps xmm0, xmm15, xmm14
00007cfd13bd07d4  pextrw eax, xmm0, 0x03
00007cfd13bd07d9  and eax, 0x7FF8
00007cfd13bd07de  cmp eax, 0x08
00007cfd13bd07e1  jnz 0x00007CFD13BD022A
00007cfd13bd07e7  movq rax, xmm14
00007cfd13bd07ec  shl rax, 0x0D
00007cfd13bd07f0  jbe 0x00007CFD13BD022A
00007cfd13bd07f6  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd07fe  jmp 0x00007CFD13BD022A
00007cfd13bd0803  ucomisd xmm1, xmm15
00007cfd13bd0808  jp 0x00007CFD13BD0817
00007cfd13bd080a  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd0812  jmp 0x00007CFD13BD025F
00007cfd13bd0817  vxorps xmm0, xmm1, xmm15
00007cfd13bd081c  pextrw eax, xmm0, 0x03
00007cfd13bd0821  and eax, 0x7FF8
00007cfd13bd0826  cmp eax, 0x08
00007cfd13bd0829  jnz 0x00007CFD13BD025F
00007cfd13bd082f  movq rax, xmm15
00007cfd13bd0834  shl rax, 0x0D
00007cfd13bd0838  jbe 0x00007CFD13BD025F
00007cfd13bd083e  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd0846  jmp 0x00007CFD13BD025F
00007cfd13bd084b  ucomisd xmm1, xmm15
00007cfd13bd0850  jp 0x00007CFD13BD085F
00007cfd13bd0852  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd085a  jmp 0x00007CFD13BD0294
00007cfd13bd085f  vxorps xmm0, xmm1, xmm15
00007cfd13bd0864  pextrw eax, xmm0, 0x03
00007cfd13bd0869  and eax, 0x7FF8
00007cfd13bd086e  cmp eax, 0x08
00007cfd13bd0871  jnz 0x00007CFD13BD0294
00007cfd13bd0877  movq rax, xmm15
00007cfd13bd087c  shl rax, 0x0D
00007cfd13bd0880  jbe 0x00007CFD13BD0294
00007cfd13bd0886  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd088e  jmp 0x00007CFD13BD0294
00007cfd13bd0893  call 0x00007CFD13A0E120
00007cfd13bd0898  jmp 0x00007CFD13BD02AF
00007cfd13bd089d  int3
00007cfd13bd089e  nop
00007cfd13bd08a0  mov eax, [r15+0x58]
00007cfd13bd08a4  lea r14d, [eax+0x01]
00007cfd13bd08a9  mov [rsp+0x10], r14d
00007cfd13bd08ae  mov r14d, r14d
00007cfd13bd08b1  mov [r15+0x58], r14
00007cfd13bd08b5  xor eax, eax
00007cfd13bd08b7  mov r14d, [rsp+0x10]
00007cfd13bd08bc  cmp r14d, 0x1F4
00007cfd13bd08c3  cmc
00007cfd13bd08c4  lahf
00007cfd13bd08c5  seto al
00007cfd13bd08c8  mov [r15+0x108], eax
00007cfd13bd08cf  mov eax, [r15+0x108]
00007cfd13bd08d6  sahf
00007cfd13bd08d7  jnz 0x00007CFD13BD0909
00007cfd13bd08d9  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd08e1  jz 0x00007CFD13BD1410
00007cfd13bd08e7  nop [rax+rax*1], ax
00007cfd13bd08f0  nop [rax+rax*1], eax
00007cfd13bd08f8  mov eax, 0x410134
00007cfd13bd08fd  mov [r15+0x100], rax
00007cfd13bd0904  jmp 0x00007CFD139FE110
00007cfd13bd0909  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd0911  jz 0x00007CFD13BD0940
00007cfd13bd0917  nop [rax+rax*1], ax
00007cfd13bd0920  nop [rax+rax*1], eax
00007cfd13bd0928  mov eax, 0x410084
00007cfd13bd092d  mov [r15+0x100], rax
00007cfd13bd0934  jmp 0x00007CFD139FE110
00007cfd13bd0939  int3
00007cfd13bd093a  int3
00007cfd13bd093b  nop [rax+rax*1], eax
00007cfd13bd0940  mov qword ptr [r15+0x60], 0x00
00007cfd13bd0948  mov rax, [r15+0x50]
00007cfd13bd094c  mov [r15+0x68], rax
00007cfd13bd0950  mov r14, [r15+0x40]
00007cfd13bd0954  mov r12, [r13+r14*1]
00007cfd13bd0959  lea r11, [r14+0x08]
00007cfd13bd095d  mov r10, [r13+r11*1]
00007cfd13bd0962  movq xmm1, r12
00007cfd13bd0967  movq xmm15, r10
00007cfd13bd096c  movq xmm1, xmm1
00007cfd13bd0970  movq xmm1, xmm1
00007cfd13bd0974  movaps [r15+0x120], xmm1
00007cfd13bd097c  movq xmm15, xmm15
00007cfd13bd0981  movq xmm15, xmm15
00007cfd13bd0986  movaps [r15+0x130], xmm15
00007cfd13bd098e  lea r12, [r14+0x10]
00007cfd13bd0992  mov r11, [r13+r12*1]
00007cfd13bd0997  lea r12, [r14+0x18]
00007cfd13bd099b  mov r10, [r13+r12*1]
00007cfd13bd09a0  movq xmm1, r11
00007cfd13bd09a5  movq xmm15, r10
00007cfd13bd09aa  movq xmm1, xmm1
00007cfd13bd09ae  movq xmm1, xmm1
00007cfd13bd09b2  movaps [r15+0x140], xmm1
00007cfd13bd09ba  movq xmm15, xmm15
00007cfd13bd09bf  movq xmm15, xmm15
00007cfd13bd09c4  movaps [r15+0x150], xmm15
00007cfd13bd09cc  lea r12, [r14+0x20]
00007cfd13bd09d0  mov r11, [r13+r12*1]
00007cfd13bd09d5  lea r12, [r14+0x28]
00007cfd13bd09d9  mov r10, [r13+r12*1]
00007cfd13bd09de  movq xmm1, r11
00007cfd13bd09e3  movq xmm15, r10
00007cfd13bd09e8  movq xmm1, xmm1
00007cfd13bd09ec  movq xmm1, xmm1
00007cfd13bd09f0  movaps [r15+0x160], xmm1
00007cfd13bd09f8  movq xmm15, xmm15
00007cfd13bd09fd  movq xmm15, xmm15
00007cfd13bd0a02  movaps [r15+0x170], xmm15
00007cfd13bd0a0a  lea r12, [r14+0x30]
00007cfd13bd0a0e  mov r11, [r13+r12*1]
00007cfd13bd0a13  lea r12, [r14+0x38]
00007cfd13bd0a17  mov r14, [r13+r12*1]
00007cfd13bd0a1c  movq xmm1, r11
00007cfd13bd0a21  movq xmm15, r14
00007cfd13bd0a26  movq xmm1, xmm1
00007cfd13bd0a2a  movq xmm1, xmm1
00007cfd13bd0a2e  movaps [r15+0x180], xmm1
00007cfd13bd0a36  movq xmm15, xmm15
00007cfd13bd0a3b  movq xmm15, xmm15
00007cfd13bd0a40  movaps [r15+0x210], xmm15
00007cfd13bd0a48  mov r14, [r15+0x48]
00007cfd13bd0a4c  mov [r15+0x78], r14
00007cfd13bd0a50  mov r12, [r13+r14*1]
00007cfd13bd0a55  movq xmm1, r12
00007cfd13bd0a5a  lea r12, [r14+0x40]
00007cfd13bd0a5e  mov r11, [r13+r12*1]
00007cfd13bd0a63  movq xmm15, r11
00007cfd13bd0a68  lea r12, [r14+0x80]
00007cfd13bd0a6f  mov r11, [r13+r12*1]
00007cfd13bd0a74  movq xmm14, r11
00007cfd13bd0a79  movaps xmm13, [r15+0x120]
00007cfd13bd0a81  movq r12, xmm13
00007cfd13bd0a86  movq r11, xmm1
00007cfd13bd0a8b  vmovq xmm1, r12
00007cfd13bd0a90  vmovq xmm13, r11
00007cfd13bd0a95  movaps xmm12, xmm1
00007cfd13bd0a99  mulsd xmm12, xmm13
00007cfd13bd0a9e  ucomisd xmm12, xmm12
00007cfd13bd0aa3  jp 0x00007CFD13BD0F06
00007cfd13bd0aa9  movq xmm12, xmm12
00007cfd13bd0aae  movaps xmm1, [r15+0x130]
00007cfd13bd0ab6  movq r12, xmm1
00007cfd13bd0abb  movq r11, xmm15
00007cfd13bd0ac0  vmovq xmm1, r12
00007cfd13bd0ac5  vmovq xmm15, r11
00007cfd13bd0aca  movaps xmm13, xmm1
00007cfd13bd0ace  mulsd xmm13, xmm15
00007cfd13bd0ad3  ucomisd xmm13, xmm13
00007cfd13bd0ad8  jp 0x00007CFD13BD0F52
00007cfd13bd0ade  movq xmm13, xmm13
00007cfd13bd0ae3  movq r12, xmm12
00007cfd13bd0ae8  movaps xmm1, [r15+0x110]
00007cfd13bd0af0  movq r11, xmm1
00007cfd13bd0af5  vmovq xmm1, r12
00007cfd13bd0afa  vmovq xmm15, r11
00007cfd13bd0aff  movaps xmm12, xmm1
00007cfd13bd0b03  addsd xmm12, xmm15
00007cfd13bd0b08  ucomisd xmm12, xmm12
00007cfd13bd0b0d  jp 0x00007CFD13BD0F9E
00007cfd13bd0b13  movq xmm12, xmm12
00007cfd13bd0b18  movq r12, xmm12
00007cfd13bd0b1d  movq r11, xmm13
00007cfd13bd0b22  vmovq xmm1, r12
00007cfd13bd0b27  vmovq xmm15, r11
00007cfd13bd0b2c  movaps xmm13, xmm1
00007cfd13bd0b30  addsd xmm13, xmm15
00007cfd13bd0b35  ucomisd xmm13, xmm13
00007cfd13bd0b3a  jp 0x00007CFD13BD0FEA
00007cfd13bd0b40  movq xmm13, xmm13
00007cfd13bd0b45  movaps xmm1, [r15+0x140]
00007cfd13bd0b4d  movq r12, xmm1
00007cfd13bd0b52  movq r11, xmm14
00007cfd13bd0b57  vmovq xmm1, r12
00007cfd13bd0b5c  vmovq xmm15, r11
00007cfd13bd0b61  movaps xmm14, xmm1
00007cfd13bd0b65  mulsd xmm14, xmm15
00007cfd13bd0b6a  ucomisd xmm14, xmm14
00007cfd13bd0b6f  jp 0x00007CFD13BD1036
00007cfd13bd0b75  movq xmm14, xmm14
00007cfd13bd0b7a  lea r12, [r14+0xC0]
00007cfd13bd0b81  mov r11, [r13+r12*1]
00007cfd13bd0b86  movq xmm1, r11
00007cfd13bd0b8b  movq r12, xmm13
00007cfd13bd0b90  movq r11, xmm14
00007cfd13bd0b95  vmovq xmm15, r12
00007cfd13bd0b9a  vmovq xmm14, r11
00007cfd13bd0b9f  movaps xmm13, xmm15
00007cfd13bd0ba3  addsd xmm13, xmm14
00007cfd13bd0ba8  ucomisd xmm13, xmm13
00007cfd13bd0bad  jp 0x00007CFD13BD108C
00007cfd13bd0bb3  movq xmm13, xmm13
00007cfd13bd0bb8  movaps xmm15, [r15+0x150]
00007cfd13bd0bc0  movq r12, xmm15
00007cfd13bd0bc5  movq r11, xmm1
00007cfd13bd0bca  vmovq xmm1, r12
00007cfd13bd0bcf  vmovq xmm15, r11
00007cfd13bd0bd4  movaps xmm14, xmm1
00007cfd13bd0bd8  mulsd xmm14, xmm15
00007cfd13bd0bdd  ucomisd xmm14, xmm14
00007cfd13bd0be2  jp 0x00007CFD13BD10D8
00007cfd13bd0be8  movq xmm14, xmm14
00007cfd13bd0bed  lea r12, [r14+0x100]
00007cfd13bd0bf4  mov r11, [r13+r12*1]
00007cfd13bd0bf9  movq xmm1, r11
00007cfd13bd0bfe  movq r12, xmm13
00007cfd13bd0c03  movq r11, xmm14
00007cfd13bd0c08  vmovq xmm15, r12
00007cfd13bd0c0d  vmovq xmm14, r11
00007cfd13bd0c12  movaps xmm13, xmm15
00007cfd13bd0c16  addsd xmm13, xmm14
00007cfd13bd0c1b  ucomisd xmm13, xmm13
00007cfd13bd0c20  jp 0x00007CFD13BD112E
00007cfd13bd0c26  movq xmm13, xmm13
00007cfd13bd0c2b  movaps xmm15, [r15+0x160]
00007cfd13bd0c33  movq r12, xmm15
00007cfd13bd0c38  movq r11, xmm1
00007cfd13bd0c3d  vmovq xmm1, r12
00007cfd13bd0c42  vmovq xmm15, r11
00007cfd13bd0c47  movaps xmm14, xmm1
00007cfd13bd0c4b  mulsd xmm14, xmm15
00007cfd13bd0c50  ucomisd xmm14, xmm14
00007cfd13bd0c55  jp 0x00007CFD13BD117A
00007cfd13bd0c5b  movq xmm14, xmm14
00007cfd13bd0c60  lea r12, [r14+0x140]
00007cfd13bd0c67  mov r11, [r13+r12*1]
00007cfd13bd0c6c  movq xmm1, r11
00007cfd13bd0c71  movq r12, xmm13
00007cfd13bd0c76  movq r11, xmm14
00007cfd13bd0c7b  vmovq xmm15, r12
00007cfd13bd0c80  vmovq xmm14, r11
00007cfd13bd0c85  movaps xmm13, xmm15
00007cfd13bd0c89  addsd xmm13, xmm14
00007cfd13bd0c8e  ucomisd xmm13, xmm13
00007cfd13bd0c93  jp 0x00007CFD13BD11D0
00007cfd13bd0c99  movq xmm13, xmm13
00007cfd13bd0c9e  movaps xmm15, [r15+0x170]
00007cfd13bd0ca6  movq r12, xmm15
00007cfd13bd0cab  movq r11, xmm1
00007cfd13bd0cb0  vmovq xmm1, r12
00007cfd13bd0cb5  vmovq xmm15, r11
00007cfd13bd0cba  movaps xmm14, xmm1
00007cfd13bd0cbe  mulsd xmm14, xmm15
00007cfd13bd0cc3  ucomisd xmm14, xmm14
00007cfd13bd0cc8  jp 0x00007CFD13BD121C
00007cfd13bd0cce  movq xmm14, xmm14
00007cfd13bd0cd3  lea r12, [r14+0x180]
00007cfd13bd0cda  mov r11, [r13+r12*1]
00007cfd13bd0cdf  movq xmm1, r11
00007cfd13bd0ce4  movq r12, xmm13
00007cfd13bd0ce9  movq r11, xmm14
00007cfd13bd0cee  vmovq xmm15, r12
00007cfd13bd0cf3  vmovq xmm14, r11
00007cfd13bd0cf8  movaps xmm13, xmm15
00007cfd13bd0cfc  addsd xmm13, xmm14
00007cfd13bd0d01  ucomisd xmm13, xmm13
00007cfd13bd0d06  jp 0x00007CFD13BD1272
00007cfd13bd0d0c  movq xmm13, xmm13
00007cfd13bd0d11  movaps xmm15, [r15+0x180]
00007cfd13bd0d19  movq r12, xmm15
00007cfd13bd0d1e  movq r11, xmm1
00007cfd13bd0d23  vmovq xmm1, r12
00007cfd13bd0d28  vmovq xmm15, r11
00007cfd13bd0d2d  movaps xmm14, xmm1
00007cfd13bd0d31  mulsd xmm14, xmm15
00007cfd13bd0d36  ucomisd xmm14, xmm14
00007cfd13bd0d3b  jp 0x00007CFD13BD12BE
00007cfd13bd0d41  movq xmm14, xmm14
00007cfd13bd0d46  lea r12, [r14+0x1C0]
00007cfd13bd0d4d  mov r14, [r13+r12*1]
00007cfd13bd0d52  movq xmm1, r14
00007cfd13bd0d57  movaps [r15+0x240], xmm1
00007cfd13bd0d5f  movq r14, xmm13
00007cfd13bd0d64  movq r12, xmm14
00007cfd13bd0d69  vmovq xmm15, r14
00007cfd13bd0d6e  vmovq xmm14, r12
00007cfd13bd0d73  movaps xmm13, xmm15
00007cfd13bd0d77  addsd xmm13, xmm14
00007cfd13bd0d7c  ucomisd xmm13, xmm13
00007cfd13bd0d81  jp 0x00007CFD13BD1314
00007cfd13bd0d87  movq xmm13, xmm13
00007cfd13bd0d8c  movaps xmm15, [r15+0x210]
00007cfd13bd0d94  movq r14, xmm15
00007cfd13bd0d99  movq r12, xmm1
00007cfd13bd0d9e  vmovq xmm1, r14
00007cfd13bd0da3  vmovq xmm15, r12
00007cfd13bd0da8  movaps xmm14, xmm1
00007cfd13bd0dac  mulsd xmm14, xmm15
00007cfd13bd0db1  ucomisd xmm14, xmm14
00007cfd13bd0db6  jp 0x00007CFD13BD1360
00007cfd13bd0dbc  movq xmm14, xmm14
00007cfd13bd0dc1  movaps [r15+0x230], xmm14
00007cfd13bd0dc9  movq r14, xmm13
00007cfd13bd0dce  movq r12, xmm14
00007cfd13bd0dd3  vmovq xmm1, r14
00007cfd13bd0dd8  vmovq xmm15, r12
00007cfd13bd0ddd  movaps xmm14, xmm1
00007cfd13bd0de1  addsd xmm14, xmm15
00007cfd13bd0de6  ucomisd xmm14, xmm14
00007cfd13bd0deb  jp 0x00007CFD13BD13AC
00007cfd13bd0df1  movq xmm14, xmm14
00007cfd13bd0df6  movaps [r15+0x220], xmm14
00007cfd13bd0dfe  movq r14, xmm14
00007cfd13bd0e03  mov [r13+rax*1], r14
00007cfd13bd0e08  mov qword ptr [r15+0x70], 0x08
00007cfd13bd0e10  xor eax, eax
00007cfd13bd0e12  mov r14d, 0x08
00007cfd13bd0e18  mov r12d, 0x40
00007cfd13bd0e1e  cmp r14, r12
00007cfd13bd0e21  cmc
00007cfd13bd0e22  lahf
00007cfd13bd0e23  seto al
00007cfd13bd0e26  mov [r15+0x108], eax
00007cfd13bd0e2d  mov eax, [r15+0x108]
00007cfd13bd0e34  sahf
00007cfd13bd0e35  jnz 0x00007CFD13BD0E67
00007cfd13bd0e37  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd0e3f  jz 0x00007CFD13BCFD40
00007cfd13bd0e45  nop [rax+rax*1], ax
00007cfd13bd0e4e  nop [rax+rax*1], eax
00007cfd13bd0e56  mov eax, 0x410118
00007cfd13bd0e5b  mov [r15+0x100], rax
00007cfd13bd0e62  jmp 0x00007CFD139FE110
00007cfd13bd0e67  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd0e6f  jz 0x00007CFD13BCF3F0
00007cfd13bd0e75  nop [rax+rax*1], ax
00007cfd13bd0e7e  nop [rax+rax*1], eax
00007cfd13bd0e86  mov eax, 0x4100A4
00007cfd13bd0e8b  mov [r15+0x100], rax
00007cfd13bd0e92  jmp 0x00007CFD139FE110
00007cfd13bd0e97  int3
00007cfd13bd0e98  call 0x00007CFD13AE27E0
00007cfd13bd0e9d  jmp 0x00007CFD13BD0959
00007cfd13bd0ea2  call 0x00007CFD13AAE800
00007cfd13bd0ea7  jmp 0x00007CFD13BD0962
00007cfd13bd0eac  call 0x00007CFD13AC0370
00007cfd13bd0eb1  jmp 0x00007CFD13BD0997
00007cfd13bd0eb6  call 0x00007CFD13ABF100
00007cfd13bd0ebb  jmp 0x00007CFD13BD09A0
00007cfd13bd0ec0  call 0x00007CFD13AC0370
00007cfd13bd0ec5  jmp 0x00007CFD13BD09D5
00007cfd13bd0eca  call 0x00007CFD13ABF100
00007cfd13bd0ecf  jmp 0x00007CFD13BD09DE
00007cfd13bd0ed4  call 0x00007CFD13AC0370
00007cfd13bd0ed9  jmp 0x00007CFD13BD0A13
00007cfd13bd0ede  call 0x00007CFD13AC3AE0
00007cfd13bd0ee3  jmp 0x00007CFD13BD0A1C
00007cfd13bd0ee8  call 0x00007CFD13AE27E0
00007cfd13bd0eed  jmp 0x00007CFD13BD0A55
00007cfd13bd0ef2  call 0x00007CFD13AC0370
00007cfd13bd0ef7  jmp 0x00007CFD13BD0A63
00007cfd13bd0efc  call 0x00007CFD13AC0370
00007cfd13bd0f01  jmp 0x00007CFD13BD0A74
00007cfd13bd0f06  ucomisd xmm1, xmm13
00007cfd13bd0f0b  jp 0x00007CFD13BD0F1A
00007cfd13bd0f0d  movaps xmm12, [0x00007CFD137FE030]
00007cfd13bd0f15  jmp 0x00007CFD13BD0AA9
00007cfd13bd0f1a  vxorps xmm0, xmm1, xmm13
00007cfd13bd0f1f  pextrw r12d, xmm0, 0x03
00007cfd13bd0f25  and r12d, 0x7FF8
00007cfd13bd0f2c  cmp r12d, 0x08
00007cfd13bd0f30  jnz 0x00007CFD13BD0AA9
00007cfd13bd0f36  movq r12, xmm13
00007cfd13bd0f3b  shl r12, 0x0D
00007cfd13bd0f3f  jbe 0x00007CFD13BD0AA9
00007cfd13bd0f45  vorps xmm12, xmm13, [0x00007CFD137FE040]
00007cfd13bd0f4d  jmp 0x00007CFD13BD0AA9
00007cfd13bd0f52  ucomisd xmm1, xmm15
00007cfd13bd0f57  jp 0x00007CFD13BD0F66
00007cfd13bd0f59  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd0f61  jmp 0x00007CFD13BD0ADE
00007cfd13bd0f66  vxorps xmm0, xmm1, xmm15
00007cfd13bd0f6b  pextrw r12d, xmm0, 0x03
00007cfd13bd0f71  and r12d, 0x7FF8
00007cfd13bd0f78  cmp r12d, 0x08
00007cfd13bd0f7c  jnz 0x00007CFD13BD0ADE
00007cfd13bd0f82  movq r12, xmm15
00007cfd13bd0f87  shl r12, 0x0D
00007cfd13bd0f8b  jbe 0x00007CFD13BD0ADE
00007cfd13bd0f91  vorps xmm13, xmm15, [0x00007CFD137FE040]
00007cfd13bd0f99  jmp 0x00007CFD13BD0ADE
00007cfd13bd0f9e  ucomisd xmm1, xmm15
00007cfd13bd0fa3  jp 0x00007CFD13BD0FB2
00007cfd13bd0fa5  movaps xmm12, [0x00007CFD137FE030]
00007cfd13bd0fad  jmp 0x00007CFD13BD0B13
00007cfd13bd0fb2  vxorps xmm0, xmm1, xmm15
00007cfd13bd0fb7  pextrw r12d, xmm0, 0x03
00007cfd13bd0fbd  and r12d, 0x7FF8
00007cfd13bd0fc4  cmp r12d, 0x08
00007cfd13bd0fc8  jnz 0x00007CFD13BD0B13
00007cfd13bd0fce  movq r12, xmm15
00007cfd13bd0fd3  shl r12, 0x0D
00007cfd13bd0fd7  jbe 0x00007CFD13BD0B13
00007cfd13bd0fdd  vorps xmm12, xmm15, [0x00007CFD137FE040]
00007cfd13bd0fe5  jmp 0x00007CFD13BD0B13
00007cfd13bd0fea  ucomisd xmm1, xmm15
00007cfd13bd0fef  jp 0x00007CFD13BD0FFE
00007cfd13bd0ff1  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd0ff9  jmp 0x00007CFD13BD0B40
00007cfd13bd0ffe  vxorps xmm0, xmm1, xmm15
00007cfd13bd1003  pextrw r12d, xmm0, 0x03
00007cfd13bd1009  and r12d, 0x7FF8
00007cfd13bd1010  cmp r12d, 0x08
00007cfd13bd1014  jnz 0x00007CFD13BD0B40
00007cfd13bd101a  movq r12, xmm15
00007cfd13bd101f  shl r12, 0x0D
00007cfd13bd1023  jbe 0x00007CFD13BD0B40
00007cfd13bd1029  vorps xmm13, xmm15, [0x00007CFD137FE040]
00007cfd13bd1031  jmp 0x00007CFD13BD0B40
00007cfd13bd1036  ucomisd xmm1, xmm15
00007cfd13bd103b  jp 0x00007CFD13BD104A
00007cfd13bd103d  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd1045  jmp 0x00007CFD13BD0B75
00007cfd13bd104a  vxorps xmm0, xmm1, xmm15
00007cfd13bd104f  pextrw r12d, xmm0, 0x03
00007cfd13bd1055  and r12d, 0x7FF8
00007cfd13bd105c  cmp r12d, 0x08
00007cfd13bd1060  jnz 0x00007CFD13BD0B75
00007cfd13bd1066  movq r12, xmm15
00007cfd13bd106b  shl r12, 0x0D
00007cfd13bd106f  jbe 0x00007CFD13BD0B75
00007cfd13bd1075  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd107d  jmp 0x00007CFD13BD0B75
00007cfd13bd1082  call 0x00007CFD13AC0370
00007cfd13bd1087  jmp 0x00007CFD13BD0B86
00007cfd13bd108c  ucomisd xmm15, xmm14
00007cfd13bd1091  jp 0x00007CFD13BD10A0
00007cfd13bd1093  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd109b  jmp 0x00007CFD13BD0BB3
00007cfd13bd10a0  vxorps xmm0, xmm15, xmm14
00007cfd13bd10a5  pextrw r12d, xmm0, 0x03
00007cfd13bd10ab  and r12d, 0x7FF8
00007cfd13bd10b2  cmp r12d, 0x08
00007cfd13bd10b6  jnz 0x00007CFD13BD0BB3
00007cfd13bd10bc  movq r12, xmm14
00007cfd13bd10c1  shl r12, 0x0D
00007cfd13bd10c5  jbe 0x00007CFD13BD0BB3
00007cfd13bd10cb  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd10d3  jmp 0x00007CFD13BD0BB3
00007cfd13bd10d8  ucomisd xmm1, xmm15
00007cfd13bd10dd  jp 0x00007CFD13BD10EC
00007cfd13bd10df  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd10e7  jmp 0x00007CFD13BD0BE8
00007cfd13bd10ec  vxorps xmm0, xmm1, xmm15
00007cfd13bd10f1  pextrw r12d, xmm0, 0x03
00007cfd13bd10f7  and r12d, 0x7FF8
00007cfd13bd10fe  cmp r12d, 0x08
00007cfd13bd1102  jnz 0x00007CFD13BD0BE8
00007cfd13bd1108  movq r12, xmm15
00007cfd13bd110d  shl r12, 0x0D
00007cfd13bd1111  jbe 0x00007CFD13BD0BE8
00007cfd13bd1117  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd111f  jmp 0x00007CFD13BD0BE8
00007cfd13bd1124  call 0x00007CFD13AC0370
00007cfd13bd1129  jmp 0x00007CFD13BD0BF9
00007cfd13bd112e  ucomisd xmm15, xmm14
00007cfd13bd1133  jp 0x00007CFD13BD1142
00007cfd13bd1135  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd113d  jmp 0x00007CFD13BD0C26
00007cfd13bd1142  vxorps xmm0, xmm15, xmm14
00007cfd13bd1147  pextrw r12d, xmm0, 0x03
00007cfd13bd114d  and r12d, 0x7FF8
00007cfd13bd1154  cmp r12d, 0x08
00007cfd13bd1158  jnz 0x00007CFD13BD0C26
00007cfd13bd115e  movq r12, xmm14
00007cfd13bd1163  shl r12, 0x0D
00007cfd13bd1167  jbe 0x00007CFD13BD0C26
00007cfd13bd116d  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd1175  jmp 0x00007CFD13BD0C26
00007cfd13bd117a  ucomisd xmm1, xmm15
00007cfd13bd117f  jp 0x00007CFD13BD118E
00007cfd13bd1181  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd1189  jmp 0x00007CFD13BD0C5B
00007cfd13bd118e  vxorps xmm0, xmm1, xmm15
00007cfd13bd1193  pextrw r12d, xmm0, 0x03
00007cfd13bd1199  and r12d, 0x7FF8
00007cfd13bd11a0  cmp r12d, 0x08
00007cfd13bd11a4  jnz 0x00007CFD13BD0C5B
00007cfd13bd11aa  movq r12, xmm15
00007cfd13bd11af  shl r12, 0x0D
00007cfd13bd11b3  jbe 0x00007CFD13BD0C5B
00007cfd13bd11b9  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd11c1  jmp 0x00007CFD13BD0C5B
00007cfd13bd11c6  call 0x00007CFD13AC0370
00007cfd13bd11cb  jmp 0x00007CFD13BD0C6C
00007cfd13bd11d0  ucomisd xmm15, xmm14
00007cfd13bd11d5  jp 0x00007CFD13BD11E4
00007cfd13bd11d7  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd11df  jmp 0x00007CFD13BD0C99
00007cfd13bd11e4  vxorps xmm0, xmm15, xmm14
00007cfd13bd11e9  pextrw r12d, xmm0, 0x03
00007cfd13bd11ef  and r12d, 0x7FF8
00007cfd13bd11f6  cmp r12d, 0x08
00007cfd13bd11fa  jnz 0x00007CFD13BD0C99
00007cfd13bd1200  movq r12, xmm14
00007cfd13bd1205  shl r12, 0x0D
00007cfd13bd1209  jbe 0x00007CFD13BD0C99
00007cfd13bd120f  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd1217  jmp 0x00007CFD13BD0C99
00007cfd13bd121c  ucomisd xmm1, xmm15
00007cfd13bd1221  jp 0x00007CFD13BD1230
00007cfd13bd1223  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd122b  jmp 0x00007CFD13BD0CCE
00007cfd13bd1230  vxorps xmm0, xmm1, xmm15
00007cfd13bd1235  pextrw r12d, xmm0, 0x03
00007cfd13bd123b  and r12d, 0x7FF8
00007cfd13bd1242  cmp r12d, 0x08
00007cfd13bd1246  jnz 0x00007CFD13BD0CCE
00007cfd13bd124c  movq r12, xmm15
00007cfd13bd1251  shl r12, 0x0D
00007cfd13bd1255  jbe 0x00007CFD13BD0CCE
00007cfd13bd125b  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd1263  jmp 0x00007CFD13BD0CCE
00007cfd13bd1268  call 0x00007CFD13AC0370
00007cfd13bd126d  jmp 0x00007CFD13BD0CDF
00007cfd13bd1272  ucomisd xmm15, xmm14
00007cfd13bd1277  jp 0x00007CFD13BD1286
00007cfd13bd1279  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd1281  jmp 0x00007CFD13BD0D0C
00007cfd13bd1286  vxorps xmm0, xmm15, xmm14
00007cfd13bd128b  pextrw r12d, xmm0, 0x03
00007cfd13bd1291  and r12d, 0x7FF8
00007cfd13bd1298  cmp r12d, 0x08
00007cfd13bd129c  jnz 0x00007CFD13BD0D0C
00007cfd13bd12a2  movq r12, xmm14
00007cfd13bd12a7  shl r12, 0x0D
00007cfd13bd12ab  jbe 0x00007CFD13BD0D0C
00007cfd13bd12b1  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd12b9  jmp 0x00007CFD13BD0D0C
00007cfd13bd12be  ucomisd xmm1, xmm15
00007cfd13bd12c3  jp 0x00007CFD13BD12D2
00007cfd13bd12c5  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd12cd  jmp 0x00007CFD13BD0D41
00007cfd13bd12d2  vxorps xmm0, xmm1, xmm15
00007cfd13bd12d7  pextrw r12d, xmm0, 0x03
00007cfd13bd12dd  and r12d, 0x7FF8
00007cfd13bd12e4  cmp r12d, 0x08
00007cfd13bd12e8  jnz 0x00007CFD13BD0D41
00007cfd13bd12ee  movq r12, xmm15
00007cfd13bd12f3  shl r12, 0x0D
00007cfd13bd12f7  jbe 0x00007CFD13BD0D41
00007cfd13bd12fd  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd1305  jmp 0x00007CFD13BD0D41
00007cfd13bd130a  call 0x00007CFD13AC3AE0
00007cfd13bd130f  jmp 0x00007CFD13BD0D52
00007cfd13bd1314  ucomisd xmm15, xmm14
00007cfd13bd1319  jp 0x00007CFD13BD1328
00007cfd13bd131b  movaps xmm13, [0x00007CFD137FE030]
00007cfd13bd1323  jmp 0x00007CFD13BD0D87
00007cfd13bd1328  vxorps xmm0, xmm15, xmm14
00007cfd13bd132d  pextrw r14d, xmm0, 0x03
00007cfd13bd1333  and r14d, 0x7FF8
00007cfd13bd133a  cmp r14d, 0x08
00007cfd13bd133e  jnz 0x00007CFD13BD0D87
00007cfd13bd1344  movq r14, xmm14
00007cfd13bd1349  shl r14, 0x0D
00007cfd13bd134d  jbe 0x00007CFD13BD0D87
00007cfd13bd1353  vorps xmm13, xmm14, [0x00007CFD137FE040]
00007cfd13bd135b  jmp 0x00007CFD13BD0D87
00007cfd13bd1360  ucomisd xmm1, xmm15
00007cfd13bd1365  jp 0x00007CFD13BD1374
00007cfd13bd1367  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd136f  jmp 0x00007CFD13BD0DBC
00007cfd13bd1374  vxorps xmm0, xmm1, xmm15
00007cfd13bd1379  pextrw r14d, xmm0, 0x03
00007cfd13bd137f  and r14d, 0x7FF8
00007cfd13bd1386  cmp r14d, 0x08
00007cfd13bd138a  jnz 0x00007CFD13BD0DBC
00007cfd13bd1390  movq r14, xmm15
00007cfd13bd1395  shl r14, 0x0D
00007cfd13bd1399  jbe 0x00007CFD13BD0DBC
00007cfd13bd139f  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd13a7  jmp 0x00007CFD13BD0DBC
00007cfd13bd13ac  ucomisd xmm1, xmm15
00007cfd13bd13b1  jp 0x00007CFD13BD13C0
00007cfd13bd13b3  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd13bb  jmp 0x00007CFD13BD0DF1
00007cfd13bd13c0  vxorps xmm0, xmm1, xmm15
00007cfd13bd13c5  pextrw r14d, xmm0, 0x03
00007cfd13bd13cb  and r14d, 0x7FF8
00007cfd13bd13d2  cmp r14d, 0x08
00007cfd13bd13d6  jnz 0x00007CFD13BD0DF1
00007cfd13bd13dc  movq r14, xmm15
00007cfd13bd13e1  shl r14, 0x0D
00007cfd13bd13e5  jbe 0x00007CFD13BD0DF1
00007cfd13bd13eb  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd13f3  jmp 0x00007CFD13BD0DF1
00007cfd13bd13f8  call 0x00007CFD13A0E120
00007cfd13bd13fd  jmp 0x00007CFD13BD0E08
00007cfd13bd1402  int3
00007cfd13bd1403  nop [rax+rax*1], ax
00007cfd13bd140c  nop [rax], eax
00007cfd13bd1410  mov qword ptr [r15+0x40], 0x420000
00007cfd13bd1418  mov eax, 0x4201B8
00007cfd13bd141d  mov r14, [r13+rax*1]
00007cfd13bd1422  movq xmm1, r14
00007cfd13bd1427  mov rax, [r15+0x50]
00007cfd13bd142b  mov r14, [r13+rax*1]
00007cfd13bd1430  movq xmm15, r14
00007cfd13bd1435  movaps [r15+0x120], xmm15
00007cfd13bd143d  mov qword ptr [r15+0x48], 0x08
00007cfd13bd1445  xor eax, eax
00007cfd13bd1447  mov r14d, 0x08
00007cfd13bd144d  mov r12d, 0x200
00007cfd13bd1453  cmp r14, r12
00007cfd13bd1456  cmc
00007cfd13bd1457  lahf
00007cfd13bd1458  seto al
00007cfd13bd145b  mov [r15+0x108], eax
00007cfd13bd1462  movq rax, xmm1
00007cfd13bd1467  movq r14, xmm15
00007cfd13bd146c  vmovq xmm1, rax
00007cfd13bd1471  vmovq xmm15, r14
00007cfd13bd1476  movaps xmm14, xmm1
00007cfd13bd147a  addsd xmm14, xmm15
00007cfd13bd147f  ucomisd xmm14, xmm14
00007cfd13bd1484  jp 0x00007CFD13BD1516
00007cfd13bd148a  movq xmm14, xmm14
00007cfd13bd148f  movaps [r15+0x110], xmm14
00007cfd13bd1497  mov eax, [r15+0x108]
00007cfd13bd149e  sahf
00007cfd13bd149f  jnz 0x00007CFD13BD14D1
00007cfd13bd14a1  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd14a9  jz 0x00007CFD13BD16A0
00007cfd13bd14af  nop [rax+rax*1], ax
00007cfd13bd14b8  nop [rax+rax*1], eax
00007cfd13bd14c0  mov eax, 0x410154
00007cfd13bd14c5  mov [r15+0x100], rax
00007cfd13bd14cc  jmp 0x00007CFD139FE110
00007cfd13bd14d1  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd14d9  jz 0x00007CFD13BD1560
00007cfd13bd14df  nop [rax+rax*1], ax
00007cfd13bd14e8  nop [rax+rax*1], eax
00007cfd13bd14f0  mov eax, 0x410140
00007cfd13bd14f5  mov [r15+0x100], rax
00007cfd13bd14fc  jmp 0x00007CFD139FE110
00007cfd13bd1501  int3
00007cfd13bd1502  call 0x00007CFD13A0DC20
00007cfd13bd1507  jmp 0x00007CFD13BD1422
00007cfd13bd150c  call 0x00007CFD13A0DC20
00007cfd13bd1511  jmp 0x00007CFD13BD1430
00007cfd13bd1516  ucomisd xmm1, xmm15
00007cfd13bd151b  jp 0x00007CFD13BD152A
00007cfd13bd151d  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd1525  jmp 0x00007CFD13BD148A
00007cfd13bd152a  vxorps xmm0, xmm1, xmm15
00007cfd13bd152f  pextrw eax, xmm0, 0x03
00007cfd13bd1534  and eax, 0x7FF8
00007cfd13bd1539  cmp eax, 0x08
00007cfd13bd153c  jnz 0x00007CFD13BD148A
00007cfd13bd1542  movq rax, xmm15
00007cfd13bd1547  shl rax, 0x0D
00007cfd13bd154b  jbe 0x00007CFD13BD148A
00007cfd13bd1551  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd1559  jmp 0x00007CFD13BD148A
00007cfd13bd155e  int3
00007cfd13bd155f  nop
00007cfd13bd1560  mov rax, [r15+0x48]
00007cfd13bd1564  mov r14, [r15+0x50]
00007cfd13bd1568  lea r12, [r14+rax*1]
00007cfd13bd156c  mov r14, [r13+r12*1]
00007cfd13bd1571  movq xmm1, r14
00007cfd13bd1576  movaps [r15+0x120], xmm1
00007cfd13bd157e  lea r14, [rax+0x08]
00007cfd13bd1582  mov [r15+0x48], r14
00007cfd13bd1586  xor eax, eax
00007cfd13bd1588  mov r12d, 0x200
00007cfd13bd158e  cmp r14, r12
00007cfd13bd1591  cmc
00007cfd13bd1592  lahf
00007cfd13bd1593  seto al
00007cfd13bd1596  mov [r15+0x108], eax
00007cfd13bd159d  movaps xmm15, [r15+0x110]
00007cfd13bd15a5  movq rax, xmm15
00007cfd13bd15aa  movq r14, xmm1
00007cfd13bd15af  vmovq xmm1, rax
00007cfd13bd15b4  vmovq xmm15, r14
00007cfd13bd15b9  movaps xmm14, xmm1
00007cfd13bd15bd  addsd xmm14, xmm15
00007cfd13bd15c2  ucomisd xmm14, xmm14
00007cfd13bd15c7  jp 0x00007CFD13BD164F
00007cfd13bd15cd  movq xmm14, xmm14
00007cfd13bd15d2  movaps [r15+0x110], xmm14
00007cfd13bd15da  mov eax, [r15+0x108]
00007cfd13bd15e1  sahf
00007cfd13bd15e2  jnz 0x00007CFD13BD1614
00007cfd13bd15e4  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd15ec  jz 0x00007CFD13BD16A0
00007cfd13bd15f2  nop [rax+rax*1], ax
00007cfd13bd15fb  nop [rax+rax*1], eax
00007cfd13bd1603  mov eax, 0x410154
00007cfd13bd1608  mov [r15+0x100], rax
00007cfd13bd160f  jmp 0x00007CFD139FE110
00007cfd13bd1614  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd161c  jz 0x00007CFD13BD1560
00007cfd13bd1622  nop [rax+rax*1], ax
00007cfd13bd162b  nop [rax+rax*1], eax
00007cfd13bd1633  mov eax, 0x410140
00007cfd13bd1638  mov [r15+0x100], rax
00007cfd13bd163f  jmp 0x00007CFD139FE110
00007cfd13bd1644  int3
00007cfd13bd1645  call 0x00007CFD13AC3AE0
00007cfd13bd164a  jmp 0x00007CFD13BD1571
00007cfd13bd164f  ucomisd xmm1, xmm15
00007cfd13bd1654  jp 0x00007CFD13BD1663
00007cfd13bd1656  movaps xmm14, [0x00007CFD137FE030]
00007cfd13bd165e  jmp 0x00007CFD13BD15CD
00007cfd13bd1663  vxorps xmm0, xmm1, xmm15
00007cfd13bd1668  pextrw eax, xmm0, 0x03
00007cfd13bd166d  and eax, 0x7FF8
00007cfd13bd1672  cmp eax, 0x08
00007cfd13bd1675  jnz 0x00007CFD13BD15CD
00007cfd13bd167b  movq rax, xmm15
00007cfd13bd1680  shl rax, 0x0D
00007cfd13bd1684  jbe 0x00007CFD13BD15CD
00007cfd13bd168a  vorps xmm14, xmm15, [0x00007CFD137FE040]
00007cfd13bd1692  jmp 0x00007CFD13BD15CD
00007cfd13bd1697  int3
00007cfd13bd1698  nop [rax+rax*1], eax
00007cfd13bd16a0  mov rax, [r15+0x40]
00007cfd13bd16a4  lea r14, [rax+0x1B8]
00007cfd13bd16ab  movaps xmm1, [r15+0x110]
00007cfd13bd16b3  movq rax, xmm1
00007cfd13bd16b8  mov [r13+r14*1], rax
00007cfd13bd16bd  mov rax, [r15+0xF0]
00007cfd13bd16c4  mov [r15+0x100], rax
00007cfd13bd16cb  jmp 0x00007CFD13BCE5C0
00007cfd13bd16d0  int3
00007cfd13bd16d1  call 0x00007CFD13AD5EB0
00007cfd13bd16d6  jmp 0x00007CFD13BD16BD
00007cfd13bd16db  int3
00007cfd13bd16dc  nop [rax], eax
00007cfd13bd16e0  mov qword ptr [r15+0x100], 0x04
00007cfd13bd16eb  mov esi, 0x00
00007cfd13bd16f0  mov edx, 0x09
00007cfd13bd16f5  mov rdi, 0x7FFE93539150
00007cfd13bd16ff  mov rax, 0x594C21C22970
00007cfd13bd1709  call rax
00007cfd13bd170b  cmp dword ptr [r15+0x318], 0x00
00007cfd13bd1713  jnz 0x00007CFD139FE110
00007cfd13bd1719  jmp 0x00007CFD139FE0A0
00007cfd13bd171e  int3
00007cfd13bd171f  int3
