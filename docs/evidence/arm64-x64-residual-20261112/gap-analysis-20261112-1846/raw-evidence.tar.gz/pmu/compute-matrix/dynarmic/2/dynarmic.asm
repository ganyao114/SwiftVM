00007f8fe1fce69b  nop [rax+rax*1], eax
00007f8fe1fce6a0  vmovaps xmm1, [0x00007F8FE1BFE010]
00007f8fe1fce6a8  movq xmm1, xmm1
00007f8fe1fce6ac  movaps [r15+0x110], xmm1
00007f8fe1fce6b4  vmovaps xmm1, [0x00007F8FE1BFE020]
00007f8fe1fce6bc  movq xmm1, xmm1
00007f8fe1fce6c0  movaps [r15+0x120], xmm1
00007f8fe1fce6c8  mov eax, 0x4204C0
00007f8fe1fce6cd  mov r14, [r13+rax*1]
00007f8fe1fce6d2  movq xmm1, r14
00007f8fe1fce6d7  movaps [r15+0x130], xmm1
00007f8fe1fce6df  vmovaps xmm1, [0x00007F8FE1BFE030]
00007f8fe1fce6e7  vpbroadcastq xmm1, xmm1
00007f8fe1fce6ec  movaps [r15+0x140], xmm1
00007f8fe1fce6f4  mov qword ptr [r15+0x40], 0x02
00007f8fe1fce6fc  vmovaps xmm15, [0x00007F8FE1BFE040]
00007f8fe1fce704  movq xmm15, xmm15
00007f8fe1fce709  movaps [r15+0x150], xmm15
00007f8fe1fce711  mov qword ptr [r15+0x58], 0x420000
00007f8fe1fce719  vmovaps xmm15, [0x00007F8FE1BFE050]
00007f8fe1fce721  vpbroadcastq xmm15, xmm15
00007f8fe1fce726  movaps [r15+0x160], xmm15
00007f8fe1fce72e  mov rax, [r15+0x40]
00007f8fe1fce732  vmovq xmm14, rax
00007f8fe1fce737  vpbroadcastq xmm14, xmm14
00007f8fe1fce73c  movaps [r15+0x170], xmm14
00007f8fe1fce744  mov eax, 0x4204D0
00007f8fe1fce749  movups xmm13, [r13+rax*1]
00007f8fe1fce74f  mov qword ptr [r15+0x40], 0x430518
00007f8fe1fce757  mov qword ptr [r15+0x50], 0x430720
00007f8fe1fce75f  vpmovqd xmm12, xmm13
00007f8fe1fce765  pxor xmm11, xmm11
00007f8fe1fce76a  punpcklqdq xmm12, xmm11
00007f8fe1fce76f  movaps [r15+0x210], xmm12
00007f8fe1fce777  movq xmm12, qword ptr [r15+0x120]
00007f8fe1fce780  movq xmm11, qword ptr [r15+0x130]
00007f8fe1fce789  psubd xmm12, xmm11
00007f8fe1fce78e  movq xmm12, xmm12
00007f8fe1fce793  paddq xmm13, xmm14
00007f8fe1fce798  movaps [r15+0x180], xmm13
00007f8fe1fce7a0  movq xmm14, qword ptr [r15+0x150]
00007f8fe1fce7a9  paddd xmm11, xmm14
00007f8fe1fce7ae  movq xmm11, xmm11
00007f8fe1fce7b3  movq xmm11, xmm11
00007f8fe1fce7b8  movaps [r15+0x130], xmm11
00007f8fe1fce7c0  pmovzxdq xmm12, xmm12
00007f8fe1fce7c6  psllq xmm12, 0x00
00007f8fe1fce7cc  movq xmm14, qword ptr [r15+0x210]
00007f8fe1fce7d5  movq xmm13, qword ptr [r15+0x110]
00007f8fe1fce7de  paddd xmm14, xmm13
00007f8fe1fce7e3  movq xmm14, xmm14
00007f8fe1fce7e8  vcvtuqq2pd xmm12, xmm12
00007f8fe1fce7ee  pmovzxdq xmm14, xmm14
00007f8fe1fce7f4  psllq xmm14, 0x00
00007f8fe1fce7fa  vcvtuqq2pd xmm14, xmm14
00007f8fe1fce800  movaps xmm13, xmm12
00007f8fe1fce804  mulpd xmm13, xmm1
00007f8fe1fce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007f8fe1fce80f  ptest xmm11, xmm11
00007f8fe1fce815  jnz 0x00007F8FE1FCE8FF
00007f8fe1fce81b  movaps [r15+0x220], xmm13
00007f8fe1fce823  mov eax, 0x430720
00007f8fe1fce828  movups [r13+rax*1], xmm13
00007f8fe1fce82e  movaps xmm1, xmm14
00007f8fe1fce832  mulpd xmm1, xmm15
00007f8fe1fce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007f8fe1fce83c  ptest xmm13, xmm13
00007f8fe1fce842  jnz 0x00007F8FE1FCEA4C
00007f8fe1fce848  movaps [r15+0x210], xmm1
00007f8fe1fce850  mov eax, 0x430518
00007f8fe1fce855  movups [r13+rax*1], xmm1
00007f8fe1fce85b  mov qword ptr [r15+0x48], 0x10
00007f8fe1fce863  xor eax, eax
00007f8fe1fce865  mov r14d, 0x10
00007f8fe1fce86b  mov r12d, 0x200
00007f8fe1fce871  cmp r14, r12
00007f8fe1fce874  cmc
00007f8fe1fce875  lahf
00007f8fe1fce876  seto al
00007f8fe1fce879  mov [r15+0x108], eax
00007f8fe1fce880  mov eax, [r15+0x108]
00007f8fe1fce887  sahf
00007f8fe1fce888  jnz 0x00007F8FE1FCE8BA
00007f8fe1fce88a  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fce892  jz 0x00007F8FE1FCEFF0
00007f8fe1fce898  nop [rax+rax*1], ax
00007f8fe1fce8a1  nop [rax+rax*1], eax
00007f8fe1fce8a9  mov eax, 0x4101EC
00007f8fe1fce8ae  mov [r15+0x100], rax
00007f8fe1fce8b5  jmp 0x00007F8FE1DFE110
00007f8fe1fce8ba  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fce8c2  jz 0x00007F8FE1FCEBA0
00007f8fe1fce8c8  nop [rax+rax*1], ax
00007f8fe1fce8d1  nop [rax+rax*1], eax
00007f8fe1fce8d9  mov eax, 0x4101AC
00007f8fe1fce8de  mov [r15+0x100], rax
00007f8fe1fce8e5  jmp 0x00007F8FE1DFE110
00007f8fe1fce8ea  int3
00007f8fe1fce8eb  call 0x00007F8FE1E0DC20
00007f8fe1fce8f0  jmp 0x00007F8FE1FCE6D2
00007f8fe1fce8f5  call 0x00007F8FE1E0C260
00007f8fe1fce8fa  jmp 0x00007F8FE1FCE74F
00007f8fe1fce8ff  sub rsp, 0x08
00007f8fe1fce903  push rax
00007f8fe1fce904  push rcx
00007f8fe1fce905  push rdx
00007f8fe1fce906  push rdi
00007f8fe1fce907  push rsi
00007f8fe1fce908  push r8
00007f8fe1fce90a  push r9
00007f8fe1fce90c  push r10
00007f8fe1fce90e  push r11
00007f8fe1fce910  sub rsp, 0xF0
00007f8fe1fce917  vmovaps [rsp], xmm0
00007f8fe1fce91c  vmovaps [rsp+0x10], xmm1
00007f8fe1fce922  vmovaps [rsp+0x20], xmm2
00007f8fe1fce928  vmovaps [rsp+0x30], xmm3
00007f8fe1fce92e  vmovaps [rsp+0x40], xmm4
00007f8fe1fce934  vmovaps [rsp+0x50], xmm5
00007f8fe1fce93a  vmovaps [rsp+0x60], xmm6
00007f8fe1fce940  vmovaps [rsp+0x70], xmm7
00007f8fe1fce946  vmovaps [rsp+0x80], xmm8
00007f8fe1fce94f  vmovaps [rsp+0x90], xmm9
00007f8fe1fce958  vmovaps [rsp+0xA0], xmm10
00007f8fe1fce961  vmovaps [rsp+0xB0], xmm11
00007f8fe1fce96a  vmovaps [rsp+0xC0], xmm12
00007f8fe1fce973  vmovaps [rsp+0xD0], xmm14
00007f8fe1fce97c  vmovaps [rsp+0xE0], xmm15
00007f8fe1fce985  sub rsp, 0x30
00007f8fe1fce989  movaps [rsp], xmm13
00007f8fe1fce98e  movaps [rsp+0x10], xmm12
00007f8fe1fce994  movaps [rsp+0x20], xmm1
00007f8fe1fce999  lea rdi, [rsp]
00007f8fe1fce99d  mov esi, 0x00
00007f8fe1fce9a2  mov rax, 0x6020BB77F530
00007f8fe1fce9ac  call rax
00007f8fe1fce9ae  movaps xmm13, [rsp]
00007f8fe1fce9b3  add rsp, 0x30
00007f8fe1fce9b7  vmovaps xmm0, [rsp]
00007f8fe1fce9bc  vmovaps xmm1, [rsp+0x10]
00007f8fe1fce9c2  vmovaps xmm2, [rsp+0x20]
00007f8fe1fce9c8  vmovaps xmm3, [rsp+0x30]
00007f8fe1fce9ce  vmovaps xmm4, [rsp+0x40]
00007f8fe1fce9d4  vmovaps xmm5, [rsp+0x50]
00007f8fe1fce9da  vmovaps xmm6, [rsp+0x60]
00007f8fe1fce9e0  vmovaps xmm7, [rsp+0x70]
00007f8fe1fce9e6  vmovaps xmm8, [rsp+0x80]
00007f8fe1fce9ef  vmovaps xmm9, [rsp+0x90]
00007f8fe1fce9f8  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fcea01  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fcea0a  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fcea13  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fcea1c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fcea25  add rsp, 0xF0
00007f8fe1fcea2c  pop r11
00007f8fe1fcea2e  pop r10
00007f8fe1fcea30  pop r9
00007f8fe1fcea32  pop r8
00007f8fe1fcea34  pop rsi
00007f8fe1fcea35  pop rdi
00007f8fe1fcea36  pop rdx
00007f8fe1fcea37  pop rcx
00007f8fe1fcea38  pop rax
00007f8fe1fcea39  add rsp, 0x08
00007f8fe1fcea3d  jmp 0x00007F8FE1FCE81B
00007f8fe1fcea42  call 0x00007F8FE1E0C380
00007f8fe1fcea47  jmp 0x00007F8FE1FCE82E
00007f8fe1fcea4c  sub rsp, 0x08
00007f8fe1fcea50  push rax
00007f8fe1fcea51  push rcx
00007f8fe1fcea52  push rdx
00007f8fe1fcea53  push rdi
00007f8fe1fcea54  push rsi
00007f8fe1fcea55  push r8
00007f8fe1fcea57  push r9
00007f8fe1fcea59  push r10
00007f8fe1fcea5b  push r11
00007f8fe1fcea5d  sub rsp, 0xF0
00007f8fe1fcea64  vmovaps [rsp], xmm0
00007f8fe1fcea69  vmovaps [rsp+0x10], xmm2
00007f8fe1fcea6f  vmovaps [rsp+0x20], xmm3
00007f8fe1fcea75  vmovaps [rsp+0x30], xmm4
00007f8fe1fcea7b  vmovaps [rsp+0x40], xmm5
00007f8fe1fcea81  vmovaps [rsp+0x50], xmm6
00007f8fe1fcea87  vmovaps [rsp+0x60], xmm7
00007f8fe1fcea8d  vmovaps [rsp+0x70], xmm8
00007f8fe1fcea93  vmovaps [rsp+0x80], xmm9
00007f8fe1fcea9c  vmovaps [rsp+0x90], xmm10
00007f8fe1fceaa5  vmovaps [rsp+0xA0], xmm11
00007f8fe1fceaae  vmovaps [rsp+0xB0], xmm12
00007f8fe1fceab7  vmovaps [rsp+0xC0], xmm13
00007f8fe1fceac0  vmovaps [rsp+0xD0], xmm14
00007f8fe1fceac9  vmovaps [rsp+0xE0], xmm15
00007f8fe1fcead2  sub rsp, 0x30
00007f8fe1fcead6  movaps [rsp], xmm1
00007f8fe1fceada  movaps [rsp+0x10], xmm14
00007f8fe1fceae0  movaps [rsp+0x20], xmm15
00007f8fe1fceae6  lea rdi, [rsp]
00007f8fe1fceaea  mov esi, 0x00
00007f8fe1fceaef  mov rax, 0x6020BB77F530
00007f8fe1fceaf9  call rax
00007f8fe1fceafb  movaps xmm1, [rsp]
00007f8fe1fceaff  add rsp, 0x30
00007f8fe1fceb03  vmovaps xmm0, [rsp]
00007f8fe1fceb08  vmovaps xmm2, [rsp+0x10]
00007f8fe1fceb0e  vmovaps xmm3, [rsp+0x20]
00007f8fe1fceb14  vmovaps xmm4, [rsp+0x30]
00007f8fe1fceb1a  vmovaps xmm5, [rsp+0x40]
00007f8fe1fceb20  vmovaps xmm6, [rsp+0x50]
00007f8fe1fceb26  vmovaps xmm7, [rsp+0x60]
00007f8fe1fceb2c  vmovaps xmm8, [rsp+0x70]
00007f8fe1fceb32  vmovaps xmm9, [rsp+0x80]
00007f8fe1fceb3b  vmovaps xmm10, [rsp+0x90]
00007f8fe1fceb44  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fceb4d  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fceb56  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fceb5f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fceb68  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fceb71  add rsp, 0xF0
00007f8fe1fceb78  pop r11
00007f8fe1fceb7a  pop r10
00007f8fe1fceb7c  pop r9
00007f8fe1fceb7e  pop r8
00007f8fe1fceb80  pop rsi
00007f8fe1fceb81  pop rdi
00007f8fe1fceb82  pop rdx
00007f8fe1fceb83  pop rcx
00007f8fe1fceb84  pop rax
00007f8fe1fceb85  add rsp, 0x08
00007f8fe1fceb89  jmp 0x00007F8FE1FCE848
00007f8fe1fceb8e  call 0x00007F8FE1DFF540
00007f8fe1fceb93  jmp 0x00007F8FE1FCE85B
00007f8fe1fceb98  int3
00007f8fe1fceb99  nop [rax], eax
00007f8fe1fceba0  movaps xmm1, [r15+0x180]
00007f8fe1fceba8  vpmovqd xmm15, xmm1
00007f8fe1fcebae  pxor xmm14, xmm14
00007f8fe1fcebb3  punpcklqdq xmm15, xmm14
00007f8fe1fcebb8  movaps [r15+0x210], xmm15
00007f8fe1fcebc0  movq xmm15, qword ptr [r15+0x120]
00007f8fe1fcebc9  movq xmm14, qword ptr [r15+0x130]
00007f8fe1fcebd2  psubd xmm15, xmm14
00007f8fe1fcebd7  movq xmm15, xmm15
00007f8fe1fcebdc  movaps xmm13, [r15+0x170]
00007f8fe1fcebe4  paddq xmm1, xmm13
00007f8fe1fcebe9  movaps [r15+0x180], xmm1
00007f8fe1fcebf1  movq xmm1, qword ptr [r15+0x150]
00007f8fe1fcebfa  paddd xmm14, xmm1
00007f8fe1fcebff  movq xmm14, xmm14
00007f8fe1fcec04  movq xmm14, xmm14
00007f8fe1fcec09  movaps [r15+0x130], xmm14
00007f8fe1fcec11  pmovzxdq xmm15, xmm15
00007f8fe1fcec17  psllq xmm15, 0x00
00007f8fe1fcec1d  movq xmm1, qword ptr [r15+0x210]
00007f8fe1fcec26  movq xmm14, qword ptr [r15+0x110]
00007f8fe1fcec2f  paddd xmm1, xmm14
00007f8fe1fcec34  movq xmm1, xmm1
00007f8fe1fcec38  vcvtuqq2pd xmm15, xmm15
00007f8fe1fcec3e  pmovzxdq xmm1, xmm1
00007f8fe1fcec43  psllq xmm1, 0x00
00007f8fe1fcec48  vcvtuqq2pd xmm1, xmm1
00007f8fe1fcec4e  movaps xmm14, [r15+0x140]
00007f8fe1fcec56  movaps xmm13, xmm15
00007f8fe1fcec5a  mulpd xmm13, xmm14
00007f8fe1fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f8fe1fcec65  ptest xmm12, xmm12
00007f8fe1fcec6b  jnz 0x00007F8FE1FCED4E
00007f8fe1fcec71  movaps [r15+0x220], xmm13
00007f8fe1fcec79  mov rax, [r15+0x48]
00007f8fe1fcec7d  mov r14, [r15+0x50]
00007f8fe1fcec81  lea r12, [r14+rax*1]
00007f8fe1fcec85  movups [r13+r12*1], xmm13
00007f8fe1fcec8b  movaps xmm15, [r15+0x160]
00007f8fe1fcec93  movaps xmm14, xmm1
00007f8fe1fcec97  mulpd xmm14, xmm15
00007f8fe1fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007f8fe1fceca2  ptest xmm13, xmm13
00007f8fe1fceca8  jnz 0x00007F8FE1FCEE9C
00007f8fe1fcecae  movaps [r15+0x210], xmm14
00007f8fe1fcecb6  mov r14, [r15+0x40]
00007f8fe1fcecba  lea r12, [r14+rax*1]
00007f8fe1fcecbe  movups [r13+r12*1], xmm14
00007f8fe1fcecc4  lea r14, [rax+0x10]
00007f8fe1fcecc8  mov [r15+0x48], r14
00007f8fe1fceccc  xor eax, eax
00007f8fe1fcecce  mov r12d, 0x200
00007f8fe1fcecd4  cmp r14, r12
00007f8fe1fcecd7  cmc
00007f8fe1fcecd8  lahf
00007f8fe1fcecd9  seto al
00007f8fe1fcecdc  mov [r15+0x108], eax
00007f8fe1fcece3  mov eax, [r15+0x108]
00007f8fe1fcecea  sahf
00007f8fe1fceceb  jnz 0x00007F8FE1FCED1D
00007f8fe1fceced  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fcecf5  jz 0x00007F8FE1FCEFF0
00007f8fe1fcecfb  nop [rax+rax*1], ax
00007f8fe1fced04  nop [rax+rax*1], eax
00007f8fe1fced0c  mov eax, 0x4101EC
00007f8fe1fced11  mov [r15+0x100], rax
00007f8fe1fced18  jmp 0x00007F8FE1DFE110
00007f8fe1fced1d  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fced25  jz 0x00007F8FE1FCEBA0
00007f8fe1fced2b  nop [rax+rax*1], ax
00007f8fe1fced34  nop [rax+rax*1], eax
00007f8fe1fced3c  mov eax, 0x4101AC
00007f8fe1fced41  mov [r15+0x100], rax
00007f8fe1fced48  jmp 0x00007F8FE1DFE110
00007f8fe1fced4d  int3
00007f8fe1fced4e  sub rsp, 0x08
00007f8fe1fced52  push rax
00007f8fe1fced53  push rcx
00007f8fe1fced54  push rdx
00007f8fe1fced55  push rdi
00007f8fe1fced56  push rsi
00007f8fe1fced57  push r8
00007f8fe1fced59  push r9
00007f8fe1fced5b  push r10
00007f8fe1fced5d  push r11
00007f8fe1fced5f  sub rsp, 0xF0
00007f8fe1fced66  vmovaps [rsp], xmm0
00007f8fe1fced6b  vmovaps [rsp+0x10], xmm1
00007f8fe1fced71  vmovaps [rsp+0x20], xmm2
00007f8fe1fced77  vmovaps [rsp+0x30], xmm3
00007f8fe1fced7d  vmovaps [rsp+0x40], xmm4
00007f8fe1fced83  vmovaps [rsp+0x50], xmm5
00007f8fe1fced89  vmovaps [rsp+0x60], xmm6
00007f8fe1fced8f  vmovaps [rsp+0x70], xmm7
00007f8fe1fced95  vmovaps [rsp+0x80], xmm8
00007f8fe1fced9e  vmovaps [rsp+0x90], xmm9
00007f8fe1fceda7  vmovaps [rsp+0xA0], xmm10
00007f8fe1fcedb0  vmovaps [rsp+0xB0], xmm11
00007f8fe1fcedb9  vmovaps [rsp+0xC0], xmm12
00007f8fe1fcedc2  vmovaps [rsp+0xD0], xmm14
00007f8fe1fcedcb  vmovaps [rsp+0xE0], xmm15
00007f8fe1fcedd4  sub rsp, 0x30
00007f8fe1fcedd8  movaps [rsp], xmm13
00007f8fe1fceddd  movaps [rsp+0x10], xmm15
00007f8fe1fcede3  movaps [rsp+0x20], xmm14
00007f8fe1fcede9  lea rdi, [rsp]
00007f8fe1fceded  mov esi, 0x00
00007f8fe1fcedf2  mov rax, 0x6020BB77F530
00007f8fe1fcedfc  call rax
00007f8fe1fcedfe  movaps xmm13, [rsp]
00007f8fe1fcee03  add rsp, 0x30
00007f8fe1fcee07  vmovaps xmm0, [rsp]
00007f8fe1fcee0c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fcee12  vmovaps xmm2, [rsp+0x20]
00007f8fe1fcee18  vmovaps xmm3, [rsp+0x30]
00007f8fe1fcee1e  vmovaps xmm4, [rsp+0x40]
00007f8fe1fcee24  vmovaps xmm5, [rsp+0x50]
00007f8fe1fcee2a  vmovaps xmm6, [rsp+0x60]
00007f8fe1fcee30  vmovaps xmm7, [rsp+0x70]
00007f8fe1fcee36  vmovaps xmm8, [rsp+0x80]
00007f8fe1fcee3f  vmovaps xmm9, [rsp+0x90]
00007f8fe1fcee48  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fcee51  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fcee5a  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fcee63  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fcee6c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fcee75  add rsp, 0xF0
00007f8fe1fcee7c  pop r11
00007f8fe1fcee7e  pop r10
00007f8fe1fcee80  pop r9
00007f8fe1fcee82  pop r8
00007f8fe1fcee84  pop rsi
00007f8fe1fcee85  pop rdi
00007f8fe1fcee86  pop rdx
00007f8fe1fcee87  pop rcx
00007f8fe1fcee88  pop rax
00007f8fe1fcee89  add rsp, 0x08
00007f8fe1fcee8d  jmp 0x00007F8FE1FCEC71
00007f8fe1fcee92  call 0x00007F8FE1EC2240
00007f8fe1fcee97  jmp 0x00007F8FE1FCEC8B
00007f8fe1fcee9c  sub rsp, 0x08
00007f8fe1fceea0  push rax
00007f8fe1fceea1  push rcx
00007f8fe1fceea2  push rdx
00007f8fe1fceea3  push rdi
00007f8fe1fceea4  push rsi
00007f8fe1fceea5  push r8
00007f8fe1fceea7  push r9
00007f8fe1fceea9  push r10
00007f8fe1fceeab  push r11
00007f8fe1fceead  sub rsp, 0xF0
00007f8fe1fceeb4  vmovaps [rsp], xmm0
00007f8fe1fceeb9  vmovaps [rsp+0x10], xmm1
00007f8fe1fceebf  vmovaps [rsp+0x20], xmm2
00007f8fe1fceec5  vmovaps [rsp+0x30], xmm3
00007f8fe1fceecb  vmovaps [rsp+0x40], xmm4
00007f8fe1fceed1  vmovaps [rsp+0x50], xmm5
00007f8fe1fceed7  vmovaps [rsp+0x60], xmm6
00007f8fe1fceedd  vmovaps [rsp+0x70], xmm7
00007f8fe1fceee3  vmovaps [rsp+0x80], xmm8
00007f8fe1fceeec  vmovaps [rsp+0x90], xmm9
00007f8fe1fceef5  vmovaps [rsp+0xA0], xmm10
00007f8fe1fceefe  vmovaps [rsp+0xB0], xmm11
00007f8fe1fcef07  vmovaps [rsp+0xC0], xmm12
00007f8fe1fcef10  vmovaps [rsp+0xD0], xmm13
00007f8fe1fcef19  vmovaps [rsp+0xE0], xmm15
00007f8fe1fcef22  sub rsp, 0x30
00007f8fe1fcef26  movaps [rsp], xmm14
00007f8fe1fcef2b  movaps [rsp+0x10], xmm1
00007f8fe1fcef30  movaps [rsp+0x20], xmm15
00007f8fe1fcef36  lea rdi, [rsp]
00007f8fe1fcef3a  mov esi, 0x00
00007f8fe1fcef3f  mov rax, 0x6020BB77F530
00007f8fe1fcef49  call rax
00007f8fe1fcef4b  movaps xmm14, [rsp]
00007f8fe1fcef50  add rsp, 0x30
00007f8fe1fcef54  vmovaps xmm0, [rsp]
00007f8fe1fcef59  vmovaps xmm1, [rsp+0x10]
00007f8fe1fcef5f  vmovaps xmm2, [rsp+0x20]
00007f8fe1fcef65  vmovaps xmm3, [rsp+0x30]
00007f8fe1fcef6b  vmovaps xmm4, [rsp+0x40]
00007f8fe1fcef71  vmovaps xmm5, [rsp+0x50]
00007f8fe1fcef77  vmovaps xmm6, [rsp+0x60]
00007f8fe1fcef7d  vmovaps xmm7, [rsp+0x70]
00007f8fe1fcef83  vmovaps xmm8, [rsp+0x80]
00007f8fe1fcef8c  vmovaps xmm9, [rsp+0x90]
00007f8fe1fcef95  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fcef9e  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fcefa7  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fcefb0  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fcefb9  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fcefc2  add rsp, 0xF0
00007f8fe1fcefc9  pop r11
00007f8fe1fcefcb  pop r10
00007f8fe1fcefcd  pop r9
00007f8fe1fcefcf  pop r8
00007f8fe1fcefd1  pop rsi
00007f8fe1fcefd2  pop rdi
00007f8fe1fcefd3  pop rdx
00007f8fe1fcefd4  pop rcx
00007f8fe1fcefd5  pop rax
00007f8fe1fcefd6  add rsp, 0x08
00007f8fe1fcefda  jmp 0x00007F8FE1FCECAE
00007f8fe1fcefdf  call 0x00007F8FE1EC34C0
00007f8fe1fcefe4  jmp 0x00007F8FE1FCECC4
00007f8fe1fcefe9  int3
00007f8fe1fcefea  nop [rax+rax*1], ax
00007f8fe1fceff0  mov rax, [r15+0xF8]
00007f8fe1fceff7  lea r14, [rax-0x150]
00007f8fe1fceffe  mov [r15+0xF8], r14
00007f8fe1fcf005  mov rax, [r15+0x50]
00007f8fe1fcf009  lea r12, [rax+0x80]
00007f8fe1fcf010  movups xmm1, [r13+r12*1]
00007f8fe1fcf016  lea r12, [rax+0x90]
00007f8fe1fcf01d  movups xmm15, [r13+r12*1]
00007f8fe1fcf023  mov qword ptr [r15+0x48], 0x00
00007f8fe1fcf02b  lea r12, [rax+0x40]
00007f8fe1fcf02f  movups xmm14, [r13+r12*1]
00007f8fe1fcf035  lea r12, [rax+0x50]
00007f8fe1fcf039  movups xmm13, [r13+r12*1]
00007f8fe1fcf03f  lea r12, [r14+0x120]
00007f8fe1fcf046  movq xmm12, qword ptr [r15+0x1C0]
00007f8fe1fcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007f8fe1fcf058  movq r11, xmm12
00007f8fe1fcf05d  movq r10, xmm11
00007f8fe1fcf062  mov [r13+r12*1], r11
00007f8fe1fcf067  lea r12, [r14+0x128]
00007f8fe1fcf06e  mov [r13+r12*1], r10
00007f8fe1fcf073  vxorps xmm12, xmm12, xmm12
00007f8fe1fcf078  vpbroadcastq xmm12, xmm12
00007f8fe1fcf07d  lea r12, [r14+0x100]
00007f8fe1fcf084  movq xmm11, qword ptr [r15+0x200]
00007f8fe1fcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007f8fe1fcf096  movq r11, xmm11
00007f8fe1fcf09b  movq r10, xmm10
00007f8fe1fcf0a0  mov [r13+r12*1], r11
00007f8fe1fcf0a5  lea r12, [r14+0x108]
00007f8fe1fcf0ac  mov [r13+r12*1], r10
00007f8fe1fcf0b1  lea r12, [r14+0xE0]
00007f8fe1fcf0b8  movups [r13+r12*1], xmm15
00007f8fe1fcf0be  lea r12, [r14+0xF0]
00007f8fe1fcf0c5  movups [r13+r12*1], xmm1
00007f8fe1fcf0cb  lea r12, [rax+0xC0]
00007f8fe1fcf0d2  movups xmm1, [r13+r12*1]
00007f8fe1fcf0d8  lea r12, [rax+0xD0]
00007f8fe1fcf0df  movups xmm15, [r13+r12*1]
00007f8fe1fcf0e5  lea r12, [r14+0x110]
00007f8fe1fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007f8fe1fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007f8fe1fcf0fe  movq r11, xmm11
00007f8fe1fcf103  movq r10, xmm10
00007f8fe1fcf108  mov [r13+r12*1], r11
00007f8fe1fcf10d  lea r12, [r14+0x118]
00007f8fe1fcf114  mov [r13+r12*1], r10
00007f8fe1fcf119  movups xmm11, [r13+rax*1]
00007f8fe1fcf11f  lea r12, [rax+0x10]
00007f8fe1fcf123  movups xmm10, [r13+r12*1]
00007f8fe1fcf129  lea r12, [r14+0x130]
00007f8fe1fcf130  movq xmm9, qword ptr [r15+0x1A0]
00007f8fe1fcf139  movq xmm8, qword ptr [r15+0x190]
00007f8fe1fcf142  movq r11, xmm9
00007f8fe1fcf147  movq r10, xmm8
00007f8fe1fcf14c  mov [r13+r12*1], r11
00007f8fe1fcf151  lea r12, [r14+0x138]
00007f8fe1fcf158  mov [r13+r12*1], r10
00007f8fe1fcf15d  lea r12, [rax+0x140]
00007f8fe1fcf164  movups xmm9, [r13+r12*1]
00007f8fe1fcf16a  lea r12, [rax+0x150]
00007f8fe1fcf171  movups xmm8, [r13+r12*1]
00007f8fe1fcf177  lea r12, [r14+0xC0]
00007f8fe1fcf17e  movups [r13+r12*1], xmm15
00007f8fe1fcf184  lea r12, [r14+0xD0]
00007f8fe1fcf18b  movups [r13+r12*1], xmm1
00007f8fe1fcf191  lea r12, [rax+0x100]
00007f8fe1fcf198  movups xmm1, [r13+r12*1]
00007f8fe1fcf19e  lea r12, [rax+0x110]
00007f8fe1fcf1a5  movups xmm15, [r13+r12*1]
00007f8fe1fcf1ab  lea r12, [r14+0x140]
00007f8fe1fcf1b2  mov r11, [r15+0xE8]
00007f8fe1fcf1b9  mov [r13+r12*1], r11
00007f8fe1fcf1be  lea r12, [rax+0x180]
00007f8fe1fcf1c5  movups xmm7, [r13+r12*1]
00007f8fe1fcf1cb  lea r12, [rax+0x190]
00007f8fe1fcf1d2  movups xmm6, [r13+r12*1]
00007f8fe1fcf1d8  lea r12, [rax+0x1C0]
00007f8fe1fcf1df  movups xmm5, [r13+r12*1]
00007f8fe1fcf1e5  lea r12, [rax+0x1D0]
00007f8fe1fcf1ec  movups xmm4, [r13+r12*1]
00007f8fe1fcf1f2  lea r12, [r14+0x20]
00007f8fe1fcf1f6  movups [r13+r12*1], xmm1
00007f8fe1fcf1fc  lea r12, [r14+0x30]
00007f8fe1fcf200  movups [r13+r12*1], xmm13
00007f8fe1fcf206  lea r12, [rax+0x60]
00007f8fe1fcf20a  movups xmm1, [r13+r12*1]
00007f8fe1fcf210  lea r12, [rax+0x70]
00007f8fe1fcf214  movups xmm13, [r13+r12*1]
00007f8fe1fcf21a  lea r12, [rax+0x20]
00007f8fe1fcf21e  movups xmm3, [r13+r12*1]
00007f8fe1fcf224  lea r12, [rax+0x30]
00007f8fe1fcf228  movups xmm2, [r13+r12*1]
00007f8fe1fcf22e  movaps [r15+0x1F0], xmm2
00007f8fe1fcf236  lea r12, [r14+0x60]
00007f8fe1fcf23a  movups [r13+r12*1], xmm11
00007f8fe1fcf240  lea r12, [r14+0x70]
00007f8fe1fcf244  movups [r13+r12*1], xmm5
00007f8fe1fcf24a  lea r12, [rax+0xE0]
00007f8fe1fcf251  movups xmm11, [r13+r12*1]
00007f8fe1fcf257  lea r12, [rax+0xF0]
00007f8fe1fcf25e  movups xmm5, [r13+r12*1]
00007f8fe1fcf264  lea r12, [r14+0xA0]
00007f8fe1fcf26b  movups [r13+r12*1], xmm13
00007f8fe1fcf271  lea r12, [r14+0xB0]
00007f8fe1fcf278  movups [r13+r12*1], xmm1
00007f8fe1fcf27e  lea r12, [rax+0xA0]
00007f8fe1fcf285  movups xmm1, [r13+r12*1]
00007f8fe1fcf28b  lea r12, [rax+0xB0]
00007f8fe1fcf292  movups xmm13, [r13+r12*1]
00007f8fe1fcf298  lea r12, [rax+0x120]
00007f8fe1fcf29f  vmovaps [rsp+0x10], xmm1
00007f8fe1fcf2a5  movups xmm1, [r13+r12*1]
00007f8fe1fcf2ab  lea r12, [rax+0x130]
00007f8fe1fcf2b2  vmovaps [rsp+0x20], xmm1
00007f8fe1fcf2b8  movups xmm1, [r13+r12*1]
00007f8fe1fcf2be  lea r12, [rax+0x160]
00007f8fe1fcf2c5  vmovaps [rsp+0x30], xmm1
00007f8fe1fcf2cb  movups xmm1, [r13+r12*1]
00007f8fe1fcf2d1  lea r12, [rax+0x170]
00007f8fe1fcf2d8  vmovaps [rsp+0x40], xmm1
00007f8fe1fcf2de  movups xmm1, [r13+r12*1]
00007f8fe1fcf2e4  movaps [r15+0x2B0], xmm1
00007f8fe1fcf2ec  lea r12, [r14+0x80]
00007f8fe1fcf2f3  movups [r13+r12*1], xmm13
00007f8fe1fcf2f9  lea r12, [r14+0x90]
00007f8fe1fcf300  vmovaps xmm13, [rsp+0x10]
00007f8fe1fcf306  movups [r13+r12*1], xmm13
00007f8fe1fcf30c  lea r12, [rax+0x1A0]
00007f8fe1fcf313  movups xmm13, [r13+r12*1]
00007f8fe1fcf319  lea r12, [rax+0x1B0]
00007f8fe1fcf320  vmovaps [rsp+0x10], xmm1
00007f8fe1fcf326  movups xmm1, [r13+r12*1]
00007f8fe1fcf32c  movaps [r15+0x290], xmm13
00007f8fe1fcf334  movaps [r15+0x1E0], xmm1
00007f8fe1fcf33c  lea r12, [rax+0x1E0]
00007f8fe1fcf343  vmovaps [rsp+0x50], xmm1
00007f8fe1fcf349  movups xmm1, [r13+r12*1]
00007f8fe1fcf34f  lea r12, [rax+0x1F0]
00007f8fe1fcf356  vmovaps [rsp+0x60], xmm1
00007f8fe1fcf35c  movups xmm1, [r13+r12*1]
00007f8fe1fcf362  mov qword ptr [r15+0x50], 0x430920
00007f8fe1fcf36a  lea rax, [r14+0x40]
00007f8fe1fcf36e  vmovaps [rsp+0x70], xmm1
00007f8fe1fcf374  vmovaps xmm1, [rsp+0x40]
00007f8fe1fcf37a  movups [r13+rax*1], xmm1
00007f8fe1fcf380  lea rax, [r14+0x50]
00007f8fe1fcf384  movups [r13+rax*1], xmm10
00007f8fe1fcf38a  vmovaps xmm1, [rsp+0x70]
00007f8fe1fcf390  movups [r13+r14*1], xmm1
00007f8fe1fcf396  lea rax, [r14+0x10]
00007f8fe1fcf39a  vmovaps xmm1, [rsp+0x60]
00007f8fe1fcf3a0  movups [r13+rax*1], xmm1
00007f8fe1fcf3a6  mov rax, [r15+0x40]
00007f8fe1fcf3aa  vmovaps [rsp+0x40], xmm3
00007f8fe1fcf3b0  vmovaps xmm1, [rsp+0x40]
00007f8fe1fcf3b6  por xmm3, xmm1
00007f8fe1fcf3ba  vmovaps [rsp+0x40], xmm6
00007f8fe1fcf3c0  vmovaps xmm10, [rsp+0x40]
00007f8fe1fcf3c6  por xmm6, xmm10
00007f8fe1fcf3cb  lea r12, [rax+0x30]
00007f8fe1fcf3cf  mov r11, [r13+r12*1]
00007f8fe1fcf3d4  lea r12, [rax+0x38]
00007f8fe1fcf3d8  mov r10, [r13+r12*1]
00007f8fe1fcf3dd  movq xmm10, r11
00007f8fe1fcf3e2  vmovaps [rsp+0x40], xmm1
00007f8fe1fcf3e8  movq xmm1, r10
00007f8fe1fcf3ed  movq xmm10, xmm10
00007f8fe1fcf3f2  vmovaps [rsp+0x60], xmm10
00007f8fe1fcf3f8  movq xmm10, xmm10
00007f8fe1fcf3fd  movaps [r15+0x130], xmm10
00007f8fe1fcf405  movq xmm1, xmm1
00007f8fe1fcf409  vmovaps [rsp+0x70], xmm1
00007f8fe1fcf40f  movq xmm1, xmm1
00007f8fe1fcf413  movaps [r15+0x280], xmm1
00007f8fe1fcf41b  vmovaps [rsp+0x80], xmm9
00007f8fe1fcf424  vmovaps xmm1, [rsp+0x80]
00007f8fe1fcf42d  por xmm9, xmm1
00007f8fe1fcf432  lea r12, [rax+0x20]
00007f8fe1fcf436  mov r11, [r13+r12*1]
00007f8fe1fcf43b  lea r12, [rax+0x28]
00007f8fe1fcf43f  mov r10, [r13+r12*1]
00007f8fe1fcf444  movq xmm1, r11
00007f8fe1fcf449  movq xmm10, r10
00007f8fe1fcf44e  movq xmm1, xmm1
00007f8fe1fcf452  vmovaps [rsp+0x80], xmm1
00007f8fe1fcf45b  movq xmm1, xmm1
00007f8fe1fcf45f  movaps [r15+0x150], xmm1
00007f8fe1fcf467  movq xmm10, xmm10
00007f8fe1fcf46c  vmovaps [rsp+0x90], xmm10
00007f8fe1fcf475  movq xmm10, xmm10
00007f8fe1fcf47a  movaps [r15+0x140], xmm10
00007f8fe1fcf482  lea r12, [rax+0x10]
00007f8fe1fcf486  mov r11, [r13+r12*1]
00007f8fe1fcf48b  lea r12, [rax+0x18]
00007f8fe1fcf48f  mov r10, [r13+r12*1]
00007f8fe1fcf494  movq xmm1, r11
00007f8fe1fcf499  movq xmm10, r10
00007f8fe1fcf49e  movq xmm1, xmm1
00007f8fe1fcf4a2  vmovaps [rsp+0xA0], xmm1
00007f8fe1fcf4ab  movq xmm1, xmm1
00007f8fe1fcf4af  movaps [r15+0x170], xmm1
00007f8fe1fcf4b7  movq xmm10, xmm10
00007f8fe1fcf4bc  vmovaps [rsp+0xB0], xmm10
00007f8fe1fcf4c5  movq xmm10, xmm10
00007f8fe1fcf4ca  movaps [r15+0x160], xmm10
00007f8fe1fcf4d2  mov r12, [r13+rax*1]
00007f8fe1fcf4d7  vmovq xmm1, r12
00007f8fe1fcf4dc  vpbroadcastq xmm1, xmm1
00007f8fe1fcf4e1  lea r12, [rax+0x08]
00007f8fe1fcf4e5  mov rax, [r13+r12*1]
00007f8fe1fcf4ea  movq xmm10, rax
00007f8fe1fcf4ef  movaps [r15+0x230], xmm10
00007f8fe1fcf4f7  lea rax, [r14+0x50]
00007f8fe1fcf4fb  movups xmm10, [r13+rax*1]
00007f8fe1fcf501  lea rax, [r14+0x60]
00007f8fe1fcf505  vmovaps [rsp+0xC0], xmm1
00007f8fe1fcf50e  movups xmm1, [r13+rax*1]
00007f8fe1fcf514  lea rax, [r14+0x30]
00007f8fe1fcf518  vmovaps [rsp+0xD0], xmm1
00007f8fe1fcf521  movups xmm1, [r13+rax*1]
00007f8fe1fcf527  mov qword ptr [r15+0x60], 0x430920
00007f8fe1fcf52f  mov qword ptr [r15+0x58], 0x40
00007f8fe1fcf537  vmovaps [rsp+0xE0], xmm1
00007f8fe1fcf540  vmovaps [rsp+0xF0], xmm15
00007f8fe1fcf549  vmovaps xmm15, [rsp+0xC0]
00007f8fe1fcf552  vmovaps [rsp+0xC0], xmm14
00007f8fe1fcf55b  vmovaps xmm14, [rsp+0x40]
00007f8fe1fcf561  vmovaps [rsp+0x40], xmm13
00007f8fe1fcf567  movaps xmm1, xmm15
00007f8fe1fcf56b  mulpd xmm1, xmm14
00007f8fe1fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007f8fe1fcf575  ptest xmm13, xmm13
00007f8fe1fcf57b  jnz 0x00007F8FE1FD0682
00007f8fe1fcf581  movq xmm14, qword ptr [r15+0x230]
00007f8fe1fcf58a  vmovaps [rsp+0x100], xmm14
00007f8fe1fcf593  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fcf599  vmovaps [rsp+0x110], xmm1
00007f8fe1fcf5a2  vmovaps xmm1, [rsp+0xE0]
00007f8fe1fcf5ab  vmovaps [rsp+0xE0], xmm15
00007f8fe1fcf5b4  movaps xmm13, xmm1
00007f8fe1fcf5b8  mulpd xmm13, xmm14
00007f8fe1fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007f8fe1fcf5c3  ptest xmm15, xmm15
00007f8fe1fcf5c9  jnz 0x00007F8FE1FD07C4
00007f8fe1fcf5cf  vxorps xmm1, xmm1, xmm1
00007f8fe1fcf5d3  vpbroadcastq xmm1, xmm1
00007f8fe1fcf5d8  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fcf5e1  vmovaps [rsp+0xE0], xmm1
00007f8fe1fcf5ea  vmovaps xmm1, [rsp+0xD0]
00007f8fe1fcf5f3  vmovaps [rsp+0xD0], xmm13
00007f8fe1fcf5fc  movaps xmm15, xmm14
00007f8fe1fcf600  mulpd xmm15, xmm1
00007f8fe1fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007f8fe1fcf60b  ptest xmm13, xmm13
00007f8fe1fcf611  jnz 0x00007F8FE1FD0907
00007f8fe1fcf617  movaps xmm1, xmm14
00007f8fe1fcf61b  mulpd xmm1, xmm10
00007f8fe1fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007f8fe1fcf625  ptest xmm13, xmm13
00007f8fe1fcf62b  jnz 0x00007F8FE1FD0A4A
00007f8fe1fcf631  movaps xmm13, xmm14
00007f8fe1fcf635  mulpd xmm13, xmm2
00007f8fe1fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007f8fe1fcf640  ptest xmm10, xmm10
00007f8fe1fcf646  jnz 0x00007F8FE1FD0B8C
00007f8fe1fcf64c  vmovaps [rsp+0x120], xmm7
00007f8fe1fcf655  vmovaps xmm14, [rsp+0x120]
00007f8fe1fcf65e  por xmm7, xmm14
00007f8fe1fcf663  vmovaps xmm14, [rsp+0xC0]
00007f8fe1fcf66c  vmovaps xmm10, [rsp+0xC0]
00007f8fe1fcf675  por xmm14, xmm10
00007f8fe1fcf67a  vmovaps xmm2, [rsp+0x100]
00007f8fe1fcf683  vpermilpd xmm2, xmm2, 0x00
00007f8fe1fcf689  vmovaps [rsp+0xC0], xmm1
00007f8fe1fcf692  vmovaps [rsp+0x120], xmm15
00007f8fe1fcf69b  movaps xmm1, xmm10
00007f8fe1fcf69f  mulpd xmm1, xmm2
00007f8fe1fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007f8fe1fcf6a8  ptest xmm15, xmm15
00007f8fe1fcf6ae  jnz 0x00007F8FE1FD0CCF
00007f8fe1fcf6b4  xor eax, eax
00007f8fe1fcf6b6  mov r12d, 0x40
00007f8fe1fcf6bc  mov r11d, 0x200
00007f8fe1fcf6c2  cmp r12, r11
00007f8fe1fcf6c5  cmc
00007f8fe1fcf6c6  lahf
00007f8fe1fcf6c7  seto al
00007f8fe1fcf6ca  mov [r15+0x108], eax
00007f8fe1fcf6d1  vmovaps xmm10, [rsp+0x110]
00007f8fe1fcf6da  vmovaps xmm2, [rsp+0xE0]
00007f8fe1fcf6e3  vmovaps [rsp+0xE0], xmm1
00007f8fe1fcf6ec  movaps xmm15, xmm10
00007f8fe1fcf6f0  addpd xmm15, xmm2
00007f8fe1fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f8fe1fcf6fb  ptest xmm1, xmm1
00007f8fe1fcf700  jnz 0x00007F8FE1FD0E10
00007f8fe1fcf706  vmovaps xmm10, [rsp+0x120]
00007f8fe1fcf70f  vmovaps [rsp+0x110], xmm15
00007f8fe1fcf718  movaps xmm1, xmm10
00007f8fe1fcf71c  addpd xmm1, xmm12
00007f8fe1fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007f8fe1fcf726  ptest xmm15, xmm15
00007f8fe1fcf72c  jnz 0x00007F8FE1FD0F53
00007f8fe1fcf732  vmovaps xmm10, [rsp+0xC0]
00007f8fe1fcf73b  vmovaps [rsp+0xC0], xmm1
00007f8fe1fcf744  movaps xmm15, xmm10
00007f8fe1fcf748  addpd xmm15, xmm12
00007f8fe1fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007f8fe1fcf753  ptest xmm1, xmm1
00007f8fe1fcf758  jnz 0x00007F8FE1FD1095
00007f8fe1fcf75e  vmovaps xmm1, [rsp+0x30]
00007f8fe1fcf764  vmovaps xmm12, [rsp+0x30]
00007f8fe1fcf76a  por xmm1, xmm12
00007f8fe1fcf76f  vmovaps xmm12, [rsp+0x20]
00007f8fe1fcf775  vmovaps xmm10, [rsp+0x20]
00007f8fe1fcf77b  por xmm12, xmm10
00007f8fe1fcf780  vmovaps [rsp+0x20], xmm5
00007f8fe1fcf786  vmovaps xmm10, [rsp+0x20]
00007f8fe1fcf78c  por xmm5, xmm10
00007f8fe1fcf791  vmovaps [rsp+0x20], xmm11
00007f8fe1fcf797  vmovaps xmm10, [rsp+0x20]
00007f8fe1fcf79d  por xmm11, xmm10
00007f8fe1fcf7a2  vmovaps [rsp+0x20], xmm4
00007f8fe1fcf7a8  vmovaps xmm10, [rsp+0x20]
00007f8fe1fcf7ae  por xmm4, xmm10
00007f8fe1fcf7b3  vmovaps [rsp+0x20], xmm8
00007f8fe1fcf7b9  vmovaps xmm10, [rsp+0x20]
00007f8fe1fcf7bf  por xmm8, xmm10
00007f8fe1fcf7c4  vmovaps xmm10, [rsp+0xF0]
00007f8fe1fcf7cd  vmovaps [rsp+0x20], xmm1
00007f8fe1fcf7d3  vmovaps xmm1, [rsp+0xF0]
00007f8fe1fcf7dc  por xmm10, xmm1
00007f8fe1fcf7e1  lea rax, [r14+0xA0]
00007f8fe1fcf7e8  movups xmm1, [r13+rax*1]
00007f8fe1fcf7ee  lea rax, [r14+0xB0]
00007f8fe1fcf7f5  vmovaps [rsp+0x30], xmm1
00007f8fe1fcf7fb  movups xmm1, [r13+rax*1]
00007f8fe1fcf801  vmovaps [rsp+0xF0], xmm1
00007f8fe1fcf80a  vmovaps [rsp+0x120], xmm15
00007f8fe1fcf813  movaps xmm1, xmm13
00007f8fe1fcf817  addpd xmm1, xmm2
00007f8fe1fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f8fe1fcf820  ptest xmm15, xmm15
00007f8fe1fcf826  jnz 0x00007F8FE1FD11ED
00007f8fe1fcf82c  lea rax, [r14+0xF0]
00007f8fe1fcf833  movups xmm15, [r13+rax*1]
00007f8fe1fcf839  vmovaps xmm2, [rsp+0xC0]
00007f8fe1fcf842  vmovaps [rsp+0xC0], xmm1
00007f8fe1fcf84b  vmovaps xmm1, [rsp+0xE0]
00007f8fe1fcf854  vmovaps [rsp+0xE0], xmm15
00007f8fe1fcf85d  movaps xmm13, xmm2
00007f8fe1fcf861  addpd xmm13, xmm1
00007f8fe1fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007f8fe1fcf86c  ptest xmm15, xmm15
00007f8fe1fcf872  jnz 0x00007F8FE1FD1338
00007f8fe1fcf878  vmovaps xmm15, [rsp+0x120]
00007f8fe1fcf881  vmovaps xmm2, [rsp+0xD0]
00007f8fe1fcf88a  vmovaps [rsp+0xD0], xmm14
00007f8fe1fcf893  movaps xmm1, xmm15
00007f8fe1fcf897  addpd xmm1, xmm2
00007f8fe1fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007f8fe1fcf8a0  ptest xmm14, xmm14
00007f8fe1fcf8a6  jnz 0x00007F8FE1FD147A
00007f8fe1fcf8ac  vmovaps xmm15, [rsp+0x100]
00007f8fe1fcf8b5  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fcf8bb  vmovaps xmm2, [rsp+0xF0]
00007f8fe1fcf8c4  vmovaps [rsp+0xF0], xmm1
00007f8fe1fcf8cd  movaps xmm14, xmm2
00007f8fe1fcf8d1  mulpd xmm14, xmm15
00007f8fe1fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007f8fe1fcf8dc  ptest xmm1, xmm1
00007f8fe1fcf8e1  jnz 0x00007F8FE1FD15BB
00007f8fe1fcf8e7  vmovaps xmm1, [rsp+0xA0]
00007f8fe1fcf8f0  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fcf8f6  vmovaps xmm2, [rsp+0xE0]
00007f8fe1fcf8ff  vmovaps [rsp+0xE0], xmm14
00007f8fe1fcf908  movaps xmm15, xmm2
00007f8fe1fcf90c  mulpd xmm15, xmm1
00007f8fe1fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007f8fe1fcf917  ptest xmm14, xmm14
00007f8fe1fcf91d  jnz 0x00007F8FE1FD16FE
00007f8fe1fcf923  lea rax, [r14+0xE0]
00007f8fe1fcf92a  movups xmm1, [r13+rax*1]
00007f8fe1fcf930  vmovaps xmm14, [rsp+0x100]
00007f8fe1fcf939  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fcf93f  vmovaps [rsp+0x100], xmm1
00007f8fe1fcf948  vmovaps xmm1, [rsp+0x30]
00007f8fe1fcf94e  vmovaps [rsp+0x30], xmm15
00007f8fe1fcf954  movaps xmm2, xmm1
00007f8fe1fcf957  mulpd xmm2, xmm14
00007f8fe1fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007f8fe1fcf961  ptest xmm15, xmm15
00007f8fe1fcf967  jnz 0x00007F8FE1FD184A
00007f8fe1fcf96d  vmovaps [rsp+0x120], xmm10
00007f8fe1fcf976  vmovaps xmm1, [rsp+0x120]
00007f8fe1fcf97f  por xmm10, xmm1
00007f8fe1fcf984  movaps [r15+0x300], xmm10
00007f8fe1fcf98c  vmovaps [rsp+0x120], xmm8
00007f8fe1fcf995  vmovaps xmm1, [rsp+0x120]
00007f8fe1fcf99e  por xmm8, xmm1
00007f8fe1fcf9a3  movaps [r15+0x190], xmm8
00007f8fe1fcf9ab  vmovaps xmm1, [rsp+0xA0]
00007f8fe1fcf9b4  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fcf9ba  vmovaps xmm14, [rsp+0x100]
00007f8fe1fcf9c3  vmovaps [rsp+0x100], xmm13
00007f8fe1fcf9cc  movaps xmm15, xmm14
00007f8fe1fcf9d0  mulpd xmm15, xmm1
00007f8fe1fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007f8fe1fcf9db  ptest xmm13, xmm13
00007f8fe1fcf9e1  jnz 0x00007F8FE1FD198B
00007f8fe1fcf9e7  lea rax, [r14+0x90]
00007f8fe1fcf9ee  movups xmm1, [r13+rax*1]
00007f8fe1fcf9f4  vmovaps [rsp+0x120], xmm4
00007f8fe1fcf9fd  vmovaps xmm14, [rsp+0x120]
00007f8fe1fcfa06  por xmm4, xmm14
00007f8fe1fcfa0b  movaps [r15+0x1C0], xmm4
00007f8fe1fcfa13  vmovaps [rsp+0x120], xmm11
00007f8fe1fcfa1c  vmovaps xmm14, [rsp+0x120]
00007f8fe1fcfa25  por xmm11, xmm14
00007f8fe1fcfa2a  movaps [r15+0x200], xmm11
00007f8fe1fcfa32  vmovaps [rsp+0x120], xmm5
00007f8fe1fcfa3b  vmovaps xmm14, [rsp+0x120]
00007f8fe1fcfa44  por xmm5, xmm14
00007f8fe1fcfa49  movaps [r15+0x2D0], xmm5
00007f8fe1fcfa51  vmovaps [rsp+0x120], xmm12
00007f8fe1fcfa5a  vmovaps xmm14, [rsp+0x120]
00007f8fe1fcfa63  por xmm12, xmm14
00007f8fe1fcfa68  movaps [r15+0x2E0], xmm12
00007f8fe1fcfa70  vmovaps xmm13, [rsp+0x110]
00007f8fe1fcfa79  vmovaps [rsp+0x110], xmm1
00007f8fe1fcfa82  vmovaps xmm1, [rsp+0xE0]
00007f8fe1fcfa8b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fcfa94  movaps xmm14, xmm13
00007f8fe1fcfa98  addpd xmm14, xmm1
00007f8fe1fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007f8fe1fcfaa3  ptest xmm15, xmm15
00007f8fe1fcfaa9  jnz 0x00007F8FE1FD1AD8
00007f8fe1fcfaaf  vmovaps xmm1, [rsp+0xA0]
00007f8fe1fcfab8  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fcfabe  vmovaps xmm13, [rsp+0x110]
00007f8fe1fcfac7  vmovaps [rsp+0x110], xmm14
00007f8fe1fcfad0  movaps xmm15, xmm13
00007f8fe1fcfad4  mulpd xmm15, xmm1
00007f8fe1fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007f8fe1fcfadf  ptest xmm14, xmm14
00007f8fe1fcfae5  jnz 0x00007F8FE1FD1C1B
00007f8fe1fcfaeb  lea rax, [r14+0x80]
00007f8fe1fcfaf2  movups xmm1, [r13+rax*1]
00007f8fe1fcfaf8  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fcfb01  vmovaps [rsp+0xC0], xmm1
00007f8fe1fcfb0a  movaps xmm14, xmm13
00007f8fe1fcfb0e  addpd xmm14, xmm2
00007f8fe1fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007f8fe1fcfb19  ptest xmm1, xmm1
00007f8fe1fcfb1e  jnz 0x00007F8FE1FD1D68
00007f8fe1fcfb24  vmovaps xmm13, [rsp+0x100]
00007f8fe1fcfb2d  vmovaps xmm2, [rsp+0x30]
00007f8fe1fcfb33  vmovaps [rsp+0x30], xmm15
00007f8fe1fcfb39  movaps xmm1, xmm13
00007f8fe1fcfb3d  addpd xmm1, xmm2
00007f8fe1fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007f8fe1fcfb46  ptest xmm15, xmm15
00007f8fe1fcfb4c  jnz 0x00007F8FE1FD1EAB
00007f8fe1fcfb52  vmovaps xmm15, [rsp+0x20]
00007f8fe1fcfb58  vmovaps xmm13, [rsp+0x20]
00007f8fe1fcfb5e  por xmm15, xmm13
00007f8fe1fcfb63  movaps [r15+0x2F0], xmm15
00007f8fe1fcfb6b  vmovaps xmm13, [rsp+0xA0]
00007f8fe1fcfb74  vpermilpd xmm13, xmm13, 0x00
00007f8fe1fcfb7a  vmovaps [rsp+0x20], xmm1
00007f8fe1fcfb80  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fcfb89  vmovaps [rsp+0xA0], xmm15
00007f8fe1fcfb92  movaps xmm2, xmm1
00007f8fe1fcfb95  mulpd xmm2, xmm13
00007f8fe1fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f8fe1fcfb9f  ptest xmm15, xmm15
00007f8fe1fcfba5  jnz 0x00007F8FE1FD1FEC
00007f8fe1fcfbab  lea rax, [r14+0xD0]
00007f8fe1fcfbb2  movups xmm1, [r13+rax*1]
00007f8fe1fcfbb8  vmovaps xmm13, [rsp+0xF0]
00007f8fe1fcfbc1  vmovaps [rsp+0xC0], xmm1
00007f8fe1fcfbca  vmovaps xmm1, [rsp+0xE0]
00007f8fe1fcfbd3  vmovaps [rsp+0xE0], xmm14
00007f8fe1fcfbdc  movaps xmm15, xmm13
00007f8fe1fcfbe0  addpd xmm15, xmm1
00007f8fe1fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007f8fe1fcfbeb  ptest xmm14, xmm14
00007f8fe1fcfbf1  jnz 0x00007F8FE1FD2137
00007f8fe1fcfbf7  vmovaps xmm1, [rsp+0xB0]
00007f8fe1fcfc00  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fcfc06  movaps xmm14, xmm11
00007f8fe1fcfc0a  mulpd xmm14, xmm1
00007f8fe1fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007f8fe1fcfc15  ptest xmm13, xmm13
00007f8fe1fcfc1b  jnz 0x00007F8FE1FD227A
00007f8fe1fcfc21  movaps [r15+0x260], xmm14
00007f8fe1fcfc29  vxorps xmm1, xmm1, xmm1
00007f8fe1fcfc2d  vpbroadcastq xmm1, xmm1
00007f8fe1fcfc32  movaps [r15+0x1B0], xmm1
00007f8fe1fcfc3a  vmovaps xmm1, [rsp+0xB0]
00007f8fe1fcfc43  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fcfc49  vmovaps xmm11, [rsp+0xC0]
00007f8fe1fcfc52  vmovaps [rsp+0xC0], xmm15
00007f8fe1fcfc5b  movaps xmm13, xmm11
00007f8fe1fcfc5f  mulpd xmm13, xmm1
00007f8fe1fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007f8fe1fcfc6a  ptest xmm15, xmm15
00007f8fe1fcfc70  jnz 0x00007F8FE1FD23BD
00007f8fe1fcfc76  lea rax, [r14+0xC0]
00007f8fe1fcfc7d  movups xmm1, [r13+rax*1]
00007f8fe1fcfc83  vmovaps xmm11, [rsp+0x110]
00007f8fe1fcfc8c  vmovaps [rsp+0xF0], xmm1
00007f8fe1fcfc95  vmovaps xmm1, [rsp+0x30]
00007f8fe1fcfc9b  vmovaps [rsp+0x30], xmm14
00007f8fe1fcfca1  movaps xmm15, xmm11
00007f8fe1fcfca5  addpd xmm15, xmm1
00007f8fe1fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007f8fe1fcfcb0  ptest xmm14, xmm14
00007f8fe1fcfcb6  jnz 0x00007F8FE1FD250A
00007f8fe1fcfcbc  vmovaps [rsp+0x100], xmm9
00007f8fe1fcfcc5  vmovaps xmm1, [rsp+0x100]
00007f8fe1fcfcce  por xmm9, xmm1
00007f8fe1fcfcd3  movaps [r15+0x270], xmm9
00007f8fe1fcfcdb  vmovaps [rsp+0x100], xmm6
00007f8fe1fcfce4  vmovaps xmm1, [rsp+0x100]
00007f8fe1fcfced  por xmm6, xmm1
00007f8fe1fcfcf1  movaps [r15+0x1A0], xmm6
00007f8fe1fcfcf9  vmovaps xmm14, [rsp+0xB0]
00007f8fe1fcfd02  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fcfd08  vmovaps xmm6, [rsp+0xF0]
00007f8fe1fcfd11  vmovaps [rsp+0xF0], xmm1
00007f8fe1fcfd1a  movaps xmm11, xmm6
00007f8fe1fcfd1e  mulpd xmm11, xmm14
00007f8fe1fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007f8fe1fcfd29  ptest xmm1, xmm1
00007f8fe1fcfd2e  jnz 0x00007F8FE1FD264D
00007f8fe1fcfd34  lea rax, [r14+0x20]
00007f8fe1fcfd38  movups xmm1, [r13+rax*1]
00007f8fe1fcfd3e  movaps [r15+0x110], xmm1
00007f8fe1fcfd46  vmovaps xmm6, [rsp+0xE0]
00007f8fe1fcfd4f  vmovaps [rsp+0xE0], xmm1
00007f8fe1fcfd58  movaps xmm14, xmm6
00007f8fe1fcfd5c  addpd xmm14, xmm2
00007f8fe1fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007f8fe1fcfd67  ptest xmm1, xmm1
00007f8fe1fcfd6c  jnz 0x00007F8FE1FD279A
00007f8fe1fcfd72  vmovaps xmm1, [rsp+0xB0]
00007f8fe1fcfd7b  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fcfd81  movaps xmm6, xmm5
00007f8fe1fcfd84  mulpd xmm6, xmm1
00007f8fe1fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007f8fe1fcfd8d  ptest xmm2, xmm2
00007f8fe1fcfd92  jnz 0x00007F8FE1FD28DC
00007f8fe1fcfd98  vmovaps xmm5, [rsp+0x20]
00007f8fe1fcfd9e  movaps xmm1, xmm5
00007f8fe1fcfda1  addpd xmm1, xmm13
00007f8fe1fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007f8fe1fcfdab  ptest xmm2, xmm2
00007f8fe1fcfdb0  jnz 0x00007F8FE1FD2A1C
00007f8fe1fcfdb6  vmovaps xmm13, [rsp+0x80]
00007f8fe1fcfdbf  vpermilpd xmm13, xmm13, 0x00
00007f8fe1fcfdc5  vmovaps xmm2, [rsp+0xE0]
00007f8fe1fcfdce  vmovaps [rsp+0x20], xmm1
00007f8fe1fcfdd4  movaps xmm5, xmm2
00007f8fe1fcfdd7  mulpd xmm5, xmm13
00007f8fe1fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007f8fe1fcfde1  ptest xmm1, xmm1
00007f8fe1fcfde6  jnz 0x00007F8FE1FD2B5D
00007f8fe1fcfdec  vmovaps xmm1, [rsp+0x80]
00007f8fe1fcfdf5  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fcfdfb  movaps xmm13, xmm10
00007f8fe1fcfdff  mulpd xmm13, xmm1
00007f8fe1fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007f8fe1fcfe0a  ptest xmm2, xmm2
00007f8fe1fcfe0f  jnz 0x00007F8FE1FD2C9E
00007f8fe1fcfe15  vmovaps xmm10, [rsp+0x30]
00007f8fe1fcfe1b  movaps xmm1, xmm15
00007f8fe1fcfe1f  addpd xmm1, xmm10
00007f8fe1fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007f8fe1fcfe29  ptest xmm2, xmm2
00007f8fe1fcfe2e  jnz 0x00007F8FE1FD2DE1
00007f8fe1fcfe34  vmovaps xmm10, [rsp+0xC0]
00007f8fe1fcfe3d  movaps xmm15, xmm10
00007f8fe1fcfe41  addpd xmm15, xmm11
00007f8fe1fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007f8fe1fcfe4c  ptest xmm2, xmm2
00007f8fe1fcfe51  jnz 0x00007F8FE1FD2F23
00007f8fe1fcfe57  vmovaps xmm11, [rsp+0x80]
00007f8fe1fcfe60  vpermilpd xmm11, xmm11, 0x00
00007f8fe1fcfe66  movaps xmm10, xmm12
00007f8fe1fcfe6a  mulpd xmm10, xmm11
00007f8fe1fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007f8fe1fcfe75  ptest xmm2, xmm2
00007f8fe1fcfe7a  jnz 0x00007F8FE1FD3067
00007f8fe1fcfe80  vmovaps xmm12, [rsp+0x80]
00007f8fe1fcfe89  vpermilpd xmm12, xmm12, 0x00
00007f8fe1fcfe8f  vmovaps xmm2, [rsp+0xA0]
00007f8fe1fcfe98  vmovaps [rsp+0x30], xmm1
00007f8fe1fcfe9e  movaps xmm11, xmm2
00007f8fe1fcfea2  mulpd xmm11, xmm12
00007f8fe1fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007f8fe1fcfead  ptest xmm1, xmm1
00007f8fe1fcfeb2  jnz 0x00007F8FE1FD31AB
00007f8fe1fcfeb8  movaps xmm1, xmm14
00007f8fe1fcfebc  addpd xmm1, xmm6
00007f8fe1fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007f8fe1fcfec5  ptest xmm12, xmm12
00007f8fe1fcfecb  jnz 0x00007F8FE1FD32EE
00007f8fe1fcfed1  vmovaps xmm12, [rsp+0x20]
00007f8fe1fcfed7  movaps xmm14, xmm12
00007f8fe1fcfedb  addpd xmm14, xmm5
00007f8fe1fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007f8fe1fcfee6  ptest xmm6, xmm6
00007f8fe1fcfeeb  jnz 0x00007F8FE1FD342F
00007f8fe1fcfef1  vmovaps xmm12, [rsp+0x90]
00007f8fe1fcfefa  vpermilpd xmm12, xmm12, 0x00
00007f8fe1fcff00  movaps xmm6, xmm9
00007f8fe1fcff04  mulpd xmm6, xmm12
00007f8fe1fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007f8fe1fcff0e  ptest xmm5, xmm5
00007f8fe1fcff13  jnz 0x00007F8FE1FD3572
00007f8fe1fcff19  movaps xmm12, xmm15
00007f8fe1fcff1d  addpd xmm12, xmm13
00007f8fe1fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007f8fe1fcff28  ptest xmm9, xmm9
00007f8fe1fcff2e  jnz 0x00007F8FE1FD36B4
00007f8fe1fcff34  vmovaps xmm13, [rsp+0x30]
00007f8fe1fcff3a  movaps xmm15, xmm13
00007f8fe1fcff3e  addpd xmm15, xmm10
00007f8fe1fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007f8fe1fcff49  ptest xmm9, xmm9
00007f8fe1fcff4f  jnz 0x00007F8FE1FD37F8
00007f8fe1fcff55  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fcff5e  vmovaps xmm10, [rsp+0xD0]
00007f8fe1fcff67  por xmm13, xmm10
00007f8fe1fcff6c  movaps [r15+0x250], xmm13
00007f8fe1fcff74  vmovaps [rsp+0x20], xmm7
00007f8fe1fcff7a  vmovaps xmm13, [rsp+0x20]
00007f8fe1fcff80  por xmm7, xmm13
00007f8fe1fcff85  movaps [r15+0x2A0], xmm7
00007f8fe1fcff8d  vmovaps [rsp+0x20], xmm3
00007f8fe1fcff93  vmovaps xmm13, [rsp+0x20]
00007f8fe1fcff99  por xmm3, xmm13
00007f8fe1fcff9e  movaps [r15+0x1D0], xmm3
00007f8fe1fcffa6  lea rax, [r14+0x40]
00007f8fe1fcffaa  movups xmm13, [r13+rax*1]
00007f8fe1fcffb0  movaps [r15+0x2C0], xmm13
00007f8fe1fcffb8  vmovaps xmm10, [rsp+0x90]
00007f8fe1fcffc1  vpermilpd xmm10, xmm10, 0x00
00007f8fe1fcffc7  movaps xmm9, xmm8
00007f8fe1fcffcb  mulpd xmm9, xmm10
00007f8fe1fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f8fe1fcffd6  ptest xmm5, xmm5
00007f8fe1fcffdb  jnz 0x00007F8FE1FD3946
00007f8fe1fcffe1  movaps xmm10, xmm1
00007f8fe1fcffe5  addpd xmm10, xmm11
00007f8fe1fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007f8fe1fcfff0  ptest xmm8, xmm8
00007f8fe1fcfff6  jnz 0x00007F8FE1FD3A8A
00007f8fe1fcfffc  movaps xmm1, xmm14
00007f8fe1fd0000  addpd xmm1, xmm6
00007f8fe1fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007f8fe1fd0009  ptest xmm11, xmm11
00007f8fe1fd000f  jnz 0x00007F8FE1FD3BCD
00007f8fe1fd0015  vmovaps xmm14, [rsp+0x90]
00007f8fe1fd001e  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fd0024  movaps xmm11, xmm13
00007f8fe1fd0028  mulpd xmm11, xmm14
00007f8fe1fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007f8fe1fd0033  ptest xmm8, xmm8
00007f8fe1fd0039  jnz 0x00007F8FE1FD3D0E
00007f8fe1fd003f  vmovaps xmm14, [rsp+0x90]
00007f8fe1fd0048  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fd004e  vmovaps xmm8, [rsp+0x10]
00007f8fe1fd0054  movaps xmm13, xmm8
00007f8fe1fd0058  mulpd xmm13, xmm14
00007f8fe1fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007f8fe1fd0063  ptest xmm6, xmm6
00007f8fe1fd0068  jnz 0x00007F8FE1FD3E52
00007f8fe1fd006e  vmovaps xmm14, [rsp+0x60]
00007f8fe1fd0074  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fd007a  movaps xmm8, xmm7
00007f8fe1fd007e  mulpd xmm8, xmm14
00007f8fe1fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007f8fe1fd0089  ptest xmm6, xmm6
00007f8fe1fd008e  jnz 0x00007F8FE1FD3F96
00007f8fe1fd0094  movaps xmm14, xmm12
00007f8fe1fd0098  addpd xmm14, xmm9
00007f8fe1fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007f8fe1fd00a3  ptest xmm7, xmm7
00007f8fe1fd00a8  jnz 0x00007F8FE1FD40D9
00007f8fe1fd00ae  vmovaps xmm12, [rsp+0x60]
00007f8fe1fd00b4  vpermilpd xmm12, xmm12, 0x00
00007f8fe1fd00ba  vmovaps xmm7, [rsp+0xF0]
00007f8fe1fd00c3  movaps xmm9, xmm7
00007f8fe1fd00c7  mulpd xmm9, xmm12
00007f8fe1fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007f8fe1fd00d2  ptest xmm6, xmm6
00007f8fe1fd00d7  jnz 0x00007F8FE1FD421D
00007f8fe1fd00dd  movaps xmm12, xmm15
00007f8fe1fd00e1  addpd xmm12, xmm11
00007f8fe1fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007f8fe1fd00ec  ptest xmm7, xmm7
00007f8fe1fd00f1  jnz 0x00007F8FE1FD4360
00007f8fe1fd00f7  vmovaps xmm15, [rsp+0x60]
00007f8fe1fd00fd  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fd0103  vmovaps xmm7, [rsp+0x40]
00007f8fe1fd0109  movaps xmm11, xmm7
00007f8fe1fd010d  mulpd xmm11, xmm15
00007f8fe1fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007f8fe1fd0118  ptest xmm6, xmm6
00007f8fe1fd011d  jnz 0x00007F8FE1FD44A4
00007f8fe1fd0123  movaps xmm15, xmm10
00007f8fe1fd0127  addpd xmm15, xmm13
00007f8fe1fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007f8fe1fd0132  ptest xmm7, xmm7
00007f8fe1fd0137  jnz 0x00007F8FE1FD45E7
00007f8fe1fd013d  vmovaps xmm13, [rsp+0x60]
00007f8fe1fd0143  vpermilpd xmm13, xmm13, 0x00
00007f8fe1fd0149  vmovaps xmm7, [rsp+0x50]
00007f8fe1fd014f  movaps xmm10, xmm7
00007f8fe1fd0153  mulpd xmm10, xmm13
00007f8fe1fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007f8fe1fd015e  ptest xmm6, xmm6
00007f8fe1fd0163  jnz 0x00007F8FE1FD472B
00007f8fe1fd0169  movaps xmm13, xmm1
00007f8fe1fd016d  addpd xmm13, xmm8
00007f8fe1fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007f8fe1fd0178  ptest xmm7, xmm7
00007f8fe1fd017d  jnz 0x00007F8FE1FD486E
00007f8fe1fd0183  lea rax, [r14+0x70]
00007f8fe1fd0187  movups xmm1, [r13+rax*1]
00007f8fe1fd018d  movaps [r15+0x240], xmm1
00007f8fe1fd0195  movaps xmm8, xmm14
00007f8fe1fd0199  addpd xmm8, xmm9
00007f8fe1fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007f8fe1fd01a4  ptest xmm7, xmm7
00007f8fe1fd01a9  jnz 0x00007F8FE1FD49BB
00007f8fe1fd01af  movaps [r15+0x170], xmm8
00007f8fe1fd01b7  vmovaps xmm14, [rsp+0x70]
00007f8fe1fd01bd  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fd01c3  movaps xmm9, xmm1
00007f8fe1fd01c7  mulpd xmm9, xmm14
00007f8fe1fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007f8fe1fd01d2  ptest xmm7, xmm7
00007f8fe1fd01d7  jnz 0x00007F8FE1FD4AFF
00007f8fe1fd01dd  vmovaps xmm1, [rsp+0x70]
00007f8fe1fd01e3  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd01e9  movaps xmm14, xmm4
00007f8fe1fd01ed  mulpd xmm14, xmm1
00007f8fe1fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007f8fe1fd01f8  ptest xmm7, xmm7
00007f8fe1fd01fd  jnz 0x00007F8FE1FD4C42
00007f8fe1fd0203  movaps [r15+0x180], xmm14
00007f8fe1fd020b  movaps xmm1, xmm12
00007f8fe1fd020f  addpd xmm1, xmm11
00007f8fe1fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007f8fe1fd0219  ptest xmm7, xmm7
00007f8fe1fd021e  jnz 0x00007F8FE1FD4D84
00007f8fe1fd0224  movaps [r15+0x210], xmm1
00007f8fe1fd022c  movups xmm12, [r13+r14*1]
00007f8fe1fd0232  lea rax, [r14+0x10]
00007f8fe1fd0236  movups xmm11, [r13+rax*1]
00007f8fe1fd023c  movaps [r15+0x230], xmm11
00007f8fe1fd0244  movaps xmm7, xmm15
00007f8fe1fd0248  addpd xmm7, xmm10
00007f8fe1fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f8fe1fd0252  ptest xmm6, xmm6
00007f8fe1fd0257  jnz 0x00007F8FE1FD4EDA
00007f8fe1fd025d  movaps [r15+0x130], xmm7
00007f8fe1fd0265  vmovaps xmm15, [rsp+0x70]
00007f8fe1fd026b  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fd0271  movaps xmm10, xmm11
00007f8fe1fd0275  mulpd xmm10, xmm15
00007f8fe1fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007f8fe1fd0280  ptest xmm6, xmm6
00007f8fe1fd0285  jnz 0x00007F8FE1FD501C
00007f8fe1fd028b  movaps [r15+0x220], xmm10
00007f8fe1fd0293  vmovaps xmm15, [rsp+0x70]
00007f8fe1fd0299  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fd029f  movaps xmm11, xmm12
00007f8fe1fd02a3  mulpd xmm11, xmm15
00007f8fe1fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007f8fe1fd02ae  ptest xmm6, xmm6
00007f8fe1fd02b3  jnz 0x00007F8FE1FD5160
00007f8fe1fd02b9  movaps xmm15, xmm13
00007f8fe1fd02bd  addpd xmm15, xmm9
00007f8fe1fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007f8fe1fd02c8  ptest xmm12, xmm12
00007f8fe1fd02ce  jnz 0x00007F8FE1FD52A4
00007f8fe1fd02d4  movaps [r15+0x140], xmm15
00007f8fe1fd02dc  movaps xmm13, xmm8
00007f8fe1fd02e0  addpd xmm13, xmm14
00007f8fe1fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007f8fe1fd02eb  ptest xmm12, xmm12
00007f8fe1fd02f1  jnz 0x00007F8FE1FD53E8
00007f8fe1fd02f7  movaps [r15+0x150], xmm13
00007f8fe1fd02ff  movaps xmm14, xmm1
00007f8fe1fd0303  addpd xmm14, xmm10
00007f8fe1fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007f8fe1fd030e  ptest xmm12, xmm12
00007f8fe1fd0314  jnz 0x00007F8FE1FD552C
00007f8fe1fd031a  movaps [r15+0x160], xmm14
00007f8fe1fd0322  movaps xmm1, xmm7
00007f8fe1fd0325  addpd xmm1, xmm11
00007f8fe1fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007f8fe1fd032f  ptest xmm12, xmm12
00007f8fe1fd0335  jnz 0x00007F8FE1FD566F
00007f8fe1fd033b  movaps [r15+0x120], xmm1
00007f8fe1fd0343  mov eax, 0x430920
00007f8fe1fd0348  movups [r13+rax*1], xmm15
00007f8fe1fd034e  mov eax, 0x430930
00007f8fe1fd0353  movups [r13+rax*1], xmm13
00007f8fe1fd0359  mov eax, 0x430940
00007f8fe1fd035e  movups [r13+rax*1], xmm14
00007f8fe1fd0364  mov eax, 0x430950
00007f8fe1fd0369  movups [r13+rax*1], xmm1
00007f8fe1fd036f  mov eax, [r15+0x108]
00007f8fe1fd0376  sahf
00007f8fe1fd0377  jnz 0x00007F8FE1FD03A9
00007f8fe1fd0379  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fd0381  jz 0x00007F8FE1FDB900
00007f8fe1fd0387  nop [rax+rax*1], ax
00007f8fe1fd0390  nop [rax+rax*1], eax
00007f8fe1fd0398  mov eax, 0x410444
00007f8fe1fd039d  mov [r15+0x100], rax
00007f8fe1fd03a4  jmp 0x00007F8FE1DFE110
00007f8fe1fd03a9  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fd03b1  jz 0x00007F8FE1FD57E0
00007f8fe1fd03b7  nop [rax+rax*1], ax
00007f8fe1fd03c0  nop [rax+rax*1], eax
00007f8fe1fd03c8  mov eax, 0x410278
00007f8fe1fd03cd  mov [r15+0x100], rax
00007f8fe1fd03d4  jmp 0x00007F8FE1DFE110
00007f8fe1fd03d9  int3
00007f8fe1fd03da  call 0x00007F8FE1EB52F0
00007f8fe1fd03df  jmp 0x00007F8FE1FCF016
00007f8fe1fd03e4  call 0x00007F8FE1EC4620
00007f8fe1fd03e9  jmp 0x00007F8FE1FCF023
00007f8fe1fd03ee  call 0x00007F8FE1EC33A0
00007f8fe1fd03f3  jmp 0x00007F8FE1FCF035
00007f8fe1fd03f8  call 0x00007F8FE1EC2120
00007f8fe1fd03fd  jmp 0x00007F8FE1FCF03F
00007f8fe1fd0402  call 0x00007F8FE1EC0860
00007f8fe1fd0407  jmp 0x00007F8FE1FCF067
00007f8fe1fd040c  call 0x00007F8FE1EBF5F0
00007f8fe1fd0411  jmp 0x00007F8FE1FCF073
00007f8fe1fd0416  call 0x00007F8FE1EC0860
00007f8fe1fd041b  jmp 0x00007F8FE1FCF0A5
00007f8fe1fd0420  call 0x00007F8FE1EBF5F0
00007f8fe1fd0425  jmp 0x00007F8FE1FCF0B1
00007f8fe1fd042a  call 0x00007F8FE1EC4740
00007f8fe1fd042f  jmp 0x00007F8FE1FCF0BE
00007f8fe1fd0434  call 0x00007F8FE1EB5400
00007f8fe1fd0439  jmp 0x00007F8FE1FCF0CB
00007f8fe1fd043e  call 0x00007F8FE1EB52F0
00007f8fe1fd0443  jmp 0x00007F8FE1FCF0D8
00007f8fe1fd0448  call 0x00007F8FE1EC4620
00007f8fe1fd044d  jmp 0x00007F8FE1FCF0E5
00007f8fe1fd0452  call 0x00007F8FE1EC0860
00007f8fe1fd0457  jmp 0x00007F8FE1FCF10D
00007f8fe1fd045c  call 0x00007F8FE1EBF5F0
00007f8fe1fd0461  jmp 0x00007F8FE1FCF119
00007f8fe1fd0466  call 0x00007F8FE1E09D70
00007f8fe1fd046b  jmp 0x00007F8FE1FCF11F
00007f8fe1fd0470  call 0x00007F8FE1EBE9C0
00007f8fe1fd0475  jmp 0x00007F8FE1FCF129
00007f8fe1fd047a  call 0x00007F8FE1EC0860
00007f8fe1fd047f  jmp 0x00007F8FE1FCF151
00007f8fe1fd0484  call 0x00007F8FE1EBF5F0
00007f8fe1fd0489  jmp 0x00007F8FE1FCF15D
00007f8fe1fd048e  call 0x00007F8FE1EBD750
00007f8fe1fd0493  jmp 0x00007F8FE1FCF16A
00007f8fe1fd0498  call 0x00007F8FE1EBC4E0
00007f8fe1fd049d  jmp 0x00007F8FE1FCF177
00007f8fe1fd04a2  call 0x00007F8FE1EC4740
00007f8fe1fd04a7  jmp 0x00007F8FE1FCF184
00007f8fe1fd04ac  call 0x00007F8FE1EB5400
00007f8fe1fd04b1  jmp 0x00007F8FE1FCF191
00007f8fe1fd04b6  call 0x00007F8FE1EB52F0
00007f8fe1fd04bb  jmp 0x00007F8FE1FCF19E
00007f8fe1fd04c0  call 0x00007F8FE1EC4620
00007f8fe1fd04c5  jmp 0x00007F8FE1FCF1AB
00007f8fe1fd04ca  call 0x00007F8FE1EC0860
00007f8fe1fd04cf  jmp 0x00007F8FE1FCF1BE
00007f8fe1fd04d4  call 0x00007F8FE1EBB270
00007f8fe1fd04d9  jmp 0x00007F8FE1FCF1CB
00007f8fe1fd04de  call 0x00007F8FE1EBA000
00007f8fe1fd04e3  jmp 0x00007F8FE1FCF1D8
00007f8fe1fd04e8  call 0x00007F8FE1EB8D90
00007f8fe1fd04ed  jmp 0x00007F8FE1FCF1E5
00007f8fe1fd04f2  call 0x00007F8FE1EB8A20
00007f8fe1fd04f7  jmp 0x00007F8FE1FCF1F2
00007f8fe1fd04fc  call 0x00007F8FE1EB5400
00007f8fe1fd0501  jmp 0x00007F8FE1FCF1FC
00007f8fe1fd0506  call 0x00007F8FE1EC2240
00007f8fe1fd050b  jmp 0x00007F8FE1FCF206
00007f8fe1fd0510  call 0x00007F8FE1EB52F0
00007f8fe1fd0515  jmp 0x00007F8FE1FCF210
00007f8fe1fd051a  call 0x00007F8FE1EC2120
00007f8fe1fd051f  jmp 0x00007F8FE1FCF21A
00007f8fe1fd0524  call 0x00007F8FE1EB77B0
00007f8fe1fd0529  jmp 0x00007F8FE1FCF224
00007f8fe1fd052e  call 0x00007F8FE1EB6550
00007f8fe1fd0533  jmp 0x00007F8FE1FCF22E
00007f8fe1fd0538  call 0x00007F8FE1EBFD50
00007f8fe1fd053d  jmp 0x00007F8FE1FCF240
00007f8fe1fd0542  call 0x00007F8FE1EB8EA0
00007f8fe1fd0547  jmp 0x00007F8FE1FCF24A
00007f8fe1fd054c  call 0x00007F8FE1EBFC30
00007f8fe1fd0551  jmp 0x00007F8FE1FCF257
00007f8fe1fd0556  call 0x00007F8FE1EB8D90
00007f8fe1fd055b  jmp 0x00007F8FE1FCF264
00007f8fe1fd0560  call 0x00007F8FE1EC2240
00007f8fe1fd0565  jmp 0x00007F8FE1FCF271
00007f8fe1fd056a  call 0x00007F8FE1EB5400
00007f8fe1fd056f  jmp 0x00007F8FE1FCF27E
00007f8fe1fd0574  call 0x00007F8FE1EB52F0
00007f8fe1fd0579  jmp 0x00007F8FE1FCF28B
00007f8fe1fd057e  call 0x00007F8FE1EC2120
00007f8fe1fd0583  jmp 0x00007F8FE1FCF298
00007f8fe1fd0588  call 0x00007F8FE1EB52F0
00007f8fe1fd058d  jmp 0x00007F8FE1FCF2AB
00007f8fe1fd0592  call 0x00007F8FE1EB52F0
00007f8fe1fd0597  jmp 0x00007F8FE1FCF2BE
00007f8fe1fd059c  call 0x00007F8FE1EB52F0
00007f8fe1fd05a1  jmp 0x00007F8FE1FCF2D1
00007f8fe1fd05a6  call 0x00007F8FE1EB52F0
00007f8fe1fd05ab  jmp 0x00007F8FE1FCF2E4
00007f8fe1fd05b0  call 0x00007F8FE1EC2240
00007f8fe1fd05b5  jmp 0x00007F8FE1FCF2F9
00007f8fe1fd05ba  call 0x00007F8FE1EC2240
00007f8fe1fd05bf  jmp 0x00007F8FE1FCF30C
00007f8fe1fd05c4  call 0x00007F8FE1EC2120
00007f8fe1fd05c9  jmp 0x00007F8FE1FCF319
00007f8fe1fd05ce  call 0x00007F8FE1EB52F0
00007f8fe1fd05d3  jmp 0x00007F8FE1FCF32C
00007f8fe1fd05d8  call 0x00007F8FE1EB52F0
00007f8fe1fd05dd  jmp 0x00007F8FE1FCF34F
00007f8fe1fd05e2  call 0x00007F8FE1EB52F0
00007f8fe1fd05e7  jmp 0x00007F8FE1FCF362
00007f8fe1fd05ec  call 0x00007F8FE1DFF540
00007f8fe1fd05f1  jmp 0x00007F8FE1FCF380
00007f8fe1fd05f6  call 0x00007F8FE1E08C20
00007f8fe1fd05fb  jmp 0x00007F8FE1FCF38A
00007f8fe1fd0600  call 0x00007F8FE1ED6600
00007f8fe1fd0605  jmp 0x00007F8FE1FCF396
00007f8fe1fd060a  call 0x00007F8FE1DFF540
00007f8fe1fd060f  jmp 0x00007F8FE1FCF3A6
00007f8fe1fd0614  call 0x00007F8FE1EC0370
00007f8fe1fd0619  jmp 0x00007F8FE1FCF3D4
00007f8fe1fd061e  call 0x00007F8FE1EBF100
00007f8fe1fd0623  jmp 0x00007F8FE1FCF3DD
00007f8fe1fd0628  call 0x00007F8FE1EC0370
00007f8fe1fd062d  jmp 0x00007F8FE1FCF43B
00007f8fe1fd0632  call 0x00007F8FE1EBF100
00007f8fe1fd0637  jmp 0x00007F8FE1FCF444
00007f8fe1fd063c  call 0x00007F8FE1EC0370
00007f8fe1fd0641  jmp 0x00007F8FE1FCF48B
00007f8fe1fd0646  call 0x00007F8FE1EBF100
00007f8fe1fd064b  jmp 0x00007F8FE1FCF494
00007f8fe1fd0650  call 0x00007F8FE1E0B720
00007f8fe1fd0655  jmp 0x00007F8FE1FCF4D7
00007f8fe1fd065a  call 0x00007F8FE1EB47C0
00007f8fe1fd065f  jmp 0x00007F8FE1FCF4EA
00007f8fe1fd0664  call 0x00007F8FE1E08B00
00007f8fe1fd0669  jmp 0x00007F8FE1FCF501
00007f8fe1fd066e  call 0x00007F8FE1DFF430
00007f8fe1fd0673  jmp 0x00007F8FE1FCF514
00007f8fe1fd0678  call 0x00007F8FE1DFF430
00007f8fe1fd067d  jmp 0x00007F8FE1FCF527
00007f8fe1fd0682  sub rsp, 0x08
00007f8fe1fd0686  push rax
00007f8fe1fd0687  push rcx
00007f8fe1fd0688  push rdx
00007f8fe1fd0689  push rdi
00007f8fe1fd068a  push rsi
00007f8fe1fd068b  push r8
00007f8fe1fd068d  push r9
00007f8fe1fd068f  push r10
00007f8fe1fd0691  push r11
00007f8fe1fd0693  sub rsp, 0xF0
00007f8fe1fd069a  vmovaps [rsp], xmm0
00007f8fe1fd069f  vmovaps [rsp+0x10], xmm2
00007f8fe1fd06a5  vmovaps [rsp+0x20], xmm3
00007f8fe1fd06ab  vmovaps [rsp+0x30], xmm4
00007f8fe1fd06b1  vmovaps [rsp+0x40], xmm5
00007f8fe1fd06b7  vmovaps [rsp+0x50], xmm6
00007f8fe1fd06bd  vmovaps [rsp+0x60], xmm7
00007f8fe1fd06c3  vmovaps [rsp+0x70], xmm8
00007f8fe1fd06c9  vmovaps [rsp+0x80], xmm9
00007f8fe1fd06d2  vmovaps [rsp+0x90], xmm10
00007f8fe1fd06db  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd06e4  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd06ed  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd06f6  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd06ff  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd0708  sub rsp, 0x30
00007f8fe1fd070c  movaps [rsp], xmm1
00007f8fe1fd0710  movaps [rsp+0x10], xmm15
00007f8fe1fd0716  movaps [rsp+0x20], xmm14
00007f8fe1fd071c  lea rdi, [rsp]
00007f8fe1fd0720  mov esi, 0x00
00007f8fe1fd0725  mov rax, 0x6020BB77F530
00007f8fe1fd072f  call rax
00007f8fe1fd0731  movaps xmm1, [rsp]
00007f8fe1fd0735  add rsp, 0x30
00007f8fe1fd0739  vmovaps xmm0, [rsp]
00007f8fe1fd073e  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd0744  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd074a  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd0750  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd0756  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd075c  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd0762  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd0768  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd0771  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd077a  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd0783  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd078c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd0795  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd079e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd07a7  add rsp, 0xF0
00007f8fe1fd07ae  pop r11
00007f8fe1fd07b0  pop r10
00007f8fe1fd07b2  pop r9
00007f8fe1fd07b4  pop r8
00007f8fe1fd07b6  pop rsi
00007f8fe1fd07b7  pop rdi
00007f8fe1fd07b8  pop rdx
00007f8fe1fd07b9  pop rcx
00007f8fe1fd07ba  pop rax
00007f8fe1fd07bb  add rsp, 0x08
00007f8fe1fd07bf  jmp 0x00007F8FE1FCF581
00007f8fe1fd07c4  sub rsp, 0x08
00007f8fe1fd07c8  push rax
00007f8fe1fd07c9  push rcx
00007f8fe1fd07ca  push rdx
00007f8fe1fd07cb  push rdi
00007f8fe1fd07cc  push rsi
00007f8fe1fd07cd  push r8
00007f8fe1fd07cf  push r9
00007f8fe1fd07d1  push r10
00007f8fe1fd07d3  push r11
00007f8fe1fd07d5  sub rsp, 0xF0
00007f8fe1fd07dc  vmovaps [rsp], xmm0
00007f8fe1fd07e1  vmovaps [rsp+0x10], xmm1
00007f8fe1fd07e7  vmovaps [rsp+0x20], xmm2
00007f8fe1fd07ed  vmovaps [rsp+0x30], xmm3
00007f8fe1fd07f3  vmovaps [rsp+0x40], xmm4
00007f8fe1fd07f9  vmovaps [rsp+0x50], xmm5
00007f8fe1fd07ff  vmovaps [rsp+0x60], xmm6
00007f8fe1fd0805  vmovaps [rsp+0x70], xmm7
00007f8fe1fd080b  vmovaps [rsp+0x80], xmm8
00007f8fe1fd0814  vmovaps [rsp+0x90], xmm9
00007f8fe1fd081d  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd0826  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd082f  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd0838  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd0841  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd084a  sub rsp, 0x30
00007f8fe1fd084e  movaps [rsp], xmm13
00007f8fe1fd0853  movaps [rsp+0x10], xmm1
00007f8fe1fd0858  movaps [rsp+0x20], xmm14
00007f8fe1fd085e  lea rdi, [rsp]
00007f8fe1fd0862  mov esi, 0x00
00007f8fe1fd0867  mov rax, 0x6020BB77F530
00007f8fe1fd0871  call rax
00007f8fe1fd0873  movaps xmm13, [rsp]
00007f8fe1fd0878  add rsp, 0x30
00007f8fe1fd087c  vmovaps xmm0, [rsp]
00007f8fe1fd0881  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd0887  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd088d  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd0893  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd0899  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd089f  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd08a5  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd08ab  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd08b4  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd08bd  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd08c6  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd08cf  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd08d8  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd08e1  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd08ea  add rsp, 0xF0
00007f8fe1fd08f1  pop r11
00007f8fe1fd08f3  pop r10
00007f8fe1fd08f5  pop r9
00007f8fe1fd08f7  pop r8
00007f8fe1fd08f9  pop rsi
00007f8fe1fd08fa  pop rdi
00007f8fe1fd08fb  pop rdx
00007f8fe1fd08fc  pop rcx
00007f8fe1fd08fd  pop rax
00007f8fe1fd08fe  add rsp, 0x08
00007f8fe1fd0902  jmp 0x00007F8FE1FCF5CF
00007f8fe1fd0907  sub rsp, 0x08
00007f8fe1fd090b  push rax
00007f8fe1fd090c  push rcx
00007f8fe1fd090d  push rdx
00007f8fe1fd090e  push rdi
00007f8fe1fd090f  push rsi
00007f8fe1fd0910  push r8
00007f8fe1fd0912  push r9
00007f8fe1fd0914  push r10
00007f8fe1fd0916  push r11
00007f8fe1fd0918  sub rsp, 0xF0
00007f8fe1fd091f  vmovaps [rsp], xmm0
00007f8fe1fd0924  vmovaps [rsp+0x10], xmm1
00007f8fe1fd092a  vmovaps [rsp+0x20], xmm2
00007f8fe1fd0930  vmovaps [rsp+0x30], xmm3
00007f8fe1fd0936  vmovaps [rsp+0x40], xmm4
00007f8fe1fd093c  vmovaps [rsp+0x50], xmm5
00007f8fe1fd0942  vmovaps [rsp+0x60], xmm6
00007f8fe1fd0948  vmovaps [rsp+0x70], xmm7
00007f8fe1fd094e  vmovaps [rsp+0x80], xmm8
00007f8fe1fd0957  vmovaps [rsp+0x90], xmm9
00007f8fe1fd0960  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd0969  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd0972  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd097b  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd0984  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd098d  sub rsp, 0x30
00007f8fe1fd0991  movaps [rsp], xmm15
00007f8fe1fd0996  movaps [rsp+0x10], xmm14
00007f8fe1fd099c  movaps [rsp+0x20], xmm1
00007f8fe1fd09a1  lea rdi, [rsp]
00007f8fe1fd09a5  mov esi, 0x00
00007f8fe1fd09aa  mov rax, 0x6020BB77F530
00007f8fe1fd09b4  call rax
00007f8fe1fd09b6  movaps xmm15, [rsp]
00007f8fe1fd09bb  add rsp, 0x30
00007f8fe1fd09bf  vmovaps xmm0, [rsp]
00007f8fe1fd09c4  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd09ca  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd09d0  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd09d6  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd09dc  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd09e2  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd09e8  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd09ee  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd09f7  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd0a00  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd0a09  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd0a12  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd0a1b  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd0a24  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd0a2d  add rsp, 0xF0
00007f8fe1fd0a34  pop r11
00007f8fe1fd0a36  pop r10
00007f8fe1fd0a38  pop r9
00007f8fe1fd0a3a  pop r8
00007f8fe1fd0a3c  pop rsi
00007f8fe1fd0a3d  pop rdi
00007f8fe1fd0a3e  pop rdx
00007f8fe1fd0a3f  pop rcx
00007f8fe1fd0a40  pop rax
00007f8fe1fd0a41  add rsp, 0x08
00007f8fe1fd0a45  jmp 0x00007F8FE1FCF617
00007f8fe1fd0a4a  sub rsp, 0x08
00007f8fe1fd0a4e  push rax
00007f8fe1fd0a4f  push rcx
00007f8fe1fd0a50  push rdx
00007f8fe1fd0a51  push rdi
00007f8fe1fd0a52  push rsi
00007f8fe1fd0a53  push r8
00007f8fe1fd0a55  push r9
00007f8fe1fd0a57  push r10
00007f8fe1fd0a59  push r11
00007f8fe1fd0a5b  sub rsp, 0xF0
00007f8fe1fd0a62  vmovaps [rsp], xmm0
00007f8fe1fd0a67  vmovaps [rsp+0x10], xmm2
00007f8fe1fd0a6d  vmovaps [rsp+0x20], xmm3
00007f8fe1fd0a73  vmovaps [rsp+0x30], xmm4
00007f8fe1fd0a79  vmovaps [rsp+0x40], xmm5
00007f8fe1fd0a7f  vmovaps [rsp+0x50], xmm6
00007f8fe1fd0a85  vmovaps [rsp+0x60], xmm7
00007f8fe1fd0a8b  vmovaps [rsp+0x70], xmm8
00007f8fe1fd0a91  vmovaps [rsp+0x80], xmm9
00007f8fe1fd0a9a  vmovaps [rsp+0x90], xmm10
00007f8fe1fd0aa3  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd0aac  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd0ab5  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd0abe  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd0ac7  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd0ad0  sub rsp, 0x30
00007f8fe1fd0ad4  movaps [rsp], xmm1
00007f8fe1fd0ad8  movaps [rsp+0x10], xmm14
00007f8fe1fd0ade  movaps [rsp+0x20], xmm10
00007f8fe1fd0ae4  lea rdi, [rsp]
00007f8fe1fd0ae8  mov esi, 0x00
00007f8fe1fd0aed  mov rax, 0x6020BB77F530
00007f8fe1fd0af7  call rax
00007f8fe1fd0af9  movaps xmm1, [rsp]
00007f8fe1fd0afd  add rsp, 0x30
00007f8fe1fd0b01  vmovaps xmm0, [rsp]
00007f8fe1fd0b06  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd0b0c  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd0b12  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd0b18  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd0b1e  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd0b24  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd0b2a  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd0b30  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd0b39  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd0b42  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd0b4b  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd0b54  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd0b5d  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd0b66  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd0b6f  add rsp, 0xF0
00007f8fe1fd0b76  pop r11
00007f8fe1fd0b78  pop r10
00007f8fe1fd0b7a  pop r9
00007f8fe1fd0b7c  pop r8
00007f8fe1fd0b7e  pop rsi
00007f8fe1fd0b7f  pop rdi
00007f8fe1fd0b80  pop rdx
00007f8fe1fd0b81  pop rcx
00007f8fe1fd0b82  pop rax
00007f8fe1fd0b83  add rsp, 0x08
00007f8fe1fd0b87  jmp 0x00007F8FE1FCF631
00007f8fe1fd0b8c  sub rsp, 0x08
00007f8fe1fd0b90  push rax
00007f8fe1fd0b91  push rcx
00007f8fe1fd0b92  push rdx
00007f8fe1fd0b93  push rdi
00007f8fe1fd0b94  push rsi
00007f8fe1fd0b95  push r8
00007f8fe1fd0b97  push r9
00007f8fe1fd0b99  push r10
00007f8fe1fd0b9b  push r11
00007f8fe1fd0b9d  sub rsp, 0xF0
00007f8fe1fd0ba4  vmovaps [rsp], xmm0
00007f8fe1fd0ba9  vmovaps [rsp+0x10], xmm1
00007f8fe1fd0baf  vmovaps [rsp+0x20], xmm2
00007f8fe1fd0bb5  vmovaps [rsp+0x30], xmm3
00007f8fe1fd0bbb  vmovaps [rsp+0x40], xmm4
00007f8fe1fd0bc1  vmovaps [rsp+0x50], xmm5
00007f8fe1fd0bc7  vmovaps [rsp+0x60], xmm6
00007f8fe1fd0bcd  vmovaps [rsp+0x70], xmm7
00007f8fe1fd0bd3  vmovaps [rsp+0x80], xmm8
00007f8fe1fd0bdc  vmovaps [rsp+0x90], xmm9
00007f8fe1fd0be5  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd0bee  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd0bf7  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd0c00  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd0c09  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd0c12  sub rsp, 0x30
00007f8fe1fd0c16  movaps [rsp], xmm13
00007f8fe1fd0c1b  movaps [rsp+0x10], xmm14
00007f8fe1fd0c21  movaps [rsp+0x20], xmm2
00007f8fe1fd0c26  lea rdi, [rsp]
00007f8fe1fd0c2a  mov esi, 0x00
00007f8fe1fd0c2f  mov rax, 0x6020BB77F530
00007f8fe1fd0c39  call rax
00007f8fe1fd0c3b  movaps xmm13, [rsp]
00007f8fe1fd0c40  add rsp, 0x30
00007f8fe1fd0c44  vmovaps xmm0, [rsp]
00007f8fe1fd0c49  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd0c4f  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd0c55  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd0c5b  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd0c61  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd0c67  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd0c6d  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd0c73  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd0c7c  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd0c85  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd0c8e  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd0c97  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd0ca0  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd0ca9  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd0cb2  add rsp, 0xF0
00007f8fe1fd0cb9  pop r11
00007f8fe1fd0cbb  pop r10
00007f8fe1fd0cbd  pop r9
00007f8fe1fd0cbf  pop r8
00007f8fe1fd0cc1  pop rsi
00007f8fe1fd0cc2  pop rdi
00007f8fe1fd0cc3  pop rdx
00007f8fe1fd0cc4  pop rcx
00007f8fe1fd0cc5  pop rax
00007f8fe1fd0cc6  add rsp, 0x08
00007f8fe1fd0cca  jmp 0x00007F8FE1FCF64C
00007f8fe1fd0ccf  sub rsp, 0x08
00007f8fe1fd0cd3  push rax
00007f8fe1fd0cd4  push rcx
00007f8fe1fd0cd5  push rdx
00007f8fe1fd0cd6  push rdi
00007f8fe1fd0cd7  push rsi
00007f8fe1fd0cd8  push r8
00007f8fe1fd0cda  push r9
00007f8fe1fd0cdc  push r10
00007f8fe1fd0cde  push r11
00007f8fe1fd0ce0  sub rsp, 0xF0
00007f8fe1fd0ce7  vmovaps [rsp], xmm0
00007f8fe1fd0cec  vmovaps [rsp+0x10], xmm2
00007f8fe1fd0cf2  vmovaps [rsp+0x20], xmm3
00007f8fe1fd0cf8  vmovaps [rsp+0x30], xmm4
00007f8fe1fd0cfe  vmovaps [rsp+0x40], xmm5
00007f8fe1fd0d04  vmovaps [rsp+0x50], xmm6
00007f8fe1fd0d0a  vmovaps [rsp+0x60], xmm7
00007f8fe1fd0d10  vmovaps [rsp+0x70], xmm8
00007f8fe1fd0d16  vmovaps [rsp+0x80], xmm9
00007f8fe1fd0d1f  vmovaps [rsp+0x90], xmm10
00007f8fe1fd0d28  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd0d31  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd0d3a  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd0d43  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd0d4c  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd0d55  sub rsp, 0x30
00007f8fe1fd0d59  movaps [rsp], xmm1
00007f8fe1fd0d5d  movaps [rsp+0x10], xmm10
00007f8fe1fd0d63  movaps [rsp+0x20], xmm2
00007f8fe1fd0d68  lea rdi, [rsp]
00007f8fe1fd0d6c  mov esi, 0x00
00007f8fe1fd0d71  mov rax, 0x6020BB77F530
00007f8fe1fd0d7b  call rax
00007f8fe1fd0d7d  movaps xmm1, [rsp]
00007f8fe1fd0d81  add rsp, 0x30
00007f8fe1fd0d85  vmovaps xmm0, [rsp]
00007f8fe1fd0d8a  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd0d90  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd0d96  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd0d9c  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd0da2  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd0da8  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd0dae  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd0db4  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd0dbd  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd0dc6  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd0dcf  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd0dd8  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd0de1  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd0dea  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd0df3  add rsp, 0xF0
00007f8fe1fd0dfa  pop r11
00007f8fe1fd0dfc  pop r10
00007f8fe1fd0dfe  pop r9
00007f8fe1fd0e00  pop r8
00007f8fe1fd0e02  pop rsi
00007f8fe1fd0e03  pop rdi
00007f8fe1fd0e04  pop rdx
00007f8fe1fd0e05  pop rcx
00007f8fe1fd0e06  pop rax
00007f8fe1fd0e07  add rsp, 0x08
00007f8fe1fd0e0b  jmp 0x00007F8FE1FCF6B4
00007f8fe1fd0e10  sub rsp, 0x08
00007f8fe1fd0e14  push rax
00007f8fe1fd0e15  push rcx
00007f8fe1fd0e16  push rdx
00007f8fe1fd0e17  push rdi
00007f8fe1fd0e18  push rsi
00007f8fe1fd0e19  push r8
00007f8fe1fd0e1b  push r9
00007f8fe1fd0e1d  push r10
00007f8fe1fd0e1f  push r11
00007f8fe1fd0e21  sub rsp, 0xF0
00007f8fe1fd0e28  vmovaps [rsp], xmm0
00007f8fe1fd0e2d  vmovaps [rsp+0x10], xmm1
00007f8fe1fd0e33  vmovaps [rsp+0x20], xmm2
00007f8fe1fd0e39  vmovaps [rsp+0x30], xmm3
00007f8fe1fd0e3f  vmovaps [rsp+0x40], xmm4
00007f8fe1fd0e45  vmovaps [rsp+0x50], xmm5
00007f8fe1fd0e4b  vmovaps [rsp+0x60], xmm6
00007f8fe1fd0e51  vmovaps [rsp+0x70], xmm7
00007f8fe1fd0e57  vmovaps [rsp+0x80], xmm8
00007f8fe1fd0e60  vmovaps [rsp+0x90], xmm9
00007f8fe1fd0e69  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd0e72  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd0e7b  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd0e84  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd0e8d  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd0e96  sub rsp, 0x30
00007f8fe1fd0e9a  movaps [rsp], xmm15
00007f8fe1fd0e9f  movaps [rsp+0x10], xmm10
00007f8fe1fd0ea5  movaps [rsp+0x20], xmm2
00007f8fe1fd0eaa  lea rdi, [rsp]
00007f8fe1fd0eae  mov esi, 0x00
00007f8fe1fd0eb3  mov rax, 0x6020BB77F530
00007f8fe1fd0ebd  call rax
00007f8fe1fd0ebf  movaps xmm15, [rsp]
00007f8fe1fd0ec4  add rsp, 0x30
00007f8fe1fd0ec8  vmovaps xmm0, [rsp]
00007f8fe1fd0ecd  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd0ed3  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd0ed9  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd0edf  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd0ee5  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd0eeb  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd0ef1  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd0ef7  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd0f00  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd0f09  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd0f12  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd0f1b  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd0f24  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd0f2d  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd0f36  add rsp, 0xF0
00007f8fe1fd0f3d  pop r11
00007f8fe1fd0f3f  pop r10
00007f8fe1fd0f41  pop r9
00007f8fe1fd0f43  pop r8
00007f8fe1fd0f45  pop rsi
00007f8fe1fd0f46  pop rdi
00007f8fe1fd0f47  pop rdx
00007f8fe1fd0f48  pop rcx
00007f8fe1fd0f49  pop rax
00007f8fe1fd0f4a  add rsp, 0x08
00007f8fe1fd0f4e  jmp 0x00007F8FE1FCF706
00007f8fe1fd0f53  sub rsp, 0x08
00007f8fe1fd0f57  push rax
00007f8fe1fd0f58  push rcx
00007f8fe1fd0f59  push rdx
00007f8fe1fd0f5a  push rdi
00007f8fe1fd0f5b  push rsi
00007f8fe1fd0f5c  push r8
00007f8fe1fd0f5e  push r9
00007f8fe1fd0f60  push r10
00007f8fe1fd0f62  push r11
00007f8fe1fd0f64  sub rsp, 0xF0
00007f8fe1fd0f6b  vmovaps [rsp], xmm0
00007f8fe1fd0f70  vmovaps [rsp+0x10], xmm2
00007f8fe1fd0f76  vmovaps [rsp+0x20], xmm3
00007f8fe1fd0f7c  vmovaps [rsp+0x30], xmm4
00007f8fe1fd0f82  vmovaps [rsp+0x40], xmm5
00007f8fe1fd0f88  vmovaps [rsp+0x50], xmm6
00007f8fe1fd0f8e  vmovaps [rsp+0x60], xmm7
00007f8fe1fd0f94  vmovaps [rsp+0x70], xmm8
00007f8fe1fd0f9a  vmovaps [rsp+0x80], xmm9
00007f8fe1fd0fa3  vmovaps [rsp+0x90], xmm10
00007f8fe1fd0fac  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd0fb5  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd0fbe  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd0fc7  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd0fd0  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd0fd9  sub rsp, 0x30
00007f8fe1fd0fdd  movaps [rsp], xmm1
00007f8fe1fd0fe1  movaps [rsp+0x10], xmm10
00007f8fe1fd0fe7  movaps [rsp+0x20], xmm12
00007f8fe1fd0fed  lea rdi, [rsp]
00007f8fe1fd0ff1  mov esi, 0x00
00007f8fe1fd0ff6  mov rax, 0x6020BB77F530
00007f8fe1fd1000  call rax
00007f8fe1fd1002  movaps xmm1, [rsp]
00007f8fe1fd1006  add rsp, 0x30
00007f8fe1fd100a  vmovaps xmm0, [rsp]
00007f8fe1fd100f  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd1015  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd101b  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd1021  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd1027  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd102d  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd1033  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd1039  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd1042  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd104b  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd1054  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd105d  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd1066  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd106f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd1078  add rsp, 0xF0
00007f8fe1fd107f  pop r11
00007f8fe1fd1081  pop r10
00007f8fe1fd1083  pop r9
00007f8fe1fd1085  pop r8
00007f8fe1fd1087  pop rsi
00007f8fe1fd1088  pop rdi
00007f8fe1fd1089  pop rdx
00007f8fe1fd108a  pop rcx
00007f8fe1fd108b  pop rax
00007f8fe1fd108c  add rsp, 0x08
00007f8fe1fd1090  jmp 0x00007F8FE1FCF732
00007f8fe1fd1095  sub rsp, 0x08
00007f8fe1fd1099  push rax
00007f8fe1fd109a  push rcx
00007f8fe1fd109b  push rdx
00007f8fe1fd109c  push rdi
00007f8fe1fd109d  push rsi
00007f8fe1fd109e  push r8
00007f8fe1fd10a0  push r9
00007f8fe1fd10a2  push r10
00007f8fe1fd10a4  push r11
00007f8fe1fd10a6  sub rsp, 0xF0
00007f8fe1fd10ad  vmovaps [rsp], xmm0
00007f8fe1fd10b2  vmovaps [rsp+0x10], xmm1
00007f8fe1fd10b8  vmovaps [rsp+0x20], xmm2
00007f8fe1fd10be  vmovaps [rsp+0x30], xmm3
00007f8fe1fd10c4  vmovaps [rsp+0x40], xmm4
00007f8fe1fd10ca  vmovaps [rsp+0x50], xmm5
00007f8fe1fd10d0  vmovaps [rsp+0x60], xmm6
00007f8fe1fd10d6  vmovaps [rsp+0x70], xmm7
00007f8fe1fd10dc  vmovaps [rsp+0x80], xmm8
00007f8fe1fd10e5  vmovaps [rsp+0x90], xmm9
00007f8fe1fd10ee  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd10f7  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd1100  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd1109  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd1112  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd111b  sub rsp, 0x30
00007f8fe1fd111f  movaps [rsp], xmm15
00007f8fe1fd1124  movaps [rsp+0x10], xmm10
00007f8fe1fd112a  movaps [rsp+0x20], xmm12
00007f8fe1fd1130  lea rdi, [rsp]
00007f8fe1fd1134  mov esi, 0x00
00007f8fe1fd1139  mov rax, 0x6020BB77F530
00007f8fe1fd1143  call rax
00007f8fe1fd1145  movaps xmm15, [rsp]
00007f8fe1fd114a  add rsp, 0x30
00007f8fe1fd114e  vmovaps xmm0, [rsp]
00007f8fe1fd1153  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd1159  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd115f  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd1165  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd116b  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd1171  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd1177  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd117d  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd1186  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd118f  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd1198  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd11a1  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd11aa  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd11b3  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd11bc  add rsp, 0xF0
00007f8fe1fd11c3  pop r11
00007f8fe1fd11c5  pop r10
00007f8fe1fd11c7  pop r9
00007f8fe1fd11c9  pop r8
00007f8fe1fd11cb  pop rsi
00007f8fe1fd11cc  pop rdi
00007f8fe1fd11cd  pop rdx
00007f8fe1fd11ce  pop rcx
00007f8fe1fd11cf  pop rax
00007f8fe1fd11d0  add rsp, 0x08
00007f8fe1fd11d4  jmp 0x00007F8FE1FCF75E
00007f8fe1fd11d9  call 0x00007F8FE1DFF430
00007f8fe1fd11de  jmp 0x00007F8FE1FCF7EE
00007f8fe1fd11e3  call 0x00007F8FE1DFF430
00007f8fe1fd11e8  jmp 0x00007F8FE1FCF801
00007f8fe1fd11ed  sub rsp, 0x08
00007f8fe1fd11f1  push rax
00007f8fe1fd11f2  push rcx
00007f8fe1fd11f3  push rdx
00007f8fe1fd11f4  push rdi
00007f8fe1fd11f5  push rsi
00007f8fe1fd11f6  push r8
00007f8fe1fd11f8  push r9
00007f8fe1fd11fa  push r10
00007f8fe1fd11fc  push r11
00007f8fe1fd11fe  sub rsp, 0xF0
00007f8fe1fd1205  vmovaps [rsp], xmm0
00007f8fe1fd120a  vmovaps [rsp+0x10], xmm2
00007f8fe1fd1210  vmovaps [rsp+0x20], xmm3
00007f8fe1fd1216  vmovaps [rsp+0x30], xmm4
00007f8fe1fd121c  vmovaps [rsp+0x40], xmm5
00007f8fe1fd1222  vmovaps [rsp+0x50], xmm6
00007f8fe1fd1228  vmovaps [rsp+0x60], xmm7
00007f8fe1fd122e  vmovaps [rsp+0x70], xmm8
00007f8fe1fd1234  vmovaps [rsp+0x80], xmm9
00007f8fe1fd123d  vmovaps [rsp+0x90], xmm10
00007f8fe1fd1246  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd124f  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd1258  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd1261  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd126a  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd1273  sub rsp, 0x30
00007f8fe1fd1277  movaps [rsp], xmm1
00007f8fe1fd127b  movaps [rsp+0x10], xmm13
00007f8fe1fd1281  movaps [rsp+0x20], xmm2
00007f8fe1fd1286  lea rdi, [rsp]
00007f8fe1fd128a  mov esi, 0x00
00007f8fe1fd128f  mov rax, 0x6020BB77F530
00007f8fe1fd1299  call rax
00007f8fe1fd129b  movaps xmm1, [rsp]
00007f8fe1fd129f  add rsp, 0x30
00007f8fe1fd12a3  vmovaps xmm0, [rsp]
00007f8fe1fd12a8  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd12ae  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd12b4  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd12ba  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd12c0  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd12c6  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd12cc  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd12d2  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd12db  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd12e4  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd12ed  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd12f6  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd12ff  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd1308  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd1311  add rsp, 0xF0
00007f8fe1fd1318  pop r11
00007f8fe1fd131a  pop r10
00007f8fe1fd131c  pop r9
00007f8fe1fd131e  pop r8
00007f8fe1fd1320  pop rsi
00007f8fe1fd1321  pop rdi
00007f8fe1fd1322  pop rdx
00007f8fe1fd1323  pop rcx
00007f8fe1fd1324  pop rax
00007f8fe1fd1325  add rsp, 0x08
00007f8fe1fd1329  jmp 0x00007F8FE1FCF82C
00007f8fe1fd132e  call 0x00007F8FE1E0E760
00007f8fe1fd1333  jmp 0x00007F8FE1FCF839
00007f8fe1fd1338  sub rsp, 0x08
00007f8fe1fd133c  push rax
00007f8fe1fd133d  push rcx
00007f8fe1fd133e  push rdx
00007f8fe1fd133f  push rdi
00007f8fe1fd1340  push rsi
00007f8fe1fd1341  push r8
00007f8fe1fd1343  push r9
00007f8fe1fd1345  push r10
00007f8fe1fd1347  push r11
00007f8fe1fd1349  sub rsp, 0xF0
00007f8fe1fd1350  vmovaps [rsp], xmm0
00007f8fe1fd1355  vmovaps [rsp+0x10], xmm1
00007f8fe1fd135b  vmovaps [rsp+0x20], xmm2
00007f8fe1fd1361  vmovaps [rsp+0x30], xmm3
00007f8fe1fd1367  vmovaps [rsp+0x40], xmm4
00007f8fe1fd136d  vmovaps [rsp+0x50], xmm5
00007f8fe1fd1373  vmovaps [rsp+0x60], xmm6
00007f8fe1fd1379  vmovaps [rsp+0x70], xmm7
00007f8fe1fd137f  vmovaps [rsp+0x80], xmm8
00007f8fe1fd1388  vmovaps [rsp+0x90], xmm9
00007f8fe1fd1391  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd139a  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd13a3  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd13ac  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd13b5  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd13be  sub rsp, 0x30
00007f8fe1fd13c2  movaps [rsp], xmm13
00007f8fe1fd13c7  movaps [rsp+0x10], xmm2
00007f8fe1fd13cc  movaps [rsp+0x20], xmm1
00007f8fe1fd13d1  lea rdi, [rsp]
00007f8fe1fd13d5  mov esi, 0x00
00007f8fe1fd13da  mov rax, 0x6020BB77F530
00007f8fe1fd13e4  call rax
00007f8fe1fd13e6  movaps xmm13, [rsp]
00007f8fe1fd13eb  add rsp, 0x30
00007f8fe1fd13ef  vmovaps xmm0, [rsp]
00007f8fe1fd13f4  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd13fa  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd1400  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd1406  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd140c  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd1412  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd1418  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd141e  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd1427  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd1430  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd1439  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd1442  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd144b  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd1454  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd145d  add rsp, 0xF0
00007f8fe1fd1464  pop r11
00007f8fe1fd1466  pop r10
00007f8fe1fd1468  pop r9
00007f8fe1fd146a  pop r8
00007f8fe1fd146c  pop rsi
00007f8fe1fd146d  pop rdi
00007f8fe1fd146e  pop rdx
00007f8fe1fd146f  pop rcx
00007f8fe1fd1470  pop rax
00007f8fe1fd1471  add rsp, 0x08
00007f8fe1fd1475  jmp 0x00007F8FE1FCF878
00007f8fe1fd147a  sub rsp, 0x08
00007f8fe1fd147e  push rax
00007f8fe1fd147f  push rcx
00007f8fe1fd1480  push rdx
00007f8fe1fd1481  push rdi
00007f8fe1fd1482  push rsi
00007f8fe1fd1483  push r8
00007f8fe1fd1485  push r9
00007f8fe1fd1487  push r10
00007f8fe1fd1489  push r11
00007f8fe1fd148b  sub rsp, 0xF0
00007f8fe1fd1492  vmovaps [rsp], xmm0
00007f8fe1fd1497  vmovaps [rsp+0x10], xmm2
00007f8fe1fd149d  vmovaps [rsp+0x20], xmm3
00007f8fe1fd14a3  vmovaps [rsp+0x30], xmm4
00007f8fe1fd14a9  vmovaps [rsp+0x40], xmm5
00007f8fe1fd14af  vmovaps [rsp+0x50], xmm6
00007f8fe1fd14b5  vmovaps [rsp+0x60], xmm7
00007f8fe1fd14bb  vmovaps [rsp+0x70], xmm8
00007f8fe1fd14c1  vmovaps [rsp+0x80], xmm9
00007f8fe1fd14ca  vmovaps [rsp+0x90], xmm10
00007f8fe1fd14d3  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd14dc  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd14e5  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd14ee  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd14f7  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd1500  sub rsp, 0x30
00007f8fe1fd1504  movaps [rsp], xmm1
00007f8fe1fd1508  movaps [rsp+0x10], xmm15
00007f8fe1fd150e  movaps [rsp+0x20], xmm2
00007f8fe1fd1513  lea rdi, [rsp]
00007f8fe1fd1517  mov esi, 0x00
00007f8fe1fd151c  mov rax, 0x6020BB77F530
00007f8fe1fd1526  call rax
00007f8fe1fd1528  movaps xmm1, [rsp]
00007f8fe1fd152c  add rsp, 0x30
00007f8fe1fd1530  vmovaps xmm0, [rsp]
00007f8fe1fd1535  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd153b  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd1541  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd1547  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd154d  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd1553  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd1559  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd155f  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd1568  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd1571  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd157a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd1583  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd158c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd1595  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd159e  add rsp, 0xF0
00007f8fe1fd15a5  pop r11
00007f8fe1fd15a7  pop r10
00007f8fe1fd15a9  pop r9
00007f8fe1fd15ab  pop r8
00007f8fe1fd15ad  pop rsi
00007f8fe1fd15ae  pop rdi
00007f8fe1fd15af  pop rdx
00007f8fe1fd15b0  pop rcx
00007f8fe1fd15b1  pop rax
00007f8fe1fd15b2  add rsp, 0x08
00007f8fe1fd15b6  jmp 0x00007F8FE1FCF8AC
00007f8fe1fd15bb  sub rsp, 0x08
00007f8fe1fd15bf  push rax
00007f8fe1fd15c0  push rcx
00007f8fe1fd15c1  push rdx
00007f8fe1fd15c2  push rdi
00007f8fe1fd15c3  push rsi
00007f8fe1fd15c4  push r8
00007f8fe1fd15c6  push r9
00007f8fe1fd15c8  push r10
00007f8fe1fd15ca  push r11
00007f8fe1fd15cc  sub rsp, 0xF0
00007f8fe1fd15d3  vmovaps [rsp], xmm0
00007f8fe1fd15d8  vmovaps [rsp+0x10], xmm1
00007f8fe1fd15de  vmovaps [rsp+0x20], xmm2
00007f8fe1fd15e4  vmovaps [rsp+0x30], xmm3
00007f8fe1fd15ea  vmovaps [rsp+0x40], xmm4
00007f8fe1fd15f0  vmovaps [rsp+0x50], xmm5
00007f8fe1fd15f6  vmovaps [rsp+0x60], xmm6
00007f8fe1fd15fc  vmovaps [rsp+0x70], xmm7
00007f8fe1fd1602  vmovaps [rsp+0x80], xmm8
00007f8fe1fd160b  vmovaps [rsp+0x90], xmm9
00007f8fe1fd1614  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd161d  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd1626  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd162f  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd1638  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd1641  sub rsp, 0x30
00007f8fe1fd1645  movaps [rsp], xmm14
00007f8fe1fd164a  movaps [rsp+0x10], xmm2
00007f8fe1fd164f  movaps [rsp+0x20], xmm15
00007f8fe1fd1655  lea rdi, [rsp]
00007f8fe1fd1659  mov esi, 0x00
00007f8fe1fd165e  mov rax, 0x6020BB77F530
00007f8fe1fd1668  call rax
00007f8fe1fd166a  movaps xmm14, [rsp]
00007f8fe1fd166f  add rsp, 0x30
00007f8fe1fd1673  vmovaps xmm0, [rsp]
00007f8fe1fd1678  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd167e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd1684  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd168a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd1690  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd1696  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd169c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd16a2  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd16ab  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd16b4  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd16bd  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd16c6  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd16cf  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd16d8  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd16e1  add rsp, 0xF0
00007f8fe1fd16e8  pop r11
00007f8fe1fd16ea  pop r10
00007f8fe1fd16ec  pop r9
00007f8fe1fd16ee  pop r8
00007f8fe1fd16f0  pop rsi
00007f8fe1fd16f1  pop rdi
00007f8fe1fd16f2  pop rdx
00007f8fe1fd16f3  pop rcx
00007f8fe1fd16f4  pop rax
00007f8fe1fd16f5  add rsp, 0x08
00007f8fe1fd16f9  jmp 0x00007F8FE1FCF8E7
00007f8fe1fd16fe  sub rsp, 0x08
00007f8fe1fd1702  push rax
00007f8fe1fd1703  push rcx
00007f8fe1fd1704  push rdx
00007f8fe1fd1705  push rdi
00007f8fe1fd1706  push rsi
00007f8fe1fd1707  push r8
00007f8fe1fd1709  push r9
00007f8fe1fd170b  push r10
00007f8fe1fd170d  push r11
00007f8fe1fd170f  sub rsp, 0xF0
00007f8fe1fd1716  vmovaps [rsp], xmm0
00007f8fe1fd171b  vmovaps [rsp+0x10], xmm1
00007f8fe1fd1721  vmovaps [rsp+0x20], xmm2
00007f8fe1fd1727  vmovaps [rsp+0x30], xmm3
00007f8fe1fd172d  vmovaps [rsp+0x40], xmm4
00007f8fe1fd1733  vmovaps [rsp+0x50], xmm5
00007f8fe1fd1739  vmovaps [rsp+0x60], xmm6
00007f8fe1fd173f  vmovaps [rsp+0x70], xmm7
00007f8fe1fd1745  vmovaps [rsp+0x80], xmm8
00007f8fe1fd174e  vmovaps [rsp+0x90], xmm9
00007f8fe1fd1757  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd1760  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd1769  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd1772  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd177b  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd1784  sub rsp, 0x30
00007f8fe1fd1788  movaps [rsp], xmm15
00007f8fe1fd178d  movaps [rsp+0x10], xmm2
00007f8fe1fd1792  movaps [rsp+0x20], xmm1
00007f8fe1fd1797  lea rdi, [rsp]
00007f8fe1fd179b  mov esi, 0x00
00007f8fe1fd17a0  mov rax, 0x6020BB77F530
00007f8fe1fd17aa  call rax
00007f8fe1fd17ac  movaps xmm15, [rsp]
00007f8fe1fd17b1  add rsp, 0x30
00007f8fe1fd17b5  vmovaps xmm0, [rsp]
00007f8fe1fd17ba  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd17c0  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd17c6  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd17cc  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd17d2  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd17d8  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd17de  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd17e4  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd17ed  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd17f6  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd17ff  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd1808  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd1811  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd181a  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd1823  add rsp, 0xF0
00007f8fe1fd182a  pop r11
00007f8fe1fd182c  pop r10
00007f8fe1fd182e  pop r9
00007f8fe1fd1830  pop r8
00007f8fe1fd1832  pop rsi
00007f8fe1fd1833  pop rdi
00007f8fe1fd1834  pop rdx
00007f8fe1fd1835  pop rcx
00007f8fe1fd1836  pop rax
00007f8fe1fd1837  add rsp, 0x08
00007f8fe1fd183b  jmp 0x00007F8FE1FCF923
00007f8fe1fd1840  call 0x00007F8FE1DFF430
00007f8fe1fd1845  jmp 0x00007F8FE1FCF930
00007f8fe1fd184a  sub rsp, 0x08
00007f8fe1fd184e  push rax
00007f8fe1fd184f  push rcx
00007f8fe1fd1850  push rdx
00007f8fe1fd1851  push rdi
00007f8fe1fd1852  push rsi
00007f8fe1fd1853  push r8
00007f8fe1fd1855  push r9
00007f8fe1fd1857  push r10
00007f8fe1fd1859  push r11
00007f8fe1fd185b  sub rsp, 0xF0
00007f8fe1fd1862  vmovaps [rsp], xmm0
00007f8fe1fd1867  vmovaps [rsp+0x10], xmm1
00007f8fe1fd186d  vmovaps [rsp+0x20], xmm3
00007f8fe1fd1873  vmovaps [rsp+0x30], xmm4
00007f8fe1fd1879  vmovaps [rsp+0x40], xmm5
00007f8fe1fd187f  vmovaps [rsp+0x50], xmm6
00007f8fe1fd1885  vmovaps [rsp+0x60], xmm7
00007f8fe1fd188b  vmovaps [rsp+0x70], xmm8
00007f8fe1fd1891  vmovaps [rsp+0x80], xmm9
00007f8fe1fd189a  vmovaps [rsp+0x90], xmm10
00007f8fe1fd18a3  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd18ac  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd18b5  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd18be  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd18c7  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd18d0  sub rsp, 0x30
00007f8fe1fd18d4  movaps [rsp], xmm2
00007f8fe1fd18d8  movaps [rsp+0x10], xmm1
00007f8fe1fd18dd  movaps [rsp+0x20], xmm14
00007f8fe1fd18e3  lea rdi, [rsp]
00007f8fe1fd18e7  mov esi, 0x00
00007f8fe1fd18ec  mov rax, 0x6020BB77F530
00007f8fe1fd18f6  call rax
00007f8fe1fd18f8  movaps xmm2, [rsp]
00007f8fe1fd18fc  add rsp, 0x30
00007f8fe1fd1900  vmovaps xmm0, [rsp]
00007f8fe1fd1905  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd190b  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd1911  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd1917  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd191d  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd1923  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd1929  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd192f  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd1938  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd1941  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd194a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd1953  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd195c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd1965  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd196e  add rsp, 0xF0
00007f8fe1fd1975  pop r11
00007f8fe1fd1977  pop r10
00007f8fe1fd1979  pop r9
00007f8fe1fd197b  pop r8
00007f8fe1fd197d  pop rsi
00007f8fe1fd197e  pop rdi
00007f8fe1fd197f  pop rdx
00007f8fe1fd1980  pop rcx
00007f8fe1fd1981  pop rax
00007f8fe1fd1982  add rsp, 0x08
00007f8fe1fd1986  jmp 0x00007F8FE1FCF96D
00007f8fe1fd198b  sub rsp, 0x08
00007f8fe1fd198f  push rax
00007f8fe1fd1990  push rcx
00007f8fe1fd1991  push rdx
00007f8fe1fd1992  push rdi
00007f8fe1fd1993  push rsi
00007f8fe1fd1994  push r8
00007f8fe1fd1996  push r9
00007f8fe1fd1998  push r10
00007f8fe1fd199a  push r11
00007f8fe1fd199c  sub rsp, 0xF0
00007f8fe1fd19a3  vmovaps [rsp], xmm0
00007f8fe1fd19a8  vmovaps [rsp+0x10], xmm1
00007f8fe1fd19ae  vmovaps [rsp+0x20], xmm2
00007f8fe1fd19b4  vmovaps [rsp+0x30], xmm3
00007f8fe1fd19ba  vmovaps [rsp+0x40], xmm4
00007f8fe1fd19c0  vmovaps [rsp+0x50], xmm5
00007f8fe1fd19c6  vmovaps [rsp+0x60], xmm6
00007f8fe1fd19cc  vmovaps [rsp+0x70], xmm7
00007f8fe1fd19d2  vmovaps [rsp+0x80], xmm8
00007f8fe1fd19db  vmovaps [rsp+0x90], xmm9
00007f8fe1fd19e4  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd19ed  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd19f6  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd19ff  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd1a08  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd1a11  sub rsp, 0x30
00007f8fe1fd1a15  movaps [rsp], xmm15
00007f8fe1fd1a1a  movaps [rsp+0x10], xmm14
00007f8fe1fd1a20  movaps [rsp+0x20], xmm1
00007f8fe1fd1a25  lea rdi, [rsp]
00007f8fe1fd1a29  mov esi, 0x00
00007f8fe1fd1a2e  mov rax, 0x6020BB77F530
00007f8fe1fd1a38  call rax
00007f8fe1fd1a3a  movaps xmm15, [rsp]
00007f8fe1fd1a3f  add rsp, 0x30
00007f8fe1fd1a43  vmovaps xmm0, [rsp]
00007f8fe1fd1a48  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd1a4e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd1a54  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd1a5a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd1a60  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd1a66  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd1a6c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd1a72  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd1a7b  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd1a84  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd1a8d  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd1a96  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd1a9f  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd1aa8  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd1ab1  add rsp, 0xF0
00007f8fe1fd1ab8  pop r11
00007f8fe1fd1aba  pop r10
00007f8fe1fd1abc  pop r9
00007f8fe1fd1abe  pop r8
00007f8fe1fd1ac0  pop rsi
00007f8fe1fd1ac1  pop rdi
00007f8fe1fd1ac2  pop rdx
00007f8fe1fd1ac3  pop rcx
00007f8fe1fd1ac4  pop rax
00007f8fe1fd1ac5  add rsp, 0x08
00007f8fe1fd1ac9  jmp 0x00007F8FE1FCF9E7
00007f8fe1fd1ace  call 0x00007F8FE1DFF430
00007f8fe1fd1ad3  jmp 0x00007F8FE1FCF9F4
00007f8fe1fd1ad8  sub rsp, 0x08
00007f8fe1fd1adc  push rax
00007f8fe1fd1add  push rcx
00007f8fe1fd1ade  push rdx
00007f8fe1fd1adf  push rdi
00007f8fe1fd1ae0  push rsi
00007f8fe1fd1ae1  push r8
00007f8fe1fd1ae3  push r9
00007f8fe1fd1ae5  push r10
00007f8fe1fd1ae7  push r11
00007f8fe1fd1ae9  sub rsp, 0xF0
00007f8fe1fd1af0  vmovaps [rsp], xmm0
00007f8fe1fd1af5  vmovaps [rsp+0x10], xmm1
00007f8fe1fd1afb  vmovaps [rsp+0x20], xmm2
00007f8fe1fd1b01  vmovaps [rsp+0x30], xmm3
00007f8fe1fd1b07  vmovaps [rsp+0x40], xmm4
00007f8fe1fd1b0d  vmovaps [rsp+0x50], xmm5
00007f8fe1fd1b13  vmovaps [rsp+0x60], xmm6
00007f8fe1fd1b19  vmovaps [rsp+0x70], xmm7
00007f8fe1fd1b1f  vmovaps [rsp+0x80], xmm8
00007f8fe1fd1b28  vmovaps [rsp+0x90], xmm9
00007f8fe1fd1b31  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd1b3a  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd1b43  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd1b4c  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd1b55  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd1b5e  sub rsp, 0x30
00007f8fe1fd1b62  movaps [rsp], xmm14
00007f8fe1fd1b67  movaps [rsp+0x10], xmm13
00007f8fe1fd1b6d  movaps [rsp+0x20], xmm1
00007f8fe1fd1b72  lea rdi, [rsp]
00007f8fe1fd1b76  mov esi, 0x00
00007f8fe1fd1b7b  mov rax, 0x6020BB77F530
00007f8fe1fd1b85  call rax
00007f8fe1fd1b87  movaps xmm14, [rsp]
00007f8fe1fd1b8c  add rsp, 0x30
00007f8fe1fd1b90  vmovaps xmm0, [rsp]
00007f8fe1fd1b95  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd1b9b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd1ba1  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd1ba7  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd1bad  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd1bb3  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd1bb9  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd1bbf  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd1bc8  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd1bd1  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd1bda  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd1be3  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd1bec  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd1bf5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd1bfe  add rsp, 0xF0
00007f8fe1fd1c05  pop r11
00007f8fe1fd1c07  pop r10
00007f8fe1fd1c09  pop r9
00007f8fe1fd1c0b  pop r8
00007f8fe1fd1c0d  pop rsi
00007f8fe1fd1c0e  pop rdi
00007f8fe1fd1c0f  pop rdx
00007f8fe1fd1c10  pop rcx
00007f8fe1fd1c11  pop rax
00007f8fe1fd1c12  add rsp, 0x08
00007f8fe1fd1c16  jmp 0x00007F8FE1FCFAAF
00007f8fe1fd1c1b  sub rsp, 0x08
00007f8fe1fd1c1f  push rax
00007f8fe1fd1c20  push rcx
00007f8fe1fd1c21  push rdx
00007f8fe1fd1c22  push rdi
00007f8fe1fd1c23  push rsi
00007f8fe1fd1c24  push r8
00007f8fe1fd1c26  push r9
00007f8fe1fd1c28  push r10
00007f8fe1fd1c2a  push r11
00007f8fe1fd1c2c  sub rsp, 0xF0
00007f8fe1fd1c33  vmovaps [rsp], xmm0
00007f8fe1fd1c38  vmovaps [rsp+0x10], xmm1
00007f8fe1fd1c3e  vmovaps [rsp+0x20], xmm2
00007f8fe1fd1c44  vmovaps [rsp+0x30], xmm3
00007f8fe1fd1c4a  vmovaps [rsp+0x40], xmm4
00007f8fe1fd1c50  vmovaps [rsp+0x50], xmm5
00007f8fe1fd1c56  vmovaps [rsp+0x60], xmm6
00007f8fe1fd1c5c  vmovaps [rsp+0x70], xmm7
00007f8fe1fd1c62  vmovaps [rsp+0x80], xmm8
00007f8fe1fd1c6b  vmovaps [rsp+0x90], xmm9
00007f8fe1fd1c74  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd1c7d  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd1c86  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd1c8f  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd1c98  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd1ca1  sub rsp, 0x30
00007f8fe1fd1ca5  movaps [rsp], xmm15
00007f8fe1fd1caa  movaps [rsp+0x10], xmm13
00007f8fe1fd1cb0  movaps [rsp+0x20], xmm1
00007f8fe1fd1cb5  lea rdi, [rsp]
00007f8fe1fd1cb9  mov esi, 0x00
00007f8fe1fd1cbe  mov rax, 0x6020BB77F530
00007f8fe1fd1cc8  call rax
00007f8fe1fd1cca  movaps xmm15, [rsp]
00007f8fe1fd1ccf  add rsp, 0x30
00007f8fe1fd1cd3  vmovaps xmm0, [rsp]
00007f8fe1fd1cd8  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd1cde  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd1ce4  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd1cea  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd1cf0  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd1cf6  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd1cfc  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd1d02  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd1d0b  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd1d14  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd1d1d  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd1d26  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd1d2f  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd1d38  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd1d41  add rsp, 0xF0
00007f8fe1fd1d48  pop r11
00007f8fe1fd1d4a  pop r10
00007f8fe1fd1d4c  pop r9
00007f8fe1fd1d4e  pop r8
00007f8fe1fd1d50  pop rsi
00007f8fe1fd1d51  pop rdi
00007f8fe1fd1d52  pop rdx
00007f8fe1fd1d53  pop rcx
00007f8fe1fd1d54  pop rax
00007f8fe1fd1d55  add rsp, 0x08
00007f8fe1fd1d59  jmp 0x00007F8FE1FCFAEB
00007f8fe1fd1d5e  call 0x00007F8FE1DFF430
00007f8fe1fd1d63  jmp 0x00007F8FE1FCFAF8
00007f8fe1fd1d68  sub rsp, 0x08
00007f8fe1fd1d6c  push rax
00007f8fe1fd1d6d  push rcx
00007f8fe1fd1d6e  push rdx
00007f8fe1fd1d6f  push rdi
00007f8fe1fd1d70  push rsi
00007f8fe1fd1d71  push r8
00007f8fe1fd1d73  push r9
00007f8fe1fd1d75  push r10
00007f8fe1fd1d77  push r11
00007f8fe1fd1d79  sub rsp, 0xF0
00007f8fe1fd1d80  vmovaps [rsp], xmm0
00007f8fe1fd1d85  vmovaps [rsp+0x10], xmm1
00007f8fe1fd1d8b  vmovaps [rsp+0x20], xmm2
00007f8fe1fd1d91  vmovaps [rsp+0x30], xmm3
00007f8fe1fd1d97  vmovaps [rsp+0x40], xmm4
00007f8fe1fd1d9d  vmovaps [rsp+0x50], xmm5
00007f8fe1fd1da3  vmovaps [rsp+0x60], xmm6
00007f8fe1fd1da9  vmovaps [rsp+0x70], xmm7
00007f8fe1fd1daf  vmovaps [rsp+0x80], xmm8
00007f8fe1fd1db8  vmovaps [rsp+0x90], xmm9
00007f8fe1fd1dc1  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd1dca  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd1dd3  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd1ddc  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd1de5  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd1dee  sub rsp, 0x30
00007f8fe1fd1df2  movaps [rsp], xmm14
00007f8fe1fd1df7  movaps [rsp+0x10], xmm13
00007f8fe1fd1dfd  movaps [rsp+0x20], xmm2
00007f8fe1fd1e02  lea rdi, [rsp]
00007f8fe1fd1e06  mov esi, 0x00
00007f8fe1fd1e0b  mov rax, 0x6020BB77F530
00007f8fe1fd1e15  call rax
00007f8fe1fd1e17  movaps xmm14, [rsp]
00007f8fe1fd1e1c  add rsp, 0x30
00007f8fe1fd1e20  vmovaps xmm0, [rsp]
00007f8fe1fd1e25  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd1e2b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd1e31  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd1e37  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd1e3d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd1e43  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd1e49  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd1e4f  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd1e58  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd1e61  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd1e6a  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd1e73  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd1e7c  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd1e85  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd1e8e  add rsp, 0xF0
00007f8fe1fd1e95  pop r11
00007f8fe1fd1e97  pop r10
00007f8fe1fd1e99  pop r9
00007f8fe1fd1e9b  pop r8
00007f8fe1fd1e9d  pop rsi
00007f8fe1fd1e9e  pop rdi
00007f8fe1fd1e9f  pop rdx
00007f8fe1fd1ea0  pop rcx
00007f8fe1fd1ea1  pop rax
00007f8fe1fd1ea2  add rsp, 0x08
00007f8fe1fd1ea6  jmp 0x00007F8FE1FCFB24
00007f8fe1fd1eab  sub rsp, 0x08
00007f8fe1fd1eaf  push rax
00007f8fe1fd1eb0  push rcx
00007f8fe1fd1eb1  push rdx
00007f8fe1fd1eb2  push rdi
00007f8fe1fd1eb3  push rsi
00007f8fe1fd1eb4  push r8
00007f8fe1fd1eb6  push r9
00007f8fe1fd1eb8  push r10
00007f8fe1fd1eba  push r11
00007f8fe1fd1ebc  sub rsp, 0xF0
00007f8fe1fd1ec3  vmovaps [rsp], xmm0
00007f8fe1fd1ec8  vmovaps [rsp+0x10], xmm2
00007f8fe1fd1ece  vmovaps [rsp+0x20], xmm3
00007f8fe1fd1ed4  vmovaps [rsp+0x30], xmm4
00007f8fe1fd1eda  vmovaps [rsp+0x40], xmm5
00007f8fe1fd1ee0  vmovaps [rsp+0x50], xmm6
00007f8fe1fd1ee6  vmovaps [rsp+0x60], xmm7
00007f8fe1fd1eec  vmovaps [rsp+0x70], xmm8
00007f8fe1fd1ef2  vmovaps [rsp+0x80], xmm9
00007f8fe1fd1efb  vmovaps [rsp+0x90], xmm10
00007f8fe1fd1f04  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd1f0d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd1f16  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd1f1f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd1f28  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd1f31  sub rsp, 0x30
00007f8fe1fd1f35  movaps [rsp], xmm1
00007f8fe1fd1f39  movaps [rsp+0x10], xmm13
00007f8fe1fd1f3f  movaps [rsp+0x20], xmm2
00007f8fe1fd1f44  lea rdi, [rsp]
00007f8fe1fd1f48  mov esi, 0x00
00007f8fe1fd1f4d  mov rax, 0x6020BB77F530
00007f8fe1fd1f57  call rax
00007f8fe1fd1f59  movaps xmm1, [rsp]
00007f8fe1fd1f5d  add rsp, 0x30
00007f8fe1fd1f61  vmovaps xmm0, [rsp]
00007f8fe1fd1f66  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd1f6c  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd1f72  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd1f78  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd1f7e  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd1f84  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd1f8a  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd1f90  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd1f99  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd1fa2  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd1fab  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd1fb4  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd1fbd  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd1fc6  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd1fcf  add rsp, 0xF0
00007f8fe1fd1fd6  pop r11
00007f8fe1fd1fd8  pop r10
00007f8fe1fd1fda  pop r9
00007f8fe1fd1fdc  pop r8
00007f8fe1fd1fde  pop rsi
00007f8fe1fd1fdf  pop rdi
00007f8fe1fd1fe0  pop rdx
00007f8fe1fd1fe1  pop rcx
00007f8fe1fd1fe2  pop rax
00007f8fe1fd1fe3  add rsp, 0x08
00007f8fe1fd1fe7  jmp 0x00007F8FE1FCFB52
00007f8fe1fd1fec  sub rsp, 0x08
00007f8fe1fd1ff0  push rax
00007f8fe1fd1ff1  push rcx
00007f8fe1fd1ff2  push rdx
00007f8fe1fd1ff3  push rdi
00007f8fe1fd1ff4  push rsi
00007f8fe1fd1ff5  push r8
00007f8fe1fd1ff7  push r9
00007f8fe1fd1ff9  push r10
00007f8fe1fd1ffb  push r11
00007f8fe1fd1ffd  sub rsp, 0xF0
00007f8fe1fd2004  vmovaps [rsp], xmm0
00007f8fe1fd2009  vmovaps [rsp+0x10], xmm1
00007f8fe1fd200f  vmovaps [rsp+0x20], xmm3
00007f8fe1fd2015  vmovaps [rsp+0x30], xmm4
00007f8fe1fd201b  vmovaps [rsp+0x40], xmm5
00007f8fe1fd2021  vmovaps [rsp+0x50], xmm6
00007f8fe1fd2027  vmovaps [rsp+0x60], xmm7
00007f8fe1fd202d  vmovaps [rsp+0x70], xmm8
00007f8fe1fd2033  vmovaps [rsp+0x80], xmm9
00007f8fe1fd203c  vmovaps [rsp+0x90], xmm10
00007f8fe1fd2045  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd204e  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd2057  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd2060  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd2069  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2072  sub rsp, 0x30
00007f8fe1fd2076  movaps [rsp], xmm2
00007f8fe1fd207a  movaps [rsp+0x10], xmm1
00007f8fe1fd207f  movaps [rsp+0x20], xmm13
00007f8fe1fd2085  lea rdi, [rsp]
00007f8fe1fd2089  mov esi, 0x00
00007f8fe1fd208e  mov rax, 0x6020BB77F530
00007f8fe1fd2098  call rax
00007f8fe1fd209a  movaps xmm2, [rsp]
00007f8fe1fd209e  add rsp, 0x30
00007f8fe1fd20a2  vmovaps xmm0, [rsp]
00007f8fe1fd20a7  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd20ad  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd20b3  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd20b9  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd20bf  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd20c5  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd20cb  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd20d1  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd20da  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd20e3  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd20ec  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd20f5  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd20fe  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd2107  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd2110  add rsp, 0xF0
00007f8fe1fd2117  pop r11
00007f8fe1fd2119  pop r10
00007f8fe1fd211b  pop r9
00007f8fe1fd211d  pop r8
00007f8fe1fd211f  pop rsi
00007f8fe1fd2120  pop rdi
00007f8fe1fd2121  pop rdx
00007f8fe1fd2122  pop rcx
00007f8fe1fd2123  pop rax
00007f8fe1fd2124  add rsp, 0x08
00007f8fe1fd2128  jmp 0x00007F8FE1FCFBAB
00007f8fe1fd212d  call 0x00007F8FE1DFF430
00007f8fe1fd2132  jmp 0x00007F8FE1FCFBB8
00007f8fe1fd2137  sub rsp, 0x08
00007f8fe1fd213b  push rax
00007f8fe1fd213c  push rcx
00007f8fe1fd213d  push rdx
00007f8fe1fd213e  push rdi
00007f8fe1fd213f  push rsi
00007f8fe1fd2140  push r8
00007f8fe1fd2142  push r9
00007f8fe1fd2144  push r10
00007f8fe1fd2146  push r11
00007f8fe1fd2148  sub rsp, 0xF0
00007f8fe1fd214f  vmovaps [rsp], xmm0
00007f8fe1fd2154  vmovaps [rsp+0x10], xmm1
00007f8fe1fd215a  vmovaps [rsp+0x20], xmm2
00007f8fe1fd2160  vmovaps [rsp+0x30], xmm3
00007f8fe1fd2166  vmovaps [rsp+0x40], xmm4
00007f8fe1fd216c  vmovaps [rsp+0x50], xmm5
00007f8fe1fd2172  vmovaps [rsp+0x60], xmm6
00007f8fe1fd2178  vmovaps [rsp+0x70], xmm7
00007f8fe1fd217e  vmovaps [rsp+0x80], xmm8
00007f8fe1fd2187  vmovaps [rsp+0x90], xmm9
00007f8fe1fd2190  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd2199  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd21a2  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd21ab  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd21b4  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd21bd  sub rsp, 0x30
00007f8fe1fd21c1  movaps [rsp], xmm15
00007f8fe1fd21c6  movaps [rsp+0x10], xmm13
00007f8fe1fd21cc  movaps [rsp+0x20], xmm1
00007f8fe1fd21d1  lea rdi, [rsp]
00007f8fe1fd21d5  mov esi, 0x00
00007f8fe1fd21da  mov rax, 0x6020BB77F530
00007f8fe1fd21e4  call rax
00007f8fe1fd21e6  movaps xmm15, [rsp]
00007f8fe1fd21eb  add rsp, 0x30
00007f8fe1fd21ef  vmovaps xmm0, [rsp]
00007f8fe1fd21f4  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd21fa  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd2200  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd2206  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd220c  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd2212  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd2218  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd221e  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd2227  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd2230  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd2239  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd2242  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd224b  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd2254  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd225d  add rsp, 0xF0
00007f8fe1fd2264  pop r11
00007f8fe1fd2266  pop r10
00007f8fe1fd2268  pop r9
00007f8fe1fd226a  pop r8
00007f8fe1fd226c  pop rsi
00007f8fe1fd226d  pop rdi
00007f8fe1fd226e  pop rdx
00007f8fe1fd226f  pop rcx
00007f8fe1fd2270  pop rax
00007f8fe1fd2271  add rsp, 0x08
00007f8fe1fd2275  jmp 0x00007F8FE1FCFBF7
00007f8fe1fd227a  sub rsp, 0x08
00007f8fe1fd227e  push rax
00007f8fe1fd227f  push rcx
00007f8fe1fd2280  push rdx
00007f8fe1fd2281  push rdi
00007f8fe1fd2282  push rsi
00007f8fe1fd2283  push r8
00007f8fe1fd2285  push r9
00007f8fe1fd2287  push r10
00007f8fe1fd2289  push r11
00007f8fe1fd228b  sub rsp, 0xF0
00007f8fe1fd2292  vmovaps [rsp], xmm0
00007f8fe1fd2297  vmovaps [rsp+0x10], xmm1
00007f8fe1fd229d  vmovaps [rsp+0x20], xmm2
00007f8fe1fd22a3  vmovaps [rsp+0x30], xmm3
00007f8fe1fd22a9  vmovaps [rsp+0x40], xmm4
00007f8fe1fd22af  vmovaps [rsp+0x50], xmm5
00007f8fe1fd22b5  vmovaps [rsp+0x60], xmm6
00007f8fe1fd22bb  vmovaps [rsp+0x70], xmm7
00007f8fe1fd22c1  vmovaps [rsp+0x80], xmm8
00007f8fe1fd22ca  vmovaps [rsp+0x90], xmm9
00007f8fe1fd22d3  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd22dc  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd22e5  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd22ee  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd22f7  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2300  sub rsp, 0x30
00007f8fe1fd2304  movaps [rsp], xmm14
00007f8fe1fd2309  movaps [rsp+0x10], xmm11
00007f8fe1fd230f  movaps [rsp+0x20], xmm1
00007f8fe1fd2314  lea rdi, [rsp]
00007f8fe1fd2318  mov esi, 0x00
00007f8fe1fd231d  mov rax, 0x6020BB77F530
00007f8fe1fd2327  call rax
00007f8fe1fd2329  movaps xmm14, [rsp]
00007f8fe1fd232e  add rsp, 0x30
00007f8fe1fd2332  vmovaps xmm0, [rsp]
00007f8fe1fd2337  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd233d  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd2343  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd2349  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd234f  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd2355  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd235b  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd2361  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd236a  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd2373  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd237c  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd2385  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd238e  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd2397  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd23a0  add rsp, 0xF0
00007f8fe1fd23a7  pop r11
00007f8fe1fd23a9  pop r10
00007f8fe1fd23ab  pop r9
00007f8fe1fd23ad  pop r8
00007f8fe1fd23af  pop rsi
00007f8fe1fd23b0  pop rdi
00007f8fe1fd23b1  pop rdx
00007f8fe1fd23b2  pop rcx
00007f8fe1fd23b3  pop rax
00007f8fe1fd23b4  add rsp, 0x08
00007f8fe1fd23b8  jmp 0x00007F8FE1FCFC21
00007f8fe1fd23bd  sub rsp, 0x08
00007f8fe1fd23c1  push rax
00007f8fe1fd23c2  push rcx
00007f8fe1fd23c3  push rdx
00007f8fe1fd23c4  push rdi
00007f8fe1fd23c5  push rsi
00007f8fe1fd23c6  push r8
00007f8fe1fd23c8  push r9
00007f8fe1fd23ca  push r10
00007f8fe1fd23cc  push r11
00007f8fe1fd23ce  sub rsp, 0xF0
00007f8fe1fd23d5  vmovaps [rsp], xmm0
00007f8fe1fd23da  vmovaps [rsp+0x10], xmm1
00007f8fe1fd23e0  vmovaps [rsp+0x20], xmm2
00007f8fe1fd23e6  vmovaps [rsp+0x30], xmm3
00007f8fe1fd23ec  vmovaps [rsp+0x40], xmm4
00007f8fe1fd23f2  vmovaps [rsp+0x50], xmm5
00007f8fe1fd23f8  vmovaps [rsp+0x60], xmm6
00007f8fe1fd23fe  vmovaps [rsp+0x70], xmm7
00007f8fe1fd2404  vmovaps [rsp+0x80], xmm8
00007f8fe1fd240d  vmovaps [rsp+0x90], xmm9
00007f8fe1fd2416  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd241f  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd2428  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd2431  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd243a  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2443  sub rsp, 0x30
00007f8fe1fd2447  movaps [rsp], xmm13
00007f8fe1fd244c  movaps [rsp+0x10], xmm11
00007f8fe1fd2452  movaps [rsp+0x20], xmm1
00007f8fe1fd2457  lea rdi, [rsp]
00007f8fe1fd245b  mov esi, 0x00
00007f8fe1fd2460  mov rax, 0x6020BB77F530
00007f8fe1fd246a  call rax
00007f8fe1fd246c  movaps xmm13, [rsp]
00007f8fe1fd2471  add rsp, 0x30
00007f8fe1fd2475  vmovaps xmm0, [rsp]
00007f8fe1fd247a  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd2480  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd2486  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd248c  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd2492  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd2498  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd249e  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd24a4  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd24ad  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd24b6  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd24bf  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd24c8  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd24d1  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd24da  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd24e3  add rsp, 0xF0
00007f8fe1fd24ea  pop r11
00007f8fe1fd24ec  pop r10
00007f8fe1fd24ee  pop r9
00007f8fe1fd24f0  pop r8
00007f8fe1fd24f2  pop rsi
00007f8fe1fd24f3  pop rdi
00007f8fe1fd24f4  pop rdx
00007f8fe1fd24f5  pop rcx
00007f8fe1fd24f6  pop rax
00007f8fe1fd24f7  add rsp, 0x08
00007f8fe1fd24fb  jmp 0x00007F8FE1FCFC76
00007f8fe1fd2500  call 0x00007F8FE1DFF430
00007f8fe1fd2505  jmp 0x00007F8FE1FCFC83
00007f8fe1fd250a  sub rsp, 0x08
00007f8fe1fd250e  push rax
00007f8fe1fd250f  push rcx
00007f8fe1fd2510  push rdx
00007f8fe1fd2511  push rdi
00007f8fe1fd2512  push rsi
00007f8fe1fd2513  push r8
00007f8fe1fd2515  push r9
00007f8fe1fd2517  push r10
00007f8fe1fd2519  push r11
00007f8fe1fd251b  sub rsp, 0xF0
00007f8fe1fd2522  vmovaps [rsp], xmm0
00007f8fe1fd2527  vmovaps [rsp+0x10], xmm1
00007f8fe1fd252d  vmovaps [rsp+0x20], xmm2
00007f8fe1fd2533  vmovaps [rsp+0x30], xmm3
00007f8fe1fd2539  vmovaps [rsp+0x40], xmm4
00007f8fe1fd253f  vmovaps [rsp+0x50], xmm5
00007f8fe1fd2545  vmovaps [rsp+0x60], xmm6
00007f8fe1fd254b  vmovaps [rsp+0x70], xmm7
00007f8fe1fd2551  vmovaps [rsp+0x80], xmm8
00007f8fe1fd255a  vmovaps [rsp+0x90], xmm9
00007f8fe1fd2563  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd256c  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd2575  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd257e  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd2587  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd2590  sub rsp, 0x30
00007f8fe1fd2594  movaps [rsp], xmm15
00007f8fe1fd2599  movaps [rsp+0x10], xmm11
00007f8fe1fd259f  movaps [rsp+0x20], xmm1
00007f8fe1fd25a4  lea rdi, [rsp]
00007f8fe1fd25a8  mov esi, 0x00
00007f8fe1fd25ad  mov rax, 0x6020BB77F530
00007f8fe1fd25b7  call rax
00007f8fe1fd25b9  movaps xmm15, [rsp]
00007f8fe1fd25be  add rsp, 0x30
00007f8fe1fd25c2  vmovaps xmm0, [rsp]
00007f8fe1fd25c7  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd25cd  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd25d3  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd25d9  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd25df  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd25e5  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd25eb  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd25f1  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd25fa  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd2603  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd260c  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd2615  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd261e  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd2627  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd2630  add rsp, 0xF0
00007f8fe1fd2637  pop r11
00007f8fe1fd2639  pop r10
00007f8fe1fd263b  pop r9
00007f8fe1fd263d  pop r8
00007f8fe1fd263f  pop rsi
00007f8fe1fd2640  pop rdi
00007f8fe1fd2641  pop rdx
00007f8fe1fd2642  pop rcx
00007f8fe1fd2643  pop rax
00007f8fe1fd2644  add rsp, 0x08
00007f8fe1fd2648  jmp 0x00007F8FE1FCFCBC
00007f8fe1fd264d  sub rsp, 0x08
00007f8fe1fd2651  push rax
00007f8fe1fd2652  push rcx
00007f8fe1fd2653  push rdx
00007f8fe1fd2654  push rdi
00007f8fe1fd2655  push rsi
00007f8fe1fd2656  push r8
00007f8fe1fd2658  push r9
00007f8fe1fd265a  push r10
00007f8fe1fd265c  push r11
00007f8fe1fd265e  sub rsp, 0xF0
00007f8fe1fd2665  vmovaps [rsp], xmm0
00007f8fe1fd266a  vmovaps [rsp+0x10], xmm1
00007f8fe1fd2670  vmovaps [rsp+0x20], xmm2
00007f8fe1fd2676  vmovaps [rsp+0x30], xmm3
00007f8fe1fd267c  vmovaps [rsp+0x40], xmm4
00007f8fe1fd2682  vmovaps [rsp+0x50], xmm5
00007f8fe1fd2688  vmovaps [rsp+0x60], xmm6
00007f8fe1fd268e  vmovaps [rsp+0x70], xmm7
00007f8fe1fd2694  vmovaps [rsp+0x80], xmm8
00007f8fe1fd269d  vmovaps [rsp+0x90], xmm9
00007f8fe1fd26a6  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd26af  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd26b8  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd26c1  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd26ca  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd26d3  sub rsp, 0x30
00007f8fe1fd26d7  movaps [rsp], xmm11
00007f8fe1fd26dc  movaps [rsp+0x10], xmm6
00007f8fe1fd26e1  movaps [rsp+0x20], xmm14
00007f8fe1fd26e7  lea rdi, [rsp]
00007f8fe1fd26eb  mov esi, 0x00
00007f8fe1fd26f0  mov rax, 0x6020BB77F530
00007f8fe1fd26fa  call rax
00007f8fe1fd26fc  movaps xmm11, [rsp]
00007f8fe1fd2701  add rsp, 0x30
00007f8fe1fd2705  vmovaps xmm0, [rsp]
00007f8fe1fd270a  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd2710  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd2716  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd271c  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd2722  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd2728  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd272e  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd2734  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd273d  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd2746  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd274f  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd2758  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd2761  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd276a  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd2773  add rsp, 0xF0
00007f8fe1fd277a  pop r11
00007f8fe1fd277c  pop r10
00007f8fe1fd277e  pop r9
00007f8fe1fd2780  pop r8
00007f8fe1fd2782  pop rsi
00007f8fe1fd2783  pop rdi
00007f8fe1fd2784  pop rdx
00007f8fe1fd2785  pop rcx
00007f8fe1fd2786  pop rax
00007f8fe1fd2787  add rsp, 0x08
00007f8fe1fd278b  jmp 0x00007F8FE1FCFD34
00007f8fe1fd2790  call 0x00007F8FE1DFF430
00007f8fe1fd2795  jmp 0x00007F8FE1FCFD3E
00007f8fe1fd279a  sub rsp, 0x08
00007f8fe1fd279e  push rax
00007f8fe1fd279f  push rcx
00007f8fe1fd27a0  push rdx
00007f8fe1fd27a1  push rdi
00007f8fe1fd27a2  push rsi
00007f8fe1fd27a3  push r8
00007f8fe1fd27a5  push r9
00007f8fe1fd27a7  push r10
00007f8fe1fd27a9  push r11
00007f8fe1fd27ab  sub rsp, 0xF0
00007f8fe1fd27b2  vmovaps [rsp], xmm0
00007f8fe1fd27b7  vmovaps [rsp+0x10], xmm1
00007f8fe1fd27bd  vmovaps [rsp+0x20], xmm2
00007f8fe1fd27c3  vmovaps [rsp+0x30], xmm3
00007f8fe1fd27c9  vmovaps [rsp+0x40], xmm4
00007f8fe1fd27cf  vmovaps [rsp+0x50], xmm5
00007f8fe1fd27d5  vmovaps [rsp+0x60], xmm6
00007f8fe1fd27db  vmovaps [rsp+0x70], xmm7
00007f8fe1fd27e1  vmovaps [rsp+0x80], xmm8
00007f8fe1fd27ea  vmovaps [rsp+0x90], xmm9
00007f8fe1fd27f3  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd27fc  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd2805  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd280e  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd2817  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2820  sub rsp, 0x30
00007f8fe1fd2824  movaps [rsp], xmm14
00007f8fe1fd2829  movaps [rsp+0x10], xmm6
00007f8fe1fd282e  movaps [rsp+0x20], xmm2
00007f8fe1fd2833  lea rdi, [rsp]
00007f8fe1fd2837  mov esi, 0x00
00007f8fe1fd283c  mov rax, 0x6020BB77F530
00007f8fe1fd2846  call rax
00007f8fe1fd2848  movaps xmm14, [rsp]
00007f8fe1fd284d  add rsp, 0x30
00007f8fe1fd2851  vmovaps xmm0, [rsp]
00007f8fe1fd2856  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd285c  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd2862  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd2868  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd286e  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd2874  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd287a  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd2880  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd2889  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd2892  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd289b  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd28a4  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd28ad  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd28b6  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd28bf  add rsp, 0xF0
00007f8fe1fd28c6  pop r11
00007f8fe1fd28c8  pop r10
00007f8fe1fd28ca  pop r9
00007f8fe1fd28cc  pop r8
00007f8fe1fd28ce  pop rsi
00007f8fe1fd28cf  pop rdi
00007f8fe1fd28d0  pop rdx
00007f8fe1fd28d1  pop rcx
00007f8fe1fd28d2  pop rax
00007f8fe1fd28d3  add rsp, 0x08
00007f8fe1fd28d7  jmp 0x00007F8FE1FCFD72
00007f8fe1fd28dc  sub rsp, 0x08
00007f8fe1fd28e0  push rax
00007f8fe1fd28e1  push rcx
00007f8fe1fd28e2  push rdx
00007f8fe1fd28e3  push rdi
00007f8fe1fd28e4  push rsi
00007f8fe1fd28e5  push r8
00007f8fe1fd28e7  push r9
00007f8fe1fd28e9  push r10
00007f8fe1fd28eb  push r11
00007f8fe1fd28ed  sub rsp, 0xF0
00007f8fe1fd28f4  vmovaps [rsp], xmm0
00007f8fe1fd28f9  vmovaps [rsp+0x10], xmm1
00007f8fe1fd28ff  vmovaps [rsp+0x20], xmm2
00007f8fe1fd2905  vmovaps [rsp+0x30], xmm3
00007f8fe1fd290b  vmovaps [rsp+0x40], xmm4
00007f8fe1fd2911  vmovaps [rsp+0x50], xmm5
00007f8fe1fd2917  vmovaps [rsp+0x60], xmm7
00007f8fe1fd291d  vmovaps [rsp+0x70], xmm8
00007f8fe1fd2923  vmovaps [rsp+0x80], xmm9
00007f8fe1fd292c  vmovaps [rsp+0x90], xmm10
00007f8fe1fd2935  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd293e  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd2947  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd2950  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd2959  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2962  sub rsp, 0x30
00007f8fe1fd2966  movaps [rsp], xmm6
00007f8fe1fd296a  movaps [rsp+0x10], xmm5
00007f8fe1fd296f  movaps [rsp+0x20], xmm1
00007f8fe1fd2974  lea rdi, [rsp]
00007f8fe1fd2978  mov esi, 0x00
00007f8fe1fd297d  mov rax, 0x6020BB77F530
00007f8fe1fd2987  call rax
00007f8fe1fd2989  movaps xmm6, [rsp]
00007f8fe1fd298d  add rsp, 0x30
00007f8fe1fd2991  vmovaps xmm0, [rsp]
00007f8fe1fd2996  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd299c  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd29a2  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd29a8  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd29ae  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd29b4  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd29ba  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd29c0  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd29c9  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd29d2  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd29db  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd29e4  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd29ed  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd29f6  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd29ff  add rsp, 0xF0
00007f8fe1fd2a06  pop r11
00007f8fe1fd2a08  pop r10
00007f8fe1fd2a0a  pop r9
00007f8fe1fd2a0c  pop r8
00007f8fe1fd2a0e  pop rsi
00007f8fe1fd2a0f  pop rdi
00007f8fe1fd2a10  pop rdx
00007f8fe1fd2a11  pop rcx
00007f8fe1fd2a12  pop rax
00007f8fe1fd2a13  add rsp, 0x08
00007f8fe1fd2a17  jmp 0x00007F8FE1FCFD98
00007f8fe1fd2a1c  sub rsp, 0x08
00007f8fe1fd2a20  push rax
00007f8fe1fd2a21  push rcx
00007f8fe1fd2a22  push rdx
00007f8fe1fd2a23  push rdi
00007f8fe1fd2a24  push rsi
00007f8fe1fd2a25  push r8
00007f8fe1fd2a27  push r9
00007f8fe1fd2a29  push r10
00007f8fe1fd2a2b  push r11
00007f8fe1fd2a2d  sub rsp, 0xF0
00007f8fe1fd2a34  vmovaps [rsp], xmm0
00007f8fe1fd2a39  vmovaps [rsp+0x10], xmm2
00007f8fe1fd2a3f  vmovaps [rsp+0x20], xmm3
00007f8fe1fd2a45  vmovaps [rsp+0x30], xmm4
00007f8fe1fd2a4b  vmovaps [rsp+0x40], xmm5
00007f8fe1fd2a51  vmovaps [rsp+0x50], xmm6
00007f8fe1fd2a57  vmovaps [rsp+0x60], xmm7
00007f8fe1fd2a5d  vmovaps [rsp+0x70], xmm8
00007f8fe1fd2a63  vmovaps [rsp+0x80], xmm9
00007f8fe1fd2a6c  vmovaps [rsp+0x90], xmm10
00007f8fe1fd2a75  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd2a7e  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd2a87  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd2a90  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd2a99  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2aa2  sub rsp, 0x30
00007f8fe1fd2aa6  movaps [rsp], xmm1
00007f8fe1fd2aaa  movaps [rsp+0x10], xmm5
00007f8fe1fd2aaf  movaps [rsp+0x20], xmm13
00007f8fe1fd2ab5  lea rdi, [rsp]
00007f8fe1fd2ab9  mov esi, 0x00
00007f8fe1fd2abe  mov rax, 0x6020BB77F530
00007f8fe1fd2ac8  call rax
00007f8fe1fd2aca  movaps xmm1, [rsp]
00007f8fe1fd2ace  add rsp, 0x30
00007f8fe1fd2ad2  vmovaps xmm0, [rsp]
00007f8fe1fd2ad7  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd2add  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd2ae3  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd2ae9  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd2aef  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd2af5  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd2afb  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd2b01  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd2b0a  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd2b13  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd2b1c  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd2b25  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd2b2e  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd2b37  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd2b40  add rsp, 0xF0
00007f8fe1fd2b47  pop r11
00007f8fe1fd2b49  pop r10
00007f8fe1fd2b4b  pop r9
00007f8fe1fd2b4d  pop r8
00007f8fe1fd2b4f  pop rsi
00007f8fe1fd2b50  pop rdi
00007f8fe1fd2b51  pop rdx
00007f8fe1fd2b52  pop rcx
00007f8fe1fd2b53  pop rax
00007f8fe1fd2b54  add rsp, 0x08
00007f8fe1fd2b58  jmp 0x00007F8FE1FCFDB6
00007f8fe1fd2b5d  sub rsp, 0x08
00007f8fe1fd2b61  push rax
00007f8fe1fd2b62  push rcx
00007f8fe1fd2b63  push rdx
00007f8fe1fd2b64  push rdi
00007f8fe1fd2b65  push rsi
00007f8fe1fd2b66  push r8
00007f8fe1fd2b68  push r9
00007f8fe1fd2b6a  push r10
00007f8fe1fd2b6c  push r11
00007f8fe1fd2b6e  sub rsp, 0xF0
00007f8fe1fd2b75  vmovaps [rsp], xmm0
00007f8fe1fd2b7a  vmovaps [rsp+0x10], xmm1
00007f8fe1fd2b80  vmovaps [rsp+0x20], xmm2
00007f8fe1fd2b86  vmovaps [rsp+0x30], xmm3
00007f8fe1fd2b8c  vmovaps [rsp+0x40], xmm4
00007f8fe1fd2b92  vmovaps [rsp+0x50], xmm6
00007f8fe1fd2b98  vmovaps [rsp+0x60], xmm7
00007f8fe1fd2b9e  vmovaps [rsp+0x70], xmm8
00007f8fe1fd2ba4  vmovaps [rsp+0x80], xmm9
00007f8fe1fd2bad  vmovaps [rsp+0x90], xmm10
00007f8fe1fd2bb6  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd2bbf  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd2bc8  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd2bd1  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd2bda  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2be3  sub rsp, 0x30
00007f8fe1fd2be7  movaps [rsp], xmm5
00007f8fe1fd2beb  movaps [rsp+0x10], xmm2
00007f8fe1fd2bf0  movaps [rsp+0x20], xmm13
00007f8fe1fd2bf6  lea rdi, [rsp]
00007f8fe1fd2bfa  mov esi, 0x00
00007f8fe1fd2bff  mov rax, 0x6020BB77F530
00007f8fe1fd2c09  call rax
00007f8fe1fd2c0b  movaps xmm5, [rsp]
00007f8fe1fd2c0f  add rsp, 0x30
00007f8fe1fd2c13  vmovaps xmm0, [rsp]
00007f8fe1fd2c18  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd2c1e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd2c24  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd2c2a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd2c30  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd2c36  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd2c3c  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd2c42  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd2c4b  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd2c54  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd2c5d  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd2c66  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd2c6f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd2c78  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd2c81  add rsp, 0xF0
00007f8fe1fd2c88  pop r11
00007f8fe1fd2c8a  pop r10
00007f8fe1fd2c8c  pop r9
00007f8fe1fd2c8e  pop r8
00007f8fe1fd2c90  pop rsi
00007f8fe1fd2c91  pop rdi
00007f8fe1fd2c92  pop rdx
00007f8fe1fd2c93  pop rcx
00007f8fe1fd2c94  pop rax
00007f8fe1fd2c95  add rsp, 0x08
00007f8fe1fd2c99  jmp 0x00007F8FE1FCFDEC
00007f8fe1fd2c9e  sub rsp, 0x08
00007f8fe1fd2ca2  push rax
00007f8fe1fd2ca3  push rcx
00007f8fe1fd2ca4  push rdx
00007f8fe1fd2ca5  push rdi
00007f8fe1fd2ca6  push rsi
00007f8fe1fd2ca7  push r8
00007f8fe1fd2ca9  push r9
00007f8fe1fd2cab  push r10
00007f8fe1fd2cad  push r11
00007f8fe1fd2caf  sub rsp, 0xF0
00007f8fe1fd2cb6  vmovaps [rsp], xmm0
00007f8fe1fd2cbb  vmovaps [rsp+0x10], xmm1
00007f8fe1fd2cc1  vmovaps [rsp+0x20], xmm2
00007f8fe1fd2cc7  vmovaps [rsp+0x30], xmm3
00007f8fe1fd2ccd  vmovaps [rsp+0x40], xmm4
00007f8fe1fd2cd3  vmovaps [rsp+0x50], xmm5
00007f8fe1fd2cd9  vmovaps [rsp+0x60], xmm6
00007f8fe1fd2cdf  vmovaps [rsp+0x70], xmm7
00007f8fe1fd2ce5  vmovaps [rsp+0x80], xmm8
00007f8fe1fd2cee  vmovaps [rsp+0x90], xmm9
00007f8fe1fd2cf7  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd2d00  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd2d09  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd2d12  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd2d1b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2d24  sub rsp, 0x30
00007f8fe1fd2d28  movaps [rsp], xmm13
00007f8fe1fd2d2d  movaps [rsp+0x10], xmm10
00007f8fe1fd2d33  movaps [rsp+0x20], xmm1
00007f8fe1fd2d38  lea rdi, [rsp]
00007f8fe1fd2d3c  mov esi, 0x00
00007f8fe1fd2d41  mov rax, 0x6020BB77F530
00007f8fe1fd2d4b  call rax
00007f8fe1fd2d4d  movaps xmm13, [rsp]
00007f8fe1fd2d52  add rsp, 0x30
00007f8fe1fd2d56  vmovaps xmm0, [rsp]
00007f8fe1fd2d5b  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd2d61  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd2d67  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd2d6d  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd2d73  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd2d79  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd2d7f  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd2d85  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd2d8e  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd2d97  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd2da0  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd2da9  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd2db2  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd2dbb  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd2dc4  add rsp, 0xF0
00007f8fe1fd2dcb  pop r11
00007f8fe1fd2dcd  pop r10
00007f8fe1fd2dcf  pop r9
00007f8fe1fd2dd1  pop r8
00007f8fe1fd2dd3  pop rsi
00007f8fe1fd2dd4  pop rdi
00007f8fe1fd2dd5  pop rdx
00007f8fe1fd2dd6  pop rcx
00007f8fe1fd2dd7  pop rax
00007f8fe1fd2dd8  add rsp, 0x08
00007f8fe1fd2ddc  jmp 0x00007F8FE1FCFE15
00007f8fe1fd2de1  sub rsp, 0x08
00007f8fe1fd2de5  push rax
00007f8fe1fd2de6  push rcx
00007f8fe1fd2de7  push rdx
00007f8fe1fd2de8  push rdi
00007f8fe1fd2de9  push rsi
00007f8fe1fd2dea  push r8
00007f8fe1fd2dec  push r9
00007f8fe1fd2dee  push r10
00007f8fe1fd2df0  push r11
00007f8fe1fd2df2  sub rsp, 0xF0
00007f8fe1fd2df9  vmovaps [rsp], xmm0
00007f8fe1fd2dfe  vmovaps [rsp+0x10], xmm2
00007f8fe1fd2e04  vmovaps [rsp+0x20], xmm3
00007f8fe1fd2e0a  vmovaps [rsp+0x30], xmm4
00007f8fe1fd2e10  vmovaps [rsp+0x40], xmm5
00007f8fe1fd2e16  vmovaps [rsp+0x50], xmm6
00007f8fe1fd2e1c  vmovaps [rsp+0x60], xmm7
00007f8fe1fd2e22  vmovaps [rsp+0x70], xmm8
00007f8fe1fd2e28  vmovaps [rsp+0x80], xmm9
00007f8fe1fd2e31  vmovaps [rsp+0x90], xmm10
00007f8fe1fd2e3a  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd2e43  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd2e4c  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd2e55  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd2e5e  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd2e67  sub rsp, 0x30
00007f8fe1fd2e6b  movaps [rsp], xmm1
00007f8fe1fd2e6f  movaps [rsp+0x10], xmm15
00007f8fe1fd2e75  movaps [rsp+0x20], xmm10
00007f8fe1fd2e7b  lea rdi, [rsp]
00007f8fe1fd2e7f  mov esi, 0x00
00007f8fe1fd2e84  mov rax, 0x6020BB77F530
00007f8fe1fd2e8e  call rax
00007f8fe1fd2e90  movaps xmm1, [rsp]
00007f8fe1fd2e94  add rsp, 0x30
00007f8fe1fd2e98  vmovaps xmm0, [rsp]
00007f8fe1fd2e9d  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd2ea3  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd2ea9  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd2eaf  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd2eb5  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd2ebb  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd2ec1  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd2ec7  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd2ed0  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd2ed9  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd2ee2  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd2eeb  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd2ef4  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd2efd  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd2f06  add rsp, 0xF0
00007f8fe1fd2f0d  pop r11
00007f8fe1fd2f0f  pop r10
00007f8fe1fd2f11  pop r9
00007f8fe1fd2f13  pop r8
00007f8fe1fd2f15  pop rsi
00007f8fe1fd2f16  pop rdi
00007f8fe1fd2f17  pop rdx
00007f8fe1fd2f18  pop rcx
00007f8fe1fd2f19  pop rax
00007f8fe1fd2f1a  add rsp, 0x08
00007f8fe1fd2f1e  jmp 0x00007F8FE1FCFE34
00007f8fe1fd2f23  sub rsp, 0x08
00007f8fe1fd2f27  push rax
00007f8fe1fd2f28  push rcx
00007f8fe1fd2f29  push rdx
00007f8fe1fd2f2a  push rdi
00007f8fe1fd2f2b  push rsi
00007f8fe1fd2f2c  push r8
00007f8fe1fd2f2e  push r9
00007f8fe1fd2f30  push r10
00007f8fe1fd2f32  push r11
00007f8fe1fd2f34  sub rsp, 0xF0
00007f8fe1fd2f3b  vmovaps [rsp], xmm0
00007f8fe1fd2f40  vmovaps [rsp+0x10], xmm1
00007f8fe1fd2f46  vmovaps [rsp+0x20], xmm2
00007f8fe1fd2f4c  vmovaps [rsp+0x30], xmm3
00007f8fe1fd2f52  vmovaps [rsp+0x40], xmm4
00007f8fe1fd2f58  vmovaps [rsp+0x50], xmm5
00007f8fe1fd2f5e  vmovaps [rsp+0x60], xmm6
00007f8fe1fd2f64  vmovaps [rsp+0x70], xmm7
00007f8fe1fd2f6a  vmovaps [rsp+0x80], xmm8
00007f8fe1fd2f73  vmovaps [rsp+0x90], xmm9
00007f8fe1fd2f7c  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd2f85  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd2f8e  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd2f97  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd2fa0  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd2fa9  sub rsp, 0x30
00007f8fe1fd2fad  movaps [rsp], xmm15
00007f8fe1fd2fb2  movaps [rsp+0x10], xmm10
00007f8fe1fd2fb8  movaps [rsp+0x20], xmm11
00007f8fe1fd2fbe  lea rdi, [rsp]
00007f8fe1fd2fc2  mov esi, 0x00
00007f8fe1fd2fc7  mov rax, 0x6020BB77F530
00007f8fe1fd2fd1  call rax
00007f8fe1fd2fd3  movaps xmm15, [rsp]
00007f8fe1fd2fd8  add rsp, 0x30
00007f8fe1fd2fdc  vmovaps xmm0, [rsp]
00007f8fe1fd2fe1  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd2fe7  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd2fed  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd2ff3  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd2ff9  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd2fff  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd3005  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd300b  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd3014  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd301d  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd3026  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd302f  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd3038  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd3041  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd304a  add rsp, 0xF0
00007f8fe1fd3051  pop r11
00007f8fe1fd3053  pop r10
00007f8fe1fd3055  pop r9
00007f8fe1fd3057  pop r8
00007f8fe1fd3059  pop rsi
00007f8fe1fd305a  pop rdi
00007f8fe1fd305b  pop rdx
00007f8fe1fd305c  pop rcx
00007f8fe1fd305d  pop rax
00007f8fe1fd305e  add rsp, 0x08
00007f8fe1fd3062  jmp 0x00007F8FE1FCFE57
00007f8fe1fd3067  sub rsp, 0x08
00007f8fe1fd306b  push rax
00007f8fe1fd306c  push rcx
00007f8fe1fd306d  push rdx
00007f8fe1fd306e  push rdi
00007f8fe1fd306f  push rsi
00007f8fe1fd3070  push r8
00007f8fe1fd3072  push r9
00007f8fe1fd3074  push r10
00007f8fe1fd3076  push r11
00007f8fe1fd3078  sub rsp, 0xF0
00007f8fe1fd307f  vmovaps [rsp], xmm0
00007f8fe1fd3084  vmovaps [rsp+0x10], xmm1
00007f8fe1fd308a  vmovaps [rsp+0x20], xmm2
00007f8fe1fd3090  vmovaps [rsp+0x30], xmm3
00007f8fe1fd3096  vmovaps [rsp+0x40], xmm4
00007f8fe1fd309c  vmovaps [rsp+0x50], xmm5
00007f8fe1fd30a2  vmovaps [rsp+0x60], xmm6
00007f8fe1fd30a8  vmovaps [rsp+0x70], xmm7
00007f8fe1fd30ae  vmovaps [rsp+0x80], xmm8
00007f8fe1fd30b7  vmovaps [rsp+0x90], xmm9
00007f8fe1fd30c0  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd30c9  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd30d2  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd30db  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd30e4  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd30ed  sub rsp, 0x30
00007f8fe1fd30f1  movaps [rsp], xmm10
00007f8fe1fd30f6  movaps [rsp+0x10], xmm12
00007f8fe1fd30fc  movaps [rsp+0x20], xmm11
00007f8fe1fd3102  lea rdi, [rsp]
00007f8fe1fd3106  mov esi, 0x00
00007f8fe1fd310b  mov rax, 0x6020BB77F530
00007f8fe1fd3115  call rax
00007f8fe1fd3117  movaps xmm10, [rsp]
00007f8fe1fd311c  add rsp, 0x30
00007f8fe1fd3120  vmovaps xmm0, [rsp]
00007f8fe1fd3125  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd312b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd3131  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd3137  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd313d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd3143  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd3149  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd314f  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd3158  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd3161  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd316a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd3173  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd317c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd3185  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd318e  add rsp, 0xF0
00007f8fe1fd3195  pop r11
00007f8fe1fd3197  pop r10
00007f8fe1fd3199  pop r9
00007f8fe1fd319b  pop r8
00007f8fe1fd319d  pop rsi
00007f8fe1fd319e  pop rdi
00007f8fe1fd319f  pop rdx
00007f8fe1fd31a0  pop rcx
00007f8fe1fd31a1  pop rax
00007f8fe1fd31a2  add rsp, 0x08
00007f8fe1fd31a6  jmp 0x00007F8FE1FCFE80
00007f8fe1fd31ab  sub rsp, 0x08
00007f8fe1fd31af  push rax
00007f8fe1fd31b0  push rcx
00007f8fe1fd31b1  push rdx
00007f8fe1fd31b2  push rdi
00007f8fe1fd31b3  push rsi
00007f8fe1fd31b4  push r8
00007f8fe1fd31b6  push r9
00007f8fe1fd31b8  push r10
00007f8fe1fd31ba  push r11
00007f8fe1fd31bc  sub rsp, 0xF0
00007f8fe1fd31c3  vmovaps [rsp], xmm0
00007f8fe1fd31c8  vmovaps [rsp+0x10], xmm1
00007f8fe1fd31ce  vmovaps [rsp+0x20], xmm2
00007f8fe1fd31d4  vmovaps [rsp+0x30], xmm3
00007f8fe1fd31da  vmovaps [rsp+0x40], xmm4
00007f8fe1fd31e0  vmovaps [rsp+0x50], xmm5
00007f8fe1fd31e6  vmovaps [rsp+0x60], xmm6
00007f8fe1fd31ec  vmovaps [rsp+0x70], xmm7
00007f8fe1fd31f2  vmovaps [rsp+0x80], xmm8
00007f8fe1fd31fb  vmovaps [rsp+0x90], xmm9
00007f8fe1fd3204  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd320d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd3216  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd321f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd3228  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd3231  sub rsp, 0x30
00007f8fe1fd3235  movaps [rsp], xmm11
00007f8fe1fd323a  movaps [rsp+0x10], xmm2
00007f8fe1fd323f  movaps [rsp+0x20], xmm12
00007f8fe1fd3245  lea rdi, [rsp]
00007f8fe1fd3249  mov esi, 0x00
00007f8fe1fd324e  mov rax, 0x6020BB77F530
00007f8fe1fd3258  call rax
00007f8fe1fd325a  movaps xmm11, [rsp]
00007f8fe1fd325f  add rsp, 0x30
00007f8fe1fd3263  vmovaps xmm0, [rsp]
00007f8fe1fd3268  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd326e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd3274  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd327a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd3280  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd3286  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd328c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd3292  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd329b  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd32a4  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd32ad  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd32b6  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd32bf  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd32c8  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd32d1  add rsp, 0xF0
00007f8fe1fd32d8  pop r11
00007f8fe1fd32da  pop r10
00007f8fe1fd32dc  pop r9
00007f8fe1fd32de  pop r8
00007f8fe1fd32e0  pop rsi
00007f8fe1fd32e1  pop rdi
00007f8fe1fd32e2  pop rdx
00007f8fe1fd32e3  pop rcx
00007f8fe1fd32e4  pop rax
00007f8fe1fd32e5  add rsp, 0x08
00007f8fe1fd32e9  jmp 0x00007F8FE1FCFEB8
00007f8fe1fd32ee  sub rsp, 0x08
00007f8fe1fd32f2  push rax
00007f8fe1fd32f3  push rcx
00007f8fe1fd32f4  push rdx
00007f8fe1fd32f5  push rdi
00007f8fe1fd32f6  push rsi
00007f8fe1fd32f7  push r8
00007f8fe1fd32f9  push r9
00007f8fe1fd32fb  push r10
00007f8fe1fd32fd  push r11
00007f8fe1fd32ff  sub rsp, 0xF0
00007f8fe1fd3306  vmovaps [rsp], xmm0
00007f8fe1fd330b  vmovaps [rsp+0x10], xmm2
00007f8fe1fd3311  vmovaps [rsp+0x20], xmm3
00007f8fe1fd3317  vmovaps [rsp+0x30], xmm4
00007f8fe1fd331d  vmovaps [rsp+0x40], xmm5
00007f8fe1fd3323  vmovaps [rsp+0x50], xmm6
00007f8fe1fd3329  vmovaps [rsp+0x60], xmm7
00007f8fe1fd332f  vmovaps [rsp+0x70], xmm8
00007f8fe1fd3335  vmovaps [rsp+0x80], xmm9
00007f8fe1fd333e  vmovaps [rsp+0x90], xmm10
00007f8fe1fd3347  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd3350  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd3359  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd3362  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd336b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd3374  sub rsp, 0x30
00007f8fe1fd3378  movaps [rsp], xmm1
00007f8fe1fd337c  movaps [rsp+0x10], xmm14
00007f8fe1fd3382  movaps [rsp+0x20], xmm6
00007f8fe1fd3387  lea rdi, [rsp]
00007f8fe1fd338b  mov esi, 0x00
00007f8fe1fd3390  mov rax, 0x6020BB77F530
00007f8fe1fd339a  call rax
00007f8fe1fd339c  movaps xmm1, [rsp]
00007f8fe1fd33a0  add rsp, 0x30
00007f8fe1fd33a4  vmovaps xmm0, [rsp]
00007f8fe1fd33a9  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd33af  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd33b5  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd33bb  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd33c1  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd33c7  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd33cd  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd33d3  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd33dc  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd33e5  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd33ee  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd33f7  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd3400  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd3409  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd3412  add rsp, 0xF0
00007f8fe1fd3419  pop r11
00007f8fe1fd341b  pop r10
00007f8fe1fd341d  pop r9
00007f8fe1fd341f  pop r8
00007f8fe1fd3421  pop rsi
00007f8fe1fd3422  pop rdi
00007f8fe1fd3423  pop rdx
00007f8fe1fd3424  pop rcx
00007f8fe1fd3425  pop rax
00007f8fe1fd3426  add rsp, 0x08
00007f8fe1fd342a  jmp 0x00007F8FE1FCFED1
00007f8fe1fd342f  sub rsp, 0x08
00007f8fe1fd3433  push rax
00007f8fe1fd3434  push rcx
00007f8fe1fd3435  push rdx
00007f8fe1fd3436  push rdi
00007f8fe1fd3437  push rsi
00007f8fe1fd3438  push r8
00007f8fe1fd343a  push r9
00007f8fe1fd343c  push r10
00007f8fe1fd343e  push r11
00007f8fe1fd3440  sub rsp, 0xF0
00007f8fe1fd3447  vmovaps [rsp], xmm0
00007f8fe1fd344c  vmovaps [rsp+0x10], xmm1
00007f8fe1fd3452  vmovaps [rsp+0x20], xmm2
00007f8fe1fd3458  vmovaps [rsp+0x30], xmm3
00007f8fe1fd345e  vmovaps [rsp+0x40], xmm4
00007f8fe1fd3464  vmovaps [rsp+0x50], xmm5
00007f8fe1fd346a  vmovaps [rsp+0x60], xmm6
00007f8fe1fd3470  vmovaps [rsp+0x70], xmm7
00007f8fe1fd3476  vmovaps [rsp+0x80], xmm8
00007f8fe1fd347f  vmovaps [rsp+0x90], xmm9
00007f8fe1fd3488  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd3491  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd349a  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd34a3  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd34ac  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd34b5  sub rsp, 0x30
00007f8fe1fd34b9  movaps [rsp], xmm14
00007f8fe1fd34be  movaps [rsp+0x10], xmm12
00007f8fe1fd34c4  movaps [rsp+0x20], xmm5
00007f8fe1fd34c9  lea rdi, [rsp]
00007f8fe1fd34cd  mov esi, 0x00
00007f8fe1fd34d2  mov rax, 0x6020BB77F530
00007f8fe1fd34dc  call rax
00007f8fe1fd34de  movaps xmm14, [rsp]
00007f8fe1fd34e3  add rsp, 0x30
00007f8fe1fd34e7  vmovaps xmm0, [rsp]
00007f8fe1fd34ec  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd34f2  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd34f8  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd34fe  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd3504  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd350a  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd3510  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd3516  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd351f  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd3528  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd3531  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd353a  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd3543  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd354c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd3555  add rsp, 0xF0
00007f8fe1fd355c  pop r11
00007f8fe1fd355e  pop r10
00007f8fe1fd3560  pop r9
00007f8fe1fd3562  pop r8
00007f8fe1fd3564  pop rsi
00007f8fe1fd3565  pop rdi
00007f8fe1fd3566  pop rdx
00007f8fe1fd3567  pop rcx
00007f8fe1fd3568  pop rax
00007f8fe1fd3569  add rsp, 0x08
00007f8fe1fd356d  jmp 0x00007F8FE1FCFEF1
00007f8fe1fd3572  sub rsp, 0x08
00007f8fe1fd3576  push rax
00007f8fe1fd3577  push rcx
00007f8fe1fd3578  push rdx
00007f8fe1fd3579  push rdi
00007f8fe1fd357a  push rsi
00007f8fe1fd357b  push r8
00007f8fe1fd357d  push r9
00007f8fe1fd357f  push r10
00007f8fe1fd3581  push r11
00007f8fe1fd3583  sub rsp, 0xF0
00007f8fe1fd358a  vmovaps [rsp], xmm0
00007f8fe1fd358f  vmovaps [rsp+0x10], xmm1
00007f8fe1fd3595  vmovaps [rsp+0x20], xmm2
00007f8fe1fd359b  vmovaps [rsp+0x30], xmm3
00007f8fe1fd35a1  vmovaps [rsp+0x40], xmm4
00007f8fe1fd35a7  vmovaps [rsp+0x50], xmm5
00007f8fe1fd35ad  vmovaps [rsp+0x60], xmm7
00007f8fe1fd35b3  vmovaps [rsp+0x70], xmm8
00007f8fe1fd35b9  vmovaps [rsp+0x80], xmm9
00007f8fe1fd35c2  vmovaps [rsp+0x90], xmm10
00007f8fe1fd35cb  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd35d4  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd35dd  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd35e6  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd35ef  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd35f8  sub rsp, 0x30
00007f8fe1fd35fc  movaps [rsp], xmm6
00007f8fe1fd3600  movaps [rsp+0x10], xmm9
00007f8fe1fd3606  movaps [rsp+0x20], xmm12
00007f8fe1fd360c  lea rdi, [rsp]
00007f8fe1fd3610  mov esi, 0x00
00007f8fe1fd3615  mov rax, 0x6020BB77F530
00007f8fe1fd361f  call rax
00007f8fe1fd3621  movaps xmm6, [rsp]
00007f8fe1fd3625  add rsp, 0x30
00007f8fe1fd3629  vmovaps xmm0, [rsp]
00007f8fe1fd362e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd3634  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd363a  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd3640  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd3646  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd364c  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd3652  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd3658  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd3661  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd366a  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd3673  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd367c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd3685  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd368e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd3697  add rsp, 0xF0
00007f8fe1fd369e  pop r11
00007f8fe1fd36a0  pop r10
00007f8fe1fd36a2  pop r9
00007f8fe1fd36a4  pop r8
00007f8fe1fd36a6  pop rsi
00007f8fe1fd36a7  pop rdi
00007f8fe1fd36a8  pop rdx
00007f8fe1fd36a9  pop rcx
00007f8fe1fd36aa  pop rax
00007f8fe1fd36ab  add rsp, 0x08
00007f8fe1fd36af  jmp 0x00007F8FE1FCFF19
00007f8fe1fd36b4  sub rsp, 0x08
00007f8fe1fd36b8  push rax
00007f8fe1fd36b9  push rcx
00007f8fe1fd36ba  push rdx
00007f8fe1fd36bb  push rdi
00007f8fe1fd36bc  push rsi
00007f8fe1fd36bd  push r8
00007f8fe1fd36bf  push r9
00007f8fe1fd36c1  push r10
00007f8fe1fd36c3  push r11
00007f8fe1fd36c5  sub rsp, 0xF0
00007f8fe1fd36cc  vmovaps [rsp], xmm0
00007f8fe1fd36d1  vmovaps [rsp+0x10], xmm1
00007f8fe1fd36d7  vmovaps [rsp+0x20], xmm2
00007f8fe1fd36dd  vmovaps [rsp+0x30], xmm3
00007f8fe1fd36e3  vmovaps [rsp+0x40], xmm4
00007f8fe1fd36e9  vmovaps [rsp+0x50], xmm5
00007f8fe1fd36ef  vmovaps [rsp+0x60], xmm6
00007f8fe1fd36f5  vmovaps [rsp+0x70], xmm7
00007f8fe1fd36fb  vmovaps [rsp+0x80], xmm8
00007f8fe1fd3704  vmovaps [rsp+0x90], xmm9
00007f8fe1fd370d  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd3716  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd371f  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd3728  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd3731  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd373a  sub rsp, 0x30
00007f8fe1fd373e  movaps [rsp], xmm12
00007f8fe1fd3743  movaps [rsp+0x10], xmm15
00007f8fe1fd3749  movaps [rsp+0x20], xmm13
00007f8fe1fd374f  lea rdi, [rsp]
00007f8fe1fd3753  mov esi, 0x00
00007f8fe1fd3758  mov rax, 0x6020BB77F530
00007f8fe1fd3762  call rax
00007f8fe1fd3764  movaps xmm12, [rsp]
00007f8fe1fd3769  add rsp, 0x30
00007f8fe1fd376d  vmovaps xmm0, [rsp]
00007f8fe1fd3772  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd3778  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd377e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd3784  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd378a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd3790  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd3796  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd379c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd37a5  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd37ae  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd37b7  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd37c0  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd37c9  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd37d2  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd37db  add rsp, 0xF0
00007f8fe1fd37e2  pop r11
00007f8fe1fd37e4  pop r10
00007f8fe1fd37e6  pop r9
00007f8fe1fd37e8  pop r8
00007f8fe1fd37ea  pop rsi
00007f8fe1fd37eb  pop rdi
00007f8fe1fd37ec  pop rdx
00007f8fe1fd37ed  pop rcx
00007f8fe1fd37ee  pop rax
00007f8fe1fd37ef  add rsp, 0x08
00007f8fe1fd37f3  jmp 0x00007F8FE1FCFF34
00007f8fe1fd37f8  sub rsp, 0x08
00007f8fe1fd37fc  push rax
00007f8fe1fd37fd  push rcx
00007f8fe1fd37fe  push rdx
00007f8fe1fd37ff  push rdi
00007f8fe1fd3800  push rsi
00007f8fe1fd3801  push r8
00007f8fe1fd3803  push r9
00007f8fe1fd3805  push r10
00007f8fe1fd3807  push r11
00007f8fe1fd3809  sub rsp, 0xF0
00007f8fe1fd3810  vmovaps [rsp], xmm0
00007f8fe1fd3815  vmovaps [rsp+0x10], xmm1
00007f8fe1fd381b  vmovaps [rsp+0x20], xmm2
00007f8fe1fd3821  vmovaps [rsp+0x30], xmm3
00007f8fe1fd3827  vmovaps [rsp+0x40], xmm4
00007f8fe1fd382d  vmovaps [rsp+0x50], xmm5
00007f8fe1fd3833  vmovaps [rsp+0x60], xmm6
00007f8fe1fd3839  vmovaps [rsp+0x70], xmm7
00007f8fe1fd383f  vmovaps [rsp+0x80], xmm8
00007f8fe1fd3848  vmovaps [rsp+0x90], xmm9
00007f8fe1fd3851  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd385a  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd3863  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd386c  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd3875  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd387e  sub rsp, 0x30
00007f8fe1fd3882  movaps [rsp], xmm15
00007f8fe1fd3887  movaps [rsp+0x10], xmm13
00007f8fe1fd388d  movaps [rsp+0x20], xmm10
00007f8fe1fd3893  lea rdi, [rsp]
00007f8fe1fd3897  mov esi, 0x00
00007f8fe1fd389c  mov rax, 0x6020BB77F530
00007f8fe1fd38a6  call rax
00007f8fe1fd38a8  movaps xmm15, [rsp]
00007f8fe1fd38ad  add rsp, 0x30
00007f8fe1fd38b1  vmovaps xmm0, [rsp]
00007f8fe1fd38b6  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd38bc  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd38c2  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd38c8  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd38ce  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd38d4  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd38da  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd38e0  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd38e9  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd38f2  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd38fb  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd3904  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd390d  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd3916  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd391f  add rsp, 0xF0
00007f8fe1fd3926  pop r11
00007f8fe1fd3928  pop r10
00007f8fe1fd392a  pop r9
00007f8fe1fd392c  pop r8
00007f8fe1fd392e  pop rsi
00007f8fe1fd392f  pop rdi
00007f8fe1fd3930  pop rdx
00007f8fe1fd3931  pop rcx
00007f8fe1fd3932  pop rax
00007f8fe1fd3933  add rsp, 0x08
00007f8fe1fd3937  jmp 0x00007F8FE1FCFF55
00007f8fe1fd393c  call 0x00007F8FE1E0C260
00007f8fe1fd3941  jmp 0x00007F8FE1FCFFB0
00007f8fe1fd3946  sub rsp, 0x08
00007f8fe1fd394a  push rax
00007f8fe1fd394b  push rcx
00007f8fe1fd394c  push rdx
00007f8fe1fd394d  push rdi
00007f8fe1fd394e  push rsi
00007f8fe1fd394f  push r8
00007f8fe1fd3951  push r9
00007f8fe1fd3953  push r10
00007f8fe1fd3955  push r11
00007f8fe1fd3957  sub rsp, 0xF0
00007f8fe1fd395e  vmovaps [rsp], xmm0
00007f8fe1fd3963  vmovaps [rsp+0x10], xmm1
00007f8fe1fd3969  vmovaps [rsp+0x20], xmm2
00007f8fe1fd396f  vmovaps [rsp+0x30], xmm3
00007f8fe1fd3975  vmovaps [rsp+0x40], xmm4
00007f8fe1fd397b  vmovaps [rsp+0x50], xmm5
00007f8fe1fd3981  vmovaps [rsp+0x60], xmm6
00007f8fe1fd3987  vmovaps [rsp+0x70], xmm7
00007f8fe1fd398d  vmovaps [rsp+0x80], xmm8
00007f8fe1fd3996  vmovaps [rsp+0x90], xmm10
00007f8fe1fd399f  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd39a8  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd39b1  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd39ba  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd39c3  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd39cc  sub rsp, 0x30
00007f8fe1fd39d0  movaps [rsp], xmm9
00007f8fe1fd39d5  movaps [rsp+0x10], xmm8
00007f8fe1fd39db  movaps [rsp+0x20], xmm10
00007f8fe1fd39e1  lea rdi, [rsp]
00007f8fe1fd39e5  mov esi, 0x00
00007f8fe1fd39ea  mov rax, 0x6020BB77F530
00007f8fe1fd39f4  call rax
00007f8fe1fd39f6  movaps xmm9, [rsp]
00007f8fe1fd39fb  add rsp, 0x30
00007f8fe1fd39ff  vmovaps xmm0, [rsp]
00007f8fe1fd3a04  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd3a0a  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd3a10  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd3a16  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd3a1c  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd3a22  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd3a28  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd3a2e  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd3a37  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd3a40  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd3a49  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd3a52  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd3a5b  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd3a64  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd3a6d  add rsp, 0xF0
00007f8fe1fd3a74  pop r11
00007f8fe1fd3a76  pop r10
00007f8fe1fd3a78  pop r9
00007f8fe1fd3a7a  pop r8
00007f8fe1fd3a7c  pop rsi
00007f8fe1fd3a7d  pop rdi
00007f8fe1fd3a7e  pop rdx
00007f8fe1fd3a7f  pop rcx
00007f8fe1fd3a80  pop rax
00007f8fe1fd3a81  add rsp, 0x08
00007f8fe1fd3a85  jmp 0x00007F8FE1FCFFE1
00007f8fe1fd3a8a  sub rsp, 0x08
00007f8fe1fd3a8e  push rax
00007f8fe1fd3a8f  push rcx
00007f8fe1fd3a90  push rdx
00007f8fe1fd3a91  push rdi
00007f8fe1fd3a92  push rsi
00007f8fe1fd3a93  push r8
00007f8fe1fd3a95  push r9
00007f8fe1fd3a97  push r10
00007f8fe1fd3a99  push r11
00007f8fe1fd3a9b  sub rsp, 0xF0
00007f8fe1fd3aa2  vmovaps [rsp], xmm0
00007f8fe1fd3aa7  vmovaps [rsp+0x10], xmm1
00007f8fe1fd3aad  vmovaps [rsp+0x20], xmm2
00007f8fe1fd3ab3  vmovaps [rsp+0x30], xmm3
00007f8fe1fd3ab9  vmovaps [rsp+0x40], xmm4
00007f8fe1fd3abf  vmovaps [rsp+0x50], xmm5
00007f8fe1fd3ac5  vmovaps [rsp+0x60], xmm6
00007f8fe1fd3acb  vmovaps [rsp+0x70], xmm7
00007f8fe1fd3ad1  vmovaps [rsp+0x80], xmm8
00007f8fe1fd3ada  vmovaps [rsp+0x90], xmm9
00007f8fe1fd3ae3  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd3aec  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd3af5  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd3afe  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd3b07  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd3b10  sub rsp, 0x30
00007f8fe1fd3b14  movaps [rsp], xmm10
00007f8fe1fd3b19  movaps [rsp+0x10], xmm1
00007f8fe1fd3b1e  movaps [rsp+0x20], xmm11
00007f8fe1fd3b24  lea rdi, [rsp]
00007f8fe1fd3b28  mov esi, 0x00
00007f8fe1fd3b2d  mov rax, 0x6020BB77F530
00007f8fe1fd3b37  call rax
00007f8fe1fd3b39  movaps xmm10, [rsp]
00007f8fe1fd3b3e  add rsp, 0x30
00007f8fe1fd3b42  vmovaps xmm0, [rsp]
00007f8fe1fd3b47  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd3b4d  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd3b53  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd3b59  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd3b5f  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd3b65  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd3b6b  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd3b71  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd3b7a  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd3b83  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd3b8c  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd3b95  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd3b9e  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd3ba7  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd3bb0  add rsp, 0xF0
00007f8fe1fd3bb7  pop r11
00007f8fe1fd3bb9  pop r10
00007f8fe1fd3bbb  pop r9
00007f8fe1fd3bbd  pop r8
00007f8fe1fd3bbf  pop rsi
00007f8fe1fd3bc0  pop rdi
00007f8fe1fd3bc1  pop rdx
00007f8fe1fd3bc2  pop rcx
00007f8fe1fd3bc3  pop rax
00007f8fe1fd3bc4  add rsp, 0x08
00007f8fe1fd3bc8  jmp 0x00007F8FE1FCFFFC
00007f8fe1fd3bcd  sub rsp, 0x08
00007f8fe1fd3bd1  push rax
00007f8fe1fd3bd2  push rcx
00007f8fe1fd3bd3  push rdx
00007f8fe1fd3bd4  push rdi
00007f8fe1fd3bd5  push rsi
00007f8fe1fd3bd6  push r8
00007f8fe1fd3bd8  push r9
00007f8fe1fd3bda  push r10
00007f8fe1fd3bdc  push r11
00007f8fe1fd3bde  sub rsp, 0xF0
00007f8fe1fd3be5  vmovaps [rsp], xmm0
00007f8fe1fd3bea  vmovaps [rsp+0x10], xmm2
00007f8fe1fd3bf0  vmovaps [rsp+0x20], xmm3
00007f8fe1fd3bf6  vmovaps [rsp+0x30], xmm4
00007f8fe1fd3bfc  vmovaps [rsp+0x40], xmm5
00007f8fe1fd3c02  vmovaps [rsp+0x50], xmm6
00007f8fe1fd3c08  vmovaps [rsp+0x60], xmm7
00007f8fe1fd3c0e  vmovaps [rsp+0x70], xmm8
00007f8fe1fd3c14  vmovaps [rsp+0x80], xmm9
00007f8fe1fd3c1d  vmovaps [rsp+0x90], xmm10
00007f8fe1fd3c26  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd3c2f  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd3c38  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd3c41  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd3c4a  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd3c53  sub rsp, 0x30
00007f8fe1fd3c57  movaps [rsp], xmm1
00007f8fe1fd3c5b  movaps [rsp+0x10], xmm14
00007f8fe1fd3c61  movaps [rsp+0x20], xmm6
00007f8fe1fd3c66  lea rdi, [rsp]
00007f8fe1fd3c6a  mov esi, 0x00
00007f8fe1fd3c6f  mov rax, 0x6020BB77F530
00007f8fe1fd3c79  call rax
00007f8fe1fd3c7b  movaps xmm1, [rsp]
00007f8fe1fd3c7f  add rsp, 0x30
00007f8fe1fd3c83  vmovaps xmm0, [rsp]
00007f8fe1fd3c88  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd3c8e  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd3c94  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd3c9a  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd3ca0  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd3ca6  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd3cac  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd3cb2  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd3cbb  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd3cc4  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd3ccd  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd3cd6  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd3cdf  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd3ce8  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd3cf1  add rsp, 0xF0
00007f8fe1fd3cf8  pop r11
00007f8fe1fd3cfa  pop r10
00007f8fe1fd3cfc  pop r9
00007f8fe1fd3cfe  pop r8
00007f8fe1fd3d00  pop rsi
00007f8fe1fd3d01  pop rdi
00007f8fe1fd3d02  pop rdx
00007f8fe1fd3d03  pop rcx
00007f8fe1fd3d04  pop rax
00007f8fe1fd3d05  add rsp, 0x08
00007f8fe1fd3d09  jmp 0x00007F8FE1FD0015
00007f8fe1fd3d0e  sub rsp, 0x08
00007f8fe1fd3d12  push rax
00007f8fe1fd3d13  push rcx
00007f8fe1fd3d14  push rdx
00007f8fe1fd3d15  push rdi
00007f8fe1fd3d16  push rsi
00007f8fe1fd3d17  push r8
00007f8fe1fd3d19  push r9
00007f8fe1fd3d1b  push r10
00007f8fe1fd3d1d  push r11
00007f8fe1fd3d1f  sub rsp, 0xF0
00007f8fe1fd3d26  vmovaps [rsp], xmm0
00007f8fe1fd3d2b  vmovaps [rsp+0x10], xmm1
00007f8fe1fd3d31  vmovaps [rsp+0x20], xmm2
00007f8fe1fd3d37  vmovaps [rsp+0x30], xmm3
00007f8fe1fd3d3d  vmovaps [rsp+0x40], xmm4
00007f8fe1fd3d43  vmovaps [rsp+0x50], xmm5
00007f8fe1fd3d49  vmovaps [rsp+0x60], xmm6
00007f8fe1fd3d4f  vmovaps [rsp+0x70], xmm7
00007f8fe1fd3d55  vmovaps [rsp+0x80], xmm8
00007f8fe1fd3d5e  vmovaps [rsp+0x90], xmm9
00007f8fe1fd3d67  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd3d70  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd3d79  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd3d82  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd3d8b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd3d94  sub rsp, 0x30
00007f8fe1fd3d98  movaps [rsp], xmm11
00007f8fe1fd3d9d  movaps [rsp+0x10], xmm13
00007f8fe1fd3da3  movaps [rsp+0x20], xmm14
00007f8fe1fd3da9  lea rdi, [rsp]
00007f8fe1fd3dad  mov esi, 0x00
00007f8fe1fd3db2  mov rax, 0x6020BB77F530
00007f8fe1fd3dbc  call rax
00007f8fe1fd3dbe  movaps xmm11, [rsp]
00007f8fe1fd3dc3  add rsp, 0x30
00007f8fe1fd3dc7  vmovaps xmm0, [rsp]
00007f8fe1fd3dcc  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd3dd2  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd3dd8  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd3dde  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd3de4  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd3dea  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd3df0  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd3df6  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd3dff  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd3e08  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd3e11  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd3e1a  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd3e23  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd3e2c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd3e35  add rsp, 0xF0
00007f8fe1fd3e3c  pop r11
00007f8fe1fd3e3e  pop r10
00007f8fe1fd3e40  pop r9
00007f8fe1fd3e42  pop r8
00007f8fe1fd3e44  pop rsi
00007f8fe1fd3e45  pop rdi
00007f8fe1fd3e46  pop rdx
00007f8fe1fd3e47  pop rcx
00007f8fe1fd3e48  pop rax
00007f8fe1fd3e49  add rsp, 0x08
00007f8fe1fd3e4d  jmp 0x00007F8FE1FD003F
00007f8fe1fd3e52  sub rsp, 0x08
00007f8fe1fd3e56  push rax
00007f8fe1fd3e57  push rcx
00007f8fe1fd3e58  push rdx
00007f8fe1fd3e59  push rdi
00007f8fe1fd3e5a  push rsi
00007f8fe1fd3e5b  push r8
00007f8fe1fd3e5d  push r9
00007f8fe1fd3e5f  push r10
00007f8fe1fd3e61  push r11
00007f8fe1fd3e63  sub rsp, 0xF0
00007f8fe1fd3e6a  vmovaps [rsp], xmm0
00007f8fe1fd3e6f  vmovaps [rsp+0x10], xmm1
00007f8fe1fd3e75  vmovaps [rsp+0x20], xmm2
00007f8fe1fd3e7b  vmovaps [rsp+0x30], xmm3
00007f8fe1fd3e81  vmovaps [rsp+0x40], xmm4
00007f8fe1fd3e87  vmovaps [rsp+0x50], xmm5
00007f8fe1fd3e8d  vmovaps [rsp+0x60], xmm6
00007f8fe1fd3e93  vmovaps [rsp+0x70], xmm7
00007f8fe1fd3e99  vmovaps [rsp+0x80], xmm8
00007f8fe1fd3ea2  vmovaps [rsp+0x90], xmm9
00007f8fe1fd3eab  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd3eb4  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd3ebd  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd3ec6  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd3ecf  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd3ed8  sub rsp, 0x30
00007f8fe1fd3edc  movaps [rsp], xmm13
00007f8fe1fd3ee1  movaps [rsp+0x10], xmm8
00007f8fe1fd3ee7  movaps [rsp+0x20], xmm14
00007f8fe1fd3eed  lea rdi, [rsp]
00007f8fe1fd3ef1  mov esi, 0x00
00007f8fe1fd3ef6  mov rax, 0x6020BB77F530
00007f8fe1fd3f00  call rax
00007f8fe1fd3f02  movaps xmm13, [rsp]
00007f8fe1fd3f07  add rsp, 0x30
00007f8fe1fd3f0b  vmovaps xmm0, [rsp]
00007f8fe1fd3f10  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd3f16  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd3f1c  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd3f22  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd3f28  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd3f2e  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd3f34  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd3f3a  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd3f43  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd3f4c  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd3f55  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd3f5e  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd3f67  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd3f70  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd3f79  add rsp, 0xF0
00007f8fe1fd3f80  pop r11
00007f8fe1fd3f82  pop r10
00007f8fe1fd3f84  pop r9
00007f8fe1fd3f86  pop r8
00007f8fe1fd3f88  pop rsi
00007f8fe1fd3f89  pop rdi
00007f8fe1fd3f8a  pop rdx
00007f8fe1fd3f8b  pop rcx
00007f8fe1fd3f8c  pop rax
00007f8fe1fd3f8d  add rsp, 0x08
00007f8fe1fd3f91  jmp 0x00007F8FE1FD006E
00007f8fe1fd3f96  sub rsp, 0x08
00007f8fe1fd3f9a  push rax
00007f8fe1fd3f9b  push rcx
00007f8fe1fd3f9c  push rdx
00007f8fe1fd3f9d  push rdi
00007f8fe1fd3f9e  push rsi
00007f8fe1fd3f9f  push r8
00007f8fe1fd3fa1  push r9
00007f8fe1fd3fa3  push r10
00007f8fe1fd3fa5  push r11
00007f8fe1fd3fa7  sub rsp, 0xF0
00007f8fe1fd3fae  vmovaps [rsp], xmm0
00007f8fe1fd3fb3  vmovaps [rsp+0x10], xmm1
00007f8fe1fd3fb9  vmovaps [rsp+0x20], xmm2
00007f8fe1fd3fbf  vmovaps [rsp+0x30], xmm3
00007f8fe1fd3fc5  vmovaps [rsp+0x40], xmm4
00007f8fe1fd3fcb  vmovaps [rsp+0x50], xmm5
00007f8fe1fd3fd1  vmovaps [rsp+0x60], xmm6
00007f8fe1fd3fd7  vmovaps [rsp+0x70], xmm7
00007f8fe1fd3fdd  vmovaps [rsp+0x80], xmm9
00007f8fe1fd3fe6  vmovaps [rsp+0x90], xmm10
00007f8fe1fd3fef  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd3ff8  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd4001  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd400a  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd4013  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd401c  sub rsp, 0x30
00007f8fe1fd4020  movaps [rsp], xmm8
00007f8fe1fd4025  movaps [rsp+0x10], xmm7
00007f8fe1fd402a  movaps [rsp+0x20], xmm14
00007f8fe1fd4030  lea rdi, [rsp]
00007f8fe1fd4034  mov esi, 0x00
00007f8fe1fd4039  mov rax, 0x6020BB77F530
00007f8fe1fd4043  call rax
00007f8fe1fd4045  movaps xmm8, [rsp]
00007f8fe1fd404a  add rsp, 0x30
00007f8fe1fd404e  vmovaps xmm0, [rsp]
00007f8fe1fd4053  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd4059  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd405f  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd4065  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd406b  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd4071  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd4077  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd407d  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd4086  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd408f  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd4098  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd40a1  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd40aa  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd40b3  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd40bc  add rsp, 0xF0
00007f8fe1fd40c3  pop r11
00007f8fe1fd40c5  pop r10
00007f8fe1fd40c7  pop r9
00007f8fe1fd40c9  pop r8
00007f8fe1fd40cb  pop rsi
00007f8fe1fd40cc  pop rdi
00007f8fe1fd40cd  pop rdx
00007f8fe1fd40ce  pop rcx
00007f8fe1fd40cf  pop rax
00007f8fe1fd40d0  add rsp, 0x08
00007f8fe1fd40d4  jmp 0x00007F8FE1FD0094
00007f8fe1fd40d9  sub rsp, 0x08
00007f8fe1fd40dd  push rax
00007f8fe1fd40de  push rcx
00007f8fe1fd40df  push rdx
00007f8fe1fd40e0  push rdi
00007f8fe1fd40e1  push rsi
00007f8fe1fd40e2  push r8
00007f8fe1fd40e4  push r9
00007f8fe1fd40e6  push r10
00007f8fe1fd40e8  push r11
00007f8fe1fd40ea  sub rsp, 0xF0
00007f8fe1fd40f1  vmovaps [rsp], xmm0
00007f8fe1fd40f6  vmovaps [rsp+0x10], xmm1
00007f8fe1fd40fc  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4102  vmovaps [rsp+0x30], xmm3
00007f8fe1fd4108  vmovaps [rsp+0x40], xmm4
00007f8fe1fd410e  vmovaps [rsp+0x50], xmm5
00007f8fe1fd4114  vmovaps [rsp+0x60], xmm6
00007f8fe1fd411a  vmovaps [rsp+0x70], xmm7
00007f8fe1fd4120  vmovaps [rsp+0x80], xmm8
00007f8fe1fd4129  vmovaps [rsp+0x90], xmm9
00007f8fe1fd4132  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd413b  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd4144  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd414d  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd4156  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd415f  sub rsp, 0x30
00007f8fe1fd4163  movaps [rsp], xmm14
00007f8fe1fd4168  movaps [rsp+0x10], xmm12
00007f8fe1fd416e  movaps [rsp+0x20], xmm9
00007f8fe1fd4174  lea rdi, [rsp]
00007f8fe1fd4178  mov esi, 0x00
00007f8fe1fd417d  mov rax, 0x6020BB77F530
00007f8fe1fd4187  call rax
00007f8fe1fd4189  movaps xmm14, [rsp]
00007f8fe1fd418e  add rsp, 0x30
00007f8fe1fd4192  vmovaps xmm0, [rsp]
00007f8fe1fd4197  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd419d  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd41a3  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd41a9  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd41af  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd41b5  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd41bb  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd41c1  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd41ca  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd41d3  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd41dc  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd41e5  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd41ee  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd41f7  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4200  add rsp, 0xF0
00007f8fe1fd4207  pop r11
00007f8fe1fd4209  pop r10
00007f8fe1fd420b  pop r9
00007f8fe1fd420d  pop r8
00007f8fe1fd420f  pop rsi
00007f8fe1fd4210  pop rdi
00007f8fe1fd4211  pop rdx
00007f8fe1fd4212  pop rcx
00007f8fe1fd4213  pop rax
00007f8fe1fd4214  add rsp, 0x08
00007f8fe1fd4218  jmp 0x00007F8FE1FD00AE
00007f8fe1fd421d  sub rsp, 0x08
00007f8fe1fd4221  push rax
00007f8fe1fd4222  push rcx
00007f8fe1fd4223  push rdx
00007f8fe1fd4224  push rdi
00007f8fe1fd4225  push rsi
00007f8fe1fd4226  push r8
00007f8fe1fd4228  push r9
00007f8fe1fd422a  push r10
00007f8fe1fd422c  push r11
00007f8fe1fd422e  sub rsp, 0xF0
00007f8fe1fd4235  vmovaps [rsp], xmm0
00007f8fe1fd423a  vmovaps [rsp+0x10], xmm1
00007f8fe1fd4240  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4246  vmovaps [rsp+0x30], xmm3
00007f8fe1fd424c  vmovaps [rsp+0x40], xmm4
00007f8fe1fd4252  vmovaps [rsp+0x50], xmm5
00007f8fe1fd4258  vmovaps [rsp+0x60], xmm6
00007f8fe1fd425e  vmovaps [rsp+0x70], xmm7
00007f8fe1fd4264  vmovaps [rsp+0x80], xmm8
00007f8fe1fd426d  vmovaps [rsp+0x90], xmm10
00007f8fe1fd4276  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd427f  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd4288  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd4291  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd429a  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd42a3  sub rsp, 0x30
00007f8fe1fd42a7  movaps [rsp], xmm9
00007f8fe1fd42ac  movaps [rsp+0x10], xmm7
00007f8fe1fd42b1  movaps [rsp+0x20], xmm12
00007f8fe1fd42b7  lea rdi, [rsp]
00007f8fe1fd42bb  mov esi, 0x00
00007f8fe1fd42c0  mov rax, 0x6020BB77F530
00007f8fe1fd42ca  call rax
00007f8fe1fd42cc  movaps xmm9, [rsp]
00007f8fe1fd42d1  add rsp, 0x30
00007f8fe1fd42d5  vmovaps xmm0, [rsp]
00007f8fe1fd42da  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd42e0  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd42e6  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd42ec  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd42f2  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd42f8  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd42fe  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd4304  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd430d  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd4316  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd431f  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd4328  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd4331  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd433a  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4343  add rsp, 0xF0
00007f8fe1fd434a  pop r11
00007f8fe1fd434c  pop r10
00007f8fe1fd434e  pop r9
00007f8fe1fd4350  pop r8
00007f8fe1fd4352  pop rsi
00007f8fe1fd4353  pop rdi
00007f8fe1fd4354  pop rdx
00007f8fe1fd4355  pop rcx
00007f8fe1fd4356  pop rax
00007f8fe1fd4357  add rsp, 0x08
00007f8fe1fd435b  jmp 0x00007F8FE1FD00DD
00007f8fe1fd4360  sub rsp, 0x08
00007f8fe1fd4364  push rax
00007f8fe1fd4365  push rcx
00007f8fe1fd4366  push rdx
00007f8fe1fd4367  push rdi
00007f8fe1fd4368  push rsi
00007f8fe1fd4369  push r8
00007f8fe1fd436b  push r9
00007f8fe1fd436d  push r10
00007f8fe1fd436f  push r11
00007f8fe1fd4371  sub rsp, 0xF0
00007f8fe1fd4378  vmovaps [rsp], xmm0
00007f8fe1fd437d  vmovaps [rsp+0x10], xmm1
00007f8fe1fd4383  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4389  vmovaps [rsp+0x30], xmm3
00007f8fe1fd438f  vmovaps [rsp+0x40], xmm4
00007f8fe1fd4395  vmovaps [rsp+0x50], xmm5
00007f8fe1fd439b  vmovaps [rsp+0x60], xmm6
00007f8fe1fd43a1  vmovaps [rsp+0x70], xmm7
00007f8fe1fd43a7  vmovaps [rsp+0x80], xmm8
00007f8fe1fd43b0  vmovaps [rsp+0x90], xmm9
00007f8fe1fd43b9  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd43c2  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd43cb  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd43d4  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd43dd  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd43e6  sub rsp, 0x30
00007f8fe1fd43ea  movaps [rsp], xmm12
00007f8fe1fd43ef  movaps [rsp+0x10], xmm15
00007f8fe1fd43f5  movaps [rsp+0x20], xmm11
00007f8fe1fd43fb  lea rdi, [rsp]
00007f8fe1fd43ff  mov esi, 0x00
00007f8fe1fd4404  mov rax, 0x6020BB77F530
00007f8fe1fd440e  call rax
00007f8fe1fd4410  movaps xmm12, [rsp]
00007f8fe1fd4415  add rsp, 0x30
00007f8fe1fd4419  vmovaps xmm0, [rsp]
00007f8fe1fd441e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd4424  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd442a  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd4430  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd4436  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd443c  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd4442  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd4448  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd4451  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd445a  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd4463  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd446c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd4475  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd447e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4487  add rsp, 0xF0
00007f8fe1fd448e  pop r11
00007f8fe1fd4490  pop r10
00007f8fe1fd4492  pop r9
00007f8fe1fd4494  pop r8
00007f8fe1fd4496  pop rsi
00007f8fe1fd4497  pop rdi
00007f8fe1fd4498  pop rdx
00007f8fe1fd4499  pop rcx
00007f8fe1fd449a  pop rax
00007f8fe1fd449b  add rsp, 0x08
00007f8fe1fd449f  jmp 0x00007F8FE1FD00F7
00007f8fe1fd44a4  sub rsp, 0x08
00007f8fe1fd44a8  push rax
00007f8fe1fd44a9  push rcx
00007f8fe1fd44aa  push rdx
00007f8fe1fd44ab  push rdi
00007f8fe1fd44ac  push rsi
00007f8fe1fd44ad  push r8
00007f8fe1fd44af  push r9
00007f8fe1fd44b1  push r10
00007f8fe1fd44b3  push r11
00007f8fe1fd44b5  sub rsp, 0xF0
00007f8fe1fd44bc  vmovaps [rsp], xmm0
00007f8fe1fd44c1  vmovaps [rsp+0x10], xmm1
00007f8fe1fd44c7  vmovaps [rsp+0x20], xmm2
00007f8fe1fd44cd  vmovaps [rsp+0x30], xmm3
00007f8fe1fd44d3  vmovaps [rsp+0x40], xmm4
00007f8fe1fd44d9  vmovaps [rsp+0x50], xmm5
00007f8fe1fd44df  vmovaps [rsp+0x60], xmm6
00007f8fe1fd44e5  vmovaps [rsp+0x70], xmm7
00007f8fe1fd44eb  vmovaps [rsp+0x80], xmm8
00007f8fe1fd44f4  vmovaps [rsp+0x90], xmm9
00007f8fe1fd44fd  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd4506  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd450f  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd4518  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd4521  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd452a  sub rsp, 0x30
00007f8fe1fd452e  movaps [rsp], xmm11
00007f8fe1fd4533  movaps [rsp+0x10], xmm7
00007f8fe1fd4538  movaps [rsp+0x20], xmm15
00007f8fe1fd453e  lea rdi, [rsp]
00007f8fe1fd4542  mov esi, 0x00
00007f8fe1fd4547  mov rax, 0x6020BB77F530
00007f8fe1fd4551  call rax
00007f8fe1fd4553  movaps xmm11, [rsp]
00007f8fe1fd4558  add rsp, 0x30
00007f8fe1fd455c  vmovaps xmm0, [rsp]
00007f8fe1fd4561  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd4567  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd456d  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd4573  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd4579  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd457f  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd4585  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd458b  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd4594  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd459d  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd45a6  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd45af  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd45b8  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd45c1  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd45ca  add rsp, 0xF0
00007f8fe1fd45d1  pop r11
00007f8fe1fd45d3  pop r10
00007f8fe1fd45d5  pop r9
00007f8fe1fd45d7  pop r8
00007f8fe1fd45d9  pop rsi
00007f8fe1fd45da  pop rdi
00007f8fe1fd45db  pop rdx
00007f8fe1fd45dc  pop rcx
00007f8fe1fd45dd  pop rax
00007f8fe1fd45de  add rsp, 0x08
00007f8fe1fd45e2  jmp 0x00007F8FE1FD0123
00007f8fe1fd45e7  sub rsp, 0x08
00007f8fe1fd45eb  push rax
00007f8fe1fd45ec  push rcx
00007f8fe1fd45ed  push rdx
00007f8fe1fd45ee  push rdi
00007f8fe1fd45ef  push rsi
00007f8fe1fd45f0  push r8
00007f8fe1fd45f2  push r9
00007f8fe1fd45f4  push r10
00007f8fe1fd45f6  push r11
00007f8fe1fd45f8  sub rsp, 0xF0
00007f8fe1fd45ff  vmovaps [rsp], xmm0
00007f8fe1fd4604  vmovaps [rsp+0x10], xmm1
00007f8fe1fd460a  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4610  vmovaps [rsp+0x30], xmm3
00007f8fe1fd4616  vmovaps [rsp+0x40], xmm4
00007f8fe1fd461c  vmovaps [rsp+0x50], xmm5
00007f8fe1fd4622  vmovaps [rsp+0x60], xmm6
00007f8fe1fd4628  vmovaps [rsp+0x70], xmm7
00007f8fe1fd462e  vmovaps [rsp+0x80], xmm8
00007f8fe1fd4637  vmovaps [rsp+0x90], xmm9
00007f8fe1fd4640  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd4649  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd4652  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd465b  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd4664  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd466d  sub rsp, 0x30
00007f8fe1fd4671  movaps [rsp], xmm15
00007f8fe1fd4676  movaps [rsp+0x10], xmm10
00007f8fe1fd467c  movaps [rsp+0x20], xmm13
00007f8fe1fd4682  lea rdi, [rsp]
00007f8fe1fd4686  mov esi, 0x00
00007f8fe1fd468b  mov rax, 0x6020BB77F530
00007f8fe1fd4695  call rax
00007f8fe1fd4697  movaps xmm15, [rsp]
00007f8fe1fd469c  add rsp, 0x30
00007f8fe1fd46a0  vmovaps xmm0, [rsp]
00007f8fe1fd46a5  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd46ab  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd46b1  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd46b7  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd46bd  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd46c3  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd46c9  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd46cf  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd46d8  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd46e1  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd46ea  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd46f3  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd46fc  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd4705  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd470e  add rsp, 0xF0
00007f8fe1fd4715  pop r11
00007f8fe1fd4717  pop r10
00007f8fe1fd4719  pop r9
00007f8fe1fd471b  pop r8
00007f8fe1fd471d  pop rsi
00007f8fe1fd471e  pop rdi
00007f8fe1fd471f  pop rdx
00007f8fe1fd4720  pop rcx
00007f8fe1fd4721  pop rax
00007f8fe1fd4722  add rsp, 0x08
00007f8fe1fd4726  jmp 0x00007F8FE1FD013D
00007f8fe1fd472b  sub rsp, 0x08
00007f8fe1fd472f  push rax
00007f8fe1fd4730  push rcx
00007f8fe1fd4731  push rdx
00007f8fe1fd4732  push rdi
00007f8fe1fd4733  push rsi
00007f8fe1fd4734  push r8
00007f8fe1fd4736  push r9
00007f8fe1fd4738  push r10
00007f8fe1fd473a  push r11
00007f8fe1fd473c  sub rsp, 0xF0
00007f8fe1fd4743  vmovaps [rsp], xmm0
00007f8fe1fd4748  vmovaps [rsp+0x10], xmm1
00007f8fe1fd474e  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4754  vmovaps [rsp+0x30], xmm3
00007f8fe1fd475a  vmovaps [rsp+0x40], xmm4
00007f8fe1fd4760  vmovaps [rsp+0x50], xmm5
00007f8fe1fd4766  vmovaps [rsp+0x60], xmm6
00007f8fe1fd476c  vmovaps [rsp+0x70], xmm7
00007f8fe1fd4772  vmovaps [rsp+0x80], xmm8
00007f8fe1fd477b  vmovaps [rsp+0x90], xmm9
00007f8fe1fd4784  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd478d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd4796  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd479f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd47a8  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd47b1  sub rsp, 0x30
00007f8fe1fd47b5  movaps [rsp], xmm10
00007f8fe1fd47ba  movaps [rsp+0x10], xmm7
00007f8fe1fd47bf  movaps [rsp+0x20], xmm13
00007f8fe1fd47c5  lea rdi, [rsp]
00007f8fe1fd47c9  mov esi, 0x00
00007f8fe1fd47ce  mov rax, 0x6020BB77F530
00007f8fe1fd47d8  call rax
00007f8fe1fd47da  movaps xmm10, [rsp]
00007f8fe1fd47df  add rsp, 0x30
00007f8fe1fd47e3  vmovaps xmm0, [rsp]
00007f8fe1fd47e8  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd47ee  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd47f4  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd47fa  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd4800  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd4806  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd480c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd4812  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd481b  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd4824  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd482d  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd4836  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd483f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd4848  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4851  add rsp, 0xF0
00007f8fe1fd4858  pop r11
00007f8fe1fd485a  pop r10
00007f8fe1fd485c  pop r9
00007f8fe1fd485e  pop r8
00007f8fe1fd4860  pop rsi
00007f8fe1fd4861  pop rdi
00007f8fe1fd4862  pop rdx
00007f8fe1fd4863  pop rcx
00007f8fe1fd4864  pop rax
00007f8fe1fd4865  add rsp, 0x08
00007f8fe1fd4869  jmp 0x00007F8FE1FD0169
00007f8fe1fd486e  sub rsp, 0x08
00007f8fe1fd4872  push rax
00007f8fe1fd4873  push rcx
00007f8fe1fd4874  push rdx
00007f8fe1fd4875  push rdi
00007f8fe1fd4876  push rsi
00007f8fe1fd4877  push r8
00007f8fe1fd4879  push r9
00007f8fe1fd487b  push r10
00007f8fe1fd487d  push r11
00007f8fe1fd487f  sub rsp, 0xF0
00007f8fe1fd4886  vmovaps [rsp], xmm0
00007f8fe1fd488b  vmovaps [rsp+0x10], xmm1
00007f8fe1fd4891  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4897  vmovaps [rsp+0x30], xmm3
00007f8fe1fd489d  vmovaps [rsp+0x40], xmm4
00007f8fe1fd48a3  vmovaps [rsp+0x50], xmm5
00007f8fe1fd48a9  vmovaps [rsp+0x60], xmm6
00007f8fe1fd48af  vmovaps [rsp+0x70], xmm7
00007f8fe1fd48b5  vmovaps [rsp+0x80], xmm8
00007f8fe1fd48be  vmovaps [rsp+0x90], xmm9
00007f8fe1fd48c7  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd48d0  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd48d9  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd48e2  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd48eb  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd48f4  sub rsp, 0x30
00007f8fe1fd48f8  movaps [rsp], xmm13
00007f8fe1fd48fd  movaps [rsp+0x10], xmm1
00007f8fe1fd4902  movaps [rsp+0x20], xmm8
00007f8fe1fd4908  lea rdi, [rsp]
00007f8fe1fd490c  mov esi, 0x00
00007f8fe1fd4911  mov rax, 0x6020BB77F530
00007f8fe1fd491b  call rax
00007f8fe1fd491d  movaps xmm13, [rsp]
00007f8fe1fd4922  add rsp, 0x30
00007f8fe1fd4926  vmovaps xmm0, [rsp]
00007f8fe1fd492b  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd4931  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd4937  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd493d  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd4943  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd4949  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd494f  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd4955  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd495e  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd4967  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd4970  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd4979  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd4982  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd498b  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4994  add rsp, 0xF0
00007f8fe1fd499b  pop r11
00007f8fe1fd499d  pop r10
00007f8fe1fd499f  pop r9
00007f8fe1fd49a1  pop r8
00007f8fe1fd49a3  pop rsi
00007f8fe1fd49a4  pop rdi
00007f8fe1fd49a5  pop rdx
00007f8fe1fd49a6  pop rcx
00007f8fe1fd49a7  pop rax
00007f8fe1fd49a8  add rsp, 0x08
00007f8fe1fd49ac  jmp 0x00007F8FE1FD0183
00007f8fe1fd49b1  call 0x00007F8FE1DFF430
00007f8fe1fd49b6  jmp 0x00007F8FE1FD018D
00007f8fe1fd49bb  sub rsp, 0x08
00007f8fe1fd49bf  push rax
00007f8fe1fd49c0  push rcx
00007f8fe1fd49c1  push rdx
00007f8fe1fd49c2  push rdi
00007f8fe1fd49c3  push rsi
00007f8fe1fd49c4  push r8
00007f8fe1fd49c6  push r9
00007f8fe1fd49c8  push r10
00007f8fe1fd49ca  push r11
00007f8fe1fd49cc  sub rsp, 0xF0
00007f8fe1fd49d3  vmovaps [rsp], xmm0
00007f8fe1fd49d8  vmovaps [rsp+0x10], xmm1
00007f8fe1fd49de  vmovaps [rsp+0x20], xmm2
00007f8fe1fd49e4  vmovaps [rsp+0x30], xmm3
00007f8fe1fd49ea  vmovaps [rsp+0x40], xmm4
00007f8fe1fd49f0  vmovaps [rsp+0x50], xmm5
00007f8fe1fd49f6  vmovaps [rsp+0x60], xmm6
00007f8fe1fd49fc  vmovaps [rsp+0x70], xmm7
00007f8fe1fd4a02  vmovaps [rsp+0x80], xmm9
00007f8fe1fd4a0b  vmovaps [rsp+0x90], xmm10
00007f8fe1fd4a14  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd4a1d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd4a26  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd4a2f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd4a38  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd4a41  sub rsp, 0x30
00007f8fe1fd4a45  movaps [rsp], xmm8
00007f8fe1fd4a4a  movaps [rsp+0x10], xmm14
00007f8fe1fd4a50  movaps [rsp+0x20], xmm9
00007f8fe1fd4a56  lea rdi, [rsp]
00007f8fe1fd4a5a  mov esi, 0x00
00007f8fe1fd4a5f  mov rax, 0x6020BB77F530
00007f8fe1fd4a69  call rax
00007f8fe1fd4a6b  movaps xmm8, [rsp]
00007f8fe1fd4a70  add rsp, 0x30
00007f8fe1fd4a74  vmovaps xmm0, [rsp]
00007f8fe1fd4a79  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd4a7f  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd4a85  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd4a8b  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd4a91  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd4a97  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd4a9d  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd4aa3  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd4aac  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd4ab5  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd4abe  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd4ac7  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd4ad0  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd4ad9  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4ae2  add rsp, 0xF0
00007f8fe1fd4ae9  pop r11
00007f8fe1fd4aeb  pop r10
00007f8fe1fd4aed  pop r9
00007f8fe1fd4aef  pop r8
00007f8fe1fd4af1  pop rsi
00007f8fe1fd4af2  pop rdi
00007f8fe1fd4af3  pop rdx
00007f8fe1fd4af4  pop rcx
00007f8fe1fd4af5  pop rax
00007f8fe1fd4af6  add rsp, 0x08
00007f8fe1fd4afa  jmp 0x00007F8FE1FD01AF
00007f8fe1fd4aff  sub rsp, 0x08
00007f8fe1fd4b03  push rax
00007f8fe1fd4b04  push rcx
00007f8fe1fd4b05  push rdx
00007f8fe1fd4b06  push rdi
00007f8fe1fd4b07  push rsi
00007f8fe1fd4b08  push r8
00007f8fe1fd4b0a  push r9
00007f8fe1fd4b0c  push r10
00007f8fe1fd4b0e  push r11
00007f8fe1fd4b10  sub rsp, 0xF0
00007f8fe1fd4b17  vmovaps [rsp], xmm0
00007f8fe1fd4b1c  vmovaps [rsp+0x10], xmm1
00007f8fe1fd4b22  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4b28  vmovaps [rsp+0x30], xmm3
00007f8fe1fd4b2e  vmovaps [rsp+0x40], xmm4
00007f8fe1fd4b34  vmovaps [rsp+0x50], xmm5
00007f8fe1fd4b3a  vmovaps [rsp+0x60], xmm6
00007f8fe1fd4b40  vmovaps [rsp+0x70], xmm7
00007f8fe1fd4b46  vmovaps [rsp+0x80], xmm8
00007f8fe1fd4b4f  vmovaps [rsp+0x90], xmm10
00007f8fe1fd4b58  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd4b61  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd4b6a  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd4b73  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd4b7c  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd4b85  sub rsp, 0x30
00007f8fe1fd4b89  movaps [rsp], xmm9
00007f8fe1fd4b8e  movaps [rsp+0x10], xmm1
00007f8fe1fd4b93  movaps [rsp+0x20], xmm14
00007f8fe1fd4b99  lea rdi, [rsp]
00007f8fe1fd4b9d  mov esi, 0x00
00007f8fe1fd4ba2  mov rax, 0x6020BB77F530
00007f8fe1fd4bac  call rax
00007f8fe1fd4bae  movaps xmm9, [rsp]
00007f8fe1fd4bb3  add rsp, 0x30
00007f8fe1fd4bb7  vmovaps xmm0, [rsp]
00007f8fe1fd4bbc  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd4bc2  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd4bc8  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd4bce  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd4bd4  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd4bda  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd4be0  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd4be6  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd4bef  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd4bf8  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd4c01  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd4c0a  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd4c13  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd4c1c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4c25  add rsp, 0xF0
00007f8fe1fd4c2c  pop r11
00007f8fe1fd4c2e  pop r10
00007f8fe1fd4c30  pop r9
00007f8fe1fd4c32  pop r8
00007f8fe1fd4c34  pop rsi
00007f8fe1fd4c35  pop rdi
00007f8fe1fd4c36  pop rdx
00007f8fe1fd4c37  pop rcx
00007f8fe1fd4c38  pop rax
00007f8fe1fd4c39  add rsp, 0x08
00007f8fe1fd4c3d  jmp 0x00007F8FE1FD01DD
00007f8fe1fd4c42  sub rsp, 0x08
00007f8fe1fd4c46  push rax
00007f8fe1fd4c47  push rcx
00007f8fe1fd4c48  push rdx
00007f8fe1fd4c49  push rdi
00007f8fe1fd4c4a  push rsi
00007f8fe1fd4c4b  push r8
00007f8fe1fd4c4d  push r9
00007f8fe1fd4c4f  push r10
00007f8fe1fd4c51  push r11
00007f8fe1fd4c53  sub rsp, 0xF0
00007f8fe1fd4c5a  vmovaps [rsp], xmm0
00007f8fe1fd4c5f  vmovaps [rsp+0x10], xmm1
00007f8fe1fd4c65  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4c6b  vmovaps [rsp+0x30], xmm3
00007f8fe1fd4c71  vmovaps [rsp+0x40], xmm4
00007f8fe1fd4c77  vmovaps [rsp+0x50], xmm5
00007f8fe1fd4c7d  vmovaps [rsp+0x60], xmm6
00007f8fe1fd4c83  vmovaps [rsp+0x70], xmm7
00007f8fe1fd4c89  vmovaps [rsp+0x80], xmm8
00007f8fe1fd4c92  vmovaps [rsp+0x90], xmm9
00007f8fe1fd4c9b  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd4ca4  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd4cad  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd4cb6  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd4cbf  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd4cc8  sub rsp, 0x30
00007f8fe1fd4ccc  movaps [rsp], xmm14
00007f8fe1fd4cd1  movaps [rsp+0x10], xmm4
00007f8fe1fd4cd6  movaps [rsp+0x20], xmm1
00007f8fe1fd4cdb  lea rdi, [rsp]
00007f8fe1fd4cdf  mov esi, 0x00
00007f8fe1fd4ce4  mov rax, 0x6020BB77F530
00007f8fe1fd4cee  call rax
00007f8fe1fd4cf0  movaps xmm14, [rsp]
00007f8fe1fd4cf5  add rsp, 0x30
00007f8fe1fd4cf9  vmovaps xmm0, [rsp]
00007f8fe1fd4cfe  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd4d04  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd4d0a  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd4d10  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd4d16  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd4d1c  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd4d22  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd4d28  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd4d31  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd4d3a  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd4d43  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd4d4c  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd4d55  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd4d5e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4d67  add rsp, 0xF0
00007f8fe1fd4d6e  pop r11
00007f8fe1fd4d70  pop r10
00007f8fe1fd4d72  pop r9
00007f8fe1fd4d74  pop r8
00007f8fe1fd4d76  pop rsi
00007f8fe1fd4d77  pop rdi
00007f8fe1fd4d78  pop rdx
00007f8fe1fd4d79  pop rcx
00007f8fe1fd4d7a  pop rax
00007f8fe1fd4d7b  add rsp, 0x08
00007f8fe1fd4d7f  jmp 0x00007F8FE1FD0203
00007f8fe1fd4d84  sub rsp, 0x08
00007f8fe1fd4d88  push rax
00007f8fe1fd4d89  push rcx
00007f8fe1fd4d8a  push rdx
00007f8fe1fd4d8b  push rdi
00007f8fe1fd4d8c  push rsi
00007f8fe1fd4d8d  push r8
00007f8fe1fd4d8f  push r9
00007f8fe1fd4d91  push r10
00007f8fe1fd4d93  push r11
00007f8fe1fd4d95  sub rsp, 0xF0
00007f8fe1fd4d9c  vmovaps [rsp], xmm0
00007f8fe1fd4da1  vmovaps [rsp+0x10], xmm2
00007f8fe1fd4da7  vmovaps [rsp+0x20], xmm3
00007f8fe1fd4dad  vmovaps [rsp+0x30], xmm4
00007f8fe1fd4db3  vmovaps [rsp+0x40], xmm5
00007f8fe1fd4db9  vmovaps [rsp+0x50], xmm6
00007f8fe1fd4dbf  vmovaps [rsp+0x60], xmm7
00007f8fe1fd4dc5  vmovaps [rsp+0x70], xmm8
00007f8fe1fd4dcb  vmovaps [rsp+0x80], xmm9
00007f8fe1fd4dd4  vmovaps [rsp+0x90], xmm10
00007f8fe1fd4ddd  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd4de6  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd4def  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd4df8  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd4e01  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd4e0a  sub rsp, 0x30
00007f8fe1fd4e0e  movaps [rsp], xmm1
00007f8fe1fd4e12  movaps [rsp+0x10], xmm12
00007f8fe1fd4e18  movaps [rsp+0x20], xmm11
00007f8fe1fd4e1e  lea rdi, [rsp]
00007f8fe1fd4e22  mov esi, 0x00
00007f8fe1fd4e27  mov rax, 0x6020BB77F530
00007f8fe1fd4e31  call rax
00007f8fe1fd4e33  movaps xmm1, [rsp]
00007f8fe1fd4e37  add rsp, 0x30
00007f8fe1fd4e3b  vmovaps xmm0, [rsp]
00007f8fe1fd4e40  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd4e46  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd4e4c  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd4e52  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd4e58  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd4e5e  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd4e64  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd4e6a  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd4e73  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd4e7c  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd4e85  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd4e8e  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd4e97  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd4ea0  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4ea9  add rsp, 0xF0
00007f8fe1fd4eb0  pop r11
00007f8fe1fd4eb2  pop r10
00007f8fe1fd4eb4  pop r9
00007f8fe1fd4eb6  pop r8
00007f8fe1fd4eb8  pop rsi
00007f8fe1fd4eb9  pop rdi
00007f8fe1fd4eba  pop rdx
00007f8fe1fd4ebb  pop rcx
00007f8fe1fd4ebc  pop rax
00007f8fe1fd4ebd  add rsp, 0x08
00007f8fe1fd4ec1  jmp 0x00007F8FE1FD0224
00007f8fe1fd4ec6  call 0x00007F8FE1EE20A0
00007f8fe1fd4ecb  jmp 0x00007F8FE1FD0232
00007f8fe1fd4ed0  call 0x00007F8FE1E09D70
00007f8fe1fd4ed5  jmp 0x00007F8FE1FD023C
00007f8fe1fd4eda  sub rsp, 0x08
00007f8fe1fd4ede  push rax
00007f8fe1fd4edf  push rcx
00007f8fe1fd4ee0  push rdx
00007f8fe1fd4ee1  push rdi
00007f8fe1fd4ee2  push rsi
00007f8fe1fd4ee3  push r8
00007f8fe1fd4ee5  push r9
00007f8fe1fd4ee7  push r10
00007f8fe1fd4ee9  push r11
00007f8fe1fd4eeb  sub rsp, 0xF0
00007f8fe1fd4ef2  vmovaps [rsp], xmm0
00007f8fe1fd4ef7  vmovaps [rsp+0x10], xmm1
00007f8fe1fd4efd  vmovaps [rsp+0x20], xmm2
00007f8fe1fd4f03  vmovaps [rsp+0x30], xmm3
00007f8fe1fd4f09  vmovaps [rsp+0x40], xmm4
00007f8fe1fd4f0f  vmovaps [rsp+0x50], xmm5
00007f8fe1fd4f15  vmovaps [rsp+0x60], xmm6
00007f8fe1fd4f1b  vmovaps [rsp+0x70], xmm8
00007f8fe1fd4f21  vmovaps [rsp+0x80], xmm9
00007f8fe1fd4f2a  vmovaps [rsp+0x90], xmm10
00007f8fe1fd4f33  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd4f3c  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd4f45  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd4f4e  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd4f57  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd4f60  sub rsp, 0x30
00007f8fe1fd4f64  movaps [rsp], xmm7
00007f8fe1fd4f68  movaps [rsp+0x10], xmm15
00007f8fe1fd4f6e  movaps [rsp+0x20], xmm10
00007f8fe1fd4f74  lea rdi, [rsp]
00007f8fe1fd4f78  mov esi, 0x00
00007f8fe1fd4f7d  mov rax, 0x6020BB77F530
00007f8fe1fd4f87  call rax
00007f8fe1fd4f89  movaps xmm7, [rsp]
00007f8fe1fd4f8d  add rsp, 0x30
00007f8fe1fd4f91  vmovaps xmm0, [rsp]
00007f8fe1fd4f96  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd4f9c  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd4fa2  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd4fa8  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd4fae  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd4fb4  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd4fba  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd4fc0  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd4fc9  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd4fd2  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd4fdb  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd4fe4  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd4fed  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd4ff6  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd4fff  add rsp, 0xF0
00007f8fe1fd5006  pop r11
00007f8fe1fd5008  pop r10
00007f8fe1fd500a  pop r9
00007f8fe1fd500c  pop r8
00007f8fe1fd500e  pop rsi
00007f8fe1fd500f  pop rdi
00007f8fe1fd5010  pop rdx
00007f8fe1fd5011  pop rcx
00007f8fe1fd5012  pop rax
00007f8fe1fd5013  add rsp, 0x08
00007f8fe1fd5017  jmp 0x00007F8FE1FD025D
00007f8fe1fd501c  sub rsp, 0x08
00007f8fe1fd5020  push rax
00007f8fe1fd5021  push rcx
00007f8fe1fd5022  push rdx
00007f8fe1fd5023  push rdi
00007f8fe1fd5024  push rsi
00007f8fe1fd5025  push r8
00007f8fe1fd5027  push r9
00007f8fe1fd5029  push r10
00007f8fe1fd502b  push r11
00007f8fe1fd502d  sub rsp, 0xF0
00007f8fe1fd5034  vmovaps [rsp], xmm0
00007f8fe1fd5039  vmovaps [rsp+0x10], xmm1
00007f8fe1fd503f  vmovaps [rsp+0x20], xmm2
00007f8fe1fd5045  vmovaps [rsp+0x30], xmm3
00007f8fe1fd504b  vmovaps [rsp+0x40], xmm4
00007f8fe1fd5051  vmovaps [rsp+0x50], xmm5
00007f8fe1fd5057  vmovaps [rsp+0x60], xmm6
00007f8fe1fd505d  vmovaps [rsp+0x70], xmm7
00007f8fe1fd5063  vmovaps [rsp+0x80], xmm8
00007f8fe1fd506c  vmovaps [rsp+0x90], xmm9
00007f8fe1fd5075  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd507e  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd5087  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd5090  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd5099  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd50a2  sub rsp, 0x30
00007f8fe1fd50a6  movaps [rsp], xmm10
00007f8fe1fd50ab  movaps [rsp+0x10], xmm11
00007f8fe1fd50b1  movaps [rsp+0x20], xmm15
00007f8fe1fd50b7  lea rdi, [rsp]
00007f8fe1fd50bb  mov esi, 0x00
00007f8fe1fd50c0  mov rax, 0x6020BB77F530
00007f8fe1fd50ca  call rax
00007f8fe1fd50cc  movaps xmm10, [rsp]
00007f8fe1fd50d1  add rsp, 0x30
00007f8fe1fd50d5  vmovaps xmm0, [rsp]
00007f8fe1fd50da  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd50e0  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd50e6  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd50ec  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd50f2  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd50f8  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd50fe  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd5104  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd510d  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd5116  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd511f  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd5128  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd5131  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd513a  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd5143  add rsp, 0xF0
00007f8fe1fd514a  pop r11
00007f8fe1fd514c  pop r10
00007f8fe1fd514e  pop r9
00007f8fe1fd5150  pop r8
00007f8fe1fd5152  pop rsi
00007f8fe1fd5153  pop rdi
00007f8fe1fd5154  pop rdx
00007f8fe1fd5155  pop rcx
00007f8fe1fd5156  pop rax
00007f8fe1fd5157  add rsp, 0x08
00007f8fe1fd515b  jmp 0x00007F8FE1FD028B
00007f8fe1fd5160  sub rsp, 0x08
00007f8fe1fd5164  push rax
00007f8fe1fd5165  push rcx
00007f8fe1fd5166  push rdx
00007f8fe1fd5167  push rdi
00007f8fe1fd5168  push rsi
00007f8fe1fd5169  push r8
00007f8fe1fd516b  push r9
00007f8fe1fd516d  push r10
00007f8fe1fd516f  push r11
00007f8fe1fd5171  sub rsp, 0xF0
00007f8fe1fd5178  vmovaps [rsp], xmm0
00007f8fe1fd517d  vmovaps [rsp+0x10], xmm1
00007f8fe1fd5183  vmovaps [rsp+0x20], xmm2
00007f8fe1fd5189  vmovaps [rsp+0x30], xmm3
00007f8fe1fd518f  vmovaps [rsp+0x40], xmm4
00007f8fe1fd5195  vmovaps [rsp+0x50], xmm5
00007f8fe1fd519b  vmovaps [rsp+0x60], xmm6
00007f8fe1fd51a1  vmovaps [rsp+0x70], xmm7
00007f8fe1fd51a7  vmovaps [rsp+0x80], xmm8
00007f8fe1fd51b0  vmovaps [rsp+0x90], xmm9
00007f8fe1fd51b9  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd51c2  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd51cb  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd51d4  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd51dd  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd51e6  sub rsp, 0x30
00007f8fe1fd51ea  movaps [rsp], xmm11
00007f8fe1fd51ef  movaps [rsp+0x10], xmm12
00007f8fe1fd51f5  movaps [rsp+0x20], xmm15
00007f8fe1fd51fb  lea rdi, [rsp]
00007f8fe1fd51ff  mov esi, 0x00
00007f8fe1fd5204  mov rax, 0x6020BB77F530
00007f8fe1fd520e  call rax
00007f8fe1fd5210  movaps xmm11, [rsp]
00007f8fe1fd5215  add rsp, 0x30
00007f8fe1fd5219  vmovaps xmm0, [rsp]
00007f8fe1fd521e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd5224  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd522a  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd5230  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd5236  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd523c  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd5242  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd5248  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd5251  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd525a  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd5263  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd526c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd5275  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd527e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd5287  add rsp, 0xF0
00007f8fe1fd528e  pop r11
00007f8fe1fd5290  pop r10
00007f8fe1fd5292  pop r9
00007f8fe1fd5294  pop r8
00007f8fe1fd5296  pop rsi
00007f8fe1fd5297  pop rdi
00007f8fe1fd5298  pop rdx
00007f8fe1fd5299  pop rcx
00007f8fe1fd529a  pop rax
00007f8fe1fd529b  add rsp, 0x08
00007f8fe1fd529f  jmp 0x00007F8FE1FD02B9
00007f8fe1fd52a4  sub rsp, 0x08
00007f8fe1fd52a8  push rax
00007f8fe1fd52a9  push rcx
00007f8fe1fd52aa  push rdx
00007f8fe1fd52ab  push rdi
00007f8fe1fd52ac  push rsi
00007f8fe1fd52ad  push r8
00007f8fe1fd52af  push r9
00007f8fe1fd52b1  push r10
00007f8fe1fd52b3  push r11
00007f8fe1fd52b5  sub rsp, 0xF0
00007f8fe1fd52bc  vmovaps [rsp], xmm0
00007f8fe1fd52c1  vmovaps [rsp+0x10], xmm1
00007f8fe1fd52c7  vmovaps [rsp+0x20], xmm2
00007f8fe1fd52cd  vmovaps [rsp+0x30], xmm3
00007f8fe1fd52d3  vmovaps [rsp+0x40], xmm4
00007f8fe1fd52d9  vmovaps [rsp+0x50], xmm5
00007f8fe1fd52df  vmovaps [rsp+0x60], xmm6
00007f8fe1fd52e5  vmovaps [rsp+0x70], xmm7
00007f8fe1fd52eb  vmovaps [rsp+0x80], xmm8
00007f8fe1fd52f4  vmovaps [rsp+0x90], xmm9
00007f8fe1fd52fd  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd5306  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd530f  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd5318  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd5321  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd532a  sub rsp, 0x30
00007f8fe1fd532e  movaps [rsp], xmm15
00007f8fe1fd5333  movaps [rsp+0x10], xmm13
00007f8fe1fd5339  movaps [rsp+0x20], xmm9
00007f8fe1fd533f  lea rdi, [rsp]
00007f8fe1fd5343  mov esi, 0x00
00007f8fe1fd5348  mov rax, 0x6020BB77F530
00007f8fe1fd5352  call rax
00007f8fe1fd5354  movaps xmm15, [rsp]
00007f8fe1fd5359  add rsp, 0x30
00007f8fe1fd535d  vmovaps xmm0, [rsp]
00007f8fe1fd5362  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd5368  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd536e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd5374  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd537a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd5380  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd5386  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd538c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd5395  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd539e  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd53a7  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd53b0  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd53b9  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd53c2  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd53cb  add rsp, 0xF0
00007f8fe1fd53d2  pop r11
00007f8fe1fd53d4  pop r10
00007f8fe1fd53d6  pop r9
00007f8fe1fd53d8  pop r8
00007f8fe1fd53da  pop rsi
00007f8fe1fd53db  pop rdi
00007f8fe1fd53dc  pop rdx
00007f8fe1fd53dd  pop rcx
00007f8fe1fd53de  pop rax
00007f8fe1fd53df  add rsp, 0x08
00007f8fe1fd53e3  jmp 0x00007F8FE1FD02D4
00007f8fe1fd53e8  sub rsp, 0x08
00007f8fe1fd53ec  push rax
00007f8fe1fd53ed  push rcx
00007f8fe1fd53ee  push rdx
00007f8fe1fd53ef  push rdi
00007f8fe1fd53f0  push rsi
00007f8fe1fd53f1  push r8
00007f8fe1fd53f3  push r9
00007f8fe1fd53f5  push r10
00007f8fe1fd53f7  push r11
00007f8fe1fd53f9  sub rsp, 0xF0
00007f8fe1fd5400  vmovaps [rsp], xmm0
00007f8fe1fd5405  vmovaps [rsp+0x10], xmm1
00007f8fe1fd540b  vmovaps [rsp+0x20], xmm2
00007f8fe1fd5411  vmovaps [rsp+0x30], xmm3
00007f8fe1fd5417  vmovaps [rsp+0x40], xmm4
00007f8fe1fd541d  vmovaps [rsp+0x50], xmm5
00007f8fe1fd5423  vmovaps [rsp+0x60], xmm6
00007f8fe1fd5429  vmovaps [rsp+0x70], xmm7
00007f8fe1fd542f  vmovaps [rsp+0x80], xmm8
00007f8fe1fd5438  vmovaps [rsp+0x90], xmm9
00007f8fe1fd5441  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd544a  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd5453  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd545c  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd5465  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd546e  sub rsp, 0x30
00007f8fe1fd5472  movaps [rsp], xmm13
00007f8fe1fd5477  movaps [rsp+0x10], xmm8
00007f8fe1fd547d  movaps [rsp+0x20], xmm14
00007f8fe1fd5483  lea rdi, [rsp]
00007f8fe1fd5487  mov esi, 0x00
00007f8fe1fd548c  mov rax, 0x6020BB77F530
00007f8fe1fd5496  call rax
00007f8fe1fd5498  movaps xmm13, [rsp]
00007f8fe1fd549d  add rsp, 0x30
00007f8fe1fd54a1  vmovaps xmm0, [rsp]
00007f8fe1fd54a6  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd54ac  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd54b2  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd54b8  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd54be  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd54c4  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd54ca  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd54d0  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd54d9  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd54e2  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd54eb  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd54f4  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd54fd  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd5506  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd550f  add rsp, 0xF0
00007f8fe1fd5516  pop r11
00007f8fe1fd5518  pop r10
00007f8fe1fd551a  pop r9
00007f8fe1fd551c  pop r8
00007f8fe1fd551e  pop rsi
00007f8fe1fd551f  pop rdi
00007f8fe1fd5520  pop rdx
00007f8fe1fd5521  pop rcx
00007f8fe1fd5522  pop rax
00007f8fe1fd5523  add rsp, 0x08
00007f8fe1fd5527  jmp 0x00007F8FE1FD02F7
00007f8fe1fd552c  sub rsp, 0x08
00007f8fe1fd5530  push rax
00007f8fe1fd5531  push rcx
00007f8fe1fd5532  push rdx
00007f8fe1fd5533  push rdi
00007f8fe1fd5534  push rsi
00007f8fe1fd5535  push r8
00007f8fe1fd5537  push r9
00007f8fe1fd5539  push r10
00007f8fe1fd553b  push r11
00007f8fe1fd553d  sub rsp, 0xF0
00007f8fe1fd5544  vmovaps [rsp], xmm0
00007f8fe1fd5549  vmovaps [rsp+0x10], xmm1
00007f8fe1fd554f  vmovaps [rsp+0x20], xmm2
00007f8fe1fd5555  vmovaps [rsp+0x30], xmm3
00007f8fe1fd555b  vmovaps [rsp+0x40], xmm4
00007f8fe1fd5561  vmovaps [rsp+0x50], xmm5
00007f8fe1fd5567  vmovaps [rsp+0x60], xmm6
00007f8fe1fd556d  vmovaps [rsp+0x70], xmm7
00007f8fe1fd5573  vmovaps [rsp+0x80], xmm8
00007f8fe1fd557c  vmovaps [rsp+0x90], xmm9
00007f8fe1fd5585  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd558e  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd5597  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd55a0  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd55a9  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd55b2  sub rsp, 0x30
00007f8fe1fd55b6  movaps [rsp], xmm14
00007f8fe1fd55bb  movaps [rsp+0x10], xmm1
00007f8fe1fd55c0  movaps [rsp+0x20], xmm10
00007f8fe1fd55c6  lea rdi, [rsp]
00007f8fe1fd55ca  mov esi, 0x00
00007f8fe1fd55cf  mov rax, 0x6020BB77F530
00007f8fe1fd55d9  call rax
00007f8fe1fd55db  movaps xmm14, [rsp]
00007f8fe1fd55e0  add rsp, 0x30
00007f8fe1fd55e4  vmovaps xmm0, [rsp]
00007f8fe1fd55e9  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd55ef  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd55f5  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd55fb  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd5601  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd5607  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd560d  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd5613  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd561c  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd5625  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd562e  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd5637  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd5640  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd5649  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd5652  add rsp, 0xF0
00007f8fe1fd5659  pop r11
00007f8fe1fd565b  pop r10
00007f8fe1fd565d  pop r9
00007f8fe1fd565f  pop r8
00007f8fe1fd5661  pop rsi
00007f8fe1fd5662  pop rdi
00007f8fe1fd5663  pop rdx
00007f8fe1fd5664  pop rcx
00007f8fe1fd5665  pop rax
00007f8fe1fd5666  add rsp, 0x08
00007f8fe1fd566a  jmp 0x00007F8FE1FD031A
00007f8fe1fd566f  sub rsp, 0x08
00007f8fe1fd5673  push rax
00007f8fe1fd5674  push rcx
00007f8fe1fd5675  push rdx
00007f8fe1fd5676  push rdi
00007f8fe1fd5677  push rsi
00007f8fe1fd5678  push r8
00007f8fe1fd567a  push r9
00007f8fe1fd567c  push r10
00007f8fe1fd567e  push r11
00007f8fe1fd5680  sub rsp, 0xF0
00007f8fe1fd5687  vmovaps [rsp], xmm0
00007f8fe1fd568c  vmovaps [rsp+0x10], xmm2
00007f8fe1fd5692  vmovaps [rsp+0x20], xmm3
00007f8fe1fd5698  vmovaps [rsp+0x30], xmm4
00007f8fe1fd569e  vmovaps [rsp+0x40], xmm5
00007f8fe1fd56a4  vmovaps [rsp+0x50], xmm6
00007f8fe1fd56aa  vmovaps [rsp+0x60], xmm7
00007f8fe1fd56b0  vmovaps [rsp+0x70], xmm8
00007f8fe1fd56b6  vmovaps [rsp+0x80], xmm9
00007f8fe1fd56bf  vmovaps [rsp+0x90], xmm10
00007f8fe1fd56c8  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd56d1  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd56da  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd56e3  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd56ec  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd56f5  sub rsp, 0x30
00007f8fe1fd56f9  movaps [rsp], xmm1
00007f8fe1fd56fd  movaps [rsp+0x10], xmm7
00007f8fe1fd5702  movaps [rsp+0x20], xmm11
00007f8fe1fd5708  lea rdi, [rsp]
00007f8fe1fd570c  mov esi, 0x00
00007f8fe1fd5711  mov rax, 0x6020BB77F530
00007f8fe1fd571b  call rax
00007f8fe1fd571d  movaps xmm1, [rsp]
00007f8fe1fd5721  add rsp, 0x30
00007f8fe1fd5725  vmovaps xmm0, [rsp]
00007f8fe1fd572a  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd5730  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd5736  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd573c  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd5742  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd5748  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd574e  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd5754  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd575d  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd5766  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd576f  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd5778  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd5781  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd578a  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd5793  add rsp, 0xF0
00007f8fe1fd579a  pop r11
00007f8fe1fd579c  pop r10
00007f8fe1fd579e  pop r9
00007f8fe1fd57a0  pop r8
00007f8fe1fd57a2  pop rsi
00007f8fe1fd57a3  pop rdi
00007f8fe1fd57a4  pop rdx
00007f8fe1fd57a5  pop rcx
00007f8fe1fd57a6  pop rax
00007f8fe1fd57a7  add rsp, 0x08
00007f8fe1fd57ab  jmp 0x00007F8FE1FD033B
00007f8fe1fd57b0  call 0x00007F8FE1E0E880
00007f8fe1fd57b5  jmp 0x00007F8FE1FD034E
00007f8fe1fd57ba  call 0x00007F8FE1E0C380
00007f8fe1fd57bf  jmp 0x00007F8FE1FD0359
00007f8fe1fd57c4  call 0x00007F8FE1E0D600
00007f8fe1fd57c9  jmp 0x00007F8FE1FD0364
00007f8fe1fd57ce  call 0x00007F8FE1DFF540
00007f8fe1fd57d3  jmp 0x00007F8FE1FD036F
00007f8fe1fd57d8  int3
00007f8fe1fd57d9  nop [rax], eax
00007f8fe1fd57e0  mov rax, [r15+0x40]
00007f8fe1fd57e4  mov r14, [r15+0x58]
00007f8fe1fd57e8  lea r12, [rax+r14*1]
00007f8fe1fd57ec  movaps xmm1, [r15+0x1D0]
00007f8fe1fd57f4  vmovaps [rsp+0x10], xmm1
00007f8fe1fd57fa  vmovaps xmm15, [rsp+0x10]
00007f8fe1fd5800  por xmm1, xmm15
00007f8fe1fd5805  movaps xmm14, [r15+0x1A0]
00007f8fe1fd580d  vmovaps [rsp+0x10], xmm14
00007f8fe1fd5813  vmovaps xmm13, [rsp+0x10]
00007f8fe1fd5819  por xmm14, xmm13
00007f8fe1fd581e  lea rax, [r12+0x30]
00007f8fe1fd5823  mov r11, [r13+rax*1]
00007f8fe1fd5828  lea rax, [r12+0x38]
00007f8fe1fd582d  mov r10, [r13+rax*1]
00007f8fe1fd5832  movq xmm13, r11
00007f8fe1fd5837  movq xmm12, r10
00007f8fe1fd583c  movq xmm13, xmm13
00007f8fe1fd5841  vmovaps [rsp+0x10], xmm13
00007f8fe1fd5847  movq xmm13, xmm13
00007f8fe1fd584c  movaps [r15+0x130], xmm13
00007f8fe1fd5854  movq xmm12, xmm12
00007f8fe1fd5859  vmovaps [rsp+0x20], xmm12
00007f8fe1fd585f  movq xmm12, xmm12
00007f8fe1fd5864  movaps [r15+0x280], xmm12
00007f8fe1fd586c  movaps xmm13, [r15+0x270]
00007f8fe1fd5874  vmovaps [rsp+0x30], xmm13
00007f8fe1fd587a  vmovaps xmm12, [rsp+0x30]
00007f8fe1fd5880  por xmm13, xmm12
00007f8fe1fd5885  lea rax, [r12+0x20]
00007f8fe1fd588a  mov r11, [r13+rax*1]
00007f8fe1fd588f  lea rax, [r12+0x28]
00007f8fe1fd5894  mov r10, [r13+rax*1]
00007f8fe1fd5899  movq xmm12, r11
00007f8fe1fd589e  movq xmm11, r10
00007f8fe1fd58a3  movq xmm12, xmm12
00007f8fe1fd58a8  vmovaps [rsp+0x30], xmm12
00007f8fe1fd58ae  movq xmm12, xmm12
00007f8fe1fd58b3  movaps [r15+0x150], xmm12
00007f8fe1fd58bb  movq xmm11, xmm11
00007f8fe1fd58c0  vmovaps [rsp+0x40], xmm11
00007f8fe1fd58c6  movq xmm11, xmm11
00007f8fe1fd58cb  movaps [r15+0x140], xmm11
00007f8fe1fd58d3  lea rax, [r12+0x10]
00007f8fe1fd58d8  mov r11, [r13+rax*1]
00007f8fe1fd58dd  lea rax, [r12+0x18]
00007f8fe1fd58e2  mov r10, [r13+rax*1]
00007f8fe1fd58e7  movq xmm12, r11
00007f8fe1fd58ec  movq xmm11, r10
00007f8fe1fd58f1  movq xmm12, xmm12
00007f8fe1fd58f6  vmovaps [rsp+0x50], xmm12
00007f8fe1fd58fc  movq xmm12, xmm12
00007f8fe1fd5901  movaps [r15+0x170], xmm12
00007f8fe1fd5909  movq xmm11, xmm11
00007f8fe1fd590e  vmovaps [rsp+0x60], xmm11
00007f8fe1fd5914  movq xmm11, xmm11
00007f8fe1fd5919  movaps [r15+0x160], xmm11
00007f8fe1fd5921  mov rax, [r13+r12*1]
00007f8fe1fd5926  vmovq xmm12, rax
00007f8fe1fd592b  vpbroadcastq xmm12, xmm12
00007f8fe1fd5930  lea rax, [r12+0x08]
00007f8fe1fd5935  mov r12, [r13+rax*1]
00007f8fe1fd593a  movq xmm11, r12
00007f8fe1fd593f  movaps [r15+0x230], xmm11
00007f8fe1fd5947  mov rax, [r15+0xF8]
00007f8fe1fd594e  lea r12, [rax+0x50]
00007f8fe1fd5952  movups xmm11, [r13+r12*1]
00007f8fe1fd5958  lea r12, [rax+0x60]
00007f8fe1fd595c  movups xmm10, [r13+r12*1]
00007f8fe1fd5962  lea r12, [rax+0x30]
00007f8fe1fd5966  movups xmm9, [r13+r12*1]
00007f8fe1fd596c  mov r12, [r15+0x50]
00007f8fe1fd5970  lea r11, [r12+r14*1]
00007f8fe1fd5974  mov [r15+0x60], r11
00007f8fe1fd5978  lea r12, [r14+0x40]
00007f8fe1fd597c  mov [r15+0x58], r12
00007f8fe1fd5980  movaps xmm8, xmm12
00007f8fe1fd5984  mulpd xmm8, xmm15
00007f8fe1fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007f8fe1fd598f  ptest xmm7, xmm7
00007f8fe1fd5994  jnz 0x00007F8FE1FD67B7
00007f8fe1fd599a  movq xmm15, qword ptr [r15+0x230]
00007f8fe1fd59a3  vmovaps [rsp+0x70], xmm15
00007f8fe1fd59a9  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fd59af  movaps xmm7, xmm9
00007f8fe1fd59b3  mulpd xmm7, xmm15
00007f8fe1fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f8fe1fd59bd  ptest xmm6, xmm6
00007f8fe1fd59c2  jnz 0x00007F8FE1FD68FB
00007f8fe1fd59c8  vxorps xmm15, xmm15, xmm15
00007f8fe1fd59cd  vpbroadcastq xmm15, xmm15
00007f8fe1fd59d2  movaps xmm9, xmm12
00007f8fe1fd59d6  mulpd xmm9, xmm10
00007f8fe1fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007f8fe1fd59e1  ptest xmm6, xmm6
00007f8fe1fd59e6  jnz 0x00007F8FE1FD6A3D
00007f8fe1fd59ec  movaps xmm10, xmm12
00007f8fe1fd59f0  mulpd xmm10, xmm11
00007f8fe1fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f8fe1fd59fb  ptest xmm6, xmm6
00007f8fe1fd5a00  jnz 0x00007F8FE1FD6B81
00007f8fe1fd5a06  movaps xmm11, [r15+0x1F0]
00007f8fe1fd5a0e  movaps xmm6, xmm12
00007f8fe1fd5a12  mulpd xmm6, xmm11
00007f8fe1fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007f8fe1fd5a1c  ptest xmm5, xmm5
00007f8fe1fd5a21  jnz 0x00007F8FE1FD6CC5
00007f8fe1fd5a27  movaps xmm12, [r15+0x2A0]
00007f8fe1fd5a2f  vmovaps [rsp+0x80], xmm12
00007f8fe1fd5a38  vmovaps xmm11, [rsp+0x80]
00007f8fe1fd5a41  por xmm12, xmm11
00007f8fe1fd5a46  movaps xmm11, [r15+0x250]
00007f8fe1fd5a4e  vmovaps [rsp+0x80], xmm11
00007f8fe1fd5a57  vmovaps xmm5, [rsp+0x80]
00007f8fe1fd5a60  por xmm11, xmm5
00007f8fe1fd5a65  vmovaps xmm4, [rsp+0x70]
00007f8fe1fd5a6b  vpermilpd xmm4, xmm4, 0x00
00007f8fe1fd5a71  movaps xmm3, xmm5
00007f8fe1fd5a74  mulpd xmm3, xmm4
00007f8fe1fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007f8fe1fd5a7d  ptest xmm2, xmm2
00007f8fe1fd5a82  jnz 0x00007F8FE1FD6E07
00007f8fe1fd5a88  mov [rsp+0x80], rax
00007f8fe1fd5a90  xor eax, eax
00007f8fe1fd5a92  mov r14d, 0x200
00007f8fe1fd5a98  cmp r12, r14
00007f8fe1fd5a9b  cmc
00007f8fe1fd5a9c  lahf
00007f8fe1fd5a9d  seto al
00007f8fe1fd5aa0  mov [r15+0x108], eax
00007f8fe1fd5aa7  movaps xmm5, xmm8
00007f8fe1fd5aab  addpd xmm5, xmm15
00007f8fe1fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007f8fe1fd5ab5  ptest xmm4, xmm4
00007f8fe1fd5aba  jnz 0x00007F8FE1FD6F47
00007f8fe1fd5ac0  movaps xmm8, [r15+0x1B0]
00007f8fe1fd5ac8  movaps xmm4, xmm9
00007f8fe1fd5acc  addpd xmm4, xmm8
00007f8fe1fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f8fe1fd5ad6  ptest xmm2, xmm2
00007f8fe1fd5adb  jnz 0x00007F8FE1FD7089
00007f8fe1fd5ae1  movaps xmm9, xmm10
00007f8fe1fd5ae5  addpd xmm9, xmm8
00007f8fe1fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007f8fe1fd5af0  ptest xmm2, xmm2
00007f8fe1fd5af5  jnz 0x00007F8FE1FD71CB
00007f8fe1fd5afb  movaps xmm10, [r15+0x2F0]
00007f8fe1fd5b03  vmovaps [rsp+0x90], xmm10
00007f8fe1fd5b0c  vmovaps xmm8, [rsp+0x90]
00007f8fe1fd5b15  por xmm10, xmm8
00007f8fe1fd5b1a  movaps xmm8, [r15+0x2E0]
00007f8fe1fd5b22  vmovaps [rsp+0x90], xmm8
00007f8fe1fd5b2b  vmovaps xmm2, [rsp+0x90]
00007f8fe1fd5b34  por xmm8, xmm2
00007f8fe1fd5b39  movaps xmm2, [r15+0x2D0]
00007f8fe1fd5b41  vmovaps [rsp+0x90], xmm2
00007f8fe1fd5b4a  vmovaps [rsp+0xA0], xmm1
00007f8fe1fd5b53  vmovaps xmm1, [rsp+0x90]
00007f8fe1fd5b5c  por xmm2, xmm1
00007f8fe1fd5b60  movaps xmm1, [r15+0x200]
00007f8fe1fd5b68  vmovaps [rsp+0x90], xmm1
00007f8fe1fd5b71  vmovaps [rsp+0xB0], xmm15
00007f8fe1fd5b7a  vmovaps xmm15, [rsp+0x90]
00007f8fe1fd5b83  por xmm1, xmm15
00007f8fe1fd5b88  movaps xmm15, [r15+0x1C0]
00007f8fe1fd5b90  vmovaps [rsp+0x90], xmm15
00007f8fe1fd5b99  vmovaps [rsp+0xC0], xmm1
00007f8fe1fd5ba2  vmovaps xmm1, [rsp+0x90]
00007f8fe1fd5bab  por xmm15, xmm1
00007f8fe1fd5bb0  movaps xmm1, [r15+0x190]
00007f8fe1fd5bb8  vmovaps [rsp+0x90], xmm1
00007f8fe1fd5bc1  vmovaps [rsp+0xD0], xmm15
00007f8fe1fd5bca  vmovaps xmm15, [rsp+0x90]
00007f8fe1fd5bd3  por xmm1, xmm15
00007f8fe1fd5bd8  movaps xmm15, [r15+0x300]
00007f8fe1fd5be0  vmovaps [rsp+0x90], xmm15
00007f8fe1fd5be9  vmovaps [rsp+0xE0], xmm1
00007f8fe1fd5bf2  vmovaps xmm1, [rsp+0x90]
00007f8fe1fd5bfb  por xmm15, xmm1
00007f8fe1fd5c00  mov rax, [rsp+0x80]
00007f8fe1fd5c08  lea r14, [rax+0xA0]
00007f8fe1fd5c0f  movups xmm1, [r13+r14*1]
00007f8fe1fd5c15  lea r14, [rax+0xB0]
00007f8fe1fd5c1c  vmovaps [rsp+0x80], xmm1
00007f8fe1fd5c25  movups xmm1, [r13+r14*1]
00007f8fe1fd5c2b  vmovaps [rsp+0x90], xmm1
00007f8fe1fd5c34  vmovaps [rsp+0xF0], xmm15
00007f8fe1fd5c3d  vmovaps xmm15, [rsp+0xB0]
00007f8fe1fd5c46  vmovaps [rsp+0xB0], xmm14
00007f8fe1fd5c4f  movaps xmm1, xmm6
00007f8fe1fd5c52  addpd xmm1, xmm15
00007f8fe1fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007f8fe1fd5c5c  ptest xmm14, xmm14
00007f8fe1fd5c62  jnz 0x00007F8FE1FD7323
00007f8fe1fd5c68  lea r14, [rax+0xF0]
00007f8fe1fd5c6f  movups xmm15, [r13+r14*1]
00007f8fe1fd5c75  movaps xmm14, xmm4
00007f8fe1fd5c79  addpd xmm14, xmm3
00007f8fe1fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f8fe1fd5c84  ptest xmm6, xmm6
00007f8fe1fd5c89  jnz 0x00007F8FE1FD746E
00007f8fe1fd5c8f  movaps xmm6, xmm9
00007f8fe1fd5c93  addpd xmm6, xmm7
00007f8fe1fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007f8fe1fd5c9c  ptest xmm4, xmm4
00007f8fe1fd5ca1  jnz 0x00007F8FE1FD75B0
00007f8fe1fd5ca7  vmovaps xmm9, [rsp+0x70]
00007f8fe1fd5cad  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fd5cb3  vmovaps xmm4, [rsp+0x90]
00007f8fe1fd5cbc  movaps xmm7, xmm4
00007f8fe1fd5cbf  mulpd xmm7, xmm9
00007f8fe1fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f8fe1fd5cc9  ptest xmm3, xmm3
00007f8fe1fd5cce  jnz 0x00007F8FE1FD76F1
00007f8fe1fd5cd4  vmovaps xmm9, [rsp+0x50]
00007f8fe1fd5cda  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fd5ce0  movaps xmm4, xmm15
00007f8fe1fd5ce4  mulpd xmm4, xmm9
00007f8fe1fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f8fe1fd5cee  ptest xmm3, xmm3
00007f8fe1fd5cf3  jnz 0x00007F8FE1FD7832
00007f8fe1fd5cf9  lea r14, [rax+0xE0]
00007f8fe1fd5d00  movups xmm15, [r13+r14*1]
00007f8fe1fd5d06  vmovaps xmm9, [rsp+0x70]
00007f8fe1fd5d0c  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fd5d12  vmovaps [rsp+0x70], xmm1
00007f8fe1fd5d18  vmovaps xmm1, [rsp+0x80]
00007f8fe1fd5d21  vmovaps [rsp+0x80], xmm15
00007f8fe1fd5d2a  movaps xmm3, xmm1
00007f8fe1fd5d2d  mulpd xmm3, xmm9
00007f8fe1fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007f8fe1fd5d37  ptest xmm15, xmm15
00007f8fe1fd5d3d  jnz 0x00007F8FE1FD797E
00007f8fe1fd5d43  vmovaps xmm1, [rsp+0xF0]
00007f8fe1fd5d4c  vmovaps xmm15, [rsp+0xF0]
00007f8fe1fd5d55  por xmm1, xmm15
00007f8fe1fd5d5a  movaps [r15+0x300], xmm1
00007f8fe1fd5d62  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd5d6b  vmovaps xmm9, [rsp+0xE0]
00007f8fe1fd5d74  por xmm15, xmm9
00007f8fe1fd5d79  movaps [r15+0x190], xmm15
00007f8fe1fd5d81  vmovaps xmm9, [rsp+0x50]
00007f8fe1fd5d87  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fd5d8d  vmovaps [rsp+0x90], xmm1
00007f8fe1fd5d96  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd5d9f  vmovaps xmm15, [rsp+0x80]
00007f8fe1fd5da8  vmovaps [rsp+0x80], xmm14
00007f8fe1fd5db1  movaps xmm1, xmm15
00007f8fe1fd5db5  mulpd xmm1, xmm9
00007f8fe1fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007f8fe1fd5dbf  ptest xmm14, xmm14
00007f8fe1fd5dc5  jnz 0x00007F8FE1FD7ABF
00007f8fe1fd5dcb  lea r14, [rax+0x90]
00007f8fe1fd5dd2  movups xmm15, [r13+r14*1]
00007f8fe1fd5dd8  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd5de1  vmovaps xmm9, [rsp+0xD0]
00007f8fe1fd5dea  por xmm14, xmm9
00007f8fe1fd5def  movaps [r15+0x1C0], xmm14
00007f8fe1fd5df7  vmovaps xmm9, [rsp+0xC0]
00007f8fe1fd5e00  vmovaps [rsp+0xD0], xmm1
00007f8fe1fd5e09  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fd5e12  por xmm9, xmm1
00007f8fe1fd5e17  movaps [r15+0x200], xmm9
00007f8fe1fd5e1f  vmovaps [rsp+0xC0], xmm2
00007f8fe1fd5e28  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fd5e31  por xmm2, xmm1
00007f8fe1fd5e35  movaps [r15+0x2D0], xmm2
00007f8fe1fd5e3d  vmovaps [rsp+0xC0], xmm8
00007f8fe1fd5e46  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fd5e4f  por xmm8, xmm1
00007f8fe1fd5e54  movaps [r15+0x2E0], xmm8
00007f8fe1fd5e5c  vmovaps [rsp+0xC0], xmm15
00007f8fe1fd5e65  movaps xmm1, xmm5
00007f8fe1fd5e68  addpd xmm1, xmm7
00007f8fe1fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f8fe1fd5e71  ptest xmm15, xmm15
00007f8fe1fd5e77  jnz 0x00007F8FE1FD7C0B
00007f8fe1fd5e7d  vmovaps xmm15, [rsp+0x50]
00007f8fe1fd5e83  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fd5e89  vmovaps xmm5, [rsp+0xC0]
00007f8fe1fd5e92  vmovaps [rsp+0xC0], xmm1
00007f8fe1fd5e9b  movaps xmm7, xmm5
00007f8fe1fd5e9e  mulpd xmm7, xmm15
00007f8fe1fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007f8fe1fd5ea8  ptest xmm1, xmm1
00007f8fe1fd5ead  jnz 0x00007F8FE1FD7D4B
00007f8fe1fd5eb3  lea r14, [rax+0x80]
00007f8fe1fd5eba  movups xmm1, [r13+r14*1]
00007f8fe1fd5ec0  vmovaps xmm5, [rsp+0x70]
00007f8fe1fd5ec6  vmovaps [rsp+0x70], xmm1
00007f8fe1fd5ecc  movaps xmm15, xmm5
00007f8fe1fd5ed0  addpd xmm15, xmm3
00007f8fe1fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f8fe1fd5edb  ptest xmm1, xmm1
00007f8fe1fd5ee0  jnz 0x00007F8FE1FD7E96
00007f8fe1fd5ee6  vmovaps xmm5, [rsp+0x80]
00007f8fe1fd5eef  movaps xmm1, xmm5
00007f8fe1fd5ef2  addpd xmm1, xmm4
00007f8fe1fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f8fe1fd5efb  ptest xmm3, xmm3
00007f8fe1fd5f00  jnz 0x00007F8FE1FD7FD8
00007f8fe1fd5f06  vmovaps [rsp+0x80], xmm10
00007f8fe1fd5f0f  vmovaps xmm5, [rsp+0x80]
00007f8fe1fd5f18  por xmm10, xmm5
00007f8fe1fd5f1d  movaps [r15+0x2F0], xmm10
00007f8fe1fd5f25  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd5f2b  vpermilpd xmm5, xmm5, 0x00
00007f8fe1fd5f31  vmovaps xmm3, [rsp+0x70]
00007f8fe1fd5f37  vmovaps [rsp+0x50], xmm1
00007f8fe1fd5f3d  movaps xmm4, xmm3
00007f8fe1fd5f40  mulpd xmm4, xmm5
00007f8fe1fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007f8fe1fd5f49  ptest xmm1, xmm1
00007f8fe1fd5f4e  jnz 0x00007F8FE1FD8118
00007f8fe1fd5f54  lea r14, [rax+0xD0]
00007f8fe1fd5f5b  movups xmm1, [r13+r14*1]
00007f8fe1fd5f61  vmovaps xmm3, [rsp+0xD0]
00007f8fe1fd5f6a  vmovaps [rsp+0x70], xmm1
00007f8fe1fd5f70  movaps xmm5, xmm6
00007f8fe1fd5f73  addpd xmm5, xmm3
00007f8fe1fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007f8fe1fd5f7c  ptest xmm1, xmm1
00007f8fe1fd5f81  jnz 0x00007F8FE1FD8262
00007f8fe1fd5f87  vmovaps xmm1, [rsp+0x60]
00007f8fe1fd5f8d  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd5f93  movaps xmm6, xmm9
00007f8fe1fd5f97  mulpd xmm6, xmm1
00007f8fe1fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f8fe1fd5fa0  ptest xmm3, xmm3
00007f8fe1fd5fa5  jnz 0x00007F8FE1FD83A2
00007f8fe1fd5fab  movaps [r15+0x260], xmm6
00007f8fe1fd5fb3  vxorps xmm1, xmm1, xmm1
00007f8fe1fd5fb7  vpbroadcastq xmm1, xmm1
00007f8fe1fd5fbc  movaps [r15+0x1B0], xmm1
00007f8fe1fd5fc4  vmovaps xmm1, [rsp+0x60]
00007f8fe1fd5fca  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd5fd0  vmovaps xmm3, [rsp+0x70]
00007f8fe1fd5fd6  vmovaps [rsp+0x70], xmm15
00007f8fe1fd5fdc  movaps xmm9, xmm3
00007f8fe1fd5fe0  mulpd xmm9, xmm1
00007f8fe1fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f8fe1fd5feb  ptest xmm15, xmm15
00007f8fe1fd5ff1  jnz 0x00007F8FE1FD84E3
00007f8fe1fd5ff7  lea r14, [rax+0xC0]
00007f8fe1fd5ffe  movups xmm1, [r13+r14*1]
00007f8fe1fd6004  vmovaps xmm3, [rsp+0xC0]
00007f8fe1fd600d  vmovaps [rsp+0x80], xmm1
00007f8fe1fd6016  movaps xmm15, xmm3
00007f8fe1fd601a  addpd xmm15, xmm7
00007f8fe1fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007f8fe1fd6025  ptest xmm1, xmm1
00007f8fe1fd602a  jnz 0x00007F8FE1FD862F
00007f8fe1fd6030  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd6039  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fd6042  por xmm13, xmm1
00007f8fe1fd6047  movaps [r15+0x270], xmm13
00007f8fe1fd604f  vmovaps xmm1, [rsp+0xB0]
00007f8fe1fd6058  vmovaps xmm7, [rsp+0xB0]
00007f8fe1fd6061  por xmm1, xmm7
00007f8fe1fd6065  movaps [r15+0x1A0], xmm1
00007f8fe1fd606d  vmovaps xmm1, [rsp+0x60]
00007f8fe1fd6073  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd6079  vmovaps [rsp+0xB0], xmm1
00007f8fe1fd6082  vmovaps xmm1, [rsp+0x80]
00007f8fe1fd608b  vmovaps [rsp+0x80], xmm15
00007f8fe1fd6094  vmovaps xmm15, [rsp+0xB0]
00007f8fe1fd609d  vmovaps [rsp+0xB0], xmm14
00007f8fe1fd60a6  movaps xmm3, xmm1
00007f8fe1fd60a9  mulpd xmm3, xmm15
00007f8fe1fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007f8fe1fd60b3  ptest xmm14, xmm14
00007f8fe1fd60b9  jnz 0x00007F8FE1FD8771
00007f8fe1fd60bf  lea r14, [rax+0x20]
00007f8fe1fd60c3  movups xmm1, [r13+r14*1]
00007f8fe1fd60c9  movaps [r15+0x110], xmm1
00007f8fe1fd60d1  vmovaps xmm14, [rsp+0x70]
00007f8fe1fd60d7  vmovaps [rsp+0x70], xmm1
00007f8fe1fd60dd  movaps xmm15, xmm14
00007f8fe1fd60e1  addpd xmm15, xmm4
00007f8fe1fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f8fe1fd60ec  ptest xmm1, xmm1
00007f8fe1fd60f1  jnz 0x00007F8FE1FD88BC
00007f8fe1fd60f7  vmovaps xmm1, [rsp+0x60]
00007f8fe1fd60fd  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd6103  movaps xmm14, xmm2
00007f8fe1fd6107  mulpd xmm14, xmm1
00007f8fe1fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007f8fe1fd6112  ptest xmm4, xmm4
00007f8fe1fd6117  jnz 0x00007F8FE1FD89FF
00007f8fe1fd611d  vmovaps xmm4, [rsp+0x50]
00007f8fe1fd6123  movaps xmm1, xmm4
00007f8fe1fd6126  addpd xmm1, xmm9
00007f8fe1fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f8fe1fd6130  ptest xmm2, xmm2
00007f8fe1fd6135  jnz 0x00007F8FE1FD8B41
00007f8fe1fd613b  vmovaps xmm9, [rsp+0x30]
00007f8fe1fd6141  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fd6147  vmovaps xmm2, [rsp+0x70]
00007f8fe1fd614d  vmovaps [rsp+0x50], xmm1
00007f8fe1fd6153  movaps xmm4, xmm2
00007f8fe1fd6156  mulpd xmm4, xmm9
00007f8fe1fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f8fe1fd6160  ptest xmm1, xmm1
00007f8fe1fd6165  jnz 0x00007F8FE1FD8C82
00007f8fe1fd616b  vmovaps xmm1, [rsp+0x30]
00007f8fe1fd6171  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd6177  vmovaps xmm2, [rsp+0x90]
00007f8fe1fd6180  vmovaps [rsp+0x60], xmm15
00007f8fe1fd6186  movaps xmm9, xmm2
00007f8fe1fd618a  mulpd xmm9, xmm1
00007f8fe1fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f8fe1fd6195  ptest xmm15, xmm15
00007f8fe1fd619b  jnz 0x00007F8FE1FD8DC3
00007f8fe1fd61a1  vmovaps xmm15, [rsp+0x80]
00007f8fe1fd61aa  movaps xmm1, xmm15
00007f8fe1fd61ae  addpd xmm1, xmm6
00007f8fe1fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007f8fe1fd61b7  ptest xmm2, xmm2
00007f8fe1fd61bc  jnz 0x00007F8FE1FD8F05
00007f8fe1fd61c2  movaps xmm15, xmm5
00007f8fe1fd61c6  addpd xmm15, xmm3
00007f8fe1fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007f8fe1fd61d1  ptest xmm6, xmm6
00007f8fe1fd61d6  jnz 0x00007F8FE1FD9046
00007f8fe1fd61dc  vmovaps xmm6, [rsp+0x30]
00007f8fe1fd61e2  vpermilpd xmm6, xmm6, 0x00
00007f8fe1fd61e8  movaps xmm5, xmm8
00007f8fe1fd61ec  mulpd xmm5, xmm6
00007f8fe1fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f8fe1fd61f5  ptest xmm3, xmm3
00007f8fe1fd61fa  jnz 0x00007F8FE1FD9188
00007f8fe1fd6200  vmovaps xmm8, [rsp+0x30]
00007f8fe1fd6206  vpermilpd xmm8, xmm8, 0x00
00007f8fe1fd620c  movaps xmm6, xmm10
00007f8fe1fd6210  mulpd xmm6, xmm8
00007f8fe1fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007f8fe1fd621a  ptest xmm3, xmm3
00007f8fe1fd621f  jnz 0x00007F8FE1FD92C9
00007f8fe1fd6225  vmovaps xmm8, [rsp+0x60]
00007f8fe1fd622b  movaps xmm10, xmm8
00007f8fe1fd622f  addpd xmm10, xmm14
00007f8fe1fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007f8fe1fd623a  ptest xmm3, xmm3
00007f8fe1fd623f  jnz 0x00007F8FE1FD940B
00007f8fe1fd6245  vmovaps xmm8, [rsp+0x50]
00007f8fe1fd624b  movaps xmm14, xmm8
00007f8fe1fd624f  addpd xmm14, xmm4
00007f8fe1fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007f8fe1fd625a  ptest xmm3, xmm3
00007f8fe1fd625f  jnz 0x00007F8FE1FD954F
00007f8fe1fd6265  vmovaps xmm8, [rsp+0x40]
00007f8fe1fd626b  vpermilpd xmm8, xmm8, 0x00
00007f8fe1fd6271  movaps xmm4, xmm13
00007f8fe1fd6275  mulpd xmm4, xmm8
00007f8fe1fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f8fe1fd627f  ptest xmm3, xmm3
00007f8fe1fd6284  jnz 0x00007F8FE1FD9692
00007f8fe1fd628a  movaps xmm13, xmm15
00007f8fe1fd628e  addpd xmm13, xmm9
00007f8fe1fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007f8fe1fd6299  ptest xmm8, xmm8
00007f8fe1fd629f  jnz 0x00007F8FE1FD97D4
00007f8fe1fd62a5  movaps xmm15, xmm1
00007f8fe1fd62a9  addpd xmm15, xmm5
00007f8fe1fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007f8fe1fd62b4  ptest xmm9, xmm9
00007f8fe1fd62ba  jnz 0x00007F8FE1FD9918
00007f8fe1fd62c0  vmovaps [rsp+0x30], xmm11
00007f8fe1fd62c6  vmovaps xmm1, [rsp+0x30]
00007f8fe1fd62cc  por xmm11, xmm1
00007f8fe1fd62d1  movaps [r15+0x250], xmm11
00007f8fe1fd62d9  vmovaps [rsp+0x30], xmm12
00007f8fe1fd62df  vmovaps xmm1, [rsp+0x30]
00007f8fe1fd62e5  por xmm12, xmm1
00007f8fe1fd62ea  movaps [r15+0x2A0], xmm12
00007f8fe1fd62f2  vmovaps xmm1, [rsp+0xA0]
00007f8fe1fd62fb  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd6304  por xmm1, xmm11
00007f8fe1fd6309  movaps [r15+0x1D0], xmm1
00007f8fe1fd6311  lea r14, [rax+0x40]
00007f8fe1fd6315  movups xmm1, [r13+r14*1]
00007f8fe1fd631b  movaps [r15+0x2C0], xmm1
00007f8fe1fd6323  vmovaps xmm11, [rsp+0x40]
00007f8fe1fd6329  vpermilpd xmm11, xmm11, 0x00
00007f8fe1fd632f  vmovaps xmm8, [rsp+0xE0]
00007f8fe1fd6338  movaps xmm9, xmm8
00007f8fe1fd633c  mulpd xmm9, xmm11
00007f8fe1fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007f8fe1fd6347  ptest xmm5, xmm5
00007f8fe1fd634c  jnz 0x00007F8FE1FD9A64
00007f8fe1fd6352  movaps xmm11, xmm10
00007f8fe1fd6356  addpd xmm11, xmm6
00007f8fe1fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f8fe1fd6361  ptest xmm8, xmm8
00007f8fe1fd6367  jnz 0x00007F8FE1FD9BA8
00007f8fe1fd636d  movaps xmm10, xmm14
00007f8fe1fd6371  addpd xmm10, xmm4
00007f8fe1fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007f8fe1fd637c  ptest xmm8, xmm8
00007f8fe1fd6382  jnz 0x00007F8FE1FD9CEB
00007f8fe1fd6388  vmovaps xmm14, [rsp+0x40]
00007f8fe1fd638e  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fd6394  movaps xmm8, xmm1
00007f8fe1fd6398  mulpd xmm8, xmm14
00007f8fe1fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f8fe1fd63a3  ptest xmm6, xmm6
00007f8fe1fd63a8  jnz 0x00007F8FE1FD9E2E
00007f8fe1fd63ae  movaps xmm1, [r15+0x2B0]
00007f8fe1fd63b6  vmovaps xmm14, [rsp+0x40]
00007f8fe1fd63bc  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fd63c2  movaps xmm6, xmm1
00007f8fe1fd63c5  mulpd xmm6, xmm14
00007f8fe1fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007f8fe1fd63cf  ptest xmm5, xmm5
00007f8fe1fd63d4  jnz 0x00007F8FE1FD9F71
00007f8fe1fd63da  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd63e0  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd63e6  movaps xmm14, xmm12
00007f8fe1fd63ea  mulpd xmm14, xmm1
00007f8fe1fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007f8fe1fd63f5  ptest xmm5, xmm5
00007f8fe1fd63fa  jnz 0x00007F8FE1FDA0B2
00007f8fe1fd6400  movaps xmm1, xmm13
00007f8fe1fd6404  addpd xmm1, xmm9
00007f8fe1fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007f8fe1fd640e  ptest xmm12, xmm12
00007f8fe1fd6414  jnz 0x00007F8FE1FDA1F5
00007f8fe1fd641a  vmovaps xmm13, [rsp+0x10]
00007f8fe1fd6420  vpermilpd xmm13, xmm13, 0x00
00007f8fe1fd6426  movaps xmm12, xmm7
00007f8fe1fd642a  mulpd xmm12, xmm13
00007f8fe1fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f8fe1fd6435  ptest xmm9, xmm9
00007f8fe1fd643b  jnz 0x00007F8FE1FDA337
00007f8fe1fd6441  movaps xmm13, xmm15
00007f8fe1fd6445  addpd xmm13, xmm8
00007f8fe1fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f8fe1fd6450  ptest xmm9, xmm9
00007f8fe1fd6456  jnz 0x00007F8FE1FDA47A
00007f8fe1fd645c  movaps xmm15, [r15+0x290]
00007f8fe1fd6464  vmovaps xmm9, [rsp+0x10]
00007f8fe1fd646a  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fd6470  movaps xmm8, xmm15
00007f8fe1fd6474  mulpd xmm8, xmm9
00007f8fe1fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007f8fe1fd647f  ptest xmm7, xmm7
00007f8fe1fd6484  jnz 0x00007F8FE1FDA5BE
00007f8fe1fd648a  movaps xmm15, xmm11
00007f8fe1fd648e  addpd xmm15, xmm6
00007f8fe1fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007f8fe1fd6499  ptest xmm9, xmm9
00007f8fe1fd649f  jnz 0x00007F8FE1FDA702
00007f8fe1fd64a5  movaps xmm11, [r15+0x1E0]
00007f8fe1fd64ad  vmovaps xmm9, [rsp+0x10]
00007f8fe1fd64b3  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fd64b9  movaps xmm7, xmm11
00007f8fe1fd64bd  mulpd xmm7, xmm9
00007f8fe1fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f8fe1fd64c7  ptest xmm6, xmm6
00007f8fe1fd64cc  jnz 0x00007F8FE1FDA845
00007f8fe1fd64d2  movaps xmm11, xmm10
00007f8fe1fd64d6  addpd xmm11, xmm14
00007f8fe1fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007f8fe1fd64e1  ptest xmm9, xmm9
00007f8fe1fd64e7  jnz 0x00007F8FE1FDA987
00007f8fe1fd64ed  lea r14, [rax+0x70]
00007f8fe1fd64f1  movups xmm14, [r13+r14*1]
00007f8fe1fd64f7  movaps [r15+0x240], xmm14
00007f8fe1fd64ff  movaps xmm10, xmm1
00007f8fe1fd6503  addpd xmm10, xmm12
00007f8fe1fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007f8fe1fd650e  ptest xmm9, xmm9
00007f8fe1fd6514  jnz 0x00007F8FE1FDAAD5
00007f8fe1fd651a  movaps [r15+0x170], xmm10
00007f8fe1fd6522  vmovaps xmm1, [rsp+0x20]
00007f8fe1fd6528  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd652e  movaps xmm12, xmm14
00007f8fe1fd6532  mulpd xmm12, xmm1
00007f8fe1fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007f8fe1fd653d  ptest xmm9, xmm9
00007f8fe1fd6543  jnz 0x00007F8FE1FDAC18
00007f8fe1fd6549  vmovaps xmm1, [rsp+0x20]
00007f8fe1fd654f  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fd6555  vmovaps xmm9, [rsp+0xB0]
00007f8fe1fd655e  movaps xmm14, xmm9
00007f8fe1fd6562  mulpd xmm14, xmm1
00007f8fe1fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007f8fe1fd656d  ptest xmm6, xmm6
00007f8fe1fd6572  jnz 0x00007F8FE1FDAD5B
00007f8fe1fd6578  movaps [r15+0x180], xmm14
00007f8fe1fd6580  movaps xmm1, xmm13
00007f8fe1fd6584  addpd xmm1, xmm8
00007f8fe1fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007f8fe1fd658e  ptest xmm9, xmm9
00007f8fe1fd6594  jnz 0x00007F8FE1FDAE9E
00007f8fe1fd659a  movaps [r15+0x210], xmm1
00007f8fe1fd65a2  movups xmm13, [r13+rax*1]
00007f8fe1fd65a8  lea r14, [rax+0x10]
00007f8fe1fd65ac  movups xmm9, [r13+r14*1]
00007f8fe1fd65b2  movaps [r15+0x230], xmm9
00007f8fe1fd65ba  movaps xmm8, xmm15
00007f8fe1fd65be  addpd xmm8, xmm7
00007f8fe1fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f8fe1fd65c9  ptest xmm6, xmm6
00007f8fe1fd65ce  jnz 0x00007F8FE1FDAFF4
00007f8fe1fd65d4  movaps [r15+0x130], xmm8
00007f8fe1fd65dc  vmovaps xmm15, [rsp+0x20]
00007f8fe1fd65e2  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fd65e8  movaps xmm7, xmm9
00007f8fe1fd65ec  mulpd xmm7, xmm15
00007f8fe1fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f8fe1fd65f6  ptest xmm6, xmm6
00007f8fe1fd65fb  jnz 0x00007F8FE1FDB137
00007f8fe1fd6601  movaps [r15+0x220], xmm7
00007f8fe1fd6609  vmovaps xmm15, [rsp+0x20]
00007f8fe1fd660f  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fd6615  movaps xmm9, xmm13
00007f8fe1fd6619  mulpd xmm9, xmm15
00007f8fe1fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007f8fe1fd6624  ptest xmm6, xmm6
00007f8fe1fd6629  jnz 0x00007F8FE1FDB279
00007f8fe1fd662f  movaps xmm15, xmm11
00007f8fe1fd6633  addpd xmm15, xmm12
00007f8fe1fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007f8fe1fd663e  ptest xmm13, xmm13
00007f8fe1fd6644  jnz 0x00007F8FE1FDB3BD
00007f8fe1fd664a  movaps [r15+0x140], xmm15
00007f8fe1fd6652  movaps xmm13, xmm10
00007f8fe1fd6656  addpd xmm13, xmm14
00007f8fe1fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f8fe1fd6661  ptest xmm12, xmm12
00007f8fe1fd6667  jnz 0x00007F8FE1FDB501
00007f8fe1fd666d  movaps [r15+0x150], xmm13
00007f8fe1fd6675  movaps xmm14, xmm1
00007f8fe1fd6679  addpd xmm14, xmm7
00007f8fe1fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f8fe1fd6684  ptest xmm12, xmm12
00007f8fe1fd668a  jnz 0x00007F8FE1FDB645
00007f8fe1fd6690  movaps [r15+0x160], xmm14
00007f8fe1fd6698  movaps xmm1, xmm8
00007f8fe1fd669c  addpd xmm1, xmm9
00007f8fe1fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007f8fe1fd66a6  ptest xmm12, xmm12
00007f8fe1fd66ac  jnz 0x00007F8FE1FDB787
00007f8fe1fd66b2  movaps [r15+0x120], xmm1
00007f8fe1fd66ba  movups [r13+r11*1], xmm15
00007f8fe1fd66c0  lea rax, [r11+0x10]
00007f8fe1fd66c4  movups [r13+rax*1], xmm13
00007f8fe1fd66ca  lea rax, [r11+0x20]
00007f8fe1fd66ce  movups [r13+rax*1], xmm14
00007f8fe1fd66d4  lea rax, [r11+0x30]
00007f8fe1fd66d8  movups [r13+rax*1], xmm1
00007f8fe1fd66de  mov eax, [r15+0x108]
00007f8fe1fd66e5  sahf
00007f8fe1fd66e6  jnz 0x00007F8FE1FD6718
00007f8fe1fd66e8  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fd66f0  jz 0x00007F8FE1FDB900
00007f8fe1fd66f6  nop [rax+rax*1], ax
00007f8fe1fd66ff  nop [rax+rax*1], eax
00007f8fe1fd6707  mov eax, 0x410444
00007f8fe1fd670c  mov [r15+0x100], rax
00007f8fe1fd6713  jmp 0x00007F8FE1DFE110
00007f8fe1fd6718  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fd6720  jz 0x00007F8FE1FD57E0
00007f8fe1fd6726  nop [rax+rax*1], ax
00007f8fe1fd672f  nop [rax+rax*1], eax
00007f8fe1fd6737  mov eax, 0x410278
00007f8fe1fd673c  mov [r15+0x100], rax
00007f8fe1fd6743  jmp 0x00007F8FE1DFE110
00007f8fe1fd6748  int3
00007f8fe1fd6749  call 0x00007F8FE1E0A4B0
00007f8fe1fd674e  jmp 0x00007F8FE1FD5828
00007f8fe1fd6753  call 0x00007F8FE1E09240
00007f8fe1fd6758  jmp 0x00007F8FE1FD5832
00007f8fe1fd675d  call 0x00007F8FE1E0A4B0
00007f8fe1fd6762  jmp 0x00007F8FE1FD588F
00007f8fe1fd6767  call 0x00007F8FE1E09240
00007f8fe1fd676c  jmp 0x00007F8FE1FD5899
00007f8fe1fd6771  call 0x00007F8FE1E0A4B0
00007f8fe1fd6776  jmp 0x00007F8FE1FD58DD
00007f8fe1fd677b  call 0x00007F8FE1E09240
00007f8fe1fd6780  jmp 0x00007F8FE1FD58E7
00007f8fe1fd6785  call 0x00007F8FE1EB47C0
00007f8fe1fd678a  jmp 0x00007F8FE1FD5926
00007f8fe1fd678f  call 0x00007F8FE1E0B720
00007f8fe1fd6794  jmp 0x00007F8FE1FD593A
00007f8fe1fd6799  call 0x00007F8FE1EBFC30
00007f8fe1fd679e  jmp 0x00007F8FE1FD5958
00007f8fe1fd67a3  call 0x00007F8FE1EBE9C0
00007f8fe1fd67a8  jmp 0x00007F8FE1FD5962
00007f8fe1fd67ad  call 0x00007F8FE1EBD750
00007f8fe1fd67b2  jmp 0x00007F8FE1FD596C
00007f8fe1fd67b7  sub rsp, 0x08
00007f8fe1fd67bb  push rax
00007f8fe1fd67bc  push rcx
00007f8fe1fd67bd  push rdx
00007f8fe1fd67be  push rdi
00007f8fe1fd67bf  push rsi
00007f8fe1fd67c0  push r8
00007f8fe1fd67c2  push r9
00007f8fe1fd67c4  push r10
00007f8fe1fd67c6  push r11
00007f8fe1fd67c8  sub rsp, 0xF0
00007f8fe1fd67cf  vmovaps [rsp], xmm0
00007f8fe1fd67d4  vmovaps [rsp+0x10], xmm1
00007f8fe1fd67da  vmovaps [rsp+0x20], xmm2
00007f8fe1fd67e0  vmovaps [rsp+0x30], xmm3
00007f8fe1fd67e6  vmovaps [rsp+0x40], xmm4
00007f8fe1fd67ec  vmovaps [rsp+0x50], xmm5
00007f8fe1fd67f2  vmovaps [rsp+0x60], xmm6
00007f8fe1fd67f8  vmovaps [rsp+0x70], xmm7
00007f8fe1fd67fe  vmovaps [rsp+0x80], xmm9
00007f8fe1fd6807  vmovaps [rsp+0x90], xmm10
00007f8fe1fd6810  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd6819  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd6822  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd682b  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd6834  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd683d  sub rsp, 0x30
00007f8fe1fd6841  movaps [rsp], xmm8
00007f8fe1fd6846  movaps [rsp+0x10], xmm12
00007f8fe1fd684c  movaps [rsp+0x20], xmm15
00007f8fe1fd6852  lea rdi, [rsp]
00007f8fe1fd6856  mov esi, 0x00
00007f8fe1fd685b  mov rax, 0x6020BB77F530
00007f8fe1fd6865  call rax
00007f8fe1fd6867  movaps xmm8, [rsp]
00007f8fe1fd686c  add rsp, 0x30
00007f8fe1fd6870  vmovaps xmm0, [rsp]
00007f8fe1fd6875  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd687b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd6881  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd6887  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd688d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd6893  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd6899  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd689f  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd68a8  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd68b1  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd68ba  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd68c3  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd68cc  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd68d5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd68de  add rsp, 0xF0
00007f8fe1fd68e5  pop r11
00007f8fe1fd68e7  pop r10
00007f8fe1fd68e9  pop r9
00007f8fe1fd68eb  pop r8
00007f8fe1fd68ed  pop rsi
00007f8fe1fd68ee  pop rdi
00007f8fe1fd68ef  pop rdx
00007f8fe1fd68f0  pop rcx
00007f8fe1fd68f1  pop rax
00007f8fe1fd68f2  add rsp, 0x08
00007f8fe1fd68f6  jmp 0x00007F8FE1FD599A
00007f8fe1fd68fb  sub rsp, 0x08
00007f8fe1fd68ff  push rax
00007f8fe1fd6900  push rcx
00007f8fe1fd6901  push rdx
00007f8fe1fd6902  push rdi
00007f8fe1fd6903  push rsi
00007f8fe1fd6904  push r8
00007f8fe1fd6906  push r9
00007f8fe1fd6908  push r10
00007f8fe1fd690a  push r11
00007f8fe1fd690c  sub rsp, 0xF0
00007f8fe1fd6913  vmovaps [rsp], xmm0
00007f8fe1fd6918  vmovaps [rsp+0x10], xmm1
00007f8fe1fd691e  vmovaps [rsp+0x20], xmm2
00007f8fe1fd6924  vmovaps [rsp+0x30], xmm3
00007f8fe1fd692a  vmovaps [rsp+0x40], xmm4
00007f8fe1fd6930  vmovaps [rsp+0x50], xmm5
00007f8fe1fd6936  vmovaps [rsp+0x60], xmm6
00007f8fe1fd693c  vmovaps [rsp+0x70], xmm8
00007f8fe1fd6942  vmovaps [rsp+0x80], xmm9
00007f8fe1fd694b  vmovaps [rsp+0x90], xmm10
00007f8fe1fd6954  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd695d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd6966  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd696f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd6978  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd6981  sub rsp, 0x30
00007f8fe1fd6985  movaps [rsp], xmm7
00007f8fe1fd6989  movaps [rsp+0x10], xmm9
00007f8fe1fd698f  movaps [rsp+0x20], xmm15
00007f8fe1fd6995  lea rdi, [rsp]
00007f8fe1fd6999  mov esi, 0x00
00007f8fe1fd699e  mov rax, 0x6020BB77F530
00007f8fe1fd69a8  call rax
00007f8fe1fd69aa  movaps xmm7, [rsp]
00007f8fe1fd69ae  add rsp, 0x30
00007f8fe1fd69b2  vmovaps xmm0, [rsp]
00007f8fe1fd69b7  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd69bd  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd69c3  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd69c9  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd69cf  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd69d5  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd69db  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd69e1  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd69ea  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd69f3  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd69fc  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd6a05  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd6a0e  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd6a17  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd6a20  add rsp, 0xF0
00007f8fe1fd6a27  pop r11
00007f8fe1fd6a29  pop r10
00007f8fe1fd6a2b  pop r9
00007f8fe1fd6a2d  pop r8
00007f8fe1fd6a2f  pop rsi
00007f8fe1fd6a30  pop rdi
00007f8fe1fd6a31  pop rdx
00007f8fe1fd6a32  pop rcx
00007f8fe1fd6a33  pop rax
00007f8fe1fd6a34  add rsp, 0x08
00007f8fe1fd6a38  jmp 0x00007F8FE1FD59C8
00007f8fe1fd6a3d  sub rsp, 0x08
00007f8fe1fd6a41  push rax
00007f8fe1fd6a42  push rcx
00007f8fe1fd6a43  push rdx
00007f8fe1fd6a44  push rdi
00007f8fe1fd6a45  push rsi
00007f8fe1fd6a46  push r8
00007f8fe1fd6a48  push r9
00007f8fe1fd6a4a  push r10
00007f8fe1fd6a4c  push r11
00007f8fe1fd6a4e  sub rsp, 0xF0
00007f8fe1fd6a55  vmovaps [rsp], xmm0
00007f8fe1fd6a5a  vmovaps [rsp+0x10], xmm1
00007f8fe1fd6a60  vmovaps [rsp+0x20], xmm2
00007f8fe1fd6a66  vmovaps [rsp+0x30], xmm3
00007f8fe1fd6a6c  vmovaps [rsp+0x40], xmm4
00007f8fe1fd6a72  vmovaps [rsp+0x50], xmm5
00007f8fe1fd6a78  vmovaps [rsp+0x60], xmm6
00007f8fe1fd6a7e  vmovaps [rsp+0x70], xmm7
00007f8fe1fd6a84  vmovaps [rsp+0x80], xmm8
00007f8fe1fd6a8d  vmovaps [rsp+0x90], xmm10
00007f8fe1fd6a96  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd6a9f  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd6aa8  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd6ab1  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd6aba  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd6ac3  sub rsp, 0x30
00007f8fe1fd6ac7  movaps [rsp], xmm9
00007f8fe1fd6acc  movaps [rsp+0x10], xmm12
00007f8fe1fd6ad2  movaps [rsp+0x20], xmm10
00007f8fe1fd6ad8  lea rdi, [rsp]
00007f8fe1fd6adc  mov esi, 0x00
00007f8fe1fd6ae1  mov rax, 0x6020BB77F530
00007f8fe1fd6aeb  call rax
00007f8fe1fd6aed  movaps xmm9, [rsp]
00007f8fe1fd6af2  add rsp, 0x30
00007f8fe1fd6af6  vmovaps xmm0, [rsp]
00007f8fe1fd6afb  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd6b01  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd6b07  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd6b0d  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd6b13  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd6b19  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd6b1f  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd6b25  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd6b2e  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd6b37  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd6b40  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd6b49  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd6b52  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd6b5b  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd6b64  add rsp, 0xF0
00007f8fe1fd6b6b  pop r11
00007f8fe1fd6b6d  pop r10
00007f8fe1fd6b6f  pop r9
00007f8fe1fd6b71  pop r8
00007f8fe1fd6b73  pop rsi
00007f8fe1fd6b74  pop rdi
00007f8fe1fd6b75  pop rdx
00007f8fe1fd6b76  pop rcx
00007f8fe1fd6b77  pop rax
00007f8fe1fd6b78  add rsp, 0x08
00007f8fe1fd6b7c  jmp 0x00007F8FE1FD59EC
00007f8fe1fd6b81  sub rsp, 0x08
00007f8fe1fd6b85  push rax
00007f8fe1fd6b86  push rcx
00007f8fe1fd6b87  push rdx
00007f8fe1fd6b88  push rdi
00007f8fe1fd6b89  push rsi
00007f8fe1fd6b8a  push r8
00007f8fe1fd6b8c  push r9
00007f8fe1fd6b8e  push r10
00007f8fe1fd6b90  push r11
00007f8fe1fd6b92  sub rsp, 0xF0
00007f8fe1fd6b99  vmovaps [rsp], xmm0
00007f8fe1fd6b9e  vmovaps [rsp+0x10], xmm1
00007f8fe1fd6ba4  vmovaps [rsp+0x20], xmm2
00007f8fe1fd6baa  vmovaps [rsp+0x30], xmm3
00007f8fe1fd6bb0  vmovaps [rsp+0x40], xmm4
00007f8fe1fd6bb6  vmovaps [rsp+0x50], xmm5
00007f8fe1fd6bbc  vmovaps [rsp+0x60], xmm6
00007f8fe1fd6bc2  vmovaps [rsp+0x70], xmm7
00007f8fe1fd6bc8  vmovaps [rsp+0x80], xmm8
00007f8fe1fd6bd1  vmovaps [rsp+0x90], xmm9
00007f8fe1fd6bda  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd6be3  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd6bec  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd6bf5  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd6bfe  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd6c07  sub rsp, 0x30
00007f8fe1fd6c0b  movaps [rsp], xmm10
00007f8fe1fd6c10  movaps [rsp+0x10], xmm12
00007f8fe1fd6c16  movaps [rsp+0x20], xmm11
00007f8fe1fd6c1c  lea rdi, [rsp]
00007f8fe1fd6c20  mov esi, 0x00
00007f8fe1fd6c25  mov rax, 0x6020BB77F530
00007f8fe1fd6c2f  call rax
00007f8fe1fd6c31  movaps xmm10, [rsp]
00007f8fe1fd6c36  add rsp, 0x30
00007f8fe1fd6c3a  vmovaps xmm0, [rsp]
00007f8fe1fd6c3f  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd6c45  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd6c4b  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd6c51  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd6c57  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd6c5d  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd6c63  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd6c69  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd6c72  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd6c7b  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd6c84  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd6c8d  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd6c96  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd6c9f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd6ca8  add rsp, 0xF0
00007f8fe1fd6caf  pop r11
00007f8fe1fd6cb1  pop r10
00007f8fe1fd6cb3  pop r9
00007f8fe1fd6cb5  pop r8
00007f8fe1fd6cb7  pop rsi
00007f8fe1fd6cb8  pop rdi
00007f8fe1fd6cb9  pop rdx
00007f8fe1fd6cba  pop rcx
00007f8fe1fd6cbb  pop rax
00007f8fe1fd6cbc  add rsp, 0x08
00007f8fe1fd6cc0  jmp 0x00007F8FE1FD5A06
00007f8fe1fd6cc5  sub rsp, 0x08
00007f8fe1fd6cc9  push rax
00007f8fe1fd6cca  push rcx
00007f8fe1fd6ccb  push rdx
00007f8fe1fd6ccc  push rdi
00007f8fe1fd6ccd  push rsi
00007f8fe1fd6cce  push r8
00007f8fe1fd6cd0  push r9
00007f8fe1fd6cd2  push r10
00007f8fe1fd6cd4  push r11
00007f8fe1fd6cd6  sub rsp, 0xF0
00007f8fe1fd6cdd  vmovaps [rsp], xmm0
00007f8fe1fd6ce2  vmovaps [rsp+0x10], xmm1
00007f8fe1fd6ce8  vmovaps [rsp+0x20], xmm2
00007f8fe1fd6cee  vmovaps [rsp+0x30], xmm3
00007f8fe1fd6cf4  vmovaps [rsp+0x40], xmm4
00007f8fe1fd6cfa  vmovaps [rsp+0x50], xmm5
00007f8fe1fd6d00  vmovaps [rsp+0x60], xmm7
00007f8fe1fd6d06  vmovaps [rsp+0x70], xmm8
00007f8fe1fd6d0c  vmovaps [rsp+0x80], xmm9
00007f8fe1fd6d15  vmovaps [rsp+0x90], xmm10
00007f8fe1fd6d1e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd6d27  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd6d30  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd6d39  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd6d42  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd6d4b  sub rsp, 0x30
00007f8fe1fd6d4f  movaps [rsp], xmm6
00007f8fe1fd6d53  movaps [rsp+0x10], xmm12
00007f8fe1fd6d59  movaps [rsp+0x20], xmm11
00007f8fe1fd6d5f  lea rdi, [rsp]
00007f8fe1fd6d63  mov esi, 0x00
00007f8fe1fd6d68  mov rax, 0x6020BB77F530
00007f8fe1fd6d72  call rax
00007f8fe1fd6d74  movaps xmm6, [rsp]
00007f8fe1fd6d78  add rsp, 0x30
00007f8fe1fd6d7c  vmovaps xmm0, [rsp]
00007f8fe1fd6d81  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd6d87  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd6d8d  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd6d93  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd6d99  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd6d9f  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd6da5  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd6dab  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd6db4  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd6dbd  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd6dc6  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd6dcf  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd6dd8  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd6de1  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd6dea  add rsp, 0xF0
00007f8fe1fd6df1  pop r11
00007f8fe1fd6df3  pop r10
00007f8fe1fd6df5  pop r9
00007f8fe1fd6df7  pop r8
00007f8fe1fd6df9  pop rsi
00007f8fe1fd6dfa  pop rdi
00007f8fe1fd6dfb  pop rdx
00007f8fe1fd6dfc  pop rcx
00007f8fe1fd6dfd  pop rax
00007f8fe1fd6dfe  add rsp, 0x08
00007f8fe1fd6e02  jmp 0x00007F8FE1FD5A27
00007f8fe1fd6e07  sub rsp, 0x08
00007f8fe1fd6e0b  push rax
00007f8fe1fd6e0c  push rcx
00007f8fe1fd6e0d  push rdx
00007f8fe1fd6e0e  push rdi
00007f8fe1fd6e0f  push rsi
00007f8fe1fd6e10  push r8
00007f8fe1fd6e12  push r9
00007f8fe1fd6e14  push r10
00007f8fe1fd6e16  push r11
00007f8fe1fd6e18  sub rsp, 0xF0
00007f8fe1fd6e1f  vmovaps [rsp], xmm0
00007f8fe1fd6e24  vmovaps [rsp+0x10], xmm1
00007f8fe1fd6e2a  vmovaps [rsp+0x20], xmm2
00007f8fe1fd6e30  vmovaps [rsp+0x30], xmm4
00007f8fe1fd6e36  vmovaps [rsp+0x40], xmm5
00007f8fe1fd6e3c  vmovaps [rsp+0x50], xmm6
00007f8fe1fd6e42  vmovaps [rsp+0x60], xmm7
00007f8fe1fd6e48  vmovaps [rsp+0x70], xmm8
00007f8fe1fd6e4e  vmovaps [rsp+0x80], xmm9
00007f8fe1fd6e57  vmovaps [rsp+0x90], xmm10
00007f8fe1fd6e60  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd6e69  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd6e72  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd6e7b  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd6e84  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd6e8d  sub rsp, 0x30
00007f8fe1fd6e91  movaps [rsp], xmm3
00007f8fe1fd6e95  movaps [rsp+0x10], xmm5
00007f8fe1fd6e9a  movaps [rsp+0x20], xmm4
00007f8fe1fd6e9f  lea rdi, [rsp]
00007f8fe1fd6ea3  mov esi, 0x00
00007f8fe1fd6ea8  mov rax, 0x6020BB77F530
00007f8fe1fd6eb2  call rax
00007f8fe1fd6eb4  movaps xmm3, [rsp]
00007f8fe1fd6eb8  add rsp, 0x30
00007f8fe1fd6ebc  vmovaps xmm0, [rsp]
00007f8fe1fd6ec1  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd6ec7  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd6ecd  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd6ed3  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd6ed9  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd6edf  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd6ee5  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd6eeb  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd6ef4  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd6efd  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd6f06  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd6f0f  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd6f18  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd6f21  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd6f2a  add rsp, 0xF0
00007f8fe1fd6f31  pop r11
00007f8fe1fd6f33  pop r10
00007f8fe1fd6f35  pop r9
00007f8fe1fd6f37  pop r8
00007f8fe1fd6f39  pop rsi
00007f8fe1fd6f3a  pop rdi
00007f8fe1fd6f3b  pop rdx
00007f8fe1fd6f3c  pop rcx
00007f8fe1fd6f3d  pop rax
00007f8fe1fd6f3e  add rsp, 0x08
00007f8fe1fd6f42  jmp 0x00007F8FE1FD5A88
00007f8fe1fd6f47  sub rsp, 0x08
00007f8fe1fd6f4b  push rax
00007f8fe1fd6f4c  push rcx
00007f8fe1fd6f4d  push rdx
00007f8fe1fd6f4e  push rdi
00007f8fe1fd6f4f  push rsi
00007f8fe1fd6f50  push r8
00007f8fe1fd6f52  push r9
00007f8fe1fd6f54  push r10
00007f8fe1fd6f56  push r11
00007f8fe1fd6f58  sub rsp, 0xF0
00007f8fe1fd6f5f  vmovaps [rsp], xmm0
00007f8fe1fd6f64  vmovaps [rsp+0x10], xmm1
00007f8fe1fd6f6a  vmovaps [rsp+0x20], xmm2
00007f8fe1fd6f70  vmovaps [rsp+0x30], xmm3
00007f8fe1fd6f76  vmovaps [rsp+0x40], xmm4
00007f8fe1fd6f7c  vmovaps [rsp+0x50], xmm6
00007f8fe1fd6f82  vmovaps [rsp+0x60], xmm7
00007f8fe1fd6f88  vmovaps [rsp+0x70], xmm8
00007f8fe1fd6f8e  vmovaps [rsp+0x80], xmm9
00007f8fe1fd6f97  vmovaps [rsp+0x90], xmm10
00007f8fe1fd6fa0  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd6fa9  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd6fb2  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd6fbb  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd6fc4  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd6fcd  sub rsp, 0x30
00007f8fe1fd6fd1  movaps [rsp], xmm5
00007f8fe1fd6fd5  movaps [rsp+0x10], xmm8
00007f8fe1fd6fdb  movaps [rsp+0x20], xmm15
00007f8fe1fd6fe1  lea rdi, [rsp]
00007f8fe1fd6fe5  mov esi, 0x00
00007f8fe1fd6fea  mov rax, 0x6020BB77F530
00007f8fe1fd6ff4  call rax
00007f8fe1fd6ff6  movaps xmm5, [rsp]
00007f8fe1fd6ffa  add rsp, 0x30
00007f8fe1fd6ffe  vmovaps xmm0, [rsp]
00007f8fe1fd7003  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd7009  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd700f  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd7015  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd701b  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd7021  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd7027  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd702d  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd7036  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd703f  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd7048  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd7051  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd705a  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd7063  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd706c  add rsp, 0xF0
00007f8fe1fd7073  pop r11
00007f8fe1fd7075  pop r10
00007f8fe1fd7077  pop r9
00007f8fe1fd7079  pop r8
00007f8fe1fd707b  pop rsi
00007f8fe1fd707c  pop rdi
00007f8fe1fd707d  pop rdx
00007f8fe1fd707e  pop rcx
00007f8fe1fd707f  pop rax
00007f8fe1fd7080  add rsp, 0x08
00007f8fe1fd7084  jmp 0x00007F8FE1FD5AC0
00007f8fe1fd7089  sub rsp, 0x08
00007f8fe1fd708d  push rax
00007f8fe1fd708e  push rcx
00007f8fe1fd708f  push rdx
00007f8fe1fd7090  push rdi
00007f8fe1fd7091  push rsi
00007f8fe1fd7092  push r8
00007f8fe1fd7094  push r9
00007f8fe1fd7096  push r10
00007f8fe1fd7098  push r11
00007f8fe1fd709a  sub rsp, 0xF0
00007f8fe1fd70a1  vmovaps [rsp], xmm0
00007f8fe1fd70a6  vmovaps [rsp+0x10], xmm1
00007f8fe1fd70ac  vmovaps [rsp+0x20], xmm2
00007f8fe1fd70b2  vmovaps [rsp+0x30], xmm3
00007f8fe1fd70b8  vmovaps [rsp+0x40], xmm5
00007f8fe1fd70be  vmovaps [rsp+0x50], xmm6
00007f8fe1fd70c4  vmovaps [rsp+0x60], xmm7
00007f8fe1fd70ca  vmovaps [rsp+0x70], xmm8
00007f8fe1fd70d0  vmovaps [rsp+0x80], xmm9
00007f8fe1fd70d9  vmovaps [rsp+0x90], xmm10
00007f8fe1fd70e2  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd70eb  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd70f4  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd70fd  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd7106  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd710f  sub rsp, 0x30
00007f8fe1fd7113  movaps [rsp], xmm4
00007f8fe1fd7117  movaps [rsp+0x10], xmm9
00007f8fe1fd711d  movaps [rsp+0x20], xmm8
00007f8fe1fd7123  lea rdi, [rsp]
00007f8fe1fd7127  mov esi, 0x00
00007f8fe1fd712c  mov rax, 0x6020BB77F530
00007f8fe1fd7136  call rax
00007f8fe1fd7138  movaps xmm4, [rsp]
00007f8fe1fd713c  add rsp, 0x30
00007f8fe1fd7140  vmovaps xmm0, [rsp]
00007f8fe1fd7145  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd714b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd7151  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd7157  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd715d  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd7163  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd7169  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd716f  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd7178  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd7181  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd718a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd7193  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd719c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd71a5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd71ae  add rsp, 0xF0
00007f8fe1fd71b5  pop r11
00007f8fe1fd71b7  pop r10
00007f8fe1fd71b9  pop r9
00007f8fe1fd71bb  pop r8
00007f8fe1fd71bd  pop rsi
00007f8fe1fd71be  pop rdi
00007f8fe1fd71bf  pop rdx
00007f8fe1fd71c0  pop rcx
00007f8fe1fd71c1  pop rax
00007f8fe1fd71c2  add rsp, 0x08
00007f8fe1fd71c6  jmp 0x00007F8FE1FD5AE1
00007f8fe1fd71cb  sub rsp, 0x08
00007f8fe1fd71cf  push rax
00007f8fe1fd71d0  push rcx
00007f8fe1fd71d1  push rdx
00007f8fe1fd71d2  push rdi
00007f8fe1fd71d3  push rsi
00007f8fe1fd71d4  push r8
00007f8fe1fd71d6  push r9
00007f8fe1fd71d8  push r10
00007f8fe1fd71da  push r11
00007f8fe1fd71dc  sub rsp, 0xF0
00007f8fe1fd71e3  vmovaps [rsp], xmm0
00007f8fe1fd71e8  vmovaps [rsp+0x10], xmm1
00007f8fe1fd71ee  vmovaps [rsp+0x20], xmm2
00007f8fe1fd71f4  vmovaps [rsp+0x30], xmm3
00007f8fe1fd71fa  vmovaps [rsp+0x40], xmm4
00007f8fe1fd7200  vmovaps [rsp+0x50], xmm5
00007f8fe1fd7206  vmovaps [rsp+0x60], xmm6
00007f8fe1fd720c  vmovaps [rsp+0x70], xmm7
00007f8fe1fd7212  vmovaps [rsp+0x80], xmm8
00007f8fe1fd721b  vmovaps [rsp+0x90], xmm10
00007f8fe1fd7224  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd722d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd7236  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd723f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd7248  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd7251  sub rsp, 0x30
00007f8fe1fd7255  movaps [rsp], xmm9
00007f8fe1fd725a  movaps [rsp+0x10], xmm10
00007f8fe1fd7260  movaps [rsp+0x20], xmm8
00007f8fe1fd7266  lea rdi, [rsp]
00007f8fe1fd726a  mov esi, 0x00
00007f8fe1fd726f  mov rax, 0x6020BB77F530
00007f8fe1fd7279  call rax
00007f8fe1fd727b  movaps xmm9, [rsp]
00007f8fe1fd7280  add rsp, 0x30
00007f8fe1fd7284  vmovaps xmm0, [rsp]
00007f8fe1fd7289  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd728f  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd7295  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd729b  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd72a1  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd72a7  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd72ad  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd72b3  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd72bc  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd72c5  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd72ce  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd72d7  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd72e0  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd72e9  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd72f2  add rsp, 0xF0
00007f8fe1fd72f9  pop r11
00007f8fe1fd72fb  pop r10
00007f8fe1fd72fd  pop r9
00007f8fe1fd72ff  pop r8
00007f8fe1fd7301  pop rsi
00007f8fe1fd7302  pop rdi
00007f8fe1fd7303  pop rdx
00007f8fe1fd7304  pop rcx
00007f8fe1fd7305  pop rax
00007f8fe1fd7306  add rsp, 0x08
00007f8fe1fd730a  jmp 0x00007F8FE1FD5AFB
00007f8fe1fd730f  call 0x00007F8FE1ED64F0
00007f8fe1fd7314  jmp 0x00007F8FE1FD5C15
00007f8fe1fd7319  call 0x00007F8FE1ED64F0
00007f8fe1fd731e  jmp 0x00007F8FE1FD5C2B
00007f8fe1fd7323  sub rsp, 0x08
00007f8fe1fd7327  push rax
00007f8fe1fd7328  push rcx
00007f8fe1fd7329  push rdx
00007f8fe1fd732a  push rdi
00007f8fe1fd732b  push rsi
00007f8fe1fd732c  push r8
00007f8fe1fd732e  push r9
00007f8fe1fd7330  push r10
00007f8fe1fd7332  push r11
00007f8fe1fd7334  sub rsp, 0xF0
00007f8fe1fd733b  vmovaps [rsp], xmm0
00007f8fe1fd7340  vmovaps [rsp+0x10], xmm2
00007f8fe1fd7346  vmovaps [rsp+0x20], xmm3
00007f8fe1fd734c  vmovaps [rsp+0x30], xmm4
00007f8fe1fd7352  vmovaps [rsp+0x40], xmm5
00007f8fe1fd7358  vmovaps [rsp+0x50], xmm6
00007f8fe1fd735e  vmovaps [rsp+0x60], xmm7
00007f8fe1fd7364  vmovaps [rsp+0x70], xmm8
00007f8fe1fd736a  vmovaps [rsp+0x80], xmm9
00007f8fe1fd7373  vmovaps [rsp+0x90], xmm10
00007f8fe1fd737c  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd7385  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd738e  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd7397  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd73a0  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd73a9  sub rsp, 0x30
00007f8fe1fd73ad  movaps [rsp], xmm1
00007f8fe1fd73b1  movaps [rsp+0x10], xmm6
00007f8fe1fd73b6  movaps [rsp+0x20], xmm15
00007f8fe1fd73bc  lea rdi, [rsp]
00007f8fe1fd73c0  mov esi, 0x00
00007f8fe1fd73c5  mov rax, 0x6020BB77F530
00007f8fe1fd73cf  call rax
00007f8fe1fd73d1  movaps xmm1, [rsp]
00007f8fe1fd73d5  add rsp, 0x30
00007f8fe1fd73d9  vmovaps xmm0, [rsp]
00007f8fe1fd73de  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd73e4  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd73ea  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd73f0  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd73f6  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd73fc  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd7402  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd7408  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd7411  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd741a  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd7423  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd742c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd7435  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd743e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd7447  add rsp, 0xF0
00007f8fe1fd744e  pop r11
00007f8fe1fd7450  pop r10
00007f8fe1fd7452  pop r9
00007f8fe1fd7454  pop r8
00007f8fe1fd7456  pop rsi
00007f8fe1fd7457  pop rdi
00007f8fe1fd7458  pop rdx
00007f8fe1fd7459  pop rcx
00007f8fe1fd745a  pop rax
00007f8fe1fd745b  add rsp, 0x08
00007f8fe1fd745f  jmp 0x00007F8FE1FD5C68
00007f8fe1fd7464  call 0x00007F8FE1EE5820
00007f8fe1fd7469  jmp 0x00007F8FE1FD5C75
00007f8fe1fd746e  sub rsp, 0x08
00007f8fe1fd7472  push rax
00007f8fe1fd7473  push rcx
00007f8fe1fd7474  push rdx
00007f8fe1fd7475  push rdi
00007f8fe1fd7476  push rsi
00007f8fe1fd7477  push r8
00007f8fe1fd7479  push r9
00007f8fe1fd747b  push r10
00007f8fe1fd747d  push r11
00007f8fe1fd747f  sub rsp, 0xF0
00007f8fe1fd7486  vmovaps [rsp], xmm0
00007f8fe1fd748b  vmovaps [rsp+0x10], xmm1
00007f8fe1fd7491  vmovaps [rsp+0x20], xmm2
00007f8fe1fd7497  vmovaps [rsp+0x30], xmm3
00007f8fe1fd749d  vmovaps [rsp+0x40], xmm4
00007f8fe1fd74a3  vmovaps [rsp+0x50], xmm5
00007f8fe1fd74a9  vmovaps [rsp+0x60], xmm6
00007f8fe1fd74af  vmovaps [rsp+0x70], xmm7
00007f8fe1fd74b5  vmovaps [rsp+0x80], xmm8
00007f8fe1fd74be  vmovaps [rsp+0x90], xmm9
00007f8fe1fd74c7  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd74d0  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd74d9  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd74e2  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd74eb  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd74f4  sub rsp, 0x30
00007f8fe1fd74f8  movaps [rsp], xmm14
00007f8fe1fd74fd  movaps [rsp+0x10], xmm4
00007f8fe1fd7502  movaps [rsp+0x20], xmm3
00007f8fe1fd7507  lea rdi, [rsp]
00007f8fe1fd750b  mov esi, 0x00
00007f8fe1fd7510  mov rax, 0x6020BB77F530
00007f8fe1fd751a  call rax
00007f8fe1fd751c  movaps xmm14, [rsp]
00007f8fe1fd7521  add rsp, 0x30
00007f8fe1fd7525  vmovaps xmm0, [rsp]
00007f8fe1fd752a  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd7530  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd7536  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd753c  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd7542  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd7548  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd754e  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd7554  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd755d  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd7566  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd756f  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd7578  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd7581  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd758a  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd7593  add rsp, 0xF0
00007f8fe1fd759a  pop r11
00007f8fe1fd759c  pop r10
00007f8fe1fd759e  pop r9
00007f8fe1fd75a0  pop r8
00007f8fe1fd75a2  pop rsi
00007f8fe1fd75a3  pop rdi
00007f8fe1fd75a4  pop rdx
00007f8fe1fd75a5  pop rcx
00007f8fe1fd75a6  pop rax
00007f8fe1fd75a7  add rsp, 0x08
00007f8fe1fd75ab  jmp 0x00007F8FE1FD5C8F
00007f8fe1fd75b0  sub rsp, 0x08
00007f8fe1fd75b4  push rax
00007f8fe1fd75b5  push rcx
00007f8fe1fd75b6  push rdx
00007f8fe1fd75b7  push rdi
00007f8fe1fd75b8  push rsi
00007f8fe1fd75b9  push r8
00007f8fe1fd75bb  push r9
00007f8fe1fd75bd  push r10
00007f8fe1fd75bf  push r11
00007f8fe1fd75c1  sub rsp, 0xF0
00007f8fe1fd75c8  vmovaps [rsp], xmm0
00007f8fe1fd75cd  vmovaps [rsp+0x10], xmm1
00007f8fe1fd75d3  vmovaps [rsp+0x20], xmm2
00007f8fe1fd75d9  vmovaps [rsp+0x30], xmm3
00007f8fe1fd75df  vmovaps [rsp+0x40], xmm4
00007f8fe1fd75e5  vmovaps [rsp+0x50], xmm5
00007f8fe1fd75eb  vmovaps [rsp+0x60], xmm7
00007f8fe1fd75f1  vmovaps [rsp+0x70], xmm8
00007f8fe1fd75f7  vmovaps [rsp+0x80], xmm9
00007f8fe1fd7600  vmovaps [rsp+0x90], xmm10
00007f8fe1fd7609  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd7612  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd761b  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd7624  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd762d  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd7636  sub rsp, 0x30
00007f8fe1fd763a  movaps [rsp], xmm6
00007f8fe1fd763e  movaps [rsp+0x10], xmm9
00007f8fe1fd7644  movaps [rsp+0x20], xmm7
00007f8fe1fd7649  lea rdi, [rsp]
00007f8fe1fd764d  mov esi, 0x00
00007f8fe1fd7652  mov rax, 0x6020BB77F530
00007f8fe1fd765c  call rax
00007f8fe1fd765e  movaps xmm6, [rsp]
00007f8fe1fd7662  add rsp, 0x30
00007f8fe1fd7666  vmovaps xmm0, [rsp]
00007f8fe1fd766b  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd7671  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd7677  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd767d  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd7683  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd7689  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd768f  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd7695  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd769e  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd76a7  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd76b0  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd76b9  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd76c2  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd76cb  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd76d4  add rsp, 0xF0
00007f8fe1fd76db  pop r11
00007f8fe1fd76dd  pop r10
00007f8fe1fd76df  pop r9
00007f8fe1fd76e1  pop r8
00007f8fe1fd76e3  pop rsi
00007f8fe1fd76e4  pop rdi
00007f8fe1fd76e5  pop rdx
00007f8fe1fd76e6  pop rcx
00007f8fe1fd76e7  pop rax
00007f8fe1fd76e8  add rsp, 0x08
00007f8fe1fd76ec  jmp 0x00007F8FE1FD5CA7
00007f8fe1fd76f1  sub rsp, 0x08
00007f8fe1fd76f5  push rax
00007f8fe1fd76f6  push rcx
00007f8fe1fd76f7  push rdx
00007f8fe1fd76f8  push rdi
00007f8fe1fd76f9  push rsi
00007f8fe1fd76fa  push r8
00007f8fe1fd76fc  push r9
00007f8fe1fd76fe  push r10
00007f8fe1fd7700  push r11
00007f8fe1fd7702  sub rsp, 0xF0
00007f8fe1fd7709  vmovaps [rsp], xmm0
00007f8fe1fd770e  vmovaps [rsp+0x10], xmm1
00007f8fe1fd7714  vmovaps [rsp+0x20], xmm2
00007f8fe1fd771a  vmovaps [rsp+0x30], xmm3
00007f8fe1fd7720  vmovaps [rsp+0x40], xmm4
00007f8fe1fd7726  vmovaps [rsp+0x50], xmm5
00007f8fe1fd772c  vmovaps [rsp+0x60], xmm6
00007f8fe1fd7732  vmovaps [rsp+0x70], xmm8
00007f8fe1fd7738  vmovaps [rsp+0x80], xmm9
00007f8fe1fd7741  vmovaps [rsp+0x90], xmm10
00007f8fe1fd774a  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd7753  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd775c  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd7765  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd776e  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd7777  sub rsp, 0x30
00007f8fe1fd777b  movaps [rsp], xmm7
00007f8fe1fd777f  movaps [rsp+0x10], xmm4
00007f8fe1fd7784  movaps [rsp+0x20], xmm9
00007f8fe1fd778a  lea rdi, [rsp]
00007f8fe1fd778e  mov esi, 0x00
00007f8fe1fd7793  mov rax, 0x6020BB77F530
00007f8fe1fd779d  call rax
00007f8fe1fd779f  movaps xmm7, [rsp]
00007f8fe1fd77a3  add rsp, 0x30
00007f8fe1fd77a7  vmovaps xmm0, [rsp]
00007f8fe1fd77ac  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd77b2  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd77b8  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd77be  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd77c4  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd77ca  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd77d0  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd77d6  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd77df  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd77e8  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd77f1  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd77fa  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd7803  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd780c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd7815  add rsp, 0xF0
00007f8fe1fd781c  pop r11
00007f8fe1fd781e  pop r10
00007f8fe1fd7820  pop r9
00007f8fe1fd7822  pop r8
00007f8fe1fd7824  pop rsi
00007f8fe1fd7825  pop rdi
00007f8fe1fd7826  pop rdx
00007f8fe1fd7827  pop rcx
00007f8fe1fd7828  pop rax
00007f8fe1fd7829  add rsp, 0x08
00007f8fe1fd782d  jmp 0x00007F8FE1FD5CD4
00007f8fe1fd7832  sub rsp, 0x08
00007f8fe1fd7836  push rax
00007f8fe1fd7837  push rcx
00007f8fe1fd7838  push rdx
00007f8fe1fd7839  push rdi
00007f8fe1fd783a  push rsi
00007f8fe1fd783b  push r8
00007f8fe1fd783d  push r9
00007f8fe1fd783f  push r10
00007f8fe1fd7841  push r11
00007f8fe1fd7843  sub rsp, 0xF0
00007f8fe1fd784a  vmovaps [rsp], xmm0
00007f8fe1fd784f  vmovaps [rsp+0x10], xmm1
00007f8fe1fd7855  vmovaps [rsp+0x20], xmm2
00007f8fe1fd785b  vmovaps [rsp+0x30], xmm3
00007f8fe1fd7861  vmovaps [rsp+0x40], xmm5
00007f8fe1fd7867  vmovaps [rsp+0x50], xmm6
00007f8fe1fd786d  vmovaps [rsp+0x60], xmm7
00007f8fe1fd7873  vmovaps [rsp+0x70], xmm8
00007f8fe1fd7879  vmovaps [rsp+0x80], xmm9
00007f8fe1fd7882  vmovaps [rsp+0x90], xmm10
00007f8fe1fd788b  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd7894  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd789d  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd78a6  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd78af  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd78b8  sub rsp, 0x30
00007f8fe1fd78bc  movaps [rsp], xmm4
00007f8fe1fd78c0  movaps [rsp+0x10], xmm15
00007f8fe1fd78c6  movaps [rsp+0x20], xmm9
00007f8fe1fd78cc  lea rdi, [rsp]
00007f8fe1fd78d0  mov esi, 0x00
00007f8fe1fd78d5  mov rax, 0x6020BB77F530
00007f8fe1fd78df  call rax
00007f8fe1fd78e1  movaps xmm4, [rsp]
00007f8fe1fd78e5  add rsp, 0x30
00007f8fe1fd78e9  vmovaps xmm0, [rsp]
00007f8fe1fd78ee  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd78f4  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd78fa  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd7900  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd7906  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd790c  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd7912  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd7918  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd7921  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd792a  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd7933  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd793c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd7945  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd794e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd7957  add rsp, 0xF0
00007f8fe1fd795e  pop r11
00007f8fe1fd7960  pop r10
00007f8fe1fd7962  pop r9
00007f8fe1fd7964  pop r8
00007f8fe1fd7966  pop rsi
00007f8fe1fd7967  pop rdi
00007f8fe1fd7968  pop rdx
00007f8fe1fd7969  pop rcx
00007f8fe1fd796a  pop rax
00007f8fe1fd796b  add rsp, 0x08
00007f8fe1fd796f  jmp 0x00007F8FE1FD5CF9
00007f8fe1fd7974  call 0x00007F8FE1EE5820
00007f8fe1fd7979  jmp 0x00007F8FE1FD5D06
00007f8fe1fd797e  sub rsp, 0x08
00007f8fe1fd7982  push rax
00007f8fe1fd7983  push rcx
00007f8fe1fd7984  push rdx
00007f8fe1fd7985  push rdi
00007f8fe1fd7986  push rsi
00007f8fe1fd7987  push r8
00007f8fe1fd7989  push r9
00007f8fe1fd798b  push r10
00007f8fe1fd798d  push r11
00007f8fe1fd798f  sub rsp, 0xF0
00007f8fe1fd7996  vmovaps [rsp], xmm0
00007f8fe1fd799b  vmovaps [rsp+0x10], xmm1
00007f8fe1fd79a1  vmovaps [rsp+0x20], xmm2
00007f8fe1fd79a7  vmovaps [rsp+0x30], xmm4
00007f8fe1fd79ad  vmovaps [rsp+0x40], xmm5
00007f8fe1fd79b3  vmovaps [rsp+0x50], xmm6
00007f8fe1fd79b9  vmovaps [rsp+0x60], xmm7
00007f8fe1fd79bf  vmovaps [rsp+0x70], xmm8
00007f8fe1fd79c5  vmovaps [rsp+0x80], xmm9
00007f8fe1fd79ce  vmovaps [rsp+0x90], xmm10
00007f8fe1fd79d7  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd79e0  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd79e9  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd79f2  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd79fb  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd7a04  sub rsp, 0x30
00007f8fe1fd7a08  movaps [rsp], xmm3
00007f8fe1fd7a0c  movaps [rsp+0x10], xmm1
00007f8fe1fd7a11  movaps [rsp+0x20], xmm9
00007f8fe1fd7a17  lea rdi, [rsp]
00007f8fe1fd7a1b  mov esi, 0x00
00007f8fe1fd7a20  mov rax, 0x6020BB77F530
00007f8fe1fd7a2a  call rax
00007f8fe1fd7a2c  movaps xmm3, [rsp]
00007f8fe1fd7a30  add rsp, 0x30
00007f8fe1fd7a34  vmovaps xmm0, [rsp]
00007f8fe1fd7a39  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd7a3f  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd7a45  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd7a4b  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd7a51  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd7a57  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd7a5d  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd7a63  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd7a6c  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd7a75  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd7a7e  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd7a87  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd7a90  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd7a99  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd7aa2  add rsp, 0xF0
00007f8fe1fd7aa9  pop r11
00007f8fe1fd7aab  pop r10
00007f8fe1fd7aad  pop r9
00007f8fe1fd7aaf  pop r8
00007f8fe1fd7ab1  pop rsi
00007f8fe1fd7ab2  pop rdi
00007f8fe1fd7ab3  pop rdx
00007f8fe1fd7ab4  pop rcx
00007f8fe1fd7ab5  pop rax
00007f8fe1fd7ab6  add rsp, 0x08
00007f8fe1fd7aba  jmp 0x00007F8FE1FD5D43
00007f8fe1fd7abf  sub rsp, 0x08
00007f8fe1fd7ac3  push rax
00007f8fe1fd7ac4  push rcx
00007f8fe1fd7ac5  push rdx
00007f8fe1fd7ac6  push rdi
00007f8fe1fd7ac7  push rsi
00007f8fe1fd7ac8  push r8
00007f8fe1fd7aca  push r9
00007f8fe1fd7acc  push r10
00007f8fe1fd7ace  push r11
00007f8fe1fd7ad0  sub rsp, 0xF0
00007f8fe1fd7ad7  vmovaps [rsp], xmm0
00007f8fe1fd7adc  vmovaps [rsp+0x10], xmm2
00007f8fe1fd7ae2  vmovaps [rsp+0x20], xmm3
00007f8fe1fd7ae8  vmovaps [rsp+0x30], xmm4
00007f8fe1fd7aee  vmovaps [rsp+0x40], xmm5
00007f8fe1fd7af4  vmovaps [rsp+0x50], xmm6
00007f8fe1fd7afa  vmovaps [rsp+0x60], xmm7
00007f8fe1fd7b00  vmovaps [rsp+0x70], xmm8
00007f8fe1fd7b06  vmovaps [rsp+0x80], xmm9
00007f8fe1fd7b0f  vmovaps [rsp+0x90], xmm10
00007f8fe1fd7b18  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd7b21  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd7b2a  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd7b33  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd7b3c  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd7b45  sub rsp, 0x30
00007f8fe1fd7b49  movaps [rsp], xmm1
00007f8fe1fd7b4d  movaps [rsp+0x10], xmm15
00007f8fe1fd7b53  movaps [rsp+0x20], xmm9
00007f8fe1fd7b59  lea rdi, [rsp]
00007f8fe1fd7b5d  mov esi, 0x00
00007f8fe1fd7b62  mov rax, 0x6020BB77F530
00007f8fe1fd7b6c  call rax
00007f8fe1fd7b6e  movaps xmm1, [rsp]
00007f8fe1fd7b72  add rsp, 0x30
00007f8fe1fd7b76  vmovaps xmm0, [rsp]
00007f8fe1fd7b7b  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd7b81  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd7b87  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd7b8d  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd7b93  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd7b99  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd7b9f  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd7ba5  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd7bae  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd7bb7  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd7bc0  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd7bc9  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd7bd2  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd7bdb  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd7be4  add rsp, 0xF0
00007f8fe1fd7beb  pop r11
00007f8fe1fd7bed  pop r10
00007f8fe1fd7bef  pop r9
00007f8fe1fd7bf1  pop r8
00007f8fe1fd7bf3  pop rsi
00007f8fe1fd7bf4  pop rdi
00007f8fe1fd7bf5  pop rdx
00007f8fe1fd7bf6  pop rcx
00007f8fe1fd7bf7  pop rax
00007f8fe1fd7bf8  add rsp, 0x08
00007f8fe1fd7bfc  jmp 0x00007F8FE1FD5DCB
00007f8fe1fd7c01  call 0x00007F8FE1EE5820
00007f8fe1fd7c06  jmp 0x00007F8FE1FD5DD8
00007f8fe1fd7c0b  sub rsp, 0x08
00007f8fe1fd7c0f  push rax
00007f8fe1fd7c10  push rcx
00007f8fe1fd7c11  push rdx
00007f8fe1fd7c12  push rdi
00007f8fe1fd7c13  push rsi
00007f8fe1fd7c14  push r8
00007f8fe1fd7c16  push r9
00007f8fe1fd7c18  push r10
00007f8fe1fd7c1a  push r11
00007f8fe1fd7c1c  sub rsp, 0xF0
00007f8fe1fd7c23  vmovaps [rsp], xmm0
00007f8fe1fd7c28  vmovaps [rsp+0x10], xmm2
00007f8fe1fd7c2e  vmovaps [rsp+0x20], xmm3
00007f8fe1fd7c34  vmovaps [rsp+0x30], xmm4
00007f8fe1fd7c3a  vmovaps [rsp+0x40], xmm5
00007f8fe1fd7c40  vmovaps [rsp+0x50], xmm6
00007f8fe1fd7c46  vmovaps [rsp+0x60], xmm7
00007f8fe1fd7c4c  vmovaps [rsp+0x70], xmm8
00007f8fe1fd7c52  vmovaps [rsp+0x80], xmm9
00007f8fe1fd7c5b  vmovaps [rsp+0x90], xmm10
00007f8fe1fd7c64  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd7c6d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd7c76  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd7c7f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd7c88  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd7c91  sub rsp, 0x30
00007f8fe1fd7c95  movaps [rsp], xmm1
00007f8fe1fd7c99  movaps [rsp+0x10], xmm5
00007f8fe1fd7c9e  movaps [rsp+0x20], xmm7
00007f8fe1fd7ca3  lea rdi, [rsp]
00007f8fe1fd7ca7  mov esi, 0x00
00007f8fe1fd7cac  mov rax, 0x6020BB77F530
00007f8fe1fd7cb6  call rax
00007f8fe1fd7cb8  movaps xmm1, [rsp]
00007f8fe1fd7cbc  add rsp, 0x30
00007f8fe1fd7cc0  vmovaps xmm0, [rsp]
00007f8fe1fd7cc5  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd7ccb  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd7cd1  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd7cd7  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd7cdd  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd7ce3  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd7ce9  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd7cef  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd7cf8  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd7d01  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd7d0a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd7d13  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd7d1c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd7d25  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd7d2e  add rsp, 0xF0
00007f8fe1fd7d35  pop r11
00007f8fe1fd7d37  pop r10
00007f8fe1fd7d39  pop r9
00007f8fe1fd7d3b  pop r8
00007f8fe1fd7d3d  pop rsi
00007f8fe1fd7d3e  pop rdi
00007f8fe1fd7d3f  pop rdx
00007f8fe1fd7d40  pop rcx
00007f8fe1fd7d41  pop rax
00007f8fe1fd7d42  add rsp, 0x08
00007f8fe1fd7d46  jmp 0x00007F8FE1FD5E7D
00007f8fe1fd7d4b  sub rsp, 0x08
00007f8fe1fd7d4f  push rax
00007f8fe1fd7d50  push rcx
00007f8fe1fd7d51  push rdx
00007f8fe1fd7d52  push rdi
00007f8fe1fd7d53  push rsi
00007f8fe1fd7d54  push r8
00007f8fe1fd7d56  push r9
00007f8fe1fd7d58  push r10
00007f8fe1fd7d5a  push r11
00007f8fe1fd7d5c  sub rsp, 0xF0
00007f8fe1fd7d63  vmovaps [rsp], xmm0
00007f8fe1fd7d68  vmovaps [rsp+0x10], xmm1
00007f8fe1fd7d6e  vmovaps [rsp+0x20], xmm2
00007f8fe1fd7d74  vmovaps [rsp+0x30], xmm3
00007f8fe1fd7d7a  vmovaps [rsp+0x40], xmm4
00007f8fe1fd7d80  vmovaps [rsp+0x50], xmm5
00007f8fe1fd7d86  vmovaps [rsp+0x60], xmm6
00007f8fe1fd7d8c  vmovaps [rsp+0x70], xmm8
00007f8fe1fd7d92  vmovaps [rsp+0x80], xmm9
00007f8fe1fd7d9b  vmovaps [rsp+0x90], xmm10
00007f8fe1fd7da4  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd7dad  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd7db6  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd7dbf  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd7dc8  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd7dd1  sub rsp, 0x30
00007f8fe1fd7dd5  movaps [rsp], xmm7
00007f8fe1fd7dd9  movaps [rsp+0x10], xmm5
00007f8fe1fd7dde  movaps [rsp+0x20], xmm15
00007f8fe1fd7de4  lea rdi, [rsp]
00007f8fe1fd7de8  mov esi, 0x00
00007f8fe1fd7ded  mov rax, 0x6020BB77F530
00007f8fe1fd7df7  call rax
00007f8fe1fd7df9  movaps xmm7, [rsp]
00007f8fe1fd7dfd  add rsp, 0x30
00007f8fe1fd7e01  vmovaps xmm0, [rsp]
00007f8fe1fd7e06  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd7e0c  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd7e12  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd7e18  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd7e1e  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd7e24  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd7e2a  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd7e30  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd7e39  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd7e42  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd7e4b  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd7e54  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd7e5d  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd7e66  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd7e6f  add rsp, 0xF0
00007f8fe1fd7e76  pop r11
00007f8fe1fd7e78  pop r10
00007f8fe1fd7e7a  pop r9
00007f8fe1fd7e7c  pop r8
00007f8fe1fd7e7e  pop rsi
00007f8fe1fd7e7f  pop rdi
00007f8fe1fd7e80  pop rdx
00007f8fe1fd7e81  pop rcx
00007f8fe1fd7e82  pop rax
00007f8fe1fd7e83  add rsp, 0x08
00007f8fe1fd7e87  jmp 0x00007F8FE1FD5EB3
00007f8fe1fd7e8c  call 0x00007F8FE1ED64F0
00007f8fe1fd7e91  jmp 0x00007F8FE1FD5EC0
00007f8fe1fd7e96  sub rsp, 0x08
00007f8fe1fd7e9a  push rax
00007f8fe1fd7e9b  push rcx
00007f8fe1fd7e9c  push rdx
00007f8fe1fd7e9d  push rdi
00007f8fe1fd7e9e  push rsi
00007f8fe1fd7e9f  push r8
00007f8fe1fd7ea1  push r9
00007f8fe1fd7ea3  push r10
00007f8fe1fd7ea5  push r11
00007f8fe1fd7ea7  sub rsp, 0xF0
00007f8fe1fd7eae  vmovaps [rsp], xmm0
00007f8fe1fd7eb3  vmovaps [rsp+0x10], xmm1
00007f8fe1fd7eb9  vmovaps [rsp+0x20], xmm2
00007f8fe1fd7ebf  vmovaps [rsp+0x30], xmm3
00007f8fe1fd7ec5  vmovaps [rsp+0x40], xmm4
00007f8fe1fd7ecb  vmovaps [rsp+0x50], xmm5
00007f8fe1fd7ed1  vmovaps [rsp+0x60], xmm6
00007f8fe1fd7ed7  vmovaps [rsp+0x70], xmm7
00007f8fe1fd7edd  vmovaps [rsp+0x80], xmm8
00007f8fe1fd7ee6  vmovaps [rsp+0x90], xmm9
00007f8fe1fd7eef  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd7ef8  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd7f01  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd7f0a  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd7f13  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd7f1c  sub rsp, 0x30
00007f8fe1fd7f20  movaps [rsp], xmm15
00007f8fe1fd7f25  movaps [rsp+0x10], xmm5
00007f8fe1fd7f2a  movaps [rsp+0x20], xmm3
00007f8fe1fd7f2f  lea rdi, [rsp]
00007f8fe1fd7f33  mov esi, 0x00
00007f8fe1fd7f38  mov rax, 0x6020BB77F530
00007f8fe1fd7f42  call rax
00007f8fe1fd7f44  movaps xmm15, [rsp]
00007f8fe1fd7f49  add rsp, 0x30
00007f8fe1fd7f4d  vmovaps xmm0, [rsp]
00007f8fe1fd7f52  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd7f58  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd7f5e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd7f64  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd7f6a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd7f70  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd7f76  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd7f7c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd7f85  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd7f8e  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd7f97  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd7fa0  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd7fa9  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd7fb2  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd7fbb  add rsp, 0xF0
00007f8fe1fd7fc2  pop r11
00007f8fe1fd7fc4  pop r10
00007f8fe1fd7fc6  pop r9
00007f8fe1fd7fc8  pop r8
00007f8fe1fd7fca  pop rsi
00007f8fe1fd7fcb  pop rdi
00007f8fe1fd7fcc  pop rdx
00007f8fe1fd7fcd  pop rcx
00007f8fe1fd7fce  pop rax
00007f8fe1fd7fcf  add rsp, 0x08
00007f8fe1fd7fd3  jmp 0x00007F8FE1FD5EE6
00007f8fe1fd7fd8  sub rsp, 0x08
00007f8fe1fd7fdc  push rax
00007f8fe1fd7fdd  push rcx
00007f8fe1fd7fde  push rdx
00007f8fe1fd7fdf  push rdi
00007f8fe1fd7fe0  push rsi
00007f8fe1fd7fe1  push r8
00007f8fe1fd7fe3  push r9
00007f8fe1fd7fe5  push r10
00007f8fe1fd7fe7  push r11
00007f8fe1fd7fe9  sub rsp, 0xF0
00007f8fe1fd7ff0  vmovaps [rsp], xmm0
00007f8fe1fd7ff5  vmovaps [rsp+0x10], xmm2
00007f8fe1fd7ffb  vmovaps [rsp+0x20], xmm3
00007f8fe1fd8001  vmovaps [rsp+0x30], xmm4
00007f8fe1fd8007  vmovaps [rsp+0x40], xmm5
00007f8fe1fd800d  vmovaps [rsp+0x50], xmm6
00007f8fe1fd8013  vmovaps [rsp+0x60], xmm7
00007f8fe1fd8019  vmovaps [rsp+0x70], xmm8
00007f8fe1fd801f  vmovaps [rsp+0x80], xmm9
00007f8fe1fd8028  vmovaps [rsp+0x90], xmm10
00007f8fe1fd8031  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd803a  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd8043  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd804c  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd8055  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd805e  sub rsp, 0x30
00007f8fe1fd8062  movaps [rsp], xmm1
00007f8fe1fd8066  movaps [rsp+0x10], xmm5
00007f8fe1fd806b  movaps [rsp+0x20], xmm4
00007f8fe1fd8070  lea rdi, [rsp]
00007f8fe1fd8074  mov esi, 0x00
00007f8fe1fd8079  mov rax, 0x6020BB77F530
00007f8fe1fd8083  call rax
00007f8fe1fd8085  movaps xmm1, [rsp]
00007f8fe1fd8089  add rsp, 0x30
00007f8fe1fd808d  vmovaps xmm0, [rsp]
00007f8fe1fd8092  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd8098  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd809e  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd80a4  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd80aa  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd80b0  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd80b6  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd80bc  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd80c5  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd80ce  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd80d7  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd80e0  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd80e9  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd80f2  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd80fb  add rsp, 0xF0
00007f8fe1fd8102  pop r11
00007f8fe1fd8104  pop r10
00007f8fe1fd8106  pop r9
00007f8fe1fd8108  pop r8
00007f8fe1fd810a  pop rsi
00007f8fe1fd810b  pop rdi
00007f8fe1fd810c  pop rdx
00007f8fe1fd810d  pop rcx
00007f8fe1fd810e  pop rax
00007f8fe1fd810f  add rsp, 0x08
00007f8fe1fd8113  jmp 0x00007F8FE1FD5F06
00007f8fe1fd8118  sub rsp, 0x08
00007f8fe1fd811c  push rax
00007f8fe1fd811d  push rcx
00007f8fe1fd811e  push rdx
00007f8fe1fd811f  push rdi
00007f8fe1fd8120  push rsi
00007f8fe1fd8121  push r8
00007f8fe1fd8123  push r9
00007f8fe1fd8125  push r10
00007f8fe1fd8127  push r11
00007f8fe1fd8129  sub rsp, 0xF0
00007f8fe1fd8130  vmovaps [rsp], xmm0
00007f8fe1fd8135  vmovaps [rsp+0x10], xmm1
00007f8fe1fd813b  vmovaps [rsp+0x20], xmm2
00007f8fe1fd8141  vmovaps [rsp+0x30], xmm3
00007f8fe1fd8147  vmovaps [rsp+0x40], xmm5
00007f8fe1fd814d  vmovaps [rsp+0x50], xmm6
00007f8fe1fd8153  vmovaps [rsp+0x60], xmm7
00007f8fe1fd8159  vmovaps [rsp+0x70], xmm8
00007f8fe1fd815f  vmovaps [rsp+0x80], xmm9
00007f8fe1fd8168  vmovaps [rsp+0x90], xmm10
00007f8fe1fd8171  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd817a  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd8183  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd818c  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd8195  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd819e  sub rsp, 0x30
00007f8fe1fd81a2  movaps [rsp], xmm4
00007f8fe1fd81a6  movaps [rsp+0x10], xmm3
00007f8fe1fd81ab  movaps [rsp+0x20], xmm5
00007f8fe1fd81b0  lea rdi, [rsp]
00007f8fe1fd81b4  mov esi, 0x00
00007f8fe1fd81b9  mov rax, 0x6020BB77F530
00007f8fe1fd81c3  call rax
00007f8fe1fd81c5  movaps xmm4, [rsp]
00007f8fe1fd81c9  add rsp, 0x30
00007f8fe1fd81cd  vmovaps xmm0, [rsp]
00007f8fe1fd81d2  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd81d8  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd81de  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd81e4  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd81ea  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd81f0  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd81f6  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd81fc  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd8205  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd820e  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd8217  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd8220  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd8229  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd8232  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd823b  add rsp, 0xF0
00007f8fe1fd8242  pop r11
00007f8fe1fd8244  pop r10
00007f8fe1fd8246  pop r9
00007f8fe1fd8248  pop r8
00007f8fe1fd824a  pop rsi
00007f8fe1fd824b  pop rdi
00007f8fe1fd824c  pop rdx
00007f8fe1fd824d  pop rcx
00007f8fe1fd824e  pop rax
00007f8fe1fd824f  add rsp, 0x08
00007f8fe1fd8253  jmp 0x00007F8FE1FD5F54
00007f8fe1fd8258  call 0x00007F8FE1ED64F0
00007f8fe1fd825d  jmp 0x00007F8FE1FD5F61
00007f8fe1fd8262  sub rsp, 0x08
00007f8fe1fd8266  push rax
00007f8fe1fd8267  push rcx
00007f8fe1fd8268  push rdx
00007f8fe1fd8269  push rdi
00007f8fe1fd826a  push rsi
00007f8fe1fd826b  push r8
00007f8fe1fd826d  push r9
00007f8fe1fd826f  push r10
00007f8fe1fd8271  push r11
00007f8fe1fd8273  sub rsp, 0xF0
00007f8fe1fd827a  vmovaps [rsp], xmm0
00007f8fe1fd827f  vmovaps [rsp+0x10], xmm1
00007f8fe1fd8285  vmovaps [rsp+0x20], xmm2
00007f8fe1fd828b  vmovaps [rsp+0x30], xmm3
00007f8fe1fd8291  vmovaps [rsp+0x40], xmm4
00007f8fe1fd8297  vmovaps [rsp+0x50], xmm6
00007f8fe1fd829d  vmovaps [rsp+0x60], xmm7
00007f8fe1fd82a3  vmovaps [rsp+0x70], xmm8
00007f8fe1fd82a9  vmovaps [rsp+0x80], xmm9
00007f8fe1fd82b2  vmovaps [rsp+0x90], xmm10
00007f8fe1fd82bb  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd82c4  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd82cd  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd82d6  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd82df  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd82e8  sub rsp, 0x30
00007f8fe1fd82ec  movaps [rsp], xmm5
00007f8fe1fd82f0  movaps [rsp+0x10], xmm6
00007f8fe1fd82f5  movaps [rsp+0x20], xmm3
00007f8fe1fd82fa  lea rdi, [rsp]
00007f8fe1fd82fe  mov esi, 0x00
00007f8fe1fd8303  mov rax, 0x6020BB77F530
00007f8fe1fd830d  call rax
00007f8fe1fd830f  movaps xmm5, [rsp]
00007f8fe1fd8313  add rsp, 0x30
00007f8fe1fd8317  vmovaps xmm0, [rsp]
00007f8fe1fd831c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd8322  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd8328  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd832e  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd8334  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd833a  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd8340  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd8346  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd834f  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd8358  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd8361  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd836a  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd8373  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd837c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd8385  add rsp, 0xF0
00007f8fe1fd838c  pop r11
00007f8fe1fd838e  pop r10
00007f8fe1fd8390  pop r9
00007f8fe1fd8392  pop r8
00007f8fe1fd8394  pop rsi
00007f8fe1fd8395  pop rdi
00007f8fe1fd8396  pop rdx
00007f8fe1fd8397  pop rcx
00007f8fe1fd8398  pop rax
00007f8fe1fd8399  add rsp, 0x08
00007f8fe1fd839d  jmp 0x00007F8FE1FD5F87
00007f8fe1fd83a2  sub rsp, 0x08
00007f8fe1fd83a6  push rax
00007f8fe1fd83a7  push rcx
00007f8fe1fd83a8  push rdx
00007f8fe1fd83a9  push rdi
00007f8fe1fd83aa  push rsi
00007f8fe1fd83ab  push r8
00007f8fe1fd83ad  push r9
00007f8fe1fd83af  push r10
00007f8fe1fd83b1  push r11
00007f8fe1fd83b3  sub rsp, 0xF0
00007f8fe1fd83ba  vmovaps [rsp], xmm0
00007f8fe1fd83bf  vmovaps [rsp+0x10], xmm1
00007f8fe1fd83c5  vmovaps [rsp+0x20], xmm2
00007f8fe1fd83cb  vmovaps [rsp+0x30], xmm3
00007f8fe1fd83d1  vmovaps [rsp+0x40], xmm4
00007f8fe1fd83d7  vmovaps [rsp+0x50], xmm5
00007f8fe1fd83dd  vmovaps [rsp+0x60], xmm7
00007f8fe1fd83e3  vmovaps [rsp+0x70], xmm8
00007f8fe1fd83e9  vmovaps [rsp+0x80], xmm9
00007f8fe1fd83f2  vmovaps [rsp+0x90], xmm10
00007f8fe1fd83fb  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd8404  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd840d  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd8416  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd841f  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd8428  sub rsp, 0x30
00007f8fe1fd842c  movaps [rsp], xmm6
00007f8fe1fd8430  movaps [rsp+0x10], xmm9
00007f8fe1fd8436  movaps [rsp+0x20], xmm1
00007f8fe1fd843b  lea rdi, [rsp]
00007f8fe1fd843f  mov esi, 0x00
00007f8fe1fd8444  mov rax, 0x6020BB77F530
00007f8fe1fd844e  call rax
00007f8fe1fd8450  movaps xmm6, [rsp]
00007f8fe1fd8454  add rsp, 0x30
00007f8fe1fd8458  vmovaps xmm0, [rsp]
00007f8fe1fd845d  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd8463  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd8469  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd846f  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd8475  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd847b  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd8481  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd8487  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd8490  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd8499  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd84a2  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd84ab  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd84b4  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd84bd  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd84c6  add rsp, 0xF0
00007f8fe1fd84cd  pop r11
00007f8fe1fd84cf  pop r10
00007f8fe1fd84d1  pop r9
00007f8fe1fd84d3  pop r8
00007f8fe1fd84d5  pop rsi
00007f8fe1fd84d6  pop rdi
00007f8fe1fd84d7  pop rdx
00007f8fe1fd84d8  pop rcx
00007f8fe1fd84d9  pop rax
00007f8fe1fd84da  add rsp, 0x08
00007f8fe1fd84de  jmp 0x00007F8FE1FD5FAB
00007f8fe1fd84e3  sub rsp, 0x08
00007f8fe1fd84e7  push rax
00007f8fe1fd84e8  push rcx
00007f8fe1fd84e9  push rdx
00007f8fe1fd84ea  push rdi
00007f8fe1fd84eb  push rsi
00007f8fe1fd84ec  push r8
00007f8fe1fd84ee  push r9
00007f8fe1fd84f0  push r10
00007f8fe1fd84f2  push r11
00007f8fe1fd84f4  sub rsp, 0xF0
00007f8fe1fd84fb  vmovaps [rsp], xmm0
00007f8fe1fd8500  vmovaps [rsp+0x10], xmm1
00007f8fe1fd8506  vmovaps [rsp+0x20], xmm2
00007f8fe1fd850c  vmovaps [rsp+0x30], xmm3
00007f8fe1fd8512  vmovaps [rsp+0x40], xmm4
00007f8fe1fd8518  vmovaps [rsp+0x50], xmm5
00007f8fe1fd851e  vmovaps [rsp+0x60], xmm6
00007f8fe1fd8524  vmovaps [rsp+0x70], xmm7
00007f8fe1fd852a  vmovaps [rsp+0x80], xmm8
00007f8fe1fd8533  vmovaps [rsp+0x90], xmm10
00007f8fe1fd853c  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd8545  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd854e  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd8557  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd8560  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd8569  sub rsp, 0x30
00007f8fe1fd856d  movaps [rsp], xmm9
00007f8fe1fd8572  movaps [rsp+0x10], xmm3
00007f8fe1fd8577  movaps [rsp+0x20], xmm1
00007f8fe1fd857c  lea rdi, [rsp]
00007f8fe1fd8580  mov esi, 0x00
00007f8fe1fd8585  mov rax, 0x6020BB77F530
00007f8fe1fd858f  call rax
00007f8fe1fd8591  movaps xmm9, [rsp]
00007f8fe1fd8596  add rsp, 0x30
00007f8fe1fd859a  vmovaps xmm0, [rsp]
00007f8fe1fd859f  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd85a5  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd85ab  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd85b1  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd85b7  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd85bd  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd85c3  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd85c9  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd85d2  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd85db  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd85e4  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd85ed  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd85f6  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd85ff  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd8608  add rsp, 0xF0
00007f8fe1fd860f  pop r11
00007f8fe1fd8611  pop r10
00007f8fe1fd8613  pop r9
00007f8fe1fd8615  pop r8
00007f8fe1fd8617  pop rsi
00007f8fe1fd8618  pop rdi
00007f8fe1fd8619  pop rdx
00007f8fe1fd861a  pop rcx
00007f8fe1fd861b  pop rax
00007f8fe1fd861c  add rsp, 0x08
00007f8fe1fd8620  jmp 0x00007F8FE1FD5FF7
00007f8fe1fd8625  call 0x00007F8FE1ED64F0
00007f8fe1fd862a  jmp 0x00007F8FE1FD6004
00007f8fe1fd862f  sub rsp, 0x08
00007f8fe1fd8633  push rax
00007f8fe1fd8634  push rcx
00007f8fe1fd8635  push rdx
00007f8fe1fd8636  push rdi
00007f8fe1fd8637  push rsi
00007f8fe1fd8638  push r8
00007f8fe1fd863a  push r9
00007f8fe1fd863c  push r10
00007f8fe1fd863e  push r11
00007f8fe1fd8640  sub rsp, 0xF0
00007f8fe1fd8647  vmovaps [rsp], xmm0
00007f8fe1fd864c  vmovaps [rsp+0x10], xmm1
00007f8fe1fd8652  vmovaps [rsp+0x20], xmm2
00007f8fe1fd8658  vmovaps [rsp+0x30], xmm3
00007f8fe1fd865e  vmovaps [rsp+0x40], xmm4
00007f8fe1fd8664  vmovaps [rsp+0x50], xmm5
00007f8fe1fd866a  vmovaps [rsp+0x60], xmm6
00007f8fe1fd8670  vmovaps [rsp+0x70], xmm7
00007f8fe1fd8676  vmovaps [rsp+0x80], xmm8
00007f8fe1fd867f  vmovaps [rsp+0x90], xmm9
00007f8fe1fd8688  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd8691  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd869a  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd86a3  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd86ac  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd86b5  sub rsp, 0x30
00007f8fe1fd86b9  movaps [rsp], xmm15
00007f8fe1fd86be  movaps [rsp+0x10], xmm3
00007f8fe1fd86c3  movaps [rsp+0x20], xmm7
00007f8fe1fd86c8  lea rdi, [rsp]
00007f8fe1fd86cc  mov esi, 0x00
00007f8fe1fd86d1  mov rax, 0x6020BB77F530
00007f8fe1fd86db  call rax
00007f8fe1fd86dd  movaps xmm15, [rsp]
00007f8fe1fd86e2  add rsp, 0x30
00007f8fe1fd86e6  vmovaps xmm0, [rsp]
00007f8fe1fd86eb  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd86f1  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd86f7  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd86fd  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd8703  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd8709  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd870f  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd8715  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd871e  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd8727  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd8730  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd8739  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd8742  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd874b  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd8754  add rsp, 0xF0
00007f8fe1fd875b  pop r11
00007f8fe1fd875d  pop r10
00007f8fe1fd875f  pop r9
00007f8fe1fd8761  pop r8
00007f8fe1fd8763  pop rsi
00007f8fe1fd8764  pop rdi
00007f8fe1fd8765  pop rdx
00007f8fe1fd8766  pop rcx
00007f8fe1fd8767  pop rax
00007f8fe1fd8768  add rsp, 0x08
00007f8fe1fd876c  jmp 0x00007F8FE1FD6030
00007f8fe1fd8771  sub rsp, 0x08
00007f8fe1fd8775  push rax
00007f8fe1fd8776  push rcx
00007f8fe1fd8777  push rdx
00007f8fe1fd8778  push rdi
00007f8fe1fd8779  push rsi
00007f8fe1fd877a  push r8
00007f8fe1fd877c  push r9
00007f8fe1fd877e  push r10
00007f8fe1fd8780  push r11
00007f8fe1fd8782  sub rsp, 0xF0
00007f8fe1fd8789  vmovaps [rsp], xmm0
00007f8fe1fd878e  vmovaps [rsp+0x10], xmm1
00007f8fe1fd8794  vmovaps [rsp+0x20], xmm2
00007f8fe1fd879a  vmovaps [rsp+0x30], xmm4
00007f8fe1fd87a0  vmovaps [rsp+0x40], xmm5
00007f8fe1fd87a6  vmovaps [rsp+0x50], xmm6
00007f8fe1fd87ac  vmovaps [rsp+0x60], xmm7
00007f8fe1fd87b2  vmovaps [rsp+0x70], xmm8
00007f8fe1fd87b8  vmovaps [rsp+0x80], xmm9
00007f8fe1fd87c1  vmovaps [rsp+0x90], xmm10
00007f8fe1fd87ca  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd87d3  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd87dc  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd87e5  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd87ee  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd87f7  sub rsp, 0x30
00007f8fe1fd87fb  movaps [rsp], xmm3
00007f8fe1fd87ff  movaps [rsp+0x10], xmm1
00007f8fe1fd8804  movaps [rsp+0x20], xmm15
00007f8fe1fd880a  lea rdi, [rsp]
00007f8fe1fd880e  mov esi, 0x00
00007f8fe1fd8813  mov rax, 0x6020BB77F530
00007f8fe1fd881d  call rax
00007f8fe1fd881f  movaps xmm3, [rsp]
00007f8fe1fd8823  add rsp, 0x30
00007f8fe1fd8827  vmovaps xmm0, [rsp]
00007f8fe1fd882c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd8832  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd8838  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd883e  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd8844  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd884a  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd8850  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd8856  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd885f  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd8868  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd8871  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd887a  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd8883  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd888c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd8895  add rsp, 0xF0
00007f8fe1fd889c  pop r11
00007f8fe1fd889e  pop r10
00007f8fe1fd88a0  pop r9
00007f8fe1fd88a2  pop r8
00007f8fe1fd88a4  pop rsi
00007f8fe1fd88a5  pop rdi
00007f8fe1fd88a6  pop rdx
00007f8fe1fd88a7  pop rcx
00007f8fe1fd88a8  pop rax
00007f8fe1fd88a9  add rsp, 0x08
00007f8fe1fd88ad  jmp 0x00007F8FE1FD60BF
00007f8fe1fd88b2  call 0x00007F8FE1ED64F0
00007f8fe1fd88b7  jmp 0x00007F8FE1FD60C9
00007f8fe1fd88bc  sub rsp, 0x08
00007f8fe1fd88c0  push rax
00007f8fe1fd88c1  push rcx
00007f8fe1fd88c2  push rdx
00007f8fe1fd88c3  push rdi
00007f8fe1fd88c4  push rsi
00007f8fe1fd88c5  push r8
00007f8fe1fd88c7  push r9
00007f8fe1fd88c9  push r10
00007f8fe1fd88cb  push r11
00007f8fe1fd88cd  sub rsp, 0xF0
00007f8fe1fd88d4  vmovaps [rsp], xmm0
00007f8fe1fd88d9  vmovaps [rsp+0x10], xmm1
00007f8fe1fd88df  vmovaps [rsp+0x20], xmm2
00007f8fe1fd88e5  vmovaps [rsp+0x30], xmm3
00007f8fe1fd88eb  vmovaps [rsp+0x40], xmm4
00007f8fe1fd88f1  vmovaps [rsp+0x50], xmm5
00007f8fe1fd88f7  vmovaps [rsp+0x60], xmm6
00007f8fe1fd88fd  vmovaps [rsp+0x70], xmm7
00007f8fe1fd8903  vmovaps [rsp+0x80], xmm8
00007f8fe1fd890c  vmovaps [rsp+0x90], xmm9
00007f8fe1fd8915  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd891e  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd8927  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd8930  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd8939  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd8942  sub rsp, 0x30
00007f8fe1fd8946  movaps [rsp], xmm15
00007f8fe1fd894b  movaps [rsp+0x10], xmm14
00007f8fe1fd8951  movaps [rsp+0x20], xmm4
00007f8fe1fd8956  lea rdi, [rsp]
00007f8fe1fd895a  mov esi, 0x00
00007f8fe1fd895f  mov rax, 0x6020BB77F530
00007f8fe1fd8969  call rax
00007f8fe1fd896b  movaps xmm15, [rsp]
00007f8fe1fd8970  add rsp, 0x30
00007f8fe1fd8974  vmovaps xmm0, [rsp]
00007f8fe1fd8979  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd897f  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd8985  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd898b  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd8991  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd8997  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd899d  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd89a3  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd89ac  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd89b5  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd89be  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd89c7  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd89d0  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd89d9  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd89e2  add rsp, 0xF0
00007f8fe1fd89e9  pop r11
00007f8fe1fd89eb  pop r10
00007f8fe1fd89ed  pop r9
00007f8fe1fd89ef  pop r8
00007f8fe1fd89f1  pop rsi
00007f8fe1fd89f2  pop rdi
00007f8fe1fd89f3  pop rdx
00007f8fe1fd89f4  pop rcx
00007f8fe1fd89f5  pop rax
00007f8fe1fd89f6  add rsp, 0x08
00007f8fe1fd89fa  jmp 0x00007F8FE1FD60F7
00007f8fe1fd89ff  sub rsp, 0x08
00007f8fe1fd8a03  push rax
00007f8fe1fd8a04  push rcx
00007f8fe1fd8a05  push rdx
00007f8fe1fd8a06  push rdi
00007f8fe1fd8a07  push rsi
00007f8fe1fd8a08  push r8
00007f8fe1fd8a0a  push r9
00007f8fe1fd8a0c  push r10
00007f8fe1fd8a0e  push r11
00007f8fe1fd8a10  sub rsp, 0xF0
00007f8fe1fd8a17  vmovaps [rsp], xmm0
00007f8fe1fd8a1c  vmovaps [rsp+0x10], xmm1
00007f8fe1fd8a22  vmovaps [rsp+0x20], xmm2
00007f8fe1fd8a28  vmovaps [rsp+0x30], xmm3
00007f8fe1fd8a2e  vmovaps [rsp+0x40], xmm4
00007f8fe1fd8a34  vmovaps [rsp+0x50], xmm5
00007f8fe1fd8a3a  vmovaps [rsp+0x60], xmm6
00007f8fe1fd8a40  vmovaps [rsp+0x70], xmm7
00007f8fe1fd8a46  vmovaps [rsp+0x80], xmm8
00007f8fe1fd8a4f  vmovaps [rsp+0x90], xmm9
00007f8fe1fd8a58  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd8a61  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd8a6a  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd8a73  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd8a7c  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd8a85  sub rsp, 0x30
00007f8fe1fd8a89  movaps [rsp], xmm14
00007f8fe1fd8a8e  movaps [rsp+0x10], xmm2
00007f8fe1fd8a93  movaps [rsp+0x20], xmm1
00007f8fe1fd8a98  lea rdi, [rsp]
00007f8fe1fd8a9c  mov esi, 0x00
00007f8fe1fd8aa1  mov rax, 0x6020BB77F530
00007f8fe1fd8aab  call rax
00007f8fe1fd8aad  movaps xmm14, [rsp]
00007f8fe1fd8ab2  add rsp, 0x30
00007f8fe1fd8ab6  vmovaps xmm0, [rsp]
00007f8fe1fd8abb  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd8ac1  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd8ac7  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd8acd  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd8ad3  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd8ad9  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd8adf  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd8ae5  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd8aee  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd8af7  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd8b00  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd8b09  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd8b12  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd8b1b  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd8b24  add rsp, 0xF0
00007f8fe1fd8b2b  pop r11
00007f8fe1fd8b2d  pop r10
00007f8fe1fd8b2f  pop r9
00007f8fe1fd8b31  pop r8
00007f8fe1fd8b33  pop rsi
00007f8fe1fd8b34  pop rdi
00007f8fe1fd8b35  pop rdx
00007f8fe1fd8b36  pop rcx
00007f8fe1fd8b37  pop rax
00007f8fe1fd8b38  add rsp, 0x08
00007f8fe1fd8b3c  jmp 0x00007F8FE1FD611D
00007f8fe1fd8b41  sub rsp, 0x08
00007f8fe1fd8b45  push rax
00007f8fe1fd8b46  push rcx
00007f8fe1fd8b47  push rdx
00007f8fe1fd8b48  push rdi
00007f8fe1fd8b49  push rsi
00007f8fe1fd8b4a  push r8
00007f8fe1fd8b4c  push r9
00007f8fe1fd8b4e  push r10
00007f8fe1fd8b50  push r11
00007f8fe1fd8b52  sub rsp, 0xF0
00007f8fe1fd8b59  vmovaps [rsp], xmm0
00007f8fe1fd8b5e  vmovaps [rsp+0x10], xmm2
00007f8fe1fd8b64  vmovaps [rsp+0x20], xmm3
00007f8fe1fd8b6a  vmovaps [rsp+0x30], xmm4
00007f8fe1fd8b70  vmovaps [rsp+0x40], xmm5
00007f8fe1fd8b76  vmovaps [rsp+0x50], xmm6
00007f8fe1fd8b7c  vmovaps [rsp+0x60], xmm7
00007f8fe1fd8b82  vmovaps [rsp+0x70], xmm8
00007f8fe1fd8b88  vmovaps [rsp+0x80], xmm9
00007f8fe1fd8b91  vmovaps [rsp+0x90], xmm10
00007f8fe1fd8b9a  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd8ba3  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd8bac  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd8bb5  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd8bbe  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd8bc7  sub rsp, 0x30
00007f8fe1fd8bcb  movaps [rsp], xmm1
00007f8fe1fd8bcf  movaps [rsp+0x10], xmm4
00007f8fe1fd8bd4  movaps [rsp+0x20], xmm9
00007f8fe1fd8bda  lea rdi, [rsp]
00007f8fe1fd8bde  mov esi, 0x00
00007f8fe1fd8be3  mov rax, 0x6020BB77F530
00007f8fe1fd8bed  call rax
00007f8fe1fd8bef  movaps xmm1, [rsp]
00007f8fe1fd8bf3  add rsp, 0x30
00007f8fe1fd8bf7  vmovaps xmm0, [rsp]
00007f8fe1fd8bfc  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd8c02  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd8c08  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd8c0e  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd8c14  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd8c1a  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd8c20  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd8c26  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd8c2f  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd8c38  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd8c41  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd8c4a  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd8c53  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd8c5c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd8c65  add rsp, 0xF0
00007f8fe1fd8c6c  pop r11
00007f8fe1fd8c6e  pop r10
00007f8fe1fd8c70  pop r9
00007f8fe1fd8c72  pop r8
00007f8fe1fd8c74  pop rsi
00007f8fe1fd8c75  pop rdi
00007f8fe1fd8c76  pop rdx
00007f8fe1fd8c77  pop rcx
00007f8fe1fd8c78  pop rax
00007f8fe1fd8c79  add rsp, 0x08
00007f8fe1fd8c7d  jmp 0x00007F8FE1FD613B
00007f8fe1fd8c82  sub rsp, 0x08
00007f8fe1fd8c86  push rax
00007f8fe1fd8c87  push rcx
00007f8fe1fd8c88  push rdx
00007f8fe1fd8c89  push rdi
00007f8fe1fd8c8a  push rsi
00007f8fe1fd8c8b  push r8
00007f8fe1fd8c8d  push r9
00007f8fe1fd8c8f  push r10
00007f8fe1fd8c91  push r11
00007f8fe1fd8c93  sub rsp, 0xF0
00007f8fe1fd8c9a  vmovaps [rsp], xmm0
00007f8fe1fd8c9f  vmovaps [rsp+0x10], xmm1
00007f8fe1fd8ca5  vmovaps [rsp+0x20], xmm2
00007f8fe1fd8cab  vmovaps [rsp+0x30], xmm3
00007f8fe1fd8cb1  vmovaps [rsp+0x40], xmm5
00007f8fe1fd8cb7  vmovaps [rsp+0x50], xmm6
00007f8fe1fd8cbd  vmovaps [rsp+0x60], xmm7
00007f8fe1fd8cc3  vmovaps [rsp+0x70], xmm8
00007f8fe1fd8cc9  vmovaps [rsp+0x80], xmm9
00007f8fe1fd8cd2  vmovaps [rsp+0x90], xmm10
00007f8fe1fd8cdb  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd8ce4  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd8ced  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd8cf6  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd8cff  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd8d08  sub rsp, 0x30
00007f8fe1fd8d0c  movaps [rsp], xmm4
00007f8fe1fd8d10  movaps [rsp+0x10], xmm2
00007f8fe1fd8d15  movaps [rsp+0x20], xmm9
00007f8fe1fd8d1b  lea rdi, [rsp]
00007f8fe1fd8d1f  mov esi, 0x00
00007f8fe1fd8d24  mov rax, 0x6020BB77F530
00007f8fe1fd8d2e  call rax
00007f8fe1fd8d30  movaps xmm4, [rsp]
00007f8fe1fd8d34  add rsp, 0x30
00007f8fe1fd8d38  vmovaps xmm0, [rsp]
00007f8fe1fd8d3d  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd8d43  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd8d49  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd8d4f  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd8d55  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd8d5b  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd8d61  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd8d67  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd8d70  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd8d79  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd8d82  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd8d8b  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd8d94  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd8d9d  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd8da6  add rsp, 0xF0
00007f8fe1fd8dad  pop r11
00007f8fe1fd8daf  pop r10
00007f8fe1fd8db1  pop r9
00007f8fe1fd8db3  pop r8
00007f8fe1fd8db5  pop rsi
00007f8fe1fd8db6  pop rdi
00007f8fe1fd8db7  pop rdx
00007f8fe1fd8db8  pop rcx
00007f8fe1fd8db9  pop rax
00007f8fe1fd8dba  add rsp, 0x08
00007f8fe1fd8dbe  jmp 0x00007F8FE1FD616B
00007f8fe1fd8dc3  sub rsp, 0x08
00007f8fe1fd8dc7  push rax
00007f8fe1fd8dc8  push rcx
00007f8fe1fd8dc9  push rdx
00007f8fe1fd8dca  push rdi
00007f8fe1fd8dcb  push rsi
00007f8fe1fd8dcc  push r8
00007f8fe1fd8dce  push r9
00007f8fe1fd8dd0  push r10
00007f8fe1fd8dd2  push r11
00007f8fe1fd8dd4  sub rsp, 0xF0
00007f8fe1fd8ddb  vmovaps [rsp], xmm0
00007f8fe1fd8de0  vmovaps [rsp+0x10], xmm1
00007f8fe1fd8de6  vmovaps [rsp+0x20], xmm2
00007f8fe1fd8dec  vmovaps [rsp+0x30], xmm3
00007f8fe1fd8df2  vmovaps [rsp+0x40], xmm4
00007f8fe1fd8df8  vmovaps [rsp+0x50], xmm5
00007f8fe1fd8dfe  vmovaps [rsp+0x60], xmm6
00007f8fe1fd8e04  vmovaps [rsp+0x70], xmm7
00007f8fe1fd8e0a  vmovaps [rsp+0x80], xmm8
00007f8fe1fd8e13  vmovaps [rsp+0x90], xmm10
00007f8fe1fd8e1c  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd8e25  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd8e2e  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd8e37  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd8e40  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd8e49  sub rsp, 0x30
00007f8fe1fd8e4d  movaps [rsp], xmm9
00007f8fe1fd8e52  movaps [rsp+0x10], xmm2
00007f8fe1fd8e57  movaps [rsp+0x20], xmm1
00007f8fe1fd8e5c  lea rdi, [rsp]
00007f8fe1fd8e60  mov esi, 0x00
00007f8fe1fd8e65  mov rax, 0x6020BB77F530
00007f8fe1fd8e6f  call rax
00007f8fe1fd8e71  movaps xmm9, [rsp]
00007f8fe1fd8e76  add rsp, 0x30
00007f8fe1fd8e7a  vmovaps xmm0, [rsp]
00007f8fe1fd8e7f  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd8e85  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd8e8b  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd8e91  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd8e97  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd8e9d  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd8ea3  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd8ea9  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd8eb2  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd8ebb  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd8ec4  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd8ecd  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd8ed6  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd8edf  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd8ee8  add rsp, 0xF0
00007f8fe1fd8eef  pop r11
00007f8fe1fd8ef1  pop r10
00007f8fe1fd8ef3  pop r9
00007f8fe1fd8ef5  pop r8
00007f8fe1fd8ef7  pop rsi
00007f8fe1fd8ef8  pop rdi
00007f8fe1fd8ef9  pop rdx
00007f8fe1fd8efa  pop rcx
00007f8fe1fd8efb  pop rax
00007f8fe1fd8efc  add rsp, 0x08
00007f8fe1fd8f00  jmp 0x00007F8FE1FD61A1
00007f8fe1fd8f05  sub rsp, 0x08
00007f8fe1fd8f09  push rax
00007f8fe1fd8f0a  push rcx
00007f8fe1fd8f0b  push rdx
00007f8fe1fd8f0c  push rdi
00007f8fe1fd8f0d  push rsi
00007f8fe1fd8f0e  push r8
00007f8fe1fd8f10  push r9
00007f8fe1fd8f12  push r10
00007f8fe1fd8f14  push r11
00007f8fe1fd8f16  sub rsp, 0xF0
00007f8fe1fd8f1d  vmovaps [rsp], xmm0
00007f8fe1fd8f22  vmovaps [rsp+0x10], xmm2
00007f8fe1fd8f28  vmovaps [rsp+0x20], xmm3
00007f8fe1fd8f2e  vmovaps [rsp+0x30], xmm4
00007f8fe1fd8f34  vmovaps [rsp+0x40], xmm5
00007f8fe1fd8f3a  vmovaps [rsp+0x50], xmm6
00007f8fe1fd8f40  vmovaps [rsp+0x60], xmm7
00007f8fe1fd8f46  vmovaps [rsp+0x70], xmm8
00007f8fe1fd8f4c  vmovaps [rsp+0x80], xmm9
00007f8fe1fd8f55  vmovaps [rsp+0x90], xmm10
00007f8fe1fd8f5e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd8f67  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd8f70  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd8f79  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd8f82  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd8f8b  sub rsp, 0x30
00007f8fe1fd8f8f  movaps [rsp], xmm1
00007f8fe1fd8f93  movaps [rsp+0x10], xmm15
00007f8fe1fd8f99  movaps [rsp+0x20], xmm6
00007f8fe1fd8f9e  lea rdi, [rsp]
00007f8fe1fd8fa2  mov esi, 0x00
00007f8fe1fd8fa7  mov rax, 0x6020BB77F530
00007f8fe1fd8fb1  call rax
00007f8fe1fd8fb3  movaps xmm1, [rsp]
00007f8fe1fd8fb7  add rsp, 0x30
00007f8fe1fd8fbb  vmovaps xmm0, [rsp]
00007f8fe1fd8fc0  vmovaps xmm2, [rsp+0x10]
00007f8fe1fd8fc6  vmovaps xmm3, [rsp+0x20]
00007f8fe1fd8fcc  vmovaps xmm4, [rsp+0x30]
00007f8fe1fd8fd2  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd8fd8  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd8fde  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd8fe4  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd8fea  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd8ff3  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd8ffc  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd9005  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd900e  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd9017  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd9020  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd9029  add rsp, 0xF0
00007f8fe1fd9030  pop r11
00007f8fe1fd9032  pop r10
00007f8fe1fd9034  pop r9
00007f8fe1fd9036  pop r8
00007f8fe1fd9038  pop rsi
00007f8fe1fd9039  pop rdi
00007f8fe1fd903a  pop rdx
00007f8fe1fd903b  pop rcx
00007f8fe1fd903c  pop rax
00007f8fe1fd903d  add rsp, 0x08
00007f8fe1fd9041  jmp 0x00007F8FE1FD61C2
00007f8fe1fd9046  sub rsp, 0x08
00007f8fe1fd904a  push rax
00007f8fe1fd904b  push rcx
00007f8fe1fd904c  push rdx
00007f8fe1fd904d  push rdi
00007f8fe1fd904e  push rsi
00007f8fe1fd904f  push r8
00007f8fe1fd9051  push r9
00007f8fe1fd9053  push r10
00007f8fe1fd9055  push r11
00007f8fe1fd9057  sub rsp, 0xF0
00007f8fe1fd905e  vmovaps [rsp], xmm0
00007f8fe1fd9063  vmovaps [rsp+0x10], xmm1
00007f8fe1fd9069  vmovaps [rsp+0x20], xmm2
00007f8fe1fd906f  vmovaps [rsp+0x30], xmm3
00007f8fe1fd9075  vmovaps [rsp+0x40], xmm4
00007f8fe1fd907b  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9081  vmovaps [rsp+0x60], xmm6
00007f8fe1fd9087  vmovaps [rsp+0x70], xmm7
00007f8fe1fd908d  vmovaps [rsp+0x80], xmm8
00007f8fe1fd9096  vmovaps [rsp+0x90], xmm9
00007f8fe1fd909f  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd90a8  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd90b1  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd90ba  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd90c3  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd90cc  sub rsp, 0x30
00007f8fe1fd90d0  movaps [rsp], xmm15
00007f8fe1fd90d5  movaps [rsp+0x10], xmm5
00007f8fe1fd90da  movaps [rsp+0x20], xmm3
00007f8fe1fd90df  lea rdi, [rsp]
00007f8fe1fd90e3  mov esi, 0x00
00007f8fe1fd90e8  mov rax, 0x6020BB77F530
00007f8fe1fd90f2  call rax
00007f8fe1fd90f4  movaps xmm15, [rsp]
00007f8fe1fd90f9  add rsp, 0x30
00007f8fe1fd90fd  vmovaps xmm0, [rsp]
00007f8fe1fd9102  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9108  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd910e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd9114  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd911a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd9120  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd9126  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd912c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd9135  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd913e  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd9147  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd9150  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd9159  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd9162  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd916b  add rsp, 0xF0
00007f8fe1fd9172  pop r11
00007f8fe1fd9174  pop r10
00007f8fe1fd9176  pop r9
00007f8fe1fd9178  pop r8
00007f8fe1fd917a  pop rsi
00007f8fe1fd917b  pop rdi
00007f8fe1fd917c  pop rdx
00007f8fe1fd917d  pop rcx
00007f8fe1fd917e  pop rax
00007f8fe1fd917f  add rsp, 0x08
00007f8fe1fd9183  jmp 0x00007F8FE1FD61DC
00007f8fe1fd9188  sub rsp, 0x08
00007f8fe1fd918c  push rax
00007f8fe1fd918d  push rcx
00007f8fe1fd918e  push rdx
00007f8fe1fd918f  push rdi
00007f8fe1fd9190  push rsi
00007f8fe1fd9191  push r8
00007f8fe1fd9193  push r9
00007f8fe1fd9195  push r10
00007f8fe1fd9197  push r11
00007f8fe1fd9199  sub rsp, 0xF0
00007f8fe1fd91a0  vmovaps [rsp], xmm0
00007f8fe1fd91a5  vmovaps [rsp+0x10], xmm1
00007f8fe1fd91ab  vmovaps [rsp+0x20], xmm2
00007f8fe1fd91b1  vmovaps [rsp+0x30], xmm3
00007f8fe1fd91b7  vmovaps [rsp+0x40], xmm4
00007f8fe1fd91bd  vmovaps [rsp+0x50], xmm6
00007f8fe1fd91c3  vmovaps [rsp+0x60], xmm7
00007f8fe1fd91c9  vmovaps [rsp+0x70], xmm8
00007f8fe1fd91cf  vmovaps [rsp+0x80], xmm9
00007f8fe1fd91d8  vmovaps [rsp+0x90], xmm10
00007f8fe1fd91e1  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd91ea  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd91f3  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd91fc  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9205  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd920e  sub rsp, 0x30
00007f8fe1fd9212  movaps [rsp], xmm5
00007f8fe1fd9216  movaps [rsp+0x10], xmm8
00007f8fe1fd921c  movaps [rsp+0x20], xmm6
00007f8fe1fd9221  lea rdi, [rsp]
00007f8fe1fd9225  mov esi, 0x00
00007f8fe1fd922a  mov rax, 0x6020BB77F530
00007f8fe1fd9234  call rax
00007f8fe1fd9236  movaps xmm5, [rsp]
00007f8fe1fd923a  add rsp, 0x30
00007f8fe1fd923e  vmovaps xmm0, [rsp]
00007f8fe1fd9243  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9249  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd924f  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd9255  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd925b  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd9261  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd9267  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd926d  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd9276  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd927f  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd9288  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd9291  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd929a  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd92a3  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd92ac  add rsp, 0xF0
00007f8fe1fd92b3  pop r11
00007f8fe1fd92b5  pop r10
00007f8fe1fd92b7  pop r9
00007f8fe1fd92b9  pop r8
00007f8fe1fd92bb  pop rsi
00007f8fe1fd92bc  pop rdi
00007f8fe1fd92bd  pop rdx
00007f8fe1fd92be  pop rcx
00007f8fe1fd92bf  pop rax
00007f8fe1fd92c0  add rsp, 0x08
00007f8fe1fd92c4  jmp 0x00007F8FE1FD6200
00007f8fe1fd92c9  sub rsp, 0x08
00007f8fe1fd92cd  push rax
00007f8fe1fd92ce  push rcx
00007f8fe1fd92cf  push rdx
00007f8fe1fd92d0  push rdi
00007f8fe1fd92d1  push rsi
00007f8fe1fd92d2  push r8
00007f8fe1fd92d4  push r9
00007f8fe1fd92d6  push r10
00007f8fe1fd92d8  push r11
00007f8fe1fd92da  sub rsp, 0xF0
00007f8fe1fd92e1  vmovaps [rsp], xmm0
00007f8fe1fd92e6  vmovaps [rsp+0x10], xmm1
00007f8fe1fd92ec  vmovaps [rsp+0x20], xmm2
00007f8fe1fd92f2  vmovaps [rsp+0x30], xmm3
00007f8fe1fd92f8  vmovaps [rsp+0x40], xmm4
00007f8fe1fd92fe  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9304  vmovaps [rsp+0x60], xmm7
00007f8fe1fd930a  vmovaps [rsp+0x70], xmm8
00007f8fe1fd9310  vmovaps [rsp+0x80], xmm9
00007f8fe1fd9319  vmovaps [rsp+0x90], xmm10
00007f8fe1fd9322  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd932b  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd9334  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd933d  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9346  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd934f  sub rsp, 0x30
00007f8fe1fd9353  movaps [rsp], xmm6
00007f8fe1fd9357  movaps [rsp+0x10], xmm10
00007f8fe1fd935d  movaps [rsp+0x20], xmm8
00007f8fe1fd9363  lea rdi, [rsp]
00007f8fe1fd9367  mov esi, 0x00
00007f8fe1fd936c  mov rax, 0x6020BB77F530
00007f8fe1fd9376  call rax
00007f8fe1fd9378  movaps xmm6, [rsp]
00007f8fe1fd937c  add rsp, 0x30
00007f8fe1fd9380  vmovaps xmm0, [rsp]
00007f8fe1fd9385  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd938b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd9391  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd9397  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd939d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd93a3  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd93a9  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd93af  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd93b8  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd93c1  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd93ca  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd93d3  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd93dc  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd93e5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd93ee  add rsp, 0xF0
00007f8fe1fd93f5  pop r11
00007f8fe1fd93f7  pop r10
00007f8fe1fd93f9  pop r9
00007f8fe1fd93fb  pop r8
00007f8fe1fd93fd  pop rsi
00007f8fe1fd93fe  pop rdi
00007f8fe1fd93ff  pop rdx
00007f8fe1fd9400  pop rcx
00007f8fe1fd9401  pop rax
00007f8fe1fd9402  add rsp, 0x08
00007f8fe1fd9406  jmp 0x00007F8FE1FD6225
00007f8fe1fd940b  sub rsp, 0x08
00007f8fe1fd940f  push rax
00007f8fe1fd9410  push rcx
00007f8fe1fd9411  push rdx
00007f8fe1fd9412  push rdi
00007f8fe1fd9413  push rsi
00007f8fe1fd9414  push r8
00007f8fe1fd9416  push r9
00007f8fe1fd9418  push r10
00007f8fe1fd941a  push r11
00007f8fe1fd941c  sub rsp, 0xF0
00007f8fe1fd9423  vmovaps [rsp], xmm0
00007f8fe1fd9428  vmovaps [rsp+0x10], xmm1
00007f8fe1fd942e  vmovaps [rsp+0x20], xmm2
00007f8fe1fd9434  vmovaps [rsp+0x30], xmm3
00007f8fe1fd943a  vmovaps [rsp+0x40], xmm4
00007f8fe1fd9440  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9446  vmovaps [rsp+0x60], xmm6
00007f8fe1fd944c  vmovaps [rsp+0x70], xmm7
00007f8fe1fd9452  vmovaps [rsp+0x80], xmm8
00007f8fe1fd945b  vmovaps [rsp+0x90], xmm9
00007f8fe1fd9464  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd946d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd9476  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd947f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9488  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd9491  sub rsp, 0x30
00007f8fe1fd9495  movaps [rsp], xmm10
00007f8fe1fd949a  movaps [rsp+0x10], xmm8
00007f8fe1fd94a0  movaps [rsp+0x20], xmm14
00007f8fe1fd94a6  lea rdi, [rsp]
00007f8fe1fd94aa  mov esi, 0x00
00007f8fe1fd94af  mov rax, 0x6020BB77F530
00007f8fe1fd94b9  call rax
00007f8fe1fd94bb  movaps xmm10, [rsp]
00007f8fe1fd94c0  add rsp, 0x30
00007f8fe1fd94c4  vmovaps xmm0, [rsp]
00007f8fe1fd94c9  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd94cf  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd94d5  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd94db  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd94e1  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd94e7  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd94ed  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd94f3  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd94fc  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd9505  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd950e  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd9517  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd9520  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd9529  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd9532  add rsp, 0xF0
00007f8fe1fd9539  pop r11
00007f8fe1fd953b  pop r10
00007f8fe1fd953d  pop r9
00007f8fe1fd953f  pop r8
00007f8fe1fd9541  pop rsi
00007f8fe1fd9542  pop rdi
00007f8fe1fd9543  pop rdx
00007f8fe1fd9544  pop rcx
00007f8fe1fd9545  pop rax
00007f8fe1fd9546  add rsp, 0x08
00007f8fe1fd954a  jmp 0x00007F8FE1FD6245
00007f8fe1fd954f  sub rsp, 0x08
00007f8fe1fd9553  push rax
00007f8fe1fd9554  push rcx
00007f8fe1fd9555  push rdx
00007f8fe1fd9556  push rdi
00007f8fe1fd9557  push rsi
00007f8fe1fd9558  push r8
00007f8fe1fd955a  push r9
00007f8fe1fd955c  push r10
00007f8fe1fd955e  push r11
00007f8fe1fd9560  sub rsp, 0xF0
00007f8fe1fd9567  vmovaps [rsp], xmm0
00007f8fe1fd956c  vmovaps [rsp+0x10], xmm1
00007f8fe1fd9572  vmovaps [rsp+0x20], xmm2
00007f8fe1fd9578  vmovaps [rsp+0x30], xmm3
00007f8fe1fd957e  vmovaps [rsp+0x40], xmm4
00007f8fe1fd9584  vmovaps [rsp+0x50], xmm5
00007f8fe1fd958a  vmovaps [rsp+0x60], xmm6
00007f8fe1fd9590  vmovaps [rsp+0x70], xmm7
00007f8fe1fd9596  vmovaps [rsp+0x80], xmm8
00007f8fe1fd959f  vmovaps [rsp+0x90], xmm9
00007f8fe1fd95a8  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd95b1  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd95ba  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd95c3  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd95cc  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd95d5  sub rsp, 0x30
00007f8fe1fd95d9  movaps [rsp], xmm14
00007f8fe1fd95de  movaps [rsp+0x10], xmm8
00007f8fe1fd95e4  movaps [rsp+0x20], xmm4
00007f8fe1fd95e9  lea rdi, [rsp]
00007f8fe1fd95ed  mov esi, 0x00
00007f8fe1fd95f2  mov rax, 0x6020BB77F530
00007f8fe1fd95fc  call rax
00007f8fe1fd95fe  movaps xmm14, [rsp]
00007f8fe1fd9603  add rsp, 0x30
00007f8fe1fd9607  vmovaps xmm0, [rsp]
00007f8fe1fd960c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9612  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd9618  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd961e  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd9624  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd962a  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd9630  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd9636  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd963f  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd9648  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd9651  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd965a  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd9663  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd966c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd9675  add rsp, 0xF0
00007f8fe1fd967c  pop r11
00007f8fe1fd967e  pop r10
00007f8fe1fd9680  pop r9
00007f8fe1fd9682  pop r8
00007f8fe1fd9684  pop rsi
00007f8fe1fd9685  pop rdi
00007f8fe1fd9686  pop rdx
00007f8fe1fd9687  pop rcx
00007f8fe1fd9688  pop rax
00007f8fe1fd9689  add rsp, 0x08
00007f8fe1fd968d  jmp 0x00007F8FE1FD6265
00007f8fe1fd9692  sub rsp, 0x08
00007f8fe1fd9696  push rax
00007f8fe1fd9697  push rcx
00007f8fe1fd9698  push rdx
00007f8fe1fd9699  push rdi
00007f8fe1fd969a  push rsi
00007f8fe1fd969b  push r8
00007f8fe1fd969d  push r9
00007f8fe1fd969f  push r10
00007f8fe1fd96a1  push r11
00007f8fe1fd96a3  sub rsp, 0xF0
00007f8fe1fd96aa  vmovaps [rsp], xmm0
00007f8fe1fd96af  vmovaps [rsp+0x10], xmm1
00007f8fe1fd96b5  vmovaps [rsp+0x20], xmm2
00007f8fe1fd96bb  vmovaps [rsp+0x30], xmm3
00007f8fe1fd96c1  vmovaps [rsp+0x40], xmm5
00007f8fe1fd96c7  vmovaps [rsp+0x50], xmm6
00007f8fe1fd96cd  vmovaps [rsp+0x60], xmm7
00007f8fe1fd96d3  vmovaps [rsp+0x70], xmm8
00007f8fe1fd96d9  vmovaps [rsp+0x80], xmm9
00007f8fe1fd96e2  vmovaps [rsp+0x90], xmm10
00007f8fe1fd96eb  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd96f4  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd96fd  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd9706  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd970f  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd9718  sub rsp, 0x30
00007f8fe1fd971c  movaps [rsp], xmm4
00007f8fe1fd9720  movaps [rsp+0x10], xmm13
00007f8fe1fd9726  movaps [rsp+0x20], xmm8
00007f8fe1fd972c  lea rdi, [rsp]
00007f8fe1fd9730  mov esi, 0x00
00007f8fe1fd9735  mov rax, 0x6020BB77F530
00007f8fe1fd973f  call rax
00007f8fe1fd9741  movaps xmm4, [rsp]
00007f8fe1fd9745  add rsp, 0x30
00007f8fe1fd9749  vmovaps xmm0, [rsp]
00007f8fe1fd974e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9754  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd975a  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd9760  vmovaps xmm5, [rsp+0x40]
00007f8fe1fd9766  vmovaps xmm6, [rsp+0x50]
00007f8fe1fd976c  vmovaps xmm7, [rsp+0x60]
00007f8fe1fd9772  vmovaps xmm8, [rsp+0x70]
00007f8fe1fd9778  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd9781  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd978a  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd9793  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd979c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd97a5  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd97ae  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd97b7  add rsp, 0xF0
00007f8fe1fd97be  pop r11
00007f8fe1fd97c0  pop r10
00007f8fe1fd97c2  pop r9
00007f8fe1fd97c4  pop r8
00007f8fe1fd97c6  pop rsi
00007f8fe1fd97c7  pop rdi
00007f8fe1fd97c8  pop rdx
00007f8fe1fd97c9  pop rcx
00007f8fe1fd97ca  pop rax
00007f8fe1fd97cb  add rsp, 0x08
00007f8fe1fd97cf  jmp 0x00007F8FE1FD628A
00007f8fe1fd97d4  sub rsp, 0x08
00007f8fe1fd97d8  push rax
00007f8fe1fd97d9  push rcx
00007f8fe1fd97da  push rdx
00007f8fe1fd97db  push rdi
00007f8fe1fd97dc  push rsi
00007f8fe1fd97dd  push r8
00007f8fe1fd97df  push r9
00007f8fe1fd97e1  push r10
00007f8fe1fd97e3  push r11
00007f8fe1fd97e5  sub rsp, 0xF0
00007f8fe1fd97ec  vmovaps [rsp], xmm0
00007f8fe1fd97f1  vmovaps [rsp+0x10], xmm1
00007f8fe1fd97f7  vmovaps [rsp+0x20], xmm2
00007f8fe1fd97fd  vmovaps [rsp+0x30], xmm3
00007f8fe1fd9803  vmovaps [rsp+0x40], xmm4
00007f8fe1fd9809  vmovaps [rsp+0x50], xmm5
00007f8fe1fd980f  vmovaps [rsp+0x60], xmm6
00007f8fe1fd9815  vmovaps [rsp+0x70], xmm7
00007f8fe1fd981b  vmovaps [rsp+0x80], xmm8
00007f8fe1fd9824  vmovaps [rsp+0x90], xmm9
00007f8fe1fd982d  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd9836  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd983f  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd9848  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9851  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd985a  sub rsp, 0x30
00007f8fe1fd985e  movaps [rsp], xmm13
00007f8fe1fd9863  movaps [rsp+0x10], xmm15
00007f8fe1fd9869  movaps [rsp+0x20], xmm9
00007f8fe1fd986f  lea rdi, [rsp]
00007f8fe1fd9873  mov esi, 0x00
00007f8fe1fd9878  mov rax, 0x6020BB77F530
00007f8fe1fd9882  call rax
00007f8fe1fd9884  movaps xmm13, [rsp]
00007f8fe1fd9889  add rsp, 0x30
00007f8fe1fd988d  vmovaps xmm0, [rsp]
00007f8fe1fd9892  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9898  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd989e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd98a4  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd98aa  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd98b0  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd98b6  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd98bc  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd98c5  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd98ce  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd98d7  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd98e0  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd98e9  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd98f2  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd98fb  add rsp, 0xF0
00007f8fe1fd9902  pop r11
00007f8fe1fd9904  pop r10
00007f8fe1fd9906  pop r9
00007f8fe1fd9908  pop r8
00007f8fe1fd990a  pop rsi
00007f8fe1fd990b  pop rdi
00007f8fe1fd990c  pop rdx
00007f8fe1fd990d  pop rcx
00007f8fe1fd990e  pop rax
00007f8fe1fd990f  add rsp, 0x08
00007f8fe1fd9913  jmp 0x00007F8FE1FD62A5
00007f8fe1fd9918  sub rsp, 0x08
00007f8fe1fd991c  push rax
00007f8fe1fd991d  push rcx
00007f8fe1fd991e  push rdx
00007f8fe1fd991f  push rdi
00007f8fe1fd9920  push rsi
00007f8fe1fd9921  push r8
00007f8fe1fd9923  push r9
00007f8fe1fd9925  push r10
00007f8fe1fd9927  push r11
00007f8fe1fd9929  sub rsp, 0xF0
00007f8fe1fd9930  vmovaps [rsp], xmm0
00007f8fe1fd9935  vmovaps [rsp+0x10], xmm1
00007f8fe1fd993b  vmovaps [rsp+0x20], xmm2
00007f8fe1fd9941  vmovaps [rsp+0x30], xmm3
00007f8fe1fd9947  vmovaps [rsp+0x40], xmm4
00007f8fe1fd994d  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9953  vmovaps [rsp+0x60], xmm6
00007f8fe1fd9959  vmovaps [rsp+0x70], xmm7
00007f8fe1fd995f  vmovaps [rsp+0x80], xmm8
00007f8fe1fd9968  vmovaps [rsp+0x90], xmm9
00007f8fe1fd9971  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd997a  vmovaps [rsp+0xB0], xmm11
00007f8fe1fd9983  vmovaps [rsp+0xC0], xmm12
00007f8fe1fd998c  vmovaps [rsp+0xD0], xmm13
00007f8fe1fd9995  vmovaps [rsp+0xE0], xmm14
00007f8fe1fd999e  sub rsp, 0x30
00007f8fe1fd99a2  movaps [rsp], xmm15
00007f8fe1fd99a7  movaps [rsp+0x10], xmm1
00007f8fe1fd99ac  movaps [rsp+0x20], xmm5
00007f8fe1fd99b1  lea rdi, [rsp]
00007f8fe1fd99b5  mov esi, 0x00
00007f8fe1fd99ba  mov rax, 0x6020BB77F530
00007f8fe1fd99c4  call rax
00007f8fe1fd99c6  movaps xmm15, [rsp]
00007f8fe1fd99cb  add rsp, 0x30
00007f8fe1fd99cf  vmovaps xmm0, [rsp]
00007f8fe1fd99d4  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd99da  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd99e0  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd99e6  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd99ec  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd99f2  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd99f8  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd99fe  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd9a07  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd9a10  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd9a19  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fd9a22  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fd9a2b  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fd9a34  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fd9a3d  add rsp, 0xF0
00007f8fe1fd9a44  pop r11
00007f8fe1fd9a46  pop r10
00007f8fe1fd9a48  pop r9
00007f8fe1fd9a4a  pop r8
00007f8fe1fd9a4c  pop rsi
00007f8fe1fd9a4d  pop rdi
00007f8fe1fd9a4e  pop rdx
00007f8fe1fd9a4f  pop rcx
00007f8fe1fd9a50  pop rax
00007f8fe1fd9a51  add rsp, 0x08
00007f8fe1fd9a55  jmp 0x00007F8FE1FD62C0
00007f8fe1fd9a5a  call 0x00007F8FE1ED64F0
00007f8fe1fd9a5f  jmp 0x00007F8FE1FD631B
00007f8fe1fd9a64  sub rsp, 0x08
00007f8fe1fd9a68  push rax
00007f8fe1fd9a69  push rcx
00007f8fe1fd9a6a  push rdx
00007f8fe1fd9a6b  push rdi
00007f8fe1fd9a6c  push rsi
00007f8fe1fd9a6d  push r8
00007f8fe1fd9a6f  push r9
00007f8fe1fd9a71  push r10
00007f8fe1fd9a73  push r11
00007f8fe1fd9a75  sub rsp, 0xF0
00007f8fe1fd9a7c  vmovaps [rsp], xmm0
00007f8fe1fd9a81  vmovaps [rsp+0x10], xmm1
00007f8fe1fd9a87  vmovaps [rsp+0x20], xmm2
00007f8fe1fd9a8d  vmovaps [rsp+0x30], xmm3
00007f8fe1fd9a93  vmovaps [rsp+0x40], xmm4
00007f8fe1fd9a99  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9a9f  vmovaps [rsp+0x60], xmm6
00007f8fe1fd9aa5  vmovaps [rsp+0x70], xmm7
00007f8fe1fd9aab  vmovaps [rsp+0x80], xmm8
00007f8fe1fd9ab4  vmovaps [rsp+0x90], xmm10
00007f8fe1fd9abd  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd9ac6  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd9acf  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd9ad8  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9ae1  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd9aea  sub rsp, 0x30
00007f8fe1fd9aee  movaps [rsp], xmm9
00007f8fe1fd9af3  movaps [rsp+0x10], xmm8
00007f8fe1fd9af9  movaps [rsp+0x20], xmm11
00007f8fe1fd9aff  lea rdi, [rsp]
00007f8fe1fd9b03  mov esi, 0x00
00007f8fe1fd9b08  mov rax, 0x6020BB77F530
00007f8fe1fd9b12  call rax
00007f8fe1fd9b14  movaps xmm9, [rsp]
00007f8fe1fd9b19  add rsp, 0x30
00007f8fe1fd9b1d  vmovaps xmm0, [rsp]
00007f8fe1fd9b22  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9b28  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd9b2e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd9b34  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd9b3a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd9b40  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd9b46  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd9b4c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd9b55  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd9b5e  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd9b67  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd9b70  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd9b79  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd9b82  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd9b8b  add rsp, 0xF0
00007f8fe1fd9b92  pop r11
00007f8fe1fd9b94  pop r10
00007f8fe1fd9b96  pop r9
00007f8fe1fd9b98  pop r8
00007f8fe1fd9b9a  pop rsi
00007f8fe1fd9b9b  pop rdi
00007f8fe1fd9b9c  pop rdx
00007f8fe1fd9b9d  pop rcx
00007f8fe1fd9b9e  pop rax
00007f8fe1fd9b9f  add rsp, 0x08
00007f8fe1fd9ba3  jmp 0x00007F8FE1FD6352
00007f8fe1fd9ba8  sub rsp, 0x08
00007f8fe1fd9bac  push rax
00007f8fe1fd9bad  push rcx
00007f8fe1fd9bae  push rdx
00007f8fe1fd9baf  push rdi
00007f8fe1fd9bb0  push rsi
00007f8fe1fd9bb1  push r8
00007f8fe1fd9bb3  push r9
00007f8fe1fd9bb5  push r10
00007f8fe1fd9bb7  push r11
00007f8fe1fd9bb9  sub rsp, 0xF0
00007f8fe1fd9bc0  vmovaps [rsp], xmm0
00007f8fe1fd9bc5  vmovaps [rsp+0x10], xmm1
00007f8fe1fd9bcb  vmovaps [rsp+0x20], xmm2
00007f8fe1fd9bd1  vmovaps [rsp+0x30], xmm3
00007f8fe1fd9bd7  vmovaps [rsp+0x40], xmm4
00007f8fe1fd9bdd  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9be3  vmovaps [rsp+0x60], xmm6
00007f8fe1fd9be9  vmovaps [rsp+0x70], xmm7
00007f8fe1fd9bef  vmovaps [rsp+0x80], xmm8
00007f8fe1fd9bf8  vmovaps [rsp+0x90], xmm9
00007f8fe1fd9c01  vmovaps [rsp+0xA0], xmm10
00007f8fe1fd9c0a  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd9c13  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd9c1c  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9c25  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd9c2e  sub rsp, 0x30
00007f8fe1fd9c32  movaps [rsp], xmm11
00007f8fe1fd9c37  movaps [rsp+0x10], xmm10
00007f8fe1fd9c3d  movaps [rsp+0x20], xmm6
00007f8fe1fd9c42  lea rdi, [rsp]
00007f8fe1fd9c46  mov esi, 0x00
00007f8fe1fd9c4b  mov rax, 0x6020BB77F530
00007f8fe1fd9c55  call rax
00007f8fe1fd9c57  movaps xmm11, [rsp]
00007f8fe1fd9c5c  add rsp, 0x30
00007f8fe1fd9c60  vmovaps xmm0, [rsp]
00007f8fe1fd9c65  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9c6b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd9c71  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd9c77  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd9c7d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd9c83  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd9c89  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd9c8f  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd9c98  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd9ca1  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fd9caa  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd9cb3  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd9cbc  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd9cc5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd9cce  add rsp, 0xF0
00007f8fe1fd9cd5  pop r11
00007f8fe1fd9cd7  pop r10
00007f8fe1fd9cd9  pop r9
00007f8fe1fd9cdb  pop r8
00007f8fe1fd9cdd  pop rsi
00007f8fe1fd9cde  pop rdi
00007f8fe1fd9cdf  pop rdx
00007f8fe1fd9ce0  pop rcx
00007f8fe1fd9ce1  pop rax
00007f8fe1fd9ce2  add rsp, 0x08
00007f8fe1fd9ce6  jmp 0x00007F8FE1FD636D
00007f8fe1fd9ceb  sub rsp, 0x08
00007f8fe1fd9cef  push rax
00007f8fe1fd9cf0  push rcx
00007f8fe1fd9cf1  push rdx
00007f8fe1fd9cf2  push rdi
00007f8fe1fd9cf3  push rsi
00007f8fe1fd9cf4  push r8
00007f8fe1fd9cf6  push r9
00007f8fe1fd9cf8  push r10
00007f8fe1fd9cfa  push r11
00007f8fe1fd9cfc  sub rsp, 0xF0
00007f8fe1fd9d03  vmovaps [rsp], xmm0
00007f8fe1fd9d08  vmovaps [rsp+0x10], xmm1
00007f8fe1fd9d0e  vmovaps [rsp+0x20], xmm2
00007f8fe1fd9d14  vmovaps [rsp+0x30], xmm3
00007f8fe1fd9d1a  vmovaps [rsp+0x40], xmm4
00007f8fe1fd9d20  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9d26  vmovaps [rsp+0x60], xmm6
00007f8fe1fd9d2c  vmovaps [rsp+0x70], xmm7
00007f8fe1fd9d32  vmovaps [rsp+0x80], xmm8
00007f8fe1fd9d3b  vmovaps [rsp+0x90], xmm9
00007f8fe1fd9d44  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd9d4d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd9d56  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd9d5f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9d68  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd9d71  sub rsp, 0x30
00007f8fe1fd9d75  movaps [rsp], xmm10
00007f8fe1fd9d7a  movaps [rsp+0x10], xmm14
00007f8fe1fd9d80  movaps [rsp+0x20], xmm4
00007f8fe1fd9d85  lea rdi, [rsp]
00007f8fe1fd9d89  mov esi, 0x00
00007f8fe1fd9d8e  mov rax, 0x6020BB77F530
00007f8fe1fd9d98  call rax
00007f8fe1fd9d9a  movaps xmm10, [rsp]
00007f8fe1fd9d9f  add rsp, 0x30
00007f8fe1fd9da3  vmovaps xmm0, [rsp]
00007f8fe1fd9da8  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9dae  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd9db4  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd9dba  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd9dc0  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd9dc6  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd9dcc  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd9dd2  vmovaps xmm8, [rsp+0x80]
00007f8fe1fd9ddb  vmovaps xmm9, [rsp+0x90]
00007f8fe1fd9de4  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd9ded  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd9df6  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd9dff  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd9e08  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd9e11  add rsp, 0xF0
00007f8fe1fd9e18  pop r11
00007f8fe1fd9e1a  pop r10
00007f8fe1fd9e1c  pop r9
00007f8fe1fd9e1e  pop r8
00007f8fe1fd9e20  pop rsi
00007f8fe1fd9e21  pop rdi
00007f8fe1fd9e22  pop rdx
00007f8fe1fd9e23  pop rcx
00007f8fe1fd9e24  pop rax
00007f8fe1fd9e25  add rsp, 0x08
00007f8fe1fd9e29  jmp 0x00007F8FE1FD6388
00007f8fe1fd9e2e  sub rsp, 0x08
00007f8fe1fd9e32  push rax
00007f8fe1fd9e33  push rcx
00007f8fe1fd9e34  push rdx
00007f8fe1fd9e35  push rdi
00007f8fe1fd9e36  push rsi
00007f8fe1fd9e37  push r8
00007f8fe1fd9e39  push r9
00007f8fe1fd9e3b  push r10
00007f8fe1fd9e3d  push r11
00007f8fe1fd9e3f  sub rsp, 0xF0
00007f8fe1fd9e46  vmovaps [rsp], xmm0
00007f8fe1fd9e4b  vmovaps [rsp+0x10], xmm1
00007f8fe1fd9e51  vmovaps [rsp+0x20], xmm2
00007f8fe1fd9e57  vmovaps [rsp+0x30], xmm3
00007f8fe1fd9e5d  vmovaps [rsp+0x40], xmm4
00007f8fe1fd9e63  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9e69  vmovaps [rsp+0x60], xmm6
00007f8fe1fd9e6f  vmovaps [rsp+0x70], xmm7
00007f8fe1fd9e75  vmovaps [rsp+0x80], xmm9
00007f8fe1fd9e7e  vmovaps [rsp+0x90], xmm10
00007f8fe1fd9e87  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd9e90  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd9e99  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd9ea2  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9eab  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd9eb4  sub rsp, 0x30
00007f8fe1fd9eb8  movaps [rsp], xmm8
00007f8fe1fd9ebd  movaps [rsp+0x10], xmm1
00007f8fe1fd9ec2  movaps [rsp+0x20], xmm14
00007f8fe1fd9ec8  lea rdi, [rsp]
00007f8fe1fd9ecc  mov esi, 0x00
00007f8fe1fd9ed1  mov rax, 0x6020BB77F530
00007f8fe1fd9edb  call rax
00007f8fe1fd9edd  movaps xmm8, [rsp]
00007f8fe1fd9ee2  add rsp, 0x30
00007f8fe1fd9ee6  vmovaps xmm0, [rsp]
00007f8fe1fd9eeb  vmovaps xmm1, [rsp+0x10]
00007f8fe1fd9ef1  vmovaps xmm2, [rsp+0x20]
00007f8fe1fd9ef7  vmovaps xmm3, [rsp+0x30]
00007f8fe1fd9efd  vmovaps xmm4, [rsp+0x40]
00007f8fe1fd9f03  vmovaps xmm5, [rsp+0x50]
00007f8fe1fd9f09  vmovaps xmm6, [rsp+0x60]
00007f8fe1fd9f0f  vmovaps xmm7, [rsp+0x70]
00007f8fe1fd9f15  vmovaps xmm9, [rsp+0x80]
00007f8fe1fd9f1e  vmovaps xmm10, [rsp+0x90]
00007f8fe1fd9f27  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fd9f30  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fd9f39  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fd9f42  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fd9f4b  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fd9f54  add rsp, 0xF0
00007f8fe1fd9f5b  pop r11
00007f8fe1fd9f5d  pop r10
00007f8fe1fd9f5f  pop r9
00007f8fe1fd9f61  pop r8
00007f8fe1fd9f63  pop rsi
00007f8fe1fd9f64  pop rdi
00007f8fe1fd9f65  pop rdx
00007f8fe1fd9f66  pop rcx
00007f8fe1fd9f67  pop rax
00007f8fe1fd9f68  add rsp, 0x08
00007f8fe1fd9f6c  jmp 0x00007F8FE1FD63AE
00007f8fe1fd9f71  sub rsp, 0x08
00007f8fe1fd9f75  push rax
00007f8fe1fd9f76  push rcx
00007f8fe1fd9f77  push rdx
00007f8fe1fd9f78  push rdi
00007f8fe1fd9f79  push rsi
00007f8fe1fd9f7a  push r8
00007f8fe1fd9f7c  push r9
00007f8fe1fd9f7e  push r10
00007f8fe1fd9f80  push r11
00007f8fe1fd9f82  sub rsp, 0xF0
00007f8fe1fd9f89  vmovaps [rsp], xmm0
00007f8fe1fd9f8e  vmovaps [rsp+0x10], xmm1
00007f8fe1fd9f94  vmovaps [rsp+0x20], xmm2
00007f8fe1fd9f9a  vmovaps [rsp+0x30], xmm3
00007f8fe1fd9fa0  vmovaps [rsp+0x40], xmm4
00007f8fe1fd9fa6  vmovaps [rsp+0x50], xmm5
00007f8fe1fd9fac  vmovaps [rsp+0x60], xmm7
00007f8fe1fd9fb2  vmovaps [rsp+0x70], xmm8
00007f8fe1fd9fb8  vmovaps [rsp+0x80], xmm9
00007f8fe1fd9fc1  vmovaps [rsp+0x90], xmm10
00007f8fe1fd9fca  vmovaps [rsp+0xA0], xmm11
00007f8fe1fd9fd3  vmovaps [rsp+0xB0], xmm12
00007f8fe1fd9fdc  vmovaps [rsp+0xC0], xmm13
00007f8fe1fd9fe5  vmovaps [rsp+0xD0], xmm14
00007f8fe1fd9fee  vmovaps [rsp+0xE0], xmm15
00007f8fe1fd9ff7  sub rsp, 0x30
00007f8fe1fd9ffb  movaps [rsp], xmm6
00007f8fe1fd9fff  movaps [rsp+0x10], xmm1
00007f8fe1fda004  movaps [rsp+0x20], xmm14
00007f8fe1fda00a  lea rdi, [rsp]
00007f8fe1fda00e  mov esi, 0x00
00007f8fe1fda013  mov rax, 0x6020BB77F530
00007f8fe1fda01d  call rax
00007f8fe1fda01f  movaps xmm6, [rsp]
00007f8fe1fda023  add rsp, 0x30
00007f8fe1fda027  vmovaps xmm0, [rsp]
00007f8fe1fda02c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fda032  vmovaps xmm2, [rsp+0x20]
00007f8fe1fda038  vmovaps xmm3, [rsp+0x30]
00007f8fe1fda03e  vmovaps xmm4, [rsp+0x40]
00007f8fe1fda044  vmovaps xmm5, [rsp+0x50]
00007f8fe1fda04a  vmovaps xmm7, [rsp+0x60]
00007f8fe1fda050  vmovaps xmm8, [rsp+0x70]
00007f8fe1fda056  vmovaps xmm9, [rsp+0x80]
00007f8fe1fda05f  vmovaps xmm10, [rsp+0x90]
00007f8fe1fda068  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fda071  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fda07a  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fda083  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fda08c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fda095  add rsp, 0xF0
00007f8fe1fda09c  pop r11
00007f8fe1fda09e  pop r10
00007f8fe1fda0a0  pop r9
00007f8fe1fda0a2  pop r8
00007f8fe1fda0a4  pop rsi
00007f8fe1fda0a5  pop rdi
00007f8fe1fda0a6  pop rdx
00007f8fe1fda0a7  pop rcx
00007f8fe1fda0a8  pop rax
00007f8fe1fda0a9  add rsp, 0x08
00007f8fe1fda0ad  jmp 0x00007F8FE1FD63DA
00007f8fe1fda0b2  sub rsp, 0x08
00007f8fe1fda0b6  push rax
00007f8fe1fda0b7  push rcx
00007f8fe1fda0b8  push rdx
00007f8fe1fda0b9  push rdi
00007f8fe1fda0ba  push rsi
00007f8fe1fda0bb  push r8
00007f8fe1fda0bd  push r9
00007f8fe1fda0bf  push r10
00007f8fe1fda0c1  push r11
00007f8fe1fda0c3  sub rsp, 0xF0
00007f8fe1fda0ca  vmovaps [rsp], xmm0
00007f8fe1fda0cf  vmovaps [rsp+0x10], xmm1
00007f8fe1fda0d5  vmovaps [rsp+0x20], xmm2
00007f8fe1fda0db  vmovaps [rsp+0x30], xmm3
00007f8fe1fda0e1  vmovaps [rsp+0x40], xmm4
00007f8fe1fda0e7  vmovaps [rsp+0x50], xmm5
00007f8fe1fda0ed  vmovaps [rsp+0x60], xmm6
00007f8fe1fda0f3  vmovaps [rsp+0x70], xmm7
00007f8fe1fda0f9  vmovaps [rsp+0x80], xmm8
00007f8fe1fda102  vmovaps [rsp+0x90], xmm9
00007f8fe1fda10b  vmovaps [rsp+0xA0], xmm10
00007f8fe1fda114  vmovaps [rsp+0xB0], xmm11
00007f8fe1fda11d  vmovaps [rsp+0xC0], xmm12
00007f8fe1fda126  vmovaps [rsp+0xD0], xmm13
00007f8fe1fda12f  vmovaps [rsp+0xE0], xmm15
00007f8fe1fda138  sub rsp, 0x30
00007f8fe1fda13c  movaps [rsp], xmm14
00007f8fe1fda141  movaps [rsp+0x10], xmm12
00007f8fe1fda147  movaps [rsp+0x20], xmm1
00007f8fe1fda14c  lea rdi, [rsp]
00007f8fe1fda150  mov esi, 0x00
00007f8fe1fda155  mov rax, 0x6020BB77F530
00007f8fe1fda15f  call rax
00007f8fe1fda161  movaps xmm14, [rsp]
00007f8fe1fda166  add rsp, 0x30
00007f8fe1fda16a  vmovaps xmm0, [rsp]
00007f8fe1fda16f  vmovaps xmm1, [rsp+0x10]
00007f8fe1fda175  vmovaps xmm2, [rsp+0x20]
00007f8fe1fda17b  vmovaps xmm3, [rsp+0x30]
00007f8fe1fda181  vmovaps xmm4, [rsp+0x40]
00007f8fe1fda187  vmovaps xmm5, [rsp+0x50]
00007f8fe1fda18d  vmovaps xmm6, [rsp+0x60]
00007f8fe1fda193  vmovaps xmm7, [rsp+0x70]
00007f8fe1fda199  vmovaps xmm8, [rsp+0x80]
00007f8fe1fda1a2  vmovaps xmm9, [rsp+0x90]
00007f8fe1fda1ab  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fda1b4  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fda1bd  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fda1c6  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fda1cf  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fda1d8  add rsp, 0xF0
00007f8fe1fda1df  pop r11
00007f8fe1fda1e1  pop r10
00007f8fe1fda1e3  pop r9
00007f8fe1fda1e5  pop r8
00007f8fe1fda1e7  pop rsi
00007f8fe1fda1e8  pop rdi
00007f8fe1fda1e9  pop rdx
00007f8fe1fda1ea  pop rcx
00007f8fe1fda1eb  pop rax
00007f8fe1fda1ec  add rsp, 0x08
00007f8fe1fda1f0  jmp 0x00007F8FE1FD6400
00007f8fe1fda1f5  sub rsp, 0x08
00007f8fe1fda1f9  push rax
00007f8fe1fda1fa  push rcx
00007f8fe1fda1fb  push rdx
00007f8fe1fda1fc  push rdi
00007f8fe1fda1fd  push rsi
00007f8fe1fda1fe  push r8
00007f8fe1fda200  push r9
00007f8fe1fda202  push r10
00007f8fe1fda204  push r11
00007f8fe1fda206  sub rsp, 0xF0
00007f8fe1fda20d  vmovaps [rsp], xmm0
00007f8fe1fda212  vmovaps [rsp+0x10], xmm2
00007f8fe1fda218  vmovaps [rsp+0x20], xmm3
00007f8fe1fda21e  vmovaps [rsp+0x30], xmm4
00007f8fe1fda224  vmovaps [rsp+0x40], xmm5
00007f8fe1fda22a  vmovaps [rsp+0x50], xmm6
00007f8fe1fda230  vmovaps [rsp+0x60], xmm7
00007f8fe1fda236  vmovaps [rsp+0x70], xmm8
00007f8fe1fda23c  vmovaps [rsp+0x80], xmm9
00007f8fe1fda245  vmovaps [rsp+0x90], xmm10
00007f8fe1fda24e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fda257  vmovaps [rsp+0xB0], xmm12
00007f8fe1fda260  vmovaps [rsp+0xC0], xmm13
00007f8fe1fda269  vmovaps [rsp+0xD0], xmm14
00007f8fe1fda272  vmovaps [rsp+0xE0], xmm15
00007f8fe1fda27b  sub rsp, 0x30
00007f8fe1fda27f  movaps [rsp], xmm1
00007f8fe1fda283  movaps [rsp+0x10], xmm13
00007f8fe1fda289  movaps [rsp+0x20], xmm9
00007f8fe1fda28f  lea rdi, [rsp]
00007f8fe1fda293  mov esi, 0x00
00007f8fe1fda298  mov rax, 0x6020BB77F530
00007f8fe1fda2a2  call rax
00007f8fe1fda2a4  movaps xmm1, [rsp]
00007f8fe1fda2a8  add rsp, 0x30
00007f8fe1fda2ac  vmovaps xmm0, [rsp]
00007f8fe1fda2b1  vmovaps xmm2, [rsp+0x10]
00007f8fe1fda2b7  vmovaps xmm3, [rsp+0x20]
00007f8fe1fda2bd  vmovaps xmm4, [rsp+0x30]
00007f8fe1fda2c3  vmovaps xmm5, [rsp+0x40]
00007f8fe1fda2c9  vmovaps xmm6, [rsp+0x50]
00007f8fe1fda2cf  vmovaps xmm7, [rsp+0x60]
00007f8fe1fda2d5  vmovaps xmm8, [rsp+0x70]
00007f8fe1fda2db  vmovaps xmm9, [rsp+0x80]
00007f8fe1fda2e4  vmovaps xmm10, [rsp+0x90]
00007f8fe1fda2ed  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fda2f6  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fda2ff  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fda308  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fda311  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fda31a  add rsp, 0xF0
00007f8fe1fda321  pop r11
00007f8fe1fda323  pop r10
00007f8fe1fda325  pop r9
00007f8fe1fda327  pop r8
00007f8fe1fda329  pop rsi
00007f8fe1fda32a  pop rdi
00007f8fe1fda32b  pop rdx
00007f8fe1fda32c  pop rcx
00007f8fe1fda32d  pop rax
00007f8fe1fda32e  add rsp, 0x08
00007f8fe1fda332  jmp 0x00007F8FE1FD641A
00007f8fe1fda337  sub rsp, 0x08
00007f8fe1fda33b  push rax
00007f8fe1fda33c  push rcx
00007f8fe1fda33d  push rdx
00007f8fe1fda33e  push rdi
00007f8fe1fda33f  push rsi
00007f8fe1fda340  push r8
00007f8fe1fda342  push r9
00007f8fe1fda344  push r10
00007f8fe1fda346  push r11
00007f8fe1fda348  sub rsp, 0xF0
00007f8fe1fda34f  vmovaps [rsp], xmm0
00007f8fe1fda354  vmovaps [rsp+0x10], xmm1
00007f8fe1fda35a  vmovaps [rsp+0x20], xmm2
00007f8fe1fda360  vmovaps [rsp+0x30], xmm3
00007f8fe1fda366  vmovaps [rsp+0x40], xmm4
00007f8fe1fda36c  vmovaps [rsp+0x50], xmm5
00007f8fe1fda372  vmovaps [rsp+0x60], xmm6
00007f8fe1fda378  vmovaps [rsp+0x70], xmm7
00007f8fe1fda37e  vmovaps [rsp+0x80], xmm8
00007f8fe1fda387  vmovaps [rsp+0x90], xmm9
00007f8fe1fda390  vmovaps [rsp+0xA0], xmm10
00007f8fe1fda399  vmovaps [rsp+0xB0], xmm11
00007f8fe1fda3a2  vmovaps [rsp+0xC0], xmm13
00007f8fe1fda3ab  vmovaps [rsp+0xD0], xmm14
00007f8fe1fda3b4  vmovaps [rsp+0xE0], xmm15
00007f8fe1fda3bd  sub rsp, 0x30
00007f8fe1fda3c1  movaps [rsp], xmm12
00007f8fe1fda3c6  movaps [rsp+0x10], xmm7
00007f8fe1fda3cb  movaps [rsp+0x20], xmm13
00007f8fe1fda3d1  lea rdi, [rsp]
00007f8fe1fda3d5  mov esi, 0x00
00007f8fe1fda3da  mov rax, 0x6020BB77F530
00007f8fe1fda3e4  call rax
00007f8fe1fda3e6  movaps xmm12, [rsp]
00007f8fe1fda3eb  add rsp, 0x30
00007f8fe1fda3ef  vmovaps xmm0, [rsp]
00007f8fe1fda3f4  vmovaps xmm1, [rsp+0x10]
00007f8fe1fda3fa  vmovaps xmm2, [rsp+0x20]
00007f8fe1fda400  vmovaps xmm3, [rsp+0x30]
00007f8fe1fda406  vmovaps xmm4, [rsp+0x40]
00007f8fe1fda40c  vmovaps xmm5, [rsp+0x50]
00007f8fe1fda412  vmovaps xmm6, [rsp+0x60]
00007f8fe1fda418  vmovaps xmm7, [rsp+0x70]
00007f8fe1fda41e  vmovaps xmm8, [rsp+0x80]
00007f8fe1fda427  vmovaps xmm9, [rsp+0x90]
00007f8fe1fda430  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fda439  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fda442  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fda44b  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fda454  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fda45d  add rsp, 0xF0
00007f8fe1fda464  pop r11
00007f8fe1fda466  pop r10
00007f8fe1fda468  pop r9
00007f8fe1fda46a  pop r8
00007f8fe1fda46c  pop rsi
00007f8fe1fda46d  pop rdi
00007f8fe1fda46e  pop rdx
00007f8fe1fda46f  pop rcx
00007f8fe1fda470  pop rax
00007f8fe1fda471  add rsp, 0x08
00007f8fe1fda475  jmp 0x00007F8FE1FD6441
00007f8fe1fda47a  sub rsp, 0x08
00007f8fe1fda47e  push rax
00007f8fe1fda47f  push rcx
00007f8fe1fda480  push rdx
00007f8fe1fda481  push rdi
00007f8fe1fda482  push rsi
00007f8fe1fda483  push r8
00007f8fe1fda485  push r9
00007f8fe1fda487  push r10
00007f8fe1fda489  push r11
00007f8fe1fda48b  sub rsp, 0xF0
00007f8fe1fda492  vmovaps [rsp], xmm0
00007f8fe1fda497  vmovaps [rsp+0x10], xmm1
00007f8fe1fda49d  vmovaps [rsp+0x20], xmm2
00007f8fe1fda4a3  vmovaps [rsp+0x30], xmm3
00007f8fe1fda4a9  vmovaps [rsp+0x40], xmm4
00007f8fe1fda4af  vmovaps [rsp+0x50], xmm5
00007f8fe1fda4b5  vmovaps [rsp+0x60], xmm6
00007f8fe1fda4bb  vmovaps [rsp+0x70], xmm7
00007f8fe1fda4c1  vmovaps [rsp+0x80], xmm8
00007f8fe1fda4ca  vmovaps [rsp+0x90], xmm9
00007f8fe1fda4d3  vmovaps [rsp+0xA0], xmm10
00007f8fe1fda4dc  vmovaps [rsp+0xB0], xmm11
00007f8fe1fda4e5  vmovaps [rsp+0xC0], xmm12
00007f8fe1fda4ee  vmovaps [rsp+0xD0], xmm14
00007f8fe1fda4f7  vmovaps [rsp+0xE0], xmm15
00007f8fe1fda500  sub rsp, 0x30
00007f8fe1fda504  movaps [rsp], xmm13
00007f8fe1fda509  movaps [rsp+0x10], xmm15
00007f8fe1fda50f  movaps [rsp+0x20], xmm8
00007f8fe1fda515  lea rdi, [rsp]
00007f8fe1fda519  mov esi, 0x00
00007f8fe1fda51e  mov rax, 0x6020BB77F530
00007f8fe1fda528  call rax
00007f8fe1fda52a  movaps xmm13, [rsp]
00007f8fe1fda52f  add rsp, 0x30
00007f8fe1fda533  vmovaps xmm0, [rsp]
00007f8fe1fda538  vmovaps xmm1, [rsp+0x10]
00007f8fe1fda53e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fda544  vmovaps xmm3, [rsp+0x30]
00007f8fe1fda54a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fda550  vmovaps xmm5, [rsp+0x50]
00007f8fe1fda556  vmovaps xmm6, [rsp+0x60]
00007f8fe1fda55c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fda562  vmovaps xmm8, [rsp+0x80]
00007f8fe1fda56b  vmovaps xmm9, [rsp+0x90]
00007f8fe1fda574  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fda57d  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fda586  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fda58f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fda598  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fda5a1  add rsp, 0xF0
00007f8fe1fda5a8  pop r11
00007f8fe1fda5aa  pop r10
00007f8fe1fda5ac  pop r9
00007f8fe1fda5ae  pop r8
00007f8fe1fda5b0  pop rsi
00007f8fe1fda5b1  pop rdi
00007f8fe1fda5b2  pop rdx
00007f8fe1fda5b3  pop rcx
00007f8fe1fda5b4  pop rax
00007f8fe1fda5b5  add rsp, 0x08
00007f8fe1fda5b9  jmp 0x00007F8FE1FD645C
00007f8fe1fda5be  sub rsp, 0x08
00007f8fe1fda5c2  push rax
00007f8fe1fda5c3  push rcx
00007f8fe1fda5c4  push rdx
00007f8fe1fda5c5  push rdi
00007f8fe1fda5c6  push rsi
00007f8fe1fda5c7  push r8
00007f8fe1fda5c9  push r9
00007f8fe1fda5cb  push r10
00007f8fe1fda5cd  push r11
00007f8fe1fda5cf  sub rsp, 0xF0
00007f8fe1fda5d6  vmovaps [rsp], xmm0
00007f8fe1fda5db  vmovaps [rsp+0x10], xmm1
00007f8fe1fda5e1  vmovaps [rsp+0x20], xmm2
00007f8fe1fda5e7  vmovaps [rsp+0x30], xmm3
00007f8fe1fda5ed  vmovaps [rsp+0x40], xmm4
00007f8fe1fda5f3  vmovaps [rsp+0x50], xmm5
00007f8fe1fda5f9  vmovaps [rsp+0x60], xmm6
00007f8fe1fda5ff  vmovaps [rsp+0x70], xmm7
00007f8fe1fda605  vmovaps [rsp+0x80], xmm9
00007f8fe1fda60e  vmovaps [rsp+0x90], xmm10
00007f8fe1fda617  vmovaps [rsp+0xA0], xmm11
00007f8fe1fda620  vmovaps [rsp+0xB0], xmm12
00007f8fe1fda629  vmovaps [rsp+0xC0], xmm13
00007f8fe1fda632  vmovaps [rsp+0xD0], xmm14
00007f8fe1fda63b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fda644  sub rsp, 0x30
00007f8fe1fda648  movaps [rsp], xmm8
00007f8fe1fda64d  movaps [rsp+0x10], xmm15
00007f8fe1fda653  movaps [rsp+0x20], xmm9
00007f8fe1fda659  lea rdi, [rsp]
00007f8fe1fda65d  mov esi, 0x00
00007f8fe1fda662  mov rax, 0x6020BB77F530
00007f8fe1fda66c  call rax
00007f8fe1fda66e  movaps xmm8, [rsp]
00007f8fe1fda673  add rsp, 0x30
00007f8fe1fda677  vmovaps xmm0, [rsp]
00007f8fe1fda67c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fda682  vmovaps xmm2, [rsp+0x20]
00007f8fe1fda688  vmovaps xmm3, [rsp+0x30]
00007f8fe1fda68e  vmovaps xmm4, [rsp+0x40]
00007f8fe1fda694  vmovaps xmm5, [rsp+0x50]
00007f8fe1fda69a  vmovaps xmm6, [rsp+0x60]
00007f8fe1fda6a0  vmovaps xmm7, [rsp+0x70]
00007f8fe1fda6a6  vmovaps xmm9, [rsp+0x80]
00007f8fe1fda6af  vmovaps xmm10, [rsp+0x90]
00007f8fe1fda6b8  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fda6c1  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fda6ca  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fda6d3  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fda6dc  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fda6e5  add rsp, 0xF0
00007f8fe1fda6ec  pop r11
00007f8fe1fda6ee  pop r10
00007f8fe1fda6f0  pop r9
00007f8fe1fda6f2  pop r8
00007f8fe1fda6f4  pop rsi
00007f8fe1fda6f5  pop rdi
00007f8fe1fda6f6  pop rdx
00007f8fe1fda6f7  pop rcx
00007f8fe1fda6f8  pop rax
00007f8fe1fda6f9  add rsp, 0x08
00007f8fe1fda6fd  jmp 0x00007F8FE1FD648A
00007f8fe1fda702  sub rsp, 0x08
00007f8fe1fda706  push rax
00007f8fe1fda707  push rcx
00007f8fe1fda708  push rdx
00007f8fe1fda709  push rdi
00007f8fe1fda70a  push rsi
00007f8fe1fda70b  push r8
00007f8fe1fda70d  push r9
00007f8fe1fda70f  push r10
00007f8fe1fda711  push r11
00007f8fe1fda713  sub rsp, 0xF0
00007f8fe1fda71a  vmovaps [rsp], xmm0
00007f8fe1fda71f  vmovaps [rsp+0x10], xmm1
00007f8fe1fda725  vmovaps [rsp+0x20], xmm2
00007f8fe1fda72b  vmovaps [rsp+0x30], xmm3
00007f8fe1fda731  vmovaps [rsp+0x40], xmm4
00007f8fe1fda737  vmovaps [rsp+0x50], xmm5
00007f8fe1fda73d  vmovaps [rsp+0x60], xmm6
00007f8fe1fda743  vmovaps [rsp+0x70], xmm7
00007f8fe1fda749  vmovaps [rsp+0x80], xmm8
00007f8fe1fda752  vmovaps [rsp+0x90], xmm9
00007f8fe1fda75b  vmovaps [rsp+0xA0], xmm10
00007f8fe1fda764  vmovaps [rsp+0xB0], xmm11
00007f8fe1fda76d  vmovaps [rsp+0xC0], xmm12
00007f8fe1fda776  vmovaps [rsp+0xD0], xmm13
00007f8fe1fda77f  vmovaps [rsp+0xE0], xmm14
00007f8fe1fda788  sub rsp, 0x30
00007f8fe1fda78c  movaps [rsp], xmm15
00007f8fe1fda791  movaps [rsp+0x10], xmm11
00007f8fe1fda797  movaps [rsp+0x20], xmm6
00007f8fe1fda79c  lea rdi, [rsp]
00007f8fe1fda7a0  mov esi, 0x00
00007f8fe1fda7a5  mov rax, 0x6020BB77F530
00007f8fe1fda7af  call rax
00007f8fe1fda7b1  movaps xmm15, [rsp]
00007f8fe1fda7b6  add rsp, 0x30
00007f8fe1fda7ba  vmovaps xmm0, [rsp]
00007f8fe1fda7bf  vmovaps xmm1, [rsp+0x10]
00007f8fe1fda7c5  vmovaps xmm2, [rsp+0x20]
00007f8fe1fda7cb  vmovaps xmm3, [rsp+0x30]
00007f8fe1fda7d1  vmovaps xmm4, [rsp+0x40]
00007f8fe1fda7d7  vmovaps xmm5, [rsp+0x50]
00007f8fe1fda7dd  vmovaps xmm6, [rsp+0x60]
00007f8fe1fda7e3  vmovaps xmm7, [rsp+0x70]
00007f8fe1fda7e9  vmovaps xmm8, [rsp+0x80]
00007f8fe1fda7f2  vmovaps xmm9, [rsp+0x90]
00007f8fe1fda7fb  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fda804  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fda80d  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fda816  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fda81f  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fda828  add rsp, 0xF0
00007f8fe1fda82f  pop r11
00007f8fe1fda831  pop r10
00007f8fe1fda833  pop r9
00007f8fe1fda835  pop r8
00007f8fe1fda837  pop rsi
00007f8fe1fda838  pop rdi
00007f8fe1fda839  pop rdx
00007f8fe1fda83a  pop rcx
00007f8fe1fda83b  pop rax
00007f8fe1fda83c  add rsp, 0x08
00007f8fe1fda840  jmp 0x00007F8FE1FD64A5
00007f8fe1fda845  sub rsp, 0x08
00007f8fe1fda849  push rax
00007f8fe1fda84a  push rcx
00007f8fe1fda84b  push rdx
00007f8fe1fda84c  push rdi
00007f8fe1fda84d  push rsi
00007f8fe1fda84e  push r8
00007f8fe1fda850  push r9
00007f8fe1fda852  push r10
00007f8fe1fda854  push r11
00007f8fe1fda856  sub rsp, 0xF0
00007f8fe1fda85d  vmovaps [rsp], xmm0
00007f8fe1fda862  vmovaps [rsp+0x10], xmm1
00007f8fe1fda868  vmovaps [rsp+0x20], xmm2
00007f8fe1fda86e  vmovaps [rsp+0x30], xmm3
00007f8fe1fda874  vmovaps [rsp+0x40], xmm4
00007f8fe1fda87a  vmovaps [rsp+0x50], xmm5
00007f8fe1fda880  vmovaps [rsp+0x60], xmm6
00007f8fe1fda886  vmovaps [rsp+0x70], xmm8
00007f8fe1fda88c  vmovaps [rsp+0x80], xmm9
00007f8fe1fda895  vmovaps [rsp+0x90], xmm10
00007f8fe1fda89e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fda8a7  vmovaps [rsp+0xB0], xmm12
00007f8fe1fda8b0  vmovaps [rsp+0xC0], xmm13
00007f8fe1fda8b9  vmovaps [rsp+0xD0], xmm14
00007f8fe1fda8c2  vmovaps [rsp+0xE0], xmm15
00007f8fe1fda8cb  sub rsp, 0x30
00007f8fe1fda8cf  movaps [rsp], xmm7
00007f8fe1fda8d3  movaps [rsp+0x10], xmm11
00007f8fe1fda8d9  movaps [rsp+0x20], xmm9
00007f8fe1fda8df  lea rdi, [rsp]
00007f8fe1fda8e3  mov esi, 0x00
00007f8fe1fda8e8  mov rax, 0x6020BB77F530
00007f8fe1fda8f2  call rax
00007f8fe1fda8f4  movaps xmm7, [rsp]
00007f8fe1fda8f8  add rsp, 0x30
00007f8fe1fda8fc  vmovaps xmm0, [rsp]
00007f8fe1fda901  vmovaps xmm1, [rsp+0x10]
00007f8fe1fda907  vmovaps xmm2, [rsp+0x20]
00007f8fe1fda90d  vmovaps xmm3, [rsp+0x30]
00007f8fe1fda913  vmovaps xmm4, [rsp+0x40]
00007f8fe1fda919  vmovaps xmm5, [rsp+0x50]
00007f8fe1fda91f  vmovaps xmm6, [rsp+0x60]
00007f8fe1fda925  vmovaps xmm8, [rsp+0x70]
00007f8fe1fda92b  vmovaps xmm9, [rsp+0x80]
00007f8fe1fda934  vmovaps xmm10, [rsp+0x90]
00007f8fe1fda93d  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fda946  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fda94f  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fda958  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fda961  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fda96a  add rsp, 0xF0
00007f8fe1fda971  pop r11
00007f8fe1fda973  pop r10
00007f8fe1fda975  pop r9
00007f8fe1fda977  pop r8
00007f8fe1fda979  pop rsi
00007f8fe1fda97a  pop rdi
00007f8fe1fda97b  pop rdx
00007f8fe1fda97c  pop rcx
00007f8fe1fda97d  pop rax
00007f8fe1fda97e  add rsp, 0x08
00007f8fe1fda982  jmp 0x00007F8FE1FD64D2
00007f8fe1fda987  sub rsp, 0x08
00007f8fe1fda98b  push rax
00007f8fe1fda98c  push rcx
00007f8fe1fda98d  push rdx
00007f8fe1fda98e  push rdi
00007f8fe1fda98f  push rsi
00007f8fe1fda990  push r8
00007f8fe1fda992  push r9
00007f8fe1fda994  push r10
00007f8fe1fda996  push r11
00007f8fe1fda998  sub rsp, 0xF0
00007f8fe1fda99f  vmovaps [rsp], xmm0
00007f8fe1fda9a4  vmovaps [rsp+0x10], xmm1
00007f8fe1fda9aa  vmovaps [rsp+0x20], xmm2
00007f8fe1fda9b0  vmovaps [rsp+0x30], xmm3
00007f8fe1fda9b6  vmovaps [rsp+0x40], xmm4
00007f8fe1fda9bc  vmovaps [rsp+0x50], xmm5
00007f8fe1fda9c2  vmovaps [rsp+0x60], xmm6
00007f8fe1fda9c8  vmovaps [rsp+0x70], xmm7
00007f8fe1fda9ce  vmovaps [rsp+0x80], xmm8
00007f8fe1fda9d7  vmovaps [rsp+0x90], xmm9
00007f8fe1fda9e0  vmovaps [rsp+0xA0], xmm10
00007f8fe1fda9e9  vmovaps [rsp+0xB0], xmm12
00007f8fe1fda9f2  vmovaps [rsp+0xC0], xmm13
00007f8fe1fda9fb  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdaa04  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdaa0d  sub rsp, 0x30
00007f8fe1fdaa11  movaps [rsp], xmm11
00007f8fe1fdaa16  movaps [rsp+0x10], xmm10
00007f8fe1fdaa1c  movaps [rsp+0x20], xmm14
00007f8fe1fdaa22  lea rdi, [rsp]
00007f8fe1fdaa26  mov esi, 0x00
00007f8fe1fdaa2b  mov rax, 0x6020BB77F530
00007f8fe1fdaa35  call rax
00007f8fe1fdaa37  movaps xmm11, [rsp]
00007f8fe1fdaa3c  add rsp, 0x30
00007f8fe1fdaa40  vmovaps xmm0, [rsp]
00007f8fe1fdaa45  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdaa4b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdaa51  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdaa57  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdaa5d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdaa63  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdaa69  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdaa6f  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdaa78  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdaa81  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdaa8a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdaa93  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdaa9c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdaaa5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdaaae  add rsp, 0xF0
00007f8fe1fdaab5  pop r11
00007f8fe1fdaab7  pop r10
00007f8fe1fdaab9  pop r9
00007f8fe1fdaabb  pop r8
00007f8fe1fdaabd  pop rsi
00007f8fe1fdaabe  pop rdi
00007f8fe1fdaabf  pop rdx
00007f8fe1fdaac0  pop rcx
00007f8fe1fdaac1  pop rax
00007f8fe1fdaac2  add rsp, 0x08
00007f8fe1fdaac6  jmp 0x00007F8FE1FD64ED
00007f8fe1fdaacb  call 0x00007F8FE1EE45A0
00007f8fe1fdaad0  jmp 0x00007F8FE1FD64F7
00007f8fe1fdaad5  sub rsp, 0x08
00007f8fe1fdaad9  push rax
00007f8fe1fdaada  push rcx
00007f8fe1fdaadb  push rdx
00007f8fe1fdaadc  push rdi
00007f8fe1fdaadd  push rsi
00007f8fe1fdaade  push r8
00007f8fe1fdaae0  push r9
00007f8fe1fdaae2  push r10
00007f8fe1fdaae4  push r11
00007f8fe1fdaae6  sub rsp, 0xF0
00007f8fe1fdaaed  vmovaps [rsp], xmm0
00007f8fe1fdaaf2  vmovaps [rsp+0x10], xmm1
00007f8fe1fdaaf8  vmovaps [rsp+0x20], xmm2
00007f8fe1fdaafe  vmovaps [rsp+0x30], xmm3
00007f8fe1fdab04  vmovaps [rsp+0x40], xmm4
00007f8fe1fdab0a  vmovaps [rsp+0x50], xmm5
00007f8fe1fdab10  vmovaps [rsp+0x60], xmm6
00007f8fe1fdab16  vmovaps [rsp+0x70], xmm7
00007f8fe1fdab1c  vmovaps [rsp+0x80], xmm8
00007f8fe1fdab25  vmovaps [rsp+0x90], xmm9
00007f8fe1fdab2e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdab37  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdab40  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdab49  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdab52  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdab5b  sub rsp, 0x30
00007f8fe1fdab5f  movaps [rsp], xmm10
00007f8fe1fdab64  movaps [rsp+0x10], xmm1
00007f8fe1fdab69  movaps [rsp+0x20], xmm12
00007f8fe1fdab6f  lea rdi, [rsp]
00007f8fe1fdab73  mov esi, 0x00
00007f8fe1fdab78  mov rax, 0x6020BB77F530
00007f8fe1fdab82  call rax
00007f8fe1fdab84  movaps xmm10, [rsp]
00007f8fe1fdab89  add rsp, 0x30
00007f8fe1fdab8d  vmovaps xmm0, [rsp]
00007f8fe1fdab92  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdab98  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdab9e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdaba4  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdabaa  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdabb0  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdabb6  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdabbc  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdabc5  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdabce  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdabd7  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdabe0  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdabe9  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdabf2  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdabfb  add rsp, 0xF0
00007f8fe1fdac02  pop r11
00007f8fe1fdac04  pop r10
00007f8fe1fdac06  pop r9
00007f8fe1fdac08  pop r8
00007f8fe1fdac0a  pop rsi
00007f8fe1fdac0b  pop rdi
00007f8fe1fdac0c  pop rdx
00007f8fe1fdac0d  pop rcx
00007f8fe1fdac0e  pop rax
00007f8fe1fdac0f  add rsp, 0x08
00007f8fe1fdac13  jmp 0x00007F8FE1FD651A
00007f8fe1fdac18  sub rsp, 0x08
00007f8fe1fdac1c  push rax
00007f8fe1fdac1d  push rcx
00007f8fe1fdac1e  push rdx
00007f8fe1fdac1f  push rdi
00007f8fe1fdac20  push rsi
00007f8fe1fdac21  push r8
00007f8fe1fdac23  push r9
00007f8fe1fdac25  push r10
00007f8fe1fdac27  push r11
00007f8fe1fdac29  sub rsp, 0xF0
00007f8fe1fdac30  vmovaps [rsp], xmm0
00007f8fe1fdac35  vmovaps [rsp+0x10], xmm1
00007f8fe1fdac3b  vmovaps [rsp+0x20], xmm2
00007f8fe1fdac41  vmovaps [rsp+0x30], xmm3
00007f8fe1fdac47  vmovaps [rsp+0x40], xmm4
00007f8fe1fdac4d  vmovaps [rsp+0x50], xmm5
00007f8fe1fdac53  vmovaps [rsp+0x60], xmm6
00007f8fe1fdac59  vmovaps [rsp+0x70], xmm7
00007f8fe1fdac5f  vmovaps [rsp+0x80], xmm8
00007f8fe1fdac68  vmovaps [rsp+0x90], xmm9
00007f8fe1fdac71  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdac7a  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdac83  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdac8c  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdac95  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdac9e  sub rsp, 0x30
00007f8fe1fdaca2  movaps [rsp], xmm12
00007f8fe1fdaca7  movaps [rsp+0x10], xmm14
00007f8fe1fdacad  movaps [rsp+0x20], xmm1
00007f8fe1fdacb2  lea rdi, [rsp]
00007f8fe1fdacb6  mov esi, 0x00
00007f8fe1fdacbb  mov rax, 0x6020BB77F530
00007f8fe1fdacc5  call rax
00007f8fe1fdacc7  movaps xmm12, [rsp]
00007f8fe1fdaccc  add rsp, 0x30
00007f8fe1fdacd0  vmovaps xmm0, [rsp]
00007f8fe1fdacd5  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdacdb  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdace1  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdace7  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdaced  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdacf3  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdacf9  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdacff  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdad08  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdad11  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdad1a  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdad23  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdad2c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdad35  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdad3e  add rsp, 0xF0
00007f8fe1fdad45  pop r11
00007f8fe1fdad47  pop r10
00007f8fe1fdad49  pop r9
00007f8fe1fdad4b  pop r8
00007f8fe1fdad4d  pop rsi
00007f8fe1fdad4e  pop rdi
00007f8fe1fdad4f  pop rdx
00007f8fe1fdad50  pop rcx
00007f8fe1fdad51  pop rax
00007f8fe1fdad52  add rsp, 0x08
00007f8fe1fdad56  jmp 0x00007F8FE1FD6549
00007f8fe1fdad5b  sub rsp, 0x08
00007f8fe1fdad5f  push rax
00007f8fe1fdad60  push rcx
00007f8fe1fdad61  push rdx
00007f8fe1fdad62  push rdi
00007f8fe1fdad63  push rsi
00007f8fe1fdad64  push r8
00007f8fe1fdad66  push r9
00007f8fe1fdad68  push r10
00007f8fe1fdad6a  push r11
00007f8fe1fdad6c  sub rsp, 0xF0
00007f8fe1fdad73  vmovaps [rsp], xmm0
00007f8fe1fdad78  vmovaps [rsp+0x10], xmm1
00007f8fe1fdad7e  vmovaps [rsp+0x20], xmm2
00007f8fe1fdad84  vmovaps [rsp+0x30], xmm3
00007f8fe1fdad8a  vmovaps [rsp+0x40], xmm4
00007f8fe1fdad90  vmovaps [rsp+0x50], xmm5
00007f8fe1fdad96  vmovaps [rsp+0x60], xmm6
00007f8fe1fdad9c  vmovaps [rsp+0x70], xmm7
00007f8fe1fdada2  vmovaps [rsp+0x80], xmm8
00007f8fe1fdadab  vmovaps [rsp+0x90], xmm9
00007f8fe1fdadb4  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdadbd  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdadc6  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdadcf  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdadd8  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdade1  sub rsp, 0x30
00007f8fe1fdade5  movaps [rsp], xmm14
00007f8fe1fdadea  movaps [rsp+0x10], xmm9
00007f8fe1fdadf0  movaps [rsp+0x20], xmm1
00007f8fe1fdadf5  lea rdi, [rsp]
00007f8fe1fdadf9  mov esi, 0x00
00007f8fe1fdadfe  mov rax, 0x6020BB77F530
00007f8fe1fdae08  call rax
00007f8fe1fdae0a  movaps xmm14, [rsp]
00007f8fe1fdae0f  add rsp, 0x30
00007f8fe1fdae13  vmovaps xmm0, [rsp]
00007f8fe1fdae18  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdae1e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdae24  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdae2a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdae30  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdae36  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdae3c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdae42  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdae4b  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdae54  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdae5d  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdae66  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdae6f  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdae78  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdae81  add rsp, 0xF0
00007f8fe1fdae88  pop r11
00007f8fe1fdae8a  pop r10
00007f8fe1fdae8c  pop r9
00007f8fe1fdae8e  pop r8
00007f8fe1fdae90  pop rsi
00007f8fe1fdae91  pop rdi
00007f8fe1fdae92  pop rdx
00007f8fe1fdae93  pop rcx
00007f8fe1fdae94  pop rax
00007f8fe1fdae95  add rsp, 0x08
00007f8fe1fdae99  jmp 0x00007F8FE1FD6578
00007f8fe1fdae9e  sub rsp, 0x08
00007f8fe1fdaea2  push rax
00007f8fe1fdaea3  push rcx
00007f8fe1fdaea4  push rdx
00007f8fe1fdaea5  push rdi
00007f8fe1fdaea6  push rsi
00007f8fe1fdaea7  push r8
00007f8fe1fdaea9  push r9
00007f8fe1fdaeab  push r10
00007f8fe1fdaead  push r11
00007f8fe1fdaeaf  sub rsp, 0xF0
00007f8fe1fdaeb6  vmovaps [rsp], xmm0
00007f8fe1fdaebb  vmovaps [rsp+0x10], xmm2
00007f8fe1fdaec1  vmovaps [rsp+0x20], xmm3
00007f8fe1fdaec7  vmovaps [rsp+0x30], xmm4
00007f8fe1fdaecd  vmovaps [rsp+0x40], xmm5
00007f8fe1fdaed3  vmovaps [rsp+0x50], xmm6
00007f8fe1fdaed9  vmovaps [rsp+0x60], xmm7
00007f8fe1fdaedf  vmovaps [rsp+0x70], xmm8
00007f8fe1fdaee5  vmovaps [rsp+0x80], xmm9
00007f8fe1fdaeee  vmovaps [rsp+0x90], xmm10
00007f8fe1fdaef7  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdaf00  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdaf09  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdaf12  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdaf1b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdaf24  sub rsp, 0x30
00007f8fe1fdaf28  movaps [rsp], xmm1
00007f8fe1fdaf2c  movaps [rsp+0x10], xmm13
00007f8fe1fdaf32  movaps [rsp+0x20], xmm8
00007f8fe1fdaf38  lea rdi, [rsp]
00007f8fe1fdaf3c  mov esi, 0x00
00007f8fe1fdaf41  mov rax, 0x6020BB77F530
00007f8fe1fdaf4b  call rax
00007f8fe1fdaf4d  movaps xmm1, [rsp]
00007f8fe1fdaf51  add rsp, 0x30
00007f8fe1fdaf55  vmovaps xmm0, [rsp]
00007f8fe1fdaf5a  vmovaps xmm2, [rsp+0x10]
00007f8fe1fdaf60  vmovaps xmm3, [rsp+0x20]
00007f8fe1fdaf66  vmovaps xmm4, [rsp+0x30]
00007f8fe1fdaf6c  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdaf72  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdaf78  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdaf7e  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdaf84  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdaf8d  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdaf96  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdaf9f  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdafa8  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdafb1  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdafba  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdafc3  add rsp, 0xF0
00007f8fe1fdafca  pop r11
00007f8fe1fdafcc  pop r10
00007f8fe1fdafce  pop r9
00007f8fe1fdafd0  pop r8
00007f8fe1fdafd2  pop rsi
00007f8fe1fdafd3  pop rdi
00007f8fe1fdafd4  pop rdx
00007f8fe1fdafd5  pop rcx
00007f8fe1fdafd6  pop rax
00007f8fe1fdafd7  add rsp, 0x08
00007f8fe1fdafdb  jmp 0x00007F8FE1FD659A
00007f8fe1fdafe0  call 0x00007F8FE1E0C260
00007f8fe1fdafe5  jmp 0x00007F8FE1FD65A8
00007f8fe1fdafea  call 0x00007F8FE1EDE950
00007f8fe1fdafef  jmp 0x00007F8FE1FD65B2
00007f8fe1fdaff4  sub rsp, 0x08
00007f8fe1fdaff8  push rax
00007f8fe1fdaff9  push rcx
00007f8fe1fdaffa  push rdx
00007f8fe1fdaffb  push rdi
00007f8fe1fdaffc  push rsi
00007f8fe1fdaffd  push r8
00007f8fe1fdafff  push r9
00007f8fe1fdb001  push r10
00007f8fe1fdb003  push r11
00007f8fe1fdb005  sub rsp, 0xF0
00007f8fe1fdb00c  vmovaps [rsp], xmm0
00007f8fe1fdb011  vmovaps [rsp+0x10], xmm1
00007f8fe1fdb017  vmovaps [rsp+0x20], xmm2
00007f8fe1fdb01d  vmovaps [rsp+0x30], xmm3
00007f8fe1fdb023  vmovaps [rsp+0x40], xmm4
00007f8fe1fdb029  vmovaps [rsp+0x50], xmm5
00007f8fe1fdb02f  vmovaps [rsp+0x60], xmm6
00007f8fe1fdb035  vmovaps [rsp+0x70], xmm7
00007f8fe1fdb03b  vmovaps [rsp+0x80], xmm9
00007f8fe1fdb044  vmovaps [rsp+0x90], xmm10
00007f8fe1fdb04d  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdb056  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdb05f  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdb068  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdb071  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdb07a  sub rsp, 0x30
00007f8fe1fdb07e  movaps [rsp], xmm8
00007f8fe1fdb083  movaps [rsp+0x10], xmm15
00007f8fe1fdb089  movaps [rsp+0x20], xmm7
00007f8fe1fdb08e  lea rdi, [rsp]
00007f8fe1fdb092  mov esi, 0x00
00007f8fe1fdb097  mov rax, 0x6020BB77F530
00007f8fe1fdb0a1  call rax
00007f8fe1fdb0a3  movaps xmm8, [rsp]
00007f8fe1fdb0a8  add rsp, 0x30
00007f8fe1fdb0ac  vmovaps xmm0, [rsp]
00007f8fe1fdb0b1  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdb0b7  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdb0bd  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdb0c3  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdb0c9  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdb0cf  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdb0d5  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdb0db  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdb0e4  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdb0ed  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdb0f6  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdb0ff  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdb108  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdb111  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdb11a  add rsp, 0xF0
00007f8fe1fdb121  pop r11
00007f8fe1fdb123  pop r10
00007f8fe1fdb125  pop r9
00007f8fe1fdb127  pop r8
00007f8fe1fdb129  pop rsi
00007f8fe1fdb12a  pop rdi
00007f8fe1fdb12b  pop rdx
00007f8fe1fdb12c  pop rcx
00007f8fe1fdb12d  pop rax
00007f8fe1fdb12e  add rsp, 0x08
00007f8fe1fdb132  jmp 0x00007F8FE1FD65D4
00007f8fe1fdb137  sub rsp, 0x08
00007f8fe1fdb13b  push rax
00007f8fe1fdb13c  push rcx
00007f8fe1fdb13d  push rdx
00007f8fe1fdb13e  push rdi
00007f8fe1fdb13f  push rsi
00007f8fe1fdb140  push r8
00007f8fe1fdb142  push r9
00007f8fe1fdb144  push r10
00007f8fe1fdb146  push r11
00007f8fe1fdb148  sub rsp, 0xF0
00007f8fe1fdb14f  vmovaps [rsp], xmm0
00007f8fe1fdb154  vmovaps [rsp+0x10], xmm1
00007f8fe1fdb15a  vmovaps [rsp+0x20], xmm2
00007f8fe1fdb160  vmovaps [rsp+0x30], xmm3
00007f8fe1fdb166  vmovaps [rsp+0x40], xmm4
00007f8fe1fdb16c  vmovaps [rsp+0x50], xmm5
00007f8fe1fdb172  vmovaps [rsp+0x60], xmm6
00007f8fe1fdb178  vmovaps [rsp+0x70], xmm8
00007f8fe1fdb17e  vmovaps [rsp+0x80], xmm9
00007f8fe1fdb187  vmovaps [rsp+0x90], xmm10
00007f8fe1fdb190  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdb199  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdb1a2  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdb1ab  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdb1b4  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdb1bd  sub rsp, 0x30
00007f8fe1fdb1c1  movaps [rsp], xmm7
00007f8fe1fdb1c5  movaps [rsp+0x10], xmm9
00007f8fe1fdb1cb  movaps [rsp+0x20], xmm15
00007f8fe1fdb1d1  lea rdi, [rsp]
00007f8fe1fdb1d5  mov esi, 0x00
00007f8fe1fdb1da  mov rax, 0x6020BB77F530
00007f8fe1fdb1e4  call rax
00007f8fe1fdb1e6  movaps xmm7, [rsp]
00007f8fe1fdb1ea  add rsp, 0x30
00007f8fe1fdb1ee  vmovaps xmm0, [rsp]
00007f8fe1fdb1f3  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdb1f9  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdb1ff  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdb205  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdb20b  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdb211  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdb217  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdb21d  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdb226  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdb22f  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdb238  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdb241  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdb24a  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdb253  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdb25c  add rsp, 0xF0
00007f8fe1fdb263  pop r11
00007f8fe1fdb265  pop r10
00007f8fe1fdb267  pop r9
00007f8fe1fdb269  pop r8
00007f8fe1fdb26b  pop rsi
00007f8fe1fdb26c  pop rdi
00007f8fe1fdb26d  pop rdx
00007f8fe1fdb26e  pop rcx
00007f8fe1fdb26f  pop rax
00007f8fe1fdb270  add rsp, 0x08
00007f8fe1fdb274  jmp 0x00007F8FE1FD6601
00007f8fe1fdb279  sub rsp, 0x08
00007f8fe1fdb27d  push rax
00007f8fe1fdb27e  push rcx
00007f8fe1fdb27f  push rdx
00007f8fe1fdb280  push rdi
00007f8fe1fdb281  push rsi
00007f8fe1fdb282  push r8
00007f8fe1fdb284  push r9
00007f8fe1fdb286  push r10
00007f8fe1fdb288  push r11
00007f8fe1fdb28a  sub rsp, 0xF0
00007f8fe1fdb291  vmovaps [rsp], xmm0
00007f8fe1fdb296  vmovaps [rsp+0x10], xmm1
00007f8fe1fdb29c  vmovaps [rsp+0x20], xmm2
00007f8fe1fdb2a2  vmovaps [rsp+0x30], xmm3
00007f8fe1fdb2a8  vmovaps [rsp+0x40], xmm4
00007f8fe1fdb2ae  vmovaps [rsp+0x50], xmm5
00007f8fe1fdb2b4  vmovaps [rsp+0x60], xmm6
00007f8fe1fdb2ba  vmovaps [rsp+0x70], xmm7
00007f8fe1fdb2c0  vmovaps [rsp+0x80], xmm8
00007f8fe1fdb2c9  vmovaps [rsp+0x90], xmm10
00007f8fe1fdb2d2  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdb2db  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdb2e4  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdb2ed  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdb2f6  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdb2ff  sub rsp, 0x30
00007f8fe1fdb303  movaps [rsp], xmm9
00007f8fe1fdb308  movaps [rsp+0x10], xmm13
00007f8fe1fdb30e  movaps [rsp+0x20], xmm15
00007f8fe1fdb314  lea rdi, [rsp]
00007f8fe1fdb318  mov esi, 0x00
00007f8fe1fdb31d  mov rax, 0x6020BB77F530
00007f8fe1fdb327  call rax
00007f8fe1fdb329  movaps xmm9, [rsp]
00007f8fe1fdb32e  add rsp, 0x30
00007f8fe1fdb332  vmovaps xmm0, [rsp]
00007f8fe1fdb337  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdb33d  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdb343  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdb349  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdb34f  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdb355  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdb35b  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdb361  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdb36a  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdb373  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdb37c  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdb385  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdb38e  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdb397  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdb3a0  add rsp, 0xF0
00007f8fe1fdb3a7  pop r11
00007f8fe1fdb3a9  pop r10
00007f8fe1fdb3ab  pop r9
00007f8fe1fdb3ad  pop r8
00007f8fe1fdb3af  pop rsi
00007f8fe1fdb3b0  pop rdi
00007f8fe1fdb3b1  pop rdx
00007f8fe1fdb3b2  pop rcx
00007f8fe1fdb3b3  pop rax
00007f8fe1fdb3b4  add rsp, 0x08
00007f8fe1fdb3b8  jmp 0x00007F8FE1FD662F
00007f8fe1fdb3bd  sub rsp, 0x08
00007f8fe1fdb3c1  push rax
00007f8fe1fdb3c2  push rcx
00007f8fe1fdb3c3  push rdx
00007f8fe1fdb3c4  push rdi
00007f8fe1fdb3c5  push rsi
00007f8fe1fdb3c6  push r8
00007f8fe1fdb3c8  push r9
00007f8fe1fdb3ca  push r10
00007f8fe1fdb3cc  push r11
00007f8fe1fdb3ce  sub rsp, 0xF0
00007f8fe1fdb3d5  vmovaps [rsp], xmm0
00007f8fe1fdb3da  vmovaps [rsp+0x10], xmm1
00007f8fe1fdb3e0  vmovaps [rsp+0x20], xmm2
00007f8fe1fdb3e6  vmovaps [rsp+0x30], xmm3
00007f8fe1fdb3ec  vmovaps [rsp+0x40], xmm4
00007f8fe1fdb3f2  vmovaps [rsp+0x50], xmm5
00007f8fe1fdb3f8  vmovaps [rsp+0x60], xmm6
00007f8fe1fdb3fe  vmovaps [rsp+0x70], xmm7
00007f8fe1fdb404  vmovaps [rsp+0x80], xmm8
00007f8fe1fdb40d  vmovaps [rsp+0x90], xmm9
00007f8fe1fdb416  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdb41f  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdb428  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdb431  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdb43a  vmovaps [rsp+0xE0], xmm14
00007f8fe1fdb443  sub rsp, 0x30
00007f8fe1fdb447  movaps [rsp], xmm15
00007f8fe1fdb44c  movaps [rsp+0x10], xmm11
00007f8fe1fdb452  movaps [rsp+0x20], xmm12
00007f8fe1fdb458  lea rdi, [rsp]
00007f8fe1fdb45c  mov esi, 0x00
00007f8fe1fdb461  mov rax, 0x6020BB77F530
00007f8fe1fdb46b  call rax
00007f8fe1fdb46d  movaps xmm15, [rsp]
00007f8fe1fdb472  add rsp, 0x30
00007f8fe1fdb476  vmovaps xmm0, [rsp]
00007f8fe1fdb47b  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdb481  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdb487  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdb48d  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdb493  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdb499  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdb49f  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdb4a5  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdb4ae  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdb4b7  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdb4c0  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdb4c9  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdb4d2  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdb4db  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fdb4e4  add rsp, 0xF0
00007f8fe1fdb4eb  pop r11
00007f8fe1fdb4ed  pop r10
00007f8fe1fdb4ef  pop r9
00007f8fe1fdb4f1  pop r8
00007f8fe1fdb4f3  pop rsi
00007f8fe1fdb4f4  pop rdi
00007f8fe1fdb4f5  pop rdx
00007f8fe1fdb4f6  pop rcx
00007f8fe1fdb4f7  pop rax
00007f8fe1fdb4f8  add rsp, 0x08
00007f8fe1fdb4fc  jmp 0x00007F8FE1FD664A
00007f8fe1fdb501  sub rsp, 0x08
00007f8fe1fdb505  push rax
00007f8fe1fdb506  push rcx
00007f8fe1fdb507  push rdx
00007f8fe1fdb508  push rdi
00007f8fe1fdb509  push rsi
00007f8fe1fdb50a  push r8
00007f8fe1fdb50c  push r9
00007f8fe1fdb50e  push r10
00007f8fe1fdb510  push r11
00007f8fe1fdb512  sub rsp, 0xF0
00007f8fe1fdb519  vmovaps [rsp], xmm0
00007f8fe1fdb51e  vmovaps [rsp+0x10], xmm1
00007f8fe1fdb524  vmovaps [rsp+0x20], xmm2
00007f8fe1fdb52a  vmovaps [rsp+0x30], xmm3
00007f8fe1fdb530  vmovaps [rsp+0x40], xmm4
00007f8fe1fdb536  vmovaps [rsp+0x50], xmm5
00007f8fe1fdb53c  vmovaps [rsp+0x60], xmm6
00007f8fe1fdb542  vmovaps [rsp+0x70], xmm7
00007f8fe1fdb548  vmovaps [rsp+0x80], xmm8
00007f8fe1fdb551  vmovaps [rsp+0x90], xmm9
00007f8fe1fdb55a  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdb563  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdb56c  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdb575  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdb57e  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdb587  sub rsp, 0x30
00007f8fe1fdb58b  movaps [rsp], xmm13
00007f8fe1fdb590  movaps [rsp+0x10], xmm10
00007f8fe1fdb596  movaps [rsp+0x20], xmm14
00007f8fe1fdb59c  lea rdi, [rsp]
00007f8fe1fdb5a0  mov esi, 0x00
00007f8fe1fdb5a5  mov rax, 0x6020BB77F530
00007f8fe1fdb5af  call rax
00007f8fe1fdb5b1  movaps xmm13, [rsp]
00007f8fe1fdb5b6  add rsp, 0x30
00007f8fe1fdb5ba  vmovaps xmm0, [rsp]
00007f8fe1fdb5bf  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdb5c5  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdb5cb  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdb5d1  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdb5d7  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdb5dd  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdb5e3  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdb5e9  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdb5f2  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdb5fb  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdb604  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdb60d  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdb616  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdb61f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdb628  add rsp, 0xF0
00007f8fe1fdb62f  pop r11
00007f8fe1fdb631  pop r10
00007f8fe1fdb633  pop r9
00007f8fe1fdb635  pop r8
00007f8fe1fdb637  pop rsi
00007f8fe1fdb638  pop rdi
00007f8fe1fdb639  pop rdx
00007f8fe1fdb63a  pop rcx
00007f8fe1fdb63b  pop rax
00007f8fe1fdb63c  add rsp, 0x08
00007f8fe1fdb640  jmp 0x00007F8FE1FD666D
00007f8fe1fdb645  sub rsp, 0x08
00007f8fe1fdb649  push rax
00007f8fe1fdb64a  push rcx
00007f8fe1fdb64b  push rdx
00007f8fe1fdb64c  push rdi
00007f8fe1fdb64d  push rsi
00007f8fe1fdb64e  push r8
00007f8fe1fdb650  push r9
00007f8fe1fdb652  push r10
00007f8fe1fdb654  push r11
00007f8fe1fdb656  sub rsp, 0xF0
00007f8fe1fdb65d  vmovaps [rsp], xmm0
00007f8fe1fdb662  vmovaps [rsp+0x10], xmm1
00007f8fe1fdb668  vmovaps [rsp+0x20], xmm2
00007f8fe1fdb66e  vmovaps [rsp+0x30], xmm3
00007f8fe1fdb674  vmovaps [rsp+0x40], xmm4
00007f8fe1fdb67a  vmovaps [rsp+0x50], xmm5
00007f8fe1fdb680  vmovaps [rsp+0x60], xmm6
00007f8fe1fdb686  vmovaps [rsp+0x70], xmm7
00007f8fe1fdb68c  vmovaps [rsp+0x80], xmm8
00007f8fe1fdb695  vmovaps [rsp+0x90], xmm9
00007f8fe1fdb69e  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdb6a7  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdb6b0  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdb6b9  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdb6c2  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdb6cb  sub rsp, 0x30
00007f8fe1fdb6cf  movaps [rsp], xmm14
00007f8fe1fdb6d4  movaps [rsp+0x10], xmm1
00007f8fe1fdb6d9  movaps [rsp+0x20], xmm7
00007f8fe1fdb6de  lea rdi, [rsp]
00007f8fe1fdb6e2  mov esi, 0x00
00007f8fe1fdb6e7  mov rax, 0x6020BB77F530
00007f8fe1fdb6f1  call rax
00007f8fe1fdb6f3  movaps xmm14, [rsp]
00007f8fe1fdb6f8  add rsp, 0x30
00007f8fe1fdb6fc  vmovaps xmm0, [rsp]
00007f8fe1fdb701  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdb707  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdb70d  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdb713  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdb719  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdb71f  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdb725  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdb72b  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdb734  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdb73d  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdb746  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdb74f  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdb758  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdb761  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdb76a  add rsp, 0xF0
00007f8fe1fdb771  pop r11
00007f8fe1fdb773  pop r10
00007f8fe1fdb775  pop r9
00007f8fe1fdb777  pop r8
00007f8fe1fdb779  pop rsi
00007f8fe1fdb77a  pop rdi
00007f8fe1fdb77b  pop rdx
00007f8fe1fdb77c  pop rcx
00007f8fe1fdb77d  pop rax
00007f8fe1fdb77e  add rsp, 0x08
00007f8fe1fdb782  jmp 0x00007F8FE1FD6690
00007f8fe1fdb787  sub rsp, 0x08
00007f8fe1fdb78b  push rax
00007f8fe1fdb78c  push rcx
00007f8fe1fdb78d  push rdx
00007f8fe1fdb78e  push rdi
00007f8fe1fdb78f  push rsi
00007f8fe1fdb790  push r8
00007f8fe1fdb792  push r9
00007f8fe1fdb794  push r10
00007f8fe1fdb796  push r11
00007f8fe1fdb798  sub rsp, 0xF0
00007f8fe1fdb79f  vmovaps [rsp], xmm0
00007f8fe1fdb7a4  vmovaps [rsp+0x10], xmm2
00007f8fe1fdb7aa  vmovaps [rsp+0x20], xmm3
00007f8fe1fdb7b0  vmovaps [rsp+0x30], xmm4
00007f8fe1fdb7b6  vmovaps [rsp+0x40], xmm5
00007f8fe1fdb7bc  vmovaps [rsp+0x50], xmm6
00007f8fe1fdb7c2  vmovaps [rsp+0x60], xmm7
00007f8fe1fdb7c8  vmovaps [rsp+0x70], xmm8
00007f8fe1fdb7ce  vmovaps [rsp+0x80], xmm9
00007f8fe1fdb7d7  vmovaps [rsp+0x90], xmm10
00007f8fe1fdb7e0  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdb7e9  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdb7f2  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdb7fb  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdb804  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdb80d  sub rsp, 0x30
00007f8fe1fdb811  movaps [rsp], xmm1
00007f8fe1fdb815  movaps [rsp+0x10], xmm8
00007f8fe1fdb81b  movaps [rsp+0x20], xmm9
00007f8fe1fdb821  lea rdi, [rsp]
00007f8fe1fdb825  mov esi, 0x00
00007f8fe1fdb82a  mov rax, 0x6020BB77F530
00007f8fe1fdb834  call rax
00007f8fe1fdb836  movaps xmm1, [rsp]
00007f8fe1fdb83a  add rsp, 0x30
00007f8fe1fdb83e  vmovaps xmm0, [rsp]
00007f8fe1fdb843  vmovaps xmm2, [rsp+0x10]
00007f8fe1fdb849  vmovaps xmm3, [rsp+0x20]
00007f8fe1fdb84f  vmovaps xmm4, [rsp+0x30]
00007f8fe1fdb855  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdb85b  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdb861  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdb867  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdb86d  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdb876  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdb87f  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdb888  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdb891  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdb89a  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdb8a3  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdb8ac  add rsp, 0xF0
00007f8fe1fdb8b3  pop r11
00007f8fe1fdb8b5  pop r10
00007f8fe1fdb8b7  pop r9
00007f8fe1fdb8b9  pop r8
00007f8fe1fdb8bb  pop rsi
00007f8fe1fdb8bc  pop rdi
00007f8fe1fdb8bd  pop rdx
00007f8fe1fdb8be  pop rcx
00007f8fe1fdb8bf  pop rax
00007f8fe1fdb8c0  add rsp, 0x08
00007f8fe1fdb8c4  jmp 0x00007F8FE1FD66B2
00007f8fe1fdb8c9  call 0x00007F8FE1EB3E40
00007f8fe1fdb8ce  jmp 0x00007F8FE1FD66C0
00007f8fe1fdb8d3  call 0x00007F8FE1E0C380
00007f8fe1fdb8d8  jmp 0x00007F8FE1FD66CA
00007f8fe1fdb8dd  call 0x00007F8FE1E0D600
00007f8fe1fdb8e2  jmp 0x00007F8FE1FD66D4
00007f8fe1fdb8e7  call 0x00007F8FE1DFF540
00007f8fe1fdb8ec  jmp 0x00007F8FE1FD66DE
00007f8fe1fdb8f1  int3
00007f8fe1fdb8f2  nop [rax+rax*1], ax
00007f8fe1fdb8fb  nop [rax+rax*1], eax
00007f8fe1fdb900  mov eax, [r15+0x48]
00007f8fe1fdb904  lea r14d, [eax+0x01]
00007f8fe1fdb909  mov [rsp+0x10], r14d
00007f8fe1fdb90e  mov r14d, r14d
00007f8fe1fdb911  mov [r15+0x48], r14
00007f8fe1fdb915  xor eax, eax
00007f8fe1fdb917  mov r14d, [rsp+0x10]
00007f8fe1fdb91c  cmp r14d, 0x1F4
00007f8fe1fdb923  cmc
00007f8fe1fdb924  lahf
00007f8fe1fdb925  seto al
00007f8fe1fdb928  mov [r15+0x108], eax
00007f8fe1fdb92f  mov eax, [r15+0x108]
00007f8fe1fdb936  sahf
00007f8fe1fdb937  jnz 0x00007F8FE1FDB969
00007f8fe1fdb939  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fdb941  jz 0x00007F8FE1FE1AB0
00007f8fe1fdb947  nop [rax+rax*1], ax
00007f8fe1fdb950  nop [rax+rax*1], eax
00007f8fe1fdb958  mov eax, 0x410450
00007f8fe1fdb95d  mov [r15+0x100], rax
00007f8fe1fdb964  jmp 0x00007F8FE1DFE110
00007f8fe1fdb969  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fdb971  jz 0x00007F8FE1FDB9A0
00007f8fe1fdb977  nop [rax+rax*1], ax
00007f8fe1fdb980  nop [rax+rax*1], eax
00007f8fe1fdb988  mov eax, 0x410274
00007f8fe1fdb98d  mov [r15+0x100], rax
00007f8fe1fdb994  jmp 0x00007F8FE1DFE110
00007f8fe1fdb999  int3
00007f8fe1fdb99a  int3
00007f8fe1fdb99b  nop [rax+rax*1], eax
00007f8fe1fdb9a0  mov rax, [r15+0x40]
00007f8fe1fdb9a4  movaps xmm1, [r15+0x1D0]
00007f8fe1fdb9ac  vmovaps [rsp+0x10], xmm1
00007f8fe1fdb9b2  vmovaps xmm15, [rsp+0x10]
00007f8fe1fdb9b8  por xmm1, xmm15
00007f8fe1fdb9bd  movaps xmm14, [r15+0x1A0]
00007f8fe1fdb9c5  vmovaps [rsp+0x10], xmm14
00007f8fe1fdb9cb  vmovaps xmm13, [rsp+0x10]
00007f8fe1fdb9d1  por xmm14, xmm13
00007f8fe1fdb9d6  lea r14, [rax+0x30]
00007f8fe1fdb9da  mov r12, [r13+r14*1]
00007f8fe1fdb9df  lea r14, [rax+0x38]
00007f8fe1fdb9e3  mov r11, [r13+r14*1]
00007f8fe1fdb9e8  movq xmm13, r12
00007f8fe1fdb9ed  movq xmm12, r11
00007f8fe1fdb9f2  movq xmm13, xmm13
00007f8fe1fdb9f7  vmovaps [rsp+0x10], xmm13
00007f8fe1fdb9fd  movq xmm13, xmm13
00007f8fe1fdba02  movaps [r15+0x130], xmm13
00007f8fe1fdba0a  movq xmm12, xmm12
00007f8fe1fdba0f  vmovaps [rsp+0x20], xmm12
00007f8fe1fdba15  movq xmm12, xmm12
00007f8fe1fdba1a  movaps [r15+0x280], xmm12
00007f8fe1fdba22  movaps xmm13, [r15+0x270]
00007f8fe1fdba2a  vmovaps [rsp+0x30], xmm13
00007f8fe1fdba30  vmovaps xmm12, [rsp+0x30]
00007f8fe1fdba36  por xmm13, xmm12
00007f8fe1fdba3b  lea r14, [rax+0x20]
00007f8fe1fdba3f  mov r12, [r13+r14*1]
00007f8fe1fdba44  lea r14, [rax+0x28]
00007f8fe1fdba48  mov r11, [r13+r14*1]
00007f8fe1fdba4d  movq xmm12, r12
00007f8fe1fdba52  movq xmm11, r11
00007f8fe1fdba57  movq xmm12, xmm12
00007f8fe1fdba5c  vmovaps [rsp+0x30], xmm12
00007f8fe1fdba62  movq xmm12, xmm12
00007f8fe1fdba67  movaps [r15+0x150], xmm12
00007f8fe1fdba6f  movq xmm11, xmm11
00007f8fe1fdba74  vmovaps [rsp+0x40], xmm11
00007f8fe1fdba7a  movq xmm11, xmm11
00007f8fe1fdba7f  movaps [r15+0x140], xmm11
00007f8fe1fdba87  lea r14, [rax+0x10]
00007f8fe1fdba8b  mov r12, [r13+r14*1]
00007f8fe1fdba90  lea r14, [rax+0x18]
00007f8fe1fdba94  mov r11, [r13+r14*1]
00007f8fe1fdba99  movq xmm12, r12
00007f8fe1fdba9e  movq xmm11, r11
00007f8fe1fdbaa3  movq xmm12, xmm12
00007f8fe1fdbaa8  vmovaps [rsp+0x50], xmm12
00007f8fe1fdbaae  movq xmm12, xmm12
00007f8fe1fdbab3  movaps [r15+0x170], xmm12
00007f8fe1fdbabb  movq xmm11, xmm11
00007f8fe1fdbac0  vmovaps [rsp+0x60], xmm11
00007f8fe1fdbac6  movq xmm11, xmm11
00007f8fe1fdbacb  movaps [r15+0x160], xmm11
00007f8fe1fdbad3  mov r14, [r13+rax*1]
00007f8fe1fdbad8  vmovq xmm12, r14
00007f8fe1fdbadd  vpbroadcastq xmm12, xmm12
00007f8fe1fdbae2  lea r14, [rax+0x08]
00007f8fe1fdbae6  mov rax, [r13+r14*1]
00007f8fe1fdbaeb  movq xmm11, rax
00007f8fe1fdbaf0  movaps [r15+0x230], xmm11
00007f8fe1fdbaf8  mov rax, [r15+0xF8]
00007f8fe1fdbaff  lea r14, [rax+0x50]
00007f8fe1fdbb03  movups xmm11, [r13+r14*1]
00007f8fe1fdbb09  lea r14, [rax+0x60]
00007f8fe1fdbb0d  movups xmm10, [r13+r14*1]
00007f8fe1fdbb13  lea r14, [rax+0x30]
00007f8fe1fdbb17  movups xmm9, [r13+r14*1]
00007f8fe1fdbb1d  mov r14, [r15+0x50]
00007f8fe1fdbb21  mov [r15+0x60], r14
00007f8fe1fdbb25  mov qword ptr [r15+0x58], 0x40
00007f8fe1fdbb2d  movaps xmm8, xmm12
00007f8fe1fdbb31  mulpd xmm8, xmm15
00007f8fe1fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007f8fe1fdbb3c  ptest xmm7, xmm7
00007f8fe1fdbb41  jnz 0x00007F8FE1FDC96A
00007f8fe1fdbb47  movq xmm15, qword ptr [r15+0x230]
00007f8fe1fdbb50  vmovaps [rsp+0x70], xmm15
00007f8fe1fdbb56  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fdbb5c  movaps xmm7, xmm9
00007f8fe1fdbb60  mulpd xmm7, xmm15
00007f8fe1fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007f8fe1fdbb6a  ptest xmm6, xmm6
00007f8fe1fdbb6f  jnz 0x00007F8FE1FDCAAE
00007f8fe1fdbb75  vxorps xmm15, xmm15, xmm15
00007f8fe1fdbb7a  vpbroadcastq xmm15, xmm15
00007f8fe1fdbb7f  movaps xmm9, xmm12
00007f8fe1fdbb83  mulpd xmm9, xmm10
00007f8fe1fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007f8fe1fdbb8e  ptest xmm6, xmm6
00007f8fe1fdbb93  jnz 0x00007F8FE1FDCBF0
00007f8fe1fdbb99  movaps xmm10, xmm12
00007f8fe1fdbb9d  mulpd xmm10, xmm11
00007f8fe1fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007f8fe1fdbba8  ptest xmm6, xmm6
00007f8fe1fdbbad  jnz 0x00007F8FE1FDCD34
00007f8fe1fdbbb3  movaps xmm11, [r15+0x1F0]
00007f8fe1fdbbbb  movaps xmm6, xmm12
00007f8fe1fdbbbf  mulpd xmm6, xmm11
00007f8fe1fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f8fe1fdbbc9  ptest xmm5, xmm5
00007f8fe1fdbbce  jnz 0x00007F8FE1FDCE78
00007f8fe1fdbbd4  movaps xmm12, [r15+0x2A0]
00007f8fe1fdbbdc  vmovaps [rsp+0x80], xmm12
00007f8fe1fdbbe5  vmovaps xmm11, [rsp+0x80]
00007f8fe1fdbbee  por xmm12, xmm11
00007f8fe1fdbbf3  movaps xmm11, [r15+0x250]
00007f8fe1fdbbfb  vmovaps [rsp+0x80], xmm11
00007f8fe1fdbc04  vmovaps xmm5, [rsp+0x80]
00007f8fe1fdbc0d  por xmm11, xmm5
00007f8fe1fdbc12  vmovaps xmm4, [rsp+0x70]
00007f8fe1fdbc18  vpermilpd xmm4, xmm4, 0x00
00007f8fe1fdbc1e  movaps xmm3, xmm5
00007f8fe1fdbc21  mulpd xmm3, xmm4
00007f8fe1fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007f8fe1fdbc2a  ptest xmm2, xmm2
00007f8fe1fdbc2f  jnz 0x00007F8FE1FDCFBA
00007f8fe1fdbc35  mov [rsp+0x80], rax
00007f8fe1fdbc3d  xor eax, eax
00007f8fe1fdbc3f  mov r12d, 0x40
00007f8fe1fdbc45  mov r11d, 0x200
00007f8fe1fdbc4b  cmp r12, r11
00007f8fe1fdbc4e  cmc
00007f8fe1fdbc4f  lahf
00007f8fe1fdbc50  seto al
00007f8fe1fdbc53  mov [r15+0x108], eax
00007f8fe1fdbc5a  movaps xmm5, xmm8
00007f8fe1fdbc5e  addpd xmm5, xmm15
00007f8fe1fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007f8fe1fdbc68  ptest xmm4, xmm4
00007f8fe1fdbc6d  jnz 0x00007F8FE1FDD0FA
00007f8fe1fdbc73  movaps xmm8, [r15+0x1B0]
00007f8fe1fdbc7b  movaps xmm4, xmm9
00007f8fe1fdbc7f  addpd xmm4, xmm8
00007f8fe1fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007f8fe1fdbc89  ptest xmm2, xmm2
00007f8fe1fdbc8e  jnz 0x00007F8FE1FDD23C
00007f8fe1fdbc94  movaps xmm9, xmm10
00007f8fe1fdbc98  addpd xmm9, xmm8
00007f8fe1fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f8fe1fdbca3  ptest xmm2, xmm2
00007f8fe1fdbca8  jnz 0x00007F8FE1FDD37E
00007f8fe1fdbcae  movaps xmm10, [r15+0x2F0]
00007f8fe1fdbcb6  vmovaps [rsp+0x90], xmm10
00007f8fe1fdbcbf  vmovaps xmm8, [rsp+0x90]
00007f8fe1fdbcc8  por xmm10, xmm8
00007f8fe1fdbccd  movaps xmm8, [r15+0x2E0]
00007f8fe1fdbcd5  vmovaps [rsp+0x90], xmm8
00007f8fe1fdbcde  vmovaps xmm2, [rsp+0x90]
00007f8fe1fdbce7  por xmm8, xmm2
00007f8fe1fdbcec  movaps xmm2, [r15+0x2D0]
00007f8fe1fdbcf4  vmovaps [rsp+0x90], xmm2
00007f8fe1fdbcfd  vmovaps [rsp+0xA0], xmm1
00007f8fe1fdbd06  vmovaps xmm1, [rsp+0x90]
00007f8fe1fdbd0f  por xmm2, xmm1
00007f8fe1fdbd13  movaps xmm1, [r15+0x200]
00007f8fe1fdbd1b  vmovaps [rsp+0x90], xmm1
00007f8fe1fdbd24  vmovaps [rsp+0xB0], xmm15
00007f8fe1fdbd2d  vmovaps xmm15, [rsp+0x90]
00007f8fe1fdbd36  por xmm1, xmm15
00007f8fe1fdbd3b  movaps xmm15, [r15+0x1C0]
00007f8fe1fdbd43  vmovaps [rsp+0x90], xmm15
00007f8fe1fdbd4c  vmovaps [rsp+0xC0], xmm1
00007f8fe1fdbd55  vmovaps xmm1, [rsp+0x90]
00007f8fe1fdbd5e  por xmm15, xmm1
00007f8fe1fdbd63  movaps xmm1, [r15+0x190]
00007f8fe1fdbd6b  vmovaps [rsp+0x90], xmm1
00007f8fe1fdbd74  vmovaps [rsp+0xD0], xmm15
00007f8fe1fdbd7d  vmovaps xmm15, [rsp+0x90]
00007f8fe1fdbd86  por xmm1, xmm15
00007f8fe1fdbd8b  movaps xmm15, [r15+0x300]
00007f8fe1fdbd93  vmovaps [rsp+0x90], xmm15
00007f8fe1fdbd9c  vmovaps [rsp+0xE0], xmm1
00007f8fe1fdbda5  vmovaps xmm1, [rsp+0x90]
00007f8fe1fdbdae  por xmm15, xmm1
00007f8fe1fdbdb3  mov rax, [rsp+0x80]
00007f8fe1fdbdbb  lea r12, [rax+0xA0]
00007f8fe1fdbdc2  movups xmm1, [r13+r12*1]
00007f8fe1fdbdc8  lea r12, [rax+0xB0]
00007f8fe1fdbdcf  vmovaps [rsp+0x80], xmm1
00007f8fe1fdbdd8  movups xmm1, [r13+r12*1]
00007f8fe1fdbdde  vmovaps [rsp+0x90], xmm1
00007f8fe1fdbde7  vmovaps [rsp+0xF0], xmm15
00007f8fe1fdbdf0  vmovaps xmm15, [rsp+0xB0]
00007f8fe1fdbdf9  vmovaps [rsp+0xB0], xmm14
00007f8fe1fdbe02  movaps xmm1, xmm6
00007f8fe1fdbe05  addpd xmm1, xmm15
00007f8fe1fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f8fe1fdbe0f  ptest xmm14, xmm14
00007f8fe1fdbe15  jnz 0x00007F8FE1FDD4D6
00007f8fe1fdbe1b  lea r12, [rax+0xF0]
00007f8fe1fdbe22  movups xmm15, [r13+r12*1]
00007f8fe1fdbe28  movaps xmm14, xmm4
00007f8fe1fdbe2c  addpd xmm14, xmm3
00007f8fe1fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007f8fe1fdbe37  ptest xmm6, xmm6
00007f8fe1fdbe3c  jnz 0x00007F8FE1FDD621
00007f8fe1fdbe42  movaps xmm6, xmm9
00007f8fe1fdbe46  addpd xmm6, xmm7
00007f8fe1fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f8fe1fdbe4f  ptest xmm4, xmm4
00007f8fe1fdbe54  jnz 0x00007F8FE1FDD763
00007f8fe1fdbe5a  vmovaps xmm9, [rsp+0x70]
00007f8fe1fdbe60  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fdbe66  vmovaps xmm4, [rsp+0x90]
00007f8fe1fdbe6f  movaps xmm7, xmm4
00007f8fe1fdbe72  mulpd xmm7, xmm9
00007f8fe1fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007f8fe1fdbe7c  ptest xmm3, xmm3
00007f8fe1fdbe81  jnz 0x00007F8FE1FDD8A4
00007f8fe1fdbe87  vmovaps xmm9, [rsp+0x50]
00007f8fe1fdbe8d  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fdbe93  movaps xmm4, xmm15
00007f8fe1fdbe97  mulpd xmm4, xmm9
00007f8fe1fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f8fe1fdbea1  ptest xmm3, xmm3
00007f8fe1fdbea6  jnz 0x00007F8FE1FDD9E5
00007f8fe1fdbeac  lea r12, [rax+0xE0]
00007f8fe1fdbeb3  movups xmm15, [r13+r12*1]
00007f8fe1fdbeb9  vmovaps xmm9, [rsp+0x70]
00007f8fe1fdbebf  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fdbec5  vmovaps [rsp+0x70], xmm1
00007f8fe1fdbecb  vmovaps xmm1, [rsp+0x80]
00007f8fe1fdbed4  vmovaps [rsp+0x80], xmm15
00007f8fe1fdbedd  movaps xmm3, xmm1
00007f8fe1fdbee0  mulpd xmm3, xmm9
00007f8fe1fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f8fe1fdbeea  ptest xmm15, xmm15
00007f8fe1fdbef0  jnz 0x00007F8FE1FDDB31
00007f8fe1fdbef6  vmovaps xmm1, [rsp+0xF0]
00007f8fe1fdbeff  vmovaps xmm15, [rsp+0xF0]
00007f8fe1fdbf08  por xmm1, xmm15
00007f8fe1fdbf0d  movaps [r15+0x300], xmm1
00007f8fe1fdbf15  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdbf1e  vmovaps xmm9, [rsp+0xE0]
00007f8fe1fdbf27  por xmm15, xmm9
00007f8fe1fdbf2c  movaps [r15+0x190], xmm15
00007f8fe1fdbf34  vmovaps xmm9, [rsp+0x50]
00007f8fe1fdbf3a  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fdbf40  vmovaps [rsp+0x90], xmm1
00007f8fe1fdbf49  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdbf52  vmovaps xmm15, [rsp+0x80]
00007f8fe1fdbf5b  vmovaps [rsp+0x80], xmm14
00007f8fe1fdbf64  movaps xmm1, xmm15
00007f8fe1fdbf68  mulpd xmm1, xmm9
00007f8fe1fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f8fe1fdbf72  ptest xmm14, xmm14
00007f8fe1fdbf78  jnz 0x00007F8FE1FDDC72
00007f8fe1fdbf7e  lea r12, [rax+0x90]
00007f8fe1fdbf85  movups xmm15, [r13+r12*1]
00007f8fe1fdbf8b  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdbf94  vmovaps xmm9, [rsp+0xD0]
00007f8fe1fdbf9d  por xmm14, xmm9
00007f8fe1fdbfa2  movaps [r15+0x1C0], xmm14
00007f8fe1fdbfaa  vmovaps xmm9, [rsp+0xC0]
00007f8fe1fdbfb3  vmovaps [rsp+0xD0], xmm1
00007f8fe1fdbfbc  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fdbfc5  por xmm9, xmm1
00007f8fe1fdbfca  movaps [r15+0x200], xmm9
00007f8fe1fdbfd2  vmovaps [rsp+0xC0], xmm2
00007f8fe1fdbfdb  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fdbfe4  por xmm2, xmm1
00007f8fe1fdbfe8  movaps [r15+0x2D0], xmm2
00007f8fe1fdbff0  vmovaps [rsp+0xC0], xmm8
00007f8fe1fdbff9  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fdc002  por xmm8, xmm1
00007f8fe1fdc007  movaps [r15+0x2E0], xmm8
00007f8fe1fdc00f  vmovaps [rsp+0xC0], xmm15
00007f8fe1fdc018  movaps xmm1, xmm5
00007f8fe1fdc01b  addpd xmm1, xmm7
00007f8fe1fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007f8fe1fdc024  ptest xmm15, xmm15
00007f8fe1fdc02a  jnz 0x00007F8FE1FDDDBE
00007f8fe1fdc030  vmovaps xmm15, [rsp+0x50]
00007f8fe1fdc036  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fdc03c  vmovaps xmm5, [rsp+0xC0]
00007f8fe1fdc045  vmovaps [rsp+0xC0], xmm1
00007f8fe1fdc04e  movaps xmm7, xmm5
00007f8fe1fdc051  mulpd xmm7, xmm15
00007f8fe1fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007f8fe1fdc05b  ptest xmm1, xmm1
00007f8fe1fdc060  jnz 0x00007F8FE1FDDEFE
00007f8fe1fdc066  lea r12, [rax+0x80]
00007f8fe1fdc06d  movups xmm1, [r13+r12*1]
00007f8fe1fdc073  vmovaps xmm5, [rsp+0x70]
00007f8fe1fdc079  vmovaps [rsp+0x70], xmm1
00007f8fe1fdc07f  movaps xmm15, xmm5
00007f8fe1fdc083  addpd xmm15, xmm3
00007f8fe1fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007f8fe1fdc08e  ptest xmm1, xmm1
00007f8fe1fdc093  jnz 0x00007F8FE1FDE049
00007f8fe1fdc099  vmovaps xmm5, [rsp+0x80]
00007f8fe1fdc0a2  movaps xmm1, xmm5
00007f8fe1fdc0a5  addpd xmm1, xmm4
00007f8fe1fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007f8fe1fdc0ae  ptest xmm3, xmm3
00007f8fe1fdc0b3  jnz 0x00007F8FE1FDE18B
00007f8fe1fdc0b9  vmovaps [rsp+0x80], xmm10
00007f8fe1fdc0c2  vmovaps xmm5, [rsp+0x80]
00007f8fe1fdc0cb  por xmm10, xmm5
00007f8fe1fdc0d0  movaps [r15+0x2F0], xmm10
00007f8fe1fdc0d8  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdc0de  vpermilpd xmm5, xmm5, 0x00
00007f8fe1fdc0e4  vmovaps xmm3, [rsp+0x70]
00007f8fe1fdc0ea  vmovaps [rsp+0x50], xmm1
00007f8fe1fdc0f0  movaps xmm4, xmm3
00007f8fe1fdc0f3  mulpd xmm4, xmm5
00007f8fe1fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f8fe1fdc0fc  ptest xmm1, xmm1
00007f8fe1fdc101  jnz 0x00007F8FE1FDE2CB
00007f8fe1fdc107  lea r12, [rax+0xD0]
00007f8fe1fdc10e  movups xmm1, [r13+r12*1]
00007f8fe1fdc114  vmovaps xmm3, [rsp+0xD0]
00007f8fe1fdc11d  vmovaps [rsp+0x70], xmm1
00007f8fe1fdc123  movaps xmm5, xmm6
00007f8fe1fdc126  addpd xmm5, xmm3
00007f8fe1fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f8fe1fdc12f  ptest xmm1, xmm1
00007f8fe1fdc134  jnz 0x00007F8FE1FDE415
00007f8fe1fdc13a  vmovaps xmm1, [rsp+0x60]
00007f8fe1fdc140  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fdc146  movaps xmm6, xmm9
00007f8fe1fdc14a  mulpd xmm6, xmm1
00007f8fe1fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f8fe1fdc153  ptest xmm3, xmm3
00007f8fe1fdc158  jnz 0x00007F8FE1FDE555
00007f8fe1fdc15e  movaps [r15+0x260], xmm6
00007f8fe1fdc166  vxorps xmm1, xmm1, xmm1
00007f8fe1fdc16a  vpbroadcastq xmm1, xmm1
00007f8fe1fdc16f  movaps [r15+0x1B0], xmm1
00007f8fe1fdc177  vmovaps xmm1, [rsp+0x60]
00007f8fe1fdc17d  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fdc183  vmovaps xmm3, [rsp+0x70]
00007f8fe1fdc189  vmovaps [rsp+0x70], xmm15
00007f8fe1fdc18f  movaps xmm9, xmm3
00007f8fe1fdc193  mulpd xmm9, xmm1
00007f8fe1fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007f8fe1fdc19e  ptest xmm15, xmm15
00007f8fe1fdc1a4  jnz 0x00007F8FE1FDE696
00007f8fe1fdc1aa  lea r12, [rax+0xC0]
00007f8fe1fdc1b1  movups xmm1, [r13+r12*1]
00007f8fe1fdc1b7  vmovaps xmm3, [rsp+0xC0]
00007f8fe1fdc1c0  vmovaps [rsp+0x80], xmm1
00007f8fe1fdc1c9  movaps xmm15, xmm3
00007f8fe1fdc1cd  addpd xmm15, xmm7
00007f8fe1fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f8fe1fdc1d8  ptest xmm1, xmm1
00007f8fe1fdc1dd  jnz 0x00007F8FE1FDE7E2
00007f8fe1fdc1e3  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdc1ec  vmovaps xmm1, [rsp+0xC0]
00007f8fe1fdc1f5  por xmm13, xmm1
00007f8fe1fdc1fa  movaps [r15+0x270], xmm13
00007f8fe1fdc202  vmovaps xmm1, [rsp+0xB0]
00007f8fe1fdc20b  vmovaps xmm7, [rsp+0xB0]
00007f8fe1fdc214  por xmm1, xmm7
00007f8fe1fdc218  movaps [r15+0x1A0], xmm1
00007f8fe1fdc220  vmovaps xmm1, [rsp+0x60]
00007f8fe1fdc226  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fdc22c  vmovaps [rsp+0xB0], xmm1
00007f8fe1fdc235  vmovaps xmm1, [rsp+0x80]
00007f8fe1fdc23e  vmovaps [rsp+0x80], xmm15
00007f8fe1fdc247  vmovaps xmm15, [rsp+0xB0]
00007f8fe1fdc250  vmovaps [rsp+0xB0], xmm14
00007f8fe1fdc259  movaps xmm3, xmm1
00007f8fe1fdc25c  mulpd xmm3, xmm15
00007f8fe1fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007f8fe1fdc266  ptest xmm14, xmm14
00007f8fe1fdc26c  jnz 0x00007F8FE1FDE924
00007f8fe1fdc272  lea r12, [rax+0x20]
00007f8fe1fdc276  movups xmm1, [r13+r12*1]
00007f8fe1fdc27c  movaps [r15+0x110], xmm1
00007f8fe1fdc284  vmovaps xmm14, [rsp+0x70]
00007f8fe1fdc28a  vmovaps [rsp+0x70], xmm1
00007f8fe1fdc290  movaps xmm15, xmm14
00007f8fe1fdc294  addpd xmm15, xmm4
00007f8fe1fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007f8fe1fdc29f  ptest xmm1, xmm1
00007f8fe1fdc2a4  jnz 0x00007F8FE1FDEA6F
00007f8fe1fdc2aa  vmovaps xmm1, [rsp+0x60]
00007f8fe1fdc2b0  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fdc2b6  movaps xmm14, xmm2
00007f8fe1fdc2ba  mulpd xmm14, xmm1
00007f8fe1fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007f8fe1fdc2c5  ptest xmm4, xmm4
00007f8fe1fdc2ca  jnz 0x00007F8FE1FDEBB2
00007f8fe1fdc2d0  vmovaps xmm4, [rsp+0x50]
00007f8fe1fdc2d6  movaps xmm1, xmm4
00007f8fe1fdc2d9  addpd xmm1, xmm9
00007f8fe1fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007f8fe1fdc2e3  ptest xmm2, xmm2
00007f8fe1fdc2e8  jnz 0x00007F8FE1FDECF4
00007f8fe1fdc2ee  vmovaps xmm9, [rsp+0x30]
00007f8fe1fdc2f4  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fdc2fa  vmovaps xmm2, [rsp+0x70]
00007f8fe1fdc300  vmovaps [rsp+0x50], xmm1
00007f8fe1fdc306  movaps xmm4, xmm2
00007f8fe1fdc309  mulpd xmm4, xmm9
00007f8fe1fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007f8fe1fdc313  ptest xmm1, xmm1
00007f8fe1fdc318  jnz 0x00007F8FE1FDEE35
00007f8fe1fdc31e  vmovaps xmm1, [rsp+0x30]
00007f8fe1fdc324  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fdc32a  vmovaps xmm2, [rsp+0x90]
00007f8fe1fdc333  vmovaps [rsp+0x60], xmm15
00007f8fe1fdc339  movaps xmm9, xmm2
00007f8fe1fdc33d  mulpd xmm9, xmm1
00007f8fe1fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007f8fe1fdc348  ptest xmm15, xmm15
00007f8fe1fdc34e  jnz 0x00007F8FE1FDEF76
00007f8fe1fdc354  vmovaps xmm15, [rsp+0x80]
00007f8fe1fdc35d  movaps xmm1, xmm15
00007f8fe1fdc361  addpd xmm1, xmm6
00007f8fe1fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007f8fe1fdc36a  ptest xmm2, xmm2
00007f8fe1fdc36f  jnz 0x00007F8FE1FDF0B8
00007f8fe1fdc375  movaps xmm15, xmm5
00007f8fe1fdc379  addpd xmm15, xmm3
00007f8fe1fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f8fe1fdc384  ptest xmm6, xmm6
00007f8fe1fdc389  jnz 0x00007F8FE1FDF1F9
00007f8fe1fdc38f  vmovaps xmm6, [rsp+0x30]
00007f8fe1fdc395  vpermilpd xmm6, xmm6, 0x00
00007f8fe1fdc39b  movaps xmm5, xmm8
00007f8fe1fdc39f  mulpd xmm5, xmm6
00007f8fe1fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007f8fe1fdc3a8  ptest xmm3, xmm3
00007f8fe1fdc3ad  jnz 0x00007F8FE1FDF33B
00007f8fe1fdc3b3  vmovaps xmm8, [rsp+0x30]
00007f8fe1fdc3b9  vpermilpd xmm8, xmm8, 0x00
00007f8fe1fdc3bf  movaps xmm6, xmm10
00007f8fe1fdc3c3  mulpd xmm6, xmm8
00007f8fe1fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f8fe1fdc3cd  ptest xmm3, xmm3
00007f8fe1fdc3d2  jnz 0x00007F8FE1FDF47C
00007f8fe1fdc3d8  vmovaps xmm8, [rsp+0x60]
00007f8fe1fdc3de  movaps xmm10, xmm8
00007f8fe1fdc3e2  addpd xmm10, xmm14
00007f8fe1fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f8fe1fdc3ed  ptest xmm3, xmm3
00007f8fe1fdc3f2  jnz 0x00007F8FE1FDF5BE
00007f8fe1fdc3f8  vmovaps xmm8, [rsp+0x50]
00007f8fe1fdc3fe  movaps xmm14, xmm8
00007f8fe1fdc402  addpd xmm14, xmm4
00007f8fe1fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007f8fe1fdc40d  ptest xmm3, xmm3
00007f8fe1fdc412  jnz 0x00007F8FE1FDF702
00007f8fe1fdc418  vmovaps xmm8, [rsp+0x40]
00007f8fe1fdc41e  vpermilpd xmm8, xmm8, 0x00
00007f8fe1fdc424  movaps xmm4, xmm13
00007f8fe1fdc428  mulpd xmm4, xmm8
00007f8fe1fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f8fe1fdc432  ptest xmm3, xmm3
00007f8fe1fdc437  jnz 0x00007F8FE1FDF845
00007f8fe1fdc43d  movaps xmm13, xmm15
00007f8fe1fdc441  addpd xmm13, xmm9
00007f8fe1fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007f8fe1fdc44c  ptest xmm8, xmm8
00007f8fe1fdc452  jnz 0x00007F8FE1FDF987
00007f8fe1fdc458  movaps xmm15, xmm1
00007f8fe1fdc45c  addpd xmm15, xmm5
00007f8fe1fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007f8fe1fdc467  ptest xmm9, xmm9
00007f8fe1fdc46d  jnz 0x00007F8FE1FDFACB
00007f8fe1fdc473  vmovaps [rsp+0x30], xmm11
00007f8fe1fdc479  vmovaps xmm1, [rsp+0x30]
00007f8fe1fdc47f  por xmm11, xmm1
00007f8fe1fdc484  movaps [r15+0x250], xmm11
00007f8fe1fdc48c  vmovaps [rsp+0x30], xmm12
00007f8fe1fdc492  vmovaps xmm1, [rsp+0x30]
00007f8fe1fdc498  por xmm12, xmm1
00007f8fe1fdc49d  movaps [r15+0x2A0], xmm12
00007f8fe1fdc4a5  vmovaps xmm1, [rsp+0xA0]
00007f8fe1fdc4ae  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdc4b7  por xmm1, xmm11
00007f8fe1fdc4bc  movaps [r15+0x1D0], xmm1
00007f8fe1fdc4c4  lea r12, [rax+0x40]
00007f8fe1fdc4c8  movups xmm1, [r13+r12*1]
00007f8fe1fdc4ce  movaps [r15+0x2C0], xmm1
00007f8fe1fdc4d6  vmovaps xmm11, [rsp+0x40]
00007f8fe1fdc4dc  vpermilpd xmm11, xmm11, 0x00
00007f8fe1fdc4e2  vmovaps xmm8, [rsp+0xE0]
00007f8fe1fdc4eb  movaps xmm9, xmm8
00007f8fe1fdc4ef  mulpd xmm9, xmm11
00007f8fe1fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f8fe1fdc4fa  ptest xmm5, xmm5
00007f8fe1fdc4ff  jnz 0x00007F8FE1FDFC17
00007f8fe1fdc505  movaps xmm11, xmm10
00007f8fe1fdc509  addpd xmm11, xmm6
00007f8fe1fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007f8fe1fdc514  ptest xmm8, xmm8
00007f8fe1fdc51a  jnz 0x00007F8FE1FDFD5B
00007f8fe1fdc520  movaps xmm10, xmm14
00007f8fe1fdc524  addpd xmm10, xmm4
00007f8fe1fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007f8fe1fdc52f  ptest xmm8, xmm8
00007f8fe1fdc535  jnz 0x00007F8FE1FDFE9E
00007f8fe1fdc53b  vmovaps xmm14, [rsp+0x40]
00007f8fe1fdc541  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fdc547  movaps xmm8, xmm1
00007f8fe1fdc54b  mulpd xmm8, xmm14
00007f8fe1fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007f8fe1fdc556  ptest xmm6, xmm6
00007f8fe1fdc55b  jnz 0x00007F8FE1FDFFE1
00007f8fe1fdc561  movaps xmm1, [r15+0x2B0]
00007f8fe1fdc569  vmovaps xmm14, [rsp+0x40]
00007f8fe1fdc56f  vpermilpd xmm14, xmm14, 0x00
00007f8fe1fdc575  movaps xmm6, xmm1
00007f8fe1fdc578  mulpd xmm6, xmm14
00007f8fe1fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f8fe1fdc582  ptest xmm5, xmm5
00007f8fe1fdc587  jnz 0x00007F8FE1FE0124
00007f8fe1fdc58d  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdc593  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fdc599  movaps xmm14, xmm12
00007f8fe1fdc59d  mulpd xmm14, xmm1
00007f8fe1fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007f8fe1fdc5a8  ptest xmm5, xmm5
00007f8fe1fdc5ad  jnz 0x00007F8FE1FE0265
00007f8fe1fdc5b3  movaps xmm1, xmm13
00007f8fe1fdc5b7  addpd xmm1, xmm9
00007f8fe1fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007f8fe1fdc5c1  ptest xmm12, xmm12
00007f8fe1fdc5c7  jnz 0x00007F8FE1FE03A8
00007f8fe1fdc5cd  vmovaps xmm13, [rsp+0x10]
00007f8fe1fdc5d3  vpermilpd xmm13, xmm13, 0x00
00007f8fe1fdc5d9  movaps xmm12, xmm7
00007f8fe1fdc5dd  mulpd xmm12, xmm13
00007f8fe1fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f8fe1fdc5e8  ptest xmm9, xmm9
00007f8fe1fdc5ee  jnz 0x00007F8FE1FE04EA
00007f8fe1fdc5f4  movaps xmm13, xmm15
00007f8fe1fdc5f8  addpd xmm13, xmm8
00007f8fe1fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f8fe1fdc603  ptest xmm9, xmm9
00007f8fe1fdc609  jnz 0x00007F8FE1FE062D
00007f8fe1fdc60f  movaps xmm15, [r15+0x290]
00007f8fe1fdc617  vmovaps xmm9, [rsp+0x10]
00007f8fe1fdc61d  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fdc623  movaps xmm8, xmm15
00007f8fe1fdc627  mulpd xmm8, xmm9
00007f8fe1fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f8fe1fdc632  ptest xmm7, xmm7
00007f8fe1fdc637  jnz 0x00007F8FE1FE0771
00007f8fe1fdc63d  movaps xmm15, xmm11
00007f8fe1fdc641  addpd xmm15, xmm6
00007f8fe1fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007f8fe1fdc64c  ptest xmm9, xmm9
00007f8fe1fdc652  jnz 0x00007F8FE1FE08B5
00007f8fe1fdc658  movaps xmm11, [r15+0x1E0]
00007f8fe1fdc660  vmovaps xmm9, [rsp+0x10]
00007f8fe1fdc666  vpermilpd xmm9, xmm9, 0x00
00007f8fe1fdc66c  movaps xmm7, xmm11
00007f8fe1fdc670  mulpd xmm7, xmm9
00007f8fe1fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007f8fe1fdc67a  ptest xmm6, xmm6
00007f8fe1fdc67f  jnz 0x00007F8FE1FE09F8
00007f8fe1fdc685  movaps xmm11, xmm10
00007f8fe1fdc689  addpd xmm11, xmm14
00007f8fe1fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f8fe1fdc694  ptest xmm9, xmm9
00007f8fe1fdc69a  jnz 0x00007F8FE1FE0B3A
00007f8fe1fdc6a0  lea r12, [rax+0x70]
00007f8fe1fdc6a4  movups xmm14, [r13+r12*1]
00007f8fe1fdc6aa  movaps [r15+0x240], xmm14
00007f8fe1fdc6b2  movaps xmm10, xmm1
00007f8fe1fdc6b6  addpd xmm10, xmm12
00007f8fe1fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007f8fe1fdc6c1  ptest xmm9, xmm9
00007f8fe1fdc6c7  jnz 0x00007F8FE1FE0C88
00007f8fe1fdc6cd  movaps [r15+0x170], xmm10
00007f8fe1fdc6d5  vmovaps xmm1, [rsp+0x20]
00007f8fe1fdc6db  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fdc6e1  movaps xmm12, xmm14
00007f8fe1fdc6e5  mulpd xmm12, xmm1
00007f8fe1fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007f8fe1fdc6f0  ptest xmm9, xmm9
00007f8fe1fdc6f6  jnz 0x00007F8FE1FE0DCB
00007f8fe1fdc6fc  vmovaps xmm1, [rsp+0x20]
00007f8fe1fdc702  vpermilpd xmm1, xmm1, 0x00
00007f8fe1fdc708  vmovaps xmm9, [rsp+0xB0]
00007f8fe1fdc711  movaps xmm14, xmm9
00007f8fe1fdc715  mulpd xmm14, xmm1
00007f8fe1fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007f8fe1fdc720  ptest xmm6, xmm6
00007f8fe1fdc725  jnz 0x00007F8FE1FE0F0E
00007f8fe1fdc72b  movaps [r15+0x180], xmm14
00007f8fe1fdc733  movaps xmm1, xmm13
00007f8fe1fdc737  addpd xmm1, xmm8
00007f8fe1fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f8fe1fdc741  ptest xmm9, xmm9
00007f8fe1fdc747  jnz 0x00007F8FE1FE1051
00007f8fe1fdc74d  movaps [r15+0x210], xmm1
00007f8fe1fdc755  movups xmm13, [r13+rax*1]
00007f8fe1fdc75b  lea r12, [rax+0x10]
00007f8fe1fdc75f  movups xmm9, [r13+r12*1]
00007f8fe1fdc765  movaps [r15+0x230], xmm9
00007f8fe1fdc76d  movaps xmm8, xmm15
00007f8fe1fdc771  addpd xmm8, xmm7
00007f8fe1fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007f8fe1fdc77c  ptest xmm6, xmm6
00007f8fe1fdc781  jnz 0x00007F8FE1FE11A7
00007f8fe1fdc787  movaps [r15+0x130], xmm8
00007f8fe1fdc78f  vmovaps xmm15, [rsp+0x20]
00007f8fe1fdc795  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fdc79b  movaps xmm7, xmm9
00007f8fe1fdc79f  mulpd xmm7, xmm15
00007f8fe1fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007f8fe1fdc7a9  ptest xmm6, xmm6
00007f8fe1fdc7ae  jnz 0x00007F8FE1FE12EA
00007f8fe1fdc7b4  movaps [r15+0x220], xmm7
00007f8fe1fdc7bc  vmovaps xmm15, [rsp+0x20]
00007f8fe1fdc7c2  vpermilpd xmm15, xmm15, 0x00
00007f8fe1fdc7c8  movaps xmm9, xmm13
00007f8fe1fdc7cc  mulpd xmm9, xmm15
00007f8fe1fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f8fe1fdc7d7  ptest xmm6, xmm6
00007f8fe1fdc7dc  jnz 0x00007F8FE1FE142C
00007f8fe1fdc7e2  movaps xmm15, xmm11
00007f8fe1fdc7e6  addpd xmm15, xmm12
00007f8fe1fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f8fe1fdc7f1  ptest xmm13, xmm13
00007f8fe1fdc7f7  jnz 0x00007F8FE1FE1570
00007f8fe1fdc7fd  movaps [r15+0x140], xmm15
00007f8fe1fdc805  movaps xmm13, xmm10
00007f8fe1fdc809  addpd xmm13, xmm14
00007f8fe1fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f8fe1fdc814  ptest xmm12, xmm12
00007f8fe1fdc81a  jnz 0x00007F8FE1FE16B4
00007f8fe1fdc820  movaps [r15+0x150], xmm13
00007f8fe1fdc828  movaps xmm14, xmm1
00007f8fe1fdc82c  addpd xmm14, xmm7
00007f8fe1fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007f8fe1fdc837  ptest xmm12, xmm12
00007f8fe1fdc83d  jnz 0x00007F8FE1FE17F8
00007f8fe1fdc843  movaps [r15+0x160], xmm14
00007f8fe1fdc84b  movaps xmm1, xmm8
00007f8fe1fdc84f  addpd xmm1, xmm9
00007f8fe1fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007f8fe1fdc859  ptest xmm12, xmm12
00007f8fe1fdc85f  jnz 0x00007F8FE1FE193A
00007f8fe1fdc865  movaps [r15+0x120], xmm1
00007f8fe1fdc86d  movups [r13+r14*1], xmm15
00007f8fe1fdc873  lea rax, [r14+0x10]
00007f8fe1fdc877  movups [r13+rax*1], xmm13
00007f8fe1fdc87d  lea rax, [r14+0x20]
00007f8fe1fdc881  movups [r13+rax*1], xmm14
00007f8fe1fdc887  lea rax, [r14+0x30]
00007f8fe1fdc88b  movups [r13+rax*1], xmm1
00007f8fe1fdc891  mov eax, [r15+0x108]
00007f8fe1fdc898  sahf
00007f8fe1fdc899  jnz 0x00007F8FE1FDC8CB
00007f8fe1fdc89b  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fdc8a3  jz 0x00007F8FE1FDB900
00007f8fe1fdc8a9  nop [rax+rax*1], ax
00007f8fe1fdc8b2  nop [rax+rax*1], eax
00007f8fe1fdc8ba  mov eax, 0x410444
00007f8fe1fdc8bf  mov [r15+0x100], rax
00007f8fe1fdc8c6  jmp 0x00007F8FE1DFE110
00007f8fe1fdc8cb  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fdc8d3  jz 0x00007F8FE1FD57E0
00007f8fe1fdc8d9  nop [rax+rax*1], ax
00007f8fe1fdc8e2  nop [rax+rax*1], eax
00007f8fe1fdc8ea  mov eax, 0x410278
00007f8fe1fdc8ef  mov [r15+0x100], rax
00007f8fe1fdc8f6  jmp 0x00007F8FE1DFE110
00007f8fe1fdc8fb  int3
00007f8fe1fdc8fc  call 0x00007F8FE1EE27E0
00007f8fe1fdc901  jmp 0x00007F8FE1FDB9DF
00007f8fe1fdc906  call 0x00007F8FE1EE1570
00007f8fe1fdc90b  jmp 0x00007F8FE1FDB9E8
00007f8fe1fdc910  call 0x00007F8FE1EE27E0
00007f8fe1fdc915  jmp 0x00007F8FE1FDBA44
00007f8fe1fdc91a  call 0x00007F8FE1EE1570
00007f8fe1fdc91f  jmp 0x00007F8FE1FDBA4D
00007f8fe1fdc924  call 0x00007F8FE1EE27E0
00007f8fe1fdc929  jmp 0x00007F8FE1FDBA90
00007f8fe1fdc92e  call 0x00007F8FE1EE1570
00007f8fe1fdc933  jmp 0x00007F8FE1FDBA99
00007f8fe1fdc938  call 0x00007F8FE1E0DC20
00007f8fe1fdc93d  jmp 0x00007F8FE1FDBAD8
00007f8fe1fdc942  call 0x00007F8FE1ED59C0
00007f8fe1fdc947  jmp 0x00007F8FE1FDBAEB
00007f8fe1fdc94c  call 0x00007F8FE1EE0E30
00007f8fe1fdc951  jmp 0x00007F8FE1FDBB09
00007f8fe1fdc956  call 0x00007F8FE1EDFBC0
00007f8fe1fdc95b  jmp 0x00007F8FE1FDBB13
00007f8fe1fdc960  call 0x00007F8FE1EDE950
00007f8fe1fdc965  jmp 0x00007F8FE1FDBB1D
00007f8fe1fdc96a  sub rsp, 0x08
00007f8fe1fdc96e  push rax
00007f8fe1fdc96f  push rcx
00007f8fe1fdc970  push rdx
00007f8fe1fdc971  push rdi
00007f8fe1fdc972  push rsi
00007f8fe1fdc973  push r8
00007f8fe1fdc975  push r9
00007f8fe1fdc977  push r10
00007f8fe1fdc979  push r11
00007f8fe1fdc97b  sub rsp, 0xF0
00007f8fe1fdc982  vmovaps [rsp], xmm0
00007f8fe1fdc987  vmovaps [rsp+0x10], xmm1
00007f8fe1fdc98d  vmovaps [rsp+0x20], xmm2
00007f8fe1fdc993  vmovaps [rsp+0x30], xmm3
00007f8fe1fdc999  vmovaps [rsp+0x40], xmm4
00007f8fe1fdc99f  vmovaps [rsp+0x50], xmm5
00007f8fe1fdc9a5  vmovaps [rsp+0x60], xmm6
00007f8fe1fdc9ab  vmovaps [rsp+0x70], xmm7
00007f8fe1fdc9b1  vmovaps [rsp+0x80], xmm9
00007f8fe1fdc9ba  vmovaps [rsp+0x90], xmm10
00007f8fe1fdc9c3  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdc9cc  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdc9d5  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdc9de  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdc9e7  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdc9f0  sub rsp, 0x30
00007f8fe1fdc9f4  movaps [rsp], xmm8
00007f8fe1fdc9f9  movaps [rsp+0x10], xmm12
00007f8fe1fdc9ff  movaps [rsp+0x20], xmm15
00007f8fe1fdca05  lea rdi, [rsp]
00007f8fe1fdca09  mov esi, 0x00
00007f8fe1fdca0e  mov rax, 0x6020BB77F530
00007f8fe1fdca18  call rax
00007f8fe1fdca1a  movaps xmm8, [rsp]
00007f8fe1fdca1f  add rsp, 0x30
00007f8fe1fdca23  vmovaps xmm0, [rsp]
00007f8fe1fdca28  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdca2e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdca34  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdca3a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdca40  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdca46  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdca4c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdca52  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdca5b  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdca64  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdca6d  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdca76  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdca7f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdca88  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdca91  add rsp, 0xF0
00007f8fe1fdca98  pop r11
00007f8fe1fdca9a  pop r10
00007f8fe1fdca9c  pop r9
00007f8fe1fdca9e  pop r8
00007f8fe1fdcaa0  pop rsi
00007f8fe1fdcaa1  pop rdi
00007f8fe1fdcaa2  pop rdx
00007f8fe1fdcaa3  pop rcx
00007f8fe1fdcaa4  pop rax
00007f8fe1fdcaa5  add rsp, 0x08
00007f8fe1fdcaa9  jmp 0x00007F8FE1FDBB47
00007f8fe1fdcaae  sub rsp, 0x08
00007f8fe1fdcab2  push rax
00007f8fe1fdcab3  push rcx
00007f8fe1fdcab4  push rdx
00007f8fe1fdcab5  push rdi
00007f8fe1fdcab6  push rsi
00007f8fe1fdcab7  push r8
00007f8fe1fdcab9  push r9
00007f8fe1fdcabb  push r10
00007f8fe1fdcabd  push r11
00007f8fe1fdcabf  sub rsp, 0xF0
00007f8fe1fdcac6  vmovaps [rsp], xmm0
00007f8fe1fdcacb  vmovaps [rsp+0x10], xmm1
00007f8fe1fdcad1  vmovaps [rsp+0x20], xmm2
00007f8fe1fdcad7  vmovaps [rsp+0x30], xmm3
00007f8fe1fdcadd  vmovaps [rsp+0x40], xmm4
00007f8fe1fdcae3  vmovaps [rsp+0x50], xmm5
00007f8fe1fdcae9  vmovaps [rsp+0x60], xmm6
00007f8fe1fdcaef  vmovaps [rsp+0x70], xmm8
00007f8fe1fdcaf5  vmovaps [rsp+0x80], xmm9
00007f8fe1fdcafe  vmovaps [rsp+0x90], xmm10
00007f8fe1fdcb07  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdcb10  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdcb19  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdcb22  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdcb2b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdcb34  sub rsp, 0x30
00007f8fe1fdcb38  movaps [rsp], xmm7
00007f8fe1fdcb3c  movaps [rsp+0x10], xmm9
00007f8fe1fdcb42  movaps [rsp+0x20], xmm15
00007f8fe1fdcb48  lea rdi, [rsp]
00007f8fe1fdcb4c  mov esi, 0x00
00007f8fe1fdcb51  mov rax, 0x6020BB77F530
00007f8fe1fdcb5b  call rax
00007f8fe1fdcb5d  movaps xmm7, [rsp]
00007f8fe1fdcb61  add rsp, 0x30
00007f8fe1fdcb65  vmovaps xmm0, [rsp]
00007f8fe1fdcb6a  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdcb70  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdcb76  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdcb7c  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdcb82  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdcb88  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdcb8e  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdcb94  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdcb9d  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdcba6  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdcbaf  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdcbb8  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdcbc1  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdcbca  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdcbd3  add rsp, 0xF0
00007f8fe1fdcbda  pop r11
00007f8fe1fdcbdc  pop r10
00007f8fe1fdcbde  pop r9
00007f8fe1fdcbe0  pop r8
00007f8fe1fdcbe2  pop rsi
00007f8fe1fdcbe3  pop rdi
00007f8fe1fdcbe4  pop rdx
00007f8fe1fdcbe5  pop rcx
00007f8fe1fdcbe6  pop rax
00007f8fe1fdcbe7  add rsp, 0x08
00007f8fe1fdcbeb  jmp 0x00007F8FE1FDBB75
00007f8fe1fdcbf0  sub rsp, 0x08
00007f8fe1fdcbf4  push rax
00007f8fe1fdcbf5  push rcx
00007f8fe1fdcbf6  push rdx
00007f8fe1fdcbf7  push rdi
00007f8fe1fdcbf8  push rsi
00007f8fe1fdcbf9  push r8
00007f8fe1fdcbfb  push r9
00007f8fe1fdcbfd  push r10
00007f8fe1fdcbff  push r11
00007f8fe1fdcc01  sub rsp, 0xF0
00007f8fe1fdcc08  vmovaps [rsp], xmm0
00007f8fe1fdcc0d  vmovaps [rsp+0x10], xmm1
00007f8fe1fdcc13  vmovaps [rsp+0x20], xmm2
00007f8fe1fdcc19  vmovaps [rsp+0x30], xmm3
00007f8fe1fdcc1f  vmovaps [rsp+0x40], xmm4
00007f8fe1fdcc25  vmovaps [rsp+0x50], xmm5
00007f8fe1fdcc2b  vmovaps [rsp+0x60], xmm6
00007f8fe1fdcc31  vmovaps [rsp+0x70], xmm7
00007f8fe1fdcc37  vmovaps [rsp+0x80], xmm8
00007f8fe1fdcc40  vmovaps [rsp+0x90], xmm10
00007f8fe1fdcc49  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdcc52  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdcc5b  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdcc64  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdcc6d  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdcc76  sub rsp, 0x30
00007f8fe1fdcc7a  movaps [rsp], xmm9
00007f8fe1fdcc7f  movaps [rsp+0x10], xmm12
00007f8fe1fdcc85  movaps [rsp+0x20], xmm10
00007f8fe1fdcc8b  lea rdi, [rsp]
00007f8fe1fdcc8f  mov esi, 0x00
00007f8fe1fdcc94  mov rax, 0x6020BB77F530
00007f8fe1fdcc9e  call rax
00007f8fe1fdcca0  movaps xmm9, [rsp]
00007f8fe1fdcca5  add rsp, 0x30
00007f8fe1fdcca9  vmovaps xmm0, [rsp]
00007f8fe1fdccae  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdccb4  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdccba  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdccc0  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdccc6  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdcccc  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdccd2  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdccd8  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdcce1  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdccea  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdccf3  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdccfc  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdcd05  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdcd0e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdcd17  add rsp, 0xF0
00007f8fe1fdcd1e  pop r11
00007f8fe1fdcd20  pop r10
00007f8fe1fdcd22  pop r9
00007f8fe1fdcd24  pop r8
00007f8fe1fdcd26  pop rsi
00007f8fe1fdcd27  pop rdi
00007f8fe1fdcd28  pop rdx
00007f8fe1fdcd29  pop rcx
00007f8fe1fdcd2a  pop rax
00007f8fe1fdcd2b  add rsp, 0x08
00007f8fe1fdcd2f  jmp 0x00007F8FE1FDBB99
00007f8fe1fdcd34  sub rsp, 0x08
00007f8fe1fdcd38  push rax
00007f8fe1fdcd39  push rcx
00007f8fe1fdcd3a  push rdx
00007f8fe1fdcd3b  push rdi
00007f8fe1fdcd3c  push rsi
00007f8fe1fdcd3d  push r8
00007f8fe1fdcd3f  push r9
00007f8fe1fdcd41  push r10
00007f8fe1fdcd43  push r11
00007f8fe1fdcd45  sub rsp, 0xF0
00007f8fe1fdcd4c  vmovaps [rsp], xmm0
00007f8fe1fdcd51  vmovaps [rsp+0x10], xmm1
00007f8fe1fdcd57  vmovaps [rsp+0x20], xmm2
00007f8fe1fdcd5d  vmovaps [rsp+0x30], xmm3
00007f8fe1fdcd63  vmovaps [rsp+0x40], xmm4
00007f8fe1fdcd69  vmovaps [rsp+0x50], xmm5
00007f8fe1fdcd6f  vmovaps [rsp+0x60], xmm6
00007f8fe1fdcd75  vmovaps [rsp+0x70], xmm7
00007f8fe1fdcd7b  vmovaps [rsp+0x80], xmm8
00007f8fe1fdcd84  vmovaps [rsp+0x90], xmm9
00007f8fe1fdcd8d  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdcd96  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdcd9f  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdcda8  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdcdb1  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdcdba  sub rsp, 0x30
00007f8fe1fdcdbe  movaps [rsp], xmm10
00007f8fe1fdcdc3  movaps [rsp+0x10], xmm12
00007f8fe1fdcdc9  movaps [rsp+0x20], xmm11
00007f8fe1fdcdcf  lea rdi, [rsp]
00007f8fe1fdcdd3  mov esi, 0x00
00007f8fe1fdcdd8  mov rax, 0x6020BB77F530
00007f8fe1fdcde2  call rax
00007f8fe1fdcde4  movaps xmm10, [rsp]
00007f8fe1fdcde9  add rsp, 0x30
00007f8fe1fdcded  vmovaps xmm0, [rsp]
00007f8fe1fdcdf2  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdcdf8  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdcdfe  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdce04  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdce0a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdce10  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdce16  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdce1c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdce25  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdce2e  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdce37  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdce40  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdce49  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdce52  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdce5b  add rsp, 0xF0
00007f8fe1fdce62  pop r11
00007f8fe1fdce64  pop r10
00007f8fe1fdce66  pop r9
00007f8fe1fdce68  pop r8
00007f8fe1fdce6a  pop rsi
00007f8fe1fdce6b  pop rdi
00007f8fe1fdce6c  pop rdx
00007f8fe1fdce6d  pop rcx
00007f8fe1fdce6e  pop rax
00007f8fe1fdce6f  add rsp, 0x08
00007f8fe1fdce73  jmp 0x00007F8FE1FDBBB3
00007f8fe1fdce78  sub rsp, 0x08
00007f8fe1fdce7c  push rax
00007f8fe1fdce7d  push rcx
00007f8fe1fdce7e  push rdx
00007f8fe1fdce7f  push rdi
00007f8fe1fdce80  push rsi
00007f8fe1fdce81  push r8
00007f8fe1fdce83  push r9
00007f8fe1fdce85  push r10
00007f8fe1fdce87  push r11
00007f8fe1fdce89  sub rsp, 0xF0
00007f8fe1fdce90  vmovaps [rsp], xmm0
00007f8fe1fdce95  vmovaps [rsp+0x10], xmm1
00007f8fe1fdce9b  vmovaps [rsp+0x20], xmm2
00007f8fe1fdcea1  vmovaps [rsp+0x30], xmm3
00007f8fe1fdcea7  vmovaps [rsp+0x40], xmm4
00007f8fe1fdcead  vmovaps [rsp+0x50], xmm5
00007f8fe1fdceb3  vmovaps [rsp+0x60], xmm7
00007f8fe1fdceb9  vmovaps [rsp+0x70], xmm8
00007f8fe1fdcebf  vmovaps [rsp+0x80], xmm9
00007f8fe1fdcec8  vmovaps [rsp+0x90], xmm10
00007f8fe1fdced1  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdceda  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdcee3  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdceec  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdcef5  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdcefe  sub rsp, 0x30
00007f8fe1fdcf02  movaps [rsp], xmm6
00007f8fe1fdcf06  movaps [rsp+0x10], xmm12
00007f8fe1fdcf0c  movaps [rsp+0x20], xmm11
00007f8fe1fdcf12  lea rdi, [rsp]
00007f8fe1fdcf16  mov esi, 0x00
00007f8fe1fdcf1b  mov rax, 0x6020BB77F530
00007f8fe1fdcf25  call rax
00007f8fe1fdcf27  movaps xmm6, [rsp]
00007f8fe1fdcf2b  add rsp, 0x30
00007f8fe1fdcf2f  vmovaps xmm0, [rsp]
00007f8fe1fdcf34  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdcf3a  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdcf40  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdcf46  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdcf4c  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdcf52  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdcf58  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdcf5e  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdcf67  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdcf70  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdcf79  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdcf82  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdcf8b  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdcf94  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdcf9d  add rsp, 0xF0
00007f8fe1fdcfa4  pop r11
00007f8fe1fdcfa6  pop r10
00007f8fe1fdcfa8  pop r9
00007f8fe1fdcfaa  pop r8
00007f8fe1fdcfac  pop rsi
00007f8fe1fdcfad  pop rdi
00007f8fe1fdcfae  pop rdx
00007f8fe1fdcfaf  pop rcx
00007f8fe1fdcfb0  pop rax
00007f8fe1fdcfb1  add rsp, 0x08
00007f8fe1fdcfb5  jmp 0x00007F8FE1FDBBD4
00007f8fe1fdcfba  sub rsp, 0x08
00007f8fe1fdcfbe  push rax
00007f8fe1fdcfbf  push rcx
00007f8fe1fdcfc0  push rdx
00007f8fe1fdcfc1  push rdi
00007f8fe1fdcfc2  push rsi
00007f8fe1fdcfc3  push r8
00007f8fe1fdcfc5  push r9
00007f8fe1fdcfc7  push r10
00007f8fe1fdcfc9  push r11
00007f8fe1fdcfcb  sub rsp, 0xF0
00007f8fe1fdcfd2  vmovaps [rsp], xmm0
00007f8fe1fdcfd7  vmovaps [rsp+0x10], xmm1
00007f8fe1fdcfdd  vmovaps [rsp+0x20], xmm2
00007f8fe1fdcfe3  vmovaps [rsp+0x30], xmm4
00007f8fe1fdcfe9  vmovaps [rsp+0x40], xmm5
00007f8fe1fdcfef  vmovaps [rsp+0x50], xmm6
00007f8fe1fdcff5  vmovaps [rsp+0x60], xmm7
00007f8fe1fdcffb  vmovaps [rsp+0x70], xmm8
00007f8fe1fdd001  vmovaps [rsp+0x80], xmm9
00007f8fe1fdd00a  vmovaps [rsp+0x90], xmm10
00007f8fe1fdd013  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdd01c  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdd025  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdd02e  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdd037  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdd040  sub rsp, 0x30
00007f8fe1fdd044  movaps [rsp], xmm3
00007f8fe1fdd048  movaps [rsp+0x10], xmm5
00007f8fe1fdd04d  movaps [rsp+0x20], xmm4
00007f8fe1fdd052  lea rdi, [rsp]
00007f8fe1fdd056  mov esi, 0x00
00007f8fe1fdd05b  mov rax, 0x6020BB77F530
00007f8fe1fdd065  call rax
00007f8fe1fdd067  movaps xmm3, [rsp]
00007f8fe1fdd06b  add rsp, 0x30
00007f8fe1fdd06f  vmovaps xmm0, [rsp]
00007f8fe1fdd074  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdd07a  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdd080  vmovaps xmm4, [rsp+0x30]
00007f8fe1fdd086  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdd08c  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdd092  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdd098  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdd09e  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdd0a7  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdd0b0  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdd0b9  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdd0c2  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdd0cb  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdd0d4  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdd0dd  add rsp, 0xF0
00007f8fe1fdd0e4  pop r11
00007f8fe1fdd0e6  pop r10
00007f8fe1fdd0e8  pop r9
00007f8fe1fdd0ea  pop r8
00007f8fe1fdd0ec  pop rsi
00007f8fe1fdd0ed  pop rdi
00007f8fe1fdd0ee  pop rdx
00007f8fe1fdd0ef  pop rcx
00007f8fe1fdd0f0  pop rax
00007f8fe1fdd0f1  add rsp, 0x08
00007f8fe1fdd0f5  jmp 0x00007F8FE1FDBC35
00007f8fe1fdd0fa  sub rsp, 0x08
00007f8fe1fdd0fe  push rax
00007f8fe1fdd0ff  push rcx
00007f8fe1fdd100  push rdx
00007f8fe1fdd101  push rdi
00007f8fe1fdd102  push rsi
00007f8fe1fdd103  push r8
00007f8fe1fdd105  push r9
00007f8fe1fdd107  push r10
00007f8fe1fdd109  push r11
00007f8fe1fdd10b  sub rsp, 0xF0
00007f8fe1fdd112  vmovaps [rsp], xmm0
00007f8fe1fdd117  vmovaps [rsp+0x10], xmm1
00007f8fe1fdd11d  vmovaps [rsp+0x20], xmm2
00007f8fe1fdd123  vmovaps [rsp+0x30], xmm3
00007f8fe1fdd129  vmovaps [rsp+0x40], xmm4
00007f8fe1fdd12f  vmovaps [rsp+0x50], xmm6
00007f8fe1fdd135  vmovaps [rsp+0x60], xmm7
00007f8fe1fdd13b  vmovaps [rsp+0x70], xmm8
00007f8fe1fdd141  vmovaps [rsp+0x80], xmm9
00007f8fe1fdd14a  vmovaps [rsp+0x90], xmm10
00007f8fe1fdd153  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdd15c  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdd165  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdd16e  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdd177  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdd180  sub rsp, 0x30
00007f8fe1fdd184  movaps [rsp], xmm5
00007f8fe1fdd188  movaps [rsp+0x10], xmm8
00007f8fe1fdd18e  movaps [rsp+0x20], xmm15
00007f8fe1fdd194  lea rdi, [rsp]
00007f8fe1fdd198  mov esi, 0x00
00007f8fe1fdd19d  mov rax, 0x6020BB77F530
00007f8fe1fdd1a7  call rax
00007f8fe1fdd1a9  movaps xmm5, [rsp]
00007f8fe1fdd1ad  add rsp, 0x30
00007f8fe1fdd1b1  vmovaps xmm0, [rsp]
00007f8fe1fdd1b6  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdd1bc  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdd1c2  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdd1c8  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdd1ce  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdd1d4  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdd1da  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdd1e0  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdd1e9  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdd1f2  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdd1fb  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdd204  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdd20d  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdd216  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdd21f  add rsp, 0xF0
00007f8fe1fdd226  pop r11
00007f8fe1fdd228  pop r10
00007f8fe1fdd22a  pop r9
00007f8fe1fdd22c  pop r8
00007f8fe1fdd22e  pop rsi
00007f8fe1fdd22f  pop rdi
00007f8fe1fdd230  pop rdx
00007f8fe1fdd231  pop rcx
00007f8fe1fdd232  pop rax
00007f8fe1fdd233  add rsp, 0x08
00007f8fe1fdd237  jmp 0x00007F8FE1FDBC73
00007f8fe1fdd23c  sub rsp, 0x08
00007f8fe1fdd240  push rax
00007f8fe1fdd241  push rcx
00007f8fe1fdd242  push rdx
00007f8fe1fdd243  push rdi
00007f8fe1fdd244  push rsi
00007f8fe1fdd245  push r8
00007f8fe1fdd247  push r9
00007f8fe1fdd249  push r10
00007f8fe1fdd24b  push r11
00007f8fe1fdd24d  sub rsp, 0xF0
00007f8fe1fdd254  vmovaps [rsp], xmm0
00007f8fe1fdd259  vmovaps [rsp+0x10], xmm1
00007f8fe1fdd25f  vmovaps [rsp+0x20], xmm2
00007f8fe1fdd265  vmovaps [rsp+0x30], xmm3
00007f8fe1fdd26b  vmovaps [rsp+0x40], xmm5
00007f8fe1fdd271  vmovaps [rsp+0x50], xmm6
00007f8fe1fdd277  vmovaps [rsp+0x60], xmm7
00007f8fe1fdd27d  vmovaps [rsp+0x70], xmm8
00007f8fe1fdd283  vmovaps [rsp+0x80], xmm9
00007f8fe1fdd28c  vmovaps [rsp+0x90], xmm10
00007f8fe1fdd295  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdd29e  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdd2a7  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdd2b0  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdd2b9  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdd2c2  sub rsp, 0x30
00007f8fe1fdd2c6  movaps [rsp], xmm4
00007f8fe1fdd2ca  movaps [rsp+0x10], xmm9
00007f8fe1fdd2d0  movaps [rsp+0x20], xmm8
00007f8fe1fdd2d6  lea rdi, [rsp]
00007f8fe1fdd2da  mov esi, 0x00
00007f8fe1fdd2df  mov rax, 0x6020BB77F530
00007f8fe1fdd2e9  call rax
00007f8fe1fdd2eb  movaps xmm4, [rsp]
00007f8fe1fdd2ef  add rsp, 0x30
00007f8fe1fdd2f3  vmovaps xmm0, [rsp]
00007f8fe1fdd2f8  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdd2fe  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdd304  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdd30a  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdd310  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdd316  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdd31c  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdd322  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdd32b  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdd334  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdd33d  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdd346  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdd34f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdd358  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdd361  add rsp, 0xF0
00007f8fe1fdd368  pop r11
00007f8fe1fdd36a  pop r10
00007f8fe1fdd36c  pop r9
00007f8fe1fdd36e  pop r8
00007f8fe1fdd370  pop rsi
00007f8fe1fdd371  pop rdi
00007f8fe1fdd372  pop rdx
00007f8fe1fdd373  pop rcx
00007f8fe1fdd374  pop rax
00007f8fe1fdd375  add rsp, 0x08
00007f8fe1fdd379  jmp 0x00007F8FE1FDBC94
00007f8fe1fdd37e  sub rsp, 0x08
00007f8fe1fdd382  push rax
00007f8fe1fdd383  push rcx
00007f8fe1fdd384  push rdx
00007f8fe1fdd385  push rdi
00007f8fe1fdd386  push rsi
00007f8fe1fdd387  push r8
00007f8fe1fdd389  push r9
00007f8fe1fdd38b  push r10
00007f8fe1fdd38d  push r11
00007f8fe1fdd38f  sub rsp, 0xF0
00007f8fe1fdd396  vmovaps [rsp], xmm0
00007f8fe1fdd39b  vmovaps [rsp+0x10], xmm1
00007f8fe1fdd3a1  vmovaps [rsp+0x20], xmm2
00007f8fe1fdd3a7  vmovaps [rsp+0x30], xmm3
00007f8fe1fdd3ad  vmovaps [rsp+0x40], xmm4
00007f8fe1fdd3b3  vmovaps [rsp+0x50], xmm5
00007f8fe1fdd3b9  vmovaps [rsp+0x60], xmm6
00007f8fe1fdd3bf  vmovaps [rsp+0x70], xmm7
00007f8fe1fdd3c5  vmovaps [rsp+0x80], xmm8
00007f8fe1fdd3ce  vmovaps [rsp+0x90], xmm10
00007f8fe1fdd3d7  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdd3e0  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdd3e9  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdd3f2  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdd3fb  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdd404  sub rsp, 0x30
00007f8fe1fdd408  movaps [rsp], xmm9
00007f8fe1fdd40d  movaps [rsp+0x10], xmm10
00007f8fe1fdd413  movaps [rsp+0x20], xmm8
00007f8fe1fdd419  lea rdi, [rsp]
00007f8fe1fdd41d  mov esi, 0x00
00007f8fe1fdd422  mov rax, 0x6020BB77F530
00007f8fe1fdd42c  call rax
00007f8fe1fdd42e  movaps xmm9, [rsp]
00007f8fe1fdd433  add rsp, 0x30
00007f8fe1fdd437  vmovaps xmm0, [rsp]
00007f8fe1fdd43c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdd442  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdd448  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdd44e  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdd454  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdd45a  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdd460  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdd466  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdd46f  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdd478  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdd481  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdd48a  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdd493  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdd49c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdd4a5  add rsp, 0xF0
00007f8fe1fdd4ac  pop r11
00007f8fe1fdd4ae  pop r10
00007f8fe1fdd4b0  pop r9
00007f8fe1fdd4b2  pop r8
00007f8fe1fdd4b4  pop rsi
00007f8fe1fdd4b5  pop rdi
00007f8fe1fdd4b6  pop rdx
00007f8fe1fdd4b7  pop rcx
00007f8fe1fdd4b8  pop rax
00007f8fe1fdd4b9  add rsp, 0x08
00007f8fe1fdd4bd  jmp 0x00007F8FE1FDBCAE
00007f8fe1fdd4c2  call 0x00007F8FE1EB52F0
00007f8fe1fdd4c7  jmp 0x00007F8FE1FDBDC8
00007f8fe1fdd4cc  call 0x00007F8FE1EB52F0
00007f8fe1fdd4d1  jmp 0x00007F8FE1FDBDDE
00007f8fe1fdd4d6  sub rsp, 0x08
00007f8fe1fdd4da  push rax
00007f8fe1fdd4db  push rcx
00007f8fe1fdd4dc  push rdx
00007f8fe1fdd4dd  push rdi
00007f8fe1fdd4de  push rsi
00007f8fe1fdd4df  push r8
00007f8fe1fdd4e1  push r9
00007f8fe1fdd4e3  push r10
00007f8fe1fdd4e5  push r11
00007f8fe1fdd4e7  sub rsp, 0xF0
00007f8fe1fdd4ee  vmovaps [rsp], xmm0
00007f8fe1fdd4f3  vmovaps [rsp+0x10], xmm2
00007f8fe1fdd4f9  vmovaps [rsp+0x20], xmm3
00007f8fe1fdd4ff  vmovaps [rsp+0x30], xmm4
00007f8fe1fdd505  vmovaps [rsp+0x40], xmm5
00007f8fe1fdd50b  vmovaps [rsp+0x50], xmm6
00007f8fe1fdd511  vmovaps [rsp+0x60], xmm7
00007f8fe1fdd517  vmovaps [rsp+0x70], xmm8
00007f8fe1fdd51d  vmovaps [rsp+0x80], xmm9
00007f8fe1fdd526  vmovaps [rsp+0x90], xmm10
00007f8fe1fdd52f  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdd538  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdd541  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdd54a  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdd553  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdd55c  sub rsp, 0x30
00007f8fe1fdd560  movaps [rsp], xmm1
00007f8fe1fdd564  movaps [rsp+0x10], xmm6
00007f8fe1fdd569  movaps [rsp+0x20], xmm15
00007f8fe1fdd56f  lea rdi, [rsp]
00007f8fe1fdd573  mov esi, 0x00
00007f8fe1fdd578  mov rax, 0x6020BB77F530
00007f8fe1fdd582  call rax
00007f8fe1fdd584  movaps xmm1, [rsp]
00007f8fe1fdd588  add rsp, 0x30
00007f8fe1fdd58c  vmovaps xmm0, [rsp]
00007f8fe1fdd591  vmovaps xmm2, [rsp+0x10]
00007f8fe1fdd597  vmovaps xmm3, [rsp+0x20]
00007f8fe1fdd59d  vmovaps xmm4, [rsp+0x30]
00007f8fe1fdd5a3  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdd5a9  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdd5af  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdd5b5  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdd5bb  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdd5c4  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdd5cd  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdd5d6  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdd5df  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdd5e8  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdd5f1  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdd5fa  add rsp, 0xF0
00007f8fe1fdd601  pop r11
00007f8fe1fdd603  pop r10
00007f8fe1fdd605  pop r9
00007f8fe1fdd607  pop r8
00007f8fe1fdd609  pop rsi
00007f8fe1fdd60a  pop rdi
00007f8fe1fdd60b  pop rdx
00007f8fe1fdd60c  pop rcx
00007f8fe1fdd60d  pop rax
00007f8fe1fdd60e  add rsp, 0x08
00007f8fe1fdd612  jmp 0x00007F8FE1FDBE1B
00007f8fe1fdd617  call 0x00007F8FE1EC4620
00007f8fe1fdd61c  jmp 0x00007F8FE1FDBE28
00007f8fe1fdd621  sub rsp, 0x08
00007f8fe1fdd625  push rax
00007f8fe1fdd626  push rcx
00007f8fe1fdd627  push rdx
00007f8fe1fdd628  push rdi
00007f8fe1fdd629  push rsi
00007f8fe1fdd62a  push r8
00007f8fe1fdd62c  push r9
00007f8fe1fdd62e  push r10
00007f8fe1fdd630  push r11
00007f8fe1fdd632  sub rsp, 0xF0
00007f8fe1fdd639  vmovaps [rsp], xmm0
00007f8fe1fdd63e  vmovaps [rsp+0x10], xmm1
00007f8fe1fdd644  vmovaps [rsp+0x20], xmm2
00007f8fe1fdd64a  vmovaps [rsp+0x30], xmm3
00007f8fe1fdd650  vmovaps [rsp+0x40], xmm4
00007f8fe1fdd656  vmovaps [rsp+0x50], xmm5
00007f8fe1fdd65c  vmovaps [rsp+0x60], xmm6
00007f8fe1fdd662  vmovaps [rsp+0x70], xmm7
00007f8fe1fdd668  vmovaps [rsp+0x80], xmm8
00007f8fe1fdd671  vmovaps [rsp+0x90], xmm9
00007f8fe1fdd67a  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdd683  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdd68c  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdd695  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdd69e  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdd6a7  sub rsp, 0x30
00007f8fe1fdd6ab  movaps [rsp], xmm14
00007f8fe1fdd6b0  movaps [rsp+0x10], xmm4
00007f8fe1fdd6b5  movaps [rsp+0x20], xmm3
00007f8fe1fdd6ba  lea rdi, [rsp]
00007f8fe1fdd6be  mov esi, 0x00
00007f8fe1fdd6c3  mov rax, 0x6020BB77F530
00007f8fe1fdd6cd  call rax
00007f8fe1fdd6cf  movaps xmm14, [rsp]
00007f8fe1fdd6d4  add rsp, 0x30
00007f8fe1fdd6d8  vmovaps xmm0, [rsp]
00007f8fe1fdd6dd  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdd6e3  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdd6e9  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdd6ef  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdd6f5  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdd6fb  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdd701  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdd707  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdd710  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdd719  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdd722  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdd72b  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdd734  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdd73d  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdd746  add rsp, 0xF0
00007f8fe1fdd74d  pop r11
00007f8fe1fdd74f  pop r10
00007f8fe1fdd751  pop r9
00007f8fe1fdd753  pop r8
00007f8fe1fdd755  pop rsi
00007f8fe1fdd756  pop rdi
00007f8fe1fdd757  pop rdx
00007f8fe1fdd758  pop rcx
00007f8fe1fdd759  pop rax
00007f8fe1fdd75a  add rsp, 0x08
00007f8fe1fdd75e  jmp 0x00007F8FE1FDBE42
00007f8fe1fdd763  sub rsp, 0x08
00007f8fe1fdd767  push rax
00007f8fe1fdd768  push rcx
00007f8fe1fdd769  push rdx
00007f8fe1fdd76a  push rdi
00007f8fe1fdd76b  push rsi
00007f8fe1fdd76c  push r8
00007f8fe1fdd76e  push r9
00007f8fe1fdd770  push r10
00007f8fe1fdd772  push r11
00007f8fe1fdd774  sub rsp, 0xF0
00007f8fe1fdd77b  vmovaps [rsp], xmm0
00007f8fe1fdd780  vmovaps [rsp+0x10], xmm1
00007f8fe1fdd786  vmovaps [rsp+0x20], xmm2
00007f8fe1fdd78c  vmovaps [rsp+0x30], xmm3
00007f8fe1fdd792  vmovaps [rsp+0x40], xmm4
00007f8fe1fdd798  vmovaps [rsp+0x50], xmm5
00007f8fe1fdd79e  vmovaps [rsp+0x60], xmm7
00007f8fe1fdd7a4  vmovaps [rsp+0x70], xmm8
00007f8fe1fdd7aa  vmovaps [rsp+0x80], xmm9
00007f8fe1fdd7b3  vmovaps [rsp+0x90], xmm10
00007f8fe1fdd7bc  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdd7c5  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdd7ce  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdd7d7  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdd7e0  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdd7e9  sub rsp, 0x30
00007f8fe1fdd7ed  movaps [rsp], xmm6
00007f8fe1fdd7f1  movaps [rsp+0x10], xmm9
00007f8fe1fdd7f7  movaps [rsp+0x20], xmm7
00007f8fe1fdd7fc  lea rdi, [rsp]
00007f8fe1fdd800  mov esi, 0x00
00007f8fe1fdd805  mov rax, 0x6020BB77F530
00007f8fe1fdd80f  call rax
00007f8fe1fdd811  movaps xmm6, [rsp]
00007f8fe1fdd815  add rsp, 0x30
00007f8fe1fdd819  vmovaps xmm0, [rsp]
00007f8fe1fdd81e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdd824  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdd82a  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdd830  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdd836  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdd83c  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdd842  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdd848  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdd851  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdd85a  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdd863  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdd86c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdd875  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdd87e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdd887  add rsp, 0xF0
00007f8fe1fdd88e  pop r11
00007f8fe1fdd890  pop r10
00007f8fe1fdd892  pop r9
00007f8fe1fdd894  pop r8
00007f8fe1fdd896  pop rsi
00007f8fe1fdd897  pop rdi
00007f8fe1fdd898  pop rdx
00007f8fe1fdd899  pop rcx
00007f8fe1fdd89a  pop rax
00007f8fe1fdd89b  add rsp, 0x08
00007f8fe1fdd89f  jmp 0x00007F8FE1FDBE5A
00007f8fe1fdd8a4  sub rsp, 0x08
00007f8fe1fdd8a8  push rax
00007f8fe1fdd8a9  push rcx
00007f8fe1fdd8aa  push rdx
00007f8fe1fdd8ab  push rdi
00007f8fe1fdd8ac  push rsi
00007f8fe1fdd8ad  push r8
00007f8fe1fdd8af  push r9
00007f8fe1fdd8b1  push r10
00007f8fe1fdd8b3  push r11
00007f8fe1fdd8b5  sub rsp, 0xF0
00007f8fe1fdd8bc  vmovaps [rsp], xmm0
00007f8fe1fdd8c1  vmovaps [rsp+0x10], xmm1
00007f8fe1fdd8c7  vmovaps [rsp+0x20], xmm2
00007f8fe1fdd8cd  vmovaps [rsp+0x30], xmm3
00007f8fe1fdd8d3  vmovaps [rsp+0x40], xmm4
00007f8fe1fdd8d9  vmovaps [rsp+0x50], xmm5
00007f8fe1fdd8df  vmovaps [rsp+0x60], xmm6
00007f8fe1fdd8e5  vmovaps [rsp+0x70], xmm8
00007f8fe1fdd8eb  vmovaps [rsp+0x80], xmm9
00007f8fe1fdd8f4  vmovaps [rsp+0x90], xmm10
00007f8fe1fdd8fd  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdd906  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdd90f  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdd918  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdd921  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdd92a  sub rsp, 0x30
00007f8fe1fdd92e  movaps [rsp], xmm7
00007f8fe1fdd932  movaps [rsp+0x10], xmm4
00007f8fe1fdd937  movaps [rsp+0x20], xmm9
00007f8fe1fdd93d  lea rdi, [rsp]
00007f8fe1fdd941  mov esi, 0x00
00007f8fe1fdd946  mov rax, 0x6020BB77F530
00007f8fe1fdd950  call rax
00007f8fe1fdd952  movaps xmm7, [rsp]
00007f8fe1fdd956  add rsp, 0x30
00007f8fe1fdd95a  vmovaps xmm0, [rsp]
00007f8fe1fdd95f  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdd965  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdd96b  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdd971  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdd977  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdd97d  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdd983  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdd989  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdd992  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdd99b  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdd9a4  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdd9ad  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdd9b6  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdd9bf  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdd9c8  add rsp, 0xF0
00007f8fe1fdd9cf  pop r11
00007f8fe1fdd9d1  pop r10
00007f8fe1fdd9d3  pop r9
00007f8fe1fdd9d5  pop r8
00007f8fe1fdd9d7  pop rsi
00007f8fe1fdd9d8  pop rdi
00007f8fe1fdd9d9  pop rdx
00007f8fe1fdd9da  pop rcx
00007f8fe1fdd9db  pop rax
00007f8fe1fdd9dc  add rsp, 0x08
00007f8fe1fdd9e0  jmp 0x00007F8FE1FDBE87
00007f8fe1fdd9e5  sub rsp, 0x08
00007f8fe1fdd9e9  push rax
00007f8fe1fdd9ea  push rcx
00007f8fe1fdd9eb  push rdx
00007f8fe1fdd9ec  push rdi
00007f8fe1fdd9ed  push rsi
00007f8fe1fdd9ee  push r8
00007f8fe1fdd9f0  push r9
00007f8fe1fdd9f2  push r10
00007f8fe1fdd9f4  push r11
00007f8fe1fdd9f6  sub rsp, 0xF0
00007f8fe1fdd9fd  vmovaps [rsp], xmm0
00007f8fe1fdda02  vmovaps [rsp+0x10], xmm1
00007f8fe1fdda08  vmovaps [rsp+0x20], xmm2
00007f8fe1fdda0e  vmovaps [rsp+0x30], xmm3
00007f8fe1fdda14  vmovaps [rsp+0x40], xmm5
00007f8fe1fdda1a  vmovaps [rsp+0x50], xmm6
00007f8fe1fdda20  vmovaps [rsp+0x60], xmm7
00007f8fe1fdda26  vmovaps [rsp+0x70], xmm8
00007f8fe1fdda2c  vmovaps [rsp+0x80], xmm9
00007f8fe1fdda35  vmovaps [rsp+0x90], xmm10
00007f8fe1fdda3e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdda47  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdda50  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdda59  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdda62  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdda6b  sub rsp, 0x30
00007f8fe1fdda6f  movaps [rsp], xmm4
00007f8fe1fdda73  movaps [rsp+0x10], xmm15
00007f8fe1fdda79  movaps [rsp+0x20], xmm9
00007f8fe1fdda7f  lea rdi, [rsp]
00007f8fe1fdda83  mov esi, 0x00
00007f8fe1fdda88  mov rax, 0x6020BB77F530
00007f8fe1fdda92  call rax
00007f8fe1fdda94  movaps xmm4, [rsp]
00007f8fe1fdda98  add rsp, 0x30
00007f8fe1fdda9c  vmovaps xmm0, [rsp]
00007f8fe1fddaa1  vmovaps xmm1, [rsp+0x10]
00007f8fe1fddaa7  vmovaps xmm2, [rsp+0x20]
00007f8fe1fddaad  vmovaps xmm3, [rsp+0x30]
00007f8fe1fddab3  vmovaps xmm5, [rsp+0x40]
00007f8fe1fddab9  vmovaps xmm6, [rsp+0x50]
00007f8fe1fddabf  vmovaps xmm7, [rsp+0x60]
00007f8fe1fddac5  vmovaps xmm8, [rsp+0x70]
00007f8fe1fddacb  vmovaps xmm9, [rsp+0x80]
00007f8fe1fddad4  vmovaps xmm10, [rsp+0x90]
00007f8fe1fddadd  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fddae6  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fddaef  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fddaf8  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fddb01  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fddb0a  add rsp, 0xF0
00007f8fe1fddb11  pop r11
00007f8fe1fddb13  pop r10
00007f8fe1fddb15  pop r9
00007f8fe1fddb17  pop r8
00007f8fe1fddb19  pop rsi
00007f8fe1fddb1a  pop rdi
00007f8fe1fddb1b  pop rdx
00007f8fe1fddb1c  pop rcx
00007f8fe1fddb1d  pop rax
00007f8fe1fddb1e  add rsp, 0x08
00007f8fe1fddb22  jmp 0x00007F8FE1FDBEAC
00007f8fe1fddb27  call 0x00007F8FE1EC4620
00007f8fe1fddb2c  jmp 0x00007F8FE1FDBEB9
00007f8fe1fddb31  sub rsp, 0x08
00007f8fe1fddb35  push rax
00007f8fe1fddb36  push rcx
00007f8fe1fddb37  push rdx
00007f8fe1fddb38  push rdi
00007f8fe1fddb39  push rsi
00007f8fe1fddb3a  push r8
00007f8fe1fddb3c  push r9
00007f8fe1fddb3e  push r10
00007f8fe1fddb40  push r11
00007f8fe1fddb42  sub rsp, 0xF0
00007f8fe1fddb49  vmovaps [rsp], xmm0
00007f8fe1fddb4e  vmovaps [rsp+0x10], xmm1
00007f8fe1fddb54  vmovaps [rsp+0x20], xmm2
00007f8fe1fddb5a  vmovaps [rsp+0x30], xmm4
00007f8fe1fddb60  vmovaps [rsp+0x40], xmm5
00007f8fe1fddb66  vmovaps [rsp+0x50], xmm6
00007f8fe1fddb6c  vmovaps [rsp+0x60], xmm7
00007f8fe1fddb72  vmovaps [rsp+0x70], xmm8
00007f8fe1fddb78  vmovaps [rsp+0x80], xmm9
00007f8fe1fddb81  vmovaps [rsp+0x90], xmm10
00007f8fe1fddb8a  vmovaps [rsp+0xA0], xmm11
00007f8fe1fddb93  vmovaps [rsp+0xB0], xmm12
00007f8fe1fddb9c  vmovaps [rsp+0xC0], xmm13
00007f8fe1fddba5  vmovaps [rsp+0xD0], xmm14
00007f8fe1fddbae  vmovaps [rsp+0xE0], xmm15
00007f8fe1fddbb7  sub rsp, 0x30
00007f8fe1fddbbb  movaps [rsp], xmm3
00007f8fe1fddbbf  movaps [rsp+0x10], xmm1
00007f8fe1fddbc4  movaps [rsp+0x20], xmm9
00007f8fe1fddbca  lea rdi, [rsp]
00007f8fe1fddbce  mov esi, 0x00
00007f8fe1fddbd3  mov rax, 0x6020BB77F530
00007f8fe1fddbdd  call rax
00007f8fe1fddbdf  movaps xmm3, [rsp]
00007f8fe1fddbe3  add rsp, 0x30
00007f8fe1fddbe7  vmovaps xmm0, [rsp]
00007f8fe1fddbec  vmovaps xmm1, [rsp+0x10]
00007f8fe1fddbf2  vmovaps xmm2, [rsp+0x20]
00007f8fe1fddbf8  vmovaps xmm4, [rsp+0x30]
00007f8fe1fddbfe  vmovaps xmm5, [rsp+0x40]
00007f8fe1fddc04  vmovaps xmm6, [rsp+0x50]
00007f8fe1fddc0a  vmovaps xmm7, [rsp+0x60]
00007f8fe1fddc10  vmovaps xmm8, [rsp+0x70]
00007f8fe1fddc16  vmovaps xmm9, [rsp+0x80]
00007f8fe1fddc1f  vmovaps xmm10, [rsp+0x90]
00007f8fe1fddc28  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fddc31  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fddc3a  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fddc43  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fddc4c  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fddc55  add rsp, 0xF0
00007f8fe1fddc5c  pop r11
00007f8fe1fddc5e  pop r10
00007f8fe1fddc60  pop r9
00007f8fe1fddc62  pop r8
00007f8fe1fddc64  pop rsi
00007f8fe1fddc65  pop rdi
00007f8fe1fddc66  pop rdx
00007f8fe1fddc67  pop rcx
00007f8fe1fddc68  pop rax
00007f8fe1fddc69  add rsp, 0x08
00007f8fe1fddc6d  jmp 0x00007F8FE1FDBEF6
00007f8fe1fddc72  sub rsp, 0x08
00007f8fe1fddc76  push rax
00007f8fe1fddc77  push rcx
00007f8fe1fddc78  push rdx
00007f8fe1fddc79  push rdi
00007f8fe1fddc7a  push rsi
00007f8fe1fddc7b  push r8
00007f8fe1fddc7d  push r9
00007f8fe1fddc7f  push r10
00007f8fe1fddc81  push r11
00007f8fe1fddc83  sub rsp, 0xF0
00007f8fe1fddc8a  vmovaps [rsp], xmm0
00007f8fe1fddc8f  vmovaps [rsp+0x10], xmm2
00007f8fe1fddc95  vmovaps [rsp+0x20], xmm3
00007f8fe1fddc9b  vmovaps [rsp+0x30], xmm4
00007f8fe1fddca1  vmovaps [rsp+0x40], xmm5
00007f8fe1fddca7  vmovaps [rsp+0x50], xmm6
00007f8fe1fddcad  vmovaps [rsp+0x60], xmm7
00007f8fe1fddcb3  vmovaps [rsp+0x70], xmm8
00007f8fe1fddcb9  vmovaps [rsp+0x80], xmm9
00007f8fe1fddcc2  vmovaps [rsp+0x90], xmm10
00007f8fe1fddccb  vmovaps [rsp+0xA0], xmm11
00007f8fe1fddcd4  vmovaps [rsp+0xB0], xmm12
00007f8fe1fddcdd  vmovaps [rsp+0xC0], xmm13
00007f8fe1fddce6  vmovaps [rsp+0xD0], xmm14
00007f8fe1fddcef  vmovaps [rsp+0xE0], xmm15
00007f8fe1fddcf8  sub rsp, 0x30
00007f8fe1fddcfc  movaps [rsp], xmm1
00007f8fe1fddd00  movaps [rsp+0x10], xmm15
00007f8fe1fddd06  movaps [rsp+0x20], xmm9
00007f8fe1fddd0c  lea rdi, [rsp]
00007f8fe1fddd10  mov esi, 0x00
00007f8fe1fddd15  mov rax, 0x6020BB77F530
00007f8fe1fddd1f  call rax
00007f8fe1fddd21  movaps xmm1, [rsp]
00007f8fe1fddd25  add rsp, 0x30
00007f8fe1fddd29  vmovaps xmm0, [rsp]
00007f8fe1fddd2e  vmovaps xmm2, [rsp+0x10]
00007f8fe1fddd34  vmovaps xmm3, [rsp+0x20]
00007f8fe1fddd3a  vmovaps xmm4, [rsp+0x30]
00007f8fe1fddd40  vmovaps xmm5, [rsp+0x40]
00007f8fe1fddd46  vmovaps xmm6, [rsp+0x50]
00007f8fe1fddd4c  vmovaps xmm7, [rsp+0x60]
00007f8fe1fddd52  vmovaps xmm8, [rsp+0x70]
00007f8fe1fddd58  vmovaps xmm9, [rsp+0x80]
00007f8fe1fddd61  vmovaps xmm10, [rsp+0x90]
00007f8fe1fddd6a  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fddd73  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fddd7c  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fddd85  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fddd8e  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fddd97  add rsp, 0xF0
00007f8fe1fddd9e  pop r11
00007f8fe1fddda0  pop r10
00007f8fe1fddda2  pop r9
00007f8fe1fddda4  pop r8
00007f8fe1fddda6  pop rsi
00007f8fe1fddda7  pop rdi
00007f8fe1fddda8  pop rdx
00007f8fe1fddda9  pop rcx
00007f8fe1fdddaa  pop rax
00007f8fe1fdddab  add rsp, 0x08
00007f8fe1fdddaf  jmp 0x00007F8FE1FDBF7E
00007f8fe1fdddb4  call 0x00007F8FE1EC4620
00007f8fe1fdddb9  jmp 0x00007F8FE1FDBF8B
00007f8fe1fdddbe  sub rsp, 0x08
00007f8fe1fdddc2  push rax
00007f8fe1fdddc3  push rcx
00007f8fe1fdddc4  push rdx
00007f8fe1fdddc5  push rdi
00007f8fe1fdddc6  push rsi
00007f8fe1fdddc7  push r8
00007f8fe1fdddc9  push r9
00007f8fe1fdddcb  push r10
00007f8fe1fdddcd  push r11
00007f8fe1fdddcf  sub rsp, 0xF0
00007f8fe1fdddd6  vmovaps [rsp], xmm0
00007f8fe1fddddb  vmovaps [rsp+0x10], xmm2
00007f8fe1fddde1  vmovaps [rsp+0x20], xmm3
00007f8fe1fddde7  vmovaps [rsp+0x30], xmm4
00007f8fe1fddded  vmovaps [rsp+0x40], xmm5
00007f8fe1fdddf3  vmovaps [rsp+0x50], xmm6
00007f8fe1fdddf9  vmovaps [rsp+0x60], xmm7
00007f8fe1fdddff  vmovaps [rsp+0x70], xmm8
00007f8fe1fdde05  vmovaps [rsp+0x80], xmm9
00007f8fe1fdde0e  vmovaps [rsp+0x90], xmm10
00007f8fe1fdde17  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdde20  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdde29  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdde32  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdde3b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdde44  sub rsp, 0x30
00007f8fe1fdde48  movaps [rsp], xmm1
00007f8fe1fdde4c  movaps [rsp+0x10], xmm5
00007f8fe1fdde51  movaps [rsp+0x20], xmm7
00007f8fe1fdde56  lea rdi, [rsp]
00007f8fe1fdde5a  mov esi, 0x00
00007f8fe1fdde5f  mov rax, 0x6020BB77F530
00007f8fe1fdde69  call rax
00007f8fe1fdde6b  movaps xmm1, [rsp]
00007f8fe1fdde6f  add rsp, 0x30
00007f8fe1fdde73  vmovaps xmm0, [rsp]
00007f8fe1fdde78  vmovaps xmm2, [rsp+0x10]
00007f8fe1fdde7e  vmovaps xmm3, [rsp+0x20]
00007f8fe1fdde84  vmovaps xmm4, [rsp+0x30]
00007f8fe1fdde8a  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdde90  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdde96  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdde9c  vmovaps xmm8, [rsp+0x70]
00007f8fe1fddea2  vmovaps xmm9, [rsp+0x80]
00007f8fe1fddeab  vmovaps xmm10, [rsp+0x90]
00007f8fe1fddeb4  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fddebd  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fddec6  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fddecf  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdded8  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fddee1  add rsp, 0xF0
00007f8fe1fddee8  pop r11
00007f8fe1fddeea  pop r10
00007f8fe1fddeec  pop r9
00007f8fe1fddeee  pop r8
00007f8fe1fddef0  pop rsi
00007f8fe1fddef1  pop rdi
00007f8fe1fddef2  pop rdx
00007f8fe1fddef3  pop rcx
00007f8fe1fddef4  pop rax
00007f8fe1fddef5  add rsp, 0x08
00007f8fe1fddef9  jmp 0x00007F8FE1FDC030
00007f8fe1fddefe  sub rsp, 0x08
00007f8fe1fddf02  push rax
00007f8fe1fddf03  push rcx
00007f8fe1fddf04  push rdx
00007f8fe1fddf05  push rdi
00007f8fe1fddf06  push rsi
00007f8fe1fddf07  push r8
00007f8fe1fddf09  push r9
00007f8fe1fddf0b  push r10
00007f8fe1fddf0d  push r11
00007f8fe1fddf0f  sub rsp, 0xF0
00007f8fe1fddf16  vmovaps [rsp], xmm0
00007f8fe1fddf1b  vmovaps [rsp+0x10], xmm1
00007f8fe1fddf21  vmovaps [rsp+0x20], xmm2
00007f8fe1fddf27  vmovaps [rsp+0x30], xmm3
00007f8fe1fddf2d  vmovaps [rsp+0x40], xmm4
00007f8fe1fddf33  vmovaps [rsp+0x50], xmm5
00007f8fe1fddf39  vmovaps [rsp+0x60], xmm6
00007f8fe1fddf3f  vmovaps [rsp+0x70], xmm8
00007f8fe1fddf45  vmovaps [rsp+0x80], xmm9
00007f8fe1fddf4e  vmovaps [rsp+0x90], xmm10
00007f8fe1fddf57  vmovaps [rsp+0xA0], xmm11
00007f8fe1fddf60  vmovaps [rsp+0xB0], xmm12
00007f8fe1fddf69  vmovaps [rsp+0xC0], xmm13
00007f8fe1fddf72  vmovaps [rsp+0xD0], xmm14
00007f8fe1fddf7b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fddf84  sub rsp, 0x30
00007f8fe1fddf88  movaps [rsp], xmm7
00007f8fe1fddf8c  movaps [rsp+0x10], xmm5
00007f8fe1fddf91  movaps [rsp+0x20], xmm15
00007f8fe1fddf97  lea rdi, [rsp]
00007f8fe1fddf9b  mov esi, 0x00
00007f8fe1fddfa0  mov rax, 0x6020BB77F530
00007f8fe1fddfaa  call rax
00007f8fe1fddfac  movaps xmm7, [rsp]
00007f8fe1fddfb0  add rsp, 0x30
00007f8fe1fddfb4  vmovaps xmm0, [rsp]
00007f8fe1fddfb9  vmovaps xmm1, [rsp+0x10]
00007f8fe1fddfbf  vmovaps xmm2, [rsp+0x20]
00007f8fe1fddfc5  vmovaps xmm3, [rsp+0x30]
00007f8fe1fddfcb  vmovaps xmm4, [rsp+0x40]
00007f8fe1fddfd1  vmovaps xmm5, [rsp+0x50]
00007f8fe1fddfd7  vmovaps xmm6, [rsp+0x60]
00007f8fe1fddfdd  vmovaps xmm8, [rsp+0x70]
00007f8fe1fddfe3  vmovaps xmm9, [rsp+0x80]
00007f8fe1fddfec  vmovaps xmm10, [rsp+0x90]
00007f8fe1fddff5  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fddffe  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fde007  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fde010  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fde019  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fde022  add rsp, 0xF0
00007f8fe1fde029  pop r11
00007f8fe1fde02b  pop r10
00007f8fe1fde02d  pop r9
00007f8fe1fde02f  pop r8
00007f8fe1fde031  pop rsi
00007f8fe1fde032  pop rdi
00007f8fe1fde033  pop rdx
00007f8fe1fde034  pop rcx
00007f8fe1fde035  pop rax
00007f8fe1fde036  add rsp, 0x08
00007f8fe1fde03a  jmp 0x00007F8FE1FDC066
00007f8fe1fde03f  call 0x00007F8FE1EB52F0
00007f8fe1fde044  jmp 0x00007F8FE1FDC073
00007f8fe1fde049  sub rsp, 0x08
00007f8fe1fde04d  push rax
00007f8fe1fde04e  push rcx
00007f8fe1fde04f  push rdx
00007f8fe1fde050  push rdi
00007f8fe1fde051  push rsi
00007f8fe1fde052  push r8
00007f8fe1fde054  push r9
00007f8fe1fde056  push r10
00007f8fe1fde058  push r11
00007f8fe1fde05a  sub rsp, 0xF0
00007f8fe1fde061  vmovaps [rsp], xmm0
00007f8fe1fde066  vmovaps [rsp+0x10], xmm1
00007f8fe1fde06c  vmovaps [rsp+0x20], xmm2
00007f8fe1fde072  vmovaps [rsp+0x30], xmm3
00007f8fe1fde078  vmovaps [rsp+0x40], xmm4
00007f8fe1fde07e  vmovaps [rsp+0x50], xmm5
00007f8fe1fde084  vmovaps [rsp+0x60], xmm6
00007f8fe1fde08a  vmovaps [rsp+0x70], xmm7
00007f8fe1fde090  vmovaps [rsp+0x80], xmm8
00007f8fe1fde099  vmovaps [rsp+0x90], xmm9
00007f8fe1fde0a2  vmovaps [rsp+0xA0], xmm10
00007f8fe1fde0ab  vmovaps [rsp+0xB0], xmm11
00007f8fe1fde0b4  vmovaps [rsp+0xC0], xmm12
00007f8fe1fde0bd  vmovaps [rsp+0xD0], xmm13
00007f8fe1fde0c6  vmovaps [rsp+0xE0], xmm14
00007f8fe1fde0cf  sub rsp, 0x30
00007f8fe1fde0d3  movaps [rsp], xmm15
00007f8fe1fde0d8  movaps [rsp+0x10], xmm5
00007f8fe1fde0dd  movaps [rsp+0x20], xmm3
00007f8fe1fde0e2  lea rdi, [rsp]
00007f8fe1fde0e6  mov esi, 0x00
00007f8fe1fde0eb  mov rax, 0x6020BB77F530
00007f8fe1fde0f5  call rax
00007f8fe1fde0f7  movaps xmm15, [rsp]
00007f8fe1fde0fc  add rsp, 0x30
00007f8fe1fde100  vmovaps xmm0, [rsp]
00007f8fe1fde105  vmovaps xmm1, [rsp+0x10]
00007f8fe1fde10b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fde111  vmovaps xmm3, [rsp+0x30]
00007f8fe1fde117  vmovaps xmm4, [rsp+0x40]
00007f8fe1fde11d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fde123  vmovaps xmm6, [rsp+0x60]
00007f8fe1fde129  vmovaps xmm7, [rsp+0x70]
00007f8fe1fde12f  vmovaps xmm8, [rsp+0x80]
00007f8fe1fde138  vmovaps xmm9, [rsp+0x90]
00007f8fe1fde141  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fde14a  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fde153  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fde15c  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fde165  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fde16e  add rsp, 0xF0
00007f8fe1fde175  pop r11
00007f8fe1fde177  pop r10
00007f8fe1fde179  pop r9
00007f8fe1fde17b  pop r8
00007f8fe1fde17d  pop rsi
00007f8fe1fde17e  pop rdi
00007f8fe1fde17f  pop rdx
00007f8fe1fde180  pop rcx
00007f8fe1fde181  pop rax
00007f8fe1fde182  add rsp, 0x08
00007f8fe1fde186  jmp 0x00007F8FE1FDC099
00007f8fe1fde18b  sub rsp, 0x08
00007f8fe1fde18f  push rax
00007f8fe1fde190  push rcx
00007f8fe1fde191  push rdx
00007f8fe1fde192  push rdi
00007f8fe1fde193  push rsi
00007f8fe1fde194  push r8
00007f8fe1fde196  push r9
00007f8fe1fde198  push r10
00007f8fe1fde19a  push r11
00007f8fe1fde19c  sub rsp, 0xF0
00007f8fe1fde1a3  vmovaps [rsp], xmm0
00007f8fe1fde1a8  vmovaps [rsp+0x10], xmm2
00007f8fe1fde1ae  vmovaps [rsp+0x20], xmm3
00007f8fe1fde1b4  vmovaps [rsp+0x30], xmm4
00007f8fe1fde1ba  vmovaps [rsp+0x40], xmm5
00007f8fe1fde1c0  vmovaps [rsp+0x50], xmm6
00007f8fe1fde1c6  vmovaps [rsp+0x60], xmm7
00007f8fe1fde1cc  vmovaps [rsp+0x70], xmm8
00007f8fe1fde1d2  vmovaps [rsp+0x80], xmm9
00007f8fe1fde1db  vmovaps [rsp+0x90], xmm10
00007f8fe1fde1e4  vmovaps [rsp+0xA0], xmm11
00007f8fe1fde1ed  vmovaps [rsp+0xB0], xmm12
00007f8fe1fde1f6  vmovaps [rsp+0xC0], xmm13
00007f8fe1fde1ff  vmovaps [rsp+0xD0], xmm14
00007f8fe1fde208  vmovaps [rsp+0xE0], xmm15
00007f8fe1fde211  sub rsp, 0x30
00007f8fe1fde215  movaps [rsp], xmm1
00007f8fe1fde219  movaps [rsp+0x10], xmm5
00007f8fe1fde21e  movaps [rsp+0x20], xmm4
00007f8fe1fde223  lea rdi, [rsp]
00007f8fe1fde227  mov esi, 0x00
00007f8fe1fde22c  mov rax, 0x6020BB77F530
00007f8fe1fde236  call rax
00007f8fe1fde238  movaps xmm1, [rsp]
00007f8fe1fde23c  add rsp, 0x30
00007f8fe1fde240  vmovaps xmm0, [rsp]
00007f8fe1fde245  vmovaps xmm2, [rsp+0x10]
00007f8fe1fde24b  vmovaps xmm3, [rsp+0x20]
00007f8fe1fde251  vmovaps xmm4, [rsp+0x30]
00007f8fe1fde257  vmovaps xmm5, [rsp+0x40]
00007f8fe1fde25d  vmovaps xmm6, [rsp+0x50]
00007f8fe1fde263  vmovaps xmm7, [rsp+0x60]
00007f8fe1fde269  vmovaps xmm8, [rsp+0x70]
00007f8fe1fde26f  vmovaps xmm9, [rsp+0x80]
00007f8fe1fde278  vmovaps xmm10, [rsp+0x90]
00007f8fe1fde281  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fde28a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fde293  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fde29c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fde2a5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fde2ae  add rsp, 0xF0
00007f8fe1fde2b5  pop r11
00007f8fe1fde2b7  pop r10
00007f8fe1fde2b9  pop r9
00007f8fe1fde2bb  pop r8
00007f8fe1fde2bd  pop rsi
00007f8fe1fde2be  pop rdi
00007f8fe1fde2bf  pop rdx
00007f8fe1fde2c0  pop rcx
00007f8fe1fde2c1  pop rax
00007f8fe1fde2c2  add rsp, 0x08
00007f8fe1fde2c6  jmp 0x00007F8FE1FDC0B9
00007f8fe1fde2cb  sub rsp, 0x08
00007f8fe1fde2cf  push rax
00007f8fe1fde2d0  push rcx
00007f8fe1fde2d1  push rdx
00007f8fe1fde2d2  push rdi
00007f8fe1fde2d3  push rsi
00007f8fe1fde2d4  push r8
00007f8fe1fde2d6  push r9
00007f8fe1fde2d8  push r10
00007f8fe1fde2da  push r11
00007f8fe1fde2dc  sub rsp, 0xF0
00007f8fe1fde2e3  vmovaps [rsp], xmm0
00007f8fe1fde2e8  vmovaps [rsp+0x10], xmm1
00007f8fe1fde2ee  vmovaps [rsp+0x20], xmm2
00007f8fe1fde2f4  vmovaps [rsp+0x30], xmm3
00007f8fe1fde2fa  vmovaps [rsp+0x40], xmm5
00007f8fe1fde300  vmovaps [rsp+0x50], xmm6
00007f8fe1fde306  vmovaps [rsp+0x60], xmm7
00007f8fe1fde30c  vmovaps [rsp+0x70], xmm8
00007f8fe1fde312  vmovaps [rsp+0x80], xmm9
00007f8fe1fde31b  vmovaps [rsp+0x90], xmm10
00007f8fe1fde324  vmovaps [rsp+0xA0], xmm11
00007f8fe1fde32d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fde336  vmovaps [rsp+0xC0], xmm13
00007f8fe1fde33f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fde348  vmovaps [rsp+0xE0], xmm15
00007f8fe1fde351  sub rsp, 0x30
00007f8fe1fde355  movaps [rsp], xmm4
00007f8fe1fde359  movaps [rsp+0x10], xmm3
00007f8fe1fde35e  movaps [rsp+0x20], xmm5
00007f8fe1fde363  lea rdi, [rsp]
00007f8fe1fde367  mov esi, 0x00
00007f8fe1fde36c  mov rax, 0x6020BB77F530
00007f8fe1fde376  call rax
00007f8fe1fde378  movaps xmm4, [rsp]
00007f8fe1fde37c  add rsp, 0x30
00007f8fe1fde380  vmovaps xmm0, [rsp]
00007f8fe1fde385  vmovaps xmm1, [rsp+0x10]
00007f8fe1fde38b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fde391  vmovaps xmm3, [rsp+0x30]
00007f8fe1fde397  vmovaps xmm5, [rsp+0x40]
00007f8fe1fde39d  vmovaps xmm6, [rsp+0x50]
00007f8fe1fde3a3  vmovaps xmm7, [rsp+0x60]
00007f8fe1fde3a9  vmovaps xmm8, [rsp+0x70]
00007f8fe1fde3af  vmovaps xmm9, [rsp+0x80]
00007f8fe1fde3b8  vmovaps xmm10, [rsp+0x90]
00007f8fe1fde3c1  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fde3ca  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fde3d3  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fde3dc  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fde3e5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fde3ee  add rsp, 0xF0
00007f8fe1fde3f5  pop r11
00007f8fe1fde3f7  pop r10
00007f8fe1fde3f9  pop r9
00007f8fe1fde3fb  pop r8
00007f8fe1fde3fd  pop rsi
00007f8fe1fde3fe  pop rdi
00007f8fe1fde3ff  pop rdx
00007f8fe1fde400  pop rcx
00007f8fe1fde401  pop rax
00007f8fe1fde402  add rsp, 0x08
00007f8fe1fde406  jmp 0x00007F8FE1FDC107
00007f8fe1fde40b  call 0x00007F8FE1EB52F0
00007f8fe1fde410  jmp 0x00007F8FE1FDC114
00007f8fe1fde415  sub rsp, 0x08
00007f8fe1fde419  push rax
00007f8fe1fde41a  push rcx
00007f8fe1fde41b  push rdx
00007f8fe1fde41c  push rdi
00007f8fe1fde41d  push rsi
00007f8fe1fde41e  push r8
00007f8fe1fde420  push r9
00007f8fe1fde422  push r10
00007f8fe1fde424  push r11
00007f8fe1fde426  sub rsp, 0xF0
00007f8fe1fde42d  vmovaps [rsp], xmm0
00007f8fe1fde432  vmovaps [rsp+0x10], xmm1
00007f8fe1fde438  vmovaps [rsp+0x20], xmm2
00007f8fe1fde43e  vmovaps [rsp+0x30], xmm3
00007f8fe1fde444  vmovaps [rsp+0x40], xmm4
00007f8fe1fde44a  vmovaps [rsp+0x50], xmm6
00007f8fe1fde450  vmovaps [rsp+0x60], xmm7
00007f8fe1fde456  vmovaps [rsp+0x70], xmm8
00007f8fe1fde45c  vmovaps [rsp+0x80], xmm9
00007f8fe1fde465  vmovaps [rsp+0x90], xmm10
00007f8fe1fde46e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fde477  vmovaps [rsp+0xB0], xmm12
00007f8fe1fde480  vmovaps [rsp+0xC0], xmm13
00007f8fe1fde489  vmovaps [rsp+0xD0], xmm14
00007f8fe1fde492  vmovaps [rsp+0xE0], xmm15
00007f8fe1fde49b  sub rsp, 0x30
00007f8fe1fde49f  movaps [rsp], xmm5
00007f8fe1fde4a3  movaps [rsp+0x10], xmm6
00007f8fe1fde4a8  movaps [rsp+0x20], xmm3
00007f8fe1fde4ad  lea rdi, [rsp]
00007f8fe1fde4b1  mov esi, 0x00
00007f8fe1fde4b6  mov rax, 0x6020BB77F530
00007f8fe1fde4c0  call rax
00007f8fe1fde4c2  movaps xmm5, [rsp]
00007f8fe1fde4c6  add rsp, 0x30
00007f8fe1fde4ca  vmovaps xmm0, [rsp]
00007f8fe1fde4cf  vmovaps xmm1, [rsp+0x10]
00007f8fe1fde4d5  vmovaps xmm2, [rsp+0x20]
00007f8fe1fde4db  vmovaps xmm3, [rsp+0x30]
00007f8fe1fde4e1  vmovaps xmm4, [rsp+0x40]
00007f8fe1fde4e7  vmovaps xmm6, [rsp+0x50]
00007f8fe1fde4ed  vmovaps xmm7, [rsp+0x60]
00007f8fe1fde4f3  vmovaps xmm8, [rsp+0x70]
00007f8fe1fde4f9  vmovaps xmm9, [rsp+0x80]
00007f8fe1fde502  vmovaps xmm10, [rsp+0x90]
00007f8fe1fde50b  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fde514  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fde51d  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fde526  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fde52f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fde538  add rsp, 0xF0
00007f8fe1fde53f  pop r11
00007f8fe1fde541  pop r10
00007f8fe1fde543  pop r9
00007f8fe1fde545  pop r8
00007f8fe1fde547  pop rsi
00007f8fe1fde548  pop rdi
00007f8fe1fde549  pop rdx
00007f8fe1fde54a  pop rcx
00007f8fe1fde54b  pop rax
00007f8fe1fde54c  add rsp, 0x08
00007f8fe1fde550  jmp 0x00007F8FE1FDC13A
00007f8fe1fde555  sub rsp, 0x08
00007f8fe1fde559  push rax
00007f8fe1fde55a  push rcx
00007f8fe1fde55b  push rdx
00007f8fe1fde55c  push rdi
00007f8fe1fde55d  push rsi
00007f8fe1fde55e  push r8
00007f8fe1fde560  push r9
00007f8fe1fde562  push r10
00007f8fe1fde564  push r11
00007f8fe1fde566  sub rsp, 0xF0
00007f8fe1fde56d  vmovaps [rsp], xmm0
00007f8fe1fde572  vmovaps [rsp+0x10], xmm1
00007f8fe1fde578  vmovaps [rsp+0x20], xmm2
00007f8fe1fde57e  vmovaps [rsp+0x30], xmm3
00007f8fe1fde584  vmovaps [rsp+0x40], xmm4
00007f8fe1fde58a  vmovaps [rsp+0x50], xmm5
00007f8fe1fde590  vmovaps [rsp+0x60], xmm7
00007f8fe1fde596  vmovaps [rsp+0x70], xmm8
00007f8fe1fde59c  vmovaps [rsp+0x80], xmm9
00007f8fe1fde5a5  vmovaps [rsp+0x90], xmm10
00007f8fe1fde5ae  vmovaps [rsp+0xA0], xmm11
00007f8fe1fde5b7  vmovaps [rsp+0xB0], xmm12
00007f8fe1fde5c0  vmovaps [rsp+0xC0], xmm13
00007f8fe1fde5c9  vmovaps [rsp+0xD0], xmm14
00007f8fe1fde5d2  vmovaps [rsp+0xE0], xmm15
00007f8fe1fde5db  sub rsp, 0x30
00007f8fe1fde5df  movaps [rsp], xmm6
00007f8fe1fde5e3  movaps [rsp+0x10], xmm9
00007f8fe1fde5e9  movaps [rsp+0x20], xmm1
00007f8fe1fde5ee  lea rdi, [rsp]
00007f8fe1fde5f2  mov esi, 0x00
00007f8fe1fde5f7  mov rax, 0x6020BB77F530
00007f8fe1fde601  call rax
00007f8fe1fde603  movaps xmm6, [rsp]
00007f8fe1fde607  add rsp, 0x30
00007f8fe1fde60b  vmovaps xmm0, [rsp]
00007f8fe1fde610  vmovaps xmm1, [rsp+0x10]
00007f8fe1fde616  vmovaps xmm2, [rsp+0x20]
00007f8fe1fde61c  vmovaps xmm3, [rsp+0x30]
00007f8fe1fde622  vmovaps xmm4, [rsp+0x40]
00007f8fe1fde628  vmovaps xmm5, [rsp+0x50]
00007f8fe1fde62e  vmovaps xmm7, [rsp+0x60]
00007f8fe1fde634  vmovaps xmm8, [rsp+0x70]
00007f8fe1fde63a  vmovaps xmm9, [rsp+0x80]
00007f8fe1fde643  vmovaps xmm10, [rsp+0x90]
00007f8fe1fde64c  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fde655  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fde65e  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fde667  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fde670  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fde679  add rsp, 0xF0
00007f8fe1fde680  pop r11
00007f8fe1fde682  pop r10
00007f8fe1fde684  pop r9
00007f8fe1fde686  pop r8
00007f8fe1fde688  pop rsi
00007f8fe1fde689  pop rdi
00007f8fe1fde68a  pop rdx
00007f8fe1fde68b  pop rcx
00007f8fe1fde68c  pop rax
00007f8fe1fde68d  add rsp, 0x08
00007f8fe1fde691  jmp 0x00007F8FE1FDC15E
00007f8fe1fde696  sub rsp, 0x08
00007f8fe1fde69a  push rax
00007f8fe1fde69b  push rcx
00007f8fe1fde69c  push rdx
00007f8fe1fde69d  push rdi
00007f8fe1fde69e  push rsi
00007f8fe1fde69f  push r8
00007f8fe1fde6a1  push r9
00007f8fe1fde6a3  push r10
00007f8fe1fde6a5  push r11
00007f8fe1fde6a7  sub rsp, 0xF0
00007f8fe1fde6ae  vmovaps [rsp], xmm0
00007f8fe1fde6b3  vmovaps [rsp+0x10], xmm1
00007f8fe1fde6b9  vmovaps [rsp+0x20], xmm2
00007f8fe1fde6bf  vmovaps [rsp+0x30], xmm3
00007f8fe1fde6c5  vmovaps [rsp+0x40], xmm4
00007f8fe1fde6cb  vmovaps [rsp+0x50], xmm5
00007f8fe1fde6d1  vmovaps [rsp+0x60], xmm6
00007f8fe1fde6d7  vmovaps [rsp+0x70], xmm7
00007f8fe1fde6dd  vmovaps [rsp+0x80], xmm8
00007f8fe1fde6e6  vmovaps [rsp+0x90], xmm10
00007f8fe1fde6ef  vmovaps [rsp+0xA0], xmm11
00007f8fe1fde6f8  vmovaps [rsp+0xB0], xmm12
00007f8fe1fde701  vmovaps [rsp+0xC0], xmm13
00007f8fe1fde70a  vmovaps [rsp+0xD0], xmm14
00007f8fe1fde713  vmovaps [rsp+0xE0], xmm15
00007f8fe1fde71c  sub rsp, 0x30
00007f8fe1fde720  movaps [rsp], xmm9
00007f8fe1fde725  movaps [rsp+0x10], xmm3
00007f8fe1fde72a  movaps [rsp+0x20], xmm1
00007f8fe1fde72f  lea rdi, [rsp]
00007f8fe1fde733  mov esi, 0x00
00007f8fe1fde738  mov rax, 0x6020BB77F530
00007f8fe1fde742  call rax
00007f8fe1fde744  movaps xmm9, [rsp]
00007f8fe1fde749  add rsp, 0x30
00007f8fe1fde74d  vmovaps xmm0, [rsp]
00007f8fe1fde752  vmovaps xmm1, [rsp+0x10]
00007f8fe1fde758  vmovaps xmm2, [rsp+0x20]
00007f8fe1fde75e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fde764  vmovaps xmm4, [rsp+0x40]
00007f8fe1fde76a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fde770  vmovaps xmm6, [rsp+0x60]
00007f8fe1fde776  vmovaps xmm7, [rsp+0x70]
00007f8fe1fde77c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fde785  vmovaps xmm10, [rsp+0x90]
00007f8fe1fde78e  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fde797  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fde7a0  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fde7a9  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fde7b2  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fde7bb  add rsp, 0xF0
00007f8fe1fde7c2  pop r11
00007f8fe1fde7c4  pop r10
00007f8fe1fde7c6  pop r9
00007f8fe1fde7c8  pop r8
00007f8fe1fde7ca  pop rsi
00007f8fe1fde7cb  pop rdi
00007f8fe1fde7cc  pop rdx
00007f8fe1fde7cd  pop rcx
00007f8fe1fde7ce  pop rax
00007f8fe1fde7cf  add rsp, 0x08
00007f8fe1fde7d3  jmp 0x00007F8FE1FDC1AA
00007f8fe1fde7d8  call 0x00007F8FE1EB52F0
00007f8fe1fde7dd  jmp 0x00007F8FE1FDC1B7
00007f8fe1fde7e2  sub rsp, 0x08
00007f8fe1fde7e6  push rax
00007f8fe1fde7e7  push rcx
00007f8fe1fde7e8  push rdx
00007f8fe1fde7e9  push rdi
00007f8fe1fde7ea  push rsi
00007f8fe1fde7eb  push r8
00007f8fe1fde7ed  push r9
00007f8fe1fde7ef  push r10
00007f8fe1fde7f1  push r11
00007f8fe1fde7f3  sub rsp, 0xF0
00007f8fe1fde7fa  vmovaps [rsp], xmm0
00007f8fe1fde7ff  vmovaps [rsp+0x10], xmm1
00007f8fe1fde805  vmovaps [rsp+0x20], xmm2
00007f8fe1fde80b  vmovaps [rsp+0x30], xmm3
00007f8fe1fde811  vmovaps [rsp+0x40], xmm4
00007f8fe1fde817  vmovaps [rsp+0x50], xmm5
00007f8fe1fde81d  vmovaps [rsp+0x60], xmm6
00007f8fe1fde823  vmovaps [rsp+0x70], xmm7
00007f8fe1fde829  vmovaps [rsp+0x80], xmm8
00007f8fe1fde832  vmovaps [rsp+0x90], xmm9
00007f8fe1fde83b  vmovaps [rsp+0xA0], xmm10
00007f8fe1fde844  vmovaps [rsp+0xB0], xmm11
00007f8fe1fde84d  vmovaps [rsp+0xC0], xmm12
00007f8fe1fde856  vmovaps [rsp+0xD0], xmm13
00007f8fe1fde85f  vmovaps [rsp+0xE0], xmm14
00007f8fe1fde868  sub rsp, 0x30
00007f8fe1fde86c  movaps [rsp], xmm15
00007f8fe1fde871  movaps [rsp+0x10], xmm3
00007f8fe1fde876  movaps [rsp+0x20], xmm7
00007f8fe1fde87b  lea rdi, [rsp]
00007f8fe1fde87f  mov esi, 0x00
00007f8fe1fde884  mov rax, 0x6020BB77F530
00007f8fe1fde88e  call rax
00007f8fe1fde890  movaps xmm15, [rsp]
00007f8fe1fde895  add rsp, 0x30
00007f8fe1fde899  vmovaps xmm0, [rsp]
00007f8fe1fde89e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fde8a4  vmovaps xmm2, [rsp+0x20]
00007f8fe1fde8aa  vmovaps xmm3, [rsp+0x30]
00007f8fe1fde8b0  vmovaps xmm4, [rsp+0x40]
00007f8fe1fde8b6  vmovaps xmm5, [rsp+0x50]
00007f8fe1fde8bc  vmovaps xmm6, [rsp+0x60]
00007f8fe1fde8c2  vmovaps xmm7, [rsp+0x70]
00007f8fe1fde8c8  vmovaps xmm8, [rsp+0x80]
00007f8fe1fde8d1  vmovaps xmm9, [rsp+0x90]
00007f8fe1fde8da  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fde8e3  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fde8ec  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fde8f5  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fde8fe  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fde907  add rsp, 0xF0
00007f8fe1fde90e  pop r11
00007f8fe1fde910  pop r10
00007f8fe1fde912  pop r9
00007f8fe1fde914  pop r8
00007f8fe1fde916  pop rsi
00007f8fe1fde917  pop rdi
00007f8fe1fde918  pop rdx
00007f8fe1fde919  pop rcx
00007f8fe1fde91a  pop rax
00007f8fe1fde91b  add rsp, 0x08
00007f8fe1fde91f  jmp 0x00007F8FE1FDC1E3
00007f8fe1fde924  sub rsp, 0x08
00007f8fe1fde928  push rax
00007f8fe1fde929  push rcx
00007f8fe1fde92a  push rdx
00007f8fe1fde92b  push rdi
00007f8fe1fde92c  push rsi
00007f8fe1fde92d  push r8
00007f8fe1fde92f  push r9
00007f8fe1fde931  push r10
00007f8fe1fde933  push r11
00007f8fe1fde935  sub rsp, 0xF0
00007f8fe1fde93c  vmovaps [rsp], xmm0
00007f8fe1fde941  vmovaps [rsp+0x10], xmm1
00007f8fe1fde947  vmovaps [rsp+0x20], xmm2
00007f8fe1fde94d  vmovaps [rsp+0x30], xmm4
00007f8fe1fde953  vmovaps [rsp+0x40], xmm5
00007f8fe1fde959  vmovaps [rsp+0x50], xmm6
00007f8fe1fde95f  vmovaps [rsp+0x60], xmm7
00007f8fe1fde965  vmovaps [rsp+0x70], xmm8
00007f8fe1fde96b  vmovaps [rsp+0x80], xmm9
00007f8fe1fde974  vmovaps [rsp+0x90], xmm10
00007f8fe1fde97d  vmovaps [rsp+0xA0], xmm11
00007f8fe1fde986  vmovaps [rsp+0xB0], xmm12
00007f8fe1fde98f  vmovaps [rsp+0xC0], xmm13
00007f8fe1fde998  vmovaps [rsp+0xD0], xmm14
00007f8fe1fde9a1  vmovaps [rsp+0xE0], xmm15
00007f8fe1fde9aa  sub rsp, 0x30
00007f8fe1fde9ae  movaps [rsp], xmm3
00007f8fe1fde9b2  movaps [rsp+0x10], xmm1
00007f8fe1fde9b7  movaps [rsp+0x20], xmm15
00007f8fe1fde9bd  lea rdi, [rsp]
00007f8fe1fde9c1  mov esi, 0x00
00007f8fe1fde9c6  mov rax, 0x6020BB77F530
00007f8fe1fde9d0  call rax
00007f8fe1fde9d2  movaps xmm3, [rsp]
00007f8fe1fde9d6  add rsp, 0x30
00007f8fe1fde9da  vmovaps xmm0, [rsp]
00007f8fe1fde9df  vmovaps xmm1, [rsp+0x10]
00007f8fe1fde9e5  vmovaps xmm2, [rsp+0x20]
00007f8fe1fde9eb  vmovaps xmm4, [rsp+0x30]
00007f8fe1fde9f1  vmovaps xmm5, [rsp+0x40]
00007f8fe1fde9f7  vmovaps xmm6, [rsp+0x50]
00007f8fe1fde9fd  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdea03  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdea09  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdea12  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdea1b  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdea24  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdea2d  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdea36  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdea3f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdea48  add rsp, 0xF0
00007f8fe1fdea4f  pop r11
00007f8fe1fdea51  pop r10
00007f8fe1fdea53  pop r9
00007f8fe1fdea55  pop r8
00007f8fe1fdea57  pop rsi
00007f8fe1fdea58  pop rdi
00007f8fe1fdea59  pop rdx
00007f8fe1fdea5a  pop rcx
00007f8fe1fdea5b  pop rax
00007f8fe1fdea5c  add rsp, 0x08
00007f8fe1fdea60  jmp 0x00007F8FE1FDC272
00007f8fe1fdea65  call 0x00007F8FE1EB52F0
00007f8fe1fdea6a  jmp 0x00007F8FE1FDC27C
00007f8fe1fdea6f  sub rsp, 0x08
00007f8fe1fdea73  push rax
00007f8fe1fdea74  push rcx
00007f8fe1fdea75  push rdx
00007f8fe1fdea76  push rdi
00007f8fe1fdea77  push rsi
00007f8fe1fdea78  push r8
00007f8fe1fdea7a  push r9
00007f8fe1fdea7c  push r10
00007f8fe1fdea7e  push r11
00007f8fe1fdea80  sub rsp, 0xF0
00007f8fe1fdea87  vmovaps [rsp], xmm0
00007f8fe1fdea8c  vmovaps [rsp+0x10], xmm1
00007f8fe1fdea92  vmovaps [rsp+0x20], xmm2
00007f8fe1fdea98  vmovaps [rsp+0x30], xmm3
00007f8fe1fdea9e  vmovaps [rsp+0x40], xmm4
00007f8fe1fdeaa4  vmovaps [rsp+0x50], xmm5
00007f8fe1fdeaaa  vmovaps [rsp+0x60], xmm6
00007f8fe1fdeab0  vmovaps [rsp+0x70], xmm7
00007f8fe1fdeab6  vmovaps [rsp+0x80], xmm8
00007f8fe1fdeabf  vmovaps [rsp+0x90], xmm9
00007f8fe1fdeac8  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdead1  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdeada  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdeae3  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdeaec  vmovaps [rsp+0xE0], xmm14
00007f8fe1fdeaf5  sub rsp, 0x30
00007f8fe1fdeaf9  movaps [rsp], xmm15
00007f8fe1fdeafe  movaps [rsp+0x10], xmm14
00007f8fe1fdeb04  movaps [rsp+0x20], xmm4
00007f8fe1fdeb09  lea rdi, [rsp]
00007f8fe1fdeb0d  mov esi, 0x00
00007f8fe1fdeb12  mov rax, 0x6020BB77F530
00007f8fe1fdeb1c  call rax
00007f8fe1fdeb1e  movaps xmm15, [rsp]
00007f8fe1fdeb23  add rsp, 0x30
00007f8fe1fdeb27  vmovaps xmm0, [rsp]
00007f8fe1fdeb2c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdeb32  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdeb38  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdeb3e  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdeb44  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdeb4a  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdeb50  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdeb56  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdeb5f  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdeb68  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdeb71  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdeb7a  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdeb83  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdeb8c  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fdeb95  add rsp, 0xF0
00007f8fe1fdeb9c  pop r11
00007f8fe1fdeb9e  pop r10
00007f8fe1fdeba0  pop r9
00007f8fe1fdeba2  pop r8
00007f8fe1fdeba4  pop rsi
00007f8fe1fdeba5  pop rdi
00007f8fe1fdeba6  pop rdx
00007f8fe1fdeba7  pop rcx
00007f8fe1fdeba8  pop rax
00007f8fe1fdeba9  add rsp, 0x08
00007f8fe1fdebad  jmp 0x00007F8FE1FDC2AA
00007f8fe1fdebb2  sub rsp, 0x08
00007f8fe1fdebb6  push rax
00007f8fe1fdebb7  push rcx
00007f8fe1fdebb8  push rdx
00007f8fe1fdebb9  push rdi
00007f8fe1fdebba  push rsi
00007f8fe1fdebbb  push r8
00007f8fe1fdebbd  push r9
00007f8fe1fdebbf  push r10
00007f8fe1fdebc1  push r11
00007f8fe1fdebc3  sub rsp, 0xF0
00007f8fe1fdebca  vmovaps [rsp], xmm0
00007f8fe1fdebcf  vmovaps [rsp+0x10], xmm1
00007f8fe1fdebd5  vmovaps [rsp+0x20], xmm2
00007f8fe1fdebdb  vmovaps [rsp+0x30], xmm3
00007f8fe1fdebe1  vmovaps [rsp+0x40], xmm4
00007f8fe1fdebe7  vmovaps [rsp+0x50], xmm5
00007f8fe1fdebed  vmovaps [rsp+0x60], xmm6
00007f8fe1fdebf3  vmovaps [rsp+0x70], xmm7
00007f8fe1fdebf9  vmovaps [rsp+0x80], xmm8
00007f8fe1fdec02  vmovaps [rsp+0x90], xmm9
00007f8fe1fdec0b  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdec14  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdec1d  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdec26  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdec2f  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdec38  sub rsp, 0x30
00007f8fe1fdec3c  movaps [rsp], xmm14
00007f8fe1fdec41  movaps [rsp+0x10], xmm2
00007f8fe1fdec46  movaps [rsp+0x20], xmm1
00007f8fe1fdec4b  lea rdi, [rsp]
00007f8fe1fdec4f  mov esi, 0x00
00007f8fe1fdec54  mov rax, 0x6020BB77F530
00007f8fe1fdec5e  call rax
00007f8fe1fdec60  movaps xmm14, [rsp]
00007f8fe1fdec65  add rsp, 0x30
00007f8fe1fdec69  vmovaps xmm0, [rsp]
00007f8fe1fdec6e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdec74  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdec7a  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdec80  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdec86  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdec8c  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdec92  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdec98  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdeca1  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdecaa  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdecb3  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdecbc  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdecc5  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdecce  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdecd7  add rsp, 0xF0
00007f8fe1fdecde  pop r11
00007f8fe1fdece0  pop r10
00007f8fe1fdece2  pop r9
00007f8fe1fdece4  pop r8
00007f8fe1fdece6  pop rsi
00007f8fe1fdece7  pop rdi
00007f8fe1fdece8  pop rdx
00007f8fe1fdece9  pop rcx
00007f8fe1fdecea  pop rax
00007f8fe1fdeceb  add rsp, 0x08
00007f8fe1fdecef  jmp 0x00007F8FE1FDC2D0
00007f8fe1fdecf4  sub rsp, 0x08
00007f8fe1fdecf8  push rax
00007f8fe1fdecf9  push rcx
00007f8fe1fdecfa  push rdx
00007f8fe1fdecfb  push rdi
00007f8fe1fdecfc  push rsi
00007f8fe1fdecfd  push r8
00007f8fe1fdecff  push r9
00007f8fe1fded01  push r10
00007f8fe1fded03  push r11
00007f8fe1fded05  sub rsp, 0xF0
00007f8fe1fded0c  vmovaps [rsp], xmm0
00007f8fe1fded11  vmovaps [rsp+0x10], xmm2
00007f8fe1fded17  vmovaps [rsp+0x20], xmm3
00007f8fe1fded1d  vmovaps [rsp+0x30], xmm4
00007f8fe1fded23  vmovaps [rsp+0x40], xmm5
00007f8fe1fded29  vmovaps [rsp+0x50], xmm6
00007f8fe1fded2f  vmovaps [rsp+0x60], xmm7
00007f8fe1fded35  vmovaps [rsp+0x70], xmm8
00007f8fe1fded3b  vmovaps [rsp+0x80], xmm9
00007f8fe1fded44  vmovaps [rsp+0x90], xmm10
00007f8fe1fded4d  vmovaps [rsp+0xA0], xmm11
00007f8fe1fded56  vmovaps [rsp+0xB0], xmm12
00007f8fe1fded5f  vmovaps [rsp+0xC0], xmm13
00007f8fe1fded68  vmovaps [rsp+0xD0], xmm14
00007f8fe1fded71  vmovaps [rsp+0xE0], xmm15
00007f8fe1fded7a  sub rsp, 0x30
00007f8fe1fded7e  movaps [rsp], xmm1
00007f8fe1fded82  movaps [rsp+0x10], xmm4
00007f8fe1fded87  movaps [rsp+0x20], xmm9
00007f8fe1fded8d  lea rdi, [rsp]
00007f8fe1fded91  mov esi, 0x00
00007f8fe1fded96  mov rax, 0x6020BB77F530
00007f8fe1fdeda0  call rax
00007f8fe1fdeda2  movaps xmm1, [rsp]
00007f8fe1fdeda6  add rsp, 0x30
00007f8fe1fdedaa  vmovaps xmm0, [rsp]
00007f8fe1fdedaf  vmovaps xmm2, [rsp+0x10]
00007f8fe1fdedb5  vmovaps xmm3, [rsp+0x20]
00007f8fe1fdedbb  vmovaps xmm4, [rsp+0x30]
00007f8fe1fdedc1  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdedc7  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdedcd  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdedd3  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdedd9  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdede2  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdedeb  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdedf4  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdedfd  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdee06  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdee0f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdee18  add rsp, 0xF0
00007f8fe1fdee1f  pop r11
00007f8fe1fdee21  pop r10
00007f8fe1fdee23  pop r9
00007f8fe1fdee25  pop r8
00007f8fe1fdee27  pop rsi
00007f8fe1fdee28  pop rdi
00007f8fe1fdee29  pop rdx
00007f8fe1fdee2a  pop rcx
00007f8fe1fdee2b  pop rax
00007f8fe1fdee2c  add rsp, 0x08
00007f8fe1fdee30  jmp 0x00007F8FE1FDC2EE
00007f8fe1fdee35  sub rsp, 0x08
00007f8fe1fdee39  push rax
00007f8fe1fdee3a  push rcx
00007f8fe1fdee3b  push rdx
00007f8fe1fdee3c  push rdi
00007f8fe1fdee3d  push rsi
00007f8fe1fdee3e  push r8
00007f8fe1fdee40  push r9
00007f8fe1fdee42  push r10
00007f8fe1fdee44  push r11
00007f8fe1fdee46  sub rsp, 0xF0
00007f8fe1fdee4d  vmovaps [rsp], xmm0
00007f8fe1fdee52  vmovaps [rsp+0x10], xmm1
00007f8fe1fdee58  vmovaps [rsp+0x20], xmm2
00007f8fe1fdee5e  vmovaps [rsp+0x30], xmm3
00007f8fe1fdee64  vmovaps [rsp+0x40], xmm5
00007f8fe1fdee6a  vmovaps [rsp+0x50], xmm6
00007f8fe1fdee70  vmovaps [rsp+0x60], xmm7
00007f8fe1fdee76  vmovaps [rsp+0x70], xmm8
00007f8fe1fdee7c  vmovaps [rsp+0x80], xmm9
00007f8fe1fdee85  vmovaps [rsp+0x90], xmm10
00007f8fe1fdee8e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdee97  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdeea0  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdeea9  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdeeb2  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdeebb  sub rsp, 0x30
00007f8fe1fdeebf  movaps [rsp], xmm4
00007f8fe1fdeec3  movaps [rsp+0x10], xmm2
00007f8fe1fdeec8  movaps [rsp+0x20], xmm9
00007f8fe1fdeece  lea rdi, [rsp]
00007f8fe1fdeed2  mov esi, 0x00
00007f8fe1fdeed7  mov rax, 0x6020BB77F530
00007f8fe1fdeee1  call rax
00007f8fe1fdeee3  movaps xmm4, [rsp]
00007f8fe1fdeee7  add rsp, 0x30
00007f8fe1fdeeeb  vmovaps xmm0, [rsp]
00007f8fe1fdeef0  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdeef6  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdeefc  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdef02  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdef08  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdef0e  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdef14  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdef1a  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdef23  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdef2c  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdef35  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdef3e  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdef47  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdef50  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdef59  add rsp, 0xF0
00007f8fe1fdef60  pop r11
00007f8fe1fdef62  pop r10
00007f8fe1fdef64  pop r9
00007f8fe1fdef66  pop r8
00007f8fe1fdef68  pop rsi
00007f8fe1fdef69  pop rdi
00007f8fe1fdef6a  pop rdx
00007f8fe1fdef6b  pop rcx
00007f8fe1fdef6c  pop rax
00007f8fe1fdef6d  add rsp, 0x08
00007f8fe1fdef71  jmp 0x00007F8FE1FDC31E
00007f8fe1fdef76  sub rsp, 0x08
00007f8fe1fdef7a  push rax
00007f8fe1fdef7b  push rcx
00007f8fe1fdef7c  push rdx
00007f8fe1fdef7d  push rdi
00007f8fe1fdef7e  push rsi
00007f8fe1fdef7f  push r8
00007f8fe1fdef81  push r9
00007f8fe1fdef83  push r10
00007f8fe1fdef85  push r11
00007f8fe1fdef87  sub rsp, 0xF0
00007f8fe1fdef8e  vmovaps [rsp], xmm0
00007f8fe1fdef93  vmovaps [rsp+0x10], xmm1
00007f8fe1fdef99  vmovaps [rsp+0x20], xmm2
00007f8fe1fdef9f  vmovaps [rsp+0x30], xmm3
00007f8fe1fdefa5  vmovaps [rsp+0x40], xmm4
00007f8fe1fdefab  vmovaps [rsp+0x50], xmm5
00007f8fe1fdefb1  vmovaps [rsp+0x60], xmm6
00007f8fe1fdefb7  vmovaps [rsp+0x70], xmm7
00007f8fe1fdefbd  vmovaps [rsp+0x80], xmm8
00007f8fe1fdefc6  vmovaps [rsp+0x90], xmm10
00007f8fe1fdefcf  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdefd8  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdefe1  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdefea  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdeff3  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdeffc  sub rsp, 0x30
00007f8fe1fdf000  movaps [rsp], xmm9
00007f8fe1fdf005  movaps [rsp+0x10], xmm2
00007f8fe1fdf00a  movaps [rsp+0x20], xmm1
00007f8fe1fdf00f  lea rdi, [rsp]
00007f8fe1fdf013  mov esi, 0x00
00007f8fe1fdf018  mov rax, 0x6020BB77F530
00007f8fe1fdf022  call rax
00007f8fe1fdf024  movaps xmm9, [rsp]
00007f8fe1fdf029  add rsp, 0x30
00007f8fe1fdf02d  vmovaps xmm0, [rsp]
00007f8fe1fdf032  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdf038  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdf03e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdf044  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdf04a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdf050  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdf056  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdf05c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdf065  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdf06e  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdf077  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdf080  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdf089  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdf092  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdf09b  add rsp, 0xF0
00007f8fe1fdf0a2  pop r11
00007f8fe1fdf0a4  pop r10
00007f8fe1fdf0a6  pop r9
00007f8fe1fdf0a8  pop r8
00007f8fe1fdf0aa  pop rsi
00007f8fe1fdf0ab  pop rdi
00007f8fe1fdf0ac  pop rdx
00007f8fe1fdf0ad  pop rcx
00007f8fe1fdf0ae  pop rax
00007f8fe1fdf0af  add rsp, 0x08
00007f8fe1fdf0b3  jmp 0x00007F8FE1FDC354
00007f8fe1fdf0b8  sub rsp, 0x08
00007f8fe1fdf0bc  push rax
00007f8fe1fdf0bd  push rcx
00007f8fe1fdf0be  push rdx
00007f8fe1fdf0bf  push rdi
00007f8fe1fdf0c0  push rsi
00007f8fe1fdf0c1  push r8
00007f8fe1fdf0c3  push r9
00007f8fe1fdf0c5  push r10
00007f8fe1fdf0c7  push r11
00007f8fe1fdf0c9  sub rsp, 0xF0
00007f8fe1fdf0d0  vmovaps [rsp], xmm0
00007f8fe1fdf0d5  vmovaps [rsp+0x10], xmm2
00007f8fe1fdf0db  vmovaps [rsp+0x20], xmm3
00007f8fe1fdf0e1  vmovaps [rsp+0x30], xmm4
00007f8fe1fdf0e7  vmovaps [rsp+0x40], xmm5
00007f8fe1fdf0ed  vmovaps [rsp+0x50], xmm6
00007f8fe1fdf0f3  vmovaps [rsp+0x60], xmm7
00007f8fe1fdf0f9  vmovaps [rsp+0x70], xmm8
00007f8fe1fdf0ff  vmovaps [rsp+0x80], xmm9
00007f8fe1fdf108  vmovaps [rsp+0x90], xmm10
00007f8fe1fdf111  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdf11a  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdf123  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdf12c  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdf135  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdf13e  sub rsp, 0x30
00007f8fe1fdf142  movaps [rsp], xmm1
00007f8fe1fdf146  movaps [rsp+0x10], xmm15
00007f8fe1fdf14c  movaps [rsp+0x20], xmm6
00007f8fe1fdf151  lea rdi, [rsp]
00007f8fe1fdf155  mov esi, 0x00
00007f8fe1fdf15a  mov rax, 0x6020BB77F530
00007f8fe1fdf164  call rax
00007f8fe1fdf166  movaps xmm1, [rsp]
00007f8fe1fdf16a  add rsp, 0x30
00007f8fe1fdf16e  vmovaps xmm0, [rsp]
00007f8fe1fdf173  vmovaps xmm2, [rsp+0x10]
00007f8fe1fdf179  vmovaps xmm3, [rsp+0x20]
00007f8fe1fdf17f  vmovaps xmm4, [rsp+0x30]
00007f8fe1fdf185  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdf18b  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdf191  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdf197  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdf19d  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdf1a6  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdf1af  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdf1b8  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdf1c1  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdf1ca  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdf1d3  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdf1dc  add rsp, 0xF0
00007f8fe1fdf1e3  pop r11
00007f8fe1fdf1e5  pop r10
00007f8fe1fdf1e7  pop r9
00007f8fe1fdf1e9  pop r8
00007f8fe1fdf1eb  pop rsi
00007f8fe1fdf1ec  pop rdi
00007f8fe1fdf1ed  pop rdx
00007f8fe1fdf1ee  pop rcx
00007f8fe1fdf1ef  pop rax
00007f8fe1fdf1f0  add rsp, 0x08
00007f8fe1fdf1f4  jmp 0x00007F8FE1FDC375
00007f8fe1fdf1f9  sub rsp, 0x08
00007f8fe1fdf1fd  push rax
00007f8fe1fdf1fe  push rcx
00007f8fe1fdf1ff  push rdx
00007f8fe1fdf200  push rdi
00007f8fe1fdf201  push rsi
00007f8fe1fdf202  push r8
00007f8fe1fdf204  push r9
00007f8fe1fdf206  push r10
00007f8fe1fdf208  push r11
00007f8fe1fdf20a  sub rsp, 0xF0
00007f8fe1fdf211  vmovaps [rsp], xmm0
00007f8fe1fdf216  vmovaps [rsp+0x10], xmm1
00007f8fe1fdf21c  vmovaps [rsp+0x20], xmm2
00007f8fe1fdf222  vmovaps [rsp+0x30], xmm3
00007f8fe1fdf228  vmovaps [rsp+0x40], xmm4
00007f8fe1fdf22e  vmovaps [rsp+0x50], xmm5
00007f8fe1fdf234  vmovaps [rsp+0x60], xmm6
00007f8fe1fdf23a  vmovaps [rsp+0x70], xmm7
00007f8fe1fdf240  vmovaps [rsp+0x80], xmm8
00007f8fe1fdf249  vmovaps [rsp+0x90], xmm9
00007f8fe1fdf252  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdf25b  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdf264  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdf26d  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdf276  vmovaps [rsp+0xE0], xmm14
00007f8fe1fdf27f  sub rsp, 0x30
00007f8fe1fdf283  movaps [rsp], xmm15
00007f8fe1fdf288  movaps [rsp+0x10], xmm5
00007f8fe1fdf28d  movaps [rsp+0x20], xmm3
00007f8fe1fdf292  lea rdi, [rsp]
00007f8fe1fdf296  mov esi, 0x00
00007f8fe1fdf29b  mov rax, 0x6020BB77F530
00007f8fe1fdf2a5  call rax
00007f8fe1fdf2a7  movaps xmm15, [rsp]
00007f8fe1fdf2ac  add rsp, 0x30
00007f8fe1fdf2b0  vmovaps xmm0, [rsp]
00007f8fe1fdf2b5  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdf2bb  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdf2c1  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdf2c7  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdf2cd  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdf2d3  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdf2d9  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdf2df  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdf2e8  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdf2f1  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdf2fa  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdf303  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdf30c  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdf315  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fdf31e  add rsp, 0xF0
00007f8fe1fdf325  pop r11
00007f8fe1fdf327  pop r10
00007f8fe1fdf329  pop r9
00007f8fe1fdf32b  pop r8
00007f8fe1fdf32d  pop rsi
00007f8fe1fdf32e  pop rdi
00007f8fe1fdf32f  pop rdx
00007f8fe1fdf330  pop rcx
00007f8fe1fdf331  pop rax
00007f8fe1fdf332  add rsp, 0x08
00007f8fe1fdf336  jmp 0x00007F8FE1FDC38F
00007f8fe1fdf33b  sub rsp, 0x08
00007f8fe1fdf33f  push rax
00007f8fe1fdf340  push rcx
00007f8fe1fdf341  push rdx
00007f8fe1fdf342  push rdi
00007f8fe1fdf343  push rsi
00007f8fe1fdf344  push r8
00007f8fe1fdf346  push r9
00007f8fe1fdf348  push r10
00007f8fe1fdf34a  push r11
00007f8fe1fdf34c  sub rsp, 0xF0
00007f8fe1fdf353  vmovaps [rsp], xmm0
00007f8fe1fdf358  vmovaps [rsp+0x10], xmm1
00007f8fe1fdf35e  vmovaps [rsp+0x20], xmm2
00007f8fe1fdf364  vmovaps [rsp+0x30], xmm3
00007f8fe1fdf36a  vmovaps [rsp+0x40], xmm4
00007f8fe1fdf370  vmovaps [rsp+0x50], xmm6
00007f8fe1fdf376  vmovaps [rsp+0x60], xmm7
00007f8fe1fdf37c  vmovaps [rsp+0x70], xmm8
00007f8fe1fdf382  vmovaps [rsp+0x80], xmm9
00007f8fe1fdf38b  vmovaps [rsp+0x90], xmm10
00007f8fe1fdf394  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdf39d  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdf3a6  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdf3af  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdf3b8  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdf3c1  sub rsp, 0x30
00007f8fe1fdf3c5  movaps [rsp], xmm5
00007f8fe1fdf3c9  movaps [rsp+0x10], xmm8
00007f8fe1fdf3cf  movaps [rsp+0x20], xmm6
00007f8fe1fdf3d4  lea rdi, [rsp]
00007f8fe1fdf3d8  mov esi, 0x00
00007f8fe1fdf3dd  mov rax, 0x6020BB77F530
00007f8fe1fdf3e7  call rax
00007f8fe1fdf3e9  movaps xmm5, [rsp]
00007f8fe1fdf3ed  add rsp, 0x30
00007f8fe1fdf3f1  vmovaps xmm0, [rsp]
00007f8fe1fdf3f6  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdf3fc  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdf402  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdf408  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdf40e  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdf414  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdf41a  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdf420  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdf429  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdf432  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdf43b  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdf444  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdf44d  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdf456  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdf45f  add rsp, 0xF0
00007f8fe1fdf466  pop r11
00007f8fe1fdf468  pop r10
00007f8fe1fdf46a  pop r9
00007f8fe1fdf46c  pop r8
00007f8fe1fdf46e  pop rsi
00007f8fe1fdf46f  pop rdi
00007f8fe1fdf470  pop rdx
00007f8fe1fdf471  pop rcx
00007f8fe1fdf472  pop rax
00007f8fe1fdf473  add rsp, 0x08
00007f8fe1fdf477  jmp 0x00007F8FE1FDC3B3
00007f8fe1fdf47c  sub rsp, 0x08
00007f8fe1fdf480  push rax
00007f8fe1fdf481  push rcx
00007f8fe1fdf482  push rdx
00007f8fe1fdf483  push rdi
00007f8fe1fdf484  push rsi
00007f8fe1fdf485  push r8
00007f8fe1fdf487  push r9
00007f8fe1fdf489  push r10
00007f8fe1fdf48b  push r11
00007f8fe1fdf48d  sub rsp, 0xF0
00007f8fe1fdf494  vmovaps [rsp], xmm0
00007f8fe1fdf499  vmovaps [rsp+0x10], xmm1
00007f8fe1fdf49f  vmovaps [rsp+0x20], xmm2
00007f8fe1fdf4a5  vmovaps [rsp+0x30], xmm3
00007f8fe1fdf4ab  vmovaps [rsp+0x40], xmm4
00007f8fe1fdf4b1  vmovaps [rsp+0x50], xmm5
00007f8fe1fdf4b7  vmovaps [rsp+0x60], xmm7
00007f8fe1fdf4bd  vmovaps [rsp+0x70], xmm8
00007f8fe1fdf4c3  vmovaps [rsp+0x80], xmm9
00007f8fe1fdf4cc  vmovaps [rsp+0x90], xmm10
00007f8fe1fdf4d5  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdf4de  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdf4e7  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdf4f0  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdf4f9  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdf502  sub rsp, 0x30
00007f8fe1fdf506  movaps [rsp], xmm6
00007f8fe1fdf50a  movaps [rsp+0x10], xmm10
00007f8fe1fdf510  movaps [rsp+0x20], xmm8
00007f8fe1fdf516  lea rdi, [rsp]
00007f8fe1fdf51a  mov esi, 0x00
00007f8fe1fdf51f  mov rax, 0x6020BB77F530
00007f8fe1fdf529  call rax
00007f8fe1fdf52b  movaps xmm6, [rsp]
00007f8fe1fdf52f  add rsp, 0x30
00007f8fe1fdf533  vmovaps xmm0, [rsp]
00007f8fe1fdf538  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdf53e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdf544  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdf54a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdf550  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdf556  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdf55c  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdf562  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdf56b  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdf574  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdf57d  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdf586  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdf58f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdf598  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdf5a1  add rsp, 0xF0
00007f8fe1fdf5a8  pop r11
00007f8fe1fdf5aa  pop r10
00007f8fe1fdf5ac  pop r9
00007f8fe1fdf5ae  pop r8
00007f8fe1fdf5b0  pop rsi
00007f8fe1fdf5b1  pop rdi
00007f8fe1fdf5b2  pop rdx
00007f8fe1fdf5b3  pop rcx
00007f8fe1fdf5b4  pop rax
00007f8fe1fdf5b5  add rsp, 0x08
00007f8fe1fdf5b9  jmp 0x00007F8FE1FDC3D8
00007f8fe1fdf5be  sub rsp, 0x08
00007f8fe1fdf5c2  push rax
00007f8fe1fdf5c3  push rcx
00007f8fe1fdf5c4  push rdx
00007f8fe1fdf5c5  push rdi
00007f8fe1fdf5c6  push rsi
00007f8fe1fdf5c7  push r8
00007f8fe1fdf5c9  push r9
00007f8fe1fdf5cb  push r10
00007f8fe1fdf5cd  push r11
00007f8fe1fdf5cf  sub rsp, 0xF0
00007f8fe1fdf5d6  vmovaps [rsp], xmm0
00007f8fe1fdf5db  vmovaps [rsp+0x10], xmm1
00007f8fe1fdf5e1  vmovaps [rsp+0x20], xmm2
00007f8fe1fdf5e7  vmovaps [rsp+0x30], xmm3
00007f8fe1fdf5ed  vmovaps [rsp+0x40], xmm4
00007f8fe1fdf5f3  vmovaps [rsp+0x50], xmm5
00007f8fe1fdf5f9  vmovaps [rsp+0x60], xmm6
00007f8fe1fdf5ff  vmovaps [rsp+0x70], xmm7
00007f8fe1fdf605  vmovaps [rsp+0x80], xmm8
00007f8fe1fdf60e  vmovaps [rsp+0x90], xmm9
00007f8fe1fdf617  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdf620  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdf629  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdf632  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdf63b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdf644  sub rsp, 0x30
00007f8fe1fdf648  movaps [rsp], xmm10
00007f8fe1fdf64d  movaps [rsp+0x10], xmm8
00007f8fe1fdf653  movaps [rsp+0x20], xmm14
00007f8fe1fdf659  lea rdi, [rsp]
00007f8fe1fdf65d  mov esi, 0x00
00007f8fe1fdf662  mov rax, 0x6020BB77F530
00007f8fe1fdf66c  call rax
00007f8fe1fdf66e  movaps xmm10, [rsp]
00007f8fe1fdf673  add rsp, 0x30
00007f8fe1fdf677  vmovaps xmm0, [rsp]
00007f8fe1fdf67c  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdf682  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdf688  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdf68e  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdf694  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdf69a  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdf6a0  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdf6a6  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdf6af  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdf6b8  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdf6c1  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdf6ca  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdf6d3  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdf6dc  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdf6e5  add rsp, 0xF0
00007f8fe1fdf6ec  pop r11
00007f8fe1fdf6ee  pop r10
00007f8fe1fdf6f0  pop r9
00007f8fe1fdf6f2  pop r8
00007f8fe1fdf6f4  pop rsi
00007f8fe1fdf6f5  pop rdi
00007f8fe1fdf6f6  pop rdx
00007f8fe1fdf6f7  pop rcx
00007f8fe1fdf6f8  pop rax
00007f8fe1fdf6f9  add rsp, 0x08
00007f8fe1fdf6fd  jmp 0x00007F8FE1FDC3F8
00007f8fe1fdf702  sub rsp, 0x08
00007f8fe1fdf706  push rax
00007f8fe1fdf707  push rcx
00007f8fe1fdf708  push rdx
00007f8fe1fdf709  push rdi
00007f8fe1fdf70a  push rsi
00007f8fe1fdf70b  push r8
00007f8fe1fdf70d  push r9
00007f8fe1fdf70f  push r10
00007f8fe1fdf711  push r11
00007f8fe1fdf713  sub rsp, 0xF0
00007f8fe1fdf71a  vmovaps [rsp], xmm0
00007f8fe1fdf71f  vmovaps [rsp+0x10], xmm1
00007f8fe1fdf725  vmovaps [rsp+0x20], xmm2
00007f8fe1fdf72b  vmovaps [rsp+0x30], xmm3
00007f8fe1fdf731  vmovaps [rsp+0x40], xmm4
00007f8fe1fdf737  vmovaps [rsp+0x50], xmm5
00007f8fe1fdf73d  vmovaps [rsp+0x60], xmm6
00007f8fe1fdf743  vmovaps [rsp+0x70], xmm7
00007f8fe1fdf749  vmovaps [rsp+0x80], xmm8
00007f8fe1fdf752  vmovaps [rsp+0x90], xmm9
00007f8fe1fdf75b  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdf764  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdf76d  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdf776  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdf77f  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdf788  sub rsp, 0x30
00007f8fe1fdf78c  movaps [rsp], xmm14
00007f8fe1fdf791  movaps [rsp+0x10], xmm8
00007f8fe1fdf797  movaps [rsp+0x20], xmm4
00007f8fe1fdf79c  lea rdi, [rsp]
00007f8fe1fdf7a0  mov esi, 0x00
00007f8fe1fdf7a5  mov rax, 0x6020BB77F530
00007f8fe1fdf7af  call rax
00007f8fe1fdf7b1  movaps xmm14, [rsp]
00007f8fe1fdf7b6  add rsp, 0x30
00007f8fe1fdf7ba  vmovaps xmm0, [rsp]
00007f8fe1fdf7bf  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdf7c5  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdf7cb  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdf7d1  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdf7d7  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdf7dd  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdf7e3  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdf7e9  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdf7f2  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdf7fb  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdf804  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdf80d  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdf816  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdf81f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdf828  add rsp, 0xF0
00007f8fe1fdf82f  pop r11
00007f8fe1fdf831  pop r10
00007f8fe1fdf833  pop r9
00007f8fe1fdf835  pop r8
00007f8fe1fdf837  pop rsi
00007f8fe1fdf838  pop rdi
00007f8fe1fdf839  pop rdx
00007f8fe1fdf83a  pop rcx
00007f8fe1fdf83b  pop rax
00007f8fe1fdf83c  add rsp, 0x08
00007f8fe1fdf840  jmp 0x00007F8FE1FDC418
00007f8fe1fdf845  sub rsp, 0x08
00007f8fe1fdf849  push rax
00007f8fe1fdf84a  push rcx
00007f8fe1fdf84b  push rdx
00007f8fe1fdf84c  push rdi
00007f8fe1fdf84d  push rsi
00007f8fe1fdf84e  push r8
00007f8fe1fdf850  push r9
00007f8fe1fdf852  push r10
00007f8fe1fdf854  push r11
00007f8fe1fdf856  sub rsp, 0xF0
00007f8fe1fdf85d  vmovaps [rsp], xmm0
00007f8fe1fdf862  vmovaps [rsp+0x10], xmm1
00007f8fe1fdf868  vmovaps [rsp+0x20], xmm2
00007f8fe1fdf86e  vmovaps [rsp+0x30], xmm3
00007f8fe1fdf874  vmovaps [rsp+0x40], xmm5
00007f8fe1fdf87a  vmovaps [rsp+0x50], xmm6
00007f8fe1fdf880  vmovaps [rsp+0x60], xmm7
00007f8fe1fdf886  vmovaps [rsp+0x70], xmm8
00007f8fe1fdf88c  vmovaps [rsp+0x80], xmm9
00007f8fe1fdf895  vmovaps [rsp+0x90], xmm10
00007f8fe1fdf89e  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdf8a7  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdf8b0  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdf8b9  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdf8c2  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdf8cb  sub rsp, 0x30
00007f8fe1fdf8cf  movaps [rsp], xmm4
00007f8fe1fdf8d3  movaps [rsp+0x10], xmm13
00007f8fe1fdf8d9  movaps [rsp+0x20], xmm8
00007f8fe1fdf8df  lea rdi, [rsp]
00007f8fe1fdf8e3  mov esi, 0x00
00007f8fe1fdf8e8  mov rax, 0x6020BB77F530
00007f8fe1fdf8f2  call rax
00007f8fe1fdf8f4  movaps xmm4, [rsp]
00007f8fe1fdf8f8  add rsp, 0x30
00007f8fe1fdf8fc  vmovaps xmm0, [rsp]
00007f8fe1fdf901  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdf907  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdf90d  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdf913  vmovaps xmm5, [rsp+0x40]
00007f8fe1fdf919  vmovaps xmm6, [rsp+0x50]
00007f8fe1fdf91f  vmovaps xmm7, [rsp+0x60]
00007f8fe1fdf925  vmovaps xmm8, [rsp+0x70]
00007f8fe1fdf92b  vmovaps xmm9, [rsp+0x80]
00007f8fe1fdf934  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdf93d  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdf946  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdf94f  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdf958  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdf961  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdf96a  add rsp, 0xF0
00007f8fe1fdf971  pop r11
00007f8fe1fdf973  pop r10
00007f8fe1fdf975  pop r9
00007f8fe1fdf977  pop r8
00007f8fe1fdf979  pop rsi
00007f8fe1fdf97a  pop rdi
00007f8fe1fdf97b  pop rdx
00007f8fe1fdf97c  pop rcx
00007f8fe1fdf97d  pop rax
00007f8fe1fdf97e  add rsp, 0x08
00007f8fe1fdf982  jmp 0x00007F8FE1FDC43D
00007f8fe1fdf987  sub rsp, 0x08
00007f8fe1fdf98b  push rax
00007f8fe1fdf98c  push rcx
00007f8fe1fdf98d  push rdx
00007f8fe1fdf98e  push rdi
00007f8fe1fdf98f  push rsi
00007f8fe1fdf990  push r8
00007f8fe1fdf992  push r9
00007f8fe1fdf994  push r10
00007f8fe1fdf996  push r11
00007f8fe1fdf998  sub rsp, 0xF0
00007f8fe1fdf99f  vmovaps [rsp], xmm0
00007f8fe1fdf9a4  vmovaps [rsp+0x10], xmm1
00007f8fe1fdf9aa  vmovaps [rsp+0x20], xmm2
00007f8fe1fdf9b0  vmovaps [rsp+0x30], xmm3
00007f8fe1fdf9b6  vmovaps [rsp+0x40], xmm4
00007f8fe1fdf9bc  vmovaps [rsp+0x50], xmm5
00007f8fe1fdf9c2  vmovaps [rsp+0x60], xmm6
00007f8fe1fdf9c8  vmovaps [rsp+0x70], xmm7
00007f8fe1fdf9ce  vmovaps [rsp+0x80], xmm8
00007f8fe1fdf9d7  vmovaps [rsp+0x90], xmm9
00007f8fe1fdf9e0  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdf9e9  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdf9f2  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdf9fb  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdfa04  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdfa0d  sub rsp, 0x30
00007f8fe1fdfa11  movaps [rsp], xmm13
00007f8fe1fdfa16  movaps [rsp+0x10], xmm15
00007f8fe1fdfa1c  movaps [rsp+0x20], xmm9
00007f8fe1fdfa22  lea rdi, [rsp]
00007f8fe1fdfa26  mov esi, 0x00
00007f8fe1fdfa2b  mov rax, 0x6020BB77F530
00007f8fe1fdfa35  call rax
00007f8fe1fdfa37  movaps xmm13, [rsp]
00007f8fe1fdfa3c  add rsp, 0x30
00007f8fe1fdfa40  vmovaps xmm0, [rsp]
00007f8fe1fdfa45  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdfa4b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdfa51  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdfa57  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdfa5d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdfa63  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdfa69  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdfa6f  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdfa78  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdfa81  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdfa8a  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdfa93  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdfa9c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdfaa5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdfaae  add rsp, 0xF0
00007f8fe1fdfab5  pop r11
00007f8fe1fdfab7  pop r10
00007f8fe1fdfab9  pop r9
00007f8fe1fdfabb  pop r8
00007f8fe1fdfabd  pop rsi
00007f8fe1fdfabe  pop rdi
00007f8fe1fdfabf  pop rdx
00007f8fe1fdfac0  pop rcx
00007f8fe1fdfac1  pop rax
00007f8fe1fdfac2  add rsp, 0x08
00007f8fe1fdfac6  jmp 0x00007F8FE1FDC458
00007f8fe1fdfacb  sub rsp, 0x08
00007f8fe1fdfacf  push rax
00007f8fe1fdfad0  push rcx
00007f8fe1fdfad1  push rdx
00007f8fe1fdfad2  push rdi
00007f8fe1fdfad3  push rsi
00007f8fe1fdfad4  push r8
00007f8fe1fdfad6  push r9
00007f8fe1fdfad8  push r10
00007f8fe1fdfada  push r11
00007f8fe1fdfadc  sub rsp, 0xF0
00007f8fe1fdfae3  vmovaps [rsp], xmm0
00007f8fe1fdfae8  vmovaps [rsp+0x10], xmm1
00007f8fe1fdfaee  vmovaps [rsp+0x20], xmm2
00007f8fe1fdfaf4  vmovaps [rsp+0x30], xmm3
00007f8fe1fdfafa  vmovaps [rsp+0x40], xmm4
00007f8fe1fdfb00  vmovaps [rsp+0x50], xmm5
00007f8fe1fdfb06  vmovaps [rsp+0x60], xmm6
00007f8fe1fdfb0c  vmovaps [rsp+0x70], xmm7
00007f8fe1fdfb12  vmovaps [rsp+0x80], xmm8
00007f8fe1fdfb1b  vmovaps [rsp+0x90], xmm9
00007f8fe1fdfb24  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdfb2d  vmovaps [rsp+0xB0], xmm11
00007f8fe1fdfb36  vmovaps [rsp+0xC0], xmm12
00007f8fe1fdfb3f  vmovaps [rsp+0xD0], xmm13
00007f8fe1fdfb48  vmovaps [rsp+0xE0], xmm14
00007f8fe1fdfb51  sub rsp, 0x30
00007f8fe1fdfb55  movaps [rsp], xmm15
00007f8fe1fdfb5a  movaps [rsp+0x10], xmm1
00007f8fe1fdfb5f  movaps [rsp+0x20], xmm5
00007f8fe1fdfb64  lea rdi, [rsp]
00007f8fe1fdfb68  mov esi, 0x00
00007f8fe1fdfb6d  mov rax, 0x6020BB77F530
00007f8fe1fdfb77  call rax
00007f8fe1fdfb79  movaps xmm15, [rsp]
00007f8fe1fdfb7e  add rsp, 0x30
00007f8fe1fdfb82  vmovaps xmm0, [rsp]
00007f8fe1fdfb87  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdfb8d  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdfb93  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdfb99  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdfb9f  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdfba5  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdfbab  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdfbb1  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdfbba  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdfbc3  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdfbcc  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fdfbd5  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fdfbde  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fdfbe7  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fdfbf0  add rsp, 0xF0
00007f8fe1fdfbf7  pop r11
00007f8fe1fdfbf9  pop r10
00007f8fe1fdfbfb  pop r9
00007f8fe1fdfbfd  pop r8
00007f8fe1fdfbff  pop rsi
00007f8fe1fdfc00  pop rdi
00007f8fe1fdfc01  pop rdx
00007f8fe1fdfc02  pop rcx
00007f8fe1fdfc03  pop rax
00007f8fe1fdfc04  add rsp, 0x08
00007f8fe1fdfc08  jmp 0x00007F8FE1FDC473
00007f8fe1fdfc0d  call 0x00007F8FE1EB52F0
00007f8fe1fdfc12  jmp 0x00007F8FE1FDC4CE
00007f8fe1fdfc17  sub rsp, 0x08
00007f8fe1fdfc1b  push rax
00007f8fe1fdfc1c  push rcx
00007f8fe1fdfc1d  push rdx
00007f8fe1fdfc1e  push rdi
00007f8fe1fdfc1f  push rsi
00007f8fe1fdfc20  push r8
00007f8fe1fdfc22  push r9
00007f8fe1fdfc24  push r10
00007f8fe1fdfc26  push r11
00007f8fe1fdfc28  sub rsp, 0xF0
00007f8fe1fdfc2f  vmovaps [rsp], xmm0
00007f8fe1fdfc34  vmovaps [rsp+0x10], xmm1
00007f8fe1fdfc3a  vmovaps [rsp+0x20], xmm2
00007f8fe1fdfc40  vmovaps [rsp+0x30], xmm3
00007f8fe1fdfc46  vmovaps [rsp+0x40], xmm4
00007f8fe1fdfc4c  vmovaps [rsp+0x50], xmm5
00007f8fe1fdfc52  vmovaps [rsp+0x60], xmm6
00007f8fe1fdfc58  vmovaps [rsp+0x70], xmm7
00007f8fe1fdfc5e  vmovaps [rsp+0x80], xmm8
00007f8fe1fdfc67  vmovaps [rsp+0x90], xmm10
00007f8fe1fdfc70  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdfc79  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdfc82  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdfc8b  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdfc94  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdfc9d  sub rsp, 0x30
00007f8fe1fdfca1  movaps [rsp], xmm9
00007f8fe1fdfca6  movaps [rsp+0x10], xmm8
00007f8fe1fdfcac  movaps [rsp+0x20], xmm11
00007f8fe1fdfcb2  lea rdi, [rsp]
00007f8fe1fdfcb6  mov esi, 0x00
00007f8fe1fdfcbb  mov rax, 0x6020BB77F530
00007f8fe1fdfcc5  call rax
00007f8fe1fdfcc7  movaps xmm9, [rsp]
00007f8fe1fdfccc  add rsp, 0x30
00007f8fe1fdfcd0  vmovaps xmm0, [rsp]
00007f8fe1fdfcd5  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdfcdb  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdfce1  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdfce7  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdfced  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdfcf3  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdfcf9  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdfcff  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdfd08  vmovaps xmm10, [rsp+0x90]
00007f8fe1fdfd11  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdfd1a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdfd23  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdfd2c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdfd35  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdfd3e  add rsp, 0xF0
00007f8fe1fdfd45  pop r11
00007f8fe1fdfd47  pop r10
00007f8fe1fdfd49  pop r9
00007f8fe1fdfd4b  pop r8
00007f8fe1fdfd4d  pop rsi
00007f8fe1fdfd4e  pop rdi
00007f8fe1fdfd4f  pop rdx
00007f8fe1fdfd50  pop rcx
00007f8fe1fdfd51  pop rax
00007f8fe1fdfd52  add rsp, 0x08
00007f8fe1fdfd56  jmp 0x00007F8FE1FDC505
00007f8fe1fdfd5b  sub rsp, 0x08
00007f8fe1fdfd5f  push rax
00007f8fe1fdfd60  push rcx
00007f8fe1fdfd61  push rdx
00007f8fe1fdfd62  push rdi
00007f8fe1fdfd63  push rsi
00007f8fe1fdfd64  push r8
00007f8fe1fdfd66  push r9
00007f8fe1fdfd68  push r10
00007f8fe1fdfd6a  push r11
00007f8fe1fdfd6c  sub rsp, 0xF0
00007f8fe1fdfd73  vmovaps [rsp], xmm0
00007f8fe1fdfd78  vmovaps [rsp+0x10], xmm1
00007f8fe1fdfd7e  vmovaps [rsp+0x20], xmm2
00007f8fe1fdfd84  vmovaps [rsp+0x30], xmm3
00007f8fe1fdfd8a  vmovaps [rsp+0x40], xmm4
00007f8fe1fdfd90  vmovaps [rsp+0x50], xmm5
00007f8fe1fdfd96  vmovaps [rsp+0x60], xmm6
00007f8fe1fdfd9c  vmovaps [rsp+0x70], xmm7
00007f8fe1fdfda2  vmovaps [rsp+0x80], xmm8
00007f8fe1fdfdab  vmovaps [rsp+0x90], xmm9
00007f8fe1fdfdb4  vmovaps [rsp+0xA0], xmm10
00007f8fe1fdfdbd  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdfdc6  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdfdcf  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdfdd8  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdfde1  sub rsp, 0x30
00007f8fe1fdfde5  movaps [rsp], xmm11
00007f8fe1fdfdea  movaps [rsp+0x10], xmm10
00007f8fe1fdfdf0  movaps [rsp+0x20], xmm6
00007f8fe1fdfdf5  lea rdi, [rsp]
00007f8fe1fdfdf9  mov esi, 0x00
00007f8fe1fdfdfe  mov rax, 0x6020BB77F530
00007f8fe1fdfe08  call rax
00007f8fe1fdfe0a  movaps xmm11, [rsp]
00007f8fe1fdfe0f  add rsp, 0x30
00007f8fe1fdfe13  vmovaps xmm0, [rsp]
00007f8fe1fdfe18  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdfe1e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdfe24  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdfe2a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdfe30  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdfe36  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdfe3c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdfe42  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdfe4b  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdfe54  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fdfe5d  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdfe66  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdfe6f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdfe78  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdfe81  add rsp, 0xF0
00007f8fe1fdfe88  pop r11
00007f8fe1fdfe8a  pop r10
00007f8fe1fdfe8c  pop r9
00007f8fe1fdfe8e  pop r8
00007f8fe1fdfe90  pop rsi
00007f8fe1fdfe91  pop rdi
00007f8fe1fdfe92  pop rdx
00007f8fe1fdfe93  pop rcx
00007f8fe1fdfe94  pop rax
00007f8fe1fdfe95  add rsp, 0x08
00007f8fe1fdfe99  jmp 0x00007F8FE1FDC520
00007f8fe1fdfe9e  sub rsp, 0x08
00007f8fe1fdfea2  push rax
00007f8fe1fdfea3  push rcx
00007f8fe1fdfea4  push rdx
00007f8fe1fdfea5  push rdi
00007f8fe1fdfea6  push rsi
00007f8fe1fdfea7  push r8
00007f8fe1fdfea9  push r9
00007f8fe1fdfeab  push r10
00007f8fe1fdfead  push r11
00007f8fe1fdfeaf  sub rsp, 0xF0
00007f8fe1fdfeb6  vmovaps [rsp], xmm0
00007f8fe1fdfebb  vmovaps [rsp+0x10], xmm1
00007f8fe1fdfec1  vmovaps [rsp+0x20], xmm2
00007f8fe1fdfec7  vmovaps [rsp+0x30], xmm3
00007f8fe1fdfecd  vmovaps [rsp+0x40], xmm4
00007f8fe1fdfed3  vmovaps [rsp+0x50], xmm5
00007f8fe1fdfed9  vmovaps [rsp+0x60], xmm6
00007f8fe1fdfedf  vmovaps [rsp+0x70], xmm7
00007f8fe1fdfee5  vmovaps [rsp+0x80], xmm8
00007f8fe1fdfeee  vmovaps [rsp+0x90], xmm9
00007f8fe1fdfef7  vmovaps [rsp+0xA0], xmm11
00007f8fe1fdff00  vmovaps [rsp+0xB0], xmm12
00007f8fe1fdff09  vmovaps [rsp+0xC0], xmm13
00007f8fe1fdff12  vmovaps [rsp+0xD0], xmm14
00007f8fe1fdff1b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fdff24  sub rsp, 0x30
00007f8fe1fdff28  movaps [rsp], xmm10
00007f8fe1fdff2d  movaps [rsp+0x10], xmm14
00007f8fe1fdff33  movaps [rsp+0x20], xmm4
00007f8fe1fdff38  lea rdi, [rsp]
00007f8fe1fdff3c  mov esi, 0x00
00007f8fe1fdff41  mov rax, 0x6020BB77F530
00007f8fe1fdff4b  call rax
00007f8fe1fdff4d  movaps xmm10, [rsp]
00007f8fe1fdff52  add rsp, 0x30
00007f8fe1fdff56  vmovaps xmm0, [rsp]
00007f8fe1fdff5b  vmovaps xmm1, [rsp+0x10]
00007f8fe1fdff61  vmovaps xmm2, [rsp+0x20]
00007f8fe1fdff67  vmovaps xmm3, [rsp+0x30]
00007f8fe1fdff6d  vmovaps xmm4, [rsp+0x40]
00007f8fe1fdff73  vmovaps xmm5, [rsp+0x50]
00007f8fe1fdff79  vmovaps xmm6, [rsp+0x60]
00007f8fe1fdff7f  vmovaps xmm7, [rsp+0x70]
00007f8fe1fdff85  vmovaps xmm8, [rsp+0x80]
00007f8fe1fdff8e  vmovaps xmm9, [rsp+0x90]
00007f8fe1fdff97  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fdffa0  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fdffa9  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fdffb2  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fdffbb  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fdffc4  add rsp, 0xF0
00007f8fe1fdffcb  pop r11
00007f8fe1fdffcd  pop r10
00007f8fe1fdffcf  pop r9
00007f8fe1fdffd1  pop r8
00007f8fe1fdffd3  pop rsi
00007f8fe1fdffd4  pop rdi
00007f8fe1fdffd5  pop rdx
00007f8fe1fdffd6  pop rcx
00007f8fe1fdffd7  pop rax
00007f8fe1fdffd8  add rsp, 0x08
00007f8fe1fdffdc  jmp 0x00007F8FE1FDC53B
00007f8fe1fdffe1  sub rsp, 0x08
00007f8fe1fdffe5  push rax
00007f8fe1fdffe6  push rcx
00007f8fe1fdffe7  push rdx
00007f8fe1fdffe8  push rdi
00007f8fe1fdffe9  push rsi
00007f8fe1fdffea  push r8
00007f8fe1fdffec  push r9
00007f8fe1fdffee  push r10
00007f8fe1fdfff0  push r11
00007f8fe1fdfff2  sub rsp, 0xF0
00007f8fe1fdfff9  vmovaps [rsp], xmm0
00007f8fe1fdfffe  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0004  vmovaps [rsp+0x20], xmm2
00007f8fe1fe000a  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0010  vmovaps [rsp+0x40], xmm4
00007f8fe1fe0016  vmovaps [rsp+0x50], xmm5
00007f8fe1fe001c  vmovaps [rsp+0x60], xmm6
00007f8fe1fe0022  vmovaps [rsp+0x70], xmm7
00007f8fe1fe0028  vmovaps [rsp+0x80], xmm9
00007f8fe1fe0031  vmovaps [rsp+0x90], xmm10
00007f8fe1fe003a  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe0043  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe004c  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe0055  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe005e  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe0067  sub rsp, 0x30
00007f8fe1fe006b  movaps [rsp], xmm8
00007f8fe1fe0070  movaps [rsp+0x10], xmm1
00007f8fe1fe0075  movaps [rsp+0x20], xmm14
00007f8fe1fe007b  lea rdi, [rsp]
00007f8fe1fe007f  mov esi, 0x00
00007f8fe1fe0084  mov rax, 0x6020BB77F530
00007f8fe1fe008e  call rax
00007f8fe1fe0090  movaps xmm8, [rsp]
00007f8fe1fe0095  add rsp, 0x30
00007f8fe1fe0099  vmovaps xmm0, [rsp]
00007f8fe1fe009e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe00a4  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe00aa  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe00b0  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe00b6  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe00bc  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe00c2  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe00c8  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe00d1  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe00da  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe00e3  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe00ec  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe00f5  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe00fe  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0107  add rsp, 0xF0
00007f8fe1fe010e  pop r11
00007f8fe1fe0110  pop r10
00007f8fe1fe0112  pop r9
00007f8fe1fe0114  pop r8
00007f8fe1fe0116  pop rsi
00007f8fe1fe0117  pop rdi
00007f8fe1fe0118  pop rdx
00007f8fe1fe0119  pop rcx
00007f8fe1fe011a  pop rax
00007f8fe1fe011b  add rsp, 0x08
00007f8fe1fe011f  jmp 0x00007F8FE1FDC561
00007f8fe1fe0124  sub rsp, 0x08
00007f8fe1fe0128  push rax
00007f8fe1fe0129  push rcx
00007f8fe1fe012a  push rdx
00007f8fe1fe012b  push rdi
00007f8fe1fe012c  push rsi
00007f8fe1fe012d  push r8
00007f8fe1fe012f  push r9
00007f8fe1fe0131  push r10
00007f8fe1fe0133  push r11
00007f8fe1fe0135  sub rsp, 0xF0
00007f8fe1fe013c  vmovaps [rsp], xmm0
00007f8fe1fe0141  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0147  vmovaps [rsp+0x20], xmm2
00007f8fe1fe014d  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0153  vmovaps [rsp+0x40], xmm4
00007f8fe1fe0159  vmovaps [rsp+0x50], xmm5
00007f8fe1fe015f  vmovaps [rsp+0x60], xmm7
00007f8fe1fe0165  vmovaps [rsp+0x70], xmm8
00007f8fe1fe016b  vmovaps [rsp+0x80], xmm9
00007f8fe1fe0174  vmovaps [rsp+0x90], xmm10
00007f8fe1fe017d  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe0186  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe018f  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe0198  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe01a1  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe01aa  sub rsp, 0x30
00007f8fe1fe01ae  movaps [rsp], xmm6
00007f8fe1fe01b2  movaps [rsp+0x10], xmm1
00007f8fe1fe01b7  movaps [rsp+0x20], xmm14
00007f8fe1fe01bd  lea rdi, [rsp]
00007f8fe1fe01c1  mov esi, 0x00
00007f8fe1fe01c6  mov rax, 0x6020BB77F530
00007f8fe1fe01d0  call rax
00007f8fe1fe01d2  movaps xmm6, [rsp]
00007f8fe1fe01d6  add rsp, 0x30
00007f8fe1fe01da  vmovaps xmm0, [rsp]
00007f8fe1fe01df  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe01e5  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe01eb  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe01f1  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe01f7  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe01fd  vmovaps xmm7, [rsp+0x60]
00007f8fe1fe0203  vmovaps xmm8, [rsp+0x70]
00007f8fe1fe0209  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe0212  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe021b  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe0224  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe022d  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe0236  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe023f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0248  add rsp, 0xF0
00007f8fe1fe024f  pop r11
00007f8fe1fe0251  pop r10
00007f8fe1fe0253  pop r9
00007f8fe1fe0255  pop r8
00007f8fe1fe0257  pop rsi
00007f8fe1fe0258  pop rdi
00007f8fe1fe0259  pop rdx
00007f8fe1fe025a  pop rcx
00007f8fe1fe025b  pop rax
00007f8fe1fe025c  add rsp, 0x08
00007f8fe1fe0260  jmp 0x00007F8FE1FDC58D
00007f8fe1fe0265  sub rsp, 0x08
00007f8fe1fe0269  push rax
00007f8fe1fe026a  push rcx
00007f8fe1fe026b  push rdx
00007f8fe1fe026c  push rdi
00007f8fe1fe026d  push rsi
00007f8fe1fe026e  push r8
00007f8fe1fe0270  push r9
00007f8fe1fe0272  push r10
00007f8fe1fe0274  push r11
00007f8fe1fe0276  sub rsp, 0xF0
00007f8fe1fe027d  vmovaps [rsp], xmm0
00007f8fe1fe0282  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0288  vmovaps [rsp+0x20], xmm2
00007f8fe1fe028e  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0294  vmovaps [rsp+0x40], xmm4
00007f8fe1fe029a  vmovaps [rsp+0x50], xmm5
00007f8fe1fe02a0  vmovaps [rsp+0x60], xmm6
00007f8fe1fe02a6  vmovaps [rsp+0x70], xmm7
00007f8fe1fe02ac  vmovaps [rsp+0x80], xmm8
00007f8fe1fe02b5  vmovaps [rsp+0x90], xmm9
00007f8fe1fe02be  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe02c7  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe02d0  vmovaps [rsp+0xC0], xmm12
00007f8fe1fe02d9  vmovaps [rsp+0xD0], xmm13
00007f8fe1fe02e2  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe02eb  sub rsp, 0x30
00007f8fe1fe02ef  movaps [rsp], xmm14
00007f8fe1fe02f4  movaps [rsp+0x10], xmm12
00007f8fe1fe02fa  movaps [rsp+0x20], xmm1
00007f8fe1fe02ff  lea rdi, [rsp]
00007f8fe1fe0303  mov esi, 0x00
00007f8fe1fe0308  mov rax, 0x6020BB77F530
00007f8fe1fe0312  call rax
00007f8fe1fe0314  movaps xmm14, [rsp]
00007f8fe1fe0319  add rsp, 0x30
00007f8fe1fe031d  vmovaps xmm0, [rsp]
00007f8fe1fe0322  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe0328  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe032e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe0334  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe033a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe0340  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe0346  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe034c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe0355  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe035e  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe0367  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe0370  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fe0379  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fe0382  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe038b  add rsp, 0xF0
00007f8fe1fe0392  pop r11
00007f8fe1fe0394  pop r10
00007f8fe1fe0396  pop r9
00007f8fe1fe0398  pop r8
00007f8fe1fe039a  pop rsi
00007f8fe1fe039b  pop rdi
00007f8fe1fe039c  pop rdx
00007f8fe1fe039d  pop rcx
00007f8fe1fe039e  pop rax
00007f8fe1fe039f  add rsp, 0x08
00007f8fe1fe03a3  jmp 0x00007F8FE1FDC5B3
00007f8fe1fe03a8  sub rsp, 0x08
00007f8fe1fe03ac  push rax
00007f8fe1fe03ad  push rcx
00007f8fe1fe03ae  push rdx
00007f8fe1fe03af  push rdi
00007f8fe1fe03b0  push rsi
00007f8fe1fe03b1  push r8
00007f8fe1fe03b3  push r9
00007f8fe1fe03b5  push r10
00007f8fe1fe03b7  push r11
00007f8fe1fe03b9  sub rsp, 0xF0
00007f8fe1fe03c0  vmovaps [rsp], xmm0
00007f8fe1fe03c5  vmovaps [rsp+0x10], xmm2
00007f8fe1fe03cb  vmovaps [rsp+0x20], xmm3
00007f8fe1fe03d1  vmovaps [rsp+0x30], xmm4
00007f8fe1fe03d7  vmovaps [rsp+0x40], xmm5
00007f8fe1fe03dd  vmovaps [rsp+0x50], xmm6
00007f8fe1fe03e3  vmovaps [rsp+0x60], xmm7
00007f8fe1fe03e9  vmovaps [rsp+0x70], xmm8
00007f8fe1fe03ef  vmovaps [rsp+0x80], xmm9
00007f8fe1fe03f8  vmovaps [rsp+0x90], xmm10
00007f8fe1fe0401  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe040a  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe0413  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe041c  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe0425  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe042e  sub rsp, 0x30
00007f8fe1fe0432  movaps [rsp], xmm1
00007f8fe1fe0436  movaps [rsp+0x10], xmm13
00007f8fe1fe043c  movaps [rsp+0x20], xmm9
00007f8fe1fe0442  lea rdi, [rsp]
00007f8fe1fe0446  mov esi, 0x00
00007f8fe1fe044b  mov rax, 0x6020BB77F530
00007f8fe1fe0455  call rax
00007f8fe1fe0457  movaps xmm1, [rsp]
00007f8fe1fe045b  add rsp, 0x30
00007f8fe1fe045f  vmovaps xmm0, [rsp]
00007f8fe1fe0464  vmovaps xmm2, [rsp+0x10]
00007f8fe1fe046a  vmovaps xmm3, [rsp+0x20]
00007f8fe1fe0470  vmovaps xmm4, [rsp+0x30]
00007f8fe1fe0476  vmovaps xmm5, [rsp+0x40]
00007f8fe1fe047c  vmovaps xmm6, [rsp+0x50]
00007f8fe1fe0482  vmovaps xmm7, [rsp+0x60]
00007f8fe1fe0488  vmovaps xmm8, [rsp+0x70]
00007f8fe1fe048e  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe0497  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe04a0  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe04a9  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe04b2  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe04bb  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe04c4  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe04cd  add rsp, 0xF0
00007f8fe1fe04d4  pop r11
00007f8fe1fe04d6  pop r10
00007f8fe1fe04d8  pop r9
00007f8fe1fe04da  pop r8
00007f8fe1fe04dc  pop rsi
00007f8fe1fe04dd  pop rdi
00007f8fe1fe04de  pop rdx
00007f8fe1fe04df  pop rcx
00007f8fe1fe04e0  pop rax
00007f8fe1fe04e1  add rsp, 0x08
00007f8fe1fe04e5  jmp 0x00007F8FE1FDC5CD
00007f8fe1fe04ea  sub rsp, 0x08
00007f8fe1fe04ee  push rax
00007f8fe1fe04ef  push rcx
00007f8fe1fe04f0  push rdx
00007f8fe1fe04f1  push rdi
00007f8fe1fe04f2  push rsi
00007f8fe1fe04f3  push r8
00007f8fe1fe04f5  push r9
00007f8fe1fe04f7  push r10
00007f8fe1fe04f9  push r11
00007f8fe1fe04fb  sub rsp, 0xF0
00007f8fe1fe0502  vmovaps [rsp], xmm0
00007f8fe1fe0507  vmovaps [rsp+0x10], xmm1
00007f8fe1fe050d  vmovaps [rsp+0x20], xmm2
00007f8fe1fe0513  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0519  vmovaps [rsp+0x40], xmm4
00007f8fe1fe051f  vmovaps [rsp+0x50], xmm5
00007f8fe1fe0525  vmovaps [rsp+0x60], xmm6
00007f8fe1fe052b  vmovaps [rsp+0x70], xmm7
00007f8fe1fe0531  vmovaps [rsp+0x80], xmm8
00007f8fe1fe053a  vmovaps [rsp+0x90], xmm9
00007f8fe1fe0543  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe054c  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe0555  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe055e  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe0567  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe0570  sub rsp, 0x30
00007f8fe1fe0574  movaps [rsp], xmm12
00007f8fe1fe0579  movaps [rsp+0x10], xmm7
00007f8fe1fe057e  movaps [rsp+0x20], xmm13
00007f8fe1fe0584  lea rdi, [rsp]
00007f8fe1fe0588  mov esi, 0x00
00007f8fe1fe058d  mov rax, 0x6020BB77F530
00007f8fe1fe0597  call rax
00007f8fe1fe0599  movaps xmm12, [rsp]
00007f8fe1fe059e  add rsp, 0x30
00007f8fe1fe05a2  vmovaps xmm0, [rsp]
00007f8fe1fe05a7  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe05ad  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe05b3  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe05b9  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe05bf  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe05c5  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe05cb  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe05d1  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe05da  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe05e3  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe05ec  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe05f5  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe05fe  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe0607  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0610  add rsp, 0xF0
00007f8fe1fe0617  pop r11
00007f8fe1fe0619  pop r10
00007f8fe1fe061b  pop r9
00007f8fe1fe061d  pop r8
00007f8fe1fe061f  pop rsi
00007f8fe1fe0620  pop rdi
00007f8fe1fe0621  pop rdx
00007f8fe1fe0622  pop rcx
00007f8fe1fe0623  pop rax
00007f8fe1fe0624  add rsp, 0x08
00007f8fe1fe0628  jmp 0x00007F8FE1FDC5F4
00007f8fe1fe062d  sub rsp, 0x08
00007f8fe1fe0631  push rax
00007f8fe1fe0632  push rcx
00007f8fe1fe0633  push rdx
00007f8fe1fe0634  push rdi
00007f8fe1fe0635  push rsi
00007f8fe1fe0636  push r8
00007f8fe1fe0638  push r9
00007f8fe1fe063a  push r10
00007f8fe1fe063c  push r11
00007f8fe1fe063e  sub rsp, 0xF0
00007f8fe1fe0645  vmovaps [rsp], xmm0
00007f8fe1fe064a  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0650  vmovaps [rsp+0x20], xmm2
00007f8fe1fe0656  vmovaps [rsp+0x30], xmm3
00007f8fe1fe065c  vmovaps [rsp+0x40], xmm4
00007f8fe1fe0662  vmovaps [rsp+0x50], xmm5
00007f8fe1fe0668  vmovaps [rsp+0x60], xmm6
00007f8fe1fe066e  vmovaps [rsp+0x70], xmm7
00007f8fe1fe0674  vmovaps [rsp+0x80], xmm8
00007f8fe1fe067d  vmovaps [rsp+0x90], xmm9
00007f8fe1fe0686  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe068f  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe0698  vmovaps [rsp+0xC0], xmm12
00007f8fe1fe06a1  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe06aa  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe06b3  sub rsp, 0x30
00007f8fe1fe06b7  movaps [rsp], xmm13
00007f8fe1fe06bc  movaps [rsp+0x10], xmm15
00007f8fe1fe06c2  movaps [rsp+0x20], xmm8
00007f8fe1fe06c8  lea rdi, [rsp]
00007f8fe1fe06cc  mov esi, 0x00
00007f8fe1fe06d1  mov rax, 0x6020BB77F530
00007f8fe1fe06db  call rax
00007f8fe1fe06dd  movaps xmm13, [rsp]
00007f8fe1fe06e2  add rsp, 0x30
00007f8fe1fe06e6  vmovaps xmm0, [rsp]
00007f8fe1fe06eb  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe06f1  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe06f7  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe06fd  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe0703  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe0709  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe070f  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe0715  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe071e  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe0727  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe0730  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe0739  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fe0742  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe074b  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0754  add rsp, 0xF0
00007f8fe1fe075b  pop r11
00007f8fe1fe075d  pop r10
00007f8fe1fe075f  pop r9
00007f8fe1fe0761  pop r8
00007f8fe1fe0763  pop rsi
00007f8fe1fe0764  pop rdi
00007f8fe1fe0765  pop rdx
00007f8fe1fe0766  pop rcx
00007f8fe1fe0767  pop rax
00007f8fe1fe0768  add rsp, 0x08
00007f8fe1fe076c  jmp 0x00007F8FE1FDC60F
00007f8fe1fe0771  sub rsp, 0x08
00007f8fe1fe0775  push rax
00007f8fe1fe0776  push rcx
00007f8fe1fe0777  push rdx
00007f8fe1fe0778  push rdi
00007f8fe1fe0779  push rsi
00007f8fe1fe077a  push r8
00007f8fe1fe077c  push r9
00007f8fe1fe077e  push r10
00007f8fe1fe0780  push r11
00007f8fe1fe0782  sub rsp, 0xF0
00007f8fe1fe0789  vmovaps [rsp], xmm0
00007f8fe1fe078e  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0794  vmovaps [rsp+0x20], xmm2
00007f8fe1fe079a  vmovaps [rsp+0x30], xmm3
00007f8fe1fe07a0  vmovaps [rsp+0x40], xmm4
00007f8fe1fe07a6  vmovaps [rsp+0x50], xmm5
00007f8fe1fe07ac  vmovaps [rsp+0x60], xmm6
00007f8fe1fe07b2  vmovaps [rsp+0x70], xmm7
00007f8fe1fe07b8  vmovaps [rsp+0x80], xmm9
00007f8fe1fe07c1  vmovaps [rsp+0x90], xmm10
00007f8fe1fe07ca  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe07d3  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe07dc  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe07e5  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe07ee  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe07f7  sub rsp, 0x30
00007f8fe1fe07fb  movaps [rsp], xmm8
00007f8fe1fe0800  movaps [rsp+0x10], xmm15
00007f8fe1fe0806  movaps [rsp+0x20], xmm9
00007f8fe1fe080c  lea rdi, [rsp]
00007f8fe1fe0810  mov esi, 0x00
00007f8fe1fe0815  mov rax, 0x6020BB77F530
00007f8fe1fe081f  call rax
00007f8fe1fe0821  movaps xmm8, [rsp]
00007f8fe1fe0826  add rsp, 0x30
00007f8fe1fe082a  vmovaps xmm0, [rsp]
00007f8fe1fe082f  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe0835  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe083b  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe0841  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe0847  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe084d  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe0853  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe0859  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe0862  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe086b  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe0874  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe087d  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe0886  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe088f  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0898  add rsp, 0xF0
00007f8fe1fe089f  pop r11
00007f8fe1fe08a1  pop r10
00007f8fe1fe08a3  pop r9
00007f8fe1fe08a5  pop r8
00007f8fe1fe08a7  pop rsi
00007f8fe1fe08a8  pop rdi
00007f8fe1fe08a9  pop rdx
00007f8fe1fe08aa  pop rcx
00007f8fe1fe08ab  pop rax
00007f8fe1fe08ac  add rsp, 0x08
00007f8fe1fe08b0  jmp 0x00007F8FE1FDC63D
00007f8fe1fe08b5  sub rsp, 0x08
00007f8fe1fe08b9  push rax
00007f8fe1fe08ba  push rcx
00007f8fe1fe08bb  push rdx
00007f8fe1fe08bc  push rdi
00007f8fe1fe08bd  push rsi
00007f8fe1fe08be  push r8
00007f8fe1fe08c0  push r9
00007f8fe1fe08c2  push r10
00007f8fe1fe08c4  push r11
00007f8fe1fe08c6  sub rsp, 0xF0
00007f8fe1fe08cd  vmovaps [rsp], xmm0
00007f8fe1fe08d2  vmovaps [rsp+0x10], xmm1
00007f8fe1fe08d8  vmovaps [rsp+0x20], xmm2
00007f8fe1fe08de  vmovaps [rsp+0x30], xmm3
00007f8fe1fe08e4  vmovaps [rsp+0x40], xmm4
00007f8fe1fe08ea  vmovaps [rsp+0x50], xmm5
00007f8fe1fe08f0  vmovaps [rsp+0x60], xmm6
00007f8fe1fe08f6  vmovaps [rsp+0x70], xmm7
00007f8fe1fe08fc  vmovaps [rsp+0x80], xmm8
00007f8fe1fe0905  vmovaps [rsp+0x90], xmm9
00007f8fe1fe090e  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe0917  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe0920  vmovaps [rsp+0xC0], xmm12
00007f8fe1fe0929  vmovaps [rsp+0xD0], xmm13
00007f8fe1fe0932  vmovaps [rsp+0xE0], xmm14
00007f8fe1fe093b  sub rsp, 0x30
00007f8fe1fe093f  movaps [rsp], xmm15
00007f8fe1fe0944  movaps [rsp+0x10], xmm11
00007f8fe1fe094a  movaps [rsp+0x20], xmm6
00007f8fe1fe094f  lea rdi, [rsp]
00007f8fe1fe0953  mov esi, 0x00
00007f8fe1fe0958  mov rax, 0x6020BB77F530
00007f8fe1fe0962  call rax
00007f8fe1fe0964  movaps xmm15, [rsp]
00007f8fe1fe0969  add rsp, 0x30
00007f8fe1fe096d  vmovaps xmm0, [rsp]
00007f8fe1fe0972  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe0978  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe097e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe0984  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe098a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe0990  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe0996  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe099c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe09a5  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe09ae  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe09b7  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe09c0  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fe09c9  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fe09d2  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fe09db  add rsp, 0xF0
00007f8fe1fe09e2  pop r11
00007f8fe1fe09e4  pop r10
00007f8fe1fe09e6  pop r9
00007f8fe1fe09e8  pop r8
00007f8fe1fe09ea  pop rsi
00007f8fe1fe09eb  pop rdi
00007f8fe1fe09ec  pop rdx
00007f8fe1fe09ed  pop rcx
00007f8fe1fe09ee  pop rax
00007f8fe1fe09ef  add rsp, 0x08
00007f8fe1fe09f3  jmp 0x00007F8FE1FDC658
00007f8fe1fe09f8  sub rsp, 0x08
00007f8fe1fe09fc  push rax
00007f8fe1fe09fd  push rcx
00007f8fe1fe09fe  push rdx
00007f8fe1fe09ff  push rdi
00007f8fe1fe0a00  push rsi
00007f8fe1fe0a01  push r8
00007f8fe1fe0a03  push r9
00007f8fe1fe0a05  push r10
00007f8fe1fe0a07  push r11
00007f8fe1fe0a09  sub rsp, 0xF0
00007f8fe1fe0a10  vmovaps [rsp], xmm0
00007f8fe1fe0a15  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0a1b  vmovaps [rsp+0x20], xmm2
00007f8fe1fe0a21  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0a27  vmovaps [rsp+0x40], xmm4
00007f8fe1fe0a2d  vmovaps [rsp+0x50], xmm5
00007f8fe1fe0a33  vmovaps [rsp+0x60], xmm6
00007f8fe1fe0a39  vmovaps [rsp+0x70], xmm8
00007f8fe1fe0a3f  vmovaps [rsp+0x80], xmm9
00007f8fe1fe0a48  vmovaps [rsp+0x90], xmm10
00007f8fe1fe0a51  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe0a5a  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe0a63  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe0a6c  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe0a75  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe0a7e  sub rsp, 0x30
00007f8fe1fe0a82  movaps [rsp], xmm7
00007f8fe1fe0a86  movaps [rsp+0x10], xmm11
00007f8fe1fe0a8c  movaps [rsp+0x20], xmm9
00007f8fe1fe0a92  lea rdi, [rsp]
00007f8fe1fe0a96  mov esi, 0x00
00007f8fe1fe0a9b  mov rax, 0x6020BB77F530
00007f8fe1fe0aa5  call rax
00007f8fe1fe0aa7  movaps xmm7, [rsp]
00007f8fe1fe0aab  add rsp, 0x30
00007f8fe1fe0aaf  vmovaps xmm0, [rsp]
00007f8fe1fe0ab4  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe0aba  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe0ac0  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe0ac6  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe0acc  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe0ad2  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe0ad8  vmovaps xmm8, [rsp+0x70]
00007f8fe1fe0ade  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe0ae7  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe0af0  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe0af9  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe0b02  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe0b0b  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe0b14  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0b1d  add rsp, 0xF0
00007f8fe1fe0b24  pop r11
00007f8fe1fe0b26  pop r10
00007f8fe1fe0b28  pop r9
00007f8fe1fe0b2a  pop r8
00007f8fe1fe0b2c  pop rsi
00007f8fe1fe0b2d  pop rdi
00007f8fe1fe0b2e  pop rdx
00007f8fe1fe0b2f  pop rcx
00007f8fe1fe0b30  pop rax
00007f8fe1fe0b31  add rsp, 0x08
00007f8fe1fe0b35  jmp 0x00007F8FE1FDC685
00007f8fe1fe0b3a  sub rsp, 0x08
00007f8fe1fe0b3e  push rax
00007f8fe1fe0b3f  push rcx
00007f8fe1fe0b40  push rdx
00007f8fe1fe0b41  push rdi
00007f8fe1fe0b42  push rsi
00007f8fe1fe0b43  push r8
00007f8fe1fe0b45  push r9
00007f8fe1fe0b47  push r10
00007f8fe1fe0b49  push r11
00007f8fe1fe0b4b  sub rsp, 0xF0
00007f8fe1fe0b52  vmovaps [rsp], xmm0
00007f8fe1fe0b57  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0b5d  vmovaps [rsp+0x20], xmm2
00007f8fe1fe0b63  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0b69  vmovaps [rsp+0x40], xmm4
00007f8fe1fe0b6f  vmovaps [rsp+0x50], xmm5
00007f8fe1fe0b75  vmovaps [rsp+0x60], xmm6
00007f8fe1fe0b7b  vmovaps [rsp+0x70], xmm7
00007f8fe1fe0b81  vmovaps [rsp+0x80], xmm8
00007f8fe1fe0b8a  vmovaps [rsp+0x90], xmm9
00007f8fe1fe0b93  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe0b9c  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe0ba5  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe0bae  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe0bb7  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe0bc0  sub rsp, 0x30
00007f8fe1fe0bc4  movaps [rsp], xmm11
00007f8fe1fe0bc9  movaps [rsp+0x10], xmm10
00007f8fe1fe0bcf  movaps [rsp+0x20], xmm14
00007f8fe1fe0bd5  lea rdi, [rsp]
00007f8fe1fe0bd9  mov esi, 0x00
00007f8fe1fe0bde  mov rax, 0x6020BB77F530
00007f8fe1fe0be8  call rax
00007f8fe1fe0bea  movaps xmm11, [rsp]
00007f8fe1fe0bef  add rsp, 0x30
00007f8fe1fe0bf3  vmovaps xmm0, [rsp]
00007f8fe1fe0bf8  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe0bfe  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe0c04  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe0c0a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe0c10  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe0c16  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe0c1c  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe0c22  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe0c2b  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe0c34  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe0c3d  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe0c46  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe0c4f  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe0c58  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0c61  add rsp, 0xF0
00007f8fe1fe0c68  pop r11
00007f8fe1fe0c6a  pop r10
00007f8fe1fe0c6c  pop r9
00007f8fe1fe0c6e  pop r8
00007f8fe1fe0c70  pop rsi
00007f8fe1fe0c71  pop rdi
00007f8fe1fe0c72  pop rdx
00007f8fe1fe0c73  pop rcx
00007f8fe1fe0c74  pop rax
00007f8fe1fe0c75  add rsp, 0x08
00007f8fe1fe0c79  jmp 0x00007F8FE1FDC6A0
00007f8fe1fe0c7e  call 0x00007F8FE1EC33A0
00007f8fe1fe0c83  jmp 0x00007F8FE1FDC6AA
00007f8fe1fe0c88  sub rsp, 0x08
00007f8fe1fe0c8c  push rax
00007f8fe1fe0c8d  push rcx
00007f8fe1fe0c8e  push rdx
00007f8fe1fe0c8f  push rdi
00007f8fe1fe0c90  push rsi
00007f8fe1fe0c91  push r8
00007f8fe1fe0c93  push r9
00007f8fe1fe0c95  push r10
00007f8fe1fe0c97  push r11
00007f8fe1fe0c99  sub rsp, 0xF0
00007f8fe1fe0ca0  vmovaps [rsp], xmm0
00007f8fe1fe0ca5  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0cab  vmovaps [rsp+0x20], xmm2
00007f8fe1fe0cb1  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0cb7  vmovaps [rsp+0x40], xmm4
00007f8fe1fe0cbd  vmovaps [rsp+0x50], xmm5
00007f8fe1fe0cc3  vmovaps [rsp+0x60], xmm6
00007f8fe1fe0cc9  vmovaps [rsp+0x70], xmm7
00007f8fe1fe0ccf  vmovaps [rsp+0x80], xmm8
00007f8fe1fe0cd8  vmovaps [rsp+0x90], xmm9
00007f8fe1fe0ce1  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe0cea  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe0cf3  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe0cfc  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe0d05  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe0d0e  sub rsp, 0x30
00007f8fe1fe0d12  movaps [rsp], xmm10
00007f8fe1fe0d17  movaps [rsp+0x10], xmm1
00007f8fe1fe0d1c  movaps [rsp+0x20], xmm12
00007f8fe1fe0d22  lea rdi, [rsp]
00007f8fe1fe0d26  mov esi, 0x00
00007f8fe1fe0d2b  mov rax, 0x6020BB77F530
00007f8fe1fe0d35  call rax
00007f8fe1fe0d37  movaps xmm10, [rsp]
00007f8fe1fe0d3c  add rsp, 0x30
00007f8fe1fe0d40  vmovaps xmm0, [rsp]
00007f8fe1fe0d45  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe0d4b  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe0d51  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe0d57  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe0d5d  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe0d63  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe0d69  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe0d6f  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe0d78  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe0d81  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe0d8a  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe0d93  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe0d9c  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe0da5  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0dae  add rsp, 0xF0
00007f8fe1fe0db5  pop r11
00007f8fe1fe0db7  pop r10
00007f8fe1fe0db9  pop r9
00007f8fe1fe0dbb  pop r8
00007f8fe1fe0dbd  pop rsi
00007f8fe1fe0dbe  pop rdi
00007f8fe1fe0dbf  pop rdx
00007f8fe1fe0dc0  pop rcx
00007f8fe1fe0dc1  pop rax
00007f8fe1fe0dc2  add rsp, 0x08
00007f8fe1fe0dc6  jmp 0x00007F8FE1FDC6CD
00007f8fe1fe0dcb  sub rsp, 0x08
00007f8fe1fe0dcf  push rax
00007f8fe1fe0dd0  push rcx
00007f8fe1fe0dd1  push rdx
00007f8fe1fe0dd2  push rdi
00007f8fe1fe0dd3  push rsi
00007f8fe1fe0dd4  push r8
00007f8fe1fe0dd6  push r9
00007f8fe1fe0dd8  push r10
00007f8fe1fe0dda  push r11
00007f8fe1fe0ddc  sub rsp, 0xF0
00007f8fe1fe0de3  vmovaps [rsp], xmm0
00007f8fe1fe0de8  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0dee  vmovaps [rsp+0x20], xmm2
00007f8fe1fe0df4  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0dfa  vmovaps [rsp+0x40], xmm4
00007f8fe1fe0e00  vmovaps [rsp+0x50], xmm5
00007f8fe1fe0e06  vmovaps [rsp+0x60], xmm6
00007f8fe1fe0e0c  vmovaps [rsp+0x70], xmm7
00007f8fe1fe0e12  vmovaps [rsp+0x80], xmm8
00007f8fe1fe0e1b  vmovaps [rsp+0x90], xmm9
00007f8fe1fe0e24  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe0e2d  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe0e36  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe0e3f  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe0e48  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe0e51  sub rsp, 0x30
00007f8fe1fe0e55  movaps [rsp], xmm12
00007f8fe1fe0e5a  movaps [rsp+0x10], xmm14
00007f8fe1fe0e60  movaps [rsp+0x20], xmm1
00007f8fe1fe0e65  lea rdi, [rsp]
00007f8fe1fe0e69  mov esi, 0x00
00007f8fe1fe0e6e  mov rax, 0x6020BB77F530
00007f8fe1fe0e78  call rax
00007f8fe1fe0e7a  movaps xmm12, [rsp]
00007f8fe1fe0e7f  add rsp, 0x30
00007f8fe1fe0e83  vmovaps xmm0, [rsp]
00007f8fe1fe0e88  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe0e8e  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe0e94  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe0e9a  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe0ea0  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe0ea6  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe0eac  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe0eb2  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe0ebb  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe0ec4  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe0ecd  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe0ed6  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe0edf  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe0ee8  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe0ef1  add rsp, 0xF0
00007f8fe1fe0ef8  pop r11
00007f8fe1fe0efa  pop r10
00007f8fe1fe0efc  pop r9
00007f8fe1fe0efe  pop r8
00007f8fe1fe0f00  pop rsi
00007f8fe1fe0f01  pop rdi
00007f8fe1fe0f02  pop rdx
00007f8fe1fe0f03  pop rcx
00007f8fe1fe0f04  pop rax
00007f8fe1fe0f05  add rsp, 0x08
00007f8fe1fe0f09  jmp 0x00007F8FE1FDC6FC
00007f8fe1fe0f0e  sub rsp, 0x08
00007f8fe1fe0f12  push rax
00007f8fe1fe0f13  push rcx
00007f8fe1fe0f14  push rdx
00007f8fe1fe0f15  push rdi
00007f8fe1fe0f16  push rsi
00007f8fe1fe0f17  push r8
00007f8fe1fe0f19  push r9
00007f8fe1fe0f1b  push r10
00007f8fe1fe0f1d  push r11
00007f8fe1fe0f1f  sub rsp, 0xF0
00007f8fe1fe0f26  vmovaps [rsp], xmm0
00007f8fe1fe0f2b  vmovaps [rsp+0x10], xmm1
00007f8fe1fe0f31  vmovaps [rsp+0x20], xmm2
00007f8fe1fe0f37  vmovaps [rsp+0x30], xmm3
00007f8fe1fe0f3d  vmovaps [rsp+0x40], xmm4
00007f8fe1fe0f43  vmovaps [rsp+0x50], xmm5
00007f8fe1fe0f49  vmovaps [rsp+0x60], xmm6
00007f8fe1fe0f4f  vmovaps [rsp+0x70], xmm7
00007f8fe1fe0f55  vmovaps [rsp+0x80], xmm8
00007f8fe1fe0f5e  vmovaps [rsp+0x90], xmm9
00007f8fe1fe0f67  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe0f70  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe0f79  vmovaps [rsp+0xC0], xmm12
00007f8fe1fe0f82  vmovaps [rsp+0xD0], xmm13
00007f8fe1fe0f8b  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe0f94  sub rsp, 0x30
00007f8fe1fe0f98  movaps [rsp], xmm14
00007f8fe1fe0f9d  movaps [rsp+0x10], xmm9
00007f8fe1fe0fa3  movaps [rsp+0x20], xmm1
00007f8fe1fe0fa8  lea rdi, [rsp]
00007f8fe1fe0fac  mov esi, 0x00
00007f8fe1fe0fb1  mov rax, 0x6020BB77F530
00007f8fe1fe0fbb  call rax
00007f8fe1fe0fbd  movaps xmm14, [rsp]
00007f8fe1fe0fc2  add rsp, 0x30
00007f8fe1fe0fc6  vmovaps xmm0, [rsp]
00007f8fe1fe0fcb  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe0fd1  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe0fd7  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe0fdd  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe0fe3  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe0fe9  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe0fef  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe0ff5  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe0ffe  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe1007  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe1010  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe1019  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fe1022  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fe102b  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe1034  add rsp, 0xF0
00007f8fe1fe103b  pop r11
00007f8fe1fe103d  pop r10
00007f8fe1fe103f  pop r9
00007f8fe1fe1041  pop r8
00007f8fe1fe1043  pop rsi
00007f8fe1fe1044  pop rdi
00007f8fe1fe1045  pop rdx
00007f8fe1fe1046  pop rcx
00007f8fe1fe1047  pop rax
00007f8fe1fe1048  add rsp, 0x08
00007f8fe1fe104c  jmp 0x00007F8FE1FDC72B
00007f8fe1fe1051  sub rsp, 0x08
00007f8fe1fe1055  push rax
00007f8fe1fe1056  push rcx
00007f8fe1fe1057  push rdx
00007f8fe1fe1058  push rdi
00007f8fe1fe1059  push rsi
00007f8fe1fe105a  push r8
00007f8fe1fe105c  push r9
00007f8fe1fe105e  push r10
00007f8fe1fe1060  push r11
00007f8fe1fe1062  sub rsp, 0xF0
00007f8fe1fe1069  vmovaps [rsp], xmm0
00007f8fe1fe106e  vmovaps [rsp+0x10], xmm2
00007f8fe1fe1074  vmovaps [rsp+0x20], xmm3
00007f8fe1fe107a  vmovaps [rsp+0x30], xmm4
00007f8fe1fe1080  vmovaps [rsp+0x40], xmm5
00007f8fe1fe1086  vmovaps [rsp+0x50], xmm6
00007f8fe1fe108c  vmovaps [rsp+0x60], xmm7
00007f8fe1fe1092  vmovaps [rsp+0x70], xmm8
00007f8fe1fe1098  vmovaps [rsp+0x80], xmm9
00007f8fe1fe10a1  vmovaps [rsp+0x90], xmm10
00007f8fe1fe10aa  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe10b3  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe10bc  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe10c5  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe10ce  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe10d7  sub rsp, 0x30
00007f8fe1fe10db  movaps [rsp], xmm1
00007f8fe1fe10df  movaps [rsp+0x10], xmm13
00007f8fe1fe10e5  movaps [rsp+0x20], xmm8
00007f8fe1fe10eb  lea rdi, [rsp]
00007f8fe1fe10ef  mov esi, 0x00
00007f8fe1fe10f4  mov rax, 0x6020BB77F530
00007f8fe1fe10fe  call rax
00007f8fe1fe1100  movaps xmm1, [rsp]
00007f8fe1fe1104  add rsp, 0x30
00007f8fe1fe1108  vmovaps xmm0, [rsp]
00007f8fe1fe110d  vmovaps xmm2, [rsp+0x10]
00007f8fe1fe1113  vmovaps xmm3, [rsp+0x20]
00007f8fe1fe1119  vmovaps xmm4, [rsp+0x30]
00007f8fe1fe111f  vmovaps xmm5, [rsp+0x40]
00007f8fe1fe1125  vmovaps xmm6, [rsp+0x50]
00007f8fe1fe112b  vmovaps xmm7, [rsp+0x60]
00007f8fe1fe1131  vmovaps xmm8, [rsp+0x70]
00007f8fe1fe1137  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe1140  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe1149  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe1152  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe115b  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe1164  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe116d  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe1176  add rsp, 0xF0
00007f8fe1fe117d  pop r11
00007f8fe1fe117f  pop r10
00007f8fe1fe1181  pop r9
00007f8fe1fe1183  pop r8
00007f8fe1fe1185  pop rsi
00007f8fe1fe1186  pop rdi
00007f8fe1fe1187  pop rdx
00007f8fe1fe1188  pop rcx
00007f8fe1fe1189  pop rax
00007f8fe1fe118a  add rsp, 0x08
00007f8fe1fe118e  jmp 0x00007F8FE1FDC74D
00007f8fe1fe1193  call 0x00007F8FE1E0C260
00007f8fe1fe1198  jmp 0x00007F8FE1FDC75B
00007f8fe1fe119d  call 0x00007F8FE1EBD750
00007f8fe1fe11a2  jmp 0x00007F8FE1FDC765
00007f8fe1fe11a7  sub rsp, 0x08
00007f8fe1fe11ab  push rax
00007f8fe1fe11ac  push rcx
00007f8fe1fe11ad  push rdx
00007f8fe1fe11ae  push rdi
00007f8fe1fe11af  push rsi
00007f8fe1fe11b0  push r8
00007f8fe1fe11b2  push r9
00007f8fe1fe11b4  push r10
00007f8fe1fe11b6  push r11
00007f8fe1fe11b8  sub rsp, 0xF0
00007f8fe1fe11bf  vmovaps [rsp], xmm0
00007f8fe1fe11c4  vmovaps [rsp+0x10], xmm1
00007f8fe1fe11ca  vmovaps [rsp+0x20], xmm2
00007f8fe1fe11d0  vmovaps [rsp+0x30], xmm3
00007f8fe1fe11d6  vmovaps [rsp+0x40], xmm4
00007f8fe1fe11dc  vmovaps [rsp+0x50], xmm5
00007f8fe1fe11e2  vmovaps [rsp+0x60], xmm6
00007f8fe1fe11e8  vmovaps [rsp+0x70], xmm7
00007f8fe1fe11ee  vmovaps [rsp+0x80], xmm9
00007f8fe1fe11f7  vmovaps [rsp+0x90], xmm10
00007f8fe1fe1200  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe1209  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe1212  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe121b  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe1224  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe122d  sub rsp, 0x30
00007f8fe1fe1231  movaps [rsp], xmm8
00007f8fe1fe1236  movaps [rsp+0x10], xmm15
00007f8fe1fe123c  movaps [rsp+0x20], xmm7
00007f8fe1fe1241  lea rdi, [rsp]
00007f8fe1fe1245  mov esi, 0x00
00007f8fe1fe124a  mov rax, 0x6020BB77F530
00007f8fe1fe1254  call rax
00007f8fe1fe1256  movaps xmm8, [rsp]
00007f8fe1fe125b  add rsp, 0x30
00007f8fe1fe125f  vmovaps xmm0, [rsp]
00007f8fe1fe1264  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe126a  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe1270  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe1276  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe127c  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe1282  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe1288  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe128e  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe1297  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe12a0  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe12a9  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe12b2  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe12bb  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe12c4  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe12cd  add rsp, 0xF0
00007f8fe1fe12d4  pop r11
00007f8fe1fe12d6  pop r10
00007f8fe1fe12d8  pop r9
00007f8fe1fe12da  pop r8
00007f8fe1fe12dc  pop rsi
00007f8fe1fe12dd  pop rdi
00007f8fe1fe12de  pop rdx
00007f8fe1fe12df  pop rcx
00007f8fe1fe12e0  pop rax
00007f8fe1fe12e1  add rsp, 0x08
00007f8fe1fe12e5  jmp 0x00007F8FE1FDC787
00007f8fe1fe12ea  sub rsp, 0x08
00007f8fe1fe12ee  push rax
00007f8fe1fe12ef  push rcx
00007f8fe1fe12f0  push rdx
00007f8fe1fe12f1  push rdi
00007f8fe1fe12f2  push rsi
00007f8fe1fe12f3  push r8
00007f8fe1fe12f5  push r9
00007f8fe1fe12f7  push r10
00007f8fe1fe12f9  push r11
00007f8fe1fe12fb  sub rsp, 0xF0
00007f8fe1fe1302  vmovaps [rsp], xmm0
00007f8fe1fe1307  vmovaps [rsp+0x10], xmm1
00007f8fe1fe130d  vmovaps [rsp+0x20], xmm2
00007f8fe1fe1313  vmovaps [rsp+0x30], xmm3
00007f8fe1fe1319  vmovaps [rsp+0x40], xmm4
00007f8fe1fe131f  vmovaps [rsp+0x50], xmm5
00007f8fe1fe1325  vmovaps [rsp+0x60], xmm6
00007f8fe1fe132b  vmovaps [rsp+0x70], xmm8
00007f8fe1fe1331  vmovaps [rsp+0x80], xmm9
00007f8fe1fe133a  vmovaps [rsp+0x90], xmm10
00007f8fe1fe1343  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe134c  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe1355  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe135e  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe1367  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe1370  sub rsp, 0x30
00007f8fe1fe1374  movaps [rsp], xmm7
00007f8fe1fe1378  movaps [rsp+0x10], xmm9
00007f8fe1fe137e  movaps [rsp+0x20], xmm15
00007f8fe1fe1384  lea rdi, [rsp]
00007f8fe1fe1388  mov esi, 0x00
00007f8fe1fe138d  mov rax, 0x6020BB77F530
00007f8fe1fe1397  call rax
00007f8fe1fe1399  movaps xmm7, [rsp]
00007f8fe1fe139d  add rsp, 0x30
00007f8fe1fe13a1  vmovaps xmm0, [rsp]
00007f8fe1fe13a6  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe13ac  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe13b2  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe13b8  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe13be  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe13c4  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe13ca  vmovaps xmm8, [rsp+0x70]
00007f8fe1fe13d0  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe13d9  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe13e2  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe13eb  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe13f4  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe13fd  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe1406  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe140f  add rsp, 0xF0
00007f8fe1fe1416  pop r11
00007f8fe1fe1418  pop r10
00007f8fe1fe141a  pop r9
00007f8fe1fe141c  pop r8
00007f8fe1fe141e  pop rsi
00007f8fe1fe141f  pop rdi
00007f8fe1fe1420  pop rdx
00007f8fe1fe1421  pop rcx
00007f8fe1fe1422  pop rax
00007f8fe1fe1423  add rsp, 0x08
00007f8fe1fe1427  jmp 0x00007F8FE1FDC7B4
00007f8fe1fe142c  sub rsp, 0x08
00007f8fe1fe1430  push rax
00007f8fe1fe1431  push rcx
00007f8fe1fe1432  push rdx
00007f8fe1fe1433  push rdi
00007f8fe1fe1434  push rsi
00007f8fe1fe1435  push r8
00007f8fe1fe1437  push r9
00007f8fe1fe1439  push r10
00007f8fe1fe143b  push r11
00007f8fe1fe143d  sub rsp, 0xF0
00007f8fe1fe1444  vmovaps [rsp], xmm0
00007f8fe1fe1449  vmovaps [rsp+0x10], xmm1
00007f8fe1fe144f  vmovaps [rsp+0x20], xmm2
00007f8fe1fe1455  vmovaps [rsp+0x30], xmm3
00007f8fe1fe145b  vmovaps [rsp+0x40], xmm4
00007f8fe1fe1461  vmovaps [rsp+0x50], xmm5
00007f8fe1fe1467  vmovaps [rsp+0x60], xmm6
00007f8fe1fe146d  vmovaps [rsp+0x70], xmm7
00007f8fe1fe1473  vmovaps [rsp+0x80], xmm8
00007f8fe1fe147c  vmovaps [rsp+0x90], xmm10
00007f8fe1fe1485  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe148e  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe1497  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe14a0  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe14a9  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe14b2  sub rsp, 0x30
00007f8fe1fe14b6  movaps [rsp], xmm9
00007f8fe1fe14bb  movaps [rsp+0x10], xmm13
00007f8fe1fe14c1  movaps [rsp+0x20], xmm15
00007f8fe1fe14c7  lea rdi, [rsp]
00007f8fe1fe14cb  mov esi, 0x00
00007f8fe1fe14d0  mov rax, 0x6020BB77F530
00007f8fe1fe14da  call rax
00007f8fe1fe14dc  movaps xmm9, [rsp]
00007f8fe1fe14e1  add rsp, 0x30
00007f8fe1fe14e5  vmovaps xmm0, [rsp]
00007f8fe1fe14ea  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe14f0  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe14f6  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe14fc  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe1502  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe1508  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe150e  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe1514  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe151d  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe1526  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe152f  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe1538  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe1541  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe154a  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe1553  add rsp, 0xF0
00007f8fe1fe155a  pop r11
00007f8fe1fe155c  pop r10
00007f8fe1fe155e  pop r9
00007f8fe1fe1560  pop r8
00007f8fe1fe1562  pop rsi
00007f8fe1fe1563  pop rdi
00007f8fe1fe1564  pop rdx
00007f8fe1fe1565  pop rcx
00007f8fe1fe1566  pop rax
00007f8fe1fe1567  add rsp, 0x08
00007f8fe1fe156b  jmp 0x00007F8FE1FDC7E2
00007f8fe1fe1570  sub rsp, 0x08
00007f8fe1fe1574  push rax
00007f8fe1fe1575  push rcx
00007f8fe1fe1576  push rdx
00007f8fe1fe1577  push rdi
00007f8fe1fe1578  push rsi
00007f8fe1fe1579  push r8
00007f8fe1fe157b  push r9
00007f8fe1fe157d  push r10
00007f8fe1fe157f  push r11
00007f8fe1fe1581  sub rsp, 0xF0
00007f8fe1fe1588  vmovaps [rsp], xmm0
00007f8fe1fe158d  vmovaps [rsp+0x10], xmm1
00007f8fe1fe1593  vmovaps [rsp+0x20], xmm2
00007f8fe1fe1599  vmovaps [rsp+0x30], xmm3
00007f8fe1fe159f  vmovaps [rsp+0x40], xmm4
00007f8fe1fe15a5  vmovaps [rsp+0x50], xmm5
00007f8fe1fe15ab  vmovaps [rsp+0x60], xmm6
00007f8fe1fe15b1  vmovaps [rsp+0x70], xmm7
00007f8fe1fe15b7  vmovaps [rsp+0x80], xmm8
00007f8fe1fe15c0  vmovaps [rsp+0x90], xmm9
00007f8fe1fe15c9  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe15d2  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe15db  vmovaps [rsp+0xC0], xmm12
00007f8fe1fe15e4  vmovaps [rsp+0xD0], xmm13
00007f8fe1fe15ed  vmovaps [rsp+0xE0], xmm14
00007f8fe1fe15f6  sub rsp, 0x30
00007f8fe1fe15fa  movaps [rsp], xmm15
00007f8fe1fe15ff  movaps [rsp+0x10], xmm11
00007f8fe1fe1605  movaps [rsp+0x20], xmm12
00007f8fe1fe160b  lea rdi, [rsp]
00007f8fe1fe160f  mov esi, 0x00
00007f8fe1fe1614  mov rax, 0x6020BB77F530
00007f8fe1fe161e  call rax
00007f8fe1fe1620  movaps xmm15, [rsp]
00007f8fe1fe1625  add rsp, 0x30
00007f8fe1fe1629  vmovaps xmm0, [rsp]
00007f8fe1fe162e  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe1634  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe163a  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe1640  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe1646  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe164c  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe1652  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe1658  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe1661  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe166a  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe1673  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe167c  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fe1685  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fe168e  vmovaps xmm14, [rsp+0xE0]
00007f8fe1fe1697  add rsp, 0xF0
00007f8fe1fe169e  pop r11
00007f8fe1fe16a0  pop r10
00007f8fe1fe16a2  pop r9
00007f8fe1fe16a4  pop r8
00007f8fe1fe16a6  pop rsi
00007f8fe1fe16a7  pop rdi
00007f8fe1fe16a8  pop rdx
00007f8fe1fe16a9  pop rcx
00007f8fe1fe16aa  pop rax
00007f8fe1fe16ab  add rsp, 0x08
00007f8fe1fe16af  jmp 0x00007F8FE1FDC7FD
00007f8fe1fe16b4  sub rsp, 0x08
00007f8fe1fe16b8  push rax
00007f8fe1fe16b9  push rcx
00007f8fe1fe16ba  push rdx
00007f8fe1fe16bb  push rdi
00007f8fe1fe16bc  push rsi
00007f8fe1fe16bd  push r8
00007f8fe1fe16bf  push r9
00007f8fe1fe16c1  push r10
00007f8fe1fe16c3  push r11
00007f8fe1fe16c5  sub rsp, 0xF0
00007f8fe1fe16cc  vmovaps [rsp], xmm0
00007f8fe1fe16d1  vmovaps [rsp+0x10], xmm1
00007f8fe1fe16d7  vmovaps [rsp+0x20], xmm2
00007f8fe1fe16dd  vmovaps [rsp+0x30], xmm3
00007f8fe1fe16e3  vmovaps [rsp+0x40], xmm4
00007f8fe1fe16e9  vmovaps [rsp+0x50], xmm5
00007f8fe1fe16ef  vmovaps [rsp+0x60], xmm6
00007f8fe1fe16f5  vmovaps [rsp+0x70], xmm7
00007f8fe1fe16fb  vmovaps [rsp+0x80], xmm8
00007f8fe1fe1704  vmovaps [rsp+0x90], xmm9
00007f8fe1fe170d  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe1716  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe171f  vmovaps [rsp+0xC0], xmm12
00007f8fe1fe1728  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe1731  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe173a  sub rsp, 0x30
00007f8fe1fe173e  movaps [rsp], xmm13
00007f8fe1fe1743  movaps [rsp+0x10], xmm10
00007f8fe1fe1749  movaps [rsp+0x20], xmm14
00007f8fe1fe174f  lea rdi, [rsp]
00007f8fe1fe1753  mov esi, 0x00
00007f8fe1fe1758  mov rax, 0x6020BB77F530
00007f8fe1fe1762  call rax
00007f8fe1fe1764  movaps xmm13, [rsp]
00007f8fe1fe1769  add rsp, 0x30
00007f8fe1fe176d  vmovaps xmm0, [rsp]
00007f8fe1fe1772  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe1778  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe177e  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe1784  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe178a  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe1790  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe1796  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe179c  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe17a5  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe17ae  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe17b7  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe17c0  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fe17c9  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe17d2  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe17db  add rsp, 0xF0
00007f8fe1fe17e2  pop r11
00007f8fe1fe17e4  pop r10
00007f8fe1fe17e6  pop r9
00007f8fe1fe17e8  pop r8
00007f8fe1fe17ea  pop rsi
00007f8fe1fe17eb  pop rdi
00007f8fe1fe17ec  pop rdx
00007f8fe1fe17ed  pop rcx
00007f8fe1fe17ee  pop rax
00007f8fe1fe17ef  add rsp, 0x08
00007f8fe1fe17f3  jmp 0x00007F8FE1FDC820
00007f8fe1fe17f8  sub rsp, 0x08
00007f8fe1fe17fc  push rax
00007f8fe1fe17fd  push rcx
00007f8fe1fe17fe  push rdx
00007f8fe1fe17ff  push rdi
00007f8fe1fe1800  push rsi
00007f8fe1fe1801  push r8
00007f8fe1fe1803  push r9
00007f8fe1fe1805  push r10
00007f8fe1fe1807  push r11
00007f8fe1fe1809  sub rsp, 0xF0
00007f8fe1fe1810  vmovaps [rsp], xmm0
00007f8fe1fe1815  vmovaps [rsp+0x10], xmm1
00007f8fe1fe181b  vmovaps [rsp+0x20], xmm2
00007f8fe1fe1821  vmovaps [rsp+0x30], xmm3
00007f8fe1fe1827  vmovaps [rsp+0x40], xmm4
00007f8fe1fe182d  vmovaps [rsp+0x50], xmm5
00007f8fe1fe1833  vmovaps [rsp+0x60], xmm6
00007f8fe1fe1839  vmovaps [rsp+0x70], xmm7
00007f8fe1fe183f  vmovaps [rsp+0x80], xmm8
00007f8fe1fe1848  vmovaps [rsp+0x90], xmm9
00007f8fe1fe1851  vmovaps [rsp+0xA0], xmm10
00007f8fe1fe185a  vmovaps [rsp+0xB0], xmm11
00007f8fe1fe1863  vmovaps [rsp+0xC0], xmm12
00007f8fe1fe186c  vmovaps [rsp+0xD0], xmm13
00007f8fe1fe1875  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe187e  sub rsp, 0x30
00007f8fe1fe1882  movaps [rsp], xmm14
00007f8fe1fe1887  movaps [rsp+0x10], xmm1
00007f8fe1fe188c  movaps [rsp+0x20], xmm7
00007f8fe1fe1891  lea rdi, [rsp]
00007f8fe1fe1895  mov esi, 0x00
00007f8fe1fe189a  mov rax, 0x6020BB77F530
00007f8fe1fe18a4  call rax
00007f8fe1fe18a6  movaps xmm14, [rsp]
00007f8fe1fe18ab  add rsp, 0x30
00007f8fe1fe18af  vmovaps xmm0, [rsp]
00007f8fe1fe18b4  vmovaps xmm1, [rsp+0x10]
00007f8fe1fe18ba  vmovaps xmm2, [rsp+0x20]
00007f8fe1fe18c0  vmovaps xmm3, [rsp+0x30]
00007f8fe1fe18c6  vmovaps xmm4, [rsp+0x40]
00007f8fe1fe18cc  vmovaps xmm5, [rsp+0x50]
00007f8fe1fe18d2  vmovaps xmm6, [rsp+0x60]
00007f8fe1fe18d8  vmovaps xmm7, [rsp+0x70]
00007f8fe1fe18de  vmovaps xmm8, [rsp+0x80]
00007f8fe1fe18e7  vmovaps xmm9, [rsp+0x90]
00007f8fe1fe18f0  vmovaps xmm10, [rsp+0xA0]
00007f8fe1fe18f9  vmovaps xmm11, [rsp+0xB0]
00007f8fe1fe1902  vmovaps xmm12, [rsp+0xC0]
00007f8fe1fe190b  vmovaps xmm13, [rsp+0xD0]
00007f8fe1fe1914  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe191d  add rsp, 0xF0
00007f8fe1fe1924  pop r11
00007f8fe1fe1926  pop r10
00007f8fe1fe1928  pop r9
00007f8fe1fe192a  pop r8
00007f8fe1fe192c  pop rsi
00007f8fe1fe192d  pop rdi
00007f8fe1fe192e  pop rdx
00007f8fe1fe192f  pop rcx
00007f8fe1fe1930  pop rax
00007f8fe1fe1931  add rsp, 0x08
00007f8fe1fe1935  jmp 0x00007F8FE1FDC843
00007f8fe1fe193a  sub rsp, 0x08
00007f8fe1fe193e  push rax
00007f8fe1fe193f  push rcx
00007f8fe1fe1940  push rdx
00007f8fe1fe1941  push rdi
00007f8fe1fe1942  push rsi
00007f8fe1fe1943  push r8
00007f8fe1fe1945  push r9
00007f8fe1fe1947  push r10
00007f8fe1fe1949  push r11
00007f8fe1fe194b  sub rsp, 0xF0
00007f8fe1fe1952  vmovaps [rsp], xmm0
00007f8fe1fe1957  vmovaps [rsp+0x10], xmm2
00007f8fe1fe195d  vmovaps [rsp+0x20], xmm3
00007f8fe1fe1963  vmovaps [rsp+0x30], xmm4
00007f8fe1fe1969  vmovaps [rsp+0x40], xmm5
00007f8fe1fe196f  vmovaps [rsp+0x50], xmm6
00007f8fe1fe1975  vmovaps [rsp+0x60], xmm7
00007f8fe1fe197b  vmovaps [rsp+0x70], xmm8
00007f8fe1fe1981  vmovaps [rsp+0x80], xmm9
00007f8fe1fe198a  vmovaps [rsp+0x90], xmm10
00007f8fe1fe1993  vmovaps [rsp+0xA0], xmm11
00007f8fe1fe199c  vmovaps [rsp+0xB0], xmm12
00007f8fe1fe19a5  vmovaps [rsp+0xC0], xmm13
00007f8fe1fe19ae  vmovaps [rsp+0xD0], xmm14
00007f8fe1fe19b7  vmovaps [rsp+0xE0], xmm15
00007f8fe1fe19c0  sub rsp, 0x30
00007f8fe1fe19c4  movaps [rsp], xmm1
00007f8fe1fe19c8  movaps [rsp+0x10], xmm8
00007f8fe1fe19ce  movaps [rsp+0x20], xmm9
00007f8fe1fe19d4  lea rdi, [rsp]
00007f8fe1fe19d8  mov esi, 0x00
00007f8fe1fe19dd  mov rax, 0x6020BB77F530
00007f8fe1fe19e7  call rax
00007f8fe1fe19e9  movaps xmm1, [rsp]
00007f8fe1fe19ed  add rsp, 0x30
00007f8fe1fe19f1  vmovaps xmm0, [rsp]
00007f8fe1fe19f6  vmovaps xmm2, [rsp+0x10]
00007f8fe1fe19fc  vmovaps xmm3, [rsp+0x20]
00007f8fe1fe1a02  vmovaps xmm4, [rsp+0x30]
00007f8fe1fe1a08  vmovaps xmm5, [rsp+0x40]
00007f8fe1fe1a0e  vmovaps xmm6, [rsp+0x50]
00007f8fe1fe1a14  vmovaps xmm7, [rsp+0x60]
00007f8fe1fe1a1a  vmovaps xmm8, [rsp+0x70]
00007f8fe1fe1a20  vmovaps xmm9, [rsp+0x80]
00007f8fe1fe1a29  vmovaps xmm10, [rsp+0x90]
00007f8fe1fe1a32  vmovaps xmm11, [rsp+0xA0]
00007f8fe1fe1a3b  vmovaps xmm12, [rsp+0xB0]
00007f8fe1fe1a44  vmovaps xmm13, [rsp+0xC0]
00007f8fe1fe1a4d  vmovaps xmm14, [rsp+0xD0]
00007f8fe1fe1a56  vmovaps xmm15, [rsp+0xE0]
00007f8fe1fe1a5f  add rsp, 0xF0
00007f8fe1fe1a66  pop r11
00007f8fe1fe1a68  pop r10
00007f8fe1fe1a6a  pop r9
00007f8fe1fe1a6c  pop r8
00007f8fe1fe1a6e  pop rsi
00007f8fe1fe1a6f  pop rdi
00007f8fe1fe1a70  pop rdx
00007f8fe1fe1a71  pop rcx
00007f8fe1fe1a72  pop rax
00007f8fe1fe1a73  add rsp, 0x08
00007f8fe1fe1a77  jmp 0x00007F8FE1FDC865
00007f8fe1fe1a7c  call 0x00007F8FE1EE5940
00007f8fe1fe1a81  jmp 0x00007F8FE1FDC873
00007f8fe1fe1a86  call 0x00007F8FE1E0C380
00007f8fe1fe1a8b  jmp 0x00007F8FE1FDC87D
00007f8fe1fe1a90  call 0x00007F8FE1E0D600
00007f8fe1fe1a95  jmp 0x00007F8FE1FDC887
00007f8fe1fe1a9a  call 0x00007F8FE1DFF540
00007f8fe1fe1a9f  jmp 0x00007F8FE1FDC891
00007f8fe1fe1aa4  int3
00007f8fe1fe1aa5  nop [rax+rax*1], ax
00007f8fe1fe1aae  nop
00007f8fe1fe1ab0  mov rax, [r15+0xF8]
00007f8fe1fe1ab7  lea r14, [rax+0x140]
00007f8fe1fe1abe  mov r12, [r13+r14*1]
00007f8fe1fe1ac3  mov [r15+0xE8], r12
00007f8fe1fe1aca  lea r14, [rax+0x130]
00007f8fe1fe1ad1  mov r12, [r13+r14*1]
00007f8fe1fe1ad6  lea r14, [rax+0x138]
00007f8fe1fe1add  mov r11, [r13+r14*1]
00007f8fe1fe1ae2  movq xmm1, r12
00007f8fe1fe1ae7  movq xmm15, r11
00007f8fe1fe1aec  movq xmm1, xmm1
00007f8fe1fe1af0  movq xmm1, xmm1
00007f8fe1fe1af4  movaps [r15+0x1A0], xmm1
00007f8fe1fe1afc  movq xmm15, xmm15
00007f8fe1fe1b01  movq xmm15, xmm15
00007f8fe1fe1b06  movaps [r15+0x190], xmm15
00007f8fe1fe1b0e  lea r14, [rax+0x120]
00007f8fe1fe1b15  mov r12, [r13+r14*1]
00007f8fe1fe1b1a  lea r14, [rax+0x128]
00007f8fe1fe1b21  mov r11, [r13+r14*1]
00007f8fe1fe1b26  movq xmm1, r12
00007f8fe1fe1b2b  movq xmm15, r11
00007f8fe1fe1b30  movq xmm1, xmm1
00007f8fe1fe1b34  movq xmm1, xmm1
00007f8fe1fe1b38  movaps [r15+0x1C0], xmm1
00007f8fe1fe1b40  movq xmm15, xmm15
00007f8fe1fe1b45  movq xmm15, xmm15
00007f8fe1fe1b4a  movaps [r15+0x1B0], xmm15
00007f8fe1fe1b52  lea r14, [rax+0x110]
00007f8fe1fe1b59  mov r12, [r13+r14*1]
00007f8fe1fe1b5e  lea r14, [rax+0x118]
00007f8fe1fe1b65  mov r11, [r13+r14*1]
00007f8fe1fe1b6a  movq xmm1, r12
00007f8fe1fe1b6f  movq xmm15, r11
00007f8fe1fe1b74  movq xmm1, xmm1
00007f8fe1fe1b78  movq xmm1, xmm1
00007f8fe1fe1b7c  movaps [r15+0x1E0], xmm1
00007f8fe1fe1b84  movq xmm15, xmm15
00007f8fe1fe1b89  movq xmm15, xmm15
00007f8fe1fe1b8e  movaps [r15+0x1D0], xmm15
00007f8fe1fe1b96  lea r14, [rax+0x100]
00007f8fe1fe1b9d  mov r12, [r13+r14*1]
00007f8fe1fe1ba2  lea r14, [rax+0x108]
00007f8fe1fe1ba9  mov r11, [r13+r14*1]
00007f8fe1fe1bae  movq xmm1, r12
00007f8fe1fe1bb3  movq xmm15, r11
00007f8fe1fe1bb8  movq xmm1, xmm1
00007f8fe1fe1bbc  movq xmm1, xmm1
00007f8fe1fe1bc0  movaps [r15+0x200], xmm1
00007f8fe1fe1bc8  movq xmm15, xmm15
00007f8fe1fe1bcd  movq xmm15, xmm15
00007f8fe1fe1bd2  movaps [r15+0x1F0], xmm15
00007f8fe1fe1bda  mov qword ptr [r15+0x40], 0x430000
00007f8fe1fe1be2  mov r14d, 0x430510
00007f8fe1fe1be8  mov r12, [r13+r14*1]
00007f8fe1fe1bed  movq xmm1, r12
00007f8fe1fe1bf2  lea r14, [rax+0x150]
00007f8fe1fe1bf9  mov [r15+0xF8], r14
00007f8fe1fe1c00  mov rax, [r15+0x50]
00007f8fe1fe1c04  movups xmm15, [r13+rax*1]
00007f8fe1fe1c0a  movaps [r15+0x120], xmm15
00007f8fe1fe1c12  mov qword ptr [r15+0x48], 0x10
00007f8fe1fe1c1a  xor eax, eax
00007f8fe1fe1c1c  mov r14d, 0x10
00007f8fe1fe1c22  mov r12d, 0x200
00007f8fe1fe1c28  cmp r14, r12
00007f8fe1fe1c2b  cmc
00007f8fe1fe1c2c  lahf
00007f8fe1fe1c2d  seto al
00007f8fe1fe1c30  mov [r15+0x108], eax
00007f8fe1fe1c37  pextrq rax, xmm15, 0x01
00007f8fe1fe1c3e  movq xmm14, rax
00007f8fe1fe1c43  movaps [r15+0x130], xmm14
00007f8fe1fe1c4b  movq rax, xmm1
00007f8fe1fe1c50  movq r14, xmm15
00007f8fe1fe1c55  vmovq xmm1, rax
00007f8fe1fe1c5a  vmovq xmm15, r14
00007f8fe1fe1c5f  movaps xmm13, xmm1
00007f8fe1fe1c63  addsd xmm13, xmm15
00007f8fe1fe1c68  ucomisd xmm13, xmm13
00007f8fe1fe1c6d  jp 0x00007F8FE1FE1D86
00007f8fe1fe1c73  movq xmm13, xmm13
00007f8fe1fe1c78  movq rax, xmm13
00007f8fe1fe1c7d  movq r14, xmm14
00007f8fe1fe1c82  vmovq xmm1, rax
00007f8fe1fe1c87  vmovq xmm15, r14
00007f8fe1fe1c8c  movaps xmm14, xmm1
00007f8fe1fe1c90  addsd xmm14, xmm15
00007f8fe1fe1c95  ucomisd xmm14, xmm14
00007f8fe1fe1c9a  jp 0x00007F8FE1FE1DCE
00007f8fe1fe1ca0  movq xmm14, xmm14
00007f8fe1fe1ca5  movaps [r15+0x110], xmm14
00007f8fe1fe1cad  mov eax, [r15+0x108]
00007f8fe1fe1cb4  sahf
00007f8fe1fe1cb5  jnz 0x00007F8FE1FE1CE7
00007f8fe1fe1cb7  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fe1cbf  jz 0x00007F8FE1FE1FE0
00007f8fe1fe1cc5  nop [rax+rax*1], ax
00007f8fe1fe1cce  nop [rax+rax*1], eax
00007f8fe1fe1cd6  mov eax, 0x410490
00007f8fe1fe1cdb  mov [r15+0x100], rax
00007f8fe1fe1ce2  jmp 0x00007F8FE1DFE110
00007f8fe1fe1ce7  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fe1cef  jz 0x00007F8FE1FE1E20
00007f8fe1fe1cf5  nop [rax+rax*1], ax
00007f8fe1fe1cfe  nop [rax+rax*1], eax
00007f8fe1fe1d06  mov eax, 0x410474
00007f8fe1fe1d0b  mov [r15+0x100], rax
00007f8fe1fe1d12  jmp 0x00007F8FE1DFE110
00007f8fe1fe1d17  int3
00007f8fe1fe1d18  call 0x00007F8FE1EE27E0
00007f8fe1fe1d1d  jmp 0x00007F8FE1FE1AC3
00007f8fe1fe1d22  call 0x00007F8FE1EE27E0
00007f8fe1fe1d27  jmp 0x00007F8FE1FE1AD6
00007f8fe1fe1d2c  call 0x00007F8FE1EE1570
00007f8fe1fe1d31  jmp 0x00007F8FE1FE1AE2
00007f8fe1fe1d36  call 0x00007F8FE1EE27E0
00007f8fe1fe1d3b  jmp 0x00007F8FE1FE1B1A
00007f8fe1fe1d40  call 0x00007F8FE1EE1570
00007f8fe1fe1d45  jmp 0x00007F8FE1FE1B26
00007f8fe1fe1d4a  call 0x00007F8FE1EE27E0
00007f8fe1fe1d4f  jmp 0x00007F8FE1FE1B5E
00007f8fe1fe1d54  call 0x00007F8FE1EE1570
00007f8fe1fe1d59  jmp 0x00007F8FE1FE1B6A
00007f8fe1fe1d5e  call 0x00007F8FE1EE27E0
00007f8fe1fe1d63  jmp 0x00007F8FE1FE1BA2
00007f8fe1fe1d68  call 0x00007F8FE1EE1570
00007f8fe1fe1d6d  jmp 0x00007F8FE1FE1BAE
00007f8fe1fe1d72  call 0x00007F8FE1EE27E0
00007f8fe1fe1d77  jmp 0x00007F8FE1FE1BED
00007f8fe1fe1d7c  call 0x00007F8FE1E0E760
00007f8fe1fe1d81  jmp 0x00007F8FE1FE1C0A
00007f8fe1fe1d86  ucomisd xmm1, xmm15
00007f8fe1fe1d8b  jp 0x00007F8FE1FE1D9A
00007f8fe1fe1d8d  movaps xmm13, [0x00007F8FE1BFE060]
00007f8fe1fe1d95  jmp 0x00007F8FE1FE1C73
00007f8fe1fe1d9a  vxorps xmm0, xmm1, xmm15
00007f8fe1fe1d9f  pextrw eax, xmm0, 0x03
00007f8fe1fe1da4  and eax, 0x7FF8
00007f8fe1fe1da9  cmp eax, 0x08
00007f8fe1fe1dac  jnz 0x00007F8FE1FE1C73
00007f8fe1fe1db2  movq rax, xmm15
00007f8fe1fe1db7  shl rax, 0x0D
00007f8fe1fe1dbb  jbe 0x00007F8FE1FE1C73
00007f8fe1fe1dc1  vorps xmm13, xmm15, [0x00007F8FE1BFE070]
00007f8fe1fe1dc9  jmp 0x00007F8FE1FE1C73
00007f8fe1fe1dce  ucomisd xmm1, xmm15
00007f8fe1fe1dd3  jp 0x00007F8FE1FE1DE2
00007f8fe1fe1dd5  movaps xmm14, [0x00007F8FE1BFE060]
00007f8fe1fe1ddd  jmp 0x00007F8FE1FE1CA0
00007f8fe1fe1de2  vxorps xmm0, xmm1, xmm15
00007f8fe1fe1de7  pextrw eax, xmm0, 0x03
00007f8fe1fe1dec  and eax, 0x7FF8
00007f8fe1fe1df1  cmp eax, 0x08
00007f8fe1fe1df4  jnz 0x00007F8FE1FE1CA0
00007f8fe1fe1dfa  movq rax, xmm15
00007f8fe1fe1dff  shl rax, 0x0D
00007f8fe1fe1e03  jbe 0x00007F8FE1FE1CA0
00007f8fe1fe1e09  vorps xmm14, xmm15, [0x00007F8FE1BFE070]
00007f8fe1fe1e11  jmp 0x00007F8FE1FE1CA0
00007f8fe1fe1e16  int3
00007f8fe1fe1e17  nop [rax+rax*1], ax
00007f8fe1fe1e20  mov rax, [r15+0x48]
00007f8fe1fe1e24  mov r14, [r15+0x50]
00007f8fe1fe1e28  lea r12, [r14+rax*1]
00007f8fe1fe1e2c  movups xmm1, [r13+r12*1]
00007f8fe1fe1e32  movaps [r15+0x120], xmm1
00007f8fe1fe1e3a  lea r14, [rax+0x10]
00007f8fe1fe1e3e  mov [r15+0x48], r14
00007f8fe1fe1e42  xor eax, eax
00007f8fe1fe1e44  mov r12d, 0x200
00007f8fe1fe1e4a  cmp r14, r12
00007f8fe1fe1e4d  cmc
00007f8fe1fe1e4e  lahf
00007f8fe1fe1e4f  seto al
00007f8fe1fe1e52  mov [r15+0x108], eax
00007f8fe1fe1e59  pextrq rax, xmm1, 0x01
00007f8fe1fe1e60  movq xmm15, rax
00007f8fe1fe1e65  movaps [r15+0x130], xmm15
00007f8fe1fe1e6d  movaps xmm14, [r15+0x110]
00007f8fe1fe1e75  movq rax, xmm14
00007f8fe1fe1e7a  movq r14, xmm1
00007f8fe1fe1e7f  vmovq xmm1, rax
00007f8fe1fe1e84  vmovq xmm14, r14
00007f8fe1fe1e89  movaps xmm13, xmm1
00007f8fe1fe1e8d  addsd xmm13, xmm14
00007f8fe1fe1e92  ucomisd xmm13, xmm13
00007f8fe1fe1e97  jp 0x00007F8FE1FE1F4C
00007f8fe1fe1e9d  movq xmm13, xmm13
00007f8fe1fe1ea2  movq rax, xmm13
00007f8fe1fe1ea7  movq r14, xmm15
00007f8fe1fe1eac  vmovq xmm1, rax
00007f8fe1fe1eb1  vmovq xmm15, r14
00007f8fe1fe1eb6  movaps xmm14, xmm1
00007f8fe1fe1eba  addsd xmm14, xmm15
00007f8fe1fe1ebf  ucomisd xmm14, xmm14
00007f8fe1fe1ec4  jp 0x00007F8FE1FE1F94
00007f8fe1fe1eca  movq xmm14, xmm14
00007f8fe1fe1ecf  movaps [r15+0x110], xmm14
00007f8fe1fe1ed7  mov eax, [r15+0x108]
00007f8fe1fe1ede  sahf
00007f8fe1fe1edf  jnz 0x00007F8FE1FE1F11
00007f8fe1fe1ee1  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fe1ee9  jz 0x00007F8FE1FE1FE0
00007f8fe1fe1eef  nop [rax+rax*1], ax
00007f8fe1fe1ef8  nop [rax+rax*1], eax
00007f8fe1fe1f00  mov eax, 0x410490
00007f8fe1fe1f05  mov [r15+0x100], rax
00007f8fe1fe1f0c  jmp 0x00007F8FE1DFE110
00007f8fe1fe1f11  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fe1f19  jz 0x00007F8FE1FE1E20
00007f8fe1fe1f1f  nop [rax+rax*1], ax
00007f8fe1fe1f28  nop [rax+rax*1], eax
00007f8fe1fe1f30  mov eax, 0x410474
00007f8fe1fe1f35  mov [r15+0x100], rax
00007f8fe1fe1f3c  jmp 0x00007F8FE1DFE110
00007f8fe1fe1f41  int3
00007f8fe1fe1f42  call 0x00007F8FE1EB52F0
00007f8fe1fe1f47  jmp 0x00007F8FE1FE1E32
00007f8fe1fe1f4c  ucomisd xmm1, xmm14
00007f8fe1fe1f51  jp 0x00007F8FE1FE1F60
00007f8fe1fe1f53  movaps xmm13, [0x00007F8FE1BFE060]
00007f8fe1fe1f5b  jmp 0x00007F8FE1FE1E9D
00007f8fe1fe1f60  vxorps xmm0, xmm1, xmm14
00007f8fe1fe1f65  pextrw eax, xmm0, 0x03
00007f8fe1fe1f6a  and eax, 0x7FF8
00007f8fe1fe1f6f  cmp eax, 0x08
00007f8fe1fe1f72  jnz 0x00007F8FE1FE1E9D
00007f8fe1fe1f78  movq rax, xmm14
00007f8fe1fe1f7d  shl rax, 0x0D
00007f8fe1fe1f81  jbe 0x00007F8FE1FE1E9D
00007f8fe1fe1f87  vorps xmm13, xmm14, [0x00007F8FE1BFE070]
00007f8fe1fe1f8f  jmp 0x00007F8FE1FE1E9D
00007f8fe1fe1f94  ucomisd xmm1, xmm15
00007f8fe1fe1f99  jp 0x00007F8FE1FE1FA8
00007f8fe1fe1f9b  movaps xmm14, [0x00007F8FE1BFE060]
00007f8fe1fe1fa3  jmp 0x00007F8FE1FE1ECA
00007f8fe1fe1fa8  vxorps xmm0, xmm1, xmm15
00007f8fe1fe1fad  pextrw eax, xmm0, 0x03
00007f8fe1fe1fb2  and eax, 0x7FF8
00007f8fe1fe1fb7  cmp eax, 0x08
00007f8fe1fe1fba  jnz 0x00007F8FE1FE1ECA
00007f8fe1fe1fc0  movq rax, xmm15
00007f8fe1fe1fc5  shl rax, 0x0D
00007f8fe1fe1fc9  jbe 0x00007F8FE1FE1ECA
00007f8fe1fe1fcf  vorps xmm14, xmm15, [0x00007F8FE1BFE070]
00007f8fe1fe1fd7  jmp 0x00007F8FE1FE1ECA
00007f8fe1fe1fdc  int3
00007f8fe1fe1fdd  nop [rax], eax
00007f8fe1fe1fe0  mov rax, [r15+0x40]
00007f8fe1fe1fe4  lea r14, [rax+0x510]
00007f8fe1fe1feb  movaps xmm1, [r15+0x110]
00007f8fe1fe1ff3  movq rax, xmm1
00007f8fe1fe1ff8  mov [r13+r14*1], rax
00007f8fe1fe1ffd  mov rax, [r15+0xF0]
00007f8fe1fe2004  mov [r15+0x100], rax
00007f8fe1fe200b  jmp 0x00007F8FE1FCE5C0
00007f8fe1fe2010  int3
00007f8fe1fe2011  call 0x00007F8FE1ED5EB0
00007f8fe1fe2016  jmp 0x00007F8FE1FE1FFD
00007f8fe1fe201b  int3
00007f8fe1fe201c  nop [rax], eax
00007f8fe1fe2020  mov qword ptr [r15+0x100], 0x04
00007f8fe1fe202b  mov esi, 0x00
00007f8fe1fe2030  mov edx, 0x09
00007f8fe1fe2035  mov rdi, 0x7FFD6B33CDF0
00007f8fe1fe203f  mov rax, 0x6020BB612970
00007f8fe1fe2049  call rax
00007f8fe1fe204b  cmp dword ptr [r15+0x318], 0x00
00007f8fe1fe2053  jnz 0x00007F8FE1DFE110
00007f8fe1fe2059  jmp 0x00007F8FE1DFE0A0
00007f8fe1fe205e  int3
00007f8fe1fe205f  int3
