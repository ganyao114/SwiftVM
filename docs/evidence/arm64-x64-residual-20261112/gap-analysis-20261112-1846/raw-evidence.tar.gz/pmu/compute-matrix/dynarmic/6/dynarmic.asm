00007e6bc8bce69b  nop [rax+rax*1], eax
00007e6bc8bce6a0  vmovaps xmm1, [0x00007E6BC87FE010]
00007e6bc8bce6a8  movq xmm1, xmm1
00007e6bc8bce6ac  movaps [r15+0x110], xmm1
00007e6bc8bce6b4  vmovaps xmm1, [0x00007E6BC87FE020]
00007e6bc8bce6bc  movq xmm1, xmm1
00007e6bc8bce6c0  movaps [r15+0x120], xmm1
00007e6bc8bce6c8  mov eax, 0x4204C0
00007e6bc8bce6cd  mov r14, [r13+rax*1]
00007e6bc8bce6d2  movq xmm1, r14
00007e6bc8bce6d7  movaps [r15+0x130], xmm1
00007e6bc8bce6df  vmovaps xmm1, [0x00007E6BC87FE030]
00007e6bc8bce6e7  vpbroadcastq xmm1, xmm1
00007e6bc8bce6ec  movaps [r15+0x140], xmm1
00007e6bc8bce6f4  mov qword ptr [r15+0x40], 0x02
00007e6bc8bce6fc  vmovaps xmm15, [0x00007E6BC87FE040]
00007e6bc8bce704  movq xmm15, xmm15
00007e6bc8bce709  movaps [r15+0x150], xmm15
00007e6bc8bce711  mov qword ptr [r15+0x58], 0x420000
00007e6bc8bce719  vmovaps xmm15, [0x00007E6BC87FE050]
00007e6bc8bce721  vpbroadcastq xmm15, xmm15
00007e6bc8bce726  movaps [r15+0x160], xmm15
00007e6bc8bce72e  mov rax, [r15+0x40]
00007e6bc8bce732  vmovq xmm14, rax
00007e6bc8bce737  vpbroadcastq xmm14, xmm14
00007e6bc8bce73c  movaps [r15+0x170], xmm14
00007e6bc8bce744  mov eax, 0x4204D0
00007e6bc8bce749  movups xmm13, [r13+rax*1]
00007e6bc8bce74f  mov qword ptr [r15+0x40], 0x430518
00007e6bc8bce757  mov qword ptr [r15+0x50], 0x430720
00007e6bc8bce75f  vpmovqd xmm12, xmm13
00007e6bc8bce765  pxor xmm11, xmm11
00007e6bc8bce76a  punpcklqdq xmm12, xmm11
00007e6bc8bce76f  movaps [r15+0x210], xmm12
00007e6bc8bce777  movq xmm12, qword ptr [r15+0x120]
00007e6bc8bce780  movq xmm11, qword ptr [r15+0x130]
00007e6bc8bce789  psubd xmm12, xmm11
00007e6bc8bce78e  movq xmm12, xmm12
00007e6bc8bce793  paddq xmm13, xmm14
00007e6bc8bce798  movaps [r15+0x180], xmm13
00007e6bc8bce7a0  movq xmm14, qword ptr [r15+0x150]
00007e6bc8bce7a9  paddd xmm11, xmm14
00007e6bc8bce7ae  movq xmm11, xmm11
00007e6bc8bce7b3  movq xmm11, xmm11
00007e6bc8bce7b8  movaps [r15+0x130], xmm11
00007e6bc8bce7c0  pmovzxdq xmm12, xmm12
00007e6bc8bce7c6  psllq xmm12, 0x00
00007e6bc8bce7cc  movq xmm14, qword ptr [r15+0x210]
00007e6bc8bce7d5  movq xmm13, qword ptr [r15+0x110]
00007e6bc8bce7de  paddd xmm14, xmm13
00007e6bc8bce7e3  movq xmm14, xmm14
00007e6bc8bce7e8  vcvtuqq2pd xmm12, xmm12
00007e6bc8bce7ee  pmovzxdq xmm14, xmm14
00007e6bc8bce7f4  psllq xmm14, 0x00
00007e6bc8bce7fa  vcvtuqq2pd xmm14, xmm14
00007e6bc8bce800  movaps xmm13, xmm12
00007e6bc8bce804  mulpd xmm13, xmm1
00007e6bc8bce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007e6bc8bce80f  ptest xmm11, xmm11
00007e6bc8bce815  jnz 0x00007E6BC8BCE8FF
00007e6bc8bce81b  movaps [r15+0x220], xmm13
00007e6bc8bce823  mov eax, 0x430720
00007e6bc8bce828  movups [r13+rax*1], xmm13
00007e6bc8bce82e  movaps xmm1, xmm14
00007e6bc8bce832  mulpd xmm1, xmm15
00007e6bc8bce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007e6bc8bce83c  ptest xmm13, xmm13
00007e6bc8bce842  jnz 0x00007E6BC8BCEA4C
00007e6bc8bce848  movaps [r15+0x210], xmm1
00007e6bc8bce850  mov eax, 0x430518
00007e6bc8bce855  movups [r13+rax*1], xmm1
00007e6bc8bce85b  mov qword ptr [r15+0x48], 0x10
00007e6bc8bce863  xor eax, eax
00007e6bc8bce865  mov r14d, 0x10
00007e6bc8bce86b  mov r12d, 0x200
00007e6bc8bce871  cmp r14, r12
00007e6bc8bce874  cmc
00007e6bc8bce875  lahf
00007e6bc8bce876  seto al
00007e6bc8bce879  mov [r15+0x108], eax
00007e6bc8bce880  mov eax, [r15+0x108]
00007e6bc8bce887  sahf
00007e6bc8bce888  jnz 0x00007E6BC8BCE8BA
00007e6bc8bce88a  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bce892  jz 0x00007E6BC8BCEFF0
00007e6bc8bce898  nop [rax+rax*1], ax
00007e6bc8bce8a1  nop [rax+rax*1], eax
00007e6bc8bce8a9  mov eax, 0x4101EC
00007e6bc8bce8ae  mov [r15+0x100], rax
00007e6bc8bce8b5  jmp 0x00007E6BC89FE110
00007e6bc8bce8ba  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bce8c2  jz 0x00007E6BC8BCEBA0
00007e6bc8bce8c8  nop [rax+rax*1], ax
00007e6bc8bce8d1  nop [rax+rax*1], eax
00007e6bc8bce8d9  mov eax, 0x4101AC
00007e6bc8bce8de  mov [r15+0x100], rax
00007e6bc8bce8e5  jmp 0x00007E6BC89FE110
00007e6bc8bce8ea  int3
00007e6bc8bce8eb  call 0x00007E6BC8A0DC20
00007e6bc8bce8f0  jmp 0x00007E6BC8BCE6D2
00007e6bc8bce8f5  call 0x00007E6BC8A0C260
00007e6bc8bce8fa  jmp 0x00007E6BC8BCE74F
00007e6bc8bce8ff  sub rsp, 0x08
00007e6bc8bce903  push rax
00007e6bc8bce904  push rcx
00007e6bc8bce905  push rdx
00007e6bc8bce906  push rdi
00007e6bc8bce907  push rsi
00007e6bc8bce908  push r8
00007e6bc8bce90a  push r9
00007e6bc8bce90c  push r10
00007e6bc8bce90e  push r11
00007e6bc8bce910  sub rsp, 0xF0
00007e6bc8bce917  vmovaps [rsp], xmm0
00007e6bc8bce91c  vmovaps [rsp+0x10], xmm1
00007e6bc8bce922  vmovaps [rsp+0x20], xmm2
00007e6bc8bce928  vmovaps [rsp+0x30], xmm3
00007e6bc8bce92e  vmovaps [rsp+0x40], xmm4
00007e6bc8bce934  vmovaps [rsp+0x50], xmm5
00007e6bc8bce93a  vmovaps [rsp+0x60], xmm6
00007e6bc8bce940  vmovaps [rsp+0x70], xmm7
00007e6bc8bce946  vmovaps [rsp+0x80], xmm8
00007e6bc8bce94f  vmovaps [rsp+0x90], xmm9
00007e6bc8bce958  vmovaps [rsp+0xA0], xmm10
00007e6bc8bce961  vmovaps [rsp+0xB0], xmm11
00007e6bc8bce96a  vmovaps [rsp+0xC0], xmm12
00007e6bc8bce973  vmovaps [rsp+0xD0], xmm14
00007e6bc8bce97c  vmovaps [rsp+0xE0], xmm15
00007e6bc8bce985  sub rsp, 0x30
00007e6bc8bce989  movaps [rsp], xmm13
00007e6bc8bce98e  movaps [rsp+0x10], xmm12
00007e6bc8bce994  movaps [rsp+0x20], xmm1
00007e6bc8bce999  lea rdi, [rsp]
00007e6bc8bce99d  mov esi, 0x00
00007e6bc8bce9a2  mov rax, 0x6543F191D530
00007e6bc8bce9ac  call rax
00007e6bc8bce9ae  movaps xmm13, [rsp]
00007e6bc8bce9b3  add rsp, 0x30
00007e6bc8bce9b7  vmovaps xmm0, [rsp]
00007e6bc8bce9bc  vmovaps xmm1, [rsp+0x10]
00007e6bc8bce9c2  vmovaps xmm2, [rsp+0x20]
00007e6bc8bce9c8  vmovaps xmm3, [rsp+0x30]
00007e6bc8bce9ce  vmovaps xmm4, [rsp+0x40]
00007e6bc8bce9d4  vmovaps xmm5, [rsp+0x50]
00007e6bc8bce9da  vmovaps xmm6, [rsp+0x60]
00007e6bc8bce9e0  vmovaps xmm7, [rsp+0x70]
00007e6bc8bce9e6  vmovaps xmm8, [rsp+0x80]
00007e6bc8bce9ef  vmovaps xmm9, [rsp+0x90]
00007e6bc8bce9f8  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bcea01  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bcea0a  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bcea13  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bcea1c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bcea25  add rsp, 0xF0
00007e6bc8bcea2c  pop r11
00007e6bc8bcea2e  pop r10
00007e6bc8bcea30  pop r9
00007e6bc8bcea32  pop r8
00007e6bc8bcea34  pop rsi
00007e6bc8bcea35  pop rdi
00007e6bc8bcea36  pop rdx
00007e6bc8bcea37  pop rcx
00007e6bc8bcea38  pop rax
00007e6bc8bcea39  add rsp, 0x08
00007e6bc8bcea3d  jmp 0x00007E6BC8BCE81B
00007e6bc8bcea42  call 0x00007E6BC8A0C380
00007e6bc8bcea47  jmp 0x00007E6BC8BCE82E
00007e6bc8bcea4c  sub rsp, 0x08
00007e6bc8bcea50  push rax
00007e6bc8bcea51  push rcx
00007e6bc8bcea52  push rdx
00007e6bc8bcea53  push rdi
00007e6bc8bcea54  push rsi
00007e6bc8bcea55  push r8
00007e6bc8bcea57  push r9
00007e6bc8bcea59  push r10
00007e6bc8bcea5b  push r11
00007e6bc8bcea5d  sub rsp, 0xF0
00007e6bc8bcea64  vmovaps [rsp], xmm0
00007e6bc8bcea69  vmovaps [rsp+0x10], xmm2
00007e6bc8bcea6f  vmovaps [rsp+0x20], xmm3
00007e6bc8bcea75  vmovaps [rsp+0x30], xmm4
00007e6bc8bcea7b  vmovaps [rsp+0x40], xmm5
00007e6bc8bcea81  vmovaps [rsp+0x50], xmm6
00007e6bc8bcea87  vmovaps [rsp+0x60], xmm7
00007e6bc8bcea8d  vmovaps [rsp+0x70], xmm8
00007e6bc8bcea93  vmovaps [rsp+0x80], xmm9
00007e6bc8bcea9c  vmovaps [rsp+0x90], xmm10
00007e6bc8bceaa5  vmovaps [rsp+0xA0], xmm11
00007e6bc8bceaae  vmovaps [rsp+0xB0], xmm12
00007e6bc8bceab7  vmovaps [rsp+0xC0], xmm13
00007e6bc8bceac0  vmovaps [rsp+0xD0], xmm14
00007e6bc8bceac9  vmovaps [rsp+0xE0], xmm15
00007e6bc8bcead2  sub rsp, 0x30
00007e6bc8bcead6  movaps [rsp], xmm1
00007e6bc8bceada  movaps [rsp+0x10], xmm14
00007e6bc8bceae0  movaps [rsp+0x20], xmm15
00007e6bc8bceae6  lea rdi, [rsp]
00007e6bc8bceaea  mov esi, 0x00
00007e6bc8bceaef  mov rax, 0x6543F191D530
00007e6bc8bceaf9  call rax
00007e6bc8bceafb  movaps xmm1, [rsp]
00007e6bc8bceaff  add rsp, 0x30
00007e6bc8bceb03  vmovaps xmm0, [rsp]
00007e6bc8bceb08  vmovaps xmm2, [rsp+0x10]
00007e6bc8bceb0e  vmovaps xmm3, [rsp+0x20]
00007e6bc8bceb14  vmovaps xmm4, [rsp+0x30]
00007e6bc8bceb1a  vmovaps xmm5, [rsp+0x40]
00007e6bc8bceb20  vmovaps xmm6, [rsp+0x50]
00007e6bc8bceb26  vmovaps xmm7, [rsp+0x60]
00007e6bc8bceb2c  vmovaps xmm8, [rsp+0x70]
00007e6bc8bceb32  vmovaps xmm9, [rsp+0x80]
00007e6bc8bceb3b  vmovaps xmm10, [rsp+0x90]
00007e6bc8bceb44  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bceb4d  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bceb56  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bceb5f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bceb68  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bceb71  add rsp, 0xF0
00007e6bc8bceb78  pop r11
00007e6bc8bceb7a  pop r10
00007e6bc8bceb7c  pop r9
00007e6bc8bceb7e  pop r8
00007e6bc8bceb80  pop rsi
00007e6bc8bceb81  pop rdi
00007e6bc8bceb82  pop rdx
00007e6bc8bceb83  pop rcx
00007e6bc8bceb84  pop rax
00007e6bc8bceb85  add rsp, 0x08
00007e6bc8bceb89  jmp 0x00007E6BC8BCE848
00007e6bc8bceb8e  call 0x00007E6BC89FF540
00007e6bc8bceb93  jmp 0x00007E6BC8BCE85B
00007e6bc8bceb98  int3
00007e6bc8bceb99  nop [rax], eax
00007e6bc8bceba0  movaps xmm1, [r15+0x180]
00007e6bc8bceba8  vpmovqd xmm15, xmm1
00007e6bc8bcebae  pxor xmm14, xmm14
00007e6bc8bcebb3  punpcklqdq xmm15, xmm14
00007e6bc8bcebb8  movaps [r15+0x210], xmm15
00007e6bc8bcebc0  movq xmm15, qword ptr [r15+0x120]
00007e6bc8bcebc9  movq xmm14, qword ptr [r15+0x130]
00007e6bc8bcebd2  psubd xmm15, xmm14
00007e6bc8bcebd7  movq xmm15, xmm15
00007e6bc8bcebdc  movaps xmm13, [r15+0x170]
00007e6bc8bcebe4  paddq xmm1, xmm13
00007e6bc8bcebe9  movaps [r15+0x180], xmm1
00007e6bc8bcebf1  movq xmm1, qword ptr [r15+0x150]
00007e6bc8bcebfa  paddd xmm14, xmm1
00007e6bc8bcebff  movq xmm14, xmm14
00007e6bc8bcec04  movq xmm14, xmm14
00007e6bc8bcec09  movaps [r15+0x130], xmm14
00007e6bc8bcec11  pmovzxdq xmm15, xmm15
00007e6bc8bcec17  psllq xmm15, 0x00
00007e6bc8bcec1d  movq xmm1, qword ptr [r15+0x210]
00007e6bc8bcec26  movq xmm14, qword ptr [r15+0x110]
00007e6bc8bcec2f  paddd xmm1, xmm14
00007e6bc8bcec34  movq xmm1, xmm1
00007e6bc8bcec38  vcvtuqq2pd xmm15, xmm15
00007e6bc8bcec3e  pmovzxdq xmm1, xmm1
00007e6bc8bcec43  psllq xmm1, 0x00
00007e6bc8bcec48  vcvtuqq2pd xmm1, xmm1
00007e6bc8bcec4e  movaps xmm14, [r15+0x140]
00007e6bc8bcec56  movaps xmm13, xmm15
00007e6bc8bcec5a  mulpd xmm13, xmm14
00007e6bc8bcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007e6bc8bcec65  ptest xmm12, xmm12
00007e6bc8bcec6b  jnz 0x00007E6BC8BCED4E
00007e6bc8bcec71  movaps [r15+0x220], xmm13
00007e6bc8bcec79  mov rax, [r15+0x48]
00007e6bc8bcec7d  mov r14, [r15+0x50]
00007e6bc8bcec81  lea r12, [r14+rax*1]
00007e6bc8bcec85  movups [r13+r12*1], xmm13
00007e6bc8bcec8b  movaps xmm15, [r15+0x160]
00007e6bc8bcec93  movaps xmm14, xmm1
00007e6bc8bcec97  mulpd xmm14, xmm15
00007e6bc8bcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007e6bc8bceca2  ptest xmm13, xmm13
00007e6bc8bceca8  jnz 0x00007E6BC8BCEE9C
00007e6bc8bcecae  movaps [r15+0x210], xmm14
00007e6bc8bcecb6  mov r14, [r15+0x40]
00007e6bc8bcecba  lea r12, [r14+rax*1]
00007e6bc8bcecbe  movups [r13+r12*1], xmm14
00007e6bc8bcecc4  lea r14, [rax+0x10]
00007e6bc8bcecc8  mov [r15+0x48], r14
00007e6bc8bceccc  xor eax, eax
00007e6bc8bcecce  mov r12d, 0x200
00007e6bc8bcecd4  cmp r14, r12
00007e6bc8bcecd7  cmc
00007e6bc8bcecd8  lahf
00007e6bc8bcecd9  seto al
00007e6bc8bcecdc  mov [r15+0x108], eax
00007e6bc8bcece3  mov eax, [r15+0x108]
00007e6bc8bcecea  sahf
00007e6bc8bceceb  jnz 0x00007E6BC8BCED1D
00007e6bc8bceced  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bcecf5  jz 0x00007E6BC8BCEFF0
00007e6bc8bcecfb  nop [rax+rax*1], ax
00007e6bc8bced04  nop [rax+rax*1], eax
00007e6bc8bced0c  mov eax, 0x4101EC
00007e6bc8bced11  mov [r15+0x100], rax
00007e6bc8bced18  jmp 0x00007E6BC89FE110
00007e6bc8bced1d  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bced25  jz 0x00007E6BC8BCEBA0
00007e6bc8bced2b  nop [rax+rax*1], ax
00007e6bc8bced34  nop [rax+rax*1], eax
00007e6bc8bced3c  mov eax, 0x4101AC
00007e6bc8bced41  mov [r15+0x100], rax
00007e6bc8bced48  jmp 0x00007E6BC89FE110
00007e6bc8bced4d  int3
00007e6bc8bced4e  sub rsp, 0x08
00007e6bc8bced52  push rax
00007e6bc8bced53  push rcx
00007e6bc8bced54  push rdx
00007e6bc8bced55  push rdi
00007e6bc8bced56  push rsi
00007e6bc8bced57  push r8
00007e6bc8bced59  push r9
00007e6bc8bced5b  push r10
00007e6bc8bced5d  push r11
00007e6bc8bced5f  sub rsp, 0xF0
00007e6bc8bced66  vmovaps [rsp], xmm0
00007e6bc8bced6b  vmovaps [rsp+0x10], xmm1
00007e6bc8bced71  vmovaps [rsp+0x20], xmm2
00007e6bc8bced77  vmovaps [rsp+0x30], xmm3
00007e6bc8bced7d  vmovaps [rsp+0x40], xmm4
00007e6bc8bced83  vmovaps [rsp+0x50], xmm5
00007e6bc8bced89  vmovaps [rsp+0x60], xmm6
00007e6bc8bced8f  vmovaps [rsp+0x70], xmm7
00007e6bc8bced95  vmovaps [rsp+0x80], xmm8
00007e6bc8bced9e  vmovaps [rsp+0x90], xmm9
00007e6bc8bceda7  vmovaps [rsp+0xA0], xmm10
00007e6bc8bcedb0  vmovaps [rsp+0xB0], xmm11
00007e6bc8bcedb9  vmovaps [rsp+0xC0], xmm12
00007e6bc8bcedc2  vmovaps [rsp+0xD0], xmm14
00007e6bc8bcedcb  vmovaps [rsp+0xE0], xmm15
00007e6bc8bcedd4  sub rsp, 0x30
00007e6bc8bcedd8  movaps [rsp], xmm13
00007e6bc8bceddd  movaps [rsp+0x10], xmm15
00007e6bc8bcede3  movaps [rsp+0x20], xmm14
00007e6bc8bcede9  lea rdi, [rsp]
00007e6bc8bceded  mov esi, 0x00
00007e6bc8bcedf2  mov rax, 0x6543F191D530
00007e6bc8bcedfc  call rax
00007e6bc8bcedfe  movaps xmm13, [rsp]
00007e6bc8bcee03  add rsp, 0x30
00007e6bc8bcee07  vmovaps xmm0, [rsp]
00007e6bc8bcee0c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bcee12  vmovaps xmm2, [rsp+0x20]
00007e6bc8bcee18  vmovaps xmm3, [rsp+0x30]
00007e6bc8bcee1e  vmovaps xmm4, [rsp+0x40]
00007e6bc8bcee24  vmovaps xmm5, [rsp+0x50]
00007e6bc8bcee2a  vmovaps xmm6, [rsp+0x60]
00007e6bc8bcee30  vmovaps xmm7, [rsp+0x70]
00007e6bc8bcee36  vmovaps xmm8, [rsp+0x80]
00007e6bc8bcee3f  vmovaps xmm9, [rsp+0x90]
00007e6bc8bcee48  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bcee51  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bcee5a  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bcee63  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bcee6c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bcee75  add rsp, 0xF0
00007e6bc8bcee7c  pop r11
00007e6bc8bcee7e  pop r10
00007e6bc8bcee80  pop r9
00007e6bc8bcee82  pop r8
00007e6bc8bcee84  pop rsi
00007e6bc8bcee85  pop rdi
00007e6bc8bcee86  pop rdx
00007e6bc8bcee87  pop rcx
00007e6bc8bcee88  pop rax
00007e6bc8bcee89  add rsp, 0x08
00007e6bc8bcee8d  jmp 0x00007E6BC8BCEC71
00007e6bc8bcee92  call 0x00007E6BC8AC2240
00007e6bc8bcee97  jmp 0x00007E6BC8BCEC8B
00007e6bc8bcee9c  sub rsp, 0x08
00007e6bc8bceea0  push rax
00007e6bc8bceea1  push rcx
00007e6bc8bceea2  push rdx
00007e6bc8bceea3  push rdi
00007e6bc8bceea4  push rsi
00007e6bc8bceea5  push r8
00007e6bc8bceea7  push r9
00007e6bc8bceea9  push r10
00007e6bc8bceeab  push r11
00007e6bc8bceead  sub rsp, 0xF0
00007e6bc8bceeb4  vmovaps [rsp], xmm0
00007e6bc8bceeb9  vmovaps [rsp+0x10], xmm1
00007e6bc8bceebf  vmovaps [rsp+0x20], xmm2
00007e6bc8bceec5  vmovaps [rsp+0x30], xmm3
00007e6bc8bceecb  vmovaps [rsp+0x40], xmm4
00007e6bc8bceed1  vmovaps [rsp+0x50], xmm5
00007e6bc8bceed7  vmovaps [rsp+0x60], xmm6
00007e6bc8bceedd  vmovaps [rsp+0x70], xmm7
00007e6bc8bceee3  vmovaps [rsp+0x80], xmm8
00007e6bc8bceeec  vmovaps [rsp+0x90], xmm9
00007e6bc8bceef5  vmovaps [rsp+0xA0], xmm10
00007e6bc8bceefe  vmovaps [rsp+0xB0], xmm11
00007e6bc8bcef07  vmovaps [rsp+0xC0], xmm12
00007e6bc8bcef10  vmovaps [rsp+0xD0], xmm13
00007e6bc8bcef19  vmovaps [rsp+0xE0], xmm15
00007e6bc8bcef22  sub rsp, 0x30
00007e6bc8bcef26  movaps [rsp], xmm14
00007e6bc8bcef2b  movaps [rsp+0x10], xmm1
00007e6bc8bcef30  movaps [rsp+0x20], xmm15
00007e6bc8bcef36  lea rdi, [rsp]
00007e6bc8bcef3a  mov esi, 0x00
00007e6bc8bcef3f  mov rax, 0x6543F191D530
00007e6bc8bcef49  call rax
00007e6bc8bcef4b  movaps xmm14, [rsp]
00007e6bc8bcef50  add rsp, 0x30
00007e6bc8bcef54  vmovaps xmm0, [rsp]
00007e6bc8bcef59  vmovaps xmm1, [rsp+0x10]
00007e6bc8bcef5f  vmovaps xmm2, [rsp+0x20]
00007e6bc8bcef65  vmovaps xmm3, [rsp+0x30]
00007e6bc8bcef6b  vmovaps xmm4, [rsp+0x40]
00007e6bc8bcef71  vmovaps xmm5, [rsp+0x50]
00007e6bc8bcef77  vmovaps xmm6, [rsp+0x60]
00007e6bc8bcef7d  vmovaps xmm7, [rsp+0x70]
00007e6bc8bcef83  vmovaps xmm8, [rsp+0x80]
00007e6bc8bcef8c  vmovaps xmm9, [rsp+0x90]
00007e6bc8bcef95  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bcef9e  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bcefa7  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bcefb0  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bcefb9  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bcefc2  add rsp, 0xF0
00007e6bc8bcefc9  pop r11
00007e6bc8bcefcb  pop r10
00007e6bc8bcefcd  pop r9
00007e6bc8bcefcf  pop r8
00007e6bc8bcefd1  pop rsi
00007e6bc8bcefd2  pop rdi
00007e6bc8bcefd3  pop rdx
00007e6bc8bcefd4  pop rcx
00007e6bc8bcefd5  pop rax
00007e6bc8bcefd6  add rsp, 0x08
00007e6bc8bcefda  jmp 0x00007E6BC8BCECAE
00007e6bc8bcefdf  call 0x00007E6BC8AC34C0
00007e6bc8bcefe4  jmp 0x00007E6BC8BCECC4
00007e6bc8bcefe9  int3
00007e6bc8bcefea  nop [rax+rax*1], ax
00007e6bc8bceff0  mov rax, [r15+0xF8]
00007e6bc8bceff7  lea r14, [rax-0x150]
00007e6bc8bceffe  mov [r15+0xF8], r14
00007e6bc8bcf005  mov rax, [r15+0x50]
00007e6bc8bcf009  lea r12, [rax+0x80]
00007e6bc8bcf010  movups xmm1, [r13+r12*1]
00007e6bc8bcf016  lea r12, [rax+0x90]
00007e6bc8bcf01d  movups xmm15, [r13+r12*1]
00007e6bc8bcf023  mov qword ptr [r15+0x48], 0x00
00007e6bc8bcf02b  lea r12, [rax+0x40]
00007e6bc8bcf02f  movups xmm14, [r13+r12*1]
00007e6bc8bcf035  lea r12, [rax+0x50]
00007e6bc8bcf039  movups xmm13, [r13+r12*1]
00007e6bc8bcf03f  lea r12, [r14+0x120]
00007e6bc8bcf046  movq xmm12, qword ptr [r15+0x1C0]
00007e6bc8bcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007e6bc8bcf058  movq r11, xmm12
00007e6bc8bcf05d  movq r10, xmm11
00007e6bc8bcf062  mov [r13+r12*1], r11
00007e6bc8bcf067  lea r12, [r14+0x128]
00007e6bc8bcf06e  mov [r13+r12*1], r10
00007e6bc8bcf073  vxorps xmm12, xmm12, xmm12
00007e6bc8bcf078  vpbroadcastq xmm12, xmm12
00007e6bc8bcf07d  lea r12, [r14+0x100]
00007e6bc8bcf084  movq xmm11, qword ptr [r15+0x200]
00007e6bc8bcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007e6bc8bcf096  movq r11, xmm11
00007e6bc8bcf09b  movq r10, xmm10
00007e6bc8bcf0a0  mov [r13+r12*1], r11
00007e6bc8bcf0a5  lea r12, [r14+0x108]
00007e6bc8bcf0ac  mov [r13+r12*1], r10
00007e6bc8bcf0b1  lea r12, [r14+0xE0]
00007e6bc8bcf0b8  movups [r13+r12*1], xmm15
00007e6bc8bcf0be  lea r12, [r14+0xF0]
00007e6bc8bcf0c5  movups [r13+r12*1], xmm1
00007e6bc8bcf0cb  lea r12, [rax+0xC0]
00007e6bc8bcf0d2  movups xmm1, [r13+r12*1]
00007e6bc8bcf0d8  lea r12, [rax+0xD0]
00007e6bc8bcf0df  movups xmm15, [r13+r12*1]
00007e6bc8bcf0e5  lea r12, [r14+0x110]
00007e6bc8bcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007e6bc8bcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007e6bc8bcf0fe  movq r11, xmm11
00007e6bc8bcf103  movq r10, xmm10
00007e6bc8bcf108  mov [r13+r12*1], r11
00007e6bc8bcf10d  lea r12, [r14+0x118]
00007e6bc8bcf114  mov [r13+r12*1], r10
00007e6bc8bcf119  movups xmm11, [r13+rax*1]
00007e6bc8bcf11f  lea r12, [rax+0x10]
00007e6bc8bcf123  movups xmm10, [r13+r12*1]
00007e6bc8bcf129  lea r12, [r14+0x130]
00007e6bc8bcf130  movq xmm9, qword ptr [r15+0x1A0]
00007e6bc8bcf139  movq xmm8, qword ptr [r15+0x190]
00007e6bc8bcf142  movq r11, xmm9
00007e6bc8bcf147  movq r10, xmm8
00007e6bc8bcf14c  mov [r13+r12*1], r11
00007e6bc8bcf151  lea r12, [r14+0x138]
00007e6bc8bcf158  mov [r13+r12*1], r10
00007e6bc8bcf15d  lea r12, [rax+0x140]
00007e6bc8bcf164  movups xmm9, [r13+r12*1]
00007e6bc8bcf16a  lea r12, [rax+0x150]
00007e6bc8bcf171  movups xmm8, [r13+r12*1]
00007e6bc8bcf177  lea r12, [r14+0xC0]
00007e6bc8bcf17e  movups [r13+r12*1], xmm15
00007e6bc8bcf184  lea r12, [r14+0xD0]
00007e6bc8bcf18b  movups [r13+r12*1], xmm1
00007e6bc8bcf191  lea r12, [rax+0x100]
00007e6bc8bcf198  movups xmm1, [r13+r12*1]
00007e6bc8bcf19e  lea r12, [rax+0x110]
00007e6bc8bcf1a5  movups xmm15, [r13+r12*1]
00007e6bc8bcf1ab  lea r12, [r14+0x140]
00007e6bc8bcf1b2  mov r11, [r15+0xE8]
00007e6bc8bcf1b9  mov [r13+r12*1], r11
00007e6bc8bcf1be  lea r12, [rax+0x180]
00007e6bc8bcf1c5  movups xmm7, [r13+r12*1]
00007e6bc8bcf1cb  lea r12, [rax+0x190]
00007e6bc8bcf1d2  movups xmm6, [r13+r12*1]
00007e6bc8bcf1d8  lea r12, [rax+0x1C0]
00007e6bc8bcf1df  movups xmm5, [r13+r12*1]
00007e6bc8bcf1e5  lea r12, [rax+0x1D0]
00007e6bc8bcf1ec  movups xmm4, [r13+r12*1]
00007e6bc8bcf1f2  lea r12, [r14+0x20]
00007e6bc8bcf1f6  movups [r13+r12*1], xmm1
00007e6bc8bcf1fc  lea r12, [r14+0x30]
00007e6bc8bcf200  movups [r13+r12*1], xmm13
00007e6bc8bcf206  lea r12, [rax+0x60]
00007e6bc8bcf20a  movups xmm1, [r13+r12*1]
00007e6bc8bcf210  lea r12, [rax+0x70]
00007e6bc8bcf214  movups xmm13, [r13+r12*1]
00007e6bc8bcf21a  lea r12, [rax+0x20]
00007e6bc8bcf21e  movups xmm3, [r13+r12*1]
00007e6bc8bcf224  lea r12, [rax+0x30]
00007e6bc8bcf228  movups xmm2, [r13+r12*1]
00007e6bc8bcf22e  movaps [r15+0x1F0], xmm2
00007e6bc8bcf236  lea r12, [r14+0x60]
00007e6bc8bcf23a  movups [r13+r12*1], xmm11
00007e6bc8bcf240  lea r12, [r14+0x70]
00007e6bc8bcf244  movups [r13+r12*1], xmm5
00007e6bc8bcf24a  lea r12, [rax+0xE0]
00007e6bc8bcf251  movups xmm11, [r13+r12*1]
00007e6bc8bcf257  lea r12, [rax+0xF0]
00007e6bc8bcf25e  movups xmm5, [r13+r12*1]
00007e6bc8bcf264  lea r12, [r14+0xA0]
00007e6bc8bcf26b  movups [r13+r12*1], xmm13
00007e6bc8bcf271  lea r12, [r14+0xB0]
00007e6bc8bcf278  movups [r13+r12*1], xmm1
00007e6bc8bcf27e  lea r12, [rax+0xA0]
00007e6bc8bcf285  movups xmm1, [r13+r12*1]
00007e6bc8bcf28b  lea r12, [rax+0xB0]
00007e6bc8bcf292  movups xmm13, [r13+r12*1]
00007e6bc8bcf298  lea r12, [rax+0x120]
00007e6bc8bcf29f  vmovaps [rsp+0x10], xmm1
00007e6bc8bcf2a5  movups xmm1, [r13+r12*1]
00007e6bc8bcf2ab  lea r12, [rax+0x130]
00007e6bc8bcf2b2  vmovaps [rsp+0x20], xmm1
00007e6bc8bcf2b8  movups xmm1, [r13+r12*1]
00007e6bc8bcf2be  lea r12, [rax+0x160]
00007e6bc8bcf2c5  vmovaps [rsp+0x30], xmm1
00007e6bc8bcf2cb  movups xmm1, [r13+r12*1]
00007e6bc8bcf2d1  lea r12, [rax+0x170]
00007e6bc8bcf2d8  vmovaps [rsp+0x40], xmm1
00007e6bc8bcf2de  movups xmm1, [r13+r12*1]
00007e6bc8bcf2e4  movaps [r15+0x2B0], xmm1
00007e6bc8bcf2ec  lea r12, [r14+0x80]
00007e6bc8bcf2f3  movups [r13+r12*1], xmm13
00007e6bc8bcf2f9  lea r12, [r14+0x90]
00007e6bc8bcf300  vmovaps xmm13, [rsp+0x10]
00007e6bc8bcf306  movups [r13+r12*1], xmm13
00007e6bc8bcf30c  lea r12, [rax+0x1A0]
00007e6bc8bcf313  movups xmm13, [r13+r12*1]
00007e6bc8bcf319  lea r12, [rax+0x1B0]
00007e6bc8bcf320  vmovaps [rsp+0x10], xmm1
00007e6bc8bcf326  movups xmm1, [r13+r12*1]
00007e6bc8bcf32c  movaps [r15+0x290], xmm13
00007e6bc8bcf334  movaps [r15+0x1E0], xmm1
00007e6bc8bcf33c  lea r12, [rax+0x1E0]
00007e6bc8bcf343  vmovaps [rsp+0x50], xmm1
00007e6bc8bcf349  movups xmm1, [r13+r12*1]
00007e6bc8bcf34f  lea r12, [rax+0x1F0]
00007e6bc8bcf356  vmovaps [rsp+0x60], xmm1
00007e6bc8bcf35c  movups xmm1, [r13+r12*1]
00007e6bc8bcf362  mov qword ptr [r15+0x50], 0x430920
00007e6bc8bcf36a  lea rax, [r14+0x40]
00007e6bc8bcf36e  vmovaps [rsp+0x70], xmm1
00007e6bc8bcf374  vmovaps xmm1, [rsp+0x40]
00007e6bc8bcf37a  movups [r13+rax*1], xmm1
00007e6bc8bcf380  lea rax, [r14+0x50]
00007e6bc8bcf384  movups [r13+rax*1], xmm10
00007e6bc8bcf38a  vmovaps xmm1, [rsp+0x70]
00007e6bc8bcf390  movups [r13+r14*1], xmm1
00007e6bc8bcf396  lea rax, [r14+0x10]
00007e6bc8bcf39a  vmovaps xmm1, [rsp+0x60]
00007e6bc8bcf3a0  movups [r13+rax*1], xmm1
00007e6bc8bcf3a6  mov rax, [r15+0x40]
00007e6bc8bcf3aa  vmovaps [rsp+0x40], xmm3
00007e6bc8bcf3b0  vmovaps xmm1, [rsp+0x40]
00007e6bc8bcf3b6  por xmm3, xmm1
00007e6bc8bcf3ba  vmovaps [rsp+0x40], xmm6
00007e6bc8bcf3c0  vmovaps xmm10, [rsp+0x40]
00007e6bc8bcf3c6  por xmm6, xmm10
00007e6bc8bcf3cb  lea r12, [rax+0x30]
00007e6bc8bcf3cf  mov r11, [r13+r12*1]
00007e6bc8bcf3d4  lea r12, [rax+0x38]
00007e6bc8bcf3d8  mov r10, [r13+r12*1]
00007e6bc8bcf3dd  movq xmm10, r11
00007e6bc8bcf3e2  vmovaps [rsp+0x40], xmm1
00007e6bc8bcf3e8  movq xmm1, r10
00007e6bc8bcf3ed  movq xmm10, xmm10
00007e6bc8bcf3f2  vmovaps [rsp+0x60], xmm10
00007e6bc8bcf3f8  movq xmm10, xmm10
00007e6bc8bcf3fd  movaps [r15+0x130], xmm10
00007e6bc8bcf405  movq xmm1, xmm1
00007e6bc8bcf409  vmovaps [rsp+0x70], xmm1
00007e6bc8bcf40f  movq xmm1, xmm1
00007e6bc8bcf413  movaps [r15+0x280], xmm1
00007e6bc8bcf41b  vmovaps [rsp+0x80], xmm9
00007e6bc8bcf424  vmovaps xmm1, [rsp+0x80]
00007e6bc8bcf42d  por xmm9, xmm1
00007e6bc8bcf432  lea r12, [rax+0x20]
00007e6bc8bcf436  mov r11, [r13+r12*1]
00007e6bc8bcf43b  lea r12, [rax+0x28]
00007e6bc8bcf43f  mov r10, [r13+r12*1]
00007e6bc8bcf444  movq xmm1, r11
00007e6bc8bcf449  movq xmm10, r10
00007e6bc8bcf44e  movq xmm1, xmm1
00007e6bc8bcf452  vmovaps [rsp+0x80], xmm1
00007e6bc8bcf45b  movq xmm1, xmm1
00007e6bc8bcf45f  movaps [r15+0x150], xmm1
00007e6bc8bcf467  movq xmm10, xmm10
00007e6bc8bcf46c  vmovaps [rsp+0x90], xmm10
00007e6bc8bcf475  movq xmm10, xmm10
00007e6bc8bcf47a  movaps [r15+0x140], xmm10
00007e6bc8bcf482  lea r12, [rax+0x10]
00007e6bc8bcf486  mov r11, [r13+r12*1]
00007e6bc8bcf48b  lea r12, [rax+0x18]
00007e6bc8bcf48f  mov r10, [r13+r12*1]
00007e6bc8bcf494  movq xmm1, r11
00007e6bc8bcf499  movq xmm10, r10
00007e6bc8bcf49e  movq xmm1, xmm1
00007e6bc8bcf4a2  vmovaps [rsp+0xA0], xmm1
00007e6bc8bcf4ab  movq xmm1, xmm1
00007e6bc8bcf4af  movaps [r15+0x170], xmm1
00007e6bc8bcf4b7  movq xmm10, xmm10
00007e6bc8bcf4bc  vmovaps [rsp+0xB0], xmm10
00007e6bc8bcf4c5  movq xmm10, xmm10
00007e6bc8bcf4ca  movaps [r15+0x160], xmm10
00007e6bc8bcf4d2  mov r12, [r13+rax*1]
00007e6bc8bcf4d7  vmovq xmm1, r12
00007e6bc8bcf4dc  vpbroadcastq xmm1, xmm1
00007e6bc8bcf4e1  lea r12, [rax+0x08]
00007e6bc8bcf4e5  mov rax, [r13+r12*1]
00007e6bc8bcf4ea  movq xmm10, rax
00007e6bc8bcf4ef  movaps [r15+0x230], xmm10
00007e6bc8bcf4f7  lea rax, [r14+0x50]
00007e6bc8bcf4fb  movups xmm10, [r13+rax*1]
00007e6bc8bcf501  lea rax, [r14+0x60]
00007e6bc8bcf505  vmovaps [rsp+0xC0], xmm1
00007e6bc8bcf50e  movups xmm1, [r13+rax*1]
00007e6bc8bcf514  lea rax, [r14+0x30]
00007e6bc8bcf518  vmovaps [rsp+0xD0], xmm1
00007e6bc8bcf521  movups xmm1, [r13+rax*1]
00007e6bc8bcf527  mov qword ptr [r15+0x60], 0x430920
00007e6bc8bcf52f  mov qword ptr [r15+0x58], 0x40
00007e6bc8bcf537  vmovaps [rsp+0xE0], xmm1
00007e6bc8bcf540  vmovaps [rsp+0xF0], xmm15
00007e6bc8bcf549  vmovaps xmm15, [rsp+0xC0]
00007e6bc8bcf552  vmovaps [rsp+0xC0], xmm14
00007e6bc8bcf55b  vmovaps xmm14, [rsp+0x40]
00007e6bc8bcf561  vmovaps [rsp+0x40], xmm13
00007e6bc8bcf567  movaps xmm1, xmm15
00007e6bc8bcf56b  mulpd xmm1, xmm14
00007e6bc8bcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007e6bc8bcf575  ptest xmm13, xmm13
00007e6bc8bcf57b  jnz 0x00007E6BC8BD0682
00007e6bc8bcf581  movq xmm14, qword ptr [r15+0x230]
00007e6bc8bcf58a  vmovaps [rsp+0x100], xmm14
00007e6bc8bcf593  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bcf599  vmovaps [rsp+0x110], xmm1
00007e6bc8bcf5a2  vmovaps xmm1, [rsp+0xE0]
00007e6bc8bcf5ab  vmovaps [rsp+0xE0], xmm15
00007e6bc8bcf5b4  movaps xmm13, xmm1
00007e6bc8bcf5b8  mulpd xmm13, xmm14
00007e6bc8bcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007e6bc8bcf5c3  ptest xmm15, xmm15
00007e6bc8bcf5c9  jnz 0x00007E6BC8BD07C4
00007e6bc8bcf5cf  vxorps xmm1, xmm1, xmm1
00007e6bc8bcf5d3  vpbroadcastq xmm1, xmm1
00007e6bc8bcf5d8  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bcf5e1  vmovaps [rsp+0xE0], xmm1
00007e6bc8bcf5ea  vmovaps xmm1, [rsp+0xD0]
00007e6bc8bcf5f3  vmovaps [rsp+0xD0], xmm13
00007e6bc8bcf5fc  movaps xmm15, xmm14
00007e6bc8bcf600  mulpd xmm15, xmm1
00007e6bc8bcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007e6bc8bcf60b  ptest xmm13, xmm13
00007e6bc8bcf611  jnz 0x00007E6BC8BD0907
00007e6bc8bcf617  movaps xmm1, xmm14
00007e6bc8bcf61b  mulpd xmm1, xmm10
00007e6bc8bcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007e6bc8bcf625  ptest xmm13, xmm13
00007e6bc8bcf62b  jnz 0x00007E6BC8BD0A4A
00007e6bc8bcf631  movaps xmm13, xmm14
00007e6bc8bcf635  mulpd xmm13, xmm2
00007e6bc8bcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007e6bc8bcf640  ptest xmm10, xmm10
00007e6bc8bcf646  jnz 0x00007E6BC8BD0B8C
00007e6bc8bcf64c  vmovaps [rsp+0x120], xmm7
00007e6bc8bcf655  vmovaps xmm14, [rsp+0x120]
00007e6bc8bcf65e  por xmm7, xmm14
00007e6bc8bcf663  vmovaps xmm14, [rsp+0xC0]
00007e6bc8bcf66c  vmovaps xmm10, [rsp+0xC0]
00007e6bc8bcf675  por xmm14, xmm10
00007e6bc8bcf67a  vmovaps xmm2, [rsp+0x100]
00007e6bc8bcf683  vpermilpd xmm2, xmm2, 0x00
00007e6bc8bcf689  vmovaps [rsp+0xC0], xmm1
00007e6bc8bcf692  vmovaps [rsp+0x120], xmm15
00007e6bc8bcf69b  movaps xmm1, xmm10
00007e6bc8bcf69f  mulpd xmm1, xmm2
00007e6bc8bcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007e6bc8bcf6a8  ptest xmm15, xmm15
00007e6bc8bcf6ae  jnz 0x00007E6BC8BD0CCF
00007e6bc8bcf6b4  xor eax, eax
00007e6bc8bcf6b6  mov r12d, 0x40
00007e6bc8bcf6bc  mov r11d, 0x200
00007e6bc8bcf6c2  cmp r12, r11
00007e6bc8bcf6c5  cmc
00007e6bc8bcf6c6  lahf
00007e6bc8bcf6c7  seto al
00007e6bc8bcf6ca  mov [r15+0x108], eax
00007e6bc8bcf6d1  vmovaps xmm10, [rsp+0x110]
00007e6bc8bcf6da  vmovaps xmm2, [rsp+0xE0]
00007e6bc8bcf6e3  vmovaps [rsp+0xE0], xmm1
00007e6bc8bcf6ec  movaps xmm15, xmm10
00007e6bc8bcf6f0  addpd xmm15, xmm2
00007e6bc8bcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e6bc8bcf6fb  ptest xmm1, xmm1
00007e6bc8bcf700  jnz 0x00007E6BC8BD0E10
00007e6bc8bcf706  vmovaps xmm10, [rsp+0x120]
00007e6bc8bcf70f  vmovaps [rsp+0x110], xmm15
00007e6bc8bcf718  movaps xmm1, xmm10
00007e6bc8bcf71c  addpd xmm1, xmm12
00007e6bc8bcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007e6bc8bcf726  ptest xmm15, xmm15
00007e6bc8bcf72c  jnz 0x00007E6BC8BD0F53
00007e6bc8bcf732  vmovaps xmm10, [rsp+0xC0]
00007e6bc8bcf73b  vmovaps [rsp+0xC0], xmm1
00007e6bc8bcf744  movaps xmm15, xmm10
00007e6bc8bcf748  addpd xmm15, xmm12
00007e6bc8bcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007e6bc8bcf753  ptest xmm1, xmm1
00007e6bc8bcf758  jnz 0x00007E6BC8BD1095
00007e6bc8bcf75e  vmovaps xmm1, [rsp+0x30]
00007e6bc8bcf764  vmovaps xmm12, [rsp+0x30]
00007e6bc8bcf76a  por xmm1, xmm12
00007e6bc8bcf76f  vmovaps xmm12, [rsp+0x20]
00007e6bc8bcf775  vmovaps xmm10, [rsp+0x20]
00007e6bc8bcf77b  por xmm12, xmm10
00007e6bc8bcf780  vmovaps [rsp+0x20], xmm5
00007e6bc8bcf786  vmovaps xmm10, [rsp+0x20]
00007e6bc8bcf78c  por xmm5, xmm10
00007e6bc8bcf791  vmovaps [rsp+0x20], xmm11
00007e6bc8bcf797  vmovaps xmm10, [rsp+0x20]
00007e6bc8bcf79d  por xmm11, xmm10
00007e6bc8bcf7a2  vmovaps [rsp+0x20], xmm4
00007e6bc8bcf7a8  vmovaps xmm10, [rsp+0x20]
00007e6bc8bcf7ae  por xmm4, xmm10
00007e6bc8bcf7b3  vmovaps [rsp+0x20], xmm8
00007e6bc8bcf7b9  vmovaps xmm10, [rsp+0x20]
00007e6bc8bcf7bf  por xmm8, xmm10
00007e6bc8bcf7c4  vmovaps xmm10, [rsp+0xF0]
00007e6bc8bcf7cd  vmovaps [rsp+0x20], xmm1
00007e6bc8bcf7d3  vmovaps xmm1, [rsp+0xF0]
00007e6bc8bcf7dc  por xmm10, xmm1
00007e6bc8bcf7e1  lea rax, [r14+0xA0]
00007e6bc8bcf7e8  movups xmm1, [r13+rax*1]
00007e6bc8bcf7ee  lea rax, [r14+0xB0]
00007e6bc8bcf7f5  vmovaps [rsp+0x30], xmm1
00007e6bc8bcf7fb  movups xmm1, [r13+rax*1]
00007e6bc8bcf801  vmovaps [rsp+0xF0], xmm1
00007e6bc8bcf80a  vmovaps [rsp+0x120], xmm15
00007e6bc8bcf813  movaps xmm1, xmm13
00007e6bc8bcf817  addpd xmm1, xmm2
00007e6bc8bcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007e6bc8bcf820  ptest xmm15, xmm15
00007e6bc8bcf826  jnz 0x00007E6BC8BD11ED
00007e6bc8bcf82c  lea rax, [r14+0xF0]
00007e6bc8bcf833  movups xmm15, [r13+rax*1]
00007e6bc8bcf839  vmovaps xmm2, [rsp+0xC0]
00007e6bc8bcf842  vmovaps [rsp+0xC0], xmm1
00007e6bc8bcf84b  vmovaps xmm1, [rsp+0xE0]
00007e6bc8bcf854  vmovaps [rsp+0xE0], xmm15
00007e6bc8bcf85d  movaps xmm13, xmm2
00007e6bc8bcf861  addpd xmm13, xmm1
00007e6bc8bcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007e6bc8bcf86c  ptest xmm15, xmm15
00007e6bc8bcf872  jnz 0x00007E6BC8BD1338
00007e6bc8bcf878  vmovaps xmm15, [rsp+0x120]
00007e6bc8bcf881  vmovaps xmm2, [rsp+0xD0]
00007e6bc8bcf88a  vmovaps [rsp+0xD0], xmm14
00007e6bc8bcf893  movaps xmm1, xmm15
00007e6bc8bcf897  addpd xmm1, xmm2
00007e6bc8bcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007e6bc8bcf8a0  ptest xmm14, xmm14
00007e6bc8bcf8a6  jnz 0x00007E6BC8BD147A
00007e6bc8bcf8ac  vmovaps xmm15, [rsp+0x100]
00007e6bc8bcf8b5  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bcf8bb  vmovaps xmm2, [rsp+0xF0]
00007e6bc8bcf8c4  vmovaps [rsp+0xF0], xmm1
00007e6bc8bcf8cd  movaps xmm14, xmm2
00007e6bc8bcf8d1  mulpd xmm14, xmm15
00007e6bc8bcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007e6bc8bcf8dc  ptest xmm1, xmm1
00007e6bc8bcf8e1  jnz 0x00007E6BC8BD15BB
00007e6bc8bcf8e7  vmovaps xmm1, [rsp+0xA0]
00007e6bc8bcf8f0  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bcf8f6  vmovaps xmm2, [rsp+0xE0]
00007e6bc8bcf8ff  vmovaps [rsp+0xE0], xmm14
00007e6bc8bcf908  movaps xmm15, xmm2
00007e6bc8bcf90c  mulpd xmm15, xmm1
00007e6bc8bcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007e6bc8bcf917  ptest xmm14, xmm14
00007e6bc8bcf91d  jnz 0x00007E6BC8BD16FE
00007e6bc8bcf923  lea rax, [r14+0xE0]
00007e6bc8bcf92a  movups xmm1, [r13+rax*1]
00007e6bc8bcf930  vmovaps xmm14, [rsp+0x100]
00007e6bc8bcf939  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bcf93f  vmovaps [rsp+0x100], xmm1
00007e6bc8bcf948  vmovaps xmm1, [rsp+0x30]
00007e6bc8bcf94e  vmovaps [rsp+0x30], xmm15
00007e6bc8bcf954  movaps xmm2, xmm1
00007e6bc8bcf957  mulpd xmm2, xmm14
00007e6bc8bcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007e6bc8bcf961  ptest xmm15, xmm15
00007e6bc8bcf967  jnz 0x00007E6BC8BD184A
00007e6bc8bcf96d  vmovaps [rsp+0x120], xmm10
00007e6bc8bcf976  vmovaps xmm1, [rsp+0x120]
00007e6bc8bcf97f  por xmm10, xmm1
00007e6bc8bcf984  movaps [r15+0x300], xmm10
00007e6bc8bcf98c  vmovaps [rsp+0x120], xmm8
00007e6bc8bcf995  vmovaps xmm1, [rsp+0x120]
00007e6bc8bcf99e  por xmm8, xmm1
00007e6bc8bcf9a3  movaps [r15+0x190], xmm8
00007e6bc8bcf9ab  vmovaps xmm1, [rsp+0xA0]
00007e6bc8bcf9b4  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bcf9ba  vmovaps xmm14, [rsp+0x100]
00007e6bc8bcf9c3  vmovaps [rsp+0x100], xmm13
00007e6bc8bcf9cc  movaps xmm15, xmm14
00007e6bc8bcf9d0  mulpd xmm15, xmm1
00007e6bc8bcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007e6bc8bcf9db  ptest xmm13, xmm13
00007e6bc8bcf9e1  jnz 0x00007E6BC8BD198B
00007e6bc8bcf9e7  lea rax, [r14+0x90]
00007e6bc8bcf9ee  movups xmm1, [r13+rax*1]
00007e6bc8bcf9f4  vmovaps [rsp+0x120], xmm4
00007e6bc8bcf9fd  vmovaps xmm14, [rsp+0x120]
00007e6bc8bcfa06  por xmm4, xmm14
00007e6bc8bcfa0b  movaps [r15+0x1C0], xmm4
00007e6bc8bcfa13  vmovaps [rsp+0x120], xmm11
00007e6bc8bcfa1c  vmovaps xmm14, [rsp+0x120]
00007e6bc8bcfa25  por xmm11, xmm14
00007e6bc8bcfa2a  movaps [r15+0x200], xmm11
00007e6bc8bcfa32  vmovaps [rsp+0x120], xmm5
00007e6bc8bcfa3b  vmovaps xmm14, [rsp+0x120]
00007e6bc8bcfa44  por xmm5, xmm14
00007e6bc8bcfa49  movaps [r15+0x2D0], xmm5
00007e6bc8bcfa51  vmovaps [rsp+0x120], xmm12
00007e6bc8bcfa5a  vmovaps xmm14, [rsp+0x120]
00007e6bc8bcfa63  por xmm12, xmm14
00007e6bc8bcfa68  movaps [r15+0x2E0], xmm12
00007e6bc8bcfa70  vmovaps xmm13, [rsp+0x110]
00007e6bc8bcfa79  vmovaps [rsp+0x110], xmm1
00007e6bc8bcfa82  vmovaps xmm1, [rsp+0xE0]
00007e6bc8bcfa8b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bcfa94  movaps xmm14, xmm13
00007e6bc8bcfa98  addpd xmm14, xmm1
00007e6bc8bcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007e6bc8bcfaa3  ptest xmm15, xmm15
00007e6bc8bcfaa9  jnz 0x00007E6BC8BD1AD8
00007e6bc8bcfaaf  vmovaps xmm1, [rsp+0xA0]
00007e6bc8bcfab8  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bcfabe  vmovaps xmm13, [rsp+0x110]
00007e6bc8bcfac7  vmovaps [rsp+0x110], xmm14
00007e6bc8bcfad0  movaps xmm15, xmm13
00007e6bc8bcfad4  mulpd xmm15, xmm1
00007e6bc8bcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007e6bc8bcfadf  ptest xmm14, xmm14
00007e6bc8bcfae5  jnz 0x00007E6BC8BD1C1B
00007e6bc8bcfaeb  lea rax, [r14+0x80]
00007e6bc8bcfaf2  movups xmm1, [r13+rax*1]
00007e6bc8bcfaf8  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bcfb01  vmovaps [rsp+0xC0], xmm1
00007e6bc8bcfb0a  movaps xmm14, xmm13
00007e6bc8bcfb0e  addpd xmm14, xmm2
00007e6bc8bcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007e6bc8bcfb19  ptest xmm1, xmm1
00007e6bc8bcfb1e  jnz 0x00007E6BC8BD1D68
00007e6bc8bcfb24  vmovaps xmm13, [rsp+0x100]
00007e6bc8bcfb2d  vmovaps xmm2, [rsp+0x30]
00007e6bc8bcfb33  vmovaps [rsp+0x30], xmm15
00007e6bc8bcfb39  movaps xmm1, xmm13
00007e6bc8bcfb3d  addpd xmm1, xmm2
00007e6bc8bcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007e6bc8bcfb46  ptest xmm15, xmm15
00007e6bc8bcfb4c  jnz 0x00007E6BC8BD1EAB
00007e6bc8bcfb52  vmovaps xmm15, [rsp+0x20]
00007e6bc8bcfb58  vmovaps xmm13, [rsp+0x20]
00007e6bc8bcfb5e  por xmm15, xmm13
00007e6bc8bcfb63  movaps [r15+0x2F0], xmm15
00007e6bc8bcfb6b  vmovaps xmm13, [rsp+0xA0]
00007e6bc8bcfb74  vpermilpd xmm13, xmm13, 0x00
00007e6bc8bcfb7a  vmovaps [rsp+0x20], xmm1
00007e6bc8bcfb80  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bcfb89  vmovaps [rsp+0xA0], xmm15
00007e6bc8bcfb92  movaps xmm2, xmm1
00007e6bc8bcfb95  mulpd xmm2, xmm13
00007e6bc8bcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007e6bc8bcfb9f  ptest xmm15, xmm15
00007e6bc8bcfba5  jnz 0x00007E6BC8BD1FEC
00007e6bc8bcfbab  lea rax, [r14+0xD0]
00007e6bc8bcfbb2  movups xmm1, [r13+rax*1]
00007e6bc8bcfbb8  vmovaps xmm13, [rsp+0xF0]
00007e6bc8bcfbc1  vmovaps [rsp+0xC0], xmm1
00007e6bc8bcfbca  vmovaps xmm1, [rsp+0xE0]
00007e6bc8bcfbd3  vmovaps [rsp+0xE0], xmm14
00007e6bc8bcfbdc  movaps xmm15, xmm13
00007e6bc8bcfbe0  addpd xmm15, xmm1
00007e6bc8bcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007e6bc8bcfbeb  ptest xmm14, xmm14
00007e6bc8bcfbf1  jnz 0x00007E6BC8BD2137
00007e6bc8bcfbf7  vmovaps xmm1, [rsp+0xB0]
00007e6bc8bcfc00  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bcfc06  movaps xmm14, xmm11
00007e6bc8bcfc0a  mulpd xmm14, xmm1
00007e6bc8bcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007e6bc8bcfc15  ptest xmm13, xmm13
00007e6bc8bcfc1b  jnz 0x00007E6BC8BD227A
00007e6bc8bcfc21  movaps [r15+0x260], xmm14
00007e6bc8bcfc29  vxorps xmm1, xmm1, xmm1
00007e6bc8bcfc2d  vpbroadcastq xmm1, xmm1
00007e6bc8bcfc32  movaps [r15+0x1B0], xmm1
00007e6bc8bcfc3a  vmovaps xmm1, [rsp+0xB0]
00007e6bc8bcfc43  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bcfc49  vmovaps xmm11, [rsp+0xC0]
00007e6bc8bcfc52  vmovaps [rsp+0xC0], xmm15
00007e6bc8bcfc5b  movaps xmm13, xmm11
00007e6bc8bcfc5f  mulpd xmm13, xmm1
00007e6bc8bcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007e6bc8bcfc6a  ptest xmm15, xmm15
00007e6bc8bcfc70  jnz 0x00007E6BC8BD23BD
00007e6bc8bcfc76  lea rax, [r14+0xC0]
00007e6bc8bcfc7d  movups xmm1, [r13+rax*1]
00007e6bc8bcfc83  vmovaps xmm11, [rsp+0x110]
00007e6bc8bcfc8c  vmovaps [rsp+0xF0], xmm1
00007e6bc8bcfc95  vmovaps xmm1, [rsp+0x30]
00007e6bc8bcfc9b  vmovaps [rsp+0x30], xmm14
00007e6bc8bcfca1  movaps xmm15, xmm11
00007e6bc8bcfca5  addpd xmm15, xmm1
00007e6bc8bcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007e6bc8bcfcb0  ptest xmm14, xmm14
00007e6bc8bcfcb6  jnz 0x00007E6BC8BD250A
00007e6bc8bcfcbc  vmovaps [rsp+0x100], xmm9
00007e6bc8bcfcc5  vmovaps xmm1, [rsp+0x100]
00007e6bc8bcfcce  por xmm9, xmm1
00007e6bc8bcfcd3  movaps [r15+0x270], xmm9
00007e6bc8bcfcdb  vmovaps [rsp+0x100], xmm6
00007e6bc8bcfce4  vmovaps xmm1, [rsp+0x100]
00007e6bc8bcfced  por xmm6, xmm1
00007e6bc8bcfcf1  movaps [r15+0x1A0], xmm6
00007e6bc8bcfcf9  vmovaps xmm14, [rsp+0xB0]
00007e6bc8bcfd02  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bcfd08  vmovaps xmm6, [rsp+0xF0]
00007e6bc8bcfd11  vmovaps [rsp+0xF0], xmm1
00007e6bc8bcfd1a  movaps xmm11, xmm6
00007e6bc8bcfd1e  mulpd xmm11, xmm14
00007e6bc8bcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007e6bc8bcfd29  ptest xmm1, xmm1
00007e6bc8bcfd2e  jnz 0x00007E6BC8BD264D
00007e6bc8bcfd34  lea rax, [r14+0x20]
00007e6bc8bcfd38  movups xmm1, [r13+rax*1]
00007e6bc8bcfd3e  movaps [r15+0x110], xmm1
00007e6bc8bcfd46  vmovaps xmm6, [rsp+0xE0]
00007e6bc8bcfd4f  vmovaps [rsp+0xE0], xmm1
00007e6bc8bcfd58  movaps xmm14, xmm6
00007e6bc8bcfd5c  addpd xmm14, xmm2
00007e6bc8bcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007e6bc8bcfd67  ptest xmm1, xmm1
00007e6bc8bcfd6c  jnz 0x00007E6BC8BD279A
00007e6bc8bcfd72  vmovaps xmm1, [rsp+0xB0]
00007e6bc8bcfd7b  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bcfd81  movaps xmm6, xmm5
00007e6bc8bcfd84  mulpd xmm6, xmm1
00007e6bc8bcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007e6bc8bcfd8d  ptest xmm2, xmm2
00007e6bc8bcfd92  jnz 0x00007E6BC8BD28DC
00007e6bc8bcfd98  vmovaps xmm5, [rsp+0x20]
00007e6bc8bcfd9e  movaps xmm1, xmm5
00007e6bc8bcfda1  addpd xmm1, xmm13
00007e6bc8bcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007e6bc8bcfdab  ptest xmm2, xmm2
00007e6bc8bcfdb0  jnz 0x00007E6BC8BD2A1C
00007e6bc8bcfdb6  vmovaps xmm13, [rsp+0x80]
00007e6bc8bcfdbf  vpermilpd xmm13, xmm13, 0x00
00007e6bc8bcfdc5  vmovaps xmm2, [rsp+0xE0]
00007e6bc8bcfdce  vmovaps [rsp+0x20], xmm1
00007e6bc8bcfdd4  movaps xmm5, xmm2
00007e6bc8bcfdd7  mulpd xmm5, xmm13
00007e6bc8bcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007e6bc8bcfde1  ptest xmm1, xmm1
00007e6bc8bcfde6  jnz 0x00007E6BC8BD2B5D
00007e6bc8bcfdec  vmovaps xmm1, [rsp+0x80]
00007e6bc8bcfdf5  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bcfdfb  movaps xmm13, xmm10
00007e6bc8bcfdff  mulpd xmm13, xmm1
00007e6bc8bcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007e6bc8bcfe0a  ptest xmm2, xmm2
00007e6bc8bcfe0f  jnz 0x00007E6BC8BD2C9E
00007e6bc8bcfe15  vmovaps xmm10, [rsp+0x30]
00007e6bc8bcfe1b  movaps xmm1, xmm15
00007e6bc8bcfe1f  addpd xmm1, xmm10
00007e6bc8bcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007e6bc8bcfe29  ptest xmm2, xmm2
00007e6bc8bcfe2e  jnz 0x00007E6BC8BD2DE1
00007e6bc8bcfe34  vmovaps xmm10, [rsp+0xC0]
00007e6bc8bcfe3d  movaps xmm15, xmm10
00007e6bc8bcfe41  addpd xmm15, xmm11
00007e6bc8bcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007e6bc8bcfe4c  ptest xmm2, xmm2
00007e6bc8bcfe51  jnz 0x00007E6BC8BD2F23
00007e6bc8bcfe57  vmovaps xmm11, [rsp+0x80]
00007e6bc8bcfe60  vpermilpd xmm11, xmm11, 0x00
00007e6bc8bcfe66  movaps xmm10, xmm12
00007e6bc8bcfe6a  mulpd xmm10, xmm11
00007e6bc8bcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007e6bc8bcfe75  ptest xmm2, xmm2
00007e6bc8bcfe7a  jnz 0x00007E6BC8BD3067
00007e6bc8bcfe80  vmovaps xmm12, [rsp+0x80]
00007e6bc8bcfe89  vpermilpd xmm12, xmm12, 0x00
00007e6bc8bcfe8f  vmovaps xmm2, [rsp+0xA0]
00007e6bc8bcfe98  vmovaps [rsp+0x30], xmm1
00007e6bc8bcfe9e  movaps xmm11, xmm2
00007e6bc8bcfea2  mulpd xmm11, xmm12
00007e6bc8bcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007e6bc8bcfead  ptest xmm1, xmm1
00007e6bc8bcfeb2  jnz 0x00007E6BC8BD31AB
00007e6bc8bcfeb8  movaps xmm1, xmm14
00007e6bc8bcfebc  addpd xmm1, xmm6
00007e6bc8bcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007e6bc8bcfec5  ptest xmm12, xmm12
00007e6bc8bcfecb  jnz 0x00007E6BC8BD32EE
00007e6bc8bcfed1  vmovaps xmm12, [rsp+0x20]
00007e6bc8bcfed7  movaps xmm14, xmm12
00007e6bc8bcfedb  addpd xmm14, xmm5
00007e6bc8bcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007e6bc8bcfee6  ptest xmm6, xmm6
00007e6bc8bcfeeb  jnz 0x00007E6BC8BD342F
00007e6bc8bcfef1  vmovaps xmm12, [rsp+0x90]
00007e6bc8bcfefa  vpermilpd xmm12, xmm12, 0x00
00007e6bc8bcff00  movaps xmm6, xmm9
00007e6bc8bcff04  mulpd xmm6, xmm12
00007e6bc8bcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007e6bc8bcff0e  ptest xmm5, xmm5
00007e6bc8bcff13  jnz 0x00007E6BC8BD3572
00007e6bc8bcff19  movaps xmm12, xmm15
00007e6bc8bcff1d  addpd xmm12, xmm13
00007e6bc8bcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007e6bc8bcff28  ptest xmm9, xmm9
00007e6bc8bcff2e  jnz 0x00007E6BC8BD36B4
00007e6bc8bcff34  vmovaps xmm13, [rsp+0x30]
00007e6bc8bcff3a  movaps xmm15, xmm13
00007e6bc8bcff3e  addpd xmm15, xmm10
00007e6bc8bcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007e6bc8bcff49  ptest xmm9, xmm9
00007e6bc8bcff4f  jnz 0x00007E6BC8BD37F8
00007e6bc8bcff55  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bcff5e  vmovaps xmm10, [rsp+0xD0]
00007e6bc8bcff67  por xmm13, xmm10
00007e6bc8bcff6c  movaps [r15+0x250], xmm13
00007e6bc8bcff74  vmovaps [rsp+0x20], xmm7
00007e6bc8bcff7a  vmovaps xmm13, [rsp+0x20]
00007e6bc8bcff80  por xmm7, xmm13
00007e6bc8bcff85  movaps [r15+0x2A0], xmm7
00007e6bc8bcff8d  vmovaps [rsp+0x20], xmm3
00007e6bc8bcff93  vmovaps xmm13, [rsp+0x20]
00007e6bc8bcff99  por xmm3, xmm13
00007e6bc8bcff9e  movaps [r15+0x1D0], xmm3
00007e6bc8bcffa6  lea rax, [r14+0x40]
00007e6bc8bcffaa  movups xmm13, [r13+rax*1]
00007e6bc8bcffb0  movaps [r15+0x2C0], xmm13
00007e6bc8bcffb8  vmovaps xmm10, [rsp+0x90]
00007e6bc8bcffc1  vpermilpd xmm10, xmm10, 0x00
00007e6bc8bcffc7  movaps xmm9, xmm8
00007e6bc8bcffcb  mulpd xmm9, xmm10
00007e6bc8bcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007e6bc8bcffd6  ptest xmm5, xmm5
00007e6bc8bcffdb  jnz 0x00007E6BC8BD3946
00007e6bc8bcffe1  movaps xmm10, xmm1
00007e6bc8bcffe5  addpd xmm10, xmm11
00007e6bc8bcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007e6bc8bcfff0  ptest xmm8, xmm8
00007e6bc8bcfff6  jnz 0x00007E6BC8BD3A8A
00007e6bc8bcfffc  movaps xmm1, xmm14
00007e6bc8bd0000  addpd xmm1, xmm6
00007e6bc8bd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007e6bc8bd0009  ptest xmm11, xmm11
00007e6bc8bd000f  jnz 0x00007E6BC8BD3BCD
00007e6bc8bd0015  vmovaps xmm14, [rsp+0x90]
00007e6bc8bd001e  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bd0024  movaps xmm11, xmm13
00007e6bc8bd0028  mulpd xmm11, xmm14
00007e6bc8bd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007e6bc8bd0033  ptest xmm8, xmm8
00007e6bc8bd0039  jnz 0x00007E6BC8BD3D0E
00007e6bc8bd003f  vmovaps xmm14, [rsp+0x90]
00007e6bc8bd0048  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bd004e  vmovaps xmm8, [rsp+0x10]
00007e6bc8bd0054  movaps xmm13, xmm8
00007e6bc8bd0058  mulpd xmm13, xmm14
00007e6bc8bd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007e6bc8bd0063  ptest xmm6, xmm6
00007e6bc8bd0068  jnz 0x00007E6BC8BD3E52
00007e6bc8bd006e  vmovaps xmm14, [rsp+0x60]
00007e6bc8bd0074  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bd007a  movaps xmm8, xmm7
00007e6bc8bd007e  mulpd xmm8, xmm14
00007e6bc8bd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007e6bc8bd0089  ptest xmm6, xmm6
00007e6bc8bd008e  jnz 0x00007E6BC8BD3F96
00007e6bc8bd0094  movaps xmm14, xmm12
00007e6bc8bd0098  addpd xmm14, xmm9
00007e6bc8bd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007e6bc8bd00a3  ptest xmm7, xmm7
00007e6bc8bd00a8  jnz 0x00007E6BC8BD40D9
00007e6bc8bd00ae  vmovaps xmm12, [rsp+0x60]
00007e6bc8bd00b4  vpermilpd xmm12, xmm12, 0x00
00007e6bc8bd00ba  vmovaps xmm7, [rsp+0xF0]
00007e6bc8bd00c3  movaps xmm9, xmm7
00007e6bc8bd00c7  mulpd xmm9, xmm12
00007e6bc8bd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007e6bc8bd00d2  ptest xmm6, xmm6
00007e6bc8bd00d7  jnz 0x00007E6BC8BD421D
00007e6bc8bd00dd  movaps xmm12, xmm15
00007e6bc8bd00e1  addpd xmm12, xmm11
00007e6bc8bd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007e6bc8bd00ec  ptest xmm7, xmm7
00007e6bc8bd00f1  jnz 0x00007E6BC8BD4360
00007e6bc8bd00f7  vmovaps xmm15, [rsp+0x60]
00007e6bc8bd00fd  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bd0103  vmovaps xmm7, [rsp+0x40]
00007e6bc8bd0109  movaps xmm11, xmm7
00007e6bc8bd010d  mulpd xmm11, xmm15
00007e6bc8bd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007e6bc8bd0118  ptest xmm6, xmm6
00007e6bc8bd011d  jnz 0x00007E6BC8BD44A4
00007e6bc8bd0123  movaps xmm15, xmm10
00007e6bc8bd0127  addpd xmm15, xmm13
00007e6bc8bd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007e6bc8bd0132  ptest xmm7, xmm7
00007e6bc8bd0137  jnz 0x00007E6BC8BD45E7
00007e6bc8bd013d  vmovaps xmm13, [rsp+0x60]
00007e6bc8bd0143  vpermilpd xmm13, xmm13, 0x00
00007e6bc8bd0149  vmovaps xmm7, [rsp+0x50]
00007e6bc8bd014f  movaps xmm10, xmm7
00007e6bc8bd0153  mulpd xmm10, xmm13
00007e6bc8bd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007e6bc8bd015e  ptest xmm6, xmm6
00007e6bc8bd0163  jnz 0x00007E6BC8BD472B
00007e6bc8bd0169  movaps xmm13, xmm1
00007e6bc8bd016d  addpd xmm13, xmm8
00007e6bc8bd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007e6bc8bd0178  ptest xmm7, xmm7
00007e6bc8bd017d  jnz 0x00007E6BC8BD486E
00007e6bc8bd0183  lea rax, [r14+0x70]
00007e6bc8bd0187  movups xmm1, [r13+rax*1]
00007e6bc8bd018d  movaps [r15+0x240], xmm1
00007e6bc8bd0195  movaps xmm8, xmm14
00007e6bc8bd0199  addpd xmm8, xmm9
00007e6bc8bd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007e6bc8bd01a4  ptest xmm7, xmm7
00007e6bc8bd01a9  jnz 0x00007E6BC8BD49BB
00007e6bc8bd01af  movaps [r15+0x170], xmm8
00007e6bc8bd01b7  vmovaps xmm14, [rsp+0x70]
00007e6bc8bd01bd  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bd01c3  movaps xmm9, xmm1
00007e6bc8bd01c7  mulpd xmm9, xmm14
00007e6bc8bd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007e6bc8bd01d2  ptest xmm7, xmm7
00007e6bc8bd01d7  jnz 0x00007E6BC8BD4AFF
00007e6bc8bd01dd  vmovaps xmm1, [rsp+0x70]
00007e6bc8bd01e3  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd01e9  movaps xmm14, xmm4
00007e6bc8bd01ed  mulpd xmm14, xmm1
00007e6bc8bd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007e6bc8bd01f8  ptest xmm7, xmm7
00007e6bc8bd01fd  jnz 0x00007E6BC8BD4C42
00007e6bc8bd0203  movaps [r15+0x180], xmm14
00007e6bc8bd020b  movaps xmm1, xmm12
00007e6bc8bd020f  addpd xmm1, xmm11
00007e6bc8bd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007e6bc8bd0219  ptest xmm7, xmm7
00007e6bc8bd021e  jnz 0x00007E6BC8BD4D84
00007e6bc8bd0224  movaps [r15+0x210], xmm1
00007e6bc8bd022c  movups xmm12, [r13+r14*1]
00007e6bc8bd0232  lea rax, [r14+0x10]
00007e6bc8bd0236  movups xmm11, [r13+rax*1]
00007e6bc8bd023c  movaps [r15+0x230], xmm11
00007e6bc8bd0244  movaps xmm7, xmm15
00007e6bc8bd0248  addpd xmm7, xmm10
00007e6bc8bd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007e6bc8bd0252  ptest xmm6, xmm6
00007e6bc8bd0257  jnz 0x00007E6BC8BD4EDA
00007e6bc8bd025d  movaps [r15+0x130], xmm7
00007e6bc8bd0265  vmovaps xmm15, [rsp+0x70]
00007e6bc8bd026b  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bd0271  movaps xmm10, xmm11
00007e6bc8bd0275  mulpd xmm10, xmm15
00007e6bc8bd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007e6bc8bd0280  ptest xmm6, xmm6
00007e6bc8bd0285  jnz 0x00007E6BC8BD501C
00007e6bc8bd028b  movaps [r15+0x220], xmm10
00007e6bc8bd0293  vmovaps xmm15, [rsp+0x70]
00007e6bc8bd0299  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bd029f  movaps xmm11, xmm12
00007e6bc8bd02a3  mulpd xmm11, xmm15
00007e6bc8bd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007e6bc8bd02ae  ptest xmm6, xmm6
00007e6bc8bd02b3  jnz 0x00007E6BC8BD5160
00007e6bc8bd02b9  movaps xmm15, xmm13
00007e6bc8bd02bd  addpd xmm15, xmm9
00007e6bc8bd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007e6bc8bd02c8  ptest xmm12, xmm12
00007e6bc8bd02ce  jnz 0x00007E6BC8BD52A4
00007e6bc8bd02d4  movaps [r15+0x140], xmm15
00007e6bc8bd02dc  movaps xmm13, xmm8
00007e6bc8bd02e0  addpd xmm13, xmm14
00007e6bc8bd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007e6bc8bd02eb  ptest xmm12, xmm12
00007e6bc8bd02f1  jnz 0x00007E6BC8BD53E8
00007e6bc8bd02f7  movaps [r15+0x150], xmm13
00007e6bc8bd02ff  movaps xmm14, xmm1
00007e6bc8bd0303  addpd xmm14, xmm10
00007e6bc8bd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007e6bc8bd030e  ptest xmm12, xmm12
00007e6bc8bd0314  jnz 0x00007E6BC8BD552C
00007e6bc8bd031a  movaps [r15+0x160], xmm14
00007e6bc8bd0322  movaps xmm1, xmm7
00007e6bc8bd0325  addpd xmm1, xmm11
00007e6bc8bd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007e6bc8bd032f  ptest xmm12, xmm12
00007e6bc8bd0335  jnz 0x00007E6BC8BD566F
00007e6bc8bd033b  movaps [r15+0x120], xmm1
00007e6bc8bd0343  mov eax, 0x430920
00007e6bc8bd0348  movups [r13+rax*1], xmm15
00007e6bc8bd034e  mov eax, 0x430930
00007e6bc8bd0353  movups [r13+rax*1], xmm13
00007e6bc8bd0359  mov eax, 0x430940
00007e6bc8bd035e  movups [r13+rax*1], xmm14
00007e6bc8bd0364  mov eax, 0x430950
00007e6bc8bd0369  movups [r13+rax*1], xmm1
00007e6bc8bd036f  mov eax, [r15+0x108]
00007e6bc8bd0376  sahf
00007e6bc8bd0377  jnz 0x00007E6BC8BD03A9
00007e6bc8bd0379  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bd0381  jz 0x00007E6BC8BDB900
00007e6bc8bd0387  nop [rax+rax*1], ax
00007e6bc8bd0390  nop [rax+rax*1], eax
00007e6bc8bd0398  mov eax, 0x410444
00007e6bc8bd039d  mov [r15+0x100], rax
00007e6bc8bd03a4  jmp 0x00007E6BC89FE110
00007e6bc8bd03a9  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bd03b1  jz 0x00007E6BC8BD57E0
00007e6bc8bd03b7  nop [rax+rax*1], ax
00007e6bc8bd03c0  nop [rax+rax*1], eax
00007e6bc8bd03c8  mov eax, 0x410278
00007e6bc8bd03cd  mov [r15+0x100], rax
00007e6bc8bd03d4  jmp 0x00007E6BC89FE110
00007e6bc8bd03d9  int3
00007e6bc8bd03da  call 0x00007E6BC8AB52F0
00007e6bc8bd03df  jmp 0x00007E6BC8BCF016
00007e6bc8bd03e4  call 0x00007E6BC8AC4620
00007e6bc8bd03e9  jmp 0x00007E6BC8BCF023
00007e6bc8bd03ee  call 0x00007E6BC8AC33A0
00007e6bc8bd03f3  jmp 0x00007E6BC8BCF035
00007e6bc8bd03f8  call 0x00007E6BC8AC2120
00007e6bc8bd03fd  jmp 0x00007E6BC8BCF03F
00007e6bc8bd0402  call 0x00007E6BC8AC0860
00007e6bc8bd0407  jmp 0x00007E6BC8BCF067
00007e6bc8bd040c  call 0x00007E6BC8ABF5F0
00007e6bc8bd0411  jmp 0x00007E6BC8BCF073
00007e6bc8bd0416  call 0x00007E6BC8AC0860
00007e6bc8bd041b  jmp 0x00007E6BC8BCF0A5
00007e6bc8bd0420  call 0x00007E6BC8ABF5F0
00007e6bc8bd0425  jmp 0x00007E6BC8BCF0B1
00007e6bc8bd042a  call 0x00007E6BC8AC4740
00007e6bc8bd042f  jmp 0x00007E6BC8BCF0BE
00007e6bc8bd0434  call 0x00007E6BC8AB5400
00007e6bc8bd0439  jmp 0x00007E6BC8BCF0CB
00007e6bc8bd043e  call 0x00007E6BC8AB52F0
00007e6bc8bd0443  jmp 0x00007E6BC8BCF0D8
00007e6bc8bd0448  call 0x00007E6BC8AC4620
00007e6bc8bd044d  jmp 0x00007E6BC8BCF0E5
00007e6bc8bd0452  call 0x00007E6BC8AC0860
00007e6bc8bd0457  jmp 0x00007E6BC8BCF10D
00007e6bc8bd045c  call 0x00007E6BC8ABF5F0
00007e6bc8bd0461  jmp 0x00007E6BC8BCF119
00007e6bc8bd0466  call 0x00007E6BC8A09D70
00007e6bc8bd046b  jmp 0x00007E6BC8BCF11F
00007e6bc8bd0470  call 0x00007E6BC8ABE9C0
00007e6bc8bd0475  jmp 0x00007E6BC8BCF129
00007e6bc8bd047a  call 0x00007E6BC8AC0860
00007e6bc8bd047f  jmp 0x00007E6BC8BCF151
00007e6bc8bd0484  call 0x00007E6BC8ABF5F0
00007e6bc8bd0489  jmp 0x00007E6BC8BCF15D
00007e6bc8bd048e  call 0x00007E6BC8ABD750
00007e6bc8bd0493  jmp 0x00007E6BC8BCF16A
00007e6bc8bd0498  call 0x00007E6BC8ABC4E0
00007e6bc8bd049d  jmp 0x00007E6BC8BCF177
00007e6bc8bd04a2  call 0x00007E6BC8AC4740
00007e6bc8bd04a7  jmp 0x00007E6BC8BCF184
00007e6bc8bd04ac  call 0x00007E6BC8AB5400
00007e6bc8bd04b1  jmp 0x00007E6BC8BCF191
00007e6bc8bd04b6  call 0x00007E6BC8AB52F0
00007e6bc8bd04bb  jmp 0x00007E6BC8BCF19E
00007e6bc8bd04c0  call 0x00007E6BC8AC4620
00007e6bc8bd04c5  jmp 0x00007E6BC8BCF1AB
00007e6bc8bd04ca  call 0x00007E6BC8AC0860
00007e6bc8bd04cf  jmp 0x00007E6BC8BCF1BE
00007e6bc8bd04d4  call 0x00007E6BC8ABB270
00007e6bc8bd04d9  jmp 0x00007E6BC8BCF1CB
00007e6bc8bd04de  call 0x00007E6BC8ABA000
00007e6bc8bd04e3  jmp 0x00007E6BC8BCF1D8
00007e6bc8bd04e8  call 0x00007E6BC8AB8D90
00007e6bc8bd04ed  jmp 0x00007E6BC8BCF1E5
00007e6bc8bd04f2  call 0x00007E6BC8AB8A20
00007e6bc8bd04f7  jmp 0x00007E6BC8BCF1F2
00007e6bc8bd04fc  call 0x00007E6BC8AB5400
00007e6bc8bd0501  jmp 0x00007E6BC8BCF1FC
00007e6bc8bd0506  call 0x00007E6BC8AC2240
00007e6bc8bd050b  jmp 0x00007E6BC8BCF206
00007e6bc8bd0510  call 0x00007E6BC8AB52F0
00007e6bc8bd0515  jmp 0x00007E6BC8BCF210
00007e6bc8bd051a  call 0x00007E6BC8AC2120
00007e6bc8bd051f  jmp 0x00007E6BC8BCF21A
00007e6bc8bd0524  call 0x00007E6BC8AB77B0
00007e6bc8bd0529  jmp 0x00007E6BC8BCF224
00007e6bc8bd052e  call 0x00007E6BC8AB6550
00007e6bc8bd0533  jmp 0x00007E6BC8BCF22E
00007e6bc8bd0538  call 0x00007E6BC8ABFD50
00007e6bc8bd053d  jmp 0x00007E6BC8BCF240
00007e6bc8bd0542  call 0x00007E6BC8AB8EA0
00007e6bc8bd0547  jmp 0x00007E6BC8BCF24A
00007e6bc8bd054c  call 0x00007E6BC8ABFC30
00007e6bc8bd0551  jmp 0x00007E6BC8BCF257
00007e6bc8bd0556  call 0x00007E6BC8AB8D90
00007e6bc8bd055b  jmp 0x00007E6BC8BCF264
00007e6bc8bd0560  call 0x00007E6BC8AC2240
00007e6bc8bd0565  jmp 0x00007E6BC8BCF271
00007e6bc8bd056a  call 0x00007E6BC8AB5400
00007e6bc8bd056f  jmp 0x00007E6BC8BCF27E
00007e6bc8bd0574  call 0x00007E6BC8AB52F0
00007e6bc8bd0579  jmp 0x00007E6BC8BCF28B
00007e6bc8bd057e  call 0x00007E6BC8AC2120
00007e6bc8bd0583  jmp 0x00007E6BC8BCF298
00007e6bc8bd0588  call 0x00007E6BC8AB52F0
00007e6bc8bd058d  jmp 0x00007E6BC8BCF2AB
00007e6bc8bd0592  call 0x00007E6BC8AB52F0
00007e6bc8bd0597  jmp 0x00007E6BC8BCF2BE
00007e6bc8bd059c  call 0x00007E6BC8AB52F0
00007e6bc8bd05a1  jmp 0x00007E6BC8BCF2D1
00007e6bc8bd05a6  call 0x00007E6BC8AB52F0
00007e6bc8bd05ab  jmp 0x00007E6BC8BCF2E4
00007e6bc8bd05b0  call 0x00007E6BC8AC2240
00007e6bc8bd05b5  jmp 0x00007E6BC8BCF2F9
00007e6bc8bd05ba  call 0x00007E6BC8AC2240
00007e6bc8bd05bf  jmp 0x00007E6BC8BCF30C
00007e6bc8bd05c4  call 0x00007E6BC8AC2120
00007e6bc8bd05c9  jmp 0x00007E6BC8BCF319
00007e6bc8bd05ce  call 0x00007E6BC8AB52F0
00007e6bc8bd05d3  jmp 0x00007E6BC8BCF32C
00007e6bc8bd05d8  call 0x00007E6BC8AB52F0
00007e6bc8bd05dd  jmp 0x00007E6BC8BCF34F
00007e6bc8bd05e2  call 0x00007E6BC8AB52F0
00007e6bc8bd05e7  jmp 0x00007E6BC8BCF362
00007e6bc8bd05ec  call 0x00007E6BC89FF540
00007e6bc8bd05f1  jmp 0x00007E6BC8BCF380
00007e6bc8bd05f6  call 0x00007E6BC8A08C20
00007e6bc8bd05fb  jmp 0x00007E6BC8BCF38A
00007e6bc8bd0600  call 0x00007E6BC8AD6600
00007e6bc8bd0605  jmp 0x00007E6BC8BCF396
00007e6bc8bd060a  call 0x00007E6BC89FF540
00007e6bc8bd060f  jmp 0x00007E6BC8BCF3A6
00007e6bc8bd0614  call 0x00007E6BC8AC0370
00007e6bc8bd0619  jmp 0x00007E6BC8BCF3D4
00007e6bc8bd061e  call 0x00007E6BC8ABF100
00007e6bc8bd0623  jmp 0x00007E6BC8BCF3DD
00007e6bc8bd0628  call 0x00007E6BC8AC0370
00007e6bc8bd062d  jmp 0x00007E6BC8BCF43B
00007e6bc8bd0632  call 0x00007E6BC8ABF100
00007e6bc8bd0637  jmp 0x00007E6BC8BCF444
00007e6bc8bd063c  call 0x00007E6BC8AC0370
00007e6bc8bd0641  jmp 0x00007E6BC8BCF48B
00007e6bc8bd0646  call 0x00007E6BC8ABF100
00007e6bc8bd064b  jmp 0x00007E6BC8BCF494
00007e6bc8bd0650  call 0x00007E6BC8A0B720
00007e6bc8bd0655  jmp 0x00007E6BC8BCF4D7
00007e6bc8bd065a  call 0x00007E6BC8AB47C0
00007e6bc8bd065f  jmp 0x00007E6BC8BCF4EA
00007e6bc8bd0664  call 0x00007E6BC8A08B00
00007e6bc8bd0669  jmp 0x00007E6BC8BCF501
00007e6bc8bd066e  call 0x00007E6BC89FF430
00007e6bc8bd0673  jmp 0x00007E6BC8BCF514
00007e6bc8bd0678  call 0x00007E6BC89FF430
00007e6bc8bd067d  jmp 0x00007E6BC8BCF527
00007e6bc8bd0682  sub rsp, 0x08
00007e6bc8bd0686  push rax
00007e6bc8bd0687  push rcx
00007e6bc8bd0688  push rdx
00007e6bc8bd0689  push rdi
00007e6bc8bd068a  push rsi
00007e6bc8bd068b  push r8
00007e6bc8bd068d  push r9
00007e6bc8bd068f  push r10
00007e6bc8bd0691  push r11
00007e6bc8bd0693  sub rsp, 0xF0
00007e6bc8bd069a  vmovaps [rsp], xmm0
00007e6bc8bd069f  vmovaps [rsp+0x10], xmm2
00007e6bc8bd06a5  vmovaps [rsp+0x20], xmm3
00007e6bc8bd06ab  vmovaps [rsp+0x30], xmm4
00007e6bc8bd06b1  vmovaps [rsp+0x40], xmm5
00007e6bc8bd06b7  vmovaps [rsp+0x50], xmm6
00007e6bc8bd06bd  vmovaps [rsp+0x60], xmm7
00007e6bc8bd06c3  vmovaps [rsp+0x70], xmm8
00007e6bc8bd06c9  vmovaps [rsp+0x80], xmm9
00007e6bc8bd06d2  vmovaps [rsp+0x90], xmm10
00007e6bc8bd06db  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd06e4  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd06ed  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd06f6  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd06ff  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd0708  sub rsp, 0x30
00007e6bc8bd070c  movaps [rsp], xmm1
00007e6bc8bd0710  movaps [rsp+0x10], xmm15
00007e6bc8bd0716  movaps [rsp+0x20], xmm14
00007e6bc8bd071c  lea rdi, [rsp]
00007e6bc8bd0720  mov esi, 0x00
00007e6bc8bd0725  mov rax, 0x6543F191D530
00007e6bc8bd072f  call rax
00007e6bc8bd0731  movaps xmm1, [rsp]
00007e6bc8bd0735  add rsp, 0x30
00007e6bc8bd0739  vmovaps xmm0, [rsp]
00007e6bc8bd073e  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd0744  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd074a  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd0750  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd0756  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd075c  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd0762  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd0768  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd0771  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd077a  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd0783  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd078c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd0795  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd079e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd07a7  add rsp, 0xF0
00007e6bc8bd07ae  pop r11
00007e6bc8bd07b0  pop r10
00007e6bc8bd07b2  pop r9
00007e6bc8bd07b4  pop r8
00007e6bc8bd07b6  pop rsi
00007e6bc8bd07b7  pop rdi
00007e6bc8bd07b8  pop rdx
00007e6bc8bd07b9  pop rcx
00007e6bc8bd07ba  pop rax
00007e6bc8bd07bb  add rsp, 0x08
00007e6bc8bd07bf  jmp 0x00007E6BC8BCF581
00007e6bc8bd07c4  sub rsp, 0x08
00007e6bc8bd07c8  push rax
00007e6bc8bd07c9  push rcx
00007e6bc8bd07ca  push rdx
00007e6bc8bd07cb  push rdi
00007e6bc8bd07cc  push rsi
00007e6bc8bd07cd  push r8
00007e6bc8bd07cf  push r9
00007e6bc8bd07d1  push r10
00007e6bc8bd07d3  push r11
00007e6bc8bd07d5  sub rsp, 0xF0
00007e6bc8bd07dc  vmovaps [rsp], xmm0
00007e6bc8bd07e1  vmovaps [rsp+0x10], xmm1
00007e6bc8bd07e7  vmovaps [rsp+0x20], xmm2
00007e6bc8bd07ed  vmovaps [rsp+0x30], xmm3
00007e6bc8bd07f3  vmovaps [rsp+0x40], xmm4
00007e6bc8bd07f9  vmovaps [rsp+0x50], xmm5
00007e6bc8bd07ff  vmovaps [rsp+0x60], xmm6
00007e6bc8bd0805  vmovaps [rsp+0x70], xmm7
00007e6bc8bd080b  vmovaps [rsp+0x80], xmm8
00007e6bc8bd0814  vmovaps [rsp+0x90], xmm9
00007e6bc8bd081d  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd0826  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd082f  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd0838  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd0841  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd084a  sub rsp, 0x30
00007e6bc8bd084e  movaps [rsp], xmm13
00007e6bc8bd0853  movaps [rsp+0x10], xmm1
00007e6bc8bd0858  movaps [rsp+0x20], xmm14
00007e6bc8bd085e  lea rdi, [rsp]
00007e6bc8bd0862  mov esi, 0x00
00007e6bc8bd0867  mov rax, 0x6543F191D530
00007e6bc8bd0871  call rax
00007e6bc8bd0873  movaps xmm13, [rsp]
00007e6bc8bd0878  add rsp, 0x30
00007e6bc8bd087c  vmovaps xmm0, [rsp]
00007e6bc8bd0881  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd0887  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd088d  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd0893  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd0899  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd089f  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd08a5  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd08ab  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd08b4  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd08bd  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd08c6  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd08cf  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd08d8  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd08e1  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd08ea  add rsp, 0xF0
00007e6bc8bd08f1  pop r11
00007e6bc8bd08f3  pop r10
00007e6bc8bd08f5  pop r9
00007e6bc8bd08f7  pop r8
00007e6bc8bd08f9  pop rsi
00007e6bc8bd08fa  pop rdi
00007e6bc8bd08fb  pop rdx
00007e6bc8bd08fc  pop rcx
00007e6bc8bd08fd  pop rax
00007e6bc8bd08fe  add rsp, 0x08
00007e6bc8bd0902  jmp 0x00007E6BC8BCF5CF
00007e6bc8bd0907  sub rsp, 0x08
00007e6bc8bd090b  push rax
00007e6bc8bd090c  push rcx
00007e6bc8bd090d  push rdx
00007e6bc8bd090e  push rdi
00007e6bc8bd090f  push rsi
00007e6bc8bd0910  push r8
00007e6bc8bd0912  push r9
00007e6bc8bd0914  push r10
00007e6bc8bd0916  push r11
00007e6bc8bd0918  sub rsp, 0xF0
00007e6bc8bd091f  vmovaps [rsp], xmm0
00007e6bc8bd0924  vmovaps [rsp+0x10], xmm1
00007e6bc8bd092a  vmovaps [rsp+0x20], xmm2
00007e6bc8bd0930  vmovaps [rsp+0x30], xmm3
00007e6bc8bd0936  vmovaps [rsp+0x40], xmm4
00007e6bc8bd093c  vmovaps [rsp+0x50], xmm5
00007e6bc8bd0942  vmovaps [rsp+0x60], xmm6
00007e6bc8bd0948  vmovaps [rsp+0x70], xmm7
00007e6bc8bd094e  vmovaps [rsp+0x80], xmm8
00007e6bc8bd0957  vmovaps [rsp+0x90], xmm9
00007e6bc8bd0960  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd0969  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd0972  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd097b  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd0984  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd098d  sub rsp, 0x30
00007e6bc8bd0991  movaps [rsp], xmm15
00007e6bc8bd0996  movaps [rsp+0x10], xmm14
00007e6bc8bd099c  movaps [rsp+0x20], xmm1
00007e6bc8bd09a1  lea rdi, [rsp]
00007e6bc8bd09a5  mov esi, 0x00
00007e6bc8bd09aa  mov rax, 0x6543F191D530
00007e6bc8bd09b4  call rax
00007e6bc8bd09b6  movaps xmm15, [rsp]
00007e6bc8bd09bb  add rsp, 0x30
00007e6bc8bd09bf  vmovaps xmm0, [rsp]
00007e6bc8bd09c4  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd09ca  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd09d0  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd09d6  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd09dc  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd09e2  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd09e8  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd09ee  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd09f7  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd0a00  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd0a09  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd0a12  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd0a1b  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd0a24  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd0a2d  add rsp, 0xF0
00007e6bc8bd0a34  pop r11
00007e6bc8bd0a36  pop r10
00007e6bc8bd0a38  pop r9
00007e6bc8bd0a3a  pop r8
00007e6bc8bd0a3c  pop rsi
00007e6bc8bd0a3d  pop rdi
00007e6bc8bd0a3e  pop rdx
00007e6bc8bd0a3f  pop rcx
00007e6bc8bd0a40  pop rax
00007e6bc8bd0a41  add rsp, 0x08
00007e6bc8bd0a45  jmp 0x00007E6BC8BCF617
00007e6bc8bd0a4a  sub rsp, 0x08
00007e6bc8bd0a4e  push rax
00007e6bc8bd0a4f  push rcx
00007e6bc8bd0a50  push rdx
00007e6bc8bd0a51  push rdi
00007e6bc8bd0a52  push rsi
00007e6bc8bd0a53  push r8
00007e6bc8bd0a55  push r9
00007e6bc8bd0a57  push r10
00007e6bc8bd0a59  push r11
00007e6bc8bd0a5b  sub rsp, 0xF0
00007e6bc8bd0a62  vmovaps [rsp], xmm0
00007e6bc8bd0a67  vmovaps [rsp+0x10], xmm2
00007e6bc8bd0a6d  vmovaps [rsp+0x20], xmm3
00007e6bc8bd0a73  vmovaps [rsp+0x30], xmm4
00007e6bc8bd0a79  vmovaps [rsp+0x40], xmm5
00007e6bc8bd0a7f  vmovaps [rsp+0x50], xmm6
00007e6bc8bd0a85  vmovaps [rsp+0x60], xmm7
00007e6bc8bd0a8b  vmovaps [rsp+0x70], xmm8
00007e6bc8bd0a91  vmovaps [rsp+0x80], xmm9
00007e6bc8bd0a9a  vmovaps [rsp+0x90], xmm10
00007e6bc8bd0aa3  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd0aac  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd0ab5  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd0abe  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd0ac7  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd0ad0  sub rsp, 0x30
00007e6bc8bd0ad4  movaps [rsp], xmm1
00007e6bc8bd0ad8  movaps [rsp+0x10], xmm14
00007e6bc8bd0ade  movaps [rsp+0x20], xmm10
00007e6bc8bd0ae4  lea rdi, [rsp]
00007e6bc8bd0ae8  mov esi, 0x00
00007e6bc8bd0aed  mov rax, 0x6543F191D530
00007e6bc8bd0af7  call rax
00007e6bc8bd0af9  movaps xmm1, [rsp]
00007e6bc8bd0afd  add rsp, 0x30
00007e6bc8bd0b01  vmovaps xmm0, [rsp]
00007e6bc8bd0b06  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd0b0c  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd0b12  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd0b18  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd0b1e  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd0b24  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd0b2a  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd0b30  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd0b39  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd0b42  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd0b4b  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd0b54  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd0b5d  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd0b66  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd0b6f  add rsp, 0xF0
00007e6bc8bd0b76  pop r11
00007e6bc8bd0b78  pop r10
00007e6bc8bd0b7a  pop r9
00007e6bc8bd0b7c  pop r8
00007e6bc8bd0b7e  pop rsi
00007e6bc8bd0b7f  pop rdi
00007e6bc8bd0b80  pop rdx
00007e6bc8bd0b81  pop rcx
00007e6bc8bd0b82  pop rax
00007e6bc8bd0b83  add rsp, 0x08
00007e6bc8bd0b87  jmp 0x00007E6BC8BCF631
00007e6bc8bd0b8c  sub rsp, 0x08
00007e6bc8bd0b90  push rax
00007e6bc8bd0b91  push rcx
00007e6bc8bd0b92  push rdx
00007e6bc8bd0b93  push rdi
00007e6bc8bd0b94  push rsi
00007e6bc8bd0b95  push r8
00007e6bc8bd0b97  push r9
00007e6bc8bd0b99  push r10
00007e6bc8bd0b9b  push r11
00007e6bc8bd0b9d  sub rsp, 0xF0
00007e6bc8bd0ba4  vmovaps [rsp], xmm0
00007e6bc8bd0ba9  vmovaps [rsp+0x10], xmm1
00007e6bc8bd0baf  vmovaps [rsp+0x20], xmm2
00007e6bc8bd0bb5  vmovaps [rsp+0x30], xmm3
00007e6bc8bd0bbb  vmovaps [rsp+0x40], xmm4
00007e6bc8bd0bc1  vmovaps [rsp+0x50], xmm5
00007e6bc8bd0bc7  vmovaps [rsp+0x60], xmm6
00007e6bc8bd0bcd  vmovaps [rsp+0x70], xmm7
00007e6bc8bd0bd3  vmovaps [rsp+0x80], xmm8
00007e6bc8bd0bdc  vmovaps [rsp+0x90], xmm9
00007e6bc8bd0be5  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd0bee  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd0bf7  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd0c00  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd0c09  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd0c12  sub rsp, 0x30
00007e6bc8bd0c16  movaps [rsp], xmm13
00007e6bc8bd0c1b  movaps [rsp+0x10], xmm14
00007e6bc8bd0c21  movaps [rsp+0x20], xmm2
00007e6bc8bd0c26  lea rdi, [rsp]
00007e6bc8bd0c2a  mov esi, 0x00
00007e6bc8bd0c2f  mov rax, 0x6543F191D530
00007e6bc8bd0c39  call rax
00007e6bc8bd0c3b  movaps xmm13, [rsp]
00007e6bc8bd0c40  add rsp, 0x30
00007e6bc8bd0c44  vmovaps xmm0, [rsp]
00007e6bc8bd0c49  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd0c4f  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd0c55  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd0c5b  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd0c61  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd0c67  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd0c6d  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd0c73  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd0c7c  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd0c85  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd0c8e  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd0c97  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd0ca0  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd0ca9  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd0cb2  add rsp, 0xF0
00007e6bc8bd0cb9  pop r11
00007e6bc8bd0cbb  pop r10
00007e6bc8bd0cbd  pop r9
00007e6bc8bd0cbf  pop r8
00007e6bc8bd0cc1  pop rsi
00007e6bc8bd0cc2  pop rdi
00007e6bc8bd0cc3  pop rdx
00007e6bc8bd0cc4  pop rcx
00007e6bc8bd0cc5  pop rax
00007e6bc8bd0cc6  add rsp, 0x08
00007e6bc8bd0cca  jmp 0x00007E6BC8BCF64C
00007e6bc8bd0ccf  sub rsp, 0x08
00007e6bc8bd0cd3  push rax
00007e6bc8bd0cd4  push rcx
00007e6bc8bd0cd5  push rdx
00007e6bc8bd0cd6  push rdi
00007e6bc8bd0cd7  push rsi
00007e6bc8bd0cd8  push r8
00007e6bc8bd0cda  push r9
00007e6bc8bd0cdc  push r10
00007e6bc8bd0cde  push r11
00007e6bc8bd0ce0  sub rsp, 0xF0
00007e6bc8bd0ce7  vmovaps [rsp], xmm0
00007e6bc8bd0cec  vmovaps [rsp+0x10], xmm2
00007e6bc8bd0cf2  vmovaps [rsp+0x20], xmm3
00007e6bc8bd0cf8  vmovaps [rsp+0x30], xmm4
00007e6bc8bd0cfe  vmovaps [rsp+0x40], xmm5
00007e6bc8bd0d04  vmovaps [rsp+0x50], xmm6
00007e6bc8bd0d0a  vmovaps [rsp+0x60], xmm7
00007e6bc8bd0d10  vmovaps [rsp+0x70], xmm8
00007e6bc8bd0d16  vmovaps [rsp+0x80], xmm9
00007e6bc8bd0d1f  vmovaps [rsp+0x90], xmm10
00007e6bc8bd0d28  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd0d31  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd0d3a  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd0d43  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd0d4c  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd0d55  sub rsp, 0x30
00007e6bc8bd0d59  movaps [rsp], xmm1
00007e6bc8bd0d5d  movaps [rsp+0x10], xmm10
00007e6bc8bd0d63  movaps [rsp+0x20], xmm2
00007e6bc8bd0d68  lea rdi, [rsp]
00007e6bc8bd0d6c  mov esi, 0x00
00007e6bc8bd0d71  mov rax, 0x6543F191D530
00007e6bc8bd0d7b  call rax
00007e6bc8bd0d7d  movaps xmm1, [rsp]
00007e6bc8bd0d81  add rsp, 0x30
00007e6bc8bd0d85  vmovaps xmm0, [rsp]
00007e6bc8bd0d8a  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd0d90  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd0d96  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd0d9c  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd0da2  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd0da8  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd0dae  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd0db4  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd0dbd  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd0dc6  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd0dcf  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd0dd8  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd0de1  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd0dea  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd0df3  add rsp, 0xF0
00007e6bc8bd0dfa  pop r11
00007e6bc8bd0dfc  pop r10
00007e6bc8bd0dfe  pop r9
00007e6bc8bd0e00  pop r8
00007e6bc8bd0e02  pop rsi
00007e6bc8bd0e03  pop rdi
00007e6bc8bd0e04  pop rdx
00007e6bc8bd0e05  pop rcx
00007e6bc8bd0e06  pop rax
00007e6bc8bd0e07  add rsp, 0x08
00007e6bc8bd0e0b  jmp 0x00007E6BC8BCF6B4
00007e6bc8bd0e10  sub rsp, 0x08
00007e6bc8bd0e14  push rax
00007e6bc8bd0e15  push rcx
00007e6bc8bd0e16  push rdx
00007e6bc8bd0e17  push rdi
00007e6bc8bd0e18  push rsi
00007e6bc8bd0e19  push r8
00007e6bc8bd0e1b  push r9
00007e6bc8bd0e1d  push r10
00007e6bc8bd0e1f  push r11
00007e6bc8bd0e21  sub rsp, 0xF0
00007e6bc8bd0e28  vmovaps [rsp], xmm0
00007e6bc8bd0e2d  vmovaps [rsp+0x10], xmm1
00007e6bc8bd0e33  vmovaps [rsp+0x20], xmm2
00007e6bc8bd0e39  vmovaps [rsp+0x30], xmm3
00007e6bc8bd0e3f  vmovaps [rsp+0x40], xmm4
00007e6bc8bd0e45  vmovaps [rsp+0x50], xmm5
00007e6bc8bd0e4b  vmovaps [rsp+0x60], xmm6
00007e6bc8bd0e51  vmovaps [rsp+0x70], xmm7
00007e6bc8bd0e57  vmovaps [rsp+0x80], xmm8
00007e6bc8bd0e60  vmovaps [rsp+0x90], xmm9
00007e6bc8bd0e69  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd0e72  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd0e7b  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd0e84  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd0e8d  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd0e96  sub rsp, 0x30
00007e6bc8bd0e9a  movaps [rsp], xmm15
00007e6bc8bd0e9f  movaps [rsp+0x10], xmm10
00007e6bc8bd0ea5  movaps [rsp+0x20], xmm2
00007e6bc8bd0eaa  lea rdi, [rsp]
00007e6bc8bd0eae  mov esi, 0x00
00007e6bc8bd0eb3  mov rax, 0x6543F191D530
00007e6bc8bd0ebd  call rax
00007e6bc8bd0ebf  movaps xmm15, [rsp]
00007e6bc8bd0ec4  add rsp, 0x30
00007e6bc8bd0ec8  vmovaps xmm0, [rsp]
00007e6bc8bd0ecd  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd0ed3  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd0ed9  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd0edf  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd0ee5  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd0eeb  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd0ef1  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd0ef7  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd0f00  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd0f09  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd0f12  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd0f1b  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd0f24  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd0f2d  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd0f36  add rsp, 0xF0
00007e6bc8bd0f3d  pop r11
00007e6bc8bd0f3f  pop r10
00007e6bc8bd0f41  pop r9
00007e6bc8bd0f43  pop r8
00007e6bc8bd0f45  pop rsi
00007e6bc8bd0f46  pop rdi
00007e6bc8bd0f47  pop rdx
00007e6bc8bd0f48  pop rcx
00007e6bc8bd0f49  pop rax
00007e6bc8bd0f4a  add rsp, 0x08
00007e6bc8bd0f4e  jmp 0x00007E6BC8BCF706
00007e6bc8bd0f53  sub rsp, 0x08
00007e6bc8bd0f57  push rax
00007e6bc8bd0f58  push rcx
00007e6bc8bd0f59  push rdx
00007e6bc8bd0f5a  push rdi
00007e6bc8bd0f5b  push rsi
00007e6bc8bd0f5c  push r8
00007e6bc8bd0f5e  push r9
00007e6bc8bd0f60  push r10
00007e6bc8bd0f62  push r11
00007e6bc8bd0f64  sub rsp, 0xF0
00007e6bc8bd0f6b  vmovaps [rsp], xmm0
00007e6bc8bd0f70  vmovaps [rsp+0x10], xmm2
00007e6bc8bd0f76  vmovaps [rsp+0x20], xmm3
00007e6bc8bd0f7c  vmovaps [rsp+0x30], xmm4
00007e6bc8bd0f82  vmovaps [rsp+0x40], xmm5
00007e6bc8bd0f88  vmovaps [rsp+0x50], xmm6
00007e6bc8bd0f8e  vmovaps [rsp+0x60], xmm7
00007e6bc8bd0f94  vmovaps [rsp+0x70], xmm8
00007e6bc8bd0f9a  vmovaps [rsp+0x80], xmm9
00007e6bc8bd0fa3  vmovaps [rsp+0x90], xmm10
00007e6bc8bd0fac  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd0fb5  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd0fbe  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd0fc7  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd0fd0  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd0fd9  sub rsp, 0x30
00007e6bc8bd0fdd  movaps [rsp], xmm1
00007e6bc8bd0fe1  movaps [rsp+0x10], xmm10
00007e6bc8bd0fe7  movaps [rsp+0x20], xmm12
00007e6bc8bd0fed  lea rdi, [rsp]
00007e6bc8bd0ff1  mov esi, 0x00
00007e6bc8bd0ff6  mov rax, 0x6543F191D530
00007e6bc8bd1000  call rax
00007e6bc8bd1002  movaps xmm1, [rsp]
00007e6bc8bd1006  add rsp, 0x30
00007e6bc8bd100a  vmovaps xmm0, [rsp]
00007e6bc8bd100f  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd1015  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd101b  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd1021  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd1027  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd102d  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd1033  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd1039  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd1042  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd104b  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd1054  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd105d  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd1066  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd106f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd1078  add rsp, 0xF0
00007e6bc8bd107f  pop r11
00007e6bc8bd1081  pop r10
00007e6bc8bd1083  pop r9
00007e6bc8bd1085  pop r8
00007e6bc8bd1087  pop rsi
00007e6bc8bd1088  pop rdi
00007e6bc8bd1089  pop rdx
00007e6bc8bd108a  pop rcx
00007e6bc8bd108b  pop rax
00007e6bc8bd108c  add rsp, 0x08
00007e6bc8bd1090  jmp 0x00007E6BC8BCF732
00007e6bc8bd1095  sub rsp, 0x08
00007e6bc8bd1099  push rax
00007e6bc8bd109a  push rcx
00007e6bc8bd109b  push rdx
00007e6bc8bd109c  push rdi
00007e6bc8bd109d  push rsi
00007e6bc8bd109e  push r8
00007e6bc8bd10a0  push r9
00007e6bc8bd10a2  push r10
00007e6bc8bd10a4  push r11
00007e6bc8bd10a6  sub rsp, 0xF0
00007e6bc8bd10ad  vmovaps [rsp], xmm0
00007e6bc8bd10b2  vmovaps [rsp+0x10], xmm1
00007e6bc8bd10b8  vmovaps [rsp+0x20], xmm2
00007e6bc8bd10be  vmovaps [rsp+0x30], xmm3
00007e6bc8bd10c4  vmovaps [rsp+0x40], xmm4
00007e6bc8bd10ca  vmovaps [rsp+0x50], xmm5
00007e6bc8bd10d0  vmovaps [rsp+0x60], xmm6
00007e6bc8bd10d6  vmovaps [rsp+0x70], xmm7
00007e6bc8bd10dc  vmovaps [rsp+0x80], xmm8
00007e6bc8bd10e5  vmovaps [rsp+0x90], xmm9
00007e6bc8bd10ee  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd10f7  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd1100  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd1109  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd1112  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd111b  sub rsp, 0x30
00007e6bc8bd111f  movaps [rsp], xmm15
00007e6bc8bd1124  movaps [rsp+0x10], xmm10
00007e6bc8bd112a  movaps [rsp+0x20], xmm12
00007e6bc8bd1130  lea rdi, [rsp]
00007e6bc8bd1134  mov esi, 0x00
00007e6bc8bd1139  mov rax, 0x6543F191D530
00007e6bc8bd1143  call rax
00007e6bc8bd1145  movaps xmm15, [rsp]
00007e6bc8bd114a  add rsp, 0x30
00007e6bc8bd114e  vmovaps xmm0, [rsp]
00007e6bc8bd1153  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd1159  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd115f  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd1165  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd116b  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd1171  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd1177  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd117d  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd1186  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd118f  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd1198  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd11a1  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd11aa  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd11b3  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd11bc  add rsp, 0xF0
00007e6bc8bd11c3  pop r11
00007e6bc8bd11c5  pop r10
00007e6bc8bd11c7  pop r9
00007e6bc8bd11c9  pop r8
00007e6bc8bd11cb  pop rsi
00007e6bc8bd11cc  pop rdi
00007e6bc8bd11cd  pop rdx
00007e6bc8bd11ce  pop rcx
00007e6bc8bd11cf  pop rax
00007e6bc8bd11d0  add rsp, 0x08
00007e6bc8bd11d4  jmp 0x00007E6BC8BCF75E
00007e6bc8bd11d9  call 0x00007E6BC89FF430
00007e6bc8bd11de  jmp 0x00007E6BC8BCF7EE
00007e6bc8bd11e3  call 0x00007E6BC89FF430
00007e6bc8bd11e8  jmp 0x00007E6BC8BCF801
00007e6bc8bd11ed  sub rsp, 0x08
00007e6bc8bd11f1  push rax
00007e6bc8bd11f2  push rcx
00007e6bc8bd11f3  push rdx
00007e6bc8bd11f4  push rdi
00007e6bc8bd11f5  push rsi
00007e6bc8bd11f6  push r8
00007e6bc8bd11f8  push r9
00007e6bc8bd11fa  push r10
00007e6bc8bd11fc  push r11
00007e6bc8bd11fe  sub rsp, 0xF0
00007e6bc8bd1205  vmovaps [rsp], xmm0
00007e6bc8bd120a  vmovaps [rsp+0x10], xmm2
00007e6bc8bd1210  vmovaps [rsp+0x20], xmm3
00007e6bc8bd1216  vmovaps [rsp+0x30], xmm4
00007e6bc8bd121c  vmovaps [rsp+0x40], xmm5
00007e6bc8bd1222  vmovaps [rsp+0x50], xmm6
00007e6bc8bd1228  vmovaps [rsp+0x60], xmm7
00007e6bc8bd122e  vmovaps [rsp+0x70], xmm8
00007e6bc8bd1234  vmovaps [rsp+0x80], xmm9
00007e6bc8bd123d  vmovaps [rsp+0x90], xmm10
00007e6bc8bd1246  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd124f  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd1258  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd1261  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd126a  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd1273  sub rsp, 0x30
00007e6bc8bd1277  movaps [rsp], xmm1
00007e6bc8bd127b  movaps [rsp+0x10], xmm13
00007e6bc8bd1281  movaps [rsp+0x20], xmm2
00007e6bc8bd1286  lea rdi, [rsp]
00007e6bc8bd128a  mov esi, 0x00
00007e6bc8bd128f  mov rax, 0x6543F191D530
00007e6bc8bd1299  call rax
00007e6bc8bd129b  movaps xmm1, [rsp]
00007e6bc8bd129f  add rsp, 0x30
00007e6bc8bd12a3  vmovaps xmm0, [rsp]
00007e6bc8bd12a8  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd12ae  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd12b4  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd12ba  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd12c0  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd12c6  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd12cc  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd12d2  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd12db  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd12e4  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd12ed  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd12f6  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd12ff  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd1308  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd1311  add rsp, 0xF0
00007e6bc8bd1318  pop r11
00007e6bc8bd131a  pop r10
00007e6bc8bd131c  pop r9
00007e6bc8bd131e  pop r8
00007e6bc8bd1320  pop rsi
00007e6bc8bd1321  pop rdi
00007e6bc8bd1322  pop rdx
00007e6bc8bd1323  pop rcx
00007e6bc8bd1324  pop rax
00007e6bc8bd1325  add rsp, 0x08
00007e6bc8bd1329  jmp 0x00007E6BC8BCF82C
00007e6bc8bd132e  call 0x00007E6BC8A0E760
00007e6bc8bd1333  jmp 0x00007E6BC8BCF839
00007e6bc8bd1338  sub rsp, 0x08
00007e6bc8bd133c  push rax
00007e6bc8bd133d  push rcx
00007e6bc8bd133e  push rdx
00007e6bc8bd133f  push rdi
00007e6bc8bd1340  push rsi
00007e6bc8bd1341  push r8
00007e6bc8bd1343  push r9
00007e6bc8bd1345  push r10
00007e6bc8bd1347  push r11
00007e6bc8bd1349  sub rsp, 0xF0
00007e6bc8bd1350  vmovaps [rsp], xmm0
00007e6bc8bd1355  vmovaps [rsp+0x10], xmm1
00007e6bc8bd135b  vmovaps [rsp+0x20], xmm2
00007e6bc8bd1361  vmovaps [rsp+0x30], xmm3
00007e6bc8bd1367  vmovaps [rsp+0x40], xmm4
00007e6bc8bd136d  vmovaps [rsp+0x50], xmm5
00007e6bc8bd1373  vmovaps [rsp+0x60], xmm6
00007e6bc8bd1379  vmovaps [rsp+0x70], xmm7
00007e6bc8bd137f  vmovaps [rsp+0x80], xmm8
00007e6bc8bd1388  vmovaps [rsp+0x90], xmm9
00007e6bc8bd1391  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd139a  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd13a3  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd13ac  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd13b5  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd13be  sub rsp, 0x30
00007e6bc8bd13c2  movaps [rsp], xmm13
00007e6bc8bd13c7  movaps [rsp+0x10], xmm2
00007e6bc8bd13cc  movaps [rsp+0x20], xmm1
00007e6bc8bd13d1  lea rdi, [rsp]
00007e6bc8bd13d5  mov esi, 0x00
00007e6bc8bd13da  mov rax, 0x6543F191D530
00007e6bc8bd13e4  call rax
00007e6bc8bd13e6  movaps xmm13, [rsp]
00007e6bc8bd13eb  add rsp, 0x30
00007e6bc8bd13ef  vmovaps xmm0, [rsp]
00007e6bc8bd13f4  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd13fa  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd1400  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd1406  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd140c  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd1412  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd1418  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd141e  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd1427  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd1430  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd1439  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd1442  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd144b  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd1454  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd145d  add rsp, 0xF0
00007e6bc8bd1464  pop r11
00007e6bc8bd1466  pop r10
00007e6bc8bd1468  pop r9
00007e6bc8bd146a  pop r8
00007e6bc8bd146c  pop rsi
00007e6bc8bd146d  pop rdi
00007e6bc8bd146e  pop rdx
00007e6bc8bd146f  pop rcx
00007e6bc8bd1470  pop rax
00007e6bc8bd1471  add rsp, 0x08
00007e6bc8bd1475  jmp 0x00007E6BC8BCF878
00007e6bc8bd147a  sub rsp, 0x08
00007e6bc8bd147e  push rax
00007e6bc8bd147f  push rcx
00007e6bc8bd1480  push rdx
00007e6bc8bd1481  push rdi
00007e6bc8bd1482  push rsi
00007e6bc8bd1483  push r8
00007e6bc8bd1485  push r9
00007e6bc8bd1487  push r10
00007e6bc8bd1489  push r11
00007e6bc8bd148b  sub rsp, 0xF0
00007e6bc8bd1492  vmovaps [rsp], xmm0
00007e6bc8bd1497  vmovaps [rsp+0x10], xmm2
00007e6bc8bd149d  vmovaps [rsp+0x20], xmm3
00007e6bc8bd14a3  vmovaps [rsp+0x30], xmm4
00007e6bc8bd14a9  vmovaps [rsp+0x40], xmm5
00007e6bc8bd14af  vmovaps [rsp+0x50], xmm6
00007e6bc8bd14b5  vmovaps [rsp+0x60], xmm7
00007e6bc8bd14bb  vmovaps [rsp+0x70], xmm8
00007e6bc8bd14c1  vmovaps [rsp+0x80], xmm9
00007e6bc8bd14ca  vmovaps [rsp+0x90], xmm10
00007e6bc8bd14d3  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd14dc  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd14e5  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd14ee  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd14f7  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd1500  sub rsp, 0x30
00007e6bc8bd1504  movaps [rsp], xmm1
00007e6bc8bd1508  movaps [rsp+0x10], xmm15
00007e6bc8bd150e  movaps [rsp+0x20], xmm2
00007e6bc8bd1513  lea rdi, [rsp]
00007e6bc8bd1517  mov esi, 0x00
00007e6bc8bd151c  mov rax, 0x6543F191D530
00007e6bc8bd1526  call rax
00007e6bc8bd1528  movaps xmm1, [rsp]
00007e6bc8bd152c  add rsp, 0x30
00007e6bc8bd1530  vmovaps xmm0, [rsp]
00007e6bc8bd1535  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd153b  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd1541  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd1547  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd154d  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd1553  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd1559  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd155f  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd1568  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd1571  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd157a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd1583  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd158c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd1595  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd159e  add rsp, 0xF0
00007e6bc8bd15a5  pop r11
00007e6bc8bd15a7  pop r10
00007e6bc8bd15a9  pop r9
00007e6bc8bd15ab  pop r8
00007e6bc8bd15ad  pop rsi
00007e6bc8bd15ae  pop rdi
00007e6bc8bd15af  pop rdx
00007e6bc8bd15b0  pop rcx
00007e6bc8bd15b1  pop rax
00007e6bc8bd15b2  add rsp, 0x08
00007e6bc8bd15b6  jmp 0x00007E6BC8BCF8AC
00007e6bc8bd15bb  sub rsp, 0x08
00007e6bc8bd15bf  push rax
00007e6bc8bd15c0  push rcx
00007e6bc8bd15c1  push rdx
00007e6bc8bd15c2  push rdi
00007e6bc8bd15c3  push rsi
00007e6bc8bd15c4  push r8
00007e6bc8bd15c6  push r9
00007e6bc8bd15c8  push r10
00007e6bc8bd15ca  push r11
00007e6bc8bd15cc  sub rsp, 0xF0
00007e6bc8bd15d3  vmovaps [rsp], xmm0
00007e6bc8bd15d8  vmovaps [rsp+0x10], xmm1
00007e6bc8bd15de  vmovaps [rsp+0x20], xmm2
00007e6bc8bd15e4  vmovaps [rsp+0x30], xmm3
00007e6bc8bd15ea  vmovaps [rsp+0x40], xmm4
00007e6bc8bd15f0  vmovaps [rsp+0x50], xmm5
00007e6bc8bd15f6  vmovaps [rsp+0x60], xmm6
00007e6bc8bd15fc  vmovaps [rsp+0x70], xmm7
00007e6bc8bd1602  vmovaps [rsp+0x80], xmm8
00007e6bc8bd160b  vmovaps [rsp+0x90], xmm9
00007e6bc8bd1614  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd161d  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd1626  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd162f  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd1638  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd1641  sub rsp, 0x30
00007e6bc8bd1645  movaps [rsp], xmm14
00007e6bc8bd164a  movaps [rsp+0x10], xmm2
00007e6bc8bd164f  movaps [rsp+0x20], xmm15
00007e6bc8bd1655  lea rdi, [rsp]
00007e6bc8bd1659  mov esi, 0x00
00007e6bc8bd165e  mov rax, 0x6543F191D530
00007e6bc8bd1668  call rax
00007e6bc8bd166a  movaps xmm14, [rsp]
00007e6bc8bd166f  add rsp, 0x30
00007e6bc8bd1673  vmovaps xmm0, [rsp]
00007e6bc8bd1678  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd167e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd1684  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd168a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd1690  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd1696  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd169c  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd16a2  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd16ab  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd16b4  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd16bd  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd16c6  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd16cf  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd16d8  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd16e1  add rsp, 0xF0
00007e6bc8bd16e8  pop r11
00007e6bc8bd16ea  pop r10
00007e6bc8bd16ec  pop r9
00007e6bc8bd16ee  pop r8
00007e6bc8bd16f0  pop rsi
00007e6bc8bd16f1  pop rdi
00007e6bc8bd16f2  pop rdx
00007e6bc8bd16f3  pop rcx
00007e6bc8bd16f4  pop rax
00007e6bc8bd16f5  add rsp, 0x08
00007e6bc8bd16f9  jmp 0x00007E6BC8BCF8E7
00007e6bc8bd16fe  sub rsp, 0x08
00007e6bc8bd1702  push rax
00007e6bc8bd1703  push rcx
00007e6bc8bd1704  push rdx
00007e6bc8bd1705  push rdi
00007e6bc8bd1706  push rsi
00007e6bc8bd1707  push r8
00007e6bc8bd1709  push r9
00007e6bc8bd170b  push r10
00007e6bc8bd170d  push r11
00007e6bc8bd170f  sub rsp, 0xF0
00007e6bc8bd1716  vmovaps [rsp], xmm0
00007e6bc8bd171b  vmovaps [rsp+0x10], xmm1
00007e6bc8bd1721  vmovaps [rsp+0x20], xmm2
00007e6bc8bd1727  vmovaps [rsp+0x30], xmm3
00007e6bc8bd172d  vmovaps [rsp+0x40], xmm4
00007e6bc8bd1733  vmovaps [rsp+0x50], xmm5
00007e6bc8bd1739  vmovaps [rsp+0x60], xmm6
00007e6bc8bd173f  vmovaps [rsp+0x70], xmm7
00007e6bc8bd1745  vmovaps [rsp+0x80], xmm8
00007e6bc8bd174e  vmovaps [rsp+0x90], xmm9
00007e6bc8bd1757  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd1760  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd1769  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd1772  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd177b  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd1784  sub rsp, 0x30
00007e6bc8bd1788  movaps [rsp], xmm15
00007e6bc8bd178d  movaps [rsp+0x10], xmm2
00007e6bc8bd1792  movaps [rsp+0x20], xmm1
00007e6bc8bd1797  lea rdi, [rsp]
00007e6bc8bd179b  mov esi, 0x00
00007e6bc8bd17a0  mov rax, 0x6543F191D530
00007e6bc8bd17aa  call rax
00007e6bc8bd17ac  movaps xmm15, [rsp]
00007e6bc8bd17b1  add rsp, 0x30
00007e6bc8bd17b5  vmovaps xmm0, [rsp]
00007e6bc8bd17ba  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd17c0  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd17c6  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd17cc  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd17d2  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd17d8  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd17de  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd17e4  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd17ed  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd17f6  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd17ff  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd1808  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd1811  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd181a  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd1823  add rsp, 0xF0
00007e6bc8bd182a  pop r11
00007e6bc8bd182c  pop r10
00007e6bc8bd182e  pop r9
00007e6bc8bd1830  pop r8
00007e6bc8bd1832  pop rsi
00007e6bc8bd1833  pop rdi
00007e6bc8bd1834  pop rdx
00007e6bc8bd1835  pop rcx
00007e6bc8bd1836  pop rax
00007e6bc8bd1837  add rsp, 0x08
00007e6bc8bd183b  jmp 0x00007E6BC8BCF923
00007e6bc8bd1840  call 0x00007E6BC89FF430
00007e6bc8bd1845  jmp 0x00007E6BC8BCF930
00007e6bc8bd184a  sub rsp, 0x08
00007e6bc8bd184e  push rax
00007e6bc8bd184f  push rcx
00007e6bc8bd1850  push rdx
00007e6bc8bd1851  push rdi
00007e6bc8bd1852  push rsi
00007e6bc8bd1853  push r8
00007e6bc8bd1855  push r9
00007e6bc8bd1857  push r10
00007e6bc8bd1859  push r11
00007e6bc8bd185b  sub rsp, 0xF0
00007e6bc8bd1862  vmovaps [rsp], xmm0
00007e6bc8bd1867  vmovaps [rsp+0x10], xmm1
00007e6bc8bd186d  vmovaps [rsp+0x20], xmm3
00007e6bc8bd1873  vmovaps [rsp+0x30], xmm4
00007e6bc8bd1879  vmovaps [rsp+0x40], xmm5
00007e6bc8bd187f  vmovaps [rsp+0x50], xmm6
00007e6bc8bd1885  vmovaps [rsp+0x60], xmm7
00007e6bc8bd188b  vmovaps [rsp+0x70], xmm8
00007e6bc8bd1891  vmovaps [rsp+0x80], xmm9
00007e6bc8bd189a  vmovaps [rsp+0x90], xmm10
00007e6bc8bd18a3  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd18ac  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd18b5  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd18be  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd18c7  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd18d0  sub rsp, 0x30
00007e6bc8bd18d4  movaps [rsp], xmm2
00007e6bc8bd18d8  movaps [rsp+0x10], xmm1
00007e6bc8bd18dd  movaps [rsp+0x20], xmm14
00007e6bc8bd18e3  lea rdi, [rsp]
00007e6bc8bd18e7  mov esi, 0x00
00007e6bc8bd18ec  mov rax, 0x6543F191D530
00007e6bc8bd18f6  call rax
00007e6bc8bd18f8  movaps xmm2, [rsp]
00007e6bc8bd18fc  add rsp, 0x30
00007e6bc8bd1900  vmovaps xmm0, [rsp]
00007e6bc8bd1905  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd190b  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd1911  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd1917  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd191d  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd1923  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd1929  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd192f  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd1938  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd1941  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd194a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd1953  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd195c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd1965  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd196e  add rsp, 0xF0
00007e6bc8bd1975  pop r11
00007e6bc8bd1977  pop r10
00007e6bc8bd1979  pop r9
00007e6bc8bd197b  pop r8
00007e6bc8bd197d  pop rsi
00007e6bc8bd197e  pop rdi
00007e6bc8bd197f  pop rdx
00007e6bc8bd1980  pop rcx
00007e6bc8bd1981  pop rax
00007e6bc8bd1982  add rsp, 0x08
00007e6bc8bd1986  jmp 0x00007E6BC8BCF96D
00007e6bc8bd198b  sub rsp, 0x08
00007e6bc8bd198f  push rax
00007e6bc8bd1990  push rcx
00007e6bc8bd1991  push rdx
00007e6bc8bd1992  push rdi
00007e6bc8bd1993  push rsi
00007e6bc8bd1994  push r8
00007e6bc8bd1996  push r9
00007e6bc8bd1998  push r10
00007e6bc8bd199a  push r11
00007e6bc8bd199c  sub rsp, 0xF0
00007e6bc8bd19a3  vmovaps [rsp], xmm0
00007e6bc8bd19a8  vmovaps [rsp+0x10], xmm1
00007e6bc8bd19ae  vmovaps [rsp+0x20], xmm2
00007e6bc8bd19b4  vmovaps [rsp+0x30], xmm3
00007e6bc8bd19ba  vmovaps [rsp+0x40], xmm4
00007e6bc8bd19c0  vmovaps [rsp+0x50], xmm5
00007e6bc8bd19c6  vmovaps [rsp+0x60], xmm6
00007e6bc8bd19cc  vmovaps [rsp+0x70], xmm7
00007e6bc8bd19d2  vmovaps [rsp+0x80], xmm8
00007e6bc8bd19db  vmovaps [rsp+0x90], xmm9
00007e6bc8bd19e4  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd19ed  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd19f6  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd19ff  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd1a08  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd1a11  sub rsp, 0x30
00007e6bc8bd1a15  movaps [rsp], xmm15
00007e6bc8bd1a1a  movaps [rsp+0x10], xmm14
00007e6bc8bd1a20  movaps [rsp+0x20], xmm1
00007e6bc8bd1a25  lea rdi, [rsp]
00007e6bc8bd1a29  mov esi, 0x00
00007e6bc8bd1a2e  mov rax, 0x6543F191D530
00007e6bc8bd1a38  call rax
00007e6bc8bd1a3a  movaps xmm15, [rsp]
00007e6bc8bd1a3f  add rsp, 0x30
00007e6bc8bd1a43  vmovaps xmm0, [rsp]
00007e6bc8bd1a48  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd1a4e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd1a54  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd1a5a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd1a60  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd1a66  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd1a6c  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd1a72  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd1a7b  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd1a84  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd1a8d  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd1a96  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd1a9f  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd1aa8  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd1ab1  add rsp, 0xF0
00007e6bc8bd1ab8  pop r11
00007e6bc8bd1aba  pop r10
00007e6bc8bd1abc  pop r9
00007e6bc8bd1abe  pop r8
00007e6bc8bd1ac0  pop rsi
00007e6bc8bd1ac1  pop rdi
00007e6bc8bd1ac2  pop rdx
00007e6bc8bd1ac3  pop rcx
00007e6bc8bd1ac4  pop rax
00007e6bc8bd1ac5  add rsp, 0x08
00007e6bc8bd1ac9  jmp 0x00007E6BC8BCF9E7
00007e6bc8bd1ace  call 0x00007E6BC89FF430
00007e6bc8bd1ad3  jmp 0x00007E6BC8BCF9F4
00007e6bc8bd1ad8  sub rsp, 0x08
00007e6bc8bd1adc  push rax
00007e6bc8bd1add  push rcx
00007e6bc8bd1ade  push rdx
00007e6bc8bd1adf  push rdi
00007e6bc8bd1ae0  push rsi
00007e6bc8bd1ae1  push r8
00007e6bc8bd1ae3  push r9
00007e6bc8bd1ae5  push r10
00007e6bc8bd1ae7  push r11
00007e6bc8bd1ae9  sub rsp, 0xF0
00007e6bc8bd1af0  vmovaps [rsp], xmm0
00007e6bc8bd1af5  vmovaps [rsp+0x10], xmm1
00007e6bc8bd1afb  vmovaps [rsp+0x20], xmm2
00007e6bc8bd1b01  vmovaps [rsp+0x30], xmm3
00007e6bc8bd1b07  vmovaps [rsp+0x40], xmm4
00007e6bc8bd1b0d  vmovaps [rsp+0x50], xmm5
00007e6bc8bd1b13  vmovaps [rsp+0x60], xmm6
00007e6bc8bd1b19  vmovaps [rsp+0x70], xmm7
00007e6bc8bd1b1f  vmovaps [rsp+0x80], xmm8
00007e6bc8bd1b28  vmovaps [rsp+0x90], xmm9
00007e6bc8bd1b31  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd1b3a  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd1b43  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd1b4c  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd1b55  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd1b5e  sub rsp, 0x30
00007e6bc8bd1b62  movaps [rsp], xmm14
00007e6bc8bd1b67  movaps [rsp+0x10], xmm13
00007e6bc8bd1b6d  movaps [rsp+0x20], xmm1
00007e6bc8bd1b72  lea rdi, [rsp]
00007e6bc8bd1b76  mov esi, 0x00
00007e6bc8bd1b7b  mov rax, 0x6543F191D530
00007e6bc8bd1b85  call rax
00007e6bc8bd1b87  movaps xmm14, [rsp]
00007e6bc8bd1b8c  add rsp, 0x30
00007e6bc8bd1b90  vmovaps xmm0, [rsp]
00007e6bc8bd1b95  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd1b9b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd1ba1  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd1ba7  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd1bad  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd1bb3  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd1bb9  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd1bbf  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd1bc8  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd1bd1  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd1bda  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd1be3  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd1bec  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd1bf5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd1bfe  add rsp, 0xF0
00007e6bc8bd1c05  pop r11
00007e6bc8bd1c07  pop r10
00007e6bc8bd1c09  pop r9
00007e6bc8bd1c0b  pop r8
00007e6bc8bd1c0d  pop rsi
00007e6bc8bd1c0e  pop rdi
00007e6bc8bd1c0f  pop rdx
00007e6bc8bd1c10  pop rcx
00007e6bc8bd1c11  pop rax
00007e6bc8bd1c12  add rsp, 0x08
00007e6bc8bd1c16  jmp 0x00007E6BC8BCFAAF
00007e6bc8bd1c1b  sub rsp, 0x08
00007e6bc8bd1c1f  push rax
00007e6bc8bd1c20  push rcx
00007e6bc8bd1c21  push rdx
00007e6bc8bd1c22  push rdi
00007e6bc8bd1c23  push rsi
00007e6bc8bd1c24  push r8
00007e6bc8bd1c26  push r9
00007e6bc8bd1c28  push r10
00007e6bc8bd1c2a  push r11
00007e6bc8bd1c2c  sub rsp, 0xF0
00007e6bc8bd1c33  vmovaps [rsp], xmm0
00007e6bc8bd1c38  vmovaps [rsp+0x10], xmm1
00007e6bc8bd1c3e  vmovaps [rsp+0x20], xmm2
00007e6bc8bd1c44  vmovaps [rsp+0x30], xmm3
00007e6bc8bd1c4a  vmovaps [rsp+0x40], xmm4
00007e6bc8bd1c50  vmovaps [rsp+0x50], xmm5
00007e6bc8bd1c56  vmovaps [rsp+0x60], xmm6
00007e6bc8bd1c5c  vmovaps [rsp+0x70], xmm7
00007e6bc8bd1c62  vmovaps [rsp+0x80], xmm8
00007e6bc8bd1c6b  vmovaps [rsp+0x90], xmm9
00007e6bc8bd1c74  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd1c7d  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd1c86  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd1c8f  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd1c98  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd1ca1  sub rsp, 0x30
00007e6bc8bd1ca5  movaps [rsp], xmm15
00007e6bc8bd1caa  movaps [rsp+0x10], xmm13
00007e6bc8bd1cb0  movaps [rsp+0x20], xmm1
00007e6bc8bd1cb5  lea rdi, [rsp]
00007e6bc8bd1cb9  mov esi, 0x00
00007e6bc8bd1cbe  mov rax, 0x6543F191D530
00007e6bc8bd1cc8  call rax
00007e6bc8bd1cca  movaps xmm15, [rsp]
00007e6bc8bd1ccf  add rsp, 0x30
00007e6bc8bd1cd3  vmovaps xmm0, [rsp]
00007e6bc8bd1cd8  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd1cde  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd1ce4  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd1cea  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd1cf0  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd1cf6  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd1cfc  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd1d02  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd1d0b  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd1d14  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd1d1d  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd1d26  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd1d2f  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd1d38  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd1d41  add rsp, 0xF0
00007e6bc8bd1d48  pop r11
00007e6bc8bd1d4a  pop r10
00007e6bc8bd1d4c  pop r9
00007e6bc8bd1d4e  pop r8
00007e6bc8bd1d50  pop rsi
00007e6bc8bd1d51  pop rdi
00007e6bc8bd1d52  pop rdx
00007e6bc8bd1d53  pop rcx
00007e6bc8bd1d54  pop rax
00007e6bc8bd1d55  add rsp, 0x08
00007e6bc8bd1d59  jmp 0x00007E6BC8BCFAEB
00007e6bc8bd1d5e  call 0x00007E6BC89FF430
00007e6bc8bd1d63  jmp 0x00007E6BC8BCFAF8
00007e6bc8bd1d68  sub rsp, 0x08
00007e6bc8bd1d6c  push rax
00007e6bc8bd1d6d  push rcx
00007e6bc8bd1d6e  push rdx
00007e6bc8bd1d6f  push rdi
00007e6bc8bd1d70  push rsi
00007e6bc8bd1d71  push r8
00007e6bc8bd1d73  push r9
00007e6bc8bd1d75  push r10
00007e6bc8bd1d77  push r11
00007e6bc8bd1d79  sub rsp, 0xF0
00007e6bc8bd1d80  vmovaps [rsp], xmm0
00007e6bc8bd1d85  vmovaps [rsp+0x10], xmm1
00007e6bc8bd1d8b  vmovaps [rsp+0x20], xmm2
00007e6bc8bd1d91  vmovaps [rsp+0x30], xmm3
00007e6bc8bd1d97  vmovaps [rsp+0x40], xmm4
00007e6bc8bd1d9d  vmovaps [rsp+0x50], xmm5
00007e6bc8bd1da3  vmovaps [rsp+0x60], xmm6
00007e6bc8bd1da9  vmovaps [rsp+0x70], xmm7
00007e6bc8bd1daf  vmovaps [rsp+0x80], xmm8
00007e6bc8bd1db8  vmovaps [rsp+0x90], xmm9
00007e6bc8bd1dc1  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd1dca  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd1dd3  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd1ddc  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd1de5  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd1dee  sub rsp, 0x30
00007e6bc8bd1df2  movaps [rsp], xmm14
00007e6bc8bd1df7  movaps [rsp+0x10], xmm13
00007e6bc8bd1dfd  movaps [rsp+0x20], xmm2
00007e6bc8bd1e02  lea rdi, [rsp]
00007e6bc8bd1e06  mov esi, 0x00
00007e6bc8bd1e0b  mov rax, 0x6543F191D530
00007e6bc8bd1e15  call rax
00007e6bc8bd1e17  movaps xmm14, [rsp]
00007e6bc8bd1e1c  add rsp, 0x30
00007e6bc8bd1e20  vmovaps xmm0, [rsp]
00007e6bc8bd1e25  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd1e2b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd1e31  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd1e37  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd1e3d  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd1e43  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd1e49  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd1e4f  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd1e58  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd1e61  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd1e6a  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd1e73  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd1e7c  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd1e85  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd1e8e  add rsp, 0xF0
00007e6bc8bd1e95  pop r11
00007e6bc8bd1e97  pop r10
00007e6bc8bd1e99  pop r9
00007e6bc8bd1e9b  pop r8
00007e6bc8bd1e9d  pop rsi
00007e6bc8bd1e9e  pop rdi
00007e6bc8bd1e9f  pop rdx
00007e6bc8bd1ea0  pop rcx
00007e6bc8bd1ea1  pop rax
00007e6bc8bd1ea2  add rsp, 0x08
00007e6bc8bd1ea6  jmp 0x00007E6BC8BCFB24
00007e6bc8bd1eab  sub rsp, 0x08
00007e6bc8bd1eaf  push rax
00007e6bc8bd1eb0  push rcx
00007e6bc8bd1eb1  push rdx
00007e6bc8bd1eb2  push rdi
00007e6bc8bd1eb3  push rsi
00007e6bc8bd1eb4  push r8
00007e6bc8bd1eb6  push r9
00007e6bc8bd1eb8  push r10
00007e6bc8bd1eba  push r11
00007e6bc8bd1ebc  sub rsp, 0xF0
00007e6bc8bd1ec3  vmovaps [rsp], xmm0
00007e6bc8bd1ec8  vmovaps [rsp+0x10], xmm2
00007e6bc8bd1ece  vmovaps [rsp+0x20], xmm3
00007e6bc8bd1ed4  vmovaps [rsp+0x30], xmm4
00007e6bc8bd1eda  vmovaps [rsp+0x40], xmm5
00007e6bc8bd1ee0  vmovaps [rsp+0x50], xmm6
00007e6bc8bd1ee6  vmovaps [rsp+0x60], xmm7
00007e6bc8bd1eec  vmovaps [rsp+0x70], xmm8
00007e6bc8bd1ef2  vmovaps [rsp+0x80], xmm9
00007e6bc8bd1efb  vmovaps [rsp+0x90], xmm10
00007e6bc8bd1f04  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd1f0d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd1f16  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd1f1f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd1f28  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd1f31  sub rsp, 0x30
00007e6bc8bd1f35  movaps [rsp], xmm1
00007e6bc8bd1f39  movaps [rsp+0x10], xmm13
00007e6bc8bd1f3f  movaps [rsp+0x20], xmm2
00007e6bc8bd1f44  lea rdi, [rsp]
00007e6bc8bd1f48  mov esi, 0x00
00007e6bc8bd1f4d  mov rax, 0x6543F191D530
00007e6bc8bd1f57  call rax
00007e6bc8bd1f59  movaps xmm1, [rsp]
00007e6bc8bd1f5d  add rsp, 0x30
00007e6bc8bd1f61  vmovaps xmm0, [rsp]
00007e6bc8bd1f66  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd1f6c  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd1f72  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd1f78  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd1f7e  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd1f84  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd1f8a  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd1f90  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd1f99  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd1fa2  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd1fab  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd1fb4  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd1fbd  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd1fc6  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd1fcf  add rsp, 0xF0
00007e6bc8bd1fd6  pop r11
00007e6bc8bd1fd8  pop r10
00007e6bc8bd1fda  pop r9
00007e6bc8bd1fdc  pop r8
00007e6bc8bd1fde  pop rsi
00007e6bc8bd1fdf  pop rdi
00007e6bc8bd1fe0  pop rdx
00007e6bc8bd1fe1  pop rcx
00007e6bc8bd1fe2  pop rax
00007e6bc8bd1fe3  add rsp, 0x08
00007e6bc8bd1fe7  jmp 0x00007E6BC8BCFB52
00007e6bc8bd1fec  sub rsp, 0x08
00007e6bc8bd1ff0  push rax
00007e6bc8bd1ff1  push rcx
00007e6bc8bd1ff2  push rdx
00007e6bc8bd1ff3  push rdi
00007e6bc8bd1ff4  push rsi
00007e6bc8bd1ff5  push r8
00007e6bc8bd1ff7  push r9
00007e6bc8bd1ff9  push r10
00007e6bc8bd1ffb  push r11
00007e6bc8bd1ffd  sub rsp, 0xF0
00007e6bc8bd2004  vmovaps [rsp], xmm0
00007e6bc8bd2009  vmovaps [rsp+0x10], xmm1
00007e6bc8bd200f  vmovaps [rsp+0x20], xmm3
00007e6bc8bd2015  vmovaps [rsp+0x30], xmm4
00007e6bc8bd201b  vmovaps [rsp+0x40], xmm5
00007e6bc8bd2021  vmovaps [rsp+0x50], xmm6
00007e6bc8bd2027  vmovaps [rsp+0x60], xmm7
00007e6bc8bd202d  vmovaps [rsp+0x70], xmm8
00007e6bc8bd2033  vmovaps [rsp+0x80], xmm9
00007e6bc8bd203c  vmovaps [rsp+0x90], xmm10
00007e6bc8bd2045  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd204e  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd2057  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd2060  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd2069  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2072  sub rsp, 0x30
00007e6bc8bd2076  movaps [rsp], xmm2
00007e6bc8bd207a  movaps [rsp+0x10], xmm1
00007e6bc8bd207f  movaps [rsp+0x20], xmm13
00007e6bc8bd2085  lea rdi, [rsp]
00007e6bc8bd2089  mov esi, 0x00
00007e6bc8bd208e  mov rax, 0x6543F191D530
00007e6bc8bd2098  call rax
00007e6bc8bd209a  movaps xmm2, [rsp]
00007e6bc8bd209e  add rsp, 0x30
00007e6bc8bd20a2  vmovaps xmm0, [rsp]
00007e6bc8bd20a7  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd20ad  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd20b3  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd20b9  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd20bf  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd20c5  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd20cb  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd20d1  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd20da  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd20e3  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd20ec  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd20f5  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd20fe  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd2107  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd2110  add rsp, 0xF0
00007e6bc8bd2117  pop r11
00007e6bc8bd2119  pop r10
00007e6bc8bd211b  pop r9
00007e6bc8bd211d  pop r8
00007e6bc8bd211f  pop rsi
00007e6bc8bd2120  pop rdi
00007e6bc8bd2121  pop rdx
00007e6bc8bd2122  pop rcx
00007e6bc8bd2123  pop rax
00007e6bc8bd2124  add rsp, 0x08
00007e6bc8bd2128  jmp 0x00007E6BC8BCFBAB
00007e6bc8bd212d  call 0x00007E6BC89FF430
00007e6bc8bd2132  jmp 0x00007E6BC8BCFBB8
00007e6bc8bd2137  sub rsp, 0x08
00007e6bc8bd213b  push rax
00007e6bc8bd213c  push rcx
00007e6bc8bd213d  push rdx
00007e6bc8bd213e  push rdi
00007e6bc8bd213f  push rsi
00007e6bc8bd2140  push r8
00007e6bc8bd2142  push r9
00007e6bc8bd2144  push r10
00007e6bc8bd2146  push r11
00007e6bc8bd2148  sub rsp, 0xF0
00007e6bc8bd214f  vmovaps [rsp], xmm0
00007e6bc8bd2154  vmovaps [rsp+0x10], xmm1
00007e6bc8bd215a  vmovaps [rsp+0x20], xmm2
00007e6bc8bd2160  vmovaps [rsp+0x30], xmm3
00007e6bc8bd2166  vmovaps [rsp+0x40], xmm4
00007e6bc8bd216c  vmovaps [rsp+0x50], xmm5
00007e6bc8bd2172  vmovaps [rsp+0x60], xmm6
00007e6bc8bd2178  vmovaps [rsp+0x70], xmm7
00007e6bc8bd217e  vmovaps [rsp+0x80], xmm8
00007e6bc8bd2187  vmovaps [rsp+0x90], xmm9
00007e6bc8bd2190  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd2199  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd21a2  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd21ab  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd21b4  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd21bd  sub rsp, 0x30
00007e6bc8bd21c1  movaps [rsp], xmm15
00007e6bc8bd21c6  movaps [rsp+0x10], xmm13
00007e6bc8bd21cc  movaps [rsp+0x20], xmm1
00007e6bc8bd21d1  lea rdi, [rsp]
00007e6bc8bd21d5  mov esi, 0x00
00007e6bc8bd21da  mov rax, 0x6543F191D530
00007e6bc8bd21e4  call rax
00007e6bc8bd21e6  movaps xmm15, [rsp]
00007e6bc8bd21eb  add rsp, 0x30
00007e6bc8bd21ef  vmovaps xmm0, [rsp]
00007e6bc8bd21f4  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd21fa  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd2200  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd2206  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd220c  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd2212  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd2218  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd221e  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd2227  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd2230  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd2239  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd2242  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd224b  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd2254  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd225d  add rsp, 0xF0
00007e6bc8bd2264  pop r11
00007e6bc8bd2266  pop r10
00007e6bc8bd2268  pop r9
00007e6bc8bd226a  pop r8
00007e6bc8bd226c  pop rsi
00007e6bc8bd226d  pop rdi
00007e6bc8bd226e  pop rdx
00007e6bc8bd226f  pop rcx
00007e6bc8bd2270  pop rax
00007e6bc8bd2271  add rsp, 0x08
00007e6bc8bd2275  jmp 0x00007E6BC8BCFBF7
00007e6bc8bd227a  sub rsp, 0x08
00007e6bc8bd227e  push rax
00007e6bc8bd227f  push rcx
00007e6bc8bd2280  push rdx
00007e6bc8bd2281  push rdi
00007e6bc8bd2282  push rsi
00007e6bc8bd2283  push r8
00007e6bc8bd2285  push r9
00007e6bc8bd2287  push r10
00007e6bc8bd2289  push r11
00007e6bc8bd228b  sub rsp, 0xF0
00007e6bc8bd2292  vmovaps [rsp], xmm0
00007e6bc8bd2297  vmovaps [rsp+0x10], xmm1
00007e6bc8bd229d  vmovaps [rsp+0x20], xmm2
00007e6bc8bd22a3  vmovaps [rsp+0x30], xmm3
00007e6bc8bd22a9  vmovaps [rsp+0x40], xmm4
00007e6bc8bd22af  vmovaps [rsp+0x50], xmm5
00007e6bc8bd22b5  vmovaps [rsp+0x60], xmm6
00007e6bc8bd22bb  vmovaps [rsp+0x70], xmm7
00007e6bc8bd22c1  vmovaps [rsp+0x80], xmm8
00007e6bc8bd22ca  vmovaps [rsp+0x90], xmm9
00007e6bc8bd22d3  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd22dc  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd22e5  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd22ee  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd22f7  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2300  sub rsp, 0x30
00007e6bc8bd2304  movaps [rsp], xmm14
00007e6bc8bd2309  movaps [rsp+0x10], xmm11
00007e6bc8bd230f  movaps [rsp+0x20], xmm1
00007e6bc8bd2314  lea rdi, [rsp]
00007e6bc8bd2318  mov esi, 0x00
00007e6bc8bd231d  mov rax, 0x6543F191D530
00007e6bc8bd2327  call rax
00007e6bc8bd2329  movaps xmm14, [rsp]
00007e6bc8bd232e  add rsp, 0x30
00007e6bc8bd2332  vmovaps xmm0, [rsp]
00007e6bc8bd2337  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd233d  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd2343  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd2349  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd234f  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd2355  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd235b  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd2361  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd236a  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd2373  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd237c  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd2385  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd238e  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd2397  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd23a0  add rsp, 0xF0
00007e6bc8bd23a7  pop r11
00007e6bc8bd23a9  pop r10
00007e6bc8bd23ab  pop r9
00007e6bc8bd23ad  pop r8
00007e6bc8bd23af  pop rsi
00007e6bc8bd23b0  pop rdi
00007e6bc8bd23b1  pop rdx
00007e6bc8bd23b2  pop rcx
00007e6bc8bd23b3  pop rax
00007e6bc8bd23b4  add rsp, 0x08
00007e6bc8bd23b8  jmp 0x00007E6BC8BCFC21
00007e6bc8bd23bd  sub rsp, 0x08
00007e6bc8bd23c1  push rax
00007e6bc8bd23c2  push rcx
00007e6bc8bd23c3  push rdx
00007e6bc8bd23c4  push rdi
00007e6bc8bd23c5  push rsi
00007e6bc8bd23c6  push r8
00007e6bc8bd23c8  push r9
00007e6bc8bd23ca  push r10
00007e6bc8bd23cc  push r11
00007e6bc8bd23ce  sub rsp, 0xF0
00007e6bc8bd23d5  vmovaps [rsp], xmm0
00007e6bc8bd23da  vmovaps [rsp+0x10], xmm1
00007e6bc8bd23e0  vmovaps [rsp+0x20], xmm2
00007e6bc8bd23e6  vmovaps [rsp+0x30], xmm3
00007e6bc8bd23ec  vmovaps [rsp+0x40], xmm4
00007e6bc8bd23f2  vmovaps [rsp+0x50], xmm5
00007e6bc8bd23f8  vmovaps [rsp+0x60], xmm6
00007e6bc8bd23fe  vmovaps [rsp+0x70], xmm7
00007e6bc8bd2404  vmovaps [rsp+0x80], xmm8
00007e6bc8bd240d  vmovaps [rsp+0x90], xmm9
00007e6bc8bd2416  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd241f  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd2428  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd2431  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd243a  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2443  sub rsp, 0x30
00007e6bc8bd2447  movaps [rsp], xmm13
00007e6bc8bd244c  movaps [rsp+0x10], xmm11
00007e6bc8bd2452  movaps [rsp+0x20], xmm1
00007e6bc8bd2457  lea rdi, [rsp]
00007e6bc8bd245b  mov esi, 0x00
00007e6bc8bd2460  mov rax, 0x6543F191D530
00007e6bc8bd246a  call rax
00007e6bc8bd246c  movaps xmm13, [rsp]
00007e6bc8bd2471  add rsp, 0x30
00007e6bc8bd2475  vmovaps xmm0, [rsp]
00007e6bc8bd247a  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd2480  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd2486  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd248c  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd2492  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd2498  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd249e  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd24a4  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd24ad  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd24b6  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd24bf  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd24c8  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd24d1  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd24da  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd24e3  add rsp, 0xF0
00007e6bc8bd24ea  pop r11
00007e6bc8bd24ec  pop r10
00007e6bc8bd24ee  pop r9
00007e6bc8bd24f0  pop r8
00007e6bc8bd24f2  pop rsi
00007e6bc8bd24f3  pop rdi
00007e6bc8bd24f4  pop rdx
00007e6bc8bd24f5  pop rcx
00007e6bc8bd24f6  pop rax
00007e6bc8bd24f7  add rsp, 0x08
00007e6bc8bd24fb  jmp 0x00007E6BC8BCFC76
00007e6bc8bd2500  call 0x00007E6BC89FF430
00007e6bc8bd2505  jmp 0x00007E6BC8BCFC83
00007e6bc8bd250a  sub rsp, 0x08
00007e6bc8bd250e  push rax
00007e6bc8bd250f  push rcx
00007e6bc8bd2510  push rdx
00007e6bc8bd2511  push rdi
00007e6bc8bd2512  push rsi
00007e6bc8bd2513  push r8
00007e6bc8bd2515  push r9
00007e6bc8bd2517  push r10
00007e6bc8bd2519  push r11
00007e6bc8bd251b  sub rsp, 0xF0
00007e6bc8bd2522  vmovaps [rsp], xmm0
00007e6bc8bd2527  vmovaps [rsp+0x10], xmm1
00007e6bc8bd252d  vmovaps [rsp+0x20], xmm2
00007e6bc8bd2533  vmovaps [rsp+0x30], xmm3
00007e6bc8bd2539  vmovaps [rsp+0x40], xmm4
00007e6bc8bd253f  vmovaps [rsp+0x50], xmm5
00007e6bc8bd2545  vmovaps [rsp+0x60], xmm6
00007e6bc8bd254b  vmovaps [rsp+0x70], xmm7
00007e6bc8bd2551  vmovaps [rsp+0x80], xmm8
00007e6bc8bd255a  vmovaps [rsp+0x90], xmm9
00007e6bc8bd2563  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd256c  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd2575  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd257e  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd2587  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd2590  sub rsp, 0x30
00007e6bc8bd2594  movaps [rsp], xmm15
00007e6bc8bd2599  movaps [rsp+0x10], xmm11
00007e6bc8bd259f  movaps [rsp+0x20], xmm1
00007e6bc8bd25a4  lea rdi, [rsp]
00007e6bc8bd25a8  mov esi, 0x00
00007e6bc8bd25ad  mov rax, 0x6543F191D530
00007e6bc8bd25b7  call rax
00007e6bc8bd25b9  movaps xmm15, [rsp]
00007e6bc8bd25be  add rsp, 0x30
00007e6bc8bd25c2  vmovaps xmm0, [rsp]
00007e6bc8bd25c7  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd25cd  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd25d3  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd25d9  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd25df  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd25e5  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd25eb  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd25f1  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd25fa  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd2603  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd260c  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd2615  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd261e  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd2627  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd2630  add rsp, 0xF0
00007e6bc8bd2637  pop r11
00007e6bc8bd2639  pop r10
00007e6bc8bd263b  pop r9
00007e6bc8bd263d  pop r8
00007e6bc8bd263f  pop rsi
00007e6bc8bd2640  pop rdi
00007e6bc8bd2641  pop rdx
00007e6bc8bd2642  pop rcx
00007e6bc8bd2643  pop rax
00007e6bc8bd2644  add rsp, 0x08
00007e6bc8bd2648  jmp 0x00007E6BC8BCFCBC
00007e6bc8bd264d  sub rsp, 0x08
00007e6bc8bd2651  push rax
00007e6bc8bd2652  push rcx
00007e6bc8bd2653  push rdx
00007e6bc8bd2654  push rdi
00007e6bc8bd2655  push rsi
00007e6bc8bd2656  push r8
00007e6bc8bd2658  push r9
00007e6bc8bd265a  push r10
00007e6bc8bd265c  push r11
00007e6bc8bd265e  sub rsp, 0xF0
00007e6bc8bd2665  vmovaps [rsp], xmm0
00007e6bc8bd266a  vmovaps [rsp+0x10], xmm1
00007e6bc8bd2670  vmovaps [rsp+0x20], xmm2
00007e6bc8bd2676  vmovaps [rsp+0x30], xmm3
00007e6bc8bd267c  vmovaps [rsp+0x40], xmm4
00007e6bc8bd2682  vmovaps [rsp+0x50], xmm5
00007e6bc8bd2688  vmovaps [rsp+0x60], xmm6
00007e6bc8bd268e  vmovaps [rsp+0x70], xmm7
00007e6bc8bd2694  vmovaps [rsp+0x80], xmm8
00007e6bc8bd269d  vmovaps [rsp+0x90], xmm9
00007e6bc8bd26a6  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd26af  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd26b8  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd26c1  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd26ca  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd26d3  sub rsp, 0x30
00007e6bc8bd26d7  movaps [rsp], xmm11
00007e6bc8bd26dc  movaps [rsp+0x10], xmm6
00007e6bc8bd26e1  movaps [rsp+0x20], xmm14
00007e6bc8bd26e7  lea rdi, [rsp]
00007e6bc8bd26eb  mov esi, 0x00
00007e6bc8bd26f0  mov rax, 0x6543F191D530
00007e6bc8bd26fa  call rax
00007e6bc8bd26fc  movaps xmm11, [rsp]
00007e6bc8bd2701  add rsp, 0x30
00007e6bc8bd2705  vmovaps xmm0, [rsp]
00007e6bc8bd270a  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd2710  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd2716  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd271c  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd2722  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd2728  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd272e  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd2734  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd273d  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd2746  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd274f  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd2758  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd2761  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd276a  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd2773  add rsp, 0xF0
00007e6bc8bd277a  pop r11
00007e6bc8bd277c  pop r10
00007e6bc8bd277e  pop r9
00007e6bc8bd2780  pop r8
00007e6bc8bd2782  pop rsi
00007e6bc8bd2783  pop rdi
00007e6bc8bd2784  pop rdx
00007e6bc8bd2785  pop rcx
00007e6bc8bd2786  pop rax
00007e6bc8bd2787  add rsp, 0x08
00007e6bc8bd278b  jmp 0x00007E6BC8BCFD34
00007e6bc8bd2790  call 0x00007E6BC89FF430
00007e6bc8bd2795  jmp 0x00007E6BC8BCFD3E
00007e6bc8bd279a  sub rsp, 0x08
00007e6bc8bd279e  push rax
00007e6bc8bd279f  push rcx
00007e6bc8bd27a0  push rdx
00007e6bc8bd27a1  push rdi
00007e6bc8bd27a2  push rsi
00007e6bc8bd27a3  push r8
00007e6bc8bd27a5  push r9
00007e6bc8bd27a7  push r10
00007e6bc8bd27a9  push r11
00007e6bc8bd27ab  sub rsp, 0xF0
00007e6bc8bd27b2  vmovaps [rsp], xmm0
00007e6bc8bd27b7  vmovaps [rsp+0x10], xmm1
00007e6bc8bd27bd  vmovaps [rsp+0x20], xmm2
00007e6bc8bd27c3  vmovaps [rsp+0x30], xmm3
00007e6bc8bd27c9  vmovaps [rsp+0x40], xmm4
00007e6bc8bd27cf  vmovaps [rsp+0x50], xmm5
00007e6bc8bd27d5  vmovaps [rsp+0x60], xmm6
00007e6bc8bd27db  vmovaps [rsp+0x70], xmm7
00007e6bc8bd27e1  vmovaps [rsp+0x80], xmm8
00007e6bc8bd27ea  vmovaps [rsp+0x90], xmm9
00007e6bc8bd27f3  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd27fc  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd2805  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd280e  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd2817  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2820  sub rsp, 0x30
00007e6bc8bd2824  movaps [rsp], xmm14
00007e6bc8bd2829  movaps [rsp+0x10], xmm6
00007e6bc8bd282e  movaps [rsp+0x20], xmm2
00007e6bc8bd2833  lea rdi, [rsp]
00007e6bc8bd2837  mov esi, 0x00
00007e6bc8bd283c  mov rax, 0x6543F191D530
00007e6bc8bd2846  call rax
00007e6bc8bd2848  movaps xmm14, [rsp]
00007e6bc8bd284d  add rsp, 0x30
00007e6bc8bd2851  vmovaps xmm0, [rsp]
00007e6bc8bd2856  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd285c  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd2862  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd2868  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd286e  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd2874  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd287a  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd2880  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd2889  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd2892  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd289b  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd28a4  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd28ad  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd28b6  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd28bf  add rsp, 0xF0
00007e6bc8bd28c6  pop r11
00007e6bc8bd28c8  pop r10
00007e6bc8bd28ca  pop r9
00007e6bc8bd28cc  pop r8
00007e6bc8bd28ce  pop rsi
00007e6bc8bd28cf  pop rdi
00007e6bc8bd28d0  pop rdx
00007e6bc8bd28d1  pop rcx
00007e6bc8bd28d2  pop rax
00007e6bc8bd28d3  add rsp, 0x08
00007e6bc8bd28d7  jmp 0x00007E6BC8BCFD72
00007e6bc8bd28dc  sub rsp, 0x08
00007e6bc8bd28e0  push rax
00007e6bc8bd28e1  push rcx
00007e6bc8bd28e2  push rdx
00007e6bc8bd28e3  push rdi
00007e6bc8bd28e4  push rsi
00007e6bc8bd28e5  push r8
00007e6bc8bd28e7  push r9
00007e6bc8bd28e9  push r10
00007e6bc8bd28eb  push r11
00007e6bc8bd28ed  sub rsp, 0xF0
00007e6bc8bd28f4  vmovaps [rsp], xmm0
00007e6bc8bd28f9  vmovaps [rsp+0x10], xmm1
00007e6bc8bd28ff  vmovaps [rsp+0x20], xmm2
00007e6bc8bd2905  vmovaps [rsp+0x30], xmm3
00007e6bc8bd290b  vmovaps [rsp+0x40], xmm4
00007e6bc8bd2911  vmovaps [rsp+0x50], xmm5
00007e6bc8bd2917  vmovaps [rsp+0x60], xmm7
00007e6bc8bd291d  vmovaps [rsp+0x70], xmm8
00007e6bc8bd2923  vmovaps [rsp+0x80], xmm9
00007e6bc8bd292c  vmovaps [rsp+0x90], xmm10
00007e6bc8bd2935  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd293e  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd2947  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd2950  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd2959  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2962  sub rsp, 0x30
00007e6bc8bd2966  movaps [rsp], xmm6
00007e6bc8bd296a  movaps [rsp+0x10], xmm5
00007e6bc8bd296f  movaps [rsp+0x20], xmm1
00007e6bc8bd2974  lea rdi, [rsp]
00007e6bc8bd2978  mov esi, 0x00
00007e6bc8bd297d  mov rax, 0x6543F191D530
00007e6bc8bd2987  call rax
00007e6bc8bd2989  movaps xmm6, [rsp]
00007e6bc8bd298d  add rsp, 0x30
00007e6bc8bd2991  vmovaps xmm0, [rsp]
00007e6bc8bd2996  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd299c  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd29a2  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd29a8  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd29ae  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd29b4  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd29ba  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd29c0  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd29c9  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd29d2  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd29db  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd29e4  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd29ed  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd29f6  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd29ff  add rsp, 0xF0
00007e6bc8bd2a06  pop r11
00007e6bc8bd2a08  pop r10
00007e6bc8bd2a0a  pop r9
00007e6bc8bd2a0c  pop r8
00007e6bc8bd2a0e  pop rsi
00007e6bc8bd2a0f  pop rdi
00007e6bc8bd2a10  pop rdx
00007e6bc8bd2a11  pop rcx
00007e6bc8bd2a12  pop rax
00007e6bc8bd2a13  add rsp, 0x08
00007e6bc8bd2a17  jmp 0x00007E6BC8BCFD98
00007e6bc8bd2a1c  sub rsp, 0x08
00007e6bc8bd2a20  push rax
00007e6bc8bd2a21  push rcx
00007e6bc8bd2a22  push rdx
00007e6bc8bd2a23  push rdi
00007e6bc8bd2a24  push rsi
00007e6bc8bd2a25  push r8
00007e6bc8bd2a27  push r9
00007e6bc8bd2a29  push r10
00007e6bc8bd2a2b  push r11
00007e6bc8bd2a2d  sub rsp, 0xF0
00007e6bc8bd2a34  vmovaps [rsp], xmm0
00007e6bc8bd2a39  vmovaps [rsp+0x10], xmm2
00007e6bc8bd2a3f  vmovaps [rsp+0x20], xmm3
00007e6bc8bd2a45  vmovaps [rsp+0x30], xmm4
00007e6bc8bd2a4b  vmovaps [rsp+0x40], xmm5
00007e6bc8bd2a51  vmovaps [rsp+0x50], xmm6
00007e6bc8bd2a57  vmovaps [rsp+0x60], xmm7
00007e6bc8bd2a5d  vmovaps [rsp+0x70], xmm8
00007e6bc8bd2a63  vmovaps [rsp+0x80], xmm9
00007e6bc8bd2a6c  vmovaps [rsp+0x90], xmm10
00007e6bc8bd2a75  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd2a7e  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd2a87  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd2a90  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd2a99  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2aa2  sub rsp, 0x30
00007e6bc8bd2aa6  movaps [rsp], xmm1
00007e6bc8bd2aaa  movaps [rsp+0x10], xmm5
00007e6bc8bd2aaf  movaps [rsp+0x20], xmm13
00007e6bc8bd2ab5  lea rdi, [rsp]
00007e6bc8bd2ab9  mov esi, 0x00
00007e6bc8bd2abe  mov rax, 0x6543F191D530
00007e6bc8bd2ac8  call rax
00007e6bc8bd2aca  movaps xmm1, [rsp]
00007e6bc8bd2ace  add rsp, 0x30
00007e6bc8bd2ad2  vmovaps xmm0, [rsp]
00007e6bc8bd2ad7  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd2add  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd2ae3  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd2ae9  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd2aef  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd2af5  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd2afb  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd2b01  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd2b0a  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd2b13  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd2b1c  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd2b25  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd2b2e  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd2b37  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd2b40  add rsp, 0xF0
00007e6bc8bd2b47  pop r11
00007e6bc8bd2b49  pop r10
00007e6bc8bd2b4b  pop r9
00007e6bc8bd2b4d  pop r8
00007e6bc8bd2b4f  pop rsi
00007e6bc8bd2b50  pop rdi
00007e6bc8bd2b51  pop rdx
00007e6bc8bd2b52  pop rcx
00007e6bc8bd2b53  pop rax
00007e6bc8bd2b54  add rsp, 0x08
00007e6bc8bd2b58  jmp 0x00007E6BC8BCFDB6
00007e6bc8bd2b5d  sub rsp, 0x08
00007e6bc8bd2b61  push rax
00007e6bc8bd2b62  push rcx
00007e6bc8bd2b63  push rdx
00007e6bc8bd2b64  push rdi
00007e6bc8bd2b65  push rsi
00007e6bc8bd2b66  push r8
00007e6bc8bd2b68  push r9
00007e6bc8bd2b6a  push r10
00007e6bc8bd2b6c  push r11
00007e6bc8bd2b6e  sub rsp, 0xF0
00007e6bc8bd2b75  vmovaps [rsp], xmm0
00007e6bc8bd2b7a  vmovaps [rsp+0x10], xmm1
00007e6bc8bd2b80  vmovaps [rsp+0x20], xmm2
00007e6bc8bd2b86  vmovaps [rsp+0x30], xmm3
00007e6bc8bd2b8c  vmovaps [rsp+0x40], xmm4
00007e6bc8bd2b92  vmovaps [rsp+0x50], xmm6
00007e6bc8bd2b98  vmovaps [rsp+0x60], xmm7
00007e6bc8bd2b9e  vmovaps [rsp+0x70], xmm8
00007e6bc8bd2ba4  vmovaps [rsp+0x80], xmm9
00007e6bc8bd2bad  vmovaps [rsp+0x90], xmm10
00007e6bc8bd2bb6  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd2bbf  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd2bc8  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd2bd1  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd2bda  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2be3  sub rsp, 0x30
00007e6bc8bd2be7  movaps [rsp], xmm5
00007e6bc8bd2beb  movaps [rsp+0x10], xmm2
00007e6bc8bd2bf0  movaps [rsp+0x20], xmm13
00007e6bc8bd2bf6  lea rdi, [rsp]
00007e6bc8bd2bfa  mov esi, 0x00
00007e6bc8bd2bff  mov rax, 0x6543F191D530
00007e6bc8bd2c09  call rax
00007e6bc8bd2c0b  movaps xmm5, [rsp]
00007e6bc8bd2c0f  add rsp, 0x30
00007e6bc8bd2c13  vmovaps xmm0, [rsp]
00007e6bc8bd2c18  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd2c1e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd2c24  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd2c2a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd2c30  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd2c36  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd2c3c  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd2c42  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd2c4b  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd2c54  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd2c5d  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd2c66  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd2c6f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd2c78  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd2c81  add rsp, 0xF0
00007e6bc8bd2c88  pop r11
00007e6bc8bd2c8a  pop r10
00007e6bc8bd2c8c  pop r9
00007e6bc8bd2c8e  pop r8
00007e6bc8bd2c90  pop rsi
00007e6bc8bd2c91  pop rdi
00007e6bc8bd2c92  pop rdx
00007e6bc8bd2c93  pop rcx
00007e6bc8bd2c94  pop rax
00007e6bc8bd2c95  add rsp, 0x08
00007e6bc8bd2c99  jmp 0x00007E6BC8BCFDEC
00007e6bc8bd2c9e  sub rsp, 0x08
00007e6bc8bd2ca2  push rax
00007e6bc8bd2ca3  push rcx
00007e6bc8bd2ca4  push rdx
00007e6bc8bd2ca5  push rdi
00007e6bc8bd2ca6  push rsi
00007e6bc8bd2ca7  push r8
00007e6bc8bd2ca9  push r9
00007e6bc8bd2cab  push r10
00007e6bc8bd2cad  push r11
00007e6bc8bd2caf  sub rsp, 0xF0
00007e6bc8bd2cb6  vmovaps [rsp], xmm0
00007e6bc8bd2cbb  vmovaps [rsp+0x10], xmm1
00007e6bc8bd2cc1  vmovaps [rsp+0x20], xmm2
00007e6bc8bd2cc7  vmovaps [rsp+0x30], xmm3
00007e6bc8bd2ccd  vmovaps [rsp+0x40], xmm4
00007e6bc8bd2cd3  vmovaps [rsp+0x50], xmm5
00007e6bc8bd2cd9  vmovaps [rsp+0x60], xmm6
00007e6bc8bd2cdf  vmovaps [rsp+0x70], xmm7
00007e6bc8bd2ce5  vmovaps [rsp+0x80], xmm8
00007e6bc8bd2cee  vmovaps [rsp+0x90], xmm9
00007e6bc8bd2cf7  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd2d00  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd2d09  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd2d12  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd2d1b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2d24  sub rsp, 0x30
00007e6bc8bd2d28  movaps [rsp], xmm13
00007e6bc8bd2d2d  movaps [rsp+0x10], xmm10
00007e6bc8bd2d33  movaps [rsp+0x20], xmm1
00007e6bc8bd2d38  lea rdi, [rsp]
00007e6bc8bd2d3c  mov esi, 0x00
00007e6bc8bd2d41  mov rax, 0x6543F191D530
00007e6bc8bd2d4b  call rax
00007e6bc8bd2d4d  movaps xmm13, [rsp]
00007e6bc8bd2d52  add rsp, 0x30
00007e6bc8bd2d56  vmovaps xmm0, [rsp]
00007e6bc8bd2d5b  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd2d61  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd2d67  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd2d6d  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd2d73  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd2d79  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd2d7f  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd2d85  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd2d8e  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd2d97  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd2da0  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd2da9  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd2db2  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd2dbb  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd2dc4  add rsp, 0xF0
00007e6bc8bd2dcb  pop r11
00007e6bc8bd2dcd  pop r10
00007e6bc8bd2dcf  pop r9
00007e6bc8bd2dd1  pop r8
00007e6bc8bd2dd3  pop rsi
00007e6bc8bd2dd4  pop rdi
00007e6bc8bd2dd5  pop rdx
00007e6bc8bd2dd6  pop rcx
00007e6bc8bd2dd7  pop rax
00007e6bc8bd2dd8  add rsp, 0x08
00007e6bc8bd2ddc  jmp 0x00007E6BC8BCFE15
00007e6bc8bd2de1  sub rsp, 0x08
00007e6bc8bd2de5  push rax
00007e6bc8bd2de6  push rcx
00007e6bc8bd2de7  push rdx
00007e6bc8bd2de8  push rdi
00007e6bc8bd2de9  push rsi
00007e6bc8bd2dea  push r8
00007e6bc8bd2dec  push r9
00007e6bc8bd2dee  push r10
00007e6bc8bd2df0  push r11
00007e6bc8bd2df2  sub rsp, 0xF0
00007e6bc8bd2df9  vmovaps [rsp], xmm0
00007e6bc8bd2dfe  vmovaps [rsp+0x10], xmm2
00007e6bc8bd2e04  vmovaps [rsp+0x20], xmm3
00007e6bc8bd2e0a  vmovaps [rsp+0x30], xmm4
00007e6bc8bd2e10  vmovaps [rsp+0x40], xmm5
00007e6bc8bd2e16  vmovaps [rsp+0x50], xmm6
00007e6bc8bd2e1c  vmovaps [rsp+0x60], xmm7
00007e6bc8bd2e22  vmovaps [rsp+0x70], xmm8
00007e6bc8bd2e28  vmovaps [rsp+0x80], xmm9
00007e6bc8bd2e31  vmovaps [rsp+0x90], xmm10
00007e6bc8bd2e3a  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd2e43  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd2e4c  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd2e55  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd2e5e  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd2e67  sub rsp, 0x30
00007e6bc8bd2e6b  movaps [rsp], xmm1
00007e6bc8bd2e6f  movaps [rsp+0x10], xmm15
00007e6bc8bd2e75  movaps [rsp+0x20], xmm10
00007e6bc8bd2e7b  lea rdi, [rsp]
00007e6bc8bd2e7f  mov esi, 0x00
00007e6bc8bd2e84  mov rax, 0x6543F191D530
00007e6bc8bd2e8e  call rax
00007e6bc8bd2e90  movaps xmm1, [rsp]
00007e6bc8bd2e94  add rsp, 0x30
00007e6bc8bd2e98  vmovaps xmm0, [rsp]
00007e6bc8bd2e9d  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd2ea3  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd2ea9  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd2eaf  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd2eb5  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd2ebb  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd2ec1  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd2ec7  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd2ed0  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd2ed9  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd2ee2  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd2eeb  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd2ef4  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd2efd  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd2f06  add rsp, 0xF0
00007e6bc8bd2f0d  pop r11
00007e6bc8bd2f0f  pop r10
00007e6bc8bd2f11  pop r9
00007e6bc8bd2f13  pop r8
00007e6bc8bd2f15  pop rsi
00007e6bc8bd2f16  pop rdi
00007e6bc8bd2f17  pop rdx
00007e6bc8bd2f18  pop rcx
00007e6bc8bd2f19  pop rax
00007e6bc8bd2f1a  add rsp, 0x08
00007e6bc8bd2f1e  jmp 0x00007E6BC8BCFE34
00007e6bc8bd2f23  sub rsp, 0x08
00007e6bc8bd2f27  push rax
00007e6bc8bd2f28  push rcx
00007e6bc8bd2f29  push rdx
00007e6bc8bd2f2a  push rdi
00007e6bc8bd2f2b  push rsi
00007e6bc8bd2f2c  push r8
00007e6bc8bd2f2e  push r9
00007e6bc8bd2f30  push r10
00007e6bc8bd2f32  push r11
00007e6bc8bd2f34  sub rsp, 0xF0
00007e6bc8bd2f3b  vmovaps [rsp], xmm0
00007e6bc8bd2f40  vmovaps [rsp+0x10], xmm1
00007e6bc8bd2f46  vmovaps [rsp+0x20], xmm2
00007e6bc8bd2f4c  vmovaps [rsp+0x30], xmm3
00007e6bc8bd2f52  vmovaps [rsp+0x40], xmm4
00007e6bc8bd2f58  vmovaps [rsp+0x50], xmm5
00007e6bc8bd2f5e  vmovaps [rsp+0x60], xmm6
00007e6bc8bd2f64  vmovaps [rsp+0x70], xmm7
00007e6bc8bd2f6a  vmovaps [rsp+0x80], xmm8
00007e6bc8bd2f73  vmovaps [rsp+0x90], xmm9
00007e6bc8bd2f7c  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd2f85  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd2f8e  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd2f97  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd2fa0  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd2fa9  sub rsp, 0x30
00007e6bc8bd2fad  movaps [rsp], xmm15
00007e6bc8bd2fb2  movaps [rsp+0x10], xmm10
00007e6bc8bd2fb8  movaps [rsp+0x20], xmm11
00007e6bc8bd2fbe  lea rdi, [rsp]
00007e6bc8bd2fc2  mov esi, 0x00
00007e6bc8bd2fc7  mov rax, 0x6543F191D530
00007e6bc8bd2fd1  call rax
00007e6bc8bd2fd3  movaps xmm15, [rsp]
00007e6bc8bd2fd8  add rsp, 0x30
00007e6bc8bd2fdc  vmovaps xmm0, [rsp]
00007e6bc8bd2fe1  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd2fe7  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd2fed  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd2ff3  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd2ff9  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd2fff  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd3005  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd300b  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd3014  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd301d  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd3026  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd302f  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd3038  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd3041  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd304a  add rsp, 0xF0
00007e6bc8bd3051  pop r11
00007e6bc8bd3053  pop r10
00007e6bc8bd3055  pop r9
00007e6bc8bd3057  pop r8
00007e6bc8bd3059  pop rsi
00007e6bc8bd305a  pop rdi
00007e6bc8bd305b  pop rdx
00007e6bc8bd305c  pop rcx
00007e6bc8bd305d  pop rax
00007e6bc8bd305e  add rsp, 0x08
00007e6bc8bd3062  jmp 0x00007E6BC8BCFE57
00007e6bc8bd3067  sub rsp, 0x08
00007e6bc8bd306b  push rax
00007e6bc8bd306c  push rcx
00007e6bc8bd306d  push rdx
00007e6bc8bd306e  push rdi
00007e6bc8bd306f  push rsi
00007e6bc8bd3070  push r8
00007e6bc8bd3072  push r9
00007e6bc8bd3074  push r10
00007e6bc8bd3076  push r11
00007e6bc8bd3078  sub rsp, 0xF0
00007e6bc8bd307f  vmovaps [rsp], xmm0
00007e6bc8bd3084  vmovaps [rsp+0x10], xmm1
00007e6bc8bd308a  vmovaps [rsp+0x20], xmm2
00007e6bc8bd3090  vmovaps [rsp+0x30], xmm3
00007e6bc8bd3096  vmovaps [rsp+0x40], xmm4
00007e6bc8bd309c  vmovaps [rsp+0x50], xmm5
00007e6bc8bd30a2  vmovaps [rsp+0x60], xmm6
00007e6bc8bd30a8  vmovaps [rsp+0x70], xmm7
00007e6bc8bd30ae  vmovaps [rsp+0x80], xmm8
00007e6bc8bd30b7  vmovaps [rsp+0x90], xmm9
00007e6bc8bd30c0  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd30c9  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd30d2  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd30db  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd30e4  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd30ed  sub rsp, 0x30
00007e6bc8bd30f1  movaps [rsp], xmm10
00007e6bc8bd30f6  movaps [rsp+0x10], xmm12
00007e6bc8bd30fc  movaps [rsp+0x20], xmm11
00007e6bc8bd3102  lea rdi, [rsp]
00007e6bc8bd3106  mov esi, 0x00
00007e6bc8bd310b  mov rax, 0x6543F191D530
00007e6bc8bd3115  call rax
00007e6bc8bd3117  movaps xmm10, [rsp]
00007e6bc8bd311c  add rsp, 0x30
00007e6bc8bd3120  vmovaps xmm0, [rsp]
00007e6bc8bd3125  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd312b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd3131  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd3137  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd313d  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd3143  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd3149  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd314f  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd3158  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd3161  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd316a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd3173  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd317c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd3185  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd318e  add rsp, 0xF0
00007e6bc8bd3195  pop r11
00007e6bc8bd3197  pop r10
00007e6bc8bd3199  pop r9
00007e6bc8bd319b  pop r8
00007e6bc8bd319d  pop rsi
00007e6bc8bd319e  pop rdi
00007e6bc8bd319f  pop rdx
00007e6bc8bd31a0  pop rcx
00007e6bc8bd31a1  pop rax
00007e6bc8bd31a2  add rsp, 0x08
00007e6bc8bd31a6  jmp 0x00007E6BC8BCFE80
00007e6bc8bd31ab  sub rsp, 0x08
00007e6bc8bd31af  push rax
00007e6bc8bd31b0  push rcx
00007e6bc8bd31b1  push rdx
00007e6bc8bd31b2  push rdi
00007e6bc8bd31b3  push rsi
00007e6bc8bd31b4  push r8
00007e6bc8bd31b6  push r9
00007e6bc8bd31b8  push r10
00007e6bc8bd31ba  push r11
00007e6bc8bd31bc  sub rsp, 0xF0
00007e6bc8bd31c3  vmovaps [rsp], xmm0
00007e6bc8bd31c8  vmovaps [rsp+0x10], xmm1
00007e6bc8bd31ce  vmovaps [rsp+0x20], xmm2
00007e6bc8bd31d4  vmovaps [rsp+0x30], xmm3
00007e6bc8bd31da  vmovaps [rsp+0x40], xmm4
00007e6bc8bd31e0  vmovaps [rsp+0x50], xmm5
00007e6bc8bd31e6  vmovaps [rsp+0x60], xmm6
00007e6bc8bd31ec  vmovaps [rsp+0x70], xmm7
00007e6bc8bd31f2  vmovaps [rsp+0x80], xmm8
00007e6bc8bd31fb  vmovaps [rsp+0x90], xmm9
00007e6bc8bd3204  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd320d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd3216  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd321f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd3228  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd3231  sub rsp, 0x30
00007e6bc8bd3235  movaps [rsp], xmm11
00007e6bc8bd323a  movaps [rsp+0x10], xmm2
00007e6bc8bd323f  movaps [rsp+0x20], xmm12
00007e6bc8bd3245  lea rdi, [rsp]
00007e6bc8bd3249  mov esi, 0x00
00007e6bc8bd324e  mov rax, 0x6543F191D530
00007e6bc8bd3258  call rax
00007e6bc8bd325a  movaps xmm11, [rsp]
00007e6bc8bd325f  add rsp, 0x30
00007e6bc8bd3263  vmovaps xmm0, [rsp]
00007e6bc8bd3268  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd326e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd3274  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd327a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd3280  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd3286  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd328c  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd3292  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd329b  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd32a4  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd32ad  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd32b6  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd32bf  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd32c8  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd32d1  add rsp, 0xF0
00007e6bc8bd32d8  pop r11
00007e6bc8bd32da  pop r10
00007e6bc8bd32dc  pop r9
00007e6bc8bd32de  pop r8
00007e6bc8bd32e0  pop rsi
00007e6bc8bd32e1  pop rdi
00007e6bc8bd32e2  pop rdx
00007e6bc8bd32e3  pop rcx
00007e6bc8bd32e4  pop rax
00007e6bc8bd32e5  add rsp, 0x08
00007e6bc8bd32e9  jmp 0x00007E6BC8BCFEB8
00007e6bc8bd32ee  sub rsp, 0x08
00007e6bc8bd32f2  push rax
00007e6bc8bd32f3  push rcx
00007e6bc8bd32f4  push rdx
00007e6bc8bd32f5  push rdi
00007e6bc8bd32f6  push rsi
00007e6bc8bd32f7  push r8
00007e6bc8bd32f9  push r9
00007e6bc8bd32fb  push r10
00007e6bc8bd32fd  push r11
00007e6bc8bd32ff  sub rsp, 0xF0
00007e6bc8bd3306  vmovaps [rsp], xmm0
00007e6bc8bd330b  vmovaps [rsp+0x10], xmm2
00007e6bc8bd3311  vmovaps [rsp+0x20], xmm3
00007e6bc8bd3317  vmovaps [rsp+0x30], xmm4
00007e6bc8bd331d  vmovaps [rsp+0x40], xmm5
00007e6bc8bd3323  vmovaps [rsp+0x50], xmm6
00007e6bc8bd3329  vmovaps [rsp+0x60], xmm7
00007e6bc8bd332f  vmovaps [rsp+0x70], xmm8
00007e6bc8bd3335  vmovaps [rsp+0x80], xmm9
00007e6bc8bd333e  vmovaps [rsp+0x90], xmm10
00007e6bc8bd3347  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd3350  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd3359  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd3362  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd336b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd3374  sub rsp, 0x30
00007e6bc8bd3378  movaps [rsp], xmm1
00007e6bc8bd337c  movaps [rsp+0x10], xmm14
00007e6bc8bd3382  movaps [rsp+0x20], xmm6
00007e6bc8bd3387  lea rdi, [rsp]
00007e6bc8bd338b  mov esi, 0x00
00007e6bc8bd3390  mov rax, 0x6543F191D530
00007e6bc8bd339a  call rax
00007e6bc8bd339c  movaps xmm1, [rsp]
00007e6bc8bd33a0  add rsp, 0x30
00007e6bc8bd33a4  vmovaps xmm0, [rsp]
00007e6bc8bd33a9  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd33af  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd33b5  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd33bb  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd33c1  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd33c7  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd33cd  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd33d3  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd33dc  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd33e5  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd33ee  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd33f7  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd3400  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd3409  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd3412  add rsp, 0xF0
00007e6bc8bd3419  pop r11
00007e6bc8bd341b  pop r10
00007e6bc8bd341d  pop r9
00007e6bc8bd341f  pop r8
00007e6bc8bd3421  pop rsi
00007e6bc8bd3422  pop rdi
00007e6bc8bd3423  pop rdx
00007e6bc8bd3424  pop rcx
00007e6bc8bd3425  pop rax
00007e6bc8bd3426  add rsp, 0x08
00007e6bc8bd342a  jmp 0x00007E6BC8BCFED1
00007e6bc8bd342f  sub rsp, 0x08
00007e6bc8bd3433  push rax
00007e6bc8bd3434  push rcx
00007e6bc8bd3435  push rdx
00007e6bc8bd3436  push rdi
00007e6bc8bd3437  push rsi
00007e6bc8bd3438  push r8
00007e6bc8bd343a  push r9
00007e6bc8bd343c  push r10
00007e6bc8bd343e  push r11
00007e6bc8bd3440  sub rsp, 0xF0
00007e6bc8bd3447  vmovaps [rsp], xmm0
00007e6bc8bd344c  vmovaps [rsp+0x10], xmm1
00007e6bc8bd3452  vmovaps [rsp+0x20], xmm2
00007e6bc8bd3458  vmovaps [rsp+0x30], xmm3
00007e6bc8bd345e  vmovaps [rsp+0x40], xmm4
00007e6bc8bd3464  vmovaps [rsp+0x50], xmm5
00007e6bc8bd346a  vmovaps [rsp+0x60], xmm6
00007e6bc8bd3470  vmovaps [rsp+0x70], xmm7
00007e6bc8bd3476  vmovaps [rsp+0x80], xmm8
00007e6bc8bd347f  vmovaps [rsp+0x90], xmm9
00007e6bc8bd3488  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd3491  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd349a  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd34a3  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd34ac  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd34b5  sub rsp, 0x30
00007e6bc8bd34b9  movaps [rsp], xmm14
00007e6bc8bd34be  movaps [rsp+0x10], xmm12
00007e6bc8bd34c4  movaps [rsp+0x20], xmm5
00007e6bc8bd34c9  lea rdi, [rsp]
00007e6bc8bd34cd  mov esi, 0x00
00007e6bc8bd34d2  mov rax, 0x6543F191D530
00007e6bc8bd34dc  call rax
00007e6bc8bd34de  movaps xmm14, [rsp]
00007e6bc8bd34e3  add rsp, 0x30
00007e6bc8bd34e7  vmovaps xmm0, [rsp]
00007e6bc8bd34ec  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd34f2  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd34f8  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd34fe  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd3504  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd350a  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd3510  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd3516  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd351f  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd3528  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd3531  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd353a  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd3543  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd354c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd3555  add rsp, 0xF0
00007e6bc8bd355c  pop r11
00007e6bc8bd355e  pop r10
00007e6bc8bd3560  pop r9
00007e6bc8bd3562  pop r8
00007e6bc8bd3564  pop rsi
00007e6bc8bd3565  pop rdi
00007e6bc8bd3566  pop rdx
00007e6bc8bd3567  pop rcx
00007e6bc8bd3568  pop rax
00007e6bc8bd3569  add rsp, 0x08
00007e6bc8bd356d  jmp 0x00007E6BC8BCFEF1
00007e6bc8bd3572  sub rsp, 0x08
00007e6bc8bd3576  push rax
00007e6bc8bd3577  push rcx
00007e6bc8bd3578  push rdx
00007e6bc8bd3579  push rdi
00007e6bc8bd357a  push rsi
00007e6bc8bd357b  push r8
00007e6bc8bd357d  push r9
00007e6bc8bd357f  push r10
00007e6bc8bd3581  push r11
00007e6bc8bd3583  sub rsp, 0xF0
00007e6bc8bd358a  vmovaps [rsp], xmm0
00007e6bc8bd358f  vmovaps [rsp+0x10], xmm1
00007e6bc8bd3595  vmovaps [rsp+0x20], xmm2
00007e6bc8bd359b  vmovaps [rsp+0x30], xmm3
00007e6bc8bd35a1  vmovaps [rsp+0x40], xmm4
00007e6bc8bd35a7  vmovaps [rsp+0x50], xmm5
00007e6bc8bd35ad  vmovaps [rsp+0x60], xmm7
00007e6bc8bd35b3  vmovaps [rsp+0x70], xmm8
00007e6bc8bd35b9  vmovaps [rsp+0x80], xmm9
00007e6bc8bd35c2  vmovaps [rsp+0x90], xmm10
00007e6bc8bd35cb  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd35d4  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd35dd  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd35e6  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd35ef  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd35f8  sub rsp, 0x30
00007e6bc8bd35fc  movaps [rsp], xmm6
00007e6bc8bd3600  movaps [rsp+0x10], xmm9
00007e6bc8bd3606  movaps [rsp+0x20], xmm12
00007e6bc8bd360c  lea rdi, [rsp]
00007e6bc8bd3610  mov esi, 0x00
00007e6bc8bd3615  mov rax, 0x6543F191D530
00007e6bc8bd361f  call rax
00007e6bc8bd3621  movaps xmm6, [rsp]
00007e6bc8bd3625  add rsp, 0x30
00007e6bc8bd3629  vmovaps xmm0, [rsp]
00007e6bc8bd362e  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd3634  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd363a  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd3640  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd3646  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd364c  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd3652  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd3658  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd3661  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd366a  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd3673  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd367c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd3685  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd368e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd3697  add rsp, 0xF0
00007e6bc8bd369e  pop r11
00007e6bc8bd36a0  pop r10
00007e6bc8bd36a2  pop r9
00007e6bc8bd36a4  pop r8
00007e6bc8bd36a6  pop rsi
00007e6bc8bd36a7  pop rdi
00007e6bc8bd36a8  pop rdx
00007e6bc8bd36a9  pop rcx
00007e6bc8bd36aa  pop rax
00007e6bc8bd36ab  add rsp, 0x08
00007e6bc8bd36af  jmp 0x00007E6BC8BCFF19
00007e6bc8bd36b4  sub rsp, 0x08
00007e6bc8bd36b8  push rax
00007e6bc8bd36b9  push rcx
00007e6bc8bd36ba  push rdx
00007e6bc8bd36bb  push rdi
00007e6bc8bd36bc  push rsi
00007e6bc8bd36bd  push r8
00007e6bc8bd36bf  push r9
00007e6bc8bd36c1  push r10
00007e6bc8bd36c3  push r11
00007e6bc8bd36c5  sub rsp, 0xF0
00007e6bc8bd36cc  vmovaps [rsp], xmm0
00007e6bc8bd36d1  vmovaps [rsp+0x10], xmm1
00007e6bc8bd36d7  vmovaps [rsp+0x20], xmm2
00007e6bc8bd36dd  vmovaps [rsp+0x30], xmm3
00007e6bc8bd36e3  vmovaps [rsp+0x40], xmm4
00007e6bc8bd36e9  vmovaps [rsp+0x50], xmm5
00007e6bc8bd36ef  vmovaps [rsp+0x60], xmm6
00007e6bc8bd36f5  vmovaps [rsp+0x70], xmm7
00007e6bc8bd36fb  vmovaps [rsp+0x80], xmm8
00007e6bc8bd3704  vmovaps [rsp+0x90], xmm9
00007e6bc8bd370d  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd3716  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd371f  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd3728  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd3731  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd373a  sub rsp, 0x30
00007e6bc8bd373e  movaps [rsp], xmm12
00007e6bc8bd3743  movaps [rsp+0x10], xmm15
00007e6bc8bd3749  movaps [rsp+0x20], xmm13
00007e6bc8bd374f  lea rdi, [rsp]
00007e6bc8bd3753  mov esi, 0x00
00007e6bc8bd3758  mov rax, 0x6543F191D530
00007e6bc8bd3762  call rax
00007e6bc8bd3764  movaps xmm12, [rsp]
00007e6bc8bd3769  add rsp, 0x30
00007e6bc8bd376d  vmovaps xmm0, [rsp]
00007e6bc8bd3772  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd3778  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd377e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd3784  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd378a  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd3790  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd3796  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd379c  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd37a5  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd37ae  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd37b7  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd37c0  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd37c9  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd37d2  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd37db  add rsp, 0xF0
00007e6bc8bd37e2  pop r11
00007e6bc8bd37e4  pop r10
00007e6bc8bd37e6  pop r9
00007e6bc8bd37e8  pop r8
00007e6bc8bd37ea  pop rsi
00007e6bc8bd37eb  pop rdi
00007e6bc8bd37ec  pop rdx
00007e6bc8bd37ed  pop rcx
00007e6bc8bd37ee  pop rax
00007e6bc8bd37ef  add rsp, 0x08
00007e6bc8bd37f3  jmp 0x00007E6BC8BCFF34
00007e6bc8bd37f8  sub rsp, 0x08
00007e6bc8bd37fc  push rax
00007e6bc8bd37fd  push rcx
00007e6bc8bd37fe  push rdx
00007e6bc8bd37ff  push rdi
00007e6bc8bd3800  push rsi
00007e6bc8bd3801  push r8
00007e6bc8bd3803  push r9
00007e6bc8bd3805  push r10
00007e6bc8bd3807  push r11
00007e6bc8bd3809  sub rsp, 0xF0
00007e6bc8bd3810  vmovaps [rsp], xmm0
00007e6bc8bd3815  vmovaps [rsp+0x10], xmm1
00007e6bc8bd381b  vmovaps [rsp+0x20], xmm2
00007e6bc8bd3821  vmovaps [rsp+0x30], xmm3
00007e6bc8bd3827  vmovaps [rsp+0x40], xmm4
00007e6bc8bd382d  vmovaps [rsp+0x50], xmm5
00007e6bc8bd3833  vmovaps [rsp+0x60], xmm6
00007e6bc8bd3839  vmovaps [rsp+0x70], xmm7
00007e6bc8bd383f  vmovaps [rsp+0x80], xmm8
00007e6bc8bd3848  vmovaps [rsp+0x90], xmm9
00007e6bc8bd3851  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd385a  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd3863  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd386c  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd3875  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd387e  sub rsp, 0x30
00007e6bc8bd3882  movaps [rsp], xmm15
00007e6bc8bd3887  movaps [rsp+0x10], xmm13
00007e6bc8bd388d  movaps [rsp+0x20], xmm10
00007e6bc8bd3893  lea rdi, [rsp]
00007e6bc8bd3897  mov esi, 0x00
00007e6bc8bd389c  mov rax, 0x6543F191D530
00007e6bc8bd38a6  call rax
00007e6bc8bd38a8  movaps xmm15, [rsp]
00007e6bc8bd38ad  add rsp, 0x30
00007e6bc8bd38b1  vmovaps xmm0, [rsp]
00007e6bc8bd38b6  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd38bc  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd38c2  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd38c8  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd38ce  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd38d4  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd38da  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd38e0  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd38e9  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd38f2  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd38fb  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd3904  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd390d  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd3916  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd391f  add rsp, 0xF0
00007e6bc8bd3926  pop r11
00007e6bc8bd3928  pop r10
00007e6bc8bd392a  pop r9
00007e6bc8bd392c  pop r8
00007e6bc8bd392e  pop rsi
00007e6bc8bd392f  pop rdi
00007e6bc8bd3930  pop rdx
00007e6bc8bd3931  pop rcx
00007e6bc8bd3932  pop rax
00007e6bc8bd3933  add rsp, 0x08
00007e6bc8bd3937  jmp 0x00007E6BC8BCFF55
00007e6bc8bd393c  call 0x00007E6BC8A0C260
00007e6bc8bd3941  jmp 0x00007E6BC8BCFFB0
00007e6bc8bd3946  sub rsp, 0x08
00007e6bc8bd394a  push rax
00007e6bc8bd394b  push rcx
00007e6bc8bd394c  push rdx
00007e6bc8bd394d  push rdi
00007e6bc8bd394e  push rsi
00007e6bc8bd394f  push r8
00007e6bc8bd3951  push r9
00007e6bc8bd3953  push r10
00007e6bc8bd3955  push r11
00007e6bc8bd3957  sub rsp, 0xF0
00007e6bc8bd395e  vmovaps [rsp], xmm0
00007e6bc8bd3963  vmovaps [rsp+0x10], xmm1
00007e6bc8bd3969  vmovaps [rsp+0x20], xmm2
00007e6bc8bd396f  vmovaps [rsp+0x30], xmm3
00007e6bc8bd3975  vmovaps [rsp+0x40], xmm4
00007e6bc8bd397b  vmovaps [rsp+0x50], xmm5
00007e6bc8bd3981  vmovaps [rsp+0x60], xmm6
00007e6bc8bd3987  vmovaps [rsp+0x70], xmm7
00007e6bc8bd398d  vmovaps [rsp+0x80], xmm8
00007e6bc8bd3996  vmovaps [rsp+0x90], xmm10
00007e6bc8bd399f  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd39a8  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd39b1  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd39ba  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd39c3  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd39cc  sub rsp, 0x30
00007e6bc8bd39d0  movaps [rsp], xmm9
00007e6bc8bd39d5  movaps [rsp+0x10], xmm8
00007e6bc8bd39db  movaps [rsp+0x20], xmm10
00007e6bc8bd39e1  lea rdi, [rsp]
00007e6bc8bd39e5  mov esi, 0x00
00007e6bc8bd39ea  mov rax, 0x6543F191D530
00007e6bc8bd39f4  call rax
00007e6bc8bd39f6  movaps xmm9, [rsp]
00007e6bc8bd39fb  add rsp, 0x30
00007e6bc8bd39ff  vmovaps xmm0, [rsp]
00007e6bc8bd3a04  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd3a0a  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd3a10  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd3a16  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd3a1c  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd3a22  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd3a28  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd3a2e  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd3a37  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd3a40  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd3a49  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd3a52  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd3a5b  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd3a64  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd3a6d  add rsp, 0xF0
00007e6bc8bd3a74  pop r11
00007e6bc8bd3a76  pop r10
00007e6bc8bd3a78  pop r9
00007e6bc8bd3a7a  pop r8
00007e6bc8bd3a7c  pop rsi
00007e6bc8bd3a7d  pop rdi
00007e6bc8bd3a7e  pop rdx
00007e6bc8bd3a7f  pop rcx
00007e6bc8bd3a80  pop rax
00007e6bc8bd3a81  add rsp, 0x08
00007e6bc8bd3a85  jmp 0x00007E6BC8BCFFE1
00007e6bc8bd3a8a  sub rsp, 0x08
00007e6bc8bd3a8e  push rax
00007e6bc8bd3a8f  push rcx
00007e6bc8bd3a90  push rdx
00007e6bc8bd3a91  push rdi
00007e6bc8bd3a92  push rsi
00007e6bc8bd3a93  push r8
00007e6bc8bd3a95  push r9
00007e6bc8bd3a97  push r10
00007e6bc8bd3a99  push r11
00007e6bc8bd3a9b  sub rsp, 0xF0
00007e6bc8bd3aa2  vmovaps [rsp], xmm0
00007e6bc8bd3aa7  vmovaps [rsp+0x10], xmm1
00007e6bc8bd3aad  vmovaps [rsp+0x20], xmm2
00007e6bc8bd3ab3  vmovaps [rsp+0x30], xmm3
00007e6bc8bd3ab9  vmovaps [rsp+0x40], xmm4
00007e6bc8bd3abf  vmovaps [rsp+0x50], xmm5
00007e6bc8bd3ac5  vmovaps [rsp+0x60], xmm6
00007e6bc8bd3acb  vmovaps [rsp+0x70], xmm7
00007e6bc8bd3ad1  vmovaps [rsp+0x80], xmm8
00007e6bc8bd3ada  vmovaps [rsp+0x90], xmm9
00007e6bc8bd3ae3  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd3aec  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd3af5  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd3afe  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd3b07  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd3b10  sub rsp, 0x30
00007e6bc8bd3b14  movaps [rsp], xmm10
00007e6bc8bd3b19  movaps [rsp+0x10], xmm1
00007e6bc8bd3b1e  movaps [rsp+0x20], xmm11
00007e6bc8bd3b24  lea rdi, [rsp]
00007e6bc8bd3b28  mov esi, 0x00
00007e6bc8bd3b2d  mov rax, 0x6543F191D530
00007e6bc8bd3b37  call rax
00007e6bc8bd3b39  movaps xmm10, [rsp]
00007e6bc8bd3b3e  add rsp, 0x30
00007e6bc8bd3b42  vmovaps xmm0, [rsp]
00007e6bc8bd3b47  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd3b4d  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd3b53  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd3b59  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd3b5f  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd3b65  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd3b6b  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd3b71  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd3b7a  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd3b83  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd3b8c  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd3b95  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd3b9e  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd3ba7  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd3bb0  add rsp, 0xF0
00007e6bc8bd3bb7  pop r11
00007e6bc8bd3bb9  pop r10
00007e6bc8bd3bbb  pop r9
00007e6bc8bd3bbd  pop r8
00007e6bc8bd3bbf  pop rsi
00007e6bc8bd3bc0  pop rdi
00007e6bc8bd3bc1  pop rdx
00007e6bc8bd3bc2  pop rcx
00007e6bc8bd3bc3  pop rax
00007e6bc8bd3bc4  add rsp, 0x08
00007e6bc8bd3bc8  jmp 0x00007E6BC8BCFFFC
00007e6bc8bd3bcd  sub rsp, 0x08
00007e6bc8bd3bd1  push rax
00007e6bc8bd3bd2  push rcx
00007e6bc8bd3bd3  push rdx
00007e6bc8bd3bd4  push rdi
00007e6bc8bd3bd5  push rsi
00007e6bc8bd3bd6  push r8
00007e6bc8bd3bd8  push r9
00007e6bc8bd3bda  push r10
00007e6bc8bd3bdc  push r11
00007e6bc8bd3bde  sub rsp, 0xF0
00007e6bc8bd3be5  vmovaps [rsp], xmm0
00007e6bc8bd3bea  vmovaps [rsp+0x10], xmm2
00007e6bc8bd3bf0  vmovaps [rsp+0x20], xmm3
00007e6bc8bd3bf6  vmovaps [rsp+0x30], xmm4
00007e6bc8bd3bfc  vmovaps [rsp+0x40], xmm5
00007e6bc8bd3c02  vmovaps [rsp+0x50], xmm6
00007e6bc8bd3c08  vmovaps [rsp+0x60], xmm7
00007e6bc8bd3c0e  vmovaps [rsp+0x70], xmm8
00007e6bc8bd3c14  vmovaps [rsp+0x80], xmm9
00007e6bc8bd3c1d  vmovaps [rsp+0x90], xmm10
00007e6bc8bd3c26  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd3c2f  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd3c38  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd3c41  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd3c4a  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd3c53  sub rsp, 0x30
00007e6bc8bd3c57  movaps [rsp], xmm1
00007e6bc8bd3c5b  movaps [rsp+0x10], xmm14
00007e6bc8bd3c61  movaps [rsp+0x20], xmm6
00007e6bc8bd3c66  lea rdi, [rsp]
00007e6bc8bd3c6a  mov esi, 0x00
00007e6bc8bd3c6f  mov rax, 0x6543F191D530
00007e6bc8bd3c79  call rax
00007e6bc8bd3c7b  movaps xmm1, [rsp]
00007e6bc8bd3c7f  add rsp, 0x30
00007e6bc8bd3c83  vmovaps xmm0, [rsp]
00007e6bc8bd3c88  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd3c8e  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd3c94  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd3c9a  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd3ca0  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd3ca6  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd3cac  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd3cb2  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd3cbb  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd3cc4  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd3ccd  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd3cd6  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd3cdf  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd3ce8  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd3cf1  add rsp, 0xF0
00007e6bc8bd3cf8  pop r11
00007e6bc8bd3cfa  pop r10
00007e6bc8bd3cfc  pop r9
00007e6bc8bd3cfe  pop r8
00007e6bc8bd3d00  pop rsi
00007e6bc8bd3d01  pop rdi
00007e6bc8bd3d02  pop rdx
00007e6bc8bd3d03  pop rcx
00007e6bc8bd3d04  pop rax
00007e6bc8bd3d05  add rsp, 0x08
00007e6bc8bd3d09  jmp 0x00007E6BC8BD0015
00007e6bc8bd3d0e  sub rsp, 0x08
00007e6bc8bd3d12  push rax
00007e6bc8bd3d13  push rcx
00007e6bc8bd3d14  push rdx
00007e6bc8bd3d15  push rdi
00007e6bc8bd3d16  push rsi
00007e6bc8bd3d17  push r8
00007e6bc8bd3d19  push r9
00007e6bc8bd3d1b  push r10
00007e6bc8bd3d1d  push r11
00007e6bc8bd3d1f  sub rsp, 0xF0
00007e6bc8bd3d26  vmovaps [rsp], xmm0
00007e6bc8bd3d2b  vmovaps [rsp+0x10], xmm1
00007e6bc8bd3d31  vmovaps [rsp+0x20], xmm2
00007e6bc8bd3d37  vmovaps [rsp+0x30], xmm3
00007e6bc8bd3d3d  vmovaps [rsp+0x40], xmm4
00007e6bc8bd3d43  vmovaps [rsp+0x50], xmm5
00007e6bc8bd3d49  vmovaps [rsp+0x60], xmm6
00007e6bc8bd3d4f  vmovaps [rsp+0x70], xmm7
00007e6bc8bd3d55  vmovaps [rsp+0x80], xmm8
00007e6bc8bd3d5e  vmovaps [rsp+0x90], xmm9
00007e6bc8bd3d67  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd3d70  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd3d79  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd3d82  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd3d8b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd3d94  sub rsp, 0x30
00007e6bc8bd3d98  movaps [rsp], xmm11
00007e6bc8bd3d9d  movaps [rsp+0x10], xmm13
00007e6bc8bd3da3  movaps [rsp+0x20], xmm14
00007e6bc8bd3da9  lea rdi, [rsp]
00007e6bc8bd3dad  mov esi, 0x00
00007e6bc8bd3db2  mov rax, 0x6543F191D530
00007e6bc8bd3dbc  call rax
00007e6bc8bd3dbe  movaps xmm11, [rsp]
00007e6bc8bd3dc3  add rsp, 0x30
00007e6bc8bd3dc7  vmovaps xmm0, [rsp]
00007e6bc8bd3dcc  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd3dd2  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd3dd8  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd3dde  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd3de4  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd3dea  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd3df0  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd3df6  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd3dff  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd3e08  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd3e11  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd3e1a  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd3e23  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd3e2c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd3e35  add rsp, 0xF0
00007e6bc8bd3e3c  pop r11
00007e6bc8bd3e3e  pop r10
00007e6bc8bd3e40  pop r9
00007e6bc8bd3e42  pop r8
00007e6bc8bd3e44  pop rsi
00007e6bc8bd3e45  pop rdi
00007e6bc8bd3e46  pop rdx
00007e6bc8bd3e47  pop rcx
00007e6bc8bd3e48  pop rax
00007e6bc8bd3e49  add rsp, 0x08
00007e6bc8bd3e4d  jmp 0x00007E6BC8BD003F
00007e6bc8bd3e52  sub rsp, 0x08
00007e6bc8bd3e56  push rax
00007e6bc8bd3e57  push rcx
00007e6bc8bd3e58  push rdx
00007e6bc8bd3e59  push rdi
00007e6bc8bd3e5a  push rsi
00007e6bc8bd3e5b  push r8
00007e6bc8bd3e5d  push r9
00007e6bc8bd3e5f  push r10
00007e6bc8bd3e61  push r11
00007e6bc8bd3e63  sub rsp, 0xF0
00007e6bc8bd3e6a  vmovaps [rsp], xmm0
00007e6bc8bd3e6f  vmovaps [rsp+0x10], xmm1
00007e6bc8bd3e75  vmovaps [rsp+0x20], xmm2
00007e6bc8bd3e7b  vmovaps [rsp+0x30], xmm3
00007e6bc8bd3e81  vmovaps [rsp+0x40], xmm4
00007e6bc8bd3e87  vmovaps [rsp+0x50], xmm5
00007e6bc8bd3e8d  vmovaps [rsp+0x60], xmm6
00007e6bc8bd3e93  vmovaps [rsp+0x70], xmm7
00007e6bc8bd3e99  vmovaps [rsp+0x80], xmm8
00007e6bc8bd3ea2  vmovaps [rsp+0x90], xmm9
00007e6bc8bd3eab  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd3eb4  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd3ebd  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd3ec6  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd3ecf  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd3ed8  sub rsp, 0x30
00007e6bc8bd3edc  movaps [rsp], xmm13
00007e6bc8bd3ee1  movaps [rsp+0x10], xmm8
00007e6bc8bd3ee7  movaps [rsp+0x20], xmm14
00007e6bc8bd3eed  lea rdi, [rsp]
00007e6bc8bd3ef1  mov esi, 0x00
00007e6bc8bd3ef6  mov rax, 0x6543F191D530
00007e6bc8bd3f00  call rax
00007e6bc8bd3f02  movaps xmm13, [rsp]
00007e6bc8bd3f07  add rsp, 0x30
00007e6bc8bd3f0b  vmovaps xmm0, [rsp]
00007e6bc8bd3f10  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd3f16  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd3f1c  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd3f22  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd3f28  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd3f2e  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd3f34  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd3f3a  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd3f43  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd3f4c  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd3f55  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd3f5e  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd3f67  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd3f70  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd3f79  add rsp, 0xF0
00007e6bc8bd3f80  pop r11
00007e6bc8bd3f82  pop r10
00007e6bc8bd3f84  pop r9
00007e6bc8bd3f86  pop r8
00007e6bc8bd3f88  pop rsi
00007e6bc8bd3f89  pop rdi
00007e6bc8bd3f8a  pop rdx
00007e6bc8bd3f8b  pop rcx
00007e6bc8bd3f8c  pop rax
00007e6bc8bd3f8d  add rsp, 0x08
00007e6bc8bd3f91  jmp 0x00007E6BC8BD006E
00007e6bc8bd3f96  sub rsp, 0x08
00007e6bc8bd3f9a  push rax
00007e6bc8bd3f9b  push rcx
00007e6bc8bd3f9c  push rdx
00007e6bc8bd3f9d  push rdi
00007e6bc8bd3f9e  push rsi
00007e6bc8bd3f9f  push r8
00007e6bc8bd3fa1  push r9
00007e6bc8bd3fa3  push r10
00007e6bc8bd3fa5  push r11
00007e6bc8bd3fa7  sub rsp, 0xF0
00007e6bc8bd3fae  vmovaps [rsp], xmm0
00007e6bc8bd3fb3  vmovaps [rsp+0x10], xmm1
00007e6bc8bd3fb9  vmovaps [rsp+0x20], xmm2
00007e6bc8bd3fbf  vmovaps [rsp+0x30], xmm3
00007e6bc8bd3fc5  vmovaps [rsp+0x40], xmm4
00007e6bc8bd3fcb  vmovaps [rsp+0x50], xmm5
00007e6bc8bd3fd1  vmovaps [rsp+0x60], xmm6
00007e6bc8bd3fd7  vmovaps [rsp+0x70], xmm7
00007e6bc8bd3fdd  vmovaps [rsp+0x80], xmm9
00007e6bc8bd3fe6  vmovaps [rsp+0x90], xmm10
00007e6bc8bd3fef  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd3ff8  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd4001  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd400a  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd4013  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd401c  sub rsp, 0x30
00007e6bc8bd4020  movaps [rsp], xmm8
00007e6bc8bd4025  movaps [rsp+0x10], xmm7
00007e6bc8bd402a  movaps [rsp+0x20], xmm14
00007e6bc8bd4030  lea rdi, [rsp]
00007e6bc8bd4034  mov esi, 0x00
00007e6bc8bd4039  mov rax, 0x6543F191D530
00007e6bc8bd4043  call rax
00007e6bc8bd4045  movaps xmm8, [rsp]
00007e6bc8bd404a  add rsp, 0x30
00007e6bc8bd404e  vmovaps xmm0, [rsp]
00007e6bc8bd4053  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd4059  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd405f  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd4065  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd406b  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd4071  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd4077  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd407d  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd4086  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd408f  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd4098  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd40a1  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd40aa  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd40b3  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd40bc  add rsp, 0xF0
00007e6bc8bd40c3  pop r11
00007e6bc8bd40c5  pop r10
00007e6bc8bd40c7  pop r9
00007e6bc8bd40c9  pop r8
00007e6bc8bd40cb  pop rsi
00007e6bc8bd40cc  pop rdi
00007e6bc8bd40cd  pop rdx
00007e6bc8bd40ce  pop rcx
00007e6bc8bd40cf  pop rax
00007e6bc8bd40d0  add rsp, 0x08
00007e6bc8bd40d4  jmp 0x00007E6BC8BD0094
00007e6bc8bd40d9  sub rsp, 0x08
00007e6bc8bd40dd  push rax
00007e6bc8bd40de  push rcx
00007e6bc8bd40df  push rdx
00007e6bc8bd40e0  push rdi
00007e6bc8bd40e1  push rsi
00007e6bc8bd40e2  push r8
00007e6bc8bd40e4  push r9
00007e6bc8bd40e6  push r10
00007e6bc8bd40e8  push r11
00007e6bc8bd40ea  sub rsp, 0xF0
00007e6bc8bd40f1  vmovaps [rsp], xmm0
00007e6bc8bd40f6  vmovaps [rsp+0x10], xmm1
00007e6bc8bd40fc  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4102  vmovaps [rsp+0x30], xmm3
00007e6bc8bd4108  vmovaps [rsp+0x40], xmm4
00007e6bc8bd410e  vmovaps [rsp+0x50], xmm5
00007e6bc8bd4114  vmovaps [rsp+0x60], xmm6
00007e6bc8bd411a  vmovaps [rsp+0x70], xmm7
00007e6bc8bd4120  vmovaps [rsp+0x80], xmm8
00007e6bc8bd4129  vmovaps [rsp+0x90], xmm9
00007e6bc8bd4132  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd413b  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd4144  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd414d  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd4156  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd415f  sub rsp, 0x30
00007e6bc8bd4163  movaps [rsp], xmm14
00007e6bc8bd4168  movaps [rsp+0x10], xmm12
00007e6bc8bd416e  movaps [rsp+0x20], xmm9
00007e6bc8bd4174  lea rdi, [rsp]
00007e6bc8bd4178  mov esi, 0x00
00007e6bc8bd417d  mov rax, 0x6543F191D530
00007e6bc8bd4187  call rax
00007e6bc8bd4189  movaps xmm14, [rsp]
00007e6bc8bd418e  add rsp, 0x30
00007e6bc8bd4192  vmovaps xmm0, [rsp]
00007e6bc8bd4197  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd419d  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd41a3  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd41a9  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd41af  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd41b5  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd41bb  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd41c1  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd41ca  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd41d3  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd41dc  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd41e5  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd41ee  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd41f7  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4200  add rsp, 0xF0
00007e6bc8bd4207  pop r11
00007e6bc8bd4209  pop r10
00007e6bc8bd420b  pop r9
00007e6bc8bd420d  pop r8
00007e6bc8bd420f  pop rsi
00007e6bc8bd4210  pop rdi
00007e6bc8bd4211  pop rdx
00007e6bc8bd4212  pop rcx
00007e6bc8bd4213  pop rax
00007e6bc8bd4214  add rsp, 0x08
00007e6bc8bd4218  jmp 0x00007E6BC8BD00AE
00007e6bc8bd421d  sub rsp, 0x08
00007e6bc8bd4221  push rax
00007e6bc8bd4222  push rcx
00007e6bc8bd4223  push rdx
00007e6bc8bd4224  push rdi
00007e6bc8bd4225  push rsi
00007e6bc8bd4226  push r8
00007e6bc8bd4228  push r9
00007e6bc8bd422a  push r10
00007e6bc8bd422c  push r11
00007e6bc8bd422e  sub rsp, 0xF0
00007e6bc8bd4235  vmovaps [rsp], xmm0
00007e6bc8bd423a  vmovaps [rsp+0x10], xmm1
00007e6bc8bd4240  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4246  vmovaps [rsp+0x30], xmm3
00007e6bc8bd424c  vmovaps [rsp+0x40], xmm4
00007e6bc8bd4252  vmovaps [rsp+0x50], xmm5
00007e6bc8bd4258  vmovaps [rsp+0x60], xmm6
00007e6bc8bd425e  vmovaps [rsp+0x70], xmm7
00007e6bc8bd4264  vmovaps [rsp+0x80], xmm8
00007e6bc8bd426d  vmovaps [rsp+0x90], xmm10
00007e6bc8bd4276  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd427f  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd4288  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd4291  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd429a  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd42a3  sub rsp, 0x30
00007e6bc8bd42a7  movaps [rsp], xmm9
00007e6bc8bd42ac  movaps [rsp+0x10], xmm7
00007e6bc8bd42b1  movaps [rsp+0x20], xmm12
00007e6bc8bd42b7  lea rdi, [rsp]
00007e6bc8bd42bb  mov esi, 0x00
00007e6bc8bd42c0  mov rax, 0x6543F191D530
00007e6bc8bd42ca  call rax
00007e6bc8bd42cc  movaps xmm9, [rsp]
00007e6bc8bd42d1  add rsp, 0x30
00007e6bc8bd42d5  vmovaps xmm0, [rsp]
00007e6bc8bd42da  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd42e0  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd42e6  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd42ec  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd42f2  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd42f8  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd42fe  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd4304  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd430d  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd4316  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd431f  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd4328  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd4331  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd433a  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4343  add rsp, 0xF0
00007e6bc8bd434a  pop r11
00007e6bc8bd434c  pop r10
00007e6bc8bd434e  pop r9
00007e6bc8bd4350  pop r8
00007e6bc8bd4352  pop rsi
00007e6bc8bd4353  pop rdi
00007e6bc8bd4354  pop rdx
00007e6bc8bd4355  pop rcx
00007e6bc8bd4356  pop rax
00007e6bc8bd4357  add rsp, 0x08
00007e6bc8bd435b  jmp 0x00007E6BC8BD00DD
00007e6bc8bd4360  sub rsp, 0x08
00007e6bc8bd4364  push rax
00007e6bc8bd4365  push rcx
00007e6bc8bd4366  push rdx
00007e6bc8bd4367  push rdi
00007e6bc8bd4368  push rsi
00007e6bc8bd4369  push r8
00007e6bc8bd436b  push r9
00007e6bc8bd436d  push r10
00007e6bc8bd436f  push r11
00007e6bc8bd4371  sub rsp, 0xF0
00007e6bc8bd4378  vmovaps [rsp], xmm0
00007e6bc8bd437d  vmovaps [rsp+0x10], xmm1
00007e6bc8bd4383  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4389  vmovaps [rsp+0x30], xmm3
00007e6bc8bd438f  vmovaps [rsp+0x40], xmm4
00007e6bc8bd4395  vmovaps [rsp+0x50], xmm5
00007e6bc8bd439b  vmovaps [rsp+0x60], xmm6
00007e6bc8bd43a1  vmovaps [rsp+0x70], xmm7
00007e6bc8bd43a7  vmovaps [rsp+0x80], xmm8
00007e6bc8bd43b0  vmovaps [rsp+0x90], xmm9
00007e6bc8bd43b9  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd43c2  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd43cb  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd43d4  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd43dd  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd43e6  sub rsp, 0x30
00007e6bc8bd43ea  movaps [rsp], xmm12
00007e6bc8bd43ef  movaps [rsp+0x10], xmm15
00007e6bc8bd43f5  movaps [rsp+0x20], xmm11
00007e6bc8bd43fb  lea rdi, [rsp]
00007e6bc8bd43ff  mov esi, 0x00
00007e6bc8bd4404  mov rax, 0x6543F191D530
00007e6bc8bd440e  call rax
00007e6bc8bd4410  movaps xmm12, [rsp]
00007e6bc8bd4415  add rsp, 0x30
00007e6bc8bd4419  vmovaps xmm0, [rsp]
00007e6bc8bd441e  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd4424  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd442a  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd4430  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd4436  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd443c  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd4442  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd4448  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd4451  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd445a  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd4463  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd446c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd4475  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd447e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4487  add rsp, 0xF0
00007e6bc8bd448e  pop r11
00007e6bc8bd4490  pop r10
00007e6bc8bd4492  pop r9
00007e6bc8bd4494  pop r8
00007e6bc8bd4496  pop rsi
00007e6bc8bd4497  pop rdi
00007e6bc8bd4498  pop rdx
00007e6bc8bd4499  pop rcx
00007e6bc8bd449a  pop rax
00007e6bc8bd449b  add rsp, 0x08
00007e6bc8bd449f  jmp 0x00007E6BC8BD00F7
00007e6bc8bd44a4  sub rsp, 0x08
00007e6bc8bd44a8  push rax
00007e6bc8bd44a9  push rcx
00007e6bc8bd44aa  push rdx
00007e6bc8bd44ab  push rdi
00007e6bc8bd44ac  push rsi
00007e6bc8bd44ad  push r8
00007e6bc8bd44af  push r9
00007e6bc8bd44b1  push r10
00007e6bc8bd44b3  push r11
00007e6bc8bd44b5  sub rsp, 0xF0
00007e6bc8bd44bc  vmovaps [rsp], xmm0
00007e6bc8bd44c1  vmovaps [rsp+0x10], xmm1
00007e6bc8bd44c7  vmovaps [rsp+0x20], xmm2
00007e6bc8bd44cd  vmovaps [rsp+0x30], xmm3
00007e6bc8bd44d3  vmovaps [rsp+0x40], xmm4
00007e6bc8bd44d9  vmovaps [rsp+0x50], xmm5
00007e6bc8bd44df  vmovaps [rsp+0x60], xmm6
00007e6bc8bd44e5  vmovaps [rsp+0x70], xmm7
00007e6bc8bd44eb  vmovaps [rsp+0x80], xmm8
00007e6bc8bd44f4  vmovaps [rsp+0x90], xmm9
00007e6bc8bd44fd  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd4506  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd450f  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd4518  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd4521  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd452a  sub rsp, 0x30
00007e6bc8bd452e  movaps [rsp], xmm11
00007e6bc8bd4533  movaps [rsp+0x10], xmm7
00007e6bc8bd4538  movaps [rsp+0x20], xmm15
00007e6bc8bd453e  lea rdi, [rsp]
00007e6bc8bd4542  mov esi, 0x00
00007e6bc8bd4547  mov rax, 0x6543F191D530
00007e6bc8bd4551  call rax
00007e6bc8bd4553  movaps xmm11, [rsp]
00007e6bc8bd4558  add rsp, 0x30
00007e6bc8bd455c  vmovaps xmm0, [rsp]
00007e6bc8bd4561  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd4567  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd456d  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd4573  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd4579  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd457f  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd4585  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd458b  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd4594  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd459d  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd45a6  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd45af  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd45b8  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd45c1  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd45ca  add rsp, 0xF0
00007e6bc8bd45d1  pop r11
00007e6bc8bd45d3  pop r10
00007e6bc8bd45d5  pop r9
00007e6bc8bd45d7  pop r8
00007e6bc8bd45d9  pop rsi
00007e6bc8bd45da  pop rdi
00007e6bc8bd45db  pop rdx
00007e6bc8bd45dc  pop rcx
00007e6bc8bd45dd  pop rax
00007e6bc8bd45de  add rsp, 0x08
00007e6bc8bd45e2  jmp 0x00007E6BC8BD0123
00007e6bc8bd45e7  sub rsp, 0x08
00007e6bc8bd45eb  push rax
00007e6bc8bd45ec  push rcx
00007e6bc8bd45ed  push rdx
00007e6bc8bd45ee  push rdi
00007e6bc8bd45ef  push rsi
00007e6bc8bd45f0  push r8
00007e6bc8bd45f2  push r9
00007e6bc8bd45f4  push r10
00007e6bc8bd45f6  push r11
00007e6bc8bd45f8  sub rsp, 0xF0
00007e6bc8bd45ff  vmovaps [rsp], xmm0
00007e6bc8bd4604  vmovaps [rsp+0x10], xmm1
00007e6bc8bd460a  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4610  vmovaps [rsp+0x30], xmm3
00007e6bc8bd4616  vmovaps [rsp+0x40], xmm4
00007e6bc8bd461c  vmovaps [rsp+0x50], xmm5
00007e6bc8bd4622  vmovaps [rsp+0x60], xmm6
00007e6bc8bd4628  vmovaps [rsp+0x70], xmm7
00007e6bc8bd462e  vmovaps [rsp+0x80], xmm8
00007e6bc8bd4637  vmovaps [rsp+0x90], xmm9
00007e6bc8bd4640  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd4649  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd4652  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd465b  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd4664  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd466d  sub rsp, 0x30
00007e6bc8bd4671  movaps [rsp], xmm15
00007e6bc8bd4676  movaps [rsp+0x10], xmm10
00007e6bc8bd467c  movaps [rsp+0x20], xmm13
00007e6bc8bd4682  lea rdi, [rsp]
00007e6bc8bd4686  mov esi, 0x00
00007e6bc8bd468b  mov rax, 0x6543F191D530
00007e6bc8bd4695  call rax
00007e6bc8bd4697  movaps xmm15, [rsp]
00007e6bc8bd469c  add rsp, 0x30
00007e6bc8bd46a0  vmovaps xmm0, [rsp]
00007e6bc8bd46a5  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd46ab  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd46b1  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd46b7  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd46bd  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd46c3  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd46c9  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd46cf  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd46d8  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd46e1  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd46ea  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd46f3  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd46fc  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd4705  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd470e  add rsp, 0xF0
00007e6bc8bd4715  pop r11
00007e6bc8bd4717  pop r10
00007e6bc8bd4719  pop r9
00007e6bc8bd471b  pop r8
00007e6bc8bd471d  pop rsi
00007e6bc8bd471e  pop rdi
00007e6bc8bd471f  pop rdx
00007e6bc8bd4720  pop rcx
00007e6bc8bd4721  pop rax
00007e6bc8bd4722  add rsp, 0x08
00007e6bc8bd4726  jmp 0x00007E6BC8BD013D
00007e6bc8bd472b  sub rsp, 0x08
00007e6bc8bd472f  push rax
00007e6bc8bd4730  push rcx
00007e6bc8bd4731  push rdx
00007e6bc8bd4732  push rdi
00007e6bc8bd4733  push rsi
00007e6bc8bd4734  push r8
00007e6bc8bd4736  push r9
00007e6bc8bd4738  push r10
00007e6bc8bd473a  push r11
00007e6bc8bd473c  sub rsp, 0xF0
00007e6bc8bd4743  vmovaps [rsp], xmm0
00007e6bc8bd4748  vmovaps [rsp+0x10], xmm1
00007e6bc8bd474e  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4754  vmovaps [rsp+0x30], xmm3
00007e6bc8bd475a  vmovaps [rsp+0x40], xmm4
00007e6bc8bd4760  vmovaps [rsp+0x50], xmm5
00007e6bc8bd4766  vmovaps [rsp+0x60], xmm6
00007e6bc8bd476c  vmovaps [rsp+0x70], xmm7
00007e6bc8bd4772  vmovaps [rsp+0x80], xmm8
00007e6bc8bd477b  vmovaps [rsp+0x90], xmm9
00007e6bc8bd4784  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd478d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd4796  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd479f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd47a8  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd47b1  sub rsp, 0x30
00007e6bc8bd47b5  movaps [rsp], xmm10
00007e6bc8bd47ba  movaps [rsp+0x10], xmm7
00007e6bc8bd47bf  movaps [rsp+0x20], xmm13
00007e6bc8bd47c5  lea rdi, [rsp]
00007e6bc8bd47c9  mov esi, 0x00
00007e6bc8bd47ce  mov rax, 0x6543F191D530
00007e6bc8bd47d8  call rax
00007e6bc8bd47da  movaps xmm10, [rsp]
00007e6bc8bd47df  add rsp, 0x30
00007e6bc8bd47e3  vmovaps xmm0, [rsp]
00007e6bc8bd47e8  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd47ee  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd47f4  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd47fa  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd4800  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd4806  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd480c  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd4812  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd481b  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd4824  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd482d  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd4836  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd483f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd4848  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4851  add rsp, 0xF0
00007e6bc8bd4858  pop r11
00007e6bc8bd485a  pop r10
00007e6bc8bd485c  pop r9
00007e6bc8bd485e  pop r8
00007e6bc8bd4860  pop rsi
00007e6bc8bd4861  pop rdi
00007e6bc8bd4862  pop rdx
00007e6bc8bd4863  pop rcx
00007e6bc8bd4864  pop rax
00007e6bc8bd4865  add rsp, 0x08
00007e6bc8bd4869  jmp 0x00007E6BC8BD0169
00007e6bc8bd486e  sub rsp, 0x08
00007e6bc8bd4872  push rax
00007e6bc8bd4873  push rcx
00007e6bc8bd4874  push rdx
00007e6bc8bd4875  push rdi
00007e6bc8bd4876  push rsi
00007e6bc8bd4877  push r8
00007e6bc8bd4879  push r9
00007e6bc8bd487b  push r10
00007e6bc8bd487d  push r11
00007e6bc8bd487f  sub rsp, 0xF0
00007e6bc8bd4886  vmovaps [rsp], xmm0
00007e6bc8bd488b  vmovaps [rsp+0x10], xmm1
00007e6bc8bd4891  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4897  vmovaps [rsp+0x30], xmm3
00007e6bc8bd489d  vmovaps [rsp+0x40], xmm4
00007e6bc8bd48a3  vmovaps [rsp+0x50], xmm5
00007e6bc8bd48a9  vmovaps [rsp+0x60], xmm6
00007e6bc8bd48af  vmovaps [rsp+0x70], xmm7
00007e6bc8bd48b5  vmovaps [rsp+0x80], xmm8
00007e6bc8bd48be  vmovaps [rsp+0x90], xmm9
00007e6bc8bd48c7  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd48d0  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd48d9  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd48e2  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd48eb  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd48f4  sub rsp, 0x30
00007e6bc8bd48f8  movaps [rsp], xmm13
00007e6bc8bd48fd  movaps [rsp+0x10], xmm1
00007e6bc8bd4902  movaps [rsp+0x20], xmm8
00007e6bc8bd4908  lea rdi, [rsp]
00007e6bc8bd490c  mov esi, 0x00
00007e6bc8bd4911  mov rax, 0x6543F191D530
00007e6bc8bd491b  call rax
00007e6bc8bd491d  movaps xmm13, [rsp]
00007e6bc8bd4922  add rsp, 0x30
00007e6bc8bd4926  vmovaps xmm0, [rsp]
00007e6bc8bd492b  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd4931  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd4937  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd493d  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd4943  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd4949  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd494f  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd4955  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd495e  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd4967  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd4970  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd4979  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd4982  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd498b  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4994  add rsp, 0xF0
00007e6bc8bd499b  pop r11
00007e6bc8bd499d  pop r10
00007e6bc8bd499f  pop r9
00007e6bc8bd49a1  pop r8
00007e6bc8bd49a3  pop rsi
00007e6bc8bd49a4  pop rdi
00007e6bc8bd49a5  pop rdx
00007e6bc8bd49a6  pop rcx
00007e6bc8bd49a7  pop rax
00007e6bc8bd49a8  add rsp, 0x08
00007e6bc8bd49ac  jmp 0x00007E6BC8BD0183
00007e6bc8bd49b1  call 0x00007E6BC89FF430
00007e6bc8bd49b6  jmp 0x00007E6BC8BD018D
00007e6bc8bd49bb  sub rsp, 0x08
00007e6bc8bd49bf  push rax
00007e6bc8bd49c0  push rcx
00007e6bc8bd49c1  push rdx
00007e6bc8bd49c2  push rdi
00007e6bc8bd49c3  push rsi
00007e6bc8bd49c4  push r8
00007e6bc8bd49c6  push r9
00007e6bc8bd49c8  push r10
00007e6bc8bd49ca  push r11
00007e6bc8bd49cc  sub rsp, 0xF0
00007e6bc8bd49d3  vmovaps [rsp], xmm0
00007e6bc8bd49d8  vmovaps [rsp+0x10], xmm1
00007e6bc8bd49de  vmovaps [rsp+0x20], xmm2
00007e6bc8bd49e4  vmovaps [rsp+0x30], xmm3
00007e6bc8bd49ea  vmovaps [rsp+0x40], xmm4
00007e6bc8bd49f0  vmovaps [rsp+0x50], xmm5
00007e6bc8bd49f6  vmovaps [rsp+0x60], xmm6
00007e6bc8bd49fc  vmovaps [rsp+0x70], xmm7
00007e6bc8bd4a02  vmovaps [rsp+0x80], xmm9
00007e6bc8bd4a0b  vmovaps [rsp+0x90], xmm10
00007e6bc8bd4a14  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd4a1d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd4a26  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd4a2f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd4a38  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd4a41  sub rsp, 0x30
00007e6bc8bd4a45  movaps [rsp], xmm8
00007e6bc8bd4a4a  movaps [rsp+0x10], xmm14
00007e6bc8bd4a50  movaps [rsp+0x20], xmm9
00007e6bc8bd4a56  lea rdi, [rsp]
00007e6bc8bd4a5a  mov esi, 0x00
00007e6bc8bd4a5f  mov rax, 0x6543F191D530
00007e6bc8bd4a69  call rax
00007e6bc8bd4a6b  movaps xmm8, [rsp]
00007e6bc8bd4a70  add rsp, 0x30
00007e6bc8bd4a74  vmovaps xmm0, [rsp]
00007e6bc8bd4a79  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd4a7f  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd4a85  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd4a8b  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd4a91  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd4a97  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd4a9d  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd4aa3  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd4aac  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd4ab5  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd4abe  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd4ac7  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd4ad0  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd4ad9  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4ae2  add rsp, 0xF0
00007e6bc8bd4ae9  pop r11
00007e6bc8bd4aeb  pop r10
00007e6bc8bd4aed  pop r9
00007e6bc8bd4aef  pop r8
00007e6bc8bd4af1  pop rsi
00007e6bc8bd4af2  pop rdi
00007e6bc8bd4af3  pop rdx
00007e6bc8bd4af4  pop rcx
00007e6bc8bd4af5  pop rax
00007e6bc8bd4af6  add rsp, 0x08
00007e6bc8bd4afa  jmp 0x00007E6BC8BD01AF
00007e6bc8bd4aff  sub rsp, 0x08
00007e6bc8bd4b03  push rax
00007e6bc8bd4b04  push rcx
00007e6bc8bd4b05  push rdx
00007e6bc8bd4b06  push rdi
00007e6bc8bd4b07  push rsi
00007e6bc8bd4b08  push r8
00007e6bc8bd4b0a  push r9
00007e6bc8bd4b0c  push r10
00007e6bc8bd4b0e  push r11
00007e6bc8bd4b10  sub rsp, 0xF0
00007e6bc8bd4b17  vmovaps [rsp], xmm0
00007e6bc8bd4b1c  vmovaps [rsp+0x10], xmm1
00007e6bc8bd4b22  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4b28  vmovaps [rsp+0x30], xmm3
00007e6bc8bd4b2e  vmovaps [rsp+0x40], xmm4
00007e6bc8bd4b34  vmovaps [rsp+0x50], xmm5
00007e6bc8bd4b3a  vmovaps [rsp+0x60], xmm6
00007e6bc8bd4b40  vmovaps [rsp+0x70], xmm7
00007e6bc8bd4b46  vmovaps [rsp+0x80], xmm8
00007e6bc8bd4b4f  vmovaps [rsp+0x90], xmm10
00007e6bc8bd4b58  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd4b61  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd4b6a  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd4b73  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd4b7c  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd4b85  sub rsp, 0x30
00007e6bc8bd4b89  movaps [rsp], xmm9
00007e6bc8bd4b8e  movaps [rsp+0x10], xmm1
00007e6bc8bd4b93  movaps [rsp+0x20], xmm14
00007e6bc8bd4b99  lea rdi, [rsp]
00007e6bc8bd4b9d  mov esi, 0x00
00007e6bc8bd4ba2  mov rax, 0x6543F191D530
00007e6bc8bd4bac  call rax
00007e6bc8bd4bae  movaps xmm9, [rsp]
00007e6bc8bd4bb3  add rsp, 0x30
00007e6bc8bd4bb7  vmovaps xmm0, [rsp]
00007e6bc8bd4bbc  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd4bc2  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd4bc8  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd4bce  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd4bd4  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd4bda  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd4be0  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd4be6  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd4bef  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd4bf8  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd4c01  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd4c0a  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd4c13  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd4c1c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4c25  add rsp, 0xF0
00007e6bc8bd4c2c  pop r11
00007e6bc8bd4c2e  pop r10
00007e6bc8bd4c30  pop r9
00007e6bc8bd4c32  pop r8
00007e6bc8bd4c34  pop rsi
00007e6bc8bd4c35  pop rdi
00007e6bc8bd4c36  pop rdx
00007e6bc8bd4c37  pop rcx
00007e6bc8bd4c38  pop rax
00007e6bc8bd4c39  add rsp, 0x08
00007e6bc8bd4c3d  jmp 0x00007E6BC8BD01DD
00007e6bc8bd4c42  sub rsp, 0x08
00007e6bc8bd4c46  push rax
00007e6bc8bd4c47  push rcx
00007e6bc8bd4c48  push rdx
00007e6bc8bd4c49  push rdi
00007e6bc8bd4c4a  push rsi
00007e6bc8bd4c4b  push r8
00007e6bc8bd4c4d  push r9
00007e6bc8bd4c4f  push r10
00007e6bc8bd4c51  push r11
00007e6bc8bd4c53  sub rsp, 0xF0
00007e6bc8bd4c5a  vmovaps [rsp], xmm0
00007e6bc8bd4c5f  vmovaps [rsp+0x10], xmm1
00007e6bc8bd4c65  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4c6b  vmovaps [rsp+0x30], xmm3
00007e6bc8bd4c71  vmovaps [rsp+0x40], xmm4
00007e6bc8bd4c77  vmovaps [rsp+0x50], xmm5
00007e6bc8bd4c7d  vmovaps [rsp+0x60], xmm6
00007e6bc8bd4c83  vmovaps [rsp+0x70], xmm7
00007e6bc8bd4c89  vmovaps [rsp+0x80], xmm8
00007e6bc8bd4c92  vmovaps [rsp+0x90], xmm9
00007e6bc8bd4c9b  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd4ca4  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd4cad  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd4cb6  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd4cbf  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd4cc8  sub rsp, 0x30
00007e6bc8bd4ccc  movaps [rsp], xmm14
00007e6bc8bd4cd1  movaps [rsp+0x10], xmm4
00007e6bc8bd4cd6  movaps [rsp+0x20], xmm1
00007e6bc8bd4cdb  lea rdi, [rsp]
00007e6bc8bd4cdf  mov esi, 0x00
00007e6bc8bd4ce4  mov rax, 0x6543F191D530
00007e6bc8bd4cee  call rax
00007e6bc8bd4cf0  movaps xmm14, [rsp]
00007e6bc8bd4cf5  add rsp, 0x30
00007e6bc8bd4cf9  vmovaps xmm0, [rsp]
00007e6bc8bd4cfe  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd4d04  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd4d0a  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd4d10  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd4d16  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd4d1c  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd4d22  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd4d28  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd4d31  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd4d3a  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd4d43  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd4d4c  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd4d55  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd4d5e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4d67  add rsp, 0xF0
00007e6bc8bd4d6e  pop r11
00007e6bc8bd4d70  pop r10
00007e6bc8bd4d72  pop r9
00007e6bc8bd4d74  pop r8
00007e6bc8bd4d76  pop rsi
00007e6bc8bd4d77  pop rdi
00007e6bc8bd4d78  pop rdx
00007e6bc8bd4d79  pop rcx
00007e6bc8bd4d7a  pop rax
00007e6bc8bd4d7b  add rsp, 0x08
00007e6bc8bd4d7f  jmp 0x00007E6BC8BD0203
00007e6bc8bd4d84  sub rsp, 0x08
00007e6bc8bd4d88  push rax
00007e6bc8bd4d89  push rcx
00007e6bc8bd4d8a  push rdx
00007e6bc8bd4d8b  push rdi
00007e6bc8bd4d8c  push rsi
00007e6bc8bd4d8d  push r8
00007e6bc8bd4d8f  push r9
00007e6bc8bd4d91  push r10
00007e6bc8bd4d93  push r11
00007e6bc8bd4d95  sub rsp, 0xF0
00007e6bc8bd4d9c  vmovaps [rsp], xmm0
00007e6bc8bd4da1  vmovaps [rsp+0x10], xmm2
00007e6bc8bd4da7  vmovaps [rsp+0x20], xmm3
00007e6bc8bd4dad  vmovaps [rsp+0x30], xmm4
00007e6bc8bd4db3  vmovaps [rsp+0x40], xmm5
00007e6bc8bd4db9  vmovaps [rsp+0x50], xmm6
00007e6bc8bd4dbf  vmovaps [rsp+0x60], xmm7
00007e6bc8bd4dc5  vmovaps [rsp+0x70], xmm8
00007e6bc8bd4dcb  vmovaps [rsp+0x80], xmm9
00007e6bc8bd4dd4  vmovaps [rsp+0x90], xmm10
00007e6bc8bd4ddd  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd4de6  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd4def  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd4df8  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd4e01  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd4e0a  sub rsp, 0x30
00007e6bc8bd4e0e  movaps [rsp], xmm1
00007e6bc8bd4e12  movaps [rsp+0x10], xmm12
00007e6bc8bd4e18  movaps [rsp+0x20], xmm11
00007e6bc8bd4e1e  lea rdi, [rsp]
00007e6bc8bd4e22  mov esi, 0x00
00007e6bc8bd4e27  mov rax, 0x6543F191D530
00007e6bc8bd4e31  call rax
00007e6bc8bd4e33  movaps xmm1, [rsp]
00007e6bc8bd4e37  add rsp, 0x30
00007e6bc8bd4e3b  vmovaps xmm0, [rsp]
00007e6bc8bd4e40  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd4e46  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd4e4c  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd4e52  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd4e58  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd4e5e  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd4e64  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd4e6a  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd4e73  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd4e7c  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd4e85  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd4e8e  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd4e97  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd4ea0  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4ea9  add rsp, 0xF0
00007e6bc8bd4eb0  pop r11
00007e6bc8bd4eb2  pop r10
00007e6bc8bd4eb4  pop r9
00007e6bc8bd4eb6  pop r8
00007e6bc8bd4eb8  pop rsi
00007e6bc8bd4eb9  pop rdi
00007e6bc8bd4eba  pop rdx
00007e6bc8bd4ebb  pop rcx
00007e6bc8bd4ebc  pop rax
00007e6bc8bd4ebd  add rsp, 0x08
00007e6bc8bd4ec1  jmp 0x00007E6BC8BD0224
00007e6bc8bd4ec6  call 0x00007E6BC8AE20A0
00007e6bc8bd4ecb  jmp 0x00007E6BC8BD0232
00007e6bc8bd4ed0  call 0x00007E6BC8A09D70
00007e6bc8bd4ed5  jmp 0x00007E6BC8BD023C
00007e6bc8bd4eda  sub rsp, 0x08
00007e6bc8bd4ede  push rax
00007e6bc8bd4edf  push rcx
00007e6bc8bd4ee0  push rdx
00007e6bc8bd4ee1  push rdi
00007e6bc8bd4ee2  push rsi
00007e6bc8bd4ee3  push r8
00007e6bc8bd4ee5  push r9
00007e6bc8bd4ee7  push r10
00007e6bc8bd4ee9  push r11
00007e6bc8bd4eeb  sub rsp, 0xF0
00007e6bc8bd4ef2  vmovaps [rsp], xmm0
00007e6bc8bd4ef7  vmovaps [rsp+0x10], xmm1
00007e6bc8bd4efd  vmovaps [rsp+0x20], xmm2
00007e6bc8bd4f03  vmovaps [rsp+0x30], xmm3
00007e6bc8bd4f09  vmovaps [rsp+0x40], xmm4
00007e6bc8bd4f0f  vmovaps [rsp+0x50], xmm5
00007e6bc8bd4f15  vmovaps [rsp+0x60], xmm6
00007e6bc8bd4f1b  vmovaps [rsp+0x70], xmm8
00007e6bc8bd4f21  vmovaps [rsp+0x80], xmm9
00007e6bc8bd4f2a  vmovaps [rsp+0x90], xmm10
00007e6bc8bd4f33  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd4f3c  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd4f45  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd4f4e  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd4f57  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd4f60  sub rsp, 0x30
00007e6bc8bd4f64  movaps [rsp], xmm7
00007e6bc8bd4f68  movaps [rsp+0x10], xmm15
00007e6bc8bd4f6e  movaps [rsp+0x20], xmm10
00007e6bc8bd4f74  lea rdi, [rsp]
00007e6bc8bd4f78  mov esi, 0x00
00007e6bc8bd4f7d  mov rax, 0x6543F191D530
00007e6bc8bd4f87  call rax
00007e6bc8bd4f89  movaps xmm7, [rsp]
00007e6bc8bd4f8d  add rsp, 0x30
00007e6bc8bd4f91  vmovaps xmm0, [rsp]
00007e6bc8bd4f96  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd4f9c  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd4fa2  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd4fa8  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd4fae  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd4fb4  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd4fba  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd4fc0  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd4fc9  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd4fd2  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd4fdb  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd4fe4  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd4fed  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd4ff6  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd4fff  add rsp, 0xF0
00007e6bc8bd5006  pop r11
00007e6bc8bd5008  pop r10
00007e6bc8bd500a  pop r9
00007e6bc8bd500c  pop r8
00007e6bc8bd500e  pop rsi
00007e6bc8bd500f  pop rdi
00007e6bc8bd5010  pop rdx
00007e6bc8bd5011  pop rcx
00007e6bc8bd5012  pop rax
00007e6bc8bd5013  add rsp, 0x08
00007e6bc8bd5017  jmp 0x00007E6BC8BD025D
00007e6bc8bd501c  sub rsp, 0x08
00007e6bc8bd5020  push rax
00007e6bc8bd5021  push rcx
00007e6bc8bd5022  push rdx
00007e6bc8bd5023  push rdi
00007e6bc8bd5024  push rsi
00007e6bc8bd5025  push r8
00007e6bc8bd5027  push r9
00007e6bc8bd5029  push r10
00007e6bc8bd502b  push r11
00007e6bc8bd502d  sub rsp, 0xF0
00007e6bc8bd5034  vmovaps [rsp], xmm0
00007e6bc8bd5039  vmovaps [rsp+0x10], xmm1
00007e6bc8bd503f  vmovaps [rsp+0x20], xmm2
00007e6bc8bd5045  vmovaps [rsp+0x30], xmm3
00007e6bc8bd504b  vmovaps [rsp+0x40], xmm4
00007e6bc8bd5051  vmovaps [rsp+0x50], xmm5
00007e6bc8bd5057  vmovaps [rsp+0x60], xmm6
00007e6bc8bd505d  vmovaps [rsp+0x70], xmm7
00007e6bc8bd5063  vmovaps [rsp+0x80], xmm8
00007e6bc8bd506c  vmovaps [rsp+0x90], xmm9
00007e6bc8bd5075  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd507e  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd5087  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd5090  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd5099  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd50a2  sub rsp, 0x30
00007e6bc8bd50a6  movaps [rsp], xmm10
00007e6bc8bd50ab  movaps [rsp+0x10], xmm11
00007e6bc8bd50b1  movaps [rsp+0x20], xmm15
00007e6bc8bd50b7  lea rdi, [rsp]
00007e6bc8bd50bb  mov esi, 0x00
00007e6bc8bd50c0  mov rax, 0x6543F191D530
00007e6bc8bd50ca  call rax
00007e6bc8bd50cc  movaps xmm10, [rsp]
00007e6bc8bd50d1  add rsp, 0x30
00007e6bc8bd50d5  vmovaps xmm0, [rsp]
00007e6bc8bd50da  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd50e0  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd50e6  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd50ec  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd50f2  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd50f8  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd50fe  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd5104  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd510d  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd5116  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd511f  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd5128  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd5131  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd513a  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd5143  add rsp, 0xF0
00007e6bc8bd514a  pop r11
00007e6bc8bd514c  pop r10
00007e6bc8bd514e  pop r9
00007e6bc8bd5150  pop r8
00007e6bc8bd5152  pop rsi
00007e6bc8bd5153  pop rdi
00007e6bc8bd5154  pop rdx
00007e6bc8bd5155  pop rcx
00007e6bc8bd5156  pop rax
00007e6bc8bd5157  add rsp, 0x08
00007e6bc8bd515b  jmp 0x00007E6BC8BD028B
00007e6bc8bd5160  sub rsp, 0x08
00007e6bc8bd5164  push rax
00007e6bc8bd5165  push rcx
00007e6bc8bd5166  push rdx
00007e6bc8bd5167  push rdi
00007e6bc8bd5168  push rsi
00007e6bc8bd5169  push r8
00007e6bc8bd516b  push r9
00007e6bc8bd516d  push r10
00007e6bc8bd516f  push r11
00007e6bc8bd5171  sub rsp, 0xF0
00007e6bc8bd5178  vmovaps [rsp], xmm0
00007e6bc8bd517d  vmovaps [rsp+0x10], xmm1
00007e6bc8bd5183  vmovaps [rsp+0x20], xmm2
00007e6bc8bd5189  vmovaps [rsp+0x30], xmm3
00007e6bc8bd518f  vmovaps [rsp+0x40], xmm4
00007e6bc8bd5195  vmovaps [rsp+0x50], xmm5
00007e6bc8bd519b  vmovaps [rsp+0x60], xmm6
00007e6bc8bd51a1  vmovaps [rsp+0x70], xmm7
00007e6bc8bd51a7  vmovaps [rsp+0x80], xmm8
00007e6bc8bd51b0  vmovaps [rsp+0x90], xmm9
00007e6bc8bd51b9  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd51c2  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd51cb  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd51d4  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd51dd  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd51e6  sub rsp, 0x30
00007e6bc8bd51ea  movaps [rsp], xmm11
00007e6bc8bd51ef  movaps [rsp+0x10], xmm12
00007e6bc8bd51f5  movaps [rsp+0x20], xmm15
00007e6bc8bd51fb  lea rdi, [rsp]
00007e6bc8bd51ff  mov esi, 0x00
00007e6bc8bd5204  mov rax, 0x6543F191D530
00007e6bc8bd520e  call rax
00007e6bc8bd5210  movaps xmm11, [rsp]
00007e6bc8bd5215  add rsp, 0x30
00007e6bc8bd5219  vmovaps xmm0, [rsp]
00007e6bc8bd521e  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd5224  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd522a  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd5230  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd5236  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd523c  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd5242  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd5248  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd5251  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd525a  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd5263  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd526c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd5275  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd527e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd5287  add rsp, 0xF0
00007e6bc8bd528e  pop r11
00007e6bc8bd5290  pop r10
00007e6bc8bd5292  pop r9
00007e6bc8bd5294  pop r8
00007e6bc8bd5296  pop rsi
00007e6bc8bd5297  pop rdi
00007e6bc8bd5298  pop rdx
00007e6bc8bd5299  pop rcx
00007e6bc8bd529a  pop rax
00007e6bc8bd529b  add rsp, 0x08
00007e6bc8bd529f  jmp 0x00007E6BC8BD02B9
00007e6bc8bd52a4  sub rsp, 0x08
00007e6bc8bd52a8  push rax
00007e6bc8bd52a9  push rcx
00007e6bc8bd52aa  push rdx
00007e6bc8bd52ab  push rdi
00007e6bc8bd52ac  push rsi
00007e6bc8bd52ad  push r8
00007e6bc8bd52af  push r9
00007e6bc8bd52b1  push r10
00007e6bc8bd52b3  push r11
00007e6bc8bd52b5  sub rsp, 0xF0
00007e6bc8bd52bc  vmovaps [rsp], xmm0
00007e6bc8bd52c1  vmovaps [rsp+0x10], xmm1
00007e6bc8bd52c7  vmovaps [rsp+0x20], xmm2
00007e6bc8bd52cd  vmovaps [rsp+0x30], xmm3
00007e6bc8bd52d3  vmovaps [rsp+0x40], xmm4
00007e6bc8bd52d9  vmovaps [rsp+0x50], xmm5
00007e6bc8bd52df  vmovaps [rsp+0x60], xmm6
00007e6bc8bd52e5  vmovaps [rsp+0x70], xmm7
00007e6bc8bd52eb  vmovaps [rsp+0x80], xmm8
00007e6bc8bd52f4  vmovaps [rsp+0x90], xmm9
00007e6bc8bd52fd  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd5306  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd530f  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd5318  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd5321  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd532a  sub rsp, 0x30
00007e6bc8bd532e  movaps [rsp], xmm15
00007e6bc8bd5333  movaps [rsp+0x10], xmm13
00007e6bc8bd5339  movaps [rsp+0x20], xmm9
00007e6bc8bd533f  lea rdi, [rsp]
00007e6bc8bd5343  mov esi, 0x00
00007e6bc8bd5348  mov rax, 0x6543F191D530
00007e6bc8bd5352  call rax
00007e6bc8bd5354  movaps xmm15, [rsp]
00007e6bc8bd5359  add rsp, 0x30
00007e6bc8bd535d  vmovaps xmm0, [rsp]
00007e6bc8bd5362  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd5368  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd536e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd5374  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd537a  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd5380  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd5386  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd538c  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd5395  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd539e  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd53a7  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd53b0  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd53b9  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd53c2  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd53cb  add rsp, 0xF0
00007e6bc8bd53d2  pop r11
00007e6bc8bd53d4  pop r10
00007e6bc8bd53d6  pop r9
00007e6bc8bd53d8  pop r8
00007e6bc8bd53da  pop rsi
00007e6bc8bd53db  pop rdi
00007e6bc8bd53dc  pop rdx
00007e6bc8bd53dd  pop rcx
00007e6bc8bd53de  pop rax
00007e6bc8bd53df  add rsp, 0x08
00007e6bc8bd53e3  jmp 0x00007E6BC8BD02D4
00007e6bc8bd53e8  sub rsp, 0x08
00007e6bc8bd53ec  push rax
00007e6bc8bd53ed  push rcx
00007e6bc8bd53ee  push rdx
00007e6bc8bd53ef  push rdi
00007e6bc8bd53f0  push rsi
00007e6bc8bd53f1  push r8
00007e6bc8bd53f3  push r9
00007e6bc8bd53f5  push r10
00007e6bc8bd53f7  push r11
00007e6bc8bd53f9  sub rsp, 0xF0
00007e6bc8bd5400  vmovaps [rsp], xmm0
00007e6bc8bd5405  vmovaps [rsp+0x10], xmm1
00007e6bc8bd540b  vmovaps [rsp+0x20], xmm2
00007e6bc8bd5411  vmovaps [rsp+0x30], xmm3
00007e6bc8bd5417  vmovaps [rsp+0x40], xmm4
00007e6bc8bd541d  vmovaps [rsp+0x50], xmm5
00007e6bc8bd5423  vmovaps [rsp+0x60], xmm6
00007e6bc8bd5429  vmovaps [rsp+0x70], xmm7
00007e6bc8bd542f  vmovaps [rsp+0x80], xmm8
00007e6bc8bd5438  vmovaps [rsp+0x90], xmm9
00007e6bc8bd5441  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd544a  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd5453  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd545c  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd5465  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd546e  sub rsp, 0x30
00007e6bc8bd5472  movaps [rsp], xmm13
00007e6bc8bd5477  movaps [rsp+0x10], xmm8
00007e6bc8bd547d  movaps [rsp+0x20], xmm14
00007e6bc8bd5483  lea rdi, [rsp]
00007e6bc8bd5487  mov esi, 0x00
00007e6bc8bd548c  mov rax, 0x6543F191D530
00007e6bc8bd5496  call rax
00007e6bc8bd5498  movaps xmm13, [rsp]
00007e6bc8bd549d  add rsp, 0x30
00007e6bc8bd54a1  vmovaps xmm0, [rsp]
00007e6bc8bd54a6  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd54ac  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd54b2  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd54b8  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd54be  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd54c4  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd54ca  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd54d0  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd54d9  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd54e2  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd54eb  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd54f4  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd54fd  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd5506  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd550f  add rsp, 0xF0
00007e6bc8bd5516  pop r11
00007e6bc8bd5518  pop r10
00007e6bc8bd551a  pop r9
00007e6bc8bd551c  pop r8
00007e6bc8bd551e  pop rsi
00007e6bc8bd551f  pop rdi
00007e6bc8bd5520  pop rdx
00007e6bc8bd5521  pop rcx
00007e6bc8bd5522  pop rax
00007e6bc8bd5523  add rsp, 0x08
00007e6bc8bd5527  jmp 0x00007E6BC8BD02F7
00007e6bc8bd552c  sub rsp, 0x08
00007e6bc8bd5530  push rax
00007e6bc8bd5531  push rcx
00007e6bc8bd5532  push rdx
00007e6bc8bd5533  push rdi
00007e6bc8bd5534  push rsi
00007e6bc8bd5535  push r8
00007e6bc8bd5537  push r9
00007e6bc8bd5539  push r10
00007e6bc8bd553b  push r11
00007e6bc8bd553d  sub rsp, 0xF0
00007e6bc8bd5544  vmovaps [rsp], xmm0
00007e6bc8bd5549  vmovaps [rsp+0x10], xmm1
00007e6bc8bd554f  vmovaps [rsp+0x20], xmm2
00007e6bc8bd5555  vmovaps [rsp+0x30], xmm3
00007e6bc8bd555b  vmovaps [rsp+0x40], xmm4
00007e6bc8bd5561  vmovaps [rsp+0x50], xmm5
00007e6bc8bd5567  vmovaps [rsp+0x60], xmm6
00007e6bc8bd556d  vmovaps [rsp+0x70], xmm7
00007e6bc8bd5573  vmovaps [rsp+0x80], xmm8
00007e6bc8bd557c  vmovaps [rsp+0x90], xmm9
00007e6bc8bd5585  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd558e  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd5597  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd55a0  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd55a9  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd55b2  sub rsp, 0x30
00007e6bc8bd55b6  movaps [rsp], xmm14
00007e6bc8bd55bb  movaps [rsp+0x10], xmm1
00007e6bc8bd55c0  movaps [rsp+0x20], xmm10
00007e6bc8bd55c6  lea rdi, [rsp]
00007e6bc8bd55ca  mov esi, 0x00
00007e6bc8bd55cf  mov rax, 0x6543F191D530
00007e6bc8bd55d9  call rax
00007e6bc8bd55db  movaps xmm14, [rsp]
00007e6bc8bd55e0  add rsp, 0x30
00007e6bc8bd55e4  vmovaps xmm0, [rsp]
00007e6bc8bd55e9  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd55ef  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd55f5  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd55fb  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd5601  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd5607  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd560d  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd5613  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd561c  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd5625  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd562e  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd5637  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd5640  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd5649  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd5652  add rsp, 0xF0
00007e6bc8bd5659  pop r11
00007e6bc8bd565b  pop r10
00007e6bc8bd565d  pop r9
00007e6bc8bd565f  pop r8
00007e6bc8bd5661  pop rsi
00007e6bc8bd5662  pop rdi
00007e6bc8bd5663  pop rdx
00007e6bc8bd5664  pop rcx
00007e6bc8bd5665  pop rax
00007e6bc8bd5666  add rsp, 0x08
00007e6bc8bd566a  jmp 0x00007E6BC8BD031A
00007e6bc8bd566f  sub rsp, 0x08
00007e6bc8bd5673  push rax
00007e6bc8bd5674  push rcx
00007e6bc8bd5675  push rdx
00007e6bc8bd5676  push rdi
00007e6bc8bd5677  push rsi
00007e6bc8bd5678  push r8
00007e6bc8bd567a  push r9
00007e6bc8bd567c  push r10
00007e6bc8bd567e  push r11
00007e6bc8bd5680  sub rsp, 0xF0
00007e6bc8bd5687  vmovaps [rsp], xmm0
00007e6bc8bd568c  vmovaps [rsp+0x10], xmm2
00007e6bc8bd5692  vmovaps [rsp+0x20], xmm3
00007e6bc8bd5698  vmovaps [rsp+0x30], xmm4
00007e6bc8bd569e  vmovaps [rsp+0x40], xmm5
00007e6bc8bd56a4  vmovaps [rsp+0x50], xmm6
00007e6bc8bd56aa  vmovaps [rsp+0x60], xmm7
00007e6bc8bd56b0  vmovaps [rsp+0x70], xmm8
00007e6bc8bd56b6  vmovaps [rsp+0x80], xmm9
00007e6bc8bd56bf  vmovaps [rsp+0x90], xmm10
00007e6bc8bd56c8  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd56d1  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd56da  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd56e3  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd56ec  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd56f5  sub rsp, 0x30
00007e6bc8bd56f9  movaps [rsp], xmm1
00007e6bc8bd56fd  movaps [rsp+0x10], xmm7
00007e6bc8bd5702  movaps [rsp+0x20], xmm11
00007e6bc8bd5708  lea rdi, [rsp]
00007e6bc8bd570c  mov esi, 0x00
00007e6bc8bd5711  mov rax, 0x6543F191D530
00007e6bc8bd571b  call rax
00007e6bc8bd571d  movaps xmm1, [rsp]
00007e6bc8bd5721  add rsp, 0x30
00007e6bc8bd5725  vmovaps xmm0, [rsp]
00007e6bc8bd572a  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd5730  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd5736  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd573c  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd5742  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd5748  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd574e  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd5754  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd575d  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd5766  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd576f  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd5778  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd5781  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd578a  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd5793  add rsp, 0xF0
00007e6bc8bd579a  pop r11
00007e6bc8bd579c  pop r10
00007e6bc8bd579e  pop r9
00007e6bc8bd57a0  pop r8
00007e6bc8bd57a2  pop rsi
00007e6bc8bd57a3  pop rdi
00007e6bc8bd57a4  pop rdx
00007e6bc8bd57a5  pop rcx
00007e6bc8bd57a6  pop rax
00007e6bc8bd57a7  add rsp, 0x08
00007e6bc8bd57ab  jmp 0x00007E6BC8BD033B
00007e6bc8bd57b0  call 0x00007E6BC8A0E880
00007e6bc8bd57b5  jmp 0x00007E6BC8BD034E
00007e6bc8bd57ba  call 0x00007E6BC8A0C380
00007e6bc8bd57bf  jmp 0x00007E6BC8BD0359
00007e6bc8bd57c4  call 0x00007E6BC8A0D600
00007e6bc8bd57c9  jmp 0x00007E6BC8BD0364
00007e6bc8bd57ce  call 0x00007E6BC89FF540
00007e6bc8bd57d3  jmp 0x00007E6BC8BD036F
00007e6bc8bd57d8  int3
00007e6bc8bd57d9  nop [rax], eax
00007e6bc8bd57e0  mov rax, [r15+0x40]
00007e6bc8bd57e4  mov r14, [r15+0x58]
00007e6bc8bd57e8  lea r12, [rax+r14*1]
00007e6bc8bd57ec  movaps xmm1, [r15+0x1D0]
00007e6bc8bd57f4  vmovaps [rsp+0x10], xmm1
00007e6bc8bd57fa  vmovaps xmm15, [rsp+0x10]
00007e6bc8bd5800  por xmm1, xmm15
00007e6bc8bd5805  movaps xmm14, [r15+0x1A0]
00007e6bc8bd580d  vmovaps [rsp+0x10], xmm14
00007e6bc8bd5813  vmovaps xmm13, [rsp+0x10]
00007e6bc8bd5819  por xmm14, xmm13
00007e6bc8bd581e  lea rax, [r12+0x30]
00007e6bc8bd5823  mov r11, [r13+rax*1]
00007e6bc8bd5828  lea rax, [r12+0x38]
00007e6bc8bd582d  mov r10, [r13+rax*1]
00007e6bc8bd5832  movq xmm13, r11
00007e6bc8bd5837  movq xmm12, r10
00007e6bc8bd583c  movq xmm13, xmm13
00007e6bc8bd5841  vmovaps [rsp+0x10], xmm13
00007e6bc8bd5847  movq xmm13, xmm13
00007e6bc8bd584c  movaps [r15+0x130], xmm13
00007e6bc8bd5854  movq xmm12, xmm12
00007e6bc8bd5859  vmovaps [rsp+0x20], xmm12
00007e6bc8bd585f  movq xmm12, xmm12
00007e6bc8bd5864  movaps [r15+0x280], xmm12
00007e6bc8bd586c  movaps xmm13, [r15+0x270]
00007e6bc8bd5874  vmovaps [rsp+0x30], xmm13
00007e6bc8bd587a  vmovaps xmm12, [rsp+0x30]
00007e6bc8bd5880  por xmm13, xmm12
00007e6bc8bd5885  lea rax, [r12+0x20]
00007e6bc8bd588a  mov r11, [r13+rax*1]
00007e6bc8bd588f  lea rax, [r12+0x28]
00007e6bc8bd5894  mov r10, [r13+rax*1]
00007e6bc8bd5899  movq xmm12, r11
00007e6bc8bd589e  movq xmm11, r10
00007e6bc8bd58a3  movq xmm12, xmm12
00007e6bc8bd58a8  vmovaps [rsp+0x30], xmm12
00007e6bc8bd58ae  movq xmm12, xmm12
00007e6bc8bd58b3  movaps [r15+0x150], xmm12
00007e6bc8bd58bb  movq xmm11, xmm11
00007e6bc8bd58c0  vmovaps [rsp+0x40], xmm11
00007e6bc8bd58c6  movq xmm11, xmm11
00007e6bc8bd58cb  movaps [r15+0x140], xmm11
00007e6bc8bd58d3  lea rax, [r12+0x10]
00007e6bc8bd58d8  mov r11, [r13+rax*1]
00007e6bc8bd58dd  lea rax, [r12+0x18]
00007e6bc8bd58e2  mov r10, [r13+rax*1]
00007e6bc8bd58e7  movq xmm12, r11
00007e6bc8bd58ec  movq xmm11, r10
00007e6bc8bd58f1  movq xmm12, xmm12
00007e6bc8bd58f6  vmovaps [rsp+0x50], xmm12
00007e6bc8bd58fc  movq xmm12, xmm12
00007e6bc8bd5901  movaps [r15+0x170], xmm12
00007e6bc8bd5909  movq xmm11, xmm11
00007e6bc8bd590e  vmovaps [rsp+0x60], xmm11
00007e6bc8bd5914  movq xmm11, xmm11
00007e6bc8bd5919  movaps [r15+0x160], xmm11
00007e6bc8bd5921  mov rax, [r13+r12*1]
00007e6bc8bd5926  vmovq xmm12, rax
00007e6bc8bd592b  vpbroadcastq xmm12, xmm12
00007e6bc8bd5930  lea rax, [r12+0x08]
00007e6bc8bd5935  mov r12, [r13+rax*1]
00007e6bc8bd593a  movq xmm11, r12
00007e6bc8bd593f  movaps [r15+0x230], xmm11
00007e6bc8bd5947  mov rax, [r15+0xF8]
00007e6bc8bd594e  lea r12, [rax+0x50]
00007e6bc8bd5952  movups xmm11, [r13+r12*1]
00007e6bc8bd5958  lea r12, [rax+0x60]
00007e6bc8bd595c  movups xmm10, [r13+r12*1]
00007e6bc8bd5962  lea r12, [rax+0x30]
00007e6bc8bd5966  movups xmm9, [r13+r12*1]
00007e6bc8bd596c  mov r12, [r15+0x50]
00007e6bc8bd5970  lea r11, [r12+r14*1]
00007e6bc8bd5974  mov [r15+0x60], r11
00007e6bc8bd5978  lea r12, [r14+0x40]
00007e6bc8bd597c  mov [r15+0x58], r12
00007e6bc8bd5980  movaps xmm8, xmm12
00007e6bc8bd5984  mulpd xmm8, xmm15
00007e6bc8bd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007e6bc8bd598f  ptest xmm7, xmm7
00007e6bc8bd5994  jnz 0x00007E6BC8BD67B7
00007e6bc8bd599a  movq xmm15, qword ptr [r15+0x230]
00007e6bc8bd59a3  vmovaps [rsp+0x70], xmm15
00007e6bc8bd59a9  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bd59af  movaps xmm7, xmm9
00007e6bc8bd59b3  mulpd xmm7, xmm15
00007e6bc8bd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007e6bc8bd59bd  ptest xmm6, xmm6
00007e6bc8bd59c2  jnz 0x00007E6BC8BD68FB
00007e6bc8bd59c8  vxorps xmm15, xmm15, xmm15
00007e6bc8bd59cd  vpbroadcastq xmm15, xmm15
00007e6bc8bd59d2  movaps xmm9, xmm12
00007e6bc8bd59d6  mulpd xmm9, xmm10
00007e6bc8bd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007e6bc8bd59e1  ptest xmm6, xmm6
00007e6bc8bd59e6  jnz 0x00007E6BC8BD6A3D
00007e6bc8bd59ec  movaps xmm10, xmm12
00007e6bc8bd59f0  mulpd xmm10, xmm11
00007e6bc8bd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e6bc8bd59fb  ptest xmm6, xmm6
00007e6bc8bd5a00  jnz 0x00007E6BC8BD6B81
00007e6bc8bd5a06  movaps xmm11, [r15+0x1F0]
00007e6bc8bd5a0e  movaps xmm6, xmm12
00007e6bc8bd5a12  mulpd xmm6, xmm11
00007e6bc8bd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007e6bc8bd5a1c  ptest xmm5, xmm5
00007e6bc8bd5a21  jnz 0x00007E6BC8BD6CC5
00007e6bc8bd5a27  movaps xmm12, [r15+0x2A0]
00007e6bc8bd5a2f  vmovaps [rsp+0x80], xmm12
00007e6bc8bd5a38  vmovaps xmm11, [rsp+0x80]
00007e6bc8bd5a41  por xmm12, xmm11
00007e6bc8bd5a46  movaps xmm11, [r15+0x250]
00007e6bc8bd5a4e  vmovaps [rsp+0x80], xmm11
00007e6bc8bd5a57  vmovaps xmm5, [rsp+0x80]
00007e6bc8bd5a60  por xmm11, xmm5
00007e6bc8bd5a65  vmovaps xmm4, [rsp+0x70]
00007e6bc8bd5a6b  vpermilpd xmm4, xmm4, 0x00
00007e6bc8bd5a71  movaps xmm3, xmm5
00007e6bc8bd5a74  mulpd xmm3, xmm4
00007e6bc8bd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007e6bc8bd5a7d  ptest xmm2, xmm2
00007e6bc8bd5a82  jnz 0x00007E6BC8BD6E07
00007e6bc8bd5a88  mov [rsp+0x80], rax
00007e6bc8bd5a90  xor eax, eax
00007e6bc8bd5a92  mov r14d, 0x200
00007e6bc8bd5a98  cmp r12, r14
00007e6bc8bd5a9b  cmc
00007e6bc8bd5a9c  lahf
00007e6bc8bd5a9d  seto al
00007e6bc8bd5aa0  mov [r15+0x108], eax
00007e6bc8bd5aa7  movaps xmm5, xmm8
00007e6bc8bd5aab  addpd xmm5, xmm15
00007e6bc8bd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007e6bc8bd5ab5  ptest xmm4, xmm4
00007e6bc8bd5aba  jnz 0x00007E6BC8BD6F47
00007e6bc8bd5ac0  movaps xmm8, [r15+0x1B0]
00007e6bc8bd5ac8  movaps xmm4, xmm9
00007e6bc8bd5acc  addpd xmm4, xmm8
00007e6bc8bd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007e6bc8bd5ad6  ptest xmm2, xmm2
00007e6bc8bd5adb  jnz 0x00007E6BC8BD7089
00007e6bc8bd5ae1  movaps xmm9, xmm10
00007e6bc8bd5ae5  addpd xmm9, xmm8
00007e6bc8bd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007e6bc8bd5af0  ptest xmm2, xmm2
00007e6bc8bd5af5  jnz 0x00007E6BC8BD71CB
00007e6bc8bd5afb  movaps xmm10, [r15+0x2F0]
00007e6bc8bd5b03  vmovaps [rsp+0x90], xmm10
00007e6bc8bd5b0c  vmovaps xmm8, [rsp+0x90]
00007e6bc8bd5b15  por xmm10, xmm8
00007e6bc8bd5b1a  movaps xmm8, [r15+0x2E0]
00007e6bc8bd5b22  vmovaps [rsp+0x90], xmm8
00007e6bc8bd5b2b  vmovaps xmm2, [rsp+0x90]
00007e6bc8bd5b34  por xmm8, xmm2
00007e6bc8bd5b39  movaps xmm2, [r15+0x2D0]
00007e6bc8bd5b41  vmovaps [rsp+0x90], xmm2
00007e6bc8bd5b4a  vmovaps [rsp+0xA0], xmm1
00007e6bc8bd5b53  vmovaps xmm1, [rsp+0x90]
00007e6bc8bd5b5c  por xmm2, xmm1
00007e6bc8bd5b60  movaps xmm1, [r15+0x200]
00007e6bc8bd5b68  vmovaps [rsp+0x90], xmm1
00007e6bc8bd5b71  vmovaps [rsp+0xB0], xmm15
00007e6bc8bd5b7a  vmovaps xmm15, [rsp+0x90]
00007e6bc8bd5b83  por xmm1, xmm15
00007e6bc8bd5b88  movaps xmm15, [r15+0x1C0]
00007e6bc8bd5b90  vmovaps [rsp+0x90], xmm15
00007e6bc8bd5b99  vmovaps [rsp+0xC0], xmm1
00007e6bc8bd5ba2  vmovaps xmm1, [rsp+0x90]
00007e6bc8bd5bab  por xmm15, xmm1
00007e6bc8bd5bb0  movaps xmm1, [r15+0x190]
00007e6bc8bd5bb8  vmovaps [rsp+0x90], xmm1
00007e6bc8bd5bc1  vmovaps [rsp+0xD0], xmm15
00007e6bc8bd5bca  vmovaps xmm15, [rsp+0x90]
00007e6bc8bd5bd3  por xmm1, xmm15
00007e6bc8bd5bd8  movaps xmm15, [r15+0x300]
00007e6bc8bd5be0  vmovaps [rsp+0x90], xmm15
00007e6bc8bd5be9  vmovaps [rsp+0xE0], xmm1
00007e6bc8bd5bf2  vmovaps xmm1, [rsp+0x90]
00007e6bc8bd5bfb  por xmm15, xmm1
00007e6bc8bd5c00  mov rax, [rsp+0x80]
00007e6bc8bd5c08  lea r14, [rax+0xA0]
00007e6bc8bd5c0f  movups xmm1, [r13+r14*1]
00007e6bc8bd5c15  lea r14, [rax+0xB0]
00007e6bc8bd5c1c  vmovaps [rsp+0x80], xmm1
00007e6bc8bd5c25  movups xmm1, [r13+r14*1]
00007e6bc8bd5c2b  vmovaps [rsp+0x90], xmm1
00007e6bc8bd5c34  vmovaps [rsp+0xF0], xmm15
00007e6bc8bd5c3d  vmovaps xmm15, [rsp+0xB0]
00007e6bc8bd5c46  vmovaps [rsp+0xB0], xmm14
00007e6bc8bd5c4f  movaps xmm1, xmm6
00007e6bc8bd5c52  addpd xmm1, xmm15
00007e6bc8bd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007e6bc8bd5c5c  ptest xmm14, xmm14
00007e6bc8bd5c62  jnz 0x00007E6BC8BD7323
00007e6bc8bd5c68  lea r14, [rax+0xF0]
00007e6bc8bd5c6f  movups xmm15, [r13+r14*1]
00007e6bc8bd5c75  movaps xmm14, xmm4
00007e6bc8bd5c79  addpd xmm14, xmm3
00007e6bc8bd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007e6bc8bd5c84  ptest xmm6, xmm6
00007e6bc8bd5c89  jnz 0x00007E6BC8BD746E
00007e6bc8bd5c8f  movaps xmm6, xmm9
00007e6bc8bd5c93  addpd xmm6, xmm7
00007e6bc8bd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007e6bc8bd5c9c  ptest xmm4, xmm4
00007e6bc8bd5ca1  jnz 0x00007E6BC8BD75B0
00007e6bc8bd5ca7  vmovaps xmm9, [rsp+0x70]
00007e6bc8bd5cad  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bd5cb3  vmovaps xmm4, [rsp+0x90]
00007e6bc8bd5cbc  movaps xmm7, xmm4
00007e6bc8bd5cbf  mulpd xmm7, xmm9
00007e6bc8bd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007e6bc8bd5cc9  ptest xmm3, xmm3
00007e6bc8bd5cce  jnz 0x00007E6BC8BD76F1
00007e6bc8bd5cd4  vmovaps xmm9, [rsp+0x50]
00007e6bc8bd5cda  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bd5ce0  movaps xmm4, xmm15
00007e6bc8bd5ce4  mulpd xmm4, xmm9
00007e6bc8bd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007e6bc8bd5cee  ptest xmm3, xmm3
00007e6bc8bd5cf3  jnz 0x00007E6BC8BD7832
00007e6bc8bd5cf9  lea r14, [rax+0xE0]
00007e6bc8bd5d00  movups xmm15, [r13+r14*1]
00007e6bc8bd5d06  vmovaps xmm9, [rsp+0x70]
00007e6bc8bd5d0c  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bd5d12  vmovaps [rsp+0x70], xmm1
00007e6bc8bd5d18  vmovaps xmm1, [rsp+0x80]
00007e6bc8bd5d21  vmovaps [rsp+0x80], xmm15
00007e6bc8bd5d2a  movaps xmm3, xmm1
00007e6bc8bd5d2d  mulpd xmm3, xmm9
00007e6bc8bd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007e6bc8bd5d37  ptest xmm15, xmm15
00007e6bc8bd5d3d  jnz 0x00007E6BC8BD797E
00007e6bc8bd5d43  vmovaps xmm1, [rsp+0xF0]
00007e6bc8bd5d4c  vmovaps xmm15, [rsp+0xF0]
00007e6bc8bd5d55  por xmm1, xmm15
00007e6bc8bd5d5a  movaps [r15+0x300], xmm1
00007e6bc8bd5d62  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd5d6b  vmovaps xmm9, [rsp+0xE0]
00007e6bc8bd5d74  por xmm15, xmm9
00007e6bc8bd5d79  movaps [r15+0x190], xmm15
00007e6bc8bd5d81  vmovaps xmm9, [rsp+0x50]
00007e6bc8bd5d87  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bd5d8d  vmovaps [rsp+0x90], xmm1
00007e6bc8bd5d96  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd5d9f  vmovaps xmm15, [rsp+0x80]
00007e6bc8bd5da8  vmovaps [rsp+0x80], xmm14
00007e6bc8bd5db1  movaps xmm1, xmm15
00007e6bc8bd5db5  mulpd xmm1, xmm9
00007e6bc8bd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007e6bc8bd5dbf  ptest xmm14, xmm14
00007e6bc8bd5dc5  jnz 0x00007E6BC8BD7ABF
00007e6bc8bd5dcb  lea r14, [rax+0x90]
00007e6bc8bd5dd2  movups xmm15, [r13+r14*1]
00007e6bc8bd5dd8  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd5de1  vmovaps xmm9, [rsp+0xD0]
00007e6bc8bd5dea  por xmm14, xmm9
00007e6bc8bd5def  movaps [r15+0x1C0], xmm14
00007e6bc8bd5df7  vmovaps xmm9, [rsp+0xC0]
00007e6bc8bd5e00  vmovaps [rsp+0xD0], xmm1
00007e6bc8bd5e09  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bd5e12  por xmm9, xmm1
00007e6bc8bd5e17  movaps [r15+0x200], xmm9
00007e6bc8bd5e1f  vmovaps [rsp+0xC0], xmm2
00007e6bc8bd5e28  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bd5e31  por xmm2, xmm1
00007e6bc8bd5e35  movaps [r15+0x2D0], xmm2
00007e6bc8bd5e3d  vmovaps [rsp+0xC0], xmm8
00007e6bc8bd5e46  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bd5e4f  por xmm8, xmm1
00007e6bc8bd5e54  movaps [r15+0x2E0], xmm8
00007e6bc8bd5e5c  vmovaps [rsp+0xC0], xmm15
00007e6bc8bd5e65  movaps xmm1, xmm5
00007e6bc8bd5e68  addpd xmm1, xmm7
00007e6bc8bd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007e6bc8bd5e71  ptest xmm15, xmm15
00007e6bc8bd5e77  jnz 0x00007E6BC8BD7C0B
00007e6bc8bd5e7d  vmovaps xmm15, [rsp+0x50]
00007e6bc8bd5e83  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bd5e89  vmovaps xmm5, [rsp+0xC0]
00007e6bc8bd5e92  vmovaps [rsp+0xC0], xmm1
00007e6bc8bd5e9b  movaps xmm7, xmm5
00007e6bc8bd5e9e  mulpd xmm7, xmm15
00007e6bc8bd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007e6bc8bd5ea8  ptest xmm1, xmm1
00007e6bc8bd5ead  jnz 0x00007E6BC8BD7D4B
00007e6bc8bd5eb3  lea r14, [rax+0x80]
00007e6bc8bd5eba  movups xmm1, [r13+r14*1]
00007e6bc8bd5ec0  vmovaps xmm5, [rsp+0x70]
00007e6bc8bd5ec6  vmovaps [rsp+0x70], xmm1
00007e6bc8bd5ecc  movaps xmm15, xmm5
00007e6bc8bd5ed0  addpd xmm15, xmm3
00007e6bc8bd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e6bc8bd5edb  ptest xmm1, xmm1
00007e6bc8bd5ee0  jnz 0x00007E6BC8BD7E96
00007e6bc8bd5ee6  vmovaps xmm5, [rsp+0x80]
00007e6bc8bd5eef  movaps xmm1, xmm5
00007e6bc8bd5ef2  addpd xmm1, xmm4
00007e6bc8bd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007e6bc8bd5efb  ptest xmm3, xmm3
00007e6bc8bd5f00  jnz 0x00007E6BC8BD7FD8
00007e6bc8bd5f06  vmovaps [rsp+0x80], xmm10
00007e6bc8bd5f0f  vmovaps xmm5, [rsp+0x80]
00007e6bc8bd5f18  por xmm10, xmm5
00007e6bc8bd5f1d  movaps [r15+0x2F0], xmm10
00007e6bc8bd5f25  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd5f2b  vpermilpd xmm5, xmm5, 0x00
00007e6bc8bd5f31  vmovaps xmm3, [rsp+0x70]
00007e6bc8bd5f37  vmovaps [rsp+0x50], xmm1
00007e6bc8bd5f3d  movaps xmm4, xmm3
00007e6bc8bd5f40  mulpd xmm4, xmm5
00007e6bc8bd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007e6bc8bd5f49  ptest xmm1, xmm1
00007e6bc8bd5f4e  jnz 0x00007E6BC8BD8118
00007e6bc8bd5f54  lea r14, [rax+0xD0]
00007e6bc8bd5f5b  movups xmm1, [r13+r14*1]
00007e6bc8bd5f61  vmovaps xmm3, [rsp+0xD0]
00007e6bc8bd5f6a  vmovaps [rsp+0x70], xmm1
00007e6bc8bd5f70  movaps xmm5, xmm6
00007e6bc8bd5f73  addpd xmm5, xmm3
00007e6bc8bd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007e6bc8bd5f7c  ptest xmm1, xmm1
00007e6bc8bd5f81  jnz 0x00007E6BC8BD8262
00007e6bc8bd5f87  vmovaps xmm1, [rsp+0x60]
00007e6bc8bd5f8d  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd5f93  movaps xmm6, xmm9
00007e6bc8bd5f97  mulpd xmm6, xmm1
00007e6bc8bd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007e6bc8bd5fa0  ptest xmm3, xmm3
00007e6bc8bd5fa5  jnz 0x00007E6BC8BD83A2
00007e6bc8bd5fab  movaps [r15+0x260], xmm6
00007e6bc8bd5fb3  vxorps xmm1, xmm1, xmm1
00007e6bc8bd5fb7  vpbroadcastq xmm1, xmm1
00007e6bc8bd5fbc  movaps [r15+0x1B0], xmm1
00007e6bc8bd5fc4  vmovaps xmm1, [rsp+0x60]
00007e6bc8bd5fca  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd5fd0  vmovaps xmm3, [rsp+0x70]
00007e6bc8bd5fd6  vmovaps [rsp+0x70], xmm15
00007e6bc8bd5fdc  movaps xmm9, xmm3
00007e6bc8bd5fe0  mulpd xmm9, xmm1
00007e6bc8bd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007e6bc8bd5feb  ptest xmm15, xmm15
00007e6bc8bd5ff1  jnz 0x00007E6BC8BD84E3
00007e6bc8bd5ff7  lea r14, [rax+0xC0]
00007e6bc8bd5ffe  movups xmm1, [r13+r14*1]
00007e6bc8bd6004  vmovaps xmm3, [rsp+0xC0]
00007e6bc8bd600d  vmovaps [rsp+0x80], xmm1
00007e6bc8bd6016  movaps xmm15, xmm3
00007e6bc8bd601a  addpd xmm15, xmm7
00007e6bc8bd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007e6bc8bd6025  ptest xmm1, xmm1
00007e6bc8bd602a  jnz 0x00007E6BC8BD862F
00007e6bc8bd6030  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd6039  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bd6042  por xmm13, xmm1
00007e6bc8bd6047  movaps [r15+0x270], xmm13
00007e6bc8bd604f  vmovaps xmm1, [rsp+0xB0]
00007e6bc8bd6058  vmovaps xmm7, [rsp+0xB0]
00007e6bc8bd6061  por xmm1, xmm7
00007e6bc8bd6065  movaps [r15+0x1A0], xmm1
00007e6bc8bd606d  vmovaps xmm1, [rsp+0x60]
00007e6bc8bd6073  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd6079  vmovaps [rsp+0xB0], xmm1
00007e6bc8bd6082  vmovaps xmm1, [rsp+0x80]
00007e6bc8bd608b  vmovaps [rsp+0x80], xmm15
00007e6bc8bd6094  vmovaps xmm15, [rsp+0xB0]
00007e6bc8bd609d  vmovaps [rsp+0xB0], xmm14
00007e6bc8bd60a6  movaps xmm3, xmm1
00007e6bc8bd60a9  mulpd xmm3, xmm15
00007e6bc8bd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007e6bc8bd60b3  ptest xmm14, xmm14
00007e6bc8bd60b9  jnz 0x00007E6BC8BD8771
00007e6bc8bd60bf  lea r14, [rax+0x20]
00007e6bc8bd60c3  movups xmm1, [r13+r14*1]
00007e6bc8bd60c9  movaps [r15+0x110], xmm1
00007e6bc8bd60d1  vmovaps xmm14, [rsp+0x70]
00007e6bc8bd60d7  vmovaps [rsp+0x70], xmm1
00007e6bc8bd60dd  movaps xmm15, xmm14
00007e6bc8bd60e1  addpd xmm15, xmm4
00007e6bc8bd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007e6bc8bd60ec  ptest xmm1, xmm1
00007e6bc8bd60f1  jnz 0x00007E6BC8BD88BC
00007e6bc8bd60f7  vmovaps xmm1, [rsp+0x60]
00007e6bc8bd60fd  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd6103  movaps xmm14, xmm2
00007e6bc8bd6107  mulpd xmm14, xmm1
00007e6bc8bd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007e6bc8bd6112  ptest xmm4, xmm4
00007e6bc8bd6117  jnz 0x00007E6BC8BD89FF
00007e6bc8bd611d  vmovaps xmm4, [rsp+0x50]
00007e6bc8bd6123  movaps xmm1, xmm4
00007e6bc8bd6126  addpd xmm1, xmm9
00007e6bc8bd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e6bc8bd6130  ptest xmm2, xmm2
00007e6bc8bd6135  jnz 0x00007E6BC8BD8B41
00007e6bc8bd613b  vmovaps xmm9, [rsp+0x30]
00007e6bc8bd6141  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bd6147  vmovaps xmm2, [rsp+0x70]
00007e6bc8bd614d  vmovaps [rsp+0x50], xmm1
00007e6bc8bd6153  movaps xmm4, xmm2
00007e6bc8bd6156  mulpd xmm4, xmm9
00007e6bc8bd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007e6bc8bd6160  ptest xmm1, xmm1
00007e6bc8bd6165  jnz 0x00007E6BC8BD8C82
00007e6bc8bd616b  vmovaps xmm1, [rsp+0x30]
00007e6bc8bd6171  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd6177  vmovaps xmm2, [rsp+0x90]
00007e6bc8bd6180  vmovaps [rsp+0x60], xmm15
00007e6bc8bd6186  movaps xmm9, xmm2
00007e6bc8bd618a  mulpd xmm9, xmm1
00007e6bc8bd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007e6bc8bd6195  ptest xmm15, xmm15
00007e6bc8bd619b  jnz 0x00007E6BC8BD8DC3
00007e6bc8bd61a1  vmovaps xmm15, [rsp+0x80]
00007e6bc8bd61aa  movaps xmm1, xmm15
00007e6bc8bd61ae  addpd xmm1, xmm6
00007e6bc8bd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007e6bc8bd61b7  ptest xmm2, xmm2
00007e6bc8bd61bc  jnz 0x00007E6BC8BD8F05
00007e6bc8bd61c2  movaps xmm15, xmm5
00007e6bc8bd61c6  addpd xmm15, xmm3
00007e6bc8bd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007e6bc8bd61d1  ptest xmm6, xmm6
00007e6bc8bd61d6  jnz 0x00007E6BC8BD9046
00007e6bc8bd61dc  vmovaps xmm6, [rsp+0x30]
00007e6bc8bd61e2  vpermilpd xmm6, xmm6, 0x00
00007e6bc8bd61e8  movaps xmm5, xmm8
00007e6bc8bd61ec  mulpd xmm5, xmm6
00007e6bc8bd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007e6bc8bd61f5  ptest xmm3, xmm3
00007e6bc8bd61fa  jnz 0x00007E6BC8BD9188
00007e6bc8bd6200  vmovaps xmm8, [rsp+0x30]
00007e6bc8bd6206  vpermilpd xmm8, xmm8, 0x00
00007e6bc8bd620c  movaps xmm6, xmm10
00007e6bc8bd6210  mulpd xmm6, xmm8
00007e6bc8bd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007e6bc8bd621a  ptest xmm3, xmm3
00007e6bc8bd621f  jnz 0x00007E6BC8BD92C9
00007e6bc8bd6225  vmovaps xmm8, [rsp+0x60]
00007e6bc8bd622b  movaps xmm10, xmm8
00007e6bc8bd622f  addpd xmm10, xmm14
00007e6bc8bd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007e6bc8bd623a  ptest xmm3, xmm3
00007e6bc8bd623f  jnz 0x00007E6BC8BD940B
00007e6bc8bd6245  vmovaps xmm8, [rsp+0x50]
00007e6bc8bd624b  movaps xmm14, xmm8
00007e6bc8bd624f  addpd xmm14, xmm4
00007e6bc8bd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007e6bc8bd625a  ptest xmm3, xmm3
00007e6bc8bd625f  jnz 0x00007E6BC8BD954F
00007e6bc8bd6265  vmovaps xmm8, [rsp+0x40]
00007e6bc8bd626b  vpermilpd xmm8, xmm8, 0x00
00007e6bc8bd6271  movaps xmm4, xmm13
00007e6bc8bd6275  mulpd xmm4, xmm8
00007e6bc8bd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007e6bc8bd627f  ptest xmm3, xmm3
00007e6bc8bd6284  jnz 0x00007E6BC8BD9692
00007e6bc8bd628a  movaps xmm13, xmm15
00007e6bc8bd628e  addpd xmm13, xmm9
00007e6bc8bd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007e6bc8bd6299  ptest xmm8, xmm8
00007e6bc8bd629f  jnz 0x00007E6BC8BD97D4
00007e6bc8bd62a5  movaps xmm15, xmm1
00007e6bc8bd62a9  addpd xmm15, xmm5
00007e6bc8bd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007e6bc8bd62b4  ptest xmm9, xmm9
00007e6bc8bd62ba  jnz 0x00007E6BC8BD9918
00007e6bc8bd62c0  vmovaps [rsp+0x30], xmm11
00007e6bc8bd62c6  vmovaps xmm1, [rsp+0x30]
00007e6bc8bd62cc  por xmm11, xmm1
00007e6bc8bd62d1  movaps [r15+0x250], xmm11
00007e6bc8bd62d9  vmovaps [rsp+0x30], xmm12
00007e6bc8bd62df  vmovaps xmm1, [rsp+0x30]
00007e6bc8bd62e5  por xmm12, xmm1
00007e6bc8bd62ea  movaps [r15+0x2A0], xmm12
00007e6bc8bd62f2  vmovaps xmm1, [rsp+0xA0]
00007e6bc8bd62fb  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd6304  por xmm1, xmm11
00007e6bc8bd6309  movaps [r15+0x1D0], xmm1
00007e6bc8bd6311  lea r14, [rax+0x40]
00007e6bc8bd6315  movups xmm1, [r13+r14*1]
00007e6bc8bd631b  movaps [r15+0x2C0], xmm1
00007e6bc8bd6323  vmovaps xmm11, [rsp+0x40]
00007e6bc8bd6329  vpermilpd xmm11, xmm11, 0x00
00007e6bc8bd632f  vmovaps xmm8, [rsp+0xE0]
00007e6bc8bd6338  movaps xmm9, xmm8
00007e6bc8bd633c  mulpd xmm9, xmm11
00007e6bc8bd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007e6bc8bd6347  ptest xmm5, xmm5
00007e6bc8bd634c  jnz 0x00007E6BC8BD9A64
00007e6bc8bd6352  movaps xmm11, xmm10
00007e6bc8bd6356  addpd xmm11, xmm6
00007e6bc8bd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007e6bc8bd6361  ptest xmm8, xmm8
00007e6bc8bd6367  jnz 0x00007E6BC8BD9BA8
00007e6bc8bd636d  movaps xmm10, xmm14
00007e6bc8bd6371  addpd xmm10, xmm4
00007e6bc8bd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007e6bc8bd637c  ptest xmm8, xmm8
00007e6bc8bd6382  jnz 0x00007E6BC8BD9CEB
00007e6bc8bd6388  vmovaps xmm14, [rsp+0x40]
00007e6bc8bd638e  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bd6394  movaps xmm8, xmm1
00007e6bc8bd6398  mulpd xmm8, xmm14
00007e6bc8bd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007e6bc8bd63a3  ptest xmm6, xmm6
00007e6bc8bd63a8  jnz 0x00007E6BC8BD9E2E
00007e6bc8bd63ae  movaps xmm1, [r15+0x2B0]
00007e6bc8bd63b6  vmovaps xmm14, [rsp+0x40]
00007e6bc8bd63bc  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bd63c2  movaps xmm6, xmm1
00007e6bc8bd63c5  mulpd xmm6, xmm14
00007e6bc8bd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007e6bc8bd63cf  ptest xmm5, xmm5
00007e6bc8bd63d4  jnz 0x00007E6BC8BD9F71
00007e6bc8bd63da  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd63e0  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd63e6  movaps xmm14, xmm12
00007e6bc8bd63ea  mulpd xmm14, xmm1
00007e6bc8bd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007e6bc8bd63f5  ptest xmm5, xmm5
00007e6bc8bd63fa  jnz 0x00007E6BC8BDA0B2
00007e6bc8bd6400  movaps xmm1, xmm13
00007e6bc8bd6404  addpd xmm1, xmm9
00007e6bc8bd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007e6bc8bd640e  ptest xmm12, xmm12
00007e6bc8bd6414  jnz 0x00007E6BC8BDA1F5
00007e6bc8bd641a  vmovaps xmm13, [rsp+0x10]
00007e6bc8bd6420  vpermilpd xmm13, xmm13, 0x00
00007e6bc8bd6426  movaps xmm12, xmm7
00007e6bc8bd642a  mulpd xmm12, xmm13
00007e6bc8bd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007e6bc8bd6435  ptest xmm9, xmm9
00007e6bc8bd643b  jnz 0x00007E6BC8BDA337
00007e6bc8bd6441  movaps xmm13, xmm15
00007e6bc8bd6445  addpd xmm13, xmm8
00007e6bc8bd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007e6bc8bd6450  ptest xmm9, xmm9
00007e6bc8bd6456  jnz 0x00007E6BC8BDA47A
00007e6bc8bd645c  movaps xmm15, [r15+0x290]
00007e6bc8bd6464  vmovaps xmm9, [rsp+0x10]
00007e6bc8bd646a  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bd6470  movaps xmm8, xmm15
00007e6bc8bd6474  mulpd xmm8, xmm9
00007e6bc8bd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007e6bc8bd647f  ptest xmm7, xmm7
00007e6bc8bd6484  jnz 0x00007E6BC8BDA5BE
00007e6bc8bd648a  movaps xmm15, xmm11
00007e6bc8bd648e  addpd xmm15, xmm6
00007e6bc8bd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007e6bc8bd6499  ptest xmm9, xmm9
00007e6bc8bd649f  jnz 0x00007E6BC8BDA702
00007e6bc8bd64a5  movaps xmm11, [r15+0x1E0]
00007e6bc8bd64ad  vmovaps xmm9, [rsp+0x10]
00007e6bc8bd64b3  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bd64b9  movaps xmm7, xmm11
00007e6bc8bd64bd  mulpd xmm7, xmm9
00007e6bc8bd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007e6bc8bd64c7  ptest xmm6, xmm6
00007e6bc8bd64cc  jnz 0x00007E6BC8BDA845
00007e6bc8bd64d2  movaps xmm11, xmm10
00007e6bc8bd64d6  addpd xmm11, xmm14
00007e6bc8bd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007e6bc8bd64e1  ptest xmm9, xmm9
00007e6bc8bd64e7  jnz 0x00007E6BC8BDA987
00007e6bc8bd64ed  lea r14, [rax+0x70]
00007e6bc8bd64f1  movups xmm14, [r13+r14*1]
00007e6bc8bd64f7  movaps [r15+0x240], xmm14
00007e6bc8bd64ff  movaps xmm10, xmm1
00007e6bc8bd6503  addpd xmm10, xmm12
00007e6bc8bd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007e6bc8bd650e  ptest xmm9, xmm9
00007e6bc8bd6514  jnz 0x00007E6BC8BDAAD5
00007e6bc8bd651a  movaps [r15+0x170], xmm10
00007e6bc8bd6522  vmovaps xmm1, [rsp+0x20]
00007e6bc8bd6528  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd652e  movaps xmm12, xmm14
00007e6bc8bd6532  mulpd xmm12, xmm1
00007e6bc8bd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007e6bc8bd653d  ptest xmm9, xmm9
00007e6bc8bd6543  jnz 0x00007E6BC8BDAC18
00007e6bc8bd6549  vmovaps xmm1, [rsp+0x20]
00007e6bc8bd654f  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bd6555  vmovaps xmm9, [rsp+0xB0]
00007e6bc8bd655e  movaps xmm14, xmm9
00007e6bc8bd6562  mulpd xmm14, xmm1
00007e6bc8bd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007e6bc8bd656d  ptest xmm6, xmm6
00007e6bc8bd6572  jnz 0x00007E6BC8BDAD5B
00007e6bc8bd6578  movaps [r15+0x180], xmm14
00007e6bc8bd6580  movaps xmm1, xmm13
00007e6bc8bd6584  addpd xmm1, xmm8
00007e6bc8bd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007e6bc8bd658e  ptest xmm9, xmm9
00007e6bc8bd6594  jnz 0x00007E6BC8BDAE9E
00007e6bc8bd659a  movaps [r15+0x210], xmm1
00007e6bc8bd65a2  movups xmm13, [r13+rax*1]
00007e6bc8bd65a8  lea r14, [rax+0x10]
00007e6bc8bd65ac  movups xmm9, [r13+r14*1]
00007e6bc8bd65b2  movaps [r15+0x230], xmm9
00007e6bc8bd65ba  movaps xmm8, xmm15
00007e6bc8bd65be  addpd xmm8, xmm7
00007e6bc8bd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007e6bc8bd65c9  ptest xmm6, xmm6
00007e6bc8bd65ce  jnz 0x00007E6BC8BDAFF4
00007e6bc8bd65d4  movaps [r15+0x130], xmm8
00007e6bc8bd65dc  vmovaps xmm15, [rsp+0x20]
00007e6bc8bd65e2  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bd65e8  movaps xmm7, xmm9
00007e6bc8bd65ec  mulpd xmm7, xmm15
00007e6bc8bd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007e6bc8bd65f6  ptest xmm6, xmm6
00007e6bc8bd65fb  jnz 0x00007E6BC8BDB137
00007e6bc8bd6601  movaps [r15+0x220], xmm7
00007e6bc8bd6609  vmovaps xmm15, [rsp+0x20]
00007e6bc8bd660f  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bd6615  movaps xmm9, xmm13
00007e6bc8bd6619  mulpd xmm9, xmm15
00007e6bc8bd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007e6bc8bd6624  ptest xmm6, xmm6
00007e6bc8bd6629  jnz 0x00007E6BC8BDB279
00007e6bc8bd662f  movaps xmm15, xmm11
00007e6bc8bd6633  addpd xmm15, xmm12
00007e6bc8bd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007e6bc8bd663e  ptest xmm13, xmm13
00007e6bc8bd6644  jnz 0x00007E6BC8BDB3BD
00007e6bc8bd664a  movaps [r15+0x140], xmm15
00007e6bc8bd6652  movaps xmm13, xmm10
00007e6bc8bd6656  addpd xmm13, xmm14
00007e6bc8bd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007e6bc8bd6661  ptest xmm12, xmm12
00007e6bc8bd6667  jnz 0x00007E6BC8BDB501
00007e6bc8bd666d  movaps [r15+0x150], xmm13
00007e6bc8bd6675  movaps xmm14, xmm1
00007e6bc8bd6679  addpd xmm14, xmm7
00007e6bc8bd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007e6bc8bd6684  ptest xmm12, xmm12
00007e6bc8bd668a  jnz 0x00007E6BC8BDB645
00007e6bc8bd6690  movaps [r15+0x160], xmm14
00007e6bc8bd6698  movaps xmm1, xmm8
00007e6bc8bd669c  addpd xmm1, xmm9
00007e6bc8bd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007e6bc8bd66a6  ptest xmm12, xmm12
00007e6bc8bd66ac  jnz 0x00007E6BC8BDB787
00007e6bc8bd66b2  movaps [r15+0x120], xmm1
00007e6bc8bd66ba  movups [r13+r11*1], xmm15
00007e6bc8bd66c0  lea rax, [r11+0x10]
00007e6bc8bd66c4  movups [r13+rax*1], xmm13
00007e6bc8bd66ca  lea rax, [r11+0x20]
00007e6bc8bd66ce  movups [r13+rax*1], xmm14
00007e6bc8bd66d4  lea rax, [r11+0x30]
00007e6bc8bd66d8  movups [r13+rax*1], xmm1
00007e6bc8bd66de  mov eax, [r15+0x108]
00007e6bc8bd66e5  sahf
00007e6bc8bd66e6  jnz 0x00007E6BC8BD6718
00007e6bc8bd66e8  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bd66f0  jz 0x00007E6BC8BDB900
00007e6bc8bd66f6  nop [rax+rax*1], ax
00007e6bc8bd66ff  nop [rax+rax*1], eax
00007e6bc8bd6707  mov eax, 0x410444
00007e6bc8bd670c  mov [r15+0x100], rax
00007e6bc8bd6713  jmp 0x00007E6BC89FE110
00007e6bc8bd6718  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bd6720  jz 0x00007E6BC8BD57E0
00007e6bc8bd6726  nop [rax+rax*1], ax
00007e6bc8bd672f  nop [rax+rax*1], eax
00007e6bc8bd6737  mov eax, 0x410278
00007e6bc8bd673c  mov [r15+0x100], rax
00007e6bc8bd6743  jmp 0x00007E6BC89FE110
00007e6bc8bd6748  int3
00007e6bc8bd6749  call 0x00007E6BC8A0A4B0
00007e6bc8bd674e  jmp 0x00007E6BC8BD5828
00007e6bc8bd6753  call 0x00007E6BC8A09240
00007e6bc8bd6758  jmp 0x00007E6BC8BD5832
00007e6bc8bd675d  call 0x00007E6BC8A0A4B0
00007e6bc8bd6762  jmp 0x00007E6BC8BD588F
00007e6bc8bd6767  call 0x00007E6BC8A09240
00007e6bc8bd676c  jmp 0x00007E6BC8BD5899
00007e6bc8bd6771  call 0x00007E6BC8A0A4B0
00007e6bc8bd6776  jmp 0x00007E6BC8BD58DD
00007e6bc8bd677b  call 0x00007E6BC8A09240
00007e6bc8bd6780  jmp 0x00007E6BC8BD58E7
00007e6bc8bd6785  call 0x00007E6BC8AB47C0
00007e6bc8bd678a  jmp 0x00007E6BC8BD5926
00007e6bc8bd678f  call 0x00007E6BC8A0B720
00007e6bc8bd6794  jmp 0x00007E6BC8BD593A
00007e6bc8bd6799  call 0x00007E6BC8ABFC30
00007e6bc8bd679e  jmp 0x00007E6BC8BD5958
00007e6bc8bd67a3  call 0x00007E6BC8ABE9C0
00007e6bc8bd67a8  jmp 0x00007E6BC8BD5962
00007e6bc8bd67ad  call 0x00007E6BC8ABD750
00007e6bc8bd67b2  jmp 0x00007E6BC8BD596C
00007e6bc8bd67b7  sub rsp, 0x08
00007e6bc8bd67bb  push rax
00007e6bc8bd67bc  push rcx
00007e6bc8bd67bd  push rdx
00007e6bc8bd67be  push rdi
00007e6bc8bd67bf  push rsi
00007e6bc8bd67c0  push r8
00007e6bc8bd67c2  push r9
00007e6bc8bd67c4  push r10
00007e6bc8bd67c6  push r11
00007e6bc8bd67c8  sub rsp, 0xF0
00007e6bc8bd67cf  vmovaps [rsp], xmm0
00007e6bc8bd67d4  vmovaps [rsp+0x10], xmm1
00007e6bc8bd67da  vmovaps [rsp+0x20], xmm2
00007e6bc8bd67e0  vmovaps [rsp+0x30], xmm3
00007e6bc8bd67e6  vmovaps [rsp+0x40], xmm4
00007e6bc8bd67ec  vmovaps [rsp+0x50], xmm5
00007e6bc8bd67f2  vmovaps [rsp+0x60], xmm6
00007e6bc8bd67f8  vmovaps [rsp+0x70], xmm7
00007e6bc8bd67fe  vmovaps [rsp+0x80], xmm9
00007e6bc8bd6807  vmovaps [rsp+0x90], xmm10
00007e6bc8bd6810  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd6819  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd6822  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd682b  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd6834  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd683d  sub rsp, 0x30
00007e6bc8bd6841  movaps [rsp], xmm8
00007e6bc8bd6846  movaps [rsp+0x10], xmm12
00007e6bc8bd684c  movaps [rsp+0x20], xmm15
00007e6bc8bd6852  lea rdi, [rsp]
00007e6bc8bd6856  mov esi, 0x00
00007e6bc8bd685b  mov rax, 0x6543F191D530
00007e6bc8bd6865  call rax
00007e6bc8bd6867  movaps xmm8, [rsp]
00007e6bc8bd686c  add rsp, 0x30
00007e6bc8bd6870  vmovaps xmm0, [rsp]
00007e6bc8bd6875  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd687b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd6881  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd6887  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd688d  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd6893  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd6899  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd689f  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd68a8  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd68b1  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd68ba  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd68c3  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd68cc  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd68d5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd68de  add rsp, 0xF0
00007e6bc8bd68e5  pop r11
00007e6bc8bd68e7  pop r10
00007e6bc8bd68e9  pop r9
00007e6bc8bd68eb  pop r8
00007e6bc8bd68ed  pop rsi
00007e6bc8bd68ee  pop rdi
00007e6bc8bd68ef  pop rdx
00007e6bc8bd68f0  pop rcx
00007e6bc8bd68f1  pop rax
00007e6bc8bd68f2  add rsp, 0x08
00007e6bc8bd68f6  jmp 0x00007E6BC8BD599A
00007e6bc8bd68fb  sub rsp, 0x08
00007e6bc8bd68ff  push rax
00007e6bc8bd6900  push rcx
00007e6bc8bd6901  push rdx
00007e6bc8bd6902  push rdi
00007e6bc8bd6903  push rsi
00007e6bc8bd6904  push r8
00007e6bc8bd6906  push r9
00007e6bc8bd6908  push r10
00007e6bc8bd690a  push r11
00007e6bc8bd690c  sub rsp, 0xF0
00007e6bc8bd6913  vmovaps [rsp], xmm0
00007e6bc8bd6918  vmovaps [rsp+0x10], xmm1
00007e6bc8bd691e  vmovaps [rsp+0x20], xmm2
00007e6bc8bd6924  vmovaps [rsp+0x30], xmm3
00007e6bc8bd692a  vmovaps [rsp+0x40], xmm4
00007e6bc8bd6930  vmovaps [rsp+0x50], xmm5
00007e6bc8bd6936  vmovaps [rsp+0x60], xmm6
00007e6bc8bd693c  vmovaps [rsp+0x70], xmm8
00007e6bc8bd6942  vmovaps [rsp+0x80], xmm9
00007e6bc8bd694b  vmovaps [rsp+0x90], xmm10
00007e6bc8bd6954  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd695d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd6966  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd696f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd6978  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd6981  sub rsp, 0x30
00007e6bc8bd6985  movaps [rsp], xmm7
00007e6bc8bd6989  movaps [rsp+0x10], xmm9
00007e6bc8bd698f  movaps [rsp+0x20], xmm15
00007e6bc8bd6995  lea rdi, [rsp]
00007e6bc8bd6999  mov esi, 0x00
00007e6bc8bd699e  mov rax, 0x6543F191D530
00007e6bc8bd69a8  call rax
00007e6bc8bd69aa  movaps xmm7, [rsp]
00007e6bc8bd69ae  add rsp, 0x30
00007e6bc8bd69b2  vmovaps xmm0, [rsp]
00007e6bc8bd69b7  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd69bd  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd69c3  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd69c9  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd69cf  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd69d5  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd69db  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd69e1  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd69ea  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd69f3  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd69fc  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd6a05  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd6a0e  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd6a17  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd6a20  add rsp, 0xF0
00007e6bc8bd6a27  pop r11
00007e6bc8bd6a29  pop r10
00007e6bc8bd6a2b  pop r9
00007e6bc8bd6a2d  pop r8
00007e6bc8bd6a2f  pop rsi
00007e6bc8bd6a30  pop rdi
00007e6bc8bd6a31  pop rdx
00007e6bc8bd6a32  pop rcx
00007e6bc8bd6a33  pop rax
00007e6bc8bd6a34  add rsp, 0x08
00007e6bc8bd6a38  jmp 0x00007E6BC8BD59C8
00007e6bc8bd6a3d  sub rsp, 0x08
00007e6bc8bd6a41  push rax
00007e6bc8bd6a42  push rcx
00007e6bc8bd6a43  push rdx
00007e6bc8bd6a44  push rdi
00007e6bc8bd6a45  push rsi
00007e6bc8bd6a46  push r8
00007e6bc8bd6a48  push r9
00007e6bc8bd6a4a  push r10
00007e6bc8bd6a4c  push r11
00007e6bc8bd6a4e  sub rsp, 0xF0
00007e6bc8bd6a55  vmovaps [rsp], xmm0
00007e6bc8bd6a5a  vmovaps [rsp+0x10], xmm1
00007e6bc8bd6a60  vmovaps [rsp+0x20], xmm2
00007e6bc8bd6a66  vmovaps [rsp+0x30], xmm3
00007e6bc8bd6a6c  vmovaps [rsp+0x40], xmm4
00007e6bc8bd6a72  vmovaps [rsp+0x50], xmm5
00007e6bc8bd6a78  vmovaps [rsp+0x60], xmm6
00007e6bc8bd6a7e  vmovaps [rsp+0x70], xmm7
00007e6bc8bd6a84  vmovaps [rsp+0x80], xmm8
00007e6bc8bd6a8d  vmovaps [rsp+0x90], xmm10
00007e6bc8bd6a96  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd6a9f  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd6aa8  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd6ab1  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd6aba  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd6ac3  sub rsp, 0x30
00007e6bc8bd6ac7  movaps [rsp], xmm9
00007e6bc8bd6acc  movaps [rsp+0x10], xmm12
00007e6bc8bd6ad2  movaps [rsp+0x20], xmm10
00007e6bc8bd6ad8  lea rdi, [rsp]
00007e6bc8bd6adc  mov esi, 0x00
00007e6bc8bd6ae1  mov rax, 0x6543F191D530
00007e6bc8bd6aeb  call rax
00007e6bc8bd6aed  movaps xmm9, [rsp]
00007e6bc8bd6af2  add rsp, 0x30
00007e6bc8bd6af6  vmovaps xmm0, [rsp]
00007e6bc8bd6afb  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd6b01  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd6b07  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd6b0d  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd6b13  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd6b19  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd6b1f  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd6b25  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd6b2e  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd6b37  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd6b40  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd6b49  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd6b52  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd6b5b  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd6b64  add rsp, 0xF0
00007e6bc8bd6b6b  pop r11
00007e6bc8bd6b6d  pop r10
00007e6bc8bd6b6f  pop r9
00007e6bc8bd6b71  pop r8
00007e6bc8bd6b73  pop rsi
00007e6bc8bd6b74  pop rdi
00007e6bc8bd6b75  pop rdx
00007e6bc8bd6b76  pop rcx
00007e6bc8bd6b77  pop rax
00007e6bc8bd6b78  add rsp, 0x08
00007e6bc8bd6b7c  jmp 0x00007E6BC8BD59EC
00007e6bc8bd6b81  sub rsp, 0x08
00007e6bc8bd6b85  push rax
00007e6bc8bd6b86  push rcx
00007e6bc8bd6b87  push rdx
00007e6bc8bd6b88  push rdi
00007e6bc8bd6b89  push rsi
00007e6bc8bd6b8a  push r8
00007e6bc8bd6b8c  push r9
00007e6bc8bd6b8e  push r10
00007e6bc8bd6b90  push r11
00007e6bc8bd6b92  sub rsp, 0xF0
00007e6bc8bd6b99  vmovaps [rsp], xmm0
00007e6bc8bd6b9e  vmovaps [rsp+0x10], xmm1
00007e6bc8bd6ba4  vmovaps [rsp+0x20], xmm2
00007e6bc8bd6baa  vmovaps [rsp+0x30], xmm3
00007e6bc8bd6bb0  vmovaps [rsp+0x40], xmm4
00007e6bc8bd6bb6  vmovaps [rsp+0x50], xmm5
00007e6bc8bd6bbc  vmovaps [rsp+0x60], xmm6
00007e6bc8bd6bc2  vmovaps [rsp+0x70], xmm7
00007e6bc8bd6bc8  vmovaps [rsp+0x80], xmm8
00007e6bc8bd6bd1  vmovaps [rsp+0x90], xmm9
00007e6bc8bd6bda  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd6be3  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd6bec  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd6bf5  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd6bfe  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd6c07  sub rsp, 0x30
00007e6bc8bd6c0b  movaps [rsp], xmm10
00007e6bc8bd6c10  movaps [rsp+0x10], xmm12
00007e6bc8bd6c16  movaps [rsp+0x20], xmm11
00007e6bc8bd6c1c  lea rdi, [rsp]
00007e6bc8bd6c20  mov esi, 0x00
00007e6bc8bd6c25  mov rax, 0x6543F191D530
00007e6bc8bd6c2f  call rax
00007e6bc8bd6c31  movaps xmm10, [rsp]
00007e6bc8bd6c36  add rsp, 0x30
00007e6bc8bd6c3a  vmovaps xmm0, [rsp]
00007e6bc8bd6c3f  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd6c45  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd6c4b  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd6c51  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd6c57  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd6c5d  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd6c63  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd6c69  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd6c72  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd6c7b  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd6c84  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd6c8d  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd6c96  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd6c9f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd6ca8  add rsp, 0xF0
00007e6bc8bd6caf  pop r11
00007e6bc8bd6cb1  pop r10
00007e6bc8bd6cb3  pop r9
00007e6bc8bd6cb5  pop r8
00007e6bc8bd6cb7  pop rsi
00007e6bc8bd6cb8  pop rdi
00007e6bc8bd6cb9  pop rdx
00007e6bc8bd6cba  pop rcx
00007e6bc8bd6cbb  pop rax
00007e6bc8bd6cbc  add rsp, 0x08
00007e6bc8bd6cc0  jmp 0x00007E6BC8BD5A06
00007e6bc8bd6cc5  sub rsp, 0x08
00007e6bc8bd6cc9  push rax
00007e6bc8bd6cca  push rcx
00007e6bc8bd6ccb  push rdx
00007e6bc8bd6ccc  push rdi
00007e6bc8bd6ccd  push rsi
00007e6bc8bd6cce  push r8
00007e6bc8bd6cd0  push r9
00007e6bc8bd6cd2  push r10
00007e6bc8bd6cd4  push r11
00007e6bc8bd6cd6  sub rsp, 0xF0
00007e6bc8bd6cdd  vmovaps [rsp], xmm0
00007e6bc8bd6ce2  vmovaps [rsp+0x10], xmm1
00007e6bc8bd6ce8  vmovaps [rsp+0x20], xmm2
00007e6bc8bd6cee  vmovaps [rsp+0x30], xmm3
00007e6bc8bd6cf4  vmovaps [rsp+0x40], xmm4
00007e6bc8bd6cfa  vmovaps [rsp+0x50], xmm5
00007e6bc8bd6d00  vmovaps [rsp+0x60], xmm7
00007e6bc8bd6d06  vmovaps [rsp+0x70], xmm8
00007e6bc8bd6d0c  vmovaps [rsp+0x80], xmm9
00007e6bc8bd6d15  vmovaps [rsp+0x90], xmm10
00007e6bc8bd6d1e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd6d27  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd6d30  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd6d39  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd6d42  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd6d4b  sub rsp, 0x30
00007e6bc8bd6d4f  movaps [rsp], xmm6
00007e6bc8bd6d53  movaps [rsp+0x10], xmm12
00007e6bc8bd6d59  movaps [rsp+0x20], xmm11
00007e6bc8bd6d5f  lea rdi, [rsp]
00007e6bc8bd6d63  mov esi, 0x00
00007e6bc8bd6d68  mov rax, 0x6543F191D530
00007e6bc8bd6d72  call rax
00007e6bc8bd6d74  movaps xmm6, [rsp]
00007e6bc8bd6d78  add rsp, 0x30
00007e6bc8bd6d7c  vmovaps xmm0, [rsp]
00007e6bc8bd6d81  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd6d87  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd6d8d  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd6d93  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd6d99  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd6d9f  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd6da5  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd6dab  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd6db4  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd6dbd  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd6dc6  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd6dcf  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd6dd8  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd6de1  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd6dea  add rsp, 0xF0
00007e6bc8bd6df1  pop r11
00007e6bc8bd6df3  pop r10
00007e6bc8bd6df5  pop r9
00007e6bc8bd6df7  pop r8
00007e6bc8bd6df9  pop rsi
00007e6bc8bd6dfa  pop rdi
00007e6bc8bd6dfb  pop rdx
00007e6bc8bd6dfc  pop rcx
00007e6bc8bd6dfd  pop rax
00007e6bc8bd6dfe  add rsp, 0x08
00007e6bc8bd6e02  jmp 0x00007E6BC8BD5A27
00007e6bc8bd6e07  sub rsp, 0x08
00007e6bc8bd6e0b  push rax
00007e6bc8bd6e0c  push rcx
00007e6bc8bd6e0d  push rdx
00007e6bc8bd6e0e  push rdi
00007e6bc8bd6e0f  push rsi
00007e6bc8bd6e10  push r8
00007e6bc8bd6e12  push r9
00007e6bc8bd6e14  push r10
00007e6bc8bd6e16  push r11
00007e6bc8bd6e18  sub rsp, 0xF0
00007e6bc8bd6e1f  vmovaps [rsp], xmm0
00007e6bc8bd6e24  vmovaps [rsp+0x10], xmm1
00007e6bc8bd6e2a  vmovaps [rsp+0x20], xmm2
00007e6bc8bd6e30  vmovaps [rsp+0x30], xmm4
00007e6bc8bd6e36  vmovaps [rsp+0x40], xmm5
00007e6bc8bd6e3c  vmovaps [rsp+0x50], xmm6
00007e6bc8bd6e42  vmovaps [rsp+0x60], xmm7
00007e6bc8bd6e48  vmovaps [rsp+0x70], xmm8
00007e6bc8bd6e4e  vmovaps [rsp+0x80], xmm9
00007e6bc8bd6e57  vmovaps [rsp+0x90], xmm10
00007e6bc8bd6e60  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd6e69  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd6e72  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd6e7b  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd6e84  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd6e8d  sub rsp, 0x30
00007e6bc8bd6e91  movaps [rsp], xmm3
00007e6bc8bd6e95  movaps [rsp+0x10], xmm5
00007e6bc8bd6e9a  movaps [rsp+0x20], xmm4
00007e6bc8bd6e9f  lea rdi, [rsp]
00007e6bc8bd6ea3  mov esi, 0x00
00007e6bc8bd6ea8  mov rax, 0x6543F191D530
00007e6bc8bd6eb2  call rax
00007e6bc8bd6eb4  movaps xmm3, [rsp]
00007e6bc8bd6eb8  add rsp, 0x30
00007e6bc8bd6ebc  vmovaps xmm0, [rsp]
00007e6bc8bd6ec1  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd6ec7  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd6ecd  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd6ed3  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd6ed9  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd6edf  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd6ee5  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd6eeb  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd6ef4  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd6efd  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd6f06  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd6f0f  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd6f18  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd6f21  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd6f2a  add rsp, 0xF0
00007e6bc8bd6f31  pop r11
00007e6bc8bd6f33  pop r10
00007e6bc8bd6f35  pop r9
00007e6bc8bd6f37  pop r8
00007e6bc8bd6f39  pop rsi
00007e6bc8bd6f3a  pop rdi
00007e6bc8bd6f3b  pop rdx
00007e6bc8bd6f3c  pop rcx
00007e6bc8bd6f3d  pop rax
00007e6bc8bd6f3e  add rsp, 0x08
00007e6bc8bd6f42  jmp 0x00007E6BC8BD5A88
00007e6bc8bd6f47  sub rsp, 0x08
00007e6bc8bd6f4b  push rax
00007e6bc8bd6f4c  push rcx
00007e6bc8bd6f4d  push rdx
00007e6bc8bd6f4e  push rdi
00007e6bc8bd6f4f  push rsi
00007e6bc8bd6f50  push r8
00007e6bc8bd6f52  push r9
00007e6bc8bd6f54  push r10
00007e6bc8bd6f56  push r11
00007e6bc8bd6f58  sub rsp, 0xF0
00007e6bc8bd6f5f  vmovaps [rsp], xmm0
00007e6bc8bd6f64  vmovaps [rsp+0x10], xmm1
00007e6bc8bd6f6a  vmovaps [rsp+0x20], xmm2
00007e6bc8bd6f70  vmovaps [rsp+0x30], xmm3
00007e6bc8bd6f76  vmovaps [rsp+0x40], xmm4
00007e6bc8bd6f7c  vmovaps [rsp+0x50], xmm6
00007e6bc8bd6f82  vmovaps [rsp+0x60], xmm7
00007e6bc8bd6f88  vmovaps [rsp+0x70], xmm8
00007e6bc8bd6f8e  vmovaps [rsp+0x80], xmm9
00007e6bc8bd6f97  vmovaps [rsp+0x90], xmm10
00007e6bc8bd6fa0  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd6fa9  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd6fb2  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd6fbb  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd6fc4  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd6fcd  sub rsp, 0x30
00007e6bc8bd6fd1  movaps [rsp], xmm5
00007e6bc8bd6fd5  movaps [rsp+0x10], xmm8
00007e6bc8bd6fdb  movaps [rsp+0x20], xmm15
00007e6bc8bd6fe1  lea rdi, [rsp]
00007e6bc8bd6fe5  mov esi, 0x00
00007e6bc8bd6fea  mov rax, 0x6543F191D530
00007e6bc8bd6ff4  call rax
00007e6bc8bd6ff6  movaps xmm5, [rsp]
00007e6bc8bd6ffa  add rsp, 0x30
00007e6bc8bd6ffe  vmovaps xmm0, [rsp]
00007e6bc8bd7003  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd7009  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd700f  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd7015  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd701b  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd7021  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd7027  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd702d  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd7036  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd703f  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd7048  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd7051  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd705a  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd7063  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd706c  add rsp, 0xF0
00007e6bc8bd7073  pop r11
00007e6bc8bd7075  pop r10
00007e6bc8bd7077  pop r9
00007e6bc8bd7079  pop r8
00007e6bc8bd707b  pop rsi
00007e6bc8bd707c  pop rdi
00007e6bc8bd707d  pop rdx
00007e6bc8bd707e  pop rcx
00007e6bc8bd707f  pop rax
00007e6bc8bd7080  add rsp, 0x08
00007e6bc8bd7084  jmp 0x00007E6BC8BD5AC0
00007e6bc8bd7089  sub rsp, 0x08
00007e6bc8bd708d  push rax
00007e6bc8bd708e  push rcx
00007e6bc8bd708f  push rdx
00007e6bc8bd7090  push rdi
00007e6bc8bd7091  push rsi
00007e6bc8bd7092  push r8
00007e6bc8bd7094  push r9
00007e6bc8bd7096  push r10
00007e6bc8bd7098  push r11
00007e6bc8bd709a  sub rsp, 0xF0
00007e6bc8bd70a1  vmovaps [rsp], xmm0
00007e6bc8bd70a6  vmovaps [rsp+0x10], xmm1
00007e6bc8bd70ac  vmovaps [rsp+0x20], xmm2
00007e6bc8bd70b2  vmovaps [rsp+0x30], xmm3
00007e6bc8bd70b8  vmovaps [rsp+0x40], xmm5
00007e6bc8bd70be  vmovaps [rsp+0x50], xmm6
00007e6bc8bd70c4  vmovaps [rsp+0x60], xmm7
00007e6bc8bd70ca  vmovaps [rsp+0x70], xmm8
00007e6bc8bd70d0  vmovaps [rsp+0x80], xmm9
00007e6bc8bd70d9  vmovaps [rsp+0x90], xmm10
00007e6bc8bd70e2  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd70eb  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd70f4  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd70fd  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd7106  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd710f  sub rsp, 0x30
00007e6bc8bd7113  movaps [rsp], xmm4
00007e6bc8bd7117  movaps [rsp+0x10], xmm9
00007e6bc8bd711d  movaps [rsp+0x20], xmm8
00007e6bc8bd7123  lea rdi, [rsp]
00007e6bc8bd7127  mov esi, 0x00
00007e6bc8bd712c  mov rax, 0x6543F191D530
00007e6bc8bd7136  call rax
00007e6bc8bd7138  movaps xmm4, [rsp]
00007e6bc8bd713c  add rsp, 0x30
00007e6bc8bd7140  vmovaps xmm0, [rsp]
00007e6bc8bd7145  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd714b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd7151  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd7157  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd715d  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd7163  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd7169  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd716f  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd7178  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd7181  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd718a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd7193  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd719c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd71a5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd71ae  add rsp, 0xF0
00007e6bc8bd71b5  pop r11
00007e6bc8bd71b7  pop r10
00007e6bc8bd71b9  pop r9
00007e6bc8bd71bb  pop r8
00007e6bc8bd71bd  pop rsi
00007e6bc8bd71be  pop rdi
00007e6bc8bd71bf  pop rdx
00007e6bc8bd71c0  pop rcx
00007e6bc8bd71c1  pop rax
00007e6bc8bd71c2  add rsp, 0x08
00007e6bc8bd71c6  jmp 0x00007E6BC8BD5AE1
00007e6bc8bd71cb  sub rsp, 0x08
00007e6bc8bd71cf  push rax
00007e6bc8bd71d0  push rcx
00007e6bc8bd71d1  push rdx
00007e6bc8bd71d2  push rdi
00007e6bc8bd71d3  push rsi
00007e6bc8bd71d4  push r8
00007e6bc8bd71d6  push r9
00007e6bc8bd71d8  push r10
00007e6bc8bd71da  push r11
00007e6bc8bd71dc  sub rsp, 0xF0
00007e6bc8bd71e3  vmovaps [rsp], xmm0
00007e6bc8bd71e8  vmovaps [rsp+0x10], xmm1
00007e6bc8bd71ee  vmovaps [rsp+0x20], xmm2
00007e6bc8bd71f4  vmovaps [rsp+0x30], xmm3
00007e6bc8bd71fa  vmovaps [rsp+0x40], xmm4
00007e6bc8bd7200  vmovaps [rsp+0x50], xmm5
00007e6bc8bd7206  vmovaps [rsp+0x60], xmm6
00007e6bc8bd720c  vmovaps [rsp+0x70], xmm7
00007e6bc8bd7212  vmovaps [rsp+0x80], xmm8
00007e6bc8bd721b  vmovaps [rsp+0x90], xmm10
00007e6bc8bd7224  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd722d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd7236  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd723f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd7248  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd7251  sub rsp, 0x30
00007e6bc8bd7255  movaps [rsp], xmm9
00007e6bc8bd725a  movaps [rsp+0x10], xmm10
00007e6bc8bd7260  movaps [rsp+0x20], xmm8
00007e6bc8bd7266  lea rdi, [rsp]
00007e6bc8bd726a  mov esi, 0x00
00007e6bc8bd726f  mov rax, 0x6543F191D530
00007e6bc8bd7279  call rax
00007e6bc8bd727b  movaps xmm9, [rsp]
00007e6bc8bd7280  add rsp, 0x30
00007e6bc8bd7284  vmovaps xmm0, [rsp]
00007e6bc8bd7289  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd728f  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd7295  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd729b  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd72a1  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd72a7  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd72ad  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd72b3  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd72bc  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd72c5  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd72ce  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd72d7  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd72e0  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd72e9  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd72f2  add rsp, 0xF0
00007e6bc8bd72f9  pop r11
00007e6bc8bd72fb  pop r10
00007e6bc8bd72fd  pop r9
00007e6bc8bd72ff  pop r8
00007e6bc8bd7301  pop rsi
00007e6bc8bd7302  pop rdi
00007e6bc8bd7303  pop rdx
00007e6bc8bd7304  pop rcx
00007e6bc8bd7305  pop rax
00007e6bc8bd7306  add rsp, 0x08
00007e6bc8bd730a  jmp 0x00007E6BC8BD5AFB
00007e6bc8bd730f  call 0x00007E6BC8AD64F0
00007e6bc8bd7314  jmp 0x00007E6BC8BD5C15
00007e6bc8bd7319  call 0x00007E6BC8AD64F0
00007e6bc8bd731e  jmp 0x00007E6BC8BD5C2B
00007e6bc8bd7323  sub rsp, 0x08
00007e6bc8bd7327  push rax
00007e6bc8bd7328  push rcx
00007e6bc8bd7329  push rdx
00007e6bc8bd732a  push rdi
00007e6bc8bd732b  push rsi
00007e6bc8bd732c  push r8
00007e6bc8bd732e  push r9
00007e6bc8bd7330  push r10
00007e6bc8bd7332  push r11
00007e6bc8bd7334  sub rsp, 0xF0
00007e6bc8bd733b  vmovaps [rsp], xmm0
00007e6bc8bd7340  vmovaps [rsp+0x10], xmm2
00007e6bc8bd7346  vmovaps [rsp+0x20], xmm3
00007e6bc8bd734c  vmovaps [rsp+0x30], xmm4
00007e6bc8bd7352  vmovaps [rsp+0x40], xmm5
00007e6bc8bd7358  vmovaps [rsp+0x50], xmm6
00007e6bc8bd735e  vmovaps [rsp+0x60], xmm7
00007e6bc8bd7364  vmovaps [rsp+0x70], xmm8
00007e6bc8bd736a  vmovaps [rsp+0x80], xmm9
00007e6bc8bd7373  vmovaps [rsp+0x90], xmm10
00007e6bc8bd737c  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd7385  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd738e  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd7397  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd73a0  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd73a9  sub rsp, 0x30
00007e6bc8bd73ad  movaps [rsp], xmm1
00007e6bc8bd73b1  movaps [rsp+0x10], xmm6
00007e6bc8bd73b6  movaps [rsp+0x20], xmm15
00007e6bc8bd73bc  lea rdi, [rsp]
00007e6bc8bd73c0  mov esi, 0x00
00007e6bc8bd73c5  mov rax, 0x6543F191D530
00007e6bc8bd73cf  call rax
00007e6bc8bd73d1  movaps xmm1, [rsp]
00007e6bc8bd73d5  add rsp, 0x30
00007e6bc8bd73d9  vmovaps xmm0, [rsp]
00007e6bc8bd73de  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd73e4  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd73ea  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd73f0  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd73f6  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd73fc  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd7402  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd7408  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd7411  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd741a  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd7423  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd742c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd7435  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd743e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd7447  add rsp, 0xF0
00007e6bc8bd744e  pop r11
00007e6bc8bd7450  pop r10
00007e6bc8bd7452  pop r9
00007e6bc8bd7454  pop r8
00007e6bc8bd7456  pop rsi
00007e6bc8bd7457  pop rdi
00007e6bc8bd7458  pop rdx
00007e6bc8bd7459  pop rcx
00007e6bc8bd745a  pop rax
00007e6bc8bd745b  add rsp, 0x08
00007e6bc8bd745f  jmp 0x00007E6BC8BD5C68
00007e6bc8bd7464  call 0x00007E6BC8AE5820
00007e6bc8bd7469  jmp 0x00007E6BC8BD5C75
00007e6bc8bd746e  sub rsp, 0x08
00007e6bc8bd7472  push rax
00007e6bc8bd7473  push rcx
00007e6bc8bd7474  push rdx
00007e6bc8bd7475  push rdi
00007e6bc8bd7476  push rsi
00007e6bc8bd7477  push r8
00007e6bc8bd7479  push r9
00007e6bc8bd747b  push r10
00007e6bc8bd747d  push r11
00007e6bc8bd747f  sub rsp, 0xF0
00007e6bc8bd7486  vmovaps [rsp], xmm0
00007e6bc8bd748b  vmovaps [rsp+0x10], xmm1
00007e6bc8bd7491  vmovaps [rsp+0x20], xmm2
00007e6bc8bd7497  vmovaps [rsp+0x30], xmm3
00007e6bc8bd749d  vmovaps [rsp+0x40], xmm4
00007e6bc8bd74a3  vmovaps [rsp+0x50], xmm5
00007e6bc8bd74a9  vmovaps [rsp+0x60], xmm6
00007e6bc8bd74af  vmovaps [rsp+0x70], xmm7
00007e6bc8bd74b5  vmovaps [rsp+0x80], xmm8
00007e6bc8bd74be  vmovaps [rsp+0x90], xmm9
00007e6bc8bd74c7  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd74d0  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd74d9  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd74e2  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd74eb  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd74f4  sub rsp, 0x30
00007e6bc8bd74f8  movaps [rsp], xmm14
00007e6bc8bd74fd  movaps [rsp+0x10], xmm4
00007e6bc8bd7502  movaps [rsp+0x20], xmm3
00007e6bc8bd7507  lea rdi, [rsp]
00007e6bc8bd750b  mov esi, 0x00
00007e6bc8bd7510  mov rax, 0x6543F191D530
00007e6bc8bd751a  call rax
00007e6bc8bd751c  movaps xmm14, [rsp]
00007e6bc8bd7521  add rsp, 0x30
00007e6bc8bd7525  vmovaps xmm0, [rsp]
00007e6bc8bd752a  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd7530  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd7536  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd753c  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd7542  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd7548  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd754e  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd7554  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd755d  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd7566  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd756f  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd7578  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd7581  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd758a  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd7593  add rsp, 0xF0
00007e6bc8bd759a  pop r11
00007e6bc8bd759c  pop r10
00007e6bc8bd759e  pop r9
00007e6bc8bd75a0  pop r8
00007e6bc8bd75a2  pop rsi
00007e6bc8bd75a3  pop rdi
00007e6bc8bd75a4  pop rdx
00007e6bc8bd75a5  pop rcx
00007e6bc8bd75a6  pop rax
00007e6bc8bd75a7  add rsp, 0x08
00007e6bc8bd75ab  jmp 0x00007E6BC8BD5C8F
00007e6bc8bd75b0  sub rsp, 0x08
00007e6bc8bd75b4  push rax
00007e6bc8bd75b5  push rcx
00007e6bc8bd75b6  push rdx
00007e6bc8bd75b7  push rdi
00007e6bc8bd75b8  push rsi
00007e6bc8bd75b9  push r8
00007e6bc8bd75bb  push r9
00007e6bc8bd75bd  push r10
00007e6bc8bd75bf  push r11
00007e6bc8bd75c1  sub rsp, 0xF0
00007e6bc8bd75c8  vmovaps [rsp], xmm0
00007e6bc8bd75cd  vmovaps [rsp+0x10], xmm1
00007e6bc8bd75d3  vmovaps [rsp+0x20], xmm2
00007e6bc8bd75d9  vmovaps [rsp+0x30], xmm3
00007e6bc8bd75df  vmovaps [rsp+0x40], xmm4
00007e6bc8bd75e5  vmovaps [rsp+0x50], xmm5
00007e6bc8bd75eb  vmovaps [rsp+0x60], xmm7
00007e6bc8bd75f1  vmovaps [rsp+0x70], xmm8
00007e6bc8bd75f7  vmovaps [rsp+0x80], xmm9
00007e6bc8bd7600  vmovaps [rsp+0x90], xmm10
00007e6bc8bd7609  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd7612  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd761b  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd7624  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd762d  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd7636  sub rsp, 0x30
00007e6bc8bd763a  movaps [rsp], xmm6
00007e6bc8bd763e  movaps [rsp+0x10], xmm9
00007e6bc8bd7644  movaps [rsp+0x20], xmm7
00007e6bc8bd7649  lea rdi, [rsp]
00007e6bc8bd764d  mov esi, 0x00
00007e6bc8bd7652  mov rax, 0x6543F191D530
00007e6bc8bd765c  call rax
00007e6bc8bd765e  movaps xmm6, [rsp]
00007e6bc8bd7662  add rsp, 0x30
00007e6bc8bd7666  vmovaps xmm0, [rsp]
00007e6bc8bd766b  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd7671  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd7677  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd767d  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd7683  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd7689  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd768f  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd7695  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd769e  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd76a7  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd76b0  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd76b9  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd76c2  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd76cb  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd76d4  add rsp, 0xF0
00007e6bc8bd76db  pop r11
00007e6bc8bd76dd  pop r10
00007e6bc8bd76df  pop r9
00007e6bc8bd76e1  pop r8
00007e6bc8bd76e3  pop rsi
00007e6bc8bd76e4  pop rdi
00007e6bc8bd76e5  pop rdx
00007e6bc8bd76e6  pop rcx
00007e6bc8bd76e7  pop rax
00007e6bc8bd76e8  add rsp, 0x08
00007e6bc8bd76ec  jmp 0x00007E6BC8BD5CA7
00007e6bc8bd76f1  sub rsp, 0x08
00007e6bc8bd76f5  push rax
00007e6bc8bd76f6  push rcx
00007e6bc8bd76f7  push rdx
00007e6bc8bd76f8  push rdi
00007e6bc8bd76f9  push rsi
00007e6bc8bd76fa  push r8
00007e6bc8bd76fc  push r9
00007e6bc8bd76fe  push r10
00007e6bc8bd7700  push r11
00007e6bc8bd7702  sub rsp, 0xF0
00007e6bc8bd7709  vmovaps [rsp], xmm0
00007e6bc8bd770e  vmovaps [rsp+0x10], xmm1
00007e6bc8bd7714  vmovaps [rsp+0x20], xmm2
00007e6bc8bd771a  vmovaps [rsp+0x30], xmm3
00007e6bc8bd7720  vmovaps [rsp+0x40], xmm4
00007e6bc8bd7726  vmovaps [rsp+0x50], xmm5
00007e6bc8bd772c  vmovaps [rsp+0x60], xmm6
00007e6bc8bd7732  vmovaps [rsp+0x70], xmm8
00007e6bc8bd7738  vmovaps [rsp+0x80], xmm9
00007e6bc8bd7741  vmovaps [rsp+0x90], xmm10
00007e6bc8bd774a  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd7753  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd775c  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd7765  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd776e  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd7777  sub rsp, 0x30
00007e6bc8bd777b  movaps [rsp], xmm7
00007e6bc8bd777f  movaps [rsp+0x10], xmm4
00007e6bc8bd7784  movaps [rsp+0x20], xmm9
00007e6bc8bd778a  lea rdi, [rsp]
00007e6bc8bd778e  mov esi, 0x00
00007e6bc8bd7793  mov rax, 0x6543F191D530
00007e6bc8bd779d  call rax
00007e6bc8bd779f  movaps xmm7, [rsp]
00007e6bc8bd77a3  add rsp, 0x30
00007e6bc8bd77a7  vmovaps xmm0, [rsp]
00007e6bc8bd77ac  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd77b2  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd77b8  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd77be  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd77c4  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd77ca  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd77d0  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd77d6  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd77df  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd77e8  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd77f1  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd77fa  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd7803  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd780c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd7815  add rsp, 0xF0
00007e6bc8bd781c  pop r11
00007e6bc8bd781e  pop r10
00007e6bc8bd7820  pop r9
00007e6bc8bd7822  pop r8
00007e6bc8bd7824  pop rsi
00007e6bc8bd7825  pop rdi
00007e6bc8bd7826  pop rdx
00007e6bc8bd7827  pop rcx
00007e6bc8bd7828  pop rax
00007e6bc8bd7829  add rsp, 0x08
00007e6bc8bd782d  jmp 0x00007E6BC8BD5CD4
00007e6bc8bd7832  sub rsp, 0x08
00007e6bc8bd7836  push rax
00007e6bc8bd7837  push rcx
00007e6bc8bd7838  push rdx
00007e6bc8bd7839  push rdi
00007e6bc8bd783a  push rsi
00007e6bc8bd783b  push r8
00007e6bc8bd783d  push r9
00007e6bc8bd783f  push r10
00007e6bc8bd7841  push r11
00007e6bc8bd7843  sub rsp, 0xF0
00007e6bc8bd784a  vmovaps [rsp], xmm0
00007e6bc8bd784f  vmovaps [rsp+0x10], xmm1
00007e6bc8bd7855  vmovaps [rsp+0x20], xmm2
00007e6bc8bd785b  vmovaps [rsp+0x30], xmm3
00007e6bc8bd7861  vmovaps [rsp+0x40], xmm5
00007e6bc8bd7867  vmovaps [rsp+0x50], xmm6
00007e6bc8bd786d  vmovaps [rsp+0x60], xmm7
00007e6bc8bd7873  vmovaps [rsp+0x70], xmm8
00007e6bc8bd7879  vmovaps [rsp+0x80], xmm9
00007e6bc8bd7882  vmovaps [rsp+0x90], xmm10
00007e6bc8bd788b  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd7894  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd789d  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd78a6  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd78af  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd78b8  sub rsp, 0x30
00007e6bc8bd78bc  movaps [rsp], xmm4
00007e6bc8bd78c0  movaps [rsp+0x10], xmm15
00007e6bc8bd78c6  movaps [rsp+0x20], xmm9
00007e6bc8bd78cc  lea rdi, [rsp]
00007e6bc8bd78d0  mov esi, 0x00
00007e6bc8bd78d5  mov rax, 0x6543F191D530
00007e6bc8bd78df  call rax
00007e6bc8bd78e1  movaps xmm4, [rsp]
00007e6bc8bd78e5  add rsp, 0x30
00007e6bc8bd78e9  vmovaps xmm0, [rsp]
00007e6bc8bd78ee  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd78f4  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd78fa  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd7900  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd7906  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd790c  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd7912  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd7918  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd7921  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd792a  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd7933  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd793c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd7945  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd794e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd7957  add rsp, 0xF0
00007e6bc8bd795e  pop r11
00007e6bc8bd7960  pop r10
00007e6bc8bd7962  pop r9
00007e6bc8bd7964  pop r8
00007e6bc8bd7966  pop rsi
00007e6bc8bd7967  pop rdi
00007e6bc8bd7968  pop rdx
00007e6bc8bd7969  pop rcx
00007e6bc8bd796a  pop rax
00007e6bc8bd796b  add rsp, 0x08
00007e6bc8bd796f  jmp 0x00007E6BC8BD5CF9
00007e6bc8bd7974  call 0x00007E6BC8AE5820
00007e6bc8bd7979  jmp 0x00007E6BC8BD5D06
00007e6bc8bd797e  sub rsp, 0x08
00007e6bc8bd7982  push rax
00007e6bc8bd7983  push rcx
00007e6bc8bd7984  push rdx
00007e6bc8bd7985  push rdi
00007e6bc8bd7986  push rsi
00007e6bc8bd7987  push r8
00007e6bc8bd7989  push r9
00007e6bc8bd798b  push r10
00007e6bc8bd798d  push r11
00007e6bc8bd798f  sub rsp, 0xF0
00007e6bc8bd7996  vmovaps [rsp], xmm0
00007e6bc8bd799b  vmovaps [rsp+0x10], xmm1
00007e6bc8bd79a1  vmovaps [rsp+0x20], xmm2
00007e6bc8bd79a7  vmovaps [rsp+0x30], xmm4
00007e6bc8bd79ad  vmovaps [rsp+0x40], xmm5
00007e6bc8bd79b3  vmovaps [rsp+0x50], xmm6
00007e6bc8bd79b9  vmovaps [rsp+0x60], xmm7
00007e6bc8bd79bf  vmovaps [rsp+0x70], xmm8
00007e6bc8bd79c5  vmovaps [rsp+0x80], xmm9
00007e6bc8bd79ce  vmovaps [rsp+0x90], xmm10
00007e6bc8bd79d7  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd79e0  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd79e9  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd79f2  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd79fb  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd7a04  sub rsp, 0x30
00007e6bc8bd7a08  movaps [rsp], xmm3
00007e6bc8bd7a0c  movaps [rsp+0x10], xmm1
00007e6bc8bd7a11  movaps [rsp+0x20], xmm9
00007e6bc8bd7a17  lea rdi, [rsp]
00007e6bc8bd7a1b  mov esi, 0x00
00007e6bc8bd7a20  mov rax, 0x6543F191D530
00007e6bc8bd7a2a  call rax
00007e6bc8bd7a2c  movaps xmm3, [rsp]
00007e6bc8bd7a30  add rsp, 0x30
00007e6bc8bd7a34  vmovaps xmm0, [rsp]
00007e6bc8bd7a39  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd7a3f  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd7a45  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd7a4b  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd7a51  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd7a57  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd7a5d  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd7a63  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd7a6c  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd7a75  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd7a7e  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd7a87  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd7a90  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd7a99  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd7aa2  add rsp, 0xF0
00007e6bc8bd7aa9  pop r11
00007e6bc8bd7aab  pop r10
00007e6bc8bd7aad  pop r9
00007e6bc8bd7aaf  pop r8
00007e6bc8bd7ab1  pop rsi
00007e6bc8bd7ab2  pop rdi
00007e6bc8bd7ab3  pop rdx
00007e6bc8bd7ab4  pop rcx
00007e6bc8bd7ab5  pop rax
00007e6bc8bd7ab6  add rsp, 0x08
00007e6bc8bd7aba  jmp 0x00007E6BC8BD5D43
00007e6bc8bd7abf  sub rsp, 0x08
00007e6bc8bd7ac3  push rax
00007e6bc8bd7ac4  push rcx
00007e6bc8bd7ac5  push rdx
00007e6bc8bd7ac6  push rdi
00007e6bc8bd7ac7  push rsi
00007e6bc8bd7ac8  push r8
00007e6bc8bd7aca  push r9
00007e6bc8bd7acc  push r10
00007e6bc8bd7ace  push r11
00007e6bc8bd7ad0  sub rsp, 0xF0
00007e6bc8bd7ad7  vmovaps [rsp], xmm0
00007e6bc8bd7adc  vmovaps [rsp+0x10], xmm2
00007e6bc8bd7ae2  vmovaps [rsp+0x20], xmm3
00007e6bc8bd7ae8  vmovaps [rsp+0x30], xmm4
00007e6bc8bd7aee  vmovaps [rsp+0x40], xmm5
00007e6bc8bd7af4  vmovaps [rsp+0x50], xmm6
00007e6bc8bd7afa  vmovaps [rsp+0x60], xmm7
00007e6bc8bd7b00  vmovaps [rsp+0x70], xmm8
00007e6bc8bd7b06  vmovaps [rsp+0x80], xmm9
00007e6bc8bd7b0f  vmovaps [rsp+0x90], xmm10
00007e6bc8bd7b18  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd7b21  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd7b2a  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd7b33  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd7b3c  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd7b45  sub rsp, 0x30
00007e6bc8bd7b49  movaps [rsp], xmm1
00007e6bc8bd7b4d  movaps [rsp+0x10], xmm15
00007e6bc8bd7b53  movaps [rsp+0x20], xmm9
00007e6bc8bd7b59  lea rdi, [rsp]
00007e6bc8bd7b5d  mov esi, 0x00
00007e6bc8bd7b62  mov rax, 0x6543F191D530
00007e6bc8bd7b6c  call rax
00007e6bc8bd7b6e  movaps xmm1, [rsp]
00007e6bc8bd7b72  add rsp, 0x30
00007e6bc8bd7b76  vmovaps xmm0, [rsp]
00007e6bc8bd7b7b  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd7b81  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd7b87  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd7b8d  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd7b93  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd7b99  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd7b9f  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd7ba5  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd7bae  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd7bb7  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd7bc0  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd7bc9  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd7bd2  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd7bdb  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd7be4  add rsp, 0xF0
00007e6bc8bd7beb  pop r11
00007e6bc8bd7bed  pop r10
00007e6bc8bd7bef  pop r9
00007e6bc8bd7bf1  pop r8
00007e6bc8bd7bf3  pop rsi
00007e6bc8bd7bf4  pop rdi
00007e6bc8bd7bf5  pop rdx
00007e6bc8bd7bf6  pop rcx
00007e6bc8bd7bf7  pop rax
00007e6bc8bd7bf8  add rsp, 0x08
00007e6bc8bd7bfc  jmp 0x00007E6BC8BD5DCB
00007e6bc8bd7c01  call 0x00007E6BC8AE5820
00007e6bc8bd7c06  jmp 0x00007E6BC8BD5DD8
00007e6bc8bd7c0b  sub rsp, 0x08
00007e6bc8bd7c0f  push rax
00007e6bc8bd7c10  push rcx
00007e6bc8bd7c11  push rdx
00007e6bc8bd7c12  push rdi
00007e6bc8bd7c13  push rsi
00007e6bc8bd7c14  push r8
00007e6bc8bd7c16  push r9
00007e6bc8bd7c18  push r10
00007e6bc8bd7c1a  push r11
00007e6bc8bd7c1c  sub rsp, 0xF0
00007e6bc8bd7c23  vmovaps [rsp], xmm0
00007e6bc8bd7c28  vmovaps [rsp+0x10], xmm2
00007e6bc8bd7c2e  vmovaps [rsp+0x20], xmm3
00007e6bc8bd7c34  vmovaps [rsp+0x30], xmm4
00007e6bc8bd7c3a  vmovaps [rsp+0x40], xmm5
00007e6bc8bd7c40  vmovaps [rsp+0x50], xmm6
00007e6bc8bd7c46  vmovaps [rsp+0x60], xmm7
00007e6bc8bd7c4c  vmovaps [rsp+0x70], xmm8
00007e6bc8bd7c52  vmovaps [rsp+0x80], xmm9
00007e6bc8bd7c5b  vmovaps [rsp+0x90], xmm10
00007e6bc8bd7c64  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd7c6d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd7c76  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd7c7f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd7c88  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd7c91  sub rsp, 0x30
00007e6bc8bd7c95  movaps [rsp], xmm1
00007e6bc8bd7c99  movaps [rsp+0x10], xmm5
00007e6bc8bd7c9e  movaps [rsp+0x20], xmm7
00007e6bc8bd7ca3  lea rdi, [rsp]
00007e6bc8bd7ca7  mov esi, 0x00
00007e6bc8bd7cac  mov rax, 0x6543F191D530
00007e6bc8bd7cb6  call rax
00007e6bc8bd7cb8  movaps xmm1, [rsp]
00007e6bc8bd7cbc  add rsp, 0x30
00007e6bc8bd7cc0  vmovaps xmm0, [rsp]
00007e6bc8bd7cc5  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd7ccb  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd7cd1  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd7cd7  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd7cdd  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd7ce3  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd7ce9  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd7cef  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd7cf8  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd7d01  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd7d0a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd7d13  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd7d1c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd7d25  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd7d2e  add rsp, 0xF0
00007e6bc8bd7d35  pop r11
00007e6bc8bd7d37  pop r10
00007e6bc8bd7d39  pop r9
00007e6bc8bd7d3b  pop r8
00007e6bc8bd7d3d  pop rsi
00007e6bc8bd7d3e  pop rdi
00007e6bc8bd7d3f  pop rdx
00007e6bc8bd7d40  pop rcx
00007e6bc8bd7d41  pop rax
00007e6bc8bd7d42  add rsp, 0x08
00007e6bc8bd7d46  jmp 0x00007E6BC8BD5E7D
00007e6bc8bd7d4b  sub rsp, 0x08
00007e6bc8bd7d4f  push rax
00007e6bc8bd7d50  push rcx
00007e6bc8bd7d51  push rdx
00007e6bc8bd7d52  push rdi
00007e6bc8bd7d53  push rsi
00007e6bc8bd7d54  push r8
00007e6bc8bd7d56  push r9
00007e6bc8bd7d58  push r10
00007e6bc8bd7d5a  push r11
00007e6bc8bd7d5c  sub rsp, 0xF0
00007e6bc8bd7d63  vmovaps [rsp], xmm0
00007e6bc8bd7d68  vmovaps [rsp+0x10], xmm1
00007e6bc8bd7d6e  vmovaps [rsp+0x20], xmm2
00007e6bc8bd7d74  vmovaps [rsp+0x30], xmm3
00007e6bc8bd7d7a  vmovaps [rsp+0x40], xmm4
00007e6bc8bd7d80  vmovaps [rsp+0x50], xmm5
00007e6bc8bd7d86  vmovaps [rsp+0x60], xmm6
00007e6bc8bd7d8c  vmovaps [rsp+0x70], xmm8
00007e6bc8bd7d92  vmovaps [rsp+0x80], xmm9
00007e6bc8bd7d9b  vmovaps [rsp+0x90], xmm10
00007e6bc8bd7da4  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd7dad  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd7db6  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd7dbf  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd7dc8  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd7dd1  sub rsp, 0x30
00007e6bc8bd7dd5  movaps [rsp], xmm7
00007e6bc8bd7dd9  movaps [rsp+0x10], xmm5
00007e6bc8bd7dde  movaps [rsp+0x20], xmm15
00007e6bc8bd7de4  lea rdi, [rsp]
00007e6bc8bd7de8  mov esi, 0x00
00007e6bc8bd7ded  mov rax, 0x6543F191D530
00007e6bc8bd7df7  call rax
00007e6bc8bd7df9  movaps xmm7, [rsp]
00007e6bc8bd7dfd  add rsp, 0x30
00007e6bc8bd7e01  vmovaps xmm0, [rsp]
00007e6bc8bd7e06  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd7e0c  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd7e12  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd7e18  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd7e1e  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd7e24  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd7e2a  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd7e30  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd7e39  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd7e42  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd7e4b  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd7e54  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd7e5d  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd7e66  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd7e6f  add rsp, 0xF0
00007e6bc8bd7e76  pop r11
00007e6bc8bd7e78  pop r10
00007e6bc8bd7e7a  pop r9
00007e6bc8bd7e7c  pop r8
00007e6bc8bd7e7e  pop rsi
00007e6bc8bd7e7f  pop rdi
00007e6bc8bd7e80  pop rdx
00007e6bc8bd7e81  pop rcx
00007e6bc8bd7e82  pop rax
00007e6bc8bd7e83  add rsp, 0x08
00007e6bc8bd7e87  jmp 0x00007E6BC8BD5EB3
00007e6bc8bd7e8c  call 0x00007E6BC8AD64F0
00007e6bc8bd7e91  jmp 0x00007E6BC8BD5EC0
00007e6bc8bd7e96  sub rsp, 0x08
00007e6bc8bd7e9a  push rax
00007e6bc8bd7e9b  push rcx
00007e6bc8bd7e9c  push rdx
00007e6bc8bd7e9d  push rdi
00007e6bc8bd7e9e  push rsi
00007e6bc8bd7e9f  push r8
00007e6bc8bd7ea1  push r9
00007e6bc8bd7ea3  push r10
00007e6bc8bd7ea5  push r11
00007e6bc8bd7ea7  sub rsp, 0xF0
00007e6bc8bd7eae  vmovaps [rsp], xmm0
00007e6bc8bd7eb3  vmovaps [rsp+0x10], xmm1
00007e6bc8bd7eb9  vmovaps [rsp+0x20], xmm2
00007e6bc8bd7ebf  vmovaps [rsp+0x30], xmm3
00007e6bc8bd7ec5  vmovaps [rsp+0x40], xmm4
00007e6bc8bd7ecb  vmovaps [rsp+0x50], xmm5
00007e6bc8bd7ed1  vmovaps [rsp+0x60], xmm6
00007e6bc8bd7ed7  vmovaps [rsp+0x70], xmm7
00007e6bc8bd7edd  vmovaps [rsp+0x80], xmm8
00007e6bc8bd7ee6  vmovaps [rsp+0x90], xmm9
00007e6bc8bd7eef  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd7ef8  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd7f01  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd7f0a  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd7f13  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd7f1c  sub rsp, 0x30
00007e6bc8bd7f20  movaps [rsp], xmm15
00007e6bc8bd7f25  movaps [rsp+0x10], xmm5
00007e6bc8bd7f2a  movaps [rsp+0x20], xmm3
00007e6bc8bd7f2f  lea rdi, [rsp]
00007e6bc8bd7f33  mov esi, 0x00
00007e6bc8bd7f38  mov rax, 0x6543F191D530
00007e6bc8bd7f42  call rax
00007e6bc8bd7f44  movaps xmm15, [rsp]
00007e6bc8bd7f49  add rsp, 0x30
00007e6bc8bd7f4d  vmovaps xmm0, [rsp]
00007e6bc8bd7f52  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd7f58  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd7f5e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd7f64  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd7f6a  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd7f70  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd7f76  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd7f7c  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd7f85  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd7f8e  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd7f97  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd7fa0  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd7fa9  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd7fb2  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd7fbb  add rsp, 0xF0
00007e6bc8bd7fc2  pop r11
00007e6bc8bd7fc4  pop r10
00007e6bc8bd7fc6  pop r9
00007e6bc8bd7fc8  pop r8
00007e6bc8bd7fca  pop rsi
00007e6bc8bd7fcb  pop rdi
00007e6bc8bd7fcc  pop rdx
00007e6bc8bd7fcd  pop rcx
00007e6bc8bd7fce  pop rax
00007e6bc8bd7fcf  add rsp, 0x08
00007e6bc8bd7fd3  jmp 0x00007E6BC8BD5EE6
00007e6bc8bd7fd8  sub rsp, 0x08
00007e6bc8bd7fdc  push rax
00007e6bc8bd7fdd  push rcx
00007e6bc8bd7fde  push rdx
00007e6bc8bd7fdf  push rdi
00007e6bc8bd7fe0  push rsi
00007e6bc8bd7fe1  push r8
00007e6bc8bd7fe3  push r9
00007e6bc8bd7fe5  push r10
00007e6bc8bd7fe7  push r11
00007e6bc8bd7fe9  sub rsp, 0xF0
00007e6bc8bd7ff0  vmovaps [rsp], xmm0
00007e6bc8bd7ff5  vmovaps [rsp+0x10], xmm2
00007e6bc8bd7ffb  vmovaps [rsp+0x20], xmm3
00007e6bc8bd8001  vmovaps [rsp+0x30], xmm4
00007e6bc8bd8007  vmovaps [rsp+0x40], xmm5
00007e6bc8bd800d  vmovaps [rsp+0x50], xmm6
00007e6bc8bd8013  vmovaps [rsp+0x60], xmm7
00007e6bc8bd8019  vmovaps [rsp+0x70], xmm8
00007e6bc8bd801f  vmovaps [rsp+0x80], xmm9
00007e6bc8bd8028  vmovaps [rsp+0x90], xmm10
00007e6bc8bd8031  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd803a  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd8043  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd804c  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd8055  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd805e  sub rsp, 0x30
00007e6bc8bd8062  movaps [rsp], xmm1
00007e6bc8bd8066  movaps [rsp+0x10], xmm5
00007e6bc8bd806b  movaps [rsp+0x20], xmm4
00007e6bc8bd8070  lea rdi, [rsp]
00007e6bc8bd8074  mov esi, 0x00
00007e6bc8bd8079  mov rax, 0x6543F191D530
00007e6bc8bd8083  call rax
00007e6bc8bd8085  movaps xmm1, [rsp]
00007e6bc8bd8089  add rsp, 0x30
00007e6bc8bd808d  vmovaps xmm0, [rsp]
00007e6bc8bd8092  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd8098  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd809e  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd80a4  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd80aa  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd80b0  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd80b6  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd80bc  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd80c5  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd80ce  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd80d7  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd80e0  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd80e9  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd80f2  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd80fb  add rsp, 0xF0
00007e6bc8bd8102  pop r11
00007e6bc8bd8104  pop r10
00007e6bc8bd8106  pop r9
00007e6bc8bd8108  pop r8
00007e6bc8bd810a  pop rsi
00007e6bc8bd810b  pop rdi
00007e6bc8bd810c  pop rdx
00007e6bc8bd810d  pop rcx
00007e6bc8bd810e  pop rax
00007e6bc8bd810f  add rsp, 0x08
00007e6bc8bd8113  jmp 0x00007E6BC8BD5F06
00007e6bc8bd8118  sub rsp, 0x08
00007e6bc8bd811c  push rax
00007e6bc8bd811d  push rcx
00007e6bc8bd811e  push rdx
00007e6bc8bd811f  push rdi
00007e6bc8bd8120  push rsi
00007e6bc8bd8121  push r8
00007e6bc8bd8123  push r9
00007e6bc8bd8125  push r10
00007e6bc8bd8127  push r11
00007e6bc8bd8129  sub rsp, 0xF0
00007e6bc8bd8130  vmovaps [rsp], xmm0
00007e6bc8bd8135  vmovaps [rsp+0x10], xmm1
00007e6bc8bd813b  vmovaps [rsp+0x20], xmm2
00007e6bc8bd8141  vmovaps [rsp+0x30], xmm3
00007e6bc8bd8147  vmovaps [rsp+0x40], xmm5
00007e6bc8bd814d  vmovaps [rsp+0x50], xmm6
00007e6bc8bd8153  vmovaps [rsp+0x60], xmm7
00007e6bc8bd8159  vmovaps [rsp+0x70], xmm8
00007e6bc8bd815f  vmovaps [rsp+0x80], xmm9
00007e6bc8bd8168  vmovaps [rsp+0x90], xmm10
00007e6bc8bd8171  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd817a  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd8183  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd818c  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd8195  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd819e  sub rsp, 0x30
00007e6bc8bd81a2  movaps [rsp], xmm4
00007e6bc8bd81a6  movaps [rsp+0x10], xmm3
00007e6bc8bd81ab  movaps [rsp+0x20], xmm5
00007e6bc8bd81b0  lea rdi, [rsp]
00007e6bc8bd81b4  mov esi, 0x00
00007e6bc8bd81b9  mov rax, 0x6543F191D530
00007e6bc8bd81c3  call rax
00007e6bc8bd81c5  movaps xmm4, [rsp]
00007e6bc8bd81c9  add rsp, 0x30
00007e6bc8bd81cd  vmovaps xmm0, [rsp]
00007e6bc8bd81d2  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd81d8  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd81de  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd81e4  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd81ea  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd81f0  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd81f6  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd81fc  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd8205  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd820e  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd8217  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd8220  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd8229  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd8232  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd823b  add rsp, 0xF0
00007e6bc8bd8242  pop r11
00007e6bc8bd8244  pop r10
00007e6bc8bd8246  pop r9
00007e6bc8bd8248  pop r8
00007e6bc8bd824a  pop rsi
00007e6bc8bd824b  pop rdi
00007e6bc8bd824c  pop rdx
00007e6bc8bd824d  pop rcx
00007e6bc8bd824e  pop rax
00007e6bc8bd824f  add rsp, 0x08
00007e6bc8bd8253  jmp 0x00007E6BC8BD5F54
00007e6bc8bd8258  call 0x00007E6BC8AD64F0
00007e6bc8bd825d  jmp 0x00007E6BC8BD5F61
00007e6bc8bd8262  sub rsp, 0x08
00007e6bc8bd8266  push rax
00007e6bc8bd8267  push rcx
00007e6bc8bd8268  push rdx
00007e6bc8bd8269  push rdi
00007e6bc8bd826a  push rsi
00007e6bc8bd826b  push r8
00007e6bc8bd826d  push r9
00007e6bc8bd826f  push r10
00007e6bc8bd8271  push r11
00007e6bc8bd8273  sub rsp, 0xF0
00007e6bc8bd827a  vmovaps [rsp], xmm0
00007e6bc8bd827f  vmovaps [rsp+0x10], xmm1
00007e6bc8bd8285  vmovaps [rsp+0x20], xmm2
00007e6bc8bd828b  vmovaps [rsp+0x30], xmm3
00007e6bc8bd8291  vmovaps [rsp+0x40], xmm4
00007e6bc8bd8297  vmovaps [rsp+0x50], xmm6
00007e6bc8bd829d  vmovaps [rsp+0x60], xmm7
00007e6bc8bd82a3  vmovaps [rsp+0x70], xmm8
00007e6bc8bd82a9  vmovaps [rsp+0x80], xmm9
00007e6bc8bd82b2  vmovaps [rsp+0x90], xmm10
00007e6bc8bd82bb  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd82c4  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd82cd  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd82d6  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd82df  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd82e8  sub rsp, 0x30
00007e6bc8bd82ec  movaps [rsp], xmm5
00007e6bc8bd82f0  movaps [rsp+0x10], xmm6
00007e6bc8bd82f5  movaps [rsp+0x20], xmm3
00007e6bc8bd82fa  lea rdi, [rsp]
00007e6bc8bd82fe  mov esi, 0x00
00007e6bc8bd8303  mov rax, 0x6543F191D530
00007e6bc8bd830d  call rax
00007e6bc8bd830f  movaps xmm5, [rsp]
00007e6bc8bd8313  add rsp, 0x30
00007e6bc8bd8317  vmovaps xmm0, [rsp]
00007e6bc8bd831c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd8322  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd8328  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd832e  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd8334  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd833a  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd8340  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd8346  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd834f  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd8358  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd8361  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd836a  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd8373  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd837c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd8385  add rsp, 0xF0
00007e6bc8bd838c  pop r11
00007e6bc8bd838e  pop r10
00007e6bc8bd8390  pop r9
00007e6bc8bd8392  pop r8
00007e6bc8bd8394  pop rsi
00007e6bc8bd8395  pop rdi
00007e6bc8bd8396  pop rdx
00007e6bc8bd8397  pop rcx
00007e6bc8bd8398  pop rax
00007e6bc8bd8399  add rsp, 0x08
00007e6bc8bd839d  jmp 0x00007E6BC8BD5F87
00007e6bc8bd83a2  sub rsp, 0x08
00007e6bc8bd83a6  push rax
00007e6bc8bd83a7  push rcx
00007e6bc8bd83a8  push rdx
00007e6bc8bd83a9  push rdi
00007e6bc8bd83aa  push rsi
00007e6bc8bd83ab  push r8
00007e6bc8bd83ad  push r9
00007e6bc8bd83af  push r10
00007e6bc8bd83b1  push r11
00007e6bc8bd83b3  sub rsp, 0xF0
00007e6bc8bd83ba  vmovaps [rsp], xmm0
00007e6bc8bd83bf  vmovaps [rsp+0x10], xmm1
00007e6bc8bd83c5  vmovaps [rsp+0x20], xmm2
00007e6bc8bd83cb  vmovaps [rsp+0x30], xmm3
00007e6bc8bd83d1  vmovaps [rsp+0x40], xmm4
00007e6bc8bd83d7  vmovaps [rsp+0x50], xmm5
00007e6bc8bd83dd  vmovaps [rsp+0x60], xmm7
00007e6bc8bd83e3  vmovaps [rsp+0x70], xmm8
00007e6bc8bd83e9  vmovaps [rsp+0x80], xmm9
00007e6bc8bd83f2  vmovaps [rsp+0x90], xmm10
00007e6bc8bd83fb  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd8404  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd840d  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd8416  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd841f  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd8428  sub rsp, 0x30
00007e6bc8bd842c  movaps [rsp], xmm6
00007e6bc8bd8430  movaps [rsp+0x10], xmm9
00007e6bc8bd8436  movaps [rsp+0x20], xmm1
00007e6bc8bd843b  lea rdi, [rsp]
00007e6bc8bd843f  mov esi, 0x00
00007e6bc8bd8444  mov rax, 0x6543F191D530
00007e6bc8bd844e  call rax
00007e6bc8bd8450  movaps xmm6, [rsp]
00007e6bc8bd8454  add rsp, 0x30
00007e6bc8bd8458  vmovaps xmm0, [rsp]
00007e6bc8bd845d  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd8463  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd8469  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd846f  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd8475  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd847b  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd8481  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd8487  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd8490  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd8499  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd84a2  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd84ab  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd84b4  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd84bd  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd84c6  add rsp, 0xF0
00007e6bc8bd84cd  pop r11
00007e6bc8bd84cf  pop r10
00007e6bc8bd84d1  pop r9
00007e6bc8bd84d3  pop r8
00007e6bc8bd84d5  pop rsi
00007e6bc8bd84d6  pop rdi
00007e6bc8bd84d7  pop rdx
00007e6bc8bd84d8  pop rcx
00007e6bc8bd84d9  pop rax
00007e6bc8bd84da  add rsp, 0x08
00007e6bc8bd84de  jmp 0x00007E6BC8BD5FAB
00007e6bc8bd84e3  sub rsp, 0x08
00007e6bc8bd84e7  push rax
00007e6bc8bd84e8  push rcx
00007e6bc8bd84e9  push rdx
00007e6bc8bd84ea  push rdi
00007e6bc8bd84eb  push rsi
00007e6bc8bd84ec  push r8
00007e6bc8bd84ee  push r9
00007e6bc8bd84f0  push r10
00007e6bc8bd84f2  push r11
00007e6bc8bd84f4  sub rsp, 0xF0
00007e6bc8bd84fb  vmovaps [rsp], xmm0
00007e6bc8bd8500  vmovaps [rsp+0x10], xmm1
00007e6bc8bd8506  vmovaps [rsp+0x20], xmm2
00007e6bc8bd850c  vmovaps [rsp+0x30], xmm3
00007e6bc8bd8512  vmovaps [rsp+0x40], xmm4
00007e6bc8bd8518  vmovaps [rsp+0x50], xmm5
00007e6bc8bd851e  vmovaps [rsp+0x60], xmm6
00007e6bc8bd8524  vmovaps [rsp+0x70], xmm7
00007e6bc8bd852a  vmovaps [rsp+0x80], xmm8
00007e6bc8bd8533  vmovaps [rsp+0x90], xmm10
00007e6bc8bd853c  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd8545  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd854e  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd8557  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd8560  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd8569  sub rsp, 0x30
00007e6bc8bd856d  movaps [rsp], xmm9
00007e6bc8bd8572  movaps [rsp+0x10], xmm3
00007e6bc8bd8577  movaps [rsp+0x20], xmm1
00007e6bc8bd857c  lea rdi, [rsp]
00007e6bc8bd8580  mov esi, 0x00
00007e6bc8bd8585  mov rax, 0x6543F191D530
00007e6bc8bd858f  call rax
00007e6bc8bd8591  movaps xmm9, [rsp]
00007e6bc8bd8596  add rsp, 0x30
00007e6bc8bd859a  vmovaps xmm0, [rsp]
00007e6bc8bd859f  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd85a5  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd85ab  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd85b1  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd85b7  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd85bd  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd85c3  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd85c9  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd85d2  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd85db  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd85e4  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd85ed  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd85f6  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd85ff  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd8608  add rsp, 0xF0
00007e6bc8bd860f  pop r11
00007e6bc8bd8611  pop r10
00007e6bc8bd8613  pop r9
00007e6bc8bd8615  pop r8
00007e6bc8bd8617  pop rsi
00007e6bc8bd8618  pop rdi
00007e6bc8bd8619  pop rdx
00007e6bc8bd861a  pop rcx
00007e6bc8bd861b  pop rax
00007e6bc8bd861c  add rsp, 0x08
00007e6bc8bd8620  jmp 0x00007E6BC8BD5FF7
00007e6bc8bd8625  call 0x00007E6BC8AD64F0
00007e6bc8bd862a  jmp 0x00007E6BC8BD6004
00007e6bc8bd862f  sub rsp, 0x08
00007e6bc8bd8633  push rax
00007e6bc8bd8634  push rcx
00007e6bc8bd8635  push rdx
00007e6bc8bd8636  push rdi
00007e6bc8bd8637  push rsi
00007e6bc8bd8638  push r8
00007e6bc8bd863a  push r9
00007e6bc8bd863c  push r10
00007e6bc8bd863e  push r11
00007e6bc8bd8640  sub rsp, 0xF0
00007e6bc8bd8647  vmovaps [rsp], xmm0
00007e6bc8bd864c  vmovaps [rsp+0x10], xmm1
00007e6bc8bd8652  vmovaps [rsp+0x20], xmm2
00007e6bc8bd8658  vmovaps [rsp+0x30], xmm3
00007e6bc8bd865e  vmovaps [rsp+0x40], xmm4
00007e6bc8bd8664  vmovaps [rsp+0x50], xmm5
00007e6bc8bd866a  vmovaps [rsp+0x60], xmm6
00007e6bc8bd8670  vmovaps [rsp+0x70], xmm7
00007e6bc8bd8676  vmovaps [rsp+0x80], xmm8
00007e6bc8bd867f  vmovaps [rsp+0x90], xmm9
00007e6bc8bd8688  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd8691  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd869a  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd86a3  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd86ac  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd86b5  sub rsp, 0x30
00007e6bc8bd86b9  movaps [rsp], xmm15
00007e6bc8bd86be  movaps [rsp+0x10], xmm3
00007e6bc8bd86c3  movaps [rsp+0x20], xmm7
00007e6bc8bd86c8  lea rdi, [rsp]
00007e6bc8bd86cc  mov esi, 0x00
00007e6bc8bd86d1  mov rax, 0x6543F191D530
00007e6bc8bd86db  call rax
00007e6bc8bd86dd  movaps xmm15, [rsp]
00007e6bc8bd86e2  add rsp, 0x30
00007e6bc8bd86e6  vmovaps xmm0, [rsp]
00007e6bc8bd86eb  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd86f1  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd86f7  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd86fd  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd8703  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd8709  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd870f  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd8715  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd871e  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd8727  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd8730  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd8739  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd8742  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd874b  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd8754  add rsp, 0xF0
00007e6bc8bd875b  pop r11
00007e6bc8bd875d  pop r10
00007e6bc8bd875f  pop r9
00007e6bc8bd8761  pop r8
00007e6bc8bd8763  pop rsi
00007e6bc8bd8764  pop rdi
00007e6bc8bd8765  pop rdx
00007e6bc8bd8766  pop rcx
00007e6bc8bd8767  pop rax
00007e6bc8bd8768  add rsp, 0x08
00007e6bc8bd876c  jmp 0x00007E6BC8BD6030
00007e6bc8bd8771  sub rsp, 0x08
00007e6bc8bd8775  push rax
00007e6bc8bd8776  push rcx
00007e6bc8bd8777  push rdx
00007e6bc8bd8778  push rdi
00007e6bc8bd8779  push rsi
00007e6bc8bd877a  push r8
00007e6bc8bd877c  push r9
00007e6bc8bd877e  push r10
00007e6bc8bd8780  push r11
00007e6bc8bd8782  sub rsp, 0xF0
00007e6bc8bd8789  vmovaps [rsp], xmm0
00007e6bc8bd878e  vmovaps [rsp+0x10], xmm1
00007e6bc8bd8794  vmovaps [rsp+0x20], xmm2
00007e6bc8bd879a  vmovaps [rsp+0x30], xmm4
00007e6bc8bd87a0  vmovaps [rsp+0x40], xmm5
00007e6bc8bd87a6  vmovaps [rsp+0x50], xmm6
00007e6bc8bd87ac  vmovaps [rsp+0x60], xmm7
00007e6bc8bd87b2  vmovaps [rsp+0x70], xmm8
00007e6bc8bd87b8  vmovaps [rsp+0x80], xmm9
00007e6bc8bd87c1  vmovaps [rsp+0x90], xmm10
00007e6bc8bd87ca  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd87d3  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd87dc  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd87e5  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd87ee  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd87f7  sub rsp, 0x30
00007e6bc8bd87fb  movaps [rsp], xmm3
00007e6bc8bd87ff  movaps [rsp+0x10], xmm1
00007e6bc8bd8804  movaps [rsp+0x20], xmm15
00007e6bc8bd880a  lea rdi, [rsp]
00007e6bc8bd880e  mov esi, 0x00
00007e6bc8bd8813  mov rax, 0x6543F191D530
00007e6bc8bd881d  call rax
00007e6bc8bd881f  movaps xmm3, [rsp]
00007e6bc8bd8823  add rsp, 0x30
00007e6bc8bd8827  vmovaps xmm0, [rsp]
00007e6bc8bd882c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd8832  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd8838  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd883e  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd8844  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd884a  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd8850  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd8856  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd885f  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd8868  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd8871  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd887a  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd8883  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd888c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd8895  add rsp, 0xF0
00007e6bc8bd889c  pop r11
00007e6bc8bd889e  pop r10
00007e6bc8bd88a0  pop r9
00007e6bc8bd88a2  pop r8
00007e6bc8bd88a4  pop rsi
00007e6bc8bd88a5  pop rdi
00007e6bc8bd88a6  pop rdx
00007e6bc8bd88a7  pop rcx
00007e6bc8bd88a8  pop rax
00007e6bc8bd88a9  add rsp, 0x08
00007e6bc8bd88ad  jmp 0x00007E6BC8BD60BF
00007e6bc8bd88b2  call 0x00007E6BC8AD64F0
00007e6bc8bd88b7  jmp 0x00007E6BC8BD60C9
00007e6bc8bd88bc  sub rsp, 0x08
00007e6bc8bd88c0  push rax
00007e6bc8bd88c1  push rcx
00007e6bc8bd88c2  push rdx
00007e6bc8bd88c3  push rdi
00007e6bc8bd88c4  push rsi
00007e6bc8bd88c5  push r8
00007e6bc8bd88c7  push r9
00007e6bc8bd88c9  push r10
00007e6bc8bd88cb  push r11
00007e6bc8bd88cd  sub rsp, 0xF0
00007e6bc8bd88d4  vmovaps [rsp], xmm0
00007e6bc8bd88d9  vmovaps [rsp+0x10], xmm1
00007e6bc8bd88df  vmovaps [rsp+0x20], xmm2
00007e6bc8bd88e5  vmovaps [rsp+0x30], xmm3
00007e6bc8bd88eb  vmovaps [rsp+0x40], xmm4
00007e6bc8bd88f1  vmovaps [rsp+0x50], xmm5
00007e6bc8bd88f7  vmovaps [rsp+0x60], xmm6
00007e6bc8bd88fd  vmovaps [rsp+0x70], xmm7
00007e6bc8bd8903  vmovaps [rsp+0x80], xmm8
00007e6bc8bd890c  vmovaps [rsp+0x90], xmm9
00007e6bc8bd8915  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd891e  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd8927  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd8930  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd8939  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd8942  sub rsp, 0x30
00007e6bc8bd8946  movaps [rsp], xmm15
00007e6bc8bd894b  movaps [rsp+0x10], xmm14
00007e6bc8bd8951  movaps [rsp+0x20], xmm4
00007e6bc8bd8956  lea rdi, [rsp]
00007e6bc8bd895a  mov esi, 0x00
00007e6bc8bd895f  mov rax, 0x6543F191D530
00007e6bc8bd8969  call rax
00007e6bc8bd896b  movaps xmm15, [rsp]
00007e6bc8bd8970  add rsp, 0x30
00007e6bc8bd8974  vmovaps xmm0, [rsp]
00007e6bc8bd8979  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd897f  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd8985  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd898b  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd8991  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd8997  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd899d  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd89a3  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd89ac  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd89b5  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd89be  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd89c7  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd89d0  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd89d9  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd89e2  add rsp, 0xF0
00007e6bc8bd89e9  pop r11
00007e6bc8bd89eb  pop r10
00007e6bc8bd89ed  pop r9
00007e6bc8bd89ef  pop r8
00007e6bc8bd89f1  pop rsi
00007e6bc8bd89f2  pop rdi
00007e6bc8bd89f3  pop rdx
00007e6bc8bd89f4  pop rcx
00007e6bc8bd89f5  pop rax
00007e6bc8bd89f6  add rsp, 0x08
00007e6bc8bd89fa  jmp 0x00007E6BC8BD60F7
00007e6bc8bd89ff  sub rsp, 0x08
00007e6bc8bd8a03  push rax
00007e6bc8bd8a04  push rcx
00007e6bc8bd8a05  push rdx
00007e6bc8bd8a06  push rdi
00007e6bc8bd8a07  push rsi
00007e6bc8bd8a08  push r8
00007e6bc8bd8a0a  push r9
00007e6bc8bd8a0c  push r10
00007e6bc8bd8a0e  push r11
00007e6bc8bd8a10  sub rsp, 0xF0
00007e6bc8bd8a17  vmovaps [rsp], xmm0
00007e6bc8bd8a1c  vmovaps [rsp+0x10], xmm1
00007e6bc8bd8a22  vmovaps [rsp+0x20], xmm2
00007e6bc8bd8a28  vmovaps [rsp+0x30], xmm3
00007e6bc8bd8a2e  vmovaps [rsp+0x40], xmm4
00007e6bc8bd8a34  vmovaps [rsp+0x50], xmm5
00007e6bc8bd8a3a  vmovaps [rsp+0x60], xmm6
00007e6bc8bd8a40  vmovaps [rsp+0x70], xmm7
00007e6bc8bd8a46  vmovaps [rsp+0x80], xmm8
00007e6bc8bd8a4f  vmovaps [rsp+0x90], xmm9
00007e6bc8bd8a58  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd8a61  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd8a6a  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd8a73  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd8a7c  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd8a85  sub rsp, 0x30
00007e6bc8bd8a89  movaps [rsp], xmm14
00007e6bc8bd8a8e  movaps [rsp+0x10], xmm2
00007e6bc8bd8a93  movaps [rsp+0x20], xmm1
00007e6bc8bd8a98  lea rdi, [rsp]
00007e6bc8bd8a9c  mov esi, 0x00
00007e6bc8bd8aa1  mov rax, 0x6543F191D530
00007e6bc8bd8aab  call rax
00007e6bc8bd8aad  movaps xmm14, [rsp]
00007e6bc8bd8ab2  add rsp, 0x30
00007e6bc8bd8ab6  vmovaps xmm0, [rsp]
00007e6bc8bd8abb  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd8ac1  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd8ac7  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd8acd  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd8ad3  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd8ad9  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd8adf  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd8ae5  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd8aee  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd8af7  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd8b00  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd8b09  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd8b12  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd8b1b  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd8b24  add rsp, 0xF0
00007e6bc8bd8b2b  pop r11
00007e6bc8bd8b2d  pop r10
00007e6bc8bd8b2f  pop r9
00007e6bc8bd8b31  pop r8
00007e6bc8bd8b33  pop rsi
00007e6bc8bd8b34  pop rdi
00007e6bc8bd8b35  pop rdx
00007e6bc8bd8b36  pop rcx
00007e6bc8bd8b37  pop rax
00007e6bc8bd8b38  add rsp, 0x08
00007e6bc8bd8b3c  jmp 0x00007E6BC8BD611D
00007e6bc8bd8b41  sub rsp, 0x08
00007e6bc8bd8b45  push rax
00007e6bc8bd8b46  push rcx
00007e6bc8bd8b47  push rdx
00007e6bc8bd8b48  push rdi
00007e6bc8bd8b49  push rsi
00007e6bc8bd8b4a  push r8
00007e6bc8bd8b4c  push r9
00007e6bc8bd8b4e  push r10
00007e6bc8bd8b50  push r11
00007e6bc8bd8b52  sub rsp, 0xF0
00007e6bc8bd8b59  vmovaps [rsp], xmm0
00007e6bc8bd8b5e  vmovaps [rsp+0x10], xmm2
00007e6bc8bd8b64  vmovaps [rsp+0x20], xmm3
00007e6bc8bd8b6a  vmovaps [rsp+0x30], xmm4
00007e6bc8bd8b70  vmovaps [rsp+0x40], xmm5
00007e6bc8bd8b76  vmovaps [rsp+0x50], xmm6
00007e6bc8bd8b7c  vmovaps [rsp+0x60], xmm7
00007e6bc8bd8b82  vmovaps [rsp+0x70], xmm8
00007e6bc8bd8b88  vmovaps [rsp+0x80], xmm9
00007e6bc8bd8b91  vmovaps [rsp+0x90], xmm10
00007e6bc8bd8b9a  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd8ba3  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd8bac  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd8bb5  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd8bbe  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd8bc7  sub rsp, 0x30
00007e6bc8bd8bcb  movaps [rsp], xmm1
00007e6bc8bd8bcf  movaps [rsp+0x10], xmm4
00007e6bc8bd8bd4  movaps [rsp+0x20], xmm9
00007e6bc8bd8bda  lea rdi, [rsp]
00007e6bc8bd8bde  mov esi, 0x00
00007e6bc8bd8be3  mov rax, 0x6543F191D530
00007e6bc8bd8bed  call rax
00007e6bc8bd8bef  movaps xmm1, [rsp]
00007e6bc8bd8bf3  add rsp, 0x30
00007e6bc8bd8bf7  vmovaps xmm0, [rsp]
00007e6bc8bd8bfc  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd8c02  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd8c08  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd8c0e  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd8c14  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd8c1a  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd8c20  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd8c26  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd8c2f  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd8c38  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd8c41  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd8c4a  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd8c53  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd8c5c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd8c65  add rsp, 0xF0
00007e6bc8bd8c6c  pop r11
00007e6bc8bd8c6e  pop r10
00007e6bc8bd8c70  pop r9
00007e6bc8bd8c72  pop r8
00007e6bc8bd8c74  pop rsi
00007e6bc8bd8c75  pop rdi
00007e6bc8bd8c76  pop rdx
00007e6bc8bd8c77  pop rcx
00007e6bc8bd8c78  pop rax
00007e6bc8bd8c79  add rsp, 0x08
00007e6bc8bd8c7d  jmp 0x00007E6BC8BD613B
00007e6bc8bd8c82  sub rsp, 0x08
00007e6bc8bd8c86  push rax
00007e6bc8bd8c87  push rcx
00007e6bc8bd8c88  push rdx
00007e6bc8bd8c89  push rdi
00007e6bc8bd8c8a  push rsi
00007e6bc8bd8c8b  push r8
00007e6bc8bd8c8d  push r9
00007e6bc8bd8c8f  push r10
00007e6bc8bd8c91  push r11
00007e6bc8bd8c93  sub rsp, 0xF0
00007e6bc8bd8c9a  vmovaps [rsp], xmm0
00007e6bc8bd8c9f  vmovaps [rsp+0x10], xmm1
00007e6bc8bd8ca5  vmovaps [rsp+0x20], xmm2
00007e6bc8bd8cab  vmovaps [rsp+0x30], xmm3
00007e6bc8bd8cb1  vmovaps [rsp+0x40], xmm5
00007e6bc8bd8cb7  vmovaps [rsp+0x50], xmm6
00007e6bc8bd8cbd  vmovaps [rsp+0x60], xmm7
00007e6bc8bd8cc3  vmovaps [rsp+0x70], xmm8
00007e6bc8bd8cc9  vmovaps [rsp+0x80], xmm9
00007e6bc8bd8cd2  vmovaps [rsp+0x90], xmm10
00007e6bc8bd8cdb  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd8ce4  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd8ced  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd8cf6  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd8cff  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd8d08  sub rsp, 0x30
00007e6bc8bd8d0c  movaps [rsp], xmm4
00007e6bc8bd8d10  movaps [rsp+0x10], xmm2
00007e6bc8bd8d15  movaps [rsp+0x20], xmm9
00007e6bc8bd8d1b  lea rdi, [rsp]
00007e6bc8bd8d1f  mov esi, 0x00
00007e6bc8bd8d24  mov rax, 0x6543F191D530
00007e6bc8bd8d2e  call rax
00007e6bc8bd8d30  movaps xmm4, [rsp]
00007e6bc8bd8d34  add rsp, 0x30
00007e6bc8bd8d38  vmovaps xmm0, [rsp]
00007e6bc8bd8d3d  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd8d43  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd8d49  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd8d4f  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd8d55  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd8d5b  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd8d61  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd8d67  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd8d70  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd8d79  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd8d82  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd8d8b  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd8d94  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd8d9d  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd8da6  add rsp, 0xF0
00007e6bc8bd8dad  pop r11
00007e6bc8bd8daf  pop r10
00007e6bc8bd8db1  pop r9
00007e6bc8bd8db3  pop r8
00007e6bc8bd8db5  pop rsi
00007e6bc8bd8db6  pop rdi
00007e6bc8bd8db7  pop rdx
00007e6bc8bd8db8  pop rcx
00007e6bc8bd8db9  pop rax
00007e6bc8bd8dba  add rsp, 0x08
00007e6bc8bd8dbe  jmp 0x00007E6BC8BD616B
00007e6bc8bd8dc3  sub rsp, 0x08
00007e6bc8bd8dc7  push rax
00007e6bc8bd8dc8  push rcx
00007e6bc8bd8dc9  push rdx
00007e6bc8bd8dca  push rdi
00007e6bc8bd8dcb  push rsi
00007e6bc8bd8dcc  push r8
00007e6bc8bd8dce  push r9
00007e6bc8bd8dd0  push r10
00007e6bc8bd8dd2  push r11
00007e6bc8bd8dd4  sub rsp, 0xF0
00007e6bc8bd8ddb  vmovaps [rsp], xmm0
00007e6bc8bd8de0  vmovaps [rsp+0x10], xmm1
00007e6bc8bd8de6  vmovaps [rsp+0x20], xmm2
00007e6bc8bd8dec  vmovaps [rsp+0x30], xmm3
00007e6bc8bd8df2  vmovaps [rsp+0x40], xmm4
00007e6bc8bd8df8  vmovaps [rsp+0x50], xmm5
00007e6bc8bd8dfe  vmovaps [rsp+0x60], xmm6
00007e6bc8bd8e04  vmovaps [rsp+0x70], xmm7
00007e6bc8bd8e0a  vmovaps [rsp+0x80], xmm8
00007e6bc8bd8e13  vmovaps [rsp+0x90], xmm10
00007e6bc8bd8e1c  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd8e25  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd8e2e  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd8e37  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd8e40  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd8e49  sub rsp, 0x30
00007e6bc8bd8e4d  movaps [rsp], xmm9
00007e6bc8bd8e52  movaps [rsp+0x10], xmm2
00007e6bc8bd8e57  movaps [rsp+0x20], xmm1
00007e6bc8bd8e5c  lea rdi, [rsp]
00007e6bc8bd8e60  mov esi, 0x00
00007e6bc8bd8e65  mov rax, 0x6543F191D530
00007e6bc8bd8e6f  call rax
00007e6bc8bd8e71  movaps xmm9, [rsp]
00007e6bc8bd8e76  add rsp, 0x30
00007e6bc8bd8e7a  vmovaps xmm0, [rsp]
00007e6bc8bd8e7f  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd8e85  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd8e8b  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd8e91  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd8e97  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd8e9d  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd8ea3  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd8ea9  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd8eb2  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd8ebb  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd8ec4  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd8ecd  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd8ed6  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd8edf  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd8ee8  add rsp, 0xF0
00007e6bc8bd8eef  pop r11
00007e6bc8bd8ef1  pop r10
00007e6bc8bd8ef3  pop r9
00007e6bc8bd8ef5  pop r8
00007e6bc8bd8ef7  pop rsi
00007e6bc8bd8ef8  pop rdi
00007e6bc8bd8ef9  pop rdx
00007e6bc8bd8efa  pop rcx
00007e6bc8bd8efb  pop rax
00007e6bc8bd8efc  add rsp, 0x08
00007e6bc8bd8f00  jmp 0x00007E6BC8BD61A1
00007e6bc8bd8f05  sub rsp, 0x08
00007e6bc8bd8f09  push rax
00007e6bc8bd8f0a  push rcx
00007e6bc8bd8f0b  push rdx
00007e6bc8bd8f0c  push rdi
00007e6bc8bd8f0d  push rsi
00007e6bc8bd8f0e  push r8
00007e6bc8bd8f10  push r9
00007e6bc8bd8f12  push r10
00007e6bc8bd8f14  push r11
00007e6bc8bd8f16  sub rsp, 0xF0
00007e6bc8bd8f1d  vmovaps [rsp], xmm0
00007e6bc8bd8f22  vmovaps [rsp+0x10], xmm2
00007e6bc8bd8f28  vmovaps [rsp+0x20], xmm3
00007e6bc8bd8f2e  vmovaps [rsp+0x30], xmm4
00007e6bc8bd8f34  vmovaps [rsp+0x40], xmm5
00007e6bc8bd8f3a  vmovaps [rsp+0x50], xmm6
00007e6bc8bd8f40  vmovaps [rsp+0x60], xmm7
00007e6bc8bd8f46  vmovaps [rsp+0x70], xmm8
00007e6bc8bd8f4c  vmovaps [rsp+0x80], xmm9
00007e6bc8bd8f55  vmovaps [rsp+0x90], xmm10
00007e6bc8bd8f5e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd8f67  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd8f70  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd8f79  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd8f82  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd8f8b  sub rsp, 0x30
00007e6bc8bd8f8f  movaps [rsp], xmm1
00007e6bc8bd8f93  movaps [rsp+0x10], xmm15
00007e6bc8bd8f99  movaps [rsp+0x20], xmm6
00007e6bc8bd8f9e  lea rdi, [rsp]
00007e6bc8bd8fa2  mov esi, 0x00
00007e6bc8bd8fa7  mov rax, 0x6543F191D530
00007e6bc8bd8fb1  call rax
00007e6bc8bd8fb3  movaps xmm1, [rsp]
00007e6bc8bd8fb7  add rsp, 0x30
00007e6bc8bd8fbb  vmovaps xmm0, [rsp]
00007e6bc8bd8fc0  vmovaps xmm2, [rsp+0x10]
00007e6bc8bd8fc6  vmovaps xmm3, [rsp+0x20]
00007e6bc8bd8fcc  vmovaps xmm4, [rsp+0x30]
00007e6bc8bd8fd2  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd8fd8  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd8fde  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd8fe4  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd8fea  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd8ff3  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd8ffc  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd9005  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd900e  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd9017  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd9020  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd9029  add rsp, 0xF0
00007e6bc8bd9030  pop r11
00007e6bc8bd9032  pop r10
00007e6bc8bd9034  pop r9
00007e6bc8bd9036  pop r8
00007e6bc8bd9038  pop rsi
00007e6bc8bd9039  pop rdi
00007e6bc8bd903a  pop rdx
00007e6bc8bd903b  pop rcx
00007e6bc8bd903c  pop rax
00007e6bc8bd903d  add rsp, 0x08
00007e6bc8bd9041  jmp 0x00007E6BC8BD61C2
00007e6bc8bd9046  sub rsp, 0x08
00007e6bc8bd904a  push rax
00007e6bc8bd904b  push rcx
00007e6bc8bd904c  push rdx
00007e6bc8bd904d  push rdi
00007e6bc8bd904e  push rsi
00007e6bc8bd904f  push r8
00007e6bc8bd9051  push r9
00007e6bc8bd9053  push r10
00007e6bc8bd9055  push r11
00007e6bc8bd9057  sub rsp, 0xF0
00007e6bc8bd905e  vmovaps [rsp], xmm0
00007e6bc8bd9063  vmovaps [rsp+0x10], xmm1
00007e6bc8bd9069  vmovaps [rsp+0x20], xmm2
00007e6bc8bd906f  vmovaps [rsp+0x30], xmm3
00007e6bc8bd9075  vmovaps [rsp+0x40], xmm4
00007e6bc8bd907b  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9081  vmovaps [rsp+0x60], xmm6
00007e6bc8bd9087  vmovaps [rsp+0x70], xmm7
00007e6bc8bd908d  vmovaps [rsp+0x80], xmm8
00007e6bc8bd9096  vmovaps [rsp+0x90], xmm9
00007e6bc8bd909f  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd90a8  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd90b1  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd90ba  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd90c3  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd90cc  sub rsp, 0x30
00007e6bc8bd90d0  movaps [rsp], xmm15
00007e6bc8bd90d5  movaps [rsp+0x10], xmm5
00007e6bc8bd90da  movaps [rsp+0x20], xmm3
00007e6bc8bd90df  lea rdi, [rsp]
00007e6bc8bd90e3  mov esi, 0x00
00007e6bc8bd90e8  mov rax, 0x6543F191D530
00007e6bc8bd90f2  call rax
00007e6bc8bd90f4  movaps xmm15, [rsp]
00007e6bc8bd90f9  add rsp, 0x30
00007e6bc8bd90fd  vmovaps xmm0, [rsp]
00007e6bc8bd9102  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9108  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd910e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd9114  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd911a  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd9120  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd9126  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd912c  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd9135  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd913e  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd9147  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd9150  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd9159  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd9162  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd916b  add rsp, 0xF0
00007e6bc8bd9172  pop r11
00007e6bc8bd9174  pop r10
00007e6bc8bd9176  pop r9
00007e6bc8bd9178  pop r8
00007e6bc8bd917a  pop rsi
00007e6bc8bd917b  pop rdi
00007e6bc8bd917c  pop rdx
00007e6bc8bd917d  pop rcx
00007e6bc8bd917e  pop rax
00007e6bc8bd917f  add rsp, 0x08
00007e6bc8bd9183  jmp 0x00007E6BC8BD61DC
00007e6bc8bd9188  sub rsp, 0x08
00007e6bc8bd918c  push rax
00007e6bc8bd918d  push rcx
00007e6bc8bd918e  push rdx
00007e6bc8bd918f  push rdi
00007e6bc8bd9190  push rsi
00007e6bc8bd9191  push r8
00007e6bc8bd9193  push r9
00007e6bc8bd9195  push r10
00007e6bc8bd9197  push r11
00007e6bc8bd9199  sub rsp, 0xF0
00007e6bc8bd91a0  vmovaps [rsp], xmm0
00007e6bc8bd91a5  vmovaps [rsp+0x10], xmm1
00007e6bc8bd91ab  vmovaps [rsp+0x20], xmm2
00007e6bc8bd91b1  vmovaps [rsp+0x30], xmm3
00007e6bc8bd91b7  vmovaps [rsp+0x40], xmm4
00007e6bc8bd91bd  vmovaps [rsp+0x50], xmm6
00007e6bc8bd91c3  vmovaps [rsp+0x60], xmm7
00007e6bc8bd91c9  vmovaps [rsp+0x70], xmm8
00007e6bc8bd91cf  vmovaps [rsp+0x80], xmm9
00007e6bc8bd91d8  vmovaps [rsp+0x90], xmm10
00007e6bc8bd91e1  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd91ea  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd91f3  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd91fc  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9205  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd920e  sub rsp, 0x30
00007e6bc8bd9212  movaps [rsp], xmm5
00007e6bc8bd9216  movaps [rsp+0x10], xmm8
00007e6bc8bd921c  movaps [rsp+0x20], xmm6
00007e6bc8bd9221  lea rdi, [rsp]
00007e6bc8bd9225  mov esi, 0x00
00007e6bc8bd922a  mov rax, 0x6543F191D530
00007e6bc8bd9234  call rax
00007e6bc8bd9236  movaps xmm5, [rsp]
00007e6bc8bd923a  add rsp, 0x30
00007e6bc8bd923e  vmovaps xmm0, [rsp]
00007e6bc8bd9243  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9249  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd924f  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd9255  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd925b  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd9261  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd9267  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd926d  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd9276  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd927f  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd9288  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd9291  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd929a  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd92a3  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd92ac  add rsp, 0xF0
00007e6bc8bd92b3  pop r11
00007e6bc8bd92b5  pop r10
00007e6bc8bd92b7  pop r9
00007e6bc8bd92b9  pop r8
00007e6bc8bd92bb  pop rsi
00007e6bc8bd92bc  pop rdi
00007e6bc8bd92bd  pop rdx
00007e6bc8bd92be  pop rcx
00007e6bc8bd92bf  pop rax
00007e6bc8bd92c0  add rsp, 0x08
00007e6bc8bd92c4  jmp 0x00007E6BC8BD6200
00007e6bc8bd92c9  sub rsp, 0x08
00007e6bc8bd92cd  push rax
00007e6bc8bd92ce  push rcx
00007e6bc8bd92cf  push rdx
00007e6bc8bd92d0  push rdi
00007e6bc8bd92d1  push rsi
00007e6bc8bd92d2  push r8
00007e6bc8bd92d4  push r9
00007e6bc8bd92d6  push r10
00007e6bc8bd92d8  push r11
00007e6bc8bd92da  sub rsp, 0xF0
00007e6bc8bd92e1  vmovaps [rsp], xmm0
00007e6bc8bd92e6  vmovaps [rsp+0x10], xmm1
00007e6bc8bd92ec  vmovaps [rsp+0x20], xmm2
00007e6bc8bd92f2  vmovaps [rsp+0x30], xmm3
00007e6bc8bd92f8  vmovaps [rsp+0x40], xmm4
00007e6bc8bd92fe  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9304  vmovaps [rsp+0x60], xmm7
00007e6bc8bd930a  vmovaps [rsp+0x70], xmm8
00007e6bc8bd9310  vmovaps [rsp+0x80], xmm9
00007e6bc8bd9319  vmovaps [rsp+0x90], xmm10
00007e6bc8bd9322  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd932b  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd9334  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd933d  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9346  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd934f  sub rsp, 0x30
00007e6bc8bd9353  movaps [rsp], xmm6
00007e6bc8bd9357  movaps [rsp+0x10], xmm10
00007e6bc8bd935d  movaps [rsp+0x20], xmm8
00007e6bc8bd9363  lea rdi, [rsp]
00007e6bc8bd9367  mov esi, 0x00
00007e6bc8bd936c  mov rax, 0x6543F191D530
00007e6bc8bd9376  call rax
00007e6bc8bd9378  movaps xmm6, [rsp]
00007e6bc8bd937c  add rsp, 0x30
00007e6bc8bd9380  vmovaps xmm0, [rsp]
00007e6bc8bd9385  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd938b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd9391  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd9397  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd939d  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd93a3  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd93a9  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd93af  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd93b8  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd93c1  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd93ca  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd93d3  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd93dc  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd93e5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd93ee  add rsp, 0xF0
00007e6bc8bd93f5  pop r11
00007e6bc8bd93f7  pop r10
00007e6bc8bd93f9  pop r9
00007e6bc8bd93fb  pop r8
00007e6bc8bd93fd  pop rsi
00007e6bc8bd93fe  pop rdi
00007e6bc8bd93ff  pop rdx
00007e6bc8bd9400  pop rcx
00007e6bc8bd9401  pop rax
00007e6bc8bd9402  add rsp, 0x08
00007e6bc8bd9406  jmp 0x00007E6BC8BD6225
00007e6bc8bd940b  sub rsp, 0x08
00007e6bc8bd940f  push rax
00007e6bc8bd9410  push rcx
00007e6bc8bd9411  push rdx
00007e6bc8bd9412  push rdi
00007e6bc8bd9413  push rsi
00007e6bc8bd9414  push r8
00007e6bc8bd9416  push r9
00007e6bc8bd9418  push r10
00007e6bc8bd941a  push r11
00007e6bc8bd941c  sub rsp, 0xF0
00007e6bc8bd9423  vmovaps [rsp], xmm0
00007e6bc8bd9428  vmovaps [rsp+0x10], xmm1
00007e6bc8bd942e  vmovaps [rsp+0x20], xmm2
00007e6bc8bd9434  vmovaps [rsp+0x30], xmm3
00007e6bc8bd943a  vmovaps [rsp+0x40], xmm4
00007e6bc8bd9440  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9446  vmovaps [rsp+0x60], xmm6
00007e6bc8bd944c  vmovaps [rsp+0x70], xmm7
00007e6bc8bd9452  vmovaps [rsp+0x80], xmm8
00007e6bc8bd945b  vmovaps [rsp+0x90], xmm9
00007e6bc8bd9464  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd946d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd9476  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd947f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9488  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd9491  sub rsp, 0x30
00007e6bc8bd9495  movaps [rsp], xmm10
00007e6bc8bd949a  movaps [rsp+0x10], xmm8
00007e6bc8bd94a0  movaps [rsp+0x20], xmm14
00007e6bc8bd94a6  lea rdi, [rsp]
00007e6bc8bd94aa  mov esi, 0x00
00007e6bc8bd94af  mov rax, 0x6543F191D530
00007e6bc8bd94b9  call rax
00007e6bc8bd94bb  movaps xmm10, [rsp]
00007e6bc8bd94c0  add rsp, 0x30
00007e6bc8bd94c4  vmovaps xmm0, [rsp]
00007e6bc8bd94c9  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd94cf  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd94d5  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd94db  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd94e1  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd94e7  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd94ed  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd94f3  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd94fc  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd9505  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd950e  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd9517  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd9520  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd9529  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd9532  add rsp, 0xF0
00007e6bc8bd9539  pop r11
00007e6bc8bd953b  pop r10
00007e6bc8bd953d  pop r9
00007e6bc8bd953f  pop r8
00007e6bc8bd9541  pop rsi
00007e6bc8bd9542  pop rdi
00007e6bc8bd9543  pop rdx
00007e6bc8bd9544  pop rcx
00007e6bc8bd9545  pop rax
00007e6bc8bd9546  add rsp, 0x08
00007e6bc8bd954a  jmp 0x00007E6BC8BD6245
00007e6bc8bd954f  sub rsp, 0x08
00007e6bc8bd9553  push rax
00007e6bc8bd9554  push rcx
00007e6bc8bd9555  push rdx
00007e6bc8bd9556  push rdi
00007e6bc8bd9557  push rsi
00007e6bc8bd9558  push r8
00007e6bc8bd955a  push r9
00007e6bc8bd955c  push r10
00007e6bc8bd955e  push r11
00007e6bc8bd9560  sub rsp, 0xF0
00007e6bc8bd9567  vmovaps [rsp], xmm0
00007e6bc8bd956c  vmovaps [rsp+0x10], xmm1
00007e6bc8bd9572  vmovaps [rsp+0x20], xmm2
00007e6bc8bd9578  vmovaps [rsp+0x30], xmm3
00007e6bc8bd957e  vmovaps [rsp+0x40], xmm4
00007e6bc8bd9584  vmovaps [rsp+0x50], xmm5
00007e6bc8bd958a  vmovaps [rsp+0x60], xmm6
00007e6bc8bd9590  vmovaps [rsp+0x70], xmm7
00007e6bc8bd9596  vmovaps [rsp+0x80], xmm8
00007e6bc8bd959f  vmovaps [rsp+0x90], xmm9
00007e6bc8bd95a8  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd95b1  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd95ba  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd95c3  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd95cc  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd95d5  sub rsp, 0x30
00007e6bc8bd95d9  movaps [rsp], xmm14
00007e6bc8bd95de  movaps [rsp+0x10], xmm8
00007e6bc8bd95e4  movaps [rsp+0x20], xmm4
00007e6bc8bd95e9  lea rdi, [rsp]
00007e6bc8bd95ed  mov esi, 0x00
00007e6bc8bd95f2  mov rax, 0x6543F191D530
00007e6bc8bd95fc  call rax
00007e6bc8bd95fe  movaps xmm14, [rsp]
00007e6bc8bd9603  add rsp, 0x30
00007e6bc8bd9607  vmovaps xmm0, [rsp]
00007e6bc8bd960c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9612  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd9618  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd961e  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd9624  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd962a  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd9630  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd9636  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd963f  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd9648  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd9651  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd965a  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd9663  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd966c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd9675  add rsp, 0xF0
00007e6bc8bd967c  pop r11
00007e6bc8bd967e  pop r10
00007e6bc8bd9680  pop r9
00007e6bc8bd9682  pop r8
00007e6bc8bd9684  pop rsi
00007e6bc8bd9685  pop rdi
00007e6bc8bd9686  pop rdx
00007e6bc8bd9687  pop rcx
00007e6bc8bd9688  pop rax
00007e6bc8bd9689  add rsp, 0x08
00007e6bc8bd968d  jmp 0x00007E6BC8BD6265
00007e6bc8bd9692  sub rsp, 0x08
00007e6bc8bd9696  push rax
00007e6bc8bd9697  push rcx
00007e6bc8bd9698  push rdx
00007e6bc8bd9699  push rdi
00007e6bc8bd969a  push rsi
00007e6bc8bd969b  push r8
00007e6bc8bd969d  push r9
00007e6bc8bd969f  push r10
00007e6bc8bd96a1  push r11
00007e6bc8bd96a3  sub rsp, 0xF0
00007e6bc8bd96aa  vmovaps [rsp], xmm0
00007e6bc8bd96af  vmovaps [rsp+0x10], xmm1
00007e6bc8bd96b5  vmovaps [rsp+0x20], xmm2
00007e6bc8bd96bb  vmovaps [rsp+0x30], xmm3
00007e6bc8bd96c1  vmovaps [rsp+0x40], xmm5
00007e6bc8bd96c7  vmovaps [rsp+0x50], xmm6
00007e6bc8bd96cd  vmovaps [rsp+0x60], xmm7
00007e6bc8bd96d3  vmovaps [rsp+0x70], xmm8
00007e6bc8bd96d9  vmovaps [rsp+0x80], xmm9
00007e6bc8bd96e2  vmovaps [rsp+0x90], xmm10
00007e6bc8bd96eb  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd96f4  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd96fd  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd9706  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd970f  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd9718  sub rsp, 0x30
00007e6bc8bd971c  movaps [rsp], xmm4
00007e6bc8bd9720  movaps [rsp+0x10], xmm13
00007e6bc8bd9726  movaps [rsp+0x20], xmm8
00007e6bc8bd972c  lea rdi, [rsp]
00007e6bc8bd9730  mov esi, 0x00
00007e6bc8bd9735  mov rax, 0x6543F191D530
00007e6bc8bd973f  call rax
00007e6bc8bd9741  movaps xmm4, [rsp]
00007e6bc8bd9745  add rsp, 0x30
00007e6bc8bd9749  vmovaps xmm0, [rsp]
00007e6bc8bd974e  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9754  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd975a  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd9760  vmovaps xmm5, [rsp+0x40]
00007e6bc8bd9766  vmovaps xmm6, [rsp+0x50]
00007e6bc8bd976c  vmovaps xmm7, [rsp+0x60]
00007e6bc8bd9772  vmovaps xmm8, [rsp+0x70]
00007e6bc8bd9778  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd9781  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd978a  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd9793  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd979c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd97a5  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd97ae  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd97b7  add rsp, 0xF0
00007e6bc8bd97be  pop r11
00007e6bc8bd97c0  pop r10
00007e6bc8bd97c2  pop r9
00007e6bc8bd97c4  pop r8
00007e6bc8bd97c6  pop rsi
00007e6bc8bd97c7  pop rdi
00007e6bc8bd97c8  pop rdx
00007e6bc8bd97c9  pop rcx
00007e6bc8bd97ca  pop rax
00007e6bc8bd97cb  add rsp, 0x08
00007e6bc8bd97cf  jmp 0x00007E6BC8BD628A
00007e6bc8bd97d4  sub rsp, 0x08
00007e6bc8bd97d8  push rax
00007e6bc8bd97d9  push rcx
00007e6bc8bd97da  push rdx
00007e6bc8bd97db  push rdi
00007e6bc8bd97dc  push rsi
00007e6bc8bd97dd  push r8
00007e6bc8bd97df  push r9
00007e6bc8bd97e1  push r10
00007e6bc8bd97e3  push r11
00007e6bc8bd97e5  sub rsp, 0xF0
00007e6bc8bd97ec  vmovaps [rsp], xmm0
00007e6bc8bd97f1  vmovaps [rsp+0x10], xmm1
00007e6bc8bd97f7  vmovaps [rsp+0x20], xmm2
00007e6bc8bd97fd  vmovaps [rsp+0x30], xmm3
00007e6bc8bd9803  vmovaps [rsp+0x40], xmm4
00007e6bc8bd9809  vmovaps [rsp+0x50], xmm5
00007e6bc8bd980f  vmovaps [rsp+0x60], xmm6
00007e6bc8bd9815  vmovaps [rsp+0x70], xmm7
00007e6bc8bd981b  vmovaps [rsp+0x80], xmm8
00007e6bc8bd9824  vmovaps [rsp+0x90], xmm9
00007e6bc8bd982d  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd9836  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd983f  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd9848  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9851  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd985a  sub rsp, 0x30
00007e6bc8bd985e  movaps [rsp], xmm13
00007e6bc8bd9863  movaps [rsp+0x10], xmm15
00007e6bc8bd9869  movaps [rsp+0x20], xmm9
00007e6bc8bd986f  lea rdi, [rsp]
00007e6bc8bd9873  mov esi, 0x00
00007e6bc8bd9878  mov rax, 0x6543F191D530
00007e6bc8bd9882  call rax
00007e6bc8bd9884  movaps xmm13, [rsp]
00007e6bc8bd9889  add rsp, 0x30
00007e6bc8bd988d  vmovaps xmm0, [rsp]
00007e6bc8bd9892  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9898  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd989e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd98a4  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd98aa  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd98b0  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd98b6  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd98bc  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd98c5  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd98ce  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd98d7  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd98e0  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd98e9  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd98f2  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd98fb  add rsp, 0xF0
00007e6bc8bd9902  pop r11
00007e6bc8bd9904  pop r10
00007e6bc8bd9906  pop r9
00007e6bc8bd9908  pop r8
00007e6bc8bd990a  pop rsi
00007e6bc8bd990b  pop rdi
00007e6bc8bd990c  pop rdx
00007e6bc8bd990d  pop rcx
00007e6bc8bd990e  pop rax
00007e6bc8bd990f  add rsp, 0x08
00007e6bc8bd9913  jmp 0x00007E6BC8BD62A5
00007e6bc8bd9918  sub rsp, 0x08
00007e6bc8bd991c  push rax
00007e6bc8bd991d  push rcx
00007e6bc8bd991e  push rdx
00007e6bc8bd991f  push rdi
00007e6bc8bd9920  push rsi
00007e6bc8bd9921  push r8
00007e6bc8bd9923  push r9
00007e6bc8bd9925  push r10
00007e6bc8bd9927  push r11
00007e6bc8bd9929  sub rsp, 0xF0
00007e6bc8bd9930  vmovaps [rsp], xmm0
00007e6bc8bd9935  vmovaps [rsp+0x10], xmm1
00007e6bc8bd993b  vmovaps [rsp+0x20], xmm2
00007e6bc8bd9941  vmovaps [rsp+0x30], xmm3
00007e6bc8bd9947  vmovaps [rsp+0x40], xmm4
00007e6bc8bd994d  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9953  vmovaps [rsp+0x60], xmm6
00007e6bc8bd9959  vmovaps [rsp+0x70], xmm7
00007e6bc8bd995f  vmovaps [rsp+0x80], xmm8
00007e6bc8bd9968  vmovaps [rsp+0x90], xmm9
00007e6bc8bd9971  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd997a  vmovaps [rsp+0xB0], xmm11
00007e6bc8bd9983  vmovaps [rsp+0xC0], xmm12
00007e6bc8bd998c  vmovaps [rsp+0xD0], xmm13
00007e6bc8bd9995  vmovaps [rsp+0xE0], xmm14
00007e6bc8bd999e  sub rsp, 0x30
00007e6bc8bd99a2  movaps [rsp], xmm15
00007e6bc8bd99a7  movaps [rsp+0x10], xmm1
00007e6bc8bd99ac  movaps [rsp+0x20], xmm5
00007e6bc8bd99b1  lea rdi, [rsp]
00007e6bc8bd99b5  mov esi, 0x00
00007e6bc8bd99ba  mov rax, 0x6543F191D530
00007e6bc8bd99c4  call rax
00007e6bc8bd99c6  movaps xmm15, [rsp]
00007e6bc8bd99cb  add rsp, 0x30
00007e6bc8bd99cf  vmovaps xmm0, [rsp]
00007e6bc8bd99d4  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd99da  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd99e0  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd99e6  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd99ec  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd99f2  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd99f8  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd99fe  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd9a07  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd9a10  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd9a19  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bd9a22  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bd9a2b  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bd9a34  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bd9a3d  add rsp, 0xF0
00007e6bc8bd9a44  pop r11
00007e6bc8bd9a46  pop r10
00007e6bc8bd9a48  pop r9
00007e6bc8bd9a4a  pop r8
00007e6bc8bd9a4c  pop rsi
00007e6bc8bd9a4d  pop rdi
00007e6bc8bd9a4e  pop rdx
00007e6bc8bd9a4f  pop rcx
00007e6bc8bd9a50  pop rax
00007e6bc8bd9a51  add rsp, 0x08
00007e6bc8bd9a55  jmp 0x00007E6BC8BD62C0
00007e6bc8bd9a5a  call 0x00007E6BC8AD64F0
00007e6bc8bd9a5f  jmp 0x00007E6BC8BD631B
00007e6bc8bd9a64  sub rsp, 0x08
00007e6bc8bd9a68  push rax
00007e6bc8bd9a69  push rcx
00007e6bc8bd9a6a  push rdx
00007e6bc8bd9a6b  push rdi
00007e6bc8bd9a6c  push rsi
00007e6bc8bd9a6d  push r8
00007e6bc8bd9a6f  push r9
00007e6bc8bd9a71  push r10
00007e6bc8bd9a73  push r11
00007e6bc8bd9a75  sub rsp, 0xF0
00007e6bc8bd9a7c  vmovaps [rsp], xmm0
00007e6bc8bd9a81  vmovaps [rsp+0x10], xmm1
00007e6bc8bd9a87  vmovaps [rsp+0x20], xmm2
00007e6bc8bd9a8d  vmovaps [rsp+0x30], xmm3
00007e6bc8bd9a93  vmovaps [rsp+0x40], xmm4
00007e6bc8bd9a99  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9a9f  vmovaps [rsp+0x60], xmm6
00007e6bc8bd9aa5  vmovaps [rsp+0x70], xmm7
00007e6bc8bd9aab  vmovaps [rsp+0x80], xmm8
00007e6bc8bd9ab4  vmovaps [rsp+0x90], xmm10
00007e6bc8bd9abd  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd9ac6  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd9acf  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd9ad8  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9ae1  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd9aea  sub rsp, 0x30
00007e6bc8bd9aee  movaps [rsp], xmm9
00007e6bc8bd9af3  movaps [rsp+0x10], xmm8
00007e6bc8bd9af9  movaps [rsp+0x20], xmm11
00007e6bc8bd9aff  lea rdi, [rsp]
00007e6bc8bd9b03  mov esi, 0x00
00007e6bc8bd9b08  mov rax, 0x6543F191D530
00007e6bc8bd9b12  call rax
00007e6bc8bd9b14  movaps xmm9, [rsp]
00007e6bc8bd9b19  add rsp, 0x30
00007e6bc8bd9b1d  vmovaps xmm0, [rsp]
00007e6bc8bd9b22  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9b28  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd9b2e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd9b34  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd9b3a  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd9b40  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd9b46  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd9b4c  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd9b55  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd9b5e  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd9b67  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd9b70  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd9b79  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd9b82  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd9b8b  add rsp, 0xF0
00007e6bc8bd9b92  pop r11
00007e6bc8bd9b94  pop r10
00007e6bc8bd9b96  pop r9
00007e6bc8bd9b98  pop r8
00007e6bc8bd9b9a  pop rsi
00007e6bc8bd9b9b  pop rdi
00007e6bc8bd9b9c  pop rdx
00007e6bc8bd9b9d  pop rcx
00007e6bc8bd9b9e  pop rax
00007e6bc8bd9b9f  add rsp, 0x08
00007e6bc8bd9ba3  jmp 0x00007E6BC8BD6352
00007e6bc8bd9ba8  sub rsp, 0x08
00007e6bc8bd9bac  push rax
00007e6bc8bd9bad  push rcx
00007e6bc8bd9bae  push rdx
00007e6bc8bd9baf  push rdi
00007e6bc8bd9bb0  push rsi
00007e6bc8bd9bb1  push r8
00007e6bc8bd9bb3  push r9
00007e6bc8bd9bb5  push r10
00007e6bc8bd9bb7  push r11
00007e6bc8bd9bb9  sub rsp, 0xF0
00007e6bc8bd9bc0  vmovaps [rsp], xmm0
00007e6bc8bd9bc5  vmovaps [rsp+0x10], xmm1
00007e6bc8bd9bcb  vmovaps [rsp+0x20], xmm2
00007e6bc8bd9bd1  vmovaps [rsp+0x30], xmm3
00007e6bc8bd9bd7  vmovaps [rsp+0x40], xmm4
00007e6bc8bd9bdd  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9be3  vmovaps [rsp+0x60], xmm6
00007e6bc8bd9be9  vmovaps [rsp+0x70], xmm7
00007e6bc8bd9bef  vmovaps [rsp+0x80], xmm8
00007e6bc8bd9bf8  vmovaps [rsp+0x90], xmm9
00007e6bc8bd9c01  vmovaps [rsp+0xA0], xmm10
00007e6bc8bd9c0a  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd9c13  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd9c1c  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9c25  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd9c2e  sub rsp, 0x30
00007e6bc8bd9c32  movaps [rsp], xmm11
00007e6bc8bd9c37  movaps [rsp+0x10], xmm10
00007e6bc8bd9c3d  movaps [rsp+0x20], xmm6
00007e6bc8bd9c42  lea rdi, [rsp]
00007e6bc8bd9c46  mov esi, 0x00
00007e6bc8bd9c4b  mov rax, 0x6543F191D530
00007e6bc8bd9c55  call rax
00007e6bc8bd9c57  movaps xmm11, [rsp]
00007e6bc8bd9c5c  add rsp, 0x30
00007e6bc8bd9c60  vmovaps xmm0, [rsp]
00007e6bc8bd9c65  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9c6b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd9c71  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd9c77  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd9c7d  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd9c83  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd9c89  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd9c8f  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd9c98  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd9ca1  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bd9caa  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd9cb3  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd9cbc  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd9cc5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd9cce  add rsp, 0xF0
00007e6bc8bd9cd5  pop r11
00007e6bc8bd9cd7  pop r10
00007e6bc8bd9cd9  pop r9
00007e6bc8bd9cdb  pop r8
00007e6bc8bd9cdd  pop rsi
00007e6bc8bd9cde  pop rdi
00007e6bc8bd9cdf  pop rdx
00007e6bc8bd9ce0  pop rcx
00007e6bc8bd9ce1  pop rax
00007e6bc8bd9ce2  add rsp, 0x08
00007e6bc8bd9ce6  jmp 0x00007E6BC8BD636D
00007e6bc8bd9ceb  sub rsp, 0x08
00007e6bc8bd9cef  push rax
00007e6bc8bd9cf0  push rcx
00007e6bc8bd9cf1  push rdx
00007e6bc8bd9cf2  push rdi
00007e6bc8bd9cf3  push rsi
00007e6bc8bd9cf4  push r8
00007e6bc8bd9cf6  push r9
00007e6bc8bd9cf8  push r10
00007e6bc8bd9cfa  push r11
00007e6bc8bd9cfc  sub rsp, 0xF0
00007e6bc8bd9d03  vmovaps [rsp], xmm0
00007e6bc8bd9d08  vmovaps [rsp+0x10], xmm1
00007e6bc8bd9d0e  vmovaps [rsp+0x20], xmm2
00007e6bc8bd9d14  vmovaps [rsp+0x30], xmm3
00007e6bc8bd9d1a  vmovaps [rsp+0x40], xmm4
00007e6bc8bd9d20  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9d26  vmovaps [rsp+0x60], xmm6
00007e6bc8bd9d2c  vmovaps [rsp+0x70], xmm7
00007e6bc8bd9d32  vmovaps [rsp+0x80], xmm8
00007e6bc8bd9d3b  vmovaps [rsp+0x90], xmm9
00007e6bc8bd9d44  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd9d4d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd9d56  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd9d5f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9d68  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd9d71  sub rsp, 0x30
00007e6bc8bd9d75  movaps [rsp], xmm10
00007e6bc8bd9d7a  movaps [rsp+0x10], xmm14
00007e6bc8bd9d80  movaps [rsp+0x20], xmm4
00007e6bc8bd9d85  lea rdi, [rsp]
00007e6bc8bd9d89  mov esi, 0x00
00007e6bc8bd9d8e  mov rax, 0x6543F191D530
00007e6bc8bd9d98  call rax
00007e6bc8bd9d9a  movaps xmm10, [rsp]
00007e6bc8bd9d9f  add rsp, 0x30
00007e6bc8bd9da3  vmovaps xmm0, [rsp]
00007e6bc8bd9da8  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9dae  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd9db4  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd9dba  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd9dc0  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd9dc6  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd9dcc  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd9dd2  vmovaps xmm8, [rsp+0x80]
00007e6bc8bd9ddb  vmovaps xmm9, [rsp+0x90]
00007e6bc8bd9de4  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd9ded  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd9df6  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd9dff  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd9e08  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd9e11  add rsp, 0xF0
00007e6bc8bd9e18  pop r11
00007e6bc8bd9e1a  pop r10
00007e6bc8bd9e1c  pop r9
00007e6bc8bd9e1e  pop r8
00007e6bc8bd9e20  pop rsi
00007e6bc8bd9e21  pop rdi
00007e6bc8bd9e22  pop rdx
00007e6bc8bd9e23  pop rcx
00007e6bc8bd9e24  pop rax
00007e6bc8bd9e25  add rsp, 0x08
00007e6bc8bd9e29  jmp 0x00007E6BC8BD6388
00007e6bc8bd9e2e  sub rsp, 0x08
00007e6bc8bd9e32  push rax
00007e6bc8bd9e33  push rcx
00007e6bc8bd9e34  push rdx
00007e6bc8bd9e35  push rdi
00007e6bc8bd9e36  push rsi
00007e6bc8bd9e37  push r8
00007e6bc8bd9e39  push r9
00007e6bc8bd9e3b  push r10
00007e6bc8bd9e3d  push r11
00007e6bc8bd9e3f  sub rsp, 0xF0
00007e6bc8bd9e46  vmovaps [rsp], xmm0
00007e6bc8bd9e4b  vmovaps [rsp+0x10], xmm1
00007e6bc8bd9e51  vmovaps [rsp+0x20], xmm2
00007e6bc8bd9e57  vmovaps [rsp+0x30], xmm3
00007e6bc8bd9e5d  vmovaps [rsp+0x40], xmm4
00007e6bc8bd9e63  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9e69  vmovaps [rsp+0x60], xmm6
00007e6bc8bd9e6f  vmovaps [rsp+0x70], xmm7
00007e6bc8bd9e75  vmovaps [rsp+0x80], xmm9
00007e6bc8bd9e7e  vmovaps [rsp+0x90], xmm10
00007e6bc8bd9e87  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd9e90  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd9e99  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd9ea2  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9eab  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd9eb4  sub rsp, 0x30
00007e6bc8bd9eb8  movaps [rsp], xmm8
00007e6bc8bd9ebd  movaps [rsp+0x10], xmm1
00007e6bc8bd9ec2  movaps [rsp+0x20], xmm14
00007e6bc8bd9ec8  lea rdi, [rsp]
00007e6bc8bd9ecc  mov esi, 0x00
00007e6bc8bd9ed1  mov rax, 0x6543F191D530
00007e6bc8bd9edb  call rax
00007e6bc8bd9edd  movaps xmm8, [rsp]
00007e6bc8bd9ee2  add rsp, 0x30
00007e6bc8bd9ee6  vmovaps xmm0, [rsp]
00007e6bc8bd9eeb  vmovaps xmm1, [rsp+0x10]
00007e6bc8bd9ef1  vmovaps xmm2, [rsp+0x20]
00007e6bc8bd9ef7  vmovaps xmm3, [rsp+0x30]
00007e6bc8bd9efd  vmovaps xmm4, [rsp+0x40]
00007e6bc8bd9f03  vmovaps xmm5, [rsp+0x50]
00007e6bc8bd9f09  vmovaps xmm6, [rsp+0x60]
00007e6bc8bd9f0f  vmovaps xmm7, [rsp+0x70]
00007e6bc8bd9f15  vmovaps xmm9, [rsp+0x80]
00007e6bc8bd9f1e  vmovaps xmm10, [rsp+0x90]
00007e6bc8bd9f27  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bd9f30  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bd9f39  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bd9f42  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bd9f4b  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bd9f54  add rsp, 0xF0
00007e6bc8bd9f5b  pop r11
00007e6bc8bd9f5d  pop r10
00007e6bc8bd9f5f  pop r9
00007e6bc8bd9f61  pop r8
00007e6bc8bd9f63  pop rsi
00007e6bc8bd9f64  pop rdi
00007e6bc8bd9f65  pop rdx
00007e6bc8bd9f66  pop rcx
00007e6bc8bd9f67  pop rax
00007e6bc8bd9f68  add rsp, 0x08
00007e6bc8bd9f6c  jmp 0x00007E6BC8BD63AE
00007e6bc8bd9f71  sub rsp, 0x08
00007e6bc8bd9f75  push rax
00007e6bc8bd9f76  push rcx
00007e6bc8bd9f77  push rdx
00007e6bc8bd9f78  push rdi
00007e6bc8bd9f79  push rsi
00007e6bc8bd9f7a  push r8
00007e6bc8bd9f7c  push r9
00007e6bc8bd9f7e  push r10
00007e6bc8bd9f80  push r11
00007e6bc8bd9f82  sub rsp, 0xF0
00007e6bc8bd9f89  vmovaps [rsp], xmm0
00007e6bc8bd9f8e  vmovaps [rsp+0x10], xmm1
00007e6bc8bd9f94  vmovaps [rsp+0x20], xmm2
00007e6bc8bd9f9a  vmovaps [rsp+0x30], xmm3
00007e6bc8bd9fa0  vmovaps [rsp+0x40], xmm4
00007e6bc8bd9fa6  vmovaps [rsp+0x50], xmm5
00007e6bc8bd9fac  vmovaps [rsp+0x60], xmm7
00007e6bc8bd9fb2  vmovaps [rsp+0x70], xmm8
00007e6bc8bd9fb8  vmovaps [rsp+0x80], xmm9
00007e6bc8bd9fc1  vmovaps [rsp+0x90], xmm10
00007e6bc8bd9fca  vmovaps [rsp+0xA0], xmm11
00007e6bc8bd9fd3  vmovaps [rsp+0xB0], xmm12
00007e6bc8bd9fdc  vmovaps [rsp+0xC0], xmm13
00007e6bc8bd9fe5  vmovaps [rsp+0xD0], xmm14
00007e6bc8bd9fee  vmovaps [rsp+0xE0], xmm15
00007e6bc8bd9ff7  sub rsp, 0x30
00007e6bc8bd9ffb  movaps [rsp], xmm6
00007e6bc8bd9fff  movaps [rsp+0x10], xmm1
00007e6bc8bda004  movaps [rsp+0x20], xmm14
00007e6bc8bda00a  lea rdi, [rsp]
00007e6bc8bda00e  mov esi, 0x00
00007e6bc8bda013  mov rax, 0x6543F191D530
00007e6bc8bda01d  call rax
00007e6bc8bda01f  movaps xmm6, [rsp]
00007e6bc8bda023  add rsp, 0x30
00007e6bc8bda027  vmovaps xmm0, [rsp]
00007e6bc8bda02c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bda032  vmovaps xmm2, [rsp+0x20]
00007e6bc8bda038  vmovaps xmm3, [rsp+0x30]
00007e6bc8bda03e  vmovaps xmm4, [rsp+0x40]
00007e6bc8bda044  vmovaps xmm5, [rsp+0x50]
00007e6bc8bda04a  vmovaps xmm7, [rsp+0x60]
00007e6bc8bda050  vmovaps xmm8, [rsp+0x70]
00007e6bc8bda056  vmovaps xmm9, [rsp+0x80]
00007e6bc8bda05f  vmovaps xmm10, [rsp+0x90]
00007e6bc8bda068  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bda071  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bda07a  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bda083  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bda08c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bda095  add rsp, 0xF0
00007e6bc8bda09c  pop r11
00007e6bc8bda09e  pop r10
00007e6bc8bda0a0  pop r9
00007e6bc8bda0a2  pop r8
00007e6bc8bda0a4  pop rsi
00007e6bc8bda0a5  pop rdi
00007e6bc8bda0a6  pop rdx
00007e6bc8bda0a7  pop rcx
00007e6bc8bda0a8  pop rax
00007e6bc8bda0a9  add rsp, 0x08
00007e6bc8bda0ad  jmp 0x00007E6BC8BD63DA
00007e6bc8bda0b2  sub rsp, 0x08
00007e6bc8bda0b6  push rax
00007e6bc8bda0b7  push rcx
00007e6bc8bda0b8  push rdx
00007e6bc8bda0b9  push rdi
00007e6bc8bda0ba  push rsi
00007e6bc8bda0bb  push r8
00007e6bc8bda0bd  push r9
00007e6bc8bda0bf  push r10
00007e6bc8bda0c1  push r11
00007e6bc8bda0c3  sub rsp, 0xF0
00007e6bc8bda0ca  vmovaps [rsp], xmm0
00007e6bc8bda0cf  vmovaps [rsp+0x10], xmm1
00007e6bc8bda0d5  vmovaps [rsp+0x20], xmm2
00007e6bc8bda0db  vmovaps [rsp+0x30], xmm3
00007e6bc8bda0e1  vmovaps [rsp+0x40], xmm4
00007e6bc8bda0e7  vmovaps [rsp+0x50], xmm5
00007e6bc8bda0ed  vmovaps [rsp+0x60], xmm6
00007e6bc8bda0f3  vmovaps [rsp+0x70], xmm7
00007e6bc8bda0f9  vmovaps [rsp+0x80], xmm8
00007e6bc8bda102  vmovaps [rsp+0x90], xmm9
00007e6bc8bda10b  vmovaps [rsp+0xA0], xmm10
00007e6bc8bda114  vmovaps [rsp+0xB0], xmm11
00007e6bc8bda11d  vmovaps [rsp+0xC0], xmm12
00007e6bc8bda126  vmovaps [rsp+0xD0], xmm13
00007e6bc8bda12f  vmovaps [rsp+0xE0], xmm15
00007e6bc8bda138  sub rsp, 0x30
00007e6bc8bda13c  movaps [rsp], xmm14
00007e6bc8bda141  movaps [rsp+0x10], xmm12
00007e6bc8bda147  movaps [rsp+0x20], xmm1
00007e6bc8bda14c  lea rdi, [rsp]
00007e6bc8bda150  mov esi, 0x00
00007e6bc8bda155  mov rax, 0x6543F191D530
00007e6bc8bda15f  call rax
00007e6bc8bda161  movaps xmm14, [rsp]
00007e6bc8bda166  add rsp, 0x30
00007e6bc8bda16a  vmovaps xmm0, [rsp]
00007e6bc8bda16f  vmovaps xmm1, [rsp+0x10]
00007e6bc8bda175  vmovaps xmm2, [rsp+0x20]
00007e6bc8bda17b  vmovaps xmm3, [rsp+0x30]
00007e6bc8bda181  vmovaps xmm4, [rsp+0x40]
00007e6bc8bda187  vmovaps xmm5, [rsp+0x50]
00007e6bc8bda18d  vmovaps xmm6, [rsp+0x60]
00007e6bc8bda193  vmovaps xmm7, [rsp+0x70]
00007e6bc8bda199  vmovaps xmm8, [rsp+0x80]
00007e6bc8bda1a2  vmovaps xmm9, [rsp+0x90]
00007e6bc8bda1ab  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bda1b4  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bda1bd  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bda1c6  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bda1cf  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bda1d8  add rsp, 0xF0
00007e6bc8bda1df  pop r11
00007e6bc8bda1e1  pop r10
00007e6bc8bda1e3  pop r9
00007e6bc8bda1e5  pop r8
00007e6bc8bda1e7  pop rsi
00007e6bc8bda1e8  pop rdi
00007e6bc8bda1e9  pop rdx
00007e6bc8bda1ea  pop rcx
00007e6bc8bda1eb  pop rax
00007e6bc8bda1ec  add rsp, 0x08
00007e6bc8bda1f0  jmp 0x00007E6BC8BD6400
00007e6bc8bda1f5  sub rsp, 0x08
00007e6bc8bda1f9  push rax
00007e6bc8bda1fa  push rcx
00007e6bc8bda1fb  push rdx
00007e6bc8bda1fc  push rdi
00007e6bc8bda1fd  push rsi
00007e6bc8bda1fe  push r8
00007e6bc8bda200  push r9
00007e6bc8bda202  push r10
00007e6bc8bda204  push r11
00007e6bc8bda206  sub rsp, 0xF0
00007e6bc8bda20d  vmovaps [rsp], xmm0
00007e6bc8bda212  vmovaps [rsp+0x10], xmm2
00007e6bc8bda218  vmovaps [rsp+0x20], xmm3
00007e6bc8bda21e  vmovaps [rsp+0x30], xmm4
00007e6bc8bda224  vmovaps [rsp+0x40], xmm5
00007e6bc8bda22a  vmovaps [rsp+0x50], xmm6
00007e6bc8bda230  vmovaps [rsp+0x60], xmm7
00007e6bc8bda236  vmovaps [rsp+0x70], xmm8
00007e6bc8bda23c  vmovaps [rsp+0x80], xmm9
00007e6bc8bda245  vmovaps [rsp+0x90], xmm10
00007e6bc8bda24e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bda257  vmovaps [rsp+0xB0], xmm12
00007e6bc8bda260  vmovaps [rsp+0xC0], xmm13
00007e6bc8bda269  vmovaps [rsp+0xD0], xmm14
00007e6bc8bda272  vmovaps [rsp+0xE0], xmm15
00007e6bc8bda27b  sub rsp, 0x30
00007e6bc8bda27f  movaps [rsp], xmm1
00007e6bc8bda283  movaps [rsp+0x10], xmm13
00007e6bc8bda289  movaps [rsp+0x20], xmm9
00007e6bc8bda28f  lea rdi, [rsp]
00007e6bc8bda293  mov esi, 0x00
00007e6bc8bda298  mov rax, 0x6543F191D530
00007e6bc8bda2a2  call rax
00007e6bc8bda2a4  movaps xmm1, [rsp]
00007e6bc8bda2a8  add rsp, 0x30
00007e6bc8bda2ac  vmovaps xmm0, [rsp]
00007e6bc8bda2b1  vmovaps xmm2, [rsp+0x10]
00007e6bc8bda2b7  vmovaps xmm3, [rsp+0x20]
00007e6bc8bda2bd  vmovaps xmm4, [rsp+0x30]
00007e6bc8bda2c3  vmovaps xmm5, [rsp+0x40]
00007e6bc8bda2c9  vmovaps xmm6, [rsp+0x50]
00007e6bc8bda2cf  vmovaps xmm7, [rsp+0x60]
00007e6bc8bda2d5  vmovaps xmm8, [rsp+0x70]
00007e6bc8bda2db  vmovaps xmm9, [rsp+0x80]
00007e6bc8bda2e4  vmovaps xmm10, [rsp+0x90]
00007e6bc8bda2ed  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bda2f6  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bda2ff  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bda308  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bda311  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bda31a  add rsp, 0xF0
00007e6bc8bda321  pop r11
00007e6bc8bda323  pop r10
00007e6bc8bda325  pop r9
00007e6bc8bda327  pop r8
00007e6bc8bda329  pop rsi
00007e6bc8bda32a  pop rdi
00007e6bc8bda32b  pop rdx
00007e6bc8bda32c  pop rcx
00007e6bc8bda32d  pop rax
00007e6bc8bda32e  add rsp, 0x08
00007e6bc8bda332  jmp 0x00007E6BC8BD641A
00007e6bc8bda337  sub rsp, 0x08
00007e6bc8bda33b  push rax
00007e6bc8bda33c  push rcx
00007e6bc8bda33d  push rdx
00007e6bc8bda33e  push rdi
00007e6bc8bda33f  push rsi
00007e6bc8bda340  push r8
00007e6bc8bda342  push r9
00007e6bc8bda344  push r10
00007e6bc8bda346  push r11
00007e6bc8bda348  sub rsp, 0xF0
00007e6bc8bda34f  vmovaps [rsp], xmm0
00007e6bc8bda354  vmovaps [rsp+0x10], xmm1
00007e6bc8bda35a  vmovaps [rsp+0x20], xmm2
00007e6bc8bda360  vmovaps [rsp+0x30], xmm3
00007e6bc8bda366  vmovaps [rsp+0x40], xmm4
00007e6bc8bda36c  vmovaps [rsp+0x50], xmm5
00007e6bc8bda372  vmovaps [rsp+0x60], xmm6
00007e6bc8bda378  vmovaps [rsp+0x70], xmm7
00007e6bc8bda37e  vmovaps [rsp+0x80], xmm8
00007e6bc8bda387  vmovaps [rsp+0x90], xmm9
00007e6bc8bda390  vmovaps [rsp+0xA0], xmm10
00007e6bc8bda399  vmovaps [rsp+0xB0], xmm11
00007e6bc8bda3a2  vmovaps [rsp+0xC0], xmm13
00007e6bc8bda3ab  vmovaps [rsp+0xD0], xmm14
00007e6bc8bda3b4  vmovaps [rsp+0xE0], xmm15
00007e6bc8bda3bd  sub rsp, 0x30
00007e6bc8bda3c1  movaps [rsp], xmm12
00007e6bc8bda3c6  movaps [rsp+0x10], xmm7
00007e6bc8bda3cb  movaps [rsp+0x20], xmm13
00007e6bc8bda3d1  lea rdi, [rsp]
00007e6bc8bda3d5  mov esi, 0x00
00007e6bc8bda3da  mov rax, 0x6543F191D530
00007e6bc8bda3e4  call rax
00007e6bc8bda3e6  movaps xmm12, [rsp]
00007e6bc8bda3eb  add rsp, 0x30
00007e6bc8bda3ef  vmovaps xmm0, [rsp]
00007e6bc8bda3f4  vmovaps xmm1, [rsp+0x10]
00007e6bc8bda3fa  vmovaps xmm2, [rsp+0x20]
00007e6bc8bda400  vmovaps xmm3, [rsp+0x30]
00007e6bc8bda406  vmovaps xmm4, [rsp+0x40]
00007e6bc8bda40c  vmovaps xmm5, [rsp+0x50]
00007e6bc8bda412  vmovaps xmm6, [rsp+0x60]
00007e6bc8bda418  vmovaps xmm7, [rsp+0x70]
00007e6bc8bda41e  vmovaps xmm8, [rsp+0x80]
00007e6bc8bda427  vmovaps xmm9, [rsp+0x90]
00007e6bc8bda430  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bda439  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bda442  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bda44b  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bda454  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bda45d  add rsp, 0xF0
00007e6bc8bda464  pop r11
00007e6bc8bda466  pop r10
00007e6bc8bda468  pop r9
00007e6bc8bda46a  pop r8
00007e6bc8bda46c  pop rsi
00007e6bc8bda46d  pop rdi
00007e6bc8bda46e  pop rdx
00007e6bc8bda46f  pop rcx
00007e6bc8bda470  pop rax
00007e6bc8bda471  add rsp, 0x08
00007e6bc8bda475  jmp 0x00007E6BC8BD6441
00007e6bc8bda47a  sub rsp, 0x08
00007e6bc8bda47e  push rax
00007e6bc8bda47f  push rcx
00007e6bc8bda480  push rdx
00007e6bc8bda481  push rdi
00007e6bc8bda482  push rsi
00007e6bc8bda483  push r8
00007e6bc8bda485  push r9
00007e6bc8bda487  push r10
00007e6bc8bda489  push r11
00007e6bc8bda48b  sub rsp, 0xF0
00007e6bc8bda492  vmovaps [rsp], xmm0
00007e6bc8bda497  vmovaps [rsp+0x10], xmm1
00007e6bc8bda49d  vmovaps [rsp+0x20], xmm2
00007e6bc8bda4a3  vmovaps [rsp+0x30], xmm3
00007e6bc8bda4a9  vmovaps [rsp+0x40], xmm4
00007e6bc8bda4af  vmovaps [rsp+0x50], xmm5
00007e6bc8bda4b5  vmovaps [rsp+0x60], xmm6
00007e6bc8bda4bb  vmovaps [rsp+0x70], xmm7
00007e6bc8bda4c1  vmovaps [rsp+0x80], xmm8
00007e6bc8bda4ca  vmovaps [rsp+0x90], xmm9
00007e6bc8bda4d3  vmovaps [rsp+0xA0], xmm10
00007e6bc8bda4dc  vmovaps [rsp+0xB0], xmm11
00007e6bc8bda4e5  vmovaps [rsp+0xC0], xmm12
00007e6bc8bda4ee  vmovaps [rsp+0xD0], xmm14
00007e6bc8bda4f7  vmovaps [rsp+0xE0], xmm15
00007e6bc8bda500  sub rsp, 0x30
00007e6bc8bda504  movaps [rsp], xmm13
00007e6bc8bda509  movaps [rsp+0x10], xmm15
00007e6bc8bda50f  movaps [rsp+0x20], xmm8
00007e6bc8bda515  lea rdi, [rsp]
00007e6bc8bda519  mov esi, 0x00
00007e6bc8bda51e  mov rax, 0x6543F191D530
00007e6bc8bda528  call rax
00007e6bc8bda52a  movaps xmm13, [rsp]
00007e6bc8bda52f  add rsp, 0x30
00007e6bc8bda533  vmovaps xmm0, [rsp]
00007e6bc8bda538  vmovaps xmm1, [rsp+0x10]
00007e6bc8bda53e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bda544  vmovaps xmm3, [rsp+0x30]
00007e6bc8bda54a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bda550  vmovaps xmm5, [rsp+0x50]
00007e6bc8bda556  vmovaps xmm6, [rsp+0x60]
00007e6bc8bda55c  vmovaps xmm7, [rsp+0x70]
00007e6bc8bda562  vmovaps xmm8, [rsp+0x80]
00007e6bc8bda56b  vmovaps xmm9, [rsp+0x90]
00007e6bc8bda574  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bda57d  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bda586  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bda58f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bda598  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bda5a1  add rsp, 0xF0
00007e6bc8bda5a8  pop r11
00007e6bc8bda5aa  pop r10
00007e6bc8bda5ac  pop r9
00007e6bc8bda5ae  pop r8
00007e6bc8bda5b0  pop rsi
00007e6bc8bda5b1  pop rdi
00007e6bc8bda5b2  pop rdx
00007e6bc8bda5b3  pop rcx
00007e6bc8bda5b4  pop rax
00007e6bc8bda5b5  add rsp, 0x08
00007e6bc8bda5b9  jmp 0x00007E6BC8BD645C
00007e6bc8bda5be  sub rsp, 0x08
00007e6bc8bda5c2  push rax
00007e6bc8bda5c3  push rcx
00007e6bc8bda5c4  push rdx
00007e6bc8bda5c5  push rdi
00007e6bc8bda5c6  push rsi
00007e6bc8bda5c7  push r8
00007e6bc8bda5c9  push r9
00007e6bc8bda5cb  push r10
00007e6bc8bda5cd  push r11
00007e6bc8bda5cf  sub rsp, 0xF0
00007e6bc8bda5d6  vmovaps [rsp], xmm0
00007e6bc8bda5db  vmovaps [rsp+0x10], xmm1
00007e6bc8bda5e1  vmovaps [rsp+0x20], xmm2
00007e6bc8bda5e7  vmovaps [rsp+0x30], xmm3
00007e6bc8bda5ed  vmovaps [rsp+0x40], xmm4
00007e6bc8bda5f3  vmovaps [rsp+0x50], xmm5
00007e6bc8bda5f9  vmovaps [rsp+0x60], xmm6
00007e6bc8bda5ff  vmovaps [rsp+0x70], xmm7
00007e6bc8bda605  vmovaps [rsp+0x80], xmm9
00007e6bc8bda60e  vmovaps [rsp+0x90], xmm10
00007e6bc8bda617  vmovaps [rsp+0xA0], xmm11
00007e6bc8bda620  vmovaps [rsp+0xB0], xmm12
00007e6bc8bda629  vmovaps [rsp+0xC0], xmm13
00007e6bc8bda632  vmovaps [rsp+0xD0], xmm14
00007e6bc8bda63b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bda644  sub rsp, 0x30
00007e6bc8bda648  movaps [rsp], xmm8
00007e6bc8bda64d  movaps [rsp+0x10], xmm15
00007e6bc8bda653  movaps [rsp+0x20], xmm9
00007e6bc8bda659  lea rdi, [rsp]
00007e6bc8bda65d  mov esi, 0x00
00007e6bc8bda662  mov rax, 0x6543F191D530
00007e6bc8bda66c  call rax
00007e6bc8bda66e  movaps xmm8, [rsp]
00007e6bc8bda673  add rsp, 0x30
00007e6bc8bda677  vmovaps xmm0, [rsp]
00007e6bc8bda67c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bda682  vmovaps xmm2, [rsp+0x20]
00007e6bc8bda688  vmovaps xmm3, [rsp+0x30]
00007e6bc8bda68e  vmovaps xmm4, [rsp+0x40]
00007e6bc8bda694  vmovaps xmm5, [rsp+0x50]
00007e6bc8bda69a  vmovaps xmm6, [rsp+0x60]
00007e6bc8bda6a0  vmovaps xmm7, [rsp+0x70]
00007e6bc8bda6a6  vmovaps xmm9, [rsp+0x80]
00007e6bc8bda6af  vmovaps xmm10, [rsp+0x90]
00007e6bc8bda6b8  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bda6c1  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bda6ca  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bda6d3  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bda6dc  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bda6e5  add rsp, 0xF0
00007e6bc8bda6ec  pop r11
00007e6bc8bda6ee  pop r10
00007e6bc8bda6f0  pop r9
00007e6bc8bda6f2  pop r8
00007e6bc8bda6f4  pop rsi
00007e6bc8bda6f5  pop rdi
00007e6bc8bda6f6  pop rdx
00007e6bc8bda6f7  pop rcx
00007e6bc8bda6f8  pop rax
00007e6bc8bda6f9  add rsp, 0x08
00007e6bc8bda6fd  jmp 0x00007E6BC8BD648A
00007e6bc8bda702  sub rsp, 0x08
00007e6bc8bda706  push rax
00007e6bc8bda707  push rcx
00007e6bc8bda708  push rdx
00007e6bc8bda709  push rdi
00007e6bc8bda70a  push rsi
00007e6bc8bda70b  push r8
00007e6bc8bda70d  push r9
00007e6bc8bda70f  push r10
00007e6bc8bda711  push r11
00007e6bc8bda713  sub rsp, 0xF0
00007e6bc8bda71a  vmovaps [rsp], xmm0
00007e6bc8bda71f  vmovaps [rsp+0x10], xmm1
00007e6bc8bda725  vmovaps [rsp+0x20], xmm2
00007e6bc8bda72b  vmovaps [rsp+0x30], xmm3
00007e6bc8bda731  vmovaps [rsp+0x40], xmm4
00007e6bc8bda737  vmovaps [rsp+0x50], xmm5
00007e6bc8bda73d  vmovaps [rsp+0x60], xmm6
00007e6bc8bda743  vmovaps [rsp+0x70], xmm7
00007e6bc8bda749  vmovaps [rsp+0x80], xmm8
00007e6bc8bda752  vmovaps [rsp+0x90], xmm9
00007e6bc8bda75b  vmovaps [rsp+0xA0], xmm10
00007e6bc8bda764  vmovaps [rsp+0xB0], xmm11
00007e6bc8bda76d  vmovaps [rsp+0xC0], xmm12
00007e6bc8bda776  vmovaps [rsp+0xD0], xmm13
00007e6bc8bda77f  vmovaps [rsp+0xE0], xmm14
00007e6bc8bda788  sub rsp, 0x30
00007e6bc8bda78c  movaps [rsp], xmm15
00007e6bc8bda791  movaps [rsp+0x10], xmm11
00007e6bc8bda797  movaps [rsp+0x20], xmm6
00007e6bc8bda79c  lea rdi, [rsp]
00007e6bc8bda7a0  mov esi, 0x00
00007e6bc8bda7a5  mov rax, 0x6543F191D530
00007e6bc8bda7af  call rax
00007e6bc8bda7b1  movaps xmm15, [rsp]
00007e6bc8bda7b6  add rsp, 0x30
00007e6bc8bda7ba  vmovaps xmm0, [rsp]
00007e6bc8bda7bf  vmovaps xmm1, [rsp+0x10]
00007e6bc8bda7c5  vmovaps xmm2, [rsp+0x20]
00007e6bc8bda7cb  vmovaps xmm3, [rsp+0x30]
00007e6bc8bda7d1  vmovaps xmm4, [rsp+0x40]
00007e6bc8bda7d7  vmovaps xmm5, [rsp+0x50]
00007e6bc8bda7dd  vmovaps xmm6, [rsp+0x60]
00007e6bc8bda7e3  vmovaps xmm7, [rsp+0x70]
00007e6bc8bda7e9  vmovaps xmm8, [rsp+0x80]
00007e6bc8bda7f2  vmovaps xmm9, [rsp+0x90]
00007e6bc8bda7fb  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bda804  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bda80d  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bda816  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bda81f  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bda828  add rsp, 0xF0
00007e6bc8bda82f  pop r11
00007e6bc8bda831  pop r10
00007e6bc8bda833  pop r9
00007e6bc8bda835  pop r8
00007e6bc8bda837  pop rsi
00007e6bc8bda838  pop rdi
00007e6bc8bda839  pop rdx
00007e6bc8bda83a  pop rcx
00007e6bc8bda83b  pop rax
00007e6bc8bda83c  add rsp, 0x08
00007e6bc8bda840  jmp 0x00007E6BC8BD64A5
00007e6bc8bda845  sub rsp, 0x08
00007e6bc8bda849  push rax
00007e6bc8bda84a  push rcx
00007e6bc8bda84b  push rdx
00007e6bc8bda84c  push rdi
00007e6bc8bda84d  push rsi
00007e6bc8bda84e  push r8
00007e6bc8bda850  push r9
00007e6bc8bda852  push r10
00007e6bc8bda854  push r11
00007e6bc8bda856  sub rsp, 0xF0
00007e6bc8bda85d  vmovaps [rsp], xmm0
00007e6bc8bda862  vmovaps [rsp+0x10], xmm1
00007e6bc8bda868  vmovaps [rsp+0x20], xmm2
00007e6bc8bda86e  vmovaps [rsp+0x30], xmm3
00007e6bc8bda874  vmovaps [rsp+0x40], xmm4
00007e6bc8bda87a  vmovaps [rsp+0x50], xmm5
00007e6bc8bda880  vmovaps [rsp+0x60], xmm6
00007e6bc8bda886  vmovaps [rsp+0x70], xmm8
00007e6bc8bda88c  vmovaps [rsp+0x80], xmm9
00007e6bc8bda895  vmovaps [rsp+0x90], xmm10
00007e6bc8bda89e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bda8a7  vmovaps [rsp+0xB0], xmm12
00007e6bc8bda8b0  vmovaps [rsp+0xC0], xmm13
00007e6bc8bda8b9  vmovaps [rsp+0xD0], xmm14
00007e6bc8bda8c2  vmovaps [rsp+0xE0], xmm15
00007e6bc8bda8cb  sub rsp, 0x30
00007e6bc8bda8cf  movaps [rsp], xmm7
00007e6bc8bda8d3  movaps [rsp+0x10], xmm11
00007e6bc8bda8d9  movaps [rsp+0x20], xmm9
00007e6bc8bda8df  lea rdi, [rsp]
00007e6bc8bda8e3  mov esi, 0x00
00007e6bc8bda8e8  mov rax, 0x6543F191D530
00007e6bc8bda8f2  call rax
00007e6bc8bda8f4  movaps xmm7, [rsp]
00007e6bc8bda8f8  add rsp, 0x30
00007e6bc8bda8fc  vmovaps xmm0, [rsp]
00007e6bc8bda901  vmovaps xmm1, [rsp+0x10]
00007e6bc8bda907  vmovaps xmm2, [rsp+0x20]
00007e6bc8bda90d  vmovaps xmm3, [rsp+0x30]
00007e6bc8bda913  vmovaps xmm4, [rsp+0x40]
00007e6bc8bda919  vmovaps xmm5, [rsp+0x50]
00007e6bc8bda91f  vmovaps xmm6, [rsp+0x60]
00007e6bc8bda925  vmovaps xmm8, [rsp+0x70]
00007e6bc8bda92b  vmovaps xmm9, [rsp+0x80]
00007e6bc8bda934  vmovaps xmm10, [rsp+0x90]
00007e6bc8bda93d  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bda946  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bda94f  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bda958  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bda961  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bda96a  add rsp, 0xF0
00007e6bc8bda971  pop r11
00007e6bc8bda973  pop r10
00007e6bc8bda975  pop r9
00007e6bc8bda977  pop r8
00007e6bc8bda979  pop rsi
00007e6bc8bda97a  pop rdi
00007e6bc8bda97b  pop rdx
00007e6bc8bda97c  pop rcx
00007e6bc8bda97d  pop rax
00007e6bc8bda97e  add rsp, 0x08
00007e6bc8bda982  jmp 0x00007E6BC8BD64D2
00007e6bc8bda987  sub rsp, 0x08
00007e6bc8bda98b  push rax
00007e6bc8bda98c  push rcx
00007e6bc8bda98d  push rdx
00007e6bc8bda98e  push rdi
00007e6bc8bda98f  push rsi
00007e6bc8bda990  push r8
00007e6bc8bda992  push r9
00007e6bc8bda994  push r10
00007e6bc8bda996  push r11
00007e6bc8bda998  sub rsp, 0xF0
00007e6bc8bda99f  vmovaps [rsp], xmm0
00007e6bc8bda9a4  vmovaps [rsp+0x10], xmm1
00007e6bc8bda9aa  vmovaps [rsp+0x20], xmm2
00007e6bc8bda9b0  vmovaps [rsp+0x30], xmm3
00007e6bc8bda9b6  vmovaps [rsp+0x40], xmm4
00007e6bc8bda9bc  vmovaps [rsp+0x50], xmm5
00007e6bc8bda9c2  vmovaps [rsp+0x60], xmm6
00007e6bc8bda9c8  vmovaps [rsp+0x70], xmm7
00007e6bc8bda9ce  vmovaps [rsp+0x80], xmm8
00007e6bc8bda9d7  vmovaps [rsp+0x90], xmm9
00007e6bc8bda9e0  vmovaps [rsp+0xA0], xmm10
00007e6bc8bda9e9  vmovaps [rsp+0xB0], xmm12
00007e6bc8bda9f2  vmovaps [rsp+0xC0], xmm13
00007e6bc8bda9fb  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdaa04  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdaa0d  sub rsp, 0x30
00007e6bc8bdaa11  movaps [rsp], xmm11
00007e6bc8bdaa16  movaps [rsp+0x10], xmm10
00007e6bc8bdaa1c  movaps [rsp+0x20], xmm14
00007e6bc8bdaa22  lea rdi, [rsp]
00007e6bc8bdaa26  mov esi, 0x00
00007e6bc8bdaa2b  mov rax, 0x6543F191D530
00007e6bc8bdaa35  call rax
00007e6bc8bdaa37  movaps xmm11, [rsp]
00007e6bc8bdaa3c  add rsp, 0x30
00007e6bc8bdaa40  vmovaps xmm0, [rsp]
00007e6bc8bdaa45  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdaa4b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdaa51  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdaa57  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdaa5d  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdaa63  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdaa69  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdaa6f  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdaa78  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdaa81  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdaa8a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdaa93  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdaa9c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdaaa5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdaaae  add rsp, 0xF0
00007e6bc8bdaab5  pop r11
00007e6bc8bdaab7  pop r10
00007e6bc8bdaab9  pop r9
00007e6bc8bdaabb  pop r8
00007e6bc8bdaabd  pop rsi
00007e6bc8bdaabe  pop rdi
00007e6bc8bdaabf  pop rdx
00007e6bc8bdaac0  pop rcx
00007e6bc8bdaac1  pop rax
00007e6bc8bdaac2  add rsp, 0x08
00007e6bc8bdaac6  jmp 0x00007E6BC8BD64ED
00007e6bc8bdaacb  call 0x00007E6BC8AE45A0
00007e6bc8bdaad0  jmp 0x00007E6BC8BD64F7
00007e6bc8bdaad5  sub rsp, 0x08
00007e6bc8bdaad9  push rax
00007e6bc8bdaada  push rcx
00007e6bc8bdaadb  push rdx
00007e6bc8bdaadc  push rdi
00007e6bc8bdaadd  push rsi
00007e6bc8bdaade  push r8
00007e6bc8bdaae0  push r9
00007e6bc8bdaae2  push r10
00007e6bc8bdaae4  push r11
00007e6bc8bdaae6  sub rsp, 0xF0
00007e6bc8bdaaed  vmovaps [rsp], xmm0
00007e6bc8bdaaf2  vmovaps [rsp+0x10], xmm1
00007e6bc8bdaaf8  vmovaps [rsp+0x20], xmm2
00007e6bc8bdaafe  vmovaps [rsp+0x30], xmm3
00007e6bc8bdab04  vmovaps [rsp+0x40], xmm4
00007e6bc8bdab0a  vmovaps [rsp+0x50], xmm5
00007e6bc8bdab10  vmovaps [rsp+0x60], xmm6
00007e6bc8bdab16  vmovaps [rsp+0x70], xmm7
00007e6bc8bdab1c  vmovaps [rsp+0x80], xmm8
00007e6bc8bdab25  vmovaps [rsp+0x90], xmm9
00007e6bc8bdab2e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdab37  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdab40  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdab49  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdab52  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdab5b  sub rsp, 0x30
00007e6bc8bdab5f  movaps [rsp], xmm10
00007e6bc8bdab64  movaps [rsp+0x10], xmm1
00007e6bc8bdab69  movaps [rsp+0x20], xmm12
00007e6bc8bdab6f  lea rdi, [rsp]
00007e6bc8bdab73  mov esi, 0x00
00007e6bc8bdab78  mov rax, 0x6543F191D530
00007e6bc8bdab82  call rax
00007e6bc8bdab84  movaps xmm10, [rsp]
00007e6bc8bdab89  add rsp, 0x30
00007e6bc8bdab8d  vmovaps xmm0, [rsp]
00007e6bc8bdab92  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdab98  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdab9e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdaba4  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdabaa  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdabb0  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdabb6  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdabbc  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdabc5  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdabce  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdabd7  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdabe0  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdabe9  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdabf2  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdabfb  add rsp, 0xF0
00007e6bc8bdac02  pop r11
00007e6bc8bdac04  pop r10
00007e6bc8bdac06  pop r9
00007e6bc8bdac08  pop r8
00007e6bc8bdac0a  pop rsi
00007e6bc8bdac0b  pop rdi
00007e6bc8bdac0c  pop rdx
00007e6bc8bdac0d  pop rcx
00007e6bc8bdac0e  pop rax
00007e6bc8bdac0f  add rsp, 0x08
00007e6bc8bdac13  jmp 0x00007E6BC8BD651A
00007e6bc8bdac18  sub rsp, 0x08
00007e6bc8bdac1c  push rax
00007e6bc8bdac1d  push rcx
00007e6bc8bdac1e  push rdx
00007e6bc8bdac1f  push rdi
00007e6bc8bdac20  push rsi
00007e6bc8bdac21  push r8
00007e6bc8bdac23  push r9
00007e6bc8bdac25  push r10
00007e6bc8bdac27  push r11
00007e6bc8bdac29  sub rsp, 0xF0
00007e6bc8bdac30  vmovaps [rsp], xmm0
00007e6bc8bdac35  vmovaps [rsp+0x10], xmm1
00007e6bc8bdac3b  vmovaps [rsp+0x20], xmm2
00007e6bc8bdac41  vmovaps [rsp+0x30], xmm3
00007e6bc8bdac47  vmovaps [rsp+0x40], xmm4
00007e6bc8bdac4d  vmovaps [rsp+0x50], xmm5
00007e6bc8bdac53  vmovaps [rsp+0x60], xmm6
00007e6bc8bdac59  vmovaps [rsp+0x70], xmm7
00007e6bc8bdac5f  vmovaps [rsp+0x80], xmm8
00007e6bc8bdac68  vmovaps [rsp+0x90], xmm9
00007e6bc8bdac71  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdac7a  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdac83  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdac8c  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdac95  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdac9e  sub rsp, 0x30
00007e6bc8bdaca2  movaps [rsp], xmm12
00007e6bc8bdaca7  movaps [rsp+0x10], xmm14
00007e6bc8bdacad  movaps [rsp+0x20], xmm1
00007e6bc8bdacb2  lea rdi, [rsp]
00007e6bc8bdacb6  mov esi, 0x00
00007e6bc8bdacbb  mov rax, 0x6543F191D530
00007e6bc8bdacc5  call rax
00007e6bc8bdacc7  movaps xmm12, [rsp]
00007e6bc8bdaccc  add rsp, 0x30
00007e6bc8bdacd0  vmovaps xmm0, [rsp]
00007e6bc8bdacd5  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdacdb  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdace1  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdace7  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdaced  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdacf3  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdacf9  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdacff  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdad08  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdad11  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdad1a  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdad23  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdad2c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdad35  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdad3e  add rsp, 0xF0
00007e6bc8bdad45  pop r11
00007e6bc8bdad47  pop r10
00007e6bc8bdad49  pop r9
00007e6bc8bdad4b  pop r8
00007e6bc8bdad4d  pop rsi
00007e6bc8bdad4e  pop rdi
00007e6bc8bdad4f  pop rdx
00007e6bc8bdad50  pop rcx
00007e6bc8bdad51  pop rax
00007e6bc8bdad52  add rsp, 0x08
00007e6bc8bdad56  jmp 0x00007E6BC8BD6549
00007e6bc8bdad5b  sub rsp, 0x08
00007e6bc8bdad5f  push rax
00007e6bc8bdad60  push rcx
00007e6bc8bdad61  push rdx
00007e6bc8bdad62  push rdi
00007e6bc8bdad63  push rsi
00007e6bc8bdad64  push r8
00007e6bc8bdad66  push r9
00007e6bc8bdad68  push r10
00007e6bc8bdad6a  push r11
00007e6bc8bdad6c  sub rsp, 0xF0
00007e6bc8bdad73  vmovaps [rsp], xmm0
00007e6bc8bdad78  vmovaps [rsp+0x10], xmm1
00007e6bc8bdad7e  vmovaps [rsp+0x20], xmm2
00007e6bc8bdad84  vmovaps [rsp+0x30], xmm3
00007e6bc8bdad8a  vmovaps [rsp+0x40], xmm4
00007e6bc8bdad90  vmovaps [rsp+0x50], xmm5
00007e6bc8bdad96  vmovaps [rsp+0x60], xmm6
00007e6bc8bdad9c  vmovaps [rsp+0x70], xmm7
00007e6bc8bdada2  vmovaps [rsp+0x80], xmm8
00007e6bc8bdadab  vmovaps [rsp+0x90], xmm9
00007e6bc8bdadb4  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdadbd  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdadc6  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdadcf  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdadd8  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdade1  sub rsp, 0x30
00007e6bc8bdade5  movaps [rsp], xmm14
00007e6bc8bdadea  movaps [rsp+0x10], xmm9
00007e6bc8bdadf0  movaps [rsp+0x20], xmm1
00007e6bc8bdadf5  lea rdi, [rsp]
00007e6bc8bdadf9  mov esi, 0x00
00007e6bc8bdadfe  mov rax, 0x6543F191D530
00007e6bc8bdae08  call rax
00007e6bc8bdae0a  movaps xmm14, [rsp]
00007e6bc8bdae0f  add rsp, 0x30
00007e6bc8bdae13  vmovaps xmm0, [rsp]
00007e6bc8bdae18  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdae1e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdae24  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdae2a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdae30  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdae36  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdae3c  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdae42  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdae4b  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdae54  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdae5d  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdae66  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdae6f  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdae78  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdae81  add rsp, 0xF0
00007e6bc8bdae88  pop r11
00007e6bc8bdae8a  pop r10
00007e6bc8bdae8c  pop r9
00007e6bc8bdae8e  pop r8
00007e6bc8bdae90  pop rsi
00007e6bc8bdae91  pop rdi
00007e6bc8bdae92  pop rdx
00007e6bc8bdae93  pop rcx
00007e6bc8bdae94  pop rax
00007e6bc8bdae95  add rsp, 0x08
00007e6bc8bdae99  jmp 0x00007E6BC8BD6578
00007e6bc8bdae9e  sub rsp, 0x08
00007e6bc8bdaea2  push rax
00007e6bc8bdaea3  push rcx
00007e6bc8bdaea4  push rdx
00007e6bc8bdaea5  push rdi
00007e6bc8bdaea6  push rsi
00007e6bc8bdaea7  push r8
00007e6bc8bdaea9  push r9
00007e6bc8bdaeab  push r10
00007e6bc8bdaead  push r11
00007e6bc8bdaeaf  sub rsp, 0xF0
00007e6bc8bdaeb6  vmovaps [rsp], xmm0
00007e6bc8bdaebb  vmovaps [rsp+0x10], xmm2
00007e6bc8bdaec1  vmovaps [rsp+0x20], xmm3
00007e6bc8bdaec7  vmovaps [rsp+0x30], xmm4
00007e6bc8bdaecd  vmovaps [rsp+0x40], xmm5
00007e6bc8bdaed3  vmovaps [rsp+0x50], xmm6
00007e6bc8bdaed9  vmovaps [rsp+0x60], xmm7
00007e6bc8bdaedf  vmovaps [rsp+0x70], xmm8
00007e6bc8bdaee5  vmovaps [rsp+0x80], xmm9
00007e6bc8bdaeee  vmovaps [rsp+0x90], xmm10
00007e6bc8bdaef7  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdaf00  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdaf09  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdaf12  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdaf1b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdaf24  sub rsp, 0x30
00007e6bc8bdaf28  movaps [rsp], xmm1
00007e6bc8bdaf2c  movaps [rsp+0x10], xmm13
00007e6bc8bdaf32  movaps [rsp+0x20], xmm8
00007e6bc8bdaf38  lea rdi, [rsp]
00007e6bc8bdaf3c  mov esi, 0x00
00007e6bc8bdaf41  mov rax, 0x6543F191D530
00007e6bc8bdaf4b  call rax
00007e6bc8bdaf4d  movaps xmm1, [rsp]
00007e6bc8bdaf51  add rsp, 0x30
00007e6bc8bdaf55  vmovaps xmm0, [rsp]
00007e6bc8bdaf5a  vmovaps xmm2, [rsp+0x10]
00007e6bc8bdaf60  vmovaps xmm3, [rsp+0x20]
00007e6bc8bdaf66  vmovaps xmm4, [rsp+0x30]
00007e6bc8bdaf6c  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdaf72  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdaf78  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdaf7e  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdaf84  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdaf8d  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdaf96  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdaf9f  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdafa8  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdafb1  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdafba  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdafc3  add rsp, 0xF0
00007e6bc8bdafca  pop r11
00007e6bc8bdafcc  pop r10
00007e6bc8bdafce  pop r9
00007e6bc8bdafd0  pop r8
00007e6bc8bdafd2  pop rsi
00007e6bc8bdafd3  pop rdi
00007e6bc8bdafd4  pop rdx
00007e6bc8bdafd5  pop rcx
00007e6bc8bdafd6  pop rax
00007e6bc8bdafd7  add rsp, 0x08
00007e6bc8bdafdb  jmp 0x00007E6BC8BD659A
00007e6bc8bdafe0  call 0x00007E6BC8A0C260
00007e6bc8bdafe5  jmp 0x00007E6BC8BD65A8
00007e6bc8bdafea  call 0x00007E6BC8ADE950
00007e6bc8bdafef  jmp 0x00007E6BC8BD65B2
00007e6bc8bdaff4  sub rsp, 0x08
00007e6bc8bdaff8  push rax
00007e6bc8bdaff9  push rcx
00007e6bc8bdaffa  push rdx
00007e6bc8bdaffb  push rdi
00007e6bc8bdaffc  push rsi
00007e6bc8bdaffd  push r8
00007e6bc8bdafff  push r9
00007e6bc8bdb001  push r10
00007e6bc8bdb003  push r11
00007e6bc8bdb005  sub rsp, 0xF0
00007e6bc8bdb00c  vmovaps [rsp], xmm0
00007e6bc8bdb011  vmovaps [rsp+0x10], xmm1
00007e6bc8bdb017  vmovaps [rsp+0x20], xmm2
00007e6bc8bdb01d  vmovaps [rsp+0x30], xmm3
00007e6bc8bdb023  vmovaps [rsp+0x40], xmm4
00007e6bc8bdb029  vmovaps [rsp+0x50], xmm5
00007e6bc8bdb02f  vmovaps [rsp+0x60], xmm6
00007e6bc8bdb035  vmovaps [rsp+0x70], xmm7
00007e6bc8bdb03b  vmovaps [rsp+0x80], xmm9
00007e6bc8bdb044  vmovaps [rsp+0x90], xmm10
00007e6bc8bdb04d  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdb056  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdb05f  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdb068  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdb071  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdb07a  sub rsp, 0x30
00007e6bc8bdb07e  movaps [rsp], xmm8
00007e6bc8bdb083  movaps [rsp+0x10], xmm15
00007e6bc8bdb089  movaps [rsp+0x20], xmm7
00007e6bc8bdb08e  lea rdi, [rsp]
00007e6bc8bdb092  mov esi, 0x00
00007e6bc8bdb097  mov rax, 0x6543F191D530
00007e6bc8bdb0a1  call rax
00007e6bc8bdb0a3  movaps xmm8, [rsp]
00007e6bc8bdb0a8  add rsp, 0x30
00007e6bc8bdb0ac  vmovaps xmm0, [rsp]
00007e6bc8bdb0b1  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdb0b7  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdb0bd  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdb0c3  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdb0c9  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdb0cf  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdb0d5  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdb0db  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdb0e4  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdb0ed  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdb0f6  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdb0ff  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdb108  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdb111  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdb11a  add rsp, 0xF0
00007e6bc8bdb121  pop r11
00007e6bc8bdb123  pop r10
00007e6bc8bdb125  pop r9
00007e6bc8bdb127  pop r8
00007e6bc8bdb129  pop rsi
00007e6bc8bdb12a  pop rdi
00007e6bc8bdb12b  pop rdx
00007e6bc8bdb12c  pop rcx
00007e6bc8bdb12d  pop rax
00007e6bc8bdb12e  add rsp, 0x08
00007e6bc8bdb132  jmp 0x00007E6BC8BD65D4
00007e6bc8bdb137  sub rsp, 0x08
00007e6bc8bdb13b  push rax
00007e6bc8bdb13c  push rcx
00007e6bc8bdb13d  push rdx
00007e6bc8bdb13e  push rdi
00007e6bc8bdb13f  push rsi
00007e6bc8bdb140  push r8
00007e6bc8bdb142  push r9
00007e6bc8bdb144  push r10
00007e6bc8bdb146  push r11
00007e6bc8bdb148  sub rsp, 0xF0
00007e6bc8bdb14f  vmovaps [rsp], xmm0
00007e6bc8bdb154  vmovaps [rsp+0x10], xmm1
00007e6bc8bdb15a  vmovaps [rsp+0x20], xmm2
00007e6bc8bdb160  vmovaps [rsp+0x30], xmm3
00007e6bc8bdb166  vmovaps [rsp+0x40], xmm4
00007e6bc8bdb16c  vmovaps [rsp+0x50], xmm5
00007e6bc8bdb172  vmovaps [rsp+0x60], xmm6
00007e6bc8bdb178  vmovaps [rsp+0x70], xmm8
00007e6bc8bdb17e  vmovaps [rsp+0x80], xmm9
00007e6bc8bdb187  vmovaps [rsp+0x90], xmm10
00007e6bc8bdb190  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdb199  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdb1a2  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdb1ab  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdb1b4  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdb1bd  sub rsp, 0x30
00007e6bc8bdb1c1  movaps [rsp], xmm7
00007e6bc8bdb1c5  movaps [rsp+0x10], xmm9
00007e6bc8bdb1cb  movaps [rsp+0x20], xmm15
00007e6bc8bdb1d1  lea rdi, [rsp]
00007e6bc8bdb1d5  mov esi, 0x00
00007e6bc8bdb1da  mov rax, 0x6543F191D530
00007e6bc8bdb1e4  call rax
00007e6bc8bdb1e6  movaps xmm7, [rsp]
00007e6bc8bdb1ea  add rsp, 0x30
00007e6bc8bdb1ee  vmovaps xmm0, [rsp]
00007e6bc8bdb1f3  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdb1f9  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdb1ff  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdb205  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdb20b  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdb211  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdb217  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdb21d  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdb226  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdb22f  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdb238  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdb241  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdb24a  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdb253  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdb25c  add rsp, 0xF0
00007e6bc8bdb263  pop r11
00007e6bc8bdb265  pop r10
00007e6bc8bdb267  pop r9
00007e6bc8bdb269  pop r8
00007e6bc8bdb26b  pop rsi
00007e6bc8bdb26c  pop rdi
00007e6bc8bdb26d  pop rdx
00007e6bc8bdb26e  pop rcx
00007e6bc8bdb26f  pop rax
00007e6bc8bdb270  add rsp, 0x08
00007e6bc8bdb274  jmp 0x00007E6BC8BD6601
00007e6bc8bdb279  sub rsp, 0x08
00007e6bc8bdb27d  push rax
00007e6bc8bdb27e  push rcx
00007e6bc8bdb27f  push rdx
00007e6bc8bdb280  push rdi
00007e6bc8bdb281  push rsi
00007e6bc8bdb282  push r8
00007e6bc8bdb284  push r9
00007e6bc8bdb286  push r10
00007e6bc8bdb288  push r11
00007e6bc8bdb28a  sub rsp, 0xF0
00007e6bc8bdb291  vmovaps [rsp], xmm0
00007e6bc8bdb296  vmovaps [rsp+0x10], xmm1
00007e6bc8bdb29c  vmovaps [rsp+0x20], xmm2
00007e6bc8bdb2a2  vmovaps [rsp+0x30], xmm3
00007e6bc8bdb2a8  vmovaps [rsp+0x40], xmm4
00007e6bc8bdb2ae  vmovaps [rsp+0x50], xmm5
00007e6bc8bdb2b4  vmovaps [rsp+0x60], xmm6
00007e6bc8bdb2ba  vmovaps [rsp+0x70], xmm7
00007e6bc8bdb2c0  vmovaps [rsp+0x80], xmm8
00007e6bc8bdb2c9  vmovaps [rsp+0x90], xmm10
00007e6bc8bdb2d2  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdb2db  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdb2e4  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdb2ed  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdb2f6  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdb2ff  sub rsp, 0x30
00007e6bc8bdb303  movaps [rsp], xmm9
00007e6bc8bdb308  movaps [rsp+0x10], xmm13
00007e6bc8bdb30e  movaps [rsp+0x20], xmm15
00007e6bc8bdb314  lea rdi, [rsp]
00007e6bc8bdb318  mov esi, 0x00
00007e6bc8bdb31d  mov rax, 0x6543F191D530
00007e6bc8bdb327  call rax
00007e6bc8bdb329  movaps xmm9, [rsp]
00007e6bc8bdb32e  add rsp, 0x30
00007e6bc8bdb332  vmovaps xmm0, [rsp]
00007e6bc8bdb337  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdb33d  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdb343  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdb349  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdb34f  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdb355  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdb35b  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdb361  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdb36a  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdb373  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdb37c  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdb385  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdb38e  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdb397  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdb3a0  add rsp, 0xF0
00007e6bc8bdb3a7  pop r11
00007e6bc8bdb3a9  pop r10
00007e6bc8bdb3ab  pop r9
00007e6bc8bdb3ad  pop r8
00007e6bc8bdb3af  pop rsi
00007e6bc8bdb3b0  pop rdi
00007e6bc8bdb3b1  pop rdx
00007e6bc8bdb3b2  pop rcx
00007e6bc8bdb3b3  pop rax
00007e6bc8bdb3b4  add rsp, 0x08
00007e6bc8bdb3b8  jmp 0x00007E6BC8BD662F
00007e6bc8bdb3bd  sub rsp, 0x08
00007e6bc8bdb3c1  push rax
00007e6bc8bdb3c2  push rcx
00007e6bc8bdb3c3  push rdx
00007e6bc8bdb3c4  push rdi
00007e6bc8bdb3c5  push rsi
00007e6bc8bdb3c6  push r8
00007e6bc8bdb3c8  push r9
00007e6bc8bdb3ca  push r10
00007e6bc8bdb3cc  push r11
00007e6bc8bdb3ce  sub rsp, 0xF0
00007e6bc8bdb3d5  vmovaps [rsp], xmm0
00007e6bc8bdb3da  vmovaps [rsp+0x10], xmm1
00007e6bc8bdb3e0  vmovaps [rsp+0x20], xmm2
00007e6bc8bdb3e6  vmovaps [rsp+0x30], xmm3
00007e6bc8bdb3ec  vmovaps [rsp+0x40], xmm4
00007e6bc8bdb3f2  vmovaps [rsp+0x50], xmm5
00007e6bc8bdb3f8  vmovaps [rsp+0x60], xmm6
00007e6bc8bdb3fe  vmovaps [rsp+0x70], xmm7
00007e6bc8bdb404  vmovaps [rsp+0x80], xmm8
00007e6bc8bdb40d  vmovaps [rsp+0x90], xmm9
00007e6bc8bdb416  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdb41f  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdb428  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdb431  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdb43a  vmovaps [rsp+0xE0], xmm14
00007e6bc8bdb443  sub rsp, 0x30
00007e6bc8bdb447  movaps [rsp], xmm15
00007e6bc8bdb44c  movaps [rsp+0x10], xmm11
00007e6bc8bdb452  movaps [rsp+0x20], xmm12
00007e6bc8bdb458  lea rdi, [rsp]
00007e6bc8bdb45c  mov esi, 0x00
00007e6bc8bdb461  mov rax, 0x6543F191D530
00007e6bc8bdb46b  call rax
00007e6bc8bdb46d  movaps xmm15, [rsp]
00007e6bc8bdb472  add rsp, 0x30
00007e6bc8bdb476  vmovaps xmm0, [rsp]
00007e6bc8bdb47b  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdb481  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdb487  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdb48d  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdb493  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdb499  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdb49f  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdb4a5  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdb4ae  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdb4b7  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdb4c0  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdb4c9  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdb4d2  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdb4db  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bdb4e4  add rsp, 0xF0
00007e6bc8bdb4eb  pop r11
00007e6bc8bdb4ed  pop r10
00007e6bc8bdb4ef  pop r9
00007e6bc8bdb4f1  pop r8
00007e6bc8bdb4f3  pop rsi
00007e6bc8bdb4f4  pop rdi
00007e6bc8bdb4f5  pop rdx
00007e6bc8bdb4f6  pop rcx
00007e6bc8bdb4f7  pop rax
00007e6bc8bdb4f8  add rsp, 0x08
00007e6bc8bdb4fc  jmp 0x00007E6BC8BD664A
00007e6bc8bdb501  sub rsp, 0x08
00007e6bc8bdb505  push rax
00007e6bc8bdb506  push rcx
00007e6bc8bdb507  push rdx
00007e6bc8bdb508  push rdi
00007e6bc8bdb509  push rsi
00007e6bc8bdb50a  push r8
00007e6bc8bdb50c  push r9
00007e6bc8bdb50e  push r10
00007e6bc8bdb510  push r11
00007e6bc8bdb512  sub rsp, 0xF0
00007e6bc8bdb519  vmovaps [rsp], xmm0
00007e6bc8bdb51e  vmovaps [rsp+0x10], xmm1
00007e6bc8bdb524  vmovaps [rsp+0x20], xmm2
00007e6bc8bdb52a  vmovaps [rsp+0x30], xmm3
00007e6bc8bdb530  vmovaps [rsp+0x40], xmm4
00007e6bc8bdb536  vmovaps [rsp+0x50], xmm5
00007e6bc8bdb53c  vmovaps [rsp+0x60], xmm6
00007e6bc8bdb542  vmovaps [rsp+0x70], xmm7
00007e6bc8bdb548  vmovaps [rsp+0x80], xmm8
00007e6bc8bdb551  vmovaps [rsp+0x90], xmm9
00007e6bc8bdb55a  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdb563  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdb56c  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdb575  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdb57e  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdb587  sub rsp, 0x30
00007e6bc8bdb58b  movaps [rsp], xmm13
00007e6bc8bdb590  movaps [rsp+0x10], xmm10
00007e6bc8bdb596  movaps [rsp+0x20], xmm14
00007e6bc8bdb59c  lea rdi, [rsp]
00007e6bc8bdb5a0  mov esi, 0x00
00007e6bc8bdb5a5  mov rax, 0x6543F191D530
00007e6bc8bdb5af  call rax
00007e6bc8bdb5b1  movaps xmm13, [rsp]
00007e6bc8bdb5b6  add rsp, 0x30
00007e6bc8bdb5ba  vmovaps xmm0, [rsp]
00007e6bc8bdb5bf  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdb5c5  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdb5cb  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdb5d1  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdb5d7  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdb5dd  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdb5e3  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdb5e9  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdb5f2  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdb5fb  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdb604  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdb60d  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdb616  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdb61f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdb628  add rsp, 0xF0
00007e6bc8bdb62f  pop r11
00007e6bc8bdb631  pop r10
00007e6bc8bdb633  pop r9
00007e6bc8bdb635  pop r8
00007e6bc8bdb637  pop rsi
00007e6bc8bdb638  pop rdi
00007e6bc8bdb639  pop rdx
00007e6bc8bdb63a  pop rcx
00007e6bc8bdb63b  pop rax
00007e6bc8bdb63c  add rsp, 0x08
00007e6bc8bdb640  jmp 0x00007E6BC8BD666D
00007e6bc8bdb645  sub rsp, 0x08
00007e6bc8bdb649  push rax
00007e6bc8bdb64a  push rcx
00007e6bc8bdb64b  push rdx
00007e6bc8bdb64c  push rdi
00007e6bc8bdb64d  push rsi
00007e6bc8bdb64e  push r8
00007e6bc8bdb650  push r9
00007e6bc8bdb652  push r10
00007e6bc8bdb654  push r11
00007e6bc8bdb656  sub rsp, 0xF0
00007e6bc8bdb65d  vmovaps [rsp], xmm0
00007e6bc8bdb662  vmovaps [rsp+0x10], xmm1
00007e6bc8bdb668  vmovaps [rsp+0x20], xmm2
00007e6bc8bdb66e  vmovaps [rsp+0x30], xmm3
00007e6bc8bdb674  vmovaps [rsp+0x40], xmm4
00007e6bc8bdb67a  vmovaps [rsp+0x50], xmm5
00007e6bc8bdb680  vmovaps [rsp+0x60], xmm6
00007e6bc8bdb686  vmovaps [rsp+0x70], xmm7
00007e6bc8bdb68c  vmovaps [rsp+0x80], xmm8
00007e6bc8bdb695  vmovaps [rsp+0x90], xmm9
00007e6bc8bdb69e  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdb6a7  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdb6b0  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdb6b9  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdb6c2  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdb6cb  sub rsp, 0x30
00007e6bc8bdb6cf  movaps [rsp], xmm14
00007e6bc8bdb6d4  movaps [rsp+0x10], xmm1
00007e6bc8bdb6d9  movaps [rsp+0x20], xmm7
00007e6bc8bdb6de  lea rdi, [rsp]
00007e6bc8bdb6e2  mov esi, 0x00
00007e6bc8bdb6e7  mov rax, 0x6543F191D530
00007e6bc8bdb6f1  call rax
00007e6bc8bdb6f3  movaps xmm14, [rsp]
00007e6bc8bdb6f8  add rsp, 0x30
00007e6bc8bdb6fc  vmovaps xmm0, [rsp]
00007e6bc8bdb701  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdb707  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdb70d  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdb713  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdb719  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdb71f  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdb725  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdb72b  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdb734  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdb73d  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdb746  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdb74f  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdb758  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdb761  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdb76a  add rsp, 0xF0
00007e6bc8bdb771  pop r11
00007e6bc8bdb773  pop r10
00007e6bc8bdb775  pop r9
00007e6bc8bdb777  pop r8
00007e6bc8bdb779  pop rsi
00007e6bc8bdb77a  pop rdi
00007e6bc8bdb77b  pop rdx
00007e6bc8bdb77c  pop rcx
00007e6bc8bdb77d  pop rax
00007e6bc8bdb77e  add rsp, 0x08
00007e6bc8bdb782  jmp 0x00007E6BC8BD6690
00007e6bc8bdb787  sub rsp, 0x08
00007e6bc8bdb78b  push rax
00007e6bc8bdb78c  push rcx
00007e6bc8bdb78d  push rdx
00007e6bc8bdb78e  push rdi
00007e6bc8bdb78f  push rsi
00007e6bc8bdb790  push r8
00007e6bc8bdb792  push r9
00007e6bc8bdb794  push r10
00007e6bc8bdb796  push r11
00007e6bc8bdb798  sub rsp, 0xF0
00007e6bc8bdb79f  vmovaps [rsp], xmm0
00007e6bc8bdb7a4  vmovaps [rsp+0x10], xmm2
00007e6bc8bdb7aa  vmovaps [rsp+0x20], xmm3
00007e6bc8bdb7b0  vmovaps [rsp+0x30], xmm4
00007e6bc8bdb7b6  vmovaps [rsp+0x40], xmm5
00007e6bc8bdb7bc  vmovaps [rsp+0x50], xmm6
00007e6bc8bdb7c2  vmovaps [rsp+0x60], xmm7
00007e6bc8bdb7c8  vmovaps [rsp+0x70], xmm8
00007e6bc8bdb7ce  vmovaps [rsp+0x80], xmm9
00007e6bc8bdb7d7  vmovaps [rsp+0x90], xmm10
00007e6bc8bdb7e0  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdb7e9  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdb7f2  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdb7fb  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdb804  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdb80d  sub rsp, 0x30
00007e6bc8bdb811  movaps [rsp], xmm1
00007e6bc8bdb815  movaps [rsp+0x10], xmm8
00007e6bc8bdb81b  movaps [rsp+0x20], xmm9
00007e6bc8bdb821  lea rdi, [rsp]
00007e6bc8bdb825  mov esi, 0x00
00007e6bc8bdb82a  mov rax, 0x6543F191D530
00007e6bc8bdb834  call rax
00007e6bc8bdb836  movaps xmm1, [rsp]
00007e6bc8bdb83a  add rsp, 0x30
00007e6bc8bdb83e  vmovaps xmm0, [rsp]
00007e6bc8bdb843  vmovaps xmm2, [rsp+0x10]
00007e6bc8bdb849  vmovaps xmm3, [rsp+0x20]
00007e6bc8bdb84f  vmovaps xmm4, [rsp+0x30]
00007e6bc8bdb855  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdb85b  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdb861  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdb867  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdb86d  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdb876  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdb87f  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdb888  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdb891  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdb89a  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdb8a3  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdb8ac  add rsp, 0xF0
00007e6bc8bdb8b3  pop r11
00007e6bc8bdb8b5  pop r10
00007e6bc8bdb8b7  pop r9
00007e6bc8bdb8b9  pop r8
00007e6bc8bdb8bb  pop rsi
00007e6bc8bdb8bc  pop rdi
00007e6bc8bdb8bd  pop rdx
00007e6bc8bdb8be  pop rcx
00007e6bc8bdb8bf  pop rax
00007e6bc8bdb8c0  add rsp, 0x08
00007e6bc8bdb8c4  jmp 0x00007E6BC8BD66B2
00007e6bc8bdb8c9  call 0x00007E6BC8AB3E40
00007e6bc8bdb8ce  jmp 0x00007E6BC8BD66C0
00007e6bc8bdb8d3  call 0x00007E6BC8A0C380
00007e6bc8bdb8d8  jmp 0x00007E6BC8BD66CA
00007e6bc8bdb8dd  call 0x00007E6BC8A0D600
00007e6bc8bdb8e2  jmp 0x00007E6BC8BD66D4
00007e6bc8bdb8e7  call 0x00007E6BC89FF540
00007e6bc8bdb8ec  jmp 0x00007E6BC8BD66DE
00007e6bc8bdb8f1  int3
00007e6bc8bdb8f2  nop [rax+rax*1], ax
00007e6bc8bdb8fb  nop [rax+rax*1], eax
00007e6bc8bdb900  mov eax, [r15+0x48]
00007e6bc8bdb904  lea r14d, [eax+0x01]
00007e6bc8bdb909  mov [rsp+0x10], r14d
00007e6bc8bdb90e  mov r14d, r14d
00007e6bc8bdb911  mov [r15+0x48], r14
00007e6bc8bdb915  xor eax, eax
00007e6bc8bdb917  mov r14d, [rsp+0x10]
00007e6bc8bdb91c  cmp r14d, 0x1F4
00007e6bc8bdb923  cmc
00007e6bc8bdb924  lahf
00007e6bc8bdb925  seto al
00007e6bc8bdb928  mov [r15+0x108], eax
00007e6bc8bdb92f  mov eax, [r15+0x108]
00007e6bc8bdb936  sahf
00007e6bc8bdb937  jnz 0x00007E6BC8BDB969
00007e6bc8bdb939  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bdb941  jz 0x00007E6BC8BE1AB0
00007e6bc8bdb947  nop [rax+rax*1], ax
00007e6bc8bdb950  nop [rax+rax*1], eax
00007e6bc8bdb958  mov eax, 0x410450
00007e6bc8bdb95d  mov [r15+0x100], rax
00007e6bc8bdb964  jmp 0x00007E6BC89FE110
00007e6bc8bdb969  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bdb971  jz 0x00007E6BC8BDB9A0
00007e6bc8bdb977  nop [rax+rax*1], ax
00007e6bc8bdb980  nop [rax+rax*1], eax
00007e6bc8bdb988  mov eax, 0x410274
00007e6bc8bdb98d  mov [r15+0x100], rax
00007e6bc8bdb994  jmp 0x00007E6BC89FE110
00007e6bc8bdb999  int3
00007e6bc8bdb99a  int3
00007e6bc8bdb99b  nop [rax+rax*1], eax
00007e6bc8bdb9a0  mov rax, [r15+0x40]
00007e6bc8bdb9a4  movaps xmm1, [r15+0x1D0]
00007e6bc8bdb9ac  vmovaps [rsp+0x10], xmm1
00007e6bc8bdb9b2  vmovaps xmm15, [rsp+0x10]
00007e6bc8bdb9b8  por xmm1, xmm15
00007e6bc8bdb9bd  movaps xmm14, [r15+0x1A0]
00007e6bc8bdb9c5  vmovaps [rsp+0x10], xmm14
00007e6bc8bdb9cb  vmovaps xmm13, [rsp+0x10]
00007e6bc8bdb9d1  por xmm14, xmm13
00007e6bc8bdb9d6  lea r14, [rax+0x30]
00007e6bc8bdb9da  mov r12, [r13+r14*1]
00007e6bc8bdb9df  lea r14, [rax+0x38]
00007e6bc8bdb9e3  mov r11, [r13+r14*1]
00007e6bc8bdb9e8  movq xmm13, r12
00007e6bc8bdb9ed  movq xmm12, r11
00007e6bc8bdb9f2  movq xmm13, xmm13
00007e6bc8bdb9f7  vmovaps [rsp+0x10], xmm13
00007e6bc8bdb9fd  movq xmm13, xmm13
00007e6bc8bdba02  movaps [r15+0x130], xmm13
00007e6bc8bdba0a  movq xmm12, xmm12
00007e6bc8bdba0f  vmovaps [rsp+0x20], xmm12
00007e6bc8bdba15  movq xmm12, xmm12
00007e6bc8bdba1a  movaps [r15+0x280], xmm12
00007e6bc8bdba22  movaps xmm13, [r15+0x270]
00007e6bc8bdba2a  vmovaps [rsp+0x30], xmm13
00007e6bc8bdba30  vmovaps xmm12, [rsp+0x30]
00007e6bc8bdba36  por xmm13, xmm12
00007e6bc8bdba3b  lea r14, [rax+0x20]
00007e6bc8bdba3f  mov r12, [r13+r14*1]
00007e6bc8bdba44  lea r14, [rax+0x28]
00007e6bc8bdba48  mov r11, [r13+r14*1]
00007e6bc8bdba4d  movq xmm12, r12
00007e6bc8bdba52  movq xmm11, r11
00007e6bc8bdba57  movq xmm12, xmm12
00007e6bc8bdba5c  vmovaps [rsp+0x30], xmm12
00007e6bc8bdba62  movq xmm12, xmm12
00007e6bc8bdba67  movaps [r15+0x150], xmm12
00007e6bc8bdba6f  movq xmm11, xmm11
00007e6bc8bdba74  vmovaps [rsp+0x40], xmm11
00007e6bc8bdba7a  movq xmm11, xmm11
00007e6bc8bdba7f  movaps [r15+0x140], xmm11
00007e6bc8bdba87  lea r14, [rax+0x10]
00007e6bc8bdba8b  mov r12, [r13+r14*1]
00007e6bc8bdba90  lea r14, [rax+0x18]
00007e6bc8bdba94  mov r11, [r13+r14*1]
00007e6bc8bdba99  movq xmm12, r12
00007e6bc8bdba9e  movq xmm11, r11
00007e6bc8bdbaa3  movq xmm12, xmm12
00007e6bc8bdbaa8  vmovaps [rsp+0x50], xmm12
00007e6bc8bdbaae  movq xmm12, xmm12
00007e6bc8bdbab3  movaps [r15+0x170], xmm12
00007e6bc8bdbabb  movq xmm11, xmm11
00007e6bc8bdbac0  vmovaps [rsp+0x60], xmm11
00007e6bc8bdbac6  movq xmm11, xmm11
00007e6bc8bdbacb  movaps [r15+0x160], xmm11
00007e6bc8bdbad3  mov r14, [r13+rax*1]
00007e6bc8bdbad8  vmovq xmm12, r14
00007e6bc8bdbadd  vpbroadcastq xmm12, xmm12
00007e6bc8bdbae2  lea r14, [rax+0x08]
00007e6bc8bdbae6  mov rax, [r13+r14*1]
00007e6bc8bdbaeb  movq xmm11, rax
00007e6bc8bdbaf0  movaps [r15+0x230], xmm11
00007e6bc8bdbaf8  mov rax, [r15+0xF8]
00007e6bc8bdbaff  lea r14, [rax+0x50]
00007e6bc8bdbb03  movups xmm11, [r13+r14*1]
00007e6bc8bdbb09  lea r14, [rax+0x60]
00007e6bc8bdbb0d  movups xmm10, [r13+r14*1]
00007e6bc8bdbb13  lea r14, [rax+0x30]
00007e6bc8bdbb17  movups xmm9, [r13+r14*1]
00007e6bc8bdbb1d  mov r14, [r15+0x50]
00007e6bc8bdbb21  mov [r15+0x60], r14
00007e6bc8bdbb25  mov qword ptr [r15+0x58], 0x40
00007e6bc8bdbb2d  movaps xmm8, xmm12
00007e6bc8bdbb31  mulpd xmm8, xmm15
00007e6bc8bdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007e6bc8bdbb3c  ptest xmm7, xmm7
00007e6bc8bdbb41  jnz 0x00007E6BC8BDC96A
00007e6bc8bdbb47  movq xmm15, qword ptr [r15+0x230]
00007e6bc8bdbb50  vmovaps [rsp+0x70], xmm15
00007e6bc8bdbb56  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bdbb5c  movaps xmm7, xmm9
00007e6bc8bdbb60  mulpd xmm7, xmm15
00007e6bc8bdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007e6bc8bdbb6a  ptest xmm6, xmm6
00007e6bc8bdbb6f  jnz 0x00007E6BC8BDCAAE
00007e6bc8bdbb75  vxorps xmm15, xmm15, xmm15
00007e6bc8bdbb7a  vpbroadcastq xmm15, xmm15
00007e6bc8bdbb7f  movaps xmm9, xmm12
00007e6bc8bdbb83  mulpd xmm9, xmm10
00007e6bc8bdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007e6bc8bdbb8e  ptest xmm6, xmm6
00007e6bc8bdbb93  jnz 0x00007E6BC8BDCBF0
00007e6bc8bdbb99  movaps xmm10, xmm12
00007e6bc8bdbb9d  mulpd xmm10, xmm11
00007e6bc8bdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007e6bc8bdbba8  ptest xmm6, xmm6
00007e6bc8bdbbad  jnz 0x00007E6BC8BDCD34
00007e6bc8bdbbb3  movaps xmm11, [r15+0x1F0]
00007e6bc8bdbbbb  movaps xmm6, xmm12
00007e6bc8bdbbbf  mulpd xmm6, xmm11
00007e6bc8bdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007e6bc8bdbbc9  ptest xmm5, xmm5
00007e6bc8bdbbce  jnz 0x00007E6BC8BDCE78
00007e6bc8bdbbd4  movaps xmm12, [r15+0x2A0]
00007e6bc8bdbbdc  vmovaps [rsp+0x80], xmm12
00007e6bc8bdbbe5  vmovaps xmm11, [rsp+0x80]
00007e6bc8bdbbee  por xmm12, xmm11
00007e6bc8bdbbf3  movaps xmm11, [r15+0x250]
00007e6bc8bdbbfb  vmovaps [rsp+0x80], xmm11
00007e6bc8bdbc04  vmovaps xmm5, [rsp+0x80]
00007e6bc8bdbc0d  por xmm11, xmm5
00007e6bc8bdbc12  vmovaps xmm4, [rsp+0x70]
00007e6bc8bdbc18  vpermilpd xmm4, xmm4, 0x00
00007e6bc8bdbc1e  movaps xmm3, xmm5
00007e6bc8bdbc21  mulpd xmm3, xmm4
00007e6bc8bdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007e6bc8bdbc2a  ptest xmm2, xmm2
00007e6bc8bdbc2f  jnz 0x00007E6BC8BDCFBA
00007e6bc8bdbc35  mov [rsp+0x80], rax
00007e6bc8bdbc3d  xor eax, eax
00007e6bc8bdbc3f  mov r12d, 0x40
00007e6bc8bdbc45  mov r11d, 0x200
00007e6bc8bdbc4b  cmp r12, r11
00007e6bc8bdbc4e  cmc
00007e6bc8bdbc4f  lahf
00007e6bc8bdbc50  seto al
00007e6bc8bdbc53  mov [r15+0x108], eax
00007e6bc8bdbc5a  movaps xmm5, xmm8
00007e6bc8bdbc5e  addpd xmm5, xmm15
00007e6bc8bdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007e6bc8bdbc68  ptest xmm4, xmm4
00007e6bc8bdbc6d  jnz 0x00007E6BC8BDD0FA
00007e6bc8bdbc73  movaps xmm8, [r15+0x1B0]
00007e6bc8bdbc7b  movaps xmm4, xmm9
00007e6bc8bdbc7f  addpd xmm4, xmm8
00007e6bc8bdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007e6bc8bdbc89  ptest xmm2, xmm2
00007e6bc8bdbc8e  jnz 0x00007E6BC8BDD23C
00007e6bc8bdbc94  movaps xmm9, xmm10
00007e6bc8bdbc98  addpd xmm9, xmm8
00007e6bc8bdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007e6bc8bdbca3  ptest xmm2, xmm2
00007e6bc8bdbca8  jnz 0x00007E6BC8BDD37E
00007e6bc8bdbcae  movaps xmm10, [r15+0x2F0]
00007e6bc8bdbcb6  vmovaps [rsp+0x90], xmm10
00007e6bc8bdbcbf  vmovaps xmm8, [rsp+0x90]
00007e6bc8bdbcc8  por xmm10, xmm8
00007e6bc8bdbccd  movaps xmm8, [r15+0x2E0]
00007e6bc8bdbcd5  vmovaps [rsp+0x90], xmm8
00007e6bc8bdbcde  vmovaps xmm2, [rsp+0x90]
00007e6bc8bdbce7  por xmm8, xmm2
00007e6bc8bdbcec  movaps xmm2, [r15+0x2D0]
00007e6bc8bdbcf4  vmovaps [rsp+0x90], xmm2
00007e6bc8bdbcfd  vmovaps [rsp+0xA0], xmm1
00007e6bc8bdbd06  vmovaps xmm1, [rsp+0x90]
00007e6bc8bdbd0f  por xmm2, xmm1
00007e6bc8bdbd13  movaps xmm1, [r15+0x200]
00007e6bc8bdbd1b  vmovaps [rsp+0x90], xmm1
00007e6bc8bdbd24  vmovaps [rsp+0xB0], xmm15
00007e6bc8bdbd2d  vmovaps xmm15, [rsp+0x90]
00007e6bc8bdbd36  por xmm1, xmm15
00007e6bc8bdbd3b  movaps xmm15, [r15+0x1C0]
00007e6bc8bdbd43  vmovaps [rsp+0x90], xmm15
00007e6bc8bdbd4c  vmovaps [rsp+0xC0], xmm1
00007e6bc8bdbd55  vmovaps xmm1, [rsp+0x90]
00007e6bc8bdbd5e  por xmm15, xmm1
00007e6bc8bdbd63  movaps xmm1, [r15+0x190]
00007e6bc8bdbd6b  vmovaps [rsp+0x90], xmm1
00007e6bc8bdbd74  vmovaps [rsp+0xD0], xmm15
00007e6bc8bdbd7d  vmovaps xmm15, [rsp+0x90]
00007e6bc8bdbd86  por xmm1, xmm15
00007e6bc8bdbd8b  movaps xmm15, [r15+0x300]
00007e6bc8bdbd93  vmovaps [rsp+0x90], xmm15
00007e6bc8bdbd9c  vmovaps [rsp+0xE0], xmm1
00007e6bc8bdbda5  vmovaps xmm1, [rsp+0x90]
00007e6bc8bdbdae  por xmm15, xmm1
00007e6bc8bdbdb3  mov rax, [rsp+0x80]
00007e6bc8bdbdbb  lea r12, [rax+0xA0]
00007e6bc8bdbdc2  movups xmm1, [r13+r12*1]
00007e6bc8bdbdc8  lea r12, [rax+0xB0]
00007e6bc8bdbdcf  vmovaps [rsp+0x80], xmm1
00007e6bc8bdbdd8  movups xmm1, [r13+r12*1]
00007e6bc8bdbdde  vmovaps [rsp+0x90], xmm1
00007e6bc8bdbde7  vmovaps [rsp+0xF0], xmm15
00007e6bc8bdbdf0  vmovaps xmm15, [rsp+0xB0]
00007e6bc8bdbdf9  vmovaps [rsp+0xB0], xmm14
00007e6bc8bdbe02  movaps xmm1, xmm6
00007e6bc8bdbe05  addpd xmm1, xmm15
00007e6bc8bdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007e6bc8bdbe0f  ptest xmm14, xmm14
00007e6bc8bdbe15  jnz 0x00007E6BC8BDD4D6
00007e6bc8bdbe1b  lea r12, [rax+0xF0]
00007e6bc8bdbe22  movups xmm15, [r13+r12*1]
00007e6bc8bdbe28  movaps xmm14, xmm4
00007e6bc8bdbe2c  addpd xmm14, xmm3
00007e6bc8bdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007e6bc8bdbe37  ptest xmm6, xmm6
00007e6bc8bdbe3c  jnz 0x00007E6BC8BDD621
00007e6bc8bdbe42  movaps xmm6, xmm9
00007e6bc8bdbe46  addpd xmm6, xmm7
00007e6bc8bdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007e6bc8bdbe4f  ptest xmm4, xmm4
00007e6bc8bdbe54  jnz 0x00007E6BC8BDD763
00007e6bc8bdbe5a  vmovaps xmm9, [rsp+0x70]
00007e6bc8bdbe60  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bdbe66  vmovaps xmm4, [rsp+0x90]
00007e6bc8bdbe6f  movaps xmm7, xmm4
00007e6bc8bdbe72  mulpd xmm7, xmm9
00007e6bc8bdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007e6bc8bdbe7c  ptest xmm3, xmm3
00007e6bc8bdbe81  jnz 0x00007E6BC8BDD8A4
00007e6bc8bdbe87  vmovaps xmm9, [rsp+0x50]
00007e6bc8bdbe8d  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bdbe93  movaps xmm4, xmm15
00007e6bc8bdbe97  mulpd xmm4, xmm9
00007e6bc8bdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007e6bc8bdbea1  ptest xmm3, xmm3
00007e6bc8bdbea6  jnz 0x00007E6BC8BDD9E5
00007e6bc8bdbeac  lea r12, [rax+0xE0]
00007e6bc8bdbeb3  movups xmm15, [r13+r12*1]
00007e6bc8bdbeb9  vmovaps xmm9, [rsp+0x70]
00007e6bc8bdbebf  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bdbec5  vmovaps [rsp+0x70], xmm1
00007e6bc8bdbecb  vmovaps xmm1, [rsp+0x80]
00007e6bc8bdbed4  vmovaps [rsp+0x80], xmm15
00007e6bc8bdbedd  movaps xmm3, xmm1
00007e6bc8bdbee0  mulpd xmm3, xmm9
00007e6bc8bdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007e6bc8bdbeea  ptest xmm15, xmm15
00007e6bc8bdbef0  jnz 0x00007E6BC8BDDB31
00007e6bc8bdbef6  vmovaps xmm1, [rsp+0xF0]
00007e6bc8bdbeff  vmovaps xmm15, [rsp+0xF0]
00007e6bc8bdbf08  por xmm1, xmm15
00007e6bc8bdbf0d  movaps [r15+0x300], xmm1
00007e6bc8bdbf15  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdbf1e  vmovaps xmm9, [rsp+0xE0]
00007e6bc8bdbf27  por xmm15, xmm9
00007e6bc8bdbf2c  movaps [r15+0x190], xmm15
00007e6bc8bdbf34  vmovaps xmm9, [rsp+0x50]
00007e6bc8bdbf3a  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bdbf40  vmovaps [rsp+0x90], xmm1
00007e6bc8bdbf49  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdbf52  vmovaps xmm15, [rsp+0x80]
00007e6bc8bdbf5b  vmovaps [rsp+0x80], xmm14
00007e6bc8bdbf64  movaps xmm1, xmm15
00007e6bc8bdbf68  mulpd xmm1, xmm9
00007e6bc8bdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007e6bc8bdbf72  ptest xmm14, xmm14
00007e6bc8bdbf78  jnz 0x00007E6BC8BDDC72
00007e6bc8bdbf7e  lea r12, [rax+0x90]
00007e6bc8bdbf85  movups xmm15, [r13+r12*1]
00007e6bc8bdbf8b  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdbf94  vmovaps xmm9, [rsp+0xD0]
00007e6bc8bdbf9d  por xmm14, xmm9
00007e6bc8bdbfa2  movaps [r15+0x1C0], xmm14
00007e6bc8bdbfaa  vmovaps xmm9, [rsp+0xC0]
00007e6bc8bdbfb3  vmovaps [rsp+0xD0], xmm1
00007e6bc8bdbfbc  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bdbfc5  por xmm9, xmm1
00007e6bc8bdbfca  movaps [r15+0x200], xmm9
00007e6bc8bdbfd2  vmovaps [rsp+0xC0], xmm2
00007e6bc8bdbfdb  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bdbfe4  por xmm2, xmm1
00007e6bc8bdbfe8  movaps [r15+0x2D0], xmm2
00007e6bc8bdbff0  vmovaps [rsp+0xC0], xmm8
00007e6bc8bdbff9  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bdc002  por xmm8, xmm1
00007e6bc8bdc007  movaps [r15+0x2E0], xmm8
00007e6bc8bdc00f  vmovaps [rsp+0xC0], xmm15
00007e6bc8bdc018  movaps xmm1, xmm5
00007e6bc8bdc01b  addpd xmm1, xmm7
00007e6bc8bdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007e6bc8bdc024  ptest xmm15, xmm15
00007e6bc8bdc02a  jnz 0x00007E6BC8BDDDBE
00007e6bc8bdc030  vmovaps xmm15, [rsp+0x50]
00007e6bc8bdc036  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bdc03c  vmovaps xmm5, [rsp+0xC0]
00007e6bc8bdc045  vmovaps [rsp+0xC0], xmm1
00007e6bc8bdc04e  movaps xmm7, xmm5
00007e6bc8bdc051  mulpd xmm7, xmm15
00007e6bc8bdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007e6bc8bdc05b  ptest xmm1, xmm1
00007e6bc8bdc060  jnz 0x00007E6BC8BDDEFE
00007e6bc8bdc066  lea r12, [rax+0x80]
00007e6bc8bdc06d  movups xmm1, [r13+r12*1]
00007e6bc8bdc073  vmovaps xmm5, [rsp+0x70]
00007e6bc8bdc079  vmovaps [rsp+0x70], xmm1
00007e6bc8bdc07f  movaps xmm15, xmm5
00007e6bc8bdc083  addpd xmm15, xmm3
00007e6bc8bdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007e6bc8bdc08e  ptest xmm1, xmm1
00007e6bc8bdc093  jnz 0x00007E6BC8BDE049
00007e6bc8bdc099  vmovaps xmm5, [rsp+0x80]
00007e6bc8bdc0a2  movaps xmm1, xmm5
00007e6bc8bdc0a5  addpd xmm1, xmm4
00007e6bc8bdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007e6bc8bdc0ae  ptest xmm3, xmm3
00007e6bc8bdc0b3  jnz 0x00007E6BC8BDE18B
00007e6bc8bdc0b9  vmovaps [rsp+0x80], xmm10
00007e6bc8bdc0c2  vmovaps xmm5, [rsp+0x80]
00007e6bc8bdc0cb  por xmm10, xmm5
00007e6bc8bdc0d0  movaps [r15+0x2F0], xmm10
00007e6bc8bdc0d8  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdc0de  vpermilpd xmm5, xmm5, 0x00
00007e6bc8bdc0e4  vmovaps xmm3, [rsp+0x70]
00007e6bc8bdc0ea  vmovaps [rsp+0x50], xmm1
00007e6bc8bdc0f0  movaps xmm4, xmm3
00007e6bc8bdc0f3  mulpd xmm4, xmm5
00007e6bc8bdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007e6bc8bdc0fc  ptest xmm1, xmm1
00007e6bc8bdc101  jnz 0x00007E6BC8BDE2CB
00007e6bc8bdc107  lea r12, [rax+0xD0]
00007e6bc8bdc10e  movups xmm1, [r13+r12*1]
00007e6bc8bdc114  vmovaps xmm3, [rsp+0xD0]
00007e6bc8bdc11d  vmovaps [rsp+0x70], xmm1
00007e6bc8bdc123  movaps xmm5, xmm6
00007e6bc8bdc126  addpd xmm5, xmm3
00007e6bc8bdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007e6bc8bdc12f  ptest xmm1, xmm1
00007e6bc8bdc134  jnz 0x00007E6BC8BDE415
00007e6bc8bdc13a  vmovaps xmm1, [rsp+0x60]
00007e6bc8bdc140  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bdc146  movaps xmm6, xmm9
00007e6bc8bdc14a  mulpd xmm6, xmm1
00007e6bc8bdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007e6bc8bdc153  ptest xmm3, xmm3
00007e6bc8bdc158  jnz 0x00007E6BC8BDE555
00007e6bc8bdc15e  movaps [r15+0x260], xmm6
00007e6bc8bdc166  vxorps xmm1, xmm1, xmm1
00007e6bc8bdc16a  vpbroadcastq xmm1, xmm1
00007e6bc8bdc16f  movaps [r15+0x1B0], xmm1
00007e6bc8bdc177  vmovaps xmm1, [rsp+0x60]
00007e6bc8bdc17d  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bdc183  vmovaps xmm3, [rsp+0x70]
00007e6bc8bdc189  vmovaps [rsp+0x70], xmm15
00007e6bc8bdc18f  movaps xmm9, xmm3
00007e6bc8bdc193  mulpd xmm9, xmm1
00007e6bc8bdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007e6bc8bdc19e  ptest xmm15, xmm15
00007e6bc8bdc1a4  jnz 0x00007E6BC8BDE696
00007e6bc8bdc1aa  lea r12, [rax+0xC0]
00007e6bc8bdc1b1  movups xmm1, [r13+r12*1]
00007e6bc8bdc1b7  vmovaps xmm3, [rsp+0xC0]
00007e6bc8bdc1c0  vmovaps [rsp+0x80], xmm1
00007e6bc8bdc1c9  movaps xmm15, xmm3
00007e6bc8bdc1cd  addpd xmm15, xmm7
00007e6bc8bdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007e6bc8bdc1d8  ptest xmm1, xmm1
00007e6bc8bdc1dd  jnz 0x00007E6BC8BDE7E2
00007e6bc8bdc1e3  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdc1ec  vmovaps xmm1, [rsp+0xC0]
00007e6bc8bdc1f5  por xmm13, xmm1
00007e6bc8bdc1fa  movaps [r15+0x270], xmm13
00007e6bc8bdc202  vmovaps xmm1, [rsp+0xB0]
00007e6bc8bdc20b  vmovaps xmm7, [rsp+0xB0]
00007e6bc8bdc214  por xmm1, xmm7
00007e6bc8bdc218  movaps [r15+0x1A0], xmm1
00007e6bc8bdc220  vmovaps xmm1, [rsp+0x60]
00007e6bc8bdc226  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bdc22c  vmovaps [rsp+0xB0], xmm1
00007e6bc8bdc235  vmovaps xmm1, [rsp+0x80]
00007e6bc8bdc23e  vmovaps [rsp+0x80], xmm15
00007e6bc8bdc247  vmovaps xmm15, [rsp+0xB0]
00007e6bc8bdc250  vmovaps [rsp+0xB0], xmm14
00007e6bc8bdc259  movaps xmm3, xmm1
00007e6bc8bdc25c  mulpd xmm3, xmm15
00007e6bc8bdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007e6bc8bdc266  ptest xmm14, xmm14
00007e6bc8bdc26c  jnz 0x00007E6BC8BDE924
00007e6bc8bdc272  lea r12, [rax+0x20]
00007e6bc8bdc276  movups xmm1, [r13+r12*1]
00007e6bc8bdc27c  movaps [r15+0x110], xmm1
00007e6bc8bdc284  vmovaps xmm14, [rsp+0x70]
00007e6bc8bdc28a  vmovaps [rsp+0x70], xmm1
00007e6bc8bdc290  movaps xmm15, xmm14
00007e6bc8bdc294  addpd xmm15, xmm4
00007e6bc8bdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007e6bc8bdc29f  ptest xmm1, xmm1
00007e6bc8bdc2a4  jnz 0x00007E6BC8BDEA6F
00007e6bc8bdc2aa  vmovaps xmm1, [rsp+0x60]
00007e6bc8bdc2b0  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bdc2b6  movaps xmm14, xmm2
00007e6bc8bdc2ba  mulpd xmm14, xmm1
00007e6bc8bdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007e6bc8bdc2c5  ptest xmm4, xmm4
00007e6bc8bdc2ca  jnz 0x00007E6BC8BDEBB2
00007e6bc8bdc2d0  vmovaps xmm4, [rsp+0x50]
00007e6bc8bdc2d6  movaps xmm1, xmm4
00007e6bc8bdc2d9  addpd xmm1, xmm9
00007e6bc8bdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007e6bc8bdc2e3  ptest xmm2, xmm2
00007e6bc8bdc2e8  jnz 0x00007E6BC8BDECF4
00007e6bc8bdc2ee  vmovaps xmm9, [rsp+0x30]
00007e6bc8bdc2f4  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bdc2fa  vmovaps xmm2, [rsp+0x70]
00007e6bc8bdc300  vmovaps [rsp+0x50], xmm1
00007e6bc8bdc306  movaps xmm4, xmm2
00007e6bc8bdc309  mulpd xmm4, xmm9
00007e6bc8bdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007e6bc8bdc313  ptest xmm1, xmm1
00007e6bc8bdc318  jnz 0x00007E6BC8BDEE35
00007e6bc8bdc31e  vmovaps xmm1, [rsp+0x30]
00007e6bc8bdc324  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bdc32a  vmovaps xmm2, [rsp+0x90]
00007e6bc8bdc333  vmovaps [rsp+0x60], xmm15
00007e6bc8bdc339  movaps xmm9, xmm2
00007e6bc8bdc33d  mulpd xmm9, xmm1
00007e6bc8bdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007e6bc8bdc348  ptest xmm15, xmm15
00007e6bc8bdc34e  jnz 0x00007E6BC8BDEF76
00007e6bc8bdc354  vmovaps xmm15, [rsp+0x80]
00007e6bc8bdc35d  movaps xmm1, xmm15
00007e6bc8bdc361  addpd xmm1, xmm6
00007e6bc8bdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007e6bc8bdc36a  ptest xmm2, xmm2
00007e6bc8bdc36f  jnz 0x00007E6BC8BDF0B8
00007e6bc8bdc375  movaps xmm15, xmm5
00007e6bc8bdc379  addpd xmm15, xmm3
00007e6bc8bdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007e6bc8bdc384  ptest xmm6, xmm6
00007e6bc8bdc389  jnz 0x00007E6BC8BDF1F9
00007e6bc8bdc38f  vmovaps xmm6, [rsp+0x30]
00007e6bc8bdc395  vpermilpd xmm6, xmm6, 0x00
00007e6bc8bdc39b  movaps xmm5, xmm8
00007e6bc8bdc39f  mulpd xmm5, xmm6
00007e6bc8bdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007e6bc8bdc3a8  ptest xmm3, xmm3
00007e6bc8bdc3ad  jnz 0x00007E6BC8BDF33B
00007e6bc8bdc3b3  vmovaps xmm8, [rsp+0x30]
00007e6bc8bdc3b9  vpermilpd xmm8, xmm8, 0x00
00007e6bc8bdc3bf  movaps xmm6, xmm10
00007e6bc8bdc3c3  mulpd xmm6, xmm8
00007e6bc8bdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007e6bc8bdc3cd  ptest xmm3, xmm3
00007e6bc8bdc3d2  jnz 0x00007E6BC8BDF47C
00007e6bc8bdc3d8  vmovaps xmm8, [rsp+0x60]
00007e6bc8bdc3de  movaps xmm10, xmm8
00007e6bc8bdc3e2  addpd xmm10, xmm14
00007e6bc8bdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007e6bc8bdc3ed  ptest xmm3, xmm3
00007e6bc8bdc3f2  jnz 0x00007E6BC8BDF5BE
00007e6bc8bdc3f8  vmovaps xmm8, [rsp+0x50]
00007e6bc8bdc3fe  movaps xmm14, xmm8
00007e6bc8bdc402  addpd xmm14, xmm4
00007e6bc8bdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007e6bc8bdc40d  ptest xmm3, xmm3
00007e6bc8bdc412  jnz 0x00007E6BC8BDF702
00007e6bc8bdc418  vmovaps xmm8, [rsp+0x40]
00007e6bc8bdc41e  vpermilpd xmm8, xmm8, 0x00
00007e6bc8bdc424  movaps xmm4, xmm13
00007e6bc8bdc428  mulpd xmm4, xmm8
00007e6bc8bdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007e6bc8bdc432  ptest xmm3, xmm3
00007e6bc8bdc437  jnz 0x00007E6BC8BDF845
00007e6bc8bdc43d  movaps xmm13, xmm15
00007e6bc8bdc441  addpd xmm13, xmm9
00007e6bc8bdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007e6bc8bdc44c  ptest xmm8, xmm8
00007e6bc8bdc452  jnz 0x00007E6BC8BDF987
00007e6bc8bdc458  movaps xmm15, xmm1
00007e6bc8bdc45c  addpd xmm15, xmm5
00007e6bc8bdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007e6bc8bdc467  ptest xmm9, xmm9
00007e6bc8bdc46d  jnz 0x00007E6BC8BDFACB
00007e6bc8bdc473  vmovaps [rsp+0x30], xmm11
00007e6bc8bdc479  vmovaps xmm1, [rsp+0x30]
00007e6bc8bdc47f  por xmm11, xmm1
00007e6bc8bdc484  movaps [r15+0x250], xmm11
00007e6bc8bdc48c  vmovaps [rsp+0x30], xmm12
00007e6bc8bdc492  vmovaps xmm1, [rsp+0x30]
00007e6bc8bdc498  por xmm12, xmm1
00007e6bc8bdc49d  movaps [r15+0x2A0], xmm12
00007e6bc8bdc4a5  vmovaps xmm1, [rsp+0xA0]
00007e6bc8bdc4ae  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdc4b7  por xmm1, xmm11
00007e6bc8bdc4bc  movaps [r15+0x1D0], xmm1
00007e6bc8bdc4c4  lea r12, [rax+0x40]
00007e6bc8bdc4c8  movups xmm1, [r13+r12*1]
00007e6bc8bdc4ce  movaps [r15+0x2C0], xmm1
00007e6bc8bdc4d6  vmovaps xmm11, [rsp+0x40]
00007e6bc8bdc4dc  vpermilpd xmm11, xmm11, 0x00
00007e6bc8bdc4e2  vmovaps xmm8, [rsp+0xE0]
00007e6bc8bdc4eb  movaps xmm9, xmm8
00007e6bc8bdc4ef  mulpd xmm9, xmm11
00007e6bc8bdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007e6bc8bdc4fa  ptest xmm5, xmm5
00007e6bc8bdc4ff  jnz 0x00007E6BC8BDFC17
00007e6bc8bdc505  movaps xmm11, xmm10
00007e6bc8bdc509  addpd xmm11, xmm6
00007e6bc8bdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007e6bc8bdc514  ptest xmm8, xmm8
00007e6bc8bdc51a  jnz 0x00007E6BC8BDFD5B
00007e6bc8bdc520  movaps xmm10, xmm14
00007e6bc8bdc524  addpd xmm10, xmm4
00007e6bc8bdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007e6bc8bdc52f  ptest xmm8, xmm8
00007e6bc8bdc535  jnz 0x00007E6BC8BDFE9E
00007e6bc8bdc53b  vmovaps xmm14, [rsp+0x40]
00007e6bc8bdc541  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bdc547  movaps xmm8, xmm1
00007e6bc8bdc54b  mulpd xmm8, xmm14
00007e6bc8bdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007e6bc8bdc556  ptest xmm6, xmm6
00007e6bc8bdc55b  jnz 0x00007E6BC8BDFFE1
00007e6bc8bdc561  movaps xmm1, [r15+0x2B0]
00007e6bc8bdc569  vmovaps xmm14, [rsp+0x40]
00007e6bc8bdc56f  vpermilpd xmm14, xmm14, 0x00
00007e6bc8bdc575  movaps xmm6, xmm1
00007e6bc8bdc578  mulpd xmm6, xmm14
00007e6bc8bdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007e6bc8bdc582  ptest xmm5, xmm5
00007e6bc8bdc587  jnz 0x00007E6BC8BE0124
00007e6bc8bdc58d  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdc593  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bdc599  movaps xmm14, xmm12
00007e6bc8bdc59d  mulpd xmm14, xmm1
00007e6bc8bdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007e6bc8bdc5a8  ptest xmm5, xmm5
00007e6bc8bdc5ad  jnz 0x00007E6BC8BE0265
00007e6bc8bdc5b3  movaps xmm1, xmm13
00007e6bc8bdc5b7  addpd xmm1, xmm9
00007e6bc8bdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007e6bc8bdc5c1  ptest xmm12, xmm12
00007e6bc8bdc5c7  jnz 0x00007E6BC8BE03A8
00007e6bc8bdc5cd  vmovaps xmm13, [rsp+0x10]
00007e6bc8bdc5d3  vpermilpd xmm13, xmm13, 0x00
00007e6bc8bdc5d9  movaps xmm12, xmm7
00007e6bc8bdc5dd  mulpd xmm12, xmm13
00007e6bc8bdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007e6bc8bdc5e8  ptest xmm9, xmm9
00007e6bc8bdc5ee  jnz 0x00007E6BC8BE04EA
00007e6bc8bdc5f4  movaps xmm13, xmm15
00007e6bc8bdc5f8  addpd xmm13, xmm8
00007e6bc8bdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007e6bc8bdc603  ptest xmm9, xmm9
00007e6bc8bdc609  jnz 0x00007E6BC8BE062D
00007e6bc8bdc60f  movaps xmm15, [r15+0x290]
00007e6bc8bdc617  vmovaps xmm9, [rsp+0x10]
00007e6bc8bdc61d  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bdc623  movaps xmm8, xmm15
00007e6bc8bdc627  mulpd xmm8, xmm9
00007e6bc8bdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007e6bc8bdc632  ptest xmm7, xmm7
00007e6bc8bdc637  jnz 0x00007E6BC8BE0771
00007e6bc8bdc63d  movaps xmm15, xmm11
00007e6bc8bdc641  addpd xmm15, xmm6
00007e6bc8bdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007e6bc8bdc64c  ptest xmm9, xmm9
00007e6bc8bdc652  jnz 0x00007E6BC8BE08B5
00007e6bc8bdc658  movaps xmm11, [r15+0x1E0]
00007e6bc8bdc660  vmovaps xmm9, [rsp+0x10]
00007e6bc8bdc666  vpermilpd xmm9, xmm9, 0x00
00007e6bc8bdc66c  movaps xmm7, xmm11
00007e6bc8bdc670  mulpd xmm7, xmm9
00007e6bc8bdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007e6bc8bdc67a  ptest xmm6, xmm6
00007e6bc8bdc67f  jnz 0x00007E6BC8BE09F8
00007e6bc8bdc685  movaps xmm11, xmm10
00007e6bc8bdc689  addpd xmm11, xmm14
00007e6bc8bdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007e6bc8bdc694  ptest xmm9, xmm9
00007e6bc8bdc69a  jnz 0x00007E6BC8BE0B3A
00007e6bc8bdc6a0  lea r12, [rax+0x70]
00007e6bc8bdc6a4  movups xmm14, [r13+r12*1]
00007e6bc8bdc6aa  movaps [r15+0x240], xmm14
00007e6bc8bdc6b2  movaps xmm10, xmm1
00007e6bc8bdc6b6  addpd xmm10, xmm12
00007e6bc8bdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007e6bc8bdc6c1  ptest xmm9, xmm9
00007e6bc8bdc6c7  jnz 0x00007E6BC8BE0C88
00007e6bc8bdc6cd  movaps [r15+0x170], xmm10
00007e6bc8bdc6d5  vmovaps xmm1, [rsp+0x20]
00007e6bc8bdc6db  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bdc6e1  movaps xmm12, xmm14
00007e6bc8bdc6e5  mulpd xmm12, xmm1
00007e6bc8bdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007e6bc8bdc6f0  ptest xmm9, xmm9
00007e6bc8bdc6f6  jnz 0x00007E6BC8BE0DCB
00007e6bc8bdc6fc  vmovaps xmm1, [rsp+0x20]
00007e6bc8bdc702  vpermilpd xmm1, xmm1, 0x00
00007e6bc8bdc708  vmovaps xmm9, [rsp+0xB0]
00007e6bc8bdc711  movaps xmm14, xmm9
00007e6bc8bdc715  mulpd xmm14, xmm1
00007e6bc8bdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007e6bc8bdc720  ptest xmm6, xmm6
00007e6bc8bdc725  jnz 0x00007E6BC8BE0F0E
00007e6bc8bdc72b  movaps [r15+0x180], xmm14
00007e6bc8bdc733  movaps xmm1, xmm13
00007e6bc8bdc737  addpd xmm1, xmm8
00007e6bc8bdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007e6bc8bdc741  ptest xmm9, xmm9
00007e6bc8bdc747  jnz 0x00007E6BC8BE1051
00007e6bc8bdc74d  movaps [r15+0x210], xmm1
00007e6bc8bdc755  movups xmm13, [r13+rax*1]
00007e6bc8bdc75b  lea r12, [rax+0x10]
00007e6bc8bdc75f  movups xmm9, [r13+r12*1]
00007e6bc8bdc765  movaps [r15+0x230], xmm9
00007e6bc8bdc76d  movaps xmm8, xmm15
00007e6bc8bdc771  addpd xmm8, xmm7
00007e6bc8bdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007e6bc8bdc77c  ptest xmm6, xmm6
00007e6bc8bdc781  jnz 0x00007E6BC8BE11A7
00007e6bc8bdc787  movaps [r15+0x130], xmm8
00007e6bc8bdc78f  vmovaps xmm15, [rsp+0x20]
00007e6bc8bdc795  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bdc79b  movaps xmm7, xmm9
00007e6bc8bdc79f  mulpd xmm7, xmm15
00007e6bc8bdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007e6bc8bdc7a9  ptest xmm6, xmm6
00007e6bc8bdc7ae  jnz 0x00007E6BC8BE12EA
00007e6bc8bdc7b4  movaps [r15+0x220], xmm7
00007e6bc8bdc7bc  vmovaps xmm15, [rsp+0x20]
00007e6bc8bdc7c2  vpermilpd xmm15, xmm15, 0x00
00007e6bc8bdc7c8  movaps xmm9, xmm13
00007e6bc8bdc7cc  mulpd xmm9, xmm15
00007e6bc8bdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007e6bc8bdc7d7  ptest xmm6, xmm6
00007e6bc8bdc7dc  jnz 0x00007E6BC8BE142C
00007e6bc8bdc7e2  movaps xmm15, xmm11
00007e6bc8bdc7e6  addpd xmm15, xmm12
00007e6bc8bdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007e6bc8bdc7f1  ptest xmm13, xmm13
00007e6bc8bdc7f7  jnz 0x00007E6BC8BE1570
00007e6bc8bdc7fd  movaps [r15+0x140], xmm15
00007e6bc8bdc805  movaps xmm13, xmm10
00007e6bc8bdc809  addpd xmm13, xmm14
00007e6bc8bdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007e6bc8bdc814  ptest xmm12, xmm12
00007e6bc8bdc81a  jnz 0x00007E6BC8BE16B4
00007e6bc8bdc820  movaps [r15+0x150], xmm13
00007e6bc8bdc828  movaps xmm14, xmm1
00007e6bc8bdc82c  addpd xmm14, xmm7
00007e6bc8bdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007e6bc8bdc837  ptest xmm12, xmm12
00007e6bc8bdc83d  jnz 0x00007E6BC8BE17F8
00007e6bc8bdc843  movaps [r15+0x160], xmm14
00007e6bc8bdc84b  movaps xmm1, xmm8
00007e6bc8bdc84f  addpd xmm1, xmm9
00007e6bc8bdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007e6bc8bdc859  ptest xmm12, xmm12
00007e6bc8bdc85f  jnz 0x00007E6BC8BE193A
00007e6bc8bdc865  movaps [r15+0x120], xmm1
00007e6bc8bdc86d  movups [r13+r14*1], xmm15
00007e6bc8bdc873  lea rax, [r14+0x10]
00007e6bc8bdc877  movups [r13+rax*1], xmm13
00007e6bc8bdc87d  lea rax, [r14+0x20]
00007e6bc8bdc881  movups [r13+rax*1], xmm14
00007e6bc8bdc887  lea rax, [r14+0x30]
00007e6bc8bdc88b  movups [r13+rax*1], xmm1
00007e6bc8bdc891  mov eax, [r15+0x108]
00007e6bc8bdc898  sahf
00007e6bc8bdc899  jnz 0x00007E6BC8BDC8CB
00007e6bc8bdc89b  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bdc8a3  jz 0x00007E6BC8BDB900
00007e6bc8bdc8a9  nop [rax+rax*1], ax
00007e6bc8bdc8b2  nop [rax+rax*1], eax
00007e6bc8bdc8ba  mov eax, 0x410444
00007e6bc8bdc8bf  mov [r15+0x100], rax
00007e6bc8bdc8c6  jmp 0x00007E6BC89FE110
00007e6bc8bdc8cb  cmp dword ptr [r15+0x318], 0x00
00007e6bc8bdc8d3  jz 0x00007E6BC8BD57E0
00007e6bc8bdc8d9  nop [rax+rax*1], ax
00007e6bc8bdc8e2  nop [rax+rax*1], eax
00007e6bc8bdc8ea  mov eax, 0x410278
00007e6bc8bdc8ef  mov [r15+0x100], rax
00007e6bc8bdc8f6  jmp 0x00007E6BC89FE110
00007e6bc8bdc8fb  int3
00007e6bc8bdc8fc  call 0x00007E6BC8AE27E0
00007e6bc8bdc901  jmp 0x00007E6BC8BDB9DF
00007e6bc8bdc906  call 0x00007E6BC8AE1570
00007e6bc8bdc90b  jmp 0x00007E6BC8BDB9E8
00007e6bc8bdc910  call 0x00007E6BC8AE27E0
00007e6bc8bdc915  jmp 0x00007E6BC8BDBA44
00007e6bc8bdc91a  call 0x00007E6BC8AE1570
00007e6bc8bdc91f  jmp 0x00007E6BC8BDBA4D
00007e6bc8bdc924  call 0x00007E6BC8AE27E0
00007e6bc8bdc929  jmp 0x00007E6BC8BDBA90
00007e6bc8bdc92e  call 0x00007E6BC8AE1570
00007e6bc8bdc933  jmp 0x00007E6BC8BDBA99
00007e6bc8bdc938  call 0x00007E6BC8A0DC20
00007e6bc8bdc93d  jmp 0x00007E6BC8BDBAD8
00007e6bc8bdc942  call 0x00007E6BC8AD59C0
00007e6bc8bdc947  jmp 0x00007E6BC8BDBAEB
00007e6bc8bdc94c  call 0x00007E6BC8AE0E30
00007e6bc8bdc951  jmp 0x00007E6BC8BDBB09
00007e6bc8bdc956  call 0x00007E6BC8ADFBC0
00007e6bc8bdc95b  jmp 0x00007E6BC8BDBB13
00007e6bc8bdc960  call 0x00007E6BC8ADE950
00007e6bc8bdc965  jmp 0x00007E6BC8BDBB1D
00007e6bc8bdc96a  sub rsp, 0x08
00007e6bc8bdc96e  push rax
00007e6bc8bdc96f  push rcx
00007e6bc8bdc970  push rdx
00007e6bc8bdc971  push rdi
00007e6bc8bdc972  push rsi
00007e6bc8bdc973  push r8
00007e6bc8bdc975  push r9
00007e6bc8bdc977  push r10
00007e6bc8bdc979  push r11
00007e6bc8bdc97b  sub rsp, 0xF0
00007e6bc8bdc982  vmovaps [rsp], xmm0
00007e6bc8bdc987  vmovaps [rsp+0x10], xmm1
00007e6bc8bdc98d  vmovaps [rsp+0x20], xmm2
00007e6bc8bdc993  vmovaps [rsp+0x30], xmm3
00007e6bc8bdc999  vmovaps [rsp+0x40], xmm4
00007e6bc8bdc99f  vmovaps [rsp+0x50], xmm5
00007e6bc8bdc9a5  vmovaps [rsp+0x60], xmm6
00007e6bc8bdc9ab  vmovaps [rsp+0x70], xmm7
00007e6bc8bdc9b1  vmovaps [rsp+0x80], xmm9
00007e6bc8bdc9ba  vmovaps [rsp+0x90], xmm10
00007e6bc8bdc9c3  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdc9cc  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdc9d5  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdc9de  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdc9e7  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdc9f0  sub rsp, 0x30
00007e6bc8bdc9f4  movaps [rsp], xmm8
00007e6bc8bdc9f9  movaps [rsp+0x10], xmm12
00007e6bc8bdc9ff  movaps [rsp+0x20], xmm15
00007e6bc8bdca05  lea rdi, [rsp]
00007e6bc8bdca09  mov esi, 0x00
00007e6bc8bdca0e  mov rax, 0x6543F191D530
00007e6bc8bdca18  call rax
00007e6bc8bdca1a  movaps xmm8, [rsp]
00007e6bc8bdca1f  add rsp, 0x30
00007e6bc8bdca23  vmovaps xmm0, [rsp]
00007e6bc8bdca28  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdca2e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdca34  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdca3a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdca40  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdca46  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdca4c  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdca52  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdca5b  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdca64  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdca6d  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdca76  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdca7f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdca88  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdca91  add rsp, 0xF0
00007e6bc8bdca98  pop r11
00007e6bc8bdca9a  pop r10
00007e6bc8bdca9c  pop r9
00007e6bc8bdca9e  pop r8
00007e6bc8bdcaa0  pop rsi
00007e6bc8bdcaa1  pop rdi
00007e6bc8bdcaa2  pop rdx
00007e6bc8bdcaa3  pop rcx
00007e6bc8bdcaa4  pop rax
00007e6bc8bdcaa5  add rsp, 0x08
00007e6bc8bdcaa9  jmp 0x00007E6BC8BDBB47
00007e6bc8bdcaae  sub rsp, 0x08
00007e6bc8bdcab2  push rax
00007e6bc8bdcab3  push rcx
00007e6bc8bdcab4  push rdx
00007e6bc8bdcab5  push rdi
00007e6bc8bdcab6  push rsi
00007e6bc8bdcab7  push r8
00007e6bc8bdcab9  push r9
00007e6bc8bdcabb  push r10
00007e6bc8bdcabd  push r11
00007e6bc8bdcabf  sub rsp, 0xF0
00007e6bc8bdcac6  vmovaps [rsp], xmm0
00007e6bc8bdcacb  vmovaps [rsp+0x10], xmm1
00007e6bc8bdcad1  vmovaps [rsp+0x20], xmm2
00007e6bc8bdcad7  vmovaps [rsp+0x30], xmm3
00007e6bc8bdcadd  vmovaps [rsp+0x40], xmm4
00007e6bc8bdcae3  vmovaps [rsp+0x50], xmm5
00007e6bc8bdcae9  vmovaps [rsp+0x60], xmm6
00007e6bc8bdcaef  vmovaps [rsp+0x70], xmm8
00007e6bc8bdcaf5  vmovaps [rsp+0x80], xmm9
00007e6bc8bdcafe  vmovaps [rsp+0x90], xmm10
00007e6bc8bdcb07  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdcb10  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdcb19  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdcb22  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdcb2b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdcb34  sub rsp, 0x30
00007e6bc8bdcb38  movaps [rsp], xmm7
00007e6bc8bdcb3c  movaps [rsp+0x10], xmm9
00007e6bc8bdcb42  movaps [rsp+0x20], xmm15
00007e6bc8bdcb48  lea rdi, [rsp]
00007e6bc8bdcb4c  mov esi, 0x00
00007e6bc8bdcb51  mov rax, 0x6543F191D530
00007e6bc8bdcb5b  call rax
00007e6bc8bdcb5d  movaps xmm7, [rsp]
00007e6bc8bdcb61  add rsp, 0x30
00007e6bc8bdcb65  vmovaps xmm0, [rsp]
00007e6bc8bdcb6a  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdcb70  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdcb76  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdcb7c  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdcb82  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdcb88  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdcb8e  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdcb94  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdcb9d  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdcba6  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdcbaf  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdcbb8  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdcbc1  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdcbca  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdcbd3  add rsp, 0xF0
00007e6bc8bdcbda  pop r11
00007e6bc8bdcbdc  pop r10
00007e6bc8bdcbde  pop r9
00007e6bc8bdcbe0  pop r8
00007e6bc8bdcbe2  pop rsi
00007e6bc8bdcbe3  pop rdi
00007e6bc8bdcbe4  pop rdx
00007e6bc8bdcbe5  pop rcx
00007e6bc8bdcbe6  pop rax
00007e6bc8bdcbe7  add rsp, 0x08
00007e6bc8bdcbeb  jmp 0x00007E6BC8BDBB75
00007e6bc8bdcbf0  sub rsp, 0x08
00007e6bc8bdcbf4  push rax
00007e6bc8bdcbf5  push rcx
00007e6bc8bdcbf6  push rdx
00007e6bc8bdcbf7  push rdi
00007e6bc8bdcbf8  push rsi
00007e6bc8bdcbf9  push r8
00007e6bc8bdcbfb  push r9
00007e6bc8bdcbfd  push r10
00007e6bc8bdcbff  push r11
00007e6bc8bdcc01  sub rsp, 0xF0
00007e6bc8bdcc08  vmovaps [rsp], xmm0
00007e6bc8bdcc0d  vmovaps [rsp+0x10], xmm1
00007e6bc8bdcc13  vmovaps [rsp+0x20], xmm2
00007e6bc8bdcc19  vmovaps [rsp+0x30], xmm3
00007e6bc8bdcc1f  vmovaps [rsp+0x40], xmm4
00007e6bc8bdcc25  vmovaps [rsp+0x50], xmm5
00007e6bc8bdcc2b  vmovaps [rsp+0x60], xmm6
00007e6bc8bdcc31  vmovaps [rsp+0x70], xmm7
00007e6bc8bdcc37  vmovaps [rsp+0x80], xmm8
00007e6bc8bdcc40  vmovaps [rsp+0x90], xmm10
00007e6bc8bdcc49  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdcc52  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdcc5b  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdcc64  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdcc6d  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdcc76  sub rsp, 0x30
00007e6bc8bdcc7a  movaps [rsp], xmm9
00007e6bc8bdcc7f  movaps [rsp+0x10], xmm12
00007e6bc8bdcc85  movaps [rsp+0x20], xmm10
00007e6bc8bdcc8b  lea rdi, [rsp]
00007e6bc8bdcc8f  mov esi, 0x00
00007e6bc8bdcc94  mov rax, 0x6543F191D530
00007e6bc8bdcc9e  call rax
00007e6bc8bdcca0  movaps xmm9, [rsp]
00007e6bc8bdcca5  add rsp, 0x30
00007e6bc8bdcca9  vmovaps xmm0, [rsp]
00007e6bc8bdccae  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdccb4  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdccba  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdccc0  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdccc6  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdcccc  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdccd2  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdccd8  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdcce1  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdccea  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdccf3  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdccfc  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdcd05  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdcd0e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdcd17  add rsp, 0xF0
00007e6bc8bdcd1e  pop r11
00007e6bc8bdcd20  pop r10
00007e6bc8bdcd22  pop r9
00007e6bc8bdcd24  pop r8
00007e6bc8bdcd26  pop rsi
00007e6bc8bdcd27  pop rdi
00007e6bc8bdcd28  pop rdx
00007e6bc8bdcd29  pop rcx
00007e6bc8bdcd2a  pop rax
00007e6bc8bdcd2b  add rsp, 0x08
00007e6bc8bdcd2f  jmp 0x00007E6BC8BDBB99
00007e6bc8bdcd34  sub rsp, 0x08
00007e6bc8bdcd38  push rax
00007e6bc8bdcd39  push rcx
00007e6bc8bdcd3a  push rdx
00007e6bc8bdcd3b  push rdi
00007e6bc8bdcd3c  push rsi
00007e6bc8bdcd3d  push r8
00007e6bc8bdcd3f  push r9
00007e6bc8bdcd41  push r10
00007e6bc8bdcd43  push r11
00007e6bc8bdcd45  sub rsp, 0xF0
00007e6bc8bdcd4c  vmovaps [rsp], xmm0
00007e6bc8bdcd51  vmovaps [rsp+0x10], xmm1
00007e6bc8bdcd57  vmovaps [rsp+0x20], xmm2
00007e6bc8bdcd5d  vmovaps [rsp+0x30], xmm3
00007e6bc8bdcd63  vmovaps [rsp+0x40], xmm4
00007e6bc8bdcd69  vmovaps [rsp+0x50], xmm5
00007e6bc8bdcd6f  vmovaps [rsp+0x60], xmm6
00007e6bc8bdcd75  vmovaps [rsp+0x70], xmm7
00007e6bc8bdcd7b  vmovaps [rsp+0x80], xmm8
00007e6bc8bdcd84  vmovaps [rsp+0x90], xmm9
00007e6bc8bdcd8d  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdcd96  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdcd9f  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdcda8  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdcdb1  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdcdba  sub rsp, 0x30
00007e6bc8bdcdbe  movaps [rsp], xmm10
00007e6bc8bdcdc3  movaps [rsp+0x10], xmm12
00007e6bc8bdcdc9  movaps [rsp+0x20], xmm11
00007e6bc8bdcdcf  lea rdi, [rsp]
00007e6bc8bdcdd3  mov esi, 0x00
00007e6bc8bdcdd8  mov rax, 0x6543F191D530
00007e6bc8bdcde2  call rax
00007e6bc8bdcde4  movaps xmm10, [rsp]
00007e6bc8bdcde9  add rsp, 0x30
00007e6bc8bdcded  vmovaps xmm0, [rsp]
00007e6bc8bdcdf2  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdcdf8  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdcdfe  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdce04  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdce0a  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdce10  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdce16  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdce1c  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdce25  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdce2e  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdce37  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdce40  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdce49  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdce52  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdce5b  add rsp, 0xF0
00007e6bc8bdce62  pop r11
00007e6bc8bdce64  pop r10
00007e6bc8bdce66  pop r9
00007e6bc8bdce68  pop r8
00007e6bc8bdce6a  pop rsi
00007e6bc8bdce6b  pop rdi
00007e6bc8bdce6c  pop rdx
00007e6bc8bdce6d  pop rcx
00007e6bc8bdce6e  pop rax
00007e6bc8bdce6f  add rsp, 0x08
00007e6bc8bdce73  jmp 0x00007E6BC8BDBBB3
00007e6bc8bdce78  sub rsp, 0x08
00007e6bc8bdce7c  push rax
00007e6bc8bdce7d  push rcx
00007e6bc8bdce7e  push rdx
00007e6bc8bdce7f  push rdi
00007e6bc8bdce80  push rsi
00007e6bc8bdce81  push r8
00007e6bc8bdce83  push r9
00007e6bc8bdce85  push r10
00007e6bc8bdce87  push r11
00007e6bc8bdce89  sub rsp, 0xF0
00007e6bc8bdce90  vmovaps [rsp], xmm0
00007e6bc8bdce95  vmovaps [rsp+0x10], xmm1
00007e6bc8bdce9b  vmovaps [rsp+0x20], xmm2
00007e6bc8bdcea1  vmovaps [rsp+0x30], xmm3
00007e6bc8bdcea7  vmovaps [rsp+0x40], xmm4
00007e6bc8bdcead  vmovaps [rsp+0x50], xmm5
00007e6bc8bdceb3  vmovaps [rsp+0x60], xmm7
00007e6bc8bdceb9  vmovaps [rsp+0x70], xmm8
00007e6bc8bdcebf  vmovaps [rsp+0x80], xmm9
00007e6bc8bdcec8  vmovaps [rsp+0x90], xmm10
00007e6bc8bdced1  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdceda  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdcee3  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdceec  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdcef5  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdcefe  sub rsp, 0x30
00007e6bc8bdcf02  movaps [rsp], xmm6
00007e6bc8bdcf06  movaps [rsp+0x10], xmm12
00007e6bc8bdcf0c  movaps [rsp+0x20], xmm11
00007e6bc8bdcf12  lea rdi, [rsp]
00007e6bc8bdcf16  mov esi, 0x00
00007e6bc8bdcf1b  mov rax, 0x6543F191D530
00007e6bc8bdcf25  call rax
00007e6bc8bdcf27  movaps xmm6, [rsp]
00007e6bc8bdcf2b  add rsp, 0x30
00007e6bc8bdcf2f  vmovaps xmm0, [rsp]
00007e6bc8bdcf34  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdcf3a  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdcf40  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdcf46  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdcf4c  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdcf52  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdcf58  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdcf5e  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdcf67  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdcf70  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdcf79  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdcf82  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdcf8b  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdcf94  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdcf9d  add rsp, 0xF0
00007e6bc8bdcfa4  pop r11
00007e6bc8bdcfa6  pop r10
00007e6bc8bdcfa8  pop r9
00007e6bc8bdcfaa  pop r8
00007e6bc8bdcfac  pop rsi
00007e6bc8bdcfad  pop rdi
00007e6bc8bdcfae  pop rdx
00007e6bc8bdcfaf  pop rcx
00007e6bc8bdcfb0  pop rax
00007e6bc8bdcfb1  add rsp, 0x08
00007e6bc8bdcfb5  jmp 0x00007E6BC8BDBBD4
00007e6bc8bdcfba  sub rsp, 0x08
00007e6bc8bdcfbe  push rax
00007e6bc8bdcfbf  push rcx
00007e6bc8bdcfc0  push rdx
00007e6bc8bdcfc1  push rdi
00007e6bc8bdcfc2  push rsi
00007e6bc8bdcfc3  push r8
00007e6bc8bdcfc5  push r9
00007e6bc8bdcfc7  push r10
00007e6bc8bdcfc9  push r11
00007e6bc8bdcfcb  sub rsp, 0xF0
00007e6bc8bdcfd2  vmovaps [rsp], xmm0
00007e6bc8bdcfd7  vmovaps [rsp+0x10], xmm1
00007e6bc8bdcfdd  vmovaps [rsp+0x20], xmm2
00007e6bc8bdcfe3  vmovaps [rsp+0x30], xmm4
00007e6bc8bdcfe9  vmovaps [rsp+0x40], xmm5
00007e6bc8bdcfef  vmovaps [rsp+0x50], xmm6
00007e6bc8bdcff5  vmovaps [rsp+0x60], xmm7
00007e6bc8bdcffb  vmovaps [rsp+0x70], xmm8
00007e6bc8bdd001  vmovaps [rsp+0x80], xmm9
00007e6bc8bdd00a  vmovaps [rsp+0x90], xmm10
00007e6bc8bdd013  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdd01c  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdd025  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdd02e  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdd037  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdd040  sub rsp, 0x30
00007e6bc8bdd044  movaps [rsp], xmm3
00007e6bc8bdd048  movaps [rsp+0x10], xmm5
00007e6bc8bdd04d  movaps [rsp+0x20], xmm4
00007e6bc8bdd052  lea rdi, [rsp]
00007e6bc8bdd056  mov esi, 0x00
00007e6bc8bdd05b  mov rax, 0x6543F191D530
00007e6bc8bdd065  call rax
00007e6bc8bdd067  movaps xmm3, [rsp]
00007e6bc8bdd06b  add rsp, 0x30
00007e6bc8bdd06f  vmovaps xmm0, [rsp]
00007e6bc8bdd074  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdd07a  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdd080  vmovaps xmm4, [rsp+0x30]
00007e6bc8bdd086  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdd08c  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdd092  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdd098  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdd09e  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdd0a7  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdd0b0  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdd0b9  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdd0c2  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdd0cb  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdd0d4  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdd0dd  add rsp, 0xF0
00007e6bc8bdd0e4  pop r11
00007e6bc8bdd0e6  pop r10
00007e6bc8bdd0e8  pop r9
00007e6bc8bdd0ea  pop r8
00007e6bc8bdd0ec  pop rsi
00007e6bc8bdd0ed  pop rdi
00007e6bc8bdd0ee  pop rdx
00007e6bc8bdd0ef  pop rcx
00007e6bc8bdd0f0  pop rax
00007e6bc8bdd0f1  add rsp, 0x08
00007e6bc8bdd0f5  jmp 0x00007E6BC8BDBC35
00007e6bc8bdd0fa  sub rsp, 0x08
00007e6bc8bdd0fe  push rax
00007e6bc8bdd0ff  push rcx
00007e6bc8bdd100  push rdx
00007e6bc8bdd101  push rdi
00007e6bc8bdd102  push rsi
00007e6bc8bdd103  push r8
00007e6bc8bdd105  push r9
00007e6bc8bdd107  push r10
00007e6bc8bdd109  push r11
00007e6bc8bdd10b  sub rsp, 0xF0
00007e6bc8bdd112  vmovaps [rsp], xmm0
00007e6bc8bdd117  vmovaps [rsp+0x10], xmm1
00007e6bc8bdd11d  vmovaps [rsp+0x20], xmm2
00007e6bc8bdd123  vmovaps [rsp+0x30], xmm3
00007e6bc8bdd129  vmovaps [rsp+0x40], xmm4
00007e6bc8bdd12f  vmovaps [rsp+0x50], xmm6
00007e6bc8bdd135  vmovaps [rsp+0x60], xmm7
00007e6bc8bdd13b  vmovaps [rsp+0x70], xmm8
00007e6bc8bdd141  vmovaps [rsp+0x80], xmm9
00007e6bc8bdd14a  vmovaps [rsp+0x90], xmm10
00007e6bc8bdd153  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdd15c  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdd165  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdd16e  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdd177  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdd180  sub rsp, 0x30
00007e6bc8bdd184  movaps [rsp], xmm5
00007e6bc8bdd188  movaps [rsp+0x10], xmm8
00007e6bc8bdd18e  movaps [rsp+0x20], xmm15
00007e6bc8bdd194  lea rdi, [rsp]
00007e6bc8bdd198  mov esi, 0x00
00007e6bc8bdd19d  mov rax, 0x6543F191D530
00007e6bc8bdd1a7  call rax
00007e6bc8bdd1a9  movaps xmm5, [rsp]
00007e6bc8bdd1ad  add rsp, 0x30
00007e6bc8bdd1b1  vmovaps xmm0, [rsp]
00007e6bc8bdd1b6  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdd1bc  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdd1c2  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdd1c8  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdd1ce  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdd1d4  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdd1da  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdd1e0  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdd1e9  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdd1f2  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdd1fb  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdd204  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdd20d  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdd216  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdd21f  add rsp, 0xF0
00007e6bc8bdd226  pop r11
00007e6bc8bdd228  pop r10
00007e6bc8bdd22a  pop r9
00007e6bc8bdd22c  pop r8
00007e6bc8bdd22e  pop rsi
00007e6bc8bdd22f  pop rdi
00007e6bc8bdd230  pop rdx
00007e6bc8bdd231  pop rcx
00007e6bc8bdd232  pop rax
00007e6bc8bdd233  add rsp, 0x08
00007e6bc8bdd237  jmp 0x00007E6BC8BDBC73
00007e6bc8bdd23c  sub rsp, 0x08
00007e6bc8bdd240  push rax
00007e6bc8bdd241  push rcx
00007e6bc8bdd242  push rdx
00007e6bc8bdd243  push rdi
00007e6bc8bdd244  push rsi
00007e6bc8bdd245  push r8
00007e6bc8bdd247  push r9
00007e6bc8bdd249  push r10
00007e6bc8bdd24b  push r11
00007e6bc8bdd24d  sub rsp, 0xF0
00007e6bc8bdd254  vmovaps [rsp], xmm0
00007e6bc8bdd259  vmovaps [rsp+0x10], xmm1
00007e6bc8bdd25f  vmovaps [rsp+0x20], xmm2
00007e6bc8bdd265  vmovaps [rsp+0x30], xmm3
00007e6bc8bdd26b  vmovaps [rsp+0x40], xmm5
00007e6bc8bdd271  vmovaps [rsp+0x50], xmm6
00007e6bc8bdd277  vmovaps [rsp+0x60], xmm7
00007e6bc8bdd27d  vmovaps [rsp+0x70], xmm8
00007e6bc8bdd283  vmovaps [rsp+0x80], xmm9
00007e6bc8bdd28c  vmovaps [rsp+0x90], xmm10
00007e6bc8bdd295  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdd29e  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdd2a7  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdd2b0  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdd2b9  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdd2c2  sub rsp, 0x30
00007e6bc8bdd2c6  movaps [rsp], xmm4
00007e6bc8bdd2ca  movaps [rsp+0x10], xmm9
00007e6bc8bdd2d0  movaps [rsp+0x20], xmm8
00007e6bc8bdd2d6  lea rdi, [rsp]
00007e6bc8bdd2da  mov esi, 0x00
00007e6bc8bdd2df  mov rax, 0x6543F191D530
00007e6bc8bdd2e9  call rax
00007e6bc8bdd2eb  movaps xmm4, [rsp]
00007e6bc8bdd2ef  add rsp, 0x30
00007e6bc8bdd2f3  vmovaps xmm0, [rsp]
00007e6bc8bdd2f8  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdd2fe  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdd304  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdd30a  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdd310  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdd316  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdd31c  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdd322  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdd32b  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdd334  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdd33d  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdd346  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdd34f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdd358  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdd361  add rsp, 0xF0
00007e6bc8bdd368  pop r11
00007e6bc8bdd36a  pop r10
00007e6bc8bdd36c  pop r9
00007e6bc8bdd36e  pop r8
00007e6bc8bdd370  pop rsi
00007e6bc8bdd371  pop rdi
00007e6bc8bdd372  pop rdx
00007e6bc8bdd373  pop rcx
00007e6bc8bdd374  pop rax
00007e6bc8bdd375  add rsp, 0x08
00007e6bc8bdd379  jmp 0x00007E6BC8BDBC94
00007e6bc8bdd37e  sub rsp, 0x08
00007e6bc8bdd382  push rax
00007e6bc8bdd383  push rcx
00007e6bc8bdd384  push rdx
00007e6bc8bdd385  push rdi
00007e6bc8bdd386  push rsi
00007e6bc8bdd387  push r8
00007e6bc8bdd389  push r9
00007e6bc8bdd38b  push r10
00007e6bc8bdd38d  push r11
00007e6bc8bdd38f  sub rsp, 0xF0
00007e6bc8bdd396  vmovaps [rsp], xmm0
00007e6bc8bdd39b  vmovaps [rsp+0x10], xmm1
00007e6bc8bdd3a1  vmovaps [rsp+0x20], xmm2
00007e6bc8bdd3a7  vmovaps [rsp+0x30], xmm3
00007e6bc8bdd3ad  vmovaps [rsp+0x40], xmm4
00007e6bc8bdd3b3  vmovaps [rsp+0x50], xmm5
00007e6bc8bdd3b9  vmovaps [rsp+0x60], xmm6
00007e6bc8bdd3bf  vmovaps [rsp+0x70], xmm7
00007e6bc8bdd3c5  vmovaps [rsp+0x80], xmm8
00007e6bc8bdd3ce  vmovaps [rsp+0x90], xmm10
00007e6bc8bdd3d7  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdd3e0  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdd3e9  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdd3f2  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdd3fb  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdd404  sub rsp, 0x30
00007e6bc8bdd408  movaps [rsp], xmm9
00007e6bc8bdd40d  movaps [rsp+0x10], xmm10
00007e6bc8bdd413  movaps [rsp+0x20], xmm8
00007e6bc8bdd419  lea rdi, [rsp]
00007e6bc8bdd41d  mov esi, 0x00
00007e6bc8bdd422  mov rax, 0x6543F191D530
00007e6bc8bdd42c  call rax
00007e6bc8bdd42e  movaps xmm9, [rsp]
00007e6bc8bdd433  add rsp, 0x30
00007e6bc8bdd437  vmovaps xmm0, [rsp]
00007e6bc8bdd43c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdd442  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdd448  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdd44e  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdd454  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdd45a  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdd460  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdd466  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdd46f  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdd478  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdd481  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdd48a  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdd493  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdd49c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdd4a5  add rsp, 0xF0
00007e6bc8bdd4ac  pop r11
00007e6bc8bdd4ae  pop r10
00007e6bc8bdd4b0  pop r9
00007e6bc8bdd4b2  pop r8
00007e6bc8bdd4b4  pop rsi
00007e6bc8bdd4b5  pop rdi
00007e6bc8bdd4b6  pop rdx
00007e6bc8bdd4b7  pop rcx
00007e6bc8bdd4b8  pop rax
00007e6bc8bdd4b9  add rsp, 0x08
00007e6bc8bdd4bd  jmp 0x00007E6BC8BDBCAE
00007e6bc8bdd4c2  call 0x00007E6BC8AB52F0
00007e6bc8bdd4c7  jmp 0x00007E6BC8BDBDC8
00007e6bc8bdd4cc  call 0x00007E6BC8AB52F0
00007e6bc8bdd4d1  jmp 0x00007E6BC8BDBDDE
00007e6bc8bdd4d6  sub rsp, 0x08
00007e6bc8bdd4da  push rax
00007e6bc8bdd4db  push rcx
00007e6bc8bdd4dc  push rdx
00007e6bc8bdd4dd  push rdi
00007e6bc8bdd4de  push rsi
00007e6bc8bdd4df  push r8
00007e6bc8bdd4e1  push r9
00007e6bc8bdd4e3  push r10
00007e6bc8bdd4e5  push r11
00007e6bc8bdd4e7  sub rsp, 0xF0
00007e6bc8bdd4ee  vmovaps [rsp], xmm0
00007e6bc8bdd4f3  vmovaps [rsp+0x10], xmm2
00007e6bc8bdd4f9  vmovaps [rsp+0x20], xmm3
00007e6bc8bdd4ff  vmovaps [rsp+0x30], xmm4
00007e6bc8bdd505  vmovaps [rsp+0x40], xmm5
00007e6bc8bdd50b  vmovaps [rsp+0x50], xmm6
00007e6bc8bdd511  vmovaps [rsp+0x60], xmm7
00007e6bc8bdd517  vmovaps [rsp+0x70], xmm8
00007e6bc8bdd51d  vmovaps [rsp+0x80], xmm9
00007e6bc8bdd526  vmovaps [rsp+0x90], xmm10
00007e6bc8bdd52f  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdd538  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdd541  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdd54a  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdd553  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdd55c  sub rsp, 0x30
00007e6bc8bdd560  movaps [rsp], xmm1
00007e6bc8bdd564  movaps [rsp+0x10], xmm6
00007e6bc8bdd569  movaps [rsp+0x20], xmm15
00007e6bc8bdd56f  lea rdi, [rsp]
00007e6bc8bdd573  mov esi, 0x00
00007e6bc8bdd578  mov rax, 0x6543F191D530
00007e6bc8bdd582  call rax
00007e6bc8bdd584  movaps xmm1, [rsp]
00007e6bc8bdd588  add rsp, 0x30
00007e6bc8bdd58c  vmovaps xmm0, [rsp]
00007e6bc8bdd591  vmovaps xmm2, [rsp+0x10]
00007e6bc8bdd597  vmovaps xmm3, [rsp+0x20]
00007e6bc8bdd59d  vmovaps xmm4, [rsp+0x30]
00007e6bc8bdd5a3  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdd5a9  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdd5af  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdd5b5  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdd5bb  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdd5c4  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdd5cd  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdd5d6  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdd5df  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdd5e8  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdd5f1  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdd5fa  add rsp, 0xF0
00007e6bc8bdd601  pop r11
00007e6bc8bdd603  pop r10
00007e6bc8bdd605  pop r9
00007e6bc8bdd607  pop r8
00007e6bc8bdd609  pop rsi
00007e6bc8bdd60a  pop rdi
00007e6bc8bdd60b  pop rdx
00007e6bc8bdd60c  pop rcx
00007e6bc8bdd60d  pop rax
00007e6bc8bdd60e  add rsp, 0x08
00007e6bc8bdd612  jmp 0x00007E6BC8BDBE1B
00007e6bc8bdd617  call 0x00007E6BC8AC4620
00007e6bc8bdd61c  jmp 0x00007E6BC8BDBE28
00007e6bc8bdd621  sub rsp, 0x08
00007e6bc8bdd625  push rax
00007e6bc8bdd626  push rcx
00007e6bc8bdd627  push rdx
00007e6bc8bdd628  push rdi
00007e6bc8bdd629  push rsi
00007e6bc8bdd62a  push r8
00007e6bc8bdd62c  push r9
00007e6bc8bdd62e  push r10
00007e6bc8bdd630  push r11
00007e6bc8bdd632  sub rsp, 0xF0
00007e6bc8bdd639  vmovaps [rsp], xmm0
00007e6bc8bdd63e  vmovaps [rsp+0x10], xmm1
00007e6bc8bdd644  vmovaps [rsp+0x20], xmm2
00007e6bc8bdd64a  vmovaps [rsp+0x30], xmm3
00007e6bc8bdd650  vmovaps [rsp+0x40], xmm4
00007e6bc8bdd656  vmovaps [rsp+0x50], xmm5
00007e6bc8bdd65c  vmovaps [rsp+0x60], xmm6
00007e6bc8bdd662  vmovaps [rsp+0x70], xmm7
00007e6bc8bdd668  vmovaps [rsp+0x80], xmm8
00007e6bc8bdd671  vmovaps [rsp+0x90], xmm9
00007e6bc8bdd67a  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdd683  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdd68c  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdd695  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdd69e  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdd6a7  sub rsp, 0x30
00007e6bc8bdd6ab  movaps [rsp], xmm14
00007e6bc8bdd6b0  movaps [rsp+0x10], xmm4
00007e6bc8bdd6b5  movaps [rsp+0x20], xmm3
00007e6bc8bdd6ba  lea rdi, [rsp]
00007e6bc8bdd6be  mov esi, 0x00
00007e6bc8bdd6c3  mov rax, 0x6543F191D530
00007e6bc8bdd6cd  call rax
00007e6bc8bdd6cf  movaps xmm14, [rsp]
00007e6bc8bdd6d4  add rsp, 0x30
00007e6bc8bdd6d8  vmovaps xmm0, [rsp]
00007e6bc8bdd6dd  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdd6e3  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdd6e9  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdd6ef  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdd6f5  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdd6fb  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdd701  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdd707  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdd710  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdd719  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdd722  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdd72b  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdd734  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdd73d  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdd746  add rsp, 0xF0
00007e6bc8bdd74d  pop r11
00007e6bc8bdd74f  pop r10
00007e6bc8bdd751  pop r9
00007e6bc8bdd753  pop r8
00007e6bc8bdd755  pop rsi
00007e6bc8bdd756  pop rdi
00007e6bc8bdd757  pop rdx
00007e6bc8bdd758  pop rcx
00007e6bc8bdd759  pop rax
00007e6bc8bdd75a  add rsp, 0x08
00007e6bc8bdd75e  jmp 0x00007E6BC8BDBE42
00007e6bc8bdd763  sub rsp, 0x08
00007e6bc8bdd767  push rax
00007e6bc8bdd768  push rcx
00007e6bc8bdd769  push rdx
00007e6bc8bdd76a  push rdi
00007e6bc8bdd76b  push rsi
00007e6bc8bdd76c  push r8
00007e6bc8bdd76e  push r9
00007e6bc8bdd770  push r10
00007e6bc8bdd772  push r11
00007e6bc8bdd774  sub rsp, 0xF0
00007e6bc8bdd77b  vmovaps [rsp], xmm0
00007e6bc8bdd780  vmovaps [rsp+0x10], xmm1
00007e6bc8bdd786  vmovaps [rsp+0x20], xmm2
00007e6bc8bdd78c  vmovaps [rsp+0x30], xmm3
00007e6bc8bdd792  vmovaps [rsp+0x40], xmm4
00007e6bc8bdd798  vmovaps [rsp+0x50], xmm5
00007e6bc8bdd79e  vmovaps [rsp+0x60], xmm7
00007e6bc8bdd7a4  vmovaps [rsp+0x70], xmm8
00007e6bc8bdd7aa  vmovaps [rsp+0x80], xmm9
00007e6bc8bdd7b3  vmovaps [rsp+0x90], xmm10
00007e6bc8bdd7bc  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdd7c5  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdd7ce  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdd7d7  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdd7e0  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdd7e9  sub rsp, 0x30
00007e6bc8bdd7ed  movaps [rsp], xmm6
00007e6bc8bdd7f1  movaps [rsp+0x10], xmm9
00007e6bc8bdd7f7  movaps [rsp+0x20], xmm7
00007e6bc8bdd7fc  lea rdi, [rsp]
00007e6bc8bdd800  mov esi, 0x00
00007e6bc8bdd805  mov rax, 0x6543F191D530
00007e6bc8bdd80f  call rax
00007e6bc8bdd811  movaps xmm6, [rsp]
00007e6bc8bdd815  add rsp, 0x30
00007e6bc8bdd819  vmovaps xmm0, [rsp]
00007e6bc8bdd81e  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdd824  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdd82a  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdd830  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdd836  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdd83c  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdd842  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdd848  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdd851  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdd85a  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdd863  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdd86c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdd875  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdd87e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdd887  add rsp, 0xF0
00007e6bc8bdd88e  pop r11
00007e6bc8bdd890  pop r10
00007e6bc8bdd892  pop r9
00007e6bc8bdd894  pop r8
00007e6bc8bdd896  pop rsi
00007e6bc8bdd897  pop rdi
00007e6bc8bdd898  pop rdx
00007e6bc8bdd899  pop rcx
00007e6bc8bdd89a  pop rax
00007e6bc8bdd89b  add rsp, 0x08
00007e6bc8bdd89f  jmp 0x00007E6BC8BDBE5A
00007e6bc8bdd8a4  sub rsp, 0x08
00007e6bc8bdd8a8  push rax
00007e6bc8bdd8a9  push rcx
00007e6bc8bdd8aa  push rdx
00007e6bc8bdd8ab  push rdi
00007e6bc8bdd8ac  push rsi
00007e6bc8bdd8ad  push r8
00007e6bc8bdd8af  push r9
00007e6bc8bdd8b1  push r10
00007e6bc8bdd8b3  push r11
00007e6bc8bdd8b5  sub rsp, 0xF0
00007e6bc8bdd8bc  vmovaps [rsp], xmm0
00007e6bc8bdd8c1  vmovaps [rsp+0x10], xmm1
00007e6bc8bdd8c7  vmovaps [rsp+0x20], xmm2
00007e6bc8bdd8cd  vmovaps [rsp+0x30], xmm3
00007e6bc8bdd8d3  vmovaps [rsp+0x40], xmm4
00007e6bc8bdd8d9  vmovaps [rsp+0x50], xmm5
00007e6bc8bdd8df  vmovaps [rsp+0x60], xmm6
00007e6bc8bdd8e5  vmovaps [rsp+0x70], xmm8
00007e6bc8bdd8eb  vmovaps [rsp+0x80], xmm9
00007e6bc8bdd8f4  vmovaps [rsp+0x90], xmm10
00007e6bc8bdd8fd  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdd906  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdd90f  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdd918  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdd921  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdd92a  sub rsp, 0x30
00007e6bc8bdd92e  movaps [rsp], xmm7
00007e6bc8bdd932  movaps [rsp+0x10], xmm4
00007e6bc8bdd937  movaps [rsp+0x20], xmm9
00007e6bc8bdd93d  lea rdi, [rsp]
00007e6bc8bdd941  mov esi, 0x00
00007e6bc8bdd946  mov rax, 0x6543F191D530
00007e6bc8bdd950  call rax
00007e6bc8bdd952  movaps xmm7, [rsp]
00007e6bc8bdd956  add rsp, 0x30
00007e6bc8bdd95a  vmovaps xmm0, [rsp]
00007e6bc8bdd95f  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdd965  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdd96b  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdd971  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdd977  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdd97d  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdd983  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdd989  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdd992  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdd99b  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdd9a4  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdd9ad  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdd9b6  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdd9bf  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdd9c8  add rsp, 0xF0
00007e6bc8bdd9cf  pop r11
00007e6bc8bdd9d1  pop r10
00007e6bc8bdd9d3  pop r9
00007e6bc8bdd9d5  pop r8
00007e6bc8bdd9d7  pop rsi
00007e6bc8bdd9d8  pop rdi
00007e6bc8bdd9d9  pop rdx
00007e6bc8bdd9da  pop rcx
00007e6bc8bdd9db  pop rax
00007e6bc8bdd9dc  add rsp, 0x08
00007e6bc8bdd9e0  jmp 0x00007E6BC8BDBE87
00007e6bc8bdd9e5  sub rsp, 0x08
00007e6bc8bdd9e9  push rax
00007e6bc8bdd9ea  push rcx
00007e6bc8bdd9eb  push rdx
00007e6bc8bdd9ec  push rdi
00007e6bc8bdd9ed  push rsi
00007e6bc8bdd9ee  push r8
00007e6bc8bdd9f0  push r9
00007e6bc8bdd9f2  push r10
00007e6bc8bdd9f4  push r11
00007e6bc8bdd9f6  sub rsp, 0xF0
00007e6bc8bdd9fd  vmovaps [rsp], xmm0
00007e6bc8bdda02  vmovaps [rsp+0x10], xmm1
00007e6bc8bdda08  vmovaps [rsp+0x20], xmm2
00007e6bc8bdda0e  vmovaps [rsp+0x30], xmm3
00007e6bc8bdda14  vmovaps [rsp+0x40], xmm5
00007e6bc8bdda1a  vmovaps [rsp+0x50], xmm6
00007e6bc8bdda20  vmovaps [rsp+0x60], xmm7
00007e6bc8bdda26  vmovaps [rsp+0x70], xmm8
00007e6bc8bdda2c  vmovaps [rsp+0x80], xmm9
00007e6bc8bdda35  vmovaps [rsp+0x90], xmm10
00007e6bc8bdda3e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdda47  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdda50  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdda59  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdda62  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdda6b  sub rsp, 0x30
00007e6bc8bdda6f  movaps [rsp], xmm4
00007e6bc8bdda73  movaps [rsp+0x10], xmm15
00007e6bc8bdda79  movaps [rsp+0x20], xmm9
00007e6bc8bdda7f  lea rdi, [rsp]
00007e6bc8bdda83  mov esi, 0x00
00007e6bc8bdda88  mov rax, 0x6543F191D530
00007e6bc8bdda92  call rax
00007e6bc8bdda94  movaps xmm4, [rsp]
00007e6bc8bdda98  add rsp, 0x30
00007e6bc8bdda9c  vmovaps xmm0, [rsp]
00007e6bc8bddaa1  vmovaps xmm1, [rsp+0x10]
00007e6bc8bddaa7  vmovaps xmm2, [rsp+0x20]
00007e6bc8bddaad  vmovaps xmm3, [rsp+0x30]
00007e6bc8bddab3  vmovaps xmm5, [rsp+0x40]
00007e6bc8bddab9  vmovaps xmm6, [rsp+0x50]
00007e6bc8bddabf  vmovaps xmm7, [rsp+0x60]
00007e6bc8bddac5  vmovaps xmm8, [rsp+0x70]
00007e6bc8bddacb  vmovaps xmm9, [rsp+0x80]
00007e6bc8bddad4  vmovaps xmm10, [rsp+0x90]
00007e6bc8bddadd  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bddae6  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bddaef  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bddaf8  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bddb01  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bddb0a  add rsp, 0xF0
00007e6bc8bddb11  pop r11
00007e6bc8bddb13  pop r10
00007e6bc8bddb15  pop r9
00007e6bc8bddb17  pop r8
00007e6bc8bddb19  pop rsi
00007e6bc8bddb1a  pop rdi
00007e6bc8bddb1b  pop rdx
00007e6bc8bddb1c  pop rcx
00007e6bc8bddb1d  pop rax
00007e6bc8bddb1e  add rsp, 0x08
00007e6bc8bddb22  jmp 0x00007E6BC8BDBEAC
00007e6bc8bddb27  call 0x00007E6BC8AC4620
00007e6bc8bddb2c  jmp 0x00007E6BC8BDBEB9
00007e6bc8bddb31  sub rsp, 0x08
00007e6bc8bddb35  push rax
00007e6bc8bddb36  push rcx
00007e6bc8bddb37  push rdx
00007e6bc8bddb38  push rdi
00007e6bc8bddb39  push rsi
00007e6bc8bddb3a  push r8
00007e6bc8bddb3c  push r9
00007e6bc8bddb3e  push r10
00007e6bc8bddb40  push r11
00007e6bc8bddb42  sub rsp, 0xF0
00007e6bc8bddb49  vmovaps [rsp], xmm0
00007e6bc8bddb4e  vmovaps [rsp+0x10], xmm1
00007e6bc8bddb54  vmovaps [rsp+0x20], xmm2
00007e6bc8bddb5a  vmovaps [rsp+0x30], xmm4
00007e6bc8bddb60  vmovaps [rsp+0x40], xmm5
00007e6bc8bddb66  vmovaps [rsp+0x50], xmm6
00007e6bc8bddb6c  vmovaps [rsp+0x60], xmm7
00007e6bc8bddb72  vmovaps [rsp+0x70], xmm8
00007e6bc8bddb78  vmovaps [rsp+0x80], xmm9
00007e6bc8bddb81  vmovaps [rsp+0x90], xmm10
00007e6bc8bddb8a  vmovaps [rsp+0xA0], xmm11
00007e6bc8bddb93  vmovaps [rsp+0xB0], xmm12
00007e6bc8bddb9c  vmovaps [rsp+0xC0], xmm13
00007e6bc8bddba5  vmovaps [rsp+0xD0], xmm14
00007e6bc8bddbae  vmovaps [rsp+0xE0], xmm15
00007e6bc8bddbb7  sub rsp, 0x30
00007e6bc8bddbbb  movaps [rsp], xmm3
00007e6bc8bddbbf  movaps [rsp+0x10], xmm1
00007e6bc8bddbc4  movaps [rsp+0x20], xmm9
00007e6bc8bddbca  lea rdi, [rsp]
00007e6bc8bddbce  mov esi, 0x00
00007e6bc8bddbd3  mov rax, 0x6543F191D530
00007e6bc8bddbdd  call rax
00007e6bc8bddbdf  movaps xmm3, [rsp]
00007e6bc8bddbe3  add rsp, 0x30
00007e6bc8bddbe7  vmovaps xmm0, [rsp]
00007e6bc8bddbec  vmovaps xmm1, [rsp+0x10]
00007e6bc8bddbf2  vmovaps xmm2, [rsp+0x20]
00007e6bc8bddbf8  vmovaps xmm4, [rsp+0x30]
00007e6bc8bddbfe  vmovaps xmm5, [rsp+0x40]
00007e6bc8bddc04  vmovaps xmm6, [rsp+0x50]
00007e6bc8bddc0a  vmovaps xmm7, [rsp+0x60]
00007e6bc8bddc10  vmovaps xmm8, [rsp+0x70]
00007e6bc8bddc16  vmovaps xmm9, [rsp+0x80]
00007e6bc8bddc1f  vmovaps xmm10, [rsp+0x90]
00007e6bc8bddc28  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bddc31  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bddc3a  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bddc43  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bddc4c  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bddc55  add rsp, 0xF0
00007e6bc8bddc5c  pop r11
00007e6bc8bddc5e  pop r10
00007e6bc8bddc60  pop r9
00007e6bc8bddc62  pop r8
00007e6bc8bddc64  pop rsi
00007e6bc8bddc65  pop rdi
00007e6bc8bddc66  pop rdx
00007e6bc8bddc67  pop rcx
00007e6bc8bddc68  pop rax
00007e6bc8bddc69  add rsp, 0x08
00007e6bc8bddc6d  jmp 0x00007E6BC8BDBEF6
00007e6bc8bddc72  sub rsp, 0x08
00007e6bc8bddc76  push rax
00007e6bc8bddc77  push rcx
00007e6bc8bddc78  push rdx
00007e6bc8bddc79  push rdi
00007e6bc8bddc7a  push rsi
00007e6bc8bddc7b  push r8
00007e6bc8bddc7d  push r9
00007e6bc8bddc7f  push r10
00007e6bc8bddc81  push r11
00007e6bc8bddc83  sub rsp, 0xF0
00007e6bc8bddc8a  vmovaps [rsp], xmm0
00007e6bc8bddc8f  vmovaps [rsp+0x10], xmm2
00007e6bc8bddc95  vmovaps [rsp+0x20], xmm3
00007e6bc8bddc9b  vmovaps [rsp+0x30], xmm4
00007e6bc8bddca1  vmovaps [rsp+0x40], xmm5
00007e6bc8bddca7  vmovaps [rsp+0x50], xmm6
00007e6bc8bddcad  vmovaps [rsp+0x60], xmm7
00007e6bc8bddcb3  vmovaps [rsp+0x70], xmm8
00007e6bc8bddcb9  vmovaps [rsp+0x80], xmm9
00007e6bc8bddcc2  vmovaps [rsp+0x90], xmm10
00007e6bc8bddccb  vmovaps [rsp+0xA0], xmm11
00007e6bc8bddcd4  vmovaps [rsp+0xB0], xmm12
00007e6bc8bddcdd  vmovaps [rsp+0xC0], xmm13
00007e6bc8bddce6  vmovaps [rsp+0xD0], xmm14
00007e6bc8bddcef  vmovaps [rsp+0xE0], xmm15
00007e6bc8bddcf8  sub rsp, 0x30
00007e6bc8bddcfc  movaps [rsp], xmm1
00007e6bc8bddd00  movaps [rsp+0x10], xmm15
00007e6bc8bddd06  movaps [rsp+0x20], xmm9
00007e6bc8bddd0c  lea rdi, [rsp]
00007e6bc8bddd10  mov esi, 0x00
00007e6bc8bddd15  mov rax, 0x6543F191D530
00007e6bc8bddd1f  call rax
00007e6bc8bddd21  movaps xmm1, [rsp]
00007e6bc8bddd25  add rsp, 0x30
00007e6bc8bddd29  vmovaps xmm0, [rsp]
00007e6bc8bddd2e  vmovaps xmm2, [rsp+0x10]
00007e6bc8bddd34  vmovaps xmm3, [rsp+0x20]
00007e6bc8bddd3a  vmovaps xmm4, [rsp+0x30]
00007e6bc8bddd40  vmovaps xmm5, [rsp+0x40]
00007e6bc8bddd46  vmovaps xmm6, [rsp+0x50]
00007e6bc8bddd4c  vmovaps xmm7, [rsp+0x60]
00007e6bc8bddd52  vmovaps xmm8, [rsp+0x70]
00007e6bc8bddd58  vmovaps xmm9, [rsp+0x80]
00007e6bc8bddd61  vmovaps xmm10, [rsp+0x90]
00007e6bc8bddd6a  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bddd73  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bddd7c  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bddd85  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bddd8e  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bddd97  add rsp, 0xF0
00007e6bc8bddd9e  pop r11
00007e6bc8bddda0  pop r10
00007e6bc8bddda2  pop r9
00007e6bc8bddda4  pop r8
00007e6bc8bddda6  pop rsi
00007e6bc8bddda7  pop rdi
00007e6bc8bddda8  pop rdx
00007e6bc8bddda9  pop rcx
00007e6bc8bdddaa  pop rax
00007e6bc8bdddab  add rsp, 0x08
00007e6bc8bdddaf  jmp 0x00007E6BC8BDBF7E
00007e6bc8bdddb4  call 0x00007E6BC8AC4620
00007e6bc8bdddb9  jmp 0x00007E6BC8BDBF8B
00007e6bc8bdddbe  sub rsp, 0x08
00007e6bc8bdddc2  push rax
00007e6bc8bdddc3  push rcx
00007e6bc8bdddc4  push rdx
00007e6bc8bdddc5  push rdi
00007e6bc8bdddc6  push rsi
00007e6bc8bdddc7  push r8
00007e6bc8bdddc9  push r9
00007e6bc8bdddcb  push r10
00007e6bc8bdddcd  push r11
00007e6bc8bdddcf  sub rsp, 0xF0
00007e6bc8bdddd6  vmovaps [rsp], xmm0
00007e6bc8bddddb  vmovaps [rsp+0x10], xmm2
00007e6bc8bddde1  vmovaps [rsp+0x20], xmm3
00007e6bc8bddde7  vmovaps [rsp+0x30], xmm4
00007e6bc8bddded  vmovaps [rsp+0x40], xmm5
00007e6bc8bdddf3  vmovaps [rsp+0x50], xmm6
00007e6bc8bdddf9  vmovaps [rsp+0x60], xmm7
00007e6bc8bdddff  vmovaps [rsp+0x70], xmm8
00007e6bc8bdde05  vmovaps [rsp+0x80], xmm9
00007e6bc8bdde0e  vmovaps [rsp+0x90], xmm10
00007e6bc8bdde17  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdde20  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdde29  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdde32  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdde3b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdde44  sub rsp, 0x30
00007e6bc8bdde48  movaps [rsp], xmm1
00007e6bc8bdde4c  movaps [rsp+0x10], xmm5
00007e6bc8bdde51  movaps [rsp+0x20], xmm7
00007e6bc8bdde56  lea rdi, [rsp]
00007e6bc8bdde5a  mov esi, 0x00
00007e6bc8bdde5f  mov rax, 0x6543F191D530
00007e6bc8bdde69  call rax
00007e6bc8bdde6b  movaps xmm1, [rsp]
00007e6bc8bdde6f  add rsp, 0x30
00007e6bc8bdde73  vmovaps xmm0, [rsp]
00007e6bc8bdde78  vmovaps xmm2, [rsp+0x10]
00007e6bc8bdde7e  vmovaps xmm3, [rsp+0x20]
00007e6bc8bdde84  vmovaps xmm4, [rsp+0x30]
00007e6bc8bdde8a  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdde90  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdde96  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdde9c  vmovaps xmm8, [rsp+0x70]
00007e6bc8bddea2  vmovaps xmm9, [rsp+0x80]
00007e6bc8bddeab  vmovaps xmm10, [rsp+0x90]
00007e6bc8bddeb4  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bddebd  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bddec6  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bddecf  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdded8  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bddee1  add rsp, 0xF0
00007e6bc8bddee8  pop r11
00007e6bc8bddeea  pop r10
00007e6bc8bddeec  pop r9
00007e6bc8bddeee  pop r8
00007e6bc8bddef0  pop rsi
00007e6bc8bddef1  pop rdi
00007e6bc8bddef2  pop rdx
00007e6bc8bddef3  pop rcx
00007e6bc8bddef4  pop rax
00007e6bc8bddef5  add rsp, 0x08
00007e6bc8bddef9  jmp 0x00007E6BC8BDC030
00007e6bc8bddefe  sub rsp, 0x08
00007e6bc8bddf02  push rax
00007e6bc8bddf03  push rcx
00007e6bc8bddf04  push rdx
00007e6bc8bddf05  push rdi
00007e6bc8bddf06  push rsi
00007e6bc8bddf07  push r8
00007e6bc8bddf09  push r9
00007e6bc8bddf0b  push r10
00007e6bc8bddf0d  push r11
00007e6bc8bddf0f  sub rsp, 0xF0
00007e6bc8bddf16  vmovaps [rsp], xmm0
00007e6bc8bddf1b  vmovaps [rsp+0x10], xmm1
00007e6bc8bddf21  vmovaps [rsp+0x20], xmm2
00007e6bc8bddf27  vmovaps [rsp+0x30], xmm3
00007e6bc8bddf2d  vmovaps [rsp+0x40], xmm4
00007e6bc8bddf33  vmovaps [rsp+0x50], xmm5
00007e6bc8bddf39  vmovaps [rsp+0x60], xmm6
00007e6bc8bddf3f  vmovaps [rsp+0x70], xmm8
00007e6bc8bddf45  vmovaps [rsp+0x80], xmm9
00007e6bc8bddf4e  vmovaps [rsp+0x90], xmm10
00007e6bc8bddf57  vmovaps [rsp+0xA0], xmm11
00007e6bc8bddf60  vmovaps [rsp+0xB0], xmm12
00007e6bc8bddf69  vmovaps [rsp+0xC0], xmm13
00007e6bc8bddf72  vmovaps [rsp+0xD0], xmm14
00007e6bc8bddf7b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bddf84  sub rsp, 0x30
00007e6bc8bddf88  movaps [rsp], xmm7
00007e6bc8bddf8c  movaps [rsp+0x10], xmm5
00007e6bc8bddf91  movaps [rsp+0x20], xmm15
00007e6bc8bddf97  lea rdi, [rsp]
00007e6bc8bddf9b  mov esi, 0x00
00007e6bc8bddfa0  mov rax, 0x6543F191D530
00007e6bc8bddfaa  call rax
00007e6bc8bddfac  movaps xmm7, [rsp]
00007e6bc8bddfb0  add rsp, 0x30
00007e6bc8bddfb4  vmovaps xmm0, [rsp]
00007e6bc8bddfb9  vmovaps xmm1, [rsp+0x10]
00007e6bc8bddfbf  vmovaps xmm2, [rsp+0x20]
00007e6bc8bddfc5  vmovaps xmm3, [rsp+0x30]
00007e6bc8bddfcb  vmovaps xmm4, [rsp+0x40]
00007e6bc8bddfd1  vmovaps xmm5, [rsp+0x50]
00007e6bc8bddfd7  vmovaps xmm6, [rsp+0x60]
00007e6bc8bddfdd  vmovaps xmm8, [rsp+0x70]
00007e6bc8bddfe3  vmovaps xmm9, [rsp+0x80]
00007e6bc8bddfec  vmovaps xmm10, [rsp+0x90]
00007e6bc8bddff5  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bddffe  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bde007  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bde010  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bde019  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bde022  add rsp, 0xF0
00007e6bc8bde029  pop r11
00007e6bc8bde02b  pop r10
00007e6bc8bde02d  pop r9
00007e6bc8bde02f  pop r8
00007e6bc8bde031  pop rsi
00007e6bc8bde032  pop rdi
00007e6bc8bde033  pop rdx
00007e6bc8bde034  pop rcx
00007e6bc8bde035  pop rax
00007e6bc8bde036  add rsp, 0x08
00007e6bc8bde03a  jmp 0x00007E6BC8BDC066
00007e6bc8bde03f  call 0x00007E6BC8AB52F0
00007e6bc8bde044  jmp 0x00007E6BC8BDC073
00007e6bc8bde049  sub rsp, 0x08
00007e6bc8bde04d  push rax
00007e6bc8bde04e  push rcx
00007e6bc8bde04f  push rdx
00007e6bc8bde050  push rdi
00007e6bc8bde051  push rsi
00007e6bc8bde052  push r8
00007e6bc8bde054  push r9
00007e6bc8bde056  push r10
00007e6bc8bde058  push r11
00007e6bc8bde05a  sub rsp, 0xF0
00007e6bc8bde061  vmovaps [rsp], xmm0
00007e6bc8bde066  vmovaps [rsp+0x10], xmm1
00007e6bc8bde06c  vmovaps [rsp+0x20], xmm2
00007e6bc8bde072  vmovaps [rsp+0x30], xmm3
00007e6bc8bde078  vmovaps [rsp+0x40], xmm4
00007e6bc8bde07e  vmovaps [rsp+0x50], xmm5
00007e6bc8bde084  vmovaps [rsp+0x60], xmm6
00007e6bc8bde08a  vmovaps [rsp+0x70], xmm7
00007e6bc8bde090  vmovaps [rsp+0x80], xmm8
00007e6bc8bde099  vmovaps [rsp+0x90], xmm9
00007e6bc8bde0a2  vmovaps [rsp+0xA0], xmm10
00007e6bc8bde0ab  vmovaps [rsp+0xB0], xmm11
00007e6bc8bde0b4  vmovaps [rsp+0xC0], xmm12
00007e6bc8bde0bd  vmovaps [rsp+0xD0], xmm13
00007e6bc8bde0c6  vmovaps [rsp+0xE0], xmm14
00007e6bc8bde0cf  sub rsp, 0x30
00007e6bc8bde0d3  movaps [rsp], xmm15
00007e6bc8bde0d8  movaps [rsp+0x10], xmm5
00007e6bc8bde0dd  movaps [rsp+0x20], xmm3
00007e6bc8bde0e2  lea rdi, [rsp]
00007e6bc8bde0e6  mov esi, 0x00
00007e6bc8bde0eb  mov rax, 0x6543F191D530
00007e6bc8bde0f5  call rax
00007e6bc8bde0f7  movaps xmm15, [rsp]
00007e6bc8bde0fc  add rsp, 0x30
00007e6bc8bde100  vmovaps xmm0, [rsp]
00007e6bc8bde105  vmovaps xmm1, [rsp+0x10]
00007e6bc8bde10b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bde111  vmovaps xmm3, [rsp+0x30]
00007e6bc8bde117  vmovaps xmm4, [rsp+0x40]
00007e6bc8bde11d  vmovaps xmm5, [rsp+0x50]
00007e6bc8bde123  vmovaps xmm6, [rsp+0x60]
00007e6bc8bde129  vmovaps xmm7, [rsp+0x70]
00007e6bc8bde12f  vmovaps xmm8, [rsp+0x80]
00007e6bc8bde138  vmovaps xmm9, [rsp+0x90]
00007e6bc8bde141  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bde14a  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bde153  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bde15c  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bde165  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bde16e  add rsp, 0xF0
00007e6bc8bde175  pop r11
00007e6bc8bde177  pop r10
00007e6bc8bde179  pop r9
00007e6bc8bde17b  pop r8
00007e6bc8bde17d  pop rsi
00007e6bc8bde17e  pop rdi
00007e6bc8bde17f  pop rdx
00007e6bc8bde180  pop rcx
00007e6bc8bde181  pop rax
00007e6bc8bde182  add rsp, 0x08
00007e6bc8bde186  jmp 0x00007E6BC8BDC099
00007e6bc8bde18b  sub rsp, 0x08
00007e6bc8bde18f  push rax
00007e6bc8bde190  push rcx
00007e6bc8bde191  push rdx
00007e6bc8bde192  push rdi
00007e6bc8bde193  push rsi
00007e6bc8bde194  push r8
00007e6bc8bde196  push r9
00007e6bc8bde198  push r10
00007e6bc8bde19a  push r11
00007e6bc8bde19c  sub rsp, 0xF0
00007e6bc8bde1a3  vmovaps [rsp], xmm0
00007e6bc8bde1a8  vmovaps [rsp+0x10], xmm2
00007e6bc8bde1ae  vmovaps [rsp+0x20], xmm3
00007e6bc8bde1b4  vmovaps [rsp+0x30], xmm4
00007e6bc8bde1ba  vmovaps [rsp+0x40], xmm5
00007e6bc8bde1c0  vmovaps [rsp+0x50], xmm6
00007e6bc8bde1c6  vmovaps [rsp+0x60], xmm7
00007e6bc8bde1cc  vmovaps [rsp+0x70], xmm8
00007e6bc8bde1d2  vmovaps [rsp+0x80], xmm9
00007e6bc8bde1db  vmovaps [rsp+0x90], xmm10
00007e6bc8bde1e4  vmovaps [rsp+0xA0], xmm11
00007e6bc8bde1ed  vmovaps [rsp+0xB0], xmm12
00007e6bc8bde1f6  vmovaps [rsp+0xC0], xmm13
00007e6bc8bde1ff  vmovaps [rsp+0xD0], xmm14
00007e6bc8bde208  vmovaps [rsp+0xE0], xmm15
00007e6bc8bde211  sub rsp, 0x30
00007e6bc8bde215  movaps [rsp], xmm1
00007e6bc8bde219  movaps [rsp+0x10], xmm5
00007e6bc8bde21e  movaps [rsp+0x20], xmm4
00007e6bc8bde223  lea rdi, [rsp]
00007e6bc8bde227  mov esi, 0x00
00007e6bc8bde22c  mov rax, 0x6543F191D530
00007e6bc8bde236  call rax
00007e6bc8bde238  movaps xmm1, [rsp]
00007e6bc8bde23c  add rsp, 0x30
00007e6bc8bde240  vmovaps xmm0, [rsp]
00007e6bc8bde245  vmovaps xmm2, [rsp+0x10]
00007e6bc8bde24b  vmovaps xmm3, [rsp+0x20]
00007e6bc8bde251  vmovaps xmm4, [rsp+0x30]
00007e6bc8bde257  vmovaps xmm5, [rsp+0x40]
00007e6bc8bde25d  vmovaps xmm6, [rsp+0x50]
00007e6bc8bde263  vmovaps xmm7, [rsp+0x60]
00007e6bc8bde269  vmovaps xmm8, [rsp+0x70]
00007e6bc8bde26f  vmovaps xmm9, [rsp+0x80]
00007e6bc8bde278  vmovaps xmm10, [rsp+0x90]
00007e6bc8bde281  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bde28a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bde293  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bde29c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bde2a5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bde2ae  add rsp, 0xF0
00007e6bc8bde2b5  pop r11
00007e6bc8bde2b7  pop r10
00007e6bc8bde2b9  pop r9
00007e6bc8bde2bb  pop r8
00007e6bc8bde2bd  pop rsi
00007e6bc8bde2be  pop rdi
00007e6bc8bde2bf  pop rdx
00007e6bc8bde2c0  pop rcx
00007e6bc8bde2c1  pop rax
00007e6bc8bde2c2  add rsp, 0x08
00007e6bc8bde2c6  jmp 0x00007E6BC8BDC0B9
00007e6bc8bde2cb  sub rsp, 0x08
00007e6bc8bde2cf  push rax
00007e6bc8bde2d0  push rcx
00007e6bc8bde2d1  push rdx
00007e6bc8bde2d2  push rdi
00007e6bc8bde2d3  push rsi
00007e6bc8bde2d4  push r8
00007e6bc8bde2d6  push r9
00007e6bc8bde2d8  push r10
00007e6bc8bde2da  push r11
00007e6bc8bde2dc  sub rsp, 0xF0
00007e6bc8bde2e3  vmovaps [rsp], xmm0
00007e6bc8bde2e8  vmovaps [rsp+0x10], xmm1
00007e6bc8bde2ee  vmovaps [rsp+0x20], xmm2
00007e6bc8bde2f4  vmovaps [rsp+0x30], xmm3
00007e6bc8bde2fa  vmovaps [rsp+0x40], xmm5
00007e6bc8bde300  vmovaps [rsp+0x50], xmm6
00007e6bc8bde306  vmovaps [rsp+0x60], xmm7
00007e6bc8bde30c  vmovaps [rsp+0x70], xmm8
00007e6bc8bde312  vmovaps [rsp+0x80], xmm9
00007e6bc8bde31b  vmovaps [rsp+0x90], xmm10
00007e6bc8bde324  vmovaps [rsp+0xA0], xmm11
00007e6bc8bde32d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bde336  vmovaps [rsp+0xC0], xmm13
00007e6bc8bde33f  vmovaps [rsp+0xD0], xmm14
00007e6bc8bde348  vmovaps [rsp+0xE0], xmm15
00007e6bc8bde351  sub rsp, 0x30
00007e6bc8bde355  movaps [rsp], xmm4
00007e6bc8bde359  movaps [rsp+0x10], xmm3
00007e6bc8bde35e  movaps [rsp+0x20], xmm5
00007e6bc8bde363  lea rdi, [rsp]
00007e6bc8bde367  mov esi, 0x00
00007e6bc8bde36c  mov rax, 0x6543F191D530
00007e6bc8bde376  call rax
00007e6bc8bde378  movaps xmm4, [rsp]
00007e6bc8bde37c  add rsp, 0x30
00007e6bc8bde380  vmovaps xmm0, [rsp]
00007e6bc8bde385  vmovaps xmm1, [rsp+0x10]
00007e6bc8bde38b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bde391  vmovaps xmm3, [rsp+0x30]
00007e6bc8bde397  vmovaps xmm5, [rsp+0x40]
00007e6bc8bde39d  vmovaps xmm6, [rsp+0x50]
00007e6bc8bde3a3  vmovaps xmm7, [rsp+0x60]
00007e6bc8bde3a9  vmovaps xmm8, [rsp+0x70]
00007e6bc8bde3af  vmovaps xmm9, [rsp+0x80]
00007e6bc8bde3b8  vmovaps xmm10, [rsp+0x90]
00007e6bc8bde3c1  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bde3ca  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bde3d3  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bde3dc  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bde3e5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bde3ee  add rsp, 0xF0
00007e6bc8bde3f5  pop r11
00007e6bc8bde3f7  pop r10
00007e6bc8bde3f9  pop r9
00007e6bc8bde3fb  pop r8
00007e6bc8bde3fd  pop rsi
00007e6bc8bde3fe  pop rdi
00007e6bc8bde3ff  pop rdx
00007e6bc8bde400  pop rcx
00007e6bc8bde401  pop rax
00007e6bc8bde402  add rsp, 0x08
00007e6bc8bde406  jmp 0x00007E6BC8BDC107
00007e6bc8bde40b  call 0x00007E6BC8AB52F0
00007e6bc8bde410  jmp 0x00007E6BC8BDC114
00007e6bc8bde415  sub rsp, 0x08
00007e6bc8bde419  push rax
00007e6bc8bde41a  push rcx
00007e6bc8bde41b  push rdx
00007e6bc8bde41c  push rdi
00007e6bc8bde41d  push rsi
00007e6bc8bde41e  push r8
00007e6bc8bde420  push r9
00007e6bc8bde422  push r10
00007e6bc8bde424  push r11
00007e6bc8bde426  sub rsp, 0xF0
00007e6bc8bde42d  vmovaps [rsp], xmm0
00007e6bc8bde432  vmovaps [rsp+0x10], xmm1
00007e6bc8bde438  vmovaps [rsp+0x20], xmm2
00007e6bc8bde43e  vmovaps [rsp+0x30], xmm3
00007e6bc8bde444  vmovaps [rsp+0x40], xmm4
00007e6bc8bde44a  vmovaps [rsp+0x50], xmm6
00007e6bc8bde450  vmovaps [rsp+0x60], xmm7
00007e6bc8bde456  vmovaps [rsp+0x70], xmm8
00007e6bc8bde45c  vmovaps [rsp+0x80], xmm9
00007e6bc8bde465  vmovaps [rsp+0x90], xmm10
00007e6bc8bde46e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bde477  vmovaps [rsp+0xB0], xmm12
00007e6bc8bde480  vmovaps [rsp+0xC0], xmm13
00007e6bc8bde489  vmovaps [rsp+0xD0], xmm14
00007e6bc8bde492  vmovaps [rsp+0xE0], xmm15
00007e6bc8bde49b  sub rsp, 0x30
00007e6bc8bde49f  movaps [rsp], xmm5
00007e6bc8bde4a3  movaps [rsp+0x10], xmm6
00007e6bc8bde4a8  movaps [rsp+0x20], xmm3
00007e6bc8bde4ad  lea rdi, [rsp]
00007e6bc8bde4b1  mov esi, 0x00
00007e6bc8bde4b6  mov rax, 0x6543F191D530
00007e6bc8bde4c0  call rax
00007e6bc8bde4c2  movaps xmm5, [rsp]
00007e6bc8bde4c6  add rsp, 0x30
00007e6bc8bde4ca  vmovaps xmm0, [rsp]
00007e6bc8bde4cf  vmovaps xmm1, [rsp+0x10]
00007e6bc8bde4d5  vmovaps xmm2, [rsp+0x20]
00007e6bc8bde4db  vmovaps xmm3, [rsp+0x30]
00007e6bc8bde4e1  vmovaps xmm4, [rsp+0x40]
00007e6bc8bde4e7  vmovaps xmm6, [rsp+0x50]
00007e6bc8bde4ed  vmovaps xmm7, [rsp+0x60]
00007e6bc8bde4f3  vmovaps xmm8, [rsp+0x70]
00007e6bc8bde4f9  vmovaps xmm9, [rsp+0x80]
00007e6bc8bde502  vmovaps xmm10, [rsp+0x90]
00007e6bc8bde50b  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bde514  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bde51d  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bde526  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bde52f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bde538  add rsp, 0xF0
00007e6bc8bde53f  pop r11
00007e6bc8bde541  pop r10
00007e6bc8bde543  pop r9
00007e6bc8bde545  pop r8
00007e6bc8bde547  pop rsi
00007e6bc8bde548  pop rdi
00007e6bc8bde549  pop rdx
00007e6bc8bde54a  pop rcx
00007e6bc8bde54b  pop rax
00007e6bc8bde54c  add rsp, 0x08
00007e6bc8bde550  jmp 0x00007E6BC8BDC13A
00007e6bc8bde555  sub rsp, 0x08
00007e6bc8bde559  push rax
00007e6bc8bde55a  push rcx
00007e6bc8bde55b  push rdx
00007e6bc8bde55c  push rdi
00007e6bc8bde55d  push rsi
00007e6bc8bde55e  push r8
00007e6bc8bde560  push r9
00007e6bc8bde562  push r10
00007e6bc8bde564  push r11
00007e6bc8bde566  sub rsp, 0xF0
00007e6bc8bde56d  vmovaps [rsp], xmm0
00007e6bc8bde572  vmovaps [rsp+0x10], xmm1
00007e6bc8bde578  vmovaps [rsp+0x20], xmm2
00007e6bc8bde57e  vmovaps [rsp+0x30], xmm3
00007e6bc8bde584  vmovaps [rsp+0x40], xmm4
00007e6bc8bde58a  vmovaps [rsp+0x50], xmm5
00007e6bc8bde590  vmovaps [rsp+0x60], xmm7
00007e6bc8bde596  vmovaps [rsp+0x70], xmm8
00007e6bc8bde59c  vmovaps [rsp+0x80], xmm9
00007e6bc8bde5a5  vmovaps [rsp+0x90], xmm10
00007e6bc8bde5ae  vmovaps [rsp+0xA0], xmm11
00007e6bc8bde5b7  vmovaps [rsp+0xB0], xmm12
00007e6bc8bde5c0  vmovaps [rsp+0xC0], xmm13
00007e6bc8bde5c9  vmovaps [rsp+0xD0], xmm14
00007e6bc8bde5d2  vmovaps [rsp+0xE0], xmm15
00007e6bc8bde5db  sub rsp, 0x30
00007e6bc8bde5df  movaps [rsp], xmm6
00007e6bc8bde5e3  movaps [rsp+0x10], xmm9
00007e6bc8bde5e9  movaps [rsp+0x20], xmm1
00007e6bc8bde5ee  lea rdi, [rsp]
00007e6bc8bde5f2  mov esi, 0x00
00007e6bc8bde5f7  mov rax, 0x6543F191D530
00007e6bc8bde601  call rax
00007e6bc8bde603  movaps xmm6, [rsp]
00007e6bc8bde607  add rsp, 0x30
00007e6bc8bde60b  vmovaps xmm0, [rsp]
00007e6bc8bde610  vmovaps xmm1, [rsp+0x10]
00007e6bc8bde616  vmovaps xmm2, [rsp+0x20]
00007e6bc8bde61c  vmovaps xmm3, [rsp+0x30]
00007e6bc8bde622  vmovaps xmm4, [rsp+0x40]
00007e6bc8bde628  vmovaps xmm5, [rsp+0x50]
00007e6bc8bde62e  vmovaps xmm7, [rsp+0x60]
00007e6bc8bde634  vmovaps xmm8, [rsp+0x70]
00007e6bc8bde63a  vmovaps xmm9, [rsp+0x80]
00007e6bc8bde643  vmovaps xmm10, [rsp+0x90]
00007e6bc8bde64c  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bde655  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bde65e  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bde667  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bde670  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bde679  add rsp, 0xF0
00007e6bc8bde680  pop r11
00007e6bc8bde682  pop r10
00007e6bc8bde684  pop r9
00007e6bc8bde686  pop r8
00007e6bc8bde688  pop rsi
00007e6bc8bde689  pop rdi
00007e6bc8bde68a  pop rdx
00007e6bc8bde68b  pop rcx
00007e6bc8bde68c  pop rax
00007e6bc8bde68d  add rsp, 0x08
00007e6bc8bde691  jmp 0x00007E6BC8BDC15E
00007e6bc8bde696  sub rsp, 0x08
00007e6bc8bde69a  push rax
00007e6bc8bde69b  push rcx
00007e6bc8bde69c  push rdx
00007e6bc8bde69d  push rdi
00007e6bc8bde69e  push rsi
00007e6bc8bde69f  push r8
00007e6bc8bde6a1  push r9
00007e6bc8bde6a3  push r10
00007e6bc8bde6a5  push r11
00007e6bc8bde6a7  sub rsp, 0xF0
00007e6bc8bde6ae  vmovaps [rsp], xmm0
00007e6bc8bde6b3  vmovaps [rsp+0x10], xmm1
00007e6bc8bde6b9  vmovaps [rsp+0x20], xmm2
00007e6bc8bde6bf  vmovaps [rsp+0x30], xmm3
00007e6bc8bde6c5  vmovaps [rsp+0x40], xmm4
00007e6bc8bde6cb  vmovaps [rsp+0x50], xmm5
00007e6bc8bde6d1  vmovaps [rsp+0x60], xmm6
00007e6bc8bde6d7  vmovaps [rsp+0x70], xmm7
00007e6bc8bde6dd  vmovaps [rsp+0x80], xmm8
00007e6bc8bde6e6  vmovaps [rsp+0x90], xmm10
00007e6bc8bde6ef  vmovaps [rsp+0xA0], xmm11
00007e6bc8bde6f8  vmovaps [rsp+0xB0], xmm12
00007e6bc8bde701  vmovaps [rsp+0xC0], xmm13
00007e6bc8bde70a  vmovaps [rsp+0xD0], xmm14
00007e6bc8bde713  vmovaps [rsp+0xE0], xmm15
00007e6bc8bde71c  sub rsp, 0x30
00007e6bc8bde720  movaps [rsp], xmm9
00007e6bc8bde725  movaps [rsp+0x10], xmm3
00007e6bc8bde72a  movaps [rsp+0x20], xmm1
00007e6bc8bde72f  lea rdi, [rsp]
00007e6bc8bde733  mov esi, 0x00
00007e6bc8bde738  mov rax, 0x6543F191D530
00007e6bc8bde742  call rax
00007e6bc8bde744  movaps xmm9, [rsp]
00007e6bc8bde749  add rsp, 0x30
00007e6bc8bde74d  vmovaps xmm0, [rsp]
00007e6bc8bde752  vmovaps xmm1, [rsp+0x10]
00007e6bc8bde758  vmovaps xmm2, [rsp+0x20]
00007e6bc8bde75e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bde764  vmovaps xmm4, [rsp+0x40]
00007e6bc8bde76a  vmovaps xmm5, [rsp+0x50]
00007e6bc8bde770  vmovaps xmm6, [rsp+0x60]
00007e6bc8bde776  vmovaps xmm7, [rsp+0x70]
00007e6bc8bde77c  vmovaps xmm8, [rsp+0x80]
00007e6bc8bde785  vmovaps xmm10, [rsp+0x90]
00007e6bc8bde78e  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bde797  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bde7a0  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bde7a9  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bde7b2  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bde7bb  add rsp, 0xF0
00007e6bc8bde7c2  pop r11
00007e6bc8bde7c4  pop r10
00007e6bc8bde7c6  pop r9
00007e6bc8bde7c8  pop r8
00007e6bc8bde7ca  pop rsi
00007e6bc8bde7cb  pop rdi
00007e6bc8bde7cc  pop rdx
00007e6bc8bde7cd  pop rcx
00007e6bc8bde7ce  pop rax
00007e6bc8bde7cf  add rsp, 0x08
00007e6bc8bde7d3  jmp 0x00007E6BC8BDC1AA
00007e6bc8bde7d8  call 0x00007E6BC8AB52F0
00007e6bc8bde7dd  jmp 0x00007E6BC8BDC1B7
00007e6bc8bde7e2  sub rsp, 0x08
00007e6bc8bde7e6  push rax
00007e6bc8bde7e7  push rcx
00007e6bc8bde7e8  push rdx
00007e6bc8bde7e9  push rdi
00007e6bc8bde7ea  push rsi
00007e6bc8bde7eb  push r8
00007e6bc8bde7ed  push r9
00007e6bc8bde7ef  push r10
00007e6bc8bde7f1  push r11
00007e6bc8bde7f3  sub rsp, 0xF0
00007e6bc8bde7fa  vmovaps [rsp], xmm0
00007e6bc8bde7ff  vmovaps [rsp+0x10], xmm1
00007e6bc8bde805  vmovaps [rsp+0x20], xmm2
00007e6bc8bde80b  vmovaps [rsp+0x30], xmm3
00007e6bc8bde811  vmovaps [rsp+0x40], xmm4
00007e6bc8bde817  vmovaps [rsp+0x50], xmm5
00007e6bc8bde81d  vmovaps [rsp+0x60], xmm6
00007e6bc8bde823  vmovaps [rsp+0x70], xmm7
00007e6bc8bde829  vmovaps [rsp+0x80], xmm8
00007e6bc8bde832  vmovaps [rsp+0x90], xmm9
00007e6bc8bde83b  vmovaps [rsp+0xA0], xmm10
00007e6bc8bde844  vmovaps [rsp+0xB0], xmm11
00007e6bc8bde84d  vmovaps [rsp+0xC0], xmm12
00007e6bc8bde856  vmovaps [rsp+0xD0], xmm13
00007e6bc8bde85f  vmovaps [rsp+0xE0], xmm14
00007e6bc8bde868  sub rsp, 0x30
00007e6bc8bde86c  movaps [rsp], xmm15
00007e6bc8bde871  movaps [rsp+0x10], xmm3
00007e6bc8bde876  movaps [rsp+0x20], xmm7
00007e6bc8bde87b  lea rdi, [rsp]
00007e6bc8bde87f  mov esi, 0x00
00007e6bc8bde884  mov rax, 0x6543F191D530
00007e6bc8bde88e  call rax
00007e6bc8bde890  movaps xmm15, [rsp]
00007e6bc8bde895  add rsp, 0x30
00007e6bc8bde899  vmovaps xmm0, [rsp]
00007e6bc8bde89e  vmovaps xmm1, [rsp+0x10]
00007e6bc8bde8a4  vmovaps xmm2, [rsp+0x20]
00007e6bc8bde8aa  vmovaps xmm3, [rsp+0x30]
00007e6bc8bde8b0  vmovaps xmm4, [rsp+0x40]
00007e6bc8bde8b6  vmovaps xmm5, [rsp+0x50]
00007e6bc8bde8bc  vmovaps xmm6, [rsp+0x60]
00007e6bc8bde8c2  vmovaps xmm7, [rsp+0x70]
00007e6bc8bde8c8  vmovaps xmm8, [rsp+0x80]
00007e6bc8bde8d1  vmovaps xmm9, [rsp+0x90]
00007e6bc8bde8da  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bde8e3  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bde8ec  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bde8f5  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bde8fe  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bde907  add rsp, 0xF0
00007e6bc8bde90e  pop r11
00007e6bc8bde910  pop r10
00007e6bc8bde912  pop r9
00007e6bc8bde914  pop r8
00007e6bc8bde916  pop rsi
00007e6bc8bde917  pop rdi
00007e6bc8bde918  pop rdx
00007e6bc8bde919  pop rcx
00007e6bc8bde91a  pop rax
00007e6bc8bde91b  add rsp, 0x08
00007e6bc8bde91f  jmp 0x00007E6BC8BDC1E3
00007e6bc8bde924  sub rsp, 0x08
00007e6bc8bde928  push rax
00007e6bc8bde929  push rcx
00007e6bc8bde92a  push rdx
00007e6bc8bde92b  push rdi
00007e6bc8bde92c  push rsi
00007e6bc8bde92d  push r8
00007e6bc8bde92f  push r9
00007e6bc8bde931  push r10
00007e6bc8bde933  push r11
00007e6bc8bde935  sub rsp, 0xF0
00007e6bc8bde93c  vmovaps [rsp], xmm0
00007e6bc8bde941  vmovaps [rsp+0x10], xmm1
00007e6bc8bde947  vmovaps [rsp+0x20], xmm2
00007e6bc8bde94d  vmovaps [rsp+0x30], xmm4
00007e6bc8bde953  vmovaps [rsp+0x40], xmm5
00007e6bc8bde959  vmovaps [rsp+0x50], xmm6
00007e6bc8bde95f  vmovaps [rsp+0x60], xmm7
00007e6bc8bde965  vmovaps [rsp+0x70], xmm8
00007e6bc8bde96b  vmovaps [rsp+0x80], xmm9
00007e6bc8bde974  vmovaps [rsp+0x90], xmm10
00007e6bc8bde97d  vmovaps [rsp+0xA0], xmm11
00007e6bc8bde986  vmovaps [rsp+0xB0], xmm12
00007e6bc8bde98f  vmovaps [rsp+0xC0], xmm13
00007e6bc8bde998  vmovaps [rsp+0xD0], xmm14
00007e6bc8bde9a1  vmovaps [rsp+0xE0], xmm15
00007e6bc8bde9aa  sub rsp, 0x30
00007e6bc8bde9ae  movaps [rsp], xmm3
00007e6bc8bde9b2  movaps [rsp+0x10], xmm1
00007e6bc8bde9b7  movaps [rsp+0x20], xmm15
00007e6bc8bde9bd  lea rdi, [rsp]
00007e6bc8bde9c1  mov esi, 0x00
00007e6bc8bde9c6  mov rax, 0x6543F191D530
00007e6bc8bde9d0  call rax
00007e6bc8bde9d2  movaps xmm3, [rsp]
00007e6bc8bde9d6  add rsp, 0x30
00007e6bc8bde9da  vmovaps xmm0, [rsp]
00007e6bc8bde9df  vmovaps xmm1, [rsp+0x10]
00007e6bc8bde9e5  vmovaps xmm2, [rsp+0x20]
00007e6bc8bde9eb  vmovaps xmm4, [rsp+0x30]
00007e6bc8bde9f1  vmovaps xmm5, [rsp+0x40]
00007e6bc8bde9f7  vmovaps xmm6, [rsp+0x50]
00007e6bc8bde9fd  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdea03  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdea09  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdea12  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdea1b  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdea24  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdea2d  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdea36  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdea3f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdea48  add rsp, 0xF0
00007e6bc8bdea4f  pop r11
00007e6bc8bdea51  pop r10
00007e6bc8bdea53  pop r9
00007e6bc8bdea55  pop r8
00007e6bc8bdea57  pop rsi
00007e6bc8bdea58  pop rdi
00007e6bc8bdea59  pop rdx
00007e6bc8bdea5a  pop rcx
00007e6bc8bdea5b  pop rax
00007e6bc8bdea5c  add rsp, 0x08
00007e6bc8bdea60  jmp 0x00007E6BC8BDC272
00007e6bc8bdea65  call 0x00007E6BC8AB52F0
00007e6bc8bdea6a  jmp 0x00007E6BC8BDC27C
00007e6bc8bdea6f  sub rsp, 0x08
00007e6bc8bdea73  push rax
00007e6bc8bdea74  push rcx
00007e6bc8bdea75  push rdx
00007e6bc8bdea76  push rdi
00007e6bc8bdea77  push rsi
00007e6bc8bdea78  push r8
00007e6bc8bdea7a  push r9
00007e6bc8bdea7c  push r10
00007e6bc8bdea7e  push r11
00007e6bc8bdea80  sub rsp, 0xF0
00007e6bc8bdea87  vmovaps [rsp], xmm0
00007e6bc8bdea8c  vmovaps [rsp+0x10], xmm1
00007e6bc8bdea92  vmovaps [rsp+0x20], xmm2
00007e6bc8bdea98  vmovaps [rsp+0x30], xmm3
00007e6bc8bdea9e  vmovaps [rsp+0x40], xmm4
00007e6bc8bdeaa4  vmovaps [rsp+0x50], xmm5
00007e6bc8bdeaaa  vmovaps [rsp+0x60], xmm6
00007e6bc8bdeab0  vmovaps [rsp+0x70], xmm7
00007e6bc8bdeab6  vmovaps [rsp+0x80], xmm8
00007e6bc8bdeabf  vmovaps [rsp+0x90], xmm9
00007e6bc8bdeac8  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdead1  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdeada  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdeae3  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdeaec  vmovaps [rsp+0xE0], xmm14
00007e6bc8bdeaf5  sub rsp, 0x30
00007e6bc8bdeaf9  movaps [rsp], xmm15
00007e6bc8bdeafe  movaps [rsp+0x10], xmm14
00007e6bc8bdeb04  movaps [rsp+0x20], xmm4
00007e6bc8bdeb09  lea rdi, [rsp]
00007e6bc8bdeb0d  mov esi, 0x00
00007e6bc8bdeb12  mov rax, 0x6543F191D530
00007e6bc8bdeb1c  call rax
00007e6bc8bdeb1e  movaps xmm15, [rsp]
00007e6bc8bdeb23  add rsp, 0x30
00007e6bc8bdeb27  vmovaps xmm0, [rsp]
00007e6bc8bdeb2c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdeb32  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdeb38  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdeb3e  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdeb44  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdeb4a  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdeb50  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdeb56  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdeb5f  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdeb68  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdeb71  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdeb7a  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdeb83  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdeb8c  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bdeb95  add rsp, 0xF0
00007e6bc8bdeb9c  pop r11
00007e6bc8bdeb9e  pop r10
00007e6bc8bdeba0  pop r9
00007e6bc8bdeba2  pop r8
00007e6bc8bdeba4  pop rsi
00007e6bc8bdeba5  pop rdi
00007e6bc8bdeba6  pop rdx
00007e6bc8bdeba7  pop rcx
00007e6bc8bdeba8  pop rax
00007e6bc8bdeba9  add rsp, 0x08
00007e6bc8bdebad  jmp 0x00007E6BC8BDC2AA
00007e6bc8bdebb2  sub rsp, 0x08
00007e6bc8bdebb6  push rax
00007e6bc8bdebb7  push rcx
00007e6bc8bdebb8  push rdx
00007e6bc8bdebb9  push rdi
00007e6bc8bdebba  push rsi
00007e6bc8bdebbb  push r8
00007e6bc8bdebbd  push r9
00007e6bc8bdebbf  push r10
00007e6bc8bdebc1  push r11
00007e6bc8bdebc3  sub rsp, 0xF0
00007e6bc8bdebca  vmovaps [rsp], xmm0
00007e6bc8bdebcf  vmovaps [rsp+0x10], xmm1
00007e6bc8bdebd5  vmovaps [rsp+0x20], xmm2
00007e6bc8bdebdb  vmovaps [rsp+0x30], xmm3
00007e6bc8bdebe1  vmovaps [rsp+0x40], xmm4
00007e6bc8bdebe7  vmovaps [rsp+0x50], xmm5
00007e6bc8bdebed  vmovaps [rsp+0x60], xmm6
00007e6bc8bdebf3  vmovaps [rsp+0x70], xmm7
00007e6bc8bdebf9  vmovaps [rsp+0x80], xmm8
00007e6bc8bdec02  vmovaps [rsp+0x90], xmm9
00007e6bc8bdec0b  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdec14  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdec1d  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdec26  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdec2f  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdec38  sub rsp, 0x30
00007e6bc8bdec3c  movaps [rsp], xmm14
00007e6bc8bdec41  movaps [rsp+0x10], xmm2
00007e6bc8bdec46  movaps [rsp+0x20], xmm1
00007e6bc8bdec4b  lea rdi, [rsp]
00007e6bc8bdec4f  mov esi, 0x00
00007e6bc8bdec54  mov rax, 0x6543F191D530
00007e6bc8bdec5e  call rax
00007e6bc8bdec60  movaps xmm14, [rsp]
00007e6bc8bdec65  add rsp, 0x30
00007e6bc8bdec69  vmovaps xmm0, [rsp]
00007e6bc8bdec6e  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdec74  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdec7a  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdec80  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdec86  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdec8c  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdec92  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdec98  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdeca1  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdecaa  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdecb3  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdecbc  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdecc5  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdecce  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdecd7  add rsp, 0xF0
00007e6bc8bdecde  pop r11
00007e6bc8bdece0  pop r10
00007e6bc8bdece2  pop r9
00007e6bc8bdece4  pop r8
00007e6bc8bdece6  pop rsi
00007e6bc8bdece7  pop rdi
00007e6bc8bdece8  pop rdx
00007e6bc8bdece9  pop rcx
00007e6bc8bdecea  pop rax
00007e6bc8bdeceb  add rsp, 0x08
00007e6bc8bdecef  jmp 0x00007E6BC8BDC2D0
00007e6bc8bdecf4  sub rsp, 0x08
00007e6bc8bdecf8  push rax
00007e6bc8bdecf9  push rcx
00007e6bc8bdecfa  push rdx
00007e6bc8bdecfb  push rdi
00007e6bc8bdecfc  push rsi
00007e6bc8bdecfd  push r8
00007e6bc8bdecff  push r9
00007e6bc8bded01  push r10
00007e6bc8bded03  push r11
00007e6bc8bded05  sub rsp, 0xF0
00007e6bc8bded0c  vmovaps [rsp], xmm0
00007e6bc8bded11  vmovaps [rsp+0x10], xmm2
00007e6bc8bded17  vmovaps [rsp+0x20], xmm3
00007e6bc8bded1d  vmovaps [rsp+0x30], xmm4
00007e6bc8bded23  vmovaps [rsp+0x40], xmm5
00007e6bc8bded29  vmovaps [rsp+0x50], xmm6
00007e6bc8bded2f  vmovaps [rsp+0x60], xmm7
00007e6bc8bded35  vmovaps [rsp+0x70], xmm8
00007e6bc8bded3b  vmovaps [rsp+0x80], xmm9
00007e6bc8bded44  vmovaps [rsp+0x90], xmm10
00007e6bc8bded4d  vmovaps [rsp+0xA0], xmm11
00007e6bc8bded56  vmovaps [rsp+0xB0], xmm12
00007e6bc8bded5f  vmovaps [rsp+0xC0], xmm13
00007e6bc8bded68  vmovaps [rsp+0xD0], xmm14
00007e6bc8bded71  vmovaps [rsp+0xE0], xmm15
00007e6bc8bded7a  sub rsp, 0x30
00007e6bc8bded7e  movaps [rsp], xmm1
00007e6bc8bded82  movaps [rsp+0x10], xmm4
00007e6bc8bded87  movaps [rsp+0x20], xmm9
00007e6bc8bded8d  lea rdi, [rsp]
00007e6bc8bded91  mov esi, 0x00
00007e6bc8bded96  mov rax, 0x6543F191D530
00007e6bc8bdeda0  call rax
00007e6bc8bdeda2  movaps xmm1, [rsp]
00007e6bc8bdeda6  add rsp, 0x30
00007e6bc8bdedaa  vmovaps xmm0, [rsp]
00007e6bc8bdedaf  vmovaps xmm2, [rsp+0x10]
00007e6bc8bdedb5  vmovaps xmm3, [rsp+0x20]
00007e6bc8bdedbb  vmovaps xmm4, [rsp+0x30]
00007e6bc8bdedc1  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdedc7  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdedcd  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdedd3  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdedd9  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdede2  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdedeb  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdedf4  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdedfd  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdee06  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdee0f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdee18  add rsp, 0xF0
00007e6bc8bdee1f  pop r11
00007e6bc8bdee21  pop r10
00007e6bc8bdee23  pop r9
00007e6bc8bdee25  pop r8
00007e6bc8bdee27  pop rsi
00007e6bc8bdee28  pop rdi
00007e6bc8bdee29  pop rdx
00007e6bc8bdee2a  pop rcx
00007e6bc8bdee2b  pop rax
00007e6bc8bdee2c  add rsp, 0x08
00007e6bc8bdee30  jmp 0x00007E6BC8BDC2EE
00007e6bc8bdee35  sub rsp, 0x08
00007e6bc8bdee39  push rax
00007e6bc8bdee3a  push rcx
00007e6bc8bdee3b  push rdx
00007e6bc8bdee3c  push rdi
00007e6bc8bdee3d  push rsi
00007e6bc8bdee3e  push r8
00007e6bc8bdee40  push r9
00007e6bc8bdee42  push r10
00007e6bc8bdee44  push r11
00007e6bc8bdee46  sub rsp, 0xF0
00007e6bc8bdee4d  vmovaps [rsp], xmm0
00007e6bc8bdee52  vmovaps [rsp+0x10], xmm1
00007e6bc8bdee58  vmovaps [rsp+0x20], xmm2
00007e6bc8bdee5e  vmovaps [rsp+0x30], xmm3
00007e6bc8bdee64  vmovaps [rsp+0x40], xmm5
00007e6bc8bdee6a  vmovaps [rsp+0x50], xmm6
00007e6bc8bdee70  vmovaps [rsp+0x60], xmm7
00007e6bc8bdee76  vmovaps [rsp+0x70], xmm8
00007e6bc8bdee7c  vmovaps [rsp+0x80], xmm9
00007e6bc8bdee85  vmovaps [rsp+0x90], xmm10
00007e6bc8bdee8e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdee97  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdeea0  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdeea9  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdeeb2  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdeebb  sub rsp, 0x30
00007e6bc8bdeebf  movaps [rsp], xmm4
00007e6bc8bdeec3  movaps [rsp+0x10], xmm2
00007e6bc8bdeec8  movaps [rsp+0x20], xmm9
00007e6bc8bdeece  lea rdi, [rsp]
00007e6bc8bdeed2  mov esi, 0x00
00007e6bc8bdeed7  mov rax, 0x6543F191D530
00007e6bc8bdeee1  call rax
00007e6bc8bdeee3  movaps xmm4, [rsp]
00007e6bc8bdeee7  add rsp, 0x30
00007e6bc8bdeeeb  vmovaps xmm0, [rsp]
00007e6bc8bdeef0  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdeef6  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdeefc  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdef02  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdef08  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdef0e  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdef14  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdef1a  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdef23  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdef2c  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdef35  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdef3e  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdef47  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdef50  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdef59  add rsp, 0xF0
00007e6bc8bdef60  pop r11
00007e6bc8bdef62  pop r10
00007e6bc8bdef64  pop r9
00007e6bc8bdef66  pop r8
00007e6bc8bdef68  pop rsi
00007e6bc8bdef69  pop rdi
00007e6bc8bdef6a  pop rdx
00007e6bc8bdef6b  pop rcx
00007e6bc8bdef6c  pop rax
00007e6bc8bdef6d  add rsp, 0x08
00007e6bc8bdef71  jmp 0x00007E6BC8BDC31E
00007e6bc8bdef76  sub rsp, 0x08
00007e6bc8bdef7a  push rax
00007e6bc8bdef7b  push rcx
00007e6bc8bdef7c  push rdx
00007e6bc8bdef7d  push rdi
00007e6bc8bdef7e  push rsi
00007e6bc8bdef7f  push r8
00007e6bc8bdef81  push r9
00007e6bc8bdef83  push r10
00007e6bc8bdef85  push r11
00007e6bc8bdef87  sub rsp, 0xF0
00007e6bc8bdef8e  vmovaps [rsp], xmm0
00007e6bc8bdef93  vmovaps [rsp+0x10], xmm1
00007e6bc8bdef99  vmovaps [rsp+0x20], xmm2
00007e6bc8bdef9f  vmovaps [rsp+0x30], xmm3
00007e6bc8bdefa5  vmovaps [rsp+0x40], xmm4
00007e6bc8bdefab  vmovaps [rsp+0x50], xmm5
00007e6bc8bdefb1  vmovaps [rsp+0x60], xmm6
00007e6bc8bdefb7  vmovaps [rsp+0x70], xmm7
00007e6bc8bdefbd  vmovaps [rsp+0x80], xmm8
00007e6bc8bdefc6  vmovaps [rsp+0x90], xmm10
00007e6bc8bdefcf  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdefd8  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdefe1  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdefea  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdeff3  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdeffc  sub rsp, 0x30
00007e6bc8bdf000  movaps [rsp], xmm9
00007e6bc8bdf005  movaps [rsp+0x10], xmm2
00007e6bc8bdf00a  movaps [rsp+0x20], xmm1
00007e6bc8bdf00f  lea rdi, [rsp]
00007e6bc8bdf013  mov esi, 0x00
00007e6bc8bdf018  mov rax, 0x6543F191D530
00007e6bc8bdf022  call rax
00007e6bc8bdf024  movaps xmm9, [rsp]
00007e6bc8bdf029  add rsp, 0x30
00007e6bc8bdf02d  vmovaps xmm0, [rsp]
00007e6bc8bdf032  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdf038  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdf03e  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdf044  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdf04a  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdf050  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdf056  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdf05c  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdf065  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdf06e  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdf077  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdf080  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdf089  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdf092  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdf09b  add rsp, 0xF0
00007e6bc8bdf0a2  pop r11
00007e6bc8bdf0a4  pop r10
00007e6bc8bdf0a6  pop r9
00007e6bc8bdf0a8  pop r8
00007e6bc8bdf0aa  pop rsi
00007e6bc8bdf0ab  pop rdi
00007e6bc8bdf0ac  pop rdx
00007e6bc8bdf0ad  pop rcx
00007e6bc8bdf0ae  pop rax
00007e6bc8bdf0af  add rsp, 0x08
00007e6bc8bdf0b3  jmp 0x00007E6BC8BDC354
00007e6bc8bdf0b8  sub rsp, 0x08
00007e6bc8bdf0bc  push rax
00007e6bc8bdf0bd  push rcx
00007e6bc8bdf0be  push rdx
00007e6bc8bdf0bf  push rdi
00007e6bc8bdf0c0  push rsi
00007e6bc8bdf0c1  push r8
00007e6bc8bdf0c3  push r9
00007e6bc8bdf0c5  push r10
00007e6bc8bdf0c7  push r11
00007e6bc8bdf0c9  sub rsp, 0xF0
00007e6bc8bdf0d0  vmovaps [rsp], xmm0
00007e6bc8bdf0d5  vmovaps [rsp+0x10], xmm2
00007e6bc8bdf0db  vmovaps [rsp+0x20], xmm3
00007e6bc8bdf0e1  vmovaps [rsp+0x30], xmm4
00007e6bc8bdf0e7  vmovaps [rsp+0x40], xmm5
00007e6bc8bdf0ed  vmovaps [rsp+0x50], xmm6
00007e6bc8bdf0f3  vmovaps [rsp+0x60], xmm7
00007e6bc8bdf0f9  vmovaps [rsp+0x70], xmm8
00007e6bc8bdf0ff  vmovaps [rsp+0x80], xmm9
00007e6bc8bdf108  vmovaps [rsp+0x90], xmm10
00007e6bc8bdf111  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdf11a  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdf123  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdf12c  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdf135  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdf13e  sub rsp, 0x30
00007e6bc8bdf142  movaps [rsp], xmm1
00007e6bc8bdf146  movaps [rsp+0x10], xmm15
00007e6bc8bdf14c  movaps [rsp+0x20], xmm6
00007e6bc8bdf151  lea rdi, [rsp]
00007e6bc8bdf155  mov esi, 0x00
00007e6bc8bdf15a  mov rax, 0x6543F191D530
00007e6bc8bdf164  call rax
00007e6bc8bdf166  movaps xmm1, [rsp]
00007e6bc8bdf16a  add rsp, 0x30
00007e6bc8bdf16e  vmovaps xmm0, [rsp]
00007e6bc8bdf173  vmovaps xmm2, [rsp+0x10]
00007e6bc8bdf179  vmovaps xmm3, [rsp+0x20]
00007e6bc8bdf17f  vmovaps xmm4, [rsp+0x30]
00007e6bc8bdf185  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdf18b  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdf191  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdf197  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdf19d  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdf1a6  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdf1af  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdf1b8  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdf1c1  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdf1ca  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdf1d3  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdf1dc  add rsp, 0xF0
00007e6bc8bdf1e3  pop r11
00007e6bc8bdf1e5  pop r10
00007e6bc8bdf1e7  pop r9
00007e6bc8bdf1e9  pop r8
00007e6bc8bdf1eb  pop rsi
00007e6bc8bdf1ec  pop rdi
00007e6bc8bdf1ed  pop rdx
00007e6bc8bdf1ee  pop rcx
00007e6bc8bdf1ef  pop rax
00007e6bc8bdf1f0  add rsp, 0x08
00007e6bc8bdf1f4  jmp 0x00007E6BC8BDC375
00007e6bc8bdf1f9  sub rsp, 0x08
00007e6bc8bdf1fd  push rax
00007e6bc8bdf1fe  push rcx
00007e6bc8bdf1ff  push rdx
00007e6bc8bdf200  push rdi
00007e6bc8bdf201  push rsi
00007e6bc8bdf202  push r8
00007e6bc8bdf204  push r9
00007e6bc8bdf206  push r10
00007e6bc8bdf208  push r11
00007e6bc8bdf20a  sub rsp, 0xF0
00007e6bc8bdf211  vmovaps [rsp], xmm0
00007e6bc8bdf216  vmovaps [rsp+0x10], xmm1
00007e6bc8bdf21c  vmovaps [rsp+0x20], xmm2
00007e6bc8bdf222  vmovaps [rsp+0x30], xmm3
00007e6bc8bdf228  vmovaps [rsp+0x40], xmm4
00007e6bc8bdf22e  vmovaps [rsp+0x50], xmm5
00007e6bc8bdf234  vmovaps [rsp+0x60], xmm6
00007e6bc8bdf23a  vmovaps [rsp+0x70], xmm7
00007e6bc8bdf240  vmovaps [rsp+0x80], xmm8
00007e6bc8bdf249  vmovaps [rsp+0x90], xmm9
00007e6bc8bdf252  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdf25b  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdf264  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdf26d  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdf276  vmovaps [rsp+0xE0], xmm14
00007e6bc8bdf27f  sub rsp, 0x30
00007e6bc8bdf283  movaps [rsp], xmm15
00007e6bc8bdf288  movaps [rsp+0x10], xmm5
00007e6bc8bdf28d  movaps [rsp+0x20], xmm3
00007e6bc8bdf292  lea rdi, [rsp]
00007e6bc8bdf296  mov esi, 0x00
00007e6bc8bdf29b  mov rax, 0x6543F191D530
00007e6bc8bdf2a5  call rax
00007e6bc8bdf2a7  movaps xmm15, [rsp]
00007e6bc8bdf2ac  add rsp, 0x30
00007e6bc8bdf2b0  vmovaps xmm0, [rsp]
00007e6bc8bdf2b5  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdf2bb  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdf2c1  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdf2c7  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdf2cd  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdf2d3  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdf2d9  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdf2df  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdf2e8  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdf2f1  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdf2fa  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdf303  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdf30c  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdf315  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bdf31e  add rsp, 0xF0
00007e6bc8bdf325  pop r11
00007e6bc8bdf327  pop r10
00007e6bc8bdf329  pop r9
00007e6bc8bdf32b  pop r8
00007e6bc8bdf32d  pop rsi
00007e6bc8bdf32e  pop rdi
00007e6bc8bdf32f  pop rdx
00007e6bc8bdf330  pop rcx
00007e6bc8bdf331  pop rax
00007e6bc8bdf332  add rsp, 0x08
00007e6bc8bdf336  jmp 0x00007E6BC8BDC38F
00007e6bc8bdf33b  sub rsp, 0x08
00007e6bc8bdf33f  push rax
00007e6bc8bdf340  push rcx
00007e6bc8bdf341  push rdx
00007e6bc8bdf342  push rdi
00007e6bc8bdf343  push rsi
00007e6bc8bdf344  push r8
00007e6bc8bdf346  push r9
00007e6bc8bdf348  push r10
00007e6bc8bdf34a  push r11
00007e6bc8bdf34c  sub rsp, 0xF0
00007e6bc8bdf353  vmovaps [rsp], xmm0
00007e6bc8bdf358  vmovaps [rsp+0x10], xmm1
00007e6bc8bdf35e  vmovaps [rsp+0x20], xmm2
00007e6bc8bdf364  vmovaps [rsp+0x30], xmm3
00007e6bc8bdf36a  vmovaps [rsp+0x40], xmm4
00007e6bc8bdf370  vmovaps [rsp+0x50], xmm6
00007e6bc8bdf376  vmovaps [rsp+0x60], xmm7
00007e6bc8bdf37c  vmovaps [rsp+0x70], xmm8
00007e6bc8bdf382  vmovaps [rsp+0x80], xmm9
00007e6bc8bdf38b  vmovaps [rsp+0x90], xmm10
00007e6bc8bdf394  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdf39d  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdf3a6  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdf3af  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdf3b8  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdf3c1  sub rsp, 0x30
00007e6bc8bdf3c5  movaps [rsp], xmm5
00007e6bc8bdf3c9  movaps [rsp+0x10], xmm8
00007e6bc8bdf3cf  movaps [rsp+0x20], xmm6
00007e6bc8bdf3d4  lea rdi, [rsp]
00007e6bc8bdf3d8  mov esi, 0x00
00007e6bc8bdf3dd  mov rax, 0x6543F191D530
00007e6bc8bdf3e7  call rax
00007e6bc8bdf3e9  movaps xmm5, [rsp]
00007e6bc8bdf3ed  add rsp, 0x30
00007e6bc8bdf3f1  vmovaps xmm0, [rsp]
00007e6bc8bdf3f6  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdf3fc  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdf402  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdf408  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdf40e  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdf414  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdf41a  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdf420  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdf429  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdf432  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdf43b  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdf444  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdf44d  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdf456  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdf45f  add rsp, 0xF0
00007e6bc8bdf466  pop r11
00007e6bc8bdf468  pop r10
00007e6bc8bdf46a  pop r9
00007e6bc8bdf46c  pop r8
00007e6bc8bdf46e  pop rsi
00007e6bc8bdf46f  pop rdi
00007e6bc8bdf470  pop rdx
00007e6bc8bdf471  pop rcx
00007e6bc8bdf472  pop rax
00007e6bc8bdf473  add rsp, 0x08
00007e6bc8bdf477  jmp 0x00007E6BC8BDC3B3
00007e6bc8bdf47c  sub rsp, 0x08
00007e6bc8bdf480  push rax
00007e6bc8bdf481  push rcx
00007e6bc8bdf482  push rdx
00007e6bc8bdf483  push rdi
00007e6bc8bdf484  push rsi
00007e6bc8bdf485  push r8
00007e6bc8bdf487  push r9
00007e6bc8bdf489  push r10
00007e6bc8bdf48b  push r11
00007e6bc8bdf48d  sub rsp, 0xF0
00007e6bc8bdf494  vmovaps [rsp], xmm0
00007e6bc8bdf499  vmovaps [rsp+0x10], xmm1
00007e6bc8bdf49f  vmovaps [rsp+0x20], xmm2
00007e6bc8bdf4a5  vmovaps [rsp+0x30], xmm3
00007e6bc8bdf4ab  vmovaps [rsp+0x40], xmm4
00007e6bc8bdf4b1  vmovaps [rsp+0x50], xmm5
00007e6bc8bdf4b7  vmovaps [rsp+0x60], xmm7
00007e6bc8bdf4bd  vmovaps [rsp+0x70], xmm8
00007e6bc8bdf4c3  vmovaps [rsp+0x80], xmm9
00007e6bc8bdf4cc  vmovaps [rsp+0x90], xmm10
00007e6bc8bdf4d5  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdf4de  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdf4e7  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdf4f0  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdf4f9  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdf502  sub rsp, 0x30
00007e6bc8bdf506  movaps [rsp], xmm6
00007e6bc8bdf50a  movaps [rsp+0x10], xmm10
00007e6bc8bdf510  movaps [rsp+0x20], xmm8
00007e6bc8bdf516  lea rdi, [rsp]
00007e6bc8bdf51a  mov esi, 0x00
00007e6bc8bdf51f  mov rax, 0x6543F191D530
00007e6bc8bdf529  call rax
00007e6bc8bdf52b  movaps xmm6, [rsp]
00007e6bc8bdf52f  add rsp, 0x30
00007e6bc8bdf533  vmovaps xmm0, [rsp]
00007e6bc8bdf538  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdf53e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdf544  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdf54a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdf550  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdf556  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdf55c  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdf562  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdf56b  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdf574  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdf57d  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdf586  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdf58f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdf598  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdf5a1  add rsp, 0xF0
00007e6bc8bdf5a8  pop r11
00007e6bc8bdf5aa  pop r10
00007e6bc8bdf5ac  pop r9
00007e6bc8bdf5ae  pop r8
00007e6bc8bdf5b0  pop rsi
00007e6bc8bdf5b1  pop rdi
00007e6bc8bdf5b2  pop rdx
00007e6bc8bdf5b3  pop rcx
00007e6bc8bdf5b4  pop rax
00007e6bc8bdf5b5  add rsp, 0x08
00007e6bc8bdf5b9  jmp 0x00007E6BC8BDC3D8
00007e6bc8bdf5be  sub rsp, 0x08
00007e6bc8bdf5c2  push rax
00007e6bc8bdf5c3  push rcx
00007e6bc8bdf5c4  push rdx
00007e6bc8bdf5c5  push rdi
00007e6bc8bdf5c6  push rsi
00007e6bc8bdf5c7  push r8
00007e6bc8bdf5c9  push r9
00007e6bc8bdf5cb  push r10
00007e6bc8bdf5cd  push r11
00007e6bc8bdf5cf  sub rsp, 0xF0
00007e6bc8bdf5d6  vmovaps [rsp], xmm0
00007e6bc8bdf5db  vmovaps [rsp+0x10], xmm1
00007e6bc8bdf5e1  vmovaps [rsp+0x20], xmm2
00007e6bc8bdf5e7  vmovaps [rsp+0x30], xmm3
00007e6bc8bdf5ed  vmovaps [rsp+0x40], xmm4
00007e6bc8bdf5f3  vmovaps [rsp+0x50], xmm5
00007e6bc8bdf5f9  vmovaps [rsp+0x60], xmm6
00007e6bc8bdf5ff  vmovaps [rsp+0x70], xmm7
00007e6bc8bdf605  vmovaps [rsp+0x80], xmm8
00007e6bc8bdf60e  vmovaps [rsp+0x90], xmm9
00007e6bc8bdf617  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdf620  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdf629  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdf632  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdf63b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdf644  sub rsp, 0x30
00007e6bc8bdf648  movaps [rsp], xmm10
00007e6bc8bdf64d  movaps [rsp+0x10], xmm8
00007e6bc8bdf653  movaps [rsp+0x20], xmm14
00007e6bc8bdf659  lea rdi, [rsp]
00007e6bc8bdf65d  mov esi, 0x00
00007e6bc8bdf662  mov rax, 0x6543F191D530
00007e6bc8bdf66c  call rax
00007e6bc8bdf66e  movaps xmm10, [rsp]
00007e6bc8bdf673  add rsp, 0x30
00007e6bc8bdf677  vmovaps xmm0, [rsp]
00007e6bc8bdf67c  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdf682  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdf688  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdf68e  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdf694  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdf69a  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdf6a0  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdf6a6  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdf6af  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdf6b8  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdf6c1  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdf6ca  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdf6d3  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdf6dc  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdf6e5  add rsp, 0xF0
00007e6bc8bdf6ec  pop r11
00007e6bc8bdf6ee  pop r10
00007e6bc8bdf6f0  pop r9
00007e6bc8bdf6f2  pop r8
00007e6bc8bdf6f4  pop rsi
00007e6bc8bdf6f5  pop rdi
00007e6bc8bdf6f6  pop rdx
00007e6bc8bdf6f7  pop rcx
00007e6bc8bdf6f8  pop rax
00007e6bc8bdf6f9  add rsp, 0x08
00007e6bc8bdf6fd  jmp 0x00007E6BC8BDC3F8
00007e6bc8bdf702  sub rsp, 0x08
00007e6bc8bdf706  push rax
00007e6bc8bdf707  push rcx
00007e6bc8bdf708  push rdx
00007e6bc8bdf709  push rdi
00007e6bc8bdf70a  push rsi
00007e6bc8bdf70b  push r8
00007e6bc8bdf70d  push r9
00007e6bc8bdf70f  push r10
00007e6bc8bdf711  push r11
00007e6bc8bdf713  sub rsp, 0xF0
00007e6bc8bdf71a  vmovaps [rsp], xmm0
00007e6bc8bdf71f  vmovaps [rsp+0x10], xmm1
00007e6bc8bdf725  vmovaps [rsp+0x20], xmm2
00007e6bc8bdf72b  vmovaps [rsp+0x30], xmm3
00007e6bc8bdf731  vmovaps [rsp+0x40], xmm4
00007e6bc8bdf737  vmovaps [rsp+0x50], xmm5
00007e6bc8bdf73d  vmovaps [rsp+0x60], xmm6
00007e6bc8bdf743  vmovaps [rsp+0x70], xmm7
00007e6bc8bdf749  vmovaps [rsp+0x80], xmm8
00007e6bc8bdf752  vmovaps [rsp+0x90], xmm9
00007e6bc8bdf75b  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdf764  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdf76d  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdf776  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdf77f  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdf788  sub rsp, 0x30
00007e6bc8bdf78c  movaps [rsp], xmm14
00007e6bc8bdf791  movaps [rsp+0x10], xmm8
00007e6bc8bdf797  movaps [rsp+0x20], xmm4
00007e6bc8bdf79c  lea rdi, [rsp]
00007e6bc8bdf7a0  mov esi, 0x00
00007e6bc8bdf7a5  mov rax, 0x6543F191D530
00007e6bc8bdf7af  call rax
00007e6bc8bdf7b1  movaps xmm14, [rsp]
00007e6bc8bdf7b6  add rsp, 0x30
00007e6bc8bdf7ba  vmovaps xmm0, [rsp]
00007e6bc8bdf7bf  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdf7c5  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdf7cb  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdf7d1  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdf7d7  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdf7dd  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdf7e3  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdf7e9  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdf7f2  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdf7fb  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdf804  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdf80d  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdf816  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdf81f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdf828  add rsp, 0xF0
00007e6bc8bdf82f  pop r11
00007e6bc8bdf831  pop r10
00007e6bc8bdf833  pop r9
00007e6bc8bdf835  pop r8
00007e6bc8bdf837  pop rsi
00007e6bc8bdf838  pop rdi
00007e6bc8bdf839  pop rdx
00007e6bc8bdf83a  pop rcx
00007e6bc8bdf83b  pop rax
00007e6bc8bdf83c  add rsp, 0x08
00007e6bc8bdf840  jmp 0x00007E6BC8BDC418
00007e6bc8bdf845  sub rsp, 0x08
00007e6bc8bdf849  push rax
00007e6bc8bdf84a  push rcx
00007e6bc8bdf84b  push rdx
00007e6bc8bdf84c  push rdi
00007e6bc8bdf84d  push rsi
00007e6bc8bdf84e  push r8
00007e6bc8bdf850  push r9
00007e6bc8bdf852  push r10
00007e6bc8bdf854  push r11
00007e6bc8bdf856  sub rsp, 0xF0
00007e6bc8bdf85d  vmovaps [rsp], xmm0
00007e6bc8bdf862  vmovaps [rsp+0x10], xmm1
00007e6bc8bdf868  vmovaps [rsp+0x20], xmm2
00007e6bc8bdf86e  vmovaps [rsp+0x30], xmm3
00007e6bc8bdf874  vmovaps [rsp+0x40], xmm5
00007e6bc8bdf87a  vmovaps [rsp+0x50], xmm6
00007e6bc8bdf880  vmovaps [rsp+0x60], xmm7
00007e6bc8bdf886  vmovaps [rsp+0x70], xmm8
00007e6bc8bdf88c  vmovaps [rsp+0x80], xmm9
00007e6bc8bdf895  vmovaps [rsp+0x90], xmm10
00007e6bc8bdf89e  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdf8a7  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdf8b0  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdf8b9  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdf8c2  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdf8cb  sub rsp, 0x30
00007e6bc8bdf8cf  movaps [rsp], xmm4
00007e6bc8bdf8d3  movaps [rsp+0x10], xmm13
00007e6bc8bdf8d9  movaps [rsp+0x20], xmm8
00007e6bc8bdf8df  lea rdi, [rsp]
00007e6bc8bdf8e3  mov esi, 0x00
00007e6bc8bdf8e8  mov rax, 0x6543F191D530
00007e6bc8bdf8f2  call rax
00007e6bc8bdf8f4  movaps xmm4, [rsp]
00007e6bc8bdf8f8  add rsp, 0x30
00007e6bc8bdf8fc  vmovaps xmm0, [rsp]
00007e6bc8bdf901  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdf907  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdf90d  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdf913  vmovaps xmm5, [rsp+0x40]
00007e6bc8bdf919  vmovaps xmm6, [rsp+0x50]
00007e6bc8bdf91f  vmovaps xmm7, [rsp+0x60]
00007e6bc8bdf925  vmovaps xmm8, [rsp+0x70]
00007e6bc8bdf92b  vmovaps xmm9, [rsp+0x80]
00007e6bc8bdf934  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdf93d  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdf946  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdf94f  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdf958  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdf961  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdf96a  add rsp, 0xF0
00007e6bc8bdf971  pop r11
00007e6bc8bdf973  pop r10
00007e6bc8bdf975  pop r9
00007e6bc8bdf977  pop r8
00007e6bc8bdf979  pop rsi
00007e6bc8bdf97a  pop rdi
00007e6bc8bdf97b  pop rdx
00007e6bc8bdf97c  pop rcx
00007e6bc8bdf97d  pop rax
00007e6bc8bdf97e  add rsp, 0x08
00007e6bc8bdf982  jmp 0x00007E6BC8BDC43D
00007e6bc8bdf987  sub rsp, 0x08
00007e6bc8bdf98b  push rax
00007e6bc8bdf98c  push rcx
00007e6bc8bdf98d  push rdx
00007e6bc8bdf98e  push rdi
00007e6bc8bdf98f  push rsi
00007e6bc8bdf990  push r8
00007e6bc8bdf992  push r9
00007e6bc8bdf994  push r10
00007e6bc8bdf996  push r11
00007e6bc8bdf998  sub rsp, 0xF0
00007e6bc8bdf99f  vmovaps [rsp], xmm0
00007e6bc8bdf9a4  vmovaps [rsp+0x10], xmm1
00007e6bc8bdf9aa  vmovaps [rsp+0x20], xmm2
00007e6bc8bdf9b0  vmovaps [rsp+0x30], xmm3
00007e6bc8bdf9b6  vmovaps [rsp+0x40], xmm4
00007e6bc8bdf9bc  vmovaps [rsp+0x50], xmm5
00007e6bc8bdf9c2  vmovaps [rsp+0x60], xmm6
00007e6bc8bdf9c8  vmovaps [rsp+0x70], xmm7
00007e6bc8bdf9ce  vmovaps [rsp+0x80], xmm8
00007e6bc8bdf9d7  vmovaps [rsp+0x90], xmm9
00007e6bc8bdf9e0  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdf9e9  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdf9f2  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdf9fb  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdfa04  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdfa0d  sub rsp, 0x30
00007e6bc8bdfa11  movaps [rsp], xmm13
00007e6bc8bdfa16  movaps [rsp+0x10], xmm15
00007e6bc8bdfa1c  movaps [rsp+0x20], xmm9
00007e6bc8bdfa22  lea rdi, [rsp]
00007e6bc8bdfa26  mov esi, 0x00
00007e6bc8bdfa2b  mov rax, 0x6543F191D530
00007e6bc8bdfa35  call rax
00007e6bc8bdfa37  movaps xmm13, [rsp]
00007e6bc8bdfa3c  add rsp, 0x30
00007e6bc8bdfa40  vmovaps xmm0, [rsp]
00007e6bc8bdfa45  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdfa4b  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdfa51  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdfa57  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdfa5d  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdfa63  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdfa69  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdfa6f  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdfa78  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdfa81  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdfa8a  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdfa93  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdfa9c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdfaa5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdfaae  add rsp, 0xF0
00007e6bc8bdfab5  pop r11
00007e6bc8bdfab7  pop r10
00007e6bc8bdfab9  pop r9
00007e6bc8bdfabb  pop r8
00007e6bc8bdfabd  pop rsi
00007e6bc8bdfabe  pop rdi
00007e6bc8bdfabf  pop rdx
00007e6bc8bdfac0  pop rcx
00007e6bc8bdfac1  pop rax
00007e6bc8bdfac2  add rsp, 0x08
00007e6bc8bdfac6  jmp 0x00007E6BC8BDC458
00007e6bc8bdfacb  sub rsp, 0x08
00007e6bc8bdfacf  push rax
00007e6bc8bdfad0  push rcx
00007e6bc8bdfad1  push rdx
00007e6bc8bdfad2  push rdi
00007e6bc8bdfad3  push rsi
00007e6bc8bdfad4  push r8
00007e6bc8bdfad6  push r9
00007e6bc8bdfad8  push r10
00007e6bc8bdfada  push r11
00007e6bc8bdfadc  sub rsp, 0xF0
00007e6bc8bdfae3  vmovaps [rsp], xmm0
00007e6bc8bdfae8  vmovaps [rsp+0x10], xmm1
00007e6bc8bdfaee  vmovaps [rsp+0x20], xmm2
00007e6bc8bdfaf4  vmovaps [rsp+0x30], xmm3
00007e6bc8bdfafa  vmovaps [rsp+0x40], xmm4
00007e6bc8bdfb00  vmovaps [rsp+0x50], xmm5
00007e6bc8bdfb06  vmovaps [rsp+0x60], xmm6
00007e6bc8bdfb0c  vmovaps [rsp+0x70], xmm7
00007e6bc8bdfb12  vmovaps [rsp+0x80], xmm8
00007e6bc8bdfb1b  vmovaps [rsp+0x90], xmm9
00007e6bc8bdfb24  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdfb2d  vmovaps [rsp+0xB0], xmm11
00007e6bc8bdfb36  vmovaps [rsp+0xC0], xmm12
00007e6bc8bdfb3f  vmovaps [rsp+0xD0], xmm13
00007e6bc8bdfb48  vmovaps [rsp+0xE0], xmm14
00007e6bc8bdfb51  sub rsp, 0x30
00007e6bc8bdfb55  movaps [rsp], xmm15
00007e6bc8bdfb5a  movaps [rsp+0x10], xmm1
00007e6bc8bdfb5f  movaps [rsp+0x20], xmm5
00007e6bc8bdfb64  lea rdi, [rsp]
00007e6bc8bdfb68  mov esi, 0x00
00007e6bc8bdfb6d  mov rax, 0x6543F191D530
00007e6bc8bdfb77  call rax
00007e6bc8bdfb79  movaps xmm15, [rsp]
00007e6bc8bdfb7e  add rsp, 0x30
00007e6bc8bdfb82  vmovaps xmm0, [rsp]
00007e6bc8bdfb87  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdfb8d  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdfb93  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdfb99  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdfb9f  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdfba5  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdfbab  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdfbb1  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdfbba  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdfbc3  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdfbcc  vmovaps xmm11, [rsp+0xB0]
00007e6bc8bdfbd5  vmovaps xmm12, [rsp+0xC0]
00007e6bc8bdfbde  vmovaps xmm13, [rsp+0xD0]
00007e6bc8bdfbe7  vmovaps xmm14, [rsp+0xE0]
00007e6bc8bdfbf0  add rsp, 0xF0
00007e6bc8bdfbf7  pop r11
00007e6bc8bdfbf9  pop r10
00007e6bc8bdfbfb  pop r9
00007e6bc8bdfbfd  pop r8
00007e6bc8bdfbff  pop rsi
00007e6bc8bdfc00  pop rdi
00007e6bc8bdfc01  pop rdx
00007e6bc8bdfc02  pop rcx
00007e6bc8bdfc03  pop rax
00007e6bc8bdfc04  add rsp, 0x08
00007e6bc8bdfc08  jmp 0x00007E6BC8BDC473
00007e6bc8bdfc0d  call 0x00007E6BC8AB52F0
00007e6bc8bdfc12  jmp 0x00007E6BC8BDC4CE
00007e6bc8bdfc17  sub rsp, 0x08
00007e6bc8bdfc1b  push rax
00007e6bc8bdfc1c  push rcx
00007e6bc8bdfc1d  push rdx
00007e6bc8bdfc1e  push rdi
00007e6bc8bdfc1f  push rsi
00007e6bc8bdfc20  push r8
00007e6bc8bdfc22  push r9
00007e6bc8bdfc24  push r10
00007e6bc8bdfc26  push r11
00007e6bc8bdfc28  sub rsp, 0xF0
00007e6bc8bdfc2f  vmovaps [rsp], xmm0
00007e6bc8bdfc34  vmovaps [rsp+0x10], xmm1
00007e6bc8bdfc3a  vmovaps [rsp+0x20], xmm2
00007e6bc8bdfc40  vmovaps [rsp+0x30], xmm3
00007e6bc8bdfc46  vmovaps [rsp+0x40], xmm4
00007e6bc8bdfc4c  vmovaps [rsp+0x50], xmm5
00007e6bc8bdfc52  vmovaps [rsp+0x60], xmm6
00007e6bc8bdfc58  vmovaps [rsp+0x70], xmm7
00007e6bc8bdfc5e  vmovaps [rsp+0x80], xmm8
00007e6bc8bdfc67  vmovaps [rsp+0x90], xmm10
00007e6bc8bdfc70  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdfc79  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdfc82  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdfc8b  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdfc94  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdfc9d  sub rsp, 0x30
00007e6bc8bdfca1  movaps [rsp], xmm9
00007e6bc8bdfca6  movaps [rsp+0x10], xmm8
00007e6bc8bdfcac  movaps [rsp+0x20], xmm11
00007e6bc8bdfcb2  lea rdi, [rsp]
00007e6bc8bdfcb6  mov esi, 0x00
00007e6bc8bdfcbb  mov rax, 0x6543F191D530
00007e6bc8bdfcc5  call rax
00007e6bc8bdfcc7  movaps xmm9, [rsp]
00007e6bc8bdfccc  add rsp, 0x30
00007e6bc8bdfcd0  vmovaps xmm0, [rsp]
00007e6bc8bdfcd5  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdfcdb  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdfce1  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdfce7  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdfced  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdfcf3  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdfcf9  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdfcff  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdfd08  vmovaps xmm10, [rsp+0x90]
00007e6bc8bdfd11  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdfd1a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdfd23  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdfd2c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdfd35  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdfd3e  add rsp, 0xF0
00007e6bc8bdfd45  pop r11
00007e6bc8bdfd47  pop r10
00007e6bc8bdfd49  pop r9
00007e6bc8bdfd4b  pop r8
00007e6bc8bdfd4d  pop rsi
00007e6bc8bdfd4e  pop rdi
00007e6bc8bdfd4f  pop rdx
00007e6bc8bdfd50  pop rcx
00007e6bc8bdfd51  pop rax
00007e6bc8bdfd52  add rsp, 0x08
00007e6bc8bdfd56  jmp 0x00007E6BC8BDC505
00007e6bc8bdfd5b  sub rsp, 0x08
00007e6bc8bdfd5f  push rax
00007e6bc8bdfd60  push rcx
00007e6bc8bdfd61  push rdx
00007e6bc8bdfd62  push rdi
00007e6bc8bdfd63  push rsi
00007e6bc8bdfd64  push r8
00007e6bc8bdfd66  push r9
00007e6bc8bdfd68  push r10
00007e6bc8bdfd6a  push r11
00007e6bc8bdfd6c  sub rsp, 0xF0
00007e6bc8bdfd73  vmovaps [rsp], xmm0
00007e6bc8bdfd78  vmovaps [rsp+0x10], xmm1
00007e6bc8bdfd7e  vmovaps [rsp+0x20], xmm2
00007e6bc8bdfd84  vmovaps [rsp+0x30], xmm3
00007e6bc8bdfd8a  vmovaps [rsp+0x40], xmm4
00007e6bc8bdfd90  vmovaps [rsp+0x50], xmm5
00007e6bc8bdfd96  vmovaps [rsp+0x60], xmm6
00007e6bc8bdfd9c  vmovaps [rsp+0x70], xmm7
00007e6bc8bdfda2  vmovaps [rsp+0x80], xmm8
00007e6bc8bdfdab  vmovaps [rsp+0x90], xmm9
00007e6bc8bdfdb4  vmovaps [rsp+0xA0], xmm10
00007e6bc8bdfdbd  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdfdc6  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdfdcf  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdfdd8  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdfde1  sub rsp, 0x30
00007e6bc8bdfde5  movaps [rsp], xmm11
00007e6bc8bdfdea  movaps [rsp+0x10], xmm10
00007e6bc8bdfdf0  movaps [rsp+0x20], xmm6
00007e6bc8bdfdf5  lea rdi, [rsp]
00007e6bc8bdfdf9  mov esi, 0x00
00007e6bc8bdfdfe  mov rax, 0x6543F191D530
00007e6bc8bdfe08  call rax
00007e6bc8bdfe0a  movaps xmm11, [rsp]
00007e6bc8bdfe0f  add rsp, 0x30
00007e6bc8bdfe13  vmovaps xmm0, [rsp]
00007e6bc8bdfe18  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdfe1e  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdfe24  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdfe2a  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdfe30  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdfe36  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdfe3c  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdfe42  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdfe4b  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdfe54  vmovaps xmm10, [rsp+0xA0]
00007e6bc8bdfe5d  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdfe66  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdfe6f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdfe78  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdfe81  add rsp, 0xF0
00007e6bc8bdfe88  pop r11
00007e6bc8bdfe8a  pop r10
00007e6bc8bdfe8c  pop r9
00007e6bc8bdfe8e  pop r8
00007e6bc8bdfe90  pop rsi
00007e6bc8bdfe91  pop rdi
00007e6bc8bdfe92  pop rdx
00007e6bc8bdfe93  pop rcx
00007e6bc8bdfe94  pop rax
00007e6bc8bdfe95  add rsp, 0x08
00007e6bc8bdfe99  jmp 0x00007E6BC8BDC520
00007e6bc8bdfe9e  sub rsp, 0x08
00007e6bc8bdfea2  push rax
00007e6bc8bdfea3  push rcx
00007e6bc8bdfea4  push rdx
00007e6bc8bdfea5  push rdi
00007e6bc8bdfea6  push rsi
00007e6bc8bdfea7  push r8
00007e6bc8bdfea9  push r9
00007e6bc8bdfeab  push r10
00007e6bc8bdfead  push r11
00007e6bc8bdfeaf  sub rsp, 0xF0
00007e6bc8bdfeb6  vmovaps [rsp], xmm0
00007e6bc8bdfebb  vmovaps [rsp+0x10], xmm1
00007e6bc8bdfec1  vmovaps [rsp+0x20], xmm2
00007e6bc8bdfec7  vmovaps [rsp+0x30], xmm3
00007e6bc8bdfecd  vmovaps [rsp+0x40], xmm4
00007e6bc8bdfed3  vmovaps [rsp+0x50], xmm5
00007e6bc8bdfed9  vmovaps [rsp+0x60], xmm6
00007e6bc8bdfedf  vmovaps [rsp+0x70], xmm7
00007e6bc8bdfee5  vmovaps [rsp+0x80], xmm8
00007e6bc8bdfeee  vmovaps [rsp+0x90], xmm9
00007e6bc8bdfef7  vmovaps [rsp+0xA0], xmm11
00007e6bc8bdff00  vmovaps [rsp+0xB0], xmm12
00007e6bc8bdff09  vmovaps [rsp+0xC0], xmm13
00007e6bc8bdff12  vmovaps [rsp+0xD0], xmm14
00007e6bc8bdff1b  vmovaps [rsp+0xE0], xmm15
00007e6bc8bdff24  sub rsp, 0x30
00007e6bc8bdff28  movaps [rsp], xmm10
00007e6bc8bdff2d  movaps [rsp+0x10], xmm14
00007e6bc8bdff33  movaps [rsp+0x20], xmm4
00007e6bc8bdff38  lea rdi, [rsp]
00007e6bc8bdff3c  mov esi, 0x00
00007e6bc8bdff41  mov rax, 0x6543F191D530
00007e6bc8bdff4b  call rax
00007e6bc8bdff4d  movaps xmm10, [rsp]
00007e6bc8bdff52  add rsp, 0x30
00007e6bc8bdff56  vmovaps xmm0, [rsp]
00007e6bc8bdff5b  vmovaps xmm1, [rsp+0x10]
00007e6bc8bdff61  vmovaps xmm2, [rsp+0x20]
00007e6bc8bdff67  vmovaps xmm3, [rsp+0x30]
00007e6bc8bdff6d  vmovaps xmm4, [rsp+0x40]
00007e6bc8bdff73  vmovaps xmm5, [rsp+0x50]
00007e6bc8bdff79  vmovaps xmm6, [rsp+0x60]
00007e6bc8bdff7f  vmovaps xmm7, [rsp+0x70]
00007e6bc8bdff85  vmovaps xmm8, [rsp+0x80]
00007e6bc8bdff8e  vmovaps xmm9, [rsp+0x90]
00007e6bc8bdff97  vmovaps xmm11, [rsp+0xA0]
00007e6bc8bdffa0  vmovaps xmm12, [rsp+0xB0]
00007e6bc8bdffa9  vmovaps xmm13, [rsp+0xC0]
00007e6bc8bdffb2  vmovaps xmm14, [rsp+0xD0]
00007e6bc8bdffbb  vmovaps xmm15, [rsp+0xE0]
00007e6bc8bdffc4  add rsp, 0xF0
00007e6bc8bdffcb  pop r11
00007e6bc8bdffcd  pop r10
00007e6bc8bdffcf  pop r9
00007e6bc8bdffd1  pop r8
00007e6bc8bdffd3  pop rsi
00007e6bc8bdffd4  pop rdi
00007e6bc8bdffd5  pop rdx
00007e6bc8bdffd6  pop rcx
00007e6bc8bdffd7  pop rax
00007e6bc8bdffd8  add rsp, 0x08
00007e6bc8bdffdc  jmp 0x00007E6BC8BDC53B
00007e6bc8bdffe1  sub rsp, 0x08
00007e6bc8bdffe5  push rax
00007e6bc8bdffe6  push rcx
00007e6bc8bdffe7  push rdx
00007e6bc8bdffe8  push rdi
00007e6bc8bdffe9  push rsi
00007e6bc8bdffea  push r8
00007e6bc8bdffec  push r9
00007e6bc8bdffee  push r10
00007e6bc8bdfff0  push r11
00007e6bc8bdfff2  sub rsp, 0xF0
00007e6bc8bdfff9  vmovaps [rsp], xmm0
00007e6bc8bdfffe  vmovaps [rsp+0x10], xmm1
00007e6bc8be0004  vmovaps [rsp+0x20], xmm2
00007e6bc8be000a  vmovaps [rsp+0x30], xmm3
00007e6bc8be0010  vmovaps [rsp+0x40], xmm4
00007e6bc8be0016  vmovaps [rsp+0x50], xmm5
00007e6bc8be001c  vmovaps [rsp+0x60], xmm6
00007e6bc8be0022  vmovaps [rsp+0x70], xmm7
00007e6bc8be0028  vmovaps [rsp+0x80], xmm9
00007e6bc8be0031  vmovaps [rsp+0x90], xmm10
00007e6bc8be003a  vmovaps [rsp+0xA0], xmm11
00007e6bc8be0043  vmovaps [rsp+0xB0], xmm12
00007e6bc8be004c  vmovaps [rsp+0xC0], xmm13
00007e6bc8be0055  vmovaps [rsp+0xD0], xmm14
00007e6bc8be005e  vmovaps [rsp+0xE0], xmm15
00007e6bc8be0067  sub rsp, 0x30
00007e6bc8be006b  movaps [rsp], xmm8
00007e6bc8be0070  movaps [rsp+0x10], xmm1
00007e6bc8be0075  movaps [rsp+0x20], xmm14
00007e6bc8be007b  lea rdi, [rsp]
00007e6bc8be007f  mov esi, 0x00
00007e6bc8be0084  mov rax, 0x6543F191D530
00007e6bc8be008e  call rax
00007e6bc8be0090  movaps xmm8, [rsp]
00007e6bc8be0095  add rsp, 0x30
00007e6bc8be0099  vmovaps xmm0, [rsp]
00007e6bc8be009e  vmovaps xmm1, [rsp+0x10]
00007e6bc8be00a4  vmovaps xmm2, [rsp+0x20]
00007e6bc8be00aa  vmovaps xmm3, [rsp+0x30]
00007e6bc8be00b0  vmovaps xmm4, [rsp+0x40]
00007e6bc8be00b6  vmovaps xmm5, [rsp+0x50]
00007e6bc8be00bc  vmovaps xmm6, [rsp+0x60]
00007e6bc8be00c2  vmovaps xmm7, [rsp+0x70]
00007e6bc8be00c8  vmovaps xmm9, [rsp+0x80]
00007e6bc8be00d1  vmovaps xmm10, [rsp+0x90]
00007e6bc8be00da  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be00e3  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be00ec  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be00f5  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be00fe  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0107  add rsp, 0xF0
00007e6bc8be010e  pop r11
00007e6bc8be0110  pop r10
00007e6bc8be0112  pop r9
00007e6bc8be0114  pop r8
00007e6bc8be0116  pop rsi
00007e6bc8be0117  pop rdi
00007e6bc8be0118  pop rdx
00007e6bc8be0119  pop rcx
00007e6bc8be011a  pop rax
00007e6bc8be011b  add rsp, 0x08
00007e6bc8be011f  jmp 0x00007E6BC8BDC561
00007e6bc8be0124  sub rsp, 0x08
00007e6bc8be0128  push rax
00007e6bc8be0129  push rcx
00007e6bc8be012a  push rdx
00007e6bc8be012b  push rdi
00007e6bc8be012c  push rsi
00007e6bc8be012d  push r8
00007e6bc8be012f  push r9
00007e6bc8be0131  push r10
00007e6bc8be0133  push r11
00007e6bc8be0135  sub rsp, 0xF0
00007e6bc8be013c  vmovaps [rsp], xmm0
00007e6bc8be0141  vmovaps [rsp+0x10], xmm1
00007e6bc8be0147  vmovaps [rsp+0x20], xmm2
00007e6bc8be014d  vmovaps [rsp+0x30], xmm3
00007e6bc8be0153  vmovaps [rsp+0x40], xmm4
00007e6bc8be0159  vmovaps [rsp+0x50], xmm5
00007e6bc8be015f  vmovaps [rsp+0x60], xmm7
00007e6bc8be0165  vmovaps [rsp+0x70], xmm8
00007e6bc8be016b  vmovaps [rsp+0x80], xmm9
00007e6bc8be0174  vmovaps [rsp+0x90], xmm10
00007e6bc8be017d  vmovaps [rsp+0xA0], xmm11
00007e6bc8be0186  vmovaps [rsp+0xB0], xmm12
00007e6bc8be018f  vmovaps [rsp+0xC0], xmm13
00007e6bc8be0198  vmovaps [rsp+0xD0], xmm14
00007e6bc8be01a1  vmovaps [rsp+0xE0], xmm15
00007e6bc8be01aa  sub rsp, 0x30
00007e6bc8be01ae  movaps [rsp], xmm6
00007e6bc8be01b2  movaps [rsp+0x10], xmm1
00007e6bc8be01b7  movaps [rsp+0x20], xmm14
00007e6bc8be01bd  lea rdi, [rsp]
00007e6bc8be01c1  mov esi, 0x00
00007e6bc8be01c6  mov rax, 0x6543F191D530
00007e6bc8be01d0  call rax
00007e6bc8be01d2  movaps xmm6, [rsp]
00007e6bc8be01d6  add rsp, 0x30
00007e6bc8be01da  vmovaps xmm0, [rsp]
00007e6bc8be01df  vmovaps xmm1, [rsp+0x10]
00007e6bc8be01e5  vmovaps xmm2, [rsp+0x20]
00007e6bc8be01eb  vmovaps xmm3, [rsp+0x30]
00007e6bc8be01f1  vmovaps xmm4, [rsp+0x40]
00007e6bc8be01f7  vmovaps xmm5, [rsp+0x50]
00007e6bc8be01fd  vmovaps xmm7, [rsp+0x60]
00007e6bc8be0203  vmovaps xmm8, [rsp+0x70]
00007e6bc8be0209  vmovaps xmm9, [rsp+0x80]
00007e6bc8be0212  vmovaps xmm10, [rsp+0x90]
00007e6bc8be021b  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be0224  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be022d  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be0236  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be023f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0248  add rsp, 0xF0
00007e6bc8be024f  pop r11
00007e6bc8be0251  pop r10
00007e6bc8be0253  pop r9
00007e6bc8be0255  pop r8
00007e6bc8be0257  pop rsi
00007e6bc8be0258  pop rdi
00007e6bc8be0259  pop rdx
00007e6bc8be025a  pop rcx
00007e6bc8be025b  pop rax
00007e6bc8be025c  add rsp, 0x08
00007e6bc8be0260  jmp 0x00007E6BC8BDC58D
00007e6bc8be0265  sub rsp, 0x08
00007e6bc8be0269  push rax
00007e6bc8be026a  push rcx
00007e6bc8be026b  push rdx
00007e6bc8be026c  push rdi
00007e6bc8be026d  push rsi
00007e6bc8be026e  push r8
00007e6bc8be0270  push r9
00007e6bc8be0272  push r10
00007e6bc8be0274  push r11
00007e6bc8be0276  sub rsp, 0xF0
00007e6bc8be027d  vmovaps [rsp], xmm0
00007e6bc8be0282  vmovaps [rsp+0x10], xmm1
00007e6bc8be0288  vmovaps [rsp+0x20], xmm2
00007e6bc8be028e  vmovaps [rsp+0x30], xmm3
00007e6bc8be0294  vmovaps [rsp+0x40], xmm4
00007e6bc8be029a  vmovaps [rsp+0x50], xmm5
00007e6bc8be02a0  vmovaps [rsp+0x60], xmm6
00007e6bc8be02a6  vmovaps [rsp+0x70], xmm7
00007e6bc8be02ac  vmovaps [rsp+0x80], xmm8
00007e6bc8be02b5  vmovaps [rsp+0x90], xmm9
00007e6bc8be02be  vmovaps [rsp+0xA0], xmm10
00007e6bc8be02c7  vmovaps [rsp+0xB0], xmm11
00007e6bc8be02d0  vmovaps [rsp+0xC0], xmm12
00007e6bc8be02d9  vmovaps [rsp+0xD0], xmm13
00007e6bc8be02e2  vmovaps [rsp+0xE0], xmm15
00007e6bc8be02eb  sub rsp, 0x30
00007e6bc8be02ef  movaps [rsp], xmm14
00007e6bc8be02f4  movaps [rsp+0x10], xmm12
00007e6bc8be02fa  movaps [rsp+0x20], xmm1
00007e6bc8be02ff  lea rdi, [rsp]
00007e6bc8be0303  mov esi, 0x00
00007e6bc8be0308  mov rax, 0x6543F191D530
00007e6bc8be0312  call rax
00007e6bc8be0314  movaps xmm14, [rsp]
00007e6bc8be0319  add rsp, 0x30
00007e6bc8be031d  vmovaps xmm0, [rsp]
00007e6bc8be0322  vmovaps xmm1, [rsp+0x10]
00007e6bc8be0328  vmovaps xmm2, [rsp+0x20]
00007e6bc8be032e  vmovaps xmm3, [rsp+0x30]
00007e6bc8be0334  vmovaps xmm4, [rsp+0x40]
00007e6bc8be033a  vmovaps xmm5, [rsp+0x50]
00007e6bc8be0340  vmovaps xmm6, [rsp+0x60]
00007e6bc8be0346  vmovaps xmm7, [rsp+0x70]
00007e6bc8be034c  vmovaps xmm8, [rsp+0x80]
00007e6bc8be0355  vmovaps xmm9, [rsp+0x90]
00007e6bc8be035e  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be0367  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be0370  vmovaps xmm12, [rsp+0xC0]
00007e6bc8be0379  vmovaps xmm13, [rsp+0xD0]
00007e6bc8be0382  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be038b  add rsp, 0xF0
00007e6bc8be0392  pop r11
00007e6bc8be0394  pop r10
00007e6bc8be0396  pop r9
00007e6bc8be0398  pop r8
00007e6bc8be039a  pop rsi
00007e6bc8be039b  pop rdi
00007e6bc8be039c  pop rdx
00007e6bc8be039d  pop rcx
00007e6bc8be039e  pop rax
00007e6bc8be039f  add rsp, 0x08
00007e6bc8be03a3  jmp 0x00007E6BC8BDC5B3
00007e6bc8be03a8  sub rsp, 0x08
00007e6bc8be03ac  push rax
00007e6bc8be03ad  push rcx
00007e6bc8be03ae  push rdx
00007e6bc8be03af  push rdi
00007e6bc8be03b0  push rsi
00007e6bc8be03b1  push r8
00007e6bc8be03b3  push r9
00007e6bc8be03b5  push r10
00007e6bc8be03b7  push r11
00007e6bc8be03b9  sub rsp, 0xF0
00007e6bc8be03c0  vmovaps [rsp], xmm0
00007e6bc8be03c5  vmovaps [rsp+0x10], xmm2
00007e6bc8be03cb  vmovaps [rsp+0x20], xmm3
00007e6bc8be03d1  vmovaps [rsp+0x30], xmm4
00007e6bc8be03d7  vmovaps [rsp+0x40], xmm5
00007e6bc8be03dd  vmovaps [rsp+0x50], xmm6
00007e6bc8be03e3  vmovaps [rsp+0x60], xmm7
00007e6bc8be03e9  vmovaps [rsp+0x70], xmm8
00007e6bc8be03ef  vmovaps [rsp+0x80], xmm9
00007e6bc8be03f8  vmovaps [rsp+0x90], xmm10
00007e6bc8be0401  vmovaps [rsp+0xA0], xmm11
00007e6bc8be040a  vmovaps [rsp+0xB0], xmm12
00007e6bc8be0413  vmovaps [rsp+0xC0], xmm13
00007e6bc8be041c  vmovaps [rsp+0xD0], xmm14
00007e6bc8be0425  vmovaps [rsp+0xE0], xmm15
00007e6bc8be042e  sub rsp, 0x30
00007e6bc8be0432  movaps [rsp], xmm1
00007e6bc8be0436  movaps [rsp+0x10], xmm13
00007e6bc8be043c  movaps [rsp+0x20], xmm9
00007e6bc8be0442  lea rdi, [rsp]
00007e6bc8be0446  mov esi, 0x00
00007e6bc8be044b  mov rax, 0x6543F191D530
00007e6bc8be0455  call rax
00007e6bc8be0457  movaps xmm1, [rsp]
00007e6bc8be045b  add rsp, 0x30
00007e6bc8be045f  vmovaps xmm0, [rsp]
00007e6bc8be0464  vmovaps xmm2, [rsp+0x10]
00007e6bc8be046a  vmovaps xmm3, [rsp+0x20]
00007e6bc8be0470  vmovaps xmm4, [rsp+0x30]
00007e6bc8be0476  vmovaps xmm5, [rsp+0x40]
00007e6bc8be047c  vmovaps xmm6, [rsp+0x50]
00007e6bc8be0482  vmovaps xmm7, [rsp+0x60]
00007e6bc8be0488  vmovaps xmm8, [rsp+0x70]
00007e6bc8be048e  vmovaps xmm9, [rsp+0x80]
00007e6bc8be0497  vmovaps xmm10, [rsp+0x90]
00007e6bc8be04a0  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be04a9  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be04b2  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be04bb  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be04c4  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be04cd  add rsp, 0xF0
00007e6bc8be04d4  pop r11
00007e6bc8be04d6  pop r10
00007e6bc8be04d8  pop r9
00007e6bc8be04da  pop r8
00007e6bc8be04dc  pop rsi
00007e6bc8be04dd  pop rdi
00007e6bc8be04de  pop rdx
00007e6bc8be04df  pop rcx
00007e6bc8be04e0  pop rax
00007e6bc8be04e1  add rsp, 0x08
00007e6bc8be04e5  jmp 0x00007E6BC8BDC5CD
00007e6bc8be04ea  sub rsp, 0x08
00007e6bc8be04ee  push rax
00007e6bc8be04ef  push rcx
00007e6bc8be04f0  push rdx
00007e6bc8be04f1  push rdi
00007e6bc8be04f2  push rsi
00007e6bc8be04f3  push r8
00007e6bc8be04f5  push r9
00007e6bc8be04f7  push r10
00007e6bc8be04f9  push r11
00007e6bc8be04fb  sub rsp, 0xF0
00007e6bc8be0502  vmovaps [rsp], xmm0
00007e6bc8be0507  vmovaps [rsp+0x10], xmm1
00007e6bc8be050d  vmovaps [rsp+0x20], xmm2
00007e6bc8be0513  vmovaps [rsp+0x30], xmm3
00007e6bc8be0519  vmovaps [rsp+0x40], xmm4
00007e6bc8be051f  vmovaps [rsp+0x50], xmm5
00007e6bc8be0525  vmovaps [rsp+0x60], xmm6
00007e6bc8be052b  vmovaps [rsp+0x70], xmm7
00007e6bc8be0531  vmovaps [rsp+0x80], xmm8
00007e6bc8be053a  vmovaps [rsp+0x90], xmm9
00007e6bc8be0543  vmovaps [rsp+0xA0], xmm10
00007e6bc8be054c  vmovaps [rsp+0xB0], xmm11
00007e6bc8be0555  vmovaps [rsp+0xC0], xmm13
00007e6bc8be055e  vmovaps [rsp+0xD0], xmm14
00007e6bc8be0567  vmovaps [rsp+0xE0], xmm15
00007e6bc8be0570  sub rsp, 0x30
00007e6bc8be0574  movaps [rsp], xmm12
00007e6bc8be0579  movaps [rsp+0x10], xmm7
00007e6bc8be057e  movaps [rsp+0x20], xmm13
00007e6bc8be0584  lea rdi, [rsp]
00007e6bc8be0588  mov esi, 0x00
00007e6bc8be058d  mov rax, 0x6543F191D530
00007e6bc8be0597  call rax
00007e6bc8be0599  movaps xmm12, [rsp]
00007e6bc8be059e  add rsp, 0x30
00007e6bc8be05a2  vmovaps xmm0, [rsp]
00007e6bc8be05a7  vmovaps xmm1, [rsp+0x10]
00007e6bc8be05ad  vmovaps xmm2, [rsp+0x20]
00007e6bc8be05b3  vmovaps xmm3, [rsp+0x30]
00007e6bc8be05b9  vmovaps xmm4, [rsp+0x40]
00007e6bc8be05bf  vmovaps xmm5, [rsp+0x50]
00007e6bc8be05c5  vmovaps xmm6, [rsp+0x60]
00007e6bc8be05cb  vmovaps xmm7, [rsp+0x70]
00007e6bc8be05d1  vmovaps xmm8, [rsp+0x80]
00007e6bc8be05da  vmovaps xmm9, [rsp+0x90]
00007e6bc8be05e3  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be05ec  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be05f5  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be05fe  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be0607  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0610  add rsp, 0xF0
00007e6bc8be0617  pop r11
00007e6bc8be0619  pop r10
00007e6bc8be061b  pop r9
00007e6bc8be061d  pop r8
00007e6bc8be061f  pop rsi
00007e6bc8be0620  pop rdi
00007e6bc8be0621  pop rdx
00007e6bc8be0622  pop rcx
00007e6bc8be0623  pop rax
00007e6bc8be0624  add rsp, 0x08
00007e6bc8be0628  jmp 0x00007E6BC8BDC5F4
00007e6bc8be062d  sub rsp, 0x08
00007e6bc8be0631  push rax
00007e6bc8be0632  push rcx
00007e6bc8be0633  push rdx
00007e6bc8be0634  push rdi
00007e6bc8be0635  push rsi
00007e6bc8be0636  push r8
00007e6bc8be0638  push r9
00007e6bc8be063a  push r10
00007e6bc8be063c  push r11
00007e6bc8be063e  sub rsp, 0xF0
00007e6bc8be0645  vmovaps [rsp], xmm0
00007e6bc8be064a  vmovaps [rsp+0x10], xmm1
00007e6bc8be0650  vmovaps [rsp+0x20], xmm2
00007e6bc8be0656  vmovaps [rsp+0x30], xmm3
00007e6bc8be065c  vmovaps [rsp+0x40], xmm4
00007e6bc8be0662  vmovaps [rsp+0x50], xmm5
00007e6bc8be0668  vmovaps [rsp+0x60], xmm6
00007e6bc8be066e  vmovaps [rsp+0x70], xmm7
00007e6bc8be0674  vmovaps [rsp+0x80], xmm8
00007e6bc8be067d  vmovaps [rsp+0x90], xmm9
00007e6bc8be0686  vmovaps [rsp+0xA0], xmm10
00007e6bc8be068f  vmovaps [rsp+0xB0], xmm11
00007e6bc8be0698  vmovaps [rsp+0xC0], xmm12
00007e6bc8be06a1  vmovaps [rsp+0xD0], xmm14
00007e6bc8be06aa  vmovaps [rsp+0xE0], xmm15
00007e6bc8be06b3  sub rsp, 0x30
00007e6bc8be06b7  movaps [rsp], xmm13
00007e6bc8be06bc  movaps [rsp+0x10], xmm15
00007e6bc8be06c2  movaps [rsp+0x20], xmm8
00007e6bc8be06c8  lea rdi, [rsp]
00007e6bc8be06cc  mov esi, 0x00
00007e6bc8be06d1  mov rax, 0x6543F191D530
00007e6bc8be06db  call rax
00007e6bc8be06dd  movaps xmm13, [rsp]
00007e6bc8be06e2  add rsp, 0x30
00007e6bc8be06e6  vmovaps xmm0, [rsp]
00007e6bc8be06eb  vmovaps xmm1, [rsp+0x10]
00007e6bc8be06f1  vmovaps xmm2, [rsp+0x20]
00007e6bc8be06f7  vmovaps xmm3, [rsp+0x30]
00007e6bc8be06fd  vmovaps xmm4, [rsp+0x40]
00007e6bc8be0703  vmovaps xmm5, [rsp+0x50]
00007e6bc8be0709  vmovaps xmm6, [rsp+0x60]
00007e6bc8be070f  vmovaps xmm7, [rsp+0x70]
00007e6bc8be0715  vmovaps xmm8, [rsp+0x80]
00007e6bc8be071e  vmovaps xmm9, [rsp+0x90]
00007e6bc8be0727  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be0730  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be0739  vmovaps xmm12, [rsp+0xC0]
00007e6bc8be0742  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be074b  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0754  add rsp, 0xF0
00007e6bc8be075b  pop r11
00007e6bc8be075d  pop r10
00007e6bc8be075f  pop r9
00007e6bc8be0761  pop r8
00007e6bc8be0763  pop rsi
00007e6bc8be0764  pop rdi
00007e6bc8be0765  pop rdx
00007e6bc8be0766  pop rcx
00007e6bc8be0767  pop rax
00007e6bc8be0768  add rsp, 0x08
00007e6bc8be076c  jmp 0x00007E6BC8BDC60F
00007e6bc8be0771  sub rsp, 0x08
00007e6bc8be0775  push rax
00007e6bc8be0776  push rcx
00007e6bc8be0777  push rdx
00007e6bc8be0778  push rdi
00007e6bc8be0779  push rsi
00007e6bc8be077a  push r8
00007e6bc8be077c  push r9
00007e6bc8be077e  push r10
00007e6bc8be0780  push r11
00007e6bc8be0782  sub rsp, 0xF0
00007e6bc8be0789  vmovaps [rsp], xmm0
00007e6bc8be078e  vmovaps [rsp+0x10], xmm1
00007e6bc8be0794  vmovaps [rsp+0x20], xmm2
00007e6bc8be079a  vmovaps [rsp+0x30], xmm3
00007e6bc8be07a0  vmovaps [rsp+0x40], xmm4
00007e6bc8be07a6  vmovaps [rsp+0x50], xmm5
00007e6bc8be07ac  vmovaps [rsp+0x60], xmm6
00007e6bc8be07b2  vmovaps [rsp+0x70], xmm7
00007e6bc8be07b8  vmovaps [rsp+0x80], xmm9
00007e6bc8be07c1  vmovaps [rsp+0x90], xmm10
00007e6bc8be07ca  vmovaps [rsp+0xA0], xmm11
00007e6bc8be07d3  vmovaps [rsp+0xB0], xmm12
00007e6bc8be07dc  vmovaps [rsp+0xC0], xmm13
00007e6bc8be07e5  vmovaps [rsp+0xD0], xmm14
00007e6bc8be07ee  vmovaps [rsp+0xE0], xmm15
00007e6bc8be07f7  sub rsp, 0x30
00007e6bc8be07fb  movaps [rsp], xmm8
00007e6bc8be0800  movaps [rsp+0x10], xmm15
00007e6bc8be0806  movaps [rsp+0x20], xmm9
00007e6bc8be080c  lea rdi, [rsp]
00007e6bc8be0810  mov esi, 0x00
00007e6bc8be0815  mov rax, 0x6543F191D530
00007e6bc8be081f  call rax
00007e6bc8be0821  movaps xmm8, [rsp]
00007e6bc8be0826  add rsp, 0x30
00007e6bc8be082a  vmovaps xmm0, [rsp]
00007e6bc8be082f  vmovaps xmm1, [rsp+0x10]
00007e6bc8be0835  vmovaps xmm2, [rsp+0x20]
00007e6bc8be083b  vmovaps xmm3, [rsp+0x30]
00007e6bc8be0841  vmovaps xmm4, [rsp+0x40]
00007e6bc8be0847  vmovaps xmm5, [rsp+0x50]
00007e6bc8be084d  vmovaps xmm6, [rsp+0x60]
00007e6bc8be0853  vmovaps xmm7, [rsp+0x70]
00007e6bc8be0859  vmovaps xmm9, [rsp+0x80]
00007e6bc8be0862  vmovaps xmm10, [rsp+0x90]
00007e6bc8be086b  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be0874  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be087d  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be0886  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be088f  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0898  add rsp, 0xF0
00007e6bc8be089f  pop r11
00007e6bc8be08a1  pop r10
00007e6bc8be08a3  pop r9
00007e6bc8be08a5  pop r8
00007e6bc8be08a7  pop rsi
00007e6bc8be08a8  pop rdi
00007e6bc8be08a9  pop rdx
00007e6bc8be08aa  pop rcx
00007e6bc8be08ab  pop rax
00007e6bc8be08ac  add rsp, 0x08
00007e6bc8be08b0  jmp 0x00007E6BC8BDC63D
00007e6bc8be08b5  sub rsp, 0x08
00007e6bc8be08b9  push rax
00007e6bc8be08ba  push rcx
00007e6bc8be08bb  push rdx
00007e6bc8be08bc  push rdi
00007e6bc8be08bd  push rsi
00007e6bc8be08be  push r8
00007e6bc8be08c0  push r9
00007e6bc8be08c2  push r10
00007e6bc8be08c4  push r11
00007e6bc8be08c6  sub rsp, 0xF0
00007e6bc8be08cd  vmovaps [rsp], xmm0
00007e6bc8be08d2  vmovaps [rsp+0x10], xmm1
00007e6bc8be08d8  vmovaps [rsp+0x20], xmm2
00007e6bc8be08de  vmovaps [rsp+0x30], xmm3
00007e6bc8be08e4  vmovaps [rsp+0x40], xmm4
00007e6bc8be08ea  vmovaps [rsp+0x50], xmm5
00007e6bc8be08f0  vmovaps [rsp+0x60], xmm6
00007e6bc8be08f6  vmovaps [rsp+0x70], xmm7
00007e6bc8be08fc  vmovaps [rsp+0x80], xmm8
00007e6bc8be0905  vmovaps [rsp+0x90], xmm9
00007e6bc8be090e  vmovaps [rsp+0xA0], xmm10
00007e6bc8be0917  vmovaps [rsp+0xB0], xmm11
00007e6bc8be0920  vmovaps [rsp+0xC0], xmm12
00007e6bc8be0929  vmovaps [rsp+0xD0], xmm13
00007e6bc8be0932  vmovaps [rsp+0xE0], xmm14
00007e6bc8be093b  sub rsp, 0x30
00007e6bc8be093f  movaps [rsp], xmm15
00007e6bc8be0944  movaps [rsp+0x10], xmm11
00007e6bc8be094a  movaps [rsp+0x20], xmm6
00007e6bc8be094f  lea rdi, [rsp]
00007e6bc8be0953  mov esi, 0x00
00007e6bc8be0958  mov rax, 0x6543F191D530
00007e6bc8be0962  call rax
00007e6bc8be0964  movaps xmm15, [rsp]
00007e6bc8be0969  add rsp, 0x30
00007e6bc8be096d  vmovaps xmm0, [rsp]
00007e6bc8be0972  vmovaps xmm1, [rsp+0x10]
00007e6bc8be0978  vmovaps xmm2, [rsp+0x20]
00007e6bc8be097e  vmovaps xmm3, [rsp+0x30]
00007e6bc8be0984  vmovaps xmm4, [rsp+0x40]
00007e6bc8be098a  vmovaps xmm5, [rsp+0x50]
00007e6bc8be0990  vmovaps xmm6, [rsp+0x60]
00007e6bc8be0996  vmovaps xmm7, [rsp+0x70]
00007e6bc8be099c  vmovaps xmm8, [rsp+0x80]
00007e6bc8be09a5  vmovaps xmm9, [rsp+0x90]
00007e6bc8be09ae  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be09b7  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be09c0  vmovaps xmm12, [rsp+0xC0]
00007e6bc8be09c9  vmovaps xmm13, [rsp+0xD0]
00007e6bc8be09d2  vmovaps xmm14, [rsp+0xE0]
00007e6bc8be09db  add rsp, 0xF0
00007e6bc8be09e2  pop r11
00007e6bc8be09e4  pop r10
00007e6bc8be09e6  pop r9
00007e6bc8be09e8  pop r8
00007e6bc8be09ea  pop rsi
00007e6bc8be09eb  pop rdi
00007e6bc8be09ec  pop rdx
00007e6bc8be09ed  pop rcx
00007e6bc8be09ee  pop rax
00007e6bc8be09ef  add rsp, 0x08
00007e6bc8be09f3  jmp 0x00007E6BC8BDC658
00007e6bc8be09f8  sub rsp, 0x08
00007e6bc8be09fc  push rax
00007e6bc8be09fd  push rcx
00007e6bc8be09fe  push rdx
00007e6bc8be09ff  push rdi
00007e6bc8be0a00  push rsi
00007e6bc8be0a01  push r8
00007e6bc8be0a03  push r9
00007e6bc8be0a05  push r10
00007e6bc8be0a07  push r11
00007e6bc8be0a09  sub rsp, 0xF0
00007e6bc8be0a10  vmovaps [rsp], xmm0
00007e6bc8be0a15  vmovaps [rsp+0x10], xmm1
00007e6bc8be0a1b  vmovaps [rsp+0x20], xmm2
00007e6bc8be0a21  vmovaps [rsp+0x30], xmm3
00007e6bc8be0a27  vmovaps [rsp+0x40], xmm4
00007e6bc8be0a2d  vmovaps [rsp+0x50], xmm5
00007e6bc8be0a33  vmovaps [rsp+0x60], xmm6
00007e6bc8be0a39  vmovaps [rsp+0x70], xmm8
00007e6bc8be0a3f  vmovaps [rsp+0x80], xmm9
00007e6bc8be0a48  vmovaps [rsp+0x90], xmm10
00007e6bc8be0a51  vmovaps [rsp+0xA0], xmm11
00007e6bc8be0a5a  vmovaps [rsp+0xB0], xmm12
00007e6bc8be0a63  vmovaps [rsp+0xC0], xmm13
00007e6bc8be0a6c  vmovaps [rsp+0xD0], xmm14
00007e6bc8be0a75  vmovaps [rsp+0xE0], xmm15
00007e6bc8be0a7e  sub rsp, 0x30
00007e6bc8be0a82  movaps [rsp], xmm7
00007e6bc8be0a86  movaps [rsp+0x10], xmm11
00007e6bc8be0a8c  movaps [rsp+0x20], xmm9
00007e6bc8be0a92  lea rdi, [rsp]
00007e6bc8be0a96  mov esi, 0x00
00007e6bc8be0a9b  mov rax, 0x6543F191D530
00007e6bc8be0aa5  call rax
00007e6bc8be0aa7  movaps xmm7, [rsp]
00007e6bc8be0aab  add rsp, 0x30
00007e6bc8be0aaf  vmovaps xmm0, [rsp]
00007e6bc8be0ab4  vmovaps xmm1, [rsp+0x10]
00007e6bc8be0aba  vmovaps xmm2, [rsp+0x20]
00007e6bc8be0ac0  vmovaps xmm3, [rsp+0x30]
00007e6bc8be0ac6  vmovaps xmm4, [rsp+0x40]
00007e6bc8be0acc  vmovaps xmm5, [rsp+0x50]
00007e6bc8be0ad2  vmovaps xmm6, [rsp+0x60]
00007e6bc8be0ad8  vmovaps xmm8, [rsp+0x70]
00007e6bc8be0ade  vmovaps xmm9, [rsp+0x80]
00007e6bc8be0ae7  vmovaps xmm10, [rsp+0x90]
00007e6bc8be0af0  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be0af9  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be0b02  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be0b0b  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be0b14  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0b1d  add rsp, 0xF0
00007e6bc8be0b24  pop r11
00007e6bc8be0b26  pop r10
00007e6bc8be0b28  pop r9
00007e6bc8be0b2a  pop r8
00007e6bc8be0b2c  pop rsi
00007e6bc8be0b2d  pop rdi
00007e6bc8be0b2e  pop rdx
00007e6bc8be0b2f  pop rcx
00007e6bc8be0b30  pop rax
00007e6bc8be0b31  add rsp, 0x08
00007e6bc8be0b35  jmp 0x00007E6BC8BDC685
00007e6bc8be0b3a  sub rsp, 0x08
00007e6bc8be0b3e  push rax
00007e6bc8be0b3f  push rcx
00007e6bc8be0b40  push rdx
00007e6bc8be0b41  push rdi
00007e6bc8be0b42  push rsi
00007e6bc8be0b43  push r8
00007e6bc8be0b45  push r9
00007e6bc8be0b47  push r10
00007e6bc8be0b49  push r11
00007e6bc8be0b4b  sub rsp, 0xF0
00007e6bc8be0b52  vmovaps [rsp], xmm0
00007e6bc8be0b57  vmovaps [rsp+0x10], xmm1
00007e6bc8be0b5d  vmovaps [rsp+0x20], xmm2
00007e6bc8be0b63  vmovaps [rsp+0x30], xmm3
00007e6bc8be0b69  vmovaps [rsp+0x40], xmm4
00007e6bc8be0b6f  vmovaps [rsp+0x50], xmm5
00007e6bc8be0b75  vmovaps [rsp+0x60], xmm6
00007e6bc8be0b7b  vmovaps [rsp+0x70], xmm7
00007e6bc8be0b81  vmovaps [rsp+0x80], xmm8
00007e6bc8be0b8a  vmovaps [rsp+0x90], xmm9
00007e6bc8be0b93  vmovaps [rsp+0xA0], xmm10
00007e6bc8be0b9c  vmovaps [rsp+0xB0], xmm12
00007e6bc8be0ba5  vmovaps [rsp+0xC0], xmm13
00007e6bc8be0bae  vmovaps [rsp+0xD0], xmm14
00007e6bc8be0bb7  vmovaps [rsp+0xE0], xmm15
00007e6bc8be0bc0  sub rsp, 0x30
00007e6bc8be0bc4  movaps [rsp], xmm11
00007e6bc8be0bc9  movaps [rsp+0x10], xmm10
00007e6bc8be0bcf  movaps [rsp+0x20], xmm14
00007e6bc8be0bd5  lea rdi, [rsp]
00007e6bc8be0bd9  mov esi, 0x00
00007e6bc8be0bde  mov rax, 0x6543F191D530
00007e6bc8be0be8  call rax
00007e6bc8be0bea  movaps xmm11, [rsp]
00007e6bc8be0bef  add rsp, 0x30
00007e6bc8be0bf3  vmovaps xmm0, [rsp]
00007e6bc8be0bf8  vmovaps xmm1, [rsp+0x10]
00007e6bc8be0bfe  vmovaps xmm2, [rsp+0x20]
00007e6bc8be0c04  vmovaps xmm3, [rsp+0x30]
00007e6bc8be0c0a  vmovaps xmm4, [rsp+0x40]
00007e6bc8be0c10  vmovaps xmm5, [rsp+0x50]
00007e6bc8be0c16  vmovaps xmm6, [rsp+0x60]
00007e6bc8be0c1c  vmovaps xmm7, [rsp+0x70]
00007e6bc8be0c22  vmovaps xmm8, [rsp+0x80]
00007e6bc8be0c2b  vmovaps xmm9, [rsp+0x90]
00007e6bc8be0c34  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be0c3d  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be0c46  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be0c4f  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be0c58  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0c61  add rsp, 0xF0
00007e6bc8be0c68  pop r11
00007e6bc8be0c6a  pop r10
00007e6bc8be0c6c  pop r9
00007e6bc8be0c6e  pop r8
00007e6bc8be0c70  pop rsi
00007e6bc8be0c71  pop rdi
00007e6bc8be0c72  pop rdx
00007e6bc8be0c73  pop rcx
00007e6bc8be0c74  pop rax
00007e6bc8be0c75  add rsp, 0x08
00007e6bc8be0c79  jmp 0x00007E6BC8BDC6A0
00007e6bc8be0c7e  call 0x00007E6BC8AC33A0
00007e6bc8be0c83  jmp 0x00007E6BC8BDC6AA
00007e6bc8be0c88  sub rsp, 0x08
00007e6bc8be0c8c  push rax
00007e6bc8be0c8d  push rcx
00007e6bc8be0c8e  push rdx
00007e6bc8be0c8f  push rdi
00007e6bc8be0c90  push rsi
00007e6bc8be0c91  push r8
00007e6bc8be0c93  push r9
00007e6bc8be0c95  push r10
00007e6bc8be0c97  push r11
00007e6bc8be0c99  sub rsp, 0xF0
00007e6bc8be0ca0  vmovaps [rsp], xmm0
00007e6bc8be0ca5  vmovaps [rsp+0x10], xmm1
00007e6bc8be0cab  vmovaps [rsp+0x20], xmm2
00007e6bc8be0cb1  vmovaps [rsp+0x30], xmm3
00007e6bc8be0cb7  vmovaps [rsp+0x40], xmm4
00007e6bc8be0cbd  vmovaps [rsp+0x50], xmm5
00007e6bc8be0cc3  vmovaps [rsp+0x60], xmm6
00007e6bc8be0cc9  vmovaps [rsp+0x70], xmm7
00007e6bc8be0ccf  vmovaps [rsp+0x80], xmm8
00007e6bc8be0cd8  vmovaps [rsp+0x90], xmm9
00007e6bc8be0ce1  vmovaps [rsp+0xA0], xmm11
00007e6bc8be0cea  vmovaps [rsp+0xB0], xmm12
00007e6bc8be0cf3  vmovaps [rsp+0xC0], xmm13
00007e6bc8be0cfc  vmovaps [rsp+0xD0], xmm14
00007e6bc8be0d05  vmovaps [rsp+0xE0], xmm15
00007e6bc8be0d0e  sub rsp, 0x30
00007e6bc8be0d12  movaps [rsp], xmm10
00007e6bc8be0d17  movaps [rsp+0x10], xmm1
00007e6bc8be0d1c  movaps [rsp+0x20], xmm12
00007e6bc8be0d22  lea rdi, [rsp]
00007e6bc8be0d26  mov esi, 0x00
00007e6bc8be0d2b  mov rax, 0x6543F191D530
00007e6bc8be0d35  call rax
00007e6bc8be0d37  movaps xmm10, [rsp]
00007e6bc8be0d3c  add rsp, 0x30
00007e6bc8be0d40  vmovaps xmm0, [rsp]
00007e6bc8be0d45  vmovaps xmm1, [rsp+0x10]
00007e6bc8be0d4b  vmovaps xmm2, [rsp+0x20]
00007e6bc8be0d51  vmovaps xmm3, [rsp+0x30]
00007e6bc8be0d57  vmovaps xmm4, [rsp+0x40]
00007e6bc8be0d5d  vmovaps xmm5, [rsp+0x50]
00007e6bc8be0d63  vmovaps xmm6, [rsp+0x60]
00007e6bc8be0d69  vmovaps xmm7, [rsp+0x70]
00007e6bc8be0d6f  vmovaps xmm8, [rsp+0x80]
00007e6bc8be0d78  vmovaps xmm9, [rsp+0x90]
00007e6bc8be0d81  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be0d8a  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be0d93  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be0d9c  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be0da5  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0dae  add rsp, 0xF0
00007e6bc8be0db5  pop r11
00007e6bc8be0db7  pop r10
00007e6bc8be0db9  pop r9
00007e6bc8be0dbb  pop r8
00007e6bc8be0dbd  pop rsi
00007e6bc8be0dbe  pop rdi
00007e6bc8be0dbf  pop rdx
00007e6bc8be0dc0  pop rcx
00007e6bc8be0dc1  pop rax
00007e6bc8be0dc2  add rsp, 0x08
00007e6bc8be0dc6  jmp 0x00007E6BC8BDC6CD
00007e6bc8be0dcb  sub rsp, 0x08
00007e6bc8be0dcf  push rax
00007e6bc8be0dd0  push rcx
00007e6bc8be0dd1  push rdx
00007e6bc8be0dd2  push rdi
00007e6bc8be0dd3  push rsi
00007e6bc8be0dd4  push r8
00007e6bc8be0dd6  push r9
00007e6bc8be0dd8  push r10
00007e6bc8be0dda  push r11
00007e6bc8be0ddc  sub rsp, 0xF0
00007e6bc8be0de3  vmovaps [rsp], xmm0
00007e6bc8be0de8  vmovaps [rsp+0x10], xmm1
00007e6bc8be0dee  vmovaps [rsp+0x20], xmm2
00007e6bc8be0df4  vmovaps [rsp+0x30], xmm3
00007e6bc8be0dfa  vmovaps [rsp+0x40], xmm4
00007e6bc8be0e00  vmovaps [rsp+0x50], xmm5
00007e6bc8be0e06  vmovaps [rsp+0x60], xmm6
00007e6bc8be0e0c  vmovaps [rsp+0x70], xmm7
00007e6bc8be0e12  vmovaps [rsp+0x80], xmm8
00007e6bc8be0e1b  vmovaps [rsp+0x90], xmm9
00007e6bc8be0e24  vmovaps [rsp+0xA0], xmm10
00007e6bc8be0e2d  vmovaps [rsp+0xB0], xmm11
00007e6bc8be0e36  vmovaps [rsp+0xC0], xmm13
00007e6bc8be0e3f  vmovaps [rsp+0xD0], xmm14
00007e6bc8be0e48  vmovaps [rsp+0xE0], xmm15
00007e6bc8be0e51  sub rsp, 0x30
00007e6bc8be0e55  movaps [rsp], xmm12
00007e6bc8be0e5a  movaps [rsp+0x10], xmm14
00007e6bc8be0e60  movaps [rsp+0x20], xmm1
00007e6bc8be0e65  lea rdi, [rsp]
00007e6bc8be0e69  mov esi, 0x00
00007e6bc8be0e6e  mov rax, 0x6543F191D530
00007e6bc8be0e78  call rax
00007e6bc8be0e7a  movaps xmm12, [rsp]
00007e6bc8be0e7f  add rsp, 0x30
00007e6bc8be0e83  vmovaps xmm0, [rsp]
00007e6bc8be0e88  vmovaps xmm1, [rsp+0x10]
00007e6bc8be0e8e  vmovaps xmm2, [rsp+0x20]
00007e6bc8be0e94  vmovaps xmm3, [rsp+0x30]
00007e6bc8be0e9a  vmovaps xmm4, [rsp+0x40]
00007e6bc8be0ea0  vmovaps xmm5, [rsp+0x50]
00007e6bc8be0ea6  vmovaps xmm6, [rsp+0x60]
00007e6bc8be0eac  vmovaps xmm7, [rsp+0x70]
00007e6bc8be0eb2  vmovaps xmm8, [rsp+0x80]
00007e6bc8be0ebb  vmovaps xmm9, [rsp+0x90]
00007e6bc8be0ec4  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be0ecd  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be0ed6  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be0edf  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be0ee8  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be0ef1  add rsp, 0xF0
00007e6bc8be0ef8  pop r11
00007e6bc8be0efa  pop r10
00007e6bc8be0efc  pop r9
00007e6bc8be0efe  pop r8
00007e6bc8be0f00  pop rsi
00007e6bc8be0f01  pop rdi
00007e6bc8be0f02  pop rdx
00007e6bc8be0f03  pop rcx
00007e6bc8be0f04  pop rax
00007e6bc8be0f05  add rsp, 0x08
00007e6bc8be0f09  jmp 0x00007E6BC8BDC6FC
00007e6bc8be0f0e  sub rsp, 0x08
00007e6bc8be0f12  push rax
00007e6bc8be0f13  push rcx
00007e6bc8be0f14  push rdx
00007e6bc8be0f15  push rdi
00007e6bc8be0f16  push rsi
00007e6bc8be0f17  push r8
00007e6bc8be0f19  push r9
00007e6bc8be0f1b  push r10
00007e6bc8be0f1d  push r11
00007e6bc8be0f1f  sub rsp, 0xF0
00007e6bc8be0f26  vmovaps [rsp], xmm0
00007e6bc8be0f2b  vmovaps [rsp+0x10], xmm1
00007e6bc8be0f31  vmovaps [rsp+0x20], xmm2
00007e6bc8be0f37  vmovaps [rsp+0x30], xmm3
00007e6bc8be0f3d  vmovaps [rsp+0x40], xmm4
00007e6bc8be0f43  vmovaps [rsp+0x50], xmm5
00007e6bc8be0f49  vmovaps [rsp+0x60], xmm6
00007e6bc8be0f4f  vmovaps [rsp+0x70], xmm7
00007e6bc8be0f55  vmovaps [rsp+0x80], xmm8
00007e6bc8be0f5e  vmovaps [rsp+0x90], xmm9
00007e6bc8be0f67  vmovaps [rsp+0xA0], xmm10
00007e6bc8be0f70  vmovaps [rsp+0xB0], xmm11
00007e6bc8be0f79  vmovaps [rsp+0xC0], xmm12
00007e6bc8be0f82  vmovaps [rsp+0xD0], xmm13
00007e6bc8be0f8b  vmovaps [rsp+0xE0], xmm15
00007e6bc8be0f94  sub rsp, 0x30
00007e6bc8be0f98  movaps [rsp], xmm14
00007e6bc8be0f9d  movaps [rsp+0x10], xmm9
00007e6bc8be0fa3  movaps [rsp+0x20], xmm1
00007e6bc8be0fa8  lea rdi, [rsp]
00007e6bc8be0fac  mov esi, 0x00
00007e6bc8be0fb1  mov rax, 0x6543F191D530
00007e6bc8be0fbb  call rax
00007e6bc8be0fbd  movaps xmm14, [rsp]
00007e6bc8be0fc2  add rsp, 0x30
00007e6bc8be0fc6  vmovaps xmm0, [rsp]
00007e6bc8be0fcb  vmovaps xmm1, [rsp+0x10]
00007e6bc8be0fd1  vmovaps xmm2, [rsp+0x20]
00007e6bc8be0fd7  vmovaps xmm3, [rsp+0x30]
00007e6bc8be0fdd  vmovaps xmm4, [rsp+0x40]
00007e6bc8be0fe3  vmovaps xmm5, [rsp+0x50]
00007e6bc8be0fe9  vmovaps xmm6, [rsp+0x60]
00007e6bc8be0fef  vmovaps xmm7, [rsp+0x70]
00007e6bc8be0ff5  vmovaps xmm8, [rsp+0x80]
00007e6bc8be0ffe  vmovaps xmm9, [rsp+0x90]
00007e6bc8be1007  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be1010  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be1019  vmovaps xmm12, [rsp+0xC0]
00007e6bc8be1022  vmovaps xmm13, [rsp+0xD0]
00007e6bc8be102b  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be1034  add rsp, 0xF0
00007e6bc8be103b  pop r11
00007e6bc8be103d  pop r10
00007e6bc8be103f  pop r9
00007e6bc8be1041  pop r8
00007e6bc8be1043  pop rsi
00007e6bc8be1044  pop rdi
00007e6bc8be1045  pop rdx
00007e6bc8be1046  pop rcx
00007e6bc8be1047  pop rax
00007e6bc8be1048  add rsp, 0x08
00007e6bc8be104c  jmp 0x00007E6BC8BDC72B
00007e6bc8be1051  sub rsp, 0x08
00007e6bc8be1055  push rax
00007e6bc8be1056  push rcx
00007e6bc8be1057  push rdx
00007e6bc8be1058  push rdi
00007e6bc8be1059  push rsi
00007e6bc8be105a  push r8
00007e6bc8be105c  push r9
00007e6bc8be105e  push r10
00007e6bc8be1060  push r11
00007e6bc8be1062  sub rsp, 0xF0
00007e6bc8be1069  vmovaps [rsp], xmm0
00007e6bc8be106e  vmovaps [rsp+0x10], xmm2
00007e6bc8be1074  vmovaps [rsp+0x20], xmm3
00007e6bc8be107a  vmovaps [rsp+0x30], xmm4
00007e6bc8be1080  vmovaps [rsp+0x40], xmm5
00007e6bc8be1086  vmovaps [rsp+0x50], xmm6
00007e6bc8be108c  vmovaps [rsp+0x60], xmm7
00007e6bc8be1092  vmovaps [rsp+0x70], xmm8
00007e6bc8be1098  vmovaps [rsp+0x80], xmm9
00007e6bc8be10a1  vmovaps [rsp+0x90], xmm10
00007e6bc8be10aa  vmovaps [rsp+0xA0], xmm11
00007e6bc8be10b3  vmovaps [rsp+0xB0], xmm12
00007e6bc8be10bc  vmovaps [rsp+0xC0], xmm13
00007e6bc8be10c5  vmovaps [rsp+0xD0], xmm14
00007e6bc8be10ce  vmovaps [rsp+0xE0], xmm15
00007e6bc8be10d7  sub rsp, 0x30
00007e6bc8be10db  movaps [rsp], xmm1
00007e6bc8be10df  movaps [rsp+0x10], xmm13
00007e6bc8be10e5  movaps [rsp+0x20], xmm8
00007e6bc8be10eb  lea rdi, [rsp]
00007e6bc8be10ef  mov esi, 0x00
00007e6bc8be10f4  mov rax, 0x6543F191D530
00007e6bc8be10fe  call rax
00007e6bc8be1100  movaps xmm1, [rsp]
00007e6bc8be1104  add rsp, 0x30
00007e6bc8be1108  vmovaps xmm0, [rsp]
00007e6bc8be110d  vmovaps xmm2, [rsp+0x10]
00007e6bc8be1113  vmovaps xmm3, [rsp+0x20]
00007e6bc8be1119  vmovaps xmm4, [rsp+0x30]
00007e6bc8be111f  vmovaps xmm5, [rsp+0x40]
00007e6bc8be1125  vmovaps xmm6, [rsp+0x50]
00007e6bc8be112b  vmovaps xmm7, [rsp+0x60]
00007e6bc8be1131  vmovaps xmm8, [rsp+0x70]
00007e6bc8be1137  vmovaps xmm9, [rsp+0x80]
00007e6bc8be1140  vmovaps xmm10, [rsp+0x90]
00007e6bc8be1149  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be1152  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be115b  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be1164  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be116d  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be1176  add rsp, 0xF0
00007e6bc8be117d  pop r11
00007e6bc8be117f  pop r10
00007e6bc8be1181  pop r9
00007e6bc8be1183  pop r8
00007e6bc8be1185  pop rsi
00007e6bc8be1186  pop rdi
00007e6bc8be1187  pop rdx
00007e6bc8be1188  pop rcx
00007e6bc8be1189  pop rax
00007e6bc8be118a  add rsp, 0x08
00007e6bc8be118e  jmp 0x00007E6BC8BDC74D
00007e6bc8be1193  call 0x00007E6BC8A0C260
00007e6bc8be1198  jmp 0x00007E6BC8BDC75B
00007e6bc8be119d  call 0x00007E6BC8ABD750
00007e6bc8be11a2  jmp 0x00007E6BC8BDC765
00007e6bc8be11a7  sub rsp, 0x08
00007e6bc8be11ab  push rax
00007e6bc8be11ac  push rcx
00007e6bc8be11ad  push rdx
00007e6bc8be11ae  push rdi
00007e6bc8be11af  push rsi
00007e6bc8be11b0  push r8
00007e6bc8be11b2  push r9
00007e6bc8be11b4  push r10
00007e6bc8be11b6  push r11
00007e6bc8be11b8  sub rsp, 0xF0
00007e6bc8be11bf  vmovaps [rsp], xmm0
00007e6bc8be11c4  vmovaps [rsp+0x10], xmm1
00007e6bc8be11ca  vmovaps [rsp+0x20], xmm2
00007e6bc8be11d0  vmovaps [rsp+0x30], xmm3
00007e6bc8be11d6  vmovaps [rsp+0x40], xmm4
00007e6bc8be11dc  vmovaps [rsp+0x50], xmm5
00007e6bc8be11e2  vmovaps [rsp+0x60], xmm6
00007e6bc8be11e8  vmovaps [rsp+0x70], xmm7
00007e6bc8be11ee  vmovaps [rsp+0x80], xmm9
00007e6bc8be11f7  vmovaps [rsp+0x90], xmm10
00007e6bc8be1200  vmovaps [rsp+0xA0], xmm11
00007e6bc8be1209  vmovaps [rsp+0xB0], xmm12
00007e6bc8be1212  vmovaps [rsp+0xC0], xmm13
00007e6bc8be121b  vmovaps [rsp+0xD0], xmm14
00007e6bc8be1224  vmovaps [rsp+0xE0], xmm15
00007e6bc8be122d  sub rsp, 0x30
00007e6bc8be1231  movaps [rsp], xmm8
00007e6bc8be1236  movaps [rsp+0x10], xmm15
00007e6bc8be123c  movaps [rsp+0x20], xmm7
00007e6bc8be1241  lea rdi, [rsp]
00007e6bc8be1245  mov esi, 0x00
00007e6bc8be124a  mov rax, 0x6543F191D530
00007e6bc8be1254  call rax
00007e6bc8be1256  movaps xmm8, [rsp]
00007e6bc8be125b  add rsp, 0x30
00007e6bc8be125f  vmovaps xmm0, [rsp]
00007e6bc8be1264  vmovaps xmm1, [rsp+0x10]
00007e6bc8be126a  vmovaps xmm2, [rsp+0x20]
00007e6bc8be1270  vmovaps xmm3, [rsp+0x30]
00007e6bc8be1276  vmovaps xmm4, [rsp+0x40]
00007e6bc8be127c  vmovaps xmm5, [rsp+0x50]
00007e6bc8be1282  vmovaps xmm6, [rsp+0x60]
00007e6bc8be1288  vmovaps xmm7, [rsp+0x70]
00007e6bc8be128e  vmovaps xmm9, [rsp+0x80]
00007e6bc8be1297  vmovaps xmm10, [rsp+0x90]
00007e6bc8be12a0  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be12a9  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be12b2  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be12bb  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be12c4  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be12cd  add rsp, 0xF0
00007e6bc8be12d4  pop r11
00007e6bc8be12d6  pop r10
00007e6bc8be12d8  pop r9
00007e6bc8be12da  pop r8
00007e6bc8be12dc  pop rsi
00007e6bc8be12dd  pop rdi
00007e6bc8be12de  pop rdx
00007e6bc8be12df  pop rcx
00007e6bc8be12e0  pop rax
00007e6bc8be12e1  add rsp, 0x08
00007e6bc8be12e5  jmp 0x00007E6BC8BDC787
00007e6bc8be12ea  sub rsp, 0x08
00007e6bc8be12ee  push rax
00007e6bc8be12ef  push rcx
00007e6bc8be12f0  push rdx
00007e6bc8be12f1  push rdi
00007e6bc8be12f2  push rsi
00007e6bc8be12f3  push r8
00007e6bc8be12f5  push r9
00007e6bc8be12f7  push r10
00007e6bc8be12f9  push r11
00007e6bc8be12fb  sub rsp, 0xF0
00007e6bc8be1302  vmovaps [rsp], xmm0
00007e6bc8be1307  vmovaps [rsp+0x10], xmm1
00007e6bc8be130d  vmovaps [rsp+0x20], xmm2
00007e6bc8be1313  vmovaps [rsp+0x30], xmm3
00007e6bc8be1319  vmovaps [rsp+0x40], xmm4
00007e6bc8be131f  vmovaps [rsp+0x50], xmm5
00007e6bc8be1325  vmovaps [rsp+0x60], xmm6
00007e6bc8be132b  vmovaps [rsp+0x70], xmm8
00007e6bc8be1331  vmovaps [rsp+0x80], xmm9
00007e6bc8be133a  vmovaps [rsp+0x90], xmm10
00007e6bc8be1343  vmovaps [rsp+0xA0], xmm11
00007e6bc8be134c  vmovaps [rsp+0xB0], xmm12
00007e6bc8be1355  vmovaps [rsp+0xC0], xmm13
00007e6bc8be135e  vmovaps [rsp+0xD0], xmm14
00007e6bc8be1367  vmovaps [rsp+0xE0], xmm15
00007e6bc8be1370  sub rsp, 0x30
00007e6bc8be1374  movaps [rsp], xmm7
00007e6bc8be1378  movaps [rsp+0x10], xmm9
00007e6bc8be137e  movaps [rsp+0x20], xmm15
00007e6bc8be1384  lea rdi, [rsp]
00007e6bc8be1388  mov esi, 0x00
00007e6bc8be138d  mov rax, 0x6543F191D530
00007e6bc8be1397  call rax
00007e6bc8be1399  movaps xmm7, [rsp]
00007e6bc8be139d  add rsp, 0x30
00007e6bc8be13a1  vmovaps xmm0, [rsp]
00007e6bc8be13a6  vmovaps xmm1, [rsp+0x10]
00007e6bc8be13ac  vmovaps xmm2, [rsp+0x20]
00007e6bc8be13b2  vmovaps xmm3, [rsp+0x30]
00007e6bc8be13b8  vmovaps xmm4, [rsp+0x40]
00007e6bc8be13be  vmovaps xmm5, [rsp+0x50]
00007e6bc8be13c4  vmovaps xmm6, [rsp+0x60]
00007e6bc8be13ca  vmovaps xmm8, [rsp+0x70]
00007e6bc8be13d0  vmovaps xmm9, [rsp+0x80]
00007e6bc8be13d9  vmovaps xmm10, [rsp+0x90]
00007e6bc8be13e2  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be13eb  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be13f4  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be13fd  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be1406  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be140f  add rsp, 0xF0
00007e6bc8be1416  pop r11
00007e6bc8be1418  pop r10
00007e6bc8be141a  pop r9
00007e6bc8be141c  pop r8
00007e6bc8be141e  pop rsi
00007e6bc8be141f  pop rdi
00007e6bc8be1420  pop rdx
00007e6bc8be1421  pop rcx
00007e6bc8be1422  pop rax
00007e6bc8be1423  add rsp, 0x08
00007e6bc8be1427  jmp 0x00007E6BC8BDC7B4
00007e6bc8be142c  sub rsp, 0x08
00007e6bc8be1430  push rax
00007e6bc8be1431  push rcx
00007e6bc8be1432  push rdx
00007e6bc8be1433  push rdi
00007e6bc8be1434  push rsi
00007e6bc8be1435  push r8
00007e6bc8be1437  push r9
00007e6bc8be1439  push r10
00007e6bc8be143b  push r11
00007e6bc8be143d  sub rsp, 0xF0
00007e6bc8be1444  vmovaps [rsp], xmm0
00007e6bc8be1449  vmovaps [rsp+0x10], xmm1
00007e6bc8be144f  vmovaps [rsp+0x20], xmm2
00007e6bc8be1455  vmovaps [rsp+0x30], xmm3
00007e6bc8be145b  vmovaps [rsp+0x40], xmm4
00007e6bc8be1461  vmovaps [rsp+0x50], xmm5
00007e6bc8be1467  vmovaps [rsp+0x60], xmm6
00007e6bc8be146d  vmovaps [rsp+0x70], xmm7
00007e6bc8be1473  vmovaps [rsp+0x80], xmm8
00007e6bc8be147c  vmovaps [rsp+0x90], xmm10
00007e6bc8be1485  vmovaps [rsp+0xA0], xmm11
00007e6bc8be148e  vmovaps [rsp+0xB0], xmm12
00007e6bc8be1497  vmovaps [rsp+0xC0], xmm13
00007e6bc8be14a0  vmovaps [rsp+0xD0], xmm14
00007e6bc8be14a9  vmovaps [rsp+0xE0], xmm15
00007e6bc8be14b2  sub rsp, 0x30
00007e6bc8be14b6  movaps [rsp], xmm9
00007e6bc8be14bb  movaps [rsp+0x10], xmm13
00007e6bc8be14c1  movaps [rsp+0x20], xmm15
00007e6bc8be14c7  lea rdi, [rsp]
00007e6bc8be14cb  mov esi, 0x00
00007e6bc8be14d0  mov rax, 0x6543F191D530
00007e6bc8be14da  call rax
00007e6bc8be14dc  movaps xmm9, [rsp]
00007e6bc8be14e1  add rsp, 0x30
00007e6bc8be14e5  vmovaps xmm0, [rsp]
00007e6bc8be14ea  vmovaps xmm1, [rsp+0x10]
00007e6bc8be14f0  vmovaps xmm2, [rsp+0x20]
00007e6bc8be14f6  vmovaps xmm3, [rsp+0x30]
00007e6bc8be14fc  vmovaps xmm4, [rsp+0x40]
00007e6bc8be1502  vmovaps xmm5, [rsp+0x50]
00007e6bc8be1508  vmovaps xmm6, [rsp+0x60]
00007e6bc8be150e  vmovaps xmm7, [rsp+0x70]
00007e6bc8be1514  vmovaps xmm8, [rsp+0x80]
00007e6bc8be151d  vmovaps xmm10, [rsp+0x90]
00007e6bc8be1526  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be152f  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be1538  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be1541  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be154a  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be1553  add rsp, 0xF0
00007e6bc8be155a  pop r11
00007e6bc8be155c  pop r10
00007e6bc8be155e  pop r9
00007e6bc8be1560  pop r8
00007e6bc8be1562  pop rsi
00007e6bc8be1563  pop rdi
00007e6bc8be1564  pop rdx
00007e6bc8be1565  pop rcx
00007e6bc8be1566  pop rax
00007e6bc8be1567  add rsp, 0x08
00007e6bc8be156b  jmp 0x00007E6BC8BDC7E2
00007e6bc8be1570  sub rsp, 0x08
00007e6bc8be1574  push rax
00007e6bc8be1575  push rcx
00007e6bc8be1576  push rdx
00007e6bc8be1577  push rdi
00007e6bc8be1578  push rsi
00007e6bc8be1579  push r8
00007e6bc8be157b  push r9
00007e6bc8be157d  push r10
00007e6bc8be157f  push r11
00007e6bc8be1581  sub rsp, 0xF0
00007e6bc8be1588  vmovaps [rsp], xmm0
00007e6bc8be158d  vmovaps [rsp+0x10], xmm1
00007e6bc8be1593  vmovaps [rsp+0x20], xmm2
00007e6bc8be1599  vmovaps [rsp+0x30], xmm3
00007e6bc8be159f  vmovaps [rsp+0x40], xmm4
00007e6bc8be15a5  vmovaps [rsp+0x50], xmm5
00007e6bc8be15ab  vmovaps [rsp+0x60], xmm6
00007e6bc8be15b1  vmovaps [rsp+0x70], xmm7
00007e6bc8be15b7  vmovaps [rsp+0x80], xmm8
00007e6bc8be15c0  vmovaps [rsp+0x90], xmm9
00007e6bc8be15c9  vmovaps [rsp+0xA0], xmm10
00007e6bc8be15d2  vmovaps [rsp+0xB0], xmm11
00007e6bc8be15db  vmovaps [rsp+0xC0], xmm12
00007e6bc8be15e4  vmovaps [rsp+0xD0], xmm13
00007e6bc8be15ed  vmovaps [rsp+0xE0], xmm14
00007e6bc8be15f6  sub rsp, 0x30
00007e6bc8be15fa  movaps [rsp], xmm15
00007e6bc8be15ff  movaps [rsp+0x10], xmm11
00007e6bc8be1605  movaps [rsp+0x20], xmm12
00007e6bc8be160b  lea rdi, [rsp]
00007e6bc8be160f  mov esi, 0x00
00007e6bc8be1614  mov rax, 0x6543F191D530
00007e6bc8be161e  call rax
00007e6bc8be1620  movaps xmm15, [rsp]
00007e6bc8be1625  add rsp, 0x30
00007e6bc8be1629  vmovaps xmm0, [rsp]
00007e6bc8be162e  vmovaps xmm1, [rsp+0x10]
00007e6bc8be1634  vmovaps xmm2, [rsp+0x20]
00007e6bc8be163a  vmovaps xmm3, [rsp+0x30]
00007e6bc8be1640  vmovaps xmm4, [rsp+0x40]
00007e6bc8be1646  vmovaps xmm5, [rsp+0x50]
00007e6bc8be164c  vmovaps xmm6, [rsp+0x60]
00007e6bc8be1652  vmovaps xmm7, [rsp+0x70]
00007e6bc8be1658  vmovaps xmm8, [rsp+0x80]
00007e6bc8be1661  vmovaps xmm9, [rsp+0x90]
00007e6bc8be166a  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be1673  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be167c  vmovaps xmm12, [rsp+0xC0]
00007e6bc8be1685  vmovaps xmm13, [rsp+0xD0]
00007e6bc8be168e  vmovaps xmm14, [rsp+0xE0]
00007e6bc8be1697  add rsp, 0xF0
00007e6bc8be169e  pop r11
00007e6bc8be16a0  pop r10
00007e6bc8be16a2  pop r9
00007e6bc8be16a4  pop r8
00007e6bc8be16a6  pop rsi
00007e6bc8be16a7  pop rdi
00007e6bc8be16a8  pop rdx
00007e6bc8be16a9  pop rcx
00007e6bc8be16aa  pop rax
00007e6bc8be16ab  add rsp, 0x08
00007e6bc8be16af  jmp 0x00007E6BC8BDC7FD
00007e6bc8be16b4  sub rsp, 0x08
00007e6bc8be16b8  push rax
00007e6bc8be16b9  push rcx
00007e6bc8be16ba  push rdx
00007e6bc8be16bb  push rdi
00007e6bc8be16bc  push rsi
00007e6bc8be16bd  push r8
00007e6bc8be16bf  push r9
00007e6bc8be16c1  push r10
00007e6bc8be16c3  push r11
00007e6bc8be16c5  sub rsp, 0xF0
00007e6bc8be16cc  vmovaps [rsp], xmm0
00007e6bc8be16d1  vmovaps [rsp+0x10], xmm1
00007e6bc8be16d7  vmovaps [rsp+0x20], xmm2
00007e6bc8be16dd  vmovaps [rsp+0x30], xmm3
00007e6bc8be16e3  vmovaps [rsp+0x40], xmm4
00007e6bc8be16e9  vmovaps [rsp+0x50], xmm5
00007e6bc8be16ef  vmovaps [rsp+0x60], xmm6
00007e6bc8be16f5  vmovaps [rsp+0x70], xmm7
00007e6bc8be16fb  vmovaps [rsp+0x80], xmm8
00007e6bc8be1704  vmovaps [rsp+0x90], xmm9
00007e6bc8be170d  vmovaps [rsp+0xA0], xmm10
00007e6bc8be1716  vmovaps [rsp+0xB0], xmm11
00007e6bc8be171f  vmovaps [rsp+0xC0], xmm12
00007e6bc8be1728  vmovaps [rsp+0xD0], xmm14
00007e6bc8be1731  vmovaps [rsp+0xE0], xmm15
00007e6bc8be173a  sub rsp, 0x30
00007e6bc8be173e  movaps [rsp], xmm13
00007e6bc8be1743  movaps [rsp+0x10], xmm10
00007e6bc8be1749  movaps [rsp+0x20], xmm14
00007e6bc8be174f  lea rdi, [rsp]
00007e6bc8be1753  mov esi, 0x00
00007e6bc8be1758  mov rax, 0x6543F191D530
00007e6bc8be1762  call rax
00007e6bc8be1764  movaps xmm13, [rsp]
00007e6bc8be1769  add rsp, 0x30
00007e6bc8be176d  vmovaps xmm0, [rsp]
00007e6bc8be1772  vmovaps xmm1, [rsp+0x10]
00007e6bc8be1778  vmovaps xmm2, [rsp+0x20]
00007e6bc8be177e  vmovaps xmm3, [rsp+0x30]
00007e6bc8be1784  vmovaps xmm4, [rsp+0x40]
00007e6bc8be178a  vmovaps xmm5, [rsp+0x50]
00007e6bc8be1790  vmovaps xmm6, [rsp+0x60]
00007e6bc8be1796  vmovaps xmm7, [rsp+0x70]
00007e6bc8be179c  vmovaps xmm8, [rsp+0x80]
00007e6bc8be17a5  vmovaps xmm9, [rsp+0x90]
00007e6bc8be17ae  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be17b7  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be17c0  vmovaps xmm12, [rsp+0xC0]
00007e6bc8be17c9  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be17d2  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be17db  add rsp, 0xF0
00007e6bc8be17e2  pop r11
00007e6bc8be17e4  pop r10
00007e6bc8be17e6  pop r9
00007e6bc8be17e8  pop r8
00007e6bc8be17ea  pop rsi
00007e6bc8be17eb  pop rdi
00007e6bc8be17ec  pop rdx
00007e6bc8be17ed  pop rcx
00007e6bc8be17ee  pop rax
00007e6bc8be17ef  add rsp, 0x08
00007e6bc8be17f3  jmp 0x00007E6BC8BDC820
00007e6bc8be17f8  sub rsp, 0x08
00007e6bc8be17fc  push rax
00007e6bc8be17fd  push rcx
00007e6bc8be17fe  push rdx
00007e6bc8be17ff  push rdi
00007e6bc8be1800  push rsi
00007e6bc8be1801  push r8
00007e6bc8be1803  push r9
00007e6bc8be1805  push r10
00007e6bc8be1807  push r11
00007e6bc8be1809  sub rsp, 0xF0
00007e6bc8be1810  vmovaps [rsp], xmm0
00007e6bc8be1815  vmovaps [rsp+0x10], xmm1
00007e6bc8be181b  vmovaps [rsp+0x20], xmm2
00007e6bc8be1821  vmovaps [rsp+0x30], xmm3
00007e6bc8be1827  vmovaps [rsp+0x40], xmm4
00007e6bc8be182d  vmovaps [rsp+0x50], xmm5
00007e6bc8be1833  vmovaps [rsp+0x60], xmm6
00007e6bc8be1839  vmovaps [rsp+0x70], xmm7
00007e6bc8be183f  vmovaps [rsp+0x80], xmm8
00007e6bc8be1848  vmovaps [rsp+0x90], xmm9
00007e6bc8be1851  vmovaps [rsp+0xA0], xmm10
00007e6bc8be185a  vmovaps [rsp+0xB0], xmm11
00007e6bc8be1863  vmovaps [rsp+0xC0], xmm12
00007e6bc8be186c  vmovaps [rsp+0xD0], xmm13
00007e6bc8be1875  vmovaps [rsp+0xE0], xmm15
00007e6bc8be187e  sub rsp, 0x30
00007e6bc8be1882  movaps [rsp], xmm14
00007e6bc8be1887  movaps [rsp+0x10], xmm1
00007e6bc8be188c  movaps [rsp+0x20], xmm7
00007e6bc8be1891  lea rdi, [rsp]
00007e6bc8be1895  mov esi, 0x00
00007e6bc8be189a  mov rax, 0x6543F191D530
00007e6bc8be18a4  call rax
00007e6bc8be18a6  movaps xmm14, [rsp]
00007e6bc8be18ab  add rsp, 0x30
00007e6bc8be18af  vmovaps xmm0, [rsp]
00007e6bc8be18b4  vmovaps xmm1, [rsp+0x10]
00007e6bc8be18ba  vmovaps xmm2, [rsp+0x20]
00007e6bc8be18c0  vmovaps xmm3, [rsp+0x30]
00007e6bc8be18c6  vmovaps xmm4, [rsp+0x40]
00007e6bc8be18cc  vmovaps xmm5, [rsp+0x50]
00007e6bc8be18d2  vmovaps xmm6, [rsp+0x60]
00007e6bc8be18d8  vmovaps xmm7, [rsp+0x70]
00007e6bc8be18de  vmovaps xmm8, [rsp+0x80]
00007e6bc8be18e7  vmovaps xmm9, [rsp+0x90]
00007e6bc8be18f0  vmovaps xmm10, [rsp+0xA0]
00007e6bc8be18f9  vmovaps xmm11, [rsp+0xB0]
00007e6bc8be1902  vmovaps xmm12, [rsp+0xC0]
00007e6bc8be190b  vmovaps xmm13, [rsp+0xD0]
00007e6bc8be1914  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be191d  add rsp, 0xF0
00007e6bc8be1924  pop r11
00007e6bc8be1926  pop r10
00007e6bc8be1928  pop r9
00007e6bc8be192a  pop r8
00007e6bc8be192c  pop rsi
00007e6bc8be192d  pop rdi
00007e6bc8be192e  pop rdx
00007e6bc8be192f  pop rcx
00007e6bc8be1930  pop rax
00007e6bc8be1931  add rsp, 0x08
00007e6bc8be1935  jmp 0x00007E6BC8BDC843
00007e6bc8be193a  sub rsp, 0x08
00007e6bc8be193e  push rax
00007e6bc8be193f  push rcx
00007e6bc8be1940  push rdx
00007e6bc8be1941  push rdi
00007e6bc8be1942  push rsi
00007e6bc8be1943  push r8
00007e6bc8be1945  push r9
00007e6bc8be1947  push r10
00007e6bc8be1949  push r11
00007e6bc8be194b  sub rsp, 0xF0
00007e6bc8be1952  vmovaps [rsp], xmm0
00007e6bc8be1957  vmovaps [rsp+0x10], xmm2
00007e6bc8be195d  vmovaps [rsp+0x20], xmm3
00007e6bc8be1963  vmovaps [rsp+0x30], xmm4
00007e6bc8be1969  vmovaps [rsp+0x40], xmm5
00007e6bc8be196f  vmovaps [rsp+0x50], xmm6
00007e6bc8be1975  vmovaps [rsp+0x60], xmm7
00007e6bc8be197b  vmovaps [rsp+0x70], xmm8
00007e6bc8be1981  vmovaps [rsp+0x80], xmm9
00007e6bc8be198a  vmovaps [rsp+0x90], xmm10
00007e6bc8be1993  vmovaps [rsp+0xA0], xmm11
00007e6bc8be199c  vmovaps [rsp+0xB0], xmm12
00007e6bc8be19a5  vmovaps [rsp+0xC0], xmm13
00007e6bc8be19ae  vmovaps [rsp+0xD0], xmm14
00007e6bc8be19b7  vmovaps [rsp+0xE0], xmm15
00007e6bc8be19c0  sub rsp, 0x30
00007e6bc8be19c4  movaps [rsp], xmm1
00007e6bc8be19c8  movaps [rsp+0x10], xmm8
00007e6bc8be19ce  movaps [rsp+0x20], xmm9
00007e6bc8be19d4  lea rdi, [rsp]
00007e6bc8be19d8  mov esi, 0x00
00007e6bc8be19dd  mov rax, 0x6543F191D530
00007e6bc8be19e7  call rax
00007e6bc8be19e9  movaps xmm1, [rsp]
00007e6bc8be19ed  add rsp, 0x30
00007e6bc8be19f1  vmovaps xmm0, [rsp]
00007e6bc8be19f6  vmovaps xmm2, [rsp+0x10]
00007e6bc8be19fc  vmovaps xmm3, [rsp+0x20]
00007e6bc8be1a02  vmovaps xmm4, [rsp+0x30]
00007e6bc8be1a08  vmovaps xmm5, [rsp+0x40]
00007e6bc8be1a0e  vmovaps xmm6, [rsp+0x50]
00007e6bc8be1a14  vmovaps xmm7, [rsp+0x60]
00007e6bc8be1a1a  vmovaps xmm8, [rsp+0x70]
00007e6bc8be1a20  vmovaps xmm9, [rsp+0x80]
00007e6bc8be1a29  vmovaps xmm10, [rsp+0x90]
00007e6bc8be1a32  vmovaps xmm11, [rsp+0xA0]
00007e6bc8be1a3b  vmovaps xmm12, [rsp+0xB0]
00007e6bc8be1a44  vmovaps xmm13, [rsp+0xC0]
00007e6bc8be1a4d  vmovaps xmm14, [rsp+0xD0]
00007e6bc8be1a56  vmovaps xmm15, [rsp+0xE0]
00007e6bc8be1a5f  add rsp, 0xF0
00007e6bc8be1a66  pop r11
00007e6bc8be1a68  pop r10
00007e6bc8be1a6a  pop r9
00007e6bc8be1a6c  pop r8
00007e6bc8be1a6e  pop rsi
00007e6bc8be1a6f  pop rdi
00007e6bc8be1a70  pop rdx
00007e6bc8be1a71  pop rcx
00007e6bc8be1a72  pop rax
00007e6bc8be1a73  add rsp, 0x08
00007e6bc8be1a77  jmp 0x00007E6BC8BDC865
00007e6bc8be1a7c  call 0x00007E6BC8AE5940
00007e6bc8be1a81  jmp 0x00007E6BC8BDC873
00007e6bc8be1a86  call 0x00007E6BC8A0C380
00007e6bc8be1a8b  jmp 0x00007E6BC8BDC87D
00007e6bc8be1a90  call 0x00007E6BC8A0D600
00007e6bc8be1a95  jmp 0x00007E6BC8BDC887
00007e6bc8be1a9a  call 0x00007E6BC89FF540
00007e6bc8be1a9f  jmp 0x00007E6BC8BDC891
00007e6bc8be1aa4  int3
00007e6bc8be1aa5  nop [rax+rax*1], ax
00007e6bc8be1aae  nop
00007e6bc8be1ab0  mov rax, [r15+0xF8]
00007e6bc8be1ab7  lea r14, [rax+0x140]
00007e6bc8be1abe  mov r12, [r13+r14*1]
00007e6bc8be1ac3  mov [r15+0xE8], r12
00007e6bc8be1aca  lea r14, [rax+0x130]
00007e6bc8be1ad1  mov r12, [r13+r14*1]
00007e6bc8be1ad6  lea r14, [rax+0x138]
00007e6bc8be1add  mov r11, [r13+r14*1]
00007e6bc8be1ae2  movq xmm1, r12
00007e6bc8be1ae7  movq xmm15, r11
00007e6bc8be1aec  movq xmm1, xmm1
00007e6bc8be1af0  movq xmm1, xmm1
00007e6bc8be1af4  movaps [r15+0x1A0], xmm1
00007e6bc8be1afc  movq xmm15, xmm15
00007e6bc8be1b01  movq xmm15, xmm15
00007e6bc8be1b06  movaps [r15+0x190], xmm15
00007e6bc8be1b0e  lea r14, [rax+0x120]
00007e6bc8be1b15  mov r12, [r13+r14*1]
00007e6bc8be1b1a  lea r14, [rax+0x128]
00007e6bc8be1b21  mov r11, [r13+r14*1]
00007e6bc8be1b26  movq xmm1, r12
00007e6bc8be1b2b  movq xmm15, r11
00007e6bc8be1b30  movq xmm1, xmm1
00007e6bc8be1b34  movq xmm1, xmm1
00007e6bc8be1b38  movaps [r15+0x1C0], xmm1
00007e6bc8be1b40  movq xmm15, xmm15
00007e6bc8be1b45  movq xmm15, xmm15
00007e6bc8be1b4a  movaps [r15+0x1B0], xmm15
00007e6bc8be1b52  lea r14, [rax+0x110]
00007e6bc8be1b59  mov r12, [r13+r14*1]
00007e6bc8be1b5e  lea r14, [rax+0x118]
00007e6bc8be1b65  mov r11, [r13+r14*1]
00007e6bc8be1b6a  movq xmm1, r12
00007e6bc8be1b6f  movq xmm15, r11
00007e6bc8be1b74  movq xmm1, xmm1
00007e6bc8be1b78  movq xmm1, xmm1
00007e6bc8be1b7c  movaps [r15+0x1E0], xmm1
00007e6bc8be1b84  movq xmm15, xmm15
00007e6bc8be1b89  movq xmm15, xmm15
00007e6bc8be1b8e  movaps [r15+0x1D0], xmm15
00007e6bc8be1b96  lea r14, [rax+0x100]
00007e6bc8be1b9d  mov r12, [r13+r14*1]
00007e6bc8be1ba2  lea r14, [rax+0x108]
00007e6bc8be1ba9  mov r11, [r13+r14*1]
00007e6bc8be1bae  movq xmm1, r12
00007e6bc8be1bb3  movq xmm15, r11
00007e6bc8be1bb8  movq xmm1, xmm1
00007e6bc8be1bbc  movq xmm1, xmm1
00007e6bc8be1bc0  movaps [r15+0x200], xmm1
00007e6bc8be1bc8  movq xmm15, xmm15
00007e6bc8be1bcd  movq xmm15, xmm15
00007e6bc8be1bd2  movaps [r15+0x1F0], xmm15
00007e6bc8be1bda  mov qword ptr [r15+0x40], 0x430000
00007e6bc8be1be2  mov r14d, 0x430510
00007e6bc8be1be8  mov r12, [r13+r14*1]
00007e6bc8be1bed  movq xmm1, r12
00007e6bc8be1bf2  lea r14, [rax+0x150]
00007e6bc8be1bf9  mov [r15+0xF8], r14
00007e6bc8be1c00  mov rax, [r15+0x50]
00007e6bc8be1c04  movups xmm15, [r13+rax*1]
00007e6bc8be1c0a  movaps [r15+0x120], xmm15
00007e6bc8be1c12  mov qword ptr [r15+0x48], 0x10
00007e6bc8be1c1a  xor eax, eax
00007e6bc8be1c1c  mov r14d, 0x10
00007e6bc8be1c22  mov r12d, 0x200
00007e6bc8be1c28  cmp r14, r12
00007e6bc8be1c2b  cmc
00007e6bc8be1c2c  lahf
00007e6bc8be1c2d  seto al
00007e6bc8be1c30  mov [r15+0x108], eax
00007e6bc8be1c37  pextrq rax, xmm15, 0x01
00007e6bc8be1c3e  movq xmm14, rax
00007e6bc8be1c43  movaps [r15+0x130], xmm14
00007e6bc8be1c4b  movq rax, xmm1
00007e6bc8be1c50  movq r14, xmm15
00007e6bc8be1c55  vmovq xmm1, rax
00007e6bc8be1c5a  vmovq xmm15, r14
00007e6bc8be1c5f  movaps xmm13, xmm1
00007e6bc8be1c63  addsd xmm13, xmm15
00007e6bc8be1c68  ucomisd xmm13, xmm13
00007e6bc8be1c6d  jp 0x00007E6BC8BE1D86
00007e6bc8be1c73  movq xmm13, xmm13
00007e6bc8be1c78  movq rax, xmm13
00007e6bc8be1c7d  movq r14, xmm14
00007e6bc8be1c82  vmovq xmm1, rax
00007e6bc8be1c87  vmovq xmm15, r14
00007e6bc8be1c8c  movaps xmm14, xmm1
00007e6bc8be1c90  addsd xmm14, xmm15
00007e6bc8be1c95  ucomisd xmm14, xmm14
00007e6bc8be1c9a  jp 0x00007E6BC8BE1DCE
00007e6bc8be1ca0  movq xmm14, xmm14
00007e6bc8be1ca5  movaps [r15+0x110], xmm14
00007e6bc8be1cad  mov eax, [r15+0x108]
00007e6bc8be1cb4  sahf
00007e6bc8be1cb5  jnz 0x00007E6BC8BE1CE7
00007e6bc8be1cb7  cmp dword ptr [r15+0x318], 0x00
00007e6bc8be1cbf  jz 0x00007E6BC8BE1FE0
00007e6bc8be1cc5  nop [rax+rax*1], ax
00007e6bc8be1cce  nop [rax+rax*1], eax
00007e6bc8be1cd6  mov eax, 0x410490
00007e6bc8be1cdb  mov [r15+0x100], rax
00007e6bc8be1ce2  jmp 0x00007E6BC89FE110
00007e6bc8be1ce7  cmp dword ptr [r15+0x318], 0x00
00007e6bc8be1cef  jz 0x00007E6BC8BE1E20
00007e6bc8be1cf5  nop [rax+rax*1], ax
00007e6bc8be1cfe  nop [rax+rax*1], eax
00007e6bc8be1d06  mov eax, 0x410474
00007e6bc8be1d0b  mov [r15+0x100], rax
00007e6bc8be1d12  jmp 0x00007E6BC89FE110
00007e6bc8be1d17  int3
00007e6bc8be1d18  call 0x00007E6BC8AE27E0
00007e6bc8be1d1d  jmp 0x00007E6BC8BE1AC3
00007e6bc8be1d22  call 0x00007E6BC8AE27E0
00007e6bc8be1d27  jmp 0x00007E6BC8BE1AD6
00007e6bc8be1d2c  call 0x00007E6BC8AE1570
00007e6bc8be1d31  jmp 0x00007E6BC8BE1AE2
00007e6bc8be1d36  call 0x00007E6BC8AE27E0
00007e6bc8be1d3b  jmp 0x00007E6BC8BE1B1A
00007e6bc8be1d40  call 0x00007E6BC8AE1570
00007e6bc8be1d45  jmp 0x00007E6BC8BE1B26
00007e6bc8be1d4a  call 0x00007E6BC8AE27E0
00007e6bc8be1d4f  jmp 0x00007E6BC8BE1B5E
00007e6bc8be1d54  call 0x00007E6BC8AE1570
00007e6bc8be1d59  jmp 0x00007E6BC8BE1B6A
00007e6bc8be1d5e  call 0x00007E6BC8AE27E0
00007e6bc8be1d63  jmp 0x00007E6BC8BE1BA2
00007e6bc8be1d68  call 0x00007E6BC8AE1570
00007e6bc8be1d6d  jmp 0x00007E6BC8BE1BAE
00007e6bc8be1d72  call 0x00007E6BC8AE27E0
00007e6bc8be1d77  jmp 0x00007E6BC8BE1BED
00007e6bc8be1d7c  call 0x00007E6BC8A0E760
00007e6bc8be1d81  jmp 0x00007E6BC8BE1C0A
00007e6bc8be1d86  ucomisd xmm1, xmm15
00007e6bc8be1d8b  jp 0x00007E6BC8BE1D9A
00007e6bc8be1d8d  movaps xmm13, [0x00007E6BC87FE060]
00007e6bc8be1d95  jmp 0x00007E6BC8BE1C73
00007e6bc8be1d9a  vxorps xmm0, xmm1, xmm15
00007e6bc8be1d9f  pextrw eax, xmm0, 0x03
00007e6bc8be1da4  and eax, 0x7FF8
00007e6bc8be1da9  cmp eax, 0x08
00007e6bc8be1dac  jnz 0x00007E6BC8BE1C73
00007e6bc8be1db2  movq rax, xmm15
00007e6bc8be1db7  shl rax, 0x0D
00007e6bc8be1dbb  jbe 0x00007E6BC8BE1C73
00007e6bc8be1dc1  vorps xmm13, xmm15, [0x00007E6BC87FE070]
00007e6bc8be1dc9  jmp 0x00007E6BC8BE1C73
00007e6bc8be1dce  ucomisd xmm1, xmm15
00007e6bc8be1dd3  jp 0x00007E6BC8BE1DE2
00007e6bc8be1dd5  movaps xmm14, [0x00007E6BC87FE060]
00007e6bc8be1ddd  jmp 0x00007E6BC8BE1CA0
00007e6bc8be1de2  vxorps xmm0, xmm1, xmm15
00007e6bc8be1de7  pextrw eax, xmm0, 0x03
00007e6bc8be1dec  and eax, 0x7FF8
00007e6bc8be1df1  cmp eax, 0x08
00007e6bc8be1df4  jnz 0x00007E6BC8BE1CA0
00007e6bc8be1dfa  movq rax, xmm15
00007e6bc8be1dff  shl rax, 0x0D
00007e6bc8be1e03  jbe 0x00007E6BC8BE1CA0
00007e6bc8be1e09  vorps xmm14, xmm15, [0x00007E6BC87FE070]
00007e6bc8be1e11  jmp 0x00007E6BC8BE1CA0
00007e6bc8be1e16  int3
00007e6bc8be1e17  nop [rax+rax*1], ax
00007e6bc8be1e20  mov rax, [r15+0x48]
00007e6bc8be1e24  mov r14, [r15+0x50]
00007e6bc8be1e28  lea r12, [r14+rax*1]
00007e6bc8be1e2c  movups xmm1, [r13+r12*1]
00007e6bc8be1e32  movaps [r15+0x120], xmm1
00007e6bc8be1e3a  lea r14, [rax+0x10]
00007e6bc8be1e3e  mov [r15+0x48], r14
00007e6bc8be1e42  xor eax, eax
00007e6bc8be1e44  mov r12d, 0x200
00007e6bc8be1e4a  cmp r14, r12
00007e6bc8be1e4d  cmc
00007e6bc8be1e4e  lahf
00007e6bc8be1e4f  seto al
00007e6bc8be1e52  mov [r15+0x108], eax
00007e6bc8be1e59  pextrq rax, xmm1, 0x01
00007e6bc8be1e60  movq xmm15, rax
00007e6bc8be1e65  movaps [r15+0x130], xmm15
00007e6bc8be1e6d  movaps xmm14, [r15+0x110]
00007e6bc8be1e75  movq rax, xmm14
00007e6bc8be1e7a  movq r14, xmm1
00007e6bc8be1e7f  vmovq xmm1, rax
00007e6bc8be1e84  vmovq xmm14, r14
00007e6bc8be1e89  movaps xmm13, xmm1
00007e6bc8be1e8d  addsd xmm13, xmm14
00007e6bc8be1e92  ucomisd xmm13, xmm13
00007e6bc8be1e97  jp 0x00007E6BC8BE1F4C
00007e6bc8be1e9d  movq xmm13, xmm13
00007e6bc8be1ea2  movq rax, xmm13
00007e6bc8be1ea7  movq r14, xmm15
00007e6bc8be1eac  vmovq xmm1, rax
00007e6bc8be1eb1  vmovq xmm15, r14
00007e6bc8be1eb6  movaps xmm14, xmm1
00007e6bc8be1eba  addsd xmm14, xmm15
00007e6bc8be1ebf  ucomisd xmm14, xmm14
00007e6bc8be1ec4  jp 0x00007E6BC8BE1F94
00007e6bc8be1eca  movq xmm14, xmm14
00007e6bc8be1ecf  movaps [r15+0x110], xmm14
00007e6bc8be1ed7  mov eax, [r15+0x108]
00007e6bc8be1ede  sahf
00007e6bc8be1edf  jnz 0x00007E6BC8BE1F11
00007e6bc8be1ee1  cmp dword ptr [r15+0x318], 0x00
00007e6bc8be1ee9  jz 0x00007E6BC8BE1FE0
00007e6bc8be1eef  nop [rax+rax*1], ax
00007e6bc8be1ef8  nop [rax+rax*1], eax
00007e6bc8be1f00  mov eax, 0x410490
00007e6bc8be1f05  mov [r15+0x100], rax
00007e6bc8be1f0c  jmp 0x00007E6BC89FE110
00007e6bc8be1f11  cmp dword ptr [r15+0x318], 0x00
00007e6bc8be1f19  jz 0x00007E6BC8BE1E20
00007e6bc8be1f1f  nop [rax+rax*1], ax
00007e6bc8be1f28  nop [rax+rax*1], eax
00007e6bc8be1f30  mov eax, 0x410474
00007e6bc8be1f35  mov [r15+0x100], rax
00007e6bc8be1f3c  jmp 0x00007E6BC89FE110
00007e6bc8be1f41  int3
00007e6bc8be1f42  call 0x00007E6BC8AB52F0
00007e6bc8be1f47  jmp 0x00007E6BC8BE1E32
00007e6bc8be1f4c  ucomisd xmm1, xmm14
00007e6bc8be1f51  jp 0x00007E6BC8BE1F60
00007e6bc8be1f53  movaps xmm13, [0x00007E6BC87FE060]
00007e6bc8be1f5b  jmp 0x00007E6BC8BE1E9D
00007e6bc8be1f60  vxorps xmm0, xmm1, xmm14
00007e6bc8be1f65  pextrw eax, xmm0, 0x03
00007e6bc8be1f6a  and eax, 0x7FF8
00007e6bc8be1f6f  cmp eax, 0x08
00007e6bc8be1f72  jnz 0x00007E6BC8BE1E9D
00007e6bc8be1f78  movq rax, xmm14
00007e6bc8be1f7d  shl rax, 0x0D
00007e6bc8be1f81  jbe 0x00007E6BC8BE1E9D
00007e6bc8be1f87  vorps xmm13, xmm14, [0x00007E6BC87FE070]
00007e6bc8be1f8f  jmp 0x00007E6BC8BE1E9D
00007e6bc8be1f94  ucomisd xmm1, xmm15
00007e6bc8be1f99  jp 0x00007E6BC8BE1FA8
00007e6bc8be1f9b  movaps xmm14, [0x00007E6BC87FE060]
00007e6bc8be1fa3  jmp 0x00007E6BC8BE1ECA
00007e6bc8be1fa8  vxorps xmm0, xmm1, xmm15
00007e6bc8be1fad  pextrw eax, xmm0, 0x03
00007e6bc8be1fb2  and eax, 0x7FF8
00007e6bc8be1fb7  cmp eax, 0x08
00007e6bc8be1fba  jnz 0x00007E6BC8BE1ECA
00007e6bc8be1fc0  movq rax, xmm15
00007e6bc8be1fc5  shl rax, 0x0D
00007e6bc8be1fc9  jbe 0x00007E6BC8BE1ECA
00007e6bc8be1fcf  vorps xmm14, xmm15, [0x00007E6BC87FE070]
00007e6bc8be1fd7  jmp 0x00007E6BC8BE1ECA
00007e6bc8be1fdc  int3
00007e6bc8be1fdd  nop [rax], eax
00007e6bc8be1fe0  mov rax, [r15+0x40]
00007e6bc8be1fe4  lea r14, [rax+0x510]
00007e6bc8be1feb  movaps xmm1, [r15+0x110]
00007e6bc8be1ff3  movq rax, xmm1
00007e6bc8be1ff8  mov [r13+r14*1], rax
00007e6bc8be1ffd  mov rax, [r15+0xF0]
00007e6bc8be2004  mov [r15+0x100], rax
00007e6bc8be200b  jmp 0x00007E6BC8BCE5C0
00007e6bc8be2010  int3
00007e6bc8be2011  call 0x00007E6BC8AD5EB0
00007e6bc8be2016  jmp 0x00007E6BC8BE1FFD
00007e6bc8be201b  int3
00007e6bc8be201c  nop [rax], eax
00007e6bc8be2020  mov qword ptr [r15+0x100], 0x04
00007e6bc8be202b  mov esi, 0x00
00007e6bc8be2030  mov edx, 0x09
00007e6bc8be2035  mov rdi, 0x7FFCAB9132B0
00007e6bc8be203f  mov rax, 0x6543F17B0970
00007e6bc8be2049  call rax
00007e6bc8be204b  cmp dword ptr [r15+0x318], 0x00
00007e6bc8be2053  jnz 0x00007E6BC89FE110
00007e6bc8be2059  jmp 0x00007E6BC89FE0A0
00007e6bc8be205e  int3
00007e6bc8be205f  int3
