000078d1a57ce69b  nop [rax+rax*1], eax
000078d1a57ce6a0  vmovaps xmm1, [0x000078D1A53FE010]
000078d1a57ce6a8  movq xmm1, xmm1
000078d1a57ce6ac  movaps [r15+0x110], xmm1
000078d1a57ce6b4  vmovaps xmm1, [0x000078D1A53FE020]
000078d1a57ce6bc  movq xmm1, xmm1
000078d1a57ce6c0  movaps [r15+0x120], xmm1
000078d1a57ce6c8  mov eax, 0x4204C0
000078d1a57ce6cd  mov r14, [r13+rax*1]
000078d1a57ce6d2  movq xmm1, r14
000078d1a57ce6d7  movaps [r15+0x130], xmm1
000078d1a57ce6df  vmovaps xmm1, [0x000078D1A53FE030]
000078d1a57ce6e7  vpbroadcastq xmm1, xmm1
000078d1a57ce6ec  movaps [r15+0x140], xmm1
000078d1a57ce6f4  mov qword ptr [r15+0x40], 0x02
000078d1a57ce6fc  vmovaps xmm15, [0x000078D1A53FE040]
000078d1a57ce704  movq xmm15, xmm15
000078d1a57ce709  movaps [r15+0x150], xmm15
000078d1a57ce711  mov qword ptr [r15+0x58], 0x420000
000078d1a57ce719  vmovaps xmm15, [0x000078D1A53FE050]
000078d1a57ce721  vpbroadcastq xmm15, xmm15
000078d1a57ce726  movaps [r15+0x160], xmm15
000078d1a57ce72e  mov rax, [r15+0x40]
000078d1a57ce732  vmovq xmm14, rax
000078d1a57ce737  vpbroadcastq xmm14, xmm14
000078d1a57ce73c  movaps [r15+0x170], xmm14
000078d1a57ce744  mov eax, 0x4204D0
000078d1a57ce749  movups xmm13, [r13+rax*1]
000078d1a57ce74f  mov qword ptr [r15+0x40], 0x430518
000078d1a57ce757  mov qword ptr [r15+0x50], 0x430720
000078d1a57ce75f  vpmovqd xmm12, xmm13
000078d1a57ce765  pxor xmm11, xmm11
000078d1a57ce76a  punpcklqdq xmm12, xmm11
000078d1a57ce76f  movaps [r15+0x210], xmm12
000078d1a57ce777  movq xmm12, qword ptr [r15+0x120]
000078d1a57ce780  movq xmm11, qword ptr [r15+0x130]
000078d1a57ce789  psubd xmm12, xmm11
000078d1a57ce78e  movq xmm12, xmm12
000078d1a57ce793  paddq xmm13, xmm14
000078d1a57ce798  movaps [r15+0x180], xmm13
000078d1a57ce7a0  movq xmm14, qword ptr [r15+0x150]
000078d1a57ce7a9  paddd xmm11, xmm14
000078d1a57ce7ae  movq xmm11, xmm11
000078d1a57ce7b3  movq xmm11, xmm11
000078d1a57ce7b8  movaps [r15+0x130], xmm11
000078d1a57ce7c0  pmovzxdq xmm12, xmm12
000078d1a57ce7c6  psllq xmm12, 0x00
000078d1a57ce7cc  movq xmm14, qword ptr [r15+0x210]
000078d1a57ce7d5  movq xmm13, qword ptr [r15+0x110]
000078d1a57ce7de  paddd xmm14, xmm13
000078d1a57ce7e3  movq xmm14, xmm14
000078d1a57ce7e8  vcvtuqq2pd xmm12, xmm12
000078d1a57ce7ee  pmovzxdq xmm14, xmm14
000078d1a57ce7f4  psllq xmm14, 0x00
000078d1a57ce7fa  vcvtuqq2pd xmm14, xmm14
000078d1a57ce800  movaps xmm13, xmm12
000078d1a57ce804  mulpd xmm13, xmm1
000078d1a57ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000078d1a57ce80f  ptest xmm11, xmm11
000078d1a57ce815  jnz 0x000078D1A57CE8FF
000078d1a57ce81b  movaps [r15+0x220], xmm13
000078d1a57ce823  mov eax, 0x430720
000078d1a57ce828  movups [r13+rax*1], xmm13
000078d1a57ce82e  movaps xmm1, xmm14
000078d1a57ce832  mulpd xmm1, xmm15
000078d1a57ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000078d1a57ce83c  ptest xmm13, xmm13
000078d1a57ce842  jnz 0x000078D1A57CEA4C
000078d1a57ce848  movaps [r15+0x210], xmm1
000078d1a57ce850  mov eax, 0x430518
000078d1a57ce855  movups [r13+rax*1], xmm1
000078d1a57ce85b  mov qword ptr [r15+0x48], 0x10
000078d1a57ce863  xor eax, eax
000078d1a57ce865  mov r14d, 0x10
000078d1a57ce86b  mov r12d, 0x200
000078d1a57ce871  cmp r14, r12
000078d1a57ce874  cmc
000078d1a57ce875  lahf
000078d1a57ce876  seto al
000078d1a57ce879  mov [r15+0x108], eax
000078d1a57ce880  mov eax, [r15+0x108]
000078d1a57ce887  sahf
000078d1a57ce888  jnz 0x000078D1A57CE8BA
000078d1a57ce88a  cmp dword ptr [r15+0x318], 0x00
000078d1a57ce892  jz 0x000078D1A57CEFF0
000078d1a57ce898  nop [rax+rax*1], ax
000078d1a57ce8a1  nop [rax+rax*1], eax
000078d1a57ce8a9  mov eax, 0x4101EC
000078d1a57ce8ae  mov [r15+0x100], rax
000078d1a57ce8b5  jmp 0x000078D1A55FE110
000078d1a57ce8ba  cmp dword ptr [r15+0x318], 0x00
000078d1a57ce8c2  jz 0x000078D1A57CEBA0
000078d1a57ce8c8  nop [rax+rax*1], ax
000078d1a57ce8d1  nop [rax+rax*1], eax
000078d1a57ce8d9  mov eax, 0x4101AC
000078d1a57ce8de  mov [r15+0x100], rax
000078d1a57ce8e5  jmp 0x000078D1A55FE110
000078d1a57ce8ea  int3
000078d1a57ce8eb  call 0x000078D1A560DC20
000078d1a57ce8f0  jmp 0x000078D1A57CE6D2
000078d1a57ce8f5  call 0x000078D1A560C260
000078d1a57ce8fa  jmp 0x000078D1A57CE74F
000078d1a57ce8ff  sub rsp, 0x08
000078d1a57ce903  push rax
000078d1a57ce904  push rcx
000078d1a57ce905  push rdx
000078d1a57ce906  push rdi
000078d1a57ce907  push rsi
000078d1a57ce908  push r8
000078d1a57ce90a  push r9
000078d1a57ce90c  push r10
000078d1a57ce90e  push r11
000078d1a57ce910  sub rsp, 0xF0
000078d1a57ce917  vmovaps [rsp], xmm0
000078d1a57ce91c  vmovaps [rsp+0x10], xmm1
000078d1a57ce922  vmovaps [rsp+0x20], xmm2
000078d1a57ce928  vmovaps [rsp+0x30], xmm3
000078d1a57ce92e  vmovaps [rsp+0x40], xmm4
000078d1a57ce934  vmovaps [rsp+0x50], xmm5
000078d1a57ce93a  vmovaps [rsp+0x60], xmm6
000078d1a57ce940  vmovaps [rsp+0x70], xmm7
000078d1a57ce946  vmovaps [rsp+0x80], xmm8
000078d1a57ce94f  vmovaps [rsp+0x90], xmm9
000078d1a57ce958  vmovaps [rsp+0xA0], xmm10
000078d1a57ce961  vmovaps [rsp+0xB0], xmm11
000078d1a57ce96a  vmovaps [rsp+0xC0], xmm12
000078d1a57ce973  vmovaps [rsp+0xD0], xmm14
000078d1a57ce97c  vmovaps [rsp+0xE0], xmm15
000078d1a57ce985  sub rsp, 0x30
000078d1a57ce989  movaps [rsp], xmm13
000078d1a57ce98e  movaps [rsp+0x10], xmm12
000078d1a57ce994  movaps [rsp+0x20], xmm1
000078d1a57ce999  lea rdi, [rsp]
000078d1a57ce99d  mov esi, 0x00
000078d1a57ce9a2  mov rax, 0x56EA20A26530
000078d1a57ce9ac  call rax
000078d1a57ce9ae  movaps xmm13, [rsp]
000078d1a57ce9b3  add rsp, 0x30
000078d1a57ce9b7  vmovaps xmm0, [rsp]
000078d1a57ce9bc  vmovaps xmm1, [rsp+0x10]
000078d1a57ce9c2  vmovaps xmm2, [rsp+0x20]
000078d1a57ce9c8  vmovaps xmm3, [rsp+0x30]
000078d1a57ce9ce  vmovaps xmm4, [rsp+0x40]
000078d1a57ce9d4  vmovaps xmm5, [rsp+0x50]
000078d1a57ce9da  vmovaps xmm6, [rsp+0x60]
000078d1a57ce9e0  vmovaps xmm7, [rsp+0x70]
000078d1a57ce9e6  vmovaps xmm8, [rsp+0x80]
000078d1a57ce9ef  vmovaps xmm9, [rsp+0x90]
000078d1a57ce9f8  vmovaps xmm10, [rsp+0xA0]
000078d1a57cea01  vmovaps xmm11, [rsp+0xB0]
000078d1a57cea0a  vmovaps xmm12, [rsp+0xC0]
000078d1a57cea13  vmovaps xmm14, [rsp+0xD0]
000078d1a57cea1c  vmovaps xmm15, [rsp+0xE0]
000078d1a57cea25  add rsp, 0xF0
000078d1a57cea2c  pop r11
000078d1a57cea2e  pop r10
000078d1a57cea30  pop r9
000078d1a57cea32  pop r8
000078d1a57cea34  pop rsi
000078d1a57cea35  pop rdi
000078d1a57cea36  pop rdx
000078d1a57cea37  pop rcx
000078d1a57cea38  pop rax
000078d1a57cea39  add rsp, 0x08
000078d1a57cea3d  jmp 0x000078D1A57CE81B
000078d1a57cea42  call 0x000078D1A560C380
000078d1a57cea47  jmp 0x000078D1A57CE82E
000078d1a57cea4c  sub rsp, 0x08
000078d1a57cea50  push rax
000078d1a57cea51  push rcx
000078d1a57cea52  push rdx
000078d1a57cea53  push rdi
000078d1a57cea54  push rsi
000078d1a57cea55  push r8
000078d1a57cea57  push r9
000078d1a57cea59  push r10
000078d1a57cea5b  push r11
000078d1a57cea5d  sub rsp, 0xF0
000078d1a57cea64  vmovaps [rsp], xmm0
000078d1a57cea69  vmovaps [rsp+0x10], xmm2
000078d1a57cea6f  vmovaps [rsp+0x20], xmm3
000078d1a57cea75  vmovaps [rsp+0x30], xmm4
000078d1a57cea7b  vmovaps [rsp+0x40], xmm5
000078d1a57cea81  vmovaps [rsp+0x50], xmm6
000078d1a57cea87  vmovaps [rsp+0x60], xmm7
000078d1a57cea8d  vmovaps [rsp+0x70], xmm8
000078d1a57cea93  vmovaps [rsp+0x80], xmm9
000078d1a57cea9c  vmovaps [rsp+0x90], xmm10
000078d1a57ceaa5  vmovaps [rsp+0xA0], xmm11
000078d1a57ceaae  vmovaps [rsp+0xB0], xmm12
000078d1a57ceab7  vmovaps [rsp+0xC0], xmm13
000078d1a57ceac0  vmovaps [rsp+0xD0], xmm14
000078d1a57ceac9  vmovaps [rsp+0xE0], xmm15
000078d1a57cead2  sub rsp, 0x30
000078d1a57cead6  movaps [rsp], xmm1
000078d1a57ceada  movaps [rsp+0x10], xmm14
000078d1a57ceae0  movaps [rsp+0x20], xmm15
000078d1a57ceae6  lea rdi, [rsp]
000078d1a57ceaea  mov esi, 0x00
000078d1a57ceaef  mov rax, 0x56EA20A26530
000078d1a57ceaf9  call rax
000078d1a57ceafb  movaps xmm1, [rsp]
000078d1a57ceaff  add rsp, 0x30
000078d1a57ceb03  vmovaps xmm0, [rsp]
000078d1a57ceb08  vmovaps xmm2, [rsp+0x10]
000078d1a57ceb0e  vmovaps xmm3, [rsp+0x20]
000078d1a57ceb14  vmovaps xmm4, [rsp+0x30]
000078d1a57ceb1a  vmovaps xmm5, [rsp+0x40]
000078d1a57ceb20  vmovaps xmm6, [rsp+0x50]
000078d1a57ceb26  vmovaps xmm7, [rsp+0x60]
000078d1a57ceb2c  vmovaps xmm8, [rsp+0x70]
000078d1a57ceb32  vmovaps xmm9, [rsp+0x80]
000078d1a57ceb3b  vmovaps xmm10, [rsp+0x90]
000078d1a57ceb44  vmovaps xmm11, [rsp+0xA0]
000078d1a57ceb4d  vmovaps xmm12, [rsp+0xB0]
000078d1a57ceb56  vmovaps xmm13, [rsp+0xC0]
000078d1a57ceb5f  vmovaps xmm14, [rsp+0xD0]
000078d1a57ceb68  vmovaps xmm15, [rsp+0xE0]
000078d1a57ceb71  add rsp, 0xF0
000078d1a57ceb78  pop r11
000078d1a57ceb7a  pop r10
000078d1a57ceb7c  pop r9
000078d1a57ceb7e  pop r8
000078d1a57ceb80  pop rsi
000078d1a57ceb81  pop rdi
000078d1a57ceb82  pop rdx
000078d1a57ceb83  pop rcx
000078d1a57ceb84  pop rax
000078d1a57ceb85  add rsp, 0x08
000078d1a57ceb89  jmp 0x000078D1A57CE848
000078d1a57ceb8e  call 0x000078D1A55FF540
000078d1a57ceb93  jmp 0x000078D1A57CE85B
000078d1a57ceb98  int3
000078d1a57ceb99  nop [rax], eax
000078d1a57ceba0  movaps xmm1, [r15+0x180]
000078d1a57ceba8  vpmovqd xmm15, xmm1
000078d1a57cebae  pxor xmm14, xmm14
000078d1a57cebb3  punpcklqdq xmm15, xmm14
000078d1a57cebb8  movaps [r15+0x210], xmm15
000078d1a57cebc0  movq xmm15, qword ptr [r15+0x120]
000078d1a57cebc9  movq xmm14, qword ptr [r15+0x130]
000078d1a57cebd2  psubd xmm15, xmm14
000078d1a57cebd7  movq xmm15, xmm15
000078d1a57cebdc  movaps xmm13, [r15+0x170]
000078d1a57cebe4  paddq xmm1, xmm13
000078d1a57cebe9  movaps [r15+0x180], xmm1
000078d1a57cebf1  movq xmm1, qword ptr [r15+0x150]
000078d1a57cebfa  paddd xmm14, xmm1
000078d1a57cebff  movq xmm14, xmm14
000078d1a57cec04  movq xmm14, xmm14
000078d1a57cec09  movaps [r15+0x130], xmm14
000078d1a57cec11  pmovzxdq xmm15, xmm15
000078d1a57cec17  psllq xmm15, 0x00
000078d1a57cec1d  movq xmm1, qword ptr [r15+0x210]
000078d1a57cec26  movq xmm14, qword ptr [r15+0x110]
000078d1a57cec2f  paddd xmm1, xmm14
000078d1a57cec34  movq xmm1, xmm1
000078d1a57cec38  vcvtuqq2pd xmm15, xmm15
000078d1a57cec3e  pmovzxdq xmm1, xmm1
000078d1a57cec43  psllq xmm1, 0x00
000078d1a57cec48  vcvtuqq2pd xmm1, xmm1
000078d1a57cec4e  movaps xmm14, [r15+0x140]
000078d1a57cec56  movaps xmm13, xmm15
000078d1a57cec5a  mulpd xmm13, xmm14
000078d1a57cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000078d1a57cec65  ptest xmm12, xmm12
000078d1a57cec6b  jnz 0x000078D1A57CED4E
000078d1a57cec71  movaps [r15+0x220], xmm13
000078d1a57cec79  mov rax, [r15+0x48]
000078d1a57cec7d  mov r14, [r15+0x50]
000078d1a57cec81  lea r12, [r14+rax*1]
000078d1a57cec85  movups [r13+r12*1], xmm13
000078d1a57cec8b  movaps xmm15, [r15+0x160]
000078d1a57cec93  movaps xmm14, xmm1
000078d1a57cec97  mulpd xmm14, xmm15
000078d1a57cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000078d1a57ceca2  ptest xmm13, xmm13
000078d1a57ceca8  jnz 0x000078D1A57CEE9C
000078d1a57cecae  movaps [r15+0x210], xmm14
000078d1a57cecb6  mov r14, [r15+0x40]
000078d1a57cecba  lea r12, [r14+rax*1]
000078d1a57cecbe  movups [r13+r12*1], xmm14
000078d1a57cecc4  lea r14, [rax+0x10]
000078d1a57cecc8  mov [r15+0x48], r14
000078d1a57ceccc  xor eax, eax
000078d1a57cecce  mov r12d, 0x200
000078d1a57cecd4  cmp r14, r12
000078d1a57cecd7  cmc
000078d1a57cecd8  lahf
000078d1a57cecd9  seto al
000078d1a57cecdc  mov [r15+0x108], eax
000078d1a57cece3  mov eax, [r15+0x108]
000078d1a57cecea  sahf
000078d1a57ceceb  jnz 0x000078D1A57CED1D
000078d1a57ceced  cmp dword ptr [r15+0x318], 0x00
000078d1a57cecf5  jz 0x000078D1A57CEFF0
000078d1a57cecfb  nop [rax+rax*1], ax
000078d1a57ced04  nop [rax+rax*1], eax
000078d1a57ced0c  mov eax, 0x4101EC
000078d1a57ced11  mov [r15+0x100], rax
000078d1a57ced18  jmp 0x000078D1A55FE110
000078d1a57ced1d  cmp dword ptr [r15+0x318], 0x00
000078d1a57ced25  jz 0x000078D1A57CEBA0
000078d1a57ced2b  nop [rax+rax*1], ax
000078d1a57ced34  nop [rax+rax*1], eax
000078d1a57ced3c  mov eax, 0x4101AC
000078d1a57ced41  mov [r15+0x100], rax
000078d1a57ced48  jmp 0x000078D1A55FE110
000078d1a57ced4d  int3
000078d1a57ced4e  sub rsp, 0x08
000078d1a57ced52  push rax
000078d1a57ced53  push rcx
000078d1a57ced54  push rdx
000078d1a57ced55  push rdi
000078d1a57ced56  push rsi
000078d1a57ced57  push r8
000078d1a57ced59  push r9
000078d1a57ced5b  push r10
000078d1a57ced5d  push r11
000078d1a57ced5f  sub rsp, 0xF0
000078d1a57ced66  vmovaps [rsp], xmm0
000078d1a57ced6b  vmovaps [rsp+0x10], xmm1
000078d1a57ced71  vmovaps [rsp+0x20], xmm2
000078d1a57ced77  vmovaps [rsp+0x30], xmm3
000078d1a57ced7d  vmovaps [rsp+0x40], xmm4
000078d1a57ced83  vmovaps [rsp+0x50], xmm5
000078d1a57ced89  vmovaps [rsp+0x60], xmm6
000078d1a57ced8f  vmovaps [rsp+0x70], xmm7
000078d1a57ced95  vmovaps [rsp+0x80], xmm8
000078d1a57ced9e  vmovaps [rsp+0x90], xmm9
000078d1a57ceda7  vmovaps [rsp+0xA0], xmm10
000078d1a57cedb0  vmovaps [rsp+0xB0], xmm11
000078d1a57cedb9  vmovaps [rsp+0xC0], xmm12
000078d1a57cedc2  vmovaps [rsp+0xD0], xmm14
000078d1a57cedcb  vmovaps [rsp+0xE0], xmm15
000078d1a57cedd4  sub rsp, 0x30
000078d1a57cedd8  movaps [rsp], xmm13
000078d1a57ceddd  movaps [rsp+0x10], xmm15
000078d1a57cede3  movaps [rsp+0x20], xmm14
000078d1a57cede9  lea rdi, [rsp]
000078d1a57ceded  mov esi, 0x00
000078d1a57cedf2  mov rax, 0x56EA20A26530
000078d1a57cedfc  call rax
000078d1a57cedfe  movaps xmm13, [rsp]
000078d1a57cee03  add rsp, 0x30
000078d1a57cee07  vmovaps xmm0, [rsp]
000078d1a57cee0c  vmovaps xmm1, [rsp+0x10]
000078d1a57cee12  vmovaps xmm2, [rsp+0x20]
000078d1a57cee18  vmovaps xmm3, [rsp+0x30]
000078d1a57cee1e  vmovaps xmm4, [rsp+0x40]
000078d1a57cee24  vmovaps xmm5, [rsp+0x50]
000078d1a57cee2a  vmovaps xmm6, [rsp+0x60]
000078d1a57cee30  vmovaps xmm7, [rsp+0x70]
000078d1a57cee36  vmovaps xmm8, [rsp+0x80]
000078d1a57cee3f  vmovaps xmm9, [rsp+0x90]
000078d1a57cee48  vmovaps xmm10, [rsp+0xA0]
000078d1a57cee51  vmovaps xmm11, [rsp+0xB0]
000078d1a57cee5a  vmovaps xmm12, [rsp+0xC0]
000078d1a57cee63  vmovaps xmm14, [rsp+0xD0]
000078d1a57cee6c  vmovaps xmm15, [rsp+0xE0]
000078d1a57cee75  add rsp, 0xF0
000078d1a57cee7c  pop r11
000078d1a57cee7e  pop r10
000078d1a57cee80  pop r9
000078d1a57cee82  pop r8
000078d1a57cee84  pop rsi
000078d1a57cee85  pop rdi
000078d1a57cee86  pop rdx
000078d1a57cee87  pop rcx
000078d1a57cee88  pop rax
000078d1a57cee89  add rsp, 0x08
000078d1a57cee8d  jmp 0x000078D1A57CEC71
000078d1a57cee92  call 0x000078D1A56C2240
000078d1a57cee97  jmp 0x000078D1A57CEC8B
000078d1a57cee9c  sub rsp, 0x08
000078d1a57ceea0  push rax
000078d1a57ceea1  push rcx
000078d1a57ceea2  push rdx
000078d1a57ceea3  push rdi
000078d1a57ceea4  push rsi
000078d1a57ceea5  push r8
000078d1a57ceea7  push r9
000078d1a57ceea9  push r10
000078d1a57ceeab  push r11
000078d1a57ceead  sub rsp, 0xF0
000078d1a57ceeb4  vmovaps [rsp], xmm0
000078d1a57ceeb9  vmovaps [rsp+0x10], xmm1
000078d1a57ceebf  vmovaps [rsp+0x20], xmm2
000078d1a57ceec5  vmovaps [rsp+0x30], xmm3
000078d1a57ceecb  vmovaps [rsp+0x40], xmm4
000078d1a57ceed1  vmovaps [rsp+0x50], xmm5
000078d1a57ceed7  vmovaps [rsp+0x60], xmm6
000078d1a57ceedd  vmovaps [rsp+0x70], xmm7
000078d1a57ceee3  vmovaps [rsp+0x80], xmm8
000078d1a57ceeec  vmovaps [rsp+0x90], xmm9
000078d1a57ceef5  vmovaps [rsp+0xA0], xmm10
000078d1a57ceefe  vmovaps [rsp+0xB0], xmm11
000078d1a57cef07  vmovaps [rsp+0xC0], xmm12
000078d1a57cef10  vmovaps [rsp+0xD0], xmm13
000078d1a57cef19  vmovaps [rsp+0xE0], xmm15
000078d1a57cef22  sub rsp, 0x30
000078d1a57cef26  movaps [rsp], xmm14
000078d1a57cef2b  movaps [rsp+0x10], xmm1
000078d1a57cef30  movaps [rsp+0x20], xmm15
000078d1a57cef36  lea rdi, [rsp]
000078d1a57cef3a  mov esi, 0x00
000078d1a57cef3f  mov rax, 0x56EA20A26530
000078d1a57cef49  call rax
000078d1a57cef4b  movaps xmm14, [rsp]
000078d1a57cef50  add rsp, 0x30
000078d1a57cef54  vmovaps xmm0, [rsp]
000078d1a57cef59  vmovaps xmm1, [rsp+0x10]
000078d1a57cef5f  vmovaps xmm2, [rsp+0x20]
000078d1a57cef65  vmovaps xmm3, [rsp+0x30]
000078d1a57cef6b  vmovaps xmm4, [rsp+0x40]
000078d1a57cef71  vmovaps xmm5, [rsp+0x50]
000078d1a57cef77  vmovaps xmm6, [rsp+0x60]
000078d1a57cef7d  vmovaps xmm7, [rsp+0x70]
000078d1a57cef83  vmovaps xmm8, [rsp+0x80]
000078d1a57cef8c  vmovaps xmm9, [rsp+0x90]
000078d1a57cef95  vmovaps xmm10, [rsp+0xA0]
000078d1a57cef9e  vmovaps xmm11, [rsp+0xB0]
000078d1a57cefa7  vmovaps xmm12, [rsp+0xC0]
000078d1a57cefb0  vmovaps xmm13, [rsp+0xD0]
000078d1a57cefb9  vmovaps xmm15, [rsp+0xE0]
000078d1a57cefc2  add rsp, 0xF0
000078d1a57cefc9  pop r11
000078d1a57cefcb  pop r10
000078d1a57cefcd  pop r9
000078d1a57cefcf  pop r8
000078d1a57cefd1  pop rsi
000078d1a57cefd2  pop rdi
000078d1a57cefd3  pop rdx
000078d1a57cefd4  pop rcx
000078d1a57cefd5  pop rax
000078d1a57cefd6  add rsp, 0x08
000078d1a57cefda  jmp 0x000078D1A57CECAE
000078d1a57cefdf  call 0x000078D1A56C34C0
000078d1a57cefe4  jmp 0x000078D1A57CECC4
000078d1a57cefe9  int3
000078d1a57cefea  nop [rax+rax*1], ax
000078d1a57ceff0  mov rax, [r15+0xF8]
000078d1a57ceff7  lea r14, [rax-0x150]
000078d1a57ceffe  mov [r15+0xF8], r14
000078d1a57cf005  mov rax, [r15+0x50]
000078d1a57cf009  lea r12, [rax+0x80]
000078d1a57cf010  movups xmm1, [r13+r12*1]
000078d1a57cf016  lea r12, [rax+0x90]
000078d1a57cf01d  movups xmm15, [r13+r12*1]
000078d1a57cf023  mov qword ptr [r15+0x48], 0x00
000078d1a57cf02b  lea r12, [rax+0x40]
000078d1a57cf02f  movups xmm14, [r13+r12*1]
000078d1a57cf035  lea r12, [rax+0x50]
000078d1a57cf039  movups xmm13, [r13+r12*1]
000078d1a57cf03f  lea r12, [r14+0x120]
000078d1a57cf046  movq xmm12, qword ptr [r15+0x1C0]
000078d1a57cf04f  movq xmm11, qword ptr [r15+0x1B0]
000078d1a57cf058  movq r11, xmm12
000078d1a57cf05d  movq r10, xmm11
000078d1a57cf062  mov [r13+r12*1], r11
000078d1a57cf067  lea r12, [r14+0x128]
000078d1a57cf06e  mov [r13+r12*1], r10
000078d1a57cf073  vxorps xmm12, xmm12, xmm12
000078d1a57cf078  vpbroadcastq xmm12, xmm12
000078d1a57cf07d  lea r12, [r14+0x100]
000078d1a57cf084  movq xmm11, qword ptr [r15+0x200]
000078d1a57cf08d  movq xmm10, qword ptr [r15+0x1F0]
000078d1a57cf096  movq r11, xmm11
000078d1a57cf09b  movq r10, xmm10
000078d1a57cf0a0  mov [r13+r12*1], r11
000078d1a57cf0a5  lea r12, [r14+0x108]
000078d1a57cf0ac  mov [r13+r12*1], r10
000078d1a57cf0b1  lea r12, [r14+0xE0]
000078d1a57cf0b8  movups [r13+r12*1], xmm15
000078d1a57cf0be  lea r12, [r14+0xF0]
000078d1a57cf0c5  movups [r13+r12*1], xmm1
000078d1a57cf0cb  lea r12, [rax+0xC0]
000078d1a57cf0d2  movups xmm1, [r13+r12*1]
000078d1a57cf0d8  lea r12, [rax+0xD0]
000078d1a57cf0df  movups xmm15, [r13+r12*1]
000078d1a57cf0e5  lea r12, [r14+0x110]
000078d1a57cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000078d1a57cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000078d1a57cf0fe  movq r11, xmm11
000078d1a57cf103  movq r10, xmm10
000078d1a57cf108  mov [r13+r12*1], r11
000078d1a57cf10d  lea r12, [r14+0x118]
000078d1a57cf114  mov [r13+r12*1], r10
000078d1a57cf119  movups xmm11, [r13+rax*1]
000078d1a57cf11f  lea r12, [rax+0x10]
000078d1a57cf123  movups xmm10, [r13+r12*1]
000078d1a57cf129  lea r12, [r14+0x130]
000078d1a57cf130  movq xmm9, qword ptr [r15+0x1A0]
000078d1a57cf139  movq xmm8, qword ptr [r15+0x190]
000078d1a57cf142  movq r11, xmm9
000078d1a57cf147  movq r10, xmm8
000078d1a57cf14c  mov [r13+r12*1], r11
000078d1a57cf151  lea r12, [r14+0x138]
000078d1a57cf158  mov [r13+r12*1], r10
000078d1a57cf15d  lea r12, [rax+0x140]
000078d1a57cf164  movups xmm9, [r13+r12*1]
000078d1a57cf16a  lea r12, [rax+0x150]
000078d1a57cf171  movups xmm8, [r13+r12*1]
000078d1a57cf177  lea r12, [r14+0xC0]
000078d1a57cf17e  movups [r13+r12*1], xmm15
000078d1a57cf184  lea r12, [r14+0xD0]
000078d1a57cf18b  movups [r13+r12*1], xmm1
000078d1a57cf191  lea r12, [rax+0x100]
000078d1a57cf198  movups xmm1, [r13+r12*1]
000078d1a57cf19e  lea r12, [rax+0x110]
000078d1a57cf1a5  movups xmm15, [r13+r12*1]
000078d1a57cf1ab  lea r12, [r14+0x140]
000078d1a57cf1b2  mov r11, [r15+0xE8]
000078d1a57cf1b9  mov [r13+r12*1], r11
000078d1a57cf1be  lea r12, [rax+0x180]
000078d1a57cf1c5  movups xmm7, [r13+r12*1]
000078d1a57cf1cb  lea r12, [rax+0x190]
000078d1a57cf1d2  movups xmm6, [r13+r12*1]
000078d1a57cf1d8  lea r12, [rax+0x1C0]
000078d1a57cf1df  movups xmm5, [r13+r12*1]
000078d1a57cf1e5  lea r12, [rax+0x1D0]
000078d1a57cf1ec  movups xmm4, [r13+r12*1]
000078d1a57cf1f2  lea r12, [r14+0x20]
000078d1a57cf1f6  movups [r13+r12*1], xmm1
000078d1a57cf1fc  lea r12, [r14+0x30]
000078d1a57cf200  movups [r13+r12*1], xmm13
000078d1a57cf206  lea r12, [rax+0x60]
000078d1a57cf20a  movups xmm1, [r13+r12*1]
000078d1a57cf210  lea r12, [rax+0x70]
000078d1a57cf214  movups xmm13, [r13+r12*1]
000078d1a57cf21a  lea r12, [rax+0x20]
000078d1a57cf21e  movups xmm3, [r13+r12*1]
000078d1a57cf224  lea r12, [rax+0x30]
000078d1a57cf228  movups xmm2, [r13+r12*1]
000078d1a57cf22e  movaps [r15+0x1F0], xmm2
000078d1a57cf236  lea r12, [r14+0x60]
000078d1a57cf23a  movups [r13+r12*1], xmm11
000078d1a57cf240  lea r12, [r14+0x70]
000078d1a57cf244  movups [r13+r12*1], xmm5
000078d1a57cf24a  lea r12, [rax+0xE0]
000078d1a57cf251  movups xmm11, [r13+r12*1]
000078d1a57cf257  lea r12, [rax+0xF0]
000078d1a57cf25e  movups xmm5, [r13+r12*1]
000078d1a57cf264  lea r12, [r14+0xA0]
000078d1a57cf26b  movups [r13+r12*1], xmm13
000078d1a57cf271  lea r12, [r14+0xB0]
000078d1a57cf278  movups [r13+r12*1], xmm1
000078d1a57cf27e  lea r12, [rax+0xA0]
000078d1a57cf285  movups xmm1, [r13+r12*1]
000078d1a57cf28b  lea r12, [rax+0xB0]
000078d1a57cf292  movups xmm13, [r13+r12*1]
000078d1a57cf298  lea r12, [rax+0x120]
000078d1a57cf29f  vmovaps [rsp+0x10], xmm1
000078d1a57cf2a5  movups xmm1, [r13+r12*1]
000078d1a57cf2ab  lea r12, [rax+0x130]
000078d1a57cf2b2  vmovaps [rsp+0x20], xmm1
000078d1a57cf2b8  movups xmm1, [r13+r12*1]
000078d1a57cf2be  lea r12, [rax+0x160]
000078d1a57cf2c5  vmovaps [rsp+0x30], xmm1
000078d1a57cf2cb  movups xmm1, [r13+r12*1]
000078d1a57cf2d1  lea r12, [rax+0x170]
000078d1a57cf2d8  vmovaps [rsp+0x40], xmm1
000078d1a57cf2de  movups xmm1, [r13+r12*1]
000078d1a57cf2e4  movaps [r15+0x2B0], xmm1
000078d1a57cf2ec  lea r12, [r14+0x80]
000078d1a57cf2f3  movups [r13+r12*1], xmm13
000078d1a57cf2f9  lea r12, [r14+0x90]
000078d1a57cf300  vmovaps xmm13, [rsp+0x10]
000078d1a57cf306  movups [r13+r12*1], xmm13
000078d1a57cf30c  lea r12, [rax+0x1A0]
000078d1a57cf313  movups xmm13, [r13+r12*1]
000078d1a57cf319  lea r12, [rax+0x1B0]
000078d1a57cf320  vmovaps [rsp+0x10], xmm1
000078d1a57cf326  movups xmm1, [r13+r12*1]
000078d1a57cf32c  movaps [r15+0x290], xmm13
000078d1a57cf334  movaps [r15+0x1E0], xmm1
000078d1a57cf33c  lea r12, [rax+0x1E0]
000078d1a57cf343  vmovaps [rsp+0x50], xmm1
000078d1a57cf349  movups xmm1, [r13+r12*1]
000078d1a57cf34f  lea r12, [rax+0x1F0]
000078d1a57cf356  vmovaps [rsp+0x60], xmm1
000078d1a57cf35c  movups xmm1, [r13+r12*1]
000078d1a57cf362  mov qword ptr [r15+0x50], 0x430920
000078d1a57cf36a  lea rax, [r14+0x40]
000078d1a57cf36e  vmovaps [rsp+0x70], xmm1
000078d1a57cf374  vmovaps xmm1, [rsp+0x40]
000078d1a57cf37a  movups [r13+rax*1], xmm1
000078d1a57cf380  lea rax, [r14+0x50]
000078d1a57cf384  movups [r13+rax*1], xmm10
000078d1a57cf38a  vmovaps xmm1, [rsp+0x70]
000078d1a57cf390  movups [r13+r14*1], xmm1
000078d1a57cf396  lea rax, [r14+0x10]
000078d1a57cf39a  vmovaps xmm1, [rsp+0x60]
000078d1a57cf3a0  movups [r13+rax*1], xmm1
000078d1a57cf3a6  mov rax, [r15+0x40]
000078d1a57cf3aa  vmovaps [rsp+0x40], xmm3
000078d1a57cf3b0  vmovaps xmm1, [rsp+0x40]
000078d1a57cf3b6  por xmm3, xmm1
000078d1a57cf3ba  vmovaps [rsp+0x40], xmm6
000078d1a57cf3c0  vmovaps xmm10, [rsp+0x40]
000078d1a57cf3c6  por xmm6, xmm10
000078d1a57cf3cb  lea r12, [rax+0x30]
000078d1a57cf3cf  mov r11, [r13+r12*1]
000078d1a57cf3d4  lea r12, [rax+0x38]
000078d1a57cf3d8  mov r10, [r13+r12*1]
000078d1a57cf3dd  movq xmm10, r11
000078d1a57cf3e2  vmovaps [rsp+0x40], xmm1
000078d1a57cf3e8  movq xmm1, r10
000078d1a57cf3ed  movq xmm10, xmm10
000078d1a57cf3f2  vmovaps [rsp+0x60], xmm10
000078d1a57cf3f8  movq xmm10, xmm10
000078d1a57cf3fd  movaps [r15+0x130], xmm10
000078d1a57cf405  movq xmm1, xmm1
000078d1a57cf409  vmovaps [rsp+0x70], xmm1
000078d1a57cf40f  movq xmm1, xmm1
000078d1a57cf413  movaps [r15+0x280], xmm1
000078d1a57cf41b  vmovaps [rsp+0x80], xmm9
000078d1a57cf424  vmovaps xmm1, [rsp+0x80]
000078d1a57cf42d  por xmm9, xmm1
000078d1a57cf432  lea r12, [rax+0x20]
000078d1a57cf436  mov r11, [r13+r12*1]
000078d1a57cf43b  lea r12, [rax+0x28]
000078d1a57cf43f  mov r10, [r13+r12*1]
000078d1a57cf444  movq xmm1, r11
000078d1a57cf449  movq xmm10, r10
000078d1a57cf44e  movq xmm1, xmm1
000078d1a57cf452  vmovaps [rsp+0x80], xmm1
000078d1a57cf45b  movq xmm1, xmm1
000078d1a57cf45f  movaps [r15+0x150], xmm1
000078d1a57cf467  movq xmm10, xmm10
000078d1a57cf46c  vmovaps [rsp+0x90], xmm10
000078d1a57cf475  movq xmm10, xmm10
000078d1a57cf47a  movaps [r15+0x140], xmm10
000078d1a57cf482  lea r12, [rax+0x10]
000078d1a57cf486  mov r11, [r13+r12*1]
000078d1a57cf48b  lea r12, [rax+0x18]
000078d1a57cf48f  mov r10, [r13+r12*1]
000078d1a57cf494  movq xmm1, r11
000078d1a57cf499  movq xmm10, r10
000078d1a57cf49e  movq xmm1, xmm1
000078d1a57cf4a2  vmovaps [rsp+0xA0], xmm1
000078d1a57cf4ab  movq xmm1, xmm1
000078d1a57cf4af  movaps [r15+0x170], xmm1
000078d1a57cf4b7  movq xmm10, xmm10
000078d1a57cf4bc  vmovaps [rsp+0xB0], xmm10
000078d1a57cf4c5  movq xmm10, xmm10
000078d1a57cf4ca  movaps [r15+0x160], xmm10
000078d1a57cf4d2  mov r12, [r13+rax*1]
000078d1a57cf4d7  vmovq xmm1, r12
000078d1a57cf4dc  vpbroadcastq xmm1, xmm1
000078d1a57cf4e1  lea r12, [rax+0x08]
000078d1a57cf4e5  mov rax, [r13+r12*1]
000078d1a57cf4ea  movq xmm10, rax
000078d1a57cf4ef  movaps [r15+0x230], xmm10
000078d1a57cf4f7  lea rax, [r14+0x50]
000078d1a57cf4fb  movups xmm10, [r13+rax*1]
000078d1a57cf501  lea rax, [r14+0x60]
000078d1a57cf505  vmovaps [rsp+0xC0], xmm1
000078d1a57cf50e  movups xmm1, [r13+rax*1]
000078d1a57cf514  lea rax, [r14+0x30]
000078d1a57cf518  vmovaps [rsp+0xD0], xmm1
000078d1a57cf521  movups xmm1, [r13+rax*1]
000078d1a57cf527  mov qword ptr [r15+0x60], 0x430920
000078d1a57cf52f  mov qword ptr [r15+0x58], 0x40
000078d1a57cf537  vmovaps [rsp+0xE0], xmm1
000078d1a57cf540  vmovaps [rsp+0xF0], xmm15
000078d1a57cf549  vmovaps xmm15, [rsp+0xC0]
000078d1a57cf552  vmovaps [rsp+0xC0], xmm14
000078d1a57cf55b  vmovaps xmm14, [rsp+0x40]
000078d1a57cf561  vmovaps [rsp+0x40], xmm13
000078d1a57cf567  movaps xmm1, xmm15
000078d1a57cf56b  mulpd xmm1, xmm14
000078d1a57cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000078d1a57cf575  ptest xmm13, xmm13
000078d1a57cf57b  jnz 0x000078D1A57D0682
000078d1a57cf581  movq xmm14, qword ptr [r15+0x230]
000078d1a57cf58a  vmovaps [rsp+0x100], xmm14
000078d1a57cf593  vpermilpd xmm14, xmm14, 0x00
000078d1a57cf599  vmovaps [rsp+0x110], xmm1
000078d1a57cf5a2  vmovaps xmm1, [rsp+0xE0]
000078d1a57cf5ab  vmovaps [rsp+0xE0], xmm15
000078d1a57cf5b4  movaps xmm13, xmm1
000078d1a57cf5b8  mulpd xmm13, xmm14
000078d1a57cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000078d1a57cf5c3  ptest xmm15, xmm15
000078d1a57cf5c9  jnz 0x000078D1A57D07C4
000078d1a57cf5cf  vxorps xmm1, xmm1, xmm1
000078d1a57cf5d3  vpbroadcastq xmm1, xmm1
000078d1a57cf5d8  vmovaps xmm14, [rsp+0xE0]
000078d1a57cf5e1  vmovaps [rsp+0xE0], xmm1
000078d1a57cf5ea  vmovaps xmm1, [rsp+0xD0]
000078d1a57cf5f3  vmovaps [rsp+0xD0], xmm13
000078d1a57cf5fc  movaps xmm15, xmm14
000078d1a57cf600  mulpd xmm15, xmm1
000078d1a57cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000078d1a57cf60b  ptest xmm13, xmm13
000078d1a57cf611  jnz 0x000078D1A57D0907
000078d1a57cf617  movaps xmm1, xmm14
000078d1a57cf61b  mulpd xmm1, xmm10
000078d1a57cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000078d1a57cf625  ptest xmm13, xmm13
000078d1a57cf62b  jnz 0x000078D1A57D0A4A
000078d1a57cf631  movaps xmm13, xmm14
000078d1a57cf635  mulpd xmm13, xmm2
000078d1a57cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000078d1a57cf640  ptest xmm10, xmm10
000078d1a57cf646  jnz 0x000078D1A57D0B8C
000078d1a57cf64c  vmovaps [rsp+0x120], xmm7
000078d1a57cf655  vmovaps xmm14, [rsp+0x120]
000078d1a57cf65e  por xmm7, xmm14
000078d1a57cf663  vmovaps xmm14, [rsp+0xC0]
000078d1a57cf66c  vmovaps xmm10, [rsp+0xC0]
000078d1a57cf675  por xmm14, xmm10
000078d1a57cf67a  vmovaps xmm2, [rsp+0x100]
000078d1a57cf683  vpermilpd xmm2, xmm2, 0x00
000078d1a57cf689  vmovaps [rsp+0xC0], xmm1
000078d1a57cf692  vmovaps [rsp+0x120], xmm15
000078d1a57cf69b  movaps xmm1, xmm10
000078d1a57cf69f  mulpd xmm1, xmm2
000078d1a57cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000078d1a57cf6a8  ptest xmm15, xmm15
000078d1a57cf6ae  jnz 0x000078D1A57D0CCF
000078d1a57cf6b4  xor eax, eax
000078d1a57cf6b6  mov r12d, 0x40
000078d1a57cf6bc  mov r11d, 0x200
000078d1a57cf6c2  cmp r12, r11
000078d1a57cf6c5  cmc
000078d1a57cf6c6  lahf
000078d1a57cf6c7  seto al
000078d1a57cf6ca  mov [r15+0x108], eax
000078d1a57cf6d1  vmovaps xmm10, [rsp+0x110]
000078d1a57cf6da  vmovaps xmm2, [rsp+0xE0]
000078d1a57cf6e3  vmovaps [rsp+0xE0], xmm1
000078d1a57cf6ec  movaps xmm15, xmm10
000078d1a57cf6f0  addpd xmm15, xmm2
000078d1a57cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000078d1a57cf6fb  ptest xmm1, xmm1
000078d1a57cf700  jnz 0x000078D1A57D0E10
000078d1a57cf706  vmovaps xmm10, [rsp+0x120]
000078d1a57cf70f  vmovaps [rsp+0x110], xmm15
000078d1a57cf718  movaps xmm1, xmm10
000078d1a57cf71c  addpd xmm1, xmm12
000078d1a57cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000078d1a57cf726  ptest xmm15, xmm15
000078d1a57cf72c  jnz 0x000078D1A57D0F53
000078d1a57cf732  vmovaps xmm10, [rsp+0xC0]
000078d1a57cf73b  vmovaps [rsp+0xC0], xmm1
000078d1a57cf744  movaps xmm15, xmm10
000078d1a57cf748  addpd xmm15, xmm12
000078d1a57cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000078d1a57cf753  ptest xmm1, xmm1
000078d1a57cf758  jnz 0x000078D1A57D1095
000078d1a57cf75e  vmovaps xmm1, [rsp+0x30]
000078d1a57cf764  vmovaps xmm12, [rsp+0x30]
000078d1a57cf76a  por xmm1, xmm12
000078d1a57cf76f  vmovaps xmm12, [rsp+0x20]
000078d1a57cf775  vmovaps xmm10, [rsp+0x20]
000078d1a57cf77b  por xmm12, xmm10
000078d1a57cf780  vmovaps [rsp+0x20], xmm5
000078d1a57cf786  vmovaps xmm10, [rsp+0x20]
000078d1a57cf78c  por xmm5, xmm10
000078d1a57cf791  vmovaps [rsp+0x20], xmm11
000078d1a57cf797  vmovaps xmm10, [rsp+0x20]
000078d1a57cf79d  por xmm11, xmm10
000078d1a57cf7a2  vmovaps [rsp+0x20], xmm4
000078d1a57cf7a8  vmovaps xmm10, [rsp+0x20]
000078d1a57cf7ae  por xmm4, xmm10
000078d1a57cf7b3  vmovaps [rsp+0x20], xmm8
000078d1a57cf7b9  vmovaps xmm10, [rsp+0x20]
000078d1a57cf7bf  por xmm8, xmm10
000078d1a57cf7c4  vmovaps xmm10, [rsp+0xF0]
000078d1a57cf7cd  vmovaps [rsp+0x20], xmm1
000078d1a57cf7d3  vmovaps xmm1, [rsp+0xF0]
000078d1a57cf7dc  por xmm10, xmm1
000078d1a57cf7e1  lea rax, [r14+0xA0]
000078d1a57cf7e8  movups xmm1, [r13+rax*1]
000078d1a57cf7ee  lea rax, [r14+0xB0]
000078d1a57cf7f5  vmovaps [rsp+0x30], xmm1
000078d1a57cf7fb  movups xmm1, [r13+rax*1]
000078d1a57cf801  vmovaps [rsp+0xF0], xmm1
000078d1a57cf80a  vmovaps [rsp+0x120], xmm15
000078d1a57cf813  movaps xmm1, xmm13
000078d1a57cf817  addpd xmm1, xmm2
000078d1a57cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000078d1a57cf820  ptest xmm15, xmm15
000078d1a57cf826  jnz 0x000078D1A57D11ED
000078d1a57cf82c  lea rax, [r14+0xF0]
000078d1a57cf833  movups xmm15, [r13+rax*1]
000078d1a57cf839  vmovaps xmm2, [rsp+0xC0]
000078d1a57cf842  vmovaps [rsp+0xC0], xmm1
000078d1a57cf84b  vmovaps xmm1, [rsp+0xE0]
000078d1a57cf854  vmovaps [rsp+0xE0], xmm15
000078d1a57cf85d  movaps xmm13, xmm2
000078d1a57cf861  addpd xmm13, xmm1
000078d1a57cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000078d1a57cf86c  ptest xmm15, xmm15
000078d1a57cf872  jnz 0x000078D1A57D1338
000078d1a57cf878  vmovaps xmm15, [rsp+0x120]
000078d1a57cf881  vmovaps xmm2, [rsp+0xD0]
000078d1a57cf88a  vmovaps [rsp+0xD0], xmm14
000078d1a57cf893  movaps xmm1, xmm15
000078d1a57cf897  addpd xmm1, xmm2
000078d1a57cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000078d1a57cf8a0  ptest xmm14, xmm14
000078d1a57cf8a6  jnz 0x000078D1A57D147A
000078d1a57cf8ac  vmovaps xmm15, [rsp+0x100]
000078d1a57cf8b5  vpermilpd xmm15, xmm15, 0x00
000078d1a57cf8bb  vmovaps xmm2, [rsp+0xF0]
000078d1a57cf8c4  vmovaps [rsp+0xF0], xmm1
000078d1a57cf8cd  movaps xmm14, xmm2
000078d1a57cf8d1  mulpd xmm14, xmm15
000078d1a57cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000078d1a57cf8dc  ptest xmm1, xmm1
000078d1a57cf8e1  jnz 0x000078D1A57D15BB
000078d1a57cf8e7  vmovaps xmm1, [rsp+0xA0]
000078d1a57cf8f0  vpermilpd xmm1, xmm1, 0x00
000078d1a57cf8f6  vmovaps xmm2, [rsp+0xE0]
000078d1a57cf8ff  vmovaps [rsp+0xE0], xmm14
000078d1a57cf908  movaps xmm15, xmm2
000078d1a57cf90c  mulpd xmm15, xmm1
000078d1a57cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000078d1a57cf917  ptest xmm14, xmm14
000078d1a57cf91d  jnz 0x000078D1A57D16FE
000078d1a57cf923  lea rax, [r14+0xE0]
000078d1a57cf92a  movups xmm1, [r13+rax*1]
000078d1a57cf930  vmovaps xmm14, [rsp+0x100]
000078d1a57cf939  vpermilpd xmm14, xmm14, 0x00
000078d1a57cf93f  vmovaps [rsp+0x100], xmm1
000078d1a57cf948  vmovaps xmm1, [rsp+0x30]
000078d1a57cf94e  vmovaps [rsp+0x30], xmm15
000078d1a57cf954  movaps xmm2, xmm1
000078d1a57cf957  mulpd xmm2, xmm14
000078d1a57cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000078d1a57cf961  ptest xmm15, xmm15
000078d1a57cf967  jnz 0x000078D1A57D184A
000078d1a57cf96d  vmovaps [rsp+0x120], xmm10
000078d1a57cf976  vmovaps xmm1, [rsp+0x120]
000078d1a57cf97f  por xmm10, xmm1
000078d1a57cf984  movaps [r15+0x300], xmm10
000078d1a57cf98c  vmovaps [rsp+0x120], xmm8
000078d1a57cf995  vmovaps xmm1, [rsp+0x120]
000078d1a57cf99e  por xmm8, xmm1
000078d1a57cf9a3  movaps [r15+0x190], xmm8
000078d1a57cf9ab  vmovaps xmm1, [rsp+0xA0]
000078d1a57cf9b4  vpermilpd xmm1, xmm1, 0x00
000078d1a57cf9ba  vmovaps xmm14, [rsp+0x100]
000078d1a57cf9c3  vmovaps [rsp+0x100], xmm13
000078d1a57cf9cc  movaps xmm15, xmm14
000078d1a57cf9d0  mulpd xmm15, xmm1
000078d1a57cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000078d1a57cf9db  ptest xmm13, xmm13
000078d1a57cf9e1  jnz 0x000078D1A57D198B
000078d1a57cf9e7  lea rax, [r14+0x90]
000078d1a57cf9ee  movups xmm1, [r13+rax*1]
000078d1a57cf9f4  vmovaps [rsp+0x120], xmm4
000078d1a57cf9fd  vmovaps xmm14, [rsp+0x120]
000078d1a57cfa06  por xmm4, xmm14
000078d1a57cfa0b  movaps [r15+0x1C0], xmm4
000078d1a57cfa13  vmovaps [rsp+0x120], xmm11
000078d1a57cfa1c  vmovaps xmm14, [rsp+0x120]
000078d1a57cfa25  por xmm11, xmm14
000078d1a57cfa2a  movaps [r15+0x200], xmm11
000078d1a57cfa32  vmovaps [rsp+0x120], xmm5
000078d1a57cfa3b  vmovaps xmm14, [rsp+0x120]
000078d1a57cfa44  por xmm5, xmm14
000078d1a57cfa49  movaps [r15+0x2D0], xmm5
000078d1a57cfa51  vmovaps [rsp+0x120], xmm12
000078d1a57cfa5a  vmovaps xmm14, [rsp+0x120]
000078d1a57cfa63  por xmm12, xmm14
000078d1a57cfa68  movaps [r15+0x2E0], xmm12
000078d1a57cfa70  vmovaps xmm13, [rsp+0x110]
000078d1a57cfa79  vmovaps [rsp+0x110], xmm1
000078d1a57cfa82  vmovaps xmm1, [rsp+0xE0]
000078d1a57cfa8b  vmovaps [rsp+0xE0], xmm15
000078d1a57cfa94  movaps xmm14, xmm13
000078d1a57cfa98  addpd xmm14, xmm1
000078d1a57cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000078d1a57cfaa3  ptest xmm15, xmm15
000078d1a57cfaa9  jnz 0x000078D1A57D1AD8
000078d1a57cfaaf  vmovaps xmm1, [rsp+0xA0]
000078d1a57cfab8  vpermilpd xmm1, xmm1, 0x00
000078d1a57cfabe  vmovaps xmm13, [rsp+0x110]
000078d1a57cfac7  vmovaps [rsp+0x110], xmm14
000078d1a57cfad0  movaps xmm15, xmm13
000078d1a57cfad4  mulpd xmm15, xmm1
000078d1a57cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000078d1a57cfadf  ptest xmm14, xmm14
000078d1a57cfae5  jnz 0x000078D1A57D1C1B
000078d1a57cfaeb  lea rax, [r14+0x80]
000078d1a57cfaf2  movups xmm1, [r13+rax*1]
000078d1a57cfaf8  vmovaps xmm13, [rsp+0xC0]
000078d1a57cfb01  vmovaps [rsp+0xC0], xmm1
000078d1a57cfb0a  movaps xmm14, xmm13
000078d1a57cfb0e  addpd xmm14, xmm2
000078d1a57cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000078d1a57cfb19  ptest xmm1, xmm1
000078d1a57cfb1e  jnz 0x000078D1A57D1D68
000078d1a57cfb24  vmovaps xmm13, [rsp+0x100]
000078d1a57cfb2d  vmovaps xmm2, [rsp+0x30]
000078d1a57cfb33  vmovaps [rsp+0x30], xmm15
000078d1a57cfb39  movaps xmm1, xmm13
000078d1a57cfb3d  addpd xmm1, xmm2
000078d1a57cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000078d1a57cfb46  ptest xmm15, xmm15
000078d1a57cfb4c  jnz 0x000078D1A57D1EAB
000078d1a57cfb52  vmovaps xmm15, [rsp+0x20]
000078d1a57cfb58  vmovaps xmm13, [rsp+0x20]
000078d1a57cfb5e  por xmm15, xmm13
000078d1a57cfb63  movaps [r15+0x2F0], xmm15
000078d1a57cfb6b  vmovaps xmm13, [rsp+0xA0]
000078d1a57cfb74  vpermilpd xmm13, xmm13, 0x00
000078d1a57cfb7a  vmovaps [rsp+0x20], xmm1
000078d1a57cfb80  vmovaps xmm1, [rsp+0xC0]
000078d1a57cfb89  vmovaps [rsp+0xA0], xmm15
000078d1a57cfb92  movaps xmm2, xmm1
000078d1a57cfb95  mulpd xmm2, xmm13
000078d1a57cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000078d1a57cfb9f  ptest xmm15, xmm15
000078d1a57cfba5  jnz 0x000078D1A57D1FEC
000078d1a57cfbab  lea rax, [r14+0xD0]
000078d1a57cfbb2  movups xmm1, [r13+rax*1]
000078d1a57cfbb8  vmovaps xmm13, [rsp+0xF0]
000078d1a57cfbc1  vmovaps [rsp+0xC0], xmm1
000078d1a57cfbca  vmovaps xmm1, [rsp+0xE0]
000078d1a57cfbd3  vmovaps [rsp+0xE0], xmm14
000078d1a57cfbdc  movaps xmm15, xmm13
000078d1a57cfbe0  addpd xmm15, xmm1
000078d1a57cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000078d1a57cfbeb  ptest xmm14, xmm14
000078d1a57cfbf1  jnz 0x000078D1A57D2137
000078d1a57cfbf7  vmovaps xmm1, [rsp+0xB0]
000078d1a57cfc00  vpermilpd xmm1, xmm1, 0x00
000078d1a57cfc06  movaps xmm14, xmm11
000078d1a57cfc0a  mulpd xmm14, xmm1
000078d1a57cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000078d1a57cfc15  ptest xmm13, xmm13
000078d1a57cfc1b  jnz 0x000078D1A57D227A
000078d1a57cfc21  movaps [r15+0x260], xmm14
000078d1a57cfc29  vxorps xmm1, xmm1, xmm1
000078d1a57cfc2d  vpbroadcastq xmm1, xmm1
000078d1a57cfc32  movaps [r15+0x1B0], xmm1
000078d1a57cfc3a  vmovaps xmm1, [rsp+0xB0]
000078d1a57cfc43  vpermilpd xmm1, xmm1, 0x00
000078d1a57cfc49  vmovaps xmm11, [rsp+0xC0]
000078d1a57cfc52  vmovaps [rsp+0xC0], xmm15
000078d1a57cfc5b  movaps xmm13, xmm11
000078d1a57cfc5f  mulpd xmm13, xmm1
000078d1a57cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000078d1a57cfc6a  ptest xmm15, xmm15
000078d1a57cfc70  jnz 0x000078D1A57D23BD
000078d1a57cfc76  lea rax, [r14+0xC0]
000078d1a57cfc7d  movups xmm1, [r13+rax*1]
000078d1a57cfc83  vmovaps xmm11, [rsp+0x110]
000078d1a57cfc8c  vmovaps [rsp+0xF0], xmm1
000078d1a57cfc95  vmovaps xmm1, [rsp+0x30]
000078d1a57cfc9b  vmovaps [rsp+0x30], xmm14
000078d1a57cfca1  movaps xmm15, xmm11
000078d1a57cfca5  addpd xmm15, xmm1
000078d1a57cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000078d1a57cfcb0  ptest xmm14, xmm14
000078d1a57cfcb6  jnz 0x000078D1A57D250A
000078d1a57cfcbc  vmovaps [rsp+0x100], xmm9
000078d1a57cfcc5  vmovaps xmm1, [rsp+0x100]
000078d1a57cfcce  por xmm9, xmm1
000078d1a57cfcd3  movaps [r15+0x270], xmm9
000078d1a57cfcdb  vmovaps [rsp+0x100], xmm6
000078d1a57cfce4  vmovaps xmm1, [rsp+0x100]
000078d1a57cfced  por xmm6, xmm1
000078d1a57cfcf1  movaps [r15+0x1A0], xmm6
000078d1a57cfcf9  vmovaps xmm14, [rsp+0xB0]
000078d1a57cfd02  vpermilpd xmm14, xmm14, 0x00
000078d1a57cfd08  vmovaps xmm6, [rsp+0xF0]
000078d1a57cfd11  vmovaps [rsp+0xF0], xmm1
000078d1a57cfd1a  movaps xmm11, xmm6
000078d1a57cfd1e  mulpd xmm11, xmm14
000078d1a57cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000078d1a57cfd29  ptest xmm1, xmm1
000078d1a57cfd2e  jnz 0x000078D1A57D264D
000078d1a57cfd34  lea rax, [r14+0x20]
000078d1a57cfd38  movups xmm1, [r13+rax*1]
000078d1a57cfd3e  movaps [r15+0x110], xmm1
000078d1a57cfd46  vmovaps xmm6, [rsp+0xE0]
000078d1a57cfd4f  vmovaps [rsp+0xE0], xmm1
000078d1a57cfd58  movaps xmm14, xmm6
000078d1a57cfd5c  addpd xmm14, xmm2
000078d1a57cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000078d1a57cfd67  ptest xmm1, xmm1
000078d1a57cfd6c  jnz 0x000078D1A57D279A
000078d1a57cfd72  vmovaps xmm1, [rsp+0xB0]
000078d1a57cfd7b  vpermilpd xmm1, xmm1, 0x00
000078d1a57cfd81  movaps xmm6, xmm5
000078d1a57cfd84  mulpd xmm6, xmm1
000078d1a57cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000078d1a57cfd8d  ptest xmm2, xmm2
000078d1a57cfd92  jnz 0x000078D1A57D28DC
000078d1a57cfd98  vmovaps xmm5, [rsp+0x20]
000078d1a57cfd9e  movaps xmm1, xmm5
000078d1a57cfda1  addpd xmm1, xmm13
000078d1a57cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000078d1a57cfdab  ptest xmm2, xmm2
000078d1a57cfdb0  jnz 0x000078D1A57D2A1C
000078d1a57cfdb6  vmovaps xmm13, [rsp+0x80]
000078d1a57cfdbf  vpermilpd xmm13, xmm13, 0x00
000078d1a57cfdc5  vmovaps xmm2, [rsp+0xE0]
000078d1a57cfdce  vmovaps [rsp+0x20], xmm1
000078d1a57cfdd4  movaps xmm5, xmm2
000078d1a57cfdd7  mulpd xmm5, xmm13
000078d1a57cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000078d1a57cfde1  ptest xmm1, xmm1
000078d1a57cfde6  jnz 0x000078D1A57D2B5D
000078d1a57cfdec  vmovaps xmm1, [rsp+0x80]
000078d1a57cfdf5  vpermilpd xmm1, xmm1, 0x00
000078d1a57cfdfb  movaps xmm13, xmm10
000078d1a57cfdff  mulpd xmm13, xmm1
000078d1a57cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000078d1a57cfe0a  ptest xmm2, xmm2
000078d1a57cfe0f  jnz 0x000078D1A57D2C9E
000078d1a57cfe15  vmovaps xmm10, [rsp+0x30]
000078d1a57cfe1b  movaps xmm1, xmm15
000078d1a57cfe1f  addpd xmm1, xmm10
000078d1a57cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000078d1a57cfe29  ptest xmm2, xmm2
000078d1a57cfe2e  jnz 0x000078D1A57D2DE1
000078d1a57cfe34  vmovaps xmm10, [rsp+0xC0]
000078d1a57cfe3d  movaps xmm15, xmm10
000078d1a57cfe41  addpd xmm15, xmm11
000078d1a57cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000078d1a57cfe4c  ptest xmm2, xmm2
000078d1a57cfe51  jnz 0x000078D1A57D2F23
000078d1a57cfe57  vmovaps xmm11, [rsp+0x80]
000078d1a57cfe60  vpermilpd xmm11, xmm11, 0x00
000078d1a57cfe66  movaps xmm10, xmm12
000078d1a57cfe6a  mulpd xmm10, xmm11
000078d1a57cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000078d1a57cfe75  ptest xmm2, xmm2
000078d1a57cfe7a  jnz 0x000078D1A57D3067
000078d1a57cfe80  vmovaps xmm12, [rsp+0x80]
000078d1a57cfe89  vpermilpd xmm12, xmm12, 0x00
000078d1a57cfe8f  vmovaps xmm2, [rsp+0xA0]
000078d1a57cfe98  vmovaps [rsp+0x30], xmm1
000078d1a57cfe9e  movaps xmm11, xmm2
000078d1a57cfea2  mulpd xmm11, xmm12
000078d1a57cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000078d1a57cfead  ptest xmm1, xmm1
000078d1a57cfeb2  jnz 0x000078D1A57D31AB
000078d1a57cfeb8  movaps xmm1, xmm14
000078d1a57cfebc  addpd xmm1, xmm6
000078d1a57cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000078d1a57cfec5  ptest xmm12, xmm12
000078d1a57cfecb  jnz 0x000078D1A57D32EE
000078d1a57cfed1  vmovaps xmm12, [rsp+0x20]
000078d1a57cfed7  movaps xmm14, xmm12
000078d1a57cfedb  addpd xmm14, xmm5
000078d1a57cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000078d1a57cfee6  ptest xmm6, xmm6
000078d1a57cfeeb  jnz 0x000078D1A57D342F
000078d1a57cfef1  vmovaps xmm12, [rsp+0x90]
000078d1a57cfefa  vpermilpd xmm12, xmm12, 0x00
000078d1a57cff00  movaps xmm6, xmm9
000078d1a57cff04  mulpd xmm6, xmm12
000078d1a57cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000078d1a57cff0e  ptest xmm5, xmm5
000078d1a57cff13  jnz 0x000078D1A57D3572
000078d1a57cff19  movaps xmm12, xmm15
000078d1a57cff1d  addpd xmm12, xmm13
000078d1a57cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000078d1a57cff28  ptest xmm9, xmm9
000078d1a57cff2e  jnz 0x000078D1A57D36B4
000078d1a57cff34  vmovaps xmm13, [rsp+0x30]
000078d1a57cff3a  movaps xmm15, xmm13
000078d1a57cff3e  addpd xmm15, xmm10
000078d1a57cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000078d1a57cff49  ptest xmm9, xmm9
000078d1a57cff4f  jnz 0x000078D1A57D37F8
000078d1a57cff55  vmovaps xmm13, [rsp+0xD0]
000078d1a57cff5e  vmovaps xmm10, [rsp+0xD0]
000078d1a57cff67  por xmm13, xmm10
000078d1a57cff6c  movaps [r15+0x250], xmm13
000078d1a57cff74  vmovaps [rsp+0x20], xmm7
000078d1a57cff7a  vmovaps xmm13, [rsp+0x20]
000078d1a57cff80  por xmm7, xmm13
000078d1a57cff85  movaps [r15+0x2A0], xmm7
000078d1a57cff8d  vmovaps [rsp+0x20], xmm3
000078d1a57cff93  vmovaps xmm13, [rsp+0x20]
000078d1a57cff99  por xmm3, xmm13
000078d1a57cff9e  movaps [r15+0x1D0], xmm3
000078d1a57cffa6  lea rax, [r14+0x40]
000078d1a57cffaa  movups xmm13, [r13+rax*1]
000078d1a57cffb0  movaps [r15+0x2C0], xmm13
000078d1a57cffb8  vmovaps xmm10, [rsp+0x90]
000078d1a57cffc1  vpermilpd xmm10, xmm10, 0x00
000078d1a57cffc7  movaps xmm9, xmm8
000078d1a57cffcb  mulpd xmm9, xmm10
000078d1a57cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000078d1a57cffd6  ptest xmm5, xmm5
000078d1a57cffdb  jnz 0x000078D1A57D3946
000078d1a57cffe1  movaps xmm10, xmm1
000078d1a57cffe5  addpd xmm10, xmm11
000078d1a57cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000078d1a57cfff0  ptest xmm8, xmm8
000078d1a57cfff6  jnz 0x000078D1A57D3A8A
000078d1a57cfffc  movaps xmm1, xmm14
000078d1a57d0000  addpd xmm1, xmm6
000078d1a57d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000078d1a57d0009  ptest xmm11, xmm11
000078d1a57d000f  jnz 0x000078D1A57D3BCD
000078d1a57d0015  vmovaps xmm14, [rsp+0x90]
000078d1a57d001e  vpermilpd xmm14, xmm14, 0x00
000078d1a57d0024  movaps xmm11, xmm13
000078d1a57d0028  mulpd xmm11, xmm14
000078d1a57d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000078d1a57d0033  ptest xmm8, xmm8
000078d1a57d0039  jnz 0x000078D1A57D3D0E
000078d1a57d003f  vmovaps xmm14, [rsp+0x90]
000078d1a57d0048  vpermilpd xmm14, xmm14, 0x00
000078d1a57d004e  vmovaps xmm8, [rsp+0x10]
000078d1a57d0054  movaps xmm13, xmm8
000078d1a57d0058  mulpd xmm13, xmm14
000078d1a57d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000078d1a57d0063  ptest xmm6, xmm6
000078d1a57d0068  jnz 0x000078D1A57D3E52
000078d1a57d006e  vmovaps xmm14, [rsp+0x60]
000078d1a57d0074  vpermilpd xmm14, xmm14, 0x00
000078d1a57d007a  movaps xmm8, xmm7
000078d1a57d007e  mulpd xmm8, xmm14
000078d1a57d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000078d1a57d0089  ptest xmm6, xmm6
000078d1a57d008e  jnz 0x000078D1A57D3F96
000078d1a57d0094  movaps xmm14, xmm12
000078d1a57d0098  addpd xmm14, xmm9
000078d1a57d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000078d1a57d00a3  ptest xmm7, xmm7
000078d1a57d00a8  jnz 0x000078D1A57D40D9
000078d1a57d00ae  vmovaps xmm12, [rsp+0x60]
000078d1a57d00b4  vpermilpd xmm12, xmm12, 0x00
000078d1a57d00ba  vmovaps xmm7, [rsp+0xF0]
000078d1a57d00c3  movaps xmm9, xmm7
000078d1a57d00c7  mulpd xmm9, xmm12
000078d1a57d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000078d1a57d00d2  ptest xmm6, xmm6
000078d1a57d00d7  jnz 0x000078D1A57D421D
000078d1a57d00dd  movaps xmm12, xmm15
000078d1a57d00e1  addpd xmm12, xmm11
000078d1a57d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000078d1a57d00ec  ptest xmm7, xmm7
000078d1a57d00f1  jnz 0x000078D1A57D4360
000078d1a57d00f7  vmovaps xmm15, [rsp+0x60]
000078d1a57d00fd  vpermilpd xmm15, xmm15, 0x00
000078d1a57d0103  vmovaps xmm7, [rsp+0x40]
000078d1a57d0109  movaps xmm11, xmm7
000078d1a57d010d  mulpd xmm11, xmm15
000078d1a57d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000078d1a57d0118  ptest xmm6, xmm6
000078d1a57d011d  jnz 0x000078D1A57D44A4
000078d1a57d0123  movaps xmm15, xmm10
000078d1a57d0127  addpd xmm15, xmm13
000078d1a57d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000078d1a57d0132  ptest xmm7, xmm7
000078d1a57d0137  jnz 0x000078D1A57D45E7
000078d1a57d013d  vmovaps xmm13, [rsp+0x60]
000078d1a57d0143  vpermilpd xmm13, xmm13, 0x00
000078d1a57d0149  vmovaps xmm7, [rsp+0x50]
000078d1a57d014f  movaps xmm10, xmm7
000078d1a57d0153  mulpd xmm10, xmm13
000078d1a57d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000078d1a57d015e  ptest xmm6, xmm6
000078d1a57d0163  jnz 0x000078D1A57D472B
000078d1a57d0169  movaps xmm13, xmm1
000078d1a57d016d  addpd xmm13, xmm8
000078d1a57d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000078d1a57d0178  ptest xmm7, xmm7
000078d1a57d017d  jnz 0x000078D1A57D486E
000078d1a57d0183  lea rax, [r14+0x70]
000078d1a57d0187  movups xmm1, [r13+rax*1]
000078d1a57d018d  movaps [r15+0x240], xmm1
000078d1a57d0195  movaps xmm8, xmm14
000078d1a57d0199  addpd xmm8, xmm9
000078d1a57d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000078d1a57d01a4  ptest xmm7, xmm7
000078d1a57d01a9  jnz 0x000078D1A57D49BB
000078d1a57d01af  movaps [r15+0x170], xmm8
000078d1a57d01b7  vmovaps xmm14, [rsp+0x70]
000078d1a57d01bd  vpermilpd xmm14, xmm14, 0x00
000078d1a57d01c3  movaps xmm9, xmm1
000078d1a57d01c7  mulpd xmm9, xmm14
000078d1a57d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000078d1a57d01d2  ptest xmm7, xmm7
000078d1a57d01d7  jnz 0x000078D1A57D4AFF
000078d1a57d01dd  vmovaps xmm1, [rsp+0x70]
000078d1a57d01e3  vpermilpd xmm1, xmm1, 0x00
000078d1a57d01e9  movaps xmm14, xmm4
000078d1a57d01ed  mulpd xmm14, xmm1
000078d1a57d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000078d1a57d01f8  ptest xmm7, xmm7
000078d1a57d01fd  jnz 0x000078D1A57D4C42
000078d1a57d0203  movaps [r15+0x180], xmm14
000078d1a57d020b  movaps xmm1, xmm12
000078d1a57d020f  addpd xmm1, xmm11
000078d1a57d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000078d1a57d0219  ptest xmm7, xmm7
000078d1a57d021e  jnz 0x000078D1A57D4D84
000078d1a57d0224  movaps [r15+0x210], xmm1
000078d1a57d022c  movups xmm12, [r13+r14*1]
000078d1a57d0232  lea rax, [r14+0x10]
000078d1a57d0236  movups xmm11, [r13+rax*1]
000078d1a57d023c  movaps [r15+0x230], xmm11
000078d1a57d0244  movaps xmm7, xmm15
000078d1a57d0248  addpd xmm7, xmm10
000078d1a57d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000078d1a57d0252  ptest xmm6, xmm6
000078d1a57d0257  jnz 0x000078D1A57D4EDA
000078d1a57d025d  movaps [r15+0x130], xmm7
000078d1a57d0265  vmovaps xmm15, [rsp+0x70]
000078d1a57d026b  vpermilpd xmm15, xmm15, 0x00
000078d1a57d0271  movaps xmm10, xmm11
000078d1a57d0275  mulpd xmm10, xmm15
000078d1a57d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000078d1a57d0280  ptest xmm6, xmm6
000078d1a57d0285  jnz 0x000078D1A57D501C
000078d1a57d028b  movaps [r15+0x220], xmm10
000078d1a57d0293  vmovaps xmm15, [rsp+0x70]
000078d1a57d0299  vpermilpd xmm15, xmm15, 0x00
000078d1a57d029f  movaps xmm11, xmm12
000078d1a57d02a3  mulpd xmm11, xmm15
000078d1a57d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000078d1a57d02ae  ptest xmm6, xmm6
000078d1a57d02b3  jnz 0x000078D1A57D5160
000078d1a57d02b9  movaps xmm15, xmm13
000078d1a57d02bd  addpd xmm15, xmm9
000078d1a57d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000078d1a57d02c8  ptest xmm12, xmm12
000078d1a57d02ce  jnz 0x000078D1A57D52A4
000078d1a57d02d4  movaps [r15+0x140], xmm15
000078d1a57d02dc  movaps xmm13, xmm8
000078d1a57d02e0  addpd xmm13, xmm14
000078d1a57d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000078d1a57d02eb  ptest xmm12, xmm12
000078d1a57d02f1  jnz 0x000078D1A57D53E8
000078d1a57d02f7  movaps [r15+0x150], xmm13
000078d1a57d02ff  movaps xmm14, xmm1
000078d1a57d0303  addpd xmm14, xmm10
000078d1a57d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000078d1a57d030e  ptest xmm12, xmm12
000078d1a57d0314  jnz 0x000078D1A57D552C
000078d1a57d031a  movaps [r15+0x160], xmm14
000078d1a57d0322  movaps xmm1, xmm7
000078d1a57d0325  addpd xmm1, xmm11
000078d1a57d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000078d1a57d032f  ptest xmm12, xmm12
000078d1a57d0335  jnz 0x000078D1A57D566F
000078d1a57d033b  movaps [r15+0x120], xmm1
000078d1a57d0343  mov eax, 0x430920
000078d1a57d0348  movups [r13+rax*1], xmm15
000078d1a57d034e  mov eax, 0x430930
000078d1a57d0353  movups [r13+rax*1], xmm13
000078d1a57d0359  mov eax, 0x430940
000078d1a57d035e  movups [r13+rax*1], xmm14
000078d1a57d0364  mov eax, 0x430950
000078d1a57d0369  movups [r13+rax*1], xmm1
000078d1a57d036f  mov eax, [r15+0x108]
000078d1a57d0376  sahf
000078d1a57d0377  jnz 0x000078D1A57D03A9
000078d1a57d0379  cmp dword ptr [r15+0x318], 0x00
000078d1a57d0381  jz 0x000078D1A57DB900
000078d1a57d0387  nop [rax+rax*1], ax
000078d1a57d0390  nop [rax+rax*1], eax
000078d1a57d0398  mov eax, 0x410444
000078d1a57d039d  mov [r15+0x100], rax
000078d1a57d03a4  jmp 0x000078D1A55FE110
000078d1a57d03a9  cmp dword ptr [r15+0x318], 0x00
000078d1a57d03b1  jz 0x000078D1A57D57E0
000078d1a57d03b7  nop [rax+rax*1], ax
000078d1a57d03c0  nop [rax+rax*1], eax
000078d1a57d03c8  mov eax, 0x410278
000078d1a57d03cd  mov [r15+0x100], rax
000078d1a57d03d4  jmp 0x000078D1A55FE110
000078d1a57d03d9  int3
000078d1a57d03da  call 0x000078D1A56B52F0
000078d1a57d03df  jmp 0x000078D1A57CF016
000078d1a57d03e4  call 0x000078D1A56C4620
000078d1a57d03e9  jmp 0x000078D1A57CF023
000078d1a57d03ee  call 0x000078D1A56C33A0
000078d1a57d03f3  jmp 0x000078D1A57CF035
000078d1a57d03f8  call 0x000078D1A56C2120
000078d1a57d03fd  jmp 0x000078D1A57CF03F
000078d1a57d0402  call 0x000078D1A56C0860
000078d1a57d0407  jmp 0x000078D1A57CF067
000078d1a57d040c  call 0x000078D1A56BF5F0
000078d1a57d0411  jmp 0x000078D1A57CF073
000078d1a57d0416  call 0x000078D1A56C0860
000078d1a57d041b  jmp 0x000078D1A57CF0A5
000078d1a57d0420  call 0x000078D1A56BF5F0
000078d1a57d0425  jmp 0x000078D1A57CF0B1
000078d1a57d042a  call 0x000078D1A56C4740
000078d1a57d042f  jmp 0x000078D1A57CF0BE
000078d1a57d0434  call 0x000078D1A56B5400
000078d1a57d0439  jmp 0x000078D1A57CF0CB
000078d1a57d043e  call 0x000078D1A56B52F0
000078d1a57d0443  jmp 0x000078D1A57CF0D8
000078d1a57d0448  call 0x000078D1A56C4620
000078d1a57d044d  jmp 0x000078D1A57CF0E5
000078d1a57d0452  call 0x000078D1A56C0860
000078d1a57d0457  jmp 0x000078D1A57CF10D
000078d1a57d045c  call 0x000078D1A56BF5F0
000078d1a57d0461  jmp 0x000078D1A57CF119
000078d1a57d0466  call 0x000078D1A5609D70
000078d1a57d046b  jmp 0x000078D1A57CF11F
000078d1a57d0470  call 0x000078D1A56BE9C0
000078d1a57d0475  jmp 0x000078D1A57CF129
000078d1a57d047a  call 0x000078D1A56C0860
000078d1a57d047f  jmp 0x000078D1A57CF151
000078d1a57d0484  call 0x000078D1A56BF5F0
000078d1a57d0489  jmp 0x000078D1A57CF15D
000078d1a57d048e  call 0x000078D1A56BD750
000078d1a57d0493  jmp 0x000078D1A57CF16A
000078d1a57d0498  call 0x000078D1A56BC4E0
000078d1a57d049d  jmp 0x000078D1A57CF177
000078d1a57d04a2  call 0x000078D1A56C4740
000078d1a57d04a7  jmp 0x000078D1A57CF184
000078d1a57d04ac  call 0x000078D1A56B5400
000078d1a57d04b1  jmp 0x000078D1A57CF191
000078d1a57d04b6  call 0x000078D1A56B52F0
000078d1a57d04bb  jmp 0x000078D1A57CF19E
000078d1a57d04c0  call 0x000078D1A56C4620
000078d1a57d04c5  jmp 0x000078D1A57CF1AB
000078d1a57d04ca  call 0x000078D1A56C0860
000078d1a57d04cf  jmp 0x000078D1A57CF1BE
000078d1a57d04d4  call 0x000078D1A56BB270
000078d1a57d04d9  jmp 0x000078D1A57CF1CB
000078d1a57d04de  call 0x000078D1A56BA000
000078d1a57d04e3  jmp 0x000078D1A57CF1D8
000078d1a57d04e8  call 0x000078D1A56B8D90
000078d1a57d04ed  jmp 0x000078D1A57CF1E5
000078d1a57d04f2  call 0x000078D1A56B8A20
000078d1a57d04f7  jmp 0x000078D1A57CF1F2
000078d1a57d04fc  call 0x000078D1A56B5400
000078d1a57d0501  jmp 0x000078D1A57CF1FC
000078d1a57d0506  call 0x000078D1A56C2240
000078d1a57d050b  jmp 0x000078D1A57CF206
000078d1a57d0510  call 0x000078D1A56B52F0
000078d1a57d0515  jmp 0x000078D1A57CF210
000078d1a57d051a  call 0x000078D1A56C2120
000078d1a57d051f  jmp 0x000078D1A57CF21A
000078d1a57d0524  call 0x000078D1A56B77B0
000078d1a57d0529  jmp 0x000078D1A57CF224
000078d1a57d052e  call 0x000078D1A56B6550
000078d1a57d0533  jmp 0x000078D1A57CF22E
000078d1a57d0538  call 0x000078D1A56BFD50
000078d1a57d053d  jmp 0x000078D1A57CF240
000078d1a57d0542  call 0x000078D1A56B8EA0
000078d1a57d0547  jmp 0x000078D1A57CF24A
000078d1a57d054c  call 0x000078D1A56BFC30
000078d1a57d0551  jmp 0x000078D1A57CF257
000078d1a57d0556  call 0x000078D1A56B8D90
000078d1a57d055b  jmp 0x000078D1A57CF264
000078d1a57d0560  call 0x000078D1A56C2240
000078d1a57d0565  jmp 0x000078D1A57CF271
000078d1a57d056a  call 0x000078D1A56B5400
000078d1a57d056f  jmp 0x000078D1A57CF27E
000078d1a57d0574  call 0x000078D1A56B52F0
000078d1a57d0579  jmp 0x000078D1A57CF28B
000078d1a57d057e  call 0x000078D1A56C2120
000078d1a57d0583  jmp 0x000078D1A57CF298
000078d1a57d0588  call 0x000078D1A56B52F0
000078d1a57d058d  jmp 0x000078D1A57CF2AB
000078d1a57d0592  call 0x000078D1A56B52F0
000078d1a57d0597  jmp 0x000078D1A57CF2BE
000078d1a57d059c  call 0x000078D1A56B52F0
000078d1a57d05a1  jmp 0x000078D1A57CF2D1
000078d1a57d05a6  call 0x000078D1A56B52F0
000078d1a57d05ab  jmp 0x000078D1A57CF2E4
000078d1a57d05b0  call 0x000078D1A56C2240
000078d1a57d05b5  jmp 0x000078D1A57CF2F9
000078d1a57d05ba  call 0x000078D1A56C2240
000078d1a57d05bf  jmp 0x000078D1A57CF30C
000078d1a57d05c4  call 0x000078D1A56C2120
000078d1a57d05c9  jmp 0x000078D1A57CF319
000078d1a57d05ce  call 0x000078D1A56B52F0
000078d1a57d05d3  jmp 0x000078D1A57CF32C
000078d1a57d05d8  call 0x000078D1A56B52F0
000078d1a57d05dd  jmp 0x000078D1A57CF34F
000078d1a57d05e2  call 0x000078D1A56B52F0
000078d1a57d05e7  jmp 0x000078D1A57CF362
000078d1a57d05ec  call 0x000078D1A55FF540
000078d1a57d05f1  jmp 0x000078D1A57CF380
000078d1a57d05f6  call 0x000078D1A5608C20
000078d1a57d05fb  jmp 0x000078D1A57CF38A
000078d1a57d0600  call 0x000078D1A56D6600
000078d1a57d0605  jmp 0x000078D1A57CF396
000078d1a57d060a  call 0x000078D1A55FF540
000078d1a57d060f  jmp 0x000078D1A57CF3A6
000078d1a57d0614  call 0x000078D1A56C0370
000078d1a57d0619  jmp 0x000078D1A57CF3D4
000078d1a57d061e  call 0x000078D1A56BF100
000078d1a57d0623  jmp 0x000078D1A57CF3DD
000078d1a57d0628  call 0x000078D1A56C0370
000078d1a57d062d  jmp 0x000078D1A57CF43B
000078d1a57d0632  call 0x000078D1A56BF100
000078d1a57d0637  jmp 0x000078D1A57CF444
000078d1a57d063c  call 0x000078D1A56C0370
000078d1a57d0641  jmp 0x000078D1A57CF48B
000078d1a57d0646  call 0x000078D1A56BF100
000078d1a57d064b  jmp 0x000078D1A57CF494
000078d1a57d0650  call 0x000078D1A560B720
000078d1a57d0655  jmp 0x000078D1A57CF4D7
000078d1a57d065a  call 0x000078D1A56B47C0
000078d1a57d065f  jmp 0x000078D1A57CF4EA
000078d1a57d0664  call 0x000078D1A5608B00
000078d1a57d0669  jmp 0x000078D1A57CF501
000078d1a57d066e  call 0x000078D1A55FF430
000078d1a57d0673  jmp 0x000078D1A57CF514
000078d1a57d0678  call 0x000078D1A55FF430
000078d1a57d067d  jmp 0x000078D1A57CF527
000078d1a57d0682  sub rsp, 0x08
000078d1a57d0686  push rax
000078d1a57d0687  push rcx
000078d1a57d0688  push rdx
000078d1a57d0689  push rdi
000078d1a57d068a  push rsi
000078d1a57d068b  push r8
000078d1a57d068d  push r9
000078d1a57d068f  push r10
000078d1a57d0691  push r11
000078d1a57d0693  sub rsp, 0xF0
000078d1a57d069a  vmovaps [rsp], xmm0
000078d1a57d069f  vmovaps [rsp+0x10], xmm2
000078d1a57d06a5  vmovaps [rsp+0x20], xmm3
000078d1a57d06ab  vmovaps [rsp+0x30], xmm4
000078d1a57d06b1  vmovaps [rsp+0x40], xmm5
000078d1a57d06b7  vmovaps [rsp+0x50], xmm6
000078d1a57d06bd  vmovaps [rsp+0x60], xmm7
000078d1a57d06c3  vmovaps [rsp+0x70], xmm8
000078d1a57d06c9  vmovaps [rsp+0x80], xmm9
000078d1a57d06d2  vmovaps [rsp+0x90], xmm10
000078d1a57d06db  vmovaps [rsp+0xA0], xmm11
000078d1a57d06e4  vmovaps [rsp+0xB0], xmm12
000078d1a57d06ed  vmovaps [rsp+0xC0], xmm13
000078d1a57d06f6  vmovaps [rsp+0xD0], xmm14
000078d1a57d06ff  vmovaps [rsp+0xE0], xmm15
000078d1a57d0708  sub rsp, 0x30
000078d1a57d070c  movaps [rsp], xmm1
000078d1a57d0710  movaps [rsp+0x10], xmm15
000078d1a57d0716  movaps [rsp+0x20], xmm14
000078d1a57d071c  lea rdi, [rsp]
000078d1a57d0720  mov esi, 0x00
000078d1a57d0725  mov rax, 0x56EA20A26530
000078d1a57d072f  call rax
000078d1a57d0731  movaps xmm1, [rsp]
000078d1a57d0735  add rsp, 0x30
000078d1a57d0739  vmovaps xmm0, [rsp]
000078d1a57d073e  vmovaps xmm2, [rsp+0x10]
000078d1a57d0744  vmovaps xmm3, [rsp+0x20]
000078d1a57d074a  vmovaps xmm4, [rsp+0x30]
000078d1a57d0750  vmovaps xmm5, [rsp+0x40]
000078d1a57d0756  vmovaps xmm6, [rsp+0x50]
000078d1a57d075c  vmovaps xmm7, [rsp+0x60]
000078d1a57d0762  vmovaps xmm8, [rsp+0x70]
000078d1a57d0768  vmovaps xmm9, [rsp+0x80]
000078d1a57d0771  vmovaps xmm10, [rsp+0x90]
000078d1a57d077a  vmovaps xmm11, [rsp+0xA0]
000078d1a57d0783  vmovaps xmm12, [rsp+0xB0]
000078d1a57d078c  vmovaps xmm13, [rsp+0xC0]
000078d1a57d0795  vmovaps xmm14, [rsp+0xD0]
000078d1a57d079e  vmovaps xmm15, [rsp+0xE0]
000078d1a57d07a7  add rsp, 0xF0
000078d1a57d07ae  pop r11
000078d1a57d07b0  pop r10
000078d1a57d07b2  pop r9
000078d1a57d07b4  pop r8
000078d1a57d07b6  pop rsi
000078d1a57d07b7  pop rdi
000078d1a57d07b8  pop rdx
000078d1a57d07b9  pop rcx
000078d1a57d07ba  pop rax
000078d1a57d07bb  add rsp, 0x08
000078d1a57d07bf  jmp 0x000078D1A57CF581
000078d1a57d07c4  sub rsp, 0x08
000078d1a57d07c8  push rax
000078d1a57d07c9  push rcx
000078d1a57d07ca  push rdx
000078d1a57d07cb  push rdi
000078d1a57d07cc  push rsi
000078d1a57d07cd  push r8
000078d1a57d07cf  push r9
000078d1a57d07d1  push r10
000078d1a57d07d3  push r11
000078d1a57d07d5  sub rsp, 0xF0
000078d1a57d07dc  vmovaps [rsp], xmm0
000078d1a57d07e1  vmovaps [rsp+0x10], xmm1
000078d1a57d07e7  vmovaps [rsp+0x20], xmm2
000078d1a57d07ed  vmovaps [rsp+0x30], xmm3
000078d1a57d07f3  vmovaps [rsp+0x40], xmm4
000078d1a57d07f9  vmovaps [rsp+0x50], xmm5
000078d1a57d07ff  vmovaps [rsp+0x60], xmm6
000078d1a57d0805  vmovaps [rsp+0x70], xmm7
000078d1a57d080b  vmovaps [rsp+0x80], xmm8
000078d1a57d0814  vmovaps [rsp+0x90], xmm9
000078d1a57d081d  vmovaps [rsp+0xA0], xmm10
000078d1a57d0826  vmovaps [rsp+0xB0], xmm11
000078d1a57d082f  vmovaps [rsp+0xC0], xmm12
000078d1a57d0838  vmovaps [rsp+0xD0], xmm14
000078d1a57d0841  vmovaps [rsp+0xE0], xmm15
000078d1a57d084a  sub rsp, 0x30
000078d1a57d084e  movaps [rsp], xmm13
000078d1a57d0853  movaps [rsp+0x10], xmm1
000078d1a57d0858  movaps [rsp+0x20], xmm14
000078d1a57d085e  lea rdi, [rsp]
000078d1a57d0862  mov esi, 0x00
000078d1a57d0867  mov rax, 0x56EA20A26530
000078d1a57d0871  call rax
000078d1a57d0873  movaps xmm13, [rsp]
000078d1a57d0878  add rsp, 0x30
000078d1a57d087c  vmovaps xmm0, [rsp]
000078d1a57d0881  vmovaps xmm1, [rsp+0x10]
000078d1a57d0887  vmovaps xmm2, [rsp+0x20]
000078d1a57d088d  vmovaps xmm3, [rsp+0x30]
000078d1a57d0893  vmovaps xmm4, [rsp+0x40]
000078d1a57d0899  vmovaps xmm5, [rsp+0x50]
000078d1a57d089f  vmovaps xmm6, [rsp+0x60]
000078d1a57d08a5  vmovaps xmm7, [rsp+0x70]
000078d1a57d08ab  vmovaps xmm8, [rsp+0x80]
000078d1a57d08b4  vmovaps xmm9, [rsp+0x90]
000078d1a57d08bd  vmovaps xmm10, [rsp+0xA0]
000078d1a57d08c6  vmovaps xmm11, [rsp+0xB0]
000078d1a57d08cf  vmovaps xmm12, [rsp+0xC0]
000078d1a57d08d8  vmovaps xmm14, [rsp+0xD0]
000078d1a57d08e1  vmovaps xmm15, [rsp+0xE0]
000078d1a57d08ea  add rsp, 0xF0
000078d1a57d08f1  pop r11
000078d1a57d08f3  pop r10
000078d1a57d08f5  pop r9
000078d1a57d08f7  pop r8
000078d1a57d08f9  pop rsi
000078d1a57d08fa  pop rdi
000078d1a57d08fb  pop rdx
000078d1a57d08fc  pop rcx
000078d1a57d08fd  pop rax
000078d1a57d08fe  add rsp, 0x08
000078d1a57d0902  jmp 0x000078D1A57CF5CF
000078d1a57d0907  sub rsp, 0x08
000078d1a57d090b  push rax
000078d1a57d090c  push rcx
000078d1a57d090d  push rdx
000078d1a57d090e  push rdi
000078d1a57d090f  push rsi
000078d1a57d0910  push r8
000078d1a57d0912  push r9
000078d1a57d0914  push r10
000078d1a57d0916  push r11
000078d1a57d0918  sub rsp, 0xF0
000078d1a57d091f  vmovaps [rsp], xmm0
000078d1a57d0924  vmovaps [rsp+0x10], xmm1
000078d1a57d092a  vmovaps [rsp+0x20], xmm2
000078d1a57d0930  vmovaps [rsp+0x30], xmm3
000078d1a57d0936  vmovaps [rsp+0x40], xmm4
000078d1a57d093c  vmovaps [rsp+0x50], xmm5
000078d1a57d0942  vmovaps [rsp+0x60], xmm6
000078d1a57d0948  vmovaps [rsp+0x70], xmm7
000078d1a57d094e  vmovaps [rsp+0x80], xmm8
000078d1a57d0957  vmovaps [rsp+0x90], xmm9
000078d1a57d0960  vmovaps [rsp+0xA0], xmm10
000078d1a57d0969  vmovaps [rsp+0xB0], xmm11
000078d1a57d0972  vmovaps [rsp+0xC0], xmm12
000078d1a57d097b  vmovaps [rsp+0xD0], xmm13
000078d1a57d0984  vmovaps [rsp+0xE0], xmm14
000078d1a57d098d  sub rsp, 0x30
000078d1a57d0991  movaps [rsp], xmm15
000078d1a57d0996  movaps [rsp+0x10], xmm14
000078d1a57d099c  movaps [rsp+0x20], xmm1
000078d1a57d09a1  lea rdi, [rsp]
000078d1a57d09a5  mov esi, 0x00
000078d1a57d09aa  mov rax, 0x56EA20A26530
000078d1a57d09b4  call rax
000078d1a57d09b6  movaps xmm15, [rsp]
000078d1a57d09bb  add rsp, 0x30
000078d1a57d09bf  vmovaps xmm0, [rsp]
000078d1a57d09c4  vmovaps xmm1, [rsp+0x10]
000078d1a57d09ca  vmovaps xmm2, [rsp+0x20]
000078d1a57d09d0  vmovaps xmm3, [rsp+0x30]
000078d1a57d09d6  vmovaps xmm4, [rsp+0x40]
000078d1a57d09dc  vmovaps xmm5, [rsp+0x50]
000078d1a57d09e2  vmovaps xmm6, [rsp+0x60]
000078d1a57d09e8  vmovaps xmm7, [rsp+0x70]
000078d1a57d09ee  vmovaps xmm8, [rsp+0x80]
000078d1a57d09f7  vmovaps xmm9, [rsp+0x90]
000078d1a57d0a00  vmovaps xmm10, [rsp+0xA0]
000078d1a57d0a09  vmovaps xmm11, [rsp+0xB0]
000078d1a57d0a12  vmovaps xmm12, [rsp+0xC0]
000078d1a57d0a1b  vmovaps xmm13, [rsp+0xD0]
000078d1a57d0a24  vmovaps xmm14, [rsp+0xE0]
000078d1a57d0a2d  add rsp, 0xF0
000078d1a57d0a34  pop r11
000078d1a57d0a36  pop r10
000078d1a57d0a38  pop r9
000078d1a57d0a3a  pop r8
000078d1a57d0a3c  pop rsi
000078d1a57d0a3d  pop rdi
000078d1a57d0a3e  pop rdx
000078d1a57d0a3f  pop rcx
000078d1a57d0a40  pop rax
000078d1a57d0a41  add rsp, 0x08
000078d1a57d0a45  jmp 0x000078D1A57CF617
000078d1a57d0a4a  sub rsp, 0x08
000078d1a57d0a4e  push rax
000078d1a57d0a4f  push rcx
000078d1a57d0a50  push rdx
000078d1a57d0a51  push rdi
000078d1a57d0a52  push rsi
000078d1a57d0a53  push r8
000078d1a57d0a55  push r9
000078d1a57d0a57  push r10
000078d1a57d0a59  push r11
000078d1a57d0a5b  sub rsp, 0xF0
000078d1a57d0a62  vmovaps [rsp], xmm0
000078d1a57d0a67  vmovaps [rsp+0x10], xmm2
000078d1a57d0a6d  vmovaps [rsp+0x20], xmm3
000078d1a57d0a73  vmovaps [rsp+0x30], xmm4
000078d1a57d0a79  vmovaps [rsp+0x40], xmm5
000078d1a57d0a7f  vmovaps [rsp+0x50], xmm6
000078d1a57d0a85  vmovaps [rsp+0x60], xmm7
000078d1a57d0a8b  vmovaps [rsp+0x70], xmm8
000078d1a57d0a91  vmovaps [rsp+0x80], xmm9
000078d1a57d0a9a  vmovaps [rsp+0x90], xmm10
000078d1a57d0aa3  vmovaps [rsp+0xA0], xmm11
000078d1a57d0aac  vmovaps [rsp+0xB0], xmm12
000078d1a57d0ab5  vmovaps [rsp+0xC0], xmm13
000078d1a57d0abe  vmovaps [rsp+0xD0], xmm14
000078d1a57d0ac7  vmovaps [rsp+0xE0], xmm15
000078d1a57d0ad0  sub rsp, 0x30
000078d1a57d0ad4  movaps [rsp], xmm1
000078d1a57d0ad8  movaps [rsp+0x10], xmm14
000078d1a57d0ade  movaps [rsp+0x20], xmm10
000078d1a57d0ae4  lea rdi, [rsp]
000078d1a57d0ae8  mov esi, 0x00
000078d1a57d0aed  mov rax, 0x56EA20A26530
000078d1a57d0af7  call rax
000078d1a57d0af9  movaps xmm1, [rsp]
000078d1a57d0afd  add rsp, 0x30
000078d1a57d0b01  vmovaps xmm0, [rsp]
000078d1a57d0b06  vmovaps xmm2, [rsp+0x10]
000078d1a57d0b0c  vmovaps xmm3, [rsp+0x20]
000078d1a57d0b12  vmovaps xmm4, [rsp+0x30]
000078d1a57d0b18  vmovaps xmm5, [rsp+0x40]
000078d1a57d0b1e  vmovaps xmm6, [rsp+0x50]
000078d1a57d0b24  vmovaps xmm7, [rsp+0x60]
000078d1a57d0b2a  vmovaps xmm8, [rsp+0x70]
000078d1a57d0b30  vmovaps xmm9, [rsp+0x80]
000078d1a57d0b39  vmovaps xmm10, [rsp+0x90]
000078d1a57d0b42  vmovaps xmm11, [rsp+0xA0]
000078d1a57d0b4b  vmovaps xmm12, [rsp+0xB0]
000078d1a57d0b54  vmovaps xmm13, [rsp+0xC0]
000078d1a57d0b5d  vmovaps xmm14, [rsp+0xD0]
000078d1a57d0b66  vmovaps xmm15, [rsp+0xE0]
000078d1a57d0b6f  add rsp, 0xF0
000078d1a57d0b76  pop r11
000078d1a57d0b78  pop r10
000078d1a57d0b7a  pop r9
000078d1a57d0b7c  pop r8
000078d1a57d0b7e  pop rsi
000078d1a57d0b7f  pop rdi
000078d1a57d0b80  pop rdx
000078d1a57d0b81  pop rcx
000078d1a57d0b82  pop rax
000078d1a57d0b83  add rsp, 0x08
000078d1a57d0b87  jmp 0x000078D1A57CF631
000078d1a57d0b8c  sub rsp, 0x08
000078d1a57d0b90  push rax
000078d1a57d0b91  push rcx
000078d1a57d0b92  push rdx
000078d1a57d0b93  push rdi
000078d1a57d0b94  push rsi
000078d1a57d0b95  push r8
000078d1a57d0b97  push r9
000078d1a57d0b99  push r10
000078d1a57d0b9b  push r11
000078d1a57d0b9d  sub rsp, 0xF0
000078d1a57d0ba4  vmovaps [rsp], xmm0
000078d1a57d0ba9  vmovaps [rsp+0x10], xmm1
000078d1a57d0baf  vmovaps [rsp+0x20], xmm2
000078d1a57d0bb5  vmovaps [rsp+0x30], xmm3
000078d1a57d0bbb  vmovaps [rsp+0x40], xmm4
000078d1a57d0bc1  vmovaps [rsp+0x50], xmm5
000078d1a57d0bc7  vmovaps [rsp+0x60], xmm6
000078d1a57d0bcd  vmovaps [rsp+0x70], xmm7
000078d1a57d0bd3  vmovaps [rsp+0x80], xmm8
000078d1a57d0bdc  vmovaps [rsp+0x90], xmm9
000078d1a57d0be5  vmovaps [rsp+0xA0], xmm10
000078d1a57d0bee  vmovaps [rsp+0xB0], xmm11
000078d1a57d0bf7  vmovaps [rsp+0xC0], xmm12
000078d1a57d0c00  vmovaps [rsp+0xD0], xmm14
000078d1a57d0c09  vmovaps [rsp+0xE0], xmm15
000078d1a57d0c12  sub rsp, 0x30
000078d1a57d0c16  movaps [rsp], xmm13
000078d1a57d0c1b  movaps [rsp+0x10], xmm14
000078d1a57d0c21  movaps [rsp+0x20], xmm2
000078d1a57d0c26  lea rdi, [rsp]
000078d1a57d0c2a  mov esi, 0x00
000078d1a57d0c2f  mov rax, 0x56EA20A26530
000078d1a57d0c39  call rax
000078d1a57d0c3b  movaps xmm13, [rsp]
000078d1a57d0c40  add rsp, 0x30
000078d1a57d0c44  vmovaps xmm0, [rsp]
000078d1a57d0c49  vmovaps xmm1, [rsp+0x10]
000078d1a57d0c4f  vmovaps xmm2, [rsp+0x20]
000078d1a57d0c55  vmovaps xmm3, [rsp+0x30]
000078d1a57d0c5b  vmovaps xmm4, [rsp+0x40]
000078d1a57d0c61  vmovaps xmm5, [rsp+0x50]
000078d1a57d0c67  vmovaps xmm6, [rsp+0x60]
000078d1a57d0c6d  vmovaps xmm7, [rsp+0x70]
000078d1a57d0c73  vmovaps xmm8, [rsp+0x80]
000078d1a57d0c7c  vmovaps xmm9, [rsp+0x90]
000078d1a57d0c85  vmovaps xmm10, [rsp+0xA0]
000078d1a57d0c8e  vmovaps xmm11, [rsp+0xB0]
000078d1a57d0c97  vmovaps xmm12, [rsp+0xC0]
000078d1a57d0ca0  vmovaps xmm14, [rsp+0xD0]
000078d1a57d0ca9  vmovaps xmm15, [rsp+0xE0]
000078d1a57d0cb2  add rsp, 0xF0
000078d1a57d0cb9  pop r11
000078d1a57d0cbb  pop r10
000078d1a57d0cbd  pop r9
000078d1a57d0cbf  pop r8
000078d1a57d0cc1  pop rsi
000078d1a57d0cc2  pop rdi
000078d1a57d0cc3  pop rdx
000078d1a57d0cc4  pop rcx
000078d1a57d0cc5  pop rax
000078d1a57d0cc6  add rsp, 0x08
000078d1a57d0cca  jmp 0x000078D1A57CF64C
000078d1a57d0ccf  sub rsp, 0x08
000078d1a57d0cd3  push rax
000078d1a57d0cd4  push rcx
000078d1a57d0cd5  push rdx
000078d1a57d0cd6  push rdi
000078d1a57d0cd7  push rsi
000078d1a57d0cd8  push r8
000078d1a57d0cda  push r9
000078d1a57d0cdc  push r10
000078d1a57d0cde  push r11
000078d1a57d0ce0  sub rsp, 0xF0
000078d1a57d0ce7  vmovaps [rsp], xmm0
000078d1a57d0cec  vmovaps [rsp+0x10], xmm2
000078d1a57d0cf2  vmovaps [rsp+0x20], xmm3
000078d1a57d0cf8  vmovaps [rsp+0x30], xmm4
000078d1a57d0cfe  vmovaps [rsp+0x40], xmm5
000078d1a57d0d04  vmovaps [rsp+0x50], xmm6
000078d1a57d0d0a  vmovaps [rsp+0x60], xmm7
000078d1a57d0d10  vmovaps [rsp+0x70], xmm8
000078d1a57d0d16  vmovaps [rsp+0x80], xmm9
000078d1a57d0d1f  vmovaps [rsp+0x90], xmm10
000078d1a57d0d28  vmovaps [rsp+0xA0], xmm11
000078d1a57d0d31  vmovaps [rsp+0xB0], xmm12
000078d1a57d0d3a  vmovaps [rsp+0xC0], xmm13
000078d1a57d0d43  vmovaps [rsp+0xD0], xmm14
000078d1a57d0d4c  vmovaps [rsp+0xE0], xmm15
000078d1a57d0d55  sub rsp, 0x30
000078d1a57d0d59  movaps [rsp], xmm1
000078d1a57d0d5d  movaps [rsp+0x10], xmm10
000078d1a57d0d63  movaps [rsp+0x20], xmm2
000078d1a57d0d68  lea rdi, [rsp]
000078d1a57d0d6c  mov esi, 0x00
000078d1a57d0d71  mov rax, 0x56EA20A26530
000078d1a57d0d7b  call rax
000078d1a57d0d7d  movaps xmm1, [rsp]
000078d1a57d0d81  add rsp, 0x30
000078d1a57d0d85  vmovaps xmm0, [rsp]
000078d1a57d0d8a  vmovaps xmm2, [rsp+0x10]
000078d1a57d0d90  vmovaps xmm3, [rsp+0x20]
000078d1a57d0d96  vmovaps xmm4, [rsp+0x30]
000078d1a57d0d9c  vmovaps xmm5, [rsp+0x40]
000078d1a57d0da2  vmovaps xmm6, [rsp+0x50]
000078d1a57d0da8  vmovaps xmm7, [rsp+0x60]
000078d1a57d0dae  vmovaps xmm8, [rsp+0x70]
000078d1a57d0db4  vmovaps xmm9, [rsp+0x80]
000078d1a57d0dbd  vmovaps xmm10, [rsp+0x90]
000078d1a57d0dc6  vmovaps xmm11, [rsp+0xA0]
000078d1a57d0dcf  vmovaps xmm12, [rsp+0xB0]
000078d1a57d0dd8  vmovaps xmm13, [rsp+0xC0]
000078d1a57d0de1  vmovaps xmm14, [rsp+0xD0]
000078d1a57d0dea  vmovaps xmm15, [rsp+0xE0]
000078d1a57d0df3  add rsp, 0xF0
000078d1a57d0dfa  pop r11
000078d1a57d0dfc  pop r10
000078d1a57d0dfe  pop r9
000078d1a57d0e00  pop r8
000078d1a57d0e02  pop rsi
000078d1a57d0e03  pop rdi
000078d1a57d0e04  pop rdx
000078d1a57d0e05  pop rcx
000078d1a57d0e06  pop rax
000078d1a57d0e07  add rsp, 0x08
000078d1a57d0e0b  jmp 0x000078D1A57CF6B4
000078d1a57d0e10  sub rsp, 0x08
000078d1a57d0e14  push rax
000078d1a57d0e15  push rcx
000078d1a57d0e16  push rdx
000078d1a57d0e17  push rdi
000078d1a57d0e18  push rsi
000078d1a57d0e19  push r8
000078d1a57d0e1b  push r9
000078d1a57d0e1d  push r10
000078d1a57d0e1f  push r11
000078d1a57d0e21  sub rsp, 0xF0
000078d1a57d0e28  vmovaps [rsp], xmm0
000078d1a57d0e2d  vmovaps [rsp+0x10], xmm1
000078d1a57d0e33  vmovaps [rsp+0x20], xmm2
000078d1a57d0e39  vmovaps [rsp+0x30], xmm3
000078d1a57d0e3f  vmovaps [rsp+0x40], xmm4
000078d1a57d0e45  vmovaps [rsp+0x50], xmm5
000078d1a57d0e4b  vmovaps [rsp+0x60], xmm6
000078d1a57d0e51  vmovaps [rsp+0x70], xmm7
000078d1a57d0e57  vmovaps [rsp+0x80], xmm8
000078d1a57d0e60  vmovaps [rsp+0x90], xmm9
000078d1a57d0e69  vmovaps [rsp+0xA0], xmm10
000078d1a57d0e72  vmovaps [rsp+0xB0], xmm11
000078d1a57d0e7b  vmovaps [rsp+0xC0], xmm12
000078d1a57d0e84  vmovaps [rsp+0xD0], xmm13
000078d1a57d0e8d  vmovaps [rsp+0xE0], xmm14
000078d1a57d0e96  sub rsp, 0x30
000078d1a57d0e9a  movaps [rsp], xmm15
000078d1a57d0e9f  movaps [rsp+0x10], xmm10
000078d1a57d0ea5  movaps [rsp+0x20], xmm2
000078d1a57d0eaa  lea rdi, [rsp]
000078d1a57d0eae  mov esi, 0x00
000078d1a57d0eb3  mov rax, 0x56EA20A26530
000078d1a57d0ebd  call rax
000078d1a57d0ebf  movaps xmm15, [rsp]
000078d1a57d0ec4  add rsp, 0x30
000078d1a57d0ec8  vmovaps xmm0, [rsp]
000078d1a57d0ecd  vmovaps xmm1, [rsp+0x10]
000078d1a57d0ed3  vmovaps xmm2, [rsp+0x20]
000078d1a57d0ed9  vmovaps xmm3, [rsp+0x30]
000078d1a57d0edf  vmovaps xmm4, [rsp+0x40]
000078d1a57d0ee5  vmovaps xmm5, [rsp+0x50]
000078d1a57d0eeb  vmovaps xmm6, [rsp+0x60]
000078d1a57d0ef1  vmovaps xmm7, [rsp+0x70]
000078d1a57d0ef7  vmovaps xmm8, [rsp+0x80]
000078d1a57d0f00  vmovaps xmm9, [rsp+0x90]
000078d1a57d0f09  vmovaps xmm10, [rsp+0xA0]
000078d1a57d0f12  vmovaps xmm11, [rsp+0xB0]
000078d1a57d0f1b  vmovaps xmm12, [rsp+0xC0]
000078d1a57d0f24  vmovaps xmm13, [rsp+0xD0]
000078d1a57d0f2d  vmovaps xmm14, [rsp+0xE0]
000078d1a57d0f36  add rsp, 0xF0
000078d1a57d0f3d  pop r11
000078d1a57d0f3f  pop r10
000078d1a57d0f41  pop r9
000078d1a57d0f43  pop r8
000078d1a57d0f45  pop rsi
000078d1a57d0f46  pop rdi
000078d1a57d0f47  pop rdx
000078d1a57d0f48  pop rcx
000078d1a57d0f49  pop rax
000078d1a57d0f4a  add rsp, 0x08
000078d1a57d0f4e  jmp 0x000078D1A57CF706
000078d1a57d0f53  sub rsp, 0x08
000078d1a57d0f57  push rax
000078d1a57d0f58  push rcx
000078d1a57d0f59  push rdx
000078d1a57d0f5a  push rdi
000078d1a57d0f5b  push rsi
000078d1a57d0f5c  push r8
000078d1a57d0f5e  push r9
000078d1a57d0f60  push r10
000078d1a57d0f62  push r11
000078d1a57d0f64  sub rsp, 0xF0
000078d1a57d0f6b  vmovaps [rsp], xmm0
000078d1a57d0f70  vmovaps [rsp+0x10], xmm2
000078d1a57d0f76  vmovaps [rsp+0x20], xmm3
000078d1a57d0f7c  vmovaps [rsp+0x30], xmm4
000078d1a57d0f82  vmovaps [rsp+0x40], xmm5
000078d1a57d0f88  vmovaps [rsp+0x50], xmm6
000078d1a57d0f8e  vmovaps [rsp+0x60], xmm7
000078d1a57d0f94  vmovaps [rsp+0x70], xmm8
000078d1a57d0f9a  vmovaps [rsp+0x80], xmm9
000078d1a57d0fa3  vmovaps [rsp+0x90], xmm10
000078d1a57d0fac  vmovaps [rsp+0xA0], xmm11
000078d1a57d0fb5  vmovaps [rsp+0xB0], xmm12
000078d1a57d0fbe  vmovaps [rsp+0xC0], xmm13
000078d1a57d0fc7  vmovaps [rsp+0xD0], xmm14
000078d1a57d0fd0  vmovaps [rsp+0xE0], xmm15
000078d1a57d0fd9  sub rsp, 0x30
000078d1a57d0fdd  movaps [rsp], xmm1
000078d1a57d0fe1  movaps [rsp+0x10], xmm10
000078d1a57d0fe7  movaps [rsp+0x20], xmm12
000078d1a57d0fed  lea rdi, [rsp]
000078d1a57d0ff1  mov esi, 0x00
000078d1a57d0ff6  mov rax, 0x56EA20A26530
000078d1a57d1000  call rax
000078d1a57d1002  movaps xmm1, [rsp]
000078d1a57d1006  add rsp, 0x30
000078d1a57d100a  vmovaps xmm0, [rsp]
000078d1a57d100f  vmovaps xmm2, [rsp+0x10]
000078d1a57d1015  vmovaps xmm3, [rsp+0x20]
000078d1a57d101b  vmovaps xmm4, [rsp+0x30]
000078d1a57d1021  vmovaps xmm5, [rsp+0x40]
000078d1a57d1027  vmovaps xmm6, [rsp+0x50]
000078d1a57d102d  vmovaps xmm7, [rsp+0x60]
000078d1a57d1033  vmovaps xmm8, [rsp+0x70]
000078d1a57d1039  vmovaps xmm9, [rsp+0x80]
000078d1a57d1042  vmovaps xmm10, [rsp+0x90]
000078d1a57d104b  vmovaps xmm11, [rsp+0xA0]
000078d1a57d1054  vmovaps xmm12, [rsp+0xB0]
000078d1a57d105d  vmovaps xmm13, [rsp+0xC0]
000078d1a57d1066  vmovaps xmm14, [rsp+0xD0]
000078d1a57d106f  vmovaps xmm15, [rsp+0xE0]
000078d1a57d1078  add rsp, 0xF0
000078d1a57d107f  pop r11
000078d1a57d1081  pop r10
000078d1a57d1083  pop r9
000078d1a57d1085  pop r8
000078d1a57d1087  pop rsi
000078d1a57d1088  pop rdi
000078d1a57d1089  pop rdx
000078d1a57d108a  pop rcx
000078d1a57d108b  pop rax
000078d1a57d108c  add rsp, 0x08
000078d1a57d1090  jmp 0x000078D1A57CF732
000078d1a57d1095  sub rsp, 0x08
000078d1a57d1099  push rax
000078d1a57d109a  push rcx
000078d1a57d109b  push rdx
000078d1a57d109c  push rdi
000078d1a57d109d  push rsi
000078d1a57d109e  push r8
000078d1a57d10a0  push r9
000078d1a57d10a2  push r10
000078d1a57d10a4  push r11
000078d1a57d10a6  sub rsp, 0xF0
000078d1a57d10ad  vmovaps [rsp], xmm0
000078d1a57d10b2  vmovaps [rsp+0x10], xmm1
000078d1a57d10b8  vmovaps [rsp+0x20], xmm2
000078d1a57d10be  vmovaps [rsp+0x30], xmm3
000078d1a57d10c4  vmovaps [rsp+0x40], xmm4
000078d1a57d10ca  vmovaps [rsp+0x50], xmm5
000078d1a57d10d0  vmovaps [rsp+0x60], xmm6
000078d1a57d10d6  vmovaps [rsp+0x70], xmm7
000078d1a57d10dc  vmovaps [rsp+0x80], xmm8
000078d1a57d10e5  vmovaps [rsp+0x90], xmm9
000078d1a57d10ee  vmovaps [rsp+0xA0], xmm10
000078d1a57d10f7  vmovaps [rsp+0xB0], xmm11
000078d1a57d1100  vmovaps [rsp+0xC0], xmm12
000078d1a57d1109  vmovaps [rsp+0xD0], xmm13
000078d1a57d1112  vmovaps [rsp+0xE0], xmm14
000078d1a57d111b  sub rsp, 0x30
000078d1a57d111f  movaps [rsp], xmm15
000078d1a57d1124  movaps [rsp+0x10], xmm10
000078d1a57d112a  movaps [rsp+0x20], xmm12
000078d1a57d1130  lea rdi, [rsp]
000078d1a57d1134  mov esi, 0x00
000078d1a57d1139  mov rax, 0x56EA20A26530
000078d1a57d1143  call rax
000078d1a57d1145  movaps xmm15, [rsp]
000078d1a57d114a  add rsp, 0x30
000078d1a57d114e  vmovaps xmm0, [rsp]
000078d1a57d1153  vmovaps xmm1, [rsp+0x10]
000078d1a57d1159  vmovaps xmm2, [rsp+0x20]
000078d1a57d115f  vmovaps xmm3, [rsp+0x30]
000078d1a57d1165  vmovaps xmm4, [rsp+0x40]
000078d1a57d116b  vmovaps xmm5, [rsp+0x50]
000078d1a57d1171  vmovaps xmm6, [rsp+0x60]
000078d1a57d1177  vmovaps xmm7, [rsp+0x70]
000078d1a57d117d  vmovaps xmm8, [rsp+0x80]
000078d1a57d1186  vmovaps xmm9, [rsp+0x90]
000078d1a57d118f  vmovaps xmm10, [rsp+0xA0]
000078d1a57d1198  vmovaps xmm11, [rsp+0xB0]
000078d1a57d11a1  vmovaps xmm12, [rsp+0xC0]
000078d1a57d11aa  vmovaps xmm13, [rsp+0xD0]
000078d1a57d11b3  vmovaps xmm14, [rsp+0xE0]
000078d1a57d11bc  add rsp, 0xF0
000078d1a57d11c3  pop r11
000078d1a57d11c5  pop r10
000078d1a57d11c7  pop r9
000078d1a57d11c9  pop r8
000078d1a57d11cb  pop rsi
000078d1a57d11cc  pop rdi
000078d1a57d11cd  pop rdx
000078d1a57d11ce  pop rcx
000078d1a57d11cf  pop rax
000078d1a57d11d0  add rsp, 0x08
000078d1a57d11d4  jmp 0x000078D1A57CF75E
000078d1a57d11d9  call 0x000078D1A55FF430
000078d1a57d11de  jmp 0x000078D1A57CF7EE
000078d1a57d11e3  call 0x000078D1A55FF430
000078d1a57d11e8  jmp 0x000078D1A57CF801
000078d1a57d11ed  sub rsp, 0x08
000078d1a57d11f1  push rax
000078d1a57d11f2  push rcx
000078d1a57d11f3  push rdx
000078d1a57d11f4  push rdi
000078d1a57d11f5  push rsi
000078d1a57d11f6  push r8
000078d1a57d11f8  push r9
000078d1a57d11fa  push r10
000078d1a57d11fc  push r11
000078d1a57d11fe  sub rsp, 0xF0
000078d1a57d1205  vmovaps [rsp], xmm0
000078d1a57d120a  vmovaps [rsp+0x10], xmm2
000078d1a57d1210  vmovaps [rsp+0x20], xmm3
000078d1a57d1216  vmovaps [rsp+0x30], xmm4
000078d1a57d121c  vmovaps [rsp+0x40], xmm5
000078d1a57d1222  vmovaps [rsp+0x50], xmm6
000078d1a57d1228  vmovaps [rsp+0x60], xmm7
000078d1a57d122e  vmovaps [rsp+0x70], xmm8
000078d1a57d1234  vmovaps [rsp+0x80], xmm9
000078d1a57d123d  vmovaps [rsp+0x90], xmm10
000078d1a57d1246  vmovaps [rsp+0xA0], xmm11
000078d1a57d124f  vmovaps [rsp+0xB0], xmm12
000078d1a57d1258  vmovaps [rsp+0xC0], xmm13
000078d1a57d1261  vmovaps [rsp+0xD0], xmm14
000078d1a57d126a  vmovaps [rsp+0xE0], xmm15
000078d1a57d1273  sub rsp, 0x30
000078d1a57d1277  movaps [rsp], xmm1
000078d1a57d127b  movaps [rsp+0x10], xmm13
000078d1a57d1281  movaps [rsp+0x20], xmm2
000078d1a57d1286  lea rdi, [rsp]
000078d1a57d128a  mov esi, 0x00
000078d1a57d128f  mov rax, 0x56EA20A26530
000078d1a57d1299  call rax
000078d1a57d129b  movaps xmm1, [rsp]
000078d1a57d129f  add rsp, 0x30
000078d1a57d12a3  vmovaps xmm0, [rsp]
000078d1a57d12a8  vmovaps xmm2, [rsp+0x10]
000078d1a57d12ae  vmovaps xmm3, [rsp+0x20]
000078d1a57d12b4  vmovaps xmm4, [rsp+0x30]
000078d1a57d12ba  vmovaps xmm5, [rsp+0x40]
000078d1a57d12c0  vmovaps xmm6, [rsp+0x50]
000078d1a57d12c6  vmovaps xmm7, [rsp+0x60]
000078d1a57d12cc  vmovaps xmm8, [rsp+0x70]
000078d1a57d12d2  vmovaps xmm9, [rsp+0x80]
000078d1a57d12db  vmovaps xmm10, [rsp+0x90]
000078d1a57d12e4  vmovaps xmm11, [rsp+0xA0]
000078d1a57d12ed  vmovaps xmm12, [rsp+0xB0]
000078d1a57d12f6  vmovaps xmm13, [rsp+0xC0]
000078d1a57d12ff  vmovaps xmm14, [rsp+0xD0]
000078d1a57d1308  vmovaps xmm15, [rsp+0xE0]
000078d1a57d1311  add rsp, 0xF0
000078d1a57d1318  pop r11
000078d1a57d131a  pop r10
000078d1a57d131c  pop r9
000078d1a57d131e  pop r8
000078d1a57d1320  pop rsi
000078d1a57d1321  pop rdi
000078d1a57d1322  pop rdx
000078d1a57d1323  pop rcx
000078d1a57d1324  pop rax
000078d1a57d1325  add rsp, 0x08
000078d1a57d1329  jmp 0x000078D1A57CF82C
000078d1a57d132e  call 0x000078D1A560E760
000078d1a57d1333  jmp 0x000078D1A57CF839
000078d1a57d1338  sub rsp, 0x08
000078d1a57d133c  push rax
000078d1a57d133d  push rcx
000078d1a57d133e  push rdx
000078d1a57d133f  push rdi
000078d1a57d1340  push rsi
000078d1a57d1341  push r8
000078d1a57d1343  push r9
000078d1a57d1345  push r10
000078d1a57d1347  push r11
000078d1a57d1349  sub rsp, 0xF0
000078d1a57d1350  vmovaps [rsp], xmm0
000078d1a57d1355  vmovaps [rsp+0x10], xmm1
000078d1a57d135b  vmovaps [rsp+0x20], xmm2
000078d1a57d1361  vmovaps [rsp+0x30], xmm3
000078d1a57d1367  vmovaps [rsp+0x40], xmm4
000078d1a57d136d  vmovaps [rsp+0x50], xmm5
000078d1a57d1373  vmovaps [rsp+0x60], xmm6
000078d1a57d1379  vmovaps [rsp+0x70], xmm7
000078d1a57d137f  vmovaps [rsp+0x80], xmm8
000078d1a57d1388  vmovaps [rsp+0x90], xmm9
000078d1a57d1391  vmovaps [rsp+0xA0], xmm10
000078d1a57d139a  vmovaps [rsp+0xB0], xmm11
000078d1a57d13a3  vmovaps [rsp+0xC0], xmm12
000078d1a57d13ac  vmovaps [rsp+0xD0], xmm14
000078d1a57d13b5  vmovaps [rsp+0xE0], xmm15
000078d1a57d13be  sub rsp, 0x30
000078d1a57d13c2  movaps [rsp], xmm13
000078d1a57d13c7  movaps [rsp+0x10], xmm2
000078d1a57d13cc  movaps [rsp+0x20], xmm1
000078d1a57d13d1  lea rdi, [rsp]
000078d1a57d13d5  mov esi, 0x00
000078d1a57d13da  mov rax, 0x56EA20A26530
000078d1a57d13e4  call rax
000078d1a57d13e6  movaps xmm13, [rsp]
000078d1a57d13eb  add rsp, 0x30
000078d1a57d13ef  vmovaps xmm0, [rsp]
000078d1a57d13f4  vmovaps xmm1, [rsp+0x10]
000078d1a57d13fa  vmovaps xmm2, [rsp+0x20]
000078d1a57d1400  vmovaps xmm3, [rsp+0x30]
000078d1a57d1406  vmovaps xmm4, [rsp+0x40]
000078d1a57d140c  vmovaps xmm5, [rsp+0x50]
000078d1a57d1412  vmovaps xmm6, [rsp+0x60]
000078d1a57d1418  vmovaps xmm7, [rsp+0x70]
000078d1a57d141e  vmovaps xmm8, [rsp+0x80]
000078d1a57d1427  vmovaps xmm9, [rsp+0x90]
000078d1a57d1430  vmovaps xmm10, [rsp+0xA0]
000078d1a57d1439  vmovaps xmm11, [rsp+0xB0]
000078d1a57d1442  vmovaps xmm12, [rsp+0xC0]
000078d1a57d144b  vmovaps xmm14, [rsp+0xD0]
000078d1a57d1454  vmovaps xmm15, [rsp+0xE0]
000078d1a57d145d  add rsp, 0xF0
000078d1a57d1464  pop r11
000078d1a57d1466  pop r10
000078d1a57d1468  pop r9
000078d1a57d146a  pop r8
000078d1a57d146c  pop rsi
000078d1a57d146d  pop rdi
000078d1a57d146e  pop rdx
000078d1a57d146f  pop rcx
000078d1a57d1470  pop rax
000078d1a57d1471  add rsp, 0x08
000078d1a57d1475  jmp 0x000078D1A57CF878
000078d1a57d147a  sub rsp, 0x08
000078d1a57d147e  push rax
000078d1a57d147f  push rcx
000078d1a57d1480  push rdx
000078d1a57d1481  push rdi
000078d1a57d1482  push rsi
000078d1a57d1483  push r8
000078d1a57d1485  push r9
000078d1a57d1487  push r10
000078d1a57d1489  push r11
000078d1a57d148b  sub rsp, 0xF0
000078d1a57d1492  vmovaps [rsp], xmm0
000078d1a57d1497  vmovaps [rsp+0x10], xmm2
000078d1a57d149d  vmovaps [rsp+0x20], xmm3
000078d1a57d14a3  vmovaps [rsp+0x30], xmm4
000078d1a57d14a9  vmovaps [rsp+0x40], xmm5
000078d1a57d14af  vmovaps [rsp+0x50], xmm6
000078d1a57d14b5  vmovaps [rsp+0x60], xmm7
000078d1a57d14bb  vmovaps [rsp+0x70], xmm8
000078d1a57d14c1  vmovaps [rsp+0x80], xmm9
000078d1a57d14ca  vmovaps [rsp+0x90], xmm10
000078d1a57d14d3  vmovaps [rsp+0xA0], xmm11
000078d1a57d14dc  vmovaps [rsp+0xB0], xmm12
000078d1a57d14e5  vmovaps [rsp+0xC0], xmm13
000078d1a57d14ee  vmovaps [rsp+0xD0], xmm14
000078d1a57d14f7  vmovaps [rsp+0xE0], xmm15
000078d1a57d1500  sub rsp, 0x30
000078d1a57d1504  movaps [rsp], xmm1
000078d1a57d1508  movaps [rsp+0x10], xmm15
000078d1a57d150e  movaps [rsp+0x20], xmm2
000078d1a57d1513  lea rdi, [rsp]
000078d1a57d1517  mov esi, 0x00
000078d1a57d151c  mov rax, 0x56EA20A26530
000078d1a57d1526  call rax
000078d1a57d1528  movaps xmm1, [rsp]
000078d1a57d152c  add rsp, 0x30
000078d1a57d1530  vmovaps xmm0, [rsp]
000078d1a57d1535  vmovaps xmm2, [rsp+0x10]
000078d1a57d153b  vmovaps xmm3, [rsp+0x20]
000078d1a57d1541  vmovaps xmm4, [rsp+0x30]
000078d1a57d1547  vmovaps xmm5, [rsp+0x40]
000078d1a57d154d  vmovaps xmm6, [rsp+0x50]
000078d1a57d1553  vmovaps xmm7, [rsp+0x60]
000078d1a57d1559  vmovaps xmm8, [rsp+0x70]
000078d1a57d155f  vmovaps xmm9, [rsp+0x80]
000078d1a57d1568  vmovaps xmm10, [rsp+0x90]
000078d1a57d1571  vmovaps xmm11, [rsp+0xA0]
000078d1a57d157a  vmovaps xmm12, [rsp+0xB0]
000078d1a57d1583  vmovaps xmm13, [rsp+0xC0]
000078d1a57d158c  vmovaps xmm14, [rsp+0xD0]
000078d1a57d1595  vmovaps xmm15, [rsp+0xE0]
000078d1a57d159e  add rsp, 0xF0
000078d1a57d15a5  pop r11
000078d1a57d15a7  pop r10
000078d1a57d15a9  pop r9
000078d1a57d15ab  pop r8
000078d1a57d15ad  pop rsi
000078d1a57d15ae  pop rdi
000078d1a57d15af  pop rdx
000078d1a57d15b0  pop rcx
000078d1a57d15b1  pop rax
000078d1a57d15b2  add rsp, 0x08
000078d1a57d15b6  jmp 0x000078D1A57CF8AC
000078d1a57d15bb  sub rsp, 0x08
000078d1a57d15bf  push rax
000078d1a57d15c0  push rcx
000078d1a57d15c1  push rdx
000078d1a57d15c2  push rdi
000078d1a57d15c3  push rsi
000078d1a57d15c4  push r8
000078d1a57d15c6  push r9
000078d1a57d15c8  push r10
000078d1a57d15ca  push r11
000078d1a57d15cc  sub rsp, 0xF0
000078d1a57d15d3  vmovaps [rsp], xmm0
000078d1a57d15d8  vmovaps [rsp+0x10], xmm1
000078d1a57d15de  vmovaps [rsp+0x20], xmm2
000078d1a57d15e4  vmovaps [rsp+0x30], xmm3
000078d1a57d15ea  vmovaps [rsp+0x40], xmm4
000078d1a57d15f0  vmovaps [rsp+0x50], xmm5
000078d1a57d15f6  vmovaps [rsp+0x60], xmm6
000078d1a57d15fc  vmovaps [rsp+0x70], xmm7
000078d1a57d1602  vmovaps [rsp+0x80], xmm8
000078d1a57d160b  vmovaps [rsp+0x90], xmm9
000078d1a57d1614  vmovaps [rsp+0xA0], xmm10
000078d1a57d161d  vmovaps [rsp+0xB0], xmm11
000078d1a57d1626  vmovaps [rsp+0xC0], xmm12
000078d1a57d162f  vmovaps [rsp+0xD0], xmm13
000078d1a57d1638  vmovaps [rsp+0xE0], xmm15
000078d1a57d1641  sub rsp, 0x30
000078d1a57d1645  movaps [rsp], xmm14
000078d1a57d164a  movaps [rsp+0x10], xmm2
000078d1a57d164f  movaps [rsp+0x20], xmm15
000078d1a57d1655  lea rdi, [rsp]
000078d1a57d1659  mov esi, 0x00
000078d1a57d165e  mov rax, 0x56EA20A26530
000078d1a57d1668  call rax
000078d1a57d166a  movaps xmm14, [rsp]
000078d1a57d166f  add rsp, 0x30
000078d1a57d1673  vmovaps xmm0, [rsp]
000078d1a57d1678  vmovaps xmm1, [rsp+0x10]
000078d1a57d167e  vmovaps xmm2, [rsp+0x20]
000078d1a57d1684  vmovaps xmm3, [rsp+0x30]
000078d1a57d168a  vmovaps xmm4, [rsp+0x40]
000078d1a57d1690  vmovaps xmm5, [rsp+0x50]
000078d1a57d1696  vmovaps xmm6, [rsp+0x60]
000078d1a57d169c  vmovaps xmm7, [rsp+0x70]
000078d1a57d16a2  vmovaps xmm8, [rsp+0x80]
000078d1a57d16ab  vmovaps xmm9, [rsp+0x90]
000078d1a57d16b4  vmovaps xmm10, [rsp+0xA0]
000078d1a57d16bd  vmovaps xmm11, [rsp+0xB0]
000078d1a57d16c6  vmovaps xmm12, [rsp+0xC0]
000078d1a57d16cf  vmovaps xmm13, [rsp+0xD0]
000078d1a57d16d8  vmovaps xmm15, [rsp+0xE0]
000078d1a57d16e1  add rsp, 0xF0
000078d1a57d16e8  pop r11
000078d1a57d16ea  pop r10
000078d1a57d16ec  pop r9
000078d1a57d16ee  pop r8
000078d1a57d16f0  pop rsi
000078d1a57d16f1  pop rdi
000078d1a57d16f2  pop rdx
000078d1a57d16f3  pop rcx
000078d1a57d16f4  pop rax
000078d1a57d16f5  add rsp, 0x08
000078d1a57d16f9  jmp 0x000078D1A57CF8E7
000078d1a57d16fe  sub rsp, 0x08
000078d1a57d1702  push rax
000078d1a57d1703  push rcx
000078d1a57d1704  push rdx
000078d1a57d1705  push rdi
000078d1a57d1706  push rsi
000078d1a57d1707  push r8
000078d1a57d1709  push r9
000078d1a57d170b  push r10
000078d1a57d170d  push r11
000078d1a57d170f  sub rsp, 0xF0
000078d1a57d1716  vmovaps [rsp], xmm0
000078d1a57d171b  vmovaps [rsp+0x10], xmm1
000078d1a57d1721  vmovaps [rsp+0x20], xmm2
000078d1a57d1727  vmovaps [rsp+0x30], xmm3
000078d1a57d172d  vmovaps [rsp+0x40], xmm4
000078d1a57d1733  vmovaps [rsp+0x50], xmm5
000078d1a57d1739  vmovaps [rsp+0x60], xmm6
000078d1a57d173f  vmovaps [rsp+0x70], xmm7
000078d1a57d1745  vmovaps [rsp+0x80], xmm8
000078d1a57d174e  vmovaps [rsp+0x90], xmm9
000078d1a57d1757  vmovaps [rsp+0xA0], xmm10
000078d1a57d1760  vmovaps [rsp+0xB0], xmm11
000078d1a57d1769  vmovaps [rsp+0xC0], xmm12
000078d1a57d1772  vmovaps [rsp+0xD0], xmm13
000078d1a57d177b  vmovaps [rsp+0xE0], xmm14
000078d1a57d1784  sub rsp, 0x30
000078d1a57d1788  movaps [rsp], xmm15
000078d1a57d178d  movaps [rsp+0x10], xmm2
000078d1a57d1792  movaps [rsp+0x20], xmm1
000078d1a57d1797  lea rdi, [rsp]
000078d1a57d179b  mov esi, 0x00
000078d1a57d17a0  mov rax, 0x56EA20A26530
000078d1a57d17aa  call rax
000078d1a57d17ac  movaps xmm15, [rsp]
000078d1a57d17b1  add rsp, 0x30
000078d1a57d17b5  vmovaps xmm0, [rsp]
000078d1a57d17ba  vmovaps xmm1, [rsp+0x10]
000078d1a57d17c0  vmovaps xmm2, [rsp+0x20]
000078d1a57d17c6  vmovaps xmm3, [rsp+0x30]
000078d1a57d17cc  vmovaps xmm4, [rsp+0x40]
000078d1a57d17d2  vmovaps xmm5, [rsp+0x50]
000078d1a57d17d8  vmovaps xmm6, [rsp+0x60]
000078d1a57d17de  vmovaps xmm7, [rsp+0x70]
000078d1a57d17e4  vmovaps xmm8, [rsp+0x80]
000078d1a57d17ed  vmovaps xmm9, [rsp+0x90]
000078d1a57d17f6  vmovaps xmm10, [rsp+0xA0]
000078d1a57d17ff  vmovaps xmm11, [rsp+0xB0]
000078d1a57d1808  vmovaps xmm12, [rsp+0xC0]
000078d1a57d1811  vmovaps xmm13, [rsp+0xD0]
000078d1a57d181a  vmovaps xmm14, [rsp+0xE0]
000078d1a57d1823  add rsp, 0xF0
000078d1a57d182a  pop r11
000078d1a57d182c  pop r10
000078d1a57d182e  pop r9
000078d1a57d1830  pop r8
000078d1a57d1832  pop rsi
000078d1a57d1833  pop rdi
000078d1a57d1834  pop rdx
000078d1a57d1835  pop rcx
000078d1a57d1836  pop rax
000078d1a57d1837  add rsp, 0x08
000078d1a57d183b  jmp 0x000078D1A57CF923
000078d1a57d1840  call 0x000078D1A55FF430
000078d1a57d1845  jmp 0x000078D1A57CF930
000078d1a57d184a  sub rsp, 0x08
000078d1a57d184e  push rax
000078d1a57d184f  push rcx
000078d1a57d1850  push rdx
000078d1a57d1851  push rdi
000078d1a57d1852  push rsi
000078d1a57d1853  push r8
000078d1a57d1855  push r9
000078d1a57d1857  push r10
000078d1a57d1859  push r11
000078d1a57d185b  sub rsp, 0xF0
000078d1a57d1862  vmovaps [rsp], xmm0
000078d1a57d1867  vmovaps [rsp+0x10], xmm1
000078d1a57d186d  vmovaps [rsp+0x20], xmm3
000078d1a57d1873  vmovaps [rsp+0x30], xmm4
000078d1a57d1879  vmovaps [rsp+0x40], xmm5
000078d1a57d187f  vmovaps [rsp+0x50], xmm6
000078d1a57d1885  vmovaps [rsp+0x60], xmm7
000078d1a57d188b  vmovaps [rsp+0x70], xmm8
000078d1a57d1891  vmovaps [rsp+0x80], xmm9
000078d1a57d189a  vmovaps [rsp+0x90], xmm10
000078d1a57d18a3  vmovaps [rsp+0xA0], xmm11
000078d1a57d18ac  vmovaps [rsp+0xB0], xmm12
000078d1a57d18b5  vmovaps [rsp+0xC0], xmm13
000078d1a57d18be  vmovaps [rsp+0xD0], xmm14
000078d1a57d18c7  vmovaps [rsp+0xE0], xmm15
000078d1a57d18d0  sub rsp, 0x30
000078d1a57d18d4  movaps [rsp], xmm2
000078d1a57d18d8  movaps [rsp+0x10], xmm1
000078d1a57d18dd  movaps [rsp+0x20], xmm14
000078d1a57d18e3  lea rdi, [rsp]
000078d1a57d18e7  mov esi, 0x00
000078d1a57d18ec  mov rax, 0x56EA20A26530
000078d1a57d18f6  call rax
000078d1a57d18f8  movaps xmm2, [rsp]
000078d1a57d18fc  add rsp, 0x30
000078d1a57d1900  vmovaps xmm0, [rsp]
000078d1a57d1905  vmovaps xmm1, [rsp+0x10]
000078d1a57d190b  vmovaps xmm3, [rsp+0x20]
000078d1a57d1911  vmovaps xmm4, [rsp+0x30]
000078d1a57d1917  vmovaps xmm5, [rsp+0x40]
000078d1a57d191d  vmovaps xmm6, [rsp+0x50]
000078d1a57d1923  vmovaps xmm7, [rsp+0x60]
000078d1a57d1929  vmovaps xmm8, [rsp+0x70]
000078d1a57d192f  vmovaps xmm9, [rsp+0x80]
000078d1a57d1938  vmovaps xmm10, [rsp+0x90]
000078d1a57d1941  vmovaps xmm11, [rsp+0xA0]
000078d1a57d194a  vmovaps xmm12, [rsp+0xB0]
000078d1a57d1953  vmovaps xmm13, [rsp+0xC0]
000078d1a57d195c  vmovaps xmm14, [rsp+0xD0]
000078d1a57d1965  vmovaps xmm15, [rsp+0xE0]
000078d1a57d196e  add rsp, 0xF0
000078d1a57d1975  pop r11
000078d1a57d1977  pop r10
000078d1a57d1979  pop r9
000078d1a57d197b  pop r8
000078d1a57d197d  pop rsi
000078d1a57d197e  pop rdi
000078d1a57d197f  pop rdx
000078d1a57d1980  pop rcx
000078d1a57d1981  pop rax
000078d1a57d1982  add rsp, 0x08
000078d1a57d1986  jmp 0x000078D1A57CF96D
000078d1a57d198b  sub rsp, 0x08
000078d1a57d198f  push rax
000078d1a57d1990  push rcx
000078d1a57d1991  push rdx
000078d1a57d1992  push rdi
000078d1a57d1993  push rsi
000078d1a57d1994  push r8
000078d1a57d1996  push r9
000078d1a57d1998  push r10
000078d1a57d199a  push r11
000078d1a57d199c  sub rsp, 0xF0
000078d1a57d19a3  vmovaps [rsp], xmm0
000078d1a57d19a8  vmovaps [rsp+0x10], xmm1
000078d1a57d19ae  vmovaps [rsp+0x20], xmm2
000078d1a57d19b4  vmovaps [rsp+0x30], xmm3
000078d1a57d19ba  vmovaps [rsp+0x40], xmm4
000078d1a57d19c0  vmovaps [rsp+0x50], xmm5
000078d1a57d19c6  vmovaps [rsp+0x60], xmm6
000078d1a57d19cc  vmovaps [rsp+0x70], xmm7
000078d1a57d19d2  vmovaps [rsp+0x80], xmm8
000078d1a57d19db  vmovaps [rsp+0x90], xmm9
000078d1a57d19e4  vmovaps [rsp+0xA0], xmm10
000078d1a57d19ed  vmovaps [rsp+0xB0], xmm11
000078d1a57d19f6  vmovaps [rsp+0xC0], xmm12
000078d1a57d19ff  vmovaps [rsp+0xD0], xmm13
000078d1a57d1a08  vmovaps [rsp+0xE0], xmm14
000078d1a57d1a11  sub rsp, 0x30
000078d1a57d1a15  movaps [rsp], xmm15
000078d1a57d1a1a  movaps [rsp+0x10], xmm14
000078d1a57d1a20  movaps [rsp+0x20], xmm1
000078d1a57d1a25  lea rdi, [rsp]
000078d1a57d1a29  mov esi, 0x00
000078d1a57d1a2e  mov rax, 0x56EA20A26530
000078d1a57d1a38  call rax
000078d1a57d1a3a  movaps xmm15, [rsp]
000078d1a57d1a3f  add rsp, 0x30
000078d1a57d1a43  vmovaps xmm0, [rsp]
000078d1a57d1a48  vmovaps xmm1, [rsp+0x10]
000078d1a57d1a4e  vmovaps xmm2, [rsp+0x20]
000078d1a57d1a54  vmovaps xmm3, [rsp+0x30]
000078d1a57d1a5a  vmovaps xmm4, [rsp+0x40]
000078d1a57d1a60  vmovaps xmm5, [rsp+0x50]
000078d1a57d1a66  vmovaps xmm6, [rsp+0x60]
000078d1a57d1a6c  vmovaps xmm7, [rsp+0x70]
000078d1a57d1a72  vmovaps xmm8, [rsp+0x80]
000078d1a57d1a7b  vmovaps xmm9, [rsp+0x90]
000078d1a57d1a84  vmovaps xmm10, [rsp+0xA0]
000078d1a57d1a8d  vmovaps xmm11, [rsp+0xB0]
000078d1a57d1a96  vmovaps xmm12, [rsp+0xC0]
000078d1a57d1a9f  vmovaps xmm13, [rsp+0xD0]
000078d1a57d1aa8  vmovaps xmm14, [rsp+0xE0]
000078d1a57d1ab1  add rsp, 0xF0
000078d1a57d1ab8  pop r11
000078d1a57d1aba  pop r10
000078d1a57d1abc  pop r9
000078d1a57d1abe  pop r8
000078d1a57d1ac0  pop rsi
000078d1a57d1ac1  pop rdi
000078d1a57d1ac2  pop rdx
000078d1a57d1ac3  pop rcx
000078d1a57d1ac4  pop rax
000078d1a57d1ac5  add rsp, 0x08
000078d1a57d1ac9  jmp 0x000078D1A57CF9E7
000078d1a57d1ace  call 0x000078D1A55FF430
000078d1a57d1ad3  jmp 0x000078D1A57CF9F4
000078d1a57d1ad8  sub rsp, 0x08
000078d1a57d1adc  push rax
000078d1a57d1add  push rcx
000078d1a57d1ade  push rdx
000078d1a57d1adf  push rdi
000078d1a57d1ae0  push rsi
000078d1a57d1ae1  push r8
000078d1a57d1ae3  push r9
000078d1a57d1ae5  push r10
000078d1a57d1ae7  push r11
000078d1a57d1ae9  sub rsp, 0xF0
000078d1a57d1af0  vmovaps [rsp], xmm0
000078d1a57d1af5  vmovaps [rsp+0x10], xmm1
000078d1a57d1afb  vmovaps [rsp+0x20], xmm2
000078d1a57d1b01  vmovaps [rsp+0x30], xmm3
000078d1a57d1b07  vmovaps [rsp+0x40], xmm4
000078d1a57d1b0d  vmovaps [rsp+0x50], xmm5
000078d1a57d1b13  vmovaps [rsp+0x60], xmm6
000078d1a57d1b19  vmovaps [rsp+0x70], xmm7
000078d1a57d1b1f  vmovaps [rsp+0x80], xmm8
000078d1a57d1b28  vmovaps [rsp+0x90], xmm9
000078d1a57d1b31  vmovaps [rsp+0xA0], xmm10
000078d1a57d1b3a  vmovaps [rsp+0xB0], xmm11
000078d1a57d1b43  vmovaps [rsp+0xC0], xmm12
000078d1a57d1b4c  vmovaps [rsp+0xD0], xmm13
000078d1a57d1b55  vmovaps [rsp+0xE0], xmm15
000078d1a57d1b5e  sub rsp, 0x30
000078d1a57d1b62  movaps [rsp], xmm14
000078d1a57d1b67  movaps [rsp+0x10], xmm13
000078d1a57d1b6d  movaps [rsp+0x20], xmm1
000078d1a57d1b72  lea rdi, [rsp]
000078d1a57d1b76  mov esi, 0x00
000078d1a57d1b7b  mov rax, 0x56EA20A26530
000078d1a57d1b85  call rax
000078d1a57d1b87  movaps xmm14, [rsp]
000078d1a57d1b8c  add rsp, 0x30
000078d1a57d1b90  vmovaps xmm0, [rsp]
000078d1a57d1b95  vmovaps xmm1, [rsp+0x10]
000078d1a57d1b9b  vmovaps xmm2, [rsp+0x20]
000078d1a57d1ba1  vmovaps xmm3, [rsp+0x30]
000078d1a57d1ba7  vmovaps xmm4, [rsp+0x40]
000078d1a57d1bad  vmovaps xmm5, [rsp+0x50]
000078d1a57d1bb3  vmovaps xmm6, [rsp+0x60]
000078d1a57d1bb9  vmovaps xmm7, [rsp+0x70]
000078d1a57d1bbf  vmovaps xmm8, [rsp+0x80]
000078d1a57d1bc8  vmovaps xmm9, [rsp+0x90]
000078d1a57d1bd1  vmovaps xmm10, [rsp+0xA0]
000078d1a57d1bda  vmovaps xmm11, [rsp+0xB0]
000078d1a57d1be3  vmovaps xmm12, [rsp+0xC0]
000078d1a57d1bec  vmovaps xmm13, [rsp+0xD0]
000078d1a57d1bf5  vmovaps xmm15, [rsp+0xE0]
000078d1a57d1bfe  add rsp, 0xF0
000078d1a57d1c05  pop r11
000078d1a57d1c07  pop r10
000078d1a57d1c09  pop r9
000078d1a57d1c0b  pop r8
000078d1a57d1c0d  pop rsi
000078d1a57d1c0e  pop rdi
000078d1a57d1c0f  pop rdx
000078d1a57d1c10  pop rcx
000078d1a57d1c11  pop rax
000078d1a57d1c12  add rsp, 0x08
000078d1a57d1c16  jmp 0x000078D1A57CFAAF
000078d1a57d1c1b  sub rsp, 0x08
000078d1a57d1c1f  push rax
000078d1a57d1c20  push rcx
000078d1a57d1c21  push rdx
000078d1a57d1c22  push rdi
000078d1a57d1c23  push rsi
000078d1a57d1c24  push r8
000078d1a57d1c26  push r9
000078d1a57d1c28  push r10
000078d1a57d1c2a  push r11
000078d1a57d1c2c  sub rsp, 0xF0
000078d1a57d1c33  vmovaps [rsp], xmm0
000078d1a57d1c38  vmovaps [rsp+0x10], xmm1
000078d1a57d1c3e  vmovaps [rsp+0x20], xmm2
000078d1a57d1c44  vmovaps [rsp+0x30], xmm3
000078d1a57d1c4a  vmovaps [rsp+0x40], xmm4
000078d1a57d1c50  vmovaps [rsp+0x50], xmm5
000078d1a57d1c56  vmovaps [rsp+0x60], xmm6
000078d1a57d1c5c  vmovaps [rsp+0x70], xmm7
000078d1a57d1c62  vmovaps [rsp+0x80], xmm8
000078d1a57d1c6b  vmovaps [rsp+0x90], xmm9
000078d1a57d1c74  vmovaps [rsp+0xA0], xmm10
000078d1a57d1c7d  vmovaps [rsp+0xB0], xmm11
000078d1a57d1c86  vmovaps [rsp+0xC0], xmm12
000078d1a57d1c8f  vmovaps [rsp+0xD0], xmm13
000078d1a57d1c98  vmovaps [rsp+0xE0], xmm14
000078d1a57d1ca1  sub rsp, 0x30
000078d1a57d1ca5  movaps [rsp], xmm15
000078d1a57d1caa  movaps [rsp+0x10], xmm13
000078d1a57d1cb0  movaps [rsp+0x20], xmm1
000078d1a57d1cb5  lea rdi, [rsp]
000078d1a57d1cb9  mov esi, 0x00
000078d1a57d1cbe  mov rax, 0x56EA20A26530
000078d1a57d1cc8  call rax
000078d1a57d1cca  movaps xmm15, [rsp]
000078d1a57d1ccf  add rsp, 0x30
000078d1a57d1cd3  vmovaps xmm0, [rsp]
000078d1a57d1cd8  vmovaps xmm1, [rsp+0x10]
000078d1a57d1cde  vmovaps xmm2, [rsp+0x20]
000078d1a57d1ce4  vmovaps xmm3, [rsp+0x30]
000078d1a57d1cea  vmovaps xmm4, [rsp+0x40]
000078d1a57d1cf0  vmovaps xmm5, [rsp+0x50]
000078d1a57d1cf6  vmovaps xmm6, [rsp+0x60]
000078d1a57d1cfc  vmovaps xmm7, [rsp+0x70]
000078d1a57d1d02  vmovaps xmm8, [rsp+0x80]
000078d1a57d1d0b  vmovaps xmm9, [rsp+0x90]
000078d1a57d1d14  vmovaps xmm10, [rsp+0xA0]
000078d1a57d1d1d  vmovaps xmm11, [rsp+0xB0]
000078d1a57d1d26  vmovaps xmm12, [rsp+0xC0]
000078d1a57d1d2f  vmovaps xmm13, [rsp+0xD0]
000078d1a57d1d38  vmovaps xmm14, [rsp+0xE0]
000078d1a57d1d41  add rsp, 0xF0
000078d1a57d1d48  pop r11
000078d1a57d1d4a  pop r10
000078d1a57d1d4c  pop r9
000078d1a57d1d4e  pop r8
000078d1a57d1d50  pop rsi
000078d1a57d1d51  pop rdi
000078d1a57d1d52  pop rdx
000078d1a57d1d53  pop rcx
000078d1a57d1d54  pop rax
000078d1a57d1d55  add rsp, 0x08
000078d1a57d1d59  jmp 0x000078D1A57CFAEB
000078d1a57d1d5e  call 0x000078D1A55FF430
000078d1a57d1d63  jmp 0x000078D1A57CFAF8
000078d1a57d1d68  sub rsp, 0x08
000078d1a57d1d6c  push rax
000078d1a57d1d6d  push rcx
000078d1a57d1d6e  push rdx
000078d1a57d1d6f  push rdi
000078d1a57d1d70  push rsi
000078d1a57d1d71  push r8
000078d1a57d1d73  push r9
000078d1a57d1d75  push r10
000078d1a57d1d77  push r11
000078d1a57d1d79  sub rsp, 0xF0
000078d1a57d1d80  vmovaps [rsp], xmm0
000078d1a57d1d85  vmovaps [rsp+0x10], xmm1
000078d1a57d1d8b  vmovaps [rsp+0x20], xmm2
000078d1a57d1d91  vmovaps [rsp+0x30], xmm3
000078d1a57d1d97  vmovaps [rsp+0x40], xmm4
000078d1a57d1d9d  vmovaps [rsp+0x50], xmm5
000078d1a57d1da3  vmovaps [rsp+0x60], xmm6
000078d1a57d1da9  vmovaps [rsp+0x70], xmm7
000078d1a57d1daf  vmovaps [rsp+0x80], xmm8
000078d1a57d1db8  vmovaps [rsp+0x90], xmm9
000078d1a57d1dc1  vmovaps [rsp+0xA0], xmm10
000078d1a57d1dca  vmovaps [rsp+0xB0], xmm11
000078d1a57d1dd3  vmovaps [rsp+0xC0], xmm12
000078d1a57d1ddc  vmovaps [rsp+0xD0], xmm13
000078d1a57d1de5  vmovaps [rsp+0xE0], xmm15
000078d1a57d1dee  sub rsp, 0x30
000078d1a57d1df2  movaps [rsp], xmm14
000078d1a57d1df7  movaps [rsp+0x10], xmm13
000078d1a57d1dfd  movaps [rsp+0x20], xmm2
000078d1a57d1e02  lea rdi, [rsp]
000078d1a57d1e06  mov esi, 0x00
000078d1a57d1e0b  mov rax, 0x56EA20A26530
000078d1a57d1e15  call rax
000078d1a57d1e17  movaps xmm14, [rsp]
000078d1a57d1e1c  add rsp, 0x30
000078d1a57d1e20  vmovaps xmm0, [rsp]
000078d1a57d1e25  vmovaps xmm1, [rsp+0x10]
000078d1a57d1e2b  vmovaps xmm2, [rsp+0x20]
000078d1a57d1e31  vmovaps xmm3, [rsp+0x30]
000078d1a57d1e37  vmovaps xmm4, [rsp+0x40]
000078d1a57d1e3d  vmovaps xmm5, [rsp+0x50]
000078d1a57d1e43  vmovaps xmm6, [rsp+0x60]
000078d1a57d1e49  vmovaps xmm7, [rsp+0x70]
000078d1a57d1e4f  vmovaps xmm8, [rsp+0x80]
000078d1a57d1e58  vmovaps xmm9, [rsp+0x90]
000078d1a57d1e61  vmovaps xmm10, [rsp+0xA0]
000078d1a57d1e6a  vmovaps xmm11, [rsp+0xB0]
000078d1a57d1e73  vmovaps xmm12, [rsp+0xC0]
000078d1a57d1e7c  vmovaps xmm13, [rsp+0xD0]
000078d1a57d1e85  vmovaps xmm15, [rsp+0xE0]
000078d1a57d1e8e  add rsp, 0xF0
000078d1a57d1e95  pop r11
000078d1a57d1e97  pop r10
000078d1a57d1e99  pop r9
000078d1a57d1e9b  pop r8
000078d1a57d1e9d  pop rsi
000078d1a57d1e9e  pop rdi
000078d1a57d1e9f  pop rdx
000078d1a57d1ea0  pop rcx
000078d1a57d1ea1  pop rax
000078d1a57d1ea2  add rsp, 0x08
000078d1a57d1ea6  jmp 0x000078D1A57CFB24
000078d1a57d1eab  sub rsp, 0x08
000078d1a57d1eaf  push rax
000078d1a57d1eb0  push rcx
000078d1a57d1eb1  push rdx
000078d1a57d1eb2  push rdi
000078d1a57d1eb3  push rsi
000078d1a57d1eb4  push r8
000078d1a57d1eb6  push r9
000078d1a57d1eb8  push r10
000078d1a57d1eba  push r11
000078d1a57d1ebc  sub rsp, 0xF0
000078d1a57d1ec3  vmovaps [rsp], xmm0
000078d1a57d1ec8  vmovaps [rsp+0x10], xmm2
000078d1a57d1ece  vmovaps [rsp+0x20], xmm3
000078d1a57d1ed4  vmovaps [rsp+0x30], xmm4
000078d1a57d1eda  vmovaps [rsp+0x40], xmm5
000078d1a57d1ee0  vmovaps [rsp+0x50], xmm6
000078d1a57d1ee6  vmovaps [rsp+0x60], xmm7
000078d1a57d1eec  vmovaps [rsp+0x70], xmm8
000078d1a57d1ef2  vmovaps [rsp+0x80], xmm9
000078d1a57d1efb  vmovaps [rsp+0x90], xmm10
000078d1a57d1f04  vmovaps [rsp+0xA0], xmm11
000078d1a57d1f0d  vmovaps [rsp+0xB0], xmm12
000078d1a57d1f16  vmovaps [rsp+0xC0], xmm13
000078d1a57d1f1f  vmovaps [rsp+0xD0], xmm14
000078d1a57d1f28  vmovaps [rsp+0xE0], xmm15
000078d1a57d1f31  sub rsp, 0x30
000078d1a57d1f35  movaps [rsp], xmm1
000078d1a57d1f39  movaps [rsp+0x10], xmm13
000078d1a57d1f3f  movaps [rsp+0x20], xmm2
000078d1a57d1f44  lea rdi, [rsp]
000078d1a57d1f48  mov esi, 0x00
000078d1a57d1f4d  mov rax, 0x56EA20A26530
000078d1a57d1f57  call rax
000078d1a57d1f59  movaps xmm1, [rsp]
000078d1a57d1f5d  add rsp, 0x30
000078d1a57d1f61  vmovaps xmm0, [rsp]
000078d1a57d1f66  vmovaps xmm2, [rsp+0x10]
000078d1a57d1f6c  vmovaps xmm3, [rsp+0x20]
000078d1a57d1f72  vmovaps xmm4, [rsp+0x30]
000078d1a57d1f78  vmovaps xmm5, [rsp+0x40]
000078d1a57d1f7e  vmovaps xmm6, [rsp+0x50]
000078d1a57d1f84  vmovaps xmm7, [rsp+0x60]
000078d1a57d1f8a  vmovaps xmm8, [rsp+0x70]
000078d1a57d1f90  vmovaps xmm9, [rsp+0x80]
000078d1a57d1f99  vmovaps xmm10, [rsp+0x90]
000078d1a57d1fa2  vmovaps xmm11, [rsp+0xA0]
000078d1a57d1fab  vmovaps xmm12, [rsp+0xB0]
000078d1a57d1fb4  vmovaps xmm13, [rsp+0xC0]
000078d1a57d1fbd  vmovaps xmm14, [rsp+0xD0]
000078d1a57d1fc6  vmovaps xmm15, [rsp+0xE0]
000078d1a57d1fcf  add rsp, 0xF0
000078d1a57d1fd6  pop r11
000078d1a57d1fd8  pop r10
000078d1a57d1fda  pop r9
000078d1a57d1fdc  pop r8
000078d1a57d1fde  pop rsi
000078d1a57d1fdf  pop rdi
000078d1a57d1fe0  pop rdx
000078d1a57d1fe1  pop rcx
000078d1a57d1fe2  pop rax
000078d1a57d1fe3  add rsp, 0x08
000078d1a57d1fe7  jmp 0x000078D1A57CFB52
000078d1a57d1fec  sub rsp, 0x08
000078d1a57d1ff0  push rax
000078d1a57d1ff1  push rcx
000078d1a57d1ff2  push rdx
000078d1a57d1ff3  push rdi
000078d1a57d1ff4  push rsi
000078d1a57d1ff5  push r8
000078d1a57d1ff7  push r9
000078d1a57d1ff9  push r10
000078d1a57d1ffb  push r11
000078d1a57d1ffd  sub rsp, 0xF0
000078d1a57d2004  vmovaps [rsp], xmm0
000078d1a57d2009  vmovaps [rsp+0x10], xmm1
000078d1a57d200f  vmovaps [rsp+0x20], xmm3
000078d1a57d2015  vmovaps [rsp+0x30], xmm4
000078d1a57d201b  vmovaps [rsp+0x40], xmm5
000078d1a57d2021  vmovaps [rsp+0x50], xmm6
000078d1a57d2027  vmovaps [rsp+0x60], xmm7
000078d1a57d202d  vmovaps [rsp+0x70], xmm8
000078d1a57d2033  vmovaps [rsp+0x80], xmm9
000078d1a57d203c  vmovaps [rsp+0x90], xmm10
000078d1a57d2045  vmovaps [rsp+0xA0], xmm11
000078d1a57d204e  vmovaps [rsp+0xB0], xmm12
000078d1a57d2057  vmovaps [rsp+0xC0], xmm13
000078d1a57d2060  vmovaps [rsp+0xD0], xmm14
000078d1a57d2069  vmovaps [rsp+0xE0], xmm15
000078d1a57d2072  sub rsp, 0x30
000078d1a57d2076  movaps [rsp], xmm2
000078d1a57d207a  movaps [rsp+0x10], xmm1
000078d1a57d207f  movaps [rsp+0x20], xmm13
000078d1a57d2085  lea rdi, [rsp]
000078d1a57d2089  mov esi, 0x00
000078d1a57d208e  mov rax, 0x56EA20A26530
000078d1a57d2098  call rax
000078d1a57d209a  movaps xmm2, [rsp]
000078d1a57d209e  add rsp, 0x30
000078d1a57d20a2  vmovaps xmm0, [rsp]
000078d1a57d20a7  vmovaps xmm1, [rsp+0x10]
000078d1a57d20ad  vmovaps xmm3, [rsp+0x20]
000078d1a57d20b3  vmovaps xmm4, [rsp+0x30]
000078d1a57d20b9  vmovaps xmm5, [rsp+0x40]
000078d1a57d20bf  vmovaps xmm6, [rsp+0x50]
000078d1a57d20c5  vmovaps xmm7, [rsp+0x60]
000078d1a57d20cb  vmovaps xmm8, [rsp+0x70]
000078d1a57d20d1  vmovaps xmm9, [rsp+0x80]
000078d1a57d20da  vmovaps xmm10, [rsp+0x90]
000078d1a57d20e3  vmovaps xmm11, [rsp+0xA0]
000078d1a57d20ec  vmovaps xmm12, [rsp+0xB0]
000078d1a57d20f5  vmovaps xmm13, [rsp+0xC0]
000078d1a57d20fe  vmovaps xmm14, [rsp+0xD0]
000078d1a57d2107  vmovaps xmm15, [rsp+0xE0]
000078d1a57d2110  add rsp, 0xF0
000078d1a57d2117  pop r11
000078d1a57d2119  pop r10
000078d1a57d211b  pop r9
000078d1a57d211d  pop r8
000078d1a57d211f  pop rsi
000078d1a57d2120  pop rdi
000078d1a57d2121  pop rdx
000078d1a57d2122  pop rcx
000078d1a57d2123  pop rax
000078d1a57d2124  add rsp, 0x08
000078d1a57d2128  jmp 0x000078D1A57CFBAB
000078d1a57d212d  call 0x000078D1A55FF430
000078d1a57d2132  jmp 0x000078D1A57CFBB8
000078d1a57d2137  sub rsp, 0x08
000078d1a57d213b  push rax
000078d1a57d213c  push rcx
000078d1a57d213d  push rdx
000078d1a57d213e  push rdi
000078d1a57d213f  push rsi
000078d1a57d2140  push r8
000078d1a57d2142  push r9
000078d1a57d2144  push r10
000078d1a57d2146  push r11
000078d1a57d2148  sub rsp, 0xF0
000078d1a57d214f  vmovaps [rsp], xmm0
000078d1a57d2154  vmovaps [rsp+0x10], xmm1
000078d1a57d215a  vmovaps [rsp+0x20], xmm2
000078d1a57d2160  vmovaps [rsp+0x30], xmm3
000078d1a57d2166  vmovaps [rsp+0x40], xmm4
000078d1a57d216c  vmovaps [rsp+0x50], xmm5
000078d1a57d2172  vmovaps [rsp+0x60], xmm6
000078d1a57d2178  vmovaps [rsp+0x70], xmm7
000078d1a57d217e  vmovaps [rsp+0x80], xmm8
000078d1a57d2187  vmovaps [rsp+0x90], xmm9
000078d1a57d2190  vmovaps [rsp+0xA0], xmm10
000078d1a57d2199  vmovaps [rsp+0xB0], xmm11
000078d1a57d21a2  vmovaps [rsp+0xC0], xmm12
000078d1a57d21ab  vmovaps [rsp+0xD0], xmm13
000078d1a57d21b4  vmovaps [rsp+0xE0], xmm14
000078d1a57d21bd  sub rsp, 0x30
000078d1a57d21c1  movaps [rsp], xmm15
000078d1a57d21c6  movaps [rsp+0x10], xmm13
000078d1a57d21cc  movaps [rsp+0x20], xmm1
000078d1a57d21d1  lea rdi, [rsp]
000078d1a57d21d5  mov esi, 0x00
000078d1a57d21da  mov rax, 0x56EA20A26530
000078d1a57d21e4  call rax
000078d1a57d21e6  movaps xmm15, [rsp]
000078d1a57d21eb  add rsp, 0x30
000078d1a57d21ef  vmovaps xmm0, [rsp]
000078d1a57d21f4  vmovaps xmm1, [rsp+0x10]
000078d1a57d21fa  vmovaps xmm2, [rsp+0x20]
000078d1a57d2200  vmovaps xmm3, [rsp+0x30]
000078d1a57d2206  vmovaps xmm4, [rsp+0x40]
000078d1a57d220c  vmovaps xmm5, [rsp+0x50]
000078d1a57d2212  vmovaps xmm6, [rsp+0x60]
000078d1a57d2218  vmovaps xmm7, [rsp+0x70]
000078d1a57d221e  vmovaps xmm8, [rsp+0x80]
000078d1a57d2227  vmovaps xmm9, [rsp+0x90]
000078d1a57d2230  vmovaps xmm10, [rsp+0xA0]
000078d1a57d2239  vmovaps xmm11, [rsp+0xB0]
000078d1a57d2242  vmovaps xmm12, [rsp+0xC0]
000078d1a57d224b  vmovaps xmm13, [rsp+0xD0]
000078d1a57d2254  vmovaps xmm14, [rsp+0xE0]
000078d1a57d225d  add rsp, 0xF0
000078d1a57d2264  pop r11
000078d1a57d2266  pop r10
000078d1a57d2268  pop r9
000078d1a57d226a  pop r8
000078d1a57d226c  pop rsi
000078d1a57d226d  pop rdi
000078d1a57d226e  pop rdx
000078d1a57d226f  pop rcx
000078d1a57d2270  pop rax
000078d1a57d2271  add rsp, 0x08
000078d1a57d2275  jmp 0x000078D1A57CFBF7
000078d1a57d227a  sub rsp, 0x08
000078d1a57d227e  push rax
000078d1a57d227f  push rcx
000078d1a57d2280  push rdx
000078d1a57d2281  push rdi
000078d1a57d2282  push rsi
000078d1a57d2283  push r8
000078d1a57d2285  push r9
000078d1a57d2287  push r10
000078d1a57d2289  push r11
000078d1a57d228b  sub rsp, 0xF0
000078d1a57d2292  vmovaps [rsp], xmm0
000078d1a57d2297  vmovaps [rsp+0x10], xmm1
000078d1a57d229d  vmovaps [rsp+0x20], xmm2
000078d1a57d22a3  vmovaps [rsp+0x30], xmm3
000078d1a57d22a9  vmovaps [rsp+0x40], xmm4
000078d1a57d22af  vmovaps [rsp+0x50], xmm5
000078d1a57d22b5  vmovaps [rsp+0x60], xmm6
000078d1a57d22bb  vmovaps [rsp+0x70], xmm7
000078d1a57d22c1  vmovaps [rsp+0x80], xmm8
000078d1a57d22ca  vmovaps [rsp+0x90], xmm9
000078d1a57d22d3  vmovaps [rsp+0xA0], xmm10
000078d1a57d22dc  vmovaps [rsp+0xB0], xmm11
000078d1a57d22e5  vmovaps [rsp+0xC0], xmm12
000078d1a57d22ee  vmovaps [rsp+0xD0], xmm13
000078d1a57d22f7  vmovaps [rsp+0xE0], xmm15
000078d1a57d2300  sub rsp, 0x30
000078d1a57d2304  movaps [rsp], xmm14
000078d1a57d2309  movaps [rsp+0x10], xmm11
000078d1a57d230f  movaps [rsp+0x20], xmm1
000078d1a57d2314  lea rdi, [rsp]
000078d1a57d2318  mov esi, 0x00
000078d1a57d231d  mov rax, 0x56EA20A26530
000078d1a57d2327  call rax
000078d1a57d2329  movaps xmm14, [rsp]
000078d1a57d232e  add rsp, 0x30
000078d1a57d2332  vmovaps xmm0, [rsp]
000078d1a57d2337  vmovaps xmm1, [rsp+0x10]
000078d1a57d233d  vmovaps xmm2, [rsp+0x20]
000078d1a57d2343  vmovaps xmm3, [rsp+0x30]
000078d1a57d2349  vmovaps xmm4, [rsp+0x40]
000078d1a57d234f  vmovaps xmm5, [rsp+0x50]
000078d1a57d2355  vmovaps xmm6, [rsp+0x60]
000078d1a57d235b  vmovaps xmm7, [rsp+0x70]
000078d1a57d2361  vmovaps xmm8, [rsp+0x80]
000078d1a57d236a  vmovaps xmm9, [rsp+0x90]
000078d1a57d2373  vmovaps xmm10, [rsp+0xA0]
000078d1a57d237c  vmovaps xmm11, [rsp+0xB0]
000078d1a57d2385  vmovaps xmm12, [rsp+0xC0]
000078d1a57d238e  vmovaps xmm13, [rsp+0xD0]
000078d1a57d2397  vmovaps xmm15, [rsp+0xE0]
000078d1a57d23a0  add rsp, 0xF0
000078d1a57d23a7  pop r11
000078d1a57d23a9  pop r10
000078d1a57d23ab  pop r9
000078d1a57d23ad  pop r8
000078d1a57d23af  pop rsi
000078d1a57d23b0  pop rdi
000078d1a57d23b1  pop rdx
000078d1a57d23b2  pop rcx
000078d1a57d23b3  pop rax
000078d1a57d23b4  add rsp, 0x08
000078d1a57d23b8  jmp 0x000078D1A57CFC21
000078d1a57d23bd  sub rsp, 0x08
000078d1a57d23c1  push rax
000078d1a57d23c2  push rcx
000078d1a57d23c3  push rdx
000078d1a57d23c4  push rdi
000078d1a57d23c5  push rsi
000078d1a57d23c6  push r8
000078d1a57d23c8  push r9
000078d1a57d23ca  push r10
000078d1a57d23cc  push r11
000078d1a57d23ce  sub rsp, 0xF0
000078d1a57d23d5  vmovaps [rsp], xmm0
000078d1a57d23da  vmovaps [rsp+0x10], xmm1
000078d1a57d23e0  vmovaps [rsp+0x20], xmm2
000078d1a57d23e6  vmovaps [rsp+0x30], xmm3
000078d1a57d23ec  vmovaps [rsp+0x40], xmm4
000078d1a57d23f2  vmovaps [rsp+0x50], xmm5
000078d1a57d23f8  vmovaps [rsp+0x60], xmm6
000078d1a57d23fe  vmovaps [rsp+0x70], xmm7
000078d1a57d2404  vmovaps [rsp+0x80], xmm8
000078d1a57d240d  vmovaps [rsp+0x90], xmm9
000078d1a57d2416  vmovaps [rsp+0xA0], xmm10
000078d1a57d241f  vmovaps [rsp+0xB0], xmm11
000078d1a57d2428  vmovaps [rsp+0xC0], xmm12
000078d1a57d2431  vmovaps [rsp+0xD0], xmm14
000078d1a57d243a  vmovaps [rsp+0xE0], xmm15
000078d1a57d2443  sub rsp, 0x30
000078d1a57d2447  movaps [rsp], xmm13
000078d1a57d244c  movaps [rsp+0x10], xmm11
000078d1a57d2452  movaps [rsp+0x20], xmm1
000078d1a57d2457  lea rdi, [rsp]
000078d1a57d245b  mov esi, 0x00
000078d1a57d2460  mov rax, 0x56EA20A26530
000078d1a57d246a  call rax
000078d1a57d246c  movaps xmm13, [rsp]
000078d1a57d2471  add rsp, 0x30
000078d1a57d2475  vmovaps xmm0, [rsp]
000078d1a57d247a  vmovaps xmm1, [rsp+0x10]
000078d1a57d2480  vmovaps xmm2, [rsp+0x20]
000078d1a57d2486  vmovaps xmm3, [rsp+0x30]
000078d1a57d248c  vmovaps xmm4, [rsp+0x40]
000078d1a57d2492  vmovaps xmm5, [rsp+0x50]
000078d1a57d2498  vmovaps xmm6, [rsp+0x60]
000078d1a57d249e  vmovaps xmm7, [rsp+0x70]
000078d1a57d24a4  vmovaps xmm8, [rsp+0x80]
000078d1a57d24ad  vmovaps xmm9, [rsp+0x90]
000078d1a57d24b6  vmovaps xmm10, [rsp+0xA0]
000078d1a57d24bf  vmovaps xmm11, [rsp+0xB0]
000078d1a57d24c8  vmovaps xmm12, [rsp+0xC0]
000078d1a57d24d1  vmovaps xmm14, [rsp+0xD0]
000078d1a57d24da  vmovaps xmm15, [rsp+0xE0]
000078d1a57d24e3  add rsp, 0xF0
000078d1a57d24ea  pop r11
000078d1a57d24ec  pop r10
000078d1a57d24ee  pop r9
000078d1a57d24f0  pop r8
000078d1a57d24f2  pop rsi
000078d1a57d24f3  pop rdi
000078d1a57d24f4  pop rdx
000078d1a57d24f5  pop rcx
000078d1a57d24f6  pop rax
000078d1a57d24f7  add rsp, 0x08
000078d1a57d24fb  jmp 0x000078D1A57CFC76
000078d1a57d2500  call 0x000078D1A55FF430
000078d1a57d2505  jmp 0x000078D1A57CFC83
000078d1a57d250a  sub rsp, 0x08
000078d1a57d250e  push rax
000078d1a57d250f  push rcx
000078d1a57d2510  push rdx
000078d1a57d2511  push rdi
000078d1a57d2512  push rsi
000078d1a57d2513  push r8
000078d1a57d2515  push r9
000078d1a57d2517  push r10
000078d1a57d2519  push r11
000078d1a57d251b  sub rsp, 0xF0
000078d1a57d2522  vmovaps [rsp], xmm0
000078d1a57d2527  vmovaps [rsp+0x10], xmm1
000078d1a57d252d  vmovaps [rsp+0x20], xmm2
000078d1a57d2533  vmovaps [rsp+0x30], xmm3
000078d1a57d2539  vmovaps [rsp+0x40], xmm4
000078d1a57d253f  vmovaps [rsp+0x50], xmm5
000078d1a57d2545  vmovaps [rsp+0x60], xmm6
000078d1a57d254b  vmovaps [rsp+0x70], xmm7
000078d1a57d2551  vmovaps [rsp+0x80], xmm8
000078d1a57d255a  vmovaps [rsp+0x90], xmm9
000078d1a57d2563  vmovaps [rsp+0xA0], xmm10
000078d1a57d256c  vmovaps [rsp+0xB0], xmm11
000078d1a57d2575  vmovaps [rsp+0xC0], xmm12
000078d1a57d257e  vmovaps [rsp+0xD0], xmm13
000078d1a57d2587  vmovaps [rsp+0xE0], xmm14
000078d1a57d2590  sub rsp, 0x30
000078d1a57d2594  movaps [rsp], xmm15
000078d1a57d2599  movaps [rsp+0x10], xmm11
000078d1a57d259f  movaps [rsp+0x20], xmm1
000078d1a57d25a4  lea rdi, [rsp]
000078d1a57d25a8  mov esi, 0x00
000078d1a57d25ad  mov rax, 0x56EA20A26530
000078d1a57d25b7  call rax
000078d1a57d25b9  movaps xmm15, [rsp]
000078d1a57d25be  add rsp, 0x30
000078d1a57d25c2  vmovaps xmm0, [rsp]
000078d1a57d25c7  vmovaps xmm1, [rsp+0x10]
000078d1a57d25cd  vmovaps xmm2, [rsp+0x20]
000078d1a57d25d3  vmovaps xmm3, [rsp+0x30]
000078d1a57d25d9  vmovaps xmm4, [rsp+0x40]
000078d1a57d25df  vmovaps xmm5, [rsp+0x50]
000078d1a57d25e5  vmovaps xmm6, [rsp+0x60]
000078d1a57d25eb  vmovaps xmm7, [rsp+0x70]
000078d1a57d25f1  vmovaps xmm8, [rsp+0x80]
000078d1a57d25fa  vmovaps xmm9, [rsp+0x90]
000078d1a57d2603  vmovaps xmm10, [rsp+0xA0]
000078d1a57d260c  vmovaps xmm11, [rsp+0xB0]
000078d1a57d2615  vmovaps xmm12, [rsp+0xC0]
000078d1a57d261e  vmovaps xmm13, [rsp+0xD0]
000078d1a57d2627  vmovaps xmm14, [rsp+0xE0]
000078d1a57d2630  add rsp, 0xF0
000078d1a57d2637  pop r11
000078d1a57d2639  pop r10
000078d1a57d263b  pop r9
000078d1a57d263d  pop r8
000078d1a57d263f  pop rsi
000078d1a57d2640  pop rdi
000078d1a57d2641  pop rdx
000078d1a57d2642  pop rcx
000078d1a57d2643  pop rax
000078d1a57d2644  add rsp, 0x08
000078d1a57d2648  jmp 0x000078D1A57CFCBC
000078d1a57d264d  sub rsp, 0x08
000078d1a57d2651  push rax
000078d1a57d2652  push rcx
000078d1a57d2653  push rdx
000078d1a57d2654  push rdi
000078d1a57d2655  push rsi
000078d1a57d2656  push r8
000078d1a57d2658  push r9
000078d1a57d265a  push r10
000078d1a57d265c  push r11
000078d1a57d265e  sub rsp, 0xF0
000078d1a57d2665  vmovaps [rsp], xmm0
000078d1a57d266a  vmovaps [rsp+0x10], xmm1
000078d1a57d2670  vmovaps [rsp+0x20], xmm2
000078d1a57d2676  vmovaps [rsp+0x30], xmm3
000078d1a57d267c  vmovaps [rsp+0x40], xmm4
000078d1a57d2682  vmovaps [rsp+0x50], xmm5
000078d1a57d2688  vmovaps [rsp+0x60], xmm6
000078d1a57d268e  vmovaps [rsp+0x70], xmm7
000078d1a57d2694  vmovaps [rsp+0x80], xmm8
000078d1a57d269d  vmovaps [rsp+0x90], xmm9
000078d1a57d26a6  vmovaps [rsp+0xA0], xmm10
000078d1a57d26af  vmovaps [rsp+0xB0], xmm12
000078d1a57d26b8  vmovaps [rsp+0xC0], xmm13
000078d1a57d26c1  vmovaps [rsp+0xD0], xmm14
000078d1a57d26ca  vmovaps [rsp+0xE0], xmm15
000078d1a57d26d3  sub rsp, 0x30
000078d1a57d26d7  movaps [rsp], xmm11
000078d1a57d26dc  movaps [rsp+0x10], xmm6
000078d1a57d26e1  movaps [rsp+0x20], xmm14
000078d1a57d26e7  lea rdi, [rsp]
000078d1a57d26eb  mov esi, 0x00
000078d1a57d26f0  mov rax, 0x56EA20A26530
000078d1a57d26fa  call rax
000078d1a57d26fc  movaps xmm11, [rsp]
000078d1a57d2701  add rsp, 0x30
000078d1a57d2705  vmovaps xmm0, [rsp]
000078d1a57d270a  vmovaps xmm1, [rsp+0x10]
000078d1a57d2710  vmovaps xmm2, [rsp+0x20]
000078d1a57d2716  vmovaps xmm3, [rsp+0x30]
000078d1a57d271c  vmovaps xmm4, [rsp+0x40]
000078d1a57d2722  vmovaps xmm5, [rsp+0x50]
000078d1a57d2728  vmovaps xmm6, [rsp+0x60]
000078d1a57d272e  vmovaps xmm7, [rsp+0x70]
000078d1a57d2734  vmovaps xmm8, [rsp+0x80]
000078d1a57d273d  vmovaps xmm9, [rsp+0x90]
000078d1a57d2746  vmovaps xmm10, [rsp+0xA0]
000078d1a57d274f  vmovaps xmm12, [rsp+0xB0]
000078d1a57d2758  vmovaps xmm13, [rsp+0xC0]
000078d1a57d2761  vmovaps xmm14, [rsp+0xD0]
000078d1a57d276a  vmovaps xmm15, [rsp+0xE0]
000078d1a57d2773  add rsp, 0xF0
000078d1a57d277a  pop r11
000078d1a57d277c  pop r10
000078d1a57d277e  pop r9
000078d1a57d2780  pop r8
000078d1a57d2782  pop rsi
000078d1a57d2783  pop rdi
000078d1a57d2784  pop rdx
000078d1a57d2785  pop rcx
000078d1a57d2786  pop rax
000078d1a57d2787  add rsp, 0x08
000078d1a57d278b  jmp 0x000078D1A57CFD34
000078d1a57d2790  call 0x000078D1A55FF430
000078d1a57d2795  jmp 0x000078D1A57CFD3E
000078d1a57d279a  sub rsp, 0x08
000078d1a57d279e  push rax
000078d1a57d279f  push rcx
000078d1a57d27a0  push rdx
000078d1a57d27a1  push rdi
000078d1a57d27a2  push rsi
000078d1a57d27a3  push r8
000078d1a57d27a5  push r9
000078d1a57d27a7  push r10
000078d1a57d27a9  push r11
000078d1a57d27ab  sub rsp, 0xF0
000078d1a57d27b2  vmovaps [rsp], xmm0
000078d1a57d27b7  vmovaps [rsp+0x10], xmm1
000078d1a57d27bd  vmovaps [rsp+0x20], xmm2
000078d1a57d27c3  vmovaps [rsp+0x30], xmm3
000078d1a57d27c9  vmovaps [rsp+0x40], xmm4
000078d1a57d27cf  vmovaps [rsp+0x50], xmm5
000078d1a57d27d5  vmovaps [rsp+0x60], xmm6
000078d1a57d27db  vmovaps [rsp+0x70], xmm7
000078d1a57d27e1  vmovaps [rsp+0x80], xmm8
000078d1a57d27ea  vmovaps [rsp+0x90], xmm9
000078d1a57d27f3  vmovaps [rsp+0xA0], xmm10
000078d1a57d27fc  vmovaps [rsp+0xB0], xmm11
000078d1a57d2805  vmovaps [rsp+0xC0], xmm12
000078d1a57d280e  vmovaps [rsp+0xD0], xmm13
000078d1a57d2817  vmovaps [rsp+0xE0], xmm15
000078d1a57d2820  sub rsp, 0x30
000078d1a57d2824  movaps [rsp], xmm14
000078d1a57d2829  movaps [rsp+0x10], xmm6
000078d1a57d282e  movaps [rsp+0x20], xmm2
000078d1a57d2833  lea rdi, [rsp]
000078d1a57d2837  mov esi, 0x00
000078d1a57d283c  mov rax, 0x56EA20A26530
000078d1a57d2846  call rax
000078d1a57d2848  movaps xmm14, [rsp]
000078d1a57d284d  add rsp, 0x30
000078d1a57d2851  vmovaps xmm0, [rsp]
000078d1a57d2856  vmovaps xmm1, [rsp+0x10]
000078d1a57d285c  vmovaps xmm2, [rsp+0x20]
000078d1a57d2862  vmovaps xmm3, [rsp+0x30]
000078d1a57d2868  vmovaps xmm4, [rsp+0x40]
000078d1a57d286e  vmovaps xmm5, [rsp+0x50]
000078d1a57d2874  vmovaps xmm6, [rsp+0x60]
000078d1a57d287a  vmovaps xmm7, [rsp+0x70]
000078d1a57d2880  vmovaps xmm8, [rsp+0x80]
000078d1a57d2889  vmovaps xmm9, [rsp+0x90]
000078d1a57d2892  vmovaps xmm10, [rsp+0xA0]
000078d1a57d289b  vmovaps xmm11, [rsp+0xB0]
000078d1a57d28a4  vmovaps xmm12, [rsp+0xC0]
000078d1a57d28ad  vmovaps xmm13, [rsp+0xD0]
000078d1a57d28b6  vmovaps xmm15, [rsp+0xE0]
000078d1a57d28bf  add rsp, 0xF0
000078d1a57d28c6  pop r11
000078d1a57d28c8  pop r10
000078d1a57d28ca  pop r9
000078d1a57d28cc  pop r8
000078d1a57d28ce  pop rsi
000078d1a57d28cf  pop rdi
000078d1a57d28d0  pop rdx
000078d1a57d28d1  pop rcx
000078d1a57d28d2  pop rax
000078d1a57d28d3  add rsp, 0x08
000078d1a57d28d7  jmp 0x000078D1A57CFD72
000078d1a57d28dc  sub rsp, 0x08
000078d1a57d28e0  push rax
000078d1a57d28e1  push rcx
000078d1a57d28e2  push rdx
000078d1a57d28e3  push rdi
000078d1a57d28e4  push rsi
000078d1a57d28e5  push r8
000078d1a57d28e7  push r9
000078d1a57d28e9  push r10
000078d1a57d28eb  push r11
000078d1a57d28ed  sub rsp, 0xF0
000078d1a57d28f4  vmovaps [rsp], xmm0
000078d1a57d28f9  vmovaps [rsp+0x10], xmm1
000078d1a57d28ff  vmovaps [rsp+0x20], xmm2
000078d1a57d2905  vmovaps [rsp+0x30], xmm3
000078d1a57d290b  vmovaps [rsp+0x40], xmm4
000078d1a57d2911  vmovaps [rsp+0x50], xmm5
000078d1a57d2917  vmovaps [rsp+0x60], xmm7
000078d1a57d291d  vmovaps [rsp+0x70], xmm8
000078d1a57d2923  vmovaps [rsp+0x80], xmm9
000078d1a57d292c  vmovaps [rsp+0x90], xmm10
000078d1a57d2935  vmovaps [rsp+0xA0], xmm11
000078d1a57d293e  vmovaps [rsp+0xB0], xmm12
000078d1a57d2947  vmovaps [rsp+0xC0], xmm13
000078d1a57d2950  vmovaps [rsp+0xD0], xmm14
000078d1a57d2959  vmovaps [rsp+0xE0], xmm15
000078d1a57d2962  sub rsp, 0x30
000078d1a57d2966  movaps [rsp], xmm6
000078d1a57d296a  movaps [rsp+0x10], xmm5
000078d1a57d296f  movaps [rsp+0x20], xmm1
000078d1a57d2974  lea rdi, [rsp]
000078d1a57d2978  mov esi, 0x00
000078d1a57d297d  mov rax, 0x56EA20A26530
000078d1a57d2987  call rax
000078d1a57d2989  movaps xmm6, [rsp]
000078d1a57d298d  add rsp, 0x30
000078d1a57d2991  vmovaps xmm0, [rsp]
000078d1a57d2996  vmovaps xmm1, [rsp+0x10]
000078d1a57d299c  vmovaps xmm2, [rsp+0x20]
000078d1a57d29a2  vmovaps xmm3, [rsp+0x30]
000078d1a57d29a8  vmovaps xmm4, [rsp+0x40]
000078d1a57d29ae  vmovaps xmm5, [rsp+0x50]
000078d1a57d29b4  vmovaps xmm7, [rsp+0x60]
000078d1a57d29ba  vmovaps xmm8, [rsp+0x70]
000078d1a57d29c0  vmovaps xmm9, [rsp+0x80]
000078d1a57d29c9  vmovaps xmm10, [rsp+0x90]
000078d1a57d29d2  vmovaps xmm11, [rsp+0xA0]
000078d1a57d29db  vmovaps xmm12, [rsp+0xB0]
000078d1a57d29e4  vmovaps xmm13, [rsp+0xC0]
000078d1a57d29ed  vmovaps xmm14, [rsp+0xD0]
000078d1a57d29f6  vmovaps xmm15, [rsp+0xE0]
000078d1a57d29ff  add rsp, 0xF0
000078d1a57d2a06  pop r11
000078d1a57d2a08  pop r10
000078d1a57d2a0a  pop r9
000078d1a57d2a0c  pop r8
000078d1a57d2a0e  pop rsi
000078d1a57d2a0f  pop rdi
000078d1a57d2a10  pop rdx
000078d1a57d2a11  pop rcx
000078d1a57d2a12  pop rax
000078d1a57d2a13  add rsp, 0x08
000078d1a57d2a17  jmp 0x000078D1A57CFD98
000078d1a57d2a1c  sub rsp, 0x08
000078d1a57d2a20  push rax
000078d1a57d2a21  push rcx
000078d1a57d2a22  push rdx
000078d1a57d2a23  push rdi
000078d1a57d2a24  push rsi
000078d1a57d2a25  push r8
000078d1a57d2a27  push r9
000078d1a57d2a29  push r10
000078d1a57d2a2b  push r11
000078d1a57d2a2d  sub rsp, 0xF0
000078d1a57d2a34  vmovaps [rsp], xmm0
000078d1a57d2a39  vmovaps [rsp+0x10], xmm2
000078d1a57d2a3f  vmovaps [rsp+0x20], xmm3
000078d1a57d2a45  vmovaps [rsp+0x30], xmm4
000078d1a57d2a4b  vmovaps [rsp+0x40], xmm5
000078d1a57d2a51  vmovaps [rsp+0x50], xmm6
000078d1a57d2a57  vmovaps [rsp+0x60], xmm7
000078d1a57d2a5d  vmovaps [rsp+0x70], xmm8
000078d1a57d2a63  vmovaps [rsp+0x80], xmm9
000078d1a57d2a6c  vmovaps [rsp+0x90], xmm10
000078d1a57d2a75  vmovaps [rsp+0xA0], xmm11
000078d1a57d2a7e  vmovaps [rsp+0xB0], xmm12
000078d1a57d2a87  vmovaps [rsp+0xC0], xmm13
000078d1a57d2a90  vmovaps [rsp+0xD0], xmm14
000078d1a57d2a99  vmovaps [rsp+0xE0], xmm15
000078d1a57d2aa2  sub rsp, 0x30
000078d1a57d2aa6  movaps [rsp], xmm1
000078d1a57d2aaa  movaps [rsp+0x10], xmm5
000078d1a57d2aaf  movaps [rsp+0x20], xmm13
000078d1a57d2ab5  lea rdi, [rsp]
000078d1a57d2ab9  mov esi, 0x00
000078d1a57d2abe  mov rax, 0x56EA20A26530
000078d1a57d2ac8  call rax
000078d1a57d2aca  movaps xmm1, [rsp]
000078d1a57d2ace  add rsp, 0x30
000078d1a57d2ad2  vmovaps xmm0, [rsp]
000078d1a57d2ad7  vmovaps xmm2, [rsp+0x10]
000078d1a57d2add  vmovaps xmm3, [rsp+0x20]
000078d1a57d2ae3  vmovaps xmm4, [rsp+0x30]
000078d1a57d2ae9  vmovaps xmm5, [rsp+0x40]
000078d1a57d2aef  vmovaps xmm6, [rsp+0x50]
000078d1a57d2af5  vmovaps xmm7, [rsp+0x60]
000078d1a57d2afb  vmovaps xmm8, [rsp+0x70]
000078d1a57d2b01  vmovaps xmm9, [rsp+0x80]
000078d1a57d2b0a  vmovaps xmm10, [rsp+0x90]
000078d1a57d2b13  vmovaps xmm11, [rsp+0xA0]
000078d1a57d2b1c  vmovaps xmm12, [rsp+0xB0]
000078d1a57d2b25  vmovaps xmm13, [rsp+0xC0]
000078d1a57d2b2e  vmovaps xmm14, [rsp+0xD0]
000078d1a57d2b37  vmovaps xmm15, [rsp+0xE0]
000078d1a57d2b40  add rsp, 0xF0
000078d1a57d2b47  pop r11
000078d1a57d2b49  pop r10
000078d1a57d2b4b  pop r9
000078d1a57d2b4d  pop r8
000078d1a57d2b4f  pop rsi
000078d1a57d2b50  pop rdi
000078d1a57d2b51  pop rdx
000078d1a57d2b52  pop rcx
000078d1a57d2b53  pop rax
000078d1a57d2b54  add rsp, 0x08
000078d1a57d2b58  jmp 0x000078D1A57CFDB6
000078d1a57d2b5d  sub rsp, 0x08
000078d1a57d2b61  push rax
000078d1a57d2b62  push rcx
000078d1a57d2b63  push rdx
000078d1a57d2b64  push rdi
000078d1a57d2b65  push rsi
000078d1a57d2b66  push r8
000078d1a57d2b68  push r9
000078d1a57d2b6a  push r10
000078d1a57d2b6c  push r11
000078d1a57d2b6e  sub rsp, 0xF0
000078d1a57d2b75  vmovaps [rsp], xmm0
000078d1a57d2b7a  vmovaps [rsp+0x10], xmm1
000078d1a57d2b80  vmovaps [rsp+0x20], xmm2
000078d1a57d2b86  vmovaps [rsp+0x30], xmm3
000078d1a57d2b8c  vmovaps [rsp+0x40], xmm4
000078d1a57d2b92  vmovaps [rsp+0x50], xmm6
000078d1a57d2b98  vmovaps [rsp+0x60], xmm7
000078d1a57d2b9e  vmovaps [rsp+0x70], xmm8
000078d1a57d2ba4  vmovaps [rsp+0x80], xmm9
000078d1a57d2bad  vmovaps [rsp+0x90], xmm10
000078d1a57d2bb6  vmovaps [rsp+0xA0], xmm11
000078d1a57d2bbf  vmovaps [rsp+0xB0], xmm12
000078d1a57d2bc8  vmovaps [rsp+0xC0], xmm13
000078d1a57d2bd1  vmovaps [rsp+0xD0], xmm14
000078d1a57d2bda  vmovaps [rsp+0xE0], xmm15
000078d1a57d2be3  sub rsp, 0x30
000078d1a57d2be7  movaps [rsp], xmm5
000078d1a57d2beb  movaps [rsp+0x10], xmm2
000078d1a57d2bf0  movaps [rsp+0x20], xmm13
000078d1a57d2bf6  lea rdi, [rsp]
000078d1a57d2bfa  mov esi, 0x00
000078d1a57d2bff  mov rax, 0x56EA20A26530
000078d1a57d2c09  call rax
000078d1a57d2c0b  movaps xmm5, [rsp]
000078d1a57d2c0f  add rsp, 0x30
000078d1a57d2c13  vmovaps xmm0, [rsp]
000078d1a57d2c18  vmovaps xmm1, [rsp+0x10]
000078d1a57d2c1e  vmovaps xmm2, [rsp+0x20]
000078d1a57d2c24  vmovaps xmm3, [rsp+0x30]
000078d1a57d2c2a  vmovaps xmm4, [rsp+0x40]
000078d1a57d2c30  vmovaps xmm6, [rsp+0x50]
000078d1a57d2c36  vmovaps xmm7, [rsp+0x60]
000078d1a57d2c3c  vmovaps xmm8, [rsp+0x70]
000078d1a57d2c42  vmovaps xmm9, [rsp+0x80]
000078d1a57d2c4b  vmovaps xmm10, [rsp+0x90]
000078d1a57d2c54  vmovaps xmm11, [rsp+0xA0]
000078d1a57d2c5d  vmovaps xmm12, [rsp+0xB0]
000078d1a57d2c66  vmovaps xmm13, [rsp+0xC0]
000078d1a57d2c6f  vmovaps xmm14, [rsp+0xD0]
000078d1a57d2c78  vmovaps xmm15, [rsp+0xE0]
000078d1a57d2c81  add rsp, 0xF0
000078d1a57d2c88  pop r11
000078d1a57d2c8a  pop r10
000078d1a57d2c8c  pop r9
000078d1a57d2c8e  pop r8
000078d1a57d2c90  pop rsi
000078d1a57d2c91  pop rdi
000078d1a57d2c92  pop rdx
000078d1a57d2c93  pop rcx
000078d1a57d2c94  pop rax
000078d1a57d2c95  add rsp, 0x08
000078d1a57d2c99  jmp 0x000078D1A57CFDEC
000078d1a57d2c9e  sub rsp, 0x08
000078d1a57d2ca2  push rax
000078d1a57d2ca3  push rcx
000078d1a57d2ca4  push rdx
000078d1a57d2ca5  push rdi
000078d1a57d2ca6  push rsi
000078d1a57d2ca7  push r8
000078d1a57d2ca9  push r9
000078d1a57d2cab  push r10
000078d1a57d2cad  push r11
000078d1a57d2caf  sub rsp, 0xF0
000078d1a57d2cb6  vmovaps [rsp], xmm0
000078d1a57d2cbb  vmovaps [rsp+0x10], xmm1
000078d1a57d2cc1  vmovaps [rsp+0x20], xmm2
000078d1a57d2cc7  vmovaps [rsp+0x30], xmm3
000078d1a57d2ccd  vmovaps [rsp+0x40], xmm4
000078d1a57d2cd3  vmovaps [rsp+0x50], xmm5
000078d1a57d2cd9  vmovaps [rsp+0x60], xmm6
000078d1a57d2cdf  vmovaps [rsp+0x70], xmm7
000078d1a57d2ce5  vmovaps [rsp+0x80], xmm8
000078d1a57d2cee  vmovaps [rsp+0x90], xmm9
000078d1a57d2cf7  vmovaps [rsp+0xA0], xmm10
000078d1a57d2d00  vmovaps [rsp+0xB0], xmm11
000078d1a57d2d09  vmovaps [rsp+0xC0], xmm12
000078d1a57d2d12  vmovaps [rsp+0xD0], xmm14
000078d1a57d2d1b  vmovaps [rsp+0xE0], xmm15
000078d1a57d2d24  sub rsp, 0x30
000078d1a57d2d28  movaps [rsp], xmm13
000078d1a57d2d2d  movaps [rsp+0x10], xmm10
000078d1a57d2d33  movaps [rsp+0x20], xmm1
000078d1a57d2d38  lea rdi, [rsp]
000078d1a57d2d3c  mov esi, 0x00
000078d1a57d2d41  mov rax, 0x56EA20A26530
000078d1a57d2d4b  call rax
000078d1a57d2d4d  movaps xmm13, [rsp]
000078d1a57d2d52  add rsp, 0x30
000078d1a57d2d56  vmovaps xmm0, [rsp]
000078d1a57d2d5b  vmovaps xmm1, [rsp+0x10]
000078d1a57d2d61  vmovaps xmm2, [rsp+0x20]
000078d1a57d2d67  vmovaps xmm3, [rsp+0x30]
000078d1a57d2d6d  vmovaps xmm4, [rsp+0x40]
000078d1a57d2d73  vmovaps xmm5, [rsp+0x50]
000078d1a57d2d79  vmovaps xmm6, [rsp+0x60]
000078d1a57d2d7f  vmovaps xmm7, [rsp+0x70]
000078d1a57d2d85  vmovaps xmm8, [rsp+0x80]
000078d1a57d2d8e  vmovaps xmm9, [rsp+0x90]
000078d1a57d2d97  vmovaps xmm10, [rsp+0xA0]
000078d1a57d2da0  vmovaps xmm11, [rsp+0xB0]
000078d1a57d2da9  vmovaps xmm12, [rsp+0xC0]
000078d1a57d2db2  vmovaps xmm14, [rsp+0xD0]
000078d1a57d2dbb  vmovaps xmm15, [rsp+0xE0]
000078d1a57d2dc4  add rsp, 0xF0
000078d1a57d2dcb  pop r11
000078d1a57d2dcd  pop r10
000078d1a57d2dcf  pop r9
000078d1a57d2dd1  pop r8
000078d1a57d2dd3  pop rsi
000078d1a57d2dd4  pop rdi
000078d1a57d2dd5  pop rdx
000078d1a57d2dd6  pop rcx
000078d1a57d2dd7  pop rax
000078d1a57d2dd8  add rsp, 0x08
000078d1a57d2ddc  jmp 0x000078D1A57CFE15
000078d1a57d2de1  sub rsp, 0x08
000078d1a57d2de5  push rax
000078d1a57d2de6  push rcx
000078d1a57d2de7  push rdx
000078d1a57d2de8  push rdi
000078d1a57d2de9  push rsi
000078d1a57d2dea  push r8
000078d1a57d2dec  push r9
000078d1a57d2dee  push r10
000078d1a57d2df0  push r11
000078d1a57d2df2  sub rsp, 0xF0
000078d1a57d2df9  vmovaps [rsp], xmm0
000078d1a57d2dfe  vmovaps [rsp+0x10], xmm2
000078d1a57d2e04  vmovaps [rsp+0x20], xmm3
000078d1a57d2e0a  vmovaps [rsp+0x30], xmm4
000078d1a57d2e10  vmovaps [rsp+0x40], xmm5
000078d1a57d2e16  vmovaps [rsp+0x50], xmm6
000078d1a57d2e1c  vmovaps [rsp+0x60], xmm7
000078d1a57d2e22  vmovaps [rsp+0x70], xmm8
000078d1a57d2e28  vmovaps [rsp+0x80], xmm9
000078d1a57d2e31  vmovaps [rsp+0x90], xmm10
000078d1a57d2e3a  vmovaps [rsp+0xA0], xmm11
000078d1a57d2e43  vmovaps [rsp+0xB0], xmm12
000078d1a57d2e4c  vmovaps [rsp+0xC0], xmm13
000078d1a57d2e55  vmovaps [rsp+0xD0], xmm14
000078d1a57d2e5e  vmovaps [rsp+0xE0], xmm15
000078d1a57d2e67  sub rsp, 0x30
000078d1a57d2e6b  movaps [rsp], xmm1
000078d1a57d2e6f  movaps [rsp+0x10], xmm15
000078d1a57d2e75  movaps [rsp+0x20], xmm10
000078d1a57d2e7b  lea rdi, [rsp]
000078d1a57d2e7f  mov esi, 0x00
000078d1a57d2e84  mov rax, 0x56EA20A26530
000078d1a57d2e8e  call rax
000078d1a57d2e90  movaps xmm1, [rsp]
000078d1a57d2e94  add rsp, 0x30
000078d1a57d2e98  vmovaps xmm0, [rsp]
000078d1a57d2e9d  vmovaps xmm2, [rsp+0x10]
000078d1a57d2ea3  vmovaps xmm3, [rsp+0x20]
000078d1a57d2ea9  vmovaps xmm4, [rsp+0x30]
000078d1a57d2eaf  vmovaps xmm5, [rsp+0x40]
000078d1a57d2eb5  vmovaps xmm6, [rsp+0x50]
000078d1a57d2ebb  vmovaps xmm7, [rsp+0x60]
000078d1a57d2ec1  vmovaps xmm8, [rsp+0x70]
000078d1a57d2ec7  vmovaps xmm9, [rsp+0x80]
000078d1a57d2ed0  vmovaps xmm10, [rsp+0x90]
000078d1a57d2ed9  vmovaps xmm11, [rsp+0xA0]
000078d1a57d2ee2  vmovaps xmm12, [rsp+0xB0]
000078d1a57d2eeb  vmovaps xmm13, [rsp+0xC0]
000078d1a57d2ef4  vmovaps xmm14, [rsp+0xD0]
000078d1a57d2efd  vmovaps xmm15, [rsp+0xE0]
000078d1a57d2f06  add rsp, 0xF0
000078d1a57d2f0d  pop r11
000078d1a57d2f0f  pop r10
000078d1a57d2f11  pop r9
000078d1a57d2f13  pop r8
000078d1a57d2f15  pop rsi
000078d1a57d2f16  pop rdi
000078d1a57d2f17  pop rdx
000078d1a57d2f18  pop rcx
000078d1a57d2f19  pop rax
000078d1a57d2f1a  add rsp, 0x08
000078d1a57d2f1e  jmp 0x000078D1A57CFE34
000078d1a57d2f23  sub rsp, 0x08
000078d1a57d2f27  push rax
000078d1a57d2f28  push rcx
000078d1a57d2f29  push rdx
000078d1a57d2f2a  push rdi
000078d1a57d2f2b  push rsi
000078d1a57d2f2c  push r8
000078d1a57d2f2e  push r9
000078d1a57d2f30  push r10
000078d1a57d2f32  push r11
000078d1a57d2f34  sub rsp, 0xF0
000078d1a57d2f3b  vmovaps [rsp], xmm0
000078d1a57d2f40  vmovaps [rsp+0x10], xmm1
000078d1a57d2f46  vmovaps [rsp+0x20], xmm2
000078d1a57d2f4c  vmovaps [rsp+0x30], xmm3
000078d1a57d2f52  vmovaps [rsp+0x40], xmm4
000078d1a57d2f58  vmovaps [rsp+0x50], xmm5
000078d1a57d2f5e  vmovaps [rsp+0x60], xmm6
000078d1a57d2f64  vmovaps [rsp+0x70], xmm7
000078d1a57d2f6a  vmovaps [rsp+0x80], xmm8
000078d1a57d2f73  vmovaps [rsp+0x90], xmm9
000078d1a57d2f7c  vmovaps [rsp+0xA0], xmm10
000078d1a57d2f85  vmovaps [rsp+0xB0], xmm11
000078d1a57d2f8e  vmovaps [rsp+0xC0], xmm12
000078d1a57d2f97  vmovaps [rsp+0xD0], xmm13
000078d1a57d2fa0  vmovaps [rsp+0xE0], xmm14
000078d1a57d2fa9  sub rsp, 0x30
000078d1a57d2fad  movaps [rsp], xmm15
000078d1a57d2fb2  movaps [rsp+0x10], xmm10
000078d1a57d2fb8  movaps [rsp+0x20], xmm11
000078d1a57d2fbe  lea rdi, [rsp]
000078d1a57d2fc2  mov esi, 0x00
000078d1a57d2fc7  mov rax, 0x56EA20A26530
000078d1a57d2fd1  call rax
000078d1a57d2fd3  movaps xmm15, [rsp]
000078d1a57d2fd8  add rsp, 0x30
000078d1a57d2fdc  vmovaps xmm0, [rsp]
000078d1a57d2fe1  vmovaps xmm1, [rsp+0x10]
000078d1a57d2fe7  vmovaps xmm2, [rsp+0x20]
000078d1a57d2fed  vmovaps xmm3, [rsp+0x30]
000078d1a57d2ff3  vmovaps xmm4, [rsp+0x40]
000078d1a57d2ff9  vmovaps xmm5, [rsp+0x50]
000078d1a57d2fff  vmovaps xmm6, [rsp+0x60]
000078d1a57d3005  vmovaps xmm7, [rsp+0x70]
000078d1a57d300b  vmovaps xmm8, [rsp+0x80]
000078d1a57d3014  vmovaps xmm9, [rsp+0x90]
000078d1a57d301d  vmovaps xmm10, [rsp+0xA0]
000078d1a57d3026  vmovaps xmm11, [rsp+0xB0]
000078d1a57d302f  vmovaps xmm12, [rsp+0xC0]
000078d1a57d3038  vmovaps xmm13, [rsp+0xD0]
000078d1a57d3041  vmovaps xmm14, [rsp+0xE0]
000078d1a57d304a  add rsp, 0xF0
000078d1a57d3051  pop r11
000078d1a57d3053  pop r10
000078d1a57d3055  pop r9
000078d1a57d3057  pop r8
000078d1a57d3059  pop rsi
000078d1a57d305a  pop rdi
000078d1a57d305b  pop rdx
000078d1a57d305c  pop rcx
000078d1a57d305d  pop rax
000078d1a57d305e  add rsp, 0x08
000078d1a57d3062  jmp 0x000078D1A57CFE57
000078d1a57d3067  sub rsp, 0x08
000078d1a57d306b  push rax
000078d1a57d306c  push rcx
000078d1a57d306d  push rdx
000078d1a57d306e  push rdi
000078d1a57d306f  push rsi
000078d1a57d3070  push r8
000078d1a57d3072  push r9
000078d1a57d3074  push r10
000078d1a57d3076  push r11
000078d1a57d3078  sub rsp, 0xF0
000078d1a57d307f  vmovaps [rsp], xmm0
000078d1a57d3084  vmovaps [rsp+0x10], xmm1
000078d1a57d308a  vmovaps [rsp+0x20], xmm2
000078d1a57d3090  vmovaps [rsp+0x30], xmm3
000078d1a57d3096  vmovaps [rsp+0x40], xmm4
000078d1a57d309c  vmovaps [rsp+0x50], xmm5
000078d1a57d30a2  vmovaps [rsp+0x60], xmm6
000078d1a57d30a8  vmovaps [rsp+0x70], xmm7
000078d1a57d30ae  vmovaps [rsp+0x80], xmm8
000078d1a57d30b7  vmovaps [rsp+0x90], xmm9
000078d1a57d30c0  vmovaps [rsp+0xA0], xmm11
000078d1a57d30c9  vmovaps [rsp+0xB0], xmm12
000078d1a57d30d2  vmovaps [rsp+0xC0], xmm13
000078d1a57d30db  vmovaps [rsp+0xD0], xmm14
000078d1a57d30e4  vmovaps [rsp+0xE0], xmm15
000078d1a57d30ed  sub rsp, 0x30
000078d1a57d30f1  movaps [rsp], xmm10
000078d1a57d30f6  movaps [rsp+0x10], xmm12
000078d1a57d30fc  movaps [rsp+0x20], xmm11
000078d1a57d3102  lea rdi, [rsp]
000078d1a57d3106  mov esi, 0x00
000078d1a57d310b  mov rax, 0x56EA20A26530
000078d1a57d3115  call rax
000078d1a57d3117  movaps xmm10, [rsp]
000078d1a57d311c  add rsp, 0x30
000078d1a57d3120  vmovaps xmm0, [rsp]
000078d1a57d3125  vmovaps xmm1, [rsp+0x10]
000078d1a57d312b  vmovaps xmm2, [rsp+0x20]
000078d1a57d3131  vmovaps xmm3, [rsp+0x30]
000078d1a57d3137  vmovaps xmm4, [rsp+0x40]
000078d1a57d313d  vmovaps xmm5, [rsp+0x50]
000078d1a57d3143  vmovaps xmm6, [rsp+0x60]
000078d1a57d3149  vmovaps xmm7, [rsp+0x70]
000078d1a57d314f  vmovaps xmm8, [rsp+0x80]
000078d1a57d3158  vmovaps xmm9, [rsp+0x90]
000078d1a57d3161  vmovaps xmm11, [rsp+0xA0]
000078d1a57d316a  vmovaps xmm12, [rsp+0xB0]
000078d1a57d3173  vmovaps xmm13, [rsp+0xC0]
000078d1a57d317c  vmovaps xmm14, [rsp+0xD0]
000078d1a57d3185  vmovaps xmm15, [rsp+0xE0]
000078d1a57d318e  add rsp, 0xF0
000078d1a57d3195  pop r11
000078d1a57d3197  pop r10
000078d1a57d3199  pop r9
000078d1a57d319b  pop r8
000078d1a57d319d  pop rsi
000078d1a57d319e  pop rdi
000078d1a57d319f  pop rdx
000078d1a57d31a0  pop rcx
000078d1a57d31a1  pop rax
000078d1a57d31a2  add rsp, 0x08
000078d1a57d31a6  jmp 0x000078D1A57CFE80
000078d1a57d31ab  sub rsp, 0x08
000078d1a57d31af  push rax
000078d1a57d31b0  push rcx
000078d1a57d31b1  push rdx
000078d1a57d31b2  push rdi
000078d1a57d31b3  push rsi
000078d1a57d31b4  push r8
000078d1a57d31b6  push r9
000078d1a57d31b8  push r10
000078d1a57d31ba  push r11
000078d1a57d31bc  sub rsp, 0xF0
000078d1a57d31c3  vmovaps [rsp], xmm0
000078d1a57d31c8  vmovaps [rsp+0x10], xmm1
000078d1a57d31ce  vmovaps [rsp+0x20], xmm2
000078d1a57d31d4  vmovaps [rsp+0x30], xmm3
000078d1a57d31da  vmovaps [rsp+0x40], xmm4
000078d1a57d31e0  vmovaps [rsp+0x50], xmm5
000078d1a57d31e6  vmovaps [rsp+0x60], xmm6
000078d1a57d31ec  vmovaps [rsp+0x70], xmm7
000078d1a57d31f2  vmovaps [rsp+0x80], xmm8
000078d1a57d31fb  vmovaps [rsp+0x90], xmm9
000078d1a57d3204  vmovaps [rsp+0xA0], xmm10
000078d1a57d320d  vmovaps [rsp+0xB0], xmm12
000078d1a57d3216  vmovaps [rsp+0xC0], xmm13
000078d1a57d321f  vmovaps [rsp+0xD0], xmm14
000078d1a57d3228  vmovaps [rsp+0xE0], xmm15
000078d1a57d3231  sub rsp, 0x30
000078d1a57d3235  movaps [rsp], xmm11
000078d1a57d323a  movaps [rsp+0x10], xmm2
000078d1a57d323f  movaps [rsp+0x20], xmm12
000078d1a57d3245  lea rdi, [rsp]
000078d1a57d3249  mov esi, 0x00
000078d1a57d324e  mov rax, 0x56EA20A26530
000078d1a57d3258  call rax
000078d1a57d325a  movaps xmm11, [rsp]
000078d1a57d325f  add rsp, 0x30
000078d1a57d3263  vmovaps xmm0, [rsp]
000078d1a57d3268  vmovaps xmm1, [rsp+0x10]
000078d1a57d326e  vmovaps xmm2, [rsp+0x20]
000078d1a57d3274  vmovaps xmm3, [rsp+0x30]
000078d1a57d327a  vmovaps xmm4, [rsp+0x40]
000078d1a57d3280  vmovaps xmm5, [rsp+0x50]
000078d1a57d3286  vmovaps xmm6, [rsp+0x60]
000078d1a57d328c  vmovaps xmm7, [rsp+0x70]
000078d1a57d3292  vmovaps xmm8, [rsp+0x80]
000078d1a57d329b  vmovaps xmm9, [rsp+0x90]
000078d1a57d32a4  vmovaps xmm10, [rsp+0xA0]
000078d1a57d32ad  vmovaps xmm12, [rsp+0xB0]
000078d1a57d32b6  vmovaps xmm13, [rsp+0xC0]
000078d1a57d32bf  vmovaps xmm14, [rsp+0xD0]
000078d1a57d32c8  vmovaps xmm15, [rsp+0xE0]
000078d1a57d32d1  add rsp, 0xF0
000078d1a57d32d8  pop r11
000078d1a57d32da  pop r10
000078d1a57d32dc  pop r9
000078d1a57d32de  pop r8
000078d1a57d32e0  pop rsi
000078d1a57d32e1  pop rdi
000078d1a57d32e2  pop rdx
000078d1a57d32e3  pop rcx
000078d1a57d32e4  pop rax
000078d1a57d32e5  add rsp, 0x08
000078d1a57d32e9  jmp 0x000078D1A57CFEB8
000078d1a57d32ee  sub rsp, 0x08
000078d1a57d32f2  push rax
000078d1a57d32f3  push rcx
000078d1a57d32f4  push rdx
000078d1a57d32f5  push rdi
000078d1a57d32f6  push rsi
000078d1a57d32f7  push r8
000078d1a57d32f9  push r9
000078d1a57d32fb  push r10
000078d1a57d32fd  push r11
000078d1a57d32ff  sub rsp, 0xF0
000078d1a57d3306  vmovaps [rsp], xmm0
000078d1a57d330b  vmovaps [rsp+0x10], xmm2
000078d1a57d3311  vmovaps [rsp+0x20], xmm3
000078d1a57d3317  vmovaps [rsp+0x30], xmm4
000078d1a57d331d  vmovaps [rsp+0x40], xmm5
000078d1a57d3323  vmovaps [rsp+0x50], xmm6
000078d1a57d3329  vmovaps [rsp+0x60], xmm7
000078d1a57d332f  vmovaps [rsp+0x70], xmm8
000078d1a57d3335  vmovaps [rsp+0x80], xmm9
000078d1a57d333e  vmovaps [rsp+0x90], xmm10
000078d1a57d3347  vmovaps [rsp+0xA0], xmm11
000078d1a57d3350  vmovaps [rsp+0xB0], xmm12
000078d1a57d3359  vmovaps [rsp+0xC0], xmm13
000078d1a57d3362  vmovaps [rsp+0xD0], xmm14
000078d1a57d336b  vmovaps [rsp+0xE0], xmm15
000078d1a57d3374  sub rsp, 0x30
000078d1a57d3378  movaps [rsp], xmm1
000078d1a57d337c  movaps [rsp+0x10], xmm14
000078d1a57d3382  movaps [rsp+0x20], xmm6
000078d1a57d3387  lea rdi, [rsp]
000078d1a57d338b  mov esi, 0x00
000078d1a57d3390  mov rax, 0x56EA20A26530
000078d1a57d339a  call rax
000078d1a57d339c  movaps xmm1, [rsp]
000078d1a57d33a0  add rsp, 0x30
000078d1a57d33a4  vmovaps xmm0, [rsp]
000078d1a57d33a9  vmovaps xmm2, [rsp+0x10]
000078d1a57d33af  vmovaps xmm3, [rsp+0x20]
000078d1a57d33b5  vmovaps xmm4, [rsp+0x30]
000078d1a57d33bb  vmovaps xmm5, [rsp+0x40]
000078d1a57d33c1  vmovaps xmm6, [rsp+0x50]
000078d1a57d33c7  vmovaps xmm7, [rsp+0x60]
000078d1a57d33cd  vmovaps xmm8, [rsp+0x70]
000078d1a57d33d3  vmovaps xmm9, [rsp+0x80]
000078d1a57d33dc  vmovaps xmm10, [rsp+0x90]
000078d1a57d33e5  vmovaps xmm11, [rsp+0xA0]
000078d1a57d33ee  vmovaps xmm12, [rsp+0xB0]
000078d1a57d33f7  vmovaps xmm13, [rsp+0xC0]
000078d1a57d3400  vmovaps xmm14, [rsp+0xD0]
000078d1a57d3409  vmovaps xmm15, [rsp+0xE0]
000078d1a57d3412  add rsp, 0xF0
000078d1a57d3419  pop r11
000078d1a57d341b  pop r10
000078d1a57d341d  pop r9
000078d1a57d341f  pop r8
000078d1a57d3421  pop rsi
000078d1a57d3422  pop rdi
000078d1a57d3423  pop rdx
000078d1a57d3424  pop rcx
000078d1a57d3425  pop rax
000078d1a57d3426  add rsp, 0x08
000078d1a57d342a  jmp 0x000078D1A57CFED1
000078d1a57d342f  sub rsp, 0x08
000078d1a57d3433  push rax
000078d1a57d3434  push rcx
000078d1a57d3435  push rdx
000078d1a57d3436  push rdi
000078d1a57d3437  push rsi
000078d1a57d3438  push r8
000078d1a57d343a  push r9
000078d1a57d343c  push r10
000078d1a57d343e  push r11
000078d1a57d3440  sub rsp, 0xF0
000078d1a57d3447  vmovaps [rsp], xmm0
000078d1a57d344c  vmovaps [rsp+0x10], xmm1
000078d1a57d3452  vmovaps [rsp+0x20], xmm2
000078d1a57d3458  vmovaps [rsp+0x30], xmm3
000078d1a57d345e  vmovaps [rsp+0x40], xmm4
000078d1a57d3464  vmovaps [rsp+0x50], xmm5
000078d1a57d346a  vmovaps [rsp+0x60], xmm6
000078d1a57d3470  vmovaps [rsp+0x70], xmm7
000078d1a57d3476  vmovaps [rsp+0x80], xmm8
000078d1a57d347f  vmovaps [rsp+0x90], xmm9
000078d1a57d3488  vmovaps [rsp+0xA0], xmm10
000078d1a57d3491  vmovaps [rsp+0xB0], xmm11
000078d1a57d349a  vmovaps [rsp+0xC0], xmm12
000078d1a57d34a3  vmovaps [rsp+0xD0], xmm13
000078d1a57d34ac  vmovaps [rsp+0xE0], xmm15
000078d1a57d34b5  sub rsp, 0x30
000078d1a57d34b9  movaps [rsp], xmm14
000078d1a57d34be  movaps [rsp+0x10], xmm12
000078d1a57d34c4  movaps [rsp+0x20], xmm5
000078d1a57d34c9  lea rdi, [rsp]
000078d1a57d34cd  mov esi, 0x00
000078d1a57d34d2  mov rax, 0x56EA20A26530
000078d1a57d34dc  call rax
000078d1a57d34de  movaps xmm14, [rsp]
000078d1a57d34e3  add rsp, 0x30
000078d1a57d34e7  vmovaps xmm0, [rsp]
000078d1a57d34ec  vmovaps xmm1, [rsp+0x10]
000078d1a57d34f2  vmovaps xmm2, [rsp+0x20]
000078d1a57d34f8  vmovaps xmm3, [rsp+0x30]
000078d1a57d34fe  vmovaps xmm4, [rsp+0x40]
000078d1a57d3504  vmovaps xmm5, [rsp+0x50]
000078d1a57d350a  vmovaps xmm6, [rsp+0x60]
000078d1a57d3510  vmovaps xmm7, [rsp+0x70]
000078d1a57d3516  vmovaps xmm8, [rsp+0x80]
000078d1a57d351f  vmovaps xmm9, [rsp+0x90]
000078d1a57d3528  vmovaps xmm10, [rsp+0xA0]
000078d1a57d3531  vmovaps xmm11, [rsp+0xB0]
000078d1a57d353a  vmovaps xmm12, [rsp+0xC0]
000078d1a57d3543  vmovaps xmm13, [rsp+0xD0]
000078d1a57d354c  vmovaps xmm15, [rsp+0xE0]
000078d1a57d3555  add rsp, 0xF0
000078d1a57d355c  pop r11
000078d1a57d355e  pop r10
000078d1a57d3560  pop r9
000078d1a57d3562  pop r8
000078d1a57d3564  pop rsi
000078d1a57d3565  pop rdi
000078d1a57d3566  pop rdx
000078d1a57d3567  pop rcx
000078d1a57d3568  pop rax
000078d1a57d3569  add rsp, 0x08
000078d1a57d356d  jmp 0x000078D1A57CFEF1
000078d1a57d3572  sub rsp, 0x08
000078d1a57d3576  push rax
000078d1a57d3577  push rcx
000078d1a57d3578  push rdx
000078d1a57d3579  push rdi
000078d1a57d357a  push rsi
000078d1a57d357b  push r8
000078d1a57d357d  push r9
000078d1a57d357f  push r10
000078d1a57d3581  push r11
000078d1a57d3583  sub rsp, 0xF0
000078d1a57d358a  vmovaps [rsp], xmm0
000078d1a57d358f  vmovaps [rsp+0x10], xmm1
000078d1a57d3595  vmovaps [rsp+0x20], xmm2
000078d1a57d359b  vmovaps [rsp+0x30], xmm3
000078d1a57d35a1  vmovaps [rsp+0x40], xmm4
000078d1a57d35a7  vmovaps [rsp+0x50], xmm5
000078d1a57d35ad  vmovaps [rsp+0x60], xmm7
000078d1a57d35b3  vmovaps [rsp+0x70], xmm8
000078d1a57d35b9  vmovaps [rsp+0x80], xmm9
000078d1a57d35c2  vmovaps [rsp+0x90], xmm10
000078d1a57d35cb  vmovaps [rsp+0xA0], xmm11
000078d1a57d35d4  vmovaps [rsp+0xB0], xmm12
000078d1a57d35dd  vmovaps [rsp+0xC0], xmm13
000078d1a57d35e6  vmovaps [rsp+0xD0], xmm14
000078d1a57d35ef  vmovaps [rsp+0xE0], xmm15
000078d1a57d35f8  sub rsp, 0x30
000078d1a57d35fc  movaps [rsp], xmm6
000078d1a57d3600  movaps [rsp+0x10], xmm9
000078d1a57d3606  movaps [rsp+0x20], xmm12
000078d1a57d360c  lea rdi, [rsp]
000078d1a57d3610  mov esi, 0x00
000078d1a57d3615  mov rax, 0x56EA20A26530
000078d1a57d361f  call rax
000078d1a57d3621  movaps xmm6, [rsp]
000078d1a57d3625  add rsp, 0x30
000078d1a57d3629  vmovaps xmm0, [rsp]
000078d1a57d362e  vmovaps xmm1, [rsp+0x10]
000078d1a57d3634  vmovaps xmm2, [rsp+0x20]
000078d1a57d363a  vmovaps xmm3, [rsp+0x30]
000078d1a57d3640  vmovaps xmm4, [rsp+0x40]
000078d1a57d3646  vmovaps xmm5, [rsp+0x50]
000078d1a57d364c  vmovaps xmm7, [rsp+0x60]
000078d1a57d3652  vmovaps xmm8, [rsp+0x70]
000078d1a57d3658  vmovaps xmm9, [rsp+0x80]
000078d1a57d3661  vmovaps xmm10, [rsp+0x90]
000078d1a57d366a  vmovaps xmm11, [rsp+0xA0]
000078d1a57d3673  vmovaps xmm12, [rsp+0xB0]
000078d1a57d367c  vmovaps xmm13, [rsp+0xC0]
000078d1a57d3685  vmovaps xmm14, [rsp+0xD0]
000078d1a57d368e  vmovaps xmm15, [rsp+0xE0]
000078d1a57d3697  add rsp, 0xF0
000078d1a57d369e  pop r11
000078d1a57d36a0  pop r10
000078d1a57d36a2  pop r9
000078d1a57d36a4  pop r8
000078d1a57d36a6  pop rsi
000078d1a57d36a7  pop rdi
000078d1a57d36a8  pop rdx
000078d1a57d36a9  pop rcx
000078d1a57d36aa  pop rax
000078d1a57d36ab  add rsp, 0x08
000078d1a57d36af  jmp 0x000078D1A57CFF19
000078d1a57d36b4  sub rsp, 0x08
000078d1a57d36b8  push rax
000078d1a57d36b9  push rcx
000078d1a57d36ba  push rdx
000078d1a57d36bb  push rdi
000078d1a57d36bc  push rsi
000078d1a57d36bd  push r8
000078d1a57d36bf  push r9
000078d1a57d36c1  push r10
000078d1a57d36c3  push r11
000078d1a57d36c5  sub rsp, 0xF0
000078d1a57d36cc  vmovaps [rsp], xmm0
000078d1a57d36d1  vmovaps [rsp+0x10], xmm1
000078d1a57d36d7  vmovaps [rsp+0x20], xmm2
000078d1a57d36dd  vmovaps [rsp+0x30], xmm3
000078d1a57d36e3  vmovaps [rsp+0x40], xmm4
000078d1a57d36e9  vmovaps [rsp+0x50], xmm5
000078d1a57d36ef  vmovaps [rsp+0x60], xmm6
000078d1a57d36f5  vmovaps [rsp+0x70], xmm7
000078d1a57d36fb  vmovaps [rsp+0x80], xmm8
000078d1a57d3704  vmovaps [rsp+0x90], xmm9
000078d1a57d370d  vmovaps [rsp+0xA0], xmm10
000078d1a57d3716  vmovaps [rsp+0xB0], xmm11
000078d1a57d371f  vmovaps [rsp+0xC0], xmm13
000078d1a57d3728  vmovaps [rsp+0xD0], xmm14
000078d1a57d3731  vmovaps [rsp+0xE0], xmm15
000078d1a57d373a  sub rsp, 0x30
000078d1a57d373e  movaps [rsp], xmm12
000078d1a57d3743  movaps [rsp+0x10], xmm15
000078d1a57d3749  movaps [rsp+0x20], xmm13
000078d1a57d374f  lea rdi, [rsp]
000078d1a57d3753  mov esi, 0x00
000078d1a57d3758  mov rax, 0x56EA20A26530
000078d1a57d3762  call rax
000078d1a57d3764  movaps xmm12, [rsp]
000078d1a57d3769  add rsp, 0x30
000078d1a57d376d  vmovaps xmm0, [rsp]
000078d1a57d3772  vmovaps xmm1, [rsp+0x10]
000078d1a57d3778  vmovaps xmm2, [rsp+0x20]
000078d1a57d377e  vmovaps xmm3, [rsp+0x30]
000078d1a57d3784  vmovaps xmm4, [rsp+0x40]
000078d1a57d378a  vmovaps xmm5, [rsp+0x50]
000078d1a57d3790  vmovaps xmm6, [rsp+0x60]
000078d1a57d3796  vmovaps xmm7, [rsp+0x70]
000078d1a57d379c  vmovaps xmm8, [rsp+0x80]
000078d1a57d37a5  vmovaps xmm9, [rsp+0x90]
000078d1a57d37ae  vmovaps xmm10, [rsp+0xA0]
000078d1a57d37b7  vmovaps xmm11, [rsp+0xB0]
000078d1a57d37c0  vmovaps xmm13, [rsp+0xC0]
000078d1a57d37c9  vmovaps xmm14, [rsp+0xD0]
000078d1a57d37d2  vmovaps xmm15, [rsp+0xE0]
000078d1a57d37db  add rsp, 0xF0
000078d1a57d37e2  pop r11
000078d1a57d37e4  pop r10
000078d1a57d37e6  pop r9
000078d1a57d37e8  pop r8
000078d1a57d37ea  pop rsi
000078d1a57d37eb  pop rdi
000078d1a57d37ec  pop rdx
000078d1a57d37ed  pop rcx
000078d1a57d37ee  pop rax
000078d1a57d37ef  add rsp, 0x08
000078d1a57d37f3  jmp 0x000078D1A57CFF34
000078d1a57d37f8  sub rsp, 0x08
000078d1a57d37fc  push rax
000078d1a57d37fd  push rcx
000078d1a57d37fe  push rdx
000078d1a57d37ff  push rdi
000078d1a57d3800  push rsi
000078d1a57d3801  push r8
000078d1a57d3803  push r9
000078d1a57d3805  push r10
000078d1a57d3807  push r11
000078d1a57d3809  sub rsp, 0xF0
000078d1a57d3810  vmovaps [rsp], xmm0
000078d1a57d3815  vmovaps [rsp+0x10], xmm1
000078d1a57d381b  vmovaps [rsp+0x20], xmm2
000078d1a57d3821  vmovaps [rsp+0x30], xmm3
000078d1a57d3827  vmovaps [rsp+0x40], xmm4
000078d1a57d382d  vmovaps [rsp+0x50], xmm5
000078d1a57d3833  vmovaps [rsp+0x60], xmm6
000078d1a57d3839  vmovaps [rsp+0x70], xmm7
000078d1a57d383f  vmovaps [rsp+0x80], xmm8
000078d1a57d3848  vmovaps [rsp+0x90], xmm9
000078d1a57d3851  vmovaps [rsp+0xA0], xmm10
000078d1a57d385a  vmovaps [rsp+0xB0], xmm11
000078d1a57d3863  vmovaps [rsp+0xC0], xmm12
000078d1a57d386c  vmovaps [rsp+0xD0], xmm13
000078d1a57d3875  vmovaps [rsp+0xE0], xmm14
000078d1a57d387e  sub rsp, 0x30
000078d1a57d3882  movaps [rsp], xmm15
000078d1a57d3887  movaps [rsp+0x10], xmm13
000078d1a57d388d  movaps [rsp+0x20], xmm10
000078d1a57d3893  lea rdi, [rsp]
000078d1a57d3897  mov esi, 0x00
000078d1a57d389c  mov rax, 0x56EA20A26530
000078d1a57d38a6  call rax
000078d1a57d38a8  movaps xmm15, [rsp]
000078d1a57d38ad  add rsp, 0x30
000078d1a57d38b1  vmovaps xmm0, [rsp]
000078d1a57d38b6  vmovaps xmm1, [rsp+0x10]
000078d1a57d38bc  vmovaps xmm2, [rsp+0x20]
000078d1a57d38c2  vmovaps xmm3, [rsp+0x30]
000078d1a57d38c8  vmovaps xmm4, [rsp+0x40]
000078d1a57d38ce  vmovaps xmm5, [rsp+0x50]
000078d1a57d38d4  vmovaps xmm6, [rsp+0x60]
000078d1a57d38da  vmovaps xmm7, [rsp+0x70]
000078d1a57d38e0  vmovaps xmm8, [rsp+0x80]
000078d1a57d38e9  vmovaps xmm9, [rsp+0x90]
000078d1a57d38f2  vmovaps xmm10, [rsp+0xA0]
000078d1a57d38fb  vmovaps xmm11, [rsp+0xB0]
000078d1a57d3904  vmovaps xmm12, [rsp+0xC0]
000078d1a57d390d  vmovaps xmm13, [rsp+0xD0]
000078d1a57d3916  vmovaps xmm14, [rsp+0xE0]
000078d1a57d391f  add rsp, 0xF0
000078d1a57d3926  pop r11
000078d1a57d3928  pop r10
000078d1a57d392a  pop r9
000078d1a57d392c  pop r8
000078d1a57d392e  pop rsi
000078d1a57d392f  pop rdi
000078d1a57d3930  pop rdx
000078d1a57d3931  pop rcx
000078d1a57d3932  pop rax
000078d1a57d3933  add rsp, 0x08
000078d1a57d3937  jmp 0x000078D1A57CFF55
000078d1a57d393c  call 0x000078D1A560C260
000078d1a57d3941  jmp 0x000078D1A57CFFB0
000078d1a57d3946  sub rsp, 0x08
000078d1a57d394a  push rax
000078d1a57d394b  push rcx
000078d1a57d394c  push rdx
000078d1a57d394d  push rdi
000078d1a57d394e  push rsi
000078d1a57d394f  push r8
000078d1a57d3951  push r9
000078d1a57d3953  push r10
000078d1a57d3955  push r11
000078d1a57d3957  sub rsp, 0xF0
000078d1a57d395e  vmovaps [rsp], xmm0
000078d1a57d3963  vmovaps [rsp+0x10], xmm1
000078d1a57d3969  vmovaps [rsp+0x20], xmm2
000078d1a57d396f  vmovaps [rsp+0x30], xmm3
000078d1a57d3975  vmovaps [rsp+0x40], xmm4
000078d1a57d397b  vmovaps [rsp+0x50], xmm5
000078d1a57d3981  vmovaps [rsp+0x60], xmm6
000078d1a57d3987  vmovaps [rsp+0x70], xmm7
000078d1a57d398d  vmovaps [rsp+0x80], xmm8
000078d1a57d3996  vmovaps [rsp+0x90], xmm10
000078d1a57d399f  vmovaps [rsp+0xA0], xmm11
000078d1a57d39a8  vmovaps [rsp+0xB0], xmm12
000078d1a57d39b1  vmovaps [rsp+0xC0], xmm13
000078d1a57d39ba  vmovaps [rsp+0xD0], xmm14
000078d1a57d39c3  vmovaps [rsp+0xE0], xmm15
000078d1a57d39cc  sub rsp, 0x30
000078d1a57d39d0  movaps [rsp], xmm9
000078d1a57d39d5  movaps [rsp+0x10], xmm8
000078d1a57d39db  movaps [rsp+0x20], xmm10
000078d1a57d39e1  lea rdi, [rsp]
000078d1a57d39e5  mov esi, 0x00
000078d1a57d39ea  mov rax, 0x56EA20A26530
000078d1a57d39f4  call rax
000078d1a57d39f6  movaps xmm9, [rsp]
000078d1a57d39fb  add rsp, 0x30
000078d1a57d39ff  vmovaps xmm0, [rsp]
000078d1a57d3a04  vmovaps xmm1, [rsp+0x10]
000078d1a57d3a0a  vmovaps xmm2, [rsp+0x20]
000078d1a57d3a10  vmovaps xmm3, [rsp+0x30]
000078d1a57d3a16  vmovaps xmm4, [rsp+0x40]
000078d1a57d3a1c  vmovaps xmm5, [rsp+0x50]
000078d1a57d3a22  vmovaps xmm6, [rsp+0x60]
000078d1a57d3a28  vmovaps xmm7, [rsp+0x70]
000078d1a57d3a2e  vmovaps xmm8, [rsp+0x80]
000078d1a57d3a37  vmovaps xmm10, [rsp+0x90]
000078d1a57d3a40  vmovaps xmm11, [rsp+0xA0]
000078d1a57d3a49  vmovaps xmm12, [rsp+0xB0]
000078d1a57d3a52  vmovaps xmm13, [rsp+0xC0]
000078d1a57d3a5b  vmovaps xmm14, [rsp+0xD0]
000078d1a57d3a64  vmovaps xmm15, [rsp+0xE0]
000078d1a57d3a6d  add rsp, 0xF0
000078d1a57d3a74  pop r11
000078d1a57d3a76  pop r10
000078d1a57d3a78  pop r9
000078d1a57d3a7a  pop r8
000078d1a57d3a7c  pop rsi
000078d1a57d3a7d  pop rdi
000078d1a57d3a7e  pop rdx
000078d1a57d3a7f  pop rcx
000078d1a57d3a80  pop rax
000078d1a57d3a81  add rsp, 0x08
000078d1a57d3a85  jmp 0x000078D1A57CFFE1
000078d1a57d3a8a  sub rsp, 0x08
000078d1a57d3a8e  push rax
000078d1a57d3a8f  push rcx
000078d1a57d3a90  push rdx
000078d1a57d3a91  push rdi
000078d1a57d3a92  push rsi
000078d1a57d3a93  push r8
000078d1a57d3a95  push r9
000078d1a57d3a97  push r10
000078d1a57d3a99  push r11
000078d1a57d3a9b  sub rsp, 0xF0
000078d1a57d3aa2  vmovaps [rsp], xmm0
000078d1a57d3aa7  vmovaps [rsp+0x10], xmm1
000078d1a57d3aad  vmovaps [rsp+0x20], xmm2
000078d1a57d3ab3  vmovaps [rsp+0x30], xmm3
000078d1a57d3ab9  vmovaps [rsp+0x40], xmm4
000078d1a57d3abf  vmovaps [rsp+0x50], xmm5
000078d1a57d3ac5  vmovaps [rsp+0x60], xmm6
000078d1a57d3acb  vmovaps [rsp+0x70], xmm7
000078d1a57d3ad1  vmovaps [rsp+0x80], xmm8
000078d1a57d3ada  vmovaps [rsp+0x90], xmm9
000078d1a57d3ae3  vmovaps [rsp+0xA0], xmm11
000078d1a57d3aec  vmovaps [rsp+0xB0], xmm12
000078d1a57d3af5  vmovaps [rsp+0xC0], xmm13
000078d1a57d3afe  vmovaps [rsp+0xD0], xmm14
000078d1a57d3b07  vmovaps [rsp+0xE0], xmm15
000078d1a57d3b10  sub rsp, 0x30
000078d1a57d3b14  movaps [rsp], xmm10
000078d1a57d3b19  movaps [rsp+0x10], xmm1
000078d1a57d3b1e  movaps [rsp+0x20], xmm11
000078d1a57d3b24  lea rdi, [rsp]
000078d1a57d3b28  mov esi, 0x00
000078d1a57d3b2d  mov rax, 0x56EA20A26530
000078d1a57d3b37  call rax
000078d1a57d3b39  movaps xmm10, [rsp]
000078d1a57d3b3e  add rsp, 0x30
000078d1a57d3b42  vmovaps xmm0, [rsp]
000078d1a57d3b47  vmovaps xmm1, [rsp+0x10]
000078d1a57d3b4d  vmovaps xmm2, [rsp+0x20]
000078d1a57d3b53  vmovaps xmm3, [rsp+0x30]
000078d1a57d3b59  vmovaps xmm4, [rsp+0x40]
000078d1a57d3b5f  vmovaps xmm5, [rsp+0x50]
000078d1a57d3b65  vmovaps xmm6, [rsp+0x60]
000078d1a57d3b6b  vmovaps xmm7, [rsp+0x70]
000078d1a57d3b71  vmovaps xmm8, [rsp+0x80]
000078d1a57d3b7a  vmovaps xmm9, [rsp+0x90]
000078d1a57d3b83  vmovaps xmm11, [rsp+0xA0]
000078d1a57d3b8c  vmovaps xmm12, [rsp+0xB0]
000078d1a57d3b95  vmovaps xmm13, [rsp+0xC0]
000078d1a57d3b9e  vmovaps xmm14, [rsp+0xD0]
000078d1a57d3ba7  vmovaps xmm15, [rsp+0xE0]
000078d1a57d3bb0  add rsp, 0xF0
000078d1a57d3bb7  pop r11
000078d1a57d3bb9  pop r10
000078d1a57d3bbb  pop r9
000078d1a57d3bbd  pop r8
000078d1a57d3bbf  pop rsi
000078d1a57d3bc0  pop rdi
000078d1a57d3bc1  pop rdx
000078d1a57d3bc2  pop rcx
000078d1a57d3bc3  pop rax
000078d1a57d3bc4  add rsp, 0x08
000078d1a57d3bc8  jmp 0x000078D1A57CFFFC
000078d1a57d3bcd  sub rsp, 0x08
000078d1a57d3bd1  push rax
000078d1a57d3bd2  push rcx
000078d1a57d3bd3  push rdx
000078d1a57d3bd4  push rdi
000078d1a57d3bd5  push rsi
000078d1a57d3bd6  push r8
000078d1a57d3bd8  push r9
000078d1a57d3bda  push r10
000078d1a57d3bdc  push r11
000078d1a57d3bde  sub rsp, 0xF0
000078d1a57d3be5  vmovaps [rsp], xmm0
000078d1a57d3bea  vmovaps [rsp+0x10], xmm2
000078d1a57d3bf0  vmovaps [rsp+0x20], xmm3
000078d1a57d3bf6  vmovaps [rsp+0x30], xmm4
000078d1a57d3bfc  vmovaps [rsp+0x40], xmm5
000078d1a57d3c02  vmovaps [rsp+0x50], xmm6
000078d1a57d3c08  vmovaps [rsp+0x60], xmm7
000078d1a57d3c0e  vmovaps [rsp+0x70], xmm8
000078d1a57d3c14  vmovaps [rsp+0x80], xmm9
000078d1a57d3c1d  vmovaps [rsp+0x90], xmm10
000078d1a57d3c26  vmovaps [rsp+0xA0], xmm11
000078d1a57d3c2f  vmovaps [rsp+0xB0], xmm12
000078d1a57d3c38  vmovaps [rsp+0xC0], xmm13
000078d1a57d3c41  vmovaps [rsp+0xD0], xmm14
000078d1a57d3c4a  vmovaps [rsp+0xE0], xmm15
000078d1a57d3c53  sub rsp, 0x30
000078d1a57d3c57  movaps [rsp], xmm1
000078d1a57d3c5b  movaps [rsp+0x10], xmm14
000078d1a57d3c61  movaps [rsp+0x20], xmm6
000078d1a57d3c66  lea rdi, [rsp]
000078d1a57d3c6a  mov esi, 0x00
000078d1a57d3c6f  mov rax, 0x56EA20A26530
000078d1a57d3c79  call rax
000078d1a57d3c7b  movaps xmm1, [rsp]
000078d1a57d3c7f  add rsp, 0x30
000078d1a57d3c83  vmovaps xmm0, [rsp]
000078d1a57d3c88  vmovaps xmm2, [rsp+0x10]
000078d1a57d3c8e  vmovaps xmm3, [rsp+0x20]
000078d1a57d3c94  vmovaps xmm4, [rsp+0x30]
000078d1a57d3c9a  vmovaps xmm5, [rsp+0x40]
000078d1a57d3ca0  vmovaps xmm6, [rsp+0x50]
000078d1a57d3ca6  vmovaps xmm7, [rsp+0x60]
000078d1a57d3cac  vmovaps xmm8, [rsp+0x70]
000078d1a57d3cb2  vmovaps xmm9, [rsp+0x80]
000078d1a57d3cbb  vmovaps xmm10, [rsp+0x90]
000078d1a57d3cc4  vmovaps xmm11, [rsp+0xA0]
000078d1a57d3ccd  vmovaps xmm12, [rsp+0xB0]
000078d1a57d3cd6  vmovaps xmm13, [rsp+0xC0]
000078d1a57d3cdf  vmovaps xmm14, [rsp+0xD0]
000078d1a57d3ce8  vmovaps xmm15, [rsp+0xE0]
000078d1a57d3cf1  add rsp, 0xF0
000078d1a57d3cf8  pop r11
000078d1a57d3cfa  pop r10
000078d1a57d3cfc  pop r9
000078d1a57d3cfe  pop r8
000078d1a57d3d00  pop rsi
000078d1a57d3d01  pop rdi
000078d1a57d3d02  pop rdx
000078d1a57d3d03  pop rcx
000078d1a57d3d04  pop rax
000078d1a57d3d05  add rsp, 0x08
000078d1a57d3d09  jmp 0x000078D1A57D0015
000078d1a57d3d0e  sub rsp, 0x08
000078d1a57d3d12  push rax
000078d1a57d3d13  push rcx
000078d1a57d3d14  push rdx
000078d1a57d3d15  push rdi
000078d1a57d3d16  push rsi
000078d1a57d3d17  push r8
000078d1a57d3d19  push r9
000078d1a57d3d1b  push r10
000078d1a57d3d1d  push r11
000078d1a57d3d1f  sub rsp, 0xF0
000078d1a57d3d26  vmovaps [rsp], xmm0
000078d1a57d3d2b  vmovaps [rsp+0x10], xmm1
000078d1a57d3d31  vmovaps [rsp+0x20], xmm2
000078d1a57d3d37  vmovaps [rsp+0x30], xmm3
000078d1a57d3d3d  vmovaps [rsp+0x40], xmm4
000078d1a57d3d43  vmovaps [rsp+0x50], xmm5
000078d1a57d3d49  vmovaps [rsp+0x60], xmm6
000078d1a57d3d4f  vmovaps [rsp+0x70], xmm7
000078d1a57d3d55  vmovaps [rsp+0x80], xmm8
000078d1a57d3d5e  vmovaps [rsp+0x90], xmm9
000078d1a57d3d67  vmovaps [rsp+0xA0], xmm10
000078d1a57d3d70  vmovaps [rsp+0xB0], xmm12
000078d1a57d3d79  vmovaps [rsp+0xC0], xmm13
000078d1a57d3d82  vmovaps [rsp+0xD0], xmm14
000078d1a57d3d8b  vmovaps [rsp+0xE0], xmm15
000078d1a57d3d94  sub rsp, 0x30
000078d1a57d3d98  movaps [rsp], xmm11
000078d1a57d3d9d  movaps [rsp+0x10], xmm13
000078d1a57d3da3  movaps [rsp+0x20], xmm14
000078d1a57d3da9  lea rdi, [rsp]
000078d1a57d3dad  mov esi, 0x00
000078d1a57d3db2  mov rax, 0x56EA20A26530
000078d1a57d3dbc  call rax
000078d1a57d3dbe  movaps xmm11, [rsp]
000078d1a57d3dc3  add rsp, 0x30
000078d1a57d3dc7  vmovaps xmm0, [rsp]
000078d1a57d3dcc  vmovaps xmm1, [rsp+0x10]
000078d1a57d3dd2  vmovaps xmm2, [rsp+0x20]
000078d1a57d3dd8  vmovaps xmm3, [rsp+0x30]
000078d1a57d3dde  vmovaps xmm4, [rsp+0x40]
000078d1a57d3de4  vmovaps xmm5, [rsp+0x50]
000078d1a57d3dea  vmovaps xmm6, [rsp+0x60]
000078d1a57d3df0  vmovaps xmm7, [rsp+0x70]
000078d1a57d3df6  vmovaps xmm8, [rsp+0x80]
000078d1a57d3dff  vmovaps xmm9, [rsp+0x90]
000078d1a57d3e08  vmovaps xmm10, [rsp+0xA0]
000078d1a57d3e11  vmovaps xmm12, [rsp+0xB0]
000078d1a57d3e1a  vmovaps xmm13, [rsp+0xC0]
000078d1a57d3e23  vmovaps xmm14, [rsp+0xD0]
000078d1a57d3e2c  vmovaps xmm15, [rsp+0xE0]
000078d1a57d3e35  add rsp, 0xF0
000078d1a57d3e3c  pop r11
000078d1a57d3e3e  pop r10
000078d1a57d3e40  pop r9
000078d1a57d3e42  pop r8
000078d1a57d3e44  pop rsi
000078d1a57d3e45  pop rdi
000078d1a57d3e46  pop rdx
000078d1a57d3e47  pop rcx
000078d1a57d3e48  pop rax
000078d1a57d3e49  add rsp, 0x08
000078d1a57d3e4d  jmp 0x000078D1A57D003F
000078d1a57d3e52  sub rsp, 0x08
000078d1a57d3e56  push rax
000078d1a57d3e57  push rcx
000078d1a57d3e58  push rdx
000078d1a57d3e59  push rdi
000078d1a57d3e5a  push rsi
000078d1a57d3e5b  push r8
000078d1a57d3e5d  push r9
000078d1a57d3e5f  push r10
000078d1a57d3e61  push r11
000078d1a57d3e63  sub rsp, 0xF0
000078d1a57d3e6a  vmovaps [rsp], xmm0
000078d1a57d3e6f  vmovaps [rsp+0x10], xmm1
000078d1a57d3e75  vmovaps [rsp+0x20], xmm2
000078d1a57d3e7b  vmovaps [rsp+0x30], xmm3
000078d1a57d3e81  vmovaps [rsp+0x40], xmm4
000078d1a57d3e87  vmovaps [rsp+0x50], xmm5
000078d1a57d3e8d  vmovaps [rsp+0x60], xmm6
000078d1a57d3e93  vmovaps [rsp+0x70], xmm7
000078d1a57d3e99  vmovaps [rsp+0x80], xmm8
000078d1a57d3ea2  vmovaps [rsp+0x90], xmm9
000078d1a57d3eab  vmovaps [rsp+0xA0], xmm10
000078d1a57d3eb4  vmovaps [rsp+0xB0], xmm11
000078d1a57d3ebd  vmovaps [rsp+0xC0], xmm12
000078d1a57d3ec6  vmovaps [rsp+0xD0], xmm14
000078d1a57d3ecf  vmovaps [rsp+0xE0], xmm15
000078d1a57d3ed8  sub rsp, 0x30
000078d1a57d3edc  movaps [rsp], xmm13
000078d1a57d3ee1  movaps [rsp+0x10], xmm8
000078d1a57d3ee7  movaps [rsp+0x20], xmm14
000078d1a57d3eed  lea rdi, [rsp]
000078d1a57d3ef1  mov esi, 0x00
000078d1a57d3ef6  mov rax, 0x56EA20A26530
000078d1a57d3f00  call rax
000078d1a57d3f02  movaps xmm13, [rsp]
000078d1a57d3f07  add rsp, 0x30
000078d1a57d3f0b  vmovaps xmm0, [rsp]
000078d1a57d3f10  vmovaps xmm1, [rsp+0x10]
000078d1a57d3f16  vmovaps xmm2, [rsp+0x20]
000078d1a57d3f1c  vmovaps xmm3, [rsp+0x30]
000078d1a57d3f22  vmovaps xmm4, [rsp+0x40]
000078d1a57d3f28  vmovaps xmm5, [rsp+0x50]
000078d1a57d3f2e  vmovaps xmm6, [rsp+0x60]
000078d1a57d3f34  vmovaps xmm7, [rsp+0x70]
000078d1a57d3f3a  vmovaps xmm8, [rsp+0x80]
000078d1a57d3f43  vmovaps xmm9, [rsp+0x90]
000078d1a57d3f4c  vmovaps xmm10, [rsp+0xA0]
000078d1a57d3f55  vmovaps xmm11, [rsp+0xB0]
000078d1a57d3f5e  vmovaps xmm12, [rsp+0xC0]
000078d1a57d3f67  vmovaps xmm14, [rsp+0xD0]
000078d1a57d3f70  vmovaps xmm15, [rsp+0xE0]
000078d1a57d3f79  add rsp, 0xF0
000078d1a57d3f80  pop r11
000078d1a57d3f82  pop r10
000078d1a57d3f84  pop r9
000078d1a57d3f86  pop r8
000078d1a57d3f88  pop rsi
000078d1a57d3f89  pop rdi
000078d1a57d3f8a  pop rdx
000078d1a57d3f8b  pop rcx
000078d1a57d3f8c  pop rax
000078d1a57d3f8d  add rsp, 0x08
000078d1a57d3f91  jmp 0x000078D1A57D006E
000078d1a57d3f96  sub rsp, 0x08
000078d1a57d3f9a  push rax
000078d1a57d3f9b  push rcx
000078d1a57d3f9c  push rdx
000078d1a57d3f9d  push rdi
000078d1a57d3f9e  push rsi
000078d1a57d3f9f  push r8
000078d1a57d3fa1  push r9
000078d1a57d3fa3  push r10
000078d1a57d3fa5  push r11
000078d1a57d3fa7  sub rsp, 0xF0
000078d1a57d3fae  vmovaps [rsp], xmm0
000078d1a57d3fb3  vmovaps [rsp+0x10], xmm1
000078d1a57d3fb9  vmovaps [rsp+0x20], xmm2
000078d1a57d3fbf  vmovaps [rsp+0x30], xmm3
000078d1a57d3fc5  vmovaps [rsp+0x40], xmm4
000078d1a57d3fcb  vmovaps [rsp+0x50], xmm5
000078d1a57d3fd1  vmovaps [rsp+0x60], xmm6
000078d1a57d3fd7  vmovaps [rsp+0x70], xmm7
000078d1a57d3fdd  vmovaps [rsp+0x80], xmm9
000078d1a57d3fe6  vmovaps [rsp+0x90], xmm10
000078d1a57d3fef  vmovaps [rsp+0xA0], xmm11
000078d1a57d3ff8  vmovaps [rsp+0xB0], xmm12
000078d1a57d4001  vmovaps [rsp+0xC0], xmm13
000078d1a57d400a  vmovaps [rsp+0xD0], xmm14
000078d1a57d4013  vmovaps [rsp+0xE0], xmm15
000078d1a57d401c  sub rsp, 0x30
000078d1a57d4020  movaps [rsp], xmm8
000078d1a57d4025  movaps [rsp+0x10], xmm7
000078d1a57d402a  movaps [rsp+0x20], xmm14
000078d1a57d4030  lea rdi, [rsp]
000078d1a57d4034  mov esi, 0x00
000078d1a57d4039  mov rax, 0x56EA20A26530
000078d1a57d4043  call rax
000078d1a57d4045  movaps xmm8, [rsp]
000078d1a57d404a  add rsp, 0x30
000078d1a57d404e  vmovaps xmm0, [rsp]
000078d1a57d4053  vmovaps xmm1, [rsp+0x10]
000078d1a57d4059  vmovaps xmm2, [rsp+0x20]
000078d1a57d405f  vmovaps xmm3, [rsp+0x30]
000078d1a57d4065  vmovaps xmm4, [rsp+0x40]
000078d1a57d406b  vmovaps xmm5, [rsp+0x50]
000078d1a57d4071  vmovaps xmm6, [rsp+0x60]
000078d1a57d4077  vmovaps xmm7, [rsp+0x70]
000078d1a57d407d  vmovaps xmm9, [rsp+0x80]
000078d1a57d4086  vmovaps xmm10, [rsp+0x90]
000078d1a57d408f  vmovaps xmm11, [rsp+0xA0]
000078d1a57d4098  vmovaps xmm12, [rsp+0xB0]
000078d1a57d40a1  vmovaps xmm13, [rsp+0xC0]
000078d1a57d40aa  vmovaps xmm14, [rsp+0xD0]
000078d1a57d40b3  vmovaps xmm15, [rsp+0xE0]
000078d1a57d40bc  add rsp, 0xF0
000078d1a57d40c3  pop r11
000078d1a57d40c5  pop r10
000078d1a57d40c7  pop r9
000078d1a57d40c9  pop r8
000078d1a57d40cb  pop rsi
000078d1a57d40cc  pop rdi
000078d1a57d40cd  pop rdx
000078d1a57d40ce  pop rcx
000078d1a57d40cf  pop rax
000078d1a57d40d0  add rsp, 0x08
000078d1a57d40d4  jmp 0x000078D1A57D0094
000078d1a57d40d9  sub rsp, 0x08
000078d1a57d40dd  push rax
000078d1a57d40de  push rcx
000078d1a57d40df  push rdx
000078d1a57d40e0  push rdi
000078d1a57d40e1  push rsi
000078d1a57d40e2  push r8
000078d1a57d40e4  push r9
000078d1a57d40e6  push r10
000078d1a57d40e8  push r11
000078d1a57d40ea  sub rsp, 0xF0
000078d1a57d40f1  vmovaps [rsp], xmm0
000078d1a57d40f6  vmovaps [rsp+0x10], xmm1
000078d1a57d40fc  vmovaps [rsp+0x20], xmm2
000078d1a57d4102  vmovaps [rsp+0x30], xmm3
000078d1a57d4108  vmovaps [rsp+0x40], xmm4
000078d1a57d410e  vmovaps [rsp+0x50], xmm5
000078d1a57d4114  vmovaps [rsp+0x60], xmm6
000078d1a57d411a  vmovaps [rsp+0x70], xmm7
000078d1a57d4120  vmovaps [rsp+0x80], xmm8
000078d1a57d4129  vmovaps [rsp+0x90], xmm9
000078d1a57d4132  vmovaps [rsp+0xA0], xmm10
000078d1a57d413b  vmovaps [rsp+0xB0], xmm11
000078d1a57d4144  vmovaps [rsp+0xC0], xmm12
000078d1a57d414d  vmovaps [rsp+0xD0], xmm13
000078d1a57d4156  vmovaps [rsp+0xE0], xmm15
000078d1a57d415f  sub rsp, 0x30
000078d1a57d4163  movaps [rsp], xmm14
000078d1a57d4168  movaps [rsp+0x10], xmm12
000078d1a57d416e  movaps [rsp+0x20], xmm9
000078d1a57d4174  lea rdi, [rsp]
000078d1a57d4178  mov esi, 0x00
000078d1a57d417d  mov rax, 0x56EA20A26530
000078d1a57d4187  call rax
000078d1a57d4189  movaps xmm14, [rsp]
000078d1a57d418e  add rsp, 0x30
000078d1a57d4192  vmovaps xmm0, [rsp]
000078d1a57d4197  vmovaps xmm1, [rsp+0x10]
000078d1a57d419d  vmovaps xmm2, [rsp+0x20]
000078d1a57d41a3  vmovaps xmm3, [rsp+0x30]
000078d1a57d41a9  vmovaps xmm4, [rsp+0x40]
000078d1a57d41af  vmovaps xmm5, [rsp+0x50]
000078d1a57d41b5  vmovaps xmm6, [rsp+0x60]
000078d1a57d41bb  vmovaps xmm7, [rsp+0x70]
000078d1a57d41c1  vmovaps xmm8, [rsp+0x80]
000078d1a57d41ca  vmovaps xmm9, [rsp+0x90]
000078d1a57d41d3  vmovaps xmm10, [rsp+0xA0]
000078d1a57d41dc  vmovaps xmm11, [rsp+0xB0]
000078d1a57d41e5  vmovaps xmm12, [rsp+0xC0]
000078d1a57d41ee  vmovaps xmm13, [rsp+0xD0]
000078d1a57d41f7  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4200  add rsp, 0xF0
000078d1a57d4207  pop r11
000078d1a57d4209  pop r10
000078d1a57d420b  pop r9
000078d1a57d420d  pop r8
000078d1a57d420f  pop rsi
000078d1a57d4210  pop rdi
000078d1a57d4211  pop rdx
000078d1a57d4212  pop rcx
000078d1a57d4213  pop rax
000078d1a57d4214  add rsp, 0x08
000078d1a57d4218  jmp 0x000078D1A57D00AE
000078d1a57d421d  sub rsp, 0x08
000078d1a57d4221  push rax
000078d1a57d4222  push rcx
000078d1a57d4223  push rdx
000078d1a57d4224  push rdi
000078d1a57d4225  push rsi
000078d1a57d4226  push r8
000078d1a57d4228  push r9
000078d1a57d422a  push r10
000078d1a57d422c  push r11
000078d1a57d422e  sub rsp, 0xF0
000078d1a57d4235  vmovaps [rsp], xmm0
000078d1a57d423a  vmovaps [rsp+0x10], xmm1
000078d1a57d4240  vmovaps [rsp+0x20], xmm2
000078d1a57d4246  vmovaps [rsp+0x30], xmm3
000078d1a57d424c  vmovaps [rsp+0x40], xmm4
000078d1a57d4252  vmovaps [rsp+0x50], xmm5
000078d1a57d4258  vmovaps [rsp+0x60], xmm6
000078d1a57d425e  vmovaps [rsp+0x70], xmm7
000078d1a57d4264  vmovaps [rsp+0x80], xmm8
000078d1a57d426d  vmovaps [rsp+0x90], xmm10
000078d1a57d4276  vmovaps [rsp+0xA0], xmm11
000078d1a57d427f  vmovaps [rsp+0xB0], xmm12
000078d1a57d4288  vmovaps [rsp+0xC0], xmm13
000078d1a57d4291  vmovaps [rsp+0xD0], xmm14
000078d1a57d429a  vmovaps [rsp+0xE0], xmm15
000078d1a57d42a3  sub rsp, 0x30
000078d1a57d42a7  movaps [rsp], xmm9
000078d1a57d42ac  movaps [rsp+0x10], xmm7
000078d1a57d42b1  movaps [rsp+0x20], xmm12
000078d1a57d42b7  lea rdi, [rsp]
000078d1a57d42bb  mov esi, 0x00
000078d1a57d42c0  mov rax, 0x56EA20A26530
000078d1a57d42ca  call rax
000078d1a57d42cc  movaps xmm9, [rsp]
000078d1a57d42d1  add rsp, 0x30
000078d1a57d42d5  vmovaps xmm0, [rsp]
000078d1a57d42da  vmovaps xmm1, [rsp+0x10]
000078d1a57d42e0  vmovaps xmm2, [rsp+0x20]
000078d1a57d42e6  vmovaps xmm3, [rsp+0x30]
000078d1a57d42ec  vmovaps xmm4, [rsp+0x40]
000078d1a57d42f2  vmovaps xmm5, [rsp+0x50]
000078d1a57d42f8  vmovaps xmm6, [rsp+0x60]
000078d1a57d42fe  vmovaps xmm7, [rsp+0x70]
000078d1a57d4304  vmovaps xmm8, [rsp+0x80]
000078d1a57d430d  vmovaps xmm10, [rsp+0x90]
000078d1a57d4316  vmovaps xmm11, [rsp+0xA0]
000078d1a57d431f  vmovaps xmm12, [rsp+0xB0]
000078d1a57d4328  vmovaps xmm13, [rsp+0xC0]
000078d1a57d4331  vmovaps xmm14, [rsp+0xD0]
000078d1a57d433a  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4343  add rsp, 0xF0
000078d1a57d434a  pop r11
000078d1a57d434c  pop r10
000078d1a57d434e  pop r9
000078d1a57d4350  pop r8
000078d1a57d4352  pop rsi
000078d1a57d4353  pop rdi
000078d1a57d4354  pop rdx
000078d1a57d4355  pop rcx
000078d1a57d4356  pop rax
000078d1a57d4357  add rsp, 0x08
000078d1a57d435b  jmp 0x000078D1A57D00DD
000078d1a57d4360  sub rsp, 0x08
000078d1a57d4364  push rax
000078d1a57d4365  push rcx
000078d1a57d4366  push rdx
000078d1a57d4367  push rdi
000078d1a57d4368  push rsi
000078d1a57d4369  push r8
000078d1a57d436b  push r9
000078d1a57d436d  push r10
000078d1a57d436f  push r11
000078d1a57d4371  sub rsp, 0xF0
000078d1a57d4378  vmovaps [rsp], xmm0
000078d1a57d437d  vmovaps [rsp+0x10], xmm1
000078d1a57d4383  vmovaps [rsp+0x20], xmm2
000078d1a57d4389  vmovaps [rsp+0x30], xmm3
000078d1a57d438f  vmovaps [rsp+0x40], xmm4
000078d1a57d4395  vmovaps [rsp+0x50], xmm5
000078d1a57d439b  vmovaps [rsp+0x60], xmm6
000078d1a57d43a1  vmovaps [rsp+0x70], xmm7
000078d1a57d43a7  vmovaps [rsp+0x80], xmm8
000078d1a57d43b0  vmovaps [rsp+0x90], xmm9
000078d1a57d43b9  vmovaps [rsp+0xA0], xmm10
000078d1a57d43c2  vmovaps [rsp+0xB0], xmm11
000078d1a57d43cb  vmovaps [rsp+0xC0], xmm13
000078d1a57d43d4  vmovaps [rsp+0xD0], xmm14
000078d1a57d43dd  vmovaps [rsp+0xE0], xmm15
000078d1a57d43e6  sub rsp, 0x30
000078d1a57d43ea  movaps [rsp], xmm12
000078d1a57d43ef  movaps [rsp+0x10], xmm15
000078d1a57d43f5  movaps [rsp+0x20], xmm11
000078d1a57d43fb  lea rdi, [rsp]
000078d1a57d43ff  mov esi, 0x00
000078d1a57d4404  mov rax, 0x56EA20A26530
000078d1a57d440e  call rax
000078d1a57d4410  movaps xmm12, [rsp]
000078d1a57d4415  add rsp, 0x30
000078d1a57d4419  vmovaps xmm0, [rsp]
000078d1a57d441e  vmovaps xmm1, [rsp+0x10]
000078d1a57d4424  vmovaps xmm2, [rsp+0x20]
000078d1a57d442a  vmovaps xmm3, [rsp+0x30]
000078d1a57d4430  vmovaps xmm4, [rsp+0x40]
000078d1a57d4436  vmovaps xmm5, [rsp+0x50]
000078d1a57d443c  vmovaps xmm6, [rsp+0x60]
000078d1a57d4442  vmovaps xmm7, [rsp+0x70]
000078d1a57d4448  vmovaps xmm8, [rsp+0x80]
000078d1a57d4451  vmovaps xmm9, [rsp+0x90]
000078d1a57d445a  vmovaps xmm10, [rsp+0xA0]
000078d1a57d4463  vmovaps xmm11, [rsp+0xB0]
000078d1a57d446c  vmovaps xmm13, [rsp+0xC0]
000078d1a57d4475  vmovaps xmm14, [rsp+0xD0]
000078d1a57d447e  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4487  add rsp, 0xF0
000078d1a57d448e  pop r11
000078d1a57d4490  pop r10
000078d1a57d4492  pop r9
000078d1a57d4494  pop r8
000078d1a57d4496  pop rsi
000078d1a57d4497  pop rdi
000078d1a57d4498  pop rdx
000078d1a57d4499  pop rcx
000078d1a57d449a  pop rax
000078d1a57d449b  add rsp, 0x08
000078d1a57d449f  jmp 0x000078D1A57D00F7
000078d1a57d44a4  sub rsp, 0x08
000078d1a57d44a8  push rax
000078d1a57d44a9  push rcx
000078d1a57d44aa  push rdx
000078d1a57d44ab  push rdi
000078d1a57d44ac  push rsi
000078d1a57d44ad  push r8
000078d1a57d44af  push r9
000078d1a57d44b1  push r10
000078d1a57d44b3  push r11
000078d1a57d44b5  sub rsp, 0xF0
000078d1a57d44bc  vmovaps [rsp], xmm0
000078d1a57d44c1  vmovaps [rsp+0x10], xmm1
000078d1a57d44c7  vmovaps [rsp+0x20], xmm2
000078d1a57d44cd  vmovaps [rsp+0x30], xmm3
000078d1a57d44d3  vmovaps [rsp+0x40], xmm4
000078d1a57d44d9  vmovaps [rsp+0x50], xmm5
000078d1a57d44df  vmovaps [rsp+0x60], xmm6
000078d1a57d44e5  vmovaps [rsp+0x70], xmm7
000078d1a57d44eb  vmovaps [rsp+0x80], xmm8
000078d1a57d44f4  vmovaps [rsp+0x90], xmm9
000078d1a57d44fd  vmovaps [rsp+0xA0], xmm10
000078d1a57d4506  vmovaps [rsp+0xB0], xmm12
000078d1a57d450f  vmovaps [rsp+0xC0], xmm13
000078d1a57d4518  vmovaps [rsp+0xD0], xmm14
000078d1a57d4521  vmovaps [rsp+0xE0], xmm15
000078d1a57d452a  sub rsp, 0x30
000078d1a57d452e  movaps [rsp], xmm11
000078d1a57d4533  movaps [rsp+0x10], xmm7
000078d1a57d4538  movaps [rsp+0x20], xmm15
000078d1a57d453e  lea rdi, [rsp]
000078d1a57d4542  mov esi, 0x00
000078d1a57d4547  mov rax, 0x56EA20A26530
000078d1a57d4551  call rax
000078d1a57d4553  movaps xmm11, [rsp]
000078d1a57d4558  add rsp, 0x30
000078d1a57d455c  vmovaps xmm0, [rsp]
000078d1a57d4561  vmovaps xmm1, [rsp+0x10]
000078d1a57d4567  vmovaps xmm2, [rsp+0x20]
000078d1a57d456d  vmovaps xmm3, [rsp+0x30]
000078d1a57d4573  vmovaps xmm4, [rsp+0x40]
000078d1a57d4579  vmovaps xmm5, [rsp+0x50]
000078d1a57d457f  vmovaps xmm6, [rsp+0x60]
000078d1a57d4585  vmovaps xmm7, [rsp+0x70]
000078d1a57d458b  vmovaps xmm8, [rsp+0x80]
000078d1a57d4594  vmovaps xmm9, [rsp+0x90]
000078d1a57d459d  vmovaps xmm10, [rsp+0xA0]
000078d1a57d45a6  vmovaps xmm12, [rsp+0xB0]
000078d1a57d45af  vmovaps xmm13, [rsp+0xC0]
000078d1a57d45b8  vmovaps xmm14, [rsp+0xD0]
000078d1a57d45c1  vmovaps xmm15, [rsp+0xE0]
000078d1a57d45ca  add rsp, 0xF0
000078d1a57d45d1  pop r11
000078d1a57d45d3  pop r10
000078d1a57d45d5  pop r9
000078d1a57d45d7  pop r8
000078d1a57d45d9  pop rsi
000078d1a57d45da  pop rdi
000078d1a57d45db  pop rdx
000078d1a57d45dc  pop rcx
000078d1a57d45dd  pop rax
000078d1a57d45de  add rsp, 0x08
000078d1a57d45e2  jmp 0x000078D1A57D0123
000078d1a57d45e7  sub rsp, 0x08
000078d1a57d45eb  push rax
000078d1a57d45ec  push rcx
000078d1a57d45ed  push rdx
000078d1a57d45ee  push rdi
000078d1a57d45ef  push rsi
000078d1a57d45f0  push r8
000078d1a57d45f2  push r9
000078d1a57d45f4  push r10
000078d1a57d45f6  push r11
000078d1a57d45f8  sub rsp, 0xF0
000078d1a57d45ff  vmovaps [rsp], xmm0
000078d1a57d4604  vmovaps [rsp+0x10], xmm1
000078d1a57d460a  vmovaps [rsp+0x20], xmm2
000078d1a57d4610  vmovaps [rsp+0x30], xmm3
000078d1a57d4616  vmovaps [rsp+0x40], xmm4
000078d1a57d461c  vmovaps [rsp+0x50], xmm5
000078d1a57d4622  vmovaps [rsp+0x60], xmm6
000078d1a57d4628  vmovaps [rsp+0x70], xmm7
000078d1a57d462e  vmovaps [rsp+0x80], xmm8
000078d1a57d4637  vmovaps [rsp+0x90], xmm9
000078d1a57d4640  vmovaps [rsp+0xA0], xmm10
000078d1a57d4649  vmovaps [rsp+0xB0], xmm11
000078d1a57d4652  vmovaps [rsp+0xC0], xmm12
000078d1a57d465b  vmovaps [rsp+0xD0], xmm13
000078d1a57d4664  vmovaps [rsp+0xE0], xmm14
000078d1a57d466d  sub rsp, 0x30
000078d1a57d4671  movaps [rsp], xmm15
000078d1a57d4676  movaps [rsp+0x10], xmm10
000078d1a57d467c  movaps [rsp+0x20], xmm13
000078d1a57d4682  lea rdi, [rsp]
000078d1a57d4686  mov esi, 0x00
000078d1a57d468b  mov rax, 0x56EA20A26530
000078d1a57d4695  call rax
000078d1a57d4697  movaps xmm15, [rsp]
000078d1a57d469c  add rsp, 0x30
000078d1a57d46a0  vmovaps xmm0, [rsp]
000078d1a57d46a5  vmovaps xmm1, [rsp+0x10]
000078d1a57d46ab  vmovaps xmm2, [rsp+0x20]
000078d1a57d46b1  vmovaps xmm3, [rsp+0x30]
000078d1a57d46b7  vmovaps xmm4, [rsp+0x40]
000078d1a57d46bd  vmovaps xmm5, [rsp+0x50]
000078d1a57d46c3  vmovaps xmm6, [rsp+0x60]
000078d1a57d46c9  vmovaps xmm7, [rsp+0x70]
000078d1a57d46cf  vmovaps xmm8, [rsp+0x80]
000078d1a57d46d8  vmovaps xmm9, [rsp+0x90]
000078d1a57d46e1  vmovaps xmm10, [rsp+0xA0]
000078d1a57d46ea  vmovaps xmm11, [rsp+0xB0]
000078d1a57d46f3  vmovaps xmm12, [rsp+0xC0]
000078d1a57d46fc  vmovaps xmm13, [rsp+0xD0]
000078d1a57d4705  vmovaps xmm14, [rsp+0xE0]
000078d1a57d470e  add rsp, 0xF0
000078d1a57d4715  pop r11
000078d1a57d4717  pop r10
000078d1a57d4719  pop r9
000078d1a57d471b  pop r8
000078d1a57d471d  pop rsi
000078d1a57d471e  pop rdi
000078d1a57d471f  pop rdx
000078d1a57d4720  pop rcx
000078d1a57d4721  pop rax
000078d1a57d4722  add rsp, 0x08
000078d1a57d4726  jmp 0x000078D1A57D013D
000078d1a57d472b  sub rsp, 0x08
000078d1a57d472f  push rax
000078d1a57d4730  push rcx
000078d1a57d4731  push rdx
000078d1a57d4732  push rdi
000078d1a57d4733  push rsi
000078d1a57d4734  push r8
000078d1a57d4736  push r9
000078d1a57d4738  push r10
000078d1a57d473a  push r11
000078d1a57d473c  sub rsp, 0xF0
000078d1a57d4743  vmovaps [rsp], xmm0
000078d1a57d4748  vmovaps [rsp+0x10], xmm1
000078d1a57d474e  vmovaps [rsp+0x20], xmm2
000078d1a57d4754  vmovaps [rsp+0x30], xmm3
000078d1a57d475a  vmovaps [rsp+0x40], xmm4
000078d1a57d4760  vmovaps [rsp+0x50], xmm5
000078d1a57d4766  vmovaps [rsp+0x60], xmm6
000078d1a57d476c  vmovaps [rsp+0x70], xmm7
000078d1a57d4772  vmovaps [rsp+0x80], xmm8
000078d1a57d477b  vmovaps [rsp+0x90], xmm9
000078d1a57d4784  vmovaps [rsp+0xA0], xmm11
000078d1a57d478d  vmovaps [rsp+0xB0], xmm12
000078d1a57d4796  vmovaps [rsp+0xC0], xmm13
000078d1a57d479f  vmovaps [rsp+0xD0], xmm14
000078d1a57d47a8  vmovaps [rsp+0xE0], xmm15
000078d1a57d47b1  sub rsp, 0x30
000078d1a57d47b5  movaps [rsp], xmm10
000078d1a57d47ba  movaps [rsp+0x10], xmm7
000078d1a57d47bf  movaps [rsp+0x20], xmm13
000078d1a57d47c5  lea rdi, [rsp]
000078d1a57d47c9  mov esi, 0x00
000078d1a57d47ce  mov rax, 0x56EA20A26530
000078d1a57d47d8  call rax
000078d1a57d47da  movaps xmm10, [rsp]
000078d1a57d47df  add rsp, 0x30
000078d1a57d47e3  vmovaps xmm0, [rsp]
000078d1a57d47e8  vmovaps xmm1, [rsp+0x10]
000078d1a57d47ee  vmovaps xmm2, [rsp+0x20]
000078d1a57d47f4  vmovaps xmm3, [rsp+0x30]
000078d1a57d47fa  vmovaps xmm4, [rsp+0x40]
000078d1a57d4800  vmovaps xmm5, [rsp+0x50]
000078d1a57d4806  vmovaps xmm6, [rsp+0x60]
000078d1a57d480c  vmovaps xmm7, [rsp+0x70]
000078d1a57d4812  vmovaps xmm8, [rsp+0x80]
000078d1a57d481b  vmovaps xmm9, [rsp+0x90]
000078d1a57d4824  vmovaps xmm11, [rsp+0xA0]
000078d1a57d482d  vmovaps xmm12, [rsp+0xB0]
000078d1a57d4836  vmovaps xmm13, [rsp+0xC0]
000078d1a57d483f  vmovaps xmm14, [rsp+0xD0]
000078d1a57d4848  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4851  add rsp, 0xF0
000078d1a57d4858  pop r11
000078d1a57d485a  pop r10
000078d1a57d485c  pop r9
000078d1a57d485e  pop r8
000078d1a57d4860  pop rsi
000078d1a57d4861  pop rdi
000078d1a57d4862  pop rdx
000078d1a57d4863  pop rcx
000078d1a57d4864  pop rax
000078d1a57d4865  add rsp, 0x08
000078d1a57d4869  jmp 0x000078D1A57D0169
000078d1a57d486e  sub rsp, 0x08
000078d1a57d4872  push rax
000078d1a57d4873  push rcx
000078d1a57d4874  push rdx
000078d1a57d4875  push rdi
000078d1a57d4876  push rsi
000078d1a57d4877  push r8
000078d1a57d4879  push r9
000078d1a57d487b  push r10
000078d1a57d487d  push r11
000078d1a57d487f  sub rsp, 0xF0
000078d1a57d4886  vmovaps [rsp], xmm0
000078d1a57d488b  vmovaps [rsp+0x10], xmm1
000078d1a57d4891  vmovaps [rsp+0x20], xmm2
000078d1a57d4897  vmovaps [rsp+0x30], xmm3
000078d1a57d489d  vmovaps [rsp+0x40], xmm4
000078d1a57d48a3  vmovaps [rsp+0x50], xmm5
000078d1a57d48a9  vmovaps [rsp+0x60], xmm6
000078d1a57d48af  vmovaps [rsp+0x70], xmm7
000078d1a57d48b5  vmovaps [rsp+0x80], xmm8
000078d1a57d48be  vmovaps [rsp+0x90], xmm9
000078d1a57d48c7  vmovaps [rsp+0xA0], xmm10
000078d1a57d48d0  vmovaps [rsp+0xB0], xmm11
000078d1a57d48d9  vmovaps [rsp+0xC0], xmm12
000078d1a57d48e2  vmovaps [rsp+0xD0], xmm14
000078d1a57d48eb  vmovaps [rsp+0xE0], xmm15
000078d1a57d48f4  sub rsp, 0x30
000078d1a57d48f8  movaps [rsp], xmm13
000078d1a57d48fd  movaps [rsp+0x10], xmm1
000078d1a57d4902  movaps [rsp+0x20], xmm8
000078d1a57d4908  lea rdi, [rsp]
000078d1a57d490c  mov esi, 0x00
000078d1a57d4911  mov rax, 0x56EA20A26530
000078d1a57d491b  call rax
000078d1a57d491d  movaps xmm13, [rsp]
000078d1a57d4922  add rsp, 0x30
000078d1a57d4926  vmovaps xmm0, [rsp]
000078d1a57d492b  vmovaps xmm1, [rsp+0x10]
000078d1a57d4931  vmovaps xmm2, [rsp+0x20]
000078d1a57d4937  vmovaps xmm3, [rsp+0x30]
000078d1a57d493d  vmovaps xmm4, [rsp+0x40]
000078d1a57d4943  vmovaps xmm5, [rsp+0x50]
000078d1a57d4949  vmovaps xmm6, [rsp+0x60]
000078d1a57d494f  vmovaps xmm7, [rsp+0x70]
000078d1a57d4955  vmovaps xmm8, [rsp+0x80]
000078d1a57d495e  vmovaps xmm9, [rsp+0x90]
000078d1a57d4967  vmovaps xmm10, [rsp+0xA0]
000078d1a57d4970  vmovaps xmm11, [rsp+0xB0]
000078d1a57d4979  vmovaps xmm12, [rsp+0xC0]
000078d1a57d4982  vmovaps xmm14, [rsp+0xD0]
000078d1a57d498b  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4994  add rsp, 0xF0
000078d1a57d499b  pop r11
000078d1a57d499d  pop r10
000078d1a57d499f  pop r9
000078d1a57d49a1  pop r8
000078d1a57d49a3  pop rsi
000078d1a57d49a4  pop rdi
000078d1a57d49a5  pop rdx
000078d1a57d49a6  pop rcx
000078d1a57d49a7  pop rax
000078d1a57d49a8  add rsp, 0x08
000078d1a57d49ac  jmp 0x000078D1A57D0183
000078d1a57d49b1  call 0x000078D1A55FF430
000078d1a57d49b6  jmp 0x000078D1A57D018D
000078d1a57d49bb  sub rsp, 0x08
000078d1a57d49bf  push rax
000078d1a57d49c0  push rcx
000078d1a57d49c1  push rdx
000078d1a57d49c2  push rdi
000078d1a57d49c3  push rsi
000078d1a57d49c4  push r8
000078d1a57d49c6  push r9
000078d1a57d49c8  push r10
000078d1a57d49ca  push r11
000078d1a57d49cc  sub rsp, 0xF0
000078d1a57d49d3  vmovaps [rsp], xmm0
000078d1a57d49d8  vmovaps [rsp+0x10], xmm1
000078d1a57d49de  vmovaps [rsp+0x20], xmm2
000078d1a57d49e4  vmovaps [rsp+0x30], xmm3
000078d1a57d49ea  vmovaps [rsp+0x40], xmm4
000078d1a57d49f0  vmovaps [rsp+0x50], xmm5
000078d1a57d49f6  vmovaps [rsp+0x60], xmm6
000078d1a57d49fc  vmovaps [rsp+0x70], xmm7
000078d1a57d4a02  vmovaps [rsp+0x80], xmm9
000078d1a57d4a0b  vmovaps [rsp+0x90], xmm10
000078d1a57d4a14  vmovaps [rsp+0xA0], xmm11
000078d1a57d4a1d  vmovaps [rsp+0xB0], xmm12
000078d1a57d4a26  vmovaps [rsp+0xC0], xmm13
000078d1a57d4a2f  vmovaps [rsp+0xD0], xmm14
000078d1a57d4a38  vmovaps [rsp+0xE0], xmm15
000078d1a57d4a41  sub rsp, 0x30
000078d1a57d4a45  movaps [rsp], xmm8
000078d1a57d4a4a  movaps [rsp+0x10], xmm14
000078d1a57d4a50  movaps [rsp+0x20], xmm9
000078d1a57d4a56  lea rdi, [rsp]
000078d1a57d4a5a  mov esi, 0x00
000078d1a57d4a5f  mov rax, 0x56EA20A26530
000078d1a57d4a69  call rax
000078d1a57d4a6b  movaps xmm8, [rsp]
000078d1a57d4a70  add rsp, 0x30
000078d1a57d4a74  vmovaps xmm0, [rsp]
000078d1a57d4a79  vmovaps xmm1, [rsp+0x10]
000078d1a57d4a7f  vmovaps xmm2, [rsp+0x20]
000078d1a57d4a85  vmovaps xmm3, [rsp+0x30]
000078d1a57d4a8b  vmovaps xmm4, [rsp+0x40]
000078d1a57d4a91  vmovaps xmm5, [rsp+0x50]
000078d1a57d4a97  vmovaps xmm6, [rsp+0x60]
000078d1a57d4a9d  vmovaps xmm7, [rsp+0x70]
000078d1a57d4aa3  vmovaps xmm9, [rsp+0x80]
000078d1a57d4aac  vmovaps xmm10, [rsp+0x90]
000078d1a57d4ab5  vmovaps xmm11, [rsp+0xA0]
000078d1a57d4abe  vmovaps xmm12, [rsp+0xB0]
000078d1a57d4ac7  vmovaps xmm13, [rsp+0xC0]
000078d1a57d4ad0  vmovaps xmm14, [rsp+0xD0]
000078d1a57d4ad9  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4ae2  add rsp, 0xF0
000078d1a57d4ae9  pop r11
000078d1a57d4aeb  pop r10
000078d1a57d4aed  pop r9
000078d1a57d4aef  pop r8
000078d1a57d4af1  pop rsi
000078d1a57d4af2  pop rdi
000078d1a57d4af3  pop rdx
000078d1a57d4af4  pop rcx
000078d1a57d4af5  pop rax
000078d1a57d4af6  add rsp, 0x08
000078d1a57d4afa  jmp 0x000078D1A57D01AF
000078d1a57d4aff  sub rsp, 0x08
000078d1a57d4b03  push rax
000078d1a57d4b04  push rcx
000078d1a57d4b05  push rdx
000078d1a57d4b06  push rdi
000078d1a57d4b07  push rsi
000078d1a57d4b08  push r8
000078d1a57d4b0a  push r9
000078d1a57d4b0c  push r10
000078d1a57d4b0e  push r11
000078d1a57d4b10  sub rsp, 0xF0
000078d1a57d4b17  vmovaps [rsp], xmm0
000078d1a57d4b1c  vmovaps [rsp+0x10], xmm1
000078d1a57d4b22  vmovaps [rsp+0x20], xmm2
000078d1a57d4b28  vmovaps [rsp+0x30], xmm3
000078d1a57d4b2e  vmovaps [rsp+0x40], xmm4
000078d1a57d4b34  vmovaps [rsp+0x50], xmm5
000078d1a57d4b3a  vmovaps [rsp+0x60], xmm6
000078d1a57d4b40  vmovaps [rsp+0x70], xmm7
000078d1a57d4b46  vmovaps [rsp+0x80], xmm8
000078d1a57d4b4f  vmovaps [rsp+0x90], xmm10
000078d1a57d4b58  vmovaps [rsp+0xA0], xmm11
000078d1a57d4b61  vmovaps [rsp+0xB0], xmm12
000078d1a57d4b6a  vmovaps [rsp+0xC0], xmm13
000078d1a57d4b73  vmovaps [rsp+0xD0], xmm14
000078d1a57d4b7c  vmovaps [rsp+0xE0], xmm15
000078d1a57d4b85  sub rsp, 0x30
000078d1a57d4b89  movaps [rsp], xmm9
000078d1a57d4b8e  movaps [rsp+0x10], xmm1
000078d1a57d4b93  movaps [rsp+0x20], xmm14
000078d1a57d4b99  lea rdi, [rsp]
000078d1a57d4b9d  mov esi, 0x00
000078d1a57d4ba2  mov rax, 0x56EA20A26530
000078d1a57d4bac  call rax
000078d1a57d4bae  movaps xmm9, [rsp]
000078d1a57d4bb3  add rsp, 0x30
000078d1a57d4bb7  vmovaps xmm0, [rsp]
000078d1a57d4bbc  vmovaps xmm1, [rsp+0x10]
000078d1a57d4bc2  vmovaps xmm2, [rsp+0x20]
000078d1a57d4bc8  vmovaps xmm3, [rsp+0x30]
000078d1a57d4bce  vmovaps xmm4, [rsp+0x40]
000078d1a57d4bd4  vmovaps xmm5, [rsp+0x50]
000078d1a57d4bda  vmovaps xmm6, [rsp+0x60]
000078d1a57d4be0  vmovaps xmm7, [rsp+0x70]
000078d1a57d4be6  vmovaps xmm8, [rsp+0x80]
000078d1a57d4bef  vmovaps xmm10, [rsp+0x90]
000078d1a57d4bf8  vmovaps xmm11, [rsp+0xA0]
000078d1a57d4c01  vmovaps xmm12, [rsp+0xB0]
000078d1a57d4c0a  vmovaps xmm13, [rsp+0xC0]
000078d1a57d4c13  vmovaps xmm14, [rsp+0xD0]
000078d1a57d4c1c  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4c25  add rsp, 0xF0
000078d1a57d4c2c  pop r11
000078d1a57d4c2e  pop r10
000078d1a57d4c30  pop r9
000078d1a57d4c32  pop r8
000078d1a57d4c34  pop rsi
000078d1a57d4c35  pop rdi
000078d1a57d4c36  pop rdx
000078d1a57d4c37  pop rcx
000078d1a57d4c38  pop rax
000078d1a57d4c39  add rsp, 0x08
000078d1a57d4c3d  jmp 0x000078D1A57D01DD
000078d1a57d4c42  sub rsp, 0x08
000078d1a57d4c46  push rax
000078d1a57d4c47  push rcx
000078d1a57d4c48  push rdx
000078d1a57d4c49  push rdi
000078d1a57d4c4a  push rsi
000078d1a57d4c4b  push r8
000078d1a57d4c4d  push r9
000078d1a57d4c4f  push r10
000078d1a57d4c51  push r11
000078d1a57d4c53  sub rsp, 0xF0
000078d1a57d4c5a  vmovaps [rsp], xmm0
000078d1a57d4c5f  vmovaps [rsp+0x10], xmm1
000078d1a57d4c65  vmovaps [rsp+0x20], xmm2
000078d1a57d4c6b  vmovaps [rsp+0x30], xmm3
000078d1a57d4c71  vmovaps [rsp+0x40], xmm4
000078d1a57d4c77  vmovaps [rsp+0x50], xmm5
000078d1a57d4c7d  vmovaps [rsp+0x60], xmm6
000078d1a57d4c83  vmovaps [rsp+0x70], xmm7
000078d1a57d4c89  vmovaps [rsp+0x80], xmm8
000078d1a57d4c92  vmovaps [rsp+0x90], xmm9
000078d1a57d4c9b  vmovaps [rsp+0xA0], xmm10
000078d1a57d4ca4  vmovaps [rsp+0xB0], xmm11
000078d1a57d4cad  vmovaps [rsp+0xC0], xmm12
000078d1a57d4cb6  vmovaps [rsp+0xD0], xmm13
000078d1a57d4cbf  vmovaps [rsp+0xE0], xmm15
000078d1a57d4cc8  sub rsp, 0x30
000078d1a57d4ccc  movaps [rsp], xmm14
000078d1a57d4cd1  movaps [rsp+0x10], xmm4
000078d1a57d4cd6  movaps [rsp+0x20], xmm1
000078d1a57d4cdb  lea rdi, [rsp]
000078d1a57d4cdf  mov esi, 0x00
000078d1a57d4ce4  mov rax, 0x56EA20A26530
000078d1a57d4cee  call rax
000078d1a57d4cf0  movaps xmm14, [rsp]
000078d1a57d4cf5  add rsp, 0x30
000078d1a57d4cf9  vmovaps xmm0, [rsp]
000078d1a57d4cfe  vmovaps xmm1, [rsp+0x10]
000078d1a57d4d04  vmovaps xmm2, [rsp+0x20]
000078d1a57d4d0a  vmovaps xmm3, [rsp+0x30]
000078d1a57d4d10  vmovaps xmm4, [rsp+0x40]
000078d1a57d4d16  vmovaps xmm5, [rsp+0x50]
000078d1a57d4d1c  vmovaps xmm6, [rsp+0x60]
000078d1a57d4d22  vmovaps xmm7, [rsp+0x70]
000078d1a57d4d28  vmovaps xmm8, [rsp+0x80]
000078d1a57d4d31  vmovaps xmm9, [rsp+0x90]
000078d1a57d4d3a  vmovaps xmm10, [rsp+0xA0]
000078d1a57d4d43  vmovaps xmm11, [rsp+0xB0]
000078d1a57d4d4c  vmovaps xmm12, [rsp+0xC0]
000078d1a57d4d55  vmovaps xmm13, [rsp+0xD0]
000078d1a57d4d5e  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4d67  add rsp, 0xF0
000078d1a57d4d6e  pop r11
000078d1a57d4d70  pop r10
000078d1a57d4d72  pop r9
000078d1a57d4d74  pop r8
000078d1a57d4d76  pop rsi
000078d1a57d4d77  pop rdi
000078d1a57d4d78  pop rdx
000078d1a57d4d79  pop rcx
000078d1a57d4d7a  pop rax
000078d1a57d4d7b  add rsp, 0x08
000078d1a57d4d7f  jmp 0x000078D1A57D0203
000078d1a57d4d84  sub rsp, 0x08
000078d1a57d4d88  push rax
000078d1a57d4d89  push rcx
000078d1a57d4d8a  push rdx
000078d1a57d4d8b  push rdi
000078d1a57d4d8c  push rsi
000078d1a57d4d8d  push r8
000078d1a57d4d8f  push r9
000078d1a57d4d91  push r10
000078d1a57d4d93  push r11
000078d1a57d4d95  sub rsp, 0xF0
000078d1a57d4d9c  vmovaps [rsp], xmm0
000078d1a57d4da1  vmovaps [rsp+0x10], xmm2
000078d1a57d4da7  vmovaps [rsp+0x20], xmm3
000078d1a57d4dad  vmovaps [rsp+0x30], xmm4
000078d1a57d4db3  vmovaps [rsp+0x40], xmm5
000078d1a57d4db9  vmovaps [rsp+0x50], xmm6
000078d1a57d4dbf  vmovaps [rsp+0x60], xmm7
000078d1a57d4dc5  vmovaps [rsp+0x70], xmm8
000078d1a57d4dcb  vmovaps [rsp+0x80], xmm9
000078d1a57d4dd4  vmovaps [rsp+0x90], xmm10
000078d1a57d4ddd  vmovaps [rsp+0xA0], xmm11
000078d1a57d4de6  vmovaps [rsp+0xB0], xmm12
000078d1a57d4def  vmovaps [rsp+0xC0], xmm13
000078d1a57d4df8  vmovaps [rsp+0xD0], xmm14
000078d1a57d4e01  vmovaps [rsp+0xE0], xmm15
000078d1a57d4e0a  sub rsp, 0x30
000078d1a57d4e0e  movaps [rsp], xmm1
000078d1a57d4e12  movaps [rsp+0x10], xmm12
000078d1a57d4e18  movaps [rsp+0x20], xmm11
000078d1a57d4e1e  lea rdi, [rsp]
000078d1a57d4e22  mov esi, 0x00
000078d1a57d4e27  mov rax, 0x56EA20A26530
000078d1a57d4e31  call rax
000078d1a57d4e33  movaps xmm1, [rsp]
000078d1a57d4e37  add rsp, 0x30
000078d1a57d4e3b  vmovaps xmm0, [rsp]
000078d1a57d4e40  vmovaps xmm2, [rsp+0x10]
000078d1a57d4e46  vmovaps xmm3, [rsp+0x20]
000078d1a57d4e4c  vmovaps xmm4, [rsp+0x30]
000078d1a57d4e52  vmovaps xmm5, [rsp+0x40]
000078d1a57d4e58  vmovaps xmm6, [rsp+0x50]
000078d1a57d4e5e  vmovaps xmm7, [rsp+0x60]
000078d1a57d4e64  vmovaps xmm8, [rsp+0x70]
000078d1a57d4e6a  vmovaps xmm9, [rsp+0x80]
000078d1a57d4e73  vmovaps xmm10, [rsp+0x90]
000078d1a57d4e7c  vmovaps xmm11, [rsp+0xA0]
000078d1a57d4e85  vmovaps xmm12, [rsp+0xB0]
000078d1a57d4e8e  vmovaps xmm13, [rsp+0xC0]
000078d1a57d4e97  vmovaps xmm14, [rsp+0xD0]
000078d1a57d4ea0  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4ea9  add rsp, 0xF0
000078d1a57d4eb0  pop r11
000078d1a57d4eb2  pop r10
000078d1a57d4eb4  pop r9
000078d1a57d4eb6  pop r8
000078d1a57d4eb8  pop rsi
000078d1a57d4eb9  pop rdi
000078d1a57d4eba  pop rdx
000078d1a57d4ebb  pop rcx
000078d1a57d4ebc  pop rax
000078d1a57d4ebd  add rsp, 0x08
000078d1a57d4ec1  jmp 0x000078D1A57D0224
000078d1a57d4ec6  call 0x000078D1A56E20A0
000078d1a57d4ecb  jmp 0x000078D1A57D0232
000078d1a57d4ed0  call 0x000078D1A5609D70
000078d1a57d4ed5  jmp 0x000078D1A57D023C
000078d1a57d4eda  sub rsp, 0x08
000078d1a57d4ede  push rax
000078d1a57d4edf  push rcx
000078d1a57d4ee0  push rdx
000078d1a57d4ee1  push rdi
000078d1a57d4ee2  push rsi
000078d1a57d4ee3  push r8
000078d1a57d4ee5  push r9
000078d1a57d4ee7  push r10
000078d1a57d4ee9  push r11
000078d1a57d4eeb  sub rsp, 0xF0
000078d1a57d4ef2  vmovaps [rsp], xmm0
000078d1a57d4ef7  vmovaps [rsp+0x10], xmm1
000078d1a57d4efd  vmovaps [rsp+0x20], xmm2
000078d1a57d4f03  vmovaps [rsp+0x30], xmm3
000078d1a57d4f09  vmovaps [rsp+0x40], xmm4
000078d1a57d4f0f  vmovaps [rsp+0x50], xmm5
000078d1a57d4f15  vmovaps [rsp+0x60], xmm6
000078d1a57d4f1b  vmovaps [rsp+0x70], xmm8
000078d1a57d4f21  vmovaps [rsp+0x80], xmm9
000078d1a57d4f2a  vmovaps [rsp+0x90], xmm10
000078d1a57d4f33  vmovaps [rsp+0xA0], xmm11
000078d1a57d4f3c  vmovaps [rsp+0xB0], xmm12
000078d1a57d4f45  vmovaps [rsp+0xC0], xmm13
000078d1a57d4f4e  vmovaps [rsp+0xD0], xmm14
000078d1a57d4f57  vmovaps [rsp+0xE0], xmm15
000078d1a57d4f60  sub rsp, 0x30
000078d1a57d4f64  movaps [rsp], xmm7
000078d1a57d4f68  movaps [rsp+0x10], xmm15
000078d1a57d4f6e  movaps [rsp+0x20], xmm10
000078d1a57d4f74  lea rdi, [rsp]
000078d1a57d4f78  mov esi, 0x00
000078d1a57d4f7d  mov rax, 0x56EA20A26530
000078d1a57d4f87  call rax
000078d1a57d4f89  movaps xmm7, [rsp]
000078d1a57d4f8d  add rsp, 0x30
000078d1a57d4f91  vmovaps xmm0, [rsp]
000078d1a57d4f96  vmovaps xmm1, [rsp+0x10]
000078d1a57d4f9c  vmovaps xmm2, [rsp+0x20]
000078d1a57d4fa2  vmovaps xmm3, [rsp+0x30]
000078d1a57d4fa8  vmovaps xmm4, [rsp+0x40]
000078d1a57d4fae  vmovaps xmm5, [rsp+0x50]
000078d1a57d4fb4  vmovaps xmm6, [rsp+0x60]
000078d1a57d4fba  vmovaps xmm8, [rsp+0x70]
000078d1a57d4fc0  vmovaps xmm9, [rsp+0x80]
000078d1a57d4fc9  vmovaps xmm10, [rsp+0x90]
000078d1a57d4fd2  vmovaps xmm11, [rsp+0xA0]
000078d1a57d4fdb  vmovaps xmm12, [rsp+0xB0]
000078d1a57d4fe4  vmovaps xmm13, [rsp+0xC0]
000078d1a57d4fed  vmovaps xmm14, [rsp+0xD0]
000078d1a57d4ff6  vmovaps xmm15, [rsp+0xE0]
000078d1a57d4fff  add rsp, 0xF0
000078d1a57d5006  pop r11
000078d1a57d5008  pop r10
000078d1a57d500a  pop r9
000078d1a57d500c  pop r8
000078d1a57d500e  pop rsi
000078d1a57d500f  pop rdi
000078d1a57d5010  pop rdx
000078d1a57d5011  pop rcx
000078d1a57d5012  pop rax
000078d1a57d5013  add rsp, 0x08
000078d1a57d5017  jmp 0x000078D1A57D025D
000078d1a57d501c  sub rsp, 0x08
000078d1a57d5020  push rax
000078d1a57d5021  push rcx
000078d1a57d5022  push rdx
000078d1a57d5023  push rdi
000078d1a57d5024  push rsi
000078d1a57d5025  push r8
000078d1a57d5027  push r9
000078d1a57d5029  push r10
000078d1a57d502b  push r11
000078d1a57d502d  sub rsp, 0xF0
000078d1a57d5034  vmovaps [rsp], xmm0
000078d1a57d5039  vmovaps [rsp+0x10], xmm1
000078d1a57d503f  vmovaps [rsp+0x20], xmm2
000078d1a57d5045  vmovaps [rsp+0x30], xmm3
000078d1a57d504b  vmovaps [rsp+0x40], xmm4
000078d1a57d5051  vmovaps [rsp+0x50], xmm5
000078d1a57d5057  vmovaps [rsp+0x60], xmm6
000078d1a57d505d  vmovaps [rsp+0x70], xmm7
000078d1a57d5063  vmovaps [rsp+0x80], xmm8
000078d1a57d506c  vmovaps [rsp+0x90], xmm9
000078d1a57d5075  vmovaps [rsp+0xA0], xmm11
000078d1a57d507e  vmovaps [rsp+0xB0], xmm12
000078d1a57d5087  vmovaps [rsp+0xC0], xmm13
000078d1a57d5090  vmovaps [rsp+0xD0], xmm14
000078d1a57d5099  vmovaps [rsp+0xE0], xmm15
000078d1a57d50a2  sub rsp, 0x30
000078d1a57d50a6  movaps [rsp], xmm10
000078d1a57d50ab  movaps [rsp+0x10], xmm11
000078d1a57d50b1  movaps [rsp+0x20], xmm15
000078d1a57d50b7  lea rdi, [rsp]
000078d1a57d50bb  mov esi, 0x00
000078d1a57d50c0  mov rax, 0x56EA20A26530
000078d1a57d50ca  call rax
000078d1a57d50cc  movaps xmm10, [rsp]
000078d1a57d50d1  add rsp, 0x30
000078d1a57d50d5  vmovaps xmm0, [rsp]
000078d1a57d50da  vmovaps xmm1, [rsp+0x10]
000078d1a57d50e0  vmovaps xmm2, [rsp+0x20]
000078d1a57d50e6  vmovaps xmm3, [rsp+0x30]
000078d1a57d50ec  vmovaps xmm4, [rsp+0x40]
000078d1a57d50f2  vmovaps xmm5, [rsp+0x50]
000078d1a57d50f8  vmovaps xmm6, [rsp+0x60]
000078d1a57d50fe  vmovaps xmm7, [rsp+0x70]
000078d1a57d5104  vmovaps xmm8, [rsp+0x80]
000078d1a57d510d  vmovaps xmm9, [rsp+0x90]
000078d1a57d5116  vmovaps xmm11, [rsp+0xA0]
000078d1a57d511f  vmovaps xmm12, [rsp+0xB0]
000078d1a57d5128  vmovaps xmm13, [rsp+0xC0]
000078d1a57d5131  vmovaps xmm14, [rsp+0xD0]
000078d1a57d513a  vmovaps xmm15, [rsp+0xE0]
000078d1a57d5143  add rsp, 0xF0
000078d1a57d514a  pop r11
000078d1a57d514c  pop r10
000078d1a57d514e  pop r9
000078d1a57d5150  pop r8
000078d1a57d5152  pop rsi
000078d1a57d5153  pop rdi
000078d1a57d5154  pop rdx
000078d1a57d5155  pop rcx
000078d1a57d5156  pop rax
000078d1a57d5157  add rsp, 0x08
000078d1a57d515b  jmp 0x000078D1A57D028B
000078d1a57d5160  sub rsp, 0x08
000078d1a57d5164  push rax
000078d1a57d5165  push rcx
000078d1a57d5166  push rdx
000078d1a57d5167  push rdi
000078d1a57d5168  push rsi
000078d1a57d5169  push r8
000078d1a57d516b  push r9
000078d1a57d516d  push r10
000078d1a57d516f  push r11
000078d1a57d5171  sub rsp, 0xF0
000078d1a57d5178  vmovaps [rsp], xmm0
000078d1a57d517d  vmovaps [rsp+0x10], xmm1
000078d1a57d5183  vmovaps [rsp+0x20], xmm2
000078d1a57d5189  vmovaps [rsp+0x30], xmm3
000078d1a57d518f  vmovaps [rsp+0x40], xmm4
000078d1a57d5195  vmovaps [rsp+0x50], xmm5
000078d1a57d519b  vmovaps [rsp+0x60], xmm6
000078d1a57d51a1  vmovaps [rsp+0x70], xmm7
000078d1a57d51a7  vmovaps [rsp+0x80], xmm8
000078d1a57d51b0  vmovaps [rsp+0x90], xmm9
000078d1a57d51b9  vmovaps [rsp+0xA0], xmm10
000078d1a57d51c2  vmovaps [rsp+0xB0], xmm12
000078d1a57d51cb  vmovaps [rsp+0xC0], xmm13
000078d1a57d51d4  vmovaps [rsp+0xD0], xmm14
000078d1a57d51dd  vmovaps [rsp+0xE0], xmm15
000078d1a57d51e6  sub rsp, 0x30
000078d1a57d51ea  movaps [rsp], xmm11
000078d1a57d51ef  movaps [rsp+0x10], xmm12
000078d1a57d51f5  movaps [rsp+0x20], xmm15
000078d1a57d51fb  lea rdi, [rsp]
000078d1a57d51ff  mov esi, 0x00
000078d1a57d5204  mov rax, 0x56EA20A26530
000078d1a57d520e  call rax
000078d1a57d5210  movaps xmm11, [rsp]
000078d1a57d5215  add rsp, 0x30
000078d1a57d5219  vmovaps xmm0, [rsp]
000078d1a57d521e  vmovaps xmm1, [rsp+0x10]
000078d1a57d5224  vmovaps xmm2, [rsp+0x20]
000078d1a57d522a  vmovaps xmm3, [rsp+0x30]
000078d1a57d5230  vmovaps xmm4, [rsp+0x40]
000078d1a57d5236  vmovaps xmm5, [rsp+0x50]
000078d1a57d523c  vmovaps xmm6, [rsp+0x60]
000078d1a57d5242  vmovaps xmm7, [rsp+0x70]
000078d1a57d5248  vmovaps xmm8, [rsp+0x80]
000078d1a57d5251  vmovaps xmm9, [rsp+0x90]
000078d1a57d525a  vmovaps xmm10, [rsp+0xA0]
000078d1a57d5263  vmovaps xmm12, [rsp+0xB0]
000078d1a57d526c  vmovaps xmm13, [rsp+0xC0]
000078d1a57d5275  vmovaps xmm14, [rsp+0xD0]
000078d1a57d527e  vmovaps xmm15, [rsp+0xE0]
000078d1a57d5287  add rsp, 0xF0
000078d1a57d528e  pop r11
000078d1a57d5290  pop r10
000078d1a57d5292  pop r9
000078d1a57d5294  pop r8
000078d1a57d5296  pop rsi
000078d1a57d5297  pop rdi
000078d1a57d5298  pop rdx
000078d1a57d5299  pop rcx
000078d1a57d529a  pop rax
000078d1a57d529b  add rsp, 0x08
000078d1a57d529f  jmp 0x000078D1A57D02B9
000078d1a57d52a4  sub rsp, 0x08
000078d1a57d52a8  push rax
000078d1a57d52a9  push rcx
000078d1a57d52aa  push rdx
000078d1a57d52ab  push rdi
000078d1a57d52ac  push rsi
000078d1a57d52ad  push r8
000078d1a57d52af  push r9
000078d1a57d52b1  push r10
000078d1a57d52b3  push r11
000078d1a57d52b5  sub rsp, 0xF0
000078d1a57d52bc  vmovaps [rsp], xmm0
000078d1a57d52c1  vmovaps [rsp+0x10], xmm1
000078d1a57d52c7  vmovaps [rsp+0x20], xmm2
000078d1a57d52cd  vmovaps [rsp+0x30], xmm3
000078d1a57d52d3  vmovaps [rsp+0x40], xmm4
000078d1a57d52d9  vmovaps [rsp+0x50], xmm5
000078d1a57d52df  vmovaps [rsp+0x60], xmm6
000078d1a57d52e5  vmovaps [rsp+0x70], xmm7
000078d1a57d52eb  vmovaps [rsp+0x80], xmm8
000078d1a57d52f4  vmovaps [rsp+0x90], xmm9
000078d1a57d52fd  vmovaps [rsp+0xA0], xmm10
000078d1a57d5306  vmovaps [rsp+0xB0], xmm11
000078d1a57d530f  vmovaps [rsp+0xC0], xmm12
000078d1a57d5318  vmovaps [rsp+0xD0], xmm13
000078d1a57d5321  vmovaps [rsp+0xE0], xmm14
000078d1a57d532a  sub rsp, 0x30
000078d1a57d532e  movaps [rsp], xmm15
000078d1a57d5333  movaps [rsp+0x10], xmm13
000078d1a57d5339  movaps [rsp+0x20], xmm9
000078d1a57d533f  lea rdi, [rsp]
000078d1a57d5343  mov esi, 0x00
000078d1a57d5348  mov rax, 0x56EA20A26530
000078d1a57d5352  call rax
000078d1a57d5354  movaps xmm15, [rsp]
000078d1a57d5359  add rsp, 0x30
000078d1a57d535d  vmovaps xmm0, [rsp]
000078d1a57d5362  vmovaps xmm1, [rsp+0x10]
000078d1a57d5368  vmovaps xmm2, [rsp+0x20]
000078d1a57d536e  vmovaps xmm3, [rsp+0x30]
000078d1a57d5374  vmovaps xmm4, [rsp+0x40]
000078d1a57d537a  vmovaps xmm5, [rsp+0x50]
000078d1a57d5380  vmovaps xmm6, [rsp+0x60]
000078d1a57d5386  vmovaps xmm7, [rsp+0x70]
000078d1a57d538c  vmovaps xmm8, [rsp+0x80]
000078d1a57d5395  vmovaps xmm9, [rsp+0x90]
000078d1a57d539e  vmovaps xmm10, [rsp+0xA0]
000078d1a57d53a7  vmovaps xmm11, [rsp+0xB0]
000078d1a57d53b0  vmovaps xmm12, [rsp+0xC0]
000078d1a57d53b9  vmovaps xmm13, [rsp+0xD0]
000078d1a57d53c2  vmovaps xmm14, [rsp+0xE0]
000078d1a57d53cb  add rsp, 0xF0
000078d1a57d53d2  pop r11
000078d1a57d53d4  pop r10
000078d1a57d53d6  pop r9
000078d1a57d53d8  pop r8
000078d1a57d53da  pop rsi
000078d1a57d53db  pop rdi
000078d1a57d53dc  pop rdx
000078d1a57d53dd  pop rcx
000078d1a57d53de  pop rax
000078d1a57d53df  add rsp, 0x08
000078d1a57d53e3  jmp 0x000078D1A57D02D4
000078d1a57d53e8  sub rsp, 0x08
000078d1a57d53ec  push rax
000078d1a57d53ed  push rcx
000078d1a57d53ee  push rdx
000078d1a57d53ef  push rdi
000078d1a57d53f0  push rsi
000078d1a57d53f1  push r8
000078d1a57d53f3  push r9
000078d1a57d53f5  push r10
000078d1a57d53f7  push r11
000078d1a57d53f9  sub rsp, 0xF0
000078d1a57d5400  vmovaps [rsp], xmm0
000078d1a57d5405  vmovaps [rsp+0x10], xmm1
000078d1a57d540b  vmovaps [rsp+0x20], xmm2
000078d1a57d5411  vmovaps [rsp+0x30], xmm3
000078d1a57d5417  vmovaps [rsp+0x40], xmm4
000078d1a57d541d  vmovaps [rsp+0x50], xmm5
000078d1a57d5423  vmovaps [rsp+0x60], xmm6
000078d1a57d5429  vmovaps [rsp+0x70], xmm7
000078d1a57d542f  vmovaps [rsp+0x80], xmm8
000078d1a57d5438  vmovaps [rsp+0x90], xmm9
000078d1a57d5441  vmovaps [rsp+0xA0], xmm10
000078d1a57d544a  vmovaps [rsp+0xB0], xmm11
000078d1a57d5453  vmovaps [rsp+0xC0], xmm12
000078d1a57d545c  vmovaps [rsp+0xD0], xmm14
000078d1a57d5465  vmovaps [rsp+0xE0], xmm15
000078d1a57d546e  sub rsp, 0x30
000078d1a57d5472  movaps [rsp], xmm13
000078d1a57d5477  movaps [rsp+0x10], xmm8
000078d1a57d547d  movaps [rsp+0x20], xmm14
000078d1a57d5483  lea rdi, [rsp]
000078d1a57d5487  mov esi, 0x00
000078d1a57d548c  mov rax, 0x56EA20A26530
000078d1a57d5496  call rax
000078d1a57d5498  movaps xmm13, [rsp]
000078d1a57d549d  add rsp, 0x30
000078d1a57d54a1  vmovaps xmm0, [rsp]
000078d1a57d54a6  vmovaps xmm1, [rsp+0x10]
000078d1a57d54ac  vmovaps xmm2, [rsp+0x20]
000078d1a57d54b2  vmovaps xmm3, [rsp+0x30]
000078d1a57d54b8  vmovaps xmm4, [rsp+0x40]
000078d1a57d54be  vmovaps xmm5, [rsp+0x50]
000078d1a57d54c4  vmovaps xmm6, [rsp+0x60]
000078d1a57d54ca  vmovaps xmm7, [rsp+0x70]
000078d1a57d54d0  vmovaps xmm8, [rsp+0x80]
000078d1a57d54d9  vmovaps xmm9, [rsp+0x90]
000078d1a57d54e2  vmovaps xmm10, [rsp+0xA0]
000078d1a57d54eb  vmovaps xmm11, [rsp+0xB0]
000078d1a57d54f4  vmovaps xmm12, [rsp+0xC0]
000078d1a57d54fd  vmovaps xmm14, [rsp+0xD0]
000078d1a57d5506  vmovaps xmm15, [rsp+0xE0]
000078d1a57d550f  add rsp, 0xF0
000078d1a57d5516  pop r11
000078d1a57d5518  pop r10
000078d1a57d551a  pop r9
000078d1a57d551c  pop r8
000078d1a57d551e  pop rsi
000078d1a57d551f  pop rdi
000078d1a57d5520  pop rdx
000078d1a57d5521  pop rcx
000078d1a57d5522  pop rax
000078d1a57d5523  add rsp, 0x08
000078d1a57d5527  jmp 0x000078D1A57D02F7
000078d1a57d552c  sub rsp, 0x08
000078d1a57d5530  push rax
000078d1a57d5531  push rcx
000078d1a57d5532  push rdx
000078d1a57d5533  push rdi
000078d1a57d5534  push rsi
000078d1a57d5535  push r8
000078d1a57d5537  push r9
000078d1a57d5539  push r10
000078d1a57d553b  push r11
000078d1a57d553d  sub rsp, 0xF0
000078d1a57d5544  vmovaps [rsp], xmm0
000078d1a57d5549  vmovaps [rsp+0x10], xmm1
000078d1a57d554f  vmovaps [rsp+0x20], xmm2
000078d1a57d5555  vmovaps [rsp+0x30], xmm3
000078d1a57d555b  vmovaps [rsp+0x40], xmm4
000078d1a57d5561  vmovaps [rsp+0x50], xmm5
000078d1a57d5567  vmovaps [rsp+0x60], xmm6
000078d1a57d556d  vmovaps [rsp+0x70], xmm7
000078d1a57d5573  vmovaps [rsp+0x80], xmm8
000078d1a57d557c  vmovaps [rsp+0x90], xmm9
000078d1a57d5585  vmovaps [rsp+0xA0], xmm10
000078d1a57d558e  vmovaps [rsp+0xB0], xmm11
000078d1a57d5597  vmovaps [rsp+0xC0], xmm12
000078d1a57d55a0  vmovaps [rsp+0xD0], xmm13
000078d1a57d55a9  vmovaps [rsp+0xE0], xmm15
000078d1a57d55b2  sub rsp, 0x30
000078d1a57d55b6  movaps [rsp], xmm14
000078d1a57d55bb  movaps [rsp+0x10], xmm1
000078d1a57d55c0  movaps [rsp+0x20], xmm10
000078d1a57d55c6  lea rdi, [rsp]
000078d1a57d55ca  mov esi, 0x00
000078d1a57d55cf  mov rax, 0x56EA20A26530
000078d1a57d55d9  call rax
000078d1a57d55db  movaps xmm14, [rsp]
000078d1a57d55e0  add rsp, 0x30
000078d1a57d55e4  vmovaps xmm0, [rsp]
000078d1a57d55e9  vmovaps xmm1, [rsp+0x10]
000078d1a57d55ef  vmovaps xmm2, [rsp+0x20]
000078d1a57d55f5  vmovaps xmm3, [rsp+0x30]
000078d1a57d55fb  vmovaps xmm4, [rsp+0x40]
000078d1a57d5601  vmovaps xmm5, [rsp+0x50]
000078d1a57d5607  vmovaps xmm6, [rsp+0x60]
000078d1a57d560d  vmovaps xmm7, [rsp+0x70]
000078d1a57d5613  vmovaps xmm8, [rsp+0x80]
000078d1a57d561c  vmovaps xmm9, [rsp+0x90]
000078d1a57d5625  vmovaps xmm10, [rsp+0xA0]
000078d1a57d562e  vmovaps xmm11, [rsp+0xB0]
000078d1a57d5637  vmovaps xmm12, [rsp+0xC0]
000078d1a57d5640  vmovaps xmm13, [rsp+0xD0]
000078d1a57d5649  vmovaps xmm15, [rsp+0xE0]
000078d1a57d5652  add rsp, 0xF0
000078d1a57d5659  pop r11
000078d1a57d565b  pop r10
000078d1a57d565d  pop r9
000078d1a57d565f  pop r8
000078d1a57d5661  pop rsi
000078d1a57d5662  pop rdi
000078d1a57d5663  pop rdx
000078d1a57d5664  pop rcx
000078d1a57d5665  pop rax
000078d1a57d5666  add rsp, 0x08
000078d1a57d566a  jmp 0x000078D1A57D031A
000078d1a57d566f  sub rsp, 0x08
000078d1a57d5673  push rax
000078d1a57d5674  push rcx
000078d1a57d5675  push rdx
000078d1a57d5676  push rdi
000078d1a57d5677  push rsi
000078d1a57d5678  push r8
000078d1a57d567a  push r9
000078d1a57d567c  push r10
000078d1a57d567e  push r11
000078d1a57d5680  sub rsp, 0xF0
000078d1a57d5687  vmovaps [rsp], xmm0
000078d1a57d568c  vmovaps [rsp+0x10], xmm2
000078d1a57d5692  vmovaps [rsp+0x20], xmm3
000078d1a57d5698  vmovaps [rsp+0x30], xmm4
000078d1a57d569e  vmovaps [rsp+0x40], xmm5
000078d1a57d56a4  vmovaps [rsp+0x50], xmm6
000078d1a57d56aa  vmovaps [rsp+0x60], xmm7
000078d1a57d56b0  vmovaps [rsp+0x70], xmm8
000078d1a57d56b6  vmovaps [rsp+0x80], xmm9
000078d1a57d56bf  vmovaps [rsp+0x90], xmm10
000078d1a57d56c8  vmovaps [rsp+0xA0], xmm11
000078d1a57d56d1  vmovaps [rsp+0xB0], xmm12
000078d1a57d56da  vmovaps [rsp+0xC0], xmm13
000078d1a57d56e3  vmovaps [rsp+0xD0], xmm14
000078d1a57d56ec  vmovaps [rsp+0xE0], xmm15
000078d1a57d56f5  sub rsp, 0x30
000078d1a57d56f9  movaps [rsp], xmm1
000078d1a57d56fd  movaps [rsp+0x10], xmm7
000078d1a57d5702  movaps [rsp+0x20], xmm11
000078d1a57d5708  lea rdi, [rsp]
000078d1a57d570c  mov esi, 0x00
000078d1a57d5711  mov rax, 0x56EA20A26530
000078d1a57d571b  call rax
000078d1a57d571d  movaps xmm1, [rsp]
000078d1a57d5721  add rsp, 0x30
000078d1a57d5725  vmovaps xmm0, [rsp]
000078d1a57d572a  vmovaps xmm2, [rsp+0x10]
000078d1a57d5730  vmovaps xmm3, [rsp+0x20]
000078d1a57d5736  vmovaps xmm4, [rsp+0x30]
000078d1a57d573c  vmovaps xmm5, [rsp+0x40]
000078d1a57d5742  vmovaps xmm6, [rsp+0x50]
000078d1a57d5748  vmovaps xmm7, [rsp+0x60]
000078d1a57d574e  vmovaps xmm8, [rsp+0x70]
000078d1a57d5754  vmovaps xmm9, [rsp+0x80]
000078d1a57d575d  vmovaps xmm10, [rsp+0x90]
000078d1a57d5766  vmovaps xmm11, [rsp+0xA0]
000078d1a57d576f  vmovaps xmm12, [rsp+0xB0]
000078d1a57d5778  vmovaps xmm13, [rsp+0xC0]
000078d1a57d5781  vmovaps xmm14, [rsp+0xD0]
000078d1a57d578a  vmovaps xmm15, [rsp+0xE0]
000078d1a57d5793  add rsp, 0xF0
000078d1a57d579a  pop r11
000078d1a57d579c  pop r10
000078d1a57d579e  pop r9
000078d1a57d57a0  pop r8
000078d1a57d57a2  pop rsi
000078d1a57d57a3  pop rdi
000078d1a57d57a4  pop rdx
000078d1a57d57a5  pop rcx
000078d1a57d57a6  pop rax
000078d1a57d57a7  add rsp, 0x08
000078d1a57d57ab  jmp 0x000078D1A57D033B
000078d1a57d57b0  call 0x000078D1A560E880
000078d1a57d57b5  jmp 0x000078D1A57D034E
000078d1a57d57ba  call 0x000078D1A560C380
000078d1a57d57bf  jmp 0x000078D1A57D0359
000078d1a57d57c4  call 0x000078D1A560D600
000078d1a57d57c9  jmp 0x000078D1A57D0364
000078d1a57d57ce  call 0x000078D1A55FF540
000078d1a57d57d3  jmp 0x000078D1A57D036F
000078d1a57d57d8  int3
000078d1a57d57d9  nop [rax], eax
000078d1a57d57e0  mov rax, [r15+0x40]
000078d1a57d57e4  mov r14, [r15+0x58]
000078d1a57d57e8  lea r12, [rax+r14*1]
000078d1a57d57ec  movaps xmm1, [r15+0x1D0]
000078d1a57d57f4  vmovaps [rsp+0x10], xmm1
000078d1a57d57fa  vmovaps xmm15, [rsp+0x10]
000078d1a57d5800  por xmm1, xmm15
000078d1a57d5805  movaps xmm14, [r15+0x1A0]
000078d1a57d580d  vmovaps [rsp+0x10], xmm14
000078d1a57d5813  vmovaps xmm13, [rsp+0x10]
000078d1a57d5819  por xmm14, xmm13
000078d1a57d581e  lea rax, [r12+0x30]
000078d1a57d5823  mov r11, [r13+rax*1]
000078d1a57d5828  lea rax, [r12+0x38]
000078d1a57d582d  mov r10, [r13+rax*1]
000078d1a57d5832  movq xmm13, r11
000078d1a57d5837  movq xmm12, r10
000078d1a57d583c  movq xmm13, xmm13
000078d1a57d5841  vmovaps [rsp+0x10], xmm13
000078d1a57d5847  movq xmm13, xmm13
000078d1a57d584c  movaps [r15+0x130], xmm13
000078d1a57d5854  movq xmm12, xmm12
000078d1a57d5859  vmovaps [rsp+0x20], xmm12
000078d1a57d585f  movq xmm12, xmm12
000078d1a57d5864  movaps [r15+0x280], xmm12
000078d1a57d586c  movaps xmm13, [r15+0x270]
000078d1a57d5874  vmovaps [rsp+0x30], xmm13
000078d1a57d587a  vmovaps xmm12, [rsp+0x30]
000078d1a57d5880  por xmm13, xmm12
000078d1a57d5885  lea rax, [r12+0x20]
000078d1a57d588a  mov r11, [r13+rax*1]
000078d1a57d588f  lea rax, [r12+0x28]
000078d1a57d5894  mov r10, [r13+rax*1]
000078d1a57d5899  movq xmm12, r11
000078d1a57d589e  movq xmm11, r10
000078d1a57d58a3  movq xmm12, xmm12
000078d1a57d58a8  vmovaps [rsp+0x30], xmm12
000078d1a57d58ae  movq xmm12, xmm12
000078d1a57d58b3  movaps [r15+0x150], xmm12
000078d1a57d58bb  movq xmm11, xmm11
000078d1a57d58c0  vmovaps [rsp+0x40], xmm11
000078d1a57d58c6  movq xmm11, xmm11
000078d1a57d58cb  movaps [r15+0x140], xmm11
000078d1a57d58d3  lea rax, [r12+0x10]
000078d1a57d58d8  mov r11, [r13+rax*1]
000078d1a57d58dd  lea rax, [r12+0x18]
000078d1a57d58e2  mov r10, [r13+rax*1]
000078d1a57d58e7  movq xmm12, r11
000078d1a57d58ec  movq xmm11, r10
000078d1a57d58f1  movq xmm12, xmm12
000078d1a57d58f6  vmovaps [rsp+0x50], xmm12
000078d1a57d58fc  movq xmm12, xmm12
000078d1a57d5901  movaps [r15+0x170], xmm12
000078d1a57d5909  movq xmm11, xmm11
000078d1a57d590e  vmovaps [rsp+0x60], xmm11
000078d1a57d5914  movq xmm11, xmm11
000078d1a57d5919  movaps [r15+0x160], xmm11
000078d1a57d5921  mov rax, [r13+r12*1]
000078d1a57d5926  vmovq xmm12, rax
000078d1a57d592b  vpbroadcastq xmm12, xmm12
000078d1a57d5930  lea rax, [r12+0x08]
000078d1a57d5935  mov r12, [r13+rax*1]
000078d1a57d593a  movq xmm11, r12
000078d1a57d593f  movaps [r15+0x230], xmm11
000078d1a57d5947  mov rax, [r15+0xF8]
000078d1a57d594e  lea r12, [rax+0x50]
000078d1a57d5952  movups xmm11, [r13+r12*1]
000078d1a57d5958  lea r12, [rax+0x60]
000078d1a57d595c  movups xmm10, [r13+r12*1]
000078d1a57d5962  lea r12, [rax+0x30]
000078d1a57d5966  movups xmm9, [r13+r12*1]
000078d1a57d596c  mov r12, [r15+0x50]
000078d1a57d5970  lea r11, [r12+r14*1]
000078d1a57d5974  mov [r15+0x60], r11
000078d1a57d5978  lea r12, [r14+0x40]
000078d1a57d597c  mov [r15+0x58], r12
000078d1a57d5980  movaps xmm8, xmm12
000078d1a57d5984  mulpd xmm8, xmm15
000078d1a57d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000078d1a57d598f  ptest xmm7, xmm7
000078d1a57d5994  jnz 0x000078D1A57D67B7
000078d1a57d599a  movq xmm15, qword ptr [r15+0x230]
000078d1a57d59a3  vmovaps [rsp+0x70], xmm15
000078d1a57d59a9  vpermilpd xmm15, xmm15, 0x00
000078d1a57d59af  movaps xmm7, xmm9
000078d1a57d59b3  mulpd xmm7, xmm15
000078d1a57d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000078d1a57d59bd  ptest xmm6, xmm6
000078d1a57d59c2  jnz 0x000078D1A57D68FB
000078d1a57d59c8  vxorps xmm15, xmm15, xmm15
000078d1a57d59cd  vpbroadcastq xmm15, xmm15
000078d1a57d59d2  movaps xmm9, xmm12
000078d1a57d59d6  mulpd xmm9, xmm10
000078d1a57d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000078d1a57d59e1  ptest xmm6, xmm6
000078d1a57d59e6  jnz 0x000078D1A57D6A3D
000078d1a57d59ec  movaps xmm10, xmm12
000078d1a57d59f0  mulpd xmm10, xmm11
000078d1a57d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000078d1a57d59fb  ptest xmm6, xmm6
000078d1a57d5a00  jnz 0x000078D1A57D6B81
000078d1a57d5a06  movaps xmm11, [r15+0x1F0]
000078d1a57d5a0e  movaps xmm6, xmm12
000078d1a57d5a12  mulpd xmm6, xmm11
000078d1a57d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000078d1a57d5a1c  ptest xmm5, xmm5
000078d1a57d5a21  jnz 0x000078D1A57D6CC5
000078d1a57d5a27  movaps xmm12, [r15+0x2A0]
000078d1a57d5a2f  vmovaps [rsp+0x80], xmm12
000078d1a57d5a38  vmovaps xmm11, [rsp+0x80]
000078d1a57d5a41  por xmm12, xmm11
000078d1a57d5a46  movaps xmm11, [r15+0x250]
000078d1a57d5a4e  vmovaps [rsp+0x80], xmm11
000078d1a57d5a57  vmovaps xmm5, [rsp+0x80]
000078d1a57d5a60  por xmm11, xmm5
000078d1a57d5a65  vmovaps xmm4, [rsp+0x70]
000078d1a57d5a6b  vpermilpd xmm4, xmm4, 0x00
000078d1a57d5a71  movaps xmm3, xmm5
000078d1a57d5a74  mulpd xmm3, xmm4
000078d1a57d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000078d1a57d5a7d  ptest xmm2, xmm2
000078d1a57d5a82  jnz 0x000078D1A57D6E07
000078d1a57d5a88  mov [rsp+0x80], rax
000078d1a57d5a90  xor eax, eax
000078d1a57d5a92  mov r14d, 0x200
000078d1a57d5a98  cmp r12, r14
000078d1a57d5a9b  cmc
000078d1a57d5a9c  lahf
000078d1a57d5a9d  seto al
000078d1a57d5aa0  mov [r15+0x108], eax
000078d1a57d5aa7  movaps xmm5, xmm8
000078d1a57d5aab  addpd xmm5, xmm15
000078d1a57d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000078d1a57d5ab5  ptest xmm4, xmm4
000078d1a57d5aba  jnz 0x000078D1A57D6F47
000078d1a57d5ac0  movaps xmm8, [r15+0x1B0]
000078d1a57d5ac8  movaps xmm4, xmm9
000078d1a57d5acc  addpd xmm4, xmm8
000078d1a57d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000078d1a57d5ad6  ptest xmm2, xmm2
000078d1a57d5adb  jnz 0x000078D1A57D7089
000078d1a57d5ae1  movaps xmm9, xmm10
000078d1a57d5ae5  addpd xmm9, xmm8
000078d1a57d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000078d1a57d5af0  ptest xmm2, xmm2
000078d1a57d5af5  jnz 0x000078D1A57D71CB
000078d1a57d5afb  movaps xmm10, [r15+0x2F0]
000078d1a57d5b03  vmovaps [rsp+0x90], xmm10
000078d1a57d5b0c  vmovaps xmm8, [rsp+0x90]
000078d1a57d5b15  por xmm10, xmm8
000078d1a57d5b1a  movaps xmm8, [r15+0x2E0]
000078d1a57d5b22  vmovaps [rsp+0x90], xmm8
000078d1a57d5b2b  vmovaps xmm2, [rsp+0x90]
000078d1a57d5b34  por xmm8, xmm2
000078d1a57d5b39  movaps xmm2, [r15+0x2D0]
000078d1a57d5b41  vmovaps [rsp+0x90], xmm2
000078d1a57d5b4a  vmovaps [rsp+0xA0], xmm1
000078d1a57d5b53  vmovaps xmm1, [rsp+0x90]
000078d1a57d5b5c  por xmm2, xmm1
000078d1a57d5b60  movaps xmm1, [r15+0x200]
000078d1a57d5b68  vmovaps [rsp+0x90], xmm1
000078d1a57d5b71  vmovaps [rsp+0xB0], xmm15
000078d1a57d5b7a  vmovaps xmm15, [rsp+0x90]
000078d1a57d5b83  por xmm1, xmm15
000078d1a57d5b88  movaps xmm15, [r15+0x1C0]
000078d1a57d5b90  vmovaps [rsp+0x90], xmm15
000078d1a57d5b99  vmovaps [rsp+0xC0], xmm1
000078d1a57d5ba2  vmovaps xmm1, [rsp+0x90]
000078d1a57d5bab  por xmm15, xmm1
000078d1a57d5bb0  movaps xmm1, [r15+0x190]
000078d1a57d5bb8  vmovaps [rsp+0x90], xmm1
000078d1a57d5bc1  vmovaps [rsp+0xD0], xmm15
000078d1a57d5bca  vmovaps xmm15, [rsp+0x90]
000078d1a57d5bd3  por xmm1, xmm15
000078d1a57d5bd8  movaps xmm15, [r15+0x300]
000078d1a57d5be0  vmovaps [rsp+0x90], xmm15
000078d1a57d5be9  vmovaps [rsp+0xE0], xmm1
000078d1a57d5bf2  vmovaps xmm1, [rsp+0x90]
000078d1a57d5bfb  por xmm15, xmm1
000078d1a57d5c00  mov rax, [rsp+0x80]
000078d1a57d5c08  lea r14, [rax+0xA0]
000078d1a57d5c0f  movups xmm1, [r13+r14*1]
000078d1a57d5c15  lea r14, [rax+0xB0]
000078d1a57d5c1c  vmovaps [rsp+0x80], xmm1
000078d1a57d5c25  movups xmm1, [r13+r14*1]
000078d1a57d5c2b  vmovaps [rsp+0x90], xmm1
000078d1a57d5c34  vmovaps [rsp+0xF0], xmm15
000078d1a57d5c3d  vmovaps xmm15, [rsp+0xB0]
000078d1a57d5c46  vmovaps [rsp+0xB0], xmm14
000078d1a57d5c4f  movaps xmm1, xmm6
000078d1a57d5c52  addpd xmm1, xmm15
000078d1a57d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000078d1a57d5c5c  ptest xmm14, xmm14
000078d1a57d5c62  jnz 0x000078D1A57D7323
000078d1a57d5c68  lea r14, [rax+0xF0]
000078d1a57d5c6f  movups xmm15, [r13+r14*1]
000078d1a57d5c75  movaps xmm14, xmm4
000078d1a57d5c79  addpd xmm14, xmm3
000078d1a57d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000078d1a57d5c84  ptest xmm6, xmm6
000078d1a57d5c89  jnz 0x000078D1A57D746E
000078d1a57d5c8f  movaps xmm6, xmm9
000078d1a57d5c93  addpd xmm6, xmm7
000078d1a57d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000078d1a57d5c9c  ptest xmm4, xmm4
000078d1a57d5ca1  jnz 0x000078D1A57D75B0
000078d1a57d5ca7  vmovaps xmm9, [rsp+0x70]
000078d1a57d5cad  vpermilpd xmm9, xmm9, 0x00
000078d1a57d5cb3  vmovaps xmm4, [rsp+0x90]
000078d1a57d5cbc  movaps xmm7, xmm4
000078d1a57d5cbf  mulpd xmm7, xmm9
000078d1a57d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000078d1a57d5cc9  ptest xmm3, xmm3
000078d1a57d5cce  jnz 0x000078D1A57D76F1
000078d1a57d5cd4  vmovaps xmm9, [rsp+0x50]
000078d1a57d5cda  vpermilpd xmm9, xmm9, 0x00
000078d1a57d5ce0  movaps xmm4, xmm15
000078d1a57d5ce4  mulpd xmm4, xmm9
000078d1a57d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000078d1a57d5cee  ptest xmm3, xmm3
000078d1a57d5cf3  jnz 0x000078D1A57D7832
000078d1a57d5cf9  lea r14, [rax+0xE0]
000078d1a57d5d00  movups xmm15, [r13+r14*1]
000078d1a57d5d06  vmovaps xmm9, [rsp+0x70]
000078d1a57d5d0c  vpermilpd xmm9, xmm9, 0x00
000078d1a57d5d12  vmovaps [rsp+0x70], xmm1
000078d1a57d5d18  vmovaps xmm1, [rsp+0x80]
000078d1a57d5d21  vmovaps [rsp+0x80], xmm15
000078d1a57d5d2a  movaps xmm3, xmm1
000078d1a57d5d2d  mulpd xmm3, xmm9
000078d1a57d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000078d1a57d5d37  ptest xmm15, xmm15
000078d1a57d5d3d  jnz 0x000078D1A57D797E
000078d1a57d5d43  vmovaps xmm1, [rsp+0xF0]
000078d1a57d5d4c  vmovaps xmm15, [rsp+0xF0]
000078d1a57d5d55  por xmm1, xmm15
000078d1a57d5d5a  movaps [r15+0x300], xmm1
000078d1a57d5d62  vmovaps xmm15, [rsp+0xE0]
000078d1a57d5d6b  vmovaps xmm9, [rsp+0xE0]
000078d1a57d5d74  por xmm15, xmm9
000078d1a57d5d79  movaps [r15+0x190], xmm15
000078d1a57d5d81  vmovaps xmm9, [rsp+0x50]
000078d1a57d5d87  vpermilpd xmm9, xmm9, 0x00
000078d1a57d5d8d  vmovaps [rsp+0x90], xmm1
000078d1a57d5d96  vmovaps [rsp+0xE0], xmm15
000078d1a57d5d9f  vmovaps xmm15, [rsp+0x80]
000078d1a57d5da8  vmovaps [rsp+0x80], xmm14
000078d1a57d5db1  movaps xmm1, xmm15
000078d1a57d5db5  mulpd xmm1, xmm9
000078d1a57d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000078d1a57d5dbf  ptest xmm14, xmm14
000078d1a57d5dc5  jnz 0x000078D1A57D7ABF
000078d1a57d5dcb  lea r14, [rax+0x90]
000078d1a57d5dd2  movups xmm15, [r13+r14*1]
000078d1a57d5dd8  vmovaps xmm14, [rsp+0xD0]
000078d1a57d5de1  vmovaps xmm9, [rsp+0xD0]
000078d1a57d5dea  por xmm14, xmm9
000078d1a57d5def  movaps [r15+0x1C0], xmm14
000078d1a57d5df7  vmovaps xmm9, [rsp+0xC0]
000078d1a57d5e00  vmovaps [rsp+0xD0], xmm1
000078d1a57d5e09  vmovaps xmm1, [rsp+0xC0]
000078d1a57d5e12  por xmm9, xmm1
000078d1a57d5e17  movaps [r15+0x200], xmm9
000078d1a57d5e1f  vmovaps [rsp+0xC0], xmm2
000078d1a57d5e28  vmovaps xmm1, [rsp+0xC0]
000078d1a57d5e31  por xmm2, xmm1
000078d1a57d5e35  movaps [r15+0x2D0], xmm2
000078d1a57d5e3d  vmovaps [rsp+0xC0], xmm8
000078d1a57d5e46  vmovaps xmm1, [rsp+0xC0]
000078d1a57d5e4f  por xmm8, xmm1
000078d1a57d5e54  movaps [r15+0x2E0], xmm8
000078d1a57d5e5c  vmovaps [rsp+0xC0], xmm15
000078d1a57d5e65  movaps xmm1, xmm5
000078d1a57d5e68  addpd xmm1, xmm7
000078d1a57d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000078d1a57d5e71  ptest xmm15, xmm15
000078d1a57d5e77  jnz 0x000078D1A57D7C0B
000078d1a57d5e7d  vmovaps xmm15, [rsp+0x50]
000078d1a57d5e83  vpermilpd xmm15, xmm15, 0x00
000078d1a57d5e89  vmovaps xmm5, [rsp+0xC0]
000078d1a57d5e92  vmovaps [rsp+0xC0], xmm1
000078d1a57d5e9b  movaps xmm7, xmm5
000078d1a57d5e9e  mulpd xmm7, xmm15
000078d1a57d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000078d1a57d5ea8  ptest xmm1, xmm1
000078d1a57d5ead  jnz 0x000078D1A57D7D4B
000078d1a57d5eb3  lea r14, [rax+0x80]
000078d1a57d5eba  movups xmm1, [r13+r14*1]
000078d1a57d5ec0  vmovaps xmm5, [rsp+0x70]
000078d1a57d5ec6  vmovaps [rsp+0x70], xmm1
000078d1a57d5ecc  movaps xmm15, xmm5
000078d1a57d5ed0  addpd xmm15, xmm3
000078d1a57d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000078d1a57d5edb  ptest xmm1, xmm1
000078d1a57d5ee0  jnz 0x000078D1A57D7E96
000078d1a57d5ee6  vmovaps xmm5, [rsp+0x80]
000078d1a57d5eef  movaps xmm1, xmm5
000078d1a57d5ef2  addpd xmm1, xmm4
000078d1a57d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000078d1a57d5efb  ptest xmm3, xmm3
000078d1a57d5f00  jnz 0x000078D1A57D7FD8
000078d1a57d5f06  vmovaps [rsp+0x80], xmm10
000078d1a57d5f0f  vmovaps xmm5, [rsp+0x80]
000078d1a57d5f18  por xmm10, xmm5
000078d1a57d5f1d  movaps [r15+0x2F0], xmm10
000078d1a57d5f25  vmovaps xmm5, [rsp+0x50]
000078d1a57d5f2b  vpermilpd xmm5, xmm5, 0x00
000078d1a57d5f31  vmovaps xmm3, [rsp+0x70]
000078d1a57d5f37  vmovaps [rsp+0x50], xmm1
000078d1a57d5f3d  movaps xmm4, xmm3
000078d1a57d5f40  mulpd xmm4, xmm5
000078d1a57d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000078d1a57d5f49  ptest xmm1, xmm1
000078d1a57d5f4e  jnz 0x000078D1A57D8118
000078d1a57d5f54  lea r14, [rax+0xD0]
000078d1a57d5f5b  movups xmm1, [r13+r14*1]
000078d1a57d5f61  vmovaps xmm3, [rsp+0xD0]
000078d1a57d5f6a  vmovaps [rsp+0x70], xmm1
000078d1a57d5f70  movaps xmm5, xmm6
000078d1a57d5f73  addpd xmm5, xmm3
000078d1a57d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000078d1a57d5f7c  ptest xmm1, xmm1
000078d1a57d5f81  jnz 0x000078D1A57D8262
000078d1a57d5f87  vmovaps xmm1, [rsp+0x60]
000078d1a57d5f8d  vpermilpd xmm1, xmm1, 0x00
000078d1a57d5f93  movaps xmm6, xmm9
000078d1a57d5f97  mulpd xmm6, xmm1
000078d1a57d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000078d1a57d5fa0  ptest xmm3, xmm3
000078d1a57d5fa5  jnz 0x000078D1A57D83A2
000078d1a57d5fab  movaps [r15+0x260], xmm6
000078d1a57d5fb3  vxorps xmm1, xmm1, xmm1
000078d1a57d5fb7  vpbroadcastq xmm1, xmm1
000078d1a57d5fbc  movaps [r15+0x1B0], xmm1
000078d1a57d5fc4  vmovaps xmm1, [rsp+0x60]
000078d1a57d5fca  vpermilpd xmm1, xmm1, 0x00
000078d1a57d5fd0  vmovaps xmm3, [rsp+0x70]
000078d1a57d5fd6  vmovaps [rsp+0x70], xmm15
000078d1a57d5fdc  movaps xmm9, xmm3
000078d1a57d5fe0  mulpd xmm9, xmm1
000078d1a57d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000078d1a57d5feb  ptest xmm15, xmm15
000078d1a57d5ff1  jnz 0x000078D1A57D84E3
000078d1a57d5ff7  lea r14, [rax+0xC0]
000078d1a57d5ffe  movups xmm1, [r13+r14*1]
000078d1a57d6004  vmovaps xmm3, [rsp+0xC0]
000078d1a57d600d  vmovaps [rsp+0x80], xmm1
000078d1a57d6016  movaps xmm15, xmm3
000078d1a57d601a  addpd xmm15, xmm7
000078d1a57d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000078d1a57d6025  ptest xmm1, xmm1
000078d1a57d602a  jnz 0x000078D1A57D862F
000078d1a57d6030  vmovaps [rsp+0xC0], xmm13
000078d1a57d6039  vmovaps xmm1, [rsp+0xC0]
000078d1a57d6042  por xmm13, xmm1
000078d1a57d6047  movaps [r15+0x270], xmm13
000078d1a57d604f  vmovaps xmm1, [rsp+0xB0]
000078d1a57d6058  vmovaps xmm7, [rsp+0xB0]
000078d1a57d6061  por xmm1, xmm7
000078d1a57d6065  movaps [r15+0x1A0], xmm1
000078d1a57d606d  vmovaps xmm1, [rsp+0x60]
000078d1a57d6073  vpermilpd xmm1, xmm1, 0x00
000078d1a57d6079  vmovaps [rsp+0xB0], xmm1
000078d1a57d6082  vmovaps xmm1, [rsp+0x80]
000078d1a57d608b  vmovaps [rsp+0x80], xmm15
000078d1a57d6094  vmovaps xmm15, [rsp+0xB0]
000078d1a57d609d  vmovaps [rsp+0xB0], xmm14
000078d1a57d60a6  movaps xmm3, xmm1
000078d1a57d60a9  mulpd xmm3, xmm15
000078d1a57d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000078d1a57d60b3  ptest xmm14, xmm14
000078d1a57d60b9  jnz 0x000078D1A57D8771
000078d1a57d60bf  lea r14, [rax+0x20]
000078d1a57d60c3  movups xmm1, [r13+r14*1]
000078d1a57d60c9  movaps [r15+0x110], xmm1
000078d1a57d60d1  vmovaps xmm14, [rsp+0x70]
000078d1a57d60d7  vmovaps [rsp+0x70], xmm1
000078d1a57d60dd  movaps xmm15, xmm14
000078d1a57d60e1  addpd xmm15, xmm4
000078d1a57d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000078d1a57d60ec  ptest xmm1, xmm1
000078d1a57d60f1  jnz 0x000078D1A57D88BC
000078d1a57d60f7  vmovaps xmm1, [rsp+0x60]
000078d1a57d60fd  vpermilpd xmm1, xmm1, 0x00
000078d1a57d6103  movaps xmm14, xmm2
000078d1a57d6107  mulpd xmm14, xmm1
000078d1a57d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000078d1a57d6112  ptest xmm4, xmm4
000078d1a57d6117  jnz 0x000078D1A57D89FF
000078d1a57d611d  vmovaps xmm4, [rsp+0x50]
000078d1a57d6123  movaps xmm1, xmm4
000078d1a57d6126  addpd xmm1, xmm9
000078d1a57d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000078d1a57d6130  ptest xmm2, xmm2
000078d1a57d6135  jnz 0x000078D1A57D8B41
000078d1a57d613b  vmovaps xmm9, [rsp+0x30]
000078d1a57d6141  vpermilpd xmm9, xmm9, 0x00
000078d1a57d6147  vmovaps xmm2, [rsp+0x70]
000078d1a57d614d  vmovaps [rsp+0x50], xmm1
000078d1a57d6153  movaps xmm4, xmm2
000078d1a57d6156  mulpd xmm4, xmm9
000078d1a57d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000078d1a57d6160  ptest xmm1, xmm1
000078d1a57d6165  jnz 0x000078D1A57D8C82
000078d1a57d616b  vmovaps xmm1, [rsp+0x30]
000078d1a57d6171  vpermilpd xmm1, xmm1, 0x00
000078d1a57d6177  vmovaps xmm2, [rsp+0x90]
000078d1a57d6180  vmovaps [rsp+0x60], xmm15
000078d1a57d6186  movaps xmm9, xmm2
000078d1a57d618a  mulpd xmm9, xmm1
000078d1a57d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000078d1a57d6195  ptest xmm15, xmm15
000078d1a57d619b  jnz 0x000078D1A57D8DC3
000078d1a57d61a1  vmovaps xmm15, [rsp+0x80]
000078d1a57d61aa  movaps xmm1, xmm15
000078d1a57d61ae  addpd xmm1, xmm6
000078d1a57d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000078d1a57d61b7  ptest xmm2, xmm2
000078d1a57d61bc  jnz 0x000078D1A57D8F05
000078d1a57d61c2  movaps xmm15, xmm5
000078d1a57d61c6  addpd xmm15, xmm3
000078d1a57d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000078d1a57d61d1  ptest xmm6, xmm6
000078d1a57d61d6  jnz 0x000078D1A57D9046
000078d1a57d61dc  vmovaps xmm6, [rsp+0x30]
000078d1a57d61e2  vpermilpd xmm6, xmm6, 0x00
000078d1a57d61e8  movaps xmm5, xmm8
000078d1a57d61ec  mulpd xmm5, xmm6
000078d1a57d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000078d1a57d61f5  ptest xmm3, xmm3
000078d1a57d61fa  jnz 0x000078D1A57D9188
000078d1a57d6200  vmovaps xmm8, [rsp+0x30]
000078d1a57d6206  vpermilpd xmm8, xmm8, 0x00
000078d1a57d620c  movaps xmm6, xmm10
000078d1a57d6210  mulpd xmm6, xmm8
000078d1a57d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000078d1a57d621a  ptest xmm3, xmm3
000078d1a57d621f  jnz 0x000078D1A57D92C9
000078d1a57d6225  vmovaps xmm8, [rsp+0x60]
000078d1a57d622b  movaps xmm10, xmm8
000078d1a57d622f  addpd xmm10, xmm14
000078d1a57d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000078d1a57d623a  ptest xmm3, xmm3
000078d1a57d623f  jnz 0x000078D1A57D940B
000078d1a57d6245  vmovaps xmm8, [rsp+0x50]
000078d1a57d624b  movaps xmm14, xmm8
000078d1a57d624f  addpd xmm14, xmm4
000078d1a57d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000078d1a57d625a  ptest xmm3, xmm3
000078d1a57d625f  jnz 0x000078D1A57D954F
000078d1a57d6265  vmovaps xmm8, [rsp+0x40]
000078d1a57d626b  vpermilpd xmm8, xmm8, 0x00
000078d1a57d6271  movaps xmm4, xmm13
000078d1a57d6275  mulpd xmm4, xmm8
000078d1a57d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000078d1a57d627f  ptest xmm3, xmm3
000078d1a57d6284  jnz 0x000078D1A57D9692
000078d1a57d628a  movaps xmm13, xmm15
000078d1a57d628e  addpd xmm13, xmm9
000078d1a57d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000078d1a57d6299  ptest xmm8, xmm8
000078d1a57d629f  jnz 0x000078D1A57D97D4
000078d1a57d62a5  movaps xmm15, xmm1
000078d1a57d62a9  addpd xmm15, xmm5
000078d1a57d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000078d1a57d62b4  ptest xmm9, xmm9
000078d1a57d62ba  jnz 0x000078D1A57D9918
000078d1a57d62c0  vmovaps [rsp+0x30], xmm11
000078d1a57d62c6  vmovaps xmm1, [rsp+0x30]
000078d1a57d62cc  por xmm11, xmm1
000078d1a57d62d1  movaps [r15+0x250], xmm11
000078d1a57d62d9  vmovaps [rsp+0x30], xmm12
000078d1a57d62df  vmovaps xmm1, [rsp+0x30]
000078d1a57d62e5  por xmm12, xmm1
000078d1a57d62ea  movaps [r15+0x2A0], xmm12
000078d1a57d62f2  vmovaps xmm1, [rsp+0xA0]
000078d1a57d62fb  vmovaps xmm11, [rsp+0xA0]
000078d1a57d6304  por xmm1, xmm11
000078d1a57d6309  movaps [r15+0x1D0], xmm1
000078d1a57d6311  lea r14, [rax+0x40]
000078d1a57d6315  movups xmm1, [r13+r14*1]
000078d1a57d631b  movaps [r15+0x2C0], xmm1
000078d1a57d6323  vmovaps xmm11, [rsp+0x40]
000078d1a57d6329  vpermilpd xmm11, xmm11, 0x00
000078d1a57d632f  vmovaps xmm8, [rsp+0xE0]
000078d1a57d6338  movaps xmm9, xmm8
000078d1a57d633c  mulpd xmm9, xmm11
000078d1a57d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000078d1a57d6347  ptest xmm5, xmm5
000078d1a57d634c  jnz 0x000078D1A57D9A64
000078d1a57d6352  movaps xmm11, xmm10
000078d1a57d6356  addpd xmm11, xmm6
000078d1a57d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000078d1a57d6361  ptest xmm8, xmm8
000078d1a57d6367  jnz 0x000078D1A57D9BA8
000078d1a57d636d  movaps xmm10, xmm14
000078d1a57d6371  addpd xmm10, xmm4
000078d1a57d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000078d1a57d637c  ptest xmm8, xmm8
000078d1a57d6382  jnz 0x000078D1A57D9CEB
000078d1a57d6388  vmovaps xmm14, [rsp+0x40]
000078d1a57d638e  vpermilpd xmm14, xmm14, 0x00
000078d1a57d6394  movaps xmm8, xmm1
000078d1a57d6398  mulpd xmm8, xmm14
000078d1a57d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000078d1a57d63a3  ptest xmm6, xmm6
000078d1a57d63a8  jnz 0x000078D1A57D9E2E
000078d1a57d63ae  movaps xmm1, [r15+0x2B0]
000078d1a57d63b6  vmovaps xmm14, [rsp+0x40]
000078d1a57d63bc  vpermilpd xmm14, xmm14, 0x00
000078d1a57d63c2  movaps xmm6, xmm1
000078d1a57d63c5  mulpd xmm6, xmm14
000078d1a57d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000078d1a57d63cf  ptest xmm5, xmm5
000078d1a57d63d4  jnz 0x000078D1A57D9F71
000078d1a57d63da  vmovaps xmm1, [rsp+0x10]
000078d1a57d63e0  vpermilpd xmm1, xmm1, 0x00
000078d1a57d63e6  movaps xmm14, xmm12
000078d1a57d63ea  mulpd xmm14, xmm1
000078d1a57d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000078d1a57d63f5  ptest xmm5, xmm5
000078d1a57d63fa  jnz 0x000078D1A57DA0B2
000078d1a57d6400  movaps xmm1, xmm13
000078d1a57d6404  addpd xmm1, xmm9
000078d1a57d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000078d1a57d640e  ptest xmm12, xmm12
000078d1a57d6414  jnz 0x000078D1A57DA1F5
000078d1a57d641a  vmovaps xmm13, [rsp+0x10]
000078d1a57d6420  vpermilpd xmm13, xmm13, 0x00
000078d1a57d6426  movaps xmm12, xmm7
000078d1a57d642a  mulpd xmm12, xmm13
000078d1a57d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000078d1a57d6435  ptest xmm9, xmm9
000078d1a57d643b  jnz 0x000078D1A57DA337
000078d1a57d6441  movaps xmm13, xmm15
000078d1a57d6445  addpd xmm13, xmm8
000078d1a57d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000078d1a57d6450  ptest xmm9, xmm9
000078d1a57d6456  jnz 0x000078D1A57DA47A
000078d1a57d645c  movaps xmm15, [r15+0x290]
000078d1a57d6464  vmovaps xmm9, [rsp+0x10]
000078d1a57d646a  vpermilpd xmm9, xmm9, 0x00
000078d1a57d6470  movaps xmm8, xmm15
000078d1a57d6474  mulpd xmm8, xmm9
000078d1a57d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000078d1a57d647f  ptest xmm7, xmm7
000078d1a57d6484  jnz 0x000078D1A57DA5BE
000078d1a57d648a  movaps xmm15, xmm11
000078d1a57d648e  addpd xmm15, xmm6
000078d1a57d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000078d1a57d6499  ptest xmm9, xmm9
000078d1a57d649f  jnz 0x000078D1A57DA702
000078d1a57d64a5  movaps xmm11, [r15+0x1E0]
000078d1a57d64ad  vmovaps xmm9, [rsp+0x10]
000078d1a57d64b3  vpermilpd xmm9, xmm9, 0x00
000078d1a57d64b9  movaps xmm7, xmm11
000078d1a57d64bd  mulpd xmm7, xmm9
000078d1a57d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000078d1a57d64c7  ptest xmm6, xmm6
000078d1a57d64cc  jnz 0x000078D1A57DA845
000078d1a57d64d2  movaps xmm11, xmm10
000078d1a57d64d6  addpd xmm11, xmm14
000078d1a57d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000078d1a57d64e1  ptest xmm9, xmm9
000078d1a57d64e7  jnz 0x000078D1A57DA987
000078d1a57d64ed  lea r14, [rax+0x70]
000078d1a57d64f1  movups xmm14, [r13+r14*1]
000078d1a57d64f7  movaps [r15+0x240], xmm14
000078d1a57d64ff  movaps xmm10, xmm1
000078d1a57d6503  addpd xmm10, xmm12
000078d1a57d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000078d1a57d650e  ptest xmm9, xmm9
000078d1a57d6514  jnz 0x000078D1A57DAAD5
000078d1a57d651a  movaps [r15+0x170], xmm10
000078d1a57d6522  vmovaps xmm1, [rsp+0x20]
000078d1a57d6528  vpermilpd xmm1, xmm1, 0x00
000078d1a57d652e  movaps xmm12, xmm14
000078d1a57d6532  mulpd xmm12, xmm1
000078d1a57d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000078d1a57d653d  ptest xmm9, xmm9
000078d1a57d6543  jnz 0x000078D1A57DAC18
000078d1a57d6549  vmovaps xmm1, [rsp+0x20]
000078d1a57d654f  vpermilpd xmm1, xmm1, 0x00
000078d1a57d6555  vmovaps xmm9, [rsp+0xB0]
000078d1a57d655e  movaps xmm14, xmm9
000078d1a57d6562  mulpd xmm14, xmm1
000078d1a57d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000078d1a57d656d  ptest xmm6, xmm6
000078d1a57d6572  jnz 0x000078D1A57DAD5B
000078d1a57d6578  movaps [r15+0x180], xmm14
000078d1a57d6580  movaps xmm1, xmm13
000078d1a57d6584  addpd xmm1, xmm8
000078d1a57d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000078d1a57d658e  ptest xmm9, xmm9
000078d1a57d6594  jnz 0x000078D1A57DAE9E
000078d1a57d659a  movaps [r15+0x210], xmm1
000078d1a57d65a2  movups xmm13, [r13+rax*1]
000078d1a57d65a8  lea r14, [rax+0x10]
000078d1a57d65ac  movups xmm9, [r13+r14*1]
000078d1a57d65b2  movaps [r15+0x230], xmm9
000078d1a57d65ba  movaps xmm8, xmm15
000078d1a57d65be  addpd xmm8, xmm7
000078d1a57d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000078d1a57d65c9  ptest xmm6, xmm6
000078d1a57d65ce  jnz 0x000078D1A57DAFF4
000078d1a57d65d4  movaps [r15+0x130], xmm8
000078d1a57d65dc  vmovaps xmm15, [rsp+0x20]
000078d1a57d65e2  vpermilpd xmm15, xmm15, 0x00
000078d1a57d65e8  movaps xmm7, xmm9
000078d1a57d65ec  mulpd xmm7, xmm15
000078d1a57d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000078d1a57d65f6  ptest xmm6, xmm6
000078d1a57d65fb  jnz 0x000078D1A57DB137
000078d1a57d6601  movaps [r15+0x220], xmm7
000078d1a57d6609  vmovaps xmm15, [rsp+0x20]
000078d1a57d660f  vpermilpd xmm15, xmm15, 0x00
000078d1a57d6615  movaps xmm9, xmm13
000078d1a57d6619  mulpd xmm9, xmm15
000078d1a57d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000078d1a57d6624  ptest xmm6, xmm6
000078d1a57d6629  jnz 0x000078D1A57DB279
000078d1a57d662f  movaps xmm15, xmm11
000078d1a57d6633  addpd xmm15, xmm12
000078d1a57d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000078d1a57d663e  ptest xmm13, xmm13
000078d1a57d6644  jnz 0x000078D1A57DB3BD
000078d1a57d664a  movaps [r15+0x140], xmm15
000078d1a57d6652  movaps xmm13, xmm10
000078d1a57d6656  addpd xmm13, xmm14
000078d1a57d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000078d1a57d6661  ptest xmm12, xmm12
000078d1a57d6667  jnz 0x000078D1A57DB501
000078d1a57d666d  movaps [r15+0x150], xmm13
000078d1a57d6675  movaps xmm14, xmm1
000078d1a57d6679  addpd xmm14, xmm7
000078d1a57d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000078d1a57d6684  ptest xmm12, xmm12
000078d1a57d668a  jnz 0x000078D1A57DB645
000078d1a57d6690  movaps [r15+0x160], xmm14
000078d1a57d6698  movaps xmm1, xmm8
000078d1a57d669c  addpd xmm1, xmm9
000078d1a57d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000078d1a57d66a6  ptest xmm12, xmm12
000078d1a57d66ac  jnz 0x000078D1A57DB787
000078d1a57d66b2  movaps [r15+0x120], xmm1
000078d1a57d66ba  movups [r13+r11*1], xmm15
000078d1a57d66c0  lea rax, [r11+0x10]
000078d1a57d66c4  movups [r13+rax*1], xmm13
000078d1a57d66ca  lea rax, [r11+0x20]
000078d1a57d66ce  movups [r13+rax*1], xmm14
000078d1a57d66d4  lea rax, [r11+0x30]
000078d1a57d66d8  movups [r13+rax*1], xmm1
000078d1a57d66de  mov eax, [r15+0x108]
000078d1a57d66e5  sahf
000078d1a57d66e6  jnz 0x000078D1A57D6718
000078d1a57d66e8  cmp dword ptr [r15+0x318], 0x00
000078d1a57d66f0  jz 0x000078D1A57DB900
000078d1a57d66f6  nop [rax+rax*1], ax
000078d1a57d66ff  nop [rax+rax*1], eax
000078d1a57d6707  mov eax, 0x410444
000078d1a57d670c  mov [r15+0x100], rax
000078d1a57d6713  jmp 0x000078D1A55FE110
000078d1a57d6718  cmp dword ptr [r15+0x318], 0x00
000078d1a57d6720  jz 0x000078D1A57D57E0
000078d1a57d6726  nop [rax+rax*1], ax
000078d1a57d672f  nop [rax+rax*1], eax
000078d1a57d6737  mov eax, 0x410278
000078d1a57d673c  mov [r15+0x100], rax
000078d1a57d6743  jmp 0x000078D1A55FE110
000078d1a57d6748  int3
000078d1a57d6749  call 0x000078D1A560A4B0
000078d1a57d674e  jmp 0x000078D1A57D5828
000078d1a57d6753  call 0x000078D1A5609240
000078d1a57d6758  jmp 0x000078D1A57D5832
000078d1a57d675d  call 0x000078D1A560A4B0
000078d1a57d6762  jmp 0x000078D1A57D588F
000078d1a57d6767  call 0x000078D1A5609240
000078d1a57d676c  jmp 0x000078D1A57D5899
000078d1a57d6771  call 0x000078D1A560A4B0
000078d1a57d6776  jmp 0x000078D1A57D58DD
000078d1a57d677b  call 0x000078D1A5609240
000078d1a57d6780  jmp 0x000078D1A57D58E7
000078d1a57d6785  call 0x000078D1A56B47C0
000078d1a57d678a  jmp 0x000078D1A57D5926
000078d1a57d678f  call 0x000078D1A560B720
000078d1a57d6794  jmp 0x000078D1A57D593A
000078d1a57d6799  call 0x000078D1A56BFC30
000078d1a57d679e  jmp 0x000078D1A57D5958
000078d1a57d67a3  call 0x000078D1A56BE9C0
000078d1a57d67a8  jmp 0x000078D1A57D5962
000078d1a57d67ad  call 0x000078D1A56BD750
000078d1a57d67b2  jmp 0x000078D1A57D596C
000078d1a57d67b7  sub rsp, 0x08
000078d1a57d67bb  push rax
000078d1a57d67bc  push rcx
000078d1a57d67bd  push rdx
000078d1a57d67be  push rdi
000078d1a57d67bf  push rsi
000078d1a57d67c0  push r8
000078d1a57d67c2  push r9
000078d1a57d67c4  push r10
000078d1a57d67c6  push r11
000078d1a57d67c8  sub rsp, 0xF0
000078d1a57d67cf  vmovaps [rsp], xmm0
000078d1a57d67d4  vmovaps [rsp+0x10], xmm1
000078d1a57d67da  vmovaps [rsp+0x20], xmm2
000078d1a57d67e0  vmovaps [rsp+0x30], xmm3
000078d1a57d67e6  vmovaps [rsp+0x40], xmm4
000078d1a57d67ec  vmovaps [rsp+0x50], xmm5
000078d1a57d67f2  vmovaps [rsp+0x60], xmm6
000078d1a57d67f8  vmovaps [rsp+0x70], xmm7
000078d1a57d67fe  vmovaps [rsp+0x80], xmm9
000078d1a57d6807  vmovaps [rsp+0x90], xmm10
000078d1a57d6810  vmovaps [rsp+0xA0], xmm11
000078d1a57d6819  vmovaps [rsp+0xB0], xmm12
000078d1a57d6822  vmovaps [rsp+0xC0], xmm13
000078d1a57d682b  vmovaps [rsp+0xD0], xmm14
000078d1a57d6834  vmovaps [rsp+0xE0], xmm15
000078d1a57d683d  sub rsp, 0x30
000078d1a57d6841  movaps [rsp], xmm8
000078d1a57d6846  movaps [rsp+0x10], xmm12
000078d1a57d684c  movaps [rsp+0x20], xmm15
000078d1a57d6852  lea rdi, [rsp]
000078d1a57d6856  mov esi, 0x00
000078d1a57d685b  mov rax, 0x56EA20A26530
000078d1a57d6865  call rax
000078d1a57d6867  movaps xmm8, [rsp]
000078d1a57d686c  add rsp, 0x30
000078d1a57d6870  vmovaps xmm0, [rsp]
000078d1a57d6875  vmovaps xmm1, [rsp+0x10]
000078d1a57d687b  vmovaps xmm2, [rsp+0x20]
000078d1a57d6881  vmovaps xmm3, [rsp+0x30]
000078d1a57d6887  vmovaps xmm4, [rsp+0x40]
000078d1a57d688d  vmovaps xmm5, [rsp+0x50]
000078d1a57d6893  vmovaps xmm6, [rsp+0x60]
000078d1a57d6899  vmovaps xmm7, [rsp+0x70]
000078d1a57d689f  vmovaps xmm9, [rsp+0x80]
000078d1a57d68a8  vmovaps xmm10, [rsp+0x90]
000078d1a57d68b1  vmovaps xmm11, [rsp+0xA0]
000078d1a57d68ba  vmovaps xmm12, [rsp+0xB0]
000078d1a57d68c3  vmovaps xmm13, [rsp+0xC0]
000078d1a57d68cc  vmovaps xmm14, [rsp+0xD0]
000078d1a57d68d5  vmovaps xmm15, [rsp+0xE0]
000078d1a57d68de  add rsp, 0xF0
000078d1a57d68e5  pop r11
000078d1a57d68e7  pop r10
000078d1a57d68e9  pop r9
000078d1a57d68eb  pop r8
000078d1a57d68ed  pop rsi
000078d1a57d68ee  pop rdi
000078d1a57d68ef  pop rdx
000078d1a57d68f0  pop rcx
000078d1a57d68f1  pop rax
000078d1a57d68f2  add rsp, 0x08
000078d1a57d68f6  jmp 0x000078D1A57D599A
000078d1a57d68fb  sub rsp, 0x08
000078d1a57d68ff  push rax
000078d1a57d6900  push rcx
000078d1a57d6901  push rdx
000078d1a57d6902  push rdi
000078d1a57d6903  push rsi
000078d1a57d6904  push r8
000078d1a57d6906  push r9
000078d1a57d6908  push r10
000078d1a57d690a  push r11
000078d1a57d690c  sub rsp, 0xF0
000078d1a57d6913  vmovaps [rsp], xmm0
000078d1a57d6918  vmovaps [rsp+0x10], xmm1
000078d1a57d691e  vmovaps [rsp+0x20], xmm2
000078d1a57d6924  vmovaps [rsp+0x30], xmm3
000078d1a57d692a  vmovaps [rsp+0x40], xmm4
000078d1a57d6930  vmovaps [rsp+0x50], xmm5
000078d1a57d6936  vmovaps [rsp+0x60], xmm6
000078d1a57d693c  vmovaps [rsp+0x70], xmm8
000078d1a57d6942  vmovaps [rsp+0x80], xmm9
000078d1a57d694b  vmovaps [rsp+0x90], xmm10
000078d1a57d6954  vmovaps [rsp+0xA0], xmm11
000078d1a57d695d  vmovaps [rsp+0xB0], xmm12
000078d1a57d6966  vmovaps [rsp+0xC0], xmm13
000078d1a57d696f  vmovaps [rsp+0xD0], xmm14
000078d1a57d6978  vmovaps [rsp+0xE0], xmm15
000078d1a57d6981  sub rsp, 0x30
000078d1a57d6985  movaps [rsp], xmm7
000078d1a57d6989  movaps [rsp+0x10], xmm9
000078d1a57d698f  movaps [rsp+0x20], xmm15
000078d1a57d6995  lea rdi, [rsp]
000078d1a57d6999  mov esi, 0x00
000078d1a57d699e  mov rax, 0x56EA20A26530
000078d1a57d69a8  call rax
000078d1a57d69aa  movaps xmm7, [rsp]
000078d1a57d69ae  add rsp, 0x30
000078d1a57d69b2  vmovaps xmm0, [rsp]
000078d1a57d69b7  vmovaps xmm1, [rsp+0x10]
000078d1a57d69bd  vmovaps xmm2, [rsp+0x20]
000078d1a57d69c3  vmovaps xmm3, [rsp+0x30]
000078d1a57d69c9  vmovaps xmm4, [rsp+0x40]
000078d1a57d69cf  vmovaps xmm5, [rsp+0x50]
000078d1a57d69d5  vmovaps xmm6, [rsp+0x60]
000078d1a57d69db  vmovaps xmm8, [rsp+0x70]
000078d1a57d69e1  vmovaps xmm9, [rsp+0x80]
000078d1a57d69ea  vmovaps xmm10, [rsp+0x90]
000078d1a57d69f3  vmovaps xmm11, [rsp+0xA0]
000078d1a57d69fc  vmovaps xmm12, [rsp+0xB0]
000078d1a57d6a05  vmovaps xmm13, [rsp+0xC0]
000078d1a57d6a0e  vmovaps xmm14, [rsp+0xD0]
000078d1a57d6a17  vmovaps xmm15, [rsp+0xE0]
000078d1a57d6a20  add rsp, 0xF0
000078d1a57d6a27  pop r11
000078d1a57d6a29  pop r10
000078d1a57d6a2b  pop r9
000078d1a57d6a2d  pop r8
000078d1a57d6a2f  pop rsi
000078d1a57d6a30  pop rdi
000078d1a57d6a31  pop rdx
000078d1a57d6a32  pop rcx
000078d1a57d6a33  pop rax
000078d1a57d6a34  add rsp, 0x08
000078d1a57d6a38  jmp 0x000078D1A57D59C8
000078d1a57d6a3d  sub rsp, 0x08
000078d1a57d6a41  push rax
000078d1a57d6a42  push rcx
000078d1a57d6a43  push rdx
000078d1a57d6a44  push rdi
000078d1a57d6a45  push rsi
000078d1a57d6a46  push r8
000078d1a57d6a48  push r9
000078d1a57d6a4a  push r10
000078d1a57d6a4c  push r11
000078d1a57d6a4e  sub rsp, 0xF0
000078d1a57d6a55  vmovaps [rsp], xmm0
000078d1a57d6a5a  vmovaps [rsp+0x10], xmm1
000078d1a57d6a60  vmovaps [rsp+0x20], xmm2
000078d1a57d6a66  vmovaps [rsp+0x30], xmm3
000078d1a57d6a6c  vmovaps [rsp+0x40], xmm4
000078d1a57d6a72  vmovaps [rsp+0x50], xmm5
000078d1a57d6a78  vmovaps [rsp+0x60], xmm6
000078d1a57d6a7e  vmovaps [rsp+0x70], xmm7
000078d1a57d6a84  vmovaps [rsp+0x80], xmm8
000078d1a57d6a8d  vmovaps [rsp+0x90], xmm10
000078d1a57d6a96  vmovaps [rsp+0xA0], xmm11
000078d1a57d6a9f  vmovaps [rsp+0xB0], xmm12
000078d1a57d6aa8  vmovaps [rsp+0xC0], xmm13
000078d1a57d6ab1  vmovaps [rsp+0xD0], xmm14
000078d1a57d6aba  vmovaps [rsp+0xE0], xmm15
000078d1a57d6ac3  sub rsp, 0x30
000078d1a57d6ac7  movaps [rsp], xmm9
000078d1a57d6acc  movaps [rsp+0x10], xmm12
000078d1a57d6ad2  movaps [rsp+0x20], xmm10
000078d1a57d6ad8  lea rdi, [rsp]
000078d1a57d6adc  mov esi, 0x00
000078d1a57d6ae1  mov rax, 0x56EA20A26530
000078d1a57d6aeb  call rax
000078d1a57d6aed  movaps xmm9, [rsp]
000078d1a57d6af2  add rsp, 0x30
000078d1a57d6af6  vmovaps xmm0, [rsp]
000078d1a57d6afb  vmovaps xmm1, [rsp+0x10]
000078d1a57d6b01  vmovaps xmm2, [rsp+0x20]
000078d1a57d6b07  vmovaps xmm3, [rsp+0x30]
000078d1a57d6b0d  vmovaps xmm4, [rsp+0x40]
000078d1a57d6b13  vmovaps xmm5, [rsp+0x50]
000078d1a57d6b19  vmovaps xmm6, [rsp+0x60]
000078d1a57d6b1f  vmovaps xmm7, [rsp+0x70]
000078d1a57d6b25  vmovaps xmm8, [rsp+0x80]
000078d1a57d6b2e  vmovaps xmm10, [rsp+0x90]
000078d1a57d6b37  vmovaps xmm11, [rsp+0xA0]
000078d1a57d6b40  vmovaps xmm12, [rsp+0xB0]
000078d1a57d6b49  vmovaps xmm13, [rsp+0xC0]
000078d1a57d6b52  vmovaps xmm14, [rsp+0xD0]
000078d1a57d6b5b  vmovaps xmm15, [rsp+0xE0]
000078d1a57d6b64  add rsp, 0xF0
000078d1a57d6b6b  pop r11
000078d1a57d6b6d  pop r10
000078d1a57d6b6f  pop r9
000078d1a57d6b71  pop r8
000078d1a57d6b73  pop rsi
000078d1a57d6b74  pop rdi
000078d1a57d6b75  pop rdx
000078d1a57d6b76  pop rcx
000078d1a57d6b77  pop rax
000078d1a57d6b78  add rsp, 0x08
000078d1a57d6b7c  jmp 0x000078D1A57D59EC
000078d1a57d6b81  sub rsp, 0x08
000078d1a57d6b85  push rax
000078d1a57d6b86  push rcx
000078d1a57d6b87  push rdx
000078d1a57d6b88  push rdi
000078d1a57d6b89  push rsi
000078d1a57d6b8a  push r8
000078d1a57d6b8c  push r9
000078d1a57d6b8e  push r10
000078d1a57d6b90  push r11
000078d1a57d6b92  sub rsp, 0xF0
000078d1a57d6b99  vmovaps [rsp], xmm0
000078d1a57d6b9e  vmovaps [rsp+0x10], xmm1
000078d1a57d6ba4  vmovaps [rsp+0x20], xmm2
000078d1a57d6baa  vmovaps [rsp+0x30], xmm3
000078d1a57d6bb0  vmovaps [rsp+0x40], xmm4
000078d1a57d6bb6  vmovaps [rsp+0x50], xmm5
000078d1a57d6bbc  vmovaps [rsp+0x60], xmm6
000078d1a57d6bc2  vmovaps [rsp+0x70], xmm7
000078d1a57d6bc8  vmovaps [rsp+0x80], xmm8
000078d1a57d6bd1  vmovaps [rsp+0x90], xmm9
000078d1a57d6bda  vmovaps [rsp+0xA0], xmm11
000078d1a57d6be3  vmovaps [rsp+0xB0], xmm12
000078d1a57d6bec  vmovaps [rsp+0xC0], xmm13
000078d1a57d6bf5  vmovaps [rsp+0xD0], xmm14
000078d1a57d6bfe  vmovaps [rsp+0xE0], xmm15
000078d1a57d6c07  sub rsp, 0x30
000078d1a57d6c0b  movaps [rsp], xmm10
000078d1a57d6c10  movaps [rsp+0x10], xmm12
000078d1a57d6c16  movaps [rsp+0x20], xmm11
000078d1a57d6c1c  lea rdi, [rsp]
000078d1a57d6c20  mov esi, 0x00
000078d1a57d6c25  mov rax, 0x56EA20A26530
000078d1a57d6c2f  call rax
000078d1a57d6c31  movaps xmm10, [rsp]
000078d1a57d6c36  add rsp, 0x30
000078d1a57d6c3a  vmovaps xmm0, [rsp]
000078d1a57d6c3f  vmovaps xmm1, [rsp+0x10]
000078d1a57d6c45  vmovaps xmm2, [rsp+0x20]
000078d1a57d6c4b  vmovaps xmm3, [rsp+0x30]
000078d1a57d6c51  vmovaps xmm4, [rsp+0x40]
000078d1a57d6c57  vmovaps xmm5, [rsp+0x50]
000078d1a57d6c5d  vmovaps xmm6, [rsp+0x60]
000078d1a57d6c63  vmovaps xmm7, [rsp+0x70]
000078d1a57d6c69  vmovaps xmm8, [rsp+0x80]
000078d1a57d6c72  vmovaps xmm9, [rsp+0x90]
000078d1a57d6c7b  vmovaps xmm11, [rsp+0xA0]
000078d1a57d6c84  vmovaps xmm12, [rsp+0xB0]
000078d1a57d6c8d  vmovaps xmm13, [rsp+0xC0]
000078d1a57d6c96  vmovaps xmm14, [rsp+0xD0]
000078d1a57d6c9f  vmovaps xmm15, [rsp+0xE0]
000078d1a57d6ca8  add rsp, 0xF0
000078d1a57d6caf  pop r11
000078d1a57d6cb1  pop r10
000078d1a57d6cb3  pop r9
000078d1a57d6cb5  pop r8
000078d1a57d6cb7  pop rsi
000078d1a57d6cb8  pop rdi
000078d1a57d6cb9  pop rdx
000078d1a57d6cba  pop rcx
000078d1a57d6cbb  pop rax
000078d1a57d6cbc  add rsp, 0x08
000078d1a57d6cc0  jmp 0x000078D1A57D5A06
000078d1a57d6cc5  sub rsp, 0x08
000078d1a57d6cc9  push rax
000078d1a57d6cca  push rcx
000078d1a57d6ccb  push rdx
000078d1a57d6ccc  push rdi
000078d1a57d6ccd  push rsi
000078d1a57d6cce  push r8
000078d1a57d6cd0  push r9
000078d1a57d6cd2  push r10
000078d1a57d6cd4  push r11
000078d1a57d6cd6  sub rsp, 0xF0
000078d1a57d6cdd  vmovaps [rsp], xmm0
000078d1a57d6ce2  vmovaps [rsp+0x10], xmm1
000078d1a57d6ce8  vmovaps [rsp+0x20], xmm2
000078d1a57d6cee  vmovaps [rsp+0x30], xmm3
000078d1a57d6cf4  vmovaps [rsp+0x40], xmm4
000078d1a57d6cfa  vmovaps [rsp+0x50], xmm5
000078d1a57d6d00  vmovaps [rsp+0x60], xmm7
000078d1a57d6d06  vmovaps [rsp+0x70], xmm8
000078d1a57d6d0c  vmovaps [rsp+0x80], xmm9
000078d1a57d6d15  vmovaps [rsp+0x90], xmm10
000078d1a57d6d1e  vmovaps [rsp+0xA0], xmm11
000078d1a57d6d27  vmovaps [rsp+0xB0], xmm12
000078d1a57d6d30  vmovaps [rsp+0xC0], xmm13
000078d1a57d6d39  vmovaps [rsp+0xD0], xmm14
000078d1a57d6d42  vmovaps [rsp+0xE0], xmm15
000078d1a57d6d4b  sub rsp, 0x30
000078d1a57d6d4f  movaps [rsp], xmm6
000078d1a57d6d53  movaps [rsp+0x10], xmm12
000078d1a57d6d59  movaps [rsp+0x20], xmm11
000078d1a57d6d5f  lea rdi, [rsp]
000078d1a57d6d63  mov esi, 0x00
000078d1a57d6d68  mov rax, 0x56EA20A26530
000078d1a57d6d72  call rax
000078d1a57d6d74  movaps xmm6, [rsp]
000078d1a57d6d78  add rsp, 0x30
000078d1a57d6d7c  vmovaps xmm0, [rsp]
000078d1a57d6d81  vmovaps xmm1, [rsp+0x10]
000078d1a57d6d87  vmovaps xmm2, [rsp+0x20]
000078d1a57d6d8d  vmovaps xmm3, [rsp+0x30]
000078d1a57d6d93  vmovaps xmm4, [rsp+0x40]
000078d1a57d6d99  vmovaps xmm5, [rsp+0x50]
000078d1a57d6d9f  vmovaps xmm7, [rsp+0x60]
000078d1a57d6da5  vmovaps xmm8, [rsp+0x70]
000078d1a57d6dab  vmovaps xmm9, [rsp+0x80]
000078d1a57d6db4  vmovaps xmm10, [rsp+0x90]
000078d1a57d6dbd  vmovaps xmm11, [rsp+0xA0]
000078d1a57d6dc6  vmovaps xmm12, [rsp+0xB0]
000078d1a57d6dcf  vmovaps xmm13, [rsp+0xC0]
000078d1a57d6dd8  vmovaps xmm14, [rsp+0xD0]
000078d1a57d6de1  vmovaps xmm15, [rsp+0xE0]
000078d1a57d6dea  add rsp, 0xF0
000078d1a57d6df1  pop r11
000078d1a57d6df3  pop r10
000078d1a57d6df5  pop r9
000078d1a57d6df7  pop r8
000078d1a57d6df9  pop rsi
000078d1a57d6dfa  pop rdi
000078d1a57d6dfb  pop rdx
000078d1a57d6dfc  pop rcx
000078d1a57d6dfd  pop rax
000078d1a57d6dfe  add rsp, 0x08
000078d1a57d6e02  jmp 0x000078D1A57D5A27
000078d1a57d6e07  sub rsp, 0x08
000078d1a57d6e0b  push rax
000078d1a57d6e0c  push rcx
000078d1a57d6e0d  push rdx
000078d1a57d6e0e  push rdi
000078d1a57d6e0f  push rsi
000078d1a57d6e10  push r8
000078d1a57d6e12  push r9
000078d1a57d6e14  push r10
000078d1a57d6e16  push r11
000078d1a57d6e18  sub rsp, 0xF0
000078d1a57d6e1f  vmovaps [rsp], xmm0
000078d1a57d6e24  vmovaps [rsp+0x10], xmm1
000078d1a57d6e2a  vmovaps [rsp+0x20], xmm2
000078d1a57d6e30  vmovaps [rsp+0x30], xmm4
000078d1a57d6e36  vmovaps [rsp+0x40], xmm5
000078d1a57d6e3c  vmovaps [rsp+0x50], xmm6
000078d1a57d6e42  vmovaps [rsp+0x60], xmm7
000078d1a57d6e48  vmovaps [rsp+0x70], xmm8
000078d1a57d6e4e  vmovaps [rsp+0x80], xmm9
000078d1a57d6e57  vmovaps [rsp+0x90], xmm10
000078d1a57d6e60  vmovaps [rsp+0xA0], xmm11
000078d1a57d6e69  vmovaps [rsp+0xB0], xmm12
000078d1a57d6e72  vmovaps [rsp+0xC0], xmm13
000078d1a57d6e7b  vmovaps [rsp+0xD0], xmm14
000078d1a57d6e84  vmovaps [rsp+0xE0], xmm15
000078d1a57d6e8d  sub rsp, 0x30
000078d1a57d6e91  movaps [rsp], xmm3
000078d1a57d6e95  movaps [rsp+0x10], xmm5
000078d1a57d6e9a  movaps [rsp+0x20], xmm4
000078d1a57d6e9f  lea rdi, [rsp]
000078d1a57d6ea3  mov esi, 0x00
000078d1a57d6ea8  mov rax, 0x56EA20A26530
000078d1a57d6eb2  call rax
000078d1a57d6eb4  movaps xmm3, [rsp]
000078d1a57d6eb8  add rsp, 0x30
000078d1a57d6ebc  vmovaps xmm0, [rsp]
000078d1a57d6ec1  vmovaps xmm1, [rsp+0x10]
000078d1a57d6ec7  vmovaps xmm2, [rsp+0x20]
000078d1a57d6ecd  vmovaps xmm4, [rsp+0x30]
000078d1a57d6ed3  vmovaps xmm5, [rsp+0x40]
000078d1a57d6ed9  vmovaps xmm6, [rsp+0x50]
000078d1a57d6edf  vmovaps xmm7, [rsp+0x60]
000078d1a57d6ee5  vmovaps xmm8, [rsp+0x70]
000078d1a57d6eeb  vmovaps xmm9, [rsp+0x80]
000078d1a57d6ef4  vmovaps xmm10, [rsp+0x90]
000078d1a57d6efd  vmovaps xmm11, [rsp+0xA0]
000078d1a57d6f06  vmovaps xmm12, [rsp+0xB0]
000078d1a57d6f0f  vmovaps xmm13, [rsp+0xC0]
000078d1a57d6f18  vmovaps xmm14, [rsp+0xD0]
000078d1a57d6f21  vmovaps xmm15, [rsp+0xE0]
000078d1a57d6f2a  add rsp, 0xF0
000078d1a57d6f31  pop r11
000078d1a57d6f33  pop r10
000078d1a57d6f35  pop r9
000078d1a57d6f37  pop r8
000078d1a57d6f39  pop rsi
000078d1a57d6f3a  pop rdi
000078d1a57d6f3b  pop rdx
000078d1a57d6f3c  pop rcx
000078d1a57d6f3d  pop rax
000078d1a57d6f3e  add rsp, 0x08
000078d1a57d6f42  jmp 0x000078D1A57D5A88
000078d1a57d6f47  sub rsp, 0x08
000078d1a57d6f4b  push rax
000078d1a57d6f4c  push rcx
000078d1a57d6f4d  push rdx
000078d1a57d6f4e  push rdi
000078d1a57d6f4f  push rsi
000078d1a57d6f50  push r8
000078d1a57d6f52  push r9
000078d1a57d6f54  push r10
000078d1a57d6f56  push r11
000078d1a57d6f58  sub rsp, 0xF0
000078d1a57d6f5f  vmovaps [rsp], xmm0
000078d1a57d6f64  vmovaps [rsp+0x10], xmm1
000078d1a57d6f6a  vmovaps [rsp+0x20], xmm2
000078d1a57d6f70  vmovaps [rsp+0x30], xmm3
000078d1a57d6f76  vmovaps [rsp+0x40], xmm4
000078d1a57d6f7c  vmovaps [rsp+0x50], xmm6
000078d1a57d6f82  vmovaps [rsp+0x60], xmm7
000078d1a57d6f88  vmovaps [rsp+0x70], xmm8
000078d1a57d6f8e  vmovaps [rsp+0x80], xmm9
000078d1a57d6f97  vmovaps [rsp+0x90], xmm10
000078d1a57d6fa0  vmovaps [rsp+0xA0], xmm11
000078d1a57d6fa9  vmovaps [rsp+0xB0], xmm12
000078d1a57d6fb2  vmovaps [rsp+0xC0], xmm13
000078d1a57d6fbb  vmovaps [rsp+0xD0], xmm14
000078d1a57d6fc4  vmovaps [rsp+0xE0], xmm15
000078d1a57d6fcd  sub rsp, 0x30
000078d1a57d6fd1  movaps [rsp], xmm5
000078d1a57d6fd5  movaps [rsp+0x10], xmm8
000078d1a57d6fdb  movaps [rsp+0x20], xmm15
000078d1a57d6fe1  lea rdi, [rsp]
000078d1a57d6fe5  mov esi, 0x00
000078d1a57d6fea  mov rax, 0x56EA20A26530
000078d1a57d6ff4  call rax
000078d1a57d6ff6  movaps xmm5, [rsp]
000078d1a57d6ffa  add rsp, 0x30
000078d1a57d6ffe  vmovaps xmm0, [rsp]
000078d1a57d7003  vmovaps xmm1, [rsp+0x10]
000078d1a57d7009  vmovaps xmm2, [rsp+0x20]
000078d1a57d700f  vmovaps xmm3, [rsp+0x30]
000078d1a57d7015  vmovaps xmm4, [rsp+0x40]
000078d1a57d701b  vmovaps xmm6, [rsp+0x50]
000078d1a57d7021  vmovaps xmm7, [rsp+0x60]
000078d1a57d7027  vmovaps xmm8, [rsp+0x70]
000078d1a57d702d  vmovaps xmm9, [rsp+0x80]
000078d1a57d7036  vmovaps xmm10, [rsp+0x90]
000078d1a57d703f  vmovaps xmm11, [rsp+0xA0]
000078d1a57d7048  vmovaps xmm12, [rsp+0xB0]
000078d1a57d7051  vmovaps xmm13, [rsp+0xC0]
000078d1a57d705a  vmovaps xmm14, [rsp+0xD0]
000078d1a57d7063  vmovaps xmm15, [rsp+0xE0]
000078d1a57d706c  add rsp, 0xF0
000078d1a57d7073  pop r11
000078d1a57d7075  pop r10
000078d1a57d7077  pop r9
000078d1a57d7079  pop r8
000078d1a57d707b  pop rsi
000078d1a57d707c  pop rdi
000078d1a57d707d  pop rdx
000078d1a57d707e  pop rcx
000078d1a57d707f  pop rax
000078d1a57d7080  add rsp, 0x08
000078d1a57d7084  jmp 0x000078D1A57D5AC0
000078d1a57d7089  sub rsp, 0x08
000078d1a57d708d  push rax
000078d1a57d708e  push rcx
000078d1a57d708f  push rdx
000078d1a57d7090  push rdi
000078d1a57d7091  push rsi
000078d1a57d7092  push r8
000078d1a57d7094  push r9
000078d1a57d7096  push r10
000078d1a57d7098  push r11
000078d1a57d709a  sub rsp, 0xF0
000078d1a57d70a1  vmovaps [rsp], xmm0
000078d1a57d70a6  vmovaps [rsp+0x10], xmm1
000078d1a57d70ac  vmovaps [rsp+0x20], xmm2
000078d1a57d70b2  vmovaps [rsp+0x30], xmm3
000078d1a57d70b8  vmovaps [rsp+0x40], xmm5
000078d1a57d70be  vmovaps [rsp+0x50], xmm6
000078d1a57d70c4  vmovaps [rsp+0x60], xmm7
000078d1a57d70ca  vmovaps [rsp+0x70], xmm8
000078d1a57d70d0  vmovaps [rsp+0x80], xmm9
000078d1a57d70d9  vmovaps [rsp+0x90], xmm10
000078d1a57d70e2  vmovaps [rsp+0xA0], xmm11
000078d1a57d70eb  vmovaps [rsp+0xB0], xmm12
000078d1a57d70f4  vmovaps [rsp+0xC0], xmm13
000078d1a57d70fd  vmovaps [rsp+0xD0], xmm14
000078d1a57d7106  vmovaps [rsp+0xE0], xmm15
000078d1a57d710f  sub rsp, 0x30
000078d1a57d7113  movaps [rsp], xmm4
000078d1a57d7117  movaps [rsp+0x10], xmm9
000078d1a57d711d  movaps [rsp+0x20], xmm8
000078d1a57d7123  lea rdi, [rsp]
000078d1a57d7127  mov esi, 0x00
000078d1a57d712c  mov rax, 0x56EA20A26530
000078d1a57d7136  call rax
000078d1a57d7138  movaps xmm4, [rsp]
000078d1a57d713c  add rsp, 0x30
000078d1a57d7140  vmovaps xmm0, [rsp]
000078d1a57d7145  vmovaps xmm1, [rsp+0x10]
000078d1a57d714b  vmovaps xmm2, [rsp+0x20]
000078d1a57d7151  vmovaps xmm3, [rsp+0x30]
000078d1a57d7157  vmovaps xmm5, [rsp+0x40]
000078d1a57d715d  vmovaps xmm6, [rsp+0x50]
000078d1a57d7163  vmovaps xmm7, [rsp+0x60]
000078d1a57d7169  vmovaps xmm8, [rsp+0x70]
000078d1a57d716f  vmovaps xmm9, [rsp+0x80]
000078d1a57d7178  vmovaps xmm10, [rsp+0x90]
000078d1a57d7181  vmovaps xmm11, [rsp+0xA0]
000078d1a57d718a  vmovaps xmm12, [rsp+0xB0]
000078d1a57d7193  vmovaps xmm13, [rsp+0xC0]
000078d1a57d719c  vmovaps xmm14, [rsp+0xD0]
000078d1a57d71a5  vmovaps xmm15, [rsp+0xE0]
000078d1a57d71ae  add rsp, 0xF0
000078d1a57d71b5  pop r11
000078d1a57d71b7  pop r10
000078d1a57d71b9  pop r9
000078d1a57d71bb  pop r8
000078d1a57d71bd  pop rsi
000078d1a57d71be  pop rdi
000078d1a57d71bf  pop rdx
000078d1a57d71c0  pop rcx
000078d1a57d71c1  pop rax
000078d1a57d71c2  add rsp, 0x08
000078d1a57d71c6  jmp 0x000078D1A57D5AE1
000078d1a57d71cb  sub rsp, 0x08
000078d1a57d71cf  push rax
000078d1a57d71d0  push rcx
000078d1a57d71d1  push rdx
000078d1a57d71d2  push rdi
000078d1a57d71d3  push rsi
000078d1a57d71d4  push r8
000078d1a57d71d6  push r9
000078d1a57d71d8  push r10
000078d1a57d71da  push r11
000078d1a57d71dc  sub rsp, 0xF0
000078d1a57d71e3  vmovaps [rsp], xmm0
000078d1a57d71e8  vmovaps [rsp+0x10], xmm1
000078d1a57d71ee  vmovaps [rsp+0x20], xmm2
000078d1a57d71f4  vmovaps [rsp+0x30], xmm3
000078d1a57d71fa  vmovaps [rsp+0x40], xmm4
000078d1a57d7200  vmovaps [rsp+0x50], xmm5
000078d1a57d7206  vmovaps [rsp+0x60], xmm6
000078d1a57d720c  vmovaps [rsp+0x70], xmm7
000078d1a57d7212  vmovaps [rsp+0x80], xmm8
000078d1a57d721b  vmovaps [rsp+0x90], xmm10
000078d1a57d7224  vmovaps [rsp+0xA0], xmm11
000078d1a57d722d  vmovaps [rsp+0xB0], xmm12
000078d1a57d7236  vmovaps [rsp+0xC0], xmm13
000078d1a57d723f  vmovaps [rsp+0xD0], xmm14
000078d1a57d7248  vmovaps [rsp+0xE0], xmm15
000078d1a57d7251  sub rsp, 0x30
000078d1a57d7255  movaps [rsp], xmm9
000078d1a57d725a  movaps [rsp+0x10], xmm10
000078d1a57d7260  movaps [rsp+0x20], xmm8
000078d1a57d7266  lea rdi, [rsp]
000078d1a57d726a  mov esi, 0x00
000078d1a57d726f  mov rax, 0x56EA20A26530
000078d1a57d7279  call rax
000078d1a57d727b  movaps xmm9, [rsp]
000078d1a57d7280  add rsp, 0x30
000078d1a57d7284  vmovaps xmm0, [rsp]
000078d1a57d7289  vmovaps xmm1, [rsp+0x10]
000078d1a57d728f  vmovaps xmm2, [rsp+0x20]
000078d1a57d7295  vmovaps xmm3, [rsp+0x30]
000078d1a57d729b  vmovaps xmm4, [rsp+0x40]
000078d1a57d72a1  vmovaps xmm5, [rsp+0x50]
000078d1a57d72a7  vmovaps xmm6, [rsp+0x60]
000078d1a57d72ad  vmovaps xmm7, [rsp+0x70]
000078d1a57d72b3  vmovaps xmm8, [rsp+0x80]
000078d1a57d72bc  vmovaps xmm10, [rsp+0x90]
000078d1a57d72c5  vmovaps xmm11, [rsp+0xA0]
000078d1a57d72ce  vmovaps xmm12, [rsp+0xB0]
000078d1a57d72d7  vmovaps xmm13, [rsp+0xC0]
000078d1a57d72e0  vmovaps xmm14, [rsp+0xD0]
000078d1a57d72e9  vmovaps xmm15, [rsp+0xE0]
000078d1a57d72f2  add rsp, 0xF0
000078d1a57d72f9  pop r11
000078d1a57d72fb  pop r10
000078d1a57d72fd  pop r9
000078d1a57d72ff  pop r8
000078d1a57d7301  pop rsi
000078d1a57d7302  pop rdi
000078d1a57d7303  pop rdx
000078d1a57d7304  pop rcx
000078d1a57d7305  pop rax
000078d1a57d7306  add rsp, 0x08
000078d1a57d730a  jmp 0x000078D1A57D5AFB
000078d1a57d730f  call 0x000078D1A56D64F0
000078d1a57d7314  jmp 0x000078D1A57D5C15
000078d1a57d7319  call 0x000078D1A56D64F0
000078d1a57d731e  jmp 0x000078D1A57D5C2B
000078d1a57d7323  sub rsp, 0x08
000078d1a57d7327  push rax
000078d1a57d7328  push rcx
000078d1a57d7329  push rdx
000078d1a57d732a  push rdi
000078d1a57d732b  push rsi
000078d1a57d732c  push r8
000078d1a57d732e  push r9
000078d1a57d7330  push r10
000078d1a57d7332  push r11
000078d1a57d7334  sub rsp, 0xF0
000078d1a57d733b  vmovaps [rsp], xmm0
000078d1a57d7340  vmovaps [rsp+0x10], xmm2
000078d1a57d7346  vmovaps [rsp+0x20], xmm3
000078d1a57d734c  vmovaps [rsp+0x30], xmm4
000078d1a57d7352  vmovaps [rsp+0x40], xmm5
000078d1a57d7358  vmovaps [rsp+0x50], xmm6
000078d1a57d735e  vmovaps [rsp+0x60], xmm7
000078d1a57d7364  vmovaps [rsp+0x70], xmm8
000078d1a57d736a  vmovaps [rsp+0x80], xmm9
000078d1a57d7373  vmovaps [rsp+0x90], xmm10
000078d1a57d737c  vmovaps [rsp+0xA0], xmm11
000078d1a57d7385  vmovaps [rsp+0xB0], xmm12
000078d1a57d738e  vmovaps [rsp+0xC0], xmm13
000078d1a57d7397  vmovaps [rsp+0xD0], xmm14
000078d1a57d73a0  vmovaps [rsp+0xE0], xmm15
000078d1a57d73a9  sub rsp, 0x30
000078d1a57d73ad  movaps [rsp], xmm1
000078d1a57d73b1  movaps [rsp+0x10], xmm6
000078d1a57d73b6  movaps [rsp+0x20], xmm15
000078d1a57d73bc  lea rdi, [rsp]
000078d1a57d73c0  mov esi, 0x00
000078d1a57d73c5  mov rax, 0x56EA20A26530
000078d1a57d73cf  call rax
000078d1a57d73d1  movaps xmm1, [rsp]
000078d1a57d73d5  add rsp, 0x30
000078d1a57d73d9  vmovaps xmm0, [rsp]
000078d1a57d73de  vmovaps xmm2, [rsp+0x10]
000078d1a57d73e4  vmovaps xmm3, [rsp+0x20]
000078d1a57d73ea  vmovaps xmm4, [rsp+0x30]
000078d1a57d73f0  vmovaps xmm5, [rsp+0x40]
000078d1a57d73f6  vmovaps xmm6, [rsp+0x50]
000078d1a57d73fc  vmovaps xmm7, [rsp+0x60]
000078d1a57d7402  vmovaps xmm8, [rsp+0x70]
000078d1a57d7408  vmovaps xmm9, [rsp+0x80]
000078d1a57d7411  vmovaps xmm10, [rsp+0x90]
000078d1a57d741a  vmovaps xmm11, [rsp+0xA0]
000078d1a57d7423  vmovaps xmm12, [rsp+0xB0]
000078d1a57d742c  vmovaps xmm13, [rsp+0xC0]
000078d1a57d7435  vmovaps xmm14, [rsp+0xD0]
000078d1a57d743e  vmovaps xmm15, [rsp+0xE0]
000078d1a57d7447  add rsp, 0xF0
000078d1a57d744e  pop r11
000078d1a57d7450  pop r10
000078d1a57d7452  pop r9
000078d1a57d7454  pop r8
000078d1a57d7456  pop rsi
000078d1a57d7457  pop rdi
000078d1a57d7458  pop rdx
000078d1a57d7459  pop rcx
000078d1a57d745a  pop rax
000078d1a57d745b  add rsp, 0x08
000078d1a57d745f  jmp 0x000078D1A57D5C68
000078d1a57d7464  call 0x000078D1A56E5820
000078d1a57d7469  jmp 0x000078D1A57D5C75
000078d1a57d746e  sub rsp, 0x08
000078d1a57d7472  push rax
000078d1a57d7473  push rcx
000078d1a57d7474  push rdx
000078d1a57d7475  push rdi
000078d1a57d7476  push rsi
000078d1a57d7477  push r8
000078d1a57d7479  push r9
000078d1a57d747b  push r10
000078d1a57d747d  push r11
000078d1a57d747f  sub rsp, 0xF0
000078d1a57d7486  vmovaps [rsp], xmm0
000078d1a57d748b  vmovaps [rsp+0x10], xmm1
000078d1a57d7491  vmovaps [rsp+0x20], xmm2
000078d1a57d7497  vmovaps [rsp+0x30], xmm3
000078d1a57d749d  vmovaps [rsp+0x40], xmm4
000078d1a57d74a3  vmovaps [rsp+0x50], xmm5
000078d1a57d74a9  vmovaps [rsp+0x60], xmm6
000078d1a57d74af  vmovaps [rsp+0x70], xmm7
000078d1a57d74b5  vmovaps [rsp+0x80], xmm8
000078d1a57d74be  vmovaps [rsp+0x90], xmm9
000078d1a57d74c7  vmovaps [rsp+0xA0], xmm10
000078d1a57d74d0  vmovaps [rsp+0xB0], xmm11
000078d1a57d74d9  vmovaps [rsp+0xC0], xmm12
000078d1a57d74e2  vmovaps [rsp+0xD0], xmm13
000078d1a57d74eb  vmovaps [rsp+0xE0], xmm15
000078d1a57d74f4  sub rsp, 0x30
000078d1a57d74f8  movaps [rsp], xmm14
000078d1a57d74fd  movaps [rsp+0x10], xmm4
000078d1a57d7502  movaps [rsp+0x20], xmm3
000078d1a57d7507  lea rdi, [rsp]
000078d1a57d750b  mov esi, 0x00
000078d1a57d7510  mov rax, 0x56EA20A26530
000078d1a57d751a  call rax
000078d1a57d751c  movaps xmm14, [rsp]
000078d1a57d7521  add rsp, 0x30
000078d1a57d7525  vmovaps xmm0, [rsp]
000078d1a57d752a  vmovaps xmm1, [rsp+0x10]
000078d1a57d7530  vmovaps xmm2, [rsp+0x20]
000078d1a57d7536  vmovaps xmm3, [rsp+0x30]
000078d1a57d753c  vmovaps xmm4, [rsp+0x40]
000078d1a57d7542  vmovaps xmm5, [rsp+0x50]
000078d1a57d7548  vmovaps xmm6, [rsp+0x60]
000078d1a57d754e  vmovaps xmm7, [rsp+0x70]
000078d1a57d7554  vmovaps xmm8, [rsp+0x80]
000078d1a57d755d  vmovaps xmm9, [rsp+0x90]
000078d1a57d7566  vmovaps xmm10, [rsp+0xA0]
000078d1a57d756f  vmovaps xmm11, [rsp+0xB0]
000078d1a57d7578  vmovaps xmm12, [rsp+0xC0]
000078d1a57d7581  vmovaps xmm13, [rsp+0xD0]
000078d1a57d758a  vmovaps xmm15, [rsp+0xE0]
000078d1a57d7593  add rsp, 0xF0
000078d1a57d759a  pop r11
000078d1a57d759c  pop r10
000078d1a57d759e  pop r9
000078d1a57d75a0  pop r8
000078d1a57d75a2  pop rsi
000078d1a57d75a3  pop rdi
000078d1a57d75a4  pop rdx
000078d1a57d75a5  pop rcx
000078d1a57d75a6  pop rax
000078d1a57d75a7  add rsp, 0x08
000078d1a57d75ab  jmp 0x000078D1A57D5C8F
000078d1a57d75b0  sub rsp, 0x08
000078d1a57d75b4  push rax
000078d1a57d75b5  push rcx
000078d1a57d75b6  push rdx
000078d1a57d75b7  push rdi
000078d1a57d75b8  push rsi
000078d1a57d75b9  push r8
000078d1a57d75bb  push r9
000078d1a57d75bd  push r10
000078d1a57d75bf  push r11
000078d1a57d75c1  sub rsp, 0xF0
000078d1a57d75c8  vmovaps [rsp], xmm0
000078d1a57d75cd  vmovaps [rsp+0x10], xmm1
000078d1a57d75d3  vmovaps [rsp+0x20], xmm2
000078d1a57d75d9  vmovaps [rsp+0x30], xmm3
000078d1a57d75df  vmovaps [rsp+0x40], xmm4
000078d1a57d75e5  vmovaps [rsp+0x50], xmm5
000078d1a57d75eb  vmovaps [rsp+0x60], xmm7
000078d1a57d75f1  vmovaps [rsp+0x70], xmm8
000078d1a57d75f7  vmovaps [rsp+0x80], xmm9
000078d1a57d7600  vmovaps [rsp+0x90], xmm10
000078d1a57d7609  vmovaps [rsp+0xA0], xmm11
000078d1a57d7612  vmovaps [rsp+0xB0], xmm12
000078d1a57d761b  vmovaps [rsp+0xC0], xmm13
000078d1a57d7624  vmovaps [rsp+0xD0], xmm14
000078d1a57d762d  vmovaps [rsp+0xE0], xmm15
000078d1a57d7636  sub rsp, 0x30
000078d1a57d763a  movaps [rsp], xmm6
000078d1a57d763e  movaps [rsp+0x10], xmm9
000078d1a57d7644  movaps [rsp+0x20], xmm7
000078d1a57d7649  lea rdi, [rsp]
000078d1a57d764d  mov esi, 0x00
000078d1a57d7652  mov rax, 0x56EA20A26530
000078d1a57d765c  call rax
000078d1a57d765e  movaps xmm6, [rsp]
000078d1a57d7662  add rsp, 0x30
000078d1a57d7666  vmovaps xmm0, [rsp]
000078d1a57d766b  vmovaps xmm1, [rsp+0x10]
000078d1a57d7671  vmovaps xmm2, [rsp+0x20]
000078d1a57d7677  vmovaps xmm3, [rsp+0x30]
000078d1a57d767d  vmovaps xmm4, [rsp+0x40]
000078d1a57d7683  vmovaps xmm5, [rsp+0x50]
000078d1a57d7689  vmovaps xmm7, [rsp+0x60]
000078d1a57d768f  vmovaps xmm8, [rsp+0x70]
000078d1a57d7695  vmovaps xmm9, [rsp+0x80]
000078d1a57d769e  vmovaps xmm10, [rsp+0x90]
000078d1a57d76a7  vmovaps xmm11, [rsp+0xA0]
000078d1a57d76b0  vmovaps xmm12, [rsp+0xB0]
000078d1a57d76b9  vmovaps xmm13, [rsp+0xC0]
000078d1a57d76c2  vmovaps xmm14, [rsp+0xD0]
000078d1a57d76cb  vmovaps xmm15, [rsp+0xE0]
000078d1a57d76d4  add rsp, 0xF0
000078d1a57d76db  pop r11
000078d1a57d76dd  pop r10
000078d1a57d76df  pop r9
000078d1a57d76e1  pop r8
000078d1a57d76e3  pop rsi
000078d1a57d76e4  pop rdi
000078d1a57d76e5  pop rdx
000078d1a57d76e6  pop rcx
000078d1a57d76e7  pop rax
000078d1a57d76e8  add rsp, 0x08
000078d1a57d76ec  jmp 0x000078D1A57D5CA7
000078d1a57d76f1  sub rsp, 0x08
000078d1a57d76f5  push rax
000078d1a57d76f6  push rcx
000078d1a57d76f7  push rdx
000078d1a57d76f8  push rdi
000078d1a57d76f9  push rsi
000078d1a57d76fa  push r8
000078d1a57d76fc  push r9
000078d1a57d76fe  push r10
000078d1a57d7700  push r11
000078d1a57d7702  sub rsp, 0xF0
000078d1a57d7709  vmovaps [rsp], xmm0
000078d1a57d770e  vmovaps [rsp+0x10], xmm1
000078d1a57d7714  vmovaps [rsp+0x20], xmm2
000078d1a57d771a  vmovaps [rsp+0x30], xmm3
000078d1a57d7720  vmovaps [rsp+0x40], xmm4
000078d1a57d7726  vmovaps [rsp+0x50], xmm5
000078d1a57d772c  vmovaps [rsp+0x60], xmm6
000078d1a57d7732  vmovaps [rsp+0x70], xmm8
000078d1a57d7738  vmovaps [rsp+0x80], xmm9
000078d1a57d7741  vmovaps [rsp+0x90], xmm10
000078d1a57d774a  vmovaps [rsp+0xA0], xmm11
000078d1a57d7753  vmovaps [rsp+0xB0], xmm12
000078d1a57d775c  vmovaps [rsp+0xC0], xmm13
000078d1a57d7765  vmovaps [rsp+0xD0], xmm14
000078d1a57d776e  vmovaps [rsp+0xE0], xmm15
000078d1a57d7777  sub rsp, 0x30
000078d1a57d777b  movaps [rsp], xmm7
000078d1a57d777f  movaps [rsp+0x10], xmm4
000078d1a57d7784  movaps [rsp+0x20], xmm9
000078d1a57d778a  lea rdi, [rsp]
000078d1a57d778e  mov esi, 0x00
000078d1a57d7793  mov rax, 0x56EA20A26530
000078d1a57d779d  call rax
000078d1a57d779f  movaps xmm7, [rsp]
000078d1a57d77a3  add rsp, 0x30
000078d1a57d77a7  vmovaps xmm0, [rsp]
000078d1a57d77ac  vmovaps xmm1, [rsp+0x10]
000078d1a57d77b2  vmovaps xmm2, [rsp+0x20]
000078d1a57d77b8  vmovaps xmm3, [rsp+0x30]
000078d1a57d77be  vmovaps xmm4, [rsp+0x40]
000078d1a57d77c4  vmovaps xmm5, [rsp+0x50]
000078d1a57d77ca  vmovaps xmm6, [rsp+0x60]
000078d1a57d77d0  vmovaps xmm8, [rsp+0x70]
000078d1a57d77d6  vmovaps xmm9, [rsp+0x80]
000078d1a57d77df  vmovaps xmm10, [rsp+0x90]
000078d1a57d77e8  vmovaps xmm11, [rsp+0xA0]
000078d1a57d77f1  vmovaps xmm12, [rsp+0xB0]
000078d1a57d77fa  vmovaps xmm13, [rsp+0xC0]
000078d1a57d7803  vmovaps xmm14, [rsp+0xD0]
000078d1a57d780c  vmovaps xmm15, [rsp+0xE0]
000078d1a57d7815  add rsp, 0xF0
000078d1a57d781c  pop r11
000078d1a57d781e  pop r10
000078d1a57d7820  pop r9
000078d1a57d7822  pop r8
000078d1a57d7824  pop rsi
000078d1a57d7825  pop rdi
000078d1a57d7826  pop rdx
000078d1a57d7827  pop rcx
000078d1a57d7828  pop rax
000078d1a57d7829  add rsp, 0x08
000078d1a57d782d  jmp 0x000078D1A57D5CD4
000078d1a57d7832  sub rsp, 0x08
000078d1a57d7836  push rax
000078d1a57d7837  push rcx
000078d1a57d7838  push rdx
000078d1a57d7839  push rdi
000078d1a57d783a  push rsi
000078d1a57d783b  push r8
000078d1a57d783d  push r9
000078d1a57d783f  push r10
000078d1a57d7841  push r11
000078d1a57d7843  sub rsp, 0xF0
000078d1a57d784a  vmovaps [rsp], xmm0
000078d1a57d784f  vmovaps [rsp+0x10], xmm1
000078d1a57d7855  vmovaps [rsp+0x20], xmm2
000078d1a57d785b  vmovaps [rsp+0x30], xmm3
000078d1a57d7861  vmovaps [rsp+0x40], xmm5
000078d1a57d7867  vmovaps [rsp+0x50], xmm6
000078d1a57d786d  vmovaps [rsp+0x60], xmm7
000078d1a57d7873  vmovaps [rsp+0x70], xmm8
000078d1a57d7879  vmovaps [rsp+0x80], xmm9
000078d1a57d7882  vmovaps [rsp+0x90], xmm10
000078d1a57d788b  vmovaps [rsp+0xA0], xmm11
000078d1a57d7894  vmovaps [rsp+0xB0], xmm12
000078d1a57d789d  vmovaps [rsp+0xC0], xmm13
000078d1a57d78a6  vmovaps [rsp+0xD0], xmm14
000078d1a57d78af  vmovaps [rsp+0xE0], xmm15
000078d1a57d78b8  sub rsp, 0x30
000078d1a57d78bc  movaps [rsp], xmm4
000078d1a57d78c0  movaps [rsp+0x10], xmm15
000078d1a57d78c6  movaps [rsp+0x20], xmm9
000078d1a57d78cc  lea rdi, [rsp]
000078d1a57d78d0  mov esi, 0x00
000078d1a57d78d5  mov rax, 0x56EA20A26530
000078d1a57d78df  call rax
000078d1a57d78e1  movaps xmm4, [rsp]
000078d1a57d78e5  add rsp, 0x30
000078d1a57d78e9  vmovaps xmm0, [rsp]
000078d1a57d78ee  vmovaps xmm1, [rsp+0x10]
000078d1a57d78f4  vmovaps xmm2, [rsp+0x20]
000078d1a57d78fa  vmovaps xmm3, [rsp+0x30]
000078d1a57d7900  vmovaps xmm5, [rsp+0x40]
000078d1a57d7906  vmovaps xmm6, [rsp+0x50]
000078d1a57d790c  vmovaps xmm7, [rsp+0x60]
000078d1a57d7912  vmovaps xmm8, [rsp+0x70]
000078d1a57d7918  vmovaps xmm9, [rsp+0x80]
000078d1a57d7921  vmovaps xmm10, [rsp+0x90]
000078d1a57d792a  vmovaps xmm11, [rsp+0xA0]
000078d1a57d7933  vmovaps xmm12, [rsp+0xB0]
000078d1a57d793c  vmovaps xmm13, [rsp+0xC0]
000078d1a57d7945  vmovaps xmm14, [rsp+0xD0]
000078d1a57d794e  vmovaps xmm15, [rsp+0xE0]
000078d1a57d7957  add rsp, 0xF0
000078d1a57d795e  pop r11
000078d1a57d7960  pop r10
000078d1a57d7962  pop r9
000078d1a57d7964  pop r8
000078d1a57d7966  pop rsi
000078d1a57d7967  pop rdi
000078d1a57d7968  pop rdx
000078d1a57d7969  pop rcx
000078d1a57d796a  pop rax
000078d1a57d796b  add rsp, 0x08
000078d1a57d796f  jmp 0x000078D1A57D5CF9
000078d1a57d7974  call 0x000078D1A56E5820
000078d1a57d7979  jmp 0x000078D1A57D5D06
000078d1a57d797e  sub rsp, 0x08
000078d1a57d7982  push rax
000078d1a57d7983  push rcx
000078d1a57d7984  push rdx
000078d1a57d7985  push rdi
000078d1a57d7986  push rsi
000078d1a57d7987  push r8
000078d1a57d7989  push r9
000078d1a57d798b  push r10
000078d1a57d798d  push r11
000078d1a57d798f  sub rsp, 0xF0
000078d1a57d7996  vmovaps [rsp], xmm0
000078d1a57d799b  vmovaps [rsp+0x10], xmm1
000078d1a57d79a1  vmovaps [rsp+0x20], xmm2
000078d1a57d79a7  vmovaps [rsp+0x30], xmm4
000078d1a57d79ad  vmovaps [rsp+0x40], xmm5
000078d1a57d79b3  vmovaps [rsp+0x50], xmm6
000078d1a57d79b9  vmovaps [rsp+0x60], xmm7
000078d1a57d79bf  vmovaps [rsp+0x70], xmm8
000078d1a57d79c5  vmovaps [rsp+0x80], xmm9
000078d1a57d79ce  vmovaps [rsp+0x90], xmm10
000078d1a57d79d7  vmovaps [rsp+0xA0], xmm11
000078d1a57d79e0  vmovaps [rsp+0xB0], xmm12
000078d1a57d79e9  vmovaps [rsp+0xC0], xmm13
000078d1a57d79f2  vmovaps [rsp+0xD0], xmm14
000078d1a57d79fb  vmovaps [rsp+0xE0], xmm15
000078d1a57d7a04  sub rsp, 0x30
000078d1a57d7a08  movaps [rsp], xmm3
000078d1a57d7a0c  movaps [rsp+0x10], xmm1
000078d1a57d7a11  movaps [rsp+0x20], xmm9
000078d1a57d7a17  lea rdi, [rsp]
000078d1a57d7a1b  mov esi, 0x00
000078d1a57d7a20  mov rax, 0x56EA20A26530
000078d1a57d7a2a  call rax
000078d1a57d7a2c  movaps xmm3, [rsp]
000078d1a57d7a30  add rsp, 0x30
000078d1a57d7a34  vmovaps xmm0, [rsp]
000078d1a57d7a39  vmovaps xmm1, [rsp+0x10]
000078d1a57d7a3f  vmovaps xmm2, [rsp+0x20]
000078d1a57d7a45  vmovaps xmm4, [rsp+0x30]
000078d1a57d7a4b  vmovaps xmm5, [rsp+0x40]
000078d1a57d7a51  vmovaps xmm6, [rsp+0x50]
000078d1a57d7a57  vmovaps xmm7, [rsp+0x60]
000078d1a57d7a5d  vmovaps xmm8, [rsp+0x70]
000078d1a57d7a63  vmovaps xmm9, [rsp+0x80]
000078d1a57d7a6c  vmovaps xmm10, [rsp+0x90]
000078d1a57d7a75  vmovaps xmm11, [rsp+0xA0]
000078d1a57d7a7e  vmovaps xmm12, [rsp+0xB0]
000078d1a57d7a87  vmovaps xmm13, [rsp+0xC0]
000078d1a57d7a90  vmovaps xmm14, [rsp+0xD0]
000078d1a57d7a99  vmovaps xmm15, [rsp+0xE0]
000078d1a57d7aa2  add rsp, 0xF0
000078d1a57d7aa9  pop r11
000078d1a57d7aab  pop r10
000078d1a57d7aad  pop r9
000078d1a57d7aaf  pop r8
000078d1a57d7ab1  pop rsi
000078d1a57d7ab2  pop rdi
000078d1a57d7ab3  pop rdx
000078d1a57d7ab4  pop rcx
000078d1a57d7ab5  pop rax
000078d1a57d7ab6  add rsp, 0x08
000078d1a57d7aba  jmp 0x000078D1A57D5D43
000078d1a57d7abf  sub rsp, 0x08
000078d1a57d7ac3  push rax
000078d1a57d7ac4  push rcx
000078d1a57d7ac5  push rdx
000078d1a57d7ac6  push rdi
000078d1a57d7ac7  push rsi
000078d1a57d7ac8  push r8
000078d1a57d7aca  push r9
000078d1a57d7acc  push r10
000078d1a57d7ace  push r11
000078d1a57d7ad0  sub rsp, 0xF0
000078d1a57d7ad7  vmovaps [rsp], xmm0
000078d1a57d7adc  vmovaps [rsp+0x10], xmm2
000078d1a57d7ae2  vmovaps [rsp+0x20], xmm3
000078d1a57d7ae8  vmovaps [rsp+0x30], xmm4
000078d1a57d7aee  vmovaps [rsp+0x40], xmm5
000078d1a57d7af4  vmovaps [rsp+0x50], xmm6
000078d1a57d7afa  vmovaps [rsp+0x60], xmm7
000078d1a57d7b00  vmovaps [rsp+0x70], xmm8
000078d1a57d7b06  vmovaps [rsp+0x80], xmm9
000078d1a57d7b0f  vmovaps [rsp+0x90], xmm10
000078d1a57d7b18  vmovaps [rsp+0xA0], xmm11
000078d1a57d7b21  vmovaps [rsp+0xB0], xmm12
000078d1a57d7b2a  vmovaps [rsp+0xC0], xmm13
000078d1a57d7b33  vmovaps [rsp+0xD0], xmm14
000078d1a57d7b3c  vmovaps [rsp+0xE0], xmm15
000078d1a57d7b45  sub rsp, 0x30
000078d1a57d7b49  movaps [rsp], xmm1
000078d1a57d7b4d  movaps [rsp+0x10], xmm15
000078d1a57d7b53  movaps [rsp+0x20], xmm9
000078d1a57d7b59  lea rdi, [rsp]
000078d1a57d7b5d  mov esi, 0x00
000078d1a57d7b62  mov rax, 0x56EA20A26530
000078d1a57d7b6c  call rax
000078d1a57d7b6e  movaps xmm1, [rsp]
000078d1a57d7b72  add rsp, 0x30
000078d1a57d7b76  vmovaps xmm0, [rsp]
000078d1a57d7b7b  vmovaps xmm2, [rsp+0x10]
000078d1a57d7b81  vmovaps xmm3, [rsp+0x20]
000078d1a57d7b87  vmovaps xmm4, [rsp+0x30]
000078d1a57d7b8d  vmovaps xmm5, [rsp+0x40]
000078d1a57d7b93  vmovaps xmm6, [rsp+0x50]
000078d1a57d7b99  vmovaps xmm7, [rsp+0x60]
000078d1a57d7b9f  vmovaps xmm8, [rsp+0x70]
000078d1a57d7ba5  vmovaps xmm9, [rsp+0x80]
000078d1a57d7bae  vmovaps xmm10, [rsp+0x90]
000078d1a57d7bb7  vmovaps xmm11, [rsp+0xA0]
000078d1a57d7bc0  vmovaps xmm12, [rsp+0xB0]
000078d1a57d7bc9  vmovaps xmm13, [rsp+0xC0]
000078d1a57d7bd2  vmovaps xmm14, [rsp+0xD0]
000078d1a57d7bdb  vmovaps xmm15, [rsp+0xE0]
000078d1a57d7be4  add rsp, 0xF0
000078d1a57d7beb  pop r11
000078d1a57d7bed  pop r10
000078d1a57d7bef  pop r9
000078d1a57d7bf1  pop r8
000078d1a57d7bf3  pop rsi
000078d1a57d7bf4  pop rdi
000078d1a57d7bf5  pop rdx
000078d1a57d7bf6  pop rcx
000078d1a57d7bf7  pop rax
000078d1a57d7bf8  add rsp, 0x08
000078d1a57d7bfc  jmp 0x000078D1A57D5DCB
000078d1a57d7c01  call 0x000078D1A56E5820
000078d1a57d7c06  jmp 0x000078D1A57D5DD8
000078d1a57d7c0b  sub rsp, 0x08
000078d1a57d7c0f  push rax
000078d1a57d7c10  push rcx
000078d1a57d7c11  push rdx
000078d1a57d7c12  push rdi
000078d1a57d7c13  push rsi
000078d1a57d7c14  push r8
000078d1a57d7c16  push r9
000078d1a57d7c18  push r10
000078d1a57d7c1a  push r11
000078d1a57d7c1c  sub rsp, 0xF0
000078d1a57d7c23  vmovaps [rsp], xmm0
000078d1a57d7c28  vmovaps [rsp+0x10], xmm2
000078d1a57d7c2e  vmovaps [rsp+0x20], xmm3
000078d1a57d7c34  vmovaps [rsp+0x30], xmm4
000078d1a57d7c3a  vmovaps [rsp+0x40], xmm5
000078d1a57d7c40  vmovaps [rsp+0x50], xmm6
000078d1a57d7c46  vmovaps [rsp+0x60], xmm7
000078d1a57d7c4c  vmovaps [rsp+0x70], xmm8
000078d1a57d7c52  vmovaps [rsp+0x80], xmm9
000078d1a57d7c5b  vmovaps [rsp+0x90], xmm10
000078d1a57d7c64  vmovaps [rsp+0xA0], xmm11
000078d1a57d7c6d  vmovaps [rsp+0xB0], xmm12
000078d1a57d7c76  vmovaps [rsp+0xC0], xmm13
000078d1a57d7c7f  vmovaps [rsp+0xD0], xmm14
000078d1a57d7c88  vmovaps [rsp+0xE0], xmm15
000078d1a57d7c91  sub rsp, 0x30
000078d1a57d7c95  movaps [rsp], xmm1
000078d1a57d7c99  movaps [rsp+0x10], xmm5
000078d1a57d7c9e  movaps [rsp+0x20], xmm7
000078d1a57d7ca3  lea rdi, [rsp]
000078d1a57d7ca7  mov esi, 0x00
000078d1a57d7cac  mov rax, 0x56EA20A26530
000078d1a57d7cb6  call rax
000078d1a57d7cb8  movaps xmm1, [rsp]
000078d1a57d7cbc  add rsp, 0x30
000078d1a57d7cc0  vmovaps xmm0, [rsp]
000078d1a57d7cc5  vmovaps xmm2, [rsp+0x10]
000078d1a57d7ccb  vmovaps xmm3, [rsp+0x20]
000078d1a57d7cd1  vmovaps xmm4, [rsp+0x30]
000078d1a57d7cd7  vmovaps xmm5, [rsp+0x40]
000078d1a57d7cdd  vmovaps xmm6, [rsp+0x50]
000078d1a57d7ce3  vmovaps xmm7, [rsp+0x60]
000078d1a57d7ce9  vmovaps xmm8, [rsp+0x70]
000078d1a57d7cef  vmovaps xmm9, [rsp+0x80]
000078d1a57d7cf8  vmovaps xmm10, [rsp+0x90]
000078d1a57d7d01  vmovaps xmm11, [rsp+0xA0]
000078d1a57d7d0a  vmovaps xmm12, [rsp+0xB0]
000078d1a57d7d13  vmovaps xmm13, [rsp+0xC0]
000078d1a57d7d1c  vmovaps xmm14, [rsp+0xD0]
000078d1a57d7d25  vmovaps xmm15, [rsp+0xE0]
000078d1a57d7d2e  add rsp, 0xF0
000078d1a57d7d35  pop r11
000078d1a57d7d37  pop r10
000078d1a57d7d39  pop r9
000078d1a57d7d3b  pop r8
000078d1a57d7d3d  pop rsi
000078d1a57d7d3e  pop rdi
000078d1a57d7d3f  pop rdx
000078d1a57d7d40  pop rcx
000078d1a57d7d41  pop rax
000078d1a57d7d42  add rsp, 0x08
000078d1a57d7d46  jmp 0x000078D1A57D5E7D
000078d1a57d7d4b  sub rsp, 0x08
000078d1a57d7d4f  push rax
000078d1a57d7d50  push rcx
000078d1a57d7d51  push rdx
000078d1a57d7d52  push rdi
000078d1a57d7d53  push rsi
000078d1a57d7d54  push r8
000078d1a57d7d56  push r9
000078d1a57d7d58  push r10
000078d1a57d7d5a  push r11
000078d1a57d7d5c  sub rsp, 0xF0
000078d1a57d7d63  vmovaps [rsp], xmm0
000078d1a57d7d68  vmovaps [rsp+0x10], xmm1
000078d1a57d7d6e  vmovaps [rsp+0x20], xmm2
000078d1a57d7d74  vmovaps [rsp+0x30], xmm3
000078d1a57d7d7a  vmovaps [rsp+0x40], xmm4
000078d1a57d7d80  vmovaps [rsp+0x50], xmm5
000078d1a57d7d86  vmovaps [rsp+0x60], xmm6
000078d1a57d7d8c  vmovaps [rsp+0x70], xmm8
000078d1a57d7d92  vmovaps [rsp+0x80], xmm9
000078d1a57d7d9b  vmovaps [rsp+0x90], xmm10
000078d1a57d7da4  vmovaps [rsp+0xA0], xmm11
000078d1a57d7dad  vmovaps [rsp+0xB0], xmm12
000078d1a57d7db6  vmovaps [rsp+0xC0], xmm13
000078d1a57d7dbf  vmovaps [rsp+0xD0], xmm14
000078d1a57d7dc8  vmovaps [rsp+0xE0], xmm15
000078d1a57d7dd1  sub rsp, 0x30
000078d1a57d7dd5  movaps [rsp], xmm7
000078d1a57d7dd9  movaps [rsp+0x10], xmm5
000078d1a57d7dde  movaps [rsp+0x20], xmm15
000078d1a57d7de4  lea rdi, [rsp]
000078d1a57d7de8  mov esi, 0x00
000078d1a57d7ded  mov rax, 0x56EA20A26530
000078d1a57d7df7  call rax
000078d1a57d7df9  movaps xmm7, [rsp]
000078d1a57d7dfd  add rsp, 0x30
000078d1a57d7e01  vmovaps xmm0, [rsp]
000078d1a57d7e06  vmovaps xmm1, [rsp+0x10]
000078d1a57d7e0c  vmovaps xmm2, [rsp+0x20]
000078d1a57d7e12  vmovaps xmm3, [rsp+0x30]
000078d1a57d7e18  vmovaps xmm4, [rsp+0x40]
000078d1a57d7e1e  vmovaps xmm5, [rsp+0x50]
000078d1a57d7e24  vmovaps xmm6, [rsp+0x60]
000078d1a57d7e2a  vmovaps xmm8, [rsp+0x70]
000078d1a57d7e30  vmovaps xmm9, [rsp+0x80]
000078d1a57d7e39  vmovaps xmm10, [rsp+0x90]
000078d1a57d7e42  vmovaps xmm11, [rsp+0xA0]
000078d1a57d7e4b  vmovaps xmm12, [rsp+0xB0]
000078d1a57d7e54  vmovaps xmm13, [rsp+0xC0]
000078d1a57d7e5d  vmovaps xmm14, [rsp+0xD0]
000078d1a57d7e66  vmovaps xmm15, [rsp+0xE0]
000078d1a57d7e6f  add rsp, 0xF0
000078d1a57d7e76  pop r11
000078d1a57d7e78  pop r10
000078d1a57d7e7a  pop r9
000078d1a57d7e7c  pop r8
000078d1a57d7e7e  pop rsi
000078d1a57d7e7f  pop rdi
000078d1a57d7e80  pop rdx
000078d1a57d7e81  pop rcx
000078d1a57d7e82  pop rax
000078d1a57d7e83  add rsp, 0x08
000078d1a57d7e87  jmp 0x000078D1A57D5EB3
000078d1a57d7e8c  call 0x000078D1A56D64F0
000078d1a57d7e91  jmp 0x000078D1A57D5EC0
000078d1a57d7e96  sub rsp, 0x08
000078d1a57d7e9a  push rax
000078d1a57d7e9b  push rcx
000078d1a57d7e9c  push rdx
000078d1a57d7e9d  push rdi
000078d1a57d7e9e  push rsi
000078d1a57d7e9f  push r8
000078d1a57d7ea1  push r9
000078d1a57d7ea3  push r10
000078d1a57d7ea5  push r11
000078d1a57d7ea7  sub rsp, 0xF0
000078d1a57d7eae  vmovaps [rsp], xmm0
000078d1a57d7eb3  vmovaps [rsp+0x10], xmm1
000078d1a57d7eb9  vmovaps [rsp+0x20], xmm2
000078d1a57d7ebf  vmovaps [rsp+0x30], xmm3
000078d1a57d7ec5  vmovaps [rsp+0x40], xmm4
000078d1a57d7ecb  vmovaps [rsp+0x50], xmm5
000078d1a57d7ed1  vmovaps [rsp+0x60], xmm6
000078d1a57d7ed7  vmovaps [rsp+0x70], xmm7
000078d1a57d7edd  vmovaps [rsp+0x80], xmm8
000078d1a57d7ee6  vmovaps [rsp+0x90], xmm9
000078d1a57d7eef  vmovaps [rsp+0xA0], xmm10
000078d1a57d7ef8  vmovaps [rsp+0xB0], xmm11
000078d1a57d7f01  vmovaps [rsp+0xC0], xmm12
000078d1a57d7f0a  vmovaps [rsp+0xD0], xmm13
000078d1a57d7f13  vmovaps [rsp+0xE0], xmm14
000078d1a57d7f1c  sub rsp, 0x30
000078d1a57d7f20  movaps [rsp], xmm15
000078d1a57d7f25  movaps [rsp+0x10], xmm5
000078d1a57d7f2a  movaps [rsp+0x20], xmm3
000078d1a57d7f2f  lea rdi, [rsp]
000078d1a57d7f33  mov esi, 0x00
000078d1a57d7f38  mov rax, 0x56EA20A26530
000078d1a57d7f42  call rax
000078d1a57d7f44  movaps xmm15, [rsp]
000078d1a57d7f49  add rsp, 0x30
000078d1a57d7f4d  vmovaps xmm0, [rsp]
000078d1a57d7f52  vmovaps xmm1, [rsp+0x10]
000078d1a57d7f58  vmovaps xmm2, [rsp+0x20]
000078d1a57d7f5e  vmovaps xmm3, [rsp+0x30]
000078d1a57d7f64  vmovaps xmm4, [rsp+0x40]
000078d1a57d7f6a  vmovaps xmm5, [rsp+0x50]
000078d1a57d7f70  vmovaps xmm6, [rsp+0x60]
000078d1a57d7f76  vmovaps xmm7, [rsp+0x70]
000078d1a57d7f7c  vmovaps xmm8, [rsp+0x80]
000078d1a57d7f85  vmovaps xmm9, [rsp+0x90]
000078d1a57d7f8e  vmovaps xmm10, [rsp+0xA0]
000078d1a57d7f97  vmovaps xmm11, [rsp+0xB0]
000078d1a57d7fa0  vmovaps xmm12, [rsp+0xC0]
000078d1a57d7fa9  vmovaps xmm13, [rsp+0xD0]
000078d1a57d7fb2  vmovaps xmm14, [rsp+0xE0]
000078d1a57d7fbb  add rsp, 0xF0
000078d1a57d7fc2  pop r11
000078d1a57d7fc4  pop r10
000078d1a57d7fc6  pop r9
000078d1a57d7fc8  pop r8
000078d1a57d7fca  pop rsi
000078d1a57d7fcb  pop rdi
000078d1a57d7fcc  pop rdx
000078d1a57d7fcd  pop rcx
000078d1a57d7fce  pop rax
000078d1a57d7fcf  add rsp, 0x08
000078d1a57d7fd3  jmp 0x000078D1A57D5EE6
000078d1a57d7fd8  sub rsp, 0x08
000078d1a57d7fdc  push rax
000078d1a57d7fdd  push rcx
000078d1a57d7fde  push rdx
000078d1a57d7fdf  push rdi
000078d1a57d7fe0  push rsi
000078d1a57d7fe1  push r8
000078d1a57d7fe3  push r9
000078d1a57d7fe5  push r10
000078d1a57d7fe7  push r11
000078d1a57d7fe9  sub rsp, 0xF0
000078d1a57d7ff0  vmovaps [rsp], xmm0
000078d1a57d7ff5  vmovaps [rsp+0x10], xmm2
000078d1a57d7ffb  vmovaps [rsp+0x20], xmm3
000078d1a57d8001  vmovaps [rsp+0x30], xmm4
000078d1a57d8007  vmovaps [rsp+0x40], xmm5
000078d1a57d800d  vmovaps [rsp+0x50], xmm6
000078d1a57d8013  vmovaps [rsp+0x60], xmm7
000078d1a57d8019  vmovaps [rsp+0x70], xmm8
000078d1a57d801f  vmovaps [rsp+0x80], xmm9
000078d1a57d8028  vmovaps [rsp+0x90], xmm10
000078d1a57d8031  vmovaps [rsp+0xA0], xmm11
000078d1a57d803a  vmovaps [rsp+0xB0], xmm12
000078d1a57d8043  vmovaps [rsp+0xC0], xmm13
000078d1a57d804c  vmovaps [rsp+0xD0], xmm14
000078d1a57d8055  vmovaps [rsp+0xE0], xmm15
000078d1a57d805e  sub rsp, 0x30
000078d1a57d8062  movaps [rsp], xmm1
000078d1a57d8066  movaps [rsp+0x10], xmm5
000078d1a57d806b  movaps [rsp+0x20], xmm4
000078d1a57d8070  lea rdi, [rsp]
000078d1a57d8074  mov esi, 0x00
000078d1a57d8079  mov rax, 0x56EA20A26530
000078d1a57d8083  call rax
000078d1a57d8085  movaps xmm1, [rsp]
000078d1a57d8089  add rsp, 0x30
000078d1a57d808d  vmovaps xmm0, [rsp]
000078d1a57d8092  vmovaps xmm2, [rsp+0x10]
000078d1a57d8098  vmovaps xmm3, [rsp+0x20]
000078d1a57d809e  vmovaps xmm4, [rsp+0x30]
000078d1a57d80a4  vmovaps xmm5, [rsp+0x40]
000078d1a57d80aa  vmovaps xmm6, [rsp+0x50]
000078d1a57d80b0  vmovaps xmm7, [rsp+0x60]
000078d1a57d80b6  vmovaps xmm8, [rsp+0x70]
000078d1a57d80bc  vmovaps xmm9, [rsp+0x80]
000078d1a57d80c5  vmovaps xmm10, [rsp+0x90]
000078d1a57d80ce  vmovaps xmm11, [rsp+0xA0]
000078d1a57d80d7  vmovaps xmm12, [rsp+0xB0]
000078d1a57d80e0  vmovaps xmm13, [rsp+0xC0]
000078d1a57d80e9  vmovaps xmm14, [rsp+0xD0]
000078d1a57d80f2  vmovaps xmm15, [rsp+0xE0]
000078d1a57d80fb  add rsp, 0xF0
000078d1a57d8102  pop r11
000078d1a57d8104  pop r10
000078d1a57d8106  pop r9
000078d1a57d8108  pop r8
000078d1a57d810a  pop rsi
000078d1a57d810b  pop rdi
000078d1a57d810c  pop rdx
000078d1a57d810d  pop rcx
000078d1a57d810e  pop rax
000078d1a57d810f  add rsp, 0x08
000078d1a57d8113  jmp 0x000078D1A57D5F06
000078d1a57d8118  sub rsp, 0x08
000078d1a57d811c  push rax
000078d1a57d811d  push rcx
000078d1a57d811e  push rdx
000078d1a57d811f  push rdi
000078d1a57d8120  push rsi
000078d1a57d8121  push r8
000078d1a57d8123  push r9
000078d1a57d8125  push r10
000078d1a57d8127  push r11
000078d1a57d8129  sub rsp, 0xF0
000078d1a57d8130  vmovaps [rsp], xmm0
000078d1a57d8135  vmovaps [rsp+0x10], xmm1
000078d1a57d813b  vmovaps [rsp+0x20], xmm2
000078d1a57d8141  vmovaps [rsp+0x30], xmm3
000078d1a57d8147  vmovaps [rsp+0x40], xmm5
000078d1a57d814d  vmovaps [rsp+0x50], xmm6
000078d1a57d8153  vmovaps [rsp+0x60], xmm7
000078d1a57d8159  vmovaps [rsp+0x70], xmm8
000078d1a57d815f  vmovaps [rsp+0x80], xmm9
000078d1a57d8168  vmovaps [rsp+0x90], xmm10
000078d1a57d8171  vmovaps [rsp+0xA0], xmm11
000078d1a57d817a  vmovaps [rsp+0xB0], xmm12
000078d1a57d8183  vmovaps [rsp+0xC0], xmm13
000078d1a57d818c  vmovaps [rsp+0xD0], xmm14
000078d1a57d8195  vmovaps [rsp+0xE0], xmm15
000078d1a57d819e  sub rsp, 0x30
000078d1a57d81a2  movaps [rsp], xmm4
000078d1a57d81a6  movaps [rsp+0x10], xmm3
000078d1a57d81ab  movaps [rsp+0x20], xmm5
000078d1a57d81b0  lea rdi, [rsp]
000078d1a57d81b4  mov esi, 0x00
000078d1a57d81b9  mov rax, 0x56EA20A26530
000078d1a57d81c3  call rax
000078d1a57d81c5  movaps xmm4, [rsp]
000078d1a57d81c9  add rsp, 0x30
000078d1a57d81cd  vmovaps xmm0, [rsp]
000078d1a57d81d2  vmovaps xmm1, [rsp+0x10]
000078d1a57d81d8  vmovaps xmm2, [rsp+0x20]
000078d1a57d81de  vmovaps xmm3, [rsp+0x30]
000078d1a57d81e4  vmovaps xmm5, [rsp+0x40]
000078d1a57d81ea  vmovaps xmm6, [rsp+0x50]
000078d1a57d81f0  vmovaps xmm7, [rsp+0x60]
000078d1a57d81f6  vmovaps xmm8, [rsp+0x70]
000078d1a57d81fc  vmovaps xmm9, [rsp+0x80]
000078d1a57d8205  vmovaps xmm10, [rsp+0x90]
000078d1a57d820e  vmovaps xmm11, [rsp+0xA0]
000078d1a57d8217  vmovaps xmm12, [rsp+0xB0]
000078d1a57d8220  vmovaps xmm13, [rsp+0xC0]
000078d1a57d8229  vmovaps xmm14, [rsp+0xD0]
000078d1a57d8232  vmovaps xmm15, [rsp+0xE0]
000078d1a57d823b  add rsp, 0xF0
000078d1a57d8242  pop r11
000078d1a57d8244  pop r10
000078d1a57d8246  pop r9
000078d1a57d8248  pop r8
000078d1a57d824a  pop rsi
000078d1a57d824b  pop rdi
000078d1a57d824c  pop rdx
000078d1a57d824d  pop rcx
000078d1a57d824e  pop rax
000078d1a57d824f  add rsp, 0x08
000078d1a57d8253  jmp 0x000078D1A57D5F54
000078d1a57d8258  call 0x000078D1A56D64F0
000078d1a57d825d  jmp 0x000078D1A57D5F61
000078d1a57d8262  sub rsp, 0x08
000078d1a57d8266  push rax
000078d1a57d8267  push rcx
000078d1a57d8268  push rdx
000078d1a57d8269  push rdi
000078d1a57d826a  push rsi
000078d1a57d826b  push r8
000078d1a57d826d  push r9
000078d1a57d826f  push r10
000078d1a57d8271  push r11
000078d1a57d8273  sub rsp, 0xF0
000078d1a57d827a  vmovaps [rsp], xmm0
000078d1a57d827f  vmovaps [rsp+0x10], xmm1
000078d1a57d8285  vmovaps [rsp+0x20], xmm2
000078d1a57d828b  vmovaps [rsp+0x30], xmm3
000078d1a57d8291  vmovaps [rsp+0x40], xmm4
000078d1a57d8297  vmovaps [rsp+0x50], xmm6
000078d1a57d829d  vmovaps [rsp+0x60], xmm7
000078d1a57d82a3  vmovaps [rsp+0x70], xmm8
000078d1a57d82a9  vmovaps [rsp+0x80], xmm9
000078d1a57d82b2  vmovaps [rsp+0x90], xmm10
000078d1a57d82bb  vmovaps [rsp+0xA0], xmm11
000078d1a57d82c4  vmovaps [rsp+0xB0], xmm12
000078d1a57d82cd  vmovaps [rsp+0xC0], xmm13
000078d1a57d82d6  vmovaps [rsp+0xD0], xmm14
000078d1a57d82df  vmovaps [rsp+0xE0], xmm15
000078d1a57d82e8  sub rsp, 0x30
000078d1a57d82ec  movaps [rsp], xmm5
000078d1a57d82f0  movaps [rsp+0x10], xmm6
000078d1a57d82f5  movaps [rsp+0x20], xmm3
000078d1a57d82fa  lea rdi, [rsp]
000078d1a57d82fe  mov esi, 0x00
000078d1a57d8303  mov rax, 0x56EA20A26530
000078d1a57d830d  call rax
000078d1a57d830f  movaps xmm5, [rsp]
000078d1a57d8313  add rsp, 0x30
000078d1a57d8317  vmovaps xmm0, [rsp]
000078d1a57d831c  vmovaps xmm1, [rsp+0x10]
000078d1a57d8322  vmovaps xmm2, [rsp+0x20]
000078d1a57d8328  vmovaps xmm3, [rsp+0x30]
000078d1a57d832e  vmovaps xmm4, [rsp+0x40]
000078d1a57d8334  vmovaps xmm6, [rsp+0x50]
000078d1a57d833a  vmovaps xmm7, [rsp+0x60]
000078d1a57d8340  vmovaps xmm8, [rsp+0x70]
000078d1a57d8346  vmovaps xmm9, [rsp+0x80]
000078d1a57d834f  vmovaps xmm10, [rsp+0x90]
000078d1a57d8358  vmovaps xmm11, [rsp+0xA0]
000078d1a57d8361  vmovaps xmm12, [rsp+0xB0]
000078d1a57d836a  vmovaps xmm13, [rsp+0xC0]
000078d1a57d8373  vmovaps xmm14, [rsp+0xD0]
000078d1a57d837c  vmovaps xmm15, [rsp+0xE0]
000078d1a57d8385  add rsp, 0xF0
000078d1a57d838c  pop r11
000078d1a57d838e  pop r10
000078d1a57d8390  pop r9
000078d1a57d8392  pop r8
000078d1a57d8394  pop rsi
000078d1a57d8395  pop rdi
000078d1a57d8396  pop rdx
000078d1a57d8397  pop rcx
000078d1a57d8398  pop rax
000078d1a57d8399  add rsp, 0x08
000078d1a57d839d  jmp 0x000078D1A57D5F87
000078d1a57d83a2  sub rsp, 0x08
000078d1a57d83a6  push rax
000078d1a57d83a7  push rcx
000078d1a57d83a8  push rdx
000078d1a57d83a9  push rdi
000078d1a57d83aa  push rsi
000078d1a57d83ab  push r8
000078d1a57d83ad  push r9
000078d1a57d83af  push r10
000078d1a57d83b1  push r11
000078d1a57d83b3  sub rsp, 0xF0
000078d1a57d83ba  vmovaps [rsp], xmm0
000078d1a57d83bf  vmovaps [rsp+0x10], xmm1
000078d1a57d83c5  vmovaps [rsp+0x20], xmm2
000078d1a57d83cb  vmovaps [rsp+0x30], xmm3
000078d1a57d83d1  vmovaps [rsp+0x40], xmm4
000078d1a57d83d7  vmovaps [rsp+0x50], xmm5
000078d1a57d83dd  vmovaps [rsp+0x60], xmm7
000078d1a57d83e3  vmovaps [rsp+0x70], xmm8
000078d1a57d83e9  vmovaps [rsp+0x80], xmm9
000078d1a57d83f2  vmovaps [rsp+0x90], xmm10
000078d1a57d83fb  vmovaps [rsp+0xA0], xmm11
000078d1a57d8404  vmovaps [rsp+0xB0], xmm12
000078d1a57d840d  vmovaps [rsp+0xC0], xmm13
000078d1a57d8416  vmovaps [rsp+0xD0], xmm14
000078d1a57d841f  vmovaps [rsp+0xE0], xmm15
000078d1a57d8428  sub rsp, 0x30
000078d1a57d842c  movaps [rsp], xmm6
000078d1a57d8430  movaps [rsp+0x10], xmm9
000078d1a57d8436  movaps [rsp+0x20], xmm1
000078d1a57d843b  lea rdi, [rsp]
000078d1a57d843f  mov esi, 0x00
000078d1a57d8444  mov rax, 0x56EA20A26530
000078d1a57d844e  call rax
000078d1a57d8450  movaps xmm6, [rsp]
000078d1a57d8454  add rsp, 0x30
000078d1a57d8458  vmovaps xmm0, [rsp]
000078d1a57d845d  vmovaps xmm1, [rsp+0x10]
000078d1a57d8463  vmovaps xmm2, [rsp+0x20]
000078d1a57d8469  vmovaps xmm3, [rsp+0x30]
000078d1a57d846f  vmovaps xmm4, [rsp+0x40]
000078d1a57d8475  vmovaps xmm5, [rsp+0x50]
000078d1a57d847b  vmovaps xmm7, [rsp+0x60]
000078d1a57d8481  vmovaps xmm8, [rsp+0x70]
000078d1a57d8487  vmovaps xmm9, [rsp+0x80]
000078d1a57d8490  vmovaps xmm10, [rsp+0x90]
000078d1a57d8499  vmovaps xmm11, [rsp+0xA0]
000078d1a57d84a2  vmovaps xmm12, [rsp+0xB0]
000078d1a57d84ab  vmovaps xmm13, [rsp+0xC0]
000078d1a57d84b4  vmovaps xmm14, [rsp+0xD0]
000078d1a57d84bd  vmovaps xmm15, [rsp+0xE0]
000078d1a57d84c6  add rsp, 0xF0
000078d1a57d84cd  pop r11
000078d1a57d84cf  pop r10
000078d1a57d84d1  pop r9
000078d1a57d84d3  pop r8
000078d1a57d84d5  pop rsi
000078d1a57d84d6  pop rdi
000078d1a57d84d7  pop rdx
000078d1a57d84d8  pop rcx
000078d1a57d84d9  pop rax
000078d1a57d84da  add rsp, 0x08
000078d1a57d84de  jmp 0x000078D1A57D5FAB
000078d1a57d84e3  sub rsp, 0x08
000078d1a57d84e7  push rax
000078d1a57d84e8  push rcx
000078d1a57d84e9  push rdx
000078d1a57d84ea  push rdi
000078d1a57d84eb  push rsi
000078d1a57d84ec  push r8
000078d1a57d84ee  push r9
000078d1a57d84f0  push r10
000078d1a57d84f2  push r11
000078d1a57d84f4  sub rsp, 0xF0
000078d1a57d84fb  vmovaps [rsp], xmm0
000078d1a57d8500  vmovaps [rsp+0x10], xmm1
000078d1a57d8506  vmovaps [rsp+0x20], xmm2
000078d1a57d850c  vmovaps [rsp+0x30], xmm3
000078d1a57d8512  vmovaps [rsp+0x40], xmm4
000078d1a57d8518  vmovaps [rsp+0x50], xmm5
000078d1a57d851e  vmovaps [rsp+0x60], xmm6
000078d1a57d8524  vmovaps [rsp+0x70], xmm7
000078d1a57d852a  vmovaps [rsp+0x80], xmm8
000078d1a57d8533  vmovaps [rsp+0x90], xmm10
000078d1a57d853c  vmovaps [rsp+0xA0], xmm11
000078d1a57d8545  vmovaps [rsp+0xB0], xmm12
000078d1a57d854e  vmovaps [rsp+0xC0], xmm13
000078d1a57d8557  vmovaps [rsp+0xD0], xmm14
000078d1a57d8560  vmovaps [rsp+0xE0], xmm15
000078d1a57d8569  sub rsp, 0x30
000078d1a57d856d  movaps [rsp], xmm9
000078d1a57d8572  movaps [rsp+0x10], xmm3
000078d1a57d8577  movaps [rsp+0x20], xmm1
000078d1a57d857c  lea rdi, [rsp]
000078d1a57d8580  mov esi, 0x00
000078d1a57d8585  mov rax, 0x56EA20A26530
000078d1a57d858f  call rax
000078d1a57d8591  movaps xmm9, [rsp]
000078d1a57d8596  add rsp, 0x30
000078d1a57d859a  vmovaps xmm0, [rsp]
000078d1a57d859f  vmovaps xmm1, [rsp+0x10]
000078d1a57d85a5  vmovaps xmm2, [rsp+0x20]
000078d1a57d85ab  vmovaps xmm3, [rsp+0x30]
000078d1a57d85b1  vmovaps xmm4, [rsp+0x40]
000078d1a57d85b7  vmovaps xmm5, [rsp+0x50]
000078d1a57d85bd  vmovaps xmm6, [rsp+0x60]
000078d1a57d85c3  vmovaps xmm7, [rsp+0x70]
000078d1a57d85c9  vmovaps xmm8, [rsp+0x80]
000078d1a57d85d2  vmovaps xmm10, [rsp+0x90]
000078d1a57d85db  vmovaps xmm11, [rsp+0xA0]
000078d1a57d85e4  vmovaps xmm12, [rsp+0xB0]
000078d1a57d85ed  vmovaps xmm13, [rsp+0xC0]
000078d1a57d85f6  vmovaps xmm14, [rsp+0xD0]
000078d1a57d85ff  vmovaps xmm15, [rsp+0xE0]
000078d1a57d8608  add rsp, 0xF0
000078d1a57d860f  pop r11
000078d1a57d8611  pop r10
000078d1a57d8613  pop r9
000078d1a57d8615  pop r8
000078d1a57d8617  pop rsi
000078d1a57d8618  pop rdi
000078d1a57d8619  pop rdx
000078d1a57d861a  pop rcx
000078d1a57d861b  pop rax
000078d1a57d861c  add rsp, 0x08
000078d1a57d8620  jmp 0x000078D1A57D5FF7
000078d1a57d8625  call 0x000078D1A56D64F0
000078d1a57d862a  jmp 0x000078D1A57D6004
000078d1a57d862f  sub rsp, 0x08
000078d1a57d8633  push rax
000078d1a57d8634  push rcx
000078d1a57d8635  push rdx
000078d1a57d8636  push rdi
000078d1a57d8637  push rsi
000078d1a57d8638  push r8
000078d1a57d863a  push r9
000078d1a57d863c  push r10
000078d1a57d863e  push r11
000078d1a57d8640  sub rsp, 0xF0
000078d1a57d8647  vmovaps [rsp], xmm0
000078d1a57d864c  vmovaps [rsp+0x10], xmm1
000078d1a57d8652  vmovaps [rsp+0x20], xmm2
000078d1a57d8658  vmovaps [rsp+0x30], xmm3
000078d1a57d865e  vmovaps [rsp+0x40], xmm4
000078d1a57d8664  vmovaps [rsp+0x50], xmm5
000078d1a57d866a  vmovaps [rsp+0x60], xmm6
000078d1a57d8670  vmovaps [rsp+0x70], xmm7
000078d1a57d8676  vmovaps [rsp+0x80], xmm8
000078d1a57d867f  vmovaps [rsp+0x90], xmm9
000078d1a57d8688  vmovaps [rsp+0xA0], xmm10
000078d1a57d8691  vmovaps [rsp+0xB0], xmm11
000078d1a57d869a  vmovaps [rsp+0xC0], xmm12
000078d1a57d86a3  vmovaps [rsp+0xD0], xmm13
000078d1a57d86ac  vmovaps [rsp+0xE0], xmm14
000078d1a57d86b5  sub rsp, 0x30
000078d1a57d86b9  movaps [rsp], xmm15
000078d1a57d86be  movaps [rsp+0x10], xmm3
000078d1a57d86c3  movaps [rsp+0x20], xmm7
000078d1a57d86c8  lea rdi, [rsp]
000078d1a57d86cc  mov esi, 0x00
000078d1a57d86d1  mov rax, 0x56EA20A26530
000078d1a57d86db  call rax
000078d1a57d86dd  movaps xmm15, [rsp]
000078d1a57d86e2  add rsp, 0x30
000078d1a57d86e6  vmovaps xmm0, [rsp]
000078d1a57d86eb  vmovaps xmm1, [rsp+0x10]
000078d1a57d86f1  vmovaps xmm2, [rsp+0x20]
000078d1a57d86f7  vmovaps xmm3, [rsp+0x30]
000078d1a57d86fd  vmovaps xmm4, [rsp+0x40]
000078d1a57d8703  vmovaps xmm5, [rsp+0x50]
000078d1a57d8709  vmovaps xmm6, [rsp+0x60]
000078d1a57d870f  vmovaps xmm7, [rsp+0x70]
000078d1a57d8715  vmovaps xmm8, [rsp+0x80]
000078d1a57d871e  vmovaps xmm9, [rsp+0x90]
000078d1a57d8727  vmovaps xmm10, [rsp+0xA0]
000078d1a57d8730  vmovaps xmm11, [rsp+0xB0]
000078d1a57d8739  vmovaps xmm12, [rsp+0xC0]
000078d1a57d8742  vmovaps xmm13, [rsp+0xD0]
000078d1a57d874b  vmovaps xmm14, [rsp+0xE0]
000078d1a57d8754  add rsp, 0xF0
000078d1a57d875b  pop r11
000078d1a57d875d  pop r10
000078d1a57d875f  pop r9
000078d1a57d8761  pop r8
000078d1a57d8763  pop rsi
000078d1a57d8764  pop rdi
000078d1a57d8765  pop rdx
000078d1a57d8766  pop rcx
000078d1a57d8767  pop rax
000078d1a57d8768  add rsp, 0x08
000078d1a57d876c  jmp 0x000078D1A57D6030
000078d1a57d8771  sub rsp, 0x08
000078d1a57d8775  push rax
000078d1a57d8776  push rcx
000078d1a57d8777  push rdx
000078d1a57d8778  push rdi
000078d1a57d8779  push rsi
000078d1a57d877a  push r8
000078d1a57d877c  push r9
000078d1a57d877e  push r10
000078d1a57d8780  push r11
000078d1a57d8782  sub rsp, 0xF0
000078d1a57d8789  vmovaps [rsp], xmm0
000078d1a57d878e  vmovaps [rsp+0x10], xmm1
000078d1a57d8794  vmovaps [rsp+0x20], xmm2
000078d1a57d879a  vmovaps [rsp+0x30], xmm4
000078d1a57d87a0  vmovaps [rsp+0x40], xmm5
000078d1a57d87a6  vmovaps [rsp+0x50], xmm6
000078d1a57d87ac  vmovaps [rsp+0x60], xmm7
000078d1a57d87b2  vmovaps [rsp+0x70], xmm8
000078d1a57d87b8  vmovaps [rsp+0x80], xmm9
000078d1a57d87c1  vmovaps [rsp+0x90], xmm10
000078d1a57d87ca  vmovaps [rsp+0xA0], xmm11
000078d1a57d87d3  vmovaps [rsp+0xB0], xmm12
000078d1a57d87dc  vmovaps [rsp+0xC0], xmm13
000078d1a57d87e5  vmovaps [rsp+0xD0], xmm14
000078d1a57d87ee  vmovaps [rsp+0xE0], xmm15
000078d1a57d87f7  sub rsp, 0x30
000078d1a57d87fb  movaps [rsp], xmm3
000078d1a57d87ff  movaps [rsp+0x10], xmm1
000078d1a57d8804  movaps [rsp+0x20], xmm15
000078d1a57d880a  lea rdi, [rsp]
000078d1a57d880e  mov esi, 0x00
000078d1a57d8813  mov rax, 0x56EA20A26530
000078d1a57d881d  call rax
000078d1a57d881f  movaps xmm3, [rsp]
000078d1a57d8823  add rsp, 0x30
000078d1a57d8827  vmovaps xmm0, [rsp]
000078d1a57d882c  vmovaps xmm1, [rsp+0x10]
000078d1a57d8832  vmovaps xmm2, [rsp+0x20]
000078d1a57d8838  vmovaps xmm4, [rsp+0x30]
000078d1a57d883e  vmovaps xmm5, [rsp+0x40]
000078d1a57d8844  vmovaps xmm6, [rsp+0x50]
000078d1a57d884a  vmovaps xmm7, [rsp+0x60]
000078d1a57d8850  vmovaps xmm8, [rsp+0x70]
000078d1a57d8856  vmovaps xmm9, [rsp+0x80]
000078d1a57d885f  vmovaps xmm10, [rsp+0x90]
000078d1a57d8868  vmovaps xmm11, [rsp+0xA0]
000078d1a57d8871  vmovaps xmm12, [rsp+0xB0]
000078d1a57d887a  vmovaps xmm13, [rsp+0xC0]
000078d1a57d8883  vmovaps xmm14, [rsp+0xD0]
000078d1a57d888c  vmovaps xmm15, [rsp+0xE0]
000078d1a57d8895  add rsp, 0xF0
000078d1a57d889c  pop r11
000078d1a57d889e  pop r10
000078d1a57d88a0  pop r9
000078d1a57d88a2  pop r8
000078d1a57d88a4  pop rsi
000078d1a57d88a5  pop rdi
000078d1a57d88a6  pop rdx
000078d1a57d88a7  pop rcx
000078d1a57d88a8  pop rax
000078d1a57d88a9  add rsp, 0x08
000078d1a57d88ad  jmp 0x000078D1A57D60BF
000078d1a57d88b2  call 0x000078D1A56D64F0
000078d1a57d88b7  jmp 0x000078D1A57D60C9
000078d1a57d88bc  sub rsp, 0x08
000078d1a57d88c0  push rax
000078d1a57d88c1  push rcx
000078d1a57d88c2  push rdx
000078d1a57d88c3  push rdi
000078d1a57d88c4  push rsi
000078d1a57d88c5  push r8
000078d1a57d88c7  push r9
000078d1a57d88c9  push r10
000078d1a57d88cb  push r11
000078d1a57d88cd  sub rsp, 0xF0
000078d1a57d88d4  vmovaps [rsp], xmm0
000078d1a57d88d9  vmovaps [rsp+0x10], xmm1
000078d1a57d88df  vmovaps [rsp+0x20], xmm2
000078d1a57d88e5  vmovaps [rsp+0x30], xmm3
000078d1a57d88eb  vmovaps [rsp+0x40], xmm4
000078d1a57d88f1  vmovaps [rsp+0x50], xmm5
000078d1a57d88f7  vmovaps [rsp+0x60], xmm6
000078d1a57d88fd  vmovaps [rsp+0x70], xmm7
000078d1a57d8903  vmovaps [rsp+0x80], xmm8
000078d1a57d890c  vmovaps [rsp+0x90], xmm9
000078d1a57d8915  vmovaps [rsp+0xA0], xmm10
000078d1a57d891e  vmovaps [rsp+0xB0], xmm11
000078d1a57d8927  vmovaps [rsp+0xC0], xmm12
000078d1a57d8930  vmovaps [rsp+0xD0], xmm13
000078d1a57d8939  vmovaps [rsp+0xE0], xmm14
000078d1a57d8942  sub rsp, 0x30
000078d1a57d8946  movaps [rsp], xmm15
000078d1a57d894b  movaps [rsp+0x10], xmm14
000078d1a57d8951  movaps [rsp+0x20], xmm4
000078d1a57d8956  lea rdi, [rsp]
000078d1a57d895a  mov esi, 0x00
000078d1a57d895f  mov rax, 0x56EA20A26530
000078d1a57d8969  call rax
000078d1a57d896b  movaps xmm15, [rsp]
000078d1a57d8970  add rsp, 0x30
000078d1a57d8974  vmovaps xmm0, [rsp]
000078d1a57d8979  vmovaps xmm1, [rsp+0x10]
000078d1a57d897f  vmovaps xmm2, [rsp+0x20]
000078d1a57d8985  vmovaps xmm3, [rsp+0x30]
000078d1a57d898b  vmovaps xmm4, [rsp+0x40]
000078d1a57d8991  vmovaps xmm5, [rsp+0x50]
000078d1a57d8997  vmovaps xmm6, [rsp+0x60]
000078d1a57d899d  vmovaps xmm7, [rsp+0x70]
000078d1a57d89a3  vmovaps xmm8, [rsp+0x80]
000078d1a57d89ac  vmovaps xmm9, [rsp+0x90]
000078d1a57d89b5  vmovaps xmm10, [rsp+0xA0]
000078d1a57d89be  vmovaps xmm11, [rsp+0xB0]
000078d1a57d89c7  vmovaps xmm12, [rsp+0xC0]
000078d1a57d89d0  vmovaps xmm13, [rsp+0xD0]
000078d1a57d89d9  vmovaps xmm14, [rsp+0xE0]
000078d1a57d89e2  add rsp, 0xF0
000078d1a57d89e9  pop r11
000078d1a57d89eb  pop r10
000078d1a57d89ed  pop r9
000078d1a57d89ef  pop r8
000078d1a57d89f1  pop rsi
000078d1a57d89f2  pop rdi
000078d1a57d89f3  pop rdx
000078d1a57d89f4  pop rcx
000078d1a57d89f5  pop rax
000078d1a57d89f6  add rsp, 0x08
000078d1a57d89fa  jmp 0x000078D1A57D60F7
000078d1a57d89ff  sub rsp, 0x08
000078d1a57d8a03  push rax
000078d1a57d8a04  push rcx
000078d1a57d8a05  push rdx
000078d1a57d8a06  push rdi
000078d1a57d8a07  push rsi
000078d1a57d8a08  push r8
000078d1a57d8a0a  push r9
000078d1a57d8a0c  push r10
000078d1a57d8a0e  push r11
000078d1a57d8a10  sub rsp, 0xF0
000078d1a57d8a17  vmovaps [rsp], xmm0
000078d1a57d8a1c  vmovaps [rsp+0x10], xmm1
000078d1a57d8a22  vmovaps [rsp+0x20], xmm2
000078d1a57d8a28  vmovaps [rsp+0x30], xmm3
000078d1a57d8a2e  vmovaps [rsp+0x40], xmm4
000078d1a57d8a34  vmovaps [rsp+0x50], xmm5
000078d1a57d8a3a  vmovaps [rsp+0x60], xmm6
000078d1a57d8a40  vmovaps [rsp+0x70], xmm7
000078d1a57d8a46  vmovaps [rsp+0x80], xmm8
000078d1a57d8a4f  vmovaps [rsp+0x90], xmm9
000078d1a57d8a58  vmovaps [rsp+0xA0], xmm10
000078d1a57d8a61  vmovaps [rsp+0xB0], xmm11
000078d1a57d8a6a  vmovaps [rsp+0xC0], xmm12
000078d1a57d8a73  vmovaps [rsp+0xD0], xmm13
000078d1a57d8a7c  vmovaps [rsp+0xE0], xmm15
000078d1a57d8a85  sub rsp, 0x30
000078d1a57d8a89  movaps [rsp], xmm14
000078d1a57d8a8e  movaps [rsp+0x10], xmm2
000078d1a57d8a93  movaps [rsp+0x20], xmm1
000078d1a57d8a98  lea rdi, [rsp]
000078d1a57d8a9c  mov esi, 0x00
000078d1a57d8aa1  mov rax, 0x56EA20A26530
000078d1a57d8aab  call rax
000078d1a57d8aad  movaps xmm14, [rsp]
000078d1a57d8ab2  add rsp, 0x30
000078d1a57d8ab6  vmovaps xmm0, [rsp]
000078d1a57d8abb  vmovaps xmm1, [rsp+0x10]
000078d1a57d8ac1  vmovaps xmm2, [rsp+0x20]
000078d1a57d8ac7  vmovaps xmm3, [rsp+0x30]
000078d1a57d8acd  vmovaps xmm4, [rsp+0x40]
000078d1a57d8ad3  vmovaps xmm5, [rsp+0x50]
000078d1a57d8ad9  vmovaps xmm6, [rsp+0x60]
000078d1a57d8adf  vmovaps xmm7, [rsp+0x70]
000078d1a57d8ae5  vmovaps xmm8, [rsp+0x80]
000078d1a57d8aee  vmovaps xmm9, [rsp+0x90]
000078d1a57d8af7  vmovaps xmm10, [rsp+0xA0]
000078d1a57d8b00  vmovaps xmm11, [rsp+0xB0]
000078d1a57d8b09  vmovaps xmm12, [rsp+0xC0]
000078d1a57d8b12  vmovaps xmm13, [rsp+0xD0]
000078d1a57d8b1b  vmovaps xmm15, [rsp+0xE0]
000078d1a57d8b24  add rsp, 0xF0
000078d1a57d8b2b  pop r11
000078d1a57d8b2d  pop r10
000078d1a57d8b2f  pop r9
000078d1a57d8b31  pop r8
000078d1a57d8b33  pop rsi
000078d1a57d8b34  pop rdi
000078d1a57d8b35  pop rdx
000078d1a57d8b36  pop rcx
000078d1a57d8b37  pop rax
000078d1a57d8b38  add rsp, 0x08
000078d1a57d8b3c  jmp 0x000078D1A57D611D
000078d1a57d8b41  sub rsp, 0x08
000078d1a57d8b45  push rax
000078d1a57d8b46  push rcx
000078d1a57d8b47  push rdx
000078d1a57d8b48  push rdi
000078d1a57d8b49  push rsi
000078d1a57d8b4a  push r8
000078d1a57d8b4c  push r9
000078d1a57d8b4e  push r10
000078d1a57d8b50  push r11
000078d1a57d8b52  sub rsp, 0xF0
000078d1a57d8b59  vmovaps [rsp], xmm0
000078d1a57d8b5e  vmovaps [rsp+0x10], xmm2
000078d1a57d8b64  vmovaps [rsp+0x20], xmm3
000078d1a57d8b6a  vmovaps [rsp+0x30], xmm4
000078d1a57d8b70  vmovaps [rsp+0x40], xmm5
000078d1a57d8b76  vmovaps [rsp+0x50], xmm6
000078d1a57d8b7c  vmovaps [rsp+0x60], xmm7
000078d1a57d8b82  vmovaps [rsp+0x70], xmm8
000078d1a57d8b88  vmovaps [rsp+0x80], xmm9
000078d1a57d8b91  vmovaps [rsp+0x90], xmm10
000078d1a57d8b9a  vmovaps [rsp+0xA0], xmm11
000078d1a57d8ba3  vmovaps [rsp+0xB0], xmm12
000078d1a57d8bac  vmovaps [rsp+0xC0], xmm13
000078d1a57d8bb5  vmovaps [rsp+0xD0], xmm14
000078d1a57d8bbe  vmovaps [rsp+0xE0], xmm15
000078d1a57d8bc7  sub rsp, 0x30
000078d1a57d8bcb  movaps [rsp], xmm1
000078d1a57d8bcf  movaps [rsp+0x10], xmm4
000078d1a57d8bd4  movaps [rsp+0x20], xmm9
000078d1a57d8bda  lea rdi, [rsp]
000078d1a57d8bde  mov esi, 0x00
000078d1a57d8be3  mov rax, 0x56EA20A26530
000078d1a57d8bed  call rax
000078d1a57d8bef  movaps xmm1, [rsp]
000078d1a57d8bf3  add rsp, 0x30
000078d1a57d8bf7  vmovaps xmm0, [rsp]
000078d1a57d8bfc  vmovaps xmm2, [rsp+0x10]
000078d1a57d8c02  vmovaps xmm3, [rsp+0x20]
000078d1a57d8c08  vmovaps xmm4, [rsp+0x30]
000078d1a57d8c0e  vmovaps xmm5, [rsp+0x40]
000078d1a57d8c14  vmovaps xmm6, [rsp+0x50]
000078d1a57d8c1a  vmovaps xmm7, [rsp+0x60]
000078d1a57d8c20  vmovaps xmm8, [rsp+0x70]
000078d1a57d8c26  vmovaps xmm9, [rsp+0x80]
000078d1a57d8c2f  vmovaps xmm10, [rsp+0x90]
000078d1a57d8c38  vmovaps xmm11, [rsp+0xA0]
000078d1a57d8c41  vmovaps xmm12, [rsp+0xB0]
000078d1a57d8c4a  vmovaps xmm13, [rsp+0xC0]
000078d1a57d8c53  vmovaps xmm14, [rsp+0xD0]
000078d1a57d8c5c  vmovaps xmm15, [rsp+0xE0]
000078d1a57d8c65  add rsp, 0xF0
000078d1a57d8c6c  pop r11
000078d1a57d8c6e  pop r10
000078d1a57d8c70  pop r9
000078d1a57d8c72  pop r8
000078d1a57d8c74  pop rsi
000078d1a57d8c75  pop rdi
000078d1a57d8c76  pop rdx
000078d1a57d8c77  pop rcx
000078d1a57d8c78  pop rax
000078d1a57d8c79  add rsp, 0x08
000078d1a57d8c7d  jmp 0x000078D1A57D613B
000078d1a57d8c82  sub rsp, 0x08
000078d1a57d8c86  push rax
000078d1a57d8c87  push rcx
000078d1a57d8c88  push rdx
000078d1a57d8c89  push rdi
000078d1a57d8c8a  push rsi
000078d1a57d8c8b  push r8
000078d1a57d8c8d  push r9
000078d1a57d8c8f  push r10
000078d1a57d8c91  push r11
000078d1a57d8c93  sub rsp, 0xF0
000078d1a57d8c9a  vmovaps [rsp], xmm0
000078d1a57d8c9f  vmovaps [rsp+0x10], xmm1
000078d1a57d8ca5  vmovaps [rsp+0x20], xmm2
000078d1a57d8cab  vmovaps [rsp+0x30], xmm3
000078d1a57d8cb1  vmovaps [rsp+0x40], xmm5
000078d1a57d8cb7  vmovaps [rsp+0x50], xmm6
000078d1a57d8cbd  vmovaps [rsp+0x60], xmm7
000078d1a57d8cc3  vmovaps [rsp+0x70], xmm8
000078d1a57d8cc9  vmovaps [rsp+0x80], xmm9
000078d1a57d8cd2  vmovaps [rsp+0x90], xmm10
000078d1a57d8cdb  vmovaps [rsp+0xA0], xmm11
000078d1a57d8ce4  vmovaps [rsp+0xB0], xmm12
000078d1a57d8ced  vmovaps [rsp+0xC0], xmm13
000078d1a57d8cf6  vmovaps [rsp+0xD0], xmm14
000078d1a57d8cff  vmovaps [rsp+0xE0], xmm15
000078d1a57d8d08  sub rsp, 0x30
000078d1a57d8d0c  movaps [rsp], xmm4
000078d1a57d8d10  movaps [rsp+0x10], xmm2
000078d1a57d8d15  movaps [rsp+0x20], xmm9
000078d1a57d8d1b  lea rdi, [rsp]
000078d1a57d8d1f  mov esi, 0x00
000078d1a57d8d24  mov rax, 0x56EA20A26530
000078d1a57d8d2e  call rax
000078d1a57d8d30  movaps xmm4, [rsp]
000078d1a57d8d34  add rsp, 0x30
000078d1a57d8d38  vmovaps xmm0, [rsp]
000078d1a57d8d3d  vmovaps xmm1, [rsp+0x10]
000078d1a57d8d43  vmovaps xmm2, [rsp+0x20]
000078d1a57d8d49  vmovaps xmm3, [rsp+0x30]
000078d1a57d8d4f  vmovaps xmm5, [rsp+0x40]
000078d1a57d8d55  vmovaps xmm6, [rsp+0x50]
000078d1a57d8d5b  vmovaps xmm7, [rsp+0x60]
000078d1a57d8d61  vmovaps xmm8, [rsp+0x70]
000078d1a57d8d67  vmovaps xmm9, [rsp+0x80]
000078d1a57d8d70  vmovaps xmm10, [rsp+0x90]
000078d1a57d8d79  vmovaps xmm11, [rsp+0xA0]
000078d1a57d8d82  vmovaps xmm12, [rsp+0xB0]
000078d1a57d8d8b  vmovaps xmm13, [rsp+0xC0]
000078d1a57d8d94  vmovaps xmm14, [rsp+0xD0]
000078d1a57d8d9d  vmovaps xmm15, [rsp+0xE0]
000078d1a57d8da6  add rsp, 0xF0
000078d1a57d8dad  pop r11
000078d1a57d8daf  pop r10
000078d1a57d8db1  pop r9
000078d1a57d8db3  pop r8
000078d1a57d8db5  pop rsi
000078d1a57d8db6  pop rdi
000078d1a57d8db7  pop rdx
000078d1a57d8db8  pop rcx
000078d1a57d8db9  pop rax
000078d1a57d8dba  add rsp, 0x08
000078d1a57d8dbe  jmp 0x000078D1A57D616B
000078d1a57d8dc3  sub rsp, 0x08
000078d1a57d8dc7  push rax
000078d1a57d8dc8  push rcx
000078d1a57d8dc9  push rdx
000078d1a57d8dca  push rdi
000078d1a57d8dcb  push rsi
000078d1a57d8dcc  push r8
000078d1a57d8dce  push r9
000078d1a57d8dd0  push r10
000078d1a57d8dd2  push r11
000078d1a57d8dd4  sub rsp, 0xF0
000078d1a57d8ddb  vmovaps [rsp], xmm0
000078d1a57d8de0  vmovaps [rsp+0x10], xmm1
000078d1a57d8de6  vmovaps [rsp+0x20], xmm2
000078d1a57d8dec  vmovaps [rsp+0x30], xmm3
000078d1a57d8df2  vmovaps [rsp+0x40], xmm4
000078d1a57d8df8  vmovaps [rsp+0x50], xmm5
000078d1a57d8dfe  vmovaps [rsp+0x60], xmm6
000078d1a57d8e04  vmovaps [rsp+0x70], xmm7
000078d1a57d8e0a  vmovaps [rsp+0x80], xmm8
000078d1a57d8e13  vmovaps [rsp+0x90], xmm10
000078d1a57d8e1c  vmovaps [rsp+0xA0], xmm11
000078d1a57d8e25  vmovaps [rsp+0xB0], xmm12
000078d1a57d8e2e  vmovaps [rsp+0xC0], xmm13
000078d1a57d8e37  vmovaps [rsp+0xD0], xmm14
000078d1a57d8e40  vmovaps [rsp+0xE0], xmm15
000078d1a57d8e49  sub rsp, 0x30
000078d1a57d8e4d  movaps [rsp], xmm9
000078d1a57d8e52  movaps [rsp+0x10], xmm2
000078d1a57d8e57  movaps [rsp+0x20], xmm1
000078d1a57d8e5c  lea rdi, [rsp]
000078d1a57d8e60  mov esi, 0x00
000078d1a57d8e65  mov rax, 0x56EA20A26530
000078d1a57d8e6f  call rax
000078d1a57d8e71  movaps xmm9, [rsp]
000078d1a57d8e76  add rsp, 0x30
000078d1a57d8e7a  vmovaps xmm0, [rsp]
000078d1a57d8e7f  vmovaps xmm1, [rsp+0x10]
000078d1a57d8e85  vmovaps xmm2, [rsp+0x20]
000078d1a57d8e8b  vmovaps xmm3, [rsp+0x30]
000078d1a57d8e91  vmovaps xmm4, [rsp+0x40]
000078d1a57d8e97  vmovaps xmm5, [rsp+0x50]
000078d1a57d8e9d  vmovaps xmm6, [rsp+0x60]
000078d1a57d8ea3  vmovaps xmm7, [rsp+0x70]
000078d1a57d8ea9  vmovaps xmm8, [rsp+0x80]
000078d1a57d8eb2  vmovaps xmm10, [rsp+0x90]
000078d1a57d8ebb  vmovaps xmm11, [rsp+0xA0]
000078d1a57d8ec4  vmovaps xmm12, [rsp+0xB0]
000078d1a57d8ecd  vmovaps xmm13, [rsp+0xC0]
000078d1a57d8ed6  vmovaps xmm14, [rsp+0xD0]
000078d1a57d8edf  vmovaps xmm15, [rsp+0xE0]
000078d1a57d8ee8  add rsp, 0xF0
000078d1a57d8eef  pop r11
000078d1a57d8ef1  pop r10
000078d1a57d8ef3  pop r9
000078d1a57d8ef5  pop r8
000078d1a57d8ef7  pop rsi
000078d1a57d8ef8  pop rdi
000078d1a57d8ef9  pop rdx
000078d1a57d8efa  pop rcx
000078d1a57d8efb  pop rax
000078d1a57d8efc  add rsp, 0x08
000078d1a57d8f00  jmp 0x000078D1A57D61A1
000078d1a57d8f05  sub rsp, 0x08
000078d1a57d8f09  push rax
000078d1a57d8f0a  push rcx
000078d1a57d8f0b  push rdx
000078d1a57d8f0c  push rdi
000078d1a57d8f0d  push rsi
000078d1a57d8f0e  push r8
000078d1a57d8f10  push r9
000078d1a57d8f12  push r10
000078d1a57d8f14  push r11
000078d1a57d8f16  sub rsp, 0xF0
000078d1a57d8f1d  vmovaps [rsp], xmm0
000078d1a57d8f22  vmovaps [rsp+0x10], xmm2
000078d1a57d8f28  vmovaps [rsp+0x20], xmm3
000078d1a57d8f2e  vmovaps [rsp+0x30], xmm4
000078d1a57d8f34  vmovaps [rsp+0x40], xmm5
000078d1a57d8f3a  vmovaps [rsp+0x50], xmm6
000078d1a57d8f40  vmovaps [rsp+0x60], xmm7
000078d1a57d8f46  vmovaps [rsp+0x70], xmm8
000078d1a57d8f4c  vmovaps [rsp+0x80], xmm9
000078d1a57d8f55  vmovaps [rsp+0x90], xmm10
000078d1a57d8f5e  vmovaps [rsp+0xA0], xmm11
000078d1a57d8f67  vmovaps [rsp+0xB0], xmm12
000078d1a57d8f70  vmovaps [rsp+0xC0], xmm13
000078d1a57d8f79  vmovaps [rsp+0xD0], xmm14
000078d1a57d8f82  vmovaps [rsp+0xE0], xmm15
000078d1a57d8f8b  sub rsp, 0x30
000078d1a57d8f8f  movaps [rsp], xmm1
000078d1a57d8f93  movaps [rsp+0x10], xmm15
000078d1a57d8f99  movaps [rsp+0x20], xmm6
000078d1a57d8f9e  lea rdi, [rsp]
000078d1a57d8fa2  mov esi, 0x00
000078d1a57d8fa7  mov rax, 0x56EA20A26530
000078d1a57d8fb1  call rax
000078d1a57d8fb3  movaps xmm1, [rsp]
000078d1a57d8fb7  add rsp, 0x30
000078d1a57d8fbb  vmovaps xmm0, [rsp]
000078d1a57d8fc0  vmovaps xmm2, [rsp+0x10]
000078d1a57d8fc6  vmovaps xmm3, [rsp+0x20]
000078d1a57d8fcc  vmovaps xmm4, [rsp+0x30]
000078d1a57d8fd2  vmovaps xmm5, [rsp+0x40]
000078d1a57d8fd8  vmovaps xmm6, [rsp+0x50]
000078d1a57d8fde  vmovaps xmm7, [rsp+0x60]
000078d1a57d8fe4  vmovaps xmm8, [rsp+0x70]
000078d1a57d8fea  vmovaps xmm9, [rsp+0x80]
000078d1a57d8ff3  vmovaps xmm10, [rsp+0x90]
000078d1a57d8ffc  vmovaps xmm11, [rsp+0xA0]
000078d1a57d9005  vmovaps xmm12, [rsp+0xB0]
000078d1a57d900e  vmovaps xmm13, [rsp+0xC0]
000078d1a57d9017  vmovaps xmm14, [rsp+0xD0]
000078d1a57d9020  vmovaps xmm15, [rsp+0xE0]
000078d1a57d9029  add rsp, 0xF0
000078d1a57d9030  pop r11
000078d1a57d9032  pop r10
000078d1a57d9034  pop r9
000078d1a57d9036  pop r8
000078d1a57d9038  pop rsi
000078d1a57d9039  pop rdi
000078d1a57d903a  pop rdx
000078d1a57d903b  pop rcx
000078d1a57d903c  pop rax
000078d1a57d903d  add rsp, 0x08
000078d1a57d9041  jmp 0x000078D1A57D61C2
000078d1a57d9046  sub rsp, 0x08
000078d1a57d904a  push rax
000078d1a57d904b  push rcx
000078d1a57d904c  push rdx
000078d1a57d904d  push rdi
000078d1a57d904e  push rsi
000078d1a57d904f  push r8
000078d1a57d9051  push r9
000078d1a57d9053  push r10
000078d1a57d9055  push r11
000078d1a57d9057  sub rsp, 0xF0
000078d1a57d905e  vmovaps [rsp], xmm0
000078d1a57d9063  vmovaps [rsp+0x10], xmm1
000078d1a57d9069  vmovaps [rsp+0x20], xmm2
000078d1a57d906f  vmovaps [rsp+0x30], xmm3
000078d1a57d9075  vmovaps [rsp+0x40], xmm4
000078d1a57d907b  vmovaps [rsp+0x50], xmm5
000078d1a57d9081  vmovaps [rsp+0x60], xmm6
000078d1a57d9087  vmovaps [rsp+0x70], xmm7
000078d1a57d908d  vmovaps [rsp+0x80], xmm8
000078d1a57d9096  vmovaps [rsp+0x90], xmm9
000078d1a57d909f  vmovaps [rsp+0xA0], xmm10
000078d1a57d90a8  vmovaps [rsp+0xB0], xmm11
000078d1a57d90b1  vmovaps [rsp+0xC0], xmm12
000078d1a57d90ba  vmovaps [rsp+0xD0], xmm13
000078d1a57d90c3  vmovaps [rsp+0xE0], xmm14
000078d1a57d90cc  sub rsp, 0x30
000078d1a57d90d0  movaps [rsp], xmm15
000078d1a57d90d5  movaps [rsp+0x10], xmm5
000078d1a57d90da  movaps [rsp+0x20], xmm3
000078d1a57d90df  lea rdi, [rsp]
000078d1a57d90e3  mov esi, 0x00
000078d1a57d90e8  mov rax, 0x56EA20A26530
000078d1a57d90f2  call rax
000078d1a57d90f4  movaps xmm15, [rsp]
000078d1a57d90f9  add rsp, 0x30
000078d1a57d90fd  vmovaps xmm0, [rsp]
000078d1a57d9102  vmovaps xmm1, [rsp+0x10]
000078d1a57d9108  vmovaps xmm2, [rsp+0x20]
000078d1a57d910e  vmovaps xmm3, [rsp+0x30]
000078d1a57d9114  vmovaps xmm4, [rsp+0x40]
000078d1a57d911a  vmovaps xmm5, [rsp+0x50]
000078d1a57d9120  vmovaps xmm6, [rsp+0x60]
000078d1a57d9126  vmovaps xmm7, [rsp+0x70]
000078d1a57d912c  vmovaps xmm8, [rsp+0x80]
000078d1a57d9135  vmovaps xmm9, [rsp+0x90]
000078d1a57d913e  vmovaps xmm10, [rsp+0xA0]
000078d1a57d9147  vmovaps xmm11, [rsp+0xB0]
000078d1a57d9150  vmovaps xmm12, [rsp+0xC0]
000078d1a57d9159  vmovaps xmm13, [rsp+0xD0]
000078d1a57d9162  vmovaps xmm14, [rsp+0xE0]
000078d1a57d916b  add rsp, 0xF0
000078d1a57d9172  pop r11
000078d1a57d9174  pop r10
000078d1a57d9176  pop r9
000078d1a57d9178  pop r8
000078d1a57d917a  pop rsi
000078d1a57d917b  pop rdi
000078d1a57d917c  pop rdx
000078d1a57d917d  pop rcx
000078d1a57d917e  pop rax
000078d1a57d917f  add rsp, 0x08
000078d1a57d9183  jmp 0x000078D1A57D61DC
000078d1a57d9188  sub rsp, 0x08
000078d1a57d918c  push rax
000078d1a57d918d  push rcx
000078d1a57d918e  push rdx
000078d1a57d918f  push rdi
000078d1a57d9190  push rsi
000078d1a57d9191  push r8
000078d1a57d9193  push r9
000078d1a57d9195  push r10
000078d1a57d9197  push r11
000078d1a57d9199  sub rsp, 0xF0
000078d1a57d91a0  vmovaps [rsp], xmm0
000078d1a57d91a5  vmovaps [rsp+0x10], xmm1
000078d1a57d91ab  vmovaps [rsp+0x20], xmm2
000078d1a57d91b1  vmovaps [rsp+0x30], xmm3
000078d1a57d91b7  vmovaps [rsp+0x40], xmm4
000078d1a57d91bd  vmovaps [rsp+0x50], xmm6
000078d1a57d91c3  vmovaps [rsp+0x60], xmm7
000078d1a57d91c9  vmovaps [rsp+0x70], xmm8
000078d1a57d91cf  vmovaps [rsp+0x80], xmm9
000078d1a57d91d8  vmovaps [rsp+0x90], xmm10
000078d1a57d91e1  vmovaps [rsp+0xA0], xmm11
000078d1a57d91ea  vmovaps [rsp+0xB0], xmm12
000078d1a57d91f3  vmovaps [rsp+0xC0], xmm13
000078d1a57d91fc  vmovaps [rsp+0xD0], xmm14
000078d1a57d9205  vmovaps [rsp+0xE0], xmm15
000078d1a57d920e  sub rsp, 0x30
000078d1a57d9212  movaps [rsp], xmm5
000078d1a57d9216  movaps [rsp+0x10], xmm8
000078d1a57d921c  movaps [rsp+0x20], xmm6
000078d1a57d9221  lea rdi, [rsp]
000078d1a57d9225  mov esi, 0x00
000078d1a57d922a  mov rax, 0x56EA20A26530
000078d1a57d9234  call rax
000078d1a57d9236  movaps xmm5, [rsp]
000078d1a57d923a  add rsp, 0x30
000078d1a57d923e  vmovaps xmm0, [rsp]
000078d1a57d9243  vmovaps xmm1, [rsp+0x10]
000078d1a57d9249  vmovaps xmm2, [rsp+0x20]
000078d1a57d924f  vmovaps xmm3, [rsp+0x30]
000078d1a57d9255  vmovaps xmm4, [rsp+0x40]
000078d1a57d925b  vmovaps xmm6, [rsp+0x50]
000078d1a57d9261  vmovaps xmm7, [rsp+0x60]
000078d1a57d9267  vmovaps xmm8, [rsp+0x70]
000078d1a57d926d  vmovaps xmm9, [rsp+0x80]
000078d1a57d9276  vmovaps xmm10, [rsp+0x90]
000078d1a57d927f  vmovaps xmm11, [rsp+0xA0]
000078d1a57d9288  vmovaps xmm12, [rsp+0xB0]
000078d1a57d9291  vmovaps xmm13, [rsp+0xC0]
000078d1a57d929a  vmovaps xmm14, [rsp+0xD0]
000078d1a57d92a3  vmovaps xmm15, [rsp+0xE0]
000078d1a57d92ac  add rsp, 0xF0
000078d1a57d92b3  pop r11
000078d1a57d92b5  pop r10
000078d1a57d92b7  pop r9
000078d1a57d92b9  pop r8
000078d1a57d92bb  pop rsi
000078d1a57d92bc  pop rdi
000078d1a57d92bd  pop rdx
000078d1a57d92be  pop rcx
000078d1a57d92bf  pop rax
000078d1a57d92c0  add rsp, 0x08
000078d1a57d92c4  jmp 0x000078D1A57D6200
000078d1a57d92c9  sub rsp, 0x08
000078d1a57d92cd  push rax
000078d1a57d92ce  push rcx
000078d1a57d92cf  push rdx
000078d1a57d92d0  push rdi
000078d1a57d92d1  push rsi
000078d1a57d92d2  push r8
000078d1a57d92d4  push r9
000078d1a57d92d6  push r10
000078d1a57d92d8  push r11
000078d1a57d92da  sub rsp, 0xF0
000078d1a57d92e1  vmovaps [rsp], xmm0
000078d1a57d92e6  vmovaps [rsp+0x10], xmm1
000078d1a57d92ec  vmovaps [rsp+0x20], xmm2
000078d1a57d92f2  vmovaps [rsp+0x30], xmm3
000078d1a57d92f8  vmovaps [rsp+0x40], xmm4
000078d1a57d92fe  vmovaps [rsp+0x50], xmm5
000078d1a57d9304  vmovaps [rsp+0x60], xmm7
000078d1a57d930a  vmovaps [rsp+0x70], xmm8
000078d1a57d9310  vmovaps [rsp+0x80], xmm9
000078d1a57d9319  vmovaps [rsp+0x90], xmm10
000078d1a57d9322  vmovaps [rsp+0xA0], xmm11
000078d1a57d932b  vmovaps [rsp+0xB0], xmm12
000078d1a57d9334  vmovaps [rsp+0xC0], xmm13
000078d1a57d933d  vmovaps [rsp+0xD0], xmm14
000078d1a57d9346  vmovaps [rsp+0xE0], xmm15
000078d1a57d934f  sub rsp, 0x30
000078d1a57d9353  movaps [rsp], xmm6
000078d1a57d9357  movaps [rsp+0x10], xmm10
000078d1a57d935d  movaps [rsp+0x20], xmm8
000078d1a57d9363  lea rdi, [rsp]
000078d1a57d9367  mov esi, 0x00
000078d1a57d936c  mov rax, 0x56EA20A26530
000078d1a57d9376  call rax
000078d1a57d9378  movaps xmm6, [rsp]
000078d1a57d937c  add rsp, 0x30
000078d1a57d9380  vmovaps xmm0, [rsp]
000078d1a57d9385  vmovaps xmm1, [rsp+0x10]
000078d1a57d938b  vmovaps xmm2, [rsp+0x20]
000078d1a57d9391  vmovaps xmm3, [rsp+0x30]
000078d1a57d9397  vmovaps xmm4, [rsp+0x40]
000078d1a57d939d  vmovaps xmm5, [rsp+0x50]
000078d1a57d93a3  vmovaps xmm7, [rsp+0x60]
000078d1a57d93a9  vmovaps xmm8, [rsp+0x70]
000078d1a57d93af  vmovaps xmm9, [rsp+0x80]
000078d1a57d93b8  vmovaps xmm10, [rsp+0x90]
000078d1a57d93c1  vmovaps xmm11, [rsp+0xA0]
000078d1a57d93ca  vmovaps xmm12, [rsp+0xB0]
000078d1a57d93d3  vmovaps xmm13, [rsp+0xC0]
000078d1a57d93dc  vmovaps xmm14, [rsp+0xD0]
000078d1a57d93e5  vmovaps xmm15, [rsp+0xE0]
000078d1a57d93ee  add rsp, 0xF0
000078d1a57d93f5  pop r11
000078d1a57d93f7  pop r10
000078d1a57d93f9  pop r9
000078d1a57d93fb  pop r8
000078d1a57d93fd  pop rsi
000078d1a57d93fe  pop rdi
000078d1a57d93ff  pop rdx
000078d1a57d9400  pop rcx
000078d1a57d9401  pop rax
000078d1a57d9402  add rsp, 0x08
000078d1a57d9406  jmp 0x000078D1A57D6225
000078d1a57d940b  sub rsp, 0x08
000078d1a57d940f  push rax
000078d1a57d9410  push rcx
000078d1a57d9411  push rdx
000078d1a57d9412  push rdi
000078d1a57d9413  push rsi
000078d1a57d9414  push r8
000078d1a57d9416  push r9
000078d1a57d9418  push r10
000078d1a57d941a  push r11
000078d1a57d941c  sub rsp, 0xF0
000078d1a57d9423  vmovaps [rsp], xmm0
000078d1a57d9428  vmovaps [rsp+0x10], xmm1
000078d1a57d942e  vmovaps [rsp+0x20], xmm2
000078d1a57d9434  vmovaps [rsp+0x30], xmm3
000078d1a57d943a  vmovaps [rsp+0x40], xmm4
000078d1a57d9440  vmovaps [rsp+0x50], xmm5
000078d1a57d9446  vmovaps [rsp+0x60], xmm6
000078d1a57d944c  vmovaps [rsp+0x70], xmm7
000078d1a57d9452  vmovaps [rsp+0x80], xmm8
000078d1a57d945b  vmovaps [rsp+0x90], xmm9
000078d1a57d9464  vmovaps [rsp+0xA0], xmm11
000078d1a57d946d  vmovaps [rsp+0xB0], xmm12
000078d1a57d9476  vmovaps [rsp+0xC0], xmm13
000078d1a57d947f  vmovaps [rsp+0xD0], xmm14
000078d1a57d9488  vmovaps [rsp+0xE0], xmm15
000078d1a57d9491  sub rsp, 0x30
000078d1a57d9495  movaps [rsp], xmm10
000078d1a57d949a  movaps [rsp+0x10], xmm8
000078d1a57d94a0  movaps [rsp+0x20], xmm14
000078d1a57d94a6  lea rdi, [rsp]
000078d1a57d94aa  mov esi, 0x00
000078d1a57d94af  mov rax, 0x56EA20A26530
000078d1a57d94b9  call rax
000078d1a57d94bb  movaps xmm10, [rsp]
000078d1a57d94c0  add rsp, 0x30
000078d1a57d94c4  vmovaps xmm0, [rsp]
000078d1a57d94c9  vmovaps xmm1, [rsp+0x10]
000078d1a57d94cf  vmovaps xmm2, [rsp+0x20]
000078d1a57d94d5  vmovaps xmm3, [rsp+0x30]
000078d1a57d94db  vmovaps xmm4, [rsp+0x40]
000078d1a57d94e1  vmovaps xmm5, [rsp+0x50]
000078d1a57d94e7  vmovaps xmm6, [rsp+0x60]
000078d1a57d94ed  vmovaps xmm7, [rsp+0x70]
000078d1a57d94f3  vmovaps xmm8, [rsp+0x80]
000078d1a57d94fc  vmovaps xmm9, [rsp+0x90]
000078d1a57d9505  vmovaps xmm11, [rsp+0xA0]
000078d1a57d950e  vmovaps xmm12, [rsp+0xB0]
000078d1a57d9517  vmovaps xmm13, [rsp+0xC0]
000078d1a57d9520  vmovaps xmm14, [rsp+0xD0]
000078d1a57d9529  vmovaps xmm15, [rsp+0xE0]
000078d1a57d9532  add rsp, 0xF0
000078d1a57d9539  pop r11
000078d1a57d953b  pop r10
000078d1a57d953d  pop r9
000078d1a57d953f  pop r8
000078d1a57d9541  pop rsi
000078d1a57d9542  pop rdi
000078d1a57d9543  pop rdx
000078d1a57d9544  pop rcx
000078d1a57d9545  pop rax
000078d1a57d9546  add rsp, 0x08
000078d1a57d954a  jmp 0x000078D1A57D6245
000078d1a57d954f  sub rsp, 0x08
000078d1a57d9553  push rax
000078d1a57d9554  push rcx
000078d1a57d9555  push rdx
000078d1a57d9556  push rdi
000078d1a57d9557  push rsi
000078d1a57d9558  push r8
000078d1a57d955a  push r9
000078d1a57d955c  push r10
000078d1a57d955e  push r11
000078d1a57d9560  sub rsp, 0xF0
000078d1a57d9567  vmovaps [rsp], xmm0
000078d1a57d956c  vmovaps [rsp+0x10], xmm1
000078d1a57d9572  vmovaps [rsp+0x20], xmm2
000078d1a57d9578  vmovaps [rsp+0x30], xmm3
000078d1a57d957e  vmovaps [rsp+0x40], xmm4
000078d1a57d9584  vmovaps [rsp+0x50], xmm5
000078d1a57d958a  vmovaps [rsp+0x60], xmm6
000078d1a57d9590  vmovaps [rsp+0x70], xmm7
000078d1a57d9596  vmovaps [rsp+0x80], xmm8
000078d1a57d959f  vmovaps [rsp+0x90], xmm9
000078d1a57d95a8  vmovaps [rsp+0xA0], xmm10
000078d1a57d95b1  vmovaps [rsp+0xB0], xmm11
000078d1a57d95ba  vmovaps [rsp+0xC0], xmm12
000078d1a57d95c3  vmovaps [rsp+0xD0], xmm13
000078d1a57d95cc  vmovaps [rsp+0xE0], xmm15
000078d1a57d95d5  sub rsp, 0x30
000078d1a57d95d9  movaps [rsp], xmm14
000078d1a57d95de  movaps [rsp+0x10], xmm8
000078d1a57d95e4  movaps [rsp+0x20], xmm4
000078d1a57d95e9  lea rdi, [rsp]
000078d1a57d95ed  mov esi, 0x00
000078d1a57d95f2  mov rax, 0x56EA20A26530
000078d1a57d95fc  call rax
000078d1a57d95fe  movaps xmm14, [rsp]
000078d1a57d9603  add rsp, 0x30
000078d1a57d9607  vmovaps xmm0, [rsp]
000078d1a57d960c  vmovaps xmm1, [rsp+0x10]
000078d1a57d9612  vmovaps xmm2, [rsp+0x20]
000078d1a57d9618  vmovaps xmm3, [rsp+0x30]
000078d1a57d961e  vmovaps xmm4, [rsp+0x40]
000078d1a57d9624  vmovaps xmm5, [rsp+0x50]
000078d1a57d962a  vmovaps xmm6, [rsp+0x60]
000078d1a57d9630  vmovaps xmm7, [rsp+0x70]
000078d1a57d9636  vmovaps xmm8, [rsp+0x80]
000078d1a57d963f  vmovaps xmm9, [rsp+0x90]
000078d1a57d9648  vmovaps xmm10, [rsp+0xA0]
000078d1a57d9651  vmovaps xmm11, [rsp+0xB0]
000078d1a57d965a  vmovaps xmm12, [rsp+0xC0]
000078d1a57d9663  vmovaps xmm13, [rsp+0xD0]
000078d1a57d966c  vmovaps xmm15, [rsp+0xE0]
000078d1a57d9675  add rsp, 0xF0
000078d1a57d967c  pop r11
000078d1a57d967e  pop r10
000078d1a57d9680  pop r9
000078d1a57d9682  pop r8
000078d1a57d9684  pop rsi
000078d1a57d9685  pop rdi
000078d1a57d9686  pop rdx
000078d1a57d9687  pop rcx
000078d1a57d9688  pop rax
000078d1a57d9689  add rsp, 0x08
000078d1a57d968d  jmp 0x000078D1A57D6265
000078d1a57d9692  sub rsp, 0x08
000078d1a57d9696  push rax
000078d1a57d9697  push rcx
000078d1a57d9698  push rdx
000078d1a57d9699  push rdi
000078d1a57d969a  push rsi
000078d1a57d969b  push r8
000078d1a57d969d  push r9
000078d1a57d969f  push r10
000078d1a57d96a1  push r11
000078d1a57d96a3  sub rsp, 0xF0
000078d1a57d96aa  vmovaps [rsp], xmm0
000078d1a57d96af  vmovaps [rsp+0x10], xmm1
000078d1a57d96b5  vmovaps [rsp+0x20], xmm2
000078d1a57d96bb  vmovaps [rsp+0x30], xmm3
000078d1a57d96c1  vmovaps [rsp+0x40], xmm5
000078d1a57d96c7  vmovaps [rsp+0x50], xmm6
000078d1a57d96cd  vmovaps [rsp+0x60], xmm7
000078d1a57d96d3  vmovaps [rsp+0x70], xmm8
000078d1a57d96d9  vmovaps [rsp+0x80], xmm9
000078d1a57d96e2  vmovaps [rsp+0x90], xmm10
000078d1a57d96eb  vmovaps [rsp+0xA0], xmm11
000078d1a57d96f4  vmovaps [rsp+0xB0], xmm12
000078d1a57d96fd  vmovaps [rsp+0xC0], xmm13
000078d1a57d9706  vmovaps [rsp+0xD0], xmm14
000078d1a57d970f  vmovaps [rsp+0xE0], xmm15
000078d1a57d9718  sub rsp, 0x30
000078d1a57d971c  movaps [rsp], xmm4
000078d1a57d9720  movaps [rsp+0x10], xmm13
000078d1a57d9726  movaps [rsp+0x20], xmm8
000078d1a57d972c  lea rdi, [rsp]
000078d1a57d9730  mov esi, 0x00
000078d1a57d9735  mov rax, 0x56EA20A26530
000078d1a57d973f  call rax
000078d1a57d9741  movaps xmm4, [rsp]
000078d1a57d9745  add rsp, 0x30
000078d1a57d9749  vmovaps xmm0, [rsp]
000078d1a57d974e  vmovaps xmm1, [rsp+0x10]
000078d1a57d9754  vmovaps xmm2, [rsp+0x20]
000078d1a57d975a  vmovaps xmm3, [rsp+0x30]
000078d1a57d9760  vmovaps xmm5, [rsp+0x40]
000078d1a57d9766  vmovaps xmm6, [rsp+0x50]
000078d1a57d976c  vmovaps xmm7, [rsp+0x60]
000078d1a57d9772  vmovaps xmm8, [rsp+0x70]
000078d1a57d9778  vmovaps xmm9, [rsp+0x80]
000078d1a57d9781  vmovaps xmm10, [rsp+0x90]
000078d1a57d978a  vmovaps xmm11, [rsp+0xA0]
000078d1a57d9793  vmovaps xmm12, [rsp+0xB0]
000078d1a57d979c  vmovaps xmm13, [rsp+0xC0]
000078d1a57d97a5  vmovaps xmm14, [rsp+0xD0]
000078d1a57d97ae  vmovaps xmm15, [rsp+0xE0]
000078d1a57d97b7  add rsp, 0xF0
000078d1a57d97be  pop r11
000078d1a57d97c0  pop r10
000078d1a57d97c2  pop r9
000078d1a57d97c4  pop r8
000078d1a57d97c6  pop rsi
000078d1a57d97c7  pop rdi
000078d1a57d97c8  pop rdx
000078d1a57d97c9  pop rcx
000078d1a57d97ca  pop rax
000078d1a57d97cb  add rsp, 0x08
000078d1a57d97cf  jmp 0x000078D1A57D628A
000078d1a57d97d4  sub rsp, 0x08
000078d1a57d97d8  push rax
000078d1a57d97d9  push rcx
000078d1a57d97da  push rdx
000078d1a57d97db  push rdi
000078d1a57d97dc  push rsi
000078d1a57d97dd  push r8
000078d1a57d97df  push r9
000078d1a57d97e1  push r10
000078d1a57d97e3  push r11
000078d1a57d97e5  sub rsp, 0xF0
000078d1a57d97ec  vmovaps [rsp], xmm0
000078d1a57d97f1  vmovaps [rsp+0x10], xmm1
000078d1a57d97f7  vmovaps [rsp+0x20], xmm2
000078d1a57d97fd  vmovaps [rsp+0x30], xmm3
000078d1a57d9803  vmovaps [rsp+0x40], xmm4
000078d1a57d9809  vmovaps [rsp+0x50], xmm5
000078d1a57d980f  vmovaps [rsp+0x60], xmm6
000078d1a57d9815  vmovaps [rsp+0x70], xmm7
000078d1a57d981b  vmovaps [rsp+0x80], xmm8
000078d1a57d9824  vmovaps [rsp+0x90], xmm9
000078d1a57d982d  vmovaps [rsp+0xA0], xmm10
000078d1a57d9836  vmovaps [rsp+0xB0], xmm11
000078d1a57d983f  vmovaps [rsp+0xC0], xmm12
000078d1a57d9848  vmovaps [rsp+0xD0], xmm14
000078d1a57d9851  vmovaps [rsp+0xE0], xmm15
000078d1a57d985a  sub rsp, 0x30
000078d1a57d985e  movaps [rsp], xmm13
000078d1a57d9863  movaps [rsp+0x10], xmm15
000078d1a57d9869  movaps [rsp+0x20], xmm9
000078d1a57d986f  lea rdi, [rsp]
000078d1a57d9873  mov esi, 0x00
000078d1a57d9878  mov rax, 0x56EA20A26530
000078d1a57d9882  call rax
000078d1a57d9884  movaps xmm13, [rsp]
000078d1a57d9889  add rsp, 0x30
000078d1a57d988d  vmovaps xmm0, [rsp]
000078d1a57d9892  vmovaps xmm1, [rsp+0x10]
000078d1a57d9898  vmovaps xmm2, [rsp+0x20]
000078d1a57d989e  vmovaps xmm3, [rsp+0x30]
000078d1a57d98a4  vmovaps xmm4, [rsp+0x40]
000078d1a57d98aa  vmovaps xmm5, [rsp+0x50]
000078d1a57d98b0  vmovaps xmm6, [rsp+0x60]
000078d1a57d98b6  vmovaps xmm7, [rsp+0x70]
000078d1a57d98bc  vmovaps xmm8, [rsp+0x80]
000078d1a57d98c5  vmovaps xmm9, [rsp+0x90]
000078d1a57d98ce  vmovaps xmm10, [rsp+0xA0]
000078d1a57d98d7  vmovaps xmm11, [rsp+0xB0]
000078d1a57d98e0  vmovaps xmm12, [rsp+0xC0]
000078d1a57d98e9  vmovaps xmm14, [rsp+0xD0]
000078d1a57d98f2  vmovaps xmm15, [rsp+0xE0]
000078d1a57d98fb  add rsp, 0xF0
000078d1a57d9902  pop r11
000078d1a57d9904  pop r10
000078d1a57d9906  pop r9
000078d1a57d9908  pop r8
000078d1a57d990a  pop rsi
000078d1a57d990b  pop rdi
000078d1a57d990c  pop rdx
000078d1a57d990d  pop rcx
000078d1a57d990e  pop rax
000078d1a57d990f  add rsp, 0x08
000078d1a57d9913  jmp 0x000078D1A57D62A5
000078d1a57d9918  sub rsp, 0x08
000078d1a57d991c  push rax
000078d1a57d991d  push rcx
000078d1a57d991e  push rdx
000078d1a57d991f  push rdi
000078d1a57d9920  push rsi
000078d1a57d9921  push r8
000078d1a57d9923  push r9
000078d1a57d9925  push r10
000078d1a57d9927  push r11
000078d1a57d9929  sub rsp, 0xF0
000078d1a57d9930  vmovaps [rsp], xmm0
000078d1a57d9935  vmovaps [rsp+0x10], xmm1
000078d1a57d993b  vmovaps [rsp+0x20], xmm2
000078d1a57d9941  vmovaps [rsp+0x30], xmm3
000078d1a57d9947  vmovaps [rsp+0x40], xmm4
000078d1a57d994d  vmovaps [rsp+0x50], xmm5
000078d1a57d9953  vmovaps [rsp+0x60], xmm6
000078d1a57d9959  vmovaps [rsp+0x70], xmm7
000078d1a57d995f  vmovaps [rsp+0x80], xmm8
000078d1a57d9968  vmovaps [rsp+0x90], xmm9
000078d1a57d9971  vmovaps [rsp+0xA0], xmm10
000078d1a57d997a  vmovaps [rsp+0xB0], xmm11
000078d1a57d9983  vmovaps [rsp+0xC0], xmm12
000078d1a57d998c  vmovaps [rsp+0xD0], xmm13
000078d1a57d9995  vmovaps [rsp+0xE0], xmm14
000078d1a57d999e  sub rsp, 0x30
000078d1a57d99a2  movaps [rsp], xmm15
000078d1a57d99a7  movaps [rsp+0x10], xmm1
000078d1a57d99ac  movaps [rsp+0x20], xmm5
000078d1a57d99b1  lea rdi, [rsp]
000078d1a57d99b5  mov esi, 0x00
000078d1a57d99ba  mov rax, 0x56EA20A26530
000078d1a57d99c4  call rax
000078d1a57d99c6  movaps xmm15, [rsp]
000078d1a57d99cb  add rsp, 0x30
000078d1a57d99cf  vmovaps xmm0, [rsp]
000078d1a57d99d4  vmovaps xmm1, [rsp+0x10]
000078d1a57d99da  vmovaps xmm2, [rsp+0x20]
000078d1a57d99e0  vmovaps xmm3, [rsp+0x30]
000078d1a57d99e6  vmovaps xmm4, [rsp+0x40]
000078d1a57d99ec  vmovaps xmm5, [rsp+0x50]
000078d1a57d99f2  vmovaps xmm6, [rsp+0x60]
000078d1a57d99f8  vmovaps xmm7, [rsp+0x70]
000078d1a57d99fe  vmovaps xmm8, [rsp+0x80]
000078d1a57d9a07  vmovaps xmm9, [rsp+0x90]
000078d1a57d9a10  vmovaps xmm10, [rsp+0xA0]
000078d1a57d9a19  vmovaps xmm11, [rsp+0xB0]
000078d1a57d9a22  vmovaps xmm12, [rsp+0xC0]
000078d1a57d9a2b  vmovaps xmm13, [rsp+0xD0]
000078d1a57d9a34  vmovaps xmm14, [rsp+0xE0]
000078d1a57d9a3d  add rsp, 0xF0
000078d1a57d9a44  pop r11
000078d1a57d9a46  pop r10
000078d1a57d9a48  pop r9
000078d1a57d9a4a  pop r8
000078d1a57d9a4c  pop rsi
000078d1a57d9a4d  pop rdi
000078d1a57d9a4e  pop rdx
000078d1a57d9a4f  pop rcx
000078d1a57d9a50  pop rax
000078d1a57d9a51  add rsp, 0x08
000078d1a57d9a55  jmp 0x000078D1A57D62C0
000078d1a57d9a5a  call 0x000078D1A56D64F0
000078d1a57d9a5f  jmp 0x000078D1A57D631B
000078d1a57d9a64  sub rsp, 0x08
000078d1a57d9a68  push rax
000078d1a57d9a69  push rcx
000078d1a57d9a6a  push rdx
000078d1a57d9a6b  push rdi
000078d1a57d9a6c  push rsi
000078d1a57d9a6d  push r8
000078d1a57d9a6f  push r9
000078d1a57d9a71  push r10
000078d1a57d9a73  push r11
000078d1a57d9a75  sub rsp, 0xF0
000078d1a57d9a7c  vmovaps [rsp], xmm0
000078d1a57d9a81  vmovaps [rsp+0x10], xmm1
000078d1a57d9a87  vmovaps [rsp+0x20], xmm2
000078d1a57d9a8d  vmovaps [rsp+0x30], xmm3
000078d1a57d9a93  vmovaps [rsp+0x40], xmm4
000078d1a57d9a99  vmovaps [rsp+0x50], xmm5
000078d1a57d9a9f  vmovaps [rsp+0x60], xmm6
000078d1a57d9aa5  vmovaps [rsp+0x70], xmm7
000078d1a57d9aab  vmovaps [rsp+0x80], xmm8
000078d1a57d9ab4  vmovaps [rsp+0x90], xmm10
000078d1a57d9abd  vmovaps [rsp+0xA0], xmm11
000078d1a57d9ac6  vmovaps [rsp+0xB0], xmm12
000078d1a57d9acf  vmovaps [rsp+0xC0], xmm13
000078d1a57d9ad8  vmovaps [rsp+0xD0], xmm14
000078d1a57d9ae1  vmovaps [rsp+0xE0], xmm15
000078d1a57d9aea  sub rsp, 0x30
000078d1a57d9aee  movaps [rsp], xmm9
000078d1a57d9af3  movaps [rsp+0x10], xmm8
000078d1a57d9af9  movaps [rsp+0x20], xmm11
000078d1a57d9aff  lea rdi, [rsp]
000078d1a57d9b03  mov esi, 0x00
000078d1a57d9b08  mov rax, 0x56EA20A26530
000078d1a57d9b12  call rax
000078d1a57d9b14  movaps xmm9, [rsp]
000078d1a57d9b19  add rsp, 0x30
000078d1a57d9b1d  vmovaps xmm0, [rsp]
000078d1a57d9b22  vmovaps xmm1, [rsp+0x10]
000078d1a57d9b28  vmovaps xmm2, [rsp+0x20]
000078d1a57d9b2e  vmovaps xmm3, [rsp+0x30]
000078d1a57d9b34  vmovaps xmm4, [rsp+0x40]
000078d1a57d9b3a  vmovaps xmm5, [rsp+0x50]
000078d1a57d9b40  vmovaps xmm6, [rsp+0x60]
000078d1a57d9b46  vmovaps xmm7, [rsp+0x70]
000078d1a57d9b4c  vmovaps xmm8, [rsp+0x80]
000078d1a57d9b55  vmovaps xmm10, [rsp+0x90]
000078d1a57d9b5e  vmovaps xmm11, [rsp+0xA0]
000078d1a57d9b67  vmovaps xmm12, [rsp+0xB0]
000078d1a57d9b70  vmovaps xmm13, [rsp+0xC0]
000078d1a57d9b79  vmovaps xmm14, [rsp+0xD0]
000078d1a57d9b82  vmovaps xmm15, [rsp+0xE0]
000078d1a57d9b8b  add rsp, 0xF0
000078d1a57d9b92  pop r11
000078d1a57d9b94  pop r10
000078d1a57d9b96  pop r9
000078d1a57d9b98  pop r8
000078d1a57d9b9a  pop rsi
000078d1a57d9b9b  pop rdi
000078d1a57d9b9c  pop rdx
000078d1a57d9b9d  pop rcx
000078d1a57d9b9e  pop rax
000078d1a57d9b9f  add rsp, 0x08
000078d1a57d9ba3  jmp 0x000078D1A57D6352
000078d1a57d9ba8  sub rsp, 0x08
000078d1a57d9bac  push rax
000078d1a57d9bad  push rcx
000078d1a57d9bae  push rdx
000078d1a57d9baf  push rdi
000078d1a57d9bb0  push rsi
000078d1a57d9bb1  push r8
000078d1a57d9bb3  push r9
000078d1a57d9bb5  push r10
000078d1a57d9bb7  push r11
000078d1a57d9bb9  sub rsp, 0xF0
000078d1a57d9bc0  vmovaps [rsp], xmm0
000078d1a57d9bc5  vmovaps [rsp+0x10], xmm1
000078d1a57d9bcb  vmovaps [rsp+0x20], xmm2
000078d1a57d9bd1  vmovaps [rsp+0x30], xmm3
000078d1a57d9bd7  vmovaps [rsp+0x40], xmm4
000078d1a57d9bdd  vmovaps [rsp+0x50], xmm5
000078d1a57d9be3  vmovaps [rsp+0x60], xmm6
000078d1a57d9be9  vmovaps [rsp+0x70], xmm7
000078d1a57d9bef  vmovaps [rsp+0x80], xmm8
000078d1a57d9bf8  vmovaps [rsp+0x90], xmm9
000078d1a57d9c01  vmovaps [rsp+0xA0], xmm10
000078d1a57d9c0a  vmovaps [rsp+0xB0], xmm12
000078d1a57d9c13  vmovaps [rsp+0xC0], xmm13
000078d1a57d9c1c  vmovaps [rsp+0xD0], xmm14
000078d1a57d9c25  vmovaps [rsp+0xE0], xmm15
000078d1a57d9c2e  sub rsp, 0x30
000078d1a57d9c32  movaps [rsp], xmm11
000078d1a57d9c37  movaps [rsp+0x10], xmm10
000078d1a57d9c3d  movaps [rsp+0x20], xmm6
000078d1a57d9c42  lea rdi, [rsp]
000078d1a57d9c46  mov esi, 0x00
000078d1a57d9c4b  mov rax, 0x56EA20A26530
000078d1a57d9c55  call rax
000078d1a57d9c57  movaps xmm11, [rsp]
000078d1a57d9c5c  add rsp, 0x30
000078d1a57d9c60  vmovaps xmm0, [rsp]
000078d1a57d9c65  vmovaps xmm1, [rsp+0x10]
000078d1a57d9c6b  vmovaps xmm2, [rsp+0x20]
000078d1a57d9c71  vmovaps xmm3, [rsp+0x30]
000078d1a57d9c77  vmovaps xmm4, [rsp+0x40]
000078d1a57d9c7d  vmovaps xmm5, [rsp+0x50]
000078d1a57d9c83  vmovaps xmm6, [rsp+0x60]
000078d1a57d9c89  vmovaps xmm7, [rsp+0x70]
000078d1a57d9c8f  vmovaps xmm8, [rsp+0x80]
000078d1a57d9c98  vmovaps xmm9, [rsp+0x90]
000078d1a57d9ca1  vmovaps xmm10, [rsp+0xA0]
000078d1a57d9caa  vmovaps xmm12, [rsp+0xB0]
000078d1a57d9cb3  vmovaps xmm13, [rsp+0xC0]
000078d1a57d9cbc  vmovaps xmm14, [rsp+0xD0]
000078d1a57d9cc5  vmovaps xmm15, [rsp+0xE0]
000078d1a57d9cce  add rsp, 0xF0
000078d1a57d9cd5  pop r11
000078d1a57d9cd7  pop r10
000078d1a57d9cd9  pop r9
000078d1a57d9cdb  pop r8
000078d1a57d9cdd  pop rsi
000078d1a57d9cde  pop rdi
000078d1a57d9cdf  pop rdx
000078d1a57d9ce0  pop rcx
000078d1a57d9ce1  pop rax
000078d1a57d9ce2  add rsp, 0x08
000078d1a57d9ce6  jmp 0x000078D1A57D636D
000078d1a57d9ceb  sub rsp, 0x08
000078d1a57d9cef  push rax
000078d1a57d9cf0  push rcx
000078d1a57d9cf1  push rdx
000078d1a57d9cf2  push rdi
000078d1a57d9cf3  push rsi
000078d1a57d9cf4  push r8
000078d1a57d9cf6  push r9
000078d1a57d9cf8  push r10
000078d1a57d9cfa  push r11
000078d1a57d9cfc  sub rsp, 0xF0
000078d1a57d9d03  vmovaps [rsp], xmm0
000078d1a57d9d08  vmovaps [rsp+0x10], xmm1
000078d1a57d9d0e  vmovaps [rsp+0x20], xmm2
000078d1a57d9d14  vmovaps [rsp+0x30], xmm3
000078d1a57d9d1a  vmovaps [rsp+0x40], xmm4
000078d1a57d9d20  vmovaps [rsp+0x50], xmm5
000078d1a57d9d26  vmovaps [rsp+0x60], xmm6
000078d1a57d9d2c  vmovaps [rsp+0x70], xmm7
000078d1a57d9d32  vmovaps [rsp+0x80], xmm8
000078d1a57d9d3b  vmovaps [rsp+0x90], xmm9
000078d1a57d9d44  vmovaps [rsp+0xA0], xmm11
000078d1a57d9d4d  vmovaps [rsp+0xB0], xmm12
000078d1a57d9d56  vmovaps [rsp+0xC0], xmm13
000078d1a57d9d5f  vmovaps [rsp+0xD0], xmm14
000078d1a57d9d68  vmovaps [rsp+0xE0], xmm15
000078d1a57d9d71  sub rsp, 0x30
000078d1a57d9d75  movaps [rsp], xmm10
000078d1a57d9d7a  movaps [rsp+0x10], xmm14
000078d1a57d9d80  movaps [rsp+0x20], xmm4
000078d1a57d9d85  lea rdi, [rsp]
000078d1a57d9d89  mov esi, 0x00
000078d1a57d9d8e  mov rax, 0x56EA20A26530
000078d1a57d9d98  call rax
000078d1a57d9d9a  movaps xmm10, [rsp]
000078d1a57d9d9f  add rsp, 0x30
000078d1a57d9da3  vmovaps xmm0, [rsp]
000078d1a57d9da8  vmovaps xmm1, [rsp+0x10]
000078d1a57d9dae  vmovaps xmm2, [rsp+0x20]
000078d1a57d9db4  vmovaps xmm3, [rsp+0x30]
000078d1a57d9dba  vmovaps xmm4, [rsp+0x40]
000078d1a57d9dc0  vmovaps xmm5, [rsp+0x50]
000078d1a57d9dc6  vmovaps xmm6, [rsp+0x60]
000078d1a57d9dcc  vmovaps xmm7, [rsp+0x70]
000078d1a57d9dd2  vmovaps xmm8, [rsp+0x80]
000078d1a57d9ddb  vmovaps xmm9, [rsp+0x90]
000078d1a57d9de4  vmovaps xmm11, [rsp+0xA0]
000078d1a57d9ded  vmovaps xmm12, [rsp+0xB0]
000078d1a57d9df6  vmovaps xmm13, [rsp+0xC0]
000078d1a57d9dff  vmovaps xmm14, [rsp+0xD0]
000078d1a57d9e08  vmovaps xmm15, [rsp+0xE0]
000078d1a57d9e11  add rsp, 0xF0
000078d1a57d9e18  pop r11
000078d1a57d9e1a  pop r10
000078d1a57d9e1c  pop r9
000078d1a57d9e1e  pop r8
000078d1a57d9e20  pop rsi
000078d1a57d9e21  pop rdi
000078d1a57d9e22  pop rdx
000078d1a57d9e23  pop rcx
000078d1a57d9e24  pop rax
000078d1a57d9e25  add rsp, 0x08
000078d1a57d9e29  jmp 0x000078D1A57D6388
000078d1a57d9e2e  sub rsp, 0x08
000078d1a57d9e32  push rax
000078d1a57d9e33  push rcx
000078d1a57d9e34  push rdx
000078d1a57d9e35  push rdi
000078d1a57d9e36  push rsi
000078d1a57d9e37  push r8
000078d1a57d9e39  push r9
000078d1a57d9e3b  push r10
000078d1a57d9e3d  push r11
000078d1a57d9e3f  sub rsp, 0xF0
000078d1a57d9e46  vmovaps [rsp], xmm0
000078d1a57d9e4b  vmovaps [rsp+0x10], xmm1
000078d1a57d9e51  vmovaps [rsp+0x20], xmm2
000078d1a57d9e57  vmovaps [rsp+0x30], xmm3
000078d1a57d9e5d  vmovaps [rsp+0x40], xmm4
000078d1a57d9e63  vmovaps [rsp+0x50], xmm5
000078d1a57d9e69  vmovaps [rsp+0x60], xmm6
000078d1a57d9e6f  vmovaps [rsp+0x70], xmm7
000078d1a57d9e75  vmovaps [rsp+0x80], xmm9
000078d1a57d9e7e  vmovaps [rsp+0x90], xmm10
000078d1a57d9e87  vmovaps [rsp+0xA0], xmm11
000078d1a57d9e90  vmovaps [rsp+0xB0], xmm12
000078d1a57d9e99  vmovaps [rsp+0xC0], xmm13
000078d1a57d9ea2  vmovaps [rsp+0xD0], xmm14
000078d1a57d9eab  vmovaps [rsp+0xE0], xmm15
000078d1a57d9eb4  sub rsp, 0x30
000078d1a57d9eb8  movaps [rsp], xmm8
000078d1a57d9ebd  movaps [rsp+0x10], xmm1
000078d1a57d9ec2  movaps [rsp+0x20], xmm14
000078d1a57d9ec8  lea rdi, [rsp]
000078d1a57d9ecc  mov esi, 0x00
000078d1a57d9ed1  mov rax, 0x56EA20A26530
000078d1a57d9edb  call rax
000078d1a57d9edd  movaps xmm8, [rsp]
000078d1a57d9ee2  add rsp, 0x30
000078d1a57d9ee6  vmovaps xmm0, [rsp]
000078d1a57d9eeb  vmovaps xmm1, [rsp+0x10]
000078d1a57d9ef1  vmovaps xmm2, [rsp+0x20]
000078d1a57d9ef7  vmovaps xmm3, [rsp+0x30]
000078d1a57d9efd  vmovaps xmm4, [rsp+0x40]
000078d1a57d9f03  vmovaps xmm5, [rsp+0x50]
000078d1a57d9f09  vmovaps xmm6, [rsp+0x60]
000078d1a57d9f0f  vmovaps xmm7, [rsp+0x70]
000078d1a57d9f15  vmovaps xmm9, [rsp+0x80]
000078d1a57d9f1e  vmovaps xmm10, [rsp+0x90]
000078d1a57d9f27  vmovaps xmm11, [rsp+0xA0]
000078d1a57d9f30  vmovaps xmm12, [rsp+0xB0]
000078d1a57d9f39  vmovaps xmm13, [rsp+0xC0]
000078d1a57d9f42  vmovaps xmm14, [rsp+0xD0]
000078d1a57d9f4b  vmovaps xmm15, [rsp+0xE0]
000078d1a57d9f54  add rsp, 0xF0
000078d1a57d9f5b  pop r11
000078d1a57d9f5d  pop r10
000078d1a57d9f5f  pop r9
000078d1a57d9f61  pop r8
000078d1a57d9f63  pop rsi
000078d1a57d9f64  pop rdi
000078d1a57d9f65  pop rdx
000078d1a57d9f66  pop rcx
000078d1a57d9f67  pop rax
000078d1a57d9f68  add rsp, 0x08
000078d1a57d9f6c  jmp 0x000078D1A57D63AE
000078d1a57d9f71  sub rsp, 0x08
000078d1a57d9f75  push rax
000078d1a57d9f76  push rcx
000078d1a57d9f77  push rdx
000078d1a57d9f78  push rdi
000078d1a57d9f79  push rsi
000078d1a57d9f7a  push r8
000078d1a57d9f7c  push r9
000078d1a57d9f7e  push r10
000078d1a57d9f80  push r11
000078d1a57d9f82  sub rsp, 0xF0
000078d1a57d9f89  vmovaps [rsp], xmm0
000078d1a57d9f8e  vmovaps [rsp+0x10], xmm1
000078d1a57d9f94  vmovaps [rsp+0x20], xmm2
000078d1a57d9f9a  vmovaps [rsp+0x30], xmm3
000078d1a57d9fa0  vmovaps [rsp+0x40], xmm4
000078d1a57d9fa6  vmovaps [rsp+0x50], xmm5
000078d1a57d9fac  vmovaps [rsp+0x60], xmm7
000078d1a57d9fb2  vmovaps [rsp+0x70], xmm8
000078d1a57d9fb8  vmovaps [rsp+0x80], xmm9
000078d1a57d9fc1  vmovaps [rsp+0x90], xmm10
000078d1a57d9fca  vmovaps [rsp+0xA0], xmm11
000078d1a57d9fd3  vmovaps [rsp+0xB0], xmm12
000078d1a57d9fdc  vmovaps [rsp+0xC0], xmm13
000078d1a57d9fe5  vmovaps [rsp+0xD0], xmm14
000078d1a57d9fee  vmovaps [rsp+0xE0], xmm15
000078d1a57d9ff7  sub rsp, 0x30
000078d1a57d9ffb  movaps [rsp], xmm6
000078d1a57d9fff  movaps [rsp+0x10], xmm1
000078d1a57da004  movaps [rsp+0x20], xmm14
000078d1a57da00a  lea rdi, [rsp]
000078d1a57da00e  mov esi, 0x00
000078d1a57da013  mov rax, 0x56EA20A26530
000078d1a57da01d  call rax
000078d1a57da01f  movaps xmm6, [rsp]
000078d1a57da023  add rsp, 0x30
000078d1a57da027  vmovaps xmm0, [rsp]
000078d1a57da02c  vmovaps xmm1, [rsp+0x10]
000078d1a57da032  vmovaps xmm2, [rsp+0x20]
000078d1a57da038  vmovaps xmm3, [rsp+0x30]
000078d1a57da03e  vmovaps xmm4, [rsp+0x40]
000078d1a57da044  vmovaps xmm5, [rsp+0x50]
000078d1a57da04a  vmovaps xmm7, [rsp+0x60]
000078d1a57da050  vmovaps xmm8, [rsp+0x70]
000078d1a57da056  vmovaps xmm9, [rsp+0x80]
000078d1a57da05f  vmovaps xmm10, [rsp+0x90]
000078d1a57da068  vmovaps xmm11, [rsp+0xA0]
000078d1a57da071  vmovaps xmm12, [rsp+0xB0]
000078d1a57da07a  vmovaps xmm13, [rsp+0xC0]
000078d1a57da083  vmovaps xmm14, [rsp+0xD0]
000078d1a57da08c  vmovaps xmm15, [rsp+0xE0]
000078d1a57da095  add rsp, 0xF0
000078d1a57da09c  pop r11
000078d1a57da09e  pop r10
000078d1a57da0a0  pop r9
000078d1a57da0a2  pop r8
000078d1a57da0a4  pop rsi
000078d1a57da0a5  pop rdi
000078d1a57da0a6  pop rdx
000078d1a57da0a7  pop rcx
000078d1a57da0a8  pop rax
000078d1a57da0a9  add rsp, 0x08
000078d1a57da0ad  jmp 0x000078D1A57D63DA
000078d1a57da0b2  sub rsp, 0x08
000078d1a57da0b6  push rax
000078d1a57da0b7  push rcx
000078d1a57da0b8  push rdx
000078d1a57da0b9  push rdi
000078d1a57da0ba  push rsi
000078d1a57da0bb  push r8
000078d1a57da0bd  push r9
000078d1a57da0bf  push r10
000078d1a57da0c1  push r11
000078d1a57da0c3  sub rsp, 0xF0
000078d1a57da0ca  vmovaps [rsp], xmm0
000078d1a57da0cf  vmovaps [rsp+0x10], xmm1
000078d1a57da0d5  vmovaps [rsp+0x20], xmm2
000078d1a57da0db  vmovaps [rsp+0x30], xmm3
000078d1a57da0e1  vmovaps [rsp+0x40], xmm4
000078d1a57da0e7  vmovaps [rsp+0x50], xmm5
000078d1a57da0ed  vmovaps [rsp+0x60], xmm6
000078d1a57da0f3  vmovaps [rsp+0x70], xmm7
000078d1a57da0f9  vmovaps [rsp+0x80], xmm8
000078d1a57da102  vmovaps [rsp+0x90], xmm9
000078d1a57da10b  vmovaps [rsp+0xA0], xmm10
000078d1a57da114  vmovaps [rsp+0xB0], xmm11
000078d1a57da11d  vmovaps [rsp+0xC0], xmm12
000078d1a57da126  vmovaps [rsp+0xD0], xmm13
000078d1a57da12f  vmovaps [rsp+0xE0], xmm15
000078d1a57da138  sub rsp, 0x30
000078d1a57da13c  movaps [rsp], xmm14
000078d1a57da141  movaps [rsp+0x10], xmm12
000078d1a57da147  movaps [rsp+0x20], xmm1
000078d1a57da14c  lea rdi, [rsp]
000078d1a57da150  mov esi, 0x00
000078d1a57da155  mov rax, 0x56EA20A26530
000078d1a57da15f  call rax
000078d1a57da161  movaps xmm14, [rsp]
000078d1a57da166  add rsp, 0x30
000078d1a57da16a  vmovaps xmm0, [rsp]
000078d1a57da16f  vmovaps xmm1, [rsp+0x10]
000078d1a57da175  vmovaps xmm2, [rsp+0x20]
000078d1a57da17b  vmovaps xmm3, [rsp+0x30]
000078d1a57da181  vmovaps xmm4, [rsp+0x40]
000078d1a57da187  vmovaps xmm5, [rsp+0x50]
000078d1a57da18d  vmovaps xmm6, [rsp+0x60]
000078d1a57da193  vmovaps xmm7, [rsp+0x70]
000078d1a57da199  vmovaps xmm8, [rsp+0x80]
000078d1a57da1a2  vmovaps xmm9, [rsp+0x90]
000078d1a57da1ab  vmovaps xmm10, [rsp+0xA0]
000078d1a57da1b4  vmovaps xmm11, [rsp+0xB0]
000078d1a57da1bd  vmovaps xmm12, [rsp+0xC0]
000078d1a57da1c6  vmovaps xmm13, [rsp+0xD0]
000078d1a57da1cf  vmovaps xmm15, [rsp+0xE0]
000078d1a57da1d8  add rsp, 0xF0
000078d1a57da1df  pop r11
000078d1a57da1e1  pop r10
000078d1a57da1e3  pop r9
000078d1a57da1e5  pop r8
000078d1a57da1e7  pop rsi
000078d1a57da1e8  pop rdi
000078d1a57da1e9  pop rdx
000078d1a57da1ea  pop rcx
000078d1a57da1eb  pop rax
000078d1a57da1ec  add rsp, 0x08
000078d1a57da1f0  jmp 0x000078D1A57D6400
000078d1a57da1f5  sub rsp, 0x08
000078d1a57da1f9  push rax
000078d1a57da1fa  push rcx
000078d1a57da1fb  push rdx
000078d1a57da1fc  push rdi
000078d1a57da1fd  push rsi
000078d1a57da1fe  push r8
000078d1a57da200  push r9
000078d1a57da202  push r10
000078d1a57da204  push r11
000078d1a57da206  sub rsp, 0xF0
000078d1a57da20d  vmovaps [rsp], xmm0
000078d1a57da212  vmovaps [rsp+0x10], xmm2
000078d1a57da218  vmovaps [rsp+0x20], xmm3
000078d1a57da21e  vmovaps [rsp+0x30], xmm4
000078d1a57da224  vmovaps [rsp+0x40], xmm5
000078d1a57da22a  vmovaps [rsp+0x50], xmm6
000078d1a57da230  vmovaps [rsp+0x60], xmm7
000078d1a57da236  vmovaps [rsp+0x70], xmm8
000078d1a57da23c  vmovaps [rsp+0x80], xmm9
000078d1a57da245  vmovaps [rsp+0x90], xmm10
000078d1a57da24e  vmovaps [rsp+0xA0], xmm11
000078d1a57da257  vmovaps [rsp+0xB0], xmm12
000078d1a57da260  vmovaps [rsp+0xC0], xmm13
000078d1a57da269  vmovaps [rsp+0xD0], xmm14
000078d1a57da272  vmovaps [rsp+0xE0], xmm15
000078d1a57da27b  sub rsp, 0x30
000078d1a57da27f  movaps [rsp], xmm1
000078d1a57da283  movaps [rsp+0x10], xmm13
000078d1a57da289  movaps [rsp+0x20], xmm9
000078d1a57da28f  lea rdi, [rsp]
000078d1a57da293  mov esi, 0x00
000078d1a57da298  mov rax, 0x56EA20A26530
000078d1a57da2a2  call rax
000078d1a57da2a4  movaps xmm1, [rsp]
000078d1a57da2a8  add rsp, 0x30
000078d1a57da2ac  vmovaps xmm0, [rsp]
000078d1a57da2b1  vmovaps xmm2, [rsp+0x10]
000078d1a57da2b7  vmovaps xmm3, [rsp+0x20]
000078d1a57da2bd  vmovaps xmm4, [rsp+0x30]
000078d1a57da2c3  vmovaps xmm5, [rsp+0x40]
000078d1a57da2c9  vmovaps xmm6, [rsp+0x50]
000078d1a57da2cf  vmovaps xmm7, [rsp+0x60]
000078d1a57da2d5  vmovaps xmm8, [rsp+0x70]
000078d1a57da2db  vmovaps xmm9, [rsp+0x80]
000078d1a57da2e4  vmovaps xmm10, [rsp+0x90]
000078d1a57da2ed  vmovaps xmm11, [rsp+0xA0]
000078d1a57da2f6  vmovaps xmm12, [rsp+0xB0]
000078d1a57da2ff  vmovaps xmm13, [rsp+0xC0]
000078d1a57da308  vmovaps xmm14, [rsp+0xD0]
000078d1a57da311  vmovaps xmm15, [rsp+0xE0]
000078d1a57da31a  add rsp, 0xF0
000078d1a57da321  pop r11
000078d1a57da323  pop r10
000078d1a57da325  pop r9
000078d1a57da327  pop r8
000078d1a57da329  pop rsi
000078d1a57da32a  pop rdi
000078d1a57da32b  pop rdx
000078d1a57da32c  pop rcx
000078d1a57da32d  pop rax
000078d1a57da32e  add rsp, 0x08
000078d1a57da332  jmp 0x000078D1A57D641A
000078d1a57da337  sub rsp, 0x08
000078d1a57da33b  push rax
000078d1a57da33c  push rcx
000078d1a57da33d  push rdx
000078d1a57da33e  push rdi
000078d1a57da33f  push rsi
000078d1a57da340  push r8
000078d1a57da342  push r9
000078d1a57da344  push r10
000078d1a57da346  push r11
000078d1a57da348  sub rsp, 0xF0
000078d1a57da34f  vmovaps [rsp], xmm0
000078d1a57da354  vmovaps [rsp+0x10], xmm1
000078d1a57da35a  vmovaps [rsp+0x20], xmm2
000078d1a57da360  vmovaps [rsp+0x30], xmm3
000078d1a57da366  vmovaps [rsp+0x40], xmm4
000078d1a57da36c  vmovaps [rsp+0x50], xmm5
000078d1a57da372  vmovaps [rsp+0x60], xmm6
000078d1a57da378  vmovaps [rsp+0x70], xmm7
000078d1a57da37e  vmovaps [rsp+0x80], xmm8
000078d1a57da387  vmovaps [rsp+0x90], xmm9
000078d1a57da390  vmovaps [rsp+0xA0], xmm10
000078d1a57da399  vmovaps [rsp+0xB0], xmm11
000078d1a57da3a2  vmovaps [rsp+0xC0], xmm13
000078d1a57da3ab  vmovaps [rsp+0xD0], xmm14
000078d1a57da3b4  vmovaps [rsp+0xE0], xmm15
000078d1a57da3bd  sub rsp, 0x30
000078d1a57da3c1  movaps [rsp], xmm12
000078d1a57da3c6  movaps [rsp+0x10], xmm7
000078d1a57da3cb  movaps [rsp+0x20], xmm13
000078d1a57da3d1  lea rdi, [rsp]
000078d1a57da3d5  mov esi, 0x00
000078d1a57da3da  mov rax, 0x56EA20A26530
000078d1a57da3e4  call rax
000078d1a57da3e6  movaps xmm12, [rsp]
000078d1a57da3eb  add rsp, 0x30
000078d1a57da3ef  vmovaps xmm0, [rsp]
000078d1a57da3f4  vmovaps xmm1, [rsp+0x10]
000078d1a57da3fa  vmovaps xmm2, [rsp+0x20]
000078d1a57da400  vmovaps xmm3, [rsp+0x30]
000078d1a57da406  vmovaps xmm4, [rsp+0x40]
000078d1a57da40c  vmovaps xmm5, [rsp+0x50]
000078d1a57da412  vmovaps xmm6, [rsp+0x60]
000078d1a57da418  vmovaps xmm7, [rsp+0x70]
000078d1a57da41e  vmovaps xmm8, [rsp+0x80]
000078d1a57da427  vmovaps xmm9, [rsp+0x90]
000078d1a57da430  vmovaps xmm10, [rsp+0xA0]
000078d1a57da439  vmovaps xmm11, [rsp+0xB0]
000078d1a57da442  vmovaps xmm13, [rsp+0xC0]
000078d1a57da44b  vmovaps xmm14, [rsp+0xD0]
000078d1a57da454  vmovaps xmm15, [rsp+0xE0]
000078d1a57da45d  add rsp, 0xF0
000078d1a57da464  pop r11
000078d1a57da466  pop r10
000078d1a57da468  pop r9
000078d1a57da46a  pop r8
000078d1a57da46c  pop rsi
000078d1a57da46d  pop rdi
000078d1a57da46e  pop rdx
000078d1a57da46f  pop rcx
000078d1a57da470  pop rax
000078d1a57da471  add rsp, 0x08
000078d1a57da475  jmp 0x000078D1A57D6441
000078d1a57da47a  sub rsp, 0x08
000078d1a57da47e  push rax
000078d1a57da47f  push rcx
000078d1a57da480  push rdx
000078d1a57da481  push rdi
000078d1a57da482  push rsi
000078d1a57da483  push r8
000078d1a57da485  push r9
000078d1a57da487  push r10
000078d1a57da489  push r11
000078d1a57da48b  sub rsp, 0xF0
000078d1a57da492  vmovaps [rsp], xmm0
000078d1a57da497  vmovaps [rsp+0x10], xmm1
000078d1a57da49d  vmovaps [rsp+0x20], xmm2
000078d1a57da4a3  vmovaps [rsp+0x30], xmm3
000078d1a57da4a9  vmovaps [rsp+0x40], xmm4
000078d1a57da4af  vmovaps [rsp+0x50], xmm5
000078d1a57da4b5  vmovaps [rsp+0x60], xmm6
000078d1a57da4bb  vmovaps [rsp+0x70], xmm7
000078d1a57da4c1  vmovaps [rsp+0x80], xmm8
000078d1a57da4ca  vmovaps [rsp+0x90], xmm9
000078d1a57da4d3  vmovaps [rsp+0xA0], xmm10
000078d1a57da4dc  vmovaps [rsp+0xB0], xmm11
000078d1a57da4e5  vmovaps [rsp+0xC0], xmm12
000078d1a57da4ee  vmovaps [rsp+0xD0], xmm14
000078d1a57da4f7  vmovaps [rsp+0xE0], xmm15
000078d1a57da500  sub rsp, 0x30
000078d1a57da504  movaps [rsp], xmm13
000078d1a57da509  movaps [rsp+0x10], xmm15
000078d1a57da50f  movaps [rsp+0x20], xmm8
000078d1a57da515  lea rdi, [rsp]
000078d1a57da519  mov esi, 0x00
000078d1a57da51e  mov rax, 0x56EA20A26530
000078d1a57da528  call rax
000078d1a57da52a  movaps xmm13, [rsp]
000078d1a57da52f  add rsp, 0x30
000078d1a57da533  vmovaps xmm0, [rsp]
000078d1a57da538  vmovaps xmm1, [rsp+0x10]
000078d1a57da53e  vmovaps xmm2, [rsp+0x20]
000078d1a57da544  vmovaps xmm3, [rsp+0x30]
000078d1a57da54a  vmovaps xmm4, [rsp+0x40]
000078d1a57da550  vmovaps xmm5, [rsp+0x50]
000078d1a57da556  vmovaps xmm6, [rsp+0x60]
000078d1a57da55c  vmovaps xmm7, [rsp+0x70]
000078d1a57da562  vmovaps xmm8, [rsp+0x80]
000078d1a57da56b  vmovaps xmm9, [rsp+0x90]
000078d1a57da574  vmovaps xmm10, [rsp+0xA0]
000078d1a57da57d  vmovaps xmm11, [rsp+0xB0]
000078d1a57da586  vmovaps xmm12, [rsp+0xC0]
000078d1a57da58f  vmovaps xmm14, [rsp+0xD0]
000078d1a57da598  vmovaps xmm15, [rsp+0xE0]
000078d1a57da5a1  add rsp, 0xF0
000078d1a57da5a8  pop r11
000078d1a57da5aa  pop r10
000078d1a57da5ac  pop r9
000078d1a57da5ae  pop r8
000078d1a57da5b0  pop rsi
000078d1a57da5b1  pop rdi
000078d1a57da5b2  pop rdx
000078d1a57da5b3  pop rcx
000078d1a57da5b4  pop rax
000078d1a57da5b5  add rsp, 0x08
000078d1a57da5b9  jmp 0x000078D1A57D645C
000078d1a57da5be  sub rsp, 0x08
000078d1a57da5c2  push rax
000078d1a57da5c3  push rcx
000078d1a57da5c4  push rdx
000078d1a57da5c5  push rdi
000078d1a57da5c6  push rsi
000078d1a57da5c7  push r8
000078d1a57da5c9  push r9
000078d1a57da5cb  push r10
000078d1a57da5cd  push r11
000078d1a57da5cf  sub rsp, 0xF0
000078d1a57da5d6  vmovaps [rsp], xmm0
000078d1a57da5db  vmovaps [rsp+0x10], xmm1
000078d1a57da5e1  vmovaps [rsp+0x20], xmm2
000078d1a57da5e7  vmovaps [rsp+0x30], xmm3
000078d1a57da5ed  vmovaps [rsp+0x40], xmm4
000078d1a57da5f3  vmovaps [rsp+0x50], xmm5
000078d1a57da5f9  vmovaps [rsp+0x60], xmm6
000078d1a57da5ff  vmovaps [rsp+0x70], xmm7
000078d1a57da605  vmovaps [rsp+0x80], xmm9
000078d1a57da60e  vmovaps [rsp+0x90], xmm10
000078d1a57da617  vmovaps [rsp+0xA0], xmm11
000078d1a57da620  vmovaps [rsp+0xB0], xmm12
000078d1a57da629  vmovaps [rsp+0xC0], xmm13
000078d1a57da632  vmovaps [rsp+0xD0], xmm14
000078d1a57da63b  vmovaps [rsp+0xE0], xmm15
000078d1a57da644  sub rsp, 0x30
000078d1a57da648  movaps [rsp], xmm8
000078d1a57da64d  movaps [rsp+0x10], xmm15
000078d1a57da653  movaps [rsp+0x20], xmm9
000078d1a57da659  lea rdi, [rsp]
000078d1a57da65d  mov esi, 0x00
000078d1a57da662  mov rax, 0x56EA20A26530
000078d1a57da66c  call rax
000078d1a57da66e  movaps xmm8, [rsp]
000078d1a57da673  add rsp, 0x30
000078d1a57da677  vmovaps xmm0, [rsp]
000078d1a57da67c  vmovaps xmm1, [rsp+0x10]
000078d1a57da682  vmovaps xmm2, [rsp+0x20]
000078d1a57da688  vmovaps xmm3, [rsp+0x30]
000078d1a57da68e  vmovaps xmm4, [rsp+0x40]
000078d1a57da694  vmovaps xmm5, [rsp+0x50]
000078d1a57da69a  vmovaps xmm6, [rsp+0x60]
000078d1a57da6a0  vmovaps xmm7, [rsp+0x70]
000078d1a57da6a6  vmovaps xmm9, [rsp+0x80]
000078d1a57da6af  vmovaps xmm10, [rsp+0x90]
000078d1a57da6b8  vmovaps xmm11, [rsp+0xA0]
000078d1a57da6c1  vmovaps xmm12, [rsp+0xB0]
000078d1a57da6ca  vmovaps xmm13, [rsp+0xC0]
000078d1a57da6d3  vmovaps xmm14, [rsp+0xD0]
000078d1a57da6dc  vmovaps xmm15, [rsp+0xE0]
000078d1a57da6e5  add rsp, 0xF0
000078d1a57da6ec  pop r11
000078d1a57da6ee  pop r10
000078d1a57da6f0  pop r9
000078d1a57da6f2  pop r8
000078d1a57da6f4  pop rsi
000078d1a57da6f5  pop rdi
000078d1a57da6f6  pop rdx
000078d1a57da6f7  pop rcx
000078d1a57da6f8  pop rax
000078d1a57da6f9  add rsp, 0x08
000078d1a57da6fd  jmp 0x000078D1A57D648A
000078d1a57da702  sub rsp, 0x08
000078d1a57da706  push rax
000078d1a57da707  push rcx
000078d1a57da708  push rdx
000078d1a57da709  push rdi
000078d1a57da70a  push rsi
000078d1a57da70b  push r8
000078d1a57da70d  push r9
000078d1a57da70f  push r10
000078d1a57da711  push r11
000078d1a57da713  sub rsp, 0xF0
000078d1a57da71a  vmovaps [rsp], xmm0
000078d1a57da71f  vmovaps [rsp+0x10], xmm1
000078d1a57da725  vmovaps [rsp+0x20], xmm2
000078d1a57da72b  vmovaps [rsp+0x30], xmm3
000078d1a57da731  vmovaps [rsp+0x40], xmm4
000078d1a57da737  vmovaps [rsp+0x50], xmm5
000078d1a57da73d  vmovaps [rsp+0x60], xmm6
000078d1a57da743  vmovaps [rsp+0x70], xmm7
000078d1a57da749  vmovaps [rsp+0x80], xmm8
000078d1a57da752  vmovaps [rsp+0x90], xmm9
000078d1a57da75b  vmovaps [rsp+0xA0], xmm10
000078d1a57da764  vmovaps [rsp+0xB0], xmm11
000078d1a57da76d  vmovaps [rsp+0xC0], xmm12
000078d1a57da776  vmovaps [rsp+0xD0], xmm13
000078d1a57da77f  vmovaps [rsp+0xE0], xmm14
000078d1a57da788  sub rsp, 0x30
000078d1a57da78c  movaps [rsp], xmm15
000078d1a57da791  movaps [rsp+0x10], xmm11
000078d1a57da797  movaps [rsp+0x20], xmm6
000078d1a57da79c  lea rdi, [rsp]
000078d1a57da7a0  mov esi, 0x00
000078d1a57da7a5  mov rax, 0x56EA20A26530
000078d1a57da7af  call rax
000078d1a57da7b1  movaps xmm15, [rsp]
000078d1a57da7b6  add rsp, 0x30
000078d1a57da7ba  vmovaps xmm0, [rsp]
000078d1a57da7bf  vmovaps xmm1, [rsp+0x10]
000078d1a57da7c5  vmovaps xmm2, [rsp+0x20]
000078d1a57da7cb  vmovaps xmm3, [rsp+0x30]
000078d1a57da7d1  vmovaps xmm4, [rsp+0x40]
000078d1a57da7d7  vmovaps xmm5, [rsp+0x50]
000078d1a57da7dd  vmovaps xmm6, [rsp+0x60]
000078d1a57da7e3  vmovaps xmm7, [rsp+0x70]
000078d1a57da7e9  vmovaps xmm8, [rsp+0x80]
000078d1a57da7f2  vmovaps xmm9, [rsp+0x90]
000078d1a57da7fb  vmovaps xmm10, [rsp+0xA0]
000078d1a57da804  vmovaps xmm11, [rsp+0xB0]
000078d1a57da80d  vmovaps xmm12, [rsp+0xC0]
000078d1a57da816  vmovaps xmm13, [rsp+0xD0]
000078d1a57da81f  vmovaps xmm14, [rsp+0xE0]
000078d1a57da828  add rsp, 0xF0
000078d1a57da82f  pop r11
000078d1a57da831  pop r10
000078d1a57da833  pop r9
000078d1a57da835  pop r8
000078d1a57da837  pop rsi
000078d1a57da838  pop rdi
000078d1a57da839  pop rdx
000078d1a57da83a  pop rcx
000078d1a57da83b  pop rax
000078d1a57da83c  add rsp, 0x08
000078d1a57da840  jmp 0x000078D1A57D64A5
000078d1a57da845  sub rsp, 0x08
000078d1a57da849  push rax
000078d1a57da84a  push rcx
000078d1a57da84b  push rdx
000078d1a57da84c  push rdi
000078d1a57da84d  push rsi
000078d1a57da84e  push r8
000078d1a57da850  push r9
000078d1a57da852  push r10
000078d1a57da854  push r11
000078d1a57da856  sub rsp, 0xF0
000078d1a57da85d  vmovaps [rsp], xmm0
000078d1a57da862  vmovaps [rsp+0x10], xmm1
000078d1a57da868  vmovaps [rsp+0x20], xmm2
000078d1a57da86e  vmovaps [rsp+0x30], xmm3
000078d1a57da874  vmovaps [rsp+0x40], xmm4
000078d1a57da87a  vmovaps [rsp+0x50], xmm5
000078d1a57da880  vmovaps [rsp+0x60], xmm6
000078d1a57da886  vmovaps [rsp+0x70], xmm8
000078d1a57da88c  vmovaps [rsp+0x80], xmm9
000078d1a57da895  vmovaps [rsp+0x90], xmm10
000078d1a57da89e  vmovaps [rsp+0xA0], xmm11
000078d1a57da8a7  vmovaps [rsp+0xB0], xmm12
000078d1a57da8b0  vmovaps [rsp+0xC0], xmm13
000078d1a57da8b9  vmovaps [rsp+0xD0], xmm14
000078d1a57da8c2  vmovaps [rsp+0xE0], xmm15
000078d1a57da8cb  sub rsp, 0x30
000078d1a57da8cf  movaps [rsp], xmm7
000078d1a57da8d3  movaps [rsp+0x10], xmm11
000078d1a57da8d9  movaps [rsp+0x20], xmm9
000078d1a57da8df  lea rdi, [rsp]
000078d1a57da8e3  mov esi, 0x00
000078d1a57da8e8  mov rax, 0x56EA20A26530
000078d1a57da8f2  call rax
000078d1a57da8f4  movaps xmm7, [rsp]
000078d1a57da8f8  add rsp, 0x30
000078d1a57da8fc  vmovaps xmm0, [rsp]
000078d1a57da901  vmovaps xmm1, [rsp+0x10]
000078d1a57da907  vmovaps xmm2, [rsp+0x20]
000078d1a57da90d  vmovaps xmm3, [rsp+0x30]
000078d1a57da913  vmovaps xmm4, [rsp+0x40]
000078d1a57da919  vmovaps xmm5, [rsp+0x50]
000078d1a57da91f  vmovaps xmm6, [rsp+0x60]
000078d1a57da925  vmovaps xmm8, [rsp+0x70]
000078d1a57da92b  vmovaps xmm9, [rsp+0x80]
000078d1a57da934  vmovaps xmm10, [rsp+0x90]
000078d1a57da93d  vmovaps xmm11, [rsp+0xA0]
000078d1a57da946  vmovaps xmm12, [rsp+0xB0]
000078d1a57da94f  vmovaps xmm13, [rsp+0xC0]
000078d1a57da958  vmovaps xmm14, [rsp+0xD0]
000078d1a57da961  vmovaps xmm15, [rsp+0xE0]
000078d1a57da96a  add rsp, 0xF0
000078d1a57da971  pop r11
000078d1a57da973  pop r10
000078d1a57da975  pop r9
000078d1a57da977  pop r8
000078d1a57da979  pop rsi
000078d1a57da97a  pop rdi
000078d1a57da97b  pop rdx
000078d1a57da97c  pop rcx
000078d1a57da97d  pop rax
000078d1a57da97e  add rsp, 0x08
000078d1a57da982  jmp 0x000078D1A57D64D2
000078d1a57da987  sub rsp, 0x08
000078d1a57da98b  push rax
000078d1a57da98c  push rcx
000078d1a57da98d  push rdx
000078d1a57da98e  push rdi
000078d1a57da98f  push rsi
000078d1a57da990  push r8
000078d1a57da992  push r9
000078d1a57da994  push r10
000078d1a57da996  push r11
000078d1a57da998  sub rsp, 0xF0
000078d1a57da99f  vmovaps [rsp], xmm0
000078d1a57da9a4  vmovaps [rsp+0x10], xmm1
000078d1a57da9aa  vmovaps [rsp+0x20], xmm2
000078d1a57da9b0  vmovaps [rsp+0x30], xmm3
000078d1a57da9b6  vmovaps [rsp+0x40], xmm4
000078d1a57da9bc  vmovaps [rsp+0x50], xmm5
000078d1a57da9c2  vmovaps [rsp+0x60], xmm6
000078d1a57da9c8  vmovaps [rsp+0x70], xmm7
000078d1a57da9ce  vmovaps [rsp+0x80], xmm8
000078d1a57da9d7  vmovaps [rsp+0x90], xmm9
000078d1a57da9e0  vmovaps [rsp+0xA0], xmm10
000078d1a57da9e9  vmovaps [rsp+0xB0], xmm12
000078d1a57da9f2  vmovaps [rsp+0xC0], xmm13
000078d1a57da9fb  vmovaps [rsp+0xD0], xmm14
000078d1a57daa04  vmovaps [rsp+0xE0], xmm15
000078d1a57daa0d  sub rsp, 0x30
000078d1a57daa11  movaps [rsp], xmm11
000078d1a57daa16  movaps [rsp+0x10], xmm10
000078d1a57daa1c  movaps [rsp+0x20], xmm14
000078d1a57daa22  lea rdi, [rsp]
000078d1a57daa26  mov esi, 0x00
000078d1a57daa2b  mov rax, 0x56EA20A26530
000078d1a57daa35  call rax
000078d1a57daa37  movaps xmm11, [rsp]
000078d1a57daa3c  add rsp, 0x30
000078d1a57daa40  vmovaps xmm0, [rsp]
000078d1a57daa45  vmovaps xmm1, [rsp+0x10]
000078d1a57daa4b  vmovaps xmm2, [rsp+0x20]
000078d1a57daa51  vmovaps xmm3, [rsp+0x30]
000078d1a57daa57  vmovaps xmm4, [rsp+0x40]
000078d1a57daa5d  vmovaps xmm5, [rsp+0x50]
000078d1a57daa63  vmovaps xmm6, [rsp+0x60]
000078d1a57daa69  vmovaps xmm7, [rsp+0x70]
000078d1a57daa6f  vmovaps xmm8, [rsp+0x80]
000078d1a57daa78  vmovaps xmm9, [rsp+0x90]
000078d1a57daa81  vmovaps xmm10, [rsp+0xA0]
000078d1a57daa8a  vmovaps xmm12, [rsp+0xB0]
000078d1a57daa93  vmovaps xmm13, [rsp+0xC0]
000078d1a57daa9c  vmovaps xmm14, [rsp+0xD0]
000078d1a57daaa5  vmovaps xmm15, [rsp+0xE0]
000078d1a57daaae  add rsp, 0xF0
000078d1a57daab5  pop r11
000078d1a57daab7  pop r10
000078d1a57daab9  pop r9
000078d1a57daabb  pop r8
000078d1a57daabd  pop rsi
000078d1a57daabe  pop rdi
000078d1a57daabf  pop rdx
000078d1a57daac0  pop rcx
000078d1a57daac1  pop rax
000078d1a57daac2  add rsp, 0x08
000078d1a57daac6  jmp 0x000078D1A57D64ED
000078d1a57daacb  call 0x000078D1A56E45A0
000078d1a57daad0  jmp 0x000078D1A57D64F7
000078d1a57daad5  sub rsp, 0x08
000078d1a57daad9  push rax
000078d1a57daada  push rcx
000078d1a57daadb  push rdx
000078d1a57daadc  push rdi
000078d1a57daadd  push rsi
000078d1a57daade  push r8
000078d1a57daae0  push r9
000078d1a57daae2  push r10
000078d1a57daae4  push r11
000078d1a57daae6  sub rsp, 0xF0
000078d1a57daaed  vmovaps [rsp], xmm0
000078d1a57daaf2  vmovaps [rsp+0x10], xmm1
000078d1a57daaf8  vmovaps [rsp+0x20], xmm2
000078d1a57daafe  vmovaps [rsp+0x30], xmm3
000078d1a57dab04  vmovaps [rsp+0x40], xmm4
000078d1a57dab0a  vmovaps [rsp+0x50], xmm5
000078d1a57dab10  vmovaps [rsp+0x60], xmm6
000078d1a57dab16  vmovaps [rsp+0x70], xmm7
000078d1a57dab1c  vmovaps [rsp+0x80], xmm8
000078d1a57dab25  vmovaps [rsp+0x90], xmm9
000078d1a57dab2e  vmovaps [rsp+0xA0], xmm11
000078d1a57dab37  vmovaps [rsp+0xB0], xmm12
000078d1a57dab40  vmovaps [rsp+0xC0], xmm13
000078d1a57dab49  vmovaps [rsp+0xD0], xmm14
000078d1a57dab52  vmovaps [rsp+0xE0], xmm15
000078d1a57dab5b  sub rsp, 0x30
000078d1a57dab5f  movaps [rsp], xmm10
000078d1a57dab64  movaps [rsp+0x10], xmm1
000078d1a57dab69  movaps [rsp+0x20], xmm12
000078d1a57dab6f  lea rdi, [rsp]
000078d1a57dab73  mov esi, 0x00
000078d1a57dab78  mov rax, 0x56EA20A26530
000078d1a57dab82  call rax
000078d1a57dab84  movaps xmm10, [rsp]
000078d1a57dab89  add rsp, 0x30
000078d1a57dab8d  vmovaps xmm0, [rsp]
000078d1a57dab92  vmovaps xmm1, [rsp+0x10]
000078d1a57dab98  vmovaps xmm2, [rsp+0x20]
000078d1a57dab9e  vmovaps xmm3, [rsp+0x30]
000078d1a57daba4  vmovaps xmm4, [rsp+0x40]
000078d1a57dabaa  vmovaps xmm5, [rsp+0x50]
000078d1a57dabb0  vmovaps xmm6, [rsp+0x60]
000078d1a57dabb6  vmovaps xmm7, [rsp+0x70]
000078d1a57dabbc  vmovaps xmm8, [rsp+0x80]
000078d1a57dabc5  vmovaps xmm9, [rsp+0x90]
000078d1a57dabce  vmovaps xmm11, [rsp+0xA0]
000078d1a57dabd7  vmovaps xmm12, [rsp+0xB0]
000078d1a57dabe0  vmovaps xmm13, [rsp+0xC0]
000078d1a57dabe9  vmovaps xmm14, [rsp+0xD0]
000078d1a57dabf2  vmovaps xmm15, [rsp+0xE0]
000078d1a57dabfb  add rsp, 0xF0
000078d1a57dac02  pop r11
000078d1a57dac04  pop r10
000078d1a57dac06  pop r9
000078d1a57dac08  pop r8
000078d1a57dac0a  pop rsi
000078d1a57dac0b  pop rdi
000078d1a57dac0c  pop rdx
000078d1a57dac0d  pop rcx
000078d1a57dac0e  pop rax
000078d1a57dac0f  add rsp, 0x08
000078d1a57dac13  jmp 0x000078D1A57D651A
000078d1a57dac18  sub rsp, 0x08
000078d1a57dac1c  push rax
000078d1a57dac1d  push rcx
000078d1a57dac1e  push rdx
000078d1a57dac1f  push rdi
000078d1a57dac20  push rsi
000078d1a57dac21  push r8
000078d1a57dac23  push r9
000078d1a57dac25  push r10
000078d1a57dac27  push r11
000078d1a57dac29  sub rsp, 0xF0
000078d1a57dac30  vmovaps [rsp], xmm0
000078d1a57dac35  vmovaps [rsp+0x10], xmm1
000078d1a57dac3b  vmovaps [rsp+0x20], xmm2
000078d1a57dac41  vmovaps [rsp+0x30], xmm3
000078d1a57dac47  vmovaps [rsp+0x40], xmm4
000078d1a57dac4d  vmovaps [rsp+0x50], xmm5
000078d1a57dac53  vmovaps [rsp+0x60], xmm6
000078d1a57dac59  vmovaps [rsp+0x70], xmm7
000078d1a57dac5f  vmovaps [rsp+0x80], xmm8
000078d1a57dac68  vmovaps [rsp+0x90], xmm9
000078d1a57dac71  vmovaps [rsp+0xA0], xmm10
000078d1a57dac7a  vmovaps [rsp+0xB0], xmm11
000078d1a57dac83  vmovaps [rsp+0xC0], xmm13
000078d1a57dac8c  vmovaps [rsp+0xD0], xmm14
000078d1a57dac95  vmovaps [rsp+0xE0], xmm15
000078d1a57dac9e  sub rsp, 0x30
000078d1a57daca2  movaps [rsp], xmm12
000078d1a57daca7  movaps [rsp+0x10], xmm14
000078d1a57dacad  movaps [rsp+0x20], xmm1
000078d1a57dacb2  lea rdi, [rsp]
000078d1a57dacb6  mov esi, 0x00
000078d1a57dacbb  mov rax, 0x56EA20A26530
000078d1a57dacc5  call rax
000078d1a57dacc7  movaps xmm12, [rsp]
000078d1a57daccc  add rsp, 0x30
000078d1a57dacd0  vmovaps xmm0, [rsp]
000078d1a57dacd5  vmovaps xmm1, [rsp+0x10]
000078d1a57dacdb  vmovaps xmm2, [rsp+0x20]
000078d1a57dace1  vmovaps xmm3, [rsp+0x30]
000078d1a57dace7  vmovaps xmm4, [rsp+0x40]
000078d1a57daced  vmovaps xmm5, [rsp+0x50]
000078d1a57dacf3  vmovaps xmm6, [rsp+0x60]
000078d1a57dacf9  vmovaps xmm7, [rsp+0x70]
000078d1a57dacff  vmovaps xmm8, [rsp+0x80]
000078d1a57dad08  vmovaps xmm9, [rsp+0x90]
000078d1a57dad11  vmovaps xmm10, [rsp+0xA0]
000078d1a57dad1a  vmovaps xmm11, [rsp+0xB0]
000078d1a57dad23  vmovaps xmm13, [rsp+0xC0]
000078d1a57dad2c  vmovaps xmm14, [rsp+0xD0]
000078d1a57dad35  vmovaps xmm15, [rsp+0xE0]
000078d1a57dad3e  add rsp, 0xF0
000078d1a57dad45  pop r11
000078d1a57dad47  pop r10
000078d1a57dad49  pop r9
000078d1a57dad4b  pop r8
000078d1a57dad4d  pop rsi
000078d1a57dad4e  pop rdi
000078d1a57dad4f  pop rdx
000078d1a57dad50  pop rcx
000078d1a57dad51  pop rax
000078d1a57dad52  add rsp, 0x08
000078d1a57dad56  jmp 0x000078D1A57D6549
000078d1a57dad5b  sub rsp, 0x08
000078d1a57dad5f  push rax
000078d1a57dad60  push rcx
000078d1a57dad61  push rdx
000078d1a57dad62  push rdi
000078d1a57dad63  push rsi
000078d1a57dad64  push r8
000078d1a57dad66  push r9
000078d1a57dad68  push r10
000078d1a57dad6a  push r11
000078d1a57dad6c  sub rsp, 0xF0
000078d1a57dad73  vmovaps [rsp], xmm0
000078d1a57dad78  vmovaps [rsp+0x10], xmm1
000078d1a57dad7e  vmovaps [rsp+0x20], xmm2
000078d1a57dad84  vmovaps [rsp+0x30], xmm3
000078d1a57dad8a  vmovaps [rsp+0x40], xmm4
000078d1a57dad90  vmovaps [rsp+0x50], xmm5
000078d1a57dad96  vmovaps [rsp+0x60], xmm6
000078d1a57dad9c  vmovaps [rsp+0x70], xmm7
000078d1a57dada2  vmovaps [rsp+0x80], xmm8
000078d1a57dadab  vmovaps [rsp+0x90], xmm9
000078d1a57dadb4  vmovaps [rsp+0xA0], xmm10
000078d1a57dadbd  vmovaps [rsp+0xB0], xmm11
000078d1a57dadc6  vmovaps [rsp+0xC0], xmm12
000078d1a57dadcf  vmovaps [rsp+0xD0], xmm13
000078d1a57dadd8  vmovaps [rsp+0xE0], xmm15
000078d1a57dade1  sub rsp, 0x30
000078d1a57dade5  movaps [rsp], xmm14
000078d1a57dadea  movaps [rsp+0x10], xmm9
000078d1a57dadf0  movaps [rsp+0x20], xmm1
000078d1a57dadf5  lea rdi, [rsp]
000078d1a57dadf9  mov esi, 0x00
000078d1a57dadfe  mov rax, 0x56EA20A26530
000078d1a57dae08  call rax
000078d1a57dae0a  movaps xmm14, [rsp]
000078d1a57dae0f  add rsp, 0x30
000078d1a57dae13  vmovaps xmm0, [rsp]
000078d1a57dae18  vmovaps xmm1, [rsp+0x10]
000078d1a57dae1e  vmovaps xmm2, [rsp+0x20]
000078d1a57dae24  vmovaps xmm3, [rsp+0x30]
000078d1a57dae2a  vmovaps xmm4, [rsp+0x40]
000078d1a57dae30  vmovaps xmm5, [rsp+0x50]
000078d1a57dae36  vmovaps xmm6, [rsp+0x60]
000078d1a57dae3c  vmovaps xmm7, [rsp+0x70]
000078d1a57dae42  vmovaps xmm8, [rsp+0x80]
000078d1a57dae4b  vmovaps xmm9, [rsp+0x90]
000078d1a57dae54  vmovaps xmm10, [rsp+0xA0]
000078d1a57dae5d  vmovaps xmm11, [rsp+0xB0]
000078d1a57dae66  vmovaps xmm12, [rsp+0xC0]
000078d1a57dae6f  vmovaps xmm13, [rsp+0xD0]
000078d1a57dae78  vmovaps xmm15, [rsp+0xE0]
000078d1a57dae81  add rsp, 0xF0
000078d1a57dae88  pop r11
000078d1a57dae8a  pop r10
000078d1a57dae8c  pop r9
000078d1a57dae8e  pop r8
000078d1a57dae90  pop rsi
000078d1a57dae91  pop rdi
000078d1a57dae92  pop rdx
000078d1a57dae93  pop rcx
000078d1a57dae94  pop rax
000078d1a57dae95  add rsp, 0x08
000078d1a57dae99  jmp 0x000078D1A57D6578
000078d1a57dae9e  sub rsp, 0x08
000078d1a57daea2  push rax
000078d1a57daea3  push rcx
000078d1a57daea4  push rdx
000078d1a57daea5  push rdi
000078d1a57daea6  push rsi
000078d1a57daea7  push r8
000078d1a57daea9  push r9
000078d1a57daeab  push r10
000078d1a57daead  push r11
000078d1a57daeaf  sub rsp, 0xF0
000078d1a57daeb6  vmovaps [rsp], xmm0
000078d1a57daebb  vmovaps [rsp+0x10], xmm2
000078d1a57daec1  vmovaps [rsp+0x20], xmm3
000078d1a57daec7  vmovaps [rsp+0x30], xmm4
000078d1a57daecd  vmovaps [rsp+0x40], xmm5
000078d1a57daed3  vmovaps [rsp+0x50], xmm6
000078d1a57daed9  vmovaps [rsp+0x60], xmm7
000078d1a57daedf  vmovaps [rsp+0x70], xmm8
000078d1a57daee5  vmovaps [rsp+0x80], xmm9
000078d1a57daeee  vmovaps [rsp+0x90], xmm10
000078d1a57daef7  vmovaps [rsp+0xA0], xmm11
000078d1a57daf00  vmovaps [rsp+0xB0], xmm12
000078d1a57daf09  vmovaps [rsp+0xC0], xmm13
000078d1a57daf12  vmovaps [rsp+0xD0], xmm14
000078d1a57daf1b  vmovaps [rsp+0xE0], xmm15
000078d1a57daf24  sub rsp, 0x30
000078d1a57daf28  movaps [rsp], xmm1
000078d1a57daf2c  movaps [rsp+0x10], xmm13
000078d1a57daf32  movaps [rsp+0x20], xmm8
000078d1a57daf38  lea rdi, [rsp]
000078d1a57daf3c  mov esi, 0x00
000078d1a57daf41  mov rax, 0x56EA20A26530
000078d1a57daf4b  call rax
000078d1a57daf4d  movaps xmm1, [rsp]
000078d1a57daf51  add rsp, 0x30
000078d1a57daf55  vmovaps xmm0, [rsp]
000078d1a57daf5a  vmovaps xmm2, [rsp+0x10]
000078d1a57daf60  vmovaps xmm3, [rsp+0x20]
000078d1a57daf66  vmovaps xmm4, [rsp+0x30]
000078d1a57daf6c  vmovaps xmm5, [rsp+0x40]
000078d1a57daf72  vmovaps xmm6, [rsp+0x50]
000078d1a57daf78  vmovaps xmm7, [rsp+0x60]
000078d1a57daf7e  vmovaps xmm8, [rsp+0x70]
000078d1a57daf84  vmovaps xmm9, [rsp+0x80]
000078d1a57daf8d  vmovaps xmm10, [rsp+0x90]
000078d1a57daf96  vmovaps xmm11, [rsp+0xA0]
000078d1a57daf9f  vmovaps xmm12, [rsp+0xB0]
000078d1a57dafa8  vmovaps xmm13, [rsp+0xC0]
000078d1a57dafb1  vmovaps xmm14, [rsp+0xD0]
000078d1a57dafba  vmovaps xmm15, [rsp+0xE0]
000078d1a57dafc3  add rsp, 0xF0
000078d1a57dafca  pop r11
000078d1a57dafcc  pop r10
000078d1a57dafce  pop r9
000078d1a57dafd0  pop r8
000078d1a57dafd2  pop rsi
000078d1a57dafd3  pop rdi
000078d1a57dafd4  pop rdx
000078d1a57dafd5  pop rcx
000078d1a57dafd6  pop rax
000078d1a57dafd7  add rsp, 0x08
000078d1a57dafdb  jmp 0x000078D1A57D659A
000078d1a57dafe0  call 0x000078D1A560C260
000078d1a57dafe5  jmp 0x000078D1A57D65A8
000078d1a57dafea  call 0x000078D1A56DE950
000078d1a57dafef  jmp 0x000078D1A57D65B2
000078d1a57daff4  sub rsp, 0x08
000078d1a57daff8  push rax
000078d1a57daff9  push rcx
000078d1a57daffa  push rdx
000078d1a57daffb  push rdi
000078d1a57daffc  push rsi
000078d1a57daffd  push r8
000078d1a57dafff  push r9
000078d1a57db001  push r10
000078d1a57db003  push r11
000078d1a57db005  sub rsp, 0xF0
000078d1a57db00c  vmovaps [rsp], xmm0
000078d1a57db011  vmovaps [rsp+0x10], xmm1
000078d1a57db017  vmovaps [rsp+0x20], xmm2
000078d1a57db01d  vmovaps [rsp+0x30], xmm3
000078d1a57db023  vmovaps [rsp+0x40], xmm4
000078d1a57db029  vmovaps [rsp+0x50], xmm5
000078d1a57db02f  vmovaps [rsp+0x60], xmm6
000078d1a57db035  vmovaps [rsp+0x70], xmm7
000078d1a57db03b  vmovaps [rsp+0x80], xmm9
000078d1a57db044  vmovaps [rsp+0x90], xmm10
000078d1a57db04d  vmovaps [rsp+0xA0], xmm11
000078d1a57db056  vmovaps [rsp+0xB0], xmm12
000078d1a57db05f  vmovaps [rsp+0xC0], xmm13
000078d1a57db068  vmovaps [rsp+0xD0], xmm14
000078d1a57db071  vmovaps [rsp+0xE0], xmm15
000078d1a57db07a  sub rsp, 0x30
000078d1a57db07e  movaps [rsp], xmm8
000078d1a57db083  movaps [rsp+0x10], xmm15
000078d1a57db089  movaps [rsp+0x20], xmm7
000078d1a57db08e  lea rdi, [rsp]
000078d1a57db092  mov esi, 0x00
000078d1a57db097  mov rax, 0x56EA20A26530
000078d1a57db0a1  call rax
000078d1a57db0a3  movaps xmm8, [rsp]
000078d1a57db0a8  add rsp, 0x30
000078d1a57db0ac  vmovaps xmm0, [rsp]
000078d1a57db0b1  vmovaps xmm1, [rsp+0x10]
000078d1a57db0b7  vmovaps xmm2, [rsp+0x20]
000078d1a57db0bd  vmovaps xmm3, [rsp+0x30]
000078d1a57db0c3  vmovaps xmm4, [rsp+0x40]
000078d1a57db0c9  vmovaps xmm5, [rsp+0x50]
000078d1a57db0cf  vmovaps xmm6, [rsp+0x60]
000078d1a57db0d5  vmovaps xmm7, [rsp+0x70]
000078d1a57db0db  vmovaps xmm9, [rsp+0x80]
000078d1a57db0e4  vmovaps xmm10, [rsp+0x90]
000078d1a57db0ed  vmovaps xmm11, [rsp+0xA0]
000078d1a57db0f6  vmovaps xmm12, [rsp+0xB0]
000078d1a57db0ff  vmovaps xmm13, [rsp+0xC0]
000078d1a57db108  vmovaps xmm14, [rsp+0xD0]
000078d1a57db111  vmovaps xmm15, [rsp+0xE0]
000078d1a57db11a  add rsp, 0xF0
000078d1a57db121  pop r11
000078d1a57db123  pop r10
000078d1a57db125  pop r9
000078d1a57db127  pop r8
000078d1a57db129  pop rsi
000078d1a57db12a  pop rdi
000078d1a57db12b  pop rdx
000078d1a57db12c  pop rcx
000078d1a57db12d  pop rax
000078d1a57db12e  add rsp, 0x08
000078d1a57db132  jmp 0x000078D1A57D65D4
000078d1a57db137  sub rsp, 0x08
000078d1a57db13b  push rax
000078d1a57db13c  push rcx
000078d1a57db13d  push rdx
000078d1a57db13e  push rdi
000078d1a57db13f  push rsi
000078d1a57db140  push r8
000078d1a57db142  push r9
000078d1a57db144  push r10
000078d1a57db146  push r11
000078d1a57db148  sub rsp, 0xF0
000078d1a57db14f  vmovaps [rsp], xmm0
000078d1a57db154  vmovaps [rsp+0x10], xmm1
000078d1a57db15a  vmovaps [rsp+0x20], xmm2
000078d1a57db160  vmovaps [rsp+0x30], xmm3
000078d1a57db166  vmovaps [rsp+0x40], xmm4
000078d1a57db16c  vmovaps [rsp+0x50], xmm5
000078d1a57db172  vmovaps [rsp+0x60], xmm6
000078d1a57db178  vmovaps [rsp+0x70], xmm8
000078d1a57db17e  vmovaps [rsp+0x80], xmm9
000078d1a57db187  vmovaps [rsp+0x90], xmm10
000078d1a57db190  vmovaps [rsp+0xA0], xmm11
000078d1a57db199  vmovaps [rsp+0xB0], xmm12
000078d1a57db1a2  vmovaps [rsp+0xC0], xmm13
000078d1a57db1ab  vmovaps [rsp+0xD0], xmm14
000078d1a57db1b4  vmovaps [rsp+0xE0], xmm15
000078d1a57db1bd  sub rsp, 0x30
000078d1a57db1c1  movaps [rsp], xmm7
000078d1a57db1c5  movaps [rsp+0x10], xmm9
000078d1a57db1cb  movaps [rsp+0x20], xmm15
000078d1a57db1d1  lea rdi, [rsp]
000078d1a57db1d5  mov esi, 0x00
000078d1a57db1da  mov rax, 0x56EA20A26530
000078d1a57db1e4  call rax
000078d1a57db1e6  movaps xmm7, [rsp]
000078d1a57db1ea  add rsp, 0x30
000078d1a57db1ee  vmovaps xmm0, [rsp]
000078d1a57db1f3  vmovaps xmm1, [rsp+0x10]
000078d1a57db1f9  vmovaps xmm2, [rsp+0x20]
000078d1a57db1ff  vmovaps xmm3, [rsp+0x30]
000078d1a57db205  vmovaps xmm4, [rsp+0x40]
000078d1a57db20b  vmovaps xmm5, [rsp+0x50]
000078d1a57db211  vmovaps xmm6, [rsp+0x60]
000078d1a57db217  vmovaps xmm8, [rsp+0x70]
000078d1a57db21d  vmovaps xmm9, [rsp+0x80]
000078d1a57db226  vmovaps xmm10, [rsp+0x90]
000078d1a57db22f  vmovaps xmm11, [rsp+0xA0]
000078d1a57db238  vmovaps xmm12, [rsp+0xB0]
000078d1a57db241  vmovaps xmm13, [rsp+0xC0]
000078d1a57db24a  vmovaps xmm14, [rsp+0xD0]
000078d1a57db253  vmovaps xmm15, [rsp+0xE0]
000078d1a57db25c  add rsp, 0xF0
000078d1a57db263  pop r11
000078d1a57db265  pop r10
000078d1a57db267  pop r9
000078d1a57db269  pop r8
000078d1a57db26b  pop rsi
000078d1a57db26c  pop rdi
000078d1a57db26d  pop rdx
000078d1a57db26e  pop rcx
000078d1a57db26f  pop rax
000078d1a57db270  add rsp, 0x08
000078d1a57db274  jmp 0x000078D1A57D6601
000078d1a57db279  sub rsp, 0x08
000078d1a57db27d  push rax
000078d1a57db27e  push rcx
000078d1a57db27f  push rdx
000078d1a57db280  push rdi
000078d1a57db281  push rsi
000078d1a57db282  push r8
000078d1a57db284  push r9
000078d1a57db286  push r10
000078d1a57db288  push r11
000078d1a57db28a  sub rsp, 0xF0
000078d1a57db291  vmovaps [rsp], xmm0
000078d1a57db296  vmovaps [rsp+0x10], xmm1
000078d1a57db29c  vmovaps [rsp+0x20], xmm2
000078d1a57db2a2  vmovaps [rsp+0x30], xmm3
000078d1a57db2a8  vmovaps [rsp+0x40], xmm4
000078d1a57db2ae  vmovaps [rsp+0x50], xmm5
000078d1a57db2b4  vmovaps [rsp+0x60], xmm6
000078d1a57db2ba  vmovaps [rsp+0x70], xmm7
000078d1a57db2c0  vmovaps [rsp+0x80], xmm8
000078d1a57db2c9  vmovaps [rsp+0x90], xmm10
000078d1a57db2d2  vmovaps [rsp+0xA0], xmm11
000078d1a57db2db  vmovaps [rsp+0xB0], xmm12
000078d1a57db2e4  vmovaps [rsp+0xC0], xmm13
000078d1a57db2ed  vmovaps [rsp+0xD0], xmm14
000078d1a57db2f6  vmovaps [rsp+0xE0], xmm15
000078d1a57db2ff  sub rsp, 0x30
000078d1a57db303  movaps [rsp], xmm9
000078d1a57db308  movaps [rsp+0x10], xmm13
000078d1a57db30e  movaps [rsp+0x20], xmm15
000078d1a57db314  lea rdi, [rsp]
000078d1a57db318  mov esi, 0x00
000078d1a57db31d  mov rax, 0x56EA20A26530
000078d1a57db327  call rax
000078d1a57db329  movaps xmm9, [rsp]
000078d1a57db32e  add rsp, 0x30
000078d1a57db332  vmovaps xmm0, [rsp]
000078d1a57db337  vmovaps xmm1, [rsp+0x10]
000078d1a57db33d  vmovaps xmm2, [rsp+0x20]
000078d1a57db343  vmovaps xmm3, [rsp+0x30]
000078d1a57db349  vmovaps xmm4, [rsp+0x40]
000078d1a57db34f  vmovaps xmm5, [rsp+0x50]
000078d1a57db355  vmovaps xmm6, [rsp+0x60]
000078d1a57db35b  vmovaps xmm7, [rsp+0x70]
000078d1a57db361  vmovaps xmm8, [rsp+0x80]
000078d1a57db36a  vmovaps xmm10, [rsp+0x90]
000078d1a57db373  vmovaps xmm11, [rsp+0xA0]
000078d1a57db37c  vmovaps xmm12, [rsp+0xB0]
000078d1a57db385  vmovaps xmm13, [rsp+0xC0]
000078d1a57db38e  vmovaps xmm14, [rsp+0xD0]
000078d1a57db397  vmovaps xmm15, [rsp+0xE0]
000078d1a57db3a0  add rsp, 0xF0
000078d1a57db3a7  pop r11
000078d1a57db3a9  pop r10
000078d1a57db3ab  pop r9
000078d1a57db3ad  pop r8
000078d1a57db3af  pop rsi
000078d1a57db3b0  pop rdi
000078d1a57db3b1  pop rdx
000078d1a57db3b2  pop rcx
000078d1a57db3b3  pop rax
000078d1a57db3b4  add rsp, 0x08
000078d1a57db3b8  jmp 0x000078D1A57D662F
000078d1a57db3bd  sub rsp, 0x08
000078d1a57db3c1  push rax
000078d1a57db3c2  push rcx
000078d1a57db3c3  push rdx
000078d1a57db3c4  push rdi
000078d1a57db3c5  push rsi
000078d1a57db3c6  push r8
000078d1a57db3c8  push r9
000078d1a57db3ca  push r10
000078d1a57db3cc  push r11
000078d1a57db3ce  sub rsp, 0xF0
000078d1a57db3d5  vmovaps [rsp], xmm0
000078d1a57db3da  vmovaps [rsp+0x10], xmm1
000078d1a57db3e0  vmovaps [rsp+0x20], xmm2
000078d1a57db3e6  vmovaps [rsp+0x30], xmm3
000078d1a57db3ec  vmovaps [rsp+0x40], xmm4
000078d1a57db3f2  vmovaps [rsp+0x50], xmm5
000078d1a57db3f8  vmovaps [rsp+0x60], xmm6
000078d1a57db3fe  vmovaps [rsp+0x70], xmm7
000078d1a57db404  vmovaps [rsp+0x80], xmm8
000078d1a57db40d  vmovaps [rsp+0x90], xmm9
000078d1a57db416  vmovaps [rsp+0xA0], xmm10
000078d1a57db41f  vmovaps [rsp+0xB0], xmm11
000078d1a57db428  vmovaps [rsp+0xC0], xmm12
000078d1a57db431  vmovaps [rsp+0xD0], xmm13
000078d1a57db43a  vmovaps [rsp+0xE0], xmm14
000078d1a57db443  sub rsp, 0x30
000078d1a57db447  movaps [rsp], xmm15
000078d1a57db44c  movaps [rsp+0x10], xmm11
000078d1a57db452  movaps [rsp+0x20], xmm12
000078d1a57db458  lea rdi, [rsp]
000078d1a57db45c  mov esi, 0x00
000078d1a57db461  mov rax, 0x56EA20A26530
000078d1a57db46b  call rax
000078d1a57db46d  movaps xmm15, [rsp]
000078d1a57db472  add rsp, 0x30
000078d1a57db476  vmovaps xmm0, [rsp]
000078d1a57db47b  vmovaps xmm1, [rsp+0x10]
000078d1a57db481  vmovaps xmm2, [rsp+0x20]
000078d1a57db487  vmovaps xmm3, [rsp+0x30]
000078d1a57db48d  vmovaps xmm4, [rsp+0x40]
000078d1a57db493  vmovaps xmm5, [rsp+0x50]
000078d1a57db499  vmovaps xmm6, [rsp+0x60]
000078d1a57db49f  vmovaps xmm7, [rsp+0x70]
000078d1a57db4a5  vmovaps xmm8, [rsp+0x80]
000078d1a57db4ae  vmovaps xmm9, [rsp+0x90]
000078d1a57db4b7  vmovaps xmm10, [rsp+0xA0]
000078d1a57db4c0  vmovaps xmm11, [rsp+0xB0]
000078d1a57db4c9  vmovaps xmm12, [rsp+0xC0]
000078d1a57db4d2  vmovaps xmm13, [rsp+0xD0]
000078d1a57db4db  vmovaps xmm14, [rsp+0xE0]
000078d1a57db4e4  add rsp, 0xF0
000078d1a57db4eb  pop r11
000078d1a57db4ed  pop r10
000078d1a57db4ef  pop r9
000078d1a57db4f1  pop r8
000078d1a57db4f3  pop rsi
000078d1a57db4f4  pop rdi
000078d1a57db4f5  pop rdx
000078d1a57db4f6  pop rcx
000078d1a57db4f7  pop rax
000078d1a57db4f8  add rsp, 0x08
000078d1a57db4fc  jmp 0x000078D1A57D664A
000078d1a57db501  sub rsp, 0x08
000078d1a57db505  push rax
000078d1a57db506  push rcx
000078d1a57db507  push rdx
000078d1a57db508  push rdi
000078d1a57db509  push rsi
000078d1a57db50a  push r8
000078d1a57db50c  push r9
000078d1a57db50e  push r10
000078d1a57db510  push r11
000078d1a57db512  sub rsp, 0xF0
000078d1a57db519  vmovaps [rsp], xmm0
000078d1a57db51e  vmovaps [rsp+0x10], xmm1
000078d1a57db524  vmovaps [rsp+0x20], xmm2
000078d1a57db52a  vmovaps [rsp+0x30], xmm3
000078d1a57db530  vmovaps [rsp+0x40], xmm4
000078d1a57db536  vmovaps [rsp+0x50], xmm5
000078d1a57db53c  vmovaps [rsp+0x60], xmm6
000078d1a57db542  vmovaps [rsp+0x70], xmm7
000078d1a57db548  vmovaps [rsp+0x80], xmm8
000078d1a57db551  vmovaps [rsp+0x90], xmm9
000078d1a57db55a  vmovaps [rsp+0xA0], xmm10
000078d1a57db563  vmovaps [rsp+0xB0], xmm11
000078d1a57db56c  vmovaps [rsp+0xC0], xmm12
000078d1a57db575  vmovaps [rsp+0xD0], xmm14
000078d1a57db57e  vmovaps [rsp+0xE0], xmm15
000078d1a57db587  sub rsp, 0x30
000078d1a57db58b  movaps [rsp], xmm13
000078d1a57db590  movaps [rsp+0x10], xmm10
000078d1a57db596  movaps [rsp+0x20], xmm14
000078d1a57db59c  lea rdi, [rsp]
000078d1a57db5a0  mov esi, 0x00
000078d1a57db5a5  mov rax, 0x56EA20A26530
000078d1a57db5af  call rax
000078d1a57db5b1  movaps xmm13, [rsp]
000078d1a57db5b6  add rsp, 0x30
000078d1a57db5ba  vmovaps xmm0, [rsp]
000078d1a57db5bf  vmovaps xmm1, [rsp+0x10]
000078d1a57db5c5  vmovaps xmm2, [rsp+0x20]
000078d1a57db5cb  vmovaps xmm3, [rsp+0x30]
000078d1a57db5d1  vmovaps xmm4, [rsp+0x40]
000078d1a57db5d7  vmovaps xmm5, [rsp+0x50]
000078d1a57db5dd  vmovaps xmm6, [rsp+0x60]
000078d1a57db5e3  vmovaps xmm7, [rsp+0x70]
000078d1a57db5e9  vmovaps xmm8, [rsp+0x80]
000078d1a57db5f2  vmovaps xmm9, [rsp+0x90]
000078d1a57db5fb  vmovaps xmm10, [rsp+0xA0]
000078d1a57db604  vmovaps xmm11, [rsp+0xB0]
000078d1a57db60d  vmovaps xmm12, [rsp+0xC0]
000078d1a57db616  vmovaps xmm14, [rsp+0xD0]
000078d1a57db61f  vmovaps xmm15, [rsp+0xE0]
000078d1a57db628  add rsp, 0xF0
000078d1a57db62f  pop r11
000078d1a57db631  pop r10
000078d1a57db633  pop r9
000078d1a57db635  pop r8
000078d1a57db637  pop rsi
000078d1a57db638  pop rdi
000078d1a57db639  pop rdx
000078d1a57db63a  pop rcx
000078d1a57db63b  pop rax
000078d1a57db63c  add rsp, 0x08
000078d1a57db640  jmp 0x000078D1A57D666D
000078d1a57db645  sub rsp, 0x08
000078d1a57db649  push rax
000078d1a57db64a  push rcx
000078d1a57db64b  push rdx
000078d1a57db64c  push rdi
000078d1a57db64d  push rsi
000078d1a57db64e  push r8
000078d1a57db650  push r9
000078d1a57db652  push r10
000078d1a57db654  push r11
000078d1a57db656  sub rsp, 0xF0
000078d1a57db65d  vmovaps [rsp], xmm0
000078d1a57db662  vmovaps [rsp+0x10], xmm1
000078d1a57db668  vmovaps [rsp+0x20], xmm2
000078d1a57db66e  vmovaps [rsp+0x30], xmm3
000078d1a57db674  vmovaps [rsp+0x40], xmm4
000078d1a57db67a  vmovaps [rsp+0x50], xmm5
000078d1a57db680  vmovaps [rsp+0x60], xmm6
000078d1a57db686  vmovaps [rsp+0x70], xmm7
000078d1a57db68c  vmovaps [rsp+0x80], xmm8
000078d1a57db695  vmovaps [rsp+0x90], xmm9
000078d1a57db69e  vmovaps [rsp+0xA0], xmm10
000078d1a57db6a7  vmovaps [rsp+0xB0], xmm11
000078d1a57db6b0  vmovaps [rsp+0xC0], xmm12
000078d1a57db6b9  vmovaps [rsp+0xD0], xmm13
000078d1a57db6c2  vmovaps [rsp+0xE0], xmm15
000078d1a57db6cb  sub rsp, 0x30
000078d1a57db6cf  movaps [rsp], xmm14
000078d1a57db6d4  movaps [rsp+0x10], xmm1
000078d1a57db6d9  movaps [rsp+0x20], xmm7
000078d1a57db6de  lea rdi, [rsp]
000078d1a57db6e2  mov esi, 0x00
000078d1a57db6e7  mov rax, 0x56EA20A26530
000078d1a57db6f1  call rax
000078d1a57db6f3  movaps xmm14, [rsp]
000078d1a57db6f8  add rsp, 0x30
000078d1a57db6fc  vmovaps xmm0, [rsp]
000078d1a57db701  vmovaps xmm1, [rsp+0x10]
000078d1a57db707  vmovaps xmm2, [rsp+0x20]
000078d1a57db70d  vmovaps xmm3, [rsp+0x30]
000078d1a57db713  vmovaps xmm4, [rsp+0x40]
000078d1a57db719  vmovaps xmm5, [rsp+0x50]
000078d1a57db71f  vmovaps xmm6, [rsp+0x60]
000078d1a57db725  vmovaps xmm7, [rsp+0x70]
000078d1a57db72b  vmovaps xmm8, [rsp+0x80]
000078d1a57db734  vmovaps xmm9, [rsp+0x90]
000078d1a57db73d  vmovaps xmm10, [rsp+0xA0]
000078d1a57db746  vmovaps xmm11, [rsp+0xB0]
000078d1a57db74f  vmovaps xmm12, [rsp+0xC0]
000078d1a57db758  vmovaps xmm13, [rsp+0xD0]
000078d1a57db761  vmovaps xmm15, [rsp+0xE0]
000078d1a57db76a  add rsp, 0xF0
000078d1a57db771  pop r11
000078d1a57db773  pop r10
000078d1a57db775  pop r9
000078d1a57db777  pop r8
000078d1a57db779  pop rsi
000078d1a57db77a  pop rdi
000078d1a57db77b  pop rdx
000078d1a57db77c  pop rcx
000078d1a57db77d  pop rax
000078d1a57db77e  add rsp, 0x08
000078d1a57db782  jmp 0x000078D1A57D6690
000078d1a57db787  sub rsp, 0x08
000078d1a57db78b  push rax
000078d1a57db78c  push rcx
000078d1a57db78d  push rdx
000078d1a57db78e  push rdi
000078d1a57db78f  push rsi
000078d1a57db790  push r8
000078d1a57db792  push r9
000078d1a57db794  push r10
000078d1a57db796  push r11
000078d1a57db798  sub rsp, 0xF0
000078d1a57db79f  vmovaps [rsp], xmm0
000078d1a57db7a4  vmovaps [rsp+0x10], xmm2
000078d1a57db7aa  vmovaps [rsp+0x20], xmm3
000078d1a57db7b0  vmovaps [rsp+0x30], xmm4
000078d1a57db7b6  vmovaps [rsp+0x40], xmm5
000078d1a57db7bc  vmovaps [rsp+0x50], xmm6
000078d1a57db7c2  vmovaps [rsp+0x60], xmm7
000078d1a57db7c8  vmovaps [rsp+0x70], xmm8
000078d1a57db7ce  vmovaps [rsp+0x80], xmm9
000078d1a57db7d7  vmovaps [rsp+0x90], xmm10
000078d1a57db7e0  vmovaps [rsp+0xA0], xmm11
000078d1a57db7e9  vmovaps [rsp+0xB0], xmm12
000078d1a57db7f2  vmovaps [rsp+0xC0], xmm13
000078d1a57db7fb  vmovaps [rsp+0xD0], xmm14
000078d1a57db804  vmovaps [rsp+0xE0], xmm15
000078d1a57db80d  sub rsp, 0x30
000078d1a57db811  movaps [rsp], xmm1
000078d1a57db815  movaps [rsp+0x10], xmm8
000078d1a57db81b  movaps [rsp+0x20], xmm9
000078d1a57db821  lea rdi, [rsp]
000078d1a57db825  mov esi, 0x00
000078d1a57db82a  mov rax, 0x56EA20A26530
000078d1a57db834  call rax
000078d1a57db836  movaps xmm1, [rsp]
000078d1a57db83a  add rsp, 0x30
000078d1a57db83e  vmovaps xmm0, [rsp]
000078d1a57db843  vmovaps xmm2, [rsp+0x10]
000078d1a57db849  vmovaps xmm3, [rsp+0x20]
000078d1a57db84f  vmovaps xmm4, [rsp+0x30]
000078d1a57db855  vmovaps xmm5, [rsp+0x40]
000078d1a57db85b  vmovaps xmm6, [rsp+0x50]
000078d1a57db861  vmovaps xmm7, [rsp+0x60]
000078d1a57db867  vmovaps xmm8, [rsp+0x70]
000078d1a57db86d  vmovaps xmm9, [rsp+0x80]
000078d1a57db876  vmovaps xmm10, [rsp+0x90]
000078d1a57db87f  vmovaps xmm11, [rsp+0xA0]
000078d1a57db888  vmovaps xmm12, [rsp+0xB0]
000078d1a57db891  vmovaps xmm13, [rsp+0xC0]
000078d1a57db89a  vmovaps xmm14, [rsp+0xD0]
000078d1a57db8a3  vmovaps xmm15, [rsp+0xE0]
000078d1a57db8ac  add rsp, 0xF0
000078d1a57db8b3  pop r11
000078d1a57db8b5  pop r10
000078d1a57db8b7  pop r9
000078d1a57db8b9  pop r8
000078d1a57db8bb  pop rsi
000078d1a57db8bc  pop rdi
000078d1a57db8bd  pop rdx
000078d1a57db8be  pop rcx
000078d1a57db8bf  pop rax
000078d1a57db8c0  add rsp, 0x08
000078d1a57db8c4  jmp 0x000078D1A57D66B2
000078d1a57db8c9  call 0x000078D1A56B3E40
000078d1a57db8ce  jmp 0x000078D1A57D66C0
000078d1a57db8d3  call 0x000078D1A560C380
000078d1a57db8d8  jmp 0x000078D1A57D66CA
000078d1a57db8dd  call 0x000078D1A560D600
000078d1a57db8e2  jmp 0x000078D1A57D66D4
000078d1a57db8e7  call 0x000078D1A55FF540
000078d1a57db8ec  jmp 0x000078D1A57D66DE
000078d1a57db8f1  int3
000078d1a57db8f2  nop [rax+rax*1], ax
000078d1a57db8fb  nop [rax+rax*1], eax
000078d1a57db900  mov eax, [r15+0x48]
000078d1a57db904  lea r14d, [eax+0x01]
000078d1a57db909  mov [rsp+0x10], r14d
000078d1a57db90e  mov r14d, r14d
000078d1a57db911  mov [r15+0x48], r14
000078d1a57db915  xor eax, eax
000078d1a57db917  mov r14d, [rsp+0x10]
000078d1a57db91c  cmp r14d, 0x1F4
000078d1a57db923  cmc
000078d1a57db924  lahf
000078d1a57db925  seto al
000078d1a57db928  mov [r15+0x108], eax
000078d1a57db92f  mov eax, [r15+0x108]
000078d1a57db936  sahf
000078d1a57db937  jnz 0x000078D1A57DB969
000078d1a57db939  cmp dword ptr [r15+0x318], 0x00
000078d1a57db941  jz 0x000078D1A57E1AB0
000078d1a57db947  nop [rax+rax*1], ax
000078d1a57db950  nop [rax+rax*1], eax
000078d1a57db958  mov eax, 0x410450
000078d1a57db95d  mov [r15+0x100], rax
000078d1a57db964  jmp 0x000078D1A55FE110
000078d1a57db969  cmp dword ptr [r15+0x318], 0x00
000078d1a57db971  jz 0x000078D1A57DB9A0
000078d1a57db977  nop [rax+rax*1], ax
000078d1a57db980  nop [rax+rax*1], eax
000078d1a57db988  mov eax, 0x410274
000078d1a57db98d  mov [r15+0x100], rax
000078d1a57db994  jmp 0x000078D1A55FE110
000078d1a57db999  int3
000078d1a57db99a  int3
000078d1a57db99b  nop [rax+rax*1], eax
000078d1a57db9a0  mov rax, [r15+0x40]
000078d1a57db9a4  movaps xmm1, [r15+0x1D0]
000078d1a57db9ac  vmovaps [rsp+0x10], xmm1
000078d1a57db9b2  vmovaps xmm15, [rsp+0x10]
000078d1a57db9b8  por xmm1, xmm15
000078d1a57db9bd  movaps xmm14, [r15+0x1A0]
000078d1a57db9c5  vmovaps [rsp+0x10], xmm14
000078d1a57db9cb  vmovaps xmm13, [rsp+0x10]
000078d1a57db9d1  por xmm14, xmm13
000078d1a57db9d6  lea r14, [rax+0x30]
000078d1a57db9da  mov r12, [r13+r14*1]
000078d1a57db9df  lea r14, [rax+0x38]
000078d1a57db9e3  mov r11, [r13+r14*1]
000078d1a57db9e8  movq xmm13, r12
000078d1a57db9ed  movq xmm12, r11
000078d1a57db9f2  movq xmm13, xmm13
000078d1a57db9f7  vmovaps [rsp+0x10], xmm13
000078d1a57db9fd  movq xmm13, xmm13
000078d1a57dba02  movaps [r15+0x130], xmm13
000078d1a57dba0a  movq xmm12, xmm12
000078d1a57dba0f  vmovaps [rsp+0x20], xmm12
000078d1a57dba15  movq xmm12, xmm12
000078d1a57dba1a  movaps [r15+0x280], xmm12
000078d1a57dba22  movaps xmm13, [r15+0x270]
000078d1a57dba2a  vmovaps [rsp+0x30], xmm13
000078d1a57dba30  vmovaps xmm12, [rsp+0x30]
000078d1a57dba36  por xmm13, xmm12
000078d1a57dba3b  lea r14, [rax+0x20]
000078d1a57dba3f  mov r12, [r13+r14*1]
000078d1a57dba44  lea r14, [rax+0x28]
000078d1a57dba48  mov r11, [r13+r14*1]
000078d1a57dba4d  movq xmm12, r12
000078d1a57dba52  movq xmm11, r11
000078d1a57dba57  movq xmm12, xmm12
000078d1a57dba5c  vmovaps [rsp+0x30], xmm12
000078d1a57dba62  movq xmm12, xmm12
000078d1a57dba67  movaps [r15+0x150], xmm12
000078d1a57dba6f  movq xmm11, xmm11
000078d1a57dba74  vmovaps [rsp+0x40], xmm11
000078d1a57dba7a  movq xmm11, xmm11
000078d1a57dba7f  movaps [r15+0x140], xmm11
000078d1a57dba87  lea r14, [rax+0x10]
000078d1a57dba8b  mov r12, [r13+r14*1]
000078d1a57dba90  lea r14, [rax+0x18]
000078d1a57dba94  mov r11, [r13+r14*1]
000078d1a57dba99  movq xmm12, r12
000078d1a57dba9e  movq xmm11, r11
000078d1a57dbaa3  movq xmm12, xmm12
000078d1a57dbaa8  vmovaps [rsp+0x50], xmm12
000078d1a57dbaae  movq xmm12, xmm12
000078d1a57dbab3  movaps [r15+0x170], xmm12
000078d1a57dbabb  movq xmm11, xmm11
000078d1a57dbac0  vmovaps [rsp+0x60], xmm11
000078d1a57dbac6  movq xmm11, xmm11
000078d1a57dbacb  movaps [r15+0x160], xmm11
000078d1a57dbad3  mov r14, [r13+rax*1]
000078d1a57dbad8  vmovq xmm12, r14
000078d1a57dbadd  vpbroadcastq xmm12, xmm12
000078d1a57dbae2  lea r14, [rax+0x08]
000078d1a57dbae6  mov rax, [r13+r14*1]
000078d1a57dbaeb  movq xmm11, rax
000078d1a57dbaf0  movaps [r15+0x230], xmm11
000078d1a57dbaf8  mov rax, [r15+0xF8]
000078d1a57dbaff  lea r14, [rax+0x50]
000078d1a57dbb03  movups xmm11, [r13+r14*1]
000078d1a57dbb09  lea r14, [rax+0x60]
000078d1a57dbb0d  movups xmm10, [r13+r14*1]
000078d1a57dbb13  lea r14, [rax+0x30]
000078d1a57dbb17  movups xmm9, [r13+r14*1]
000078d1a57dbb1d  mov r14, [r15+0x50]
000078d1a57dbb21  mov [r15+0x60], r14
000078d1a57dbb25  mov qword ptr [r15+0x58], 0x40
000078d1a57dbb2d  movaps xmm8, xmm12
000078d1a57dbb31  mulpd xmm8, xmm15
000078d1a57dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000078d1a57dbb3c  ptest xmm7, xmm7
000078d1a57dbb41  jnz 0x000078D1A57DC96A
000078d1a57dbb47  movq xmm15, qword ptr [r15+0x230]
000078d1a57dbb50  vmovaps [rsp+0x70], xmm15
000078d1a57dbb56  vpermilpd xmm15, xmm15, 0x00
000078d1a57dbb5c  movaps xmm7, xmm9
000078d1a57dbb60  mulpd xmm7, xmm15
000078d1a57dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000078d1a57dbb6a  ptest xmm6, xmm6
000078d1a57dbb6f  jnz 0x000078D1A57DCAAE
000078d1a57dbb75  vxorps xmm15, xmm15, xmm15
000078d1a57dbb7a  vpbroadcastq xmm15, xmm15
000078d1a57dbb7f  movaps xmm9, xmm12
000078d1a57dbb83  mulpd xmm9, xmm10
000078d1a57dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000078d1a57dbb8e  ptest xmm6, xmm6
000078d1a57dbb93  jnz 0x000078D1A57DCBF0
000078d1a57dbb99  movaps xmm10, xmm12
000078d1a57dbb9d  mulpd xmm10, xmm11
000078d1a57dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000078d1a57dbba8  ptest xmm6, xmm6
000078d1a57dbbad  jnz 0x000078D1A57DCD34
000078d1a57dbbb3  movaps xmm11, [r15+0x1F0]
000078d1a57dbbbb  movaps xmm6, xmm12
000078d1a57dbbbf  mulpd xmm6, xmm11
000078d1a57dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000078d1a57dbbc9  ptest xmm5, xmm5
000078d1a57dbbce  jnz 0x000078D1A57DCE78
000078d1a57dbbd4  movaps xmm12, [r15+0x2A0]
000078d1a57dbbdc  vmovaps [rsp+0x80], xmm12
000078d1a57dbbe5  vmovaps xmm11, [rsp+0x80]
000078d1a57dbbee  por xmm12, xmm11
000078d1a57dbbf3  movaps xmm11, [r15+0x250]
000078d1a57dbbfb  vmovaps [rsp+0x80], xmm11
000078d1a57dbc04  vmovaps xmm5, [rsp+0x80]
000078d1a57dbc0d  por xmm11, xmm5
000078d1a57dbc12  vmovaps xmm4, [rsp+0x70]
000078d1a57dbc18  vpermilpd xmm4, xmm4, 0x00
000078d1a57dbc1e  movaps xmm3, xmm5
000078d1a57dbc21  mulpd xmm3, xmm4
000078d1a57dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000078d1a57dbc2a  ptest xmm2, xmm2
000078d1a57dbc2f  jnz 0x000078D1A57DCFBA
000078d1a57dbc35  mov [rsp+0x80], rax
000078d1a57dbc3d  xor eax, eax
000078d1a57dbc3f  mov r12d, 0x40
000078d1a57dbc45  mov r11d, 0x200
000078d1a57dbc4b  cmp r12, r11
000078d1a57dbc4e  cmc
000078d1a57dbc4f  lahf
000078d1a57dbc50  seto al
000078d1a57dbc53  mov [r15+0x108], eax
000078d1a57dbc5a  movaps xmm5, xmm8
000078d1a57dbc5e  addpd xmm5, xmm15
000078d1a57dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000078d1a57dbc68  ptest xmm4, xmm4
000078d1a57dbc6d  jnz 0x000078D1A57DD0FA
000078d1a57dbc73  movaps xmm8, [r15+0x1B0]
000078d1a57dbc7b  movaps xmm4, xmm9
000078d1a57dbc7f  addpd xmm4, xmm8
000078d1a57dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000078d1a57dbc89  ptest xmm2, xmm2
000078d1a57dbc8e  jnz 0x000078D1A57DD23C
000078d1a57dbc94  movaps xmm9, xmm10
000078d1a57dbc98  addpd xmm9, xmm8
000078d1a57dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000078d1a57dbca3  ptest xmm2, xmm2
000078d1a57dbca8  jnz 0x000078D1A57DD37E
000078d1a57dbcae  movaps xmm10, [r15+0x2F0]
000078d1a57dbcb6  vmovaps [rsp+0x90], xmm10
000078d1a57dbcbf  vmovaps xmm8, [rsp+0x90]
000078d1a57dbcc8  por xmm10, xmm8
000078d1a57dbccd  movaps xmm8, [r15+0x2E0]
000078d1a57dbcd5  vmovaps [rsp+0x90], xmm8
000078d1a57dbcde  vmovaps xmm2, [rsp+0x90]
000078d1a57dbce7  por xmm8, xmm2
000078d1a57dbcec  movaps xmm2, [r15+0x2D0]
000078d1a57dbcf4  vmovaps [rsp+0x90], xmm2
000078d1a57dbcfd  vmovaps [rsp+0xA0], xmm1
000078d1a57dbd06  vmovaps xmm1, [rsp+0x90]
000078d1a57dbd0f  por xmm2, xmm1
000078d1a57dbd13  movaps xmm1, [r15+0x200]
000078d1a57dbd1b  vmovaps [rsp+0x90], xmm1
000078d1a57dbd24  vmovaps [rsp+0xB0], xmm15
000078d1a57dbd2d  vmovaps xmm15, [rsp+0x90]
000078d1a57dbd36  por xmm1, xmm15
000078d1a57dbd3b  movaps xmm15, [r15+0x1C0]
000078d1a57dbd43  vmovaps [rsp+0x90], xmm15
000078d1a57dbd4c  vmovaps [rsp+0xC0], xmm1
000078d1a57dbd55  vmovaps xmm1, [rsp+0x90]
000078d1a57dbd5e  por xmm15, xmm1
000078d1a57dbd63  movaps xmm1, [r15+0x190]
000078d1a57dbd6b  vmovaps [rsp+0x90], xmm1
000078d1a57dbd74  vmovaps [rsp+0xD0], xmm15
000078d1a57dbd7d  vmovaps xmm15, [rsp+0x90]
000078d1a57dbd86  por xmm1, xmm15
000078d1a57dbd8b  movaps xmm15, [r15+0x300]
000078d1a57dbd93  vmovaps [rsp+0x90], xmm15
000078d1a57dbd9c  vmovaps [rsp+0xE0], xmm1
000078d1a57dbda5  vmovaps xmm1, [rsp+0x90]
000078d1a57dbdae  por xmm15, xmm1
000078d1a57dbdb3  mov rax, [rsp+0x80]
000078d1a57dbdbb  lea r12, [rax+0xA0]
000078d1a57dbdc2  movups xmm1, [r13+r12*1]
000078d1a57dbdc8  lea r12, [rax+0xB0]
000078d1a57dbdcf  vmovaps [rsp+0x80], xmm1
000078d1a57dbdd8  movups xmm1, [r13+r12*1]
000078d1a57dbdde  vmovaps [rsp+0x90], xmm1
000078d1a57dbde7  vmovaps [rsp+0xF0], xmm15
000078d1a57dbdf0  vmovaps xmm15, [rsp+0xB0]
000078d1a57dbdf9  vmovaps [rsp+0xB0], xmm14
000078d1a57dbe02  movaps xmm1, xmm6
000078d1a57dbe05  addpd xmm1, xmm15
000078d1a57dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000078d1a57dbe0f  ptest xmm14, xmm14
000078d1a57dbe15  jnz 0x000078D1A57DD4D6
000078d1a57dbe1b  lea r12, [rax+0xF0]
000078d1a57dbe22  movups xmm15, [r13+r12*1]
000078d1a57dbe28  movaps xmm14, xmm4
000078d1a57dbe2c  addpd xmm14, xmm3
000078d1a57dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000078d1a57dbe37  ptest xmm6, xmm6
000078d1a57dbe3c  jnz 0x000078D1A57DD621
000078d1a57dbe42  movaps xmm6, xmm9
000078d1a57dbe46  addpd xmm6, xmm7
000078d1a57dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000078d1a57dbe4f  ptest xmm4, xmm4
000078d1a57dbe54  jnz 0x000078D1A57DD763
000078d1a57dbe5a  vmovaps xmm9, [rsp+0x70]
000078d1a57dbe60  vpermilpd xmm9, xmm9, 0x00
000078d1a57dbe66  vmovaps xmm4, [rsp+0x90]
000078d1a57dbe6f  movaps xmm7, xmm4
000078d1a57dbe72  mulpd xmm7, xmm9
000078d1a57dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000078d1a57dbe7c  ptest xmm3, xmm3
000078d1a57dbe81  jnz 0x000078D1A57DD8A4
000078d1a57dbe87  vmovaps xmm9, [rsp+0x50]
000078d1a57dbe8d  vpermilpd xmm9, xmm9, 0x00
000078d1a57dbe93  movaps xmm4, xmm15
000078d1a57dbe97  mulpd xmm4, xmm9
000078d1a57dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000078d1a57dbea1  ptest xmm3, xmm3
000078d1a57dbea6  jnz 0x000078D1A57DD9E5
000078d1a57dbeac  lea r12, [rax+0xE0]
000078d1a57dbeb3  movups xmm15, [r13+r12*1]
000078d1a57dbeb9  vmovaps xmm9, [rsp+0x70]
000078d1a57dbebf  vpermilpd xmm9, xmm9, 0x00
000078d1a57dbec5  vmovaps [rsp+0x70], xmm1
000078d1a57dbecb  vmovaps xmm1, [rsp+0x80]
000078d1a57dbed4  vmovaps [rsp+0x80], xmm15
000078d1a57dbedd  movaps xmm3, xmm1
000078d1a57dbee0  mulpd xmm3, xmm9
000078d1a57dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000078d1a57dbeea  ptest xmm15, xmm15
000078d1a57dbef0  jnz 0x000078D1A57DDB31
000078d1a57dbef6  vmovaps xmm1, [rsp+0xF0]
000078d1a57dbeff  vmovaps xmm15, [rsp+0xF0]
000078d1a57dbf08  por xmm1, xmm15
000078d1a57dbf0d  movaps [r15+0x300], xmm1
000078d1a57dbf15  vmovaps xmm15, [rsp+0xE0]
000078d1a57dbf1e  vmovaps xmm9, [rsp+0xE0]
000078d1a57dbf27  por xmm15, xmm9
000078d1a57dbf2c  movaps [r15+0x190], xmm15
000078d1a57dbf34  vmovaps xmm9, [rsp+0x50]
000078d1a57dbf3a  vpermilpd xmm9, xmm9, 0x00
000078d1a57dbf40  vmovaps [rsp+0x90], xmm1
000078d1a57dbf49  vmovaps [rsp+0xE0], xmm15
000078d1a57dbf52  vmovaps xmm15, [rsp+0x80]
000078d1a57dbf5b  vmovaps [rsp+0x80], xmm14
000078d1a57dbf64  movaps xmm1, xmm15
000078d1a57dbf68  mulpd xmm1, xmm9
000078d1a57dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000078d1a57dbf72  ptest xmm14, xmm14
000078d1a57dbf78  jnz 0x000078D1A57DDC72
000078d1a57dbf7e  lea r12, [rax+0x90]
000078d1a57dbf85  movups xmm15, [r13+r12*1]
000078d1a57dbf8b  vmovaps xmm14, [rsp+0xD0]
000078d1a57dbf94  vmovaps xmm9, [rsp+0xD0]
000078d1a57dbf9d  por xmm14, xmm9
000078d1a57dbfa2  movaps [r15+0x1C0], xmm14
000078d1a57dbfaa  vmovaps xmm9, [rsp+0xC0]
000078d1a57dbfb3  vmovaps [rsp+0xD0], xmm1
000078d1a57dbfbc  vmovaps xmm1, [rsp+0xC0]
000078d1a57dbfc5  por xmm9, xmm1
000078d1a57dbfca  movaps [r15+0x200], xmm9
000078d1a57dbfd2  vmovaps [rsp+0xC0], xmm2
000078d1a57dbfdb  vmovaps xmm1, [rsp+0xC0]
000078d1a57dbfe4  por xmm2, xmm1
000078d1a57dbfe8  movaps [r15+0x2D0], xmm2
000078d1a57dbff0  vmovaps [rsp+0xC0], xmm8
000078d1a57dbff9  vmovaps xmm1, [rsp+0xC0]
000078d1a57dc002  por xmm8, xmm1
000078d1a57dc007  movaps [r15+0x2E0], xmm8
000078d1a57dc00f  vmovaps [rsp+0xC0], xmm15
000078d1a57dc018  movaps xmm1, xmm5
000078d1a57dc01b  addpd xmm1, xmm7
000078d1a57dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000078d1a57dc024  ptest xmm15, xmm15
000078d1a57dc02a  jnz 0x000078D1A57DDDBE
000078d1a57dc030  vmovaps xmm15, [rsp+0x50]
000078d1a57dc036  vpermilpd xmm15, xmm15, 0x00
000078d1a57dc03c  vmovaps xmm5, [rsp+0xC0]
000078d1a57dc045  vmovaps [rsp+0xC0], xmm1
000078d1a57dc04e  movaps xmm7, xmm5
000078d1a57dc051  mulpd xmm7, xmm15
000078d1a57dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000078d1a57dc05b  ptest xmm1, xmm1
000078d1a57dc060  jnz 0x000078D1A57DDEFE
000078d1a57dc066  lea r12, [rax+0x80]
000078d1a57dc06d  movups xmm1, [r13+r12*1]
000078d1a57dc073  vmovaps xmm5, [rsp+0x70]
000078d1a57dc079  vmovaps [rsp+0x70], xmm1
000078d1a57dc07f  movaps xmm15, xmm5
000078d1a57dc083  addpd xmm15, xmm3
000078d1a57dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000078d1a57dc08e  ptest xmm1, xmm1
000078d1a57dc093  jnz 0x000078D1A57DE049
000078d1a57dc099  vmovaps xmm5, [rsp+0x80]
000078d1a57dc0a2  movaps xmm1, xmm5
000078d1a57dc0a5  addpd xmm1, xmm4
000078d1a57dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000078d1a57dc0ae  ptest xmm3, xmm3
000078d1a57dc0b3  jnz 0x000078D1A57DE18B
000078d1a57dc0b9  vmovaps [rsp+0x80], xmm10
000078d1a57dc0c2  vmovaps xmm5, [rsp+0x80]
000078d1a57dc0cb  por xmm10, xmm5
000078d1a57dc0d0  movaps [r15+0x2F0], xmm10
000078d1a57dc0d8  vmovaps xmm5, [rsp+0x50]
000078d1a57dc0de  vpermilpd xmm5, xmm5, 0x00
000078d1a57dc0e4  vmovaps xmm3, [rsp+0x70]
000078d1a57dc0ea  vmovaps [rsp+0x50], xmm1
000078d1a57dc0f0  movaps xmm4, xmm3
000078d1a57dc0f3  mulpd xmm4, xmm5
000078d1a57dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000078d1a57dc0fc  ptest xmm1, xmm1
000078d1a57dc101  jnz 0x000078D1A57DE2CB
000078d1a57dc107  lea r12, [rax+0xD0]
000078d1a57dc10e  movups xmm1, [r13+r12*1]
000078d1a57dc114  vmovaps xmm3, [rsp+0xD0]
000078d1a57dc11d  vmovaps [rsp+0x70], xmm1
000078d1a57dc123  movaps xmm5, xmm6
000078d1a57dc126  addpd xmm5, xmm3
000078d1a57dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000078d1a57dc12f  ptest xmm1, xmm1
000078d1a57dc134  jnz 0x000078D1A57DE415
000078d1a57dc13a  vmovaps xmm1, [rsp+0x60]
000078d1a57dc140  vpermilpd xmm1, xmm1, 0x00
000078d1a57dc146  movaps xmm6, xmm9
000078d1a57dc14a  mulpd xmm6, xmm1
000078d1a57dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000078d1a57dc153  ptest xmm3, xmm3
000078d1a57dc158  jnz 0x000078D1A57DE555
000078d1a57dc15e  movaps [r15+0x260], xmm6
000078d1a57dc166  vxorps xmm1, xmm1, xmm1
000078d1a57dc16a  vpbroadcastq xmm1, xmm1
000078d1a57dc16f  movaps [r15+0x1B0], xmm1
000078d1a57dc177  vmovaps xmm1, [rsp+0x60]
000078d1a57dc17d  vpermilpd xmm1, xmm1, 0x00
000078d1a57dc183  vmovaps xmm3, [rsp+0x70]
000078d1a57dc189  vmovaps [rsp+0x70], xmm15
000078d1a57dc18f  movaps xmm9, xmm3
000078d1a57dc193  mulpd xmm9, xmm1
000078d1a57dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000078d1a57dc19e  ptest xmm15, xmm15
000078d1a57dc1a4  jnz 0x000078D1A57DE696
000078d1a57dc1aa  lea r12, [rax+0xC0]
000078d1a57dc1b1  movups xmm1, [r13+r12*1]
000078d1a57dc1b7  vmovaps xmm3, [rsp+0xC0]
000078d1a57dc1c0  vmovaps [rsp+0x80], xmm1
000078d1a57dc1c9  movaps xmm15, xmm3
000078d1a57dc1cd  addpd xmm15, xmm7
000078d1a57dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000078d1a57dc1d8  ptest xmm1, xmm1
000078d1a57dc1dd  jnz 0x000078D1A57DE7E2
000078d1a57dc1e3  vmovaps [rsp+0xC0], xmm13
000078d1a57dc1ec  vmovaps xmm1, [rsp+0xC0]
000078d1a57dc1f5  por xmm13, xmm1
000078d1a57dc1fa  movaps [r15+0x270], xmm13
000078d1a57dc202  vmovaps xmm1, [rsp+0xB0]
000078d1a57dc20b  vmovaps xmm7, [rsp+0xB0]
000078d1a57dc214  por xmm1, xmm7
000078d1a57dc218  movaps [r15+0x1A0], xmm1
000078d1a57dc220  vmovaps xmm1, [rsp+0x60]
000078d1a57dc226  vpermilpd xmm1, xmm1, 0x00
000078d1a57dc22c  vmovaps [rsp+0xB0], xmm1
000078d1a57dc235  vmovaps xmm1, [rsp+0x80]
000078d1a57dc23e  vmovaps [rsp+0x80], xmm15
000078d1a57dc247  vmovaps xmm15, [rsp+0xB0]
000078d1a57dc250  vmovaps [rsp+0xB0], xmm14
000078d1a57dc259  movaps xmm3, xmm1
000078d1a57dc25c  mulpd xmm3, xmm15
000078d1a57dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000078d1a57dc266  ptest xmm14, xmm14
000078d1a57dc26c  jnz 0x000078D1A57DE924
000078d1a57dc272  lea r12, [rax+0x20]
000078d1a57dc276  movups xmm1, [r13+r12*1]
000078d1a57dc27c  movaps [r15+0x110], xmm1
000078d1a57dc284  vmovaps xmm14, [rsp+0x70]
000078d1a57dc28a  vmovaps [rsp+0x70], xmm1
000078d1a57dc290  movaps xmm15, xmm14
000078d1a57dc294  addpd xmm15, xmm4
000078d1a57dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000078d1a57dc29f  ptest xmm1, xmm1
000078d1a57dc2a4  jnz 0x000078D1A57DEA6F
000078d1a57dc2aa  vmovaps xmm1, [rsp+0x60]
000078d1a57dc2b0  vpermilpd xmm1, xmm1, 0x00
000078d1a57dc2b6  movaps xmm14, xmm2
000078d1a57dc2ba  mulpd xmm14, xmm1
000078d1a57dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000078d1a57dc2c5  ptest xmm4, xmm4
000078d1a57dc2ca  jnz 0x000078D1A57DEBB2
000078d1a57dc2d0  vmovaps xmm4, [rsp+0x50]
000078d1a57dc2d6  movaps xmm1, xmm4
000078d1a57dc2d9  addpd xmm1, xmm9
000078d1a57dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000078d1a57dc2e3  ptest xmm2, xmm2
000078d1a57dc2e8  jnz 0x000078D1A57DECF4
000078d1a57dc2ee  vmovaps xmm9, [rsp+0x30]
000078d1a57dc2f4  vpermilpd xmm9, xmm9, 0x00
000078d1a57dc2fa  vmovaps xmm2, [rsp+0x70]
000078d1a57dc300  vmovaps [rsp+0x50], xmm1
000078d1a57dc306  movaps xmm4, xmm2
000078d1a57dc309  mulpd xmm4, xmm9
000078d1a57dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000078d1a57dc313  ptest xmm1, xmm1
000078d1a57dc318  jnz 0x000078D1A57DEE35
000078d1a57dc31e  vmovaps xmm1, [rsp+0x30]
000078d1a57dc324  vpermilpd xmm1, xmm1, 0x00
000078d1a57dc32a  vmovaps xmm2, [rsp+0x90]
000078d1a57dc333  vmovaps [rsp+0x60], xmm15
000078d1a57dc339  movaps xmm9, xmm2
000078d1a57dc33d  mulpd xmm9, xmm1
000078d1a57dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000078d1a57dc348  ptest xmm15, xmm15
000078d1a57dc34e  jnz 0x000078D1A57DEF76
000078d1a57dc354  vmovaps xmm15, [rsp+0x80]
000078d1a57dc35d  movaps xmm1, xmm15
000078d1a57dc361  addpd xmm1, xmm6
000078d1a57dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000078d1a57dc36a  ptest xmm2, xmm2
000078d1a57dc36f  jnz 0x000078D1A57DF0B8
000078d1a57dc375  movaps xmm15, xmm5
000078d1a57dc379  addpd xmm15, xmm3
000078d1a57dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000078d1a57dc384  ptest xmm6, xmm6
000078d1a57dc389  jnz 0x000078D1A57DF1F9
000078d1a57dc38f  vmovaps xmm6, [rsp+0x30]
000078d1a57dc395  vpermilpd xmm6, xmm6, 0x00
000078d1a57dc39b  movaps xmm5, xmm8
000078d1a57dc39f  mulpd xmm5, xmm6
000078d1a57dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000078d1a57dc3a8  ptest xmm3, xmm3
000078d1a57dc3ad  jnz 0x000078D1A57DF33B
000078d1a57dc3b3  vmovaps xmm8, [rsp+0x30]
000078d1a57dc3b9  vpermilpd xmm8, xmm8, 0x00
000078d1a57dc3bf  movaps xmm6, xmm10
000078d1a57dc3c3  mulpd xmm6, xmm8
000078d1a57dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000078d1a57dc3cd  ptest xmm3, xmm3
000078d1a57dc3d2  jnz 0x000078D1A57DF47C
000078d1a57dc3d8  vmovaps xmm8, [rsp+0x60]
000078d1a57dc3de  movaps xmm10, xmm8
000078d1a57dc3e2  addpd xmm10, xmm14
000078d1a57dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000078d1a57dc3ed  ptest xmm3, xmm3
000078d1a57dc3f2  jnz 0x000078D1A57DF5BE
000078d1a57dc3f8  vmovaps xmm8, [rsp+0x50]
000078d1a57dc3fe  movaps xmm14, xmm8
000078d1a57dc402  addpd xmm14, xmm4
000078d1a57dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000078d1a57dc40d  ptest xmm3, xmm3
000078d1a57dc412  jnz 0x000078D1A57DF702
000078d1a57dc418  vmovaps xmm8, [rsp+0x40]
000078d1a57dc41e  vpermilpd xmm8, xmm8, 0x00
000078d1a57dc424  movaps xmm4, xmm13
000078d1a57dc428  mulpd xmm4, xmm8
000078d1a57dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000078d1a57dc432  ptest xmm3, xmm3
000078d1a57dc437  jnz 0x000078D1A57DF845
000078d1a57dc43d  movaps xmm13, xmm15
000078d1a57dc441  addpd xmm13, xmm9
000078d1a57dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000078d1a57dc44c  ptest xmm8, xmm8
000078d1a57dc452  jnz 0x000078D1A57DF987
000078d1a57dc458  movaps xmm15, xmm1
000078d1a57dc45c  addpd xmm15, xmm5
000078d1a57dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000078d1a57dc467  ptest xmm9, xmm9
000078d1a57dc46d  jnz 0x000078D1A57DFACB
000078d1a57dc473  vmovaps [rsp+0x30], xmm11
000078d1a57dc479  vmovaps xmm1, [rsp+0x30]
000078d1a57dc47f  por xmm11, xmm1
000078d1a57dc484  movaps [r15+0x250], xmm11
000078d1a57dc48c  vmovaps [rsp+0x30], xmm12
000078d1a57dc492  vmovaps xmm1, [rsp+0x30]
000078d1a57dc498  por xmm12, xmm1
000078d1a57dc49d  movaps [r15+0x2A0], xmm12
000078d1a57dc4a5  vmovaps xmm1, [rsp+0xA0]
000078d1a57dc4ae  vmovaps xmm11, [rsp+0xA0]
000078d1a57dc4b7  por xmm1, xmm11
000078d1a57dc4bc  movaps [r15+0x1D0], xmm1
000078d1a57dc4c4  lea r12, [rax+0x40]
000078d1a57dc4c8  movups xmm1, [r13+r12*1]
000078d1a57dc4ce  movaps [r15+0x2C0], xmm1
000078d1a57dc4d6  vmovaps xmm11, [rsp+0x40]
000078d1a57dc4dc  vpermilpd xmm11, xmm11, 0x00
000078d1a57dc4e2  vmovaps xmm8, [rsp+0xE0]
000078d1a57dc4eb  movaps xmm9, xmm8
000078d1a57dc4ef  mulpd xmm9, xmm11
000078d1a57dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000078d1a57dc4fa  ptest xmm5, xmm5
000078d1a57dc4ff  jnz 0x000078D1A57DFC17
000078d1a57dc505  movaps xmm11, xmm10
000078d1a57dc509  addpd xmm11, xmm6
000078d1a57dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000078d1a57dc514  ptest xmm8, xmm8
000078d1a57dc51a  jnz 0x000078D1A57DFD5B
000078d1a57dc520  movaps xmm10, xmm14
000078d1a57dc524  addpd xmm10, xmm4
000078d1a57dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000078d1a57dc52f  ptest xmm8, xmm8
000078d1a57dc535  jnz 0x000078D1A57DFE9E
000078d1a57dc53b  vmovaps xmm14, [rsp+0x40]
000078d1a57dc541  vpermilpd xmm14, xmm14, 0x00
000078d1a57dc547  movaps xmm8, xmm1
000078d1a57dc54b  mulpd xmm8, xmm14
000078d1a57dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000078d1a57dc556  ptest xmm6, xmm6
000078d1a57dc55b  jnz 0x000078D1A57DFFE1
000078d1a57dc561  movaps xmm1, [r15+0x2B0]
000078d1a57dc569  vmovaps xmm14, [rsp+0x40]
000078d1a57dc56f  vpermilpd xmm14, xmm14, 0x00
000078d1a57dc575  movaps xmm6, xmm1
000078d1a57dc578  mulpd xmm6, xmm14
000078d1a57dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000078d1a57dc582  ptest xmm5, xmm5
000078d1a57dc587  jnz 0x000078D1A57E0124
000078d1a57dc58d  vmovaps xmm1, [rsp+0x10]
000078d1a57dc593  vpermilpd xmm1, xmm1, 0x00
000078d1a57dc599  movaps xmm14, xmm12
000078d1a57dc59d  mulpd xmm14, xmm1
000078d1a57dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000078d1a57dc5a8  ptest xmm5, xmm5
000078d1a57dc5ad  jnz 0x000078D1A57E0265
000078d1a57dc5b3  movaps xmm1, xmm13
000078d1a57dc5b7  addpd xmm1, xmm9
000078d1a57dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000078d1a57dc5c1  ptest xmm12, xmm12
000078d1a57dc5c7  jnz 0x000078D1A57E03A8
000078d1a57dc5cd  vmovaps xmm13, [rsp+0x10]
000078d1a57dc5d3  vpermilpd xmm13, xmm13, 0x00
000078d1a57dc5d9  movaps xmm12, xmm7
000078d1a57dc5dd  mulpd xmm12, xmm13
000078d1a57dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000078d1a57dc5e8  ptest xmm9, xmm9
000078d1a57dc5ee  jnz 0x000078D1A57E04EA
000078d1a57dc5f4  movaps xmm13, xmm15
000078d1a57dc5f8  addpd xmm13, xmm8
000078d1a57dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000078d1a57dc603  ptest xmm9, xmm9
000078d1a57dc609  jnz 0x000078D1A57E062D
000078d1a57dc60f  movaps xmm15, [r15+0x290]
000078d1a57dc617  vmovaps xmm9, [rsp+0x10]
000078d1a57dc61d  vpermilpd xmm9, xmm9, 0x00
000078d1a57dc623  movaps xmm8, xmm15
000078d1a57dc627  mulpd xmm8, xmm9
000078d1a57dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000078d1a57dc632  ptest xmm7, xmm7
000078d1a57dc637  jnz 0x000078D1A57E0771
000078d1a57dc63d  movaps xmm15, xmm11
000078d1a57dc641  addpd xmm15, xmm6
000078d1a57dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000078d1a57dc64c  ptest xmm9, xmm9
000078d1a57dc652  jnz 0x000078D1A57E08B5
000078d1a57dc658  movaps xmm11, [r15+0x1E0]
000078d1a57dc660  vmovaps xmm9, [rsp+0x10]
000078d1a57dc666  vpermilpd xmm9, xmm9, 0x00
000078d1a57dc66c  movaps xmm7, xmm11
000078d1a57dc670  mulpd xmm7, xmm9
000078d1a57dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000078d1a57dc67a  ptest xmm6, xmm6
000078d1a57dc67f  jnz 0x000078D1A57E09F8
000078d1a57dc685  movaps xmm11, xmm10
000078d1a57dc689  addpd xmm11, xmm14
000078d1a57dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000078d1a57dc694  ptest xmm9, xmm9
000078d1a57dc69a  jnz 0x000078D1A57E0B3A
000078d1a57dc6a0  lea r12, [rax+0x70]
000078d1a57dc6a4  movups xmm14, [r13+r12*1]
000078d1a57dc6aa  movaps [r15+0x240], xmm14
000078d1a57dc6b2  movaps xmm10, xmm1
000078d1a57dc6b6  addpd xmm10, xmm12
000078d1a57dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000078d1a57dc6c1  ptest xmm9, xmm9
000078d1a57dc6c7  jnz 0x000078D1A57E0C88
000078d1a57dc6cd  movaps [r15+0x170], xmm10
000078d1a57dc6d5  vmovaps xmm1, [rsp+0x20]
000078d1a57dc6db  vpermilpd xmm1, xmm1, 0x00
000078d1a57dc6e1  movaps xmm12, xmm14
000078d1a57dc6e5  mulpd xmm12, xmm1
000078d1a57dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000078d1a57dc6f0  ptest xmm9, xmm9
000078d1a57dc6f6  jnz 0x000078D1A57E0DCB
000078d1a57dc6fc  vmovaps xmm1, [rsp+0x20]
000078d1a57dc702  vpermilpd xmm1, xmm1, 0x00
000078d1a57dc708  vmovaps xmm9, [rsp+0xB0]
000078d1a57dc711  movaps xmm14, xmm9
000078d1a57dc715  mulpd xmm14, xmm1
000078d1a57dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000078d1a57dc720  ptest xmm6, xmm6
000078d1a57dc725  jnz 0x000078D1A57E0F0E
000078d1a57dc72b  movaps [r15+0x180], xmm14
000078d1a57dc733  movaps xmm1, xmm13
000078d1a57dc737  addpd xmm1, xmm8
000078d1a57dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000078d1a57dc741  ptest xmm9, xmm9
000078d1a57dc747  jnz 0x000078D1A57E1051
000078d1a57dc74d  movaps [r15+0x210], xmm1
000078d1a57dc755  movups xmm13, [r13+rax*1]
000078d1a57dc75b  lea r12, [rax+0x10]
000078d1a57dc75f  movups xmm9, [r13+r12*1]
000078d1a57dc765  movaps [r15+0x230], xmm9
000078d1a57dc76d  movaps xmm8, xmm15
000078d1a57dc771  addpd xmm8, xmm7
000078d1a57dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000078d1a57dc77c  ptest xmm6, xmm6
000078d1a57dc781  jnz 0x000078D1A57E11A7
000078d1a57dc787  movaps [r15+0x130], xmm8
000078d1a57dc78f  vmovaps xmm15, [rsp+0x20]
000078d1a57dc795  vpermilpd xmm15, xmm15, 0x00
000078d1a57dc79b  movaps xmm7, xmm9
000078d1a57dc79f  mulpd xmm7, xmm15
000078d1a57dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000078d1a57dc7a9  ptest xmm6, xmm6
000078d1a57dc7ae  jnz 0x000078D1A57E12EA
000078d1a57dc7b4  movaps [r15+0x220], xmm7
000078d1a57dc7bc  vmovaps xmm15, [rsp+0x20]
000078d1a57dc7c2  vpermilpd xmm15, xmm15, 0x00
000078d1a57dc7c8  movaps xmm9, xmm13
000078d1a57dc7cc  mulpd xmm9, xmm15
000078d1a57dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000078d1a57dc7d7  ptest xmm6, xmm6
000078d1a57dc7dc  jnz 0x000078D1A57E142C
000078d1a57dc7e2  movaps xmm15, xmm11
000078d1a57dc7e6  addpd xmm15, xmm12
000078d1a57dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000078d1a57dc7f1  ptest xmm13, xmm13
000078d1a57dc7f7  jnz 0x000078D1A57E1570
000078d1a57dc7fd  movaps [r15+0x140], xmm15
000078d1a57dc805  movaps xmm13, xmm10
000078d1a57dc809  addpd xmm13, xmm14
000078d1a57dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000078d1a57dc814  ptest xmm12, xmm12
000078d1a57dc81a  jnz 0x000078D1A57E16B4
000078d1a57dc820  movaps [r15+0x150], xmm13
000078d1a57dc828  movaps xmm14, xmm1
000078d1a57dc82c  addpd xmm14, xmm7
000078d1a57dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000078d1a57dc837  ptest xmm12, xmm12
000078d1a57dc83d  jnz 0x000078D1A57E17F8
000078d1a57dc843  movaps [r15+0x160], xmm14
000078d1a57dc84b  movaps xmm1, xmm8
000078d1a57dc84f  addpd xmm1, xmm9
000078d1a57dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000078d1a57dc859  ptest xmm12, xmm12
000078d1a57dc85f  jnz 0x000078D1A57E193A
000078d1a57dc865  movaps [r15+0x120], xmm1
000078d1a57dc86d  movups [r13+r14*1], xmm15
000078d1a57dc873  lea rax, [r14+0x10]
000078d1a57dc877  movups [r13+rax*1], xmm13
000078d1a57dc87d  lea rax, [r14+0x20]
000078d1a57dc881  movups [r13+rax*1], xmm14
000078d1a57dc887  lea rax, [r14+0x30]
000078d1a57dc88b  movups [r13+rax*1], xmm1
000078d1a57dc891  mov eax, [r15+0x108]
000078d1a57dc898  sahf
000078d1a57dc899  jnz 0x000078D1A57DC8CB
000078d1a57dc89b  cmp dword ptr [r15+0x318], 0x00
000078d1a57dc8a3  jz 0x000078D1A57DB900
000078d1a57dc8a9  nop [rax+rax*1], ax
000078d1a57dc8b2  nop [rax+rax*1], eax
000078d1a57dc8ba  mov eax, 0x410444
000078d1a57dc8bf  mov [r15+0x100], rax
000078d1a57dc8c6  jmp 0x000078D1A55FE110
000078d1a57dc8cb  cmp dword ptr [r15+0x318], 0x00
000078d1a57dc8d3  jz 0x000078D1A57D57E0
000078d1a57dc8d9  nop [rax+rax*1], ax
000078d1a57dc8e2  nop [rax+rax*1], eax
000078d1a57dc8ea  mov eax, 0x410278
000078d1a57dc8ef  mov [r15+0x100], rax
000078d1a57dc8f6  jmp 0x000078D1A55FE110
000078d1a57dc8fb  int3
000078d1a57dc8fc  call 0x000078D1A56E27E0
000078d1a57dc901  jmp 0x000078D1A57DB9DF
000078d1a57dc906  call 0x000078D1A56E1570
000078d1a57dc90b  jmp 0x000078D1A57DB9E8
000078d1a57dc910  call 0x000078D1A56E27E0
000078d1a57dc915  jmp 0x000078D1A57DBA44
000078d1a57dc91a  call 0x000078D1A56E1570
000078d1a57dc91f  jmp 0x000078D1A57DBA4D
000078d1a57dc924  call 0x000078D1A56E27E0
000078d1a57dc929  jmp 0x000078D1A57DBA90
000078d1a57dc92e  call 0x000078D1A56E1570
000078d1a57dc933  jmp 0x000078D1A57DBA99
000078d1a57dc938  call 0x000078D1A560DC20
000078d1a57dc93d  jmp 0x000078D1A57DBAD8
000078d1a57dc942  call 0x000078D1A56D59C0
000078d1a57dc947  jmp 0x000078D1A57DBAEB
000078d1a57dc94c  call 0x000078D1A56E0E30
000078d1a57dc951  jmp 0x000078D1A57DBB09
000078d1a57dc956  call 0x000078D1A56DFBC0
000078d1a57dc95b  jmp 0x000078D1A57DBB13
000078d1a57dc960  call 0x000078D1A56DE950
000078d1a57dc965  jmp 0x000078D1A57DBB1D
000078d1a57dc96a  sub rsp, 0x08
000078d1a57dc96e  push rax
000078d1a57dc96f  push rcx
000078d1a57dc970  push rdx
000078d1a57dc971  push rdi
000078d1a57dc972  push rsi
000078d1a57dc973  push r8
000078d1a57dc975  push r9
000078d1a57dc977  push r10
000078d1a57dc979  push r11
000078d1a57dc97b  sub rsp, 0xF0
000078d1a57dc982  vmovaps [rsp], xmm0
000078d1a57dc987  vmovaps [rsp+0x10], xmm1
000078d1a57dc98d  vmovaps [rsp+0x20], xmm2
000078d1a57dc993  vmovaps [rsp+0x30], xmm3
000078d1a57dc999  vmovaps [rsp+0x40], xmm4
000078d1a57dc99f  vmovaps [rsp+0x50], xmm5
000078d1a57dc9a5  vmovaps [rsp+0x60], xmm6
000078d1a57dc9ab  vmovaps [rsp+0x70], xmm7
000078d1a57dc9b1  vmovaps [rsp+0x80], xmm9
000078d1a57dc9ba  vmovaps [rsp+0x90], xmm10
000078d1a57dc9c3  vmovaps [rsp+0xA0], xmm11
000078d1a57dc9cc  vmovaps [rsp+0xB0], xmm12
000078d1a57dc9d5  vmovaps [rsp+0xC0], xmm13
000078d1a57dc9de  vmovaps [rsp+0xD0], xmm14
000078d1a57dc9e7  vmovaps [rsp+0xE0], xmm15
000078d1a57dc9f0  sub rsp, 0x30
000078d1a57dc9f4  movaps [rsp], xmm8
000078d1a57dc9f9  movaps [rsp+0x10], xmm12
000078d1a57dc9ff  movaps [rsp+0x20], xmm15
000078d1a57dca05  lea rdi, [rsp]
000078d1a57dca09  mov esi, 0x00
000078d1a57dca0e  mov rax, 0x56EA20A26530
000078d1a57dca18  call rax
000078d1a57dca1a  movaps xmm8, [rsp]
000078d1a57dca1f  add rsp, 0x30
000078d1a57dca23  vmovaps xmm0, [rsp]
000078d1a57dca28  vmovaps xmm1, [rsp+0x10]
000078d1a57dca2e  vmovaps xmm2, [rsp+0x20]
000078d1a57dca34  vmovaps xmm3, [rsp+0x30]
000078d1a57dca3a  vmovaps xmm4, [rsp+0x40]
000078d1a57dca40  vmovaps xmm5, [rsp+0x50]
000078d1a57dca46  vmovaps xmm6, [rsp+0x60]
000078d1a57dca4c  vmovaps xmm7, [rsp+0x70]
000078d1a57dca52  vmovaps xmm9, [rsp+0x80]
000078d1a57dca5b  vmovaps xmm10, [rsp+0x90]
000078d1a57dca64  vmovaps xmm11, [rsp+0xA0]
000078d1a57dca6d  vmovaps xmm12, [rsp+0xB0]
000078d1a57dca76  vmovaps xmm13, [rsp+0xC0]
000078d1a57dca7f  vmovaps xmm14, [rsp+0xD0]
000078d1a57dca88  vmovaps xmm15, [rsp+0xE0]
000078d1a57dca91  add rsp, 0xF0
000078d1a57dca98  pop r11
000078d1a57dca9a  pop r10
000078d1a57dca9c  pop r9
000078d1a57dca9e  pop r8
000078d1a57dcaa0  pop rsi
000078d1a57dcaa1  pop rdi
000078d1a57dcaa2  pop rdx
000078d1a57dcaa3  pop rcx
000078d1a57dcaa4  pop rax
000078d1a57dcaa5  add rsp, 0x08
000078d1a57dcaa9  jmp 0x000078D1A57DBB47
000078d1a57dcaae  sub rsp, 0x08
000078d1a57dcab2  push rax
000078d1a57dcab3  push rcx
000078d1a57dcab4  push rdx
000078d1a57dcab5  push rdi
000078d1a57dcab6  push rsi
000078d1a57dcab7  push r8
000078d1a57dcab9  push r9
000078d1a57dcabb  push r10
000078d1a57dcabd  push r11
000078d1a57dcabf  sub rsp, 0xF0
000078d1a57dcac6  vmovaps [rsp], xmm0
000078d1a57dcacb  vmovaps [rsp+0x10], xmm1
000078d1a57dcad1  vmovaps [rsp+0x20], xmm2
000078d1a57dcad7  vmovaps [rsp+0x30], xmm3
000078d1a57dcadd  vmovaps [rsp+0x40], xmm4
000078d1a57dcae3  vmovaps [rsp+0x50], xmm5
000078d1a57dcae9  vmovaps [rsp+0x60], xmm6
000078d1a57dcaef  vmovaps [rsp+0x70], xmm8
000078d1a57dcaf5  vmovaps [rsp+0x80], xmm9
000078d1a57dcafe  vmovaps [rsp+0x90], xmm10
000078d1a57dcb07  vmovaps [rsp+0xA0], xmm11
000078d1a57dcb10  vmovaps [rsp+0xB0], xmm12
000078d1a57dcb19  vmovaps [rsp+0xC0], xmm13
000078d1a57dcb22  vmovaps [rsp+0xD0], xmm14
000078d1a57dcb2b  vmovaps [rsp+0xE0], xmm15
000078d1a57dcb34  sub rsp, 0x30
000078d1a57dcb38  movaps [rsp], xmm7
000078d1a57dcb3c  movaps [rsp+0x10], xmm9
000078d1a57dcb42  movaps [rsp+0x20], xmm15
000078d1a57dcb48  lea rdi, [rsp]
000078d1a57dcb4c  mov esi, 0x00
000078d1a57dcb51  mov rax, 0x56EA20A26530
000078d1a57dcb5b  call rax
000078d1a57dcb5d  movaps xmm7, [rsp]
000078d1a57dcb61  add rsp, 0x30
000078d1a57dcb65  vmovaps xmm0, [rsp]
000078d1a57dcb6a  vmovaps xmm1, [rsp+0x10]
000078d1a57dcb70  vmovaps xmm2, [rsp+0x20]
000078d1a57dcb76  vmovaps xmm3, [rsp+0x30]
000078d1a57dcb7c  vmovaps xmm4, [rsp+0x40]
000078d1a57dcb82  vmovaps xmm5, [rsp+0x50]
000078d1a57dcb88  vmovaps xmm6, [rsp+0x60]
000078d1a57dcb8e  vmovaps xmm8, [rsp+0x70]
000078d1a57dcb94  vmovaps xmm9, [rsp+0x80]
000078d1a57dcb9d  vmovaps xmm10, [rsp+0x90]
000078d1a57dcba6  vmovaps xmm11, [rsp+0xA0]
000078d1a57dcbaf  vmovaps xmm12, [rsp+0xB0]
000078d1a57dcbb8  vmovaps xmm13, [rsp+0xC0]
000078d1a57dcbc1  vmovaps xmm14, [rsp+0xD0]
000078d1a57dcbca  vmovaps xmm15, [rsp+0xE0]
000078d1a57dcbd3  add rsp, 0xF0
000078d1a57dcbda  pop r11
000078d1a57dcbdc  pop r10
000078d1a57dcbde  pop r9
000078d1a57dcbe0  pop r8
000078d1a57dcbe2  pop rsi
000078d1a57dcbe3  pop rdi
000078d1a57dcbe4  pop rdx
000078d1a57dcbe5  pop rcx
000078d1a57dcbe6  pop rax
000078d1a57dcbe7  add rsp, 0x08
000078d1a57dcbeb  jmp 0x000078D1A57DBB75
000078d1a57dcbf0  sub rsp, 0x08
000078d1a57dcbf4  push rax
000078d1a57dcbf5  push rcx
000078d1a57dcbf6  push rdx
000078d1a57dcbf7  push rdi
000078d1a57dcbf8  push rsi
000078d1a57dcbf9  push r8
000078d1a57dcbfb  push r9
000078d1a57dcbfd  push r10
000078d1a57dcbff  push r11
000078d1a57dcc01  sub rsp, 0xF0
000078d1a57dcc08  vmovaps [rsp], xmm0
000078d1a57dcc0d  vmovaps [rsp+0x10], xmm1
000078d1a57dcc13  vmovaps [rsp+0x20], xmm2
000078d1a57dcc19  vmovaps [rsp+0x30], xmm3
000078d1a57dcc1f  vmovaps [rsp+0x40], xmm4
000078d1a57dcc25  vmovaps [rsp+0x50], xmm5
000078d1a57dcc2b  vmovaps [rsp+0x60], xmm6
000078d1a57dcc31  vmovaps [rsp+0x70], xmm7
000078d1a57dcc37  vmovaps [rsp+0x80], xmm8
000078d1a57dcc40  vmovaps [rsp+0x90], xmm10
000078d1a57dcc49  vmovaps [rsp+0xA0], xmm11
000078d1a57dcc52  vmovaps [rsp+0xB0], xmm12
000078d1a57dcc5b  vmovaps [rsp+0xC0], xmm13
000078d1a57dcc64  vmovaps [rsp+0xD0], xmm14
000078d1a57dcc6d  vmovaps [rsp+0xE0], xmm15
000078d1a57dcc76  sub rsp, 0x30
000078d1a57dcc7a  movaps [rsp], xmm9
000078d1a57dcc7f  movaps [rsp+0x10], xmm12
000078d1a57dcc85  movaps [rsp+0x20], xmm10
000078d1a57dcc8b  lea rdi, [rsp]
000078d1a57dcc8f  mov esi, 0x00
000078d1a57dcc94  mov rax, 0x56EA20A26530
000078d1a57dcc9e  call rax
000078d1a57dcca0  movaps xmm9, [rsp]
000078d1a57dcca5  add rsp, 0x30
000078d1a57dcca9  vmovaps xmm0, [rsp]
000078d1a57dccae  vmovaps xmm1, [rsp+0x10]
000078d1a57dccb4  vmovaps xmm2, [rsp+0x20]
000078d1a57dccba  vmovaps xmm3, [rsp+0x30]
000078d1a57dccc0  vmovaps xmm4, [rsp+0x40]
000078d1a57dccc6  vmovaps xmm5, [rsp+0x50]
000078d1a57dcccc  vmovaps xmm6, [rsp+0x60]
000078d1a57dccd2  vmovaps xmm7, [rsp+0x70]
000078d1a57dccd8  vmovaps xmm8, [rsp+0x80]
000078d1a57dcce1  vmovaps xmm10, [rsp+0x90]
000078d1a57dccea  vmovaps xmm11, [rsp+0xA0]
000078d1a57dccf3  vmovaps xmm12, [rsp+0xB0]
000078d1a57dccfc  vmovaps xmm13, [rsp+0xC0]
000078d1a57dcd05  vmovaps xmm14, [rsp+0xD0]
000078d1a57dcd0e  vmovaps xmm15, [rsp+0xE0]
000078d1a57dcd17  add rsp, 0xF0
000078d1a57dcd1e  pop r11
000078d1a57dcd20  pop r10
000078d1a57dcd22  pop r9
000078d1a57dcd24  pop r8
000078d1a57dcd26  pop rsi
000078d1a57dcd27  pop rdi
000078d1a57dcd28  pop rdx
000078d1a57dcd29  pop rcx
000078d1a57dcd2a  pop rax
000078d1a57dcd2b  add rsp, 0x08
000078d1a57dcd2f  jmp 0x000078D1A57DBB99
000078d1a57dcd34  sub rsp, 0x08
000078d1a57dcd38  push rax
000078d1a57dcd39  push rcx
000078d1a57dcd3a  push rdx
000078d1a57dcd3b  push rdi
000078d1a57dcd3c  push rsi
000078d1a57dcd3d  push r8
000078d1a57dcd3f  push r9
000078d1a57dcd41  push r10
000078d1a57dcd43  push r11
000078d1a57dcd45  sub rsp, 0xF0
000078d1a57dcd4c  vmovaps [rsp], xmm0
000078d1a57dcd51  vmovaps [rsp+0x10], xmm1
000078d1a57dcd57  vmovaps [rsp+0x20], xmm2
000078d1a57dcd5d  vmovaps [rsp+0x30], xmm3
000078d1a57dcd63  vmovaps [rsp+0x40], xmm4
000078d1a57dcd69  vmovaps [rsp+0x50], xmm5
000078d1a57dcd6f  vmovaps [rsp+0x60], xmm6
000078d1a57dcd75  vmovaps [rsp+0x70], xmm7
000078d1a57dcd7b  vmovaps [rsp+0x80], xmm8
000078d1a57dcd84  vmovaps [rsp+0x90], xmm9
000078d1a57dcd8d  vmovaps [rsp+0xA0], xmm11
000078d1a57dcd96  vmovaps [rsp+0xB0], xmm12
000078d1a57dcd9f  vmovaps [rsp+0xC0], xmm13
000078d1a57dcda8  vmovaps [rsp+0xD0], xmm14
000078d1a57dcdb1  vmovaps [rsp+0xE0], xmm15
000078d1a57dcdba  sub rsp, 0x30
000078d1a57dcdbe  movaps [rsp], xmm10
000078d1a57dcdc3  movaps [rsp+0x10], xmm12
000078d1a57dcdc9  movaps [rsp+0x20], xmm11
000078d1a57dcdcf  lea rdi, [rsp]
000078d1a57dcdd3  mov esi, 0x00
000078d1a57dcdd8  mov rax, 0x56EA20A26530
000078d1a57dcde2  call rax
000078d1a57dcde4  movaps xmm10, [rsp]
000078d1a57dcde9  add rsp, 0x30
000078d1a57dcded  vmovaps xmm0, [rsp]
000078d1a57dcdf2  vmovaps xmm1, [rsp+0x10]
000078d1a57dcdf8  vmovaps xmm2, [rsp+0x20]
000078d1a57dcdfe  vmovaps xmm3, [rsp+0x30]
000078d1a57dce04  vmovaps xmm4, [rsp+0x40]
000078d1a57dce0a  vmovaps xmm5, [rsp+0x50]
000078d1a57dce10  vmovaps xmm6, [rsp+0x60]
000078d1a57dce16  vmovaps xmm7, [rsp+0x70]
000078d1a57dce1c  vmovaps xmm8, [rsp+0x80]
000078d1a57dce25  vmovaps xmm9, [rsp+0x90]
000078d1a57dce2e  vmovaps xmm11, [rsp+0xA0]
000078d1a57dce37  vmovaps xmm12, [rsp+0xB0]
000078d1a57dce40  vmovaps xmm13, [rsp+0xC0]
000078d1a57dce49  vmovaps xmm14, [rsp+0xD0]
000078d1a57dce52  vmovaps xmm15, [rsp+0xE0]
000078d1a57dce5b  add rsp, 0xF0
000078d1a57dce62  pop r11
000078d1a57dce64  pop r10
000078d1a57dce66  pop r9
000078d1a57dce68  pop r8
000078d1a57dce6a  pop rsi
000078d1a57dce6b  pop rdi
000078d1a57dce6c  pop rdx
000078d1a57dce6d  pop rcx
000078d1a57dce6e  pop rax
000078d1a57dce6f  add rsp, 0x08
000078d1a57dce73  jmp 0x000078D1A57DBBB3
000078d1a57dce78  sub rsp, 0x08
000078d1a57dce7c  push rax
000078d1a57dce7d  push rcx
000078d1a57dce7e  push rdx
000078d1a57dce7f  push rdi
000078d1a57dce80  push rsi
000078d1a57dce81  push r8
000078d1a57dce83  push r9
000078d1a57dce85  push r10
000078d1a57dce87  push r11
000078d1a57dce89  sub rsp, 0xF0
000078d1a57dce90  vmovaps [rsp], xmm0
000078d1a57dce95  vmovaps [rsp+0x10], xmm1
000078d1a57dce9b  vmovaps [rsp+0x20], xmm2
000078d1a57dcea1  vmovaps [rsp+0x30], xmm3
000078d1a57dcea7  vmovaps [rsp+0x40], xmm4
000078d1a57dcead  vmovaps [rsp+0x50], xmm5
000078d1a57dceb3  vmovaps [rsp+0x60], xmm7
000078d1a57dceb9  vmovaps [rsp+0x70], xmm8
000078d1a57dcebf  vmovaps [rsp+0x80], xmm9
000078d1a57dcec8  vmovaps [rsp+0x90], xmm10
000078d1a57dced1  vmovaps [rsp+0xA0], xmm11
000078d1a57dceda  vmovaps [rsp+0xB0], xmm12
000078d1a57dcee3  vmovaps [rsp+0xC0], xmm13
000078d1a57dceec  vmovaps [rsp+0xD0], xmm14
000078d1a57dcef5  vmovaps [rsp+0xE0], xmm15
000078d1a57dcefe  sub rsp, 0x30
000078d1a57dcf02  movaps [rsp], xmm6
000078d1a57dcf06  movaps [rsp+0x10], xmm12
000078d1a57dcf0c  movaps [rsp+0x20], xmm11
000078d1a57dcf12  lea rdi, [rsp]
000078d1a57dcf16  mov esi, 0x00
000078d1a57dcf1b  mov rax, 0x56EA20A26530
000078d1a57dcf25  call rax
000078d1a57dcf27  movaps xmm6, [rsp]
000078d1a57dcf2b  add rsp, 0x30
000078d1a57dcf2f  vmovaps xmm0, [rsp]
000078d1a57dcf34  vmovaps xmm1, [rsp+0x10]
000078d1a57dcf3a  vmovaps xmm2, [rsp+0x20]
000078d1a57dcf40  vmovaps xmm3, [rsp+0x30]
000078d1a57dcf46  vmovaps xmm4, [rsp+0x40]
000078d1a57dcf4c  vmovaps xmm5, [rsp+0x50]
000078d1a57dcf52  vmovaps xmm7, [rsp+0x60]
000078d1a57dcf58  vmovaps xmm8, [rsp+0x70]
000078d1a57dcf5e  vmovaps xmm9, [rsp+0x80]
000078d1a57dcf67  vmovaps xmm10, [rsp+0x90]
000078d1a57dcf70  vmovaps xmm11, [rsp+0xA0]
000078d1a57dcf79  vmovaps xmm12, [rsp+0xB0]
000078d1a57dcf82  vmovaps xmm13, [rsp+0xC0]
000078d1a57dcf8b  vmovaps xmm14, [rsp+0xD0]
000078d1a57dcf94  vmovaps xmm15, [rsp+0xE0]
000078d1a57dcf9d  add rsp, 0xF0
000078d1a57dcfa4  pop r11
000078d1a57dcfa6  pop r10
000078d1a57dcfa8  pop r9
000078d1a57dcfaa  pop r8
000078d1a57dcfac  pop rsi
000078d1a57dcfad  pop rdi
000078d1a57dcfae  pop rdx
000078d1a57dcfaf  pop rcx
000078d1a57dcfb0  pop rax
000078d1a57dcfb1  add rsp, 0x08
000078d1a57dcfb5  jmp 0x000078D1A57DBBD4
000078d1a57dcfba  sub rsp, 0x08
000078d1a57dcfbe  push rax
000078d1a57dcfbf  push rcx
000078d1a57dcfc0  push rdx
000078d1a57dcfc1  push rdi
000078d1a57dcfc2  push rsi
000078d1a57dcfc3  push r8
000078d1a57dcfc5  push r9
000078d1a57dcfc7  push r10
000078d1a57dcfc9  push r11
000078d1a57dcfcb  sub rsp, 0xF0
000078d1a57dcfd2  vmovaps [rsp], xmm0
000078d1a57dcfd7  vmovaps [rsp+0x10], xmm1
000078d1a57dcfdd  vmovaps [rsp+0x20], xmm2
000078d1a57dcfe3  vmovaps [rsp+0x30], xmm4
000078d1a57dcfe9  vmovaps [rsp+0x40], xmm5
000078d1a57dcfef  vmovaps [rsp+0x50], xmm6
000078d1a57dcff5  vmovaps [rsp+0x60], xmm7
000078d1a57dcffb  vmovaps [rsp+0x70], xmm8
000078d1a57dd001  vmovaps [rsp+0x80], xmm9
000078d1a57dd00a  vmovaps [rsp+0x90], xmm10
000078d1a57dd013  vmovaps [rsp+0xA0], xmm11
000078d1a57dd01c  vmovaps [rsp+0xB0], xmm12
000078d1a57dd025  vmovaps [rsp+0xC0], xmm13
000078d1a57dd02e  vmovaps [rsp+0xD0], xmm14
000078d1a57dd037  vmovaps [rsp+0xE0], xmm15
000078d1a57dd040  sub rsp, 0x30
000078d1a57dd044  movaps [rsp], xmm3
000078d1a57dd048  movaps [rsp+0x10], xmm5
000078d1a57dd04d  movaps [rsp+0x20], xmm4
000078d1a57dd052  lea rdi, [rsp]
000078d1a57dd056  mov esi, 0x00
000078d1a57dd05b  mov rax, 0x56EA20A26530
000078d1a57dd065  call rax
000078d1a57dd067  movaps xmm3, [rsp]
000078d1a57dd06b  add rsp, 0x30
000078d1a57dd06f  vmovaps xmm0, [rsp]
000078d1a57dd074  vmovaps xmm1, [rsp+0x10]
000078d1a57dd07a  vmovaps xmm2, [rsp+0x20]
000078d1a57dd080  vmovaps xmm4, [rsp+0x30]
000078d1a57dd086  vmovaps xmm5, [rsp+0x40]
000078d1a57dd08c  vmovaps xmm6, [rsp+0x50]
000078d1a57dd092  vmovaps xmm7, [rsp+0x60]
000078d1a57dd098  vmovaps xmm8, [rsp+0x70]
000078d1a57dd09e  vmovaps xmm9, [rsp+0x80]
000078d1a57dd0a7  vmovaps xmm10, [rsp+0x90]
000078d1a57dd0b0  vmovaps xmm11, [rsp+0xA0]
000078d1a57dd0b9  vmovaps xmm12, [rsp+0xB0]
000078d1a57dd0c2  vmovaps xmm13, [rsp+0xC0]
000078d1a57dd0cb  vmovaps xmm14, [rsp+0xD0]
000078d1a57dd0d4  vmovaps xmm15, [rsp+0xE0]
000078d1a57dd0dd  add rsp, 0xF0
000078d1a57dd0e4  pop r11
000078d1a57dd0e6  pop r10
000078d1a57dd0e8  pop r9
000078d1a57dd0ea  pop r8
000078d1a57dd0ec  pop rsi
000078d1a57dd0ed  pop rdi
000078d1a57dd0ee  pop rdx
000078d1a57dd0ef  pop rcx
000078d1a57dd0f0  pop rax
000078d1a57dd0f1  add rsp, 0x08
000078d1a57dd0f5  jmp 0x000078D1A57DBC35
000078d1a57dd0fa  sub rsp, 0x08
000078d1a57dd0fe  push rax
000078d1a57dd0ff  push rcx
000078d1a57dd100  push rdx
000078d1a57dd101  push rdi
000078d1a57dd102  push rsi
000078d1a57dd103  push r8
000078d1a57dd105  push r9
000078d1a57dd107  push r10
000078d1a57dd109  push r11
000078d1a57dd10b  sub rsp, 0xF0
000078d1a57dd112  vmovaps [rsp], xmm0
000078d1a57dd117  vmovaps [rsp+0x10], xmm1
000078d1a57dd11d  vmovaps [rsp+0x20], xmm2
000078d1a57dd123  vmovaps [rsp+0x30], xmm3
000078d1a57dd129  vmovaps [rsp+0x40], xmm4
000078d1a57dd12f  vmovaps [rsp+0x50], xmm6
000078d1a57dd135  vmovaps [rsp+0x60], xmm7
000078d1a57dd13b  vmovaps [rsp+0x70], xmm8
000078d1a57dd141  vmovaps [rsp+0x80], xmm9
000078d1a57dd14a  vmovaps [rsp+0x90], xmm10
000078d1a57dd153  vmovaps [rsp+0xA0], xmm11
000078d1a57dd15c  vmovaps [rsp+0xB0], xmm12
000078d1a57dd165  vmovaps [rsp+0xC0], xmm13
000078d1a57dd16e  vmovaps [rsp+0xD0], xmm14
000078d1a57dd177  vmovaps [rsp+0xE0], xmm15
000078d1a57dd180  sub rsp, 0x30
000078d1a57dd184  movaps [rsp], xmm5
000078d1a57dd188  movaps [rsp+0x10], xmm8
000078d1a57dd18e  movaps [rsp+0x20], xmm15
000078d1a57dd194  lea rdi, [rsp]
000078d1a57dd198  mov esi, 0x00
000078d1a57dd19d  mov rax, 0x56EA20A26530
000078d1a57dd1a7  call rax
000078d1a57dd1a9  movaps xmm5, [rsp]
000078d1a57dd1ad  add rsp, 0x30
000078d1a57dd1b1  vmovaps xmm0, [rsp]
000078d1a57dd1b6  vmovaps xmm1, [rsp+0x10]
000078d1a57dd1bc  vmovaps xmm2, [rsp+0x20]
000078d1a57dd1c2  vmovaps xmm3, [rsp+0x30]
000078d1a57dd1c8  vmovaps xmm4, [rsp+0x40]
000078d1a57dd1ce  vmovaps xmm6, [rsp+0x50]
000078d1a57dd1d4  vmovaps xmm7, [rsp+0x60]
000078d1a57dd1da  vmovaps xmm8, [rsp+0x70]
000078d1a57dd1e0  vmovaps xmm9, [rsp+0x80]
000078d1a57dd1e9  vmovaps xmm10, [rsp+0x90]
000078d1a57dd1f2  vmovaps xmm11, [rsp+0xA0]
000078d1a57dd1fb  vmovaps xmm12, [rsp+0xB0]
000078d1a57dd204  vmovaps xmm13, [rsp+0xC0]
000078d1a57dd20d  vmovaps xmm14, [rsp+0xD0]
000078d1a57dd216  vmovaps xmm15, [rsp+0xE0]
000078d1a57dd21f  add rsp, 0xF0
000078d1a57dd226  pop r11
000078d1a57dd228  pop r10
000078d1a57dd22a  pop r9
000078d1a57dd22c  pop r8
000078d1a57dd22e  pop rsi
000078d1a57dd22f  pop rdi
000078d1a57dd230  pop rdx
000078d1a57dd231  pop rcx
000078d1a57dd232  pop rax
000078d1a57dd233  add rsp, 0x08
000078d1a57dd237  jmp 0x000078D1A57DBC73
000078d1a57dd23c  sub rsp, 0x08
000078d1a57dd240  push rax
000078d1a57dd241  push rcx
000078d1a57dd242  push rdx
000078d1a57dd243  push rdi
000078d1a57dd244  push rsi
000078d1a57dd245  push r8
000078d1a57dd247  push r9
000078d1a57dd249  push r10
000078d1a57dd24b  push r11
000078d1a57dd24d  sub rsp, 0xF0
000078d1a57dd254  vmovaps [rsp], xmm0
000078d1a57dd259  vmovaps [rsp+0x10], xmm1
000078d1a57dd25f  vmovaps [rsp+0x20], xmm2
000078d1a57dd265  vmovaps [rsp+0x30], xmm3
000078d1a57dd26b  vmovaps [rsp+0x40], xmm5
000078d1a57dd271  vmovaps [rsp+0x50], xmm6
000078d1a57dd277  vmovaps [rsp+0x60], xmm7
000078d1a57dd27d  vmovaps [rsp+0x70], xmm8
000078d1a57dd283  vmovaps [rsp+0x80], xmm9
000078d1a57dd28c  vmovaps [rsp+0x90], xmm10
000078d1a57dd295  vmovaps [rsp+0xA0], xmm11
000078d1a57dd29e  vmovaps [rsp+0xB0], xmm12
000078d1a57dd2a7  vmovaps [rsp+0xC0], xmm13
000078d1a57dd2b0  vmovaps [rsp+0xD0], xmm14
000078d1a57dd2b9  vmovaps [rsp+0xE0], xmm15
000078d1a57dd2c2  sub rsp, 0x30
000078d1a57dd2c6  movaps [rsp], xmm4
000078d1a57dd2ca  movaps [rsp+0x10], xmm9
000078d1a57dd2d0  movaps [rsp+0x20], xmm8
000078d1a57dd2d6  lea rdi, [rsp]
000078d1a57dd2da  mov esi, 0x00
000078d1a57dd2df  mov rax, 0x56EA20A26530
000078d1a57dd2e9  call rax
000078d1a57dd2eb  movaps xmm4, [rsp]
000078d1a57dd2ef  add rsp, 0x30
000078d1a57dd2f3  vmovaps xmm0, [rsp]
000078d1a57dd2f8  vmovaps xmm1, [rsp+0x10]
000078d1a57dd2fe  vmovaps xmm2, [rsp+0x20]
000078d1a57dd304  vmovaps xmm3, [rsp+0x30]
000078d1a57dd30a  vmovaps xmm5, [rsp+0x40]
000078d1a57dd310  vmovaps xmm6, [rsp+0x50]
000078d1a57dd316  vmovaps xmm7, [rsp+0x60]
000078d1a57dd31c  vmovaps xmm8, [rsp+0x70]
000078d1a57dd322  vmovaps xmm9, [rsp+0x80]
000078d1a57dd32b  vmovaps xmm10, [rsp+0x90]
000078d1a57dd334  vmovaps xmm11, [rsp+0xA0]
000078d1a57dd33d  vmovaps xmm12, [rsp+0xB0]
000078d1a57dd346  vmovaps xmm13, [rsp+0xC0]
000078d1a57dd34f  vmovaps xmm14, [rsp+0xD0]
000078d1a57dd358  vmovaps xmm15, [rsp+0xE0]
000078d1a57dd361  add rsp, 0xF0
000078d1a57dd368  pop r11
000078d1a57dd36a  pop r10
000078d1a57dd36c  pop r9
000078d1a57dd36e  pop r8
000078d1a57dd370  pop rsi
000078d1a57dd371  pop rdi
000078d1a57dd372  pop rdx
000078d1a57dd373  pop rcx
000078d1a57dd374  pop rax
000078d1a57dd375  add rsp, 0x08
000078d1a57dd379  jmp 0x000078D1A57DBC94
000078d1a57dd37e  sub rsp, 0x08
000078d1a57dd382  push rax
000078d1a57dd383  push rcx
000078d1a57dd384  push rdx
000078d1a57dd385  push rdi
000078d1a57dd386  push rsi
000078d1a57dd387  push r8
000078d1a57dd389  push r9
000078d1a57dd38b  push r10
000078d1a57dd38d  push r11
000078d1a57dd38f  sub rsp, 0xF0
000078d1a57dd396  vmovaps [rsp], xmm0
000078d1a57dd39b  vmovaps [rsp+0x10], xmm1
000078d1a57dd3a1  vmovaps [rsp+0x20], xmm2
000078d1a57dd3a7  vmovaps [rsp+0x30], xmm3
000078d1a57dd3ad  vmovaps [rsp+0x40], xmm4
000078d1a57dd3b3  vmovaps [rsp+0x50], xmm5
000078d1a57dd3b9  vmovaps [rsp+0x60], xmm6
000078d1a57dd3bf  vmovaps [rsp+0x70], xmm7
000078d1a57dd3c5  vmovaps [rsp+0x80], xmm8
000078d1a57dd3ce  vmovaps [rsp+0x90], xmm10
000078d1a57dd3d7  vmovaps [rsp+0xA0], xmm11
000078d1a57dd3e0  vmovaps [rsp+0xB0], xmm12
000078d1a57dd3e9  vmovaps [rsp+0xC0], xmm13
000078d1a57dd3f2  vmovaps [rsp+0xD0], xmm14
000078d1a57dd3fb  vmovaps [rsp+0xE0], xmm15
000078d1a57dd404  sub rsp, 0x30
000078d1a57dd408  movaps [rsp], xmm9
000078d1a57dd40d  movaps [rsp+0x10], xmm10
000078d1a57dd413  movaps [rsp+0x20], xmm8
000078d1a57dd419  lea rdi, [rsp]
000078d1a57dd41d  mov esi, 0x00
000078d1a57dd422  mov rax, 0x56EA20A26530
000078d1a57dd42c  call rax
000078d1a57dd42e  movaps xmm9, [rsp]
000078d1a57dd433  add rsp, 0x30
000078d1a57dd437  vmovaps xmm0, [rsp]
000078d1a57dd43c  vmovaps xmm1, [rsp+0x10]
000078d1a57dd442  vmovaps xmm2, [rsp+0x20]
000078d1a57dd448  vmovaps xmm3, [rsp+0x30]
000078d1a57dd44e  vmovaps xmm4, [rsp+0x40]
000078d1a57dd454  vmovaps xmm5, [rsp+0x50]
000078d1a57dd45a  vmovaps xmm6, [rsp+0x60]
000078d1a57dd460  vmovaps xmm7, [rsp+0x70]
000078d1a57dd466  vmovaps xmm8, [rsp+0x80]
000078d1a57dd46f  vmovaps xmm10, [rsp+0x90]
000078d1a57dd478  vmovaps xmm11, [rsp+0xA0]
000078d1a57dd481  vmovaps xmm12, [rsp+0xB0]
000078d1a57dd48a  vmovaps xmm13, [rsp+0xC0]
000078d1a57dd493  vmovaps xmm14, [rsp+0xD0]
000078d1a57dd49c  vmovaps xmm15, [rsp+0xE0]
000078d1a57dd4a5  add rsp, 0xF0
000078d1a57dd4ac  pop r11
000078d1a57dd4ae  pop r10
000078d1a57dd4b0  pop r9
000078d1a57dd4b2  pop r8
000078d1a57dd4b4  pop rsi
000078d1a57dd4b5  pop rdi
000078d1a57dd4b6  pop rdx
000078d1a57dd4b7  pop rcx
000078d1a57dd4b8  pop rax
000078d1a57dd4b9  add rsp, 0x08
000078d1a57dd4bd  jmp 0x000078D1A57DBCAE
000078d1a57dd4c2  call 0x000078D1A56B52F0
000078d1a57dd4c7  jmp 0x000078D1A57DBDC8
000078d1a57dd4cc  call 0x000078D1A56B52F0
000078d1a57dd4d1  jmp 0x000078D1A57DBDDE
000078d1a57dd4d6  sub rsp, 0x08
000078d1a57dd4da  push rax
000078d1a57dd4db  push rcx
000078d1a57dd4dc  push rdx
000078d1a57dd4dd  push rdi
000078d1a57dd4de  push rsi
000078d1a57dd4df  push r8
000078d1a57dd4e1  push r9
000078d1a57dd4e3  push r10
000078d1a57dd4e5  push r11
000078d1a57dd4e7  sub rsp, 0xF0
000078d1a57dd4ee  vmovaps [rsp], xmm0
000078d1a57dd4f3  vmovaps [rsp+0x10], xmm2
000078d1a57dd4f9  vmovaps [rsp+0x20], xmm3
000078d1a57dd4ff  vmovaps [rsp+0x30], xmm4
000078d1a57dd505  vmovaps [rsp+0x40], xmm5
000078d1a57dd50b  vmovaps [rsp+0x50], xmm6
000078d1a57dd511  vmovaps [rsp+0x60], xmm7
000078d1a57dd517  vmovaps [rsp+0x70], xmm8
000078d1a57dd51d  vmovaps [rsp+0x80], xmm9
000078d1a57dd526  vmovaps [rsp+0x90], xmm10
000078d1a57dd52f  vmovaps [rsp+0xA0], xmm11
000078d1a57dd538  vmovaps [rsp+0xB0], xmm12
000078d1a57dd541  vmovaps [rsp+0xC0], xmm13
000078d1a57dd54a  vmovaps [rsp+0xD0], xmm14
000078d1a57dd553  vmovaps [rsp+0xE0], xmm15
000078d1a57dd55c  sub rsp, 0x30
000078d1a57dd560  movaps [rsp], xmm1
000078d1a57dd564  movaps [rsp+0x10], xmm6
000078d1a57dd569  movaps [rsp+0x20], xmm15
000078d1a57dd56f  lea rdi, [rsp]
000078d1a57dd573  mov esi, 0x00
000078d1a57dd578  mov rax, 0x56EA20A26530
000078d1a57dd582  call rax
000078d1a57dd584  movaps xmm1, [rsp]
000078d1a57dd588  add rsp, 0x30
000078d1a57dd58c  vmovaps xmm0, [rsp]
000078d1a57dd591  vmovaps xmm2, [rsp+0x10]
000078d1a57dd597  vmovaps xmm3, [rsp+0x20]
000078d1a57dd59d  vmovaps xmm4, [rsp+0x30]
000078d1a57dd5a3  vmovaps xmm5, [rsp+0x40]
000078d1a57dd5a9  vmovaps xmm6, [rsp+0x50]
000078d1a57dd5af  vmovaps xmm7, [rsp+0x60]
000078d1a57dd5b5  vmovaps xmm8, [rsp+0x70]
000078d1a57dd5bb  vmovaps xmm9, [rsp+0x80]
000078d1a57dd5c4  vmovaps xmm10, [rsp+0x90]
000078d1a57dd5cd  vmovaps xmm11, [rsp+0xA0]
000078d1a57dd5d6  vmovaps xmm12, [rsp+0xB0]
000078d1a57dd5df  vmovaps xmm13, [rsp+0xC0]
000078d1a57dd5e8  vmovaps xmm14, [rsp+0xD0]
000078d1a57dd5f1  vmovaps xmm15, [rsp+0xE0]
000078d1a57dd5fa  add rsp, 0xF0
000078d1a57dd601  pop r11
000078d1a57dd603  pop r10
000078d1a57dd605  pop r9
000078d1a57dd607  pop r8
000078d1a57dd609  pop rsi
000078d1a57dd60a  pop rdi
000078d1a57dd60b  pop rdx
000078d1a57dd60c  pop rcx
000078d1a57dd60d  pop rax
000078d1a57dd60e  add rsp, 0x08
000078d1a57dd612  jmp 0x000078D1A57DBE1B
000078d1a57dd617  call 0x000078D1A56C4620
000078d1a57dd61c  jmp 0x000078D1A57DBE28
000078d1a57dd621  sub rsp, 0x08
000078d1a57dd625  push rax
000078d1a57dd626  push rcx
000078d1a57dd627  push rdx
000078d1a57dd628  push rdi
000078d1a57dd629  push rsi
000078d1a57dd62a  push r8
000078d1a57dd62c  push r9
000078d1a57dd62e  push r10
000078d1a57dd630  push r11
000078d1a57dd632  sub rsp, 0xF0
000078d1a57dd639  vmovaps [rsp], xmm0
000078d1a57dd63e  vmovaps [rsp+0x10], xmm1
000078d1a57dd644  vmovaps [rsp+0x20], xmm2
000078d1a57dd64a  vmovaps [rsp+0x30], xmm3
000078d1a57dd650  vmovaps [rsp+0x40], xmm4
000078d1a57dd656  vmovaps [rsp+0x50], xmm5
000078d1a57dd65c  vmovaps [rsp+0x60], xmm6
000078d1a57dd662  vmovaps [rsp+0x70], xmm7
000078d1a57dd668  vmovaps [rsp+0x80], xmm8
000078d1a57dd671  vmovaps [rsp+0x90], xmm9
000078d1a57dd67a  vmovaps [rsp+0xA0], xmm10
000078d1a57dd683  vmovaps [rsp+0xB0], xmm11
000078d1a57dd68c  vmovaps [rsp+0xC0], xmm12
000078d1a57dd695  vmovaps [rsp+0xD0], xmm13
000078d1a57dd69e  vmovaps [rsp+0xE0], xmm15
000078d1a57dd6a7  sub rsp, 0x30
000078d1a57dd6ab  movaps [rsp], xmm14
000078d1a57dd6b0  movaps [rsp+0x10], xmm4
000078d1a57dd6b5  movaps [rsp+0x20], xmm3
000078d1a57dd6ba  lea rdi, [rsp]
000078d1a57dd6be  mov esi, 0x00
000078d1a57dd6c3  mov rax, 0x56EA20A26530
000078d1a57dd6cd  call rax
000078d1a57dd6cf  movaps xmm14, [rsp]
000078d1a57dd6d4  add rsp, 0x30
000078d1a57dd6d8  vmovaps xmm0, [rsp]
000078d1a57dd6dd  vmovaps xmm1, [rsp+0x10]
000078d1a57dd6e3  vmovaps xmm2, [rsp+0x20]
000078d1a57dd6e9  vmovaps xmm3, [rsp+0x30]
000078d1a57dd6ef  vmovaps xmm4, [rsp+0x40]
000078d1a57dd6f5  vmovaps xmm5, [rsp+0x50]
000078d1a57dd6fb  vmovaps xmm6, [rsp+0x60]
000078d1a57dd701  vmovaps xmm7, [rsp+0x70]
000078d1a57dd707  vmovaps xmm8, [rsp+0x80]
000078d1a57dd710  vmovaps xmm9, [rsp+0x90]
000078d1a57dd719  vmovaps xmm10, [rsp+0xA0]
000078d1a57dd722  vmovaps xmm11, [rsp+0xB0]
000078d1a57dd72b  vmovaps xmm12, [rsp+0xC0]
000078d1a57dd734  vmovaps xmm13, [rsp+0xD0]
000078d1a57dd73d  vmovaps xmm15, [rsp+0xE0]
000078d1a57dd746  add rsp, 0xF0
000078d1a57dd74d  pop r11
000078d1a57dd74f  pop r10
000078d1a57dd751  pop r9
000078d1a57dd753  pop r8
000078d1a57dd755  pop rsi
000078d1a57dd756  pop rdi
000078d1a57dd757  pop rdx
000078d1a57dd758  pop rcx
000078d1a57dd759  pop rax
000078d1a57dd75a  add rsp, 0x08
000078d1a57dd75e  jmp 0x000078D1A57DBE42
000078d1a57dd763  sub rsp, 0x08
000078d1a57dd767  push rax
000078d1a57dd768  push rcx
000078d1a57dd769  push rdx
000078d1a57dd76a  push rdi
000078d1a57dd76b  push rsi
000078d1a57dd76c  push r8
000078d1a57dd76e  push r9
000078d1a57dd770  push r10
000078d1a57dd772  push r11
000078d1a57dd774  sub rsp, 0xF0
000078d1a57dd77b  vmovaps [rsp], xmm0
000078d1a57dd780  vmovaps [rsp+0x10], xmm1
000078d1a57dd786  vmovaps [rsp+0x20], xmm2
000078d1a57dd78c  vmovaps [rsp+0x30], xmm3
000078d1a57dd792  vmovaps [rsp+0x40], xmm4
000078d1a57dd798  vmovaps [rsp+0x50], xmm5
000078d1a57dd79e  vmovaps [rsp+0x60], xmm7
000078d1a57dd7a4  vmovaps [rsp+0x70], xmm8
000078d1a57dd7aa  vmovaps [rsp+0x80], xmm9
000078d1a57dd7b3  vmovaps [rsp+0x90], xmm10
000078d1a57dd7bc  vmovaps [rsp+0xA0], xmm11
000078d1a57dd7c5  vmovaps [rsp+0xB0], xmm12
000078d1a57dd7ce  vmovaps [rsp+0xC0], xmm13
000078d1a57dd7d7  vmovaps [rsp+0xD0], xmm14
000078d1a57dd7e0  vmovaps [rsp+0xE0], xmm15
000078d1a57dd7e9  sub rsp, 0x30
000078d1a57dd7ed  movaps [rsp], xmm6
000078d1a57dd7f1  movaps [rsp+0x10], xmm9
000078d1a57dd7f7  movaps [rsp+0x20], xmm7
000078d1a57dd7fc  lea rdi, [rsp]
000078d1a57dd800  mov esi, 0x00
000078d1a57dd805  mov rax, 0x56EA20A26530
000078d1a57dd80f  call rax
000078d1a57dd811  movaps xmm6, [rsp]
000078d1a57dd815  add rsp, 0x30
000078d1a57dd819  vmovaps xmm0, [rsp]
000078d1a57dd81e  vmovaps xmm1, [rsp+0x10]
000078d1a57dd824  vmovaps xmm2, [rsp+0x20]
000078d1a57dd82a  vmovaps xmm3, [rsp+0x30]
000078d1a57dd830  vmovaps xmm4, [rsp+0x40]
000078d1a57dd836  vmovaps xmm5, [rsp+0x50]
000078d1a57dd83c  vmovaps xmm7, [rsp+0x60]
000078d1a57dd842  vmovaps xmm8, [rsp+0x70]
000078d1a57dd848  vmovaps xmm9, [rsp+0x80]
000078d1a57dd851  vmovaps xmm10, [rsp+0x90]
000078d1a57dd85a  vmovaps xmm11, [rsp+0xA0]
000078d1a57dd863  vmovaps xmm12, [rsp+0xB0]
000078d1a57dd86c  vmovaps xmm13, [rsp+0xC0]
000078d1a57dd875  vmovaps xmm14, [rsp+0xD0]
000078d1a57dd87e  vmovaps xmm15, [rsp+0xE0]
000078d1a57dd887  add rsp, 0xF0
000078d1a57dd88e  pop r11
000078d1a57dd890  pop r10
000078d1a57dd892  pop r9
000078d1a57dd894  pop r8
000078d1a57dd896  pop rsi
000078d1a57dd897  pop rdi
000078d1a57dd898  pop rdx
000078d1a57dd899  pop rcx
000078d1a57dd89a  pop rax
000078d1a57dd89b  add rsp, 0x08
000078d1a57dd89f  jmp 0x000078D1A57DBE5A
000078d1a57dd8a4  sub rsp, 0x08
000078d1a57dd8a8  push rax
000078d1a57dd8a9  push rcx
000078d1a57dd8aa  push rdx
000078d1a57dd8ab  push rdi
000078d1a57dd8ac  push rsi
000078d1a57dd8ad  push r8
000078d1a57dd8af  push r9
000078d1a57dd8b1  push r10
000078d1a57dd8b3  push r11
000078d1a57dd8b5  sub rsp, 0xF0
000078d1a57dd8bc  vmovaps [rsp], xmm0
000078d1a57dd8c1  vmovaps [rsp+0x10], xmm1
000078d1a57dd8c7  vmovaps [rsp+0x20], xmm2
000078d1a57dd8cd  vmovaps [rsp+0x30], xmm3
000078d1a57dd8d3  vmovaps [rsp+0x40], xmm4
000078d1a57dd8d9  vmovaps [rsp+0x50], xmm5
000078d1a57dd8df  vmovaps [rsp+0x60], xmm6
000078d1a57dd8e5  vmovaps [rsp+0x70], xmm8
000078d1a57dd8eb  vmovaps [rsp+0x80], xmm9
000078d1a57dd8f4  vmovaps [rsp+0x90], xmm10
000078d1a57dd8fd  vmovaps [rsp+0xA0], xmm11
000078d1a57dd906  vmovaps [rsp+0xB0], xmm12
000078d1a57dd90f  vmovaps [rsp+0xC0], xmm13
000078d1a57dd918  vmovaps [rsp+0xD0], xmm14
000078d1a57dd921  vmovaps [rsp+0xE0], xmm15
000078d1a57dd92a  sub rsp, 0x30
000078d1a57dd92e  movaps [rsp], xmm7
000078d1a57dd932  movaps [rsp+0x10], xmm4
000078d1a57dd937  movaps [rsp+0x20], xmm9
000078d1a57dd93d  lea rdi, [rsp]
000078d1a57dd941  mov esi, 0x00
000078d1a57dd946  mov rax, 0x56EA20A26530
000078d1a57dd950  call rax
000078d1a57dd952  movaps xmm7, [rsp]
000078d1a57dd956  add rsp, 0x30
000078d1a57dd95a  vmovaps xmm0, [rsp]
000078d1a57dd95f  vmovaps xmm1, [rsp+0x10]
000078d1a57dd965  vmovaps xmm2, [rsp+0x20]
000078d1a57dd96b  vmovaps xmm3, [rsp+0x30]
000078d1a57dd971  vmovaps xmm4, [rsp+0x40]
000078d1a57dd977  vmovaps xmm5, [rsp+0x50]
000078d1a57dd97d  vmovaps xmm6, [rsp+0x60]
000078d1a57dd983  vmovaps xmm8, [rsp+0x70]
000078d1a57dd989  vmovaps xmm9, [rsp+0x80]
000078d1a57dd992  vmovaps xmm10, [rsp+0x90]
000078d1a57dd99b  vmovaps xmm11, [rsp+0xA0]
000078d1a57dd9a4  vmovaps xmm12, [rsp+0xB0]
000078d1a57dd9ad  vmovaps xmm13, [rsp+0xC0]
000078d1a57dd9b6  vmovaps xmm14, [rsp+0xD0]
000078d1a57dd9bf  vmovaps xmm15, [rsp+0xE0]
000078d1a57dd9c8  add rsp, 0xF0
000078d1a57dd9cf  pop r11
000078d1a57dd9d1  pop r10
000078d1a57dd9d3  pop r9
000078d1a57dd9d5  pop r8
000078d1a57dd9d7  pop rsi
000078d1a57dd9d8  pop rdi
000078d1a57dd9d9  pop rdx
000078d1a57dd9da  pop rcx
000078d1a57dd9db  pop rax
000078d1a57dd9dc  add rsp, 0x08
000078d1a57dd9e0  jmp 0x000078D1A57DBE87
000078d1a57dd9e5  sub rsp, 0x08
000078d1a57dd9e9  push rax
000078d1a57dd9ea  push rcx
000078d1a57dd9eb  push rdx
000078d1a57dd9ec  push rdi
000078d1a57dd9ed  push rsi
000078d1a57dd9ee  push r8
000078d1a57dd9f0  push r9
000078d1a57dd9f2  push r10
000078d1a57dd9f4  push r11
000078d1a57dd9f6  sub rsp, 0xF0
000078d1a57dd9fd  vmovaps [rsp], xmm0
000078d1a57dda02  vmovaps [rsp+0x10], xmm1
000078d1a57dda08  vmovaps [rsp+0x20], xmm2
000078d1a57dda0e  vmovaps [rsp+0x30], xmm3
000078d1a57dda14  vmovaps [rsp+0x40], xmm5
000078d1a57dda1a  vmovaps [rsp+0x50], xmm6
000078d1a57dda20  vmovaps [rsp+0x60], xmm7
000078d1a57dda26  vmovaps [rsp+0x70], xmm8
000078d1a57dda2c  vmovaps [rsp+0x80], xmm9
000078d1a57dda35  vmovaps [rsp+0x90], xmm10
000078d1a57dda3e  vmovaps [rsp+0xA0], xmm11
000078d1a57dda47  vmovaps [rsp+0xB0], xmm12
000078d1a57dda50  vmovaps [rsp+0xC0], xmm13
000078d1a57dda59  vmovaps [rsp+0xD0], xmm14
000078d1a57dda62  vmovaps [rsp+0xE0], xmm15
000078d1a57dda6b  sub rsp, 0x30
000078d1a57dda6f  movaps [rsp], xmm4
000078d1a57dda73  movaps [rsp+0x10], xmm15
000078d1a57dda79  movaps [rsp+0x20], xmm9
000078d1a57dda7f  lea rdi, [rsp]
000078d1a57dda83  mov esi, 0x00
000078d1a57dda88  mov rax, 0x56EA20A26530
000078d1a57dda92  call rax
000078d1a57dda94  movaps xmm4, [rsp]
000078d1a57dda98  add rsp, 0x30
000078d1a57dda9c  vmovaps xmm0, [rsp]
000078d1a57ddaa1  vmovaps xmm1, [rsp+0x10]
000078d1a57ddaa7  vmovaps xmm2, [rsp+0x20]
000078d1a57ddaad  vmovaps xmm3, [rsp+0x30]
000078d1a57ddab3  vmovaps xmm5, [rsp+0x40]
000078d1a57ddab9  vmovaps xmm6, [rsp+0x50]
000078d1a57ddabf  vmovaps xmm7, [rsp+0x60]
000078d1a57ddac5  vmovaps xmm8, [rsp+0x70]
000078d1a57ddacb  vmovaps xmm9, [rsp+0x80]
000078d1a57ddad4  vmovaps xmm10, [rsp+0x90]
000078d1a57ddadd  vmovaps xmm11, [rsp+0xA0]
000078d1a57ddae6  vmovaps xmm12, [rsp+0xB0]
000078d1a57ddaef  vmovaps xmm13, [rsp+0xC0]
000078d1a57ddaf8  vmovaps xmm14, [rsp+0xD0]
000078d1a57ddb01  vmovaps xmm15, [rsp+0xE0]
000078d1a57ddb0a  add rsp, 0xF0
000078d1a57ddb11  pop r11
000078d1a57ddb13  pop r10
000078d1a57ddb15  pop r9
000078d1a57ddb17  pop r8
000078d1a57ddb19  pop rsi
000078d1a57ddb1a  pop rdi
000078d1a57ddb1b  pop rdx
000078d1a57ddb1c  pop rcx
000078d1a57ddb1d  pop rax
000078d1a57ddb1e  add rsp, 0x08
000078d1a57ddb22  jmp 0x000078D1A57DBEAC
000078d1a57ddb27  call 0x000078D1A56C4620
000078d1a57ddb2c  jmp 0x000078D1A57DBEB9
000078d1a57ddb31  sub rsp, 0x08
000078d1a57ddb35  push rax
000078d1a57ddb36  push rcx
000078d1a57ddb37  push rdx
000078d1a57ddb38  push rdi
000078d1a57ddb39  push rsi
000078d1a57ddb3a  push r8
000078d1a57ddb3c  push r9
000078d1a57ddb3e  push r10
000078d1a57ddb40  push r11
000078d1a57ddb42  sub rsp, 0xF0
000078d1a57ddb49  vmovaps [rsp], xmm0
000078d1a57ddb4e  vmovaps [rsp+0x10], xmm1
000078d1a57ddb54  vmovaps [rsp+0x20], xmm2
000078d1a57ddb5a  vmovaps [rsp+0x30], xmm4
000078d1a57ddb60  vmovaps [rsp+0x40], xmm5
000078d1a57ddb66  vmovaps [rsp+0x50], xmm6
000078d1a57ddb6c  vmovaps [rsp+0x60], xmm7
000078d1a57ddb72  vmovaps [rsp+0x70], xmm8
000078d1a57ddb78  vmovaps [rsp+0x80], xmm9
000078d1a57ddb81  vmovaps [rsp+0x90], xmm10
000078d1a57ddb8a  vmovaps [rsp+0xA0], xmm11
000078d1a57ddb93  vmovaps [rsp+0xB0], xmm12
000078d1a57ddb9c  vmovaps [rsp+0xC0], xmm13
000078d1a57ddba5  vmovaps [rsp+0xD0], xmm14
000078d1a57ddbae  vmovaps [rsp+0xE0], xmm15
000078d1a57ddbb7  sub rsp, 0x30
000078d1a57ddbbb  movaps [rsp], xmm3
000078d1a57ddbbf  movaps [rsp+0x10], xmm1
000078d1a57ddbc4  movaps [rsp+0x20], xmm9
000078d1a57ddbca  lea rdi, [rsp]
000078d1a57ddbce  mov esi, 0x00
000078d1a57ddbd3  mov rax, 0x56EA20A26530
000078d1a57ddbdd  call rax
000078d1a57ddbdf  movaps xmm3, [rsp]
000078d1a57ddbe3  add rsp, 0x30
000078d1a57ddbe7  vmovaps xmm0, [rsp]
000078d1a57ddbec  vmovaps xmm1, [rsp+0x10]
000078d1a57ddbf2  vmovaps xmm2, [rsp+0x20]
000078d1a57ddbf8  vmovaps xmm4, [rsp+0x30]
000078d1a57ddbfe  vmovaps xmm5, [rsp+0x40]
000078d1a57ddc04  vmovaps xmm6, [rsp+0x50]
000078d1a57ddc0a  vmovaps xmm7, [rsp+0x60]
000078d1a57ddc10  vmovaps xmm8, [rsp+0x70]
000078d1a57ddc16  vmovaps xmm9, [rsp+0x80]
000078d1a57ddc1f  vmovaps xmm10, [rsp+0x90]
000078d1a57ddc28  vmovaps xmm11, [rsp+0xA0]
000078d1a57ddc31  vmovaps xmm12, [rsp+0xB0]
000078d1a57ddc3a  vmovaps xmm13, [rsp+0xC0]
000078d1a57ddc43  vmovaps xmm14, [rsp+0xD0]
000078d1a57ddc4c  vmovaps xmm15, [rsp+0xE0]
000078d1a57ddc55  add rsp, 0xF0
000078d1a57ddc5c  pop r11
000078d1a57ddc5e  pop r10
000078d1a57ddc60  pop r9
000078d1a57ddc62  pop r8
000078d1a57ddc64  pop rsi
000078d1a57ddc65  pop rdi
000078d1a57ddc66  pop rdx
000078d1a57ddc67  pop rcx
000078d1a57ddc68  pop rax
000078d1a57ddc69  add rsp, 0x08
000078d1a57ddc6d  jmp 0x000078D1A57DBEF6
000078d1a57ddc72  sub rsp, 0x08
000078d1a57ddc76  push rax
000078d1a57ddc77  push rcx
000078d1a57ddc78  push rdx
000078d1a57ddc79  push rdi
000078d1a57ddc7a  push rsi
000078d1a57ddc7b  push r8
000078d1a57ddc7d  push r9
000078d1a57ddc7f  push r10
000078d1a57ddc81  push r11
000078d1a57ddc83  sub rsp, 0xF0
000078d1a57ddc8a  vmovaps [rsp], xmm0
000078d1a57ddc8f  vmovaps [rsp+0x10], xmm2
000078d1a57ddc95  vmovaps [rsp+0x20], xmm3
000078d1a57ddc9b  vmovaps [rsp+0x30], xmm4
000078d1a57ddca1  vmovaps [rsp+0x40], xmm5
000078d1a57ddca7  vmovaps [rsp+0x50], xmm6
000078d1a57ddcad  vmovaps [rsp+0x60], xmm7
000078d1a57ddcb3  vmovaps [rsp+0x70], xmm8
000078d1a57ddcb9  vmovaps [rsp+0x80], xmm9
000078d1a57ddcc2  vmovaps [rsp+0x90], xmm10
000078d1a57ddccb  vmovaps [rsp+0xA0], xmm11
000078d1a57ddcd4  vmovaps [rsp+0xB0], xmm12
000078d1a57ddcdd  vmovaps [rsp+0xC0], xmm13
000078d1a57ddce6  vmovaps [rsp+0xD0], xmm14
000078d1a57ddcef  vmovaps [rsp+0xE0], xmm15
000078d1a57ddcf8  sub rsp, 0x30
000078d1a57ddcfc  movaps [rsp], xmm1
000078d1a57ddd00  movaps [rsp+0x10], xmm15
000078d1a57ddd06  movaps [rsp+0x20], xmm9
000078d1a57ddd0c  lea rdi, [rsp]
000078d1a57ddd10  mov esi, 0x00
000078d1a57ddd15  mov rax, 0x56EA20A26530
000078d1a57ddd1f  call rax
000078d1a57ddd21  movaps xmm1, [rsp]
000078d1a57ddd25  add rsp, 0x30
000078d1a57ddd29  vmovaps xmm0, [rsp]
000078d1a57ddd2e  vmovaps xmm2, [rsp+0x10]
000078d1a57ddd34  vmovaps xmm3, [rsp+0x20]
000078d1a57ddd3a  vmovaps xmm4, [rsp+0x30]
000078d1a57ddd40  vmovaps xmm5, [rsp+0x40]
000078d1a57ddd46  vmovaps xmm6, [rsp+0x50]
000078d1a57ddd4c  vmovaps xmm7, [rsp+0x60]
000078d1a57ddd52  vmovaps xmm8, [rsp+0x70]
000078d1a57ddd58  vmovaps xmm9, [rsp+0x80]
000078d1a57ddd61  vmovaps xmm10, [rsp+0x90]
000078d1a57ddd6a  vmovaps xmm11, [rsp+0xA0]
000078d1a57ddd73  vmovaps xmm12, [rsp+0xB0]
000078d1a57ddd7c  vmovaps xmm13, [rsp+0xC0]
000078d1a57ddd85  vmovaps xmm14, [rsp+0xD0]
000078d1a57ddd8e  vmovaps xmm15, [rsp+0xE0]
000078d1a57ddd97  add rsp, 0xF0
000078d1a57ddd9e  pop r11
000078d1a57ddda0  pop r10
000078d1a57ddda2  pop r9
000078d1a57ddda4  pop r8
000078d1a57ddda6  pop rsi
000078d1a57ddda7  pop rdi
000078d1a57ddda8  pop rdx
000078d1a57ddda9  pop rcx
000078d1a57dddaa  pop rax
000078d1a57dddab  add rsp, 0x08
000078d1a57dddaf  jmp 0x000078D1A57DBF7E
000078d1a57dddb4  call 0x000078D1A56C4620
000078d1a57dddb9  jmp 0x000078D1A57DBF8B
000078d1a57dddbe  sub rsp, 0x08
000078d1a57dddc2  push rax
000078d1a57dddc3  push rcx
000078d1a57dddc4  push rdx
000078d1a57dddc5  push rdi
000078d1a57dddc6  push rsi
000078d1a57dddc7  push r8
000078d1a57dddc9  push r9
000078d1a57dddcb  push r10
000078d1a57dddcd  push r11
000078d1a57dddcf  sub rsp, 0xF0
000078d1a57dddd6  vmovaps [rsp], xmm0
000078d1a57ddddb  vmovaps [rsp+0x10], xmm2
000078d1a57ddde1  vmovaps [rsp+0x20], xmm3
000078d1a57ddde7  vmovaps [rsp+0x30], xmm4
000078d1a57ddded  vmovaps [rsp+0x40], xmm5
000078d1a57dddf3  vmovaps [rsp+0x50], xmm6
000078d1a57dddf9  vmovaps [rsp+0x60], xmm7
000078d1a57dddff  vmovaps [rsp+0x70], xmm8
000078d1a57dde05  vmovaps [rsp+0x80], xmm9
000078d1a57dde0e  vmovaps [rsp+0x90], xmm10
000078d1a57dde17  vmovaps [rsp+0xA0], xmm11
000078d1a57dde20  vmovaps [rsp+0xB0], xmm12
000078d1a57dde29  vmovaps [rsp+0xC0], xmm13
000078d1a57dde32  vmovaps [rsp+0xD0], xmm14
000078d1a57dde3b  vmovaps [rsp+0xE0], xmm15
000078d1a57dde44  sub rsp, 0x30
000078d1a57dde48  movaps [rsp], xmm1
000078d1a57dde4c  movaps [rsp+0x10], xmm5
000078d1a57dde51  movaps [rsp+0x20], xmm7
000078d1a57dde56  lea rdi, [rsp]
000078d1a57dde5a  mov esi, 0x00
000078d1a57dde5f  mov rax, 0x56EA20A26530
000078d1a57dde69  call rax
000078d1a57dde6b  movaps xmm1, [rsp]
000078d1a57dde6f  add rsp, 0x30
000078d1a57dde73  vmovaps xmm0, [rsp]
000078d1a57dde78  vmovaps xmm2, [rsp+0x10]
000078d1a57dde7e  vmovaps xmm3, [rsp+0x20]
000078d1a57dde84  vmovaps xmm4, [rsp+0x30]
000078d1a57dde8a  vmovaps xmm5, [rsp+0x40]
000078d1a57dde90  vmovaps xmm6, [rsp+0x50]
000078d1a57dde96  vmovaps xmm7, [rsp+0x60]
000078d1a57dde9c  vmovaps xmm8, [rsp+0x70]
000078d1a57ddea2  vmovaps xmm9, [rsp+0x80]
000078d1a57ddeab  vmovaps xmm10, [rsp+0x90]
000078d1a57ddeb4  vmovaps xmm11, [rsp+0xA0]
000078d1a57ddebd  vmovaps xmm12, [rsp+0xB0]
000078d1a57ddec6  vmovaps xmm13, [rsp+0xC0]
000078d1a57ddecf  vmovaps xmm14, [rsp+0xD0]
000078d1a57dded8  vmovaps xmm15, [rsp+0xE0]
000078d1a57ddee1  add rsp, 0xF0
000078d1a57ddee8  pop r11
000078d1a57ddeea  pop r10
000078d1a57ddeec  pop r9
000078d1a57ddeee  pop r8
000078d1a57ddef0  pop rsi
000078d1a57ddef1  pop rdi
000078d1a57ddef2  pop rdx
000078d1a57ddef3  pop rcx
000078d1a57ddef4  pop rax
000078d1a57ddef5  add rsp, 0x08
000078d1a57ddef9  jmp 0x000078D1A57DC030
000078d1a57ddefe  sub rsp, 0x08
000078d1a57ddf02  push rax
000078d1a57ddf03  push rcx
000078d1a57ddf04  push rdx
000078d1a57ddf05  push rdi
000078d1a57ddf06  push rsi
000078d1a57ddf07  push r8
000078d1a57ddf09  push r9
000078d1a57ddf0b  push r10
000078d1a57ddf0d  push r11
000078d1a57ddf0f  sub rsp, 0xF0
000078d1a57ddf16  vmovaps [rsp], xmm0
000078d1a57ddf1b  vmovaps [rsp+0x10], xmm1
000078d1a57ddf21  vmovaps [rsp+0x20], xmm2
000078d1a57ddf27  vmovaps [rsp+0x30], xmm3
000078d1a57ddf2d  vmovaps [rsp+0x40], xmm4
000078d1a57ddf33  vmovaps [rsp+0x50], xmm5
000078d1a57ddf39  vmovaps [rsp+0x60], xmm6
000078d1a57ddf3f  vmovaps [rsp+0x70], xmm8
000078d1a57ddf45  vmovaps [rsp+0x80], xmm9
000078d1a57ddf4e  vmovaps [rsp+0x90], xmm10
000078d1a57ddf57  vmovaps [rsp+0xA0], xmm11
000078d1a57ddf60  vmovaps [rsp+0xB0], xmm12
000078d1a57ddf69  vmovaps [rsp+0xC0], xmm13
000078d1a57ddf72  vmovaps [rsp+0xD0], xmm14
000078d1a57ddf7b  vmovaps [rsp+0xE0], xmm15
000078d1a57ddf84  sub rsp, 0x30
000078d1a57ddf88  movaps [rsp], xmm7
000078d1a57ddf8c  movaps [rsp+0x10], xmm5
000078d1a57ddf91  movaps [rsp+0x20], xmm15
000078d1a57ddf97  lea rdi, [rsp]
000078d1a57ddf9b  mov esi, 0x00
000078d1a57ddfa0  mov rax, 0x56EA20A26530
000078d1a57ddfaa  call rax
000078d1a57ddfac  movaps xmm7, [rsp]
000078d1a57ddfb0  add rsp, 0x30
000078d1a57ddfb4  vmovaps xmm0, [rsp]
000078d1a57ddfb9  vmovaps xmm1, [rsp+0x10]
000078d1a57ddfbf  vmovaps xmm2, [rsp+0x20]
000078d1a57ddfc5  vmovaps xmm3, [rsp+0x30]
000078d1a57ddfcb  vmovaps xmm4, [rsp+0x40]
000078d1a57ddfd1  vmovaps xmm5, [rsp+0x50]
000078d1a57ddfd7  vmovaps xmm6, [rsp+0x60]
000078d1a57ddfdd  vmovaps xmm8, [rsp+0x70]
000078d1a57ddfe3  vmovaps xmm9, [rsp+0x80]
000078d1a57ddfec  vmovaps xmm10, [rsp+0x90]
000078d1a57ddff5  vmovaps xmm11, [rsp+0xA0]
000078d1a57ddffe  vmovaps xmm12, [rsp+0xB0]
000078d1a57de007  vmovaps xmm13, [rsp+0xC0]
000078d1a57de010  vmovaps xmm14, [rsp+0xD0]
000078d1a57de019  vmovaps xmm15, [rsp+0xE0]
000078d1a57de022  add rsp, 0xF0
000078d1a57de029  pop r11
000078d1a57de02b  pop r10
000078d1a57de02d  pop r9
000078d1a57de02f  pop r8
000078d1a57de031  pop rsi
000078d1a57de032  pop rdi
000078d1a57de033  pop rdx
000078d1a57de034  pop rcx
000078d1a57de035  pop rax
000078d1a57de036  add rsp, 0x08
000078d1a57de03a  jmp 0x000078D1A57DC066
000078d1a57de03f  call 0x000078D1A56B52F0
000078d1a57de044  jmp 0x000078D1A57DC073
000078d1a57de049  sub rsp, 0x08
000078d1a57de04d  push rax
000078d1a57de04e  push rcx
000078d1a57de04f  push rdx
000078d1a57de050  push rdi
000078d1a57de051  push rsi
000078d1a57de052  push r8
000078d1a57de054  push r9
000078d1a57de056  push r10
000078d1a57de058  push r11
000078d1a57de05a  sub rsp, 0xF0
000078d1a57de061  vmovaps [rsp], xmm0
000078d1a57de066  vmovaps [rsp+0x10], xmm1
000078d1a57de06c  vmovaps [rsp+0x20], xmm2
000078d1a57de072  vmovaps [rsp+0x30], xmm3
000078d1a57de078  vmovaps [rsp+0x40], xmm4
000078d1a57de07e  vmovaps [rsp+0x50], xmm5
000078d1a57de084  vmovaps [rsp+0x60], xmm6
000078d1a57de08a  vmovaps [rsp+0x70], xmm7
000078d1a57de090  vmovaps [rsp+0x80], xmm8
000078d1a57de099  vmovaps [rsp+0x90], xmm9
000078d1a57de0a2  vmovaps [rsp+0xA0], xmm10
000078d1a57de0ab  vmovaps [rsp+0xB0], xmm11
000078d1a57de0b4  vmovaps [rsp+0xC0], xmm12
000078d1a57de0bd  vmovaps [rsp+0xD0], xmm13
000078d1a57de0c6  vmovaps [rsp+0xE0], xmm14
000078d1a57de0cf  sub rsp, 0x30
000078d1a57de0d3  movaps [rsp], xmm15
000078d1a57de0d8  movaps [rsp+0x10], xmm5
000078d1a57de0dd  movaps [rsp+0x20], xmm3
000078d1a57de0e2  lea rdi, [rsp]
000078d1a57de0e6  mov esi, 0x00
000078d1a57de0eb  mov rax, 0x56EA20A26530
000078d1a57de0f5  call rax
000078d1a57de0f7  movaps xmm15, [rsp]
000078d1a57de0fc  add rsp, 0x30
000078d1a57de100  vmovaps xmm0, [rsp]
000078d1a57de105  vmovaps xmm1, [rsp+0x10]
000078d1a57de10b  vmovaps xmm2, [rsp+0x20]
000078d1a57de111  vmovaps xmm3, [rsp+0x30]
000078d1a57de117  vmovaps xmm4, [rsp+0x40]
000078d1a57de11d  vmovaps xmm5, [rsp+0x50]
000078d1a57de123  vmovaps xmm6, [rsp+0x60]
000078d1a57de129  vmovaps xmm7, [rsp+0x70]
000078d1a57de12f  vmovaps xmm8, [rsp+0x80]
000078d1a57de138  vmovaps xmm9, [rsp+0x90]
000078d1a57de141  vmovaps xmm10, [rsp+0xA0]
000078d1a57de14a  vmovaps xmm11, [rsp+0xB0]
000078d1a57de153  vmovaps xmm12, [rsp+0xC0]
000078d1a57de15c  vmovaps xmm13, [rsp+0xD0]
000078d1a57de165  vmovaps xmm14, [rsp+0xE0]
000078d1a57de16e  add rsp, 0xF0
000078d1a57de175  pop r11
000078d1a57de177  pop r10
000078d1a57de179  pop r9
000078d1a57de17b  pop r8
000078d1a57de17d  pop rsi
000078d1a57de17e  pop rdi
000078d1a57de17f  pop rdx
000078d1a57de180  pop rcx
000078d1a57de181  pop rax
000078d1a57de182  add rsp, 0x08
000078d1a57de186  jmp 0x000078D1A57DC099
000078d1a57de18b  sub rsp, 0x08
000078d1a57de18f  push rax
000078d1a57de190  push rcx
000078d1a57de191  push rdx
000078d1a57de192  push rdi
000078d1a57de193  push rsi
000078d1a57de194  push r8
000078d1a57de196  push r9
000078d1a57de198  push r10
000078d1a57de19a  push r11
000078d1a57de19c  sub rsp, 0xF0
000078d1a57de1a3  vmovaps [rsp], xmm0
000078d1a57de1a8  vmovaps [rsp+0x10], xmm2
000078d1a57de1ae  vmovaps [rsp+0x20], xmm3
000078d1a57de1b4  vmovaps [rsp+0x30], xmm4
000078d1a57de1ba  vmovaps [rsp+0x40], xmm5
000078d1a57de1c0  vmovaps [rsp+0x50], xmm6
000078d1a57de1c6  vmovaps [rsp+0x60], xmm7
000078d1a57de1cc  vmovaps [rsp+0x70], xmm8
000078d1a57de1d2  vmovaps [rsp+0x80], xmm9
000078d1a57de1db  vmovaps [rsp+0x90], xmm10
000078d1a57de1e4  vmovaps [rsp+0xA0], xmm11
000078d1a57de1ed  vmovaps [rsp+0xB0], xmm12
000078d1a57de1f6  vmovaps [rsp+0xC0], xmm13
000078d1a57de1ff  vmovaps [rsp+0xD0], xmm14
000078d1a57de208  vmovaps [rsp+0xE0], xmm15
000078d1a57de211  sub rsp, 0x30
000078d1a57de215  movaps [rsp], xmm1
000078d1a57de219  movaps [rsp+0x10], xmm5
000078d1a57de21e  movaps [rsp+0x20], xmm4
000078d1a57de223  lea rdi, [rsp]
000078d1a57de227  mov esi, 0x00
000078d1a57de22c  mov rax, 0x56EA20A26530
000078d1a57de236  call rax
000078d1a57de238  movaps xmm1, [rsp]
000078d1a57de23c  add rsp, 0x30
000078d1a57de240  vmovaps xmm0, [rsp]
000078d1a57de245  vmovaps xmm2, [rsp+0x10]
000078d1a57de24b  vmovaps xmm3, [rsp+0x20]
000078d1a57de251  vmovaps xmm4, [rsp+0x30]
000078d1a57de257  vmovaps xmm5, [rsp+0x40]
000078d1a57de25d  vmovaps xmm6, [rsp+0x50]
000078d1a57de263  vmovaps xmm7, [rsp+0x60]
000078d1a57de269  vmovaps xmm8, [rsp+0x70]
000078d1a57de26f  vmovaps xmm9, [rsp+0x80]
000078d1a57de278  vmovaps xmm10, [rsp+0x90]
000078d1a57de281  vmovaps xmm11, [rsp+0xA0]
000078d1a57de28a  vmovaps xmm12, [rsp+0xB0]
000078d1a57de293  vmovaps xmm13, [rsp+0xC0]
000078d1a57de29c  vmovaps xmm14, [rsp+0xD0]
000078d1a57de2a5  vmovaps xmm15, [rsp+0xE0]
000078d1a57de2ae  add rsp, 0xF0
000078d1a57de2b5  pop r11
000078d1a57de2b7  pop r10
000078d1a57de2b9  pop r9
000078d1a57de2bb  pop r8
000078d1a57de2bd  pop rsi
000078d1a57de2be  pop rdi
000078d1a57de2bf  pop rdx
000078d1a57de2c0  pop rcx
000078d1a57de2c1  pop rax
000078d1a57de2c2  add rsp, 0x08
000078d1a57de2c6  jmp 0x000078D1A57DC0B9
000078d1a57de2cb  sub rsp, 0x08
000078d1a57de2cf  push rax
000078d1a57de2d0  push rcx
000078d1a57de2d1  push rdx
000078d1a57de2d2  push rdi
000078d1a57de2d3  push rsi
000078d1a57de2d4  push r8
000078d1a57de2d6  push r9
000078d1a57de2d8  push r10
000078d1a57de2da  push r11
000078d1a57de2dc  sub rsp, 0xF0
000078d1a57de2e3  vmovaps [rsp], xmm0
000078d1a57de2e8  vmovaps [rsp+0x10], xmm1
000078d1a57de2ee  vmovaps [rsp+0x20], xmm2
000078d1a57de2f4  vmovaps [rsp+0x30], xmm3
000078d1a57de2fa  vmovaps [rsp+0x40], xmm5
000078d1a57de300  vmovaps [rsp+0x50], xmm6
000078d1a57de306  vmovaps [rsp+0x60], xmm7
000078d1a57de30c  vmovaps [rsp+0x70], xmm8
000078d1a57de312  vmovaps [rsp+0x80], xmm9
000078d1a57de31b  vmovaps [rsp+0x90], xmm10
000078d1a57de324  vmovaps [rsp+0xA0], xmm11
000078d1a57de32d  vmovaps [rsp+0xB0], xmm12
000078d1a57de336  vmovaps [rsp+0xC0], xmm13
000078d1a57de33f  vmovaps [rsp+0xD0], xmm14
000078d1a57de348  vmovaps [rsp+0xE0], xmm15
000078d1a57de351  sub rsp, 0x30
000078d1a57de355  movaps [rsp], xmm4
000078d1a57de359  movaps [rsp+0x10], xmm3
000078d1a57de35e  movaps [rsp+0x20], xmm5
000078d1a57de363  lea rdi, [rsp]
000078d1a57de367  mov esi, 0x00
000078d1a57de36c  mov rax, 0x56EA20A26530
000078d1a57de376  call rax
000078d1a57de378  movaps xmm4, [rsp]
000078d1a57de37c  add rsp, 0x30
000078d1a57de380  vmovaps xmm0, [rsp]
000078d1a57de385  vmovaps xmm1, [rsp+0x10]
000078d1a57de38b  vmovaps xmm2, [rsp+0x20]
000078d1a57de391  vmovaps xmm3, [rsp+0x30]
000078d1a57de397  vmovaps xmm5, [rsp+0x40]
000078d1a57de39d  vmovaps xmm6, [rsp+0x50]
000078d1a57de3a3  vmovaps xmm7, [rsp+0x60]
000078d1a57de3a9  vmovaps xmm8, [rsp+0x70]
000078d1a57de3af  vmovaps xmm9, [rsp+0x80]
000078d1a57de3b8  vmovaps xmm10, [rsp+0x90]
000078d1a57de3c1  vmovaps xmm11, [rsp+0xA0]
000078d1a57de3ca  vmovaps xmm12, [rsp+0xB0]
000078d1a57de3d3  vmovaps xmm13, [rsp+0xC0]
000078d1a57de3dc  vmovaps xmm14, [rsp+0xD0]
000078d1a57de3e5  vmovaps xmm15, [rsp+0xE0]
000078d1a57de3ee  add rsp, 0xF0
000078d1a57de3f5  pop r11
000078d1a57de3f7  pop r10
000078d1a57de3f9  pop r9
000078d1a57de3fb  pop r8
000078d1a57de3fd  pop rsi
000078d1a57de3fe  pop rdi
000078d1a57de3ff  pop rdx
000078d1a57de400  pop rcx
000078d1a57de401  pop rax
000078d1a57de402  add rsp, 0x08
000078d1a57de406  jmp 0x000078D1A57DC107
000078d1a57de40b  call 0x000078D1A56B52F0
000078d1a57de410  jmp 0x000078D1A57DC114
000078d1a57de415  sub rsp, 0x08
000078d1a57de419  push rax
000078d1a57de41a  push rcx
000078d1a57de41b  push rdx
000078d1a57de41c  push rdi
000078d1a57de41d  push rsi
000078d1a57de41e  push r8
000078d1a57de420  push r9
000078d1a57de422  push r10
000078d1a57de424  push r11
000078d1a57de426  sub rsp, 0xF0
000078d1a57de42d  vmovaps [rsp], xmm0
000078d1a57de432  vmovaps [rsp+0x10], xmm1
000078d1a57de438  vmovaps [rsp+0x20], xmm2
000078d1a57de43e  vmovaps [rsp+0x30], xmm3
000078d1a57de444  vmovaps [rsp+0x40], xmm4
000078d1a57de44a  vmovaps [rsp+0x50], xmm6
000078d1a57de450  vmovaps [rsp+0x60], xmm7
000078d1a57de456  vmovaps [rsp+0x70], xmm8
000078d1a57de45c  vmovaps [rsp+0x80], xmm9
000078d1a57de465  vmovaps [rsp+0x90], xmm10
000078d1a57de46e  vmovaps [rsp+0xA0], xmm11
000078d1a57de477  vmovaps [rsp+0xB0], xmm12
000078d1a57de480  vmovaps [rsp+0xC0], xmm13
000078d1a57de489  vmovaps [rsp+0xD0], xmm14
000078d1a57de492  vmovaps [rsp+0xE0], xmm15
000078d1a57de49b  sub rsp, 0x30
000078d1a57de49f  movaps [rsp], xmm5
000078d1a57de4a3  movaps [rsp+0x10], xmm6
000078d1a57de4a8  movaps [rsp+0x20], xmm3
000078d1a57de4ad  lea rdi, [rsp]
000078d1a57de4b1  mov esi, 0x00
000078d1a57de4b6  mov rax, 0x56EA20A26530
000078d1a57de4c0  call rax
000078d1a57de4c2  movaps xmm5, [rsp]
000078d1a57de4c6  add rsp, 0x30
000078d1a57de4ca  vmovaps xmm0, [rsp]
000078d1a57de4cf  vmovaps xmm1, [rsp+0x10]
000078d1a57de4d5  vmovaps xmm2, [rsp+0x20]
000078d1a57de4db  vmovaps xmm3, [rsp+0x30]
000078d1a57de4e1  vmovaps xmm4, [rsp+0x40]
000078d1a57de4e7  vmovaps xmm6, [rsp+0x50]
000078d1a57de4ed  vmovaps xmm7, [rsp+0x60]
000078d1a57de4f3  vmovaps xmm8, [rsp+0x70]
000078d1a57de4f9  vmovaps xmm9, [rsp+0x80]
000078d1a57de502  vmovaps xmm10, [rsp+0x90]
000078d1a57de50b  vmovaps xmm11, [rsp+0xA0]
000078d1a57de514  vmovaps xmm12, [rsp+0xB0]
000078d1a57de51d  vmovaps xmm13, [rsp+0xC0]
000078d1a57de526  vmovaps xmm14, [rsp+0xD0]
000078d1a57de52f  vmovaps xmm15, [rsp+0xE0]
000078d1a57de538  add rsp, 0xF0
000078d1a57de53f  pop r11
000078d1a57de541  pop r10
000078d1a57de543  pop r9
000078d1a57de545  pop r8
000078d1a57de547  pop rsi
000078d1a57de548  pop rdi
000078d1a57de549  pop rdx
000078d1a57de54a  pop rcx
000078d1a57de54b  pop rax
000078d1a57de54c  add rsp, 0x08
000078d1a57de550  jmp 0x000078D1A57DC13A
000078d1a57de555  sub rsp, 0x08
000078d1a57de559  push rax
000078d1a57de55a  push rcx
000078d1a57de55b  push rdx
000078d1a57de55c  push rdi
000078d1a57de55d  push rsi
000078d1a57de55e  push r8
000078d1a57de560  push r9
000078d1a57de562  push r10
000078d1a57de564  push r11
000078d1a57de566  sub rsp, 0xF0
000078d1a57de56d  vmovaps [rsp], xmm0
000078d1a57de572  vmovaps [rsp+0x10], xmm1
000078d1a57de578  vmovaps [rsp+0x20], xmm2
000078d1a57de57e  vmovaps [rsp+0x30], xmm3
000078d1a57de584  vmovaps [rsp+0x40], xmm4
000078d1a57de58a  vmovaps [rsp+0x50], xmm5
000078d1a57de590  vmovaps [rsp+0x60], xmm7
000078d1a57de596  vmovaps [rsp+0x70], xmm8
000078d1a57de59c  vmovaps [rsp+0x80], xmm9
000078d1a57de5a5  vmovaps [rsp+0x90], xmm10
000078d1a57de5ae  vmovaps [rsp+0xA0], xmm11
000078d1a57de5b7  vmovaps [rsp+0xB0], xmm12
000078d1a57de5c0  vmovaps [rsp+0xC0], xmm13
000078d1a57de5c9  vmovaps [rsp+0xD0], xmm14
000078d1a57de5d2  vmovaps [rsp+0xE0], xmm15
000078d1a57de5db  sub rsp, 0x30
000078d1a57de5df  movaps [rsp], xmm6
000078d1a57de5e3  movaps [rsp+0x10], xmm9
000078d1a57de5e9  movaps [rsp+0x20], xmm1
000078d1a57de5ee  lea rdi, [rsp]
000078d1a57de5f2  mov esi, 0x00
000078d1a57de5f7  mov rax, 0x56EA20A26530
000078d1a57de601  call rax
000078d1a57de603  movaps xmm6, [rsp]
000078d1a57de607  add rsp, 0x30
000078d1a57de60b  vmovaps xmm0, [rsp]
000078d1a57de610  vmovaps xmm1, [rsp+0x10]
000078d1a57de616  vmovaps xmm2, [rsp+0x20]
000078d1a57de61c  vmovaps xmm3, [rsp+0x30]
000078d1a57de622  vmovaps xmm4, [rsp+0x40]
000078d1a57de628  vmovaps xmm5, [rsp+0x50]
000078d1a57de62e  vmovaps xmm7, [rsp+0x60]
000078d1a57de634  vmovaps xmm8, [rsp+0x70]
000078d1a57de63a  vmovaps xmm9, [rsp+0x80]
000078d1a57de643  vmovaps xmm10, [rsp+0x90]
000078d1a57de64c  vmovaps xmm11, [rsp+0xA0]
000078d1a57de655  vmovaps xmm12, [rsp+0xB0]
000078d1a57de65e  vmovaps xmm13, [rsp+0xC0]
000078d1a57de667  vmovaps xmm14, [rsp+0xD0]
000078d1a57de670  vmovaps xmm15, [rsp+0xE0]
000078d1a57de679  add rsp, 0xF0
000078d1a57de680  pop r11
000078d1a57de682  pop r10
000078d1a57de684  pop r9
000078d1a57de686  pop r8
000078d1a57de688  pop rsi
000078d1a57de689  pop rdi
000078d1a57de68a  pop rdx
000078d1a57de68b  pop rcx
000078d1a57de68c  pop rax
000078d1a57de68d  add rsp, 0x08
000078d1a57de691  jmp 0x000078D1A57DC15E
000078d1a57de696  sub rsp, 0x08
000078d1a57de69a  push rax
000078d1a57de69b  push rcx
000078d1a57de69c  push rdx
000078d1a57de69d  push rdi
000078d1a57de69e  push rsi
000078d1a57de69f  push r8
000078d1a57de6a1  push r9
000078d1a57de6a3  push r10
000078d1a57de6a5  push r11
000078d1a57de6a7  sub rsp, 0xF0
000078d1a57de6ae  vmovaps [rsp], xmm0
000078d1a57de6b3  vmovaps [rsp+0x10], xmm1
000078d1a57de6b9  vmovaps [rsp+0x20], xmm2
000078d1a57de6bf  vmovaps [rsp+0x30], xmm3
000078d1a57de6c5  vmovaps [rsp+0x40], xmm4
000078d1a57de6cb  vmovaps [rsp+0x50], xmm5
000078d1a57de6d1  vmovaps [rsp+0x60], xmm6
000078d1a57de6d7  vmovaps [rsp+0x70], xmm7
000078d1a57de6dd  vmovaps [rsp+0x80], xmm8
000078d1a57de6e6  vmovaps [rsp+0x90], xmm10
000078d1a57de6ef  vmovaps [rsp+0xA0], xmm11
000078d1a57de6f8  vmovaps [rsp+0xB0], xmm12
000078d1a57de701  vmovaps [rsp+0xC0], xmm13
000078d1a57de70a  vmovaps [rsp+0xD0], xmm14
000078d1a57de713  vmovaps [rsp+0xE0], xmm15
000078d1a57de71c  sub rsp, 0x30
000078d1a57de720  movaps [rsp], xmm9
000078d1a57de725  movaps [rsp+0x10], xmm3
000078d1a57de72a  movaps [rsp+0x20], xmm1
000078d1a57de72f  lea rdi, [rsp]
000078d1a57de733  mov esi, 0x00
000078d1a57de738  mov rax, 0x56EA20A26530
000078d1a57de742  call rax
000078d1a57de744  movaps xmm9, [rsp]
000078d1a57de749  add rsp, 0x30
000078d1a57de74d  vmovaps xmm0, [rsp]
000078d1a57de752  vmovaps xmm1, [rsp+0x10]
000078d1a57de758  vmovaps xmm2, [rsp+0x20]
000078d1a57de75e  vmovaps xmm3, [rsp+0x30]
000078d1a57de764  vmovaps xmm4, [rsp+0x40]
000078d1a57de76a  vmovaps xmm5, [rsp+0x50]
000078d1a57de770  vmovaps xmm6, [rsp+0x60]
000078d1a57de776  vmovaps xmm7, [rsp+0x70]
000078d1a57de77c  vmovaps xmm8, [rsp+0x80]
000078d1a57de785  vmovaps xmm10, [rsp+0x90]
000078d1a57de78e  vmovaps xmm11, [rsp+0xA0]
000078d1a57de797  vmovaps xmm12, [rsp+0xB0]
000078d1a57de7a0  vmovaps xmm13, [rsp+0xC0]
000078d1a57de7a9  vmovaps xmm14, [rsp+0xD0]
000078d1a57de7b2  vmovaps xmm15, [rsp+0xE0]
000078d1a57de7bb  add rsp, 0xF0
000078d1a57de7c2  pop r11
000078d1a57de7c4  pop r10
000078d1a57de7c6  pop r9
000078d1a57de7c8  pop r8
000078d1a57de7ca  pop rsi
000078d1a57de7cb  pop rdi
000078d1a57de7cc  pop rdx
000078d1a57de7cd  pop rcx
000078d1a57de7ce  pop rax
000078d1a57de7cf  add rsp, 0x08
000078d1a57de7d3  jmp 0x000078D1A57DC1AA
000078d1a57de7d8  call 0x000078D1A56B52F0
000078d1a57de7dd  jmp 0x000078D1A57DC1B7
000078d1a57de7e2  sub rsp, 0x08
000078d1a57de7e6  push rax
000078d1a57de7e7  push rcx
000078d1a57de7e8  push rdx
000078d1a57de7e9  push rdi
000078d1a57de7ea  push rsi
000078d1a57de7eb  push r8
000078d1a57de7ed  push r9
000078d1a57de7ef  push r10
000078d1a57de7f1  push r11
000078d1a57de7f3  sub rsp, 0xF0
000078d1a57de7fa  vmovaps [rsp], xmm0
000078d1a57de7ff  vmovaps [rsp+0x10], xmm1
000078d1a57de805  vmovaps [rsp+0x20], xmm2
000078d1a57de80b  vmovaps [rsp+0x30], xmm3
000078d1a57de811  vmovaps [rsp+0x40], xmm4
000078d1a57de817  vmovaps [rsp+0x50], xmm5
000078d1a57de81d  vmovaps [rsp+0x60], xmm6
000078d1a57de823  vmovaps [rsp+0x70], xmm7
000078d1a57de829  vmovaps [rsp+0x80], xmm8
000078d1a57de832  vmovaps [rsp+0x90], xmm9
000078d1a57de83b  vmovaps [rsp+0xA0], xmm10
000078d1a57de844  vmovaps [rsp+0xB0], xmm11
000078d1a57de84d  vmovaps [rsp+0xC0], xmm12
000078d1a57de856  vmovaps [rsp+0xD0], xmm13
000078d1a57de85f  vmovaps [rsp+0xE0], xmm14
000078d1a57de868  sub rsp, 0x30
000078d1a57de86c  movaps [rsp], xmm15
000078d1a57de871  movaps [rsp+0x10], xmm3
000078d1a57de876  movaps [rsp+0x20], xmm7
000078d1a57de87b  lea rdi, [rsp]
000078d1a57de87f  mov esi, 0x00
000078d1a57de884  mov rax, 0x56EA20A26530
000078d1a57de88e  call rax
000078d1a57de890  movaps xmm15, [rsp]
000078d1a57de895  add rsp, 0x30
000078d1a57de899  vmovaps xmm0, [rsp]
000078d1a57de89e  vmovaps xmm1, [rsp+0x10]
000078d1a57de8a4  vmovaps xmm2, [rsp+0x20]
000078d1a57de8aa  vmovaps xmm3, [rsp+0x30]
000078d1a57de8b0  vmovaps xmm4, [rsp+0x40]
000078d1a57de8b6  vmovaps xmm5, [rsp+0x50]
000078d1a57de8bc  vmovaps xmm6, [rsp+0x60]
000078d1a57de8c2  vmovaps xmm7, [rsp+0x70]
000078d1a57de8c8  vmovaps xmm8, [rsp+0x80]
000078d1a57de8d1  vmovaps xmm9, [rsp+0x90]
000078d1a57de8da  vmovaps xmm10, [rsp+0xA0]
000078d1a57de8e3  vmovaps xmm11, [rsp+0xB0]
000078d1a57de8ec  vmovaps xmm12, [rsp+0xC0]
000078d1a57de8f5  vmovaps xmm13, [rsp+0xD0]
000078d1a57de8fe  vmovaps xmm14, [rsp+0xE0]
000078d1a57de907  add rsp, 0xF0
000078d1a57de90e  pop r11
000078d1a57de910  pop r10
000078d1a57de912  pop r9
000078d1a57de914  pop r8
000078d1a57de916  pop rsi
000078d1a57de917  pop rdi
000078d1a57de918  pop rdx
000078d1a57de919  pop rcx
000078d1a57de91a  pop rax
000078d1a57de91b  add rsp, 0x08
000078d1a57de91f  jmp 0x000078D1A57DC1E3
000078d1a57de924  sub rsp, 0x08
000078d1a57de928  push rax
000078d1a57de929  push rcx
000078d1a57de92a  push rdx
000078d1a57de92b  push rdi
000078d1a57de92c  push rsi
000078d1a57de92d  push r8
000078d1a57de92f  push r9
000078d1a57de931  push r10
000078d1a57de933  push r11
000078d1a57de935  sub rsp, 0xF0
000078d1a57de93c  vmovaps [rsp], xmm0
000078d1a57de941  vmovaps [rsp+0x10], xmm1
000078d1a57de947  vmovaps [rsp+0x20], xmm2
000078d1a57de94d  vmovaps [rsp+0x30], xmm4
000078d1a57de953  vmovaps [rsp+0x40], xmm5
000078d1a57de959  vmovaps [rsp+0x50], xmm6
000078d1a57de95f  vmovaps [rsp+0x60], xmm7
000078d1a57de965  vmovaps [rsp+0x70], xmm8
000078d1a57de96b  vmovaps [rsp+0x80], xmm9
000078d1a57de974  vmovaps [rsp+0x90], xmm10
000078d1a57de97d  vmovaps [rsp+0xA0], xmm11
000078d1a57de986  vmovaps [rsp+0xB0], xmm12
000078d1a57de98f  vmovaps [rsp+0xC0], xmm13
000078d1a57de998  vmovaps [rsp+0xD0], xmm14
000078d1a57de9a1  vmovaps [rsp+0xE0], xmm15
000078d1a57de9aa  sub rsp, 0x30
000078d1a57de9ae  movaps [rsp], xmm3
000078d1a57de9b2  movaps [rsp+0x10], xmm1
000078d1a57de9b7  movaps [rsp+0x20], xmm15
000078d1a57de9bd  lea rdi, [rsp]
000078d1a57de9c1  mov esi, 0x00
000078d1a57de9c6  mov rax, 0x56EA20A26530
000078d1a57de9d0  call rax
000078d1a57de9d2  movaps xmm3, [rsp]
000078d1a57de9d6  add rsp, 0x30
000078d1a57de9da  vmovaps xmm0, [rsp]
000078d1a57de9df  vmovaps xmm1, [rsp+0x10]
000078d1a57de9e5  vmovaps xmm2, [rsp+0x20]
000078d1a57de9eb  vmovaps xmm4, [rsp+0x30]
000078d1a57de9f1  vmovaps xmm5, [rsp+0x40]
000078d1a57de9f7  vmovaps xmm6, [rsp+0x50]
000078d1a57de9fd  vmovaps xmm7, [rsp+0x60]
000078d1a57dea03  vmovaps xmm8, [rsp+0x70]
000078d1a57dea09  vmovaps xmm9, [rsp+0x80]
000078d1a57dea12  vmovaps xmm10, [rsp+0x90]
000078d1a57dea1b  vmovaps xmm11, [rsp+0xA0]
000078d1a57dea24  vmovaps xmm12, [rsp+0xB0]
000078d1a57dea2d  vmovaps xmm13, [rsp+0xC0]
000078d1a57dea36  vmovaps xmm14, [rsp+0xD0]
000078d1a57dea3f  vmovaps xmm15, [rsp+0xE0]
000078d1a57dea48  add rsp, 0xF0
000078d1a57dea4f  pop r11
000078d1a57dea51  pop r10
000078d1a57dea53  pop r9
000078d1a57dea55  pop r8
000078d1a57dea57  pop rsi
000078d1a57dea58  pop rdi
000078d1a57dea59  pop rdx
000078d1a57dea5a  pop rcx
000078d1a57dea5b  pop rax
000078d1a57dea5c  add rsp, 0x08
000078d1a57dea60  jmp 0x000078D1A57DC272
000078d1a57dea65  call 0x000078D1A56B52F0
000078d1a57dea6a  jmp 0x000078D1A57DC27C
000078d1a57dea6f  sub rsp, 0x08
000078d1a57dea73  push rax
000078d1a57dea74  push rcx
000078d1a57dea75  push rdx
000078d1a57dea76  push rdi
000078d1a57dea77  push rsi
000078d1a57dea78  push r8
000078d1a57dea7a  push r9
000078d1a57dea7c  push r10
000078d1a57dea7e  push r11
000078d1a57dea80  sub rsp, 0xF0
000078d1a57dea87  vmovaps [rsp], xmm0
000078d1a57dea8c  vmovaps [rsp+0x10], xmm1
000078d1a57dea92  vmovaps [rsp+0x20], xmm2
000078d1a57dea98  vmovaps [rsp+0x30], xmm3
000078d1a57dea9e  vmovaps [rsp+0x40], xmm4
000078d1a57deaa4  vmovaps [rsp+0x50], xmm5
000078d1a57deaaa  vmovaps [rsp+0x60], xmm6
000078d1a57deab0  vmovaps [rsp+0x70], xmm7
000078d1a57deab6  vmovaps [rsp+0x80], xmm8
000078d1a57deabf  vmovaps [rsp+0x90], xmm9
000078d1a57deac8  vmovaps [rsp+0xA0], xmm10
000078d1a57dead1  vmovaps [rsp+0xB0], xmm11
000078d1a57deada  vmovaps [rsp+0xC0], xmm12
000078d1a57deae3  vmovaps [rsp+0xD0], xmm13
000078d1a57deaec  vmovaps [rsp+0xE0], xmm14
000078d1a57deaf5  sub rsp, 0x30
000078d1a57deaf9  movaps [rsp], xmm15
000078d1a57deafe  movaps [rsp+0x10], xmm14
000078d1a57deb04  movaps [rsp+0x20], xmm4
000078d1a57deb09  lea rdi, [rsp]
000078d1a57deb0d  mov esi, 0x00
000078d1a57deb12  mov rax, 0x56EA20A26530
000078d1a57deb1c  call rax
000078d1a57deb1e  movaps xmm15, [rsp]
000078d1a57deb23  add rsp, 0x30
000078d1a57deb27  vmovaps xmm0, [rsp]
000078d1a57deb2c  vmovaps xmm1, [rsp+0x10]
000078d1a57deb32  vmovaps xmm2, [rsp+0x20]
000078d1a57deb38  vmovaps xmm3, [rsp+0x30]
000078d1a57deb3e  vmovaps xmm4, [rsp+0x40]
000078d1a57deb44  vmovaps xmm5, [rsp+0x50]
000078d1a57deb4a  vmovaps xmm6, [rsp+0x60]
000078d1a57deb50  vmovaps xmm7, [rsp+0x70]
000078d1a57deb56  vmovaps xmm8, [rsp+0x80]
000078d1a57deb5f  vmovaps xmm9, [rsp+0x90]
000078d1a57deb68  vmovaps xmm10, [rsp+0xA0]
000078d1a57deb71  vmovaps xmm11, [rsp+0xB0]
000078d1a57deb7a  vmovaps xmm12, [rsp+0xC0]
000078d1a57deb83  vmovaps xmm13, [rsp+0xD0]
000078d1a57deb8c  vmovaps xmm14, [rsp+0xE0]
000078d1a57deb95  add rsp, 0xF0
000078d1a57deb9c  pop r11
000078d1a57deb9e  pop r10
000078d1a57deba0  pop r9
000078d1a57deba2  pop r8
000078d1a57deba4  pop rsi
000078d1a57deba5  pop rdi
000078d1a57deba6  pop rdx
000078d1a57deba7  pop rcx
000078d1a57deba8  pop rax
000078d1a57deba9  add rsp, 0x08
000078d1a57debad  jmp 0x000078D1A57DC2AA
000078d1a57debb2  sub rsp, 0x08
000078d1a57debb6  push rax
000078d1a57debb7  push rcx
000078d1a57debb8  push rdx
000078d1a57debb9  push rdi
000078d1a57debba  push rsi
000078d1a57debbb  push r8
000078d1a57debbd  push r9
000078d1a57debbf  push r10
000078d1a57debc1  push r11
000078d1a57debc3  sub rsp, 0xF0
000078d1a57debca  vmovaps [rsp], xmm0
000078d1a57debcf  vmovaps [rsp+0x10], xmm1
000078d1a57debd5  vmovaps [rsp+0x20], xmm2
000078d1a57debdb  vmovaps [rsp+0x30], xmm3
000078d1a57debe1  vmovaps [rsp+0x40], xmm4
000078d1a57debe7  vmovaps [rsp+0x50], xmm5
000078d1a57debed  vmovaps [rsp+0x60], xmm6
000078d1a57debf3  vmovaps [rsp+0x70], xmm7
000078d1a57debf9  vmovaps [rsp+0x80], xmm8
000078d1a57dec02  vmovaps [rsp+0x90], xmm9
000078d1a57dec0b  vmovaps [rsp+0xA0], xmm10
000078d1a57dec14  vmovaps [rsp+0xB0], xmm11
000078d1a57dec1d  vmovaps [rsp+0xC0], xmm12
000078d1a57dec26  vmovaps [rsp+0xD0], xmm13
000078d1a57dec2f  vmovaps [rsp+0xE0], xmm15
000078d1a57dec38  sub rsp, 0x30
000078d1a57dec3c  movaps [rsp], xmm14
000078d1a57dec41  movaps [rsp+0x10], xmm2
000078d1a57dec46  movaps [rsp+0x20], xmm1
000078d1a57dec4b  lea rdi, [rsp]
000078d1a57dec4f  mov esi, 0x00
000078d1a57dec54  mov rax, 0x56EA20A26530
000078d1a57dec5e  call rax
000078d1a57dec60  movaps xmm14, [rsp]
000078d1a57dec65  add rsp, 0x30
000078d1a57dec69  vmovaps xmm0, [rsp]
000078d1a57dec6e  vmovaps xmm1, [rsp+0x10]
000078d1a57dec74  vmovaps xmm2, [rsp+0x20]
000078d1a57dec7a  vmovaps xmm3, [rsp+0x30]
000078d1a57dec80  vmovaps xmm4, [rsp+0x40]
000078d1a57dec86  vmovaps xmm5, [rsp+0x50]
000078d1a57dec8c  vmovaps xmm6, [rsp+0x60]
000078d1a57dec92  vmovaps xmm7, [rsp+0x70]
000078d1a57dec98  vmovaps xmm8, [rsp+0x80]
000078d1a57deca1  vmovaps xmm9, [rsp+0x90]
000078d1a57decaa  vmovaps xmm10, [rsp+0xA0]
000078d1a57decb3  vmovaps xmm11, [rsp+0xB0]
000078d1a57decbc  vmovaps xmm12, [rsp+0xC0]
000078d1a57decc5  vmovaps xmm13, [rsp+0xD0]
000078d1a57decce  vmovaps xmm15, [rsp+0xE0]
000078d1a57decd7  add rsp, 0xF0
000078d1a57decde  pop r11
000078d1a57dece0  pop r10
000078d1a57dece2  pop r9
000078d1a57dece4  pop r8
000078d1a57dece6  pop rsi
000078d1a57dece7  pop rdi
000078d1a57dece8  pop rdx
000078d1a57dece9  pop rcx
000078d1a57decea  pop rax
000078d1a57deceb  add rsp, 0x08
000078d1a57decef  jmp 0x000078D1A57DC2D0
000078d1a57decf4  sub rsp, 0x08
000078d1a57decf8  push rax
000078d1a57decf9  push rcx
000078d1a57decfa  push rdx
000078d1a57decfb  push rdi
000078d1a57decfc  push rsi
000078d1a57decfd  push r8
000078d1a57decff  push r9
000078d1a57ded01  push r10
000078d1a57ded03  push r11
000078d1a57ded05  sub rsp, 0xF0
000078d1a57ded0c  vmovaps [rsp], xmm0
000078d1a57ded11  vmovaps [rsp+0x10], xmm2
000078d1a57ded17  vmovaps [rsp+0x20], xmm3
000078d1a57ded1d  vmovaps [rsp+0x30], xmm4
000078d1a57ded23  vmovaps [rsp+0x40], xmm5
000078d1a57ded29  vmovaps [rsp+0x50], xmm6
000078d1a57ded2f  vmovaps [rsp+0x60], xmm7
000078d1a57ded35  vmovaps [rsp+0x70], xmm8
000078d1a57ded3b  vmovaps [rsp+0x80], xmm9
000078d1a57ded44  vmovaps [rsp+0x90], xmm10
000078d1a57ded4d  vmovaps [rsp+0xA0], xmm11
000078d1a57ded56  vmovaps [rsp+0xB0], xmm12
000078d1a57ded5f  vmovaps [rsp+0xC0], xmm13
000078d1a57ded68  vmovaps [rsp+0xD0], xmm14
000078d1a57ded71  vmovaps [rsp+0xE0], xmm15
000078d1a57ded7a  sub rsp, 0x30
000078d1a57ded7e  movaps [rsp], xmm1
000078d1a57ded82  movaps [rsp+0x10], xmm4
000078d1a57ded87  movaps [rsp+0x20], xmm9
000078d1a57ded8d  lea rdi, [rsp]
000078d1a57ded91  mov esi, 0x00
000078d1a57ded96  mov rax, 0x56EA20A26530
000078d1a57deda0  call rax
000078d1a57deda2  movaps xmm1, [rsp]
000078d1a57deda6  add rsp, 0x30
000078d1a57dedaa  vmovaps xmm0, [rsp]
000078d1a57dedaf  vmovaps xmm2, [rsp+0x10]
000078d1a57dedb5  vmovaps xmm3, [rsp+0x20]
000078d1a57dedbb  vmovaps xmm4, [rsp+0x30]
000078d1a57dedc1  vmovaps xmm5, [rsp+0x40]
000078d1a57dedc7  vmovaps xmm6, [rsp+0x50]
000078d1a57dedcd  vmovaps xmm7, [rsp+0x60]
000078d1a57dedd3  vmovaps xmm8, [rsp+0x70]
000078d1a57dedd9  vmovaps xmm9, [rsp+0x80]
000078d1a57dede2  vmovaps xmm10, [rsp+0x90]
000078d1a57dedeb  vmovaps xmm11, [rsp+0xA0]
000078d1a57dedf4  vmovaps xmm12, [rsp+0xB0]
000078d1a57dedfd  vmovaps xmm13, [rsp+0xC0]
000078d1a57dee06  vmovaps xmm14, [rsp+0xD0]
000078d1a57dee0f  vmovaps xmm15, [rsp+0xE0]
000078d1a57dee18  add rsp, 0xF0
000078d1a57dee1f  pop r11
000078d1a57dee21  pop r10
000078d1a57dee23  pop r9
000078d1a57dee25  pop r8
000078d1a57dee27  pop rsi
000078d1a57dee28  pop rdi
000078d1a57dee29  pop rdx
000078d1a57dee2a  pop rcx
000078d1a57dee2b  pop rax
000078d1a57dee2c  add rsp, 0x08
000078d1a57dee30  jmp 0x000078D1A57DC2EE
000078d1a57dee35  sub rsp, 0x08
000078d1a57dee39  push rax
000078d1a57dee3a  push rcx
000078d1a57dee3b  push rdx
000078d1a57dee3c  push rdi
000078d1a57dee3d  push rsi
000078d1a57dee3e  push r8
000078d1a57dee40  push r9
000078d1a57dee42  push r10
000078d1a57dee44  push r11
000078d1a57dee46  sub rsp, 0xF0
000078d1a57dee4d  vmovaps [rsp], xmm0
000078d1a57dee52  vmovaps [rsp+0x10], xmm1
000078d1a57dee58  vmovaps [rsp+0x20], xmm2
000078d1a57dee5e  vmovaps [rsp+0x30], xmm3
000078d1a57dee64  vmovaps [rsp+0x40], xmm5
000078d1a57dee6a  vmovaps [rsp+0x50], xmm6
000078d1a57dee70  vmovaps [rsp+0x60], xmm7
000078d1a57dee76  vmovaps [rsp+0x70], xmm8
000078d1a57dee7c  vmovaps [rsp+0x80], xmm9
000078d1a57dee85  vmovaps [rsp+0x90], xmm10
000078d1a57dee8e  vmovaps [rsp+0xA0], xmm11
000078d1a57dee97  vmovaps [rsp+0xB0], xmm12
000078d1a57deea0  vmovaps [rsp+0xC0], xmm13
000078d1a57deea9  vmovaps [rsp+0xD0], xmm14
000078d1a57deeb2  vmovaps [rsp+0xE0], xmm15
000078d1a57deebb  sub rsp, 0x30
000078d1a57deebf  movaps [rsp], xmm4
000078d1a57deec3  movaps [rsp+0x10], xmm2
000078d1a57deec8  movaps [rsp+0x20], xmm9
000078d1a57deece  lea rdi, [rsp]
000078d1a57deed2  mov esi, 0x00
000078d1a57deed7  mov rax, 0x56EA20A26530
000078d1a57deee1  call rax
000078d1a57deee3  movaps xmm4, [rsp]
000078d1a57deee7  add rsp, 0x30
000078d1a57deeeb  vmovaps xmm0, [rsp]
000078d1a57deef0  vmovaps xmm1, [rsp+0x10]
000078d1a57deef6  vmovaps xmm2, [rsp+0x20]
000078d1a57deefc  vmovaps xmm3, [rsp+0x30]
000078d1a57def02  vmovaps xmm5, [rsp+0x40]
000078d1a57def08  vmovaps xmm6, [rsp+0x50]
000078d1a57def0e  vmovaps xmm7, [rsp+0x60]
000078d1a57def14  vmovaps xmm8, [rsp+0x70]
000078d1a57def1a  vmovaps xmm9, [rsp+0x80]
000078d1a57def23  vmovaps xmm10, [rsp+0x90]
000078d1a57def2c  vmovaps xmm11, [rsp+0xA0]
000078d1a57def35  vmovaps xmm12, [rsp+0xB0]
000078d1a57def3e  vmovaps xmm13, [rsp+0xC0]
000078d1a57def47  vmovaps xmm14, [rsp+0xD0]
000078d1a57def50  vmovaps xmm15, [rsp+0xE0]
000078d1a57def59  add rsp, 0xF0
000078d1a57def60  pop r11
000078d1a57def62  pop r10
000078d1a57def64  pop r9
000078d1a57def66  pop r8
000078d1a57def68  pop rsi
000078d1a57def69  pop rdi
000078d1a57def6a  pop rdx
000078d1a57def6b  pop rcx
000078d1a57def6c  pop rax
000078d1a57def6d  add rsp, 0x08
000078d1a57def71  jmp 0x000078D1A57DC31E
000078d1a57def76  sub rsp, 0x08
000078d1a57def7a  push rax
000078d1a57def7b  push rcx
000078d1a57def7c  push rdx
000078d1a57def7d  push rdi
000078d1a57def7e  push rsi
000078d1a57def7f  push r8
000078d1a57def81  push r9
000078d1a57def83  push r10
000078d1a57def85  push r11
000078d1a57def87  sub rsp, 0xF0
000078d1a57def8e  vmovaps [rsp], xmm0
000078d1a57def93  vmovaps [rsp+0x10], xmm1
000078d1a57def99  vmovaps [rsp+0x20], xmm2
000078d1a57def9f  vmovaps [rsp+0x30], xmm3
000078d1a57defa5  vmovaps [rsp+0x40], xmm4
000078d1a57defab  vmovaps [rsp+0x50], xmm5
000078d1a57defb1  vmovaps [rsp+0x60], xmm6
000078d1a57defb7  vmovaps [rsp+0x70], xmm7
000078d1a57defbd  vmovaps [rsp+0x80], xmm8
000078d1a57defc6  vmovaps [rsp+0x90], xmm10
000078d1a57defcf  vmovaps [rsp+0xA0], xmm11
000078d1a57defd8  vmovaps [rsp+0xB0], xmm12
000078d1a57defe1  vmovaps [rsp+0xC0], xmm13
000078d1a57defea  vmovaps [rsp+0xD0], xmm14
000078d1a57deff3  vmovaps [rsp+0xE0], xmm15
000078d1a57deffc  sub rsp, 0x30
000078d1a57df000  movaps [rsp], xmm9
000078d1a57df005  movaps [rsp+0x10], xmm2
000078d1a57df00a  movaps [rsp+0x20], xmm1
000078d1a57df00f  lea rdi, [rsp]
000078d1a57df013  mov esi, 0x00
000078d1a57df018  mov rax, 0x56EA20A26530
000078d1a57df022  call rax
000078d1a57df024  movaps xmm9, [rsp]
000078d1a57df029  add rsp, 0x30
000078d1a57df02d  vmovaps xmm0, [rsp]
000078d1a57df032  vmovaps xmm1, [rsp+0x10]
000078d1a57df038  vmovaps xmm2, [rsp+0x20]
000078d1a57df03e  vmovaps xmm3, [rsp+0x30]
000078d1a57df044  vmovaps xmm4, [rsp+0x40]
000078d1a57df04a  vmovaps xmm5, [rsp+0x50]
000078d1a57df050  vmovaps xmm6, [rsp+0x60]
000078d1a57df056  vmovaps xmm7, [rsp+0x70]
000078d1a57df05c  vmovaps xmm8, [rsp+0x80]
000078d1a57df065  vmovaps xmm10, [rsp+0x90]
000078d1a57df06e  vmovaps xmm11, [rsp+0xA0]
000078d1a57df077  vmovaps xmm12, [rsp+0xB0]
000078d1a57df080  vmovaps xmm13, [rsp+0xC0]
000078d1a57df089  vmovaps xmm14, [rsp+0xD0]
000078d1a57df092  vmovaps xmm15, [rsp+0xE0]
000078d1a57df09b  add rsp, 0xF0
000078d1a57df0a2  pop r11
000078d1a57df0a4  pop r10
000078d1a57df0a6  pop r9
000078d1a57df0a8  pop r8
000078d1a57df0aa  pop rsi
000078d1a57df0ab  pop rdi
000078d1a57df0ac  pop rdx
000078d1a57df0ad  pop rcx
000078d1a57df0ae  pop rax
000078d1a57df0af  add rsp, 0x08
000078d1a57df0b3  jmp 0x000078D1A57DC354
000078d1a57df0b8  sub rsp, 0x08
000078d1a57df0bc  push rax
000078d1a57df0bd  push rcx
000078d1a57df0be  push rdx
000078d1a57df0bf  push rdi
000078d1a57df0c0  push rsi
000078d1a57df0c1  push r8
000078d1a57df0c3  push r9
000078d1a57df0c5  push r10
000078d1a57df0c7  push r11
000078d1a57df0c9  sub rsp, 0xF0
000078d1a57df0d0  vmovaps [rsp], xmm0
000078d1a57df0d5  vmovaps [rsp+0x10], xmm2
000078d1a57df0db  vmovaps [rsp+0x20], xmm3
000078d1a57df0e1  vmovaps [rsp+0x30], xmm4
000078d1a57df0e7  vmovaps [rsp+0x40], xmm5
000078d1a57df0ed  vmovaps [rsp+0x50], xmm6
000078d1a57df0f3  vmovaps [rsp+0x60], xmm7
000078d1a57df0f9  vmovaps [rsp+0x70], xmm8
000078d1a57df0ff  vmovaps [rsp+0x80], xmm9
000078d1a57df108  vmovaps [rsp+0x90], xmm10
000078d1a57df111  vmovaps [rsp+0xA0], xmm11
000078d1a57df11a  vmovaps [rsp+0xB0], xmm12
000078d1a57df123  vmovaps [rsp+0xC0], xmm13
000078d1a57df12c  vmovaps [rsp+0xD0], xmm14
000078d1a57df135  vmovaps [rsp+0xE0], xmm15
000078d1a57df13e  sub rsp, 0x30
000078d1a57df142  movaps [rsp], xmm1
000078d1a57df146  movaps [rsp+0x10], xmm15
000078d1a57df14c  movaps [rsp+0x20], xmm6
000078d1a57df151  lea rdi, [rsp]
000078d1a57df155  mov esi, 0x00
000078d1a57df15a  mov rax, 0x56EA20A26530
000078d1a57df164  call rax
000078d1a57df166  movaps xmm1, [rsp]
000078d1a57df16a  add rsp, 0x30
000078d1a57df16e  vmovaps xmm0, [rsp]
000078d1a57df173  vmovaps xmm2, [rsp+0x10]
000078d1a57df179  vmovaps xmm3, [rsp+0x20]
000078d1a57df17f  vmovaps xmm4, [rsp+0x30]
000078d1a57df185  vmovaps xmm5, [rsp+0x40]
000078d1a57df18b  vmovaps xmm6, [rsp+0x50]
000078d1a57df191  vmovaps xmm7, [rsp+0x60]
000078d1a57df197  vmovaps xmm8, [rsp+0x70]
000078d1a57df19d  vmovaps xmm9, [rsp+0x80]
000078d1a57df1a6  vmovaps xmm10, [rsp+0x90]
000078d1a57df1af  vmovaps xmm11, [rsp+0xA0]
000078d1a57df1b8  vmovaps xmm12, [rsp+0xB0]
000078d1a57df1c1  vmovaps xmm13, [rsp+0xC0]
000078d1a57df1ca  vmovaps xmm14, [rsp+0xD0]
000078d1a57df1d3  vmovaps xmm15, [rsp+0xE0]
000078d1a57df1dc  add rsp, 0xF0
000078d1a57df1e3  pop r11
000078d1a57df1e5  pop r10
000078d1a57df1e7  pop r9
000078d1a57df1e9  pop r8
000078d1a57df1eb  pop rsi
000078d1a57df1ec  pop rdi
000078d1a57df1ed  pop rdx
000078d1a57df1ee  pop rcx
000078d1a57df1ef  pop rax
000078d1a57df1f0  add rsp, 0x08
000078d1a57df1f4  jmp 0x000078D1A57DC375
000078d1a57df1f9  sub rsp, 0x08
000078d1a57df1fd  push rax
000078d1a57df1fe  push rcx
000078d1a57df1ff  push rdx
000078d1a57df200  push rdi
000078d1a57df201  push rsi
000078d1a57df202  push r8
000078d1a57df204  push r9
000078d1a57df206  push r10
000078d1a57df208  push r11
000078d1a57df20a  sub rsp, 0xF0
000078d1a57df211  vmovaps [rsp], xmm0
000078d1a57df216  vmovaps [rsp+0x10], xmm1
000078d1a57df21c  vmovaps [rsp+0x20], xmm2
000078d1a57df222  vmovaps [rsp+0x30], xmm3
000078d1a57df228  vmovaps [rsp+0x40], xmm4
000078d1a57df22e  vmovaps [rsp+0x50], xmm5
000078d1a57df234  vmovaps [rsp+0x60], xmm6
000078d1a57df23a  vmovaps [rsp+0x70], xmm7
000078d1a57df240  vmovaps [rsp+0x80], xmm8
000078d1a57df249  vmovaps [rsp+0x90], xmm9
000078d1a57df252  vmovaps [rsp+0xA0], xmm10
000078d1a57df25b  vmovaps [rsp+0xB0], xmm11
000078d1a57df264  vmovaps [rsp+0xC0], xmm12
000078d1a57df26d  vmovaps [rsp+0xD0], xmm13
000078d1a57df276  vmovaps [rsp+0xE0], xmm14
000078d1a57df27f  sub rsp, 0x30
000078d1a57df283  movaps [rsp], xmm15
000078d1a57df288  movaps [rsp+0x10], xmm5
000078d1a57df28d  movaps [rsp+0x20], xmm3
000078d1a57df292  lea rdi, [rsp]
000078d1a57df296  mov esi, 0x00
000078d1a57df29b  mov rax, 0x56EA20A26530
000078d1a57df2a5  call rax
000078d1a57df2a7  movaps xmm15, [rsp]
000078d1a57df2ac  add rsp, 0x30
000078d1a57df2b0  vmovaps xmm0, [rsp]
000078d1a57df2b5  vmovaps xmm1, [rsp+0x10]
000078d1a57df2bb  vmovaps xmm2, [rsp+0x20]
000078d1a57df2c1  vmovaps xmm3, [rsp+0x30]
000078d1a57df2c7  vmovaps xmm4, [rsp+0x40]
000078d1a57df2cd  vmovaps xmm5, [rsp+0x50]
000078d1a57df2d3  vmovaps xmm6, [rsp+0x60]
000078d1a57df2d9  vmovaps xmm7, [rsp+0x70]
000078d1a57df2df  vmovaps xmm8, [rsp+0x80]
000078d1a57df2e8  vmovaps xmm9, [rsp+0x90]
000078d1a57df2f1  vmovaps xmm10, [rsp+0xA0]
000078d1a57df2fa  vmovaps xmm11, [rsp+0xB0]
000078d1a57df303  vmovaps xmm12, [rsp+0xC0]
000078d1a57df30c  vmovaps xmm13, [rsp+0xD0]
000078d1a57df315  vmovaps xmm14, [rsp+0xE0]
000078d1a57df31e  add rsp, 0xF0
000078d1a57df325  pop r11
000078d1a57df327  pop r10
000078d1a57df329  pop r9
000078d1a57df32b  pop r8
000078d1a57df32d  pop rsi
000078d1a57df32e  pop rdi
000078d1a57df32f  pop rdx
000078d1a57df330  pop rcx
000078d1a57df331  pop rax
000078d1a57df332  add rsp, 0x08
000078d1a57df336  jmp 0x000078D1A57DC38F
000078d1a57df33b  sub rsp, 0x08
000078d1a57df33f  push rax
000078d1a57df340  push rcx
000078d1a57df341  push rdx
000078d1a57df342  push rdi
000078d1a57df343  push rsi
000078d1a57df344  push r8
000078d1a57df346  push r9
000078d1a57df348  push r10
000078d1a57df34a  push r11
000078d1a57df34c  sub rsp, 0xF0
000078d1a57df353  vmovaps [rsp], xmm0
000078d1a57df358  vmovaps [rsp+0x10], xmm1
000078d1a57df35e  vmovaps [rsp+0x20], xmm2
000078d1a57df364  vmovaps [rsp+0x30], xmm3
000078d1a57df36a  vmovaps [rsp+0x40], xmm4
000078d1a57df370  vmovaps [rsp+0x50], xmm6
000078d1a57df376  vmovaps [rsp+0x60], xmm7
000078d1a57df37c  vmovaps [rsp+0x70], xmm8
000078d1a57df382  vmovaps [rsp+0x80], xmm9
000078d1a57df38b  vmovaps [rsp+0x90], xmm10
000078d1a57df394  vmovaps [rsp+0xA0], xmm11
000078d1a57df39d  vmovaps [rsp+0xB0], xmm12
000078d1a57df3a6  vmovaps [rsp+0xC0], xmm13
000078d1a57df3af  vmovaps [rsp+0xD0], xmm14
000078d1a57df3b8  vmovaps [rsp+0xE0], xmm15
000078d1a57df3c1  sub rsp, 0x30
000078d1a57df3c5  movaps [rsp], xmm5
000078d1a57df3c9  movaps [rsp+0x10], xmm8
000078d1a57df3cf  movaps [rsp+0x20], xmm6
000078d1a57df3d4  lea rdi, [rsp]
000078d1a57df3d8  mov esi, 0x00
000078d1a57df3dd  mov rax, 0x56EA20A26530
000078d1a57df3e7  call rax
000078d1a57df3e9  movaps xmm5, [rsp]
000078d1a57df3ed  add rsp, 0x30
000078d1a57df3f1  vmovaps xmm0, [rsp]
000078d1a57df3f6  vmovaps xmm1, [rsp+0x10]
000078d1a57df3fc  vmovaps xmm2, [rsp+0x20]
000078d1a57df402  vmovaps xmm3, [rsp+0x30]
000078d1a57df408  vmovaps xmm4, [rsp+0x40]
000078d1a57df40e  vmovaps xmm6, [rsp+0x50]
000078d1a57df414  vmovaps xmm7, [rsp+0x60]
000078d1a57df41a  vmovaps xmm8, [rsp+0x70]
000078d1a57df420  vmovaps xmm9, [rsp+0x80]
000078d1a57df429  vmovaps xmm10, [rsp+0x90]
000078d1a57df432  vmovaps xmm11, [rsp+0xA0]
000078d1a57df43b  vmovaps xmm12, [rsp+0xB0]
000078d1a57df444  vmovaps xmm13, [rsp+0xC0]
000078d1a57df44d  vmovaps xmm14, [rsp+0xD0]
000078d1a57df456  vmovaps xmm15, [rsp+0xE0]
000078d1a57df45f  add rsp, 0xF0
000078d1a57df466  pop r11
000078d1a57df468  pop r10
000078d1a57df46a  pop r9
000078d1a57df46c  pop r8
000078d1a57df46e  pop rsi
000078d1a57df46f  pop rdi
000078d1a57df470  pop rdx
000078d1a57df471  pop rcx
000078d1a57df472  pop rax
000078d1a57df473  add rsp, 0x08
000078d1a57df477  jmp 0x000078D1A57DC3B3
000078d1a57df47c  sub rsp, 0x08
000078d1a57df480  push rax
000078d1a57df481  push rcx
000078d1a57df482  push rdx
000078d1a57df483  push rdi
000078d1a57df484  push rsi
000078d1a57df485  push r8
000078d1a57df487  push r9
000078d1a57df489  push r10
000078d1a57df48b  push r11
000078d1a57df48d  sub rsp, 0xF0
000078d1a57df494  vmovaps [rsp], xmm0
000078d1a57df499  vmovaps [rsp+0x10], xmm1
000078d1a57df49f  vmovaps [rsp+0x20], xmm2
000078d1a57df4a5  vmovaps [rsp+0x30], xmm3
000078d1a57df4ab  vmovaps [rsp+0x40], xmm4
000078d1a57df4b1  vmovaps [rsp+0x50], xmm5
000078d1a57df4b7  vmovaps [rsp+0x60], xmm7
000078d1a57df4bd  vmovaps [rsp+0x70], xmm8
000078d1a57df4c3  vmovaps [rsp+0x80], xmm9
000078d1a57df4cc  vmovaps [rsp+0x90], xmm10
000078d1a57df4d5  vmovaps [rsp+0xA0], xmm11
000078d1a57df4de  vmovaps [rsp+0xB0], xmm12
000078d1a57df4e7  vmovaps [rsp+0xC0], xmm13
000078d1a57df4f0  vmovaps [rsp+0xD0], xmm14
000078d1a57df4f9  vmovaps [rsp+0xE0], xmm15
000078d1a57df502  sub rsp, 0x30
000078d1a57df506  movaps [rsp], xmm6
000078d1a57df50a  movaps [rsp+0x10], xmm10
000078d1a57df510  movaps [rsp+0x20], xmm8
000078d1a57df516  lea rdi, [rsp]
000078d1a57df51a  mov esi, 0x00
000078d1a57df51f  mov rax, 0x56EA20A26530
000078d1a57df529  call rax
000078d1a57df52b  movaps xmm6, [rsp]
000078d1a57df52f  add rsp, 0x30
000078d1a57df533  vmovaps xmm0, [rsp]
000078d1a57df538  vmovaps xmm1, [rsp+0x10]
000078d1a57df53e  vmovaps xmm2, [rsp+0x20]
000078d1a57df544  vmovaps xmm3, [rsp+0x30]
000078d1a57df54a  vmovaps xmm4, [rsp+0x40]
000078d1a57df550  vmovaps xmm5, [rsp+0x50]
000078d1a57df556  vmovaps xmm7, [rsp+0x60]
000078d1a57df55c  vmovaps xmm8, [rsp+0x70]
000078d1a57df562  vmovaps xmm9, [rsp+0x80]
000078d1a57df56b  vmovaps xmm10, [rsp+0x90]
000078d1a57df574  vmovaps xmm11, [rsp+0xA0]
000078d1a57df57d  vmovaps xmm12, [rsp+0xB0]
000078d1a57df586  vmovaps xmm13, [rsp+0xC0]
000078d1a57df58f  vmovaps xmm14, [rsp+0xD0]
000078d1a57df598  vmovaps xmm15, [rsp+0xE0]
000078d1a57df5a1  add rsp, 0xF0
000078d1a57df5a8  pop r11
000078d1a57df5aa  pop r10
000078d1a57df5ac  pop r9
000078d1a57df5ae  pop r8
000078d1a57df5b0  pop rsi
000078d1a57df5b1  pop rdi
000078d1a57df5b2  pop rdx
000078d1a57df5b3  pop rcx
000078d1a57df5b4  pop rax
000078d1a57df5b5  add rsp, 0x08
000078d1a57df5b9  jmp 0x000078D1A57DC3D8
000078d1a57df5be  sub rsp, 0x08
000078d1a57df5c2  push rax
000078d1a57df5c3  push rcx
000078d1a57df5c4  push rdx
000078d1a57df5c5  push rdi
000078d1a57df5c6  push rsi
000078d1a57df5c7  push r8
000078d1a57df5c9  push r9
000078d1a57df5cb  push r10
000078d1a57df5cd  push r11
000078d1a57df5cf  sub rsp, 0xF0
000078d1a57df5d6  vmovaps [rsp], xmm0
000078d1a57df5db  vmovaps [rsp+0x10], xmm1
000078d1a57df5e1  vmovaps [rsp+0x20], xmm2
000078d1a57df5e7  vmovaps [rsp+0x30], xmm3
000078d1a57df5ed  vmovaps [rsp+0x40], xmm4
000078d1a57df5f3  vmovaps [rsp+0x50], xmm5
000078d1a57df5f9  vmovaps [rsp+0x60], xmm6
000078d1a57df5ff  vmovaps [rsp+0x70], xmm7
000078d1a57df605  vmovaps [rsp+0x80], xmm8
000078d1a57df60e  vmovaps [rsp+0x90], xmm9
000078d1a57df617  vmovaps [rsp+0xA0], xmm11
000078d1a57df620  vmovaps [rsp+0xB0], xmm12
000078d1a57df629  vmovaps [rsp+0xC0], xmm13
000078d1a57df632  vmovaps [rsp+0xD0], xmm14
000078d1a57df63b  vmovaps [rsp+0xE0], xmm15
000078d1a57df644  sub rsp, 0x30
000078d1a57df648  movaps [rsp], xmm10
000078d1a57df64d  movaps [rsp+0x10], xmm8
000078d1a57df653  movaps [rsp+0x20], xmm14
000078d1a57df659  lea rdi, [rsp]
000078d1a57df65d  mov esi, 0x00
000078d1a57df662  mov rax, 0x56EA20A26530
000078d1a57df66c  call rax
000078d1a57df66e  movaps xmm10, [rsp]
000078d1a57df673  add rsp, 0x30
000078d1a57df677  vmovaps xmm0, [rsp]
000078d1a57df67c  vmovaps xmm1, [rsp+0x10]
000078d1a57df682  vmovaps xmm2, [rsp+0x20]
000078d1a57df688  vmovaps xmm3, [rsp+0x30]
000078d1a57df68e  vmovaps xmm4, [rsp+0x40]
000078d1a57df694  vmovaps xmm5, [rsp+0x50]
000078d1a57df69a  vmovaps xmm6, [rsp+0x60]
000078d1a57df6a0  vmovaps xmm7, [rsp+0x70]
000078d1a57df6a6  vmovaps xmm8, [rsp+0x80]
000078d1a57df6af  vmovaps xmm9, [rsp+0x90]
000078d1a57df6b8  vmovaps xmm11, [rsp+0xA0]
000078d1a57df6c1  vmovaps xmm12, [rsp+0xB0]
000078d1a57df6ca  vmovaps xmm13, [rsp+0xC0]
000078d1a57df6d3  vmovaps xmm14, [rsp+0xD0]
000078d1a57df6dc  vmovaps xmm15, [rsp+0xE0]
000078d1a57df6e5  add rsp, 0xF0
000078d1a57df6ec  pop r11
000078d1a57df6ee  pop r10
000078d1a57df6f0  pop r9
000078d1a57df6f2  pop r8
000078d1a57df6f4  pop rsi
000078d1a57df6f5  pop rdi
000078d1a57df6f6  pop rdx
000078d1a57df6f7  pop rcx
000078d1a57df6f8  pop rax
000078d1a57df6f9  add rsp, 0x08
000078d1a57df6fd  jmp 0x000078D1A57DC3F8
000078d1a57df702  sub rsp, 0x08
000078d1a57df706  push rax
000078d1a57df707  push rcx
000078d1a57df708  push rdx
000078d1a57df709  push rdi
000078d1a57df70a  push rsi
000078d1a57df70b  push r8
000078d1a57df70d  push r9
000078d1a57df70f  push r10
000078d1a57df711  push r11
000078d1a57df713  sub rsp, 0xF0
000078d1a57df71a  vmovaps [rsp], xmm0
000078d1a57df71f  vmovaps [rsp+0x10], xmm1
000078d1a57df725  vmovaps [rsp+0x20], xmm2
000078d1a57df72b  vmovaps [rsp+0x30], xmm3
000078d1a57df731  vmovaps [rsp+0x40], xmm4
000078d1a57df737  vmovaps [rsp+0x50], xmm5
000078d1a57df73d  vmovaps [rsp+0x60], xmm6
000078d1a57df743  vmovaps [rsp+0x70], xmm7
000078d1a57df749  vmovaps [rsp+0x80], xmm8
000078d1a57df752  vmovaps [rsp+0x90], xmm9
000078d1a57df75b  vmovaps [rsp+0xA0], xmm10
000078d1a57df764  vmovaps [rsp+0xB0], xmm11
000078d1a57df76d  vmovaps [rsp+0xC0], xmm12
000078d1a57df776  vmovaps [rsp+0xD0], xmm13
000078d1a57df77f  vmovaps [rsp+0xE0], xmm15
000078d1a57df788  sub rsp, 0x30
000078d1a57df78c  movaps [rsp], xmm14
000078d1a57df791  movaps [rsp+0x10], xmm8
000078d1a57df797  movaps [rsp+0x20], xmm4
000078d1a57df79c  lea rdi, [rsp]
000078d1a57df7a0  mov esi, 0x00
000078d1a57df7a5  mov rax, 0x56EA20A26530
000078d1a57df7af  call rax
000078d1a57df7b1  movaps xmm14, [rsp]
000078d1a57df7b6  add rsp, 0x30
000078d1a57df7ba  vmovaps xmm0, [rsp]
000078d1a57df7bf  vmovaps xmm1, [rsp+0x10]
000078d1a57df7c5  vmovaps xmm2, [rsp+0x20]
000078d1a57df7cb  vmovaps xmm3, [rsp+0x30]
000078d1a57df7d1  vmovaps xmm4, [rsp+0x40]
000078d1a57df7d7  vmovaps xmm5, [rsp+0x50]
000078d1a57df7dd  vmovaps xmm6, [rsp+0x60]
000078d1a57df7e3  vmovaps xmm7, [rsp+0x70]
000078d1a57df7e9  vmovaps xmm8, [rsp+0x80]
000078d1a57df7f2  vmovaps xmm9, [rsp+0x90]
000078d1a57df7fb  vmovaps xmm10, [rsp+0xA0]
000078d1a57df804  vmovaps xmm11, [rsp+0xB0]
000078d1a57df80d  vmovaps xmm12, [rsp+0xC0]
000078d1a57df816  vmovaps xmm13, [rsp+0xD0]
000078d1a57df81f  vmovaps xmm15, [rsp+0xE0]
000078d1a57df828  add rsp, 0xF0
000078d1a57df82f  pop r11
000078d1a57df831  pop r10
000078d1a57df833  pop r9
000078d1a57df835  pop r8
000078d1a57df837  pop rsi
000078d1a57df838  pop rdi
000078d1a57df839  pop rdx
000078d1a57df83a  pop rcx
000078d1a57df83b  pop rax
000078d1a57df83c  add rsp, 0x08
000078d1a57df840  jmp 0x000078D1A57DC418
000078d1a57df845  sub rsp, 0x08
000078d1a57df849  push rax
000078d1a57df84a  push rcx
000078d1a57df84b  push rdx
000078d1a57df84c  push rdi
000078d1a57df84d  push rsi
000078d1a57df84e  push r8
000078d1a57df850  push r9
000078d1a57df852  push r10
000078d1a57df854  push r11
000078d1a57df856  sub rsp, 0xF0
000078d1a57df85d  vmovaps [rsp], xmm0
000078d1a57df862  vmovaps [rsp+0x10], xmm1
000078d1a57df868  vmovaps [rsp+0x20], xmm2
000078d1a57df86e  vmovaps [rsp+0x30], xmm3
000078d1a57df874  vmovaps [rsp+0x40], xmm5
000078d1a57df87a  vmovaps [rsp+0x50], xmm6
000078d1a57df880  vmovaps [rsp+0x60], xmm7
000078d1a57df886  vmovaps [rsp+0x70], xmm8
000078d1a57df88c  vmovaps [rsp+0x80], xmm9
000078d1a57df895  vmovaps [rsp+0x90], xmm10
000078d1a57df89e  vmovaps [rsp+0xA0], xmm11
000078d1a57df8a7  vmovaps [rsp+0xB0], xmm12
000078d1a57df8b0  vmovaps [rsp+0xC0], xmm13
000078d1a57df8b9  vmovaps [rsp+0xD0], xmm14
000078d1a57df8c2  vmovaps [rsp+0xE0], xmm15
000078d1a57df8cb  sub rsp, 0x30
000078d1a57df8cf  movaps [rsp], xmm4
000078d1a57df8d3  movaps [rsp+0x10], xmm13
000078d1a57df8d9  movaps [rsp+0x20], xmm8
000078d1a57df8df  lea rdi, [rsp]
000078d1a57df8e3  mov esi, 0x00
000078d1a57df8e8  mov rax, 0x56EA20A26530
000078d1a57df8f2  call rax
000078d1a57df8f4  movaps xmm4, [rsp]
000078d1a57df8f8  add rsp, 0x30
000078d1a57df8fc  vmovaps xmm0, [rsp]
000078d1a57df901  vmovaps xmm1, [rsp+0x10]
000078d1a57df907  vmovaps xmm2, [rsp+0x20]
000078d1a57df90d  vmovaps xmm3, [rsp+0x30]
000078d1a57df913  vmovaps xmm5, [rsp+0x40]
000078d1a57df919  vmovaps xmm6, [rsp+0x50]
000078d1a57df91f  vmovaps xmm7, [rsp+0x60]
000078d1a57df925  vmovaps xmm8, [rsp+0x70]
000078d1a57df92b  vmovaps xmm9, [rsp+0x80]
000078d1a57df934  vmovaps xmm10, [rsp+0x90]
000078d1a57df93d  vmovaps xmm11, [rsp+0xA0]
000078d1a57df946  vmovaps xmm12, [rsp+0xB0]
000078d1a57df94f  vmovaps xmm13, [rsp+0xC0]
000078d1a57df958  vmovaps xmm14, [rsp+0xD0]
000078d1a57df961  vmovaps xmm15, [rsp+0xE0]
000078d1a57df96a  add rsp, 0xF0
000078d1a57df971  pop r11
000078d1a57df973  pop r10
000078d1a57df975  pop r9
000078d1a57df977  pop r8
000078d1a57df979  pop rsi
000078d1a57df97a  pop rdi
000078d1a57df97b  pop rdx
000078d1a57df97c  pop rcx
000078d1a57df97d  pop rax
000078d1a57df97e  add rsp, 0x08
000078d1a57df982  jmp 0x000078D1A57DC43D
000078d1a57df987  sub rsp, 0x08
000078d1a57df98b  push rax
000078d1a57df98c  push rcx
000078d1a57df98d  push rdx
000078d1a57df98e  push rdi
000078d1a57df98f  push rsi
000078d1a57df990  push r8
000078d1a57df992  push r9
000078d1a57df994  push r10
000078d1a57df996  push r11
000078d1a57df998  sub rsp, 0xF0
000078d1a57df99f  vmovaps [rsp], xmm0
000078d1a57df9a4  vmovaps [rsp+0x10], xmm1
000078d1a57df9aa  vmovaps [rsp+0x20], xmm2
000078d1a57df9b0  vmovaps [rsp+0x30], xmm3
000078d1a57df9b6  vmovaps [rsp+0x40], xmm4
000078d1a57df9bc  vmovaps [rsp+0x50], xmm5
000078d1a57df9c2  vmovaps [rsp+0x60], xmm6
000078d1a57df9c8  vmovaps [rsp+0x70], xmm7
000078d1a57df9ce  vmovaps [rsp+0x80], xmm8
000078d1a57df9d7  vmovaps [rsp+0x90], xmm9
000078d1a57df9e0  vmovaps [rsp+0xA0], xmm10
000078d1a57df9e9  vmovaps [rsp+0xB0], xmm11
000078d1a57df9f2  vmovaps [rsp+0xC0], xmm12
000078d1a57df9fb  vmovaps [rsp+0xD0], xmm14
000078d1a57dfa04  vmovaps [rsp+0xE0], xmm15
000078d1a57dfa0d  sub rsp, 0x30
000078d1a57dfa11  movaps [rsp], xmm13
000078d1a57dfa16  movaps [rsp+0x10], xmm15
000078d1a57dfa1c  movaps [rsp+0x20], xmm9
000078d1a57dfa22  lea rdi, [rsp]
000078d1a57dfa26  mov esi, 0x00
000078d1a57dfa2b  mov rax, 0x56EA20A26530
000078d1a57dfa35  call rax
000078d1a57dfa37  movaps xmm13, [rsp]
000078d1a57dfa3c  add rsp, 0x30
000078d1a57dfa40  vmovaps xmm0, [rsp]
000078d1a57dfa45  vmovaps xmm1, [rsp+0x10]
000078d1a57dfa4b  vmovaps xmm2, [rsp+0x20]
000078d1a57dfa51  vmovaps xmm3, [rsp+0x30]
000078d1a57dfa57  vmovaps xmm4, [rsp+0x40]
000078d1a57dfa5d  vmovaps xmm5, [rsp+0x50]
000078d1a57dfa63  vmovaps xmm6, [rsp+0x60]
000078d1a57dfa69  vmovaps xmm7, [rsp+0x70]
000078d1a57dfa6f  vmovaps xmm8, [rsp+0x80]
000078d1a57dfa78  vmovaps xmm9, [rsp+0x90]
000078d1a57dfa81  vmovaps xmm10, [rsp+0xA0]
000078d1a57dfa8a  vmovaps xmm11, [rsp+0xB0]
000078d1a57dfa93  vmovaps xmm12, [rsp+0xC0]
000078d1a57dfa9c  vmovaps xmm14, [rsp+0xD0]
000078d1a57dfaa5  vmovaps xmm15, [rsp+0xE0]
000078d1a57dfaae  add rsp, 0xF0
000078d1a57dfab5  pop r11
000078d1a57dfab7  pop r10
000078d1a57dfab9  pop r9
000078d1a57dfabb  pop r8
000078d1a57dfabd  pop rsi
000078d1a57dfabe  pop rdi
000078d1a57dfabf  pop rdx
000078d1a57dfac0  pop rcx
000078d1a57dfac1  pop rax
000078d1a57dfac2  add rsp, 0x08
000078d1a57dfac6  jmp 0x000078D1A57DC458
000078d1a57dfacb  sub rsp, 0x08
000078d1a57dfacf  push rax
000078d1a57dfad0  push rcx
000078d1a57dfad1  push rdx
000078d1a57dfad2  push rdi
000078d1a57dfad3  push rsi
000078d1a57dfad4  push r8
000078d1a57dfad6  push r9
000078d1a57dfad8  push r10
000078d1a57dfada  push r11
000078d1a57dfadc  sub rsp, 0xF0
000078d1a57dfae3  vmovaps [rsp], xmm0
000078d1a57dfae8  vmovaps [rsp+0x10], xmm1
000078d1a57dfaee  vmovaps [rsp+0x20], xmm2
000078d1a57dfaf4  vmovaps [rsp+0x30], xmm3
000078d1a57dfafa  vmovaps [rsp+0x40], xmm4
000078d1a57dfb00  vmovaps [rsp+0x50], xmm5
000078d1a57dfb06  vmovaps [rsp+0x60], xmm6
000078d1a57dfb0c  vmovaps [rsp+0x70], xmm7
000078d1a57dfb12  vmovaps [rsp+0x80], xmm8
000078d1a57dfb1b  vmovaps [rsp+0x90], xmm9
000078d1a57dfb24  vmovaps [rsp+0xA0], xmm10
000078d1a57dfb2d  vmovaps [rsp+0xB0], xmm11
000078d1a57dfb36  vmovaps [rsp+0xC0], xmm12
000078d1a57dfb3f  vmovaps [rsp+0xD0], xmm13
000078d1a57dfb48  vmovaps [rsp+0xE0], xmm14
000078d1a57dfb51  sub rsp, 0x30
000078d1a57dfb55  movaps [rsp], xmm15
000078d1a57dfb5a  movaps [rsp+0x10], xmm1
000078d1a57dfb5f  movaps [rsp+0x20], xmm5
000078d1a57dfb64  lea rdi, [rsp]
000078d1a57dfb68  mov esi, 0x00
000078d1a57dfb6d  mov rax, 0x56EA20A26530
000078d1a57dfb77  call rax
000078d1a57dfb79  movaps xmm15, [rsp]
000078d1a57dfb7e  add rsp, 0x30
000078d1a57dfb82  vmovaps xmm0, [rsp]
000078d1a57dfb87  vmovaps xmm1, [rsp+0x10]
000078d1a57dfb8d  vmovaps xmm2, [rsp+0x20]
000078d1a57dfb93  vmovaps xmm3, [rsp+0x30]
000078d1a57dfb99  vmovaps xmm4, [rsp+0x40]
000078d1a57dfb9f  vmovaps xmm5, [rsp+0x50]
000078d1a57dfba5  vmovaps xmm6, [rsp+0x60]
000078d1a57dfbab  vmovaps xmm7, [rsp+0x70]
000078d1a57dfbb1  vmovaps xmm8, [rsp+0x80]
000078d1a57dfbba  vmovaps xmm9, [rsp+0x90]
000078d1a57dfbc3  vmovaps xmm10, [rsp+0xA0]
000078d1a57dfbcc  vmovaps xmm11, [rsp+0xB0]
000078d1a57dfbd5  vmovaps xmm12, [rsp+0xC0]
000078d1a57dfbde  vmovaps xmm13, [rsp+0xD0]
000078d1a57dfbe7  vmovaps xmm14, [rsp+0xE0]
000078d1a57dfbf0  add rsp, 0xF0
000078d1a57dfbf7  pop r11
000078d1a57dfbf9  pop r10
000078d1a57dfbfb  pop r9
000078d1a57dfbfd  pop r8
000078d1a57dfbff  pop rsi
000078d1a57dfc00  pop rdi
000078d1a57dfc01  pop rdx
000078d1a57dfc02  pop rcx
000078d1a57dfc03  pop rax
000078d1a57dfc04  add rsp, 0x08
000078d1a57dfc08  jmp 0x000078D1A57DC473
000078d1a57dfc0d  call 0x000078D1A56B52F0
000078d1a57dfc12  jmp 0x000078D1A57DC4CE
000078d1a57dfc17  sub rsp, 0x08
000078d1a57dfc1b  push rax
000078d1a57dfc1c  push rcx
000078d1a57dfc1d  push rdx
000078d1a57dfc1e  push rdi
000078d1a57dfc1f  push rsi
000078d1a57dfc20  push r8
000078d1a57dfc22  push r9
000078d1a57dfc24  push r10
000078d1a57dfc26  push r11
000078d1a57dfc28  sub rsp, 0xF0
000078d1a57dfc2f  vmovaps [rsp], xmm0
000078d1a57dfc34  vmovaps [rsp+0x10], xmm1
000078d1a57dfc3a  vmovaps [rsp+0x20], xmm2
000078d1a57dfc40  vmovaps [rsp+0x30], xmm3
000078d1a57dfc46  vmovaps [rsp+0x40], xmm4
000078d1a57dfc4c  vmovaps [rsp+0x50], xmm5
000078d1a57dfc52  vmovaps [rsp+0x60], xmm6
000078d1a57dfc58  vmovaps [rsp+0x70], xmm7
000078d1a57dfc5e  vmovaps [rsp+0x80], xmm8
000078d1a57dfc67  vmovaps [rsp+0x90], xmm10
000078d1a57dfc70  vmovaps [rsp+0xA0], xmm11
000078d1a57dfc79  vmovaps [rsp+0xB0], xmm12
000078d1a57dfc82  vmovaps [rsp+0xC0], xmm13
000078d1a57dfc8b  vmovaps [rsp+0xD0], xmm14
000078d1a57dfc94  vmovaps [rsp+0xE0], xmm15
000078d1a57dfc9d  sub rsp, 0x30
000078d1a57dfca1  movaps [rsp], xmm9
000078d1a57dfca6  movaps [rsp+0x10], xmm8
000078d1a57dfcac  movaps [rsp+0x20], xmm11
000078d1a57dfcb2  lea rdi, [rsp]
000078d1a57dfcb6  mov esi, 0x00
000078d1a57dfcbb  mov rax, 0x56EA20A26530
000078d1a57dfcc5  call rax
000078d1a57dfcc7  movaps xmm9, [rsp]
000078d1a57dfccc  add rsp, 0x30
000078d1a57dfcd0  vmovaps xmm0, [rsp]
000078d1a57dfcd5  vmovaps xmm1, [rsp+0x10]
000078d1a57dfcdb  vmovaps xmm2, [rsp+0x20]
000078d1a57dfce1  vmovaps xmm3, [rsp+0x30]
000078d1a57dfce7  vmovaps xmm4, [rsp+0x40]
000078d1a57dfced  vmovaps xmm5, [rsp+0x50]
000078d1a57dfcf3  vmovaps xmm6, [rsp+0x60]
000078d1a57dfcf9  vmovaps xmm7, [rsp+0x70]
000078d1a57dfcff  vmovaps xmm8, [rsp+0x80]
000078d1a57dfd08  vmovaps xmm10, [rsp+0x90]
000078d1a57dfd11  vmovaps xmm11, [rsp+0xA0]
000078d1a57dfd1a  vmovaps xmm12, [rsp+0xB0]
000078d1a57dfd23  vmovaps xmm13, [rsp+0xC0]
000078d1a57dfd2c  vmovaps xmm14, [rsp+0xD0]
000078d1a57dfd35  vmovaps xmm15, [rsp+0xE0]
000078d1a57dfd3e  add rsp, 0xF0
000078d1a57dfd45  pop r11
000078d1a57dfd47  pop r10
000078d1a57dfd49  pop r9
000078d1a57dfd4b  pop r8
000078d1a57dfd4d  pop rsi
000078d1a57dfd4e  pop rdi
000078d1a57dfd4f  pop rdx
000078d1a57dfd50  pop rcx
000078d1a57dfd51  pop rax
000078d1a57dfd52  add rsp, 0x08
000078d1a57dfd56  jmp 0x000078D1A57DC505
000078d1a57dfd5b  sub rsp, 0x08
000078d1a57dfd5f  push rax
000078d1a57dfd60  push rcx
000078d1a57dfd61  push rdx
000078d1a57dfd62  push rdi
000078d1a57dfd63  push rsi
000078d1a57dfd64  push r8
000078d1a57dfd66  push r9
000078d1a57dfd68  push r10
000078d1a57dfd6a  push r11
000078d1a57dfd6c  sub rsp, 0xF0
000078d1a57dfd73  vmovaps [rsp], xmm0
000078d1a57dfd78  vmovaps [rsp+0x10], xmm1
000078d1a57dfd7e  vmovaps [rsp+0x20], xmm2
000078d1a57dfd84  vmovaps [rsp+0x30], xmm3
000078d1a57dfd8a  vmovaps [rsp+0x40], xmm4
000078d1a57dfd90  vmovaps [rsp+0x50], xmm5
000078d1a57dfd96  vmovaps [rsp+0x60], xmm6
000078d1a57dfd9c  vmovaps [rsp+0x70], xmm7
000078d1a57dfda2  vmovaps [rsp+0x80], xmm8
000078d1a57dfdab  vmovaps [rsp+0x90], xmm9
000078d1a57dfdb4  vmovaps [rsp+0xA0], xmm10
000078d1a57dfdbd  vmovaps [rsp+0xB0], xmm12
000078d1a57dfdc6  vmovaps [rsp+0xC0], xmm13
000078d1a57dfdcf  vmovaps [rsp+0xD0], xmm14
000078d1a57dfdd8  vmovaps [rsp+0xE0], xmm15
000078d1a57dfde1  sub rsp, 0x30
000078d1a57dfde5  movaps [rsp], xmm11
000078d1a57dfdea  movaps [rsp+0x10], xmm10
000078d1a57dfdf0  movaps [rsp+0x20], xmm6
000078d1a57dfdf5  lea rdi, [rsp]
000078d1a57dfdf9  mov esi, 0x00
000078d1a57dfdfe  mov rax, 0x56EA20A26530
000078d1a57dfe08  call rax
000078d1a57dfe0a  movaps xmm11, [rsp]
000078d1a57dfe0f  add rsp, 0x30
000078d1a57dfe13  vmovaps xmm0, [rsp]
000078d1a57dfe18  vmovaps xmm1, [rsp+0x10]
000078d1a57dfe1e  vmovaps xmm2, [rsp+0x20]
000078d1a57dfe24  vmovaps xmm3, [rsp+0x30]
000078d1a57dfe2a  vmovaps xmm4, [rsp+0x40]
000078d1a57dfe30  vmovaps xmm5, [rsp+0x50]
000078d1a57dfe36  vmovaps xmm6, [rsp+0x60]
000078d1a57dfe3c  vmovaps xmm7, [rsp+0x70]
000078d1a57dfe42  vmovaps xmm8, [rsp+0x80]
000078d1a57dfe4b  vmovaps xmm9, [rsp+0x90]
000078d1a57dfe54  vmovaps xmm10, [rsp+0xA0]
000078d1a57dfe5d  vmovaps xmm12, [rsp+0xB0]
000078d1a57dfe66  vmovaps xmm13, [rsp+0xC0]
000078d1a57dfe6f  vmovaps xmm14, [rsp+0xD0]
000078d1a57dfe78  vmovaps xmm15, [rsp+0xE0]
000078d1a57dfe81  add rsp, 0xF0
000078d1a57dfe88  pop r11
000078d1a57dfe8a  pop r10
000078d1a57dfe8c  pop r9
000078d1a57dfe8e  pop r8
000078d1a57dfe90  pop rsi
000078d1a57dfe91  pop rdi
000078d1a57dfe92  pop rdx
000078d1a57dfe93  pop rcx
000078d1a57dfe94  pop rax
000078d1a57dfe95  add rsp, 0x08
000078d1a57dfe99  jmp 0x000078D1A57DC520
000078d1a57dfe9e  sub rsp, 0x08
000078d1a57dfea2  push rax
000078d1a57dfea3  push rcx
000078d1a57dfea4  push rdx
000078d1a57dfea5  push rdi
000078d1a57dfea6  push rsi
000078d1a57dfea7  push r8
000078d1a57dfea9  push r9
000078d1a57dfeab  push r10
000078d1a57dfead  push r11
000078d1a57dfeaf  sub rsp, 0xF0
000078d1a57dfeb6  vmovaps [rsp], xmm0
000078d1a57dfebb  vmovaps [rsp+0x10], xmm1
000078d1a57dfec1  vmovaps [rsp+0x20], xmm2
000078d1a57dfec7  vmovaps [rsp+0x30], xmm3
000078d1a57dfecd  vmovaps [rsp+0x40], xmm4
000078d1a57dfed3  vmovaps [rsp+0x50], xmm5
000078d1a57dfed9  vmovaps [rsp+0x60], xmm6
000078d1a57dfedf  vmovaps [rsp+0x70], xmm7
000078d1a57dfee5  vmovaps [rsp+0x80], xmm8
000078d1a57dfeee  vmovaps [rsp+0x90], xmm9
000078d1a57dfef7  vmovaps [rsp+0xA0], xmm11
000078d1a57dff00  vmovaps [rsp+0xB0], xmm12
000078d1a57dff09  vmovaps [rsp+0xC0], xmm13
000078d1a57dff12  vmovaps [rsp+0xD0], xmm14
000078d1a57dff1b  vmovaps [rsp+0xE0], xmm15
000078d1a57dff24  sub rsp, 0x30
000078d1a57dff28  movaps [rsp], xmm10
000078d1a57dff2d  movaps [rsp+0x10], xmm14
000078d1a57dff33  movaps [rsp+0x20], xmm4
000078d1a57dff38  lea rdi, [rsp]
000078d1a57dff3c  mov esi, 0x00
000078d1a57dff41  mov rax, 0x56EA20A26530
000078d1a57dff4b  call rax
000078d1a57dff4d  movaps xmm10, [rsp]
000078d1a57dff52  add rsp, 0x30
000078d1a57dff56  vmovaps xmm0, [rsp]
000078d1a57dff5b  vmovaps xmm1, [rsp+0x10]
000078d1a57dff61  vmovaps xmm2, [rsp+0x20]
000078d1a57dff67  vmovaps xmm3, [rsp+0x30]
000078d1a57dff6d  vmovaps xmm4, [rsp+0x40]
000078d1a57dff73  vmovaps xmm5, [rsp+0x50]
000078d1a57dff79  vmovaps xmm6, [rsp+0x60]
000078d1a57dff7f  vmovaps xmm7, [rsp+0x70]
000078d1a57dff85  vmovaps xmm8, [rsp+0x80]
000078d1a57dff8e  vmovaps xmm9, [rsp+0x90]
000078d1a57dff97  vmovaps xmm11, [rsp+0xA0]
000078d1a57dffa0  vmovaps xmm12, [rsp+0xB0]
000078d1a57dffa9  vmovaps xmm13, [rsp+0xC0]
000078d1a57dffb2  vmovaps xmm14, [rsp+0xD0]
000078d1a57dffbb  vmovaps xmm15, [rsp+0xE0]
000078d1a57dffc4  add rsp, 0xF0
000078d1a57dffcb  pop r11
000078d1a57dffcd  pop r10
000078d1a57dffcf  pop r9
000078d1a57dffd1  pop r8
000078d1a57dffd3  pop rsi
000078d1a57dffd4  pop rdi
000078d1a57dffd5  pop rdx
000078d1a57dffd6  pop rcx
000078d1a57dffd7  pop rax
000078d1a57dffd8  add rsp, 0x08
000078d1a57dffdc  jmp 0x000078D1A57DC53B
000078d1a57dffe1  sub rsp, 0x08
000078d1a57dffe5  push rax
000078d1a57dffe6  push rcx
000078d1a57dffe7  push rdx
000078d1a57dffe8  push rdi
000078d1a57dffe9  push rsi
000078d1a57dffea  push r8
000078d1a57dffec  push r9
000078d1a57dffee  push r10
000078d1a57dfff0  push r11
000078d1a57dfff2  sub rsp, 0xF0
000078d1a57dfff9  vmovaps [rsp], xmm0
000078d1a57dfffe  vmovaps [rsp+0x10], xmm1
000078d1a57e0004  vmovaps [rsp+0x20], xmm2
000078d1a57e000a  vmovaps [rsp+0x30], xmm3
000078d1a57e0010  vmovaps [rsp+0x40], xmm4
000078d1a57e0016  vmovaps [rsp+0x50], xmm5
000078d1a57e001c  vmovaps [rsp+0x60], xmm6
000078d1a57e0022  vmovaps [rsp+0x70], xmm7
000078d1a57e0028  vmovaps [rsp+0x80], xmm9
000078d1a57e0031  vmovaps [rsp+0x90], xmm10
000078d1a57e003a  vmovaps [rsp+0xA0], xmm11
000078d1a57e0043  vmovaps [rsp+0xB0], xmm12
000078d1a57e004c  vmovaps [rsp+0xC0], xmm13
000078d1a57e0055  vmovaps [rsp+0xD0], xmm14
000078d1a57e005e  vmovaps [rsp+0xE0], xmm15
000078d1a57e0067  sub rsp, 0x30
000078d1a57e006b  movaps [rsp], xmm8
000078d1a57e0070  movaps [rsp+0x10], xmm1
000078d1a57e0075  movaps [rsp+0x20], xmm14
000078d1a57e007b  lea rdi, [rsp]
000078d1a57e007f  mov esi, 0x00
000078d1a57e0084  mov rax, 0x56EA20A26530
000078d1a57e008e  call rax
000078d1a57e0090  movaps xmm8, [rsp]
000078d1a57e0095  add rsp, 0x30
000078d1a57e0099  vmovaps xmm0, [rsp]
000078d1a57e009e  vmovaps xmm1, [rsp+0x10]
000078d1a57e00a4  vmovaps xmm2, [rsp+0x20]
000078d1a57e00aa  vmovaps xmm3, [rsp+0x30]
000078d1a57e00b0  vmovaps xmm4, [rsp+0x40]
000078d1a57e00b6  vmovaps xmm5, [rsp+0x50]
000078d1a57e00bc  vmovaps xmm6, [rsp+0x60]
000078d1a57e00c2  vmovaps xmm7, [rsp+0x70]
000078d1a57e00c8  vmovaps xmm9, [rsp+0x80]
000078d1a57e00d1  vmovaps xmm10, [rsp+0x90]
000078d1a57e00da  vmovaps xmm11, [rsp+0xA0]
000078d1a57e00e3  vmovaps xmm12, [rsp+0xB0]
000078d1a57e00ec  vmovaps xmm13, [rsp+0xC0]
000078d1a57e00f5  vmovaps xmm14, [rsp+0xD0]
000078d1a57e00fe  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0107  add rsp, 0xF0
000078d1a57e010e  pop r11
000078d1a57e0110  pop r10
000078d1a57e0112  pop r9
000078d1a57e0114  pop r8
000078d1a57e0116  pop rsi
000078d1a57e0117  pop rdi
000078d1a57e0118  pop rdx
000078d1a57e0119  pop rcx
000078d1a57e011a  pop rax
000078d1a57e011b  add rsp, 0x08
000078d1a57e011f  jmp 0x000078D1A57DC561
000078d1a57e0124  sub rsp, 0x08
000078d1a57e0128  push rax
000078d1a57e0129  push rcx
000078d1a57e012a  push rdx
000078d1a57e012b  push rdi
000078d1a57e012c  push rsi
000078d1a57e012d  push r8
000078d1a57e012f  push r9
000078d1a57e0131  push r10
000078d1a57e0133  push r11
000078d1a57e0135  sub rsp, 0xF0
000078d1a57e013c  vmovaps [rsp], xmm0
000078d1a57e0141  vmovaps [rsp+0x10], xmm1
000078d1a57e0147  vmovaps [rsp+0x20], xmm2
000078d1a57e014d  vmovaps [rsp+0x30], xmm3
000078d1a57e0153  vmovaps [rsp+0x40], xmm4
000078d1a57e0159  vmovaps [rsp+0x50], xmm5
000078d1a57e015f  vmovaps [rsp+0x60], xmm7
000078d1a57e0165  vmovaps [rsp+0x70], xmm8
000078d1a57e016b  vmovaps [rsp+0x80], xmm9
000078d1a57e0174  vmovaps [rsp+0x90], xmm10
000078d1a57e017d  vmovaps [rsp+0xA0], xmm11
000078d1a57e0186  vmovaps [rsp+0xB0], xmm12
000078d1a57e018f  vmovaps [rsp+0xC0], xmm13
000078d1a57e0198  vmovaps [rsp+0xD0], xmm14
000078d1a57e01a1  vmovaps [rsp+0xE0], xmm15
000078d1a57e01aa  sub rsp, 0x30
000078d1a57e01ae  movaps [rsp], xmm6
000078d1a57e01b2  movaps [rsp+0x10], xmm1
000078d1a57e01b7  movaps [rsp+0x20], xmm14
000078d1a57e01bd  lea rdi, [rsp]
000078d1a57e01c1  mov esi, 0x00
000078d1a57e01c6  mov rax, 0x56EA20A26530
000078d1a57e01d0  call rax
000078d1a57e01d2  movaps xmm6, [rsp]
000078d1a57e01d6  add rsp, 0x30
000078d1a57e01da  vmovaps xmm0, [rsp]
000078d1a57e01df  vmovaps xmm1, [rsp+0x10]
000078d1a57e01e5  vmovaps xmm2, [rsp+0x20]
000078d1a57e01eb  vmovaps xmm3, [rsp+0x30]
000078d1a57e01f1  vmovaps xmm4, [rsp+0x40]
000078d1a57e01f7  vmovaps xmm5, [rsp+0x50]
000078d1a57e01fd  vmovaps xmm7, [rsp+0x60]
000078d1a57e0203  vmovaps xmm8, [rsp+0x70]
000078d1a57e0209  vmovaps xmm9, [rsp+0x80]
000078d1a57e0212  vmovaps xmm10, [rsp+0x90]
000078d1a57e021b  vmovaps xmm11, [rsp+0xA0]
000078d1a57e0224  vmovaps xmm12, [rsp+0xB0]
000078d1a57e022d  vmovaps xmm13, [rsp+0xC0]
000078d1a57e0236  vmovaps xmm14, [rsp+0xD0]
000078d1a57e023f  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0248  add rsp, 0xF0
000078d1a57e024f  pop r11
000078d1a57e0251  pop r10
000078d1a57e0253  pop r9
000078d1a57e0255  pop r8
000078d1a57e0257  pop rsi
000078d1a57e0258  pop rdi
000078d1a57e0259  pop rdx
000078d1a57e025a  pop rcx
000078d1a57e025b  pop rax
000078d1a57e025c  add rsp, 0x08
000078d1a57e0260  jmp 0x000078D1A57DC58D
000078d1a57e0265  sub rsp, 0x08
000078d1a57e0269  push rax
000078d1a57e026a  push rcx
000078d1a57e026b  push rdx
000078d1a57e026c  push rdi
000078d1a57e026d  push rsi
000078d1a57e026e  push r8
000078d1a57e0270  push r9
000078d1a57e0272  push r10
000078d1a57e0274  push r11
000078d1a57e0276  sub rsp, 0xF0
000078d1a57e027d  vmovaps [rsp], xmm0
000078d1a57e0282  vmovaps [rsp+0x10], xmm1
000078d1a57e0288  vmovaps [rsp+0x20], xmm2
000078d1a57e028e  vmovaps [rsp+0x30], xmm3
000078d1a57e0294  vmovaps [rsp+0x40], xmm4
000078d1a57e029a  vmovaps [rsp+0x50], xmm5
000078d1a57e02a0  vmovaps [rsp+0x60], xmm6
000078d1a57e02a6  vmovaps [rsp+0x70], xmm7
000078d1a57e02ac  vmovaps [rsp+0x80], xmm8
000078d1a57e02b5  vmovaps [rsp+0x90], xmm9
000078d1a57e02be  vmovaps [rsp+0xA0], xmm10
000078d1a57e02c7  vmovaps [rsp+0xB0], xmm11
000078d1a57e02d0  vmovaps [rsp+0xC0], xmm12
000078d1a57e02d9  vmovaps [rsp+0xD0], xmm13
000078d1a57e02e2  vmovaps [rsp+0xE0], xmm15
000078d1a57e02eb  sub rsp, 0x30
000078d1a57e02ef  movaps [rsp], xmm14
000078d1a57e02f4  movaps [rsp+0x10], xmm12
000078d1a57e02fa  movaps [rsp+0x20], xmm1
000078d1a57e02ff  lea rdi, [rsp]
000078d1a57e0303  mov esi, 0x00
000078d1a57e0308  mov rax, 0x56EA20A26530
000078d1a57e0312  call rax
000078d1a57e0314  movaps xmm14, [rsp]
000078d1a57e0319  add rsp, 0x30
000078d1a57e031d  vmovaps xmm0, [rsp]
000078d1a57e0322  vmovaps xmm1, [rsp+0x10]
000078d1a57e0328  vmovaps xmm2, [rsp+0x20]
000078d1a57e032e  vmovaps xmm3, [rsp+0x30]
000078d1a57e0334  vmovaps xmm4, [rsp+0x40]
000078d1a57e033a  vmovaps xmm5, [rsp+0x50]
000078d1a57e0340  vmovaps xmm6, [rsp+0x60]
000078d1a57e0346  vmovaps xmm7, [rsp+0x70]
000078d1a57e034c  vmovaps xmm8, [rsp+0x80]
000078d1a57e0355  vmovaps xmm9, [rsp+0x90]
000078d1a57e035e  vmovaps xmm10, [rsp+0xA0]
000078d1a57e0367  vmovaps xmm11, [rsp+0xB0]
000078d1a57e0370  vmovaps xmm12, [rsp+0xC0]
000078d1a57e0379  vmovaps xmm13, [rsp+0xD0]
000078d1a57e0382  vmovaps xmm15, [rsp+0xE0]
000078d1a57e038b  add rsp, 0xF0
000078d1a57e0392  pop r11
000078d1a57e0394  pop r10
000078d1a57e0396  pop r9
000078d1a57e0398  pop r8
000078d1a57e039a  pop rsi
000078d1a57e039b  pop rdi
000078d1a57e039c  pop rdx
000078d1a57e039d  pop rcx
000078d1a57e039e  pop rax
000078d1a57e039f  add rsp, 0x08
000078d1a57e03a3  jmp 0x000078D1A57DC5B3
000078d1a57e03a8  sub rsp, 0x08
000078d1a57e03ac  push rax
000078d1a57e03ad  push rcx
000078d1a57e03ae  push rdx
000078d1a57e03af  push rdi
000078d1a57e03b0  push rsi
000078d1a57e03b1  push r8
000078d1a57e03b3  push r9
000078d1a57e03b5  push r10
000078d1a57e03b7  push r11
000078d1a57e03b9  sub rsp, 0xF0
000078d1a57e03c0  vmovaps [rsp], xmm0
000078d1a57e03c5  vmovaps [rsp+0x10], xmm2
000078d1a57e03cb  vmovaps [rsp+0x20], xmm3
000078d1a57e03d1  vmovaps [rsp+0x30], xmm4
000078d1a57e03d7  vmovaps [rsp+0x40], xmm5
000078d1a57e03dd  vmovaps [rsp+0x50], xmm6
000078d1a57e03e3  vmovaps [rsp+0x60], xmm7
000078d1a57e03e9  vmovaps [rsp+0x70], xmm8
000078d1a57e03ef  vmovaps [rsp+0x80], xmm9
000078d1a57e03f8  vmovaps [rsp+0x90], xmm10
000078d1a57e0401  vmovaps [rsp+0xA0], xmm11
000078d1a57e040a  vmovaps [rsp+0xB0], xmm12
000078d1a57e0413  vmovaps [rsp+0xC0], xmm13
000078d1a57e041c  vmovaps [rsp+0xD0], xmm14
000078d1a57e0425  vmovaps [rsp+0xE0], xmm15
000078d1a57e042e  sub rsp, 0x30
000078d1a57e0432  movaps [rsp], xmm1
000078d1a57e0436  movaps [rsp+0x10], xmm13
000078d1a57e043c  movaps [rsp+0x20], xmm9
000078d1a57e0442  lea rdi, [rsp]
000078d1a57e0446  mov esi, 0x00
000078d1a57e044b  mov rax, 0x56EA20A26530
000078d1a57e0455  call rax
000078d1a57e0457  movaps xmm1, [rsp]
000078d1a57e045b  add rsp, 0x30
000078d1a57e045f  vmovaps xmm0, [rsp]
000078d1a57e0464  vmovaps xmm2, [rsp+0x10]
000078d1a57e046a  vmovaps xmm3, [rsp+0x20]
000078d1a57e0470  vmovaps xmm4, [rsp+0x30]
000078d1a57e0476  vmovaps xmm5, [rsp+0x40]
000078d1a57e047c  vmovaps xmm6, [rsp+0x50]
000078d1a57e0482  vmovaps xmm7, [rsp+0x60]
000078d1a57e0488  vmovaps xmm8, [rsp+0x70]
000078d1a57e048e  vmovaps xmm9, [rsp+0x80]
000078d1a57e0497  vmovaps xmm10, [rsp+0x90]
000078d1a57e04a0  vmovaps xmm11, [rsp+0xA0]
000078d1a57e04a9  vmovaps xmm12, [rsp+0xB0]
000078d1a57e04b2  vmovaps xmm13, [rsp+0xC0]
000078d1a57e04bb  vmovaps xmm14, [rsp+0xD0]
000078d1a57e04c4  vmovaps xmm15, [rsp+0xE0]
000078d1a57e04cd  add rsp, 0xF0
000078d1a57e04d4  pop r11
000078d1a57e04d6  pop r10
000078d1a57e04d8  pop r9
000078d1a57e04da  pop r8
000078d1a57e04dc  pop rsi
000078d1a57e04dd  pop rdi
000078d1a57e04de  pop rdx
000078d1a57e04df  pop rcx
000078d1a57e04e0  pop rax
000078d1a57e04e1  add rsp, 0x08
000078d1a57e04e5  jmp 0x000078D1A57DC5CD
000078d1a57e04ea  sub rsp, 0x08
000078d1a57e04ee  push rax
000078d1a57e04ef  push rcx
000078d1a57e04f0  push rdx
000078d1a57e04f1  push rdi
000078d1a57e04f2  push rsi
000078d1a57e04f3  push r8
000078d1a57e04f5  push r9
000078d1a57e04f7  push r10
000078d1a57e04f9  push r11
000078d1a57e04fb  sub rsp, 0xF0
000078d1a57e0502  vmovaps [rsp], xmm0
000078d1a57e0507  vmovaps [rsp+0x10], xmm1
000078d1a57e050d  vmovaps [rsp+0x20], xmm2
000078d1a57e0513  vmovaps [rsp+0x30], xmm3
000078d1a57e0519  vmovaps [rsp+0x40], xmm4
000078d1a57e051f  vmovaps [rsp+0x50], xmm5
000078d1a57e0525  vmovaps [rsp+0x60], xmm6
000078d1a57e052b  vmovaps [rsp+0x70], xmm7
000078d1a57e0531  vmovaps [rsp+0x80], xmm8
000078d1a57e053a  vmovaps [rsp+0x90], xmm9
000078d1a57e0543  vmovaps [rsp+0xA0], xmm10
000078d1a57e054c  vmovaps [rsp+0xB0], xmm11
000078d1a57e0555  vmovaps [rsp+0xC0], xmm13
000078d1a57e055e  vmovaps [rsp+0xD0], xmm14
000078d1a57e0567  vmovaps [rsp+0xE0], xmm15
000078d1a57e0570  sub rsp, 0x30
000078d1a57e0574  movaps [rsp], xmm12
000078d1a57e0579  movaps [rsp+0x10], xmm7
000078d1a57e057e  movaps [rsp+0x20], xmm13
000078d1a57e0584  lea rdi, [rsp]
000078d1a57e0588  mov esi, 0x00
000078d1a57e058d  mov rax, 0x56EA20A26530
000078d1a57e0597  call rax
000078d1a57e0599  movaps xmm12, [rsp]
000078d1a57e059e  add rsp, 0x30
000078d1a57e05a2  vmovaps xmm0, [rsp]
000078d1a57e05a7  vmovaps xmm1, [rsp+0x10]
000078d1a57e05ad  vmovaps xmm2, [rsp+0x20]
000078d1a57e05b3  vmovaps xmm3, [rsp+0x30]
000078d1a57e05b9  vmovaps xmm4, [rsp+0x40]
000078d1a57e05bf  vmovaps xmm5, [rsp+0x50]
000078d1a57e05c5  vmovaps xmm6, [rsp+0x60]
000078d1a57e05cb  vmovaps xmm7, [rsp+0x70]
000078d1a57e05d1  vmovaps xmm8, [rsp+0x80]
000078d1a57e05da  vmovaps xmm9, [rsp+0x90]
000078d1a57e05e3  vmovaps xmm10, [rsp+0xA0]
000078d1a57e05ec  vmovaps xmm11, [rsp+0xB0]
000078d1a57e05f5  vmovaps xmm13, [rsp+0xC0]
000078d1a57e05fe  vmovaps xmm14, [rsp+0xD0]
000078d1a57e0607  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0610  add rsp, 0xF0
000078d1a57e0617  pop r11
000078d1a57e0619  pop r10
000078d1a57e061b  pop r9
000078d1a57e061d  pop r8
000078d1a57e061f  pop rsi
000078d1a57e0620  pop rdi
000078d1a57e0621  pop rdx
000078d1a57e0622  pop rcx
000078d1a57e0623  pop rax
000078d1a57e0624  add rsp, 0x08
000078d1a57e0628  jmp 0x000078D1A57DC5F4
000078d1a57e062d  sub rsp, 0x08
000078d1a57e0631  push rax
000078d1a57e0632  push rcx
000078d1a57e0633  push rdx
000078d1a57e0634  push rdi
000078d1a57e0635  push rsi
000078d1a57e0636  push r8
000078d1a57e0638  push r9
000078d1a57e063a  push r10
000078d1a57e063c  push r11
000078d1a57e063e  sub rsp, 0xF0
000078d1a57e0645  vmovaps [rsp], xmm0
000078d1a57e064a  vmovaps [rsp+0x10], xmm1
000078d1a57e0650  vmovaps [rsp+0x20], xmm2
000078d1a57e0656  vmovaps [rsp+0x30], xmm3
000078d1a57e065c  vmovaps [rsp+0x40], xmm4
000078d1a57e0662  vmovaps [rsp+0x50], xmm5
000078d1a57e0668  vmovaps [rsp+0x60], xmm6
000078d1a57e066e  vmovaps [rsp+0x70], xmm7
000078d1a57e0674  vmovaps [rsp+0x80], xmm8
000078d1a57e067d  vmovaps [rsp+0x90], xmm9
000078d1a57e0686  vmovaps [rsp+0xA0], xmm10
000078d1a57e068f  vmovaps [rsp+0xB0], xmm11
000078d1a57e0698  vmovaps [rsp+0xC0], xmm12
000078d1a57e06a1  vmovaps [rsp+0xD0], xmm14
000078d1a57e06aa  vmovaps [rsp+0xE0], xmm15
000078d1a57e06b3  sub rsp, 0x30
000078d1a57e06b7  movaps [rsp], xmm13
000078d1a57e06bc  movaps [rsp+0x10], xmm15
000078d1a57e06c2  movaps [rsp+0x20], xmm8
000078d1a57e06c8  lea rdi, [rsp]
000078d1a57e06cc  mov esi, 0x00
000078d1a57e06d1  mov rax, 0x56EA20A26530
000078d1a57e06db  call rax
000078d1a57e06dd  movaps xmm13, [rsp]
000078d1a57e06e2  add rsp, 0x30
000078d1a57e06e6  vmovaps xmm0, [rsp]
000078d1a57e06eb  vmovaps xmm1, [rsp+0x10]
000078d1a57e06f1  vmovaps xmm2, [rsp+0x20]
000078d1a57e06f7  vmovaps xmm3, [rsp+0x30]
000078d1a57e06fd  vmovaps xmm4, [rsp+0x40]
000078d1a57e0703  vmovaps xmm5, [rsp+0x50]
000078d1a57e0709  vmovaps xmm6, [rsp+0x60]
000078d1a57e070f  vmovaps xmm7, [rsp+0x70]
000078d1a57e0715  vmovaps xmm8, [rsp+0x80]
000078d1a57e071e  vmovaps xmm9, [rsp+0x90]
000078d1a57e0727  vmovaps xmm10, [rsp+0xA0]
000078d1a57e0730  vmovaps xmm11, [rsp+0xB0]
000078d1a57e0739  vmovaps xmm12, [rsp+0xC0]
000078d1a57e0742  vmovaps xmm14, [rsp+0xD0]
000078d1a57e074b  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0754  add rsp, 0xF0
000078d1a57e075b  pop r11
000078d1a57e075d  pop r10
000078d1a57e075f  pop r9
000078d1a57e0761  pop r8
000078d1a57e0763  pop rsi
000078d1a57e0764  pop rdi
000078d1a57e0765  pop rdx
000078d1a57e0766  pop rcx
000078d1a57e0767  pop rax
000078d1a57e0768  add rsp, 0x08
000078d1a57e076c  jmp 0x000078D1A57DC60F
000078d1a57e0771  sub rsp, 0x08
000078d1a57e0775  push rax
000078d1a57e0776  push rcx
000078d1a57e0777  push rdx
000078d1a57e0778  push rdi
000078d1a57e0779  push rsi
000078d1a57e077a  push r8
000078d1a57e077c  push r9
000078d1a57e077e  push r10
000078d1a57e0780  push r11
000078d1a57e0782  sub rsp, 0xF0
000078d1a57e0789  vmovaps [rsp], xmm0
000078d1a57e078e  vmovaps [rsp+0x10], xmm1
000078d1a57e0794  vmovaps [rsp+0x20], xmm2
000078d1a57e079a  vmovaps [rsp+0x30], xmm3
000078d1a57e07a0  vmovaps [rsp+0x40], xmm4
000078d1a57e07a6  vmovaps [rsp+0x50], xmm5
000078d1a57e07ac  vmovaps [rsp+0x60], xmm6
000078d1a57e07b2  vmovaps [rsp+0x70], xmm7
000078d1a57e07b8  vmovaps [rsp+0x80], xmm9
000078d1a57e07c1  vmovaps [rsp+0x90], xmm10
000078d1a57e07ca  vmovaps [rsp+0xA0], xmm11
000078d1a57e07d3  vmovaps [rsp+0xB0], xmm12
000078d1a57e07dc  vmovaps [rsp+0xC0], xmm13
000078d1a57e07e5  vmovaps [rsp+0xD0], xmm14
000078d1a57e07ee  vmovaps [rsp+0xE0], xmm15
000078d1a57e07f7  sub rsp, 0x30
000078d1a57e07fb  movaps [rsp], xmm8
000078d1a57e0800  movaps [rsp+0x10], xmm15
000078d1a57e0806  movaps [rsp+0x20], xmm9
000078d1a57e080c  lea rdi, [rsp]
000078d1a57e0810  mov esi, 0x00
000078d1a57e0815  mov rax, 0x56EA20A26530
000078d1a57e081f  call rax
000078d1a57e0821  movaps xmm8, [rsp]
000078d1a57e0826  add rsp, 0x30
000078d1a57e082a  vmovaps xmm0, [rsp]
000078d1a57e082f  vmovaps xmm1, [rsp+0x10]
000078d1a57e0835  vmovaps xmm2, [rsp+0x20]
000078d1a57e083b  vmovaps xmm3, [rsp+0x30]
000078d1a57e0841  vmovaps xmm4, [rsp+0x40]
000078d1a57e0847  vmovaps xmm5, [rsp+0x50]
000078d1a57e084d  vmovaps xmm6, [rsp+0x60]
000078d1a57e0853  vmovaps xmm7, [rsp+0x70]
000078d1a57e0859  vmovaps xmm9, [rsp+0x80]
000078d1a57e0862  vmovaps xmm10, [rsp+0x90]
000078d1a57e086b  vmovaps xmm11, [rsp+0xA0]
000078d1a57e0874  vmovaps xmm12, [rsp+0xB0]
000078d1a57e087d  vmovaps xmm13, [rsp+0xC0]
000078d1a57e0886  vmovaps xmm14, [rsp+0xD0]
000078d1a57e088f  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0898  add rsp, 0xF0
000078d1a57e089f  pop r11
000078d1a57e08a1  pop r10
000078d1a57e08a3  pop r9
000078d1a57e08a5  pop r8
000078d1a57e08a7  pop rsi
000078d1a57e08a8  pop rdi
000078d1a57e08a9  pop rdx
000078d1a57e08aa  pop rcx
000078d1a57e08ab  pop rax
000078d1a57e08ac  add rsp, 0x08
000078d1a57e08b0  jmp 0x000078D1A57DC63D
000078d1a57e08b5  sub rsp, 0x08
000078d1a57e08b9  push rax
000078d1a57e08ba  push rcx
000078d1a57e08bb  push rdx
000078d1a57e08bc  push rdi
000078d1a57e08bd  push rsi
000078d1a57e08be  push r8
000078d1a57e08c0  push r9
000078d1a57e08c2  push r10
000078d1a57e08c4  push r11
000078d1a57e08c6  sub rsp, 0xF0
000078d1a57e08cd  vmovaps [rsp], xmm0
000078d1a57e08d2  vmovaps [rsp+0x10], xmm1
000078d1a57e08d8  vmovaps [rsp+0x20], xmm2
000078d1a57e08de  vmovaps [rsp+0x30], xmm3
000078d1a57e08e4  vmovaps [rsp+0x40], xmm4
000078d1a57e08ea  vmovaps [rsp+0x50], xmm5
000078d1a57e08f0  vmovaps [rsp+0x60], xmm6
000078d1a57e08f6  vmovaps [rsp+0x70], xmm7
000078d1a57e08fc  vmovaps [rsp+0x80], xmm8
000078d1a57e0905  vmovaps [rsp+0x90], xmm9
000078d1a57e090e  vmovaps [rsp+0xA0], xmm10
000078d1a57e0917  vmovaps [rsp+0xB0], xmm11
000078d1a57e0920  vmovaps [rsp+0xC0], xmm12
000078d1a57e0929  vmovaps [rsp+0xD0], xmm13
000078d1a57e0932  vmovaps [rsp+0xE0], xmm14
000078d1a57e093b  sub rsp, 0x30
000078d1a57e093f  movaps [rsp], xmm15
000078d1a57e0944  movaps [rsp+0x10], xmm11
000078d1a57e094a  movaps [rsp+0x20], xmm6
000078d1a57e094f  lea rdi, [rsp]
000078d1a57e0953  mov esi, 0x00
000078d1a57e0958  mov rax, 0x56EA20A26530
000078d1a57e0962  call rax
000078d1a57e0964  movaps xmm15, [rsp]
000078d1a57e0969  add rsp, 0x30
000078d1a57e096d  vmovaps xmm0, [rsp]
000078d1a57e0972  vmovaps xmm1, [rsp+0x10]
000078d1a57e0978  vmovaps xmm2, [rsp+0x20]
000078d1a57e097e  vmovaps xmm3, [rsp+0x30]
000078d1a57e0984  vmovaps xmm4, [rsp+0x40]
000078d1a57e098a  vmovaps xmm5, [rsp+0x50]
000078d1a57e0990  vmovaps xmm6, [rsp+0x60]
000078d1a57e0996  vmovaps xmm7, [rsp+0x70]
000078d1a57e099c  vmovaps xmm8, [rsp+0x80]
000078d1a57e09a5  vmovaps xmm9, [rsp+0x90]
000078d1a57e09ae  vmovaps xmm10, [rsp+0xA0]
000078d1a57e09b7  vmovaps xmm11, [rsp+0xB0]
000078d1a57e09c0  vmovaps xmm12, [rsp+0xC0]
000078d1a57e09c9  vmovaps xmm13, [rsp+0xD0]
000078d1a57e09d2  vmovaps xmm14, [rsp+0xE0]
000078d1a57e09db  add rsp, 0xF0
000078d1a57e09e2  pop r11
000078d1a57e09e4  pop r10
000078d1a57e09e6  pop r9
000078d1a57e09e8  pop r8
000078d1a57e09ea  pop rsi
000078d1a57e09eb  pop rdi
000078d1a57e09ec  pop rdx
000078d1a57e09ed  pop rcx
000078d1a57e09ee  pop rax
000078d1a57e09ef  add rsp, 0x08
000078d1a57e09f3  jmp 0x000078D1A57DC658
000078d1a57e09f8  sub rsp, 0x08
000078d1a57e09fc  push rax
000078d1a57e09fd  push rcx
000078d1a57e09fe  push rdx
000078d1a57e09ff  push rdi
000078d1a57e0a00  push rsi
000078d1a57e0a01  push r8
000078d1a57e0a03  push r9
000078d1a57e0a05  push r10
000078d1a57e0a07  push r11
000078d1a57e0a09  sub rsp, 0xF0
000078d1a57e0a10  vmovaps [rsp], xmm0
000078d1a57e0a15  vmovaps [rsp+0x10], xmm1
000078d1a57e0a1b  vmovaps [rsp+0x20], xmm2
000078d1a57e0a21  vmovaps [rsp+0x30], xmm3
000078d1a57e0a27  vmovaps [rsp+0x40], xmm4
000078d1a57e0a2d  vmovaps [rsp+0x50], xmm5
000078d1a57e0a33  vmovaps [rsp+0x60], xmm6
000078d1a57e0a39  vmovaps [rsp+0x70], xmm8
000078d1a57e0a3f  vmovaps [rsp+0x80], xmm9
000078d1a57e0a48  vmovaps [rsp+0x90], xmm10
000078d1a57e0a51  vmovaps [rsp+0xA0], xmm11
000078d1a57e0a5a  vmovaps [rsp+0xB0], xmm12
000078d1a57e0a63  vmovaps [rsp+0xC0], xmm13
000078d1a57e0a6c  vmovaps [rsp+0xD0], xmm14
000078d1a57e0a75  vmovaps [rsp+0xE0], xmm15
000078d1a57e0a7e  sub rsp, 0x30
000078d1a57e0a82  movaps [rsp], xmm7
000078d1a57e0a86  movaps [rsp+0x10], xmm11
000078d1a57e0a8c  movaps [rsp+0x20], xmm9
000078d1a57e0a92  lea rdi, [rsp]
000078d1a57e0a96  mov esi, 0x00
000078d1a57e0a9b  mov rax, 0x56EA20A26530
000078d1a57e0aa5  call rax
000078d1a57e0aa7  movaps xmm7, [rsp]
000078d1a57e0aab  add rsp, 0x30
000078d1a57e0aaf  vmovaps xmm0, [rsp]
000078d1a57e0ab4  vmovaps xmm1, [rsp+0x10]
000078d1a57e0aba  vmovaps xmm2, [rsp+0x20]
000078d1a57e0ac0  vmovaps xmm3, [rsp+0x30]
000078d1a57e0ac6  vmovaps xmm4, [rsp+0x40]
000078d1a57e0acc  vmovaps xmm5, [rsp+0x50]
000078d1a57e0ad2  vmovaps xmm6, [rsp+0x60]
000078d1a57e0ad8  vmovaps xmm8, [rsp+0x70]
000078d1a57e0ade  vmovaps xmm9, [rsp+0x80]
000078d1a57e0ae7  vmovaps xmm10, [rsp+0x90]
000078d1a57e0af0  vmovaps xmm11, [rsp+0xA0]
000078d1a57e0af9  vmovaps xmm12, [rsp+0xB0]
000078d1a57e0b02  vmovaps xmm13, [rsp+0xC0]
000078d1a57e0b0b  vmovaps xmm14, [rsp+0xD0]
000078d1a57e0b14  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0b1d  add rsp, 0xF0
000078d1a57e0b24  pop r11
000078d1a57e0b26  pop r10
000078d1a57e0b28  pop r9
000078d1a57e0b2a  pop r8
000078d1a57e0b2c  pop rsi
000078d1a57e0b2d  pop rdi
000078d1a57e0b2e  pop rdx
000078d1a57e0b2f  pop rcx
000078d1a57e0b30  pop rax
000078d1a57e0b31  add rsp, 0x08
000078d1a57e0b35  jmp 0x000078D1A57DC685
000078d1a57e0b3a  sub rsp, 0x08
000078d1a57e0b3e  push rax
000078d1a57e0b3f  push rcx
000078d1a57e0b40  push rdx
000078d1a57e0b41  push rdi
000078d1a57e0b42  push rsi
000078d1a57e0b43  push r8
000078d1a57e0b45  push r9
000078d1a57e0b47  push r10
000078d1a57e0b49  push r11
000078d1a57e0b4b  sub rsp, 0xF0
000078d1a57e0b52  vmovaps [rsp], xmm0
000078d1a57e0b57  vmovaps [rsp+0x10], xmm1
000078d1a57e0b5d  vmovaps [rsp+0x20], xmm2
000078d1a57e0b63  vmovaps [rsp+0x30], xmm3
000078d1a57e0b69  vmovaps [rsp+0x40], xmm4
000078d1a57e0b6f  vmovaps [rsp+0x50], xmm5
000078d1a57e0b75  vmovaps [rsp+0x60], xmm6
000078d1a57e0b7b  vmovaps [rsp+0x70], xmm7
000078d1a57e0b81  vmovaps [rsp+0x80], xmm8
000078d1a57e0b8a  vmovaps [rsp+0x90], xmm9
000078d1a57e0b93  vmovaps [rsp+0xA0], xmm10
000078d1a57e0b9c  vmovaps [rsp+0xB0], xmm12
000078d1a57e0ba5  vmovaps [rsp+0xC0], xmm13
000078d1a57e0bae  vmovaps [rsp+0xD0], xmm14
000078d1a57e0bb7  vmovaps [rsp+0xE0], xmm15
000078d1a57e0bc0  sub rsp, 0x30
000078d1a57e0bc4  movaps [rsp], xmm11
000078d1a57e0bc9  movaps [rsp+0x10], xmm10
000078d1a57e0bcf  movaps [rsp+0x20], xmm14
000078d1a57e0bd5  lea rdi, [rsp]
000078d1a57e0bd9  mov esi, 0x00
000078d1a57e0bde  mov rax, 0x56EA20A26530
000078d1a57e0be8  call rax
000078d1a57e0bea  movaps xmm11, [rsp]
000078d1a57e0bef  add rsp, 0x30
000078d1a57e0bf3  vmovaps xmm0, [rsp]
000078d1a57e0bf8  vmovaps xmm1, [rsp+0x10]
000078d1a57e0bfe  vmovaps xmm2, [rsp+0x20]
000078d1a57e0c04  vmovaps xmm3, [rsp+0x30]
000078d1a57e0c0a  vmovaps xmm4, [rsp+0x40]
000078d1a57e0c10  vmovaps xmm5, [rsp+0x50]
000078d1a57e0c16  vmovaps xmm6, [rsp+0x60]
000078d1a57e0c1c  vmovaps xmm7, [rsp+0x70]
000078d1a57e0c22  vmovaps xmm8, [rsp+0x80]
000078d1a57e0c2b  vmovaps xmm9, [rsp+0x90]
000078d1a57e0c34  vmovaps xmm10, [rsp+0xA0]
000078d1a57e0c3d  vmovaps xmm12, [rsp+0xB0]
000078d1a57e0c46  vmovaps xmm13, [rsp+0xC0]
000078d1a57e0c4f  vmovaps xmm14, [rsp+0xD0]
000078d1a57e0c58  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0c61  add rsp, 0xF0
000078d1a57e0c68  pop r11
000078d1a57e0c6a  pop r10
000078d1a57e0c6c  pop r9
000078d1a57e0c6e  pop r8
000078d1a57e0c70  pop rsi
000078d1a57e0c71  pop rdi
000078d1a57e0c72  pop rdx
000078d1a57e0c73  pop rcx
000078d1a57e0c74  pop rax
000078d1a57e0c75  add rsp, 0x08
000078d1a57e0c79  jmp 0x000078D1A57DC6A0
000078d1a57e0c7e  call 0x000078D1A56C33A0
000078d1a57e0c83  jmp 0x000078D1A57DC6AA
000078d1a57e0c88  sub rsp, 0x08
000078d1a57e0c8c  push rax
000078d1a57e0c8d  push rcx
000078d1a57e0c8e  push rdx
000078d1a57e0c8f  push rdi
000078d1a57e0c90  push rsi
000078d1a57e0c91  push r8
000078d1a57e0c93  push r9
000078d1a57e0c95  push r10
000078d1a57e0c97  push r11
000078d1a57e0c99  sub rsp, 0xF0
000078d1a57e0ca0  vmovaps [rsp], xmm0
000078d1a57e0ca5  vmovaps [rsp+0x10], xmm1
000078d1a57e0cab  vmovaps [rsp+0x20], xmm2
000078d1a57e0cb1  vmovaps [rsp+0x30], xmm3
000078d1a57e0cb7  vmovaps [rsp+0x40], xmm4
000078d1a57e0cbd  vmovaps [rsp+0x50], xmm5
000078d1a57e0cc3  vmovaps [rsp+0x60], xmm6
000078d1a57e0cc9  vmovaps [rsp+0x70], xmm7
000078d1a57e0ccf  vmovaps [rsp+0x80], xmm8
000078d1a57e0cd8  vmovaps [rsp+0x90], xmm9
000078d1a57e0ce1  vmovaps [rsp+0xA0], xmm11
000078d1a57e0cea  vmovaps [rsp+0xB0], xmm12
000078d1a57e0cf3  vmovaps [rsp+0xC0], xmm13
000078d1a57e0cfc  vmovaps [rsp+0xD0], xmm14
000078d1a57e0d05  vmovaps [rsp+0xE0], xmm15
000078d1a57e0d0e  sub rsp, 0x30
000078d1a57e0d12  movaps [rsp], xmm10
000078d1a57e0d17  movaps [rsp+0x10], xmm1
000078d1a57e0d1c  movaps [rsp+0x20], xmm12
000078d1a57e0d22  lea rdi, [rsp]
000078d1a57e0d26  mov esi, 0x00
000078d1a57e0d2b  mov rax, 0x56EA20A26530
000078d1a57e0d35  call rax
000078d1a57e0d37  movaps xmm10, [rsp]
000078d1a57e0d3c  add rsp, 0x30
000078d1a57e0d40  vmovaps xmm0, [rsp]
000078d1a57e0d45  vmovaps xmm1, [rsp+0x10]
000078d1a57e0d4b  vmovaps xmm2, [rsp+0x20]
000078d1a57e0d51  vmovaps xmm3, [rsp+0x30]
000078d1a57e0d57  vmovaps xmm4, [rsp+0x40]
000078d1a57e0d5d  vmovaps xmm5, [rsp+0x50]
000078d1a57e0d63  vmovaps xmm6, [rsp+0x60]
000078d1a57e0d69  vmovaps xmm7, [rsp+0x70]
000078d1a57e0d6f  vmovaps xmm8, [rsp+0x80]
000078d1a57e0d78  vmovaps xmm9, [rsp+0x90]
000078d1a57e0d81  vmovaps xmm11, [rsp+0xA0]
000078d1a57e0d8a  vmovaps xmm12, [rsp+0xB0]
000078d1a57e0d93  vmovaps xmm13, [rsp+0xC0]
000078d1a57e0d9c  vmovaps xmm14, [rsp+0xD0]
000078d1a57e0da5  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0dae  add rsp, 0xF0
000078d1a57e0db5  pop r11
000078d1a57e0db7  pop r10
000078d1a57e0db9  pop r9
000078d1a57e0dbb  pop r8
000078d1a57e0dbd  pop rsi
000078d1a57e0dbe  pop rdi
000078d1a57e0dbf  pop rdx
000078d1a57e0dc0  pop rcx
000078d1a57e0dc1  pop rax
000078d1a57e0dc2  add rsp, 0x08
000078d1a57e0dc6  jmp 0x000078D1A57DC6CD
000078d1a57e0dcb  sub rsp, 0x08
000078d1a57e0dcf  push rax
000078d1a57e0dd0  push rcx
000078d1a57e0dd1  push rdx
000078d1a57e0dd2  push rdi
000078d1a57e0dd3  push rsi
000078d1a57e0dd4  push r8
000078d1a57e0dd6  push r9
000078d1a57e0dd8  push r10
000078d1a57e0dda  push r11
000078d1a57e0ddc  sub rsp, 0xF0
000078d1a57e0de3  vmovaps [rsp], xmm0
000078d1a57e0de8  vmovaps [rsp+0x10], xmm1
000078d1a57e0dee  vmovaps [rsp+0x20], xmm2
000078d1a57e0df4  vmovaps [rsp+0x30], xmm3
000078d1a57e0dfa  vmovaps [rsp+0x40], xmm4
000078d1a57e0e00  vmovaps [rsp+0x50], xmm5
000078d1a57e0e06  vmovaps [rsp+0x60], xmm6
000078d1a57e0e0c  vmovaps [rsp+0x70], xmm7
000078d1a57e0e12  vmovaps [rsp+0x80], xmm8
000078d1a57e0e1b  vmovaps [rsp+0x90], xmm9
000078d1a57e0e24  vmovaps [rsp+0xA0], xmm10
000078d1a57e0e2d  vmovaps [rsp+0xB0], xmm11
000078d1a57e0e36  vmovaps [rsp+0xC0], xmm13
000078d1a57e0e3f  vmovaps [rsp+0xD0], xmm14
000078d1a57e0e48  vmovaps [rsp+0xE0], xmm15
000078d1a57e0e51  sub rsp, 0x30
000078d1a57e0e55  movaps [rsp], xmm12
000078d1a57e0e5a  movaps [rsp+0x10], xmm14
000078d1a57e0e60  movaps [rsp+0x20], xmm1
000078d1a57e0e65  lea rdi, [rsp]
000078d1a57e0e69  mov esi, 0x00
000078d1a57e0e6e  mov rax, 0x56EA20A26530
000078d1a57e0e78  call rax
000078d1a57e0e7a  movaps xmm12, [rsp]
000078d1a57e0e7f  add rsp, 0x30
000078d1a57e0e83  vmovaps xmm0, [rsp]
000078d1a57e0e88  vmovaps xmm1, [rsp+0x10]
000078d1a57e0e8e  vmovaps xmm2, [rsp+0x20]
000078d1a57e0e94  vmovaps xmm3, [rsp+0x30]
000078d1a57e0e9a  vmovaps xmm4, [rsp+0x40]
000078d1a57e0ea0  vmovaps xmm5, [rsp+0x50]
000078d1a57e0ea6  vmovaps xmm6, [rsp+0x60]
000078d1a57e0eac  vmovaps xmm7, [rsp+0x70]
000078d1a57e0eb2  vmovaps xmm8, [rsp+0x80]
000078d1a57e0ebb  vmovaps xmm9, [rsp+0x90]
000078d1a57e0ec4  vmovaps xmm10, [rsp+0xA0]
000078d1a57e0ecd  vmovaps xmm11, [rsp+0xB0]
000078d1a57e0ed6  vmovaps xmm13, [rsp+0xC0]
000078d1a57e0edf  vmovaps xmm14, [rsp+0xD0]
000078d1a57e0ee8  vmovaps xmm15, [rsp+0xE0]
000078d1a57e0ef1  add rsp, 0xF0
000078d1a57e0ef8  pop r11
000078d1a57e0efa  pop r10
000078d1a57e0efc  pop r9
000078d1a57e0efe  pop r8
000078d1a57e0f00  pop rsi
000078d1a57e0f01  pop rdi
000078d1a57e0f02  pop rdx
000078d1a57e0f03  pop rcx
000078d1a57e0f04  pop rax
000078d1a57e0f05  add rsp, 0x08
000078d1a57e0f09  jmp 0x000078D1A57DC6FC
000078d1a57e0f0e  sub rsp, 0x08
000078d1a57e0f12  push rax
000078d1a57e0f13  push rcx
000078d1a57e0f14  push rdx
000078d1a57e0f15  push rdi
000078d1a57e0f16  push rsi
000078d1a57e0f17  push r8
000078d1a57e0f19  push r9
000078d1a57e0f1b  push r10
000078d1a57e0f1d  push r11
000078d1a57e0f1f  sub rsp, 0xF0
000078d1a57e0f26  vmovaps [rsp], xmm0
000078d1a57e0f2b  vmovaps [rsp+0x10], xmm1
000078d1a57e0f31  vmovaps [rsp+0x20], xmm2
000078d1a57e0f37  vmovaps [rsp+0x30], xmm3
000078d1a57e0f3d  vmovaps [rsp+0x40], xmm4
000078d1a57e0f43  vmovaps [rsp+0x50], xmm5
000078d1a57e0f49  vmovaps [rsp+0x60], xmm6
000078d1a57e0f4f  vmovaps [rsp+0x70], xmm7
000078d1a57e0f55  vmovaps [rsp+0x80], xmm8
000078d1a57e0f5e  vmovaps [rsp+0x90], xmm9
000078d1a57e0f67  vmovaps [rsp+0xA0], xmm10
000078d1a57e0f70  vmovaps [rsp+0xB0], xmm11
000078d1a57e0f79  vmovaps [rsp+0xC0], xmm12
000078d1a57e0f82  vmovaps [rsp+0xD0], xmm13
000078d1a57e0f8b  vmovaps [rsp+0xE0], xmm15
000078d1a57e0f94  sub rsp, 0x30
000078d1a57e0f98  movaps [rsp], xmm14
000078d1a57e0f9d  movaps [rsp+0x10], xmm9
000078d1a57e0fa3  movaps [rsp+0x20], xmm1
000078d1a57e0fa8  lea rdi, [rsp]
000078d1a57e0fac  mov esi, 0x00
000078d1a57e0fb1  mov rax, 0x56EA20A26530
000078d1a57e0fbb  call rax
000078d1a57e0fbd  movaps xmm14, [rsp]
000078d1a57e0fc2  add rsp, 0x30
000078d1a57e0fc6  vmovaps xmm0, [rsp]
000078d1a57e0fcb  vmovaps xmm1, [rsp+0x10]
000078d1a57e0fd1  vmovaps xmm2, [rsp+0x20]
000078d1a57e0fd7  vmovaps xmm3, [rsp+0x30]
000078d1a57e0fdd  vmovaps xmm4, [rsp+0x40]
000078d1a57e0fe3  vmovaps xmm5, [rsp+0x50]
000078d1a57e0fe9  vmovaps xmm6, [rsp+0x60]
000078d1a57e0fef  vmovaps xmm7, [rsp+0x70]
000078d1a57e0ff5  vmovaps xmm8, [rsp+0x80]
000078d1a57e0ffe  vmovaps xmm9, [rsp+0x90]
000078d1a57e1007  vmovaps xmm10, [rsp+0xA0]
000078d1a57e1010  vmovaps xmm11, [rsp+0xB0]
000078d1a57e1019  vmovaps xmm12, [rsp+0xC0]
000078d1a57e1022  vmovaps xmm13, [rsp+0xD0]
000078d1a57e102b  vmovaps xmm15, [rsp+0xE0]
000078d1a57e1034  add rsp, 0xF0
000078d1a57e103b  pop r11
000078d1a57e103d  pop r10
000078d1a57e103f  pop r9
000078d1a57e1041  pop r8
000078d1a57e1043  pop rsi
000078d1a57e1044  pop rdi
000078d1a57e1045  pop rdx
000078d1a57e1046  pop rcx
000078d1a57e1047  pop rax
000078d1a57e1048  add rsp, 0x08
000078d1a57e104c  jmp 0x000078D1A57DC72B
000078d1a57e1051  sub rsp, 0x08
000078d1a57e1055  push rax
000078d1a57e1056  push rcx
000078d1a57e1057  push rdx
000078d1a57e1058  push rdi
000078d1a57e1059  push rsi
000078d1a57e105a  push r8
000078d1a57e105c  push r9
000078d1a57e105e  push r10
000078d1a57e1060  push r11
000078d1a57e1062  sub rsp, 0xF0
000078d1a57e1069  vmovaps [rsp], xmm0
000078d1a57e106e  vmovaps [rsp+0x10], xmm2
000078d1a57e1074  vmovaps [rsp+0x20], xmm3
000078d1a57e107a  vmovaps [rsp+0x30], xmm4
000078d1a57e1080  vmovaps [rsp+0x40], xmm5
000078d1a57e1086  vmovaps [rsp+0x50], xmm6
000078d1a57e108c  vmovaps [rsp+0x60], xmm7
000078d1a57e1092  vmovaps [rsp+0x70], xmm8
000078d1a57e1098  vmovaps [rsp+0x80], xmm9
000078d1a57e10a1  vmovaps [rsp+0x90], xmm10
000078d1a57e10aa  vmovaps [rsp+0xA0], xmm11
000078d1a57e10b3  vmovaps [rsp+0xB0], xmm12
000078d1a57e10bc  vmovaps [rsp+0xC0], xmm13
000078d1a57e10c5  vmovaps [rsp+0xD0], xmm14
000078d1a57e10ce  vmovaps [rsp+0xE0], xmm15
000078d1a57e10d7  sub rsp, 0x30
000078d1a57e10db  movaps [rsp], xmm1
000078d1a57e10df  movaps [rsp+0x10], xmm13
000078d1a57e10e5  movaps [rsp+0x20], xmm8
000078d1a57e10eb  lea rdi, [rsp]
000078d1a57e10ef  mov esi, 0x00
000078d1a57e10f4  mov rax, 0x56EA20A26530
000078d1a57e10fe  call rax
000078d1a57e1100  movaps xmm1, [rsp]
000078d1a57e1104  add rsp, 0x30
000078d1a57e1108  vmovaps xmm0, [rsp]
000078d1a57e110d  vmovaps xmm2, [rsp+0x10]
000078d1a57e1113  vmovaps xmm3, [rsp+0x20]
000078d1a57e1119  vmovaps xmm4, [rsp+0x30]
000078d1a57e111f  vmovaps xmm5, [rsp+0x40]
000078d1a57e1125  vmovaps xmm6, [rsp+0x50]
000078d1a57e112b  vmovaps xmm7, [rsp+0x60]
000078d1a57e1131  vmovaps xmm8, [rsp+0x70]
000078d1a57e1137  vmovaps xmm9, [rsp+0x80]
000078d1a57e1140  vmovaps xmm10, [rsp+0x90]
000078d1a57e1149  vmovaps xmm11, [rsp+0xA0]
000078d1a57e1152  vmovaps xmm12, [rsp+0xB0]
000078d1a57e115b  vmovaps xmm13, [rsp+0xC0]
000078d1a57e1164  vmovaps xmm14, [rsp+0xD0]
000078d1a57e116d  vmovaps xmm15, [rsp+0xE0]
000078d1a57e1176  add rsp, 0xF0
000078d1a57e117d  pop r11
000078d1a57e117f  pop r10
000078d1a57e1181  pop r9
000078d1a57e1183  pop r8
000078d1a57e1185  pop rsi
000078d1a57e1186  pop rdi
000078d1a57e1187  pop rdx
000078d1a57e1188  pop rcx
000078d1a57e1189  pop rax
000078d1a57e118a  add rsp, 0x08
000078d1a57e118e  jmp 0x000078D1A57DC74D
000078d1a57e1193  call 0x000078D1A560C260
000078d1a57e1198  jmp 0x000078D1A57DC75B
000078d1a57e119d  call 0x000078D1A56BD750
000078d1a57e11a2  jmp 0x000078D1A57DC765
000078d1a57e11a7  sub rsp, 0x08
000078d1a57e11ab  push rax
000078d1a57e11ac  push rcx
000078d1a57e11ad  push rdx
000078d1a57e11ae  push rdi
000078d1a57e11af  push rsi
000078d1a57e11b0  push r8
000078d1a57e11b2  push r9
000078d1a57e11b4  push r10
000078d1a57e11b6  push r11
000078d1a57e11b8  sub rsp, 0xF0
000078d1a57e11bf  vmovaps [rsp], xmm0
000078d1a57e11c4  vmovaps [rsp+0x10], xmm1
000078d1a57e11ca  vmovaps [rsp+0x20], xmm2
000078d1a57e11d0  vmovaps [rsp+0x30], xmm3
000078d1a57e11d6  vmovaps [rsp+0x40], xmm4
000078d1a57e11dc  vmovaps [rsp+0x50], xmm5
000078d1a57e11e2  vmovaps [rsp+0x60], xmm6
000078d1a57e11e8  vmovaps [rsp+0x70], xmm7
000078d1a57e11ee  vmovaps [rsp+0x80], xmm9
000078d1a57e11f7  vmovaps [rsp+0x90], xmm10
000078d1a57e1200  vmovaps [rsp+0xA0], xmm11
000078d1a57e1209  vmovaps [rsp+0xB0], xmm12
000078d1a57e1212  vmovaps [rsp+0xC0], xmm13
000078d1a57e121b  vmovaps [rsp+0xD0], xmm14
000078d1a57e1224  vmovaps [rsp+0xE0], xmm15
000078d1a57e122d  sub rsp, 0x30
000078d1a57e1231  movaps [rsp], xmm8
000078d1a57e1236  movaps [rsp+0x10], xmm15
000078d1a57e123c  movaps [rsp+0x20], xmm7
000078d1a57e1241  lea rdi, [rsp]
000078d1a57e1245  mov esi, 0x00
000078d1a57e124a  mov rax, 0x56EA20A26530
000078d1a57e1254  call rax
000078d1a57e1256  movaps xmm8, [rsp]
000078d1a57e125b  add rsp, 0x30
000078d1a57e125f  vmovaps xmm0, [rsp]
000078d1a57e1264  vmovaps xmm1, [rsp+0x10]
000078d1a57e126a  vmovaps xmm2, [rsp+0x20]
000078d1a57e1270  vmovaps xmm3, [rsp+0x30]
000078d1a57e1276  vmovaps xmm4, [rsp+0x40]
000078d1a57e127c  vmovaps xmm5, [rsp+0x50]
000078d1a57e1282  vmovaps xmm6, [rsp+0x60]
000078d1a57e1288  vmovaps xmm7, [rsp+0x70]
000078d1a57e128e  vmovaps xmm9, [rsp+0x80]
000078d1a57e1297  vmovaps xmm10, [rsp+0x90]
000078d1a57e12a0  vmovaps xmm11, [rsp+0xA0]
000078d1a57e12a9  vmovaps xmm12, [rsp+0xB0]
000078d1a57e12b2  vmovaps xmm13, [rsp+0xC0]
000078d1a57e12bb  vmovaps xmm14, [rsp+0xD0]
000078d1a57e12c4  vmovaps xmm15, [rsp+0xE0]
000078d1a57e12cd  add rsp, 0xF0
000078d1a57e12d4  pop r11
000078d1a57e12d6  pop r10
000078d1a57e12d8  pop r9
000078d1a57e12da  pop r8
000078d1a57e12dc  pop rsi
000078d1a57e12dd  pop rdi
000078d1a57e12de  pop rdx
000078d1a57e12df  pop rcx
000078d1a57e12e0  pop rax
000078d1a57e12e1  add rsp, 0x08
000078d1a57e12e5  jmp 0x000078D1A57DC787
000078d1a57e12ea  sub rsp, 0x08
000078d1a57e12ee  push rax
000078d1a57e12ef  push rcx
000078d1a57e12f0  push rdx
000078d1a57e12f1  push rdi
000078d1a57e12f2  push rsi
000078d1a57e12f3  push r8
000078d1a57e12f5  push r9
000078d1a57e12f7  push r10
000078d1a57e12f9  push r11
000078d1a57e12fb  sub rsp, 0xF0
000078d1a57e1302  vmovaps [rsp], xmm0
000078d1a57e1307  vmovaps [rsp+0x10], xmm1
000078d1a57e130d  vmovaps [rsp+0x20], xmm2
000078d1a57e1313  vmovaps [rsp+0x30], xmm3
000078d1a57e1319  vmovaps [rsp+0x40], xmm4
000078d1a57e131f  vmovaps [rsp+0x50], xmm5
000078d1a57e1325  vmovaps [rsp+0x60], xmm6
000078d1a57e132b  vmovaps [rsp+0x70], xmm8
000078d1a57e1331  vmovaps [rsp+0x80], xmm9
000078d1a57e133a  vmovaps [rsp+0x90], xmm10
000078d1a57e1343  vmovaps [rsp+0xA0], xmm11
000078d1a57e134c  vmovaps [rsp+0xB0], xmm12
000078d1a57e1355  vmovaps [rsp+0xC0], xmm13
000078d1a57e135e  vmovaps [rsp+0xD0], xmm14
000078d1a57e1367  vmovaps [rsp+0xE0], xmm15
000078d1a57e1370  sub rsp, 0x30
000078d1a57e1374  movaps [rsp], xmm7
000078d1a57e1378  movaps [rsp+0x10], xmm9
000078d1a57e137e  movaps [rsp+0x20], xmm15
000078d1a57e1384  lea rdi, [rsp]
000078d1a57e1388  mov esi, 0x00
000078d1a57e138d  mov rax, 0x56EA20A26530
000078d1a57e1397  call rax
000078d1a57e1399  movaps xmm7, [rsp]
000078d1a57e139d  add rsp, 0x30
000078d1a57e13a1  vmovaps xmm0, [rsp]
000078d1a57e13a6  vmovaps xmm1, [rsp+0x10]
000078d1a57e13ac  vmovaps xmm2, [rsp+0x20]
000078d1a57e13b2  vmovaps xmm3, [rsp+0x30]
000078d1a57e13b8  vmovaps xmm4, [rsp+0x40]
000078d1a57e13be  vmovaps xmm5, [rsp+0x50]
000078d1a57e13c4  vmovaps xmm6, [rsp+0x60]
000078d1a57e13ca  vmovaps xmm8, [rsp+0x70]
000078d1a57e13d0  vmovaps xmm9, [rsp+0x80]
000078d1a57e13d9  vmovaps xmm10, [rsp+0x90]
000078d1a57e13e2  vmovaps xmm11, [rsp+0xA0]
000078d1a57e13eb  vmovaps xmm12, [rsp+0xB0]
000078d1a57e13f4  vmovaps xmm13, [rsp+0xC0]
000078d1a57e13fd  vmovaps xmm14, [rsp+0xD0]
000078d1a57e1406  vmovaps xmm15, [rsp+0xE0]
000078d1a57e140f  add rsp, 0xF0
000078d1a57e1416  pop r11
000078d1a57e1418  pop r10
000078d1a57e141a  pop r9
000078d1a57e141c  pop r8
000078d1a57e141e  pop rsi
000078d1a57e141f  pop rdi
000078d1a57e1420  pop rdx
000078d1a57e1421  pop rcx
000078d1a57e1422  pop rax
000078d1a57e1423  add rsp, 0x08
000078d1a57e1427  jmp 0x000078D1A57DC7B4
000078d1a57e142c  sub rsp, 0x08
000078d1a57e1430  push rax
000078d1a57e1431  push rcx
000078d1a57e1432  push rdx
000078d1a57e1433  push rdi
000078d1a57e1434  push rsi
000078d1a57e1435  push r8
000078d1a57e1437  push r9
000078d1a57e1439  push r10
000078d1a57e143b  push r11
000078d1a57e143d  sub rsp, 0xF0
000078d1a57e1444  vmovaps [rsp], xmm0
000078d1a57e1449  vmovaps [rsp+0x10], xmm1
000078d1a57e144f  vmovaps [rsp+0x20], xmm2
000078d1a57e1455  vmovaps [rsp+0x30], xmm3
000078d1a57e145b  vmovaps [rsp+0x40], xmm4
000078d1a57e1461  vmovaps [rsp+0x50], xmm5
000078d1a57e1467  vmovaps [rsp+0x60], xmm6
000078d1a57e146d  vmovaps [rsp+0x70], xmm7
000078d1a57e1473  vmovaps [rsp+0x80], xmm8
000078d1a57e147c  vmovaps [rsp+0x90], xmm10
000078d1a57e1485  vmovaps [rsp+0xA0], xmm11
000078d1a57e148e  vmovaps [rsp+0xB0], xmm12
000078d1a57e1497  vmovaps [rsp+0xC0], xmm13
000078d1a57e14a0  vmovaps [rsp+0xD0], xmm14
000078d1a57e14a9  vmovaps [rsp+0xE0], xmm15
000078d1a57e14b2  sub rsp, 0x30
000078d1a57e14b6  movaps [rsp], xmm9
000078d1a57e14bb  movaps [rsp+0x10], xmm13
000078d1a57e14c1  movaps [rsp+0x20], xmm15
000078d1a57e14c7  lea rdi, [rsp]
000078d1a57e14cb  mov esi, 0x00
000078d1a57e14d0  mov rax, 0x56EA20A26530
000078d1a57e14da  call rax
000078d1a57e14dc  movaps xmm9, [rsp]
000078d1a57e14e1  add rsp, 0x30
000078d1a57e14e5  vmovaps xmm0, [rsp]
000078d1a57e14ea  vmovaps xmm1, [rsp+0x10]
000078d1a57e14f0  vmovaps xmm2, [rsp+0x20]
000078d1a57e14f6  vmovaps xmm3, [rsp+0x30]
000078d1a57e14fc  vmovaps xmm4, [rsp+0x40]
000078d1a57e1502  vmovaps xmm5, [rsp+0x50]
000078d1a57e1508  vmovaps xmm6, [rsp+0x60]
000078d1a57e150e  vmovaps xmm7, [rsp+0x70]
000078d1a57e1514  vmovaps xmm8, [rsp+0x80]
000078d1a57e151d  vmovaps xmm10, [rsp+0x90]
000078d1a57e1526  vmovaps xmm11, [rsp+0xA0]
000078d1a57e152f  vmovaps xmm12, [rsp+0xB0]
000078d1a57e1538  vmovaps xmm13, [rsp+0xC0]
000078d1a57e1541  vmovaps xmm14, [rsp+0xD0]
000078d1a57e154a  vmovaps xmm15, [rsp+0xE0]
000078d1a57e1553  add rsp, 0xF0
000078d1a57e155a  pop r11
000078d1a57e155c  pop r10
000078d1a57e155e  pop r9
000078d1a57e1560  pop r8
000078d1a57e1562  pop rsi
000078d1a57e1563  pop rdi
000078d1a57e1564  pop rdx
000078d1a57e1565  pop rcx
000078d1a57e1566  pop rax
000078d1a57e1567  add rsp, 0x08
000078d1a57e156b  jmp 0x000078D1A57DC7E2
000078d1a57e1570  sub rsp, 0x08
000078d1a57e1574  push rax
000078d1a57e1575  push rcx
000078d1a57e1576  push rdx
000078d1a57e1577  push rdi
000078d1a57e1578  push rsi
000078d1a57e1579  push r8
000078d1a57e157b  push r9
000078d1a57e157d  push r10
000078d1a57e157f  push r11
000078d1a57e1581  sub rsp, 0xF0
000078d1a57e1588  vmovaps [rsp], xmm0
000078d1a57e158d  vmovaps [rsp+0x10], xmm1
000078d1a57e1593  vmovaps [rsp+0x20], xmm2
000078d1a57e1599  vmovaps [rsp+0x30], xmm3
000078d1a57e159f  vmovaps [rsp+0x40], xmm4
000078d1a57e15a5  vmovaps [rsp+0x50], xmm5
000078d1a57e15ab  vmovaps [rsp+0x60], xmm6
000078d1a57e15b1  vmovaps [rsp+0x70], xmm7
000078d1a57e15b7  vmovaps [rsp+0x80], xmm8
000078d1a57e15c0  vmovaps [rsp+0x90], xmm9
000078d1a57e15c9  vmovaps [rsp+0xA0], xmm10
000078d1a57e15d2  vmovaps [rsp+0xB0], xmm11
000078d1a57e15db  vmovaps [rsp+0xC0], xmm12
000078d1a57e15e4  vmovaps [rsp+0xD0], xmm13
000078d1a57e15ed  vmovaps [rsp+0xE0], xmm14
000078d1a57e15f6  sub rsp, 0x30
000078d1a57e15fa  movaps [rsp], xmm15
000078d1a57e15ff  movaps [rsp+0x10], xmm11
000078d1a57e1605  movaps [rsp+0x20], xmm12
000078d1a57e160b  lea rdi, [rsp]
000078d1a57e160f  mov esi, 0x00
000078d1a57e1614  mov rax, 0x56EA20A26530
000078d1a57e161e  call rax
000078d1a57e1620  movaps xmm15, [rsp]
000078d1a57e1625  add rsp, 0x30
000078d1a57e1629  vmovaps xmm0, [rsp]
000078d1a57e162e  vmovaps xmm1, [rsp+0x10]
000078d1a57e1634  vmovaps xmm2, [rsp+0x20]
000078d1a57e163a  vmovaps xmm3, [rsp+0x30]
000078d1a57e1640  vmovaps xmm4, [rsp+0x40]
000078d1a57e1646  vmovaps xmm5, [rsp+0x50]
000078d1a57e164c  vmovaps xmm6, [rsp+0x60]
000078d1a57e1652  vmovaps xmm7, [rsp+0x70]
000078d1a57e1658  vmovaps xmm8, [rsp+0x80]
000078d1a57e1661  vmovaps xmm9, [rsp+0x90]
000078d1a57e166a  vmovaps xmm10, [rsp+0xA0]
000078d1a57e1673  vmovaps xmm11, [rsp+0xB0]
000078d1a57e167c  vmovaps xmm12, [rsp+0xC0]
000078d1a57e1685  vmovaps xmm13, [rsp+0xD0]
000078d1a57e168e  vmovaps xmm14, [rsp+0xE0]
000078d1a57e1697  add rsp, 0xF0
000078d1a57e169e  pop r11
000078d1a57e16a0  pop r10
000078d1a57e16a2  pop r9
000078d1a57e16a4  pop r8
000078d1a57e16a6  pop rsi
000078d1a57e16a7  pop rdi
000078d1a57e16a8  pop rdx
000078d1a57e16a9  pop rcx
000078d1a57e16aa  pop rax
000078d1a57e16ab  add rsp, 0x08
000078d1a57e16af  jmp 0x000078D1A57DC7FD
000078d1a57e16b4  sub rsp, 0x08
000078d1a57e16b8  push rax
000078d1a57e16b9  push rcx
000078d1a57e16ba  push rdx
000078d1a57e16bb  push rdi
000078d1a57e16bc  push rsi
000078d1a57e16bd  push r8
000078d1a57e16bf  push r9
000078d1a57e16c1  push r10
000078d1a57e16c3  push r11
000078d1a57e16c5  sub rsp, 0xF0
000078d1a57e16cc  vmovaps [rsp], xmm0
000078d1a57e16d1  vmovaps [rsp+0x10], xmm1
000078d1a57e16d7  vmovaps [rsp+0x20], xmm2
000078d1a57e16dd  vmovaps [rsp+0x30], xmm3
000078d1a57e16e3  vmovaps [rsp+0x40], xmm4
000078d1a57e16e9  vmovaps [rsp+0x50], xmm5
000078d1a57e16ef  vmovaps [rsp+0x60], xmm6
000078d1a57e16f5  vmovaps [rsp+0x70], xmm7
000078d1a57e16fb  vmovaps [rsp+0x80], xmm8
000078d1a57e1704  vmovaps [rsp+0x90], xmm9
000078d1a57e170d  vmovaps [rsp+0xA0], xmm10
000078d1a57e1716  vmovaps [rsp+0xB0], xmm11
000078d1a57e171f  vmovaps [rsp+0xC0], xmm12
000078d1a57e1728  vmovaps [rsp+0xD0], xmm14
000078d1a57e1731  vmovaps [rsp+0xE0], xmm15
000078d1a57e173a  sub rsp, 0x30
000078d1a57e173e  movaps [rsp], xmm13
000078d1a57e1743  movaps [rsp+0x10], xmm10
000078d1a57e1749  movaps [rsp+0x20], xmm14
000078d1a57e174f  lea rdi, [rsp]
000078d1a57e1753  mov esi, 0x00
000078d1a57e1758  mov rax, 0x56EA20A26530
000078d1a57e1762  call rax
000078d1a57e1764  movaps xmm13, [rsp]
000078d1a57e1769  add rsp, 0x30
000078d1a57e176d  vmovaps xmm0, [rsp]
000078d1a57e1772  vmovaps xmm1, [rsp+0x10]
000078d1a57e1778  vmovaps xmm2, [rsp+0x20]
000078d1a57e177e  vmovaps xmm3, [rsp+0x30]
000078d1a57e1784  vmovaps xmm4, [rsp+0x40]
000078d1a57e178a  vmovaps xmm5, [rsp+0x50]
000078d1a57e1790  vmovaps xmm6, [rsp+0x60]
000078d1a57e1796  vmovaps xmm7, [rsp+0x70]
000078d1a57e179c  vmovaps xmm8, [rsp+0x80]
000078d1a57e17a5  vmovaps xmm9, [rsp+0x90]
000078d1a57e17ae  vmovaps xmm10, [rsp+0xA0]
000078d1a57e17b7  vmovaps xmm11, [rsp+0xB0]
000078d1a57e17c0  vmovaps xmm12, [rsp+0xC0]
000078d1a57e17c9  vmovaps xmm14, [rsp+0xD0]
000078d1a57e17d2  vmovaps xmm15, [rsp+0xE0]
000078d1a57e17db  add rsp, 0xF0
000078d1a57e17e2  pop r11
000078d1a57e17e4  pop r10
000078d1a57e17e6  pop r9
000078d1a57e17e8  pop r8
000078d1a57e17ea  pop rsi
000078d1a57e17eb  pop rdi
000078d1a57e17ec  pop rdx
000078d1a57e17ed  pop rcx
000078d1a57e17ee  pop rax
000078d1a57e17ef  add rsp, 0x08
000078d1a57e17f3  jmp 0x000078D1A57DC820
000078d1a57e17f8  sub rsp, 0x08
000078d1a57e17fc  push rax
000078d1a57e17fd  push rcx
000078d1a57e17fe  push rdx
000078d1a57e17ff  push rdi
000078d1a57e1800  push rsi
000078d1a57e1801  push r8
000078d1a57e1803  push r9
000078d1a57e1805  push r10
000078d1a57e1807  push r11
000078d1a57e1809  sub rsp, 0xF0
000078d1a57e1810  vmovaps [rsp], xmm0
000078d1a57e1815  vmovaps [rsp+0x10], xmm1
000078d1a57e181b  vmovaps [rsp+0x20], xmm2
000078d1a57e1821  vmovaps [rsp+0x30], xmm3
000078d1a57e1827  vmovaps [rsp+0x40], xmm4
000078d1a57e182d  vmovaps [rsp+0x50], xmm5
000078d1a57e1833  vmovaps [rsp+0x60], xmm6
000078d1a57e1839  vmovaps [rsp+0x70], xmm7
000078d1a57e183f  vmovaps [rsp+0x80], xmm8
000078d1a57e1848  vmovaps [rsp+0x90], xmm9
000078d1a57e1851  vmovaps [rsp+0xA0], xmm10
000078d1a57e185a  vmovaps [rsp+0xB0], xmm11
000078d1a57e1863  vmovaps [rsp+0xC0], xmm12
000078d1a57e186c  vmovaps [rsp+0xD0], xmm13
000078d1a57e1875  vmovaps [rsp+0xE0], xmm15
000078d1a57e187e  sub rsp, 0x30
000078d1a57e1882  movaps [rsp], xmm14
000078d1a57e1887  movaps [rsp+0x10], xmm1
000078d1a57e188c  movaps [rsp+0x20], xmm7
000078d1a57e1891  lea rdi, [rsp]
000078d1a57e1895  mov esi, 0x00
000078d1a57e189a  mov rax, 0x56EA20A26530
000078d1a57e18a4  call rax
000078d1a57e18a6  movaps xmm14, [rsp]
000078d1a57e18ab  add rsp, 0x30
000078d1a57e18af  vmovaps xmm0, [rsp]
000078d1a57e18b4  vmovaps xmm1, [rsp+0x10]
000078d1a57e18ba  vmovaps xmm2, [rsp+0x20]
000078d1a57e18c0  vmovaps xmm3, [rsp+0x30]
000078d1a57e18c6  vmovaps xmm4, [rsp+0x40]
000078d1a57e18cc  vmovaps xmm5, [rsp+0x50]
000078d1a57e18d2  vmovaps xmm6, [rsp+0x60]
000078d1a57e18d8  vmovaps xmm7, [rsp+0x70]
000078d1a57e18de  vmovaps xmm8, [rsp+0x80]
000078d1a57e18e7  vmovaps xmm9, [rsp+0x90]
000078d1a57e18f0  vmovaps xmm10, [rsp+0xA0]
000078d1a57e18f9  vmovaps xmm11, [rsp+0xB0]
000078d1a57e1902  vmovaps xmm12, [rsp+0xC0]
000078d1a57e190b  vmovaps xmm13, [rsp+0xD0]
000078d1a57e1914  vmovaps xmm15, [rsp+0xE0]
000078d1a57e191d  add rsp, 0xF0
000078d1a57e1924  pop r11
000078d1a57e1926  pop r10
000078d1a57e1928  pop r9
000078d1a57e192a  pop r8
000078d1a57e192c  pop rsi
000078d1a57e192d  pop rdi
000078d1a57e192e  pop rdx
000078d1a57e192f  pop rcx
000078d1a57e1930  pop rax
000078d1a57e1931  add rsp, 0x08
000078d1a57e1935  jmp 0x000078D1A57DC843
000078d1a57e193a  sub rsp, 0x08
000078d1a57e193e  push rax
000078d1a57e193f  push rcx
000078d1a57e1940  push rdx
000078d1a57e1941  push rdi
000078d1a57e1942  push rsi
000078d1a57e1943  push r8
000078d1a57e1945  push r9
000078d1a57e1947  push r10
000078d1a57e1949  push r11
000078d1a57e194b  sub rsp, 0xF0
000078d1a57e1952  vmovaps [rsp], xmm0
000078d1a57e1957  vmovaps [rsp+0x10], xmm2
000078d1a57e195d  vmovaps [rsp+0x20], xmm3
000078d1a57e1963  vmovaps [rsp+0x30], xmm4
000078d1a57e1969  vmovaps [rsp+0x40], xmm5
000078d1a57e196f  vmovaps [rsp+0x50], xmm6
000078d1a57e1975  vmovaps [rsp+0x60], xmm7
000078d1a57e197b  vmovaps [rsp+0x70], xmm8
000078d1a57e1981  vmovaps [rsp+0x80], xmm9
000078d1a57e198a  vmovaps [rsp+0x90], xmm10
000078d1a57e1993  vmovaps [rsp+0xA0], xmm11
000078d1a57e199c  vmovaps [rsp+0xB0], xmm12
000078d1a57e19a5  vmovaps [rsp+0xC0], xmm13
000078d1a57e19ae  vmovaps [rsp+0xD0], xmm14
000078d1a57e19b7  vmovaps [rsp+0xE0], xmm15
000078d1a57e19c0  sub rsp, 0x30
000078d1a57e19c4  movaps [rsp], xmm1
000078d1a57e19c8  movaps [rsp+0x10], xmm8
000078d1a57e19ce  movaps [rsp+0x20], xmm9
000078d1a57e19d4  lea rdi, [rsp]
000078d1a57e19d8  mov esi, 0x00
000078d1a57e19dd  mov rax, 0x56EA20A26530
000078d1a57e19e7  call rax
000078d1a57e19e9  movaps xmm1, [rsp]
000078d1a57e19ed  add rsp, 0x30
000078d1a57e19f1  vmovaps xmm0, [rsp]
000078d1a57e19f6  vmovaps xmm2, [rsp+0x10]
000078d1a57e19fc  vmovaps xmm3, [rsp+0x20]
000078d1a57e1a02  vmovaps xmm4, [rsp+0x30]
000078d1a57e1a08  vmovaps xmm5, [rsp+0x40]
000078d1a57e1a0e  vmovaps xmm6, [rsp+0x50]
000078d1a57e1a14  vmovaps xmm7, [rsp+0x60]
000078d1a57e1a1a  vmovaps xmm8, [rsp+0x70]
000078d1a57e1a20  vmovaps xmm9, [rsp+0x80]
000078d1a57e1a29  vmovaps xmm10, [rsp+0x90]
000078d1a57e1a32  vmovaps xmm11, [rsp+0xA0]
000078d1a57e1a3b  vmovaps xmm12, [rsp+0xB0]
000078d1a57e1a44  vmovaps xmm13, [rsp+0xC0]
000078d1a57e1a4d  vmovaps xmm14, [rsp+0xD0]
000078d1a57e1a56  vmovaps xmm15, [rsp+0xE0]
000078d1a57e1a5f  add rsp, 0xF0
000078d1a57e1a66  pop r11
000078d1a57e1a68  pop r10
000078d1a57e1a6a  pop r9
000078d1a57e1a6c  pop r8
000078d1a57e1a6e  pop rsi
000078d1a57e1a6f  pop rdi
000078d1a57e1a70  pop rdx
000078d1a57e1a71  pop rcx
000078d1a57e1a72  pop rax
000078d1a57e1a73  add rsp, 0x08
000078d1a57e1a77  jmp 0x000078D1A57DC865
000078d1a57e1a7c  call 0x000078D1A56E5940
000078d1a57e1a81  jmp 0x000078D1A57DC873
000078d1a57e1a86  call 0x000078D1A560C380
000078d1a57e1a8b  jmp 0x000078D1A57DC87D
000078d1a57e1a90  call 0x000078D1A560D600
000078d1a57e1a95  jmp 0x000078D1A57DC887
000078d1a57e1a9a  call 0x000078D1A55FF540
000078d1a57e1a9f  jmp 0x000078D1A57DC891
000078d1a57e1aa4  int3
000078d1a57e1aa5  nop [rax+rax*1], ax
000078d1a57e1aae  nop
000078d1a57e1ab0  mov rax, [r15+0xF8]
000078d1a57e1ab7  lea r14, [rax+0x140]
000078d1a57e1abe  mov r12, [r13+r14*1]
000078d1a57e1ac3  mov [r15+0xE8], r12
000078d1a57e1aca  lea r14, [rax+0x130]
000078d1a57e1ad1  mov r12, [r13+r14*1]
000078d1a57e1ad6  lea r14, [rax+0x138]
000078d1a57e1add  mov r11, [r13+r14*1]
000078d1a57e1ae2  movq xmm1, r12
000078d1a57e1ae7  movq xmm15, r11
000078d1a57e1aec  movq xmm1, xmm1
000078d1a57e1af0  movq xmm1, xmm1
000078d1a57e1af4  movaps [r15+0x1A0], xmm1
000078d1a57e1afc  movq xmm15, xmm15
000078d1a57e1b01  movq xmm15, xmm15
000078d1a57e1b06  movaps [r15+0x190], xmm15
000078d1a57e1b0e  lea r14, [rax+0x120]
000078d1a57e1b15  mov r12, [r13+r14*1]
000078d1a57e1b1a  lea r14, [rax+0x128]
000078d1a57e1b21  mov r11, [r13+r14*1]
000078d1a57e1b26  movq xmm1, r12
000078d1a57e1b2b  movq xmm15, r11
000078d1a57e1b30  movq xmm1, xmm1
000078d1a57e1b34  movq xmm1, xmm1
000078d1a57e1b38  movaps [r15+0x1C0], xmm1
000078d1a57e1b40  movq xmm15, xmm15
000078d1a57e1b45  movq xmm15, xmm15
000078d1a57e1b4a  movaps [r15+0x1B0], xmm15
000078d1a57e1b52  lea r14, [rax+0x110]
000078d1a57e1b59  mov r12, [r13+r14*1]
000078d1a57e1b5e  lea r14, [rax+0x118]
000078d1a57e1b65  mov r11, [r13+r14*1]
000078d1a57e1b6a  movq xmm1, r12
000078d1a57e1b6f  movq xmm15, r11
000078d1a57e1b74  movq xmm1, xmm1
000078d1a57e1b78  movq xmm1, xmm1
000078d1a57e1b7c  movaps [r15+0x1E0], xmm1
000078d1a57e1b84  movq xmm15, xmm15
000078d1a57e1b89  movq xmm15, xmm15
000078d1a57e1b8e  movaps [r15+0x1D0], xmm15
000078d1a57e1b96  lea r14, [rax+0x100]
000078d1a57e1b9d  mov r12, [r13+r14*1]
000078d1a57e1ba2  lea r14, [rax+0x108]
000078d1a57e1ba9  mov r11, [r13+r14*1]
000078d1a57e1bae  movq xmm1, r12
000078d1a57e1bb3  movq xmm15, r11
000078d1a57e1bb8  movq xmm1, xmm1
000078d1a57e1bbc  movq xmm1, xmm1
000078d1a57e1bc0  movaps [r15+0x200], xmm1
000078d1a57e1bc8  movq xmm15, xmm15
000078d1a57e1bcd  movq xmm15, xmm15
000078d1a57e1bd2  movaps [r15+0x1F0], xmm15
000078d1a57e1bda  mov qword ptr [r15+0x40], 0x430000
000078d1a57e1be2  mov r14d, 0x430510
000078d1a57e1be8  mov r12, [r13+r14*1]
000078d1a57e1bed  movq xmm1, r12
000078d1a57e1bf2  lea r14, [rax+0x150]
000078d1a57e1bf9  mov [r15+0xF8], r14
000078d1a57e1c00  mov rax, [r15+0x50]
000078d1a57e1c04  movups xmm15, [r13+rax*1]
000078d1a57e1c0a  movaps [r15+0x120], xmm15
000078d1a57e1c12  mov qword ptr [r15+0x48], 0x10
000078d1a57e1c1a  xor eax, eax
000078d1a57e1c1c  mov r14d, 0x10
000078d1a57e1c22  mov r12d, 0x200
000078d1a57e1c28  cmp r14, r12
000078d1a57e1c2b  cmc
000078d1a57e1c2c  lahf
000078d1a57e1c2d  seto al
000078d1a57e1c30  mov [r15+0x108], eax
000078d1a57e1c37  pextrq rax, xmm15, 0x01
000078d1a57e1c3e  movq xmm14, rax
000078d1a57e1c43  movaps [r15+0x130], xmm14
000078d1a57e1c4b  movq rax, xmm1
000078d1a57e1c50  movq r14, xmm15
000078d1a57e1c55  vmovq xmm1, rax
000078d1a57e1c5a  vmovq xmm15, r14
000078d1a57e1c5f  movaps xmm13, xmm1
000078d1a57e1c63  addsd xmm13, xmm15
000078d1a57e1c68  ucomisd xmm13, xmm13
000078d1a57e1c6d  jp 0x000078D1A57E1D86
000078d1a57e1c73  movq xmm13, xmm13
000078d1a57e1c78  movq rax, xmm13
000078d1a57e1c7d  movq r14, xmm14
000078d1a57e1c82  vmovq xmm1, rax
000078d1a57e1c87  vmovq xmm15, r14
000078d1a57e1c8c  movaps xmm14, xmm1
000078d1a57e1c90  addsd xmm14, xmm15
000078d1a57e1c95  ucomisd xmm14, xmm14
000078d1a57e1c9a  jp 0x000078D1A57E1DCE
000078d1a57e1ca0  movq xmm14, xmm14
000078d1a57e1ca5  movaps [r15+0x110], xmm14
000078d1a57e1cad  mov eax, [r15+0x108]
000078d1a57e1cb4  sahf
000078d1a57e1cb5  jnz 0x000078D1A57E1CE7
000078d1a57e1cb7  cmp dword ptr [r15+0x318], 0x00
000078d1a57e1cbf  jz 0x000078D1A57E1FE0
000078d1a57e1cc5  nop [rax+rax*1], ax
000078d1a57e1cce  nop [rax+rax*1], eax
000078d1a57e1cd6  mov eax, 0x410490
000078d1a57e1cdb  mov [r15+0x100], rax
000078d1a57e1ce2  jmp 0x000078D1A55FE110
000078d1a57e1ce7  cmp dword ptr [r15+0x318], 0x00
000078d1a57e1cef  jz 0x000078D1A57E1E20
000078d1a57e1cf5  nop [rax+rax*1], ax
000078d1a57e1cfe  nop [rax+rax*1], eax
000078d1a57e1d06  mov eax, 0x410474
000078d1a57e1d0b  mov [r15+0x100], rax
000078d1a57e1d12  jmp 0x000078D1A55FE110
000078d1a57e1d17  int3
000078d1a57e1d18  call 0x000078D1A56E27E0
000078d1a57e1d1d  jmp 0x000078D1A57E1AC3
000078d1a57e1d22  call 0x000078D1A56E27E0
000078d1a57e1d27  jmp 0x000078D1A57E1AD6
000078d1a57e1d2c  call 0x000078D1A56E1570
000078d1a57e1d31  jmp 0x000078D1A57E1AE2
000078d1a57e1d36  call 0x000078D1A56E27E0
000078d1a57e1d3b  jmp 0x000078D1A57E1B1A
000078d1a57e1d40  call 0x000078D1A56E1570
000078d1a57e1d45  jmp 0x000078D1A57E1B26
000078d1a57e1d4a  call 0x000078D1A56E27E0
000078d1a57e1d4f  jmp 0x000078D1A57E1B5E
000078d1a57e1d54  call 0x000078D1A56E1570
000078d1a57e1d59  jmp 0x000078D1A57E1B6A
000078d1a57e1d5e  call 0x000078D1A56E27E0
000078d1a57e1d63  jmp 0x000078D1A57E1BA2
000078d1a57e1d68  call 0x000078D1A56E1570
000078d1a57e1d6d  jmp 0x000078D1A57E1BAE
000078d1a57e1d72  call 0x000078D1A56E27E0
000078d1a57e1d77  jmp 0x000078D1A57E1BED
000078d1a57e1d7c  call 0x000078D1A560E760
000078d1a57e1d81  jmp 0x000078D1A57E1C0A
000078d1a57e1d86  ucomisd xmm1, xmm15
000078d1a57e1d8b  jp 0x000078D1A57E1D9A
000078d1a57e1d8d  movaps xmm13, [0x000078D1A53FE060]
000078d1a57e1d95  jmp 0x000078D1A57E1C73
000078d1a57e1d9a  vxorps xmm0, xmm1, xmm15
000078d1a57e1d9f  pextrw eax, xmm0, 0x03
000078d1a57e1da4  and eax, 0x7FF8
000078d1a57e1da9  cmp eax, 0x08
000078d1a57e1dac  jnz 0x000078D1A57E1C73
000078d1a57e1db2  movq rax, xmm15
000078d1a57e1db7  shl rax, 0x0D
000078d1a57e1dbb  jbe 0x000078D1A57E1C73
000078d1a57e1dc1  vorps xmm13, xmm15, [0x000078D1A53FE070]
000078d1a57e1dc9  jmp 0x000078D1A57E1C73
000078d1a57e1dce  ucomisd xmm1, xmm15
000078d1a57e1dd3  jp 0x000078D1A57E1DE2
000078d1a57e1dd5  movaps xmm14, [0x000078D1A53FE060]
000078d1a57e1ddd  jmp 0x000078D1A57E1CA0
000078d1a57e1de2  vxorps xmm0, xmm1, xmm15
000078d1a57e1de7  pextrw eax, xmm0, 0x03
000078d1a57e1dec  and eax, 0x7FF8
000078d1a57e1df1  cmp eax, 0x08
000078d1a57e1df4  jnz 0x000078D1A57E1CA0
000078d1a57e1dfa  movq rax, xmm15
000078d1a57e1dff  shl rax, 0x0D
000078d1a57e1e03  jbe 0x000078D1A57E1CA0
000078d1a57e1e09  vorps xmm14, xmm15, [0x000078D1A53FE070]
000078d1a57e1e11  jmp 0x000078D1A57E1CA0
000078d1a57e1e16  int3
000078d1a57e1e17  nop [rax+rax*1], ax
000078d1a57e1e20  mov rax, [r15+0x48]
000078d1a57e1e24  mov r14, [r15+0x50]
000078d1a57e1e28  lea r12, [r14+rax*1]
000078d1a57e1e2c  movups xmm1, [r13+r12*1]
000078d1a57e1e32  movaps [r15+0x120], xmm1
000078d1a57e1e3a  lea r14, [rax+0x10]
000078d1a57e1e3e  mov [r15+0x48], r14
000078d1a57e1e42  xor eax, eax
000078d1a57e1e44  mov r12d, 0x200
000078d1a57e1e4a  cmp r14, r12
000078d1a57e1e4d  cmc
000078d1a57e1e4e  lahf
000078d1a57e1e4f  seto al
000078d1a57e1e52  mov [r15+0x108], eax
000078d1a57e1e59  pextrq rax, xmm1, 0x01
000078d1a57e1e60  movq xmm15, rax
000078d1a57e1e65  movaps [r15+0x130], xmm15
000078d1a57e1e6d  movaps xmm14, [r15+0x110]
000078d1a57e1e75  movq rax, xmm14
000078d1a57e1e7a  movq r14, xmm1
000078d1a57e1e7f  vmovq xmm1, rax
000078d1a57e1e84  vmovq xmm14, r14
000078d1a57e1e89  movaps xmm13, xmm1
000078d1a57e1e8d  addsd xmm13, xmm14
000078d1a57e1e92  ucomisd xmm13, xmm13
000078d1a57e1e97  jp 0x000078D1A57E1F4C
000078d1a57e1e9d  movq xmm13, xmm13
000078d1a57e1ea2  movq rax, xmm13
000078d1a57e1ea7  movq r14, xmm15
000078d1a57e1eac  vmovq xmm1, rax
000078d1a57e1eb1  vmovq xmm15, r14
000078d1a57e1eb6  movaps xmm14, xmm1
000078d1a57e1eba  addsd xmm14, xmm15
000078d1a57e1ebf  ucomisd xmm14, xmm14
000078d1a57e1ec4  jp 0x000078D1A57E1F94
000078d1a57e1eca  movq xmm14, xmm14
000078d1a57e1ecf  movaps [r15+0x110], xmm14
000078d1a57e1ed7  mov eax, [r15+0x108]
000078d1a57e1ede  sahf
000078d1a57e1edf  jnz 0x000078D1A57E1F11
000078d1a57e1ee1  cmp dword ptr [r15+0x318], 0x00
000078d1a57e1ee9  jz 0x000078D1A57E1FE0
000078d1a57e1eef  nop [rax+rax*1], ax
000078d1a57e1ef8  nop [rax+rax*1], eax
000078d1a57e1f00  mov eax, 0x410490
000078d1a57e1f05  mov [r15+0x100], rax
000078d1a57e1f0c  jmp 0x000078D1A55FE110
000078d1a57e1f11  cmp dword ptr [r15+0x318], 0x00
000078d1a57e1f19  jz 0x000078D1A57E1E20
000078d1a57e1f1f  nop [rax+rax*1], ax
000078d1a57e1f28  nop [rax+rax*1], eax
000078d1a57e1f30  mov eax, 0x410474
000078d1a57e1f35  mov [r15+0x100], rax
000078d1a57e1f3c  jmp 0x000078D1A55FE110
000078d1a57e1f41  int3
000078d1a57e1f42  call 0x000078D1A56B52F0
000078d1a57e1f47  jmp 0x000078D1A57E1E32
000078d1a57e1f4c  ucomisd xmm1, xmm14
000078d1a57e1f51  jp 0x000078D1A57E1F60
000078d1a57e1f53  movaps xmm13, [0x000078D1A53FE060]
000078d1a57e1f5b  jmp 0x000078D1A57E1E9D
000078d1a57e1f60  vxorps xmm0, xmm1, xmm14
000078d1a57e1f65  pextrw eax, xmm0, 0x03
000078d1a57e1f6a  and eax, 0x7FF8
000078d1a57e1f6f  cmp eax, 0x08
000078d1a57e1f72  jnz 0x000078D1A57E1E9D
000078d1a57e1f78  movq rax, xmm14
000078d1a57e1f7d  shl rax, 0x0D
000078d1a57e1f81  jbe 0x000078D1A57E1E9D
000078d1a57e1f87  vorps xmm13, xmm14, [0x000078D1A53FE070]
000078d1a57e1f8f  jmp 0x000078D1A57E1E9D
000078d1a57e1f94  ucomisd xmm1, xmm15
000078d1a57e1f99  jp 0x000078D1A57E1FA8
000078d1a57e1f9b  movaps xmm14, [0x000078D1A53FE060]
000078d1a57e1fa3  jmp 0x000078D1A57E1ECA
000078d1a57e1fa8  vxorps xmm0, xmm1, xmm15
000078d1a57e1fad  pextrw eax, xmm0, 0x03
000078d1a57e1fb2  and eax, 0x7FF8
000078d1a57e1fb7  cmp eax, 0x08
000078d1a57e1fba  jnz 0x000078D1A57E1ECA
000078d1a57e1fc0  movq rax, xmm15
000078d1a57e1fc5  shl rax, 0x0D
000078d1a57e1fc9  jbe 0x000078D1A57E1ECA
000078d1a57e1fcf  vorps xmm14, xmm15, [0x000078D1A53FE070]
000078d1a57e1fd7  jmp 0x000078D1A57E1ECA
000078d1a57e1fdc  int3
000078d1a57e1fdd  nop [rax], eax
000078d1a57e1fe0  mov rax, [r15+0x40]
000078d1a57e1fe4  lea r14, [rax+0x510]
000078d1a57e1feb  movaps xmm1, [r15+0x110]
000078d1a57e1ff3  movq rax, xmm1
000078d1a57e1ff8  mov [r13+r14*1], rax
000078d1a57e1ffd  mov rax, [r15+0xF0]
000078d1a57e2004  mov [r15+0x100], rax
000078d1a57e200b  jmp 0x000078D1A57CE5C0
000078d1a57e2010  int3
000078d1a57e2011  call 0x000078D1A56D5EB0
000078d1a57e2016  jmp 0x000078D1A57E1FFD
000078d1a57e201b  int3
000078d1a57e201c  nop [rax], eax
000078d1a57e2020  mov qword ptr [r15+0x100], 0x04
000078d1a57e202b  mov esi, 0x00
000078d1a57e2030  mov edx, 0x09
000078d1a57e2035  mov rdi, 0x7FFC905338F0
000078d1a57e203f  mov rax, 0x56EA208B9970
000078d1a57e2049  call rax
000078d1a57e204b  cmp dword ptr [r15+0x318], 0x00
000078d1a57e2053  jnz 0x000078D1A55FE110
000078d1a57e2059  jmp 0x000078D1A55FE0A0
000078d1a57e205e  int3
000078d1a57e205f  int3
