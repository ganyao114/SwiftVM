000079f9de5ce69b  nop [rax+rax*1], eax
000079f9de5ce6a0  vmovaps xmm1, [0x000079F9DE1FE010]
000079f9de5ce6a8  movq xmm1, xmm1
000079f9de5ce6ac  movaps [r15+0x110], xmm1
000079f9de5ce6b4  vmovaps xmm1, [0x000079F9DE1FE020]
000079f9de5ce6bc  movq xmm1, xmm1
000079f9de5ce6c0  movaps [r15+0x120], xmm1
000079f9de5ce6c8  mov eax, 0x4204C0
000079f9de5ce6cd  mov r14, [r13+rax*1]
000079f9de5ce6d2  movq xmm1, r14
000079f9de5ce6d7  movaps [r15+0x130], xmm1
000079f9de5ce6df  vmovaps xmm1, [0x000079F9DE1FE030]
000079f9de5ce6e7  vpbroadcastq xmm1, xmm1
000079f9de5ce6ec  movaps [r15+0x140], xmm1
000079f9de5ce6f4  mov qword ptr [r15+0x40], 0x02
000079f9de5ce6fc  vmovaps xmm15, [0x000079F9DE1FE040]
000079f9de5ce704  movq xmm15, xmm15
000079f9de5ce709  movaps [r15+0x150], xmm15
000079f9de5ce711  mov qword ptr [r15+0x58], 0x420000
000079f9de5ce719  vmovaps xmm15, [0x000079F9DE1FE050]
000079f9de5ce721  vpbroadcastq xmm15, xmm15
000079f9de5ce726  movaps [r15+0x160], xmm15
000079f9de5ce72e  mov rax, [r15+0x40]
000079f9de5ce732  vmovq xmm14, rax
000079f9de5ce737  vpbroadcastq xmm14, xmm14
000079f9de5ce73c  movaps [r15+0x170], xmm14
000079f9de5ce744  mov eax, 0x4204D0
000079f9de5ce749  movups xmm13, [r13+rax*1]
000079f9de5ce74f  mov qword ptr [r15+0x40], 0x430518
000079f9de5ce757  mov qword ptr [r15+0x50], 0x430720
000079f9de5ce75f  vpmovqd xmm12, xmm13
000079f9de5ce765  pxor xmm11, xmm11
000079f9de5ce76a  punpcklqdq xmm12, xmm11
000079f9de5ce76f  movaps [r15+0x210], xmm12
000079f9de5ce777  movq xmm12, qword ptr [r15+0x120]
000079f9de5ce780  movq xmm11, qword ptr [r15+0x130]
000079f9de5ce789  psubd xmm12, xmm11
000079f9de5ce78e  movq xmm12, xmm12
000079f9de5ce793  paddq xmm13, xmm14
000079f9de5ce798  movaps [r15+0x180], xmm13
000079f9de5ce7a0  movq xmm14, qword ptr [r15+0x150]
000079f9de5ce7a9  paddd xmm11, xmm14
000079f9de5ce7ae  movq xmm11, xmm11
000079f9de5ce7b3  movq xmm11, xmm11
000079f9de5ce7b8  movaps [r15+0x130], xmm11
000079f9de5ce7c0  pmovzxdq xmm12, xmm12
000079f9de5ce7c6  psllq xmm12, 0x00
000079f9de5ce7cc  movq xmm14, qword ptr [r15+0x210]
000079f9de5ce7d5  movq xmm13, qword ptr [r15+0x110]
000079f9de5ce7de  paddd xmm14, xmm13
000079f9de5ce7e3  movq xmm14, xmm14
000079f9de5ce7e8  vcvtuqq2pd xmm12, xmm12
000079f9de5ce7ee  pmovzxdq xmm14, xmm14
000079f9de5ce7f4  psllq xmm14, 0x00
000079f9de5ce7fa  vcvtuqq2pd xmm14, xmm14
000079f9de5ce800  movaps xmm13, xmm12
000079f9de5ce804  mulpd xmm13, xmm1
000079f9de5ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000079f9de5ce80f  ptest xmm11, xmm11
000079f9de5ce815  jnz 0x000079F9DE5CE8FF
000079f9de5ce81b  movaps [r15+0x220], xmm13
000079f9de5ce823  mov eax, 0x430720
000079f9de5ce828  movups [r13+rax*1], xmm13
000079f9de5ce82e  movaps xmm1, xmm14
000079f9de5ce832  mulpd xmm1, xmm15
000079f9de5ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000079f9de5ce83c  ptest xmm13, xmm13
000079f9de5ce842  jnz 0x000079F9DE5CEA4C
000079f9de5ce848  movaps [r15+0x210], xmm1
000079f9de5ce850  mov eax, 0x430518
000079f9de5ce855  movups [r13+rax*1], xmm1
000079f9de5ce85b  mov qword ptr [r15+0x48], 0x10
000079f9de5ce863  xor eax, eax
000079f9de5ce865  mov r14d, 0x10
000079f9de5ce86b  mov r12d, 0x200
000079f9de5ce871  cmp r14, r12
000079f9de5ce874  cmc
000079f9de5ce875  lahf
000079f9de5ce876  seto al
000079f9de5ce879  mov [r15+0x108], eax
000079f9de5ce880  mov eax, [r15+0x108]
000079f9de5ce887  sahf
000079f9de5ce888  jnz 0x000079F9DE5CE8BA
000079f9de5ce88a  cmp dword ptr [r15+0x318], 0x00
000079f9de5ce892  jz 0x000079F9DE5CEFF0
000079f9de5ce898  nop [rax+rax*1], ax
000079f9de5ce8a1  nop [rax+rax*1], eax
000079f9de5ce8a9  mov eax, 0x4101EC
000079f9de5ce8ae  mov [r15+0x100], rax
000079f9de5ce8b5  jmp 0x000079F9DE3FE110
000079f9de5ce8ba  cmp dword ptr [r15+0x318], 0x00
000079f9de5ce8c2  jz 0x000079F9DE5CEBA0
000079f9de5ce8c8  nop [rax+rax*1], ax
000079f9de5ce8d1  nop [rax+rax*1], eax
000079f9de5ce8d9  mov eax, 0x4101AC
000079f9de5ce8de  mov [r15+0x100], rax
000079f9de5ce8e5  jmp 0x000079F9DE3FE110
000079f9de5ce8ea  int3
000079f9de5ce8eb  call 0x000079F9DE40DC20
000079f9de5ce8f0  jmp 0x000079F9DE5CE6D2
000079f9de5ce8f5  call 0x000079F9DE40C260
000079f9de5ce8fa  jmp 0x000079F9DE5CE74F
000079f9de5ce8ff  sub rsp, 0x08
000079f9de5ce903  push rax
000079f9de5ce904  push rcx
000079f9de5ce905  push rdx
000079f9de5ce906  push rdi
000079f9de5ce907  push rsi
000079f9de5ce908  push r8
000079f9de5ce90a  push r9
000079f9de5ce90c  push r10
000079f9de5ce90e  push r11
000079f9de5ce910  sub rsp, 0xF0
000079f9de5ce917  vmovaps [rsp], xmm0
000079f9de5ce91c  vmovaps [rsp+0x10], xmm1
000079f9de5ce922  vmovaps [rsp+0x20], xmm2
000079f9de5ce928  vmovaps [rsp+0x30], xmm3
000079f9de5ce92e  vmovaps [rsp+0x40], xmm4
000079f9de5ce934  vmovaps [rsp+0x50], xmm5
000079f9de5ce93a  vmovaps [rsp+0x60], xmm6
000079f9de5ce940  vmovaps [rsp+0x70], xmm7
000079f9de5ce946  vmovaps [rsp+0x80], xmm8
000079f9de5ce94f  vmovaps [rsp+0x90], xmm9
000079f9de5ce958  vmovaps [rsp+0xA0], xmm10
000079f9de5ce961  vmovaps [rsp+0xB0], xmm11
000079f9de5ce96a  vmovaps [rsp+0xC0], xmm12
000079f9de5ce973  vmovaps [rsp+0xD0], xmm14
000079f9de5ce97c  vmovaps [rsp+0xE0], xmm15
000079f9de5ce985  sub rsp, 0x30
000079f9de5ce989  movaps [rsp], xmm13
000079f9de5ce98e  movaps [rsp+0x10], xmm12
000079f9de5ce994  movaps [rsp+0x20], xmm1
000079f9de5ce999  lea rdi, [rsp]
000079f9de5ce99d  mov esi, 0x00
000079f9de5ce9a2  mov rax, 0x56D56FF59530
000079f9de5ce9ac  call rax
000079f9de5ce9ae  movaps xmm13, [rsp]
000079f9de5ce9b3  add rsp, 0x30
000079f9de5ce9b7  vmovaps xmm0, [rsp]
000079f9de5ce9bc  vmovaps xmm1, [rsp+0x10]
000079f9de5ce9c2  vmovaps xmm2, [rsp+0x20]
000079f9de5ce9c8  vmovaps xmm3, [rsp+0x30]
000079f9de5ce9ce  vmovaps xmm4, [rsp+0x40]
000079f9de5ce9d4  vmovaps xmm5, [rsp+0x50]
000079f9de5ce9da  vmovaps xmm6, [rsp+0x60]
000079f9de5ce9e0  vmovaps xmm7, [rsp+0x70]
000079f9de5ce9e6  vmovaps xmm8, [rsp+0x80]
000079f9de5ce9ef  vmovaps xmm9, [rsp+0x90]
000079f9de5ce9f8  vmovaps xmm10, [rsp+0xA0]
000079f9de5cea01  vmovaps xmm11, [rsp+0xB0]
000079f9de5cea0a  vmovaps xmm12, [rsp+0xC0]
000079f9de5cea13  vmovaps xmm14, [rsp+0xD0]
000079f9de5cea1c  vmovaps xmm15, [rsp+0xE0]
000079f9de5cea25  add rsp, 0xF0
000079f9de5cea2c  pop r11
000079f9de5cea2e  pop r10
000079f9de5cea30  pop r9
000079f9de5cea32  pop r8
000079f9de5cea34  pop rsi
000079f9de5cea35  pop rdi
000079f9de5cea36  pop rdx
000079f9de5cea37  pop rcx
000079f9de5cea38  pop rax
000079f9de5cea39  add rsp, 0x08
000079f9de5cea3d  jmp 0x000079F9DE5CE81B
000079f9de5cea42  call 0x000079F9DE40C380
000079f9de5cea47  jmp 0x000079F9DE5CE82E
000079f9de5cea4c  sub rsp, 0x08
000079f9de5cea50  push rax
000079f9de5cea51  push rcx
000079f9de5cea52  push rdx
000079f9de5cea53  push rdi
000079f9de5cea54  push rsi
000079f9de5cea55  push r8
000079f9de5cea57  push r9
000079f9de5cea59  push r10
000079f9de5cea5b  push r11
000079f9de5cea5d  sub rsp, 0xF0
000079f9de5cea64  vmovaps [rsp], xmm0
000079f9de5cea69  vmovaps [rsp+0x10], xmm2
000079f9de5cea6f  vmovaps [rsp+0x20], xmm3
000079f9de5cea75  vmovaps [rsp+0x30], xmm4
000079f9de5cea7b  vmovaps [rsp+0x40], xmm5
000079f9de5cea81  vmovaps [rsp+0x50], xmm6
000079f9de5cea87  vmovaps [rsp+0x60], xmm7
000079f9de5cea8d  vmovaps [rsp+0x70], xmm8
000079f9de5cea93  vmovaps [rsp+0x80], xmm9
000079f9de5cea9c  vmovaps [rsp+0x90], xmm10
000079f9de5ceaa5  vmovaps [rsp+0xA0], xmm11
000079f9de5ceaae  vmovaps [rsp+0xB0], xmm12
000079f9de5ceab7  vmovaps [rsp+0xC0], xmm13
000079f9de5ceac0  vmovaps [rsp+0xD0], xmm14
000079f9de5ceac9  vmovaps [rsp+0xE0], xmm15
000079f9de5cead2  sub rsp, 0x30
000079f9de5cead6  movaps [rsp], xmm1
000079f9de5ceada  movaps [rsp+0x10], xmm14
000079f9de5ceae0  movaps [rsp+0x20], xmm15
000079f9de5ceae6  lea rdi, [rsp]
000079f9de5ceaea  mov esi, 0x00
000079f9de5ceaef  mov rax, 0x56D56FF59530
000079f9de5ceaf9  call rax
000079f9de5ceafb  movaps xmm1, [rsp]
000079f9de5ceaff  add rsp, 0x30
000079f9de5ceb03  vmovaps xmm0, [rsp]
000079f9de5ceb08  vmovaps xmm2, [rsp+0x10]
000079f9de5ceb0e  vmovaps xmm3, [rsp+0x20]
000079f9de5ceb14  vmovaps xmm4, [rsp+0x30]
000079f9de5ceb1a  vmovaps xmm5, [rsp+0x40]
000079f9de5ceb20  vmovaps xmm6, [rsp+0x50]
000079f9de5ceb26  vmovaps xmm7, [rsp+0x60]
000079f9de5ceb2c  vmovaps xmm8, [rsp+0x70]
000079f9de5ceb32  vmovaps xmm9, [rsp+0x80]
000079f9de5ceb3b  vmovaps xmm10, [rsp+0x90]
000079f9de5ceb44  vmovaps xmm11, [rsp+0xA0]
000079f9de5ceb4d  vmovaps xmm12, [rsp+0xB0]
000079f9de5ceb56  vmovaps xmm13, [rsp+0xC0]
000079f9de5ceb5f  vmovaps xmm14, [rsp+0xD0]
000079f9de5ceb68  vmovaps xmm15, [rsp+0xE0]
000079f9de5ceb71  add rsp, 0xF0
000079f9de5ceb78  pop r11
000079f9de5ceb7a  pop r10
000079f9de5ceb7c  pop r9
000079f9de5ceb7e  pop r8
000079f9de5ceb80  pop rsi
000079f9de5ceb81  pop rdi
000079f9de5ceb82  pop rdx
000079f9de5ceb83  pop rcx
000079f9de5ceb84  pop rax
000079f9de5ceb85  add rsp, 0x08
000079f9de5ceb89  jmp 0x000079F9DE5CE848
000079f9de5ceb8e  call 0x000079F9DE3FF540
000079f9de5ceb93  jmp 0x000079F9DE5CE85B
000079f9de5ceb98  int3
000079f9de5ceb99  nop [rax], eax
000079f9de5ceba0  movaps xmm1, [r15+0x180]
000079f9de5ceba8  vpmovqd xmm15, xmm1
000079f9de5cebae  pxor xmm14, xmm14
000079f9de5cebb3  punpcklqdq xmm15, xmm14
000079f9de5cebb8  movaps [r15+0x210], xmm15
000079f9de5cebc0  movq xmm15, qword ptr [r15+0x120]
000079f9de5cebc9  movq xmm14, qword ptr [r15+0x130]
000079f9de5cebd2  psubd xmm15, xmm14
000079f9de5cebd7  movq xmm15, xmm15
000079f9de5cebdc  movaps xmm13, [r15+0x170]
000079f9de5cebe4  paddq xmm1, xmm13
000079f9de5cebe9  movaps [r15+0x180], xmm1
000079f9de5cebf1  movq xmm1, qword ptr [r15+0x150]
000079f9de5cebfa  paddd xmm14, xmm1
000079f9de5cebff  movq xmm14, xmm14
000079f9de5cec04  movq xmm14, xmm14
000079f9de5cec09  movaps [r15+0x130], xmm14
000079f9de5cec11  pmovzxdq xmm15, xmm15
000079f9de5cec17  psllq xmm15, 0x00
000079f9de5cec1d  movq xmm1, qword ptr [r15+0x210]
000079f9de5cec26  movq xmm14, qword ptr [r15+0x110]
000079f9de5cec2f  paddd xmm1, xmm14
000079f9de5cec34  movq xmm1, xmm1
000079f9de5cec38  vcvtuqq2pd xmm15, xmm15
000079f9de5cec3e  pmovzxdq xmm1, xmm1
000079f9de5cec43  psllq xmm1, 0x00
000079f9de5cec48  vcvtuqq2pd xmm1, xmm1
000079f9de5cec4e  movaps xmm14, [r15+0x140]
000079f9de5cec56  movaps xmm13, xmm15
000079f9de5cec5a  mulpd xmm13, xmm14
000079f9de5cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000079f9de5cec65  ptest xmm12, xmm12
000079f9de5cec6b  jnz 0x000079F9DE5CED4E
000079f9de5cec71  movaps [r15+0x220], xmm13
000079f9de5cec79  mov rax, [r15+0x48]
000079f9de5cec7d  mov r14, [r15+0x50]
000079f9de5cec81  lea r12, [r14+rax*1]
000079f9de5cec85  movups [r13+r12*1], xmm13
000079f9de5cec8b  movaps xmm15, [r15+0x160]
000079f9de5cec93  movaps xmm14, xmm1
000079f9de5cec97  mulpd xmm14, xmm15
000079f9de5cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000079f9de5ceca2  ptest xmm13, xmm13
000079f9de5ceca8  jnz 0x000079F9DE5CEE9C
000079f9de5cecae  movaps [r15+0x210], xmm14
000079f9de5cecb6  mov r14, [r15+0x40]
000079f9de5cecba  lea r12, [r14+rax*1]
000079f9de5cecbe  movups [r13+r12*1], xmm14
000079f9de5cecc4  lea r14, [rax+0x10]
000079f9de5cecc8  mov [r15+0x48], r14
000079f9de5ceccc  xor eax, eax
000079f9de5cecce  mov r12d, 0x200
000079f9de5cecd4  cmp r14, r12
000079f9de5cecd7  cmc
000079f9de5cecd8  lahf
000079f9de5cecd9  seto al
000079f9de5cecdc  mov [r15+0x108], eax
000079f9de5cece3  mov eax, [r15+0x108]
000079f9de5cecea  sahf
000079f9de5ceceb  jnz 0x000079F9DE5CED1D
000079f9de5ceced  cmp dword ptr [r15+0x318], 0x00
000079f9de5cecf5  jz 0x000079F9DE5CEFF0
000079f9de5cecfb  nop [rax+rax*1], ax
000079f9de5ced04  nop [rax+rax*1], eax
000079f9de5ced0c  mov eax, 0x4101EC
000079f9de5ced11  mov [r15+0x100], rax
000079f9de5ced18  jmp 0x000079F9DE3FE110
000079f9de5ced1d  cmp dword ptr [r15+0x318], 0x00
000079f9de5ced25  jz 0x000079F9DE5CEBA0
000079f9de5ced2b  nop [rax+rax*1], ax
000079f9de5ced34  nop [rax+rax*1], eax
000079f9de5ced3c  mov eax, 0x4101AC
000079f9de5ced41  mov [r15+0x100], rax
000079f9de5ced48  jmp 0x000079F9DE3FE110
000079f9de5ced4d  int3
000079f9de5ced4e  sub rsp, 0x08
000079f9de5ced52  push rax
000079f9de5ced53  push rcx
000079f9de5ced54  push rdx
000079f9de5ced55  push rdi
000079f9de5ced56  push rsi
000079f9de5ced57  push r8
000079f9de5ced59  push r9
000079f9de5ced5b  push r10
000079f9de5ced5d  push r11
000079f9de5ced5f  sub rsp, 0xF0
000079f9de5ced66  vmovaps [rsp], xmm0
000079f9de5ced6b  vmovaps [rsp+0x10], xmm1
000079f9de5ced71  vmovaps [rsp+0x20], xmm2
000079f9de5ced77  vmovaps [rsp+0x30], xmm3
000079f9de5ced7d  vmovaps [rsp+0x40], xmm4
000079f9de5ced83  vmovaps [rsp+0x50], xmm5
000079f9de5ced89  vmovaps [rsp+0x60], xmm6
000079f9de5ced8f  vmovaps [rsp+0x70], xmm7
000079f9de5ced95  vmovaps [rsp+0x80], xmm8
000079f9de5ced9e  vmovaps [rsp+0x90], xmm9
000079f9de5ceda7  vmovaps [rsp+0xA0], xmm10
000079f9de5cedb0  vmovaps [rsp+0xB0], xmm11
000079f9de5cedb9  vmovaps [rsp+0xC0], xmm12
000079f9de5cedc2  vmovaps [rsp+0xD0], xmm14
000079f9de5cedcb  vmovaps [rsp+0xE0], xmm15
000079f9de5cedd4  sub rsp, 0x30
000079f9de5cedd8  movaps [rsp], xmm13
000079f9de5ceddd  movaps [rsp+0x10], xmm15
000079f9de5cede3  movaps [rsp+0x20], xmm14
000079f9de5cede9  lea rdi, [rsp]
000079f9de5ceded  mov esi, 0x00
000079f9de5cedf2  mov rax, 0x56D56FF59530
000079f9de5cedfc  call rax
000079f9de5cedfe  movaps xmm13, [rsp]
000079f9de5cee03  add rsp, 0x30
000079f9de5cee07  vmovaps xmm0, [rsp]
000079f9de5cee0c  vmovaps xmm1, [rsp+0x10]
000079f9de5cee12  vmovaps xmm2, [rsp+0x20]
000079f9de5cee18  vmovaps xmm3, [rsp+0x30]
000079f9de5cee1e  vmovaps xmm4, [rsp+0x40]
000079f9de5cee24  vmovaps xmm5, [rsp+0x50]
000079f9de5cee2a  vmovaps xmm6, [rsp+0x60]
000079f9de5cee30  vmovaps xmm7, [rsp+0x70]
000079f9de5cee36  vmovaps xmm8, [rsp+0x80]
000079f9de5cee3f  vmovaps xmm9, [rsp+0x90]
000079f9de5cee48  vmovaps xmm10, [rsp+0xA0]
000079f9de5cee51  vmovaps xmm11, [rsp+0xB0]
000079f9de5cee5a  vmovaps xmm12, [rsp+0xC0]
000079f9de5cee63  vmovaps xmm14, [rsp+0xD0]
000079f9de5cee6c  vmovaps xmm15, [rsp+0xE0]
000079f9de5cee75  add rsp, 0xF0
000079f9de5cee7c  pop r11
000079f9de5cee7e  pop r10
000079f9de5cee80  pop r9
000079f9de5cee82  pop r8
000079f9de5cee84  pop rsi
000079f9de5cee85  pop rdi
000079f9de5cee86  pop rdx
000079f9de5cee87  pop rcx
000079f9de5cee88  pop rax
000079f9de5cee89  add rsp, 0x08
000079f9de5cee8d  jmp 0x000079F9DE5CEC71
000079f9de5cee92  call 0x000079F9DE4C2240
000079f9de5cee97  jmp 0x000079F9DE5CEC8B
000079f9de5cee9c  sub rsp, 0x08
000079f9de5ceea0  push rax
000079f9de5ceea1  push rcx
000079f9de5ceea2  push rdx
000079f9de5ceea3  push rdi
000079f9de5ceea4  push rsi
000079f9de5ceea5  push r8
000079f9de5ceea7  push r9
000079f9de5ceea9  push r10
000079f9de5ceeab  push r11
000079f9de5ceead  sub rsp, 0xF0
000079f9de5ceeb4  vmovaps [rsp], xmm0
000079f9de5ceeb9  vmovaps [rsp+0x10], xmm1
000079f9de5ceebf  vmovaps [rsp+0x20], xmm2
000079f9de5ceec5  vmovaps [rsp+0x30], xmm3
000079f9de5ceecb  vmovaps [rsp+0x40], xmm4
000079f9de5ceed1  vmovaps [rsp+0x50], xmm5
000079f9de5ceed7  vmovaps [rsp+0x60], xmm6
000079f9de5ceedd  vmovaps [rsp+0x70], xmm7
000079f9de5ceee3  vmovaps [rsp+0x80], xmm8
000079f9de5ceeec  vmovaps [rsp+0x90], xmm9
000079f9de5ceef5  vmovaps [rsp+0xA0], xmm10
000079f9de5ceefe  vmovaps [rsp+0xB0], xmm11
000079f9de5cef07  vmovaps [rsp+0xC0], xmm12
000079f9de5cef10  vmovaps [rsp+0xD0], xmm13
000079f9de5cef19  vmovaps [rsp+0xE0], xmm15
000079f9de5cef22  sub rsp, 0x30
000079f9de5cef26  movaps [rsp], xmm14
000079f9de5cef2b  movaps [rsp+0x10], xmm1
000079f9de5cef30  movaps [rsp+0x20], xmm15
000079f9de5cef36  lea rdi, [rsp]
000079f9de5cef3a  mov esi, 0x00
000079f9de5cef3f  mov rax, 0x56D56FF59530
000079f9de5cef49  call rax
000079f9de5cef4b  movaps xmm14, [rsp]
000079f9de5cef50  add rsp, 0x30
000079f9de5cef54  vmovaps xmm0, [rsp]
000079f9de5cef59  vmovaps xmm1, [rsp+0x10]
000079f9de5cef5f  vmovaps xmm2, [rsp+0x20]
000079f9de5cef65  vmovaps xmm3, [rsp+0x30]
000079f9de5cef6b  vmovaps xmm4, [rsp+0x40]
000079f9de5cef71  vmovaps xmm5, [rsp+0x50]
000079f9de5cef77  vmovaps xmm6, [rsp+0x60]
000079f9de5cef7d  vmovaps xmm7, [rsp+0x70]
000079f9de5cef83  vmovaps xmm8, [rsp+0x80]
000079f9de5cef8c  vmovaps xmm9, [rsp+0x90]
000079f9de5cef95  vmovaps xmm10, [rsp+0xA0]
000079f9de5cef9e  vmovaps xmm11, [rsp+0xB0]
000079f9de5cefa7  vmovaps xmm12, [rsp+0xC0]
000079f9de5cefb0  vmovaps xmm13, [rsp+0xD0]
000079f9de5cefb9  vmovaps xmm15, [rsp+0xE0]
000079f9de5cefc2  add rsp, 0xF0
000079f9de5cefc9  pop r11
000079f9de5cefcb  pop r10
000079f9de5cefcd  pop r9
000079f9de5cefcf  pop r8
000079f9de5cefd1  pop rsi
000079f9de5cefd2  pop rdi
000079f9de5cefd3  pop rdx
000079f9de5cefd4  pop rcx
000079f9de5cefd5  pop rax
000079f9de5cefd6  add rsp, 0x08
000079f9de5cefda  jmp 0x000079F9DE5CECAE
000079f9de5cefdf  call 0x000079F9DE4C34C0
000079f9de5cefe4  jmp 0x000079F9DE5CECC4
000079f9de5cefe9  int3
000079f9de5cefea  nop [rax+rax*1], ax
000079f9de5ceff0  mov rax, [r15+0xF8]
000079f9de5ceff7  lea r14, [rax-0x150]
000079f9de5ceffe  mov [r15+0xF8], r14
000079f9de5cf005  mov rax, [r15+0x50]
000079f9de5cf009  lea r12, [rax+0x80]
000079f9de5cf010  movups xmm1, [r13+r12*1]
000079f9de5cf016  lea r12, [rax+0x90]
000079f9de5cf01d  movups xmm15, [r13+r12*1]
000079f9de5cf023  mov qword ptr [r15+0x48], 0x00
000079f9de5cf02b  lea r12, [rax+0x40]
000079f9de5cf02f  movups xmm14, [r13+r12*1]
000079f9de5cf035  lea r12, [rax+0x50]
000079f9de5cf039  movups xmm13, [r13+r12*1]
000079f9de5cf03f  lea r12, [r14+0x120]
000079f9de5cf046  movq xmm12, qword ptr [r15+0x1C0]
000079f9de5cf04f  movq xmm11, qword ptr [r15+0x1B0]
000079f9de5cf058  movq r11, xmm12
000079f9de5cf05d  movq r10, xmm11
000079f9de5cf062  mov [r13+r12*1], r11
000079f9de5cf067  lea r12, [r14+0x128]
000079f9de5cf06e  mov [r13+r12*1], r10
000079f9de5cf073  vxorps xmm12, xmm12, xmm12
000079f9de5cf078  vpbroadcastq xmm12, xmm12
000079f9de5cf07d  lea r12, [r14+0x100]
000079f9de5cf084  movq xmm11, qword ptr [r15+0x200]
000079f9de5cf08d  movq xmm10, qword ptr [r15+0x1F0]
000079f9de5cf096  movq r11, xmm11
000079f9de5cf09b  movq r10, xmm10
000079f9de5cf0a0  mov [r13+r12*1], r11
000079f9de5cf0a5  lea r12, [r14+0x108]
000079f9de5cf0ac  mov [r13+r12*1], r10
000079f9de5cf0b1  lea r12, [r14+0xE0]
000079f9de5cf0b8  movups [r13+r12*1], xmm15
000079f9de5cf0be  lea r12, [r14+0xF0]
000079f9de5cf0c5  movups [r13+r12*1], xmm1
000079f9de5cf0cb  lea r12, [rax+0xC0]
000079f9de5cf0d2  movups xmm1, [r13+r12*1]
000079f9de5cf0d8  lea r12, [rax+0xD0]
000079f9de5cf0df  movups xmm15, [r13+r12*1]
000079f9de5cf0e5  lea r12, [r14+0x110]
000079f9de5cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000079f9de5cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000079f9de5cf0fe  movq r11, xmm11
000079f9de5cf103  movq r10, xmm10
000079f9de5cf108  mov [r13+r12*1], r11
000079f9de5cf10d  lea r12, [r14+0x118]
000079f9de5cf114  mov [r13+r12*1], r10
000079f9de5cf119  movups xmm11, [r13+rax*1]
000079f9de5cf11f  lea r12, [rax+0x10]
000079f9de5cf123  movups xmm10, [r13+r12*1]
000079f9de5cf129  lea r12, [r14+0x130]
000079f9de5cf130  movq xmm9, qword ptr [r15+0x1A0]
000079f9de5cf139  movq xmm8, qword ptr [r15+0x190]
000079f9de5cf142  movq r11, xmm9
000079f9de5cf147  movq r10, xmm8
000079f9de5cf14c  mov [r13+r12*1], r11
000079f9de5cf151  lea r12, [r14+0x138]
000079f9de5cf158  mov [r13+r12*1], r10
000079f9de5cf15d  lea r12, [rax+0x140]
000079f9de5cf164  movups xmm9, [r13+r12*1]
000079f9de5cf16a  lea r12, [rax+0x150]
000079f9de5cf171  movups xmm8, [r13+r12*1]
000079f9de5cf177  lea r12, [r14+0xC0]
000079f9de5cf17e  movups [r13+r12*1], xmm15
000079f9de5cf184  lea r12, [r14+0xD0]
000079f9de5cf18b  movups [r13+r12*1], xmm1
000079f9de5cf191  lea r12, [rax+0x100]
000079f9de5cf198  movups xmm1, [r13+r12*1]
000079f9de5cf19e  lea r12, [rax+0x110]
000079f9de5cf1a5  movups xmm15, [r13+r12*1]
000079f9de5cf1ab  lea r12, [r14+0x140]
000079f9de5cf1b2  mov r11, [r15+0xE8]
000079f9de5cf1b9  mov [r13+r12*1], r11
000079f9de5cf1be  lea r12, [rax+0x180]
000079f9de5cf1c5  movups xmm7, [r13+r12*1]
000079f9de5cf1cb  lea r12, [rax+0x190]
000079f9de5cf1d2  movups xmm6, [r13+r12*1]
000079f9de5cf1d8  lea r12, [rax+0x1C0]
000079f9de5cf1df  movups xmm5, [r13+r12*1]
000079f9de5cf1e5  lea r12, [rax+0x1D0]
000079f9de5cf1ec  movups xmm4, [r13+r12*1]
000079f9de5cf1f2  lea r12, [r14+0x20]
000079f9de5cf1f6  movups [r13+r12*1], xmm1
000079f9de5cf1fc  lea r12, [r14+0x30]
000079f9de5cf200  movups [r13+r12*1], xmm13
000079f9de5cf206  lea r12, [rax+0x60]
000079f9de5cf20a  movups xmm1, [r13+r12*1]
000079f9de5cf210  lea r12, [rax+0x70]
000079f9de5cf214  movups xmm13, [r13+r12*1]
000079f9de5cf21a  lea r12, [rax+0x20]
000079f9de5cf21e  movups xmm3, [r13+r12*1]
000079f9de5cf224  lea r12, [rax+0x30]
000079f9de5cf228  movups xmm2, [r13+r12*1]
000079f9de5cf22e  movaps [r15+0x1F0], xmm2
000079f9de5cf236  lea r12, [r14+0x60]
000079f9de5cf23a  movups [r13+r12*1], xmm11
000079f9de5cf240  lea r12, [r14+0x70]
000079f9de5cf244  movups [r13+r12*1], xmm5
000079f9de5cf24a  lea r12, [rax+0xE0]
000079f9de5cf251  movups xmm11, [r13+r12*1]
000079f9de5cf257  lea r12, [rax+0xF0]
000079f9de5cf25e  movups xmm5, [r13+r12*1]
000079f9de5cf264  lea r12, [r14+0xA0]
000079f9de5cf26b  movups [r13+r12*1], xmm13
000079f9de5cf271  lea r12, [r14+0xB0]
000079f9de5cf278  movups [r13+r12*1], xmm1
000079f9de5cf27e  lea r12, [rax+0xA0]
000079f9de5cf285  movups xmm1, [r13+r12*1]
000079f9de5cf28b  lea r12, [rax+0xB0]
000079f9de5cf292  movups xmm13, [r13+r12*1]
000079f9de5cf298  lea r12, [rax+0x120]
000079f9de5cf29f  vmovaps [rsp+0x10], xmm1
000079f9de5cf2a5  movups xmm1, [r13+r12*1]
000079f9de5cf2ab  lea r12, [rax+0x130]
000079f9de5cf2b2  vmovaps [rsp+0x20], xmm1
000079f9de5cf2b8  movups xmm1, [r13+r12*1]
000079f9de5cf2be  lea r12, [rax+0x160]
000079f9de5cf2c5  vmovaps [rsp+0x30], xmm1
000079f9de5cf2cb  movups xmm1, [r13+r12*1]
000079f9de5cf2d1  lea r12, [rax+0x170]
000079f9de5cf2d8  vmovaps [rsp+0x40], xmm1
000079f9de5cf2de  movups xmm1, [r13+r12*1]
000079f9de5cf2e4  movaps [r15+0x2B0], xmm1
000079f9de5cf2ec  lea r12, [r14+0x80]
000079f9de5cf2f3  movups [r13+r12*1], xmm13
000079f9de5cf2f9  lea r12, [r14+0x90]
000079f9de5cf300  vmovaps xmm13, [rsp+0x10]
000079f9de5cf306  movups [r13+r12*1], xmm13
000079f9de5cf30c  lea r12, [rax+0x1A0]
000079f9de5cf313  movups xmm13, [r13+r12*1]
000079f9de5cf319  lea r12, [rax+0x1B0]
000079f9de5cf320  vmovaps [rsp+0x10], xmm1
000079f9de5cf326  movups xmm1, [r13+r12*1]
000079f9de5cf32c  movaps [r15+0x290], xmm13
000079f9de5cf334  movaps [r15+0x1E0], xmm1
000079f9de5cf33c  lea r12, [rax+0x1E0]
000079f9de5cf343  vmovaps [rsp+0x50], xmm1
000079f9de5cf349  movups xmm1, [r13+r12*1]
000079f9de5cf34f  lea r12, [rax+0x1F0]
000079f9de5cf356  vmovaps [rsp+0x60], xmm1
000079f9de5cf35c  movups xmm1, [r13+r12*1]
000079f9de5cf362  mov qword ptr [r15+0x50], 0x430920
000079f9de5cf36a  lea rax, [r14+0x40]
000079f9de5cf36e  vmovaps [rsp+0x70], xmm1
000079f9de5cf374  vmovaps xmm1, [rsp+0x40]
000079f9de5cf37a  movups [r13+rax*1], xmm1
000079f9de5cf380  lea rax, [r14+0x50]
000079f9de5cf384  movups [r13+rax*1], xmm10
000079f9de5cf38a  vmovaps xmm1, [rsp+0x70]
000079f9de5cf390  movups [r13+r14*1], xmm1
000079f9de5cf396  lea rax, [r14+0x10]
000079f9de5cf39a  vmovaps xmm1, [rsp+0x60]
000079f9de5cf3a0  movups [r13+rax*1], xmm1
000079f9de5cf3a6  mov rax, [r15+0x40]
000079f9de5cf3aa  vmovaps [rsp+0x40], xmm3
000079f9de5cf3b0  vmovaps xmm1, [rsp+0x40]
000079f9de5cf3b6  por xmm3, xmm1
000079f9de5cf3ba  vmovaps [rsp+0x40], xmm6
000079f9de5cf3c0  vmovaps xmm10, [rsp+0x40]
000079f9de5cf3c6  por xmm6, xmm10
000079f9de5cf3cb  lea r12, [rax+0x30]
000079f9de5cf3cf  mov r11, [r13+r12*1]
000079f9de5cf3d4  lea r12, [rax+0x38]
000079f9de5cf3d8  mov r10, [r13+r12*1]
000079f9de5cf3dd  movq xmm10, r11
000079f9de5cf3e2  vmovaps [rsp+0x40], xmm1
000079f9de5cf3e8  movq xmm1, r10
000079f9de5cf3ed  movq xmm10, xmm10
000079f9de5cf3f2  vmovaps [rsp+0x60], xmm10
000079f9de5cf3f8  movq xmm10, xmm10
000079f9de5cf3fd  movaps [r15+0x130], xmm10
000079f9de5cf405  movq xmm1, xmm1
000079f9de5cf409  vmovaps [rsp+0x70], xmm1
000079f9de5cf40f  movq xmm1, xmm1
000079f9de5cf413  movaps [r15+0x280], xmm1
000079f9de5cf41b  vmovaps [rsp+0x80], xmm9
000079f9de5cf424  vmovaps xmm1, [rsp+0x80]
000079f9de5cf42d  por xmm9, xmm1
000079f9de5cf432  lea r12, [rax+0x20]
000079f9de5cf436  mov r11, [r13+r12*1]
000079f9de5cf43b  lea r12, [rax+0x28]
000079f9de5cf43f  mov r10, [r13+r12*1]
000079f9de5cf444  movq xmm1, r11
000079f9de5cf449  movq xmm10, r10
000079f9de5cf44e  movq xmm1, xmm1
000079f9de5cf452  vmovaps [rsp+0x80], xmm1
000079f9de5cf45b  movq xmm1, xmm1
000079f9de5cf45f  movaps [r15+0x150], xmm1
000079f9de5cf467  movq xmm10, xmm10
000079f9de5cf46c  vmovaps [rsp+0x90], xmm10
000079f9de5cf475  movq xmm10, xmm10
000079f9de5cf47a  movaps [r15+0x140], xmm10
000079f9de5cf482  lea r12, [rax+0x10]
000079f9de5cf486  mov r11, [r13+r12*1]
000079f9de5cf48b  lea r12, [rax+0x18]
000079f9de5cf48f  mov r10, [r13+r12*1]
000079f9de5cf494  movq xmm1, r11
000079f9de5cf499  movq xmm10, r10
000079f9de5cf49e  movq xmm1, xmm1
000079f9de5cf4a2  vmovaps [rsp+0xA0], xmm1
000079f9de5cf4ab  movq xmm1, xmm1
000079f9de5cf4af  movaps [r15+0x170], xmm1
000079f9de5cf4b7  movq xmm10, xmm10
000079f9de5cf4bc  vmovaps [rsp+0xB0], xmm10
000079f9de5cf4c5  movq xmm10, xmm10
000079f9de5cf4ca  movaps [r15+0x160], xmm10
000079f9de5cf4d2  mov r12, [r13+rax*1]
000079f9de5cf4d7  vmovq xmm1, r12
000079f9de5cf4dc  vpbroadcastq xmm1, xmm1
000079f9de5cf4e1  lea r12, [rax+0x08]
000079f9de5cf4e5  mov rax, [r13+r12*1]
000079f9de5cf4ea  movq xmm10, rax
000079f9de5cf4ef  movaps [r15+0x230], xmm10
000079f9de5cf4f7  lea rax, [r14+0x50]
000079f9de5cf4fb  movups xmm10, [r13+rax*1]
000079f9de5cf501  lea rax, [r14+0x60]
000079f9de5cf505  vmovaps [rsp+0xC0], xmm1
000079f9de5cf50e  movups xmm1, [r13+rax*1]
000079f9de5cf514  lea rax, [r14+0x30]
000079f9de5cf518  vmovaps [rsp+0xD0], xmm1
000079f9de5cf521  movups xmm1, [r13+rax*1]
000079f9de5cf527  mov qword ptr [r15+0x60], 0x430920
000079f9de5cf52f  mov qword ptr [r15+0x58], 0x40
000079f9de5cf537  vmovaps [rsp+0xE0], xmm1
000079f9de5cf540  vmovaps [rsp+0xF0], xmm15
000079f9de5cf549  vmovaps xmm15, [rsp+0xC0]
000079f9de5cf552  vmovaps [rsp+0xC0], xmm14
000079f9de5cf55b  vmovaps xmm14, [rsp+0x40]
000079f9de5cf561  vmovaps [rsp+0x40], xmm13
000079f9de5cf567  movaps xmm1, xmm15
000079f9de5cf56b  mulpd xmm1, xmm14
000079f9de5cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000079f9de5cf575  ptest xmm13, xmm13
000079f9de5cf57b  jnz 0x000079F9DE5D0682
000079f9de5cf581  movq xmm14, qword ptr [r15+0x230]
000079f9de5cf58a  vmovaps [rsp+0x100], xmm14
000079f9de5cf593  vpermilpd xmm14, xmm14, 0x00
000079f9de5cf599  vmovaps [rsp+0x110], xmm1
000079f9de5cf5a2  vmovaps xmm1, [rsp+0xE0]
000079f9de5cf5ab  vmovaps [rsp+0xE0], xmm15
000079f9de5cf5b4  movaps xmm13, xmm1
000079f9de5cf5b8  mulpd xmm13, xmm14
000079f9de5cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000079f9de5cf5c3  ptest xmm15, xmm15
000079f9de5cf5c9  jnz 0x000079F9DE5D07C4
000079f9de5cf5cf  vxorps xmm1, xmm1, xmm1
000079f9de5cf5d3  vpbroadcastq xmm1, xmm1
000079f9de5cf5d8  vmovaps xmm14, [rsp+0xE0]
000079f9de5cf5e1  vmovaps [rsp+0xE0], xmm1
000079f9de5cf5ea  vmovaps xmm1, [rsp+0xD0]
000079f9de5cf5f3  vmovaps [rsp+0xD0], xmm13
000079f9de5cf5fc  movaps xmm15, xmm14
000079f9de5cf600  mulpd xmm15, xmm1
000079f9de5cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000079f9de5cf60b  ptest xmm13, xmm13
000079f9de5cf611  jnz 0x000079F9DE5D0907
000079f9de5cf617  movaps xmm1, xmm14
000079f9de5cf61b  mulpd xmm1, xmm10
000079f9de5cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000079f9de5cf625  ptest xmm13, xmm13
000079f9de5cf62b  jnz 0x000079F9DE5D0A4A
000079f9de5cf631  movaps xmm13, xmm14
000079f9de5cf635  mulpd xmm13, xmm2
000079f9de5cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000079f9de5cf640  ptest xmm10, xmm10
000079f9de5cf646  jnz 0x000079F9DE5D0B8C
000079f9de5cf64c  vmovaps [rsp+0x120], xmm7
000079f9de5cf655  vmovaps xmm14, [rsp+0x120]
000079f9de5cf65e  por xmm7, xmm14
000079f9de5cf663  vmovaps xmm14, [rsp+0xC0]
000079f9de5cf66c  vmovaps xmm10, [rsp+0xC0]
000079f9de5cf675  por xmm14, xmm10
000079f9de5cf67a  vmovaps xmm2, [rsp+0x100]
000079f9de5cf683  vpermilpd xmm2, xmm2, 0x00
000079f9de5cf689  vmovaps [rsp+0xC0], xmm1
000079f9de5cf692  vmovaps [rsp+0x120], xmm15
000079f9de5cf69b  movaps xmm1, xmm10
000079f9de5cf69f  mulpd xmm1, xmm2
000079f9de5cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000079f9de5cf6a8  ptest xmm15, xmm15
000079f9de5cf6ae  jnz 0x000079F9DE5D0CCF
000079f9de5cf6b4  xor eax, eax
000079f9de5cf6b6  mov r12d, 0x40
000079f9de5cf6bc  mov r11d, 0x200
000079f9de5cf6c2  cmp r12, r11
000079f9de5cf6c5  cmc
000079f9de5cf6c6  lahf
000079f9de5cf6c7  seto al
000079f9de5cf6ca  mov [r15+0x108], eax
000079f9de5cf6d1  vmovaps xmm10, [rsp+0x110]
000079f9de5cf6da  vmovaps xmm2, [rsp+0xE0]
000079f9de5cf6e3  vmovaps [rsp+0xE0], xmm1
000079f9de5cf6ec  movaps xmm15, xmm10
000079f9de5cf6f0  addpd xmm15, xmm2
000079f9de5cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000079f9de5cf6fb  ptest xmm1, xmm1
000079f9de5cf700  jnz 0x000079F9DE5D0E10
000079f9de5cf706  vmovaps xmm10, [rsp+0x120]
000079f9de5cf70f  vmovaps [rsp+0x110], xmm15
000079f9de5cf718  movaps xmm1, xmm10
000079f9de5cf71c  addpd xmm1, xmm12
000079f9de5cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000079f9de5cf726  ptest xmm15, xmm15
000079f9de5cf72c  jnz 0x000079F9DE5D0F53
000079f9de5cf732  vmovaps xmm10, [rsp+0xC0]
000079f9de5cf73b  vmovaps [rsp+0xC0], xmm1
000079f9de5cf744  movaps xmm15, xmm10
000079f9de5cf748  addpd xmm15, xmm12
000079f9de5cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000079f9de5cf753  ptest xmm1, xmm1
000079f9de5cf758  jnz 0x000079F9DE5D1095
000079f9de5cf75e  vmovaps xmm1, [rsp+0x30]
000079f9de5cf764  vmovaps xmm12, [rsp+0x30]
000079f9de5cf76a  por xmm1, xmm12
000079f9de5cf76f  vmovaps xmm12, [rsp+0x20]
000079f9de5cf775  vmovaps xmm10, [rsp+0x20]
000079f9de5cf77b  por xmm12, xmm10
000079f9de5cf780  vmovaps [rsp+0x20], xmm5
000079f9de5cf786  vmovaps xmm10, [rsp+0x20]
000079f9de5cf78c  por xmm5, xmm10
000079f9de5cf791  vmovaps [rsp+0x20], xmm11
000079f9de5cf797  vmovaps xmm10, [rsp+0x20]
000079f9de5cf79d  por xmm11, xmm10
000079f9de5cf7a2  vmovaps [rsp+0x20], xmm4
000079f9de5cf7a8  vmovaps xmm10, [rsp+0x20]
000079f9de5cf7ae  por xmm4, xmm10
000079f9de5cf7b3  vmovaps [rsp+0x20], xmm8
000079f9de5cf7b9  vmovaps xmm10, [rsp+0x20]
000079f9de5cf7bf  por xmm8, xmm10
000079f9de5cf7c4  vmovaps xmm10, [rsp+0xF0]
000079f9de5cf7cd  vmovaps [rsp+0x20], xmm1
000079f9de5cf7d3  vmovaps xmm1, [rsp+0xF0]
000079f9de5cf7dc  por xmm10, xmm1
000079f9de5cf7e1  lea rax, [r14+0xA0]
000079f9de5cf7e8  movups xmm1, [r13+rax*1]
000079f9de5cf7ee  lea rax, [r14+0xB0]
000079f9de5cf7f5  vmovaps [rsp+0x30], xmm1
000079f9de5cf7fb  movups xmm1, [r13+rax*1]
000079f9de5cf801  vmovaps [rsp+0xF0], xmm1
000079f9de5cf80a  vmovaps [rsp+0x120], xmm15
000079f9de5cf813  movaps xmm1, xmm13
000079f9de5cf817  addpd xmm1, xmm2
000079f9de5cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000079f9de5cf820  ptest xmm15, xmm15
000079f9de5cf826  jnz 0x000079F9DE5D11ED
000079f9de5cf82c  lea rax, [r14+0xF0]
000079f9de5cf833  movups xmm15, [r13+rax*1]
000079f9de5cf839  vmovaps xmm2, [rsp+0xC0]
000079f9de5cf842  vmovaps [rsp+0xC0], xmm1
000079f9de5cf84b  vmovaps xmm1, [rsp+0xE0]
000079f9de5cf854  vmovaps [rsp+0xE0], xmm15
000079f9de5cf85d  movaps xmm13, xmm2
000079f9de5cf861  addpd xmm13, xmm1
000079f9de5cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000079f9de5cf86c  ptest xmm15, xmm15
000079f9de5cf872  jnz 0x000079F9DE5D1338
000079f9de5cf878  vmovaps xmm15, [rsp+0x120]
000079f9de5cf881  vmovaps xmm2, [rsp+0xD0]
000079f9de5cf88a  vmovaps [rsp+0xD0], xmm14
000079f9de5cf893  movaps xmm1, xmm15
000079f9de5cf897  addpd xmm1, xmm2
000079f9de5cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000079f9de5cf8a0  ptest xmm14, xmm14
000079f9de5cf8a6  jnz 0x000079F9DE5D147A
000079f9de5cf8ac  vmovaps xmm15, [rsp+0x100]
000079f9de5cf8b5  vpermilpd xmm15, xmm15, 0x00
000079f9de5cf8bb  vmovaps xmm2, [rsp+0xF0]
000079f9de5cf8c4  vmovaps [rsp+0xF0], xmm1
000079f9de5cf8cd  movaps xmm14, xmm2
000079f9de5cf8d1  mulpd xmm14, xmm15
000079f9de5cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000079f9de5cf8dc  ptest xmm1, xmm1
000079f9de5cf8e1  jnz 0x000079F9DE5D15BB
000079f9de5cf8e7  vmovaps xmm1, [rsp+0xA0]
000079f9de5cf8f0  vpermilpd xmm1, xmm1, 0x00
000079f9de5cf8f6  vmovaps xmm2, [rsp+0xE0]
000079f9de5cf8ff  vmovaps [rsp+0xE0], xmm14
000079f9de5cf908  movaps xmm15, xmm2
000079f9de5cf90c  mulpd xmm15, xmm1
000079f9de5cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000079f9de5cf917  ptest xmm14, xmm14
000079f9de5cf91d  jnz 0x000079F9DE5D16FE
000079f9de5cf923  lea rax, [r14+0xE0]
000079f9de5cf92a  movups xmm1, [r13+rax*1]
000079f9de5cf930  vmovaps xmm14, [rsp+0x100]
000079f9de5cf939  vpermilpd xmm14, xmm14, 0x00
000079f9de5cf93f  vmovaps [rsp+0x100], xmm1
000079f9de5cf948  vmovaps xmm1, [rsp+0x30]
000079f9de5cf94e  vmovaps [rsp+0x30], xmm15
000079f9de5cf954  movaps xmm2, xmm1
000079f9de5cf957  mulpd xmm2, xmm14
000079f9de5cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000079f9de5cf961  ptest xmm15, xmm15
000079f9de5cf967  jnz 0x000079F9DE5D184A
000079f9de5cf96d  vmovaps [rsp+0x120], xmm10
000079f9de5cf976  vmovaps xmm1, [rsp+0x120]
000079f9de5cf97f  por xmm10, xmm1
000079f9de5cf984  movaps [r15+0x300], xmm10
000079f9de5cf98c  vmovaps [rsp+0x120], xmm8
000079f9de5cf995  vmovaps xmm1, [rsp+0x120]
000079f9de5cf99e  por xmm8, xmm1
000079f9de5cf9a3  movaps [r15+0x190], xmm8
000079f9de5cf9ab  vmovaps xmm1, [rsp+0xA0]
000079f9de5cf9b4  vpermilpd xmm1, xmm1, 0x00
000079f9de5cf9ba  vmovaps xmm14, [rsp+0x100]
000079f9de5cf9c3  vmovaps [rsp+0x100], xmm13
000079f9de5cf9cc  movaps xmm15, xmm14
000079f9de5cf9d0  mulpd xmm15, xmm1
000079f9de5cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000079f9de5cf9db  ptest xmm13, xmm13
000079f9de5cf9e1  jnz 0x000079F9DE5D198B
000079f9de5cf9e7  lea rax, [r14+0x90]
000079f9de5cf9ee  movups xmm1, [r13+rax*1]
000079f9de5cf9f4  vmovaps [rsp+0x120], xmm4
000079f9de5cf9fd  vmovaps xmm14, [rsp+0x120]
000079f9de5cfa06  por xmm4, xmm14
000079f9de5cfa0b  movaps [r15+0x1C0], xmm4
000079f9de5cfa13  vmovaps [rsp+0x120], xmm11
000079f9de5cfa1c  vmovaps xmm14, [rsp+0x120]
000079f9de5cfa25  por xmm11, xmm14
000079f9de5cfa2a  movaps [r15+0x200], xmm11
000079f9de5cfa32  vmovaps [rsp+0x120], xmm5
000079f9de5cfa3b  vmovaps xmm14, [rsp+0x120]
000079f9de5cfa44  por xmm5, xmm14
000079f9de5cfa49  movaps [r15+0x2D0], xmm5
000079f9de5cfa51  vmovaps [rsp+0x120], xmm12
000079f9de5cfa5a  vmovaps xmm14, [rsp+0x120]
000079f9de5cfa63  por xmm12, xmm14
000079f9de5cfa68  movaps [r15+0x2E0], xmm12
000079f9de5cfa70  vmovaps xmm13, [rsp+0x110]
000079f9de5cfa79  vmovaps [rsp+0x110], xmm1
000079f9de5cfa82  vmovaps xmm1, [rsp+0xE0]
000079f9de5cfa8b  vmovaps [rsp+0xE0], xmm15
000079f9de5cfa94  movaps xmm14, xmm13
000079f9de5cfa98  addpd xmm14, xmm1
000079f9de5cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000079f9de5cfaa3  ptest xmm15, xmm15
000079f9de5cfaa9  jnz 0x000079F9DE5D1AD8
000079f9de5cfaaf  vmovaps xmm1, [rsp+0xA0]
000079f9de5cfab8  vpermilpd xmm1, xmm1, 0x00
000079f9de5cfabe  vmovaps xmm13, [rsp+0x110]
000079f9de5cfac7  vmovaps [rsp+0x110], xmm14
000079f9de5cfad0  movaps xmm15, xmm13
000079f9de5cfad4  mulpd xmm15, xmm1
000079f9de5cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000079f9de5cfadf  ptest xmm14, xmm14
000079f9de5cfae5  jnz 0x000079F9DE5D1C1B
000079f9de5cfaeb  lea rax, [r14+0x80]
000079f9de5cfaf2  movups xmm1, [r13+rax*1]
000079f9de5cfaf8  vmovaps xmm13, [rsp+0xC0]
000079f9de5cfb01  vmovaps [rsp+0xC0], xmm1
000079f9de5cfb0a  movaps xmm14, xmm13
000079f9de5cfb0e  addpd xmm14, xmm2
000079f9de5cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000079f9de5cfb19  ptest xmm1, xmm1
000079f9de5cfb1e  jnz 0x000079F9DE5D1D68
000079f9de5cfb24  vmovaps xmm13, [rsp+0x100]
000079f9de5cfb2d  vmovaps xmm2, [rsp+0x30]
000079f9de5cfb33  vmovaps [rsp+0x30], xmm15
000079f9de5cfb39  movaps xmm1, xmm13
000079f9de5cfb3d  addpd xmm1, xmm2
000079f9de5cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000079f9de5cfb46  ptest xmm15, xmm15
000079f9de5cfb4c  jnz 0x000079F9DE5D1EAB
000079f9de5cfb52  vmovaps xmm15, [rsp+0x20]
000079f9de5cfb58  vmovaps xmm13, [rsp+0x20]
000079f9de5cfb5e  por xmm15, xmm13
000079f9de5cfb63  movaps [r15+0x2F0], xmm15
000079f9de5cfb6b  vmovaps xmm13, [rsp+0xA0]
000079f9de5cfb74  vpermilpd xmm13, xmm13, 0x00
000079f9de5cfb7a  vmovaps [rsp+0x20], xmm1
000079f9de5cfb80  vmovaps xmm1, [rsp+0xC0]
000079f9de5cfb89  vmovaps [rsp+0xA0], xmm15
000079f9de5cfb92  movaps xmm2, xmm1
000079f9de5cfb95  mulpd xmm2, xmm13
000079f9de5cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000079f9de5cfb9f  ptest xmm15, xmm15
000079f9de5cfba5  jnz 0x000079F9DE5D1FEC
000079f9de5cfbab  lea rax, [r14+0xD0]
000079f9de5cfbb2  movups xmm1, [r13+rax*1]
000079f9de5cfbb8  vmovaps xmm13, [rsp+0xF0]
000079f9de5cfbc1  vmovaps [rsp+0xC0], xmm1
000079f9de5cfbca  vmovaps xmm1, [rsp+0xE0]
000079f9de5cfbd3  vmovaps [rsp+0xE0], xmm14
000079f9de5cfbdc  movaps xmm15, xmm13
000079f9de5cfbe0  addpd xmm15, xmm1
000079f9de5cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000079f9de5cfbeb  ptest xmm14, xmm14
000079f9de5cfbf1  jnz 0x000079F9DE5D2137
000079f9de5cfbf7  vmovaps xmm1, [rsp+0xB0]
000079f9de5cfc00  vpermilpd xmm1, xmm1, 0x00
000079f9de5cfc06  movaps xmm14, xmm11
000079f9de5cfc0a  mulpd xmm14, xmm1
000079f9de5cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000079f9de5cfc15  ptest xmm13, xmm13
000079f9de5cfc1b  jnz 0x000079F9DE5D227A
000079f9de5cfc21  movaps [r15+0x260], xmm14
000079f9de5cfc29  vxorps xmm1, xmm1, xmm1
000079f9de5cfc2d  vpbroadcastq xmm1, xmm1
000079f9de5cfc32  movaps [r15+0x1B0], xmm1
000079f9de5cfc3a  vmovaps xmm1, [rsp+0xB0]
000079f9de5cfc43  vpermilpd xmm1, xmm1, 0x00
000079f9de5cfc49  vmovaps xmm11, [rsp+0xC0]
000079f9de5cfc52  vmovaps [rsp+0xC0], xmm15
000079f9de5cfc5b  movaps xmm13, xmm11
000079f9de5cfc5f  mulpd xmm13, xmm1
000079f9de5cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000079f9de5cfc6a  ptest xmm15, xmm15
000079f9de5cfc70  jnz 0x000079F9DE5D23BD
000079f9de5cfc76  lea rax, [r14+0xC0]
000079f9de5cfc7d  movups xmm1, [r13+rax*1]
000079f9de5cfc83  vmovaps xmm11, [rsp+0x110]
000079f9de5cfc8c  vmovaps [rsp+0xF0], xmm1
000079f9de5cfc95  vmovaps xmm1, [rsp+0x30]
000079f9de5cfc9b  vmovaps [rsp+0x30], xmm14
000079f9de5cfca1  movaps xmm15, xmm11
000079f9de5cfca5  addpd xmm15, xmm1
000079f9de5cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000079f9de5cfcb0  ptest xmm14, xmm14
000079f9de5cfcb6  jnz 0x000079F9DE5D250A
000079f9de5cfcbc  vmovaps [rsp+0x100], xmm9
000079f9de5cfcc5  vmovaps xmm1, [rsp+0x100]
000079f9de5cfcce  por xmm9, xmm1
000079f9de5cfcd3  movaps [r15+0x270], xmm9
000079f9de5cfcdb  vmovaps [rsp+0x100], xmm6
000079f9de5cfce4  vmovaps xmm1, [rsp+0x100]
000079f9de5cfced  por xmm6, xmm1
000079f9de5cfcf1  movaps [r15+0x1A0], xmm6
000079f9de5cfcf9  vmovaps xmm14, [rsp+0xB0]
000079f9de5cfd02  vpermilpd xmm14, xmm14, 0x00
000079f9de5cfd08  vmovaps xmm6, [rsp+0xF0]
000079f9de5cfd11  vmovaps [rsp+0xF0], xmm1
000079f9de5cfd1a  movaps xmm11, xmm6
000079f9de5cfd1e  mulpd xmm11, xmm14
000079f9de5cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000079f9de5cfd29  ptest xmm1, xmm1
000079f9de5cfd2e  jnz 0x000079F9DE5D264D
000079f9de5cfd34  lea rax, [r14+0x20]
000079f9de5cfd38  movups xmm1, [r13+rax*1]
000079f9de5cfd3e  movaps [r15+0x110], xmm1
000079f9de5cfd46  vmovaps xmm6, [rsp+0xE0]
000079f9de5cfd4f  vmovaps [rsp+0xE0], xmm1
000079f9de5cfd58  movaps xmm14, xmm6
000079f9de5cfd5c  addpd xmm14, xmm2
000079f9de5cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000079f9de5cfd67  ptest xmm1, xmm1
000079f9de5cfd6c  jnz 0x000079F9DE5D279A
000079f9de5cfd72  vmovaps xmm1, [rsp+0xB0]
000079f9de5cfd7b  vpermilpd xmm1, xmm1, 0x00
000079f9de5cfd81  movaps xmm6, xmm5
000079f9de5cfd84  mulpd xmm6, xmm1
000079f9de5cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000079f9de5cfd8d  ptest xmm2, xmm2
000079f9de5cfd92  jnz 0x000079F9DE5D28DC
000079f9de5cfd98  vmovaps xmm5, [rsp+0x20]
000079f9de5cfd9e  movaps xmm1, xmm5
000079f9de5cfda1  addpd xmm1, xmm13
000079f9de5cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000079f9de5cfdab  ptest xmm2, xmm2
000079f9de5cfdb0  jnz 0x000079F9DE5D2A1C
000079f9de5cfdb6  vmovaps xmm13, [rsp+0x80]
000079f9de5cfdbf  vpermilpd xmm13, xmm13, 0x00
000079f9de5cfdc5  vmovaps xmm2, [rsp+0xE0]
000079f9de5cfdce  vmovaps [rsp+0x20], xmm1
000079f9de5cfdd4  movaps xmm5, xmm2
000079f9de5cfdd7  mulpd xmm5, xmm13
000079f9de5cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000079f9de5cfde1  ptest xmm1, xmm1
000079f9de5cfde6  jnz 0x000079F9DE5D2B5D
000079f9de5cfdec  vmovaps xmm1, [rsp+0x80]
000079f9de5cfdf5  vpermilpd xmm1, xmm1, 0x00
000079f9de5cfdfb  movaps xmm13, xmm10
000079f9de5cfdff  mulpd xmm13, xmm1
000079f9de5cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000079f9de5cfe0a  ptest xmm2, xmm2
000079f9de5cfe0f  jnz 0x000079F9DE5D2C9E
000079f9de5cfe15  vmovaps xmm10, [rsp+0x30]
000079f9de5cfe1b  movaps xmm1, xmm15
000079f9de5cfe1f  addpd xmm1, xmm10
000079f9de5cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000079f9de5cfe29  ptest xmm2, xmm2
000079f9de5cfe2e  jnz 0x000079F9DE5D2DE1
000079f9de5cfe34  vmovaps xmm10, [rsp+0xC0]
000079f9de5cfe3d  movaps xmm15, xmm10
000079f9de5cfe41  addpd xmm15, xmm11
000079f9de5cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000079f9de5cfe4c  ptest xmm2, xmm2
000079f9de5cfe51  jnz 0x000079F9DE5D2F23
000079f9de5cfe57  vmovaps xmm11, [rsp+0x80]
000079f9de5cfe60  vpermilpd xmm11, xmm11, 0x00
000079f9de5cfe66  movaps xmm10, xmm12
000079f9de5cfe6a  mulpd xmm10, xmm11
000079f9de5cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000079f9de5cfe75  ptest xmm2, xmm2
000079f9de5cfe7a  jnz 0x000079F9DE5D3067
000079f9de5cfe80  vmovaps xmm12, [rsp+0x80]
000079f9de5cfe89  vpermilpd xmm12, xmm12, 0x00
000079f9de5cfe8f  vmovaps xmm2, [rsp+0xA0]
000079f9de5cfe98  vmovaps [rsp+0x30], xmm1
000079f9de5cfe9e  movaps xmm11, xmm2
000079f9de5cfea2  mulpd xmm11, xmm12
000079f9de5cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000079f9de5cfead  ptest xmm1, xmm1
000079f9de5cfeb2  jnz 0x000079F9DE5D31AB
000079f9de5cfeb8  movaps xmm1, xmm14
000079f9de5cfebc  addpd xmm1, xmm6
000079f9de5cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000079f9de5cfec5  ptest xmm12, xmm12
000079f9de5cfecb  jnz 0x000079F9DE5D32EE
000079f9de5cfed1  vmovaps xmm12, [rsp+0x20]
000079f9de5cfed7  movaps xmm14, xmm12
000079f9de5cfedb  addpd xmm14, xmm5
000079f9de5cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000079f9de5cfee6  ptest xmm6, xmm6
000079f9de5cfeeb  jnz 0x000079F9DE5D342F
000079f9de5cfef1  vmovaps xmm12, [rsp+0x90]
000079f9de5cfefa  vpermilpd xmm12, xmm12, 0x00
000079f9de5cff00  movaps xmm6, xmm9
000079f9de5cff04  mulpd xmm6, xmm12
000079f9de5cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000079f9de5cff0e  ptest xmm5, xmm5
000079f9de5cff13  jnz 0x000079F9DE5D3572
000079f9de5cff19  movaps xmm12, xmm15
000079f9de5cff1d  addpd xmm12, xmm13
000079f9de5cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000079f9de5cff28  ptest xmm9, xmm9
000079f9de5cff2e  jnz 0x000079F9DE5D36B4
000079f9de5cff34  vmovaps xmm13, [rsp+0x30]
000079f9de5cff3a  movaps xmm15, xmm13
000079f9de5cff3e  addpd xmm15, xmm10
000079f9de5cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000079f9de5cff49  ptest xmm9, xmm9
000079f9de5cff4f  jnz 0x000079F9DE5D37F8
000079f9de5cff55  vmovaps xmm13, [rsp+0xD0]
000079f9de5cff5e  vmovaps xmm10, [rsp+0xD0]
000079f9de5cff67  por xmm13, xmm10
000079f9de5cff6c  movaps [r15+0x250], xmm13
000079f9de5cff74  vmovaps [rsp+0x20], xmm7
000079f9de5cff7a  vmovaps xmm13, [rsp+0x20]
000079f9de5cff80  por xmm7, xmm13
000079f9de5cff85  movaps [r15+0x2A0], xmm7
000079f9de5cff8d  vmovaps [rsp+0x20], xmm3
000079f9de5cff93  vmovaps xmm13, [rsp+0x20]
000079f9de5cff99  por xmm3, xmm13
000079f9de5cff9e  movaps [r15+0x1D0], xmm3
000079f9de5cffa6  lea rax, [r14+0x40]
000079f9de5cffaa  movups xmm13, [r13+rax*1]
000079f9de5cffb0  movaps [r15+0x2C0], xmm13
000079f9de5cffb8  vmovaps xmm10, [rsp+0x90]
000079f9de5cffc1  vpermilpd xmm10, xmm10, 0x00
000079f9de5cffc7  movaps xmm9, xmm8
000079f9de5cffcb  mulpd xmm9, xmm10
000079f9de5cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000079f9de5cffd6  ptest xmm5, xmm5
000079f9de5cffdb  jnz 0x000079F9DE5D3946
000079f9de5cffe1  movaps xmm10, xmm1
000079f9de5cffe5  addpd xmm10, xmm11
000079f9de5cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000079f9de5cfff0  ptest xmm8, xmm8
000079f9de5cfff6  jnz 0x000079F9DE5D3A8A
000079f9de5cfffc  movaps xmm1, xmm14
000079f9de5d0000  addpd xmm1, xmm6
000079f9de5d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000079f9de5d0009  ptest xmm11, xmm11
000079f9de5d000f  jnz 0x000079F9DE5D3BCD
000079f9de5d0015  vmovaps xmm14, [rsp+0x90]
000079f9de5d001e  vpermilpd xmm14, xmm14, 0x00
000079f9de5d0024  movaps xmm11, xmm13
000079f9de5d0028  mulpd xmm11, xmm14
000079f9de5d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000079f9de5d0033  ptest xmm8, xmm8
000079f9de5d0039  jnz 0x000079F9DE5D3D0E
000079f9de5d003f  vmovaps xmm14, [rsp+0x90]
000079f9de5d0048  vpermilpd xmm14, xmm14, 0x00
000079f9de5d004e  vmovaps xmm8, [rsp+0x10]
000079f9de5d0054  movaps xmm13, xmm8
000079f9de5d0058  mulpd xmm13, xmm14
000079f9de5d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000079f9de5d0063  ptest xmm6, xmm6
000079f9de5d0068  jnz 0x000079F9DE5D3E52
000079f9de5d006e  vmovaps xmm14, [rsp+0x60]
000079f9de5d0074  vpermilpd xmm14, xmm14, 0x00
000079f9de5d007a  movaps xmm8, xmm7
000079f9de5d007e  mulpd xmm8, xmm14
000079f9de5d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000079f9de5d0089  ptest xmm6, xmm6
000079f9de5d008e  jnz 0x000079F9DE5D3F96
000079f9de5d0094  movaps xmm14, xmm12
000079f9de5d0098  addpd xmm14, xmm9
000079f9de5d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000079f9de5d00a3  ptest xmm7, xmm7
000079f9de5d00a8  jnz 0x000079F9DE5D40D9
000079f9de5d00ae  vmovaps xmm12, [rsp+0x60]
000079f9de5d00b4  vpermilpd xmm12, xmm12, 0x00
000079f9de5d00ba  vmovaps xmm7, [rsp+0xF0]
000079f9de5d00c3  movaps xmm9, xmm7
000079f9de5d00c7  mulpd xmm9, xmm12
000079f9de5d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000079f9de5d00d2  ptest xmm6, xmm6
000079f9de5d00d7  jnz 0x000079F9DE5D421D
000079f9de5d00dd  movaps xmm12, xmm15
000079f9de5d00e1  addpd xmm12, xmm11
000079f9de5d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000079f9de5d00ec  ptest xmm7, xmm7
000079f9de5d00f1  jnz 0x000079F9DE5D4360
000079f9de5d00f7  vmovaps xmm15, [rsp+0x60]
000079f9de5d00fd  vpermilpd xmm15, xmm15, 0x00
000079f9de5d0103  vmovaps xmm7, [rsp+0x40]
000079f9de5d0109  movaps xmm11, xmm7
000079f9de5d010d  mulpd xmm11, xmm15
000079f9de5d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000079f9de5d0118  ptest xmm6, xmm6
000079f9de5d011d  jnz 0x000079F9DE5D44A4
000079f9de5d0123  movaps xmm15, xmm10
000079f9de5d0127  addpd xmm15, xmm13
000079f9de5d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000079f9de5d0132  ptest xmm7, xmm7
000079f9de5d0137  jnz 0x000079F9DE5D45E7
000079f9de5d013d  vmovaps xmm13, [rsp+0x60]
000079f9de5d0143  vpermilpd xmm13, xmm13, 0x00
000079f9de5d0149  vmovaps xmm7, [rsp+0x50]
000079f9de5d014f  movaps xmm10, xmm7
000079f9de5d0153  mulpd xmm10, xmm13
000079f9de5d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000079f9de5d015e  ptest xmm6, xmm6
000079f9de5d0163  jnz 0x000079F9DE5D472B
000079f9de5d0169  movaps xmm13, xmm1
000079f9de5d016d  addpd xmm13, xmm8
000079f9de5d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000079f9de5d0178  ptest xmm7, xmm7
000079f9de5d017d  jnz 0x000079F9DE5D486E
000079f9de5d0183  lea rax, [r14+0x70]
000079f9de5d0187  movups xmm1, [r13+rax*1]
000079f9de5d018d  movaps [r15+0x240], xmm1
000079f9de5d0195  movaps xmm8, xmm14
000079f9de5d0199  addpd xmm8, xmm9
000079f9de5d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000079f9de5d01a4  ptest xmm7, xmm7
000079f9de5d01a9  jnz 0x000079F9DE5D49BB
000079f9de5d01af  movaps [r15+0x170], xmm8
000079f9de5d01b7  vmovaps xmm14, [rsp+0x70]
000079f9de5d01bd  vpermilpd xmm14, xmm14, 0x00
000079f9de5d01c3  movaps xmm9, xmm1
000079f9de5d01c7  mulpd xmm9, xmm14
000079f9de5d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000079f9de5d01d2  ptest xmm7, xmm7
000079f9de5d01d7  jnz 0x000079F9DE5D4AFF
000079f9de5d01dd  vmovaps xmm1, [rsp+0x70]
000079f9de5d01e3  vpermilpd xmm1, xmm1, 0x00
000079f9de5d01e9  movaps xmm14, xmm4
000079f9de5d01ed  mulpd xmm14, xmm1
000079f9de5d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000079f9de5d01f8  ptest xmm7, xmm7
000079f9de5d01fd  jnz 0x000079F9DE5D4C42
000079f9de5d0203  movaps [r15+0x180], xmm14
000079f9de5d020b  movaps xmm1, xmm12
000079f9de5d020f  addpd xmm1, xmm11
000079f9de5d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000079f9de5d0219  ptest xmm7, xmm7
000079f9de5d021e  jnz 0x000079F9DE5D4D84
000079f9de5d0224  movaps [r15+0x210], xmm1
000079f9de5d022c  movups xmm12, [r13+r14*1]
000079f9de5d0232  lea rax, [r14+0x10]
000079f9de5d0236  movups xmm11, [r13+rax*1]
000079f9de5d023c  movaps [r15+0x230], xmm11
000079f9de5d0244  movaps xmm7, xmm15
000079f9de5d0248  addpd xmm7, xmm10
000079f9de5d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000079f9de5d0252  ptest xmm6, xmm6
000079f9de5d0257  jnz 0x000079F9DE5D4EDA
000079f9de5d025d  movaps [r15+0x130], xmm7
000079f9de5d0265  vmovaps xmm15, [rsp+0x70]
000079f9de5d026b  vpermilpd xmm15, xmm15, 0x00
000079f9de5d0271  movaps xmm10, xmm11
000079f9de5d0275  mulpd xmm10, xmm15
000079f9de5d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000079f9de5d0280  ptest xmm6, xmm6
000079f9de5d0285  jnz 0x000079F9DE5D501C
000079f9de5d028b  movaps [r15+0x220], xmm10
000079f9de5d0293  vmovaps xmm15, [rsp+0x70]
000079f9de5d0299  vpermilpd xmm15, xmm15, 0x00
000079f9de5d029f  movaps xmm11, xmm12
000079f9de5d02a3  mulpd xmm11, xmm15
000079f9de5d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000079f9de5d02ae  ptest xmm6, xmm6
000079f9de5d02b3  jnz 0x000079F9DE5D5160
000079f9de5d02b9  movaps xmm15, xmm13
000079f9de5d02bd  addpd xmm15, xmm9
000079f9de5d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000079f9de5d02c8  ptest xmm12, xmm12
000079f9de5d02ce  jnz 0x000079F9DE5D52A4
000079f9de5d02d4  movaps [r15+0x140], xmm15
000079f9de5d02dc  movaps xmm13, xmm8
000079f9de5d02e0  addpd xmm13, xmm14
000079f9de5d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000079f9de5d02eb  ptest xmm12, xmm12
000079f9de5d02f1  jnz 0x000079F9DE5D53E8
000079f9de5d02f7  movaps [r15+0x150], xmm13
000079f9de5d02ff  movaps xmm14, xmm1
000079f9de5d0303  addpd xmm14, xmm10
000079f9de5d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000079f9de5d030e  ptest xmm12, xmm12
000079f9de5d0314  jnz 0x000079F9DE5D552C
000079f9de5d031a  movaps [r15+0x160], xmm14
000079f9de5d0322  movaps xmm1, xmm7
000079f9de5d0325  addpd xmm1, xmm11
000079f9de5d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000079f9de5d032f  ptest xmm12, xmm12
000079f9de5d0335  jnz 0x000079F9DE5D566F
000079f9de5d033b  movaps [r15+0x120], xmm1
000079f9de5d0343  mov eax, 0x430920
000079f9de5d0348  movups [r13+rax*1], xmm15
000079f9de5d034e  mov eax, 0x430930
000079f9de5d0353  movups [r13+rax*1], xmm13
000079f9de5d0359  mov eax, 0x430940
000079f9de5d035e  movups [r13+rax*1], xmm14
000079f9de5d0364  mov eax, 0x430950
000079f9de5d0369  movups [r13+rax*1], xmm1
000079f9de5d036f  mov eax, [r15+0x108]
000079f9de5d0376  sahf
000079f9de5d0377  jnz 0x000079F9DE5D03A9
000079f9de5d0379  cmp dword ptr [r15+0x318], 0x00
000079f9de5d0381  jz 0x000079F9DE5DB900
000079f9de5d0387  nop [rax+rax*1], ax
000079f9de5d0390  nop [rax+rax*1], eax
000079f9de5d0398  mov eax, 0x410444
000079f9de5d039d  mov [r15+0x100], rax
000079f9de5d03a4  jmp 0x000079F9DE3FE110
000079f9de5d03a9  cmp dword ptr [r15+0x318], 0x00
000079f9de5d03b1  jz 0x000079F9DE5D57E0
000079f9de5d03b7  nop [rax+rax*1], ax
000079f9de5d03c0  nop [rax+rax*1], eax
000079f9de5d03c8  mov eax, 0x410278
000079f9de5d03cd  mov [r15+0x100], rax
000079f9de5d03d4  jmp 0x000079F9DE3FE110
000079f9de5d03d9  int3
000079f9de5d03da  call 0x000079F9DE4B52F0
000079f9de5d03df  jmp 0x000079F9DE5CF016
000079f9de5d03e4  call 0x000079F9DE4C4620
000079f9de5d03e9  jmp 0x000079F9DE5CF023
000079f9de5d03ee  call 0x000079F9DE4C33A0
000079f9de5d03f3  jmp 0x000079F9DE5CF035
000079f9de5d03f8  call 0x000079F9DE4C2120
000079f9de5d03fd  jmp 0x000079F9DE5CF03F
000079f9de5d0402  call 0x000079F9DE4C0860
000079f9de5d0407  jmp 0x000079F9DE5CF067
000079f9de5d040c  call 0x000079F9DE4BF5F0
000079f9de5d0411  jmp 0x000079F9DE5CF073
000079f9de5d0416  call 0x000079F9DE4C0860
000079f9de5d041b  jmp 0x000079F9DE5CF0A5
000079f9de5d0420  call 0x000079F9DE4BF5F0
000079f9de5d0425  jmp 0x000079F9DE5CF0B1
000079f9de5d042a  call 0x000079F9DE4C4740
000079f9de5d042f  jmp 0x000079F9DE5CF0BE
000079f9de5d0434  call 0x000079F9DE4B5400
000079f9de5d0439  jmp 0x000079F9DE5CF0CB
000079f9de5d043e  call 0x000079F9DE4B52F0
000079f9de5d0443  jmp 0x000079F9DE5CF0D8
000079f9de5d0448  call 0x000079F9DE4C4620
000079f9de5d044d  jmp 0x000079F9DE5CF0E5
000079f9de5d0452  call 0x000079F9DE4C0860
000079f9de5d0457  jmp 0x000079F9DE5CF10D
000079f9de5d045c  call 0x000079F9DE4BF5F0
000079f9de5d0461  jmp 0x000079F9DE5CF119
000079f9de5d0466  call 0x000079F9DE409D70
000079f9de5d046b  jmp 0x000079F9DE5CF11F
000079f9de5d0470  call 0x000079F9DE4BE9C0
000079f9de5d0475  jmp 0x000079F9DE5CF129
000079f9de5d047a  call 0x000079F9DE4C0860
000079f9de5d047f  jmp 0x000079F9DE5CF151
000079f9de5d0484  call 0x000079F9DE4BF5F0
000079f9de5d0489  jmp 0x000079F9DE5CF15D
000079f9de5d048e  call 0x000079F9DE4BD750
000079f9de5d0493  jmp 0x000079F9DE5CF16A
000079f9de5d0498  call 0x000079F9DE4BC4E0
000079f9de5d049d  jmp 0x000079F9DE5CF177
000079f9de5d04a2  call 0x000079F9DE4C4740
000079f9de5d04a7  jmp 0x000079F9DE5CF184
000079f9de5d04ac  call 0x000079F9DE4B5400
000079f9de5d04b1  jmp 0x000079F9DE5CF191
000079f9de5d04b6  call 0x000079F9DE4B52F0
000079f9de5d04bb  jmp 0x000079F9DE5CF19E
000079f9de5d04c0  call 0x000079F9DE4C4620
000079f9de5d04c5  jmp 0x000079F9DE5CF1AB
000079f9de5d04ca  call 0x000079F9DE4C0860
000079f9de5d04cf  jmp 0x000079F9DE5CF1BE
000079f9de5d04d4  call 0x000079F9DE4BB270
000079f9de5d04d9  jmp 0x000079F9DE5CF1CB
000079f9de5d04de  call 0x000079F9DE4BA000
000079f9de5d04e3  jmp 0x000079F9DE5CF1D8
000079f9de5d04e8  call 0x000079F9DE4B8D90
000079f9de5d04ed  jmp 0x000079F9DE5CF1E5
000079f9de5d04f2  call 0x000079F9DE4B8A20
000079f9de5d04f7  jmp 0x000079F9DE5CF1F2
000079f9de5d04fc  call 0x000079F9DE4B5400
000079f9de5d0501  jmp 0x000079F9DE5CF1FC
000079f9de5d0506  call 0x000079F9DE4C2240
000079f9de5d050b  jmp 0x000079F9DE5CF206
000079f9de5d0510  call 0x000079F9DE4B52F0
000079f9de5d0515  jmp 0x000079F9DE5CF210
000079f9de5d051a  call 0x000079F9DE4C2120
000079f9de5d051f  jmp 0x000079F9DE5CF21A
000079f9de5d0524  call 0x000079F9DE4B77B0
000079f9de5d0529  jmp 0x000079F9DE5CF224
000079f9de5d052e  call 0x000079F9DE4B6550
000079f9de5d0533  jmp 0x000079F9DE5CF22E
000079f9de5d0538  call 0x000079F9DE4BFD50
000079f9de5d053d  jmp 0x000079F9DE5CF240
000079f9de5d0542  call 0x000079F9DE4B8EA0
000079f9de5d0547  jmp 0x000079F9DE5CF24A
000079f9de5d054c  call 0x000079F9DE4BFC30
000079f9de5d0551  jmp 0x000079F9DE5CF257
000079f9de5d0556  call 0x000079F9DE4B8D90
000079f9de5d055b  jmp 0x000079F9DE5CF264
000079f9de5d0560  call 0x000079F9DE4C2240
000079f9de5d0565  jmp 0x000079F9DE5CF271
000079f9de5d056a  call 0x000079F9DE4B5400
000079f9de5d056f  jmp 0x000079F9DE5CF27E
000079f9de5d0574  call 0x000079F9DE4B52F0
000079f9de5d0579  jmp 0x000079F9DE5CF28B
000079f9de5d057e  call 0x000079F9DE4C2120
000079f9de5d0583  jmp 0x000079F9DE5CF298
000079f9de5d0588  call 0x000079F9DE4B52F0
000079f9de5d058d  jmp 0x000079F9DE5CF2AB
000079f9de5d0592  call 0x000079F9DE4B52F0
000079f9de5d0597  jmp 0x000079F9DE5CF2BE
000079f9de5d059c  call 0x000079F9DE4B52F0
000079f9de5d05a1  jmp 0x000079F9DE5CF2D1
000079f9de5d05a6  call 0x000079F9DE4B52F0
000079f9de5d05ab  jmp 0x000079F9DE5CF2E4
000079f9de5d05b0  call 0x000079F9DE4C2240
000079f9de5d05b5  jmp 0x000079F9DE5CF2F9
000079f9de5d05ba  call 0x000079F9DE4C2240
000079f9de5d05bf  jmp 0x000079F9DE5CF30C
000079f9de5d05c4  call 0x000079F9DE4C2120
000079f9de5d05c9  jmp 0x000079F9DE5CF319
000079f9de5d05ce  call 0x000079F9DE4B52F0
000079f9de5d05d3  jmp 0x000079F9DE5CF32C
000079f9de5d05d8  call 0x000079F9DE4B52F0
000079f9de5d05dd  jmp 0x000079F9DE5CF34F
000079f9de5d05e2  call 0x000079F9DE4B52F0
000079f9de5d05e7  jmp 0x000079F9DE5CF362
000079f9de5d05ec  call 0x000079F9DE3FF540
000079f9de5d05f1  jmp 0x000079F9DE5CF380
000079f9de5d05f6  call 0x000079F9DE408C20
000079f9de5d05fb  jmp 0x000079F9DE5CF38A
000079f9de5d0600  call 0x000079F9DE4D6600
000079f9de5d0605  jmp 0x000079F9DE5CF396
000079f9de5d060a  call 0x000079F9DE3FF540
000079f9de5d060f  jmp 0x000079F9DE5CF3A6
000079f9de5d0614  call 0x000079F9DE4C0370
000079f9de5d0619  jmp 0x000079F9DE5CF3D4
000079f9de5d061e  call 0x000079F9DE4BF100
000079f9de5d0623  jmp 0x000079F9DE5CF3DD
000079f9de5d0628  call 0x000079F9DE4C0370
000079f9de5d062d  jmp 0x000079F9DE5CF43B
000079f9de5d0632  call 0x000079F9DE4BF100
000079f9de5d0637  jmp 0x000079F9DE5CF444
000079f9de5d063c  call 0x000079F9DE4C0370
000079f9de5d0641  jmp 0x000079F9DE5CF48B
000079f9de5d0646  call 0x000079F9DE4BF100
000079f9de5d064b  jmp 0x000079F9DE5CF494
000079f9de5d0650  call 0x000079F9DE40B720
000079f9de5d0655  jmp 0x000079F9DE5CF4D7
000079f9de5d065a  call 0x000079F9DE4B47C0
000079f9de5d065f  jmp 0x000079F9DE5CF4EA
000079f9de5d0664  call 0x000079F9DE408B00
000079f9de5d0669  jmp 0x000079F9DE5CF501
000079f9de5d066e  call 0x000079F9DE3FF430
000079f9de5d0673  jmp 0x000079F9DE5CF514
000079f9de5d0678  call 0x000079F9DE3FF430
000079f9de5d067d  jmp 0x000079F9DE5CF527
000079f9de5d0682  sub rsp, 0x08
000079f9de5d0686  push rax
000079f9de5d0687  push rcx
000079f9de5d0688  push rdx
000079f9de5d0689  push rdi
000079f9de5d068a  push rsi
000079f9de5d068b  push r8
000079f9de5d068d  push r9
000079f9de5d068f  push r10
000079f9de5d0691  push r11
000079f9de5d0693  sub rsp, 0xF0
000079f9de5d069a  vmovaps [rsp], xmm0
000079f9de5d069f  vmovaps [rsp+0x10], xmm2
000079f9de5d06a5  vmovaps [rsp+0x20], xmm3
000079f9de5d06ab  vmovaps [rsp+0x30], xmm4
000079f9de5d06b1  vmovaps [rsp+0x40], xmm5
000079f9de5d06b7  vmovaps [rsp+0x50], xmm6
000079f9de5d06bd  vmovaps [rsp+0x60], xmm7
000079f9de5d06c3  vmovaps [rsp+0x70], xmm8
000079f9de5d06c9  vmovaps [rsp+0x80], xmm9
000079f9de5d06d2  vmovaps [rsp+0x90], xmm10
000079f9de5d06db  vmovaps [rsp+0xA0], xmm11
000079f9de5d06e4  vmovaps [rsp+0xB0], xmm12
000079f9de5d06ed  vmovaps [rsp+0xC0], xmm13
000079f9de5d06f6  vmovaps [rsp+0xD0], xmm14
000079f9de5d06ff  vmovaps [rsp+0xE0], xmm15
000079f9de5d0708  sub rsp, 0x30
000079f9de5d070c  movaps [rsp], xmm1
000079f9de5d0710  movaps [rsp+0x10], xmm15
000079f9de5d0716  movaps [rsp+0x20], xmm14
000079f9de5d071c  lea rdi, [rsp]
000079f9de5d0720  mov esi, 0x00
000079f9de5d0725  mov rax, 0x56D56FF59530
000079f9de5d072f  call rax
000079f9de5d0731  movaps xmm1, [rsp]
000079f9de5d0735  add rsp, 0x30
000079f9de5d0739  vmovaps xmm0, [rsp]
000079f9de5d073e  vmovaps xmm2, [rsp+0x10]
000079f9de5d0744  vmovaps xmm3, [rsp+0x20]
000079f9de5d074a  vmovaps xmm4, [rsp+0x30]
000079f9de5d0750  vmovaps xmm5, [rsp+0x40]
000079f9de5d0756  vmovaps xmm6, [rsp+0x50]
000079f9de5d075c  vmovaps xmm7, [rsp+0x60]
000079f9de5d0762  vmovaps xmm8, [rsp+0x70]
000079f9de5d0768  vmovaps xmm9, [rsp+0x80]
000079f9de5d0771  vmovaps xmm10, [rsp+0x90]
000079f9de5d077a  vmovaps xmm11, [rsp+0xA0]
000079f9de5d0783  vmovaps xmm12, [rsp+0xB0]
000079f9de5d078c  vmovaps xmm13, [rsp+0xC0]
000079f9de5d0795  vmovaps xmm14, [rsp+0xD0]
000079f9de5d079e  vmovaps xmm15, [rsp+0xE0]
000079f9de5d07a7  add rsp, 0xF0
000079f9de5d07ae  pop r11
000079f9de5d07b0  pop r10
000079f9de5d07b2  pop r9
000079f9de5d07b4  pop r8
000079f9de5d07b6  pop rsi
000079f9de5d07b7  pop rdi
000079f9de5d07b8  pop rdx
000079f9de5d07b9  pop rcx
000079f9de5d07ba  pop rax
000079f9de5d07bb  add rsp, 0x08
000079f9de5d07bf  jmp 0x000079F9DE5CF581
000079f9de5d07c4  sub rsp, 0x08
000079f9de5d07c8  push rax
000079f9de5d07c9  push rcx
000079f9de5d07ca  push rdx
000079f9de5d07cb  push rdi
000079f9de5d07cc  push rsi
000079f9de5d07cd  push r8
000079f9de5d07cf  push r9
000079f9de5d07d1  push r10
000079f9de5d07d3  push r11
000079f9de5d07d5  sub rsp, 0xF0
000079f9de5d07dc  vmovaps [rsp], xmm0
000079f9de5d07e1  vmovaps [rsp+0x10], xmm1
000079f9de5d07e7  vmovaps [rsp+0x20], xmm2
000079f9de5d07ed  vmovaps [rsp+0x30], xmm3
000079f9de5d07f3  vmovaps [rsp+0x40], xmm4
000079f9de5d07f9  vmovaps [rsp+0x50], xmm5
000079f9de5d07ff  vmovaps [rsp+0x60], xmm6
000079f9de5d0805  vmovaps [rsp+0x70], xmm7
000079f9de5d080b  vmovaps [rsp+0x80], xmm8
000079f9de5d0814  vmovaps [rsp+0x90], xmm9
000079f9de5d081d  vmovaps [rsp+0xA0], xmm10
000079f9de5d0826  vmovaps [rsp+0xB0], xmm11
000079f9de5d082f  vmovaps [rsp+0xC0], xmm12
000079f9de5d0838  vmovaps [rsp+0xD0], xmm14
000079f9de5d0841  vmovaps [rsp+0xE0], xmm15
000079f9de5d084a  sub rsp, 0x30
000079f9de5d084e  movaps [rsp], xmm13
000079f9de5d0853  movaps [rsp+0x10], xmm1
000079f9de5d0858  movaps [rsp+0x20], xmm14
000079f9de5d085e  lea rdi, [rsp]
000079f9de5d0862  mov esi, 0x00
000079f9de5d0867  mov rax, 0x56D56FF59530
000079f9de5d0871  call rax
000079f9de5d0873  movaps xmm13, [rsp]
000079f9de5d0878  add rsp, 0x30
000079f9de5d087c  vmovaps xmm0, [rsp]
000079f9de5d0881  vmovaps xmm1, [rsp+0x10]
000079f9de5d0887  vmovaps xmm2, [rsp+0x20]
000079f9de5d088d  vmovaps xmm3, [rsp+0x30]
000079f9de5d0893  vmovaps xmm4, [rsp+0x40]
000079f9de5d0899  vmovaps xmm5, [rsp+0x50]
000079f9de5d089f  vmovaps xmm6, [rsp+0x60]
000079f9de5d08a5  vmovaps xmm7, [rsp+0x70]
000079f9de5d08ab  vmovaps xmm8, [rsp+0x80]
000079f9de5d08b4  vmovaps xmm9, [rsp+0x90]
000079f9de5d08bd  vmovaps xmm10, [rsp+0xA0]
000079f9de5d08c6  vmovaps xmm11, [rsp+0xB0]
000079f9de5d08cf  vmovaps xmm12, [rsp+0xC0]
000079f9de5d08d8  vmovaps xmm14, [rsp+0xD0]
000079f9de5d08e1  vmovaps xmm15, [rsp+0xE0]
000079f9de5d08ea  add rsp, 0xF0
000079f9de5d08f1  pop r11
000079f9de5d08f3  pop r10
000079f9de5d08f5  pop r9
000079f9de5d08f7  pop r8
000079f9de5d08f9  pop rsi
000079f9de5d08fa  pop rdi
000079f9de5d08fb  pop rdx
000079f9de5d08fc  pop rcx
000079f9de5d08fd  pop rax
000079f9de5d08fe  add rsp, 0x08
000079f9de5d0902  jmp 0x000079F9DE5CF5CF
000079f9de5d0907  sub rsp, 0x08
000079f9de5d090b  push rax
000079f9de5d090c  push rcx
000079f9de5d090d  push rdx
000079f9de5d090e  push rdi
000079f9de5d090f  push rsi
000079f9de5d0910  push r8
000079f9de5d0912  push r9
000079f9de5d0914  push r10
000079f9de5d0916  push r11
000079f9de5d0918  sub rsp, 0xF0
000079f9de5d091f  vmovaps [rsp], xmm0
000079f9de5d0924  vmovaps [rsp+0x10], xmm1
000079f9de5d092a  vmovaps [rsp+0x20], xmm2
000079f9de5d0930  vmovaps [rsp+0x30], xmm3
000079f9de5d0936  vmovaps [rsp+0x40], xmm4
000079f9de5d093c  vmovaps [rsp+0x50], xmm5
000079f9de5d0942  vmovaps [rsp+0x60], xmm6
000079f9de5d0948  vmovaps [rsp+0x70], xmm7
000079f9de5d094e  vmovaps [rsp+0x80], xmm8
000079f9de5d0957  vmovaps [rsp+0x90], xmm9
000079f9de5d0960  vmovaps [rsp+0xA0], xmm10
000079f9de5d0969  vmovaps [rsp+0xB0], xmm11
000079f9de5d0972  vmovaps [rsp+0xC0], xmm12
000079f9de5d097b  vmovaps [rsp+0xD0], xmm13
000079f9de5d0984  vmovaps [rsp+0xE0], xmm14
000079f9de5d098d  sub rsp, 0x30
000079f9de5d0991  movaps [rsp], xmm15
000079f9de5d0996  movaps [rsp+0x10], xmm14
000079f9de5d099c  movaps [rsp+0x20], xmm1
000079f9de5d09a1  lea rdi, [rsp]
000079f9de5d09a5  mov esi, 0x00
000079f9de5d09aa  mov rax, 0x56D56FF59530
000079f9de5d09b4  call rax
000079f9de5d09b6  movaps xmm15, [rsp]
000079f9de5d09bb  add rsp, 0x30
000079f9de5d09bf  vmovaps xmm0, [rsp]
000079f9de5d09c4  vmovaps xmm1, [rsp+0x10]
000079f9de5d09ca  vmovaps xmm2, [rsp+0x20]
000079f9de5d09d0  vmovaps xmm3, [rsp+0x30]
000079f9de5d09d6  vmovaps xmm4, [rsp+0x40]
000079f9de5d09dc  vmovaps xmm5, [rsp+0x50]
000079f9de5d09e2  vmovaps xmm6, [rsp+0x60]
000079f9de5d09e8  vmovaps xmm7, [rsp+0x70]
000079f9de5d09ee  vmovaps xmm8, [rsp+0x80]
000079f9de5d09f7  vmovaps xmm9, [rsp+0x90]
000079f9de5d0a00  vmovaps xmm10, [rsp+0xA0]
000079f9de5d0a09  vmovaps xmm11, [rsp+0xB0]
000079f9de5d0a12  vmovaps xmm12, [rsp+0xC0]
000079f9de5d0a1b  vmovaps xmm13, [rsp+0xD0]
000079f9de5d0a24  vmovaps xmm14, [rsp+0xE0]
000079f9de5d0a2d  add rsp, 0xF0
000079f9de5d0a34  pop r11
000079f9de5d0a36  pop r10
000079f9de5d0a38  pop r9
000079f9de5d0a3a  pop r8
000079f9de5d0a3c  pop rsi
000079f9de5d0a3d  pop rdi
000079f9de5d0a3e  pop rdx
000079f9de5d0a3f  pop rcx
000079f9de5d0a40  pop rax
000079f9de5d0a41  add rsp, 0x08
000079f9de5d0a45  jmp 0x000079F9DE5CF617
000079f9de5d0a4a  sub rsp, 0x08
000079f9de5d0a4e  push rax
000079f9de5d0a4f  push rcx
000079f9de5d0a50  push rdx
000079f9de5d0a51  push rdi
000079f9de5d0a52  push rsi
000079f9de5d0a53  push r8
000079f9de5d0a55  push r9
000079f9de5d0a57  push r10
000079f9de5d0a59  push r11
000079f9de5d0a5b  sub rsp, 0xF0
000079f9de5d0a62  vmovaps [rsp], xmm0
000079f9de5d0a67  vmovaps [rsp+0x10], xmm2
000079f9de5d0a6d  vmovaps [rsp+0x20], xmm3
000079f9de5d0a73  vmovaps [rsp+0x30], xmm4
000079f9de5d0a79  vmovaps [rsp+0x40], xmm5
000079f9de5d0a7f  vmovaps [rsp+0x50], xmm6
000079f9de5d0a85  vmovaps [rsp+0x60], xmm7
000079f9de5d0a8b  vmovaps [rsp+0x70], xmm8
000079f9de5d0a91  vmovaps [rsp+0x80], xmm9
000079f9de5d0a9a  vmovaps [rsp+0x90], xmm10
000079f9de5d0aa3  vmovaps [rsp+0xA0], xmm11
000079f9de5d0aac  vmovaps [rsp+0xB0], xmm12
000079f9de5d0ab5  vmovaps [rsp+0xC0], xmm13
000079f9de5d0abe  vmovaps [rsp+0xD0], xmm14
000079f9de5d0ac7  vmovaps [rsp+0xE0], xmm15
000079f9de5d0ad0  sub rsp, 0x30
000079f9de5d0ad4  movaps [rsp], xmm1
000079f9de5d0ad8  movaps [rsp+0x10], xmm14
000079f9de5d0ade  movaps [rsp+0x20], xmm10
000079f9de5d0ae4  lea rdi, [rsp]
000079f9de5d0ae8  mov esi, 0x00
000079f9de5d0aed  mov rax, 0x56D56FF59530
000079f9de5d0af7  call rax
000079f9de5d0af9  movaps xmm1, [rsp]
000079f9de5d0afd  add rsp, 0x30
000079f9de5d0b01  vmovaps xmm0, [rsp]
000079f9de5d0b06  vmovaps xmm2, [rsp+0x10]
000079f9de5d0b0c  vmovaps xmm3, [rsp+0x20]
000079f9de5d0b12  vmovaps xmm4, [rsp+0x30]
000079f9de5d0b18  vmovaps xmm5, [rsp+0x40]
000079f9de5d0b1e  vmovaps xmm6, [rsp+0x50]
000079f9de5d0b24  vmovaps xmm7, [rsp+0x60]
000079f9de5d0b2a  vmovaps xmm8, [rsp+0x70]
000079f9de5d0b30  vmovaps xmm9, [rsp+0x80]
000079f9de5d0b39  vmovaps xmm10, [rsp+0x90]
000079f9de5d0b42  vmovaps xmm11, [rsp+0xA0]
000079f9de5d0b4b  vmovaps xmm12, [rsp+0xB0]
000079f9de5d0b54  vmovaps xmm13, [rsp+0xC0]
000079f9de5d0b5d  vmovaps xmm14, [rsp+0xD0]
000079f9de5d0b66  vmovaps xmm15, [rsp+0xE0]
000079f9de5d0b6f  add rsp, 0xF0
000079f9de5d0b76  pop r11
000079f9de5d0b78  pop r10
000079f9de5d0b7a  pop r9
000079f9de5d0b7c  pop r8
000079f9de5d0b7e  pop rsi
000079f9de5d0b7f  pop rdi
000079f9de5d0b80  pop rdx
000079f9de5d0b81  pop rcx
000079f9de5d0b82  pop rax
000079f9de5d0b83  add rsp, 0x08
000079f9de5d0b87  jmp 0x000079F9DE5CF631
000079f9de5d0b8c  sub rsp, 0x08
000079f9de5d0b90  push rax
000079f9de5d0b91  push rcx
000079f9de5d0b92  push rdx
000079f9de5d0b93  push rdi
000079f9de5d0b94  push rsi
000079f9de5d0b95  push r8
000079f9de5d0b97  push r9
000079f9de5d0b99  push r10
000079f9de5d0b9b  push r11
000079f9de5d0b9d  sub rsp, 0xF0
000079f9de5d0ba4  vmovaps [rsp], xmm0
000079f9de5d0ba9  vmovaps [rsp+0x10], xmm1
000079f9de5d0baf  vmovaps [rsp+0x20], xmm2
000079f9de5d0bb5  vmovaps [rsp+0x30], xmm3
000079f9de5d0bbb  vmovaps [rsp+0x40], xmm4
000079f9de5d0bc1  vmovaps [rsp+0x50], xmm5
000079f9de5d0bc7  vmovaps [rsp+0x60], xmm6
000079f9de5d0bcd  vmovaps [rsp+0x70], xmm7
000079f9de5d0bd3  vmovaps [rsp+0x80], xmm8
000079f9de5d0bdc  vmovaps [rsp+0x90], xmm9
000079f9de5d0be5  vmovaps [rsp+0xA0], xmm10
000079f9de5d0bee  vmovaps [rsp+0xB0], xmm11
000079f9de5d0bf7  vmovaps [rsp+0xC0], xmm12
000079f9de5d0c00  vmovaps [rsp+0xD0], xmm14
000079f9de5d0c09  vmovaps [rsp+0xE0], xmm15
000079f9de5d0c12  sub rsp, 0x30
000079f9de5d0c16  movaps [rsp], xmm13
000079f9de5d0c1b  movaps [rsp+0x10], xmm14
000079f9de5d0c21  movaps [rsp+0x20], xmm2
000079f9de5d0c26  lea rdi, [rsp]
000079f9de5d0c2a  mov esi, 0x00
000079f9de5d0c2f  mov rax, 0x56D56FF59530
000079f9de5d0c39  call rax
000079f9de5d0c3b  movaps xmm13, [rsp]
000079f9de5d0c40  add rsp, 0x30
000079f9de5d0c44  vmovaps xmm0, [rsp]
000079f9de5d0c49  vmovaps xmm1, [rsp+0x10]
000079f9de5d0c4f  vmovaps xmm2, [rsp+0x20]
000079f9de5d0c55  vmovaps xmm3, [rsp+0x30]
000079f9de5d0c5b  vmovaps xmm4, [rsp+0x40]
000079f9de5d0c61  vmovaps xmm5, [rsp+0x50]
000079f9de5d0c67  vmovaps xmm6, [rsp+0x60]
000079f9de5d0c6d  vmovaps xmm7, [rsp+0x70]
000079f9de5d0c73  vmovaps xmm8, [rsp+0x80]
000079f9de5d0c7c  vmovaps xmm9, [rsp+0x90]
000079f9de5d0c85  vmovaps xmm10, [rsp+0xA0]
000079f9de5d0c8e  vmovaps xmm11, [rsp+0xB0]
000079f9de5d0c97  vmovaps xmm12, [rsp+0xC0]
000079f9de5d0ca0  vmovaps xmm14, [rsp+0xD0]
000079f9de5d0ca9  vmovaps xmm15, [rsp+0xE0]
000079f9de5d0cb2  add rsp, 0xF0
000079f9de5d0cb9  pop r11
000079f9de5d0cbb  pop r10
000079f9de5d0cbd  pop r9
000079f9de5d0cbf  pop r8
000079f9de5d0cc1  pop rsi
000079f9de5d0cc2  pop rdi
000079f9de5d0cc3  pop rdx
000079f9de5d0cc4  pop rcx
000079f9de5d0cc5  pop rax
000079f9de5d0cc6  add rsp, 0x08
000079f9de5d0cca  jmp 0x000079F9DE5CF64C
000079f9de5d0ccf  sub rsp, 0x08
000079f9de5d0cd3  push rax
000079f9de5d0cd4  push rcx
000079f9de5d0cd5  push rdx
000079f9de5d0cd6  push rdi
000079f9de5d0cd7  push rsi
000079f9de5d0cd8  push r8
000079f9de5d0cda  push r9
000079f9de5d0cdc  push r10
000079f9de5d0cde  push r11
000079f9de5d0ce0  sub rsp, 0xF0
000079f9de5d0ce7  vmovaps [rsp], xmm0
000079f9de5d0cec  vmovaps [rsp+0x10], xmm2
000079f9de5d0cf2  vmovaps [rsp+0x20], xmm3
000079f9de5d0cf8  vmovaps [rsp+0x30], xmm4
000079f9de5d0cfe  vmovaps [rsp+0x40], xmm5
000079f9de5d0d04  vmovaps [rsp+0x50], xmm6
000079f9de5d0d0a  vmovaps [rsp+0x60], xmm7
000079f9de5d0d10  vmovaps [rsp+0x70], xmm8
000079f9de5d0d16  vmovaps [rsp+0x80], xmm9
000079f9de5d0d1f  vmovaps [rsp+0x90], xmm10
000079f9de5d0d28  vmovaps [rsp+0xA0], xmm11
000079f9de5d0d31  vmovaps [rsp+0xB0], xmm12
000079f9de5d0d3a  vmovaps [rsp+0xC0], xmm13
000079f9de5d0d43  vmovaps [rsp+0xD0], xmm14
000079f9de5d0d4c  vmovaps [rsp+0xE0], xmm15
000079f9de5d0d55  sub rsp, 0x30
000079f9de5d0d59  movaps [rsp], xmm1
000079f9de5d0d5d  movaps [rsp+0x10], xmm10
000079f9de5d0d63  movaps [rsp+0x20], xmm2
000079f9de5d0d68  lea rdi, [rsp]
000079f9de5d0d6c  mov esi, 0x00
000079f9de5d0d71  mov rax, 0x56D56FF59530
000079f9de5d0d7b  call rax
000079f9de5d0d7d  movaps xmm1, [rsp]
000079f9de5d0d81  add rsp, 0x30
000079f9de5d0d85  vmovaps xmm0, [rsp]
000079f9de5d0d8a  vmovaps xmm2, [rsp+0x10]
000079f9de5d0d90  vmovaps xmm3, [rsp+0x20]
000079f9de5d0d96  vmovaps xmm4, [rsp+0x30]
000079f9de5d0d9c  vmovaps xmm5, [rsp+0x40]
000079f9de5d0da2  vmovaps xmm6, [rsp+0x50]
000079f9de5d0da8  vmovaps xmm7, [rsp+0x60]
000079f9de5d0dae  vmovaps xmm8, [rsp+0x70]
000079f9de5d0db4  vmovaps xmm9, [rsp+0x80]
000079f9de5d0dbd  vmovaps xmm10, [rsp+0x90]
000079f9de5d0dc6  vmovaps xmm11, [rsp+0xA0]
000079f9de5d0dcf  vmovaps xmm12, [rsp+0xB0]
000079f9de5d0dd8  vmovaps xmm13, [rsp+0xC0]
000079f9de5d0de1  vmovaps xmm14, [rsp+0xD0]
000079f9de5d0dea  vmovaps xmm15, [rsp+0xE0]
000079f9de5d0df3  add rsp, 0xF0
000079f9de5d0dfa  pop r11
000079f9de5d0dfc  pop r10
000079f9de5d0dfe  pop r9
000079f9de5d0e00  pop r8
000079f9de5d0e02  pop rsi
000079f9de5d0e03  pop rdi
000079f9de5d0e04  pop rdx
000079f9de5d0e05  pop rcx
000079f9de5d0e06  pop rax
000079f9de5d0e07  add rsp, 0x08
000079f9de5d0e0b  jmp 0x000079F9DE5CF6B4
000079f9de5d0e10  sub rsp, 0x08
000079f9de5d0e14  push rax
000079f9de5d0e15  push rcx
000079f9de5d0e16  push rdx
000079f9de5d0e17  push rdi
000079f9de5d0e18  push rsi
000079f9de5d0e19  push r8
000079f9de5d0e1b  push r9
000079f9de5d0e1d  push r10
000079f9de5d0e1f  push r11
000079f9de5d0e21  sub rsp, 0xF0
000079f9de5d0e28  vmovaps [rsp], xmm0
000079f9de5d0e2d  vmovaps [rsp+0x10], xmm1
000079f9de5d0e33  vmovaps [rsp+0x20], xmm2
000079f9de5d0e39  vmovaps [rsp+0x30], xmm3
000079f9de5d0e3f  vmovaps [rsp+0x40], xmm4
000079f9de5d0e45  vmovaps [rsp+0x50], xmm5
000079f9de5d0e4b  vmovaps [rsp+0x60], xmm6
000079f9de5d0e51  vmovaps [rsp+0x70], xmm7
000079f9de5d0e57  vmovaps [rsp+0x80], xmm8
000079f9de5d0e60  vmovaps [rsp+0x90], xmm9
000079f9de5d0e69  vmovaps [rsp+0xA0], xmm10
000079f9de5d0e72  vmovaps [rsp+0xB0], xmm11
000079f9de5d0e7b  vmovaps [rsp+0xC0], xmm12
000079f9de5d0e84  vmovaps [rsp+0xD0], xmm13
000079f9de5d0e8d  vmovaps [rsp+0xE0], xmm14
000079f9de5d0e96  sub rsp, 0x30
000079f9de5d0e9a  movaps [rsp], xmm15
000079f9de5d0e9f  movaps [rsp+0x10], xmm10
000079f9de5d0ea5  movaps [rsp+0x20], xmm2
000079f9de5d0eaa  lea rdi, [rsp]
000079f9de5d0eae  mov esi, 0x00
000079f9de5d0eb3  mov rax, 0x56D56FF59530
000079f9de5d0ebd  call rax
000079f9de5d0ebf  movaps xmm15, [rsp]
000079f9de5d0ec4  add rsp, 0x30
000079f9de5d0ec8  vmovaps xmm0, [rsp]
000079f9de5d0ecd  vmovaps xmm1, [rsp+0x10]
000079f9de5d0ed3  vmovaps xmm2, [rsp+0x20]
000079f9de5d0ed9  vmovaps xmm3, [rsp+0x30]
000079f9de5d0edf  vmovaps xmm4, [rsp+0x40]
000079f9de5d0ee5  vmovaps xmm5, [rsp+0x50]
000079f9de5d0eeb  vmovaps xmm6, [rsp+0x60]
000079f9de5d0ef1  vmovaps xmm7, [rsp+0x70]
000079f9de5d0ef7  vmovaps xmm8, [rsp+0x80]
000079f9de5d0f00  vmovaps xmm9, [rsp+0x90]
000079f9de5d0f09  vmovaps xmm10, [rsp+0xA0]
000079f9de5d0f12  vmovaps xmm11, [rsp+0xB0]
000079f9de5d0f1b  vmovaps xmm12, [rsp+0xC0]
000079f9de5d0f24  vmovaps xmm13, [rsp+0xD0]
000079f9de5d0f2d  vmovaps xmm14, [rsp+0xE0]
000079f9de5d0f36  add rsp, 0xF0
000079f9de5d0f3d  pop r11
000079f9de5d0f3f  pop r10
000079f9de5d0f41  pop r9
000079f9de5d0f43  pop r8
000079f9de5d0f45  pop rsi
000079f9de5d0f46  pop rdi
000079f9de5d0f47  pop rdx
000079f9de5d0f48  pop rcx
000079f9de5d0f49  pop rax
000079f9de5d0f4a  add rsp, 0x08
000079f9de5d0f4e  jmp 0x000079F9DE5CF706
000079f9de5d0f53  sub rsp, 0x08
000079f9de5d0f57  push rax
000079f9de5d0f58  push rcx
000079f9de5d0f59  push rdx
000079f9de5d0f5a  push rdi
000079f9de5d0f5b  push rsi
000079f9de5d0f5c  push r8
000079f9de5d0f5e  push r9
000079f9de5d0f60  push r10
000079f9de5d0f62  push r11
000079f9de5d0f64  sub rsp, 0xF0
000079f9de5d0f6b  vmovaps [rsp], xmm0
000079f9de5d0f70  vmovaps [rsp+0x10], xmm2
000079f9de5d0f76  vmovaps [rsp+0x20], xmm3
000079f9de5d0f7c  vmovaps [rsp+0x30], xmm4
000079f9de5d0f82  vmovaps [rsp+0x40], xmm5
000079f9de5d0f88  vmovaps [rsp+0x50], xmm6
000079f9de5d0f8e  vmovaps [rsp+0x60], xmm7
000079f9de5d0f94  vmovaps [rsp+0x70], xmm8
000079f9de5d0f9a  vmovaps [rsp+0x80], xmm9
000079f9de5d0fa3  vmovaps [rsp+0x90], xmm10
000079f9de5d0fac  vmovaps [rsp+0xA0], xmm11
000079f9de5d0fb5  vmovaps [rsp+0xB0], xmm12
000079f9de5d0fbe  vmovaps [rsp+0xC0], xmm13
000079f9de5d0fc7  vmovaps [rsp+0xD0], xmm14
000079f9de5d0fd0  vmovaps [rsp+0xE0], xmm15
000079f9de5d0fd9  sub rsp, 0x30
000079f9de5d0fdd  movaps [rsp], xmm1
000079f9de5d0fe1  movaps [rsp+0x10], xmm10
000079f9de5d0fe7  movaps [rsp+0x20], xmm12
000079f9de5d0fed  lea rdi, [rsp]
000079f9de5d0ff1  mov esi, 0x00
000079f9de5d0ff6  mov rax, 0x56D56FF59530
000079f9de5d1000  call rax
000079f9de5d1002  movaps xmm1, [rsp]
000079f9de5d1006  add rsp, 0x30
000079f9de5d100a  vmovaps xmm0, [rsp]
000079f9de5d100f  vmovaps xmm2, [rsp+0x10]
000079f9de5d1015  vmovaps xmm3, [rsp+0x20]
000079f9de5d101b  vmovaps xmm4, [rsp+0x30]
000079f9de5d1021  vmovaps xmm5, [rsp+0x40]
000079f9de5d1027  vmovaps xmm6, [rsp+0x50]
000079f9de5d102d  vmovaps xmm7, [rsp+0x60]
000079f9de5d1033  vmovaps xmm8, [rsp+0x70]
000079f9de5d1039  vmovaps xmm9, [rsp+0x80]
000079f9de5d1042  vmovaps xmm10, [rsp+0x90]
000079f9de5d104b  vmovaps xmm11, [rsp+0xA0]
000079f9de5d1054  vmovaps xmm12, [rsp+0xB0]
000079f9de5d105d  vmovaps xmm13, [rsp+0xC0]
000079f9de5d1066  vmovaps xmm14, [rsp+0xD0]
000079f9de5d106f  vmovaps xmm15, [rsp+0xE0]
000079f9de5d1078  add rsp, 0xF0
000079f9de5d107f  pop r11
000079f9de5d1081  pop r10
000079f9de5d1083  pop r9
000079f9de5d1085  pop r8
000079f9de5d1087  pop rsi
000079f9de5d1088  pop rdi
000079f9de5d1089  pop rdx
000079f9de5d108a  pop rcx
000079f9de5d108b  pop rax
000079f9de5d108c  add rsp, 0x08
000079f9de5d1090  jmp 0x000079F9DE5CF732
000079f9de5d1095  sub rsp, 0x08
000079f9de5d1099  push rax
000079f9de5d109a  push rcx
000079f9de5d109b  push rdx
000079f9de5d109c  push rdi
000079f9de5d109d  push rsi
000079f9de5d109e  push r8
000079f9de5d10a0  push r9
000079f9de5d10a2  push r10
000079f9de5d10a4  push r11
000079f9de5d10a6  sub rsp, 0xF0
000079f9de5d10ad  vmovaps [rsp], xmm0
000079f9de5d10b2  vmovaps [rsp+0x10], xmm1
000079f9de5d10b8  vmovaps [rsp+0x20], xmm2
000079f9de5d10be  vmovaps [rsp+0x30], xmm3
000079f9de5d10c4  vmovaps [rsp+0x40], xmm4
000079f9de5d10ca  vmovaps [rsp+0x50], xmm5
000079f9de5d10d0  vmovaps [rsp+0x60], xmm6
000079f9de5d10d6  vmovaps [rsp+0x70], xmm7
000079f9de5d10dc  vmovaps [rsp+0x80], xmm8
000079f9de5d10e5  vmovaps [rsp+0x90], xmm9
000079f9de5d10ee  vmovaps [rsp+0xA0], xmm10
000079f9de5d10f7  vmovaps [rsp+0xB0], xmm11
000079f9de5d1100  vmovaps [rsp+0xC0], xmm12
000079f9de5d1109  vmovaps [rsp+0xD0], xmm13
000079f9de5d1112  vmovaps [rsp+0xE0], xmm14
000079f9de5d111b  sub rsp, 0x30
000079f9de5d111f  movaps [rsp], xmm15
000079f9de5d1124  movaps [rsp+0x10], xmm10
000079f9de5d112a  movaps [rsp+0x20], xmm12
000079f9de5d1130  lea rdi, [rsp]
000079f9de5d1134  mov esi, 0x00
000079f9de5d1139  mov rax, 0x56D56FF59530
000079f9de5d1143  call rax
000079f9de5d1145  movaps xmm15, [rsp]
000079f9de5d114a  add rsp, 0x30
000079f9de5d114e  vmovaps xmm0, [rsp]
000079f9de5d1153  vmovaps xmm1, [rsp+0x10]
000079f9de5d1159  vmovaps xmm2, [rsp+0x20]
000079f9de5d115f  vmovaps xmm3, [rsp+0x30]
000079f9de5d1165  vmovaps xmm4, [rsp+0x40]
000079f9de5d116b  vmovaps xmm5, [rsp+0x50]
000079f9de5d1171  vmovaps xmm6, [rsp+0x60]
000079f9de5d1177  vmovaps xmm7, [rsp+0x70]
000079f9de5d117d  vmovaps xmm8, [rsp+0x80]
000079f9de5d1186  vmovaps xmm9, [rsp+0x90]
000079f9de5d118f  vmovaps xmm10, [rsp+0xA0]
000079f9de5d1198  vmovaps xmm11, [rsp+0xB0]
000079f9de5d11a1  vmovaps xmm12, [rsp+0xC0]
000079f9de5d11aa  vmovaps xmm13, [rsp+0xD0]
000079f9de5d11b3  vmovaps xmm14, [rsp+0xE0]
000079f9de5d11bc  add rsp, 0xF0
000079f9de5d11c3  pop r11
000079f9de5d11c5  pop r10
000079f9de5d11c7  pop r9
000079f9de5d11c9  pop r8
000079f9de5d11cb  pop rsi
000079f9de5d11cc  pop rdi
000079f9de5d11cd  pop rdx
000079f9de5d11ce  pop rcx
000079f9de5d11cf  pop rax
000079f9de5d11d0  add rsp, 0x08
000079f9de5d11d4  jmp 0x000079F9DE5CF75E
000079f9de5d11d9  call 0x000079F9DE3FF430
000079f9de5d11de  jmp 0x000079F9DE5CF7EE
000079f9de5d11e3  call 0x000079F9DE3FF430
000079f9de5d11e8  jmp 0x000079F9DE5CF801
000079f9de5d11ed  sub rsp, 0x08
000079f9de5d11f1  push rax
000079f9de5d11f2  push rcx
000079f9de5d11f3  push rdx
000079f9de5d11f4  push rdi
000079f9de5d11f5  push rsi
000079f9de5d11f6  push r8
000079f9de5d11f8  push r9
000079f9de5d11fa  push r10
000079f9de5d11fc  push r11
000079f9de5d11fe  sub rsp, 0xF0
000079f9de5d1205  vmovaps [rsp], xmm0
000079f9de5d120a  vmovaps [rsp+0x10], xmm2
000079f9de5d1210  vmovaps [rsp+0x20], xmm3
000079f9de5d1216  vmovaps [rsp+0x30], xmm4
000079f9de5d121c  vmovaps [rsp+0x40], xmm5
000079f9de5d1222  vmovaps [rsp+0x50], xmm6
000079f9de5d1228  vmovaps [rsp+0x60], xmm7
000079f9de5d122e  vmovaps [rsp+0x70], xmm8
000079f9de5d1234  vmovaps [rsp+0x80], xmm9
000079f9de5d123d  vmovaps [rsp+0x90], xmm10
000079f9de5d1246  vmovaps [rsp+0xA0], xmm11
000079f9de5d124f  vmovaps [rsp+0xB0], xmm12
000079f9de5d1258  vmovaps [rsp+0xC0], xmm13
000079f9de5d1261  vmovaps [rsp+0xD0], xmm14
000079f9de5d126a  vmovaps [rsp+0xE0], xmm15
000079f9de5d1273  sub rsp, 0x30
000079f9de5d1277  movaps [rsp], xmm1
000079f9de5d127b  movaps [rsp+0x10], xmm13
000079f9de5d1281  movaps [rsp+0x20], xmm2
000079f9de5d1286  lea rdi, [rsp]
000079f9de5d128a  mov esi, 0x00
000079f9de5d128f  mov rax, 0x56D56FF59530
000079f9de5d1299  call rax
000079f9de5d129b  movaps xmm1, [rsp]
000079f9de5d129f  add rsp, 0x30
000079f9de5d12a3  vmovaps xmm0, [rsp]
000079f9de5d12a8  vmovaps xmm2, [rsp+0x10]
000079f9de5d12ae  vmovaps xmm3, [rsp+0x20]
000079f9de5d12b4  vmovaps xmm4, [rsp+0x30]
000079f9de5d12ba  vmovaps xmm5, [rsp+0x40]
000079f9de5d12c0  vmovaps xmm6, [rsp+0x50]
000079f9de5d12c6  vmovaps xmm7, [rsp+0x60]
000079f9de5d12cc  vmovaps xmm8, [rsp+0x70]
000079f9de5d12d2  vmovaps xmm9, [rsp+0x80]
000079f9de5d12db  vmovaps xmm10, [rsp+0x90]
000079f9de5d12e4  vmovaps xmm11, [rsp+0xA0]
000079f9de5d12ed  vmovaps xmm12, [rsp+0xB0]
000079f9de5d12f6  vmovaps xmm13, [rsp+0xC0]
000079f9de5d12ff  vmovaps xmm14, [rsp+0xD0]
000079f9de5d1308  vmovaps xmm15, [rsp+0xE0]
000079f9de5d1311  add rsp, 0xF0
000079f9de5d1318  pop r11
000079f9de5d131a  pop r10
000079f9de5d131c  pop r9
000079f9de5d131e  pop r8
000079f9de5d1320  pop rsi
000079f9de5d1321  pop rdi
000079f9de5d1322  pop rdx
000079f9de5d1323  pop rcx
000079f9de5d1324  pop rax
000079f9de5d1325  add rsp, 0x08
000079f9de5d1329  jmp 0x000079F9DE5CF82C
000079f9de5d132e  call 0x000079F9DE40E760
000079f9de5d1333  jmp 0x000079F9DE5CF839
000079f9de5d1338  sub rsp, 0x08
000079f9de5d133c  push rax
000079f9de5d133d  push rcx
000079f9de5d133e  push rdx
000079f9de5d133f  push rdi
000079f9de5d1340  push rsi
000079f9de5d1341  push r8
000079f9de5d1343  push r9
000079f9de5d1345  push r10
000079f9de5d1347  push r11
000079f9de5d1349  sub rsp, 0xF0
000079f9de5d1350  vmovaps [rsp], xmm0
000079f9de5d1355  vmovaps [rsp+0x10], xmm1
000079f9de5d135b  vmovaps [rsp+0x20], xmm2
000079f9de5d1361  vmovaps [rsp+0x30], xmm3
000079f9de5d1367  vmovaps [rsp+0x40], xmm4
000079f9de5d136d  vmovaps [rsp+0x50], xmm5
000079f9de5d1373  vmovaps [rsp+0x60], xmm6
000079f9de5d1379  vmovaps [rsp+0x70], xmm7
000079f9de5d137f  vmovaps [rsp+0x80], xmm8
000079f9de5d1388  vmovaps [rsp+0x90], xmm9
000079f9de5d1391  vmovaps [rsp+0xA0], xmm10
000079f9de5d139a  vmovaps [rsp+0xB0], xmm11
000079f9de5d13a3  vmovaps [rsp+0xC0], xmm12
000079f9de5d13ac  vmovaps [rsp+0xD0], xmm14
000079f9de5d13b5  vmovaps [rsp+0xE0], xmm15
000079f9de5d13be  sub rsp, 0x30
000079f9de5d13c2  movaps [rsp], xmm13
000079f9de5d13c7  movaps [rsp+0x10], xmm2
000079f9de5d13cc  movaps [rsp+0x20], xmm1
000079f9de5d13d1  lea rdi, [rsp]
000079f9de5d13d5  mov esi, 0x00
000079f9de5d13da  mov rax, 0x56D56FF59530
000079f9de5d13e4  call rax
000079f9de5d13e6  movaps xmm13, [rsp]
000079f9de5d13eb  add rsp, 0x30
000079f9de5d13ef  vmovaps xmm0, [rsp]
000079f9de5d13f4  vmovaps xmm1, [rsp+0x10]
000079f9de5d13fa  vmovaps xmm2, [rsp+0x20]
000079f9de5d1400  vmovaps xmm3, [rsp+0x30]
000079f9de5d1406  vmovaps xmm4, [rsp+0x40]
000079f9de5d140c  vmovaps xmm5, [rsp+0x50]
000079f9de5d1412  vmovaps xmm6, [rsp+0x60]
000079f9de5d1418  vmovaps xmm7, [rsp+0x70]
000079f9de5d141e  vmovaps xmm8, [rsp+0x80]
000079f9de5d1427  vmovaps xmm9, [rsp+0x90]
000079f9de5d1430  vmovaps xmm10, [rsp+0xA0]
000079f9de5d1439  vmovaps xmm11, [rsp+0xB0]
000079f9de5d1442  vmovaps xmm12, [rsp+0xC0]
000079f9de5d144b  vmovaps xmm14, [rsp+0xD0]
000079f9de5d1454  vmovaps xmm15, [rsp+0xE0]
000079f9de5d145d  add rsp, 0xF0
000079f9de5d1464  pop r11
000079f9de5d1466  pop r10
000079f9de5d1468  pop r9
000079f9de5d146a  pop r8
000079f9de5d146c  pop rsi
000079f9de5d146d  pop rdi
000079f9de5d146e  pop rdx
000079f9de5d146f  pop rcx
000079f9de5d1470  pop rax
000079f9de5d1471  add rsp, 0x08
000079f9de5d1475  jmp 0x000079F9DE5CF878
000079f9de5d147a  sub rsp, 0x08
000079f9de5d147e  push rax
000079f9de5d147f  push rcx
000079f9de5d1480  push rdx
000079f9de5d1481  push rdi
000079f9de5d1482  push rsi
000079f9de5d1483  push r8
000079f9de5d1485  push r9
000079f9de5d1487  push r10
000079f9de5d1489  push r11
000079f9de5d148b  sub rsp, 0xF0
000079f9de5d1492  vmovaps [rsp], xmm0
000079f9de5d1497  vmovaps [rsp+0x10], xmm2
000079f9de5d149d  vmovaps [rsp+0x20], xmm3
000079f9de5d14a3  vmovaps [rsp+0x30], xmm4
000079f9de5d14a9  vmovaps [rsp+0x40], xmm5
000079f9de5d14af  vmovaps [rsp+0x50], xmm6
000079f9de5d14b5  vmovaps [rsp+0x60], xmm7
000079f9de5d14bb  vmovaps [rsp+0x70], xmm8
000079f9de5d14c1  vmovaps [rsp+0x80], xmm9
000079f9de5d14ca  vmovaps [rsp+0x90], xmm10
000079f9de5d14d3  vmovaps [rsp+0xA0], xmm11
000079f9de5d14dc  vmovaps [rsp+0xB0], xmm12
000079f9de5d14e5  vmovaps [rsp+0xC0], xmm13
000079f9de5d14ee  vmovaps [rsp+0xD0], xmm14
000079f9de5d14f7  vmovaps [rsp+0xE0], xmm15
000079f9de5d1500  sub rsp, 0x30
000079f9de5d1504  movaps [rsp], xmm1
000079f9de5d1508  movaps [rsp+0x10], xmm15
000079f9de5d150e  movaps [rsp+0x20], xmm2
000079f9de5d1513  lea rdi, [rsp]
000079f9de5d1517  mov esi, 0x00
000079f9de5d151c  mov rax, 0x56D56FF59530
000079f9de5d1526  call rax
000079f9de5d1528  movaps xmm1, [rsp]
000079f9de5d152c  add rsp, 0x30
000079f9de5d1530  vmovaps xmm0, [rsp]
000079f9de5d1535  vmovaps xmm2, [rsp+0x10]
000079f9de5d153b  vmovaps xmm3, [rsp+0x20]
000079f9de5d1541  vmovaps xmm4, [rsp+0x30]
000079f9de5d1547  vmovaps xmm5, [rsp+0x40]
000079f9de5d154d  vmovaps xmm6, [rsp+0x50]
000079f9de5d1553  vmovaps xmm7, [rsp+0x60]
000079f9de5d1559  vmovaps xmm8, [rsp+0x70]
000079f9de5d155f  vmovaps xmm9, [rsp+0x80]
000079f9de5d1568  vmovaps xmm10, [rsp+0x90]
000079f9de5d1571  vmovaps xmm11, [rsp+0xA0]
000079f9de5d157a  vmovaps xmm12, [rsp+0xB0]
000079f9de5d1583  vmovaps xmm13, [rsp+0xC0]
000079f9de5d158c  vmovaps xmm14, [rsp+0xD0]
000079f9de5d1595  vmovaps xmm15, [rsp+0xE0]
000079f9de5d159e  add rsp, 0xF0
000079f9de5d15a5  pop r11
000079f9de5d15a7  pop r10
000079f9de5d15a9  pop r9
000079f9de5d15ab  pop r8
000079f9de5d15ad  pop rsi
000079f9de5d15ae  pop rdi
000079f9de5d15af  pop rdx
000079f9de5d15b0  pop rcx
000079f9de5d15b1  pop rax
000079f9de5d15b2  add rsp, 0x08
000079f9de5d15b6  jmp 0x000079F9DE5CF8AC
000079f9de5d15bb  sub rsp, 0x08
000079f9de5d15bf  push rax
000079f9de5d15c0  push rcx
000079f9de5d15c1  push rdx
000079f9de5d15c2  push rdi
000079f9de5d15c3  push rsi
000079f9de5d15c4  push r8
000079f9de5d15c6  push r9
000079f9de5d15c8  push r10
000079f9de5d15ca  push r11
000079f9de5d15cc  sub rsp, 0xF0
000079f9de5d15d3  vmovaps [rsp], xmm0
000079f9de5d15d8  vmovaps [rsp+0x10], xmm1
000079f9de5d15de  vmovaps [rsp+0x20], xmm2
000079f9de5d15e4  vmovaps [rsp+0x30], xmm3
000079f9de5d15ea  vmovaps [rsp+0x40], xmm4
000079f9de5d15f0  vmovaps [rsp+0x50], xmm5
000079f9de5d15f6  vmovaps [rsp+0x60], xmm6
000079f9de5d15fc  vmovaps [rsp+0x70], xmm7
000079f9de5d1602  vmovaps [rsp+0x80], xmm8
000079f9de5d160b  vmovaps [rsp+0x90], xmm9
000079f9de5d1614  vmovaps [rsp+0xA0], xmm10
000079f9de5d161d  vmovaps [rsp+0xB0], xmm11
000079f9de5d1626  vmovaps [rsp+0xC0], xmm12
000079f9de5d162f  vmovaps [rsp+0xD0], xmm13
000079f9de5d1638  vmovaps [rsp+0xE0], xmm15
000079f9de5d1641  sub rsp, 0x30
000079f9de5d1645  movaps [rsp], xmm14
000079f9de5d164a  movaps [rsp+0x10], xmm2
000079f9de5d164f  movaps [rsp+0x20], xmm15
000079f9de5d1655  lea rdi, [rsp]
000079f9de5d1659  mov esi, 0x00
000079f9de5d165e  mov rax, 0x56D56FF59530
000079f9de5d1668  call rax
000079f9de5d166a  movaps xmm14, [rsp]
000079f9de5d166f  add rsp, 0x30
000079f9de5d1673  vmovaps xmm0, [rsp]
000079f9de5d1678  vmovaps xmm1, [rsp+0x10]
000079f9de5d167e  vmovaps xmm2, [rsp+0x20]
000079f9de5d1684  vmovaps xmm3, [rsp+0x30]
000079f9de5d168a  vmovaps xmm4, [rsp+0x40]
000079f9de5d1690  vmovaps xmm5, [rsp+0x50]
000079f9de5d1696  vmovaps xmm6, [rsp+0x60]
000079f9de5d169c  vmovaps xmm7, [rsp+0x70]
000079f9de5d16a2  vmovaps xmm8, [rsp+0x80]
000079f9de5d16ab  vmovaps xmm9, [rsp+0x90]
000079f9de5d16b4  vmovaps xmm10, [rsp+0xA0]
000079f9de5d16bd  vmovaps xmm11, [rsp+0xB0]
000079f9de5d16c6  vmovaps xmm12, [rsp+0xC0]
000079f9de5d16cf  vmovaps xmm13, [rsp+0xD0]
000079f9de5d16d8  vmovaps xmm15, [rsp+0xE0]
000079f9de5d16e1  add rsp, 0xF0
000079f9de5d16e8  pop r11
000079f9de5d16ea  pop r10
000079f9de5d16ec  pop r9
000079f9de5d16ee  pop r8
000079f9de5d16f0  pop rsi
000079f9de5d16f1  pop rdi
000079f9de5d16f2  pop rdx
000079f9de5d16f3  pop rcx
000079f9de5d16f4  pop rax
000079f9de5d16f5  add rsp, 0x08
000079f9de5d16f9  jmp 0x000079F9DE5CF8E7
000079f9de5d16fe  sub rsp, 0x08
000079f9de5d1702  push rax
000079f9de5d1703  push rcx
000079f9de5d1704  push rdx
000079f9de5d1705  push rdi
000079f9de5d1706  push rsi
000079f9de5d1707  push r8
000079f9de5d1709  push r9
000079f9de5d170b  push r10
000079f9de5d170d  push r11
000079f9de5d170f  sub rsp, 0xF0
000079f9de5d1716  vmovaps [rsp], xmm0
000079f9de5d171b  vmovaps [rsp+0x10], xmm1
000079f9de5d1721  vmovaps [rsp+0x20], xmm2
000079f9de5d1727  vmovaps [rsp+0x30], xmm3
000079f9de5d172d  vmovaps [rsp+0x40], xmm4
000079f9de5d1733  vmovaps [rsp+0x50], xmm5
000079f9de5d1739  vmovaps [rsp+0x60], xmm6
000079f9de5d173f  vmovaps [rsp+0x70], xmm7
000079f9de5d1745  vmovaps [rsp+0x80], xmm8
000079f9de5d174e  vmovaps [rsp+0x90], xmm9
000079f9de5d1757  vmovaps [rsp+0xA0], xmm10
000079f9de5d1760  vmovaps [rsp+0xB0], xmm11
000079f9de5d1769  vmovaps [rsp+0xC0], xmm12
000079f9de5d1772  vmovaps [rsp+0xD0], xmm13
000079f9de5d177b  vmovaps [rsp+0xE0], xmm14
000079f9de5d1784  sub rsp, 0x30
000079f9de5d1788  movaps [rsp], xmm15
000079f9de5d178d  movaps [rsp+0x10], xmm2
000079f9de5d1792  movaps [rsp+0x20], xmm1
000079f9de5d1797  lea rdi, [rsp]
000079f9de5d179b  mov esi, 0x00
000079f9de5d17a0  mov rax, 0x56D56FF59530
000079f9de5d17aa  call rax
000079f9de5d17ac  movaps xmm15, [rsp]
000079f9de5d17b1  add rsp, 0x30
000079f9de5d17b5  vmovaps xmm0, [rsp]
000079f9de5d17ba  vmovaps xmm1, [rsp+0x10]
000079f9de5d17c0  vmovaps xmm2, [rsp+0x20]
000079f9de5d17c6  vmovaps xmm3, [rsp+0x30]
000079f9de5d17cc  vmovaps xmm4, [rsp+0x40]
000079f9de5d17d2  vmovaps xmm5, [rsp+0x50]
000079f9de5d17d8  vmovaps xmm6, [rsp+0x60]
000079f9de5d17de  vmovaps xmm7, [rsp+0x70]
000079f9de5d17e4  vmovaps xmm8, [rsp+0x80]
000079f9de5d17ed  vmovaps xmm9, [rsp+0x90]
000079f9de5d17f6  vmovaps xmm10, [rsp+0xA0]
000079f9de5d17ff  vmovaps xmm11, [rsp+0xB0]
000079f9de5d1808  vmovaps xmm12, [rsp+0xC0]
000079f9de5d1811  vmovaps xmm13, [rsp+0xD0]
000079f9de5d181a  vmovaps xmm14, [rsp+0xE0]
000079f9de5d1823  add rsp, 0xF0
000079f9de5d182a  pop r11
000079f9de5d182c  pop r10
000079f9de5d182e  pop r9
000079f9de5d1830  pop r8
000079f9de5d1832  pop rsi
000079f9de5d1833  pop rdi
000079f9de5d1834  pop rdx
000079f9de5d1835  pop rcx
000079f9de5d1836  pop rax
000079f9de5d1837  add rsp, 0x08
000079f9de5d183b  jmp 0x000079F9DE5CF923
000079f9de5d1840  call 0x000079F9DE3FF430
000079f9de5d1845  jmp 0x000079F9DE5CF930
000079f9de5d184a  sub rsp, 0x08
000079f9de5d184e  push rax
000079f9de5d184f  push rcx
000079f9de5d1850  push rdx
000079f9de5d1851  push rdi
000079f9de5d1852  push rsi
000079f9de5d1853  push r8
000079f9de5d1855  push r9
000079f9de5d1857  push r10
000079f9de5d1859  push r11
000079f9de5d185b  sub rsp, 0xF0
000079f9de5d1862  vmovaps [rsp], xmm0
000079f9de5d1867  vmovaps [rsp+0x10], xmm1
000079f9de5d186d  vmovaps [rsp+0x20], xmm3
000079f9de5d1873  vmovaps [rsp+0x30], xmm4
000079f9de5d1879  vmovaps [rsp+0x40], xmm5
000079f9de5d187f  vmovaps [rsp+0x50], xmm6
000079f9de5d1885  vmovaps [rsp+0x60], xmm7
000079f9de5d188b  vmovaps [rsp+0x70], xmm8
000079f9de5d1891  vmovaps [rsp+0x80], xmm9
000079f9de5d189a  vmovaps [rsp+0x90], xmm10
000079f9de5d18a3  vmovaps [rsp+0xA0], xmm11
000079f9de5d18ac  vmovaps [rsp+0xB0], xmm12
000079f9de5d18b5  vmovaps [rsp+0xC0], xmm13
000079f9de5d18be  vmovaps [rsp+0xD0], xmm14
000079f9de5d18c7  vmovaps [rsp+0xE0], xmm15
000079f9de5d18d0  sub rsp, 0x30
000079f9de5d18d4  movaps [rsp], xmm2
000079f9de5d18d8  movaps [rsp+0x10], xmm1
000079f9de5d18dd  movaps [rsp+0x20], xmm14
000079f9de5d18e3  lea rdi, [rsp]
000079f9de5d18e7  mov esi, 0x00
000079f9de5d18ec  mov rax, 0x56D56FF59530
000079f9de5d18f6  call rax
000079f9de5d18f8  movaps xmm2, [rsp]
000079f9de5d18fc  add rsp, 0x30
000079f9de5d1900  vmovaps xmm0, [rsp]
000079f9de5d1905  vmovaps xmm1, [rsp+0x10]
000079f9de5d190b  vmovaps xmm3, [rsp+0x20]
000079f9de5d1911  vmovaps xmm4, [rsp+0x30]
000079f9de5d1917  vmovaps xmm5, [rsp+0x40]
000079f9de5d191d  vmovaps xmm6, [rsp+0x50]
000079f9de5d1923  vmovaps xmm7, [rsp+0x60]
000079f9de5d1929  vmovaps xmm8, [rsp+0x70]
000079f9de5d192f  vmovaps xmm9, [rsp+0x80]
000079f9de5d1938  vmovaps xmm10, [rsp+0x90]
000079f9de5d1941  vmovaps xmm11, [rsp+0xA0]
000079f9de5d194a  vmovaps xmm12, [rsp+0xB0]
000079f9de5d1953  vmovaps xmm13, [rsp+0xC0]
000079f9de5d195c  vmovaps xmm14, [rsp+0xD0]
000079f9de5d1965  vmovaps xmm15, [rsp+0xE0]
000079f9de5d196e  add rsp, 0xF0
000079f9de5d1975  pop r11
000079f9de5d1977  pop r10
000079f9de5d1979  pop r9
000079f9de5d197b  pop r8
000079f9de5d197d  pop rsi
000079f9de5d197e  pop rdi
000079f9de5d197f  pop rdx
000079f9de5d1980  pop rcx
000079f9de5d1981  pop rax
000079f9de5d1982  add rsp, 0x08
000079f9de5d1986  jmp 0x000079F9DE5CF96D
000079f9de5d198b  sub rsp, 0x08
000079f9de5d198f  push rax
000079f9de5d1990  push rcx
000079f9de5d1991  push rdx
000079f9de5d1992  push rdi
000079f9de5d1993  push rsi
000079f9de5d1994  push r8
000079f9de5d1996  push r9
000079f9de5d1998  push r10
000079f9de5d199a  push r11
000079f9de5d199c  sub rsp, 0xF0
000079f9de5d19a3  vmovaps [rsp], xmm0
000079f9de5d19a8  vmovaps [rsp+0x10], xmm1
000079f9de5d19ae  vmovaps [rsp+0x20], xmm2
000079f9de5d19b4  vmovaps [rsp+0x30], xmm3
000079f9de5d19ba  vmovaps [rsp+0x40], xmm4
000079f9de5d19c0  vmovaps [rsp+0x50], xmm5
000079f9de5d19c6  vmovaps [rsp+0x60], xmm6
000079f9de5d19cc  vmovaps [rsp+0x70], xmm7
000079f9de5d19d2  vmovaps [rsp+0x80], xmm8
000079f9de5d19db  vmovaps [rsp+0x90], xmm9
000079f9de5d19e4  vmovaps [rsp+0xA0], xmm10
000079f9de5d19ed  vmovaps [rsp+0xB0], xmm11
000079f9de5d19f6  vmovaps [rsp+0xC0], xmm12
000079f9de5d19ff  vmovaps [rsp+0xD0], xmm13
000079f9de5d1a08  vmovaps [rsp+0xE0], xmm14
000079f9de5d1a11  sub rsp, 0x30
000079f9de5d1a15  movaps [rsp], xmm15
000079f9de5d1a1a  movaps [rsp+0x10], xmm14
000079f9de5d1a20  movaps [rsp+0x20], xmm1
000079f9de5d1a25  lea rdi, [rsp]
000079f9de5d1a29  mov esi, 0x00
000079f9de5d1a2e  mov rax, 0x56D56FF59530
000079f9de5d1a38  call rax
000079f9de5d1a3a  movaps xmm15, [rsp]
000079f9de5d1a3f  add rsp, 0x30
000079f9de5d1a43  vmovaps xmm0, [rsp]
000079f9de5d1a48  vmovaps xmm1, [rsp+0x10]
000079f9de5d1a4e  vmovaps xmm2, [rsp+0x20]
000079f9de5d1a54  vmovaps xmm3, [rsp+0x30]
000079f9de5d1a5a  vmovaps xmm4, [rsp+0x40]
000079f9de5d1a60  vmovaps xmm5, [rsp+0x50]
000079f9de5d1a66  vmovaps xmm6, [rsp+0x60]
000079f9de5d1a6c  vmovaps xmm7, [rsp+0x70]
000079f9de5d1a72  vmovaps xmm8, [rsp+0x80]
000079f9de5d1a7b  vmovaps xmm9, [rsp+0x90]
000079f9de5d1a84  vmovaps xmm10, [rsp+0xA0]
000079f9de5d1a8d  vmovaps xmm11, [rsp+0xB0]
000079f9de5d1a96  vmovaps xmm12, [rsp+0xC0]
000079f9de5d1a9f  vmovaps xmm13, [rsp+0xD0]
000079f9de5d1aa8  vmovaps xmm14, [rsp+0xE0]
000079f9de5d1ab1  add rsp, 0xF0
000079f9de5d1ab8  pop r11
000079f9de5d1aba  pop r10
000079f9de5d1abc  pop r9
000079f9de5d1abe  pop r8
000079f9de5d1ac0  pop rsi
000079f9de5d1ac1  pop rdi
000079f9de5d1ac2  pop rdx
000079f9de5d1ac3  pop rcx
000079f9de5d1ac4  pop rax
000079f9de5d1ac5  add rsp, 0x08
000079f9de5d1ac9  jmp 0x000079F9DE5CF9E7
000079f9de5d1ace  call 0x000079F9DE3FF430
000079f9de5d1ad3  jmp 0x000079F9DE5CF9F4
000079f9de5d1ad8  sub rsp, 0x08
000079f9de5d1adc  push rax
000079f9de5d1add  push rcx
000079f9de5d1ade  push rdx
000079f9de5d1adf  push rdi
000079f9de5d1ae0  push rsi
000079f9de5d1ae1  push r8
000079f9de5d1ae3  push r9
000079f9de5d1ae5  push r10
000079f9de5d1ae7  push r11
000079f9de5d1ae9  sub rsp, 0xF0
000079f9de5d1af0  vmovaps [rsp], xmm0
000079f9de5d1af5  vmovaps [rsp+0x10], xmm1
000079f9de5d1afb  vmovaps [rsp+0x20], xmm2
000079f9de5d1b01  vmovaps [rsp+0x30], xmm3
000079f9de5d1b07  vmovaps [rsp+0x40], xmm4
000079f9de5d1b0d  vmovaps [rsp+0x50], xmm5
000079f9de5d1b13  vmovaps [rsp+0x60], xmm6
000079f9de5d1b19  vmovaps [rsp+0x70], xmm7
000079f9de5d1b1f  vmovaps [rsp+0x80], xmm8
000079f9de5d1b28  vmovaps [rsp+0x90], xmm9
000079f9de5d1b31  vmovaps [rsp+0xA0], xmm10
000079f9de5d1b3a  vmovaps [rsp+0xB0], xmm11
000079f9de5d1b43  vmovaps [rsp+0xC0], xmm12
000079f9de5d1b4c  vmovaps [rsp+0xD0], xmm13
000079f9de5d1b55  vmovaps [rsp+0xE0], xmm15
000079f9de5d1b5e  sub rsp, 0x30
000079f9de5d1b62  movaps [rsp], xmm14
000079f9de5d1b67  movaps [rsp+0x10], xmm13
000079f9de5d1b6d  movaps [rsp+0x20], xmm1
000079f9de5d1b72  lea rdi, [rsp]
000079f9de5d1b76  mov esi, 0x00
000079f9de5d1b7b  mov rax, 0x56D56FF59530
000079f9de5d1b85  call rax
000079f9de5d1b87  movaps xmm14, [rsp]
000079f9de5d1b8c  add rsp, 0x30
000079f9de5d1b90  vmovaps xmm0, [rsp]
000079f9de5d1b95  vmovaps xmm1, [rsp+0x10]
000079f9de5d1b9b  vmovaps xmm2, [rsp+0x20]
000079f9de5d1ba1  vmovaps xmm3, [rsp+0x30]
000079f9de5d1ba7  vmovaps xmm4, [rsp+0x40]
000079f9de5d1bad  vmovaps xmm5, [rsp+0x50]
000079f9de5d1bb3  vmovaps xmm6, [rsp+0x60]
000079f9de5d1bb9  vmovaps xmm7, [rsp+0x70]
000079f9de5d1bbf  vmovaps xmm8, [rsp+0x80]
000079f9de5d1bc8  vmovaps xmm9, [rsp+0x90]
000079f9de5d1bd1  vmovaps xmm10, [rsp+0xA0]
000079f9de5d1bda  vmovaps xmm11, [rsp+0xB0]
000079f9de5d1be3  vmovaps xmm12, [rsp+0xC0]
000079f9de5d1bec  vmovaps xmm13, [rsp+0xD0]
000079f9de5d1bf5  vmovaps xmm15, [rsp+0xE0]
000079f9de5d1bfe  add rsp, 0xF0
000079f9de5d1c05  pop r11
000079f9de5d1c07  pop r10
000079f9de5d1c09  pop r9
000079f9de5d1c0b  pop r8
000079f9de5d1c0d  pop rsi
000079f9de5d1c0e  pop rdi
000079f9de5d1c0f  pop rdx
000079f9de5d1c10  pop rcx
000079f9de5d1c11  pop rax
000079f9de5d1c12  add rsp, 0x08
000079f9de5d1c16  jmp 0x000079F9DE5CFAAF
000079f9de5d1c1b  sub rsp, 0x08
000079f9de5d1c1f  push rax
000079f9de5d1c20  push rcx
000079f9de5d1c21  push rdx
000079f9de5d1c22  push rdi
000079f9de5d1c23  push rsi
000079f9de5d1c24  push r8
000079f9de5d1c26  push r9
000079f9de5d1c28  push r10
000079f9de5d1c2a  push r11
000079f9de5d1c2c  sub rsp, 0xF0
000079f9de5d1c33  vmovaps [rsp], xmm0
000079f9de5d1c38  vmovaps [rsp+0x10], xmm1
000079f9de5d1c3e  vmovaps [rsp+0x20], xmm2
000079f9de5d1c44  vmovaps [rsp+0x30], xmm3
000079f9de5d1c4a  vmovaps [rsp+0x40], xmm4
000079f9de5d1c50  vmovaps [rsp+0x50], xmm5
000079f9de5d1c56  vmovaps [rsp+0x60], xmm6
000079f9de5d1c5c  vmovaps [rsp+0x70], xmm7
000079f9de5d1c62  vmovaps [rsp+0x80], xmm8
000079f9de5d1c6b  vmovaps [rsp+0x90], xmm9
000079f9de5d1c74  vmovaps [rsp+0xA0], xmm10
000079f9de5d1c7d  vmovaps [rsp+0xB0], xmm11
000079f9de5d1c86  vmovaps [rsp+0xC0], xmm12
000079f9de5d1c8f  vmovaps [rsp+0xD0], xmm13
000079f9de5d1c98  vmovaps [rsp+0xE0], xmm14
000079f9de5d1ca1  sub rsp, 0x30
000079f9de5d1ca5  movaps [rsp], xmm15
000079f9de5d1caa  movaps [rsp+0x10], xmm13
000079f9de5d1cb0  movaps [rsp+0x20], xmm1
000079f9de5d1cb5  lea rdi, [rsp]
000079f9de5d1cb9  mov esi, 0x00
000079f9de5d1cbe  mov rax, 0x56D56FF59530
000079f9de5d1cc8  call rax
000079f9de5d1cca  movaps xmm15, [rsp]
000079f9de5d1ccf  add rsp, 0x30
000079f9de5d1cd3  vmovaps xmm0, [rsp]
000079f9de5d1cd8  vmovaps xmm1, [rsp+0x10]
000079f9de5d1cde  vmovaps xmm2, [rsp+0x20]
000079f9de5d1ce4  vmovaps xmm3, [rsp+0x30]
000079f9de5d1cea  vmovaps xmm4, [rsp+0x40]
000079f9de5d1cf0  vmovaps xmm5, [rsp+0x50]
000079f9de5d1cf6  vmovaps xmm6, [rsp+0x60]
000079f9de5d1cfc  vmovaps xmm7, [rsp+0x70]
000079f9de5d1d02  vmovaps xmm8, [rsp+0x80]
000079f9de5d1d0b  vmovaps xmm9, [rsp+0x90]
000079f9de5d1d14  vmovaps xmm10, [rsp+0xA0]
000079f9de5d1d1d  vmovaps xmm11, [rsp+0xB0]
000079f9de5d1d26  vmovaps xmm12, [rsp+0xC0]
000079f9de5d1d2f  vmovaps xmm13, [rsp+0xD0]
000079f9de5d1d38  vmovaps xmm14, [rsp+0xE0]
000079f9de5d1d41  add rsp, 0xF0
000079f9de5d1d48  pop r11
000079f9de5d1d4a  pop r10
000079f9de5d1d4c  pop r9
000079f9de5d1d4e  pop r8
000079f9de5d1d50  pop rsi
000079f9de5d1d51  pop rdi
000079f9de5d1d52  pop rdx
000079f9de5d1d53  pop rcx
000079f9de5d1d54  pop rax
000079f9de5d1d55  add rsp, 0x08
000079f9de5d1d59  jmp 0x000079F9DE5CFAEB
000079f9de5d1d5e  call 0x000079F9DE3FF430
000079f9de5d1d63  jmp 0x000079F9DE5CFAF8
000079f9de5d1d68  sub rsp, 0x08
000079f9de5d1d6c  push rax
000079f9de5d1d6d  push rcx
000079f9de5d1d6e  push rdx
000079f9de5d1d6f  push rdi
000079f9de5d1d70  push rsi
000079f9de5d1d71  push r8
000079f9de5d1d73  push r9
000079f9de5d1d75  push r10
000079f9de5d1d77  push r11
000079f9de5d1d79  sub rsp, 0xF0
000079f9de5d1d80  vmovaps [rsp], xmm0
000079f9de5d1d85  vmovaps [rsp+0x10], xmm1
000079f9de5d1d8b  vmovaps [rsp+0x20], xmm2
000079f9de5d1d91  vmovaps [rsp+0x30], xmm3
000079f9de5d1d97  vmovaps [rsp+0x40], xmm4
000079f9de5d1d9d  vmovaps [rsp+0x50], xmm5
000079f9de5d1da3  vmovaps [rsp+0x60], xmm6
000079f9de5d1da9  vmovaps [rsp+0x70], xmm7
000079f9de5d1daf  vmovaps [rsp+0x80], xmm8
000079f9de5d1db8  vmovaps [rsp+0x90], xmm9
000079f9de5d1dc1  vmovaps [rsp+0xA0], xmm10
000079f9de5d1dca  vmovaps [rsp+0xB0], xmm11
000079f9de5d1dd3  vmovaps [rsp+0xC0], xmm12
000079f9de5d1ddc  vmovaps [rsp+0xD0], xmm13
000079f9de5d1de5  vmovaps [rsp+0xE0], xmm15
000079f9de5d1dee  sub rsp, 0x30
000079f9de5d1df2  movaps [rsp], xmm14
000079f9de5d1df7  movaps [rsp+0x10], xmm13
000079f9de5d1dfd  movaps [rsp+0x20], xmm2
000079f9de5d1e02  lea rdi, [rsp]
000079f9de5d1e06  mov esi, 0x00
000079f9de5d1e0b  mov rax, 0x56D56FF59530
000079f9de5d1e15  call rax
000079f9de5d1e17  movaps xmm14, [rsp]
000079f9de5d1e1c  add rsp, 0x30
000079f9de5d1e20  vmovaps xmm0, [rsp]
000079f9de5d1e25  vmovaps xmm1, [rsp+0x10]
000079f9de5d1e2b  vmovaps xmm2, [rsp+0x20]
000079f9de5d1e31  vmovaps xmm3, [rsp+0x30]
000079f9de5d1e37  vmovaps xmm4, [rsp+0x40]
000079f9de5d1e3d  vmovaps xmm5, [rsp+0x50]
000079f9de5d1e43  vmovaps xmm6, [rsp+0x60]
000079f9de5d1e49  vmovaps xmm7, [rsp+0x70]
000079f9de5d1e4f  vmovaps xmm8, [rsp+0x80]
000079f9de5d1e58  vmovaps xmm9, [rsp+0x90]
000079f9de5d1e61  vmovaps xmm10, [rsp+0xA0]
000079f9de5d1e6a  vmovaps xmm11, [rsp+0xB0]
000079f9de5d1e73  vmovaps xmm12, [rsp+0xC0]
000079f9de5d1e7c  vmovaps xmm13, [rsp+0xD0]
000079f9de5d1e85  vmovaps xmm15, [rsp+0xE0]
000079f9de5d1e8e  add rsp, 0xF0
000079f9de5d1e95  pop r11
000079f9de5d1e97  pop r10
000079f9de5d1e99  pop r9
000079f9de5d1e9b  pop r8
000079f9de5d1e9d  pop rsi
000079f9de5d1e9e  pop rdi
000079f9de5d1e9f  pop rdx
000079f9de5d1ea0  pop rcx
000079f9de5d1ea1  pop rax
000079f9de5d1ea2  add rsp, 0x08
000079f9de5d1ea6  jmp 0x000079F9DE5CFB24
000079f9de5d1eab  sub rsp, 0x08
000079f9de5d1eaf  push rax
000079f9de5d1eb0  push rcx
000079f9de5d1eb1  push rdx
000079f9de5d1eb2  push rdi
000079f9de5d1eb3  push rsi
000079f9de5d1eb4  push r8
000079f9de5d1eb6  push r9
000079f9de5d1eb8  push r10
000079f9de5d1eba  push r11
000079f9de5d1ebc  sub rsp, 0xF0
000079f9de5d1ec3  vmovaps [rsp], xmm0
000079f9de5d1ec8  vmovaps [rsp+0x10], xmm2
000079f9de5d1ece  vmovaps [rsp+0x20], xmm3
000079f9de5d1ed4  vmovaps [rsp+0x30], xmm4
000079f9de5d1eda  vmovaps [rsp+0x40], xmm5
000079f9de5d1ee0  vmovaps [rsp+0x50], xmm6
000079f9de5d1ee6  vmovaps [rsp+0x60], xmm7
000079f9de5d1eec  vmovaps [rsp+0x70], xmm8
000079f9de5d1ef2  vmovaps [rsp+0x80], xmm9
000079f9de5d1efb  vmovaps [rsp+0x90], xmm10
000079f9de5d1f04  vmovaps [rsp+0xA0], xmm11
000079f9de5d1f0d  vmovaps [rsp+0xB0], xmm12
000079f9de5d1f16  vmovaps [rsp+0xC0], xmm13
000079f9de5d1f1f  vmovaps [rsp+0xD0], xmm14
000079f9de5d1f28  vmovaps [rsp+0xE0], xmm15
000079f9de5d1f31  sub rsp, 0x30
000079f9de5d1f35  movaps [rsp], xmm1
000079f9de5d1f39  movaps [rsp+0x10], xmm13
000079f9de5d1f3f  movaps [rsp+0x20], xmm2
000079f9de5d1f44  lea rdi, [rsp]
000079f9de5d1f48  mov esi, 0x00
000079f9de5d1f4d  mov rax, 0x56D56FF59530
000079f9de5d1f57  call rax
000079f9de5d1f59  movaps xmm1, [rsp]
000079f9de5d1f5d  add rsp, 0x30
000079f9de5d1f61  vmovaps xmm0, [rsp]
000079f9de5d1f66  vmovaps xmm2, [rsp+0x10]
000079f9de5d1f6c  vmovaps xmm3, [rsp+0x20]
000079f9de5d1f72  vmovaps xmm4, [rsp+0x30]
000079f9de5d1f78  vmovaps xmm5, [rsp+0x40]
000079f9de5d1f7e  vmovaps xmm6, [rsp+0x50]
000079f9de5d1f84  vmovaps xmm7, [rsp+0x60]
000079f9de5d1f8a  vmovaps xmm8, [rsp+0x70]
000079f9de5d1f90  vmovaps xmm9, [rsp+0x80]
000079f9de5d1f99  vmovaps xmm10, [rsp+0x90]
000079f9de5d1fa2  vmovaps xmm11, [rsp+0xA0]
000079f9de5d1fab  vmovaps xmm12, [rsp+0xB0]
000079f9de5d1fb4  vmovaps xmm13, [rsp+0xC0]
000079f9de5d1fbd  vmovaps xmm14, [rsp+0xD0]
000079f9de5d1fc6  vmovaps xmm15, [rsp+0xE0]
000079f9de5d1fcf  add rsp, 0xF0
000079f9de5d1fd6  pop r11
000079f9de5d1fd8  pop r10
000079f9de5d1fda  pop r9
000079f9de5d1fdc  pop r8
000079f9de5d1fde  pop rsi
000079f9de5d1fdf  pop rdi
000079f9de5d1fe0  pop rdx
000079f9de5d1fe1  pop rcx
000079f9de5d1fe2  pop rax
000079f9de5d1fe3  add rsp, 0x08
000079f9de5d1fe7  jmp 0x000079F9DE5CFB52
000079f9de5d1fec  sub rsp, 0x08
000079f9de5d1ff0  push rax
000079f9de5d1ff1  push rcx
000079f9de5d1ff2  push rdx
000079f9de5d1ff3  push rdi
000079f9de5d1ff4  push rsi
000079f9de5d1ff5  push r8
000079f9de5d1ff7  push r9
000079f9de5d1ff9  push r10
000079f9de5d1ffb  push r11
000079f9de5d1ffd  sub rsp, 0xF0
000079f9de5d2004  vmovaps [rsp], xmm0
000079f9de5d2009  vmovaps [rsp+0x10], xmm1
000079f9de5d200f  vmovaps [rsp+0x20], xmm3
000079f9de5d2015  vmovaps [rsp+0x30], xmm4
000079f9de5d201b  vmovaps [rsp+0x40], xmm5
000079f9de5d2021  vmovaps [rsp+0x50], xmm6
000079f9de5d2027  vmovaps [rsp+0x60], xmm7
000079f9de5d202d  vmovaps [rsp+0x70], xmm8
000079f9de5d2033  vmovaps [rsp+0x80], xmm9
000079f9de5d203c  vmovaps [rsp+0x90], xmm10
000079f9de5d2045  vmovaps [rsp+0xA0], xmm11
000079f9de5d204e  vmovaps [rsp+0xB0], xmm12
000079f9de5d2057  vmovaps [rsp+0xC0], xmm13
000079f9de5d2060  vmovaps [rsp+0xD0], xmm14
000079f9de5d2069  vmovaps [rsp+0xE0], xmm15
000079f9de5d2072  sub rsp, 0x30
000079f9de5d2076  movaps [rsp], xmm2
000079f9de5d207a  movaps [rsp+0x10], xmm1
000079f9de5d207f  movaps [rsp+0x20], xmm13
000079f9de5d2085  lea rdi, [rsp]
000079f9de5d2089  mov esi, 0x00
000079f9de5d208e  mov rax, 0x56D56FF59530
000079f9de5d2098  call rax
000079f9de5d209a  movaps xmm2, [rsp]
000079f9de5d209e  add rsp, 0x30
000079f9de5d20a2  vmovaps xmm0, [rsp]
000079f9de5d20a7  vmovaps xmm1, [rsp+0x10]
000079f9de5d20ad  vmovaps xmm3, [rsp+0x20]
000079f9de5d20b3  vmovaps xmm4, [rsp+0x30]
000079f9de5d20b9  vmovaps xmm5, [rsp+0x40]
000079f9de5d20bf  vmovaps xmm6, [rsp+0x50]
000079f9de5d20c5  vmovaps xmm7, [rsp+0x60]
000079f9de5d20cb  vmovaps xmm8, [rsp+0x70]
000079f9de5d20d1  vmovaps xmm9, [rsp+0x80]
000079f9de5d20da  vmovaps xmm10, [rsp+0x90]
000079f9de5d20e3  vmovaps xmm11, [rsp+0xA0]
000079f9de5d20ec  vmovaps xmm12, [rsp+0xB0]
000079f9de5d20f5  vmovaps xmm13, [rsp+0xC0]
000079f9de5d20fe  vmovaps xmm14, [rsp+0xD0]
000079f9de5d2107  vmovaps xmm15, [rsp+0xE0]
000079f9de5d2110  add rsp, 0xF0
000079f9de5d2117  pop r11
000079f9de5d2119  pop r10
000079f9de5d211b  pop r9
000079f9de5d211d  pop r8
000079f9de5d211f  pop rsi
000079f9de5d2120  pop rdi
000079f9de5d2121  pop rdx
000079f9de5d2122  pop rcx
000079f9de5d2123  pop rax
000079f9de5d2124  add rsp, 0x08
000079f9de5d2128  jmp 0x000079F9DE5CFBAB
000079f9de5d212d  call 0x000079F9DE3FF430
000079f9de5d2132  jmp 0x000079F9DE5CFBB8
000079f9de5d2137  sub rsp, 0x08
000079f9de5d213b  push rax
000079f9de5d213c  push rcx
000079f9de5d213d  push rdx
000079f9de5d213e  push rdi
000079f9de5d213f  push rsi
000079f9de5d2140  push r8
000079f9de5d2142  push r9
000079f9de5d2144  push r10
000079f9de5d2146  push r11
000079f9de5d2148  sub rsp, 0xF0
000079f9de5d214f  vmovaps [rsp], xmm0
000079f9de5d2154  vmovaps [rsp+0x10], xmm1
000079f9de5d215a  vmovaps [rsp+0x20], xmm2
000079f9de5d2160  vmovaps [rsp+0x30], xmm3
000079f9de5d2166  vmovaps [rsp+0x40], xmm4
000079f9de5d216c  vmovaps [rsp+0x50], xmm5
000079f9de5d2172  vmovaps [rsp+0x60], xmm6
000079f9de5d2178  vmovaps [rsp+0x70], xmm7
000079f9de5d217e  vmovaps [rsp+0x80], xmm8
000079f9de5d2187  vmovaps [rsp+0x90], xmm9
000079f9de5d2190  vmovaps [rsp+0xA0], xmm10
000079f9de5d2199  vmovaps [rsp+0xB0], xmm11
000079f9de5d21a2  vmovaps [rsp+0xC0], xmm12
000079f9de5d21ab  vmovaps [rsp+0xD0], xmm13
000079f9de5d21b4  vmovaps [rsp+0xE0], xmm14
000079f9de5d21bd  sub rsp, 0x30
000079f9de5d21c1  movaps [rsp], xmm15
000079f9de5d21c6  movaps [rsp+0x10], xmm13
000079f9de5d21cc  movaps [rsp+0x20], xmm1
000079f9de5d21d1  lea rdi, [rsp]
000079f9de5d21d5  mov esi, 0x00
000079f9de5d21da  mov rax, 0x56D56FF59530
000079f9de5d21e4  call rax
000079f9de5d21e6  movaps xmm15, [rsp]
000079f9de5d21eb  add rsp, 0x30
000079f9de5d21ef  vmovaps xmm0, [rsp]
000079f9de5d21f4  vmovaps xmm1, [rsp+0x10]
000079f9de5d21fa  vmovaps xmm2, [rsp+0x20]
000079f9de5d2200  vmovaps xmm3, [rsp+0x30]
000079f9de5d2206  vmovaps xmm4, [rsp+0x40]
000079f9de5d220c  vmovaps xmm5, [rsp+0x50]
000079f9de5d2212  vmovaps xmm6, [rsp+0x60]
000079f9de5d2218  vmovaps xmm7, [rsp+0x70]
000079f9de5d221e  vmovaps xmm8, [rsp+0x80]
000079f9de5d2227  vmovaps xmm9, [rsp+0x90]
000079f9de5d2230  vmovaps xmm10, [rsp+0xA0]
000079f9de5d2239  vmovaps xmm11, [rsp+0xB0]
000079f9de5d2242  vmovaps xmm12, [rsp+0xC0]
000079f9de5d224b  vmovaps xmm13, [rsp+0xD0]
000079f9de5d2254  vmovaps xmm14, [rsp+0xE0]
000079f9de5d225d  add rsp, 0xF0
000079f9de5d2264  pop r11
000079f9de5d2266  pop r10
000079f9de5d2268  pop r9
000079f9de5d226a  pop r8
000079f9de5d226c  pop rsi
000079f9de5d226d  pop rdi
000079f9de5d226e  pop rdx
000079f9de5d226f  pop rcx
000079f9de5d2270  pop rax
000079f9de5d2271  add rsp, 0x08
000079f9de5d2275  jmp 0x000079F9DE5CFBF7
000079f9de5d227a  sub rsp, 0x08
000079f9de5d227e  push rax
000079f9de5d227f  push rcx
000079f9de5d2280  push rdx
000079f9de5d2281  push rdi
000079f9de5d2282  push rsi
000079f9de5d2283  push r8
000079f9de5d2285  push r9
000079f9de5d2287  push r10
000079f9de5d2289  push r11
000079f9de5d228b  sub rsp, 0xF0
000079f9de5d2292  vmovaps [rsp], xmm0
000079f9de5d2297  vmovaps [rsp+0x10], xmm1
000079f9de5d229d  vmovaps [rsp+0x20], xmm2
000079f9de5d22a3  vmovaps [rsp+0x30], xmm3
000079f9de5d22a9  vmovaps [rsp+0x40], xmm4
000079f9de5d22af  vmovaps [rsp+0x50], xmm5
000079f9de5d22b5  vmovaps [rsp+0x60], xmm6
000079f9de5d22bb  vmovaps [rsp+0x70], xmm7
000079f9de5d22c1  vmovaps [rsp+0x80], xmm8
000079f9de5d22ca  vmovaps [rsp+0x90], xmm9
000079f9de5d22d3  vmovaps [rsp+0xA0], xmm10
000079f9de5d22dc  vmovaps [rsp+0xB0], xmm11
000079f9de5d22e5  vmovaps [rsp+0xC0], xmm12
000079f9de5d22ee  vmovaps [rsp+0xD0], xmm13
000079f9de5d22f7  vmovaps [rsp+0xE0], xmm15
000079f9de5d2300  sub rsp, 0x30
000079f9de5d2304  movaps [rsp], xmm14
000079f9de5d2309  movaps [rsp+0x10], xmm11
000079f9de5d230f  movaps [rsp+0x20], xmm1
000079f9de5d2314  lea rdi, [rsp]
000079f9de5d2318  mov esi, 0x00
000079f9de5d231d  mov rax, 0x56D56FF59530
000079f9de5d2327  call rax
000079f9de5d2329  movaps xmm14, [rsp]
000079f9de5d232e  add rsp, 0x30
000079f9de5d2332  vmovaps xmm0, [rsp]
000079f9de5d2337  vmovaps xmm1, [rsp+0x10]
000079f9de5d233d  vmovaps xmm2, [rsp+0x20]
000079f9de5d2343  vmovaps xmm3, [rsp+0x30]
000079f9de5d2349  vmovaps xmm4, [rsp+0x40]
000079f9de5d234f  vmovaps xmm5, [rsp+0x50]
000079f9de5d2355  vmovaps xmm6, [rsp+0x60]
000079f9de5d235b  vmovaps xmm7, [rsp+0x70]
000079f9de5d2361  vmovaps xmm8, [rsp+0x80]
000079f9de5d236a  vmovaps xmm9, [rsp+0x90]
000079f9de5d2373  vmovaps xmm10, [rsp+0xA0]
000079f9de5d237c  vmovaps xmm11, [rsp+0xB0]
000079f9de5d2385  vmovaps xmm12, [rsp+0xC0]
000079f9de5d238e  vmovaps xmm13, [rsp+0xD0]
000079f9de5d2397  vmovaps xmm15, [rsp+0xE0]
000079f9de5d23a0  add rsp, 0xF0
000079f9de5d23a7  pop r11
000079f9de5d23a9  pop r10
000079f9de5d23ab  pop r9
000079f9de5d23ad  pop r8
000079f9de5d23af  pop rsi
000079f9de5d23b0  pop rdi
000079f9de5d23b1  pop rdx
000079f9de5d23b2  pop rcx
000079f9de5d23b3  pop rax
000079f9de5d23b4  add rsp, 0x08
000079f9de5d23b8  jmp 0x000079F9DE5CFC21
000079f9de5d23bd  sub rsp, 0x08
000079f9de5d23c1  push rax
000079f9de5d23c2  push rcx
000079f9de5d23c3  push rdx
000079f9de5d23c4  push rdi
000079f9de5d23c5  push rsi
000079f9de5d23c6  push r8
000079f9de5d23c8  push r9
000079f9de5d23ca  push r10
000079f9de5d23cc  push r11
000079f9de5d23ce  sub rsp, 0xF0
000079f9de5d23d5  vmovaps [rsp], xmm0
000079f9de5d23da  vmovaps [rsp+0x10], xmm1
000079f9de5d23e0  vmovaps [rsp+0x20], xmm2
000079f9de5d23e6  vmovaps [rsp+0x30], xmm3
000079f9de5d23ec  vmovaps [rsp+0x40], xmm4
000079f9de5d23f2  vmovaps [rsp+0x50], xmm5
000079f9de5d23f8  vmovaps [rsp+0x60], xmm6
000079f9de5d23fe  vmovaps [rsp+0x70], xmm7
000079f9de5d2404  vmovaps [rsp+0x80], xmm8
000079f9de5d240d  vmovaps [rsp+0x90], xmm9
000079f9de5d2416  vmovaps [rsp+0xA0], xmm10
000079f9de5d241f  vmovaps [rsp+0xB0], xmm11
000079f9de5d2428  vmovaps [rsp+0xC0], xmm12
000079f9de5d2431  vmovaps [rsp+0xD0], xmm14
000079f9de5d243a  vmovaps [rsp+0xE0], xmm15
000079f9de5d2443  sub rsp, 0x30
000079f9de5d2447  movaps [rsp], xmm13
000079f9de5d244c  movaps [rsp+0x10], xmm11
000079f9de5d2452  movaps [rsp+0x20], xmm1
000079f9de5d2457  lea rdi, [rsp]
000079f9de5d245b  mov esi, 0x00
000079f9de5d2460  mov rax, 0x56D56FF59530
000079f9de5d246a  call rax
000079f9de5d246c  movaps xmm13, [rsp]
000079f9de5d2471  add rsp, 0x30
000079f9de5d2475  vmovaps xmm0, [rsp]
000079f9de5d247a  vmovaps xmm1, [rsp+0x10]
000079f9de5d2480  vmovaps xmm2, [rsp+0x20]
000079f9de5d2486  vmovaps xmm3, [rsp+0x30]
000079f9de5d248c  vmovaps xmm4, [rsp+0x40]
000079f9de5d2492  vmovaps xmm5, [rsp+0x50]
000079f9de5d2498  vmovaps xmm6, [rsp+0x60]
000079f9de5d249e  vmovaps xmm7, [rsp+0x70]
000079f9de5d24a4  vmovaps xmm8, [rsp+0x80]
000079f9de5d24ad  vmovaps xmm9, [rsp+0x90]
000079f9de5d24b6  vmovaps xmm10, [rsp+0xA0]
000079f9de5d24bf  vmovaps xmm11, [rsp+0xB0]
000079f9de5d24c8  vmovaps xmm12, [rsp+0xC0]
000079f9de5d24d1  vmovaps xmm14, [rsp+0xD0]
000079f9de5d24da  vmovaps xmm15, [rsp+0xE0]
000079f9de5d24e3  add rsp, 0xF0
000079f9de5d24ea  pop r11
000079f9de5d24ec  pop r10
000079f9de5d24ee  pop r9
000079f9de5d24f0  pop r8
000079f9de5d24f2  pop rsi
000079f9de5d24f3  pop rdi
000079f9de5d24f4  pop rdx
000079f9de5d24f5  pop rcx
000079f9de5d24f6  pop rax
000079f9de5d24f7  add rsp, 0x08
000079f9de5d24fb  jmp 0x000079F9DE5CFC76
000079f9de5d2500  call 0x000079F9DE3FF430
000079f9de5d2505  jmp 0x000079F9DE5CFC83
000079f9de5d250a  sub rsp, 0x08
000079f9de5d250e  push rax
000079f9de5d250f  push rcx
000079f9de5d2510  push rdx
000079f9de5d2511  push rdi
000079f9de5d2512  push rsi
000079f9de5d2513  push r8
000079f9de5d2515  push r9
000079f9de5d2517  push r10
000079f9de5d2519  push r11
000079f9de5d251b  sub rsp, 0xF0
000079f9de5d2522  vmovaps [rsp], xmm0
000079f9de5d2527  vmovaps [rsp+0x10], xmm1
000079f9de5d252d  vmovaps [rsp+0x20], xmm2
000079f9de5d2533  vmovaps [rsp+0x30], xmm3
000079f9de5d2539  vmovaps [rsp+0x40], xmm4
000079f9de5d253f  vmovaps [rsp+0x50], xmm5
000079f9de5d2545  vmovaps [rsp+0x60], xmm6
000079f9de5d254b  vmovaps [rsp+0x70], xmm7
000079f9de5d2551  vmovaps [rsp+0x80], xmm8
000079f9de5d255a  vmovaps [rsp+0x90], xmm9
000079f9de5d2563  vmovaps [rsp+0xA0], xmm10
000079f9de5d256c  vmovaps [rsp+0xB0], xmm11
000079f9de5d2575  vmovaps [rsp+0xC0], xmm12
000079f9de5d257e  vmovaps [rsp+0xD0], xmm13
000079f9de5d2587  vmovaps [rsp+0xE0], xmm14
000079f9de5d2590  sub rsp, 0x30
000079f9de5d2594  movaps [rsp], xmm15
000079f9de5d2599  movaps [rsp+0x10], xmm11
000079f9de5d259f  movaps [rsp+0x20], xmm1
000079f9de5d25a4  lea rdi, [rsp]
000079f9de5d25a8  mov esi, 0x00
000079f9de5d25ad  mov rax, 0x56D56FF59530
000079f9de5d25b7  call rax
000079f9de5d25b9  movaps xmm15, [rsp]
000079f9de5d25be  add rsp, 0x30
000079f9de5d25c2  vmovaps xmm0, [rsp]
000079f9de5d25c7  vmovaps xmm1, [rsp+0x10]
000079f9de5d25cd  vmovaps xmm2, [rsp+0x20]
000079f9de5d25d3  vmovaps xmm3, [rsp+0x30]
000079f9de5d25d9  vmovaps xmm4, [rsp+0x40]
000079f9de5d25df  vmovaps xmm5, [rsp+0x50]
000079f9de5d25e5  vmovaps xmm6, [rsp+0x60]
000079f9de5d25eb  vmovaps xmm7, [rsp+0x70]
000079f9de5d25f1  vmovaps xmm8, [rsp+0x80]
000079f9de5d25fa  vmovaps xmm9, [rsp+0x90]
000079f9de5d2603  vmovaps xmm10, [rsp+0xA0]
000079f9de5d260c  vmovaps xmm11, [rsp+0xB0]
000079f9de5d2615  vmovaps xmm12, [rsp+0xC0]
000079f9de5d261e  vmovaps xmm13, [rsp+0xD0]
000079f9de5d2627  vmovaps xmm14, [rsp+0xE0]
000079f9de5d2630  add rsp, 0xF0
000079f9de5d2637  pop r11
000079f9de5d2639  pop r10
000079f9de5d263b  pop r9
000079f9de5d263d  pop r8
000079f9de5d263f  pop rsi
000079f9de5d2640  pop rdi
000079f9de5d2641  pop rdx
000079f9de5d2642  pop rcx
000079f9de5d2643  pop rax
000079f9de5d2644  add rsp, 0x08
000079f9de5d2648  jmp 0x000079F9DE5CFCBC
000079f9de5d264d  sub rsp, 0x08
000079f9de5d2651  push rax
000079f9de5d2652  push rcx
000079f9de5d2653  push rdx
000079f9de5d2654  push rdi
000079f9de5d2655  push rsi
000079f9de5d2656  push r8
000079f9de5d2658  push r9
000079f9de5d265a  push r10
000079f9de5d265c  push r11
000079f9de5d265e  sub rsp, 0xF0
000079f9de5d2665  vmovaps [rsp], xmm0
000079f9de5d266a  vmovaps [rsp+0x10], xmm1
000079f9de5d2670  vmovaps [rsp+0x20], xmm2
000079f9de5d2676  vmovaps [rsp+0x30], xmm3
000079f9de5d267c  vmovaps [rsp+0x40], xmm4
000079f9de5d2682  vmovaps [rsp+0x50], xmm5
000079f9de5d2688  vmovaps [rsp+0x60], xmm6
000079f9de5d268e  vmovaps [rsp+0x70], xmm7
000079f9de5d2694  vmovaps [rsp+0x80], xmm8
000079f9de5d269d  vmovaps [rsp+0x90], xmm9
000079f9de5d26a6  vmovaps [rsp+0xA0], xmm10
000079f9de5d26af  vmovaps [rsp+0xB0], xmm12
000079f9de5d26b8  vmovaps [rsp+0xC0], xmm13
000079f9de5d26c1  vmovaps [rsp+0xD0], xmm14
000079f9de5d26ca  vmovaps [rsp+0xE0], xmm15
000079f9de5d26d3  sub rsp, 0x30
000079f9de5d26d7  movaps [rsp], xmm11
000079f9de5d26dc  movaps [rsp+0x10], xmm6
000079f9de5d26e1  movaps [rsp+0x20], xmm14
000079f9de5d26e7  lea rdi, [rsp]
000079f9de5d26eb  mov esi, 0x00
000079f9de5d26f0  mov rax, 0x56D56FF59530
000079f9de5d26fa  call rax
000079f9de5d26fc  movaps xmm11, [rsp]
000079f9de5d2701  add rsp, 0x30
000079f9de5d2705  vmovaps xmm0, [rsp]
000079f9de5d270a  vmovaps xmm1, [rsp+0x10]
000079f9de5d2710  vmovaps xmm2, [rsp+0x20]
000079f9de5d2716  vmovaps xmm3, [rsp+0x30]
000079f9de5d271c  vmovaps xmm4, [rsp+0x40]
000079f9de5d2722  vmovaps xmm5, [rsp+0x50]
000079f9de5d2728  vmovaps xmm6, [rsp+0x60]
000079f9de5d272e  vmovaps xmm7, [rsp+0x70]
000079f9de5d2734  vmovaps xmm8, [rsp+0x80]
000079f9de5d273d  vmovaps xmm9, [rsp+0x90]
000079f9de5d2746  vmovaps xmm10, [rsp+0xA0]
000079f9de5d274f  vmovaps xmm12, [rsp+0xB0]
000079f9de5d2758  vmovaps xmm13, [rsp+0xC0]
000079f9de5d2761  vmovaps xmm14, [rsp+0xD0]
000079f9de5d276a  vmovaps xmm15, [rsp+0xE0]
000079f9de5d2773  add rsp, 0xF0
000079f9de5d277a  pop r11
000079f9de5d277c  pop r10
000079f9de5d277e  pop r9
000079f9de5d2780  pop r8
000079f9de5d2782  pop rsi
000079f9de5d2783  pop rdi
000079f9de5d2784  pop rdx
000079f9de5d2785  pop rcx
000079f9de5d2786  pop rax
000079f9de5d2787  add rsp, 0x08
000079f9de5d278b  jmp 0x000079F9DE5CFD34
000079f9de5d2790  call 0x000079F9DE3FF430
000079f9de5d2795  jmp 0x000079F9DE5CFD3E
000079f9de5d279a  sub rsp, 0x08
000079f9de5d279e  push rax
000079f9de5d279f  push rcx
000079f9de5d27a0  push rdx
000079f9de5d27a1  push rdi
000079f9de5d27a2  push rsi
000079f9de5d27a3  push r8
000079f9de5d27a5  push r9
000079f9de5d27a7  push r10
000079f9de5d27a9  push r11
000079f9de5d27ab  sub rsp, 0xF0
000079f9de5d27b2  vmovaps [rsp], xmm0
000079f9de5d27b7  vmovaps [rsp+0x10], xmm1
000079f9de5d27bd  vmovaps [rsp+0x20], xmm2
000079f9de5d27c3  vmovaps [rsp+0x30], xmm3
000079f9de5d27c9  vmovaps [rsp+0x40], xmm4
000079f9de5d27cf  vmovaps [rsp+0x50], xmm5
000079f9de5d27d5  vmovaps [rsp+0x60], xmm6
000079f9de5d27db  vmovaps [rsp+0x70], xmm7
000079f9de5d27e1  vmovaps [rsp+0x80], xmm8
000079f9de5d27ea  vmovaps [rsp+0x90], xmm9
000079f9de5d27f3  vmovaps [rsp+0xA0], xmm10
000079f9de5d27fc  vmovaps [rsp+0xB0], xmm11
000079f9de5d2805  vmovaps [rsp+0xC0], xmm12
000079f9de5d280e  vmovaps [rsp+0xD0], xmm13
000079f9de5d2817  vmovaps [rsp+0xE0], xmm15
000079f9de5d2820  sub rsp, 0x30
000079f9de5d2824  movaps [rsp], xmm14
000079f9de5d2829  movaps [rsp+0x10], xmm6
000079f9de5d282e  movaps [rsp+0x20], xmm2
000079f9de5d2833  lea rdi, [rsp]
000079f9de5d2837  mov esi, 0x00
000079f9de5d283c  mov rax, 0x56D56FF59530
000079f9de5d2846  call rax
000079f9de5d2848  movaps xmm14, [rsp]
000079f9de5d284d  add rsp, 0x30
000079f9de5d2851  vmovaps xmm0, [rsp]
000079f9de5d2856  vmovaps xmm1, [rsp+0x10]
000079f9de5d285c  vmovaps xmm2, [rsp+0x20]
000079f9de5d2862  vmovaps xmm3, [rsp+0x30]
000079f9de5d2868  vmovaps xmm4, [rsp+0x40]
000079f9de5d286e  vmovaps xmm5, [rsp+0x50]
000079f9de5d2874  vmovaps xmm6, [rsp+0x60]
000079f9de5d287a  vmovaps xmm7, [rsp+0x70]
000079f9de5d2880  vmovaps xmm8, [rsp+0x80]
000079f9de5d2889  vmovaps xmm9, [rsp+0x90]
000079f9de5d2892  vmovaps xmm10, [rsp+0xA0]
000079f9de5d289b  vmovaps xmm11, [rsp+0xB0]
000079f9de5d28a4  vmovaps xmm12, [rsp+0xC0]
000079f9de5d28ad  vmovaps xmm13, [rsp+0xD0]
000079f9de5d28b6  vmovaps xmm15, [rsp+0xE0]
000079f9de5d28bf  add rsp, 0xF0
000079f9de5d28c6  pop r11
000079f9de5d28c8  pop r10
000079f9de5d28ca  pop r9
000079f9de5d28cc  pop r8
000079f9de5d28ce  pop rsi
000079f9de5d28cf  pop rdi
000079f9de5d28d0  pop rdx
000079f9de5d28d1  pop rcx
000079f9de5d28d2  pop rax
000079f9de5d28d3  add rsp, 0x08
000079f9de5d28d7  jmp 0x000079F9DE5CFD72
000079f9de5d28dc  sub rsp, 0x08
000079f9de5d28e0  push rax
000079f9de5d28e1  push rcx
000079f9de5d28e2  push rdx
000079f9de5d28e3  push rdi
000079f9de5d28e4  push rsi
000079f9de5d28e5  push r8
000079f9de5d28e7  push r9
000079f9de5d28e9  push r10
000079f9de5d28eb  push r11
000079f9de5d28ed  sub rsp, 0xF0
000079f9de5d28f4  vmovaps [rsp], xmm0
000079f9de5d28f9  vmovaps [rsp+0x10], xmm1
000079f9de5d28ff  vmovaps [rsp+0x20], xmm2
000079f9de5d2905  vmovaps [rsp+0x30], xmm3
000079f9de5d290b  vmovaps [rsp+0x40], xmm4
000079f9de5d2911  vmovaps [rsp+0x50], xmm5
000079f9de5d2917  vmovaps [rsp+0x60], xmm7
000079f9de5d291d  vmovaps [rsp+0x70], xmm8
000079f9de5d2923  vmovaps [rsp+0x80], xmm9
000079f9de5d292c  vmovaps [rsp+0x90], xmm10
000079f9de5d2935  vmovaps [rsp+0xA0], xmm11
000079f9de5d293e  vmovaps [rsp+0xB0], xmm12
000079f9de5d2947  vmovaps [rsp+0xC0], xmm13
000079f9de5d2950  vmovaps [rsp+0xD0], xmm14
000079f9de5d2959  vmovaps [rsp+0xE0], xmm15
000079f9de5d2962  sub rsp, 0x30
000079f9de5d2966  movaps [rsp], xmm6
000079f9de5d296a  movaps [rsp+0x10], xmm5
000079f9de5d296f  movaps [rsp+0x20], xmm1
000079f9de5d2974  lea rdi, [rsp]
000079f9de5d2978  mov esi, 0x00
000079f9de5d297d  mov rax, 0x56D56FF59530
000079f9de5d2987  call rax
000079f9de5d2989  movaps xmm6, [rsp]
000079f9de5d298d  add rsp, 0x30
000079f9de5d2991  vmovaps xmm0, [rsp]
000079f9de5d2996  vmovaps xmm1, [rsp+0x10]
000079f9de5d299c  vmovaps xmm2, [rsp+0x20]
000079f9de5d29a2  vmovaps xmm3, [rsp+0x30]
000079f9de5d29a8  vmovaps xmm4, [rsp+0x40]
000079f9de5d29ae  vmovaps xmm5, [rsp+0x50]
000079f9de5d29b4  vmovaps xmm7, [rsp+0x60]
000079f9de5d29ba  vmovaps xmm8, [rsp+0x70]
000079f9de5d29c0  vmovaps xmm9, [rsp+0x80]
000079f9de5d29c9  vmovaps xmm10, [rsp+0x90]
000079f9de5d29d2  vmovaps xmm11, [rsp+0xA0]
000079f9de5d29db  vmovaps xmm12, [rsp+0xB0]
000079f9de5d29e4  vmovaps xmm13, [rsp+0xC0]
000079f9de5d29ed  vmovaps xmm14, [rsp+0xD0]
000079f9de5d29f6  vmovaps xmm15, [rsp+0xE0]
000079f9de5d29ff  add rsp, 0xF0
000079f9de5d2a06  pop r11
000079f9de5d2a08  pop r10
000079f9de5d2a0a  pop r9
000079f9de5d2a0c  pop r8
000079f9de5d2a0e  pop rsi
000079f9de5d2a0f  pop rdi
000079f9de5d2a10  pop rdx
000079f9de5d2a11  pop rcx
000079f9de5d2a12  pop rax
000079f9de5d2a13  add rsp, 0x08
000079f9de5d2a17  jmp 0x000079F9DE5CFD98
000079f9de5d2a1c  sub rsp, 0x08
000079f9de5d2a20  push rax
000079f9de5d2a21  push rcx
000079f9de5d2a22  push rdx
000079f9de5d2a23  push rdi
000079f9de5d2a24  push rsi
000079f9de5d2a25  push r8
000079f9de5d2a27  push r9
000079f9de5d2a29  push r10
000079f9de5d2a2b  push r11
000079f9de5d2a2d  sub rsp, 0xF0
000079f9de5d2a34  vmovaps [rsp], xmm0
000079f9de5d2a39  vmovaps [rsp+0x10], xmm2
000079f9de5d2a3f  vmovaps [rsp+0x20], xmm3
000079f9de5d2a45  vmovaps [rsp+0x30], xmm4
000079f9de5d2a4b  vmovaps [rsp+0x40], xmm5
000079f9de5d2a51  vmovaps [rsp+0x50], xmm6
000079f9de5d2a57  vmovaps [rsp+0x60], xmm7
000079f9de5d2a5d  vmovaps [rsp+0x70], xmm8
000079f9de5d2a63  vmovaps [rsp+0x80], xmm9
000079f9de5d2a6c  vmovaps [rsp+0x90], xmm10
000079f9de5d2a75  vmovaps [rsp+0xA0], xmm11
000079f9de5d2a7e  vmovaps [rsp+0xB0], xmm12
000079f9de5d2a87  vmovaps [rsp+0xC0], xmm13
000079f9de5d2a90  vmovaps [rsp+0xD0], xmm14
000079f9de5d2a99  vmovaps [rsp+0xE0], xmm15
000079f9de5d2aa2  sub rsp, 0x30
000079f9de5d2aa6  movaps [rsp], xmm1
000079f9de5d2aaa  movaps [rsp+0x10], xmm5
000079f9de5d2aaf  movaps [rsp+0x20], xmm13
000079f9de5d2ab5  lea rdi, [rsp]
000079f9de5d2ab9  mov esi, 0x00
000079f9de5d2abe  mov rax, 0x56D56FF59530
000079f9de5d2ac8  call rax
000079f9de5d2aca  movaps xmm1, [rsp]
000079f9de5d2ace  add rsp, 0x30
000079f9de5d2ad2  vmovaps xmm0, [rsp]
000079f9de5d2ad7  vmovaps xmm2, [rsp+0x10]
000079f9de5d2add  vmovaps xmm3, [rsp+0x20]
000079f9de5d2ae3  vmovaps xmm4, [rsp+0x30]
000079f9de5d2ae9  vmovaps xmm5, [rsp+0x40]
000079f9de5d2aef  vmovaps xmm6, [rsp+0x50]
000079f9de5d2af5  vmovaps xmm7, [rsp+0x60]
000079f9de5d2afb  vmovaps xmm8, [rsp+0x70]
000079f9de5d2b01  vmovaps xmm9, [rsp+0x80]
000079f9de5d2b0a  vmovaps xmm10, [rsp+0x90]
000079f9de5d2b13  vmovaps xmm11, [rsp+0xA0]
000079f9de5d2b1c  vmovaps xmm12, [rsp+0xB0]
000079f9de5d2b25  vmovaps xmm13, [rsp+0xC0]
000079f9de5d2b2e  vmovaps xmm14, [rsp+0xD0]
000079f9de5d2b37  vmovaps xmm15, [rsp+0xE0]
000079f9de5d2b40  add rsp, 0xF0
000079f9de5d2b47  pop r11
000079f9de5d2b49  pop r10
000079f9de5d2b4b  pop r9
000079f9de5d2b4d  pop r8
000079f9de5d2b4f  pop rsi
000079f9de5d2b50  pop rdi
000079f9de5d2b51  pop rdx
000079f9de5d2b52  pop rcx
000079f9de5d2b53  pop rax
000079f9de5d2b54  add rsp, 0x08
000079f9de5d2b58  jmp 0x000079F9DE5CFDB6
000079f9de5d2b5d  sub rsp, 0x08
000079f9de5d2b61  push rax
000079f9de5d2b62  push rcx
000079f9de5d2b63  push rdx
000079f9de5d2b64  push rdi
000079f9de5d2b65  push rsi
000079f9de5d2b66  push r8
000079f9de5d2b68  push r9
000079f9de5d2b6a  push r10
000079f9de5d2b6c  push r11
000079f9de5d2b6e  sub rsp, 0xF0
000079f9de5d2b75  vmovaps [rsp], xmm0
000079f9de5d2b7a  vmovaps [rsp+0x10], xmm1
000079f9de5d2b80  vmovaps [rsp+0x20], xmm2
000079f9de5d2b86  vmovaps [rsp+0x30], xmm3
000079f9de5d2b8c  vmovaps [rsp+0x40], xmm4
000079f9de5d2b92  vmovaps [rsp+0x50], xmm6
000079f9de5d2b98  vmovaps [rsp+0x60], xmm7
000079f9de5d2b9e  vmovaps [rsp+0x70], xmm8
000079f9de5d2ba4  vmovaps [rsp+0x80], xmm9
000079f9de5d2bad  vmovaps [rsp+0x90], xmm10
000079f9de5d2bb6  vmovaps [rsp+0xA0], xmm11
000079f9de5d2bbf  vmovaps [rsp+0xB0], xmm12
000079f9de5d2bc8  vmovaps [rsp+0xC0], xmm13
000079f9de5d2bd1  vmovaps [rsp+0xD0], xmm14
000079f9de5d2bda  vmovaps [rsp+0xE0], xmm15
000079f9de5d2be3  sub rsp, 0x30
000079f9de5d2be7  movaps [rsp], xmm5
000079f9de5d2beb  movaps [rsp+0x10], xmm2
000079f9de5d2bf0  movaps [rsp+0x20], xmm13
000079f9de5d2bf6  lea rdi, [rsp]
000079f9de5d2bfa  mov esi, 0x00
000079f9de5d2bff  mov rax, 0x56D56FF59530
000079f9de5d2c09  call rax
000079f9de5d2c0b  movaps xmm5, [rsp]
000079f9de5d2c0f  add rsp, 0x30
000079f9de5d2c13  vmovaps xmm0, [rsp]
000079f9de5d2c18  vmovaps xmm1, [rsp+0x10]
000079f9de5d2c1e  vmovaps xmm2, [rsp+0x20]
000079f9de5d2c24  vmovaps xmm3, [rsp+0x30]
000079f9de5d2c2a  vmovaps xmm4, [rsp+0x40]
000079f9de5d2c30  vmovaps xmm6, [rsp+0x50]
000079f9de5d2c36  vmovaps xmm7, [rsp+0x60]
000079f9de5d2c3c  vmovaps xmm8, [rsp+0x70]
000079f9de5d2c42  vmovaps xmm9, [rsp+0x80]
000079f9de5d2c4b  vmovaps xmm10, [rsp+0x90]
000079f9de5d2c54  vmovaps xmm11, [rsp+0xA0]
000079f9de5d2c5d  vmovaps xmm12, [rsp+0xB0]
000079f9de5d2c66  vmovaps xmm13, [rsp+0xC0]
000079f9de5d2c6f  vmovaps xmm14, [rsp+0xD0]
000079f9de5d2c78  vmovaps xmm15, [rsp+0xE0]
000079f9de5d2c81  add rsp, 0xF0
000079f9de5d2c88  pop r11
000079f9de5d2c8a  pop r10
000079f9de5d2c8c  pop r9
000079f9de5d2c8e  pop r8
000079f9de5d2c90  pop rsi
000079f9de5d2c91  pop rdi
000079f9de5d2c92  pop rdx
000079f9de5d2c93  pop rcx
000079f9de5d2c94  pop rax
000079f9de5d2c95  add rsp, 0x08
000079f9de5d2c99  jmp 0x000079F9DE5CFDEC
000079f9de5d2c9e  sub rsp, 0x08
000079f9de5d2ca2  push rax
000079f9de5d2ca3  push rcx
000079f9de5d2ca4  push rdx
000079f9de5d2ca5  push rdi
000079f9de5d2ca6  push rsi
000079f9de5d2ca7  push r8
000079f9de5d2ca9  push r9
000079f9de5d2cab  push r10
000079f9de5d2cad  push r11
000079f9de5d2caf  sub rsp, 0xF0
000079f9de5d2cb6  vmovaps [rsp], xmm0
000079f9de5d2cbb  vmovaps [rsp+0x10], xmm1
000079f9de5d2cc1  vmovaps [rsp+0x20], xmm2
000079f9de5d2cc7  vmovaps [rsp+0x30], xmm3
000079f9de5d2ccd  vmovaps [rsp+0x40], xmm4
000079f9de5d2cd3  vmovaps [rsp+0x50], xmm5
000079f9de5d2cd9  vmovaps [rsp+0x60], xmm6
000079f9de5d2cdf  vmovaps [rsp+0x70], xmm7
000079f9de5d2ce5  vmovaps [rsp+0x80], xmm8
000079f9de5d2cee  vmovaps [rsp+0x90], xmm9
000079f9de5d2cf7  vmovaps [rsp+0xA0], xmm10
000079f9de5d2d00  vmovaps [rsp+0xB0], xmm11
000079f9de5d2d09  vmovaps [rsp+0xC0], xmm12
000079f9de5d2d12  vmovaps [rsp+0xD0], xmm14
000079f9de5d2d1b  vmovaps [rsp+0xE0], xmm15
000079f9de5d2d24  sub rsp, 0x30
000079f9de5d2d28  movaps [rsp], xmm13
000079f9de5d2d2d  movaps [rsp+0x10], xmm10
000079f9de5d2d33  movaps [rsp+0x20], xmm1
000079f9de5d2d38  lea rdi, [rsp]
000079f9de5d2d3c  mov esi, 0x00
000079f9de5d2d41  mov rax, 0x56D56FF59530
000079f9de5d2d4b  call rax
000079f9de5d2d4d  movaps xmm13, [rsp]
000079f9de5d2d52  add rsp, 0x30
000079f9de5d2d56  vmovaps xmm0, [rsp]
000079f9de5d2d5b  vmovaps xmm1, [rsp+0x10]
000079f9de5d2d61  vmovaps xmm2, [rsp+0x20]
000079f9de5d2d67  vmovaps xmm3, [rsp+0x30]
000079f9de5d2d6d  vmovaps xmm4, [rsp+0x40]
000079f9de5d2d73  vmovaps xmm5, [rsp+0x50]
000079f9de5d2d79  vmovaps xmm6, [rsp+0x60]
000079f9de5d2d7f  vmovaps xmm7, [rsp+0x70]
000079f9de5d2d85  vmovaps xmm8, [rsp+0x80]
000079f9de5d2d8e  vmovaps xmm9, [rsp+0x90]
000079f9de5d2d97  vmovaps xmm10, [rsp+0xA0]
000079f9de5d2da0  vmovaps xmm11, [rsp+0xB0]
000079f9de5d2da9  vmovaps xmm12, [rsp+0xC0]
000079f9de5d2db2  vmovaps xmm14, [rsp+0xD0]
000079f9de5d2dbb  vmovaps xmm15, [rsp+0xE0]
000079f9de5d2dc4  add rsp, 0xF0
000079f9de5d2dcb  pop r11
000079f9de5d2dcd  pop r10
000079f9de5d2dcf  pop r9
000079f9de5d2dd1  pop r8
000079f9de5d2dd3  pop rsi
000079f9de5d2dd4  pop rdi
000079f9de5d2dd5  pop rdx
000079f9de5d2dd6  pop rcx
000079f9de5d2dd7  pop rax
000079f9de5d2dd8  add rsp, 0x08
000079f9de5d2ddc  jmp 0x000079F9DE5CFE15
000079f9de5d2de1  sub rsp, 0x08
000079f9de5d2de5  push rax
000079f9de5d2de6  push rcx
000079f9de5d2de7  push rdx
000079f9de5d2de8  push rdi
000079f9de5d2de9  push rsi
000079f9de5d2dea  push r8
000079f9de5d2dec  push r9
000079f9de5d2dee  push r10
000079f9de5d2df0  push r11
000079f9de5d2df2  sub rsp, 0xF0
000079f9de5d2df9  vmovaps [rsp], xmm0
000079f9de5d2dfe  vmovaps [rsp+0x10], xmm2
000079f9de5d2e04  vmovaps [rsp+0x20], xmm3
000079f9de5d2e0a  vmovaps [rsp+0x30], xmm4
000079f9de5d2e10  vmovaps [rsp+0x40], xmm5
000079f9de5d2e16  vmovaps [rsp+0x50], xmm6
000079f9de5d2e1c  vmovaps [rsp+0x60], xmm7
000079f9de5d2e22  vmovaps [rsp+0x70], xmm8
000079f9de5d2e28  vmovaps [rsp+0x80], xmm9
000079f9de5d2e31  vmovaps [rsp+0x90], xmm10
000079f9de5d2e3a  vmovaps [rsp+0xA0], xmm11
000079f9de5d2e43  vmovaps [rsp+0xB0], xmm12
000079f9de5d2e4c  vmovaps [rsp+0xC0], xmm13
000079f9de5d2e55  vmovaps [rsp+0xD0], xmm14
000079f9de5d2e5e  vmovaps [rsp+0xE0], xmm15
000079f9de5d2e67  sub rsp, 0x30
000079f9de5d2e6b  movaps [rsp], xmm1
000079f9de5d2e6f  movaps [rsp+0x10], xmm15
000079f9de5d2e75  movaps [rsp+0x20], xmm10
000079f9de5d2e7b  lea rdi, [rsp]
000079f9de5d2e7f  mov esi, 0x00
000079f9de5d2e84  mov rax, 0x56D56FF59530
000079f9de5d2e8e  call rax
000079f9de5d2e90  movaps xmm1, [rsp]
000079f9de5d2e94  add rsp, 0x30
000079f9de5d2e98  vmovaps xmm0, [rsp]
000079f9de5d2e9d  vmovaps xmm2, [rsp+0x10]
000079f9de5d2ea3  vmovaps xmm3, [rsp+0x20]
000079f9de5d2ea9  vmovaps xmm4, [rsp+0x30]
000079f9de5d2eaf  vmovaps xmm5, [rsp+0x40]
000079f9de5d2eb5  vmovaps xmm6, [rsp+0x50]
000079f9de5d2ebb  vmovaps xmm7, [rsp+0x60]
000079f9de5d2ec1  vmovaps xmm8, [rsp+0x70]
000079f9de5d2ec7  vmovaps xmm9, [rsp+0x80]
000079f9de5d2ed0  vmovaps xmm10, [rsp+0x90]
000079f9de5d2ed9  vmovaps xmm11, [rsp+0xA0]
000079f9de5d2ee2  vmovaps xmm12, [rsp+0xB0]
000079f9de5d2eeb  vmovaps xmm13, [rsp+0xC0]
000079f9de5d2ef4  vmovaps xmm14, [rsp+0xD0]
000079f9de5d2efd  vmovaps xmm15, [rsp+0xE0]
000079f9de5d2f06  add rsp, 0xF0
000079f9de5d2f0d  pop r11
000079f9de5d2f0f  pop r10
000079f9de5d2f11  pop r9
000079f9de5d2f13  pop r8
000079f9de5d2f15  pop rsi
000079f9de5d2f16  pop rdi
000079f9de5d2f17  pop rdx
000079f9de5d2f18  pop rcx
000079f9de5d2f19  pop rax
000079f9de5d2f1a  add rsp, 0x08
000079f9de5d2f1e  jmp 0x000079F9DE5CFE34
000079f9de5d2f23  sub rsp, 0x08
000079f9de5d2f27  push rax
000079f9de5d2f28  push rcx
000079f9de5d2f29  push rdx
000079f9de5d2f2a  push rdi
000079f9de5d2f2b  push rsi
000079f9de5d2f2c  push r8
000079f9de5d2f2e  push r9
000079f9de5d2f30  push r10
000079f9de5d2f32  push r11
000079f9de5d2f34  sub rsp, 0xF0
000079f9de5d2f3b  vmovaps [rsp], xmm0
000079f9de5d2f40  vmovaps [rsp+0x10], xmm1
000079f9de5d2f46  vmovaps [rsp+0x20], xmm2
000079f9de5d2f4c  vmovaps [rsp+0x30], xmm3
000079f9de5d2f52  vmovaps [rsp+0x40], xmm4
000079f9de5d2f58  vmovaps [rsp+0x50], xmm5
000079f9de5d2f5e  vmovaps [rsp+0x60], xmm6
000079f9de5d2f64  vmovaps [rsp+0x70], xmm7
000079f9de5d2f6a  vmovaps [rsp+0x80], xmm8
000079f9de5d2f73  vmovaps [rsp+0x90], xmm9
000079f9de5d2f7c  vmovaps [rsp+0xA0], xmm10
000079f9de5d2f85  vmovaps [rsp+0xB0], xmm11
000079f9de5d2f8e  vmovaps [rsp+0xC0], xmm12
000079f9de5d2f97  vmovaps [rsp+0xD0], xmm13
000079f9de5d2fa0  vmovaps [rsp+0xE0], xmm14
000079f9de5d2fa9  sub rsp, 0x30
000079f9de5d2fad  movaps [rsp], xmm15
000079f9de5d2fb2  movaps [rsp+0x10], xmm10
000079f9de5d2fb8  movaps [rsp+0x20], xmm11
000079f9de5d2fbe  lea rdi, [rsp]
000079f9de5d2fc2  mov esi, 0x00
000079f9de5d2fc7  mov rax, 0x56D56FF59530
000079f9de5d2fd1  call rax
000079f9de5d2fd3  movaps xmm15, [rsp]
000079f9de5d2fd8  add rsp, 0x30
000079f9de5d2fdc  vmovaps xmm0, [rsp]
000079f9de5d2fe1  vmovaps xmm1, [rsp+0x10]
000079f9de5d2fe7  vmovaps xmm2, [rsp+0x20]
000079f9de5d2fed  vmovaps xmm3, [rsp+0x30]
000079f9de5d2ff3  vmovaps xmm4, [rsp+0x40]
000079f9de5d2ff9  vmovaps xmm5, [rsp+0x50]
000079f9de5d2fff  vmovaps xmm6, [rsp+0x60]
000079f9de5d3005  vmovaps xmm7, [rsp+0x70]
000079f9de5d300b  vmovaps xmm8, [rsp+0x80]
000079f9de5d3014  vmovaps xmm9, [rsp+0x90]
000079f9de5d301d  vmovaps xmm10, [rsp+0xA0]
000079f9de5d3026  vmovaps xmm11, [rsp+0xB0]
000079f9de5d302f  vmovaps xmm12, [rsp+0xC0]
000079f9de5d3038  vmovaps xmm13, [rsp+0xD0]
000079f9de5d3041  vmovaps xmm14, [rsp+0xE0]
000079f9de5d304a  add rsp, 0xF0
000079f9de5d3051  pop r11
000079f9de5d3053  pop r10
000079f9de5d3055  pop r9
000079f9de5d3057  pop r8
000079f9de5d3059  pop rsi
000079f9de5d305a  pop rdi
000079f9de5d305b  pop rdx
000079f9de5d305c  pop rcx
000079f9de5d305d  pop rax
000079f9de5d305e  add rsp, 0x08
000079f9de5d3062  jmp 0x000079F9DE5CFE57
000079f9de5d3067  sub rsp, 0x08
000079f9de5d306b  push rax
000079f9de5d306c  push rcx
000079f9de5d306d  push rdx
000079f9de5d306e  push rdi
000079f9de5d306f  push rsi
000079f9de5d3070  push r8
000079f9de5d3072  push r9
000079f9de5d3074  push r10
000079f9de5d3076  push r11
000079f9de5d3078  sub rsp, 0xF0
000079f9de5d307f  vmovaps [rsp], xmm0
000079f9de5d3084  vmovaps [rsp+0x10], xmm1
000079f9de5d308a  vmovaps [rsp+0x20], xmm2
000079f9de5d3090  vmovaps [rsp+0x30], xmm3
000079f9de5d3096  vmovaps [rsp+0x40], xmm4
000079f9de5d309c  vmovaps [rsp+0x50], xmm5
000079f9de5d30a2  vmovaps [rsp+0x60], xmm6
000079f9de5d30a8  vmovaps [rsp+0x70], xmm7
000079f9de5d30ae  vmovaps [rsp+0x80], xmm8
000079f9de5d30b7  vmovaps [rsp+0x90], xmm9
000079f9de5d30c0  vmovaps [rsp+0xA0], xmm11
000079f9de5d30c9  vmovaps [rsp+0xB0], xmm12
000079f9de5d30d2  vmovaps [rsp+0xC0], xmm13
000079f9de5d30db  vmovaps [rsp+0xD0], xmm14
000079f9de5d30e4  vmovaps [rsp+0xE0], xmm15
000079f9de5d30ed  sub rsp, 0x30
000079f9de5d30f1  movaps [rsp], xmm10
000079f9de5d30f6  movaps [rsp+0x10], xmm12
000079f9de5d30fc  movaps [rsp+0x20], xmm11
000079f9de5d3102  lea rdi, [rsp]
000079f9de5d3106  mov esi, 0x00
000079f9de5d310b  mov rax, 0x56D56FF59530
000079f9de5d3115  call rax
000079f9de5d3117  movaps xmm10, [rsp]
000079f9de5d311c  add rsp, 0x30
000079f9de5d3120  vmovaps xmm0, [rsp]
000079f9de5d3125  vmovaps xmm1, [rsp+0x10]
000079f9de5d312b  vmovaps xmm2, [rsp+0x20]
000079f9de5d3131  vmovaps xmm3, [rsp+0x30]
000079f9de5d3137  vmovaps xmm4, [rsp+0x40]
000079f9de5d313d  vmovaps xmm5, [rsp+0x50]
000079f9de5d3143  vmovaps xmm6, [rsp+0x60]
000079f9de5d3149  vmovaps xmm7, [rsp+0x70]
000079f9de5d314f  vmovaps xmm8, [rsp+0x80]
000079f9de5d3158  vmovaps xmm9, [rsp+0x90]
000079f9de5d3161  vmovaps xmm11, [rsp+0xA0]
000079f9de5d316a  vmovaps xmm12, [rsp+0xB0]
000079f9de5d3173  vmovaps xmm13, [rsp+0xC0]
000079f9de5d317c  vmovaps xmm14, [rsp+0xD0]
000079f9de5d3185  vmovaps xmm15, [rsp+0xE0]
000079f9de5d318e  add rsp, 0xF0
000079f9de5d3195  pop r11
000079f9de5d3197  pop r10
000079f9de5d3199  pop r9
000079f9de5d319b  pop r8
000079f9de5d319d  pop rsi
000079f9de5d319e  pop rdi
000079f9de5d319f  pop rdx
000079f9de5d31a0  pop rcx
000079f9de5d31a1  pop rax
000079f9de5d31a2  add rsp, 0x08
000079f9de5d31a6  jmp 0x000079F9DE5CFE80
000079f9de5d31ab  sub rsp, 0x08
000079f9de5d31af  push rax
000079f9de5d31b0  push rcx
000079f9de5d31b1  push rdx
000079f9de5d31b2  push rdi
000079f9de5d31b3  push rsi
000079f9de5d31b4  push r8
000079f9de5d31b6  push r9
000079f9de5d31b8  push r10
000079f9de5d31ba  push r11
000079f9de5d31bc  sub rsp, 0xF0
000079f9de5d31c3  vmovaps [rsp], xmm0
000079f9de5d31c8  vmovaps [rsp+0x10], xmm1
000079f9de5d31ce  vmovaps [rsp+0x20], xmm2
000079f9de5d31d4  vmovaps [rsp+0x30], xmm3
000079f9de5d31da  vmovaps [rsp+0x40], xmm4
000079f9de5d31e0  vmovaps [rsp+0x50], xmm5
000079f9de5d31e6  vmovaps [rsp+0x60], xmm6
000079f9de5d31ec  vmovaps [rsp+0x70], xmm7
000079f9de5d31f2  vmovaps [rsp+0x80], xmm8
000079f9de5d31fb  vmovaps [rsp+0x90], xmm9
000079f9de5d3204  vmovaps [rsp+0xA0], xmm10
000079f9de5d320d  vmovaps [rsp+0xB0], xmm12
000079f9de5d3216  vmovaps [rsp+0xC0], xmm13
000079f9de5d321f  vmovaps [rsp+0xD0], xmm14
000079f9de5d3228  vmovaps [rsp+0xE0], xmm15
000079f9de5d3231  sub rsp, 0x30
000079f9de5d3235  movaps [rsp], xmm11
000079f9de5d323a  movaps [rsp+0x10], xmm2
000079f9de5d323f  movaps [rsp+0x20], xmm12
000079f9de5d3245  lea rdi, [rsp]
000079f9de5d3249  mov esi, 0x00
000079f9de5d324e  mov rax, 0x56D56FF59530
000079f9de5d3258  call rax
000079f9de5d325a  movaps xmm11, [rsp]
000079f9de5d325f  add rsp, 0x30
000079f9de5d3263  vmovaps xmm0, [rsp]
000079f9de5d3268  vmovaps xmm1, [rsp+0x10]
000079f9de5d326e  vmovaps xmm2, [rsp+0x20]
000079f9de5d3274  vmovaps xmm3, [rsp+0x30]
000079f9de5d327a  vmovaps xmm4, [rsp+0x40]
000079f9de5d3280  vmovaps xmm5, [rsp+0x50]
000079f9de5d3286  vmovaps xmm6, [rsp+0x60]
000079f9de5d328c  vmovaps xmm7, [rsp+0x70]
000079f9de5d3292  vmovaps xmm8, [rsp+0x80]
000079f9de5d329b  vmovaps xmm9, [rsp+0x90]
000079f9de5d32a4  vmovaps xmm10, [rsp+0xA0]
000079f9de5d32ad  vmovaps xmm12, [rsp+0xB0]
000079f9de5d32b6  vmovaps xmm13, [rsp+0xC0]
000079f9de5d32bf  vmovaps xmm14, [rsp+0xD0]
000079f9de5d32c8  vmovaps xmm15, [rsp+0xE0]
000079f9de5d32d1  add rsp, 0xF0
000079f9de5d32d8  pop r11
000079f9de5d32da  pop r10
000079f9de5d32dc  pop r9
000079f9de5d32de  pop r8
000079f9de5d32e0  pop rsi
000079f9de5d32e1  pop rdi
000079f9de5d32e2  pop rdx
000079f9de5d32e3  pop rcx
000079f9de5d32e4  pop rax
000079f9de5d32e5  add rsp, 0x08
000079f9de5d32e9  jmp 0x000079F9DE5CFEB8
000079f9de5d32ee  sub rsp, 0x08
000079f9de5d32f2  push rax
000079f9de5d32f3  push rcx
000079f9de5d32f4  push rdx
000079f9de5d32f5  push rdi
000079f9de5d32f6  push rsi
000079f9de5d32f7  push r8
000079f9de5d32f9  push r9
000079f9de5d32fb  push r10
000079f9de5d32fd  push r11
000079f9de5d32ff  sub rsp, 0xF0
000079f9de5d3306  vmovaps [rsp], xmm0
000079f9de5d330b  vmovaps [rsp+0x10], xmm2
000079f9de5d3311  vmovaps [rsp+0x20], xmm3
000079f9de5d3317  vmovaps [rsp+0x30], xmm4
000079f9de5d331d  vmovaps [rsp+0x40], xmm5
000079f9de5d3323  vmovaps [rsp+0x50], xmm6
000079f9de5d3329  vmovaps [rsp+0x60], xmm7
000079f9de5d332f  vmovaps [rsp+0x70], xmm8
000079f9de5d3335  vmovaps [rsp+0x80], xmm9
000079f9de5d333e  vmovaps [rsp+0x90], xmm10
000079f9de5d3347  vmovaps [rsp+0xA0], xmm11
000079f9de5d3350  vmovaps [rsp+0xB0], xmm12
000079f9de5d3359  vmovaps [rsp+0xC0], xmm13
000079f9de5d3362  vmovaps [rsp+0xD0], xmm14
000079f9de5d336b  vmovaps [rsp+0xE0], xmm15
000079f9de5d3374  sub rsp, 0x30
000079f9de5d3378  movaps [rsp], xmm1
000079f9de5d337c  movaps [rsp+0x10], xmm14
000079f9de5d3382  movaps [rsp+0x20], xmm6
000079f9de5d3387  lea rdi, [rsp]
000079f9de5d338b  mov esi, 0x00
000079f9de5d3390  mov rax, 0x56D56FF59530
000079f9de5d339a  call rax
000079f9de5d339c  movaps xmm1, [rsp]
000079f9de5d33a0  add rsp, 0x30
000079f9de5d33a4  vmovaps xmm0, [rsp]
000079f9de5d33a9  vmovaps xmm2, [rsp+0x10]
000079f9de5d33af  vmovaps xmm3, [rsp+0x20]
000079f9de5d33b5  vmovaps xmm4, [rsp+0x30]
000079f9de5d33bb  vmovaps xmm5, [rsp+0x40]
000079f9de5d33c1  vmovaps xmm6, [rsp+0x50]
000079f9de5d33c7  vmovaps xmm7, [rsp+0x60]
000079f9de5d33cd  vmovaps xmm8, [rsp+0x70]
000079f9de5d33d3  vmovaps xmm9, [rsp+0x80]
000079f9de5d33dc  vmovaps xmm10, [rsp+0x90]
000079f9de5d33e5  vmovaps xmm11, [rsp+0xA0]
000079f9de5d33ee  vmovaps xmm12, [rsp+0xB0]
000079f9de5d33f7  vmovaps xmm13, [rsp+0xC0]
000079f9de5d3400  vmovaps xmm14, [rsp+0xD0]
000079f9de5d3409  vmovaps xmm15, [rsp+0xE0]
000079f9de5d3412  add rsp, 0xF0
000079f9de5d3419  pop r11
000079f9de5d341b  pop r10
000079f9de5d341d  pop r9
000079f9de5d341f  pop r8
000079f9de5d3421  pop rsi
000079f9de5d3422  pop rdi
000079f9de5d3423  pop rdx
000079f9de5d3424  pop rcx
000079f9de5d3425  pop rax
000079f9de5d3426  add rsp, 0x08
000079f9de5d342a  jmp 0x000079F9DE5CFED1
000079f9de5d342f  sub rsp, 0x08
000079f9de5d3433  push rax
000079f9de5d3434  push rcx
000079f9de5d3435  push rdx
000079f9de5d3436  push rdi
000079f9de5d3437  push rsi
000079f9de5d3438  push r8
000079f9de5d343a  push r9
000079f9de5d343c  push r10
000079f9de5d343e  push r11
000079f9de5d3440  sub rsp, 0xF0
000079f9de5d3447  vmovaps [rsp], xmm0
000079f9de5d344c  vmovaps [rsp+0x10], xmm1
000079f9de5d3452  vmovaps [rsp+0x20], xmm2
000079f9de5d3458  vmovaps [rsp+0x30], xmm3
000079f9de5d345e  vmovaps [rsp+0x40], xmm4
000079f9de5d3464  vmovaps [rsp+0x50], xmm5
000079f9de5d346a  vmovaps [rsp+0x60], xmm6
000079f9de5d3470  vmovaps [rsp+0x70], xmm7
000079f9de5d3476  vmovaps [rsp+0x80], xmm8
000079f9de5d347f  vmovaps [rsp+0x90], xmm9
000079f9de5d3488  vmovaps [rsp+0xA0], xmm10
000079f9de5d3491  vmovaps [rsp+0xB0], xmm11
000079f9de5d349a  vmovaps [rsp+0xC0], xmm12
000079f9de5d34a3  vmovaps [rsp+0xD0], xmm13
000079f9de5d34ac  vmovaps [rsp+0xE0], xmm15
000079f9de5d34b5  sub rsp, 0x30
000079f9de5d34b9  movaps [rsp], xmm14
000079f9de5d34be  movaps [rsp+0x10], xmm12
000079f9de5d34c4  movaps [rsp+0x20], xmm5
000079f9de5d34c9  lea rdi, [rsp]
000079f9de5d34cd  mov esi, 0x00
000079f9de5d34d2  mov rax, 0x56D56FF59530
000079f9de5d34dc  call rax
000079f9de5d34de  movaps xmm14, [rsp]
000079f9de5d34e3  add rsp, 0x30
000079f9de5d34e7  vmovaps xmm0, [rsp]
000079f9de5d34ec  vmovaps xmm1, [rsp+0x10]
000079f9de5d34f2  vmovaps xmm2, [rsp+0x20]
000079f9de5d34f8  vmovaps xmm3, [rsp+0x30]
000079f9de5d34fe  vmovaps xmm4, [rsp+0x40]
000079f9de5d3504  vmovaps xmm5, [rsp+0x50]
000079f9de5d350a  vmovaps xmm6, [rsp+0x60]
000079f9de5d3510  vmovaps xmm7, [rsp+0x70]
000079f9de5d3516  vmovaps xmm8, [rsp+0x80]
000079f9de5d351f  vmovaps xmm9, [rsp+0x90]
000079f9de5d3528  vmovaps xmm10, [rsp+0xA0]
000079f9de5d3531  vmovaps xmm11, [rsp+0xB0]
000079f9de5d353a  vmovaps xmm12, [rsp+0xC0]
000079f9de5d3543  vmovaps xmm13, [rsp+0xD0]
000079f9de5d354c  vmovaps xmm15, [rsp+0xE0]
000079f9de5d3555  add rsp, 0xF0
000079f9de5d355c  pop r11
000079f9de5d355e  pop r10
000079f9de5d3560  pop r9
000079f9de5d3562  pop r8
000079f9de5d3564  pop rsi
000079f9de5d3565  pop rdi
000079f9de5d3566  pop rdx
000079f9de5d3567  pop rcx
000079f9de5d3568  pop rax
000079f9de5d3569  add rsp, 0x08
000079f9de5d356d  jmp 0x000079F9DE5CFEF1
000079f9de5d3572  sub rsp, 0x08
000079f9de5d3576  push rax
000079f9de5d3577  push rcx
000079f9de5d3578  push rdx
000079f9de5d3579  push rdi
000079f9de5d357a  push rsi
000079f9de5d357b  push r8
000079f9de5d357d  push r9
000079f9de5d357f  push r10
000079f9de5d3581  push r11
000079f9de5d3583  sub rsp, 0xF0
000079f9de5d358a  vmovaps [rsp], xmm0
000079f9de5d358f  vmovaps [rsp+0x10], xmm1
000079f9de5d3595  vmovaps [rsp+0x20], xmm2
000079f9de5d359b  vmovaps [rsp+0x30], xmm3
000079f9de5d35a1  vmovaps [rsp+0x40], xmm4
000079f9de5d35a7  vmovaps [rsp+0x50], xmm5
000079f9de5d35ad  vmovaps [rsp+0x60], xmm7
000079f9de5d35b3  vmovaps [rsp+0x70], xmm8
000079f9de5d35b9  vmovaps [rsp+0x80], xmm9
000079f9de5d35c2  vmovaps [rsp+0x90], xmm10
000079f9de5d35cb  vmovaps [rsp+0xA0], xmm11
000079f9de5d35d4  vmovaps [rsp+0xB0], xmm12
000079f9de5d35dd  vmovaps [rsp+0xC0], xmm13
000079f9de5d35e6  vmovaps [rsp+0xD0], xmm14
000079f9de5d35ef  vmovaps [rsp+0xE0], xmm15
000079f9de5d35f8  sub rsp, 0x30
000079f9de5d35fc  movaps [rsp], xmm6
000079f9de5d3600  movaps [rsp+0x10], xmm9
000079f9de5d3606  movaps [rsp+0x20], xmm12
000079f9de5d360c  lea rdi, [rsp]
000079f9de5d3610  mov esi, 0x00
000079f9de5d3615  mov rax, 0x56D56FF59530
000079f9de5d361f  call rax
000079f9de5d3621  movaps xmm6, [rsp]
000079f9de5d3625  add rsp, 0x30
000079f9de5d3629  vmovaps xmm0, [rsp]
000079f9de5d362e  vmovaps xmm1, [rsp+0x10]
000079f9de5d3634  vmovaps xmm2, [rsp+0x20]
000079f9de5d363a  vmovaps xmm3, [rsp+0x30]
000079f9de5d3640  vmovaps xmm4, [rsp+0x40]
000079f9de5d3646  vmovaps xmm5, [rsp+0x50]
000079f9de5d364c  vmovaps xmm7, [rsp+0x60]
000079f9de5d3652  vmovaps xmm8, [rsp+0x70]
000079f9de5d3658  vmovaps xmm9, [rsp+0x80]
000079f9de5d3661  vmovaps xmm10, [rsp+0x90]
000079f9de5d366a  vmovaps xmm11, [rsp+0xA0]
000079f9de5d3673  vmovaps xmm12, [rsp+0xB0]
000079f9de5d367c  vmovaps xmm13, [rsp+0xC0]
000079f9de5d3685  vmovaps xmm14, [rsp+0xD0]
000079f9de5d368e  vmovaps xmm15, [rsp+0xE0]
000079f9de5d3697  add rsp, 0xF0
000079f9de5d369e  pop r11
000079f9de5d36a0  pop r10
000079f9de5d36a2  pop r9
000079f9de5d36a4  pop r8
000079f9de5d36a6  pop rsi
000079f9de5d36a7  pop rdi
000079f9de5d36a8  pop rdx
000079f9de5d36a9  pop rcx
000079f9de5d36aa  pop rax
000079f9de5d36ab  add rsp, 0x08
000079f9de5d36af  jmp 0x000079F9DE5CFF19
000079f9de5d36b4  sub rsp, 0x08
000079f9de5d36b8  push rax
000079f9de5d36b9  push rcx
000079f9de5d36ba  push rdx
000079f9de5d36bb  push rdi
000079f9de5d36bc  push rsi
000079f9de5d36bd  push r8
000079f9de5d36bf  push r9
000079f9de5d36c1  push r10
000079f9de5d36c3  push r11
000079f9de5d36c5  sub rsp, 0xF0
000079f9de5d36cc  vmovaps [rsp], xmm0
000079f9de5d36d1  vmovaps [rsp+0x10], xmm1
000079f9de5d36d7  vmovaps [rsp+0x20], xmm2
000079f9de5d36dd  vmovaps [rsp+0x30], xmm3
000079f9de5d36e3  vmovaps [rsp+0x40], xmm4
000079f9de5d36e9  vmovaps [rsp+0x50], xmm5
000079f9de5d36ef  vmovaps [rsp+0x60], xmm6
000079f9de5d36f5  vmovaps [rsp+0x70], xmm7
000079f9de5d36fb  vmovaps [rsp+0x80], xmm8
000079f9de5d3704  vmovaps [rsp+0x90], xmm9
000079f9de5d370d  vmovaps [rsp+0xA0], xmm10
000079f9de5d3716  vmovaps [rsp+0xB0], xmm11
000079f9de5d371f  vmovaps [rsp+0xC0], xmm13
000079f9de5d3728  vmovaps [rsp+0xD0], xmm14
000079f9de5d3731  vmovaps [rsp+0xE0], xmm15
000079f9de5d373a  sub rsp, 0x30
000079f9de5d373e  movaps [rsp], xmm12
000079f9de5d3743  movaps [rsp+0x10], xmm15
000079f9de5d3749  movaps [rsp+0x20], xmm13
000079f9de5d374f  lea rdi, [rsp]
000079f9de5d3753  mov esi, 0x00
000079f9de5d3758  mov rax, 0x56D56FF59530
000079f9de5d3762  call rax
000079f9de5d3764  movaps xmm12, [rsp]
000079f9de5d3769  add rsp, 0x30
000079f9de5d376d  vmovaps xmm0, [rsp]
000079f9de5d3772  vmovaps xmm1, [rsp+0x10]
000079f9de5d3778  vmovaps xmm2, [rsp+0x20]
000079f9de5d377e  vmovaps xmm3, [rsp+0x30]
000079f9de5d3784  vmovaps xmm4, [rsp+0x40]
000079f9de5d378a  vmovaps xmm5, [rsp+0x50]
000079f9de5d3790  vmovaps xmm6, [rsp+0x60]
000079f9de5d3796  vmovaps xmm7, [rsp+0x70]
000079f9de5d379c  vmovaps xmm8, [rsp+0x80]
000079f9de5d37a5  vmovaps xmm9, [rsp+0x90]
000079f9de5d37ae  vmovaps xmm10, [rsp+0xA0]
000079f9de5d37b7  vmovaps xmm11, [rsp+0xB0]
000079f9de5d37c0  vmovaps xmm13, [rsp+0xC0]
000079f9de5d37c9  vmovaps xmm14, [rsp+0xD0]
000079f9de5d37d2  vmovaps xmm15, [rsp+0xE0]
000079f9de5d37db  add rsp, 0xF0
000079f9de5d37e2  pop r11
000079f9de5d37e4  pop r10
000079f9de5d37e6  pop r9
000079f9de5d37e8  pop r8
000079f9de5d37ea  pop rsi
000079f9de5d37eb  pop rdi
000079f9de5d37ec  pop rdx
000079f9de5d37ed  pop rcx
000079f9de5d37ee  pop rax
000079f9de5d37ef  add rsp, 0x08
000079f9de5d37f3  jmp 0x000079F9DE5CFF34
000079f9de5d37f8  sub rsp, 0x08
000079f9de5d37fc  push rax
000079f9de5d37fd  push rcx
000079f9de5d37fe  push rdx
000079f9de5d37ff  push rdi
000079f9de5d3800  push rsi
000079f9de5d3801  push r8
000079f9de5d3803  push r9
000079f9de5d3805  push r10
000079f9de5d3807  push r11
000079f9de5d3809  sub rsp, 0xF0
000079f9de5d3810  vmovaps [rsp], xmm0
000079f9de5d3815  vmovaps [rsp+0x10], xmm1
000079f9de5d381b  vmovaps [rsp+0x20], xmm2
000079f9de5d3821  vmovaps [rsp+0x30], xmm3
000079f9de5d3827  vmovaps [rsp+0x40], xmm4
000079f9de5d382d  vmovaps [rsp+0x50], xmm5
000079f9de5d3833  vmovaps [rsp+0x60], xmm6
000079f9de5d3839  vmovaps [rsp+0x70], xmm7
000079f9de5d383f  vmovaps [rsp+0x80], xmm8
000079f9de5d3848  vmovaps [rsp+0x90], xmm9
000079f9de5d3851  vmovaps [rsp+0xA0], xmm10
000079f9de5d385a  vmovaps [rsp+0xB0], xmm11
000079f9de5d3863  vmovaps [rsp+0xC0], xmm12
000079f9de5d386c  vmovaps [rsp+0xD0], xmm13
000079f9de5d3875  vmovaps [rsp+0xE0], xmm14
000079f9de5d387e  sub rsp, 0x30
000079f9de5d3882  movaps [rsp], xmm15
000079f9de5d3887  movaps [rsp+0x10], xmm13
000079f9de5d388d  movaps [rsp+0x20], xmm10
000079f9de5d3893  lea rdi, [rsp]
000079f9de5d3897  mov esi, 0x00
000079f9de5d389c  mov rax, 0x56D56FF59530
000079f9de5d38a6  call rax
000079f9de5d38a8  movaps xmm15, [rsp]
000079f9de5d38ad  add rsp, 0x30
000079f9de5d38b1  vmovaps xmm0, [rsp]
000079f9de5d38b6  vmovaps xmm1, [rsp+0x10]
000079f9de5d38bc  vmovaps xmm2, [rsp+0x20]
000079f9de5d38c2  vmovaps xmm3, [rsp+0x30]
000079f9de5d38c8  vmovaps xmm4, [rsp+0x40]
000079f9de5d38ce  vmovaps xmm5, [rsp+0x50]
000079f9de5d38d4  vmovaps xmm6, [rsp+0x60]
000079f9de5d38da  vmovaps xmm7, [rsp+0x70]
000079f9de5d38e0  vmovaps xmm8, [rsp+0x80]
000079f9de5d38e9  vmovaps xmm9, [rsp+0x90]
000079f9de5d38f2  vmovaps xmm10, [rsp+0xA0]
000079f9de5d38fb  vmovaps xmm11, [rsp+0xB0]
000079f9de5d3904  vmovaps xmm12, [rsp+0xC0]
000079f9de5d390d  vmovaps xmm13, [rsp+0xD0]
000079f9de5d3916  vmovaps xmm14, [rsp+0xE0]
000079f9de5d391f  add rsp, 0xF0
000079f9de5d3926  pop r11
000079f9de5d3928  pop r10
000079f9de5d392a  pop r9
000079f9de5d392c  pop r8
000079f9de5d392e  pop rsi
000079f9de5d392f  pop rdi
000079f9de5d3930  pop rdx
000079f9de5d3931  pop rcx
000079f9de5d3932  pop rax
000079f9de5d3933  add rsp, 0x08
000079f9de5d3937  jmp 0x000079F9DE5CFF55
000079f9de5d393c  call 0x000079F9DE40C260
000079f9de5d3941  jmp 0x000079F9DE5CFFB0
000079f9de5d3946  sub rsp, 0x08
000079f9de5d394a  push rax
000079f9de5d394b  push rcx
000079f9de5d394c  push rdx
000079f9de5d394d  push rdi
000079f9de5d394e  push rsi
000079f9de5d394f  push r8
000079f9de5d3951  push r9
000079f9de5d3953  push r10
000079f9de5d3955  push r11
000079f9de5d3957  sub rsp, 0xF0
000079f9de5d395e  vmovaps [rsp], xmm0
000079f9de5d3963  vmovaps [rsp+0x10], xmm1
000079f9de5d3969  vmovaps [rsp+0x20], xmm2
000079f9de5d396f  vmovaps [rsp+0x30], xmm3
000079f9de5d3975  vmovaps [rsp+0x40], xmm4
000079f9de5d397b  vmovaps [rsp+0x50], xmm5
000079f9de5d3981  vmovaps [rsp+0x60], xmm6
000079f9de5d3987  vmovaps [rsp+0x70], xmm7
000079f9de5d398d  vmovaps [rsp+0x80], xmm8
000079f9de5d3996  vmovaps [rsp+0x90], xmm10
000079f9de5d399f  vmovaps [rsp+0xA0], xmm11
000079f9de5d39a8  vmovaps [rsp+0xB0], xmm12
000079f9de5d39b1  vmovaps [rsp+0xC0], xmm13
000079f9de5d39ba  vmovaps [rsp+0xD0], xmm14
000079f9de5d39c3  vmovaps [rsp+0xE0], xmm15
000079f9de5d39cc  sub rsp, 0x30
000079f9de5d39d0  movaps [rsp], xmm9
000079f9de5d39d5  movaps [rsp+0x10], xmm8
000079f9de5d39db  movaps [rsp+0x20], xmm10
000079f9de5d39e1  lea rdi, [rsp]
000079f9de5d39e5  mov esi, 0x00
000079f9de5d39ea  mov rax, 0x56D56FF59530
000079f9de5d39f4  call rax
000079f9de5d39f6  movaps xmm9, [rsp]
000079f9de5d39fb  add rsp, 0x30
000079f9de5d39ff  vmovaps xmm0, [rsp]
000079f9de5d3a04  vmovaps xmm1, [rsp+0x10]
000079f9de5d3a0a  vmovaps xmm2, [rsp+0x20]
000079f9de5d3a10  vmovaps xmm3, [rsp+0x30]
000079f9de5d3a16  vmovaps xmm4, [rsp+0x40]
000079f9de5d3a1c  vmovaps xmm5, [rsp+0x50]
000079f9de5d3a22  vmovaps xmm6, [rsp+0x60]
000079f9de5d3a28  vmovaps xmm7, [rsp+0x70]
000079f9de5d3a2e  vmovaps xmm8, [rsp+0x80]
000079f9de5d3a37  vmovaps xmm10, [rsp+0x90]
000079f9de5d3a40  vmovaps xmm11, [rsp+0xA0]
000079f9de5d3a49  vmovaps xmm12, [rsp+0xB0]
000079f9de5d3a52  vmovaps xmm13, [rsp+0xC0]
000079f9de5d3a5b  vmovaps xmm14, [rsp+0xD0]
000079f9de5d3a64  vmovaps xmm15, [rsp+0xE0]
000079f9de5d3a6d  add rsp, 0xF0
000079f9de5d3a74  pop r11
000079f9de5d3a76  pop r10
000079f9de5d3a78  pop r9
000079f9de5d3a7a  pop r8
000079f9de5d3a7c  pop rsi
000079f9de5d3a7d  pop rdi
000079f9de5d3a7e  pop rdx
000079f9de5d3a7f  pop rcx
000079f9de5d3a80  pop rax
000079f9de5d3a81  add rsp, 0x08
000079f9de5d3a85  jmp 0x000079F9DE5CFFE1
000079f9de5d3a8a  sub rsp, 0x08
000079f9de5d3a8e  push rax
000079f9de5d3a8f  push rcx
000079f9de5d3a90  push rdx
000079f9de5d3a91  push rdi
000079f9de5d3a92  push rsi
000079f9de5d3a93  push r8
000079f9de5d3a95  push r9
000079f9de5d3a97  push r10
000079f9de5d3a99  push r11
000079f9de5d3a9b  sub rsp, 0xF0
000079f9de5d3aa2  vmovaps [rsp], xmm0
000079f9de5d3aa7  vmovaps [rsp+0x10], xmm1
000079f9de5d3aad  vmovaps [rsp+0x20], xmm2
000079f9de5d3ab3  vmovaps [rsp+0x30], xmm3
000079f9de5d3ab9  vmovaps [rsp+0x40], xmm4
000079f9de5d3abf  vmovaps [rsp+0x50], xmm5
000079f9de5d3ac5  vmovaps [rsp+0x60], xmm6
000079f9de5d3acb  vmovaps [rsp+0x70], xmm7
000079f9de5d3ad1  vmovaps [rsp+0x80], xmm8
000079f9de5d3ada  vmovaps [rsp+0x90], xmm9
000079f9de5d3ae3  vmovaps [rsp+0xA0], xmm11
000079f9de5d3aec  vmovaps [rsp+0xB0], xmm12
000079f9de5d3af5  vmovaps [rsp+0xC0], xmm13
000079f9de5d3afe  vmovaps [rsp+0xD0], xmm14
000079f9de5d3b07  vmovaps [rsp+0xE0], xmm15
000079f9de5d3b10  sub rsp, 0x30
000079f9de5d3b14  movaps [rsp], xmm10
000079f9de5d3b19  movaps [rsp+0x10], xmm1
000079f9de5d3b1e  movaps [rsp+0x20], xmm11
000079f9de5d3b24  lea rdi, [rsp]
000079f9de5d3b28  mov esi, 0x00
000079f9de5d3b2d  mov rax, 0x56D56FF59530
000079f9de5d3b37  call rax
000079f9de5d3b39  movaps xmm10, [rsp]
000079f9de5d3b3e  add rsp, 0x30
000079f9de5d3b42  vmovaps xmm0, [rsp]
000079f9de5d3b47  vmovaps xmm1, [rsp+0x10]
000079f9de5d3b4d  vmovaps xmm2, [rsp+0x20]
000079f9de5d3b53  vmovaps xmm3, [rsp+0x30]
000079f9de5d3b59  vmovaps xmm4, [rsp+0x40]
000079f9de5d3b5f  vmovaps xmm5, [rsp+0x50]
000079f9de5d3b65  vmovaps xmm6, [rsp+0x60]
000079f9de5d3b6b  vmovaps xmm7, [rsp+0x70]
000079f9de5d3b71  vmovaps xmm8, [rsp+0x80]
000079f9de5d3b7a  vmovaps xmm9, [rsp+0x90]
000079f9de5d3b83  vmovaps xmm11, [rsp+0xA0]
000079f9de5d3b8c  vmovaps xmm12, [rsp+0xB0]
000079f9de5d3b95  vmovaps xmm13, [rsp+0xC0]
000079f9de5d3b9e  vmovaps xmm14, [rsp+0xD0]
000079f9de5d3ba7  vmovaps xmm15, [rsp+0xE0]
000079f9de5d3bb0  add rsp, 0xF0
000079f9de5d3bb7  pop r11
000079f9de5d3bb9  pop r10
000079f9de5d3bbb  pop r9
000079f9de5d3bbd  pop r8
000079f9de5d3bbf  pop rsi
000079f9de5d3bc0  pop rdi
000079f9de5d3bc1  pop rdx
000079f9de5d3bc2  pop rcx
000079f9de5d3bc3  pop rax
000079f9de5d3bc4  add rsp, 0x08
000079f9de5d3bc8  jmp 0x000079F9DE5CFFFC
000079f9de5d3bcd  sub rsp, 0x08
000079f9de5d3bd1  push rax
000079f9de5d3bd2  push rcx
000079f9de5d3bd3  push rdx
000079f9de5d3bd4  push rdi
000079f9de5d3bd5  push rsi
000079f9de5d3bd6  push r8
000079f9de5d3bd8  push r9
000079f9de5d3bda  push r10
000079f9de5d3bdc  push r11
000079f9de5d3bde  sub rsp, 0xF0
000079f9de5d3be5  vmovaps [rsp], xmm0
000079f9de5d3bea  vmovaps [rsp+0x10], xmm2
000079f9de5d3bf0  vmovaps [rsp+0x20], xmm3
000079f9de5d3bf6  vmovaps [rsp+0x30], xmm4
000079f9de5d3bfc  vmovaps [rsp+0x40], xmm5
000079f9de5d3c02  vmovaps [rsp+0x50], xmm6
000079f9de5d3c08  vmovaps [rsp+0x60], xmm7
000079f9de5d3c0e  vmovaps [rsp+0x70], xmm8
000079f9de5d3c14  vmovaps [rsp+0x80], xmm9
000079f9de5d3c1d  vmovaps [rsp+0x90], xmm10
000079f9de5d3c26  vmovaps [rsp+0xA0], xmm11
000079f9de5d3c2f  vmovaps [rsp+0xB0], xmm12
000079f9de5d3c38  vmovaps [rsp+0xC0], xmm13
000079f9de5d3c41  vmovaps [rsp+0xD0], xmm14
000079f9de5d3c4a  vmovaps [rsp+0xE0], xmm15
000079f9de5d3c53  sub rsp, 0x30
000079f9de5d3c57  movaps [rsp], xmm1
000079f9de5d3c5b  movaps [rsp+0x10], xmm14
000079f9de5d3c61  movaps [rsp+0x20], xmm6
000079f9de5d3c66  lea rdi, [rsp]
000079f9de5d3c6a  mov esi, 0x00
000079f9de5d3c6f  mov rax, 0x56D56FF59530
000079f9de5d3c79  call rax
000079f9de5d3c7b  movaps xmm1, [rsp]
000079f9de5d3c7f  add rsp, 0x30
000079f9de5d3c83  vmovaps xmm0, [rsp]
000079f9de5d3c88  vmovaps xmm2, [rsp+0x10]
000079f9de5d3c8e  vmovaps xmm3, [rsp+0x20]
000079f9de5d3c94  vmovaps xmm4, [rsp+0x30]
000079f9de5d3c9a  vmovaps xmm5, [rsp+0x40]
000079f9de5d3ca0  vmovaps xmm6, [rsp+0x50]
000079f9de5d3ca6  vmovaps xmm7, [rsp+0x60]
000079f9de5d3cac  vmovaps xmm8, [rsp+0x70]
000079f9de5d3cb2  vmovaps xmm9, [rsp+0x80]
000079f9de5d3cbb  vmovaps xmm10, [rsp+0x90]
000079f9de5d3cc4  vmovaps xmm11, [rsp+0xA0]
000079f9de5d3ccd  vmovaps xmm12, [rsp+0xB0]
000079f9de5d3cd6  vmovaps xmm13, [rsp+0xC0]
000079f9de5d3cdf  vmovaps xmm14, [rsp+0xD0]
000079f9de5d3ce8  vmovaps xmm15, [rsp+0xE0]
000079f9de5d3cf1  add rsp, 0xF0
000079f9de5d3cf8  pop r11
000079f9de5d3cfa  pop r10
000079f9de5d3cfc  pop r9
000079f9de5d3cfe  pop r8
000079f9de5d3d00  pop rsi
000079f9de5d3d01  pop rdi
000079f9de5d3d02  pop rdx
000079f9de5d3d03  pop rcx
000079f9de5d3d04  pop rax
000079f9de5d3d05  add rsp, 0x08
000079f9de5d3d09  jmp 0x000079F9DE5D0015
000079f9de5d3d0e  sub rsp, 0x08
000079f9de5d3d12  push rax
000079f9de5d3d13  push rcx
000079f9de5d3d14  push rdx
000079f9de5d3d15  push rdi
000079f9de5d3d16  push rsi
000079f9de5d3d17  push r8
000079f9de5d3d19  push r9
000079f9de5d3d1b  push r10
000079f9de5d3d1d  push r11
000079f9de5d3d1f  sub rsp, 0xF0
000079f9de5d3d26  vmovaps [rsp], xmm0
000079f9de5d3d2b  vmovaps [rsp+0x10], xmm1
000079f9de5d3d31  vmovaps [rsp+0x20], xmm2
000079f9de5d3d37  vmovaps [rsp+0x30], xmm3
000079f9de5d3d3d  vmovaps [rsp+0x40], xmm4
000079f9de5d3d43  vmovaps [rsp+0x50], xmm5
000079f9de5d3d49  vmovaps [rsp+0x60], xmm6
000079f9de5d3d4f  vmovaps [rsp+0x70], xmm7
000079f9de5d3d55  vmovaps [rsp+0x80], xmm8
000079f9de5d3d5e  vmovaps [rsp+0x90], xmm9
000079f9de5d3d67  vmovaps [rsp+0xA0], xmm10
000079f9de5d3d70  vmovaps [rsp+0xB0], xmm12
000079f9de5d3d79  vmovaps [rsp+0xC0], xmm13
000079f9de5d3d82  vmovaps [rsp+0xD0], xmm14
000079f9de5d3d8b  vmovaps [rsp+0xE0], xmm15
000079f9de5d3d94  sub rsp, 0x30
000079f9de5d3d98  movaps [rsp], xmm11
000079f9de5d3d9d  movaps [rsp+0x10], xmm13
000079f9de5d3da3  movaps [rsp+0x20], xmm14
000079f9de5d3da9  lea rdi, [rsp]
000079f9de5d3dad  mov esi, 0x00
000079f9de5d3db2  mov rax, 0x56D56FF59530
000079f9de5d3dbc  call rax
000079f9de5d3dbe  movaps xmm11, [rsp]
000079f9de5d3dc3  add rsp, 0x30
000079f9de5d3dc7  vmovaps xmm0, [rsp]
000079f9de5d3dcc  vmovaps xmm1, [rsp+0x10]
000079f9de5d3dd2  vmovaps xmm2, [rsp+0x20]
000079f9de5d3dd8  vmovaps xmm3, [rsp+0x30]
000079f9de5d3dde  vmovaps xmm4, [rsp+0x40]
000079f9de5d3de4  vmovaps xmm5, [rsp+0x50]
000079f9de5d3dea  vmovaps xmm6, [rsp+0x60]
000079f9de5d3df0  vmovaps xmm7, [rsp+0x70]
000079f9de5d3df6  vmovaps xmm8, [rsp+0x80]
000079f9de5d3dff  vmovaps xmm9, [rsp+0x90]
000079f9de5d3e08  vmovaps xmm10, [rsp+0xA0]
000079f9de5d3e11  vmovaps xmm12, [rsp+0xB0]
000079f9de5d3e1a  vmovaps xmm13, [rsp+0xC0]
000079f9de5d3e23  vmovaps xmm14, [rsp+0xD0]
000079f9de5d3e2c  vmovaps xmm15, [rsp+0xE0]
000079f9de5d3e35  add rsp, 0xF0
000079f9de5d3e3c  pop r11
000079f9de5d3e3e  pop r10
000079f9de5d3e40  pop r9
000079f9de5d3e42  pop r8
000079f9de5d3e44  pop rsi
000079f9de5d3e45  pop rdi
000079f9de5d3e46  pop rdx
000079f9de5d3e47  pop rcx
000079f9de5d3e48  pop rax
000079f9de5d3e49  add rsp, 0x08
000079f9de5d3e4d  jmp 0x000079F9DE5D003F
000079f9de5d3e52  sub rsp, 0x08
000079f9de5d3e56  push rax
000079f9de5d3e57  push rcx
000079f9de5d3e58  push rdx
000079f9de5d3e59  push rdi
000079f9de5d3e5a  push rsi
000079f9de5d3e5b  push r8
000079f9de5d3e5d  push r9
000079f9de5d3e5f  push r10
000079f9de5d3e61  push r11
000079f9de5d3e63  sub rsp, 0xF0
000079f9de5d3e6a  vmovaps [rsp], xmm0
000079f9de5d3e6f  vmovaps [rsp+0x10], xmm1
000079f9de5d3e75  vmovaps [rsp+0x20], xmm2
000079f9de5d3e7b  vmovaps [rsp+0x30], xmm3
000079f9de5d3e81  vmovaps [rsp+0x40], xmm4
000079f9de5d3e87  vmovaps [rsp+0x50], xmm5
000079f9de5d3e8d  vmovaps [rsp+0x60], xmm6
000079f9de5d3e93  vmovaps [rsp+0x70], xmm7
000079f9de5d3e99  vmovaps [rsp+0x80], xmm8
000079f9de5d3ea2  vmovaps [rsp+0x90], xmm9
000079f9de5d3eab  vmovaps [rsp+0xA0], xmm10
000079f9de5d3eb4  vmovaps [rsp+0xB0], xmm11
000079f9de5d3ebd  vmovaps [rsp+0xC0], xmm12
000079f9de5d3ec6  vmovaps [rsp+0xD0], xmm14
000079f9de5d3ecf  vmovaps [rsp+0xE0], xmm15
000079f9de5d3ed8  sub rsp, 0x30
000079f9de5d3edc  movaps [rsp], xmm13
000079f9de5d3ee1  movaps [rsp+0x10], xmm8
000079f9de5d3ee7  movaps [rsp+0x20], xmm14
000079f9de5d3eed  lea rdi, [rsp]
000079f9de5d3ef1  mov esi, 0x00
000079f9de5d3ef6  mov rax, 0x56D56FF59530
000079f9de5d3f00  call rax
000079f9de5d3f02  movaps xmm13, [rsp]
000079f9de5d3f07  add rsp, 0x30
000079f9de5d3f0b  vmovaps xmm0, [rsp]
000079f9de5d3f10  vmovaps xmm1, [rsp+0x10]
000079f9de5d3f16  vmovaps xmm2, [rsp+0x20]
000079f9de5d3f1c  vmovaps xmm3, [rsp+0x30]
000079f9de5d3f22  vmovaps xmm4, [rsp+0x40]
000079f9de5d3f28  vmovaps xmm5, [rsp+0x50]
000079f9de5d3f2e  vmovaps xmm6, [rsp+0x60]
000079f9de5d3f34  vmovaps xmm7, [rsp+0x70]
000079f9de5d3f3a  vmovaps xmm8, [rsp+0x80]
000079f9de5d3f43  vmovaps xmm9, [rsp+0x90]
000079f9de5d3f4c  vmovaps xmm10, [rsp+0xA0]
000079f9de5d3f55  vmovaps xmm11, [rsp+0xB0]
000079f9de5d3f5e  vmovaps xmm12, [rsp+0xC0]
000079f9de5d3f67  vmovaps xmm14, [rsp+0xD0]
000079f9de5d3f70  vmovaps xmm15, [rsp+0xE0]
000079f9de5d3f79  add rsp, 0xF0
000079f9de5d3f80  pop r11
000079f9de5d3f82  pop r10
000079f9de5d3f84  pop r9
000079f9de5d3f86  pop r8
000079f9de5d3f88  pop rsi
000079f9de5d3f89  pop rdi
000079f9de5d3f8a  pop rdx
000079f9de5d3f8b  pop rcx
000079f9de5d3f8c  pop rax
000079f9de5d3f8d  add rsp, 0x08
000079f9de5d3f91  jmp 0x000079F9DE5D006E
000079f9de5d3f96  sub rsp, 0x08
000079f9de5d3f9a  push rax
000079f9de5d3f9b  push rcx
000079f9de5d3f9c  push rdx
000079f9de5d3f9d  push rdi
000079f9de5d3f9e  push rsi
000079f9de5d3f9f  push r8
000079f9de5d3fa1  push r9
000079f9de5d3fa3  push r10
000079f9de5d3fa5  push r11
000079f9de5d3fa7  sub rsp, 0xF0
000079f9de5d3fae  vmovaps [rsp], xmm0
000079f9de5d3fb3  vmovaps [rsp+0x10], xmm1
000079f9de5d3fb9  vmovaps [rsp+0x20], xmm2
000079f9de5d3fbf  vmovaps [rsp+0x30], xmm3
000079f9de5d3fc5  vmovaps [rsp+0x40], xmm4
000079f9de5d3fcb  vmovaps [rsp+0x50], xmm5
000079f9de5d3fd1  vmovaps [rsp+0x60], xmm6
000079f9de5d3fd7  vmovaps [rsp+0x70], xmm7
000079f9de5d3fdd  vmovaps [rsp+0x80], xmm9
000079f9de5d3fe6  vmovaps [rsp+0x90], xmm10
000079f9de5d3fef  vmovaps [rsp+0xA0], xmm11
000079f9de5d3ff8  vmovaps [rsp+0xB0], xmm12
000079f9de5d4001  vmovaps [rsp+0xC0], xmm13
000079f9de5d400a  vmovaps [rsp+0xD0], xmm14
000079f9de5d4013  vmovaps [rsp+0xE0], xmm15
000079f9de5d401c  sub rsp, 0x30
000079f9de5d4020  movaps [rsp], xmm8
000079f9de5d4025  movaps [rsp+0x10], xmm7
000079f9de5d402a  movaps [rsp+0x20], xmm14
000079f9de5d4030  lea rdi, [rsp]
000079f9de5d4034  mov esi, 0x00
000079f9de5d4039  mov rax, 0x56D56FF59530
000079f9de5d4043  call rax
000079f9de5d4045  movaps xmm8, [rsp]
000079f9de5d404a  add rsp, 0x30
000079f9de5d404e  vmovaps xmm0, [rsp]
000079f9de5d4053  vmovaps xmm1, [rsp+0x10]
000079f9de5d4059  vmovaps xmm2, [rsp+0x20]
000079f9de5d405f  vmovaps xmm3, [rsp+0x30]
000079f9de5d4065  vmovaps xmm4, [rsp+0x40]
000079f9de5d406b  vmovaps xmm5, [rsp+0x50]
000079f9de5d4071  vmovaps xmm6, [rsp+0x60]
000079f9de5d4077  vmovaps xmm7, [rsp+0x70]
000079f9de5d407d  vmovaps xmm9, [rsp+0x80]
000079f9de5d4086  vmovaps xmm10, [rsp+0x90]
000079f9de5d408f  vmovaps xmm11, [rsp+0xA0]
000079f9de5d4098  vmovaps xmm12, [rsp+0xB0]
000079f9de5d40a1  vmovaps xmm13, [rsp+0xC0]
000079f9de5d40aa  vmovaps xmm14, [rsp+0xD0]
000079f9de5d40b3  vmovaps xmm15, [rsp+0xE0]
000079f9de5d40bc  add rsp, 0xF0
000079f9de5d40c3  pop r11
000079f9de5d40c5  pop r10
000079f9de5d40c7  pop r9
000079f9de5d40c9  pop r8
000079f9de5d40cb  pop rsi
000079f9de5d40cc  pop rdi
000079f9de5d40cd  pop rdx
000079f9de5d40ce  pop rcx
000079f9de5d40cf  pop rax
000079f9de5d40d0  add rsp, 0x08
000079f9de5d40d4  jmp 0x000079F9DE5D0094
000079f9de5d40d9  sub rsp, 0x08
000079f9de5d40dd  push rax
000079f9de5d40de  push rcx
000079f9de5d40df  push rdx
000079f9de5d40e0  push rdi
000079f9de5d40e1  push rsi
000079f9de5d40e2  push r8
000079f9de5d40e4  push r9
000079f9de5d40e6  push r10
000079f9de5d40e8  push r11
000079f9de5d40ea  sub rsp, 0xF0
000079f9de5d40f1  vmovaps [rsp], xmm0
000079f9de5d40f6  vmovaps [rsp+0x10], xmm1
000079f9de5d40fc  vmovaps [rsp+0x20], xmm2
000079f9de5d4102  vmovaps [rsp+0x30], xmm3
000079f9de5d4108  vmovaps [rsp+0x40], xmm4
000079f9de5d410e  vmovaps [rsp+0x50], xmm5
000079f9de5d4114  vmovaps [rsp+0x60], xmm6
000079f9de5d411a  vmovaps [rsp+0x70], xmm7
000079f9de5d4120  vmovaps [rsp+0x80], xmm8
000079f9de5d4129  vmovaps [rsp+0x90], xmm9
000079f9de5d4132  vmovaps [rsp+0xA0], xmm10
000079f9de5d413b  vmovaps [rsp+0xB0], xmm11
000079f9de5d4144  vmovaps [rsp+0xC0], xmm12
000079f9de5d414d  vmovaps [rsp+0xD0], xmm13
000079f9de5d4156  vmovaps [rsp+0xE0], xmm15
000079f9de5d415f  sub rsp, 0x30
000079f9de5d4163  movaps [rsp], xmm14
000079f9de5d4168  movaps [rsp+0x10], xmm12
000079f9de5d416e  movaps [rsp+0x20], xmm9
000079f9de5d4174  lea rdi, [rsp]
000079f9de5d4178  mov esi, 0x00
000079f9de5d417d  mov rax, 0x56D56FF59530
000079f9de5d4187  call rax
000079f9de5d4189  movaps xmm14, [rsp]
000079f9de5d418e  add rsp, 0x30
000079f9de5d4192  vmovaps xmm0, [rsp]
000079f9de5d4197  vmovaps xmm1, [rsp+0x10]
000079f9de5d419d  vmovaps xmm2, [rsp+0x20]
000079f9de5d41a3  vmovaps xmm3, [rsp+0x30]
000079f9de5d41a9  vmovaps xmm4, [rsp+0x40]
000079f9de5d41af  vmovaps xmm5, [rsp+0x50]
000079f9de5d41b5  vmovaps xmm6, [rsp+0x60]
000079f9de5d41bb  vmovaps xmm7, [rsp+0x70]
000079f9de5d41c1  vmovaps xmm8, [rsp+0x80]
000079f9de5d41ca  vmovaps xmm9, [rsp+0x90]
000079f9de5d41d3  vmovaps xmm10, [rsp+0xA0]
000079f9de5d41dc  vmovaps xmm11, [rsp+0xB0]
000079f9de5d41e5  vmovaps xmm12, [rsp+0xC0]
000079f9de5d41ee  vmovaps xmm13, [rsp+0xD0]
000079f9de5d41f7  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4200  add rsp, 0xF0
000079f9de5d4207  pop r11
000079f9de5d4209  pop r10
000079f9de5d420b  pop r9
000079f9de5d420d  pop r8
000079f9de5d420f  pop rsi
000079f9de5d4210  pop rdi
000079f9de5d4211  pop rdx
000079f9de5d4212  pop rcx
000079f9de5d4213  pop rax
000079f9de5d4214  add rsp, 0x08
000079f9de5d4218  jmp 0x000079F9DE5D00AE
000079f9de5d421d  sub rsp, 0x08
000079f9de5d4221  push rax
000079f9de5d4222  push rcx
000079f9de5d4223  push rdx
000079f9de5d4224  push rdi
000079f9de5d4225  push rsi
000079f9de5d4226  push r8
000079f9de5d4228  push r9
000079f9de5d422a  push r10
000079f9de5d422c  push r11
000079f9de5d422e  sub rsp, 0xF0
000079f9de5d4235  vmovaps [rsp], xmm0
000079f9de5d423a  vmovaps [rsp+0x10], xmm1
000079f9de5d4240  vmovaps [rsp+0x20], xmm2
000079f9de5d4246  vmovaps [rsp+0x30], xmm3
000079f9de5d424c  vmovaps [rsp+0x40], xmm4
000079f9de5d4252  vmovaps [rsp+0x50], xmm5
000079f9de5d4258  vmovaps [rsp+0x60], xmm6
000079f9de5d425e  vmovaps [rsp+0x70], xmm7
000079f9de5d4264  vmovaps [rsp+0x80], xmm8
000079f9de5d426d  vmovaps [rsp+0x90], xmm10
000079f9de5d4276  vmovaps [rsp+0xA0], xmm11
000079f9de5d427f  vmovaps [rsp+0xB0], xmm12
000079f9de5d4288  vmovaps [rsp+0xC0], xmm13
000079f9de5d4291  vmovaps [rsp+0xD0], xmm14
000079f9de5d429a  vmovaps [rsp+0xE0], xmm15
000079f9de5d42a3  sub rsp, 0x30
000079f9de5d42a7  movaps [rsp], xmm9
000079f9de5d42ac  movaps [rsp+0x10], xmm7
000079f9de5d42b1  movaps [rsp+0x20], xmm12
000079f9de5d42b7  lea rdi, [rsp]
000079f9de5d42bb  mov esi, 0x00
000079f9de5d42c0  mov rax, 0x56D56FF59530
000079f9de5d42ca  call rax
000079f9de5d42cc  movaps xmm9, [rsp]
000079f9de5d42d1  add rsp, 0x30
000079f9de5d42d5  vmovaps xmm0, [rsp]
000079f9de5d42da  vmovaps xmm1, [rsp+0x10]
000079f9de5d42e0  vmovaps xmm2, [rsp+0x20]
000079f9de5d42e6  vmovaps xmm3, [rsp+0x30]
000079f9de5d42ec  vmovaps xmm4, [rsp+0x40]
000079f9de5d42f2  vmovaps xmm5, [rsp+0x50]
000079f9de5d42f8  vmovaps xmm6, [rsp+0x60]
000079f9de5d42fe  vmovaps xmm7, [rsp+0x70]
000079f9de5d4304  vmovaps xmm8, [rsp+0x80]
000079f9de5d430d  vmovaps xmm10, [rsp+0x90]
000079f9de5d4316  vmovaps xmm11, [rsp+0xA0]
000079f9de5d431f  vmovaps xmm12, [rsp+0xB0]
000079f9de5d4328  vmovaps xmm13, [rsp+0xC0]
000079f9de5d4331  vmovaps xmm14, [rsp+0xD0]
000079f9de5d433a  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4343  add rsp, 0xF0
000079f9de5d434a  pop r11
000079f9de5d434c  pop r10
000079f9de5d434e  pop r9
000079f9de5d4350  pop r8
000079f9de5d4352  pop rsi
000079f9de5d4353  pop rdi
000079f9de5d4354  pop rdx
000079f9de5d4355  pop rcx
000079f9de5d4356  pop rax
000079f9de5d4357  add rsp, 0x08
000079f9de5d435b  jmp 0x000079F9DE5D00DD
000079f9de5d4360  sub rsp, 0x08
000079f9de5d4364  push rax
000079f9de5d4365  push rcx
000079f9de5d4366  push rdx
000079f9de5d4367  push rdi
000079f9de5d4368  push rsi
000079f9de5d4369  push r8
000079f9de5d436b  push r9
000079f9de5d436d  push r10
000079f9de5d436f  push r11
000079f9de5d4371  sub rsp, 0xF0
000079f9de5d4378  vmovaps [rsp], xmm0
000079f9de5d437d  vmovaps [rsp+0x10], xmm1
000079f9de5d4383  vmovaps [rsp+0x20], xmm2
000079f9de5d4389  vmovaps [rsp+0x30], xmm3
000079f9de5d438f  vmovaps [rsp+0x40], xmm4
000079f9de5d4395  vmovaps [rsp+0x50], xmm5
000079f9de5d439b  vmovaps [rsp+0x60], xmm6
000079f9de5d43a1  vmovaps [rsp+0x70], xmm7
000079f9de5d43a7  vmovaps [rsp+0x80], xmm8
000079f9de5d43b0  vmovaps [rsp+0x90], xmm9
000079f9de5d43b9  vmovaps [rsp+0xA0], xmm10
000079f9de5d43c2  vmovaps [rsp+0xB0], xmm11
000079f9de5d43cb  vmovaps [rsp+0xC0], xmm13
000079f9de5d43d4  vmovaps [rsp+0xD0], xmm14
000079f9de5d43dd  vmovaps [rsp+0xE0], xmm15
000079f9de5d43e6  sub rsp, 0x30
000079f9de5d43ea  movaps [rsp], xmm12
000079f9de5d43ef  movaps [rsp+0x10], xmm15
000079f9de5d43f5  movaps [rsp+0x20], xmm11
000079f9de5d43fb  lea rdi, [rsp]
000079f9de5d43ff  mov esi, 0x00
000079f9de5d4404  mov rax, 0x56D56FF59530
000079f9de5d440e  call rax
000079f9de5d4410  movaps xmm12, [rsp]
000079f9de5d4415  add rsp, 0x30
000079f9de5d4419  vmovaps xmm0, [rsp]
000079f9de5d441e  vmovaps xmm1, [rsp+0x10]
000079f9de5d4424  vmovaps xmm2, [rsp+0x20]
000079f9de5d442a  vmovaps xmm3, [rsp+0x30]
000079f9de5d4430  vmovaps xmm4, [rsp+0x40]
000079f9de5d4436  vmovaps xmm5, [rsp+0x50]
000079f9de5d443c  vmovaps xmm6, [rsp+0x60]
000079f9de5d4442  vmovaps xmm7, [rsp+0x70]
000079f9de5d4448  vmovaps xmm8, [rsp+0x80]
000079f9de5d4451  vmovaps xmm9, [rsp+0x90]
000079f9de5d445a  vmovaps xmm10, [rsp+0xA0]
000079f9de5d4463  vmovaps xmm11, [rsp+0xB0]
000079f9de5d446c  vmovaps xmm13, [rsp+0xC0]
000079f9de5d4475  vmovaps xmm14, [rsp+0xD0]
000079f9de5d447e  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4487  add rsp, 0xF0
000079f9de5d448e  pop r11
000079f9de5d4490  pop r10
000079f9de5d4492  pop r9
000079f9de5d4494  pop r8
000079f9de5d4496  pop rsi
000079f9de5d4497  pop rdi
000079f9de5d4498  pop rdx
000079f9de5d4499  pop rcx
000079f9de5d449a  pop rax
000079f9de5d449b  add rsp, 0x08
000079f9de5d449f  jmp 0x000079F9DE5D00F7
000079f9de5d44a4  sub rsp, 0x08
000079f9de5d44a8  push rax
000079f9de5d44a9  push rcx
000079f9de5d44aa  push rdx
000079f9de5d44ab  push rdi
000079f9de5d44ac  push rsi
000079f9de5d44ad  push r8
000079f9de5d44af  push r9
000079f9de5d44b1  push r10
000079f9de5d44b3  push r11
000079f9de5d44b5  sub rsp, 0xF0
000079f9de5d44bc  vmovaps [rsp], xmm0
000079f9de5d44c1  vmovaps [rsp+0x10], xmm1
000079f9de5d44c7  vmovaps [rsp+0x20], xmm2
000079f9de5d44cd  vmovaps [rsp+0x30], xmm3
000079f9de5d44d3  vmovaps [rsp+0x40], xmm4
000079f9de5d44d9  vmovaps [rsp+0x50], xmm5
000079f9de5d44df  vmovaps [rsp+0x60], xmm6
000079f9de5d44e5  vmovaps [rsp+0x70], xmm7
000079f9de5d44eb  vmovaps [rsp+0x80], xmm8
000079f9de5d44f4  vmovaps [rsp+0x90], xmm9
000079f9de5d44fd  vmovaps [rsp+0xA0], xmm10
000079f9de5d4506  vmovaps [rsp+0xB0], xmm12
000079f9de5d450f  vmovaps [rsp+0xC0], xmm13
000079f9de5d4518  vmovaps [rsp+0xD0], xmm14
000079f9de5d4521  vmovaps [rsp+0xE0], xmm15
000079f9de5d452a  sub rsp, 0x30
000079f9de5d452e  movaps [rsp], xmm11
000079f9de5d4533  movaps [rsp+0x10], xmm7
000079f9de5d4538  movaps [rsp+0x20], xmm15
000079f9de5d453e  lea rdi, [rsp]
000079f9de5d4542  mov esi, 0x00
000079f9de5d4547  mov rax, 0x56D56FF59530
000079f9de5d4551  call rax
000079f9de5d4553  movaps xmm11, [rsp]
000079f9de5d4558  add rsp, 0x30
000079f9de5d455c  vmovaps xmm0, [rsp]
000079f9de5d4561  vmovaps xmm1, [rsp+0x10]
000079f9de5d4567  vmovaps xmm2, [rsp+0x20]
000079f9de5d456d  vmovaps xmm3, [rsp+0x30]
000079f9de5d4573  vmovaps xmm4, [rsp+0x40]
000079f9de5d4579  vmovaps xmm5, [rsp+0x50]
000079f9de5d457f  vmovaps xmm6, [rsp+0x60]
000079f9de5d4585  vmovaps xmm7, [rsp+0x70]
000079f9de5d458b  vmovaps xmm8, [rsp+0x80]
000079f9de5d4594  vmovaps xmm9, [rsp+0x90]
000079f9de5d459d  vmovaps xmm10, [rsp+0xA0]
000079f9de5d45a6  vmovaps xmm12, [rsp+0xB0]
000079f9de5d45af  vmovaps xmm13, [rsp+0xC0]
000079f9de5d45b8  vmovaps xmm14, [rsp+0xD0]
000079f9de5d45c1  vmovaps xmm15, [rsp+0xE0]
000079f9de5d45ca  add rsp, 0xF0
000079f9de5d45d1  pop r11
000079f9de5d45d3  pop r10
000079f9de5d45d5  pop r9
000079f9de5d45d7  pop r8
000079f9de5d45d9  pop rsi
000079f9de5d45da  pop rdi
000079f9de5d45db  pop rdx
000079f9de5d45dc  pop rcx
000079f9de5d45dd  pop rax
000079f9de5d45de  add rsp, 0x08
000079f9de5d45e2  jmp 0x000079F9DE5D0123
000079f9de5d45e7  sub rsp, 0x08
000079f9de5d45eb  push rax
000079f9de5d45ec  push rcx
000079f9de5d45ed  push rdx
000079f9de5d45ee  push rdi
000079f9de5d45ef  push rsi
000079f9de5d45f0  push r8
000079f9de5d45f2  push r9
000079f9de5d45f4  push r10
000079f9de5d45f6  push r11
000079f9de5d45f8  sub rsp, 0xF0
000079f9de5d45ff  vmovaps [rsp], xmm0
000079f9de5d4604  vmovaps [rsp+0x10], xmm1
000079f9de5d460a  vmovaps [rsp+0x20], xmm2
000079f9de5d4610  vmovaps [rsp+0x30], xmm3
000079f9de5d4616  vmovaps [rsp+0x40], xmm4
000079f9de5d461c  vmovaps [rsp+0x50], xmm5
000079f9de5d4622  vmovaps [rsp+0x60], xmm6
000079f9de5d4628  vmovaps [rsp+0x70], xmm7
000079f9de5d462e  vmovaps [rsp+0x80], xmm8
000079f9de5d4637  vmovaps [rsp+0x90], xmm9
000079f9de5d4640  vmovaps [rsp+0xA0], xmm10
000079f9de5d4649  vmovaps [rsp+0xB0], xmm11
000079f9de5d4652  vmovaps [rsp+0xC0], xmm12
000079f9de5d465b  vmovaps [rsp+0xD0], xmm13
000079f9de5d4664  vmovaps [rsp+0xE0], xmm14
000079f9de5d466d  sub rsp, 0x30
000079f9de5d4671  movaps [rsp], xmm15
000079f9de5d4676  movaps [rsp+0x10], xmm10
000079f9de5d467c  movaps [rsp+0x20], xmm13
000079f9de5d4682  lea rdi, [rsp]
000079f9de5d4686  mov esi, 0x00
000079f9de5d468b  mov rax, 0x56D56FF59530
000079f9de5d4695  call rax
000079f9de5d4697  movaps xmm15, [rsp]
000079f9de5d469c  add rsp, 0x30
000079f9de5d46a0  vmovaps xmm0, [rsp]
000079f9de5d46a5  vmovaps xmm1, [rsp+0x10]
000079f9de5d46ab  vmovaps xmm2, [rsp+0x20]
000079f9de5d46b1  vmovaps xmm3, [rsp+0x30]
000079f9de5d46b7  vmovaps xmm4, [rsp+0x40]
000079f9de5d46bd  vmovaps xmm5, [rsp+0x50]
000079f9de5d46c3  vmovaps xmm6, [rsp+0x60]
000079f9de5d46c9  vmovaps xmm7, [rsp+0x70]
000079f9de5d46cf  vmovaps xmm8, [rsp+0x80]
000079f9de5d46d8  vmovaps xmm9, [rsp+0x90]
000079f9de5d46e1  vmovaps xmm10, [rsp+0xA0]
000079f9de5d46ea  vmovaps xmm11, [rsp+0xB0]
000079f9de5d46f3  vmovaps xmm12, [rsp+0xC0]
000079f9de5d46fc  vmovaps xmm13, [rsp+0xD0]
000079f9de5d4705  vmovaps xmm14, [rsp+0xE0]
000079f9de5d470e  add rsp, 0xF0
000079f9de5d4715  pop r11
000079f9de5d4717  pop r10
000079f9de5d4719  pop r9
000079f9de5d471b  pop r8
000079f9de5d471d  pop rsi
000079f9de5d471e  pop rdi
000079f9de5d471f  pop rdx
000079f9de5d4720  pop rcx
000079f9de5d4721  pop rax
000079f9de5d4722  add rsp, 0x08
000079f9de5d4726  jmp 0x000079F9DE5D013D
000079f9de5d472b  sub rsp, 0x08
000079f9de5d472f  push rax
000079f9de5d4730  push rcx
000079f9de5d4731  push rdx
000079f9de5d4732  push rdi
000079f9de5d4733  push rsi
000079f9de5d4734  push r8
000079f9de5d4736  push r9
000079f9de5d4738  push r10
000079f9de5d473a  push r11
000079f9de5d473c  sub rsp, 0xF0
000079f9de5d4743  vmovaps [rsp], xmm0
000079f9de5d4748  vmovaps [rsp+0x10], xmm1
000079f9de5d474e  vmovaps [rsp+0x20], xmm2
000079f9de5d4754  vmovaps [rsp+0x30], xmm3
000079f9de5d475a  vmovaps [rsp+0x40], xmm4
000079f9de5d4760  vmovaps [rsp+0x50], xmm5
000079f9de5d4766  vmovaps [rsp+0x60], xmm6
000079f9de5d476c  vmovaps [rsp+0x70], xmm7
000079f9de5d4772  vmovaps [rsp+0x80], xmm8
000079f9de5d477b  vmovaps [rsp+0x90], xmm9
000079f9de5d4784  vmovaps [rsp+0xA0], xmm11
000079f9de5d478d  vmovaps [rsp+0xB0], xmm12
000079f9de5d4796  vmovaps [rsp+0xC0], xmm13
000079f9de5d479f  vmovaps [rsp+0xD0], xmm14
000079f9de5d47a8  vmovaps [rsp+0xE0], xmm15
000079f9de5d47b1  sub rsp, 0x30
000079f9de5d47b5  movaps [rsp], xmm10
000079f9de5d47ba  movaps [rsp+0x10], xmm7
000079f9de5d47bf  movaps [rsp+0x20], xmm13
000079f9de5d47c5  lea rdi, [rsp]
000079f9de5d47c9  mov esi, 0x00
000079f9de5d47ce  mov rax, 0x56D56FF59530
000079f9de5d47d8  call rax
000079f9de5d47da  movaps xmm10, [rsp]
000079f9de5d47df  add rsp, 0x30
000079f9de5d47e3  vmovaps xmm0, [rsp]
000079f9de5d47e8  vmovaps xmm1, [rsp+0x10]
000079f9de5d47ee  vmovaps xmm2, [rsp+0x20]
000079f9de5d47f4  vmovaps xmm3, [rsp+0x30]
000079f9de5d47fa  vmovaps xmm4, [rsp+0x40]
000079f9de5d4800  vmovaps xmm5, [rsp+0x50]
000079f9de5d4806  vmovaps xmm6, [rsp+0x60]
000079f9de5d480c  vmovaps xmm7, [rsp+0x70]
000079f9de5d4812  vmovaps xmm8, [rsp+0x80]
000079f9de5d481b  vmovaps xmm9, [rsp+0x90]
000079f9de5d4824  vmovaps xmm11, [rsp+0xA0]
000079f9de5d482d  vmovaps xmm12, [rsp+0xB0]
000079f9de5d4836  vmovaps xmm13, [rsp+0xC0]
000079f9de5d483f  vmovaps xmm14, [rsp+0xD0]
000079f9de5d4848  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4851  add rsp, 0xF0
000079f9de5d4858  pop r11
000079f9de5d485a  pop r10
000079f9de5d485c  pop r9
000079f9de5d485e  pop r8
000079f9de5d4860  pop rsi
000079f9de5d4861  pop rdi
000079f9de5d4862  pop rdx
000079f9de5d4863  pop rcx
000079f9de5d4864  pop rax
000079f9de5d4865  add rsp, 0x08
000079f9de5d4869  jmp 0x000079F9DE5D0169
000079f9de5d486e  sub rsp, 0x08
000079f9de5d4872  push rax
000079f9de5d4873  push rcx
000079f9de5d4874  push rdx
000079f9de5d4875  push rdi
000079f9de5d4876  push rsi
000079f9de5d4877  push r8
000079f9de5d4879  push r9
000079f9de5d487b  push r10
000079f9de5d487d  push r11
000079f9de5d487f  sub rsp, 0xF0
000079f9de5d4886  vmovaps [rsp], xmm0
000079f9de5d488b  vmovaps [rsp+0x10], xmm1
000079f9de5d4891  vmovaps [rsp+0x20], xmm2
000079f9de5d4897  vmovaps [rsp+0x30], xmm3
000079f9de5d489d  vmovaps [rsp+0x40], xmm4
000079f9de5d48a3  vmovaps [rsp+0x50], xmm5
000079f9de5d48a9  vmovaps [rsp+0x60], xmm6
000079f9de5d48af  vmovaps [rsp+0x70], xmm7
000079f9de5d48b5  vmovaps [rsp+0x80], xmm8
000079f9de5d48be  vmovaps [rsp+0x90], xmm9
000079f9de5d48c7  vmovaps [rsp+0xA0], xmm10
000079f9de5d48d0  vmovaps [rsp+0xB0], xmm11
000079f9de5d48d9  vmovaps [rsp+0xC0], xmm12
000079f9de5d48e2  vmovaps [rsp+0xD0], xmm14
000079f9de5d48eb  vmovaps [rsp+0xE0], xmm15
000079f9de5d48f4  sub rsp, 0x30
000079f9de5d48f8  movaps [rsp], xmm13
000079f9de5d48fd  movaps [rsp+0x10], xmm1
000079f9de5d4902  movaps [rsp+0x20], xmm8
000079f9de5d4908  lea rdi, [rsp]
000079f9de5d490c  mov esi, 0x00
000079f9de5d4911  mov rax, 0x56D56FF59530
000079f9de5d491b  call rax
000079f9de5d491d  movaps xmm13, [rsp]
000079f9de5d4922  add rsp, 0x30
000079f9de5d4926  vmovaps xmm0, [rsp]
000079f9de5d492b  vmovaps xmm1, [rsp+0x10]
000079f9de5d4931  vmovaps xmm2, [rsp+0x20]
000079f9de5d4937  vmovaps xmm3, [rsp+0x30]
000079f9de5d493d  vmovaps xmm4, [rsp+0x40]
000079f9de5d4943  vmovaps xmm5, [rsp+0x50]
000079f9de5d4949  vmovaps xmm6, [rsp+0x60]
000079f9de5d494f  vmovaps xmm7, [rsp+0x70]
000079f9de5d4955  vmovaps xmm8, [rsp+0x80]
000079f9de5d495e  vmovaps xmm9, [rsp+0x90]
000079f9de5d4967  vmovaps xmm10, [rsp+0xA0]
000079f9de5d4970  vmovaps xmm11, [rsp+0xB0]
000079f9de5d4979  vmovaps xmm12, [rsp+0xC0]
000079f9de5d4982  vmovaps xmm14, [rsp+0xD0]
000079f9de5d498b  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4994  add rsp, 0xF0
000079f9de5d499b  pop r11
000079f9de5d499d  pop r10
000079f9de5d499f  pop r9
000079f9de5d49a1  pop r8
000079f9de5d49a3  pop rsi
000079f9de5d49a4  pop rdi
000079f9de5d49a5  pop rdx
000079f9de5d49a6  pop rcx
000079f9de5d49a7  pop rax
000079f9de5d49a8  add rsp, 0x08
000079f9de5d49ac  jmp 0x000079F9DE5D0183
000079f9de5d49b1  call 0x000079F9DE3FF430
000079f9de5d49b6  jmp 0x000079F9DE5D018D
000079f9de5d49bb  sub rsp, 0x08
000079f9de5d49bf  push rax
000079f9de5d49c0  push rcx
000079f9de5d49c1  push rdx
000079f9de5d49c2  push rdi
000079f9de5d49c3  push rsi
000079f9de5d49c4  push r8
000079f9de5d49c6  push r9
000079f9de5d49c8  push r10
000079f9de5d49ca  push r11
000079f9de5d49cc  sub rsp, 0xF0
000079f9de5d49d3  vmovaps [rsp], xmm0
000079f9de5d49d8  vmovaps [rsp+0x10], xmm1
000079f9de5d49de  vmovaps [rsp+0x20], xmm2
000079f9de5d49e4  vmovaps [rsp+0x30], xmm3
000079f9de5d49ea  vmovaps [rsp+0x40], xmm4
000079f9de5d49f0  vmovaps [rsp+0x50], xmm5
000079f9de5d49f6  vmovaps [rsp+0x60], xmm6
000079f9de5d49fc  vmovaps [rsp+0x70], xmm7
000079f9de5d4a02  vmovaps [rsp+0x80], xmm9
000079f9de5d4a0b  vmovaps [rsp+0x90], xmm10
000079f9de5d4a14  vmovaps [rsp+0xA0], xmm11
000079f9de5d4a1d  vmovaps [rsp+0xB0], xmm12
000079f9de5d4a26  vmovaps [rsp+0xC0], xmm13
000079f9de5d4a2f  vmovaps [rsp+0xD0], xmm14
000079f9de5d4a38  vmovaps [rsp+0xE0], xmm15
000079f9de5d4a41  sub rsp, 0x30
000079f9de5d4a45  movaps [rsp], xmm8
000079f9de5d4a4a  movaps [rsp+0x10], xmm14
000079f9de5d4a50  movaps [rsp+0x20], xmm9
000079f9de5d4a56  lea rdi, [rsp]
000079f9de5d4a5a  mov esi, 0x00
000079f9de5d4a5f  mov rax, 0x56D56FF59530
000079f9de5d4a69  call rax
000079f9de5d4a6b  movaps xmm8, [rsp]
000079f9de5d4a70  add rsp, 0x30
000079f9de5d4a74  vmovaps xmm0, [rsp]
000079f9de5d4a79  vmovaps xmm1, [rsp+0x10]
000079f9de5d4a7f  vmovaps xmm2, [rsp+0x20]
000079f9de5d4a85  vmovaps xmm3, [rsp+0x30]
000079f9de5d4a8b  vmovaps xmm4, [rsp+0x40]
000079f9de5d4a91  vmovaps xmm5, [rsp+0x50]
000079f9de5d4a97  vmovaps xmm6, [rsp+0x60]
000079f9de5d4a9d  vmovaps xmm7, [rsp+0x70]
000079f9de5d4aa3  vmovaps xmm9, [rsp+0x80]
000079f9de5d4aac  vmovaps xmm10, [rsp+0x90]
000079f9de5d4ab5  vmovaps xmm11, [rsp+0xA0]
000079f9de5d4abe  vmovaps xmm12, [rsp+0xB0]
000079f9de5d4ac7  vmovaps xmm13, [rsp+0xC0]
000079f9de5d4ad0  vmovaps xmm14, [rsp+0xD0]
000079f9de5d4ad9  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4ae2  add rsp, 0xF0
000079f9de5d4ae9  pop r11
000079f9de5d4aeb  pop r10
000079f9de5d4aed  pop r9
000079f9de5d4aef  pop r8
000079f9de5d4af1  pop rsi
000079f9de5d4af2  pop rdi
000079f9de5d4af3  pop rdx
000079f9de5d4af4  pop rcx
000079f9de5d4af5  pop rax
000079f9de5d4af6  add rsp, 0x08
000079f9de5d4afa  jmp 0x000079F9DE5D01AF
000079f9de5d4aff  sub rsp, 0x08
000079f9de5d4b03  push rax
000079f9de5d4b04  push rcx
000079f9de5d4b05  push rdx
000079f9de5d4b06  push rdi
000079f9de5d4b07  push rsi
000079f9de5d4b08  push r8
000079f9de5d4b0a  push r9
000079f9de5d4b0c  push r10
000079f9de5d4b0e  push r11
000079f9de5d4b10  sub rsp, 0xF0
000079f9de5d4b17  vmovaps [rsp], xmm0
000079f9de5d4b1c  vmovaps [rsp+0x10], xmm1
000079f9de5d4b22  vmovaps [rsp+0x20], xmm2
000079f9de5d4b28  vmovaps [rsp+0x30], xmm3
000079f9de5d4b2e  vmovaps [rsp+0x40], xmm4
000079f9de5d4b34  vmovaps [rsp+0x50], xmm5
000079f9de5d4b3a  vmovaps [rsp+0x60], xmm6
000079f9de5d4b40  vmovaps [rsp+0x70], xmm7
000079f9de5d4b46  vmovaps [rsp+0x80], xmm8
000079f9de5d4b4f  vmovaps [rsp+0x90], xmm10
000079f9de5d4b58  vmovaps [rsp+0xA0], xmm11
000079f9de5d4b61  vmovaps [rsp+0xB0], xmm12
000079f9de5d4b6a  vmovaps [rsp+0xC0], xmm13
000079f9de5d4b73  vmovaps [rsp+0xD0], xmm14
000079f9de5d4b7c  vmovaps [rsp+0xE0], xmm15
000079f9de5d4b85  sub rsp, 0x30
000079f9de5d4b89  movaps [rsp], xmm9
000079f9de5d4b8e  movaps [rsp+0x10], xmm1
000079f9de5d4b93  movaps [rsp+0x20], xmm14
000079f9de5d4b99  lea rdi, [rsp]
000079f9de5d4b9d  mov esi, 0x00
000079f9de5d4ba2  mov rax, 0x56D56FF59530
000079f9de5d4bac  call rax
000079f9de5d4bae  movaps xmm9, [rsp]
000079f9de5d4bb3  add rsp, 0x30
000079f9de5d4bb7  vmovaps xmm0, [rsp]
000079f9de5d4bbc  vmovaps xmm1, [rsp+0x10]
000079f9de5d4bc2  vmovaps xmm2, [rsp+0x20]
000079f9de5d4bc8  vmovaps xmm3, [rsp+0x30]
000079f9de5d4bce  vmovaps xmm4, [rsp+0x40]
000079f9de5d4bd4  vmovaps xmm5, [rsp+0x50]
000079f9de5d4bda  vmovaps xmm6, [rsp+0x60]
000079f9de5d4be0  vmovaps xmm7, [rsp+0x70]
000079f9de5d4be6  vmovaps xmm8, [rsp+0x80]
000079f9de5d4bef  vmovaps xmm10, [rsp+0x90]
000079f9de5d4bf8  vmovaps xmm11, [rsp+0xA0]
000079f9de5d4c01  vmovaps xmm12, [rsp+0xB0]
000079f9de5d4c0a  vmovaps xmm13, [rsp+0xC0]
000079f9de5d4c13  vmovaps xmm14, [rsp+0xD0]
000079f9de5d4c1c  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4c25  add rsp, 0xF0
000079f9de5d4c2c  pop r11
000079f9de5d4c2e  pop r10
000079f9de5d4c30  pop r9
000079f9de5d4c32  pop r8
000079f9de5d4c34  pop rsi
000079f9de5d4c35  pop rdi
000079f9de5d4c36  pop rdx
000079f9de5d4c37  pop rcx
000079f9de5d4c38  pop rax
000079f9de5d4c39  add rsp, 0x08
000079f9de5d4c3d  jmp 0x000079F9DE5D01DD
000079f9de5d4c42  sub rsp, 0x08
000079f9de5d4c46  push rax
000079f9de5d4c47  push rcx
000079f9de5d4c48  push rdx
000079f9de5d4c49  push rdi
000079f9de5d4c4a  push rsi
000079f9de5d4c4b  push r8
000079f9de5d4c4d  push r9
000079f9de5d4c4f  push r10
000079f9de5d4c51  push r11
000079f9de5d4c53  sub rsp, 0xF0
000079f9de5d4c5a  vmovaps [rsp], xmm0
000079f9de5d4c5f  vmovaps [rsp+0x10], xmm1
000079f9de5d4c65  vmovaps [rsp+0x20], xmm2
000079f9de5d4c6b  vmovaps [rsp+0x30], xmm3
000079f9de5d4c71  vmovaps [rsp+0x40], xmm4
000079f9de5d4c77  vmovaps [rsp+0x50], xmm5
000079f9de5d4c7d  vmovaps [rsp+0x60], xmm6
000079f9de5d4c83  vmovaps [rsp+0x70], xmm7
000079f9de5d4c89  vmovaps [rsp+0x80], xmm8
000079f9de5d4c92  vmovaps [rsp+0x90], xmm9
000079f9de5d4c9b  vmovaps [rsp+0xA0], xmm10
000079f9de5d4ca4  vmovaps [rsp+0xB0], xmm11
000079f9de5d4cad  vmovaps [rsp+0xC0], xmm12
000079f9de5d4cb6  vmovaps [rsp+0xD0], xmm13
000079f9de5d4cbf  vmovaps [rsp+0xE0], xmm15
000079f9de5d4cc8  sub rsp, 0x30
000079f9de5d4ccc  movaps [rsp], xmm14
000079f9de5d4cd1  movaps [rsp+0x10], xmm4
000079f9de5d4cd6  movaps [rsp+0x20], xmm1
000079f9de5d4cdb  lea rdi, [rsp]
000079f9de5d4cdf  mov esi, 0x00
000079f9de5d4ce4  mov rax, 0x56D56FF59530
000079f9de5d4cee  call rax
000079f9de5d4cf0  movaps xmm14, [rsp]
000079f9de5d4cf5  add rsp, 0x30
000079f9de5d4cf9  vmovaps xmm0, [rsp]
000079f9de5d4cfe  vmovaps xmm1, [rsp+0x10]
000079f9de5d4d04  vmovaps xmm2, [rsp+0x20]
000079f9de5d4d0a  vmovaps xmm3, [rsp+0x30]
000079f9de5d4d10  vmovaps xmm4, [rsp+0x40]
000079f9de5d4d16  vmovaps xmm5, [rsp+0x50]
000079f9de5d4d1c  vmovaps xmm6, [rsp+0x60]
000079f9de5d4d22  vmovaps xmm7, [rsp+0x70]
000079f9de5d4d28  vmovaps xmm8, [rsp+0x80]
000079f9de5d4d31  vmovaps xmm9, [rsp+0x90]
000079f9de5d4d3a  vmovaps xmm10, [rsp+0xA0]
000079f9de5d4d43  vmovaps xmm11, [rsp+0xB0]
000079f9de5d4d4c  vmovaps xmm12, [rsp+0xC0]
000079f9de5d4d55  vmovaps xmm13, [rsp+0xD0]
000079f9de5d4d5e  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4d67  add rsp, 0xF0
000079f9de5d4d6e  pop r11
000079f9de5d4d70  pop r10
000079f9de5d4d72  pop r9
000079f9de5d4d74  pop r8
000079f9de5d4d76  pop rsi
000079f9de5d4d77  pop rdi
000079f9de5d4d78  pop rdx
000079f9de5d4d79  pop rcx
000079f9de5d4d7a  pop rax
000079f9de5d4d7b  add rsp, 0x08
000079f9de5d4d7f  jmp 0x000079F9DE5D0203
000079f9de5d4d84  sub rsp, 0x08
000079f9de5d4d88  push rax
000079f9de5d4d89  push rcx
000079f9de5d4d8a  push rdx
000079f9de5d4d8b  push rdi
000079f9de5d4d8c  push rsi
000079f9de5d4d8d  push r8
000079f9de5d4d8f  push r9
000079f9de5d4d91  push r10
000079f9de5d4d93  push r11
000079f9de5d4d95  sub rsp, 0xF0
000079f9de5d4d9c  vmovaps [rsp], xmm0
000079f9de5d4da1  vmovaps [rsp+0x10], xmm2
000079f9de5d4da7  vmovaps [rsp+0x20], xmm3
000079f9de5d4dad  vmovaps [rsp+0x30], xmm4
000079f9de5d4db3  vmovaps [rsp+0x40], xmm5
000079f9de5d4db9  vmovaps [rsp+0x50], xmm6
000079f9de5d4dbf  vmovaps [rsp+0x60], xmm7
000079f9de5d4dc5  vmovaps [rsp+0x70], xmm8
000079f9de5d4dcb  vmovaps [rsp+0x80], xmm9
000079f9de5d4dd4  vmovaps [rsp+0x90], xmm10
000079f9de5d4ddd  vmovaps [rsp+0xA0], xmm11
000079f9de5d4de6  vmovaps [rsp+0xB0], xmm12
000079f9de5d4def  vmovaps [rsp+0xC0], xmm13
000079f9de5d4df8  vmovaps [rsp+0xD0], xmm14
000079f9de5d4e01  vmovaps [rsp+0xE0], xmm15
000079f9de5d4e0a  sub rsp, 0x30
000079f9de5d4e0e  movaps [rsp], xmm1
000079f9de5d4e12  movaps [rsp+0x10], xmm12
000079f9de5d4e18  movaps [rsp+0x20], xmm11
000079f9de5d4e1e  lea rdi, [rsp]
000079f9de5d4e22  mov esi, 0x00
000079f9de5d4e27  mov rax, 0x56D56FF59530
000079f9de5d4e31  call rax
000079f9de5d4e33  movaps xmm1, [rsp]
000079f9de5d4e37  add rsp, 0x30
000079f9de5d4e3b  vmovaps xmm0, [rsp]
000079f9de5d4e40  vmovaps xmm2, [rsp+0x10]
000079f9de5d4e46  vmovaps xmm3, [rsp+0x20]
000079f9de5d4e4c  vmovaps xmm4, [rsp+0x30]
000079f9de5d4e52  vmovaps xmm5, [rsp+0x40]
000079f9de5d4e58  vmovaps xmm6, [rsp+0x50]
000079f9de5d4e5e  vmovaps xmm7, [rsp+0x60]
000079f9de5d4e64  vmovaps xmm8, [rsp+0x70]
000079f9de5d4e6a  vmovaps xmm9, [rsp+0x80]
000079f9de5d4e73  vmovaps xmm10, [rsp+0x90]
000079f9de5d4e7c  vmovaps xmm11, [rsp+0xA0]
000079f9de5d4e85  vmovaps xmm12, [rsp+0xB0]
000079f9de5d4e8e  vmovaps xmm13, [rsp+0xC0]
000079f9de5d4e97  vmovaps xmm14, [rsp+0xD0]
000079f9de5d4ea0  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4ea9  add rsp, 0xF0
000079f9de5d4eb0  pop r11
000079f9de5d4eb2  pop r10
000079f9de5d4eb4  pop r9
000079f9de5d4eb6  pop r8
000079f9de5d4eb8  pop rsi
000079f9de5d4eb9  pop rdi
000079f9de5d4eba  pop rdx
000079f9de5d4ebb  pop rcx
000079f9de5d4ebc  pop rax
000079f9de5d4ebd  add rsp, 0x08
000079f9de5d4ec1  jmp 0x000079F9DE5D0224
000079f9de5d4ec6  call 0x000079F9DE4E20A0
000079f9de5d4ecb  jmp 0x000079F9DE5D0232
000079f9de5d4ed0  call 0x000079F9DE409D70
000079f9de5d4ed5  jmp 0x000079F9DE5D023C
000079f9de5d4eda  sub rsp, 0x08
000079f9de5d4ede  push rax
000079f9de5d4edf  push rcx
000079f9de5d4ee0  push rdx
000079f9de5d4ee1  push rdi
000079f9de5d4ee2  push rsi
000079f9de5d4ee3  push r8
000079f9de5d4ee5  push r9
000079f9de5d4ee7  push r10
000079f9de5d4ee9  push r11
000079f9de5d4eeb  sub rsp, 0xF0
000079f9de5d4ef2  vmovaps [rsp], xmm0
000079f9de5d4ef7  vmovaps [rsp+0x10], xmm1
000079f9de5d4efd  vmovaps [rsp+0x20], xmm2
000079f9de5d4f03  vmovaps [rsp+0x30], xmm3
000079f9de5d4f09  vmovaps [rsp+0x40], xmm4
000079f9de5d4f0f  vmovaps [rsp+0x50], xmm5
000079f9de5d4f15  vmovaps [rsp+0x60], xmm6
000079f9de5d4f1b  vmovaps [rsp+0x70], xmm8
000079f9de5d4f21  vmovaps [rsp+0x80], xmm9
000079f9de5d4f2a  vmovaps [rsp+0x90], xmm10
000079f9de5d4f33  vmovaps [rsp+0xA0], xmm11
000079f9de5d4f3c  vmovaps [rsp+0xB0], xmm12
000079f9de5d4f45  vmovaps [rsp+0xC0], xmm13
000079f9de5d4f4e  vmovaps [rsp+0xD0], xmm14
000079f9de5d4f57  vmovaps [rsp+0xE0], xmm15
000079f9de5d4f60  sub rsp, 0x30
000079f9de5d4f64  movaps [rsp], xmm7
000079f9de5d4f68  movaps [rsp+0x10], xmm15
000079f9de5d4f6e  movaps [rsp+0x20], xmm10
000079f9de5d4f74  lea rdi, [rsp]
000079f9de5d4f78  mov esi, 0x00
000079f9de5d4f7d  mov rax, 0x56D56FF59530
000079f9de5d4f87  call rax
000079f9de5d4f89  movaps xmm7, [rsp]
000079f9de5d4f8d  add rsp, 0x30
000079f9de5d4f91  vmovaps xmm0, [rsp]
000079f9de5d4f96  vmovaps xmm1, [rsp+0x10]
000079f9de5d4f9c  vmovaps xmm2, [rsp+0x20]
000079f9de5d4fa2  vmovaps xmm3, [rsp+0x30]
000079f9de5d4fa8  vmovaps xmm4, [rsp+0x40]
000079f9de5d4fae  vmovaps xmm5, [rsp+0x50]
000079f9de5d4fb4  vmovaps xmm6, [rsp+0x60]
000079f9de5d4fba  vmovaps xmm8, [rsp+0x70]
000079f9de5d4fc0  vmovaps xmm9, [rsp+0x80]
000079f9de5d4fc9  vmovaps xmm10, [rsp+0x90]
000079f9de5d4fd2  vmovaps xmm11, [rsp+0xA0]
000079f9de5d4fdb  vmovaps xmm12, [rsp+0xB0]
000079f9de5d4fe4  vmovaps xmm13, [rsp+0xC0]
000079f9de5d4fed  vmovaps xmm14, [rsp+0xD0]
000079f9de5d4ff6  vmovaps xmm15, [rsp+0xE0]
000079f9de5d4fff  add rsp, 0xF0
000079f9de5d5006  pop r11
000079f9de5d5008  pop r10
000079f9de5d500a  pop r9
000079f9de5d500c  pop r8
000079f9de5d500e  pop rsi
000079f9de5d500f  pop rdi
000079f9de5d5010  pop rdx
000079f9de5d5011  pop rcx
000079f9de5d5012  pop rax
000079f9de5d5013  add rsp, 0x08
000079f9de5d5017  jmp 0x000079F9DE5D025D
000079f9de5d501c  sub rsp, 0x08
000079f9de5d5020  push rax
000079f9de5d5021  push rcx
000079f9de5d5022  push rdx
000079f9de5d5023  push rdi
000079f9de5d5024  push rsi
000079f9de5d5025  push r8
000079f9de5d5027  push r9
000079f9de5d5029  push r10
000079f9de5d502b  push r11
000079f9de5d502d  sub rsp, 0xF0
000079f9de5d5034  vmovaps [rsp], xmm0
000079f9de5d5039  vmovaps [rsp+0x10], xmm1
000079f9de5d503f  vmovaps [rsp+0x20], xmm2
000079f9de5d5045  vmovaps [rsp+0x30], xmm3
000079f9de5d504b  vmovaps [rsp+0x40], xmm4
000079f9de5d5051  vmovaps [rsp+0x50], xmm5
000079f9de5d5057  vmovaps [rsp+0x60], xmm6
000079f9de5d505d  vmovaps [rsp+0x70], xmm7
000079f9de5d5063  vmovaps [rsp+0x80], xmm8
000079f9de5d506c  vmovaps [rsp+0x90], xmm9
000079f9de5d5075  vmovaps [rsp+0xA0], xmm11
000079f9de5d507e  vmovaps [rsp+0xB0], xmm12
000079f9de5d5087  vmovaps [rsp+0xC0], xmm13
000079f9de5d5090  vmovaps [rsp+0xD0], xmm14
000079f9de5d5099  vmovaps [rsp+0xE0], xmm15
000079f9de5d50a2  sub rsp, 0x30
000079f9de5d50a6  movaps [rsp], xmm10
000079f9de5d50ab  movaps [rsp+0x10], xmm11
000079f9de5d50b1  movaps [rsp+0x20], xmm15
000079f9de5d50b7  lea rdi, [rsp]
000079f9de5d50bb  mov esi, 0x00
000079f9de5d50c0  mov rax, 0x56D56FF59530
000079f9de5d50ca  call rax
000079f9de5d50cc  movaps xmm10, [rsp]
000079f9de5d50d1  add rsp, 0x30
000079f9de5d50d5  vmovaps xmm0, [rsp]
000079f9de5d50da  vmovaps xmm1, [rsp+0x10]
000079f9de5d50e0  vmovaps xmm2, [rsp+0x20]
000079f9de5d50e6  vmovaps xmm3, [rsp+0x30]
000079f9de5d50ec  vmovaps xmm4, [rsp+0x40]
000079f9de5d50f2  vmovaps xmm5, [rsp+0x50]
000079f9de5d50f8  vmovaps xmm6, [rsp+0x60]
000079f9de5d50fe  vmovaps xmm7, [rsp+0x70]
000079f9de5d5104  vmovaps xmm8, [rsp+0x80]
000079f9de5d510d  vmovaps xmm9, [rsp+0x90]
000079f9de5d5116  vmovaps xmm11, [rsp+0xA0]
000079f9de5d511f  vmovaps xmm12, [rsp+0xB0]
000079f9de5d5128  vmovaps xmm13, [rsp+0xC0]
000079f9de5d5131  vmovaps xmm14, [rsp+0xD0]
000079f9de5d513a  vmovaps xmm15, [rsp+0xE0]
000079f9de5d5143  add rsp, 0xF0
000079f9de5d514a  pop r11
000079f9de5d514c  pop r10
000079f9de5d514e  pop r9
000079f9de5d5150  pop r8
000079f9de5d5152  pop rsi
000079f9de5d5153  pop rdi
000079f9de5d5154  pop rdx
000079f9de5d5155  pop rcx
000079f9de5d5156  pop rax
000079f9de5d5157  add rsp, 0x08
000079f9de5d515b  jmp 0x000079F9DE5D028B
000079f9de5d5160  sub rsp, 0x08
000079f9de5d5164  push rax
000079f9de5d5165  push rcx
000079f9de5d5166  push rdx
000079f9de5d5167  push rdi
000079f9de5d5168  push rsi
000079f9de5d5169  push r8
000079f9de5d516b  push r9
000079f9de5d516d  push r10
000079f9de5d516f  push r11
000079f9de5d5171  sub rsp, 0xF0
000079f9de5d5178  vmovaps [rsp], xmm0
000079f9de5d517d  vmovaps [rsp+0x10], xmm1
000079f9de5d5183  vmovaps [rsp+0x20], xmm2
000079f9de5d5189  vmovaps [rsp+0x30], xmm3
000079f9de5d518f  vmovaps [rsp+0x40], xmm4
000079f9de5d5195  vmovaps [rsp+0x50], xmm5
000079f9de5d519b  vmovaps [rsp+0x60], xmm6
000079f9de5d51a1  vmovaps [rsp+0x70], xmm7
000079f9de5d51a7  vmovaps [rsp+0x80], xmm8
000079f9de5d51b0  vmovaps [rsp+0x90], xmm9
000079f9de5d51b9  vmovaps [rsp+0xA0], xmm10
000079f9de5d51c2  vmovaps [rsp+0xB0], xmm12
000079f9de5d51cb  vmovaps [rsp+0xC0], xmm13
000079f9de5d51d4  vmovaps [rsp+0xD0], xmm14
000079f9de5d51dd  vmovaps [rsp+0xE0], xmm15
000079f9de5d51e6  sub rsp, 0x30
000079f9de5d51ea  movaps [rsp], xmm11
000079f9de5d51ef  movaps [rsp+0x10], xmm12
000079f9de5d51f5  movaps [rsp+0x20], xmm15
000079f9de5d51fb  lea rdi, [rsp]
000079f9de5d51ff  mov esi, 0x00
000079f9de5d5204  mov rax, 0x56D56FF59530
000079f9de5d520e  call rax
000079f9de5d5210  movaps xmm11, [rsp]
000079f9de5d5215  add rsp, 0x30
000079f9de5d5219  vmovaps xmm0, [rsp]
000079f9de5d521e  vmovaps xmm1, [rsp+0x10]
000079f9de5d5224  vmovaps xmm2, [rsp+0x20]
000079f9de5d522a  vmovaps xmm3, [rsp+0x30]
000079f9de5d5230  vmovaps xmm4, [rsp+0x40]
000079f9de5d5236  vmovaps xmm5, [rsp+0x50]
000079f9de5d523c  vmovaps xmm6, [rsp+0x60]
000079f9de5d5242  vmovaps xmm7, [rsp+0x70]
000079f9de5d5248  vmovaps xmm8, [rsp+0x80]
000079f9de5d5251  vmovaps xmm9, [rsp+0x90]
000079f9de5d525a  vmovaps xmm10, [rsp+0xA0]
000079f9de5d5263  vmovaps xmm12, [rsp+0xB0]
000079f9de5d526c  vmovaps xmm13, [rsp+0xC0]
000079f9de5d5275  vmovaps xmm14, [rsp+0xD0]
000079f9de5d527e  vmovaps xmm15, [rsp+0xE0]
000079f9de5d5287  add rsp, 0xF0
000079f9de5d528e  pop r11
000079f9de5d5290  pop r10
000079f9de5d5292  pop r9
000079f9de5d5294  pop r8
000079f9de5d5296  pop rsi
000079f9de5d5297  pop rdi
000079f9de5d5298  pop rdx
000079f9de5d5299  pop rcx
000079f9de5d529a  pop rax
000079f9de5d529b  add rsp, 0x08
000079f9de5d529f  jmp 0x000079F9DE5D02B9
000079f9de5d52a4  sub rsp, 0x08
000079f9de5d52a8  push rax
000079f9de5d52a9  push rcx
000079f9de5d52aa  push rdx
000079f9de5d52ab  push rdi
000079f9de5d52ac  push rsi
000079f9de5d52ad  push r8
000079f9de5d52af  push r9
000079f9de5d52b1  push r10
000079f9de5d52b3  push r11
000079f9de5d52b5  sub rsp, 0xF0
000079f9de5d52bc  vmovaps [rsp], xmm0
000079f9de5d52c1  vmovaps [rsp+0x10], xmm1
000079f9de5d52c7  vmovaps [rsp+0x20], xmm2
000079f9de5d52cd  vmovaps [rsp+0x30], xmm3
000079f9de5d52d3  vmovaps [rsp+0x40], xmm4
000079f9de5d52d9  vmovaps [rsp+0x50], xmm5
000079f9de5d52df  vmovaps [rsp+0x60], xmm6
000079f9de5d52e5  vmovaps [rsp+0x70], xmm7
000079f9de5d52eb  vmovaps [rsp+0x80], xmm8
000079f9de5d52f4  vmovaps [rsp+0x90], xmm9
000079f9de5d52fd  vmovaps [rsp+0xA0], xmm10
000079f9de5d5306  vmovaps [rsp+0xB0], xmm11
000079f9de5d530f  vmovaps [rsp+0xC0], xmm12
000079f9de5d5318  vmovaps [rsp+0xD0], xmm13
000079f9de5d5321  vmovaps [rsp+0xE0], xmm14
000079f9de5d532a  sub rsp, 0x30
000079f9de5d532e  movaps [rsp], xmm15
000079f9de5d5333  movaps [rsp+0x10], xmm13
000079f9de5d5339  movaps [rsp+0x20], xmm9
000079f9de5d533f  lea rdi, [rsp]
000079f9de5d5343  mov esi, 0x00
000079f9de5d5348  mov rax, 0x56D56FF59530
000079f9de5d5352  call rax
000079f9de5d5354  movaps xmm15, [rsp]
000079f9de5d5359  add rsp, 0x30
000079f9de5d535d  vmovaps xmm0, [rsp]
000079f9de5d5362  vmovaps xmm1, [rsp+0x10]
000079f9de5d5368  vmovaps xmm2, [rsp+0x20]
000079f9de5d536e  vmovaps xmm3, [rsp+0x30]
000079f9de5d5374  vmovaps xmm4, [rsp+0x40]
000079f9de5d537a  vmovaps xmm5, [rsp+0x50]
000079f9de5d5380  vmovaps xmm6, [rsp+0x60]
000079f9de5d5386  vmovaps xmm7, [rsp+0x70]
000079f9de5d538c  vmovaps xmm8, [rsp+0x80]
000079f9de5d5395  vmovaps xmm9, [rsp+0x90]
000079f9de5d539e  vmovaps xmm10, [rsp+0xA0]
000079f9de5d53a7  vmovaps xmm11, [rsp+0xB0]
000079f9de5d53b0  vmovaps xmm12, [rsp+0xC0]
000079f9de5d53b9  vmovaps xmm13, [rsp+0xD0]
000079f9de5d53c2  vmovaps xmm14, [rsp+0xE0]
000079f9de5d53cb  add rsp, 0xF0
000079f9de5d53d2  pop r11
000079f9de5d53d4  pop r10
000079f9de5d53d6  pop r9
000079f9de5d53d8  pop r8
000079f9de5d53da  pop rsi
000079f9de5d53db  pop rdi
000079f9de5d53dc  pop rdx
000079f9de5d53dd  pop rcx
000079f9de5d53de  pop rax
000079f9de5d53df  add rsp, 0x08
000079f9de5d53e3  jmp 0x000079F9DE5D02D4
000079f9de5d53e8  sub rsp, 0x08
000079f9de5d53ec  push rax
000079f9de5d53ed  push rcx
000079f9de5d53ee  push rdx
000079f9de5d53ef  push rdi
000079f9de5d53f0  push rsi
000079f9de5d53f1  push r8
000079f9de5d53f3  push r9
000079f9de5d53f5  push r10
000079f9de5d53f7  push r11
000079f9de5d53f9  sub rsp, 0xF0
000079f9de5d5400  vmovaps [rsp], xmm0
000079f9de5d5405  vmovaps [rsp+0x10], xmm1
000079f9de5d540b  vmovaps [rsp+0x20], xmm2
000079f9de5d5411  vmovaps [rsp+0x30], xmm3
000079f9de5d5417  vmovaps [rsp+0x40], xmm4
000079f9de5d541d  vmovaps [rsp+0x50], xmm5
000079f9de5d5423  vmovaps [rsp+0x60], xmm6
000079f9de5d5429  vmovaps [rsp+0x70], xmm7
000079f9de5d542f  vmovaps [rsp+0x80], xmm8
000079f9de5d5438  vmovaps [rsp+0x90], xmm9
000079f9de5d5441  vmovaps [rsp+0xA0], xmm10
000079f9de5d544a  vmovaps [rsp+0xB0], xmm11
000079f9de5d5453  vmovaps [rsp+0xC0], xmm12
000079f9de5d545c  vmovaps [rsp+0xD0], xmm14
000079f9de5d5465  vmovaps [rsp+0xE0], xmm15
000079f9de5d546e  sub rsp, 0x30
000079f9de5d5472  movaps [rsp], xmm13
000079f9de5d5477  movaps [rsp+0x10], xmm8
000079f9de5d547d  movaps [rsp+0x20], xmm14
000079f9de5d5483  lea rdi, [rsp]
000079f9de5d5487  mov esi, 0x00
000079f9de5d548c  mov rax, 0x56D56FF59530
000079f9de5d5496  call rax
000079f9de5d5498  movaps xmm13, [rsp]
000079f9de5d549d  add rsp, 0x30
000079f9de5d54a1  vmovaps xmm0, [rsp]
000079f9de5d54a6  vmovaps xmm1, [rsp+0x10]
000079f9de5d54ac  vmovaps xmm2, [rsp+0x20]
000079f9de5d54b2  vmovaps xmm3, [rsp+0x30]
000079f9de5d54b8  vmovaps xmm4, [rsp+0x40]
000079f9de5d54be  vmovaps xmm5, [rsp+0x50]
000079f9de5d54c4  vmovaps xmm6, [rsp+0x60]
000079f9de5d54ca  vmovaps xmm7, [rsp+0x70]
000079f9de5d54d0  vmovaps xmm8, [rsp+0x80]
000079f9de5d54d9  vmovaps xmm9, [rsp+0x90]
000079f9de5d54e2  vmovaps xmm10, [rsp+0xA0]
000079f9de5d54eb  vmovaps xmm11, [rsp+0xB0]
000079f9de5d54f4  vmovaps xmm12, [rsp+0xC0]
000079f9de5d54fd  vmovaps xmm14, [rsp+0xD0]
000079f9de5d5506  vmovaps xmm15, [rsp+0xE0]
000079f9de5d550f  add rsp, 0xF0
000079f9de5d5516  pop r11
000079f9de5d5518  pop r10
000079f9de5d551a  pop r9
000079f9de5d551c  pop r8
000079f9de5d551e  pop rsi
000079f9de5d551f  pop rdi
000079f9de5d5520  pop rdx
000079f9de5d5521  pop rcx
000079f9de5d5522  pop rax
000079f9de5d5523  add rsp, 0x08
000079f9de5d5527  jmp 0x000079F9DE5D02F7
000079f9de5d552c  sub rsp, 0x08
000079f9de5d5530  push rax
000079f9de5d5531  push rcx
000079f9de5d5532  push rdx
000079f9de5d5533  push rdi
000079f9de5d5534  push rsi
000079f9de5d5535  push r8
000079f9de5d5537  push r9
000079f9de5d5539  push r10
000079f9de5d553b  push r11
000079f9de5d553d  sub rsp, 0xF0
000079f9de5d5544  vmovaps [rsp], xmm0
000079f9de5d5549  vmovaps [rsp+0x10], xmm1
000079f9de5d554f  vmovaps [rsp+0x20], xmm2
000079f9de5d5555  vmovaps [rsp+0x30], xmm3
000079f9de5d555b  vmovaps [rsp+0x40], xmm4
000079f9de5d5561  vmovaps [rsp+0x50], xmm5
000079f9de5d5567  vmovaps [rsp+0x60], xmm6
000079f9de5d556d  vmovaps [rsp+0x70], xmm7
000079f9de5d5573  vmovaps [rsp+0x80], xmm8
000079f9de5d557c  vmovaps [rsp+0x90], xmm9
000079f9de5d5585  vmovaps [rsp+0xA0], xmm10
000079f9de5d558e  vmovaps [rsp+0xB0], xmm11
000079f9de5d5597  vmovaps [rsp+0xC0], xmm12
000079f9de5d55a0  vmovaps [rsp+0xD0], xmm13
000079f9de5d55a9  vmovaps [rsp+0xE0], xmm15
000079f9de5d55b2  sub rsp, 0x30
000079f9de5d55b6  movaps [rsp], xmm14
000079f9de5d55bb  movaps [rsp+0x10], xmm1
000079f9de5d55c0  movaps [rsp+0x20], xmm10
000079f9de5d55c6  lea rdi, [rsp]
000079f9de5d55ca  mov esi, 0x00
000079f9de5d55cf  mov rax, 0x56D56FF59530
000079f9de5d55d9  call rax
000079f9de5d55db  movaps xmm14, [rsp]
000079f9de5d55e0  add rsp, 0x30
000079f9de5d55e4  vmovaps xmm0, [rsp]
000079f9de5d55e9  vmovaps xmm1, [rsp+0x10]
000079f9de5d55ef  vmovaps xmm2, [rsp+0x20]
000079f9de5d55f5  vmovaps xmm3, [rsp+0x30]
000079f9de5d55fb  vmovaps xmm4, [rsp+0x40]
000079f9de5d5601  vmovaps xmm5, [rsp+0x50]
000079f9de5d5607  vmovaps xmm6, [rsp+0x60]
000079f9de5d560d  vmovaps xmm7, [rsp+0x70]
000079f9de5d5613  vmovaps xmm8, [rsp+0x80]
000079f9de5d561c  vmovaps xmm9, [rsp+0x90]
000079f9de5d5625  vmovaps xmm10, [rsp+0xA0]
000079f9de5d562e  vmovaps xmm11, [rsp+0xB0]
000079f9de5d5637  vmovaps xmm12, [rsp+0xC0]
000079f9de5d5640  vmovaps xmm13, [rsp+0xD0]
000079f9de5d5649  vmovaps xmm15, [rsp+0xE0]
000079f9de5d5652  add rsp, 0xF0
000079f9de5d5659  pop r11
000079f9de5d565b  pop r10
000079f9de5d565d  pop r9
000079f9de5d565f  pop r8
000079f9de5d5661  pop rsi
000079f9de5d5662  pop rdi
000079f9de5d5663  pop rdx
000079f9de5d5664  pop rcx
000079f9de5d5665  pop rax
000079f9de5d5666  add rsp, 0x08
000079f9de5d566a  jmp 0x000079F9DE5D031A
000079f9de5d566f  sub rsp, 0x08
000079f9de5d5673  push rax
000079f9de5d5674  push rcx
000079f9de5d5675  push rdx
000079f9de5d5676  push rdi
000079f9de5d5677  push rsi
000079f9de5d5678  push r8
000079f9de5d567a  push r9
000079f9de5d567c  push r10
000079f9de5d567e  push r11
000079f9de5d5680  sub rsp, 0xF0
000079f9de5d5687  vmovaps [rsp], xmm0
000079f9de5d568c  vmovaps [rsp+0x10], xmm2
000079f9de5d5692  vmovaps [rsp+0x20], xmm3
000079f9de5d5698  vmovaps [rsp+0x30], xmm4
000079f9de5d569e  vmovaps [rsp+0x40], xmm5
000079f9de5d56a4  vmovaps [rsp+0x50], xmm6
000079f9de5d56aa  vmovaps [rsp+0x60], xmm7
000079f9de5d56b0  vmovaps [rsp+0x70], xmm8
000079f9de5d56b6  vmovaps [rsp+0x80], xmm9
000079f9de5d56bf  vmovaps [rsp+0x90], xmm10
000079f9de5d56c8  vmovaps [rsp+0xA0], xmm11
000079f9de5d56d1  vmovaps [rsp+0xB0], xmm12
000079f9de5d56da  vmovaps [rsp+0xC0], xmm13
000079f9de5d56e3  vmovaps [rsp+0xD0], xmm14
000079f9de5d56ec  vmovaps [rsp+0xE0], xmm15
000079f9de5d56f5  sub rsp, 0x30
000079f9de5d56f9  movaps [rsp], xmm1
000079f9de5d56fd  movaps [rsp+0x10], xmm7
000079f9de5d5702  movaps [rsp+0x20], xmm11
000079f9de5d5708  lea rdi, [rsp]
000079f9de5d570c  mov esi, 0x00
000079f9de5d5711  mov rax, 0x56D56FF59530
000079f9de5d571b  call rax
000079f9de5d571d  movaps xmm1, [rsp]
000079f9de5d5721  add rsp, 0x30
000079f9de5d5725  vmovaps xmm0, [rsp]
000079f9de5d572a  vmovaps xmm2, [rsp+0x10]
000079f9de5d5730  vmovaps xmm3, [rsp+0x20]
000079f9de5d5736  vmovaps xmm4, [rsp+0x30]
000079f9de5d573c  vmovaps xmm5, [rsp+0x40]
000079f9de5d5742  vmovaps xmm6, [rsp+0x50]
000079f9de5d5748  vmovaps xmm7, [rsp+0x60]
000079f9de5d574e  vmovaps xmm8, [rsp+0x70]
000079f9de5d5754  vmovaps xmm9, [rsp+0x80]
000079f9de5d575d  vmovaps xmm10, [rsp+0x90]
000079f9de5d5766  vmovaps xmm11, [rsp+0xA0]
000079f9de5d576f  vmovaps xmm12, [rsp+0xB0]
000079f9de5d5778  vmovaps xmm13, [rsp+0xC0]
000079f9de5d5781  vmovaps xmm14, [rsp+0xD0]
000079f9de5d578a  vmovaps xmm15, [rsp+0xE0]
000079f9de5d5793  add rsp, 0xF0
000079f9de5d579a  pop r11
000079f9de5d579c  pop r10
000079f9de5d579e  pop r9
000079f9de5d57a0  pop r8
000079f9de5d57a2  pop rsi
000079f9de5d57a3  pop rdi
000079f9de5d57a4  pop rdx
000079f9de5d57a5  pop rcx
000079f9de5d57a6  pop rax
000079f9de5d57a7  add rsp, 0x08
000079f9de5d57ab  jmp 0x000079F9DE5D033B
000079f9de5d57b0  call 0x000079F9DE40E880
000079f9de5d57b5  jmp 0x000079F9DE5D034E
000079f9de5d57ba  call 0x000079F9DE40C380
000079f9de5d57bf  jmp 0x000079F9DE5D0359
000079f9de5d57c4  call 0x000079F9DE40D600
000079f9de5d57c9  jmp 0x000079F9DE5D0364
000079f9de5d57ce  call 0x000079F9DE3FF540
000079f9de5d57d3  jmp 0x000079F9DE5D036F
000079f9de5d57d8  int3
000079f9de5d57d9  nop [rax], eax
000079f9de5d57e0  mov rax, [r15+0x40]
000079f9de5d57e4  mov r14, [r15+0x58]
000079f9de5d57e8  lea r12, [rax+r14*1]
000079f9de5d57ec  movaps xmm1, [r15+0x1D0]
000079f9de5d57f4  vmovaps [rsp+0x10], xmm1
000079f9de5d57fa  vmovaps xmm15, [rsp+0x10]
000079f9de5d5800  por xmm1, xmm15
000079f9de5d5805  movaps xmm14, [r15+0x1A0]
000079f9de5d580d  vmovaps [rsp+0x10], xmm14
000079f9de5d5813  vmovaps xmm13, [rsp+0x10]
000079f9de5d5819  por xmm14, xmm13
000079f9de5d581e  lea rax, [r12+0x30]
000079f9de5d5823  mov r11, [r13+rax*1]
000079f9de5d5828  lea rax, [r12+0x38]
000079f9de5d582d  mov r10, [r13+rax*1]
000079f9de5d5832  movq xmm13, r11
000079f9de5d5837  movq xmm12, r10
000079f9de5d583c  movq xmm13, xmm13
000079f9de5d5841  vmovaps [rsp+0x10], xmm13
000079f9de5d5847  movq xmm13, xmm13
000079f9de5d584c  movaps [r15+0x130], xmm13
000079f9de5d5854  movq xmm12, xmm12
000079f9de5d5859  vmovaps [rsp+0x20], xmm12
000079f9de5d585f  movq xmm12, xmm12
000079f9de5d5864  movaps [r15+0x280], xmm12
000079f9de5d586c  movaps xmm13, [r15+0x270]
000079f9de5d5874  vmovaps [rsp+0x30], xmm13
000079f9de5d587a  vmovaps xmm12, [rsp+0x30]
000079f9de5d5880  por xmm13, xmm12
000079f9de5d5885  lea rax, [r12+0x20]
000079f9de5d588a  mov r11, [r13+rax*1]
000079f9de5d588f  lea rax, [r12+0x28]
000079f9de5d5894  mov r10, [r13+rax*1]
000079f9de5d5899  movq xmm12, r11
000079f9de5d589e  movq xmm11, r10
000079f9de5d58a3  movq xmm12, xmm12
000079f9de5d58a8  vmovaps [rsp+0x30], xmm12
000079f9de5d58ae  movq xmm12, xmm12
000079f9de5d58b3  movaps [r15+0x150], xmm12
000079f9de5d58bb  movq xmm11, xmm11
000079f9de5d58c0  vmovaps [rsp+0x40], xmm11
000079f9de5d58c6  movq xmm11, xmm11
000079f9de5d58cb  movaps [r15+0x140], xmm11
000079f9de5d58d3  lea rax, [r12+0x10]
000079f9de5d58d8  mov r11, [r13+rax*1]
000079f9de5d58dd  lea rax, [r12+0x18]
000079f9de5d58e2  mov r10, [r13+rax*1]
000079f9de5d58e7  movq xmm12, r11
000079f9de5d58ec  movq xmm11, r10
000079f9de5d58f1  movq xmm12, xmm12
000079f9de5d58f6  vmovaps [rsp+0x50], xmm12
000079f9de5d58fc  movq xmm12, xmm12
000079f9de5d5901  movaps [r15+0x170], xmm12
000079f9de5d5909  movq xmm11, xmm11
000079f9de5d590e  vmovaps [rsp+0x60], xmm11
000079f9de5d5914  movq xmm11, xmm11
000079f9de5d5919  movaps [r15+0x160], xmm11
000079f9de5d5921  mov rax, [r13+r12*1]
000079f9de5d5926  vmovq xmm12, rax
000079f9de5d592b  vpbroadcastq xmm12, xmm12
000079f9de5d5930  lea rax, [r12+0x08]
000079f9de5d5935  mov r12, [r13+rax*1]
000079f9de5d593a  movq xmm11, r12
000079f9de5d593f  movaps [r15+0x230], xmm11
000079f9de5d5947  mov rax, [r15+0xF8]
000079f9de5d594e  lea r12, [rax+0x50]
000079f9de5d5952  movups xmm11, [r13+r12*1]
000079f9de5d5958  lea r12, [rax+0x60]
000079f9de5d595c  movups xmm10, [r13+r12*1]
000079f9de5d5962  lea r12, [rax+0x30]
000079f9de5d5966  movups xmm9, [r13+r12*1]
000079f9de5d596c  mov r12, [r15+0x50]
000079f9de5d5970  lea r11, [r12+r14*1]
000079f9de5d5974  mov [r15+0x60], r11
000079f9de5d5978  lea r12, [r14+0x40]
000079f9de5d597c  mov [r15+0x58], r12
000079f9de5d5980  movaps xmm8, xmm12
000079f9de5d5984  mulpd xmm8, xmm15
000079f9de5d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000079f9de5d598f  ptest xmm7, xmm7
000079f9de5d5994  jnz 0x000079F9DE5D67B7
000079f9de5d599a  movq xmm15, qword ptr [r15+0x230]
000079f9de5d59a3  vmovaps [rsp+0x70], xmm15
000079f9de5d59a9  vpermilpd xmm15, xmm15, 0x00
000079f9de5d59af  movaps xmm7, xmm9
000079f9de5d59b3  mulpd xmm7, xmm15
000079f9de5d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000079f9de5d59bd  ptest xmm6, xmm6
000079f9de5d59c2  jnz 0x000079F9DE5D68FB
000079f9de5d59c8  vxorps xmm15, xmm15, xmm15
000079f9de5d59cd  vpbroadcastq xmm15, xmm15
000079f9de5d59d2  movaps xmm9, xmm12
000079f9de5d59d6  mulpd xmm9, xmm10
000079f9de5d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000079f9de5d59e1  ptest xmm6, xmm6
000079f9de5d59e6  jnz 0x000079F9DE5D6A3D
000079f9de5d59ec  movaps xmm10, xmm12
000079f9de5d59f0  mulpd xmm10, xmm11
000079f9de5d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000079f9de5d59fb  ptest xmm6, xmm6
000079f9de5d5a00  jnz 0x000079F9DE5D6B81
000079f9de5d5a06  movaps xmm11, [r15+0x1F0]
000079f9de5d5a0e  movaps xmm6, xmm12
000079f9de5d5a12  mulpd xmm6, xmm11
000079f9de5d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000079f9de5d5a1c  ptest xmm5, xmm5
000079f9de5d5a21  jnz 0x000079F9DE5D6CC5
000079f9de5d5a27  movaps xmm12, [r15+0x2A0]
000079f9de5d5a2f  vmovaps [rsp+0x80], xmm12
000079f9de5d5a38  vmovaps xmm11, [rsp+0x80]
000079f9de5d5a41  por xmm12, xmm11
000079f9de5d5a46  movaps xmm11, [r15+0x250]
000079f9de5d5a4e  vmovaps [rsp+0x80], xmm11
000079f9de5d5a57  vmovaps xmm5, [rsp+0x80]
000079f9de5d5a60  por xmm11, xmm5
000079f9de5d5a65  vmovaps xmm4, [rsp+0x70]
000079f9de5d5a6b  vpermilpd xmm4, xmm4, 0x00
000079f9de5d5a71  movaps xmm3, xmm5
000079f9de5d5a74  mulpd xmm3, xmm4
000079f9de5d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000079f9de5d5a7d  ptest xmm2, xmm2
000079f9de5d5a82  jnz 0x000079F9DE5D6E07
000079f9de5d5a88  mov [rsp+0x80], rax
000079f9de5d5a90  xor eax, eax
000079f9de5d5a92  mov r14d, 0x200
000079f9de5d5a98  cmp r12, r14
000079f9de5d5a9b  cmc
000079f9de5d5a9c  lahf
000079f9de5d5a9d  seto al
000079f9de5d5aa0  mov [r15+0x108], eax
000079f9de5d5aa7  movaps xmm5, xmm8
000079f9de5d5aab  addpd xmm5, xmm15
000079f9de5d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000079f9de5d5ab5  ptest xmm4, xmm4
000079f9de5d5aba  jnz 0x000079F9DE5D6F47
000079f9de5d5ac0  movaps xmm8, [r15+0x1B0]
000079f9de5d5ac8  movaps xmm4, xmm9
000079f9de5d5acc  addpd xmm4, xmm8
000079f9de5d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000079f9de5d5ad6  ptest xmm2, xmm2
000079f9de5d5adb  jnz 0x000079F9DE5D7089
000079f9de5d5ae1  movaps xmm9, xmm10
000079f9de5d5ae5  addpd xmm9, xmm8
000079f9de5d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000079f9de5d5af0  ptest xmm2, xmm2
000079f9de5d5af5  jnz 0x000079F9DE5D71CB
000079f9de5d5afb  movaps xmm10, [r15+0x2F0]
000079f9de5d5b03  vmovaps [rsp+0x90], xmm10
000079f9de5d5b0c  vmovaps xmm8, [rsp+0x90]
000079f9de5d5b15  por xmm10, xmm8
000079f9de5d5b1a  movaps xmm8, [r15+0x2E0]
000079f9de5d5b22  vmovaps [rsp+0x90], xmm8
000079f9de5d5b2b  vmovaps xmm2, [rsp+0x90]
000079f9de5d5b34  por xmm8, xmm2
000079f9de5d5b39  movaps xmm2, [r15+0x2D0]
000079f9de5d5b41  vmovaps [rsp+0x90], xmm2
000079f9de5d5b4a  vmovaps [rsp+0xA0], xmm1
000079f9de5d5b53  vmovaps xmm1, [rsp+0x90]
000079f9de5d5b5c  por xmm2, xmm1
000079f9de5d5b60  movaps xmm1, [r15+0x200]
000079f9de5d5b68  vmovaps [rsp+0x90], xmm1
000079f9de5d5b71  vmovaps [rsp+0xB0], xmm15
000079f9de5d5b7a  vmovaps xmm15, [rsp+0x90]
000079f9de5d5b83  por xmm1, xmm15
000079f9de5d5b88  movaps xmm15, [r15+0x1C0]
000079f9de5d5b90  vmovaps [rsp+0x90], xmm15
000079f9de5d5b99  vmovaps [rsp+0xC0], xmm1
000079f9de5d5ba2  vmovaps xmm1, [rsp+0x90]
000079f9de5d5bab  por xmm15, xmm1
000079f9de5d5bb0  movaps xmm1, [r15+0x190]
000079f9de5d5bb8  vmovaps [rsp+0x90], xmm1
000079f9de5d5bc1  vmovaps [rsp+0xD0], xmm15
000079f9de5d5bca  vmovaps xmm15, [rsp+0x90]
000079f9de5d5bd3  por xmm1, xmm15
000079f9de5d5bd8  movaps xmm15, [r15+0x300]
000079f9de5d5be0  vmovaps [rsp+0x90], xmm15
000079f9de5d5be9  vmovaps [rsp+0xE0], xmm1
000079f9de5d5bf2  vmovaps xmm1, [rsp+0x90]
000079f9de5d5bfb  por xmm15, xmm1
000079f9de5d5c00  mov rax, [rsp+0x80]
000079f9de5d5c08  lea r14, [rax+0xA0]
000079f9de5d5c0f  movups xmm1, [r13+r14*1]
000079f9de5d5c15  lea r14, [rax+0xB0]
000079f9de5d5c1c  vmovaps [rsp+0x80], xmm1
000079f9de5d5c25  movups xmm1, [r13+r14*1]
000079f9de5d5c2b  vmovaps [rsp+0x90], xmm1
000079f9de5d5c34  vmovaps [rsp+0xF0], xmm15
000079f9de5d5c3d  vmovaps xmm15, [rsp+0xB0]
000079f9de5d5c46  vmovaps [rsp+0xB0], xmm14
000079f9de5d5c4f  movaps xmm1, xmm6
000079f9de5d5c52  addpd xmm1, xmm15
000079f9de5d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000079f9de5d5c5c  ptest xmm14, xmm14
000079f9de5d5c62  jnz 0x000079F9DE5D7323
000079f9de5d5c68  lea r14, [rax+0xF0]
000079f9de5d5c6f  movups xmm15, [r13+r14*1]
000079f9de5d5c75  movaps xmm14, xmm4
000079f9de5d5c79  addpd xmm14, xmm3
000079f9de5d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000079f9de5d5c84  ptest xmm6, xmm6
000079f9de5d5c89  jnz 0x000079F9DE5D746E
000079f9de5d5c8f  movaps xmm6, xmm9
000079f9de5d5c93  addpd xmm6, xmm7
000079f9de5d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000079f9de5d5c9c  ptest xmm4, xmm4
000079f9de5d5ca1  jnz 0x000079F9DE5D75B0
000079f9de5d5ca7  vmovaps xmm9, [rsp+0x70]
000079f9de5d5cad  vpermilpd xmm9, xmm9, 0x00
000079f9de5d5cb3  vmovaps xmm4, [rsp+0x90]
000079f9de5d5cbc  movaps xmm7, xmm4
000079f9de5d5cbf  mulpd xmm7, xmm9
000079f9de5d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000079f9de5d5cc9  ptest xmm3, xmm3
000079f9de5d5cce  jnz 0x000079F9DE5D76F1
000079f9de5d5cd4  vmovaps xmm9, [rsp+0x50]
000079f9de5d5cda  vpermilpd xmm9, xmm9, 0x00
000079f9de5d5ce0  movaps xmm4, xmm15
000079f9de5d5ce4  mulpd xmm4, xmm9
000079f9de5d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000079f9de5d5cee  ptest xmm3, xmm3
000079f9de5d5cf3  jnz 0x000079F9DE5D7832
000079f9de5d5cf9  lea r14, [rax+0xE0]
000079f9de5d5d00  movups xmm15, [r13+r14*1]
000079f9de5d5d06  vmovaps xmm9, [rsp+0x70]
000079f9de5d5d0c  vpermilpd xmm9, xmm9, 0x00
000079f9de5d5d12  vmovaps [rsp+0x70], xmm1
000079f9de5d5d18  vmovaps xmm1, [rsp+0x80]
000079f9de5d5d21  vmovaps [rsp+0x80], xmm15
000079f9de5d5d2a  movaps xmm3, xmm1
000079f9de5d5d2d  mulpd xmm3, xmm9
000079f9de5d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000079f9de5d5d37  ptest xmm15, xmm15
000079f9de5d5d3d  jnz 0x000079F9DE5D797E
000079f9de5d5d43  vmovaps xmm1, [rsp+0xF0]
000079f9de5d5d4c  vmovaps xmm15, [rsp+0xF0]
000079f9de5d5d55  por xmm1, xmm15
000079f9de5d5d5a  movaps [r15+0x300], xmm1
000079f9de5d5d62  vmovaps xmm15, [rsp+0xE0]
000079f9de5d5d6b  vmovaps xmm9, [rsp+0xE0]
000079f9de5d5d74  por xmm15, xmm9
000079f9de5d5d79  movaps [r15+0x190], xmm15
000079f9de5d5d81  vmovaps xmm9, [rsp+0x50]
000079f9de5d5d87  vpermilpd xmm9, xmm9, 0x00
000079f9de5d5d8d  vmovaps [rsp+0x90], xmm1
000079f9de5d5d96  vmovaps [rsp+0xE0], xmm15
000079f9de5d5d9f  vmovaps xmm15, [rsp+0x80]
000079f9de5d5da8  vmovaps [rsp+0x80], xmm14
000079f9de5d5db1  movaps xmm1, xmm15
000079f9de5d5db5  mulpd xmm1, xmm9
000079f9de5d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000079f9de5d5dbf  ptest xmm14, xmm14
000079f9de5d5dc5  jnz 0x000079F9DE5D7ABF
000079f9de5d5dcb  lea r14, [rax+0x90]
000079f9de5d5dd2  movups xmm15, [r13+r14*1]
000079f9de5d5dd8  vmovaps xmm14, [rsp+0xD0]
000079f9de5d5de1  vmovaps xmm9, [rsp+0xD0]
000079f9de5d5dea  por xmm14, xmm9
000079f9de5d5def  movaps [r15+0x1C0], xmm14
000079f9de5d5df7  vmovaps xmm9, [rsp+0xC0]
000079f9de5d5e00  vmovaps [rsp+0xD0], xmm1
000079f9de5d5e09  vmovaps xmm1, [rsp+0xC0]
000079f9de5d5e12  por xmm9, xmm1
000079f9de5d5e17  movaps [r15+0x200], xmm9
000079f9de5d5e1f  vmovaps [rsp+0xC0], xmm2
000079f9de5d5e28  vmovaps xmm1, [rsp+0xC0]
000079f9de5d5e31  por xmm2, xmm1
000079f9de5d5e35  movaps [r15+0x2D0], xmm2
000079f9de5d5e3d  vmovaps [rsp+0xC0], xmm8
000079f9de5d5e46  vmovaps xmm1, [rsp+0xC0]
000079f9de5d5e4f  por xmm8, xmm1
000079f9de5d5e54  movaps [r15+0x2E0], xmm8
000079f9de5d5e5c  vmovaps [rsp+0xC0], xmm15
000079f9de5d5e65  movaps xmm1, xmm5
000079f9de5d5e68  addpd xmm1, xmm7
000079f9de5d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000079f9de5d5e71  ptest xmm15, xmm15
000079f9de5d5e77  jnz 0x000079F9DE5D7C0B
000079f9de5d5e7d  vmovaps xmm15, [rsp+0x50]
000079f9de5d5e83  vpermilpd xmm15, xmm15, 0x00
000079f9de5d5e89  vmovaps xmm5, [rsp+0xC0]
000079f9de5d5e92  vmovaps [rsp+0xC0], xmm1
000079f9de5d5e9b  movaps xmm7, xmm5
000079f9de5d5e9e  mulpd xmm7, xmm15
000079f9de5d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000079f9de5d5ea8  ptest xmm1, xmm1
000079f9de5d5ead  jnz 0x000079F9DE5D7D4B
000079f9de5d5eb3  lea r14, [rax+0x80]
000079f9de5d5eba  movups xmm1, [r13+r14*1]
000079f9de5d5ec0  vmovaps xmm5, [rsp+0x70]
000079f9de5d5ec6  vmovaps [rsp+0x70], xmm1
000079f9de5d5ecc  movaps xmm15, xmm5
000079f9de5d5ed0  addpd xmm15, xmm3
000079f9de5d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000079f9de5d5edb  ptest xmm1, xmm1
000079f9de5d5ee0  jnz 0x000079F9DE5D7E96
000079f9de5d5ee6  vmovaps xmm5, [rsp+0x80]
000079f9de5d5eef  movaps xmm1, xmm5
000079f9de5d5ef2  addpd xmm1, xmm4
000079f9de5d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000079f9de5d5efb  ptest xmm3, xmm3
000079f9de5d5f00  jnz 0x000079F9DE5D7FD8
000079f9de5d5f06  vmovaps [rsp+0x80], xmm10
000079f9de5d5f0f  vmovaps xmm5, [rsp+0x80]
000079f9de5d5f18  por xmm10, xmm5
000079f9de5d5f1d  movaps [r15+0x2F0], xmm10
000079f9de5d5f25  vmovaps xmm5, [rsp+0x50]
000079f9de5d5f2b  vpermilpd xmm5, xmm5, 0x00
000079f9de5d5f31  vmovaps xmm3, [rsp+0x70]
000079f9de5d5f37  vmovaps [rsp+0x50], xmm1
000079f9de5d5f3d  movaps xmm4, xmm3
000079f9de5d5f40  mulpd xmm4, xmm5
000079f9de5d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000079f9de5d5f49  ptest xmm1, xmm1
000079f9de5d5f4e  jnz 0x000079F9DE5D8118
000079f9de5d5f54  lea r14, [rax+0xD0]
000079f9de5d5f5b  movups xmm1, [r13+r14*1]
000079f9de5d5f61  vmovaps xmm3, [rsp+0xD0]
000079f9de5d5f6a  vmovaps [rsp+0x70], xmm1
000079f9de5d5f70  movaps xmm5, xmm6
000079f9de5d5f73  addpd xmm5, xmm3
000079f9de5d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000079f9de5d5f7c  ptest xmm1, xmm1
000079f9de5d5f81  jnz 0x000079F9DE5D8262
000079f9de5d5f87  vmovaps xmm1, [rsp+0x60]
000079f9de5d5f8d  vpermilpd xmm1, xmm1, 0x00
000079f9de5d5f93  movaps xmm6, xmm9
000079f9de5d5f97  mulpd xmm6, xmm1
000079f9de5d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000079f9de5d5fa0  ptest xmm3, xmm3
000079f9de5d5fa5  jnz 0x000079F9DE5D83A2
000079f9de5d5fab  movaps [r15+0x260], xmm6
000079f9de5d5fb3  vxorps xmm1, xmm1, xmm1
000079f9de5d5fb7  vpbroadcastq xmm1, xmm1
000079f9de5d5fbc  movaps [r15+0x1B0], xmm1
000079f9de5d5fc4  vmovaps xmm1, [rsp+0x60]
000079f9de5d5fca  vpermilpd xmm1, xmm1, 0x00
000079f9de5d5fd0  vmovaps xmm3, [rsp+0x70]
000079f9de5d5fd6  vmovaps [rsp+0x70], xmm15
000079f9de5d5fdc  movaps xmm9, xmm3
000079f9de5d5fe0  mulpd xmm9, xmm1
000079f9de5d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000079f9de5d5feb  ptest xmm15, xmm15
000079f9de5d5ff1  jnz 0x000079F9DE5D84E3
000079f9de5d5ff7  lea r14, [rax+0xC0]
000079f9de5d5ffe  movups xmm1, [r13+r14*1]
000079f9de5d6004  vmovaps xmm3, [rsp+0xC0]
000079f9de5d600d  vmovaps [rsp+0x80], xmm1
000079f9de5d6016  movaps xmm15, xmm3
000079f9de5d601a  addpd xmm15, xmm7
000079f9de5d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000079f9de5d6025  ptest xmm1, xmm1
000079f9de5d602a  jnz 0x000079F9DE5D862F
000079f9de5d6030  vmovaps [rsp+0xC0], xmm13
000079f9de5d6039  vmovaps xmm1, [rsp+0xC0]
000079f9de5d6042  por xmm13, xmm1
000079f9de5d6047  movaps [r15+0x270], xmm13
000079f9de5d604f  vmovaps xmm1, [rsp+0xB0]
000079f9de5d6058  vmovaps xmm7, [rsp+0xB0]
000079f9de5d6061  por xmm1, xmm7
000079f9de5d6065  movaps [r15+0x1A0], xmm1
000079f9de5d606d  vmovaps xmm1, [rsp+0x60]
000079f9de5d6073  vpermilpd xmm1, xmm1, 0x00
000079f9de5d6079  vmovaps [rsp+0xB0], xmm1
000079f9de5d6082  vmovaps xmm1, [rsp+0x80]
000079f9de5d608b  vmovaps [rsp+0x80], xmm15
000079f9de5d6094  vmovaps xmm15, [rsp+0xB0]
000079f9de5d609d  vmovaps [rsp+0xB0], xmm14
000079f9de5d60a6  movaps xmm3, xmm1
000079f9de5d60a9  mulpd xmm3, xmm15
000079f9de5d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000079f9de5d60b3  ptest xmm14, xmm14
000079f9de5d60b9  jnz 0x000079F9DE5D8771
000079f9de5d60bf  lea r14, [rax+0x20]
000079f9de5d60c3  movups xmm1, [r13+r14*1]
000079f9de5d60c9  movaps [r15+0x110], xmm1
000079f9de5d60d1  vmovaps xmm14, [rsp+0x70]
000079f9de5d60d7  vmovaps [rsp+0x70], xmm1
000079f9de5d60dd  movaps xmm15, xmm14
000079f9de5d60e1  addpd xmm15, xmm4
000079f9de5d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000079f9de5d60ec  ptest xmm1, xmm1
000079f9de5d60f1  jnz 0x000079F9DE5D88BC
000079f9de5d60f7  vmovaps xmm1, [rsp+0x60]
000079f9de5d60fd  vpermilpd xmm1, xmm1, 0x00
000079f9de5d6103  movaps xmm14, xmm2
000079f9de5d6107  mulpd xmm14, xmm1
000079f9de5d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000079f9de5d6112  ptest xmm4, xmm4
000079f9de5d6117  jnz 0x000079F9DE5D89FF
000079f9de5d611d  vmovaps xmm4, [rsp+0x50]
000079f9de5d6123  movaps xmm1, xmm4
000079f9de5d6126  addpd xmm1, xmm9
000079f9de5d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000079f9de5d6130  ptest xmm2, xmm2
000079f9de5d6135  jnz 0x000079F9DE5D8B41
000079f9de5d613b  vmovaps xmm9, [rsp+0x30]
000079f9de5d6141  vpermilpd xmm9, xmm9, 0x00
000079f9de5d6147  vmovaps xmm2, [rsp+0x70]
000079f9de5d614d  vmovaps [rsp+0x50], xmm1
000079f9de5d6153  movaps xmm4, xmm2
000079f9de5d6156  mulpd xmm4, xmm9
000079f9de5d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000079f9de5d6160  ptest xmm1, xmm1
000079f9de5d6165  jnz 0x000079F9DE5D8C82
000079f9de5d616b  vmovaps xmm1, [rsp+0x30]
000079f9de5d6171  vpermilpd xmm1, xmm1, 0x00
000079f9de5d6177  vmovaps xmm2, [rsp+0x90]
000079f9de5d6180  vmovaps [rsp+0x60], xmm15
000079f9de5d6186  movaps xmm9, xmm2
000079f9de5d618a  mulpd xmm9, xmm1
000079f9de5d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000079f9de5d6195  ptest xmm15, xmm15
000079f9de5d619b  jnz 0x000079F9DE5D8DC3
000079f9de5d61a1  vmovaps xmm15, [rsp+0x80]
000079f9de5d61aa  movaps xmm1, xmm15
000079f9de5d61ae  addpd xmm1, xmm6
000079f9de5d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000079f9de5d61b7  ptest xmm2, xmm2
000079f9de5d61bc  jnz 0x000079F9DE5D8F05
000079f9de5d61c2  movaps xmm15, xmm5
000079f9de5d61c6  addpd xmm15, xmm3
000079f9de5d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000079f9de5d61d1  ptest xmm6, xmm6
000079f9de5d61d6  jnz 0x000079F9DE5D9046
000079f9de5d61dc  vmovaps xmm6, [rsp+0x30]
000079f9de5d61e2  vpermilpd xmm6, xmm6, 0x00
000079f9de5d61e8  movaps xmm5, xmm8
000079f9de5d61ec  mulpd xmm5, xmm6
000079f9de5d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000079f9de5d61f5  ptest xmm3, xmm3
000079f9de5d61fa  jnz 0x000079F9DE5D9188
000079f9de5d6200  vmovaps xmm8, [rsp+0x30]
000079f9de5d6206  vpermilpd xmm8, xmm8, 0x00
000079f9de5d620c  movaps xmm6, xmm10
000079f9de5d6210  mulpd xmm6, xmm8
000079f9de5d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000079f9de5d621a  ptest xmm3, xmm3
000079f9de5d621f  jnz 0x000079F9DE5D92C9
000079f9de5d6225  vmovaps xmm8, [rsp+0x60]
000079f9de5d622b  movaps xmm10, xmm8
000079f9de5d622f  addpd xmm10, xmm14
000079f9de5d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000079f9de5d623a  ptest xmm3, xmm3
000079f9de5d623f  jnz 0x000079F9DE5D940B
000079f9de5d6245  vmovaps xmm8, [rsp+0x50]
000079f9de5d624b  movaps xmm14, xmm8
000079f9de5d624f  addpd xmm14, xmm4
000079f9de5d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000079f9de5d625a  ptest xmm3, xmm3
000079f9de5d625f  jnz 0x000079F9DE5D954F
000079f9de5d6265  vmovaps xmm8, [rsp+0x40]
000079f9de5d626b  vpermilpd xmm8, xmm8, 0x00
000079f9de5d6271  movaps xmm4, xmm13
000079f9de5d6275  mulpd xmm4, xmm8
000079f9de5d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000079f9de5d627f  ptest xmm3, xmm3
000079f9de5d6284  jnz 0x000079F9DE5D9692
000079f9de5d628a  movaps xmm13, xmm15
000079f9de5d628e  addpd xmm13, xmm9
000079f9de5d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000079f9de5d6299  ptest xmm8, xmm8
000079f9de5d629f  jnz 0x000079F9DE5D97D4
000079f9de5d62a5  movaps xmm15, xmm1
000079f9de5d62a9  addpd xmm15, xmm5
000079f9de5d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000079f9de5d62b4  ptest xmm9, xmm9
000079f9de5d62ba  jnz 0x000079F9DE5D9918
000079f9de5d62c0  vmovaps [rsp+0x30], xmm11
000079f9de5d62c6  vmovaps xmm1, [rsp+0x30]
000079f9de5d62cc  por xmm11, xmm1
000079f9de5d62d1  movaps [r15+0x250], xmm11
000079f9de5d62d9  vmovaps [rsp+0x30], xmm12
000079f9de5d62df  vmovaps xmm1, [rsp+0x30]
000079f9de5d62e5  por xmm12, xmm1
000079f9de5d62ea  movaps [r15+0x2A0], xmm12
000079f9de5d62f2  vmovaps xmm1, [rsp+0xA0]
000079f9de5d62fb  vmovaps xmm11, [rsp+0xA0]
000079f9de5d6304  por xmm1, xmm11
000079f9de5d6309  movaps [r15+0x1D0], xmm1
000079f9de5d6311  lea r14, [rax+0x40]
000079f9de5d6315  movups xmm1, [r13+r14*1]
000079f9de5d631b  movaps [r15+0x2C0], xmm1
000079f9de5d6323  vmovaps xmm11, [rsp+0x40]
000079f9de5d6329  vpermilpd xmm11, xmm11, 0x00
000079f9de5d632f  vmovaps xmm8, [rsp+0xE0]
000079f9de5d6338  movaps xmm9, xmm8
000079f9de5d633c  mulpd xmm9, xmm11
000079f9de5d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000079f9de5d6347  ptest xmm5, xmm5
000079f9de5d634c  jnz 0x000079F9DE5D9A64
000079f9de5d6352  movaps xmm11, xmm10
000079f9de5d6356  addpd xmm11, xmm6
000079f9de5d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000079f9de5d6361  ptest xmm8, xmm8
000079f9de5d6367  jnz 0x000079F9DE5D9BA8
000079f9de5d636d  movaps xmm10, xmm14
000079f9de5d6371  addpd xmm10, xmm4
000079f9de5d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000079f9de5d637c  ptest xmm8, xmm8
000079f9de5d6382  jnz 0x000079F9DE5D9CEB
000079f9de5d6388  vmovaps xmm14, [rsp+0x40]
000079f9de5d638e  vpermilpd xmm14, xmm14, 0x00
000079f9de5d6394  movaps xmm8, xmm1
000079f9de5d6398  mulpd xmm8, xmm14
000079f9de5d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000079f9de5d63a3  ptest xmm6, xmm6
000079f9de5d63a8  jnz 0x000079F9DE5D9E2E
000079f9de5d63ae  movaps xmm1, [r15+0x2B0]
000079f9de5d63b6  vmovaps xmm14, [rsp+0x40]
000079f9de5d63bc  vpermilpd xmm14, xmm14, 0x00
000079f9de5d63c2  movaps xmm6, xmm1
000079f9de5d63c5  mulpd xmm6, xmm14
000079f9de5d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000079f9de5d63cf  ptest xmm5, xmm5
000079f9de5d63d4  jnz 0x000079F9DE5D9F71
000079f9de5d63da  vmovaps xmm1, [rsp+0x10]
000079f9de5d63e0  vpermilpd xmm1, xmm1, 0x00
000079f9de5d63e6  movaps xmm14, xmm12
000079f9de5d63ea  mulpd xmm14, xmm1
000079f9de5d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000079f9de5d63f5  ptest xmm5, xmm5
000079f9de5d63fa  jnz 0x000079F9DE5DA0B2
000079f9de5d6400  movaps xmm1, xmm13
000079f9de5d6404  addpd xmm1, xmm9
000079f9de5d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000079f9de5d640e  ptest xmm12, xmm12
000079f9de5d6414  jnz 0x000079F9DE5DA1F5
000079f9de5d641a  vmovaps xmm13, [rsp+0x10]
000079f9de5d6420  vpermilpd xmm13, xmm13, 0x00
000079f9de5d6426  movaps xmm12, xmm7
000079f9de5d642a  mulpd xmm12, xmm13
000079f9de5d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000079f9de5d6435  ptest xmm9, xmm9
000079f9de5d643b  jnz 0x000079F9DE5DA337
000079f9de5d6441  movaps xmm13, xmm15
000079f9de5d6445  addpd xmm13, xmm8
000079f9de5d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000079f9de5d6450  ptest xmm9, xmm9
000079f9de5d6456  jnz 0x000079F9DE5DA47A
000079f9de5d645c  movaps xmm15, [r15+0x290]
000079f9de5d6464  vmovaps xmm9, [rsp+0x10]
000079f9de5d646a  vpermilpd xmm9, xmm9, 0x00
000079f9de5d6470  movaps xmm8, xmm15
000079f9de5d6474  mulpd xmm8, xmm9
000079f9de5d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000079f9de5d647f  ptest xmm7, xmm7
000079f9de5d6484  jnz 0x000079F9DE5DA5BE
000079f9de5d648a  movaps xmm15, xmm11
000079f9de5d648e  addpd xmm15, xmm6
000079f9de5d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000079f9de5d6499  ptest xmm9, xmm9
000079f9de5d649f  jnz 0x000079F9DE5DA702
000079f9de5d64a5  movaps xmm11, [r15+0x1E0]
000079f9de5d64ad  vmovaps xmm9, [rsp+0x10]
000079f9de5d64b3  vpermilpd xmm9, xmm9, 0x00
000079f9de5d64b9  movaps xmm7, xmm11
000079f9de5d64bd  mulpd xmm7, xmm9
000079f9de5d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000079f9de5d64c7  ptest xmm6, xmm6
000079f9de5d64cc  jnz 0x000079F9DE5DA845
000079f9de5d64d2  movaps xmm11, xmm10
000079f9de5d64d6  addpd xmm11, xmm14
000079f9de5d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000079f9de5d64e1  ptest xmm9, xmm9
000079f9de5d64e7  jnz 0x000079F9DE5DA987
000079f9de5d64ed  lea r14, [rax+0x70]
000079f9de5d64f1  movups xmm14, [r13+r14*1]
000079f9de5d64f7  movaps [r15+0x240], xmm14
000079f9de5d64ff  movaps xmm10, xmm1
000079f9de5d6503  addpd xmm10, xmm12
000079f9de5d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000079f9de5d650e  ptest xmm9, xmm9
000079f9de5d6514  jnz 0x000079F9DE5DAAD5
000079f9de5d651a  movaps [r15+0x170], xmm10
000079f9de5d6522  vmovaps xmm1, [rsp+0x20]
000079f9de5d6528  vpermilpd xmm1, xmm1, 0x00
000079f9de5d652e  movaps xmm12, xmm14
000079f9de5d6532  mulpd xmm12, xmm1
000079f9de5d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000079f9de5d653d  ptest xmm9, xmm9
000079f9de5d6543  jnz 0x000079F9DE5DAC18
000079f9de5d6549  vmovaps xmm1, [rsp+0x20]
000079f9de5d654f  vpermilpd xmm1, xmm1, 0x00
000079f9de5d6555  vmovaps xmm9, [rsp+0xB0]
000079f9de5d655e  movaps xmm14, xmm9
000079f9de5d6562  mulpd xmm14, xmm1
000079f9de5d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000079f9de5d656d  ptest xmm6, xmm6
000079f9de5d6572  jnz 0x000079F9DE5DAD5B
000079f9de5d6578  movaps [r15+0x180], xmm14
000079f9de5d6580  movaps xmm1, xmm13
000079f9de5d6584  addpd xmm1, xmm8
000079f9de5d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000079f9de5d658e  ptest xmm9, xmm9
000079f9de5d6594  jnz 0x000079F9DE5DAE9E
000079f9de5d659a  movaps [r15+0x210], xmm1
000079f9de5d65a2  movups xmm13, [r13+rax*1]
000079f9de5d65a8  lea r14, [rax+0x10]
000079f9de5d65ac  movups xmm9, [r13+r14*1]
000079f9de5d65b2  movaps [r15+0x230], xmm9
000079f9de5d65ba  movaps xmm8, xmm15
000079f9de5d65be  addpd xmm8, xmm7
000079f9de5d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000079f9de5d65c9  ptest xmm6, xmm6
000079f9de5d65ce  jnz 0x000079F9DE5DAFF4
000079f9de5d65d4  movaps [r15+0x130], xmm8
000079f9de5d65dc  vmovaps xmm15, [rsp+0x20]
000079f9de5d65e2  vpermilpd xmm15, xmm15, 0x00
000079f9de5d65e8  movaps xmm7, xmm9
000079f9de5d65ec  mulpd xmm7, xmm15
000079f9de5d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000079f9de5d65f6  ptest xmm6, xmm6
000079f9de5d65fb  jnz 0x000079F9DE5DB137
000079f9de5d6601  movaps [r15+0x220], xmm7
000079f9de5d6609  vmovaps xmm15, [rsp+0x20]
000079f9de5d660f  vpermilpd xmm15, xmm15, 0x00
000079f9de5d6615  movaps xmm9, xmm13
000079f9de5d6619  mulpd xmm9, xmm15
000079f9de5d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000079f9de5d6624  ptest xmm6, xmm6
000079f9de5d6629  jnz 0x000079F9DE5DB279
000079f9de5d662f  movaps xmm15, xmm11
000079f9de5d6633  addpd xmm15, xmm12
000079f9de5d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000079f9de5d663e  ptest xmm13, xmm13
000079f9de5d6644  jnz 0x000079F9DE5DB3BD
000079f9de5d664a  movaps [r15+0x140], xmm15
000079f9de5d6652  movaps xmm13, xmm10
000079f9de5d6656  addpd xmm13, xmm14
000079f9de5d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000079f9de5d6661  ptest xmm12, xmm12
000079f9de5d6667  jnz 0x000079F9DE5DB501
000079f9de5d666d  movaps [r15+0x150], xmm13
000079f9de5d6675  movaps xmm14, xmm1
000079f9de5d6679  addpd xmm14, xmm7
000079f9de5d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000079f9de5d6684  ptest xmm12, xmm12
000079f9de5d668a  jnz 0x000079F9DE5DB645
000079f9de5d6690  movaps [r15+0x160], xmm14
000079f9de5d6698  movaps xmm1, xmm8
000079f9de5d669c  addpd xmm1, xmm9
000079f9de5d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000079f9de5d66a6  ptest xmm12, xmm12
000079f9de5d66ac  jnz 0x000079F9DE5DB787
000079f9de5d66b2  movaps [r15+0x120], xmm1
000079f9de5d66ba  movups [r13+r11*1], xmm15
000079f9de5d66c0  lea rax, [r11+0x10]
000079f9de5d66c4  movups [r13+rax*1], xmm13
000079f9de5d66ca  lea rax, [r11+0x20]
000079f9de5d66ce  movups [r13+rax*1], xmm14
000079f9de5d66d4  lea rax, [r11+0x30]
000079f9de5d66d8  movups [r13+rax*1], xmm1
000079f9de5d66de  mov eax, [r15+0x108]
000079f9de5d66e5  sahf
000079f9de5d66e6  jnz 0x000079F9DE5D6718
000079f9de5d66e8  cmp dword ptr [r15+0x318], 0x00
000079f9de5d66f0  jz 0x000079F9DE5DB900
000079f9de5d66f6  nop [rax+rax*1], ax
000079f9de5d66ff  nop [rax+rax*1], eax
000079f9de5d6707  mov eax, 0x410444
000079f9de5d670c  mov [r15+0x100], rax
000079f9de5d6713  jmp 0x000079F9DE3FE110
000079f9de5d6718  cmp dword ptr [r15+0x318], 0x00
000079f9de5d6720  jz 0x000079F9DE5D57E0
000079f9de5d6726  nop [rax+rax*1], ax
000079f9de5d672f  nop [rax+rax*1], eax
000079f9de5d6737  mov eax, 0x410278
000079f9de5d673c  mov [r15+0x100], rax
000079f9de5d6743  jmp 0x000079F9DE3FE110
000079f9de5d6748  int3
000079f9de5d6749  call 0x000079F9DE40A4B0
000079f9de5d674e  jmp 0x000079F9DE5D5828
000079f9de5d6753  call 0x000079F9DE409240
000079f9de5d6758  jmp 0x000079F9DE5D5832
000079f9de5d675d  call 0x000079F9DE40A4B0
000079f9de5d6762  jmp 0x000079F9DE5D588F
000079f9de5d6767  call 0x000079F9DE409240
000079f9de5d676c  jmp 0x000079F9DE5D5899
000079f9de5d6771  call 0x000079F9DE40A4B0
000079f9de5d6776  jmp 0x000079F9DE5D58DD
000079f9de5d677b  call 0x000079F9DE409240
000079f9de5d6780  jmp 0x000079F9DE5D58E7
000079f9de5d6785  call 0x000079F9DE4B47C0
000079f9de5d678a  jmp 0x000079F9DE5D5926
000079f9de5d678f  call 0x000079F9DE40B720
000079f9de5d6794  jmp 0x000079F9DE5D593A
000079f9de5d6799  call 0x000079F9DE4BFC30
000079f9de5d679e  jmp 0x000079F9DE5D5958
000079f9de5d67a3  call 0x000079F9DE4BE9C0
000079f9de5d67a8  jmp 0x000079F9DE5D5962
000079f9de5d67ad  call 0x000079F9DE4BD750
000079f9de5d67b2  jmp 0x000079F9DE5D596C
000079f9de5d67b7  sub rsp, 0x08
000079f9de5d67bb  push rax
000079f9de5d67bc  push rcx
000079f9de5d67bd  push rdx
000079f9de5d67be  push rdi
000079f9de5d67bf  push rsi
000079f9de5d67c0  push r8
000079f9de5d67c2  push r9
000079f9de5d67c4  push r10
000079f9de5d67c6  push r11
000079f9de5d67c8  sub rsp, 0xF0
000079f9de5d67cf  vmovaps [rsp], xmm0
000079f9de5d67d4  vmovaps [rsp+0x10], xmm1
000079f9de5d67da  vmovaps [rsp+0x20], xmm2
000079f9de5d67e0  vmovaps [rsp+0x30], xmm3
000079f9de5d67e6  vmovaps [rsp+0x40], xmm4
000079f9de5d67ec  vmovaps [rsp+0x50], xmm5
000079f9de5d67f2  vmovaps [rsp+0x60], xmm6
000079f9de5d67f8  vmovaps [rsp+0x70], xmm7
000079f9de5d67fe  vmovaps [rsp+0x80], xmm9
000079f9de5d6807  vmovaps [rsp+0x90], xmm10
000079f9de5d6810  vmovaps [rsp+0xA0], xmm11
000079f9de5d6819  vmovaps [rsp+0xB0], xmm12
000079f9de5d6822  vmovaps [rsp+0xC0], xmm13
000079f9de5d682b  vmovaps [rsp+0xD0], xmm14
000079f9de5d6834  vmovaps [rsp+0xE0], xmm15
000079f9de5d683d  sub rsp, 0x30
000079f9de5d6841  movaps [rsp], xmm8
000079f9de5d6846  movaps [rsp+0x10], xmm12
000079f9de5d684c  movaps [rsp+0x20], xmm15
000079f9de5d6852  lea rdi, [rsp]
000079f9de5d6856  mov esi, 0x00
000079f9de5d685b  mov rax, 0x56D56FF59530
000079f9de5d6865  call rax
000079f9de5d6867  movaps xmm8, [rsp]
000079f9de5d686c  add rsp, 0x30
000079f9de5d6870  vmovaps xmm0, [rsp]
000079f9de5d6875  vmovaps xmm1, [rsp+0x10]
000079f9de5d687b  vmovaps xmm2, [rsp+0x20]
000079f9de5d6881  vmovaps xmm3, [rsp+0x30]
000079f9de5d6887  vmovaps xmm4, [rsp+0x40]
000079f9de5d688d  vmovaps xmm5, [rsp+0x50]
000079f9de5d6893  vmovaps xmm6, [rsp+0x60]
000079f9de5d6899  vmovaps xmm7, [rsp+0x70]
000079f9de5d689f  vmovaps xmm9, [rsp+0x80]
000079f9de5d68a8  vmovaps xmm10, [rsp+0x90]
000079f9de5d68b1  vmovaps xmm11, [rsp+0xA0]
000079f9de5d68ba  vmovaps xmm12, [rsp+0xB0]
000079f9de5d68c3  vmovaps xmm13, [rsp+0xC0]
000079f9de5d68cc  vmovaps xmm14, [rsp+0xD0]
000079f9de5d68d5  vmovaps xmm15, [rsp+0xE0]
000079f9de5d68de  add rsp, 0xF0
000079f9de5d68e5  pop r11
000079f9de5d68e7  pop r10
000079f9de5d68e9  pop r9
000079f9de5d68eb  pop r8
000079f9de5d68ed  pop rsi
000079f9de5d68ee  pop rdi
000079f9de5d68ef  pop rdx
000079f9de5d68f0  pop rcx
000079f9de5d68f1  pop rax
000079f9de5d68f2  add rsp, 0x08
000079f9de5d68f6  jmp 0x000079F9DE5D599A
000079f9de5d68fb  sub rsp, 0x08
000079f9de5d68ff  push rax
000079f9de5d6900  push rcx
000079f9de5d6901  push rdx
000079f9de5d6902  push rdi
000079f9de5d6903  push rsi
000079f9de5d6904  push r8
000079f9de5d6906  push r9
000079f9de5d6908  push r10
000079f9de5d690a  push r11
000079f9de5d690c  sub rsp, 0xF0
000079f9de5d6913  vmovaps [rsp], xmm0
000079f9de5d6918  vmovaps [rsp+0x10], xmm1
000079f9de5d691e  vmovaps [rsp+0x20], xmm2
000079f9de5d6924  vmovaps [rsp+0x30], xmm3
000079f9de5d692a  vmovaps [rsp+0x40], xmm4
000079f9de5d6930  vmovaps [rsp+0x50], xmm5
000079f9de5d6936  vmovaps [rsp+0x60], xmm6
000079f9de5d693c  vmovaps [rsp+0x70], xmm8
000079f9de5d6942  vmovaps [rsp+0x80], xmm9
000079f9de5d694b  vmovaps [rsp+0x90], xmm10
000079f9de5d6954  vmovaps [rsp+0xA0], xmm11
000079f9de5d695d  vmovaps [rsp+0xB0], xmm12
000079f9de5d6966  vmovaps [rsp+0xC0], xmm13
000079f9de5d696f  vmovaps [rsp+0xD0], xmm14
000079f9de5d6978  vmovaps [rsp+0xE0], xmm15
000079f9de5d6981  sub rsp, 0x30
000079f9de5d6985  movaps [rsp], xmm7
000079f9de5d6989  movaps [rsp+0x10], xmm9
000079f9de5d698f  movaps [rsp+0x20], xmm15
000079f9de5d6995  lea rdi, [rsp]
000079f9de5d6999  mov esi, 0x00
000079f9de5d699e  mov rax, 0x56D56FF59530
000079f9de5d69a8  call rax
000079f9de5d69aa  movaps xmm7, [rsp]
000079f9de5d69ae  add rsp, 0x30
000079f9de5d69b2  vmovaps xmm0, [rsp]
000079f9de5d69b7  vmovaps xmm1, [rsp+0x10]
000079f9de5d69bd  vmovaps xmm2, [rsp+0x20]
000079f9de5d69c3  vmovaps xmm3, [rsp+0x30]
000079f9de5d69c9  vmovaps xmm4, [rsp+0x40]
000079f9de5d69cf  vmovaps xmm5, [rsp+0x50]
000079f9de5d69d5  vmovaps xmm6, [rsp+0x60]
000079f9de5d69db  vmovaps xmm8, [rsp+0x70]
000079f9de5d69e1  vmovaps xmm9, [rsp+0x80]
000079f9de5d69ea  vmovaps xmm10, [rsp+0x90]
000079f9de5d69f3  vmovaps xmm11, [rsp+0xA0]
000079f9de5d69fc  vmovaps xmm12, [rsp+0xB0]
000079f9de5d6a05  vmovaps xmm13, [rsp+0xC0]
000079f9de5d6a0e  vmovaps xmm14, [rsp+0xD0]
000079f9de5d6a17  vmovaps xmm15, [rsp+0xE0]
000079f9de5d6a20  add rsp, 0xF0
000079f9de5d6a27  pop r11
000079f9de5d6a29  pop r10
000079f9de5d6a2b  pop r9
000079f9de5d6a2d  pop r8
000079f9de5d6a2f  pop rsi
000079f9de5d6a30  pop rdi
000079f9de5d6a31  pop rdx
000079f9de5d6a32  pop rcx
000079f9de5d6a33  pop rax
000079f9de5d6a34  add rsp, 0x08
000079f9de5d6a38  jmp 0x000079F9DE5D59C8
000079f9de5d6a3d  sub rsp, 0x08
000079f9de5d6a41  push rax
000079f9de5d6a42  push rcx
000079f9de5d6a43  push rdx
000079f9de5d6a44  push rdi
000079f9de5d6a45  push rsi
000079f9de5d6a46  push r8
000079f9de5d6a48  push r9
000079f9de5d6a4a  push r10
000079f9de5d6a4c  push r11
000079f9de5d6a4e  sub rsp, 0xF0
000079f9de5d6a55  vmovaps [rsp], xmm0
000079f9de5d6a5a  vmovaps [rsp+0x10], xmm1
000079f9de5d6a60  vmovaps [rsp+0x20], xmm2
000079f9de5d6a66  vmovaps [rsp+0x30], xmm3
000079f9de5d6a6c  vmovaps [rsp+0x40], xmm4
000079f9de5d6a72  vmovaps [rsp+0x50], xmm5
000079f9de5d6a78  vmovaps [rsp+0x60], xmm6
000079f9de5d6a7e  vmovaps [rsp+0x70], xmm7
000079f9de5d6a84  vmovaps [rsp+0x80], xmm8
000079f9de5d6a8d  vmovaps [rsp+0x90], xmm10
000079f9de5d6a96  vmovaps [rsp+0xA0], xmm11
000079f9de5d6a9f  vmovaps [rsp+0xB0], xmm12
000079f9de5d6aa8  vmovaps [rsp+0xC0], xmm13
000079f9de5d6ab1  vmovaps [rsp+0xD0], xmm14
000079f9de5d6aba  vmovaps [rsp+0xE0], xmm15
000079f9de5d6ac3  sub rsp, 0x30
000079f9de5d6ac7  movaps [rsp], xmm9
000079f9de5d6acc  movaps [rsp+0x10], xmm12
000079f9de5d6ad2  movaps [rsp+0x20], xmm10
000079f9de5d6ad8  lea rdi, [rsp]
000079f9de5d6adc  mov esi, 0x00
000079f9de5d6ae1  mov rax, 0x56D56FF59530
000079f9de5d6aeb  call rax
000079f9de5d6aed  movaps xmm9, [rsp]
000079f9de5d6af2  add rsp, 0x30
000079f9de5d6af6  vmovaps xmm0, [rsp]
000079f9de5d6afb  vmovaps xmm1, [rsp+0x10]
000079f9de5d6b01  vmovaps xmm2, [rsp+0x20]
000079f9de5d6b07  vmovaps xmm3, [rsp+0x30]
000079f9de5d6b0d  vmovaps xmm4, [rsp+0x40]
000079f9de5d6b13  vmovaps xmm5, [rsp+0x50]
000079f9de5d6b19  vmovaps xmm6, [rsp+0x60]
000079f9de5d6b1f  vmovaps xmm7, [rsp+0x70]
000079f9de5d6b25  vmovaps xmm8, [rsp+0x80]
000079f9de5d6b2e  vmovaps xmm10, [rsp+0x90]
000079f9de5d6b37  vmovaps xmm11, [rsp+0xA0]
000079f9de5d6b40  vmovaps xmm12, [rsp+0xB0]
000079f9de5d6b49  vmovaps xmm13, [rsp+0xC0]
000079f9de5d6b52  vmovaps xmm14, [rsp+0xD0]
000079f9de5d6b5b  vmovaps xmm15, [rsp+0xE0]
000079f9de5d6b64  add rsp, 0xF0
000079f9de5d6b6b  pop r11
000079f9de5d6b6d  pop r10
000079f9de5d6b6f  pop r9
000079f9de5d6b71  pop r8
000079f9de5d6b73  pop rsi
000079f9de5d6b74  pop rdi
000079f9de5d6b75  pop rdx
000079f9de5d6b76  pop rcx
000079f9de5d6b77  pop rax
000079f9de5d6b78  add rsp, 0x08
000079f9de5d6b7c  jmp 0x000079F9DE5D59EC
000079f9de5d6b81  sub rsp, 0x08
000079f9de5d6b85  push rax
000079f9de5d6b86  push rcx
000079f9de5d6b87  push rdx
000079f9de5d6b88  push rdi
000079f9de5d6b89  push rsi
000079f9de5d6b8a  push r8
000079f9de5d6b8c  push r9
000079f9de5d6b8e  push r10
000079f9de5d6b90  push r11
000079f9de5d6b92  sub rsp, 0xF0
000079f9de5d6b99  vmovaps [rsp], xmm0
000079f9de5d6b9e  vmovaps [rsp+0x10], xmm1
000079f9de5d6ba4  vmovaps [rsp+0x20], xmm2
000079f9de5d6baa  vmovaps [rsp+0x30], xmm3
000079f9de5d6bb0  vmovaps [rsp+0x40], xmm4
000079f9de5d6bb6  vmovaps [rsp+0x50], xmm5
000079f9de5d6bbc  vmovaps [rsp+0x60], xmm6
000079f9de5d6bc2  vmovaps [rsp+0x70], xmm7
000079f9de5d6bc8  vmovaps [rsp+0x80], xmm8
000079f9de5d6bd1  vmovaps [rsp+0x90], xmm9
000079f9de5d6bda  vmovaps [rsp+0xA0], xmm11
000079f9de5d6be3  vmovaps [rsp+0xB0], xmm12
000079f9de5d6bec  vmovaps [rsp+0xC0], xmm13
000079f9de5d6bf5  vmovaps [rsp+0xD0], xmm14
000079f9de5d6bfe  vmovaps [rsp+0xE0], xmm15
000079f9de5d6c07  sub rsp, 0x30
000079f9de5d6c0b  movaps [rsp], xmm10
000079f9de5d6c10  movaps [rsp+0x10], xmm12
000079f9de5d6c16  movaps [rsp+0x20], xmm11
000079f9de5d6c1c  lea rdi, [rsp]
000079f9de5d6c20  mov esi, 0x00
000079f9de5d6c25  mov rax, 0x56D56FF59530
000079f9de5d6c2f  call rax
000079f9de5d6c31  movaps xmm10, [rsp]
000079f9de5d6c36  add rsp, 0x30
000079f9de5d6c3a  vmovaps xmm0, [rsp]
000079f9de5d6c3f  vmovaps xmm1, [rsp+0x10]
000079f9de5d6c45  vmovaps xmm2, [rsp+0x20]
000079f9de5d6c4b  vmovaps xmm3, [rsp+0x30]
000079f9de5d6c51  vmovaps xmm4, [rsp+0x40]
000079f9de5d6c57  vmovaps xmm5, [rsp+0x50]
000079f9de5d6c5d  vmovaps xmm6, [rsp+0x60]
000079f9de5d6c63  vmovaps xmm7, [rsp+0x70]
000079f9de5d6c69  vmovaps xmm8, [rsp+0x80]
000079f9de5d6c72  vmovaps xmm9, [rsp+0x90]
000079f9de5d6c7b  vmovaps xmm11, [rsp+0xA0]
000079f9de5d6c84  vmovaps xmm12, [rsp+0xB0]
000079f9de5d6c8d  vmovaps xmm13, [rsp+0xC0]
000079f9de5d6c96  vmovaps xmm14, [rsp+0xD0]
000079f9de5d6c9f  vmovaps xmm15, [rsp+0xE0]
000079f9de5d6ca8  add rsp, 0xF0
000079f9de5d6caf  pop r11
000079f9de5d6cb1  pop r10
000079f9de5d6cb3  pop r9
000079f9de5d6cb5  pop r8
000079f9de5d6cb7  pop rsi
000079f9de5d6cb8  pop rdi
000079f9de5d6cb9  pop rdx
000079f9de5d6cba  pop rcx
000079f9de5d6cbb  pop rax
000079f9de5d6cbc  add rsp, 0x08
000079f9de5d6cc0  jmp 0x000079F9DE5D5A06
000079f9de5d6cc5  sub rsp, 0x08
000079f9de5d6cc9  push rax
000079f9de5d6cca  push rcx
000079f9de5d6ccb  push rdx
000079f9de5d6ccc  push rdi
000079f9de5d6ccd  push rsi
000079f9de5d6cce  push r8
000079f9de5d6cd0  push r9
000079f9de5d6cd2  push r10
000079f9de5d6cd4  push r11
000079f9de5d6cd6  sub rsp, 0xF0
000079f9de5d6cdd  vmovaps [rsp], xmm0
000079f9de5d6ce2  vmovaps [rsp+0x10], xmm1
000079f9de5d6ce8  vmovaps [rsp+0x20], xmm2
000079f9de5d6cee  vmovaps [rsp+0x30], xmm3
000079f9de5d6cf4  vmovaps [rsp+0x40], xmm4
000079f9de5d6cfa  vmovaps [rsp+0x50], xmm5
000079f9de5d6d00  vmovaps [rsp+0x60], xmm7
000079f9de5d6d06  vmovaps [rsp+0x70], xmm8
000079f9de5d6d0c  vmovaps [rsp+0x80], xmm9
000079f9de5d6d15  vmovaps [rsp+0x90], xmm10
000079f9de5d6d1e  vmovaps [rsp+0xA0], xmm11
000079f9de5d6d27  vmovaps [rsp+0xB0], xmm12
000079f9de5d6d30  vmovaps [rsp+0xC0], xmm13
000079f9de5d6d39  vmovaps [rsp+0xD0], xmm14
000079f9de5d6d42  vmovaps [rsp+0xE0], xmm15
000079f9de5d6d4b  sub rsp, 0x30
000079f9de5d6d4f  movaps [rsp], xmm6
000079f9de5d6d53  movaps [rsp+0x10], xmm12
000079f9de5d6d59  movaps [rsp+0x20], xmm11
000079f9de5d6d5f  lea rdi, [rsp]
000079f9de5d6d63  mov esi, 0x00
000079f9de5d6d68  mov rax, 0x56D56FF59530
000079f9de5d6d72  call rax
000079f9de5d6d74  movaps xmm6, [rsp]
000079f9de5d6d78  add rsp, 0x30
000079f9de5d6d7c  vmovaps xmm0, [rsp]
000079f9de5d6d81  vmovaps xmm1, [rsp+0x10]
000079f9de5d6d87  vmovaps xmm2, [rsp+0x20]
000079f9de5d6d8d  vmovaps xmm3, [rsp+0x30]
000079f9de5d6d93  vmovaps xmm4, [rsp+0x40]
000079f9de5d6d99  vmovaps xmm5, [rsp+0x50]
000079f9de5d6d9f  vmovaps xmm7, [rsp+0x60]
000079f9de5d6da5  vmovaps xmm8, [rsp+0x70]
000079f9de5d6dab  vmovaps xmm9, [rsp+0x80]
000079f9de5d6db4  vmovaps xmm10, [rsp+0x90]
000079f9de5d6dbd  vmovaps xmm11, [rsp+0xA0]
000079f9de5d6dc6  vmovaps xmm12, [rsp+0xB0]
000079f9de5d6dcf  vmovaps xmm13, [rsp+0xC0]
000079f9de5d6dd8  vmovaps xmm14, [rsp+0xD0]
000079f9de5d6de1  vmovaps xmm15, [rsp+0xE0]
000079f9de5d6dea  add rsp, 0xF0
000079f9de5d6df1  pop r11
000079f9de5d6df3  pop r10
000079f9de5d6df5  pop r9
000079f9de5d6df7  pop r8
000079f9de5d6df9  pop rsi
000079f9de5d6dfa  pop rdi
000079f9de5d6dfb  pop rdx
000079f9de5d6dfc  pop rcx
000079f9de5d6dfd  pop rax
000079f9de5d6dfe  add rsp, 0x08
000079f9de5d6e02  jmp 0x000079F9DE5D5A27
000079f9de5d6e07  sub rsp, 0x08
000079f9de5d6e0b  push rax
000079f9de5d6e0c  push rcx
000079f9de5d6e0d  push rdx
000079f9de5d6e0e  push rdi
000079f9de5d6e0f  push rsi
000079f9de5d6e10  push r8
000079f9de5d6e12  push r9
000079f9de5d6e14  push r10
000079f9de5d6e16  push r11
000079f9de5d6e18  sub rsp, 0xF0
000079f9de5d6e1f  vmovaps [rsp], xmm0
000079f9de5d6e24  vmovaps [rsp+0x10], xmm1
000079f9de5d6e2a  vmovaps [rsp+0x20], xmm2
000079f9de5d6e30  vmovaps [rsp+0x30], xmm4
000079f9de5d6e36  vmovaps [rsp+0x40], xmm5
000079f9de5d6e3c  vmovaps [rsp+0x50], xmm6
000079f9de5d6e42  vmovaps [rsp+0x60], xmm7
000079f9de5d6e48  vmovaps [rsp+0x70], xmm8
000079f9de5d6e4e  vmovaps [rsp+0x80], xmm9
000079f9de5d6e57  vmovaps [rsp+0x90], xmm10
000079f9de5d6e60  vmovaps [rsp+0xA0], xmm11
000079f9de5d6e69  vmovaps [rsp+0xB0], xmm12
000079f9de5d6e72  vmovaps [rsp+0xC0], xmm13
000079f9de5d6e7b  vmovaps [rsp+0xD0], xmm14
000079f9de5d6e84  vmovaps [rsp+0xE0], xmm15
000079f9de5d6e8d  sub rsp, 0x30
000079f9de5d6e91  movaps [rsp], xmm3
000079f9de5d6e95  movaps [rsp+0x10], xmm5
000079f9de5d6e9a  movaps [rsp+0x20], xmm4
000079f9de5d6e9f  lea rdi, [rsp]
000079f9de5d6ea3  mov esi, 0x00
000079f9de5d6ea8  mov rax, 0x56D56FF59530
000079f9de5d6eb2  call rax
000079f9de5d6eb4  movaps xmm3, [rsp]
000079f9de5d6eb8  add rsp, 0x30
000079f9de5d6ebc  vmovaps xmm0, [rsp]
000079f9de5d6ec1  vmovaps xmm1, [rsp+0x10]
000079f9de5d6ec7  vmovaps xmm2, [rsp+0x20]
000079f9de5d6ecd  vmovaps xmm4, [rsp+0x30]
000079f9de5d6ed3  vmovaps xmm5, [rsp+0x40]
000079f9de5d6ed9  vmovaps xmm6, [rsp+0x50]
000079f9de5d6edf  vmovaps xmm7, [rsp+0x60]
000079f9de5d6ee5  vmovaps xmm8, [rsp+0x70]
000079f9de5d6eeb  vmovaps xmm9, [rsp+0x80]
000079f9de5d6ef4  vmovaps xmm10, [rsp+0x90]
000079f9de5d6efd  vmovaps xmm11, [rsp+0xA0]
000079f9de5d6f06  vmovaps xmm12, [rsp+0xB0]
000079f9de5d6f0f  vmovaps xmm13, [rsp+0xC0]
000079f9de5d6f18  vmovaps xmm14, [rsp+0xD0]
000079f9de5d6f21  vmovaps xmm15, [rsp+0xE0]
000079f9de5d6f2a  add rsp, 0xF0
000079f9de5d6f31  pop r11
000079f9de5d6f33  pop r10
000079f9de5d6f35  pop r9
000079f9de5d6f37  pop r8
000079f9de5d6f39  pop rsi
000079f9de5d6f3a  pop rdi
000079f9de5d6f3b  pop rdx
000079f9de5d6f3c  pop rcx
000079f9de5d6f3d  pop rax
000079f9de5d6f3e  add rsp, 0x08
000079f9de5d6f42  jmp 0x000079F9DE5D5A88
000079f9de5d6f47  sub rsp, 0x08
000079f9de5d6f4b  push rax
000079f9de5d6f4c  push rcx
000079f9de5d6f4d  push rdx
000079f9de5d6f4e  push rdi
000079f9de5d6f4f  push rsi
000079f9de5d6f50  push r8
000079f9de5d6f52  push r9
000079f9de5d6f54  push r10
000079f9de5d6f56  push r11
000079f9de5d6f58  sub rsp, 0xF0
000079f9de5d6f5f  vmovaps [rsp], xmm0
000079f9de5d6f64  vmovaps [rsp+0x10], xmm1
000079f9de5d6f6a  vmovaps [rsp+0x20], xmm2
000079f9de5d6f70  vmovaps [rsp+0x30], xmm3
000079f9de5d6f76  vmovaps [rsp+0x40], xmm4
000079f9de5d6f7c  vmovaps [rsp+0x50], xmm6
000079f9de5d6f82  vmovaps [rsp+0x60], xmm7
000079f9de5d6f88  vmovaps [rsp+0x70], xmm8
000079f9de5d6f8e  vmovaps [rsp+0x80], xmm9
000079f9de5d6f97  vmovaps [rsp+0x90], xmm10
000079f9de5d6fa0  vmovaps [rsp+0xA0], xmm11
000079f9de5d6fa9  vmovaps [rsp+0xB0], xmm12
000079f9de5d6fb2  vmovaps [rsp+0xC0], xmm13
000079f9de5d6fbb  vmovaps [rsp+0xD0], xmm14
000079f9de5d6fc4  vmovaps [rsp+0xE0], xmm15
000079f9de5d6fcd  sub rsp, 0x30
000079f9de5d6fd1  movaps [rsp], xmm5
000079f9de5d6fd5  movaps [rsp+0x10], xmm8
000079f9de5d6fdb  movaps [rsp+0x20], xmm15
000079f9de5d6fe1  lea rdi, [rsp]
000079f9de5d6fe5  mov esi, 0x00
000079f9de5d6fea  mov rax, 0x56D56FF59530
000079f9de5d6ff4  call rax
000079f9de5d6ff6  movaps xmm5, [rsp]
000079f9de5d6ffa  add rsp, 0x30
000079f9de5d6ffe  vmovaps xmm0, [rsp]
000079f9de5d7003  vmovaps xmm1, [rsp+0x10]
000079f9de5d7009  vmovaps xmm2, [rsp+0x20]
000079f9de5d700f  vmovaps xmm3, [rsp+0x30]
000079f9de5d7015  vmovaps xmm4, [rsp+0x40]
000079f9de5d701b  vmovaps xmm6, [rsp+0x50]
000079f9de5d7021  vmovaps xmm7, [rsp+0x60]
000079f9de5d7027  vmovaps xmm8, [rsp+0x70]
000079f9de5d702d  vmovaps xmm9, [rsp+0x80]
000079f9de5d7036  vmovaps xmm10, [rsp+0x90]
000079f9de5d703f  vmovaps xmm11, [rsp+0xA0]
000079f9de5d7048  vmovaps xmm12, [rsp+0xB0]
000079f9de5d7051  vmovaps xmm13, [rsp+0xC0]
000079f9de5d705a  vmovaps xmm14, [rsp+0xD0]
000079f9de5d7063  vmovaps xmm15, [rsp+0xE0]
000079f9de5d706c  add rsp, 0xF0
000079f9de5d7073  pop r11
000079f9de5d7075  pop r10
000079f9de5d7077  pop r9
000079f9de5d7079  pop r8
000079f9de5d707b  pop rsi
000079f9de5d707c  pop rdi
000079f9de5d707d  pop rdx
000079f9de5d707e  pop rcx
000079f9de5d707f  pop rax
000079f9de5d7080  add rsp, 0x08
000079f9de5d7084  jmp 0x000079F9DE5D5AC0
000079f9de5d7089  sub rsp, 0x08
000079f9de5d708d  push rax
000079f9de5d708e  push rcx
000079f9de5d708f  push rdx
000079f9de5d7090  push rdi
000079f9de5d7091  push rsi
000079f9de5d7092  push r8
000079f9de5d7094  push r9
000079f9de5d7096  push r10
000079f9de5d7098  push r11
000079f9de5d709a  sub rsp, 0xF0
000079f9de5d70a1  vmovaps [rsp], xmm0
000079f9de5d70a6  vmovaps [rsp+0x10], xmm1
000079f9de5d70ac  vmovaps [rsp+0x20], xmm2
000079f9de5d70b2  vmovaps [rsp+0x30], xmm3
000079f9de5d70b8  vmovaps [rsp+0x40], xmm5
000079f9de5d70be  vmovaps [rsp+0x50], xmm6
000079f9de5d70c4  vmovaps [rsp+0x60], xmm7
000079f9de5d70ca  vmovaps [rsp+0x70], xmm8
000079f9de5d70d0  vmovaps [rsp+0x80], xmm9
000079f9de5d70d9  vmovaps [rsp+0x90], xmm10
000079f9de5d70e2  vmovaps [rsp+0xA0], xmm11
000079f9de5d70eb  vmovaps [rsp+0xB0], xmm12
000079f9de5d70f4  vmovaps [rsp+0xC0], xmm13
000079f9de5d70fd  vmovaps [rsp+0xD0], xmm14
000079f9de5d7106  vmovaps [rsp+0xE0], xmm15
000079f9de5d710f  sub rsp, 0x30
000079f9de5d7113  movaps [rsp], xmm4
000079f9de5d7117  movaps [rsp+0x10], xmm9
000079f9de5d711d  movaps [rsp+0x20], xmm8
000079f9de5d7123  lea rdi, [rsp]
000079f9de5d7127  mov esi, 0x00
000079f9de5d712c  mov rax, 0x56D56FF59530
000079f9de5d7136  call rax
000079f9de5d7138  movaps xmm4, [rsp]
000079f9de5d713c  add rsp, 0x30
000079f9de5d7140  vmovaps xmm0, [rsp]
000079f9de5d7145  vmovaps xmm1, [rsp+0x10]
000079f9de5d714b  vmovaps xmm2, [rsp+0x20]
000079f9de5d7151  vmovaps xmm3, [rsp+0x30]
000079f9de5d7157  vmovaps xmm5, [rsp+0x40]
000079f9de5d715d  vmovaps xmm6, [rsp+0x50]
000079f9de5d7163  vmovaps xmm7, [rsp+0x60]
000079f9de5d7169  vmovaps xmm8, [rsp+0x70]
000079f9de5d716f  vmovaps xmm9, [rsp+0x80]
000079f9de5d7178  vmovaps xmm10, [rsp+0x90]
000079f9de5d7181  vmovaps xmm11, [rsp+0xA0]
000079f9de5d718a  vmovaps xmm12, [rsp+0xB0]
000079f9de5d7193  vmovaps xmm13, [rsp+0xC0]
000079f9de5d719c  vmovaps xmm14, [rsp+0xD0]
000079f9de5d71a5  vmovaps xmm15, [rsp+0xE0]
000079f9de5d71ae  add rsp, 0xF0
000079f9de5d71b5  pop r11
000079f9de5d71b7  pop r10
000079f9de5d71b9  pop r9
000079f9de5d71bb  pop r8
000079f9de5d71bd  pop rsi
000079f9de5d71be  pop rdi
000079f9de5d71bf  pop rdx
000079f9de5d71c0  pop rcx
000079f9de5d71c1  pop rax
000079f9de5d71c2  add rsp, 0x08
000079f9de5d71c6  jmp 0x000079F9DE5D5AE1
000079f9de5d71cb  sub rsp, 0x08
000079f9de5d71cf  push rax
000079f9de5d71d0  push rcx
000079f9de5d71d1  push rdx
000079f9de5d71d2  push rdi
000079f9de5d71d3  push rsi
000079f9de5d71d4  push r8
000079f9de5d71d6  push r9
000079f9de5d71d8  push r10
000079f9de5d71da  push r11
000079f9de5d71dc  sub rsp, 0xF0
000079f9de5d71e3  vmovaps [rsp], xmm0
000079f9de5d71e8  vmovaps [rsp+0x10], xmm1
000079f9de5d71ee  vmovaps [rsp+0x20], xmm2
000079f9de5d71f4  vmovaps [rsp+0x30], xmm3
000079f9de5d71fa  vmovaps [rsp+0x40], xmm4
000079f9de5d7200  vmovaps [rsp+0x50], xmm5
000079f9de5d7206  vmovaps [rsp+0x60], xmm6
000079f9de5d720c  vmovaps [rsp+0x70], xmm7
000079f9de5d7212  vmovaps [rsp+0x80], xmm8
000079f9de5d721b  vmovaps [rsp+0x90], xmm10
000079f9de5d7224  vmovaps [rsp+0xA0], xmm11
000079f9de5d722d  vmovaps [rsp+0xB0], xmm12
000079f9de5d7236  vmovaps [rsp+0xC0], xmm13
000079f9de5d723f  vmovaps [rsp+0xD0], xmm14
000079f9de5d7248  vmovaps [rsp+0xE0], xmm15
000079f9de5d7251  sub rsp, 0x30
000079f9de5d7255  movaps [rsp], xmm9
000079f9de5d725a  movaps [rsp+0x10], xmm10
000079f9de5d7260  movaps [rsp+0x20], xmm8
000079f9de5d7266  lea rdi, [rsp]
000079f9de5d726a  mov esi, 0x00
000079f9de5d726f  mov rax, 0x56D56FF59530
000079f9de5d7279  call rax
000079f9de5d727b  movaps xmm9, [rsp]
000079f9de5d7280  add rsp, 0x30
000079f9de5d7284  vmovaps xmm0, [rsp]
000079f9de5d7289  vmovaps xmm1, [rsp+0x10]
000079f9de5d728f  vmovaps xmm2, [rsp+0x20]
000079f9de5d7295  vmovaps xmm3, [rsp+0x30]
000079f9de5d729b  vmovaps xmm4, [rsp+0x40]
000079f9de5d72a1  vmovaps xmm5, [rsp+0x50]
000079f9de5d72a7  vmovaps xmm6, [rsp+0x60]
000079f9de5d72ad  vmovaps xmm7, [rsp+0x70]
000079f9de5d72b3  vmovaps xmm8, [rsp+0x80]
000079f9de5d72bc  vmovaps xmm10, [rsp+0x90]
000079f9de5d72c5  vmovaps xmm11, [rsp+0xA0]
000079f9de5d72ce  vmovaps xmm12, [rsp+0xB0]
000079f9de5d72d7  vmovaps xmm13, [rsp+0xC0]
000079f9de5d72e0  vmovaps xmm14, [rsp+0xD0]
000079f9de5d72e9  vmovaps xmm15, [rsp+0xE0]
000079f9de5d72f2  add rsp, 0xF0
000079f9de5d72f9  pop r11
000079f9de5d72fb  pop r10
000079f9de5d72fd  pop r9
000079f9de5d72ff  pop r8
000079f9de5d7301  pop rsi
000079f9de5d7302  pop rdi
000079f9de5d7303  pop rdx
000079f9de5d7304  pop rcx
000079f9de5d7305  pop rax
000079f9de5d7306  add rsp, 0x08
000079f9de5d730a  jmp 0x000079F9DE5D5AFB
000079f9de5d730f  call 0x000079F9DE4D64F0
000079f9de5d7314  jmp 0x000079F9DE5D5C15
000079f9de5d7319  call 0x000079F9DE4D64F0
000079f9de5d731e  jmp 0x000079F9DE5D5C2B
000079f9de5d7323  sub rsp, 0x08
000079f9de5d7327  push rax
000079f9de5d7328  push rcx
000079f9de5d7329  push rdx
000079f9de5d732a  push rdi
000079f9de5d732b  push rsi
000079f9de5d732c  push r8
000079f9de5d732e  push r9
000079f9de5d7330  push r10
000079f9de5d7332  push r11
000079f9de5d7334  sub rsp, 0xF0
000079f9de5d733b  vmovaps [rsp], xmm0
000079f9de5d7340  vmovaps [rsp+0x10], xmm2
000079f9de5d7346  vmovaps [rsp+0x20], xmm3
000079f9de5d734c  vmovaps [rsp+0x30], xmm4
000079f9de5d7352  vmovaps [rsp+0x40], xmm5
000079f9de5d7358  vmovaps [rsp+0x50], xmm6
000079f9de5d735e  vmovaps [rsp+0x60], xmm7
000079f9de5d7364  vmovaps [rsp+0x70], xmm8
000079f9de5d736a  vmovaps [rsp+0x80], xmm9
000079f9de5d7373  vmovaps [rsp+0x90], xmm10
000079f9de5d737c  vmovaps [rsp+0xA0], xmm11
000079f9de5d7385  vmovaps [rsp+0xB0], xmm12
000079f9de5d738e  vmovaps [rsp+0xC0], xmm13
000079f9de5d7397  vmovaps [rsp+0xD0], xmm14
000079f9de5d73a0  vmovaps [rsp+0xE0], xmm15
000079f9de5d73a9  sub rsp, 0x30
000079f9de5d73ad  movaps [rsp], xmm1
000079f9de5d73b1  movaps [rsp+0x10], xmm6
000079f9de5d73b6  movaps [rsp+0x20], xmm15
000079f9de5d73bc  lea rdi, [rsp]
000079f9de5d73c0  mov esi, 0x00
000079f9de5d73c5  mov rax, 0x56D56FF59530
000079f9de5d73cf  call rax
000079f9de5d73d1  movaps xmm1, [rsp]
000079f9de5d73d5  add rsp, 0x30
000079f9de5d73d9  vmovaps xmm0, [rsp]
000079f9de5d73de  vmovaps xmm2, [rsp+0x10]
000079f9de5d73e4  vmovaps xmm3, [rsp+0x20]
000079f9de5d73ea  vmovaps xmm4, [rsp+0x30]
000079f9de5d73f0  vmovaps xmm5, [rsp+0x40]
000079f9de5d73f6  vmovaps xmm6, [rsp+0x50]
000079f9de5d73fc  vmovaps xmm7, [rsp+0x60]
000079f9de5d7402  vmovaps xmm8, [rsp+0x70]
000079f9de5d7408  vmovaps xmm9, [rsp+0x80]
000079f9de5d7411  vmovaps xmm10, [rsp+0x90]
000079f9de5d741a  vmovaps xmm11, [rsp+0xA0]
000079f9de5d7423  vmovaps xmm12, [rsp+0xB0]
000079f9de5d742c  vmovaps xmm13, [rsp+0xC0]
000079f9de5d7435  vmovaps xmm14, [rsp+0xD0]
000079f9de5d743e  vmovaps xmm15, [rsp+0xE0]
000079f9de5d7447  add rsp, 0xF0
000079f9de5d744e  pop r11
000079f9de5d7450  pop r10
000079f9de5d7452  pop r9
000079f9de5d7454  pop r8
000079f9de5d7456  pop rsi
000079f9de5d7457  pop rdi
000079f9de5d7458  pop rdx
000079f9de5d7459  pop rcx
000079f9de5d745a  pop rax
000079f9de5d745b  add rsp, 0x08
000079f9de5d745f  jmp 0x000079F9DE5D5C68
000079f9de5d7464  call 0x000079F9DE4E5820
000079f9de5d7469  jmp 0x000079F9DE5D5C75
000079f9de5d746e  sub rsp, 0x08
000079f9de5d7472  push rax
000079f9de5d7473  push rcx
000079f9de5d7474  push rdx
000079f9de5d7475  push rdi
000079f9de5d7476  push rsi
000079f9de5d7477  push r8
000079f9de5d7479  push r9
000079f9de5d747b  push r10
000079f9de5d747d  push r11
000079f9de5d747f  sub rsp, 0xF0
000079f9de5d7486  vmovaps [rsp], xmm0
000079f9de5d748b  vmovaps [rsp+0x10], xmm1
000079f9de5d7491  vmovaps [rsp+0x20], xmm2
000079f9de5d7497  vmovaps [rsp+0x30], xmm3
000079f9de5d749d  vmovaps [rsp+0x40], xmm4
000079f9de5d74a3  vmovaps [rsp+0x50], xmm5
000079f9de5d74a9  vmovaps [rsp+0x60], xmm6
000079f9de5d74af  vmovaps [rsp+0x70], xmm7
000079f9de5d74b5  vmovaps [rsp+0x80], xmm8
000079f9de5d74be  vmovaps [rsp+0x90], xmm9
000079f9de5d74c7  vmovaps [rsp+0xA0], xmm10
000079f9de5d74d0  vmovaps [rsp+0xB0], xmm11
000079f9de5d74d9  vmovaps [rsp+0xC0], xmm12
000079f9de5d74e2  vmovaps [rsp+0xD0], xmm13
000079f9de5d74eb  vmovaps [rsp+0xE0], xmm15
000079f9de5d74f4  sub rsp, 0x30
000079f9de5d74f8  movaps [rsp], xmm14
000079f9de5d74fd  movaps [rsp+0x10], xmm4
000079f9de5d7502  movaps [rsp+0x20], xmm3
000079f9de5d7507  lea rdi, [rsp]
000079f9de5d750b  mov esi, 0x00
000079f9de5d7510  mov rax, 0x56D56FF59530
000079f9de5d751a  call rax
000079f9de5d751c  movaps xmm14, [rsp]
000079f9de5d7521  add rsp, 0x30
000079f9de5d7525  vmovaps xmm0, [rsp]
000079f9de5d752a  vmovaps xmm1, [rsp+0x10]
000079f9de5d7530  vmovaps xmm2, [rsp+0x20]
000079f9de5d7536  vmovaps xmm3, [rsp+0x30]
000079f9de5d753c  vmovaps xmm4, [rsp+0x40]
000079f9de5d7542  vmovaps xmm5, [rsp+0x50]
000079f9de5d7548  vmovaps xmm6, [rsp+0x60]
000079f9de5d754e  vmovaps xmm7, [rsp+0x70]
000079f9de5d7554  vmovaps xmm8, [rsp+0x80]
000079f9de5d755d  vmovaps xmm9, [rsp+0x90]
000079f9de5d7566  vmovaps xmm10, [rsp+0xA0]
000079f9de5d756f  vmovaps xmm11, [rsp+0xB0]
000079f9de5d7578  vmovaps xmm12, [rsp+0xC0]
000079f9de5d7581  vmovaps xmm13, [rsp+0xD0]
000079f9de5d758a  vmovaps xmm15, [rsp+0xE0]
000079f9de5d7593  add rsp, 0xF0
000079f9de5d759a  pop r11
000079f9de5d759c  pop r10
000079f9de5d759e  pop r9
000079f9de5d75a0  pop r8
000079f9de5d75a2  pop rsi
000079f9de5d75a3  pop rdi
000079f9de5d75a4  pop rdx
000079f9de5d75a5  pop rcx
000079f9de5d75a6  pop rax
000079f9de5d75a7  add rsp, 0x08
000079f9de5d75ab  jmp 0x000079F9DE5D5C8F
000079f9de5d75b0  sub rsp, 0x08
000079f9de5d75b4  push rax
000079f9de5d75b5  push rcx
000079f9de5d75b6  push rdx
000079f9de5d75b7  push rdi
000079f9de5d75b8  push rsi
000079f9de5d75b9  push r8
000079f9de5d75bb  push r9
000079f9de5d75bd  push r10
000079f9de5d75bf  push r11
000079f9de5d75c1  sub rsp, 0xF0
000079f9de5d75c8  vmovaps [rsp], xmm0
000079f9de5d75cd  vmovaps [rsp+0x10], xmm1
000079f9de5d75d3  vmovaps [rsp+0x20], xmm2
000079f9de5d75d9  vmovaps [rsp+0x30], xmm3
000079f9de5d75df  vmovaps [rsp+0x40], xmm4
000079f9de5d75e5  vmovaps [rsp+0x50], xmm5
000079f9de5d75eb  vmovaps [rsp+0x60], xmm7
000079f9de5d75f1  vmovaps [rsp+0x70], xmm8
000079f9de5d75f7  vmovaps [rsp+0x80], xmm9
000079f9de5d7600  vmovaps [rsp+0x90], xmm10
000079f9de5d7609  vmovaps [rsp+0xA0], xmm11
000079f9de5d7612  vmovaps [rsp+0xB0], xmm12
000079f9de5d761b  vmovaps [rsp+0xC0], xmm13
000079f9de5d7624  vmovaps [rsp+0xD0], xmm14
000079f9de5d762d  vmovaps [rsp+0xE0], xmm15
000079f9de5d7636  sub rsp, 0x30
000079f9de5d763a  movaps [rsp], xmm6
000079f9de5d763e  movaps [rsp+0x10], xmm9
000079f9de5d7644  movaps [rsp+0x20], xmm7
000079f9de5d7649  lea rdi, [rsp]
000079f9de5d764d  mov esi, 0x00
000079f9de5d7652  mov rax, 0x56D56FF59530
000079f9de5d765c  call rax
000079f9de5d765e  movaps xmm6, [rsp]
000079f9de5d7662  add rsp, 0x30
000079f9de5d7666  vmovaps xmm0, [rsp]
000079f9de5d766b  vmovaps xmm1, [rsp+0x10]
000079f9de5d7671  vmovaps xmm2, [rsp+0x20]
000079f9de5d7677  vmovaps xmm3, [rsp+0x30]
000079f9de5d767d  vmovaps xmm4, [rsp+0x40]
000079f9de5d7683  vmovaps xmm5, [rsp+0x50]
000079f9de5d7689  vmovaps xmm7, [rsp+0x60]
000079f9de5d768f  vmovaps xmm8, [rsp+0x70]
000079f9de5d7695  vmovaps xmm9, [rsp+0x80]
000079f9de5d769e  vmovaps xmm10, [rsp+0x90]
000079f9de5d76a7  vmovaps xmm11, [rsp+0xA0]
000079f9de5d76b0  vmovaps xmm12, [rsp+0xB0]
000079f9de5d76b9  vmovaps xmm13, [rsp+0xC0]
000079f9de5d76c2  vmovaps xmm14, [rsp+0xD0]
000079f9de5d76cb  vmovaps xmm15, [rsp+0xE0]
000079f9de5d76d4  add rsp, 0xF0
000079f9de5d76db  pop r11
000079f9de5d76dd  pop r10
000079f9de5d76df  pop r9
000079f9de5d76e1  pop r8
000079f9de5d76e3  pop rsi
000079f9de5d76e4  pop rdi
000079f9de5d76e5  pop rdx
000079f9de5d76e6  pop rcx
000079f9de5d76e7  pop rax
000079f9de5d76e8  add rsp, 0x08
000079f9de5d76ec  jmp 0x000079F9DE5D5CA7
000079f9de5d76f1  sub rsp, 0x08
000079f9de5d76f5  push rax
000079f9de5d76f6  push rcx
000079f9de5d76f7  push rdx
000079f9de5d76f8  push rdi
000079f9de5d76f9  push rsi
000079f9de5d76fa  push r8
000079f9de5d76fc  push r9
000079f9de5d76fe  push r10
000079f9de5d7700  push r11
000079f9de5d7702  sub rsp, 0xF0
000079f9de5d7709  vmovaps [rsp], xmm0
000079f9de5d770e  vmovaps [rsp+0x10], xmm1
000079f9de5d7714  vmovaps [rsp+0x20], xmm2
000079f9de5d771a  vmovaps [rsp+0x30], xmm3
000079f9de5d7720  vmovaps [rsp+0x40], xmm4
000079f9de5d7726  vmovaps [rsp+0x50], xmm5
000079f9de5d772c  vmovaps [rsp+0x60], xmm6
000079f9de5d7732  vmovaps [rsp+0x70], xmm8
000079f9de5d7738  vmovaps [rsp+0x80], xmm9
000079f9de5d7741  vmovaps [rsp+0x90], xmm10
000079f9de5d774a  vmovaps [rsp+0xA0], xmm11
000079f9de5d7753  vmovaps [rsp+0xB0], xmm12
000079f9de5d775c  vmovaps [rsp+0xC0], xmm13
000079f9de5d7765  vmovaps [rsp+0xD0], xmm14
000079f9de5d776e  vmovaps [rsp+0xE0], xmm15
000079f9de5d7777  sub rsp, 0x30
000079f9de5d777b  movaps [rsp], xmm7
000079f9de5d777f  movaps [rsp+0x10], xmm4
000079f9de5d7784  movaps [rsp+0x20], xmm9
000079f9de5d778a  lea rdi, [rsp]
000079f9de5d778e  mov esi, 0x00
000079f9de5d7793  mov rax, 0x56D56FF59530
000079f9de5d779d  call rax
000079f9de5d779f  movaps xmm7, [rsp]
000079f9de5d77a3  add rsp, 0x30
000079f9de5d77a7  vmovaps xmm0, [rsp]
000079f9de5d77ac  vmovaps xmm1, [rsp+0x10]
000079f9de5d77b2  vmovaps xmm2, [rsp+0x20]
000079f9de5d77b8  vmovaps xmm3, [rsp+0x30]
000079f9de5d77be  vmovaps xmm4, [rsp+0x40]
000079f9de5d77c4  vmovaps xmm5, [rsp+0x50]
000079f9de5d77ca  vmovaps xmm6, [rsp+0x60]
000079f9de5d77d0  vmovaps xmm8, [rsp+0x70]
000079f9de5d77d6  vmovaps xmm9, [rsp+0x80]
000079f9de5d77df  vmovaps xmm10, [rsp+0x90]
000079f9de5d77e8  vmovaps xmm11, [rsp+0xA0]
000079f9de5d77f1  vmovaps xmm12, [rsp+0xB0]
000079f9de5d77fa  vmovaps xmm13, [rsp+0xC0]
000079f9de5d7803  vmovaps xmm14, [rsp+0xD0]
000079f9de5d780c  vmovaps xmm15, [rsp+0xE0]
000079f9de5d7815  add rsp, 0xF0
000079f9de5d781c  pop r11
000079f9de5d781e  pop r10
000079f9de5d7820  pop r9
000079f9de5d7822  pop r8
000079f9de5d7824  pop rsi
000079f9de5d7825  pop rdi
000079f9de5d7826  pop rdx
000079f9de5d7827  pop rcx
000079f9de5d7828  pop rax
000079f9de5d7829  add rsp, 0x08
000079f9de5d782d  jmp 0x000079F9DE5D5CD4
000079f9de5d7832  sub rsp, 0x08
000079f9de5d7836  push rax
000079f9de5d7837  push rcx
000079f9de5d7838  push rdx
000079f9de5d7839  push rdi
000079f9de5d783a  push rsi
000079f9de5d783b  push r8
000079f9de5d783d  push r9
000079f9de5d783f  push r10
000079f9de5d7841  push r11
000079f9de5d7843  sub rsp, 0xF0
000079f9de5d784a  vmovaps [rsp], xmm0
000079f9de5d784f  vmovaps [rsp+0x10], xmm1
000079f9de5d7855  vmovaps [rsp+0x20], xmm2
000079f9de5d785b  vmovaps [rsp+0x30], xmm3
000079f9de5d7861  vmovaps [rsp+0x40], xmm5
000079f9de5d7867  vmovaps [rsp+0x50], xmm6
000079f9de5d786d  vmovaps [rsp+0x60], xmm7
000079f9de5d7873  vmovaps [rsp+0x70], xmm8
000079f9de5d7879  vmovaps [rsp+0x80], xmm9
000079f9de5d7882  vmovaps [rsp+0x90], xmm10
000079f9de5d788b  vmovaps [rsp+0xA0], xmm11
000079f9de5d7894  vmovaps [rsp+0xB0], xmm12
000079f9de5d789d  vmovaps [rsp+0xC0], xmm13
000079f9de5d78a6  vmovaps [rsp+0xD0], xmm14
000079f9de5d78af  vmovaps [rsp+0xE0], xmm15
000079f9de5d78b8  sub rsp, 0x30
000079f9de5d78bc  movaps [rsp], xmm4
000079f9de5d78c0  movaps [rsp+0x10], xmm15
000079f9de5d78c6  movaps [rsp+0x20], xmm9
000079f9de5d78cc  lea rdi, [rsp]
000079f9de5d78d0  mov esi, 0x00
000079f9de5d78d5  mov rax, 0x56D56FF59530
000079f9de5d78df  call rax
000079f9de5d78e1  movaps xmm4, [rsp]
000079f9de5d78e5  add rsp, 0x30
000079f9de5d78e9  vmovaps xmm0, [rsp]
000079f9de5d78ee  vmovaps xmm1, [rsp+0x10]
000079f9de5d78f4  vmovaps xmm2, [rsp+0x20]
000079f9de5d78fa  vmovaps xmm3, [rsp+0x30]
000079f9de5d7900  vmovaps xmm5, [rsp+0x40]
000079f9de5d7906  vmovaps xmm6, [rsp+0x50]
000079f9de5d790c  vmovaps xmm7, [rsp+0x60]
000079f9de5d7912  vmovaps xmm8, [rsp+0x70]
000079f9de5d7918  vmovaps xmm9, [rsp+0x80]
000079f9de5d7921  vmovaps xmm10, [rsp+0x90]
000079f9de5d792a  vmovaps xmm11, [rsp+0xA0]
000079f9de5d7933  vmovaps xmm12, [rsp+0xB0]
000079f9de5d793c  vmovaps xmm13, [rsp+0xC0]
000079f9de5d7945  vmovaps xmm14, [rsp+0xD0]
000079f9de5d794e  vmovaps xmm15, [rsp+0xE0]
000079f9de5d7957  add rsp, 0xF0
000079f9de5d795e  pop r11
000079f9de5d7960  pop r10
000079f9de5d7962  pop r9
000079f9de5d7964  pop r8
000079f9de5d7966  pop rsi
000079f9de5d7967  pop rdi
000079f9de5d7968  pop rdx
000079f9de5d7969  pop rcx
000079f9de5d796a  pop rax
000079f9de5d796b  add rsp, 0x08
000079f9de5d796f  jmp 0x000079F9DE5D5CF9
000079f9de5d7974  call 0x000079F9DE4E5820
000079f9de5d7979  jmp 0x000079F9DE5D5D06
000079f9de5d797e  sub rsp, 0x08
000079f9de5d7982  push rax
000079f9de5d7983  push rcx
000079f9de5d7984  push rdx
000079f9de5d7985  push rdi
000079f9de5d7986  push rsi
000079f9de5d7987  push r8
000079f9de5d7989  push r9
000079f9de5d798b  push r10
000079f9de5d798d  push r11
000079f9de5d798f  sub rsp, 0xF0
000079f9de5d7996  vmovaps [rsp], xmm0
000079f9de5d799b  vmovaps [rsp+0x10], xmm1
000079f9de5d79a1  vmovaps [rsp+0x20], xmm2
000079f9de5d79a7  vmovaps [rsp+0x30], xmm4
000079f9de5d79ad  vmovaps [rsp+0x40], xmm5
000079f9de5d79b3  vmovaps [rsp+0x50], xmm6
000079f9de5d79b9  vmovaps [rsp+0x60], xmm7
000079f9de5d79bf  vmovaps [rsp+0x70], xmm8
000079f9de5d79c5  vmovaps [rsp+0x80], xmm9
000079f9de5d79ce  vmovaps [rsp+0x90], xmm10
000079f9de5d79d7  vmovaps [rsp+0xA0], xmm11
000079f9de5d79e0  vmovaps [rsp+0xB0], xmm12
000079f9de5d79e9  vmovaps [rsp+0xC0], xmm13
000079f9de5d79f2  vmovaps [rsp+0xD0], xmm14
000079f9de5d79fb  vmovaps [rsp+0xE0], xmm15
000079f9de5d7a04  sub rsp, 0x30
000079f9de5d7a08  movaps [rsp], xmm3
000079f9de5d7a0c  movaps [rsp+0x10], xmm1
000079f9de5d7a11  movaps [rsp+0x20], xmm9
000079f9de5d7a17  lea rdi, [rsp]
000079f9de5d7a1b  mov esi, 0x00
000079f9de5d7a20  mov rax, 0x56D56FF59530
000079f9de5d7a2a  call rax
000079f9de5d7a2c  movaps xmm3, [rsp]
000079f9de5d7a30  add rsp, 0x30
000079f9de5d7a34  vmovaps xmm0, [rsp]
000079f9de5d7a39  vmovaps xmm1, [rsp+0x10]
000079f9de5d7a3f  vmovaps xmm2, [rsp+0x20]
000079f9de5d7a45  vmovaps xmm4, [rsp+0x30]
000079f9de5d7a4b  vmovaps xmm5, [rsp+0x40]
000079f9de5d7a51  vmovaps xmm6, [rsp+0x50]
000079f9de5d7a57  vmovaps xmm7, [rsp+0x60]
000079f9de5d7a5d  vmovaps xmm8, [rsp+0x70]
000079f9de5d7a63  vmovaps xmm9, [rsp+0x80]
000079f9de5d7a6c  vmovaps xmm10, [rsp+0x90]
000079f9de5d7a75  vmovaps xmm11, [rsp+0xA0]
000079f9de5d7a7e  vmovaps xmm12, [rsp+0xB0]
000079f9de5d7a87  vmovaps xmm13, [rsp+0xC0]
000079f9de5d7a90  vmovaps xmm14, [rsp+0xD0]
000079f9de5d7a99  vmovaps xmm15, [rsp+0xE0]
000079f9de5d7aa2  add rsp, 0xF0
000079f9de5d7aa9  pop r11
000079f9de5d7aab  pop r10
000079f9de5d7aad  pop r9
000079f9de5d7aaf  pop r8
000079f9de5d7ab1  pop rsi
000079f9de5d7ab2  pop rdi
000079f9de5d7ab3  pop rdx
000079f9de5d7ab4  pop rcx
000079f9de5d7ab5  pop rax
000079f9de5d7ab6  add rsp, 0x08
000079f9de5d7aba  jmp 0x000079F9DE5D5D43
000079f9de5d7abf  sub rsp, 0x08
000079f9de5d7ac3  push rax
000079f9de5d7ac4  push rcx
000079f9de5d7ac5  push rdx
000079f9de5d7ac6  push rdi
000079f9de5d7ac7  push rsi
000079f9de5d7ac8  push r8
000079f9de5d7aca  push r9
000079f9de5d7acc  push r10
000079f9de5d7ace  push r11
000079f9de5d7ad0  sub rsp, 0xF0
000079f9de5d7ad7  vmovaps [rsp], xmm0
000079f9de5d7adc  vmovaps [rsp+0x10], xmm2
000079f9de5d7ae2  vmovaps [rsp+0x20], xmm3
000079f9de5d7ae8  vmovaps [rsp+0x30], xmm4
000079f9de5d7aee  vmovaps [rsp+0x40], xmm5
000079f9de5d7af4  vmovaps [rsp+0x50], xmm6
000079f9de5d7afa  vmovaps [rsp+0x60], xmm7
000079f9de5d7b00  vmovaps [rsp+0x70], xmm8
000079f9de5d7b06  vmovaps [rsp+0x80], xmm9
000079f9de5d7b0f  vmovaps [rsp+0x90], xmm10
000079f9de5d7b18  vmovaps [rsp+0xA0], xmm11
000079f9de5d7b21  vmovaps [rsp+0xB0], xmm12
000079f9de5d7b2a  vmovaps [rsp+0xC0], xmm13
000079f9de5d7b33  vmovaps [rsp+0xD0], xmm14
000079f9de5d7b3c  vmovaps [rsp+0xE0], xmm15
000079f9de5d7b45  sub rsp, 0x30
000079f9de5d7b49  movaps [rsp], xmm1
000079f9de5d7b4d  movaps [rsp+0x10], xmm15
000079f9de5d7b53  movaps [rsp+0x20], xmm9
000079f9de5d7b59  lea rdi, [rsp]
000079f9de5d7b5d  mov esi, 0x00
000079f9de5d7b62  mov rax, 0x56D56FF59530
000079f9de5d7b6c  call rax
000079f9de5d7b6e  movaps xmm1, [rsp]
000079f9de5d7b72  add rsp, 0x30
000079f9de5d7b76  vmovaps xmm0, [rsp]
000079f9de5d7b7b  vmovaps xmm2, [rsp+0x10]
000079f9de5d7b81  vmovaps xmm3, [rsp+0x20]
000079f9de5d7b87  vmovaps xmm4, [rsp+0x30]
000079f9de5d7b8d  vmovaps xmm5, [rsp+0x40]
000079f9de5d7b93  vmovaps xmm6, [rsp+0x50]
000079f9de5d7b99  vmovaps xmm7, [rsp+0x60]
000079f9de5d7b9f  vmovaps xmm8, [rsp+0x70]
000079f9de5d7ba5  vmovaps xmm9, [rsp+0x80]
000079f9de5d7bae  vmovaps xmm10, [rsp+0x90]
000079f9de5d7bb7  vmovaps xmm11, [rsp+0xA0]
000079f9de5d7bc0  vmovaps xmm12, [rsp+0xB0]
000079f9de5d7bc9  vmovaps xmm13, [rsp+0xC0]
000079f9de5d7bd2  vmovaps xmm14, [rsp+0xD0]
000079f9de5d7bdb  vmovaps xmm15, [rsp+0xE0]
000079f9de5d7be4  add rsp, 0xF0
000079f9de5d7beb  pop r11
000079f9de5d7bed  pop r10
000079f9de5d7bef  pop r9
000079f9de5d7bf1  pop r8
000079f9de5d7bf3  pop rsi
000079f9de5d7bf4  pop rdi
000079f9de5d7bf5  pop rdx
000079f9de5d7bf6  pop rcx
000079f9de5d7bf7  pop rax
000079f9de5d7bf8  add rsp, 0x08
000079f9de5d7bfc  jmp 0x000079F9DE5D5DCB
000079f9de5d7c01  call 0x000079F9DE4E5820
000079f9de5d7c06  jmp 0x000079F9DE5D5DD8
000079f9de5d7c0b  sub rsp, 0x08
000079f9de5d7c0f  push rax
000079f9de5d7c10  push rcx
000079f9de5d7c11  push rdx
000079f9de5d7c12  push rdi
000079f9de5d7c13  push rsi
000079f9de5d7c14  push r8
000079f9de5d7c16  push r9
000079f9de5d7c18  push r10
000079f9de5d7c1a  push r11
000079f9de5d7c1c  sub rsp, 0xF0
000079f9de5d7c23  vmovaps [rsp], xmm0
000079f9de5d7c28  vmovaps [rsp+0x10], xmm2
000079f9de5d7c2e  vmovaps [rsp+0x20], xmm3
000079f9de5d7c34  vmovaps [rsp+0x30], xmm4
000079f9de5d7c3a  vmovaps [rsp+0x40], xmm5
000079f9de5d7c40  vmovaps [rsp+0x50], xmm6
000079f9de5d7c46  vmovaps [rsp+0x60], xmm7
000079f9de5d7c4c  vmovaps [rsp+0x70], xmm8
000079f9de5d7c52  vmovaps [rsp+0x80], xmm9
000079f9de5d7c5b  vmovaps [rsp+0x90], xmm10
000079f9de5d7c64  vmovaps [rsp+0xA0], xmm11
000079f9de5d7c6d  vmovaps [rsp+0xB0], xmm12
000079f9de5d7c76  vmovaps [rsp+0xC0], xmm13
000079f9de5d7c7f  vmovaps [rsp+0xD0], xmm14
000079f9de5d7c88  vmovaps [rsp+0xE0], xmm15
000079f9de5d7c91  sub rsp, 0x30
000079f9de5d7c95  movaps [rsp], xmm1
000079f9de5d7c99  movaps [rsp+0x10], xmm5
000079f9de5d7c9e  movaps [rsp+0x20], xmm7
000079f9de5d7ca3  lea rdi, [rsp]
000079f9de5d7ca7  mov esi, 0x00
000079f9de5d7cac  mov rax, 0x56D56FF59530
000079f9de5d7cb6  call rax
000079f9de5d7cb8  movaps xmm1, [rsp]
000079f9de5d7cbc  add rsp, 0x30
000079f9de5d7cc0  vmovaps xmm0, [rsp]
000079f9de5d7cc5  vmovaps xmm2, [rsp+0x10]
000079f9de5d7ccb  vmovaps xmm3, [rsp+0x20]
000079f9de5d7cd1  vmovaps xmm4, [rsp+0x30]
000079f9de5d7cd7  vmovaps xmm5, [rsp+0x40]
000079f9de5d7cdd  vmovaps xmm6, [rsp+0x50]
000079f9de5d7ce3  vmovaps xmm7, [rsp+0x60]
000079f9de5d7ce9  vmovaps xmm8, [rsp+0x70]
000079f9de5d7cef  vmovaps xmm9, [rsp+0x80]
000079f9de5d7cf8  vmovaps xmm10, [rsp+0x90]
000079f9de5d7d01  vmovaps xmm11, [rsp+0xA0]
000079f9de5d7d0a  vmovaps xmm12, [rsp+0xB0]
000079f9de5d7d13  vmovaps xmm13, [rsp+0xC0]
000079f9de5d7d1c  vmovaps xmm14, [rsp+0xD0]
000079f9de5d7d25  vmovaps xmm15, [rsp+0xE0]
000079f9de5d7d2e  add rsp, 0xF0
000079f9de5d7d35  pop r11
000079f9de5d7d37  pop r10
000079f9de5d7d39  pop r9
000079f9de5d7d3b  pop r8
000079f9de5d7d3d  pop rsi
000079f9de5d7d3e  pop rdi
000079f9de5d7d3f  pop rdx
000079f9de5d7d40  pop rcx
000079f9de5d7d41  pop rax
000079f9de5d7d42  add rsp, 0x08
000079f9de5d7d46  jmp 0x000079F9DE5D5E7D
000079f9de5d7d4b  sub rsp, 0x08
000079f9de5d7d4f  push rax
000079f9de5d7d50  push rcx
000079f9de5d7d51  push rdx
000079f9de5d7d52  push rdi
000079f9de5d7d53  push rsi
000079f9de5d7d54  push r8
000079f9de5d7d56  push r9
000079f9de5d7d58  push r10
000079f9de5d7d5a  push r11
000079f9de5d7d5c  sub rsp, 0xF0
000079f9de5d7d63  vmovaps [rsp], xmm0
000079f9de5d7d68  vmovaps [rsp+0x10], xmm1
000079f9de5d7d6e  vmovaps [rsp+0x20], xmm2
000079f9de5d7d74  vmovaps [rsp+0x30], xmm3
000079f9de5d7d7a  vmovaps [rsp+0x40], xmm4
000079f9de5d7d80  vmovaps [rsp+0x50], xmm5
000079f9de5d7d86  vmovaps [rsp+0x60], xmm6
000079f9de5d7d8c  vmovaps [rsp+0x70], xmm8
000079f9de5d7d92  vmovaps [rsp+0x80], xmm9
000079f9de5d7d9b  vmovaps [rsp+0x90], xmm10
000079f9de5d7da4  vmovaps [rsp+0xA0], xmm11
000079f9de5d7dad  vmovaps [rsp+0xB0], xmm12
000079f9de5d7db6  vmovaps [rsp+0xC0], xmm13
000079f9de5d7dbf  vmovaps [rsp+0xD0], xmm14
000079f9de5d7dc8  vmovaps [rsp+0xE0], xmm15
000079f9de5d7dd1  sub rsp, 0x30
000079f9de5d7dd5  movaps [rsp], xmm7
000079f9de5d7dd9  movaps [rsp+0x10], xmm5
000079f9de5d7dde  movaps [rsp+0x20], xmm15
000079f9de5d7de4  lea rdi, [rsp]
000079f9de5d7de8  mov esi, 0x00
000079f9de5d7ded  mov rax, 0x56D56FF59530
000079f9de5d7df7  call rax
000079f9de5d7df9  movaps xmm7, [rsp]
000079f9de5d7dfd  add rsp, 0x30
000079f9de5d7e01  vmovaps xmm0, [rsp]
000079f9de5d7e06  vmovaps xmm1, [rsp+0x10]
000079f9de5d7e0c  vmovaps xmm2, [rsp+0x20]
000079f9de5d7e12  vmovaps xmm3, [rsp+0x30]
000079f9de5d7e18  vmovaps xmm4, [rsp+0x40]
000079f9de5d7e1e  vmovaps xmm5, [rsp+0x50]
000079f9de5d7e24  vmovaps xmm6, [rsp+0x60]
000079f9de5d7e2a  vmovaps xmm8, [rsp+0x70]
000079f9de5d7e30  vmovaps xmm9, [rsp+0x80]
000079f9de5d7e39  vmovaps xmm10, [rsp+0x90]
000079f9de5d7e42  vmovaps xmm11, [rsp+0xA0]
000079f9de5d7e4b  vmovaps xmm12, [rsp+0xB0]
000079f9de5d7e54  vmovaps xmm13, [rsp+0xC0]
000079f9de5d7e5d  vmovaps xmm14, [rsp+0xD0]
000079f9de5d7e66  vmovaps xmm15, [rsp+0xE0]
000079f9de5d7e6f  add rsp, 0xF0
000079f9de5d7e76  pop r11
000079f9de5d7e78  pop r10
000079f9de5d7e7a  pop r9
000079f9de5d7e7c  pop r8
000079f9de5d7e7e  pop rsi
000079f9de5d7e7f  pop rdi
000079f9de5d7e80  pop rdx
000079f9de5d7e81  pop rcx
000079f9de5d7e82  pop rax
000079f9de5d7e83  add rsp, 0x08
000079f9de5d7e87  jmp 0x000079F9DE5D5EB3
000079f9de5d7e8c  call 0x000079F9DE4D64F0
000079f9de5d7e91  jmp 0x000079F9DE5D5EC0
000079f9de5d7e96  sub rsp, 0x08
000079f9de5d7e9a  push rax
000079f9de5d7e9b  push rcx
000079f9de5d7e9c  push rdx
000079f9de5d7e9d  push rdi
000079f9de5d7e9e  push rsi
000079f9de5d7e9f  push r8
000079f9de5d7ea1  push r9
000079f9de5d7ea3  push r10
000079f9de5d7ea5  push r11
000079f9de5d7ea7  sub rsp, 0xF0
000079f9de5d7eae  vmovaps [rsp], xmm0
000079f9de5d7eb3  vmovaps [rsp+0x10], xmm1
000079f9de5d7eb9  vmovaps [rsp+0x20], xmm2
000079f9de5d7ebf  vmovaps [rsp+0x30], xmm3
000079f9de5d7ec5  vmovaps [rsp+0x40], xmm4
000079f9de5d7ecb  vmovaps [rsp+0x50], xmm5
000079f9de5d7ed1  vmovaps [rsp+0x60], xmm6
000079f9de5d7ed7  vmovaps [rsp+0x70], xmm7
000079f9de5d7edd  vmovaps [rsp+0x80], xmm8
000079f9de5d7ee6  vmovaps [rsp+0x90], xmm9
000079f9de5d7eef  vmovaps [rsp+0xA0], xmm10
000079f9de5d7ef8  vmovaps [rsp+0xB0], xmm11
000079f9de5d7f01  vmovaps [rsp+0xC0], xmm12
000079f9de5d7f0a  vmovaps [rsp+0xD0], xmm13
000079f9de5d7f13  vmovaps [rsp+0xE0], xmm14
000079f9de5d7f1c  sub rsp, 0x30
000079f9de5d7f20  movaps [rsp], xmm15
000079f9de5d7f25  movaps [rsp+0x10], xmm5
000079f9de5d7f2a  movaps [rsp+0x20], xmm3
000079f9de5d7f2f  lea rdi, [rsp]
000079f9de5d7f33  mov esi, 0x00
000079f9de5d7f38  mov rax, 0x56D56FF59530
000079f9de5d7f42  call rax
000079f9de5d7f44  movaps xmm15, [rsp]
000079f9de5d7f49  add rsp, 0x30
000079f9de5d7f4d  vmovaps xmm0, [rsp]
000079f9de5d7f52  vmovaps xmm1, [rsp+0x10]
000079f9de5d7f58  vmovaps xmm2, [rsp+0x20]
000079f9de5d7f5e  vmovaps xmm3, [rsp+0x30]
000079f9de5d7f64  vmovaps xmm4, [rsp+0x40]
000079f9de5d7f6a  vmovaps xmm5, [rsp+0x50]
000079f9de5d7f70  vmovaps xmm6, [rsp+0x60]
000079f9de5d7f76  vmovaps xmm7, [rsp+0x70]
000079f9de5d7f7c  vmovaps xmm8, [rsp+0x80]
000079f9de5d7f85  vmovaps xmm9, [rsp+0x90]
000079f9de5d7f8e  vmovaps xmm10, [rsp+0xA0]
000079f9de5d7f97  vmovaps xmm11, [rsp+0xB0]
000079f9de5d7fa0  vmovaps xmm12, [rsp+0xC0]
000079f9de5d7fa9  vmovaps xmm13, [rsp+0xD0]
000079f9de5d7fb2  vmovaps xmm14, [rsp+0xE0]
000079f9de5d7fbb  add rsp, 0xF0
000079f9de5d7fc2  pop r11
000079f9de5d7fc4  pop r10
000079f9de5d7fc6  pop r9
000079f9de5d7fc8  pop r8
000079f9de5d7fca  pop rsi
000079f9de5d7fcb  pop rdi
000079f9de5d7fcc  pop rdx
000079f9de5d7fcd  pop rcx
000079f9de5d7fce  pop rax
000079f9de5d7fcf  add rsp, 0x08
000079f9de5d7fd3  jmp 0x000079F9DE5D5EE6
000079f9de5d7fd8  sub rsp, 0x08
000079f9de5d7fdc  push rax
000079f9de5d7fdd  push rcx
000079f9de5d7fde  push rdx
000079f9de5d7fdf  push rdi
000079f9de5d7fe0  push rsi
000079f9de5d7fe1  push r8
000079f9de5d7fe3  push r9
000079f9de5d7fe5  push r10
000079f9de5d7fe7  push r11
000079f9de5d7fe9  sub rsp, 0xF0
000079f9de5d7ff0  vmovaps [rsp], xmm0
000079f9de5d7ff5  vmovaps [rsp+0x10], xmm2
000079f9de5d7ffb  vmovaps [rsp+0x20], xmm3
000079f9de5d8001  vmovaps [rsp+0x30], xmm4
000079f9de5d8007  vmovaps [rsp+0x40], xmm5
000079f9de5d800d  vmovaps [rsp+0x50], xmm6
000079f9de5d8013  vmovaps [rsp+0x60], xmm7
000079f9de5d8019  vmovaps [rsp+0x70], xmm8
000079f9de5d801f  vmovaps [rsp+0x80], xmm9
000079f9de5d8028  vmovaps [rsp+0x90], xmm10
000079f9de5d8031  vmovaps [rsp+0xA0], xmm11
000079f9de5d803a  vmovaps [rsp+0xB0], xmm12
000079f9de5d8043  vmovaps [rsp+0xC0], xmm13
000079f9de5d804c  vmovaps [rsp+0xD0], xmm14
000079f9de5d8055  vmovaps [rsp+0xE0], xmm15
000079f9de5d805e  sub rsp, 0x30
000079f9de5d8062  movaps [rsp], xmm1
000079f9de5d8066  movaps [rsp+0x10], xmm5
000079f9de5d806b  movaps [rsp+0x20], xmm4
000079f9de5d8070  lea rdi, [rsp]
000079f9de5d8074  mov esi, 0x00
000079f9de5d8079  mov rax, 0x56D56FF59530
000079f9de5d8083  call rax
000079f9de5d8085  movaps xmm1, [rsp]
000079f9de5d8089  add rsp, 0x30
000079f9de5d808d  vmovaps xmm0, [rsp]
000079f9de5d8092  vmovaps xmm2, [rsp+0x10]
000079f9de5d8098  vmovaps xmm3, [rsp+0x20]
000079f9de5d809e  vmovaps xmm4, [rsp+0x30]
000079f9de5d80a4  vmovaps xmm5, [rsp+0x40]
000079f9de5d80aa  vmovaps xmm6, [rsp+0x50]
000079f9de5d80b0  vmovaps xmm7, [rsp+0x60]
000079f9de5d80b6  vmovaps xmm8, [rsp+0x70]
000079f9de5d80bc  vmovaps xmm9, [rsp+0x80]
000079f9de5d80c5  vmovaps xmm10, [rsp+0x90]
000079f9de5d80ce  vmovaps xmm11, [rsp+0xA0]
000079f9de5d80d7  vmovaps xmm12, [rsp+0xB0]
000079f9de5d80e0  vmovaps xmm13, [rsp+0xC0]
000079f9de5d80e9  vmovaps xmm14, [rsp+0xD0]
000079f9de5d80f2  vmovaps xmm15, [rsp+0xE0]
000079f9de5d80fb  add rsp, 0xF0
000079f9de5d8102  pop r11
000079f9de5d8104  pop r10
000079f9de5d8106  pop r9
000079f9de5d8108  pop r8
000079f9de5d810a  pop rsi
000079f9de5d810b  pop rdi
000079f9de5d810c  pop rdx
000079f9de5d810d  pop rcx
000079f9de5d810e  pop rax
000079f9de5d810f  add rsp, 0x08
000079f9de5d8113  jmp 0x000079F9DE5D5F06
000079f9de5d8118  sub rsp, 0x08
000079f9de5d811c  push rax
000079f9de5d811d  push rcx
000079f9de5d811e  push rdx
000079f9de5d811f  push rdi
000079f9de5d8120  push rsi
000079f9de5d8121  push r8
000079f9de5d8123  push r9
000079f9de5d8125  push r10
000079f9de5d8127  push r11
000079f9de5d8129  sub rsp, 0xF0
000079f9de5d8130  vmovaps [rsp], xmm0
000079f9de5d8135  vmovaps [rsp+0x10], xmm1
000079f9de5d813b  vmovaps [rsp+0x20], xmm2
000079f9de5d8141  vmovaps [rsp+0x30], xmm3
000079f9de5d8147  vmovaps [rsp+0x40], xmm5
000079f9de5d814d  vmovaps [rsp+0x50], xmm6
000079f9de5d8153  vmovaps [rsp+0x60], xmm7
000079f9de5d8159  vmovaps [rsp+0x70], xmm8
000079f9de5d815f  vmovaps [rsp+0x80], xmm9
000079f9de5d8168  vmovaps [rsp+0x90], xmm10
000079f9de5d8171  vmovaps [rsp+0xA0], xmm11
000079f9de5d817a  vmovaps [rsp+0xB0], xmm12
000079f9de5d8183  vmovaps [rsp+0xC0], xmm13
000079f9de5d818c  vmovaps [rsp+0xD0], xmm14
000079f9de5d8195  vmovaps [rsp+0xE0], xmm15
000079f9de5d819e  sub rsp, 0x30
000079f9de5d81a2  movaps [rsp], xmm4
000079f9de5d81a6  movaps [rsp+0x10], xmm3
000079f9de5d81ab  movaps [rsp+0x20], xmm5
000079f9de5d81b0  lea rdi, [rsp]
000079f9de5d81b4  mov esi, 0x00
000079f9de5d81b9  mov rax, 0x56D56FF59530
000079f9de5d81c3  call rax
000079f9de5d81c5  movaps xmm4, [rsp]
000079f9de5d81c9  add rsp, 0x30
000079f9de5d81cd  vmovaps xmm0, [rsp]
000079f9de5d81d2  vmovaps xmm1, [rsp+0x10]
000079f9de5d81d8  vmovaps xmm2, [rsp+0x20]
000079f9de5d81de  vmovaps xmm3, [rsp+0x30]
000079f9de5d81e4  vmovaps xmm5, [rsp+0x40]
000079f9de5d81ea  vmovaps xmm6, [rsp+0x50]
000079f9de5d81f0  vmovaps xmm7, [rsp+0x60]
000079f9de5d81f6  vmovaps xmm8, [rsp+0x70]
000079f9de5d81fc  vmovaps xmm9, [rsp+0x80]
000079f9de5d8205  vmovaps xmm10, [rsp+0x90]
000079f9de5d820e  vmovaps xmm11, [rsp+0xA0]
000079f9de5d8217  vmovaps xmm12, [rsp+0xB0]
000079f9de5d8220  vmovaps xmm13, [rsp+0xC0]
000079f9de5d8229  vmovaps xmm14, [rsp+0xD0]
000079f9de5d8232  vmovaps xmm15, [rsp+0xE0]
000079f9de5d823b  add rsp, 0xF0
000079f9de5d8242  pop r11
000079f9de5d8244  pop r10
000079f9de5d8246  pop r9
000079f9de5d8248  pop r8
000079f9de5d824a  pop rsi
000079f9de5d824b  pop rdi
000079f9de5d824c  pop rdx
000079f9de5d824d  pop rcx
000079f9de5d824e  pop rax
000079f9de5d824f  add rsp, 0x08
000079f9de5d8253  jmp 0x000079F9DE5D5F54
000079f9de5d8258  call 0x000079F9DE4D64F0
000079f9de5d825d  jmp 0x000079F9DE5D5F61
000079f9de5d8262  sub rsp, 0x08
000079f9de5d8266  push rax
000079f9de5d8267  push rcx
000079f9de5d8268  push rdx
000079f9de5d8269  push rdi
000079f9de5d826a  push rsi
000079f9de5d826b  push r8
000079f9de5d826d  push r9
000079f9de5d826f  push r10
000079f9de5d8271  push r11
000079f9de5d8273  sub rsp, 0xF0
000079f9de5d827a  vmovaps [rsp], xmm0
000079f9de5d827f  vmovaps [rsp+0x10], xmm1
000079f9de5d8285  vmovaps [rsp+0x20], xmm2
000079f9de5d828b  vmovaps [rsp+0x30], xmm3
000079f9de5d8291  vmovaps [rsp+0x40], xmm4
000079f9de5d8297  vmovaps [rsp+0x50], xmm6
000079f9de5d829d  vmovaps [rsp+0x60], xmm7
000079f9de5d82a3  vmovaps [rsp+0x70], xmm8
000079f9de5d82a9  vmovaps [rsp+0x80], xmm9
000079f9de5d82b2  vmovaps [rsp+0x90], xmm10
000079f9de5d82bb  vmovaps [rsp+0xA0], xmm11
000079f9de5d82c4  vmovaps [rsp+0xB0], xmm12
000079f9de5d82cd  vmovaps [rsp+0xC0], xmm13
000079f9de5d82d6  vmovaps [rsp+0xD0], xmm14
000079f9de5d82df  vmovaps [rsp+0xE0], xmm15
000079f9de5d82e8  sub rsp, 0x30
000079f9de5d82ec  movaps [rsp], xmm5
000079f9de5d82f0  movaps [rsp+0x10], xmm6
000079f9de5d82f5  movaps [rsp+0x20], xmm3
000079f9de5d82fa  lea rdi, [rsp]
000079f9de5d82fe  mov esi, 0x00
000079f9de5d8303  mov rax, 0x56D56FF59530
000079f9de5d830d  call rax
000079f9de5d830f  movaps xmm5, [rsp]
000079f9de5d8313  add rsp, 0x30
000079f9de5d8317  vmovaps xmm0, [rsp]
000079f9de5d831c  vmovaps xmm1, [rsp+0x10]
000079f9de5d8322  vmovaps xmm2, [rsp+0x20]
000079f9de5d8328  vmovaps xmm3, [rsp+0x30]
000079f9de5d832e  vmovaps xmm4, [rsp+0x40]
000079f9de5d8334  vmovaps xmm6, [rsp+0x50]
000079f9de5d833a  vmovaps xmm7, [rsp+0x60]
000079f9de5d8340  vmovaps xmm8, [rsp+0x70]
000079f9de5d8346  vmovaps xmm9, [rsp+0x80]
000079f9de5d834f  vmovaps xmm10, [rsp+0x90]
000079f9de5d8358  vmovaps xmm11, [rsp+0xA0]
000079f9de5d8361  vmovaps xmm12, [rsp+0xB0]
000079f9de5d836a  vmovaps xmm13, [rsp+0xC0]
000079f9de5d8373  vmovaps xmm14, [rsp+0xD0]
000079f9de5d837c  vmovaps xmm15, [rsp+0xE0]
000079f9de5d8385  add rsp, 0xF0
000079f9de5d838c  pop r11
000079f9de5d838e  pop r10
000079f9de5d8390  pop r9
000079f9de5d8392  pop r8
000079f9de5d8394  pop rsi
000079f9de5d8395  pop rdi
000079f9de5d8396  pop rdx
000079f9de5d8397  pop rcx
000079f9de5d8398  pop rax
000079f9de5d8399  add rsp, 0x08
000079f9de5d839d  jmp 0x000079F9DE5D5F87
000079f9de5d83a2  sub rsp, 0x08
000079f9de5d83a6  push rax
000079f9de5d83a7  push rcx
000079f9de5d83a8  push rdx
000079f9de5d83a9  push rdi
000079f9de5d83aa  push rsi
000079f9de5d83ab  push r8
000079f9de5d83ad  push r9
000079f9de5d83af  push r10
000079f9de5d83b1  push r11
000079f9de5d83b3  sub rsp, 0xF0
000079f9de5d83ba  vmovaps [rsp], xmm0
000079f9de5d83bf  vmovaps [rsp+0x10], xmm1
000079f9de5d83c5  vmovaps [rsp+0x20], xmm2
000079f9de5d83cb  vmovaps [rsp+0x30], xmm3
000079f9de5d83d1  vmovaps [rsp+0x40], xmm4
000079f9de5d83d7  vmovaps [rsp+0x50], xmm5
000079f9de5d83dd  vmovaps [rsp+0x60], xmm7
000079f9de5d83e3  vmovaps [rsp+0x70], xmm8
000079f9de5d83e9  vmovaps [rsp+0x80], xmm9
000079f9de5d83f2  vmovaps [rsp+0x90], xmm10
000079f9de5d83fb  vmovaps [rsp+0xA0], xmm11
000079f9de5d8404  vmovaps [rsp+0xB0], xmm12
000079f9de5d840d  vmovaps [rsp+0xC0], xmm13
000079f9de5d8416  vmovaps [rsp+0xD0], xmm14
000079f9de5d841f  vmovaps [rsp+0xE0], xmm15
000079f9de5d8428  sub rsp, 0x30
000079f9de5d842c  movaps [rsp], xmm6
000079f9de5d8430  movaps [rsp+0x10], xmm9
000079f9de5d8436  movaps [rsp+0x20], xmm1
000079f9de5d843b  lea rdi, [rsp]
000079f9de5d843f  mov esi, 0x00
000079f9de5d8444  mov rax, 0x56D56FF59530
000079f9de5d844e  call rax
000079f9de5d8450  movaps xmm6, [rsp]
000079f9de5d8454  add rsp, 0x30
000079f9de5d8458  vmovaps xmm0, [rsp]
000079f9de5d845d  vmovaps xmm1, [rsp+0x10]
000079f9de5d8463  vmovaps xmm2, [rsp+0x20]
000079f9de5d8469  vmovaps xmm3, [rsp+0x30]
000079f9de5d846f  vmovaps xmm4, [rsp+0x40]
000079f9de5d8475  vmovaps xmm5, [rsp+0x50]
000079f9de5d847b  vmovaps xmm7, [rsp+0x60]
000079f9de5d8481  vmovaps xmm8, [rsp+0x70]
000079f9de5d8487  vmovaps xmm9, [rsp+0x80]
000079f9de5d8490  vmovaps xmm10, [rsp+0x90]
000079f9de5d8499  vmovaps xmm11, [rsp+0xA0]
000079f9de5d84a2  vmovaps xmm12, [rsp+0xB0]
000079f9de5d84ab  vmovaps xmm13, [rsp+0xC0]
000079f9de5d84b4  vmovaps xmm14, [rsp+0xD0]
000079f9de5d84bd  vmovaps xmm15, [rsp+0xE0]
000079f9de5d84c6  add rsp, 0xF0
000079f9de5d84cd  pop r11
000079f9de5d84cf  pop r10
000079f9de5d84d1  pop r9
000079f9de5d84d3  pop r8
000079f9de5d84d5  pop rsi
000079f9de5d84d6  pop rdi
000079f9de5d84d7  pop rdx
000079f9de5d84d8  pop rcx
000079f9de5d84d9  pop rax
000079f9de5d84da  add rsp, 0x08
000079f9de5d84de  jmp 0x000079F9DE5D5FAB
000079f9de5d84e3  sub rsp, 0x08
000079f9de5d84e7  push rax
000079f9de5d84e8  push rcx
000079f9de5d84e9  push rdx
000079f9de5d84ea  push rdi
000079f9de5d84eb  push rsi
000079f9de5d84ec  push r8
000079f9de5d84ee  push r9
000079f9de5d84f0  push r10
000079f9de5d84f2  push r11
000079f9de5d84f4  sub rsp, 0xF0
000079f9de5d84fb  vmovaps [rsp], xmm0
000079f9de5d8500  vmovaps [rsp+0x10], xmm1
000079f9de5d8506  vmovaps [rsp+0x20], xmm2
000079f9de5d850c  vmovaps [rsp+0x30], xmm3
000079f9de5d8512  vmovaps [rsp+0x40], xmm4
000079f9de5d8518  vmovaps [rsp+0x50], xmm5
000079f9de5d851e  vmovaps [rsp+0x60], xmm6
000079f9de5d8524  vmovaps [rsp+0x70], xmm7
000079f9de5d852a  vmovaps [rsp+0x80], xmm8
000079f9de5d8533  vmovaps [rsp+0x90], xmm10
000079f9de5d853c  vmovaps [rsp+0xA0], xmm11
000079f9de5d8545  vmovaps [rsp+0xB0], xmm12
000079f9de5d854e  vmovaps [rsp+0xC0], xmm13
000079f9de5d8557  vmovaps [rsp+0xD0], xmm14
000079f9de5d8560  vmovaps [rsp+0xE0], xmm15
000079f9de5d8569  sub rsp, 0x30
000079f9de5d856d  movaps [rsp], xmm9
000079f9de5d8572  movaps [rsp+0x10], xmm3
000079f9de5d8577  movaps [rsp+0x20], xmm1
000079f9de5d857c  lea rdi, [rsp]
000079f9de5d8580  mov esi, 0x00
000079f9de5d8585  mov rax, 0x56D56FF59530
000079f9de5d858f  call rax
000079f9de5d8591  movaps xmm9, [rsp]
000079f9de5d8596  add rsp, 0x30
000079f9de5d859a  vmovaps xmm0, [rsp]
000079f9de5d859f  vmovaps xmm1, [rsp+0x10]
000079f9de5d85a5  vmovaps xmm2, [rsp+0x20]
000079f9de5d85ab  vmovaps xmm3, [rsp+0x30]
000079f9de5d85b1  vmovaps xmm4, [rsp+0x40]
000079f9de5d85b7  vmovaps xmm5, [rsp+0x50]
000079f9de5d85bd  vmovaps xmm6, [rsp+0x60]
000079f9de5d85c3  vmovaps xmm7, [rsp+0x70]
000079f9de5d85c9  vmovaps xmm8, [rsp+0x80]
000079f9de5d85d2  vmovaps xmm10, [rsp+0x90]
000079f9de5d85db  vmovaps xmm11, [rsp+0xA0]
000079f9de5d85e4  vmovaps xmm12, [rsp+0xB0]
000079f9de5d85ed  vmovaps xmm13, [rsp+0xC0]
000079f9de5d85f6  vmovaps xmm14, [rsp+0xD0]
000079f9de5d85ff  vmovaps xmm15, [rsp+0xE0]
000079f9de5d8608  add rsp, 0xF0
000079f9de5d860f  pop r11
000079f9de5d8611  pop r10
000079f9de5d8613  pop r9
000079f9de5d8615  pop r8
000079f9de5d8617  pop rsi
000079f9de5d8618  pop rdi
000079f9de5d8619  pop rdx
000079f9de5d861a  pop rcx
000079f9de5d861b  pop rax
000079f9de5d861c  add rsp, 0x08
000079f9de5d8620  jmp 0x000079F9DE5D5FF7
000079f9de5d8625  call 0x000079F9DE4D64F0
000079f9de5d862a  jmp 0x000079F9DE5D6004
000079f9de5d862f  sub rsp, 0x08
000079f9de5d8633  push rax
000079f9de5d8634  push rcx
000079f9de5d8635  push rdx
000079f9de5d8636  push rdi
000079f9de5d8637  push rsi
000079f9de5d8638  push r8
000079f9de5d863a  push r9
000079f9de5d863c  push r10
000079f9de5d863e  push r11
000079f9de5d8640  sub rsp, 0xF0
000079f9de5d8647  vmovaps [rsp], xmm0
000079f9de5d864c  vmovaps [rsp+0x10], xmm1
000079f9de5d8652  vmovaps [rsp+0x20], xmm2
000079f9de5d8658  vmovaps [rsp+0x30], xmm3
000079f9de5d865e  vmovaps [rsp+0x40], xmm4
000079f9de5d8664  vmovaps [rsp+0x50], xmm5
000079f9de5d866a  vmovaps [rsp+0x60], xmm6
000079f9de5d8670  vmovaps [rsp+0x70], xmm7
000079f9de5d8676  vmovaps [rsp+0x80], xmm8
000079f9de5d867f  vmovaps [rsp+0x90], xmm9
000079f9de5d8688  vmovaps [rsp+0xA0], xmm10
000079f9de5d8691  vmovaps [rsp+0xB0], xmm11
000079f9de5d869a  vmovaps [rsp+0xC0], xmm12
000079f9de5d86a3  vmovaps [rsp+0xD0], xmm13
000079f9de5d86ac  vmovaps [rsp+0xE0], xmm14
000079f9de5d86b5  sub rsp, 0x30
000079f9de5d86b9  movaps [rsp], xmm15
000079f9de5d86be  movaps [rsp+0x10], xmm3
000079f9de5d86c3  movaps [rsp+0x20], xmm7
000079f9de5d86c8  lea rdi, [rsp]
000079f9de5d86cc  mov esi, 0x00
000079f9de5d86d1  mov rax, 0x56D56FF59530
000079f9de5d86db  call rax
000079f9de5d86dd  movaps xmm15, [rsp]
000079f9de5d86e2  add rsp, 0x30
000079f9de5d86e6  vmovaps xmm0, [rsp]
000079f9de5d86eb  vmovaps xmm1, [rsp+0x10]
000079f9de5d86f1  vmovaps xmm2, [rsp+0x20]
000079f9de5d86f7  vmovaps xmm3, [rsp+0x30]
000079f9de5d86fd  vmovaps xmm4, [rsp+0x40]
000079f9de5d8703  vmovaps xmm5, [rsp+0x50]
000079f9de5d8709  vmovaps xmm6, [rsp+0x60]
000079f9de5d870f  vmovaps xmm7, [rsp+0x70]
000079f9de5d8715  vmovaps xmm8, [rsp+0x80]
000079f9de5d871e  vmovaps xmm9, [rsp+0x90]
000079f9de5d8727  vmovaps xmm10, [rsp+0xA0]
000079f9de5d8730  vmovaps xmm11, [rsp+0xB0]
000079f9de5d8739  vmovaps xmm12, [rsp+0xC0]
000079f9de5d8742  vmovaps xmm13, [rsp+0xD0]
000079f9de5d874b  vmovaps xmm14, [rsp+0xE0]
000079f9de5d8754  add rsp, 0xF0
000079f9de5d875b  pop r11
000079f9de5d875d  pop r10
000079f9de5d875f  pop r9
000079f9de5d8761  pop r8
000079f9de5d8763  pop rsi
000079f9de5d8764  pop rdi
000079f9de5d8765  pop rdx
000079f9de5d8766  pop rcx
000079f9de5d8767  pop rax
000079f9de5d8768  add rsp, 0x08
000079f9de5d876c  jmp 0x000079F9DE5D6030
000079f9de5d8771  sub rsp, 0x08
000079f9de5d8775  push rax
000079f9de5d8776  push rcx
000079f9de5d8777  push rdx
000079f9de5d8778  push rdi
000079f9de5d8779  push rsi
000079f9de5d877a  push r8
000079f9de5d877c  push r9
000079f9de5d877e  push r10
000079f9de5d8780  push r11
000079f9de5d8782  sub rsp, 0xF0
000079f9de5d8789  vmovaps [rsp], xmm0
000079f9de5d878e  vmovaps [rsp+0x10], xmm1
000079f9de5d8794  vmovaps [rsp+0x20], xmm2
000079f9de5d879a  vmovaps [rsp+0x30], xmm4
000079f9de5d87a0  vmovaps [rsp+0x40], xmm5
000079f9de5d87a6  vmovaps [rsp+0x50], xmm6
000079f9de5d87ac  vmovaps [rsp+0x60], xmm7
000079f9de5d87b2  vmovaps [rsp+0x70], xmm8
000079f9de5d87b8  vmovaps [rsp+0x80], xmm9
000079f9de5d87c1  vmovaps [rsp+0x90], xmm10
000079f9de5d87ca  vmovaps [rsp+0xA0], xmm11
000079f9de5d87d3  vmovaps [rsp+0xB0], xmm12
000079f9de5d87dc  vmovaps [rsp+0xC0], xmm13
000079f9de5d87e5  vmovaps [rsp+0xD0], xmm14
000079f9de5d87ee  vmovaps [rsp+0xE0], xmm15
000079f9de5d87f7  sub rsp, 0x30
000079f9de5d87fb  movaps [rsp], xmm3
000079f9de5d87ff  movaps [rsp+0x10], xmm1
000079f9de5d8804  movaps [rsp+0x20], xmm15
000079f9de5d880a  lea rdi, [rsp]
000079f9de5d880e  mov esi, 0x00
000079f9de5d8813  mov rax, 0x56D56FF59530
000079f9de5d881d  call rax
000079f9de5d881f  movaps xmm3, [rsp]
000079f9de5d8823  add rsp, 0x30
000079f9de5d8827  vmovaps xmm0, [rsp]
000079f9de5d882c  vmovaps xmm1, [rsp+0x10]
000079f9de5d8832  vmovaps xmm2, [rsp+0x20]
000079f9de5d8838  vmovaps xmm4, [rsp+0x30]
000079f9de5d883e  vmovaps xmm5, [rsp+0x40]
000079f9de5d8844  vmovaps xmm6, [rsp+0x50]
000079f9de5d884a  vmovaps xmm7, [rsp+0x60]
000079f9de5d8850  vmovaps xmm8, [rsp+0x70]
000079f9de5d8856  vmovaps xmm9, [rsp+0x80]
000079f9de5d885f  vmovaps xmm10, [rsp+0x90]
000079f9de5d8868  vmovaps xmm11, [rsp+0xA0]
000079f9de5d8871  vmovaps xmm12, [rsp+0xB0]
000079f9de5d887a  vmovaps xmm13, [rsp+0xC0]
000079f9de5d8883  vmovaps xmm14, [rsp+0xD0]
000079f9de5d888c  vmovaps xmm15, [rsp+0xE0]
000079f9de5d8895  add rsp, 0xF0
000079f9de5d889c  pop r11
000079f9de5d889e  pop r10
000079f9de5d88a0  pop r9
000079f9de5d88a2  pop r8
000079f9de5d88a4  pop rsi
000079f9de5d88a5  pop rdi
000079f9de5d88a6  pop rdx
000079f9de5d88a7  pop rcx
000079f9de5d88a8  pop rax
000079f9de5d88a9  add rsp, 0x08
000079f9de5d88ad  jmp 0x000079F9DE5D60BF
000079f9de5d88b2  call 0x000079F9DE4D64F0
000079f9de5d88b7  jmp 0x000079F9DE5D60C9
000079f9de5d88bc  sub rsp, 0x08
000079f9de5d88c0  push rax
000079f9de5d88c1  push rcx
000079f9de5d88c2  push rdx
000079f9de5d88c3  push rdi
000079f9de5d88c4  push rsi
000079f9de5d88c5  push r8
000079f9de5d88c7  push r9
000079f9de5d88c9  push r10
000079f9de5d88cb  push r11
000079f9de5d88cd  sub rsp, 0xF0
000079f9de5d88d4  vmovaps [rsp], xmm0
000079f9de5d88d9  vmovaps [rsp+0x10], xmm1
000079f9de5d88df  vmovaps [rsp+0x20], xmm2
000079f9de5d88e5  vmovaps [rsp+0x30], xmm3
000079f9de5d88eb  vmovaps [rsp+0x40], xmm4
000079f9de5d88f1  vmovaps [rsp+0x50], xmm5
000079f9de5d88f7  vmovaps [rsp+0x60], xmm6
000079f9de5d88fd  vmovaps [rsp+0x70], xmm7
000079f9de5d8903  vmovaps [rsp+0x80], xmm8
000079f9de5d890c  vmovaps [rsp+0x90], xmm9
000079f9de5d8915  vmovaps [rsp+0xA0], xmm10
000079f9de5d891e  vmovaps [rsp+0xB0], xmm11
000079f9de5d8927  vmovaps [rsp+0xC0], xmm12
000079f9de5d8930  vmovaps [rsp+0xD0], xmm13
000079f9de5d8939  vmovaps [rsp+0xE0], xmm14
000079f9de5d8942  sub rsp, 0x30
000079f9de5d8946  movaps [rsp], xmm15
000079f9de5d894b  movaps [rsp+0x10], xmm14
000079f9de5d8951  movaps [rsp+0x20], xmm4
000079f9de5d8956  lea rdi, [rsp]
000079f9de5d895a  mov esi, 0x00
000079f9de5d895f  mov rax, 0x56D56FF59530
000079f9de5d8969  call rax
000079f9de5d896b  movaps xmm15, [rsp]
000079f9de5d8970  add rsp, 0x30
000079f9de5d8974  vmovaps xmm0, [rsp]
000079f9de5d8979  vmovaps xmm1, [rsp+0x10]
000079f9de5d897f  vmovaps xmm2, [rsp+0x20]
000079f9de5d8985  vmovaps xmm3, [rsp+0x30]
000079f9de5d898b  vmovaps xmm4, [rsp+0x40]
000079f9de5d8991  vmovaps xmm5, [rsp+0x50]
000079f9de5d8997  vmovaps xmm6, [rsp+0x60]
000079f9de5d899d  vmovaps xmm7, [rsp+0x70]
000079f9de5d89a3  vmovaps xmm8, [rsp+0x80]
000079f9de5d89ac  vmovaps xmm9, [rsp+0x90]
000079f9de5d89b5  vmovaps xmm10, [rsp+0xA0]
000079f9de5d89be  vmovaps xmm11, [rsp+0xB0]
000079f9de5d89c7  vmovaps xmm12, [rsp+0xC0]
000079f9de5d89d0  vmovaps xmm13, [rsp+0xD0]
000079f9de5d89d9  vmovaps xmm14, [rsp+0xE0]
000079f9de5d89e2  add rsp, 0xF0
000079f9de5d89e9  pop r11
000079f9de5d89eb  pop r10
000079f9de5d89ed  pop r9
000079f9de5d89ef  pop r8
000079f9de5d89f1  pop rsi
000079f9de5d89f2  pop rdi
000079f9de5d89f3  pop rdx
000079f9de5d89f4  pop rcx
000079f9de5d89f5  pop rax
000079f9de5d89f6  add rsp, 0x08
000079f9de5d89fa  jmp 0x000079F9DE5D60F7
000079f9de5d89ff  sub rsp, 0x08
000079f9de5d8a03  push rax
000079f9de5d8a04  push rcx
000079f9de5d8a05  push rdx
000079f9de5d8a06  push rdi
000079f9de5d8a07  push rsi
000079f9de5d8a08  push r8
000079f9de5d8a0a  push r9
000079f9de5d8a0c  push r10
000079f9de5d8a0e  push r11
000079f9de5d8a10  sub rsp, 0xF0
000079f9de5d8a17  vmovaps [rsp], xmm0
000079f9de5d8a1c  vmovaps [rsp+0x10], xmm1
000079f9de5d8a22  vmovaps [rsp+0x20], xmm2
000079f9de5d8a28  vmovaps [rsp+0x30], xmm3
000079f9de5d8a2e  vmovaps [rsp+0x40], xmm4
000079f9de5d8a34  vmovaps [rsp+0x50], xmm5
000079f9de5d8a3a  vmovaps [rsp+0x60], xmm6
000079f9de5d8a40  vmovaps [rsp+0x70], xmm7
000079f9de5d8a46  vmovaps [rsp+0x80], xmm8
000079f9de5d8a4f  vmovaps [rsp+0x90], xmm9
000079f9de5d8a58  vmovaps [rsp+0xA0], xmm10
000079f9de5d8a61  vmovaps [rsp+0xB0], xmm11
000079f9de5d8a6a  vmovaps [rsp+0xC0], xmm12
000079f9de5d8a73  vmovaps [rsp+0xD0], xmm13
000079f9de5d8a7c  vmovaps [rsp+0xE0], xmm15
000079f9de5d8a85  sub rsp, 0x30
000079f9de5d8a89  movaps [rsp], xmm14
000079f9de5d8a8e  movaps [rsp+0x10], xmm2
000079f9de5d8a93  movaps [rsp+0x20], xmm1
000079f9de5d8a98  lea rdi, [rsp]
000079f9de5d8a9c  mov esi, 0x00
000079f9de5d8aa1  mov rax, 0x56D56FF59530
000079f9de5d8aab  call rax
000079f9de5d8aad  movaps xmm14, [rsp]
000079f9de5d8ab2  add rsp, 0x30
000079f9de5d8ab6  vmovaps xmm0, [rsp]
000079f9de5d8abb  vmovaps xmm1, [rsp+0x10]
000079f9de5d8ac1  vmovaps xmm2, [rsp+0x20]
000079f9de5d8ac7  vmovaps xmm3, [rsp+0x30]
000079f9de5d8acd  vmovaps xmm4, [rsp+0x40]
000079f9de5d8ad3  vmovaps xmm5, [rsp+0x50]
000079f9de5d8ad9  vmovaps xmm6, [rsp+0x60]
000079f9de5d8adf  vmovaps xmm7, [rsp+0x70]
000079f9de5d8ae5  vmovaps xmm8, [rsp+0x80]
000079f9de5d8aee  vmovaps xmm9, [rsp+0x90]
000079f9de5d8af7  vmovaps xmm10, [rsp+0xA0]
000079f9de5d8b00  vmovaps xmm11, [rsp+0xB0]
000079f9de5d8b09  vmovaps xmm12, [rsp+0xC0]
000079f9de5d8b12  vmovaps xmm13, [rsp+0xD0]
000079f9de5d8b1b  vmovaps xmm15, [rsp+0xE0]
000079f9de5d8b24  add rsp, 0xF0
000079f9de5d8b2b  pop r11
000079f9de5d8b2d  pop r10
000079f9de5d8b2f  pop r9
000079f9de5d8b31  pop r8
000079f9de5d8b33  pop rsi
000079f9de5d8b34  pop rdi
000079f9de5d8b35  pop rdx
000079f9de5d8b36  pop rcx
000079f9de5d8b37  pop rax
000079f9de5d8b38  add rsp, 0x08
000079f9de5d8b3c  jmp 0x000079F9DE5D611D
000079f9de5d8b41  sub rsp, 0x08
000079f9de5d8b45  push rax
000079f9de5d8b46  push rcx
000079f9de5d8b47  push rdx
000079f9de5d8b48  push rdi
000079f9de5d8b49  push rsi
000079f9de5d8b4a  push r8
000079f9de5d8b4c  push r9
000079f9de5d8b4e  push r10
000079f9de5d8b50  push r11
000079f9de5d8b52  sub rsp, 0xF0
000079f9de5d8b59  vmovaps [rsp], xmm0
000079f9de5d8b5e  vmovaps [rsp+0x10], xmm2
000079f9de5d8b64  vmovaps [rsp+0x20], xmm3
000079f9de5d8b6a  vmovaps [rsp+0x30], xmm4
000079f9de5d8b70  vmovaps [rsp+0x40], xmm5
000079f9de5d8b76  vmovaps [rsp+0x50], xmm6
000079f9de5d8b7c  vmovaps [rsp+0x60], xmm7
000079f9de5d8b82  vmovaps [rsp+0x70], xmm8
000079f9de5d8b88  vmovaps [rsp+0x80], xmm9
000079f9de5d8b91  vmovaps [rsp+0x90], xmm10
000079f9de5d8b9a  vmovaps [rsp+0xA0], xmm11
000079f9de5d8ba3  vmovaps [rsp+0xB0], xmm12
000079f9de5d8bac  vmovaps [rsp+0xC0], xmm13
000079f9de5d8bb5  vmovaps [rsp+0xD0], xmm14
000079f9de5d8bbe  vmovaps [rsp+0xE0], xmm15
000079f9de5d8bc7  sub rsp, 0x30
000079f9de5d8bcb  movaps [rsp], xmm1
000079f9de5d8bcf  movaps [rsp+0x10], xmm4
000079f9de5d8bd4  movaps [rsp+0x20], xmm9
000079f9de5d8bda  lea rdi, [rsp]
000079f9de5d8bde  mov esi, 0x00
000079f9de5d8be3  mov rax, 0x56D56FF59530
000079f9de5d8bed  call rax
000079f9de5d8bef  movaps xmm1, [rsp]
000079f9de5d8bf3  add rsp, 0x30
000079f9de5d8bf7  vmovaps xmm0, [rsp]
000079f9de5d8bfc  vmovaps xmm2, [rsp+0x10]
000079f9de5d8c02  vmovaps xmm3, [rsp+0x20]
000079f9de5d8c08  vmovaps xmm4, [rsp+0x30]
000079f9de5d8c0e  vmovaps xmm5, [rsp+0x40]
000079f9de5d8c14  vmovaps xmm6, [rsp+0x50]
000079f9de5d8c1a  vmovaps xmm7, [rsp+0x60]
000079f9de5d8c20  vmovaps xmm8, [rsp+0x70]
000079f9de5d8c26  vmovaps xmm9, [rsp+0x80]
000079f9de5d8c2f  vmovaps xmm10, [rsp+0x90]
000079f9de5d8c38  vmovaps xmm11, [rsp+0xA0]
000079f9de5d8c41  vmovaps xmm12, [rsp+0xB0]
000079f9de5d8c4a  vmovaps xmm13, [rsp+0xC0]
000079f9de5d8c53  vmovaps xmm14, [rsp+0xD0]
000079f9de5d8c5c  vmovaps xmm15, [rsp+0xE0]
000079f9de5d8c65  add rsp, 0xF0
000079f9de5d8c6c  pop r11
000079f9de5d8c6e  pop r10
000079f9de5d8c70  pop r9
000079f9de5d8c72  pop r8
000079f9de5d8c74  pop rsi
000079f9de5d8c75  pop rdi
000079f9de5d8c76  pop rdx
000079f9de5d8c77  pop rcx
000079f9de5d8c78  pop rax
000079f9de5d8c79  add rsp, 0x08
000079f9de5d8c7d  jmp 0x000079F9DE5D613B
000079f9de5d8c82  sub rsp, 0x08
000079f9de5d8c86  push rax
000079f9de5d8c87  push rcx
000079f9de5d8c88  push rdx
000079f9de5d8c89  push rdi
000079f9de5d8c8a  push rsi
000079f9de5d8c8b  push r8
000079f9de5d8c8d  push r9
000079f9de5d8c8f  push r10
000079f9de5d8c91  push r11
000079f9de5d8c93  sub rsp, 0xF0
000079f9de5d8c9a  vmovaps [rsp], xmm0
000079f9de5d8c9f  vmovaps [rsp+0x10], xmm1
000079f9de5d8ca5  vmovaps [rsp+0x20], xmm2
000079f9de5d8cab  vmovaps [rsp+0x30], xmm3
000079f9de5d8cb1  vmovaps [rsp+0x40], xmm5
000079f9de5d8cb7  vmovaps [rsp+0x50], xmm6
000079f9de5d8cbd  vmovaps [rsp+0x60], xmm7
000079f9de5d8cc3  vmovaps [rsp+0x70], xmm8
000079f9de5d8cc9  vmovaps [rsp+0x80], xmm9
000079f9de5d8cd2  vmovaps [rsp+0x90], xmm10
000079f9de5d8cdb  vmovaps [rsp+0xA0], xmm11
000079f9de5d8ce4  vmovaps [rsp+0xB0], xmm12
000079f9de5d8ced  vmovaps [rsp+0xC0], xmm13
000079f9de5d8cf6  vmovaps [rsp+0xD0], xmm14
000079f9de5d8cff  vmovaps [rsp+0xE0], xmm15
000079f9de5d8d08  sub rsp, 0x30
000079f9de5d8d0c  movaps [rsp], xmm4
000079f9de5d8d10  movaps [rsp+0x10], xmm2
000079f9de5d8d15  movaps [rsp+0x20], xmm9
000079f9de5d8d1b  lea rdi, [rsp]
000079f9de5d8d1f  mov esi, 0x00
000079f9de5d8d24  mov rax, 0x56D56FF59530
000079f9de5d8d2e  call rax
000079f9de5d8d30  movaps xmm4, [rsp]
000079f9de5d8d34  add rsp, 0x30
000079f9de5d8d38  vmovaps xmm0, [rsp]
000079f9de5d8d3d  vmovaps xmm1, [rsp+0x10]
000079f9de5d8d43  vmovaps xmm2, [rsp+0x20]
000079f9de5d8d49  vmovaps xmm3, [rsp+0x30]
000079f9de5d8d4f  vmovaps xmm5, [rsp+0x40]
000079f9de5d8d55  vmovaps xmm6, [rsp+0x50]
000079f9de5d8d5b  vmovaps xmm7, [rsp+0x60]
000079f9de5d8d61  vmovaps xmm8, [rsp+0x70]
000079f9de5d8d67  vmovaps xmm9, [rsp+0x80]
000079f9de5d8d70  vmovaps xmm10, [rsp+0x90]
000079f9de5d8d79  vmovaps xmm11, [rsp+0xA0]
000079f9de5d8d82  vmovaps xmm12, [rsp+0xB0]
000079f9de5d8d8b  vmovaps xmm13, [rsp+0xC0]
000079f9de5d8d94  vmovaps xmm14, [rsp+0xD0]
000079f9de5d8d9d  vmovaps xmm15, [rsp+0xE0]
000079f9de5d8da6  add rsp, 0xF0
000079f9de5d8dad  pop r11
000079f9de5d8daf  pop r10
000079f9de5d8db1  pop r9
000079f9de5d8db3  pop r8
000079f9de5d8db5  pop rsi
000079f9de5d8db6  pop rdi
000079f9de5d8db7  pop rdx
000079f9de5d8db8  pop rcx
000079f9de5d8db9  pop rax
000079f9de5d8dba  add rsp, 0x08
000079f9de5d8dbe  jmp 0x000079F9DE5D616B
000079f9de5d8dc3  sub rsp, 0x08
000079f9de5d8dc7  push rax
000079f9de5d8dc8  push rcx
000079f9de5d8dc9  push rdx
000079f9de5d8dca  push rdi
000079f9de5d8dcb  push rsi
000079f9de5d8dcc  push r8
000079f9de5d8dce  push r9
000079f9de5d8dd0  push r10
000079f9de5d8dd2  push r11
000079f9de5d8dd4  sub rsp, 0xF0
000079f9de5d8ddb  vmovaps [rsp], xmm0
000079f9de5d8de0  vmovaps [rsp+0x10], xmm1
000079f9de5d8de6  vmovaps [rsp+0x20], xmm2
000079f9de5d8dec  vmovaps [rsp+0x30], xmm3
000079f9de5d8df2  vmovaps [rsp+0x40], xmm4
000079f9de5d8df8  vmovaps [rsp+0x50], xmm5
000079f9de5d8dfe  vmovaps [rsp+0x60], xmm6
000079f9de5d8e04  vmovaps [rsp+0x70], xmm7
000079f9de5d8e0a  vmovaps [rsp+0x80], xmm8
000079f9de5d8e13  vmovaps [rsp+0x90], xmm10
000079f9de5d8e1c  vmovaps [rsp+0xA0], xmm11
000079f9de5d8e25  vmovaps [rsp+0xB0], xmm12
000079f9de5d8e2e  vmovaps [rsp+0xC0], xmm13
000079f9de5d8e37  vmovaps [rsp+0xD0], xmm14
000079f9de5d8e40  vmovaps [rsp+0xE0], xmm15
000079f9de5d8e49  sub rsp, 0x30
000079f9de5d8e4d  movaps [rsp], xmm9
000079f9de5d8e52  movaps [rsp+0x10], xmm2
000079f9de5d8e57  movaps [rsp+0x20], xmm1
000079f9de5d8e5c  lea rdi, [rsp]
000079f9de5d8e60  mov esi, 0x00
000079f9de5d8e65  mov rax, 0x56D56FF59530
000079f9de5d8e6f  call rax
000079f9de5d8e71  movaps xmm9, [rsp]
000079f9de5d8e76  add rsp, 0x30
000079f9de5d8e7a  vmovaps xmm0, [rsp]
000079f9de5d8e7f  vmovaps xmm1, [rsp+0x10]
000079f9de5d8e85  vmovaps xmm2, [rsp+0x20]
000079f9de5d8e8b  vmovaps xmm3, [rsp+0x30]
000079f9de5d8e91  vmovaps xmm4, [rsp+0x40]
000079f9de5d8e97  vmovaps xmm5, [rsp+0x50]
000079f9de5d8e9d  vmovaps xmm6, [rsp+0x60]
000079f9de5d8ea3  vmovaps xmm7, [rsp+0x70]
000079f9de5d8ea9  vmovaps xmm8, [rsp+0x80]
000079f9de5d8eb2  vmovaps xmm10, [rsp+0x90]
000079f9de5d8ebb  vmovaps xmm11, [rsp+0xA0]
000079f9de5d8ec4  vmovaps xmm12, [rsp+0xB0]
000079f9de5d8ecd  vmovaps xmm13, [rsp+0xC0]
000079f9de5d8ed6  vmovaps xmm14, [rsp+0xD0]
000079f9de5d8edf  vmovaps xmm15, [rsp+0xE0]
000079f9de5d8ee8  add rsp, 0xF0
000079f9de5d8eef  pop r11
000079f9de5d8ef1  pop r10
000079f9de5d8ef3  pop r9
000079f9de5d8ef5  pop r8
000079f9de5d8ef7  pop rsi
000079f9de5d8ef8  pop rdi
000079f9de5d8ef9  pop rdx
000079f9de5d8efa  pop rcx
000079f9de5d8efb  pop rax
000079f9de5d8efc  add rsp, 0x08
000079f9de5d8f00  jmp 0x000079F9DE5D61A1
000079f9de5d8f05  sub rsp, 0x08
000079f9de5d8f09  push rax
000079f9de5d8f0a  push rcx
000079f9de5d8f0b  push rdx
000079f9de5d8f0c  push rdi
000079f9de5d8f0d  push rsi
000079f9de5d8f0e  push r8
000079f9de5d8f10  push r9
000079f9de5d8f12  push r10
000079f9de5d8f14  push r11
000079f9de5d8f16  sub rsp, 0xF0
000079f9de5d8f1d  vmovaps [rsp], xmm0
000079f9de5d8f22  vmovaps [rsp+0x10], xmm2
000079f9de5d8f28  vmovaps [rsp+0x20], xmm3
000079f9de5d8f2e  vmovaps [rsp+0x30], xmm4
000079f9de5d8f34  vmovaps [rsp+0x40], xmm5
000079f9de5d8f3a  vmovaps [rsp+0x50], xmm6
000079f9de5d8f40  vmovaps [rsp+0x60], xmm7
000079f9de5d8f46  vmovaps [rsp+0x70], xmm8
000079f9de5d8f4c  vmovaps [rsp+0x80], xmm9
000079f9de5d8f55  vmovaps [rsp+0x90], xmm10
000079f9de5d8f5e  vmovaps [rsp+0xA0], xmm11
000079f9de5d8f67  vmovaps [rsp+0xB0], xmm12
000079f9de5d8f70  vmovaps [rsp+0xC0], xmm13
000079f9de5d8f79  vmovaps [rsp+0xD0], xmm14
000079f9de5d8f82  vmovaps [rsp+0xE0], xmm15
000079f9de5d8f8b  sub rsp, 0x30
000079f9de5d8f8f  movaps [rsp], xmm1
000079f9de5d8f93  movaps [rsp+0x10], xmm15
000079f9de5d8f99  movaps [rsp+0x20], xmm6
000079f9de5d8f9e  lea rdi, [rsp]
000079f9de5d8fa2  mov esi, 0x00
000079f9de5d8fa7  mov rax, 0x56D56FF59530
000079f9de5d8fb1  call rax
000079f9de5d8fb3  movaps xmm1, [rsp]
000079f9de5d8fb7  add rsp, 0x30
000079f9de5d8fbb  vmovaps xmm0, [rsp]
000079f9de5d8fc0  vmovaps xmm2, [rsp+0x10]
000079f9de5d8fc6  vmovaps xmm3, [rsp+0x20]
000079f9de5d8fcc  vmovaps xmm4, [rsp+0x30]
000079f9de5d8fd2  vmovaps xmm5, [rsp+0x40]
000079f9de5d8fd8  vmovaps xmm6, [rsp+0x50]
000079f9de5d8fde  vmovaps xmm7, [rsp+0x60]
000079f9de5d8fe4  vmovaps xmm8, [rsp+0x70]
000079f9de5d8fea  vmovaps xmm9, [rsp+0x80]
000079f9de5d8ff3  vmovaps xmm10, [rsp+0x90]
000079f9de5d8ffc  vmovaps xmm11, [rsp+0xA0]
000079f9de5d9005  vmovaps xmm12, [rsp+0xB0]
000079f9de5d900e  vmovaps xmm13, [rsp+0xC0]
000079f9de5d9017  vmovaps xmm14, [rsp+0xD0]
000079f9de5d9020  vmovaps xmm15, [rsp+0xE0]
000079f9de5d9029  add rsp, 0xF0
000079f9de5d9030  pop r11
000079f9de5d9032  pop r10
000079f9de5d9034  pop r9
000079f9de5d9036  pop r8
000079f9de5d9038  pop rsi
000079f9de5d9039  pop rdi
000079f9de5d903a  pop rdx
000079f9de5d903b  pop rcx
000079f9de5d903c  pop rax
000079f9de5d903d  add rsp, 0x08
000079f9de5d9041  jmp 0x000079F9DE5D61C2
000079f9de5d9046  sub rsp, 0x08
000079f9de5d904a  push rax
000079f9de5d904b  push rcx
000079f9de5d904c  push rdx
000079f9de5d904d  push rdi
000079f9de5d904e  push rsi
000079f9de5d904f  push r8
000079f9de5d9051  push r9
000079f9de5d9053  push r10
000079f9de5d9055  push r11
000079f9de5d9057  sub rsp, 0xF0
000079f9de5d905e  vmovaps [rsp], xmm0
000079f9de5d9063  vmovaps [rsp+0x10], xmm1
000079f9de5d9069  vmovaps [rsp+0x20], xmm2
000079f9de5d906f  vmovaps [rsp+0x30], xmm3
000079f9de5d9075  vmovaps [rsp+0x40], xmm4
000079f9de5d907b  vmovaps [rsp+0x50], xmm5
000079f9de5d9081  vmovaps [rsp+0x60], xmm6
000079f9de5d9087  vmovaps [rsp+0x70], xmm7
000079f9de5d908d  vmovaps [rsp+0x80], xmm8
000079f9de5d9096  vmovaps [rsp+0x90], xmm9
000079f9de5d909f  vmovaps [rsp+0xA0], xmm10
000079f9de5d90a8  vmovaps [rsp+0xB0], xmm11
000079f9de5d90b1  vmovaps [rsp+0xC0], xmm12
000079f9de5d90ba  vmovaps [rsp+0xD0], xmm13
000079f9de5d90c3  vmovaps [rsp+0xE0], xmm14
000079f9de5d90cc  sub rsp, 0x30
000079f9de5d90d0  movaps [rsp], xmm15
000079f9de5d90d5  movaps [rsp+0x10], xmm5
000079f9de5d90da  movaps [rsp+0x20], xmm3
000079f9de5d90df  lea rdi, [rsp]
000079f9de5d90e3  mov esi, 0x00
000079f9de5d90e8  mov rax, 0x56D56FF59530
000079f9de5d90f2  call rax
000079f9de5d90f4  movaps xmm15, [rsp]
000079f9de5d90f9  add rsp, 0x30
000079f9de5d90fd  vmovaps xmm0, [rsp]
000079f9de5d9102  vmovaps xmm1, [rsp+0x10]
000079f9de5d9108  vmovaps xmm2, [rsp+0x20]
000079f9de5d910e  vmovaps xmm3, [rsp+0x30]
000079f9de5d9114  vmovaps xmm4, [rsp+0x40]
000079f9de5d911a  vmovaps xmm5, [rsp+0x50]
000079f9de5d9120  vmovaps xmm6, [rsp+0x60]
000079f9de5d9126  vmovaps xmm7, [rsp+0x70]
000079f9de5d912c  vmovaps xmm8, [rsp+0x80]
000079f9de5d9135  vmovaps xmm9, [rsp+0x90]
000079f9de5d913e  vmovaps xmm10, [rsp+0xA0]
000079f9de5d9147  vmovaps xmm11, [rsp+0xB0]
000079f9de5d9150  vmovaps xmm12, [rsp+0xC0]
000079f9de5d9159  vmovaps xmm13, [rsp+0xD0]
000079f9de5d9162  vmovaps xmm14, [rsp+0xE0]
000079f9de5d916b  add rsp, 0xF0
000079f9de5d9172  pop r11
000079f9de5d9174  pop r10
000079f9de5d9176  pop r9
000079f9de5d9178  pop r8
000079f9de5d917a  pop rsi
000079f9de5d917b  pop rdi
000079f9de5d917c  pop rdx
000079f9de5d917d  pop rcx
000079f9de5d917e  pop rax
000079f9de5d917f  add rsp, 0x08
000079f9de5d9183  jmp 0x000079F9DE5D61DC
000079f9de5d9188  sub rsp, 0x08
000079f9de5d918c  push rax
000079f9de5d918d  push rcx
000079f9de5d918e  push rdx
000079f9de5d918f  push rdi
000079f9de5d9190  push rsi
000079f9de5d9191  push r8
000079f9de5d9193  push r9
000079f9de5d9195  push r10
000079f9de5d9197  push r11
000079f9de5d9199  sub rsp, 0xF0
000079f9de5d91a0  vmovaps [rsp], xmm0
000079f9de5d91a5  vmovaps [rsp+0x10], xmm1
000079f9de5d91ab  vmovaps [rsp+0x20], xmm2
000079f9de5d91b1  vmovaps [rsp+0x30], xmm3
000079f9de5d91b7  vmovaps [rsp+0x40], xmm4
000079f9de5d91bd  vmovaps [rsp+0x50], xmm6
000079f9de5d91c3  vmovaps [rsp+0x60], xmm7
000079f9de5d91c9  vmovaps [rsp+0x70], xmm8
000079f9de5d91cf  vmovaps [rsp+0x80], xmm9
000079f9de5d91d8  vmovaps [rsp+0x90], xmm10
000079f9de5d91e1  vmovaps [rsp+0xA0], xmm11
000079f9de5d91ea  vmovaps [rsp+0xB0], xmm12
000079f9de5d91f3  vmovaps [rsp+0xC0], xmm13
000079f9de5d91fc  vmovaps [rsp+0xD0], xmm14
000079f9de5d9205  vmovaps [rsp+0xE0], xmm15
000079f9de5d920e  sub rsp, 0x30
000079f9de5d9212  movaps [rsp], xmm5
000079f9de5d9216  movaps [rsp+0x10], xmm8
000079f9de5d921c  movaps [rsp+0x20], xmm6
000079f9de5d9221  lea rdi, [rsp]
000079f9de5d9225  mov esi, 0x00
000079f9de5d922a  mov rax, 0x56D56FF59530
000079f9de5d9234  call rax
000079f9de5d9236  movaps xmm5, [rsp]
000079f9de5d923a  add rsp, 0x30
000079f9de5d923e  vmovaps xmm0, [rsp]
000079f9de5d9243  vmovaps xmm1, [rsp+0x10]
000079f9de5d9249  vmovaps xmm2, [rsp+0x20]
000079f9de5d924f  vmovaps xmm3, [rsp+0x30]
000079f9de5d9255  vmovaps xmm4, [rsp+0x40]
000079f9de5d925b  vmovaps xmm6, [rsp+0x50]
000079f9de5d9261  vmovaps xmm7, [rsp+0x60]
000079f9de5d9267  vmovaps xmm8, [rsp+0x70]
000079f9de5d926d  vmovaps xmm9, [rsp+0x80]
000079f9de5d9276  vmovaps xmm10, [rsp+0x90]
000079f9de5d927f  vmovaps xmm11, [rsp+0xA0]
000079f9de5d9288  vmovaps xmm12, [rsp+0xB0]
000079f9de5d9291  vmovaps xmm13, [rsp+0xC0]
000079f9de5d929a  vmovaps xmm14, [rsp+0xD0]
000079f9de5d92a3  vmovaps xmm15, [rsp+0xE0]
000079f9de5d92ac  add rsp, 0xF0
000079f9de5d92b3  pop r11
000079f9de5d92b5  pop r10
000079f9de5d92b7  pop r9
000079f9de5d92b9  pop r8
000079f9de5d92bb  pop rsi
000079f9de5d92bc  pop rdi
000079f9de5d92bd  pop rdx
000079f9de5d92be  pop rcx
000079f9de5d92bf  pop rax
000079f9de5d92c0  add rsp, 0x08
000079f9de5d92c4  jmp 0x000079F9DE5D6200
000079f9de5d92c9  sub rsp, 0x08
000079f9de5d92cd  push rax
000079f9de5d92ce  push rcx
000079f9de5d92cf  push rdx
000079f9de5d92d0  push rdi
000079f9de5d92d1  push rsi
000079f9de5d92d2  push r8
000079f9de5d92d4  push r9
000079f9de5d92d6  push r10
000079f9de5d92d8  push r11
000079f9de5d92da  sub rsp, 0xF0
000079f9de5d92e1  vmovaps [rsp], xmm0
000079f9de5d92e6  vmovaps [rsp+0x10], xmm1
000079f9de5d92ec  vmovaps [rsp+0x20], xmm2
000079f9de5d92f2  vmovaps [rsp+0x30], xmm3
000079f9de5d92f8  vmovaps [rsp+0x40], xmm4
000079f9de5d92fe  vmovaps [rsp+0x50], xmm5
000079f9de5d9304  vmovaps [rsp+0x60], xmm7
000079f9de5d930a  vmovaps [rsp+0x70], xmm8
000079f9de5d9310  vmovaps [rsp+0x80], xmm9
000079f9de5d9319  vmovaps [rsp+0x90], xmm10
000079f9de5d9322  vmovaps [rsp+0xA0], xmm11
000079f9de5d932b  vmovaps [rsp+0xB0], xmm12
000079f9de5d9334  vmovaps [rsp+0xC0], xmm13
000079f9de5d933d  vmovaps [rsp+0xD0], xmm14
000079f9de5d9346  vmovaps [rsp+0xE0], xmm15
000079f9de5d934f  sub rsp, 0x30
000079f9de5d9353  movaps [rsp], xmm6
000079f9de5d9357  movaps [rsp+0x10], xmm10
000079f9de5d935d  movaps [rsp+0x20], xmm8
000079f9de5d9363  lea rdi, [rsp]
000079f9de5d9367  mov esi, 0x00
000079f9de5d936c  mov rax, 0x56D56FF59530
000079f9de5d9376  call rax
000079f9de5d9378  movaps xmm6, [rsp]
000079f9de5d937c  add rsp, 0x30
000079f9de5d9380  vmovaps xmm0, [rsp]
000079f9de5d9385  vmovaps xmm1, [rsp+0x10]
000079f9de5d938b  vmovaps xmm2, [rsp+0x20]
000079f9de5d9391  vmovaps xmm3, [rsp+0x30]
000079f9de5d9397  vmovaps xmm4, [rsp+0x40]
000079f9de5d939d  vmovaps xmm5, [rsp+0x50]
000079f9de5d93a3  vmovaps xmm7, [rsp+0x60]
000079f9de5d93a9  vmovaps xmm8, [rsp+0x70]
000079f9de5d93af  vmovaps xmm9, [rsp+0x80]
000079f9de5d93b8  vmovaps xmm10, [rsp+0x90]
000079f9de5d93c1  vmovaps xmm11, [rsp+0xA0]
000079f9de5d93ca  vmovaps xmm12, [rsp+0xB0]
000079f9de5d93d3  vmovaps xmm13, [rsp+0xC0]
000079f9de5d93dc  vmovaps xmm14, [rsp+0xD0]
000079f9de5d93e5  vmovaps xmm15, [rsp+0xE0]
000079f9de5d93ee  add rsp, 0xF0
000079f9de5d93f5  pop r11
000079f9de5d93f7  pop r10
000079f9de5d93f9  pop r9
000079f9de5d93fb  pop r8
000079f9de5d93fd  pop rsi
000079f9de5d93fe  pop rdi
000079f9de5d93ff  pop rdx
000079f9de5d9400  pop rcx
000079f9de5d9401  pop rax
000079f9de5d9402  add rsp, 0x08
000079f9de5d9406  jmp 0x000079F9DE5D6225
000079f9de5d940b  sub rsp, 0x08
000079f9de5d940f  push rax
000079f9de5d9410  push rcx
000079f9de5d9411  push rdx
000079f9de5d9412  push rdi
000079f9de5d9413  push rsi
000079f9de5d9414  push r8
000079f9de5d9416  push r9
000079f9de5d9418  push r10
000079f9de5d941a  push r11
000079f9de5d941c  sub rsp, 0xF0
000079f9de5d9423  vmovaps [rsp], xmm0
000079f9de5d9428  vmovaps [rsp+0x10], xmm1
000079f9de5d942e  vmovaps [rsp+0x20], xmm2
000079f9de5d9434  vmovaps [rsp+0x30], xmm3
000079f9de5d943a  vmovaps [rsp+0x40], xmm4
000079f9de5d9440  vmovaps [rsp+0x50], xmm5
000079f9de5d9446  vmovaps [rsp+0x60], xmm6
000079f9de5d944c  vmovaps [rsp+0x70], xmm7
000079f9de5d9452  vmovaps [rsp+0x80], xmm8
000079f9de5d945b  vmovaps [rsp+0x90], xmm9
000079f9de5d9464  vmovaps [rsp+0xA0], xmm11
000079f9de5d946d  vmovaps [rsp+0xB0], xmm12
000079f9de5d9476  vmovaps [rsp+0xC0], xmm13
000079f9de5d947f  vmovaps [rsp+0xD0], xmm14
000079f9de5d9488  vmovaps [rsp+0xE0], xmm15
000079f9de5d9491  sub rsp, 0x30
000079f9de5d9495  movaps [rsp], xmm10
000079f9de5d949a  movaps [rsp+0x10], xmm8
000079f9de5d94a0  movaps [rsp+0x20], xmm14
000079f9de5d94a6  lea rdi, [rsp]
000079f9de5d94aa  mov esi, 0x00
000079f9de5d94af  mov rax, 0x56D56FF59530
000079f9de5d94b9  call rax
000079f9de5d94bb  movaps xmm10, [rsp]
000079f9de5d94c0  add rsp, 0x30
000079f9de5d94c4  vmovaps xmm0, [rsp]
000079f9de5d94c9  vmovaps xmm1, [rsp+0x10]
000079f9de5d94cf  vmovaps xmm2, [rsp+0x20]
000079f9de5d94d5  vmovaps xmm3, [rsp+0x30]
000079f9de5d94db  vmovaps xmm4, [rsp+0x40]
000079f9de5d94e1  vmovaps xmm5, [rsp+0x50]
000079f9de5d94e7  vmovaps xmm6, [rsp+0x60]
000079f9de5d94ed  vmovaps xmm7, [rsp+0x70]
000079f9de5d94f3  vmovaps xmm8, [rsp+0x80]
000079f9de5d94fc  vmovaps xmm9, [rsp+0x90]
000079f9de5d9505  vmovaps xmm11, [rsp+0xA0]
000079f9de5d950e  vmovaps xmm12, [rsp+0xB0]
000079f9de5d9517  vmovaps xmm13, [rsp+0xC0]
000079f9de5d9520  vmovaps xmm14, [rsp+0xD0]
000079f9de5d9529  vmovaps xmm15, [rsp+0xE0]
000079f9de5d9532  add rsp, 0xF0
000079f9de5d9539  pop r11
000079f9de5d953b  pop r10
000079f9de5d953d  pop r9
000079f9de5d953f  pop r8
000079f9de5d9541  pop rsi
000079f9de5d9542  pop rdi
000079f9de5d9543  pop rdx
000079f9de5d9544  pop rcx
000079f9de5d9545  pop rax
000079f9de5d9546  add rsp, 0x08
000079f9de5d954a  jmp 0x000079F9DE5D6245
000079f9de5d954f  sub rsp, 0x08
000079f9de5d9553  push rax
000079f9de5d9554  push rcx
000079f9de5d9555  push rdx
000079f9de5d9556  push rdi
000079f9de5d9557  push rsi
000079f9de5d9558  push r8
000079f9de5d955a  push r9
000079f9de5d955c  push r10
000079f9de5d955e  push r11
000079f9de5d9560  sub rsp, 0xF0
000079f9de5d9567  vmovaps [rsp], xmm0
000079f9de5d956c  vmovaps [rsp+0x10], xmm1
000079f9de5d9572  vmovaps [rsp+0x20], xmm2
000079f9de5d9578  vmovaps [rsp+0x30], xmm3
000079f9de5d957e  vmovaps [rsp+0x40], xmm4
000079f9de5d9584  vmovaps [rsp+0x50], xmm5
000079f9de5d958a  vmovaps [rsp+0x60], xmm6
000079f9de5d9590  vmovaps [rsp+0x70], xmm7
000079f9de5d9596  vmovaps [rsp+0x80], xmm8
000079f9de5d959f  vmovaps [rsp+0x90], xmm9
000079f9de5d95a8  vmovaps [rsp+0xA0], xmm10
000079f9de5d95b1  vmovaps [rsp+0xB0], xmm11
000079f9de5d95ba  vmovaps [rsp+0xC0], xmm12
000079f9de5d95c3  vmovaps [rsp+0xD0], xmm13
000079f9de5d95cc  vmovaps [rsp+0xE0], xmm15
000079f9de5d95d5  sub rsp, 0x30
000079f9de5d95d9  movaps [rsp], xmm14
000079f9de5d95de  movaps [rsp+0x10], xmm8
000079f9de5d95e4  movaps [rsp+0x20], xmm4
000079f9de5d95e9  lea rdi, [rsp]
000079f9de5d95ed  mov esi, 0x00
000079f9de5d95f2  mov rax, 0x56D56FF59530
000079f9de5d95fc  call rax
000079f9de5d95fe  movaps xmm14, [rsp]
000079f9de5d9603  add rsp, 0x30
000079f9de5d9607  vmovaps xmm0, [rsp]
000079f9de5d960c  vmovaps xmm1, [rsp+0x10]
000079f9de5d9612  vmovaps xmm2, [rsp+0x20]
000079f9de5d9618  vmovaps xmm3, [rsp+0x30]
000079f9de5d961e  vmovaps xmm4, [rsp+0x40]
000079f9de5d9624  vmovaps xmm5, [rsp+0x50]
000079f9de5d962a  vmovaps xmm6, [rsp+0x60]
000079f9de5d9630  vmovaps xmm7, [rsp+0x70]
000079f9de5d9636  vmovaps xmm8, [rsp+0x80]
000079f9de5d963f  vmovaps xmm9, [rsp+0x90]
000079f9de5d9648  vmovaps xmm10, [rsp+0xA0]
000079f9de5d9651  vmovaps xmm11, [rsp+0xB0]
000079f9de5d965a  vmovaps xmm12, [rsp+0xC0]
000079f9de5d9663  vmovaps xmm13, [rsp+0xD0]
000079f9de5d966c  vmovaps xmm15, [rsp+0xE0]
000079f9de5d9675  add rsp, 0xF0
000079f9de5d967c  pop r11
000079f9de5d967e  pop r10
000079f9de5d9680  pop r9
000079f9de5d9682  pop r8
000079f9de5d9684  pop rsi
000079f9de5d9685  pop rdi
000079f9de5d9686  pop rdx
000079f9de5d9687  pop rcx
000079f9de5d9688  pop rax
000079f9de5d9689  add rsp, 0x08
000079f9de5d968d  jmp 0x000079F9DE5D6265
000079f9de5d9692  sub rsp, 0x08
000079f9de5d9696  push rax
000079f9de5d9697  push rcx
000079f9de5d9698  push rdx
000079f9de5d9699  push rdi
000079f9de5d969a  push rsi
000079f9de5d969b  push r8
000079f9de5d969d  push r9
000079f9de5d969f  push r10
000079f9de5d96a1  push r11
000079f9de5d96a3  sub rsp, 0xF0
000079f9de5d96aa  vmovaps [rsp], xmm0
000079f9de5d96af  vmovaps [rsp+0x10], xmm1
000079f9de5d96b5  vmovaps [rsp+0x20], xmm2
000079f9de5d96bb  vmovaps [rsp+0x30], xmm3
000079f9de5d96c1  vmovaps [rsp+0x40], xmm5
000079f9de5d96c7  vmovaps [rsp+0x50], xmm6
000079f9de5d96cd  vmovaps [rsp+0x60], xmm7
000079f9de5d96d3  vmovaps [rsp+0x70], xmm8
000079f9de5d96d9  vmovaps [rsp+0x80], xmm9
000079f9de5d96e2  vmovaps [rsp+0x90], xmm10
000079f9de5d96eb  vmovaps [rsp+0xA0], xmm11
000079f9de5d96f4  vmovaps [rsp+0xB0], xmm12
000079f9de5d96fd  vmovaps [rsp+0xC0], xmm13
000079f9de5d9706  vmovaps [rsp+0xD0], xmm14
000079f9de5d970f  vmovaps [rsp+0xE0], xmm15
000079f9de5d9718  sub rsp, 0x30
000079f9de5d971c  movaps [rsp], xmm4
000079f9de5d9720  movaps [rsp+0x10], xmm13
000079f9de5d9726  movaps [rsp+0x20], xmm8
000079f9de5d972c  lea rdi, [rsp]
000079f9de5d9730  mov esi, 0x00
000079f9de5d9735  mov rax, 0x56D56FF59530
000079f9de5d973f  call rax
000079f9de5d9741  movaps xmm4, [rsp]
000079f9de5d9745  add rsp, 0x30
000079f9de5d9749  vmovaps xmm0, [rsp]
000079f9de5d974e  vmovaps xmm1, [rsp+0x10]
000079f9de5d9754  vmovaps xmm2, [rsp+0x20]
000079f9de5d975a  vmovaps xmm3, [rsp+0x30]
000079f9de5d9760  vmovaps xmm5, [rsp+0x40]
000079f9de5d9766  vmovaps xmm6, [rsp+0x50]
000079f9de5d976c  vmovaps xmm7, [rsp+0x60]
000079f9de5d9772  vmovaps xmm8, [rsp+0x70]
000079f9de5d9778  vmovaps xmm9, [rsp+0x80]
000079f9de5d9781  vmovaps xmm10, [rsp+0x90]
000079f9de5d978a  vmovaps xmm11, [rsp+0xA0]
000079f9de5d9793  vmovaps xmm12, [rsp+0xB0]
000079f9de5d979c  vmovaps xmm13, [rsp+0xC0]
000079f9de5d97a5  vmovaps xmm14, [rsp+0xD0]
000079f9de5d97ae  vmovaps xmm15, [rsp+0xE0]
000079f9de5d97b7  add rsp, 0xF0
000079f9de5d97be  pop r11
000079f9de5d97c0  pop r10
000079f9de5d97c2  pop r9
000079f9de5d97c4  pop r8
000079f9de5d97c6  pop rsi
000079f9de5d97c7  pop rdi
000079f9de5d97c8  pop rdx
000079f9de5d97c9  pop rcx
000079f9de5d97ca  pop rax
000079f9de5d97cb  add rsp, 0x08
000079f9de5d97cf  jmp 0x000079F9DE5D628A
000079f9de5d97d4  sub rsp, 0x08
000079f9de5d97d8  push rax
000079f9de5d97d9  push rcx
000079f9de5d97da  push rdx
000079f9de5d97db  push rdi
000079f9de5d97dc  push rsi
000079f9de5d97dd  push r8
000079f9de5d97df  push r9
000079f9de5d97e1  push r10
000079f9de5d97e3  push r11
000079f9de5d97e5  sub rsp, 0xF0
000079f9de5d97ec  vmovaps [rsp], xmm0
000079f9de5d97f1  vmovaps [rsp+0x10], xmm1
000079f9de5d97f7  vmovaps [rsp+0x20], xmm2
000079f9de5d97fd  vmovaps [rsp+0x30], xmm3
000079f9de5d9803  vmovaps [rsp+0x40], xmm4
000079f9de5d9809  vmovaps [rsp+0x50], xmm5
000079f9de5d980f  vmovaps [rsp+0x60], xmm6
000079f9de5d9815  vmovaps [rsp+0x70], xmm7
000079f9de5d981b  vmovaps [rsp+0x80], xmm8
000079f9de5d9824  vmovaps [rsp+0x90], xmm9
000079f9de5d982d  vmovaps [rsp+0xA0], xmm10
000079f9de5d9836  vmovaps [rsp+0xB0], xmm11
000079f9de5d983f  vmovaps [rsp+0xC0], xmm12
000079f9de5d9848  vmovaps [rsp+0xD0], xmm14
000079f9de5d9851  vmovaps [rsp+0xE0], xmm15
000079f9de5d985a  sub rsp, 0x30
000079f9de5d985e  movaps [rsp], xmm13
000079f9de5d9863  movaps [rsp+0x10], xmm15
000079f9de5d9869  movaps [rsp+0x20], xmm9
000079f9de5d986f  lea rdi, [rsp]
000079f9de5d9873  mov esi, 0x00
000079f9de5d9878  mov rax, 0x56D56FF59530
000079f9de5d9882  call rax
000079f9de5d9884  movaps xmm13, [rsp]
000079f9de5d9889  add rsp, 0x30
000079f9de5d988d  vmovaps xmm0, [rsp]
000079f9de5d9892  vmovaps xmm1, [rsp+0x10]
000079f9de5d9898  vmovaps xmm2, [rsp+0x20]
000079f9de5d989e  vmovaps xmm3, [rsp+0x30]
000079f9de5d98a4  vmovaps xmm4, [rsp+0x40]
000079f9de5d98aa  vmovaps xmm5, [rsp+0x50]
000079f9de5d98b0  vmovaps xmm6, [rsp+0x60]
000079f9de5d98b6  vmovaps xmm7, [rsp+0x70]
000079f9de5d98bc  vmovaps xmm8, [rsp+0x80]
000079f9de5d98c5  vmovaps xmm9, [rsp+0x90]
000079f9de5d98ce  vmovaps xmm10, [rsp+0xA0]
000079f9de5d98d7  vmovaps xmm11, [rsp+0xB0]
000079f9de5d98e0  vmovaps xmm12, [rsp+0xC0]
000079f9de5d98e9  vmovaps xmm14, [rsp+0xD0]
000079f9de5d98f2  vmovaps xmm15, [rsp+0xE0]
000079f9de5d98fb  add rsp, 0xF0
000079f9de5d9902  pop r11
000079f9de5d9904  pop r10
000079f9de5d9906  pop r9
000079f9de5d9908  pop r8
000079f9de5d990a  pop rsi
000079f9de5d990b  pop rdi
000079f9de5d990c  pop rdx
000079f9de5d990d  pop rcx
000079f9de5d990e  pop rax
000079f9de5d990f  add rsp, 0x08
000079f9de5d9913  jmp 0x000079F9DE5D62A5
000079f9de5d9918  sub rsp, 0x08
000079f9de5d991c  push rax
000079f9de5d991d  push rcx
000079f9de5d991e  push rdx
000079f9de5d991f  push rdi
000079f9de5d9920  push rsi
000079f9de5d9921  push r8
000079f9de5d9923  push r9
000079f9de5d9925  push r10
000079f9de5d9927  push r11
000079f9de5d9929  sub rsp, 0xF0
000079f9de5d9930  vmovaps [rsp], xmm0
000079f9de5d9935  vmovaps [rsp+0x10], xmm1
000079f9de5d993b  vmovaps [rsp+0x20], xmm2
000079f9de5d9941  vmovaps [rsp+0x30], xmm3
000079f9de5d9947  vmovaps [rsp+0x40], xmm4
000079f9de5d994d  vmovaps [rsp+0x50], xmm5
000079f9de5d9953  vmovaps [rsp+0x60], xmm6
000079f9de5d9959  vmovaps [rsp+0x70], xmm7
000079f9de5d995f  vmovaps [rsp+0x80], xmm8
000079f9de5d9968  vmovaps [rsp+0x90], xmm9
000079f9de5d9971  vmovaps [rsp+0xA0], xmm10
000079f9de5d997a  vmovaps [rsp+0xB0], xmm11
000079f9de5d9983  vmovaps [rsp+0xC0], xmm12
000079f9de5d998c  vmovaps [rsp+0xD0], xmm13
000079f9de5d9995  vmovaps [rsp+0xE0], xmm14
000079f9de5d999e  sub rsp, 0x30
000079f9de5d99a2  movaps [rsp], xmm15
000079f9de5d99a7  movaps [rsp+0x10], xmm1
000079f9de5d99ac  movaps [rsp+0x20], xmm5
000079f9de5d99b1  lea rdi, [rsp]
000079f9de5d99b5  mov esi, 0x00
000079f9de5d99ba  mov rax, 0x56D56FF59530
000079f9de5d99c4  call rax
000079f9de5d99c6  movaps xmm15, [rsp]
000079f9de5d99cb  add rsp, 0x30
000079f9de5d99cf  vmovaps xmm0, [rsp]
000079f9de5d99d4  vmovaps xmm1, [rsp+0x10]
000079f9de5d99da  vmovaps xmm2, [rsp+0x20]
000079f9de5d99e0  vmovaps xmm3, [rsp+0x30]
000079f9de5d99e6  vmovaps xmm4, [rsp+0x40]
000079f9de5d99ec  vmovaps xmm5, [rsp+0x50]
000079f9de5d99f2  vmovaps xmm6, [rsp+0x60]
000079f9de5d99f8  vmovaps xmm7, [rsp+0x70]
000079f9de5d99fe  vmovaps xmm8, [rsp+0x80]
000079f9de5d9a07  vmovaps xmm9, [rsp+0x90]
000079f9de5d9a10  vmovaps xmm10, [rsp+0xA0]
000079f9de5d9a19  vmovaps xmm11, [rsp+0xB0]
000079f9de5d9a22  vmovaps xmm12, [rsp+0xC0]
000079f9de5d9a2b  vmovaps xmm13, [rsp+0xD0]
000079f9de5d9a34  vmovaps xmm14, [rsp+0xE0]
000079f9de5d9a3d  add rsp, 0xF0
000079f9de5d9a44  pop r11
000079f9de5d9a46  pop r10
000079f9de5d9a48  pop r9
000079f9de5d9a4a  pop r8
000079f9de5d9a4c  pop rsi
000079f9de5d9a4d  pop rdi
000079f9de5d9a4e  pop rdx
000079f9de5d9a4f  pop rcx
000079f9de5d9a50  pop rax
000079f9de5d9a51  add rsp, 0x08
000079f9de5d9a55  jmp 0x000079F9DE5D62C0
000079f9de5d9a5a  call 0x000079F9DE4D64F0
000079f9de5d9a5f  jmp 0x000079F9DE5D631B
000079f9de5d9a64  sub rsp, 0x08
000079f9de5d9a68  push rax
000079f9de5d9a69  push rcx
000079f9de5d9a6a  push rdx
000079f9de5d9a6b  push rdi
000079f9de5d9a6c  push rsi
000079f9de5d9a6d  push r8
000079f9de5d9a6f  push r9
000079f9de5d9a71  push r10
000079f9de5d9a73  push r11
000079f9de5d9a75  sub rsp, 0xF0
000079f9de5d9a7c  vmovaps [rsp], xmm0
000079f9de5d9a81  vmovaps [rsp+0x10], xmm1
000079f9de5d9a87  vmovaps [rsp+0x20], xmm2
000079f9de5d9a8d  vmovaps [rsp+0x30], xmm3
000079f9de5d9a93  vmovaps [rsp+0x40], xmm4
000079f9de5d9a99  vmovaps [rsp+0x50], xmm5
000079f9de5d9a9f  vmovaps [rsp+0x60], xmm6
000079f9de5d9aa5  vmovaps [rsp+0x70], xmm7
000079f9de5d9aab  vmovaps [rsp+0x80], xmm8
000079f9de5d9ab4  vmovaps [rsp+0x90], xmm10
000079f9de5d9abd  vmovaps [rsp+0xA0], xmm11
000079f9de5d9ac6  vmovaps [rsp+0xB0], xmm12
000079f9de5d9acf  vmovaps [rsp+0xC0], xmm13
000079f9de5d9ad8  vmovaps [rsp+0xD0], xmm14
000079f9de5d9ae1  vmovaps [rsp+0xE0], xmm15
000079f9de5d9aea  sub rsp, 0x30
000079f9de5d9aee  movaps [rsp], xmm9
000079f9de5d9af3  movaps [rsp+0x10], xmm8
000079f9de5d9af9  movaps [rsp+0x20], xmm11
000079f9de5d9aff  lea rdi, [rsp]
000079f9de5d9b03  mov esi, 0x00
000079f9de5d9b08  mov rax, 0x56D56FF59530
000079f9de5d9b12  call rax
000079f9de5d9b14  movaps xmm9, [rsp]
000079f9de5d9b19  add rsp, 0x30
000079f9de5d9b1d  vmovaps xmm0, [rsp]
000079f9de5d9b22  vmovaps xmm1, [rsp+0x10]
000079f9de5d9b28  vmovaps xmm2, [rsp+0x20]
000079f9de5d9b2e  vmovaps xmm3, [rsp+0x30]
000079f9de5d9b34  vmovaps xmm4, [rsp+0x40]
000079f9de5d9b3a  vmovaps xmm5, [rsp+0x50]
000079f9de5d9b40  vmovaps xmm6, [rsp+0x60]
000079f9de5d9b46  vmovaps xmm7, [rsp+0x70]
000079f9de5d9b4c  vmovaps xmm8, [rsp+0x80]
000079f9de5d9b55  vmovaps xmm10, [rsp+0x90]
000079f9de5d9b5e  vmovaps xmm11, [rsp+0xA0]
000079f9de5d9b67  vmovaps xmm12, [rsp+0xB0]
000079f9de5d9b70  vmovaps xmm13, [rsp+0xC0]
000079f9de5d9b79  vmovaps xmm14, [rsp+0xD0]
000079f9de5d9b82  vmovaps xmm15, [rsp+0xE0]
000079f9de5d9b8b  add rsp, 0xF0
000079f9de5d9b92  pop r11
000079f9de5d9b94  pop r10
000079f9de5d9b96  pop r9
000079f9de5d9b98  pop r8
000079f9de5d9b9a  pop rsi
000079f9de5d9b9b  pop rdi
000079f9de5d9b9c  pop rdx
000079f9de5d9b9d  pop rcx
000079f9de5d9b9e  pop rax
000079f9de5d9b9f  add rsp, 0x08
000079f9de5d9ba3  jmp 0x000079F9DE5D6352
000079f9de5d9ba8  sub rsp, 0x08
000079f9de5d9bac  push rax
000079f9de5d9bad  push rcx
000079f9de5d9bae  push rdx
000079f9de5d9baf  push rdi
000079f9de5d9bb0  push rsi
000079f9de5d9bb1  push r8
000079f9de5d9bb3  push r9
000079f9de5d9bb5  push r10
000079f9de5d9bb7  push r11
000079f9de5d9bb9  sub rsp, 0xF0
000079f9de5d9bc0  vmovaps [rsp], xmm0
000079f9de5d9bc5  vmovaps [rsp+0x10], xmm1
000079f9de5d9bcb  vmovaps [rsp+0x20], xmm2
000079f9de5d9bd1  vmovaps [rsp+0x30], xmm3
000079f9de5d9bd7  vmovaps [rsp+0x40], xmm4
000079f9de5d9bdd  vmovaps [rsp+0x50], xmm5
000079f9de5d9be3  vmovaps [rsp+0x60], xmm6
000079f9de5d9be9  vmovaps [rsp+0x70], xmm7
000079f9de5d9bef  vmovaps [rsp+0x80], xmm8
000079f9de5d9bf8  vmovaps [rsp+0x90], xmm9
000079f9de5d9c01  vmovaps [rsp+0xA0], xmm10
000079f9de5d9c0a  vmovaps [rsp+0xB0], xmm12
000079f9de5d9c13  vmovaps [rsp+0xC0], xmm13
000079f9de5d9c1c  vmovaps [rsp+0xD0], xmm14
000079f9de5d9c25  vmovaps [rsp+0xE0], xmm15
000079f9de5d9c2e  sub rsp, 0x30
000079f9de5d9c32  movaps [rsp], xmm11
000079f9de5d9c37  movaps [rsp+0x10], xmm10
000079f9de5d9c3d  movaps [rsp+0x20], xmm6
000079f9de5d9c42  lea rdi, [rsp]
000079f9de5d9c46  mov esi, 0x00
000079f9de5d9c4b  mov rax, 0x56D56FF59530
000079f9de5d9c55  call rax
000079f9de5d9c57  movaps xmm11, [rsp]
000079f9de5d9c5c  add rsp, 0x30
000079f9de5d9c60  vmovaps xmm0, [rsp]
000079f9de5d9c65  vmovaps xmm1, [rsp+0x10]
000079f9de5d9c6b  vmovaps xmm2, [rsp+0x20]
000079f9de5d9c71  vmovaps xmm3, [rsp+0x30]
000079f9de5d9c77  vmovaps xmm4, [rsp+0x40]
000079f9de5d9c7d  vmovaps xmm5, [rsp+0x50]
000079f9de5d9c83  vmovaps xmm6, [rsp+0x60]
000079f9de5d9c89  vmovaps xmm7, [rsp+0x70]
000079f9de5d9c8f  vmovaps xmm8, [rsp+0x80]
000079f9de5d9c98  vmovaps xmm9, [rsp+0x90]
000079f9de5d9ca1  vmovaps xmm10, [rsp+0xA0]
000079f9de5d9caa  vmovaps xmm12, [rsp+0xB0]
000079f9de5d9cb3  vmovaps xmm13, [rsp+0xC0]
000079f9de5d9cbc  vmovaps xmm14, [rsp+0xD0]
000079f9de5d9cc5  vmovaps xmm15, [rsp+0xE0]
000079f9de5d9cce  add rsp, 0xF0
000079f9de5d9cd5  pop r11
000079f9de5d9cd7  pop r10
000079f9de5d9cd9  pop r9
000079f9de5d9cdb  pop r8
000079f9de5d9cdd  pop rsi
000079f9de5d9cde  pop rdi
000079f9de5d9cdf  pop rdx
000079f9de5d9ce0  pop rcx
000079f9de5d9ce1  pop rax
000079f9de5d9ce2  add rsp, 0x08
000079f9de5d9ce6  jmp 0x000079F9DE5D636D
000079f9de5d9ceb  sub rsp, 0x08
000079f9de5d9cef  push rax
000079f9de5d9cf0  push rcx
000079f9de5d9cf1  push rdx
000079f9de5d9cf2  push rdi
000079f9de5d9cf3  push rsi
000079f9de5d9cf4  push r8
000079f9de5d9cf6  push r9
000079f9de5d9cf8  push r10
000079f9de5d9cfa  push r11
000079f9de5d9cfc  sub rsp, 0xF0
000079f9de5d9d03  vmovaps [rsp], xmm0
000079f9de5d9d08  vmovaps [rsp+0x10], xmm1
000079f9de5d9d0e  vmovaps [rsp+0x20], xmm2
000079f9de5d9d14  vmovaps [rsp+0x30], xmm3
000079f9de5d9d1a  vmovaps [rsp+0x40], xmm4
000079f9de5d9d20  vmovaps [rsp+0x50], xmm5
000079f9de5d9d26  vmovaps [rsp+0x60], xmm6
000079f9de5d9d2c  vmovaps [rsp+0x70], xmm7
000079f9de5d9d32  vmovaps [rsp+0x80], xmm8
000079f9de5d9d3b  vmovaps [rsp+0x90], xmm9
000079f9de5d9d44  vmovaps [rsp+0xA0], xmm11
000079f9de5d9d4d  vmovaps [rsp+0xB0], xmm12
000079f9de5d9d56  vmovaps [rsp+0xC0], xmm13
000079f9de5d9d5f  vmovaps [rsp+0xD0], xmm14
000079f9de5d9d68  vmovaps [rsp+0xE0], xmm15
000079f9de5d9d71  sub rsp, 0x30
000079f9de5d9d75  movaps [rsp], xmm10
000079f9de5d9d7a  movaps [rsp+0x10], xmm14
000079f9de5d9d80  movaps [rsp+0x20], xmm4
000079f9de5d9d85  lea rdi, [rsp]
000079f9de5d9d89  mov esi, 0x00
000079f9de5d9d8e  mov rax, 0x56D56FF59530
000079f9de5d9d98  call rax
000079f9de5d9d9a  movaps xmm10, [rsp]
000079f9de5d9d9f  add rsp, 0x30
000079f9de5d9da3  vmovaps xmm0, [rsp]
000079f9de5d9da8  vmovaps xmm1, [rsp+0x10]
000079f9de5d9dae  vmovaps xmm2, [rsp+0x20]
000079f9de5d9db4  vmovaps xmm3, [rsp+0x30]
000079f9de5d9dba  vmovaps xmm4, [rsp+0x40]
000079f9de5d9dc0  vmovaps xmm5, [rsp+0x50]
000079f9de5d9dc6  vmovaps xmm6, [rsp+0x60]
000079f9de5d9dcc  vmovaps xmm7, [rsp+0x70]
000079f9de5d9dd2  vmovaps xmm8, [rsp+0x80]
000079f9de5d9ddb  vmovaps xmm9, [rsp+0x90]
000079f9de5d9de4  vmovaps xmm11, [rsp+0xA0]
000079f9de5d9ded  vmovaps xmm12, [rsp+0xB0]
000079f9de5d9df6  vmovaps xmm13, [rsp+0xC0]
000079f9de5d9dff  vmovaps xmm14, [rsp+0xD0]
000079f9de5d9e08  vmovaps xmm15, [rsp+0xE0]
000079f9de5d9e11  add rsp, 0xF0
000079f9de5d9e18  pop r11
000079f9de5d9e1a  pop r10
000079f9de5d9e1c  pop r9
000079f9de5d9e1e  pop r8
000079f9de5d9e20  pop rsi
000079f9de5d9e21  pop rdi
000079f9de5d9e22  pop rdx
000079f9de5d9e23  pop rcx
000079f9de5d9e24  pop rax
000079f9de5d9e25  add rsp, 0x08
000079f9de5d9e29  jmp 0x000079F9DE5D6388
000079f9de5d9e2e  sub rsp, 0x08
000079f9de5d9e32  push rax
000079f9de5d9e33  push rcx
000079f9de5d9e34  push rdx
000079f9de5d9e35  push rdi
000079f9de5d9e36  push rsi
000079f9de5d9e37  push r8
000079f9de5d9e39  push r9
000079f9de5d9e3b  push r10
000079f9de5d9e3d  push r11
000079f9de5d9e3f  sub rsp, 0xF0
000079f9de5d9e46  vmovaps [rsp], xmm0
000079f9de5d9e4b  vmovaps [rsp+0x10], xmm1
000079f9de5d9e51  vmovaps [rsp+0x20], xmm2
000079f9de5d9e57  vmovaps [rsp+0x30], xmm3
000079f9de5d9e5d  vmovaps [rsp+0x40], xmm4
000079f9de5d9e63  vmovaps [rsp+0x50], xmm5
000079f9de5d9e69  vmovaps [rsp+0x60], xmm6
000079f9de5d9e6f  vmovaps [rsp+0x70], xmm7
000079f9de5d9e75  vmovaps [rsp+0x80], xmm9
000079f9de5d9e7e  vmovaps [rsp+0x90], xmm10
000079f9de5d9e87  vmovaps [rsp+0xA0], xmm11
000079f9de5d9e90  vmovaps [rsp+0xB0], xmm12
000079f9de5d9e99  vmovaps [rsp+0xC0], xmm13
000079f9de5d9ea2  vmovaps [rsp+0xD0], xmm14
000079f9de5d9eab  vmovaps [rsp+0xE0], xmm15
000079f9de5d9eb4  sub rsp, 0x30
000079f9de5d9eb8  movaps [rsp], xmm8
000079f9de5d9ebd  movaps [rsp+0x10], xmm1
000079f9de5d9ec2  movaps [rsp+0x20], xmm14
000079f9de5d9ec8  lea rdi, [rsp]
000079f9de5d9ecc  mov esi, 0x00
000079f9de5d9ed1  mov rax, 0x56D56FF59530
000079f9de5d9edb  call rax
000079f9de5d9edd  movaps xmm8, [rsp]
000079f9de5d9ee2  add rsp, 0x30
000079f9de5d9ee6  vmovaps xmm0, [rsp]
000079f9de5d9eeb  vmovaps xmm1, [rsp+0x10]
000079f9de5d9ef1  vmovaps xmm2, [rsp+0x20]
000079f9de5d9ef7  vmovaps xmm3, [rsp+0x30]
000079f9de5d9efd  vmovaps xmm4, [rsp+0x40]
000079f9de5d9f03  vmovaps xmm5, [rsp+0x50]
000079f9de5d9f09  vmovaps xmm6, [rsp+0x60]
000079f9de5d9f0f  vmovaps xmm7, [rsp+0x70]
000079f9de5d9f15  vmovaps xmm9, [rsp+0x80]
000079f9de5d9f1e  vmovaps xmm10, [rsp+0x90]
000079f9de5d9f27  vmovaps xmm11, [rsp+0xA0]
000079f9de5d9f30  vmovaps xmm12, [rsp+0xB0]
000079f9de5d9f39  vmovaps xmm13, [rsp+0xC0]
000079f9de5d9f42  vmovaps xmm14, [rsp+0xD0]
000079f9de5d9f4b  vmovaps xmm15, [rsp+0xE0]
000079f9de5d9f54  add rsp, 0xF0
000079f9de5d9f5b  pop r11
000079f9de5d9f5d  pop r10
000079f9de5d9f5f  pop r9
000079f9de5d9f61  pop r8
000079f9de5d9f63  pop rsi
000079f9de5d9f64  pop rdi
000079f9de5d9f65  pop rdx
000079f9de5d9f66  pop rcx
000079f9de5d9f67  pop rax
000079f9de5d9f68  add rsp, 0x08
000079f9de5d9f6c  jmp 0x000079F9DE5D63AE
000079f9de5d9f71  sub rsp, 0x08
000079f9de5d9f75  push rax
000079f9de5d9f76  push rcx
000079f9de5d9f77  push rdx
000079f9de5d9f78  push rdi
000079f9de5d9f79  push rsi
000079f9de5d9f7a  push r8
000079f9de5d9f7c  push r9
000079f9de5d9f7e  push r10
000079f9de5d9f80  push r11
000079f9de5d9f82  sub rsp, 0xF0
000079f9de5d9f89  vmovaps [rsp], xmm0
000079f9de5d9f8e  vmovaps [rsp+0x10], xmm1
000079f9de5d9f94  vmovaps [rsp+0x20], xmm2
000079f9de5d9f9a  vmovaps [rsp+0x30], xmm3
000079f9de5d9fa0  vmovaps [rsp+0x40], xmm4
000079f9de5d9fa6  vmovaps [rsp+0x50], xmm5
000079f9de5d9fac  vmovaps [rsp+0x60], xmm7
000079f9de5d9fb2  vmovaps [rsp+0x70], xmm8
000079f9de5d9fb8  vmovaps [rsp+0x80], xmm9
000079f9de5d9fc1  vmovaps [rsp+0x90], xmm10
000079f9de5d9fca  vmovaps [rsp+0xA0], xmm11
000079f9de5d9fd3  vmovaps [rsp+0xB0], xmm12
000079f9de5d9fdc  vmovaps [rsp+0xC0], xmm13
000079f9de5d9fe5  vmovaps [rsp+0xD0], xmm14
000079f9de5d9fee  vmovaps [rsp+0xE0], xmm15
000079f9de5d9ff7  sub rsp, 0x30
000079f9de5d9ffb  movaps [rsp], xmm6
000079f9de5d9fff  movaps [rsp+0x10], xmm1
000079f9de5da004  movaps [rsp+0x20], xmm14
000079f9de5da00a  lea rdi, [rsp]
000079f9de5da00e  mov esi, 0x00
000079f9de5da013  mov rax, 0x56D56FF59530
000079f9de5da01d  call rax
000079f9de5da01f  movaps xmm6, [rsp]
000079f9de5da023  add rsp, 0x30
000079f9de5da027  vmovaps xmm0, [rsp]
000079f9de5da02c  vmovaps xmm1, [rsp+0x10]
000079f9de5da032  vmovaps xmm2, [rsp+0x20]
000079f9de5da038  vmovaps xmm3, [rsp+0x30]
000079f9de5da03e  vmovaps xmm4, [rsp+0x40]
000079f9de5da044  vmovaps xmm5, [rsp+0x50]
000079f9de5da04a  vmovaps xmm7, [rsp+0x60]
000079f9de5da050  vmovaps xmm8, [rsp+0x70]
000079f9de5da056  vmovaps xmm9, [rsp+0x80]
000079f9de5da05f  vmovaps xmm10, [rsp+0x90]
000079f9de5da068  vmovaps xmm11, [rsp+0xA0]
000079f9de5da071  vmovaps xmm12, [rsp+0xB0]
000079f9de5da07a  vmovaps xmm13, [rsp+0xC0]
000079f9de5da083  vmovaps xmm14, [rsp+0xD0]
000079f9de5da08c  vmovaps xmm15, [rsp+0xE0]
000079f9de5da095  add rsp, 0xF0
000079f9de5da09c  pop r11
000079f9de5da09e  pop r10
000079f9de5da0a0  pop r9
000079f9de5da0a2  pop r8
000079f9de5da0a4  pop rsi
000079f9de5da0a5  pop rdi
000079f9de5da0a6  pop rdx
000079f9de5da0a7  pop rcx
000079f9de5da0a8  pop rax
000079f9de5da0a9  add rsp, 0x08
000079f9de5da0ad  jmp 0x000079F9DE5D63DA
000079f9de5da0b2  sub rsp, 0x08
000079f9de5da0b6  push rax
000079f9de5da0b7  push rcx
000079f9de5da0b8  push rdx
000079f9de5da0b9  push rdi
000079f9de5da0ba  push rsi
000079f9de5da0bb  push r8
000079f9de5da0bd  push r9
000079f9de5da0bf  push r10
000079f9de5da0c1  push r11
000079f9de5da0c3  sub rsp, 0xF0
000079f9de5da0ca  vmovaps [rsp], xmm0
000079f9de5da0cf  vmovaps [rsp+0x10], xmm1
000079f9de5da0d5  vmovaps [rsp+0x20], xmm2
000079f9de5da0db  vmovaps [rsp+0x30], xmm3
000079f9de5da0e1  vmovaps [rsp+0x40], xmm4
000079f9de5da0e7  vmovaps [rsp+0x50], xmm5
000079f9de5da0ed  vmovaps [rsp+0x60], xmm6
000079f9de5da0f3  vmovaps [rsp+0x70], xmm7
000079f9de5da0f9  vmovaps [rsp+0x80], xmm8
000079f9de5da102  vmovaps [rsp+0x90], xmm9
000079f9de5da10b  vmovaps [rsp+0xA0], xmm10
000079f9de5da114  vmovaps [rsp+0xB0], xmm11
000079f9de5da11d  vmovaps [rsp+0xC0], xmm12
000079f9de5da126  vmovaps [rsp+0xD0], xmm13
000079f9de5da12f  vmovaps [rsp+0xE0], xmm15
000079f9de5da138  sub rsp, 0x30
000079f9de5da13c  movaps [rsp], xmm14
000079f9de5da141  movaps [rsp+0x10], xmm12
000079f9de5da147  movaps [rsp+0x20], xmm1
000079f9de5da14c  lea rdi, [rsp]
000079f9de5da150  mov esi, 0x00
000079f9de5da155  mov rax, 0x56D56FF59530
000079f9de5da15f  call rax
000079f9de5da161  movaps xmm14, [rsp]
000079f9de5da166  add rsp, 0x30
000079f9de5da16a  vmovaps xmm0, [rsp]
000079f9de5da16f  vmovaps xmm1, [rsp+0x10]
000079f9de5da175  vmovaps xmm2, [rsp+0x20]
000079f9de5da17b  vmovaps xmm3, [rsp+0x30]
000079f9de5da181  vmovaps xmm4, [rsp+0x40]
000079f9de5da187  vmovaps xmm5, [rsp+0x50]
000079f9de5da18d  vmovaps xmm6, [rsp+0x60]
000079f9de5da193  vmovaps xmm7, [rsp+0x70]
000079f9de5da199  vmovaps xmm8, [rsp+0x80]
000079f9de5da1a2  vmovaps xmm9, [rsp+0x90]
000079f9de5da1ab  vmovaps xmm10, [rsp+0xA0]
000079f9de5da1b4  vmovaps xmm11, [rsp+0xB0]
000079f9de5da1bd  vmovaps xmm12, [rsp+0xC0]
000079f9de5da1c6  vmovaps xmm13, [rsp+0xD0]
000079f9de5da1cf  vmovaps xmm15, [rsp+0xE0]
000079f9de5da1d8  add rsp, 0xF0
000079f9de5da1df  pop r11
000079f9de5da1e1  pop r10
000079f9de5da1e3  pop r9
000079f9de5da1e5  pop r8
000079f9de5da1e7  pop rsi
000079f9de5da1e8  pop rdi
000079f9de5da1e9  pop rdx
000079f9de5da1ea  pop rcx
000079f9de5da1eb  pop rax
000079f9de5da1ec  add rsp, 0x08
000079f9de5da1f0  jmp 0x000079F9DE5D6400
000079f9de5da1f5  sub rsp, 0x08
000079f9de5da1f9  push rax
000079f9de5da1fa  push rcx
000079f9de5da1fb  push rdx
000079f9de5da1fc  push rdi
000079f9de5da1fd  push rsi
000079f9de5da1fe  push r8
000079f9de5da200  push r9
000079f9de5da202  push r10
000079f9de5da204  push r11
000079f9de5da206  sub rsp, 0xF0
000079f9de5da20d  vmovaps [rsp], xmm0
000079f9de5da212  vmovaps [rsp+0x10], xmm2
000079f9de5da218  vmovaps [rsp+0x20], xmm3
000079f9de5da21e  vmovaps [rsp+0x30], xmm4
000079f9de5da224  vmovaps [rsp+0x40], xmm5
000079f9de5da22a  vmovaps [rsp+0x50], xmm6
000079f9de5da230  vmovaps [rsp+0x60], xmm7
000079f9de5da236  vmovaps [rsp+0x70], xmm8
000079f9de5da23c  vmovaps [rsp+0x80], xmm9
000079f9de5da245  vmovaps [rsp+0x90], xmm10
000079f9de5da24e  vmovaps [rsp+0xA0], xmm11
000079f9de5da257  vmovaps [rsp+0xB0], xmm12
000079f9de5da260  vmovaps [rsp+0xC0], xmm13
000079f9de5da269  vmovaps [rsp+0xD0], xmm14
000079f9de5da272  vmovaps [rsp+0xE0], xmm15
000079f9de5da27b  sub rsp, 0x30
000079f9de5da27f  movaps [rsp], xmm1
000079f9de5da283  movaps [rsp+0x10], xmm13
000079f9de5da289  movaps [rsp+0x20], xmm9
000079f9de5da28f  lea rdi, [rsp]
000079f9de5da293  mov esi, 0x00
000079f9de5da298  mov rax, 0x56D56FF59530
000079f9de5da2a2  call rax
000079f9de5da2a4  movaps xmm1, [rsp]
000079f9de5da2a8  add rsp, 0x30
000079f9de5da2ac  vmovaps xmm0, [rsp]
000079f9de5da2b1  vmovaps xmm2, [rsp+0x10]
000079f9de5da2b7  vmovaps xmm3, [rsp+0x20]
000079f9de5da2bd  vmovaps xmm4, [rsp+0x30]
000079f9de5da2c3  vmovaps xmm5, [rsp+0x40]
000079f9de5da2c9  vmovaps xmm6, [rsp+0x50]
000079f9de5da2cf  vmovaps xmm7, [rsp+0x60]
000079f9de5da2d5  vmovaps xmm8, [rsp+0x70]
000079f9de5da2db  vmovaps xmm9, [rsp+0x80]
000079f9de5da2e4  vmovaps xmm10, [rsp+0x90]
000079f9de5da2ed  vmovaps xmm11, [rsp+0xA0]
000079f9de5da2f6  vmovaps xmm12, [rsp+0xB0]
000079f9de5da2ff  vmovaps xmm13, [rsp+0xC0]
000079f9de5da308  vmovaps xmm14, [rsp+0xD0]
000079f9de5da311  vmovaps xmm15, [rsp+0xE0]
000079f9de5da31a  add rsp, 0xF0
000079f9de5da321  pop r11
000079f9de5da323  pop r10
000079f9de5da325  pop r9
000079f9de5da327  pop r8
000079f9de5da329  pop rsi
000079f9de5da32a  pop rdi
000079f9de5da32b  pop rdx
000079f9de5da32c  pop rcx
000079f9de5da32d  pop rax
000079f9de5da32e  add rsp, 0x08
000079f9de5da332  jmp 0x000079F9DE5D641A
000079f9de5da337  sub rsp, 0x08
000079f9de5da33b  push rax
000079f9de5da33c  push rcx
000079f9de5da33d  push rdx
000079f9de5da33e  push rdi
000079f9de5da33f  push rsi
000079f9de5da340  push r8
000079f9de5da342  push r9
000079f9de5da344  push r10
000079f9de5da346  push r11
000079f9de5da348  sub rsp, 0xF0
000079f9de5da34f  vmovaps [rsp], xmm0
000079f9de5da354  vmovaps [rsp+0x10], xmm1
000079f9de5da35a  vmovaps [rsp+0x20], xmm2
000079f9de5da360  vmovaps [rsp+0x30], xmm3
000079f9de5da366  vmovaps [rsp+0x40], xmm4
000079f9de5da36c  vmovaps [rsp+0x50], xmm5
000079f9de5da372  vmovaps [rsp+0x60], xmm6
000079f9de5da378  vmovaps [rsp+0x70], xmm7
000079f9de5da37e  vmovaps [rsp+0x80], xmm8
000079f9de5da387  vmovaps [rsp+0x90], xmm9
000079f9de5da390  vmovaps [rsp+0xA0], xmm10
000079f9de5da399  vmovaps [rsp+0xB0], xmm11
000079f9de5da3a2  vmovaps [rsp+0xC0], xmm13
000079f9de5da3ab  vmovaps [rsp+0xD0], xmm14
000079f9de5da3b4  vmovaps [rsp+0xE0], xmm15
000079f9de5da3bd  sub rsp, 0x30
000079f9de5da3c1  movaps [rsp], xmm12
000079f9de5da3c6  movaps [rsp+0x10], xmm7
000079f9de5da3cb  movaps [rsp+0x20], xmm13
000079f9de5da3d1  lea rdi, [rsp]
000079f9de5da3d5  mov esi, 0x00
000079f9de5da3da  mov rax, 0x56D56FF59530
000079f9de5da3e4  call rax
000079f9de5da3e6  movaps xmm12, [rsp]
000079f9de5da3eb  add rsp, 0x30
000079f9de5da3ef  vmovaps xmm0, [rsp]
000079f9de5da3f4  vmovaps xmm1, [rsp+0x10]
000079f9de5da3fa  vmovaps xmm2, [rsp+0x20]
000079f9de5da400  vmovaps xmm3, [rsp+0x30]
000079f9de5da406  vmovaps xmm4, [rsp+0x40]
000079f9de5da40c  vmovaps xmm5, [rsp+0x50]
000079f9de5da412  vmovaps xmm6, [rsp+0x60]
000079f9de5da418  vmovaps xmm7, [rsp+0x70]
000079f9de5da41e  vmovaps xmm8, [rsp+0x80]
000079f9de5da427  vmovaps xmm9, [rsp+0x90]
000079f9de5da430  vmovaps xmm10, [rsp+0xA0]
000079f9de5da439  vmovaps xmm11, [rsp+0xB0]
000079f9de5da442  vmovaps xmm13, [rsp+0xC0]
000079f9de5da44b  vmovaps xmm14, [rsp+0xD0]
000079f9de5da454  vmovaps xmm15, [rsp+0xE0]
000079f9de5da45d  add rsp, 0xF0
000079f9de5da464  pop r11
000079f9de5da466  pop r10
000079f9de5da468  pop r9
000079f9de5da46a  pop r8
000079f9de5da46c  pop rsi
000079f9de5da46d  pop rdi
000079f9de5da46e  pop rdx
000079f9de5da46f  pop rcx
000079f9de5da470  pop rax
000079f9de5da471  add rsp, 0x08
000079f9de5da475  jmp 0x000079F9DE5D6441
000079f9de5da47a  sub rsp, 0x08
000079f9de5da47e  push rax
000079f9de5da47f  push rcx
000079f9de5da480  push rdx
000079f9de5da481  push rdi
000079f9de5da482  push rsi
000079f9de5da483  push r8
000079f9de5da485  push r9
000079f9de5da487  push r10
000079f9de5da489  push r11
000079f9de5da48b  sub rsp, 0xF0
000079f9de5da492  vmovaps [rsp], xmm0
000079f9de5da497  vmovaps [rsp+0x10], xmm1
000079f9de5da49d  vmovaps [rsp+0x20], xmm2
000079f9de5da4a3  vmovaps [rsp+0x30], xmm3
000079f9de5da4a9  vmovaps [rsp+0x40], xmm4
000079f9de5da4af  vmovaps [rsp+0x50], xmm5
000079f9de5da4b5  vmovaps [rsp+0x60], xmm6
000079f9de5da4bb  vmovaps [rsp+0x70], xmm7
000079f9de5da4c1  vmovaps [rsp+0x80], xmm8
000079f9de5da4ca  vmovaps [rsp+0x90], xmm9
000079f9de5da4d3  vmovaps [rsp+0xA0], xmm10
000079f9de5da4dc  vmovaps [rsp+0xB0], xmm11
000079f9de5da4e5  vmovaps [rsp+0xC0], xmm12
000079f9de5da4ee  vmovaps [rsp+0xD0], xmm14
000079f9de5da4f7  vmovaps [rsp+0xE0], xmm15
000079f9de5da500  sub rsp, 0x30
000079f9de5da504  movaps [rsp], xmm13
000079f9de5da509  movaps [rsp+0x10], xmm15
000079f9de5da50f  movaps [rsp+0x20], xmm8
000079f9de5da515  lea rdi, [rsp]
000079f9de5da519  mov esi, 0x00
000079f9de5da51e  mov rax, 0x56D56FF59530
000079f9de5da528  call rax
000079f9de5da52a  movaps xmm13, [rsp]
000079f9de5da52f  add rsp, 0x30
000079f9de5da533  vmovaps xmm0, [rsp]
000079f9de5da538  vmovaps xmm1, [rsp+0x10]
000079f9de5da53e  vmovaps xmm2, [rsp+0x20]
000079f9de5da544  vmovaps xmm3, [rsp+0x30]
000079f9de5da54a  vmovaps xmm4, [rsp+0x40]
000079f9de5da550  vmovaps xmm5, [rsp+0x50]
000079f9de5da556  vmovaps xmm6, [rsp+0x60]
000079f9de5da55c  vmovaps xmm7, [rsp+0x70]
000079f9de5da562  vmovaps xmm8, [rsp+0x80]
000079f9de5da56b  vmovaps xmm9, [rsp+0x90]
000079f9de5da574  vmovaps xmm10, [rsp+0xA0]
000079f9de5da57d  vmovaps xmm11, [rsp+0xB0]
000079f9de5da586  vmovaps xmm12, [rsp+0xC0]
000079f9de5da58f  vmovaps xmm14, [rsp+0xD0]
000079f9de5da598  vmovaps xmm15, [rsp+0xE0]
000079f9de5da5a1  add rsp, 0xF0
000079f9de5da5a8  pop r11
000079f9de5da5aa  pop r10
000079f9de5da5ac  pop r9
000079f9de5da5ae  pop r8
000079f9de5da5b0  pop rsi
000079f9de5da5b1  pop rdi
000079f9de5da5b2  pop rdx
000079f9de5da5b3  pop rcx
000079f9de5da5b4  pop rax
000079f9de5da5b5  add rsp, 0x08
000079f9de5da5b9  jmp 0x000079F9DE5D645C
000079f9de5da5be  sub rsp, 0x08
000079f9de5da5c2  push rax
000079f9de5da5c3  push rcx
000079f9de5da5c4  push rdx
000079f9de5da5c5  push rdi
000079f9de5da5c6  push rsi
000079f9de5da5c7  push r8
000079f9de5da5c9  push r9
000079f9de5da5cb  push r10
000079f9de5da5cd  push r11
000079f9de5da5cf  sub rsp, 0xF0
000079f9de5da5d6  vmovaps [rsp], xmm0
000079f9de5da5db  vmovaps [rsp+0x10], xmm1
000079f9de5da5e1  vmovaps [rsp+0x20], xmm2
000079f9de5da5e7  vmovaps [rsp+0x30], xmm3
000079f9de5da5ed  vmovaps [rsp+0x40], xmm4
000079f9de5da5f3  vmovaps [rsp+0x50], xmm5
000079f9de5da5f9  vmovaps [rsp+0x60], xmm6
000079f9de5da5ff  vmovaps [rsp+0x70], xmm7
000079f9de5da605  vmovaps [rsp+0x80], xmm9
000079f9de5da60e  vmovaps [rsp+0x90], xmm10
000079f9de5da617  vmovaps [rsp+0xA0], xmm11
000079f9de5da620  vmovaps [rsp+0xB0], xmm12
000079f9de5da629  vmovaps [rsp+0xC0], xmm13
000079f9de5da632  vmovaps [rsp+0xD0], xmm14
000079f9de5da63b  vmovaps [rsp+0xE0], xmm15
000079f9de5da644  sub rsp, 0x30
000079f9de5da648  movaps [rsp], xmm8
000079f9de5da64d  movaps [rsp+0x10], xmm15
000079f9de5da653  movaps [rsp+0x20], xmm9
000079f9de5da659  lea rdi, [rsp]
000079f9de5da65d  mov esi, 0x00
000079f9de5da662  mov rax, 0x56D56FF59530
000079f9de5da66c  call rax
000079f9de5da66e  movaps xmm8, [rsp]
000079f9de5da673  add rsp, 0x30
000079f9de5da677  vmovaps xmm0, [rsp]
000079f9de5da67c  vmovaps xmm1, [rsp+0x10]
000079f9de5da682  vmovaps xmm2, [rsp+0x20]
000079f9de5da688  vmovaps xmm3, [rsp+0x30]
000079f9de5da68e  vmovaps xmm4, [rsp+0x40]
000079f9de5da694  vmovaps xmm5, [rsp+0x50]
000079f9de5da69a  vmovaps xmm6, [rsp+0x60]
000079f9de5da6a0  vmovaps xmm7, [rsp+0x70]
000079f9de5da6a6  vmovaps xmm9, [rsp+0x80]
000079f9de5da6af  vmovaps xmm10, [rsp+0x90]
000079f9de5da6b8  vmovaps xmm11, [rsp+0xA0]
000079f9de5da6c1  vmovaps xmm12, [rsp+0xB0]
000079f9de5da6ca  vmovaps xmm13, [rsp+0xC0]
000079f9de5da6d3  vmovaps xmm14, [rsp+0xD0]
000079f9de5da6dc  vmovaps xmm15, [rsp+0xE0]
000079f9de5da6e5  add rsp, 0xF0
000079f9de5da6ec  pop r11
000079f9de5da6ee  pop r10
000079f9de5da6f0  pop r9
000079f9de5da6f2  pop r8
000079f9de5da6f4  pop rsi
000079f9de5da6f5  pop rdi
000079f9de5da6f6  pop rdx
000079f9de5da6f7  pop rcx
000079f9de5da6f8  pop rax
000079f9de5da6f9  add rsp, 0x08
000079f9de5da6fd  jmp 0x000079F9DE5D648A
000079f9de5da702  sub rsp, 0x08
000079f9de5da706  push rax
000079f9de5da707  push rcx
000079f9de5da708  push rdx
000079f9de5da709  push rdi
000079f9de5da70a  push rsi
000079f9de5da70b  push r8
000079f9de5da70d  push r9
000079f9de5da70f  push r10
000079f9de5da711  push r11
000079f9de5da713  sub rsp, 0xF0
000079f9de5da71a  vmovaps [rsp], xmm0
000079f9de5da71f  vmovaps [rsp+0x10], xmm1
000079f9de5da725  vmovaps [rsp+0x20], xmm2
000079f9de5da72b  vmovaps [rsp+0x30], xmm3
000079f9de5da731  vmovaps [rsp+0x40], xmm4
000079f9de5da737  vmovaps [rsp+0x50], xmm5
000079f9de5da73d  vmovaps [rsp+0x60], xmm6
000079f9de5da743  vmovaps [rsp+0x70], xmm7
000079f9de5da749  vmovaps [rsp+0x80], xmm8
000079f9de5da752  vmovaps [rsp+0x90], xmm9
000079f9de5da75b  vmovaps [rsp+0xA0], xmm10
000079f9de5da764  vmovaps [rsp+0xB0], xmm11
000079f9de5da76d  vmovaps [rsp+0xC0], xmm12
000079f9de5da776  vmovaps [rsp+0xD0], xmm13
000079f9de5da77f  vmovaps [rsp+0xE0], xmm14
000079f9de5da788  sub rsp, 0x30
000079f9de5da78c  movaps [rsp], xmm15
000079f9de5da791  movaps [rsp+0x10], xmm11
000079f9de5da797  movaps [rsp+0x20], xmm6
000079f9de5da79c  lea rdi, [rsp]
000079f9de5da7a0  mov esi, 0x00
000079f9de5da7a5  mov rax, 0x56D56FF59530
000079f9de5da7af  call rax
000079f9de5da7b1  movaps xmm15, [rsp]
000079f9de5da7b6  add rsp, 0x30
000079f9de5da7ba  vmovaps xmm0, [rsp]
000079f9de5da7bf  vmovaps xmm1, [rsp+0x10]
000079f9de5da7c5  vmovaps xmm2, [rsp+0x20]
000079f9de5da7cb  vmovaps xmm3, [rsp+0x30]
000079f9de5da7d1  vmovaps xmm4, [rsp+0x40]
000079f9de5da7d7  vmovaps xmm5, [rsp+0x50]
000079f9de5da7dd  vmovaps xmm6, [rsp+0x60]
000079f9de5da7e3  vmovaps xmm7, [rsp+0x70]
000079f9de5da7e9  vmovaps xmm8, [rsp+0x80]
000079f9de5da7f2  vmovaps xmm9, [rsp+0x90]
000079f9de5da7fb  vmovaps xmm10, [rsp+0xA0]
000079f9de5da804  vmovaps xmm11, [rsp+0xB0]
000079f9de5da80d  vmovaps xmm12, [rsp+0xC0]
000079f9de5da816  vmovaps xmm13, [rsp+0xD0]
000079f9de5da81f  vmovaps xmm14, [rsp+0xE0]
000079f9de5da828  add rsp, 0xF0
000079f9de5da82f  pop r11
000079f9de5da831  pop r10
000079f9de5da833  pop r9
000079f9de5da835  pop r8
000079f9de5da837  pop rsi
000079f9de5da838  pop rdi
000079f9de5da839  pop rdx
000079f9de5da83a  pop rcx
000079f9de5da83b  pop rax
000079f9de5da83c  add rsp, 0x08
000079f9de5da840  jmp 0x000079F9DE5D64A5
000079f9de5da845  sub rsp, 0x08
000079f9de5da849  push rax
000079f9de5da84a  push rcx
000079f9de5da84b  push rdx
000079f9de5da84c  push rdi
000079f9de5da84d  push rsi
000079f9de5da84e  push r8
000079f9de5da850  push r9
000079f9de5da852  push r10
000079f9de5da854  push r11
000079f9de5da856  sub rsp, 0xF0
000079f9de5da85d  vmovaps [rsp], xmm0
000079f9de5da862  vmovaps [rsp+0x10], xmm1
000079f9de5da868  vmovaps [rsp+0x20], xmm2
000079f9de5da86e  vmovaps [rsp+0x30], xmm3
000079f9de5da874  vmovaps [rsp+0x40], xmm4
000079f9de5da87a  vmovaps [rsp+0x50], xmm5
000079f9de5da880  vmovaps [rsp+0x60], xmm6
000079f9de5da886  vmovaps [rsp+0x70], xmm8
000079f9de5da88c  vmovaps [rsp+0x80], xmm9
000079f9de5da895  vmovaps [rsp+0x90], xmm10
000079f9de5da89e  vmovaps [rsp+0xA0], xmm11
000079f9de5da8a7  vmovaps [rsp+0xB0], xmm12
000079f9de5da8b0  vmovaps [rsp+0xC0], xmm13
000079f9de5da8b9  vmovaps [rsp+0xD0], xmm14
000079f9de5da8c2  vmovaps [rsp+0xE0], xmm15
000079f9de5da8cb  sub rsp, 0x30
000079f9de5da8cf  movaps [rsp], xmm7
000079f9de5da8d3  movaps [rsp+0x10], xmm11
000079f9de5da8d9  movaps [rsp+0x20], xmm9
000079f9de5da8df  lea rdi, [rsp]
000079f9de5da8e3  mov esi, 0x00
000079f9de5da8e8  mov rax, 0x56D56FF59530
000079f9de5da8f2  call rax
000079f9de5da8f4  movaps xmm7, [rsp]
000079f9de5da8f8  add rsp, 0x30
000079f9de5da8fc  vmovaps xmm0, [rsp]
000079f9de5da901  vmovaps xmm1, [rsp+0x10]
000079f9de5da907  vmovaps xmm2, [rsp+0x20]
000079f9de5da90d  vmovaps xmm3, [rsp+0x30]
000079f9de5da913  vmovaps xmm4, [rsp+0x40]
000079f9de5da919  vmovaps xmm5, [rsp+0x50]
000079f9de5da91f  vmovaps xmm6, [rsp+0x60]
000079f9de5da925  vmovaps xmm8, [rsp+0x70]
000079f9de5da92b  vmovaps xmm9, [rsp+0x80]
000079f9de5da934  vmovaps xmm10, [rsp+0x90]
000079f9de5da93d  vmovaps xmm11, [rsp+0xA0]
000079f9de5da946  vmovaps xmm12, [rsp+0xB0]
000079f9de5da94f  vmovaps xmm13, [rsp+0xC0]
000079f9de5da958  vmovaps xmm14, [rsp+0xD0]
000079f9de5da961  vmovaps xmm15, [rsp+0xE0]
000079f9de5da96a  add rsp, 0xF0
000079f9de5da971  pop r11
000079f9de5da973  pop r10
000079f9de5da975  pop r9
000079f9de5da977  pop r8
000079f9de5da979  pop rsi
000079f9de5da97a  pop rdi
000079f9de5da97b  pop rdx
000079f9de5da97c  pop rcx
000079f9de5da97d  pop rax
000079f9de5da97e  add rsp, 0x08
000079f9de5da982  jmp 0x000079F9DE5D64D2
000079f9de5da987  sub rsp, 0x08
000079f9de5da98b  push rax
000079f9de5da98c  push rcx
000079f9de5da98d  push rdx
000079f9de5da98e  push rdi
000079f9de5da98f  push rsi
000079f9de5da990  push r8
000079f9de5da992  push r9
000079f9de5da994  push r10
000079f9de5da996  push r11
000079f9de5da998  sub rsp, 0xF0
000079f9de5da99f  vmovaps [rsp], xmm0
000079f9de5da9a4  vmovaps [rsp+0x10], xmm1
000079f9de5da9aa  vmovaps [rsp+0x20], xmm2
000079f9de5da9b0  vmovaps [rsp+0x30], xmm3
000079f9de5da9b6  vmovaps [rsp+0x40], xmm4
000079f9de5da9bc  vmovaps [rsp+0x50], xmm5
000079f9de5da9c2  vmovaps [rsp+0x60], xmm6
000079f9de5da9c8  vmovaps [rsp+0x70], xmm7
000079f9de5da9ce  vmovaps [rsp+0x80], xmm8
000079f9de5da9d7  vmovaps [rsp+0x90], xmm9
000079f9de5da9e0  vmovaps [rsp+0xA0], xmm10
000079f9de5da9e9  vmovaps [rsp+0xB0], xmm12
000079f9de5da9f2  vmovaps [rsp+0xC0], xmm13
000079f9de5da9fb  vmovaps [rsp+0xD0], xmm14
000079f9de5daa04  vmovaps [rsp+0xE0], xmm15
000079f9de5daa0d  sub rsp, 0x30
000079f9de5daa11  movaps [rsp], xmm11
000079f9de5daa16  movaps [rsp+0x10], xmm10
000079f9de5daa1c  movaps [rsp+0x20], xmm14
000079f9de5daa22  lea rdi, [rsp]
000079f9de5daa26  mov esi, 0x00
000079f9de5daa2b  mov rax, 0x56D56FF59530
000079f9de5daa35  call rax
000079f9de5daa37  movaps xmm11, [rsp]
000079f9de5daa3c  add rsp, 0x30
000079f9de5daa40  vmovaps xmm0, [rsp]
000079f9de5daa45  vmovaps xmm1, [rsp+0x10]
000079f9de5daa4b  vmovaps xmm2, [rsp+0x20]
000079f9de5daa51  vmovaps xmm3, [rsp+0x30]
000079f9de5daa57  vmovaps xmm4, [rsp+0x40]
000079f9de5daa5d  vmovaps xmm5, [rsp+0x50]
000079f9de5daa63  vmovaps xmm6, [rsp+0x60]
000079f9de5daa69  vmovaps xmm7, [rsp+0x70]
000079f9de5daa6f  vmovaps xmm8, [rsp+0x80]
000079f9de5daa78  vmovaps xmm9, [rsp+0x90]
000079f9de5daa81  vmovaps xmm10, [rsp+0xA0]
000079f9de5daa8a  vmovaps xmm12, [rsp+0xB0]
000079f9de5daa93  vmovaps xmm13, [rsp+0xC0]
000079f9de5daa9c  vmovaps xmm14, [rsp+0xD0]
000079f9de5daaa5  vmovaps xmm15, [rsp+0xE0]
000079f9de5daaae  add rsp, 0xF0
000079f9de5daab5  pop r11
000079f9de5daab7  pop r10
000079f9de5daab9  pop r9
000079f9de5daabb  pop r8
000079f9de5daabd  pop rsi
000079f9de5daabe  pop rdi
000079f9de5daabf  pop rdx
000079f9de5daac0  pop rcx
000079f9de5daac1  pop rax
000079f9de5daac2  add rsp, 0x08
000079f9de5daac6  jmp 0x000079F9DE5D64ED
000079f9de5daacb  call 0x000079F9DE4E45A0
000079f9de5daad0  jmp 0x000079F9DE5D64F7
000079f9de5daad5  sub rsp, 0x08
000079f9de5daad9  push rax
000079f9de5daada  push rcx
000079f9de5daadb  push rdx
000079f9de5daadc  push rdi
000079f9de5daadd  push rsi
000079f9de5daade  push r8
000079f9de5daae0  push r9
000079f9de5daae2  push r10
000079f9de5daae4  push r11
000079f9de5daae6  sub rsp, 0xF0
000079f9de5daaed  vmovaps [rsp], xmm0
000079f9de5daaf2  vmovaps [rsp+0x10], xmm1
000079f9de5daaf8  vmovaps [rsp+0x20], xmm2
000079f9de5daafe  vmovaps [rsp+0x30], xmm3
000079f9de5dab04  vmovaps [rsp+0x40], xmm4
000079f9de5dab0a  vmovaps [rsp+0x50], xmm5
000079f9de5dab10  vmovaps [rsp+0x60], xmm6
000079f9de5dab16  vmovaps [rsp+0x70], xmm7
000079f9de5dab1c  vmovaps [rsp+0x80], xmm8
000079f9de5dab25  vmovaps [rsp+0x90], xmm9
000079f9de5dab2e  vmovaps [rsp+0xA0], xmm11
000079f9de5dab37  vmovaps [rsp+0xB0], xmm12
000079f9de5dab40  vmovaps [rsp+0xC0], xmm13
000079f9de5dab49  vmovaps [rsp+0xD0], xmm14
000079f9de5dab52  vmovaps [rsp+0xE0], xmm15
000079f9de5dab5b  sub rsp, 0x30
000079f9de5dab5f  movaps [rsp], xmm10
000079f9de5dab64  movaps [rsp+0x10], xmm1
000079f9de5dab69  movaps [rsp+0x20], xmm12
000079f9de5dab6f  lea rdi, [rsp]
000079f9de5dab73  mov esi, 0x00
000079f9de5dab78  mov rax, 0x56D56FF59530
000079f9de5dab82  call rax
000079f9de5dab84  movaps xmm10, [rsp]
000079f9de5dab89  add rsp, 0x30
000079f9de5dab8d  vmovaps xmm0, [rsp]
000079f9de5dab92  vmovaps xmm1, [rsp+0x10]
000079f9de5dab98  vmovaps xmm2, [rsp+0x20]
000079f9de5dab9e  vmovaps xmm3, [rsp+0x30]
000079f9de5daba4  vmovaps xmm4, [rsp+0x40]
000079f9de5dabaa  vmovaps xmm5, [rsp+0x50]
000079f9de5dabb0  vmovaps xmm6, [rsp+0x60]
000079f9de5dabb6  vmovaps xmm7, [rsp+0x70]
000079f9de5dabbc  vmovaps xmm8, [rsp+0x80]
000079f9de5dabc5  vmovaps xmm9, [rsp+0x90]
000079f9de5dabce  vmovaps xmm11, [rsp+0xA0]
000079f9de5dabd7  vmovaps xmm12, [rsp+0xB0]
000079f9de5dabe0  vmovaps xmm13, [rsp+0xC0]
000079f9de5dabe9  vmovaps xmm14, [rsp+0xD0]
000079f9de5dabf2  vmovaps xmm15, [rsp+0xE0]
000079f9de5dabfb  add rsp, 0xF0
000079f9de5dac02  pop r11
000079f9de5dac04  pop r10
000079f9de5dac06  pop r9
000079f9de5dac08  pop r8
000079f9de5dac0a  pop rsi
000079f9de5dac0b  pop rdi
000079f9de5dac0c  pop rdx
000079f9de5dac0d  pop rcx
000079f9de5dac0e  pop rax
000079f9de5dac0f  add rsp, 0x08
000079f9de5dac13  jmp 0x000079F9DE5D651A
000079f9de5dac18  sub rsp, 0x08
000079f9de5dac1c  push rax
000079f9de5dac1d  push rcx
000079f9de5dac1e  push rdx
000079f9de5dac1f  push rdi
000079f9de5dac20  push rsi
000079f9de5dac21  push r8
000079f9de5dac23  push r9
000079f9de5dac25  push r10
000079f9de5dac27  push r11
000079f9de5dac29  sub rsp, 0xF0
000079f9de5dac30  vmovaps [rsp], xmm0
000079f9de5dac35  vmovaps [rsp+0x10], xmm1
000079f9de5dac3b  vmovaps [rsp+0x20], xmm2
000079f9de5dac41  vmovaps [rsp+0x30], xmm3
000079f9de5dac47  vmovaps [rsp+0x40], xmm4
000079f9de5dac4d  vmovaps [rsp+0x50], xmm5
000079f9de5dac53  vmovaps [rsp+0x60], xmm6
000079f9de5dac59  vmovaps [rsp+0x70], xmm7
000079f9de5dac5f  vmovaps [rsp+0x80], xmm8
000079f9de5dac68  vmovaps [rsp+0x90], xmm9
000079f9de5dac71  vmovaps [rsp+0xA0], xmm10
000079f9de5dac7a  vmovaps [rsp+0xB0], xmm11
000079f9de5dac83  vmovaps [rsp+0xC0], xmm13
000079f9de5dac8c  vmovaps [rsp+0xD0], xmm14
000079f9de5dac95  vmovaps [rsp+0xE0], xmm15
000079f9de5dac9e  sub rsp, 0x30
000079f9de5daca2  movaps [rsp], xmm12
000079f9de5daca7  movaps [rsp+0x10], xmm14
000079f9de5dacad  movaps [rsp+0x20], xmm1
000079f9de5dacb2  lea rdi, [rsp]
000079f9de5dacb6  mov esi, 0x00
000079f9de5dacbb  mov rax, 0x56D56FF59530
000079f9de5dacc5  call rax
000079f9de5dacc7  movaps xmm12, [rsp]
000079f9de5daccc  add rsp, 0x30
000079f9de5dacd0  vmovaps xmm0, [rsp]
000079f9de5dacd5  vmovaps xmm1, [rsp+0x10]
000079f9de5dacdb  vmovaps xmm2, [rsp+0x20]
000079f9de5dace1  vmovaps xmm3, [rsp+0x30]
000079f9de5dace7  vmovaps xmm4, [rsp+0x40]
000079f9de5daced  vmovaps xmm5, [rsp+0x50]
000079f9de5dacf3  vmovaps xmm6, [rsp+0x60]
000079f9de5dacf9  vmovaps xmm7, [rsp+0x70]
000079f9de5dacff  vmovaps xmm8, [rsp+0x80]
000079f9de5dad08  vmovaps xmm9, [rsp+0x90]
000079f9de5dad11  vmovaps xmm10, [rsp+0xA0]
000079f9de5dad1a  vmovaps xmm11, [rsp+0xB0]
000079f9de5dad23  vmovaps xmm13, [rsp+0xC0]
000079f9de5dad2c  vmovaps xmm14, [rsp+0xD0]
000079f9de5dad35  vmovaps xmm15, [rsp+0xE0]
000079f9de5dad3e  add rsp, 0xF0
000079f9de5dad45  pop r11
000079f9de5dad47  pop r10
000079f9de5dad49  pop r9
000079f9de5dad4b  pop r8
000079f9de5dad4d  pop rsi
000079f9de5dad4e  pop rdi
000079f9de5dad4f  pop rdx
000079f9de5dad50  pop rcx
000079f9de5dad51  pop rax
000079f9de5dad52  add rsp, 0x08
000079f9de5dad56  jmp 0x000079F9DE5D6549
000079f9de5dad5b  sub rsp, 0x08
000079f9de5dad5f  push rax
000079f9de5dad60  push rcx
000079f9de5dad61  push rdx
000079f9de5dad62  push rdi
000079f9de5dad63  push rsi
000079f9de5dad64  push r8
000079f9de5dad66  push r9
000079f9de5dad68  push r10
000079f9de5dad6a  push r11
000079f9de5dad6c  sub rsp, 0xF0
000079f9de5dad73  vmovaps [rsp], xmm0
000079f9de5dad78  vmovaps [rsp+0x10], xmm1
000079f9de5dad7e  vmovaps [rsp+0x20], xmm2
000079f9de5dad84  vmovaps [rsp+0x30], xmm3
000079f9de5dad8a  vmovaps [rsp+0x40], xmm4
000079f9de5dad90  vmovaps [rsp+0x50], xmm5
000079f9de5dad96  vmovaps [rsp+0x60], xmm6
000079f9de5dad9c  vmovaps [rsp+0x70], xmm7
000079f9de5dada2  vmovaps [rsp+0x80], xmm8
000079f9de5dadab  vmovaps [rsp+0x90], xmm9
000079f9de5dadb4  vmovaps [rsp+0xA0], xmm10
000079f9de5dadbd  vmovaps [rsp+0xB0], xmm11
000079f9de5dadc6  vmovaps [rsp+0xC0], xmm12
000079f9de5dadcf  vmovaps [rsp+0xD0], xmm13
000079f9de5dadd8  vmovaps [rsp+0xE0], xmm15
000079f9de5dade1  sub rsp, 0x30
000079f9de5dade5  movaps [rsp], xmm14
000079f9de5dadea  movaps [rsp+0x10], xmm9
000079f9de5dadf0  movaps [rsp+0x20], xmm1
000079f9de5dadf5  lea rdi, [rsp]
000079f9de5dadf9  mov esi, 0x00
000079f9de5dadfe  mov rax, 0x56D56FF59530
000079f9de5dae08  call rax
000079f9de5dae0a  movaps xmm14, [rsp]
000079f9de5dae0f  add rsp, 0x30
000079f9de5dae13  vmovaps xmm0, [rsp]
000079f9de5dae18  vmovaps xmm1, [rsp+0x10]
000079f9de5dae1e  vmovaps xmm2, [rsp+0x20]
000079f9de5dae24  vmovaps xmm3, [rsp+0x30]
000079f9de5dae2a  vmovaps xmm4, [rsp+0x40]
000079f9de5dae30  vmovaps xmm5, [rsp+0x50]
000079f9de5dae36  vmovaps xmm6, [rsp+0x60]
000079f9de5dae3c  vmovaps xmm7, [rsp+0x70]
000079f9de5dae42  vmovaps xmm8, [rsp+0x80]
000079f9de5dae4b  vmovaps xmm9, [rsp+0x90]
000079f9de5dae54  vmovaps xmm10, [rsp+0xA0]
000079f9de5dae5d  vmovaps xmm11, [rsp+0xB0]
000079f9de5dae66  vmovaps xmm12, [rsp+0xC0]
000079f9de5dae6f  vmovaps xmm13, [rsp+0xD0]
000079f9de5dae78  vmovaps xmm15, [rsp+0xE0]
000079f9de5dae81  add rsp, 0xF0
000079f9de5dae88  pop r11
000079f9de5dae8a  pop r10
000079f9de5dae8c  pop r9
000079f9de5dae8e  pop r8
000079f9de5dae90  pop rsi
000079f9de5dae91  pop rdi
000079f9de5dae92  pop rdx
000079f9de5dae93  pop rcx
000079f9de5dae94  pop rax
000079f9de5dae95  add rsp, 0x08
000079f9de5dae99  jmp 0x000079F9DE5D6578
000079f9de5dae9e  sub rsp, 0x08
000079f9de5daea2  push rax
000079f9de5daea3  push rcx
000079f9de5daea4  push rdx
000079f9de5daea5  push rdi
000079f9de5daea6  push rsi
000079f9de5daea7  push r8
000079f9de5daea9  push r9
000079f9de5daeab  push r10
000079f9de5daead  push r11
000079f9de5daeaf  sub rsp, 0xF0
000079f9de5daeb6  vmovaps [rsp], xmm0
000079f9de5daebb  vmovaps [rsp+0x10], xmm2
000079f9de5daec1  vmovaps [rsp+0x20], xmm3
000079f9de5daec7  vmovaps [rsp+0x30], xmm4
000079f9de5daecd  vmovaps [rsp+0x40], xmm5
000079f9de5daed3  vmovaps [rsp+0x50], xmm6
000079f9de5daed9  vmovaps [rsp+0x60], xmm7
000079f9de5daedf  vmovaps [rsp+0x70], xmm8
000079f9de5daee5  vmovaps [rsp+0x80], xmm9
000079f9de5daeee  vmovaps [rsp+0x90], xmm10
000079f9de5daef7  vmovaps [rsp+0xA0], xmm11
000079f9de5daf00  vmovaps [rsp+0xB0], xmm12
000079f9de5daf09  vmovaps [rsp+0xC0], xmm13
000079f9de5daf12  vmovaps [rsp+0xD0], xmm14
000079f9de5daf1b  vmovaps [rsp+0xE0], xmm15
000079f9de5daf24  sub rsp, 0x30
000079f9de5daf28  movaps [rsp], xmm1
000079f9de5daf2c  movaps [rsp+0x10], xmm13
000079f9de5daf32  movaps [rsp+0x20], xmm8
000079f9de5daf38  lea rdi, [rsp]
000079f9de5daf3c  mov esi, 0x00
000079f9de5daf41  mov rax, 0x56D56FF59530
000079f9de5daf4b  call rax
000079f9de5daf4d  movaps xmm1, [rsp]
000079f9de5daf51  add rsp, 0x30
000079f9de5daf55  vmovaps xmm0, [rsp]
000079f9de5daf5a  vmovaps xmm2, [rsp+0x10]
000079f9de5daf60  vmovaps xmm3, [rsp+0x20]
000079f9de5daf66  vmovaps xmm4, [rsp+0x30]
000079f9de5daf6c  vmovaps xmm5, [rsp+0x40]
000079f9de5daf72  vmovaps xmm6, [rsp+0x50]
000079f9de5daf78  vmovaps xmm7, [rsp+0x60]
000079f9de5daf7e  vmovaps xmm8, [rsp+0x70]
000079f9de5daf84  vmovaps xmm9, [rsp+0x80]
000079f9de5daf8d  vmovaps xmm10, [rsp+0x90]
000079f9de5daf96  vmovaps xmm11, [rsp+0xA0]
000079f9de5daf9f  vmovaps xmm12, [rsp+0xB0]
000079f9de5dafa8  vmovaps xmm13, [rsp+0xC0]
000079f9de5dafb1  vmovaps xmm14, [rsp+0xD0]
000079f9de5dafba  vmovaps xmm15, [rsp+0xE0]
000079f9de5dafc3  add rsp, 0xF0
000079f9de5dafca  pop r11
000079f9de5dafcc  pop r10
000079f9de5dafce  pop r9
000079f9de5dafd0  pop r8
000079f9de5dafd2  pop rsi
000079f9de5dafd3  pop rdi
000079f9de5dafd4  pop rdx
000079f9de5dafd5  pop rcx
000079f9de5dafd6  pop rax
000079f9de5dafd7  add rsp, 0x08
000079f9de5dafdb  jmp 0x000079F9DE5D659A
000079f9de5dafe0  call 0x000079F9DE40C260
000079f9de5dafe5  jmp 0x000079F9DE5D65A8
000079f9de5dafea  call 0x000079F9DE4DE950
000079f9de5dafef  jmp 0x000079F9DE5D65B2
000079f9de5daff4  sub rsp, 0x08
000079f9de5daff8  push rax
000079f9de5daff9  push rcx
000079f9de5daffa  push rdx
000079f9de5daffb  push rdi
000079f9de5daffc  push rsi
000079f9de5daffd  push r8
000079f9de5dafff  push r9
000079f9de5db001  push r10
000079f9de5db003  push r11
000079f9de5db005  sub rsp, 0xF0
000079f9de5db00c  vmovaps [rsp], xmm0
000079f9de5db011  vmovaps [rsp+0x10], xmm1
000079f9de5db017  vmovaps [rsp+0x20], xmm2
000079f9de5db01d  vmovaps [rsp+0x30], xmm3
000079f9de5db023  vmovaps [rsp+0x40], xmm4
000079f9de5db029  vmovaps [rsp+0x50], xmm5
000079f9de5db02f  vmovaps [rsp+0x60], xmm6
000079f9de5db035  vmovaps [rsp+0x70], xmm7
000079f9de5db03b  vmovaps [rsp+0x80], xmm9
000079f9de5db044  vmovaps [rsp+0x90], xmm10
000079f9de5db04d  vmovaps [rsp+0xA0], xmm11
000079f9de5db056  vmovaps [rsp+0xB0], xmm12
000079f9de5db05f  vmovaps [rsp+0xC0], xmm13
000079f9de5db068  vmovaps [rsp+0xD0], xmm14
000079f9de5db071  vmovaps [rsp+0xE0], xmm15
000079f9de5db07a  sub rsp, 0x30
000079f9de5db07e  movaps [rsp], xmm8
000079f9de5db083  movaps [rsp+0x10], xmm15
000079f9de5db089  movaps [rsp+0x20], xmm7
000079f9de5db08e  lea rdi, [rsp]
000079f9de5db092  mov esi, 0x00
000079f9de5db097  mov rax, 0x56D56FF59530
000079f9de5db0a1  call rax
000079f9de5db0a3  movaps xmm8, [rsp]
000079f9de5db0a8  add rsp, 0x30
000079f9de5db0ac  vmovaps xmm0, [rsp]
000079f9de5db0b1  vmovaps xmm1, [rsp+0x10]
000079f9de5db0b7  vmovaps xmm2, [rsp+0x20]
000079f9de5db0bd  vmovaps xmm3, [rsp+0x30]
000079f9de5db0c3  vmovaps xmm4, [rsp+0x40]
000079f9de5db0c9  vmovaps xmm5, [rsp+0x50]
000079f9de5db0cf  vmovaps xmm6, [rsp+0x60]
000079f9de5db0d5  vmovaps xmm7, [rsp+0x70]
000079f9de5db0db  vmovaps xmm9, [rsp+0x80]
000079f9de5db0e4  vmovaps xmm10, [rsp+0x90]
000079f9de5db0ed  vmovaps xmm11, [rsp+0xA0]
000079f9de5db0f6  vmovaps xmm12, [rsp+0xB0]
000079f9de5db0ff  vmovaps xmm13, [rsp+0xC0]
000079f9de5db108  vmovaps xmm14, [rsp+0xD0]
000079f9de5db111  vmovaps xmm15, [rsp+0xE0]
000079f9de5db11a  add rsp, 0xF0
000079f9de5db121  pop r11
000079f9de5db123  pop r10
000079f9de5db125  pop r9
000079f9de5db127  pop r8
000079f9de5db129  pop rsi
000079f9de5db12a  pop rdi
000079f9de5db12b  pop rdx
000079f9de5db12c  pop rcx
000079f9de5db12d  pop rax
000079f9de5db12e  add rsp, 0x08
000079f9de5db132  jmp 0x000079F9DE5D65D4
000079f9de5db137  sub rsp, 0x08
000079f9de5db13b  push rax
000079f9de5db13c  push rcx
000079f9de5db13d  push rdx
000079f9de5db13e  push rdi
000079f9de5db13f  push rsi
000079f9de5db140  push r8
000079f9de5db142  push r9
000079f9de5db144  push r10
000079f9de5db146  push r11
000079f9de5db148  sub rsp, 0xF0
000079f9de5db14f  vmovaps [rsp], xmm0
000079f9de5db154  vmovaps [rsp+0x10], xmm1
000079f9de5db15a  vmovaps [rsp+0x20], xmm2
000079f9de5db160  vmovaps [rsp+0x30], xmm3
000079f9de5db166  vmovaps [rsp+0x40], xmm4
000079f9de5db16c  vmovaps [rsp+0x50], xmm5
000079f9de5db172  vmovaps [rsp+0x60], xmm6
000079f9de5db178  vmovaps [rsp+0x70], xmm8
000079f9de5db17e  vmovaps [rsp+0x80], xmm9
000079f9de5db187  vmovaps [rsp+0x90], xmm10
000079f9de5db190  vmovaps [rsp+0xA0], xmm11
000079f9de5db199  vmovaps [rsp+0xB0], xmm12
000079f9de5db1a2  vmovaps [rsp+0xC0], xmm13
000079f9de5db1ab  vmovaps [rsp+0xD0], xmm14
000079f9de5db1b4  vmovaps [rsp+0xE0], xmm15
000079f9de5db1bd  sub rsp, 0x30
000079f9de5db1c1  movaps [rsp], xmm7
000079f9de5db1c5  movaps [rsp+0x10], xmm9
000079f9de5db1cb  movaps [rsp+0x20], xmm15
000079f9de5db1d1  lea rdi, [rsp]
000079f9de5db1d5  mov esi, 0x00
000079f9de5db1da  mov rax, 0x56D56FF59530
000079f9de5db1e4  call rax
000079f9de5db1e6  movaps xmm7, [rsp]
000079f9de5db1ea  add rsp, 0x30
000079f9de5db1ee  vmovaps xmm0, [rsp]
000079f9de5db1f3  vmovaps xmm1, [rsp+0x10]
000079f9de5db1f9  vmovaps xmm2, [rsp+0x20]
000079f9de5db1ff  vmovaps xmm3, [rsp+0x30]
000079f9de5db205  vmovaps xmm4, [rsp+0x40]
000079f9de5db20b  vmovaps xmm5, [rsp+0x50]
000079f9de5db211  vmovaps xmm6, [rsp+0x60]
000079f9de5db217  vmovaps xmm8, [rsp+0x70]
000079f9de5db21d  vmovaps xmm9, [rsp+0x80]
000079f9de5db226  vmovaps xmm10, [rsp+0x90]
000079f9de5db22f  vmovaps xmm11, [rsp+0xA0]
000079f9de5db238  vmovaps xmm12, [rsp+0xB0]
000079f9de5db241  vmovaps xmm13, [rsp+0xC0]
000079f9de5db24a  vmovaps xmm14, [rsp+0xD0]
000079f9de5db253  vmovaps xmm15, [rsp+0xE0]
000079f9de5db25c  add rsp, 0xF0
000079f9de5db263  pop r11
000079f9de5db265  pop r10
000079f9de5db267  pop r9
000079f9de5db269  pop r8
000079f9de5db26b  pop rsi
000079f9de5db26c  pop rdi
000079f9de5db26d  pop rdx
000079f9de5db26e  pop rcx
000079f9de5db26f  pop rax
000079f9de5db270  add rsp, 0x08
000079f9de5db274  jmp 0x000079F9DE5D6601
000079f9de5db279  sub rsp, 0x08
000079f9de5db27d  push rax
000079f9de5db27e  push rcx
000079f9de5db27f  push rdx
000079f9de5db280  push rdi
000079f9de5db281  push rsi
000079f9de5db282  push r8
000079f9de5db284  push r9
000079f9de5db286  push r10
000079f9de5db288  push r11
000079f9de5db28a  sub rsp, 0xF0
000079f9de5db291  vmovaps [rsp], xmm0
000079f9de5db296  vmovaps [rsp+0x10], xmm1
000079f9de5db29c  vmovaps [rsp+0x20], xmm2
000079f9de5db2a2  vmovaps [rsp+0x30], xmm3
000079f9de5db2a8  vmovaps [rsp+0x40], xmm4
000079f9de5db2ae  vmovaps [rsp+0x50], xmm5
000079f9de5db2b4  vmovaps [rsp+0x60], xmm6
000079f9de5db2ba  vmovaps [rsp+0x70], xmm7
000079f9de5db2c0  vmovaps [rsp+0x80], xmm8
000079f9de5db2c9  vmovaps [rsp+0x90], xmm10
000079f9de5db2d2  vmovaps [rsp+0xA0], xmm11
000079f9de5db2db  vmovaps [rsp+0xB0], xmm12
000079f9de5db2e4  vmovaps [rsp+0xC0], xmm13
000079f9de5db2ed  vmovaps [rsp+0xD0], xmm14
000079f9de5db2f6  vmovaps [rsp+0xE0], xmm15
000079f9de5db2ff  sub rsp, 0x30
000079f9de5db303  movaps [rsp], xmm9
000079f9de5db308  movaps [rsp+0x10], xmm13
000079f9de5db30e  movaps [rsp+0x20], xmm15
000079f9de5db314  lea rdi, [rsp]
000079f9de5db318  mov esi, 0x00
000079f9de5db31d  mov rax, 0x56D56FF59530
000079f9de5db327  call rax
000079f9de5db329  movaps xmm9, [rsp]
000079f9de5db32e  add rsp, 0x30
000079f9de5db332  vmovaps xmm0, [rsp]
000079f9de5db337  vmovaps xmm1, [rsp+0x10]
000079f9de5db33d  vmovaps xmm2, [rsp+0x20]
000079f9de5db343  vmovaps xmm3, [rsp+0x30]
000079f9de5db349  vmovaps xmm4, [rsp+0x40]
000079f9de5db34f  vmovaps xmm5, [rsp+0x50]
000079f9de5db355  vmovaps xmm6, [rsp+0x60]
000079f9de5db35b  vmovaps xmm7, [rsp+0x70]
000079f9de5db361  vmovaps xmm8, [rsp+0x80]
000079f9de5db36a  vmovaps xmm10, [rsp+0x90]
000079f9de5db373  vmovaps xmm11, [rsp+0xA0]
000079f9de5db37c  vmovaps xmm12, [rsp+0xB0]
000079f9de5db385  vmovaps xmm13, [rsp+0xC0]
000079f9de5db38e  vmovaps xmm14, [rsp+0xD0]
000079f9de5db397  vmovaps xmm15, [rsp+0xE0]
000079f9de5db3a0  add rsp, 0xF0
000079f9de5db3a7  pop r11
000079f9de5db3a9  pop r10
000079f9de5db3ab  pop r9
000079f9de5db3ad  pop r8
000079f9de5db3af  pop rsi
000079f9de5db3b0  pop rdi
000079f9de5db3b1  pop rdx
000079f9de5db3b2  pop rcx
000079f9de5db3b3  pop rax
000079f9de5db3b4  add rsp, 0x08
000079f9de5db3b8  jmp 0x000079F9DE5D662F
000079f9de5db3bd  sub rsp, 0x08
000079f9de5db3c1  push rax
000079f9de5db3c2  push rcx
000079f9de5db3c3  push rdx
000079f9de5db3c4  push rdi
000079f9de5db3c5  push rsi
000079f9de5db3c6  push r8
000079f9de5db3c8  push r9
000079f9de5db3ca  push r10
000079f9de5db3cc  push r11
000079f9de5db3ce  sub rsp, 0xF0
000079f9de5db3d5  vmovaps [rsp], xmm0
000079f9de5db3da  vmovaps [rsp+0x10], xmm1
000079f9de5db3e0  vmovaps [rsp+0x20], xmm2
000079f9de5db3e6  vmovaps [rsp+0x30], xmm3
000079f9de5db3ec  vmovaps [rsp+0x40], xmm4
000079f9de5db3f2  vmovaps [rsp+0x50], xmm5
000079f9de5db3f8  vmovaps [rsp+0x60], xmm6
000079f9de5db3fe  vmovaps [rsp+0x70], xmm7
000079f9de5db404  vmovaps [rsp+0x80], xmm8
000079f9de5db40d  vmovaps [rsp+0x90], xmm9
000079f9de5db416  vmovaps [rsp+0xA0], xmm10
000079f9de5db41f  vmovaps [rsp+0xB0], xmm11
000079f9de5db428  vmovaps [rsp+0xC0], xmm12
000079f9de5db431  vmovaps [rsp+0xD0], xmm13
000079f9de5db43a  vmovaps [rsp+0xE0], xmm14
000079f9de5db443  sub rsp, 0x30
000079f9de5db447  movaps [rsp], xmm15
000079f9de5db44c  movaps [rsp+0x10], xmm11
000079f9de5db452  movaps [rsp+0x20], xmm12
000079f9de5db458  lea rdi, [rsp]
000079f9de5db45c  mov esi, 0x00
000079f9de5db461  mov rax, 0x56D56FF59530
000079f9de5db46b  call rax
000079f9de5db46d  movaps xmm15, [rsp]
000079f9de5db472  add rsp, 0x30
000079f9de5db476  vmovaps xmm0, [rsp]
000079f9de5db47b  vmovaps xmm1, [rsp+0x10]
000079f9de5db481  vmovaps xmm2, [rsp+0x20]
000079f9de5db487  vmovaps xmm3, [rsp+0x30]
000079f9de5db48d  vmovaps xmm4, [rsp+0x40]
000079f9de5db493  vmovaps xmm5, [rsp+0x50]
000079f9de5db499  vmovaps xmm6, [rsp+0x60]
000079f9de5db49f  vmovaps xmm7, [rsp+0x70]
000079f9de5db4a5  vmovaps xmm8, [rsp+0x80]
000079f9de5db4ae  vmovaps xmm9, [rsp+0x90]
000079f9de5db4b7  vmovaps xmm10, [rsp+0xA0]
000079f9de5db4c0  vmovaps xmm11, [rsp+0xB0]
000079f9de5db4c9  vmovaps xmm12, [rsp+0xC0]
000079f9de5db4d2  vmovaps xmm13, [rsp+0xD0]
000079f9de5db4db  vmovaps xmm14, [rsp+0xE0]
000079f9de5db4e4  add rsp, 0xF0
000079f9de5db4eb  pop r11
000079f9de5db4ed  pop r10
000079f9de5db4ef  pop r9
000079f9de5db4f1  pop r8
000079f9de5db4f3  pop rsi
000079f9de5db4f4  pop rdi
000079f9de5db4f5  pop rdx
000079f9de5db4f6  pop rcx
000079f9de5db4f7  pop rax
000079f9de5db4f8  add rsp, 0x08
000079f9de5db4fc  jmp 0x000079F9DE5D664A
000079f9de5db501  sub rsp, 0x08
000079f9de5db505  push rax
000079f9de5db506  push rcx
000079f9de5db507  push rdx
000079f9de5db508  push rdi
000079f9de5db509  push rsi
000079f9de5db50a  push r8
000079f9de5db50c  push r9
000079f9de5db50e  push r10
000079f9de5db510  push r11
000079f9de5db512  sub rsp, 0xF0
000079f9de5db519  vmovaps [rsp], xmm0
000079f9de5db51e  vmovaps [rsp+0x10], xmm1
000079f9de5db524  vmovaps [rsp+0x20], xmm2
000079f9de5db52a  vmovaps [rsp+0x30], xmm3
000079f9de5db530  vmovaps [rsp+0x40], xmm4
000079f9de5db536  vmovaps [rsp+0x50], xmm5
000079f9de5db53c  vmovaps [rsp+0x60], xmm6
000079f9de5db542  vmovaps [rsp+0x70], xmm7
000079f9de5db548  vmovaps [rsp+0x80], xmm8
000079f9de5db551  vmovaps [rsp+0x90], xmm9
000079f9de5db55a  vmovaps [rsp+0xA0], xmm10
000079f9de5db563  vmovaps [rsp+0xB0], xmm11
000079f9de5db56c  vmovaps [rsp+0xC0], xmm12
000079f9de5db575  vmovaps [rsp+0xD0], xmm14
000079f9de5db57e  vmovaps [rsp+0xE0], xmm15
000079f9de5db587  sub rsp, 0x30
000079f9de5db58b  movaps [rsp], xmm13
000079f9de5db590  movaps [rsp+0x10], xmm10
000079f9de5db596  movaps [rsp+0x20], xmm14
000079f9de5db59c  lea rdi, [rsp]
000079f9de5db5a0  mov esi, 0x00
000079f9de5db5a5  mov rax, 0x56D56FF59530
000079f9de5db5af  call rax
000079f9de5db5b1  movaps xmm13, [rsp]
000079f9de5db5b6  add rsp, 0x30
000079f9de5db5ba  vmovaps xmm0, [rsp]
000079f9de5db5bf  vmovaps xmm1, [rsp+0x10]
000079f9de5db5c5  vmovaps xmm2, [rsp+0x20]
000079f9de5db5cb  vmovaps xmm3, [rsp+0x30]
000079f9de5db5d1  vmovaps xmm4, [rsp+0x40]
000079f9de5db5d7  vmovaps xmm5, [rsp+0x50]
000079f9de5db5dd  vmovaps xmm6, [rsp+0x60]
000079f9de5db5e3  vmovaps xmm7, [rsp+0x70]
000079f9de5db5e9  vmovaps xmm8, [rsp+0x80]
000079f9de5db5f2  vmovaps xmm9, [rsp+0x90]
000079f9de5db5fb  vmovaps xmm10, [rsp+0xA0]
000079f9de5db604  vmovaps xmm11, [rsp+0xB0]
000079f9de5db60d  vmovaps xmm12, [rsp+0xC0]
000079f9de5db616  vmovaps xmm14, [rsp+0xD0]
000079f9de5db61f  vmovaps xmm15, [rsp+0xE0]
000079f9de5db628  add rsp, 0xF0
000079f9de5db62f  pop r11
000079f9de5db631  pop r10
000079f9de5db633  pop r9
000079f9de5db635  pop r8
000079f9de5db637  pop rsi
000079f9de5db638  pop rdi
000079f9de5db639  pop rdx
000079f9de5db63a  pop rcx
000079f9de5db63b  pop rax
000079f9de5db63c  add rsp, 0x08
000079f9de5db640  jmp 0x000079F9DE5D666D
000079f9de5db645  sub rsp, 0x08
000079f9de5db649  push rax
000079f9de5db64a  push rcx
000079f9de5db64b  push rdx
000079f9de5db64c  push rdi
000079f9de5db64d  push rsi
000079f9de5db64e  push r8
000079f9de5db650  push r9
000079f9de5db652  push r10
000079f9de5db654  push r11
000079f9de5db656  sub rsp, 0xF0
000079f9de5db65d  vmovaps [rsp], xmm0
000079f9de5db662  vmovaps [rsp+0x10], xmm1
000079f9de5db668  vmovaps [rsp+0x20], xmm2
000079f9de5db66e  vmovaps [rsp+0x30], xmm3
000079f9de5db674  vmovaps [rsp+0x40], xmm4
000079f9de5db67a  vmovaps [rsp+0x50], xmm5
000079f9de5db680  vmovaps [rsp+0x60], xmm6
000079f9de5db686  vmovaps [rsp+0x70], xmm7
000079f9de5db68c  vmovaps [rsp+0x80], xmm8
000079f9de5db695  vmovaps [rsp+0x90], xmm9
000079f9de5db69e  vmovaps [rsp+0xA0], xmm10
000079f9de5db6a7  vmovaps [rsp+0xB0], xmm11
000079f9de5db6b0  vmovaps [rsp+0xC0], xmm12
000079f9de5db6b9  vmovaps [rsp+0xD0], xmm13
000079f9de5db6c2  vmovaps [rsp+0xE0], xmm15
000079f9de5db6cb  sub rsp, 0x30
000079f9de5db6cf  movaps [rsp], xmm14
000079f9de5db6d4  movaps [rsp+0x10], xmm1
000079f9de5db6d9  movaps [rsp+0x20], xmm7
000079f9de5db6de  lea rdi, [rsp]
000079f9de5db6e2  mov esi, 0x00
000079f9de5db6e7  mov rax, 0x56D56FF59530
000079f9de5db6f1  call rax
000079f9de5db6f3  movaps xmm14, [rsp]
000079f9de5db6f8  add rsp, 0x30
000079f9de5db6fc  vmovaps xmm0, [rsp]
000079f9de5db701  vmovaps xmm1, [rsp+0x10]
000079f9de5db707  vmovaps xmm2, [rsp+0x20]
000079f9de5db70d  vmovaps xmm3, [rsp+0x30]
000079f9de5db713  vmovaps xmm4, [rsp+0x40]
000079f9de5db719  vmovaps xmm5, [rsp+0x50]
000079f9de5db71f  vmovaps xmm6, [rsp+0x60]
000079f9de5db725  vmovaps xmm7, [rsp+0x70]
000079f9de5db72b  vmovaps xmm8, [rsp+0x80]
000079f9de5db734  vmovaps xmm9, [rsp+0x90]
000079f9de5db73d  vmovaps xmm10, [rsp+0xA0]
000079f9de5db746  vmovaps xmm11, [rsp+0xB0]
000079f9de5db74f  vmovaps xmm12, [rsp+0xC0]
000079f9de5db758  vmovaps xmm13, [rsp+0xD0]
000079f9de5db761  vmovaps xmm15, [rsp+0xE0]
000079f9de5db76a  add rsp, 0xF0
000079f9de5db771  pop r11
000079f9de5db773  pop r10
000079f9de5db775  pop r9
000079f9de5db777  pop r8
000079f9de5db779  pop rsi
000079f9de5db77a  pop rdi
000079f9de5db77b  pop rdx
000079f9de5db77c  pop rcx
000079f9de5db77d  pop rax
000079f9de5db77e  add rsp, 0x08
000079f9de5db782  jmp 0x000079F9DE5D6690
000079f9de5db787  sub rsp, 0x08
000079f9de5db78b  push rax
000079f9de5db78c  push rcx
000079f9de5db78d  push rdx
000079f9de5db78e  push rdi
000079f9de5db78f  push rsi
000079f9de5db790  push r8
000079f9de5db792  push r9
000079f9de5db794  push r10
000079f9de5db796  push r11
000079f9de5db798  sub rsp, 0xF0
000079f9de5db79f  vmovaps [rsp], xmm0
000079f9de5db7a4  vmovaps [rsp+0x10], xmm2
000079f9de5db7aa  vmovaps [rsp+0x20], xmm3
000079f9de5db7b0  vmovaps [rsp+0x30], xmm4
000079f9de5db7b6  vmovaps [rsp+0x40], xmm5
000079f9de5db7bc  vmovaps [rsp+0x50], xmm6
000079f9de5db7c2  vmovaps [rsp+0x60], xmm7
000079f9de5db7c8  vmovaps [rsp+0x70], xmm8
000079f9de5db7ce  vmovaps [rsp+0x80], xmm9
000079f9de5db7d7  vmovaps [rsp+0x90], xmm10
000079f9de5db7e0  vmovaps [rsp+0xA0], xmm11
000079f9de5db7e9  vmovaps [rsp+0xB0], xmm12
000079f9de5db7f2  vmovaps [rsp+0xC0], xmm13
000079f9de5db7fb  vmovaps [rsp+0xD0], xmm14
000079f9de5db804  vmovaps [rsp+0xE0], xmm15
000079f9de5db80d  sub rsp, 0x30
000079f9de5db811  movaps [rsp], xmm1
000079f9de5db815  movaps [rsp+0x10], xmm8
000079f9de5db81b  movaps [rsp+0x20], xmm9
000079f9de5db821  lea rdi, [rsp]
000079f9de5db825  mov esi, 0x00
000079f9de5db82a  mov rax, 0x56D56FF59530
000079f9de5db834  call rax
000079f9de5db836  movaps xmm1, [rsp]
000079f9de5db83a  add rsp, 0x30
000079f9de5db83e  vmovaps xmm0, [rsp]
000079f9de5db843  vmovaps xmm2, [rsp+0x10]
000079f9de5db849  vmovaps xmm3, [rsp+0x20]
000079f9de5db84f  vmovaps xmm4, [rsp+0x30]
000079f9de5db855  vmovaps xmm5, [rsp+0x40]
000079f9de5db85b  vmovaps xmm6, [rsp+0x50]
000079f9de5db861  vmovaps xmm7, [rsp+0x60]
000079f9de5db867  vmovaps xmm8, [rsp+0x70]
000079f9de5db86d  vmovaps xmm9, [rsp+0x80]
000079f9de5db876  vmovaps xmm10, [rsp+0x90]
000079f9de5db87f  vmovaps xmm11, [rsp+0xA0]
000079f9de5db888  vmovaps xmm12, [rsp+0xB0]
000079f9de5db891  vmovaps xmm13, [rsp+0xC0]
000079f9de5db89a  vmovaps xmm14, [rsp+0xD0]
000079f9de5db8a3  vmovaps xmm15, [rsp+0xE0]
000079f9de5db8ac  add rsp, 0xF0
000079f9de5db8b3  pop r11
000079f9de5db8b5  pop r10
000079f9de5db8b7  pop r9
000079f9de5db8b9  pop r8
000079f9de5db8bb  pop rsi
000079f9de5db8bc  pop rdi
000079f9de5db8bd  pop rdx
000079f9de5db8be  pop rcx
000079f9de5db8bf  pop rax
000079f9de5db8c0  add rsp, 0x08
000079f9de5db8c4  jmp 0x000079F9DE5D66B2
000079f9de5db8c9  call 0x000079F9DE4B3E40
000079f9de5db8ce  jmp 0x000079F9DE5D66C0
000079f9de5db8d3  call 0x000079F9DE40C380
000079f9de5db8d8  jmp 0x000079F9DE5D66CA
000079f9de5db8dd  call 0x000079F9DE40D600
000079f9de5db8e2  jmp 0x000079F9DE5D66D4
000079f9de5db8e7  call 0x000079F9DE3FF540
000079f9de5db8ec  jmp 0x000079F9DE5D66DE
000079f9de5db8f1  int3
000079f9de5db8f2  nop [rax+rax*1], ax
000079f9de5db8fb  nop [rax+rax*1], eax
000079f9de5db900  mov eax, [r15+0x48]
000079f9de5db904  lea r14d, [eax+0x01]
000079f9de5db909  mov [rsp+0x10], r14d
000079f9de5db90e  mov r14d, r14d
000079f9de5db911  mov [r15+0x48], r14
000079f9de5db915  xor eax, eax
000079f9de5db917  mov r14d, [rsp+0x10]
000079f9de5db91c  cmp r14d, 0x1F4
000079f9de5db923  cmc
000079f9de5db924  lahf
000079f9de5db925  seto al
000079f9de5db928  mov [r15+0x108], eax
000079f9de5db92f  mov eax, [r15+0x108]
000079f9de5db936  sahf
000079f9de5db937  jnz 0x000079F9DE5DB969
000079f9de5db939  cmp dword ptr [r15+0x318], 0x00
000079f9de5db941  jz 0x000079F9DE5E1AB0
000079f9de5db947  nop [rax+rax*1], ax
000079f9de5db950  nop [rax+rax*1], eax
000079f9de5db958  mov eax, 0x410450
000079f9de5db95d  mov [r15+0x100], rax
000079f9de5db964  jmp 0x000079F9DE3FE110
000079f9de5db969  cmp dword ptr [r15+0x318], 0x00
000079f9de5db971  jz 0x000079F9DE5DB9A0
000079f9de5db977  nop [rax+rax*1], ax
000079f9de5db980  nop [rax+rax*1], eax
000079f9de5db988  mov eax, 0x410274
000079f9de5db98d  mov [r15+0x100], rax
000079f9de5db994  jmp 0x000079F9DE3FE110
000079f9de5db999  int3
000079f9de5db99a  int3
000079f9de5db99b  nop [rax+rax*1], eax
000079f9de5db9a0  mov rax, [r15+0x40]
000079f9de5db9a4  movaps xmm1, [r15+0x1D0]
000079f9de5db9ac  vmovaps [rsp+0x10], xmm1
000079f9de5db9b2  vmovaps xmm15, [rsp+0x10]
000079f9de5db9b8  por xmm1, xmm15
000079f9de5db9bd  movaps xmm14, [r15+0x1A0]
000079f9de5db9c5  vmovaps [rsp+0x10], xmm14
000079f9de5db9cb  vmovaps xmm13, [rsp+0x10]
000079f9de5db9d1  por xmm14, xmm13
000079f9de5db9d6  lea r14, [rax+0x30]
000079f9de5db9da  mov r12, [r13+r14*1]
000079f9de5db9df  lea r14, [rax+0x38]
000079f9de5db9e3  mov r11, [r13+r14*1]
000079f9de5db9e8  movq xmm13, r12
000079f9de5db9ed  movq xmm12, r11
000079f9de5db9f2  movq xmm13, xmm13
000079f9de5db9f7  vmovaps [rsp+0x10], xmm13
000079f9de5db9fd  movq xmm13, xmm13
000079f9de5dba02  movaps [r15+0x130], xmm13
000079f9de5dba0a  movq xmm12, xmm12
000079f9de5dba0f  vmovaps [rsp+0x20], xmm12
000079f9de5dba15  movq xmm12, xmm12
000079f9de5dba1a  movaps [r15+0x280], xmm12
000079f9de5dba22  movaps xmm13, [r15+0x270]
000079f9de5dba2a  vmovaps [rsp+0x30], xmm13
000079f9de5dba30  vmovaps xmm12, [rsp+0x30]
000079f9de5dba36  por xmm13, xmm12
000079f9de5dba3b  lea r14, [rax+0x20]
000079f9de5dba3f  mov r12, [r13+r14*1]
000079f9de5dba44  lea r14, [rax+0x28]
000079f9de5dba48  mov r11, [r13+r14*1]
000079f9de5dba4d  movq xmm12, r12
000079f9de5dba52  movq xmm11, r11
000079f9de5dba57  movq xmm12, xmm12
000079f9de5dba5c  vmovaps [rsp+0x30], xmm12
000079f9de5dba62  movq xmm12, xmm12
000079f9de5dba67  movaps [r15+0x150], xmm12
000079f9de5dba6f  movq xmm11, xmm11
000079f9de5dba74  vmovaps [rsp+0x40], xmm11
000079f9de5dba7a  movq xmm11, xmm11
000079f9de5dba7f  movaps [r15+0x140], xmm11
000079f9de5dba87  lea r14, [rax+0x10]
000079f9de5dba8b  mov r12, [r13+r14*1]
000079f9de5dba90  lea r14, [rax+0x18]
000079f9de5dba94  mov r11, [r13+r14*1]
000079f9de5dba99  movq xmm12, r12
000079f9de5dba9e  movq xmm11, r11
000079f9de5dbaa3  movq xmm12, xmm12
000079f9de5dbaa8  vmovaps [rsp+0x50], xmm12
000079f9de5dbaae  movq xmm12, xmm12
000079f9de5dbab3  movaps [r15+0x170], xmm12
000079f9de5dbabb  movq xmm11, xmm11
000079f9de5dbac0  vmovaps [rsp+0x60], xmm11
000079f9de5dbac6  movq xmm11, xmm11
000079f9de5dbacb  movaps [r15+0x160], xmm11
000079f9de5dbad3  mov r14, [r13+rax*1]
000079f9de5dbad8  vmovq xmm12, r14
000079f9de5dbadd  vpbroadcastq xmm12, xmm12
000079f9de5dbae2  lea r14, [rax+0x08]
000079f9de5dbae6  mov rax, [r13+r14*1]
000079f9de5dbaeb  movq xmm11, rax
000079f9de5dbaf0  movaps [r15+0x230], xmm11
000079f9de5dbaf8  mov rax, [r15+0xF8]
000079f9de5dbaff  lea r14, [rax+0x50]
000079f9de5dbb03  movups xmm11, [r13+r14*1]
000079f9de5dbb09  lea r14, [rax+0x60]
000079f9de5dbb0d  movups xmm10, [r13+r14*1]
000079f9de5dbb13  lea r14, [rax+0x30]
000079f9de5dbb17  movups xmm9, [r13+r14*1]
000079f9de5dbb1d  mov r14, [r15+0x50]
000079f9de5dbb21  mov [r15+0x60], r14
000079f9de5dbb25  mov qword ptr [r15+0x58], 0x40
000079f9de5dbb2d  movaps xmm8, xmm12
000079f9de5dbb31  mulpd xmm8, xmm15
000079f9de5dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000079f9de5dbb3c  ptest xmm7, xmm7
000079f9de5dbb41  jnz 0x000079F9DE5DC96A
000079f9de5dbb47  movq xmm15, qword ptr [r15+0x230]
000079f9de5dbb50  vmovaps [rsp+0x70], xmm15
000079f9de5dbb56  vpermilpd xmm15, xmm15, 0x00
000079f9de5dbb5c  movaps xmm7, xmm9
000079f9de5dbb60  mulpd xmm7, xmm15
000079f9de5dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000079f9de5dbb6a  ptest xmm6, xmm6
000079f9de5dbb6f  jnz 0x000079F9DE5DCAAE
000079f9de5dbb75  vxorps xmm15, xmm15, xmm15
000079f9de5dbb7a  vpbroadcastq xmm15, xmm15
000079f9de5dbb7f  movaps xmm9, xmm12
000079f9de5dbb83  mulpd xmm9, xmm10
000079f9de5dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000079f9de5dbb8e  ptest xmm6, xmm6
000079f9de5dbb93  jnz 0x000079F9DE5DCBF0
000079f9de5dbb99  movaps xmm10, xmm12
000079f9de5dbb9d  mulpd xmm10, xmm11
000079f9de5dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000079f9de5dbba8  ptest xmm6, xmm6
000079f9de5dbbad  jnz 0x000079F9DE5DCD34
000079f9de5dbbb3  movaps xmm11, [r15+0x1F0]
000079f9de5dbbbb  movaps xmm6, xmm12
000079f9de5dbbbf  mulpd xmm6, xmm11
000079f9de5dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000079f9de5dbbc9  ptest xmm5, xmm5
000079f9de5dbbce  jnz 0x000079F9DE5DCE78
000079f9de5dbbd4  movaps xmm12, [r15+0x2A0]
000079f9de5dbbdc  vmovaps [rsp+0x80], xmm12
000079f9de5dbbe5  vmovaps xmm11, [rsp+0x80]
000079f9de5dbbee  por xmm12, xmm11
000079f9de5dbbf3  movaps xmm11, [r15+0x250]
000079f9de5dbbfb  vmovaps [rsp+0x80], xmm11
000079f9de5dbc04  vmovaps xmm5, [rsp+0x80]
000079f9de5dbc0d  por xmm11, xmm5
000079f9de5dbc12  vmovaps xmm4, [rsp+0x70]
000079f9de5dbc18  vpermilpd xmm4, xmm4, 0x00
000079f9de5dbc1e  movaps xmm3, xmm5
000079f9de5dbc21  mulpd xmm3, xmm4
000079f9de5dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000079f9de5dbc2a  ptest xmm2, xmm2
000079f9de5dbc2f  jnz 0x000079F9DE5DCFBA
000079f9de5dbc35  mov [rsp+0x80], rax
000079f9de5dbc3d  xor eax, eax
000079f9de5dbc3f  mov r12d, 0x40
000079f9de5dbc45  mov r11d, 0x200
000079f9de5dbc4b  cmp r12, r11
000079f9de5dbc4e  cmc
000079f9de5dbc4f  lahf
000079f9de5dbc50  seto al
000079f9de5dbc53  mov [r15+0x108], eax
000079f9de5dbc5a  movaps xmm5, xmm8
000079f9de5dbc5e  addpd xmm5, xmm15
000079f9de5dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000079f9de5dbc68  ptest xmm4, xmm4
000079f9de5dbc6d  jnz 0x000079F9DE5DD0FA
000079f9de5dbc73  movaps xmm8, [r15+0x1B0]
000079f9de5dbc7b  movaps xmm4, xmm9
000079f9de5dbc7f  addpd xmm4, xmm8
000079f9de5dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000079f9de5dbc89  ptest xmm2, xmm2
000079f9de5dbc8e  jnz 0x000079F9DE5DD23C
000079f9de5dbc94  movaps xmm9, xmm10
000079f9de5dbc98  addpd xmm9, xmm8
000079f9de5dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000079f9de5dbca3  ptest xmm2, xmm2
000079f9de5dbca8  jnz 0x000079F9DE5DD37E
000079f9de5dbcae  movaps xmm10, [r15+0x2F0]
000079f9de5dbcb6  vmovaps [rsp+0x90], xmm10
000079f9de5dbcbf  vmovaps xmm8, [rsp+0x90]
000079f9de5dbcc8  por xmm10, xmm8
000079f9de5dbccd  movaps xmm8, [r15+0x2E0]
000079f9de5dbcd5  vmovaps [rsp+0x90], xmm8
000079f9de5dbcde  vmovaps xmm2, [rsp+0x90]
000079f9de5dbce7  por xmm8, xmm2
000079f9de5dbcec  movaps xmm2, [r15+0x2D0]
000079f9de5dbcf4  vmovaps [rsp+0x90], xmm2
000079f9de5dbcfd  vmovaps [rsp+0xA0], xmm1
000079f9de5dbd06  vmovaps xmm1, [rsp+0x90]
000079f9de5dbd0f  por xmm2, xmm1
000079f9de5dbd13  movaps xmm1, [r15+0x200]
000079f9de5dbd1b  vmovaps [rsp+0x90], xmm1
000079f9de5dbd24  vmovaps [rsp+0xB0], xmm15
000079f9de5dbd2d  vmovaps xmm15, [rsp+0x90]
000079f9de5dbd36  por xmm1, xmm15
000079f9de5dbd3b  movaps xmm15, [r15+0x1C0]
000079f9de5dbd43  vmovaps [rsp+0x90], xmm15
000079f9de5dbd4c  vmovaps [rsp+0xC0], xmm1
000079f9de5dbd55  vmovaps xmm1, [rsp+0x90]
000079f9de5dbd5e  por xmm15, xmm1
000079f9de5dbd63  movaps xmm1, [r15+0x190]
000079f9de5dbd6b  vmovaps [rsp+0x90], xmm1
000079f9de5dbd74  vmovaps [rsp+0xD0], xmm15
000079f9de5dbd7d  vmovaps xmm15, [rsp+0x90]
000079f9de5dbd86  por xmm1, xmm15
000079f9de5dbd8b  movaps xmm15, [r15+0x300]
000079f9de5dbd93  vmovaps [rsp+0x90], xmm15
000079f9de5dbd9c  vmovaps [rsp+0xE0], xmm1
000079f9de5dbda5  vmovaps xmm1, [rsp+0x90]
000079f9de5dbdae  por xmm15, xmm1
000079f9de5dbdb3  mov rax, [rsp+0x80]
000079f9de5dbdbb  lea r12, [rax+0xA0]
000079f9de5dbdc2  movups xmm1, [r13+r12*1]
000079f9de5dbdc8  lea r12, [rax+0xB0]
000079f9de5dbdcf  vmovaps [rsp+0x80], xmm1
000079f9de5dbdd8  movups xmm1, [r13+r12*1]
000079f9de5dbdde  vmovaps [rsp+0x90], xmm1
000079f9de5dbde7  vmovaps [rsp+0xF0], xmm15
000079f9de5dbdf0  vmovaps xmm15, [rsp+0xB0]
000079f9de5dbdf9  vmovaps [rsp+0xB0], xmm14
000079f9de5dbe02  movaps xmm1, xmm6
000079f9de5dbe05  addpd xmm1, xmm15
000079f9de5dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000079f9de5dbe0f  ptest xmm14, xmm14
000079f9de5dbe15  jnz 0x000079F9DE5DD4D6
000079f9de5dbe1b  lea r12, [rax+0xF0]
000079f9de5dbe22  movups xmm15, [r13+r12*1]
000079f9de5dbe28  movaps xmm14, xmm4
000079f9de5dbe2c  addpd xmm14, xmm3
000079f9de5dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000079f9de5dbe37  ptest xmm6, xmm6
000079f9de5dbe3c  jnz 0x000079F9DE5DD621
000079f9de5dbe42  movaps xmm6, xmm9
000079f9de5dbe46  addpd xmm6, xmm7
000079f9de5dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000079f9de5dbe4f  ptest xmm4, xmm4
000079f9de5dbe54  jnz 0x000079F9DE5DD763
000079f9de5dbe5a  vmovaps xmm9, [rsp+0x70]
000079f9de5dbe60  vpermilpd xmm9, xmm9, 0x00
000079f9de5dbe66  vmovaps xmm4, [rsp+0x90]
000079f9de5dbe6f  movaps xmm7, xmm4
000079f9de5dbe72  mulpd xmm7, xmm9
000079f9de5dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000079f9de5dbe7c  ptest xmm3, xmm3
000079f9de5dbe81  jnz 0x000079F9DE5DD8A4
000079f9de5dbe87  vmovaps xmm9, [rsp+0x50]
000079f9de5dbe8d  vpermilpd xmm9, xmm9, 0x00
000079f9de5dbe93  movaps xmm4, xmm15
000079f9de5dbe97  mulpd xmm4, xmm9
000079f9de5dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000079f9de5dbea1  ptest xmm3, xmm3
000079f9de5dbea6  jnz 0x000079F9DE5DD9E5
000079f9de5dbeac  lea r12, [rax+0xE0]
000079f9de5dbeb3  movups xmm15, [r13+r12*1]
000079f9de5dbeb9  vmovaps xmm9, [rsp+0x70]
000079f9de5dbebf  vpermilpd xmm9, xmm9, 0x00
000079f9de5dbec5  vmovaps [rsp+0x70], xmm1
000079f9de5dbecb  vmovaps xmm1, [rsp+0x80]
000079f9de5dbed4  vmovaps [rsp+0x80], xmm15
000079f9de5dbedd  movaps xmm3, xmm1
000079f9de5dbee0  mulpd xmm3, xmm9
000079f9de5dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000079f9de5dbeea  ptest xmm15, xmm15
000079f9de5dbef0  jnz 0x000079F9DE5DDB31
000079f9de5dbef6  vmovaps xmm1, [rsp+0xF0]
000079f9de5dbeff  vmovaps xmm15, [rsp+0xF0]
000079f9de5dbf08  por xmm1, xmm15
000079f9de5dbf0d  movaps [r15+0x300], xmm1
000079f9de5dbf15  vmovaps xmm15, [rsp+0xE0]
000079f9de5dbf1e  vmovaps xmm9, [rsp+0xE0]
000079f9de5dbf27  por xmm15, xmm9
000079f9de5dbf2c  movaps [r15+0x190], xmm15
000079f9de5dbf34  vmovaps xmm9, [rsp+0x50]
000079f9de5dbf3a  vpermilpd xmm9, xmm9, 0x00
000079f9de5dbf40  vmovaps [rsp+0x90], xmm1
000079f9de5dbf49  vmovaps [rsp+0xE0], xmm15
000079f9de5dbf52  vmovaps xmm15, [rsp+0x80]
000079f9de5dbf5b  vmovaps [rsp+0x80], xmm14
000079f9de5dbf64  movaps xmm1, xmm15
000079f9de5dbf68  mulpd xmm1, xmm9
000079f9de5dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000079f9de5dbf72  ptest xmm14, xmm14
000079f9de5dbf78  jnz 0x000079F9DE5DDC72
000079f9de5dbf7e  lea r12, [rax+0x90]
000079f9de5dbf85  movups xmm15, [r13+r12*1]
000079f9de5dbf8b  vmovaps xmm14, [rsp+0xD0]
000079f9de5dbf94  vmovaps xmm9, [rsp+0xD0]
000079f9de5dbf9d  por xmm14, xmm9
000079f9de5dbfa2  movaps [r15+0x1C0], xmm14
000079f9de5dbfaa  vmovaps xmm9, [rsp+0xC0]
000079f9de5dbfb3  vmovaps [rsp+0xD0], xmm1
000079f9de5dbfbc  vmovaps xmm1, [rsp+0xC0]
000079f9de5dbfc5  por xmm9, xmm1
000079f9de5dbfca  movaps [r15+0x200], xmm9
000079f9de5dbfd2  vmovaps [rsp+0xC0], xmm2
000079f9de5dbfdb  vmovaps xmm1, [rsp+0xC0]
000079f9de5dbfe4  por xmm2, xmm1
000079f9de5dbfe8  movaps [r15+0x2D0], xmm2
000079f9de5dbff0  vmovaps [rsp+0xC0], xmm8
000079f9de5dbff9  vmovaps xmm1, [rsp+0xC0]
000079f9de5dc002  por xmm8, xmm1
000079f9de5dc007  movaps [r15+0x2E0], xmm8
000079f9de5dc00f  vmovaps [rsp+0xC0], xmm15
000079f9de5dc018  movaps xmm1, xmm5
000079f9de5dc01b  addpd xmm1, xmm7
000079f9de5dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000079f9de5dc024  ptest xmm15, xmm15
000079f9de5dc02a  jnz 0x000079F9DE5DDDBE
000079f9de5dc030  vmovaps xmm15, [rsp+0x50]
000079f9de5dc036  vpermilpd xmm15, xmm15, 0x00
000079f9de5dc03c  vmovaps xmm5, [rsp+0xC0]
000079f9de5dc045  vmovaps [rsp+0xC0], xmm1
000079f9de5dc04e  movaps xmm7, xmm5
000079f9de5dc051  mulpd xmm7, xmm15
000079f9de5dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000079f9de5dc05b  ptest xmm1, xmm1
000079f9de5dc060  jnz 0x000079F9DE5DDEFE
000079f9de5dc066  lea r12, [rax+0x80]
000079f9de5dc06d  movups xmm1, [r13+r12*1]
000079f9de5dc073  vmovaps xmm5, [rsp+0x70]
000079f9de5dc079  vmovaps [rsp+0x70], xmm1
000079f9de5dc07f  movaps xmm15, xmm5
000079f9de5dc083  addpd xmm15, xmm3
000079f9de5dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000079f9de5dc08e  ptest xmm1, xmm1
000079f9de5dc093  jnz 0x000079F9DE5DE049
000079f9de5dc099  vmovaps xmm5, [rsp+0x80]
000079f9de5dc0a2  movaps xmm1, xmm5
000079f9de5dc0a5  addpd xmm1, xmm4
000079f9de5dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000079f9de5dc0ae  ptest xmm3, xmm3
000079f9de5dc0b3  jnz 0x000079F9DE5DE18B
000079f9de5dc0b9  vmovaps [rsp+0x80], xmm10
000079f9de5dc0c2  vmovaps xmm5, [rsp+0x80]
000079f9de5dc0cb  por xmm10, xmm5
000079f9de5dc0d0  movaps [r15+0x2F0], xmm10
000079f9de5dc0d8  vmovaps xmm5, [rsp+0x50]
000079f9de5dc0de  vpermilpd xmm5, xmm5, 0x00
000079f9de5dc0e4  vmovaps xmm3, [rsp+0x70]
000079f9de5dc0ea  vmovaps [rsp+0x50], xmm1
000079f9de5dc0f0  movaps xmm4, xmm3
000079f9de5dc0f3  mulpd xmm4, xmm5
000079f9de5dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000079f9de5dc0fc  ptest xmm1, xmm1
000079f9de5dc101  jnz 0x000079F9DE5DE2CB
000079f9de5dc107  lea r12, [rax+0xD0]
000079f9de5dc10e  movups xmm1, [r13+r12*1]
000079f9de5dc114  vmovaps xmm3, [rsp+0xD0]
000079f9de5dc11d  vmovaps [rsp+0x70], xmm1
000079f9de5dc123  movaps xmm5, xmm6
000079f9de5dc126  addpd xmm5, xmm3
000079f9de5dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000079f9de5dc12f  ptest xmm1, xmm1
000079f9de5dc134  jnz 0x000079F9DE5DE415
000079f9de5dc13a  vmovaps xmm1, [rsp+0x60]
000079f9de5dc140  vpermilpd xmm1, xmm1, 0x00
000079f9de5dc146  movaps xmm6, xmm9
000079f9de5dc14a  mulpd xmm6, xmm1
000079f9de5dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000079f9de5dc153  ptest xmm3, xmm3
000079f9de5dc158  jnz 0x000079F9DE5DE555
000079f9de5dc15e  movaps [r15+0x260], xmm6
000079f9de5dc166  vxorps xmm1, xmm1, xmm1
000079f9de5dc16a  vpbroadcastq xmm1, xmm1
000079f9de5dc16f  movaps [r15+0x1B0], xmm1
000079f9de5dc177  vmovaps xmm1, [rsp+0x60]
000079f9de5dc17d  vpermilpd xmm1, xmm1, 0x00
000079f9de5dc183  vmovaps xmm3, [rsp+0x70]
000079f9de5dc189  vmovaps [rsp+0x70], xmm15
000079f9de5dc18f  movaps xmm9, xmm3
000079f9de5dc193  mulpd xmm9, xmm1
000079f9de5dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000079f9de5dc19e  ptest xmm15, xmm15
000079f9de5dc1a4  jnz 0x000079F9DE5DE696
000079f9de5dc1aa  lea r12, [rax+0xC0]
000079f9de5dc1b1  movups xmm1, [r13+r12*1]
000079f9de5dc1b7  vmovaps xmm3, [rsp+0xC0]
000079f9de5dc1c0  vmovaps [rsp+0x80], xmm1
000079f9de5dc1c9  movaps xmm15, xmm3
000079f9de5dc1cd  addpd xmm15, xmm7
000079f9de5dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000079f9de5dc1d8  ptest xmm1, xmm1
000079f9de5dc1dd  jnz 0x000079F9DE5DE7E2
000079f9de5dc1e3  vmovaps [rsp+0xC0], xmm13
000079f9de5dc1ec  vmovaps xmm1, [rsp+0xC0]
000079f9de5dc1f5  por xmm13, xmm1
000079f9de5dc1fa  movaps [r15+0x270], xmm13
000079f9de5dc202  vmovaps xmm1, [rsp+0xB0]
000079f9de5dc20b  vmovaps xmm7, [rsp+0xB0]
000079f9de5dc214  por xmm1, xmm7
000079f9de5dc218  movaps [r15+0x1A0], xmm1
000079f9de5dc220  vmovaps xmm1, [rsp+0x60]
000079f9de5dc226  vpermilpd xmm1, xmm1, 0x00
000079f9de5dc22c  vmovaps [rsp+0xB0], xmm1
000079f9de5dc235  vmovaps xmm1, [rsp+0x80]
000079f9de5dc23e  vmovaps [rsp+0x80], xmm15
000079f9de5dc247  vmovaps xmm15, [rsp+0xB0]
000079f9de5dc250  vmovaps [rsp+0xB0], xmm14
000079f9de5dc259  movaps xmm3, xmm1
000079f9de5dc25c  mulpd xmm3, xmm15
000079f9de5dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000079f9de5dc266  ptest xmm14, xmm14
000079f9de5dc26c  jnz 0x000079F9DE5DE924
000079f9de5dc272  lea r12, [rax+0x20]
000079f9de5dc276  movups xmm1, [r13+r12*1]
000079f9de5dc27c  movaps [r15+0x110], xmm1
000079f9de5dc284  vmovaps xmm14, [rsp+0x70]
000079f9de5dc28a  vmovaps [rsp+0x70], xmm1
000079f9de5dc290  movaps xmm15, xmm14
000079f9de5dc294  addpd xmm15, xmm4
000079f9de5dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000079f9de5dc29f  ptest xmm1, xmm1
000079f9de5dc2a4  jnz 0x000079F9DE5DEA6F
000079f9de5dc2aa  vmovaps xmm1, [rsp+0x60]
000079f9de5dc2b0  vpermilpd xmm1, xmm1, 0x00
000079f9de5dc2b6  movaps xmm14, xmm2
000079f9de5dc2ba  mulpd xmm14, xmm1
000079f9de5dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000079f9de5dc2c5  ptest xmm4, xmm4
000079f9de5dc2ca  jnz 0x000079F9DE5DEBB2
000079f9de5dc2d0  vmovaps xmm4, [rsp+0x50]
000079f9de5dc2d6  movaps xmm1, xmm4
000079f9de5dc2d9  addpd xmm1, xmm9
000079f9de5dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000079f9de5dc2e3  ptest xmm2, xmm2
000079f9de5dc2e8  jnz 0x000079F9DE5DECF4
000079f9de5dc2ee  vmovaps xmm9, [rsp+0x30]
000079f9de5dc2f4  vpermilpd xmm9, xmm9, 0x00
000079f9de5dc2fa  vmovaps xmm2, [rsp+0x70]
000079f9de5dc300  vmovaps [rsp+0x50], xmm1
000079f9de5dc306  movaps xmm4, xmm2
000079f9de5dc309  mulpd xmm4, xmm9
000079f9de5dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000079f9de5dc313  ptest xmm1, xmm1
000079f9de5dc318  jnz 0x000079F9DE5DEE35
000079f9de5dc31e  vmovaps xmm1, [rsp+0x30]
000079f9de5dc324  vpermilpd xmm1, xmm1, 0x00
000079f9de5dc32a  vmovaps xmm2, [rsp+0x90]
000079f9de5dc333  vmovaps [rsp+0x60], xmm15
000079f9de5dc339  movaps xmm9, xmm2
000079f9de5dc33d  mulpd xmm9, xmm1
000079f9de5dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000079f9de5dc348  ptest xmm15, xmm15
000079f9de5dc34e  jnz 0x000079F9DE5DEF76
000079f9de5dc354  vmovaps xmm15, [rsp+0x80]
000079f9de5dc35d  movaps xmm1, xmm15
000079f9de5dc361  addpd xmm1, xmm6
000079f9de5dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000079f9de5dc36a  ptest xmm2, xmm2
000079f9de5dc36f  jnz 0x000079F9DE5DF0B8
000079f9de5dc375  movaps xmm15, xmm5
000079f9de5dc379  addpd xmm15, xmm3
000079f9de5dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000079f9de5dc384  ptest xmm6, xmm6
000079f9de5dc389  jnz 0x000079F9DE5DF1F9
000079f9de5dc38f  vmovaps xmm6, [rsp+0x30]
000079f9de5dc395  vpermilpd xmm6, xmm6, 0x00
000079f9de5dc39b  movaps xmm5, xmm8
000079f9de5dc39f  mulpd xmm5, xmm6
000079f9de5dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000079f9de5dc3a8  ptest xmm3, xmm3
000079f9de5dc3ad  jnz 0x000079F9DE5DF33B
000079f9de5dc3b3  vmovaps xmm8, [rsp+0x30]
000079f9de5dc3b9  vpermilpd xmm8, xmm8, 0x00
000079f9de5dc3bf  movaps xmm6, xmm10
000079f9de5dc3c3  mulpd xmm6, xmm8
000079f9de5dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000079f9de5dc3cd  ptest xmm3, xmm3
000079f9de5dc3d2  jnz 0x000079F9DE5DF47C
000079f9de5dc3d8  vmovaps xmm8, [rsp+0x60]
000079f9de5dc3de  movaps xmm10, xmm8
000079f9de5dc3e2  addpd xmm10, xmm14
000079f9de5dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000079f9de5dc3ed  ptest xmm3, xmm3
000079f9de5dc3f2  jnz 0x000079F9DE5DF5BE
000079f9de5dc3f8  vmovaps xmm8, [rsp+0x50]
000079f9de5dc3fe  movaps xmm14, xmm8
000079f9de5dc402  addpd xmm14, xmm4
000079f9de5dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000079f9de5dc40d  ptest xmm3, xmm3
000079f9de5dc412  jnz 0x000079F9DE5DF702
000079f9de5dc418  vmovaps xmm8, [rsp+0x40]
000079f9de5dc41e  vpermilpd xmm8, xmm8, 0x00
000079f9de5dc424  movaps xmm4, xmm13
000079f9de5dc428  mulpd xmm4, xmm8
000079f9de5dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000079f9de5dc432  ptest xmm3, xmm3
000079f9de5dc437  jnz 0x000079F9DE5DF845
000079f9de5dc43d  movaps xmm13, xmm15
000079f9de5dc441  addpd xmm13, xmm9
000079f9de5dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000079f9de5dc44c  ptest xmm8, xmm8
000079f9de5dc452  jnz 0x000079F9DE5DF987
000079f9de5dc458  movaps xmm15, xmm1
000079f9de5dc45c  addpd xmm15, xmm5
000079f9de5dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000079f9de5dc467  ptest xmm9, xmm9
000079f9de5dc46d  jnz 0x000079F9DE5DFACB
000079f9de5dc473  vmovaps [rsp+0x30], xmm11
000079f9de5dc479  vmovaps xmm1, [rsp+0x30]
000079f9de5dc47f  por xmm11, xmm1
000079f9de5dc484  movaps [r15+0x250], xmm11
000079f9de5dc48c  vmovaps [rsp+0x30], xmm12
000079f9de5dc492  vmovaps xmm1, [rsp+0x30]
000079f9de5dc498  por xmm12, xmm1
000079f9de5dc49d  movaps [r15+0x2A0], xmm12
000079f9de5dc4a5  vmovaps xmm1, [rsp+0xA0]
000079f9de5dc4ae  vmovaps xmm11, [rsp+0xA0]
000079f9de5dc4b7  por xmm1, xmm11
000079f9de5dc4bc  movaps [r15+0x1D0], xmm1
000079f9de5dc4c4  lea r12, [rax+0x40]
000079f9de5dc4c8  movups xmm1, [r13+r12*1]
000079f9de5dc4ce  movaps [r15+0x2C0], xmm1
000079f9de5dc4d6  vmovaps xmm11, [rsp+0x40]
000079f9de5dc4dc  vpermilpd xmm11, xmm11, 0x00
000079f9de5dc4e2  vmovaps xmm8, [rsp+0xE0]
000079f9de5dc4eb  movaps xmm9, xmm8
000079f9de5dc4ef  mulpd xmm9, xmm11
000079f9de5dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000079f9de5dc4fa  ptest xmm5, xmm5
000079f9de5dc4ff  jnz 0x000079F9DE5DFC17
000079f9de5dc505  movaps xmm11, xmm10
000079f9de5dc509  addpd xmm11, xmm6
000079f9de5dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000079f9de5dc514  ptest xmm8, xmm8
000079f9de5dc51a  jnz 0x000079F9DE5DFD5B
000079f9de5dc520  movaps xmm10, xmm14
000079f9de5dc524  addpd xmm10, xmm4
000079f9de5dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000079f9de5dc52f  ptest xmm8, xmm8
000079f9de5dc535  jnz 0x000079F9DE5DFE9E
000079f9de5dc53b  vmovaps xmm14, [rsp+0x40]
000079f9de5dc541  vpermilpd xmm14, xmm14, 0x00
000079f9de5dc547  movaps xmm8, xmm1
000079f9de5dc54b  mulpd xmm8, xmm14
000079f9de5dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000079f9de5dc556  ptest xmm6, xmm6
000079f9de5dc55b  jnz 0x000079F9DE5DFFE1
000079f9de5dc561  movaps xmm1, [r15+0x2B0]
000079f9de5dc569  vmovaps xmm14, [rsp+0x40]
000079f9de5dc56f  vpermilpd xmm14, xmm14, 0x00
000079f9de5dc575  movaps xmm6, xmm1
000079f9de5dc578  mulpd xmm6, xmm14
000079f9de5dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000079f9de5dc582  ptest xmm5, xmm5
000079f9de5dc587  jnz 0x000079F9DE5E0124
000079f9de5dc58d  vmovaps xmm1, [rsp+0x10]
000079f9de5dc593  vpermilpd xmm1, xmm1, 0x00
000079f9de5dc599  movaps xmm14, xmm12
000079f9de5dc59d  mulpd xmm14, xmm1
000079f9de5dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000079f9de5dc5a8  ptest xmm5, xmm5
000079f9de5dc5ad  jnz 0x000079F9DE5E0265
000079f9de5dc5b3  movaps xmm1, xmm13
000079f9de5dc5b7  addpd xmm1, xmm9
000079f9de5dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000079f9de5dc5c1  ptest xmm12, xmm12
000079f9de5dc5c7  jnz 0x000079F9DE5E03A8
000079f9de5dc5cd  vmovaps xmm13, [rsp+0x10]
000079f9de5dc5d3  vpermilpd xmm13, xmm13, 0x00
000079f9de5dc5d9  movaps xmm12, xmm7
000079f9de5dc5dd  mulpd xmm12, xmm13
000079f9de5dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000079f9de5dc5e8  ptest xmm9, xmm9
000079f9de5dc5ee  jnz 0x000079F9DE5E04EA
000079f9de5dc5f4  movaps xmm13, xmm15
000079f9de5dc5f8  addpd xmm13, xmm8
000079f9de5dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000079f9de5dc603  ptest xmm9, xmm9
000079f9de5dc609  jnz 0x000079F9DE5E062D
000079f9de5dc60f  movaps xmm15, [r15+0x290]
000079f9de5dc617  vmovaps xmm9, [rsp+0x10]
000079f9de5dc61d  vpermilpd xmm9, xmm9, 0x00
000079f9de5dc623  movaps xmm8, xmm15
000079f9de5dc627  mulpd xmm8, xmm9
000079f9de5dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000079f9de5dc632  ptest xmm7, xmm7
000079f9de5dc637  jnz 0x000079F9DE5E0771
000079f9de5dc63d  movaps xmm15, xmm11
000079f9de5dc641  addpd xmm15, xmm6
000079f9de5dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000079f9de5dc64c  ptest xmm9, xmm9
000079f9de5dc652  jnz 0x000079F9DE5E08B5
000079f9de5dc658  movaps xmm11, [r15+0x1E0]
000079f9de5dc660  vmovaps xmm9, [rsp+0x10]
000079f9de5dc666  vpermilpd xmm9, xmm9, 0x00
000079f9de5dc66c  movaps xmm7, xmm11
000079f9de5dc670  mulpd xmm7, xmm9
000079f9de5dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000079f9de5dc67a  ptest xmm6, xmm6
000079f9de5dc67f  jnz 0x000079F9DE5E09F8
000079f9de5dc685  movaps xmm11, xmm10
000079f9de5dc689  addpd xmm11, xmm14
000079f9de5dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000079f9de5dc694  ptest xmm9, xmm9
000079f9de5dc69a  jnz 0x000079F9DE5E0B3A
000079f9de5dc6a0  lea r12, [rax+0x70]
000079f9de5dc6a4  movups xmm14, [r13+r12*1]
000079f9de5dc6aa  movaps [r15+0x240], xmm14
000079f9de5dc6b2  movaps xmm10, xmm1
000079f9de5dc6b6  addpd xmm10, xmm12
000079f9de5dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000079f9de5dc6c1  ptest xmm9, xmm9
000079f9de5dc6c7  jnz 0x000079F9DE5E0C88
000079f9de5dc6cd  movaps [r15+0x170], xmm10
000079f9de5dc6d5  vmovaps xmm1, [rsp+0x20]
000079f9de5dc6db  vpermilpd xmm1, xmm1, 0x00
000079f9de5dc6e1  movaps xmm12, xmm14
000079f9de5dc6e5  mulpd xmm12, xmm1
000079f9de5dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000079f9de5dc6f0  ptest xmm9, xmm9
000079f9de5dc6f6  jnz 0x000079F9DE5E0DCB
000079f9de5dc6fc  vmovaps xmm1, [rsp+0x20]
000079f9de5dc702  vpermilpd xmm1, xmm1, 0x00
000079f9de5dc708  vmovaps xmm9, [rsp+0xB0]
000079f9de5dc711  movaps xmm14, xmm9
000079f9de5dc715  mulpd xmm14, xmm1
000079f9de5dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000079f9de5dc720  ptest xmm6, xmm6
000079f9de5dc725  jnz 0x000079F9DE5E0F0E
000079f9de5dc72b  movaps [r15+0x180], xmm14
000079f9de5dc733  movaps xmm1, xmm13
000079f9de5dc737  addpd xmm1, xmm8
000079f9de5dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000079f9de5dc741  ptest xmm9, xmm9
000079f9de5dc747  jnz 0x000079F9DE5E1051
000079f9de5dc74d  movaps [r15+0x210], xmm1
000079f9de5dc755  movups xmm13, [r13+rax*1]
000079f9de5dc75b  lea r12, [rax+0x10]
000079f9de5dc75f  movups xmm9, [r13+r12*1]
000079f9de5dc765  movaps [r15+0x230], xmm9
000079f9de5dc76d  movaps xmm8, xmm15
000079f9de5dc771  addpd xmm8, xmm7
000079f9de5dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000079f9de5dc77c  ptest xmm6, xmm6
000079f9de5dc781  jnz 0x000079F9DE5E11A7
000079f9de5dc787  movaps [r15+0x130], xmm8
000079f9de5dc78f  vmovaps xmm15, [rsp+0x20]
000079f9de5dc795  vpermilpd xmm15, xmm15, 0x00
000079f9de5dc79b  movaps xmm7, xmm9
000079f9de5dc79f  mulpd xmm7, xmm15
000079f9de5dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000079f9de5dc7a9  ptest xmm6, xmm6
000079f9de5dc7ae  jnz 0x000079F9DE5E12EA
000079f9de5dc7b4  movaps [r15+0x220], xmm7
000079f9de5dc7bc  vmovaps xmm15, [rsp+0x20]
000079f9de5dc7c2  vpermilpd xmm15, xmm15, 0x00
000079f9de5dc7c8  movaps xmm9, xmm13
000079f9de5dc7cc  mulpd xmm9, xmm15
000079f9de5dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000079f9de5dc7d7  ptest xmm6, xmm6
000079f9de5dc7dc  jnz 0x000079F9DE5E142C
000079f9de5dc7e2  movaps xmm15, xmm11
000079f9de5dc7e6  addpd xmm15, xmm12
000079f9de5dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000079f9de5dc7f1  ptest xmm13, xmm13
000079f9de5dc7f7  jnz 0x000079F9DE5E1570
000079f9de5dc7fd  movaps [r15+0x140], xmm15
000079f9de5dc805  movaps xmm13, xmm10
000079f9de5dc809  addpd xmm13, xmm14
000079f9de5dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000079f9de5dc814  ptest xmm12, xmm12
000079f9de5dc81a  jnz 0x000079F9DE5E16B4
000079f9de5dc820  movaps [r15+0x150], xmm13
000079f9de5dc828  movaps xmm14, xmm1
000079f9de5dc82c  addpd xmm14, xmm7
000079f9de5dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000079f9de5dc837  ptest xmm12, xmm12
000079f9de5dc83d  jnz 0x000079F9DE5E17F8
000079f9de5dc843  movaps [r15+0x160], xmm14
000079f9de5dc84b  movaps xmm1, xmm8
000079f9de5dc84f  addpd xmm1, xmm9
000079f9de5dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000079f9de5dc859  ptest xmm12, xmm12
000079f9de5dc85f  jnz 0x000079F9DE5E193A
000079f9de5dc865  movaps [r15+0x120], xmm1
000079f9de5dc86d  movups [r13+r14*1], xmm15
000079f9de5dc873  lea rax, [r14+0x10]
000079f9de5dc877  movups [r13+rax*1], xmm13
000079f9de5dc87d  lea rax, [r14+0x20]
000079f9de5dc881  movups [r13+rax*1], xmm14
000079f9de5dc887  lea rax, [r14+0x30]
000079f9de5dc88b  movups [r13+rax*1], xmm1
000079f9de5dc891  mov eax, [r15+0x108]
000079f9de5dc898  sahf
000079f9de5dc899  jnz 0x000079F9DE5DC8CB
000079f9de5dc89b  cmp dword ptr [r15+0x318], 0x00
000079f9de5dc8a3  jz 0x000079F9DE5DB900
000079f9de5dc8a9  nop [rax+rax*1], ax
000079f9de5dc8b2  nop [rax+rax*1], eax
000079f9de5dc8ba  mov eax, 0x410444
000079f9de5dc8bf  mov [r15+0x100], rax
000079f9de5dc8c6  jmp 0x000079F9DE3FE110
000079f9de5dc8cb  cmp dword ptr [r15+0x318], 0x00
000079f9de5dc8d3  jz 0x000079F9DE5D57E0
000079f9de5dc8d9  nop [rax+rax*1], ax
000079f9de5dc8e2  nop [rax+rax*1], eax
000079f9de5dc8ea  mov eax, 0x410278
000079f9de5dc8ef  mov [r15+0x100], rax
000079f9de5dc8f6  jmp 0x000079F9DE3FE110
000079f9de5dc8fb  int3
000079f9de5dc8fc  call 0x000079F9DE4E27E0
000079f9de5dc901  jmp 0x000079F9DE5DB9DF
000079f9de5dc906  call 0x000079F9DE4E1570
000079f9de5dc90b  jmp 0x000079F9DE5DB9E8
000079f9de5dc910  call 0x000079F9DE4E27E0
000079f9de5dc915  jmp 0x000079F9DE5DBA44
000079f9de5dc91a  call 0x000079F9DE4E1570
000079f9de5dc91f  jmp 0x000079F9DE5DBA4D
000079f9de5dc924  call 0x000079F9DE4E27E0
000079f9de5dc929  jmp 0x000079F9DE5DBA90
000079f9de5dc92e  call 0x000079F9DE4E1570
000079f9de5dc933  jmp 0x000079F9DE5DBA99
000079f9de5dc938  call 0x000079F9DE40DC20
000079f9de5dc93d  jmp 0x000079F9DE5DBAD8
000079f9de5dc942  call 0x000079F9DE4D59C0
000079f9de5dc947  jmp 0x000079F9DE5DBAEB
000079f9de5dc94c  call 0x000079F9DE4E0E30
000079f9de5dc951  jmp 0x000079F9DE5DBB09
000079f9de5dc956  call 0x000079F9DE4DFBC0
000079f9de5dc95b  jmp 0x000079F9DE5DBB13
000079f9de5dc960  call 0x000079F9DE4DE950
000079f9de5dc965  jmp 0x000079F9DE5DBB1D
000079f9de5dc96a  sub rsp, 0x08
000079f9de5dc96e  push rax
000079f9de5dc96f  push rcx
000079f9de5dc970  push rdx
000079f9de5dc971  push rdi
000079f9de5dc972  push rsi
000079f9de5dc973  push r8
000079f9de5dc975  push r9
000079f9de5dc977  push r10
000079f9de5dc979  push r11
000079f9de5dc97b  sub rsp, 0xF0
000079f9de5dc982  vmovaps [rsp], xmm0
000079f9de5dc987  vmovaps [rsp+0x10], xmm1
000079f9de5dc98d  vmovaps [rsp+0x20], xmm2
000079f9de5dc993  vmovaps [rsp+0x30], xmm3
000079f9de5dc999  vmovaps [rsp+0x40], xmm4
000079f9de5dc99f  vmovaps [rsp+0x50], xmm5
000079f9de5dc9a5  vmovaps [rsp+0x60], xmm6
000079f9de5dc9ab  vmovaps [rsp+0x70], xmm7
000079f9de5dc9b1  vmovaps [rsp+0x80], xmm9
000079f9de5dc9ba  vmovaps [rsp+0x90], xmm10
000079f9de5dc9c3  vmovaps [rsp+0xA0], xmm11
000079f9de5dc9cc  vmovaps [rsp+0xB0], xmm12
000079f9de5dc9d5  vmovaps [rsp+0xC0], xmm13
000079f9de5dc9de  vmovaps [rsp+0xD0], xmm14
000079f9de5dc9e7  vmovaps [rsp+0xE0], xmm15
000079f9de5dc9f0  sub rsp, 0x30
000079f9de5dc9f4  movaps [rsp], xmm8
000079f9de5dc9f9  movaps [rsp+0x10], xmm12
000079f9de5dc9ff  movaps [rsp+0x20], xmm15
000079f9de5dca05  lea rdi, [rsp]
000079f9de5dca09  mov esi, 0x00
000079f9de5dca0e  mov rax, 0x56D56FF59530
000079f9de5dca18  call rax
000079f9de5dca1a  movaps xmm8, [rsp]
000079f9de5dca1f  add rsp, 0x30
000079f9de5dca23  vmovaps xmm0, [rsp]
000079f9de5dca28  vmovaps xmm1, [rsp+0x10]
000079f9de5dca2e  vmovaps xmm2, [rsp+0x20]
000079f9de5dca34  vmovaps xmm3, [rsp+0x30]
000079f9de5dca3a  vmovaps xmm4, [rsp+0x40]
000079f9de5dca40  vmovaps xmm5, [rsp+0x50]
000079f9de5dca46  vmovaps xmm6, [rsp+0x60]
000079f9de5dca4c  vmovaps xmm7, [rsp+0x70]
000079f9de5dca52  vmovaps xmm9, [rsp+0x80]
000079f9de5dca5b  vmovaps xmm10, [rsp+0x90]
000079f9de5dca64  vmovaps xmm11, [rsp+0xA0]
000079f9de5dca6d  vmovaps xmm12, [rsp+0xB0]
000079f9de5dca76  vmovaps xmm13, [rsp+0xC0]
000079f9de5dca7f  vmovaps xmm14, [rsp+0xD0]
000079f9de5dca88  vmovaps xmm15, [rsp+0xE0]
000079f9de5dca91  add rsp, 0xF0
000079f9de5dca98  pop r11
000079f9de5dca9a  pop r10
000079f9de5dca9c  pop r9
000079f9de5dca9e  pop r8
000079f9de5dcaa0  pop rsi
000079f9de5dcaa1  pop rdi
000079f9de5dcaa2  pop rdx
000079f9de5dcaa3  pop rcx
000079f9de5dcaa4  pop rax
000079f9de5dcaa5  add rsp, 0x08
000079f9de5dcaa9  jmp 0x000079F9DE5DBB47
000079f9de5dcaae  sub rsp, 0x08
000079f9de5dcab2  push rax
000079f9de5dcab3  push rcx
000079f9de5dcab4  push rdx
000079f9de5dcab5  push rdi
000079f9de5dcab6  push rsi
000079f9de5dcab7  push r8
000079f9de5dcab9  push r9
000079f9de5dcabb  push r10
000079f9de5dcabd  push r11
000079f9de5dcabf  sub rsp, 0xF0
000079f9de5dcac6  vmovaps [rsp], xmm0
000079f9de5dcacb  vmovaps [rsp+0x10], xmm1
000079f9de5dcad1  vmovaps [rsp+0x20], xmm2
000079f9de5dcad7  vmovaps [rsp+0x30], xmm3
000079f9de5dcadd  vmovaps [rsp+0x40], xmm4
000079f9de5dcae3  vmovaps [rsp+0x50], xmm5
000079f9de5dcae9  vmovaps [rsp+0x60], xmm6
000079f9de5dcaef  vmovaps [rsp+0x70], xmm8
000079f9de5dcaf5  vmovaps [rsp+0x80], xmm9
000079f9de5dcafe  vmovaps [rsp+0x90], xmm10
000079f9de5dcb07  vmovaps [rsp+0xA0], xmm11
000079f9de5dcb10  vmovaps [rsp+0xB0], xmm12
000079f9de5dcb19  vmovaps [rsp+0xC0], xmm13
000079f9de5dcb22  vmovaps [rsp+0xD0], xmm14
000079f9de5dcb2b  vmovaps [rsp+0xE0], xmm15
000079f9de5dcb34  sub rsp, 0x30
000079f9de5dcb38  movaps [rsp], xmm7
000079f9de5dcb3c  movaps [rsp+0x10], xmm9
000079f9de5dcb42  movaps [rsp+0x20], xmm15
000079f9de5dcb48  lea rdi, [rsp]
000079f9de5dcb4c  mov esi, 0x00
000079f9de5dcb51  mov rax, 0x56D56FF59530
000079f9de5dcb5b  call rax
000079f9de5dcb5d  movaps xmm7, [rsp]
000079f9de5dcb61  add rsp, 0x30
000079f9de5dcb65  vmovaps xmm0, [rsp]
000079f9de5dcb6a  vmovaps xmm1, [rsp+0x10]
000079f9de5dcb70  vmovaps xmm2, [rsp+0x20]
000079f9de5dcb76  vmovaps xmm3, [rsp+0x30]
000079f9de5dcb7c  vmovaps xmm4, [rsp+0x40]
000079f9de5dcb82  vmovaps xmm5, [rsp+0x50]
000079f9de5dcb88  vmovaps xmm6, [rsp+0x60]
000079f9de5dcb8e  vmovaps xmm8, [rsp+0x70]
000079f9de5dcb94  vmovaps xmm9, [rsp+0x80]
000079f9de5dcb9d  vmovaps xmm10, [rsp+0x90]
000079f9de5dcba6  vmovaps xmm11, [rsp+0xA0]
000079f9de5dcbaf  vmovaps xmm12, [rsp+0xB0]
000079f9de5dcbb8  vmovaps xmm13, [rsp+0xC0]
000079f9de5dcbc1  vmovaps xmm14, [rsp+0xD0]
000079f9de5dcbca  vmovaps xmm15, [rsp+0xE0]
000079f9de5dcbd3  add rsp, 0xF0
000079f9de5dcbda  pop r11
000079f9de5dcbdc  pop r10
000079f9de5dcbde  pop r9
000079f9de5dcbe0  pop r8
000079f9de5dcbe2  pop rsi
000079f9de5dcbe3  pop rdi
000079f9de5dcbe4  pop rdx
000079f9de5dcbe5  pop rcx
000079f9de5dcbe6  pop rax
000079f9de5dcbe7  add rsp, 0x08
000079f9de5dcbeb  jmp 0x000079F9DE5DBB75
000079f9de5dcbf0  sub rsp, 0x08
000079f9de5dcbf4  push rax
000079f9de5dcbf5  push rcx
000079f9de5dcbf6  push rdx
000079f9de5dcbf7  push rdi
000079f9de5dcbf8  push rsi
000079f9de5dcbf9  push r8
000079f9de5dcbfb  push r9
000079f9de5dcbfd  push r10
000079f9de5dcbff  push r11
000079f9de5dcc01  sub rsp, 0xF0
000079f9de5dcc08  vmovaps [rsp], xmm0
000079f9de5dcc0d  vmovaps [rsp+0x10], xmm1
000079f9de5dcc13  vmovaps [rsp+0x20], xmm2
000079f9de5dcc19  vmovaps [rsp+0x30], xmm3
000079f9de5dcc1f  vmovaps [rsp+0x40], xmm4
000079f9de5dcc25  vmovaps [rsp+0x50], xmm5
000079f9de5dcc2b  vmovaps [rsp+0x60], xmm6
000079f9de5dcc31  vmovaps [rsp+0x70], xmm7
000079f9de5dcc37  vmovaps [rsp+0x80], xmm8
000079f9de5dcc40  vmovaps [rsp+0x90], xmm10
000079f9de5dcc49  vmovaps [rsp+0xA0], xmm11
000079f9de5dcc52  vmovaps [rsp+0xB0], xmm12
000079f9de5dcc5b  vmovaps [rsp+0xC0], xmm13
000079f9de5dcc64  vmovaps [rsp+0xD0], xmm14
000079f9de5dcc6d  vmovaps [rsp+0xE0], xmm15
000079f9de5dcc76  sub rsp, 0x30
000079f9de5dcc7a  movaps [rsp], xmm9
000079f9de5dcc7f  movaps [rsp+0x10], xmm12
000079f9de5dcc85  movaps [rsp+0x20], xmm10
000079f9de5dcc8b  lea rdi, [rsp]
000079f9de5dcc8f  mov esi, 0x00
000079f9de5dcc94  mov rax, 0x56D56FF59530
000079f9de5dcc9e  call rax
000079f9de5dcca0  movaps xmm9, [rsp]
000079f9de5dcca5  add rsp, 0x30
000079f9de5dcca9  vmovaps xmm0, [rsp]
000079f9de5dccae  vmovaps xmm1, [rsp+0x10]
000079f9de5dccb4  vmovaps xmm2, [rsp+0x20]
000079f9de5dccba  vmovaps xmm3, [rsp+0x30]
000079f9de5dccc0  vmovaps xmm4, [rsp+0x40]
000079f9de5dccc6  vmovaps xmm5, [rsp+0x50]
000079f9de5dcccc  vmovaps xmm6, [rsp+0x60]
000079f9de5dccd2  vmovaps xmm7, [rsp+0x70]
000079f9de5dccd8  vmovaps xmm8, [rsp+0x80]
000079f9de5dcce1  vmovaps xmm10, [rsp+0x90]
000079f9de5dccea  vmovaps xmm11, [rsp+0xA0]
000079f9de5dccf3  vmovaps xmm12, [rsp+0xB0]
000079f9de5dccfc  vmovaps xmm13, [rsp+0xC0]
000079f9de5dcd05  vmovaps xmm14, [rsp+0xD0]
000079f9de5dcd0e  vmovaps xmm15, [rsp+0xE0]
000079f9de5dcd17  add rsp, 0xF0
000079f9de5dcd1e  pop r11
000079f9de5dcd20  pop r10
000079f9de5dcd22  pop r9
000079f9de5dcd24  pop r8
000079f9de5dcd26  pop rsi
000079f9de5dcd27  pop rdi
000079f9de5dcd28  pop rdx
000079f9de5dcd29  pop rcx
000079f9de5dcd2a  pop rax
000079f9de5dcd2b  add rsp, 0x08
000079f9de5dcd2f  jmp 0x000079F9DE5DBB99
000079f9de5dcd34  sub rsp, 0x08
000079f9de5dcd38  push rax
000079f9de5dcd39  push rcx
000079f9de5dcd3a  push rdx
000079f9de5dcd3b  push rdi
000079f9de5dcd3c  push rsi
000079f9de5dcd3d  push r8
000079f9de5dcd3f  push r9
000079f9de5dcd41  push r10
000079f9de5dcd43  push r11
000079f9de5dcd45  sub rsp, 0xF0
000079f9de5dcd4c  vmovaps [rsp], xmm0
000079f9de5dcd51  vmovaps [rsp+0x10], xmm1
000079f9de5dcd57  vmovaps [rsp+0x20], xmm2
000079f9de5dcd5d  vmovaps [rsp+0x30], xmm3
000079f9de5dcd63  vmovaps [rsp+0x40], xmm4
000079f9de5dcd69  vmovaps [rsp+0x50], xmm5
000079f9de5dcd6f  vmovaps [rsp+0x60], xmm6
000079f9de5dcd75  vmovaps [rsp+0x70], xmm7
000079f9de5dcd7b  vmovaps [rsp+0x80], xmm8
000079f9de5dcd84  vmovaps [rsp+0x90], xmm9
000079f9de5dcd8d  vmovaps [rsp+0xA0], xmm11
000079f9de5dcd96  vmovaps [rsp+0xB0], xmm12
000079f9de5dcd9f  vmovaps [rsp+0xC0], xmm13
000079f9de5dcda8  vmovaps [rsp+0xD0], xmm14
000079f9de5dcdb1  vmovaps [rsp+0xE0], xmm15
000079f9de5dcdba  sub rsp, 0x30
000079f9de5dcdbe  movaps [rsp], xmm10
000079f9de5dcdc3  movaps [rsp+0x10], xmm12
000079f9de5dcdc9  movaps [rsp+0x20], xmm11
000079f9de5dcdcf  lea rdi, [rsp]
000079f9de5dcdd3  mov esi, 0x00
000079f9de5dcdd8  mov rax, 0x56D56FF59530
000079f9de5dcde2  call rax
000079f9de5dcde4  movaps xmm10, [rsp]
000079f9de5dcde9  add rsp, 0x30
000079f9de5dcded  vmovaps xmm0, [rsp]
000079f9de5dcdf2  vmovaps xmm1, [rsp+0x10]
000079f9de5dcdf8  vmovaps xmm2, [rsp+0x20]
000079f9de5dcdfe  vmovaps xmm3, [rsp+0x30]
000079f9de5dce04  vmovaps xmm4, [rsp+0x40]
000079f9de5dce0a  vmovaps xmm5, [rsp+0x50]
000079f9de5dce10  vmovaps xmm6, [rsp+0x60]
000079f9de5dce16  vmovaps xmm7, [rsp+0x70]
000079f9de5dce1c  vmovaps xmm8, [rsp+0x80]
000079f9de5dce25  vmovaps xmm9, [rsp+0x90]
000079f9de5dce2e  vmovaps xmm11, [rsp+0xA0]
000079f9de5dce37  vmovaps xmm12, [rsp+0xB0]
000079f9de5dce40  vmovaps xmm13, [rsp+0xC0]
000079f9de5dce49  vmovaps xmm14, [rsp+0xD0]
000079f9de5dce52  vmovaps xmm15, [rsp+0xE0]
000079f9de5dce5b  add rsp, 0xF0
000079f9de5dce62  pop r11
000079f9de5dce64  pop r10
000079f9de5dce66  pop r9
000079f9de5dce68  pop r8
000079f9de5dce6a  pop rsi
000079f9de5dce6b  pop rdi
000079f9de5dce6c  pop rdx
000079f9de5dce6d  pop rcx
000079f9de5dce6e  pop rax
000079f9de5dce6f  add rsp, 0x08
000079f9de5dce73  jmp 0x000079F9DE5DBBB3
000079f9de5dce78  sub rsp, 0x08
000079f9de5dce7c  push rax
000079f9de5dce7d  push rcx
000079f9de5dce7e  push rdx
000079f9de5dce7f  push rdi
000079f9de5dce80  push rsi
000079f9de5dce81  push r8
000079f9de5dce83  push r9
000079f9de5dce85  push r10
000079f9de5dce87  push r11
000079f9de5dce89  sub rsp, 0xF0
000079f9de5dce90  vmovaps [rsp], xmm0
000079f9de5dce95  vmovaps [rsp+0x10], xmm1
000079f9de5dce9b  vmovaps [rsp+0x20], xmm2
000079f9de5dcea1  vmovaps [rsp+0x30], xmm3
000079f9de5dcea7  vmovaps [rsp+0x40], xmm4
000079f9de5dcead  vmovaps [rsp+0x50], xmm5
000079f9de5dceb3  vmovaps [rsp+0x60], xmm7
000079f9de5dceb9  vmovaps [rsp+0x70], xmm8
000079f9de5dcebf  vmovaps [rsp+0x80], xmm9
000079f9de5dcec8  vmovaps [rsp+0x90], xmm10
000079f9de5dced1  vmovaps [rsp+0xA0], xmm11
000079f9de5dceda  vmovaps [rsp+0xB0], xmm12
000079f9de5dcee3  vmovaps [rsp+0xC0], xmm13
000079f9de5dceec  vmovaps [rsp+0xD0], xmm14
000079f9de5dcef5  vmovaps [rsp+0xE0], xmm15
000079f9de5dcefe  sub rsp, 0x30
000079f9de5dcf02  movaps [rsp], xmm6
000079f9de5dcf06  movaps [rsp+0x10], xmm12
000079f9de5dcf0c  movaps [rsp+0x20], xmm11
000079f9de5dcf12  lea rdi, [rsp]
000079f9de5dcf16  mov esi, 0x00
000079f9de5dcf1b  mov rax, 0x56D56FF59530
000079f9de5dcf25  call rax
000079f9de5dcf27  movaps xmm6, [rsp]
000079f9de5dcf2b  add rsp, 0x30
000079f9de5dcf2f  vmovaps xmm0, [rsp]
000079f9de5dcf34  vmovaps xmm1, [rsp+0x10]
000079f9de5dcf3a  vmovaps xmm2, [rsp+0x20]
000079f9de5dcf40  vmovaps xmm3, [rsp+0x30]
000079f9de5dcf46  vmovaps xmm4, [rsp+0x40]
000079f9de5dcf4c  vmovaps xmm5, [rsp+0x50]
000079f9de5dcf52  vmovaps xmm7, [rsp+0x60]
000079f9de5dcf58  vmovaps xmm8, [rsp+0x70]
000079f9de5dcf5e  vmovaps xmm9, [rsp+0x80]
000079f9de5dcf67  vmovaps xmm10, [rsp+0x90]
000079f9de5dcf70  vmovaps xmm11, [rsp+0xA0]
000079f9de5dcf79  vmovaps xmm12, [rsp+0xB0]
000079f9de5dcf82  vmovaps xmm13, [rsp+0xC0]
000079f9de5dcf8b  vmovaps xmm14, [rsp+0xD0]
000079f9de5dcf94  vmovaps xmm15, [rsp+0xE0]
000079f9de5dcf9d  add rsp, 0xF0
000079f9de5dcfa4  pop r11
000079f9de5dcfa6  pop r10
000079f9de5dcfa8  pop r9
000079f9de5dcfaa  pop r8
000079f9de5dcfac  pop rsi
000079f9de5dcfad  pop rdi
000079f9de5dcfae  pop rdx
000079f9de5dcfaf  pop rcx
000079f9de5dcfb0  pop rax
000079f9de5dcfb1  add rsp, 0x08
000079f9de5dcfb5  jmp 0x000079F9DE5DBBD4
000079f9de5dcfba  sub rsp, 0x08
000079f9de5dcfbe  push rax
000079f9de5dcfbf  push rcx
000079f9de5dcfc0  push rdx
000079f9de5dcfc1  push rdi
000079f9de5dcfc2  push rsi
000079f9de5dcfc3  push r8
000079f9de5dcfc5  push r9
000079f9de5dcfc7  push r10
000079f9de5dcfc9  push r11
000079f9de5dcfcb  sub rsp, 0xF0
000079f9de5dcfd2  vmovaps [rsp], xmm0
000079f9de5dcfd7  vmovaps [rsp+0x10], xmm1
000079f9de5dcfdd  vmovaps [rsp+0x20], xmm2
000079f9de5dcfe3  vmovaps [rsp+0x30], xmm4
000079f9de5dcfe9  vmovaps [rsp+0x40], xmm5
000079f9de5dcfef  vmovaps [rsp+0x50], xmm6
000079f9de5dcff5  vmovaps [rsp+0x60], xmm7
000079f9de5dcffb  vmovaps [rsp+0x70], xmm8
000079f9de5dd001  vmovaps [rsp+0x80], xmm9
000079f9de5dd00a  vmovaps [rsp+0x90], xmm10
000079f9de5dd013  vmovaps [rsp+0xA0], xmm11
000079f9de5dd01c  vmovaps [rsp+0xB0], xmm12
000079f9de5dd025  vmovaps [rsp+0xC0], xmm13
000079f9de5dd02e  vmovaps [rsp+0xD0], xmm14
000079f9de5dd037  vmovaps [rsp+0xE0], xmm15
000079f9de5dd040  sub rsp, 0x30
000079f9de5dd044  movaps [rsp], xmm3
000079f9de5dd048  movaps [rsp+0x10], xmm5
000079f9de5dd04d  movaps [rsp+0x20], xmm4
000079f9de5dd052  lea rdi, [rsp]
000079f9de5dd056  mov esi, 0x00
000079f9de5dd05b  mov rax, 0x56D56FF59530
000079f9de5dd065  call rax
000079f9de5dd067  movaps xmm3, [rsp]
000079f9de5dd06b  add rsp, 0x30
000079f9de5dd06f  vmovaps xmm0, [rsp]
000079f9de5dd074  vmovaps xmm1, [rsp+0x10]
000079f9de5dd07a  vmovaps xmm2, [rsp+0x20]
000079f9de5dd080  vmovaps xmm4, [rsp+0x30]
000079f9de5dd086  vmovaps xmm5, [rsp+0x40]
000079f9de5dd08c  vmovaps xmm6, [rsp+0x50]
000079f9de5dd092  vmovaps xmm7, [rsp+0x60]
000079f9de5dd098  vmovaps xmm8, [rsp+0x70]
000079f9de5dd09e  vmovaps xmm9, [rsp+0x80]
000079f9de5dd0a7  vmovaps xmm10, [rsp+0x90]
000079f9de5dd0b0  vmovaps xmm11, [rsp+0xA0]
000079f9de5dd0b9  vmovaps xmm12, [rsp+0xB0]
000079f9de5dd0c2  vmovaps xmm13, [rsp+0xC0]
000079f9de5dd0cb  vmovaps xmm14, [rsp+0xD0]
000079f9de5dd0d4  vmovaps xmm15, [rsp+0xE0]
000079f9de5dd0dd  add rsp, 0xF0
000079f9de5dd0e4  pop r11
000079f9de5dd0e6  pop r10
000079f9de5dd0e8  pop r9
000079f9de5dd0ea  pop r8
000079f9de5dd0ec  pop rsi
000079f9de5dd0ed  pop rdi
000079f9de5dd0ee  pop rdx
000079f9de5dd0ef  pop rcx
000079f9de5dd0f0  pop rax
000079f9de5dd0f1  add rsp, 0x08
000079f9de5dd0f5  jmp 0x000079F9DE5DBC35
000079f9de5dd0fa  sub rsp, 0x08
000079f9de5dd0fe  push rax
000079f9de5dd0ff  push rcx
000079f9de5dd100  push rdx
000079f9de5dd101  push rdi
000079f9de5dd102  push rsi
000079f9de5dd103  push r8
000079f9de5dd105  push r9
000079f9de5dd107  push r10
000079f9de5dd109  push r11
000079f9de5dd10b  sub rsp, 0xF0
000079f9de5dd112  vmovaps [rsp], xmm0
000079f9de5dd117  vmovaps [rsp+0x10], xmm1
000079f9de5dd11d  vmovaps [rsp+0x20], xmm2
000079f9de5dd123  vmovaps [rsp+0x30], xmm3
000079f9de5dd129  vmovaps [rsp+0x40], xmm4
000079f9de5dd12f  vmovaps [rsp+0x50], xmm6
000079f9de5dd135  vmovaps [rsp+0x60], xmm7
000079f9de5dd13b  vmovaps [rsp+0x70], xmm8
000079f9de5dd141  vmovaps [rsp+0x80], xmm9
000079f9de5dd14a  vmovaps [rsp+0x90], xmm10
000079f9de5dd153  vmovaps [rsp+0xA0], xmm11
000079f9de5dd15c  vmovaps [rsp+0xB0], xmm12
000079f9de5dd165  vmovaps [rsp+0xC0], xmm13
000079f9de5dd16e  vmovaps [rsp+0xD0], xmm14
000079f9de5dd177  vmovaps [rsp+0xE0], xmm15
000079f9de5dd180  sub rsp, 0x30
000079f9de5dd184  movaps [rsp], xmm5
000079f9de5dd188  movaps [rsp+0x10], xmm8
000079f9de5dd18e  movaps [rsp+0x20], xmm15
000079f9de5dd194  lea rdi, [rsp]
000079f9de5dd198  mov esi, 0x00
000079f9de5dd19d  mov rax, 0x56D56FF59530
000079f9de5dd1a7  call rax
000079f9de5dd1a9  movaps xmm5, [rsp]
000079f9de5dd1ad  add rsp, 0x30
000079f9de5dd1b1  vmovaps xmm0, [rsp]
000079f9de5dd1b6  vmovaps xmm1, [rsp+0x10]
000079f9de5dd1bc  vmovaps xmm2, [rsp+0x20]
000079f9de5dd1c2  vmovaps xmm3, [rsp+0x30]
000079f9de5dd1c8  vmovaps xmm4, [rsp+0x40]
000079f9de5dd1ce  vmovaps xmm6, [rsp+0x50]
000079f9de5dd1d4  vmovaps xmm7, [rsp+0x60]
000079f9de5dd1da  vmovaps xmm8, [rsp+0x70]
000079f9de5dd1e0  vmovaps xmm9, [rsp+0x80]
000079f9de5dd1e9  vmovaps xmm10, [rsp+0x90]
000079f9de5dd1f2  vmovaps xmm11, [rsp+0xA0]
000079f9de5dd1fb  vmovaps xmm12, [rsp+0xB0]
000079f9de5dd204  vmovaps xmm13, [rsp+0xC0]
000079f9de5dd20d  vmovaps xmm14, [rsp+0xD0]
000079f9de5dd216  vmovaps xmm15, [rsp+0xE0]
000079f9de5dd21f  add rsp, 0xF0
000079f9de5dd226  pop r11
000079f9de5dd228  pop r10
000079f9de5dd22a  pop r9
000079f9de5dd22c  pop r8
000079f9de5dd22e  pop rsi
000079f9de5dd22f  pop rdi
000079f9de5dd230  pop rdx
000079f9de5dd231  pop rcx
000079f9de5dd232  pop rax
000079f9de5dd233  add rsp, 0x08
000079f9de5dd237  jmp 0x000079F9DE5DBC73
000079f9de5dd23c  sub rsp, 0x08
000079f9de5dd240  push rax
000079f9de5dd241  push rcx
000079f9de5dd242  push rdx
000079f9de5dd243  push rdi
000079f9de5dd244  push rsi
000079f9de5dd245  push r8
000079f9de5dd247  push r9
000079f9de5dd249  push r10
000079f9de5dd24b  push r11
000079f9de5dd24d  sub rsp, 0xF0
000079f9de5dd254  vmovaps [rsp], xmm0
000079f9de5dd259  vmovaps [rsp+0x10], xmm1
000079f9de5dd25f  vmovaps [rsp+0x20], xmm2
000079f9de5dd265  vmovaps [rsp+0x30], xmm3
000079f9de5dd26b  vmovaps [rsp+0x40], xmm5
000079f9de5dd271  vmovaps [rsp+0x50], xmm6
000079f9de5dd277  vmovaps [rsp+0x60], xmm7
000079f9de5dd27d  vmovaps [rsp+0x70], xmm8
000079f9de5dd283  vmovaps [rsp+0x80], xmm9
000079f9de5dd28c  vmovaps [rsp+0x90], xmm10
000079f9de5dd295  vmovaps [rsp+0xA0], xmm11
000079f9de5dd29e  vmovaps [rsp+0xB0], xmm12
000079f9de5dd2a7  vmovaps [rsp+0xC0], xmm13
000079f9de5dd2b0  vmovaps [rsp+0xD0], xmm14
000079f9de5dd2b9  vmovaps [rsp+0xE0], xmm15
000079f9de5dd2c2  sub rsp, 0x30
000079f9de5dd2c6  movaps [rsp], xmm4
000079f9de5dd2ca  movaps [rsp+0x10], xmm9
000079f9de5dd2d0  movaps [rsp+0x20], xmm8
000079f9de5dd2d6  lea rdi, [rsp]
000079f9de5dd2da  mov esi, 0x00
000079f9de5dd2df  mov rax, 0x56D56FF59530
000079f9de5dd2e9  call rax
000079f9de5dd2eb  movaps xmm4, [rsp]
000079f9de5dd2ef  add rsp, 0x30
000079f9de5dd2f3  vmovaps xmm0, [rsp]
000079f9de5dd2f8  vmovaps xmm1, [rsp+0x10]
000079f9de5dd2fe  vmovaps xmm2, [rsp+0x20]
000079f9de5dd304  vmovaps xmm3, [rsp+0x30]
000079f9de5dd30a  vmovaps xmm5, [rsp+0x40]
000079f9de5dd310  vmovaps xmm6, [rsp+0x50]
000079f9de5dd316  vmovaps xmm7, [rsp+0x60]
000079f9de5dd31c  vmovaps xmm8, [rsp+0x70]
000079f9de5dd322  vmovaps xmm9, [rsp+0x80]
000079f9de5dd32b  vmovaps xmm10, [rsp+0x90]
000079f9de5dd334  vmovaps xmm11, [rsp+0xA0]
000079f9de5dd33d  vmovaps xmm12, [rsp+0xB0]
000079f9de5dd346  vmovaps xmm13, [rsp+0xC0]
000079f9de5dd34f  vmovaps xmm14, [rsp+0xD0]
000079f9de5dd358  vmovaps xmm15, [rsp+0xE0]
000079f9de5dd361  add rsp, 0xF0
000079f9de5dd368  pop r11
000079f9de5dd36a  pop r10
000079f9de5dd36c  pop r9
000079f9de5dd36e  pop r8
000079f9de5dd370  pop rsi
000079f9de5dd371  pop rdi
000079f9de5dd372  pop rdx
000079f9de5dd373  pop rcx
000079f9de5dd374  pop rax
000079f9de5dd375  add rsp, 0x08
000079f9de5dd379  jmp 0x000079F9DE5DBC94
000079f9de5dd37e  sub rsp, 0x08
000079f9de5dd382  push rax
000079f9de5dd383  push rcx
000079f9de5dd384  push rdx
000079f9de5dd385  push rdi
000079f9de5dd386  push rsi
000079f9de5dd387  push r8
000079f9de5dd389  push r9
000079f9de5dd38b  push r10
000079f9de5dd38d  push r11
000079f9de5dd38f  sub rsp, 0xF0
000079f9de5dd396  vmovaps [rsp], xmm0
000079f9de5dd39b  vmovaps [rsp+0x10], xmm1
000079f9de5dd3a1  vmovaps [rsp+0x20], xmm2
000079f9de5dd3a7  vmovaps [rsp+0x30], xmm3
000079f9de5dd3ad  vmovaps [rsp+0x40], xmm4
000079f9de5dd3b3  vmovaps [rsp+0x50], xmm5
000079f9de5dd3b9  vmovaps [rsp+0x60], xmm6
000079f9de5dd3bf  vmovaps [rsp+0x70], xmm7
000079f9de5dd3c5  vmovaps [rsp+0x80], xmm8
000079f9de5dd3ce  vmovaps [rsp+0x90], xmm10
000079f9de5dd3d7  vmovaps [rsp+0xA0], xmm11
000079f9de5dd3e0  vmovaps [rsp+0xB0], xmm12
000079f9de5dd3e9  vmovaps [rsp+0xC0], xmm13
000079f9de5dd3f2  vmovaps [rsp+0xD0], xmm14
000079f9de5dd3fb  vmovaps [rsp+0xE0], xmm15
000079f9de5dd404  sub rsp, 0x30
000079f9de5dd408  movaps [rsp], xmm9
000079f9de5dd40d  movaps [rsp+0x10], xmm10
000079f9de5dd413  movaps [rsp+0x20], xmm8
000079f9de5dd419  lea rdi, [rsp]
000079f9de5dd41d  mov esi, 0x00
000079f9de5dd422  mov rax, 0x56D56FF59530
000079f9de5dd42c  call rax
000079f9de5dd42e  movaps xmm9, [rsp]
000079f9de5dd433  add rsp, 0x30
000079f9de5dd437  vmovaps xmm0, [rsp]
000079f9de5dd43c  vmovaps xmm1, [rsp+0x10]
000079f9de5dd442  vmovaps xmm2, [rsp+0x20]
000079f9de5dd448  vmovaps xmm3, [rsp+0x30]
000079f9de5dd44e  vmovaps xmm4, [rsp+0x40]
000079f9de5dd454  vmovaps xmm5, [rsp+0x50]
000079f9de5dd45a  vmovaps xmm6, [rsp+0x60]
000079f9de5dd460  vmovaps xmm7, [rsp+0x70]
000079f9de5dd466  vmovaps xmm8, [rsp+0x80]
000079f9de5dd46f  vmovaps xmm10, [rsp+0x90]
000079f9de5dd478  vmovaps xmm11, [rsp+0xA0]
000079f9de5dd481  vmovaps xmm12, [rsp+0xB0]
000079f9de5dd48a  vmovaps xmm13, [rsp+0xC0]
000079f9de5dd493  vmovaps xmm14, [rsp+0xD0]
000079f9de5dd49c  vmovaps xmm15, [rsp+0xE0]
000079f9de5dd4a5  add rsp, 0xF0
000079f9de5dd4ac  pop r11
000079f9de5dd4ae  pop r10
000079f9de5dd4b0  pop r9
000079f9de5dd4b2  pop r8
000079f9de5dd4b4  pop rsi
000079f9de5dd4b5  pop rdi
000079f9de5dd4b6  pop rdx
000079f9de5dd4b7  pop rcx
000079f9de5dd4b8  pop rax
000079f9de5dd4b9  add rsp, 0x08
000079f9de5dd4bd  jmp 0x000079F9DE5DBCAE
000079f9de5dd4c2  call 0x000079F9DE4B52F0
000079f9de5dd4c7  jmp 0x000079F9DE5DBDC8
000079f9de5dd4cc  call 0x000079F9DE4B52F0
000079f9de5dd4d1  jmp 0x000079F9DE5DBDDE
000079f9de5dd4d6  sub rsp, 0x08
000079f9de5dd4da  push rax
000079f9de5dd4db  push rcx
000079f9de5dd4dc  push rdx
000079f9de5dd4dd  push rdi
000079f9de5dd4de  push rsi
000079f9de5dd4df  push r8
000079f9de5dd4e1  push r9
000079f9de5dd4e3  push r10
000079f9de5dd4e5  push r11
000079f9de5dd4e7  sub rsp, 0xF0
000079f9de5dd4ee  vmovaps [rsp], xmm0
000079f9de5dd4f3  vmovaps [rsp+0x10], xmm2
000079f9de5dd4f9  vmovaps [rsp+0x20], xmm3
000079f9de5dd4ff  vmovaps [rsp+0x30], xmm4
000079f9de5dd505  vmovaps [rsp+0x40], xmm5
000079f9de5dd50b  vmovaps [rsp+0x50], xmm6
000079f9de5dd511  vmovaps [rsp+0x60], xmm7
000079f9de5dd517  vmovaps [rsp+0x70], xmm8
000079f9de5dd51d  vmovaps [rsp+0x80], xmm9
000079f9de5dd526  vmovaps [rsp+0x90], xmm10
000079f9de5dd52f  vmovaps [rsp+0xA0], xmm11
000079f9de5dd538  vmovaps [rsp+0xB0], xmm12
000079f9de5dd541  vmovaps [rsp+0xC0], xmm13
000079f9de5dd54a  vmovaps [rsp+0xD0], xmm14
000079f9de5dd553  vmovaps [rsp+0xE0], xmm15
000079f9de5dd55c  sub rsp, 0x30
000079f9de5dd560  movaps [rsp], xmm1
000079f9de5dd564  movaps [rsp+0x10], xmm6
000079f9de5dd569  movaps [rsp+0x20], xmm15
000079f9de5dd56f  lea rdi, [rsp]
000079f9de5dd573  mov esi, 0x00
000079f9de5dd578  mov rax, 0x56D56FF59530
000079f9de5dd582  call rax
000079f9de5dd584  movaps xmm1, [rsp]
000079f9de5dd588  add rsp, 0x30
000079f9de5dd58c  vmovaps xmm0, [rsp]
000079f9de5dd591  vmovaps xmm2, [rsp+0x10]
000079f9de5dd597  vmovaps xmm3, [rsp+0x20]
000079f9de5dd59d  vmovaps xmm4, [rsp+0x30]
000079f9de5dd5a3  vmovaps xmm5, [rsp+0x40]
000079f9de5dd5a9  vmovaps xmm6, [rsp+0x50]
000079f9de5dd5af  vmovaps xmm7, [rsp+0x60]
000079f9de5dd5b5  vmovaps xmm8, [rsp+0x70]
000079f9de5dd5bb  vmovaps xmm9, [rsp+0x80]
000079f9de5dd5c4  vmovaps xmm10, [rsp+0x90]
000079f9de5dd5cd  vmovaps xmm11, [rsp+0xA0]
000079f9de5dd5d6  vmovaps xmm12, [rsp+0xB0]
000079f9de5dd5df  vmovaps xmm13, [rsp+0xC0]
000079f9de5dd5e8  vmovaps xmm14, [rsp+0xD0]
000079f9de5dd5f1  vmovaps xmm15, [rsp+0xE0]
000079f9de5dd5fa  add rsp, 0xF0
000079f9de5dd601  pop r11
000079f9de5dd603  pop r10
000079f9de5dd605  pop r9
000079f9de5dd607  pop r8
000079f9de5dd609  pop rsi
000079f9de5dd60a  pop rdi
000079f9de5dd60b  pop rdx
000079f9de5dd60c  pop rcx
000079f9de5dd60d  pop rax
000079f9de5dd60e  add rsp, 0x08
000079f9de5dd612  jmp 0x000079F9DE5DBE1B
000079f9de5dd617  call 0x000079F9DE4C4620
000079f9de5dd61c  jmp 0x000079F9DE5DBE28
000079f9de5dd621  sub rsp, 0x08
000079f9de5dd625  push rax
000079f9de5dd626  push rcx
000079f9de5dd627  push rdx
000079f9de5dd628  push rdi
000079f9de5dd629  push rsi
000079f9de5dd62a  push r8
000079f9de5dd62c  push r9
000079f9de5dd62e  push r10
000079f9de5dd630  push r11
000079f9de5dd632  sub rsp, 0xF0
000079f9de5dd639  vmovaps [rsp], xmm0
000079f9de5dd63e  vmovaps [rsp+0x10], xmm1
000079f9de5dd644  vmovaps [rsp+0x20], xmm2
000079f9de5dd64a  vmovaps [rsp+0x30], xmm3
000079f9de5dd650  vmovaps [rsp+0x40], xmm4
000079f9de5dd656  vmovaps [rsp+0x50], xmm5
000079f9de5dd65c  vmovaps [rsp+0x60], xmm6
000079f9de5dd662  vmovaps [rsp+0x70], xmm7
000079f9de5dd668  vmovaps [rsp+0x80], xmm8
000079f9de5dd671  vmovaps [rsp+0x90], xmm9
000079f9de5dd67a  vmovaps [rsp+0xA0], xmm10
000079f9de5dd683  vmovaps [rsp+0xB0], xmm11
000079f9de5dd68c  vmovaps [rsp+0xC0], xmm12
000079f9de5dd695  vmovaps [rsp+0xD0], xmm13
000079f9de5dd69e  vmovaps [rsp+0xE0], xmm15
000079f9de5dd6a7  sub rsp, 0x30
000079f9de5dd6ab  movaps [rsp], xmm14
000079f9de5dd6b0  movaps [rsp+0x10], xmm4
000079f9de5dd6b5  movaps [rsp+0x20], xmm3
000079f9de5dd6ba  lea rdi, [rsp]
000079f9de5dd6be  mov esi, 0x00
000079f9de5dd6c3  mov rax, 0x56D56FF59530
000079f9de5dd6cd  call rax
000079f9de5dd6cf  movaps xmm14, [rsp]
000079f9de5dd6d4  add rsp, 0x30
000079f9de5dd6d8  vmovaps xmm0, [rsp]
000079f9de5dd6dd  vmovaps xmm1, [rsp+0x10]
000079f9de5dd6e3  vmovaps xmm2, [rsp+0x20]
000079f9de5dd6e9  vmovaps xmm3, [rsp+0x30]
000079f9de5dd6ef  vmovaps xmm4, [rsp+0x40]
000079f9de5dd6f5  vmovaps xmm5, [rsp+0x50]
000079f9de5dd6fb  vmovaps xmm6, [rsp+0x60]
000079f9de5dd701  vmovaps xmm7, [rsp+0x70]
000079f9de5dd707  vmovaps xmm8, [rsp+0x80]
000079f9de5dd710  vmovaps xmm9, [rsp+0x90]
000079f9de5dd719  vmovaps xmm10, [rsp+0xA0]
000079f9de5dd722  vmovaps xmm11, [rsp+0xB0]
000079f9de5dd72b  vmovaps xmm12, [rsp+0xC0]
000079f9de5dd734  vmovaps xmm13, [rsp+0xD0]
000079f9de5dd73d  vmovaps xmm15, [rsp+0xE0]
000079f9de5dd746  add rsp, 0xF0
000079f9de5dd74d  pop r11
000079f9de5dd74f  pop r10
000079f9de5dd751  pop r9
000079f9de5dd753  pop r8
000079f9de5dd755  pop rsi
000079f9de5dd756  pop rdi
000079f9de5dd757  pop rdx
000079f9de5dd758  pop rcx
000079f9de5dd759  pop rax
000079f9de5dd75a  add rsp, 0x08
000079f9de5dd75e  jmp 0x000079F9DE5DBE42
000079f9de5dd763  sub rsp, 0x08
000079f9de5dd767  push rax
000079f9de5dd768  push rcx
000079f9de5dd769  push rdx
000079f9de5dd76a  push rdi
000079f9de5dd76b  push rsi
000079f9de5dd76c  push r8
000079f9de5dd76e  push r9
000079f9de5dd770  push r10
000079f9de5dd772  push r11
000079f9de5dd774  sub rsp, 0xF0
000079f9de5dd77b  vmovaps [rsp], xmm0
000079f9de5dd780  vmovaps [rsp+0x10], xmm1
000079f9de5dd786  vmovaps [rsp+0x20], xmm2
000079f9de5dd78c  vmovaps [rsp+0x30], xmm3
000079f9de5dd792  vmovaps [rsp+0x40], xmm4
000079f9de5dd798  vmovaps [rsp+0x50], xmm5
000079f9de5dd79e  vmovaps [rsp+0x60], xmm7
000079f9de5dd7a4  vmovaps [rsp+0x70], xmm8
000079f9de5dd7aa  vmovaps [rsp+0x80], xmm9
000079f9de5dd7b3  vmovaps [rsp+0x90], xmm10
000079f9de5dd7bc  vmovaps [rsp+0xA0], xmm11
000079f9de5dd7c5  vmovaps [rsp+0xB0], xmm12
000079f9de5dd7ce  vmovaps [rsp+0xC0], xmm13
000079f9de5dd7d7  vmovaps [rsp+0xD0], xmm14
000079f9de5dd7e0  vmovaps [rsp+0xE0], xmm15
000079f9de5dd7e9  sub rsp, 0x30
000079f9de5dd7ed  movaps [rsp], xmm6
000079f9de5dd7f1  movaps [rsp+0x10], xmm9
000079f9de5dd7f7  movaps [rsp+0x20], xmm7
000079f9de5dd7fc  lea rdi, [rsp]
000079f9de5dd800  mov esi, 0x00
000079f9de5dd805  mov rax, 0x56D56FF59530
000079f9de5dd80f  call rax
000079f9de5dd811  movaps xmm6, [rsp]
000079f9de5dd815  add rsp, 0x30
000079f9de5dd819  vmovaps xmm0, [rsp]
000079f9de5dd81e  vmovaps xmm1, [rsp+0x10]
000079f9de5dd824  vmovaps xmm2, [rsp+0x20]
000079f9de5dd82a  vmovaps xmm3, [rsp+0x30]
000079f9de5dd830  vmovaps xmm4, [rsp+0x40]
000079f9de5dd836  vmovaps xmm5, [rsp+0x50]
000079f9de5dd83c  vmovaps xmm7, [rsp+0x60]
000079f9de5dd842  vmovaps xmm8, [rsp+0x70]
000079f9de5dd848  vmovaps xmm9, [rsp+0x80]
000079f9de5dd851  vmovaps xmm10, [rsp+0x90]
000079f9de5dd85a  vmovaps xmm11, [rsp+0xA0]
000079f9de5dd863  vmovaps xmm12, [rsp+0xB0]
000079f9de5dd86c  vmovaps xmm13, [rsp+0xC0]
000079f9de5dd875  vmovaps xmm14, [rsp+0xD0]
000079f9de5dd87e  vmovaps xmm15, [rsp+0xE0]
000079f9de5dd887  add rsp, 0xF0
000079f9de5dd88e  pop r11
000079f9de5dd890  pop r10
000079f9de5dd892  pop r9
000079f9de5dd894  pop r8
000079f9de5dd896  pop rsi
000079f9de5dd897  pop rdi
000079f9de5dd898  pop rdx
000079f9de5dd899  pop rcx
000079f9de5dd89a  pop rax
000079f9de5dd89b  add rsp, 0x08
000079f9de5dd89f  jmp 0x000079F9DE5DBE5A
000079f9de5dd8a4  sub rsp, 0x08
000079f9de5dd8a8  push rax
000079f9de5dd8a9  push rcx
000079f9de5dd8aa  push rdx
000079f9de5dd8ab  push rdi
000079f9de5dd8ac  push rsi
000079f9de5dd8ad  push r8
000079f9de5dd8af  push r9
000079f9de5dd8b1  push r10
000079f9de5dd8b3  push r11
000079f9de5dd8b5  sub rsp, 0xF0
000079f9de5dd8bc  vmovaps [rsp], xmm0
000079f9de5dd8c1  vmovaps [rsp+0x10], xmm1
000079f9de5dd8c7  vmovaps [rsp+0x20], xmm2
000079f9de5dd8cd  vmovaps [rsp+0x30], xmm3
000079f9de5dd8d3  vmovaps [rsp+0x40], xmm4
000079f9de5dd8d9  vmovaps [rsp+0x50], xmm5
000079f9de5dd8df  vmovaps [rsp+0x60], xmm6
000079f9de5dd8e5  vmovaps [rsp+0x70], xmm8
000079f9de5dd8eb  vmovaps [rsp+0x80], xmm9
000079f9de5dd8f4  vmovaps [rsp+0x90], xmm10
000079f9de5dd8fd  vmovaps [rsp+0xA0], xmm11
000079f9de5dd906  vmovaps [rsp+0xB0], xmm12
000079f9de5dd90f  vmovaps [rsp+0xC0], xmm13
000079f9de5dd918  vmovaps [rsp+0xD0], xmm14
000079f9de5dd921  vmovaps [rsp+0xE0], xmm15
000079f9de5dd92a  sub rsp, 0x30
000079f9de5dd92e  movaps [rsp], xmm7
000079f9de5dd932  movaps [rsp+0x10], xmm4
000079f9de5dd937  movaps [rsp+0x20], xmm9
000079f9de5dd93d  lea rdi, [rsp]
000079f9de5dd941  mov esi, 0x00
000079f9de5dd946  mov rax, 0x56D56FF59530
000079f9de5dd950  call rax
000079f9de5dd952  movaps xmm7, [rsp]
000079f9de5dd956  add rsp, 0x30
000079f9de5dd95a  vmovaps xmm0, [rsp]
000079f9de5dd95f  vmovaps xmm1, [rsp+0x10]
000079f9de5dd965  vmovaps xmm2, [rsp+0x20]
000079f9de5dd96b  vmovaps xmm3, [rsp+0x30]
000079f9de5dd971  vmovaps xmm4, [rsp+0x40]
000079f9de5dd977  vmovaps xmm5, [rsp+0x50]
000079f9de5dd97d  vmovaps xmm6, [rsp+0x60]
000079f9de5dd983  vmovaps xmm8, [rsp+0x70]
000079f9de5dd989  vmovaps xmm9, [rsp+0x80]
000079f9de5dd992  vmovaps xmm10, [rsp+0x90]
000079f9de5dd99b  vmovaps xmm11, [rsp+0xA0]
000079f9de5dd9a4  vmovaps xmm12, [rsp+0xB0]
000079f9de5dd9ad  vmovaps xmm13, [rsp+0xC0]
000079f9de5dd9b6  vmovaps xmm14, [rsp+0xD0]
000079f9de5dd9bf  vmovaps xmm15, [rsp+0xE0]
000079f9de5dd9c8  add rsp, 0xF0
000079f9de5dd9cf  pop r11
000079f9de5dd9d1  pop r10
000079f9de5dd9d3  pop r9
000079f9de5dd9d5  pop r8
000079f9de5dd9d7  pop rsi
000079f9de5dd9d8  pop rdi
000079f9de5dd9d9  pop rdx
000079f9de5dd9da  pop rcx
000079f9de5dd9db  pop rax
000079f9de5dd9dc  add rsp, 0x08
000079f9de5dd9e0  jmp 0x000079F9DE5DBE87
000079f9de5dd9e5  sub rsp, 0x08
000079f9de5dd9e9  push rax
000079f9de5dd9ea  push rcx
000079f9de5dd9eb  push rdx
000079f9de5dd9ec  push rdi
000079f9de5dd9ed  push rsi
000079f9de5dd9ee  push r8
000079f9de5dd9f0  push r9
000079f9de5dd9f2  push r10
000079f9de5dd9f4  push r11
000079f9de5dd9f6  sub rsp, 0xF0
000079f9de5dd9fd  vmovaps [rsp], xmm0
000079f9de5dda02  vmovaps [rsp+0x10], xmm1
000079f9de5dda08  vmovaps [rsp+0x20], xmm2
000079f9de5dda0e  vmovaps [rsp+0x30], xmm3
000079f9de5dda14  vmovaps [rsp+0x40], xmm5
000079f9de5dda1a  vmovaps [rsp+0x50], xmm6
000079f9de5dda20  vmovaps [rsp+0x60], xmm7
000079f9de5dda26  vmovaps [rsp+0x70], xmm8
000079f9de5dda2c  vmovaps [rsp+0x80], xmm9
000079f9de5dda35  vmovaps [rsp+0x90], xmm10
000079f9de5dda3e  vmovaps [rsp+0xA0], xmm11
000079f9de5dda47  vmovaps [rsp+0xB0], xmm12
000079f9de5dda50  vmovaps [rsp+0xC0], xmm13
000079f9de5dda59  vmovaps [rsp+0xD0], xmm14
000079f9de5dda62  vmovaps [rsp+0xE0], xmm15
000079f9de5dda6b  sub rsp, 0x30
000079f9de5dda6f  movaps [rsp], xmm4
000079f9de5dda73  movaps [rsp+0x10], xmm15
000079f9de5dda79  movaps [rsp+0x20], xmm9
000079f9de5dda7f  lea rdi, [rsp]
000079f9de5dda83  mov esi, 0x00
000079f9de5dda88  mov rax, 0x56D56FF59530
000079f9de5dda92  call rax
000079f9de5dda94  movaps xmm4, [rsp]
000079f9de5dda98  add rsp, 0x30
000079f9de5dda9c  vmovaps xmm0, [rsp]
000079f9de5ddaa1  vmovaps xmm1, [rsp+0x10]
000079f9de5ddaa7  vmovaps xmm2, [rsp+0x20]
000079f9de5ddaad  vmovaps xmm3, [rsp+0x30]
000079f9de5ddab3  vmovaps xmm5, [rsp+0x40]
000079f9de5ddab9  vmovaps xmm6, [rsp+0x50]
000079f9de5ddabf  vmovaps xmm7, [rsp+0x60]
000079f9de5ddac5  vmovaps xmm8, [rsp+0x70]
000079f9de5ddacb  vmovaps xmm9, [rsp+0x80]
000079f9de5ddad4  vmovaps xmm10, [rsp+0x90]
000079f9de5ddadd  vmovaps xmm11, [rsp+0xA0]
000079f9de5ddae6  vmovaps xmm12, [rsp+0xB0]
000079f9de5ddaef  vmovaps xmm13, [rsp+0xC0]
000079f9de5ddaf8  vmovaps xmm14, [rsp+0xD0]
000079f9de5ddb01  vmovaps xmm15, [rsp+0xE0]
000079f9de5ddb0a  add rsp, 0xF0
000079f9de5ddb11  pop r11
000079f9de5ddb13  pop r10
000079f9de5ddb15  pop r9
000079f9de5ddb17  pop r8
000079f9de5ddb19  pop rsi
000079f9de5ddb1a  pop rdi
000079f9de5ddb1b  pop rdx
000079f9de5ddb1c  pop rcx
000079f9de5ddb1d  pop rax
000079f9de5ddb1e  add rsp, 0x08
000079f9de5ddb22  jmp 0x000079F9DE5DBEAC
000079f9de5ddb27  call 0x000079F9DE4C4620
000079f9de5ddb2c  jmp 0x000079F9DE5DBEB9
000079f9de5ddb31  sub rsp, 0x08
000079f9de5ddb35  push rax
000079f9de5ddb36  push rcx
000079f9de5ddb37  push rdx
000079f9de5ddb38  push rdi
000079f9de5ddb39  push rsi
000079f9de5ddb3a  push r8
000079f9de5ddb3c  push r9
000079f9de5ddb3e  push r10
000079f9de5ddb40  push r11
000079f9de5ddb42  sub rsp, 0xF0
000079f9de5ddb49  vmovaps [rsp], xmm0
000079f9de5ddb4e  vmovaps [rsp+0x10], xmm1
000079f9de5ddb54  vmovaps [rsp+0x20], xmm2
000079f9de5ddb5a  vmovaps [rsp+0x30], xmm4
000079f9de5ddb60  vmovaps [rsp+0x40], xmm5
000079f9de5ddb66  vmovaps [rsp+0x50], xmm6
000079f9de5ddb6c  vmovaps [rsp+0x60], xmm7
000079f9de5ddb72  vmovaps [rsp+0x70], xmm8
000079f9de5ddb78  vmovaps [rsp+0x80], xmm9
000079f9de5ddb81  vmovaps [rsp+0x90], xmm10
000079f9de5ddb8a  vmovaps [rsp+0xA0], xmm11
000079f9de5ddb93  vmovaps [rsp+0xB0], xmm12
000079f9de5ddb9c  vmovaps [rsp+0xC0], xmm13
000079f9de5ddba5  vmovaps [rsp+0xD0], xmm14
000079f9de5ddbae  vmovaps [rsp+0xE0], xmm15
000079f9de5ddbb7  sub rsp, 0x30
000079f9de5ddbbb  movaps [rsp], xmm3
000079f9de5ddbbf  movaps [rsp+0x10], xmm1
000079f9de5ddbc4  movaps [rsp+0x20], xmm9
000079f9de5ddbca  lea rdi, [rsp]
000079f9de5ddbce  mov esi, 0x00
000079f9de5ddbd3  mov rax, 0x56D56FF59530
000079f9de5ddbdd  call rax
000079f9de5ddbdf  movaps xmm3, [rsp]
000079f9de5ddbe3  add rsp, 0x30
000079f9de5ddbe7  vmovaps xmm0, [rsp]
000079f9de5ddbec  vmovaps xmm1, [rsp+0x10]
000079f9de5ddbf2  vmovaps xmm2, [rsp+0x20]
000079f9de5ddbf8  vmovaps xmm4, [rsp+0x30]
000079f9de5ddbfe  vmovaps xmm5, [rsp+0x40]
000079f9de5ddc04  vmovaps xmm6, [rsp+0x50]
000079f9de5ddc0a  vmovaps xmm7, [rsp+0x60]
000079f9de5ddc10  vmovaps xmm8, [rsp+0x70]
000079f9de5ddc16  vmovaps xmm9, [rsp+0x80]
000079f9de5ddc1f  vmovaps xmm10, [rsp+0x90]
000079f9de5ddc28  vmovaps xmm11, [rsp+0xA0]
000079f9de5ddc31  vmovaps xmm12, [rsp+0xB0]
000079f9de5ddc3a  vmovaps xmm13, [rsp+0xC0]
000079f9de5ddc43  vmovaps xmm14, [rsp+0xD0]
000079f9de5ddc4c  vmovaps xmm15, [rsp+0xE0]
000079f9de5ddc55  add rsp, 0xF0
000079f9de5ddc5c  pop r11
000079f9de5ddc5e  pop r10
000079f9de5ddc60  pop r9
000079f9de5ddc62  pop r8
000079f9de5ddc64  pop rsi
000079f9de5ddc65  pop rdi
000079f9de5ddc66  pop rdx
000079f9de5ddc67  pop rcx
000079f9de5ddc68  pop rax
000079f9de5ddc69  add rsp, 0x08
000079f9de5ddc6d  jmp 0x000079F9DE5DBEF6
000079f9de5ddc72  sub rsp, 0x08
000079f9de5ddc76  push rax
000079f9de5ddc77  push rcx
000079f9de5ddc78  push rdx
000079f9de5ddc79  push rdi
000079f9de5ddc7a  push rsi
000079f9de5ddc7b  push r8
000079f9de5ddc7d  push r9
000079f9de5ddc7f  push r10
000079f9de5ddc81  push r11
000079f9de5ddc83  sub rsp, 0xF0
000079f9de5ddc8a  vmovaps [rsp], xmm0
000079f9de5ddc8f  vmovaps [rsp+0x10], xmm2
000079f9de5ddc95  vmovaps [rsp+0x20], xmm3
000079f9de5ddc9b  vmovaps [rsp+0x30], xmm4
000079f9de5ddca1  vmovaps [rsp+0x40], xmm5
000079f9de5ddca7  vmovaps [rsp+0x50], xmm6
000079f9de5ddcad  vmovaps [rsp+0x60], xmm7
000079f9de5ddcb3  vmovaps [rsp+0x70], xmm8
000079f9de5ddcb9  vmovaps [rsp+0x80], xmm9
000079f9de5ddcc2  vmovaps [rsp+0x90], xmm10
000079f9de5ddccb  vmovaps [rsp+0xA0], xmm11
000079f9de5ddcd4  vmovaps [rsp+0xB0], xmm12
000079f9de5ddcdd  vmovaps [rsp+0xC0], xmm13
000079f9de5ddce6  vmovaps [rsp+0xD0], xmm14
000079f9de5ddcef  vmovaps [rsp+0xE0], xmm15
000079f9de5ddcf8  sub rsp, 0x30
000079f9de5ddcfc  movaps [rsp], xmm1
000079f9de5ddd00  movaps [rsp+0x10], xmm15
000079f9de5ddd06  movaps [rsp+0x20], xmm9
000079f9de5ddd0c  lea rdi, [rsp]
000079f9de5ddd10  mov esi, 0x00
000079f9de5ddd15  mov rax, 0x56D56FF59530
000079f9de5ddd1f  call rax
000079f9de5ddd21  movaps xmm1, [rsp]
000079f9de5ddd25  add rsp, 0x30
000079f9de5ddd29  vmovaps xmm0, [rsp]
000079f9de5ddd2e  vmovaps xmm2, [rsp+0x10]
000079f9de5ddd34  vmovaps xmm3, [rsp+0x20]
000079f9de5ddd3a  vmovaps xmm4, [rsp+0x30]
000079f9de5ddd40  vmovaps xmm5, [rsp+0x40]
000079f9de5ddd46  vmovaps xmm6, [rsp+0x50]
000079f9de5ddd4c  vmovaps xmm7, [rsp+0x60]
000079f9de5ddd52  vmovaps xmm8, [rsp+0x70]
000079f9de5ddd58  vmovaps xmm9, [rsp+0x80]
000079f9de5ddd61  vmovaps xmm10, [rsp+0x90]
000079f9de5ddd6a  vmovaps xmm11, [rsp+0xA0]
000079f9de5ddd73  vmovaps xmm12, [rsp+0xB0]
000079f9de5ddd7c  vmovaps xmm13, [rsp+0xC0]
000079f9de5ddd85  vmovaps xmm14, [rsp+0xD0]
000079f9de5ddd8e  vmovaps xmm15, [rsp+0xE0]
000079f9de5ddd97  add rsp, 0xF0
000079f9de5ddd9e  pop r11
000079f9de5ddda0  pop r10
000079f9de5ddda2  pop r9
000079f9de5ddda4  pop r8
000079f9de5ddda6  pop rsi
000079f9de5ddda7  pop rdi
000079f9de5ddda8  pop rdx
000079f9de5ddda9  pop rcx
000079f9de5dddaa  pop rax
000079f9de5dddab  add rsp, 0x08
000079f9de5dddaf  jmp 0x000079F9DE5DBF7E
000079f9de5dddb4  call 0x000079F9DE4C4620
000079f9de5dddb9  jmp 0x000079F9DE5DBF8B
000079f9de5dddbe  sub rsp, 0x08
000079f9de5dddc2  push rax
000079f9de5dddc3  push rcx
000079f9de5dddc4  push rdx
000079f9de5dddc5  push rdi
000079f9de5dddc6  push rsi
000079f9de5dddc7  push r8
000079f9de5dddc9  push r9
000079f9de5dddcb  push r10
000079f9de5dddcd  push r11
000079f9de5dddcf  sub rsp, 0xF0
000079f9de5dddd6  vmovaps [rsp], xmm0
000079f9de5ddddb  vmovaps [rsp+0x10], xmm2
000079f9de5ddde1  vmovaps [rsp+0x20], xmm3
000079f9de5ddde7  vmovaps [rsp+0x30], xmm4
000079f9de5ddded  vmovaps [rsp+0x40], xmm5
000079f9de5dddf3  vmovaps [rsp+0x50], xmm6
000079f9de5dddf9  vmovaps [rsp+0x60], xmm7
000079f9de5dddff  vmovaps [rsp+0x70], xmm8
000079f9de5dde05  vmovaps [rsp+0x80], xmm9
000079f9de5dde0e  vmovaps [rsp+0x90], xmm10
000079f9de5dde17  vmovaps [rsp+0xA0], xmm11
000079f9de5dde20  vmovaps [rsp+0xB0], xmm12
000079f9de5dde29  vmovaps [rsp+0xC0], xmm13
000079f9de5dde32  vmovaps [rsp+0xD0], xmm14
000079f9de5dde3b  vmovaps [rsp+0xE0], xmm15
000079f9de5dde44  sub rsp, 0x30
000079f9de5dde48  movaps [rsp], xmm1
000079f9de5dde4c  movaps [rsp+0x10], xmm5
000079f9de5dde51  movaps [rsp+0x20], xmm7
000079f9de5dde56  lea rdi, [rsp]
000079f9de5dde5a  mov esi, 0x00
000079f9de5dde5f  mov rax, 0x56D56FF59530
000079f9de5dde69  call rax
000079f9de5dde6b  movaps xmm1, [rsp]
000079f9de5dde6f  add rsp, 0x30
000079f9de5dde73  vmovaps xmm0, [rsp]
000079f9de5dde78  vmovaps xmm2, [rsp+0x10]
000079f9de5dde7e  vmovaps xmm3, [rsp+0x20]
000079f9de5dde84  vmovaps xmm4, [rsp+0x30]
000079f9de5dde8a  vmovaps xmm5, [rsp+0x40]
000079f9de5dde90  vmovaps xmm6, [rsp+0x50]
000079f9de5dde96  vmovaps xmm7, [rsp+0x60]
000079f9de5dde9c  vmovaps xmm8, [rsp+0x70]
000079f9de5ddea2  vmovaps xmm9, [rsp+0x80]
000079f9de5ddeab  vmovaps xmm10, [rsp+0x90]
000079f9de5ddeb4  vmovaps xmm11, [rsp+0xA0]
000079f9de5ddebd  vmovaps xmm12, [rsp+0xB0]
000079f9de5ddec6  vmovaps xmm13, [rsp+0xC0]
000079f9de5ddecf  vmovaps xmm14, [rsp+0xD0]
000079f9de5dded8  vmovaps xmm15, [rsp+0xE0]
000079f9de5ddee1  add rsp, 0xF0
000079f9de5ddee8  pop r11
000079f9de5ddeea  pop r10
000079f9de5ddeec  pop r9
000079f9de5ddeee  pop r8
000079f9de5ddef0  pop rsi
000079f9de5ddef1  pop rdi
000079f9de5ddef2  pop rdx
000079f9de5ddef3  pop rcx
000079f9de5ddef4  pop rax
000079f9de5ddef5  add rsp, 0x08
000079f9de5ddef9  jmp 0x000079F9DE5DC030
000079f9de5ddefe  sub rsp, 0x08
000079f9de5ddf02  push rax
000079f9de5ddf03  push rcx
000079f9de5ddf04  push rdx
000079f9de5ddf05  push rdi
000079f9de5ddf06  push rsi
000079f9de5ddf07  push r8
000079f9de5ddf09  push r9
000079f9de5ddf0b  push r10
000079f9de5ddf0d  push r11
000079f9de5ddf0f  sub rsp, 0xF0
000079f9de5ddf16  vmovaps [rsp], xmm0
000079f9de5ddf1b  vmovaps [rsp+0x10], xmm1
000079f9de5ddf21  vmovaps [rsp+0x20], xmm2
000079f9de5ddf27  vmovaps [rsp+0x30], xmm3
000079f9de5ddf2d  vmovaps [rsp+0x40], xmm4
000079f9de5ddf33  vmovaps [rsp+0x50], xmm5
000079f9de5ddf39  vmovaps [rsp+0x60], xmm6
000079f9de5ddf3f  vmovaps [rsp+0x70], xmm8
000079f9de5ddf45  vmovaps [rsp+0x80], xmm9
000079f9de5ddf4e  vmovaps [rsp+0x90], xmm10
000079f9de5ddf57  vmovaps [rsp+0xA0], xmm11
000079f9de5ddf60  vmovaps [rsp+0xB0], xmm12
000079f9de5ddf69  vmovaps [rsp+0xC0], xmm13
000079f9de5ddf72  vmovaps [rsp+0xD0], xmm14
000079f9de5ddf7b  vmovaps [rsp+0xE0], xmm15
000079f9de5ddf84  sub rsp, 0x30
000079f9de5ddf88  movaps [rsp], xmm7
000079f9de5ddf8c  movaps [rsp+0x10], xmm5
000079f9de5ddf91  movaps [rsp+0x20], xmm15
000079f9de5ddf97  lea rdi, [rsp]
000079f9de5ddf9b  mov esi, 0x00
000079f9de5ddfa0  mov rax, 0x56D56FF59530
000079f9de5ddfaa  call rax
000079f9de5ddfac  movaps xmm7, [rsp]
000079f9de5ddfb0  add rsp, 0x30
000079f9de5ddfb4  vmovaps xmm0, [rsp]
000079f9de5ddfb9  vmovaps xmm1, [rsp+0x10]
000079f9de5ddfbf  vmovaps xmm2, [rsp+0x20]
000079f9de5ddfc5  vmovaps xmm3, [rsp+0x30]
000079f9de5ddfcb  vmovaps xmm4, [rsp+0x40]
000079f9de5ddfd1  vmovaps xmm5, [rsp+0x50]
000079f9de5ddfd7  vmovaps xmm6, [rsp+0x60]
000079f9de5ddfdd  vmovaps xmm8, [rsp+0x70]
000079f9de5ddfe3  vmovaps xmm9, [rsp+0x80]
000079f9de5ddfec  vmovaps xmm10, [rsp+0x90]
000079f9de5ddff5  vmovaps xmm11, [rsp+0xA0]
000079f9de5ddffe  vmovaps xmm12, [rsp+0xB0]
000079f9de5de007  vmovaps xmm13, [rsp+0xC0]
000079f9de5de010  vmovaps xmm14, [rsp+0xD0]
000079f9de5de019  vmovaps xmm15, [rsp+0xE0]
000079f9de5de022  add rsp, 0xF0
000079f9de5de029  pop r11
000079f9de5de02b  pop r10
000079f9de5de02d  pop r9
000079f9de5de02f  pop r8
000079f9de5de031  pop rsi
000079f9de5de032  pop rdi
000079f9de5de033  pop rdx
000079f9de5de034  pop rcx
000079f9de5de035  pop rax
000079f9de5de036  add rsp, 0x08
000079f9de5de03a  jmp 0x000079F9DE5DC066
000079f9de5de03f  call 0x000079F9DE4B52F0
000079f9de5de044  jmp 0x000079F9DE5DC073
000079f9de5de049  sub rsp, 0x08
000079f9de5de04d  push rax
000079f9de5de04e  push rcx
000079f9de5de04f  push rdx
000079f9de5de050  push rdi
000079f9de5de051  push rsi
000079f9de5de052  push r8
000079f9de5de054  push r9
000079f9de5de056  push r10
000079f9de5de058  push r11
000079f9de5de05a  sub rsp, 0xF0
000079f9de5de061  vmovaps [rsp], xmm0
000079f9de5de066  vmovaps [rsp+0x10], xmm1
000079f9de5de06c  vmovaps [rsp+0x20], xmm2
000079f9de5de072  vmovaps [rsp+0x30], xmm3
000079f9de5de078  vmovaps [rsp+0x40], xmm4
000079f9de5de07e  vmovaps [rsp+0x50], xmm5
000079f9de5de084  vmovaps [rsp+0x60], xmm6
000079f9de5de08a  vmovaps [rsp+0x70], xmm7
000079f9de5de090  vmovaps [rsp+0x80], xmm8
000079f9de5de099  vmovaps [rsp+0x90], xmm9
000079f9de5de0a2  vmovaps [rsp+0xA0], xmm10
000079f9de5de0ab  vmovaps [rsp+0xB0], xmm11
000079f9de5de0b4  vmovaps [rsp+0xC0], xmm12
000079f9de5de0bd  vmovaps [rsp+0xD0], xmm13
000079f9de5de0c6  vmovaps [rsp+0xE0], xmm14
000079f9de5de0cf  sub rsp, 0x30
000079f9de5de0d3  movaps [rsp], xmm15
000079f9de5de0d8  movaps [rsp+0x10], xmm5
000079f9de5de0dd  movaps [rsp+0x20], xmm3
000079f9de5de0e2  lea rdi, [rsp]
000079f9de5de0e6  mov esi, 0x00
000079f9de5de0eb  mov rax, 0x56D56FF59530
000079f9de5de0f5  call rax
000079f9de5de0f7  movaps xmm15, [rsp]
000079f9de5de0fc  add rsp, 0x30
000079f9de5de100  vmovaps xmm0, [rsp]
000079f9de5de105  vmovaps xmm1, [rsp+0x10]
000079f9de5de10b  vmovaps xmm2, [rsp+0x20]
000079f9de5de111  vmovaps xmm3, [rsp+0x30]
000079f9de5de117  vmovaps xmm4, [rsp+0x40]
000079f9de5de11d  vmovaps xmm5, [rsp+0x50]
000079f9de5de123  vmovaps xmm6, [rsp+0x60]
000079f9de5de129  vmovaps xmm7, [rsp+0x70]
000079f9de5de12f  vmovaps xmm8, [rsp+0x80]
000079f9de5de138  vmovaps xmm9, [rsp+0x90]
000079f9de5de141  vmovaps xmm10, [rsp+0xA0]
000079f9de5de14a  vmovaps xmm11, [rsp+0xB0]
000079f9de5de153  vmovaps xmm12, [rsp+0xC0]
000079f9de5de15c  vmovaps xmm13, [rsp+0xD0]
000079f9de5de165  vmovaps xmm14, [rsp+0xE0]
000079f9de5de16e  add rsp, 0xF0
000079f9de5de175  pop r11
000079f9de5de177  pop r10
000079f9de5de179  pop r9
000079f9de5de17b  pop r8
000079f9de5de17d  pop rsi
000079f9de5de17e  pop rdi
000079f9de5de17f  pop rdx
000079f9de5de180  pop rcx
000079f9de5de181  pop rax
000079f9de5de182  add rsp, 0x08
000079f9de5de186  jmp 0x000079F9DE5DC099
000079f9de5de18b  sub rsp, 0x08
000079f9de5de18f  push rax
000079f9de5de190  push rcx
000079f9de5de191  push rdx
000079f9de5de192  push rdi
000079f9de5de193  push rsi
000079f9de5de194  push r8
000079f9de5de196  push r9
000079f9de5de198  push r10
000079f9de5de19a  push r11
000079f9de5de19c  sub rsp, 0xF0
000079f9de5de1a3  vmovaps [rsp], xmm0
000079f9de5de1a8  vmovaps [rsp+0x10], xmm2
000079f9de5de1ae  vmovaps [rsp+0x20], xmm3
000079f9de5de1b4  vmovaps [rsp+0x30], xmm4
000079f9de5de1ba  vmovaps [rsp+0x40], xmm5
000079f9de5de1c0  vmovaps [rsp+0x50], xmm6
000079f9de5de1c6  vmovaps [rsp+0x60], xmm7
000079f9de5de1cc  vmovaps [rsp+0x70], xmm8
000079f9de5de1d2  vmovaps [rsp+0x80], xmm9
000079f9de5de1db  vmovaps [rsp+0x90], xmm10
000079f9de5de1e4  vmovaps [rsp+0xA0], xmm11
000079f9de5de1ed  vmovaps [rsp+0xB0], xmm12
000079f9de5de1f6  vmovaps [rsp+0xC0], xmm13
000079f9de5de1ff  vmovaps [rsp+0xD0], xmm14
000079f9de5de208  vmovaps [rsp+0xE0], xmm15
000079f9de5de211  sub rsp, 0x30
000079f9de5de215  movaps [rsp], xmm1
000079f9de5de219  movaps [rsp+0x10], xmm5
000079f9de5de21e  movaps [rsp+0x20], xmm4
000079f9de5de223  lea rdi, [rsp]
000079f9de5de227  mov esi, 0x00
000079f9de5de22c  mov rax, 0x56D56FF59530
000079f9de5de236  call rax
000079f9de5de238  movaps xmm1, [rsp]
000079f9de5de23c  add rsp, 0x30
000079f9de5de240  vmovaps xmm0, [rsp]
000079f9de5de245  vmovaps xmm2, [rsp+0x10]
000079f9de5de24b  vmovaps xmm3, [rsp+0x20]
000079f9de5de251  vmovaps xmm4, [rsp+0x30]
000079f9de5de257  vmovaps xmm5, [rsp+0x40]
000079f9de5de25d  vmovaps xmm6, [rsp+0x50]
000079f9de5de263  vmovaps xmm7, [rsp+0x60]
000079f9de5de269  vmovaps xmm8, [rsp+0x70]
000079f9de5de26f  vmovaps xmm9, [rsp+0x80]
000079f9de5de278  vmovaps xmm10, [rsp+0x90]
000079f9de5de281  vmovaps xmm11, [rsp+0xA0]
000079f9de5de28a  vmovaps xmm12, [rsp+0xB0]
000079f9de5de293  vmovaps xmm13, [rsp+0xC0]
000079f9de5de29c  vmovaps xmm14, [rsp+0xD0]
000079f9de5de2a5  vmovaps xmm15, [rsp+0xE0]
000079f9de5de2ae  add rsp, 0xF0
000079f9de5de2b5  pop r11
000079f9de5de2b7  pop r10
000079f9de5de2b9  pop r9
000079f9de5de2bb  pop r8
000079f9de5de2bd  pop rsi
000079f9de5de2be  pop rdi
000079f9de5de2bf  pop rdx
000079f9de5de2c0  pop rcx
000079f9de5de2c1  pop rax
000079f9de5de2c2  add rsp, 0x08
000079f9de5de2c6  jmp 0x000079F9DE5DC0B9
000079f9de5de2cb  sub rsp, 0x08
000079f9de5de2cf  push rax
000079f9de5de2d0  push rcx
000079f9de5de2d1  push rdx
000079f9de5de2d2  push rdi
000079f9de5de2d3  push rsi
000079f9de5de2d4  push r8
000079f9de5de2d6  push r9
000079f9de5de2d8  push r10
000079f9de5de2da  push r11
000079f9de5de2dc  sub rsp, 0xF0
000079f9de5de2e3  vmovaps [rsp], xmm0
000079f9de5de2e8  vmovaps [rsp+0x10], xmm1
000079f9de5de2ee  vmovaps [rsp+0x20], xmm2
000079f9de5de2f4  vmovaps [rsp+0x30], xmm3
000079f9de5de2fa  vmovaps [rsp+0x40], xmm5
000079f9de5de300  vmovaps [rsp+0x50], xmm6
000079f9de5de306  vmovaps [rsp+0x60], xmm7
000079f9de5de30c  vmovaps [rsp+0x70], xmm8
000079f9de5de312  vmovaps [rsp+0x80], xmm9
000079f9de5de31b  vmovaps [rsp+0x90], xmm10
000079f9de5de324  vmovaps [rsp+0xA0], xmm11
000079f9de5de32d  vmovaps [rsp+0xB0], xmm12
000079f9de5de336  vmovaps [rsp+0xC0], xmm13
000079f9de5de33f  vmovaps [rsp+0xD0], xmm14
000079f9de5de348  vmovaps [rsp+0xE0], xmm15
000079f9de5de351  sub rsp, 0x30
000079f9de5de355  movaps [rsp], xmm4
000079f9de5de359  movaps [rsp+0x10], xmm3
000079f9de5de35e  movaps [rsp+0x20], xmm5
000079f9de5de363  lea rdi, [rsp]
000079f9de5de367  mov esi, 0x00
000079f9de5de36c  mov rax, 0x56D56FF59530
000079f9de5de376  call rax
000079f9de5de378  movaps xmm4, [rsp]
000079f9de5de37c  add rsp, 0x30
000079f9de5de380  vmovaps xmm0, [rsp]
000079f9de5de385  vmovaps xmm1, [rsp+0x10]
000079f9de5de38b  vmovaps xmm2, [rsp+0x20]
000079f9de5de391  vmovaps xmm3, [rsp+0x30]
000079f9de5de397  vmovaps xmm5, [rsp+0x40]
000079f9de5de39d  vmovaps xmm6, [rsp+0x50]
000079f9de5de3a3  vmovaps xmm7, [rsp+0x60]
000079f9de5de3a9  vmovaps xmm8, [rsp+0x70]
000079f9de5de3af  vmovaps xmm9, [rsp+0x80]
000079f9de5de3b8  vmovaps xmm10, [rsp+0x90]
000079f9de5de3c1  vmovaps xmm11, [rsp+0xA0]
000079f9de5de3ca  vmovaps xmm12, [rsp+0xB0]
000079f9de5de3d3  vmovaps xmm13, [rsp+0xC0]
000079f9de5de3dc  vmovaps xmm14, [rsp+0xD0]
000079f9de5de3e5  vmovaps xmm15, [rsp+0xE0]
000079f9de5de3ee  add rsp, 0xF0
000079f9de5de3f5  pop r11
000079f9de5de3f7  pop r10
000079f9de5de3f9  pop r9
000079f9de5de3fb  pop r8
000079f9de5de3fd  pop rsi
000079f9de5de3fe  pop rdi
000079f9de5de3ff  pop rdx
000079f9de5de400  pop rcx
000079f9de5de401  pop rax
000079f9de5de402  add rsp, 0x08
000079f9de5de406  jmp 0x000079F9DE5DC107
000079f9de5de40b  call 0x000079F9DE4B52F0
000079f9de5de410  jmp 0x000079F9DE5DC114
000079f9de5de415  sub rsp, 0x08
000079f9de5de419  push rax
000079f9de5de41a  push rcx
000079f9de5de41b  push rdx
000079f9de5de41c  push rdi
000079f9de5de41d  push rsi
000079f9de5de41e  push r8
000079f9de5de420  push r9
000079f9de5de422  push r10
000079f9de5de424  push r11
000079f9de5de426  sub rsp, 0xF0
000079f9de5de42d  vmovaps [rsp], xmm0
000079f9de5de432  vmovaps [rsp+0x10], xmm1
000079f9de5de438  vmovaps [rsp+0x20], xmm2
000079f9de5de43e  vmovaps [rsp+0x30], xmm3
000079f9de5de444  vmovaps [rsp+0x40], xmm4
000079f9de5de44a  vmovaps [rsp+0x50], xmm6
000079f9de5de450  vmovaps [rsp+0x60], xmm7
000079f9de5de456  vmovaps [rsp+0x70], xmm8
000079f9de5de45c  vmovaps [rsp+0x80], xmm9
000079f9de5de465  vmovaps [rsp+0x90], xmm10
000079f9de5de46e  vmovaps [rsp+0xA0], xmm11
000079f9de5de477  vmovaps [rsp+0xB0], xmm12
000079f9de5de480  vmovaps [rsp+0xC0], xmm13
000079f9de5de489  vmovaps [rsp+0xD0], xmm14
000079f9de5de492  vmovaps [rsp+0xE0], xmm15
000079f9de5de49b  sub rsp, 0x30
000079f9de5de49f  movaps [rsp], xmm5
000079f9de5de4a3  movaps [rsp+0x10], xmm6
000079f9de5de4a8  movaps [rsp+0x20], xmm3
000079f9de5de4ad  lea rdi, [rsp]
000079f9de5de4b1  mov esi, 0x00
000079f9de5de4b6  mov rax, 0x56D56FF59530
000079f9de5de4c0  call rax
000079f9de5de4c2  movaps xmm5, [rsp]
000079f9de5de4c6  add rsp, 0x30
000079f9de5de4ca  vmovaps xmm0, [rsp]
000079f9de5de4cf  vmovaps xmm1, [rsp+0x10]
000079f9de5de4d5  vmovaps xmm2, [rsp+0x20]
000079f9de5de4db  vmovaps xmm3, [rsp+0x30]
000079f9de5de4e1  vmovaps xmm4, [rsp+0x40]
000079f9de5de4e7  vmovaps xmm6, [rsp+0x50]
000079f9de5de4ed  vmovaps xmm7, [rsp+0x60]
000079f9de5de4f3  vmovaps xmm8, [rsp+0x70]
000079f9de5de4f9  vmovaps xmm9, [rsp+0x80]
000079f9de5de502  vmovaps xmm10, [rsp+0x90]
000079f9de5de50b  vmovaps xmm11, [rsp+0xA0]
000079f9de5de514  vmovaps xmm12, [rsp+0xB0]
000079f9de5de51d  vmovaps xmm13, [rsp+0xC0]
000079f9de5de526  vmovaps xmm14, [rsp+0xD0]
000079f9de5de52f  vmovaps xmm15, [rsp+0xE0]
000079f9de5de538  add rsp, 0xF0
000079f9de5de53f  pop r11
000079f9de5de541  pop r10
000079f9de5de543  pop r9
000079f9de5de545  pop r8
000079f9de5de547  pop rsi
000079f9de5de548  pop rdi
000079f9de5de549  pop rdx
000079f9de5de54a  pop rcx
000079f9de5de54b  pop rax
000079f9de5de54c  add rsp, 0x08
000079f9de5de550  jmp 0x000079F9DE5DC13A
000079f9de5de555  sub rsp, 0x08
000079f9de5de559  push rax
000079f9de5de55a  push rcx
000079f9de5de55b  push rdx
000079f9de5de55c  push rdi
000079f9de5de55d  push rsi
000079f9de5de55e  push r8
000079f9de5de560  push r9
000079f9de5de562  push r10
000079f9de5de564  push r11
000079f9de5de566  sub rsp, 0xF0
000079f9de5de56d  vmovaps [rsp], xmm0
000079f9de5de572  vmovaps [rsp+0x10], xmm1
000079f9de5de578  vmovaps [rsp+0x20], xmm2
000079f9de5de57e  vmovaps [rsp+0x30], xmm3
000079f9de5de584  vmovaps [rsp+0x40], xmm4
000079f9de5de58a  vmovaps [rsp+0x50], xmm5
000079f9de5de590  vmovaps [rsp+0x60], xmm7
000079f9de5de596  vmovaps [rsp+0x70], xmm8
000079f9de5de59c  vmovaps [rsp+0x80], xmm9
000079f9de5de5a5  vmovaps [rsp+0x90], xmm10
000079f9de5de5ae  vmovaps [rsp+0xA0], xmm11
000079f9de5de5b7  vmovaps [rsp+0xB0], xmm12
000079f9de5de5c0  vmovaps [rsp+0xC0], xmm13
000079f9de5de5c9  vmovaps [rsp+0xD0], xmm14
000079f9de5de5d2  vmovaps [rsp+0xE0], xmm15
000079f9de5de5db  sub rsp, 0x30
000079f9de5de5df  movaps [rsp], xmm6
000079f9de5de5e3  movaps [rsp+0x10], xmm9
000079f9de5de5e9  movaps [rsp+0x20], xmm1
000079f9de5de5ee  lea rdi, [rsp]
000079f9de5de5f2  mov esi, 0x00
000079f9de5de5f7  mov rax, 0x56D56FF59530
000079f9de5de601  call rax
000079f9de5de603  movaps xmm6, [rsp]
000079f9de5de607  add rsp, 0x30
000079f9de5de60b  vmovaps xmm0, [rsp]
000079f9de5de610  vmovaps xmm1, [rsp+0x10]
000079f9de5de616  vmovaps xmm2, [rsp+0x20]
000079f9de5de61c  vmovaps xmm3, [rsp+0x30]
000079f9de5de622  vmovaps xmm4, [rsp+0x40]
000079f9de5de628  vmovaps xmm5, [rsp+0x50]
000079f9de5de62e  vmovaps xmm7, [rsp+0x60]
000079f9de5de634  vmovaps xmm8, [rsp+0x70]
000079f9de5de63a  vmovaps xmm9, [rsp+0x80]
000079f9de5de643  vmovaps xmm10, [rsp+0x90]
000079f9de5de64c  vmovaps xmm11, [rsp+0xA0]
000079f9de5de655  vmovaps xmm12, [rsp+0xB0]
000079f9de5de65e  vmovaps xmm13, [rsp+0xC0]
000079f9de5de667  vmovaps xmm14, [rsp+0xD0]
000079f9de5de670  vmovaps xmm15, [rsp+0xE0]
000079f9de5de679  add rsp, 0xF0
000079f9de5de680  pop r11
000079f9de5de682  pop r10
000079f9de5de684  pop r9
000079f9de5de686  pop r8
000079f9de5de688  pop rsi
000079f9de5de689  pop rdi
000079f9de5de68a  pop rdx
000079f9de5de68b  pop rcx
000079f9de5de68c  pop rax
000079f9de5de68d  add rsp, 0x08
000079f9de5de691  jmp 0x000079F9DE5DC15E
000079f9de5de696  sub rsp, 0x08
000079f9de5de69a  push rax
000079f9de5de69b  push rcx
000079f9de5de69c  push rdx
000079f9de5de69d  push rdi
000079f9de5de69e  push rsi
000079f9de5de69f  push r8
000079f9de5de6a1  push r9
000079f9de5de6a3  push r10
000079f9de5de6a5  push r11
000079f9de5de6a7  sub rsp, 0xF0
000079f9de5de6ae  vmovaps [rsp], xmm0
000079f9de5de6b3  vmovaps [rsp+0x10], xmm1
000079f9de5de6b9  vmovaps [rsp+0x20], xmm2
000079f9de5de6bf  vmovaps [rsp+0x30], xmm3
000079f9de5de6c5  vmovaps [rsp+0x40], xmm4
000079f9de5de6cb  vmovaps [rsp+0x50], xmm5
000079f9de5de6d1  vmovaps [rsp+0x60], xmm6
000079f9de5de6d7  vmovaps [rsp+0x70], xmm7
000079f9de5de6dd  vmovaps [rsp+0x80], xmm8
000079f9de5de6e6  vmovaps [rsp+0x90], xmm10
000079f9de5de6ef  vmovaps [rsp+0xA0], xmm11
000079f9de5de6f8  vmovaps [rsp+0xB0], xmm12
000079f9de5de701  vmovaps [rsp+0xC0], xmm13
000079f9de5de70a  vmovaps [rsp+0xD0], xmm14
000079f9de5de713  vmovaps [rsp+0xE0], xmm15
000079f9de5de71c  sub rsp, 0x30
000079f9de5de720  movaps [rsp], xmm9
000079f9de5de725  movaps [rsp+0x10], xmm3
000079f9de5de72a  movaps [rsp+0x20], xmm1
000079f9de5de72f  lea rdi, [rsp]
000079f9de5de733  mov esi, 0x00
000079f9de5de738  mov rax, 0x56D56FF59530
000079f9de5de742  call rax
000079f9de5de744  movaps xmm9, [rsp]
000079f9de5de749  add rsp, 0x30
000079f9de5de74d  vmovaps xmm0, [rsp]
000079f9de5de752  vmovaps xmm1, [rsp+0x10]
000079f9de5de758  vmovaps xmm2, [rsp+0x20]
000079f9de5de75e  vmovaps xmm3, [rsp+0x30]
000079f9de5de764  vmovaps xmm4, [rsp+0x40]
000079f9de5de76a  vmovaps xmm5, [rsp+0x50]
000079f9de5de770  vmovaps xmm6, [rsp+0x60]
000079f9de5de776  vmovaps xmm7, [rsp+0x70]
000079f9de5de77c  vmovaps xmm8, [rsp+0x80]
000079f9de5de785  vmovaps xmm10, [rsp+0x90]
000079f9de5de78e  vmovaps xmm11, [rsp+0xA0]
000079f9de5de797  vmovaps xmm12, [rsp+0xB0]
000079f9de5de7a0  vmovaps xmm13, [rsp+0xC0]
000079f9de5de7a9  vmovaps xmm14, [rsp+0xD0]
000079f9de5de7b2  vmovaps xmm15, [rsp+0xE0]
000079f9de5de7bb  add rsp, 0xF0
000079f9de5de7c2  pop r11
000079f9de5de7c4  pop r10
000079f9de5de7c6  pop r9
000079f9de5de7c8  pop r8
000079f9de5de7ca  pop rsi
000079f9de5de7cb  pop rdi
000079f9de5de7cc  pop rdx
000079f9de5de7cd  pop rcx
000079f9de5de7ce  pop rax
000079f9de5de7cf  add rsp, 0x08
000079f9de5de7d3  jmp 0x000079F9DE5DC1AA
000079f9de5de7d8  call 0x000079F9DE4B52F0
000079f9de5de7dd  jmp 0x000079F9DE5DC1B7
000079f9de5de7e2  sub rsp, 0x08
000079f9de5de7e6  push rax
000079f9de5de7e7  push rcx
000079f9de5de7e8  push rdx
000079f9de5de7e9  push rdi
000079f9de5de7ea  push rsi
000079f9de5de7eb  push r8
000079f9de5de7ed  push r9
000079f9de5de7ef  push r10
000079f9de5de7f1  push r11
000079f9de5de7f3  sub rsp, 0xF0
000079f9de5de7fa  vmovaps [rsp], xmm0
000079f9de5de7ff  vmovaps [rsp+0x10], xmm1
000079f9de5de805  vmovaps [rsp+0x20], xmm2
000079f9de5de80b  vmovaps [rsp+0x30], xmm3
000079f9de5de811  vmovaps [rsp+0x40], xmm4
000079f9de5de817  vmovaps [rsp+0x50], xmm5
000079f9de5de81d  vmovaps [rsp+0x60], xmm6
000079f9de5de823  vmovaps [rsp+0x70], xmm7
000079f9de5de829  vmovaps [rsp+0x80], xmm8
000079f9de5de832  vmovaps [rsp+0x90], xmm9
000079f9de5de83b  vmovaps [rsp+0xA0], xmm10
000079f9de5de844  vmovaps [rsp+0xB0], xmm11
000079f9de5de84d  vmovaps [rsp+0xC0], xmm12
000079f9de5de856  vmovaps [rsp+0xD0], xmm13
000079f9de5de85f  vmovaps [rsp+0xE0], xmm14
000079f9de5de868  sub rsp, 0x30
000079f9de5de86c  movaps [rsp], xmm15
000079f9de5de871  movaps [rsp+0x10], xmm3
000079f9de5de876  movaps [rsp+0x20], xmm7
000079f9de5de87b  lea rdi, [rsp]
000079f9de5de87f  mov esi, 0x00
000079f9de5de884  mov rax, 0x56D56FF59530
000079f9de5de88e  call rax
000079f9de5de890  movaps xmm15, [rsp]
000079f9de5de895  add rsp, 0x30
000079f9de5de899  vmovaps xmm0, [rsp]
000079f9de5de89e  vmovaps xmm1, [rsp+0x10]
000079f9de5de8a4  vmovaps xmm2, [rsp+0x20]
000079f9de5de8aa  vmovaps xmm3, [rsp+0x30]
000079f9de5de8b0  vmovaps xmm4, [rsp+0x40]
000079f9de5de8b6  vmovaps xmm5, [rsp+0x50]
000079f9de5de8bc  vmovaps xmm6, [rsp+0x60]
000079f9de5de8c2  vmovaps xmm7, [rsp+0x70]
000079f9de5de8c8  vmovaps xmm8, [rsp+0x80]
000079f9de5de8d1  vmovaps xmm9, [rsp+0x90]
000079f9de5de8da  vmovaps xmm10, [rsp+0xA0]
000079f9de5de8e3  vmovaps xmm11, [rsp+0xB0]
000079f9de5de8ec  vmovaps xmm12, [rsp+0xC0]
000079f9de5de8f5  vmovaps xmm13, [rsp+0xD0]
000079f9de5de8fe  vmovaps xmm14, [rsp+0xE0]
000079f9de5de907  add rsp, 0xF0
000079f9de5de90e  pop r11
000079f9de5de910  pop r10
000079f9de5de912  pop r9
000079f9de5de914  pop r8
000079f9de5de916  pop rsi
000079f9de5de917  pop rdi
000079f9de5de918  pop rdx
000079f9de5de919  pop rcx
000079f9de5de91a  pop rax
000079f9de5de91b  add rsp, 0x08
000079f9de5de91f  jmp 0x000079F9DE5DC1E3
000079f9de5de924  sub rsp, 0x08
000079f9de5de928  push rax
000079f9de5de929  push rcx
000079f9de5de92a  push rdx
000079f9de5de92b  push rdi
000079f9de5de92c  push rsi
000079f9de5de92d  push r8
000079f9de5de92f  push r9
000079f9de5de931  push r10
000079f9de5de933  push r11
000079f9de5de935  sub rsp, 0xF0
000079f9de5de93c  vmovaps [rsp], xmm0
000079f9de5de941  vmovaps [rsp+0x10], xmm1
000079f9de5de947  vmovaps [rsp+0x20], xmm2
000079f9de5de94d  vmovaps [rsp+0x30], xmm4
000079f9de5de953  vmovaps [rsp+0x40], xmm5
000079f9de5de959  vmovaps [rsp+0x50], xmm6
000079f9de5de95f  vmovaps [rsp+0x60], xmm7
000079f9de5de965  vmovaps [rsp+0x70], xmm8
000079f9de5de96b  vmovaps [rsp+0x80], xmm9
000079f9de5de974  vmovaps [rsp+0x90], xmm10
000079f9de5de97d  vmovaps [rsp+0xA0], xmm11
000079f9de5de986  vmovaps [rsp+0xB0], xmm12
000079f9de5de98f  vmovaps [rsp+0xC0], xmm13
000079f9de5de998  vmovaps [rsp+0xD0], xmm14
000079f9de5de9a1  vmovaps [rsp+0xE0], xmm15
000079f9de5de9aa  sub rsp, 0x30
000079f9de5de9ae  movaps [rsp], xmm3
000079f9de5de9b2  movaps [rsp+0x10], xmm1
000079f9de5de9b7  movaps [rsp+0x20], xmm15
000079f9de5de9bd  lea rdi, [rsp]
000079f9de5de9c1  mov esi, 0x00
000079f9de5de9c6  mov rax, 0x56D56FF59530
000079f9de5de9d0  call rax
000079f9de5de9d2  movaps xmm3, [rsp]
000079f9de5de9d6  add rsp, 0x30
000079f9de5de9da  vmovaps xmm0, [rsp]
000079f9de5de9df  vmovaps xmm1, [rsp+0x10]
000079f9de5de9e5  vmovaps xmm2, [rsp+0x20]
000079f9de5de9eb  vmovaps xmm4, [rsp+0x30]
000079f9de5de9f1  vmovaps xmm5, [rsp+0x40]
000079f9de5de9f7  vmovaps xmm6, [rsp+0x50]
000079f9de5de9fd  vmovaps xmm7, [rsp+0x60]
000079f9de5dea03  vmovaps xmm8, [rsp+0x70]
000079f9de5dea09  vmovaps xmm9, [rsp+0x80]
000079f9de5dea12  vmovaps xmm10, [rsp+0x90]
000079f9de5dea1b  vmovaps xmm11, [rsp+0xA0]
000079f9de5dea24  vmovaps xmm12, [rsp+0xB0]
000079f9de5dea2d  vmovaps xmm13, [rsp+0xC0]
000079f9de5dea36  vmovaps xmm14, [rsp+0xD0]
000079f9de5dea3f  vmovaps xmm15, [rsp+0xE0]
000079f9de5dea48  add rsp, 0xF0
000079f9de5dea4f  pop r11
000079f9de5dea51  pop r10
000079f9de5dea53  pop r9
000079f9de5dea55  pop r8
000079f9de5dea57  pop rsi
000079f9de5dea58  pop rdi
000079f9de5dea59  pop rdx
000079f9de5dea5a  pop rcx
000079f9de5dea5b  pop rax
000079f9de5dea5c  add rsp, 0x08
000079f9de5dea60  jmp 0x000079F9DE5DC272
000079f9de5dea65  call 0x000079F9DE4B52F0
000079f9de5dea6a  jmp 0x000079F9DE5DC27C
000079f9de5dea6f  sub rsp, 0x08
000079f9de5dea73  push rax
000079f9de5dea74  push rcx
000079f9de5dea75  push rdx
000079f9de5dea76  push rdi
000079f9de5dea77  push rsi
000079f9de5dea78  push r8
000079f9de5dea7a  push r9
000079f9de5dea7c  push r10
000079f9de5dea7e  push r11
000079f9de5dea80  sub rsp, 0xF0
000079f9de5dea87  vmovaps [rsp], xmm0
000079f9de5dea8c  vmovaps [rsp+0x10], xmm1
000079f9de5dea92  vmovaps [rsp+0x20], xmm2
000079f9de5dea98  vmovaps [rsp+0x30], xmm3
000079f9de5dea9e  vmovaps [rsp+0x40], xmm4
000079f9de5deaa4  vmovaps [rsp+0x50], xmm5
000079f9de5deaaa  vmovaps [rsp+0x60], xmm6
000079f9de5deab0  vmovaps [rsp+0x70], xmm7
000079f9de5deab6  vmovaps [rsp+0x80], xmm8
000079f9de5deabf  vmovaps [rsp+0x90], xmm9
000079f9de5deac8  vmovaps [rsp+0xA0], xmm10
000079f9de5dead1  vmovaps [rsp+0xB0], xmm11
000079f9de5deada  vmovaps [rsp+0xC0], xmm12
000079f9de5deae3  vmovaps [rsp+0xD0], xmm13
000079f9de5deaec  vmovaps [rsp+0xE0], xmm14
000079f9de5deaf5  sub rsp, 0x30
000079f9de5deaf9  movaps [rsp], xmm15
000079f9de5deafe  movaps [rsp+0x10], xmm14
000079f9de5deb04  movaps [rsp+0x20], xmm4
000079f9de5deb09  lea rdi, [rsp]
000079f9de5deb0d  mov esi, 0x00
000079f9de5deb12  mov rax, 0x56D56FF59530
000079f9de5deb1c  call rax
000079f9de5deb1e  movaps xmm15, [rsp]
000079f9de5deb23  add rsp, 0x30
000079f9de5deb27  vmovaps xmm0, [rsp]
000079f9de5deb2c  vmovaps xmm1, [rsp+0x10]
000079f9de5deb32  vmovaps xmm2, [rsp+0x20]
000079f9de5deb38  vmovaps xmm3, [rsp+0x30]
000079f9de5deb3e  vmovaps xmm4, [rsp+0x40]
000079f9de5deb44  vmovaps xmm5, [rsp+0x50]
000079f9de5deb4a  vmovaps xmm6, [rsp+0x60]
000079f9de5deb50  vmovaps xmm7, [rsp+0x70]
000079f9de5deb56  vmovaps xmm8, [rsp+0x80]
000079f9de5deb5f  vmovaps xmm9, [rsp+0x90]
000079f9de5deb68  vmovaps xmm10, [rsp+0xA0]
000079f9de5deb71  vmovaps xmm11, [rsp+0xB0]
000079f9de5deb7a  vmovaps xmm12, [rsp+0xC0]
000079f9de5deb83  vmovaps xmm13, [rsp+0xD0]
000079f9de5deb8c  vmovaps xmm14, [rsp+0xE0]
000079f9de5deb95  add rsp, 0xF0
000079f9de5deb9c  pop r11
000079f9de5deb9e  pop r10
000079f9de5deba0  pop r9
000079f9de5deba2  pop r8
000079f9de5deba4  pop rsi
000079f9de5deba5  pop rdi
000079f9de5deba6  pop rdx
000079f9de5deba7  pop rcx
000079f9de5deba8  pop rax
000079f9de5deba9  add rsp, 0x08
000079f9de5debad  jmp 0x000079F9DE5DC2AA
000079f9de5debb2  sub rsp, 0x08
000079f9de5debb6  push rax
000079f9de5debb7  push rcx
000079f9de5debb8  push rdx
000079f9de5debb9  push rdi
000079f9de5debba  push rsi
000079f9de5debbb  push r8
000079f9de5debbd  push r9
000079f9de5debbf  push r10
000079f9de5debc1  push r11
000079f9de5debc3  sub rsp, 0xF0
000079f9de5debca  vmovaps [rsp], xmm0
000079f9de5debcf  vmovaps [rsp+0x10], xmm1
000079f9de5debd5  vmovaps [rsp+0x20], xmm2
000079f9de5debdb  vmovaps [rsp+0x30], xmm3
000079f9de5debe1  vmovaps [rsp+0x40], xmm4
000079f9de5debe7  vmovaps [rsp+0x50], xmm5
000079f9de5debed  vmovaps [rsp+0x60], xmm6
000079f9de5debf3  vmovaps [rsp+0x70], xmm7
000079f9de5debf9  vmovaps [rsp+0x80], xmm8
000079f9de5dec02  vmovaps [rsp+0x90], xmm9
000079f9de5dec0b  vmovaps [rsp+0xA0], xmm10
000079f9de5dec14  vmovaps [rsp+0xB0], xmm11
000079f9de5dec1d  vmovaps [rsp+0xC0], xmm12
000079f9de5dec26  vmovaps [rsp+0xD0], xmm13
000079f9de5dec2f  vmovaps [rsp+0xE0], xmm15
000079f9de5dec38  sub rsp, 0x30
000079f9de5dec3c  movaps [rsp], xmm14
000079f9de5dec41  movaps [rsp+0x10], xmm2
000079f9de5dec46  movaps [rsp+0x20], xmm1
000079f9de5dec4b  lea rdi, [rsp]
000079f9de5dec4f  mov esi, 0x00
000079f9de5dec54  mov rax, 0x56D56FF59530
000079f9de5dec5e  call rax
000079f9de5dec60  movaps xmm14, [rsp]
000079f9de5dec65  add rsp, 0x30
000079f9de5dec69  vmovaps xmm0, [rsp]
000079f9de5dec6e  vmovaps xmm1, [rsp+0x10]
000079f9de5dec74  vmovaps xmm2, [rsp+0x20]
000079f9de5dec7a  vmovaps xmm3, [rsp+0x30]
000079f9de5dec80  vmovaps xmm4, [rsp+0x40]
000079f9de5dec86  vmovaps xmm5, [rsp+0x50]
000079f9de5dec8c  vmovaps xmm6, [rsp+0x60]
000079f9de5dec92  vmovaps xmm7, [rsp+0x70]
000079f9de5dec98  vmovaps xmm8, [rsp+0x80]
000079f9de5deca1  vmovaps xmm9, [rsp+0x90]
000079f9de5decaa  vmovaps xmm10, [rsp+0xA0]
000079f9de5decb3  vmovaps xmm11, [rsp+0xB0]
000079f9de5decbc  vmovaps xmm12, [rsp+0xC0]
000079f9de5decc5  vmovaps xmm13, [rsp+0xD0]
000079f9de5decce  vmovaps xmm15, [rsp+0xE0]
000079f9de5decd7  add rsp, 0xF0
000079f9de5decde  pop r11
000079f9de5dece0  pop r10
000079f9de5dece2  pop r9
000079f9de5dece4  pop r8
000079f9de5dece6  pop rsi
000079f9de5dece7  pop rdi
000079f9de5dece8  pop rdx
000079f9de5dece9  pop rcx
000079f9de5decea  pop rax
000079f9de5deceb  add rsp, 0x08
000079f9de5decef  jmp 0x000079F9DE5DC2D0
000079f9de5decf4  sub rsp, 0x08
000079f9de5decf8  push rax
000079f9de5decf9  push rcx
000079f9de5decfa  push rdx
000079f9de5decfb  push rdi
000079f9de5decfc  push rsi
000079f9de5decfd  push r8
000079f9de5decff  push r9
000079f9de5ded01  push r10
000079f9de5ded03  push r11
000079f9de5ded05  sub rsp, 0xF0
000079f9de5ded0c  vmovaps [rsp], xmm0
000079f9de5ded11  vmovaps [rsp+0x10], xmm2
000079f9de5ded17  vmovaps [rsp+0x20], xmm3
000079f9de5ded1d  vmovaps [rsp+0x30], xmm4
000079f9de5ded23  vmovaps [rsp+0x40], xmm5
000079f9de5ded29  vmovaps [rsp+0x50], xmm6
000079f9de5ded2f  vmovaps [rsp+0x60], xmm7
000079f9de5ded35  vmovaps [rsp+0x70], xmm8
000079f9de5ded3b  vmovaps [rsp+0x80], xmm9
000079f9de5ded44  vmovaps [rsp+0x90], xmm10
000079f9de5ded4d  vmovaps [rsp+0xA0], xmm11
000079f9de5ded56  vmovaps [rsp+0xB0], xmm12
000079f9de5ded5f  vmovaps [rsp+0xC0], xmm13
000079f9de5ded68  vmovaps [rsp+0xD0], xmm14
000079f9de5ded71  vmovaps [rsp+0xE0], xmm15
000079f9de5ded7a  sub rsp, 0x30
000079f9de5ded7e  movaps [rsp], xmm1
000079f9de5ded82  movaps [rsp+0x10], xmm4
000079f9de5ded87  movaps [rsp+0x20], xmm9
000079f9de5ded8d  lea rdi, [rsp]
000079f9de5ded91  mov esi, 0x00
000079f9de5ded96  mov rax, 0x56D56FF59530
000079f9de5deda0  call rax
000079f9de5deda2  movaps xmm1, [rsp]
000079f9de5deda6  add rsp, 0x30
000079f9de5dedaa  vmovaps xmm0, [rsp]
000079f9de5dedaf  vmovaps xmm2, [rsp+0x10]
000079f9de5dedb5  vmovaps xmm3, [rsp+0x20]
000079f9de5dedbb  vmovaps xmm4, [rsp+0x30]
000079f9de5dedc1  vmovaps xmm5, [rsp+0x40]
000079f9de5dedc7  vmovaps xmm6, [rsp+0x50]
000079f9de5dedcd  vmovaps xmm7, [rsp+0x60]
000079f9de5dedd3  vmovaps xmm8, [rsp+0x70]
000079f9de5dedd9  vmovaps xmm9, [rsp+0x80]
000079f9de5dede2  vmovaps xmm10, [rsp+0x90]
000079f9de5dedeb  vmovaps xmm11, [rsp+0xA0]
000079f9de5dedf4  vmovaps xmm12, [rsp+0xB0]
000079f9de5dedfd  vmovaps xmm13, [rsp+0xC0]
000079f9de5dee06  vmovaps xmm14, [rsp+0xD0]
000079f9de5dee0f  vmovaps xmm15, [rsp+0xE0]
000079f9de5dee18  add rsp, 0xF0
000079f9de5dee1f  pop r11
000079f9de5dee21  pop r10
000079f9de5dee23  pop r9
000079f9de5dee25  pop r8
000079f9de5dee27  pop rsi
000079f9de5dee28  pop rdi
000079f9de5dee29  pop rdx
000079f9de5dee2a  pop rcx
000079f9de5dee2b  pop rax
000079f9de5dee2c  add rsp, 0x08
000079f9de5dee30  jmp 0x000079F9DE5DC2EE
000079f9de5dee35  sub rsp, 0x08
000079f9de5dee39  push rax
000079f9de5dee3a  push rcx
000079f9de5dee3b  push rdx
000079f9de5dee3c  push rdi
000079f9de5dee3d  push rsi
000079f9de5dee3e  push r8
000079f9de5dee40  push r9
000079f9de5dee42  push r10
000079f9de5dee44  push r11
000079f9de5dee46  sub rsp, 0xF0
000079f9de5dee4d  vmovaps [rsp], xmm0
000079f9de5dee52  vmovaps [rsp+0x10], xmm1
000079f9de5dee58  vmovaps [rsp+0x20], xmm2
000079f9de5dee5e  vmovaps [rsp+0x30], xmm3
000079f9de5dee64  vmovaps [rsp+0x40], xmm5
000079f9de5dee6a  vmovaps [rsp+0x50], xmm6
000079f9de5dee70  vmovaps [rsp+0x60], xmm7
000079f9de5dee76  vmovaps [rsp+0x70], xmm8
000079f9de5dee7c  vmovaps [rsp+0x80], xmm9
000079f9de5dee85  vmovaps [rsp+0x90], xmm10
000079f9de5dee8e  vmovaps [rsp+0xA0], xmm11
000079f9de5dee97  vmovaps [rsp+0xB0], xmm12
000079f9de5deea0  vmovaps [rsp+0xC0], xmm13
000079f9de5deea9  vmovaps [rsp+0xD0], xmm14
000079f9de5deeb2  vmovaps [rsp+0xE0], xmm15
000079f9de5deebb  sub rsp, 0x30
000079f9de5deebf  movaps [rsp], xmm4
000079f9de5deec3  movaps [rsp+0x10], xmm2
000079f9de5deec8  movaps [rsp+0x20], xmm9
000079f9de5deece  lea rdi, [rsp]
000079f9de5deed2  mov esi, 0x00
000079f9de5deed7  mov rax, 0x56D56FF59530
000079f9de5deee1  call rax
000079f9de5deee3  movaps xmm4, [rsp]
000079f9de5deee7  add rsp, 0x30
000079f9de5deeeb  vmovaps xmm0, [rsp]
000079f9de5deef0  vmovaps xmm1, [rsp+0x10]
000079f9de5deef6  vmovaps xmm2, [rsp+0x20]
000079f9de5deefc  vmovaps xmm3, [rsp+0x30]
000079f9de5def02  vmovaps xmm5, [rsp+0x40]
000079f9de5def08  vmovaps xmm6, [rsp+0x50]
000079f9de5def0e  vmovaps xmm7, [rsp+0x60]
000079f9de5def14  vmovaps xmm8, [rsp+0x70]
000079f9de5def1a  vmovaps xmm9, [rsp+0x80]
000079f9de5def23  vmovaps xmm10, [rsp+0x90]
000079f9de5def2c  vmovaps xmm11, [rsp+0xA0]
000079f9de5def35  vmovaps xmm12, [rsp+0xB0]
000079f9de5def3e  vmovaps xmm13, [rsp+0xC0]
000079f9de5def47  vmovaps xmm14, [rsp+0xD0]
000079f9de5def50  vmovaps xmm15, [rsp+0xE0]
000079f9de5def59  add rsp, 0xF0
000079f9de5def60  pop r11
000079f9de5def62  pop r10
000079f9de5def64  pop r9
000079f9de5def66  pop r8
000079f9de5def68  pop rsi
000079f9de5def69  pop rdi
000079f9de5def6a  pop rdx
000079f9de5def6b  pop rcx
000079f9de5def6c  pop rax
000079f9de5def6d  add rsp, 0x08
000079f9de5def71  jmp 0x000079F9DE5DC31E
000079f9de5def76  sub rsp, 0x08
000079f9de5def7a  push rax
000079f9de5def7b  push rcx
000079f9de5def7c  push rdx
000079f9de5def7d  push rdi
000079f9de5def7e  push rsi
000079f9de5def7f  push r8
000079f9de5def81  push r9
000079f9de5def83  push r10
000079f9de5def85  push r11
000079f9de5def87  sub rsp, 0xF0
000079f9de5def8e  vmovaps [rsp], xmm0
000079f9de5def93  vmovaps [rsp+0x10], xmm1
000079f9de5def99  vmovaps [rsp+0x20], xmm2
000079f9de5def9f  vmovaps [rsp+0x30], xmm3
000079f9de5defa5  vmovaps [rsp+0x40], xmm4
000079f9de5defab  vmovaps [rsp+0x50], xmm5
000079f9de5defb1  vmovaps [rsp+0x60], xmm6
000079f9de5defb7  vmovaps [rsp+0x70], xmm7
000079f9de5defbd  vmovaps [rsp+0x80], xmm8
000079f9de5defc6  vmovaps [rsp+0x90], xmm10
000079f9de5defcf  vmovaps [rsp+0xA0], xmm11
000079f9de5defd8  vmovaps [rsp+0xB0], xmm12
000079f9de5defe1  vmovaps [rsp+0xC0], xmm13
000079f9de5defea  vmovaps [rsp+0xD0], xmm14
000079f9de5deff3  vmovaps [rsp+0xE0], xmm15
000079f9de5deffc  sub rsp, 0x30
000079f9de5df000  movaps [rsp], xmm9
000079f9de5df005  movaps [rsp+0x10], xmm2
000079f9de5df00a  movaps [rsp+0x20], xmm1
000079f9de5df00f  lea rdi, [rsp]
000079f9de5df013  mov esi, 0x00
000079f9de5df018  mov rax, 0x56D56FF59530
000079f9de5df022  call rax
000079f9de5df024  movaps xmm9, [rsp]
000079f9de5df029  add rsp, 0x30
000079f9de5df02d  vmovaps xmm0, [rsp]
000079f9de5df032  vmovaps xmm1, [rsp+0x10]
000079f9de5df038  vmovaps xmm2, [rsp+0x20]
000079f9de5df03e  vmovaps xmm3, [rsp+0x30]
000079f9de5df044  vmovaps xmm4, [rsp+0x40]
000079f9de5df04a  vmovaps xmm5, [rsp+0x50]
000079f9de5df050  vmovaps xmm6, [rsp+0x60]
000079f9de5df056  vmovaps xmm7, [rsp+0x70]
000079f9de5df05c  vmovaps xmm8, [rsp+0x80]
000079f9de5df065  vmovaps xmm10, [rsp+0x90]
000079f9de5df06e  vmovaps xmm11, [rsp+0xA0]
000079f9de5df077  vmovaps xmm12, [rsp+0xB0]
000079f9de5df080  vmovaps xmm13, [rsp+0xC0]
000079f9de5df089  vmovaps xmm14, [rsp+0xD0]
000079f9de5df092  vmovaps xmm15, [rsp+0xE0]
000079f9de5df09b  add rsp, 0xF0
000079f9de5df0a2  pop r11
000079f9de5df0a4  pop r10
000079f9de5df0a6  pop r9
000079f9de5df0a8  pop r8
000079f9de5df0aa  pop rsi
000079f9de5df0ab  pop rdi
000079f9de5df0ac  pop rdx
000079f9de5df0ad  pop rcx
000079f9de5df0ae  pop rax
000079f9de5df0af  add rsp, 0x08
000079f9de5df0b3  jmp 0x000079F9DE5DC354
000079f9de5df0b8  sub rsp, 0x08
000079f9de5df0bc  push rax
000079f9de5df0bd  push rcx
000079f9de5df0be  push rdx
000079f9de5df0bf  push rdi
000079f9de5df0c0  push rsi
000079f9de5df0c1  push r8
000079f9de5df0c3  push r9
000079f9de5df0c5  push r10
000079f9de5df0c7  push r11
000079f9de5df0c9  sub rsp, 0xF0
000079f9de5df0d0  vmovaps [rsp], xmm0
000079f9de5df0d5  vmovaps [rsp+0x10], xmm2
000079f9de5df0db  vmovaps [rsp+0x20], xmm3
000079f9de5df0e1  vmovaps [rsp+0x30], xmm4
000079f9de5df0e7  vmovaps [rsp+0x40], xmm5
000079f9de5df0ed  vmovaps [rsp+0x50], xmm6
000079f9de5df0f3  vmovaps [rsp+0x60], xmm7
000079f9de5df0f9  vmovaps [rsp+0x70], xmm8
000079f9de5df0ff  vmovaps [rsp+0x80], xmm9
000079f9de5df108  vmovaps [rsp+0x90], xmm10
000079f9de5df111  vmovaps [rsp+0xA0], xmm11
000079f9de5df11a  vmovaps [rsp+0xB0], xmm12
000079f9de5df123  vmovaps [rsp+0xC0], xmm13
000079f9de5df12c  vmovaps [rsp+0xD0], xmm14
000079f9de5df135  vmovaps [rsp+0xE0], xmm15
000079f9de5df13e  sub rsp, 0x30
000079f9de5df142  movaps [rsp], xmm1
000079f9de5df146  movaps [rsp+0x10], xmm15
000079f9de5df14c  movaps [rsp+0x20], xmm6
000079f9de5df151  lea rdi, [rsp]
000079f9de5df155  mov esi, 0x00
000079f9de5df15a  mov rax, 0x56D56FF59530
000079f9de5df164  call rax
000079f9de5df166  movaps xmm1, [rsp]
000079f9de5df16a  add rsp, 0x30
000079f9de5df16e  vmovaps xmm0, [rsp]
000079f9de5df173  vmovaps xmm2, [rsp+0x10]
000079f9de5df179  vmovaps xmm3, [rsp+0x20]
000079f9de5df17f  vmovaps xmm4, [rsp+0x30]
000079f9de5df185  vmovaps xmm5, [rsp+0x40]
000079f9de5df18b  vmovaps xmm6, [rsp+0x50]
000079f9de5df191  vmovaps xmm7, [rsp+0x60]
000079f9de5df197  vmovaps xmm8, [rsp+0x70]
000079f9de5df19d  vmovaps xmm9, [rsp+0x80]
000079f9de5df1a6  vmovaps xmm10, [rsp+0x90]
000079f9de5df1af  vmovaps xmm11, [rsp+0xA0]
000079f9de5df1b8  vmovaps xmm12, [rsp+0xB0]
000079f9de5df1c1  vmovaps xmm13, [rsp+0xC0]
000079f9de5df1ca  vmovaps xmm14, [rsp+0xD0]
000079f9de5df1d3  vmovaps xmm15, [rsp+0xE0]
000079f9de5df1dc  add rsp, 0xF0
000079f9de5df1e3  pop r11
000079f9de5df1e5  pop r10
000079f9de5df1e7  pop r9
000079f9de5df1e9  pop r8
000079f9de5df1eb  pop rsi
000079f9de5df1ec  pop rdi
000079f9de5df1ed  pop rdx
000079f9de5df1ee  pop rcx
000079f9de5df1ef  pop rax
000079f9de5df1f0  add rsp, 0x08
000079f9de5df1f4  jmp 0x000079F9DE5DC375
000079f9de5df1f9  sub rsp, 0x08
000079f9de5df1fd  push rax
000079f9de5df1fe  push rcx
000079f9de5df1ff  push rdx
000079f9de5df200  push rdi
000079f9de5df201  push rsi
000079f9de5df202  push r8
000079f9de5df204  push r9
000079f9de5df206  push r10
000079f9de5df208  push r11
000079f9de5df20a  sub rsp, 0xF0
000079f9de5df211  vmovaps [rsp], xmm0
000079f9de5df216  vmovaps [rsp+0x10], xmm1
000079f9de5df21c  vmovaps [rsp+0x20], xmm2
000079f9de5df222  vmovaps [rsp+0x30], xmm3
000079f9de5df228  vmovaps [rsp+0x40], xmm4
000079f9de5df22e  vmovaps [rsp+0x50], xmm5
000079f9de5df234  vmovaps [rsp+0x60], xmm6
000079f9de5df23a  vmovaps [rsp+0x70], xmm7
000079f9de5df240  vmovaps [rsp+0x80], xmm8
000079f9de5df249  vmovaps [rsp+0x90], xmm9
000079f9de5df252  vmovaps [rsp+0xA0], xmm10
000079f9de5df25b  vmovaps [rsp+0xB0], xmm11
000079f9de5df264  vmovaps [rsp+0xC0], xmm12
000079f9de5df26d  vmovaps [rsp+0xD0], xmm13
000079f9de5df276  vmovaps [rsp+0xE0], xmm14
000079f9de5df27f  sub rsp, 0x30
000079f9de5df283  movaps [rsp], xmm15
000079f9de5df288  movaps [rsp+0x10], xmm5
000079f9de5df28d  movaps [rsp+0x20], xmm3
000079f9de5df292  lea rdi, [rsp]
000079f9de5df296  mov esi, 0x00
000079f9de5df29b  mov rax, 0x56D56FF59530
000079f9de5df2a5  call rax
000079f9de5df2a7  movaps xmm15, [rsp]
000079f9de5df2ac  add rsp, 0x30
000079f9de5df2b0  vmovaps xmm0, [rsp]
000079f9de5df2b5  vmovaps xmm1, [rsp+0x10]
000079f9de5df2bb  vmovaps xmm2, [rsp+0x20]
000079f9de5df2c1  vmovaps xmm3, [rsp+0x30]
000079f9de5df2c7  vmovaps xmm4, [rsp+0x40]
000079f9de5df2cd  vmovaps xmm5, [rsp+0x50]
000079f9de5df2d3  vmovaps xmm6, [rsp+0x60]
000079f9de5df2d9  vmovaps xmm7, [rsp+0x70]
000079f9de5df2df  vmovaps xmm8, [rsp+0x80]
000079f9de5df2e8  vmovaps xmm9, [rsp+0x90]
000079f9de5df2f1  vmovaps xmm10, [rsp+0xA0]
000079f9de5df2fa  vmovaps xmm11, [rsp+0xB0]
000079f9de5df303  vmovaps xmm12, [rsp+0xC0]
000079f9de5df30c  vmovaps xmm13, [rsp+0xD0]
000079f9de5df315  vmovaps xmm14, [rsp+0xE0]
000079f9de5df31e  add rsp, 0xF0
000079f9de5df325  pop r11
000079f9de5df327  pop r10
000079f9de5df329  pop r9
000079f9de5df32b  pop r8
000079f9de5df32d  pop rsi
000079f9de5df32e  pop rdi
000079f9de5df32f  pop rdx
000079f9de5df330  pop rcx
000079f9de5df331  pop rax
000079f9de5df332  add rsp, 0x08
000079f9de5df336  jmp 0x000079F9DE5DC38F
000079f9de5df33b  sub rsp, 0x08
000079f9de5df33f  push rax
000079f9de5df340  push rcx
000079f9de5df341  push rdx
000079f9de5df342  push rdi
000079f9de5df343  push rsi
000079f9de5df344  push r8
000079f9de5df346  push r9
000079f9de5df348  push r10
000079f9de5df34a  push r11
000079f9de5df34c  sub rsp, 0xF0
000079f9de5df353  vmovaps [rsp], xmm0
000079f9de5df358  vmovaps [rsp+0x10], xmm1
000079f9de5df35e  vmovaps [rsp+0x20], xmm2
000079f9de5df364  vmovaps [rsp+0x30], xmm3
000079f9de5df36a  vmovaps [rsp+0x40], xmm4
000079f9de5df370  vmovaps [rsp+0x50], xmm6
000079f9de5df376  vmovaps [rsp+0x60], xmm7
000079f9de5df37c  vmovaps [rsp+0x70], xmm8
000079f9de5df382  vmovaps [rsp+0x80], xmm9
000079f9de5df38b  vmovaps [rsp+0x90], xmm10
000079f9de5df394  vmovaps [rsp+0xA0], xmm11
000079f9de5df39d  vmovaps [rsp+0xB0], xmm12
000079f9de5df3a6  vmovaps [rsp+0xC0], xmm13
000079f9de5df3af  vmovaps [rsp+0xD0], xmm14
000079f9de5df3b8  vmovaps [rsp+0xE0], xmm15
000079f9de5df3c1  sub rsp, 0x30
000079f9de5df3c5  movaps [rsp], xmm5
000079f9de5df3c9  movaps [rsp+0x10], xmm8
000079f9de5df3cf  movaps [rsp+0x20], xmm6
000079f9de5df3d4  lea rdi, [rsp]
000079f9de5df3d8  mov esi, 0x00
000079f9de5df3dd  mov rax, 0x56D56FF59530
000079f9de5df3e7  call rax
000079f9de5df3e9  movaps xmm5, [rsp]
000079f9de5df3ed  add rsp, 0x30
000079f9de5df3f1  vmovaps xmm0, [rsp]
000079f9de5df3f6  vmovaps xmm1, [rsp+0x10]
000079f9de5df3fc  vmovaps xmm2, [rsp+0x20]
000079f9de5df402  vmovaps xmm3, [rsp+0x30]
000079f9de5df408  vmovaps xmm4, [rsp+0x40]
000079f9de5df40e  vmovaps xmm6, [rsp+0x50]
000079f9de5df414  vmovaps xmm7, [rsp+0x60]
000079f9de5df41a  vmovaps xmm8, [rsp+0x70]
000079f9de5df420  vmovaps xmm9, [rsp+0x80]
000079f9de5df429  vmovaps xmm10, [rsp+0x90]
000079f9de5df432  vmovaps xmm11, [rsp+0xA0]
000079f9de5df43b  vmovaps xmm12, [rsp+0xB0]
000079f9de5df444  vmovaps xmm13, [rsp+0xC0]
000079f9de5df44d  vmovaps xmm14, [rsp+0xD0]
000079f9de5df456  vmovaps xmm15, [rsp+0xE0]
000079f9de5df45f  add rsp, 0xF0
000079f9de5df466  pop r11
000079f9de5df468  pop r10
000079f9de5df46a  pop r9
000079f9de5df46c  pop r8
000079f9de5df46e  pop rsi
000079f9de5df46f  pop rdi
000079f9de5df470  pop rdx
000079f9de5df471  pop rcx
000079f9de5df472  pop rax
000079f9de5df473  add rsp, 0x08
000079f9de5df477  jmp 0x000079F9DE5DC3B3
000079f9de5df47c  sub rsp, 0x08
000079f9de5df480  push rax
000079f9de5df481  push rcx
000079f9de5df482  push rdx
000079f9de5df483  push rdi
000079f9de5df484  push rsi
000079f9de5df485  push r8
000079f9de5df487  push r9
000079f9de5df489  push r10
000079f9de5df48b  push r11
000079f9de5df48d  sub rsp, 0xF0
000079f9de5df494  vmovaps [rsp], xmm0
000079f9de5df499  vmovaps [rsp+0x10], xmm1
000079f9de5df49f  vmovaps [rsp+0x20], xmm2
000079f9de5df4a5  vmovaps [rsp+0x30], xmm3
000079f9de5df4ab  vmovaps [rsp+0x40], xmm4
000079f9de5df4b1  vmovaps [rsp+0x50], xmm5
000079f9de5df4b7  vmovaps [rsp+0x60], xmm7
000079f9de5df4bd  vmovaps [rsp+0x70], xmm8
000079f9de5df4c3  vmovaps [rsp+0x80], xmm9
000079f9de5df4cc  vmovaps [rsp+0x90], xmm10
000079f9de5df4d5  vmovaps [rsp+0xA0], xmm11
000079f9de5df4de  vmovaps [rsp+0xB0], xmm12
000079f9de5df4e7  vmovaps [rsp+0xC0], xmm13
000079f9de5df4f0  vmovaps [rsp+0xD0], xmm14
000079f9de5df4f9  vmovaps [rsp+0xE0], xmm15
000079f9de5df502  sub rsp, 0x30
000079f9de5df506  movaps [rsp], xmm6
000079f9de5df50a  movaps [rsp+0x10], xmm10
000079f9de5df510  movaps [rsp+0x20], xmm8
000079f9de5df516  lea rdi, [rsp]
000079f9de5df51a  mov esi, 0x00
000079f9de5df51f  mov rax, 0x56D56FF59530
000079f9de5df529  call rax
000079f9de5df52b  movaps xmm6, [rsp]
000079f9de5df52f  add rsp, 0x30
000079f9de5df533  vmovaps xmm0, [rsp]
000079f9de5df538  vmovaps xmm1, [rsp+0x10]
000079f9de5df53e  vmovaps xmm2, [rsp+0x20]
000079f9de5df544  vmovaps xmm3, [rsp+0x30]
000079f9de5df54a  vmovaps xmm4, [rsp+0x40]
000079f9de5df550  vmovaps xmm5, [rsp+0x50]
000079f9de5df556  vmovaps xmm7, [rsp+0x60]
000079f9de5df55c  vmovaps xmm8, [rsp+0x70]
000079f9de5df562  vmovaps xmm9, [rsp+0x80]
000079f9de5df56b  vmovaps xmm10, [rsp+0x90]
000079f9de5df574  vmovaps xmm11, [rsp+0xA0]
000079f9de5df57d  vmovaps xmm12, [rsp+0xB0]
000079f9de5df586  vmovaps xmm13, [rsp+0xC0]
000079f9de5df58f  vmovaps xmm14, [rsp+0xD0]
000079f9de5df598  vmovaps xmm15, [rsp+0xE0]
000079f9de5df5a1  add rsp, 0xF0
000079f9de5df5a8  pop r11
000079f9de5df5aa  pop r10
000079f9de5df5ac  pop r9
000079f9de5df5ae  pop r8
000079f9de5df5b0  pop rsi
000079f9de5df5b1  pop rdi
000079f9de5df5b2  pop rdx
000079f9de5df5b3  pop rcx
000079f9de5df5b4  pop rax
000079f9de5df5b5  add rsp, 0x08
000079f9de5df5b9  jmp 0x000079F9DE5DC3D8
000079f9de5df5be  sub rsp, 0x08
000079f9de5df5c2  push rax
000079f9de5df5c3  push rcx
000079f9de5df5c4  push rdx
000079f9de5df5c5  push rdi
000079f9de5df5c6  push rsi
000079f9de5df5c7  push r8
000079f9de5df5c9  push r9
000079f9de5df5cb  push r10
000079f9de5df5cd  push r11
000079f9de5df5cf  sub rsp, 0xF0
000079f9de5df5d6  vmovaps [rsp], xmm0
000079f9de5df5db  vmovaps [rsp+0x10], xmm1
000079f9de5df5e1  vmovaps [rsp+0x20], xmm2
000079f9de5df5e7  vmovaps [rsp+0x30], xmm3
000079f9de5df5ed  vmovaps [rsp+0x40], xmm4
000079f9de5df5f3  vmovaps [rsp+0x50], xmm5
000079f9de5df5f9  vmovaps [rsp+0x60], xmm6
000079f9de5df5ff  vmovaps [rsp+0x70], xmm7
000079f9de5df605  vmovaps [rsp+0x80], xmm8
000079f9de5df60e  vmovaps [rsp+0x90], xmm9
000079f9de5df617  vmovaps [rsp+0xA0], xmm11
000079f9de5df620  vmovaps [rsp+0xB0], xmm12
000079f9de5df629  vmovaps [rsp+0xC0], xmm13
000079f9de5df632  vmovaps [rsp+0xD0], xmm14
000079f9de5df63b  vmovaps [rsp+0xE0], xmm15
000079f9de5df644  sub rsp, 0x30
000079f9de5df648  movaps [rsp], xmm10
000079f9de5df64d  movaps [rsp+0x10], xmm8
000079f9de5df653  movaps [rsp+0x20], xmm14
000079f9de5df659  lea rdi, [rsp]
000079f9de5df65d  mov esi, 0x00
000079f9de5df662  mov rax, 0x56D56FF59530
000079f9de5df66c  call rax
000079f9de5df66e  movaps xmm10, [rsp]
000079f9de5df673  add rsp, 0x30
000079f9de5df677  vmovaps xmm0, [rsp]
000079f9de5df67c  vmovaps xmm1, [rsp+0x10]
000079f9de5df682  vmovaps xmm2, [rsp+0x20]
000079f9de5df688  vmovaps xmm3, [rsp+0x30]
000079f9de5df68e  vmovaps xmm4, [rsp+0x40]
000079f9de5df694  vmovaps xmm5, [rsp+0x50]
000079f9de5df69a  vmovaps xmm6, [rsp+0x60]
000079f9de5df6a0  vmovaps xmm7, [rsp+0x70]
000079f9de5df6a6  vmovaps xmm8, [rsp+0x80]
000079f9de5df6af  vmovaps xmm9, [rsp+0x90]
000079f9de5df6b8  vmovaps xmm11, [rsp+0xA0]
000079f9de5df6c1  vmovaps xmm12, [rsp+0xB0]
000079f9de5df6ca  vmovaps xmm13, [rsp+0xC0]
000079f9de5df6d3  vmovaps xmm14, [rsp+0xD0]
000079f9de5df6dc  vmovaps xmm15, [rsp+0xE0]
000079f9de5df6e5  add rsp, 0xF0
000079f9de5df6ec  pop r11
000079f9de5df6ee  pop r10
000079f9de5df6f0  pop r9
000079f9de5df6f2  pop r8
000079f9de5df6f4  pop rsi
000079f9de5df6f5  pop rdi
000079f9de5df6f6  pop rdx
000079f9de5df6f7  pop rcx
000079f9de5df6f8  pop rax
000079f9de5df6f9  add rsp, 0x08
000079f9de5df6fd  jmp 0x000079F9DE5DC3F8
000079f9de5df702  sub rsp, 0x08
000079f9de5df706  push rax
000079f9de5df707  push rcx
000079f9de5df708  push rdx
000079f9de5df709  push rdi
000079f9de5df70a  push rsi
000079f9de5df70b  push r8
000079f9de5df70d  push r9
000079f9de5df70f  push r10
000079f9de5df711  push r11
000079f9de5df713  sub rsp, 0xF0
000079f9de5df71a  vmovaps [rsp], xmm0
000079f9de5df71f  vmovaps [rsp+0x10], xmm1
000079f9de5df725  vmovaps [rsp+0x20], xmm2
000079f9de5df72b  vmovaps [rsp+0x30], xmm3
000079f9de5df731  vmovaps [rsp+0x40], xmm4
000079f9de5df737  vmovaps [rsp+0x50], xmm5
000079f9de5df73d  vmovaps [rsp+0x60], xmm6
000079f9de5df743  vmovaps [rsp+0x70], xmm7
000079f9de5df749  vmovaps [rsp+0x80], xmm8
000079f9de5df752  vmovaps [rsp+0x90], xmm9
000079f9de5df75b  vmovaps [rsp+0xA0], xmm10
000079f9de5df764  vmovaps [rsp+0xB0], xmm11
000079f9de5df76d  vmovaps [rsp+0xC0], xmm12
000079f9de5df776  vmovaps [rsp+0xD0], xmm13
000079f9de5df77f  vmovaps [rsp+0xE0], xmm15
000079f9de5df788  sub rsp, 0x30
000079f9de5df78c  movaps [rsp], xmm14
000079f9de5df791  movaps [rsp+0x10], xmm8
000079f9de5df797  movaps [rsp+0x20], xmm4
000079f9de5df79c  lea rdi, [rsp]
000079f9de5df7a0  mov esi, 0x00
000079f9de5df7a5  mov rax, 0x56D56FF59530
000079f9de5df7af  call rax
000079f9de5df7b1  movaps xmm14, [rsp]
000079f9de5df7b6  add rsp, 0x30
000079f9de5df7ba  vmovaps xmm0, [rsp]
000079f9de5df7bf  vmovaps xmm1, [rsp+0x10]
000079f9de5df7c5  vmovaps xmm2, [rsp+0x20]
000079f9de5df7cb  vmovaps xmm3, [rsp+0x30]
000079f9de5df7d1  vmovaps xmm4, [rsp+0x40]
000079f9de5df7d7  vmovaps xmm5, [rsp+0x50]
000079f9de5df7dd  vmovaps xmm6, [rsp+0x60]
000079f9de5df7e3  vmovaps xmm7, [rsp+0x70]
000079f9de5df7e9  vmovaps xmm8, [rsp+0x80]
000079f9de5df7f2  vmovaps xmm9, [rsp+0x90]
000079f9de5df7fb  vmovaps xmm10, [rsp+0xA0]
000079f9de5df804  vmovaps xmm11, [rsp+0xB0]
000079f9de5df80d  vmovaps xmm12, [rsp+0xC0]
000079f9de5df816  vmovaps xmm13, [rsp+0xD0]
000079f9de5df81f  vmovaps xmm15, [rsp+0xE0]
000079f9de5df828  add rsp, 0xF0
000079f9de5df82f  pop r11
000079f9de5df831  pop r10
000079f9de5df833  pop r9
000079f9de5df835  pop r8
000079f9de5df837  pop rsi
000079f9de5df838  pop rdi
000079f9de5df839  pop rdx
000079f9de5df83a  pop rcx
000079f9de5df83b  pop rax
000079f9de5df83c  add rsp, 0x08
000079f9de5df840  jmp 0x000079F9DE5DC418
000079f9de5df845  sub rsp, 0x08
000079f9de5df849  push rax
000079f9de5df84a  push rcx
000079f9de5df84b  push rdx
000079f9de5df84c  push rdi
000079f9de5df84d  push rsi
000079f9de5df84e  push r8
000079f9de5df850  push r9
000079f9de5df852  push r10
000079f9de5df854  push r11
000079f9de5df856  sub rsp, 0xF0
000079f9de5df85d  vmovaps [rsp], xmm0
000079f9de5df862  vmovaps [rsp+0x10], xmm1
000079f9de5df868  vmovaps [rsp+0x20], xmm2
000079f9de5df86e  vmovaps [rsp+0x30], xmm3
000079f9de5df874  vmovaps [rsp+0x40], xmm5
000079f9de5df87a  vmovaps [rsp+0x50], xmm6
000079f9de5df880  vmovaps [rsp+0x60], xmm7
000079f9de5df886  vmovaps [rsp+0x70], xmm8
000079f9de5df88c  vmovaps [rsp+0x80], xmm9
000079f9de5df895  vmovaps [rsp+0x90], xmm10
000079f9de5df89e  vmovaps [rsp+0xA0], xmm11
000079f9de5df8a7  vmovaps [rsp+0xB0], xmm12
000079f9de5df8b0  vmovaps [rsp+0xC0], xmm13
000079f9de5df8b9  vmovaps [rsp+0xD0], xmm14
000079f9de5df8c2  vmovaps [rsp+0xE0], xmm15
000079f9de5df8cb  sub rsp, 0x30
000079f9de5df8cf  movaps [rsp], xmm4
000079f9de5df8d3  movaps [rsp+0x10], xmm13
000079f9de5df8d9  movaps [rsp+0x20], xmm8
000079f9de5df8df  lea rdi, [rsp]
000079f9de5df8e3  mov esi, 0x00
000079f9de5df8e8  mov rax, 0x56D56FF59530
000079f9de5df8f2  call rax
000079f9de5df8f4  movaps xmm4, [rsp]
000079f9de5df8f8  add rsp, 0x30
000079f9de5df8fc  vmovaps xmm0, [rsp]
000079f9de5df901  vmovaps xmm1, [rsp+0x10]
000079f9de5df907  vmovaps xmm2, [rsp+0x20]
000079f9de5df90d  vmovaps xmm3, [rsp+0x30]
000079f9de5df913  vmovaps xmm5, [rsp+0x40]
000079f9de5df919  vmovaps xmm6, [rsp+0x50]
000079f9de5df91f  vmovaps xmm7, [rsp+0x60]
000079f9de5df925  vmovaps xmm8, [rsp+0x70]
000079f9de5df92b  vmovaps xmm9, [rsp+0x80]
000079f9de5df934  vmovaps xmm10, [rsp+0x90]
000079f9de5df93d  vmovaps xmm11, [rsp+0xA0]
000079f9de5df946  vmovaps xmm12, [rsp+0xB0]
000079f9de5df94f  vmovaps xmm13, [rsp+0xC0]
000079f9de5df958  vmovaps xmm14, [rsp+0xD0]
000079f9de5df961  vmovaps xmm15, [rsp+0xE0]
000079f9de5df96a  add rsp, 0xF0
000079f9de5df971  pop r11
000079f9de5df973  pop r10
000079f9de5df975  pop r9
000079f9de5df977  pop r8
000079f9de5df979  pop rsi
000079f9de5df97a  pop rdi
000079f9de5df97b  pop rdx
000079f9de5df97c  pop rcx
000079f9de5df97d  pop rax
000079f9de5df97e  add rsp, 0x08
000079f9de5df982  jmp 0x000079F9DE5DC43D
000079f9de5df987  sub rsp, 0x08
000079f9de5df98b  push rax
000079f9de5df98c  push rcx
000079f9de5df98d  push rdx
000079f9de5df98e  push rdi
000079f9de5df98f  push rsi
000079f9de5df990  push r8
000079f9de5df992  push r9
000079f9de5df994  push r10
000079f9de5df996  push r11
000079f9de5df998  sub rsp, 0xF0
000079f9de5df99f  vmovaps [rsp], xmm0
000079f9de5df9a4  vmovaps [rsp+0x10], xmm1
000079f9de5df9aa  vmovaps [rsp+0x20], xmm2
000079f9de5df9b0  vmovaps [rsp+0x30], xmm3
000079f9de5df9b6  vmovaps [rsp+0x40], xmm4
000079f9de5df9bc  vmovaps [rsp+0x50], xmm5
000079f9de5df9c2  vmovaps [rsp+0x60], xmm6
000079f9de5df9c8  vmovaps [rsp+0x70], xmm7
000079f9de5df9ce  vmovaps [rsp+0x80], xmm8
000079f9de5df9d7  vmovaps [rsp+0x90], xmm9
000079f9de5df9e0  vmovaps [rsp+0xA0], xmm10
000079f9de5df9e9  vmovaps [rsp+0xB0], xmm11
000079f9de5df9f2  vmovaps [rsp+0xC0], xmm12
000079f9de5df9fb  vmovaps [rsp+0xD0], xmm14
000079f9de5dfa04  vmovaps [rsp+0xE0], xmm15
000079f9de5dfa0d  sub rsp, 0x30
000079f9de5dfa11  movaps [rsp], xmm13
000079f9de5dfa16  movaps [rsp+0x10], xmm15
000079f9de5dfa1c  movaps [rsp+0x20], xmm9
000079f9de5dfa22  lea rdi, [rsp]
000079f9de5dfa26  mov esi, 0x00
000079f9de5dfa2b  mov rax, 0x56D56FF59530
000079f9de5dfa35  call rax
000079f9de5dfa37  movaps xmm13, [rsp]
000079f9de5dfa3c  add rsp, 0x30
000079f9de5dfa40  vmovaps xmm0, [rsp]
000079f9de5dfa45  vmovaps xmm1, [rsp+0x10]
000079f9de5dfa4b  vmovaps xmm2, [rsp+0x20]
000079f9de5dfa51  vmovaps xmm3, [rsp+0x30]
000079f9de5dfa57  vmovaps xmm4, [rsp+0x40]
000079f9de5dfa5d  vmovaps xmm5, [rsp+0x50]
000079f9de5dfa63  vmovaps xmm6, [rsp+0x60]
000079f9de5dfa69  vmovaps xmm7, [rsp+0x70]
000079f9de5dfa6f  vmovaps xmm8, [rsp+0x80]
000079f9de5dfa78  vmovaps xmm9, [rsp+0x90]
000079f9de5dfa81  vmovaps xmm10, [rsp+0xA0]
000079f9de5dfa8a  vmovaps xmm11, [rsp+0xB0]
000079f9de5dfa93  vmovaps xmm12, [rsp+0xC0]
000079f9de5dfa9c  vmovaps xmm14, [rsp+0xD0]
000079f9de5dfaa5  vmovaps xmm15, [rsp+0xE0]
000079f9de5dfaae  add rsp, 0xF0
000079f9de5dfab5  pop r11
000079f9de5dfab7  pop r10
000079f9de5dfab9  pop r9
000079f9de5dfabb  pop r8
000079f9de5dfabd  pop rsi
000079f9de5dfabe  pop rdi
000079f9de5dfabf  pop rdx
000079f9de5dfac0  pop rcx
000079f9de5dfac1  pop rax
000079f9de5dfac2  add rsp, 0x08
000079f9de5dfac6  jmp 0x000079F9DE5DC458
000079f9de5dfacb  sub rsp, 0x08
000079f9de5dfacf  push rax
000079f9de5dfad0  push rcx
000079f9de5dfad1  push rdx
000079f9de5dfad2  push rdi
000079f9de5dfad3  push rsi
000079f9de5dfad4  push r8
000079f9de5dfad6  push r9
000079f9de5dfad8  push r10
000079f9de5dfada  push r11
000079f9de5dfadc  sub rsp, 0xF0
000079f9de5dfae3  vmovaps [rsp], xmm0
000079f9de5dfae8  vmovaps [rsp+0x10], xmm1
000079f9de5dfaee  vmovaps [rsp+0x20], xmm2
000079f9de5dfaf4  vmovaps [rsp+0x30], xmm3
000079f9de5dfafa  vmovaps [rsp+0x40], xmm4
000079f9de5dfb00  vmovaps [rsp+0x50], xmm5
000079f9de5dfb06  vmovaps [rsp+0x60], xmm6
000079f9de5dfb0c  vmovaps [rsp+0x70], xmm7
000079f9de5dfb12  vmovaps [rsp+0x80], xmm8
000079f9de5dfb1b  vmovaps [rsp+0x90], xmm9
000079f9de5dfb24  vmovaps [rsp+0xA0], xmm10
000079f9de5dfb2d  vmovaps [rsp+0xB0], xmm11
000079f9de5dfb36  vmovaps [rsp+0xC0], xmm12
000079f9de5dfb3f  vmovaps [rsp+0xD0], xmm13
000079f9de5dfb48  vmovaps [rsp+0xE0], xmm14
000079f9de5dfb51  sub rsp, 0x30
000079f9de5dfb55  movaps [rsp], xmm15
000079f9de5dfb5a  movaps [rsp+0x10], xmm1
000079f9de5dfb5f  movaps [rsp+0x20], xmm5
000079f9de5dfb64  lea rdi, [rsp]
000079f9de5dfb68  mov esi, 0x00
000079f9de5dfb6d  mov rax, 0x56D56FF59530
000079f9de5dfb77  call rax
000079f9de5dfb79  movaps xmm15, [rsp]
000079f9de5dfb7e  add rsp, 0x30
000079f9de5dfb82  vmovaps xmm0, [rsp]
000079f9de5dfb87  vmovaps xmm1, [rsp+0x10]
000079f9de5dfb8d  vmovaps xmm2, [rsp+0x20]
000079f9de5dfb93  vmovaps xmm3, [rsp+0x30]
000079f9de5dfb99  vmovaps xmm4, [rsp+0x40]
000079f9de5dfb9f  vmovaps xmm5, [rsp+0x50]
000079f9de5dfba5  vmovaps xmm6, [rsp+0x60]
000079f9de5dfbab  vmovaps xmm7, [rsp+0x70]
000079f9de5dfbb1  vmovaps xmm8, [rsp+0x80]
000079f9de5dfbba  vmovaps xmm9, [rsp+0x90]
000079f9de5dfbc3  vmovaps xmm10, [rsp+0xA0]
000079f9de5dfbcc  vmovaps xmm11, [rsp+0xB0]
000079f9de5dfbd5  vmovaps xmm12, [rsp+0xC0]
000079f9de5dfbde  vmovaps xmm13, [rsp+0xD0]
000079f9de5dfbe7  vmovaps xmm14, [rsp+0xE0]
000079f9de5dfbf0  add rsp, 0xF0
000079f9de5dfbf7  pop r11
000079f9de5dfbf9  pop r10
000079f9de5dfbfb  pop r9
000079f9de5dfbfd  pop r8
000079f9de5dfbff  pop rsi
000079f9de5dfc00  pop rdi
000079f9de5dfc01  pop rdx
000079f9de5dfc02  pop rcx
000079f9de5dfc03  pop rax
000079f9de5dfc04  add rsp, 0x08
000079f9de5dfc08  jmp 0x000079F9DE5DC473
000079f9de5dfc0d  call 0x000079F9DE4B52F0
000079f9de5dfc12  jmp 0x000079F9DE5DC4CE
000079f9de5dfc17  sub rsp, 0x08
000079f9de5dfc1b  push rax
000079f9de5dfc1c  push rcx
000079f9de5dfc1d  push rdx
000079f9de5dfc1e  push rdi
000079f9de5dfc1f  push rsi
000079f9de5dfc20  push r8
000079f9de5dfc22  push r9
000079f9de5dfc24  push r10
000079f9de5dfc26  push r11
000079f9de5dfc28  sub rsp, 0xF0
000079f9de5dfc2f  vmovaps [rsp], xmm0
000079f9de5dfc34  vmovaps [rsp+0x10], xmm1
000079f9de5dfc3a  vmovaps [rsp+0x20], xmm2
000079f9de5dfc40  vmovaps [rsp+0x30], xmm3
000079f9de5dfc46  vmovaps [rsp+0x40], xmm4
000079f9de5dfc4c  vmovaps [rsp+0x50], xmm5
000079f9de5dfc52  vmovaps [rsp+0x60], xmm6
000079f9de5dfc58  vmovaps [rsp+0x70], xmm7
000079f9de5dfc5e  vmovaps [rsp+0x80], xmm8
000079f9de5dfc67  vmovaps [rsp+0x90], xmm10
000079f9de5dfc70  vmovaps [rsp+0xA0], xmm11
000079f9de5dfc79  vmovaps [rsp+0xB0], xmm12
000079f9de5dfc82  vmovaps [rsp+0xC0], xmm13
000079f9de5dfc8b  vmovaps [rsp+0xD0], xmm14
000079f9de5dfc94  vmovaps [rsp+0xE0], xmm15
000079f9de5dfc9d  sub rsp, 0x30
000079f9de5dfca1  movaps [rsp], xmm9
000079f9de5dfca6  movaps [rsp+0x10], xmm8
000079f9de5dfcac  movaps [rsp+0x20], xmm11
000079f9de5dfcb2  lea rdi, [rsp]
000079f9de5dfcb6  mov esi, 0x00
000079f9de5dfcbb  mov rax, 0x56D56FF59530
000079f9de5dfcc5  call rax
000079f9de5dfcc7  movaps xmm9, [rsp]
000079f9de5dfccc  add rsp, 0x30
000079f9de5dfcd0  vmovaps xmm0, [rsp]
000079f9de5dfcd5  vmovaps xmm1, [rsp+0x10]
000079f9de5dfcdb  vmovaps xmm2, [rsp+0x20]
000079f9de5dfce1  vmovaps xmm3, [rsp+0x30]
000079f9de5dfce7  vmovaps xmm4, [rsp+0x40]
000079f9de5dfced  vmovaps xmm5, [rsp+0x50]
000079f9de5dfcf3  vmovaps xmm6, [rsp+0x60]
000079f9de5dfcf9  vmovaps xmm7, [rsp+0x70]
000079f9de5dfcff  vmovaps xmm8, [rsp+0x80]
000079f9de5dfd08  vmovaps xmm10, [rsp+0x90]
000079f9de5dfd11  vmovaps xmm11, [rsp+0xA0]
000079f9de5dfd1a  vmovaps xmm12, [rsp+0xB0]
000079f9de5dfd23  vmovaps xmm13, [rsp+0xC0]
000079f9de5dfd2c  vmovaps xmm14, [rsp+0xD0]
000079f9de5dfd35  vmovaps xmm15, [rsp+0xE0]
000079f9de5dfd3e  add rsp, 0xF0
000079f9de5dfd45  pop r11
000079f9de5dfd47  pop r10
000079f9de5dfd49  pop r9
000079f9de5dfd4b  pop r8
000079f9de5dfd4d  pop rsi
000079f9de5dfd4e  pop rdi
000079f9de5dfd4f  pop rdx
000079f9de5dfd50  pop rcx
000079f9de5dfd51  pop rax
000079f9de5dfd52  add rsp, 0x08
000079f9de5dfd56  jmp 0x000079F9DE5DC505
000079f9de5dfd5b  sub rsp, 0x08
000079f9de5dfd5f  push rax
000079f9de5dfd60  push rcx
000079f9de5dfd61  push rdx
000079f9de5dfd62  push rdi
000079f9de5dfd63  push rsi
000079f9de5dfd64  push r8
000079f9de5dfd66  push r9
000079f9de5dfd68  push r10
000079f9de5dfd6a  push r11
000079f9de5dfd6c  sub rsp, 0xF0
000079f9de5dfd73  vmovaps [rsp], xmm0
000079f9de5dfd78  vmovaps [rsp+0x10], xmm1
000079f9de5dfd7e  vmovaps [rsp+0x20], xmm2
000079f9de5dfd84  vmovaps [rsp+0x30], xmm3
000079f9de5dfd8a  vmovaps [rsp+0x40], xmm4
000079f9de5dfd90  vmovaps [rsp+0x50], xmm5
000079f9de5dfd96  vmovaps [rsp+0x60], xmm6
000079f9de5dfd9c  vmovaps [rsp+0x70], xmm7
000079f9de5dfda2  vmovaps [rsp+0x80], xmm8
000079f9de5dfdab  vmovaps [rsp+0x90], xmm9
000079f9de5dfdb4  vmovaps [rsp+0xA0], xmm10
000079f9de5dfdbd  vmovaps [rsp+0xB0], xmm12
000079f9de5dfdc6  vmovaps [rsp+0xC0], xmm13
000079f9de5dfdcf  vmovaps [rsp+0xD0], xmm14
000079f9de5dfdd8  vmovaps [rsp+0xE0], xmm15
000079f9de5dfde1  sub rsp, 0x30
000079f9de5dfde5  movaps [rsp], xmm11
000079f9de5dfdea  movaps [rsp+0x10], xmm10
000079f9de5dfdf0  movaps [rsp+0x20], xmm6
000079f9de5dfdf5  lea rdi, [rsp]
000079f9de5dfdf9  mov esi, 0x00
000079f9de5dfdfe  mov rax, 0x56D56FF59530
000079f9de5dfe08  call rax
000079f9de5dfe0a  movaps xmm11, [rsp]
000079f9de5dfe0f  add rsp, 0x30
000079f9de5dfe13  vmovaps xmm0, [rsp]
000079f9de5dfe18  vmovaps xmm1, [rsp+0x10]
000079f9de5dfe1e  vmovaps xmm2, [rsp+0x20]
000079f9de5dfe24  vmovaps xmm3, [rsp+0x30]
000079f9de5dfe2a  vmovaps xmm4, [rsp+0x40]
000079f9de5dfe30  vmovaps xmm5, [rsp+0x50]
000079f9de5dfe36  vmovaps xmm6, [rsp+0x60]
000079f9de5dfe3c  vmovaps xmm7, [rsp+0x70]
000079f9de5dfe42  vmovaps xmm8, [rsp+0x80]
000079f9de5dfe4b  vmovaps xmm9, [rsp+0x90]
000079f9de5dfe54  vmovaps xmm10, [rsp+0xA0]
000079f9de5dfe5d  vmovaps xmm12, [rsp+0xB0]
000079f9de5dfe66  vmovaps xmm13, [rsp+0xC0]
000079f9de5dfe6f  vmovaps xmm14, [rsp+0xD0]
000079f9de5dfe78  vmovaps xmm15, [rsp+0xE0]
000079f9de5dfe81  add rsp, 0xF0
000079f9de5dfe88  pop r11
000079f9de5dfe8a  pop r10
000079f9de5dfe8c  pop r9
000079f9de5dfe8e  pop r8
000079f9de5dfe90  pop rsi
000079f9de5dfe91  pop rdi
000079f9de5dfe92  pop rdx
000079f9de5dfe93  pop rcx
000079f9de5dfe94  pop rax
000079f9de5dfe95  add rsp, 0x08
000079f9de5dfe99  jmp 0x000079F9DE5DC520
000079f9de5dfe9e  sub rsp, 0x08
000079f9de5dfea2  push rax
000079f9de5dfea3  push rcx
000079f9de5dfea4  push rdx
000079f9de5dfea5  push rdi
000079f9de5dfea6  push rsi
000079f9de5dfea7  push r8
000079f9de5dfea9  push r9
000079f9de5dfeab  push r10
000079f9de5dfead  push r11
000079f9de5dfeaf  sub rsp, 0xF0
000079f9de5dfeb6  vmovaps [rsp], xmm0
000079f9de5dfebb  vmovaps [rsp+0x10], xmm1
000079f9de5dfec1  vmovaps [rsp+0x20], xmm2
000079f9de5dfec7  vmovaps [rsp+0x30], xmm3
000079f9de5dfecd  vmovaps [rsp+0x40], xmm4
000079f9de5dfed3  vmovaps [rsp+0x50], xmm5
000079f9de5dfed9  vmovaps [rsp+0x60], xmm6
000079f9de5dfedf  vmovaps [rsp+0x70], xmm7
000079f9de5dfee5  vmovaps [rsp+0x80], xmm8
000079f9de5dfeee  vmovaps [rsp+0x90], xmm9
000079f9de5dfef7  vmovaps [rsp+0xA0], xmm11
000079f9de5dff00  vmovaps [rsp+0xB0], xmm12
000079f9de5dff09  vmovaps [rsp+0xC0], xmm13
000079f9de5dff12  vmovaps [rsp+0xD0], xmm14
000079f9de5dff1b  vmovaps [rsp+0xE0], xmm15
000079f9de5dff24  sub rsp, 0x30
000079f9de5dff28  movaps [rsp], xmm10
000079f9de5dff2d  movaps [rsp+0x10], xmm14
000079f9de5dff33  movaps [rsp+0x20], xmm4
000079f9de5dff38  lea rdi, [rsp]
000079f9de5dff3c  mov esi, 0x00
000079f9de5dff41  mov rax, 0x56D56FF59530
000079f9de5dff4b  call rax
000079f9de5dff4d  movaps xmm10, [rsp]
000079f9de5dff52  add rsp, 0x30
000079f9de5dff56  vmovaps xmm0, [rsp]
000079f9de5dff5b  vmovaps xmm1, [rsp+0x10]
000079f9de5dff61  vmovaps xmm2, [rsp+0x20]
000079f9de5dff67  vmovaps xmm3, [rsp+0x30]
000079f9de5dff6d  vmovaps xmm4, [rsp+0x40]
000079f9de5dff73  vmovaps xmm5, [rsp+0x50]
000079f9de5dff79  vmovaps xmm6, [rsp+0x60]
000079f9de5dff7f  vmovaps xmm7, [rsp+0x70]
000079f9de5dff85  vmovaps xmm8, [rsp+0x80]
000079f9de5dff8e  vmovaps xmm9, [rsp+0x90]
000079f9de5dff97  vmovaps xmm11, [rsp+0xA0]
000079f9de5dffa0  vmovaps xmm12, [rsp+0xB0]
000079f9de5dffa9  vmovaps xmm13, [rsp+0xC0]
000079f9de5dffb2  vmovaps xmm14, [rsp+0xD0]
000079f9de5dffbb  vmovaps xmm15, [rsp+0xE0]
000079f9de5dffc4  add rsp, 0xF0
000079f9de5dffcb  pop r11
000079f9de5dffcd  pop r10
000079f9de5dffcf  pop r9
000079f9de5dffd1  pop r8
000079f9de5dffd3  pop rsi
000079f9de5dffd4  pop rdi
000079f9de5dffd5  pop rdx
000079f9de5dffd6  pop rcx
000079f9de5dffd7  pop rax
000079f9de5dffd8  add rsp, 0x08
000079f9de5dffdc  jmp 0x000079F9DE5DC53B
000079f9de5dffe1  sub rsp, 0x08
000079f9de5dffe5  push rax
000079f9de5dffe6  push rcx
000079f9de5dffe7  push rdx
000079f9de5dffe8  push rdi
000079f9de5dffe9  push rsi
000079f9de5dffea  push r8
000079f9de5dffec  push r9
000079f9de5dffee  push r10
000079f9de5dfff0  push r11
000079f9de5dfff2  sub rsp, 0xF0
000079f9de5dfff9  vmovaps [rsp], xmm0
000079f9de5dfffe  vmovaps [rsp+0x10], xmm1
000079f9de5e0004  vmovaps [rsp+0x20], xmm2
000079f9de5e000a  vmovaps [rsp+0x30], xmm3
000079f9de5e0010  vmovaps [rsp+0x40], xmm4
000079f9de5e0016  vmovaps [rsp+0x50], xmm5
000079f9de5e001c  vmovaps [rsp+0x60], xmm6
000079f9de5e0022  vmovaps [rsp+0x70], xmm7
000079f9de5e0028  vmovaps [rsp+0x80], xmm9
000079f9de5e0031  vmovaps [rsp+0x90], xmm10
000079f9de5e003a  vmovaps [rsp+0xA0], xmm11
000079f9de5e0043  vmovaps [rsp+0xB0], xmm12
000079f9de5e004c  vmovaps [rsp+0xC0], xmm13
000079f9de5e0055  vmovaps [rsp+0xD0], xmm14
000079f9de5e005e  vmovaps [rsp+0xE0], xmm15
000079f9de5e0067  sub rsp, 0x30
000079f9de5e006b  movaps [rsp], xmm8
000079f9de5e0070  movaps [rsp+0x10], xmm1
000079f9de5e0075  movaps [rsp+0x20], xmm14
000079f9de5e007b  lea rdi, [rsp]
000079f9de5e007f  mov esi, 0x00
000079f9de5e0084  mov rax, 0x56D56FF59530
000079f9de5e008e  call rax
000079f9de5e0090  movaps xmm8, [rsp]
000079f9de5e0095  add rsp, 0x30
000079f9de5e0099  vmovaps xmm0, [rsp]
000079f9de5e009e  vmovaps xmm1, [rsp+0x10]
000079f9de5e00a4  vmovaps xmm2, [rsp+0x20]
000079f9de5e00aa  vmovaps xmm3, [rsp+0x30]
000079f9de5e00b0  vmovaps xmm4, [rsp+0x40]
000079f9de5e00b6  vmovaps xmm5, [rsp+0x50]
000079f9de5e00bc  vmovaps xmm6, [rsp+0x60]
000079f9de5e00c2  vmovaps xmm7, [rsp+0x70]
000079f9de5e00c8  vmovaps xmm9, [rsp+0x80]
000079f9de5e00d1  vmovaps xmm10, [rsp+0x90]
000079f9de5e00da  vmovaps xmm11, [rsp+0xA0]
000079f9de5e00e3  vmovaps xmm12, [rsp+0xB0]
000079f9de5e00ec  vmovaps xmm13, [rsp+0xC0]
000079f9de5e00f5  vmovaps xmm14, [rsp+0xD0]
000079f9de5e00fe  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0107  add rsp, 0xF0
000079f9de5e010e  pop r11
000079f9de5e0110  pop r10
000079f9de5e0112  pop r9
000079f9de5e0114  pop r8
000079f9de5e0116  pop rsi
000079f9de5e0117  pop rdi
000079f9de5e0118  pop rdx
000079f9de5e0119  pop rcx
000079f9de5e011a  pop rax
000079f9de5e011b  add rsp, 0x08
000079f9de5e011f  jmp 0x000079F9DE5DC561
000079f9de5e0124  sub rsp, 0x08
000079f9de5e0128  push rax
000079f9de5e0129  push rcx
000079f9de5e012a  push rdx
000079f9de5e012b  push rdi
000079f9de5e012c  push rsi
000079f9de5e012d  push r8
000079f9de5e012f  push r9
000079f9de5e0131  push r10
000079f9de5e0133  push r11
000079f9de5e0135  sub rsp, 0xF0
000079f9de5e013c  vmovaps [rsp], xmm0
000079f9de5e0141  vmovaps [rsp+0x10], xmm1
000079f9de5e0147  vmovaps [rsp+0x20], xmm2
000079f9de5e014d  vmovaps [rsp+0x30], xmm3
000079f9de5e0153  vmovaps [rsp+0x40], xmm4
000079f9de5e0159  vmovaps [rsp+0x50], xmm5
000079f9de5e015f  vmovaps [rsp+0x60], xmm7
000079f9de5e0165  vmovaps [rsp+0x70], xmm8
000079f9de5e016b  vmovaps [rsp+0x80], xmm9
000079f9de5e0174  vmovaps [rsp+0x90], xmm10
000079f9de5e017d  vmovaps [rsp+0xA0], xmm11
000079f9de5e0186  vmovaps [rsp+0xB0], xmm12
000079f9de5e018f  vmovaps [rsp+0xC0], xmm13
000079f9de5e0198  vmovaps [rsp+0xD0], xmm14
000079f9de5e01a1  vmovaps [rsp+0xE0], xmm15
000079f9de5e01aa  sub rsp, 0x30
000079f9de5e01ae  movaps [rsp], xmm6
000079f9de5e01b2  movaps [rsp+0x10], xmm1
000079f9de5e01b7  movaps [rsp+0x20], xmm14
000079f9de5e01bd  lea rdi, [rsp]
000079f9de5e01c1  mov esi, 0x00
000079f9de5e01c6  mov rax, 0x56D56FF59530
000079f9de5e01d0  call rax
000079f9de5e01d2  movaps xmm6, [rsp]
000079f9de5e01d6  add rsp, 0x30
000079f9de5e01da  vmovaps xmm0, [rsp]
000079f9de5e01df  vmovaps xmm1, [rsp+0x10]
000079f9de5e01e5  vmovaps xmm2, [rsp+0x20]
000079f9de5e01eb  vmovaps xmm3, [rsp+0x30]
000079f9de5e01f1  vmovaps xmm4, [rsp+0x40]
000079f9de5e01f7  vmovaps xmm5, [rsp+0x50]
000079f9de5e01fd  vmovaps xmm7, [rsp+0x60]
000079f9de5e0203  vmovaps xmm8, [rsp+0x70]
000079f9de5e0209  vmovaps xmm9, [rsp+0x80]
000079f9de5e0212  vmovaps xmm10, [rsp+0x90]
000079f9de5e021b  vmovaps xmm11, [rsp+0xA0]
000079f9de5e0224  vmovaps xmm12, [rsp+0xB0]
000079f9de5e022d  vmovaps xmm13, [rsp+0xC0]
000079f9de5e0236  vmovaps xmm14, [rsp+0xD0]
000079f9de5e023f  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0248  add rsp, 0xF0
000079f9de5e024f  pop r11
000079f9de5e0251  pop r10
000079f9de5e0253  pop r9
000079f9de5e0255  pop r8
000079f9de5e0257  pop rsi
000079f9de5e0258  pop rdi
000079f9de5e0259  pop rdx
000079f9de5e025a  pop rcx
000079f9de5e025b  pop rax
000079f9de5e025c  add rsp, 0x08
000079f9de5e0260  jmp 0x000079F9DE5DC58D
000079f9de5e0265  sub rsp, 0x08
000079f9de5e0269  push rax
000079f9de5e026a  push rcx
000079f9de5e026b  push rdx
000079f9de5e026c  push rdi
000079f9de5e026d  push rsi
000079f9de5e026e  push r8
000079f9de5e0270  push r9
000079f9de5e0272  push r10
000079f9de5e0274  push r11
000079f9de5e0276  sub rsp, 0xF0
000079f9de5e027d  vmovaps [rsp], xmm0
000079f9de5e0282  vmovaps [rsp+0x10], xmm1
000079f9de5e0288  vmovaps [rsp+0x20], xmm2
000079f9de5e028e  vmovaps [rsp+0x30], xmm3
000079f9de5e0294  vmovaps [rsp+0x40], xmm4
000079f9de5e029a  vmovaps [rsp+0x50], xmm5
000079f9de5e02a0  vmovaps [rsp+0x60], xmm6
000079f9de5e02a6  vmovaps [rsp+0x70], xmm7
000079f9de5e02ac  vmovaps [rsp+0x80], xmm8
000079f9de5e02b5  vmovaps [rsp+0x90], xmm9
000079f9de5e02be  vmovaps [rsp+0xA0], xmm10
000079f9de5e02c7  vmovaps [rsp+0xB0], xmm11
000079f9de5e02d0  vmovaps [rsp+0xC0], xmm12
000079f9de5e02d9  vmovaps [rsp+0xD0], xmm13
000079f9de5e02e2  vmovaps [rsp+0xE0], xmm15
000079f9de5e02eb  sub rsp, 0x30
000079f9de5e02ef  movaps [rsp], xmm14
000079f9de5e02f4  movaps [rsp+0x10], xmm12
000079f9de5e02fa  movaps [rsp+0x20], xmm1
000079f9de5e02ff  lea rdi, [rsp]
000079f9de5e0303  mov esi, 0x00
000079f9de5e0308  mov rax, 0x56D56FF59530
000079f9de5e0312  call rax
000079f9de5e0314  movaps xmm14, [rsp]
000079f9de5e0319  add rsp, 0x30
000079f9de5e031d  vmovaps xmm0, [rsp]
000079f9de5e0322  vmovaps xmm1, [rsp+0x10]
000079f9de5e0328  vmovaps xmm2, [rsp+0x20]
000079f9de5e032e  vmovaps xmm3, [rsp+0x30]
000079f9de5e0334  vmovaps xmm4, [rsp+0x40]
000079f9de5e033a  vmovaps xmm5, [rsp+0x50]
000079f9de5e0340  vmovaps xmm6, [rsp+0x60]
000079f9de5e0346  vmovaps xmm7, [rsp+0x70]
000079f9de5e034c  vmovaps xmm8, [rsp+0x80]
000079f9de5e0355  vmovaps xmm9, [rsp+0x90]
000079f9de5e035e  vmovaps xmm10, [rsp+0xA0]
000079f9de5e0367  vmovaps xmm11, [rsp+0xB0]
000079f9de5e0370  vmovaps xmm12, [rsp+0xC0]
000079f9de5e0379  vmovaps xmm13, [rsp+0xD0]
000079f9de5e0382  vmovaps xmm15, [rsp+0xE0]
000079f9de5e038b  add rsp, 0xF0
000079f9de5e0392  pop r11
000079f9de5e0394  pop r10
000079f9de5e0396  pop r9
000079f9de5e0398  pop r8
000079f9de5e039a  pop rsi
000079f9de5e039b  pop rdi
000079f9de5e039c  pop rdx
000079f9de5e039d  pop rcx
000079f9de5e039e  pop rax
000079f9de5e039f  add rsp, 0x08
000079f9de5e03a3  jmp 0x000079F9DE5DC5B3
000079f9de5e03a8  sub rsp, 0x08
000079f9de5e03ac  push rax
000079f9de5e03ad  push rcx
000079f9de5e03ae  push rdx
000079f9de5e03af  push rdi
000079f9de5e03b0  push rsi
000079f9de5e03b1  push r8
000079f9de5e03b3  push r9
000079f9de5e03b5  push r10
000079f9de5e03b7  push r11
000079f9de5e03b9  sub rsp, 0xF0
000079f9de5e03c0  vmovaps [rsp], xmm0
000079f9de5e03c5  vmovaps [rsp+0x10], xmm2
000079f9de5e03cb  vmovaps [rsp+0x20], xmm3
000079f9de5e03d1  vmovaps [rsp+0x30], xmm4
000079f9de5e03d7  vmovaps [rsp+0x40], xmm5
000079f9de5e03dd  vmovaps [rsp+0x50], xmm6
000079f9de5e03e3  vmovaps [rsp+0x60], xmm7
000079f9de5e03e9  vmovaps [rsp+0x70], xmm8
000079f9de5e03ef  vmovaps [rsp+0x80], xmm9
000079f9de5e03f8  vmovaps [rsp+0x90], xmm10
000079f9de5e0401  vmovaps [rsp+0xA0], xmm11
000079f9de5e040a  vmovaps [rsp+0xB0], xmm12
000079f9de5e0413  vmovaps [rsp+0xC0], xmm13
000079f9de5e041c  vmovaps [rsp+0xD0], xmm14
000079f9de5e0425  vmovaps [rsp+0xE0], xmm15
000079f9de5e042e  sub rsp, 0x30
000079f9de5e0432  movaps [rsp], xmm1
000079f9de5e0436  movaps [rsp+0x10], xmm13
000079f9de5e043c  movaps [rsp+0x20], xmm9
000079f9de5e0442  lea rdi, [rsp]
000079f9de5e0446  mov esi, 0x00
000079f9de5e044b  mov rax, 0x56D56FF59530
000079f9de5e0455  call rax
000079f9de5e0457  movaps xmm1, [rsp]
000079f9de5e045b  add rsp, 0x30
000079f9de5e045f  vmovaps xmm0, [rsp]
000079f9de5e0464  vmovaps xmm2, [rsp+0x10]
000079f9de5e046a  vmovaps xmm3, [rsp+0x20]
000079f9de5e0470  vmovaps xmm4, [rsp+0x30]
000079f9de5e0476  vmovaps xmm5, [rsp+0x40]
000079f9de5e047c  vmovaps xmm6, [rsp+0x50]
000079f9de5e0482  vmovaps xmm7, [rsp+0x60]
000079f9de5e0488  vmovaps xmm8, [rsp+0x70]
000079f9de5e048e  vmovaps xmm9, [rsp+0x80]
000079f9de5e0497  vmovaps xmm10, [rsp+0x90]
000079f9de5e04a0  vmovaps xmm11, [rsp+0xA0]
000079f9de5e04a9  vmovaps xmm12, [rsp+0xB0]
000079f9de5e04b2  vmovaps xmm13, [rsp+0xC0]
000079f9de5e04bb  vmovaps xmm14, [rsp+0xD0]
000079f9de5e04c4  vmovaps xmm15, [rsp+0xE0]
000079f9de5e04cd  add rsp, 0xF0
000079f9de5e04d4  pop r11
000079f9de5e04d6  pop r10
000079f9de5e04d8  pop r9
000079f9de5e04da  pop r8
000079f9de5e04dc  pop rsi
000079f9de5e04dd  pop rdi
000079f9de5e04de  pop rdx
000079f9de5e04df  pop rcx
000079f9de5e04e0  pop rax
000079f9de5e04e1  add rsp, 0x08
000079f9de5e04e5  jmp 0x000079F9DE5DC5CD
000079f9de5e04ea  sub rsp, 0x08
000079f9de5e04ee  push rax
000079f9de5e04ef  push rcx
000079f9de5e04f0  push rdx
000079f9de5e04f1  push rdi
000079f9de5e04f2  push rsi
000079f9de5e04f3  push r8
000079f9de5e04f5  push r9
000079f9de5e04f7  push r10
000079f9de5e04f9  push r11
000079f9de5e04fb  sub rsp, 0xF0
000079f9de5e0502  vmovaps [rsp], xmm0
000079f9de5e0507  vmovaps [rsp+0x10], xmm1
000079f9de5e050d  vmovaps [rsp+0x20], xmm2
000079f9de5e0513  vmovaps [rsp+0x30], xmm3
000079f9de5e0519  vmovaps [rsp+0x40], xmm4
000079f9de5e051f  vmovaps [rsp+0x50], xmm5
000079f9de5e0525  vmovaps [rsp+0x60], xmm6
000079f9de5e052b  vmovaps [rsp+0x70], xmm7
000079f9de5e0531  vmovaps [rsp+0x80], xmm8
000079f9de5e053a  vmovaps [rsp+0x90], xmm9
000079f9de5e0543  vmovaps [rsp+0xA0], xmm10
000079f9de5e054c  vmovaps [rsp+0xB0], xmm11
000079f9de5e0555  vmovaps [rsp+0xC0], xmm13
000079f9de5e055e  vmovaps [rsp+0xD0], xmm14
000079f9de5e0567  vmovaps [rsp+0xE0], xmm15
000079f9de5e0570  sub rsp, 0x30
000079f9de5e0574  movaps [rsp], xmm12
000079f9de5e0579  movaps [rsp+0x10], xmm7
000079f9de5e057e  movaps [rsp+0x20], xmm13
000079f9de5e0584  lea rdi, [rsp]
000079f9de5e0588  mov esi, 0x00
000079f9de5e058d  mov rax, 0x56D56FF59530
000079f9de5e0597  call rax
000079f9de5e0599  movaps xmm12, [rsp]
000079f9de5e059e  add rsp, 0x30
000079f9de5e05a2  vmovaps xmm0, [rsp]
000079f9de5e05a7  vmovaps xmm1, [rsp+0x10]
000079f9de5e05ad  vmovaps xmm2, [rsp+0x20]
000079f9de5e05b3  vmovaps xmm3, [rsp+0x30]
000079f9de5e05b9  vmovaps xmm4, [rsp+0x40]
000079f9de5e05bf  vmovaps xmm5, [rsp+0x50]
000079f9de5e05c5  vmovaps xmm6, [rsp+0x60]
000079f9de5e05cb  vmovaps xmm7, [rsp+0x70]
000079f9de5e05d1  vmovaps xmm8, [rsp+0x80]
000079f9de5e05da  vmovaps xmm9, [rsp+0x90]
000079f9de5e05e3  vmovaps xmm10, [rsp+0xA0]
000079f9de5e05ec  vmovaps xmm11, [rsp+0xB0]
000079f9de5e05f5  vmovaps xmm13, [rsp+0xC0]
000079f9de5e05fe  vmovaps xmm14, [rsp+0xD0]
000079f9de5e0607  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0610  add rsp, 0xF0
000079f9de5e0617  pop r11
000079f9de5e0619  pop r10
000079f9de5e061b  pop r9
000079f9de5e061d  pop r8
000079f9de5e061f  pop rsi
000079f9de5e0620  pop rdi
000079f9de5e0621  pop rdx
000079f9de5e0622  pop rcx
000079f9de5e0623  pop rax
000079f9de5e0624  add rsp, 0x08
000079f9de5e0628  jmp 0x000079F9DE5DC5F4
000079f9de5e062d  sub rsp, 0x08
000079f9de5e0631  push rax
000079f9de5e0632  push rcx
000079f9de5e0633  push rdx
000079f9de5e0634  push rdi
000079f9de5e0635  push rsi
000079f9de5e0636  push r8
000079f9de5e0638  push r9
000079f9de5e063a  push r10
000079f9de5e063c  push r11
000079f9de5e063e  sub rsp, 0xF0
000079f9de5e0645  vmovaps [rsp], xmm0
000079f9de5e064a  vmovaps [rsp+0x10], xmm1
000079f9de5e0650  vmovaps [rsp+0x20], xmm2
000079f9de5e0656  vmovaps [rsp+0x30], xmm3
000079f9de5e065c  vmovaps [rsp+0x40], xmm4
000079f9de5e0662  vmovaps [rsp+0x50], xmm5
000079f9de5e0668  vmovaps [rsp+0x60], xmm6
000079f9de5e066e  vmovaps [rsp+0x70], xmm7
000079f9de5e0674  vmovaps [rsp+0x80], xmm8
000079f9de5e067d  vmovaps [rsp+0x90], xmm9
000079f9de5e0686  vmovaps [rsp+0xA0], xmm10
000079f9de5e068f  vmovaps [rsp+0xB0], xmm11
000079f9de5e0698  vmovaps [rsp+0xC0], xmm12
000079f9de5e06a1  vmovaps [rsp+0xD0], xmm14
000079f9de5e06aa  vmovaps [rsp+0xE0], xmm15
000079f9de5e06b3  sub rsp, 0x30
000079f9de5e06b7  movaps [rsp], xmm13
000079f9de5e06bc  movaps [rsp+0x10], xmm15
000079f9de5e06c2  movaps [rsp+0x20], xmm8
000079f9de5e06c8  lea rdi, [rsp]
000079f9de5e06cc  mov esi, 0x00
000079f9de5e06d1  mov rax, 0x56D56FF59530
000079f9de5e06db  call rax
000079f9de5e06dd  movaps xmm13, [rsp]
000079f9de5e06e2  add rsp, 0x30
000079f9de5e06e6  vmovaps xmm0, [rsp]
000079f9de5e06eb  vmovaps xmm1, [rsp+0x10]
000079f9de5e06f1  vmovaps xmm2, [rsp+0x20]
000079f9de5e06f7  vmovaps xmm3, [rsp+0x30]
000079f9de5e06fd  vmovaps xmm4, [rsp+0x40]
000079f9de5e0703  vmovaps xmm5, [rsp+0x50]
000079f9de5e0709  vmovaps xmm6, [rsp+0x60]
000079f9de5e070f  vmovaps xmm7, [rsp+0x70]
000079f9de5e0715  vmovaps xmm8, [rsp+0x80]
000079f9de5e071e  vmovaps xmm9, [rsp+0x90]
000079f9de5e0727  vmovaps xmm10, [rsp+0xA0]
000079f9de5e0730  vmovaps xmm11, [rsp+0xB0]
000079f9de5e0739  vmovaps xmm12, [rsp+0xC0]
000079f9de5e0742  vmovaps xmm14, [rsp+0xD0]
000079f9de5e074b  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0754  add rsp, 0xF0
000079f9de5e075b  pop r11
000079f9de5e075d  pop r10
000079f9de5e075f  pop r9
000079f9de5e0761  pop r8
000079f9de5e0763  pop rsi
000079f9de5e0764  pop rdi
000079f9de5e0765  pop rdx
000079f9de5e0766  pop rcx
000079f9de5e0767  pop rax
000079f9de5e0768  add rsp, 0x08
000079f9de5e076c  jmp 0x000079F9DE5DC60F
000079f9de5e0771  sub rsp, 0x08
000079f9de5e0775  push rax
000079f9de5e0776  push rcx
000079f9de5e0777  push rdx
000079f9de5e0778  push rdi
000079f9de5e0779  push rsi
000079f9de5e077a  push r8
000079f9de5e077c  push r9
000079f9de5e077e  push r10
000079f9de5e0780  push r11
000079f9de5e0782  sub rsp, 0xF0
000079f9de5e0789  vmovaps [rsp], xmm0
000079f9de5e078e  vmovaps [rsp+0x10], xmm1
000079f9de5e0794  vmovaps [rsp+0x20], xmm2
000079f9de5e079a  vmovaps [rsp+0x30], xmm3
000079f9de5e07a0  vmovaps [rsp+0x40], xmm4
000079f9de5e07a6  vmovaps [rsp+0x50], xmm5
000079f9de5e07ac  vmovaps [rsp+0x60], xmm6
000079f9de5e07b2  vmovaps [rsp+0x70], xmm7
000079f9de5e07b8  vmovaps [rsp+0x80], xmm9
000079f9de5e07c1  vmovaps [rsp+0x90], xmm10
000079f9de5e07ca  vmovaps [rsp+0xA0], xmm11
000079f9de5e07d3  vmovaps [rsp+0xB0], xmm12
000079f9de5e07dc  vmovaps [rsp+0xC0], xmm13
000079f9de5e07e5  vmovaps [rsp+0xD0], xmm14
000079f9de5e07ee  vmovaps [rsp+0xE0], xmm15
000079f9de5e07f7  sub rsp, 0x30
000079f9de5e07fb  movaps [rsp], xmm8
000079f9de5e0800  movaps [rsp+0x10], xmm15
000079f9de5e0806  movaps [rsp+0x20], xmm9
000079f9de5e080c  lea rdi, [rsp]
000079f9de5e0810  mov esi, 0x00
000079f9de5e0815  mov rax, 0x56D56FF59530
000079f9de5e081f  call rax
000079f9de5e0821  movaps xmm8, [rsp]
000079f9de5e0826  add rsp, 0x30
000079f9de5e082a  vmovaps xmm0, [rsp]
000079f9de5e082f  vmovaps xmm1, [rsp+0x10]
000079f9de5e0835  vmovaps xmm2, [rsp+0x20]
000079f9de5e083b  vmovaps xmm3, [rsp+0x30]
000079f9de5e0841  vmovaps xmm4, [rsp+0x40]
000079f9de5e0847  vmovaps xmm5, [rsp+0x50]
000079f9de5e084d  vmovaps xmm6, [rsp+0x60]
000079f9de5e0853  vmovaps xmm7, [rsp+0x70]
000079f9de5e0859  vmovaps xmm9, [rsp+0x80]
000079f9de5e0862  vmovaps xmm10, [rsp+0x90]
000079f9de5e086b  vmovaps xmm11, [rsp+0xA0]
000079f9de5e0874  vmovaps xmm12, [rsp+0xB0]
000079f9de5e087d  vmovaps xmm13, [rsp+0xC0]
000079f9de5e0886  vmovaps xmm14, [rsp+0xD0]
000079f9de5e088f  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0898  add rsp, 0xF0
000079f9de5e089f  pop r11
000079f9de5e08a1  pop r10
000079f9de5e08a3  pop r9
000079f9de5e08a5  pop r8
000079f9de5e08a7  pop rsi
000079f9de5e08a8  pop rdi
000079f9de5e08a9  pop rdx
000079f9de5e08aa  pop rcx
000079f9de5e08ab  pop rax
000079f9de5e08ac  add rsp, 0x08
000079f9de5e08b0  jmp 0x000079F9DE5DC63D
000079f9de5e08b5  sub rsp, 0x08
000079f9de5e08b9  push rax
000079f9de5e08ba  push rcx
000079f9de5e08bb  push rdx
000079f9de5e08bc  push rdi
000079f9de5e08bd  push rsi
000079f9de5e08be  push r8
000079f9de5e08c0  push r9
000079f9de5e08c2  push r10
000079f9de5e08c4  push r11
000079f9de5e08c6  sub rsp, 0xF0
000079f9de5e08cd  vmovaps [rsp], xmm0
000079f9de5e08d2  vmovaps [rsp+0x10], xmm1
000079f9de5e08d8  vmovaps [rsp+0x20], xmm2
000079f9de5e08de  vmovaps [rsp+0x30], xmm3
000079f9de5e08e4  vmovaps [rsp+0x40], xmm4
000079f9de5e08ea  vmovaps [rsp+0x50], xmm5
000079f9de5e08f0  vmovaps [rsp+0x60], xmm6
000079f9de5e08f6  vmovaps [rsp+0x70], xmm7
000079f9de5e08fc  vmovaps [rsp+0x80], xmm8
000079f9de5e0905  vmovaps [rsp+0x90], xmm9
000079f9de5e090e  vmovaps [rsp+0xA0], xmm10
000079f9de5e0917  vmovaps [rsp+0xB0], xmm11
000079f9de5e0920  vmovaps [rsp+0xC0], xmm12
000079f9de5e0929  vmovaps [rsp+0xD0], xmm13
000079f9de5e0932  vmovaps [rsp+0xE0], xmm14
000079f9de5e093b  sub rsp, 0x30
000079f9de5e093f  movaps [rsp], xmm15
000079f9de5e0944  movaps [rsp+0x10], xmm11
000079f9de5e094a  movaps [rsp+0x20], xmm6
000079f9de5e094f  lea rdi, [rsp]
000079f9de5e0953  mov esi, 0x00
000079f9de5e0958  mov rax, 0x56D56FF59530
000079f9de5e0962  call rax
000079f9de5e0964  movaps xmm15, [rsp]
000079f9de5e0969  add rsp, 0x30
000079f9de5e096d  vmovaps xmm0, [rsp]
000079f9de5e0972  vmovaps xmm1, [rsp+0x10]
000079f9de5e0978  vmovaps xmm2, [rsp+0x20]
000079f9de5e097e  vmovaps xmm3, [rsp+0x30]
000079f9de5e0984  vmovaps xmm4, [rsp+0x40]
000079f9de5e098a  vmovaps xmm5, [rsp+0x50]
000079f9de5e0990  vmovaps xmm6, [rsp+0x60]
000079f9de5e0996  vmovaps xmm7, [rsp+0x70]
000079f9de5e099c  vmovaps xmm8, [rsp+0x80]
000079f9de5e09a5  vmovaps xmm9, [rsp+0x90]
000079f9de5e09ae  vmovaps xmm10, [rsp+0xA0]
000079f9de5e09b7  vmovaps xmm11, [rsp+0xB0]
000079f9de5e09c0  vmovaps xmm12, [rsp+0xC0]
000079f9de5e09c9  vmovaps xmm13, [rsp+0xD0]
000079f9de5e09d2  vmovaps xmm14, [rsp+0xE0]
000079f9de5e09db  add rsp, 0xF0
000079f9de5e09e2  pop r11
000079f9de5e09e4  pop r10
000079f9de5e09e6  pop r9
000079f9de5e09e8  pop r8
000079f9de5e09ea  pop rsi
000079f9de5e09eb  pop rdi
000079f9de5e09ec  pop rdx
000079f9de5e09ed  pop rcx
000079f9de5e09ee  pop rax
000079f9de5e09ef  add rsp, 0x08
000079f9de5e09f3  jmp 0x000079F9DE5DC658
000079f9de5e09f8  sub rsp, 0x08
000079f9de5e09fc  push rax
000079f9de5e09fd  push rcx
000079f9de5e09fe  push rdx
000079f9de5e09ff  push rdi
000079f9de5e0a00  push rsi
000079f9de5e0a01  push r8
000079f9de5e0a03  push r9
000079f9de5e0a05  push r10
000079f9de5e0a07  push r11
000079f9de5e0a09  sub rsp, 0xF0
000079f9de5e0a10  vmovaps [rsp], xmm0
000079f9de5e0a15  vmovaps [rsp+0x10], xmm1
000079f9de5e0a1b  vmovaps [rsp+0x20], xmm2
000079f9de5e0a21  vmovaps [rsp+0x30], xmm3
000079f9de5e0a27  vmovaps [rsp+0x40], xmm4
000079f9de5e0a2d  vmovaps [rsp+0x50], xmm5
000079f9de5e0a33  vmovaps [rsp+0x60], xmm6
000079f9de5e0a39  vmovaps [rsp+0x70], xmm8
000079f9de5e0a3f  vmovaps [rsp+0x80], xmm9
000079f9de5e0a48  vmovaps [rsp+0x90], xmm10
000079f9de5e0a51  vmovaps [rsp+0xA0], xmm11
000079f9de5e0a5a  vmovaps [rsp+0xB0], xmm12
000079f9de5e0a63  vmovaps [rsp+0xC0], xmm13
000079f9de5e0a6c  vmovaps [rsp+0xD0], xmm14
000079f9de5e0a75  vmovaps [rsp+0xE0], xmm15
000079f9de5e0a7e  sub rsp, 0x30
000079f9de5e0a82  movaps [rsp], xmm7
000079f9de5e0a86  movaps [rsp+0x10], xmm11
000079f9de5e0a8c  movaps [rsp+0x20], xmm9
000079f9de5e0a92  lea rdi, [rsp]
000079f9de5e0a96  mov esi, 0x00
000079f9de5e0a9b  mov rax, 0x56D56FF59530
000079f9de5e0aa5  call rax
000079f9de5e0aa7  movaps xmm7, [rsp]
000079f9de5e0aab  add rsp, 0x30
000079f9de5e0aaf  vmovaps xmm0, [rsp]
000079f9de5e0ab4  vmovaps xmm1, [rsp+0x10]
000079f9de5e0aba  vmovaps xmm2, [rsp+0x20]
000079f9de5e0ac0  vmovaps xmm3, [rsp+0x30]
000079f9de5e0ac6  vmovaps xmm4, [rsp+0x40]
000079f9de5e0acc  vmovaps xmm5, [rsp+0x50]
000079f9de5e0ad2  vmovaps xmm6, [rsp+0x60]
000079f9de5e0ad8  vmovaps xmm8, [rsp+0x70]
000079f9de5e0ade  vmovaps xmm9, [rsp+0x80]
000079f9de5e0ae7  vmovaps xmm10, [rsp+0x90]
000079f9de5e0af0  vmovaps xmm11, [rsp+0xA0]
000079f9de5e0af9  vmovaps xmm12, [rsp+0xB0]
000079f9de5e0b02  vmovaps xmm13, [rsp+0xC0]
000079f9de5e0b0b  vmovaps xmm14, [rsp+0xD0]
000079f9de5e0b14  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0b1d  add rsp, 0xF0
000079f9de5e0b24  pop r11
000079f9de5e0b26  pop r10
000079f9de5e0b28  pop r9
000079f9de5e0b2a  pop r8
000079f9de5e0b2c  pop rsi
000079f9de5e0b2d  pop rdi
000079f9de5e0b2e  pop rdx
000079f9de5e0b2f  pop rcx
000079f9de5e0b30  pop rax
000079f9de5e0b31  add rsp, 0x08
000079f9de5e0b35  jmp 0x000079F9DE5DC685
000079f9de5e0b3a  sub rsp, 0x08
000079f9de5e0b3e  push rax
000079f9de5e0b3f  push rcx
000079f9de5e0b40  push rdx
000079f9de5e0b41  push rdi
000079f9de5e0b42  push rsi
000079f9de5e0b43  push r8
000079f9de5e0b45  push r9
000079f9de5e0b47  push r10
000079f9de5e0b49  push r11
000079f9de5e0b4b  sub rsp, 0xF0
000079f9de5e0b52  vmovaps [rsp], xmm0
000079f9de5e0b57  vmovaps [rsp+0x10], xmm1
000079f9de5e0b5d  vmovaps [rsp+0x20], xmm2
000079f9de5e0b63  vmovaps [rsp+0x30], xmm3
000079f9de5e0b69  vmovaps [rsp+0x40], xmm4
000079f9de5e0b6f  vmovaps [rsp+0x50], xmm5
000079f9de5e0b75  vmovaps [rsp+0x60], xmm6
000079f9de5e0b7b  vmovaps [rsp+0x70], xmm7
000079f9de5e0b81  vmovaps [rsp+0x80], xmm8
000079f9de5e0b8a  vmovaps [rsp+0x90], xmm9
000079f9de5e0b93  vmovaps [rsp+0xA0], xmm10
000079f9de5e0b9c  vmovaps [rsp+0xB0], xmm12
000079f9de5e0ba5  vmovaps [rsp+0xC0], xmm13
000079f9de5e0bae  vmovaps [rsp+0xD0], xmm14
000079f9de5e0bb7  vmovaps [rsp+0xE0], xmm15
000079f9de5e0bc0  sub rsp, 0x30
000079f9de5e0bc4  movaps [rsp], xmm11
000079f9de5e0bc9  movaps [rsp+0x10], xmm10
000079f9de5e0bcf  movaps [rsp+0x20], xmm14
000079f9de5e0bd5  lea rdi, [rsp]
000079f9de5e0bd9  mov esi, 0x00
000079f9de5e0bde  mov rax, 0x56D56FF59530
000079f9de5e0be8  call rax
000079f9de5e0bea  movaps xmm11, [rsp]
000079f9de5e0bef  add rsp, 0x30
000079f9de5e0bf3  vmovaps xmm0, [rsp]
000079f9de5e0bf8  vmovaps xmm1, [rsp+0x10]
000079f9de5e0bfe  vmovaps xmm2, [rsp+0x20]
000079f9de5e0c04  vmovaps xmm3, [rsp+0x30]
000079f9de5e0c0a  vmovaps xmm4, [rsp+0x40]
000079f9de5e0c10  vmovaps xmm5, [rsp+0x50]
000079f9de5e0c16  vmovaps xmm6, [rsp+0x60]
000079f9de5e0c1c  vmovaps xmm7, [rsp+0x70]
000079f9de5e0c22  vmovaps xmm8, [rsp+0x80]
000079f9de5e0c2b  vmovaps xmm9, [rsp+0x90]
000079f9de5e0c34  vmovaps xmm10, [rsp+0xA0]
000079f9de5e0c3d  vmovaps xmm12, [rsp+0xB0]
000079f9de5e0c46  vmovaps xmm13, [rsp+0xC0]
000079f9de5e0c4f  vmovaps xmm14, [rsp+0xD0]
000079f9de5e0c58  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0c61  add rsp, 0xF0
000079f9de5e0c68  pop r11
000079f9de5e0c6a  pop r10
000079f9de5e0c6c  pop r9
000079f9de5e0c6e  pop r8
000079f9de5e0c70  pop rsi
000079f9de5e0c71  pop rdi
000079f9de5e0c72  pop rdx
000079f9de5e0c73  pop rcx
000079f9de5e0c74  pop rax
000079f9de5e0c75  add rsp, 0x08
000079f9de5e0c79  jmp 0x000079F9DE5DC6A0
000079f9de5e0c7e  call 0x000079F9DE4C33A0
000079f9de5e0c83  jmp 0x000079F9DE5DC6AA
000079f9de5e0c88  sub rsp, 0x08
000079f9de5e0c8c  push rax
000079f9de5e0c8d  push rcx
000079f9de5e0c8e  push rdx
000079f9de5e0c8f  push rdi
000079f9de5e0c90  push rsi
000079f9de5e0c91  push r8
000079f9de5e0c93  push r9
000079f9de5e0c95  push r10
000079f9de5e0c97  push r11
000079f9de5e0c99  sub rsp, 0xF0
000079f9de5e0ca0  vmovaps [rsp], xmm0
000079f9de5e0ca5  vmovaps [rsp+0x10], xmm1
000079f9de5e0cab  vmovaps [rsp+0x20], xmm2
000079f9de5e0cb1  vmovaps [rsp+0x30], xmm3
000079f9de5e0cb7  vmovaps [rsp+0x40], xmm4
000079f9de5e0cbd  vmovaps [rsp+0x50], xmm5
000079f9de5e0cc3  vmovaps [rsp+0x60], xmm6
000079f9de5e0cc9  vmovaps [rsp+0x70], xmm7
000079f9de5e0ccf  vmovaps [rsp+0x80], xmm8
000079f9de5e0cd8  vmovaps [rsp+0x90], xmm9
000079f9de5e0ce1  vmovaps [rsp+0xA0], xmm11
000079f9de5e0cea  vmovaps [rsp+0xB0], xmm12
000079f9de5e0cf3  vmovaps [rsp+0xC0], xmm13
000079f9de5e0cfc  vmovaps [rsp+0xD0], xmm14
000079f9de5e0d05  vmovaps [rsp+0xE0], xmm15
000079f9de5e0d0e  sub rsp, 0x30
000079f9de5e0d12  movaps [rsp], xmm10
000079f9de5e0d17  movaps [rsp+0x10], xmm1
000079f9de5e0d1c  movaps [rsp+0x20], xmm12
000079f9de5e0d22  lea rdi, [rsp]
000079f9de5e0d26  mov esi, 0x00
000079f9de5e0d2b  mov rax, 0x56D56FF59530
000079f9de5e0d35  call rax
000079f9de5e0d37  movaps xmm10, [rsp]
000079f9de5e0d3c  add rsp, 0x30
000079f9de5e0d40  vmovaps xmm0, [rsp]
000079f9de5e0d45  vmovaps xmm1, [rsp+0x10]
000079f9de5e0d4b  vmovaps xmm2, [rsp+0x20]
000079f9de5e0d51  vmovaps xmm3, [rsp+0x30]
000079f9de5e0d57  vmovaps xmm4, [rsp+0x40]
000079f9de5e0d5d  vmovaps xmm5, [rsp+0x50]
000079f9de5e0d63  vmovaps xmm6, [rsp+0x60]
000079f9de5e0d69  vmovaps xmm7, [rsp+0x70]
000079f9de5e0d6f  vmovaps xmm8, [rsp+0x80]
000079f9de5e0d78  vmovaps xmm9, [rsp+0x90]
000079f9de5e0d81  vmovaps xmm11, [rsp+0xA0]
000079f9de5e0d8a  vmovaps xmm12, [rsp+0xB0]
000079f9de5e0d93  vmovaps xmm13, [rsp+0xC0]
000079f9de5e0d9c  vmovaps xmm14, [rsp+0xD0]
000079f9de5e0da5  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0dae  add rsp, 0xF0
000079f9de5e0db5  pop r11
000079f9de5e0db7  pop r10
000079f9de5e0db9  pop r9
000079f9de5e0dbb  pop r8
000079f9de5e0dbd  pop rsi
000079f9de5e0dbe  pop rdi
000079f9de5e0dbf  pop rdx
000079f9de5e0dc0  pop rcx
000079f9de5e0dc1  pop rax
000079f9de5e0dc2  add rsp, 0x08
000079f9de5e0dc6  jmp 0x000079F9DE5DC6CD
000079f9de5e0dcb  sub rsp, 0x08
000079f9de5e0dcf  push rax
000079f9de5e0dd0  push rcx
000079f9de5e0dd1  push rdx
000079f9de5e0dd2  push rdi
000079f9de5e0dd3  push rsi
000079f9de5e0dd4  push r8
000079f9de5e0dd6  push r9
000079f9de5e0dd8  push r10
000079f9de5e0dda  push r11
000079f9de5e0ddc  sub rsp, 0xF0
000079f9de5e0de3  vmovaps [rsp], xmm0
000079f9de5e0de8  vmovaps [rsp+0x10], xmm1
000079f9de5e0dee  vmovaps [rsp+0x20], xmm2
000079f9de5e0df4  vmovaps [rsp+0x30], xmm3
000079f9de5e0dfa  vmovaps [rsp+0x40], xmm4
000079f9de5e0e00  vmovaps [rsp+0x50], xmm5
000079f9de5e0e06  vmovaps [rsp+0x60], xmm6
000079f9de5e0e0c  vmovaps [rsp+0x70], xmm7
000079f9de5e0e12  vmovaps [rsp+0x80], xmm8
000079f9de5e0e1b  vmovaps [rsp+0x90], xmm9
000079f9de5e0e24  vmovaps [rsp+0xA0], xmm10
000079f9de5e0e2d  vmovaps [rsp+0xB0], xmm11
000079f9de5e0e36  vmovaps [rsp+0xC0], xmm13
000079f9de5e0e3f  vmovaps [rsp+0xD0], xmm14
000079f9de5e0e48  vmovaps [rsp+0xE0], xmm15
000079f9de5e0e51  sub rsp, 0x30
000079f9de5e0e55  movaps [rsp], xmm12
000079f9de5e0e5a  movaps [rsp+0x10], xmm14
000079f9de5e0e60  movaps [rsp+0x20], xmm1
000079f9de5e0e65  lea rdi, [rsp]
000079f9de5e0e69  mov esi, 0x00
000079f9de5e0e6e  mov rax, 0x56D56FF59530
000079f9de5e0e78  call rax
000079f9de5e0e7a  movaps xmm12, [rsp]
000079f9de5e0e7f  add rsp, 0x30
000079f9de5e0e83  vmovaps xmm0, [rsp]
000079f9de5e0e88  vmovaps xmm1, [rsp+0x10]
000079f9de5e0e8e  vmovaps xmm2, [rsp+0x20]
000079f9de5e0e94  vmovaps xmm3, [rsp+0x30]
000079f9de5e0e9a  vmovaps xmm4, [rsp+0x40]
000079f9de5e0ea0  vmovaps xmm5, [rsp+0x50]
000079f9de5e0ea6  vmovaps xmm6, [rsp+0x60]
000079f9de5e0eac  vmovaps xmm7, [rsp+0x70]
000079f9de5e0eb2  vmovaps xmm8, [rsp+0x80]
000079f9de5e0ebb  vmovaps xmm9, [rsp+0x90]
000079f9de5e0ec4  vmovaps xmm10, [rsp+0xA0]
000079f9de5e0ecd  vmovaps xmm11, [rsp+0xB0]
000079f9de5e0ed6  vmovaps xmm13, [rsp+0xC0]
000079f9de5e0edf  vmovaps xmm14, [rsp+0xD0]
000079f9de5e0ee8  vmovaps xmm15, [rsp+0xE0]
000079f9de5e0ef1  add rsp, 0xF0
000079f9de5e0ef8  pop r11
000079f9de5e0efa  pop r10
000079f9de5e0efc  pop r9
000079f9de5e0efe  pop r8
000079f9de5e0f00  pop rsi
000079f9de5e0f01  pop rdi
000079f9de5e0f02  pop rdx
000079f9de5e0f03  pop rcx
000079f9de5e0f04  pop rax
000079f9de5e0f05  add rsp, 0x08
000079f9de5e0f09  jmp 0x000079F9DE5DC6FC
000079f9de5e0f0e  sub rsp, 0x08
000079f9de5e0f12  push rax
000079f9de5e0f13  push rcx
000079f9de5e0f14  push rdx
000079f9de5e0f15  push rdi
000079f9de5e0f16  push rsi
000079f9de5e0f17  push r8
000079f9de5e0f19  push r9
000079f9de5e0f1b  push r10
000079f9de5e0f1d  push r11
000079f9de5e0f1f  sub rsp, 0xF0
000079f9de5e0f26  vmovaps [rsp], xmm0
000079f9de5e0f2b  vmovaps [rsp+0x10], xmm1
000079f9de5e0f31  vmovaps [rsp+0x20], xmm2
000079f9de5e0f37  vmovaps [rsp+0x30], xmm3
000079f9de5e0f3d  vmovaps [rsp+0x40], xmm4
000079f9de5e0f43  vmovaps [rsp+0x50], xmm5
000079f9de5e0f49  vmovaps [rsp+0x60], xmm6
000079f9de5e0f4f  vmovaps [rsp+0x70], xmm7
000079f9de5e0f55  vmovaps [rsp+0x80], xmm8
000079f9de5e0f5e  vmovaps [rsp+0x90], xmm9
000079f9de5e0f67  vmovaps [rsp+0xA0], xmm10
000079f9de5e0f70  vmovaps [rsp+0xB0], xmm11
000079f9de5e0f79  vmovaps [rsp+0xC0], xmm12
000079f9de5e0f82  vmovaps [rsp+0xD0], xmm13
000079f9de5e0f8b  vmovaps [rsp+0xE0], xmm15
000079f9de5e0f94  sub rsp, 0x30
000079f9de5e0f98  movaps [rsp], xmm14
000079f9de5e0f9d  movaps [rsp+0x10], xmm9
000079f9de5e0fa3  movaps [rsp+0x20], xmm1
000079f9de5e0fa8  lea rdi, [rsp]
000079f9de5e0fac  mov esi, 0x00
000079f9de5e0fb1  mov rax, 0x56D56FF59530
000079f9de5e0fbb  call rax
000079f9de5e0fbd  movaps xmm14, [rsp]
000079f9de5e0fc2  add rsp, 0x30
000079f9de5e0fc6  vmovaps xmm0, [rsp]
000079f9de5e0fcb  vmovaps xmm1, [rsp+0x10]
000079f9de5e0fd1  vmovaps xmm2, [rsp+0x20]
000079f9de5e0fd7  vmovaps xmm3, [rsp+0x30]
000079f9de5e0fdd  vmovaps xmm4, [rsp+0x40]
000079f9de5e0fe3  vmovaps xmm5, [rsp+0x50]
000079f9de5e0fe9  vmovaps xmm6, [rsp+0x60]
000079f9de5e0fef  vmovaps xmm7, [rsp+0x70]
000079f9de5e0ff5  vmovaps xmm8, [rsp+0x80]
000079f9de5e0ffe  vmovaps xmm9, [rsp+0x90]
000079f9de5e1007  vmovaps xmm10, [rsp+0xA0]
000079f9de5e1010  vmovaps xmm11, [rsp+0xB0]
000079f9de5e1019  vmovaps xmm12, [rsp+0xC0]
000079f9de5e1022  vmovaps xmm13, [rsp+0xD0]
000079f9de5e102b  vmovaps xmm15, [rsp+0xE0]
000079f9de5e1034  add rsp, 0xF0
000079f9de5e103b  pop r11
000079f9de5e103d  pop r10
000079f9de5e103f  pop r9
000079f9de5e1041  pop r8
000079f9de5e1043  pop rsi
000079f9de5e1044  pop rdi
000079f9de5e1045  pop rdx
000079f9de5e1046  pop rcx
000079f9de5e1047  pop rax
000079f9de5e1048  add rsp, 0x08
000079f9de5e104c  jmp 0x000079F9DE5DC72B
000079f9de5e1051  sub rsp, 0x08
000079f9de5e1055  push rax
000079f9de5e1056  push rcx
000079f9de5e1057  push rdx
000079f9de5e1058  push rdi
000079f9de5e1059  push rsi
000079f9de5e105a  push r8
000079f9de5e105c  push r9
000079f9de5e105e  push r10
000079f9de5e1060  push r11
000079f9de5e1062  sub rsp, 0xF0
000079f9de5e1069  vmovaps [rsp], xmm0
000079f9de5e106e  vmovaps [rsp+0x10], xmm2
000079f9de5e1074  vmovaps [rsp+0x20], xmm3
000079f9de5e107a  vmovaps [rsp+0x30], xmm4
000079f9de5e1080  vmovaps [rsp+0x40], xmm5
000079f9de5e1086  vmovaps [rsp+0x50], xmm6
000079f9de5e108c  vmovaps [rsp+0x60], xmm7
000079f9de5e1092  vmovaps [rsp+0x70], xmm8
000079f9de5e1098  vmovaps [rsp+0x80], xmm9
000079f9de5e10a1  vmovaps [rsp+0x90], xmm10
000079f9de5e10aa  vmovaps [rsp+0xA0], xmm11
000079f9de5e10b3  vmovaps [rsp+0xB0], xmm12
000079f9de5e10bc  vmovaps [rsp+0xC0], xmm13
000079f9de5e10c5  vmovaps [rsp+0xD0], xmm14
000079f9de5e10ce  vmovaps [rsp+0xE0], xmm15
000079f9de5e10d7  sub rsp, 0x30
000079f9de5e10db  movaps [rsp], xmm1
000079f9de5e10df  movaps [rsp+0x10], xmm13
000079f9de5e10e5  movaps [rsp+0x20], xmm8
000079f9de5e10eb  lea rdi, [rsp]
000079f9de5e10ef  mov esi, 0x00
000079f9de5e10f4  mov rax, 0x56D56FF59530
000079f9de5e10fe  call rax
000079f9de5e1100  movaps xmm1, [rsp]
000079f9de5e1104  add rsp, 0x30
000079f9de5e1108  vmovaps xmm0, [rsp]
000079f9de5e110d  vmovaps xmm2, [rsp+0x10]
000079f9de5e1113  vmovaps xmm3, [rsp+0x20]
000079f9de5e1119  vmovaps xmm4, [rsp+0x30]
000079f9de5e111f  vmovaps xmm5, [rsp+0x40]
000079f9de5e1125  vmovaps xmm6, [rsp+0x50]
000079f9de5e112b  vmovaps xmm7, [rsp+0x60]
000079f9de5e1131  vmovaps xmm8, [rsp+0x70]
000079f9de5e1137  vmovaps xmm9, [rsp+0x80]
000079f9de5e1140  vmovaps xmm10, [rsp+0x90]
000079f9de5e1149  vmovaps xmm11, [rsp+0xA0]
000079f9de5e1152  vmovaps xmm12, [rsp+0xB0]
000079f9de5e115b  vmovaps xmm13, [rsp+0xC0]
000079f9de5e1164  vmovaps xmm14, [rsp+0xD0]
000079f9de5e116d  vmovaps xmm15, [rsp+0xE0]
000079f9de5e1176  add rsp, 0xF0
000079f9de5e117d  pop r11
000079f9de5e117f  pop r10
000079f9de5e1181  pop r9
000079f9de5e1183  pop r8
000079f9de5e1185  pop rsi
000079f9de5e1186  pop rdi
000079f9de5e1187  pop rdx
000079f9de5e1188  pop rcx
000079f9de5e1189  pop rax
000079f9de5e118a  add rsp, 0x08
000079f9de5e118e  jmp 0x000079F9DE5DC74D
000079f9de5e1193  call 0x000079F9DE40C260
000079f9de5e1198  jmp 0x000079F9DE5DC75B
000079f9de5e119d  call 0x000079F9DE4BD750
000079f9de5e11a2  jmp 0x000079F9DE5DC765
000079f9de5e11a7  sub rsp, 0x08
000079f9de5e11ab  push rax
000079f9de5e11ac  push rcx
000079f9de5e11ad  push rdx
000079f9de5e11ae  push rdi
000079f9de5e11af  push rsi
000079f9de5e11b0  push r8
000079f9de5e11b2  push r9
000079f9de5e11b4  push r10
000079f9de5e11b6  push r11
000079f9de5e11b8  sub rsp, 0xF0
000079f9de5e11bf  vmovaps [rsp], xmm0
000079f9de5e11c4  vmovaps [rsp+0x10], xmm1
000079f9de5e11ca  vmovaps [rsp+0x20], xmm2
000079f9de5e11d0  vmovaps [rsp+0x30], xmm3
000079f9de5e11d6  vmovaps [rsp+0x40], xmm4
000079f9de5e11dc  vmovaps [rsp+0x50], xmm5
000079f9de5e11e2  vmovaps [rsp+0x60], xmm6
000079f9de5e11e8  vmovaps [rsp+0x70], xmm7
000079f9de5e11ee  vmovaps [rsp+0x80], xmm9
000079f9de5e11f7  vmovaps [rsp+0x90], xmm10
000079f9de5e1200  vmovaps [rsp+0xA0], xmm11
000079f9de5e1209  vmovaps [rsp+0xB0], xmm12
000079f9de5e1212  vmovaps [rsp+0xC0], xmm13
000079f9de5e121b  vmovaps [rsp+0xD0], xmm14
000079f9de5e1224  vmovaps [rsp+0xE0], xmm15
000079f9de5e122d  sub rsp, 0x30
000079f9de5e1231  movaps [rsp], xmm8
000079f9de5e1236  movaps [rsp+0x10], xmm15
000079f9de5e123c  movaps [rsp+0x20], xmm7
000079f9de5e1241  lea rdi, [rsp]
000079f9de5e1245  mov esi, 0x00
000079f9de5e124a  mov rax, 0x56D56FF59530
000079f9de5e1254  call rax
000079f9de5e1256  movaps xmm8, [rsp]
000079f9de5e125b  add rsp, 0x30
000079f9de5e125f  vmovaps xmm0, [rsp]
000079f9de5e1264  vmovaps xmm1, [rsp+0x10]
000079f9de5e126a  vmovaps xmm2, [rsp+0x20]
000079f9de5e1270  vmovaps xmm3, [rsp+0x30]
000079f9de5e1276  vmovaps xmm4, [rsp+0x40]
000079f9de5e127c  vmovaps xmm5, [rsp+0x50]
000079f9de5e1282  vmovaps xmm6, [rsp+0x60]
000079f9de5e1288  vmovaps xmm7, [rsp+0x70]
000079f9de5e128e  vmovaps xmm9, [rsp+0x80]
000079f9de5e1297  vmovaps xmm10, [rsp+0x90]
000079f9de5e12a0  vmovaps xmm11, [rsp+0xA0]
000079f9de5e12a9  vmovaps xmm12, [rsp+0xB0]
000079f9de5e12b2  vmovaps xmm13, [rsp+0xC0]
000079f9de5e12bb  vmovaps xmm14, [rsp+0xD0]
000079f9de5e12c4  vmovaps xmm15, [rsp+0xE0]
000079f9de5e12cd  add rsp, 0xF0
000079f9de5e12d4  pop r11
000079f9de5e12d6  pop r10
000079f9de5e12d8  pop r9
000079f9de5e12da  pop r8
000079f9de5e12dc  pop rsi
000079f9de5e12dd  pop rdi
000079f9de5e12de  pop rdx
000079f9de5e12df  pop rcx
000079f9de5e12e0  pop rax
000079f9de5e12e1  add rsp, 0x08
000079f9de5e12e5  jmp 0x000079F9DE5DC787
000079f9de5e12ea  sub rsp, 0x08
000079f9de5e12ee  push rax
000079f9de5e12ef  push rcx
000079f9de5e12f0  push rdx
000079f9de5e12f1  push rdi
000079f9de5e12f2  push rsi
000079f9de5e12f3  push r8
000079f9de5e12f5  push r9
000079f9de5e12f7  push r10
000079f9de5e12f9  push r11
000079f9de5e12fb  sub rsp, 0xF0
000079f9de5e1302  vmovaps [rsp], xmm0
000079f9de5e1307  vmovaps [rsp+0x10], xmm1
000079f9de5e130d  vmovaps [rsp+0x20], xmm2
000079f9de5e1313  vmovaps [rsp+0x30], xmm3
000079f9de5e1319  vmovaps [rsp+0x40], xmm4
000079f9de5e131f  vmovaps [rsp+0x50], xmm5
000079f9de5e1325  vmovaps [rsp+0x60], xmm6
000079f9de5e132b  vmovaps [rsp+0x70], xmm8
000079f9de5e1331  vmovaps [rsp+0x80], xmm9
000079f9de5e133a  vmovaps [rsp+0x90], xmm10
000079f9de5e1343  vmovaps [rsp+0xA0], xmm11
000079f9de5e134c  vmovaps [rsp+0xB0], xmm12
000079f9de5e1355  vmovaps [rsp+0xC0], xmm13
000079f9de5e135e  vmovaps [rsp+0xD0], xmm14
000079f9de5e1367  vmovaps [rsp+0xE0], xmm15
000079f9de5e1370  sub rsp, 0x30
000079f9de5e1374  movaps [rsp], xmm7
000079f9de5e1378  movaps [rsp+0x10], xmm9
000079f9de5e137e  movaps [rsp+0x20], xmm15
000079f9de5e1384  lea rdi, [rsp]
000079f9de5e1388  mov esi, 0x00
000079f9de5e138d  mov rax, 0x56D56FF59530
000079f9de5e1397  call rax
000079f9de5e1399  movaps xmm7, [rsp]
000079f9de5e139d  add rsp, 0x30
000079f9de5e13a1  vmovaps xmm0, [rsp]
000079f9de5e13a6  vmovaps xmm1, [rsp+0x10]
000079f9de5e13ac  vmovaps xmm2, [rsp+0x20]
000079f9de5e13b2  vmovaps xmm3, [rsp+0x30]
000079f9de5e13b8  vmovaps xmm4, [rsp+0x40]
000079f9de5e13be  vmovaps xmm5, [rsp+0x50]
000079f9de5e13c4  vmovaps xmm6, [rsp+0x60]
000079f9de5e13ca  vmovaps xmm8, [rsp+0x70]
000079f9de5e13d0  vmovaps xmm9, [rsp+0x80]
000079f9de5e13d9  vmovaps xmm10, [rsp+0x90]
000079f9de5e13e2  vmovaps xmm11, [rsp+0xA0]
000079f9de5e13eb  vmovaps xmm12, [rsp+0xB0]
000079f9de5e13f4  vmovaps xmm13, [rsp+0xC0]
000079f9de5e13fd  vmovaps xmm14, [rsp+0xD0]
000079f9de5e1406  vmovaps xmm15, [rsp+0xE0]
000079f9de5e140f  add rsp, 0xF0
000079f9de5e1416  pop r11
000079f9de5e1418  pop r10
000079f9de5e141a  pop r9
000079f9de5e141c  pop r8
000079f9de5e141e  pop rsi
000079f9de5e141f  pop rdi
000079f9de5e1420  pop rdx
000079f9de5e1421  pop rcx
000079f9de5e1422  pop rax
000079f9de5e1423  add rsp, 0x08
000079f9de5e1427  jmp 0x000079F9DE5DC7B4
000079f9de5e142c  sub rsp, 0x08
000079f9de5e1430  push rax
000079f9de5e1431  push rcx
000079f9de5e1432  push rdx
000079f9de5e1433  push rdi
000079f9de5e1434  push rsi
000079f9de5e1435  push r8
000079f9de5e1437  push r9
000079f9de5e1439  push r10
000079f9de5e143b  push r11
000079f9de5e143d  sub rsp, 0xF0
000079f9de5e1444  vmovaps [rsp], xmm0
000079f9de5e1449  vmovaps [rsp+0x10], xmm1
000079f9de5e144f  vmovaps [rsp+0x20], xmm2
000079f9de5e1455  vmovaps [rsp+0x30], xmm3
000079f9de5e145b  vmovaps [rsp+0x40], xmm4
000079f9de5e1461  vmovaps [rsp+0x50], xmm5
000079f9de5e1467  vmovaps [rsp+0x60], xmm6
000079f9de5e146d  vmovaps [rsp+0x70], xmm7
000079f9de5e1473  vmovaps [rsp+0x80], xmm8
000079f9de5e147c  vmovaps [rsp+0x90], xmm10
000079f9de5e1485  vmovaps [rsp+0xA0], xmm11
000079f9de5e148e  vmovaps [rsp+0xB0], xmm12
000079f9de5e1497  vmovaps [rsp+0xC0], xmm13
000079f9de5e14a0  vmovaps [rsp+0xD0], xmm14
000079f9de5e14a9  vmovaps [rsp+0xE0], xmm15
000079f9de5e14b2  sub rsp, 0x30
000079f9de5e14b6  movaps [rsp], xmm9
000079f9de5e14bb  movaps [rsp+0x10], xmm13
000079f9de5e14c1  movaps [rsp+0x20], xmm15
000079f9de5e14c7  lea rdi, [rsp]
000079f9de5e14cb  mov esi, 0x00
000079f9de5e14d0  mov rax, 0x56D56FF59530
000079f9de5e14da  call rax
000079f9de5e14dc  movaps xmm9, [rsp]
000079f9de5e14e1  add rsp, 0x30
000079f9de5e14e5  vmovaps xmm0, [rsp]
000079f9de5e14ea  vmovaps xmm1, [rsp+0x10]
000079f9de5e14f0  vmovaps xmm2, [rsp+0x20]
000079f9de5e14f6  vmovaps xmm3, [rsp+0x30]
000079f9de5e14fc  vmovaps xmm4, [rsp+0x40]
000079f9de5e1502  vmovaps xmm5, [rsp+0x50]
000079f9de5e1508  vmovaps xmm6, [rsp+0x60]
000079f9de5e150e  vmovaps xmm7, [rsp+0x70]
000079f9de5e1514  vmovaps xmm8, [rsp+0x80]
000079f9de5e151d  vmovaps xmm10, [rsp+0x90]
000079f9de5e1526  vmovaps xmm11, [rsp+0xA0]
000079f9de5e152f  vmovaps xmm12, [rsp+0xB0]
000079f9de5e1538  vmovaps xmm13, [rsp+0xC0]
000079f9de5e1541  vmovaps xmm14, [rsp+0xD0]
000079f9de5e154a  vmovaps xmm15, [rsp+0xE0]
000079f9de5e1553  add rsp, 0xF0
000079f9de5e155a  pop r11
000079f9de5e155c  pop r10
000079f9de5e155e  pop r9
000079f9de5e1560  pop r8
000079f9de5e1562  pop rsi
000079f9de5e1563  pop rdi
000079f9de5e1564  pop rdx
000079f9de5e1565  pop rcx
000079f9de5e1566  pop rax
000079f9de5e1567  add rsp, 0x08
000079f9de5e156b  jmp 0x000079F9DE5DC7E2
000079f9de5e1570  sub rsp, 0x08
000079f9de5e1574  push rax
000079f9de5e1575  push rcx
000079f9de5e1576  push rdx
000079f9de5e1577  push rdi
000079f9de5e1578  push rsi
000079f9de5e1579  push r8
000079f9de5e157b  push r9
000079f9de5e157d  push r10
000079f9de5e157f  push r11
000079f9de5e1581  sub rsp, 0xF0
000079f9de5e1588  vmovaps [rsp], xmm0
000079f9de5e158d  vmovaps [rsp+0x10], xmm1
000079f9de5e1593  vmovaps [rsp+0x20], xmm2
000079f9de5e1599  vmovaps [rsp+0x30], xmm3
000079f9de5e159f  vmovaps [rsp+0x40], xmm4
000079f9de5e15a5  vmovaps [rsp+0x50], xmm5
000079f9de5e15ab  vmovaps [rsp+0x60], xmm6
000079f9de5e15b1  vmovaps [rsp+0x70], xmm7
000079f9de5e15b7  vmovaps [rsp+0x80], xmm8
000079f9de5e15c0  vmovaps [rsp+0x90], xmm9
000079f9de5e15c9  vmovaps [rsp+0xA0], xmm10
000079f9de5e15d2  vmovaps [rsp+0xB0], xmm11
000079f9de5e15db  vmovaps [rsp+0xC0], xmm12
000079f9de5e15e4  vmovaps [rsp+0xD0], xmm13
000079f9de5e15ed  vmovaps [rsp+0xE0], xmm14
000079f9de5e15f6  sub rsp, 0x30
000079f9de5e15fa  movaps [rsp], xmm15
000079f9de5e15ff  movaps [rsp+0x10], xmm11
000079f9de5e1605  movaps [rsp+0x20], xmm12
000079f9de5e160b  lea rdi, [rsp]
000079f9de5e160f  mov esi, 0x00
000079f9de5e1614  mov rax, 0x56D56FF59530
000079f9de5e161e  call rax
000079f9de5e1620  movaps xmm15, [rsp]
000079f9de5e1625  add rsp, 0x30
000079f9de5e1629  vmovaps xmm0, [rsp]
000079f9de5e162e  vmovaps xmm1, [rsp+0x10]
000079f9de5e1634  vmovaps xmm2, [rsp+0x20]
000079f9de5e163a  vmovaps xmm3, [rsp+0x30]
000079f9de5e1640  vmovaps xmm4, [rsp+0x40]
000079f9de5e1646  vmovaps xmm5, [rsp+0x50]
000079f9de5e164c  vmovaps xmm6, [rsp+0x60]
000079f9de5e1652  vmovaps xmm7, [rsp+0x70]
000079f9de5e1658  vmovaps xmm8, [rsp+0x80]
000079f9de5e1661  vmovaps xmm9, [rsp+0x90]
000079f9de5e166a  vmovaps xmm10, [rsp+0xA0]
000079f9de5e1673  vmovaps xmm11, [rsp+0xB0]
000079f9de5e167c  vmovaps xmm12, [rsp+0xC0]
000079f9de5e1685  vmovaps xmm13, [rsp+0xD0]
000079f9de5e168e  vmovaps xmm14, [rsp+0xE0]
000079f9de5e1697  add rsp, 0xF0
000079f9de5e169e  pop r11
000079f9de5e16a0  pop r10
000079f9de5e16a2  pop r9
000079f9de5e16a4  pop r8
000079f9de5e16a6  pop rsi
000079f9de5e16a7  pop rdi
000079f9de5e16a8  pop rdx
000079f9de5e16a9  pop rcx
000079f9de5e16aa  pop rax
000079f9de5e16ab  add rsp, 0x08
000079f9de5e16af  jmp 0x000079F9DE5DC7FD
000079f9de5e16b4  sub rsp, 0x08
000079f9de5e16b8  push rax
000079f9de5e16b9  push rcx
000079f9de5e16ba  push rdx
000079f9de5e16bb  push rdi
000079f9de5e16bc  push rsi
000079f9de5e16bd  push r8
000079f9de5e16bf  push r9
000079f9de5e16c1  push r10
000079f9de5e16c3  push r11
000079f9de5e16c5  sub rsp, 0xF0
000079f9de5e16cc  vmovaps [rsp], xmm0
000079f9de5e16d1  vmovaps [rsp+0x10], xmm1
000079f9de5e16d7  vmovaps [rsp+0x20], xmm2
000079f9de5e16dd  vmovaps [rsp+0x30], xmm3
000079f9de5e16e3  vmovaps [rsp+0x40], xmm4
000079f9de5e16e9  vmovaps [rsp+0x50], xmm5
000079f9de5e16ef  vmovaps [rsp+0x60], xmm6
000079f9de5e16f5  vmovaps [rsp+0x70], xmm7
000079f9de5e16fb  vmovaps [rsp+0x80], xmm8
000079f9de5e1704  vmovaps [rsp+0x90], xmm9
000079f9de5e170d  vmovaps [rsp+0xA0], xmm10
000079f9de5e1716  vmovaps [rsp+0xB0], xmm11
000079f9de5e171f  vmovaps [rsp+0xC0], xmm12
000079f9de5e1728  vmovaps [rsp+0xD0], xmm14
000079f9de5e1731  vmovaps [rsp+0xE0], xmm15
000079f9de5e173a  sub rsp, 0x30
000079f9de5e173e  movaps [rsp], xmm13
000079f9de5e1743  movaps [rsp+0x10], xmm10
000079f9de5e1749  movaps [rsp+0x20], xmm14
000079f9de5e174f  lea rdi, [rsp]
000079f9de5e1753  mov esi, 0x00
000079f9de5e1758  mov rax, 0x56D56FF59530
000079f9de5e1762  call rax
000079f9de5e1764  movaps xmm13, [rsp]
000079f9de5e1769  add rsp, 0x30
000079f9de5e176d  vmovaps xmm0, [rsp]
000079f9de5e1772  vmovaps xmm1, [rsp+0x10]
000079f9de5e1778  vmovaps xmm2, [rsp+0x20]
000079f9de5e177e  vmovaps xmm3, [rsp+0x30]
000079f9de5e1784  vmovaps xmm4, [rsp+0x40]
000079f9de5e178a  vmovaps xmm5, [rsp+0x50]
000079f9de5e1790  vmovaps xmm6, [rsp+0x60]
000079f9de5e1796  vmovaps xmm7, [rsp+0x70]
000079f9de5e179c  vmovaps xmm8, [rsp+0x80]
000079f9de5e17a5  vmovaps xmm9, [rsp+0x90]
000079f9de5e17ae  vmovaps xmm10, [rsp+0xA0]
000079f9de5e17b7  vmovaps xmm11, [rsp+0xB0]
000079f9de5e17c0  vmovaps xmm12, [rsp+0xC0]
000079f9de5e17c9  vmovaps xmm14, [rsp+0xD0]
000079f9de5e17d2  vmovaps xmm15, [rsp+0xE0]
000079f9de5e17db  add rsp, 0xF0
000079f9de5e17e2  pop r11
000079f9de5e17e4  pop r10
000079f9de5e17e6  pop r9
000079f9de5e17e8  pop r8
000079f9de5e17ea  pop rsi
000079f9de5e17eb  pop rdi
000079f9de5e17ec  pop rdx
000079f9de5e17ed  pop rcx
000079f9de5e17ee  pop rax
000079f9de5e17ef  add rsp, 0x08
000079f9de5e17f3  jmp 0x000079F9DE5DC820
000079f9de5e17f8  sub rsp, 0x08
000079f9de5e17fc  push rax
000079f9de5e17fd  push rcx
000079f9de5e17fe  push rdx
000079f9de5e17ff  push rdi
000079f9de5e1800  push rsi
000079f9de5e1801  push r8
000079f9de5e1803  push r9
000079f9de5e1805  push r10
000079f9de5e1807  push r11
000079f9de5e1809  sub rsp, 0xF0
000079f9de5e1810  vmovaps [rsp], xmm0
000079f9de5e1815  vmovaps [rsp+0x10], xmm1
000079f9de5e181b  vmovaps [rsp+0x20], xmm2
000079f9de5e1821  vmovaps [rsp+0x30], xmm3
000079f9de5e1827  vmovaps [rsp+0x40], xmm4
000079f9de5e182d  vmovaps [rsp+0x50], xmm5
000079f9de5e1833  vmovaps [rsp+0x60], xmm6
000079f9de5e1839  vmovaps [rsp+0x70], xmm7
000079f9de5e183f  vmovaps [rsp+0x80], xmm8
000079f9de5e1848  vmovaps [rsp+0x90], xmm9
000079f9de5e1851  vmovaps [rsp+0xA0], xmm10
000079f9de5e185a  vmovaps [rsp+0xB0], xmm11
000079f9de5e1863  vmovaps [rsp+0xC0], xmm12
000079f9de5e186c  vmovaps [rsp+0xD0], xmm13
000079f9de5e1875  vmovaps [rsp+0xE0], xmm15
000079f9de5e187e  sub rsp, 0x30
000079f9de5e1882  movaps [rsp], xmm14
000079f9de5e1887  movaps [rsp+0x10], xmm1
000079f9de5e188c  movaps [rsp+0x20], xmm7
000079f9de5e1891  lea rdi, [rsp]
000079f9de5e1895  mov esi, 0x00
000079f9de5e189a  mov rax, 0x56D56FF59530
000079f9de5e18a4  call rax
000079f9de5e18a6  movaps xmm14, [rsp]
000079f9de5e18ab  add rsp, 0x30
000079f9de5e18af  vmovaps xmm0, [rsp]
000079f9de5e18b4  vmovaps xmm1, [rsp+0x10]
000079f9de5e18ba  vmovaps xmm2, [rsp+0x20]
000079f9de5e18c0  vmovaps xmm3, [rsp+0x30]
000079f9de5e18c6  vmovaps xmm4, [rsp+0x40]
000079f9de5e18cc  vmovaps xmm5, [rsp+0x50]
000079f9de5e18d2  vmovaps xmm6, [rsp+0x60]
000079f9de5e18d8  vmovaps xmm7, [rsp+0x70]
000079f9de5e18de  vmovaps xmm8, [rsp+0x80]
000079f9de5e18e7  vmovaps xmm9, [rsp+0x90]
000079f9de5e18f0  vmovaps xmm10, [rsp+0xA0]
000079f9de5e18f9  vmovaps xmm11, [rsp+0xB0]
000079f9de5e1902  vmovaps xmm12, [rsp+0xC0]
000079f9de5e190b  vmovaps xmm13, [rsp+0xD0]
000079f9de5e1914  vmovaps xmm15, [rsp+0xE0]
000079f9de5e191d  add rsp, 0xF0
000079f9de5e1924  pop r11
000079f9de5e1926  pop r10
000079f9de5e1928  pop r9
000079f9de5e192a  pop r8
000079f9de5e192c  pop rsi
000079f9de5e192d  pop rdi
000079f9de5e192e  pop rdx
000079f9de5e192f  pop rcx
000079f9de5e1930  pop rax
000079f9de5e1931  add rsp, 0x08
000079f9de5e1935  jmp 0x000079F9DE5DC843
000079f9de5e193a  sub rsp, 0x08
000079f9de5e193e  push rax
000079f9de5e193f  push rcx
000079f9de5e1940  push rdx
000079f9de5e1941  push rdi
000079f9de5e1942  push rsi
000079f9de5e1943  push r8
000079f9de5e1945  push r9
000079f9de5e1947  push r10
000079f9de5e1949  push r11
000079f9de5e194b  sub rsp, 0xF0
000079f9de5e1952  vmovaps [rsp], xmm0
000079f9de5e1957  vmovaps [rsp+0x10], xmm2
000079f9de5e195d  vmovaps [rsp+0x20], xmm3
000079f9de5e1963  vmovaps [rsp+0x30], xmm4
000079f9de5e1969  vmovaps [rsp+0x40], xmm5
000079f9de5e196f  vmovaps [rsp+0x50], xmm6
000079f9de5e1975  vmovaps [rsp+0x60], xmm7
000079f9de5e197b  vmovaps [rsp+0x70], xmm8
000079f9de5e1981  vmovaps [rsp+0x80], xmm9
000079f9de5e198a  vmovaps [rsp+0x90], xmm10
000079f9de5e1993  vmovaps [rsp+0xA0], xmm11
000079f9de5e199c  vmovaps [rsp+0xB0], xmm12
000079f9de5e19a5  vmovaps [rsp+0xC0], xmm13
000079f9de5e19ae  vmovaps [rsp+0xD0], xmm14
000079f9de5e19b7  vmovaps [rsp+0xE0], xmm15
000079f9de5e19c0  sub rsp, 0x30
000079f9de5e19c4  movaps [rsp], xmm1
000079f9de5e19c8  movaps [rsp+0x10], xmm8
000079f9de5e19ce  movaps [rsp+0x20], xmm9
000079f9de5e19d4  lea rdi, [rsp]
000079f9de5e19d8  mov esi, 0x00
000079f9de5e19dd  mov rax, 0x56D56FF59530
000079f9de5e19e7  call rax
000079f9de5e19e9  movaps xmm1, [rsp]
000079f9de5e19ed  add rsp, 0x30
000079f9de5e19f1  vmovaps xmm0, [rsp]
000079f9de5e19f6  vmovaps xmm2, [rsp+0x10]
000079f9de5e19fc  vmovaps xmm3, [rsp+0x20]
000079f9de5e1a02  vmovaps xmm4, [rsp+0x30]
000079f9de5e1a08  vmovaps xmm5, [rsp+0x40]
000079f9de5e1a0e  vmovaps xmm6, [rsp+0x50]
000079f9de5e1a14  vmovaps xmm7, [rsp+0x60]
000079f9de5e1a1a  vmovaps xmm8, [rsp+0x70]
000079f9de5e1a20  vmovaps xmm9, [rsp+0x80]
000079f9de5e1a29  vmovaps xmm10, [rsp+0x90]
000079f9de5e1a32  vmovaps xmm11, [rsp+0xA0]
000079f9de5e1a3b  vmovaps xmm12, [rsp+0xB0]
000079f9de5e1a44  vmovaps xmm13, [rsp+0xC0]
000079f9de5e1a4d  vmovaps xmm14, [rsp+0xD0]
000079f9de5e1a56  vmovaps xmm15, [rsp+0xE0]
000079f9de5e1a5f  add rsp, 0xF0
000079f9de5e1a66  pop r11
000079f9de5e1a68  pop r10
000079f9de5e1a6a  pop r9
000079f9de5e1a6c  pop r8
000079f9de5e1a6e  pop rsi
000079f9de5e1a6f  pop rdi
000079f9de5e1a70  pop rdx
000079f9de5e1a71  pop rcx
000079f9de5e1a72  pop rax
000079f9de5e1a73  add rsp, 0x08
000079f9de5e1a77  jmp 0x000079F9DE5DC865
000079f9de5e1a7c  call 0x000079F9DE4E5940
000079f9de5e1a81  jmp 0x000079F9DE5DC873
000079f9de5e1a86  call 0x000079F9DE40C380
000079f9de5e1a8b  jmp 0x000079F9DE5DC87D
000079f9de5e1a90  call 0x000079F9DE40D600
000079f9de5e1a95  jmp 0x000079F9DE5DC887
000079f9de5e1a9a  call 0x000079F9DE3FF540
000079f9de5e1a9f  jmp 0x000079F9DE5DC891
000079f9de5e1aa4  int3
000079f9de5e1aa5  nop [rax+rax*1], ax
000079f9de5e1aae  nop
000079f9de5e1ab0  mov rax, [r15+0xF8]
000079f9de5e1ab7  lea r14, [rax+0x140]
000079f9de5e1abe  mov r12, [r13+r14*1]
000079f9de5e1ac3  mov [r15+0xE8], r12
000079f9de5e1aca  lea r14, [rax+0x130]
000079f9de5e1ad1  mov r12, [r13+r14*1]
000079f9de5e1ad6  lea r14, [rax+0x138]
000079f9de5e1add  mov r11, [r13+r14*1]
000079f9de5e1ae2  movq xmm1, r12
000079f9de5e1ae7  movq xmm15, r11
000079f9de5e1aec  movq xmm1, xmm1
000079f9de5e1af0  movq xmm1, xmm1
000079f9de5e1af4  movaps [r15+0x1A0], xmm1
000079f9de5e1afc  movq xmm15, xmm15
000079f9de5e1b01  movq xmm15, xmm15
000079f9de5e1b06  movaps [r15+0x190], xmm15
000079f9de5e1b0e  lea r14, [rax+0x120]
000079f9de5e1b15  mov r12, [r13+r14*1]
000079f9de5e1b1a  lea r14, [rax+0x128]
000079f9de5e1b21  mov r11, [r13+r14*1]
000079f9de5e1b26  movq xmm1, r12
000079f9de5e1b2b  movq xmm15, r11
000079f9de5e1b30  movq xmm1, xmm1
000079f9de5e1b34  movq xmm1, xmm1
000079f9de5e1b38  movaps [r15+0x1C0], xmm1
000079f9de5e1b40  movq xmm15, xmm15
000079f9de5e1b45  movq xmm15, xmm15
000079f9de5e1b4a  movaps [r15+0x1B0], xmm15
000079f9de5e1b52  lea r14, [rax+0x110]
000079f9de5e1b59  mov r12, [r13+r14*1]
000079f9de5e1b5e  lea r14, [rax+0x118]
000079f9de5e1b65  mov r11, [r13+r14*1]
000079f9de5e1b6a  movq xmm1, r12
000079f9de5e1b6f  movq xmm15, r11
000079f9de5e1b74  movq xmm1, xmm1
000079f9de5e1b78  movq xmm1, xmm1
000079f9de5e1b7c  movaps [r15+0x1E0], xmm1
000079f9de5e1b84  movq xmm15, xmm15
000079f9de5e1b89  movq xmm15, xmm15
000079f9de5e1b8e  movaps [r15+0x1D0], xmm15
000079f9de5e1b96  lea r14, [rax+0x100]
000079f9de5e1b9d  mov r12, [r13+r14*1]
000079f9de5e1ba2  lea r14, [rax+0x108]
000079f9de5e1ba9  mov r11, [r13+r14*1]
000079f9de5e1bae  movq xmm1, r12
000079f9de5e1bb3  movq xmm15, r11
000079f9de5e1bb8  movq xmm1, xmm1
000079f9de5e1bbc  movq xmm1, xmm1
000079f9de5e1bc0  movaps [r15+0x200], xmm1
000079f9de5e1bc8  movq xmm15, xmm15
000079f9de5e1bcd  movq xmm15, xmm15
000079f9de5e1bd2  movaps [r15+0x1F0], xmm15
000079f9de5e1bda  mov qword ptr [r15+0x40], 0x430000
000079f9de5e1be2  mov r14d, 0x430510
000079f9de5e1be8  mov r12, [r13+r14*1]
000079f9de5e1bed  movq xmm1, r12
000079f9de5e1bf2  lea r14, [rax+0x150]
000079f9de5e1bf9  mov [r15+0xF8], r14
000079f9de5e1c00  mov rax, [r15+0x50]
000079f9de5e1c04  movups xmm15, [r13+rax*1]
000079f9de5e1c0a  movaps [r15+0x120], xmm15
000079f9de5e1c12  mov qword ptr [r15+0x48], 0x10
000079f9de5e1c1a  xor eax, eax
000079f9de5e1c1c  mov r14d, 0x10
000079f9de5e1c22  mov r12d, 0x200
000079f9de5e1c28  cmp r14, r12
000079f9de5e1c2b  cmc
000079f9de5e1c2c  lahf
000079f9de5e1c2d  seto al
000079f9de5e1c30  mov [r15+0x108], eax
000079f9de5e1c37  pextrq rax, xmm15, 0x01
000079f9de5e1c3e  movq xmm14, rax
000079f9de5e1c43  movaps [r15+0x130], xmm14
000079f9de5e1c4b  movq rax, xmm1
000079f9de5e1c50  movq r14, xmm15
000079f9de5e1c55  vmovq xmm1, rax
000079f9de5e1c5a  vmovq xmm15, r14
000079f9de5e1c5f  movaps xmm13, xmm1
000079f9de5e1c63  addsd xmm13, xmm15
000079f9de5e1c68  ucomisd xmm13, xmm13
000079f9de5e1c6d  jp 0x000079F9DE5E1D86
000079f9de5e1c73  movq xmm13, xmm13
000079f9de5e1c78  movq rax, xmm13
000079f9de5e1c7d  movq r14, xmm14
000079f9de5e1c82  vmovq xmm1, rax
000079f9de5e1c87  vmovq xmm15, r14
000079f9de5e1c8c  movaps xmm14, xmm1
000079f9de5e1c90  addsd xmm14, xmm15
000079f9de5e1c95  ucomisd xmm14, xmm14
000079f9de5e1c9a  jp 0x000079F9DE5E1DCE
000079f9de5e1ca0  movq xmm14, xmm14
000079f9de5e1ca5  movaps [r15+0x110], xmm14
000079f9de5e1cad  mov eax, [r15+0x108]
000079f9de5e1cb4  sahf
000079f9de5e1cb5  jnz 0x000079F9DE5E1CE7
000079f9de5e1cb7  cmp dword ptr [r15+0x318], 0x00
000079f9de5e1cbf  jz 0x000079F9DE5E1FE0
000079f9de5e1cc5  nop [rax+rax*1], ax
000079f9de5e1cce  nop [rax+rax*1], eax
000079f9de5e1cd6  mov eax, 0x410490
000079f9de5e1cdb  mov [r15+0x100], rax
000079f9de5e1ce2  jmp 0x000079F9DE3FE110
000079f9de5e1ce7  cmp dword ptr [r15+0x318], 0x00
000079f9de5e1cef  jz 0x000079F9DE5E1E20
000079f9de5e1cf5  nop [rax+rax*1], ax
000079f9de5e1cfe  nop [rax+rax*1], eax
000079f9de5e1d06  mov eax, 0x410474
000079f9de5e1d0b  mov [r15+0x100], rax
000079f9de5e1d12  jmp 0x000079F9DE3FE110
000079f9de5e1d17  int3
000079f9de5e1d18  call 0x000079F9DE4E27E0
000079f9de5e1d1d  jmp 0x000079F9DE5E1AC3
000079f9de5e1d22  call 0x000079F9DE4E27E0
000079f9de5e1d27  jmp 0x000079F9DE5E1AD6
000079f9de5e1d2c  call 0x000079F9DE4E1570
000079f9de5e1d31  jmp 0x000079F9DE5E1AE2
000079f9de5e1d36  call 0x000079F9DE4E27E0
000079f9de5e1d3b  jmp 0x000079F9DE5E1B1A
000079f9de5e1d40  call 0x000079F9DE4E1570
000079f9de5e1d45  jmp 0x000079F9DE5E1B26
000079f9de5e1d4a  call 0x000079F9DE4E27E0
000079f9de5e1d4f  jmp 0x000079F9DE5E1B5E
000079f9de5e1d54  call 0x000079F9DE4E1570
000079f9de5e1d59  jmp 0x000079F9DE5E1B6A
000079f9de5e1d5e  call 0x000079F9DE4E27E0
000079f9de5e1d63  jmp 0x000079F9DE5E1BA2
000079f9de5e1d68  call 0x000079F9DE4E1570
000079f9de5e1d6d  jmp 0x000079F9DE5E1BAE
000079f9de5e1d72  call 0x000079F9DE4E27E0
000079f9de5e1d77  jmp 0x000079F9DE5E1BED
000079f9de5e1d7c  call 0x000079F9DE40E760
000079f9de5e1d81  jmp 0x000079F9DE5E1C0A
000079f9de5e1d86  ucomisd xmm1, xmm15
000079f9de5e1d8b  jp 0x000079F9DE5E1D9A
000079f9de5e1d8d  movaps xmm13, [0x000079F9DE1FE060]
000079f9de5e1d95  jmp 0x000079F9DE5E1C73
000079f9de5e1d9a  vxorps xmm0, xmm1, xmm15
000079f9de5e1d9f  pextrw eax, xmm0, 0x03
000079f9de5e1da4  and eax, 0x7FF8
000079f9de5e1da9  cmp eax, 0x08
000079f9de5e1dac  jnz 0x000079F9DE5E1C73
000079f9de5e1db2  movq rax, xmm15
000079f9de5e1db7  shl rax, 0x0D
000079f9de5e1dbb  jbe 0x000079F9DE5E1C73
000079f9de5e1dc1  vorps xmm13, xmm15, [0x000079F9DE1FE070]
000079f9de5e1dc9  jmp 0x000079F9DE5E1C73
000079f9de5e1dce  ucomisd xmm1, xmm15
000079f9de5e1dd3  jp 0x000079F9DE5E1DE2
000079f9de5e1dd5  movaps xmm14, [0x000079F9DE1FE060]
000079f9de5e1ddd  jmp 0x000079F9DE5E1CA0
000079f9de5e1de2  vxorps xmm0, xmm1, xmm15
000079f9de5e1de7  pextrw eax, xmm0, 0x03
000079f9de5e1dec  and eax, 0x7FF8
000079f9de5e1df1  cmp eax, 0x08
000079f9de5e1df4  jnz 0x000079F9DE5E1CA0
000079f9de5e1dfa  movq rax, xmm15
000079f9de5e1dff  shl rax, 0x0D
000079f9de5e1e03  jbe 0x000079F9DE5E1CA0
000079f9de5e1e09  vorps xmm14, xmm15, [0x000079F9DE1FE070]
000079f9de5e1e11  jmp 0x000079F9DE5E1CA0
000079f9de5e1e16  int3
000079f9de5e1e17  nop [rax+rax*1], ax
000079f9de5e1e20  mov rax, [r15+0x48]
000079f9de5e1e24  mov r14, [r15+0x50]
000079f9de5e1e28  lea r12, [r14+rax*1]
000079f9de5e1e2c  movups xmm1, [r13+r12*1]
000079f9de5e1e32  movaps [r15+0x120], xmm1
000079f9de5e1e3a  lea r14, [rax+0x10]
000079f9de5e1e3e  mov [r15+0x48], r14
000079f9de5e1e42  xor eax, eax
000079f9de5e1e44  mov r12d, 0x200
000079f9de5e1e4a  cmp r14, r12
000079f9de5e1e4d  cmc
000079f9de5e1e4e  lahf
000079f9de5e1e4f  seto al
000079f9de5e1e52  mov [r15+0x108], eax
000079f9de5e1e59  pextrq rax, xmm1, 0x01
000079f9de5e1e60  movq xmm15, rax
000079f9de5e1e65  movaps [r15+0x130], xmm15
000079f9de5e1e6d  movaps xmm14, [r15+0x110]
000079f9de5e1e75  movq rax, xmm14
000079f9de5e1e7a  movq r14, xmm1
000079f9de5e1e7f  vmovq xmm1, rax
000079f9de5e1e84  vmovq xmm14, r14
000079f9de5e1e89  movaps xmm13, xmm1
000079f9de5e1e8d  addsd xmm13, xmm14
000079f9de5e1e92  ucomisd xmm13, xmm13
000079f9de5e1e97  jp 0x000079F9DE5E1F4C
000079f9de5e1e9d  movq xmm13, xmm13
000079f9de5e1ea2  movq rax, xmm13
000079f9de5e1ea7  movq r14, xmm15
000079f9de5e1eac  vmovq xmm1, rax
000079f9de5e1eb1  vmovq xmm15, r14
000079f9de5e1eb6  movaps xmm14, xmm1
000079f9de5e1eba  addsd xmm14, xmm15
000079f9de5e1ebf  ucomisd xmm14, xmm14
000079f9de5e1ec4  jp 0x000079F9DE5E1F94
000079f9de5e1eca  movq xmm14, xmm14
000079f9de5e1ecf  movaps [r15+0x110], xmm14
000079f9de5e1ed7  mov eax, [r15+0x108]
000079f9de5e1ede  sahf
000079f9de5e1edf  jnz 0x000079F9DE5E1F11
000079f9de5e1ee1  cmp dword ptr [r15+0x318], 0x00
000079f9de5e1ee9  jz 0x000079F9DE5E1FE0
000079f9de5e1eef  nop [rax+rax*1], ax
000079f9de5e1ef8  nop [rax+rax*1], eax
000079f9de5e1f00  mov eax, 0x410490
000079f9de5e1f05  mov [r15+0x100], rax
000079f9de5e1f0c  jmp 0x000079F9DE3FE110
000079f9de5e1f11  cmp dword ptr [r15+0x318], 0x00
000079f9de5e1f19  jz 0x000079F9DE5E1E20
000079f9de5e1f1f  nop [rax+rax*1], ax
000079f9de5e1f28  nop [rax+rax*1], eax
000079f9de5e1f30  mov eax, 0x410474
000079f9de5e1f35  mov [r15+0x100], rax
000079f9de5e1f3c  jmp 0x000079F9DE3FE110
000079f9de5e1f41  int3
000079f9de5e1f42  call 0x000079F9DE4B52F0
000079f9de5e1f47  jmp 0x000079F9DE5E1E32
000079f9de5e1f4c  ucomisd xmm1, xmm14
000079f9de5e1f51  jp 0x000079F9DE5E1F60
000079f9de5e1f53  movaps xmm13, [0x000079F9DE1FE060]
000079f9de5e1f5b  jmp 0x000079F9DE5E1E9D
000079f9de5e1f60  vxorps xmm0, xmm1, xmm14
000079f9de5e1f65  pextrw eax, xmm0, 0x03
000079f9de5e1f6a  and eax, 0x7FF8
000079f9de5e1f6f  cmp eax, 0x08
000079f9de5e1f72  jnz 0x000079F9DE5E1E9D
000079f9de5e1f78  movq rax, xmm14
000079f9de5e1f7d  shl rax, 0x0D
000079f9de5e1f81  jbe 0x000079F9DE5E1E9D
000079f9de5e1f87  vorps xmm13, xmm14, [0x000079F9DE1FE070]
000079f9de5e1f8f  jmp 0x000079F9DE5E1E9D
000079f9de5e1f94  ucomisd xmm1, xmm15
000079f9de5e1f99  jp 0x000079F9DE5E1FA8
000079f9de5e1f9b  movaps xmm14, [0x000079F9DE1FE060]
000079f9de5e1fa3  jmp 0x000079F9DE5E1ECA
000079f9de5e1fa8  vxorps xmm0, xmm1, xmm15
000079f9de5e1fad  pextrw eax, xmm0, 0x03
000079f9de5e1fb2  and eax, 0x7FF8
000079f9de5e1fb7  cmp eax, 0x08
000079f9de5e1fba  jnz 0x000079F9DE5E1ECA
000079f9de5e1fc0  movq rax, xmm15
000079f9de5e1fc5  shl rax, 0x0D
000079f9de5e1fc9  jbe 0x000079F9DE5E1ECA
000079f9de5e1fcf  vorps xmm14, xmm15, [0x000079F9DE1FE070]
000079f9de5e1fd7  jmp 0x000079F9DE5E1ECA
000079f9de5e1fdc  int3
000079f9de5e1fdd  nop [rax], eax
000079f9de5e1fe0  mov rax, [r15+0x40]
000079f9de5e1fe4  lea r14, [rax+0x510]
000079f9de5e1feb  movaps xmm1, [r15+0x110]
000079f9de5e1ff3  movq rax, xmm1
000079f9de5e1ff8  mov [r13+r14*1], rax
000079f9de5e1ffd  mov rax, [r15+0xF0]
000079f9de5e2004  mov [r15+0x100], rax
000079f9de5e200b  jmp 0x000079F9DE5CE5C0
000079f9de5e2010  int3
000079f9de5e2011  call 0x000079F9DE4D5EB0
000079f9de5e2016  jmp 0x000079F9DE5E1FFD
000079f9de5e201b  int3
000079f9de5e201c  nop [rax], eax
000079f9de5e2020  mov qword ptr [r15+0x100], 0x04
000079f9de5e202b  mov esi, 0x00
000079f9de5e2030  mov edx, 0x09
000079f9de5e2035  mov rdi, 0x7FFFE286D1E0
000079f9de5e203f  mov rax, 0x56D56FDEC970
000079f9de5e2049  call rax
000079f9de5e204b  cmp dword ptr [r15+0x318], 0x00
000079f9de5e2053  jnz 0x000079F9DE3FE110
000079f9de5e2059  jmp 0x000079F9DE3FE0A0
000079f9de5e205e  int3
000079f9de5e205f  int3
