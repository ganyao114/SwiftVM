00007d2ed8dce69b  nop [rax+rax*1], eax
00007d2ed8dce6a0  vmovaps xmm1, [0x00007D2ED89FE010]
00007d2ed8dce6a8  movq xmm1, xmm1
00007d2ed8dce6ac  movaps [r15+0x110], xmm1
00007d2ed8dce6b4  vmovaps xmm1, [0x00007D2ED89FE020]
00007d2ed8dce6bc  movq xmm1, xmm1
00007d2ed8dce6c0  movaps [r15+0x120], xmm1
00007d2ed8dce6c8  mov eax, 0x4204C0
00007d2ed8dce6cd  mov r14, [r13+rax*1]
00007d2ed8dce6d2  movq xmm1, r14
00007d2ed8dce6d7  movaps [r15+0x130], xmm1
00007d2ed8dce6df  vmovaps xmm1, [0x00007D2ED89FE030]
00007d2ed8dce6e7  vpbroadcastq xmm1, xmm1
00007d2ed8dce6ec  movaps [r15+0x140], xmm1
00007d2ed8dce6f4  mov qword ptr [r15+0x40], 0x02
00007d2ed8dce6fc  vmovaps xmm15, [0x00007D2ED89FE040]
00007d2ed8dce704  movq xmm15, xmm15
00007d2ed8dce709  movaps [r15+0x150], xmm15
00007d2ed8dce711  mov qword ptr [r15+0x58], 0x420000
00007d2ed8dce719  vmovaps xmm15, [0x00007D2ED89FE050]
00007d2ed8dce721  vpbroadcastq xmm15, xmm15
00007d2ed8dce726  movaps [r15+0x160], xmm15
00007d2ed8dce72e  mov rax, [r15+0x40]
00007d2ed8dce732  vmovq xmm14, rax
00007d2ed8dce737  vpbroadcastq xmm14, xmm14
00007d2ed8dce73c  movaps [r15+0x170], xmm14
00007d2ed8dce744  mov eax, 0x4204D0
00007d2ed8dce749  movups xmm13, [r13+rax*1]
00007d2ed8dce74f  mov qword ptr [r15+0x40], 0x430518
00007d2ed8dce757  mov qword ptr [r15+0x50], 0x430720
00007d2ed8dce75f  vpmovqd xmm12, xmm13
00007d2ed8dce765  pxor xmm11, xmm11
00007d2ed8dce76a  punpcklqdq xmm12, xmm11
00007d2ed8dce76f  movaps [r15+0x210], xmm12
00007d2ed8dce777  movq xmm12, qword ptr [r15+0x120]
00007d2ed8dce780  movq xmm11, qword ptr [r15+0x130]
00007d2ed8dce789  psubd xmm12, xmm11
00007d2ed8dce78e  movq xmm12, xmm12
00007d2ed8dce793  paddq xmm13, xmm14
00007d2ed8dce798  movaps [r15+0x180], xmm13
00007d2ed8dce7a0  movq xmm14, qword ptr [r15+0x150]
00007d2ed8dce7a9  paddd xmm11, xmm14
00007d2ed8dce7ae  movq xmm11, xmm11
00007d2ed8dce7b3  movq xmm11, xmm11
00007d2ed8dce7b8  movaps [r15+0x130], xmm11
00007d2ed8dce7c0  pmovzxdq xmm12, xmm12
00007d2ed8dce7c6  psllq xmm12, 0x00
00007d2ed8dce7cc  movq xmm14, qword ptr [r15+0x210]
00007d2ed8dce7d5  movq xmm13, qword ptr [r15+0x110]
00007d2ed8dce7de  paddd xmm14, xmm13
00007d2ed8dce7e3  movq xmm14, xmm14
00007d2ed8dce7e8  vcvtuqq2pd xmm12, xmm12
00007d2ed8dce7ee  pmovzxdq xmm14, xmm14
00007d2ed8dce7f4  psllq xmm14, 0x00
00007d2ed8dce7fa  vcvtuqq2pd xmm14, xmm14
00007d2ed8dce800  movaps xmm13, xmm12
00007d2ed8dce804  mulpd xmm13, xmm1
00007d2ed8dce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007d2ed8dce80f  ptest xmm11, xmm11
00007d2ed8dce815  jnz 0x00007D2ED8DCE8FF
00007d2ed8dce81b  movaps [r15+0x220], xmm13
00007d2ed8dce823  mov eax, 0x430720
00007d2ed8dce828  movups [r13+rax*1], xmm13
00007d2ed8dce82e  movaps xmm1, xmm14
00007d2ed8dce832  mulpd xmm1, xmm15
00007d2ed8dce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007d2ed8dce83c  ptest xmm13, xmm13
00007d2ed8dce842  jnz 0x00007D2ED8DCEA4C
00007d2ed8dce848  movaps [r15+0x210], xmm1
00007d2ed8dce850  mov eax, 0x430518
00007d2ed8dce855  movups [r13+rax*1], xmm1
00007d2ed8dce85b  mov qword ptr [r15+0x48], 0x10
00007d2ed8dce863  xor eax, eax
00007d2ed8dce865  mov r14d, 0x10
00007d2ed8dce86b  mov r12d, 0x200
00007d2ed8dce871  cmp r14, r12
00007d2ed8dce874  cmc
00007d2ed8dce875  lahf
00007d2ed8dce876  seto al
00007d2ed8dce879  mov [r15+0x108], eax
00007d2ed8dce880  mov eax, [r15+0x108]
00007d2ed8dce887  sahf
00007d2ed8dce888  jnz 0x00007D2ED8DCE8BA
00007d2ed8dce88a  cmp dword ptr [r15+0x318], 0x00
00007d2ed8dce892  jz 0x00007D2ED8DCEFF0
00007d2ed8dce898  nop [rax+rax*1], ax
00007d2ed8dce8a1  nop [rax+rax*1], eax
00007d2ed8dce8a9  mov eax, 0x4101EC
00007d2ed8dce8ae  mov [r15+0x100], rax
00007d2ed8dce8b5  jmp 0x00007D2ED8BFE110
00007d2ed8dce8ba  cmp dword ptr [r15+0x318], 0x00
00007d2ed8dce8c2  jz 0x00007D2ED8DCEBA0
00007d2ed8dce8c8  nop [rax+rax*1], ax
00007d2ed8dce8d1  nop [rax+rax*1], eax
00007d2ed8dce8d9  mov eax, 0x4101AC
00007d2ed8dce8de  mov [r15+0x100], rax
00007d2ed8dce8e5  jmp 0x00007D2ED8BFE110
00007d2ed8dce8ea  int3
00007d2ed8dce8eb  call 0x00007D2ED8C0DC20
00007d2ed8dce8f0  jmp 0x00007D2ED8DCE6D2
00007d2ed8dce8f5  call 0x00007D2ED8C0C260
00007d2ed8dce8fa  jmp 0x00007D2ED8DCE74F
00007d2ed8dce8ff  sub rsp, 0x08
00007d2ed8dce903  push rax
00007d2ed8dce904  push rcx
00007d2ed8dce905  push rdx
00007d2ed8dce906  push rdi
00007d2ed8dce907  push rsi
00007d2ed8dce908  push r8
00007d2ed8dce90a  push r9
00007d2ed8dce90c  push r10
00007d2ed8dce90e  push r11
00007d2ed8dce910  sub rsp, 0xF0
00007d2ed8dce917  vmovaps [rsp], xmm0
00007d2ed8dce91c  vmovaps [rsp+0x10], xmm1
00007d2ed8dce922  vmovaps [rsp+0x20], xmm2
00007d2ed8dce928  vmovaps [rsp+0x30], xmm3
00007d2ed8dce92e  vmovaps [rsp+0x40], xmm4
00007d2ed8dce934  vmovaps [rsp+0x50], xmm5
00007d2ed8dce93a  vmovaps [rsp+0x60], xmm6
00007d2ed8dce940  vmovaps [rsp+0x70], xmm7
00007d2ed8dce946  vmovaps [rsp+0x80], xmm8
00007d2ed8dce94f  vmovaps [rsp+0x90], xmm9
00007d2ed8dce958  vmovaps [rsp+0xA0], xmm10
00007d2ed8dce961  vmovaps [rsp+0xB0], xmm11
00007d2ed8dce96a  vmovaps [rsp+0xC0], xmm12
00007d2ed8dce973  vmovaps [rsp+0xD0], xmm14
00007d2ed8dce97c  vmovaps [rsp+0xE0], xmm15
00007d2ed8dce985  sub rsp, 0x30
00007d2ed8dce989  movaps [rsp], xmm13
00007d2ed8dce98e  movaps [rsp+0x10], xmm12
00007d2ed8dce994  movaps [rsp+0x20], xmm1
00007d2ed8dce999  lea rdi, [rsp]
00007d2ed8dce99d  mov esi, 0x00
00007d2ed8dce9a2  mov rax, 0x648718324530
00007d2ed8dce9ac  call rax
00007d2ed8dce9ae  movaps xmm13, [rsp]
00007d2ed8dce9b3  add rsp, 0x30
00007d2ed8dce9b7  vmovaps xmm0, [rsp]
00007d2ed8dce9bc  vmovaps xmm1, [rsp+0x10]
00007d2ed8dce9c2  vmovaps xmm2, [rsp+0x20]
00007d2ed8dce9c8  vmovaps xmm3, [rsp+0x30]
00007d2ed8dce9ce  vmovaps xmm4, [rsp+0x40]
00007d2ed8dce9d4  vmovaps xmm5, [rsp+0x50]
00007d2ed8dce9da  vmovaps xmm6, [rsp+0x60]
00007d2ed8dce9e0  vmovaps xmm7, [rsp+0x70]
00007d2ed8dce9e6  vmovaps xmm8, [rsp+0x80]
00007d2ed8dce9ef  vmovaps xmm9, [rsp+0x90]
00007d2ed8dce9f8  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dcea01  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dcea0a  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dcea13  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dcea1c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dcea25  add rsp, 0xF0
00007d2ed8dcea2c  pop r11
00007d2ed8dcea2e  pop r10
00007d2ed8dcea30  pop r9
00007d2ed8dcea32  pop r8
00007d2ed8dcea34  pop rsi
00007d2ed8dcea35  pop rdi
00007d2ed8dcea36  pop rdx
00007d2ed8dcea37  pop rcx
00007d2ed8dcea38  pop rax
00007d2ed8dcea39  add rsp, 0x08
00007d2ed8dcea3d  jmp 0x00007D2ED8DCE81B
00007d2ed8dcea42  call 0x00007D2ED8C0C380
00007d2ed8dcea47  jmp 0x00007D2ED8DCE82E
00007d2ed8dcea4c  sub rsp, 0x08
00007d2ed8dcea50  push rax
00007d2ed8dcea51  push rcx
00007d2ed8dcea52  push rdx
00007d2ed8dcea53  push rdi
00007d2ed8dcea54  push rsi
00007d2ed8dcea55  push r8
00007d2ed8dcea57  push r9
00007d2ed8dcea59  push r10
00007d2ed8dcea5b  push r11
00007d2ed8dcea5d  sub rsp, 0xF0
00007d2ed8dcea64  vmovaps [rsp], xmm0
00007d2ed8dcea69  vmovaps [rsp+0x10], xmm2
00007d2ed8dcea6f  vmovaps [rsp+0x20], xmm3
00007d2ed8dcea75  vmovaps [rsp+0x30], xmm4
00007d2ed8dcea7b  vmovaps [rsp+0x40], xmm5
00007d2ed8dcea81  vmovaps [rsp+0x50], xmm6
00007d2ed8dcea87  vmovaps [rsp+0x60], xmm7
00007d2ed8dcea8d  vmovaps [rsp+0x70], xmm8
00007d2ed8dcea93  vmovaps [rsp+0x80], xmm9
00007d2ed8dcea9c  vmovaps [rsp+0x90], xmm10
00007d2ed8dceaa5  vmovaps [rsp+0xA0], xmm11
00007d2ed8dceaae  vmovaps [rsp+0xB0], xmm12
00007d2ed8dceab7  vmovaps [rsp+0xC0], xmm13
00007d2ed8dceac0  vmovaps [rsp+0xD0], xmm14
00007d2ed8dceac9  vmovaps [rsp+0xE0], xmm15
00007d2ed8dcead2  sub rsp, 0x30
00007d2ed8dcead6  movaps [rsp], xmm1
00007d2ed8dceada  movaps [rsp+0x10], xmm14
00007d2ed8dceae0  movaps [rsp+0x20], xmm15
00007d2ed8dceae6  lea rdi, [rsp]
00007d2ed8dceaea  mov esi, 0x00
00007d2ed8dceaef  mov rax, 0x648718324530
00007d2ed8dceaf9  call rax
00007d2ed8dceafb  movaps xmm1, [rsp]
00007d2ed8dceaff  add rsp, 0x30
00007d2ed8dceb03  vmovaps xmm0, [rsp]
00007d2ed8dceb08  vmovaps xmm2, [rsp+0x10]
00007d2ed8dceb0e  vmovaps xmm3, [rsp+0x20]
00007d2ed8dceb14  vmovaps xmm4, [rsp+0x30]
00007d2ed8dceb1a  vmovaps xmm5, [rsp+0x40]
00007d2ed8dceb20  vmovaps xmm6, [rsp+0x50]
00007d2ed8dceb26  vmovaps xmm7, [rsp+0x60]
00007d2ed8dceb2c  vmovaps xmm8, [rsp+0x70]
00007d2ed8dceb32  vmovaps xmm9, [rsp+0x80]
00007d2ed8dceb3b  vmovaps xmm10, [rsp+0x90]
00007d2ed8dceb44  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dceb4d  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dceb56  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dceb5f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dceb68  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dceb71  add rsp, 0xF0
00007d2ed8dceb78  pop r11
00007d2ed8dceb7a  pop r10
00007d2ed8dceb7c  pop r9
00007d2ed8dceb7e  pop r8
00007d2ed8dceb80  pop rsi
00007d2ed8dceb81  pop rdi
00007d2ed8dceb82  pop rdx
00007d2ed8dceb83  pop rcx
00007d2ed8dceb84  pop rax
00007d2ed8dceb85  add rsp, 0x08
00007d2ed8dceb89  jmp 0x00007D2ED8DCE848
00007d2ed8dceb8e  call 0x00007D2ED8BFF540
00007d2ed8dceb93  jmp 0x00007D2ED8DCE85B
00007d2ed8dceb98  int3
00007d2ed8dceb99  nop [rax], eax
00007d2ed8dceba0  movaps xmm1, [r15+0x180]
00007d2ed8dceba8  vpmovqd xmm15, xmm1
00007d2ed8dcebae  pxor xmm14, xmm14
00007d2ed8dcebb3  punpcklqdq xmm15, xmm14
00007d2ed8dcebb8  movaps [r15+0x210], xmm15
00007d2ed8dcebc0  movq xmm15, qword ptr [r15+0x120]
00007d2ed8dcebc9  movq xmm14, qword ptr [r15+0x130]
00007d2ed8dcebd2  psubd xmm15, xmm14
00007d2ed8dcebd7  movq xmm15, xmm15
00007d2ed8dcebdc  movaps xmm13, [r15+0x170]
00007d2ed8dcebe4  paddq xmm1, xmm13
00007d2ed8dcebe9  movaps [r15+0x180], xmm1
00007d2ed8dcebf1  movq xmm1, qword ptr [r15+0x150]
00007d2ed8dcebfa  paddd xmm14, xmm1
00007d2ed8dcebff  movq xmm14, xmm14
00007d2ed8dcec04  movq xmm14, xmm14
00007d2ed8dcec09  movaps [r15+0x130], xmm14
00007d2ed8dcec11  pmovzxdq xmm15, xmm15
00007d2ed8dcec17  psllq xmm15, 0x00
00007d2ed8dcec1d  movq xmm1, qword ptr [r15+0x210]
00007d2ed8dcec26  movq xmm14, qword ptr [r15+0x110]
00007d2ed8dcec2f  paddd xmm1, xmm14
00007d2ed8dcec34  movq xmm1, xmm1
00007d2ed8dcec38  vcvtuqq2pd xmm15, xmm15
00007d2ed8dcec3e  pmovzxdq xmm1, xmm1
00007d2ed8dcec43  psllq xmm1, 0x00
00007d2ed8dcec48  vcvtuqq2pd xmm1, xmm1
00007d2ed8dcec4e  movaps xmm14, [r15+0x140]
00007d2ed8dcec56  movaps xmm13, xmm15
00007d2ed8dcec5a  mulpd xmm13, xmm14
00007d2ed8dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d2ed8dcec65  ptest xmm12, xmm12
00007d2ed8dcec6b  jnz 0x00007D2ED8DCED4E
00007d2ed8dcec71  movaps [r15+0x220], xmm13
00007d2ed8dcec79  mov rax, [r15+0x48]
00007d2ed8dcec7d  mov r14, [r15+0x50]
00007d2ed8dcec81  lea r12, [r14+rax*1]
00007d2ed8dcec85  movups [r13+r12*1], xmm13
00007d2ed8dcec8b  movaps xmm15, [r15+0x160]
00007d2ed8dcec93  movaps xmm14, xmm1
00007d2ed8dcec97  mulpd xmm14, xmm15
00007d2ed8dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007d2ed8dceca2  ptest xmm13, xmm13
00007d2ed8dceca8  jnz 0x00007D2ED8DCEE9C
00007d2ed8dcecae  movaps [r15+0x210], xmm14
00007d2ed8dcecb6  mov r14, [r15+0x40]
00007d2ed8dcecba  lea r12, [r14+rax*1]
00007d2ed8dcecbe  movups [r13+r12*1], xmm14
00007d2ed8dcecc4  lea r14, [rax+0x10]
00007d2ed8dcecc8  mov [r15+0x48], r14
00007d2ed8dceccc  xor eax, eax
00007d2ed8dcecce  mov r12d, 0x200
00007d2ed8dcecd4  cmp r14, r12
00007d2ed8dcecd7  cmc
00007d2ed8dcecd8  lahf
00007d2ed8dcecd9  seto al
00007d2ed8dcecdc  mov [r15+0x108], eax
00007d2ed8dcece3  mov eax, [r15+0x108]
00007d2ed8dcecea  sahf
00007d2ed8dceceb  jnz 0x00007D2ED8DCED1D
00007d2ed8dceced  cmp dword ptr [r15+0x318], 0x00
00007d2ed8dcecf5  jz 0x00007D2ED8DCEFF0
00007d2ed8dcecfb  nop [rax+rax*1], ax
00007d2ed8dced04  nop [rax+rax*1], eax
00007d2ed8dced0c  mov eax, 0x4101EC
00007d2ed8dced11  mov [r15+0x100], rax
00007d2ed8dced18  jmp 0x00007D2ED8BFE110
00007d2ed8dced1d  cmp dword ptr [r15+0x318], 0x00
00007d2ed8dced25  jz 0x00007D2ED8DCEBA0
00007d2ed8dced2b  nop [rax+rax*1], ax
00007d2ed8dced34  nop [rax+rax*1], eax
00007d2ed8dced3c  mov eax, 0x4101AC
00007d2ed8dced41  mov [r15+0x100], rax
00007d2ed8dced48  jmp 0x00007D2ED8BFE110
00007d2ed8dced4d  int3
00007d2ed8dced4e  sub rsp, 0x08
00007d2ed8dced52  push rax
00007d2ed8dced53  push rcx
00007d2ed8dced54  push rdx
00007d2ed8dced55  push rdi
00007d2ed8dced56  push rsi
00007d2ed8dced57  push r8
00007d2ed8dced59  push r9
00007d2ed8dced5b  push r10
00007d2ed8dced5d  push r11
00007d2ed8dced5f  sub rsp, 0xF0
00007d2ed8dced66  vmovaps [rsp], xmm0
00007d2ed8dced6b  vmovaps [rsp+0x10], xmm1
00007d2ed8dced71  vmovaps [rsp+0x20], xmm2
00007d2ed8dced77  vmovaps [rsp+0x30], xmm3
00007d2ed8dced7d  vmovaps [rsp+0x40], xmm4
00007d2ed8dced83  vmovaps [rsp+0x50], xmm5
00007d2ed8dced89  vmovaps [rsp+0x60], xmm6
00007d2ed8dced8f  vmovaps [rsp+0x70], xmm7
00007d2ed8dced95  vmovaps [rsp+0x80], xmm8
00007d2ed8dced9e  vmovaps [rsp+0x90], xmm9
00007d2ed8dceda7  vmovaps [rsp+0xA0], xmm10
00007d2ed8dcedb0  vmovaps [rsp+0xB0], xmm11
00007d2ed8dcedb9  vmovaps [rsp+0xC0], xmm12
00007d2ed8dcedc2  vmovaps [rsp+0xD0], xmm14
00007d2ed8dcedcb  vmovaps [rsp+0xE0], xmm15
00007d2ed8dcedd4  sub rsp, 0x30
00007d2ed8dcedd8  movaps [rsp], xmm13
00007d2ed8dceddd  movaps [rsp+0x10], xmm15
00007d2ed8dcede3  movaps [rsp+0x20], xmm14
00007d2ed8dcede9  lea rdi, [rsp]
00007d2ed8dceded  mov esi, 0x00
00007d2ed8dcedf2  mov rax, 0x648718324530
00007d2ed8dcedfc  call rax
00007d2ed8dcedfe  movaps xmm13, [rsp]
00007d2ed8dcee03  add rsp, 0x30
00007d2ed8dcee07  vmovaps xmm0, [rsp]
00007d2ed8dcee0c  vmovaps xmm1, [rsp+0x10]
00007d2ed8dcee12  vmovaps xmm2, [rsp+0x20]
00007d2ed8dcee18  vmovaps xmm3, [rsp+0x30]
00007d2ed8dcee1e  vmovaps xmm4, [rsp+0x40]
00007d2ed8dcee24  vmovaps xmm5, [rsp+0x50]
00007d2ed8dcee2a  vmovaps xmm6, [rsp+0x60]
00007d2ed8dcee30  vmovaps xmm7, [rsp+0x70]
00007d2ed8dcee36  vmovaps xmm8, [rsp+0x80]
00007d2ed8dcee3f  vmovaps xmm9, [rsp+0x90]
00007d2ed8dcee48  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dcee51  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dcee5a  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dcee63  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dcee6c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dcee75  add rsp, 0xF0
00007d2ed8dcee7c  pop r11
00007d2ed8dcee7e  pop r10
00007d2ed8dcee80  pop r9
00007d2ed8dcee82  pop r8
00007d2ed8dcee84  pop rsi
00007d2ed8dcee85  pop rdi
00007d2ed8dcee86  pop rdx
00007d2ed8dcee87  pop rcx
00007d2ed8dcee88  pop rax
00007d2ed8dcee89  add rsp, 0x08
00007d2ed8dcee8d  jmp 0x00007D2ED8DCEC71
00007d2ed8dcee92  call 0x00007D2ED8CC2240
00007d2ed8dcee97  jmp 0x00007D2ED8DCEC8B
00007d2ed8dcee9c  sub rsp, 0x08
00007d2ed8dceea0  push rax
00007d2ed8dceea1  push rcx
00007d2ed8dceea2  push rdx
00007d2ed8dceea3  push rdi
00007d2ed8dceea4  push rsi
00007d2ed8dceea5  push r8
00007d2ed8dceea7  push r9
00007d2ed8dceea9  push r10
00007d2ed8dceeab  push r11
00007d2ed8dceead  sub rsp, 0xF0
00007d2ed8dceeb4  vmovaps [rsp], xmm0
00007d2ed8dceeb9  vmovaps [rsp+0x10], xmm1
00007d2ed8dceebf  vmovaps [rsp+0x20], xmm2
00007d2ed8dceec5  vmovaps [rsp+0x30], xmm3
00007d2ed8dceecb  vmovaps [rsp+0x40], xmm4
00007d2ed8dceed1  vmovaps [rsp+0x50], xmm5
00007d2ed8dceed7  vmovaps [rsp+0x60], xmm6
00007d2ed8dceedd  vmovaps [rsp+0x70], xmm7
00007d2ed8dceee3  vmovaps [rsp+0x80], xmm8
00007d2ed8dceeec  vmovaps [rsp+0x90], xmm9
00007d2ed8dceef5  vmovaps [rsp+0xA0], xmm10
00007d2ed8dceefe  vmovaps [rsp+0xB0], xmm11
00007d2ed8dcef07  vmovaps [rsp+0xC0], xmm12
00007d2ed8dcef10  vmovaps [rsp+0xD0], xmm13
00007d2ed8dcef19  vmovaps [rsp+0xE0], xmm15
00007d2ed8dcef22  sub rsp, 0x30
00007d2ed8dcef26  movaps [rsp], xmm14
00007d2ed8dcef2b  movaps [rsp+0x10], xmm1
00007d2ed8dcef30  movaps [rsp+0x20], xmm15
00007d2ed8dcef36  lea rdi, [rsp]
00007d2ed8dcef3a  mov esi, 0x00
00007d2ed8dcef3f  mov rax, 0x648718324530
00007d2ed8dcef49  call rax
00007d2ed8dcef4b  movaps xmm14, [rsp]
00007d2ed8dcef50  add rsp, 0x30
00007d2ed8dcef54  vmovaps xmm0, [rsp]
00007d2ed8dcef59  vmovaps xmm1, [rsp+0x10]
00007d2ed8dcef5f  vmovaps xmm2, [rsp+0x20]
00007d2ed8dcef65  vmovaps xmm3, [rsp+0x30]
00007d2ed8dcef6b  vmovaps xmm4, [rsp+0x40]
00007d2ed8dcef71  vmovaps xmm5, [rsp+0x50]
00007d2ed8dcef77  vmovaps xmm6, [rsp+0x60]
00007d2ed8dcef7d  vmovaps xmm7, [rsp+0x70]
00007d2ed8dcef83  vmovaps xmm8, [rsp+0x80]
00007d2ed8dcef8c  vmovaps xmm9, [rsp+0x90]
00007d2ed8dcef95  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dcef9e  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dcefa7  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dcefb0  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dcefb9  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dcefc2  add rsp, 0xF0
00007d2ed8dcefc9  pop r11
00007d2ed8dcefcb  pop r10
00007d2ed8dcefcd  pop r9
00007d2ed8dcefcf  pop r8
00007d2ed8dcefd1  pop rsi
00007d2ed8dcefd2  pop rdi
00007d2ed8dcefd3  pop rdx
00007d2ed8dcefd4  pop rcx
00007d2ed8dcefd5  pop rax
00007d2ed8dcefd6  add rsp, 0x08
00007d2ed8dcefda  jmp 0x00007D2ED8DCECAE
00007d2ed8dcefdf  call 0x00007D2ED8CC34C0
00007d2ed8dcefe4  jmp 0x00007D2ED8DCECC4
00007d2ed8dcefe9  int3
00007d2ed8dcefea  nop [rax+rax*1], ax
00007d2ed8dceff0  mov rax, [r15+0xF8]
00007d2ed8dceff7  lea r14, [rax-0x150]
00007d2ed8dceffe  mov [r15+0xF8], r14
00007d2ed8dcf005  mov rax, [r15+0x50]
00007d2ed8dcf009  lea r12, [rax+0x80]
00007d2ed8dcf010  movups xmm1, [r13+r12*1]
00007d2ed8dcf016  lea r12, [rax+0x90]
00007d2ed8dcf01d  movups xmm15, [r13+r12*1]
00007d2ed8dcf023  mov qword ptr [r15+0x48], 0x00
00007d2ed8dcf02b  lea r12, [rax+0x40]
00007d2ed8dcf02f  movups xmm14, [r13+r12*1]
00007d2ed8dcf035  lea r12, [rax+0x50]
00007d2ed8dcf039  movups xmm13, [r13+r12*1]
00007d2ed8dcf03f  lea r12, [r14+0x120]
00007d2ed8dcf046  movq xmm12, qword ptr [r15+0x1C0]
00007d2ed8dcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007d2ed8dcf058  movq r11, xmm12
00007d2ed8dcf05d  movq r10, xmm11
00007d2ed8dcf062  mov [r13+r12*1], r11
00007d2ed8dcf067  lea r12, [r14+0x128]
00007d2ed8dcf06e  mov [r13+r12*1], r10
00007d2ed8dcf073  vxorps xmm12, xmm12, xmm12
00007d2ed8dcf078  vpbroadcastq xmm12, xmm12
00007d2ed8dcf07d  lea r12, [r14+0x100]
00007d2ed8dcf084  movq xmm11, qword ptr [r15+0x200]
00007d2ed8dcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007d2ed8dcf096  movq r11, xmm11
00007d2ed8dcf09b  movq r10, xmm10
00007d2ed8dcf0a0  mov [r13+r12*1], r11
00007d2ed8dcf0a5  lea r12, [r14+0x108]
00007d2ed8dcf0ac  mov [r13+r12*1], r10
00007d2ed8dcf0b1  lea r12, [r14+0xE0]
00007d2ed8dcf0b8  movups [r13+r12*1], xmm15
00007d2ed8dcf0be  lea r12, [r14+0xF0]
00007d2ed8dcf0c5  movups [r13+r12*1], xmm1
00007d2ed8dcf0cb  lea r12, [rax+0xC0]
00007d2ed8dcf0d2  movups xmm1, [r13+r12*1]
00007d2ed8dcf0d8  lea r12, [rax+0xD0]
00007d2ed8dcf0df  movups xmm15, [r13+r12*1]
00007d2ed8dcf0e5  lea r12, [r14+0x110]
00007d2ed8dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007d2ed8dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007d2ed8dcf0fe  movq r11, xmm11
00007d2ed8dcf103  movq r10, xmm10
00007d2ed8dcf108  mov [r13+r12*1], r11
00007d2ed8dcf10d  lea r12, [r14+0x118]
00007d2ed8dcf114  mov [r13+r12*1], r10
00007d2ed8dcf119  movups xmm11, [r13+rax*1]
00007d2ed8dcf11f  lea r12, [rax+0x10]
00007d2ed8dcf123  movups xmm10, [r13+r12*1]
00007d2ed8dcf129  lea r12, [r14+0x130]
00007d2ed8dcf130  movq xmm9, qword ptr [r15+0x1A0]
00007d2ed8dcf139  movq xmm8, qword ptr [r15+0x190]
00007d2ed8dcf142  movq r11, xmm9
00007d2ed8dcf147  movq r10, xmm8
00007d2ed8dcf14c  mov [r13+r12*1], r11
00007d2ed8dcf151  lea r12, [r14+0x138]
00007d2ed8dcf158  mov [r13+r12*1], r10
00007d2ed8dcf15d  lea r12, [rax+0x140]
00007d2ed8dcf164  movups xmm9, [r13+r12*1]
00007d2ed8dcf16a  lea r12, [rax+0x150]
00007d2ed8dcf171  movups xmm8, [r13+r12*1]
00007d2ed8dcf177  lea r12, [r14+0xC0]
00007d2ed8dcf17e  movups [r13+r12*1], xmm15
00007d2ed8dcf184  lea r12, [r14+0xD0]
00007d2ed8dcf18b  movups [r13+r12*1], xmm1
00007d2ed8dcf191  lea r12, [rax+0x100]
00007d2ed8dcf198  movups xmm1, [r13+r12*1]
00007d2ed8dcf19e  lea r12, [rax+0x110]
00007d2ed8dcf1a5  movups xmm15, [r13+r12*1]
00007d2ed8dcf1ab  lea r12, [r14+0x140]
00007d2ed8dcf1b2  mov r11, [r15+0xE8]
00007d2ed8dcf1b9  mov [r13+r12*1], r11
00007d2ed8dcf1be  lea r12, [rax+0x180]
00007d2ed8dcf1c5  movups xmm7, [r13+r12*1]
00007d2ed8dcf1cb  lea r12, [rax+0x190]
00007d2ed8dcf1d2  movups xmm6, [r13+r12*1]
00007d2ed8dcf1d8  lea r12, [rax+0x1C0]
00007d2ed8dcf1df  movups xmm5, [r13+r12*1]
00007d2ed8dcf1e5  lea r12, [rax+0x1D0]
00007d2ed8dcf1ec  movups xmm4, [r13+r12*1]
00007d2ed8dcf1f2  lea r12, [r14+0x20]
00007d2ed8dcf1f6  movups [r13+r12*1], xmm1
00007d2ed8dcf1fc  lea r12, [r14+0x30]
00007d2ed8dcf200  movups [r13+r12*1], xmm13
00007d2ed8dcf206  lea r12, [rax+0x60]
00007d2ed8dcf20a  movups xmm1, [r13+r12*1]
00007d2ed8dcf210  lea r12, [rax+0x70]
00007d2ed8dcf214  movups xmm13, [r13+r12*1]
00007d2ed8dcf21a  lea r12, [rax+0x20]
00007d2ed8dcf21e  movups xmm3, [r13+r12*1]
00007d2ed8dcf224  lea r12, [rax+0x30]
00007d2ed8dcf228  movups xmm2, [r13+r12*1]
00007d2ed8dcf22e  movaps [r15+0x1F0], xmm2
00007d2ed8dcf236  lea r12, [r14+0x60]
00007d2ed8dcf23a  movups [r13+r12*1], xmm11
00007d2ed8dcf240  lea r12, [r14+0x70]
00007d2ed8dcf244  movups [r13+r12*1], xmm5
00007d2ed8dcf24a  lea r12, [rax+0xE0]
00007d2ed8dcf251  movups xmm11, [r13+r12*1]
00007d2ed8dcf257  lea r12, [rax+0xF0]
00007d2ed8dcf25e  movups xmm5, [r13+r12*1]
00007d2ed8dcf264  lea r12, [r14+0xA0]
00007d2ed8dcf26b  movups [r13+r12*1], xmm13
00007d2ed8dcf271  lea r12, [r14+0xB0]
00007d2ed8dcf278  movups [r13+r12*1], xmm1
00007d2ed8dcf27e  lea r12, [rax+0xA0]
00007d2ed8dcf285  movups xmm1, [r13+r12*1]
00007d2ed8dcf28b  lea r12, [rax+0xB0]
00007d2ed8dcf292  movups xmm13, [r13+r12*1]
00007d2ed8dcf298  lea r12, [rax+0x120]
00007d2ed8dcf29f  vmovaps [rsp+0x10], xmm1
00007d2ed8dcf2a5  movups xmm1, [r13+r12*1]
00007d2ed8dcf2ab  lea r12, [rax+0x130]
00007d2ed8dcf2b2  vmovaps [rsp+0x20], xmm1
00007d2ed8dcf2b8  movups xmm1, [r13+r12*1]
00007d2ed8dcf2be  lea r12, [rax+0x160]
00007d2ed8dcf2c5  vmovaps [rsp+0x30], xmm1
00007d2ed8dcf2cb  movups xmm1, [r13+r12*1]
00007d2ed8dcf2d1  lea r12, [rax+0x170]
00007d2ed8dcf2d8  vmovaps [rsp+0x40], xmm1
00007d2ed8dcf2de  movups xmm1, [r13+r12*1]
00007d2ed8dcf2e4  movaps [r15+0x2B0], xmm1
00007d2ed8dcf2ec  lea r12, [r14+0x80]
00007d2ed8dcf2f3  movups [r13+r12*1], xmm13
00007d2ed8dcf2f9  lea r12, [r14+0x90]
00007d2ed8dcf300  vmovaps xmm13, [rsp+0x10]
00007d2ed8dcf306  movups [r13+r12*1], xmm13
00007d2ed8dcf30c  lea r12, [rax+0x1A0]
00007d2ed8dcf313  movups xmm13, [r13+r12*1]
00007d2ed8dcf319  lea r12, [rax+0x1B0]
00007d2ed8dcf320  vmovaps [rsp+0x10], xmm1
00007d2ed8dcf326  movups xmm1, [r13+r12*1]
00007d2ed8dcf32c  movaps [r15+0x290], xmm13
00007d2ed8dcf334  movaps [r15+0x1E0], xmm1
00007d2ed8dcf33c  lea r12, [rax+0x1E0]
00007d2ed8dcf343  vmovaps [rsp+0x50], xmm1
00007d2ed8dcf349  movups xmm1, [r13+r12*1]
00007d2ed8dcf34f  lea r12, [rax+0x1F0]
00007d2ed8dcf356  vmovaps [rsp+0x60], xmm1
00007d2ed8dcf35c  movups xmm1, [r13+r12*1]
00007d2ed8dcf362  mov qword ptr [r15+0x50], 0x430920
00007d2ed8dcf36a  lea rax, [r14+0x40]
00007d2ed8dcf36e  vmovaps [rsp+0x70], xmm1
00007d2ed8dcf374  vmovaps xmm1, [rsp+0x40]
00007d2ed8dcf37a  movups [r13+rax*1], xmm1
00007d2ed8dcf380  lea rax, [r14+0x50]
00007d2ed8dcf384  movups [r13+rax*1], xmm10
00007d2ed8dcf38a  vmovaps xmm1, [rsp+0x70]
00007d2ed8dcf390  movups [r13+r14*1], xmm1
00007d2ed8dcf396  lea rax, [r14+0x10]
00007d2ed8dcf39a  vmovaps xmm1, [rsp+0x60]
00007d2ed8dcf3a0  movups [r13+rax*1], xmm1
00007d2ed8dcf3a6  mov rax, [r15+0x40]
00007d2ed8dcf3aa  vmovaps [rsp+0x40], xmm3
00007d2ed8dcf3b0  vmovaps xmm1, [rsp+0x40]
00007d2ed8dcf3b6  por xmm3, xmm1
00007d2ed8dcf3ba  vmovaps [rsp+0x40], xmm6
00007d2ed8dcf3c0  vmovaps xmm10, [rsp+0x40]
00007d2ed8dcf3c6  por xmm6, xmm10
00007d2ed8dcf3cb  lea r12, [rax+0x30]
00007d2ed8dcf3cf  mov r11, [r13+r12*1]
00007d2ed8dcf3d4  lea r12, [rax+0x38]
00007d2ed8dcf3d8  mov r10, [r13+r12*1]
00007d2ed8dcf3dd  movq xmm10, r11
00007d2ed8dcf3e2  vmovaps [rsp+0x40], xmm1
00007d2ed8dcf3e8  movq xmm1, r10
00007d2ed8dcf3ed  movq xmm10, xmm10
00007d2ed8dcf3f2  vmovaps [rsp+0x60], xmm10
00007d2ed8dcf3f8  movq xmm10, xmm10
00007d2ed8dcf3fd  movaps [r15+0x130], xmm10
00007d2ed8dcf405  movq xmm1, xmm1
00007d2ed8dcf409  vmovaps [rsp+0x70], xmm1
00007d2ed8dcf40f  movq xmm1, xmm1
00007d2ed8dcf413  movaps [r15+0x280], xmm1
00007d2ed8dcf41b  vmovaps [rsp+0x80], xmm9
00007d2ed8dcf424  vmovaps xmm1, [rsp+0x80]
00007d2ed8dcf42d  por xmm9, xmm1
00007d2ed8dcf432  lea r12, [rax+0x20]
00007d2ed8dcf436  mov r11, [r13+r12*1]
00007d2ed8dcf43b  lea r12, [rax+0x28]
00007d2ed8dcf43f  mov r10, [r13+r12*1]
00007d2ed8dcf444  movq xmm1, r11
00007d2ed8dcf449  movq xmm10, r10
00007d2ed8dcf44e  movq xmm1, xmm1
00007d2ed8dcf452  vmovaps [rsp+0x80], xmm1
00007d2ed8dcf45b  movq xmm1, xmm1
00007d2ed8dcf45f  movaps [r15+0x150], xmm1
00007d2ed8dcf467  movq xmm10, xmm10
00007d2ed8dcf46c  vmovaps [rsp+0x90], xmm10
00007d2ed8dcf475  movq xmm10, xmm10
00007d2ed8dcf47a  movaps [r15+0x140], xmm10
00007d2ed8dcf482  lea r12, [rax+0x10]
00007d2ed8dcf486  mov r11, [r13+r12*1]
00007d2ed8dcf48b  lea r12, [rax+0x18]
00007d2ed8dcf48f  mov r10, [r13+r12*1]
00007d2ed8dcf494  movq xmm1, r11
00007d2ed8dcf499  movq xmm10, r10
00007d2ed8dcf49e  movq xmm1, xmm1
00007d2ed8dcf4a2  vmovaps [rsp+0xA0], xmm1
00007d2ed8dcf4ab  movq xmm1, xmm1
00007d2ed8dcf4af  movaps [r15+0x170], xmm1
00007d2ed8dcf4b7  movq xmm10, xmm10
00007d2ed8dcf4bc  vmovaps [rsp+0xB0], xmm10
00007d2ed8dcf4c5  movq xmm10, xmm10
00007d2ed8dcf4ca  movaps [r15+0x160], xmm10
00007d2ed8dcf4d2  mov r12, [r13+rax*1]
00007d2ed8dcf4d7  vmovq xmm1, r12
00007d2ed8dcf4dc  vpbroadcastq xmm1, xmm1
00007d2ed8dcf4e1  lea r12, [rax+0x08]
00007d2ed8dcf4e5  mov rax, [r13+r12*1]
00007d2ed8dcf4ea  movq xmm10, rax
00007d2ed8dcf4ef  movaps [r15+0x230], xmm10
00007d2ed8dcf4f7  lea rax, [r14+0x50]
00007d2ed8dcf4fb  movups xmm10, [r13+rax*1]
00007d2ed8dcf501  lea rax, [r14+0x60]
00007d2ed8dcf505  vmovaps [rsp+0xC0], xmm1
00007d2ed8dcf50e  movups xmm1, [r13+rax*1]
00007d2ed8dcf514  lea rax, [r14+0x30]
00007d2ed8dcf518  vmovaps [rsp+0xD0], xmm1
00007d2ed8dcf521  movups xmm1, [r13+rax*1]
00007d2ed8dcf527  mov qword ptr [r15+0x60], 0x430920
00007d2ed8dcf52f  mov qword ptr [r15+0x58], 0x40
00007d2ed8dcf537  vmovaps [rsp+0xE0], xmm1
00007d2ed8dcf540  vmovaps [rsp+0xF0], xmm15
00007d2ed8dcf549  vmovaps xmm15, [rsp+0xC0]
00007d2ed8dcf552  vmovaps [rsp+0xC0], xmm14
00007d2ed8dcf55b  vmovaps xmm14, [rsp+0x40]
00007d2ed8dcf561  vmovaps [rsp+0x40], xmm13
00007d2ed8dcf567  movaps xmm1, xmm15
00007d2ed8dcf56b  mulpd xmm1, xmm14
00007d2ed8dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007d2ed8dcf575  ptest xmm13, xmm13
00007d2ed8dcf57b  jnz 0x00007D2ED8DD0682
00007d2ed8dcf581  movq xmm14, qword ptr [r15+0x230]
00007d2ed8dcf58a  vmovaps [rsp+0x100], xmm14
00007d2ed8dcf593  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dcf599  vmovaps [rsp+0x110], xmm1
00007d2ed8dcf5a2  vmovaps xmm1, [rsp+0xE0]
00007d2ed8dcf5ab  vmovaps [rsp+0xE0], xmm15
00007d2ed8dcf5b4  movaps xmm13, xmm1
00007d2ed8dcf5b8  mulpd xmm13, xmm14
00007d2ed8dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007d2ed8dcf5c3  ptest xmm15, xmm15
00007d2ed8dcf5c9  jnz 0x00007D2ED8DD07C4
00007d2ed8dcf5cf  vxorps xmm1, xmm1, xmm1
00007d2ed8dcf5d3  vpbroadcastq xmm1, xmm1
00007d2ed8dcf5d8  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dcf5e1  vmovaps [rsp+0xE0], xmm1
00007d2ed8dcf5ea  vmovaps xmm1, [rsp+0xD0]
00007d2ed8dcf5f3  vmovaps [rsp+0xD0], xmm13
00007d2ed8dcf5fc  movaps xmm15, xmm14
00007d2ed8dcf600  mulpd xmm15, xmm1
00007d2ed8dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007d2ed8dcf60b  ptest xmm13, xmm13
00007d2ed8dcf611  jnz 0x00007D2ED8DD0907
00007d2ed8dcf617  movaps xmm1, xmm14
00007d2ed8dcf61b  mulpd xmm1, xmm10
00007d2ed8dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007d2ed8dcf625  ptest xmm13, xmm13
00007d2ed8dcf62b  jnz 0x00007D2ED8DD0A4A
00007d2ed8dcf631  movaps xmm13, xmm14
00007d2ed8dcf635  mulpd xmm13, xmm2
00007d2ed8dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007d2ed8dcf640  ptest xmm10, xmm10
00007d2ed8dcf646  jnz 0x00007D2ED8DD0B8C
00007d2ed8dcf64c  vmovaps [rsp+0x120], xmm7
00007d2ed8dcf655  vmovaps xmm14, [rsp+0x120]
00007d2ed8dcf65e  por xmm7, xmm14
00007d2ed8dcf663  vmovaps xmm14, [rsp+0xC0]
00007d2ed8dcf66c  vmovaps xmm10, [rsp+0xC0]
00007d2ed8dcf675  por xmm14, xmm10
00007d2ed8dcf67a  vmovaps xmm2, [rsp+0x100]
00007d2ed8dcf683  vpermilpd xmm2, xmm2, 0x00
00007d2ed8dcf689  vmovaps [rsp+0xC0], xmm1
00007d2ed8dcf692  vmovaps [rsp+0x120], xmm15
00007d2ed8dcf69b  movaps xmm1, xmm10
00007d2ed8dcf69f  mulpd xmm1, xmm2
00007d2ed8dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007d2ed8dcf6a8  ptest xmm15, xmm15
00007d2ed8dcf6ae  jnz 0x00007D2ED8DD0CCF
00007d2ed8dcf6b4  xor eax, eax
00007d2ed8dcf6b6  mov r12d, 0x40
00007d2ed8dcf6bc  mov r11d, 0x200
00007d2ed8dcf6c2  cmp r12, r11
00007d2ed8dcf6c5  cmc
00007d2ed8dcf6c6  lahf
00007d2ed8dcf6c7  seto al
00007d2ed8dcf6ca  mov [r15+0x108], eax
00007d2ed8dcf6d1  vmovaps xmm10, [rsp+0x110]
00007d2ed8dcf6da  vmovaps xmm2, [rsp+0xE0]
00007d2ed8dcf6e3  vmovaps [rsp+0xE0], xmm1
00007d2ed8dcf6ec  movaps xmm15, xmm10
00007d2ed8dcf6f0  addpd xmm15, xmm2
00007d2ed8dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d2ed8dcf6fb  ptest xmm1, xmm1
00007d2ed8dcf700  jnz 0x00007D2ED8DD0E10
00007d2ed8dcf706  vmovaps xmm10, [rsp+0x120]
00007d2ed8dcf70f  vmovaps [rsp+0x110], xmm15
00007d2ed8dcf718  movaps xmm1, xmm10
00007d2ed8dcf71c  addpd xmm1, xmm12
00007d2ed8dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007d2ed8dcf726  ptest xmm15, xmm15
00007d2ed8dcf72c  jnz 0x00007D2ED8DD0F53
00007d2ed8dcf732  vmovaps xmm10, [rsp+0xC0]
00007d2ed8dcf73b  vmovaps [rsp+0xC0], xmm1
00007d2ed8dcf744  movaps xmm15, xmm10
00007d2ed8dcf748  addpd xmm15, xmm12
00007d2ed8dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007d2ed8dcf753  ptest xmm1, xmm1
00007d2ed8dcf758  jnz 0x00007D2ED8DD1095
00007d2ed8dcf75e  vmovaps xmm1, [rsp+0x30]
00007d2ed8dcf764  vmovaps xmm12, [rsp+0x30]
00007d2ed8dcf76a  por xmm1, xmm12
00007d2ed8dcf76f  vmovaps xmm12, [rsp+0x20]
00007d2ed8dcf775  vmovaps xmm10, [rsp+0x20]
00007d2ed8dcf77b  por xmm12, xmm10
00007d2ed8dcf780  vmovaps [rsp+0x20], xmm5
00007d2ed8dcf786  vmovaps xmm10, [rsp+0x20]
00007d2ed8dcf78c  por xmm5, xmm10
00007d2ed8dcf791  vmovaps [rsp+0x20], xmm11
00007d2ed8dcf797  vmovaps xmm10, [rsp+0x20]
00007d2ed8dcf79d  por xmm11, xmm10
00007d2ed8dcf7a2  vmovaps [rsp+0x20], xmm4
00007d2ed8dcf7a8  vmovaps xmm10, [rsp+0x20]
00007d2ed8dcf7ae  por xmm4, xmm10
00007d2ed8dcf7b3  vmovaps [rsp+0x20], xmm8
00007d2ed8dcf7b9  vmovaps xmm10, [rsp+0x20]
00007d2ed8dcf7bf  por xmm8, xmm10
00007d2ed8dcf7c4  vmovaps xmm10, [rsp+0xF0]
00007d2ed8dcf7cd  vmovaps [rsp+0x20], xmm1
00007d2ed8dcf7d3  vmovaps xmm1, [rsp+0xF0]
00007d2ed8dcf7dc  por xmm10, xmm1
00007d2ed8dcf7e1  lea rax, [r14+0xA0]
00007d2ed8dcf7e8  movups xmm1, [r13+rax*1]
00007d2ed8dcf7ee  lea rax, [r14+0xB0]
00007d2ed8dcf7f5  vmovaps [rsp+0x30], xmm1
00007d2ed8dcf7fb  movups xmm1, [r13+rax*1]
00007d2ed8dcf801  vmovaps [rsp+0xF0], xmm1
00007d2ed8dcf80a  vmovaps [rsp+0x120], xmm15
00007d2ed8dcf813  movaps xmm1, xmm13
00007d2ed8dcf817  addpd xmm1, xmm2
00007d2ed8dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d2ed8dcf820  ptest xmm15, xmm15
00007d2ed8dcf826  jnz 0x00007D2ED8DD11ED
00007d2ed8dcf82c  lea rax, [r14+0xF0]
00007d2ed8dcf833  movups xmm15, [r13+rax*1]
00007d2ed8dcf839  vmovaps xmm2, [rsp+0xC0]
00007d2ed8dcf842  vmovaps [rsp+0xC0], xmm1
00007d2ed8dcf84b  vmovaps xmm1, [rsp+0xE0]
00007d2ed8dcf854  vmovaps [rsp+0xE0], xmm15
00007d2ed8dcf85d  movaps xmm13, xmm2
00007d2ed8dcf861  addpd xmm13, xmm1
00007d2ed8dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007d2ed8dcf86c  ptest xmm15, xmm15
00007d2ed8dcf872  jnz 0x00007D2ED8DD1338
00007d2ed8dcf878  vmovaps xmm15, [rsp+0x120]
00007d2ed8dcf881  vmovaps xmm2, [rsp+0xD0]
00007d2ed8dcf88a  vmovaps [rsp+0xD0], xmm14
00007d2ed8dcf893  movaps xmm1, xmm15
00007d2ed8dcf897  addpd xmm1, xmm2
00007d2ed8dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007d2ed8dcf8a0  ptest xmm14, xmm14
00007d2ed8dcf8a6  jnz 0x00007D2ED8DD147A
00007d2ed8dcf8ac  vmovaps xmm15, [rsp+0x100]
00007d2ed8dcf8b5  vpermilpd xmm15, xmm15, 0x00
00007d2ed8dcf8bb  vmovaps xmm2, [rsp+0xF0]
00007d2ed8dcf8c4  vmovaps [rsp+0xF0], xmm1
00007d2ed8dcf8cd  movaps xmm14, xmm2
00007d2ed8dcf8d1  mulpd xmm14, xmm15
00007d2ed8dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007d2ed8dcf8dc  ptest xmm1, xmm1
00007d2ed8dcf8e1  jnz 0x00007D2ED8DD15BB
00007d2ed8dcf8e7  vmovaps xmm1, [rsp+0xA0]
00007d2ed8dcf8f0  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dcf8f6  vmovaps xmm2, [rsp+0xE0]
00007d2ed8dcf8ff  vmovaps [rsp+0xE0], xmm14
00007d2ed8dcf908  movaps xmm15, xmm2
00007d2ed8dcf90c  mulpd xmm15, xmm1
00007d2ed8dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007d2ed8dcf917  ptest xmm14, xmm14
00007d2ed8dcf91d  jnz 0x00007D2ED8DD16FE
00007d2ed8dcf923  lea rax, [r14+0xE0]
00007d2ed8dcf92a  movups xmm1, [r13+rax*1]
00007d2ed8dcf930  vmovaps xmm14, [rsp+0x100]
00007d2ed8dcf939  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dcf93f  vmovaps [rsp+0x100], xmm1
00007d2ed8dcf948  vmovaps xmm1, [rsp+0x30]
00007d2ed8dcf94e  vmovaps [rsp+0x30], xmm15
00007d2ed8dcf954  movaps xmm2, xmm1
00007d2ed8dcf957  mulpd xmm2, xmm14
00007d2ed8dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007d2ed8dcf961  ptest xmm15, xmm15
00007d2ed8dcf967  jnz 0x00007D2ED8DD184A
00007d2ed8dcf96d  vmovaps [rsp+0x120], xmm10
00007d2ed8dcf976  vmovaps xmm1, [rsp+0x120]
00007d2ed8dcf97f  por xmm10, xmm1
00007d2ed8dcf984  movaps [r15+0x300], xmm10
00007d2ed8dcf98c  vmovaps [rsp+0x120], xmm8
00007d2ed8dcf995  vmovaps xmm1, [rsp+0x120]
00007d2ed8dcf99e  por xmm8, xmm1
00007d2ed8dcf9a3  movaps [r15+0x190], xmm8
00007d2ed8dcf9ab  vmovaps xmm1, [rsp+0xA0]
00007d2ed8dcf9b4  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dcf9ba  vmovaps xmm14, [rsp+0x100]
00007d2ed8dcf9c3  vmovaps [rsp+0x100], xmm13
00007d2ed8dcf9cc  movaps xmm15, xmm14
00007d2ed8dcf9d0  mulpd xmm15, xmm1
00007d2ed8dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007d2ed8dcf9db  ptest xmm13, xmm13
00007d2ed8dcf9e1  jnz 0x00007D2ED8DD198B
00007d2ed8dcf9e7  lea rax, [r14+0x90]
00007d2ed8dcf9ee  movups xmm1, [r13+rax*1]
00007d2ed8dcf9f4  vmovaps [rsp+0x120], xmm4
00007d2ed8dcf9fd  vmovaps xmm14, [rsp+0x120]
00007d2ed8dcfa06  por xmm4, xmm14
00007d2ed8dcfa0b  movaps [r15+0x1C0], xmm4
00007d2ed8dcfa13  vmovaps [rsp+0x120], xmm11
00007d2ed8dcfa1c  vmovaps xmm14, [rsp+0x120]
00007d2ed8dcfa25  por xmm11, xmm14
00007d2ed8dcfa2a  movaps [r15+0x200], xmm11
00007d2ed8dcfa32  vmovaps [rsp+0x120], xmm5
00007d2ed8dcfa3b  vmovaps xmm14, [rsp+0x120]
00007d2ed8dcfa44  por xmm5, xmm14
00007d2ed8dcfa49  movaps [r15+0x2D0], xmm5
00007d2ed8dcfa51  vmovaps [rsp+0x120], xmm12
00007d2ed8dcfa5a  vmovaps xmm14, [rsp+0x120]
00007d2ed8dcfa63  por xmm12, xmm14
00007d2ed8dcfa68  movaps [r15+0x2E0], xmm12
00007d2ed8dcfa70  vmovaps xmm13, [rsp+0x110]
00007d2ed8dcfa79  vmovaps [rsp+0x110], xmm1
00007d2ed8dcfa82  vmovaps xmm1, [rsp+0xE0]
00007d2ed8dcfa8b  vmovaps [rsp+0xE0], xmm15
00007d2ed8dcfa94  movaps xmm14, xmm13
00007d2ed8dcfa98  addpd xmm14, xmm1
00007d2ed8dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007d2ed8dcfaa3  ptest xmm15, xmm15
00007d2ed8dcfaa9  jnz 0x00007D2ED8DD1AD8
00007d2ed8dcfaaf  vmovaps xmm1, [rsp+0xA0]
00007d2ed8dcfab8  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dcfabe  vmovaps xmm13, [rsp+0x110]
00007d2ed8dcfac7  vmovaps [rsp+0x110], xmm14
00007d2ed8dcfad0  movaps xmm15, xmm13
00007d2ed8dcfad4  mulpd xmm15, xmm1
00007d2ed8dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007d2ed8dcfadf  ptest xmm14, xmm14
00007d2ed8dcfae5  jnz 0x00007D2ED8DD1C1B
00007d2ed8dcfaeb  lea rax, [r14+0x80]
00007d2ed8dcfaf2  movups xmm1, [r13+rax*1]
00007d2ed8dcfaf8  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dcfb01  vmovaps [rsp+0xC0], xmm1
00007d2ed8dcfb0a  movaps xmm14, xmm13
00007d2ed8dcfb0e  addpd xmm14, xmm2
00007d2ed8dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007d2ed8dcfb19  ptest xmm1, xmm1
00007d2ed8dcfb1e  jnz 0x00007D2ED8DD1D68
00007d2ed8dcfb24  vmovaps xmm13, [rsp+0x100]
00007d2ed8dcfb2d  vmovaps xmm2, [rsp+0x30]
00007d2ed8dcfb33  vmovaps [rsp+0x30], xmm15
00007d2ed8dcfb39  movaps xmm1, xmm13
00007d2ed8dcfb3d  addpd xmm1, xmm2
00007d2ed8dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007d2ed8dcfb46  ptest xmm15, xmm15
00007d2ed8dcfb4c  jnz 0x00007D2ED8DD1EAB
00007d2ed8dcfb52  vmovaps xmm15, [rsp+0x20]
00007d2ed8dcfb58  vmovaps xmm13, [rsp+0x20]
00007d2ed8dcfb5e  por xmm15, xmm13
00007d2ed8dcfb63  movaps [r15+0x2F0], xmm15
00007d2ed8dcfb6b  vmovaps xmm13, [rsp+0xA0]
00007d2ed8dcfb74  vpermilpd xmm13, xmm13, 0x00
00007d2ed8dcfb7a  vmovaps [rsp+0x20], xmm1
00007d2ed8dcfb80  vmovaps xmm1, [rsp+0xC0]
00007d2ed8dcfb89  vmovaps [rsp+0xA0], xmm15
00007d2ed8dcfb92  movaps xmm2, xmm1
00007d2ed8dcfb95  mulpd xmm2, xmm13
00007d2ed8dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d2ed8dcfb9f  ptest xmm15, xmm15
00007d2ed8dcfba5  jnz 0x00007D2ED8DD1FEC
00007d2ed8dcfbab  lea rax, [r14+0xD0]
00007d2ed8dcfbb2  movups xmm1, [r13+rax*1]
00007d2ed8dcfbb8  vmovaps xmm13, [rsp+0xF0]
00007d2ed8dcfbc1  vmovaps [rsp+0xC0], xmm1
00007d2ed8dcfbca  vmovaps xmm1, [rsp+0xE0]
00007d2ed8dcfbd3  vmovaps [rsp+0xE0], xmm14
00007d2ed8dcfbdc  movaps xmm15, xmm13
00007d2ed8dcfbe0  addpd xmm15, xmm1
00007d2ed8dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007d2ed8dcfbeb  ptest xmm14, xmm14
00007d2ed8dcfbf1  jnz 0x00007D2ED8DD2137
00007d2ed8dcfbf7  vmovaps xmm1, [rsp+0xB0]
00007d2ed8dcfc00  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dcfc06  movaps xmm14, xmm11
00007d2ed8dcfc0a  mulpd xmm14, xmm1
00007d2ed8dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007d2ed8dcfc15  ptest xmm13, xmm13
00007d2ed8dcfc1b  jnz 0x00007D2ED8DD227A
00007d2ed8dcfc21  movaps [r15+0x260], xmm14
00007d2ed8dcfc29  vxorps xmm1, xmm1, xmm1
00007d2ed8dcfc2d  vpbroadcastq xmm1, xmm1
00007d2ed8dcfc32  movaps [r15+0x1B0], xmm1
00007d2ed8dcfc3a  vmovaps xmm1, [rsp+0xB0]
00007d2ed8dcfc43  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dcfc49  vmovaps xmm11, [rsp+0xC0]
00007d2ed8dcfc52  vmovaps [rsp+0xC0], xmm15
00007d2ed8dcfc5b  movaps xmm13, xmm11
00007d2ed8dcfc5f  mulpd xmm13, xmm1
00007d2ed8dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007d2ed8dcfc6a  ptest xmm15, xmm15
00007d2ed8dcfc70  jnz 0x00007D2ED8DD23BD
00007d2ed8dcfc76  lea rax, [r14+0xC0]
00007d2ed8dcfc7d  movups xmm1, [r13+rax*1]
00007d2ed8dcfc83  vmovaps xmm11, [rsp+0x110]
00007d2ed8dcfc8c  vmovaps [rsp+0xF0], xmm1
00007d2ed8dcfc95  vmovaps xmm1, [rsp+0x30]
00007d2ed8dcfc9b  vmovaps [rsp+0x30], xmm14
00007d2ed8dcfca1  movaps xmm15, xmm11
00007d2ed8dcfca5  addpd xmm15, xmm1
00007d2ed8dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007d2ed8dcfcb0  ptest xmm14, xmm14
00007d2ed8dcfcb6  jnz 0x00007D2ED8DD250A
00007d2ed8dcfcbc  vmovaps [rsp+0x100], xmm9
00007d2ed8dcfcc5  vmovaps xmm1, [rsp+0x100]
00007d2ed8dcfcce  por xmm9, xmm1
00007d2ed8dcfcd3  movaps [r15+0x270], xmm9
00007d2ed8dcfcdb  vmovaps [rsp+0x100], xmm6
00007d2ed8dcfce4  vmovaps xmm1, [rsp+0x100]
00007d2ed8dcfced  por xmm6, xmm1
00007d2ed8dcfcf1  movaps [r15+0x1A0], xmm6
00007d2ed8dcfcf9  vmovaps xmm14, [rsp+0xB0]
00007d2ed8dcfd02  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dcfd08  vmovaps xmm6, [rsp+0xF0]
00007d2ed8dcfd11  vmovaps [rsp+0xF0], xmm1
00007d2ed8dcfd1a  movaps xmm11, xmm6
00007d2ed8dcfd1e  mulpd xmm11, xmm14
00007d2ed8dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007d2ed8dcfd29  ptest xmm1, xmm1
00007d2ed8dcfd2e  jnz 0x00007D2ED8DD264D
00007d2ed8dcfd34  lea rax, [r14+0x20]
00007d2ed8dcfd38  movups xmm1, [r13+rax*1]
00007d2ed8dcfd3e  movaps [r15+0x110], xmm1
00007d2ed8dcfd46  vmovaps xmm6, [rsp+0xE0]
00007d2ed8dcfd4f  vmovaps [rsp+0xE0], xmm1
00007d2ed8dcfd58  movaps xmm14, xmm6
00007d2ed8dcfd5c  addpd xmm14, xmm2
00007d2ed8dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007d2ed8dcfd67  ptest xmm1, xmm1
00007d2ed8dcfd6c  jnz 0x00007D2ED8DD279A
00007d2ed8dcfd72  vmovaps xmm1, [rsp+0xB0]
00007d2ed8dcfd7b  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dcfd81  movaps xmm6, xmm5
00007d2ed8dcfd84  mulpd xmm6, xmm1
00007d2ed8dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007d2ed8dcfd8d  ptest xmm2, xmm2
00007d2ed8dcfd92  jnz 0x00007D2ED8DD28DC
00007d2ed8dcfd98  vmovaps xmm5, [rsp+0x20]
00007d2ed8dcfd9e  movaps xmm1, xmm5
00007d2ed8dcfda1  addpd xmm1, xmm13
00007d2ed8dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007d2ed8dcfdab  ptest xmm2, xmm2
00007d2ed8dcfdb0  jnz 0x00007D2ED8DD2A1C
00007d2ed8dcfdb6  vmovaps xmm13, [rsp+0x80]
00007d2ed8dcfdbf  vpermilpd xmm13, xmm13, 0x00
00007d2ed8dcfdc5  vmovaps xmm2, [rsp+0xE0]
00007d2ed8dcfdce  vmovaps [rsp+0x20], xmm1
00007d2ed8dcfdd4  movaps xmm5, xmm2
00007d2ed8dcfdd7  mulpd xmm5, xmm13
00007d2ed8dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007d2ed8dcfde1  ptest xmm1, xmm1
00007d2ed8dcfde6  jnz 0x00007D2ED8DD2B5D
00007d2ed8dcfdec  vmovaps xmm1, [rsp+0x80]
00007d2ed8dcfdf5  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dcfdfb  movaps xmm13, xmm10
00007d2ed8dcfdff  mulpd xmm13, xmm1
00007d2ed8dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007d2ed8dcfe0a  ptest xmm2, xmm2
00007d2ed8dcfe0f  jnz 0x00007D2ED8DD2C9E
00007d2ed8dcfe15  vmovaps xmm10, [rsp+0x30]
00007d2ed8dcfe1b  movaps xmm1, xmm15
00007d2ed8dcfe1f  addpd xmm1, xmm10
00007d2ed8dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007d2ed8dcfe29  ptest xmm2, xmm2
00007d2ed8dcfe2e  jnz 0x00007D2ED8DD2DE1
00007d2ed8dcfe34  vmovaps xmm10, [rsp+0xC0]
00007d2ed8dcfe3d  movaps xmm15, xmm10
00007d2ed8dcfe41  addpd xmm15, xmm11
00007d2ed8dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007d2ed8dcfe4c  ptest xmm2, xmm2
00007d2ed8dcfe51  jnz 0x00007D2ED8DD2F23
00007d2ed8dcfe57  vmovaps xmm11, [rsp+0x80]
00007d2ed8dcfe60  vpermilpd xmm11, xmm11, 0x00
00007d2ed8dcfe66  movaps xmm10, xmm12
00007d2ed8dcfe6a  mulpd xmm10, xmm11
00007d2ed8dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007d2ed8dcfe75  ptest xmm2, xmm2
00007d2ed8dcfe7a  jnz 0x00007D2ED8DD3067
00007d2ed8dcfe80  vmovaps xmm12, [rsp+0x80]
00007d2ed8dcfe89  vpermilpd xmm12, xmm12, 0x00
00007d2ed8dcfe8f  vmovaps xmm2, [rsp+0xA0]
00007d2ed8dcfe98  vmovaps [rsp+0x30], xmm1
00007d2ed8dcfe9e  movaps xmm11, xmm2
00007d2ed8dcfea2  mulpd xmm11, xmm12
00007d2ed8dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007d2ed8dcfead  ptest xmm1, xmm1
00007d2ed8dcfeb2  jnz 0x00007D2ED8DD31AB
00007d2ed8dcfeb8  movaps xmm1, xmm14
00007d2ed8dcfebc  addpd xmm1, xmm6
00007d2ed8dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007d2ed8dcfec5  ptest xmm12, xmm12
00007d2ed8dcfecb  jnz 0x00007D2ED8DD32EE
00007d2ed8dcfed1  vmovaps xmm12, [rsp+0x20]
00007d2ed8dcfed7  movaps xmm14, xmm12
00007d2ed8dcfedb  addpd xmm14, xmm5
00007d2ed8dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007d2ed8dcfee6  ptest xmm6, xmm6
00007d2ed8dcfeeb  jnz 0x00007D2ED8DD342F
00007d2ed8dcfef1  vmovaps xmm12, [rsp+0x90]
00007d2ed8dcfefa  vpermilpd xmm12, xmm12, 0x00
00007d2ed8dcff00  movaps xmm6, xmm9
00007d2ed8dcff04  mulpd xmm6, xmm12
00007d2ed8dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007d2ed8dcff0e  ptest xmm5, xmm5
00007d2ed8dcff13  jnz 0x00007D2ED8DD3572
00007d2ed8dcff19  movaps xmm12, xmm15
00007d2ed8dcff1d  addpd xmm12, xmm13
00007d2ed8dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007d2ed8dcff28  ptest xmm9, xmm9
00007d2ed8dcff2e  jnz 0x00007D2ED8DD36B4
00007d2ed8dcff34  vmovaps xmm13, [rsp+0x30]
00007d2ed8dcff3a  movaps xmm15, xmm13
00007d2ed8dcff3e  addpd xmm15, xmm10
00007d2ed8dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007d2ed8dcff49  ptest xmm9, xmm9
00007d2ed8dcff4f  jnz 0x00007D2ED8DD37F8
00007d2ed8dcff55  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dcff5e  vmovaps xmm10, [rsp+0xD0]
00007d2ed8dcff67  por xmm13, xmm10
00007d2ed8dcff6c  movaps [r15+0x250], xmm13
00007d2ed8dcff74  vmovaps [rsp+0x20], xmm7
00007d2ed8dcff7a  vmovaps xmm13, [rsp+0x20]
00007d2ed8dcff80  por xmm7, xmm13
00007d2ed8dcff85  movaps [r15+0x2A0], xmm7
00007d2ed8dcff8d  vmovaps [rsp+0x20], xmm3
00007d2ed8dcff93  vmovaps xmm13, [rsp+0x20]
00007d2ed8dcff99  por xmm3, xmm13
00007d2ed8dcff9e  movaps [r15+0x1D0], xmm3
00007d2ed8dcffa6  lea rax, [r14+0x40]
00007d2ed8dcffaa  movups xmm13, [r13+rax*1]
00007d2ed8dcffb0  movaps [r15+0x2C0], xmm13
00007d2ed8dcffb8  vmovaps xmm10, [rsp+0x90]
00007d2ed8dcffc1  vpermilpd xmm10, xmm10, 0x00
00007d2ed8dcffc7  movaps xmm9, xmm8
00007d2ed8dcffcb  mulpd xmm9, xmm10
00007d2ed8dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007d2ed8dcffd6  ptest xmm5, xmm5
00007d2ed8dcffdb  jnz 0x00007D2ED8DD3946
00007d2ed8dcffe1  movaps xmm10, xmm1
00007d2ed8dcffe5  addpd xmm10, xmm11
00007d2ed8dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007d2ed8dcfff0  ptest xmm8, xmm8
00007d2ed8dcfff6  jnz 0x00007D2ED8DD3A8A
00007d2ed8dcfffc  movaps xmm1, xmm14
00007d2ed8dd0000  addpd xmm1, xmm6
00007d2ed8dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007d2ed8dd0009  ptest xmm11, xmm11
00007d2ed8dd000f  jnz 0x00007D2ED8DD3BCD
00007d2ed8dd0015  vmovaps xmm14, [rsp+0x90]
00007d2ed8dd001e  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dd0024  movaps xmm11, xmm13
00007d2ed8dd0028  mulpd xmm11, xmm14
00007d2ed8dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007d2ed8dd0033  ptest xmm8, xmm8
00007d2ed8dd0039  jnz 0x00007D2ED8DD3D0E
00007d2ed8dd003f  vmovaps xmm14, [rsp+0x90]
00007d2ed8dd0048  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dd004e  vmovaps xmm8, [rsp+0x10]
00007d2ed8dd0054  movaps xmm13, xmm8
00007d2ed8dd0058  mulpd xmm13, xmm14
00007d2ed8dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007d2ed8dd0063  ptest xmm6, xmm6
00007d2ed8dd0068  jnz 0x00007D2ED8DD3E52
00007d2ed8dd006e  vmovaps xmm14, [rsp+0x60]
00007d2ed8dd0074  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dd007a  movaps xmm8, xmm7
00007d2ed8dd007e  mulpd xmm8, xmm14
00007d2ed8dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007d2ed8dd0089  ptest xmm6, xmm6
00007d2ed8dd008e  jnz 0x00007D2ED8DD3F96
00007d2ed8dd0094  movaps xmm14, xmm12
00007d2ed8dd0098  addpd xmm14, xmm9
00007d2ed8dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007d2ed8dd00a3  ptest xmm7, xmm7
00007d2ed8dd00a8  jnz 0x00007D2ED8DD40D9
00007d2ed8dd00ae  vmovaps xmm12, [rsp+0x60]
00007d2ed8dd00b4  vpermilpd xmm12, xmm12, 0x00
00007d2ed8dd00ba  vmovaps xmm7, [rsp+0xF0]
00007d2ed8dd00c3  movaps xmm9, xmm7
00007d2ed8dd00c7  mulpd xmm9, xmm12
00007d2ed8dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007d2ed8dd00d2  ptest xmm6, xmm6
00007d2ed8dd00d7  jnz 0x00007D2ED8DD421D
00007d2ed8dd00dd  movaps xmm12, xmm15
00007d2ed8dd00e1  addpd xmm12, xmm11
00007d2ed8dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007d2ed8dd00ec  ptest xmm7, xmm7
00007d2ed8dd00f1  jnz 0x00007D2ED8DD4360
00007d2ed8dd00f7  vmovaps xmm15, [rsp+0x60]
00007d2ed8dd00fd  vpermilpd xmm15, xmm15, 0x00
00007d2ed8dd0103  vmovaps xmm7, [rsp+0x40]
00007d2ed8dd0109  movaps xmm11, xmm7
00007d2ed8dd010d  mulpd xmm11, xmm15
00007d2ed8dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007d2ed8dd0118  ptest xmm6, xmm6
00007d2ed8dd011d  jnz 0x00007D2ED8DD44A4
00007d2ed8dd0123  movaps xmm15, xmm10
00007d2ed8dd0127  addpd xmm15, xmm13
00007d2ed8dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007d2ed8dd0132  ptest xmm7, xmm7
00007d2ed8dd0137  jnz 0x00007D2ED8DD45E7
00007d2ed8dd013d  vmovaps xmm13, [rsp+0x60]
00007d2ed8dd0143  vpermilpd xmm13, xmm13, 0x00
00007d2ed8dd0149  vmovaps xmm7, [rsp+0x50]
00007d2ed8dd014f  movaps xmm10, xmm7
00007d2ed8dd0153  mulpd xmm10, xmm13
00007d2ed8dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007d2ed8dd015e  ptest xmm6, xmm6
00007d2ed8dd0163  jnz 0x00007D2ED8DD472B
00007d2ed8dd0169  movaps xmm13, xmm1
00007d2ed8dd016d  addpd xmm13, xmm8
00007d2ed8dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007d2ed8dd0178  ptest xmm7, xmm7
00007d2ed8dd017d  jnz 0x00007D2ED8DD486E
00007d2ed8dd0183  lea rax, [r14+0x70]
00007d2ed8dd0187  movups xmm1, [r13+rax*1]
00007d2ed8dd018d  movaps [r15+0x240], xmm1
00007d2ed8dd0195  movaps xmm8, xmm14
00007d2ed8dd0199  addpd xmm8, xmm9
00007d2ed8dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007d2ed8dd01a4  ptest xmm7, xmm7
00007d2ed8dd01a9  jnz 0x00007D2ED8DD49BB
00007d2ed8dd01af  movaps [r15+0x170], xmm8
00007d2ed8dd01b7  vmovaps xmm14, [rsp+0x70]
00007d2ed8dd01bd  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dd01c3  movaps xmm9, xmm1
00007d2ed8dd01c7  mulpd xmm9, xmm14
00007d2ed8dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007d2ed8dd01d2  ptest xmm7, xmm7
00007d2ed8dd01d7  jnz 0x00007D2ED8DD4AFF
00007d2ed8dd01dd  vmovaps xmm1, [rsp+0x70]
00007d2ed8dd01e3  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd01e9  movaps xmm14, xmm4
00007d2ed8dd01ed  mulpd xmm14, xmm1
00007d2ed8dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007d2ed8dd01f8  ptest xmm7, xmm7
00007d2ed8dd01fd  jnz 0x00007D2ED8DD4C42
00007d2ed8dd0203  movaps [r15+0x180], xmm14
00007d2ed8dd020b  movaps xmm1, xmm12
00007d2ed8dd020f  addpd xmm1, xmm11
00007d2ed8dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007d2ed8dd0219  ptest xmm7, xmm7
00007d2ed8dd021e  jnz 0x00007D2ED8DD4D84
00007d2ed8dd0224  movaps [r15+0x210], xmm1
00007d2ed8dd022c  movups xmm12, [r13+r14*1]
00007d2ed8dd0232  lea rax, [r14+0x10]
00007d2ed8dd0236  movups xmm11, [r13+rax*1]
00007d2ed8dd023c  movaps [r15+0x230], xmm11
00007d2ed8dd0244  movaps xmm7, xmm15
00007d2ed8dd0248  addpd xmm7, xmm10
00007d2ed8dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007d2ed8dd0252  ptest xmm6, xmm6
00007d2ed8dd0257  jnz 0x00007D2ED8DD4EDA
00007d2ed8dd025d  movaps [r15+0x130], xmm7
00007d2ed8dd0265  vmovaps xmm15, [rsp+0x70]
00007d2ed8dd026b  vpermilpd xmm15, xmm15, 0x00
00007d2ed8dd0271  movaps xmm10, xmm11
00007d2ed8dd0275  mulpd xmm10, xmm15
00007d2ed8dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007d2ed8dd0280  ptest xmm6, xmm6
00007d2ed8dd0285  jnz 0x00007D2ED8DD501C
00007d2ed8dd028b  movaps [r15+0x220], xmm10
00007d2ed8dd0293  vmovaps xmm15, [rsp+0x70]
00007d2ed8dd0299  vpermilpd xmm15, xmm15, 0x00
00007d2ed8dd029f  movaps xmm11, xmm12
00007d2ed8dd02a3  mulpd xmm11, xmm15
00007d2ed8dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007d2ed8dd02ae  ptest xmm6, xmm6
00007d2ed8dd02b3  jnz 0x00007D2ED8DD5160
00007d2ed8dd02b9  movaps xmm15, xmm13
00007d2ed8dd02bd  addpd xmm15, xmm9
00007d2ed8dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007d2ed8dd02c8  ptest xmm12, xmm12
00007d2ed8dd02ce  jnz 0x00007D2ED8DD52A4
00007d2ed8dd02d4  movaps [r15+0x140], xmm15
00007d2ed8dd02dc  movaps xmm13, xmm8
00007d2ed8dd02e0  addpd xmm13, xmm14
00007d2ed8dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007d2ed8dd02eb  ptest xmm12, xmm12
00007d2ed8dd02f1  jnz 0x00007D2ED8DD53E8
00007d2ed8dd02f7  movaps [r15+0x150], xmm13
00007d2ed8dd02ff  movaps xmm14, xmm1
00007d2ed8dd0303  addpd xmm14, xmm10
00007d2ed8dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007d2ed8dd030e  ptest xmm12, xmm12
00007d2ed8dd0314  jnz 0x00007D2ED8DD552C
00007d2ed8dd031a  movaps [r15+0x160], xmm14
00007d2ed8dd0322  movaps xmm1, xmm7
00007d2ed8dd0325  addpd xmm1, xmm11
00007d2ed8dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007d2ed8dd032f  ptest xmm12, xmm12
00007d2ed8dd0335  jnz 0x00007D2ED8DD566F
00007d2ed8dd033b  movaps [r15+0x120], xmm1
00007d2ed8dd0343  mov eax, 0x430920
00007d2ed8dd0348  movups [r13+rax*1], xmm15
00007d2ed8dd034e  mov eax, 0x430930
00007d2ed8dd0353  movups [r13+rax*1], xmm13
00007d2ed8dd0359  mov eax, 0x430940
00007d2ed8dd035e  movups [r13+rax*1], xmm14
00007d2ed8dd0364  mov eax, 0x430950
00007d2ed8dd0369  movups [r13+rax*1], xmm1
00007d2ed8dd036f  mov eax, [r15+0x108]
00007d2ed8dd0376  sahf
00007d2ed8dd0377  jnz 0x00007D2ED8DD03A9
00007d2ed8dd0379  cmp dword ptr [r15+0x318], 0x00
00007d2ed8dd0381  jz 0x00007D2ED8DDB900
00007d2ed8dd0387  nop [rax+rax*1], ax
00007d2ed8dd0390  nop [rax+rax*1], eax
00007d2ed8dd0398  mov eax, 0x410444
00007d2ed8dd039d  mov [r15+0x100], rax
00007d2ed8dd03a4  jmp 0x00007D2ED8BFE110
00007d2ed8dd03a9  cmp dword ptr [r15+0x318], 0x00
00007d2ed8dd03b1  jz 0x00007D2ED8DD57E0
00007d2ed8dd03b7  nop [rax+rax*1], ax
00007d2ed8dd03c0  nop [rax+rax*1], eax
00007d2ed8dd03c8  mov eax, 0x410278
00007d2ed8dd03cd  mov [r15+0x100], rax
00007d2ed8dd03d4  jmp 0x00007D2ED8BFE110
00007d2ed8dd03d9  int3
00007d2ed8dd03da  call 0x00007D2ED8CB52F0
00007d2ed8dd03df  jmp 0x00007D2ED8DCF016
00007d2ed8dd03e4  call 0x00007D2ED8CC4620
00007d2ed8dd03e9  jmp 0x00007D2ED8DCF023
00007d2ed8dd03ee  call 0x00007D2ED8CC33A0
00007d2ed8dd03f3  jmp 0x00007D2ED8DCF035
00007d2ed8dd03f8  call 0x00007D2ED8CC2120
00007d2ed8dd03fd  jmp 0x00007D2ED8DCF03F
00007d2ed8dd0402  call 0x00007D2ED8CC0860
00007d2ed8dd0407  jmp 0x00007D2ED8DCF067
00007d2ed8dd040c  call 0x00007D2ED8CBF5F0
00007d2ed8dd0411  jmp 0x00007D2ED8DCF073
00007d2ed8dd0416  call 0x00007D2ED8CC0860
00007d2ed8dd041b  jmp 0x00007D2ED8DCF0A5
00007d2ed8dd0420  call 0x00007D2ED8CBF5F0
00007d2ed8dd0425  jmp 0x00007D2ED8DCF0B1
00007d2ed8dd042a  call 0x00007D2ED8CC4740
00007d2ed8dd042f  jmp 0x00007D2ED8DCF0BE
00007d2ed8dd0434  call 0x00007D2ED8CB5400
00007d2ed8dd0439  jmp 0x00007D2ED8DCF0CB
00007d2ed8dd043e  call 0x00007D2ED8CB52F0
00007d2ed8dd0443  jmp 0x00007D2ED8DCF0D8
00007d2ed8dd0448  call 0x00007D2ED8CC4620
00007d2ed8dd044d  jmp 0x00007D2ED8DCF0E5
00007d2ed8dd0452  call 0x00007D2ED8CC0860
00007d2ed8dd0457  jmp 0x00007D2ED8DCF10D
00007d2ed8dd045c  call 0x00007D2ED8CBF5F0
00007d2ed8dd0461  jmp 0x00007D2ED8DCF119
00007d2ed8dd0466  call 0x00007D2ED8C09D70
00007d2ed8dd046b  jmp 0x00007D2ED8DCF11F
00007d2ed8dd0470  call 0x00007D2ED8CBE9C0
00007d2ed8dd0475  jmp 0x00007D2ED8DCF129
00007d2ed8dd047a  call 0x00007D2ED8CC0860
00007d2ed8dd047f  jmp 0x00007D2ED8DCF151
00007d2ed8dd0484  call 0x00007D2ED8CBF5F0
00007d2ed8dd0489  jmp 0x00007D2ED8DCF15D
00007d2ed8dd048e  call 0x00007D2ED8CBD750
00007d2ed8dd0493  jmp 0x00007D2ED8DCF16A
00007d2ed8dd0498  call 0x00007D2ED8CBC4E0
00007d2ed8dd049d  jmp 0x00007D2ED8DCF177
00007d2ed8dd04a2  call 0x00007D2ED8CC4740
00007d2ed8dd04a7  jmp 0x00007D2ED8DCF184
00007d2ed8dd04ac  call 0x00007D2ED8CB5400
00007d2ed8dd04b1  jmp 0x00007D2ED8DCF191
00007d2ed8dd04b6  call 0x00007D2ED8CB52F0
00007d2ed8dd04bb  jmp 0x00007D2ED8DCF19E
00007d2ed8dd04c0  call 0x00007D2ED8CC4620
00007d2ed8dd04c5  jmp 0x00007D2ED8DCF1AB
00007d2ed8dd04ca  call 0x00007D2ED8CC0860
00007d2ed8dd04cf  jmp 0x00007D2ED8DCF1BE
00007d2ed8dd04d4  call 0x00007D2ED8CBB270
00007d2ed8dd04d9  jmp 0x00007D2ED8DCF1CB
00007d2ed8dd04de  call 0x00007D2ED8CBA000
00007d2ed8dd04e3  jmp 0x00007D2ED8DCF1D8
00007d2ed8dd04e8  call 0x00007D2ED8CB8D90
00007d2ed8dd04ed  jmp 0x00007D2ED8DCF1E5
00007d2ed8dd04f2  call 0x00007D2ED8CB8A20
00007d2ed8dd04f7  jmp 0x00007D2ED8DCF1F2
00007d2ed8dd04fc  call 0x00007D2ED8CB5400
00007d2ed8dd0501  jmp 0x00007D2ED8DCF1FC
00007d2ed8dd0506  call 0x00007D2ED8CC2240
00007d2ed8dd050b  jmp 0x00007D2ED8DCF206
00007d2ed8dd0510  call 0x00007D2ED8CB52F0
00007d2ed8dd0515  jmp 0x00007D2ED8DCF210
00007d2ed8dd051a  call 0x00007D2ED8CC2120
00007d2ed8dd051f  jmp 0x00007D2ED8DCF21A
00007d2ed8dd0524  call 0x00007D2ED8CB77B0
00007d2ed8dd0529  jmp 0x00007D2ED8DCF224
00007d2ed8dd052e  call 0x00007D2ED8CB6550
00007d2ed8dd0533  jmp 0x00007D2ED8DCF22E
00007d2ed8dd0538  call 0x00007D2ED8CBFD50
00007d2ed8dd053d  jmp 0x00007D2ED8DCF240
00007d2ed8dd0542  call 0x00007D2ED8CB8EA0
00007d2ed8dd0547  jmp 0x00007D2ED8DCF24A
00007d2ed8dd054c  call 0x00007D2ED8CBFC30
00007d2ed8dd0551  jmp 0x00007D2ED8DCF257
00007d2ed8dd0556  call 0x00007D2ED8CB8D90
00007d2ed8dd055b  jmp 0x00007D2ED8DCF264
00007d2ed8dd0560  call 0x00007D2ED8CC2240
00007d2ed8dd0565  jmp 0x00007D2ED8DCF271
00007d2ed8dd056a  call 0x00007D2ED8CB5400
00007d2ed8dd056f  jmp 0x00007D2ED8DCF27E
00007d2ed8dd0574  call 0x00007D2ED8CB52F0
00007d2ed8dd0579  jmp 0x00007D2ED8DCF28B
00007d2ed8dd057e  call 0x00007D2ED8CC2120
00007d2ed8dd0583  jmp 0x00007D2ED8DCF298
00007d2ed8dd0588  call 0x00007D2ED8CB52F0
00007d2ed8dd058d  jmp 0x00007D2ED8DCF2AB
00007d2ed8dd0592  call 0x00007D2ED8CB52F0
00007d2ed8dd0597  jmp 0x00007D2ED8DCF2BE
00007d2ed8dd059c  call 0x00007D2ED8CB52F0
00007d2ed8dd05a1  jmp 0x00007D2ED8DCF2D1
00007d2ed8dd05a6  call 0x00007D2ED8CB52F0
00007d2ed8dd05ab  jmp 0x00007D2ED8DCF2E4
00007d2ed8dd05b0  call 0x00007D2ED8CC2240
00007d2ed8dd05b5  jmp 0x00007D2ED8DCF2F9
00007d2ed8dd05ba  call 0x00007D2ED8CC2240
00007d2ed8dd05bf  jmp 0x00007D2ED8DCF30C
00007d2ed8dd05c4  call 0x00007D2ED8CC2120
00007d2ed8dd05c9  jmp 0x00007D2ED8DCF319
00007d2ed8dd05ce  call 0x00007D2ED8CB52F0
00007d2ed8dd05d3  jmp 0x00007D2ED8DCF32C
00007d2ed8dd05d8  call 0x00007D2ED8CB52F0
00007d2ed8dd05dd  jmp 0x00007D2ED8DCF34F
00007d2ed8dd05e2  call 0x00007D2ED8CB52F0
00007d2ed8dd05e7  jmp 0x00007D2ED8DCF362
00007d2ed8dd05ec  call 0x00007D2ED8BFF540
00007d2ed8dd05f1  jmp 0x00007D2ED8DCF380
00007d2ed8dd05f6  call 0x00007D2ED8C08C20
00007d2ed8dd05fb  jmp 0x00007D2ED8DCF38A
00007d2ed8dd0600  call 0x00007D2ED8CD6600
00007d2ed8dd0605  jmp 0x00007D2ED8DCF396
00007d2ed8dd060a  call 0x00007D2ED8BFF540
00007d2ed8dd060f  jmp 0x00007D2ED8DCF3A6
00007d2ed8dd0614  call 0x00007D2ED8CC0370
00007d2ed8dd0619  jmp 0x00007D2ED8DCF3D4
00007d2ed8dd061e  call 0x00007D2ED8CBF100
00007d2ed8dd0623  jmp 0x00007D2ED8DCF3DD
00007d2ed8dd0628  call 0x00007D2ED8CC0370
00007d2ed8dd062d  jmp 0x00007D2ED8DCF43B
00007d2ed8dd0632  call 0x00007D2ED8CBF100
00007d2ed8dd0637  jmp 0x00007D2ED8DCF444
00007d2ed8dd063c  call 0x00007D2ED8CC0370
00007d2ed8dd0641  jmp 0x00007D2ED8DCF48B
00007d2ed8dd0646  call 0x00007D2ED8CBF100
00007d2ed8dd064b  jmp 0x00007D2ED8DCF494
00007d2ed8dd0650  call 0x00007D2ED8C0B720
00007d2ed8dd0655  jmp 0x00007D2ED8DCF4D7
00007d2ed8dd065a  call 0x00007D2ED8CB47C0
00007d2ed8dd065f  jmp 0x00007D2ED8DCF4EA
00007d2ed8dd0664  call 0x00007D2ED8C08B00
00007d2ed8dd0669  jmp 0x00007D2ED8DCF501
00007d2ed8dd066e  call 0x00007D2ED8BFF430
00007d2ed8dd0673  jmp 0x00007D2ED8DCF514
00007d2ed8dd0678  call 0x00007D2ED8BFF430
00007d2ed8dd067d  jmp 0x00007D2ED8DCF527
00007d2ed8dd0682  sub rsp, 0x08
00007d2ed8dd0686  push rax
00007d2ed8dd0687  push rcx
00007d2ed8dd0688  push rdx
00007d2ed8dd0689  push rdi
00007d2ed8dd068a  push rsi
00007d2ed8dd068b  push r8
00007d2ed8dd068d  push r9
00007d2ed8dd068f  push r10
00007d2ed8dd0691  push r11
00007d2ed8dd0693  sub rsp, 0xF0
00007d2ed8dd069a  vmovaps [rsp], xmm0
00007d2ed8dd069f  vmovaps [rsp+0x10], xmm2
00007d2ed8dd06a5  vmovaps [rsp+0x20], xmm3
00007d2ed8dd06ab  vmovaps [rsp+0x30], xmm4
00007d2ed8dd06b1  vmovaps [rsp+0x40], xmm5
00007d2ed8dd06b7  vmovaps [rsp+0x50], xmm6
00007d2ed8dd06bd  vmovaps [rsp+0x60], xmm7
00007d2ed8dd06c3  vmovaps [rsp+0x70], xmm8
00007d2ed8dd06c9  vmovaps [rsp+0x80], xmm9
00007d2ed8dd06d2  vmovaps [rsp+0x90], xmm10
00007d2ed8dd06db  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd06e4  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd06ed  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd06f6  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd06ff  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd0708  sub rsp, 0x30
00007d2ed8dd070c  movaps [rsp], xmm1
00007d2ed8dd0710  movaps [rsp+0x10], xmm15
00007d2ed8dd0716  movaps [rsp+0x20], xmm14
00007d2ed8dd071c  lea rdi, [rsp]
00007d2ed8dd0720  mov esi, 0x00
00007d2ed8dd0725  mov rax, 0x648718324530
00007d2ed8dd072f  call rax
00007d2ed8dd0731  movaps xmm1, [rsp]
00007d2ed8dd0735  add rsp, 0x30
00007d2ed8dd0739  vmovaps xmm0, [rsp]
00007d2ed8dd073e  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd0744  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd074a  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd0750  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd0756  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd075c  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd0762  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd0768  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd0771  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd077a  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd0783  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd078c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd0795  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd079e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd07a7  add rsp, 0xF0
00007d2ed8dd07ae  pop r11
00007d2ed8dd07b0  pop r10
00007d2ed8dd07b2  pop r9
00007d2ed8dd07b4  pop r8
00007d2ed8dd07b6  pop rsi
00007d2ed8dd07b7  pop rdi
00007d2ed8dd07b8  pop rdx
00007d2ed8dd07b9  pop rcx
00007d2ed8dd07ba  pop rax
00007d2ed8dd07bb  add rsp, 0x08
00007d2ed8dd07bf  jmp 0x00007D2ED8DCF581
00007d2ed8dd07c4  sub rsp, 0x08
00007d2ed8dd07c8  push rax
00007d2ed8dd07c9  push rcx
00007d2ed8dd07ca  push rdx
00007d2ed8dd07cb  push rdi
00007d2ed8dd07cc  push rsi
00007d2ed8dd07cd  push r8
00007d2ed8dd07cf  push r9
00007d2ed8dd07d1  push r10
00007d2ed8dd07d3  push r11
00007d2ed8dd07d5  sub rsp, 0xF0
00007d2ed8dd07dc  vmovaps [rsp], xmm0
00007d2ed8dd07e1  vmovaps [rsp+0x10], xmm1
00007d2ed8dd07e7  vmovaps [rsp+0x20], xmm2
00007d2ed8dd07ed  vmovaps [rsp+0x30], xmm3
00007d2ed8dd07f3  vmovaps [rsp+0x40], xmm4
00007d2ed8dd07f9  vmovaps [rsp+0x50], xmm5
00007d2ed8dd07ff  vmovaps [rsp+0x60], xmm6
00007d2ed8dd0805  vmovaps [rsp+0x70], xmm7
00007d2ed8dd080b  vmovaps [rsp+0x80], xmm8
00007d2ed8dd0814  vmovaps [rsp+0x90], xmm9
00007d2ed8dd081d  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd0826  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd082f  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd0838  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd0841  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd084a  sub rsp, 0x30
00007d2ed8dd084e  movaps [rsp], xmm13
00007d2ed8dd0853  movaps [rsp+0x10], xmm1
00007d2ed8dd0858  movaps [rsp+0x20], xmm14
00007d2ed8dd085e  lea rdi, [rsp]
00007d2ed8dd0862  mov esi, 0x00
00007d2ed8dd0867  mov rax, 0x648718324530
00007d2ed8dd0871  call rax
00007d2ed8dd0873  movaps xmm13, [rsp]
00007d2ed8dd0878  add rsp, 0x30
00007d2ed8dd087c  vmovaps xmm0, [rsp]
00007d2ed8dd0881  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd0887  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd088d  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd0893  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd0899  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd089f  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd08a5  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd08ab  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd08b4  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd08bd  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd08c6  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd08cf  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd08d8  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd08e1  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd08ea  add rsp, 0xF0
00007d2ed8dd08f1  pop r11
00007d2ed8dd08f3  pop r10
00007d2ed8dd08f5  pop r9
00007d2ed8dd08f7  pop r8
00007d2ed8dd08f9  pop rsi
00007d2ed8dd08fa  pop rdi
00007d2ed8dd08fb  pop rdx
00007d2ed8dd08fc  pop rcx
00007d2ed8dd08fd  pop rax
00007d2ed8dd08fe  add rsp, 0x08
00007d2ed8dd0902  jmp 0x00007D2ED8DCF5CF
00007d2ed8dd0907  sub rsp, 0x08
00007d2ed8dd090b  push rax
00007d2ed8dd090c  push rcx
00007d2ed8dd090d  push rdx
00007d2ed8dd090e  push rdi
00007d2ed8dd090f  push rsi
00007d2ed8dd0910  push r8
00007d2ed8dd0912  push r9
00007d2ed8dd0914  push r10
00007d2ed8dd0916  push r11
00007d2ed8dd0918  sub rsp, 0xF0
00007d2ed8dd091f  vmovaps [rsp], xmm0
00007d2ed8dd0924  vmovaps [rsp+0x10], xmm1
00007d2ed8dd092a  vmovaps [rsp+0x20], xmm2
00007d2ed8dd0930  vmovaps [rsp+0x30], xmm3
00007d2ed8dd0936  vmovaps [rsp+0x40], xmm4
00007d2ed8dd093c  vmovaps [rsp+0x50], xmm5
00007d2ed8dd0942  vmovaps [rsp+0x60], xmm6
00007d2ed8dd0948  vmovaps [rsp+0x70], xmm7
00007d2ed8dd094e  vmovaps [rsp+0x80], xmm8
00007d2ed8dd0957  vmovaps [rsp+0x90], xmm9
00007d2ed8dd0960  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd0969  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd0972  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd097b  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd0984  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd098d  sub rsp, 0x30
00007d2ed8dd0991  movaps [rsp], xmm15
00007d2ed8dd0996  movaps [rsp+0x10], xmm14
00007d2ed8dd099c  movaps [rsp+0x20], xmm1
00007d2ed8dd09a1  lea rdi, [rsp]
00007d2ed8dd09a5  mov esi, 0x00
00007d2ed8dd09aa  mov rax, 0x648718324530
00007d2ed8dd09b4  call rax
00007d2ed8dd09b6  movaps xmm15, [rsp]
00007d2ed8dd09bb  add rsp, 0x30
00007d2ed8dd09bf  vmovaps xmm0, [rsp]
00007d2ed8dd09c4  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd09ca  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd09d0  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd09d6  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd09dc  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd09e2  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd09e8  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd09ee  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd09f7  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd0a00  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd0a09  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd0a12  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd0a1b  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd0a24  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd0a2d  add rsp, 0xF0
00007d2ed8dd0a34  pop r11
00007d2ed8dd0a36  pop r10
00007d2ed8dd0a38  pop r9
00007d2ed8dd0a3a  pop r8
00007d2ed8dd0a3c  pop rsi
00007d2ed8dd0a3d  pop rdi
00007d2ed8dd0a3e  pop rdx
00007d2ed8dd0a3f  pop rcx
00007d2ed8dd0a40  pop rax
00007d2ed8dd0a41  add rsp, 0x08
00007d2ed8dd0a45  jmp 0x00007D2ED8DCF617
00007d2ed8dd0a4a  sub rsp, 0x08
00007d2ed8dd0a4e  push rax
00007d2ed8dd0a4f  push rcx
00007d2ed8dd0a50  push rdx
00007d2ed8dd0a51  push rdi
00007d2ed8dd0a52  push rsi
00007d2ed8dd0a53  push r8
00007d2ed8dd0a55  push r9
00007d2ed8dd0a57  push r10
00007d2ed8dd0a59  push r11
00007d2ed8dd0a5b  sub rsp, 0xF0
00007d2ed8dd0a62  vmovaps [rsp], xmm0
00007d2ed8dd0a67  vmovaps [rsp+0x10], xmm2
00007d2ed8dd0a6d  vmovaps [rsp+0x20], xmm3
00007d2ed8dd0a73  vmovaps [rsp+0x30], xmm4
00007d2ed8dd0a79  vmovaps [rsp+0x40], xmm5
00007d2ed8dd0a7f  vmovaps [rsp+0x50], xmm6
00007d2ed8dd0a85  vmovaps [rsp+0x60], xmm7
00007d2ed8dd0a8b  vmovaps [rsp+0x70], xmm8
00007d2ed8dd0a91  vmovaps [rsp+0x80], xmm9
00007d2ed8dd0a9a  vmovaps [rsp+0x90], xmm10
00007d2ed8dd0aa3  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd0aac  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd0ab5  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd0abe  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd0ac7  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd0ad0  sub rsp, 0x30
00007d2ed8dd0ad4  movaps [rsp], xmm1
00007d2ed8dd0ad8  movaps [rsp+0x10], xmm14
00007d2ed8dd0ade  movaps [rsp+0x20], xmm10
00007d2ed8dd0ae4  lea rdi, [rsp]
00007d2ed8dd0ae8  mov esi, 0x00
00007d2ed8dd0aed  mov rax, 0x648718324530
00007d2ed8dd0af7  call rax
00007d2ed8dd0af9  movaps xmm1, [rsp]
00007d2ed8dd0afd  add rsp, 0x30
00007d2ed8dd0b01  vmovaps xmm0, [rsp]
00007d2ed8dd0b06  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd0b0c  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd0b12  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd0b18  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd0b1e  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd0b24  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd0b2a  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd0b30  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd0b39  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd0b42  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd0b4b  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd0b54  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd0b5d  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd0b66  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd0b6f  add rsp, 0xF0
00007d2ed8dd0b76  pop r11
00007d2ed8dd0b78  pop r10
00007d2ed8dd0b7a  pop r9
00007d2ed8dd0b7c  pop r8
00007d2ed8dd0b7e  pop rsi
00007d2ed8dd0b7f  pop rdi
00007d2ed8dd0b80  pop rdx
00007d2ed8dd0b81  pop rcx
00007d2ed8dd0b82  pop rax
00007d2ed8dd0b83  add rsp, 0x08
00007d2ed8dd0b87  jmp 0x00007D2ED8DCF631
00007d2ed8dd0b8c  sub rsp, 0x08
00007d2ed8dd0b90  push rax
00007d2ed8dd0b91  push rcx
00007d2ed8dd0b92  push rdx
00007d2ed8dd0b93  push rdi
00007d2ed8dd0b94  push rsi
00007d2ed8dd0b95  push r8
00007d2ed8dd0b97  push r9
00007d2ed8dd0b99  push r10
00007d2ed8dd0b9b  push r11
00007d2ed8dd0b9d  sub rsp, 0xF0
00007d2ed8dd0ba4  vmovaps [rsp], xmm0
00007d2ed8dd0ba9  vmovaps [rsp+0x10], xmm1
00007d2ed8dd0baf  vmovaps [rsp+0x20], xmm2
00007d2ed8dd0bb5  vmovaps [rsp+0x30], xmm3
00007d2ed8dd0bbb  vmovaps [rsp+0x40], xmm4
00007d2ed8dd0bc1  vmovaps [rsp+0x50], xmm5
00007d2ed8dd0bc7  vmovaps [rsp+0x60], xmm6
00007d2ed8dd0bcd  vmovaps [rsp+0x70], xmm7
00007d2ed8dd0bd3  vmovaps [rsp+0x80], xmm8
00007d2ed8dd0bdc  vmovaps [rsp+0x90], xmm9
00007d2ed8dd0be5  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd0bee  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd0bf7  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd0c00  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd0c09  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd0c12  sub rsp, 0x30
00007d2ed8dd0c16  movaps [rsp], xmm13
00007d2ed8dd0c1b  movaps [rsp+0x10], xmm14
00007d2ed8dd0c21  movaps [rsp+0x20], xmm2
00007d2ed8dd0c26  lea rdi, [rsp]
00007d2ed8dd0c2a  mov esi, 0x00
00007d2ed8dd0c2f  mov rax, 0x648718324530
00007d2ed8dd0c39  call rax
00007d2ed8dd0c3b  movaps xmm13, [rsp]
00007d2ed8dd0c40  add rsp, 0x30
00007d2ed8dd0c44  vmovaps xmm0, [rsp]
00007d2ed8dd0c49  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd0c4f  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd0c55  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd0c5b  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd0c61  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd0c67  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd0c6d  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd0c73  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd0c7c  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd0c85  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd0c8e  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd0c97  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd0ca0  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd0ca9  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd0cb2  add rsp, 0xF0
00007d2ed8dd0cb9  pop r11
00007d2ed8dd0cbb  pop r10
00007d2ed8dd0cbd  pop r9
00007d2ed8dd0cbf  pop r8
00007d2ed8dd0cc1  pop rsi
00007d2ed8dd0cc2  pop rdi
00007d2ed8dd0cc3  pop rdx
00007d2ed8dd0cc4  pop rcx
00007d2ed8dd0cc5  pop rax
00007d2ed8dd0cc6  add rsp, 0x08
00007d2ed8dd0cca  jmp 0x00007D2ED8DCF64C
00007d2ed8dd0ccf  sub rsp, 0x08
00007d2ed8dd0cd3  push rax
00007d2ed8dd0cd4  push rcx
00007d2ed8dd0cd5  push rdx
00007d2ed8dd0cd6  push rdi
00007d2ed8dd0cd7  push rsi
00007d2ed8dd0cd8  push r8
00007d2ed8dd0cda  push r9
00007d2ed8dd0cdc  push r10
00007d2ed8dd0cde  push r11
00007d2ed8dd0ce0  sub rsp, 0xF0
00007d2ed8dd0ce7  vmovaps [rsp], xmm0
00007d2ed8dd0cec  vmovaps [rsp+0x10], xmm2
00007d2ed8dd0cf2  vmovaps [rsp+0x20], xmm3
00007d2ed8dd0cf8  vmovaps [rsp+0x30], xmm4
00007d2ed8dd0cfe  vmovaps [rsp+0x40], xmm5
00007d2ed8dd0d04  vmovaps [rsp+0x50], xmm6
00007d2ed8dd0d0a  vmovaps [rsp+0x60], xmm7
00007d2ed8dd0d10  vmovaps [rsp+0x70], xmm8
00007d2ed8dd0d16  vmovaps [rsp+0x80], xmm9
00007d2ed8dd0d1f  vmovaps [rsp+0x90], xmm10
00007d2ed8dd0d28  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd0d31  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd0d3a  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd0d43  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd0d4c  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd0d55  sub rsp, 0x30
00007d2ed8dd0d59  movaps [rsp], xmm1
00007d2ed8dd0d5d  movaps [rsp+0x10], xmm10
00007d2ed8dd0d63  movaps [rsp+0x20], xmm2
00007d2ed8dd0d68  lea rdi, [rsp]
00007d2ed8dd0d6c  mov esi, 0x00
00007d2ed8dd0d71  mov rax, 0x648718324530
00007d2ed8dd0d7b  call rax
00007d2ed8dd0d7d  movaps xmm1, [rsp]
00007d2ed8dd0d81  add rsp, 0x30
00007d2ed8dd0d85  vmovaps xmm0, [rsp]
00007d2ed8dd0d8a  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd0d90  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd0d96  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd0d9c  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd0da2  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd0da8  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd0dae  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd0db4  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd0dbd  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd0dc6  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd0dcf  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd0dd8  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd0de1  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd0dea  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd0df3  add rsp, 0xF0
00007d2ed8dd0dfa  pop r11
00007d2ed8dd0dfc  pop r10
00007d2ed8dd0dfe  pop r9
00007d2ed8dd0e00  pop r8
00007d2ed8dd0e02  pop rsi
00007d2ed8dd0e03  pop rdi
00007d2ed8dd0e04  pop rdx
00007d2ed8dd0e05  pop rcx
00007d2ed8dd0e06  pop rax
00007d2ed8dd0e07  add rsp, 0x08
00007d2ed8dd0e0b  jmp 0x00007D2ED8DCF6B4
00007d2ed8dd0e10  sub rsp, 0x08
00007d2ed8dd0e14  push rax
00007d2ed8dd0e15  push rcx
00007d2ed8dd0e16  push rdx
00007d2ed8dd0e17  push rdi
00007d2ed8dd0e18  push rsi
00007d2ed8dd0e19  push r8
00007d2ed8dd0e1b  push r9
00007d2ed8dd0e1d  push r10
00007d2ed8dd0e1f  push r11
00007d2ed8dd0e21  sub rsp, 0xF0
00007d2ed8dd0e28  vmovaps [rsp], xmm0
00007d2ed8dd0e2d  vmovaps [rsp+0x10], xmm1
00007d2ed8dd0e33  vmovaps [rsp+0x20], xmm2
00007d2ed8dd0e39  vmovaps [rsp+0x30], xmm3
00007d2ed8dd0e3f  vmovaps [rsp+0x40], xmm4
00007d2ed8dd0e45  vmovaps [rsp+0x50], xmm5
00007d2ed8dd0e4b  vmovaps [rsp+0x60], xmm6
00007d2ed8dd0e51  vmovaps [rsp+0x70], xmm7
00007d2ed8dd0e57  vmovaps [rsp+0x80], xmm8
00007d2ed8dd0e60  vmovaps [rsp+0x90], xmm9
00007d2ed8dd0e69  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd0e72  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd0e7b  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd0e84  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd0e8d  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd0e96  sub rsp, 0x30
00007d2ed8dd0e9a  movaps [rsp], xmm15
00007d2ed8dd0e9f  movaps [rsp+0x10], xmm10
00007d2ed8dd0ea5  movaps [rsp+0x20], xmm2
00007d2ed8dd0eaa  lea rdi, [rsp]
00007d2ed8dd0eae  mov esi, 0x00
00007d2ed8dd0eb3  mov rax, 0x648718324530
00007d2ed8dd0ebd  call rax
00007d2ed8dd0ebf  movaps xmm15, [rsp]
00007d2ed8dd0ec4  add rsp, 0x30
00007d2ed8dd0ec8  vmovaps xmm0, [rsp]
00007d2ed8dd0ecd  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd0ed3  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd0ed9  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd0edf  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd0ee5  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd0eeb  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd0ef1  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd0ef7  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd0f00  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd0f09  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd0f12  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd0f1b  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd0f24  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd0f2d  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd0f36  add rsp, 0xF0
00007d2ed8dd0f3d  pop r11
00007d2ed8dd0f3f  pop r10
00007d2ed8dd0f41  pop r9
00007d2ed8dd0f43  pop r8
00007d2ed8dd0f45  pop rsi
00007d2ed8dd0f46  pop rdi
00007d2ed8dd0f47  pop rdx
00007d2ed8dd0f48  pop rcx
00007d2ed8dd0f49  pop rax
00007d2ed8dd0f4a  add rsp, 0x08
00007d2ed8dd0f4e  jmp 0x00007D2ED8DCF706
00007d2ed8dd0f53  sub rsp, 0x08
00007d2ed8dd0f57  push rax
00007d2ed8dd0f58  push rcx
00007d2ed8dd0f59  push rdx
00007d2ed8dd0f5a  push rdi
00007d2ed8dd0f5b  push rsi
00007d2ed8dd0f5c  push r8
00007d2ed8dd0f5e  push r9
00007d2ed8dd0f60  push r10
00007d2ed8dd0f62  push r11
00007d2ed8dd0f64  sub rsp, 0xF0
00007d2ed8dd0f6b  vmovaps [rsp], xmm0
00007d2ed8dd0f70  vmovaps [rsp+0x10], xmm2
00007d2ed8dd0f76  vmovaps [rsp+0x20], xmm3
00007d2ed8dd0f7c  vmovaps [rsp+0x30], xmm4
00007d2ed8dd0f82  vmovaps [rsp+0x40], xmm5
00007d2ed8dd0f88  vmovaps [rsp+0x50], xmm6
00007d2ed8dd0f8e  vmovaps [rsp+0x60], xmm7
00007d2ed8dd0f94  vmovaps [rsp+0x70], xmm8
00007d2ed8dd0f9a  vmovaps [rsp+0x80], xmm9
00007d2ed8dd0fa3  vmovaps [rsp+0x90], xmm10
00007d2ed8dd0fac  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd0fb5  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd0fbe  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd0fc7  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd0fd0  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd0fd9  sub rsp, 0x30
00007d2ed8dd0fdd  movaps [rsp], xmm1
00007d2ed8dd0fe1  movaps [rsp+0x10], xmm10
00007d2ed8dd0fe7  movaps [rsp+0x20], xmm12
00007d2ed8dd0fed  lea rdi, [rsp]
00007d2ed8dd0ff1  mov esi, 0x00
00007d2ed8dd0ff6  mov rax, 0x648718324530
00007d2ed8dd1000  call rax
00007d2ed8dd1002  movaps xmm1, [rsp]
00007d2ed8dd1006  add rsp, 0x30
00007d2ed8dd100a  vmovaps xmm0, [rsp]
00007d2ed8dd100f  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd1015  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd101b  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd1021  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd1027  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd102d  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd1033  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd1039  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd1042  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd104b  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd1054  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd105d  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd1066  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd106f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd1078  add rsp, 0xF0
00007d2ed8dd107f  pop r11
00007d2ed8dd1081  pop r10
00007d2ed8dd1083  pop r9
00007d2ed8dd1085  pop r8
00007d2ed8dd1087  pop rsi
00007d2ed8dd1088  pop rdi
00007d2ed8dd1089  pop rdx
00007d2ed8dd108a  pop rcx
00007d2ed8dd108b  pop rax
00007d2ed8dd108c  add rsp, 0x08
00007d2ed8dd1090  jmp 0x00007D2ED8DCF732
00007d2ed8dd1095  sub rsp, 0x08
00007d2ed8dd1099  push rax
00007d2ed8dd109a  push rcx
00007d2ed8dd109b  push rdx
00007d2ed8dd109c  push rdi
00007d2ed8dd109d  push rsi
00007d2ed8dd109e  push r8
00007d2ed8dd10a0  push r9
00007d2ed8dd10a2  push r10
00007d2ed8dd10a4  push r11
00007d2ed8dd10a6  sub rsp, 0xF0
00007d2ed8dd10ad  vmovaps [rsp], xmm0
00007d2ed8dd10b2  vmovaps [rsp+0x10], xmm1
00007d2ed8dd10b8  vmovaps [rsp+0x20], xmm2
00007d2ed8dd10be  vmovaps [rsp+0x30], xmm3
00007d2ed8dd10c4  vmovaps [rsp+0x40], xmm4
00007d2ed8dd10ca  vmovaps [rsp+0x50], xmm5
00007d2ed8dd10d0  vmovaps [rsp+0x60], xmm6
00007d2ed8dd10d6  vmovaps [rsp+0x70], xmm7
00007d2ed8dd10dc  vmovaps [rsp+0x80], xmm8
00007d2ed8dd10e5  vmovaps [rsp+0x90], xmm9
00007d2ed8dd10ee  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd10f7  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd1100  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd1109  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd1112  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd111b  sub rsp, 0x30
00007d2ed8dd111f  movaps [rsp], xmm15
00007d2ed8dd1124  movaps [rsp+0x10], xmm10
00007d2ed8dd112a  movaps [rsp+0x20], xmm12
00007d2ed8dd1130  lea rdi, [rsp]
00007d2ed8dd1134  mov esi, 0x00
00007d2ed8dd1139  mov rax, 0x648718324530
00007d2ed8dd1143  call rax
00007d2ed8dd1145  movaps xmm15, [rsp]
00007d2ed8dd114a  add rsp, 0x30
00007d2ed8dd114e  vmovaps xmm0, [rsp]
00007d2ed8dd1153  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd1159  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd115f  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd1165  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd116b  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd1171  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd1177  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd117d  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd1186  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd118f  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd1198  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd11a1  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd11aa  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd11b3  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd11bc  add rsp, 0xF0
00007d2ed8dd11c3  pop r11
00007d2ed8dd11c5  pop r10
00007d2ed8dd11c7  pop r9
00007d2ed8dd11c9  pop r8
00007d2ed8dd11cb  pop rsi
00007d2ed8dd11cc  pop rdi
00007d2ed8dd11cd  pop rdx
00007d2ed8dd11ce  pop rcx
00007d2ed8dd11cf  pop rax
00007d2ed8dd11d0  add rsp, 0x08
00007d2ed8dd11d4  jmp 0x00007D2ED8DCF75E
00007d2ed8dd11d9  call 0x00007D2ED8BFF430
00007d2ed8dd11de  jmp 0x00007D2ED8DCF7EE
00007d2ed8dd11e3  call 0x00007D2ED8BFF430
00007d2ed8dd11e8  jmp 0x00007D2ED8DCF801
00007d2ed8dd11ed  sub rsp, 0x08
00007d2ed8dd11f1  push rax
00007d2ed8dd11f2  push rcx
00007d2ed8dd11f3  push rdx
00007d2ed8dd11f4  push rdi
00007d2ed8dd11f5  push rsi
00007d2ed8dd11f6  push r8
00007d2ed8dd11f8  push r9
00007d2ed8dd11fa  push r10
00007d2ed8dd11fc  push r11
00007d2ed8dd11fe  sub rsp, 0xF0
00007d2ed8dd1205  vmovaps [rsp], xmm0
00007d2ed8dd120a  vmovaps [rsp+0x10], xmm2
00007d2ed8dd1210  vmovaps [rsp+0x20], xmm3
00007d2ed8dd1216  vmovaps [rsp+0x30], xmm4
00007d2ed8dd121c  vmovaps [rsp+0x40], xmm5
00007d2ed8dd1222  vmovaps [rsp+0x50], xmm6
00007d2ed8dd1228  vmovaps [rsp+0x60], xmm7
00007d2ed8dd122e  vmovaps [rsp+0x70], xmm8
00007d2ed8dd1234  vmovaps [rsp+0x80], xmm9
00007d2ed8dd123d  vmovaps [rsp+0x90], xmm10
00007d2ed8dd1246  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd124f  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd1258  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd1261  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd126a  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd1273  sub rsp, 0x30
00007d2ed8dd1277  movaps [rsp], xmm1
00007d2ed8dd127b  movaps [rsp+0x10], xmm13
00007d2ed8dd1281  movaps [rsp+0x20], xmm2
00007d2ed8dd1286  lea rdi, [rsp]
00007d2ed8dd128a  mov esi, 0x00
00007d2ed8dd128f  mov rax, 0x648718324530
00007d2ed8dd1299  call rax
00007d2ed8dd129b  movaps xmm1, [rsp]
00007d2ed8dd129f  add rsp, 0x30
00007d2ed8dd12a3  vmovaps xmm0, [rsp]
00007d2ed8dd12a8  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd12ae  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd12b4  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd12ba  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd12c0  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd12c6  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd12cc  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd12d2  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd12db  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd12e4  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd12ed  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd12f6  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd12ff  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd1308  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd1311  add rsp, 0xF0
00007d2ed8dd1318  pop r11
00007d2ed8dd131a  pop r10
00007d2ed8dd131c  pop r9
00007d2ed8dd131e  pop r8
00007d2ed8dd1320  pop rsi
00007d2ed8dd1321  pop rdi
00007d2ed8dd1322  pop rdx
00007d2ed8dd1323  pop rcx
00007d2ed8dd1324  pop rax
00007d2ed8dd1325  add rsp, 0x08
00007d2ed8dd1329  jmp 0x00007D2ED8DCF82C
00007d2ed8dd132e  call 0x00007D2ED8C0E760
00007d2ed8dd1333  jmp 0x00007D2ED8DCF839
00007d2ed8dd1338  sub rsp, 0x08
00007d2ed8dd133c  push rax
00007d2ed8dd133d  push rcx
00007d2ed8dd133e  push rdx
00007d2ed8dd133f  push rdi
00007d2ed8dd1340  push rsi
00007d2ed8dd1341  push r8
00007d2ed8dd1343  push r9
00007d2ed8dd1345  push r10
00007d2ed8dd1347  push r11
00007d2ed8dd1349  sub rsp, 0xF0
00007d2ed8dd1350  vmovaps [rsp], xmm0
00007d2ed8dd1355  vmovaps [rsp+0x10], xmm1
00007d2ed8dd135b  vmovaps [rsp+0x20], xmm2
00007d2ed8dd1361  vmovaps [rsp+0x30], xmm3
00007d2ed8dd1367  vmovaps [rsp+0x40], xmm4
00007d2ed8dd136d  vmovaps [rsp+0x50], xmm5
00007d2ed8dd1373  vmovaps [rsp+0x60], xmm6
00007d2ed8dd1379  vmovaps [rsp+0x70], xmm7
00007d2ed8dd137f  vmovaps [rsp+0x80], xmm8
00007d2ed8dd1388  vmovaps [rsp+0x90], xmm9
00007d2ed8dd1391  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd139a  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd13a3  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd13ac  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd13b5  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd13be  sub rsp, 0x30
00007d2ed8dd13c2  movaps [rsp], xmm13
00007d2ed8dd13c7  movaps [rsp+0x10], xmm2
00007d2ed8dd13cc  movaps [rsp+0x20], xmm1
00007d2ed8dd13d1  lea rdi, [rsp]
00007d2ed8dd13d5  mov esi, 0x00
00007d2ed8dd13da  mov rax, 0x648718324530
00007d2ed8dd13e4  call rax
00007d2ed8dd13e6  movaps xmm13, [rsp]
00007d2ed8dd13eb  add rsp, 0x30
00007d2ed8dd13ef  vmovaps xmm0, [rsp]
00007d2ed8dd13f4  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd13fa  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd1400  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd1406  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd140c  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd1412  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd1418  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd141e  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd1427  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd1430  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd1439  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd1442  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd144b  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd1454  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd145d  add rsp, 0xF0
00007d2ed8dd1464  pop r11
00007d2ed8dd1466  pop r10
00007d2ed8dd1468  pop r9
00007d2ed8dd146a  pop r8
00007d2ed8dd146c  pop rsi
00007d2ed8dd146d  pop rdi
00007d2ed8dd146e  pop rdx
00007d2ed8dd146f  pop rcx
00007d2ed8dd1470  pop rax
00007d2ed8dd1471  add rsp, 0x08
00007d2ed8dd1475  jmp 0x00007D2ED8DCF878
00007d2ed8dd147a  sub rsp, 0x08
00007d2ed8dd147e  push rax
00007d2ed8dd147f  push rcx
00007d2ed8dd1480  push rdx
00007d2ed8dd1481  push rdi
00007d2ed8dd1482  push rsi
00007d2ed8dd1483  push r8
00007d2ed8dd1485  push r9
00007d2ed8dd1487  push r10
00007d2ed8dd1489  push r11
00007d2ed8dd148b  sub rsp, 0xF0
00007d2ed8dd1492  vmovaps [rsp], xmm0
00007d2ed8dd1497  vmovaps [rsp+0x10], xmm2
00007d2ed8dd149d  vmovaps [rsp+0x20], xmm3
00007d2ed8dd14a3  vmovaps [rsp+0x30], xmm4
00007d2ed8dd14a9  vmovaps [rsp+0x40], xmm5
00007d2ed8dd14af  vmovaps [rsp+0x50], xmm6
00007d2ed8dd14b5  vmovaps [rsp+0x60], xmm7
00007d2ed8dd14bb  vmovaps [rsp+0x70], xmm8
00007d2ed8dd14c1  vmovaps [rsp+0x80], xmm9
00007d2ed8dd14ca  vmovaps [rsp+0x90], xmm10
00007d2ed8dd14d3  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd14dc  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd14e5  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd14ee  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd14f7  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd1500  sub rsp, 0x30
00007d2ed8dd1504  movaps [rsp], xmm1
00007d2ed8dd1508  movaps [rsp+0x10], xmm15
00007d2ed8dd150e  movaps [rsp+0x20], xmm2
00007d2ed8dd1513  lea rdi, [rsp]
00007d2ed8dd1517  mov esi, 0x00
00007d2ed8dd151c  mov rax, 0x648718324530
00007d2ed8dd1526  call rax
00007d2ed8dd1528  movaps xmm1, [rsp]
00007d2ed8dd152c  add rsp, 0x30
00007d2ed8dd1530  vmovaps xmm0, [rsp]
00007d2ed8dd1535  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd153b  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd1541  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd1547  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd154d  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd1553  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd1559  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd155f  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd1568  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd1571  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd157a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd1583  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd158c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd1595  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd159e  add rsp, 0xF0
00007d2ed8dd15a5  pop r11
00007d2ed8dd15a7  pop r10
00007d2ed8dd15a9  pop r9
00007d2ed8dd15ab  pop r8
00007d2ed8dd15ad  pop rsi
00007d2ed8dd15ae  pop rdi
00007d2ed8dd15af  pop rdx
00007d2ed8dd15b0  pop rcx
00007d2ed8dd15b1  pop rax
00007d2ed8dd15b2  add rsp, 0x08
00007d2ed8dd15b6  jmp 0x00007D2ED8DCF8AC
00007d2ed8dd15bb  sub rsp, 0x08
00007d2ed8dd15bf  push rax
00007d2ed8dd15c0  push rcx
00007d2ed8dd15c1  push rdx
00007d2ed8dd15c2  push rdi
00007d2ed8dd15c3  push rsi
00007d2ed8dd15c4  push r8
00007d2ed8dd15c6  push r9
00007d2ed8dd15c8  push r10
00007d2ed8dd15ca  push r11
00007d2ed8dd15cc  sub rsp, 0xF0
00007d2ed8dd15d3  vmovaps [rsp], xmm0
00007d2ed8dd15d8  vmovaps [rsp+0x10], xmm1
00007d2ed8dd15de  vmovaps [rsp+0x20], xmm2
00007d2ed8dd15e4  vmovaps [rsp+0x30], xmm3
00007d2ed8dd15ea  vmovaps [rsp+0x40], xmm4
00007d2ed8dd15f0  vmovaps [rsp+0x50], xmm5
00007d2ed8dd15f6  vmovaps [rsp+0x60], xmm6
00007d2ed8dd15fc  vmovaps [rsp+0x70], xmm7
00007d2ed8dd1602  vmovaps [rsp+0x80], xmm8
00007d2ed8dd160b  vmovaps [rsp+0x90], xmm9
00007d2ed8dd1614  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd161d  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd1626  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd162f  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd1638  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd1641  sub rsp, 0x30
00007d2ed8dd1645  movaps [rsp], xmm14
00007d2ed8dd164a  movaps [rsp+0x10], xmm2
00007d2ed8dd164f  movaps [rsp+0x20], xmm15
00007d2ed8dd1655  lea rdi, [rsp]
00007d2ed8dd1659  mov esi, 0x00
00007d2ed8dd165e  mov rax, 0x648718324530
00007d2ed8dd1668  call rax
00007d2ed8dd166a  movaps xmm14, [rsp]
00007d2ed8dd166f  add rsp, 0x30
00007d2ed8dd1673  vmovaps xmm0, [rsp]
00007d2ed8dd1678  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd167e  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd1684  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd168a  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd1690  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd1696  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd169c  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd16a2  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd16ab  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd16b4  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd16bd  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd16c6  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd16cf  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd16d8  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd16e1  add rsp, 0xF0
00007d2ed8dd16e8  pop r11
00007d2ed8dd16ea  pop r10
00007d2ed8dd16ec  pop r9
00007d2ed8dd16ee  pop r8
00007d2ed8dd16f0  pop rsi
00007d2ed8dd16f1  pop rdi
00007d2ed8dd16f2  pop rdx
00007d2ed8dd16f3  pop rcx
00007d2ed8dd16f4  pop rax
00007d2ed8dd16f5  add rsp, 0x08
00007d2ed8dd16f9  jmp 0x00007D2ED8DCF8E7
00007d2ed8dd16fe  sub rsp, 0x08
00007d2ed8dd1702  push rax
00007d2ed8dd1703  push rcx
00007d2ed8dd1704  push rdx
00007d2ed8dd1705  push rdi
00007d2ed8dd1706  push rsi
00007d2ed8dd1707  push r8
00007d2ed8dd1709  push r9
00007d2ed8dd170b  push r10
00007d2ed8dd170d  push r11
00007d2ed8dd170f  sub rsp, 0xF0
00007d2ed8dd1716  vmovaps [rsp], xmm0
00007d2ed8dd171b  vmovaps [rsp+0x10], xmm1
00007d2ed8dd1721  vmovaps [rsp+0x20], xmm2
00007d2ed8dd1727  vmovaps [rsp+0x30], xmm3
00007d2ed8dd172d  vmovaps [rsp+0x40], xmm4
00007d2ed8dd1733  vmovaps [rsp+0x50], xmm5
00007d2ed8dd1739  vmovaps [rsp+0x60], xmm6
00007d2ed8dd173f  vmovaps [rsp+0x70], xmm7
00007d2ed8dd1745  vmovaps [rsp+0x80], xmm8
00007d2ed8dd174e  vmovaps [rsp+0x90], xmm9
00007d2ed8dd1757  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd1760  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd1769  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd1772  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd177b  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd1784  sub rsp, 0x30
00007d2ed8dd1788  movaps [rsp], xmm15
00007d2ed8dd178d  movaps [rsp+0x10], xmm2
00007d2ed8dd1792  movaps [rsp+0x20], xmm1
00007d2ed8dd1797  lea rdi, [rsp]
00007d2ed8dd179b  mov esi, 0x00
00007d2ed8dd17a0  mov rax, 0x648718324530
00007d2ed8dd17aa  call rax
00007d2ed8dd17ac  movaps xmm15, [rsp]
00007d2ed8dd17b1  add rsp, 0x30
00007d2ed8dd17b5  vmovaps xmm0, [rsp]
00007d2ed8dd17ba  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd17c0  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd17c6  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd17cc  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd17d2  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd17d8  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd17de  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd17e4  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd17ed  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd17f6  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd17ff  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd1808  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd1811  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd181a  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd1823  add rsp, 0xF0
00007d2ed8dd182a  pop r11
00007d2ed8dd182c  pop r10
00007d2ed8dd182e  pop r9
00007d2ed8dd1830  pop r8
00007d2ed8dd1832  pop rsi
00007d2ed8dd1833  pop rdi
00007d2ed8dd1834  pop rdx
00007d2ed8dd1835  pop rcx
00007d2ed8dd1836  pop rax
00007d2ed8dd1837  add rsp, 0x08
00007d2ed8dd183b  jmp 0x00007D2ED8DCF923
00007d2ed8dd1840  call 0x00007D2ED8BFF430
00007d2ed8dd1845  jmp 0x00007D2ED8DCF930
00007d2ed8dd184a  sub rsp, 0x08
00007d2ed8dd184e  push rax
00007d2ed8dd184f  push rcx
00007d2ed8dd1850  push rdx
00007d2ed8dd1851  push rdi
00007d2ed8dd1852  push rsi
00007d2ed8dd1853  push r8
00007d2ed8dd1855  push r9
00007d2ed8dd1857  push r10
00007d2ed8dd1859  push r11
00007d2ed8dd185b  sub rsp, 0xF0
00007d2ed8dd1862  vmovaps [rsp], xmm0
00007d2ed8dd1867  vmovaps [rsp+0x10], xmm1
00007d2ed8dd186d  vmovaps [rsp+0x20], xmm3
00007d2ed8dd1873  vmovaps [rsp+0x30], xmm4
00007d2ed8dd1879  vmovaps [rsp+0x40], xmm5
00007d2ed8dd187f  vmovaps [rsp+0x50], xmm6
00007d2ed8dd1885  vmovaps [rsp+0x60], xmm7
00007d2ed8dd188b  vmovaps [rsp+0x70], xmm8
00007d2ed8dd1891  vmovaps [rsp+0x80], xmm9
00007d2ed8dd189a  vmovaps [rsp+0x90], xmm10
00007d2ed8dd18a3  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd18ac  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd18b5  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd18be  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd18c7  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd18d0  sub rsp, 0x30
00007d2ed8dd18d4  movaps [rsp], xmm2
00007d2ed8dd18d8  movaps [rsp+0x10], xmm1
00007d2ed8dd18dd  movaps [rsp+0x20], xmm14
00007d2ed8dd18e3  lea rdi, [rsp]
00007d2ed8dd18e7  mov esi, 0x00
00007d2ed8dd18ec  mov rax, 0x648718324530
00007d2ed8dd18f6  call rax
00007d2ed8dd18f8  movaps xmm2, [rsp]
00007d2ed8dd18fc  add rsp, 0x30
00007d2ed8dd1900  vmovaps xmm0, [rsp]
00007d2ed8dd1905  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd190b  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd1911  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd1917  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd191d  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd1923  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd1929  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd192f  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd1938  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd1941  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd194a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd1953  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd195c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd1965  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd196e  add rsp, 0xF0
00007d2ed8dd1975  pop r11
00007d2ed8dd1977  pop r10
00007d2ed8dd1979  pop r9
00007d2ed8dd197b  pop r8
00007d2ed8dd197d  pop rsi
00007d2ed8dd197e  pop rdi
00007d2ed8dd197f  pop rdx
00007d2ed8dd1980  pop rcx
00007d2ed8dd1981  pop rax
00007d2ed8dd1982  add rsp, 0x08
00007d2ed8dd1986  jmp 0x00007D2ED8DCF96D
00007d2ed8dd198b  sub rsp, 0x08
00007d2ed8dd198f  push rax
00007d2ed8dd1990  push rcx
00007d2ed8dd1991  push rdx
00007d2ed8dd1992  push rdi
00007d2ed8dd1993  push rsi
00007d2ed8dd1994  push r8
00007d2ed8dd1996  push r9
00007d2ed8dd1998  push r10
00007d2ed8dd199a  push r11
00007d2ed8dd199c  sub rsp, 0xF0
00007d2ed8dd19a3  vmovaps [rsp], xmm0
00007d2ed8dd19a8  vmovaps [rsp+0x10], xmm1
00007d2ed8dd19ae  vmovaps [rsp+0x20], xmm2
00007d2ed8dd19b4  vmovaps [rsp+0x30], xmm3
00007d2ed8dd19ba  vmovaps [rsp+0x40], xmm4
00007d2ed8dd19c0  vmovaps [rsp+0x50], xmm5
00007d2ed8dd19c6  vmovaps [rsp+0x60], xmm6
00007d2ed8dd19cc  vmovaps [rsp+0x70], xmm7
00007d2ed8dd19d2  vmovaps [rsp+0x80], xmm8
00007d2ed8dd19db  vmovaps [rsp+0x90], xmm9
00007d2ed8dd19e4  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd19ed  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd19f6  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd19ff  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd1a08  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd1a11  sub rsp, 0x30
00007d2ed8dd1a15  movaps [rsp], xmm15
00007d2ed8dd1a1a  movaps [rsp+0x10], xmm14
00007d2ed8dd1a20  movaps [rsp+0x20], xmm1
00007d2ed8dd1a25  lea rdi, [rsp]
00007d2ed8dd1a29  mov esi, 0x00
00007d2ed8dd1a2e  mov rax, 0x648718324530
00007d2ed8dd1a38  call rax
00007d2ed8dd1a3a  movaps xmm15, [rsp]
00007d2ed8dd1a3f  add rsp, 0x30
00007d2ed8dd1a43  vmovaps xmm0, [rsp]
00007d2ed8dd1a48  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd1a4e  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd1a54  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd1a5a  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd1a60  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd1a66  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd1a6c  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd1a72  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd1a7b  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd1a84  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd1a8d  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd1a96  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd1a9f  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd1aa8  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd1ab1  add rsp, 0xF0
00007d2ed8dd1ab8  pop r11
00007d2ed8dd1aba  pop r10
00007d2ed8dd1abc  pop r9
00007d2ed8dd1abe  pop r8
00007d2ed8dd1ac0  pop rsi
00007d2ed8dd1ac1  pop rdi
00007d2ed8dd1ac2  pop rdx
00007d2ed8dd1ac3  pop rcx
00007d2ed8dd1ac4  pop rax
00007d2ed8dd1ac5  add rsp, 0x08
00007d2ed8dd1ac9  jmp 0x00007D2ED8DCF9E7
00007d2ed8dd1ace  call 0x00007D2ED8BFF430
00007d2ed8dd1ad3  jmp 0x00007D2ED8DCF9F4
00007d2ed8dd1ad8  sub rsp, 0x08
00007d2ed8dd1adc  push rax
00007d2ed8dd1add  push rcx
00007d2ed8dd1ade  push rdx
00007d2ed8dd1adf  push rdi
00007d2ed8dd1ae0  push rsi
00007d2ed8dd1ae1  push r8
00007d2ed8dd1ae3  push r9
00007d2ed8dd1ae5  push r10
00007d2ed8dd1ae7  push r11
00007d2ed8dd1ae9  sub rsp, 0xF0
00007d2ed8dd1af0  vmovaps [rsp], xmm0
00007d2ed8dd1af5  vmovaps [rsp+0x10], xmm1
00007d2ed8dd1afb  vmovaps [rsp+0x20], xmm2
00007d2ed8dd1b01  vmovaps [rsp+0x30], xmm3
00007d2ed8dd1b07  vmovaps [rsp+0x40], xmm4
00007d2ed8dd1b0d  vmovaps [rsp+0x50], xmm5
00007d2ed8dd1b13  vmovaps [rsp+0x60], xmm6
00007d2ed8dd1b19  vmovaps [rsp+0x70], xmm7
00007d2ed8dd1b1f  vmovaps [rsp+0x80], xmm8
00007d2ed8dd1b28  vmovaps [rsp+0x90], xmm9
00007d2ed8dd1b31  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd1b3a  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd1b43  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd1b4c  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd1b55  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd1b5e  sub rsp, 0x30
00007d2ed8dd1b62  movaps [rsp], xmm14
00007d2ed8dd1b67  movaps [rsp+0x10], xmm13
00007d2ed8dd1b6d  movaps [rsp+0x20], xmm1
00007d2ed8dd1b72  lea rdi, [rsp]
00007d2ed8dd1b76  mov esi, 0x00
00007d2ed8dd1b7b  mov rax, 0x648718324530
00007d2ed8dd1b85  call rax
00007d2ed8dd1b87  movaps xmm14, [rsp]
00007d2ed8dd1b8c  add rsp, 0x30
00007d2ed8dd1b90  vmovaps xmm0, [rsp]
00007d2ed8dd1b95  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd1b9b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd1ba1  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd1ba7  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd1bad  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd1bb3  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd1bb9  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd1bbf  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd1bc8  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd1bd1  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd1bda  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd1be3  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd1bec  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd1bf5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd1bfe  add rsp, 0xF0
00007d2ed8dd1c05  pop r11
00007d2ed8dd1c07  pop r10
00007d2ed8dd1c09  pop r9
00007d2ed8dd1c0b  pop r8
00007d2ed8dd1c0d  pop rsi
00007d2ed8dd1c0e  pop rdi
00007d2ed8dd1c0f  pop rdx
00007d2ed8dd1c10  pop rcx
00007d2ed8dd1c11  pop rax
00007d2ed8dd1c12  add rsp, 0x08
00007d2ed8dd1c16  jmp 0x00007D2ED8DCFAAF
00007d2ed8dd1c1b  sub rsp, 0x08
00007d2ed8dd1c1f  push rax
00007d2ed8dd1c20  push rcx
00007d2ed8dd1c21  push rdx
00007d2ed8dd1c22  push rdi
00007d2ed8dd1c23  push rsi
00007d2ed8dd1c24  push r8
00007d2ed8dd1c26  push r9
00007d2ed8dd1c28  push r10
00007d2ed8dd1c2a  push r11
00007d2ed8dd1c2c  sub rsp, 0xF0
00007d2ed8dd1c33  vmovaps [rsp], xmm0
00007d2ed8dd1c38  vmovaps [rsp+0x10], xmm1
00007d2ed8dd1c3e  vmovaps [rsp+0x20], xmm2
00007d2ed8dd1c44  vmovaps [rsp+0x30], xmm3
00007d2ed8dd1c4a  vmovaps [rsp+0x40], xmm4
00007d2ed8dd1c50  vmovaps [rsp+0x50], xmm5
00007d2ed8dd1c56  vmovaps [rsp+0x60], xmm6
00007d2ed8dd1c5c  vmovaps [rsp+0x70], xmm7
00007d2ed8dd1c62  vmovaps [rsp+0x80], xmm8
00007d2ed8dd1c6b  vmovaps [rsp+0x90], xmm9
00007d2ed8dd1c74  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd1c7d  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd1c86  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd1c8f  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd1c98  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd1ca1  sub rsp, 0x30
00007d2ed8dd1ca5  movaps [rsp], xmm15
00007d2ed8dd1caa  movaps [rsp+0x10], xmm13
00007d2ed8dd1cb0  movaps [rsp+0x20], xmm1
00007d2ed8dd1cb5  lea rdi, [rsp]
00007d2ed8dd1cb9  mov esi, 0x00
00007d2ed8dd1cbe  mov rax, 0x648718324530
00007d2ed8dd1cc8  call rax
00007d2ed8dd1cca  movaps xmm15, [rsp]
00007d2ed8dd1ccf  add rsp, 0x30
00007d2ed8dd1cd3  vmovaps xmm0, [rsp]
00007d2ed8dd1cd8  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd1cde  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd1ce4  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd1cea  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd1cf0  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd1cf6  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd1cfc  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd1d02  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd1d0b  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd1d14  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd1d1d  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd1d26  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd1d2f  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd1d38  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd1d41  add rsp, 0xF0
00007d2ed8dd1d48  pop r11
00007d2ed8dd1d4a  pop r10
00007d2ed8dd1d4c  pop r9
00007d2ed8dd1d4e  pop r8
00007d2ed8dd1d50  pop rsi
00007d2ed8dd1d51  pop rdi
00007d2ed8dd1d52  pop rdx
00007d2ed8dd1d53  pop rcx
00007d2ed8dd1d54  pop rax
00007d2ed8dd1d55  add rsp, 0x08
00007d2ed8dd1d59  jmp 0x00007D2ED8DCFAEB
00007d2ed8dd1d5e  call 0x00007D2ED8BFF430
00007d2ed8dd1d63  jmp 0x00007D2ED8DCFAF8
00007d2ed8dd1d68  sub rsp, 0x08
00007d2ed8dd1d6c  push rax
00007d2ed8dd1d6d  push rcx
00007d2ed8dd1d6e  push rdx
00007d2ed8dd1d6f  push rdi
00007d2ed8dd1d70  push rsi
00007d2ed8dd1d71  push r8
00007d2ed8dd1d73  push r9
00007d2ed8dd1d75  push r10
00007d2ed8dd1d77  push r11
00007d2ed8dd1d79  sub rsp, 0xF0
00007d2ed8dd1d80  vmovaps [rsp], xmm0
00007d2ed8dd1d85  vmovaps [rsp+0x10], xmm1
00007d2ed8dd1d8b  vmovaps [rsp+0x20], xmm2
00007d2ed8dd1d91  vmovaps [rsp+0x30], xmm3
00007d2ed8dd1d97  vmovaps [rsp+0x40], xmm4
00007d2ed8dd1d9d  vmovaps [rsp+0x50], xmm5
00007d2ed8dd1da3  vmovaps [rsp+0x60], xmm6
00007d2ed8dd1da9  vmovaps [rsp+0x70], xmm7
00007d2ed8dd1daf  vmovaps [rsp+0x80], xmm8
00007d2ed8dd1db8  vmovaps [rsp+0x90], xmm9
00007d2ed8dd1dc1  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd1dca  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd1dd3  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd1ddc  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd1de5  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd1dee  sub rsp, 0x30
00007d2ed8dd1df2  movaps [rsp], xmm14
00007d2ed8dd1df7  movaps [rsp+0x10], xmm13
00007d2ed8dd1dfd  movaps [rsp+0x20], xmm2
00007d2ed8dd1e02  lea rdi, [rsp]
00007d2ed8dd1e06  mov esi, 0x00
00007d2ed8dd1e0b  mov rax, 0x648718324530
00007d2ed8dd1e15  call rax
00007d2ed8dd1e17  movaps xmm14, [rsp]
00007d2ed8dd1e1c  add rsp, 0x30
00007d2ed8dd1e20  vmovaps xmm0, [rsp]
00007d2ed8dd1e25  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd1e2b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd1e31  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd1e37  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd1e3d  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd1e43  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd1e49  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd1e4f  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd1e58  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd1e61  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd1e6a  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd1e73  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd1e7c  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd1e85  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd1e8e  add rsp, 0xF0
00007d2ed8dd1e95  pop r11
00007d2ed8dd1e97  pop r10
00007d2ed8dd1e99  pop r9
00007d2ed8dd1e9b  pop r8
00007d2ed8dd1e9d  pop rsi
00007d2ed8dd1e9e  pop rdi
00007d2ed8dd1e9f  pop rdx
00007d2ed8dd1ea0  pop rcx
00007d2ed8dd1ea1  pop rax
00007d2ed8dd1ea2  add rsp, 0x08
00007d2ed8dd1ea6  jmp 0x00007D2ED8DCFB24
00007d2ed8dd1eab  sub rsp, 0x08
00007d2ed8dd1eaf  push rax
00007d2ed8dd1eb0  push rcx
00007d2ed8dd1eb1  push rdx
00007d2ed8dd1eb2  push rdi
00007d2ed8dd1eb3  push rsi
00007d2ed8dd1eb4  push r8
00007d2ed8dd1eb6  push r9
00007d2ed8dd1eb8  push r10
00007d2ed8dd1eba  push r11
00007d2ed8dd1ebc  sub rsp, 0xF0
00007d2ed8dd1ec3  vmovaps [rsp], xmm0
00007d2ed8dd1ec8  vmovaps [rsp+0x10], xmm2
00007d2ed8dd1ece  vmovaps [rsp+0x20], xmm3
00007d2ed8dd1ed4  vmovaps [rsp+0x30], xmm4
00007d2ed8dd1eda  vmovaps [rsp+0x40], xmm5
00007d2ed8dd1ee0  vmovaps [rsp+0x50], xmm6
00007d2ed8dd1ee6  vmovaps [rsp+0x60], xmm7
00007d2ed8dd1eec  vmovaps [rsp+0x70], xmm8
00007d2ed8dd1ef2  vmovaps [rsp+0x80], xmm9
00007d2ed8dd1efb  vmovaps [rsp+0x90], xmm10
00007d2ed8dd1f04  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd1f0d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd1f16  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd1f1f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd1f28  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd1f31  sub rsp, 0x30
00007d2ed8dd1f35  movaps [rsp], xmm1
00007d2ed8dd1f39  movaps [rsp+0x10], xmm13
00007d2ed8dd1f3f  movaps [rsp+0x20], xmm2
00007d2ed8dd1f44  lea rdi, [rsp]
00007d2ed8dd1f48  mov esi, 0x00
00007d2ed8dd1f4d  mov rax, 0x648718324530
00007d2ed8dd1f57  call rax
00007d2ed8dd1f59  movaps xmm1, [rsp]
00007d2ed8dd1f5d  add rsp, 0x30
00007d2ed8dd1f61  vmovaps xmm0, [rsp]
00007d2ed8dd1f66  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd1f6c  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd1f72  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd1f78  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd1f7e  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd1f84  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd1f8a  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd1f90  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd1f99  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd1fa2  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd1fab  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd1fb4  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd1fbd  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd1fc6  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd1fcf  add rsp, 0xF0
00007d2ed8dd1fd6  pop r11
00007d2ed8dd1fd8  pop r10
00007d2ed8dd1fda  pop r9
00007d2ed8dd1fdc  pop r8
00007d2ed8dd1fde  pop rsi
00007d2ed8dd1fdf  pop rdi
00007d2ed8dd1fe0  pop rdx
00007d2ed8dd1fe1  pop rcx
00007d2ed8dd1fe2  pop rax
00007d2ed8dd1fe3  add rsp, 0x08
00007d2ed8dd1fe7  jmp 0x00007D2ED8DCFB52
00007d2ed8dd1fec  sub rsp, 0x08
00007d2ed8dd1ff0  push rax
00007d2ed8dd1ff1  push rcx
00007d2ed8dd1ff2  push rdx
00007d2ed8dd1ff3  push rdi
00007d2ed8dd1ff4  push rsi
00007d2ed8dd1ff5  push r8
00007d2ed8dd1ff7  push r9
00007d2ed8dd1ff9  push r10
00007d2ed8dd1ffb  push r11
00007d2ed8dd1ffd  sub rsp, 0xF0
00007d2ed8dd2004  vmovaps [rsp], xmm0
00007d2ed8dd2009  vmovaps [rsp+0x10], xmm1
00007d2ed8dd200f  vmovaps [rsp+0x20], xmm3
00007d2ed8dd2015  vmovaps [rsp+0x30], xmm4
00007d2ed8dd201b  vmovaps [rsp+0x40], xmm5
00007d2ed8dd2021  vmovaps [rsp+0x50], xmm6
00007d2ed8dd2027  vmovaps [rsp+0x60], xmm7
00007d2ed8dd202d  vmovaps [rsp+0x70], xmm8
00007d2ed8dd2033  vmovaps [rsp+0x80], xmm9
00007d2ed8dd203c  vmovaps [rsp+0x90], xmm10
00007d2ed8dd2045  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd204e  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd2057  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd2060  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd2069  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2072  sub rsp, 0x30
00007d2ed8dd2076  movaps [rsp], xmm2
00007d2ed8dd207a  movaps [rsp+0x10], xmm1
00007d2ed8dd207f  movaps [rsp+0x20], xmm13
00007d2ed8dd2085  lea rdi, [rsp]
00007d2ed8dd2089  mov esi, 0x00
00007d2ed8dd208e  mov rax, 0x648718324530
00007d2ed8dd2098  call rax
00007d2ed8dd209a  movaps xmm2, [rsp]
00007d2ed8dd209e  add rsp, 0x30
00007d2ed8dd20a2  vmovaps xmm0, [rsp]
00007d2ed8dd20a7  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd20ad  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd20b3  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd20b9  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd20bf  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd20c5  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd20cb  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd20d1  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd20da  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd20e3  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd20ec  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd20f5  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd20fe  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd2107  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd2110  add rsp, 0xF0
00007d2ed8dd2117  pop r11
00007d2ed8dd2119  pop r10
00007d2ed8dd211b  pop r9
00007d2ed8dd211d  pop r8
00007d2ed8dd211f  pop rsi
00007d2ed8dd2120  pop rdi
00007d2ed8dd2121  pop rdx
00007d2ed8dd2122  pop rcx
00007d2ed8dd2123  pop rax
00007d2ed8dd2124  add rsp, 0x08
00007d2ed8dd2128  jmp 0x00007D2ED8DCFBAB
00007d2ed8dd212d  call 0x00007D2ED8BFF430
00007d2ed8dd2132  jmp 0x00007D2ED8DCFBB8
00007d2ed8dd2137  sub rsp, 0x08
00007d2ed8dd213b  push rax
00007d2ed8dd213c  push rcx
00007d2ed8dd213d  push rdx
00007d2ed8dd213e  push rdi
00007d2ed8dd213f  push rsi
00007d2ed8dd2140  push r8
00007d2ed8dd2142  push r9
00007d2ed8dd2144  push r10
00007d2ed8dd2146  push r11
00007d2ed8dd2148  sub rsp, 0xF0
00007d2ed8dd214f  vmovaps [rsp], xmm0
00007d2ed8dd2154  vmovaps [rsp+0x10], xmm1
00007d2ed8dd215a  vmovaps [rsp+0x20], xmm2
00007d2ed8dd2160  vmovaps [rsp+0x30], xmm3
00007d2ed8dd2166  vmovaps [rsp+0x40], xmm4
00007d2ed8dd216c  vmovaps [rsp+0x50], xmm5
00007d2ed8dd2172  vmovaps [rsp+0x60], xmm6
00007d2ed8dd2178  vmovaps [rsp+0x70], xmm7
00007d2ed8dd217e  vmovaps [rsp+0x80], xmm8
00007d2ed8dd2187  vmovaps [rsp+0x90], xmm9
00007d2ed8dd2190  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd2199  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd21a2  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd21ab  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd21b4  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd21bd  sub rsp, 0x30
00007d2ed8dd21c1  movaps [rsp], xmm15
00007d2ed8dd21c6  movaps [rsp+0x10], xmm13
00007d2ed8dd21cc  movaps [rsp+0x20], xmm1
00007d2ed8dd21d1  lea rdi, [rsp]
00007d2ed8dd21d5  mov esi, 0x00
00007d2ed8dd21da  mov rax, 0x648718324530
00007d2ed8dd21e4  call rax
00007d2ed8dd21e6  movaps xmm15, [rsp]
00007d2ed8dd21eb  add rsp, 0x30
00007d2ed8dd21ef  vmovaps xmm0, [rsp]
00007d2ed8dd21f4  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd21fa  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd2200  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd2206  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd220c  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd2212  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd2218  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd221e  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd2227  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd2230  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd2239  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd2242  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd224b  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd2254  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd225d  add rsp, 0xF0
00007d2ed8dd2264  pop r11
00007d2ed8dd2266  pop r10
00007d2ed8dd2268  pop r9
00007d2ed8dd226a  pop r8
00007d2ed8dd226c  pop rsi
00007d2ed8dd226d  pop rdi
00007d2ed8dd226e  pop rdx
00007d2ed8dd226f  pop rcx
00007d2ed8dd2270  pop rax
00007d2ed8dd2271  add rsp, 0x08
00007d2ed8dd2275  jmp 0x00007D2ED8DCFBF7
00007d2ed8dd227a  sub rsp, 0x08
00007d2ed8dd227e  push rax
00007d2ed8dd227f  push rcx
00007d2ed8dd2280  push rdx
00007d2ed8dd2281  push rdi
00007d2ed8dd2282  push rsi
00007d2ed8dd2283  push r8
00007d2ed8dd2285  push r9
00007d2ed8dd2287  push r10
00007d2ed8dd2289  push r11
00007d2ed8dd228b  sub rsp, 0xF0
00007d2ed8dd2292  vmovaps [rsp], xmm0
00007d2ed8dd2297  vmovaps [rsp+0x10], xmm1
00007d2ed8dd229d  vmovaps [rsp+0x20], xmm2
00007d2ed8dd22a3  vmovaps [rsp+0x30], xmm3
00007d2ed8dd22a9  vmovaps [rsp+0x40], xmm4
00007d2ed8dd22af  vmovaps [rsp+0x50], xmm5
00007d2ed8dd22b5  vmovaps [rsp+0x60], xmm6
00007d2ed8dd22bb  vmovaps [rsp+0x70], xmm7
00007d2ed8dd22c1  vmovaps [rsp+0x80], xmm8
00007d2ed8dd22ca  vmovaps [rsp+0x90], xmm9
00007d2ed8dd22d3  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd22dc  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd22e5  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd22ee  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd22f7  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2300  sub rsp, 0x30
00007d2ed8dd2304  movaps [rsp], xmm14
00007d2ed8dd2309  movaps [rsp+0x10], xmm11
00007d2ed8dd230f  movaps [rsp+0x20], xmm1
00007d2ed8dd2314  lea rdi, [rsp]
00007d2ed8dd2318  mov esi, 0x00
00007d2ed8dd231d  mov rax, 0x648718324530
00007d2ed8dd2327  call rax
00007d2ed8dd2329  movaps xmm14, [rsp]
00007d2ed8dd232e  add rsp, 0x30
00007d2ed8dd2332  vmovaps xmm0, [rsp]
00007d2ed8dd2337  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd233d  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd2343  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd2349  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd234f  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd2355  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd235b  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd2361  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd236a  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd2373  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd237c  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd2385  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd238e  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd2397  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd23a0  add rsp, 0xF0
00007d2ed8dd23a7  pop r11
00007d2ed8dd23a9  pop r10
00007d2ed8dd23ab  pop r9
00007d2ed8dd23ad  pop r8
00007d2ed8dd23af  pop rsi
00007d2ed8dd23b0  pop rdi
00007d2ed8dd23b1  pop rdx
00007d2ed8dd23b2  pop rcx
00007d2ed8dd23b3  pop rax
00007d2ed8dd23b4  add rsp, 0x08
00007d2ed8dd23b8  jmp 0x00007D2ED8DCFC21
00007d2ed8dd23bd  sub rsp, 0x08
00007d2ed8dd23c1  push rax
00007d2ed8dd23c2  push rcx
00007d2ed8dd23c3  push rdx
00007d2ed8dd23c4  push rdi
00007d2ed8dd23c5  push rsi
00007d2ed8dd23c6  push r8
00007d2ed8dd23c8  push r9
00007d2ed8dd23ca  push r10
00007d2ed8dd23cc  push r11
00007d2ed8dd23ce  sub rsp, 0xF0
00007d2ed8dd23d5  vmovaps [rsp], xmm0
00007d2ed8dd23da  vmovaps [rsp+0x10], xmm1
00007d2ed8dd23e0  vmovaps [rsp+0x20], xmm2
00007d2ed8dd23e6  vmovaps [rsp+0x30], xmm3
00007d2ed8dd23ec  vmovaps [rsp+0x40], xmm4
00007d2ed8dd23f2  vmovaps [rsp+0x50], xmm5
00007d2ed8dd23f8  vmovaps [rsp+0x60], xmm6
00007d2ed8dd23fe  vmovaps [rsp+0x70], xmm7
00007d2ed8dd2404  vmovaps [rsp+0x80], xmm8
00007d2ed8dd240d  vmovaps [rsp+0x90], xmm9
00007d2ed8dd2416  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd241f  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd2428  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd2431  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd243a  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2443  sub rsp, 0x30
00007d2ed8dd2447  movaps [rsp], xmm13
00007d2ed8dd244c  movaps [rsp+0x10], xmm11
00007d2ed8dd2452  movaps [rsp+0x20], xmm1
00007d2ed8dd2457  lea rdi, [rsp]
00007d2ed8dd245b  mov esi, 0x00
00007d2ed8dd2460  mov rax, 0x648718324530
00007d2ed8dd246a  call rax
00007d2ed8dd246c  movaps xmm13, [rsp]
00007d2ed8dd2471  add rsp, 0x30
00007d2ed8dd2475  vmovaps xmm0, [rsp]
00007d2ed8dd247a  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd2480  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd2486  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd248c  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd2492  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd2498  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd249e  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd24a4  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd24ad  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd24b6  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd24bf  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd24c8  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd24d1  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd24da  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd24e3  add rsp, 0xF0
00007d2ed8dd24ea  pop r11
00007d2ed8dd24ec  pop r10
00007d2ed8dd24ee  pop r9
00007d2ed8dd24f0  pop r8
00007d2ed8dd24f2  pop rsi
00007d2ed8dd24f3  pop rdi
00007d2ed8dd24f4  pop rdx
00007d2ed8dd24f5  pop rcx
00007d2ed8dd24f6  pop rax
00007d2ed8dd24f7  add rsp, 0x08
00007d2ed8dd24fb  jmp 0x00007D2ED8DCFC76
00007d2ed8dd2500  call 0x00007D2ED8BFF430
00007d2ed8dd2505  jmp 0x00007D2ED8DCFC83
00007d2ed8dd250a  sub rsp, 0x08
00007d2ed8dd250e  push rax
00007d2ed8dd250f  push rcx
00007d2ed8dd2510  push rdx
00007d2ed8dd2511  push rdi
00007d2ed8dd2512  push rsi
00007d2ed8dd2513  push r8
00007d2ed8dd2515  push r9
00007d2ed8dd2517  push r10
00007d2ed8dd2519  push r11
00007d2ed8dd251b  sub rsp, 0xF0
00007d2ed8dd2522  vmovaps [rsp], xmm0
00007d2ed8dd2527  vmovaps [rsp+0x10], xmm1
00007d2ed8dd252d  vmovaps [rsp+0x20], xmm2
00007d2ed8dd2533  vmovaps [rsp+0x30], xmm3
00007d2ed8dd2539  vmovaps [rsp+0x40], xmm4
00007d2ed8dd253f  vmovaps [rsp+0x50], xmm5
00007d2ed8dd2545  vmovaps [rsp+0x60], xmm6
00007d2ed8dd254b  vmovaps [rsp+0x70], xmm7
00007d2ed8dd2551  vmovaps [rsp+0x80], xmm8
00007d2ed8dd255a  vmovaps [rsp+0x90], xmm9
00007d2ed8dd2563  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd256c  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd2575  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd257e  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd2587  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd2590  sub rsp, 0x30
00007d2ed8dd2594  movaps [rsp], xmm15
00007d2ed8dd2599  movaps [rsp+0x10], xmm11
00007d2ed8dd259f  movaps [rsp+0x20], xmm1
00007d2ed8dd25a4  lea rdi, [rsp]
00007d2ed8dd25a8  mov esi, 0x00
00007d2ed8dd25ad  mov rax, 0x648718324530
00007d2ed8dd25b7  call rax
00007d2ed8dd25b9  movaps xmm15, [rsp]
00007d2ed8dd25be  add rsp, 0x30
00007d2ed8dd25c2  vmovaps xmm0, [rsp]
00007d2ed8dd25c7  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd25cd  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd25d3  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd25d9  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd25df  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd25e5  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd25eb  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd25f1  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd25fa  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd2603  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd260c  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd2615  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd261e  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd2627  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd2630  add rsp, 0xF0
00007d2ed8dd2637  pop r11
00007d2ed8dd2639  pop r10
00007d2ed8dd263b  pop r9
00007d2ed8dd263d  pop r8
00007d2ed8dd263f  pop rsi
00007d2ed8dd2640  pop rdi
00007d2ed8dd2641  pop rdx
00007d2ed8dd2642  pop rcx
00007d2ed8dd2643  pop rax
00007d2ed8dd2644  add rsp, 0x08
00007d2ed8dd2648  jmp 0x00007D2ED8DCFCBC
00007d2ed8dd264d  sub rsp, 0x08
00007d2ed8dd2651  push rax
00007d2ed8dd2652  push rcx
00007d2ed8dd2653  push rdx
00007d2ed8dd2654  push rdi
00007d2ed8dd2655  push rsi
00007d2ed8dd2656  push r8
00007d2ed8dd2658  push r9
00007d2ed8dd265a  push r10
00007d2ed8dd265c  push r11
00007d2ed8dd265e  sub rsp, 0xF0
00007d2ed8dd2665  vmovaps [rsp], xmm0
00007d2ed8dd266a  vmovaps [rsp+0x10], xmm1
00007d2ed8dd2670  vmovaps [rsp+0x20], xmm2
00007d2ed8dd2676  vmovaps [rsp+0x30], xmm3
00007d2ed8dd267c  vmovaps [rsp+0x40], xmm4
00007d2ed8dd2682  vmovaps [rsp+0x50], xmm5
00007d2ed8dd2688  vmovaps [rsp+0x60], xmm6
00007d2ed8dd268e  vmovaps [rsp+0x70], xmm7
00007d2ed8dd2694  vmovaps [rsp+0x80], xmm8
00007d2ed8dd269d  vmovaps [rsp+0x90], xmm9
00007d2ed8dd26a6  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd26af  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd26b8  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd26c1  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd26ca  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd26d3  sub rsp, 0x30
00007d2ed8dd26d7  movaps [rsp], xmm11
00007d2ed8dd26dc  movaps [rsp+0x10], xmm6
00007d2ed8dd26e1  movaps [rsp+0x20], xmm14
00007d2ed8dd26e7  lea rdi, [rsp]
00007d2ed8dd26eb  mov esi, 0x00
00007d2ed8dd26f0  mov rax, 0x648718324530
00007d2ed8dd26fa  call rax
00007d2ed8dd26fc  movaps xmm11, [rsp]
00007d2ed8dd2701  add rsp, 0x30
00007d2ed8dd2705  vmovaps xmm0, [rsp]
00007d2ed8dd270a  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd2710  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd2716  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd271c  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd2722  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd2728  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd272e  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd2734  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd273d  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd2746  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd274f  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd2758  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd2761  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd276a  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd2773  add rsp, 0xF0
00007d2ed8dd277a  pop r11
00007d2ed8dd277c  pop r10
00007d2ed8dd277e  pop r9
00007d2ed8dd2780  pop r8
00007d2ed8dd2782  pop rsi
00007d2ed8dd2783  pop rdi
00007d2ed8dd2784  pop rdx
00007d2ed8dd2785  pop rcx
00007d2ed8dd2786  pop rax
00007d2ed8dd2787  add rsp, 0x08
00007d2ed8dd278b  jmp 0x00007D2ED8DCFD34
00007d2ed8dd2790  call 0x00007D2ED8BFF430
00007d2ed8dd2795  jmp 0x00007D2ED8DCFD3E
00007d2ed8dd279a  sub rsp, 0x08
00007d2ed8dd279e  push rax
00007d2ed8dd279f  push rcx
00007d2ed8dd27a0  push rdx
00007d2ed8dd27a1  push rdi
00007d2ed8dd27a2  push rsi
00007d2ed8dd27a3  push r8
00007d2ed8dd27a5  push r9
00007d2ed8dd27a7  push r10
00007d2ed8dd27a9  push r11
00007d2ed8dd27ab  sub rsp, 0xF0
00007d2ed8dd27b2  vmovaps [rsp], xmm0
00007d2ed8dd27b7  vmovaps [rsp+0x10], xmm1
00007d2ed8dd27bd  vmovaps [rsp+0x20], xmm2
00007d2ed8dd27c3  vmovaps [rsp+0x30], xmm3
00007d2ed8dd27c9  vmovaps [rsp+0x40], xmm4
00007d2ed8dd27cf  vmovaps [rsp+0x50], xmm5
00007d2ed8dd27d5  vmovaps [rsp+0x60], xmm6
00007d2ed8dd27db  vmovaps [rsp+0x70], xmm7
00007d2ed8dd27e1  vmovaps [rsp+0x80], xmm8
00007d2ed8dd27ea  vmovaps [rsp+0x90], xmm9
00007d2ed8dd27f3  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd27fc  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd2805  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd280e  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd2817  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2820  sub rsp, 0x30
00007d2ed8dd2824  movaps [rsp], xmm14
00007d2ed8dd2829  movaps [rsp+0x10], xmm6
00007d2ed8dd282e  movaps [rsp+0x20], xmm2
00007d2ed8dd2833  lea rdi, [rsp]
00007d2ed8dd2837  mov esi, 0x00
00007d2ed8dd283c  mov rax, 0x648718324530
00007d2ed8dd2846  call rax
00007d2ed8dd2848  movaps xmm14, [rsp]
00007d2ed8dd284d  add rsp, 0x30
00007d2ed8dd2851  vmovaps xmm0, [rsp]
00007d2ed8dd2856  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd285c  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd2862  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd2868  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd286e  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd2874  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd287a  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd2880  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd2889  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd2892  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd289b  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd28a4  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd28ad  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd28b6  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd28bf  add rsp, 0xF0
00007d2ed8dd28c6  pop r11
00007d2ed8dd28c8  pop r10
00007d2ed8dd28ca  pop r9
00007d2ed8dd28cc  pop r8
00007d2ed8dd28ce  pop rsi
00007d2ed8dd28cf  pop rdi
00007d2ed8dd28d0  pop rdx
00007d2ed8dd28d1  pop rcx
00007d2ed8dd28d2  pop rax
00007d2ed8dd28d3  add rsp, 0x08
00007d2ed8dd28d7  jmp 0x00007D2ED8DCFD72
00007d2ed8dd28dc  sub rsp, 0x08
00007d2ed8dd28e0  push rax
00007d2ed8dd28e1  push rcx
00007d2ed8dd28e2  push rdx
00007d2ed8dd28e3  push rdi
00007d2ed8dd28e4  push rsi
00007d2ed8dd28e5  push r8
00007d2ed8dd28e7  push r9
00007d2ed8dd28e9  push r10
00007d2ed8dd28eb  push r11
00007d2ed8dd28ed  sub rsp, 0xF0
00007d2ed8dd28f4  vmovaps [rsp], xmm0
00007d2ed8dd28f9  vmovaps [rsp+0x10], xmm1
00007d2ed8dd28ff  vmovaps [rsp+0x20], xmm2
00007d2ed8dd2905  vmovaps [rsp+0x30], xmm3
00007d2ed8dd290b  vmovaps [rsp+0x40], xmm4
00007d2ed8dd2911  vmovaps [rsp+0x50], xmm5
00007d2ed8dd2917  vmovaps [rsp+0x60], xmm7
00007d2ed8dd291d  vmovaps [rsp+0x70], xmm8
00007d2ed8dd2923  vmovaps [rsp+0x80], xmm9
00007d2ed8dd292c  vmovaps [rsp+0x90], xmm10
00007d2ed8dd2935  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd293e  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd2947  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd2950  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd2959  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2962  sub rsp, 0x30
00007d2ed8dd2966  movaps [rsp], xmm6
00007d2ed8dd296a  movaps [rsp+0x10], xmm5
00007d2ed8dd296f  movaps [rsp+0x20], xmm1
00007d2ed8dd2974  lea rdi, [rsp]
00007d2ed8dd2978  mov esi, 0x00
00007d2ed8dd297d  mov rax, 0x648718324530
00007d2ed8dd2987  call rax
00007d2ed8dd2989  movaps xmm6, [rsp]
00007d2ed8dd298d  add rsp, 0x30
00007d2ed8dd2991  vmovaps xmm0, [rsp]
00007d2ed8dd2996  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd299c  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd29a2  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd29a8  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd29ae  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd29b4  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd29ba  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd29c0  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd29c9  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd29d2  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd29db  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd29e4  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd29ed  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd29f6  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd29ff  add rsp, 0xF0
00007d2ed8dd2a06  pop r11
00007d2ed8dd2a08  pop r10
00007d2ed8dd2a0a  pop r9
00007d2ed8dd2a0c  pop r8
00007d2ed8dd2a0e  pop rsi
00007d2ed8dd2a0f  pop rdi
00007d2ed8dd2a10  pop rdx
00007d2ed8dd2a11  pop rcx
00007d2ed8dd2a12  pop rax
00007d2ed8dd2a13  add rsp, 0x08
00007d2ed8dd2a17  jmp 0x00007D2ED8DCFD98
00007d2ed8dd2a1c  sub rsp, 0x08
00007d2ed8dd2a20  push rax
00007d2ed8dd2a21  push rcx
00007d2ed8dd2a22  push rdx
00007d2ed8dd2a23  push rdi
00007d2ed8dd2a24  push rsi
00007d2ed8dd2a25  push r8
00007d2ed8dd2a27  push r9
00007d2ed8dd2a29  push r10
00007d2ed8dd2a2b  push r11
00007d2ed8dd2a2d  sub rsp, 0xF0
00007d2ed8dd2a34  vmovaps [rsp], xmm0
00007d2ed8dd2a39  vmovaps [rsp+0x10], xmm2
00007d2ed8dd2a3f  vmovaps [rsp+0x20], xmm3
00007d2ed8dd2a45  vmovaps [rsp+0x30], xmm4
00007d2ed8dd2a4b  vmovaps [rsp+0x40], xmm5
00007d2ed8dd2a51  vmovaps [rsp+0x50], xmm6
00007d2ed8dd2a57  vmovaps [rsp+0x60], xmm7
00007d2ed8dd2a5d  vmovaps [rsp+0x70], xmm8
00007d2ed8dd2a63  vmovaps [rsp+0x80], xmm9
00007d2ed8dd2a6c  vmovaps [rsp+0x90], xmm10
00007d2ed8dd2a75  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd2a7e  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd2a87  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd2a90  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd2a99  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2aa2  sub rsp, 0x30
00007d2ed8dd2aa6  movaps [rsp], xmm1
00007d2ed8dd2aaa  movaps [rsp+0x10], xmm5
00007d2ed8dd2aaf  movaps [rsp+0x20], xmm13
00007d2ed8dd2ab5  lea rdi, [rsp]
00007d2ed8dd2ab9  mov esi, 0x00
00007d2ed8dd2abe  mov rax, 0x648718324530
00007d2ed8dd2ac8  call rax
00007d2ed8dd2aca  movaps xmm1, [rsp]
00007d2ed8dd2ace  add rsp, 0x30
00007d2ed8dd2ad2  vmovaps xmm0, [rsp]
00007d2ed8dd2ad7  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd2add  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd2ae3  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd2ae9  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd2aef  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd2af5  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd2afb  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd2b01  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd2b0a  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd2b13  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd2b1c  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd2b25  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd2b2e  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd2b37  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd2b40  add rsp, 0xF0
00007d2ed8dd2b47  pop r11
00007d2ed8dd2b49  pop r10
00007d2ed8dd2b4b  pop r9
00007d2ed8dd2b4d  pop r8
00007d2ed8dd2b4f  pop rsi
00007d2ed8dd2b50  pop rdi
00007d2ed8dd2b51  pop rdx
00007d2ed8dd2b52  pop rcx
00007d2ed8dd2b53  pop rax
00007d2ed8dd2b54  add rsp, 0x08
00007d2ed8dd2b58  jmp 0x00007D2ED8DCFDB6
00007d2ed8dd2b5d  sub rsp, 0x08
00007d2ed8dd2b61  push rax
00007d2ed8dd2b62  push rcx
00007d2ed8dd2b63  push rdx
00007d2ed8dd2b64  push rdi
00007d2ed8dd2b65  push rsi
00007d2ed8dd2b66  push r8
00007d2ed8dd2b68  push r9
00007d2ed8dd2b6a  push r10
00007d2ed8dd2b6c  push r11
00007d2ed8dd2b6e  sub rsp, 0xF0
00007d2ed8dd2b75  vmovaps [rsp], xmm0
00007d2ed8dd2b7a  vmovaps [rsp+0x10], xmm1
00007d2ed8dd2b80  vmovaps [rsp+0x20], xmm2
00007d2ed8dd2b86  vmovaps [rsp+0x30], xmm3
00007d2ed8dd2b8c  vmovaps [rsp+0x40], xmm4
00007d2ed8dd2b92  vmovaps [rsp+0x50], xmm6
00007d2ed8dd2b98  vmovaps [rsp+0x60], xmm7
00007d2ed8dd2b9e  vmovaps [rsp+0x70], xmm8
00007d2ed8dd2ba4  vmovaps [rsp+0x80], xmm9
00007d2ed8dd2bad  vmovaps [rsp+0x90], xmm10
00007d2ed8dd2bb6  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd2bbf  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd2bc8  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd2bd1  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd2bda  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2be3  sub rsp, 0x30
00007d2ed8dd2be7  movaps [rsp], xmm5
00007d2ed8dd2beb  movaps [rsp+0x10], xmm2
00007d2ed8dd2bf0  movaps [rsp+0x20], xmm13
00007d2ed8dd2bf6  lea rdi, [rsp]
00007d2ed8dd2bfa  mov esi, 0x00
00007d2ed8dd2bff  mov rax, 0x648718324530
00007d2ed8dd2c09  call rax
00007d2ed8dd2c0b  movaps xmm5, [rsp]
00007d2ed8dd2c0f  add rsp, 0x30
00007d2ed8dd2c13  vmovaps xmm0, [rsp]
00007d2ed8dd2c18  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd2c1e  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd2c24  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd2c2a  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd2c30  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd2c36  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd2c3c  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd2c42  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd2c4b  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd2c54  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd2c5d  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd2c66  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd2c6f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd2c78  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd2c81  add rsp, 0xF0
00007d2ed8dd2c88  pop r11
00007d2ed8dd2c8a  pop r10
00007d2ed8dd2c8c  pop r9
00007d2ed8dd2c8e  pop r8
00007d2ed8dd2c90  pop rsi
00007d2ed8dd2c91  pop rdi
00007d2ed8dd2c92  pop rdx
00007d2ed8dd2c93  pop rcx
00007d2ed8dd2c94  pop rax
00007d2ed8dd2c95  add rsp, 0x08
00007d2ed8dd2c99  jmp 0x00007D2ED8DCFDEC
00007d2ed8dd2c9e  sub rsp, 0x08
00007d2ed8dd2ca2  push rax
00007d2ed8dd2ca3  push rcx
00007d2ed8dd2ca4  push rdx
00007d2ed8dd2ca5  push rdi
00007d2ed8dd2ca6  push rsi
00007d2ed8dd2ca7  push r8
00007d2ed8dd2ca9  push r9
00007d2ed8dd2cab  push r10
00007d2ed8dd2cad  push r11
00007d2ed8dd2caf  sub rsp, 0xF0
00007d2ed8dd2cb6  vmovaps [rsp], xmm0
00007d2ed8dd2cbb  vmovaps [rsp+0x10], xmm1
00007d2ed8dd2cc1  vmovaps [rsp+0x20], xmm2
00007d2ed8dd2cc7  vmovaps [rsp+0x30], xmm3
00007d2ed8dd2ccd  vmovaps [rsp+0x40], xmm4
00007d2ed8dd2cd3  vmovaps [rsp+0x50], xmm5
00007d2ed8dd2cd9  vmovaps [rsp+0x60], xmm6
00007d2ed8dd2cdf  vmovaps [rsp+0x70], xmm7
00007d2ed8dd2ce5  vmovaps [rsp+0x80], xmm8
00007d2ed8dd2cee  vmovaps [rsp+0x90], xmm9
00007d2ed8dd2cf7  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd2d00  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd2d09  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd2d12  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd2d1b  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2d24  sub rsp, 0x30
00007d2ed8dd2d28  movaps [rsp], xmm13
00007d2ed8dd2d2d  movaps [rsp+0x10], xmm10
00007d2ed8dd2d33  movaps [rsp+0x20], xmm1
00007d2ed8dd2d38  lea rdi, [rsp]
00007d2ed8dd2d3c  mov esi, 0x00
00007d2ed8dd2d41  mov rax, 0x648718324530
00007d2ed8dd2d4b  call rax
00007d2ed8dd2d4d  movaps xmm13, [rsp]
00007d2ed8dd2d52  add rsp, 0x30
00007d2ed8dd2d56  vmovaps xmm0, [rsp]
00007d2ed8dd2d5b  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd2d61  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd2d67  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd2d6d  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd2d73  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd2d79  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd2d7f  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd2d85  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd2d8e  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd2d97  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd2da0  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd2da9  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd2db2  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd2dbb  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd2dc4  add rsp, 0xF0
00007d2ed8dd2dcb  pop r11
00007d2ed8dd2dcd  pop r10
00007d2ed8dd2dcf  pop r9
00007d2ed8dd2dd1  pop r8
00007d2ed8dd2dd3  pop rsi
00007d2ed8dd2dd4  pop rdi
00007d2ed8dd2dd5  pop rdx
00007d2ed8dd2dd6  pop rcx
00007d2ed8dd2dd7  pop rax
00007d2ed8dd2dd8  add rsp, 0x08
00007d2ed8dd2ddc  jmp 0x00007D2ED8DCFE15
00007d2ed8dd2de1  sub rsp, 0x08
00007d2ed8dd2de5  push rax
00007d2ed8dd2de6  push rcx
00007d2ed8dd2de7  push rdx
00007d2ed8dd2de8  push rdi
00007d2ed8dd2de9  push rsi
00007d2ed8dd2dea  push r8
00007d2ed8dd2dec  push r9
00007d2ed8dd2dee  push r10
00007d2ed8dd2df0  push r11
00007d2ed8dd2df2  sub rsp, 0xF0
00007d2ed8dd2df9  vmovaps [rsp], xmm0
00007d2ed8dd2dfe  vmovaps [rsp+0x10], xmm2
00007d2ed8dd2e04  vmovaps [rsp+0x20], xmm3
00007d2ed8dd2e0a  vmovaps [rsp+0x30], xmm4
00007d2ed8dd2e10  vmovaps [rsp+0x40], xmm5
00007d2ed8dd2e16  vmovaps [rsp+0x50], xmm6
00007d2ed8dd2e1c  vmovaps [rsp+0x60], xmm7
00007d2ed8dd2e22  vmovaps [rsp+0x70], xmm8
00007d2ed8dd2e28  vmovaps [rsp+0x80], xmm9
00007d2ed8dd2e31  vmovaps [rsp+0x90], xmm10
00007d2ed8dd2e3a  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd2e43  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd2e4c  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd2e55  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd2e5e  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd2e67  sub rsp, 0x30
00007d2ed8dd2e6b  movaps [rsp], xmm1
00007d2ed8dd2e6f  movaps [rsp+0x10], xmm15
00007d2ed8dd2e75  movaps [rsp+0x20], xmm10
00007d2ed8dd2e7b  lea rdi, [rsp]
00007d2ed8dd2e7f  mov esi, 0x00
00007d2ed8dd2e84  mov rax, 0x648718324530
00007d2ed8dd2e8e  call rax
00007d2ed8dd2e90  movaps xmm1, [rsp]
00007d2ed8dd2e94  add rsp, 0x30
00007d2ed8dd2e98  vmovaps xmm0, [rsp]
00007d2ed8dd2e9d  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd2ea3  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd2ea9  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd2eaf  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd2eb5  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd2ebb  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd2ec1  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd2ec7  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd2ed0  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd2ed9  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd2ee2  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd2eeb  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd2ef4  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd2efd  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd2f06  add rsp, 0xF0
00007d2ed8dd2f0d  pop r11
00007d2ed8dd2f0f  pop r10
00007d2ed8dd2f11  pop r9
00007d2ed8dd2f13  pop r8
00007d2ed8dd2f15  pop rsi
00007d2ed8dd2f16  pop rdi
00007d2ed8dd2f17  pop rdx
00007d2ed8dd2f18  pop rcx
00007d2ed8dd2f19  pop rax
00007d2ed8dd2f1a  add rsp, 0x08
00007d2ed8dd2f1e  jmp 0x00007D2ED8DCFE34
00007d2ed8dd2f23  sub rsp, 0x08
00007d2ed8dd2f27  push rax
00007d2ed8dd2f28  push rcx
00007d2ed8dd2f29  push rdx
00007d2ed8dd2f2a  push rdi
00007d2ed8dd2f2b  push rsi
00007d2ed8dd2f2c  push r8
00007d2ed8dd2f2e  push r9
00007d2ed8dd2f30  push r10
00007d2ed8dd2f32  push r11
00007d2ed8dd2f34  sub rsp, 0xF0
00007d2ed8dd2f3b  vmovaps [rsp], xmm0
00007d2ed8dd2f40  vmovaps [rsp+0x10], xmm1
00007d2ed8dd2f46  vmovaps [rsp+0x20], xmm2
00007d2ed8dd2f4c  vmovaps [rsp+0x30], xmm3
00007d2ed8dd2f52  vmovaps [rsp+0x40], xmm4
00007d2ed8dd2f58  vmovaps [rsp+0x50], xmm5
00007d2ed8dd2f5e  vmovaps [rsp+0x60], xmm6
00007d2ed8dd2f64  vmovaps [rsp+0x70], xmm7
00007d2ed8dd2f6a  vmovaps [rsp+0x80], xmm8
00007d2ed8dd2f73  vmovaps [rsp+0x90], xmm9
00007d2ed8dd2f7c  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd2f85  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd2f8e  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd2f97  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd2fa0  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd2fa9  sub rsp, 0x30
00007d2ed8dd2fad  movaps [rsp], xmm15
00007d2ed8dd2fb2  movaps [rsp+0x10], xmm10
00007d2ed8dd2fb8  movaps [rsp+0x20], xmm11
00007d2ed8dd2fbe  lea rdi, [rsp]
00007d2ed8dd2fc2  mov esi, 0x00
00007d2ed8dd2fc7  mov rax, 0x648718324530
00007d2ed8dd2fd1  call rax
00007d2ed8dd2fd3  movaps xmm15, [rsp]
00007d2ed8dd2fd8  add rsp, 0x30
00007d2ed8dd2fdc  vmovaps xmm0, [rsp]
00007d2ed8dd2fe1  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd2fe7  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd2fed  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd2ff3  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd2ff9  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd2fff  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd3005  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd300b  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd3014  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd301d  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd3026  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd302f  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd3038  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd3041  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd304a  add rsp, 0xF0
00007d2ed8dd3051  pop r11
00007d2ed8dd3053  pop r10
00007d2ed8dd3055  pop r9
00007d2ed8dd3057  pop r8
00007d2ed8dd3059  pop rsi
00007d2ed8dd305a  pop rdi
00007d2ed8dd305b  pop rdx
00007d2ed8dd305c  pop rcx
00007d2ed8dd305d  pop rax
00007d2ed8dd305e  add rsp, 0x08
00007d2ed8dd3062  jmp 0x00007D2ED8DCFE57
00007d2ed8dd3067  sub rsp, 0x08
00007d2ed8dd306b  push rax
00007d2ed8dd306c  push rcx
00007d2ed8dd306d  push rdx
00007d2ed8dd306e  push rdi
00007d2ed8dd306f  push rsi
00007d2ed8dd3070  push r8
00007d2ed8dd3072  push r9
00007d2ed8dd3074  push r10
00007d2ed8dd3076  push r11
00007d2ed8dd3078  sub rsp, 0xF0
00007d2ed8dd307f  vmovaps [rsp], xmm0
00007d2ed8dd3084  vmovaps [rsp+0x10], xmm1
00007d2ed8dd308a  vmovaps [rsp+0x20], xmm2
00007d2ed8dd3090  vmovaps [rsp+0x30], xmm3
00007d2ed8dd3096  vmovaps [rsp+0x40], xmm4
00007d2ed8dd309c  vmovaps [rsp+0x50], xmm5
00007d2ed8dd30a2  vmovaps [rsp+0x60], xmm6
00007d2ed8dd30a8  vmovaps [rsp+0x70], xmm7
00007d2ed8dd30ae  vmovaps [rsp+0x80], xmm8
00007d2ed8dd30b7  vmovaps [rsp+0x90], xmm9
00007d2ed8dd30c0  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd30c9  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd30d2  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd30db  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd30e4  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd30ed  sub rsp, 0x30
00007d2ed8dd30f1  movaps [rsp], xmm10
00007d2ed8dd30f6  movaps [rsp+0x10], xmm12
00007d2ed8dd30fc  movaps [rsp+0x20], xmm11
00007d2ed8dd3102  lea rdi, [rsp]
00007d2ed8dd3106  mov esi, 0x00
00007d2ed8dd310b  mov rax, 0x648718324530
00007d2ed8dd3115  call rax
00007d2ed8dd3117  movaps xmm10, [rsp]
00007d2ed8dd311c  add rsp, 0x30
00007d2ed8dd3120  vmovaps xmm0, [rsp]
00007d2ed8dd3125  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd312b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd3131  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd3137  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd313d  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd3143  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd3149  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd314f  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd3158  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd3161  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd316a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd3173  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd317c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd3185  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd318e  add rsp, 0xF0
00007d2ed8dd3195  pop r11
00007d2ed8dd3197  pop r10
00007d2ed8dd3199  pop r9
00007d2ed8dd319b  pop r8
00007d2ed8dd319d  pop rsi
00007d2ed8dd319e  pop rdi
00007d2ed8dd319f  pop rdx
00007d2ed8dd31a0  pop rcx
00007d2ed8dd31a1  pop rax
00007d2ed8dd31a2  add rsp, 0x08
00007d2ed8dd31a6  jmp 0x00007D2ED8DCFE80
00007d2ed8dd31ab  sub rsp, 0x08
00007d2ed8dd31af  push rax
00007d2ed8dd31b0  push rcx
00007d2ed8dd31b1  push rdx
00007d2ed8dd31b2  push rdi
00007d2ed8dd31b3  push rsi
00007d2ed8dd31b4  push r8
00007d2ed8dd31b6  push r9
00007d2ed8dd31b8  push r10
00007d2ed8dd31ba  push r11
00007d2ed8dd31bc  sub rsp, 0xF0
00007d2ed8dd31c3  vmovaps [rsp], xmm0
00007d2ed8dd31c8  vmovaps [rsp+0x10], xmm1
00007d2ed8dd31ce  vmovaps [rsp+0x20], xmm2
00007d2ed8dd31d4  vmovaps [rsp+0x30], xmm3
00007d2ed8dd31da  vmovaps [rsp+0x40], xmm4
00007d2ed8dd31e0  vmovaps [rsp+0x50], xmm5
00007d2ed8dd31e6  vmovaps [rsp+0x60], xmm6
00007d2ed8dd31ec  vmovaps [rsp+0x70], xmm7
00007d2ed8dd31f2  vmovaps [rsp+0x80], xmm8
00007d2ed8dd31fb  vmovaps [rsp+0x90], xmm9
00007d2ed8dd3204  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd320d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd3216  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd321f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd3228  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd3231  sub rsp, 0x30
00007d2ed8dd3235  movaps [rsp], xmm11
00007d2ed8dd323a  movaps [rsp+0x10], xmm2
00007d2ed8dd323f  movaps [rsp+0x20], xmm12
00007d2ed8dd3245  lea rdi, [rsp]
00007d2ed8dd3249  mov esi, 0x00
00007d2ed8dd324e  mov rax, 0x648718324530
00007d2ed8dd3258  call rax
00007d2ed8dd325a  movaps xmm11, [rsp]
00007d2ed8dd325f  add rsp, 0x30
00007d2ed8dd3263  vmovaps xmm0, [rsp]
00007d2ed8dd3268  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd326e  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd3274  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd327a  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd3280  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd3286  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd328c  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd3292  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd329b  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd32a4  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd32ad  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd32b6  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd32bf  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd32c8  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd32d1  add rsp, 0xF0
00007d2ed8dd32d8  pop r11
00007d2ed8dd32da  pop r10
00007d2ed8dd32dc  pop r9
00007d2ed8dd32de  pop r8
00007d2ed8dd32e0  pop rsi
00007d2ed8dd32e1  pop rdi
00007d2ed8dd32e2  pop rdx
00007d2ed8dd32e3  pop rcx
00007d2ed8dd32e4  pop rax
00007d2ed8dd32e5  add rsp, 0x08
00007d2ed8dd32e9  jmp 0x00007D2ED8DCFEB8
00007d2ed8dd32ee  sub rsp, 0x08
00007d2ed8dd32f2  push rax
00007d2ed8dd32f3  push rcx
00007d2ed8dd32f4  push rdx
00007d2ed8dd32f5  push rdi
00007d2ed8dd32f6  push rsi
00007d2ed8dd32f7  push r8
00007d2ed8dd32f9  push r9
00007d2ed8dd32fb  push r10
00007d2ed8dd32fd  push r11
00007d2ed8dd32ff  sub rsp, 0xF0
00007d2ed8dd3306  vmovaps [rsp], xmm0
00007d2ed8dd330b  vmovaps [rsp+0x10], xmm2
00007d2ed8dd3311  vmovaps [rsp+0x20], xmm3
00007d2ed8dd3317  vmovaps [rsp+0x30], xmm4
00007d2ed8dd331d  vmovaps [rsp+0x40], xmm5
00007d2ed8dd3323  vmovaps [rsp+0x50], xmm6
00007d2ed8dd3329  vmovaps [rsp+0x60], xmm7
00007d2ed8dd332f  vmovaps [rsp+0x70], xmm8
00007d2ed8dd3335  vmovaps [rsp+0x80], xmm9
00007d2ed8dd333e  vmovaps [rsp+0x90], xmm10
00007d2ed8dd3347  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd3350  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd3359  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd3362  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd336b  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd3374  sub rsp, 0x30
00007d2ed8dd3378  movaps [rsp], xmm1
00007d2ed8dd337c  movaps [rsp+0x10], xmm14
00007d2ed8dd3382  movaps [rsp+0x20], xmm6
00007d2ed8dd3387  lea rdi, [rsp]
00007d2ed8dd338b  mov esi, 0x00
00007d2ed8dd3390  mov rax, 0x648718324530
00007d2ed8dd339a  call rax
00007d2ed8dd339c  movaps xmm1, [rsp]
00007d2ed8dd33a0  add rsp, 0x30
00007d2ed8dd33a4  vmovaps xmm0, [rsp]
00007d2ed8dd33a9  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd33af  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd33b5  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd33bb  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd33c1  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd33c7  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd33cd  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd33d3  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd33dc  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd33e5  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd33ee  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd33f7  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd3400  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd3409  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd3412  add rsp, 0xF0
00007d2ed8dd3419  pop r11
00007d2ed8dd341b  pop r10
00007d2ed8dd341d  pop r9
00007d2ed8dd341f  pop r8
00007d2ed8dd3421  pop rsi
00007d2ed8dd3422  pop rdi
00007d2ed8dd3423  pop rdx
00007d2ed8dd3424  pop rcx
00007d2ed8dd3425  pop rax
00007d2ed8dd3426  add rsp, 0x08
00007d2ed8dd342a  jmp 0x00007D2ED8DCFED1
00007d2ed8dd342f  sub rsp, 0x08
00007d2ed8dd3433  push rax
00007d2ed8dd3434  push rcx
00007d2ed8dd3435  push rdx
00007d2ed8dd3436  push rdi
00007d2ed8dd3437  push rsi
00007d2ed8dd3438  push r8
00007d2ed8dd343a  push r9
00007d2ed8dd343c  push r10
00007d2ed8dd343e  push r11
00007d2ed8dd3440  sub rsp, 0xF0
00007d2ed8dd3447  vmovaps [rsp], xmm0
00007d2ed8dd344c  vmovaps [rsp+0x10], xmm1
00007d2ed8dd3452  vmovaps [rsp+0x20], xmm2
00007d2ed8dd3458  vmovaps [rsp+0x30], xmm3
00007d2ed8dd345e  vmovaps [rsp+0x40], xmm4
00007d2ed8dd3464  vmovaps [rsp+0x50], xmm5
00007d2ed8dd346a  vmovaps [rsp+0x60], xmm6
00007d2ed8dd3470  vmovaps [rsp+0x70], xmm7
00007d2ed8dd3476  vmovaps [rsp+0x80], xmm8
00007d2ed8dd347f  vmovaps [rsp+0x90], xmm9
00007d2ed8dd3488  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd3491  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd349a  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd34a3  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd34ac  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd34b5  sub rsp, 0x30
00007d2ed8dd34b9  movaps [rsp], xmm14
00007d2ed8dd34be  movaps [rsp+0x10], xmm12
00007d2ed8dd34c4  movaps [rsp+0x20], xmm5
00007d2ed8dd34c9  lea rdi, [rsp]
00007d2ed8dd34cd  mov esi, 0x00
00007d2ed8dd34d2  mov rax, 0x648718324530
00007d2ed8dd34dc  call rax
00007d2ed8dd34de  movaps xmm14, [rsp]
00007d2ed8dd34e3  add rsp, 0x30
00007d2ed8dd34e7  vmovaps xmm0, [rsp]
00007d2ed8dd34ec  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd34f2  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd34f8  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd34fe  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd3504  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd350a  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd3510  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd3516  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd351f  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd3528  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd3531  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd353a  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd3543  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd354c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd3555  add rsp, 0xF0
00007d2ed8dd355c  pop r11
00007d2ed8dd355e  pop r10
00007d2ed8dd3560  pop r9
00007d2ed8dd3562  pop r8
00007d2ed8dd3564  pop rsi
00007d2ed8dd3565  pop rdi
00007d2ed8dd3566  pop rdx
00007d2ed8dd3567  pop rcx
00007d2ed8dd3568  pop rax
00007d2ed8dd3569  add rsp, 0x08
00007d2ed8dd356d  jmp 0x00007D2ED8DCFEF1
00007d2ed8dd3572  sub rsp, 0x08
00007d2ed8dd3576  push rax
00007d2ed8dd3577  push rcx
00007d2ed8dd3578  push rdx
00007d2ed8dd3579  push rdi
00007d2ed8dd357a  push rsi
00007d2ed8dd357b  push r8
00007d2ed8dd357d  push r9
00007d2ed8dd357f  push r10
00007d2ed8dd3581  push r11
00007d2ed8dd3583  sub rsp, 0xF0
00007d2ed8dd358a  vmovaps [rsp], xmm0
00007d2ed8dd358f  vmovaps [rsp+0x10], xmm1
00007d2ed8dd3595  vmovaps [rsp+0x20], xmm2
00007d2ed8dd359b  vmovaps [rsp+0x30], xmm3
00007d2ed8dd35a1  vmovaps [rsp+0x40], xmm4
00007d2ed8dd35a7  vmovaps [rsp+0x50], xmm5
00007d2ed8dd35ad  vmovaps [rsp+0x60], xmm7
00007d2ed8dd35b3  vmovaps [rsp+0x70], xmm8
00007d2ed8dd35b9  vmovaps [rsp+0x80], xmm9
00007d2ed8dd35c2  vmovaps [rsp+0x90], xmm10
00007d2ed8dd35cb  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd35d4  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd35dd  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd35e6  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd35ef  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd35f8  sub rsp, 0x30
00007d2ed8dd35fc  movaps [rsp], xmm6
00007d2ed8dd3600  movaps [rsp+0x10], xmm9
00007d2ed8dd3606  movaps [rsp+0x20], xmm12
00007d2ed8dd360c  lea rdi, [rsp]
00007d2ed8dd3610  mov esi, 0x00
00007d2ed8dd3615  mov rax, 0x648718324530
00007d2ed8dd361f  call rax
00007d2ed8dd3621  movaps xmm6, [rsp]
00007d2ed8dd3625  add rsp, 0x30
00007d2ed8dd3629  vmovaps xmm0, [rsp]
00007d2ed8dd362e  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd3634  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd363a  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd3640  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd3646  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd364c  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd3652  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd3658  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd3661  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd366a  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd3673  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd367c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd3685  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd368e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd3697  add rsp, 0xF0
00007d2ed8dd369e  pop r11
00007d2ed8dd36a0  pop r10
00007d2ed8dd36a2  pop r9
00007d2ed8dd36a4  pop r8
00007d2ed8dd36a6  pop rsi
00007d2ed8dd36a7  pop rdi
00007d2ed8dd36a8  pop rdx
00007d2ed8dd36a9  pop rcx
00007d2ed8dd36aa  pop rax
00007d2ed8dd36ab  add rsp, 0x08
00007d2ed8dd36af  jmp 0x00007D2ED8DCFF19
00007d2ed8dd36b4  sub rsp, 0x08
00007d2ed8dd36b8  push rax
00007d2ed8dd36b9  push rcx
00007d2ed8dd36ba  push rdx
00007d2ed8dd36bb  push rdi
00007d2ed8dd36bc  push rsi
00007d2ed8dd36bd  push r8
00007d2ed8dd36bf  push r9
00007d2ed8dd36c1  push r10
00007d2ed8dd36c3  push r11
00007d2ed8dd36c5  sub rsp, 0xF0
00007d2ed8dd36cc  vmovaps [rsp], xmm0
00007d2ed8dd36d1  vmovaps [rsp+0x10], xmm1
00007d2ed8dd36d7  vmovaps [rsp+0x20], xmm2
00007d2ed8dd36dd  vmovaps [rsp+0x30], xmm3
00007d2ed8dd36e3  vmovaps [rsp+0x40], xmm4
00007d2ed8dd36e9  vmovaps [rsp+0x50], xmm5
00007d2ed8dd36ef  vmovaps [rsp+0x60], xmm6
00007d2ed8dd36f5  vmovaps [rsp+0x70], xmm7
00007d2ed8dd36fb  vmovaps [rsp+0x80], xmm8
00007d2ed8dd3704  vmovaps [rsp+0x90], xmm9
00007d2ed8dd370d  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd3716  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd371f  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd3728  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd3731  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd373a  sub rsp, 0x30
00007d2ed8dd373e  movaps [rsp], xmm12
00007d2ed8dd3743  movaps [rsp+0x10], xmm15
00007d2ed8dd3749  movaps [rsp+0x20], xmm13
00007d2ed8dd374f  lea rdi, [rsp]
00007d2ed8dd3753  mov esi, 0x00
00007d2ed8dd3758  mov rax, 0x648718324530
00007d2ed8dd3762  call rax
00007d2ed8dd3764  movaps xmm12, [rsp]
00007d2ed8dd3769  add rsp, 0x30
00007d2ed8dd376d  vmovaps xmm0, [rsp]
00007d2ed8dd3772  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd3778  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd377e  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd3784  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd378a  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd3790  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd3796  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd379c  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd37a5  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd37ae  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd37b7  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd37c0  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd37c9  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd37d2  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd37db  add rsp, 0xF0
00007d2ed8dd37e2  pop r11
00007d2ed8dd37e4  pop r10
00007d2ed8dd37e6  pop r9
00007d2ed8dd37e8  pop r8
00007d2ed8dd37ea  pop rsi
00007d2ed8dd37eb  pop rdi
00007d2ed8dd37ec  pop rdx
00007d2ed8dd37ed  pop rcx
00007d2ed8dd37ee  pop rax
00007d2ed8dd37ef  add rsp, 0x08
00007d2ed8dd37f3  jmp 0x00007D2ED8DCFF34
00007d2ed8dd37f8  sub rsp, 0x08
00007d2ed8dd37fc  push rax
00007d2ed8dd37fd  push rcx
00007d2ed8dd37fe  push rdx
00007d2ed8dd37ff  push rdi
00007d2ed8dd3800  push rsi
00007d2ed8dd3801  push r8
00007d2ed8dd3803  push r9
00007d2ed8dd3805  push r10
00007d2ed8dd3807  push r11
00007d2ed8dd3809  sub rsp, 0xF0
00007d2ed8dd3810  vmovaps [rsp], xmm0
00007d2ed8dd3815  vmovaps [rsp+0x10], xmm1
00007d2ed8dd381b  vmovaps [rsp+0x20], xmm2
00007d2ed8dd3821  vmovaps [rsp+0x30], xmm3
00007d2ed8dd3827  vmovaps [rsp+0x40], xmm4
00007d2ed8dd382d  vmovaps [rsp+0x50], xmm5
00007d2ed8dd3833  vmovaps [rsp+0x60], xmm6
00007d2ed8dd3839  vmovaps [rsp+0x70], xmm7
00007d2ed8dd383f  vmovaps [rsp+0x80], xmm8
00007d2ed8dd3848  vmovaps [rsp+0x90], xmm9
00007d2ed8dd3851  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd385a  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd3863  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd386c  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd3875  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd387e  sub rsp, 0x30
00007d2ed8dd3882  movaps [rsp], xmm15
00007d2ed8dd3887  movaps [rsp+0x10], xmm13
00007d2ed8dd388d  movaps [rsp+0x20], xmm10
00007d2ed8dd3893  lea rdi, [rsp]
00007d2ed8dd3897  mov esi, 0x00
00007d2ed8dd389c  mov rax, 0x648718324530
00007d2ed8dd38a6  call rax
00007d2ed8dd38a8  movaps xmm15, [rsp]
00007d2ed8dd38ad  add rsp, 0x30
00007d2ed8dd38b1  vmovaps xmm0, [rsp]
00007d2ed8dd38b6  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd38bc  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd38c2  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd38c8  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd38ce  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd38d4  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd38da  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd38e0  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd38e9  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd38f2  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd38fb  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd3904  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd390d  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd3916  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd391f  add rsp, 0xF0
00007d2ed8dd3926  pop r11
00007d2ed8dd3928  pop r10
00007d2ed8dd392a  pop r9
00007d2ed8dd392c  pop r8
00007d2ed8dd392e  pop rsi
00007d2ed8dd392f  pop rdi
00007d2ed8dd3930  pop rdx
00007d2ed8dd3931  pop rcx
00007d2ed8dd3932  pop rax
00007d2ed8dd3933  add rsp, 0x08
00007d2ed8dd3937  jmp 0x00007D2ED8DCFF55
00007d2ed8dd393c  call 0x00007D2ED8C0C260
00007d2ed8dd3941  jmp 0x00007D2ED8DCFFB0
00007d2ed8dd3946  sub rsp, 0x08
00007d2ed8dd394a  push rax
00007d2ed8dd394b  push rcx
00007d2ed8dd394c  push rdx
00007d2ed8dd394d  push rdi
00007d2ed8dd394e  push rsi
00007d2ed8dd394f  push r8
00007d2ed8dd3951  push r9
00007d2ed8dd3953  push r10
00007d2ed8dd3955  push r11
00007d2ed8dd3957  sub rsp, 0xF0
00007d2ed8dd395e  vmovaps [rsp], xmm0
00007d2ed8dd3963  vmovaps [rsp+0x10], xmm1
00007d2ed8dd3969  vmovaps [rsp+0x20], xmm2
00007d2ed8dd396f  vmovaps [rsp+0x30], xmm3
00007d2ed8dd3975  vmovaps [rsp+0x40], xmm4
00007d2ed8dd397b  vmovaps [rsp+0x50], xmm5
00007d2ed8dd3981  vmovaps [rsp+0x60], xmm6
00007d2ed8dd3987  vmovaps [rsp+0x70], xmm7
00007d2ed8dd398d  vmovaps [rsp+0x80], xmm8
00007d2ed8dd3996  vmovaps [rsp+0x90], xmm10
00007d2ed8dd399f  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd39a8  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd39b1  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd39ba  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd39c3  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd39cc  sub rsp, 0x30
00007d2ed8dd39d0  movaps [rsp], xmm9
00007d2ed8dd39d5  movaps [rsp+0x10], xmm8
00007d2ed8dd39db  movaps [rsp+0x20], xmm10
00007d2ed8dd39e1  lea rdi, [rsp]
00007d2ed8dd39e5  mov esi, 0x00
00007d2ed8dd39ea  mov rax, 0x648718324530
00007d2ed8dd39f4  call rax
00007d2ed8dd39f6  movaps xmm9, [rsp]
00007d2ed8dd39fb  add rsp, 0x30
00007d2ed8dd39ff  vmovaps xmm0, [rsp]
00007d2ed8dd3a04  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd3a0a  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd3a10  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd3a16  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd3a1c  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd3a22  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd3a28  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd3a2e  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd3a37  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd3a40  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd3a49  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd3a52  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd3a5b  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd3a64  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd3a6d  add rsp, 0xF0
00007d2ed8dd3a74  pop r11
00007d2ed8dd3a76  pop r10
00007d2ed8dd3a78  pop r9
00007d2ed8dd3a7a  pop r8
00007d2ed8dd3a7c  pop rsi
00007d2ed8dd3a7d  pop rdi
00007d2ed8dd3a7e  pop rdx
00007d2ed8dd3a7f  pop rcx
00007d2ed8dd3a80  pop rax
00007d2ed8dd3a81  add rsp, 0x08
00007d2ed8dd3a85  jmp 0x00007D2ED8DCFFE1
00007d2ed8dd3a8a  sub rsp, 0x08
00007d2ed8dd3a8e  push rax
00007d2ed8dd3a8f  push rcx
00007d2ed8dd3a90  push rdx
00007d2ed8dd3a91  push rdi
00007d2ed8dd3a92  push rsi
00007d2ed8dd3a93  push r8
00007d2ed8dd3a95  push r9
00007d2ed8dd3a97  push r10
00007d2ed8dd3a99  push r11
00007d2ed8dd3a9b  sub rsp, 0xF0
00007d2ed8dd3aa2  vmovaps [rsp], xmm0
00007d2ed8dd3aa7  vmovaps [rsp+0x10], xmm1
00007d2ed8dd3aad  vmovaps [rsp+0x20], xmm2
00007d2ed8dd3ab3  vmovaps [rsp+0x30], xmm3
00007d2ed8dd3ab9  vmovaps [rsp+0x40], xmm4
00007d2ed8dd3abf  vmovaps [rsp+0x50], xmm5
00007d2ed8dd3ac5  vmovaps [rsp+0x60], xmm6
00007d2ed8dd3acb  vmovaps [rsp+0x70], xmm7
00007d2ed8dd3ad1  vmovaps [rsp+0x80], xmm8
00007d2ed8dd3ada  vmovaps [rsp+0x90], xmm9
00007d2ed8dd3ae3  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd3aec  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd3af5  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd3afe  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd3b07  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd3b10  sub rsp, 0x30
00007d2ed8dd3b14  movaps [rsp], xmm10
00007d2ed8dd3b19  movaps [rsp+0x10], xmm1
00007d2ed8dd3b1e  movaps [rsp+0x20], xmm11
00007d2ed8dd3b24  lea rdi, [rsp]
00007d2ed8dd3b28  mov esi, 0x00
00007d2ed8dd3b2d  mov rax, 0x648718324530
00007d2ed8dd3b37  call rax
00007d2ed8dd3b39  movaps xmm10, [rsp]
00007d2ed8dd3b3e  add rsp, 0x30
00007d2ed8dd3b42  vmovaps xmm0, [rsp]
00007d2ed8dd3b47  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd3b4d  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd3b53  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd3b59  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd3b5f  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd3b65  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd3b6b  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd3b71  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd3b7a  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd3b83  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd3b8c  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd3b95  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd3b9e  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd3ba7  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd3bb0  add rsp, 0xF0
00007d2ed8dd3bb7  pop r11
00007d2ed8dd3bb9  pop r10
00007d2ed8dd3bbb  pop r9
00007d2ed8dd3bbd  pop r8
00007d2ed8dd3bbf  pop rsi
00007d2ed8dd3bc0  pop rdi
00007d2ed8dd3bc1  pop rdx
00007d2ed8dd3bc2  pop rcx
00007d2ed8dd3bc3  pop rax
00007d2ed8dd3bc4  add rsp, 0x08
00007d2ed8dd3bc8  jmp 0x00007D2ED8DCFFFC
00007d2ed8dd3bcd  sub rsp, 0x08
00007d2ed8dd3bd1  push rax
00007d2ed8dd3bd2  push rcx
00007d2ed8dd3bd3  push rdx
00007d2ed8dd3bd4  push rdi
00007d2ed8dd3bd5  push rsi
00007d2ed8dd3bd6  push r8
00007d2ed8dd3bd8  push r9
00007d2ed8dd3bda  push r10
00007d2ed8dd3bdc  push r11
00007d2ed8dd3bde  sub rsp, 0xF0
00007d2ed8dd3be5  vmovaps [rsp], xmm0
00007d2ed8dd3bea  vmovaps [rsp+0x10], xmm2
00007d2ed8dd3bf0  vmovaps [rsp+0x20], xmm3
00007d2ed8dd3bf6  vmovaps [rsp+0x30], xmm4
00007d2ed8dd3bfc  vmovaps [rsp+0x40], xmm5
00007d2ed8dd3c02  vmovaps [rsp+0x50], xmm6
00007d2ed8dd3c08  vmovaps [rsp+0x60], xmm7
00007d2ed8dd3c0e  vmovaps [rsp+0x70], xmm8
00007d2ed8dd3c14  vmovaps [rsp+0x80], xmm9
00007d2ed8dd3c1d  vmovaps [rsp+0x90], xmm10
00007d2ed8dd3c26  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd3c2f  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd3c38  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd3c41  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd3c4a  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd3c53  sub rsp, 0x30
00007d2ed8dd3c57  movaps [rsp], xmm1
00007d2ed8dd3c5b  movaps [rsp+0x10], xmm14
00007d2ed8dd3c61  movaps [rsp+0x20], xmm6
00007d2ed8dd3c66  lea rdi, [rsp]
00007d2ed8dd3c6a  mov esi, 0x00
00007d2ed8dd3c6f  mov rax, 0x648718324530
00007d2ed8dd3c79  call rax
00007d2ed8dd3c7b  movaps xmm1, [rsp]
00007d2ed8dd3c7f  add rsp, 0x30
00007d2ed8dd3c83  vmovaps xmm0, [rsp]
00007d2ed8dd3c88  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd3c8e  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd3c94  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd3c9a  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd3ca0  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd3ca6  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd3cac  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd3cb2  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd3cbb  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd3cc4  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd3ccd  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd3cd6  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd3cdf  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd3ce8  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd3cf1  add rsp, 0xF0
00007d2ed8dd3cf8  pop r11
00007d2ed8dd3cfa  pop r10
00007d2ed8dd3cfc  pop r9
00007d2ed8dd3cfe  pop r8
00007d2ed8dd3d00  pop rsi
00007d2ed8dd3d01  pop rdi
00007d2ed8dd3d02  pop rdx
00007d2ed8dd3d03  pop rcx
00007d2ed8dd3d04  pop rax
00007d2ed8dd3d05  add rsp, 0x08
00007d2ed8dd3d09  jmp 0x00007D2ED8DD0015
00007d2ed8dd3d0e  sub rsp, 0x08
00007d2ed8dd3d12  push rax
00007d2ed8dd3d13  push rcx
00007d2ed8dd3d14  push rdx
00007d2ed8dd3d15  push rdi
00007d2ed8dd3d16  push rsi
00007d2ed8dd3d17  push r8
00007d2ed8dd3d19  push r9
00007d2ed8dd3d1b  push r10
00007d2ed8dd3d1d  push r11
00007d2ed8dd3d1f  sub rsp, 0xF0
00007d2ed8dd3d26  vmovaps [rsp], xmm0
00007d2ed8dd3d2b  vmovaps [rsp+0x10], xmm1
00007d2ed8dd3d31  vmovaps [rsp+0x20], xmm2
00007d2ed8dd3d37  vmovaps [rsp+0x30], xmm3
00007d2ed8dd3d3d  vmovaps [rsp+0x40], xmm4
00007d2ed8dd3d43  vmovaps [rsp+0x50], xmm5
00007d2ed8dd3d49  vmovaps [rsp+0x60], xmm6
00007d2ed8dd3d4f  vmovaps [rsp+0x70], xmm7
00007d2ed8dd3d55  vmovaps [rsp+0x80], xmm8
00007d2ed8dd3d5e  vmovaps [rsp+0x90], xmm9
00007d2ed8dd3d67  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd3d70  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd3d79  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd3d82  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd3d8b  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd3d94  sub rsp, 0x30
00007d2ed8dd3d98  movaps [rsp], xmm11
00007d2ed8dd3d9d  movaps [rsp+0x10], xmm13
00007d2ed8dd3da3  movaps [rsp+0x20], xmm14
00007d2ed8dd3da9  lea rdi, [rsp]
00007d2ed8dd3dad  mov esi, 0x00
00007d2ed8dd3db2  mov rax, 0x648718324530
00007d2ed8dd3dbc  call rax
00007d2ed8dd3dbe  movaps xmm11, [rsp]
00007d2ed8dd3dc3  add rsp, 0x30
00007d2ed8dd3dc7  vmovaps xmm0, [rsp]
00007d2ed8dd3dcc  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd3dd2  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd3dd8  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd3dde  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd3de4  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd3dea  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd3df0  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd3df6  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd3dff  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd3e08  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd3e11  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd3e1a  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd3e23  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd3e2c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd3e35  add rsp, 0xF0
00007d2ed8dd3e3c  pop r11
00007d2ed8dd3e3e  pop r10
00007d2ed8dd3e40  pop r9
00007d2ed8dd3e42  pop r8
00007d2ed8dd3e44  pop rsi
00007d2ed8dd3e45  pop rdi
00007d2ed8dd3e46  pop rdx
00007d2ed8dd3e47  pop rcx
00007d2ed8dd3e48  pop rax
00007d2ed8dd3e49  add rsp, 0x08
00007d2ed8dd3e4d  jmp 0x00007D2ED8DD003F
00007d2ed8dd3e52  sub rsp, 0x08
00007d2ed8dd3e56  push rax
00007d2ed8dd3e57  push rcx
00007d2ed8dd3e58  push rdx
00007d2ed8dd3e59  push rdi
00007d2ed8dd3e5a  push rsi
00007d2ed8dd3e5b  push r8
00007d2ed8dd3e5d  push r9
00007d2ed8dd3e5f  push r10
00007d2ed8dd3e61  push r11
00007d2ed8dd3e63  sub rsp, 0xF0
00007d2ed8dd3e6a  vmovaps [rsp], xmm0
00007d2ed8dd3e6f  vmovaps [rsp+0x10], xmm1
00007d2ed8dd3e75  vmovaps [rsp+0x20], xmm2
00007d2ed8dd3e7b  vmovaps [rsp+0x30], xmm3
00007d2ed8dd3e81  vmovaps [rsp+0x40], xmm4
00007d2ed8dd3e87  vmovaps [rsp+0x50], xmm5
00007d2ed8dd3e8d  vmovaps [rsp+0x60], xmm6
00007d2ed8dd3e93  vmovaps [rsp+0x70], xmm7
00007d2ed8dd3e99  vmovaps [rsp+0x80], xmm8
00007d2ed8dd3ea2  vmovaps [rsp+0x90], xmm9
00007d2ed8dd3eab  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd3eb4  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd3ebd  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd3ec6  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd3ecf  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd3ed8  sub rsp, 0x30
00007d2ed8dd3edc  movaps [rsp], xmm13
00007d2ed8dd3ee1  movaps [rsp+0x10], xmm8
00007d2ed8dd3ee7  movaps [rsp+0x20], xmm14
00007d2ed8dd3eed  lea rdi, [rsp]
00007d2ed8dd3ef1  mov esi, 0x00
00007d2ed8dd3ef6  mov rax, 0x648718324530
00007d2ed8dd3f00  call rax
00007d2ed8dd3f02  movaps xmm13, [rsp]
00007d2ed8dd3f07  add rsp, 0x30
00007d2ed8dd3f0b  vmovaps xmm0, [rsp]
00007d2ed8dd3f10  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd3f16  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd3f1c  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd3f22  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd3f28  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd3f2e  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd3f34  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd3f3a  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd3f43  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd3f4c  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd3f55  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd3f5e  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd3f67  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd3f70  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd3f79  add rsp, 0xF0
00007d2ed8dd3f80  pop r11
00007d2ed8dd3f82  pop r10
00007d2ed8dd3f84  pop r9
00007d2ed8dd3f86  pop r8
00007d2ed8dd3f88  pop rsi
00007d2ed8dd3f89  pop rdi
00007d2ed8dd3f8a  pop rdx
00007d2ed8dd3f8b  pop rcx
00007d2ed8dd3f8c  pop rax
00007d2ed8dd3f8d  add rsp, 0x08
00007d2ed8dd3f91  jmp 0x00007D2ED8DD006E
00007d2ed8dd3f96  sub rsp, 0x08
00007d2ed8dd3f9a  push rax
00007d2ed8dd3f9b  push rcx
00007d2ed8dd3f9c  push rdx
00007d2ed8dd3f9d  push rdi
00007d2ed8dd3f9e  push rsi
00007d2ed8dd3f9f  push r8
00007d2ed8dd3fa1  push r9
00007d2ed8dd3fa3  push r10
00007d2ed8dd3fa5  push r11
00007d2ed8dd3fa7  sub rsp, 0xF0
00007d2ed8dd3fae  vmovaps [rsp], xmm0
00007d2ed8dd3fb3  vmovaps [rsp+0x10], xmm1
00007d2ed8dd3fb9  vmovaps [rsp+0x20], xmm2
00007d2ed8dd3fbf  vmovaps [rsp+0x30], xmm3
00007d2ed8dd3fc5  vmovaps [rsp+0x40], xmm4
00007d2ed8dd3fcb  vmovaps [rsp+0x50], xmm5
00007d2ed8dd3fd1  vmovaps [rsp+0x60], xmm6
00007d2ed8dd3fd7  vmovaps [rsp+0x70], xmm7
00007d2ed8dd3fdd  vmovaps [rsp+0x80], xmm9
00007d2ed8dd3fe6  vmovaps [rsp+0x90], xmm10
00007d2ed8dd3fef  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd3ff8  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd4001  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd400a  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd4013  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd401c  sub rsp, 0x30
00007d2ed8dd4020  movaps [rsp], xmm8
00007d2ed8dd4025  movaps [rsp+0x10], xmm7
00007d2ed8dd402a  movaps [rsp+0x20], xmm14
00007d2ed8dd4030  lea rdi, [rsp]
00007d2ed8dd4034  mov esi, 0x00
00007d2ed8dd4039  mov rax, 0x648718324530
00007d2ed8dd4043  call rax
00007d2ed8dd4045  movaps xmm8, [rsp]
00007d2ed8dd404a  add rsp, 0x30
00007d2ed8dd404e  vmovaps xmm0, [rsp]
00007d2ed8dd4053  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd4059  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd405f  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd4065  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd406b  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd4071  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd4077  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd407d  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd4086  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd408f  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd4098  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd40a1  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd40aa  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd40b3  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd40bc  add rsp, 0xF0
00007d2ed8dd40c3  pop r11
00007d2ed8dd40c5  pop r10
00007d2ed8dd40c7  pop r9
00007d2ed8dd40c9  pop r8
00007d2ed8dd40cb  pop rsi
00007d2ed8dd40cc  pop rdi
00007d2ed8dd40cd  pop rdx
00007d2ed8dd40ce  pop rcx
00007d2ed8dd40cf  pop rax
00007d2ed8dd40d0  add rsp, 0x08
00007d2ed8dd40d4  jmp 0x00007D2ED8DD0094
00007d2ed8dd40d9  sub rsp, 0x08
00007d2ed8dd40dd  push rax
00007d2ed8dd40de  push rcx
00007d2ed8dd40df  push rdx
00007d2ed8dd40e0  push rdi
00007d2ed8dd40e1  push rsi
00007d2ed8dd40e2  push r8
00007d2ed8dd40e4  push r9
00007d2ed8dd40e6  push r10
00007d2ed8dd40e8  push r11
00007d2ed8dd40ea  sub rsp, 0xF0
00007d2ed8dd40f1  vmovaps [rsp], xmm0
00007d2ed8dd40f6  vmovaps [rsp+0x10], xmm1
00007d2ed8dd40fc  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4102  vmovaps [rsp+0x30], xmm3
00007d2ed8dd4108  vmovaps [rsp+0x40], xmm4
00007d2ed8dd410e  vmovaps [rsp+0x50], xmm5
00007d2ed8dd4114  vmovaps [rsp+0x60], xmm6
00007d2ed8dd411a  vmovaps [rsp+0x70], xmm7
00007d2ed8dd4120  vmovaps [rsp+0x80], xmm8
00007d2ed8dd4129  vmovaps [rsp+0x90], xmm9
00007d2ed8dd4132  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd413b  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd4144  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd414d  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd4156  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd415f  sub rsp, 0x30
00007d2ed8dd4163  movaps [rsp], xmm14
00007d2ed8dd4168  movaps [rsp+0x10], xmm12
00007d2ed8dd416e  movaps [rsp+0x20], xmm9
00007d2ed8dd4174  lea rdi, [rsp]
00007d2ed8dd4178  mov esi, 0x00
00007d2ed8dd417d  mov rax, 0x648718324530
00007d2ed8dd4187  call rax
00007d2ed8dd4189  movaps xmm14, [rsp]
00007d2ed8dd418e  add rsp, 0x30
00007d2ed8dd4192  vmovaps xmm0, [rsp]
00007d2ed8dd4197  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd419d  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd41a3  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd41a9  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd41af  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd41b5  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd41bb  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd41c1  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd41ca  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd41d3  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd41dc  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd41e5  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd41ee  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd41f7  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4200  add rsp, 0xF0
00007d2ed8dd4207  pop r11
00007d2ed8dd4209  pop r10
00007d2ed8dd420b  pop r9
00007d2ed8dd420d  pop r8
00007d2ed8dd420f  pop rsi
00007d2ed8dd4210  pop rdi
00007d2ed8dd4211  pop rdx
00007d2ed8dd4212  pop rcx
00007d2ed8dd4213  pop rax
00007d2ed8dd4214  add rsp, 0x08
00007d2ed8dd4218  jmp 0x00007D2ED8DD00AE
00007d2ed8dd421d  sub rsp, 0x08
00007d2ed8dd4221  push rax
00007d2ed8dd4222  push rcx
00007d2ed8dd4223  push rdx
00007d2ed8dd4224  push rdi
00007d2ed8dd4225  push rsi
00007d2ed8dd4226  push r8
00007d2ed8dd4228  push r9
00007d2ed8dd422a  push r10
00007d2ed8dd422c  push r11
00007d2ed8dd422e  sub rsp, 0xF0
00007d2ed8dd4235  vmovaps [rsp], xmm0
00007d2ed8dd423a  vmovaps [rsp+0x10], xmm1
00007d2ed8dd4240  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4246  vmovaps [rsp+0x30], xmm3
00007d2ed8dd424c  vmovaps [rsp+0x40], xmm4
00007d2ed8dd4252  vmovaps [rsp+0x50], xmm5
00007d2ed8dd4258  vmovaps [rsp+0x60], xmm6
00007d2ed8dd425e  vmovaps [rsp+0x70], xmm7
00007d2ed8dd4264  vmovaps [rsp+0x80], xmm8
00007d2ed8dd426d  vmovaps [rsp+0x90], xmm10
00007d2ed8dd4276  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd427f  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd4288  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd4291  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd429a  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd42a3  sub rsp, 0x30
00007d2ed8dd42a7  movaps [rsp], xmm9
00007d2ed8dd42ac  movaps [rsp+0x10], xmm7
00007d2ed8dd42b1  movaps [rsp+0x20], xmm12
00007d2ed8dd42b7  lea rdi, [rsp]
00007d2ed8dd42bb  mov esi, 0x00
00007d2ed8dd42c0  mov rax, 0x648718324530
00007d2ed8dd42ca  call rax
00007d2ed8dd42cc  movaps xmm9, [rsp]
00007d2ed8dd42d1  add rsp, 0x30
00007d2ed8dd42d5  vmovaps xmm0, [rsp]
00007d2ed8dd42da  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd42e0  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd42e6  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd42ec  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd42f2  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd42f8  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd42fe  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd4304  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd430d  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd4316  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd431f  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd4328  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd4331  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd433a  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4343  add rsp, 0xF0
00007d2ed8dd434a  pop r11
00007d2ed8dd434c  pop r10
00007d2ed8dd434e  pop r9
00007d2ed8dd4350  pop r8
00007d2ed8dd4352  pop rsi
00007d2ed8dd4353  pop rdi
00007d2ed8dd4354  pop rdx
00007d2ed8dd4355  pop rcx
00007d2ed8dd4356  pop rax
00007d2ed8dd4357  add rsp, 0x08
00007d2ed8dd435b  jmp 0x00007D2ED8DD00DD
00007d2ed8dd4360  sub rsp, 0x08
00007d2ed8dd4364  push rax
00007d2ed8dd4365  push rcx
00007d2ed8dd4366  push rdx
00007d2ed8dd4367  push rdi
00007d2ed8dd4368  push rsi
00007d2ed8dd4369  push r8
00007d2ed8dd436b  push r9
00007d2ed8dd436d  push r10
00007d2ed8dd436f  push r11
00007d2ed8dd4371  sub rsp, 0xF0
00007d2ed8dd4378  vmovaps [rsp], xmm0
00007d2ed8dd437d  vmovaps [rsp+0x10], xmm1
00007d2ed8dd4383  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4389  vmovaps [rsp+0x30], xmm3
00007d2ed8dd438f  vmovaps [rsp+0x40], xmm4
00007d2ed8dd4395  vmovaps [rsp+0x50], xmm5
00007d2ed8dd439b  vmovaps [rsp+0x60], xmm6
00007d2ed8dd43a1  vmovaps [rsp+0x70], xmm7
00007d2ed8dd43a7  vmovaps [rsp+0x80], xmm8
00007d2ed8dd43b0  vmovaps [rsp+0x90], xmm9
00007d2ed8dd43b9  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd43c2  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd43cb  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd43d4  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd43dd  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd43e6  sub rsp, 0x30
00007d2ed8dd43ea  movaps [rsp], xmm12
00007d2ed8dd43ef  movaps [rsp+0x10], xmm15
00007d2ed8dd43f5  movaps [rsp+0x20], xmm11
00007d2ed8dd43fb  lea rdi, [rsp]
00007d2ed8dd43ff  mov esi, 0x00
00007d2ed8dd4404  mov rax, 0x648718324530
00007d2ed8dd440e  call rax
00007d2ed8dd4410  movaps xmm12, [rsp]
00007d2ed8dd4415  add rsp, 0x30
00007d2ed8dd4419  vmovaps xmm0, [rsp]
00007d2ed8dd441e  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd4424  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd442a  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd4430  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd4436  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd443c  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd4442  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd4448  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd4451  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd445a  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd4463  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd446c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd4475  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd447e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4487  add rsp, 0xF0
00007d2ed8dd448e  pop r11
00007d2ed8dd4490  pop r10
00007d2ed8dd4492  pop r9
00007d2ed8dd4494  pop r8
00007d2ed8dd4496  pop rsi
00007d2ed8dd4497  pop rdi
00007d2ed8dd4498  pop rdx
00007d2ed8dd4499  pop rcx
00007d2ed8dd449a  pop rax
00007d2ed8dd449b  add rsp, 0x08
00007d2ed8dd449f  jmp 0x00007D2ED8DD00F7
00007d2ed8dd44a4  sub rsp, 0x08
00007d2ed8dd44a8  push rax
00007d2ed8dd44a9  push rcx
00007d2ed8dd44aa  push rdx
00007d2ed8dd44ab  push rdi
00007d2ed8dd44ac  push rsi
00007d2ed8dd44ad  push r8
00007d2ed8dd44af  push r9
00007d2ed8dd44b1  push r10
00007d2ed8dd44b3  push r11
00007d2ed8dd44b5  sub rsp, 0xF0
00007d2ed8dd44bc  vmovaps [rsp], xmm0
00007d2ed8dd44c1  vmovaps [rsp+0x10], xmm1
00007d2ed8dd44c7  vmovaps [rsp+0x20], xmm2
00007d2ed8dd44cd  vmovaps [rsp+0x30], xmm3
00007d2ed8dd44d3  vmovaps [rsp+0x40], xmm4
00007d2ed8dd44d9  vmovaps [rsp+0x50], xmm5
00007d2ed8dd44df  vmovaps [rsp+0x60], xmm6
00007d2ed8dd44e5  vmovaps [rsp+0x70], xmm7
00007d2ed8dd44eb  vmovaps [rsp+0x80], xmm8
00007d2ed8dd44f4  vmovaps [rsp+0x90], xmm9
00007d2ed8dd44fd  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd4506  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd450f  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd4518  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd4521  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd452a  sub rsp, 0x30
00007d2ed8dd452e  movaps [rsp], xmm11
00007d2ed8dd4533  movaps [rsp+0x10], xmm7
00007d2ed8dd4538  movaps [rsp+0x20], xmm15
00007d2ed8dd453e  lea rdi, [rsp]
00007d2ed8dd4542  mov esi, 0x00
00007d2ed8dd4547  mov rax, 0x648718324530
00007d2ed8dd4551  call rax
00007d2ed8dd4553  movaps xmm11, [rsp]
00007d2ed8dd4558  add rsp, 0x30
00007d2ed8dd455c  vmovaps xmm0, [rsp]
00007d2ed8dd4561  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd4567  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd456d  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd4573  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd4579  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd457f  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd4585  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd458b  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd4594  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd459d  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd45a6  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd45af  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd45b8  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd45c1  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd45ca  add rsp, 0xF0
00007d2ed8dd45d1  pop r11
00007d2ed8dd45d3  pop r10
00007d2ed8dd45d5  pop r9
00007d2ed8dd45d7  pop r8
00007d2ed8dd45d9  pop rsi
00007d2ed8dd45da  pop rdi
00007d2ed8dd45db  pop rdx
00007d2ed8dd45dc  pop rcx
00007d2ed8dd45dd  pop rax
00007d2ed8dd45de  add rsp, 0x08
00007d2ed8dd45e2  jmp 0x00007D2ED8DD0123
00007d2ed8dd45e7  sub rsp, 0x08
00007d2ed8dd45eb  push rax
00007d2ed8dd45ec  push rcx
00007d2ed8dd45ed  push rdx
00007d2ed8dd45ee  push rdi
00007d2ed8dd45ef  push rsi
00007d2ed8dd45f0  push r8
00007d2ed8dd45f2  push r9
00007d2ed8dd45f4  push r10
00007d2ed8dd45f6  push r11
00007d2ed8dd45f8  sub rsp, 0xF0
00007d2ed8dd45ff  vmovaps [rsp], xmm0
00007d2ed8dd4604  vmovaps [rsp+0x10], xmm1
00007d2ed8dd460a  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4610  vmovaps [rsp+0x30], xmm3
00007d2ed8dd4616  vmovaps [rsp+0x40], xmm4
00007d2ed8dd461c  vmovaps [rsp+0x50], xmm5
00007d2ed8dd4622  vmovaps [rsp+0x60], xmm6
00007d2ed8dd4628  vmovaps [rsp+0x70], xmm7
00007d2ed8dd462e  vmovaps [rsp+0x80], xmm8
00007d2ed8dd4637  vmovaps [rsp+0x90], xmm9
00007d2ed8dd4640  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd4649  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd4652  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd465b  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd4664  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd466d  sub rsp, 0x30
00007d2ed8dd4671  movaps [rsp], xmm15
00007d2ed8dd4676  movaps [rsp+0x10], xmm10
00007d2ed8dd467c  movaps [rsp+0x20], xmm13
00007d2ed8dd4682  lea rdi, [rsp]
00007d2ed8dd4686  mov esi, 0x00
00007d2ed8dd468b  mov rax, 0x648718324530
00007d2ed8dd4695  call rax
00007d2ed8dd4697  movaps xmm15, [rsp]
00007d2ed8dd469c  add rsp, 0x30
00007d2ed8dd46a0  vmovaps xmm0, [rsp]
00007d2ed8dd46a5  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd46ab  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd46b1  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd46b7  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd46bd  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd46c3  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd46c9  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd46cf  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd46d8  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd46e1  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd46ea  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd46f3  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd46fc  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd4705  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd470e  add rsp, 0xF0
00007d2ed8dd4715  pop r11
00007d2ed8dd4717  pop r10
00007d2ed8dd4719  pop r9
00007d2ed8dd471b  pop r8
00007d2ed8dd471d  pop rsi
00007d2ed8dd471e  pop rdi
00007d2ed8dd471f  pop rdx
00007d2ed8dd4720  pop rcx
00007d2ed8dd4721  pop rax
00007d2ed8dd4722  add rsp, 0x08
00007d2ed8dd4726  jmp 0x00007D2ED8DD013D
00007d2ed8dd472b  sub rsp, 0x08
00007d2ed8dd472f  push rax
00007d2ed8dd4730  push rcx
00007d2ed8dd4731  push rdx
00007d2ed8dd4732  push rdi
00007d2ed8dd4733  push rsi
00007d2ed8dd4734  push r8
00007d2ed8dd4736  push r9
00007d2ed8dd4738  push r10
00007d2ed8dd473a  push r11
00007d2ed8dd473c  sub rsp, 0xF0
00007d2ed8dd4743  vmovaps [rsp], xmm0
00007d2ed8dd4748  vmovaps [rsp+0x10], xmm1
00007d2ed8dd474e  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4754  vmovaps [rsp+0x30], xmm3
00007d2ed8dd475a  vmovaps [rsp+0x40], xmm4
00007d2ed8dd4760  vmovaps [rsp+0x50], xmm5
00007d2ed8dd4766  vmovaps [rsp+0x60], xmm6
00007d2ed8dd476c  vmovaps [rsp+0x70], xmm7
00007d2ed8dd4772  vmovaps [rsp+0x80], xmm8
00007d2ed8dd477b  vmovaps [rsp+0x90], xmm9
00007d2ed8dd4784  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd478d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd4796  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd479f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd47a8  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd47b1  sub rsp, 0x30
00007d2ed8dd47b5  movaps [rsp], xmm10
00007d2ed8dd47ba  movaps [rsp+0x10], xmm7
00007d2ed8dd47bf  movaps [rsp+0x20], xmm13
00007d2ed8dd47c5  lea rdi, [rsp]
00007d2ed8dd47c9  mov esi, 0x00
00007d2ed8dd47ce  mov rax, 0x648718324530
00007d2ed8dd47d8  call rax
00007d2ed8dd47da  movaps xmm10, [rsp]
00007d2ed8dd47df  add rsp, 0x30
00007d2ed8dd47e3  vmovaps xmm0, [rsp]
00007d2ed8dd47e8  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd47ee  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd47f4  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd47fa  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd4800  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd4806  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd480c  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd4812  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd481b  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd4824  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd482d  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd4836  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd483f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd4848  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4851  add rsp, 0xF0
00007d2ed8dd4858  pop r11
00007d2ed8dd485a  pop r10
00007d2ed8dd485c  pop r9
00007d2ed8dd485e  pop r8
00007d2ed8dd4860  pop rsi
00007d2ed8dd4861  pop rdi
00007d2ed8dd4862  pop rdx
00007d2ed8dd4863  pop rcx
00007d2ed8dd4864  pop rax
00007d2ed8dd4865  add rsp, 0x08
00007d2ed8dd4869  jmp 0x00007D2ED8DD0169
00007d2ed8dd486e  sub rsp, 0x08
00007d2ed8dd4872  push rax
00007d2ed8dd4873  push rcx
00007d2ed8dd4874  push rdx
00007d2ed8dd4875  push rdi
00007d2ed8dd4876  push rsi
00007d2ed8dd4877  push r8
00007d2ed8dd4879  push r9
00007d2ed8dd487b  push r10
00007d2ed8dd487d  push r11
00007d2ed8dd487f  sub rsp, 0xF0
00007d2ed8dd4886  vmovaps [rsp], xmm0
00007d2ed8dd488b  vmovaps [rsp+0x10], xmm1
00007d2ed8dd4891  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4897  vmovaps [rsp+0x30], xmm3
00007d2ed8dd489d  vmovaps [rsp+0x40], xmm4
00007d2ed8dd48a3  vmovaps [rsp+0x50], xmm5
00007d2ed8dd48a9  vmovaps [rsp+0x60], xmm6
00007d2ed8dd48af  vmovaps [rsp+0x70], xmm7
00007d2ed8dd48b5  vmovaps [rsp+0x80], xmm8
00007d2ed8dd48be  vmovaps [rsp+0x90], xmm9
00007d2ed8dd48c7  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd48d0  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd48d9  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd48e2  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd48eb  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd48f4  sub rsp, 0x30
00007d2ed8dd48f8  movaps [rsp], xmm13
00007d2ed8dd48fd  movaps [rsp+0x10], xmm1
00007d2ed8dd4902  movaps [rsp+0x20], xmm8
00007d2ed8dd4908  lea rdi, [rsp]
00007d2ed8dd490c  mov esi, 0x00
00007d2ed8dd4911  mov rax, 0x648718324530
00007d2ed8dd491b  call rax
00007d2ed8dd491d  movaps xmm13, [rsp]
00007d2ed8dd4922  add rsp, 0x30
00007d2ed8dd4926  vmovaps xmm0, [rsp]
00007d2ed8dd492b  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd4931  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd4937  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd493d  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd4943  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd4949  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd494f  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd4955  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd495e  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd4967  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd4970  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd4979  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd4982  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd498b  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4994  add rsp, 0xF0
00007d2ed8dd499b  pop r11
00007d2ed8dd499d  pop r10
00007d2ed8dd499f  pop r9
00007d2ed8dd49a1  pop r8
00007d2ed8dd49a3  pop rsi
00007d2ed8dd49a4  pop rdi
00007d2ed8dd49a5  pop rdx
00007d2ed8dd49a6  pop rcx
00007d2ed8dd49a7  pop rax
00007d2ed8dd49a8  add rsp, 0x08
00007d2ed8dd49ac  jmp 0x00007D2ED8DD0183
00007d2ed8dd49b1  call 0x00007D2ED8BFF430
00007d2ed8dd49b6  jmp 0x00007D2ED8DD018D
00007d2ed8dd49bb  sub rsp, 0x08
00007d2ed8dd49bf  push rax
00007d2ed8dd49c0  push rcx
00007d2ed8dd49c1  push rdx
00007d2ed8dd49c2  push rdi
00007d2ed8dd49c3  push rsi
00007d2ed8dd49c4  push r8
00007d2ed8dd49c6  push r9
00007d2ed8dd49c8  push r10
00007d2ed8dd49ca  push r11
00007d2ed8dd49cc  sub rsp, 0xF0
00007d2ed8dd49d3  vmovaps [rsp], xmm0
00007d2ed8dd49d8  vmovaps [rsp+0x10], xmm1
00007d2ed8dd49de  vmovaps [rsp+0x20], xmm2
00007d2ed8dd49e4  vmovaps [rsp+0x30], xmm3
00007d2ed8dd49ea  vmovaps [rsp+0x40], xmm4
00007d2ed8dd49f0  vmovaps [rsp+0x50], xmm5
00007d2ed8dd49f6  vmovaps [rsp+0x60], xmm6
00007d2ed8dd49fc  vmovaps [rsp+0x70], xmm7
00007d2ed8dd4a02  vmovaps [rsp+0x80], xmm9
00007d2ed8dd4a0b  vmovaps [rsp+0x90], xmm10
00007d2ed8dd4a14  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd4a1d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd4a26  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd4a2f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd4a38  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd4a41  sub rsp, 0x30
00007d2ed8dd4a45  movaps [rsp], xmm8
00007d2ed8dd4a4a  movaps [rsp+0x10], xmm14
00007d2ed8dd4a50  movaps [rsp+0x20], xmm9
00007d2ed8dd4a56  lea rdi, [rsp]
00007d2ed8dd4a5a  mov esi, 0x00
00007d2ed8dd4a5f  mov rax, 0x648718324530
00007d2ed8dd4a69  call rax
00007d2ed8dd4a6b  movaps xmm8, [rsp]
00007d2ed8dd4a70  add rsp, 0x30
00007d2ed8dd4a74  vmovaps xmm0, [rsp]
00007d2ed8dd4a79  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd4a7f  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd4a85  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd4a8b  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd4a91  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd4a97  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd4a9d  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd4aa3  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd4aac  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd4ab5  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd4abe  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd4ac7  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd4ad0  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd4ad9  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4ae2  add rsp, 0xF0
00007d2ed8dd4ae9  pop r11
00007d2ed8dd4aeb  pop r10
00007d2ed8dd4aed  pop r9
00007d2ed8dd4aef  pop r8
00007d2ed8dd4af1  pop rsi
00007d2ed8dd4af2  pop rdi
00007d2ed8dd4af3  pop rdx
00007d2ed8dd4af4  pop rcx
00007d2ed8dd4af5  pop rax
00007d2ed8dd4af6  add rsp, 0x08
00007d2ed8dd4afa  jmp 0x00007D2ED8DD01AF
00007d2ed8dd4aff  sub rsp, 0x08
00007d2ed8dd4b03  push rax
00007d2ed8dd4b04  push rcx
00007d2ed8dd4b05  push rdx
00007d2ed8dd4b06  push rdi
00007d2ed8dd4b07  push rsi
00007d2ed8dd4b08  push r8
00007d2ed8dd4b0a  push r9
00007d2ed8dd4b0c  push r10
00007d2ed8dd4b0e  push r11
00007d2ed8dd4b10  sub rsp, 0xF0
00007d2ed8dd4b17  vmovaps [rsp], xmm0
00007d2ed8dd4b1c  vmovaps [rsp+0x10], xmm1
00007d2ed8dd4b22  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4b28  vmovaps [rsp+0x30], xmm3
00007d2ed8dd4b2e  vmovaps [rsp+0x40], xmm4
00007d2ed8dd4b34  vmovaps [rsp+0x50], xmm5
00007d2ed8dd4b3a  vmovaps [rsp+0x60], xmm6
00007d2ed8dd4b40  vmovaps [rsp+0x70], xmm7
00007d2ed8dd4b46  vmovaps [rsp+0x80], xmm8
00007d2ed8dd4b4f  vmovaps [rsp+0x90], xmm10
00007d2ed8dd4b58  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd4b61  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd4b6a  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd4b73  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd4b7c  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd4b85  sub rsp, 0x30
00007d2ed8dd4b89  movaps [rsp], xmm9
00007d2ed8dd4b8e  movaps [rsp+0x10], xmm1
00007d2ed8dd4b93  movaps [rsp+0x20], xmm14
00007d2ed8dd4b99  lea rdi, [rsp]
00007d2ed8dd4b9d  mov esi, 0x00
00007d2ed8dd4ba2  mov rax, 0x648718324530
00007d2ed8dd4bac  call rax
00007d2ed8dd4bae  movaps xmm9, [rsp]
00007d2ed8dd4bb3  add rsp, 0x30
00007d2ed8dd4bb7  vmovaps xmm0, [rsp]
00007d2ed8dd4bbc  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd4bc2  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd4bc8  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd4bce  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd4bd4  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd4bda  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd4be0  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd4be6  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd4bef  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd4bf8  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd4c01  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd4c0a  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd4c13  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd4c1c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4c25  add rsp, 0xF0
00007d2ed8dd4c2c  pop r11
00007d2ed8dd4c2e  pop r10
00007d2ed8dd4c30  pop r9
00007d2ed8dd4c32  pop r8
00007d2ed8dd4c34  pop rsi
00007d2ed8dd4c35  pop rdi
00007d2ed8dd4c36  pop rdx
00007d2ed8dd4c37  pop rcx
00007d2ed8dd4c38  pop rax
00007d2ed8dd4c39  add rsp, 0x08
00007d2ed8dd4c3d  jmp 0x00007D2ED8DD01DD
00007d2ed8dd4c42  sub rsp, 0x08
00007d2ed8dd4c46  push rax
00007d2ed8dd4c47  push rcx
00007d2ed8dd4c48  push rdx
00007d2ed8dd4c49  push rdi
00007d2ed8dd4c4a  push rsi
00007d2ed8dd4c4b  push r8
00007d2ed8dd4c4d  push r9
00007d2ed8dd4c4f  push r10
00007d2ed8dd4c51  push r11
00007d2ed8dd4c53  sub rsp, 0xF0
00007d2ed8dd4c5a  vmovaps [rsp], xmm0
00007d2ed8dd4c5f  vmovaps [rsp+0x10], xmm1
00007d2ed8dd4c65  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4c6b  vmovaps [rsp+0x30], xmm3
00007d2ed8dd4c71  vmovaps [rsp+0x40], xmm4
00007d2ed8dd4c77  vmovaps [rsp+0x50], xmm5
00007d2ed8dd4c7d  vmovaps [rsp+0x60], xmm6
00007d2ed8dd4c83  vmovaps [rsp+0x70], xmm7
00007d2ed8dd4c89  vmovaps [rsp+0x80], xmm8
00007d2ed8dd4c92  vmovaps [rsp+0x90], xmm9
00007d2ed8dd4c9b  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd4ca4  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd4cad  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd4cb6  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd4cbf  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd4cc8  sub rsp, 0x30
00007d2ed8dd4ccc  movaps [rsp], xmm14
00007d2ed8dd4cd1  movaps [rsp+0x10], xmm4
00007d2ed8dd4cd6  movaps [rsp+0x20], xmm1
00007d2ed8dd4cdb  lea rdi, [rsp]
00007d2ed8dd4cdf  mov esi, 0x00
00007d2ed8dd4ce4  mov rax, 0x648718324530
00007d2ed8dd4cee  call rax
00007d2ed8dd4cf0  movaps xmm14, [rsp]
00007d2ed8dd4cf5  add rsp, 0x30
00007d2ed8dd4cf9  vmovaps xmm0, [rsp]
00007d2ed8dd4cfe  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd4d04  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd4d0a  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd4d10  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd4d16  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd4d1c  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd4d22  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd4d28  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd4d31  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd4d3a  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd4d43  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd4d4c  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd4d55  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd4d5e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4d67  add rsp, 0xF0
00007d2ed8dd4d6e  pop r11
00007d2ed8dd4d70  pop r10
00007d2ed8dd4d72  pop r9
00007d2ed8dd4d74  pop r8
00007d2ed8dd4d76  pop rsi
00007d2ed8dd4d77  pop rdi
00007d2ed8dd4d78  pop rdx
00007d2ed8dd4d79  pop rcx
00007d2ed8dd4d7a  pop rax
00007d2ed8dd4d7b  add rsp, 0x08
00007d2ed8dd4d7f  jmp 0x00007D2ED8DD0203
00007d2ed8dd4d84  sub rsp, 0x08
00007d2ed8dd4d88  push rax
00007d2ed8dd4d89  push rcx
00007d2ed8dd4d8a  push rdx
00007d2ed8dd4d8b  push rdi
00007d2ed8dd4d8c  push rsi
00007d2ed8dd4d8d  push r8
00007d2ed8dd4d8f  push r9
00007d2ed8dd4d91  push r10
00007d2ed8dd4d93  push r11
00007d2ed8dd4d95  sub rsp, 0xF0
00007d2ed8dd4d9c  vmovaps [rsp], xmm0
00007d2ed8dd4da1  vmovaps [rsp+0x10], xmm2
00007d2ed8dd4da7  vmovaps [rsp+0x20], xmm3
00007d2ed8dd4dad  vmovaps [rsp+0x30], xmm4
00007d2ed8dd4db3  vmovaps [rsp+0x40], xmm5
00007d2ed8dd4db9  vmovaps [rsp+0x50], xmm6
00007d2ed8dd4dbf  vmovaps [rsp+0x60], xmm7
00007d2ed8dd4dc5  vmovaps [rsp+0x70], xmm8
00007d2ed8dd4dcb  vmovaps [rsp+0x80], xmm9
00007d2ed8dd4dd4  vmovaps [rsp+0x90], xmm10
00007d2ed8dd4ddd  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd4de6  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd4def  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd4df8  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd4e01  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd4e0a  sub rsp, 0x30
00007d2ed8dd4e0e  movaps [rsp], xmm1
00007d2ed8dd4e12  movaps [rsp+0x10], xmm12
00007d2ed8dd4e18  movaps [rsp+0x20], xmm11
00007d2ed8dd4e1e  lea rdi, [rsp]
00007d2ed8dd4e22  mov esi, 0x00
00007d2ed8dd4e27  mov rax, 0x648718324530
00007d2ed8dd4e31  call rax
00007d2ed8dd4e33  movaps xmm1, [rsp]
00007d2ed8dd4e37  add rsp, 0x30
00007d2ed8dd4e3b  vmovaps xmm0, [rsp]
00007d2ed8dd4e40  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd4e46  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd4e4c  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd4e52  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd4e58  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd4e5e  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd4e64  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd4e6a  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd4e73  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd4e7c  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd4e85  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd4e8e  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd4e97  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd4ea0  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4ea9  add rsp, 0xF0
00007d2ed8dd4eb0  pop r11
00007d2ed8dd4eb2  pop r10
00007d2ed8dd4eb4  pop r9
00007d2ed8dd4eb6  pop r8
00007d2ed8dd4eb8  pop rsi
00007d2ed8dd4eb9  pop rdi
00007d2ed8dd4eba  pop rdx
00007d2ed8dd4ebb  pop rcx
00007d2ed8dd4ebc  pop rax
00007d2ed8dd4ebd  add rsp, 0x08
00007d2ed8dd4ec1  jmp 0x00007D2ED8DD0224
00007d2ed8dd4ec6  call 0x00007D2ED8CE20A0
00007d2ed8dd4ecb  jmp 0x00007D2ED8DD0232
00007d2ed8dd4ed0  call 0x00007D2ED8C09D70
00007d2ed8dd4ed5  jmp 0x00007D2ED8DD023C
00007d2ed8dd4eda  sub rsp, 0x08
00007d2ed8dd4ede  push rax
00007d2ed8dd4edf  push rcx
00007d2ed8dd4ee0  push rdx
00007d2ed8dd4ee1  push rdi
00007d2ed8dd4ee2  push rsi
00007d2ed8dd4ee3  push r8
00007d2ed8dd4ee5  push r9
00007d2ed8dd4ee7  push r10
00007d2ed8dd4ee9  push r11
00007d2ed8dd4eeb  sub rsp, 0xF0
00007d2ed8dd4ef2  vmovaps [rsp], xmm0
00007d2ed8dd4ef7  vmovaps [rsp+0x10], xmm1
00007d2ed8dd4efd  vmovaps [rsp+0x20], xmm2
00007d2ed8dd4f03  vmovaps [rsp+0x30], xmm3
00007d2ed8dd4f09  vmovaps [rsp+0x40], xmm4
00007d2ed8dd4f0f  vmovaps [rsp+0x50], xmm5
00007d2ed8dd4f15  vmovaps [rsp+0x60], xmm6
00007d2ed8dd4f1b  vmovaps [rsp+0x70], xmm8
00007d2ed8dd4f21  vmovaps [rsp+0x80], xmm9
00007d2ed8dd4f2a  vmovaps [rsp+0x90], xmm10
00007d2ed8dd4f33  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd4f3c  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd4f45  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd4f4e  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd4f57  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd4f60  sub rsp, 0x30
00007d2ed8dd4f64  movaps [rsp], xmm7
00007d2ed8dd4f68  movaps [rsp+0x10], xmm15
00007d2ed8dd4f6e  movaps [rsp+0x20], xmm10
00007d2ed8dd4f74  lea rdi, [rsp]
00007d2ed8dd4f78  mov esi, 0x00
00007d2ed8dd4f7d  mov rax, 0x648718324530
00007d2ed8dd4f87  call rax
00007d2ed8dd4f89  movaps xmm7, [rsp]
00007d2ed8dd4f8d  add rsp, 0x30
00007d2ed8dd4f91  vmovaps xmm0, [rsp]
00007d2ed8dd4f96  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd4f9c  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd4fa2  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd4fa8  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd4fae  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd4fb4  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd4fba  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd4fc0  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd4fc9  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd4fd2  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd4fdb  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd4fe4  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd4fed  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd4ff6  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd4fff  add rsp, 0xF0
00007d2ed8dd5006  pop r11
00007d2ed8dd5008  pop r10
00007d2ed8dd500a  pop r9
00007d2ed8dd500c  pop r8
00007d2ed8dd500e  pop rsi
00007d2ed8dd500f  pop rdi
00007d2ed8dd5010  pop rdx
00007d2ed8dd5011  pop rcx
00007d2ed8dd5012  pop rax
00007d2ed8dd5013  add rsp, 0x08
00007d2ed8dd5017  jmp 0x00007D2ED8DD025D
00007d2ed8dd501c  sub rsp, 0x08
00007d2ed8dd5020  push rax
00007d2ed8dd5021  push rcx
00007d2ed8dd5022  push rdx
00007d2ed8dd5023  push rdi
00007d2ed8dd5024  push rsi
00007d2ed8dd5025  push r8
00007d2ed8dd5027  push r9
00007d2ed8dd5029  push r10
00007d2ed8dd502b  push r11
00007d2ed8dd502d  sub rsp, 0xF0
00007d2ed8dd5034  vmovaps [rsp], xmm0
00007d2ed8dd5039  vmovaps [rsp+0x10], xmm1
00007d2ed8dd503f  vmovaps [rsp+0x20], xmm2
00007d2ed8dd5045  vmovaps [rsp+0x30], xmm3
00007d2ed8dd504b  vmovaps [rsp+0x40], xmm4
00007d2ed8dd5051  vmovaps [rsp+0x50], xmm5
00007d2ed8dd5057  vmovaps [rsp+0x60], xmm6
00007d2ed8dd505d  vmovaps [rsp+0x70], xmm7
00007d2ed8dd5063  vmovaps [rsp+0x80], xmm8
00007d2ed8dd506c  vmovaps [rsp+0x90], xmm9
00007d2ed8dd5075  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd507e  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd5087  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd5090  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd5099  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd50a2  sub rsp, 0x30
00007d2ed8dd50a6  movaps [rsp], xmm10
00007d2ed8dd50ab  movaps [rsp+0x10], xmm11
00007d2ed8dd50b1  movaps [rsp+0x20], xmm15
00007d2ed8dd50b7  lea rdi, [rsp]
00007d2ed8dd50bb  mov esi, 0x00
00007d2ed8dd50c0  mov rax, 0x648718324530
00007d2ed8dd50ca  call rax
00007d2ed8dd50cc  movaps xmm10, [rsp]
00007d2ed8dd50d1  add rsp, 0x30
00007d2ed8dd50d5  vmovaps xmm0, [rsp]
00007d2ed8dd50da  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd50e0  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd50e6  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd50ec  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd50f2  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd50f8  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd50fe  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd5104  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd510d  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd5116  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd511f  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd5128  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd5131  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd513a  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd5143  add rsp, 0xF0
00007d2ed8dd514a  pop r11
00007d2ed8dd514c  pop r10
00007d2ed8dd514e  pop r9
00007d2ed8dd5150  pop r8
00007d2ed8dd5152  pop rsi
00007d2ed8dd5153  pop rdi
00007d2ed8dd5154  pop rdx
00007d2ed8dd5155  pop rcx
00007d2ed8dd5156  pop rax
00007d2ed8dd5157  add rsp, 0x08
00007d2ed8dd515b  jmp 0x00007D2ED8DD028B
00007d2ed8dd5160  sub rsp, 0x08
00007d2ed8dd5164  push rax
00007d2ed8dd5165  push rcx
00007d2ed8dd5166  push rdx
00007d2ed8dd5167  push rdi
00007d2ed8dd5168  push rsi
00007d2ed8dd5169  push r8
00007d2ed8dd516b  push r9
00007d2ed8dd516d  push r10
00007d2ed8dd516f  push r11
00007d2ed8dd5171  sub rsp, 0xF0
00007d2ed8dd5178  vmovaps [rsp], xmm0
00007d2ed8dd517d  vmovaps [rsp+0x10], xmm1
00007d2ed8dd5183  vmovaps [rsp+0x20], xmm2
00007d2ed8dd5189  vmovaps [rsp+0x30], xmm3
00007d2ed8dd518f  vmovaps [rsp+0x40], xmm4
00007d2ed8dd5195  vmovaps [rsp+0x50], xmm5
00007d2ed8dd519b  vmovaps [rsp+0x60], xmm6
00007d2ed8dd51a1  vmovaps [rsp+0x70], xmm7
00007d2ed8dd51a7  vmovaps [rsp+0x80], xmm8
00007d2ed8dd51b0  vmovaps [rsp+0x90], xmm9
00007d2ed8dd51b9  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd51c2  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd51cb  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd51d4  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd51dd  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd51e6  sub rsp, 0x30
00007d2ed8dd51ea  movaps [rsp], xmm11
00007d2ed8dd51ef  movaps [rsp+0x10], xmm12
00007d2ed8dd51f5  movaps [rsp+0x20], xmm15
00007d2ed8dd51fb  lea rdi, [rsp]
00007d2ed8dd51ff  mov esi, 0x00
00007d2ed8dd5204  mov rax, 0x648718324530
00007d2ed8dd520e  call rax
00007d2ed8dd5210  movaps xmm11, [rsp]
00007d2ed8dd5215  add rsp, 0x30
00007d2ed8dd5219  vmovaps xmm0, [rsp]
00007d2ed8dd521e  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd5224  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd522a  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd5230  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd5236  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd523c  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd5242  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd5248  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd5251  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd525a  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd5263  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd526c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd5275  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd527e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd5287  add rsp, 0xF0
00007d2ed8dd528e  pop r11
00007d2ed8dd5290  pop r10
00007d2ed8dd5292  pop r9
00007d2ed8dd5294  pop r8
00007d2ed8dd5296  pop rsi
00007d2ed8dd5297  pop rdi
00007d2ed8dd5298  pop rdx
00007d2ed8dd5299  pop rcx
00007d2ed8dd529a  pop rax
00007d2ed8dd529b  add rsp, 0x08
00007d2ed8dd529f  jmp 0x00007D2ED8DD02B9
00007d2ed8dd52a4  sub rsp, 0x08
00007d2ed8dd52a8  push rax
00007d2ed8dd52a9  push rcx
00007d2ed8dd52aa  push rdx
00007d2ed8dd52ab  push rdi
00007d2ed8dd52ac  push rsi
00007d2ed8dd52ad  push r8
00007d2ed8dd52af  push r9
00007d2ed8dd52b1  push r10
00007d2ed8dd52b3  push r11
00007d2ed8dd52b5  sub rsp, 0xF0
00007d2ed8dd52bc  vmovaps [rsp], xmm0
00007d2ed8dd52c1  vmovaps [rsp+0x10], xmm1
00007d2ed8dd52c7  vmovaps [rsp+0x20], xmm2
00007d2ed8dd52cd  vmovaps [rsp+0x30], xmm3
00007d2ed8dd52d3  vmovaps [rsp+0x40], xmm4
00007d2ed8dd52d9  vmovaps [rsp+0x50], xmm5
00007d2ed8dd52df  vmovaps [rsp+0x60], xmm6
00007d2ed8dd52e5  vmovaps [rsp+0x70], xmm7
00007d2ed8dd52eb  vmovaps [rsp+0x80], xmm8
00007d2ed8dd52f4  vmovaps [rsp+0x90], xmm9
00007d2ed8dd52fd  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd5306  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd530f  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd5318  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd5321  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd532a  sub rsp, 0x30
00007d2ed8dd532e  movaps [rsp], xmm15
00007d2ed8dd5333  movaps [rsp+0x10], xmm13
00007d2ed8dd5339  movaps [rsp+0x20], xmm9
00007d2ed8dd533f  lea rdi, [rsp]
00007d2ed8dd5343  mov esi, 0x00
00007d2ed8dd5348  mov rax, 0x648718324530
00007d2ed8dd5352  call rax
00007d2ed8dd5354  movaps xmm15, [rsp]
00007d2ed8dd5359  add rsp, 0x30
00007d2ed8dd535d  vmovaps xmm0, [rsp]
00007d2ed8dd5362  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd5368  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd536e  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd5374  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd537a  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd5380  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd5386  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd538c  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd5395  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd539e  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd53a7  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd53b0  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd53b9  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd53c2  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd53cb  add rsp, 0xF0
00007d2ed8dd53d2  pop r11
00007d2ed8dd53d4  pop r10
00007d2ed8dd53d6  pop r9
00007d2ed8dd53d8  pop r8
00007d2ed8dd53da  pop rsi
00007d2ed8dd53db  pop rdi
00007d2ed8dd53dc  pop rdx
00007d2ed8dd53dd  pop rcx
00007d2ed8dd53de  pop rax
00007d2ed8dd53df  add rsp, 0x08
00007d2ed8dd53e3  jmp 0x00007D2ED8DD02D4
00007d2ed8dd53e8  sub rsp, 0x08
00007d2ed8dd53ec  push rax
00007d2ed8dd53ed  push rcx
00007d2ed8dd53ee  push rdx
00007d2ed8dd53ef  push rdi
00007d2ed8dd53f0  push rsi
00007d2ed8dd53f1  push r8
00007d2ed8dd53f3  push r9
00007d2ed8dd53f5  push r10
00007d2ed8dd53f7  push r11
00007d2ed8dd53f9  sub rsp, 0xF0
00007d2ed8dd5400  vmovaps [rsp], xmm0
00007d2ed8dd5405  vmovaps [rsp+0x10], xmm1
00007d2ed8dd540b  vmovaps [rsp+0x20], xmm2
00007d2ed8dd5411  vmovaps [rsp+0x30], xmm3
00007d2ed8dd5417  vmovaps [rsp+0x40], xmm4
00007d2ed8dd541d  vmovaps [rsp+0x50], xmm5
00007d2ed8dd5423  vmovaps [rsp+0x60], xmm6
00007d2ed8dd5429  vmovaps [rsp+0x70], xmm7
00007d2ed8dd542f  vmovaps [rsp+0x80], xmm8
00007d2ed8dd5438  vmovaps [rsp+0x90], xmm9
00007d2ed8dd5441  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd544a  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd5453  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd545c  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd5465  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd546e  sub rsp, 0x30
00007d2ed8dd5472  movaps [rsp], xmm13
00007d2ed8dd5477  movaps [rsp+0x10], xmm8
00007d2ed8dd547d  movaps [rsp+0x20], xmm14
00007d2ed8dd5483  lea rdi, [rsp]
00007d2ed8dd5487  mov esi, 0x00
00007d2ed8dd548c  mov rax, 0x648718324530
00007d2ed8dd5496  call rax
00007d2ed8dd5498  movaps xmm13, [rsp]
00007d2ed8dd549d  add rsp, 0x30
00007d2ed8dd54a1  vmovaps xmm0, [rsp]
00007d2ed8dd54a6  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd54ac  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd54b2  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd54b8  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd54be  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd54c4  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd54ca  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd54d0  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd54d9  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd54e2  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd54eb  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd54f4  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd54fd  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd5506  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd550f  add rsp, 0xF0
00007d2ed8dd5516  pop r11
00007d2ed8dd5518  pop r10
00007d2ed8dd551a  pop r9
00007d2ed8dd551c  pop r8
00007d2ed8dd551e  pop rsi
00007d2ed8dd551f  pop rdi
00007d2ed8dd5520  pop rdx
00007d2ed8dd5521  pop rcx
00007d2ed8dd5522  pop rax
00007d2ed8dd5523  add rsp, 0x08
00007d2ed8dd5527  jmp 0x00007D2ED8DD02F7
00007d2ed8dd552c  sub rsp, 0x08
00007d2ed8dd5530  push rax
00007d2ed8dd5531  push rcx
00007d2ed8dd5532  push rdx
00007d2ed8dd5533  push rdi
00007d2ed8dd5534  push rsi
00007d2ed8dd5535  push r8
00007d2ed8dd5537  push r9
00007d2ed8dd5539  push r10
00007d2ed8dd553b  push r11
00007d2ed8dd553d  sub rsp, 0xF0
00007d2ed8dd5544  vmovaps [rsp], xmm0
00007d2ed8dd5549  vmovaps [rsp+0x10], xmm1
00007d2ed8dd554f  vmovaps [rsp+0x20], xmm2
00007d2ed8dd5555  vmovaps [rsp+0x30], xmm3
00007d2ed8dd555b  vmovaps [rsp+0x40], xmm4
00007d2ed8dd5561  vmovaps [rsp+0x50], xmm5
00007d2ed8dd5567  vmovaps [rsp+0x60], xmm6
00007d2ed8dd556d  vmovaps [rsp+0x70], xmm7
00007d2ed8dd5573  vmovaps [rsp+0x80], xmm8
00007d2ed8dd557c  vmovaps [rsp+0x90], xmm9
00007d2ed8dd5585  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd558e  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd5597  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd55a0  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd55a9  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd55b2  sub rsp, 0x30
00007d2ed8dd55b6  movaps [rsp], xmm14
00007d2ed8dd55bb  movaps [rsp+0x10], xmm1
00007d2ed8dd55c0  movaps [rsp+0x20], xmm10
00007d2ed8dd55c6  lea rdi, [rsp]
00007d2ed8dd55ca  mov esi, 0x00
00007d2ed8dd55cf  mov rax, 0x648718324530
00007d2ed8dd55d9  call rax
00007d2ed8dd55db  movaps xmm14, [rsp]
00007d2ed8dd55e0  add rsp, 0x30
00007d2ed8dd55e4  vmovaps xmm0, [rsp]
00007d2ed8dd55e9  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd55ef  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd55f5  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd55fb  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd5601  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd5607  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd560d  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd5613  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd561c  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd5625  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd562e  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd5637  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd5640  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd5649  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd5652  add rsp, 0xF0
00007d2ed8dd5659  pop r11
00007d2ed8dd565b  pop r10
00007d2ed8dd565d  pop r9
00007d2ed8dd565f  pop r8
00007d2ed8dd5661  pop rsi
00007d2ed8dd5662  pop rdi
00007d2ed8dd5663  pop rdx
00007d2ed8dd5664  pop rcx
00007d2ed8dd5665  pop rax
00007d2ed8dd5666  add rsp, 0x08
00007d2ed8dd566a  jmp 0x00007D2ED8DD031A
00007d2ed8dd566f  sub rsp, 0x08
00007d2ed8dd5673  push rax
00007d2ed8dd5674  push rcx
00007d2ed8dd5675  push rdx
00007d2ed8dd5676  push rdi
00007d2ed8dd5677  push rsi
00007d2ed8dd5678  push r8
00007d2ed8dd567a  push r9
00007d2ed8dd567c  push r10
00007d2ed8dd567e  push r11
00007d2ed8dd5680  sub rsp, 0xF0
00007d2ed8dd5687  vmovaps [rsp], xmm0
00007d2ed8dd568c  vmovaps [rsp+0x10], xmm2
00007d2ed8dd5692  vmovaps [rsp+0x20], xmm3
00007d2ed8dd5698  vmovaps [rsp+0x30], xmm4
00007d2ed8dd569e  vmovaps [rsp+0x40], xmm5
00007d2ed8dd56a4  vmovaps [rsp+0x50], xmm6
00007d2ed8dd56aa  vmovaps [rsp+0x60], xmm7
00007d2ed8dd56b0  vmovaps [rsp+0x70], xmm8
00007d2ed8dd56b6  vmovaps [rsp+0x80], xmm9
00007d2ed8dd56bf  vmovaps [rsp+0x90], xmm10
00007d2ed8dd56c8  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd56d1  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd56da  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd56e3  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd56ec  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd56f5  sub rsp, 0x30
00007d2ed8dd56f9  movaps [rsp], xmm1
00007d2ed8dd56fd  movaps [rsp+0x10], xmm7
00007d2ed8dd5702  movaps [rsp+0x20], xmm11
00007d2ed8dd5708  lea rdi, [rsp]
00007d2ed8dd570c  mov esi, 0x00
00007d2ed8dd5711  mov rax, 0x648718324530
00007d2ed8dd571b  call rax
00007d2ed8dd571d  movaps xmm1, [rsp]
00007d2ed8dd5721  add rsp, 0x30
00007d2ed8dd5725  vmovaps xmm0, [rsp]
00007d2ed8dd572a  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd5730  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd5736  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd573c  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd5742  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd5748  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd574e  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd5754  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd575d  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd5766  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd576f  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd5778  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd5781  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd578a  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd5793  add rsp, 0xF0
00007d2ed8dd579a  pop r11
00007d2ed8dd579c  pop r10
00007d2ed8dd579e  pop r9
00007d2ed8dd57a0  pop r8
00007d2ed8dd57a2  pop rsi
00007d2ed8dd57a3  pop rdi
00007d2ed8dd57a4  pop rdx
00007d2ed8dd57a5  pop rcx
00007d2ed8dd57a6  pop rax
00007d2ed8dd57a7  add rsp, 0x08
00007d2ed8dd57ab  jmp 0x00007D2ED8DD033B
00007d2ed8dd57b0  call 0x00007D2ED8C0E880
00007d2ed8dd57b5  jmp 0x00007D2ED8DD034E
00007d2ed8dd57ba  call 0x00007D2ED8C0C380
00007d2ed8dd57bf  jmp 0x00007D2ED8DD0359
00007d2ed8dd57c4  call 0x00007D2ED8C0D600
00007d2ed8dd57c9  jmp 0x00007D2ED8DD0364
00007d2ed8dd57ce  call 0x00007D2ED8BFF540
00007d2ed8dd57d3  jmp 0x00007D2ED8DD036F
00007d2ed8dd57d8  int3
00007d2ed8dd57d9  nop [rax], eax
00007d2ed8dd57e0  mov rax, [r15+0x40]
00007d2ed8dd57e4  mov r14, [r15+0x58]
00007d2ed8dd57e8  lea r12, [rax+r14*1]
00007d2ed8dd57ec  movaps xmm1, [r15+0x1D0]
00007d2ed8dd57f4  vmovaps [rsp+0x10], xmm1
00007d2ed8dd57fa  vmovaps xmm15, [rsp+0x10]
00007d2ed8dd5800  por xmm1, xmm15
00007d2ed8dd5805  movaps xmm14, [r15+0x1A0]
00007d2ed8dd580d  vmovaps [rsp+0x10], xmm14
00007d2ed8dd5813  vmovaps xmm13, [rsp+0x10]
00007d2ed8dd5819  por xmm14, xmm13
00007d2ed8dd581e  lea rax, [r12+0x30]
00007d2ed8dd5823  mov r11, [r13+rax*1]
00007d2ed8dd5828  lea rax, [r12+0x38]
00007d2ed8dd582d  mov r10, [r13+rax*1]
00007d2ed8dd5832  movq xmm13, r11
00007d2ed8dd5837  movq xmm12, r10
00007d2ed8dd583c  movq xmm13, xmm13
00007d2ed8dd5841  vmovaps [rsp+0x10], xmm13
00007d2ed8dd5847  movq xmm13, xmm13
00007d2ed8dd584c  movaps [r15+0x130], xmm13
00007d2ed8dd5854  movq xmm12, xmm12
00007d2ed8dd5859  vmovaps [rsp+0x20], xmm12
00007d2ed8dd585f  movq xmm12, xmm12
00007d2ed8dd5864  movaps [r15+0x280], xmm12
00007d2ed8dd586c  movaps xmm13, [r15+0x270]
00007d2ed8dd5874  vmovaps [rsp+0x30], xmm13
00007d2ed8dd587a  vmovaps xmm12, [rsp+0x30]
00007d2ed8dd5880  por xmm13, xmm12
00007d2ed8dd5885  lea rax, [r12+0x20]
00007d2ed8dd588a  mov r11, [r13+rax*1]
00007d2ed8dd588f  lea rax, [r12+0x28]
00007d2ed8dd5894  mov r10, [r13+rax*1]
00007d2ed8dd5899  movq xmm12, r11
00007d2ed8dd589e  movq xmm11, r10
00007d2ed8dd58a3  movq xmm12, xmm12
00007d2ed8dd58a8  vmovaps [rsp+0x30], xmm12
00007d2ed8dd58ae  movq xmm12, xmm12
00007d2ed8dd58b3  movaps [r15+0x150], xmm12
00007d2ed8dd58bb  movq xmm11, xmm11
00007d2ed8dd58c0  vmovaps [rsp+0x40], xmm11
00007d2ed8dd58c6  movq xmm11, xmm11
00007d2ed8dd58cb  movaps [r15+0x140], xmm11
00007d2ed8dd58d3  lea rax, [r12+0x10]
00007d2ed8dd58d8  mov r11, [r13+rax*1]
00007d2ed8dd58dd  lea rax, [r12+0x18]
00007d2ed8dd58e2  mov r10, [r13+rax*1]
00007d2ed8dd58e7  movq xmm12, r11
00007d2ed8dd58ec  movq xmm11, r10
00007d2ed8dd58f1  movq xmm12, xmm12
00007d2ed8dd58f6  vmovaps [rsp+0x50], xmm12
00007d2ed8dd58fc  movq xmm12, xmm12
00007d2ed8dd5901  movaps [r15+0x170], xmm12
00007d2ed8dd5909  movq xmm11, xmm11
00007d2ed8dd590e  vmovaps [rsp+0x60], xmm11
00007d2ed8dd5914  movq xmm11, xmm11
00007d2ed8dd5919  movaps [r15+0x160], xmm11
00007d2ed8dd5921  mov rax, [r13+r12*1]
00007d2ed8dd5926  vmovq xmm12, rax
00007d2ed8dd592b  vpbroadcastq xmm12, xmm12
00007d2ed8dd5930  lea rax, [r12+0x08]
00007d2ed8dd5935  mov r12, [r13+rax*1]
00007d2ed8dd593a  movq xmm11, r12
00007d2ed8dd593f  movaps [r15+0x230], xmm11
00007d2ed8dd5947  mov rax, [r15+0xF8]
00007d2ed8dd594e  lea r12, [rax+0x50]
00007d2ed8dd5952  movups xmm11, [r13+r12*1]
00007d2ed8dd5958  lea r12, [rax+0x60]
00007d2ed8dd595c  movups xmm10, [r13+r12*1]
00007d2ed8dd5962  lea r12, [rax+0x30]
00007d2ed8dd5966  movups xmm9, [r13+r12*1]
00007d2ed8dd596c  mov r12, [r15+0x50]
00007d2ed8dd5970  lea r11, [r12+r14*1]
00007d2ed8dd5974  mov [r15+0x60], r11
00007d2ed8dd5978  lea r12, [r14+0x40]
00007d2ed8dd597c  mov [r15+0x58], r12
00007d2ed8dd5980  movaps xmm8, xmm12
00007d2ed8dd5984  mulpd xmm8, xmm15
00007d2ed8dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007d2ed8dd598f  ptest xmm7, xmm7
00007d2ed8dd5994  jnz 0x00007D2ED8DD67B7
00007d2ed8dd599a  movq xmm15, qword ptr [r15+0x230]
00007d2ed8dd59a3  vmovaps [rsp+0x70], xmm15
00007d2ed8dd59a9  vpermilpd xmm15, xmm15, 0x00
00007d2ed8dd59af  movaps xmm7, xmm9
00007d2ed8dd59b3  mulpd xmm7, xmm15
00007d2ed8dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007d2ed8dd59bd  ptest xmm6, xmm6
00007d2ed8dd59c2  jnz 0x00007D2ED8DD68FB
00007d2ed8dd59c8  vxorps xmm15, xmm15, xmm15
00007d2ed8dd59cd  vpbroadcastq xmm15, xmm15
00007d2ed8dd59d2  movaps xmm9, xmm12
00007d2ed8dd59d6  mulpd xmm9, xmm10
00007d2ed8dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007d2ed8dd59e1  ptest xmm6, xmm6
00007d2ed8dd59e6  jnz 0x00007D2ED8DD6A3D
00007d2ed8dd59ec  movaps xmm10, xmm12
00007d2ed8dd59f0  mulpd xmm10, xmm11
00007d2ed8dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d2ed8dd59fb  ptest xmm6, xmm6
00007d2ed8dd5a00  jnz 0x00007D2ED8DD6B81
00007d2ed8dd5a06  movaps xmm11, [r15+0x1F0]
00007d2ed8dd5a0e  movaps xmm6, xmm12
00007d2ed8dd5a12  mulpd xmm6, xmm11
00007d2ed8dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007d2ed8dd5a1c  ptest xmm5, xmm5
00007d2ed8dd5a21  jnz 0x00007D2ED8DD6CC5
00007d2ed8dd5a27  movaps xmm12, [r15+0x2A0]
00007d2ed8dd5a2f  vmovaps [rsp+0x80], xmm12
00007d2ed8dd5a38  vmovaps xmm11, [rsp+0x80]
00007d2ed8dd5a41  por xmm12, xmm11
00007d2ed8dd5a46  movaps xmm11, [r15+0x250]
00007d2ed8dd5a4e  vmovaps [rsp+0x80], xmm11
00007d2ed8dd5a57  vmovaps xmm5, [rsp+0x80]
00007d2ed8dd5a60  por xmm11, xmm5
00007d2ed8dd5a65  vmovaps xmm4, [rsp+0x70]
00007d2ed8dd5a6b  vpermilpd xmm4, xmm4, 0x00
00007d2ed8dd5a71  movaps xmm3, xmm5
00007d2ed8dd5a74  mulpd xmm3, xmm4
00007d2ed8dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007d2ed8dd5a7d  ptest xmm2, xmm2
00007d2ed8dd5a82  jnz 0x00007D2ED8DD6E07
00007d2ed8dd5a88  mov [rsp+0x80], rax
00007d2ed8dd5a90  xor eax, eax
00007d2ed8dd5a92  mov r14d, 0x200
00007d2ed8dd5a98  cmp r12, r14
00007d2ed8dd5a9b  cmc
00007d2ed8dd5a9c  lahf
00007d2ed8dd5a9d  seto al
00007d2ed8dd5aa0  mov [r15+0x108], eax
00007d2ed8dd5aa7  movaps xmm5, xmm8
00007d2ed8dd5aab  addpd xmm5, xmm15
00007d2ed8dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007d2ed8dd5ab5  ptest xmm4, xmm4
00007d2ed8dd5aba  jnz 0x00007D2ED8DD6F47
00007d2ed8dd5ac0  movaps xmm8, [r15+0x1B0]
00007d2ed8dd5ac8  movaps xmm4, xmm9
00007d2ed8dd5acc  addpd xmm4, xmm8
00007d2ed8dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d2ed8dd5ad6  ptest xmm2, xmm2
00007d2ed8dd5adb  jnz 0x00007D2ED8DD7089
00007d2ed8dd5ae1  movaps xmm9, xmm10
00007d2ed8dd5ae5  addpd xmm9, xmm8
00007d2ed8dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007d2ed8dd5af0  ptest xmm2, xmm2
00007d2ed8dd5af5  jnz 0x00007D2ED8DD71CB
00007d2ed8dd5afb  movaps xmm10, [r15+0x2F0]
00007d2ed8dd5b03  vmovaps [rsp+0x90], xmm10
00007d2ed8dd5b0c  vmovaps xmm8, [rsp+0x90]
00007d2ed8dd5b15  por xmm10, xmm8
00007d2ed8dd5b1a  movaps xmm8, [r15+0x2E0]
00007d2ed8dd5b22  vmovaps [rsp+0x90], xmm8
00007d2ed8dd5b2b  vmovaps xmm2, [rsp+0x90]
00007d2ed8dd5b34  por xmm8, xmm2
00007d2ed8dd5b39  movaps xmm2, [r15+0x2D0]
00007d2ed8dd5b41  vmovaps [rsp+0x90], xmm2
00007d2ed8dd5b4a  vmovaps [rsp+0xA0], xmm1
00007d2ed8dd5b53  vmovaps xmm1, [rsp+0x90]
00007d2ed8dd5b5c  por xmm2, xmm1
00007d2ed8dd5b60  movaps xmm1, [r15+0x200]
00007d2ed8dd5b68  vmovaps [rsp+0x90], xmm1
00007d2ed8dd5b71  vmovaps [rsp+0xB0], xmm15
00007d2ed8dd5b7a  vmovaps xmm15, [rsp+0x90]
00007d2ed8dd5b83  por xmm1, xmm15
00007d2ed8dd5b88  movaps xmm15, [r15+0x1C0]
00007d2ed8dd5b90  vmovaps [rsp+0x90], xmm15
00007d2ed8dd5b99  vmovaps [rsp+0xC0], xmm1
00007d2ed8dd5ba2  vmovaps xmm1, [rsp+0x90]
00007d2ed8dd5bab  por xmm15, xmm1
00007d2ed8dd5bb0  movaps xmm1, [r15+0x190]
00007d2ed8dd5bb8  vmovaps [rsp+0x90], xmm1
00007d2ed8dd5bc1  vmovaps [rsp+0xD0], xmm15
00007d2ed8dd5bca  vmovaps xmm15, [rsp+0x90]
00007d2ed8dd5bd3  por xmm1, xmm15
00007d2ed8dd5bd8  movaps xmm15, [r15+0x300]
00007d2ed8dd5be0  vmovaps [rsp+0x90], xmm15
00007d2ed8dd5be9  vmovaps [rsp+0xE0], xmm1
00007d2ed8dd5bf2  vmovaps xmm1, [rsp+0x90]
00007d2ed8dd5bfb  por xmm15, xmm1
00007d2ed8dd5c00  mov rax, [rsp+0x80]
00007d2ed8dd5c08  lea r14, [rax+0xA0]
00007d2ed8dd5c0f  movups xmm1, [r13+r14*1]
00007d2ed8dd5c15  lea r14, [rax+0xB0]
00007d2ed8dd5c1c  vmovaps [rsp+0x80], xmm1
00007d2ed8dd5c25  movups xmm1, [r13+r14*1]
00007d2ed8dd5c2b  vmovaps [rsp+0x90], xmm1
00007d2ed8dd5c34  vmovaps [rsp+0xF0], xmm15
00007d2ed8dd5c3d  vmovaps xmm15, [rsp+0xB0]
00007d2ed8dd5c46  vmovaps [rsp+0xB0], xmm14
00007d2ed8dd5c4f  movaps xmm1, xmm6
00007d2ed8dd5c52  addpd xmm1, xmm15
00007d2ed8dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007d2ed8dd5c5c  ptest xmm14, xmm14
00007d2ed8dd5c62  jnz 0x00007D2ED8DD7323
00007d2ed8dd5c68  lea r14, [rax+0xF0]
00007d2ed8dd5c6f  movups xmm15, [r13+r14*1]
00007d2ed8dd5c75  movaps xmm14, xmm4
00007d2ed8dd5c79  addpd xmm14, xmm3
00007d2ed8dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d2ed8dd5c84  ptest xmm6, xmm6
00007d2ed8dd5c89  jnz 0x00007D2ED8DD746E
00007d2ed8dd5c8f  movaps xmm6, xmm9
00007d2ed8dd5c93  addpd xmm6, xmm7
00007d2ed8dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007d2ed8dd5c9c  ptest xmm4, xmm4
00007d2ed8dd5ca1  jnz 0x00007D2ED8DD75B0
00007d2ed8dd5ca7  vmovaps xmm9, [rsp+0x70]
00007d2ed8dd5cad  vpermilpd xmm9, xmm9, 0x00
00007d2ed8dd5cb3  vmovaps xmm4, [rsp+0x90]
00007d2ed8dd5cbc  movaps xmm7, xmm4
00007d2ed8dd5cbf  mulpd xmm7, xmm9
00007d2ed8dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d2ed8dd5cc9  ptest xmm3, xmm3
00007d2ed8dd5cce  jnz 0x00007D2ED8DD76F1
00007d2ed8dd5cd4  vmovaps xmm9, [rsp+0x50]
00007d2ed8dd5cda  vpermilpd xmm9, xmm9, 0x00
00007d2ed8dd5ce0  movaps xmm4, xmm15
00007d2ed8dd5ce4  mulpd xmm4, xmm9
00007d2ed8dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d2ed8dd5cee  ptest xmm3, xmm3
00007d2ed8dd5cf3  jnz 0x00007D2ED8DD7832
00007d2ed8dd5cf9  lea r14, [rax+0xE0]
00007d2ed8dd5d00  movups xmm15, [r13+r14*1]
00007d2ed8dd5d06  vmovaps xmm9, [rsp+0x70]
00007d2ed8dd5d0c  vpermilpd xmm9, xmm9, 0x00
00007d2ed8dd5d12  vmovaps [rsp+0x70], xmm1
00007d2ed8dd5d18  vmovaps xmm1, [rsp+0x80]
00007d2ed8dd5d21  vmovaps [rsp+0x80], xmm15
00007d2ed8dd5d2a  movaps xmm3, xmm1
00007d2ed8dd5d2d  mulpd xmm3, xmm9
00007d2ed8dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007d2ed8dd5d37  ptest xmm15, xmm15
00007d2ed8dd5d3d  jnz 0x00007D2ED8DD797E
00007d2ed8dd5d43  vmovaps xmm1, [rsp+0xF0]
00007d2ed8dd5d4c  vmovaps xmm15, [rsp+0xF0]
00007d2ed8dd5d55  por xmm1, xmm15
00007d2ed8dd5d5a  movaps [r15+0x300], xmm1
00007d2ed8dd5d62  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd5d6b  vmovaps xmm9, [rsp+0xE0]
00007d2ed8dd5d74  por xmm15, xmm9
00007d2ed8dd5d79  movaps [r15+0x190], xmm15
00007d2ed8dd5d81  vmovaps xmm9, [rsp+0x50]
00007d2ed8dd5d87  vpermilpd xmm9, xmm9, 0x00
00007d2ed8dd5d8d  vmovaps [rsp+0x90], xmm1
00007d2ed8dd5d96  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd5d9f  vmovaps xmm15, [rsp+0x80]
00007d2ed8dd5da8  vmovaps [rsp+0x80], xmm14
00007d2ed8dd5db1  movaps xmm1, xmm15
00007d2ed8dd5db5  mulpd xmm1, xmm9
00007d2ed8dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007d2ed8dd5dbf  ptest xmm14, xmm14
00007d2ed8dd5dc5  jnz 0x00007D2ED8DD7ABF
00007d2ed8dd5dcb  lea r14, [rax+0x90]
00007d2ed8dd5dd2  movups xmm15, [r13+r14*1]
00007d2ed8dd5dd8  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd5de1  vmovaps xmm9, [rsp+0xD0]
00007d2ed8dd5dea  por xmm14, xmm9
00007d2ed8dd5def  movaps [r15+0x1C0], xmm14
00007d2ed8dd5df7  vmovaps xmm9, [rsp+0xC0]
00007d2ed8dd5e00  vmovaps [rsp+0xD0], xmm1
00007d2ed8dd5e09  vmovaps xmm1, [rsp+0xC0]
00007d2ed8dd5e12  por xmm9, xmm1
00007d2ed8dd5e17  movaps [r15+0x200], xmm9
00007d2ed8dd5e1f  vmovaps [rsp+0xC0], xmm2
00007d2ed8dd5e28  vmovaps xmm1, [rsp+0xC0]
00007d2ed8dd5e31  por xmm2, xmm1
00007d2ed8dd5e35  movaps [r15+0x2D0], xmm2
00007d2ed8dd5e3d  vmovaps [rsp+0xC0], xmm8
00007d2ed8dd5e46  vmovaps xmm1, [rsp+0xC0]
00007d2ed8dd5e4f  por xmm8, xmm1
00007d2ed8dd5e54  movaps [r15+0x2E0], xmm8
00007d2ed8dd5e5c  vmovaps [rsp+0xC0], xmm15
00007d2ed8dd5e65  movaps xmm1, xmm5
00007d2ed8dd5e68  addpd xmm1, xmm7
00007d2ed8dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d2ed8dd5e71  ptest xmm15, xmm15
00007d2ed8dd5e77  jnz 0x00007D2ED8DD7C0B
00007d2ed8dd5e7d  vmovaps xmm15, [rsp+0x50]
00007d2ed8dd5e83  vpermilpd xmm15, xmm15, 0x00
00007d2ed8dd5e89  vmovaps xmm5, [rsp+0xC0]
00007d2ed8dd5e92  vmovaps [rsp+0xC0], xmm1
00007d2ed8dd5e9b  movaps xmm7, xmm5
00007d2ed8dd5e9e  mulpd xmm7, xmm15
00007d2ed8dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007d2ed8dd5ea8  ptest xmm1, xmm1
00007d2ed8dd5ead  jnz 0x00007D2ED8DD7D4B
00007d2ed8dd5eb3  lea r14, [rax+0x80]
00007d2ed8dd5eba  movups xmm1, [r13+r14*1]
00007d2ed8dd5ec0  vmovaps xmm5, [rsp+0x70]
00007d2ed8dd5ec6  vmovaps [rsp+0x70], xmm1
00007d2ed8dd5ecc  movaps xmm15, xmm5
00007d2ed8dd5ed0  addpd xmm15, xmm3
00007d2ed8dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d2ed8dd5edb  ptest xmm1, xmm1
00007d2ed8dd5ee0  jnz 0x00007D2ED8DD7E96
00007d2ed8dd5ee6  vmovaps xmm5, [rsp+0x80]
00007d2ed8dd5eef  movaps xmm1, xmm5
00007d2ed8dd5ef2  addpd xmm1, xmm4
00007d2ed8dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d2ed8dd5efb  ptest xmm3, xmm3
00007d2ed8dd5f00  jnz 0x00007D2ED8DD7FD8
00007d2ed8dd5f06  vmovaps [rsp+0x80], xmm10
00007d2ed8dd5f0f  vmovaps xmm5, [rsp+0x80]
00007d2ed8dd5f18  por xmm10, xmm5
00007d2ed8dd5f1d  movaps [r15+0x2F0], xmm10
00007d2ed8dd5f25  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd5f2b  vpermilpd xmm5, xmm5, 0x00
00007d2ed8dd5f31  vmovaps xmm3, [rsp+0x70]
00007d2ed8dd5f37  vmovaps [rsp+0x50], xmm1
00007d2ed8dd5f3d  movaps xmm4, xmm3
00007d2ed8dd5f40  mulpd xmm4, xmm5
00007d2ed8dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007d2ed8dd5f49  ptest xmm1, xmm1
00007d2ed8dd5f4e  jnz 0x00007D2ED8DD8118
00007d2ed8dd5f54  lea r14, [rax+0xD0]
00007d2ed8dd5f5b  movups xmm1, [r13+r14*1]
00007d2ed8dd5f61  vmovaps xmm3, [rsp+0xD0]
00007d2ed8dd5f6a  vmovaps [rsp+0x70], xmm1
00007d2ed8dd5f70  movaps xmm5, xmm6
00007d2ed8dd5f73  addpd xmm5, xmm3
00007d2ed8dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007d2ed8dd5f7c  ptest xmm1, xmm1
00007d2ed8dd5f81  jnz 0x00007D2ED8DD8262
00007d2ed8dd5f87  vmovaps xmm1, [rsp+0x60]
00007d2ed8dd5f8d  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd5f93  movaps xmm6, xmm9
00007d2ed8dd5f97  mulpd xmm6, xmm1
00007d2ed8dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d2ed8dd5fa0  ptest xmm3, xmm3
00007d2ed8dd5fa5  jnz 0x00007D2ED8DD83A2
00007d2ed8dd5fab  movaps [r15+0x260], xmm6
00007d2ed8dd5fb3  vxorps xmm1, xmm1, xmm1
00007d2ed8dd5fb7  vpbroadcastq xmm1, xmm1
00007d2ed8dd5fbc  movaps [r15+0x1B0], xmm1
00007d2ed8dd5fc4  vmovaps xmm1, [rsp+0x60]
00007d2ed8dd5fca  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd5fd0  vmovaps xmm3, [rsp+0x70]
00007d2ed8dd5fd6  vmovaps [rsp+0x70], xmm15
00007d2ed8dd5fdc  movaps xmm9, xmm3
00007d2ed8dd5fe0  mulpd xmm9, xmm1
00007d2ed8dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d2ed8dd5feb  ptest xmm15, xmm15
00007d2ed8dd5ff1  jnz 0x00007D2ED8DD84E3
00007d2ed8dd5ff7  lea r14, [rax+0xC0]
00007d2ed8dd5ffe  movups xmm1, [r13+r14*1]
00007d2ed8dd6004  vmovaps xmm3, [rsp+0xC0]
00007d2ed8dd600d  vmovaps [rsp+0x80], xmm1
00007d2ed8dd6016  movaps xmm15, xmm3
00007d2ed8dd601a  addpd xmm15, xmm7
00007d2ed8dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007d2ed8dd6025  ptest xmm1, xmm1
00007d2ed8dd602a  jnz 0x00007D2ED8DD862F
00007d2ed8dd6030  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd6039  vmovaps xmm1, [rsp+0xC0]
00007d2ed8dd6042  por xmm13, xmm1
00007d2ed8dd6047  movaps [r15+0x270], xmm13
00007d2ed8dd604f  vmovaps xmm1, [rsp+0xB0]
00007d2ed8dd6058  vmovaps xmm7, [rsp+0xB0]
00007d2ed8dd6061  por xmm1, xmm7
00007d2ed8dd6065  movaps [r15+0x1A0], xmm1
00007d2ed8dd606d  vmovaps xmm1, [rsp+0x60]
00007d2ed8dd6073  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd6079  vmovaps [rsp+0xB0], xmm1
00007d2ed8dd6082  vmovaps xmm1, [rsp+0x80]
00007d2ed8dd608b  vmovaps [rsp+0x80], xmm15
00007d2ed8dd6094  vmovaps xmm15, [rsp+0xB0]
00007d2ed8dd609d  vmovaps [rsp+0xB0], xmm14
00007d2ed8dd60a6  movaps xmm3, xmm1
00007d2ed8dd60a9  mulpd xmm3, xmm15
00007d2ed8dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007d2ed8dd60b3  ptest xmm14, xmm14
00007d2ed8dd60b9  jnz 0x00007D2ED8DD8771
00007d2ed8dd60bf  lea r14, [rax+0x20]
00007d2ed8dd60c3  movups xmm1, [r13+r14*1]
00007d2ed8dd60c9  movaps [r15+0x110], xmm1
00007d2ed8dd60d1  vmovaps xmm14, [rsp+0x70]
00007d2ed8dd60d7  vmovaps [rsp+0x70], xmm1
00007d2ed8dd60dd  movaps xmm15, xmm14
00007d2ed8dd60e1  addpd xmm15, xmm4
00007d2ed8dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d2ed8dd60ec  ptest xmm1, xmm1
00007d2ed8dd60f1  jnz 0x00007D2ED8DD88BC
00007d2ed8dd60f7  vmovaps xmm1, [rsp+0x60]
00007d2ed8dd60fd  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd6103  movaps xmm14, xmm2
00007d2ed8dd6107  mulpd xmm14, xmm1
00007d2ed8dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007d2ed8dd6112  ptest xmm4, xmm4
00007d2ed8dd6117  jnz 0x00007D2ED8DD89FF
00007d2ed8dd611d  vmovaps xmm4, [rsp+0x50]
00007d2ed8dd6123  movaps xmm1, xmm4
00007d2ed8dd6126  addpd xmm1, xmm9
00007d2ed8dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d2ed8dd6130  ptest xmm2, xmm2
00007d2ed8dd6135  jnz 0x00007D2ED8DD8B41
00007d2ed8dd613b  vmovaps xmm9, [rsp+0x30]
00007d2ed8dd6141  vpermilpd xmm9, xmm9, 0x00
00007d2ed8dd6147  vmovaps xmm2, [rsp+0x70]
00007d2ed8dd614d  vmovaps [rsp+0x50], xmm1
00007d2ed8dd6153  movaps xmm4, xmm2
00007d2ed8dd6156  mulpd xmm4, xmm9
00007d2ed8dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d2ed8dd6160  ptest xmm1, xmm1
00007d2ed8dd6165  jnz 0x00007D2ED8DD8C82
00007d2ed8dd616b  vmovaps xmm1, [rsp+0x30]
00007d2ed8dd6171  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd6177  vmovaps xmm2, [rsp+0x90]
00007d2ed8dd6180  vmovaps [rsp+0x60], xmm15
00007d2ed8dd6186  movaps xmm9, xmm2
00007d2ed8dd618a  mulpd xmm9, xmm1
00007d2ed8dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d2ed8dd6195  ptest xmm15, xmm15
00007d2ed8dd619b  jnz 0x00007D2ED8DD8DC3
00007d2ed8dd61a1  vmovaps xmm15, [rsp+0x80]
00007d2ed8dd61aa  movaps xmm1, xmm15
00007d2ed8dd61ae  addpd xmm1, xmm6
00007d2ed8dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007d2ed8dd61b7  ptest xmm2, xmm2
00007d2ed8dd61bc  jnz 0x00007D2ED8DD8F05
00007d2ed8dd61c2  movaps xmm15, xmm5
00007d2ed8dd61c6  addpd xmm15, xmm3
00007d2ed8dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007d2ed8dd61d1  ptest xmm6, xmm6
00007d2ed8dd61d6  jnz 0x00007D2ED8DD9046
00007d2ed8dd61dc  vmovaps xmm6, [rsp+0x30]
00007d2ed8dd61e2  vpermilpd xmm6, xmm6, 0x00
00007d2ed8dd61e8  movaps xmm5, xmm8
00007d2ed8dd61ec  mulpd xmm5, xmm6
00007d2ed8dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d2ed8dd61f5  ptest xmm3, xmm3
00007d2ed8dd61fa  jnz 0x00007D2ED8DD9188
00007d2ed8dd6200  vmovaps xmm8, [rsp+0x30]
00007d2ed8dd6206  vpermilpd xmm8, xmm8, 0x00
00007d2ed8dd620c  movaps xmm6, xmm10
00007d2ed8dd6210  mulpd xmm6, xmm8
00007d2ed8dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007d2ed8dd621a  ptest xmm3, xmm3
00007d2ed8dd621f  jnz 0x00007D2ED8DD92C9
00007d2ed8dd6225  vmovaps xmm8, [rsp+0x60]
00007d2ed8dd622b  movaps xmm10, xmm8
00007d2ed8dd622f  addpd xmm10, xmm14
00007d2ed8dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007d2ed8dd623a  ptest xmm3, xmm3
00007d2ed8dd623f  jnz 0x00007D2ED8DD940B
00007d2ed8dd6245  vmovaps xmm8, [rsp+0x50]
00007d2ed8dd624b  movaps xmm14, xmm8
00007d2ed8dd624f  addpd xmm14, xmm4
00007d2ed8dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007d2ed8dd625a  ptest xmm3, xmm3
00007d2ed8dd625f  jnz 0x00007D2ED8DD954F
00007d2ed8dd6265  vmovaps xmm8, [rsp+0x40]
00007d2ed8dd626b  vpermilpd xmm8, xmm8, 0x00
00007d2ed8dd6271  movaps xmm4, xmm13
00007d2ed8dd6275  mulpd xmm4, xmm8
00007d2ed8dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d2ed8dd627f  ptest xmm3, xmm3
00007d2ed8dd6284  jnz 0x00007D2ED8DD9692
00007d2ed8dd628a  movaps xmm13, xmm15
00007d2ed8dd628e  addpd xmm13, xmm9
00007d2ed8dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007d2ed8dd6299  ptest xmm8, xmm8
00007d2ed8dd629f  jnz 0x00007D2ED8DD97D4
00007d2ed8dd62a5  movaps xmm15, xmm1
00007d2ed8dd62a9  addpd xmm15, xmm5
00007d2ed8dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007d2ed8dd62b4  ptest xmm9, xmm9
00007d2ed8dd62ba  jnz 0x00007D2ED8DD9918
00007d2ed8dd62c0  vmovaps [rsp+0x30], xmm11
00007d2ed8dd62c6  vmovaps xmm1, [rsp+0x30]
00007d2ed8dd62cc  por xmm11, xmm1
00007d2ed8dd62d1  movaps [r15+0x250], xmm11
00007d2ed8dd62d9  vmovaps [rsp+0x30], xmm12
00007d2ed8dd62df  vmovaps xmm1, [rsp+0x30]
00007d2ed8dd62e5  por xmm12, xmm1
00007d2ed8dd62ea  movaps [r15+0x2A0], xmm12
00007d2ed8dd62f2  vmovaps xmm1, [rsp+0xA0]
00007d2ed8dd62fb  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd6304  por xmm1, xmm11
00007d2ed8dd6309  movaps [r15+0x1D0], xmm1
00007d2ed8dd6311  lea r14, [rax+0x40]
00007d2ed8dd6315  movups xmm1, [r13+r14*1]
00007d2ed8dd631b  movaps [r15+0x2C0], xmm1
00007d2ed8dd6323  vmovaps xmm11, [rsp+0x40]
00007d2ed8dd6329  vpermilpd xmm11, xmm11, 0x00
00007d2ed8dd632f  vmovaps xmm8, [rsp+0xE0]
00007d2ed8dd6338  movaps xmm9, xmm8
00007d2ed8dd633c  mulpd xmm9, xmm11
00007d2ed8dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007d2ed8dd6347  ptest xmm5, xmm5
00007d2ed8dd634c  jnz 0x00007D2ED8DD9A64
00007d2ed8dd6352  movaps xmm11, xmm10
00007d2ed8dd6356  addpd xmm11, xmm6
00007d2ed8dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d2ed8dd6361  ptest xmm8, xmm8
00007d2ed8dd6367  jnz 0x00007D2ED8DD9BA8
00007d2ed8dd636d  movaps xmm10, xmm14
00007d2ed8dd6371  addpd xmm10, xmm4
00007d2ed8dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007d2ed8dd637c  ptest xmm8, xmm8
00007d2ed8dd6382  jnz 0x00007D2ED8DD9CEB
00007d2ed8dd6388  vmovaps xmm14, [rsp+0x40]
00007d2ed8dd638e  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dd6394  movaps xmm8, xmm1
00007d2ed8dd6398  mulpd xmm8, xmm14
00007d2ed8dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d2ed8dd63a3  ptest xmm6, xmm6
00007d2ed8dd63a8  jnz 0x00007D2ED8DD9E2E
00007d2ed8dd63ae  movaps xmm1, [r15+0x2B0]
00007d2ed8dd63b6  vmovaps xmm14, [rsp+0x40]
00007d2ed8dd63bc  vpermilpd xmm14, xmm14, 0x00
00007d2ed8dd63c2  movaps xmm6, xmm1
00007d2ed8dd63c5  mulpd xmm6, xmm14
00007d2ed8dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007d2ed8dd63cf  ptest xmm5, xmm5
00007d2ed8dd63d4  jnz 0x00007D2ED8DD9F71
00007d2ed8dd63da  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd63e0  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd63e6  movaps xmm14, xmm12
00007d2ed8dd63ea  mulpd xmm14, xmm1
00007d2ed8dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007d2ed8dd63f5  ptest xmm5, xmm5
00007d2ed8dd63fa  jnz 0x00007D2ED8DDA0B2
00007d2ed8dd6400  movaps xmm1, xmm13
00007d2ed8dd6404  addpd xmm1, xmm9
00007d2ed8dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007d2ed8dd640e  ptest xmm12, xmm12
00007d2ed8dd6414  jnz 0x00007D2ED8DDA1F5
00007d2ed8dd641a  vmovaps xmm13, [rsp+0x10]
00007d2ed8dd6420  vpermilpd xmm13, xmm13, 0x00
00007d2ed8dd6426  movaps xmm12, xmm7
00007d2ed8dd642a  mulpd xmm12, xmm13
00007d2ed8dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d2ed8dd6435  ptest xmm9, xmm9
00007d2ed8dd643b  jnz 0x00007D2ED8DDA337
00007d2ed8dd6441  movaps xmm13, xmm15
00007d2ed8dd6445  addpd xmm13, xmm8
00007d2ed8dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d2ed8dd6450  ptest xmm9, xmm9
00007d2ed8dd6456  jnz 0x00007D2ED8DDA47A
00007d2ed8dd645c  movaps xmm15, [r15+0x290]
00007d2ed8dd6464  vmovaps xmm9, [rsp+0x10]
00007d2ed8dd646a  vpermilpd xmm9, xmm9, 0x00
00007d2ed8dd6470  movaps xmm8, xmm15
00007d2ed8dd6474  mulpd xmm8, xmm9
00007d2ed8dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007d2ed8dd647f  ptest xmm7, xmm7
00007d2ed8dd6484  jnz 0x00007D2ED8DDA5BE
00007d2ed8dd648a  movaps xmm15, xmm11
00007d2ed8dd648e  addpd xmm15, xmm6
00007d2ed8dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007d2ed8dd6499  ptest xmm9, xmm9
00007d2ed8dd649f  jnz 0x00007D2ED8DDA702
00007d2ed8dd64a5  movaps xmm11, [r15+0x1E0]
00007d2ed8dd64ad  vmovaps xmm9, [rsp+0x10]
00007d2ed8dd64b3  vpermilpd xmm9, xmm9, 0x00
00007d2ed8dd64b9  movaps xmm7, xmm11
00007d2ed8dd64bd  mulpd xmm7, xmm9
00007d2ed8dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d2ed8dd64c7  ptest xmm6, xmm6
00007d2ed8dd64cc  jnz 0x00007D2ED8DDA845
00007d2ed8dd64d2  movaps xmm11, xmm10
00007d2ed8dd64d6  addpd xmm11, xmm14
00007d2ed8dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007d2ed8dd64e1  ptest xmm9, xmm9
00007d2ed8dd64e7  jnz 0x00007D2ED8DDA987
00007d2ed8dd64ed  lea r14, [rax+0x70]
00007d2ed8dd64f1  movups xmm14, [r13+r14*1]
00007d2ed8dd64f7  movaps [r15+0x240], xmm14
00007d2ed8dd64ff  movaps xmm10, xmm1
00007d2ed8dd6503  addpd xmm10, xmm12
00007d2ed8dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007d2ed8dd650e  ptest xmm9, xmm9
00007d2ed8dd6514  jnz 0x00007D2ED8DDAAD5
00007d2ed8dd651a  movaps [r15+0x170], xmm10
00007d2ed8dd6522  vmovaps xmm1, [rsp+0x20]
00007d2ed8dd6528  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd652e  movaps xmm12, xmm14
00007d2ed8dd6532  mulpd xmm12, xmm1
00007d2ed8dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007d2ed8dd653d  ptest xmm9, xmm9
00007d2ed8dd6543  jnz 0x00007D2ED8DDAC18
00007d2ed8dd6549  vmovaps xmm1, [rsp+0x20]
00007d2ed8dd654f  vpermilpd xmm1, xmm1, 0x00
00007d2ed8dd6555  vmovaps xmm9, [rsp+0xB0]
00007d2ed8dd655e  movaps xmm14, xmm9
00007d2ed8dd6562  mulpd xmm14, xmm1
00007d2ed8dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007d2ed8dd656d  ptest xmm6, xmm6
00007d2ed8dd6572  jnz 0x00007D2ED8DDAD5B
00007d2ed8dd6578  movaps [r15+0x180], xmm14
00007d2ed8dd6580  movaps xmm1, xmm13
00007d2ed8dd6584  addpd xmm1, xmm8
00007d2ed8dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007d2ed8dd658e  ptest xmm9, xmm9
00007d2ed8dd6594  jnz 0x00007D2ED8DDAE9E
00007d2ed8dd659a  movaps [r15+0x210], xmm1
00007d2ed8dd65a2  movups xmm13, [r13+rax*1]
00007d2ed8dd65a8  lea r14, [rax+0x10]
00007d2ed8dd65ac  movups xmm9, [r13+r14*1]
00007d2ed8dd65b2  movaps [r15+0x230], xmm9
00007d2ed8dd65ba  movaps xmm8, xmm15
00007d2ed8dd65be  addpd xmm8, xmm7
00007d2ed8dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d2ed8dd65c9  ptest xmm6, xmm6
00007d2ed8dd65ce  jnz 0x00007D2ED8DDAFF4
00007d2ed8dd65d4  movaps [r15+0x130], xmm8
00007d2ed8dd65dc  vmovaps xmm15, [rsp+0x20]
00007d2ed8dd65e2  vpermilpd xmm15, xmm15, 0x00
00007d2ed8dd65e8  movaps xmm7, xmm9
00007d2ed8dd65ec  mulpd xmm7, xmm15
00007d2ed8dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d2ed8dd65f6  ptest xmm6, xmm6
00007d2ed8dd65fb  jnz 0x00007D2ED8DDB137
00007d2ed8dd6601  movaps [r15+0x220], xmm7
00007d2ed8dd6609  vmovaps xmm15, [rsp+0x20]
00007d2ed8dd660f  vpermilpd xmm15, xmm15, 0x00
00007d2ed8dd6615  movaps xmm9, xmm13
00007d2ed8dd6619  mulpd xmm9, xmm15
00007d2ed8dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007d2ed8dd6624  ptest xmm6, xmm6
00007d2ed8dd6629  jnz 0x00007D2ED8DDB279
00007d2ed8dd662f  movaps xmm15, xmm11
00007d2ed8dd6633  addpd xmm15, xmm12
00007d2ed8dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007d2ed8dd663e  ptest xmm13, xmm13
00007d2ed8dd6644  jnz 0x00007D2ED8DDB3BD
00007d2ed8dd664a  movaps [r15+0x140], xmm15
00007d2ed8dd6652  movaps xmm13, xmm10
00007d2ed8dd6656  addpd xmm13, xmm14
00007d2ed8dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d2ed8dd6661  ptest xmm12, xmm12
00007d2ed8dd6667  jnz 0x00007D2ED8DDB501
00007d2ed8dd666d  movaps [r15+0x150], xmm13
00007d2ed8dd6675  movaps xmm14, xmm1
00007d2ed8dd6679  addpd xmm14, xmm7
00007d2ed8dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d2ed8dd6684  ptest xmm12, xmm12
00007d2ed8dd668a  jnz 0x00007D2ED8DDB645
00007d2ed8dd6690  movaps [r15+0x160], xmm14
00007d2ed8dd6698  movaps xmm1, xmm8
00007d2ed8dd669c  addpd xmm1, xmm9
00007d2ed8dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007d2ed8dd66a6  ptest xmm12, xmm12
00007d2ed8dd66ac  jnz 0x00007D2ED8DDB787
00007d2ed8dd66b2  movaps [r15+0x120], xmm1
00007d2ed8dd66ba  movups [r13+r11*1], xmm15
00007d2ed8dd66c0  lea rax, [r11+0x10]
00007d2ed8dd66c4  movups [r13+rax*1], xmm13
00007d2ed8dd66ca  lea rax, [r11+0x20]
00007d2ed8dd66ce  movups [r13+rax*1], xmm14
00007d2ed8dd66d4  lea rax, [r11+0x30]
00007d2ed8dd66d8  movups [r13+rax*1], xmm1
00007d2ed8dd66de  mov eax, [r15+0x108]
00007d2ed8dd66e5  sahf
00007d2ed8dd66e6  jnz 0x00007D2ED8DD6718
00007d2ed8dd66e8  cmp dword ptr [r15+0x318], 0x00
00007d2ed8dd66f0  jz 0x00007D2ED8DDB900
00007d2ed8dd66f6  nop [rax+rax*1], ax
00007d2ed8dd66ff  nop [rax+rax*1], eax
00007d2ed8dd6707  mov eax, 0x410444
00007d2ed8dd670c  mov [r15+0x100], rax
00007d2ed8dd6713  jmp 0x00007D2ED8BFE110
00007d2ed8dd6718  cmp dword ptr [r15+0x318], 0x00
00007d2ed8dd6720  jz 0x00007D2ED8DD57E0
00007d2ed8dd6726  nop [rax+rax*1], ax
00007d2ed8dd672f  nop [rax+rax*1], eax
00007d2ed8dd6737  mov eax, 0x410278
00007d2ed8dd673c  mov [r15+0x100], rax
00007d2ed8dd6743  jmp 0x00007D2ED8BFE110
00007d2ed8dd6748  int3
00007d2ed8dd6749  call 0x00007D2ED8C0A4B0
00007d2ed8dd674e  jmp 0x00007D2ED8DD5828
00007d2ed8dd6753  call 0x00007D2ED8C09240
00007d2ed8dd6758  jmp 0x00007D2ED8DD5832
00007d2ed8dd675d  call 0x00007D2ED8C0A4B0
00007d2ed8dd6762  jmp 0x00007D2ED8DD588F
00007d2ed8dd6767  call 0x00007D2ED8C09240
00007d2ed8dd676c  jmp 0x00007D2ED8DD5899
00007d2ed8dd6771  call 0x00007D2ED8C0A4B0
00007d2ed8dd6776  jmp 0x00007D2ED8DD58DD
00007d2ed8dd677b  call 0x00007D2ED8C09240
00007d2ed8dd6780  jmp 0x00007D2ED8DD58E7
00007d2ed8dd6785  call 0x00007D2ED8CB47C0
00007d2ed8dd678a  jmp 0x00007D2ED8DD5926
00007d2ed8dd678f  call 0x00007D2ED8C0B720
00007d2ed8dd6794  jmp 0x00007D2ED8DD593A
00007d2ed8dd6799  call 0x00007D2ED8CBFC30
00007d2ed8dd679e  jmp 0x00007D2ED8DD5958
00007d2ed8dd67a3  call 0x00007D2ED8CBE9C0
00007d2ed8dd67a8  jmp 0x00007D2ED8DD5962
00007d2ed8dd67ad  call 0x00007D2ED8CBD750
00007d2ed8dd67b2  jmp 0x00007D2ED8DD596C
00007d2ed8dd67b7  sub rsp, 0x08
00007d2ed8dd67bb  push rax
00007d2ed8dd67bc  push rcx
00007d2ed8dd67bd  push rdx
00007d2ed8dd67be  push rdi
00007d2ed8dd67bf  push rsi
00007d2ed8dd67c0  push r8
00007d2ed8dd67c2  push r9
00007d2ed8dd67c4  push r10
00007d2ed8dd67c6  push r11
00007d2ed8dd67c8  sub rsp, 0xF0
00007d2ed8dd67cf  vmovaps [rsp], xmm0
00007d2ed8dd67d4  vmovaps [rsp+0x10], xmm1
00007d2ed8dd67da  vmovaps [rsp+0x20], xmm2
00007d2ed8dd67e0  vmovaps [rsp+0x30], xmm3
00007d2ed8dd67e6  vmovaps [rsp+0x40], xmm4
00007d2ed8dd67ec  vmovaps [rsp+0x50], xmm5
00007d2ed8dd67f2  vmovaps [rsp+0x60], xmm6
00007d2ed8dd67f8  vmovaps [rsp+0x70], xmm7
00007d2ed8dd67fe  vmovaps [rsp+0x80], xmm9
00007d2ed8dd6807  vmovaps [rsp+0x90], xmm10
00007d2ed8dd6810  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd6819  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd6822  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd682b  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd6834  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd683d  sub rsp, 0x30
00007d2ed8dd6841  movaps [rsp], xmm8
00007d2ed8dd6846  movaps [rsp+0x10], xmm12
00007d2ed8dd684c  movaps [rsp+0x20], xmm15
00007d2ed8dd6852  lea rdi, [rsp]
00007d2ed8dd6856  mov esi, 0x00
00007d2ed8dd685b  mov rax, 0x648718324530
00007d2ed8dd6865  call rax
00007d2ed8dd6867  movaps xmm8, [rsp]
00007d2ed8dd686c  add rsp, 0x30
00007d2ed8dd6870  vmovaps xmm0, [rsp]
00007d2ed8dd6875  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd687b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd6881  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd6887  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd688d  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd6893  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd6899  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd689f  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd68a8  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd68b1  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd68ba  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd68c3  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd68cc  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd68d5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd68de  add rsp, 0xF0
00007d2ed8dd68e5  pop r11
00007d2ed8dd68e7  pop r10
00007d2ed8dd68e9  pop r9
00007d2ed8dd68eb  pop r8
00007d2ed8dd68ed  pop rsi
00007d2ed8dd68ee  pop rdi
00007d2ed8dd68ef  pop rdx
00007d2ed8dd68f0  pop rcx
00007d2ed8dd68f1  pop rax
00007d2ed8dd68f2  add rsp, 0x08
00007d2ed8dd68f6  jmp 0x00007D2ED8DD599A
00007d2ed8dd68fb  sub rsp, 0x08
00007d2ed8dd68ff  push rax
00007d2ed8dd6900  push rcx
00007d2ed8dd6901  push rdx
00007d2ed8dd6902  push rdi
00007d2ed8dd6903  push rsi
00007d2ed8dd6904  push r8
00007d2ed8dd6906  push r9
00007d2ed8dd6908  push r10
00007d2ed8dd690a  push r11
00007d2ed8dd690c  sub rsp, 0xF0
00007d2ed8dd6913  vmovaps [rsp], xmm0
00007d2ed8dd6918  vmovaps [rsp+0x10], xmm1
00007d2ed8dd691e  vmovaps [rsp+0x20], xmm2
00007d2ed8dd6924  vmovaps [rsp+0x30], xmm3
00007d2ed8dd692a  vmovaps [rsp+0x40], xmm4
00007d2ed8dd6930  vmovaps [rsp+0x50], xmm5
00007d2ed8dd6936  vmovaps [rsp+0x60], xmm6
00007d2ed8dd693c  vmovaps [rsp+0x70], xmm8
00007d2ed8dd6942  vmovaps [rsp+0x80], xmm9
00007d2ed8dd694b  vmovaps [rsp+0x90], xmm10
00007d2ed8dd6954  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd695d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd6966  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd696f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd6978  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd6981  sub rsp, 0x30
00007d2ed8dd6985  movaps [rsp], xmm7
00007d2ed8dd6989  movaps [rsp+0x10], xmm9
00007d2ed8dd698f  movaps [rsp+0x20], xmm15
00007d2ed8dd6995  lea rdi, [rsp]
00007d2ed8dd6999  mov esi, 0x00
00007d2ed8dd699e  mov rax, 0x648718324530
00007d2ed8dd69a8  call rax
00007d2ed8dd69aa  movaps xmm7, [rsp]
00007d2ed8dd69ae  add rsp, 0x30
00007d2ed8dd69b2  vmovaps xmm0, [rsp]
00007d2ed8dd69b7  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd69bd  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd69c3  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd69c9  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd69cf  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd69d5  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd69db  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd69e1  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd69ea  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd69f3  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd69fc  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd6a05  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd6a0e  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd6a17  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd6a20  add rsp, 0xF0
00007d2ed8dd6a27  pop r11
00007d2ed8dd6a29  pop r10
00007d2ed8dd6a2b  pop r9
00007d2ed8dd6a2d  pop r8
00007d2ed8dd6a2f  pop rsi
00007d2ed8dd6a30  pop rdi
00007d2ed8dd6a31  pop rdx
00007d2ed8dd6a32  pop rcx
00007d2ed8dd6a33  pop rax
00007d2ed8dd6a34  add rsp, 0x08
00007d2ed8dd6a38  jmp 0x00007D2ED8DD59C8
00007d2ed8dd6a3d  sub rsp, 0x08
00007d2ed8dd6a41  push rax
00007d2ed8dd6a42  push rcx
00007d2ed8dd6a43  push rdx
00007d2ed8dd6a44  push rdi
00007d2ed8dd6a45  push rsi
00007d2ed8dd6a46  push r8
00007d2ed8dd6a48  push r9
00007d2ed8dd6a4a  push r10
00007d2ed8dd6a4c  push r11
00007d2ed8dd6a4e  sub rsp, 0xF0
00007d2ed8dd6a55  vmovaps [rsp], xmm0
00007d2ed8dd6a5a  vmovaps [rsp+0x10], xmm1
00007d2ed8dd6a60  vmovaps [rsp+0x20], xmm2
00007d2ed8dd6a66  vmovaps [rsp+0x30], xmm3
00007d2ed8dd6a6c  vmovaps [rsp+0x40], xmm4
00007d2ed8dd6a72  vmovaps [rsp+0x50], xmm5
00007d2ed8dd6a78  vmovaps [rsp+0x60], xmm6
00007d2ed8dd6a7e  vmovaps [rsp+0x70], xmm7
00007d2ed8dd6a84  vmovaps [rsp+0x80], xmm8
00007d2ed8dd6a8d  vmovaps [rsp+0x90], xmm10
00007d2ed8dd6a96  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd6a9f  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd6aa8  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd6ab1  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd6aba  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd6ac3  sub rsp, 0x30
00007d2ed8dd6ac7  movaps [rsp], xmm9
00007d2ed8dd6acc  movaps [rsp+0x10], xmm12
00007d2ed8dd6ad2  movaps [rsp+0x20], xmm10
00007d2ed8dd6ad8  lea rdi, [rsp]
00007d2ed8dd6adc  mov esi, 0x00
00007d2ed8dd6ae1  mov rax, 0x648718324530
00007d2ed8dd6aeb  call rax
00007d2ed8dd6aed  movaps xmm9, [rsp]
00007d2ed8dd6af2  add rsp, 0x30
00007d2ed8dd6af6  vmovaps xmm0, [rsp]
00007d2ed8dd6afb  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd6b01  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd6b07  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd6b0d  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd6b13  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd6b19  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd6b1f  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd6b25  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd6b2e  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd6b37  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd6b40  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd6b49  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd6b52  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd6b5b  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd6b64  add rsp, 0xF0
00007d2ed8dd6b6b  pop r11
00007d2ed8dd6b6d  pop r10
00007d2ed8dd6b6f  pop r9
00007d2ed8dd6b71  pop r8
00007d2ed8dd6b73  pop rsi
00007d2ed8dd6b74  pop rdi
00007d2ed8dd6b75  pop rdx
00007d2ed8dd6b76  pop rcx
00007d2ed8dd6b77  pop rax
00007d2ed8dd6b78  add rsp, 0x08
00007d2ed8dd6b7c  jmp 0x00007D2ED8DD59EC
00007d2ed8dd6b81  sub rsp, 0x08
00007d2ed8dd6b85  push rax
00007d2ed8dd6b86  push rcx
00007d2ed8dd6b87  push rdx
00007d2ed8dd6b88  push rdi
00007d2ed8dd6b89  push rsi
00007d2ed8dd6b8a  push r8
00007d2ed8dd6b8c  push r9
00007d2ed8dd6b8e  push r10
00007d2ed8dd6b90  push r11
00007d2ed8dd6b92  sub rsp, 0xF0
00007d2ed8dd6b99  vmovaps [rsp], xmm0
00007d2ed8dd6b9e  vmovaps [rsp+0x10], xmm1
00007d2ed8dd6ba4  vmovaps [rsp+0x20], xmm2
00007d2ed8dd6baa  vmovaps [rsp+0x30], xmm3
00007d2ed8dd6bb0  vmovaps [rsp+0x40], xmm4
00007d2ed8dd6bb6  vmovaps [rsp+0x50], xmm5
00007d2ed8dd6bbc  vmovaps [rsp+0x60], xmm6
00007d2ed8dd6bc2  vmovaps [rsp+0x70], xmm7
00007d2ed8dd6bc8  vmovaps [rsp+0x80], xmm8
00007d2ed8dd6bd1  vmovaps [rsp+0x90], xmm9
00007d2ed8dd6bda  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd6be3  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd6bec  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd6bf5  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd6bfe  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd6c07  sub rsp, 0x30
00007d2ed8dd6c0b  movaps [rsp], xmm10
00007d2ed8dd6c10  movaps [rsp+0x10], xmm12
00007d2ed8dd6c16  movaps [rsp+0x20], xmm11
00007d2ed8dd6c1c  lea rdi, [rsp]
00007d2ed8dd6c20  mov esi, 0x00
00007d2ed8dd6c25  mov rax, 0x648718324530
00007d2ed8dd6c2f  call rax
00007d2ed8dd6c31  movaps xmm10, [rsp]
00007d2ed8dd6c36  add rsp, 0x30
00007d2ed8dd6c3a  vmovaps xmm0, [rsp]
00007d2ed8dd6c3f  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd6c45  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd6c4b  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd6c51  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd6c57  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd6c5d  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd6c63  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd6c69  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd6c72  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd6c7b  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd6c84  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd6c8d  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd6c96  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd6c9f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd6ca8  add rsp, 0xF0
00007d2ed8dd6caf  pop r11
00007d2ed8dd6cb1  pop r10
00007d2ed8dd6cb3  pop r9
00007d2ed8dd6cb5  pop r8
00007d2ed8dd6cb7  pop rsi
00007d2ed8dd6cb8  pop rdi
00007d2ed8dd6cb9  pop rdx
00007d2ed8dd6cba  pop rcx
00007d2ed8dd6cbb  pop rax
00007d2ed8dd6cbc  add rsp, 0x08
00007d2ed8dd6cc0  jmp 0x00007D2ED8DD5A06
00007d2ed8dd6cc5  sub rsp, 0x08
00007d2ed8dd6cc9  push rax
00007d2ed8dd6cca  push rcx
00007d2ed8dd6ccb  push rdx
00007d2ed8dd6ccc  push rdi
00007d2ed8dd6ccd  push rsi
00007d2ed8dd6cce  push r8
00007d2ed8dd6cd0  push r9
00007d2ed8dd6cd2  push r10
00007d2ed8dd6cd4  push r11
00007d2ed8dd6cd6  sub rsp, 0xF0
00007d2ed8dd6cdd  vmovaps [rsp], xmm0
00007d2ed8dd6ce2  vmovaps [rsp+0x10], xmm1
00007d2ed8dd6ce8  vmovaps [rsp+0x20], xmm2
00007d2ed8dd6cee  vmovaps [rsp+0x30], xmm3
00007d2ed8dd6cf4  vmovaps [rsp+0x40], xmm4
00007d2ed8dd6cfa  vmovaps [rsp+0x50], xmm5
00007d2ed8dd6d00  vmovaps [rsp+0x60], xmm7
00007d2ed8dd6d06  vmovaps [rsp+0x70], xmm8
00007d2ed8dd6d0c  vmovaps [rsp+0x80], xmm9
00007d2ed8dd6d15  vmovaps [rsp+0x90], xmm10
00007d2ed8dd6d1e  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd6d27  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd6d30  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd6d39  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd6d42  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd6d4b  sub rsp, 0x30
00007d2ed8dd6d4f  movaps [rsp], xmm6
00007d2ed8dd6d53  movaps [rsp+0x10], xmm12
00007d2ed8dd6d59  movaps [rsp+0x20], xmm11
00007d2ed8dd6d5f  lea rdi, [rsp]
00007d2ed8dd6d63  mov esi, 0x00
00007d2ed8dd6d68  mov rax, 0x648718324530
00007d2ed8dd6d72  call rax
00007d2ed8dd6d74  movaps xmm6, [rsp]
00007d2ed8dd6d78  add rsp, 0x30
00007d2ed8dd6d7c  vmovaps xmm0, [rsp]
00007d2ed8dd6d81  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd6d87  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd6d8d  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd6d93  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd6d99  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd6d9f  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd6da5  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd6dab  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd6db4  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd6dbd  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd6dc6  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd6dcf  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd6dd8  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd6de1  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd6dea  add rsp, 0xF0
00007d2ed8dd6df1  pop r11
00007d2ed8dd6df3  pop r10
00007d2ed8dd6df5  pop r9
00007d2ed8dd6df7  pop r8
00007d2ed8dd6df9  pop rsi
00007d2ed8dd6dfa  pop rdi
00007d2ed8dd6dfb  pop rdx
00007d2ed8dd6dfc  pop rcx
00007d2ed8dd6dfd  pop rax
00007d2ed8dd6dfe  add rsp, 0x08
00007d2ed8dd6e02  jmp 0x00007D2ED8DD5A27
00007d2ed8dd6e07  sub rsp, 0x08
00007d2ed8dd6e0b  push rax
00007d2ed8dd6e0c  push rcx
00007d2ed8dd6e0d  push rdx
00007d2ed8dd6e0e  push rdi
00007d2ed8dd6e0f  push rsi
00007d2ed8dd6e10  push r8
00007d2ed8dd6e12  push r9
00007d2ed8dd6e14  push r10
00007d2ed8dd6e16  push r11
00007d2ed8dd6e18  sub rsp, 0xF0
00007d2ed8dd6e1f  vmovaps [rsp], xmm0
00007d2ed8dd6e24  vmovaps [rsp+0x10], xmm1
00007d2ed8dd6e2a  vmovaps [rsp+0x20], xmm2
00007d2ed8dd6e30  vmovaps [rsp+0x30], xmm4
00007d2ed8dd6e36  vmovaps [rsp+0x40], xmm5
00007d2ed8dd6e3c  vmovaps [rsp+0x50], xmm6
00007d2ed8dd6e42  vmovaps [rsp+0x60], xmm7
00007d2ed8dd6e48  vmovaps [rsp+0x70], xmm8
00007d2ed8dd6e4e  vmovaps [rsp+0x80], xmm9
00007d2ed8dd6e57  vmovaps [rsp+0x90], xmm10
00007d2ed8dd6e60  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd6e69  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd6e72  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd6e7b  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd6e84  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd6e8d  sub rsp, 0x30
00007d2ed8dd6e91  movaps [rsp], xmm3
00007d2ed8dd6e95  movaps [rsp+0x10], xmm5
00007d2ed8dd6e9a  movaps [rsp+0x20], xmm4
00007d2ed8dd6e9f  lea rdi, [rsp]
00007d2ed8dd6ea3  mov esi, 0x00
00007d2ed8dd6ea8  mov rax, 0x648718324530
00007d2ed8dd6eb2  call rax
00007d2ed8dd6eb4  movaps xmm3, [rsp]
00007d2ed8dd6eb8  add rsp, 0x30
00007d2ed8dd6ebc  vmovaps xmm0, [rsp]
00007d2ed8dd6ec1  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd6ec7  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd6ecd  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd6ed3  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd6ed9  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd6edf  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd6ee5  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd6eeb  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd6ef4  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd6efd  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd6f06  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd6f0f  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd6f18  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd6f21  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd6f2a  add rsp, 0xF0
00007d2ed8dd6f31  pop r11
00007d2ed8dd6f33  pop r10
00007d2ed8dd6f35  pop r9
00007d2ed8dd6f37  pop r8
00007d2ed8dd6f39  pop rsi
00007d2ed8dd6f3a  pop rdi
00007d2ed8dd6f3b  pop rdx
00007d2ed8dd6f3c  pop rcx
00007d2ed8dd6f3d  pop rax
00007d2ed8dd6f3e  add rsp, 0x08
00007d2ed8dd6f42  jmp 0x00007D2ED8DD5A88
00007d2ed8dd6f47  sub rsp, 0x08
00007d2ed8dd6f4b  push rax
00007d2ed8dd6f4c  push rcx
00007d2ed8dd6f4d  push rdx
00007d2ed8dd6f4e  push rdi
00007d2ed8dd6f4f  push rsi
00007d2ed8dd6f50  push r8
00007d2ed8dd6f52  push r9
00007d2ed8dd6f54  push r10
00007d2ed8dd6f56  push r11
00007d2ed8dd6f58  sub rsp, 0xF0
00007d2ed8dd6f5f  vmovaps [rsp], xmm0
00007d2ed8dd6f64  vmovaps [rsp+0x10], xmm1
00007d2ed8dd6f6a  vmovaps [rsp+0x20], xmm2
00007d2ed8dd6f70  vmovaps [rsp+0x30], xmm3
00007d2ed8dd6f76  vmovaps [rsp+0x40], xmm4
00007d2ed8dd6f7c  vmovaps [rsp+0x50], xmm6
00007d2ed8dd6f82  vmovaps [rsp+0x60], xmm7
00007d2ed8dd6f88  vmovaps [rsp+0x70], xmm8
00007d2ed8dd6f8e  vmovaps [rsp+0x80], xmm9
00007d2ed8dd6f97  vmovaps [rsp+0x90], xmm10
00007d2ed8dd6fa0  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd6fa9  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd6fb2  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd6fbb  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd6fc4  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd6fcd  sub rsp, 0x30
00007d2ed8dd6fd1  movaps [rsp], xmm5
00007d2ed8dd6fd5  movaps [rsp+0x10], xmm8
00007d2ed8dd6fdb  movaps [rsp+0x20], xmm15
00007d2ed8dd6fe1  lea rdi, [rsp]
00007d2ed8dd6fe5  mov esi, 0x00
00007d2ed8dd6fea  mov rax, 0x648718324530
00007d2ed8dd6ff4  call rax
00007d2ed8dd6ff6  movaps xmm5, [rsp]
00007d2ed8dd6ffa  add rsp, 0x30
00007d2ed8dd6ffe  vmovaps xmm0, [rsp]
00007d2ed8dd7003  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd7009  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd700f  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd7015  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd701b  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd7021  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd7027  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd702d  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd7036  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd703f  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd7048  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd7051  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd705a  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd7063  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd706c  add rsp, 0xF0
00007d2ed8dd7073  pop r11
00007d2ed8dd7075  pop r10
00007d2ed8dd7077  pop r9
00007d2ed8dd7079  pop r8
00007d2ed8dd707b  pop rsi
00007d2ed8dd707c  pop rdi
00007d2ed8dd707d  pop rdx
00007d2ed8dd707e  pop rcx
00007d2ed8dd707f  pop rax
00007d2ed8dd7080  add rsp, 0x08
00007d2ed8dd7084  jmp 0x00007D2ED8DD5AC0
00007d2ed8dd7089  sub rsp, 0x08
00007d2ed8dd708d  push rax
00007d2ed8dd708e  push rcx
00007d2ed8dd708f  push rdx
00007d2ed8dd7090  push rdi
00007d2ed8dd7091  push rsi
00007d2ed8dd7092  push r8
00007d2ed8dd7094  push r9
00007d2ed8dd7096  push r10
00007d2ed8dd7098  push r11
00007d2ed8dd709a  sub rsp, 0xF0
00007d2ed8dd70a1  vmovaps [rsp], xmm0
00007d2ed8dd70a6  vmovaps [rsp+0x10], xmm1
00007d2ed8dd70ac  vmovaps [rsp+0x20], xmm2
00007d2ed8dd70b2  vmovaps [rsp+0x30], xmm3
00007d2ed8dd70b8  vmovaps [rsp+0x40], xmm5
00007d2ed8dd70be  vmovaps [rsp+0x50], xmm6
00007d2ed8dd70c4  vmovaps [rsp+0x60], xmm7
00007d2ed8dd70ca  vmovaps [rsp+0x70], xmm8
00007d2ed8dd70d0  vmovaps [rsp+0x80], xmm9
00007d2ed8dd70d9  vmovaps [rsp+0x90], xmm10
00007d2ed8dd70e2  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd70eb  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd70f4  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd70fd  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd7106  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd710f  sub rsp, 0x30
00007d2ed8dd7113  movaps [rsp], xmm4
00007d2ed8dd7117  movaps [rsp+0x10], xmm9
00007d2ed8dd711d  movaps [rsp+0x20], xmm8
00007d2ed8dd7123  lea rdi, [rsp]
00007d2ed8dd7127  mov esi, 0x00
00007d2ed8dd712c  mov rax, 0x648718324530
00007d2ed8dd7136  call rax
00007d2ed8dd7138  movaps xmm4, [rsp]
00007d2ed8dd713c  add rsp, 0x30
00007d2ed8dd7140  vmovaps xmm0, [rsp]
00007d2ed8dd7145  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd714b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd7151  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd7157  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd715d  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd7163  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd7169  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd716f  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd7178  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd7181  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd718a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd7193  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd719c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd71a5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd71ae  add rsp, 0xF0
00007d2ed8dd71b5  pop r11
00007d2ed8dd71b7  pop r10
00007d2ed8dd71b9  pop r9
00007d2ed8dd71bb  pop r8
00007d2ed8dd71bd  pop rsi
00007d2ed8dd71be  pop rdi
00007d2ed8dd71bf  pop rdx
00007d2ed8dd71c0  pop rcx
00007d2ed8dd71c1  pop rax
00007d2ed8dd71c2  add rsp, 0x08
00007d2ed8dd71c6  jmp 0x00007D2ED8DD5AE1
00007d2ed8dd71cb  sub rsp, 0x08
00007d2ed8dd71cf  push rax
00007d2ed8dd71d0  push rcx
00007d2ed8dd71d1  push rdx
00007d2ed8dd71d2  push rdi
00007d2ed8dd71d3  push rsi
00007d2ed8dd71d4  push r8
00007d2ed8dd71d6  push r9
00007d2ed8dd71d8  push r10
00007d2ed8dd71da  push r11
00007d2ed8dd71dc  sub rsp, 0xF0
00007d2ed8dd71e3  vmovaps [rsp], xmm0
00007d2ed8dd71e8  vmovaps [rsp+0x10], xmm1
00007d2ed8dd71ee  vmovaps [rsp+0x20], xmm2
00007d2ed8dd71f4  vmovaps [rsp+0x30], xmm3
00007d2ed8dd71fa  vmovaps [rsp+0x40], xmm4
00007d2ed8dd7200  vmovaps [rsp+0x50], xmm5
00007d2ed8dd7206  vmovaps [rsp+0x60], xmm6
00007d2ed8dd720c  vmovaps [rsp+0x70], xmm7
00007d2ed8dd7212  vmovaps [rsp+0x80], xmm8
00007d2ed8dd721b  vmovaps [rsp+0x90], xmm10
00007d2ed8dd7224  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd722d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd7236  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd723f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd7248  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd7251  sub rsp, 0x30
00007d2ed8dd7255  movaps [rsp], xmm9
00007d2ed8dd725a  movaps [rsp+0x10], xmm10
00007d2ed8dd7260  movaps [rsp+0x20], xmm8
00007d2ed8dd7266  lea rdi, [rsp]
00007d2ed8dd726a  mov esi, 0x00
00007d2ed8dd726f  mov rax, 0x648718324530
00007d2ed8dd7279  call rax
00007d2ed8dd727b  movaps xmm9, [rsp]
00007d2ed8dd7280  add rsp, 0x30
00007d2ed8dd7284  vmovaps xmm0, [rsp]
00007d2ed8dd7289  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd728f  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd7295  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd729b  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd72a1  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd72a7  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd72ad  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd72b3  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd72bc  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd72c5  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd72ce  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd72d7  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd72e0  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd72e9  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd72f2  add rsp, 0xF0
00007d2ed8dd72f9  pop r11
00007d2ed8dd72fb  pop r10
00007d2ed8dd72fd  pop r9
00007d2ed8dd72ff  pop r8
00007d2ed8dd7301  pop rsi
00007d2ed8dd7302  pop rdi
00007d2ed8dd7303  pop rdx
00007d2ed8dd7304  pop rcx
00007d2ed8dd7305  pop rax
00007d2ed8dd7306  add rsp, 0x08
00007d2ed8dd730a  jmp 0x00007D2ED8DD5AFB
00007d2ed8dd730f  call 0x00007D2ED8CD64F0
00007d2ed8dd7314  jmp 0x00007D2ED8DD5C15
00007d2ed8dd7319  call 0x00007D2ED8CD64F0
00007d2ed8dd731e  jmp 0x00007D2ED8DD5C2B
00007d2ed8dd7323  sub rsp, 0x08
00007d2ed8dd7327  push rax
00007d2ed8dd7328  push rcx
00007d2ed8dd7329  push rdx
00007d2ed8dd732a  push rdi
00007d2ed8dd732b  push rsi
00007d2ed8dd732c  push r8
00007d2ed8dd732e  push r9
00007d2ed8dd7330  push r10
00007d2ed8dd7332  push r11
00007d2ed8dd7334  sub rsp, 0xF0
00007d2ed8dd733b  vmovaps [rsp], xmm0
00007d2ed8dd7340  vmovaps [rsp+0x10], xmm2
00007d2ed8dd7346  vmovaps [rsp+0x20], xmm3
00007d2ed8dd734c  vmovaps [rsp+0x30], xmm4
00007d2ed8dd7352  vmovaps [rsp+0x40], xmm5
00007d2ed8dd7358  vmovaps [rsp+0x50], xmm6
00007d2ed8dd735e  vmovaps [rsp+0x60], xmm7
00007d2ed8dd7364  vmovaps [rsp+0x70], xmm8
00007d2ed8dd736a  vmovaps [rsp+0x80], xmm9
00007d2ed8dd7373  vmovaps [rsp+0x90], xmm10
00007d2ed8dd737c  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd7385  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd738e  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd7397  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd73a0  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd73a9  sub rsp, 0x30
00007d2ed8dd73ad  movaps [rsp], xmm1
00007d2ed8dd73b1  movaps [rsp+0x10], xmm6
00007d2ed8dd73b6  movaps [rsp+0x20], xmm15
00007d2ed8dd73bc  lea rdi, [rsp]
00007d2ed8dd73c0  mov esi, 0x00
00007d2ed8dd73c5  mov rax, 0x648718324530
00007d2ed8dd73cf  call rax
00007d2ed8dd73d1  movaps xmm1, [rsp]
00007d2ed8dd73d5  add rsp, 0x30
00007d2ed8dd73d9  vmovaps xmm0, [rsp]
00007d2ed8dd73de  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd73e4  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd73ea  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd73f0  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd73f6  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd73fc  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd7402  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd7408  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd7411  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd741a  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd7423  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd742c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd7435  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd743e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd7447  add rsp, 0xF0
00007d2ed8dd744e  pop r11
00007d2ed8dd7450  pop r10
00007d2ed8dd7452  pop r9
00007d2ed8dd7454  pop r8
00007d2ed8dd7456  pop rsi
00007d2ed8dd7457  pop rdi
00007d2ed8dd7458  pop rdx
00007d2ed8dd7459  pop rcx
00007d2ed8dd745a  pop rax
00007d2ed8dd745b  add rsp, 0x08
00007d2ed8dd745f  jmp 0x00007D2ED8DD5C68
00007d2ed8dd7464  call 0x00007D2ED8CE5820
00007d2ed8dd7469  jmp 0x00007D2ED8DD5C75
00007d2ed8dd746e  sub rsp, 0x08
00007d2ed8dd7472  push rax
00007d2ed8dd7473  push rcx
00007d2ed8dd7474  push rdx
00007d2ed8dd7475  push rdi
00007d2ed8dd7476  push rsi
00007d2ed8dd7477  push r8
00007d2ed8dd7479  push r9
00007d2ed8dd747b  push r10
00007d2ed8dd747d  push r11
00007d2ed8dd747f  sub rsp, 0xF0
00007d2ed8dd7486  vmovaps [rsp], xmm0
00007d2ed8dd748b  vmovaps [rsp+0x10], xmm1
00007d2ed8dd7491  vmovaps [rsp+0x20], xmm2
00007d2ed8dd7497  vmovaps [rsp+0x30], xmm3
00007d2ed8dd749d  vmovaps [rsp+0x40], xmm4
00007d2ed8dd74a3  vmovaps [rsp+0x50], xmm5
00007d2ed8dd74a9  vmovaps [rsp+0x60], xmm6
00007d2ed8dd74af  vmovaps [rsp+0x70], xmm7
00007d2ed8dd74b5  vmovaps [rsp+0x80], xmm8
00007d2ed8dd74be  vmovaps [rsp+0x90], xmm9
00007d2ed8dd74c7  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd74d0  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd74d9  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd74e2  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd74eb  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd74f4  sub rsp, 0x30
00007d2ed8dd74f8  movaps [rsp], xmm14
00007d2ed8dd74fd  movaps [rsp+0x10], xmm4
00007d2ed8dd7502  movaps [rsp+0x20], xmm3
00007d2ed8dd7507  lea rdi, [rsp]
00007d2ed8dd750b  mov esi, 0x00
00007d2ed8dd7510  mov rax, 0x648718324530
00007d2ed8dd751a  call rax
00007d2ed8dd751c  movaps xmm14, [rsp]
00007d2ed8dd7521  add rsp, 0x30
00007d2ed8dd7525  vmovaps xmm0, [rsp]
00007d2ed8dd752a  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd7530  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd7536  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd753c  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd7542  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd7548  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd754e  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd7554  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd755d  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd7566  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd756f  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd7578  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd7581  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd758a  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd7593  add rsp, 0xF0
00007d2ed8dd759a  pop r11
00007d2ed8dd759c  pop r10
00007d2ed8dd759e  pop r9
00007d2ed8dd75a0  pop r8
00007d2ed8dd75a2  pop rsi
00007d2ed8dd75a3  pop rdi
00007d2ed8dd75a4  pop rdx
00007d2ed8dd75a5  pop rcx
00007d2ed8dd75a6  pop rax
00007d2ed8dd75a7  add rsp, 0x08
00007d2ed8dd75ab  jmp 0x00007D2ED8DD5C8F
00007d2ed8dd75b0  sub rsp, 0x08
00007d2ed8dd75b4  push rax
00007d2ed8dd75b5  push rcx
00007d2ed8dd75b6  push rdx
00007d2ed8dd75b7  push rdi
00007d2ed8dd75b8  push rsi
00007d2ed8dd75b9  push r8
00007d2ed8dd75bb  push r9
00007d2ed8dd75bd  push r10
00007d2ed8dd75bf  push r11
00007d2ed8dd75c1  sub rsp, 0xF0
00007d2ed8dd75c8  vmovaps [rsp], xmm0
00007d2ed8dd75cd  vmovaps [rsp+0x10], xmm1
00007d2ed8dd75d3  vmovaps [rsp+0x20], xmm2
00007d2ed8dd75d9  vmovaps [rsp+0x30], xmm3
00007d2ed8dd75df  vmovaps [rsp+0x40], xmm4
00007d2ed8dd75e5  vmovaps [rsp+0x50], xmm5
00007d2ed8dd75eb  vmovaps [rsp+0x60], xmm7
00007d2ed8dd75f1  vmovaps [rsp+0x70], xmm8
00007d2ed8dd75f7  vmovaps [rsp+0x80], xmm9
00007d2ed8dd7600  vmovaps [rsp+0x90], xmm10
00007d2ed8dd7609  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd7612  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd761b  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd7624  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd762d  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd7636  sub rsp, 0x30
00007d2ed8dd763a  movaps [rsp], xmm6
00007d2ed8dd763e  movaps [rsp+0x10], xmm9
00007d2ed8dd7644  movaps [rsp+0x20], xmm7
00007d2ed8dd7649  lea rdi, [rsp]
00007d2ed8dd764d  mov esi, 0x00
00007d2ed8dd7652  mov rax, 0x648718324530
00007d2ed8dd765c  call rax
00007d2ed8dd765e  movaps xmm6, [rsp]
00007d2ed8dd7662  add rsp, 0x30
00007d2ed8dd7666  vmovaps xmm0, [rsp]
00007d2ed8dd766b  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd7671  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd7677  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd767d  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd7683  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd7689  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd768f  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd7695  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd769e  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd76a7  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd76b0  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd76b9  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd76c2  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd76cb  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd76d4  add rsp, 0xF0
00007d2ed8dd76db  pop r11
00007d2ed8dd76dd  pop r10
00007d2ed8dd76df  pop r9
00007d2ed8dd76e1  pop r8
00007d2ed8dd76e3  pop rsi
00007d2ed8dd76e4  pop rdi
00007d2ed8dd76e5  pop rdx
00007d2ed8dd76e6  pop rcx
00007d2ed8dd76e7  pop rax
00007d2ed8dd76e8  add rsp, 0x08
00007d2ed8dd76ec  jmp 0x00007D2ED8DD5CA7
00007d2ed8dd76f1  sub rsp, 0x08
00007d2ed8dd76f5  push rax
00007d2ed8dd76f6  push rcx
00007d2ed8dd76f7  push rdx
00007d2ed8dd76f8  push rdi
00007d2ed8dd76f9  push rsi
00007d2ed8dd76fa  push r8
00007d2ed8dd76fc  push r9
00007d2ed8dd76fe  push r10
00007d2ed8dd7700  push r11
00007d2ed8dd7702  sub rsp, 0xF0
00007d2ed8dd7709  vmovaps [rsp], xmm0
00007d2ed8dd770e  vmovaps [rsp+0x10], xmm1
00007d2ed8dd7714  vmovaps [rsp+0x20], xmm2
00007d2ed8dd771a  vmovaps [rsp+0x30], xmm3
00007d2ed8dd7720  vmovaps [rsp+0x40], xmm4
00007d2ed8dd7726  vmovaps [rsp+0x50], xmm5
00007d2ed8dd772c  vmovaps [rsp+0x60], xmm6
00007d2ed8dd7732  vmovaps [rsp+0x70], xmm8
00007d2ed8dd7738  vmovaps [rsp+0x80], xmm9
00007d2ed8dd7741  vmovaps [rsp+0x90], xmm10
00007d2ed8dd774a  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd7753  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd775c  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd7765  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd776e  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd7777  sub rsp, 0x30
00007d2ed8dd777b  movaps [rsp], xmm7
00007d2ed8dd777f  movaps [rsp+0x10], xmm4
00007d2ed8dd7784  movaps [rsp+0x20], xmm9
00007d2ed8dd778a  lea rdi, [rsp]
00007d2ed8dd778e  mov esi, 0x00
00007d2ed8dd7793  mov rax, 0x648718324530
00007d2ed8dd779d  call rax
00007d2ed8dd779f  movaps xmm7, [rsp]
00007d2ed8dd77a3  add rsp, 0x30
00007d2ed8dd77a7  vmovaps xmm0, [rsp]
00007d2ed8dd77ac  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd77b2  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd77b8  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd77be  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd77c4  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd77ca  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd77d0  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd77d6  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd77df  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd77e8  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd77f1  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd77fa  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd7803  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd780c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd7815  add rsp, 0xF0
00007d2ed8dd781c  pop r11
00007d2ed8dd781e  pop r10
00007d2ed8dd7820  pop r9
00007d2ed8dd7822  pop r8
00007d2ed8dd7824  pop rsi
00007d2ed8dd7825  pop rdi
00007d2ed8dd7826  pop rdx
00007d2ed8dd7827  pop rcx
00007d2ed8dd7828  pop rax
00007d2ed8dd7829  add rsp, 0x08
00007d2ed8dd782d  jmp 0x00007D2ED8DD5CD4
00007d2ed8dd7832  sub rsp, 0x08
00007d2ed8dd7836  push rax
00007d2ed8dd7837  push rcx
00007d2ed8dd7838  push rdx
00007d2ed8dd7839  push rdi
00007d2ed8dd783a  push rsi
00007d2ed8dd783b  push r8
00007d2ed8dd783d  push r9
00007d2ed8dd783f  push r10
00007d2ed8dd7841  push r11
00007d2ed8dd7843  sub rsp, 0xF0
00007d2ed8dd784a  vmovaps [rsp], xmm0
00007d2ed8dd784f  vmovaps [rsp+0x10], xmm1
00007d2ed8dd7855  vmovaps [rsp+0x20], xmm2
00007d2ed8dd785b  vmovaps [rsp+0x30], xmm3
00007d2ed8dd7861  vmovaps [rsp+0x40], xmm5
00007d2ed8dd7867  vmovaps [rsp+0x50], xmm6
00007d2ed8dd786d  vmovaps [rsp+0x60], xmm7
00007d2ed8dd7873  vmovaps [rsp+0x70], xmm8
00007d2ed8dd7879  vmovaps [rsp+0x80], xmm9
00007d2ed8dd7882  vmovaps [rsp+0x90], xmm10
00007d2ed8dd788b  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd7894  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd789d  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd78a6  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd78af  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd78b8  sub rsp, 0x30
00007d2ed8dd78bc  movaps [rsp], xmm4
00007d2ed8dd78c0  movaps [rsp+0x10], xmm15
00007d2ed8dd78c6  movaps [rsp+0x20], xmm9
00007d2ed8dd78cc  lea rdi, [rsp]
00007d2ed8dd78d0  mov esi, 0x00
00007d2ed8dd78d5  mov rax, 0x648718324530
00007d2ed8dd78df  call rax
00007d2ed8dd78e1  movaps xmm4, [rsp]
00007d2ed8dd78e5  add rsp, 0x30
00007d2ed8dd78e9  vmovaps xmm0, [rsp]
00007d2ed8dd78ee  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd78f4  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd78fa  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd7900  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd7906  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd790c  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd7912  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd7918  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd7921  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd792a  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd7933  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd793c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd7945  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd794e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd7957  add rsp, 0xF0
00007d2ed8dd795e  pop r11
00007d2ed8dd7960  pop r10
00007d2ed8dd7962  pop r9
00007d2ed8dd7964  pop r8
00007d2ed8dd7966  pop rsi
00007d2ed8dd7967  pop rdi
00007d2ed8dd7968  pop rdx
00007d2ed8dd7969  pop rcx
00007d2ed8dd796a  pop rax
00007d2ed8dd796b  add rsp, 0x08
00007d2ed8dd796f  jmp 0x00007D2ED8DD5CF9
00007d2ed8dd7974  call 0x00007D2ED8CE5820
00007d2ed8dd7979  jmp 0x00007D2ED8DD5D06
00007d2ed8dd797e  sub rsp, 0x08
00007d2ed8dd7982  push rax
00007d2ed8dd7983  push rcx
00007d2ed8dd7984  push rdx
00007d2ed8dd7985  push rdi
00007d2ed8dd7986  push rsi
00007d2ed8dd7987  push r8
00007d2ed8dd7989  push r9
00007d2ed8dd798b  push r10
00007d2ed8dd798d  push r11
00007d2ed8dd798f  sub rsp, 0xF0
00007d2ed8dd7996  vmovaps [rsp], xmm0
00007d2ed8dd799b  vmovaps [rsp+0x10], xmm1
00007d2ed8dd79a1  vmovaps [rsp+0x20], xmm2
00007d2ed8dd79a7  vmovaps [rsp+0x30], xmm4
00007d2ed8dd79ad  vmovaps [rsp+0x40], xmm5
00007d2ed8dd79b3  vmovaps [rsp+0x50], xmm6
00007d2ed8dd79b9  vmovaps [rsp+0x60], xmm7
00007d2ed8dd79bf  vmovaps [rsp+0x70], xmm8
00007d2ed8dd79c5  vmovaps [rsp+0x80], xmm9
00007d2ed8dd79ce  vmovaps [rsp+0x90], xmm10
00007d2ed8dd79d7  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd79e0  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd79e9  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd79f2  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd79fb  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd7a04  sub rsp, 0x30
00007d2ed8dd7a08  movaps [rsp], xmm3
00007d2ed8dd7a0c  movaps [rsp+0x10], xmm1
00007d2ed8dd7a11  movaps [rsp+0x20], xmm9
00007d2ed8dd7a17  lea rdi, [rsp]
00007d2ed8dd7a1b  mov esi, 0x00
00007d2ed8dd7a20  mov rax, 0x648718324530
00007d2ed8dd7a2a  call rax
00007d2ed8dd7a2c  movaps xmm3, [rsp]
00007d2ed8dd7a30  add rsp, 0x30
00007d2ed8dd7a34  vmovaps xmm0, [rsp]
00007d2ed8dd7a39  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd7a3f  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd7a45  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd7a4b  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd7a51  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd7a57  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd7a5d  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd7a63  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd7a6c  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd7a75  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd7a7e  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd7a87  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd7a90  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd7a99  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd7aa2  add rsp, 0xF0
00007d2ed8dd7aa9  pop r11
00007d2ed8dd7aab  pop r10
00007d2ed8dd7aad  pop r9
00007d2ed8dd7aaf  pop r8
00007d2ed8dd7ab1  pop rsi
00007d2ed8dd7ab2  pop rdi
00007d2ed8dd7ab3  pop rdx
00007d2ed8dd7ab4  pop rcx
00007d2ed8dd7ab5  pop rax
00007d2ed8dd7ab6  add rsp, 0x08
00007d2ed8dd7aba  jmp 0x00007D2ED8DD5D43
00007d2ed8dd7abf  sub rsp, 0x08
00007d2ed8dd7ac3  push rax
00007d2ed8dd7ac4  push rcx
00007d2ed8dd7ac5  push rdx
00007d2ed8dd7ac6  push rdi
00007d2ed8dd7ac7  push rsi
00007d2ed8dd7ac8  push r8
00007d2ed8dd7aca  push r9
00007d2ed8dd7acc  push r10
00007d2ed8dd7ace  push r11
00007d2ed8dd7ad0  sub rsp, 0xF0
00007d2ed8dd7ad7  vmovaps [rsp], xmm0
00007d2ed8dd7adc  vmovaps [rsp+0x10], xmm2
00007d2ed8dd7ae2  vmovaps [rsp+0x20], xmm3
00007d2ed8dd7ae8  vmovaps [rsp+0x30], xmm4
00007d2ed8dd7aee  vmovaps [rsp+0x40], xmm5
00007d2ed8dd7af4  vmovaps [rsp+0x50], xmm6
00007d2ed8dd7afa  vmovaps [rsp+0x60], xmm7
00007d2ed8dd7b00  vmovaps [rsp+0x70], xmm8
00007d2ed8dd7b06  vmovaps [rsp+0x80], xmm9
00007d2ed8dd7b0f  vmovaps [rsp+0x90], xmm10
00007d2ed8dd7b18  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd7b21  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd7b2a  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd7b33  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd7b3c  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd7b45  sub rsp, 0x30
00007d2ed8dd7b49  movaps [rsp], xmm1
00007d2ed8dd7b4d  movaps [rsp+0x10], xmm15
00007d2ed8dd7b53  movaps [rsp+0x20], xmm9
00007d2ed8dd7b59  lea rdi, [rsp]
00007d2ed8dd7b5d  mov esi, 0x00
00007d2ed8dd7b62  mov rax, 0x648718324530
00007d2ed8dd7b6c  call rax
00007d2ed8dd7b6e  movaps xmm1, [rsp]
00007d2ed8dd7b72  add rsp, 0x30
00007d2ed8dd7b76  vmovaps xmm0, [rsp]
00007d2ed8dd7b7b  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd7b81  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd7b87  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd7b8d  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd7b93  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd7b99  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd7b9f  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd7ba5  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd7bae  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd7bb7  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd7bc0  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd7bc9  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd7bd2  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd7bdb  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd7be4  add rsp, 0xF0
00007d2ed8dd7beb  pop r11
00007d2ed8dd7bed  pop r10
00007d2ed8dd7bef  pop r9
00007d2ed8dd7bf1  pop r8
00007d2ed8dd7bf3  pop rsi
00007d2ed8dd7bf4  pop rdi
00007d2ed8dd7bf5  pop rdx
00007d2ed8dd7bf6  pop rcx
00007d2ed8dd7bf7  pop rax
00007d2ed8dd7bf8  add rsp, 0x08
00007d2ed8dd7bfc  jmp 0x00007D2ED8DD5DCB
00007d2ed8dd7c01  call 0x00007D2ED8CE5820
00007d2ed8dd7c06  jmp 0x00007D2ED8DD5DD8
00007d2ed8dd7c0b  sub rsp, 0x08
00007d2ed8dd7c0f  push rax
00007d2ed8dd7c10  push rcx
00007d2ed8dd7c11  push rdx
00007d2ed8dd7c12  push rdi
00007d2ed8dd7c13  push rsi
00007d2ed8dd7c14  push r8
00007d2ed8dd7c16  push r9
00007d2ed8dd7c18  push r10
00007d2ed8dd7c1a  push r11
00007d2ed8dd7c1c  sub rsp, 0xF0
00007d2ed8dd7c23  vmovaps [rsp], xmm0
00007d2ed8dd7c28  vmovaps [rsp+0x10], xmm2
00007d2ed8dd7c2e  vmovaps [rsp+0x20], xmm3
00007d2ed8dd7c34  vmovaps [rsp+0x30], xmm4
00007d2ed8dd7c3a  vmovaps [rsp+0x40], xmm5
00007d2ed8dd7c40  vmovaps [rsp+0x50], xmm6
00007d2ed8dd7c46  vmovaps [rsp+0x60], xmm7
00007d2ed8dd7c4c  vmovaps [rsp+0x70], xmm8
00007d2ed8dd7c52  vmovaps [rsp+0x80], xmm9
00007d2ed8dd7c5b  vmovaps [rsp+0x90], xmm10
00007d2ed8dd7c64  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd7c6d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd7c76  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd7c7f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd7c88  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd7c91  sub rsp, 0x30
00007d2ed8dd7c95  movaps [rsp], xmm1
00007d2ed8dd7c99  movaps [rsp+0x10], xmm5
00007d2ed8dd7c9e  movaps [rsp+0x20], xmm7
00007d2ed8dd7ca3  lea rdi, [rsp]
00007d2ed8dd7ca7  mov esi, 0x00
00007d2ed8dd7cac  mov rax, 0x648718324530
00007d2ed8dd7cb6  call rax
00007d2ed8dd7cb8  movaps xmm1, [rsp]
00007d2ed8dd7cbc  add rsp, 0x30
00007d2ed8dd7cc0  vmovaps xmm0, [rsp]
00007d2ed8dd7cc5  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd7ccb  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd7cd1  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd7cd7  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd7cdd  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd7ce3  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd7ce9  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd7cef  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd7cf8  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd7d01  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd7d0a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd7d13  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd7d1c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd7d25  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd7d2e  add rsp, 0xF0
00007d2ed8dd7d35  pop r11
00007d2ed8dd7d37  pop r10
00007d2ed8dd7d39  pop r9
00007d2ed8dd7d3b  pop r8
00007d2ed8dd7d3d  pop rsi
00007d2ed8dd7d3e  pop rdi
00007d2ed8dd7d3f  pop rdx
00007d2ed8dd7d40  pop rcx
00007d2ed8dd7d41  pop rax
00007d2ed8dd7d42  add rsp, 0x08
00007d2ed8dd7d46  jmp 0x00007D2ED8DD5E7D
00007d2ed8dd7d4b  sub rsp, 0x08
00007d2ed8dd7d4f  push rax
00007d2ed8dd7d50  push rcx
00007d2ed8dd7d51  push rdx
00007d2ed8dd7d52  push rdi
00007d2ed8dd7d53  push rsi
00007d2ed8dd7d54  push r8
00007d2ed8dd7d56  push r9
00007d2ed8dd7d58  push r10
00007d2ed8dd7d5a  push r11
00007d2ed8dd7d5c  sub rsp, 0xF0
00007d2ed8dd7d63  vmovaps [rsp], xmm0
00007d2ed8dd7d68  vmovaps [rsp+0x10], xmm1
00007d2ed8dd7d6e  vmovaps [rsp+0x20], xmm2
00007d2ed8dd7d74  vmovaps [rsp+0x30], xmm3
00007d2ed8dd7d7a  vmovaps [rsp+0x40], xmm4
00007d2ed8dd7d80  vmovaps [rsp+0x50], xmm5
00007d2ed8dd7d86  vmovaps [rsp+0x60], xmm6
00007d2ed8dd7d8c  vmovaps [rsp+0x70], xmm8
00007d2ed8dd7d92  vmovaps [rsp+0x80], xmm9
00007d2ed8dd7d9b  vmovaps [rsp+0x90], xmm10
00007d2ed8dd7da4  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd7dad  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd7db6  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd7dbf  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd7dc8  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd7dd1  sub rsp, 0x30
00007d2ed8dd7dd5  movaps [rsp], xmm7
00007d2ed8dd7dd9  movaps [rsp+0x10], xmm5
00007d2ed8dd7dde  movaps [rsp+0x20], xmm15
00007d2ed8dd7de4  lea rdi, [rsp]
00007d2ed8dd7de8  mov esi, 0x00
00007d2ed8dd7ded  mov rax, 0x648718324530
00007d2ed8dd7df7  call rax
00007d2ed8dd7df9  movaps xmm7, [rsp]
00007d2ed8dd7dfd  add rsp, 0x30
00007d2ed8dd7e01  vmovaps xmm0, [rsp]
00007d2ed8dd7e06  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd7e0c  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd7e12  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd7e18  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd7e1e  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd7e24  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd7e2a  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd7e30  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd7e39  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd7e42  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd7e4b  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd7e54  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd7e5d  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd7e66  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd7e6f  add rsp, 0xF0
00007d2ed8dd7e76  pop r11
00007d2ed8dd7e78  pop r10
00007d2ed8dd7e7a  pop r9
00007d2ed8dd7e7c  pop r8
00007d2ed8dd7e7e  pop rsi
00007d2ed8dd7e7f  pop rdi
00007d2ed8dd7e80  pop rdx
00007d2ed8dd7e81  pop rcx
00007d2ed8dd7e82  pop rax
00007d2ed8dd7e83  add rsp, 0x08
00007d2ed8dd7e87  jmp 0x00007D2ED8DD5EB3
00007d2ed8dd7e8c  call 0x00007D2ED8CD64F0
00007d2ed8dd7e91  jmp 0x00007D2ED8DD5EC0
00007d2ed8dd7e96  sub rsp, 0x08
00007d2ed8dd7e9a  push rax
00007d2ed8dd7e9b  push rcx
00007d2ed8dd7e9c  push rdx
00007d2ed8dd7e9d  push rdi
00007d2ed8dd7e9e  push rsi
00007d2ed8dd7e9f  push r8
00007d2ed8dd7ea1  push r9
00007d2ed8dd7ea3  push r10
00007d2ed8dd7ea5  push r11
00007d2ed8dd7ea7  sub rsp, 0xF0
00007d2ed8dd7eae  vmovaps [rsp], xmm0
00007d2ed8dd7eb3  vmovaps [rsp+0x10], xmm1
00007d2ed8dd7eb9  vmovaps [rsp+0x20], xmm2
00007d2ed8dd7ebf  vmovaps [rsp+0x30], xmm3
00007d2ed8dd7ec5  vmovaps [rsp+0x40], xmm4
00007d2ed8dd7ecb  vmovaps [rsp+0x50], xmm5
00007d2ed8dd7ed1  vmovaps [rsp+0x60], xmm6
00007d2ed8dd7ed7  vmovaps [rsp+0x70], xmm7
00007d2ed8dd7edd  vmovaps [rsp+0x80], xmm8
00007d2ed8dd7ee6  vmovaps [rsp+0x90], xmm9
00007d2ed8dd7eef  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd7ef8  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd7f01  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd7f0a  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd7f13  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd7f1c  sub rsp, 0x30
00007d2ed8dd7f20  movaps [rsp], xmm15
00007d2ed8dd7f25  movaps [rsp+0x10], xmm5
00007d2ed8dd7f2a  movaps [rsp+0x20], xmm3
00007d2ed8dd7f2f  lea rdi, [rsp]
00007d2ed8dd7f33  mov esi, 0x00
00007d2ed8dd7f38  mov rax, 0x648718324530
00007d2ed8dd7f42  call rax
00007d2ed8dd7f44  movaps xmm15, [rsp]
00007d2ed8dd7f49  add rsp, 0x30
00007d2ed8dd7f4d  vmovaps xmm0, [rsp]
00007d2ed8dd7f52  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd7f58  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd7f5e  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd7f64  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd7f6a  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd7f70  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd7f76  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd7f7c  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd7f85  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd7f8e  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd7f97  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd7fa0  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd7fa9  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd7fb2  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd7fbb  add rsp, 0xF0
00007d2ed8dd7fc2  pop r11
00007d2ed8dd7fc4  pop r10
00007d2ed8dd7fc6  pop r9
00007d2ed8dd7fc8  pop r8
00007d2ed8dd7fca  pop rsi
00007d2ed8dd7fcb  pop rdi
00007d2ed8dd7fcc  pop rdx
00007d2ed8dd7fcd  pop rcx
00007d2ed8dd7fce  pop rax
00007d2ed8dd7fcf  add rsp, 0x08
00007d2ed8dd7fd3  jmp 0x00007D2ED8DD5EE6
00007d2ed8dd7fd8  sub rsp, 0x08
00007d2ed8dd7fdc  push rax
00007d2ed8dd7fdd  push rcx
00007d2ed8dd7fde  push rdx
00007d2ed8dd7fdf  push rdi
00007d2ed8dd7fe0  push rsi
00007d2ed8dd7fe1  push r8
00007d2ed8dd7fe3  push r9
00007d2ed8dd7fe5  push r10
00007d2ed8dd7fe7  push r11
00007d2ed8dd7fe9  sub rsp, 0xF0
00007d2ed8dd7ff0  vmovaps [rsp], xmm0
00007d2ed8dd7ff5  vmovaps [rsp+0x10], xmm2
00007d2ed8dd7ffb  vmovaps [rsp+0x20], xmm3
00007d2ed8dd8001  vmovaps [rsp+0x30], xmm4
00007d2ed8dd8007  vmovaps [rsp+0x40], xmm5
00007d2ed8dd800d  vmovaps [rsp+0x50], xmm6
00007d2ed8dd8013  vmovaps [rsp+0x60], xmm7
00007d2ed8dd8019  vmovaps [rsp+0x70], xmm8
00007d2ed8dd801f  vmovaps [rsp+0x80], xmm9
00007d2ed8dd8028  vmovaps [rsp+0x90], xmm10
00007d2ed8dd8031  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd803a  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd8043  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd804c  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd8055  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd805e  sub rsp, 0x30
00007d2ed8dd8062  movaps [rsp], xmm1
00007d2ed8dd8066  movaps [rsp+0x10], xmm5
00007d2ed8dd806b  movaps [rsp+0x20], xmm4
00007d2ed8dd8070  lea rdi, [rsp]
00007d2ed8dd8074  mov esi, 0x00
00007d2ed8dd8079  mov rax, 0x648718324530
00007d2ed8dd8083  call rax
00007d2ed8dd8085  movaps xmm1, [rsp]
00007d2ed8dd8089  add rsp, 0x30
00007d2ed8dd808d  vmovaps xmm0, [rsp]
00007d2ed8dd8092  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd8098  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd809e  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd80a4  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd80aa  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd80b0  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd80b6  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd80bc  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd80c5  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd80ce  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd80d7  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd80e0  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd80e9  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd80f2  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd80fb  add rsp, 0xF0
00007d2ed8dd8102  pop r11
00007d2ed8dd8104  pop r10
00007d2ed8dd8106  pop r9
00007d2ed8dd8108  pop r8
00007d2ed8dd810a  pop rsi
00007d2ed8dd810b  pop rdi
00007d2ed8dd810c  pop rdx
00007d2ed8dd810d  pop rcx
00007d2ed8dd810e  pop rax
00007d2ed8dd810f  add rsp, 0x08
00007d2ed8dd8113  jmp 0x00007D2ED8DD5F06
00007d2ed8dd8118  sub rsp, 0x08
00007d2ed8dd811c  push rax
00007d2ed8dd811d  push rcx
00007d2ed8dd811e  push rdx
00007d2ed8dd811f  push rdi
00007d2ed8dd8120  push rsi
00007d2ed8dd8121  push r8
00007d2ed8dd8123  push r9
00007d2ed8dd8125  push r10
00007d2ed8dd8127  push r11
00007d2ed8dd8129  sub rsp, 0xF0
00007d2ed8dd8130  vmovaps [rsp], xmm0
00007d2ed8dd8135  vmovaps [rsp+0x10], xmm1
00007d2ed8dd813b  vmovaps [rsp+0x20], xmm2
00007d2ed8dd8141  vmovaps [rsp+0x30], xmm3
00007d2ed8dd8147  vmovaps [rsp+0x40], xmm5
00007d2ed8dd814d  vmovaps [rsp+0x50], xmm6
00007d2ed8dd8153  vmovaps [rsp+0x60], xmm7
00007d2ed8dd8159  vmovaps [rsp+0x70], xmm8
00007d2ed8dd815f  vmovaps [rsp+0x80], xmm9
00007d2ed8dd8168  vmovaps [rsp+0x90], xmm10
00007d2ed8dd8171  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd817a  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd8183  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd818c  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd8195  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd819e  sub rsp, 0x30
00007d2ed8dd81a2  movaps [rsp], xmm4
00007d2ed8dd81a6  movaps [rsp+0x10], xmm3
00007d2ed8dd81ab  movaps [rsp+0x20], xmm5
00007d2ed8dd81b0  lea rdi, [rsp]
00007d2ed8dd81b4  mov esi, 0x00
00007d2ed8dd81b9  mov rax, 0x648718324530
00007d2ed8dd81c3  call rax
00007d2ed8dd81c5  movaps xmm4, [rsp]
00007d2ed8dd81c9  add rsp, 0x30
00007d2ed8dd81cd  vmovaps xmm0, [rsp]
00007d2ed8dd81d2  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd81d8  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd81de  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd81e4  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd81ea  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd81f0  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd81f6  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd81fc  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd8205  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd820e  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd8217  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd8220  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd8229  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd8232  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd823b  add rsp, 0xF0
00007d2ed8dd8242  pop r11
00007d2ed8dd8244  pop r10
00007d2ed8dd8246  pop r9
00007d2ed8dd8248  pop r8
00007d2ed8dd824a  pop rsi
00007d2ed8dd824b  pop rdi
00007d2ed8dd824c  pop rdx
00007d2ed8dd824d  pop rcx
00007d2ed8dd824e  pop rax
00007d2ed8dd824f  add rsp, 0x08
00007d2ed8dd8253  jmp 0x00007D2ED8DD5F54
00007d2ed8dd8258  call 0x00007D2ED8CD64F0
00007d2ed8dd825d  jmp 0x00007D2ED8DD5F61
00007d2ed8dd8262  sub rsp, 0x08
00007d2ed8dd8266  push rax
00007d2ed8dd8267  push rcx
00007d2ed8dd8268  push rdx
00007d2ed8dd8269  push rdi
00007d2ed8dd826a  push rsi
00007d2ed8dd826b  push r8
00007d2ed8dd826d  push r9
00007d2ed8dd826f  push r10
00007d2ed8dd8271  push r11
00007d2ed8dd8273  sub rsp, 0xF0
00007d2ed8dd827a  vmovaps [rsp], xmm0
00007d2ed8dd827f  vmovaps [rsp+0x10], xmm1
00007d2ed8dd8285  vmovaps [rsp+0x20], xmm2
00007d2ed8dd828b  vmovaps [rsp+0x30], xmm3
00007d2ed8dd8291  vmovaps [rsp+0x40], xmm4
00007d2ed8dd8297  vmovaps [rsp+0x50], xmm6
00007d2ed8dd829d  vmovaps [rsp+0x60], xmm7
00007d2ed8dd82a3  vmovaps [rsp+0x70], xmm8
00007d2ed8dd82a9  vmovaps [rsp+0x80], xmm9
00007d2ed8dd82b2  vmovaps [rsp+0x90], xmm10
00007d2ed8dd82bb  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd82c4  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd82cd  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd82d6  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd82df  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd82e8  sub rsp, 0x30
00007d2ed8dd82ec  movaps [rsp], xmm5
00007d2ed8dd82f0  movaps [rsp+0x10], xmm6
00007d2ed8dd82f5  movaps [rsp+0x20], xmm3
00007d2ed8dd82fa  lea rdi, [rsp]
00007d2ed8dd82fe  mov esi, 0x00
00007d2ed8dd8303  mov rax, 0x648718324530
00007d2ed8dd830d  call rax
00007d2ed8dd830f  movaps xmm5, [rsp]
00007d2ed8dd8313  add rsp, 0x30
00007d2ed8dd8317  vmovaps xmm0, [rsp]
00007d2ed8dd831c  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd8322  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd8328  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd832e  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd8334  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd833a  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd8340  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd8346  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd834f  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd8358  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd8361  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd836a  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd8373  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd837c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd8385  add rsp, 0xF0
00007d2ed8dd838c  pop r11
00007d2ed8dd838e  pop r10
00007d2ed8dd8390  pop r9
00007d2ed8dd8392  pop r8
00007d2ed8dd8394  pop rsi
00007d2ed8dd8395  pop rdi
00007d2ed8dd8396  pop rdx
00007d2ed8dd8397  pop rcx
00007d2ed8dd8398  pop rax
00007d2ed8dd8399  add rsp, 0x08
00007d2ed8dd839d  jmp 0x00007D2ED8DD5F87
00007d2ed8dd83a2  sub rsp, 0x08
00007d2ed8dd83a6  push rax
00007d2ed8dd83a7  push rcx
00007d2ed8dd83a8  push rdx
00007d2ed8dd83a9  push rdi
00007d2ed8dd83aa  push rsi
00007d2ed8dd83ab  push r8
00007d2ed8dd83ad  push r9
00007d2ed8dd83af  push r10
00007d2ed8dd83b1  push r11
00007d2ed8dd83b3  sub rsp, 0xF0
00007d2ed8dd83ba  vmovaps [rsp], xmm0
00007d2ed8dd83bf  vmovaps [rsp+0x10], xmm1
00007d2ed8dd83c5  vmovaps [rsp+0x20], xmm2
00007d2ed8dd83cb  vmovaps [rsp+0x30], xmm3
00007d2ed8dd83d1  vmovaps [rsp+0x40], xmm4
00007d2ed8dd83d7  vmovaps [rsp+0x50], xmm5
00007d2ed8dd83dd  vmovaps [rsp+0x60], xmm7
00007d2ed8dd83e3  vmovaps [rsp+0x70], xmm8
00007d2ed8dd83e9  vmovaps [rsp+0x80], xmm9
00007d2ed8dd83f2  vmovaps [rsp+0x90], xmm10
00007d2ed8dd83fb  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd8404  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd840d  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd8416  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd841f  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd8428  sub rsp, 0x30
00007d2ed8dd842c  movaps [rsp], xmm6
00007d2ed8dd8430  movaps [rsp+0x10], xmm9
00007d2ed8dd8436  movaps [rsp+0x20], xmm1
00007d2ed8dd843b  lea rdi, [rsp]
00007d2ed8dd843f  mov esi, 0x00
00007d2ed8dd8444  mov rax, 0x648718324530
00007d2ed8dd844e  call rax
00007d2ed8dd8450  movaps xmm6, [rsp]
00007d2ed8dd8454  add rsp, 0x30
00007d2ed8dd8458  vmovaps xmm0, [rsp]
00007d2ed8dd845d  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd8463  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd8469  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd846f  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd8475  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd847b  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd8481  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd8487  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd8490  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd8499  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd84a2  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd84ab  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd84b4  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd84bd  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd84c6  add rsp, 0xF0
00007d2ed8dd84cd  pop r11
00007d2ed8dd84cf  pop r10
00007d2ed8dd84d1  pop r9
00007d2ed8dd84d3  pop r8
00007d2ed8dd84d5  pop rsi
00007d2ed8dd84d6  pop rdi
00007d2ed8dd84d7  pop rdx
00007d2ed8dd84d8  pop rcx
00007d2ed8dd84d9  pop rax
00007d2ed8dd84da  add rsp, 0x08
00007d2ed8dd84de  jmp 0x00007D2ED8DD5FAB
00007d2ed8dd84e3  sub rsp, 0x08
00007d2ed8dd84e7  push rax
00007d2ed8dd84e8  push rcx
00007d2ed8dd84e9  push rdx
00007d2ed8dd84ea  push rdi
00007d2ed8dd84eb  push rsi
00007d2ed8dd84ec  push r8
00007d2ed8dd84ee  push r9
00007d2ed8dd84f0  push r10
00007d2ed8dd84f2  push r11
00007d2ed8dd84f4  sub rsp, 0xF0
00007d2ed8dd84fb  vmovaps [rsp], xmm0
00007d2ed8dd8500  vmovaps [rsp+0x10], xmm1
00007d2ed8dd8506  vmovaps [rsp+0x20], xmm2
00007d2ed8dd850c  vmovaps [rsp+0x30], xmm3
00007d2ed8dd8512  vmovaps [rsp+0x40], xmm4
00007d2ed8dd8518  vmovaps [rsp+0x50], xmm5
00007d2ed8dd851e  vmovaps [rsp+0x60], xmm6
00007d2ed8dd8524  vmovaps [rsp+0x70], xmm7
00007d2ed8dd852a  vmovaps [rsp+0x80], xmm8
00007d2ed8dd8533  vmovaps [rsp+0x90], xmm10
00007d2ed8dd853c  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd8545  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd854e  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd8557  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd8560  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd8569  sub rsp, 0x30
00007d2ed8dd856d  movaps [rsp], xmm9
00007d2ed8dd8572  movaps [rsp+0x10], xmm3
00007d2ed8dd8577  movaps [rsp+0x20], xmm1
00007d2ed8dd857c  lea rdi, [rsp]
00007d2ed8dd8580  mov esi, 0x00
00007d2ed8dd8585  mov rax, 0x648718324530
00007d2ed8dd858f  call rax
00007d2ed8dd8591  movaps xmm9, [rsp]
00007d2ed8dd8596  add rsp, 0x30
00007d2ed8dd859a  vmovaps xmm0, [rsp]
00007d2ed8dd859f  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd85a5  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd85ab  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd85b1  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd85b7  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd85bd  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd85c3  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd85c9  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd85d2  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd85db  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd85e4  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd85ed  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd85f6  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd85ff  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd8608  add rsp, 0xF0
00007d2ed8dd860f  pop r11
00007d2ed8dd8611  pop r10
00007d2ed8dd8613  pop r9
00007d2ed8dd8615  pop r8
00007d2ed8dd8617  pop rsi
00007d2ed8dd8618  pop rdi
00007d2ed8dd8619  pop rdx
00007d2ed8dd861a  pop rcx
00007d2ed8dd861b  pop rax
00007d2ed8dd861c  add rsp, 0x08
00007d2ed8dd8620  jmp 0x00007D2ED8DD5FF7
00007d2ed8dd8625  call 0x00007D2ED8CD64F0
00007d2ed8dd862a  jmp 0x00007D2ED8DD6004
00007d2ed8dd862f  sub rsp, 0x08
00007d2ed8dd8633  push rax
00007d2ed8dd8634  push rcx
00007d2ed8dd8635  push rdx
00007d2ed8dd8636  push rdi
00007d2ed8dd8637  push rsi
00007d2ed8dd8638  push r8
00007d2ed8dd863a  push r9
00007d2ed8dd863c  push r10
00007d2ed8dd863e  push r11
00007d2ed8dd8640  sub rsp, 0xF0
00007d2ed8dd8647  vmovaps [rsp], xmm0
00007d2ed8dd864c  vmovaps [rsp+0x10], xmm1
00007d2ed8dd8652  vmovaps [rsp+0x20], xmm2
00007d2ed8dd8658  vmovaps [rsp+0x30], xmm3
00007d2ed8dd865e  vmovaps [rsp+0x40], xmm4
00007d2ed8dd8664  vmovaps [rsp+0x50], xmm5
00007d2ed8dd866a  vmovaps [rsp+0x60], xmm6
00007d2ed8dd8670  vmovaps [rsp+0x70], xmm7
00007d2ed8dd8676  vmovaps [rsp+0x80], xmm8
00007d2ed8dd867f  vmovaps [rsp+0x90], xmm9
00007d2ed8dd8688  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd8691  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd869a  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd86a3  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd86ac  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd86b5  sub rsp, 0x30
00007d2ed8dd86b9  movaps [rsp], xmm15
00007d2ed8dd86be  movaps [rsp+0x10], xmm3
00007d2ed8dd86c3  movaps [rsp+0x20], xmm7
00007d2ed8dd86c8  lea rdi, [rsp]
00007d2ed8dd86cc  mov esi, 0x00
00007d2ed8dd86d1  mov rax, 0x648718324530
00007d2ed8dd86db  call rax
00007d2ed8dd86dd  movaps xmm15, [rsp]
00007d2ed8dd86e2  add rsp, 0x30
00007d2ed8dd86e6  vmovaps xmm0, [rsp]
00007d2ed8dd86eb  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd86f1  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd86f7  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd86fd  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd8703  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd8709  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd870f  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd8715  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd871e  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd8727  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd8730  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd8739  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd8742  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd874b  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd8754  add rsp, 0xF0
00007d2ed8dd875b  pop r11
00007d2ed8dd875d  pop r10
00007d2ed8dd875f  pop r9
00007d2ed8dd8761  pop r8
00007d2ed8dd8763  pop rsi
00007d2ed8dd8764  pop rdi
00007d2ed8dd8765  pop rdx
00007d2ed8dd8766  pop rcx
00007d2ed8dd8767  pop rax
00007d2ed8dd8768  add rsp, 0x08
00007d2ed8dd876c  jmp 0x00007D2ED8DD6030
00007d2ed8dd8771  sub rsp, 0x08
00007d2ed8dd8775  push rax
00007d2ed8dd8776  push rcx
00007d2ed8dd8777  push rdx
00007d2ed8dd8778  push rdi
00007d2ed8dd8779  push rsi
00007d2ed8dd877a  push r8
00007d2ed8dd877c  push r9
00007d2ed8dd877e  push r10
00007d2ed8dd8780  push r11
00007d2ed8dd8782  sub rsp, 0xF0
00007d2ed8dd8789  vmovaps [rsp], xmm0
00007d2ed8dd878e  vmovaps [rsp+0x10], xmm1
00007d2ed8dd8794  vmovaps [rsp+0x20], xmm2
00007d2ed8dd879a  vmovaps [rsp+0x30], xmm4
00007d2ed8dd87a0  vmovaps [rsp+0x40], xmm5
00007d2ed8dd87a6  vmovaps [rsp+0x50], xmm6
00007d2ed8dd87ac  vmovaps [rsp+0x60], xmm7
00007d2ed8dd87b2  vmovaps [rsp+0x70], xmm8
00007d2ed8dd87b8  vmovaps [rsp+0x80], xmm9
00007d2ed8dd87c1  vmovaps [rsp+0x90], xmm10
00007d2ed8dd87ca  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd87d3  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd87dc  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd87e5  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd87ee  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd87f7  sub rsp, 0x30
00007d2ed8dd87fb  movaps [rsp], xmm3
00007d2ed8dd87ff  movaps [rsp+0x10], xmm1
00007d2ed8dd8804  movaps [rsp+0x20], xmm15
00007d2ed8dd880a  lea rdi, [rsp]
00007d2ed8dd880e  mov esi, 0x00
00007d2ed8dd8813  mov rax, 0x648718324530
00007d2ed8dd881d  call rax
00007d2ed8dd881f  movaps xmm3, [rsp]
00007d2ed8dd8823  add rsp, 0x30
00007d2ed8dd8827  vmovaps xmm0, [rsp]
00007d2ed8dd882c  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd8832  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd8838  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd883e  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd8844  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd884a  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd8850  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd8856  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd885f  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd8868  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd8871  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd887a  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd8883  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd888c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd8895  add rsp, 0xF0
00007d2ed8dd889c  pop r11
00007d2ed8dd889e  pop r10
00007d2ed8dd88a0  pop r9
00007d2ed8dd88a2  pop r8
00007d2ed8dd88a4  pop rsi
00007d2ed8dd88a5  pop rdi
00007d2ed8dd88a6  pop rdx
00007d2ed8dd88a7  pop rcx
00007d2ed8dd88a8  pop rax
00007d2ed8dd88a9  add rsp, 0x08
00007d2ed8dd88ad  jmp 0x00007D2ED8DD60BF
00007d2ed8dd88b2  call 0x00007D2ED8CD64F0
00007d2ed8dd88b7  jmp 0x00007D2ED8DD60C9
00007d2ed8dd88bc  sub rsp, 0x08
00007d2ed8dd88c0  push rax
00007d2ed8dd88c1  push rcx
00007d2ed8dd88c2  push rdx
00007d2ed8dd88c3  push rdi
00007d2ed8dd88c4  push rsi
00007d2ed8dd88c5  push r8
00007d2ed8dd88c7  push r9
00007d2ed8dd88c9  push r10
00007d2ed8dd88cb  push r11
00007d2ed8dd88cd  sub rsp, 0xF0
00007d2ed8dd88d4  vmovaps [rsp], xmm0
00007d2ed8dd88d9  vmovaps [rsp+0x10], xmm1
00007d2ed8dd88df  vmovaps [rsp+0x20], xmm2
00007d2ed8dd88e5  vmovaps [rsp+0x30], xmm3
00007d2ed8dd88eb  vmovaps [rsp+0x40], xmm4
00007d2ed8dd88f1  vmovaps [rsp+0x50], xmm5
00007d2ed8dd88f7  vmovaps [rsp+0x60], xmm6
00007d2ed8dd88fd  vmovaps [rsp+0x70], xmm7
00007d2ed8dd8903  vmovaps [rsp+0x80], xmm8
00007d2ed8dd890c  vmovaps [rsp+0x90], xmm9
00007d2ed8dd8915  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd891e  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd8927  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd8930  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd8939  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd8942  sub rsp, 0x30
00007d2ed8dd8946  movaps [rsp], xmm15
00007d2ed8dd894b  movaps [rsp+0x10], xmm14
00007d2ed8dd8951  movaps [rsp+0x20], xmm4
00007d2ed8dd8956  lea rdi, [rsp]
00007d2ed8dd895a  mov esi, 0x00
00007d2ed8dd895f  mov rax, 0x648718324530
00007d2ed8dd8969  call rax
00007d2ed8dd896b  movaps xmm15, [rsp]
00007d2ed8dd8970  add rsp, 0x30
00007d2ed8dd8974  vmovaps xmm0, [rsp]
00007d2ed8dd8979  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd897f  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd8985  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd898b  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd8991  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd8997  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd899d  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd89a3  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd89ac  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd89b5  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd89be  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd89c7  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd89d0  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd89d9  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd89e2  add rsp, 0xF0
00007d2ed8dd89e9  pop r11
00007d2ed8dd89eb  pop r10
00007d2ed8dd89ed  pop r9
00007d2ed8dd89ef  pop r8
00007d2ed8dd89f1  pop rsi
00007d2ed8dd89f2  pop rdi
00007d2ed8dd89f3  pop rdx
00007d2ed8dd89f4  pop rcx
00007d2ed8dd89f5  pop rax
00007d2ed8dd89f6  add rsp, 0x08
00007d2ed8dd89fa  jmp 0x00007D2ED8DD60F7
00007d2ed8dd89ff  sub rsp, 0x08
00007d2ed8dd8a03  push rax
00007d2ed8dd8a04  push rcx
00007d2ed8dd8a05  push rdx
00007d2ed8dd8a06  push rdi
00007d2ed8dd8a07  push rsi
00007d2ed8dd8a08  push r8
00007d2ed8dd8a0a  push r9
00007d2ed8dd8a0c  push r10
00007d2ed8dd8a0e  push r11
00007d2ed8dd8a10  sub rsp, 0xF0
00007d2ed8dd8a17  vmovaps [rsp], xmm0
00007d2ed8dd8a1c  vmovaps [rsp+0x10], xmm1
00007d2ed8dd8a22  vmovaps [rsp+0x20], xmm2
00007d2ed8dd8a28  vmovaps [rsp+0x30], xmm3
00007d2ed8dd8a2e  vmovaps [rsp+0x40], xmm4
00007d2ed8dd8a34  vmovaps [rsp+0x50], xmm5
00007d2ed8dd8a3a  vmovaps [rsp+0x60], xmm6
00007d2ed8dd8a40  vmovaps [rsp+0x70], xmm7
00007d2ed8dd8a46  vmovaps [rsp+0x80], xmm8
00007d2ed8dd8a4f  vmovaps [rsp+0x90], xmm9
00007d2ed8dd8a58  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd8a61  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd8a6a  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd8a73  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd8a7c  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd8a85  sub rsp, 0x30
00007d2ed8dd8a89  movaps [rsp], xmm14
00007d2ed8dd8a8e  movaps [rsp+0x10], xmm2
00007d2ed8dd8a93  movaps [rsp+0x20], xmm1
00007d2ed8dd8a98  lea rdi, [rsp]
00007d2ed8dd8a9c  mov esi, 0x00
00007d2ed8dd8aa1  mov rax, 0x648718324530
00007d2ed8dd8aab  call rax
00007d2ed8dd8aad  movaps xmm14, [rsp]
00007d2ed8dd8ab2  add rsp, 0x30
00007d2ed8dd8ab6  vmovaps xmm0, [rsp]
00007d2ed8dd8abb  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd8ac1  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd8ac7  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd8acd  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd8ad3  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd8ad9  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd8adf  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd8ae5  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd8aee  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd8af7  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd8b00  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd8b09  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd8b12  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd8b1b  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd8b24  add rsp, 0xF0
00007d2ed8dd8b2b  pop r11
00007d2ed8dd8b2d  pop r10
00007d2ed8dd8b2f  pop r9
00007d2ed8dd8b31  pop r8
00007d2ed8dd8b33  pop rsi
00007d2ed8dd8b34  pop rdi
00007d2ed8dd8b35  pop rdx
00007d2ed8dd8b36  pop rcx
00007d2ed8dd8b37  pop rax
00007d2ed8dd8b38  add rsp, 0x08
00007d2ed8dd8b3c  jmp 0x00007D2ED8DD611D
00007d2ed8dd8b41  sub rsp, 0x08
00007d2ed8dd8b45  push rax
00007d2ed8dd8b46  push rcx
00007d2ed8dd8b47  push rdx
00007d2ed8dd8b48  push rdi
00007d2ed8dd8b49  push rsi
00007d2ed8dd8b4a  push r8
00007d2ed8dd8b4c  push r9
00007d2ed8dd8b4e  push r10
00007d2ed8dd8b50  push r11
00007d2ed8dd8b52  sub rsp, 0xF0
00007d2ed8dd8b59  vmovaps [rsp], xmm0
00007d2ed8dd8b5e  vmovaps [rsp+0x10], xmm2
00007d2ed8dd8b64  vmovaps [rsp+0x20], xmm3
00007d2ed8dd8b6a  vmovaps [rsp+0x30], xmm4
00007d2ed8dd8b70  vmovaps [rsp+0x40], xmm5
00007d2ed8dd8b76  vmovaps [rsp+0x50], xmm6
00007d2ed8dd8b7c  vmovaps [rsp+0x60], xmm7
00007d2ed8dd8b82  vmovaps [rsp+0x70], xmm8
00007d2ed8dd8b88  vmovaps [rsp+0x80], xmm9
00007d2ed8dd8b91  vmovaps [rsp+0x90], xmm10
00007d2ed8dd8b9a  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd8ba3  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd8bac  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd8bb5  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd8bbe  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd8bc7  sub rsp, 0x30
00007d2ed8dd8bcb  movaps [rsp], xmm1
00007d2ed8dd8bcf  movaps [rsp+0x10], xmm4
00007d2ed8dd8bd4  movaps [rsp+0x20], xmm9
00007d2ed8dd8bda  lea rdi, [rsp]
00007d2ed8dd8bde  mov esi, 0x00
00007d2ed8dd8be3  mov rax, 0x648718324530
00007d2ed8dd8bed  call rax
00007d2ed8dd8bef  movaps xmm1, [rsp]
00007d2ed8dd8bf3  add rsp, 0x30
00007d2ed8dd8bf7  vmovaps xmm0, [rsp]
00007d2ed8dd8bfc  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd8c02  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd8c08  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd8c0e  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd8c14  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd8c1a  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd8c20  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd8c26  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd8c2f  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd8c38  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd8c41  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd8c4a  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd8c53  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd8c5c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd8c65  add rsp, 0xF0
00007d2ed8dd8c6c  pop r11
00007d2ed8dd8c6e  pop r10
00007d2ed8dd8c70  pop r9
00007d2ed8dd8c72  pop r8
00007d2ed8dd8c74  pop rsi
00007d2ed8dd8c75  pop rdi
00007d2ed8dd8c76  pop rdx
00007d2ed8dd8c77  pop rcx
00007d2ed8dd8c78  pop rax
00007d2ed8dd8c79  add rsp, 0x08
00007d2ed8dd8c7d  jmp 0x00007D2ED8DD613B
00007d2ed8dd8c82  sub rsp, 0x08
00007d2ed8dd8c86  push rax
00007d2ed8dd8c87  push rcx
00007d2ed8dd8c88  push rdx
00007d2ed8dd8c89  push rdi
00007d2ed8dd8c8a  push rsi
00007d2ed8dd8c8b  push r8
00007d2ed8dd8c8d  push r9
00007d2ed8dd8c8f  push r10
00007d2ed8dd8c91  push r11
00007d2ed8dd8c93  sub rsp, 0xF0
00007d2ed8dd8c9a  vmovaps [rsp], xmm0
00007d2ed8dd8c9f  vmovaps [rsp+0x10], xmm1
00007d2ed8dd8ca5  vmovaps [rsp+0x20], xmm2
00007d2ed8dd8cab  vmovaps [rsp+0x30], xmm3
00007d2ed8dd8cb1  vmovaps [rsp+0x40], xmm5
00007d2ed8dd8cb7  vmovaps [rsp+0x50], xmm6
00007d2ed8dd8cbd  vmovaps [rsp+0x60], xmm7
00007d2ed8dd8cc3  vmovaps [rsp+0x70], xmm8
00007d2ed8dd8cc9  vmovaps [rsp+0x80], xmm9
00007d2ed8dd8cd2  vmovaps [rsp+0x90], xmm10
00007d2ed8dd8cdb  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd8ce4  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd8ced  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd8cf6  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd8cff  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd8d08  sub rsp, 0x30
00007d2ed8dd8d0c  movaps [rsp], xmm4
00007d2ed8dd8d10  movaps [rsp+0x10], xmm2
00007d2ed8dd8d15  movaps [rsp+0x20], xmm9
00007d2ed8dd8d1b  lea rdi, [rsp]
00007d2ed8dd8d1f  mov esi, 0x00
00007d2ed8dd8d24  mov rax, 0x648718324530
00007d2ed8dd8d2e  call rax
00007d2ed8dd8d30  movaps xmm4, [rsp]
00007d2ed8dd8d34  add rsp, 0x30
00007d2ed8dd8d38  vmovaps xmm0, [rsp]
00007d2ed8dd8d3d  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd8d43  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd8d49  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd8d4f  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd8d55  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd8d5b  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd8d61  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd8d67  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd8d70  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd8d79  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd8d82  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd8d8b  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd8d94  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd8d9d  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd8da6  add rsp, 0xF0
00007d2ed8dd8dad  pop r11
00007d2ed8dd8daf  pop r10
00007d2ed8dd8db1  pop r9
00007d2ed8dd8db3  pop r8
00007d2ed8dd8db5  pop rsi
00007d2ed8dd8db6  pop rdi
00007d2ed8dd8db7  pop rdx
00007d2ed8dd8db8  pop rcx
00007d2ed8dd8db9  pop rax
00007d2ed8dd8dba  add rsp, 0x08
00007d2ed8dd8dbe  jmp 0x00007D2ED8DD616B
00007d2ed8dd8dc3  sub rsp, 0x08
00007d2ed8dd8dc7  push rax
00007d2ed8dd8dc8  push rcx
00007d2ed8dd8dc9  push rdx
00007d2ed8dd8dca  push rdi
00007d2ed8dd8dcb  push rsi
00007d2ed8dd8dcc  push r8
00007d2ed8dd8dce  push r9
00007d2ed8dd8dd0  push r10
00007d2ed8dd8dd2  push r11
00007d2ed8dd8dd4  sub rsp, 0xF0
00007d2ed8dd8ddb  vmovaps [rsp], xmm0
00007d2ed8dd8de0  vmovaps [rsp+0x10], xmm1
00007d2ed8dd8de6  vmovaps [rsp+0x20], xmm2
00007d2ed8dd8dec  vmovaps [rsp+0x30], xmm3
00007d2ed8dd8df2  vmovaps [rsp+0x40], xmm4
00007d2ed8dd8df8  vmovaps [rsp+0x50], xmm5
00007d2ed8dd8dfe  vmovaps [rsp+0x60], xmm6
00007d2ed8dd8e04  vmovaps [rsp+0x70], xmm7
00007d2ed8dd8e0a  vmovaps [rsp+0x80], xmm8
00007d2ed8dd8e13  vmovaps [rsp+0x90], xmm10
00007d2ed8dd8e1c  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd8e25  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd8e2e  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd8e37  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd8e40  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd8e49  sub rsp, 0x30
00007d2ed8dd8e4d  movaps [rsp], xmm9
00007d2ed8dd8e52  movaps [rsp+0x10], xmm2
00007d2ed8dd8e57  movaps [rsp+0x20], xmm1
00007d2ed8dd8e5c  lea rdi, [rsp]
00007d2ed8dd8e60  mov esi, 0x00
00007d2ed8dd8e65  mov rax, 0x648718324530
00007d2ed8dd8e6f  call rax
00007d2ed8dd8e71  movaps xmm9, [rsp]
00007d2ed8dd8e76  add rsp, 0x30
00007d2ed8dd8e7a  vmovaps xmm0, [rsp]
00007d2ed8dd8e7f  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd8e85  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd8e8b  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd8e91  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd8e97  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd8e9d  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd8ea3  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd8ea9  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd8eb2  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd8ebb  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd8ec4  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd8ecd  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd8ed6  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd8edf  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd8ee8  add rsp, 0xF0
00007d2ed8dd8eef  pop r11
00007d2ed8dd8ef1  pop r10
00007d2ed8dd8ef3  pop r9
00007d2ed8dd8ef5  pop r8
00007d2ed8dd8ef7  pop rsi
00007d2ed8dd8ef8  pop rdi
00007d2ed8dd8ef9  pop rdx
00007d2ed8dd8efa  pop rcx
00007d2ed8dd8efb  pop rax
00007d2ed8dd8efc  add rsp, 0x08
00007d2ed8dd8f00  jmp 0x00007D2ED8DD61A1
00007d2ed8dd8f05  sub rsp, 0x08
00007d2ed8dd8f09  push rax
00007d2ed8dd8f0a  push rcx
00007d2ed8dd8f0b  push rdx
00007d2ed8dd8f0c  push rdi
00007d2ed8dd8f0d  push rsi
00007d2ed8dd8f0e  push r8
00007d2ed8dd8f10  push r9
00007d2ed8dd8f12  push r10
00007d2ed8dd8f14  push r11
00007d2ed8dd8f16  sub rsp, 0xF0
00007d2ed8dd8f1d  vmovaps [rsp], xmm0
00007d2ed8dd8f22  vmovaps [rsp+0x10], xmm2
00007d2ed8dd8f28  vmovaps [rsp+0x20], xmm3
00007d2ed8dd8f2e  vmovaps [rsp+0x30], xmm4
00007d2ed8dd8f34  vmovaps [rsp+0x40], xmm5
00007d2ed8dd8f3a  vmovaps [rsp+0x50], xmm6
00007d2ed8dd8f40  vmovaps [rsp+0x60], xmm7
00007d2ed8dd8f46  vmovaps [rsp+0x70], xmm8
00007d2ed8dd8f4c  vmovaps [rsp+0x80], xmm9
00007d2ed8dd8f55  vmovaps [rsp+0x90], xmm10
00007d2ed8dd8f5e  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd8f67  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd8f70  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd8f79  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd8f82  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd8f8b  sub rsp, 0x30
00007d2ed8dd8f8f  movaps [rsp], xmm1
00007d2ed8dd8f93  movaps [rsp+0x10], xmm15
00007d2ed8dd8f99  movaps [rsp+0x20], xmm6
00007d2ed8dd8f9e  lea rdi, [rsp]
00007d2ed8dd8fa2  mov esi, 0x00
00007d2ed8dd8fa7  mov rax, 0x648718324530
00007d2ed8dd8fb1  call rax
00007d2ed8dd8fb3  movaps xmm1, [rsp]
00007d2ed8dd8fb7  add rsp, 0x30
00007d2ed8dd8fbb  vmovaps xmm0, [rsp]
00007d2ed8dd8fc0  vmovaps xmm2, [rsp+0x10]
00007d2ed8dd8fc6  vmovaps xmm3, [rsp+0x20]
00007d2ed8dd8fcc  vmovaps xmm4, [rsp+0x30]
00007d2ed8dd8fd2  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd8fd8  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd8fde  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd8fe4  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd8fea  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd8ff3  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd8ffc  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd9005  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd900e  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd9017  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd9020  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd9029  add rsp, 0xF0
00007d2ed8dd9030  pop r11
00007d2ed8dd9032  pop r10
00007d2ed8dd9034  pop r9
00007d2ed8dd9036  pop r8
00007d2ed8dd9038  pop rsi
00007d2ed8dd9039  pop rdi
00007d2ed8dd903a  pop rdx
00007d2ed8dd903b  pop rcx
00007d2ed8dd903c  pop rax
00007d2ed8dd903d  add rsp, 0x08
00007d2ed8dd9041  jmp 0x00007D2ED8DD61C2
00007d2ed8dd9046  sub rsp, 0x08
00007d2ed8dd904a  push rax
00007d2ed8dd904b  push rcx
00007d2ed8dd904c  push rdx
00007d2ed8dd904d  push rdi
00007d2ed8dd904e  push rsi
00007d2ed8dd904f  push r8
00007d2ed8dd9051  push r9
00007d2ed8dd9053  push r10
00007d2ed8dd9055  push r11
00007d2ed8dd9057  sub rsp, 0xF0
00007d2ed8dd905e  vmovaps [rsp], xmm0
00007d2ed8dd9063  vmovaps [rsp+0x10], xmm1
00007d2ed8dd9069  vmovaps [rsp+0x20], xmm2
00007d2ed8dd906f  vmovaps [rsp+0x30], xmm3
00007d2ed8dd9075  vmovaps [rsp+0x40], xmm4
00007d2ed8dd907b  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9081  vmovaps [rsp+0x60], xmm6
00007d2ed8dd9087  vmovaps [rsp+0x70], xmm7
00007d2ed8dd908d  vmovaps [rsp+0x80], xmm8
00007d2ed8dd9096  vmovaps [rsp+0x90], xmm9
00007d2ed8dd909f  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd90a8  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd90b1  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd90ba  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd90c3  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd90cc  sub rsp, 0x30
00007d2ed8dd90d0  movaps [rsp], xmm15
00007d2ed8dd90d5  movaps [rsp+0x10], xmm5
00007d2ed8dd90da  movaps [rsp+0x20], xmm3
00007d2ed8dd90df  lea rdi, [rsp]
00007d2ed8dd90e3  mov esi, 0x00
00007d2ed8dd90e8  mov rax, 0x648718324530
00007d2ed8dd90f2  call rax
00007d2ed8dd90f4  movaps xmm15, [rsp]
00007d2ed8dd90f9  add rsp, 0x30
00007d2ed8dd90fd  vmovaps xmm0, [rsp]
00007d2ed8dd9102  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9108  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd910e  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd9114  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd911a  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd9120  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd9126  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd912c  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd9135  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd913e  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd9147  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd9150  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd9159  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd9162  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd916b  add rsp, 0xF0
00007d2ed8dd9172  pop r11
00007d2ed8dd9174  pop r10
00007d2ed8dd9176  pop r9
00007d2ed8dd9178  pop r8
00007d2ed8dd917a  pop rsi
00007d2ed8dd917b  pop rdi
00007d2ed8dd917c  pop rdx
00007d2ed8dd917d  pop rcx
00007d2ed8dd917e  pop rax
00007d2ed8dd917f  add rsp, 0x08
00007d2ed8dd9183  jmp 0x00007D2ED8DD61DC
00007d2ed8dd9188  sub rsp, 0x08
00007d2ed8dd918c  push rax
00007d2ed8dd918d  push rcx
00007d2ed8dd918e  push rdx
00007d2ed8dd918f  push rdi
00007d2ed8dd9190  push rsi
00007d2ed8dd9191  push r8
00007d2ed8dd9193  push r9
00007d2ed8dd9195  push r10
00007d2ed8dd9197  push r11
00007d2ed8dd9199  sub rsp, 0xF0
00007d2ed8dd91a0  vmovaps [rsp], xmm0
00007d2ed8dd91a5  vmovaps [rsp+0x10], xmm1
00007d2ed8dd91ab  vmovaps [rsp+0x20], xmm2
00007d2ed8dd91b1  vmovaps [rsp+0x30], xmm3
00007d2ed8dd91b7  vmovaps [rsp+0x40], xmm4
00007d2ed8dd91bd  vmovaps [rsp+0x50], xmm6
00007d2ed8dd91c3  vmovaps [rsp+0x60], xmm7
00007d2ed8dd91c9  vmovaps [rsp+0x70], xmm8
00007d2ed8dd91cf  vmovaps [rsp+0x80], xmm9
00007d2ed8dd91d8  vmovaps [rsp+0x90], xmm10
00007d2ed8dd91e1  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd91ea  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd91f3  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd91fc  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9205  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd920e  sub rsp, 0x30
00007d2ed8dd9212  movaps [rsp], xmm5
00007d2ed8dd9216  movaps [rsp+0x10], xmm8
00007d2ed8dd921c  movaps [rsp+0x20], xmm6
00007d2ed8dd9221  lea rdi, [rsp]
00007d2ed8dd9225  mov esi, 0x00
00007d2ed8dd922a  mov rax, 0x648718324530
00007d2ed8dd9234  call rax
00007d2ed8dd9236  movaps xmm5, [rsp]
00007d2ed8dd923a  add rsp, 0x30
00007d2ed8dd923e  vmovaps xmm0, [rsp]
00007d2ed8dd9243  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9249  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd924f  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd9255  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd925b  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd9261  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd9267  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd926d  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd9276  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd927f  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd9288  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd9291  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd929a  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd92a3  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd92ac  add rsp, 0xF0
00007d2ed8dd92b3  pop r11
00007d2ed8dd92b5  pop r10
00007d2ed8dd92b7  pop r9
00007d2ed8dd92b9  pop r8
00007d2ed8dd92bb  pop rsi
00007d2ed8dd92bc  pop rdi
00007d2ed8dd92bd  pop rdx
00007d2ed8dd92be  pop rcx
00007d2ed8dd92bf  pop rax
00007d2ed8dd92c0  add rsp, 0x08
00007d2ed8dd92c4  jmp 0x00007D2ED8DD6200
00007d2ed8dd92c9  sub rsp, 0x08
00007d2ed8dd92cd  push rax
00007d2ed8dd92ce  push rcx
00007d2ed8dd92cf  push rdx
00007d2ed8dd92d0  push rdi
00007d2ed8dd92d1  push rsi
00007d2ed8dd92d2  push r8
00007d2ed8dd92d4  push r9
00007d2ed8dd92d6  push r10
00007d2ed8dd92d8  push r11
00007d2ed8dd92da  sub rsp, 0xF0
00007d2ed8dd92e1  vmovaps [rsp], xmm0
00007d2ed8dd92e6  vmovaps [rsp+0x10], xmm1
00007d2ed8dd92ec  vmovaps [rsp+0x20], xmm2
00007d2ed8dd92f2  vmovaps [rsp+0x30], xmm3
00007d2ed8dd92f8  vmovaps [rsp+0x40], xmm4
00007d2ed8dd92fe  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9304  vmovaps [rsp+0x60], xmm7
00007d2ed8dd930a  vmovaps [rsp+0x70], xmm8
00007d2ed8dd9310  vmovaps [rsp+0x80], xmm9
00007d2ed8dd9319  vmovaps [rsp+0x90], xmm10
00007d2ed8dd9322  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd932b  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd9334  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd933d  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9346  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd934f  sub rsp, 0x30
00007d2ed8dd9353  movaps [rsp], xmm6
00007d2ed8dd9357  movaps [rsp+0x10], xmm10
00007d2ed8dd935d  movaps [rsp+0x20], xmm8
00007d2ed8dd9363  lea rdi, [rsp]
00007d2ed8dd9367  mov esi, 0x00
00007d2ed8dd936c  mov rax, 0x648718324530
00007d2ed8dd9376  call rax
00007d2ed8dd9378  movaps xmm6, [rsp]
00007d2ed8dd937c  add rsp, 0x30
00007d2ed8dd9380  vmovaps xmm0, [rsp]
00007d2ed8dd9385  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd938b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd9391  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd9397  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd939d  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd93a3  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd93a9  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd93af  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd93b8  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd93c1  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd93ca  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd93d3  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd93dc  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd93e5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd93ee  add rsp, 0xF0
00007d2ed8dd93f5  pop r11
00007d2ed8dd93f7  pop r10
00007d2ed8dd93f9  pop r9
00007d2ed8dd93fb  pop r8
00007d2ed8dd93fd  pop rsi
00007d2ed8dd93fe  pop rdi
00007d2ed8dd93ff  pop rdx
00007d2ed8dd9400  pop rcx
00007d2ed8dd9401  pop rax
00007d2ed8dd9402  add rsp, 0x08
00007d2ed8dd9406  jmp 0x00007D2ED8DD6225
00007d2ed8dd940b  sub rsp, 0x08
00007d2ed8dd940f  push rax
00007d2ed8dd9410  push rcx
00007d2ed8dd9411  push rdx
00007d2ed8dd9412  push rdi
00007d2ed8dd9413  push rsi
00007d2ed8dd9414  push r8
00007d2ed8dd9416  push r9
00007d2ed8dd9418  push r10
00007d2ed8dd941a  push r11
00007d2ed8dd941c  sub rsp, 0xF0
00007d2ed8dd9423  vmovaps [rsp], xmm0
00007d2ed8dd9428  vmovaps [rsp+0x10], xmm1
00007d2ed8dd942e  vmovaps [rsp+0x20], xmm2
00007d2ed8dd9434  vmovaps [rsp+0x30], xmm3
00007d2ed8dd943a  vmovaps [rsp+0x40], xmm4
00007d2ed8dd9440  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9446  vmovaps [rsp+0x60], xmm6
00007d2ed8dd944c  vmovaps [rsp+0x70], xmm7
00007d2ed8dd9452  vmovaps [rsp+0x80], xmm8
00007d2ed8dd945b  vmovaps [rsp+0x90], xmm9
00007d2ed8dd9464  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd946d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd9476  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd947f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9488  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd9491  sub rsp, 0x30
00007d2ed8dd9495  movaps [rsp], xmm10
00007d2ed8dd949a  movaps [rsp+0x10], xmm8
00007d2ed8dd94a0  movaps [rsp+0x20], xmm14
00007d2ed8dd94a6  lea rdi, [rsp]
00007d2ed8dd94aa  mov esi, 0x00
00007d2ed8dd94af  mov rax, 0x648718324530
00007d2ed8dd94b9  call rax
00007d2ed8dd94bb  movaps xmm10, [rsp]
00007d2ed8dd94c0  add rsp, 0x30
00007d2ed8dd94c4  vmovaps xmm0, [rsp]
00007d2ed8dd94c9  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd94cf  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd94d5  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd94db  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd94e1  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd94e7  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd94ed  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd94f3  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd94fc  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd9505  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd950e  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd9517  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd9520  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd9529  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd9532  add rsp, 0xF0
00007d2ed8dd9539  pop r11
00007d2ed8dd953b  pop r10
00007d2ed8dd953d  pop r9
00007d2ed8dd953f  pop r8
00007d2ed8dd9541  pop rsi
00007d2ed8dd9542  pop rdi
00007d2ed8dd9543  pop rdx
00007d2ed8dd9544  pop rcx
00007d2ed8dd9545  pop rax
00007d2ed8dd9546  add rsp, 0x08
00007d2ed8dd954a  jmp 0x00007D2ED8DD6245
00007d2ed8dd954f  sub rsp, 0x08
00007d2ed8dd9553  push rax
00007d2ed8dd9554  push rcx
00007d2ed8dd9555  push rdx
00007d2ed8dd9556  push rdi
00007d2ed8dd9557  push rsi
00007d2ed8dd9558  push r8
00007d2ed8dd955a  push r9
00007d2ed8dd955c  push r10
00007d2ed8dd955e  push r11
00007d2ed8dd9560  sub rsp, 0xF0
00007d2ed8dd9567  vmovaps [rsp], xmm0
00007d2ed8dd956c  vmovaps [rsp+0x10], xmm1
00007d2ed8dd9572  vmovaps [rsp+0x20], xmm2
00007d2ed8dd9578  vmovaps [rsp+0x30], xmm3
00007d2ed8dd957e  vmovaps [rsp+0x40], xmm4
00007d2ed8dd9584  vmovaps [rsp+0x50], xmm5
00007d2ed8dd958a  vmovaps [rsp+0x60], xmm6
00007d2ed8dd9590  vmovaps [rsp+0x70], xmm7
00007d2ed8dd9596  vmovaps [rsp+0x80], xmm8
00007d2ed8dd959f  vmovaps [rsp+0x90], xmm9
00007d2ed8dd95a8  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd95b1  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd95ba  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd95c3  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd95cc  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd95d5  sub rsp, 0x30
00007d2ed8dd95d9  movaps [rsp], xmm14
00007d2ed8dd95de  movaps [rsp+0x10], xmm8
00007d2ed8dd95e4  movaps [rsp+0x20], xmm4
00007d2ed8dd95e9  lea rdi, [rsp]
00007d2ed8dd95ed  mov esi, 0x00
00007d2ed8dd95f2  mov rax, 0x648718324530
00007d2ed8dd95fc  call rax
00007d2ed8dd95fe  movaps xmm14, [rsp]
00007d2ed8dd9603  add rsp, 0x30
00007d2ed8dd9607  vmovaps xmm0, [rsp]
00007d2ed8dd960c  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9612  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd9618  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd961e  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd9624  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd962a  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd9630  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd9636  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd963f  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd9648  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd9651  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd965a  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd9663  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd966c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd9675  add rsp, 0xF0
00007d2ed8dd967c  pop r11
00007d2ed8dd967e  pop r10
00007d2ed8dd9680  pop r9
00007d2ed8dd9682  pop r8
00007d2ed8dd9684  pop rsi
00007d2ed8dd9685  pop rdi
00007d2ed8dd9686  pop rdx
00007d2ed8dd9687  pop rcx
00007d2ed8dd9688  pop rax
00007d2ed8dd9689  add rsp, 0x08
00007d2ed8dd968d  jmp 0x00007D2ED8DD6265
00007d2ed8dd9692  sub rsp, 0x08
00007d2ed8dd9696  push rax
00007d2ed8dd9697  push rcx
00007d2ed8dd9698  push rdx
00007d2ed8dd9699  push rdi
00007d2ed8dd969a  push rsi
00007d2ed8dd969b  push r8
00007d2ed8dd969d  push r9
00007d2ed8dd969f  push r10
00007d2ed8dd96a1  push r11
00007d2ed8dd96a3  sub rsp, 0xF0
00007d2ed8dd96aa  vmovaps [rsp], xmm0
00007d2ed8dd96af  vmovaps [rsp+0x10], xmm1
00007d2ed8dd96b5  vmovaps [rsp+0x20], xmm2
00007d2ed8dd96bb  vmovaps [rsp+0x30], xmm3
00007d2ed8dd96c1  vmovaps [rsp+0x40], xmm5
00007d2ed8dd96c7  vmovaps [rsp+0x50], xmm6
00007d2ed8dd96cd  vmovaps [rsp+0x60], xmm7
00007d2ed8dd96d3  vmovaps [rsp+0x70], xmm8
00007d2ed8dd96d9  vmovaps [rsp+0x80], xmm9
00007d2ed8dd96e2  vmovaps [rsp+0x90], xmm10
00007d2ed8dd96eb  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd96f4  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd96fd  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd9706  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd970f  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd9718  sub rsp, 0x30
00007d2ed8dd971c  movaps [rsp], xmm4
00007d2ed8dd9720  movaps [rsp+0x10], xmm13
00007d2ed8dd9726  movaps [rsp+0x20], xmm8
00007d2ed8dd972c  lea rdi, [rsp]
00007d2ed8dd9730  mov esi, 0x00
00007d2ed8dd9735  mov rax, 0x648718324530
00007d2ed8dd973f  call rax
00007d2ed8dd9741  movaps xmm4, [rsp]
00007d2ed8dd9745  add rsp, 0x30
00007d2ed8dd9749  vmovaps xmm0, [rsp]
00007d2ed8dd974e  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9754  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd975a  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd9760  vmovaps xmm5, [rsp+0x40]
00007d2ed8dd9766  vmovaps xmm6, [rsp+0x50]
00007d2ed8dd976c  vmovaps xmm7, [rsp+0x60]
00007d2ed8dd9772  vmovaps xmm8, [rsp+0x70]
00007d2ed8dd9778  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd9781  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd978a  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd9793  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd979c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd97a5  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd97ae  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd97b7  add rsp, 0xF0
00007d2ed8dd97be  pop r11
00007d2ed8dd97c0  pop r10
00007d2ed8dd97c2  pop r9
00007d2ed8dd97c4  pop r8
00007d2ed8dd97c6  pop rsi
00007d2ed8dd97c7  pop rdi
00007d2ed8dd97c8  pop rdx
00007d2ed8dd97c9  pop rcx
00007d2ed8dd97ca  pop rax
00007d2ed8dd97cb  add rsp, 0x08
00007d2ed8dd97cf  jmp 0x00007D2ED8DD628A
00007d2ed8dd97d4  sub rsp, 0x08
00007d2ed8dd97d8  push rax
00007d2ed8dd97d9  push rcx
00007d2ed8dd97da  push rdx
00007d2ed8dd97db  push rdi
00007d2ed8dd97dc  push rsi
00007d2ed8dd97dd  push r8
00007d2ed8dd97df  push r9
00007d2ed8dd97e1  push r10
00007d2ed8dd97e3  push r11
00007d2ed8dd97e5  sub rsp, 0xF0
00007d2ed8dd97ec  vmovaps [rsp], xmm0
00007d2ed8dd97f1  vmovaps [rsp+0x10], xmm1
00007d2ed8dd97f7  vmovaps [rsp+0x20], xmm2
00007d2ed8dd97fd  vmovaps [rsp+0x30], xmm3
00007d2ed8dd9803  vmovaps [rsp+0x40], xmm4
00007d2ed8dd9809  vmovaps [rsp+0x50], xmm5
00007d2ed8dd980f  vmovaps [rsp+0x60], xmm6
00007d2ed8dd9815  vmovaps [rsp+0x70], xmm7
00007d2ed8dd981b  vmovaps [rsp+0x80], xmm8
00007d2ed8dd9824  vmovaps [rsp+0x90], xmm9
00007d2ed8dd982d  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd9836  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd983f  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd9848  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9851  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd985a  sub rsp, 0x30
00007d2ed8dd985e  movaps [rsp], xmm13
00007d2ed8dd9863  movaps [rsp+0x10], xmm15
00007d2ed8dd9869  movaps [rsp+0x20], xmm9
00007d2ed8dd986f  lea rdi, [rsp]
00007d2ed8dd9873  mov esi, 0x00
00007d2ed8dd9878  mov rax, 0x648718324530
00007d2ed8dd9882  call rax
00007d2ed8dd9884  movaps xmm13, [rsp]
00007d2ed8dd9889  add rsp, 0x30
00007d2ed8dd988d  vmovaps xmm0, [rsp]
00007d2ed8dd9892  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9898  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd989e  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd98a4  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd98aa  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd98b0  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd98b6  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd98bc  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd98c5  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd98ce  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd98d7  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd98e0  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd98e9  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd98f2  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd98fb  add rsp, 0xF0
00007d2ed8dd9902  pop r11
00007d2ed8dd9904  pop r10
00007d2ed8dd9906  pop r9
00007d2ed8dd9908  pop r8
00007d2ed8dd990a  pop rsi
00007d2ed8dd990b  pop rdi
00007d2ed8dd990c  pop rdx
00007d2ed8dd990d  pop rcx
00007d2ed8dd990e  pop rax
00007d2ed8dd990f  add rsp, 0x08
00007d2ed8dd9913  jmp 0x00007D2ED8DD62A5
00007d2ed8dd9918  sub rsp, 0x08
00007d2ed8dd991c  push rax
00007d2ed8dd991d  push rcx
00007d2ed8dd991e  push rdx
00007d2ed8dd991f  push rdi
00007d2ed8dd9920  push rsi
00007d2ed8dd9921  push r8
00007d2ed8dd9923  push r9
00007d2ed8dd9925  push r10
00007d2ed8dd9927  push r11
00007d2ed8dd9929  sub rsp, 0xF0
00007d2ed8dd9930  vmovaps [rsp], xmm0
00007d2ed8dd9935  vmovaps [rsp+0x10], xmm1
00007d2ed8dd993b  vmovaps [rsp+0x20], xmm2
00007d2ed8dd9941  vmovaps [rsp+0x30], xmm3
00007d2ed8dd9947  vmovaps [rsp+0x40], xmm4
00007d2ed8dd994d  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9953  vmovaps [rsp+0x60], xmm6
00007d2ed8dd9959  vmovaps [rsp+0x70], xmm7
00007d2ed8dd995f  vmovaps [rsp+0x80], xmm8
00007d2ed8dd9968  vmovaps [rsp+0x90], xmm9
00007d2ed8dd9971  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd997a  vmovaps [rsp+0xB0], xmm11
00007d2ed8dd9983  vmovaps [rsp+0xC0], xmm12
00007d2ed8dd998c  vmovaps [rsp+0xD0], xmm13
00007d2ed8dd9995  vmovaps [rsp+0xE0], xmm14
00007d2ed8dd999e  sub rsp, 0x30
00007d2ed8dd99a2  movaps [rsp], xmm15
00007d2ed8dd99a7  movaps [rsp+0x10], xmm1
00007d2ed8dd99ac  movaps [rsp+0x20], xmm5
00007d2ed8dd99b1  lea rdi, [rsp]
00007d2ed8dd99b5  mov esi, 0x00
00007d2ed8dd99ba  mov rax, 0x648718324530
00007d2ed8dd99c4  call rax
00007d2ed8dd99c6  movaps xmm15, [rsp]
00007d2ed8dd99cb  add rsp, 0x30
00007d2ed8dd99cf  vmovaps xmm0, [rsp]
00007d2ed8dd99d4  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd99da  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd99e0  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd99e6  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd99ec  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd99f2  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd99f8  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd99fe  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd9a07  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd9a10  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd9a19  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dd9a22  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dd9a2b  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dd9a34  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dd9a3d  add rsp, 0xF0
00007d2ed8dd9a44  pop r11
00007d2ed8dd9a46  pop r10
00007d2ed8dd9a48  pop r9
00007d2ed8dd9a4a  pop r8
00007d2ed8dd9a4c  pop rsi
00007d2ed8dd9a4d  pop rdi
00007d2ed8dd9a4e  pop rdx
00007d2ed8dd9a4f  pop rcx
00007d2ed8dd9a50  pop rax
00007d2ed8dd9a51  add rsp, 0x08
00007d2ed8dd9a55  jmp 0x00007D2ED8DD62C0
00007d2ed8dd9a5a  call 0x00007D2ED8CD64F0
00007d2ed8dd9a5f  jmp 0x00007D2ED8DD631B
00007d2ed8dd9a64  sub rsp, 0x08
00007d2ed8dd9a68  push rax
00007d2ed8dd9a69  push rcx
00007d2ed8dd9a6a  push rdx
00007d2ed8dd9a6b  push rdi
00007d2ed8dd9a6c  push rsi
00007d2ed8dd9a6d  push r8
00007d2ed8dd9a6f  push r9
00007d2ed8dd9a71  push r10
00007d2ed8dd9a73  push r11
00007d2ed8dd9a75  sub rsp, 0xF0
00007d2ed8dd9a7c  vmovaps [rsp], xmm0
00007d2ed8dd9a81  vmovaps [rsp+0x10], xmm1
00007d2ed8dd9a87  vmovaps [rsp+0x20], xmm2
00007d2ed8dd9a8d  vmovaps [rsp+0x30], xmm3
00007d2ed8dd9a93  vmovaps [rsp+0x40], xmm4
00007d2ed8dd9a99  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9a9f  vmovaps [rsp+0x60], xmm6
00007d2ed8dd9aa5  vmovaps [rsp+0x70], xmm7
00007d2ed8dd9aab  vmovaps [rsp+0x80], xmm8
00007d2ed8dd9ab4  vmovaps [rsp+0x90], xmm10
00007d2ed8dd9abd  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd9ac6  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd9acf  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd9ad8  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9ae1  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd9aea  sub rsp, 0x30
00007d2ed8dd9aee  movaps [rsp], xmm9
00007d2ed8dd9af3  movaps [rsp+0x10], xmm8
00007d2ed8dd9af9  movaps [rsp+0x20], xmm11
00007d2ed8dd9aff  lea rdi, [rsp]
00007d2ed8dd9b03  mov esi, 0x00
00007d2ed8dd9b08  mov rax, 0x648718324530
00007d2ed8dd9b12  call rax
00007d2ed8dd9b14  movaps xmm9, [rsp]
00007d2ed8dd9b19  add rsp, 0x30
00007d2ed8dd9b1d  vmovaps xmm0, [rsp]
00007d2ed8dd9b22  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9b28  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd9b2e  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd9b34  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd9b3a  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd9b40  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd9b46  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd9b4c  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd9b55  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd9b5e  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd9b67  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd9b70  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd9b79  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd9b82  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd9b8b  add rsp, 0xF0
00007d2ed8dd9b92  pop r11
00007d2ed8dd9b94  pop r10
00007d2ed8dd9b96  pop r9
00007d2ed8dd9b98  pop r8
00007d2ed8dd9b9a  pop rsi
00007d2ed8dd9b9b  pop rdi
00007d2ed8dd9b9c  pop rdx
00007d2ed8dd9b9d  pop rcx
00007d2ed8dd9b9e  pop rax
00007d2ed8dd9b9f  add rsp, 0x08
00007d2ed8dd9ba3  jmp 0x00007D2ED8DD6352
00007d2ed8dd9ba8  sub rsp, 0x08
00007d2ed8dd9bac  push rax
00007d2ed8dd9bad  push rcx
00007d2ed8dd9bae  push rdx
00007d2ed8dd9baf  push rdi
00007d2ed8dd9bb0  push rsi
00007d2ed8dd9bb1  push r8
00007d2ed8dd9bb3  push r9
00007d2ed8dd9bb5  push r10
00007d2ed8dd9bb7  push r11
00007d2ed8dd9bb9  sub rsp, 0xF0
00007d2ed8dd9bc0  vmovaps [rsp], xmm0
00007d2ed8dd9bc5  vmovaps [rsp+0x10], xmm1
00007d2ed8dd9bcb  vmovaps [rsp+0x20], xmm2
00007d2ed8dd9bd1  vmovaps [rsp+0x30], xmm3
00007d2ed8dd9bd7  vmovaps [rsp+0x40], xmm4
00007d2ed8dd9bdd  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9be3  vmovaps [rsp+0x60], xmm6
00007d2ed8dd9be9  vmovaps [rsp+0x70], xmm7
00007d2ed8dd9bef  vmovaps [rsp+0x80], xmm8
00007d2ed8dd9bf8  vmovaps [rsp+0x90], xmm9
00007d2ed8dd9c01  vmovaps [rsp+0xA0], xmm10
00007d2ed8dd9c0a  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd9c13  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd9c1c  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9c25  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd9c2e  sub rsp, 0x30
00007d2ed8dd9c32  movaps [rsp], xmm11
00007d2ed8dd9c37  movaps [rsp+0x10], xmm10
00007d2ed8dd9c3d  movaps [rsp+0x20], xmm6
00007d2ed8dd9c42  lea rdi, [rsp]
00007d2ed8dd9c46  mov esi, 0x00
00007d2ed8dd9c4b  mov rax, 0x648718324530
00007d2ed8dd9c55  call rax
00007d2ed8dd9c57  movaps xmm11, [rsp]
00007d2ed8dd9c5c  add rsp, 0x30
00007d2ed8dd9c60  vmovaps xmm0, [rsp]
00007d2ed8dd9c65  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9c6b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd9c71  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd9c77  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd9c7d  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd9c83  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd9c89  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd9c8f  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd9c98  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd9ca1  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dd9caa  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd9cb3  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd9cbc  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd9cc5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd9cce  add rsp, 0xF0
00007d2ed8dd9cd5  pop r11
00007d2ed8dd9cd7  pop r10
00007d2ed8dd9cd9  pop r9
00007d2ed8dd9cdb  pop r8
00007d2ed8dd9cdd  pop rsi
00007d2ed8dd9cde  pop rdi
00007d2ed8dd9cdf  pop rdx
00007d2ed8dd9ce0  pop rcx
00007d2ed8dd9ce1  pop rax
00007d2ed8dd9ce2  add rsp, 0x08
00007d2ed8dd9ce6  jmp 0x00007D2ED8DD636D
00007d2ed8dd9ceb  sub rsp, 0x08
00007d2ed8dd9cef  push rax
00007d2ed8dd9cf0  push rcx
00007d2ed8dd9cf1  push rdx
00007d2ed8dd9cf2  push rdi
00007d2ed8dd9cf3  push rsi
00007d2ed8dd9cf4  push r8
00007d2ed8dd9cf6  push r9
00007d2ed8dd9cf8  push r10
00007d2ed8dd9cfa  push r11
00007d2ed8dd9cfc  sub rsp, 0xF0
00007d2ed8dd9d03  vmovaps [rsp], xmm0
00007d2ed8dd9d08  vmovaps [rsp+0x10], xmm1
00007d2ed8dd9d0e  vmovaps [rsp+0x20], xmm2
00007d2ed8dd9d14  vmovaps [rsp+0x30], xmm3
00007d2ed8dd9d1a  vmovaps [rsp+0x40], xmm4
00007d2ed8dd9d20  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9d26  vmovaps [rsp+0x60], xmm6
00007d2ed8dd9d2c  vmovaps [rsp+0x70], xmm7
00007d2ed8dd9d32  vmovaps [rsp+0x80], xmm8
00007d2ed8dd9d3b  vmovaps [rsp+0x90], xmm9
00007d2ed8dd9d44  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd9d4d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd9d56  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd9d5f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9d68  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd9d71  sub rsp, 0x30
00007d2ed8dd9d75  movaps [rsp], xmm10
00007d2ed8dd9d7a  movaps [rsp+0x10], xmm14
00007d2ed8dd9d80  movaps [rsp+0x20], xmm4
00007d2ed8dd9d85  lea rdi, [rsp]
00007d2ed8dd9d89  mov esi, 0x00
00007d2ed8dd9d8e  mov rax, 0x648718324530
00007d2ed8dd9d98  call rax
00007d2ed8dd9d9a  movaps xmm10, [rsp]
00007d2ed8dd9d9f  add rsp, 0x30
00007d2ed8dd9da3  vmovaps xmm0, [rsp]
00007d2ed8dd9da8  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9dae  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd9db4  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd9dba  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd9dc0  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd9dc6  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd9dcc  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd9dd2  vmovaps xmm8, [rsp+0x80]
00007d2ed8dd9ddb  vmovaps xmm9, [rsp+0x90]
00007d2ed8dd9de4  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd9ded  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd9df6  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd9dff  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd9e08  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd9e11  add rsp, 0xF0
00007d2ed8dd9e18  pop r11
00007d2ed8dd9e1a  pop r10
00007d2ed8dd9e1c  pop r9
00007d2ed8dd9e1e  pop r8
00007d2ed8dd9e20  pop rsi
00007d2ed8dd9e21  pop rdi
00007d2ed8dd9e22  pop rdx
00007d2ed8dd9e23  pop rcx
00007d2ed8dd9e24  pop rax
00007d2ed8dd9e25  add rsp, 0x08
00007d2ed8dd9e29  jmp 0x00007D2ED8DD6388
00007d2ed8dd9e2e  sub rsp, 0x08
00007d2ed8dd9e32  push rax
00007d2ed8dd9e33  push rcx
00007d2ed8dd9e34  push rdx
00007d2ed8dd9e35  push rdi
00007d2ed8dd9e36  push rsi
00007d2ed8dd9e37  push r8
00007d2ed8dd9e39  push r9
00007d2ed8dd9e3b  push r10
00007d2ed8dd9e3d  push r11
00007d2ed8dd9e3f  sub rsp, 0xF0
00007d2ed8dd9e46  vmovaps [rsp], xmm0
00007d2ed8dd9e4b  vmovaps [rsp+0x10], xmm1
00007d2ed8dd9e51  vmovaps [rsp+0x20], xmm2
00007d2ed8dd9e57  vmovaps [rsp+0x30], xmm3
00007d2ed8dd9e5d  vmovaps [rsp+0x40], xmm4
00007d2ed8dd9e63  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9e69  vmovaps [rsp+0x60], xmm6
00007d2ed8dd9e6f  vmovaps [rsp+0x70], xmm7
00007d2ed8dd9e75  vmovaps [rsp+0x80], xmm9
00007d2ed8dd9e7e  vmovaps [rsp+0x90], xmm10
00007d2ed8dd9e87  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd9e90  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd9e99  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd9ea2  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9eab  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd9eb4  sub rsp, 0x30
00007d2ed8dd9eb8  movaps [rsp], xmm8
00007d2ed8dd9ebd  movaps [rsp+0x10], xmm1
00007d2ed8dd9ec2  movaps [rsp+0x20], xmm14
00007d2ed8dd9ec8  lea rdi, [rsp]
00007d2ed8dd9ecc  mov esi, 0x00
00007d2ed8dd9ed1  mov rax, 0x648718324530
00007d2ed8dd9edb  call rax
00007d2ed8dd9edd  movaps xmm8, [rsp]
00007d2ed8dd9ee2  add rsp, 0x30
00007d2ed8dd9ee6  vmovaps xmm0, [rsp]
00007d2ed8dd9eeb  vmovaps xmm1, [rsp+0x10]
00007d2ed8dd9ef1  vmovaps xmm2, [rsp+0x20]
00007d2ed8dd9ef7  vmovaps xmm3, [rsp+0x30]
00007d2ed8dd9efd  vmovaps xmm4, [rsp+0x40]
00007d2ed8dd9f03  vmovaps xmm5, [rsp+0x50]
00007d2ed8dd9f09  vmovaps xmm6, [rsp+0x60]
00007d2ed8dd9f0f  vmovaps xmm7, [rsp+0x70]
00007d2ed8dd9f15  vmovaps xmm9, [rsp+0x80]
00007d2ed8dd9f1e  vmovaps xmm10, [rsp+0x90]
00007d2ed8dd9f27  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dd9f30  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dd9f39  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dd9f42  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dd9f4b  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dd9f54  add rsp, 0xF0
00007d2ed8dd9f5b  pop r11
00007d2ed8dd9f5d  pop r10
00007d2ed8dd9f5f  pop r9
00007d2ed8dd9f61  pop r8
00007d2ed8dd9f63  pop rsi
00007d2ed8dd9f64  pop rdi
00007d2ed8dd9f65  pop rdx
00007d2ed8dd9f66  pop rcx
00007d2ed8dd9f67  pop rax
00007d2ed8dd9f68  add rsp, 0x08
00007d2ed8dd9f6c  jmp 0x00007D2ED8DD63AE
00007d2ed8dd9f71  sub rsp, 0x08
00007d2ed8dd9f75  push rax
00007d2ed8dd9f76  push rcx
00007d2ed8dd9f77  push rdx
00007d2ed8dd9f78  push rdi
00007d2ed8dd9f79  push rsi
00007d2ed8dd9f7a  push r8
00007d2ed8dd9f7c  push r9
00007d2ed8dd9f7e  push r10
00007d2ed8dd9f80  push r11
00007d2ed8dd9f82  sub rsp, 0xF0
00007d2ed8dd9f89  vmovaps [rsp], xmm0
00007d2ed8dd9f8e  vmovaps [rsp+0x10], xmm1
00007d2ed8dd9f94  vmovaps [rsp+0x20], xmm2
00007d2ed8dd9f9a  vmovaps [rsp+0x30], xmm3
00007d2ed8dd9fa0  vmovaps [rsp+0x40], xmm4
00007d2ed8dd9fa6  vmovaps [rsp+0x50], xmm5
00007d2ed8dd9fac  vmovaps [rsp+0x60], xmm7
00007d2ed8dd9fb2  vmovaps [rsp+0x70], xmm8
00007d2ed8dd9fb8  vmovaps [rsp+0x80], xmm9
00007d2ed8dd9fc1  vmovaps [rsp+0x90], xmm10
00007d2ed8dd9fca  vmovaps [rsp+0xA0], xmm11
00007d2ed8dd9fd3  vmovaps [rsp+0xB0], xmm12
00007d2ed8dd9fdc  vmovaps [rsp+0xC0], xmm13
00007d2ed8dd9fe5  vmovaps [rsp+0xD0], xmm14
00007d2ed8dd9fee  vmovaps [rsp+0xE0], xmm15
00007d2ed8dd9ff7  sub rsp, 0x30
00007d2ed8dd9ffb  movaps [rsp], xmm6
00007d2ed8dd9fff  movaps [rsp+0x10], xmm1
00007d2ed8dda004  movaps [rsp+0x20], xmm14
00007d2ed8dda00a  lea rdi, [rsp]
00007d2ed8dda00e  mov esi, 0x00
00007d2ed8dda013  mov rax, 0x648718324530
00007d2ed8dda01d  call rax
00007d2ed8dda01f  movaps xmm6, [rsp]
00007d2ed8dda023  add rsp, 0x30
00007d2ed8dda027  vmovaps xmm0, [rsp]
00007d2ed8dda02c  vmovaps xmm1, [rsp+0x10]
00007d2ed8dda032  vmovaps xmm2, [rsp+0x20]
00007d2ed8dda038  vmovaps xmm3, [rsp+0x30]
00007d2ed8dda03e  vmovaps xmm4, [rsp+0x40]
00007d2ed8dda044  vmovaps xmm5, [rsp+0x50]
00007d2ed8dda04a  vmovaps xmm7, [rsp+0x60]
00007d2ed8dda050  vmovaps xmm8, [rsp+0x70]
00007d2ed8dda056  vmovaps xmm9, [rsp+0x80]
00007d2ed8dda05f  vmovaps xmm10, [rsp+0x90]
00007d2ed8dda068  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dda071  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dda07a  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dda083  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dda08c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dda095  add rsp, 0xF0
00007d2ed8dda09c  pop r11
00007d2ed8dda09e  pop r10
00007d2ed8dda0a0  pop r9
00007d2ed8dda0a2  pop r8
00007d2ed8dda0a4  pop rsi
00007d2ed8dda0a5  pop rdi
00007d2ed8dda0a6  pop rdx
00007d2ed8dda0a7  pop rcx
00007d2ed8dda0a8  pop rax
00007d2ed8dda0a9  add rsp, 0x08
00007d2ed8dda0ad  jmp 0x00007D2ED8DD63DA
00007d2ed8dda0b2  sub rsp, 0x08
00007d2ed8dda0b6  push rax
00007d2ed8dda0b7  push rcx
00007d2ed8dda0b8  push rdx
00007d2ed8dda0b9  push rdi
00007d2ed8dda0ba  push rsi
00007d2ed8dda0bb  push r8
00007d2ed8dda0bd  push r9
00007d2ed8dda0bf  push r10
00007d2ed8dda0c1  push r11
00007d2ed8dda0c3  sub rsp, 0xF0
00007d2ed8dda0ca  vmovaps [rsp], xmm0
00007d2ed8dda0cf  vmovaps [rsp+0x10], xmm1
00007d2ed8dda0d5  vmovaps [rsp+0x20], xmm2
00007d2ed8dda0db  vmovaps [rsp+0x30], xmm3
00007d2ed8dda0e1  vmovaps [rsp+0x40], xmm4
00007d2ed8dda0e7  vmovaps [rsp+0x50], xmm5
00007d2ed8dda0ed  vmovaps [rsp+0x60], xmm6
00007d2ed8dda0f3  vmovaps [rsp+0x70], xmm7
00007d2ed8dda0f9  vmovaps [rsp+0x80], xmm8
00007d2ed8dda102  vmovaps [rsp+0x90], xmm9
00007d2ed8dda10b  vmovaps [rsp+0xA0], xmm10
00007d2ed8dda114  vmovaps [rsp+0xB0], xmm11
00007d2ed8dda11d  vmovaps [rsp+0xC0], xmm12
00007d2ed8dda126  vmovaps [rsp+0xD0], xmm13
00007d2ed8dda12f  vmovaps [rsp+0xE0], xmm15
00007d2ed8dda138  sub rsp, 0x30
00007d2ed8dda13c  movaps [rsp], xmm14
00007d2ed8dda141  movaps [rsp+0x10], xmm12
00007d2ed8dda147  movaps [rsp+0x20], xmm1
00007d2ed8dda14c  lea rdi, [rsp]
00007d2ed8dda150  mov esi, 0x00
00007d2ed8dda155  mov rax, 0x648718324530
00007d2ed8dda15f  call rax
00007d2ed8dda161  movaps xmm14, [rsp]
00007d2ed8dda166  add rsp, 0x30
00007d2ed8dda16a  vmovaps xmm0, [rsp]
00007d2ed8dda16f  vmovaps xmm1, [rsp+0x10]
00007d2ed8dda175  vmovaps xmm2, [rsp+0x20]
00007d2ed8dda17b  vmovaps xmm3, [rsp+0x30]
00007d2ed8dda181  vmovaps xmm4, [rsp+0x40]
00007d2ed8dda187  vmovaps xmm5, [rsp+0x50]
00007d2ed8dda18d  vmovaps xmm6, [rsp+0x60]
00007d2ed8dda193  vmovaps xmm7, [rsp+0x70]
00007d2ed8dda199  vmovaps xmm8, [rsp+0x80]
00007d2ed8dda1a2  vmovaps xmm9, [rsp+0x90]
00007d2ed8dda1ab  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dda1b4  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dda1bd  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dda1c6  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dda1cf  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dda1d8  add rsp, 0xF0
00007d2ed8dda1df  pop r11
00007d2ed8dda1e1  pop r10
00007d2ed8dda1e3  pop r9
00007d2ed8dda1e5  pop r8
00007d2ed8dda1e7  pop rsi
00007d2ed8dda1e8  pop rdi
00007d2ed8dda1e9  pop rdx
00007d2ed8dda1ea  pop rcx
00007d2ed8dda1eb  pop rax
00007d2ed8dda1ec  add rsp, 0x08
00007d2ed8dda1f0  jmp 0x00007D2ED8DD6400
00007d2ed8dda1f5  sub rsp, 0x08
00007d2ed8dda1f9  push rax
00007d2ed8dda1fa  push rcx
00007d2ed8dda1fb  push rdx
00007d2ed8dda1fc  push rdi
00007d2ed8dda1fd  push rsi
00007d2ed8dda1fe  push r8
00007d2ed8dda200  push r9
00007d2ed8dda202  push r10
00007d2ed8dda204  push r11
00007d2ed8dda206  sub rsp, 0xF0
00007d2ed8dda20d  vmovaps [rsp], xmm0
00007d2ed8dda212  vmovaps [rsp+0x10], xmm2
00007d2ed8dda218  vmovaps [rsp+0x20], xmm3
00007d2ed8dda21e  vmovaps [rsp+0x30], xmm4
00007d2ed8dda224  vmovaps [rsp+0x40], xmm5
00007d2ed8dda22a  vmovaps [rsp+0x50], xmm6
00007d2ed8dda230  vmovaps [rsp+0x60], xmm7
00007d2ed8dda236  vmovaps [rsp+0x70], xmm8
00007d2ed8dda23c  vmovaps [rsp+0x80], xmm9
00007d2ed8dda245  vmovaps [rsp+0x90], xmm10
00007d2ed8dda24e  vmovaps [rsp+0xA0], xmm11
00007d2ed8dda257  vmovaps [rsp+0xB0], xmm12
00007d2ed8dda260  vmovaps [rsp+0xC0], xmm13
00007d2ed8dda269  vmovaps [rsp+0xD0], xmm14
00007d2ed8dda272  vmovaps [rsp+0xE0], xmm15
00007d2ed8dda27b  sub rsp, 0x30
00007d2ed8dda27f  movaps [rsp], xmm1
00007d2ed8dda283  movaps [rsp+0x10], xmm13
00007d2ed8dda289  movaps [rsp+0x20], xmm9
00007d2ed8dda28f  lea rdi, [rsp]
00007d2ed8dda293  mov esi, 0x00
00007d2ed8dda298  mov rax, 0x648718324530
00007d2ed8dda2a2  call rax
00007d2ed8dda2a4  movaps xmm1, [rsp]
00007d2ed8dda2a8  add rsp, 0x30
00007d2ed8dda2ac  vmovaps xmm0, [rsp]
00007d2ed8dda2b1  vmovaps xmm2, [rsp+0x10]
00007d2ed8dda2b7  vmovaps xmm3, [rsp+0x20]
00007d2ed8dda2bd  vmovaps xmm4, [rsp+0x30]
00007d2ed8dda2c3  vmovaps xmm5, [rsp+0x40]
00007d2ed8dda2c9  vmovaps xmm6, [rsp+0x50]
00007d2ed8dda2cf  vmovaps xmm7, [rsp+0x60]
00007d2ed8dda2d5  vmovaps xmm8, [rsp+0x70]
00007d2ed8dda2db  vmovaps xmm9, [rsp+0x80]
00007d2ed8dda2e4  vmovaps xmm10, [rsp+0x90]
00007d2ed8dda2ed  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dda2f6  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dda2ff  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dda308  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dda311  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dda31a  add rsp, 0xF0
00007d2ed8dda321  pop r11
00007d2ed8dda323  pop r10
00007d2ed8dda325  pop r9
00007d2ed8dda327  pop r8
00007d2ed8dda329  pop rsi
00007d2ed8dda32a  pop rdi
00007d2ed8dda32b  pop rdx
00007d2ed8dda32c  pop rcx
00007d2ed8dda32d  pop rax
00007d2ed8dda32e  add rsp, 0x08
00007d2ed8dda332  jmp 0x00007D2ED8DD641A
00007d2ed8dda337  sub rsp, 0x08
00007d2ed8dda33b  push rax
00007d2ed8dda33c  push rcx
00007d2ed8dda33d  push rdx
00007d2ed8dda33e  push rdi
00007d2ed8dda33f  push rsi
00007d2ed8dda340  push r8
00007d2ed8dda342  push r9
00007d2ed8dda344  push r10
00007d2ed8dda346  push r11
00007d2ed8dda348  sub rsp, 0xF0
00007d2ed8dda34f  vmovaps [rsp], xmm0
00007d2ed8dda354  vmovaps [rsp+0x10], xmm1
00007d2ed8dda35a  vmovaps [rsp+0x20], xmm2
00007d2ed8dda360  vmovaps [rsp+0x30], xmm3
00007d2ed8dda366  vmovaps [rsp+0x40], xmm4
00007d2ed8dda36c  vmovaps [rsp+0x50], xmm5
00007d2ed8dda372  vmovaps [rsp+0x60], xmm6
00007d2ed8dda378  vmovaps [rsp+0x70], xmm7
00007d2ed8dda37e  vmovaps [rsp+0x80], xmm8
00007d2ed8dda387  vmovaps [rsp+0x90], xmm9
00007d2ed8dda390  vmovaps [rsp+0xA0], xmm10
00007d2ed8dda399  vmovaps [rsp+0xB0], xmm11
00007d2ed8dda3a2  vmovaps [rsp+0xC0], xmm13
00007d2ed8dda3ab  vmovaps [rsp+0xD0], xmm14
00007d2ed8dda3b4  vmovaps [rsp+0xE0], xmm15
00007d2ed8dda3bd  sub rsp, 0x30
00007d2ed8dda3c1  movaps [rsp], xmm12
00007d2ed8dda3c6  movaps [rsp+0x10], xmm7
00007d2ed8dda3cb  movaps [rsp+0x20], xmm13
00007d2ed8dda3d1  lea rdi, [rsp]
00007d2ed8dda3d5  mov esi, 0x00
00007d2ed8dda3da  mov rax, 0x648718324530
00007d2ed8dda3e4  call rax
00007d2ed8dda3e6  movaps xmm12, [rsp]
00007d2ed8dda3eb  add rsp, 0x30
00007d2ed8dda3ef  vmovaps xmm0, [rsp]
00007d2ed8dda3f4  vmovaps xmm1, [rsp+0x10]
00007d2ed8dda3fa  vmovaps xmm2, [rsp+0x20]
00007d2ed8dda400  vmovaps xmm3, [rsp+0x30]
00007d2ed8dda406  vmovaps xmm4, [rsp+0x40]
00007d2ed8dda40c  vmovaps xmm5, [rsp+0x50]
00007d2ed8dda412  vmovaps xmm6, [rsp+0x60]
00007d2ed8dda418  vmovaps xmm7, [rsp+0x70]
00007d2ed8dda41e  vmovaps xmm8, [rsp+0x80]
00007d2ed8dda427  vmovaps xmm9, [rsp+0x90]
00007d2ed8dda430  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dda439  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dda442  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dda44b  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dda454  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dda45d  add rsp, 0xF0
00007d2ed8dda464  pop r11
00007d2ed8dda466  pop r10
00007d2ed8dda468  pop r9
00007d2ed8dda46a  pop r8
00007d2ed8dda46c  pop rsi
00007d2ed8dda46d  pop rdi
00007d2ed8dda46e  pop rdx
00007d2ed8dda46f  pop rcx
00007d2ed8dda470  pop rax
00007d2ed8dda471  add rsp, 0x08
00007d2ed8dda475  jmp 0x00007D2ED8DD6441
00007d2ed8dda47a  sub rsp, 0x08
00007d2ed8dda47e  push rax
00007d2ed8dda47f  push rcx
00007d2ed8dda480  push rdx
00007d2ed8dda481  push rdi
00007d2ed8dda482  push rsi
00007d2ed8dda483  push r8
00007d2ed8dda485  push r9
00007d2ed8dda487  push r10
00007d2ed8dda489  push r11
00007d2ed8dda48b  sub rsp, 0xF0
00007d2ed8dda492  vmovaps [rsp], xmm0
00007d2ed8dda497  vmovaps [rsp+0x10], xmm1
00007d2ed8dda49d  vmovaps [rsp+0x20], xmm2
00007d2ed8dda4a3  vmovaps [rsp+0x30], xmm3
00007d2ed8dda4a9  vmovaps [rsp+0x40], xmm4
00007d2ed8dda4af  vmovaps [rsp+0x50], xmm5
00007d2ed8dda4b5  vmovaps [rsp+0x60], xmm6
00007d2ed8dda4bb  vmovaps [rsp+0x70], xmm7
00007d2ed8dda4c1  vmovaps [rsp+0x80], xmm8
00007d2ed8dda4ca  vmovaps [rsp+0x90], xmm9
00007d2ed8dda4d3  vmovaps [rsp+0xA0], xmm10
00007d2ed8dda4dc  vmovaps [rsp+0xB0], xmm11
00007d2ed8dda4e5  vmovaps [rsp+0xC0], xmm12
00007d2ed8dda4ee  vmovaps [rsp+0xD0], xmm14
00007d2ed8dda4f7  vmovaps [rsp+0xE0], xmm15
00007d2ed8dda500  sub rsp, 0x30
00007d2ed8dda504  movaps [rsp], xmm13
00007d2ed8dda509  movaps [rsp+0x10], xmm15
00007d2ed8dda50f  movaps [rsp+0x20], xmm8
00007d2ed8dda515  lea rdi, [rsp]
00007d2ed8dda519  mov esi, 0x00
00007d2ed8dda51e  mov rax, 0x648718324530
00007d2ed8dda528  call rax
00007d2ed8dda52a  movaps xmm13, [rsp]
00007d2ed8dda52f  add rsp, 0x30
00007d2ed8dda533  vmovaps xmm0, [rsp]
00007d2ed8dda538  vmovaps xmm1, [rsp+0x10]
00007d2ed8dda53e  vmovaps xmm2, [rsp+0x20]
00007d2ed8dda544  vmovaps xmm3, [rsp+0x30]
00007d2ed8dda54a  vmovaps xmm4, [rsp+0x40]
00007d2ed8dda550  vmovaps xmm5, [rsp+0x50]
00007d2ed8dda556  vmovaps xmm6, [rsp+0x60]
00007d2ed8dda55c  vmovaps xmm7, [rsp+0x70]
00007d2ed8dda562  vmovaps xmm8, [rsp+0x80]
00007d2ed8dda56b  vmovaps xmm9, [rsp+0x90]
00007d2ed8dda574  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dda57d  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dda586  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dda58f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dda598  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dda5a1  add rsp, 0xF0
00007d2ed8dda5a8  pop r11
00007d2ed8dda5aa  pop r10
00007d2ed8dda5ac  pop r9
00007d2ed8dda5ae  pop r8
00007d2ed8dda5b0  pop rsi
00007d2ed8dda5b1  pop rdi
00007d2ed8dda5b2  pop rdx
00007d2ed8dda5b3  pop rcx
00007d2ed8dda5b4  pop rax
00007d2ed8dda5b5  add rsp, 0x08
00007d2ed8dda5b9  jmp 0x00007D2ED8DD645C
00007d2ed8dda5be  sub rsp, 0x08
00007d2ed8dda5c2  push rax
00007d2ed8dda5c3  push rcx
00007d2ed8dda5c4  push rdx
00007d2ed8dda5c5  push rdi
00007d2ed8dda5c6  push rsi
00007d2ed8dda5c7  push r8
00007d2ed8dda5c9  push r9
00007d2ed8dda5cb  push r10
00007d2ed8dda5cd  push r11
00007d2ed8dda5cf  sub rsp, 0xF0
00007d2ed8dda5d6  vmovaps [rsp], xmm0
00007d2ed8dda5db  vmovaps [rsp+0x10], xmm1
00007d2ed8dda5e1  vmovaps [rsp+0x20], xmm2
00007d2ed8dda5e7  vmovaps [rsp+0x30], xmm3
00007d2ed8dda5ed  vmovaps [rsp+0x40], xmm4
00007d2ed8dda5f3  vmovaps [rsp+0x50], xmm5
00007d2ed8dda5f9  vmovaps [rsp+0x60], xmm6
00007d2ed8dda5ff  vmovaps [rsp+0x70], xmm7
00007d2ed8dda605  vmovaps [rsp+0x80], xmm9
00007d2ed8dda60e  vmovaps [rsp+0x90], xmm10
00007d2ed8dda617  vmovaps [rsp+0xA0], xmm11
00007d2ed8dda620  vmovaps [rsp+0xB0], xmm12
00007d2ed8dda629  vmovaps [rsp+0xC0], xmm13
00007d2ed8dda632  vmovaps [rsp+0xD0], xmm14
00007d2ed8dda63b  vmovaps [rsp+0xE0], xmm15
00007d2ed8dda644  sub rsp, 0x30
00007d2ed8dda648  movaps [rsp], xmm8
00007d2ed8dda64d  movaps [rsp+0x10], xmm15
00007d2ed8dda653  movaps [rsp+0x20], xmm9
00007d2ed8dda659  lea rdi, [rsp]
00007d2ed8dda65d  mov esi, 0x00
00007d2ed8dda662  mov rax, 0x648718324530
00007d2ed8dda66c  call rax
00007d2ed8dda66e  movaps xmm8, [rsp]
00007d2ed8dda673  add rsp, 0x30
00007d2ed8dda677  vmovaps xmm0, [rsp]
00007d2ed8dda67c  vmovaps xmm1, [rsp+0x10]
00007d2ed8dda682  vmovaps xmm2, [rsp+0x20]
00007d2ed8dda688  vmovaps xmm3, [rsp+0x30]
00007d2ed8dda68e  vmovaps xmm4, [rsp+0x40]
00007d2ed8dda694  vmovaps xmm5, [rsp+0x50]
00007d2ed8dda69a  vmovaps xmm6, [rsp+0x60]
00007d2ed8dda6a0  vmovaps xmm7, [rsp+0x70]
00007d2ed8dda6a6  vmovaps xmm9, [rsp+0x80]
00007d2ed8dda6af  vmovaps xmm10, [rsp+0x90]
00007d2ed8dda6b8  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dda6c1  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dda6ca  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dda6d3  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dda6dc  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dda6e5  add rsp, 0xF0
00007d2ed8dda6ec  pop r11
00007d2ed8dda6ee  pop r10
00007d2ed8dda6f0  pop r9
00007d2ed8dda6f2  pop r8
00007d2ed8dda6f4  pop rsi
00007d2ed8dda6f5  pop rdi
00007d2ed8dda6f6  pop rdx
00007d2ed8dda6f7  pop rcx
00007d2ed8dda6f8  pop rax
00007d2ed8dda6f9  add rsp, 0x08
00007d2ed8dda6fd  jmp 0x00007D2ED8DD648A
00007d2ed8dda702  sub rsp, 0x08
00007d2ed8dda706  push rax
00007d2ed8dda707  push rcx
00007d2ed8dda708  push rdx
00007d2ed8dda709  push rdi
00007d2ed8dda70a  push rsi
00007d2ed8dda70b  push r8
00007d2ed8dda70d  push r9
00007d2ed8dda70f  push r10
00007d2ed8dda711  push r11
00007d2ed8dda713  sub rsp, 0xF0
00007d2ed8dda71a  vmovaps [rsp], xmm0
00007d2ed8dda71f  vmovaps [rsp+0x10], xmm1
00007d2ed8dda725  vmovaps [rsp+0x20], xmm2
00007d2ed8dda72b  vmovaps [rsp+0x30], xmm3
00007d2ed8dda731  vmovaps [rsp+0x40], xmm4
00007d2ed8dda737  vmovaps [rsp+0x50], xmm5
00007d2ed8dda73d  vmovaps [rsp+0x60], xmm6
00007d2ed8dda743  vmovaps [rsp+0x70], xmm7
00007d2ed8dda749  vmovaps [rsp+0x80], xmm8
00007d2ed8dda752  vmovaps [rsp+0x90], xmm9
00007d2ed8dda75b  vmovaps [rsp+0xA0], xmm10
00007d2ed8dda764  vmovaps [rsp+0xB0], xmm11
00007d2ed8dda76d  vmovaps [rsp+0xC0], xmm12
00007d2ed8dda776  vmovaps [rsp+0xD0], xmm13
00007d2ed8dda77f  vmovaps [rsp+0xE0], xmm14
00007d2ed8dda788  sub rsp, 0x30
00007d2ed8dda78c  movaps [rsp], xmm15
00007d2ed8dda791  movaps [rsp+0x10], xmm11
00007d2ed8dda797  movaps [rsp+0x20], xmm6
00007d2ed8dda79c  lea rdi, [rsp]
00007d2ed8dda7a0  mov esi, 0x00
00007d2ed8dda7a5  mov rax, 0x648718324530
00007d2ed8dda7af  call rax
00007d2ed8dda7b1  movaps xmm15, [rsp]
00007d2ed8dda7b6  add rsp, 0x30
00007d2ed8dda7ba  vmovaps xmm0, [rsp]
00007d2ed8dda7bf  vmovaps xmm1, [rsp+0x10]
00007d2ed8dda7c5  vmovaps xmm2, [rsp+0x20]
00007d2ed8dda7cb  vmovaps xmm3, [rsp+0x30]
00007d2ed8dda7d1  vmovaps xmm4, [rsp+0x40]
00007d2ed8dda7d7  vmovaps xmm5, [rsp+0x50]
00007d2ed8dda7dd  vmovaps xmm6, [rsp+0x60]
00007d2ed8dda7e3  vmovaps xmm7, [rsp+0x70]
00007d2ed8dda7e9  vmovaps xmm8, [rsp+0x80]
00007d2ed8dda7f2  vmovaps xmm9, [rsp+0x90]
00007d2ed8dda7fb  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dda804  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dda80d  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dda816  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dda81f  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dda828  add rsp, 0xF0
00007d2ed8dda82f  pop r11
00007d2ed8dda831  pop r10
00007d2ed8dda833  pop r9
00007d2ed8dda835  pop r8
00007d2ed8dda837  pop rsi
00007d2ed8dda838  pop rdi
00007d2ed8dda839  pop rdx
00007d2ed8dda83a  pop rcx
00007d2ed8dda83b  pop rax
00007d2ed8dda83c  add rsp, 0x08
00007d2ed8dda840  jmp 0x00007D2ED8DD64A5
00007d2ed8dda845  sub rsp, 0x08
00007d2ed8dda849  push rax
00007d2ed8dda84a  push rcx
00007d2ed8dda84b  push rdx
00007d2ed8dda84c  push rdi
00007d2ed8dda84d  push rsi
00007d2ed8dda84e  push r8
00007d2ed8dda850  push r9
00007d2ed8dda852  push r10
00007d2ed8dda854  push r11
00007d2ed8dda856  sub rsp, 0xF0
00007d2ed8dda85d  vmovaps [rsp], xmm0
00007d2ed8dda862  vmovaps [rsp+0x10], xmm1
00007d2ed8dda868  vmovaps [rsp+0x20], xmm2
00007d2ed8dda86e  vmovaps [rsp+0x30], xmm3
00007d2ed8dda874  vmovaps [rsp+0x40], xmm4
00007d2ed8dda87a  vmovaps [rsp+0x50], xmm5
00007d2ed8dda880  vmovaps [rsp+0x60], xmm6
00007d2ed8dda886  vmovaps [rsp+0x70], xmm8
00007d2ed8dda88c  vmovaps [rsp+0x80], xmm9
00007d2ed8dda895  vmovaps [rsp+0x90], xmm10
00007d2ed8dda89e  vmovaps [rsp+0xA0], xmm11
00007d2ed8dda8a7  vmovaps [rsp+0xB0], xmm12
00007d2ed8dda8b0  vmovaps [rsp+0xC0], xmm13
00007d2ed8dda8b9  vmovaps [rsp+0xD0], xmm14
00007d2ed8dda8c2  vmovaps [rsp+0xE0], xmm15
00007d2ed8dda8cb  sub rsp, 0x30
00007d2ed8dda8cf  movaps [rsp], xmm7
00007d2ed8dda8d3  movaps [rsp+0x10], xmm11
00007d2ed8dda8d9  movaps [rsp+0x20], xmm9
00007d2ed8dda8df  lea rdi, [rsp]
00007d2ed8dda8e3  mov esi, 0x00
00007d2ed8dda8e8  mov rax, 0x648718324530
00007d2ed8dda8f2  call rax
00007d2ed8dda8f4  movaps xmm7, [rsp]
00007d2ed8dda8f8  add rsp, 0x30
00007d2ed8dda8fc  vmovaps xmm0, [rsp]
00007d2ed8dda901  vmovaps xmm1, [rsp+0x10]
00007d2ed8dda907  vmovaps xmm2, [rsp+0x20]
00007d2ed8dda90d  vmovaps xmm3, [rsp+0x30]
00007d2ed8dda913  vmovaps xmm4, [rsp+0x40]
00007d2ed8dda919  vmovaps xmm5, [rsp+0x50]
00007d2ed8dda91f  vmovaps xmm6, [rsp+0x60]
00007d2ed8dda925  vmovaps xmm8, [rsp+0x70]
00007d2ed8dda92b  vmovaps xmm9, [rsp+0x80]
00007d2ed8dda934  vmovaps xmm10, [rsp+0x90]
00007d2ed8dda93d  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dda946  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dda94f  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dda958  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dda961  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dda96a  add rsp, 0xF0
00007d2ed8dda971  pop r11
00007d2ed8dda973  pop r10
00007d2ed8dda975  pop r9
00007d2ed8dda977  pop r8
00007d2ed8dda979  pop rsi
00007d2ed8dda97a  pop rdi
00007d2ed8dda97b  pop rdx
00007d2ed8dda97c  pop rcx
00007d2ed8dda97d  pop rax
00007d2ed8dda97e  add rsp, 0x08
00007d2ed8dda982  jmp 0x00007D2ED8DD64D2
00007d2ed8dda987  sub rsp, 0x08
00007d2ed8dda98b  push rax
00007d2ed8dda98c  push rcx
00007d2ed8dda98d  push rdx
00007d2ed8dda98e  push rdi
00007d2ed8dda98f  push rsi
00007d2ed8dda990  push r8
00007d2ed8dda992  push r9
00007d2ed8dda994  push r10
00007d2ed8dda996  push r11
00007d2ed8dda998  sub rsp, 0xF0
00007d2ed8dda99f  vmovaps [rsp], xmm0
00007d2ed8dda9a4  vmovaps [rsp+0x10], xmm1
00007d2ed8dda9aa  vmovaps [rsp+0x20], xmm2
00007d2ed8dda9b0  vmovaps [rsp+0x30], xmm3
00007d2ed8dda9b6  vmovaps [rsp+0x40], xmm4
00007d2ed8dda9bc  vmovaps [rsp+0x50], xmm5
00007d2ed8dda9c2  vmovaps [rsp+0x60], xmm6
00007d2ed8dda9c8  vmovaps [rsp+0x70], xmm7
00007d2ed8dda9ce  vmovaps [rsp+0x80], xmm8
00007d2ed8dda9d7  vmovaps [rsp+0x90], xmm9
00007d2ed8dda9e0  vmovaps [rsp+0xA0], xmm10
00007d2ed8dda9e9  vmovaps [rsp+0xB0], xmm12
00007d2ed8dda9f2  vmovaps [rsp+0xC0], xmm13
00007d2ed8dda9fb  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddaa04  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddaa0d  sub rsp, 0x30
00007d2ed8ddaa11  movaps [rsp], xmm11
00007d2ed8ddaa16  movaps [rsp+0x10], xmm10
00007d2ed8ddaa1c  movaps [rsp+0x20], xmm14
00007d2ed8ddaa22  lea rdi, [rsp]
00007d2ed8ddaa26  mov esi, 0x00
00007d2ed8ddaa2b  mov rax, 0x648718324530
00007d2ed8ddaa35  call rax
00007d2ed8ddaa37  movaps xmm11, [rsp]
00007d2ed8ddaa3c  add rsp, 0x30
00007d2ed8ddaa40  vmovaps xmm0, [rsp]
00007d2ed8ddaa45  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddaa4b  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddaa51  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddaa57  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddaa5d  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddaa63  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddaa69  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddaa6f  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddaa78  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddaa81  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddaa8a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddaa93  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddaa9c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddaaa5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddaaae  add rsp, 0xF0
00007d2ed8ddaab5  pop r11
00007d2ed8ddaab7  pop r10
00007d2ed8ddaab9  pop r9
00007d2ed8ddaabb  pop r8
00007d2ed8ddaabd  pop rsi
00007d2ed8ddaabe  pop rdi
00007d2ed8ddaabf  pop rdx
00007d2ed8ddaac0  pop rcx
00007d2ed8ddaac1  pop rax
00007d2ed8ddaac2  add rsp, 0x08
00007d2ed8ddaac6  jmp 0x00007D2ED8DD64ED
00007d2ed8ddaacb  call 0x00007D2ED8CE45A0
00007d2ed8ddaad0  jmp 0x00007D2ED8DD64F7
00007d2ed8ddaad5  sub rsp, 0x08
00007d2ed8ddaad9  push rax
00007d2ed8ddaada  push rcx
00007d2ed8ddaadb  push rdx
00007d2ed8ddaadc  push rdi
00007d2ed8ddaadd  push rsi
00007d2ed8ddaade  push r8
00007d2ed8ddaae0  push r9
00007d2ed8ddaae2  push r10
00007d2ed8ddaae4  push r11
00007d2ed8ddaae6  sub rsp, 0xF0
00007d2ed8ddaaed  vmovaps [rsp], xmm0
00007d2ed8ddaaf2  vmovaps [rsp+0x10], xmm1
00007d2ed8ddaaf8  vmovaps [rsp+0x20], xmm2
00007d2ed8ddaafe  vmovaps [rsp+0x30], xmm3
00007d2ed8ddab04  vmovaps [rsp+0x40], xmm4
00007d2ed8ddab0a  vmovaps [rsp+0x50], xmm5
00007d2ed8ddab10  vmovaps [rsp+0x60], xmm6
00007d2ed8ddab16  vmovaps [rsp+0x70], xmm7
00007d2ed8ddab1c  vmovaps [rsp+0x80], xmm8
00007d2ed8ddab25  vmovaps [rsp+0x90], xmm9
00007d2ed8ddab2e  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddab37  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddab40  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddab49  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddab52  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddab5b  sub rsp, 0x30
00007d2ed8ddab5f  movaps [rsp], xmm10
00007d2ed8ddab64  movaps [rsp+0x10], xmm1
00007d2ed8ddab69  movaps [rsp+0x20], xmm12
00007d2ed8ddab6f  lea rdi, [rsp]
00007d2ed8ddab73  mov esi, 0x00
00007d2ed8ddab78  mov rax, 0x648718324530
00007d2ed8ddab82  call rax
00007d2ed8ddab84  movaps xmm10, [rsp]
00007d2ed8ddab89  add rsp, 0x30
00007d2ed8ddab8d  vmovaps xmm0, [rsp]
00007d2ed8ddab92  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddab98  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddab9e  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddaba4  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddabaa  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddabb0  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddabb6  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddabbc  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddabc5  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddabce  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddabd7  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddabe0  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddabe9  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddabf2  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddabfb  add rsp, 0xF0
00007d2ed8ddac02  pop r11
00007d2ed8ddac04  pop r10
00007d2ed8ddac06  pop r9
00007d2ed8ddac08  pop r8
00007d2ed8ddac0a  pop rsi
00007d2ed8ddac0b  pop rdi
00007d2ed8ddac0c  pop rdx
00007d2ed8ddac0d  pop rcx
00007d2ed8ddac0e  pop rax
00007d2ed8ddac0f  add rsp, 0x08
00007d2ed8ddac13  jmp 0x00007D2ED8DD651A
00007d2ed8ddac18  sub rsp, 0x08
00007d2ed8ddac1c  push rax
00007d2ed8ddac1d  push rcx
00007d2ed8ddac1e  push rdx
00007d2ed8ddac1f  push rdi
00007d2ed8ddac20  push rsi
00007d2ed8ddac21  push r8
00007d2ed8ddac23  push r9
00007d2ed8ddac25  push r10
00007d2ed8ddac27  push r11
00007d2ed8ddac29  sub rsp, 0xF0
00007d2ed8ddac30  vmovaps [rsp], xmm0
00007d2ed8ddac35  vmovaps [rsp+0x10], xmm1
00007d2ed8ddac3b  vmovaps [rsp+0x20], xmm2
00007d2ed8ddac41  vmovaps [rsp+0x30], xmm3
00007d2ed8ddac47  vmovaps [rsp+0x40], xmm4
00007d2ed8ddac4d  vmovaps [rsp+0x50], xmm5
00007d2ed8ddac53  vmovaps [rsp+0x60], xmm6
00007d2ed8ddac59  vmovaps [rsp+0x70], xmm7
00007d2ed8ddac5f  vmovaps [rsp+0x80], xmm8
00007d2ed8ddac68  vmovaps [rsp+0x90], xmm9
00007d2ed8ddac71  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddac7a  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddac83  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddac8c  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddac95  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddac9e  sub rsp, 0x30
00007d2ed8ddaca2  movaps [rsp], xmm12
00007d2ed8ddaca7  movaps [rsp+0x10], xmm14
00007d2ed8ddacad  movaps [rsp+0x20], xmm1
00007d2ed8ddacb2  lea rdi, [rsp]
00007d2ed8ddacb6  mov esi, 0x00
00007d2ed8ddacbb  mov rax, 0x648718324530
00007d2ed8ddacc5  call rax
00007d2ed8ddacc7  movaps xmm12, [rsp]
00007d2ed8ddaccc  add rsp, 0x30
00007d2ed8ddacd0  vmovaps xmm0, [rsp]
00007d2ed8ddacd5  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddacdb  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddace1  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddace7  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddaced  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddacf3  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddacf9  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddacff  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddad08  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddad11  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddad1a  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddad23  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddad2c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddad35  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddad3e  add rsp, 0xF0
00007d2ed8ddad45  pop r11
00007d2ed8ddad47  pop r10
00007d2ed8ddad49  pop r9
00007d2ed8ddad4b  pop r8
00007d2ed8ddad4d  pop rsi
00007d2ed8ddad4e  pop rdi
00007d2ed8ddad4f  pop rdx
00007d2ed8ddad50  pop rcx
00007d2ed8ddad51  pop rax
00007d2ed8ddad52  add rsp, 0x08
00007d2ed8ddad56  jmp 0x00007D2ED8DD6549
00007d2ed8ddad5b  sub rsp, 0x08
00007d2ed8ddad5f  push rax
00007d2ed8ddad60  push rcx
00007d2ed8ddad61  push rdx
00007d2ed8ddad62  push rdi
00007d2ed8ddad63  push rsi
00007d2ed8ddad64  push r8
00007d2ed8ddad66  push r9
00007d2ed8ddad68  push r10
00007d2ed8ddad6a  push r11
00007d2ed8ddad6c  sub rsp, 0xF0
00007d2ed8ddad73  vmovaps [rsp], xmm0
00007d2ed8ddad78  vmovaps [rsp+0x10], xmm1
00007d2ed8ddad7e  vmovaps [rsp+0x20], xmm2
00007d2ed8ddad84  vmovaps [rsp+0x30], xmm3
00007d2ed8ddad8a  vmovaps [rsp+0x40], xmm4
00007d2ed8ddad90  vmovaps [rsp+0x50], xmm5
00007d2ed8ddad96  vmovaps [rsp+0x60], xmm6
00007d2ed8ddad9c  vmovaps [rsp+0x70], xmm7
00007d2ed8ddada2  vmovaps [rsp+0x80], xmm8
00007d2ed8ddadab  vmovaps [rsp+0x90], xmm9
00007d2ed8ddadb4  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddadbd  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddadc6  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddadcf  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddadd8  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddade1  sub rsp, 0x30
00007d2ed8ddade5  movaps [rsp], xmm14
00007d2ed8ddadea  movaps [rsp+0x10], xmm9
00007d2ed8ddadf0  movaps [rsp+0x20], xmm1
00007d2ed8ddadf5  lea rdi, [rsp]
00007d2ed8ddadf9  mov esi, 0x00
00007d2ed8ddadfe  mov rax, 0x648718324530
00007d2ed8ddae08  call rax
00007d2ed8ddae0a  movaps xmm14, [rsp]
00007d2ed8ddae0f  add rsp, 0x30
00007d2ed8ddae13  vmovaps xmm0, [rsp]
00007d2ed8ddae18  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddae1e  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddae24  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddae2a  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddae30  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddae36  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddae3c  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddae42  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddae4b  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddae54  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddae5d  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddae66  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddae6f  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddae78  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddae81  add rsp, 0xF0
00007d2ed8ddae88  pop r11
00007d2ed8ddae8a  pop r10
00007d2ed8ddae8c  pop r9
00007d2ed8ddae8e  pop r8
00007d2ed8ddae90  pop rsi
00007d2ed8ddae91  pop rdi
00007d2ed8ddae92  pop rdx
00007d2ed8ddae93  pop rcx
00007d2ed8ddae94  pop rax
00007d2ed8ddae95  add rsp, 0x08
00007d2ed8ddae99  jmp 0x00007D2ED8DD6578
00007d2ed8ddae9e  sub rsp, 0x08
00007d2ed8ddaea2  push rax
00007d2ed8ddaea3  push rcx
00007d2ed8ddaea4  push rdx
00007d2ed8ddaea5  push rdi
00007d2ed8ddaea6  push rsi
00007d2ed8ddaea7  push r8
00007d2ed8ddaea9  push r9
00007d2ed8ddaeab  push r10
00007d2ed8ddaead  push r11
00007d2ed8ddaeaf  sub rsp, 0xF0
00007d2ed8ddaeb6  vmovaps [rsp], xmm0
00007d2ed8ddaebb  vmovaps [rsp+0x10], xmm2
00007d2ed8ddaec1  vmovaps [rsp+0x20], xmm3
00007d2ed8ddaec7  vmovaps [rsp+0x30], xmm4
00007d2ed8ddaecd  vmovaps [rsp+0x40], xmm5
00007d2ed8ddaed3  vmovaps [rsp+0x50], xmm6
00007d2ed8ddaed9  vmovaps [rsp+0x60], xmm7
00007d2ed8ddaedf  vmovaps [rsp+0x70], xmm8
00007d2ed8ddaee5  vmovaps [rsp+0x80], xmm9
00007d2ed8ddaeee  vmovaps [rsp+0x90], xmm10
00007d2ed8ddaef7  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddaf00  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddaf09  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddaf12  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddaf1b  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddaf24  sub rsp, 0x30
00007d2ed8ddaf28  movaps [rsp], xmm1
00007d2ed8ddaf2c  movaps [rsp+0x10], xmm13
00007d2ed8ddaf32  movaps [rsp+0x20], xmm8
00007d2ed8ddaf38  lea rdi, [rsp]
00007d2ed8ddaf3c  mov esi, 0x00
00007d2ed8ddaf41  mov rax, 0x648718324530
00007d2ed8ddaf4b  call rax
00007d2ed8ddaf4d  movaps xmm1, [rsp]
00007d2ed8ddaf51  add rsp, 0x30
00007d2ed8ddaf55  vmovaps xmm0, [rsp]
00007d2ed8ddaf5a  vmovaps xmm2, [rsp+0x10]
00007d2ed8ddaf60  vmovaps xmm3, [rsp+0x20]
00007d2ed8ddaf66  vmovaps xmm4, [rsp+0x30]
00007d2ed8ddaf6c  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddaf72  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddaf78  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddaf7e  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddaf84  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddaf8d  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddaf96  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddaf9f  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddafa8  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddafb1  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddafba  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddafc3  add rsp, 0xF0
00007d2ed8ddafca  pop r11
00007d2ed8ddafcc  pop r10
00007d2ed8ddafce  pop r9
00007d2ed8ddafd0  pop r8
00007d2ed8ddafd2  pop rsi
00007d2ed8ddafd3  pop rdi
00007d2ed8ddafd4  pop rdx
00007d2ed8ddafd5  pop rcx
00007d2ed8ddafd6  pop rax
00007d2ed8ddafd7  add rsp, 0x08
00007d2ed8ddafdb  jmp 0x00007D2ED8DD659A
00007d2ed8ddafe0  call 0x00007D2ED8C0C260
00007d2ed8ddafe5  jmp 0x00007D2ED8DD65A8
00007d2ed8ddafea  call 0x00007D2ED8CDE950
00007d2ed8ddafef  jmp 0x00007D2ED8DD65B2
00007d2ed8ddaff4  sub rsp, 0x08
00007d2ed8ddaff8  push rax
00007d2ed8ddaff9  push rcx
00007d2ed8ddaffa  push rdx
00007d2ed8ddaffb  push rdi
00007d2ed8ddaffc  push rsi
00007d2ed8ddaffd  push r8
00007d2ed8ddafff  push r9
00007d2ed8ddb001  push r10
00007d2ed8ddb003  push r11
00007d2ed8ddb005  sub rsp, 0xF0
00007d2ed8ddb00c  vmovaps [rsp], xmm0
00007d2ed8ddb011  vmovaps [rsp+0x10], xmm1
00007d2ed8ddb017  vmovaps [rsp+0x20], xmm2
00007d2ed8ddb01d  vmovaps [rsp+0x30], xmm3
00007d2ed8ddb023  vmovaps [rsp+0x40], xmm4
00007d2ed8ddb029  vmovaps [rsp+0x50], xmm5
00007d2ed8ddb02f  vmovaps [rsp+0x60], xmm6
00007d2ed8ddb035  vmovaps [rsp+0x70], xmm7
00007d2ed8ddb03b  vmovaps [rsp+0x80], xmm9
00007d2ed8ddb044  vmovaps [rsp+0x90], xmm10
00007d2ed8ddb04d  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddb056  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddb05f  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddb068  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddb071  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddb07a  sub rsp, 0x30
00007d2ed8ddb07e  movaps [rsp], xmm8
00007d2ed8ddb083  movaps [rsp+0x10], xmm15
00007d2ed8ddb089  movaps [rsp+0x20], xmm7
00007d2ed8ddb08e  lea rdi, [rsp]
00007d2ed8ddb092  mov esi, 0x00
00007d2ed8ddb097  mov rax, 0x648718324530
00007d2ed8ddb0a1  call rax
00007d2ed8ddb0a3  movaps xmm8, [rsp]
00007d2ed8ddb0a8  add rsp, 0x30
00007d2ed8ddb0ac  vmovaps xmm0, [rsp]
00007d2ed8ddb0b1  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddb0b7  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddb0bd  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddb0c3  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddb0c9  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddb0cf  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddb0d5  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddb0db  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddb0e4  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddb0ed  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddb0f6  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddb0ff  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddb108  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddb111  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddb11a  add rsp, 0xF0
00007d2ed8ddb121  pop r11
00007d2ed8ddb123  pop r10
00007d2ed8ddb125  pop r9
00007d2ed8ddb127  pop r8
00007d2ed8ddb129  pop rsi
00007d2ed8ddb12a  pop rdi
00007d2ed8ddb12b  pop rdx
00007d2ed8ddb12c  pop rcx
00007d2ed8ddb12d  pop rax
00007d2ed8ddb12e  add rsp, 0x08
00007d2ed8ddb132  jmp 0x00007D2ED8DD65D4
00007d2ed8ddb137  sub rsp, 0x08
00007d2ed8ddb13b  push rax
00007d2ed8ddb13c  push rcx
00007d2ed8ddb13d  push rdx
00007d2ed8ddb13e  push rdi
00007d2ed8ddb13f  push rsi
00007d2ed8ddb140  push r8
00007d2ed8ddb142  push r9
00007d2ed8ddb144  push r10
00007d2ed8ddb146  push r11
00007d2ed8ddb148  sub rsp, 0xF0
00007d2ed8ddb14f  vmovaps [rsp], xmm0
00007d2ed8ddb154  vmovaps [rsp+0x10], xmm1
00007d2ed8ddb15a  vmovaps [rsp+0x20], xmm2
00007d2ed8ddb160  vmovaps [rsp+0x30], xmm3
00007d2ed8ddb166  vmovaps [rsp+0x40], xmm4
00007d2ed8ddb16c  vmovaps [rsp+0x50], xmm5
00007d2ed8ddb172  vmovaps [rsp+0x60], xmm6
00007d2ed8ddb178  vmovaps [rsp+0x70], xmm8
00007d2ed8ddb17e  vmovaps [rsp+0x80], xmm9
00007d2ed8ddb187  vmovaps [rsp+0x90], xmm10
00007d2ed8ddb190  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddb199  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddb1a2  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddb1ab  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddb1b4  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddb1bd  sub rsp, 0x30
00007d2ed8ddb1c1  movaps [rsp], xmm7
00007d2ed8ddb1c5  movaps [rsp+0x10], xmm9
00007d2ed8ddb1cb  movaps [rsp+0x20], xmm15
00007d2ed8ddb1d1  lea rdi, [rsp]
00007d2ed8ddb1d5  mov esi, 0x00
00007d2ed8ddb1da  mov rax, 0x648718324530
00007d2ed8ddb1e4  call rax
00007d2ed8ddb1e6  movaps xmm7, [rsp]
00007d2ed8ddb1ea  add rsp, 0x30
00007d2ed8ddb1ee  vmovaps xmm0, [rsp]
00007d2ed8ddb1f3  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddb1f9  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddb1ff  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddb205  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddb20b  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddb211  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddb217  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddb21d  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddb226  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddb22f  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddb238  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddb241  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddb24a  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddb253  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddb25c  add rsp, 0xF0
00007d2ed8ddb263  pop r11
00007d2ed8ddb265  pop r10
00007d2ed8ddb267  pop r9
00007d2ed8ddb269  pop r8
00007d2ed8ddb26b  pop rsi
00007d2ed8ddb26c  pop rdi
00007d2ed8ddb26d  pop rdx
00007d2ed8ddb26e  pop rcx
00007d2ed8ddb26f  pop rax
00007d2ed8ddb270  add rsp, 0x08
00007d2ed8ddb274  jmp 0x00007D2ED8DD6601
00007d2ed8ddb279  sub rsp, 0x08
00007d2ed8ddb27d  push rax
00007d2ed8ddb27e  push rcx
00007d2ed8ddb27f  push rdx
00007d2ed8ddb280  push rdi
00007d2ed8ddb281  push rsi
00007d2ed8ddb282  push r8
00007d2ed8ddb284  push r9
00007d2ed8ddb286  push r10
00007d2ed8ddb288  push r11
00007d2ed8ddb28a  sub rsp, 0xF0
00007d2ed8ddb291  vmovaps [rsp], xmm0
00007d2ed8ddb296  vmovaps [rsp+0x10], xmm1
00007d2ed8ddb29c  vmovaps [rsp+0x20], xmm2
00007d2ed8ddb2a2  vmovaps [rsp+0x30], xmm3
00007d2ed8ddb2a8  vmovaps [rsp+0x40], xmm4
00007d2ed8ddb2ae  vmovaps [rsp+0x50], xmm5
00007d2ed8ddb2b4  vmovaps [rsp+0x60], xmm6
00007d2ed8ddb2ba  vmovaps [rsp+0x70], xmm7
00007d2ed8ddb2c0  vmovaps [rsp+0x80], xmm8
00007d2ed8ddb2c9  vmovaps [rsp+0x90], xmm10
00007d2ed8ddb2d2  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddb2db  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddb2e4  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddb2ed  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddb2f6  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddb2ff  sub rsp, 0x30
00007d2ed8ddb303  movaps [rsp], xmm9
00007d2ed8ddb308  movaps [rsp+0x10], xmm13
00007d2ed8ddb30e  movaps [rsp+0x20], xmm15
00007d2ed8ddb314  lea rdi, [rsp]
00007d2ed8ddb318  mov esi, 0x00
00007d2ed8ddb31d  mov rax, 0x648718324530
00007d2ed8ddb327  call rax
00007d2ed8ddb329  movaps xmm9, [rsp]
00007d2ed8ddb32e  add rsp, 0x30
00007d2ed8ddb332  vmovaps xmm0, [rsp]
00007d2ed8ddb337  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddb33d  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddb343  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddb349  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddb34f  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddb355  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddb35b  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddb361  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddb36a  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddb373  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddb37c  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddb385  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddb38e  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddb397  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddb3a0  add rsp, 0xF0
00007d2ed8ddb3a7  pop r11
00007d2ed8ddb3a9  pop r10
00007d2ed8ddb3ab  pop r9
00007d2ed8ddb3ad  pop r8
00007d2ed8ddb3af  pop rsi
00007d2ed8ddb3b0  pop rdi
00007d2ed8ddb3b1  pop rdx
00007d2ed8ddb3b2  pop rcx
00007d2ed8ddb3b3  pop rax
00007d2ed8ddb3b4  add rsp, 0x08
00007d2ed8ddb3b8  jmp 0x00007D2ED8DD662F
00007d2ed8ddb3bd  sub rsp, 0x08
00007d2ed8ddb3c1  push rax
00007d2ed8ddb3c2  push rcx
00007d2ed8ddb3c3  push rdx
00007d2ed8ddb3c4  push rdi
00007d2ed8ddb3c5  push rsi
00007d2ed8ddb3c6  push r8
00007d2ed8ddb3c8  push r9
00007d2ed8ddb3ca  push r10
00007d2ed8ddb3cc  push r11
00007d2ed8ddb3ce  sub rsp, 0xF0
00007d2ed8ddb3d5  vmovaps [rsp], xmm0
00007d2ed8ddb3da  vmovaps [rsp+0x10], xmm1
00007d2ed8ddb3e0  vmovaps [rsp+0x20], xmm2
00007d2ed8ddb3e6  vmovaps [rsp+0x30], xmm3
00007d2ed8ddb3ec  vmovaps [rsp+0x40], xmm4
00007d2ed8ddb3f2  vmovaps [rsp+0x50], xmm5
00007d2ed8ddb3f8  vmovaps [rsp+0x60], xmm6
00007d2ed8ddb3fe  vmovaps [rsp+0x70], xmm7
00007d2ed8ddb404  vmovaps [rsp+0x80], xmm8
00007d2ed8ddb40d  vmovaps [rsp+0x90], xmm9
00007d2ed8ddb416  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddb41f  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddb428  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddb431  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddb43a  vmovaps [rsp+0xE0], xmm14
00007d2ed8ddb443  sub rsp, 0x30
00007d2ed8ddb447  movaps [rsp], xmm15
00007d2ed8ddb44c  movaps [rsp+0x10], xmm11
00007d2ed8ddb452  movaps [rsp+0x20], xmm12
00007d2ed8ddb458  lea rdi, [rsp]
00007d2ed8ddb45c  mov esi, 0x00
00007d2ed8ddb461  mov rax, 0x648718324530
00007d2ed8ddb46b  call rax
00007d2ed8ddb46d  movaps xmm15, [rsp]
00007d2ed8ddb472  add rsp, 0x30
00007d2ed8ddb476  vmovaps xmm0, [rsp]
00007d2ed8ddb47b  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddb481  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddb487  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddb48d  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddb493  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddb499  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddb49f  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddb4a5  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddb4ae  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddb4b7  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddb4c0  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddb4c9  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddb4d2  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddb4db  vmovaps xmm14, [rsp+0xE0]
00007d2ed8ddb4e4  add rsp, 0xF0
00007d2ed8ddb4eb  pop r11
00007d2ed8ddb4ed  pop r10
00007d2ed8ddb4ef  pop r9
00007d2ed8ddb4f1  pop r8
00007d2ed8ddb4f3  pop rsi
00007d2ed8ddb4f4  pop rdi
00007d2ed8ddb4f5  pop rdx
00007d2ed8ddb4f6  pop rcx
00007d2ed8ddb4f7  pop rax
00007d2ed8ddb4f8  add rsp, 0x08
00007d2ed8ddb4fc  jmp 0x00007D2ED8DD664A
00007d2ed8ddb501  sub rsp, 0x08
00007d2ed8ddb505  push rax
00007d2ed8ddb506  push rcx
00007d2ed8ddb507  push rdx
00007d2ed8ddb508  push rdi
00007d2ed8ddb509  push rsi
00007d2ed8ddb50a  push r8
00007d2ed8ddb50c  push r9
00007d2ed8ddb50e  push r10
00007d2ed8ddb510  push r11
00007d2ed8ddb512  sub rsp, 0xF0
00007d2ed8ddb519  vmovaps [rsp], xmm0
00007d2ed8ddb51e  vmovaps [rsp+0x10], xmm1
00007d2ed8ddb524  vmovaps [rsp+0x20], xmm2
00007d2ed8ddb52a  vmovaps [rsp+0x30], xmm3
00007d2ed8ddb530  vmovaps [rsp+0x40], xmm4
00007d2ed8ddb536  vmovaps [rsp+0x50], xmm5
00007d2ed8ddb53c  vmovaps [rsp+0x60], xmm6
00007d2ed8ddb542  vmovaps [rsp+0x70], xmm7
00007d2ed8ddb548  vmovaps [rsp+0x80], xmm8
00007d2ed8ddb551  vmovaps [rsp+0x90], xmm9
00007d2ed8ddb55a  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddb563  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddb56c  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddb575  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddb57e  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddb587  sub rsp, 0x30
00007d2ed8ddb58b  movaps [rsp], xmm13
00007d2ed8ddb590  movaps [rsp+0x10], xmm10
00007d2ed8ddb596  movaps [rsp+0x20], xmm14
00007d2ed8ddb59c  lea rdi, [rsp]
00007d2ed8ddb5a0  mov esi, 0x00
00007d2ed8ddb5a5  mov rax, 0x648718324530
00007d2ed8ddb5af  call rax
00007d2ed8ddb5b1  movaps xmm13, [rsp]
00007d2ed8ddb5b6  add rsp, 0x30
00007d2ed8ddb5ba  vmovaps xmm0, [rsp]
00007d2ed8ddb5bf  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddb5c5  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddb5cb  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddb5d1  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddb5d7  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddb5dd  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddb5e3  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddb5e9  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddb5f2  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddb5fb  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddb604  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddb60d  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddb616  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddb61f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddb628  add rsp, 0xF0
00007d2ed8ddb62f  pop r11
00007d2ed8ddb631  pop r10
00007d2ed8ddb633  pop r9
00007d2ed8ddb635  pop r8
00007d2ed8ddb637  pop rsi
00007d2ed8ddb638  pop rdi
00007d2ed8ddb639  pop rdx
00007d2ed8ddb63a  pop rcx
00007d2ed8ddb63b  pop rax
00007d2ed8ddb63c  add rsp, 0x08
00007d2ed8ddb640  jmp 0x00007D2ED8DD666D
00007d2ed8ddb645  sub rsp, 0x08
00007d2ed8ddb649  push rax
00007d2ed8ddb64a  push rcx
00007d2ed8ddb64b  push rdx
00007d2ed8ddb64c  push rdi
00007d2ed8ddb64d  push rsi
00007d2ed8ddb64e  push r8
00007d2ed8ddb650  push r9
00007d2ed8ddb652  push r10
00007d2ed8ddb654  push r11
00007d2ed8ddb656  sub rsp, 0xF0
00007d2ed8ddb65d  vmovaps [rsp], xmm0
00007d2ed8ddb662  vmovaps [rsp+0x10], xmm1
00007d2ed8ddb668  vmovaps [rsp+0x20], xmm2
00007d2ed8ddb66e  vmovaps [rsp+0x30], xmm3
00007d2ed8ddb674  vmovaps [rsp+0x40], xmm4
00007d2ed8ddb67a  vmovaps [rsp+0x50], xmm5
00007d2ed8ddb680  vmovaps [rsp+0x60], xmm6
00007d2ed8ddb686  vmovaps [rsp+0x70], xmm7
00007d2ed8ddb68c  vmovaps [rsp+0x80], xmm8
00007d2ed8ddb695  vmovaps [rsp+0x90], xmm9
00007d2ed8ddb69e  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddb6a7  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddb6b0  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddb6b9  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddb6c2  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddb6cb  sub rsp, 0x30
00007d2ed8ddb6cf  movaps [rsp], xmm14
00007d2ed8ddb6d4  movaps [rsp+0x10], xmm1
00007d2ed8ddb6d9  movaps [rsp+0x20], xmm7
00007d2ed8ddb6de  lea rdi, [rsp]
00007d2ed8ddb6e2  mov esi, 0x00
00007d2ed8ddb6e7  mov rax, 0x648718324530
00007d2ed8ddb6f1  call rax
00007d2ed8ddb6f3  movaps xmm14, [rsp]
00007d2ed8ddb6f8  add rsp, 0x30
00007d2ed8ddb6fc  vmovaps xmm0, [rsp]
00007d2ed8ddb701  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddb707  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddb70d  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddb713  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddb719  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddb71f  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddb725  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddb72b  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddb734  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddb73d  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddb746  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddb74f  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddb758  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddb761  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddb76a  add rsp, 0xF0
00007d2ed8ddb771  pop r11
00007d2ed8ddb773  pop r10
00007d2ed8ddb775  pop r9
00007d2ed8ddb777  pop r8
00007d2ed8ddb779  pop rsi
00007d2ed8ddb77a  pop rdi
00007d2ed8ddb77b  pop rdx
00007d2ed8ddb77c  pop rcx
00007d2ed8ddb77d  pop rax
00007d2ed8ddb77e  add rsp, 0x08
00007d2ed8ddb782  jmp 0x00007D2ED8DD6690
00007d2ed8ddb787  sub rsp, 0x08
00007d2ed8ddb78b  push rax
00007d2ed8ddb78c  push rcx
00007d2ed8ddb78d  push rdx
00007d2ed8ddb78e  push rdi
00007d2ed8ddb78f  push rsi
00007d2ed8ddb790  push r8
00007d2ed8ddb792  push r9
00007d2ed8ddb794  push r10
00007d2ed8ddb796  push r11
00007d2ed8ddb798  sub rsp, 0xF0
00007d2ed8ddb79f  vmovaps [rsp], xmm0
00007d2ed8ddb7a4  vmovaps [rsp+0x10], xmm2
00007d2ed8ddb7aa  vmovaps [rsp+0x20], xmm3
00007d2ed8ddb7b0  vmovaps [rsp+0x30], xmm4
00007d2ed8ddb7b6  vmovaps [rsp+0x40], xmm5
00007d2ed8ddb7bc  vmovaps [rsp+0x50], xmm6
00007d2ed8ddb7c2  vmovaps [rsp+0x60], xmm7
00007d2ed8ddb7c8  vmovaps [rsp+0x70], xmm8
00007d2ed8ddb7ce  vmovaps [rsp+0x80], xmm9
00007d2ed8ddb7d7  vmovaps [rsp+0x90], xmm10
00007d2ed8ddb7e0  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddb7e9  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddb7f2  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddb7fb  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddb804  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddb80d  sub rsp, 0x30
00007d2ed8ddb811  movaps [rsp], xmm1
00007d2ed8ddb815  movaps [rsp+0x10], xmm8
00007d2ed8ddb81b  movaps [rsp+0x20], xmm9
00007d2ed8ddb821  lea rdi, [rsp]
00007d2ed8ddb825  mov esi, 0x00
00007d2ed8ddb82a  mov rax, 0x648718324530
00007d2ed8ddb834  call rax
00007d2ed8ddb836  movaps xmm1, [rsp]
00007d2ed8ddb83a  add rsp, 0x30
00007d2ed8ddb83e  vmovaps xmm0, [rsp]
00007d2ed8ddb843  vmovaps xmm2, [rsp+0x10]
00007d2ed8ddb849  vmovaps xmm3, [rsp+0x20]
00007d2ed8ddb84f  vmovaps xmm4, [rsp+0x30]
00007d2ed8ddb855  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddb85b  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddb861  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddb867  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddb86d  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddb876  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddb87f  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddb888  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddb891  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddb89a  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddb8a3  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddb8ac  add rsp, 0xF0
00007d2ed8ddb8b3  pop r11
00007d2ed8ddb8b5  pop r10
00007d2ed8ddb8b7  pop r9
00007d2ed8ddb8b9  pop r8
00007d2ed8ddb8bb  pop rsi
00007d2ed8ddb8bc  pop rdi
00007d2ed8ddb8bd  pop rdx
00007d2ed8ddb8be  pop rcx
00007d2ed8ddb8bf  pop rax
00007d2ed8ddb8c0  add rsp, 0x08
00007d2ed8ddb8c4  jmp 0x00007D2ED8DD66B2
00007d2ed8ddb8c9  call 0x00007D2ED8CB3E40
00007d2ed8ddb8ce  jmp 0x00007D2ED8DD66C0
00007d2ed8ddb8d3  call 0x00007D2ED8C0C380
00007d2ed8ddb8d8  jmp 0x00007D2ED8DD66CA
00007d2ed8ddb8dd  call 0x00007D2ED8C0D600
00007d2ed8ddb8e2  jmp 0x00007D2ED8DD66D4
00007d2ed8ddb8e7  call 0x00007D2ED8BFF540
00007d2ed8ddb8ec  jmp 0x00007D2ED8DD66DE
00007d2ed8ddb8f1  int3
00007d2ed8ddb8f2  nop [rax+rax*1], ax
00007d2ed8ddb8fb  nop [rax+rax*1], eax
00007d2ed8ddb900  mov eax, [r15+0x48]
00007d2ed8ddb904  lea r14d, [eax+0x01]
00007d2ed8ddb909  mov [rsp+0x10], r14d
00007d2ed8ddb90e  mov r14d, r14d
00007d2ed8ddb911  mov [r15+0x48], r14
00007d2ed8ddb915  xor eax, eax
00007d2ed8ddb917  mov r14d, [rsp+0x10]
00007d2ed8ddb91c  cmp r14d, 0x1F4
00007d2ed8ddb923  cmc
00007d2ed8ddb924  lahf
00007d2ed8ddb925  seto al
00007d2ed8ddb928  mov [r15+0x108], eax
00007d2ed8ddb92f  mov eax, [r15+0x108]
00007d2ed8ddb936  sahf
00007d2ed8ddb937  jnz 0x00007D2ED8DDB969
00007d2ed8ddb939  cmp dword ptr [r15+0x318], 0x00
00007d2ed8ddb941  jz 0x00007D2ED8DE1AB0
00007d2ed8ddb947  nop [rax+rax*1], ax
00007d2ed8ddb950  nop [rax+rax*1], eax
00007d2ed8ddb958  mov eax, 0x410450
00007d2ed8ddb95d  mov [r15+0x100], rax
00007d2ed8ddb964  jmp 0x00007D2ED8BFE110
00007d2ed8ddb969  cmp dword ptr [r15+0x318], 0x00
00007d2ed8ddb971  jz 0x00007D2ED8DDB9A0
00007d2ed8ddb977  nop [rax+rax*1], ax
00007d2ed8ddb980  nop [rax+rax*1], eax
00007d2ed8ddb988  mov eax, 0x410274
00007d2ed8ddb98d  mov [r15+0x100], rax
00007d2ed8ddb994  jmp 0x00007D2ED8BFE110
00007d2ed8ddb999  int3
00007d2ed8ddb99a  int3
00007d2ed8ddb99b  nop [rax+rax*1], eax
00007d2ed8ddb9a0  mov rax, [r15+0x40]
00007d2ed8ddb9a4  movaps xmm1, [r15+0x1D0]
00007d2ed8ddb9ac  vmovaps [rsp+0x10], xmm1
00007d2ed8ddb9b2  vmovaps xmm15, [rsp+0x10]
00007d2ed8ddb9b8  por xmm1, xmm15
00007d2ed8ddb9bd  movaps xmm14, [r15+0x1A0]
00007d2ed8ddb9c5  vmovaps [rsp+0x10], xmm14
00007d2ed8ddb9cb  vmovaps xmm13, [rsp+0x10]
00007d2ed8ddb9d1  por xmm14, xmm13
00007d2ed8ddb9d6  lea r14, [rax+0x30]
00007d2ed8ddb9da  mov r12, [r13+r14*1]
00007d2ed8ddb9df  lea r14, [rax+0x38]
00007d2ed8ddb9e3  mov r11, [r13+r14*1]
00007d2ed8ddb9e8  movq xmm13, r12
00007d2ed8ddb9ed  movq xmm12, r11
00007d2ed8ddb9f2  movq xmm13, xmm13
00007d2ed8ddb9f7  vmovaps [rsp+0x10], xmm13
00007d2ed8ddb9fd  movq xmm13, xmm13
00007d2ed8ddba02  movaps [r15+0x130], xmm13
00007d2ed8ddba0a  movq xmm12, xmm12
00007d2ed8ddba0f  vmovaps [rsp+0x20], xmm12
00007d2ed8ddba15  movq xmm12, xmm12
00007d2ed8ddba1a  movaps [r15+0x280], xmm12
00007d2ed8ddba22  movaps xmm13, [r15+0x270]
00007d2ed8ddba2a  vmovaps [rsp+0x30], xmm13
00007d2ed8ddba30  vmovaps xmm12, [rsp+0x30]
00007d2ed8ddba36  por xmm13, xmm12
00007d2ed8ddba3b  lea r14, [rax+0x20]
00007d2ed8ddba3f  mov r12, [r13+r14*1]
00007d2ed8ddba44  lea r14, [rax+0x28]
00007d2ed8ddba48  mov r11, [r13+r14*1]
00007d2ed8ddba4d  movq xmm12, r12
00007d2ed8ddba52  movq xmm11, r11
00007d2ed8ddba57  movq xmm12, xmm12
00007d2ed8ddba5c  vmovaps [rsp+0x30], xmm12
00007d2ed8ddba62  movq xmm12, xmm12
00007d2ed8ddba67  movaps [r15+0x150], xmm12
00007d2ed8ddba6f  movq xmm11, xmm11
00007d2ed8ddba74  vmovaps [rsp+0x40], xmm11
00007d2ed8ddba7a  movq xmm11, xmm11
00007d2ed8ddba7f  movaps [r15+0x140], xmm11
00007d2ed8ddba87  lea r14, [rax+0x10]
00007d2ed8ddba8b  mov r12, [r13+r14*1]
00007d2ed8ddba90  lea r14, [rax+0x18]
00007d2ed8ddba94  mov r11, [r13+r14*1]
00007d2ed8ddba99  movq xmm12, r12
00007d2ed8ddba9e  movq xmm11, r11
00007d2ed8ddbaa3  movq xmm12, xmm12
00007d2ed8ddbaa8  vmovaps [rsp+0x50], xmm12
00007d2ed8ddbaae  movq xmm12, xmm12
00007d2ed8ddbab3  movaps [r15+0x170], xmm12
00007d2ed8ddbabb  movq xmm11, xmm11
00007d2ed8ddbac0  vmovaps [rsp+0x60], xmm11
00007d2ed8ddbac6  movq xmm11, xmm11
00007d2ed8ddbacb  movaps [r15+0x160], xmm11
00007d2ed8ddbad3  mov r14, [r13+rax*1]
00007d2ed8ddbad8  vmovq xmm12, r14
00007d2ed8ddbadd  vpbroadcastq xmm12, xmm12
00007d2ed8ddbae2  lea r14, [rax+0x08]
00007d2ed8ddbae6  mov rax, [r13+r14*1]
00007d2ed8ddbaeb  movq xmm11, rax
00007d2ed8ddbaf0  movaps [r15+0x230], xmm11
00007d2ed8ddbaf8  mov rax, [r15+0xF8]
00007d2ed8ddbaff  lea r14, [rax+0x50]
00007d2ed8ddbb03  movups xmm11, [r13+r14*1]
00007d2ed8ddbb09  lea r14, [rax+0x60]
00007d2ed8ddbb0d  movups xmm10, [r13+r14*1]
00007d2ed8ddbb13  lea r14, [rax+0x30]
00007d2ed8ddbb17  movups xmm9, [r13+r14*1]
00007d2ed8ddbb1d  mov r14, [r15+0x50]
00007d2ed8ddbb21  mov [r15+0x60], r14
00007d2ed8ddbb25  mov qword ptr [r15+0x58], 0x40
00007d2ed8ddbb2d  movaps xmm8, xmm12
00007d2ed8ddbb31  mulpd xmm8, xmm15
00007d2ed8ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007d2ed8ddbb3c  ptest xmm7, xmm7
00007d2ed8ddbb41  jnz 0x00007D2ED8DDC96A
00007d2ed8ddbb47  movq xmm15, qword ptr [r15+0x230]
00007d2ed8ddbb50  vmovaps [rsp+0x70], xmm15
00007d2ed8ddbb56  vpermilpd xmm15, xmm15, 0x00
00007d2ed8ddbb5c  movaps xmm7, xmm9
00007d2ed8ddbb60  mulpd xmm7, xmm15
00007d2ed8ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007d2ed8ddbb6a  ptest xmm6, xmm6
00007d2ed8ddbb6f  jnz 0x00007D2ED8DDCAAE
00007d2ed8ddbb75  vxorps xmm15, xmm15, xmm15
00007d2ed8ddbb7a  vpbroadcastq xmm15, xmm15
00007d2ed8ddbb7f  movaps xmm9, xmm12
00007d2ed8ddbb83  mulpd xmm9, xmm10
00007d2ed8ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007d2ed8ddbb8e  ptest xmm6, xmm6
00007d2ed8ddbb93  jnz 0x00007D2ED8DDCBF0
00007d2ed8ddbb99  movaps xmm10, xmm12
00007d2ed8ddbb9d  mulpd xmm10, xmm11
00007d2ed8ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007d2ed8ddbba8  ptest xmm6, xmm6
00007d2ed8ddbbad  jnz 0x00007D2ED8DDCD34
00007d2ed8ddbbb3  movaps xmm11, [r15+0x1F0]
00007d2ed8ddbbbb  movaps xmm6, xmm12
00007d2ed8ddbbbf  mulpd xmm6, xmm11
00007d2ed8ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d2ed8ddbbc9  ptest xmm5, xmm5
00007d2ed8ddbbce  jnz 0x00007D2ED8DDCE78
00007d2ed8ddbbd4  movaps xmm12, [r15+0x2A0]
00007d2ed8ddbbdc  vmovaps [rsp+0x80], xmm12
00007d2ed8ddbbe5  vmovaps xmm11, [rsp+0x80]
00007d2ed8ddbbee  por xmm12, xmm11
00007d2ed8ddbbf3  movaps xmm11, [r15+0x250]
00007d2ed8ddbbfb  vmovaps [rsp+0x80], xmm11
00007d2ed8ddbc04  vmovaps xmm5, [rsp+0x80]
00007d2ed8ddbc0d  por xmm11, xmm5
00007d2ed8ddbc12  vmovaps xmm4, [rsp+0x70]
00007d2ed8ddbc18  vpermilpd xmm4, xmm4, 0x00
00007d2ed8ddbc1e  movaps xmm3, xmm5
00007d2ed8ddbc21  mulpd xmm3, xmm4
00007d2ed8ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007d2ed8ddbc2a  ptest xmm2, xmm2
00007d2ed8ddbc2f  jnz 0x00007D2ED8DDCFBA
00007d2ed8ddbc35  mov [rsp+0x80], rax
00007d2ed8ddbc3d  xor eax, eax
00007d2ed8ddbc3f  mov r12d, 0x40
00007d2ed8ddbc45  mov r11d, 0x200
00007d2ed8ddbc4b  cmp r12, r11
00007d2ed8ddbc4e  cmc
00007d2ed8ddbc4f  lahf
00007d2ed8ddbc50  seto al
00007d2ed8ddbc53  mov [r15+0x108], eax
00007d2ed8ddbc5a  movaps xmm5, xmm8
00007d2ed8ddbc5e  addpd xmm5, xmm15
00007d2ed8ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007d2ed8ddbc68  ptest xmm4, xmm4
00007d2ed8ddbc6d  jnz 0x00007D2ED8DDD0FA
00007d2ed8ddbc73  movaps xmm8, [r15+0x1B0]
00007d2ed8ddbc7b  movaps xmm4, xmm9
00007d2ed8ddbc7f  addpd xmm4, xmm8
00007d2ed8ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007d2ed8ddbc89  ptest xmm2, xmm2
00007d2ed8ddbc8e  jnz 0x00007D2ED8DDD23C
00007d2ed8ddbc94  movaps xmm9, xmm10
00007d2ed8ddbc98  addpd xmm9, xmm8
00007d2ed8ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d2ed8ddbca3  ptest xmm2, xmm2
00007d2ed8ddbca8  jnz 0x00007D2ED8DDD37E
00007d2ed8ddbcae  movaps xmm10, [r15+0x2F0]
00007d2ed8ddbcb6  vmovaps [rsp+0x90], xmm10
00007d2ed8ddbcbf  vmovaps xmm8, [rsp+0x90]
00007d2ed8ddbcc8  por xmm10, xmm8
00007d2ed8ddbccd  movaps xmm8, [r15+0x2E0]
00007d2ed8ddbcd5  vmovaps [rsp+0x90], xmm8
00007d2ed8ddbcde  vmovaps xmm2, [rsp+0x90]
00007d2ed8ddbce7  por xmm8, xmm2
00007d2ed8ddbcec  movaps xmm2, [r15+0x2D0]
00007d2ed8ddbcf4  vmovaps [rsp+0x90], xmm2
00007d2ed8ddbcfd  vmovaps [rsp+0xA0], xmm1
00007d2ed8ddbd06  vmovaps xmm1, [rsp+0x90]
00007d2ed8ddbd0f  por xmm2, xmm1
00007d2ed8ddbd13  movaps xmm1, [r15+0x200]
00007d2ed8ddbd1b  vmovaps [rsp+0x90], xmm1
00007d2ed8ddbd24  vmovaps [rsp+0xB0], xmm15
00007d2ed8ddbd2d  vmovaps xmm15, [rsp+0x90]
00007d2ed8ddbd36  por xmm1, xmm15
00007d2ed8ddbd3b  movaps xmm15, [r15+0x1C0]
00007d2ed8ddbd43  vmovaps [rsp+0x90], xmm15
00007d2ed8ddbd4c  vmovaps [rsp+0xC0], xmm1
00007d2ed8ddbd55  vmovaps xmm1, [rsp+0x90]
00007d2ed8ddbd5e  por xmm15, xmm1
00007d2ed8ddbd63  movaps xmm1, [r15+0x190]
00007d2ed8ddbd6b  vmovaps [rsp+0x90], xmm1
00007d2ed8ddbd74  vmovaps [rsp+0xD0], xmm15
00007d2ed8ddbd7d  vmovaps xmm15, [rsp+0x90]
00007d2ed8ddbd86  por xmm1, xmm15
00007d2ed8ddbd8b  movaps xmm15, [r15+0x300]
00007d2ed8ddbd93  vmovaps [rsp+0x90], xmm15
00007d2ed8ddbd9c  vmovaps [rsp+0xE0], xmm1
00007d2ed8ddbda5  vmovaps xmm1, [rsp+0x90]
00007d2ed8ddbdae  por xmm15, xmm1
00007d2ed8ddbdb3  mov rax, [rsp+0x80]
00007d2ed8ddbdbb  lea r12, [rax+0xA0]
00007d2ed8ddbdc2  movups xmm1, [r13+r12*1]
00007d2ed8ddbdc8  lea r12, [rax+0xB0]
00007d2ed8ddbdcf  vmovaps [rsp+0x80], xmm1
00007d2ed8ddbdd8  movups xmm1, [r13+r12*1]
00007d2ed8ddbdde  vmovaps [rsp+0x90], xmm1
00007d2ed8ddbde7  vmovaps [rsp+0xF0], xmm15
00007d2ed8ddbdf0  vmovaps xmm15, [rsp+0xB0]
00007d2ed8ddbdf9  vmovaps [rsp+0xB0], xmm14
00007d2ed8ddbe02  movaps xmm1, xmm6
00007d2ed8ddbe05  addpd xmm1, xmm15
00007d2ed8ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d2ed8ddbe0f  ptest xmm14, xmm14
00007d2ed8ddbe15  jnz 0x00007D2ED8DDD4D6
00007d2ed8ddbe1b  lea r12, [rax+0xF0]
00007d2ed8ddbe22  movups xmm15, [r13+r12*1]
00007d2ed8ddbe28  movaps xmm14, xmm4
00007d2ed8ddbe2c  addpd xmm14, xmm3
00007d2ed8ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007d2ed8ddbe37  ptest xmm6, xmm6
00007d2ed8ddbe3c  jnz 0x00007D2ED8DDD621
00007d2ed8ddbe42  movaps xmm6, xmm9
00007d2ed8ddbe46  addpd xmm6, xmm7
00007d2ed8ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d2ed8ddbe4f  ptest xmm4, xmm4
00007d2ed8ddbe54  jnz 0x00007D2ED8DDD763
00007d2ed8ddbe5a  vmovaps xmm9, [rsp+0x70]
00007d2ed8ddbe60  vpermilpd xmm9, xmm9, 0x00
00007d2ed8ddbe66  vmovaps xmm4, [rsp+0x90]
00007d2ed8ddbe6f  movaps xmm7, xmm4
00007d2ed8ddbe72  mulpd xmm7, xmm9
00007d2ed8ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007d2ed8ddbe7c  ptest xmm3, xmm3
00007d2ed8ddbe81  jnz 0x00007D2ED8DDD8A4
00007d2ed8ddbe87  vmovaps xmm9, [rsp+0x50]
00007d2ed8ddbe8d  vpermilpd xmm9, xmm9, 0x00
00007d2ed8ddbe93  movaps xmm4, xmm15
00007d2ed8ddbe97  mulpd xmm4, xmm9
00007d2ed8ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d2ed8ddbea1  ptest xmm3, xmm3
00007d2ed8ddbea6  jnz 0x00007D2ED8DDD9E5
00007d2ed8ddbeac  lea r12, [rax+0xE0]
00007d2ed8ddbeb3  movups xmm15, [r13+r12*1]
00007d2ed8ddbeb9  vmovaps xmm9, [rsp+0x70]
00007d2ed8ddbebf  vpermilpd xmm9, xmm9, 0x00
00007d2ed8ddbec5  vmovaps [rsp+0x70], xmm1
00007d2ed8ddbecb  vmovaps xmm1, [rsp+0x80]
00007d2ed8ddbed4  vmovaps [rsp+0x80], xmm15
00007d2ed8ddbedd  movaps xmm3, xmm1
00007d2ed8ddbee0  mulpd xmm3, xmm9
00007d2ed8ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d2ed8ddbeea  ptest xmm15, xmm15
00007d2ed8ddbef0  jnz 0x00007D2ED8DDDB31
00007d2ed8ddbef6  vmovaps xmm1, [rsp+0xF0]
00007d2ed8ddbeff  vmovaps xmm15, [rsp+0xF0]
00007d2ed8ddbf08  por xmm1, xmm15
00007d2ed8ddbf0d  movaps [r15+0x300], xmm1
00007d2ed8ddbf15  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddbf1e  vmovaps xmm9, [rsp+0xE0]
00007d2ed8ddbf27  por xmm15, xmm9
00007d2ed8ddbf2c  movaps [r15+0x190], xmm15
00007d2ed8ddbf34  vmovaps xmm9, [rsp+0x50]
00007d2ed8ddbf3a  vpermilpd xmm9, xmm9, 0x00
00007d2ed8ddbf40  vmovaps [rsp+0x90], xmm1
00007d2ed8ddbf49  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddbf52  vmovaps xmm15, [rsp+0x80]
00007d2ed8ddbf5b  vmovaps [rsp+0x80], xmm14
00007d2ed8ddbf64  movaps xmm1, xmm15
00007d2ed8ddbf68  mulpd xmm1, xmm9
00007d2ed8ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d2ed8ddbf72  ptest xmm14, xmm14
00007d2ed8ddbf78  jnz 0x00007D2ED8DDDC72
00007d2ed8ddbf7e  lea r12, [rax+0x90]
00007d2ed8ddbf85  movups xmm15, [r13+r12*1]
00007d2ed8ddbf8b  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddbf94  vmovaps xmm9, [rsp+0xD0]
00007d2ed8ddbf9d  por xmm14, xmm9
00007d2ed8ddbfa2  movaps [r15+0x1C0], xmm14
00007d2ed8ddbfaa  vmovaps xmm9, [rsp+0xC0]
00007d2ed8ddbfb3  vmovaps [rsp+0xD0], xmm1
00007d2ed8ddbfbc  vmovaps xmm1, [rsp+0xC0]
00007d2ed8ddbfc5  por xmm9, xmm1
00007d2ed8ddbfca  movaps [r15+0x200], xmm9
00007d2ed8ddbfd2  vmovaps [rsp+0xC0], xmm2
00007d2ed8ddbfdb  vmovaps xmm1, [rsp+0xC0]
00007d2ed8ddbfe4  por xmm2, xmm1
00007d2ed8ddbfe8  movaps [r15+0x2D0], xmm2
00007d2ed8ddbff0  vmovaps [rsp+0xC0], xmm8
00007d2ed8ddbff9  vmovaps xmm1, [rsp+0xC0]
00007d2ed8ddc002  por xmm8, xmm1
00007d2ed8ddc007  movaps [r15+0x2E0], xmm8
00007d2ed8ddc00f  vmovaps [rsp+0xC0], xmm15
00007d2ed8ddc018  movaps xmm1, xmm5
00007d2ed8ddc01b  addpd xmm1, xmm7
00007d2ed8ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007d2ed8ddc024  ptest xmm15, xmm15
00007d2ed8ddc02a  jnz 0x00007D2ED8DDDDBE
00007d2ed8ddc030  vmovaps xmm15, [rsp+0x50]
00007d2ed8ddc036  vpermilpd xmm15, xmm15, 0x00
00007d2ed8ddc03c  vmovaps xmm5, [rsp+0xC0]
00007d2ed8ddc045  vmovaps [rsp+0xC0], xmm1
00007d2ed8ddc04e  movaps xmm7, xmm5
00007d2ed8ddc051  mulpd xmm7, xmm15
00007d2ed8ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007d2ed8ddc05b  ptest xmm1, xmm1
00007d2ed8ddc060  jnz 0x00007D2ED8DDDEFE
00007d2ed8ddc066  lea r12, [rax+0x80]
00007d2ed8ddc06d  movups xmm1, [r13+r12*1]
00007d2ed8ddc073  vmovaps xmm5, [rsp+0x70]
00007d2ed8ddc079  vmovaps [rsp+0x70], xmm1
00007d2ed8ddc07f  movaps xmm15, xmm5
00007d2ed8ddc083  addpd xmm15, xmm3
00007d2ed8ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007d2ed8ddc08e  ptest xmm1, xmm1
00007d2ed8ddc093  jnz 0x00007D2ED8DDE049
00007d2ed8ddc099  vmovaps xmm5, [rsp+0x80]
00007d2ed8ddc0a2  movaps xmm1, xmm5
00007d2ed8ddc0a5  addpd xmm1, xmm4
00007d2ed8ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007d2ed8ddc0ae  ptest xmm3, xmm3
00007d2ed8ddc0b3  jnz 0x00007D2ED8DDE18B
00007d2ed8ddc0b9  vmovaps [rsp+0x80], xmm10
00007d2ed8ddc0c2  vmovaps xmm5, [rsp+0x80]
00007d2ed8ddc0cb  por xmm10, xmm5
00007d2ed8ddc0d0  movaps [r15+0x2F0], xmm10
00007d2ed8ddc0d8  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddc0de  vpermilpd xmm5, xmm5, 0x00
00007d2ed8ddc0e4  vmovaps xmm3, [rsp+0x70]
00007d2ed8ddc0ea  vmovaps [rsp+0x50], xmm1
00007d2ed8ddc0f0  movaps xmm4, xmm3
00007d2ed8ddc0f3  mulpd xmm4, xmm5
00007d2ed8ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d2ed8ddc0fc  ptest xmm1, xmm1
00007d2ed8ddc101  jnz 0x00007D2ED8DDE2CB
00007d2ed8ddc107  lea r12, [rax+0xD0]
00007d2ed8ddc10e  movups xmm1, [r13+r12*1]
00007d2ed8ddc114  vmovaps xmm3, [rsp+0xD0]
00007d2ed8ddc11d  vmovaps [rsp+0x70], xmm1
00007d2ed8ddc123  movaps xmm5, xmm6
00007d2ed8ddc126  addpd xmm5, xmm3
00007d2ed8ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d2ed8ddc12f  ptest xmm1, xmm1
00007d2ed8ddc134  jnz 0x00007D2ED8DDE415
00007d2ed8ddc13a  vmovaps xmm1, [rsp+0x60]
00007d2ed8ddc140  vpermilpd xmm1, xmm1, 0x00
00007d2ed8ddc146  movaps xmm6, xmm9
00007d2ed8ddc14a  mulpd xmm6, xmm1
00007d2ed8ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d2ed8ddc153  ptest xmm3, xmm3
00007d2ed8ddc158  jnz 0x00007D2ED8DDE555
00007d2ed8ddc15e  movaps [r15+0x260], xmm6
00007d2ed8ddc166  vxorps xmm1, xmm1, xmm1
00007d2ed8ddc16a  vpbroadcastq xmm1, xmm1
00007d2ed8ddc16f  movaps [r15+0x1B0], xmm1
00007d2ed8ddc177  vmovaps xmm1, [rsp+0x60]
00007d2ed8ddc17d  vpermilpd xmm1, xmm1, 0x00
00007d2ed8ddc183  vmovaps xmm3, [rsp+0x70]
00007d2ed8ddc189  vmovaps [rsp+0x70], xmm15
00007d2ed8ddc18f  movaps xmm9, xmm3
00007d2ed8ddc193  mulpd xmm9, xmm1
00007d2ed8ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007d2ed8ddc19e  ptest xmm15, xmm15
00007d2ed8ddc1a4  jnz 0x00007D2ED8DDE696
00007d2ed8ddc1aa  lea r12, [rax+0xC0]
00007d2ed8ddc1b1  movups xmm1, [r13+r12*1]
00007d2ed8ddc1b7  vmovaps xmm3, [rsp+0xC0]
00007d2ed8ddc1c0  vmovaps [rsp+0x80], xmm1
00007d2ed8ddc1c9  movaps xmm15, xmm3
00007d2ed8ddc1cd  addpd xmm15, xmm7
00007d2ed8ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d2ed8ddc1d8  ptest xmm1, xmm1
00007d2ed8ddc1dd  jnz 0x00007D2ED8DDE7E2
00007d2ed8ddc1e3  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddc1ec  vmovaps xmm1, [rsp+0xC0]
00007d2ed8ddc1f5  por xmm13, xmm1
00007d2ed8ddc1fa  movaps [r15+0x270], xmm13
00007d2ed8ddc202  vmovaps xmm1, [rsp+0xB0]
00007d2ed8ddc20b  vmovaps xmm7, [rsp+0xB0]
00007d2ed8ddc214  por xmm1, xmm7
00007d2ed8ddc218  movaps [r15+0x1A0], xmm1
00007d2ed8ddc220  vmovaps xmm1, [rsp+0x60]
00007d2ed8ddc226  vpermilpd xmm1, xmm1, 0x00
00007d2ed8ddc22c  vmovaps [rsp+0xB0], xmm1
00007d2ed8ddc235  vmovaps xmm1, [rsp+0x80]
00007d2ed8ddc23e  vmovaps [rsp+0x80], xmm15
00007d2ed8ddc247  vmovaps xmm15, [rsp+0xB0]
00007d2ed8ddc250  vmovaps [rsp+0xB0], xmm14
00007d2ed8ddc259  movaps xmm3, xmm1
00007d2ed8ddc25c  mulpd xmm3, xmm15
00007d2ed8ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007d2ed8ddc266  ptest xmm14, xmm14
00007d2ed8ddc26c  jnz 0x00007D2ED8DDE924
00007d2ed8ddc272  lea r12, [rax+0x20]
00007d2ed8ddc276  movups xmm1, [r13+r12*1]
00007d2ed8ddc27c  movaps [r15+0x110], xmm1
00007d2ed8ddc284  vmovaps xmm14, [rsp+0x70]
00007d2ed8ddc28a  vmovaps [rsp+0x70], xmm1
00007d2ed8ddc290  movaps xmm15, xmm14
00007d2ed8ddc294  addpd xmm15, xmm4
00007d2ed8ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007d2ed8ddc29f  ptest xmm1, xmm1
00007d2ed8ddc2a4  jnz 0x00007D2ED8DDEA6F
00007d2ed8ddc2aa  vmovaps xmm1, [rsp+0x60]
00007d2ed8ddc2b0  vpermilpd xmm1, xmm1, 0x00
00007d2ed8ddc2b6  movaps xmm14, xmm2
00007d2ed8ddc2ba  mulpd xmm14, xmm1
00007d2ed8ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007d2ed8ddc2c5  ptest xmm4, xmm4
00007d2ed8ddc2ca  jnz 0x00007D2ED8DDEBB2
00007d2ed8ddc2d0  vmovaps xmm4, [rsp+0x50]
00007d2ed8ddc2d6  movaps xmm1, xmm4
00007d2ed8ddc2d9  addpd xmm1, xmm9
00007d2ed8ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007d2ed8ddc2e3  ptest xmm2, xmm2
00007d2ed8ddc2e8  jnz 0x00007D2ED8DDECF4
00007d2ed8ddc2ee  vmovaps xmm9, [rsp+0x30]
00007d2ed8ddc2f4  vpermilpd xmm9, xmm9, 0x00
00007d2ed8ddc2fa  vmovaps xmm2, [rsp+0x70]
00007d2ed8ddc300  vmovaps [rsp+0x50], xmm1
00007d2ed8ddc306  movaps xmm4, xmm2
00007d2ed8ddc309  mulpd xmm4, xmm9
00007d2ed8ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007d2ed8ddc313  ptest xmm1, xmm1
00007d2ed8ddc318  jnz 0x00007D2ED8DDEE35
00007d2ed8ddc31e  vmovaps xmm1, [rsp+0x30]
00007d2ed8ddc324  vpermilpd xmm1, xmm1, 0x00
00007d2ed8ddc32a  vmovaps xmm2, [rsp+0x90]
00007d2ed8ddc333  vmovaps [rsp+0x60], xmm15
00007d2ed8ddc339  movaps xmm9, xmm2
00007d2ed8ddc33d  mulpd xmm9, xmm1
00007d2ed8ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007d2ed8ddc348  ptest xmm15, xmm15
00007d2ed8ddc34e  jnz 0x00007D2ED8DDEF76
00007d2ed8ddc354  vmovaps xmm15, [rsp+0x80]
00007d2ed8ddc35d  movaps xmm1, xmm15
00007d2ed8ddc361  addpd xmm1, xmm6
00007d2ed8ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007d2ed8ddc36a  ptest xmm2, xmm2
00007d2ed8ddc36f  jnz 0x00007D2ED8DDF0B8
00007d2ed8ddc375  movaps xmm15, xmm5
00007d2ed8ddc379  addpd xmm15, xmm3
00007d2ed8ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d2ed8ddc384  ptest xmm6, xmm6
00007d2ed8ddc389  jnz 0x00007D2ED8DDF1F9
00007d2ed8ddc38f  vmovaps xmm6, [rsp+0x30]
00007d2ed8ddc395  vpermilpd xmm6, xmm6, 0x00
00007d2ed8ddc39b  movaps xmm5, xmm8
00007d2ed8ddc39f  mulpd xmm5, xmm6
00007d2ed8ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007d2ed8ddc3a8  ptest xmm3, xmm3
00007d2ed8ddc3ad  jnz 0x00007D2ED8DDF33B
00007d2ed8ddc3b3  vmovaps xmm8, [rsp+0x30]
00007d2ed8ddc3b9  vpermilpd xmm8, xmm8, 0x00
00007d2ed8ddc3bf  movaps xmm6, xmm10
00007d2ed8ddc3c3  mulpd xmm6, xmm8
00007d2ed8ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d2ed8ddc3cd  ptest xmm3, xmm3
00007d2ed8ddc3d2  jnz 0x00007D2ED8DDF47C
00007d2ed8ddc3d8  vmovaps xmm8, [rsp+0x60]
00007d2ed8ddc3de  movaps xmm10, xmm8
00007d2ed8ddc3e2  addpd xmm10, xmm14
00007d2ed8ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d2ed8ddc3ed  ptest xmm3, xmm3
00007d2ed8ddc3f2  jnz 0x00007D2ED8DDF5BE
00007d2ed8ddc3f8  vmovaps xmm8, [rsp+0x50]
00007d2ed8ddc3fe  movaps xmm14, xmm8
00007d2ed8ddc402  addpd xmm14, xmm4
00007d2ed8ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007d2ed8ddc40d  ptest xmm3, xmm3
00007d2ed8ddc412  jnz 0x00007D2ED8DDF702
00007d2ed8ddc418  vmovaps xmm8, [rsp+0x40]
00007d2ed8ddc41e  vpermilpd xmm8, xmm8, 0x00
00007d2ed8ddc424  movaps xmm4, xmm13
00007d2ed8ddc428  mulpd xmm4, xmm8
00007d2ed8ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d2ed8ddc432  ptest xmm3, xmm3
00007d2ed8ddc437  jnz 0x00007D2ED8DDF845
00007d2ed8ddc43d  movaps xmm13, xmm15
00007d2ed8ddc441  addpd xmm13, xmm9
00007d2ed8ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007d2ed8ddc44c  ptest xmm8, xmm8
00007d2ed8ddc452  jnz 0x00007D2ED8DDF987
00007d2ed8ddc458  movaps xmm15, xmm1
00007d2ed8ddc45c  addpd xmm15, xmm5
00007d2ed8ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007d2ed8ddc467  ptest xmm9, xmm9
00007d2ed8ddc46d  jnz 0x00007D2ED8DDFACB
00007d2ed8ddc473  vmovaps [rsp+0x30], xmm11
00007d2ed8ddc479  vmovaps xmm1, [rsp+0x30]
00007d2ed8ddc47f  por xmm11, xmm1
00007d2ed8ddc484  movaps [r15+0x250], xmm11
00007d2ed8ddc48c  vmovaps [rsp+0x30], xmm12
00007d2ed8ddc492  vmovaps xmm1, [rsp+0x30]
00007d2ed8ddc498  por xmm12, xmm1
00007d2ed8ddc49d  movaps [r15+0x2A0], xmm12
00007d2ed8ddc4a5  vmovaps xmm1, [rsp+0xA0]
00007d2ed8ddc4ae  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddc4b7  por xmm1, xmm11
00007d2ed8ddc4bc  movaps [r15+0x1D0], xmm1
00007d2ed8ddc4c4  lea r12, [rax+0x40]
00007d2ed8ddc4c8  movups xmm1, [r13+r12*1]
00007d2ed8ddc4ce  movaps [r15+0x2C0], xmm1
00007d2ed8ddc4d6  vmovaps xmm11, [rsp+0x40]
00007d2ed8ddc4dc  vpermilpd xmm11, xmm11, 0x00
00007d2ed8ddc4e2  vmovaps xmm8, [rsp+0xE0]
00007d2ed8ddc4eb  movaps xmm9, xmm8
00007d2ed8ddc4ef  mulpd xmm9, xmm11
00007d2ed8ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d2ed8ddc4fa  ptest xmm5, xmm5
00007d2ed8ddc4ff  jnz 0x00007D2ED8DDFC17
00007d2ed8ddc505  movaps xmm11, xmm10
00007d2ed8ddc509  addpd xmm11, xmm6
00007d2ed8ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007d2ed8ddc514  ptest xmm8, xmm8
00007d2ed8ddc51a  jnz 0x00007D2ED8DDFD5B
00007d2ed8ddc520  movaps xmm10, xmm14
00007d2ed8ddc524  addpd xmm10, xmm4
00007d2ed8ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007d2ed8ddc52f  ptest xmm8, xmm8
00007d2ed8ddc535  jnz 0x00007D2ED8DDFE9E
00007d2ed8ddc53b  vmovaps xmm14, [rsp+0x40]
00007d2ed8ddc541  vpermilpd xmm14, xmm14, 0x00
00007d2ed8ddc547  movaps xmm8, xmm1
00007d2ed8ddc54b  mulpd xmm8, xmm14
00007d2ed8ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007d2ed8ddc556  ptest xmm6, xmm6
00007d2ed8ddc55b  jnz 0x00007D2ED8DDFFE1
00007d2ed8ddc561  movaps xmm1, [r15+0x2B0]
00007d2ed8ddc569  vmovaps xmm14, [rsp+0x40]
00007d2ed8ddc56f  vpermilpd xmm14, xmm14, 0x00
00007d2ed8ddc575  movaps xmm6, xmm1
00007d2ed8ddc578  mulpd xmm6, xmm14
00007d2ed8ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d2ed8ddc582  ptest xmm5, xmm5
00007d2ed8ddc587  jnz 0x00007D2ED8DE0124
00007d2ed8ddc58d  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddc593  vpermilpd xmm1, xmm1, 0x00
00007d2ed8ddc599  movaps xmm14, xmm12
00007d2ed8ddc59d  mulpd xmm14, xmm1
00007d2ed8ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007d2ed8ddc5a8  ptest xmm5, xmm5
00007d2ed8ddc5ad  jnz 0x00007D2ED8DE0265
00007d2ed8ddc5b3  movaps xmm1, xmm13
00007d2ed8ddc5b7  addpd xmm1, xmm9
00007d2ed8ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007d2ed8ddc5c1  ptest xmm12, xmm12
00007d2ed8ddc5c7  jnz 0x00007D2ED8DE03A8
00007d2ed8ddc5cd  vmovaps xmm13, [rsp+0x10]
00007d2ed8ddc5d3  vpermilpd xmm13, xmm13, 0x00
00007d2ed8ddc5d9  movaps xmm12, xmm7
00007d2ed8ddc5dd  mulpd xmm12, xmm13
00007d2ed8ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d2ed8ddc5e8  ptest xmm9, xmm9
00007d2ed8ddc5ee  jnz 0x00007D2ED8DE04EA
00007d2ed8ddc5f4  movaps xmm13, xmm15
00007d2ed8ddc5f8  addpd xmm13, xmm8
00007d2ed8ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d2ed8ddc603  ptest xmm9, xmm9
00007d2ed8ddc609  jnz 0x00007D2ED8DE062D
00007d2ed8ddc60f  movaps xmm15, [r15+0x290]
00007d2ed8ddc617  vmovaps xmm9, [rsp+0x10]
00007d2ed8ddc61d  vpermilpd xmm9, xmm9, 0x00
00007d2ed8ddc623  movaps xmm8, xmm15
00007d2ed8ddc627  mulpd xmm8, xmm9
00007d2ed8ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d2ed8ddc632  ptest xmm7, xmm7
00007d2ed8ddc637  jnz 0x00007D2ED8DE0771
00007d2ed8ddc63d  movaps xmm15, xmm11
00007d2ed8ddc641  addpd xmm15, xmm6
00007d2ed8ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007d2ed8ddc64c  ptest xmm9, xmm9
00007d2ed8ddc652  jnz 0x00007D2ED8DE08B5
00007d2ed8ddc658  movaps xmm11, [r15+0x1E0]
00007d2ed8ddc660  vmovaps xmm9, [rsp+0x10]
00007d2ed8ddc666  vpermilpd xmm9, xmm9, 0x00
00007d2ed8ddc66c  movaps xmm7, xmm11
00007d2ed8ddc670  mulpd xmm7, xmm9
00007d2ed8ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007d2ed8ddc67a  ptest xmm6, xmm6
00007d2ed8ddc67f  jnz 0x00007D2ED8DE09F8
00007d2ed8ddc685  movaps xmm11, xmm10
00007d2ed8ddc689  addpd xmm11, xmm14
00007d2ed8ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d2ed8ddc694  ptest xmm9, xmm9
00007d2ed8ddc69a  jnz 0x00007D2ED8DE0B3A
00007d2ed8ddc6a0  lea r12, [rax+0x70]
00007d2ed8ddc6a4  movups xmm14, [r13+r12*1]
00007d2ed8ddc6aa  movaps [r15+0x240], xmm14
00007d2ed8ddc6b2  movaps xmm10, xmm1
00007d2ed8ddc6b6  addpd xmm10, xmm12
00007d2ed8ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007d2ed8ddc6c1  ptest xmm9, xmm9
00007d2ed8ddc6c7  jnz 0x00007D2ED8DE0C88
00007d2ed8ddc6cd  movaps [r15+0x170], xmm10
00007d2ed8ddc6d5  vmovaps xmm1, [rsp+0x20]
00007d2ed8ddc6db  vpermilpd xmm1, xmm1, 0x00
00007d2ed8ddc6e1  movaps xmm12, xmm14
00007d2ed8ddc6e5  mulpd xmm12, xmm1
00007d2ed8ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007d2ed8ddc6f0  ptest xmm9, xmm9
00007d2ed8ddc6f6  jnz 0x00007D2ED8DE0DCB
00007d2ed8ddc6fc  vmovaps xmm1, [rsp+0x20]
00007d2ed8ddc702  vpermilpd xmm1, xmm1, 0x00
00007d2ed8ddc708  vmovaps xmm9, [rsp+0xB0]
00007d2ed8ddc711  movaps xmm14, xmm9
00007d2ed8ddc715  mulpd xmm14, xmm1
00007d2ed8ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007d2ed8ddc720  ptest xmm6, xmm6
00007d2ed8ddc725  jnz 0x00007D2ED8DE0F0E
00007d2ed8ddc72b  movaps [r15+0x180], xmm14
00007d2ed8ddc733  movaps xmm1, xmm13
00007d2ed8ddc737  addpd xmm1, xmm8
00007d2ed8ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d2ed8ddc741  ptest xmm9, xmm9
00007d2ed8ddc747  jnz 0x00007D2ED8DE1051
00007d2ed8ddc74d  movaps [r15+0x210], xmm1
00007d2ed8ddc755  movups xmm13, [r13+rax*1]
00007d2ed8ddc75b  lea r12, [rax+0x10]
00007d2ed8ddc75f  movups xmm9, [r13+r12*1]
00007d2ed8ddc765  movaps [r15+0x230], xmm9
00007d2ed8ddc76d  movaps xmm8, xmm15
00007d2ed8ddc771  addpd xmm8, xmm7
00007d2ed8ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007d2ed8ddc77c  ptest xmm6, xmm6
00007d2ed8ddc781  jnz 0x00007D2ED8DE11A7
00007d2ed8ddc787  movaps [r15+0x130], xmm8
00007d2ed8ddc78f  vmovaps xmm15, [rsp+0x20]
00007d2ed8ddc795  vpermilpd xmm15, xmm15, 0x00
00007d2ed8ddc79b  movaps xmm7, xmm9
00007d2ed8ddc79f  mulpd xmm7, xmm15
00007d2ed8ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007d2ed8ddc7a9  ptest xmm6, xmm6
00007d2ed8ddc7ae  jnz 0x00007D2ED8DE12EA
00007d2ed8ddc7b4  movaps [r15+0x220], xmm7
00007d2ed8ddc7bc  vmovaps xmm15, [rsp+0x20]
00007d2ed8ddc7c2  vpermilpd xmm15, xmm15, 0x00
00007d2ed8ddc7c8  movaps xmm9, xmm13
00007d2ed8ddc7cc  mulpd xmm9, xmm15
00007d2ed8ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d2ed8ddc7d7  ptest xmm6, xmm6
00007d2ed8ddc7dc  jnz 0x00007D2ED8DE142C
00007d2ed8ddc7e2  movaps xmm15, xmm11
00007d2ed8ddc7e6  addpd xmm15, xmm12
00007d2ed8ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d2ed8ddc7f1  ptest xmm13, xmm13
00007d2ed8ddc7f7  jnz 0x00007D2ED8DE1570
00007d2ed8ddc7fd  movaps [r15+0x140], xmm15
00007d2ed8ddc805  movaps xmm13, xmm10
00007d2ed8ddc809  addpd xmm13, xmm14
00007d2ed8ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007d2ed8ddc814  ptest xmm12, xmm12
00007d2ed8ddc81a  jnz 0x00007D2ED8DE16B4
00007d2ed8ddc820  movaps [r15+0x150], xmm13
00007d2ed8ddc828  movaps xmm14, xmm1
00007d2ed8ddc82c  addpd xmm14, xmm7
00007d2ed8ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007d2ed8ddc837  ptest xmm12, xmm12
00007d2ed8ddc83d  jnz 0x00007D2ED8DE17F8
00007d2ed8ddc843  movaps [r15+0x160], xmm14
00007d2ed8ddc84b  movaps xmm1, xmm8
00007d2ed8ddc84f  addpd xmm1, xmm9
00007d2ed8ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007d2ed8ddc859  ptest xmm12, xmm12
00007d2ed8ddc85f  jnz 0x00007D2ED8DE193A
00007d2ed8ddc865  movaps [r15+0x120], xmm1
00007d2ed8ddc86d  movups [r13+r14*1], xmm15
00007d2ed8ddc873  lea rax, [r14+0x10]
00007d2ed8ddc877  movups [r13+rax*1], xmm13
00007d2ed8ddc87d  lea rax, [r14+0x20]
00007d2ed8ddc881  movups [r13+rax*1], xmm14
00007d2ed8ddc887  lea rax, [r14+0x30]
00007d2ed8ddc88b  movups [r13+rax*1], xmm1
00007d2ed8ddc891  mov eax, [r15+0x108]
00007d2ed8ddc898  sahf
00007d2ed8ddc899  jnz 0x00007D2ED8DDC8CB
00007d2ed8ddc89b  cmp dword ptr [r15+0x318], 0x00
00007d2ed8ddc8a3  jz 0x00007D2ED8DDB900
00007d2ed8ddc8a9  nop [rax+rax*1], ax
00007d2ed8ddc8b2  nop [rax+rax*1], eax
00007d2ed8ddc8ba  mov eax, 0x410444
00007d2ed8ddc8bf  mov [r15+0x100], rax
00007d2ed8ddc8c6  jmp 0x00007D2ED8BFE110
00007d2ed8ddc8cb  cmp dword ptr [r15+0x318], 0x00
00007d2ed8ddc8d3  jz 0x00007D2ED8DD57E0
00007d2ed8ddc8d9  nop [rax+rax*1], ax
00007d2ed8ddc8e2  nop [rax+rax*1], eax
00007d2ed8ddc8ea  mov eax, 0x410278
00007d2ed8ddc8ef  mov [r15+0x100], rax
00007d2ed8ddc8f6  jmp 0x00007D2ED8BFE110
00007d2ed8ddc8fb  int3
00007d2ed8ddc8fc  call 0x00007D2ED8CE27E0
00007d2ed8ddc901  jmp 0x00007D2ED8DDB9DF
00007d2ed8ddc906  call 0x00007D2ED8CE1570
00007d2ed8ddc90b  jmp 0x00007D2ED8DDB9E8
00007d2ed8ddc910  call 0x00007D2ED8CE27E0
00007d2ed8ddc915  jmp 0x00007D2ED8DDBA44
00007d2ed8ddc91a  call 0x00007D2ED8CE1570
00007d2ed8ddc91f  jmp 0x00007D2ED8DDBA4D
00007d2ed8ddc924  call 0x00007D2ED8CE27E0
00007d2ed8ddc929  jmp 0x00007D2ED8DDBA90
00007d2ed8ddc92e  call 0x00007D2ED8CE1570
00007d2ed8ddc933  jmp 0x00007D2ED8DDBA99
00007d2ed8ddc938  call 0x00007D2ED8C0DC20
00007d2ed8ddc93d  jmp 0x00007D2ED8DDBAD8
00007d2ed8ddc942  call 0x00007D2ED8CD59C0
00007d2ed8ddc947  jmp 0x00007D2ED8DDBAEB
00007d2ed8ddc94c  call 0x00007D2ED8CE0E30
00007d2ed8ddc951  jmp 0x00007D2ED8DDBB09
00007d2ed8ddc956  call 0x00007D2ED8CDFBC0
00007d2ed8ddc95b  jmp 0x00007D2ED8DDBB13
00007d2ed8ddc960  call 0x00007D2ED8CDE950
00007d2ed8ddc965  jmp 0x00007D2ED8DDBB1D
00007d2ed8ddc96a  sub rsp, 0x08
00007d2ed8ddc96e  push rax
00007d2ed8ddc96f  push rcx
00007d2ed8ddc970  push rdx
00007d2ed8ddc971  push rdi
00007d2ed8ddc972  push rsi
00007d2ed8ddc973  push r8
00007d2ed8ddc975  push r9
00007d2ed8ddc977  push r10
00007d2ed8ddc979  push r11
00007d2ed8ddc97b  sub rsp, 0xF0
00007d2ed8ddc982  vmovaps [rsp], xmm0
00007d2ed8ddc987  vmovaps [rsp+0x10], xmm1
00007d2ed8ddc98d  vmovaps [rsp+0x20], xmm2
00007d2ed8ddc993  vmovaps [rsp+0x30], xmm3
00007d2ed8ddc999  vmovaps [rsp+0x40], xmm4
00007d2ed8ddc99f  vmovaps [rsp+0x50], xmm5
00007d2ed8ddc9a5  vmovaps [rsp+0x60], xmm6
00007d2ed8ddc9ab  vmovaps [rsp+0x70], xmm7
00007d2ed8ddc9b1  vmovaps [rsp+0x80], xmm9
00007d2ed8ddc9ba  vmovaps [rsp+0x90], xmm10
00007d2ed8ddc9c3  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddc9cc  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddc9d5  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddc9de  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddc9e7  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddc9f0  sub rsp, 0x30
00007d2ed8ddc9f4  movaps [rsp], xmm8
00007d2ed8ddc9f9  movaps [rsp+0x10], xmm12
00007d2ed8ddc9ff  movaps [rsp+0x20], xmm15
00007d2ed8ddca05  lea rdi, [rsp]
00007d2ed8ddca09  mov esi, 0x00
00007d2ed8ddca0e  mov rax, 0x648718324530
00007d2ed8ddca18  call rax
00007d2ed8ddca1a  movaps xmm8, [rsp]
00007d2ed8ddca1f  add rsp, 0x30
00007d2ed8ddca23  vmovaps xmm0, [rsp]
00007d2ed8ddca28  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddca2e  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddca34  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddca3a  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddca40  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddca46  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddca4c  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddca52  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddca5b  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddca64  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddca6d  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddca76  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddca7f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddca88  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddca91  add rsp, 0xF0
00007d2ed8ddca98  pop r11
00007d2ed8ddca9a  pop r10
00007d2ed8ddca9c  pop r9
00007d2ed8ddca9e  pop r8
00007d2ed8ddcaa0  pop rsi
00007d2ed8ddcaa1  pop rdi
00007d2ed8ddcaa2  pop rdx
00007d2ed8ddcaa3  pop rcx
00007d2ed8ddcaa4  pop rax
00007d2ed8ddcaa5  add rsp, 0x08
00007d2ed8ddcaa9  jmp 0x00007D2ED8DDBB47
00007d2ed8ddcaae  sub rsp, 0x08
00007d2ed8ddcab2  push rax
00007d2ed8ddcab3  push rcx
00007d2ed8ddcab4  push rdx
00007d2ed8ddcab5  push rdi
00007d2ed8ddcab6  push rsi
00007d2ed8ddcab7  push r8
00007d2ed8ddcab9  push r9
00007d2ed8ddcabb  push r10
00007d2ed8ddcabd  push r11
00007d2ed8ddcabf  sub rsp, 0xF0
00007d2ed8ddcac6  vmovaps [rsp], xmm0
00007d2ed8ddcacb  vmovaps [rsp+0x10], xmm1
00007d2ed8ddcad1  vmovaps [rsp+0x20], xmm2
00007d2ed8ddcad7  vmovaps [rsp+0x30], xmm3
00007d2ed8ddcadd  vmovaps [rsp+0x40], xmm4
00007d2ed8ddcae3  vmovaps [rsp+0x50], xmm5
00007d2ed8ddcae9  vmovaps [rsp+0x60], xmm6
00007d2ed8ddcaef  vmovaps [rsp+0x70], xmm8
00007d2ed8ddcaf5  vmovaps [rsp+0x80], xmm9
00007d2ed8ddcafe  vmovaps [rsp+0x90], xmm10
00007d2ed8ddcb07  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddcb10  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddcb19  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddcb22  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddcb2b  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddcb34  sub rsp, 0x30
00007d2ed8ddcb38  movaps [rsp], xmm7
00007d2ed8ddcb3c  movaps [rsp+0x10], xmm9
00007d2ed8ddcb42  movaps [rsp+0x20], xmm15
00007d2ed8ddcb48  lea rdi, [rsp]
00007d2ed8ddcb4c  mov esi, 0x00
00007d2ed8ddcb51  mov rax, 0x648718324530
00007d2ed8ddcb5b  call rax
00007d2ed8ddcb5d  movaps xmm7, [rsp]
00007d2ed8ddcb61  add rsp, 0x30
00007d2ed8ddcb65  vmovaps xmm0, [rsp]
00007d2ed8ddcb6a  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddcb70  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddcb76  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddcb7c  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddcb82  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddcb88  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddcb8e  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddcb94  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddcb9d  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddcba6  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddcbaf  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddcbb8  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddcbc1  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddcbca  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddcbd3  add rsp, 0xF0
00007d2ed8ddcbda  pop r11
00007d2ed8ddcbdc  pop r10
00007d2ed8ddcbde  pop r9
00007d2ed8ddcbe0  pop r8
00007d2ed8ddcbe2  pop rsi
00007d2ed8ddcbe3  pop rdi
00007d2ed8ddcbe4  pop rdx
00007d2ed8ddcbe5  pop rcx
00007d2ed8ddcbe6  pop rax
00007d2ed8ddcbe7  add rsp, 0x08
00007d2ed8ddcbeb  jmp 0x00007D2ED8DDBB75
00007d2ed8ddcbf0  sub rsp, 0x08
00007d2ed8ddcbf4  push rax
00007d2ed8ddcbf5  push rcx
00007d2ed8ddcbf6  push rdx
00007d2ed8ddcbf7  push rdi
00007d2ed8ddcbf8  push rsi
00007d2ed8ddcbf9  push r8
00007d2ed8ddcbfb  push r9
00007d2ed8ddcbfd  push r10
00007d2ed8ddcbff  push r11
00007d2ed8ddcc01  sub rsp, 0xF0
00007d2ed8ddcc08  vmovaps [rsp], xmm0
00007d2ed8ddcc0d  vmovaps [rsp+0x10], xmm1
00007d2ed8ddcc13  vmovaps [rsp+0x20], xmm2
00007d2ed8ddcc19  vmovaps [rsp+0x30], xmm3
00007d2ed8ddcc1f  vmovaps [rsp+0x40], xmm4
00007d2ed8ddcc25  vmovaps [rsp+0x50], xmm5
00007d2ed8ddcc2b  vmovaps [rsp+0x60], xmm6
00007d2ed8ddcc31  vmovaps [rsp+0x70], xmm7
00007d2ed8ddcc37  vmovaps [rsp+0x80], xmm8
00007d2ed8ddcc40  vmovaps [rsp+0x90], xmm10
00007d2ed8ddcc49  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddcc52  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddcc5b  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddcc64  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddcc6d  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddcc76  sub rsp, 0x30
00007d2ed8ddcc7a  movaps [rsp], xmm9
00007d2ed8ddcc7f  movaps [rsp+0x10], xmm12
00007d2ed8ddcc85  movaps [rsp+0x20], xmm10
00007d2ed8ddcc8b  lea rdi, [rsp]
00007d2ed8ddcc8f  mov esi, 0x00
00007d2ed8ddcc94  mov rax, 0x648718324530
00007d2ed8ddcc9e  call rax
00007d2ed8ddcca0  movaps xmm9, [rsp]
00007d2ed8ddcca5  add rsp, 0x30
00007d2ed8ddcca9  vmovaps xmm0, [rsp]
00007d2ed8ddccae  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddccb4  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddccba  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddccc0  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddccc6  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddcccc  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddccd2  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddccd8  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddcce1  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddccea  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddccf3  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddccfc  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddcd05  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddcd0e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddcd17  add rsp, 0xF0
00007d2ed8ddcd1e  pop r11
00007d2ed8ddcd20  pop r10
00007d2ed8ddcd22  pop r9
00007d2ed8ddcd24  pop r8
00007d2ed8ddcd26  pop rsi
00007d2ed8ddcd27  pop rdi
00007d2ed8ddcd28  pop rdx
00007d2ed8ddcd29  pop rcx
00007d2ed8ddcd2a  pop rax
00007d2ed8ddcd2b  add rsp, 0x08
00007d2ed8ddcd2f  jmp 0x00007D2ED8DDBB99
00007d2ed8ddcd34  sub rsp, 0x08
00007d2ed8ddcd38  push rax
00007d2ed8ddcd39  push rcx
00007d2ed8ddcd3a  push rdx
00007d2ed8ddcd3b  push rdi
00007d2ed8ddcd3c  push rsi
00007d2ed8ddcd3d  push r8
00007d2ed8ddcd3f  push r9
00007d2ed8ddcd41  push r10
00007d2ed8ddcd43  push r11
00007d2ed8ddcd45  sub rsp, 0xF0
00007d2ed8ddcd4c  vmovaps [rsp], xmm0
00007d2ed8ddcd51  vmovaps [rsp+0x10], xmm1
00007d2ed8ddcd57  vmovaps [rsp+0x20], xmm2
00007d2ed8ddcd5d  vmovaps [rsp+0x30], xmm3
00007d2ed8ddcd63  vmovaps [rsp+0x40], xmm4
00007d2ed8ddcd69  vmovaps [rsp+0x50], xmm5
00007d2ed8ddcd6f  vmovaps [rsp+0x60], xmm6
00007d2ed8ddcd75  vmovaps [rsp+0x70], xmm7
00007d2ed8ddcd7b  vmovaps [rsp+0x80], xmm8
00007d2ed8ddcd84  vmovaps [rsp+0x90], xmm9
00007d2ed8ddcd8d  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddcd96  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddcd9f  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddcda8  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddcdb1  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddcdba  sub rsp, 0x30
00007d2ed8ddcdbe  movaps [rsp], xmm10
00007d2ed8ddcdc3  movaps [rsp+0x10], xmm12
00007d2ed8ddcdc9  movaps [rsp+0x20], xmm11
00007d2ed8ddcdcf  lea rdi, [rsp]
00007d2ed8ddcdd3  mov esi, 0x00
00007d2ed8ddcdd8  mov rax, 0x648718324530
00007d2ed8ddcde2  call rax
00007d2ed8ddcde4  movaps xmm10, [rsp]
00007d2ed8ddcde9  add rsp, 0x30
00007d2ed8ddcded  vmovaps xmm0, [rsp]
00007d2ed8ddcdf2  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddcdf8  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddcdfe  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddce04  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddce0a  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddce10  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddce16  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddce1c  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddce25  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddce2e  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddce37  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddce40  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddce49  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddce52  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddce5b  add rsp, 0xF0
00007d2ed8ddce62  pop r11
00007d2ed8ddce64  pop r10
00007d2ed8ddce66  pop r9
00007d2ed8ddce68  pop r8
00007d2ed8ddce6a  pop rsi
00007d2ed8ddce6b  pop rdi
00007d2ed8ddce6c  pop rdx
00007d2ed8ddce6d  pop rcx
00007d2ed8ddce6e  pop rax
00007d2ed8ddce6f  add rsp, 0x08
00007d2ed8ddce73  jmp 0x00007D2ED8DDBBB3
00007d2ed8ddce78  sub rsp, 0x08
00007d2ed8ddce7c  push rax
00007d2ed8ddce7d  push rcx
00007d2ed8ddce7e  push rdx
00007d2ed8ddce7f  push rdi
00007d2ed8ddce80  push rsi
00007d2ed8ddce81  push r8
00007d2ed8ddce83  push r9
00007d2ed8ddce85  push r10
00007d2ed8ddce87  push r11
00007d2ed8ddce89  sub rsp, 0xF0
00007d2ed8ddce90  vmovaps [rsp], xmm0
00007d2ed8ddce95  vmovaps [rsp+0x10], xmm1
00007d2ed8ddce9b  vmovaps [rsp+0x20], xmm2
00007d2ed8ddcea1  vmovaps [rsp+0x30], xmm3
00007d2ed8ddcea7  vmovaps [rsp+0x40], xmm4
00007d2ed8ddcead  vmovaps [rsp+0x50], xmm5
00007d2ed8ddceb3  vmovaps [rsp+0x60], xmm7
00007d2ed8ddceb9  vmovaps [rsp+0x70], xmm8
00007d2ed8ddcebf  vmovaps [rsp+0x80], xmm9
00007d2ed8ddcec8  vmovaps [rsp+0x90], xmm10
00007d2ed8ddced1  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddceda  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddcee3  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddceec  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddcef5  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddcefe  sub rsp, 0x30
00007d2ed8ddcf02  movaps [rsp], xmm6
00007d2ed8ddcf06  movaps [rsp+0x10], xmm12
00007d2ed8ddcf0c  movaps [rsp+0x20], xmm11
00007d2ed8ddcf12  lea rdi, [rsp]
00007d2ed8ddcf16  mov esi, 0x00
00007d2ed8ddcf1b  mov rax, 0x648718324530
00007d2ed8ddcf25  call rax
00007d2ed8ddcf27  movaps xmm6, [rsp]
00007d2ed8ddcf2b  add rsp, 0x30
00007d2ed8ddcf2f  vmovaps xmm0, [rsp]
00007d2ed8ddcf34  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddcf3a  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddcf40  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddcf46  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddcf4c  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddcf52  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddcf58  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddcf5e  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddcf67  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddcf70  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddcf79  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddcf82  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddcf8b  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddcf94  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddcf9d  add rsp, 0xF0
00007d2ed8ddcfa4  pop r11
00007d2ed8ddcfa6  pop r10
00007d2ed8ddcfa8  pop r9
00007d2ed8ddcfaa  pop r8
00007d2ed8ddcfac  pop rsi
00007d2ed8ddcfad  pop rdi
00007d2ed8ddcfae  pop rdx
00007d2ed8ddcfaf  pop rcx
00007d2ed8ddcfb0  pop rax
00007d2ed8ddcfb1  add rsp, 0x08
00007d2ed8ddcfb5  jmp 0x00007D2ED8DDBBD4
00007d2ed8ddcfba  sub rsp, 0x08
00007d2ed8ddcfbe  push rax
00007d2ed8ddcfbf  push rcx
00007d2ed8ddcfc0  push rdx
00007d2ed8ddcfc1  push rdi
00007d2ed8ddcfc2  push rsi
00007d2ed8ddcfc3  push r8
00007d2ed8ddcfc5  push r9
00007d2ed8ddcfc7  push r10
00007d2ed8ddcfc9  push r11
00007d2ed8ddcfcb  sub rsp, 0xF0
00007d2ed8ddcfd2  vmovaps [rsp], xmm0
00007d2ed8ddcfd7  vmovaps [rsp+0x10], xmm1
00007d2ed8ddcfdd  vmovaps [rsp+0x20], xmm2
00007d2ed8ddcfe3  vmovaps [rsp+0x30], xmm4
00007d2ed8ddcfe9  vmovaps [rsp+0x40], xmm5
00007d2ed8ddcfef  vmovaps [rsp+0x50], xmm6
00007d2ed8ddcff5  vmovaps [rsp+0x60], xmm7
00007d2ed8ddcffb  vmovaps [rsp+0x70], xmm8
00007d2ed8ddd001  vmovaps [rsp+0x80], xmm9
00007d2ed8ddd00a  vmovaps [rsp+0x90], xmm10
00007d2ed8ddd013  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddd01c  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddd025  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddd02e  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddd037  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddd040  sub rsp, 0x30
00007d2ed8ddd044  movaps [rsp], xmm3
00007d2ed8ddd048  movaps [rsp+0x10], xmm5
00007d2ed8ddd04d  movaps [rsp+0x20], xmm4
00007d2ed8ddd052  lea rdi, [rsp]
00007d2ed8ddd056  mov esi, 0x00
00007d2ed8ddd05b  mov rax, 0x648718324530
00007d2ed8ddd065  call rax
00007d2ed8ddd067  movaps xmm3, [rsp]
00007d2ed8ddd06b  add rsp, 0x30
00007d2ed8ddd06f  vmovaps xmm0, [rsp]
00007d2ed8ddd074  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddd07a  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddd080  vmovaps xmm4, [rsp+0x30]
00007d2ed8ddd086  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddd08c  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddd092  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddd098  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddd09e  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddd0a7  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddd0b0  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddd0b9  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddd0c2  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddd0cb  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddd0d4  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddd0dd  add rsp, 0xF0
00007d2ed8ddd0e4  pop r11
00007d2ed8ddd0e6  pop r10
00007d2ed8ddd0e8  pop r9
00007d2ed8ddd0ea  pop r8
00007d2ed8ddd0ec  pop rsi
00007d2ed8ddd0ed  pop rdi
00007d2ed8ddd0ee  pop rdx
00007d2ed8ddd0ef  pop rcx
00007d2ed8ddd0f0  pop rax
00007d2ed8ddd0f1  add rsp, 0x08
00007d2ed8ddd0f5  jmp 0x00007D2ED8DDBC35
00007d2ed8ddd0fa  sub rsp, 0x08
00007d2ed8ddd0fe  push rax
00007d2ed8ddd0ff  push rcx
00007d2ed8ddd100  push rdx
00007d2ed8ddd101  push rdi
00007d2ed8ddd102  push rsi
00007d2ed8ddd103  push r8
00007d2ed8ddd105  push r9
00007d2ed8ddd107  push r10
00007d2ed8ddd109  push r11
00007d2ed8ddd10b  sub rsp, 0xF0
00007d2ed8ddd112  vmovaps [rsp], xmm0
00007d2ed8ddd117  vmovaps [rsp+0x10], xmm1
00007d2ed8ddd11d  vmovaps [rsp+0x20], xmm2
00007d2ed8ddd123  vmovaps [rsp+0x30], xmm3
00007d2ed8ddd129  vmovaps [rsp+0x40], xmm4
00007d2ed8ddd12f  vmovaps [rsp+0x50], xmm6
00007d2ed8ddd135  vmovaps [rsp+0x60], xmm7
00007d2ed8ddd13b  vmovaps [rsp+0x70], xmm8
00007d2ed8ddd141  vmovaps [rsp+0x80], xmm9
00007d2ed8ddd14a  vmovaps [rsp+0x90], xmm10
00007d2ed8ddd153  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddd15c  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddd165  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddd16e  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddd177  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddd180  sub rsp, 0x30
00007d2ed8ddd184  movaps [rsp], xmm5
00007d2ed8ddd188  movaps [rsp+0x10], xmm8
00007d2ed8ddd18e  movaps [rsp+0x20], xmm15
00007d2ed8ddd194  lea rdi, [rsp]
00007d2ed8ddd198  mov esi, 0x00
00007d2ed8ddd19d  mov rax, 0x648718324530
00007d2ed8ddd1a7  call rax
00007d2ed8ddd1a9  movaps xmm5, [rsp]
00007d2ed8ddd1ad  add rsp, 0x30
00007d2ed8ddd1b1  vmovaps xmm0, [rsp]
00007d2ed8ddd1b6  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddd1bc  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddd1c2  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddd1c8  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddd1ce  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddd1d4  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddd1da  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddd1e0  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddd1e9  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddd1f2  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddd1fb  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddd204  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddd20d  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddd216  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddd21f  add rsp, 0xF0
00007d2ed8ddd226  pop r11
00007d2ed8ddd228  pop r10
00007d2ed8ddd22a  pop r9
00007d2ed8ddd22c  pop r8
00007d2ed8ddd22e  pop rsi
00007d2ed8ddd22f  pop rdi
00007d2ed8ddd230  pop rdx
00007d2ed8ddd231  pop rcx
00007d2ed8ddd232  pop rax
00007d2ed8ddd233  add rsp, 0x08
00007d2ed8ddd237  jmp 0x00007D2ED8DDBC73
00007d2ed8ddd23c  sub rsp, 0x08
00007d2ed8ddd240  push rax
00007d2ed8ddd241  push rcx
00007d2ed8ddd242  push rdx
00007d2ed8ddd243  push rdi
00007d2ed8ddd244  push rsi
00007d2ed8ddd245  push r8
00007d2ed8ddd247  push r9
00007d2ed8ddd249  push r10
00007d2ed8ddd24b  push r11
00007d2ed8ddd24d  sub rsp, 0xF0
00007d2ed8ddd254  vmovaps [rsp], xmm0
00007d2ed8ddd259  vmovaps [rsp+0x10], xmm1
00007d2ed8ddd25f  vmovaps [rsp+0x20], xmm2
00007d2ed8ddd265  vmovaps [rsp+0x30], xmm3
00007d2ed8ddd26b  vmovaps [rsp+0x40], xmm5
00007d2ed8ddd271  vmovaps [rsp+0x50], xmm6
00007d2ed8ddd277  vmovaps [rsp+0x60], xmm7
00007d2ed8ddd27d  vmovaps [rsp+0x70], xmm8
00007d2ed8ddd283  vmovaps [rsp+0x80], xmm9
00007d2ed8ddd28c  vmovaps [rsp+0x90], xmm10
00007d2ed8ddd295  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddd29e  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddd2a7  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddd2b0  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddd2b9  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddd2c2  sub rsp, 0x30
00007d2ed8ddd2c6  movaps [rsp], xmm4
00007d2ed8ddd2ca  movaps [rsp+0x10], xmm9
00007d2ed8ddd2d0  movaps [rsp+0x20], xmm8
00007d2ed8ddd2d6  lea rdi, [rsp]
00007d2ed8ddd2da  mov esi, 0x00
00007d2ed8ddd2df  mov rax, 0x648718324530
00007d2ed8ddd2e9  call rax
00007d2ed8ddd2eb  movaps xmm4, [rsp]
00007d2ed8ddd2ef  add rsp, 0x30
00007d2ed8ddd2f3  vmovaps xmm0, [rsp]
00007d2ed8ddd2f8  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddd2fe  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddd304  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddd30a  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddd310  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddd316  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddd31c  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddd322  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddd32b  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddd334  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddd33d  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddd346  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddd34f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddd358  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddd361  add rsp, 0xF0
00007d2ed8ddd368  pop r11
00007d2ed8ddd36a  pop r10
00007d2ed8ddd36c  pop r9
00007d2ed8ddd36e  pop r8
00007d2ed8ddd370  pop rsi
00007d2ed8ddd371  pop rdi
00007d2ed8ddd372  pop rdx
00007d2ed8ddd373  pop rcx
00007d2ed8ddd374  pop rax
00007d2ed8ddd375  add rsp, 0x08
00007d2ed8ddd379  jmp 0x00007D2ED8DDBC94
00007d2ed8ddd37e  sub rsp, 0x08
00007d2ed8ddd382  push rax
00007d2ed8ddd383  push rcx
00007d2ed8ddd384  push rdx
00007d2ed8ddd385  push rdi
00007d2ed8ddd386  push rsi
00007d2ed8ddd387  push r8
00007d2ed8ddd389  push r9
00007d2ed8ddd38b  push r10
00007d2ed8ddd38d  push r11
00007d2ed8ddd38f  sub rsp, 0xF0
00007d2ed8ddd396  vmovaps [rsp], xmm0
00007d2ed8ddd39b  vmovaps [rsp+0x10], xmm1
00007d2ed8ddd3a1  vmovaps [rsp+0x20], xmm2
00007d2ed8ddd3a7  vmovaps [rsp+0x30], xmm3
00007d2ed8ddd3ad  vmovaps [rsp+0x40], xmm4
00007d2ed8ddd3b3  vmovaps [rsp+0x50], xmm5
00007d2ed8ddd3b9  vmovaps [rsp+0x60], xmm6
00007d2ed8ddd3bf  vmovaps [rsp+0x70], xmm7
00007d2ed8ddd3c5  vmovaps [rsp+0x80], xmm8
00007d2ed8ddd3ce  vmovaps [rsp+0x90], xmm10
00007d2ed8ddd3d7  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddd3e0  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddd3e9  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddd3f2  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddd3fb  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddd404  sub rsp, 0x30
00007d2ed8ddd408  movaps [rsp], xmm9
00007d2ed8ddd40d  movaps [rsp+0x10], xmm10
00007d2ed8ddd413  movaps [rsp+0x20], xmm8
00007d2ed8ddd419  lea rdi, [rsp]
00007d2ed8ddd41d  mov esi, 0x00
00007d2ed8ddd422  mov rax, 0x648718324530
00007d2ed8ddd42c  call rax
00007d2ed8ddd42e  movaps xmm9, [rsp]
00007d2ed8ddd433  add rsp, 0x30
00007d2ed8ddd437  vmovaps xmm0, [rsp]
00007d2ed8ddd43c  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddd442  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddd448  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddd44e  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddd454  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddd45a  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddd460  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddd466  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddd46f  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddd478  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddd481  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddd48a  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddd493  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddd49c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddd4a5  add rsp, 0xF0
00007d2ed8ddd4ac  pop r11
00007d2ed8ddd4ae  pop r10
00007d2ed8ddd4b0  pop r9
00007d2ed8ddd4b2  pop r8
00007d2ed8ddd4b4  pop rsi
00007d2ed8ddd4b5  pop rdi
00007d2ed8ddd4b6  pop rdx
00007d2ed8ddd4b7  pop rcx
00007d2ed8ddd4b8  pop rax
00007d2ed8ddd4b9  add rsp, 0x08
00007d2ed8ddd4bd  jmp 0x00007D2ED8DDBCAE
00007d2ed8ddd4c2  call 0x00007D2ED8CB52F0
00007d2ed8ddd4c7  jmp 0x00007D2ED8DDBDC8
00007d2ed8ddd4cc  call 0x00007D2ED8CB52F0
00007d2ed8ddd4d1  jmp 0x00007D2ED8DDBDDE
00007d2ed8ddd4d6  sub rsp, 0x08
00007d2ed8ddd4da  push rax
00007d2ed8ddd4db  push rcx
00007d2ed8ddd4dc  push rdx
00007d2ed8ddd4dd  push rdi
00007d2ed8ddd4de  push rsi
00007d2ed8ddd4df  push r8
00007d2ed8ddd4e1  push r9
00007d2ed8ddd4e3  push r10
00007d2ed8ddd4e5  push r11
00007d2ed8ddd4e7  sub rsp, 0xF0
00007d2ed8ddd4ee  vmovaps [rsp], xmm0
00007d2ed8ddd4f3  vmovaps [rsp+0x10], xmm2
00007d2ed8ddd4f9  vmovaps [rsp+0x20], xmm3
00007d2ed8ddd4ff  vmovaps [rsp+0x30], xmm4
00007d2ed8ddd505  vmovaps [rsp+0x40], xmm5
00007d2ed8ddd50b  vmovaps [rsp+0x50], xmm6
00007d2ed8ddd511  vmovaps [rsp+0x60], xmm7
00007d2ed8ddd517  vmovaps [rsp+0x70], xmm8
00007d2ed8ddd51d  vmovaps [rsp+0x80], xmm9
00007d2ed8ddd526  vmovaps [rsp+0x90], xmm10
00007d2ed8ddd52f  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddd538  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddd541  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddd54a  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddd553  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddd55c  sub rsp, 0x30
00007d2ed8ddd560  movaps [rsp], xmm1
00007d2ed8ddd564  movaps [rsp+0x10], xmm6
00007d2ed8ddd569  movaps [rsp+0x20], xmm15
00007d2ed8ddd56f  lea rdi, [rsp]
00007d2ed8ddd573  mov esi, 0x00
00007d2ed8ddd578  mov rax, 0x648718324530
00007d2ed8ddd582  call rax
00007d2ed8ddd584  movaps xmm1, [rsp]
00007d2ed8ddd588  add rsp, 0x30
00007d2ed8ddd58c  vmovaps xmm0, [rsp]
00007d2ed8ddd591  vmovaps xmm2, [rsp+0x10]
00007d2ed8ddd597  vmovaps xmm3, [rsp+0x20]
00007d2ed8ddd59d  vmovaps xmm4, [rsp+0x30]
00007d2ed8ddd5a3  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddd5a9  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddd5af  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddd5b5  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddd5bb  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddd5c4  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddd5cd  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddd5d6  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddd5df  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddd5e8  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddd5f1  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddd5fa  add rsp, 0xF0
00007d2ed8ddd601  pop r11
00007d2ed8ddd603  pop r10
00007d2ed8ddd605  pop r9
00007d2ed8ddd607  pop r8
00007d2ed8ddd609  pop rsi
00007d2ed8ddd60a  pop rdi
00007d2ed8ddd60b  pop rdx
00007d2ed8ddd60c  pop rcx
00007d2ed8ddd60d  pop rax
00007d2ed8ddd60e  add rsp, 0x08
00007d2ed8ddd612  jmp 0x00007D2ED8DDBE1B
00007d2ed8ddd617  call 0x00007D2ED8CC4620
00007d2ed8ddd61c  jmp 0x00007D2ED8DDBE28
00007d2ed8ddd621  sub rsp, 0x08
00007d2ed8ddd625  push rax
00007d2ed8ddd626  push rcx
00007d2ed8ddd627  push rdx
00007d2ed8ddd628  push rdi
00007d2ed8ddd629  push rsi
00007d2ed8ddd62a  push r8
00007d2ed8ddd62c  push r9
00007d2ed8ddd62e  push r10
00007d2ed8ddd630  push r11
00007d2ed8ddd632  sub rsp, 0xF0
00007d2ed8ddd639  vmovaps [rsp], xmm0
00007d2ed8ddd63e  vmovaps [rsp+0x10], xmm1
00007d2ed8ddd644  vmovaps [rsp+0x20], xmm2
00007d2ed8ddd64a  vmovaps [rsp+0x30], xmm3
00007d2ed8ddd650  vmovaps [rsp+0x40], xmm4
00007d2ed8ddd656  vmovaps [rsp+0x50], xmm5
00007d2ed8ddd65c  vmovaps [rsp+0x60], xmm6
00007d2ed8ddd662  vmovaps [rsp+0x70], xmm7
00007d2ed8ddd668  vmovaps [rsp+0x80], xmm8
00007d2ed8ddd671  vmovaps [rsp+0x90], xmm9
00007d2ed8ddd67a  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddd683  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddd68c  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddd695  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddd69e  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddd6a7  sub rsp, 0x30
00007d2ed8ddd6ab  movaps [rsp], xmm14
00007d2ed8ddd6b0  movaps [rsp+0x10], xmm4
00007d2ed8ddd6b5  movaps [rsp+0x20], xmm3
00007d2ed8ddd6ba  lea rdi, [rsp]
00007d2ed8ddd6be  mov esi, 0x00
00007d2ed8ddd6c3  mov rax, 0x648718324530
00007d2ed8ddd6cd  call rax
00007d2ed8ddd6cf  movaps xmm14, [rsp]
00007d2ed8ddd6d4  add rsp, 0x30
00007d2ed8ddd6d8  vmovaps xmm0, [rsp]
00007d2ed8ddd6dd  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddd6e3  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddd6e9  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddd6ef  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddd6f5  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddd6fb  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddd701  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddd707  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddd710  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddd719  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddd722  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddd72b  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddd734  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddd73d  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddd746  add rsp, 0xF0
00007d2ed8ddd74d  pop r11
00007d2ed8ddd74f  pop r10
00007d2ed8ddd751  pop r9
00007d2ed8ddd753  pop r8
00007d2ed8ddd755  pop rsi
00007d2ed8ddd756  pop rdi
00007d2ed8ddd757  pop rdx
00007d2ed8ddd758  pop rcx
00007d2ed8ddd759  pop rax
00007d2ed8ddd75a  add rsp, 0x08
00007d2ed8ddd75e  jmp 0x00007D2ED8DDBE42
00007d2ed8ddd763  sub rsp, 0x08
00007d2ed8ddd767  push rax
00007d2ed8ddd768  push rcx
00007d2ed8ddd769  push rdx
00007d2ed8ddd76a  push rdi
00007d2ed8ddd76b  push rsi
00007d2ed8ddd76c  push r8
00007d2ed8ddd76e  push r9
00007d2ed8ddd770  push r10
00007d2ed8ddd772  push r11
00007d2ed8ddd774  sub rsp, 0xF0
00007d2ed8ddd77b  vmovaps [rsp], xmm0
00007d2ed8ddd780  vmovaps [rsp+0x10], xmm1
00007d2ed8ddd786  vmovaps [rsp+0x20], xmm2
00007d2ed8ddd78c  vmovaps [rsp+0x30], xmm3
00007d2ed8ddd792  vmovaps [rsp+0x40], xmm4
00007d2ed8ddd798  vmovaps [rsp+0x50], xmm5
00007d2ed8ddd79e  vmovaps [rsp+0x60], xmm7
00007d2ed8ddd7a4  vmovaps [rsp+0x70], xmm8
00007d2ed8ddd7aa  vmovaps [rsp+0x80], xmm9
00007d2ed8ddd7b3  vmovaps [rsp+0x90], xmm10
00007d2ed8ddd7bc  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddd7c5  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddd7ce  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddd7d7  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddd7e0  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddd7e9  sub rsp, 0x30
00007d2ed8ddd7ed  movaps [rsp], xmm6
00007d2ed8ddd7f1  movaps [rsp+0x10], xmm9
00007d2ed8ddd7f7  movaps [rsp+0x20], xmm7
00007d2ed8ddd7fc  lea rdi, [rsp]
00007d2ed8ddd800  mov esi, 0x00
00007d2ed8ddd805  mov rax, 0x648718324530
00007d2ed8ddd80f  call rax
00007d2ed8ddd811  movaps xmm6, [rsp]
00007d2ed8ddd815  add rsp, 0x30
00007d2ed8ddd819  vmovaps xmm0, [rsp]
00007d2ed8ddd81e  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddd824  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddd82a  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddd830  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddd836  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddd83c  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddd842  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddd848  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddd851  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddd85a  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddd863  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddd86c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddd875  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddd87e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddd887  add rsp, 0xF0
00007d2ed8ddd88e  pop r11
00007d2ed8ddd890  pop r10
00007d2ed8ddd892  pop r9
00007d2ed8ddd894  pop r8
00007d2ed8ddd896  pop rsi
00007d2ed8ddd897  pop rdi
00007d2ed8ddd898  pop rdx
00007d2ed8ddd899  pop rcx
00007d2ed8ddd89a  pop rax
00007d2ed8ddd89b  add rsp, 0x08
00007d2ed8ddd89f  jmp 0x00007D2ED8DDBE5A
00007d2ed8ddd8a4  sub rsp, 0x08
00007d2ed8ddd8a8  push rax
00007d2ed8ddd8a9  push rcx
00007d2ed8ddd8aa  push rdx
00007d2ed8ddd8ab  push rdi
00007d2ed8ddd8ac  push rsi
00007d2ed8ddd8ad  push r8
00007d2ed8ddd8af  push r9
00007d2ed8ddd8b1  push r10
00007d2ed8ddd8b3  push r11
00007d2ed8ddd8b5  sub rsp, 0xF0
00007d2ed8ddd8bc  vmovaps [rsp], xmm0
00007d2ed8ddd8c1  vmovaps [rsp+0x10], xmm1
00007d2ed8ddd8c7  vmovaps [rsp+0x20], xmm2
00007d2ed8ddd8cd  vmovaps [rsp+0x30], xmm3
00007d2ed8ddd8d3  vmovaps [rsp+0x40], xmm4
00007d2ed8ddd8d9  vmovaps [rsp+0x50], xmm5
00007d2ed8ddd8df  vmovaps [rsp+0x60], xmm6
00007d2ed8ddd8e5  vmovaps [rsp+0x70], xmm8
00007d2ed8ddd8eb  vmovaps [rsp+0x80], xmm9
00007d2ed8ddd8f4  vmovaps [rsp+0x90], xmm10
00007d2ed8ddd8fd  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddd906  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddd90f  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddd918  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddd921  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddd92a  sub rsp, 0x30
00007d2ed8ddd92e  movaps [rsp], xmm7
00007d2ed8ddd932  movaps [rsp+0x10], xmm4
00007d2ed8ddd937  movaps [rsp+0x20], xmm9
00007d2ed8ddd93d  lea rdi, [rsp]
00007d2ed8ddd941  mov esi, 0x00
00007d2ed8ddd946  mov rax, 0x648718324530
00007d2ed8ddd950  call rax
00007d2ed8ddd952  movaps xmm7, [rsp]
00007d2ed8ddd956  add rsp, 0x30
00007d2ed8ddd95a  vmovaps xmm0, [rsp]
00007d2ed8ddd95f  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddd965  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddd96b  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddd971  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddd977  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddd97d  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddd983  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddd989  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddd992  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddd99b  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddd9a4  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddd9ad  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddd9b6  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddd9bf  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddd9c8  add rsp, 0xF0
00007d2ed8ddd9cf  pop r11
00007d2ed8ddd9d1  pop r10
00007d2ed8ddd9d3  pop r9
00007d2ed8ddd9d5  pop r8
00007d2ed8ddd9d7  pop rsi
00007d2ed8ddd9d8  pop rdi
00007d2ed8ddd9d9  pop rdx
00007d2ed8ddd9da  pop rcx
00007d2ed8ddd9db  pop rax
00007d2ed8ddd9dc  add rsp, 0x08
00007d2ed8ddd9e0  jmp 0x00007D2ED8DDBE87
00007d2ed8ddd9e5  sub rsp, 0x08
00007d2ed8ddd9e9  push rax
00007d2ed8ddd9ea  push rcx
00007d2ed8ddd9eb  push rdx
00007d2ed8ddd9ec  push rdi
00007d2ed8ddd9ed  push rsi
00007d2ed8ddd9ee  push r8
00007d2ed8ddd9f0  push r9
00007d2ed8ddd9f2  push r10
00007d2ed8ddd9f4  push r11
00007d2ed8ddd9f6  sub rsp, 0xF0
00007d2ed8ddd9fd  vmovaps [rsp], xmm0
00007d2ed8ddda02  vmovaps [rsp+0x10], xmm1
00007d2ed8ddda08  vmovaps [rsp+0x20], xmm2
00007d2ed8ddda0e  vmovaps [rsp+0x30], xmm3
00007d2ed8ddda14  vmovaps [rsp+0x40], xmm5
00007d2ed8ddda1a  vmovaps [rsp+0x50], xmm6
00007d2ed8ddda20  vmovaps [rsp+0x60], xmm7
00007d2ed8ddda26  vmovaps [rsp+0x70], xmm8
00007d2ed8ddda2c  vmovaps [rsp+0x80], xmm9
00007d2ed8ddda35  vmovaps [rsp+0x90], xmm10
00007d2ed8ddda3e  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddda47  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddda50  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddda59  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddda62  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddda6b  sub rsp, 0x30
00007d2ed8ddda6f  movaps [rsp], xmm4
00007d2ed8ddda73  movaps [rsp+0x10], xmm15
00007d2ed8ddda79  movaps [rsp+0x20], xmm9
00007d2ed8ddda7f  lea rdi, [rsp]
00007d2ed8ddda83  mov esi, 0x00
00007d2ed8ddda88  mov rax, 0x648718324530
00007d2ed8ddda92  call rax
00007d2ed8ddda94  movaps xmm4, [rsp]
00007d2ed8ddda98  add rsp, 0x30
00007d2ed8ddda9c  vmovaps xmm0, [rsp]
00007d2ed8dddaa1  vmovaps xmm1, [rsp+0x10]
00007d2ed8dddaa7  vmovaps xmm2, [rsp+0x20]
00007d2ed8dddaad  vmovaps xmm3, [rsp+0x30]
00007d2ed8dddab3  vmovaps xmm5, [rsp+0x40]
00007d2ed8dddab9  vmovaps xmm6, [rsp+0x50]
00007d2ed8dddabf  vmovaps xmm7, [rsp+0x60]
00007d2ed8dddac5  vmovaps xmm8, [rsp+0x70]
00007d2ed8dddacb  vmovaps xmm9, [rsp+0x80]
00007d2ed8dddad4  vmovaps xmm10, [rsp+0x90]
00007d2ed8dddadd  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dddae6  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dddaef  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dddaf8  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dddb01  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dddb0a  add rsp, 0xF0
00007d2ed8dddb11  pop r11
00007d2ed8dddb13  pop r10
00007d2ed8dddb15  pop r9
00007d2ed8dddb17  pop r8
00007d2ed8dddb19  pop rsi
00007d2ed8dddb1a  pop rdi
00007d2ed8dddb1b  pop rdx
00007d2ed8dddb1c  pop rcx
00007d2ed8dddb1d  pop rax
00007d2ed8dddb1e  add rsp, 0x08
00007d2ed8dddb22  jmp 0x00007D2ED8DDBEAC
00007d2ed8dddb27  call 0x00007D2ED8CC4620
00007d2ed8dddb2c  jmp 0x00007D2ED8DDBEB9
00007d2ed8dddb31  sub rsp, 0x08
00007d2ed8dddb35  push rax
00007d2ed8dddb36  push rcx
00007d2ed8dddb37  push rdx
00007d2ed8dddb38  push rdi
00007d2ed8dddb39  push rsi
00007d2ed8dddb3a  push r8
00007d2ed8dddb3c  push r9
00007d2ed8dddb3e  push r10
00007d2ed8dddb40  push r11
00007d2ed8dddb42  sub rsp, 0xF0
00007d2ed8dddb49  vmovaps [rsp], xmm0
00007d2ed8dddb4e  vmovaps [rsp+0x10], xmm1
00007d2ed8dddb54  vmovaps [rsp+0x20], xmm2
00007d2ed8dddb5a  vmovaps [rsp+0x30], xmm4
00007d2ed8dddb60  vmovaps [rsp+0x40], xmm5
00007d2ed8dddb66  vmovaps [rsp+0x50], xmm6
00007d2ed8dddb6c  vmovaps [rsp+0x60], xmm7
00007d2ed8dddb72  vmovaps [rsp+0x70], xmm8
00007d2ed8dddb78  vmovaps [rsp+0x80], xmm9
00007d2ed8dddb81  vmovaps [rsp+0x90], xmm10
00007d2ed8dddb8a  vmovaps [rsp+0xA0], xmm11
00007d2ed8dddb93  vmovaps [rsp+0xB0], xmm12
00007d2ed8dddb9c  vmovaps [rsp+0xC0], xmm13
00007d2ed8dddba5  vmovaps [rsp+0xD0], xmm14
00007d2ed8dddbae  vmovaps [rsp+0xE0], xmm15
00007d2ed8dddbb7  sub rsp, 0x30
00007d2ed8dddbbb  movaps [rsp], xmm3
00007d2ed8dddbbf  movaps [rsp+0x10], xmm1
00007d2ed8dddbc4  movaps [rsp+0x20], xmm9
00007d2ed8dddbca  lea rdi, [rsp]
00007d2ed8dddbce  mov esi, 0x00
00007d2ed8dddbd3  mov rax, 0x648718324530
00007d2ed8dddbdd  call rax
00007d2ed8dddbdf  movaps xmm3, [rsp]
00007d2ed8dddbe3  add rsp, 0x30
00007d2ed8dddbe7  vmovaps xmm0, [rsp]
00007d2ed8dddbec  vmovaps xmm1, [rsp+0x10]
00007d2ed8dddbf2  vmovaps xmm2, [rsp+0x20]
00007d2ed8dddbf8  vmovaps xmm4, [rsp+0x30]
00007d2ed8dddbfe  vmovaps xmm5, [rsp+0x40]
00007d2ed8dddc04  vmovaps xmm6, [rsp+0x50]
00007d2ed8dddc0a  vmovaps xmm7, [rsp+0x60]
00007d2ed8dddc10  vmovaps xmm8, [rsp+0x70]
00007d2ed8dddc16  vmovaps xmm9, [rsp+0x80]
00007d2ed8dddc1f  vmovaps xmm10, [rsp+0x90]
00007d2ed8dddc28  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dddc31  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dddc3a  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dddc43  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dddc4c  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dddc55  add rsp, 0xF0
00007d2ed8dddc5c  pop r11
00007d2ed8dddc5e  pop r10
00007d2ed8dddc60  pop r9
00007d2ed8dddc62  pop r8
00007d2ed8dddc64  pop rsi
00007d2ed8dddc65  pop rdi
00007d2ed8dddc66  pop rdx
00007d2ed8dddc67  pop rcx
00007d2ed8dddc68  pop rax
00007d2ed8dddc69  add rsp, 0x08
00007d2ed8dddc6d  jmp 0x00007D2ED8DDBEF6
00007d2ed8dddc72  sub rsp, 0x08
00007d2ed8dddc76  push rax
00007d2ed8dddc77  push rcx
00007d2ed8dddc78  push rdx
00007d2ed8dddc79  push rdi
00007d2ed8dddc7a  push rsi
00007d2ed8dddc7b  push r8
00007d2ed8dddc7d  push r9
00007d2ed8dddc7f  push r10
00007d2ed8dddc81  push r11
00007d2ed8dddc83  sub rsp, 0xF0
00007d2ed8dddc8a  vmovaps [rsp], xmm0
00007d2ed8dddc8f  vmovaps [rsp+0x10], xmm2
00007d2ed8dddc95  vmovaps [rsp+0x20], xmm3
00007d2ed8dddc9b  vmovaps [rsp+0x30], xmm4
00007d2ed8dddca1  vmovaps [rsp+0x40], xmm5
00007d2ed8dddca7  vmovaps [rsp+0x50], xmm6
00007d2ed8dddcad  vmovaps [rsp+0x60], xmm7
00007d2ed8dddcb3  vmovaps [rsp+0x70], xmm8
00007d2ed8dddcb9  vmovaps [rsp+0x80], xmm9
00007d2ed8dddcc2  vmovaps [rsp+0x90], xmm10
00007d2ed8dddccb  vmovaps [rsp+0xA0], xmm11
00007d2ed8dddcd4  vmovaps [rsp+0xB0], xmm12
00007d2ed8dddcdd  vmovaps [rsp+0xC0], xmm13
00007d2ed8dddce6  vmovaps [rsp+0xD0], xmm14
00007d2ed8dddcef  vmovaps [rsp+0xE0], xmm15
00007d2ed8dddcf8  sub rsp, 0x30
00007d2ed8dddcfc  movaps [rsp], xmm1
00007d2ed8dddd00  movaps [rsp+0x10], xmm15
00007d2ed8dddd06  movaps [rsp+0x20], xmm9
00007d2ed8dddd0c  lea rdi, [rsp]
00007d2ed8dddd10  mov esi, 0x00
00007d2ed8dddd15  mov rax, 0x648718324530
00007d2ed8dddd1f  call rax
00007d2ed8dddd21  movaps xmm1, [rsp]
00007d2ed8dddd25  add rsp, 0x30
00007d2ed8dddd29  vmovaps xmm0, [rsp]
00007d2ed8dddd2e  vmovaps xmm2, [rsp+0x10]
00007d2ed8dddd34  vmovaps xmm3, [rsp+0x20]
00007d2ed8dddd3a  vmovaps xmm4, [rsp+0x30]
00007d2ed8dddd40  vmovaps xmm5, [rsp+0x40]
00007d2ed8dddd46  vmovaps xmm6, [rsp+0x50]
00007d2ed8dddd4c  vmovaps xmm7, [rsp+0x60]
00007d2ed8dddd52  vmovaps xmm8, [rsp+0x70]
00007d2ed8dddd58  vmovaps xmm9, [rsp+0x80]
00007d2ed8dddd61  vmovaps xmm10, [rsp+0x90]
00007d2ed8dddd6a  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dddd73  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dddd7c  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dddd85  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dddd8e  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dddd97  add rsp, 0xF0
00007d2ed8dddd9e  pop r11
00007d2ed8dddda0  pop r10
00007d2ed8dddda2  pop r9
00007d2ed8dddda4  pop r8
00007d2ed8dddda6  pop rsi
00007d2ed8dddda7  pop rdi
00007d2ed8dddda8  pop rdx
00007d2ed8dddda9  pop rcx
00007d2ed8ddddaa  pop rax
00007d2ed8ddddab  add rsp, 0x08
00007d2ed8ddddaf  jmp 0x00007D2ED8DDBF7E
00007d2ed8ddddb4  call 0x00007D2ED8CC4620
00007d2ed8ddddb9  jmp 0x00007D2ED8DDBF8B
00007d2ed8ddddbe  sub rsp, 0x08
00007d2ed8ddddc2  push rax
00007d2ed8ddddc3  push rcx
00007d2ed8ddddc4  push rdx
00007d2ed8ddddc5  push rdi
00007d2ed8ddddc6  push rsi
00007d2ed8ddddc7  push r8
00007d2ed8ddddc9  push r9
00007d2ed8ddddcb  push r10
00007d2ed8ddddcd  push r11
00007d2ed8ddddcf  sub rsp, 0xF0
00007d2ed8ddddd6  vmovaps [rsp], xmm0
00007d2ed8dddddb  vmovaps [rsp+0x10], xmm2
00007d2ed8dddde1  vmovaps [rsp+0x20], xmm3
00007d2ed8dddde7  vmovaps [rsp+0x30], xmm4
00007d2ed8dddded  vmovaps [rsp+0x40], xmm5
00007d2ed8ddddf3  vmovaps [rsp+0x50], xmm6
00007d2ed8ddddf9  vmovaps [rsp+0x60], xmm7
00007d2ed8ddddff  vmovaps [rsp+0x70], xmm8
00007d2ed8ddde05  vmovaps [rsp+0x80], xmm9
00007d2ed8ddde0e  vmovaps [rsp+0x90], xmm10
00007d2ed8ddde17  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddde20  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddde29  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddde32  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddde3b  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddde44  sub rsp, 0x30
00007d2ed8ddde48  movaps [rsp], xmm1
00007d2ed8ddde4c  movaps [rsp+0x10], xmm5
00007d2ed8ddde51  movaps [rsp+0x20], xmm7
00007d2ed8ddde56  lea rdi, [rsp]
00007d2ed8ddde5a  mov esi, 0x00
00007d2ed8ddde5f  mov rax, 0x648718324530
00007d2ed8ddde69  call rax
00007d2ed8ddde6b  movaps xmm1, [rsp]
00007d2ed8ddde6f  add rsp, 0x30
00007d2ed8ddde73  vmovaps xmm0, [rsp]
00007d2ed8ddde78  vmovaps xmm2, [rsp+0x10]
00007d2ed8ddde7e  vmovaps xmm3, [rsp+0x20]
00007d2ed8ddde84  vmovaps xmm4, [rsp+0x30]
00007d2ed8ddde8a  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddde90  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddde96  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddde9c  vmovaps xmm8, [rsp+0x70]
00007d2ed8dddea2  vmovaps xmm9, [rsp+0x80]
00007d2ed8dddeab  vmovaps xmm10, [rsp+0x90]
00007d2ed8dddeb4  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dddebd  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dddec6  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dddecf  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddded8  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dddee1  add rsp, 0xF0
00007d2ed8dddee8  pop r11
00007d2ed8dddeea  pop r10
00007d2ed8dddeec  pop r9
00007d2ed8dddeee  pop r8
00007d2ed8dddef0  pop rsi
00007d2ed8dddef1  pop rdi
00007d2ed8dddef2  pop rdx
00007d2ed8dddef3  pop rcx
00007d2ed8dddef4  pop rax
00007d2ed8dddef5  add rsp, 0x08
00007d2ed8dddef9  jmp 0x00007D2ED8DDC030
00007d2ed8dddefe  sub rsp, 0x08
00007d2ed8dddf02  push rax
00007d2ed8dddf03  push rcx
00007d2ed8dddf04  push rdx
00007d2ed8dddf05  push rdi
00007d2ed8dddf06  push rsi
00007d2ed8dddf07  push r8
00007d2ed8dddf09  push r9
00007d2ed8dddf0b  push r10
00007d2ed8dddf0d  push r11
00007d2ed8dddf0f  sub rsp, 0xF0
00007d2ed8dddf16  vmovaps [rsp], xmm0
00007d2ed8dddf1b  vmovaps [rsp+0x10], xmm1
00007d2ed8dddf21  vmovaps [rsp+0x20], xmm2
00007d2ed8dddf27  vmovaps [rsp+0x30], xmm3
00007d2ed8dddf2d  vmovaps [rsp+0x40], xmm4
00007d2ed8dddf33  vmovaps [rsp+0x50], xmm5
00007d2ed8dddf39  vmovaps [rsp+0x60], xmm6
00007d2ed8dddf3f  vmovaps [rsp+0x70], xmm8
00007d2ed8dddf45  vmovaps [rsp+0x80], xmm9
00007d2ed8dddf4e  vmovaps [rsp+0x90], xmm10
00007d2ed8dddf57  vmovaps [rsp+0xA0], xmm11
00007d2ed8dddf60  vmovaps [rsp+0xB0], xmm12
00007d2ed8dddf69  vmovaps [rsp+0xC0], xmm13
00007d2ed8dddf72  vmovaps [rsp+0xD0], xmm14
00007d2ed8dddf7b  vmovaps [rsp+0xE0], xmm15
00007d2ed8dddf84  sub rsp, 0x30
00007d2ed8dddf88  movaps [rsp], xmm7
00007d2ed8dddf8c  movaps [rsp+0x10], xmm5
00007d2ed8dddf91  movaps [rsp+0x20], xmm15
00007d2ed8dddf97  lea rdi, [rsp]
00007d2ed8dddf9b  mov esi, 0x00
00007d2ed8dddfa0  mov rax, 0x648718324530
00007d2ed8dddfaa  call rax
00007d2ed8dddfac  movaps xmm7, [rsp]
00007d2ed8dddfb0  add rsp, 0x30
00007d2ed8dddfb4  vmovaps xmm0, [rsp]
00007d2ed8dddfb9  vmovaps xmm1, [rsp+0x10]
00007d2ed8dddfbf  vmovaps xmm2, [rsp+0x20]
00007d2ed8dddfc5  vmovaps xmm3, [rsp+0x30]
00007d2ed8dddfcb  vmovaps xmm4, [rsp+0x40]
00007d2ed8dddfd1  vmovaps xmm5, [rsp+0x50]
00007d2ed8dddfd7  vmovaps xmm6, [rsp+0x60]
00007d2ed8dddfdd  vmovaps xmm8, [rsp+0x70]
00007d2ed8dddfe3  vmovaps xmm9, [rsp+0x80]
00007d2ed8dddfec  vmovaps xmm10, [rsp+0x90]
00007d2ed8dddff5  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dddffe  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dde007  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dde010  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dde019  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dde022  add rsp, 0xF0
00007d2ed8dde029  pop r11
00007d2ed8dde02b  pop r10
00007d2ed8dde02d  pop r9
00007d2ed8dde02f  pop r8
00007d2ed8dde031  pop rsi
00007d2ed8dde032  pop rdi
00007d2ed8dde033  pop rdx
00007d2ed8dde034  pop rcx
00007d2ed8dde035  pop rax
00007d2ed8dde036  add rsp, 0x08
00007d2ed8dde03a  jmp 0x00007D2ED8DDC066
00007d2ed8dde03f  call 0x00007D2ED8CB52F0
00007d2ed8dde044  jmp 0x00007D2ED8DDC073
00007d2ed8dde049  sub rsp, 0x08
00007d2ed8dde04d  push rax
00007d2ed8dde04e  push rcx
00007d2ed8dde04f  push rdx
00007d2ed8dde050  push rdi
00007d2ed8dde051  push rsi
00007d2ed8dde052  push r8
00007d2ed8dde054  push r9
00007d2ed8dde056  push r10
00007d2ed8dde058  push r11
00007d2ed8dde05a  sub rsp, 0xF0
00007d2ed8dde061  vmovaps [rsp], xmm0
00007d2ed8dde066  vmovaps [rsp+0x10], xmm1
00007d2ed8dde06c  vmovaps [rsp+0x20], xmm2
00007d2ed8dde072  vmovaps [rsp+0x30], xmm3
00007d2ed8dde078  vmovaps [rsp+0x40], xmm4
00007d2ed8dde07e  vmovaps [rsp+0x50], xmm5
00007d2ed8dde084  vmovaps [rsp+0x60], xmm6
00007d2ed8dde08a  vmovaps [rsp+0x70], xmm7
00007d2ed8dde090  vmovaps [rsp+0x80], xmm8
00007d2ed8dde099  vmovaps [rsp+0x90], xmm9
00007d2ed8dde0a2  vmovaps [rsp+0xA0], xmm10
00007d2ed8dde0ab  vmovaps [rsp+0xB0], xmm11
00007d2ed8dde0b4  vmovaps [rsp+0xC0], xmm12
00007d2ed8dde0bd  vmovaps [rsp+0xD0], xmm13
00007d2ed8dde0c6  vmovaps [rsp+0xE0], xmm14
00007d2ed8dde0cf  sub rsp, 0x30
00007d2ed8dde0d3  movaps [rsp], xmm15
00007d2ed8dde0d8  movaps [rsp+0x10], xmm5
00007d2ed8dde0dd  movaps [rsp+0x20], xmm3
00007d2ed8dde0e2  lea rdi, [rsp]
00007d2ed8dde0e6  mov esi, 0x00
00007d2ed8dde0eb  mov rax, 0x648718324530
00007d2ed8dde0f5  call rax
00007d2ed8dde0f7  movaps xmm15, [rsp]
00007d2ed8dde0fc  add rsp, 0x30
00007d2ed8dde100  vmovaps xmm0, [rsp]
00007d2ed8dde105  vmovaps xmm1, [rsp+0x10]
00007d2ed8dde10b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dde111  vmovaps xmm3, [rsp+0x30]
00007d2ed8dde117  vmovaps xmm4, [rsp+0x40]
00007d2ed8dde11d  vmovaps xmm5, [rsp+0x50]
00007d2ed8dde123  vmovaps xmm6, [rsp+0x60]
00007d2ed8dde129  vmovaps xmm7, [rsp+0x70]
00007d2ed8dde12f  vmovaps xmm8, [rsp+0x80]
00007d2ed8dde138  vmovaps xmm9, [rsp+0x90]
00007d2ed8dde141  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dde14a  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dde153  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dde15c  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dde165  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dde16e  add rsp, 0xF0
00007d2ed8dde175  pop r11
00007d2ed8dde177  pop r10
00007d2ed8dde179  pop r9
00007d2ed8dde17b  pop r8
00007d2ed8dde17d  pop rsi
00007d2ed8dde17e  pop rdi
00007d2ed8dde17f  pop rdx
00007d2ed8dde180  pop rcx
00007d2ed8dde181  pop rax
00007d2ed8dde182  add rsp, 0x08
00007d2ed8dde186  jmp 0x00007D2ED8DDC099
00007d2ed8dde18b  sub rsp, 0x08
00007d2ed8dde18f  push rax
00007d2ed8dde190  push rcx
00007d2ed8dde191  push rdx
00007d2ed8dde192  push rdi
00007d2ed8dde193  push rsi
00007d2ed8dde194  push r8
00007d2ed8dde196  push r9
00007d2ed8dde198  push r10
00007d2ed8dde19a  push r11
00007d2ed8dde19c  sub rsp, 0xF0
00007d2ed8dde1a3  vmovaps [rsp], xmm0
00007d2ed8dde1a8  vmovaps [rsp+0x10], xmm2
00007d2ed8dde1ae  vmovaps [rsp+0x20], xmm3
00007d2ed8dde1b4  vmovaps [rsp+0x30], xmm4
00007d2ed8dde1ba  vmovaps [rsp+0x40], xmm5
00007d2ed8dde1c0  vmovaps [rsp+0x50], xmm6
00007d2ed8dde1c6  vmovaps [rsp+0x60], xmm7
00007d2ed8dde1cc  vmovaps [rsp+0x70], xmm8
00007d2ed8dde1d2  vmovaps [rsp+0x80], xmm9
00007d2ed8dde1db  vmovaps [rsp+0x90], xmm10
00007d2ed8dde1e4  vmovaps [rsp+0xA0], xmm11
00007d2ed8dde1ed  vmovaps [rsp+0xB0], xmm12
00007d2ed8dde1f6  vmovaps [rsp+0xC0], xmm13
00007d2ed8dde1ff  vmovaps [rsp+0xD0], xmm14
00007d2ed8dde208  vmovaps [rsp+0xE0], xmm15
00007d2ed8dde211  sub rsp, 0x30
00007d2ed8dde215  movaps [rsp], xmm1
00007d2ed8dde219  movaps [rsp+0x10], xmm5
00007d2ed8dde21e  movaps [rsp+0x20], xmm4
00007d2ed8dde223  lea rdi, [rsp]
00007d2ed8dde227  mov esi, 0x00
00007d2ed8dde22c  mov rax, 0x648718324530
00007d2ed8dde236  call rax
00007d2ed8dde238  movaps xmm1, [rsp]
00007d2ed8dde23c  add rsp, 0x30
00007d2ed8dde240  vmovaps xmm0, [rsp]
00007d2ed8dde245  vmovaps xmm2, [rsp+0x10]
00007d2ed8dde24b  vmovaps xmm3, [rsp+0x20]
00007d2ed8dde251  vmovaps xmm4, [rsp+0x30]
00007d2ed8dde257  vmovaps xmm5, [rsp+0x40]
00007d2ed8dde25d  vmovaps xmm6, [rsp+0x50]
00007d2ed8dde263  vmovaps xmm7, [rsp+0x60]
00007d2ed8dde269  vmovaps xmm8, [rsp+0x70]
00007d2ed8dde26f  vmovaps xmm9, [rsp+0x80]
00007d2ed8dde278  vmovaps xmm10, [rsp+0x90]
00007d2ed8dde281  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dde28a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dde293  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dde29c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dde2a5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dde2ae  add rsp, 0xF0
00007d2ed8dde2b5  pop r11
00007d2ed8dde2b7  pop r10
00007d2ed8dde2b9  pop r9
00007d2ed8dde2bb  pop r8
00007d2ed8dde2bd  pop rsi
00007d2ed8dde2be  pop rdi
00007d2ed8dde2bf  pop rdx
00007d2ed8dde2c0  pop rcx
00007d2ed8dde2c1  pop rax
00007d2ed8dde2c2  add rsp, 0x08
00007d2ed8dde2c6  jmp 0x00007D2ED8DDC0B9
00007d2ed8dde2cb  sub rsp, 0x08
00007d2ed8dde2cf  push rax
00007d2ed8dde2d0  push rcx
00007d2ed8dde2d1  push rdx
00007d2ed8dde2d2  push rdi
00007d2ed8dde2d3  push rsi
00007d2ed8dde2d4  push r8
00007d2ed8dde2d6  push r9
00007d2ed8dde2d8  push r10
00007d2ed8dde2da  push r11
00007d2ed8dde2dc  sub rsp, 0xF0
00007d2ed8dde2e3  vmovaps [rsp], xmm0
00007d2ed8dde2e8  vmovaps [rsp+0x10], xmm1
00007d2ed8dde2ee  vmovaps [rsp+0x20], xmm2
00007d2ed8dde2f4  vmovaps [rsp+0x30], xmm3
00007d2ed8dde2fa  vmovaps [rsp+0x40], xmm5
00007d2ed8dde300  vmovaps [rsp+0x50], xmm6
00007d2ed8dde306  vmovaps [rsp+0x60], xmm7
00007d2ed8dde30c  vmovaps [rsp+0x70], xmm8
00007d2ed8dde312  vmovaps [rsp+0x80], xmm9
00007d2ed8dde31b  vmovaps [rsp+0x90], xmm10
00007d2ed8dde324  vmovaps [rsp+0xA0], xmm11
00007d2ed8dde32d  vmovaps [rsp+0xB0], xmm12
00007d2ed8dde336  vmovaps [rsp+0xC0], xmm13
00007d2ed8dde33f  vmovaps [rsp+0xD0], xmm14
00007d2ed8dde348  vmovaps [rsp+0xE0], xmm15
00007d2ed8dde351  sub rsp, 0x30
00007d2ed8dde355  movaps [rsp], xmm4
00007d2ed8dde359  movaps [rsp+0x10], xmm3
00007d2ed8dde35e  movaps [rsp+0x20], xmm5
00007d2ed8dde363  lea rdi, [rsp]
00007d2ed8dde367  mov esi, 0x00
00007d2ed8dde36c  mov rax, 0x648718324530
00007d2ed8dde376  call rax
00007d2ed8dde378  movaps xmm4, [rsp]
00007d2ed8dde37c  add rsp, 0x30
00007d2ed8dde380  vmovaps xmm0, [rsp]
00007d2ed8dde385  vmovaps xmm1, [rsp+0x10]
00007d2ed8dde38b  vmovaps xmm2, [rsp+0x20]
00007d2ed8dde391  vmovaps xmm3, [rsp+0x30]
00007d2ed8dde397  vmovaps xmm5, [rsp+0x40]
00007d2ed8dde39d  vmovaps xmm6, [rsp+0x50]
00007d2ed8dde3a3  vmovaps xmm7, [rsp+0x60]
00007d2ed8dde3a9  vmovaps xmm8, [rsp+0x70]
00007d2ed8dde3af  vmovaps xmm9, [rsp+0x80]
00007d2ed8dde3b8  vmovaps xmm10, [rsp+0x90]
00007d2ed8dde3c1  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dde3ca  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dde3d3  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dde3dc  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dde3e5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dde3ee  add rsp, 0xF0
00007d2ed8dde3f5  pop r11
00007d2ed8dde3f7  pop r10
00007d2ed8dde3f9  pop r9
00007d2ed8dde3fb  pop r8
00007d2ed8dde3fd  pop rsi
00007d2ed8dde3fe  pop rdi
00007d2ed8dde3ff  pop rdx
00007d2ed8dde400  pop rcx
00007d2ed8dde401  pop rax
00007d2ed8dde402  add rsp, 0x08
00007d2ed8dde406  jmp 0x00007D2ED8DDC107
00007d2ed8dde40b  call 0x00007D2ED8CB52F0
00007d2ed8dde410  jmp 0x00007D2ED8DDC114
00007d2ed8dde415  sub rsp, 0x08
00007d2ed8dde419  push rax
00007d2ed8dde41a  push rcx
00007d2ed8dde41b  push rdx
00007d2ed8dde41c  push rdi
00007d2ed8dde41d  push rsi
00007d2ed8dde41e  push r8
00007d2ed8dde420  push r9
00007d2ed8dde422  push r10
00007d2ed8dde424  push r11
00007d2ed8dde426  sub rsp, 0xF0
00007d2ed8dde42d  vmovaps [rsp], xmm0
00007d2ed8dde432  vmovaps [rsp+0x10], xmm1
00007d2ed8dde438  vmovaps [rsp+0x20], xmm2
00007d2ed8dde43e  vmovaps [rsp+0x30], xmm3
00007d2ed8dde444  vmovaps [rsp+0x40], xmm4
00007d2ed8dde44a  vmovaps [rsp+0x50], xmm6
00007d2ed8dde450  vmovaps [rsp+0x60], xmm7
00007d2ed8dde456  vmovaps [rsp+0x70], xmm8
00007d2ed8dde45c  vmovaps [rsp+0x80], xmm9
00007d2ed8dde465  vmovaps [rsp+0x90], xmm10
00007d2ed8dde46e  vmovaps [rsp+0xA0], xmm11
00007d2ed8dde477  vmovaps [rsp+0xB0], xmm12
00007d2ed8dde480  vmovaps [rsp+0xC0], xmm13
00007d2ed8dde489  vmovaps [rsp+0xD0], xmm14
00007d2ed8dde492  vmovaps [rsp+0xE0], xmm15
00007d2ed8dde49b  sub rsp, 0x30
00007d2ed8dde49f  movaps [rsp], xmm5
00007d2ed8dde4a3  movaps [rsp+0x10], xmm6
00007d2ed8dde4a8  movaps [rsp+0x20], xmm3
00007d2ed8dde4ad  lea rdi, [rsp]
00007d2ed8dde4b1  mov esi, 0x00
00007d2ed8dde4b6  mov rax, 0x648718324530
00007d2ed8dde4c0  call rax
00007d2ed8dde4c2  movaps xmm5, [rsp]
00007d2ed8dde4c6  add rsp, 0x30
00007d2ed8dde4ca  vmovaps xmm0, [rsp]
00007d2ed8dde4cf  vmovaps xmm1, [rsp+0x10]
00007d2ed8dde4d5  vmovaps xmm2, [rsp+0x20]
00007d2ed8dde4db  vmovaps xmm3, [rsp+0x30]
00007d2ed8dde4e1  vmovaps xmm4, [rsp+0x40]
00007d2ed8dde4e7  vmovaps xmm6, [rsp+0x50]
00007d2ed8dde4ed  vmovaps xmm7, [rsp+0x60]
00007d2ed8dde4f3  vmovaps xmm8, [rsp+0x70]
00007d2ed8dde4f9  vmovaps xmm9, [rsp+0x80]
00007d2ed8dde502  vmovaps xmm10, [rsp+0x90]
00007d2ed8dde50b  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dde514  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dde51d  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dde526  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dde52f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dde538  add rsp, 0xF0
00007d2ed8dde53f  pop r11
00007d2ed8dde541  pop r10
00007d2ed8dde543  pop r9
00007d2ed8dde545  pop r8
00007d2ed8dde547  pop rsi
00007d2ed8dde548  pop rdi
00007d2ed8dde549  pop rdx
00007d2ed8dde54a  pop rcx
00007d2ed8dde54b  pop rax
00007d2ed8dde54c  add rsp, 0x08
00007d2ed8dde550  jmp 0x00007D2ED8DDC13A
00007d2ed8dde555  sub rsp, 0x08
00007d2ed8dde559  push rax
00007d2ed8dde55a  push rcx
00007d2ed8dde55b  push rdx
00007d2ed8dde55c  push rdi
00007d2ed8dde55d  push rsi
00007d2ed8dde55e  push r8
00007d2ed8dde560  push r9
00007d2ed8dde562  push r10
00007d2ed8dde564  push r11
00007d2ed8dde566  sub rsp, 0xF0
00007d2ed8dde56d  vmovaps [rsp], xmm0
00007d2ed8dde572  vmovaps [rsp+0x10], xmm1
00007d2ed8dde578  vmovaps [rsp+0x20], xmm2
00007d2ed8dde57e  vmovaps [rsp+0x30], xmm3
00007d2ed8dde584  vmovaps [rsp+0x40], xmm4
00007d2ed8dde58a  vmovaps [rsp+0x50], xmm5
00007d2ed8dde590  vmovaps [rsp+0x60], xmm7
00007d2ed8dde596  vmovaps [rsp+0x70], xmm8
00007d2ed8dde59c  vmovaps [rsp+0x80], xmm9
00007d2ed8dde5a5  vmovaps [rsp+0x90], xmm10
00007d2ed8dde5ae  vmovaps [rsp+0xA0], xmm11
00007d2ed8dde5b7  vmovaps [rsp+0xB0], xmm12
00007d2ed8dde5c0  vmovaps [rsp+0xC0], xmm13
00007d2ed8dde5c9  vmovaps [rsp+0xD0], xmm14
00007d2ed8dde5d2  vmovaps [rsp+0xE0], xmm15
00007d2ed8dde5db  sub rsp, 0x30
00007d2ed8dde5df  movaps [rsp], xmm6
00007d2ed8dde5e3  movaps [rsp+0x10], xmm9
00007d2ed8dde5e9  movaps [rsp+0x20], xmm1
00007d2ed8dde5ee  lea rdi, [rsp]
00007d2ed8dde5f2  mov esi, 0x00
00007d2ed8dde5f7  mov rax, 0x648718324530
00007d2ed8dde601  call rax
00007d2ed8dde603  movaps xmm6, [rsp]
00007d2ed8dde607  add rsp, 0x30
00007d2ed8dde60b  vmovaps xmm0, [rsp]
00007d2ed8dde610  vmovaps xmm1, [rsp+0x10]
00007d2ed8dde616  vmovaps xmm2, [rsp+0x20]
00007d2ed8dde61c  vmovaps xmm3, [rsp+0x30]
00007d2ed8dde622  vmovaps xmm4, [rsp+0x40]
00007d2ed8dde628  vmovaps xmm5, [rsp+0x50]
00007d2ed8dde62e  vmovaps xmm7, [rsp+0x60]
00007d2ed8dde634  vmovaps xmm8, [rsp+0x70]
00007d2ed8dde63a  vmovaps xmm9, [rsp+0x80]
00007d2ed8dde643  vmovaps xmm10, [rsp+0x90]
00007d2ed8dde64c  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dde655  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dde65e  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dde667  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dde670  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dde679  add rsp, 0xF0
00007d2ed8dde680  pop r11
00007d2ed8dde682  pop r10
00007d2ed8dde684  pop r9
00007d2ed8dde686  pop r8
00007d2ed8dde688  pop rsi
00007d2ed8dde689  pop rdi
00007d2ed8dde68a  pop rdx
00007d2ed8dde68b  pop rcx
00007d2ed8dde68c  pop rax
00007d2ed8dde68d  add rsp, 0x08
00007d2ed8dde691  jmp 0x00007D2ED8DDC15E
00007d2ed8dde696  sub rsp, 0x08
00007d2ed8dde69a  push rax
00007d2ed8dde69b  push rcx
00007d2ed8dde69c  push rdx
00007d2ed8dde69d  push rdi
00007d2ed8dde69e  push rsi
00007d2ed8dde69f  push r8
00007d2ed8dde6a1  push r9
00007d2ed8dde6a3  push r10
00007d2ed8dde6a5  push r11
00007d2ed8dde6a7  sub rsp, 0xF0
00007d2ed8dde6ae  vmovaps [rsp], xmm0
00007d2ed8dde6b3  vmovaps [rsp+0x10], xmm1
00007d2ed8dde6b9  vmovaps [rsp+0x20], xmm2
00007d2ed8dde6bf  vmovaps [rsp+0x30], xmm3
00007d2ed8dde6c5  vmovaps [rsp+0x40], xmm4
00007d2ed8dde6cb  vmovaps [rsp+0x50], xmm5
00007d2ed8dde6d1  vmovaps [rsp+0x60], xmm6
00007d2ed8dde6d7  vmovaps [rsp+0x70], xmm7
00007d2ed8dde6dd  vmovaps [rsp+0x80], xmm8
00007d2ed8dde6e6  vmovaps [rsp+0x90], xmm10
00007d2ed8dde6ef  vmovaps [rsp+0xA0], xmm11
00007d2ed8dde6f8  vmovaps [rsp+0xB0], xmm12
00007d2ed8dde701  vmovaps [rsp+0xC0], xmm13
00007d2ed8dde70a  vmovaps [rsp+0xD0], xmm14
00007d2ed8dde713  vmovaps [rsp+0xE0], xmm15
00007d2ed8dde71c  sub rsp, 0x30
00007d2ed8dde720  movaps [rsp], xmm9
00007d2ed8dde725  movaps [rsp+0x10], xmm3
00007d2ed8dde72a  movaps [rsp+0x20], xmm1
00007d2ed8dde72f  lea rdi, [rsp]
00007d2ed8dde733  mov esi, 0x00
00007d2ed8dde738  mov rax, 0x648718324530
00007d2ed8dde742  call rax
00007d2ed8dde744  movaps xmm9, [rsp]
00007d2ed8dde749  add rsp, 0x30
00007d2ed8dde74d  vmovaps xmm0, [rsp]
00007d2ed8dde752  vmovaps xmm1, [rsp+0x10]
00007d2ed8dde758  vmovaps xmm2, [rsp+0x20]
00007d2ed8dde75e  vmovaps xmm3, [rsp+0x30]
00007d2ed8dde764  vmovaps xmm4, [rsp+0x40]
00007d2ed8dde76a  vmovaps xmm5, [rsp+0x50]
00007d2ed8dde770  vmovaps xmm6, [rsp+0x60]
00007d2ed8dde776  vmovaps xmm7, [rsp+0x70]
00007d2ed8dde77c  vmovaps xmm8, [rsp+0x80]
00007d2ed8dde785  vmovaps xmm10, [rsp+0x90]
00007d2ed8dde78e  vmovaps xmm11, [rsp+0xA0]
00007d2ed8dde797  vmovaps xmm12, [rsp+0xB0]
00007d2ed8dde7a0  vmovaps xmm13, [rsp+0xC0]
00007d2ed8dde7a9  vmovaps xmm14, [rsp+0xD0]
00007d2ed8dde7b2  vmovaps xmm15, [rsp+0xE0]
00007d2ed8dde7bb  add rsp, 0xF0
00007d2ed8dde7c2  pop r11
00007d2ed8dde7c4  pop r10
00007d2ed8dde7c6  pop r9
00007d2ed8dde7c8  pop r8
00007d2ed8dde7ca  pop rsi
00007d2ed8dde7cb  pop rdi
00007d2ed8dde7cc  pop rdx
00007d2ed8dde7cd  pop rcx
00007d2ed8dde7ce  pop rax
00007d2ed8dde7cf  add rsp, 0x08
00007d2ed8dde7d3  jmp 0x00007D2ED8DDC1AA
00007d2ed8dde7d8  call 0x00007D2ED8CB52F0
00007d2ed8dde7dd  jmp 0x00007D2ED8DDC1B7
00007d2ed8dde7e2  sub rsp, 0x08
00007d2ed8dde7e6  push rax
00007d2ed8dde7e7  push rcx
00007d2ed8dde7e8  push rdx
00007d2ed8dde7e9  push rdi
00007d2ed8dde7ea  push rsi
00007d2ed8dde7eb  push r8
00007d2ed8dde7ed  push r9
00007d2ed8dde7ef  push r10
00007d2ed8dde7f1  push r11
00007d2ed8dde7f3  sub rsp, 0xF0
00007d2ed8dde7fa  vmovaps [rsp], xmm0
00007d2ed8dde7ff  vmovaps [rsp+0x10], xmm1
00007d2ed8dde805  vmovaps [rsp+0x20], xmm2
00007d2ed8dde80b  vmovaps [rsp+0x30], xmm3
00007d2ed8dde811  vmovaps [rsp+0x40], xmm4
00007d2ed8dde817  vmovaps [rsp+0x50], xmm5
00007d2ed8dde81d  vmovaps [rsp+0x60], xmm6
00007d2ed8dde823  vmovaps [rsp+0x70], xmm7
00007d2ed8dde829  vmovaps [rsp+0x80], xmm8
00007d2ed8dde832  vmovaps [rsp+0x90], xmm9
00007d2ed8dde83b  vmovaps [rsp+0xA0], xmm10
00007d2ed8dde844  vmovaps [rsp+0xB0], xmm11
00007d2ed8dde84d  vmovaps [rsp+0xC0], xmm12
00007d2ed8dde856  vmovaps [rsp+0xD0], xmm13
00007d2ed8dde85f  vmovaps [rsp+0xE0], xmm14
00007d2ed8dde868  sub rsp, 0x30
00007d2ed8dde86c  movaps [rsp], xmm15
00007d2ed8dde871  movaps [rsp+0x10], xmm3
00007d2ed8dde876  movaps [rsp+0x20], xmm7
00007d2ed8dde87b  lea rdi, [rsp]
00007d2ed8dde87f  mov esi, 0x00
00007d2ed8dde884  mov rax, 0x648718324530
00007d2ed8dde88e  call rax
00007d2ed8dde890  movaps xmm15, [rsp]
00007d2ed8dde895  add rsp, 0x30
00007d2ed8dde899  vmovaps xmm0, [rsp]
00007d2ed8dde89e  vmovaps xmm1, [rsp+0x10]
00007d2ed8dde8a4  vmovaps xmm2, [rsp+0x20]
00007d2ed8dde8aa  vmovaps xmm3, [rsp+0x30]
00007d2ed8dde8b0  vmovaps xmm4, [rsp+0x40]
00007d2ed8dde8b6  vmovaps xmm5, [rsp+0x50]
00007d2ed8dde8bc  vmovaps xmm6, [rsp+0x60]
00007d2ed8dde8c2  vmovaps xmm7, [rsp+0x70]
00007d2ed8dde8c8  vmovaps xmm8, [rsp+0x80]
00007d2ed8dde8d1  vmovaps xmm9, [rsp+0x90]
00007d2ed8dde8da  vmovaps xmm10, [rsp+0xA0]
00007d2ed8dde8e3  vmovaps xmm11, [rsp+0xB0]
00007d2ed8dde8ec  vmovaps xmm12, [rsp+0xC0]
00007d2ed8dde8f5  vmovaps xmm13, [rsp+0xD0]
00007d2ed8dde8fe  vmovaps xmm14, [rsp+0xE0]
00007d2ed8dde907  add rsp, 0xF0
00007d2ed8dde90e  pop r11
00007d2ed8dde910  pop r10
00007d2ed8dde912  pop r9
00007d2ed8dde914  pop r8
00007d2ed8dde916  pop rsi
00007d2ed8dde917  pop rdi
00007d2ed8dde918  pop rdx
00007d2ed8dde919  pop rcx
00007d2ed8dde91a  pop rax
00007d2ed8dde91b  add rsp, 0x08
00007d2ed8dde91f  jmp 0x00007D2ED8DDC1E3
00007d2ed8dde924  sub rsp, 0x08
00007d2ed8dde928  push rax
00007d2ed8dde929  push rcx
00007d2ed8dde92a  push rdx
00007d2ed8dde92b  push rdi
00007d2ed8dde92c  push rsi
00007d2ed8dde92d  push r8
00007d2ed8dde92f  push r9
00007d2ed8dde931  push r10
00007d2ed8dde933  push r11
00007d2ed8dde935  sub rsp, 0xF0
00007d2ed8dde93c  vmovaps [rsp], xmm0
00007d2ed8dde941  vmovaps [rsp+0x10], xmm1
00007d2ed8dde947  vmovaps [rsp+0x20], xmm2
00007d2ed8dde94d  vmovaps [rsp+0x30], xmm4
00007d2ed8dde953  vmovaps [rsp+0x40], xmm5
00007d2ed8dde959  vmovaps [rsp+0x50], xmm6
00007d2ed8dde95f  vmovaps [rsp+0x60], xmm7
00007d2ed8dde965  vmovaps [rsp+0x70], xmm8
00007d2ed8dde96b  vmovaps [rsp+0x80], xmm9
00007d2ed8dde974  vmovaps [rsp+0x90], xmm10
00007d2ed8dde97d  vmovaps [rsp+0xA0], xmm11
00007d2ed8dde986  vmovaps [rsp+0xB0], xmm12
00007d2ed8dde98f  vmovaps [rsp+0xC0], xmm13
00007d2ed8dde998  vmovaps [rsp+0xD0], xmm14
00007d2ed8dde9a1  vmovaps [rsp+0xE0], xmm15
00007d2ed8dde9aa  sub rsp, 0x30
00007d2ed8dde9ae  movaps [rsp], xmm3
00007d2ed8dde9b2  movaps [rsp+0x10], xmm1
00007d2ed8dde9b7  movaps [rsp+0x20], xmm15
00007d2ed8dde9bd  lea rdi, [rsp]
00007d2ed8dde9c1  mov esi, 0x00
00007d2ed8dde9c6  mov rax, 0x648718324530
00007d2ed8dde9d0  call rax
00007d2ed8dde9d2  movaps xmm3, [rsp]
00007d2ed8dde9d6  add rsp, 0x30
00007d2ed8dde9da  vmovaps xmm0, [rsp]
00007d2ed8dde9df  vmovaps xmm1, [rsp+0x10]
00007d2ed8dde9e5  vmovaps xmm2, [rsp+0x20]
00007d2ed8dde9eb  vmovaps xmm4, [rsp+0x30]
00007d2ed8dde9f1  vmovaps xmm5, [rsp+0x40]
00007d2ed8dde9f7  vmovaps xmm6, [rsp+0x50]
00007d2ed8dde9fd  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddea03  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddea09  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddea12  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddea1b  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddea24  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddea2d  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddea36  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddea3f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddea48  add rsp, 0xF0
00007d2ed8ddea4f  pop r11
00007d2ed8ddea51  pop r10
00007d2ed8ddea53  pop r9
00007d2ed8ddea55  pop r8
00007d2ed8ddea57  pop rsi
00007d2ed8ddea58  pop rdi
00007d2ed8ddea59  pop rdx
00007d2ed8ddea5a  pop rcx
00007d2ed8ddea5b  pop rax
00007d2ed8ddea5c  add rsp, 0x08
00007d2ed8ddea60  jmp 0x00007D2ED8DDC272
00007d2ed8ddea65  call 0x00007D2ED8CB52F0
00007d2ed8ddea6a  jmp 0x00007D2ED8DDC27C
00007d2ed8ddea6f  sub rsp, 0x08
00007d2ed8ddea73  push rax
00007d2ed8ddea74  push rcx
00007d2ed8ddea75  push rdx
00007d2ed8ddea76  push rdi
00007d2ed8ddea77  push rsi
00007d2ed8ddea78  push r8
00007d2ed8ddea7a  push r9
00007d2ed8ddea7c  push r10
00007d2ed8ddea7e  push r11
00007d2ed8ddea80  sub rsp, 0xF0
00007d2ed8ddea87  vmovaps [rsp], xmm0
00007d2ed8ddea8c  vmovaps [rsp+0x10], xmm1
00007d2ed8ddea92  vmovaps [rsp+0x20], xmm2
00007d2ed8ddea98  vmovaps [rsp+0x30], xmm3
00007d2ed8ddea9e  vmovaps [rsp+0x40], xmm4
00007d2ed8ddeaa4  vmovaps [rsp+0x50], xmm5
00007d2ed8ddeaaa  vmovaps [rsp+0x60], xmm6
00007d2ed8ddeab0  vmovaps [rsp+0x70], xmm7
00007d2ed8ddeab6  vmovaps [rsp+0x80], xmm8
00007d2ed8ddeabf  vmovaps [rsp+0x90], xmm9
00007d2ed8ddeac8  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddead1  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddeada  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddeae3  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddeaec  vmovaps [rsp+0xE0], xmm14
00007d2ed8ddeaf5  sub rsp, 0x30
00007d2ed8ddeaf9  movaps [rsp], xmm15
00007d2ed8ddeafe  movaps [rsp+0x10], xmm14
00007d2ed8ddeb04  movaps [rsp+0x20], xmm4
00007d2ed8ddeb09  lea rdi, [rsp]
00007d2ed8ddeb0d  mov esi, 0x00
00007d2ed8ddeb12  mov rax, 0x648718324530
00007d2ed8ddeb1c  call rax
00007d2ed8ddeb1e  movaps xmm15, [rsp]
00007d2ed8ddeb23  add rsp, 0x30
00007d2ed8ddeb27  vmovaps xmm0, [rsp]
00007d2ed8ddeb2c  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddeb32  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddeb38  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddeb3e  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddeb44  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddeb4a  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddeb50  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddeb56  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddeb5f  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddeb68  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddeb71  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddeb7a  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddeb83  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddeb8c  vmovaps xmm14, [rsp+0xE0]
00007d2ed8ddeb95  add rsp, 0xF0
00007d2ed8ddeb9c  pop r11
00007d2ed8ddeb9e  pop r10
00007d2ed8ddeba0  pop r9
00007d2ed8ddeba2  pop r8
00007d2ed8ddeba4  pop rsi
00007d2ed8ddeba5  pop rdi
00007d2ed8ddeba6  pop rdx
00007d2ed8ddeba7  pop rcx
00007d2ed8ddeba8  pop rax
00007d2ed8ddeba9  add rsp, 0x08
00007d2ed8ddebad  jmp 0x00007D2ED8DDC2AA
00007d2ed8ddebb2  sub rsp, 0x08
00007d2ed8ddebb6  push rax
00007d2ed8ddebb7  push rcx
00007d2ed8ddebb8  push rdx
00007d2ed8ddebb9  push rdi
00007d2ed8ddebba  push rsi
00007d2ed8ddebbb  push r8
00007d2ed8ddebbd  push r9
00007d2ed8ddebbf  push r10
00007d2ed8ddebc1  push r11
00007d2ed8ddebc3  sub rsp, 0xF0
00007d2ed8ddebca  vmovaps [rsp], xmm0
00007d2ed8ddebcf  vmovaps [rsp+0x10], xmm1
00007d2ed8ddebd5  vmovaps [rsp+0x20], xmm2
00007d2ed8ddebdb  vmovaps [rsp+0x30], xmm3
00007d2ed8ddebe1  vmovaps [rsp+0x40], xmm4
00007d2ed8ddebe7  vmovaps [rsp+0x50], xmm5
00007d2ed8ddebed  vmovaps [rsp+0x60], xmm6
00007d2ed8ddebf3  vmovaps [rsp+0x70], xmm7
00007d2ed8ddebf9  vmovaps [rsp+0x80], xmm8
00007d2ed8ddec02  vmovaps [rsp+0x90], xmm9
00007d2ed8ddec0b  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddec14  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddec1d  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddec26  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddec2f  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddec38  sub rsp, 0x30
00007d2ed8ddec3c  movaps [rsp], xmm14
00007d2ed8ddec41  movaps [rsp+0x10], xmm2
00007d2ed8ddec46  movaps [rsp+0x20], xmm1
00007d2ed8ddec4b  lea rdi, [rsp]
00007d2ed8ddec4f  mov esi, 0x00
00007d2ed8ddec54  mov rax, 0x648718324530
00007d2ed8ddec5e  call rax
00007d2ed8ddec60  movaps xmm14, [rsp]
00007d2ed8ddec65  add rsp, 0x30
00007d2ed8ddec69  vmovaps xmm0, [rsp]
00007d2ed8ddec6e  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddec74  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddec7a  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddec80  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddec86  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddec8c  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddec92  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddec98  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddeca1  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddecaa  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddecb3  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddecbc  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddecc5  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddecce  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddecd7  add rsp, 0xF0
00007d2ed8ddecde  pop r11
00007d2ed8ddece0  pop r10
00007d2ed8ddece2  pop r9
00007d2ed8ddece4  pop r8
00007d2ed8ddece6  pop rsi
00007d2ed8ddece7  pop rdi
00007d2ed8ddece8  pop rdx
00007d2ed8ddece9  pop rcx
00007d2ed8ddecea  pop rax
00007d2ed8ddeceb  add rsp, 0x08
00007d2ed8ddecef  jmp 0x00007D2ED8DDC2D0
00007d2ed8ddecf4  sub rsp, 0x08
00007d2ed8ddecf8  push rax
00007d2ed8ddecf9  push rcx
00007d2ed8ddecfa  push rdx
00007d2ed8ddecfb  push rdi
00007d2ed8ddecfc  push rsi
00007d2ed8ddecfd  push r8
00007d2ed8ddecff  push r9
00007d2ed8dded01  push r10
00007d2ed8dded03  push r11
00007d2ed8dded05  sub rsp, 0xF0
00007d2ed8dded0c  vmovaps [rsp], xmm0
00007d2ed8dded11  vmovaps [rsp+0x10], xmm2
00007d2ed8dded17  vmovaps [rsp+0x20], xmm3
00007d2ed8dded1d  vmovaps [rsp+0x30], xmm4
00007d2ed8dded23  vmovaps [rsp+0x40], xmm5
00007d2ed8dded29  vmovaps [rsp+0x50], xmm6
00007d2ed8dded2f  vmovaps [rsp+0x60], xmm7
00007d2ed8dded35  vmovaps [rsp+0x70], xmm8
00007d2ed8dded3b  vmovaps [rsp+0x80], xmm9
00007d2ed8dded44  vmovaps [rsp+0x90], xmm10
00007d2ed8dded4d  vmovaps [rsp+0xA0], xmm11
00007d2ed8dded56  vmovaps [rsp+0xB0], xmm12
00007d2ed8dded5f  vmovaps [rsp+0xC0], xmm13
00007d2ed8dded68  vmovaps [rsp+0xD0], xmm14
00007d2ed8dded71  vmovaps [rsp+0xE0], xmm15
00007d2ed8dded7a  sub rsp, 0x30
00007d2ed8dded7e  movaps [rsp], xmm1
00007d2ed8dded82  movaps [rsp+0x10], xmm4
00007d2ed8dded87  movaps [rsp+0x20], xmm9
00007d2ed8dded8d  lea rdi, [rsp]
00007d2ed8dded91  mov esi, 0x00
00007d2ed8dded96  mov rax, 0x648718324530
00007d2ed8ddeda0  call rax
00007d2ed8ddeda2  movaps xmm1, [rsp]
00007d2ed8ddeda6  add rsp, 0x30
00007d2ed8ddedaa  vmovaps xmm0, [rsp]
00007d2ed8ddedaf  vmovaps xmm2, [rsp+0x10]
00007d2ed8ddedb5  vmovaps xmm3, [rsp+0x20]
00007d2ed8ddedbb  vmovaps xmm4, [rsp+0x30]
00007d2ed8ddedc1  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddedc7  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddedcd  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddedd3  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddedd9  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddede2  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddedeb  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddedf4  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddedfd  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddee06  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddee0f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddee18  add rsp, 0xF0
00007d2ed8ddee1f  pop r11
00007d2ed8ddee21  pop r10
00007d2ed8ddee23  pop r9
00007d2ed8ddee25  pop r8
00007d2ed8ddee27  pop rsi
00007d2ed8ddee28  pop rdi
00007d2ed8ddee29  pop rdx
00007d2ed8ddee2a  pop rcx
00007d2ed8ddee2b  pop rax
00007d2ed8ddee2c  add rsp, 0x08
00007d2ed8ddee30  jmp 0x00007D2ED8DDC2EE
00007d2ed8ddee35  sub rsp, 0x08
00007d2ed8ddee39  push rax
00007d2ed8ddee3a  push rcx
00007d2ed8ddee3b  push rdx
00007d2ed8ddee3c  push rdi
00007d2ed8ddee3d  push rsi
00007d2ed8ddee3e  push r8
00007d2ed8ddee40  push r9
00007d2ed8ddee42  push r10
00007d2ed8ddee44  push r11
00007d2ed8ddee46  sub rsp, 0xF0
00007d2ed8ddee4d  vmovaps [rsp], xmm0
00007d2ed8ddee52  vmovaps [rsp+0x10], xmm1
00007d2ed8ddee58  vmovaps [rsp+0x20], xmm2
00007d2ed8ddee5e  vmovaps [rsp+0x30], xmm3
00007d2ed8ddee64  vmovaps [rsp+0x40], xmm5
00007d2ed8ddee6a  vmovaps [rsp+0x50], xmm6
00007d2ed8ddee70  vmovaps [rsp+0x60], xmm7
00007d2ed8ddee76  vmovaps [rsp+0x70], xmm8
00007d2ed8ddee7c  vmovaps [rsp+0x80], xmm9
00007d2ed8ddee85  vmovaps [rsp+0x90], xmm10
00007d2ed8ddee8e  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddee97  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddeea0  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddeea9  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddeeb2  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddeebb  sub rsp, 0x30
00007d2ed8ddeebf  movaps [rsp], xmm4
00007d2ed8ddeec3  movaps [rsp+0x10], xmm2
00007d2ed8ddeec8  movaps [rsp+0x20], xmm9
00007d2ed8ddeece  lea rdi, [rsp]
00007d2ed8ddeed2  mov esi, 0x00
00007d2ed8ddeed7  mov rax, 0x648718324530
00007d2ed8ddeee1  call rax
00007d2ed8ddeee3  movaps xmm4, [rsp]
00007d2ed8ddeee7  add rsp, 0x30
00007d2ed8ddeeeb  vmovaps xmm0, [rsp]
00007d2ed8ddeef0  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddeef6  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddeefc  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddef02  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddef08  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddef0e  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddef14  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddef1a  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddef23  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddef2c  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddef35  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddef3e  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddef47  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddef50  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddef59  add rsp, 0xF0
00007d2ed8ddef60  pop r11
00007d2ed8ddef62  pop r10
00007d2ed8ddef64  pop r9
00007d2ed8ddef66  pop r8
00007d2ed8ddef68  pop rsi
00007d2ed8ddef69  pop rdi
00007d2ed8ddef6a  pop rdx
00007d2ed8ddef6b  pop rcx
00007d2ed8ddef6c  pop rax
00007d2ed8ddef6d  add rsp, 0x08
00007d2ed8ddef71  jmp 0x00007D2ED8DDC31E
00007d2ed8ddef76  sub rsp, 0x08
00007d2ed8ddef7a  push rax
00007d2ed8ddef7b  push rcx
00007d2ed8ddef7c  push rdx
00007d2ed8ddef7d  push rdi
00007d2ed8ddef7e  push rsi
00007d2ed8ddef7f  push r8
00007d2ed8ddef81  push r9
00007d2ed8ddef83  push r10
00007d2ed8ddef85  push r11
00007d2ed8ddef87  sub rsp, 0xF0
00007d2ed8ddef8e  vmovaps [rsp], xmm0
00007d2ed8ddef93  vmovaps [rsp+0x10], xmm1
00007d2ed8ddef99  vmovaps [rsp+0x20], xmm2
00007d2ed8ddef9f  vmovaps [rsp+0x30], xmm3
00007d2ed8ddefa5  vmovaps [rsp+0x40], xmm4
00007d2ed8ddefab  vmovaps [rsp+0x50], xmm5
00007d2ed8ddefb1  vmovaps [rsp+0x60], xmm6
00007d2ed8ddefb7  vmovaps [rsp+0x70], xmm7
00007d2ed8ddefbd  vmovaps [rsp+0x80], xmm8
00007d2ed8ddefc6  vmovaps [rsp+0x90], xmm10
00007d2ed8ddefcf  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddefd8  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddefe1  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddefea  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddeff3  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddeffc  sub rsp, 0x30
00007d2ed8ddf000  movaps [rsp], xmm9
00007d2ed8ddf005  movaps [rsp+0x10], xmm2
00007d2ed8ddf00a  movaps [rsp+0x20], xmm1
00007d2ed8ddf00f  lea rdi, [rsp]
00007d2ed8ddf013  mov esi, 0x00
00007d2ed8ddf018  mov rax, 0x648718324530
00007d2ed8ddf022  call rax
00007d2ed8ddf024  movaps xmm9, [rsp]
00007d2ed8ddf029  add rsp, 0x30
00007d2ed8ddf02d  vmovaps xmm0, [rsp]
00007d2ed8ddf032  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddf038  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddf03e  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddf044  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddf04a  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddf050  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddf056  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddf05c  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddf065  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddf06e  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddf077  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddf080  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddf089  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddf092  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddf09b  add rsp, 0xF0
00007d2ed8ddf0a2  pop r11
00007d2ed8ddf0a4  pop r10
00007d2ed8ddf0a6  pop r9
00007d2ed8ddf0a8  pop r8
00007d2ed8ddf0aa  pop rsi
00007d2ed8ddf0ab  pop rdi
00007d2ed8ddf0ac  pop rdx
00007d2ed8ddf0ad  pop rcx
00007d2ed8ddf0ae  pop rax
00007d2ed8ddf0af  add rsp, 0x08
00007d2ed8ddf0b3  jmp 0x00007D2ED8DDC354
00007d2ed8ddf0b8  sub rsp, 0x08
00007d2ed8ddf0bc  push rax
00007d2ed8ddf0bd  push rcx
00007d2ed8ddf0be  push rdx
00007d2ed8ddf0bf  push rdi
00007d2ed8ddf0c0  push rsi
00007d2ed8ddf0c1  push r8
00007d2ed8ddf0c3  push r9
00007d2ed8ddf0c5  push r10
00007d2ed8ddf0c7  push r11
00007d2ed8ddf0c9  sub rsp, 0xF0
00007d2ed8ddf0d0  vmovaps [rsp], xmm0
00007d2ed8ddf0d5  vmovaps [rsp+0x10], xmm2
00007d2ed8ddf0db  vmovaps [rsp+0x20], xmm3
00007d2ed8ddf0e1  vmovaps [rsp+0x30], xmm4
00007d2ed8ddf0e7  vmovaps [rsp+0x40], xmm5
00007d2ed8ddf0ed  vmovaps [rsp+0x50], xmm6
00007d2ed8ddf0f3  vmovaps [rsp+0x60], xmm7
00007d2ed8ddf0f9  vmovaps [rsp+0x70], xmm8
00007d2ed8ddf0ff  vmovaps [rsp+0x80], xmm9
00007d2ed8ddf108  vmovaps [rsp+0x90], xmm10
00007d2ed8ddf111  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddf11a  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddf123  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddf12c  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddf135  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddf13e  sub rsp, 0x30
00007d2ed8ddf142  movaps [rsp], xmm1
00007d2ed8ddf146  movaps [rsp+0x10], xmm15
00007d2ed8ddf14c  movaps [rsp+0x20], xmm6
00007d2ed8ddf151  lea rdi, [rsp]
00007d2ed8ddf155  mov esi, 0x00
00007d2ed8ddf15a  mov rax, 0x648718324530
00007d2ed8ddf164  call rax
00007d2ed8ddf166  movaps xmm1, [rsp]
00007d2ed8ddf16a  add rsp, 0x30
00007d2ed8ddf16e  vmovaps xmm0, [rsp]
00007d2ed8ddf173  vmovaps xmm2, [rsp+0x10]
00007d2ed8ddf179  vmovaps xmm3, [rsp+0x20]
00007d2ed8ddf17f  vmovaps xmm4, [rsp+0x30]
00007d2ed8ddf185  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddf18b  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddf191  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddf197  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddf19d  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddf1a6  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddf1af  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddf1b8  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddf1c1  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddf1ca  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddf1d3  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddf1dc  add rsp, 0xF0
00007d2ed8ddf1e3  pop r11
00007d2ed8ddf1e5  pop r10
00007d2ed8ddf1e7  pop r9
00007d2ed8ddf1e9  pop r8
00007d2ed8ddf1eb  pop rsi
00007d2ed8ddf1ec  pop rdi
00007d2ed8ddf1ed  pop rdx
00007d2ed8ddf1ee  pop rcx
00007d2ed8ddf1ef  pop rax
00007d2ed8ddf1f0  add rsp, 0x08
00007d2ed8ddf1f4  jmp 0x00007D2ED8DDC375
00007d2ed8ddf1f9  sub rsp, 0x08
00007d2ed8ddf1fd  push rax
00007d2ed8ddf1fe  push rcx
00007d2ed8ddf1ff  push rdx
00007d2ed8ddf200  push rdi
00007d2ed8ddf201  push rsi
00007d2ed8ddf202  push r8
00007d2ed8ddf204  push r9
00007d2ed8ddf206  push r10
00007d2ed8ddf208  push r11
00007d2ed8ddf20a  sub rsp, 0xF0
00007d2ed8ddf211  vmovaps [rsp], xmm0
00007d2ed8ddf216  vmovaps [rsp+0x10], xmm1
00007d2ed8ddf21c  vmovaps [rsp+0x20], xmm2
00007d2ed8ddf222  vmovaps [rsp+0x30], xmm3
00007d2ed8ddf228  vmovaps [rsp+0x40], xmm4
00007d2ed8ddf22e  vmovaps [rsp+0x50], xmm5
00007d2ed8ddf234  vmovaps [rsp+0x60], xmm6
00007d2ed8ddf23a  vmovaps [rsp+0x70], xmm7
00007d2ed8ddf240  vmovaps [rsp+0x80], xmm8
00007d2ed8ddf249  vmovaps [rsp+0x90], xmm9
00007d2ed8ddf252  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddf25b  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddf264  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddf26d  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddf276  vmovaps [rsp+0xE0], xmm14
00007d2ed8ddf27f  sub rsp, 0x30
00007d2ed8ddf283  movaps [rsp], xmm15
00007d2ed8ddf288  movaps [rsp+0x10], xmm5
00007d2ed8ddf28d  movaps [rsp+0x20], xmm3
00007d2ed8ddf292  lea rdi, [rsp]
00007d2ed8ddf296  mov esi, 0x00
00007d2ed8ddf29b  mov rax, 0x648718324530
00007d2ed8ddf2a5  call rax
00007d2ed8ddf2a7  movaps xmm15, [rsp]
00007d2ed8ddf2ac  add rsp, 0x30
00007d2ed8ddf2b0  vmovaps xmm0, [rsp]
00007d2ed8ddf2b5  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddf2bb  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddf2c1  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddf2c7  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddf2cd  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddf2d3  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddf2d9  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddf2df  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddf2e8  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddf2f1  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddf2fa  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddf303  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddf30c  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddf315  vmovaps xmm14, [rsp+0xE0]
00007d2ed8ddf31e  add rsp, 0xF0
00007d2ed8ddf325  pop r11
00007d2ed8ddf327  pop r10
00007d2ed8ddf329  pop r9
00007d2ed8ddf32b  pop r8
00007d2ed8ddf32d  pop rsi
00007d2ed8ddf32e  pop rdi
00007d2ed8ddf32f  pop rdx
00007d2ed8ddf330  pop rcx
00007d2ed8ddf331  pop rax
00007d2ed8ddf332  add rsp, 0x08
00007d2ed8ddf336  jmp 0x00007D2ED8DDC38F
00007d2ed8ddf33b  sub rsp, 0x08
00007d2ed8ddf33f  push rax
00007d2ed8ddf340  push rcx
00007d2ed8ddf341  push rdx
00007d2ed8ddf342  push rdi
00007d2ed8ddf343  push rsi
00007d2ed8ddf344  push r8
00007d2ed8ddf346  push r9
00007d2ed8ddf348  push r10
00007d2ed8ddf34a  push r11
00007d2ed8ddf34c  sub rsp, 0xF0
00007d2ed8ddf353  vmovaps [rsp], xmm0
00007d2ed8ddf358  vmovaps [rsp+0x10], xmm1
00007d2ed8ddf35e  vmovaps [rsp+0x20], xmm2
00007d2ed8ddf364  vmovaps [rsp+0x30], xmm3
00007d2ed8ddf36a  vmovaps [rsp+0x40], xmm4
00007d2ed8ddf370  vmovaps [rsp+0x50], xmm6
00007d2ed8ddf376  vmovaps [rsp+0x60], xmm7
00007d2ed8ddf37c  vmovaps [rsp+0x70], xmm8
00007d2ed8ddf382  vmovaps [rsp+0x80], xmm9
00007d2ed8ddf38b  vmovaps [rsp+0x90], xmm10
00007d2ed8ddf394  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddf39d  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddf3a6  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddf3af  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddf3b8  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddf3c1  sub rsp, 0x30
00007d2ed8ddf3c5  movaps [rsp], xmm5
00007d2ed8ddf3c9  movaps [rsp+0x10], xmm8
00007d2ed8ddf3cf  movaps [rsp+0x20], xmm6
00007d2ed8ddf3d4  lea rdi, [rsp]
00007d2ed8ddf3d8  mov esi, 0x00
00007d2ed8ddf3dd  mov rax, 0x648718324530
00007d2ed8ddf3e7  call rax
00007d2ed8ddf3e9  movaps xmm5, [rsp]
00007d2ed8ddf3ed  add rsp, 0x30
00007d2ed8ddf3f1  vmovaps xmm0, [rsp]
00007d2ed8ddf3f6  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddf3fc  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddf402  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddf408  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddf40e  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddf414  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddf41a  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddf420  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddf429  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddf432  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddf43b  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddf444  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddf44d  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddf456  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddf45f  add rsp, 0xF0
00007d2ed8ddf466  pop r11
00007d2ed8ddf468  pop r10
00007d2ed8ddf46a  pop r9
00007d2ed8ddf46c  pop r8
00007d2ed8ddf46e  pop rsi
00007d2ed8ddf46f  pop rdi
00007d2ed8ddf470  pop rdx
00007d2ed8ddf471  pop rcx
00007d2ed8ddf472  pop rax
00007d2ed8ddf473  add rsp, 0x08
00007d2ed8ddf477  jmp 0x00007D2ED8DDC3B3
00007d2ed8ddf47c  sub rsp, 0x08
00007d2ed8ddf480  push rax
00007d2ed8ddf481  push rcx
00007d2ed8ddf482  push rdx
00007d2ed8ddf483  push rdi
00007d2ed8ddf484  push rsi
00007d2ed8ddf485  push r8
00007d2ed8ddf487  push r9
00007d2ed8ddf489  push r10
00007d2ed8ddf48b  push r11
00007d2ed8ddf48d  sub rsp, 0xF0
00007d2ed8ddf494  vmovaps [rsp], xmm0
00007d2ed8ddf499  vmovaps [rsp+0x10], xmm1
00007d2ed8ddf49f  vmovaps [rsp+0x20], xmm2
00007d2ed8ddf4a5  vmovaps [rsp+0x30], xmm3
00007d2ed8ddf4ab  vmovaps [rsp+0x40], xmm4
00007d2ed8ddf4b1  vmovaps [rsp+0x50], xmm5
00007d2ed8ddf4b7  vmovaps [rsp+0x60], xmm7
00007d2ed8ddf4bd  vmovaps [rsp+0x70], xmm8
00007d2ed8ddf4c3  vmovaps [rsp+0x80], xmm9
00007d2ed8ddf4cc  vmovaps [rsp+0x90], xmm10
00007d2ed8ddf4d5  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddf4de  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddf4e7  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddf4f0  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddf4f9  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddf502  sub rsp, 0x30
00007d2ed8ddf506  movaps [rsp], xmm6
00007d2ed8ddf50a  movaps [rsp+0x10], xmm10
00007d2ed8ddf510  movaps [rsp+0x20], xmm8
00007d2ed8ddf516  lea rdi, [rsp]
00007d2ed8ddf51a  mov esi, 0x00
00007d2ed8ddf51f  mov rax, 0x648718324530
00007d2ed8ddf529  call rax
00007d2ed8ddf52b  movaps xmm6, [rsp]
00007d2ed8ddf52f  add rsp, 0x30
00007d2ed8ddf533  vmovaps xmm0, [rsp]
00007d2ed8ddf538  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddf53e  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddf544  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddf54a  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddf550  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddf556  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddf55c  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddf562  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddf56b  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddf574  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddf57d  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddf586  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddf58f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddf598  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddf5a1  add rsp, 0xF0
00007d2ed8ddf5a8  pop r11
00007d2ed8ddf5aa  pop r10
00007d2ed8ddf5ac  pop r9
00007d2ed8ddf5ae  pop r8
00007d2ed8ddf5b0  pop rsi
00007d2ed8ddf5b1  pop rdi
00007d2ed8ddf5b2  pop rdx
00007d2ed8ddf5b3  pop rcx
00007d2ed8ddf5b4  pop rax
00007d2ed8ddf5b5  add rsp, 0x08
00007d2ed8ddf5b9  jmp 0x00007D2ED8DDC3D8
00007d2ed8ddf5be  sub rsp, 0x08
00007d2ed8ddf5c2  push rax
00007d2ed8ddf5c3  push rcx
00007d2ed8ddf5c4  push rdx
00007d2ed8ddf5c5  push rdi
00007d2ed8ddf5c6  push rsi
00007d2ed8ddf5c7  push r8
00007d2ed8ddf5c9  push r9
00007d2ed8ddf5cb  push r10
00007d2ed8ddf5cd  push r11
00007d2ed8ddf5cf  sub rsp, 0xF0
00007d2ed8ddf5d6  vmovaps [rsp], xmm0
00007d2ed8ddf5db  vmovaps [rsp+0x10], xmm1
00007d2ed8ddf5e1  vmovaps [rsp+0x20], xmm2
00007d2ed8ddf5e7  vmovaps [rsp+0x30], xmm3
00007d2ed8ddf5ed  vmovaps [rsp+0x40], xmm4
00007d2ed8ddf5f3  vmovaps [rsp+0x50], xmm5
00007d2ed8ddf5f9  vmovaps [rsp+0x60], xmm6
00007d2ed8ddf5ff  vmovaps [rsp+0x70], xmm7
00007d2ed8ddf605  vmovaps [rsp+0x80], xmm8
00007d2ed8ddf60e  vmovaps [rsp+0x90], xmm9
00007d2ed8ddf617  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddf620  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddf629  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddf632  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddf63b  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddf644  sub rsp, 0x30
00007d2ed8ddf648  movaps [rsp], xmm10
00007d2ed8ddf64d  movaps [rsp+0x10], xmm8
00007d2ed8ddf653  movaps [rsp+0x20], xmm14
00007d2ed8ddf659  lea rdi, [rsp]
00007d2ed8ddf65d  mov esi, 0x00
00007d2ed8ddf662  mov rax, 0x648718324530
00007d2ed8ddf66c  call rax
00007d2ed8ddf66e  movaps xmm10, [rsp]
00007d2ed8ddf673  add rsp, 0x30
00007d2ed8ddf677  vmovaps xmm0, [rsp]
00007d2ed8ddf67c  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddf682  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddf688  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddf68e  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddf694  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddf69a  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddf6a0  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddf6a6  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddf6af  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddf6b8  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddf6c1  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddf6ca  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddf6d3  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddf6dc  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddf6e5  add rsp, 0xF0
00007d2ed8ddf6ec  pop r11
00007d2ed8ddf6ee  pop r10
00007d2ed8ddf6f0  pop r9
00007d2ed8ddf6f2  pop r8
00007d2ed8ddf6f4  pop rsi
00007d2ed8ddf6f5  pop rdi
00007d2ed8ddf6f6  pop rdx
00007d2ed8ddf6f7  pop rcx
00007d2ed8ddf6f8  pop rax
00007d2ed8ddf6f9  add rsp, 0x08
00007d2ed8ddf6fd  jmp 0x00007D2ED8DDC3F8
00007d2ed8ddf702  sub rsp, 0x08
00007d2ed8ddf706  push rax
00007d2ed8ddf707  push rcx
00007d2ed8ddf708  push rdx
00007d2ed8ddf709  push rdi
00007d2ed8ddf70a  push rsi
00007d2ed8ddf70b  push r8
00007d2ed8ddf70d  push r9
00007d2ed8ddf70f  push r10
00007d2ed8ddf711  push r11
00007d2ed8ddf713  sub rsp, 0xF0
00007d2ed8ddf71a  vmovaps [rsp], xmm0
00007d2ed8ddf71f  vmovaps [rsp+0x10], xmm1
00007d2ed8ddf725  vmovaps [rsp+0x20], xmm2
00007d2ed8ddf72b  vmovaps [rsp+0x30], xmm3
00007d2ed8ddf731  vmovaps [rsp+0x40], xmm4
00007d2ed8ddf737  vmovaps [rsp+0x50], xmm5
00007d2ed8ddf73d  vmovaps [rsp+0x60], xmm6
00007d2ed8ddf743  vmovaps [rsp+0x70], xmm7
00007d2ed8ddf749  vmovaps [rsp+0x80], xmm8
00007d2ed8ddf752  vmovaps [rsp+0x90], xmm9
00007d2ed8ddf75b  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddf764  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddf76d  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddf776  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddf77f  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddf788  sub rsp, 0x30
00007d2ed8ddf78c  movaps [rsp], xmm14
00007d2ed8ddf791  movaps [rsp+0x10], xmm8
00007d2ed8ddf797  movaps [rsp+0x20], xmm4
00007d2ed8ddf79c  lea rdi, [rsp]
00007d2ed8ddf7a0  mov esi, 0x00
00007d2ed8ddf7a5  mov rax, 0x648718324530
00007d2ed8ddf7af  call rax
00007d2ed8ddf7b1  movaps xmm14, [rsp]
00007d2ed8ddf7b6  add rsp, 0x30
00007d2ed8ddf7ba  vmovaps xmm0, [rsp]
00007d2ed8ddf7bf  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddf7c5  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddf7cb  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddf7d1  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddf7d7  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddf7dd  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddf7e3  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddf7e9  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddf7f2  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddf7fb  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddf804  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddf80d  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddf816  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddf81f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddf828  add rsp, 0xF0
00007d2ed8ddf82f  pop r11
00007d2ed8ddf831  pop r10
00007d2ed8ddf833  pop r9
00007d2ed8ddf835  pop r8
00007d2ed8ddf837  pop rsi
00007d2ed8ddf838  pop rdi
00007d2ed8ddf839  pop rdx
00007d2ed8ddf83a  pop rcx
00007d2ed8ddf83b  pop rax
00007d2ed8ddf83c  add rsp, 0x08
00007d2ed8ddf840  jmp 0x00007D2ED8DDC418
00007d2ed8ddf845  sub rsp, 0x08
00007d2ed8ddf849  push rax
00007d2ed8ddf84a  push rcx
00007d2ed8ddf84b  push rdx
00007d2ed8ddf84c  push rdi
00007d2ed8ddf84d  push rsi
00007d2ed8ddf84e  push r8
00007d2ed8ddf850  push r9
00007d2ed8ddf852  push r10
00007d2ed8ddf854  push r11
00007d2ed8ddf856  sub rsp, 0xF0
00007d2ed8ddf85d  vmovaps [rsp], xmm0
00007d2ed8ddf862  vmovaps [rsp+0x10], xmm1
00007d2ed8ddf868  vmovaps [rsp+0x20], xmm2
00007d2ed8ddf86e  vmovaps [rsp+0x30], xmm3
00007d2ed8ddf874  vmovaps [rsp+0x40], xmm5
00007d2ed8ddf87a  vmovaps [rsp+0x50], xmm6
00007d2ed8ddf880  vmovaps [rsp+0x60], xmm7
00007d2ed8ddf886  vmovaps [rsp+0x70], xmm8
00007d2ed8ddf88c  vmovaps [rsp+0x80], xmm9
00007d2ed8ddf895  vmovaps [rsp+0x90], xmm10
00007d2ed8ddf89e  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddf8a7  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddf8b0  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddf8b9  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddf8c2  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddf8cb  sub rsp, 0x30
00007d2ed8ddf8cf  movaps [rsp], xmm4
00007d2ed8ddf8d3  movaps [rsp+0x10], xmm13
00007d2ed8ddf8d9  movaps [rsp+0x20], xmm8
00007d2ed8ddf8df  lea rdi, [rsp]
00007d2ed8ddf8e3  mov esi, 0x00
00007d2ed8ddf8e8  mov rax, 0x648718324530
00007d2ed8ddf8f2  call rax
00007d2ed8ddf8f4  movaps xmm4, [rsp]
00007d2ed8ddf8f8  add rsp, 0x30
00007d2ed8ddf8fc  vmovaps xmm0, [rsp]
00007d2ed8ddf901  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddf907  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddf90d  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddf913  vmovaps xmm5, [rsp+0x40]
00007d2ed8ddf919  vmovaps xmm6, [rsp+0x50]
00007d2ed8ddf91f  vmovaps xmm7, [rsp+0x60]
00007d2ed8ddf925  vmovaps xmm8, [rsp+0x70]
00007d2ed8ddf92b  vmovaps xmm9, [rsp+0x80]
00007d2ed8ddf934  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddf93d  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddf946  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddf94f  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddf958  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddf961  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddf96a  add rsp, 0xF0
00007d2ed8ddf971  pop r11
00007d2ed8ddf973  pop r10
00007d2ed8ddf975  pop r9
00007d2ed8ddf977  pop r8
00007d2ed8ddf979  pop rsi
00007d2ed8ddf97a  pop rdi
00007d2ed8ddf97b  pop rdx
00007d2ed8ddf97c  pop rcx
00007d2ed8ddf97d  pop rax
00007d2ed8ddf97e  add rsp, 0x08
00007d2ed8ddf982  jmp 0x00007D2ED8DDC43D
00007d2ed8ddf987  sub rsp, 0x08
00007d2ed8ddf98b  push rax
00007d2ed8ddf98c  push rcx
00007d2ed8ddf98d  push rdx
00007d2ed8ddf98e  push rdi
00007d2ed8ddf98f  push rsi
00007d2ed8ddf990  push r8
00007d2ed8ddf992  push r9
00007d2ed8ddf994  push r10
00007d2ed8ddf996  push r11
00007d2ed8ddf998  sub rsp, 0xF0
00007d2ed8ddf99f  vmovaps [rsp], xmm0
00007d2ed8ddf9a4  vmovaps [rsp+0x10], xmm1
00007d2ed8ddf9aa  vmovaps [rsp+0x20], xmm2
00007d2ed8ddf9b0  vmovaps [rsp+0x30], xmm3
00007d2ed8ddf9b6  vmovaps [rsp+0x40], xmm4
00007d2ed8ddf9bc  vmovaps [rsp+0x50], xmm5
00007d2ed8ddf9c2  vmovaps [rsp+0x60], xmm6
00007d2ed8ddf9c8  vmovaps [rsp+0x70], xmm7
00007d2ed8ddf9ce  vmovaps [rsp+0x80], xmm8
00007d2ed8ddf9d7  vmovaps [rsp+0x90], xmm9
00007d2ed8ddf9e0  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddf9e9  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddf9f2  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddf9fb  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddfa04  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddfa0d  sub rsp, 0x30
00007d2ed8ddfa11  movaps [rsp], xmm13
00007d2ed8ddfa16  movaps [rsp+0x10], xmm15
00007d2ed8ddfa1c  movaps [rsp+0x20], xmm9
00007d2ed8ddfa22  lea rdi, [rsp]
00007d2ed8ddfa26  mov esi, 0x00
00007d2ed8ddfa2b  mov rax, 0x648718324530
00007d2ed8ddfa35  call rax
00007d2ed8ddfa37  movaps xmm13, [rsp]
00007d2ed8ddfa3c  add rsp, 0x30
00007d2ed8ddfa40  vmovaps xmm0, [rsp]
00007d2ed8ddfa45  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddfa4b  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddfa51  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddfa57  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddfa5d  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddfa63  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddfa69  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddfa6f  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddfa78  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddfa81  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddfa8a  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddfa93  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddfa9c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddfaa5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddfaae  add rsp, 0xF0
00007d2ed8ddfab5  pop r11
00007d2ed8ddfab7  pop r10
00007d2ed8ddfab9  pop r9
00007d2ed8ddfabb  pop r8
00007d2ed8ddfabd  pop rsi
00007d2ed8ddfabe  pop rdi
00007d2ed8ddfabf  pop rdx
00007d2ed8ddfac0  pop rcx
00007d2ed8ddfac1  pop rax
00007d2ed8ddfac2  add rsp, 0x08
00007d2ed8ddfac6  jmp 0x00007D2ED8DDC458
00007d2ed8ddfacb  sub rsp, 0x08
00007d2ed8ddfacf  push rax
00007d2ed8ddfad0  push rcx
00007d2ed8ddfad1  push rdx
00007d2ed8ddfad2  push rdi
00007d2ed8ddfad3  push rsi
00007d2ed8ddfad4  push r8
00007d2ed8ddfad6  push r9
00007d2ed8ddfad8  push r10
00007d2ed8ddfada  push r11
00007d2ed8ddfadc  sub rsp, 0xF0
00007d2ed8ddfae3  vmovaps [rsp], xmm0
00007d2ed8ddfae8  vmovaps [rsp+0x10], xmm1
00007d2ed8ddfaee  vmovaps [rsp+0x20], xmm2
00007d2ed8ddfaf4  vmovaps [rsp+0x30], xmm3
00007d2ed8ddfafa  vmovaps [rsp+0x40], xmm4
00007d2ed8ddfb00  vmovaps [rsp+0x50], xmm5
00007d2ed8ddfb06  vmovaps [rsp+0x60], xmm6
00007d2ed8ddfb0c  vmovaps [rsp+0x70], xmm7
00007d2ed8ddfb12  vmovaps [rsp+0x80], xmm8
00007d2ed8ddfb1b  vmovaps [rsp+0x90], xmm9
00007d2ed8ddfb24  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddfb2d  vmovaps [rsp+0xB0], xmm11
00007d2ed8ddfb36  vmovaps [rsp+0xC0], xmm12
00007d2ed8ddfb3f  vmovaps [rsp+0xD0], xmm13
00007d2ed8ddfb48  vmovaps [rsp+0xE0], xmm14
00007d2ed8ddfb51  sub rsp, 0x30
00007d2ed8ddfb55  movaps [rsp], xmm15
00007d2ed8ddfb5a  movaps [rsp+0x10], xmm1
00007d2ed8ddfb5f  movaps [rsp+0x20], xmm5
00007d2ed8ddfb64  lea rdi, [rsp]
00007d2ed8ddfb68  mov esi, 0x00
00007d2ed8ddfb6d  mov rax, 0x648718324530
00007d2ed8ddfb77  call rax
00007d2ed8ddfb79  movaps xmm15, [rsp]
00007d2ed8ddfb7e  add rsp, 0x30
00007d2ed8ddfb82  vmovaps xmm0, [rsp]
00007d2ed8ddfb87  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddfb8d  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddfb93  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddfb99  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddfb9f  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddfba5  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddfbab  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddfbb1  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddfbba  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddfbc3  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddfbcc  vmovaps xmm11, [rsp+0xB0]
00007d2ed8ddfbd5  vmovaps xmm12, [rsp+0xC0]
00007d2ed8ddfbde  vmovaps xmm13, [rsp+0xD0]
00007d2ed8ddfbe7  vmovaps xmm14, [rsp+0xE0]
00007d2ed8ddfbf0  add rsp, 0xF0
00007d2ed8ddfbf7  pop r11
00007d2ed8ddfbf9  pop r10
00007d2ed8ddfbfb  pop r9
00007d2ed8ddfbfd  pop r8
00007d2ed8ddfbff  pop rsi
00007d2ed8ddfc00  pop rdi
00007d2ed8ddfc01  pop rdx
00007d2ed8ddfc02  pop rcx
00007d2ed8ddfc03  pop rax
00007d2ed8ddfc04  add rsp, 0x08
00007d2ed8ddfc08  jmp 0x00007D2ED8DDC473
00007d2ed8ddfc0d  call 0x00007D2ED8CB52F0
00007d2ed8ddfc12  jmp 0x00007D2ED8DDC4CE
00007d2ed8ddfc17  sub rsp, 0x08
00007d2ed8ddfc1b  push rax
00007d2ed8ddfc1c  push rcx
00007d2ed8ddfc1d  push rdx
00007d2ed8ddfc1e  push rdi
00007d2ed8ddfc1f  push rsi
00007d2ed8ddfc20  push r8
00007d2ed8ddfc22  push r9
00007d2ed8ddfc24  push r10
00007d2ed8ddfc26  push r11
00007d2ed8ddfc28  sub rsp, 0xF0
00007d2ed8ddfc2f  vmovaps [rsp], xmm0
00007d2ed8ddfc34  vmovaps [rsp+0x10], xmm1
00007d2ed8ddfc3a  vmovaps [rsp+0x20], xmm2
00007d2ed8ddfc40  vmovaps [rsp+0x30], xmm3
00007d2ed8ddfc46  vmovaps [rsp+0x40], xmm4
00007d2ed8ddfc4c  vmovaps [rsp+0x50], xmm5
00007d2ed8ddfc52  vmovaps [rsp+0x60], xmm6
00007d2ed8ddfc58  vmovaps [rsp+0x70], xmm7
00007d2ed8ddfc5e  vmovaps [rsp+0x80], xmm8
00007d2ed8ddfc67  vmovaps [rsp+0x90], xmm10
00007d2ed8ddfc70  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddfc79  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddfc82  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddfc8b  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddfc94  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddfc9d  sub rsp, 0x30
00007d2ed8ddfca1  movaps [rsp], xmm9
00007d2ed8ddfca6  movaps [rsp+0x10], xmm8
00007d2ed8ddfcac  movaps [rsp+0x20], xmm11
00007d2ed8ddfcb2  lea rdi, [rsp]
00007d2ed8ddfcb6  mov esi, 0x00
00007d2ed8ddfcbb  mov rax, 0x648718324530
00007d2ed8ddfcc5  call rax
00007d2ed8ddfcc7  movaps xmm9, [rsp]
00007d2ed8ddfccc  add rsp, 0x30
00007d2ed8ddfcd0  vmovaps xmm0, [rsp]
00007d2ed8ddfcd5  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddfcdb  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddfce1  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddfce7  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddfced  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddfcf3  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddfcf9  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddfcff  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddfd08  vmovaps xmm10, [rsp+0x90]
00007d2ed8ddfd11  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddfd1a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddfd23  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddfd2c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddfd35  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddfd3e  add rsp, 0xF0
00007d2ed8ddfd45  pop r11
00007d2ed8ddfd47  pop r10
00007d2ed8ddfd49  pop r9
00007d2ed8ddfd4b  pop r8
00007d2ed8ddfd4d  pop rsi
00007d2ed8ddfd4e  pop rdi
00007d2ed8ddfd4f  pop rdx
00007d2ed8ddfd50  pop rcx
00007d2ed8ddfd51  pop rax
00007d2ed8ddfd52  add rsp, 0x08
00007d2ed8ddfd56  jmp 0x00007D2ED8DDC505
00007d2ed8ddfd5b  sub rsp, 0x08
00007d2ed8ddfd5f  push rax
00007d2ed8ddfd60  push rcx
00007d2ed8ddfd61  push rdx
00007d2ed8ddfd62  push rdi
00007d2ed8ddfd63  push rsi
00007d2ed8ddfd64  push r8
00007d2ed8ddfd66  push r9
00007d2ed8ddfd68  push r10
00007d2ed8ddfd6a  push r11
00007d2ed8ddfd6c  sub rsp, 0xF0
00007d2ed8ddfd73  vmovaps [rsp], xmm0
00007d2ed8ddfd78  vmovaps [rsp+0x10], xmm1
00007d2ed8ddfd7e  vmovaps [rsp+0x20], xmm2
00007d2ed8ddfd84  vmovaps [rsp+0x30], xmm3
00007d2ed8ddfd8a  vmovaps [rsp+0x40], xmm4
00007d2ed8ddfd90  vmovaps [rsp+0x50], xmm5
00007d2ed8ddfd96  vmovaps [rsp+0x60], xmm6
00007d2ed8ddfd9c  vmovaps [rsp+0x70], xmm7
00007d2ed8ddfda2  vmovaps [rsp+0x80], xmm8
00007d2ed8ddfdab  vmovaps [rsp+0x90], xmm9
00007d2ed8ddfdb4  vmovaps [rsp+0xA0], xmm10
00007d2ed8ddfdbd  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddfdc6  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddfdcf  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddfdd8  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddfde1  sub rsp, 0x30
00007d2ed8ddfde5  movaps [rsp], xmm11
00007d2ed8ddfdea  movaps [rsp+0x10], xmm10
00007d2ed8ddfdf0  movaps [rsp+0x20], xmm6
00007d2ed8ddfdf5  lea rdi, [rsp]
00007d2ed8ddfdf9  mov esi, 0x00
00007d2ed8ddfdfe  mov rax, 0x648718324530
00007d2ed8ddfe08  call rax
00007d2ed8ddfe0a  movaps xmm11, [rsp]
00007d2ed8ddfe0f  add rsp, 0x30
00007d2ed8ddfe13  vmovaps xmm0, [rsp]
00007d2ed8ddfe18  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddfe1e  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddfe24  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddfe2a  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddfe30  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddfe36  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddfe3c  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddfe42  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddfe4b  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddfe54  vmovaps xmm10, [rsp+0xA0]
00007d2ed8ddfe5d  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddfe66  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddfe6f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddfe78  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddfe81  add rsp, 0xF0
00007d2ed8ddfe88  pop r11
00007d2ed8ddfe8a  pop r10
00007d2ed8ddfe8c  pop r9
00007d2ed8ddfe8e  pop r8
00007d2ed8ddfe90  pop rsi
00007d2ed8ddfe91  pop rdi
00007d2ed8ddfe92  pop rdx
00007d2ed8ddfe93  pop rcx
00007d2ed8ddfe94  pop rax
00007d2ed8ddfe95  add rsp, 0x08
00007d2ed8ddfe99  jmp 0x00007D2ED8DDC520
00007d2ed8ddfe9e  sub rsp, 0x08
00007d2ed8ddfea2  push rax
00007d2ed8ddfea3  push rcx
00007d2ed8ddfea4  push rdx
00007d2ed8ddfea5  push rdi
00007d2ed8ddfea6  push rsi
00007d2ed8ddfea7  push r8
00007d2ed8ddfea9  push r9
00007d2ed8ddfeab  push r10
00007d2ed8ddfead  push r11
00007d2ed8ddfeaf  sub rsp, 0xF0
00007d2ed8ddfeb6  vmovaps [rsp], xmm0
00007d2ed8ddfebb  vmovaps [rsp+0x10], xmm1
00007d2ed8ddfec1  vmovaps [rsp+0x20], xmm2
00007d2ed8ddfec7  vmovaps [rsp+0x30], xmm3
00007d2ed8ddfecd  vmovaps [rsp+0x40], xmm4
00007d2ed8ddfed3  vmovaps [rsp+0x50], xmm5
00007d2ed8ddfed9  vmovaps [rsp+0x60], xmm6
00007d2ed8ddfedf  vmovaps [rsp+0x70], xmm7
00007d2ed8ddfee5  vmovaps [rsp+0x80], xmm8
00007d2ed8ddfeee  vmovaps [rsp+0x90], xmm9
00007d2ed8ddfef7  vmovaps [rsp+0xA0], xmm11
00007d2ed8ddff00  vmovaps [rsp+0xB0], xmm12
00007d2ed8ddff09  vmovaps [rsp+0xC0], xmm13
00007d2ed8ddff12  vmovaps [rsp+0xD0], xmm14
00007d2ed8ddff1b  vmovaps [rsp+0xE0], xmm15
00007d2ed8ddff24  sub rsp, 0x30
00007d2ed8ddff28  movaps [rsp], xmm10
00007d2ed8ddff2d  movaps [rsp+0x10], xmm14
00007d2ed8ddff33  movaps [rsp+0x20], xmm4
00007d2ed8ddff38  lea rdi, [rsp]
00007d2ed8ddff3c  mov esi, 0x00
00007d2ed8ddff41  mov rax, 0x648718324530
00007d2ed8ddff4b  call rax
00007d2ed8ddff4d  movaps xmm10, [rsp]
00007d2ed8ddff52  add rsp, 0x30
00007d2ed8ddff56  vmovaps xmm0, [rsp]
00007d2ed8ddff5b  vmovaps xmm1, [rsp+0x10]
00007d2ed8ddff61  vmovaps xmm2, [rsp+0x20]
00007d2ed8ddff67  vmovaps xmm3, [rsp+0x30]
00007d2ed8ddff6d  vmovaps xmm4, [rsp+0x40]
00007d2ed8ddff73  vmovaps xmm5, [rsp+0x50]
00007d2ed8ddff79  vmovaps xmm6, [rsp+0x60]
00007d2ed8ddff7f  vmovaps xmm7, [rsp+0x70]
00007d2ed8ddff85  vmovaps xmm8, [rsp+0x80]
00007d2ed8ddff8e  vmovaps xmm9, [rsp+0x90]
00007d2ed8ddff97  vmovaps xmm11, [rsp+0xA0]
00007d2ed8ddffa0  vmovaps xmm12, [rsp+0xB0]
00007d2ed8ddffa9  vmovaps xmm13, [rsp+0xC0]
00007d2ed8ddffb2  vmovaps xmm14, [rsp+0xD0]
00007d2ed8ddffbb  vmovaps xmm15, [rsp+0xE0]
00007d2ed8ddffc4  add rsp, 0xF0
00007d2ed8ddffcb  pop r11
00007d2ed8ddffcd  pop r10
00007d2ed8ddffcf  pop r9
00007d2ed8ddffd1  pop r8
00007d2ed8ddffd3  pop rsi
00007d2ed8ddffd4  pop rdi
00007d2ed8ddffd5  pop rdx
00007d2ed8ddffd6  pop rcx
00007d2ed8ddffd7  pop rax
00007d2ed8ddffd8  add rsp, 0x08
00007d2ed8ddffdc  jmp 0x00007D2ED8DDC53B
00007d2ed8ddffe1  sub rsp, 0x08
00007d2ed8ddffe5  push rax
00007d2ed8ddffe6  push rcx
00007d2ed8ddffe7  push rdx
00007d2ed8ddffe8  push rdi
00007d2ed8ddffe9  push rsi
00007d2ed8ddffea  push r8
00007d2ed8ddffec  push r9
00007d2ed8ddffee  push r10
00007d2ed8ddfff0  push r11
00007d2ed8ddfff2  sub rsp, 0xF0
00007d2ed8ddfff9  vmovaps [rsp], xmm0
00007d2ed8ddfffe  vmovaps [rsp+0x10], xmm1
00007d2ed8de0004  vmovaps [rsp+0x20], xmm2
00007d2ed8de000a  vmovaps [rsp+0x30], xmm3
00007d2ed8de0010  vmovaps [rsp+0x40], xmm4
00007d2ed8de0016  vmovaps [rsp+0x50], xmm5
00007d2ed8de001c  vmovaps [rsp+0x60], xmm6
00007d2ed8de0022  vmovaps [rsp+0x70], xmm7
00007d2ed8de0028  vmovaps [rsp+0x80], xmm9
00007d2ed8de0031  vmovaps [rsp+0x90], xmm10
00007d2ed8de003a  vmovaps [rsp+0xA0], xmm11
00007d2ed8de0043  vmovaps [rsp+0xB0], xmm12
00007d2ed8de004c  vmovaps [rsp+0xC0], xmm13
00007d2ed8de0055  vmovaps [rsp+0xD0], xmm14
00007d2ed8de005e  vmovaps [rsp+0xE0], xmm15
00007d2ed8de0067  sub rsp, 0x30
00007d2ed8de006b  movaps [rsp], xmm8
00007d2ed8de0070  movaps [rsp+0x10], xmm1
00007d2ed8de0075  movaps [rsp+0x20], xmm14
00007d2ed8de007b  lea rdi, [rsp]
00007d2ed8de007f  mov esi, 0x00
00007d2ed8de0084  mov rax, 0x648718324530
00007d2ed8de008e  call rax
00007d2ed8de0090  movaps xmm8, [rsp]
00007d2ed8de0095  add rsp, 0x30
00007d2ed8de0099  vmovaps xmm0, [rsp]
00007d2ed8de009e  vmovaps xmm1, [rsp+0x10]
00007d2ed8de00a4  vmovaps xmm2, [rsp+0x20]
00007d2ed8de00aa  vmovaps xmm3, [rsp+0x30]
00007d2ed8de00b0  vmovaps xmm4, [rsp+0x40]
00007d2ed8de00b6  vmovaps xmm5, [rsp+0x50]
00007d2ed8de00bc  vmovaps xmm6, [rsp+0x60]
00007d2ed8de00c2  vmovaps xmm7, [rsp+0x70]
00007d2ed8de00c8  vmovaps xmm9, [rsp+0x80]
00007d2ed8de00d1  vmovaps xmm10, [rsp+0x90]
00007d2ed8de00da  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de00e3  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de00ec  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de00f5  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de00fe  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0107  add rsp, 0xF0
00007d2ed8de010e  pop r11
00007d2ed8de0110  pop r10
00007d2ed8de0112  pop r9
00007d2ed8de0114  pop r8
00007d2ed8de0116  pop rsi
00007d2ed8de0117  pop rdi
00007d2ed8de0118  pop rdx
00007d2ed8de0119  pop rcx
00007d2ed8de011a  pop rax
00007d2ed8de011b  add rsp, 0x08
00007d2ed8de011f  jmp 0x00007D2ED8DDC561
00007d2ed8de0124  sub rsp, 0x08
00007d2ed8de0128  push rax
00007d2ed8de0129  push rcx
00007d2ed8de012a  push rdx
00007d2ed8de012b  push rdi
00007d2ed8de012c  push rsi
00007d2ed8de012d  push r8
00007d2ed8de012f  push r9
00007d2ed8de0131  push r10
00007d2ed8de0133  push r11
00007d2ed8de0135  sub rsp, 0xF0
00007d2ed8de013c  vmovaps [rsp], xmm0
00007d2ed8de0141  vmovaps [rsp+0x10], xmm1
00007d2ed8de0147  vmovaps [rsp+0x20], xmm2
00007d2ed8de014d  vmovaps [rsp+0x30], xmm3
00007d2ed8de0153  vmovaps [rsp+0x40], xmm4
00007d2ed8de0159  vmovaps [rsp+0x50], xmm5
00007d2ed8de015f  vmovaps [rsp+0x60], xmm7
00007d2ed8de0165  vmovaps [rsp+0x70], xmm8
00007d2ed8de016b  vmovaps [rsp+0x80], xmm9
00007d2ed8de0174  vmovaps [rsp+0x90], xmm10
00007d2ed8de017d  vmovaps [rsp+0xA0], xmm11
00007d2ed8de0186  vmovaps [rsp+0xB0], xmm12
00007d2ed8de018f  vmovaps [rsp+0xC0], xmm13
00007d2ed8de0198  vmovaps [rsp+0xD0], xmm14
00007d2ed8de01a1  vmovaps [rsp+0xE0], xmm15
00007d2ed8de01aa  sub rsp, 0x30
00007d2ed8de01ae  movaps [rsp], xmm6
00007d2ed8de01b2  movaps [rsp+0x10], xmm1
00007d2ed8de01b7  movaps [rsp+0x20], xmm14
00007d2ed8de01bd  lea rdi, [rsp]
00007d2ed8de01c1  mov esi, 0x00
00007d2ed8de01c6  mov rax, 0x648718324530
00007d2ed8de01d0  call rax
00007d2ed8de01d2  movaps xmm6, [rsp]
00007d2ed8de01d6  add rsp, 0x30
00007d2ed8de01da  vmovaps xmm0, [rsp]
00007d2ed8de01df  vmovaps xmm1, [rsp+0x10]
00007d2ed8de01e5  vmovaps xmm2, [rsp+0x20]
00007d2ed8de01eb  vmovaps xmm3, [rsp+0x30]
00007d2ed8de01f1  vmovaps xmm4, [rsp+0x40]
00007d2ed8de01f7  vmovaps xmm5, [rsp+0x50]
00007d2ed8de01fd  vmovaps xmm7, [rsp+0x60]
00007d2ed8de0203  vmovaps xmm8, [rsp+0x70]
00007d2ed8de0209  vmovaps xmm9, [rsp+0x80]
00007d2ed8de0212  vmovaps xmm10, [rsp+0x90]
00007d2ed8de021b  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de0224  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de022d  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de0236  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de023f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0248  add rsp, 0xF0
00007d2ed8de024f  pop r11
00007d2ed8de0251  pop r10
00007d2ed8de0253  pop r9
00007d2ed8de0255  pop r8
00007d2ed8de0257  pop rsi
00007d2ed8de0258  pop rdi
00007d2ed8de0259  pop rdx
00007d2ed8de025a  pop rcx
00007d2ed8de025b  pop rax
00007d2ed8de025c  add rsp, 0x08
00007d2ed8de0260  jmp 0x00007D2ED8DDC58D
00007d2ed8de0265  sub rsp, 0x08
00007d2ed8de0269  push rax
00007d2ed8de026a  push rcx
00007d2ed8de026b  push rdx
00007d2ed8de026c  push rdi
00007d2ed8de026d  push rsi
00007d2ed8de026e  push r8
00007d2ed8de0270  push r9
00007d2ed8de0272  push r10
00007d2ed8de0274  push r11
00007d2ed8de0276  sub rsp, 0xF0
00007d2ed8de027d  vmovaps [rsp], xmm0
00007d2ed8de0282  vmovaps [rsp+0x10], xmm1
00007d2ed8de0288  vmovaps [rsp+0x20], xmm2
00007d2ed8de028e  vmovaps [rsp+0x30], xmm3
00007d2ed8de0294  vmovaps [rsp+0x40], xmm4
00007d2ed8de029a  vmovaps [rsp+0x50], xmm5
00007d2ed8de02a0  vmovaps [rsp+0x60], xmm6
00007d2ed8de02a6  vmovaps [rsp+0x70], xmm7
00007d2ed8de02ac  vmovaps [rsp+0x80], xmm8
00007d2ed8de02b5  vmovaps [rsp+0x90], xmm9
00007d2ed8de02be  vmovaps [rsp+0xA0], xmm10
00007d2ed8de02c7  vmovaps [rsp+0xB0], xmm11
00007d2ed8de02d0  vmovaps [rsp+0xC0], xmm12
00007d2ed8de02d9  vmovaps [rsp+0xD0], xmm13
00007d2ed8de02e2  vmovaps [rsp+0xE0], xmm15
00007d2ed8de02eb  sub rsp, 0x30
00007d2ed8de02ef  movaps [rsp], xmm14
00007d2ed8de02f4  movaps [rsp+0x10], xmm12
00007d2ed8de02fa  movaps [rsp+0x20], xmm1
00007d2ed8de02ff  lea rdi, [rsp]
00007d2ed8de0303  mov esi, 0x00
00007d2ed8de0308  mov rax, 0x648718324530
00007d2ed8de0312  call rax
00007d2ed8de0314  movaps xmm14, [rsp]
00007d2ed8de0319  add rsp, 0x30
00007d2ed8de031d  vmovaps xmm0, [rsp]
00007d2ed8de0322  vmovaps xmm1, [rsp+0x10]
00007d2ed8de0328  vmovaps xmm2, [rsp+0x20]
00007d2ed8de032e  vmovaps xmm3, [rsp+0x30]
00007d2ed8de0334  vmovaps xmm4, [rsp+0x40]
00007d2ed8de033a  vmovaps xmm5, [rsp+0x50]
00007d2ed8de0340  vmovaps xmm6, [rsp+0x60]
00007d2ed8de0346  vmovaps xmm7, [rsp+0x70]
00007d2ed8de034c  vmovaps xmm8, [rsp+0x80]
00007d2ed8de0355  vmovaps xmm9, [rsp+0x90]
00007d2ed8de035e  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de0367  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de0370  vmovaps xmm12, [rsp+0xC0]
00007d2ed8de0379  vmovaps xmm13, [rsp+0xD0]
00007d2ed8de0382  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de038b  add rsp, 0xF0
00007d2ed8de0392  pop r11
00007d2ed8de0394  pop r10
00007d2ed8de0396  pop r9
00007d2ed8de0398  pop r8
00007d2ed8de039a  pop rsi
00007d2ed8de039b  pop rdi
00007d2ed8de039c  pop rdx
00007d2ed8de039d  pop rcx
00007d2ed8de039e  pop rax
00007d2ed8de039f  add rsp, 0x08
00007d2ed8de03a3  jmp 0x00007D2ED8DDC5B3
00007d2ed8de03a8  sub rsp, 0x08
00007d2ed8de03ac  push rax
00007d2ed8de03ad  push rcx
00007d2ed8de03ae  push rdx
00007d2ed8de03af  push rdi
00007d2ed8de03b0  push rsi
00007d2ed8de03b1  push r8
00007d2ed8de03b3  push r9
00007d2ed8de03b5  push r10
00007d2ed8de03b7  push r11
00007d2ed8de03b9  sub rsp, 0xF0
00007d2ed8de03c0  vmovaps [rsp], xmm0
00007d2ed8de03c5  vmovaps [rsp+0x10], xmm2
00007d2ed8de03cb  vmovaps [rsp+0x20], xmm3
00007d2ed8de03d1  vmovaps [rsp+0x30], xmm4
00007d2ed8de03d7  vmovaps [rsp+0x40], xmm5
00007d2ed8de03dd  vmovaps [rsp+0x50], xmm6
00007d2ed8de03e3  vmovaps [rsp+0x60], xmm7
00007d2ed8de03e9  vmovaps [rsp+0x70], xmm8
00007d2ed8de03ef  vmovaps [rsp+0x80], xmm9
00007d2ed8de03f8  vmovaps [rsp+0x90], xmm10
00007d2ed8de0401  vmovaps [rsp+0xA0], xmm11
00007d2ed8de040a  vmovaps [rsp+0xB0], xmm12
00007d2ed8de0413  vmovaps [rsp+0xC0], xmm13
00007d2ed8de041c  vmovaps [rsp+0xD0], xmm14
00007d2ed8de0425  vmovaps [rsp+0xE0], xmm15
00007d2ed8de042e  sub rsp, 0x30
00007d2ed8de0432  movaps [rsp], xmm1
00007d2ed8de0436  movaps [rsp+0x10], xmm13
00007d2ed8de043c  movaps [rsp+0x20], xmm9
00007d2ed8de0442  lea rdi, [rsp]
00007d2ed8de0446  mov esi, 0x00
00007d2ed8de044b  mov rax, 0x648718324530
00007d2ed8de0455  call rax
00007d2ed8de0457  movaps xmm1, [rsp]
00007d2ed8de045b  add rsp, 0x30
00007d2ed8de045f  vmovaps xmm0, [rsp]
00007d2ed8de0464  vmovaps xmm2, [rsp+0x10]
00007d2ed8de046a  vmovaps xmm3, [rsp+0x20]
00007d2ed8de0470  vmovaps xmm4, [rsp+0x30]
00007d2ed8de0476  vmovaps xmm5, [rsp+0x40]
00007d2ed8de047c  vmovaps xmm6, [rsp+0x50]
00007d2ed8de0482  vmovaps xmm7, [rsp+0x60]
00007d2ed8de0488  vmovaps xmm8, [rsp+0x70]
00007d2ed8de048e  vmovaps xmm9, [rsp+0x80]
00007d2ed8de0497  vmovaps xmm10, [rsp+0x90]
00007d2ed8de04a0  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de04a9  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de04b2  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de04bb  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de04c4  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de04cd  add rsp, 0xF0
00007d2ed8de04d4  pop r11
00007d2ed8de04d6  pop r10
00007d2ed8de04d8  pop r9
00007d2ed8de04da  pop r8
00007d2ed8de04dc  pop rsi
00007d2ed8de04dd  pop rdi
00007d2ed8de04de  pop rdx
00007d2ed8de04df  pop rcx
00007d2ed8de04e0  pop rax
00007d2ed8de04e1  add rsp, 0x08
00007d2ed8de04e5  jmp 0x00007D2ED8DDC5CD
00007d2ed8de04ea  sub rsp, 0x08
00007d2ed8de04ee  push rax
00007d2ed8de04ef  push rcx
00007d2ed8de04f0  push rdx
00007d2ed8de04f1  push rdi
00007d2ed8de04f2  push rsi
00007d2ed8de04f3  push r8
00007d2ed8de04f5  push r9
00007d2ed8de04f7  push r10
00007d2ed8de04f9  push r11
00007d2ed8de04fb  sub rsp, 0xF0
00007d2ed8de0502  vmovaps [rsp], xmm0
00007d2ed8de0507  vmovaps [rsp+0x10], xmm1
00007d2ed8de050d  vmovaps [rsp+0x20], xmm2
00007d2ed8de0513  vmovaps [rsp+0x30], xmm3
00007d2ed8de0519  vmovaps [rsp+0x40], xmm4
00007d2ed8de051f  vmovaps [rsp+0x50], xmm5
00007d2ed8de0525  vmovaps [rsp+0x60], xmm6
00007d2ed8de052b  vmovaps [rsp+0x70], xmm7
00007d2ed8de0531  vmovaps [rsp+0x80], xmm8
00007d2ed8de053a  vmovaps [rsp+0x90], xmm9
00007d2ed8de0543  vmovaps [rsp+0xA0], xmm10
00007d2ed8de054c  vmovaps [rsp+0xB0], xmm11
00007d2ed8de0555  vmovaps [rsp+0xC0], xmm13
00007d2ed8de055e  vmovaps [rsp+0xD0], xmm14
00007d2ed8de0567  vmovaps [rsp+0xE0], xmm15
00007d2ed8de0570  sub rsp, 0x30
00007d2ed8de0574  movaps [rsp], xmm12
00007d2ed8de0579  movaps [rsp+0x10], xmm7
00007d2ed8de057e  movaps [rsp+0x20], xmm13
00007d2ed8de0584  lea rdi, [rsp]
00007d2ed8de0588  mov esi, 0x00
00007d2ed8de058d  mov rax, 0x648718324530
00007d2ed8de0597  call rax
00007d2ed8de0599  movaps xmm12, [rsp]
00007d2ed8de059e  add rsp, 0x30
00007d2ed8de05a2  vmovaps xmm0, [rsp]
00007d2ed8de05a7  vmovaps xmm1, [rsp+0x10]
00007d2ed8de05ad  vmovaps xmm2, [rsp+0x20]
00007d2ed8de05b3  vmovaps xmm3, [rsp+0x30]
00007d2ed8de05b9  vmovaps xmm4, [rsp+0x40]
00007d2ed8de05bf  vmovaps xmm5, [rsp+0x50]
00007d2ed8de05c5  vmovaps xmm6, [rsp+0x60]
00007d2ed8de05cb  vmovaps xmm7, [rsp+0x70]
00007d2ed8de05d1  vmovaps xmm8, [rsp+0x80]
00007d2ed8de05da  vmovaps xmm9, [rsp+0x90]
00007d2ed8de05e3  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de05ec  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de05f5  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de05fe  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de0607  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0610  add rsp, 0xF0
00007d2ed8de0617  pop r11
00007d2ed8de0619  pop r10
00007d2ed8de061b  pop r9
00007d2ed8de061d  pop r8
00007d2ed8de061f  pop rsi
00007d2ed8de0620  pop rdi
00007d2ed8de0621  pop rdx
00007d2ed8de0622  pop rcx
00007d2ed8de0623  pop rax
00007d2ed8de0624  add rsp, 0x08
00007d2ed8de0628  jmp 0x00007D2ED8DDC5F4
00007d2ed8de062d  sub rsp, 0x08
00007d2ed8de0631  push rax
00007d2ed8de0632  push rcx
00007d2ed8de0633  push rdx
00007d2ed8de0634  push rdi
00007d2ed8de0635  push rsi
00007d2ed8de0636  push r8
00007d2ed8de0638  push r9
00007d2ed8de063a  push r10
00007d2ed8de063c  push r11
00007d2ed8de063e  sub rsp, 0xF0
00007d2ed8de0645  vmovaps [rsp], xmm0
00007d2ed8de064a  vmovaps [rsp+0x10], xmm1
00007d2ed8de0650  vmovaps [rsp+0x20], xmm2
00007d2ed8de0656  vmovaps [rsp+0x30], xmm3
00007d2ed8de065c  vmovaps [rsp+0x40], xmm4
00007d2ed8de0662  vmovaps [rsp+0x50], xmm5
00007d2ed8de0668  vmovaps [rsp+0x60], xmm6
00007d2ed8de066e  vmovaps [rsp+0x70], xmm7
00007d2ed8de0674  vmovaps [rsp+0x80], xmm8
00007d2ed8de067d  vmovaps [rsp+0x90], xmm9
00007d2ed8de0686  vmovaps [rsp+0xA0], xmm10
00007d2ed8de068f  vmovaps [rsp+0xB0], xmm11
00007d2ed8de0698  vmovaps [rsp+0xC0], xmm12
00007d2ed8de06a1  vmovaps [rsp+0xD0], xmm14
00007d2ed8de06aa  vmovaps [rsp+0xE0], xmm15
00007d2ed8de06b3  sub rsp, 0x30
00007d2ed8de06b7  movaps [rsp], xmm13
00007d2ed8de06bc  movaps [rsp+0x10], xmm15
00007d2ed8de06c2  movaps [rsp+0x20], xmm8
00007d2ed8de06c8  lea rdi, [rsp]
00007d2ed8de06cc  mov esi, 0x00
00007d2ed8de06d1  mov rax, 0x648718324530
00007d2ed8de06db  call rax
00007d2ed8de06dd  movaps xmm13, [rsp]
00007d2ed8de06e2  add rsp, 0x30
00007d2ed8de06e6  vmovaps xmm0, [rsp]
00007d2ed8de06eb  vmovaps xmm1, [rsp+0x10]
00007d2ed8de06f1  vmovaps xmm2, [rsp+0x20]
00007d2ed8de06f7  vmovaps xmm3, [rsp+0x30]
00007d2ed8de06fd  vmovaps xmm4, [rsp+0x40]
00007d2ed8de0703  vmovaps xmm5, [rsp+0x50]
00007d2ed8de0709  vmovaps xmm6, [rsp+0x60]
00007d2ed8de070f  vmovaps xmm7, [rsp+0x70]
00007d2ed8de0715  vmovaps xmm8, [rsp+0x80]
00007d2ed8de071e  vmovaps xmm9, [rsp+0x90]
00007d2ed8de0727  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de0730  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de0739  vmovaps xmm12, [rsp+0xC0]
00007d2ed8de0742  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de074b  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0754  add rsp, 0xF0
00007d2ed8de075b  pop r11
00007d2ed8de075d  pop r10
00007d2ed8de075f  pop r9
00007d2ed8de0761  pop r8
00007d2ed8de0763  pop rsi
00007d2ed8de0764  pop rdi
00007d2ed8de0765  pop rdx
00007d2ed8de0766  pop rcx
00007d2ed8de0767  pop rax
00007d2ed8de0768  add rsp, 0x08
00007d2ed8de076c  jmp 0x00007D2ED8DDC60F
00007d2ed8de0771  sub rsp, 0x08
00007d2ed8de0775  push rax
00007d2ed8de0776  push rcx
00007d2ed8de0777  push rdx
00007d2ed8de0778  push rdi
00007d2ed8de0779  push rsi
00007d2ed8de077a  push r8
00007d2ed8de077c  push r9
00007d2ed8de077e  push r10
00007d2ed8de0780  push r11
00007d2ed8de0782  sub rsp, 0xF0
00007d2ed8de0789  vmovaps [rsp], xmm0
00007d2ed8de078e  vmovaps [rsp+0x10], xmm1
00007d2ed8de0794  vmovaps [rsp+0x20], xmm2
00007d2ed8de079a  vmovaps [rsp+0x30], xmm3
00007d2ed8de07a0  vmovaps [rsp+0x40], xmm4
00007d2ed8de07a6  vmovaps [rsp+0x50], xmm5
00007d2ed8de07ac  vmovaps [rsp+0x60], xmm6
00007d2ed8de07b2  vmovaps [rsp+0x70], xmm7
00007d2ed8de07b8  vmovaps [rsp+0x80], xmm9
00007d2ed8de07c1  vmovaps [rsp+0x90], xmm10
00007d2ed8de07ca  vmovaps [rsp+0xA0], xmm11
00007d2ed8de07d3  vmovaps [rsp+0xB0], xmm12
00007d2ed8de07dc  vmovaps [rsp+0xC0], xmm13
00007d2ed8de07e5  vmovaps [rsp+0xD0], xmm14
00007d2ed8de07ee  vmovaps [rsp+0xE0], xmm15
00007d2ed8de07f7  sub rsp, 0x30
00007d2ed8de07fb  movaps [rsp], xmm8
00007d2ed8de0800  movaps [rsp+0x10], xmm15
00007d2ed8de0806  movaps [rsp+0x20], xmm9
00007d2ed8de080c  lea rdi, [rsp]
00007d2ed8de0810  mov esi, 0x00
00007d2ed8de0815  mov rax, 0x648718324530
00007d2ed8de081f  call rax
00007d2ed8de0821  movaps xmm8, [rsp]
00007d2ed8de0826  add rsp, 0x30
00007d2ed8de082a  vmovaps xmm0, [rsp]
00007d2ed8de082f  vmovaps xmm1, [rsp+0x10]
00007d2ed8de0835  vmovaps xmm2, [rsp+0x20]
00007d2ed8de083b  vmovaps xmm3, [rsp+0x30]
00007d2ed8de0841  vmovaps xmm4, [rsp+0x40]
00007d2ed8de0847  vmovaps xmm5, [rsp+0x50]
00007d2ed8de084d  vmovaps xmm6, [rsp+0x60]
00007d2ed8de0853  vmovaps xmm7, [rsp+0x70]
00007d2ed8de0859  vmovaps xmm9, [rsp+0x80]
00007d2ed8de0862  vmovaps xmm10, [rsp+0x90]
00007d2ed8de086b  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de0874  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de087d  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de0886  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de088f  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0898  add rsp, 0xF0
00007d2ed8de089f  pop r11
00007d2ed8de08a1  pop r10
00007d2ed8de08a3  pop r9
00007d2ed8de08a5  pop r8
00007d2ed8de08a7  pop rsi
00007d2ed8de08a8  pop rdi
00007d2ed8de08a9  pop rdx
00007d2ed8de08aa  pop rcx
00007d2ed8de08ab  pop rax
00007d2ed8de08ac  add rsp, 0x08
00007d2ed8de08b0  jmp 0x00007D2ED8DDC63D
00007d2ed8de08b5  sub rsp, 0x08
00007d2ed8de08b9  push rax
00007d2ed8de08ba  push rcx
00007d2ed8de08bb  push rdx
00007d2ed8de08bc  push rdi
00007d2ed8de08bd  push rsi
00007d2ed8de08be  push r8
00007d2ed8de08c0  push r9
00007d2ed8de08c2  push r10
00007d2ed8de08c4  push r11
00007d2ed8de08c6  sub rsp, 0xF0
00007d2ed8de08cd  vmovaps [rsp], xmm0
00007d2ed8de08d2  vmovaps [rsp+0x10], xmm1
00007d2ed8de08d8  vmovaps [rsp+0x20], xmm2
00007d2ed8de08de  vmovaps [rsp+0x30], xmm3
00007d2ed8de08e4  vmovaps [rsp+0x40], xmm4
00007d2ed8de08ea  vmovaps [rsp+0x50], xmm5
00007d2ed8de08f0  vmovaps [rsp+0x60], xmm6
00007d2ed8de08f6  vmovaps [rsp+0x70], xmm7
00007d2ed8de08fc  vmovaps [rsp+0x80], xmm8
00007d2ed8de0905  vmovaps [rsp+0x90], xmm9
00007d2ed8de090e  vmovaps [rsp+0xA0], xmm10
00007d2ed8de0917  vmovaps [rsp+0xB0], xmm11
00007d2ed8de0920  vmovaps [rsp+0xC0], xmm12
00007d2ed8de0929  vmovaps [rsp+0xD0], xmm13
00007d2ed8de0932  vmovaps [rsp+0xE0], xmm14
00007d2ed8de093b  sub rsp, 0x30
00007d2ed8de093f  movaps [rsp], xmm15
00007d2ed8de0944  movaps [rsp+0x10], xmm11
00007d2ed8de094a  movaps [rsp+0x20], xmm6
00007d2ed8de094f  lea rdi, [rsp]
00007d2ed8de0953  mov esi, 0x00
00007d2ed8de0958  mov rax, 0x648718324530
00007d2ed8de0962  call rax
00007d2ed8de0964  movaps xmm15, [rsp]
00007d2ed8de0969  add rsp, 0x30
00007d2ed8de096d  vmovaps xmm0, [rsp]
00007d2ed8de0972  vmovaps xmm1, [rsp+0x10]
00007d2ed8de0978  vmovaps xmm2, [rsp+0x20]
00007d2ed8de097e  vmovaps xmm3, [rsp+0x30]
00007d2ed8de0984  vmovaps xmm4, [rsp+0x40]
00007d2ed8de098a  vmovaps xmm5, [rsp+0x50]
00007d2ed8de0990  vmovaps xmm6, [rsp+0x60]
00007d2ed8de0996  vmovaps xmm7, [rsp+0x70]
00007d2ed8de099c  vmovaps xmm8, [rsp+0x80]
00007d2ed8de09a5  vmovaps xmm9, [rsp+0x90]
00007d2ed8de09ae  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de09b7  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de09c0  vmovaps xmm12, [rsp+0xC0]
00007d2ed8de09c9  vmovaps xmm13, [rsp+0xD0]
00007d2ed8de09d2  vmovaps xmm14, [rsp+0xE0]
00007d2ed8de09db  add rsp, 0xF0
00007d2ed8de09e2  pop r11
00007d2ed8de09e4  pop r10
00007d2ed8de09e6  pop r9
00007d2ed8de09e8  pop r8
00007d2ed8de09ea  pop rsi
00007d2ed8de09eb  pop rdi
00007d2ed8de09ec  pop rdx
00007d2ed8de09ed  pop rcx
00007d2ed8de09ee  pop rax
00007d2ed8de09ef  add rsp, 0x08
00007d2ed8de09f3  jmp 0x00007D2ED8DDC658
00007d2ed8de09f8  sub rsp, 0x08
00007d2ed8de09fc  push rax
00007d2ed8de09fd  push rcx
00007d2ed8de09fe  push rdx
00007d2ed8de09ff  push rdi
00007d2ed8de0a00  push rsi
00007d2ed8de0a01  push r8
00007d2ed8de0a03  push r9
00007d2ed8de0a05  push r10
00007d2ed8de0a07  push r11
00007d2ed8de0a09  sub rsp, 0xF0
00007d2ed8de0a10  vmovaps [rsp], xmm0
00007d2ed8de0a15  vmovaps [rsp+0x10], xmm1
00007d2ed8de0a1b  vmovaps [rsp+0x20], xmm2
00007d2ed8de0a21  vmovaps [rsp+0x30], xmm3
00007d2ed8de0a27  vmovaps [rsp+0x40], xmm4
00007d2ed8de0a2d  vmovaps [rsp+0x50], xmm5
00007d2ed8de0a33  vmovaps [rsp+0x60], xmm6
00007d2ed8de0a39  vmovaps [rsp+0x70], xmm8
00007d2ed8de0a3f  vmovaps [rsp+0x80], xmm9
00007d2ed8de0a48  vmovaps [rsp+0x90], xmm10
00007d2ed8de0a51  vmovaps [rsp+0xA0], xmm11
00007d2ed8de0a5a  vmovaps [rsp+0xB0], xmm12
00007d2ed8de0a63  vmovaps [rsp+0xC0], xmm13
00007d2ed8de0a6c  vmovaps [rsp+0xD0], xmm14
00007d2ed8de0a75  vmovaps [rsp+0xE0], xmm15
00007d2ed8de0a7e  sub rsp, 0x30
00007d2ed8de0a82  movaps [rsp], xmm7
00007d2ed8de0a86  movaps [rsp+0x10], xmm11
00007d2ed8de0a8c  movaps [rsp+0x20], xmm9
00007d2ed8de0a92  lea rdi, [rsp]
00007d2ed8de0a96  mov esi, 0x00
00007d2ed8de0a9b  mov rax, 0x648718324530
00007d2ed8de0aa5  call rax
00007d2ed8de0aa7  movaps xmm7, [rsp]
00007d2ed8de0aab  add rsp, 0x30
00007d2ed8de0aaf  vmovaps xmm0, [rsp]
00007d2ed8de0ab4  vmovaps xmm1, [rsp+0x10]
00007d2ed8de0aba  vmovaps xmm2, [rsp+0x20]
00007d2ed8de0ac0  vmovaps xmm3, [rsp+0x30]
00007d2ed8de0ac6  vmovaps xmm4, [rsp+0x40]
00007d2ed8de0acc  vmovaps xmm5, [rsp+0x50]
00007d2ed8de0ad2  vmovaps xmm6, [rsp+0x60]
00007d2ed8de0ad8  vmovaps xmm8, [rsp+0x70]
00007d2ed8de0ade  vmovaps xmm9, [rsp+0x80]
00007d2ed8de0ae7  vmovaps xmm10, [rsp+0x90]
00007d2ed8de0af0  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de0af9  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de0b02  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de0b0b  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de0b14  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0b1d  add rsp, 0xF0
00007d2ed8de0b24  pop r11
00007d2ed8de0b26  pop r10
00007d2ed8de0b28  pop r9
00007d2ed8de0b2a  pop r8
00007d2ed8de0b2c  pop rsi
00007d2ed8de0b2d  pop rdi
00007d2ed8de0b2e  pop rdx
00007d2ed8de0b2f  pop rcx
00007d2ed8de0b30  pop rax
00007d2ed8de0b31  add rsp, 0x08
00007d2ed8de0b35  jmp 0x00007D2ED8DDC685
00007d2ed8de0b3a  sub rsp, 0x08
00007d2ed8de0b3e  push rax
00007d2ed8de0b3f  push rcx
00007d2ed8de0b40  push rdx
00007d2ed8de0b41  push rdi
00007d2ed8de0b42  push rsi
00007d2ed8de0b43  push r8
00007d2ed8de0b45  push r9
00007d2ed8de0b47  push r10
00007d2ed8de0b49  push r11
00007d2ed8de0b4b  sub rsp, 0xF0
00007d2ed8de0b52  vmovaps [rsp], xmm0
00007d2ed8de0b57  vmovaps [rsp+0x10], xmm1
00007d2ed8de0b5d  vmovaps [rsp+0x20], xmm2
00007d2ed8de0b63  vmovaps [rsp+0x30], xmm3
00007d2ed8de0b69  vmovaps [rsp+0x40], xmm4
00007d2ed8de0b6f  vmovaps [rsp+0x50], xmm5
00007d2ed8de0b75  vmovaps [rsp+0x60], xmm6
00007d2ed8de0b7b  vmovaps [rsp+0x70], xmm7
00007d2ed8de0b81  vmovaps [rsp+0x80], xmm8
00007d2ed8de0b8a  vmovaps [rsp+0x90], xmm9
00007d2ed8de0b93  vmovaps [rsp+0xA0], xmm10
00007d2ed8de0b9c  vmovaps [rsp+0xB0], xmm12
00007d2ed8de0ba5  vmovaps [rsp+0xC0], xmm13
00007d2ed8de0bae  vmovaps [rsp+0xD0], xmm14
00007d2ed8de0bb7  vmovaps [rsp+0xE0], xmm15
00007d2ed8de0bc0  sub rsp, 0x30
00007d2ed8de0bc4  movaps [rsp], xmm11
00007d2ed8de0bc9  movaps [rsp+0x10], xmm10
00007d2ed8de0bcf  movaps [rsp+0x20], xmm14
00007d2ed8de0bd5  lea rdi, [rsp]
00007d2ed8de0bd9  mov esi, 0x00
00007d2ed8de0bde  mov rax, 0x648718324530
00007d2ed8de0be8  call rax
00007d2ed8de0bea  movaps xmm11, [rsp]
00007d2ed8de0bef  add rsp, 0x30
00007d2ed8de0bf3  vmovaps xmm0, [rsp]
00007d2ed8de0bf8  vmovaps xmm1, [rsp+0x10]
00007d2ed8de0bfe  vmovaps xmm2, [rsp+0x20]
00007d2ed8de0c04  vmovaps xmm3, [rsp+0x30]
00007d2ed8de0c0a  vmovaps xmm4, [rsp+0x40]
00007d2ed8de0c10  vmovaps xmm5, [rsp+0x50]
00007d2ed8de0c16  vmovaps xmm6, [rsp+0x60]
00007d2ed8de0c1c  vmovaps xmm7, [rsp+0x70]
00007d2ed8de0c22  vmovaps xmm8, [rsp+0x80]
00007d2ed8de0c2b  vmovaps xmm9, [rsp+0x90]
00007d2ed8de0c34  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de0c3d  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de0c46  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de0c4f  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de0c58  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0c61  add rsp, 0xF0
00007d2ed8de0c68  pop r11
00007d2ed8de0c6a  pop r10
00007d2ed8de0c6c  pop r9
00007d2ed8de0c6e  pop r8
00007d2ed8de0c70  pop rsi
00007d2ed8de0c71  pop rdi
00007d2ed8de0c72  pop rdx
00007d2ed8de0c73  pop rcx
00007d2ed8de0c74  pop rax
00007d2ed8de0c75  add rsp, 0x08
00007d2ed8de0c79  jmp 0x00007D2ED8DDC6A0
00007d2ed8de0c7e  call 0x00007D2ED8CC33A0
00007d2ed8de0c83  jmp 0x00007D2ED8DDC6AA
00007d2ed8de0c88  sub rsp, 0x08
00007d2ed8de0c8c  push rax
00007d2ed8de0c8d  push rcx
00007d2ed8de0c8e  push rdx
00007d2ed8de0c8f  push rdi
00007d2ed8de0c90  push rsi
00007d2ed8de0c91  push r8
00007d2ed8de0c93  push r9
00007d2ed8de0c95  push r10
00007d2ed8de0c97  push r11
00007d2ed8de0c99  sub rsp, 0xF0
00007d2ed8de0ca0  vmovaps [rsp], xmm0
00007d2ed8de0ca5  vmovaps [rsp+0x10], xmm1
00007d2ed8de0cab  vmovaps [rsp+0x20], xmm2
00007d2ed8de0cb1  vmovaps [rsp+0x30], xmm3
00007d2ed8de0cb7  vmovaps [rsp+0x40], xmm4
00007d2ed8de0cbd  vmovaps [rsp+0x50], xmm5
00007d2ed8de0cc3  vmovaps [rsp+0x60], xmm6
00007d2ed8de0cc9  vmovaps [rsp+0x70], xmm7
00007d2ed8de0ccf  vmovaps [rsp+0x80], xmm8
00007d2ed8de0cd8  vmovaps [rsp+0x90], xmm9
00007d2ed8de0ce1  vmovaps [rsp+0xA0], xmm11
00007d2ed8de0cea  vmovaps [rsp+0xB0], xmm12
00007d2ed8de0cf3  vmovaps [rsp+0xC0], xmm13
00007d2ed8de0cfc  vmovaps [rsp+0xD0], xmm14
00007d2ed8de0d05  vmovaps [rsp+0xE0], xmm15
00007d2ed8de0d0e  sub rsp, 0x30
00007d2ed8de0d12  movaps [rsp], xmm10
00007d2ed8de0d17  movaps [rsp+0x10], xmm1
00007d2ed8de0d1c  movaps [rsp+0x20], xmm12
00007d2ed8de0d22  lea rdi, [rsp]
00007d2ed8de0d26  mov esi, 0x00
00007d2ed8de0d2b  mov rax, 0x648718324530
00007d2ed8de0d35  call rax
00007d2ed8de0d37  movaps xmm10, [rsp]
00007d2ed8de0d3c  add rsp, 0x30
00007d2ed8de0d40  vmovaps xmm0, [rsp]
00007d2ed8de0d45  vmovaps xmm1, [rsp+0x10]
00007d2ed8de0d4b  vmovaps xmm2, [rsp+0x20]
00007d2ed8de0d51  vmovaps xmm3, [rsp+0x30]
00007d2ed8de0d57  vmovaps xmm4, [rsp+0x40]
00007d2ed8de0d5d  vmovaps xmm5, [rsp+0x50]
00007d2ed8de0d63  vmovaps xmm6, [rsp+0x60]
00007d2ed8de0d69  vmovaps xmm7, [rsp+0x70]
00007d2ed8de0d6f  vmovaps xmm8, [rsp+0x80]
00007d2ed8de0d78  vmovaps xmm9, [rsp+0x90]
00007d2ed8de0d81  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de0d8a  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de0d93  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de0d9c  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de0da5  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0dae  add rsp, 0xF0
00007d2ed8de0db5  pop r11
00007d2ed8de0db7  pop r10
00007d2ed8de0db9  pop r9
00007d2ed8de0dbb  pop r8
00007d2ed8de0dbd  pop rsi
00007d2ed8de0dbe  pop rdi
00007d2ed8de0dbf  pop rdx
00007d2ed8de0dc0  pop rcx
00007d2ed8de0dc1  pop rax
00007d2ed8de0dc2  add rsp, 0x08
00007d2ed8de0dc6  jmp 0x00007D2ED8DDC6CD
00007d2ed8de0dcb  sub rsp, 0x08
00007d2ed8de0dcf  push rax
00007d2ed8de0dd0  push rcx
00007d2ed8de0dd1  push rdx
00007d2ed8de0dd2  push rdi
00007d2ed8de0dd3  push rsi
00007d2ed8de0dd4  push r8
00007d2ed8de0dd6  push r9
00007d2ed8de0dd8  push r10
00007d2ed8de0dda  push r11
00007d2ed8de0ddc  sub rsp, 0xF0
00007d2ed8de0de3  vmovaps [rsp], xmm0
00007d2ed8de0de8  vmovaps [rsp+0x10], xmm1
00007d2ed8de0dee  vmovaps [rsp+0x20], xmm2
00007d2ed8de0df4  vmovaps [rsp+0x30], xmm3
00007d2ed8de0dfa  vmovaps [rsp+0x40], xmm4
00007d2ed8de0e00  vmovaps [rsp+0x50], xmm5
00007d2ed8de0e06  vmovaps [rsp+0x60], xmm6
00007d2ed8de0e0c  vmovaps [rsp+0x70], xmm7
00007d2ed8de0e12  vmovaps [rsp+0x80], xmm8
00007d2ed8de0e1b  vmovaps [rsp+0x90], xmm9
00007d2ed8de0e24  vmovaps [rsp+0xA0], xmm10
00007d2ed8de0e2d  vmovaps [rsp+0xB0], xmm11
00007d2ed8de0e36  vmovaps [rsp+0xC0], xmm13
00007d2ed8de0e3f  vmovaps [rsp+0xD0], xmm14
00007d2ed8de0e48  vmovaps [rsp+0xE0], xmm15
00007d2ed8de0e51  sub rsp, 0x30
00007d2ed8de0e55  movaps [rsp], xmm12
00007d2ed8de0e5a  movaps [rsp+0x10], xmm14
00007d2ed8de0e60  movaps [rsp+0x20], xmm1
00007d2ed8de0e65  lea rdi, [rsp]
00007d2ed8de0e69  mov esi, 0x00
00007d2ed8de0e6e  mov rax, 0x648718324530
00007d2ed8de0e78  call rax
00007d2ed8de0e7a  movaps xmm12, [rsp]
00007d2ed8de0e7f  add rsp, 0x30
00007d2ed8de0e83  vmovaps xmm0, [rsp]
00007d2ed8de0e88  vmovaps xmm1, [rsp+0x10]
00007d2ed8de0e8e  vmovaps xmm2, [rsp+0x20]
00007d2ed8de0e94  vmovaps xmm3, [rsp+0x30]
00007d2ed8de0e9a  vmovaps xmm4, [rsp+0x40]
00007d2ed8de0ea0  vmovaps xmm5, [rsp+0x50]
00007d2ed8de0ea6  vmovaps xmm6, [rsp+0x60]
00007d2ed8de0eac  vmovaps xmm7, [rsp+0x70]
00007d2ed8de0eb2  vmovaps xmm8, [rsp+0x80]
00007d2ed8de0ebb  vmovaps xmm9, [rsp+0x90]
00007d2ed8de0ec4  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de0ecd  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de0ed6  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de0edf  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de0ee8  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de0ef1  add rsp, 0xF0
00007d2ed8de0ef8  pop r11
00007d2ed8de0efa  pop r10
00007d2ed8de0efc  pop r9
00007d2ed8de0efe  pop r8
00007d2ed8de0f00  pop rsi
00007d2ed8de0f01  pop rdi
00007d2ed8de0f02  pop rdx
00007d2ed8de0f03  pop rcx
00007d2ed8de0f04  pop rax
00007d2ed8de0f05  add rsp, 0x08
00007d2ed8de0f09  jmp 0x00007D2ED8DDC6FC
00007d2ed8de0f0e  sub rsp, 0x08
00007d2ed8de0f12  push rax
00007d2ed8de0f13  push rcx
00007d2ed8de0f14  push rdx
00007d2ed8de0f15  push rdi
00007d2ed8de0f16  push rsi
00007d2ed8de0f17  push r8
00007d2ed8de0f19  push r9
00007d2ed8de0f1b  push r10
00007d2ed8de0f1d  push r11
00007d2ed8de0f1f  sub rsp, 0xF0
00007d2ed8de0f26  vmovaps [rsp], xmm0
00007d2ed8de0f2b  vmovaps [rsp+0x10], xmm1
00007d2ed8de0f31  vmovaps [rsp+0x20], xmm2
00007d2ed8de0f37  vmovaps [rsp+0x30], xmm3
00007d2ed8de0f3d  vmovaps [rsp+0x40], xmm4
00007d2ed8de0f43  vmovaps [rsp+0x50], xmm5
00007d2ed8de0f49  vmovaps [rsp+0x60], xmm6
00007d2ed8de0f4f  vmovaps [rsp+0x70], xmm7
00007d2ed8de0f55  vmovaps [rsp+0x80], xmm8
00007d2ed8de0f5e  vmovaps [rsp+0x90], xmm9
00007d2ed8de0f67  vmovaps [rsp+0xA0], xmm10
00007d2ed8de0f70  vmovaps [rsp+0xB0], xmm11
00007d2ed8de0f79  vmovaps [rsp+0xC0], xmm12
00007d2ed8de0f82  vmovaps [rsp+0xD0], xmm13
00007d2ed8de0f8b  vmovaps [rsp+0xE0], xmm15
00007d2ed8de0f94  sub rsp, 0x30
00007d2ed8de0f98  movaps [rsp], xmm14
00007d2ed8de0f9d  movaps [rsp+0x10], xmm9
00007d2ed8de0fa3  movaps [rsp+0x20], xmm1
00007d2ed8de0fa8  lea rdi, [rsp]
00007d2ed8de0fac  mov esi, 0x00
00007d2ed8de0fb1  mov rax, 0x648718324530
00007d2ed8de0fbb  call rax
00007d2ed8de0fbd  movaps xmm14, [rsp]
00007d2ed8de0fc2  add rsp, 0x30
00007d2ed8de0fc6  vmovaps xmm0, [rsp]
00007d2ed8de0fcb  vmovaps xmm1, [rsp+0x10]
00007d2ed8de0fd1  vmovaps xmm2, [rsp+0x20]
00007d2ed8de0fd7  vmovaps xmm3, [rsp+0x30]
00007d2ed8de0fdd  vmovaps xmm4, [rsp+0x40]
00007d2ed8de0fe3  vmovaps xmm5, [rsp+0x50]
00007d2ed8de0fe9  vmovaps xmm6, [rsp+0x60]
00007d2ed8de0fef  vmovaps xmm7, [rsp+0x70]
00007d2ed8de0ff5  vmovaps xmm8, [rsp+0x80]
00007d2ed8de0ffe  vmovaps xmm9, [rsp+0x90]
00007d2ed8de1007  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de1010  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de1019  vmovaps xmm12, [rsp+0xC0]
00007d2ed8de1022  vmovaps xmm13, [rsp+0xD0]
00007d2ed8de102b  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de1034  add rsp, 0xF0
00007d2ed8de103b  pop r11
00007d2ed8de103d  pop r10
00007d2ed8de103f  pop r9
00007d2ed8de1041  pop r8
00007d2ed8de1043  pop rsi
00007d2ed8de1044  pop rdi
00007d2ed8de1045  pop rdx
00007d2ed8de1046  pop rcx
00007d2ed8de1047  pop rax
00007d2ed8de1048  add rsp, 0x08
00007d2ed8de104c  jmp 0x00007D2ED8DDC72B
00007d2ed8de1051  sub rsp, 0x08
00007d2ed8de1055  push rax
00007d2ed8de1056  push rcx
00007d2ed8de1057  push rdx
00007d2ed8de1058  push rdi
00007d2ed8de1059  push rsi
00007d2ed8de105a  push r8
00007d2ed8de105c  push r9
00007d2ed8de105e  push r10
00007d2ed8de1060  push r11
00007d2ed8de1062  sub rsp, 0xF0
00007d2ed8de1069  vmovaps [rsp], xmm0
00007d2ed8de106e  vmovaps [rsp+0x10], xmm2
00007d2ed8de1074  vmovaps [rsp+0x20], xmm3
00007d2ed8de107a  vmovaps [rsp+0x30], xmm4
00007d2ed8de1080  vmovaps [rsp+0x40], xmm5
00007d2ed8de1086  vmovaps [rsp+0x50], xmm6
00007d2ed8de108c  vmovaps [rsp+0x60], xmm7
00007d2ed8de1092  vmovaps [rsp+0x70], xmm8
00007d2ed8de1098  vmovaps [rsp+0x80], xmm9
00007d2ed8de10a1  vmovaps [rsp+0x90], xmm10
00007d2ed8de10aa  vmovaps [rsp+0xA0], xmm11
00007d2ed8de10b3  vmovaps [rsp+0xB0], xmm12
00007d2ed8de10bc  vmovaps [rsp+0xC0], xmm13
00007d2ed8de10c5  vmovaps [rsp+0xD0], xmm14
00007d2ed8de10ce  vmovaps [rsp+0xE0], xmm15
00007d2ed8de10d7  sub rsp, 0x30
00007d2ed8de10db  movaps [rsp], xmm1
00007d2ed8de10df  movaps [rsp+0x10], xmm13
00007d2ed8de10e5  movaps [rsp+0x20], xmm8
00007d2ed8de10eb  lea rdi, [rsp]
00007d2ed8de10ef  mov esi, 0x00
00007d2ed8de10f4  mov rax, 0x648718324530
00007d2ed8de10fe  call rax
00007d2ed8de1100  movaps xmm1, [rsp]
00007d2ed8de1104  add rsp, 0x30
00007d2ed8de1108  vmovaps xmm0, [rsp]
00007d2ed8de110d  vmovaps xmm2, [rsp+0x10]
00007d2ed8de1113  vmovaps xmm3, [rsp+0x20]
00007d2ed8de1119  vmovaps xmm4, [rsp+0x30]
00007d2ed8de111f  vmovaps xmm5, [rsp+0x40]
00007d2ed8de1125  vmovaps xmm6, [rsp+0x50]
00007d2ed8de112b  vmovaps xmm7, [rsp+0x60]
00007d2ed8de1131  vmovaps xmm8, [rsp+0x70]
00007d2ed8de1137  vmovaps xmm9, [rsp+0x80]
00007d2ed8de1140  vmovaps xmm10, [rsp+0x90]
00007d2ed8de1149  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de1152  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de115b  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de1164  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de116d  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de1176  add rsp, 0xF0
00007d2ed8de117d  pop r11
00007d2ed8de117f  pop r10
00007d2ed8de1181  pop r9
00007d2ed8de1183  pop r8
00007d2ed8de1185  pop rsi
00007d2ed8de1186  pop rdi
00007d2ed8de1187  pop rdx
00007d2ed8de1188  pop rcx
00007d2ed8de1189  pop rax
00007d2ed8de118a  add rsp, 0x08
00007d2ed8de118e  jmp 0x00007D2ED8DDC74D
00007d2ed8de1193  call 0x00007D2ED8C0C260
00007d2ed8de1198  jmp 0x00007D2ED8DDC75B
00007d2ed8de119d  call 0x00007D2ED8CBD750
00007d2ed8de11a2  jmp 0x00007D2ED8DDC765
00007d2ed8de11a7  sub rsp, 0x08
00007d2ed8de11ab  push rax
00007d2ed8de11ac  push rcx
00007d2ed8de11ad  push rdx
00007d2ed8de11ae  push rdi
00007d2ed8de11af  push rsi
00007d2ed8de11b0  push r8
00007d2ed8de11b2  push r9
00007d2ed8de11b4  push r10
00007d2ed8de11b6  push r11
00007d2ed8de11b8  sub rsp, 0xF0
00007d2ed8de11bf  vmovaps [rsp], xmm0
00007d2ed8de11c4  vmovaps [rsp+0x10], xmm1
00007d2ed8de11ca  vmovaps [rsp+0x20], xmm2
00007d2ed8de11d0  vmovaps [rsp+0x30], xmm3
00007d2ed8de11d6  vmovaps [rsp+0x40], xmm4
00007d2ed8de11dc  vmovaps [rsp+0x50], xmm5
00007d2ed8de11e2  vmovaps [rsp+0x60], xmm6
00007d2ed8de11e8  vmovaps [rsp+0x70], xmm7
00007d2ed8de11ee  vmovaps [rsp+0x80], xmm9
00007d2ed8de11f7  vmovaps [rsp+0x90], xmm10
00007d2ed8de1200  vmovaps [rsp+0xA0], xmm11
00007d2ed8de1209  vmovaps [rsp+0xB0], xmm12
00007d2ed8de1212  vmovaps [rsp+0xC0], xmm13
00007d2ed8de121b  vmovaps [rsp+0xD0], xmm14
00007d2ed8de1224  vmovaps [rsp+0xE0], xmm15
00007d2ed8de122d  sub rsp, 0x30
00007d2ed8de1231  movaps [rsp], xmm8
00007d2ed8de1236  movaps [rsp+0x10], xmm15
00007d2ed8de123c  movaps [rsp+0x20], xmm7
00007d2ed8de1241  lea rdi, [rsp]
00007d2ed8de1245  mov esi, 0x00
00007d2ed8de124a  mov rax, 0x648718324530
00007d2ed8de1254  call rax
00007d2ed8de1256  movaps xmm8, [rsp]
00007d2ed8de125b  add rsp, 0x30
00007d2ed8de125f  vmovaps xmm0, [rsp]
00007d2ed8de1264  vmovaps xmm1, [rsp+0x10]
00007d2ed8de126a  vmovaps xmm2, [rsp+0x20]
00007d2ed8de1270  vmovaps xmm3, [rsp+0x30]
00007d2ed8de1276  vmovaps xmm4, [rsp+0x40]
00007d2ed8de127c  vmovaps xmm5, [rsp+0x50]
00007d2ed8de1282  vmovaps xmm6, [rsp+0x60]
00007d2ed8de1288  vmovaps xmm7, [rsp+0x70]
00007d2ed8de128e  vmovaps xmm9, [rsp+0x80]
00007d2ed8de1297  vmovaps xmm10, [rsp+0x90]
00007d2ed8de12a0  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de12a9  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de12b2  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de12bb  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de12c4  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de12cd  add rsp, 0xF0
00007d2ed8de12d4  pop r11
00007d2ed8de12d6  pop r10
00007d2ed8de12d8  pop r9
00007d2ed8de12da  pop r8
00007d2ed8de12dc  pop rsi
00007d2ed8de12dd  pop rdi
00007d2ed8de12de  pop rdx
00007d2ed8de12df  pop rcx
00007d2ed8de12e0  pop rax
00007d2ed8de12e1  add rsp, 0x08
00007d2ed8de12e5  jmp 0x00007D2ED8DDC787
00007d2ed8de12ea  sub rsp, 0x08
00007d2ed8de12ee  push rax
00007d2ed8de12ef  push rcx
00007d2ed8de12f0  push rdx
00007d2ed8de12f1  push rdi
00007d2ed8de12f2  push rsi
00007d2ed8de12f3  push r8
00007d2ed8de12f5  push r9
00007d2ed8de12f7  push r10
00007d2ed8de12f9  push r11
00007d2ed8de12fb  sub rsp, 0xF0
00007d2ed8de1302  vmovaps [rsp], xmm0
00007d2ed8de1307  vmovaps [rsp+0x10], xmm1
00007d2ed8de130d  vmovaps [rsp+0x20], xmm2
00007d2ed8de1313  vmovaps [rsp+0x30], xmm3
00007d2ed8de1319  vmovaps [rsp+0x40], xmm4
00007d2ed8de131f  vmovaps [rsp+0x50], xmm5
00007d2ed8de1325  vmovaps [rsp+0x60], xmm6
00007d2ed8de132b  vmovaps [rsp+0x70], xmm8
00007d2ed8de1331  vmovaps [rsp+0x80], xmm9
00007d2ed8de133a  vmovaps [rsp+0x90], xmm10
00007d2ed8de1343  vmovaps [rsp+0xA0], xmm11
00007d2ed8de134c  vmovaps [rsp+0xB0], xmm12
00007d2ed8de1355  vmovaps [rsp+0xC0], xmm13
00007d2ed8de135e  vmovaps [rsp+0xD0], xmm14
00007d2ed8de1367  vmovaps [rsp+0xE0], xmm15
00007d2ed8de1370  sub rsp, 0x30
00007d2ed8de1374  movaps [rsp], xmm7
00007d2ed8de1378  movaps [rsp+0x10], xmm9
00007d2ed8de137e  movaps [rsp+0x20], xmm15
00007d2ed8de1384  lea rdi, [rsp]
00007d2ed8de1388  mov esi, 0x00
00007d2ed8de138d  mov rax, 0x648718324530
00007d2ed8de1397  call rax
00007d2ed8de1399  movaps xmm7, [rsp]
00007d2ed8de139d  add rsp, 0x30
00007d2ed8de13a1  vmovaps xmm0, [rsp]
00007d2ed8de13a6  vmovaps xmm1, [rsp+0x10]
00007d2ed8de13ac  vmovaps xmm2, [rsp+0x20]
00007d2ed8de13b2  vmovaps xmm3, [rsp+0x30]
00007d2ed8de13b8  vmovaps xmm4, [rsp+0x40]
00007d2ed8de13be  vmovaps xmm5, [rsp+0x50]
00007d2ed8de13c4  vmovaps xmm6, [rsp+0x60]
00007d2ed8de13ca  vmovaps xmm8, [rsp+0x70]
00007d2ed8de13d0  vmovaps xmm9, [rsp+0x80]
00007d2ed8de13d9  vmovaps xmm10, [rsp+0x90]
00007d2ed8de13e2  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de13eb  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de13f4  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de13fd  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de1406  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de140f  add rsp, 0xF0
00007d2ed8de1416  pop r11
00007d2ed8de1418  pop r10
00007d2ed8de141a  pop r9
00007d2ed8de141c  pop r8
00007d2ed8de141e  pop rsi
00007d2ed8de141f  pop rdi
00007d2ed8de1420  pop rdx
00007d2ed8de1421  pop rcx
00007d2ed8de1422  pop rax
00007d2ed8de1423  add rsp, 0x08
00007d2ed8de1427  jmp 0x00007D2ED8DDC7B4
00007d2ed8de142c  sub rsp, 0x08
00007d2ed8de1430  push rax
00007d2ed8de1431  push rcx
00007d2ed8de1432  push rdx
00007d2ed8de1433  push rdi
00007d2ed8de1434  push rsi
00007d2ed8de1435  push r8
00007d2ed8de1437  push r9
00007d2ed8de1439  push r10
00007d2ed8de143b  push r11
00007d2ed8de143d  sub rsp, 0xF0
00007d2ed8de1444  vmovaps [rsp], xmm0
00007d2ed8de1449  vmovaps [rsp+0x10], xmm1
00007d2ed8de144f  vmovaps [rsp+0x20], xmm2
00007d2ed8de1455  vmovaps [rsp+0x30], xmm3
00007d2ed8de145b  vmovaps [rsp+0x40], xmm4
00007d2ed8de1461  vmovaps [rsp+0x50], xmm5
00007d2ed8de1467  vmovaps [rsp+0x60], xmm6
00007d2ed8de146d  vmovaps [rsp+0x70], xmm7
00007d2ed8de1473  vmovaps [rsp+0x80], xmm8
00007d2ed8de147c  vmovaps [rsp+0x90], xmm10
00007d2ed8de1485  vmovaps [rsp+0xA0], xmm11
00007d2ed8de148e  vmovaps [rsp+0xB0], xmm12
00007d2ed8de1497  vmovaps [rsp+0xC0], xmm13
00007d2ed8de14a0  vmovaps [rsp+0xD0], xmm14
00007d2ed8de14a9  vmovaps [rsp+0xE0], xmm15
00007d2ed8de14b2  sub rsp, 0x30
00007d2ed8de14b6  movaps [rsp], xmm9
00007d2ed8de14bb  movaps [rsp+0x10], xmm13
00007d2ed8de14c1  movaps [rsp+0x20], xmm15
00007d2ed8de14c7  lea rdi, [rsp]
00007d2ed8de14cb  mov esi, 0x00
00007d2ed8de14d0  mov rax, 0x648718324530
00007d2ed8de14da  call rax
00007d2ed8de14dc  movaps xmm9, [rsp]
00007d2ed8de14e1  add rsp, 0x30
00007d2ed8de14e5  vmovaps xmm0, [rsp]
00007d2ed8de14ea  vmovaps xmm1, [rsp+0x10]
00007d2ed8de14f0  vmovaps xmm2, [rsp+0x20]
00007d2ed8de14f6  vmovaps xmm3, [rsp+0x30]
00007d2ed8de14fc  vmovaps xmm4, [rsp+0x40]
00007d2ed8de1502  vmovaps xmm5, [rsp+0x50]
00007d2ed8de1508  vmovaps xmm6, [rsp+0x60]
00007d2ed8de150e  vmovaps xmm7, [rsp+0x70]
00007d2ed8de1514  vmovaps xmm8, [rsp+0x80]
00007d2ed8de151d  vmovaps xmm10, [rsp+0x90]
00007d2ed8de1526  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de152f  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de1538  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de1541  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de154a  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de1553  add rsp, 0xF0
00007d2ed8de155a  pop r11
00007d2ed8de155c  pop r10
00007d2ed8de155e  pop r9
00007d2ed8de1560  pop r8
00007d2ed8de1562  pop rsi
00007d2ed8de1563  pop rdi
00007d2ed8de1564  pop rdx
00007d2ed8de1565  pop rcx
00007d2ed8de1566  pop rax
00007d2ed8de1567  add rsp, 0x08
00007d2ed8de156b  jmp 0x00007D2ED8DDC7E2
00007d2ed8de1570  sub rsp, 0x08
00007d2ed8de1574  push rax
00007d2ed8de1575  push rcx
00007d2ed8de1576  push rdx
00007d2ed8de1577  push rdi
00007d2ed8de1578  push rsi
00007d2ed8de1579  push r8
00007d2ed8de157b  push r9
00007d2ed8de157d  push r10
00007d2ed8de157f  push r11
00007d2ed8de1581  sub rsp, 0xF0
00007d2ed8de1588  vmovaps [rsp], xmm0
00007d2ed8de158d  vmovaps [rsp+0x10], xmm1
00007d2ed8de1593  vmovaps [rsp+0x20], xmm2
00007d2ed8de1599  vmovaps [rsp+0x30], xmm3
00007d2ed8de159f  vmovaps [rsp+0x40], xmm4
00007d2ed8de15a5  vmovaps [rsp+0x50], xmm5
00007d2ed8de15ab  vmovaps [rsp+0x60], xmm6
00007d2ed8de15b1  vmovaps [rsp+0x70], xmm7
00007d2ed8de15b7  vmovaps [rsp+0x80], xmm8
00007d2ed8de15c0  vmovaps [rsp+0x90], xmm9
00007d2ed8de15c9  vmovaps [rsp+0xA0], xmm10
00007d2ed8de15d2  vmovaps [rsp+0xB0], xmm11
00007d2ed8de15db  vmovaps [rsp+0xC0], xmm12
00007d2ed8de15e4  vmovaps [rsp+0xD0], xmm13
00007d2ed8de15ed  vmovaps [rsp+0xE0], xmm14
00007d2ed8de15f6  sub rsp, 0x30
00007d2ed8de15fa  movaps [rsp], xmm15
00007d2ed8de15ff  movaps [rsp+0x10], xmm11
00007d2ed8de1605  movaps [rsp+0x20], xmm12
00007d2ed8de160b  lea rdi, [rsp]
00007d2ed8de160f  mov esi, 0x00
00007d2ed8de1614  mov rax, 0x648718324530
00007d2ed8de161e  call rax
00007d2ed8de1620  movaps xmm15, [rsp]
00007d2ed8de1625  add rsp, 0x30
00007d2ed8de1629  vmovaps xmm0, [rsp]
00007d2ed8de162e  vmovaps xmm1, [rsp+0x10]
00007d2ed8de1634  vmovaps xmm2, [rsp+0x20]
00007d2ed8de163a  vmovaps xmm3, [rsp+0x30]
00007d2ed8de1640  vmovaps xmm4, [rsp+0x40]
00007d2ed8de1646  vmovaps xmm5, [rsp+0x50]
00007d2ed8de164c  vmovaps xmm6, [rsp+0x60]
00007d2ed8de1652  vmovaps xmm7, [rsp+0x70]
00007d2ed8de1658  vmovaps xmm8, [rsp+0x80]
00007d2ed8de1661  vmovaps xmm9, [rsp+0x90]
00007d2ed8de166a  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de1673  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de167c  vmovaps xmm12, [rsp+0xC0]
00007d2ed8de1685  vmovaps xmm13, [rsp+0xD0]
00007d2ed8de168e  vmovaps xmm14, [rsp+0xE0]
00007d2ed8de1697  add rsp, 0xF0
00007d2ed8de169e  pop r11
00007d2ed8de16a0  pop r10
00007d2ed8de16a2  pop r9
00007d2ed8de16a4  pop r8
00007d2ed8de16a6  pop rsi
00007d2ed8de16a7  pop rdi
00007d2ed8de16a8  pop rdx
00007d2ed8de16a9  pop rcx
00007d2ed8de16aa  pop rax
00007d2ed8de16ab  add rsp, 0x08
00007d2ed8de16af  jmp 0x00007D2ED8DDC7FD
00007d2ed8de16b4  sub rsp, 0x08
00007d2ed8de16b8  push rax
00007d2ed8de16b9  push rcx
00007d2ed8de16ba  push rdx
00007d2ed8de16bb  push rdi
00007d2ed8de16bc  push rsi
00007d2ed8de16bd  push r8
00007d2ed8de16bf  push r9
00007d2ed8de16c1  push r10
00007d2ed8de16c3  push r11
00007d2ed8de16c5  sub rsp, 0xF0
00007d2ed8de16cc  vmovaps [rsp], xmm0
00007d2ed8de16d1  vmovaps [rsp+0x10], xmm1
00007d2ed8de16d7  vmovaps [rsp+0x20], xmm2
00007d2ed8de16dd  vmovaps [rsp+0x30], xmm3
00007d2ed8de16e3  vmovaps [rsp+0x40], xmm4
00007d2ed8de16e9  vmovaps [rsp+0x50], xmm5
00007d2ed8de16ef  vmovaps [rsp+0x60], xmm6
00007d2ed8de16f5  vmovaps [rsp+0x70], xmm7
00007d2ed8de16fb  vmovaps [rsp+0x80], xmm8
00007d2ed8de1704  vmovaps [rsp+0x90], xmm9
00007d2ed8de170d  vmovaps [rsp+0xA0], xmm10
00007d2ed8de1716  vmovaps [rsp+0xB0], xmm11
00007d2ed8de171f  vmovaps [rsp+0xC0], xmm12
00007d2ed8de1728  vmovaps [rsp+0xD0], xmm14
00007d2ed8de1731  vmovaps [rsp+0xE0], xmm15
00007d2ed8de173a  sub rsp, 0x30
00007d2ed8de173e  movaps [rsp], xmm13
00007d2ed8de1743  movaps [rsp+0x10], xmm10
00007d2ed8de1749  movaps [rsp+0x20], xmm14
00007d2ed8de174f  lea rdi, [rsp]
00007d2ed8de1753  mov esi, 0x00
00007d2ed8de1758  mov rax, 0x648718324530
00007d2ed8de1762  call rax
00007d2ed8de1764  movaps xmm13, [rsp]
00007d2ed8de1769  add rsp, 0x30
00007d2ed8de176d  vmovaps xmm0, [rsp]
00007d2ed8de1772  vmovaps xmm1, [rsp+0x10]
00007d2ed8de1778  vmovaps xmm2, [rsp+0x20]
00007d2ed8de177e  vmovaps xmm3, [rsp+0x30]
00007d2ed8de1784  vmovaps xmm4, [rsp+0x40]
00007d2ed8de178a  vmovaps xmm5, [rsp+0x50]
00007d2ed8de1790  vmovaps xmm6, [rsp+0x60]
00007d2ed8de1796  vmovaps xmm7, [rsp+0x70]
00007d2ed8de179c  vmovaps xmm8, [rsp+0x80]
00007d2ed8de17a5  vmovaps xmm9, [rsp+0x90]
00007d2ed8de17ae  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de17b7  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de17c0  vmovaps xmm12, [rsp+0xC0]
00007d2ed8de17c9  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de17d2  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de17db  add rsp, 0xF0
00007d2ed8de17e2  pop r11
00007d2ed8de17e4  pop r10
00007d2ed8de17e6  pop r9
00007d2ed8de17e8  pop r8
00007d2ed8de17ea  pop rsi
00007d2ed8de17eb  pop rdi
00007d2ed8de17ec  pop rdx
00007d2ed8de17ed  pop rcx
00007d2ed8de17ee  pop rax
00007d2ed8de17ef  add rsp, 0x08
00007d2ed8de17f3  jmp 0x00007D2ED8DDC820
00007d2ed8de17f8  sub rsp, 0x08
00007d2ed8de17fc  push rax
00007d2ed8de17fd  push rcx
00007d2ed8de17fe  push rdx
00007d2ed8de17ff  push rdi
00007d2ed8de1800  push rsi
00007d2ed8de1801  push r8
00007d2ed8de1803  push r9
00007d2ed8de1805  push r10
00007d2ed8de1807  push r11
00007d2ed8de1809  sub rsp, 0xF0
00007d2ed8de1810  vmovaps [rsp], xmm0
00007d2ed8de1815  vmovaps [rsp+0x10], xmm1
00007d2ed8de181b  vmovaps [rsp+0x20], xmm2
00007d2ed8de1821  vmovaps [rsp+0x30], xmm3
00007d2ed8de1827  vmovaps [rsp+0x40], xmm4
00007d2ed8de182d  vmovaps [rsp+0x50], xmm5
00007d2ed8de1833  vmovaps [rsp+0x60], xmm6
00007d2ed8de1839  vmovaps [rsp+0x70], xmm7
00007d2ed8de183f  vmovaps [rsp+0x80], xmm8
00007d2ed8de1848  vmovaps [rsp+0x90], xmm9
00007d2ed8de1851  vmovaps [rsp+0xA0], xmm10
00007d2ed8de185a  vmovaps [rsp+0xB0], xmm11
00007d2ed8de1863  vmovaps [rsp+0xC0], xmm12
00007d2ed8de186c  vmovaps [rsp+0xD0], xmm13
00007d2ed8de1875  vmovaps [rsp+0xE0], xmm15
00007d2ed8de187e  sub rsp, 0x30
00007d2ed8de1882  movaps [rsp], xmm14
00007d2ed8de1887  movaps [rsp+0x10], xmm1
00007d2ed8de188c  movaps [rsp+0x20], xmm7
00007d2ed8de1891  lea rdi, [rsp]
00007d2ed8de1895  mov esi, 0x00
00007d2ed8de189a  mov rax, 0x648718324530
00007d2ed8de18a4  call rax
00007d2ed8de18a6  movaps xmm14, [rsp]
00007d2ed8de18ab  add rsp, 0x30
00007d2ed8de18af  vmovaps xmm0, [rsp]
00007d2ed8de18b4  vmovaps xmm1, [rsp+0x10]
00007d2ed8de18ba  vmovaps xmm2, [rsp+0x20]
00007d2ed8de18c0  vmovaps xmm3, [rsp+0x30]
00007d2ed8de18c6  vmovaps xmm4, [rsp+0x40]
00007d2ed8de18cc  vmovaps xmm5, [rsp+0x50]
00007d2ed8de18d2  vmovaps xmm6, [rsp+0x60]
00007d2ed8de18d8  vmovaps xmm7, [rsp+0x70]
00007d2ed8de18de  vmovaps xmm8, [rsp+0x80]
00007d2ed8de18e7  vmovaps xmm9, [rsp+0x90]
00007d2ed8de18f0  vmovaps xmm10, [rsp+0xA0]
00007d2ed8de18f9  vmovaps xmm11, [rsp+0xB0]
00007d2ed8de1902  vmovaps xmm12, [rsp+0xC0]
00007d2ed8de190b  vmovaps xmm13, [rsp+0xD0]
00007d2ed8de1914  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de191d  add rsp, 0xF0
00007d2ed8de1924  pop r11
00007d2ed8de1926  pop r10
00007d2ed8de1928  pop r9
00007d2ed8de192a  pop r8
00007d2ed8de192c  pop rsi
00007d2ed8de192d  pop rdi
00007d2ed8de192e  pop rdx
00007d2ed8de192f  pop rcx
00007d2ed8de1930  pop rax
00007d2ed8de1931  add rsp, 0x08
00007d2ed8de1935  jmp 0x00007D2ED8DDC843
00007d2ed8de193a  sub rsp, 0x08
00007d2ed8de193e  push rax
00007d2ed8de193f  push rcx
00007d2ed8de1940  push rdx
00007d2ed8de1941  push rdi
00007d2ed8de1942  push rsi
00007d2ed8de1943  push r8
00007d2ed8de1945  push r9
00007d2ed8de1947  push r10
00007d2ed8de1949  push r11
00007d2ed8de194b  sub rsp, 0xF0
00007d2ed8de1952  vmovaps [rsp], xmm0
00007d2ed8de1957  vmovaps [rsp+0x10], xmm2
00007d2ed8de195d  vmovaps [rsp+0x20], xmm3
00007d2ed8de1963  vmovaps [rsp+0x30], xmm4
00007d2ed8de1969  vmovaps [rsp+0x40], xmm5
00007d2ed8de196f  vmovaps [rsp+0x50], xmm6
00007d2ed8de1975  vmovaps [rsp+0x60], xmm7
00007d2ed8de197b  vmovaps [rsp+0x70], xmm8
00007d2ed8de1981  vmovaps [rsp+0x80], xmm9
00007d2ed8de198a  vmovaps [rsp+0x90], xmm10
00007d2ed8de1993  vmovaps [rsp+0xA0], xmm11
00007d2ed8de199c  vmovaps [rsp+0xB0], xmm12
00007d2ed8de19a5  vmovaps [rsp+0xC0], xmm13
00007d2ed8de19ae  vmovaps [rsp+0xD0], xmm14
00007d2ed8de19b7  vmovaps [rsp+0xE0], xmm15
00007d2ed8de19c0  sub rsp, 0x30
00007d2ed8de19c4  movaps [rsp], xmm1
00007d2ed8de19c8  movaps [rsp+0x10], xmm8
00007d2ed8de19ce  movaps [rsp+0x20], xmm9
00007d2ed8de19d4  lea rdi, [rsp]
00007d2ed8de19d8  mov esi, 0x00
00007d2ed8de19dd  mov rax, 0x648718324530
00007d2ed8de19e7  call rax
00007d2ed8de19e9  movaps xmm1, [rsp]
00007d2ed8de19ed  add rsp, 0x30
00007d2ed8de19f1  vmovaps xmm0, [rsp]
00007d2ed8de19f6  vmovaps xmm2, [rsp+0x10]
00007d2ed8de19fc  vmovaps xmm3, [rsp+0x20]
00007d2ed8de1a02  vmovaps xmm4, [rsp+0x30]
00007d2ed8de1a08  vmovaps xmm5, [rsp+0x40]
00007d2ed8de1a0e  vmovaps xmm6, [rsp+0x50]
00007d2ed8de1a14  vmovaps xmm7, [rsp+0x60]
00007d2ed8de1a1a  vmovaps xmm8, [rsp+0x70]
00007d2ed8de1a20  vmovaps xmm9, [rsp+0x80]
00007d2ed8de1a29  vmovaps xmm10, [rsp+0x90]
00007d2ed8de1a32  vmovaps xmm11, [rsp+0xA0]
00007d2ed8de1a3b  vmovaps xmm12, [rsp+0xB0]
00007d2ed8de1a44  vmovaps xmm13, [rsp+0xC0]
00007d2ed8de1a4d  vmovaps xmm14, [rsp+0xD0]
00007d2ed8de1a56  vmovaps xmm15, [rsp+0xE0]
00007d2ed8de1a5f  add rsp, 0xF0
00007d2ed8de1a66  pop r11
00007d2ed8de1a68  pop r10
00007d2ed8de1a6a  pop r9
00007d2ed8de1a6c  pop r8
00007d2ed8de1a6e  pop rsi
00007d2ed8de1a6f  pop rdi
00007d2ed8de1a70  pop rdx
00007d2ed8de1a71  pop rcx
00007d2ed8de1a72  pop rax
00007d2ed8de1a73  add rsp, 0x08
00007d2ed8de1a77  jmp 0x00007D2ED8DDC865
00007d2ed8de1a7c  call 0x00007D2ED8CE5940
00007d2ed8de1a81  jmp 0x00007D2ED8DDC873
00007d2ed8de1a86  call 0x00007D2ED8C0C380
00007d2ed8de1a8b  jmp 0x00007D2ED8DDC87D
00007d2ed8de1a90  call 0x00007D2ED8C0D600
00007d2ed8de1a95  jmp 0x00007D2ED8DDC887
00007d2ed8de1a9a  call 0x00007D2ED8BFF540
00007d2ed8de1a9f  jmp 0x00007D2ED8DDC891
00007d2ed8de1aa4  int3
00007d2ed8de1aa5  nop [rax+rax*1], ax
00007d2ed8de1aae  nop
00007d2ed8de1ab0  mov rax, [r15+0xF8]
00007d2ed8de1ab7  lea r14, [rax+0x140]
00007d2ed8de1abe  mov r12, [r13+r14*1]
00007d2ed8de1ac3  mov [r15+0xE8], r12
00007d2ed8de1aca  lea r14, [rax+0x130]
00007d2ed8de1ad1  mov r12, [r13+r14*1]
00007d2ed8de1ad6  lea r14, [rax+0x138]
00007d2ed8de1add  mov r11, [r13+r14*1]
00007d2ed8de1ae2  movq xmm1, r12
00007d2ed8de1ae7  movq xmm15, r11
00007d2ed8de1aec  movq xmm1, xmm1
00007d2ed8de1af0  movq xmm1, xmm1
00007d2ed8de1af4  movaps [r15+0x1A0], xmm1
00007d2ed8de1afc  movq xmm15, xmm15
00007d2ed8de1b01  movq xmm15, xmm15
00007d2ed8de1b06  movaps [r15+0x190], xmm15
00007d2ed8de1b0e  lea r14, [rax+0x120]
00007d2ed8de1b15  mov r12, [r13+r14*1]
00007d2ed8de1b1a  lea r14, [rax+0x128]
00007d2ed8de1b21  mov r11, [r13+r14*1]
00007d2ed8de1b26  movq xmm1, r12
00007d2ed8de1b2b  movq xmm15, r11
00007d2ed8de1b30  movq xmm1, xmm1
00007d2ed8de1b34  movq xmm1, xmm1
00007d2ed8de1b38  movaps [r15+0x1C0], xmm1
00007d2ed8de1b40  movq xmm15, xmm15
00007d2ed8de1b45  movq xmm15, xmm15
00007d2ed8de1b4a  movaps [r15+0x1B0], xmm15
00007d2ed8de1b52  lea r14, [rax+0x110]
00007d2ed8de1b59  mov r12, [r13+r14*1]
00007d2ed8de1b5e  lea r14, [rax+0x118]
00007d2ed8de1b65  mov r11, [r13+r14*1]
00007d2ed8de1b6a  movq xmm1, r12
00007d2ed8de1b6f  movq xmm15, r11
00007d2ed8de1b74  movq xmm1, xmm1
00007d2ed8de1b78  movq xmm1, xmm1
00007d2ed8de1b7c  movaps [r15+0x1E0], xmm1
00007d2ed8de1b84  movq xmm15, xmm15
00007d2ed8de1b89  movq xmm15, xmm15
00007d2ed8de1b8e  movaps [r15+0x1D0], xmm15
00007d2ed8de1b96  lea r14, [rax+0x100]
00007d2ed8de1b9d  mov r12, [r13+r14*1]
00007d2ed8de1ba2  lea r14, [rax+0x108]
00007d2ed8de1ba9  mov r11, [r13+r14*1]
00007d2ed8de1bae  movq xmm1, r12
00007d2ed8de1bb3  movq xmm15, r11
00007d2ed8de1bb8  movq xmm1, xmm1
00007d2ed8de1bbc  movq xmm1, xmm1
00007d2ed8de1bc0  movaps [r15+0x200], xmm1
00007d2ed8de1bc8  movq xmm15, xmm15
00007d2ed8de1bcd  movq xmm15, xmm15
00007d2ed8de1bd2  movaps [r15+0x1F0], xmm15
00007d2ed8de1bda  mov qword ptr [r15+0x40], 0x430000
00007d2ed8de1be2  mov r14d, 0x430510
00007d2ed8de1be8  mov r12, [r13+r14*1]
00007d2ed8de1bed  movq xmm1, r12
00007d2ed8de1bf2  lea r14, [rax+0x150]
00007d2ed8de1bf9  mov [r15+0xF8], r14
00007d2ed8de1c00  mov rax, [r15+0x50]
00007d2ed8de1c04  movups xmm15, [r13+rax*1]
00007d2ed8de1c0a  movaps [r15+0x120], xmm15
00007d2ed8de1c12  mov qword ptr [r15+0x48], 0x10
00007d2ed8de1c1a  xor eax, eax
00007d2ed8de1c1c  mov r14d, 0x10
00007d2ed8de1c22  mov r12d, 0x200
00007d2ed8de1c28  cmp r14, r12
00007d2ed8de1c2b  cmc
00007d2ed8de1c2c  lahf
00007d2ed8de1c2d  seto al
00007d2ed8de1c30  mov [r15+0x108], eax
00007d2ed8de1c37  pextrq rax, xmm15, 0x01
00007d2ed8de1c3e  movq xmm14, rax
00007d2ed8de1c43  movaps [r15+0x130], xmm14
00007d2ed8de1c4b  movq rax, xmm1
00007d2ed8de1c50  movq r14, xmm15
00007d2ed8de1c55  vmovq xmm1, rax
00007d2ed8de1c5a  vmovq xmm15, r14
00007d2ed8de1c5f  movaps xmm13, xmm1
00007d2ed8de1c63  addsd xmm13, xmm15
00007d2ed8de1c68  ucomisd xmm13, xmm13
00007d2ed8de1c6d  jp 0x00007D2ED8DE1D86
00007d2ed8de1c73  movq xmm13, xmm13
00007d2ed8de1c78  movq rax, xmm13
00007d2ed8de1c7d  movq r14, xmm14
00007d2ed8de1c82  vmovq xmm1, rax
00007d2ed8de1c87  vmovq xmm15, r14
00007d2ed8de1c8c  movaps xmm14, xmm1
00007d2ed8de1c90  addsd xmm14, xmm15
00007d2ed8de1c95  ucomisd xmm14, xmm14
00007d2ed8de1c9a  jp 0x00007D2ED8DE1DCE
00007d2ed8de1ca0  movq xmm14, xmm14
00007d2ed8de1ca5  movaps [r15+0x110], xmm14
00007d2ed8de1cad  mov eax, [r15+0x108]
00007d2ed8de1cb4  sahf
00007d2ed8de1cb5  jnz 0x00007D2ED8DE1CE7
00007d2ed8de1cb7  cmp dword ptr [r15+0x318], 0x00
00007d2ed8de1cbf  jz 0x00007D2ED8DE1FE0
00007d2ed8de1cc5  nop [rax+rax*1], ax
00007d2ed8de1cce  nop [rax+rax*1], eax
00007d2ed8de1cd6  mov eax, 0x410490
00007d2ed8de1cdb  mov [r15+0x100], rax
00007d2ed8de1ce2  jmp 0x00007D2ED8BFE110
00007d2ed8de1ce7  cmp dword ptr [r15+0x318], 0x00
00007d2ed8de1cef  jz 0x00007D2ED8DE1E20
00007d2ed8de1cf5  nop [rax+rax*1], ax
00007d2ed8de1cfe  nop [rax+rax*1], eax
00007d2ed8de1d06  mov eax, 0x410474
00007d2ed8de1d0b  mov [r15+0x100], rax
00007d2ed8de1d12  jmp 0x00007D2ED8BFE110
00007d2ed8de1d17  int3
00007d2ed8de1d18  call 0x00007D2ED8CE27E0
00007d2ed8de1d1d  jmp 0x00007D2ED8DE1AC3
00007d2ed8de1d22  call 0x00007D2ED8CE27E0
00007d2ed8de1d27  jmp 0x00007D2ED8DE1AD6
00007d2ed8de1d2c  call 0x00007D2ED8CE1570
00007d2ed8de1d31  jmp 0x00007D2ED8DE1AE2
00007d2ed8de1d36  call 0x00007D2ED8CE27E0
00007d2ed8de1d3b  jmp 0x00007D2ED8DE1B1A
00007d2ed8de1d40  call 0x00007D2ED8CE1570
00007d2ed8de1d45  jmp 0x00007D2ED8DE1B26
00007d2ed8de1d4a  call 0x00007D2ED8CE27E0
00007d2ed8de1d4f  jmp 0x00007D2ED8DE1B5E
00007d2ed8de1d54  call 0x00007D2ED8CE1570
00007d2ed8de1d59  jmp 0x00007D2ED8DE1B6A
00007d2ed8de1d5e  call 0x00007D2ED8CE27E0
00007d2ed8de1d63  jmp 0x00007D2ED8DE1BA2
00007d2ed8de1d68  call 0x00007D2ED8CE1570
00007d2ed8de1d6d  jmp 0x00007D2ED8DE1BAE
00007d2ed8de1d72  call 0x00007D2ED8CE27E0
00007d2ed8de1d77  jmp 0x00007D2ED8DE1BED
00007d2ed8de1d7c  call 0x00007D2ED8C0E760
00007d2ed8de1d81  jmp 0x00007D2ED8DE1C0A
00007d2ed8de1d86  ucomisd xmm1, xmm15
00007d2ed8de1d8b  jp 0x00007D2ED8DE1D9A
00007d2ed8de1d8d  movaps xmm13, [0x00007D2ED89FE060]
00007d2ed8de1d95  jmp 0x00007D2ED8DE1C73
00007d2ed8de1d9a  vxorps xmm0, xmm1, xmm15
00007d2ed8de1d9f  pextrw eax, xmm0, 0x03
00007d2ed8de1da4  and eax, 0x7FF8
00007d2ed8de1da9  cmp eax, 0x08
00007d2ed8de1dac  jnz 0x00007D2ED8DE1C73
00007d2ed8de1db2  movq rax, xmm15
00007d2ed8de1db7  shl rax, 0x0D
00007d2ed8de1dbb  jbe 0x00007D2ED8DE1C73
00007d2ed8de1dc1  vorps xmm13, xmm15, [0x00007D2ED89FE070]
00007d2ed8de1dc9  jmp 0x00007D2ED8DE1C73
00007d2ed8de1dce  ucomisd xmm1, xmm15
00007d2ed8de1dd3  jp 0x00007D2ED8DE1DE2
00007d2ed8de1dd5  movaps xmm14, [0x00007D2ED89FE060]
00007d2ed8de1ddd  jmp 0x00007D2ED8DE1CA0
00007d2ed8de1de2  vxorps xmm0, xmm1, xmm15
00007d2ed8de1de7  pextrw eax, xmm0, 0x03
00007d2ed8de1dec  and eax, 0x7FF8
00007d2ed8de1df1  cmp eax, 0x08
00007d2ed8de1df4  jnz 0x00007D2ED8DE1CA0
00007d2ed8de1dfa  movq rax, xmm15
00007d2ed8de1dff  shl rax, 0x0D
00007d2ed8de1e03  jbe 0x00007D2ED8DE1CA0
00007d2ed8de1e09  vorps xmm14, xmm15, [0x00007D2ED89FE070]
00007d2ed8de1e11  jmp 0x00007D2ED8DE1CA0
00007d2ed8de1e16  int3
00007d2ed8de1e17  nop [rax+rax*1], ax
00007d2ed8de1e20  mov rax, [r15+0x48]
00007d2ed8de1e24  mov r14, [r15+0x50]
00007d2ed8de1e28  lea r12, [r14+rax*1]
00007d2ed8de1e2c  movups xmm1, [r13+r12*1]
00007d2ed8de1e32  movaps [r15+0x120], xmm1
00007d2ed8de1e3a  lea r14, [rax+0x10]
00007d2ed8de1e3e  mov [r15+0x48], r14
00007d2ed8de1e42  xor eax, eax
00007d2ed8de1e44  mov r12d, 0x200
00007d2ed8de1e4a  cmp r14, r12
00007d2ed8de1e4d  cmc
00007d2ed8de1e4e  lahf
00007d2ed8de1e4f  seto al
00007d2ed8de1e52  mov [r15+0x108], eax
00007d2ed8de1e59  pextrq rax, xmm1, 0x01
00007d2ed8de1e60  movq xmm15, rax
00007d2ed8de1e65  movaps [r15+0x130], xmm15
00007d2ed8de1e6d  movaps xmm14, [r15+0x110]
00007d2ed8de1e75  movq rax, xmm14
00007d2ed8de1e7a  movq r14, xmm1
00007d2ed8de1e7f  vmovq xmm1, rax
00007d2ed8de1e84  vmovq xmm14, r14
00007d2ed8de1e89  movaps xmm13, xmm1
00007d2ed8de1e8d  addsd xmm13, xmm14
00007d2ed8de1e92  ucomisd xmm13, xmm13
00007d2ed8de1e97  jp 0x00007D2ED8DE1F4C
00007d2ed8de1e9d  movq xmm13, xmm13
00007d2ed8de1ea2  movq rax, xmm13
00007d2ed8de1ea7  movq r14, xmm15
00007d2ed8de1eac  vmovq xmm1, rax
00007d2ed8de1eb1  vmovq xmm15, r14
00007d2ed8de1eb6  movaps xmm14, xmm1
00007d2ed8de1eba  addsd xmm14, xmm15
00007d2ed8de1ebf  ucomisd xmm14, xmm14
00007d2ed8de1ec4  jp 0x00007D2ED8DE1F94
00007d2ed8de1eca  movq xmm14, xmm14
00007d2ed8de1ecf  movaps [r15+0x110], xmm14
00007d2ed8de1ed7  mov eax, [r15+0x108]
00007d2ed8de1ede  sahf
00007d2ed8de1edf  jnz 0x00007D2ED8DE1F11
00007d2ed8de1ee1  cmp dword ptr [r15+0x318], 0x00
00007d2ed8de1ee9  jz 0x00007D2ED8DE1FE0
00007d2ed8de1eef  nop [rax+rax*1], ax
00007d2ed8de1ef8  nop [rax+rax*1], eax
00007d2ed8de1f00  mov eax, 0x410490
00007d2ed8de1f05  mov [r15+0x100], rax
00007d2ed8de1f0c  jmp 0x00007D2ED8BFE110
00007d2ed8de1f11  cmp dword ptr [r15+0x318], 0x00
00007d2ed8de1f19  jz 0x00007D2ED8DE1E20
00007d2ed8de1f1f  nop [rax+rax*1], ax
00007d2ed8de1f28  nop [rax+rax*1], eax
00007d2ed8de1f30  mov eax, 0x410474
00007d2ed8de1f35  mov [r15+0x100], rax
00007d2ed8de1f3c  jmp 0x00007D2ED8BFE110
00007d2ed8de1f41  int3
00007d2ed8de1f42  call 0x00007D2ED8CB52F0
00007d2ed8de1f47  jmp 0x00007D2ED8DE1E32
00007d2ed8de1f4c  ucomisd xmm1, xmm14
00007d2ed8de1f51  jp 0x00007D2ED8DE1F60
00007d2ed8de1f53  movaps xmm13, [0x00007D2ED89FE060]
00007d2ed8de1f5b  jmp 0x00007D2ED8DE1E9D
00007d2ed8de1f60  vxorps xmm0, xmm1, xmm14
00007d2ed8de1f65  pextrw eax, xmm0, 0x03
00007d2ed8de1f6a  and eax, 0x7FF8
00007d2ed8de1f6f  cmp eax, 0x08
00007d2ed8de1f72  jnz 0x00007D2ED8DE1E9D
00007d2ed8de1f78  movq rax, xmm14
00007d2ed8de1f7d  shl rax, 0x0D
00007d2ed8de1f81  jbe 0x00007D2ED8DE1E9D
00007d2ed8de1f87  vorps xmm13, xmm14, [0x00007D2ED89FE070]
00007d2ed8de1f8f  jmp 0x00007D2ED8DE1E9D
00007d2ed8de1f94  ucomisd xmm1, xmm15
00007d2ed8de1f99  jp 0x00007D2ED8DE1FA8
00007d2ed8de1f9b  movaps xmm14, [0x00007D2ED89FE060]
00007d2ed8de1fa3  jmp 0x00007D2ED8DE1ECA
00007d2ed8de1fa8  vxorps xmm0, xmm1, xmm15
00007d2ed8de1fad  pextrw eax, xmm0, 0x03
00007d2ed8de1fb2  and eax, 0x7FF8
00007d2ed8de1fb7  cmp eax, 0x08
00007d2ed8de1fba  jnz 0x00007D2ED8DE1ECA
00007d2ed8de1fc0  movq rax, xmm15
00007d2ed8de1fc5  shl rax, 0x0D
00007d2ed8de1fc9  jbe 0x00007D2ED8DE1ECA
00007d2ed8de1fcf  vorps xmm14, xmm15, [0x00007D2ED89FE070]
00007d2ed8de1fd7  jmp 0x00007D2ED8DE1ECA
00007d2ed8de1fdc  int3
00007d2ed8de1fdd  nop [rax], eax
00007d2ed8de1fe0  mov rax, [r15+0x40]
00007d2ed8de1fe4  lea r14, [rax+0x510]
00007d2ed8de1feb  movaps xmm1, [r15+0x110]
00007d2ed8de1ff3  movq rax, xmm1
00007d2ed8de1ff8  mov [r13+r14*1], rax
00007d2ed8de1ffd  mov rax, [r15+0xF0]
00007d2ed8de2004  mov [r15+0x100], rax
00007d2ed8de200b  jmp 0x00007D2ED8DCE5C0
00007d2ed8de2010  int3
00007d2ed8de2011  call 0x00007D2ED8CD5EB0
00007d2ed8de2016  jmp 0x00007D2ED8DE1FFD
00007d2ed8de201b  int3
00007d2ed8de201c  nop [rax], eax
00007d2ed8de2020  mov qword ptr [r15+0x100], 0x04
00007d2ed8de202b  mov esi, 0x00
00007d2ed8de2030  mov edx, 0x09
00007d2ed8de2035  mov rdi, 0x7FFD8350BE60
00007d2ed8de203f  mov rax, 0x6487181B7970
00007d2ed8de2049  call rax
00007d2ed8de204b  cmp dword ptr [r15+0x318], 0x00
00007d2ed8de2053  jnz 0x00007D2ED8BFE110
00007d2ed8de2059  jmp 0x00007D2ED8BFE0A0
00007d2ed8de205e  int3
00007d2ed8de205f  int3
