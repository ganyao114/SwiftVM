00007583d7bce69b  nop [rax+rax*1], eax
00007583d7bce6a0  mov rax, [r15+0xF8]
00007583d7bce6a7  lea r14, [rax-0x1B0]
00007583d7bce6ae  mov [r15+0xF8], r14
00007583d7bce6b5  lea rax, [r14+0x1A0]
00007583d7bce6bc  mov r12, [r15+0xA0]
00007583d7bce6c3  mov r11, [r15+0x98]
00007583d7bce6ca  mov [r13+rax*1], r12
00007583d7bce6cf  lea rax, [r14+0x1A8]
00007583d7bce6d6  mov [r13+rax*1], r11
00007583d7bce6db  mov eax, 0x420A30
00007583d7bce6e0  movups xmm1, [r13+rax*1]
00007583d7bce6e6  mov eax, 0x4209C0
00007583d7bce6eb  movups xmm15, [r13+rax*1]
00007583d7bce6f1  mov eax, 0x420A50
00007583d7bce6f6  movups xmm14, [r13+rax*1]
00007583d7bce6fc  mov eax, 0x4209F0
00007583d7bce701  movups xmm13, [r13+rax*1]
00007583d7bce707  mov qword ptr [r15+0x98], 0x430C60
00007583d7bce712  mov eax, 0x420A60
00007583d7bce717  movups xmm12, [r13+rax*1]
00007583d7bce71d  mov eax, 0x430C60
00007583d7bce722  movups [r13+rax*1], xmm1
00007583d7bce728  mov eax, 0x430C70
00007583d7bce72d  movups [r13+rax*1], xmm15
00007583d7bce733  mov eax, 0x430C80
00007583d7bce738  movups [r13+rax*1], xmm14
00007583d7bce73e  mov eax, 0x430C90
00007583d7bce743  movups [r13+rax*1], xmm13
00007583d7bce749  mov eax, 0x4209B0
00007583d7bce74e  movups xmm14, [r13+rax*1]
00007583d7bce754  mov eax, 0x4209A0
00007583d7bce759  movups xmm13, [r13+rax*1]
00007583d7bce75f  mov eax, 0x430D60
00007583d7bce764  movups [r13+rax*1], xmm1
00007583d7bce76a  mov eax, 0x430D70
00007583d7bce76f  movups [r13+rax*1], xmm15
00007583d7bce775  mov eax, 0x430CA0
00007583d7bce77a  movups [r13+rax*1], xmm12
00007583d7bce780  mov eax, 0x430CB0
00007583d7bce785  movups [r13+rax*1], xmm14
00007583d7bce78b  mov eax, 0x420990
00007583d7bce790  movups xmm1, [r13+rax*1]
00007583d7bce796  mov eax, 0x420A00
00007583d7bce79b  movups xmm15, [r13+rax*1]
00007583d7bce7a1  mov eax, 0x430CC0
00007583d7bce7a6  movups [r13+rax*1], xmm13
00007583d7bce7ac  mov eax, 0x430CD0
00007583d7bce7b1  movups [r13+rax*1], xmm1
00007583d7bce7b7  mov eax, 0x420A10
00007583d7bce7bc  movups xmm1, [r13+rax*1]
00007583d7bce7c2  mov eax, 0x4209E0
00007583d7bce7c7  movups xmm14, [r13+rax*1]
00007583d7bce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007583d7bce7d5  mov eax, 0x430CE0
00007583d7bce7da  movups [r13+rax*1], xmm15
00007583d7bce7e0  mov eax, 0x430CF0
00007583d7bce7e5  movups [r13+rax*1], xmm1
00007583d7bce7eb  mov eax, 0x420A80
00007583d7bce7f0  movups xmm1, [r13+rax*1]
00007583d7bce7f6  mov eax, 0x420A90
00007583d7bce7fb  movups xmm15, [r13+rax*1]
00007583d7bce801  movaps [r15+0x150], xmm15
00007583d7bce809  mov qword ptr [r15+0xA0], 0x3E8
00007583d7bce814  mov eax, 0x430D00
00007583d7bce819  movups [r13+rax*1], xmm14
00007583d7bce81f  mov eax, 0x430D10
00007583d7bce824  movups [r13+rax*1], xmm1
00007583d7bce82a  mov eax, 0x420A70
00007583d7bce82f  movups xmm1, [r13+rax*1]
00007583d7bce835  mov eax, 0x420A20
00007583d7bce83a  movups xmm14, [r13+rax*1]
00007583d7bce840  movaps [r15+0x140], xmm14
00007583d7bce848  lea rax, [r14+0x150]
00007583d7bce84f  movq xmm13, qword ptr [r15+0x200]
00007583d7bce858  movq xmm12, qword ptr [r15+0x1F0]
00007583d7bce861  movq r12, xmm13
00007583d7bce866  movq r11, xmm12
00007583d7bce86b  mov [r13+rax*1], r12
00007583d7bce870  lea rax, [r14+0x158]
00007583d7bce877  mov [r13+rax*1], r11
00007583d7bce87c  mov eax, 0x430D20
00007583d7bce881  movups [r13+rax*1], xmm15
00007583d7bce887  mov eax, 0x430D30
00007583d7bce88c  movups [r13+rax*1], xmm1
00007583d7bce892  mov eax, 0x420A40
00007583d7bce897  movups xmm1, [r13+rax*1]
00007583d7bce89d  mov eax, 0x420AA8
00007583d7bce8a2  mov r12, [r13+rax*1]
00007583d7bce8a7  movq xmm15, r12
00007583d7bce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007583d7bce8b4  mov eax, 0x430D40
00007583d7bce8b9  movups [r13+rax*1], xmm14
00007583d7bce8bf  mov eax, 0x430D50
00007583d7bce8c4  movups [r13+rax*1], xmm1
00007583d7bce8ca  mov eax, 0x420B10
00007583d7bce8cf  movups xmm1, [r13+rax*1]
00007583d7bce8d5  movq rax, xmm15
00007583d7bce8da  mov r12d, 0x430D80
00007583d7bce8e0  mov [r13+r12*1], rax
00007583d7bce8e5  mov eax, 0x420AF0
00007583d7bce8ea  movups xmm15, [r13+rax*1]
00007583d7bce8f0  mov eax, 0x420B00
00007583d7bce8f5  movups xmm14, [r13+rax*1]
00007583d7bce8fb  lea rax, [r14+0x130]
00007583d7bce902  movups [r13+rax*1], xmm1
00007583d7bce908  lea rax, [r14+0x160]
00007583d7bce90f  movq xmm1, qword ptr [r15+0x1E0]
00007583d7bce918  movq xmm13, qword ptr [r15+0x1D0]
00007583d7bce921  movq r12, xmm1
00007583d7bce926  movq r11, xmm13
00007583d7bce92b  mov [r13+rax*1], r12
00007583d7bce930  lea rax, [r14+0x168]
00007583d7bce937  mov [r13+rax*1], r11
00007583d7bce93c  lea rax, [r14+0x110]
00007583d7bce943  movups [r13+rax*1], xmm15
00007583d7bce949  lea rax, [r14+0x120]
00007583d7bce950  movups [r13+rax*1], xmm14
00007583d7bce956  mov eax, 0x420AB0
00007583d7bce95b  movups xmm1, [r13+rax*1]
00007583d7bce961  mov eax, 0x420AC0
00007583d7bce966  movups xmm15, [r13+rax*1]
00007583d7bce96c  movaps [r15+0x120], xmm15
00007583d7bce974  lea rax, [r14+0x170]
00007583d7bce97b  movq xmm14, qword ptr [r15+0x1C0]
00007583d7bce984  movq xmm13, qword ptr [r15+0x1B0]
00007583d7bce98d  movq r12, xmm14
00007583d7bce992  movq r11, xmm13
00007583d7bce997  mov [r13+rax*1], r12
00007583d7bce99c  lea rax, [r14+0x178]
00007583d7bce9a3  mov [r13+rax*1], r11
00007583d7bce9a8  lea rax, [r14+0x180]
00007583d7bce9af  movq xmm14, qword ptr [r15+0x1A0]
00007583d7bce9b8  movq xmm13, qword ptr [r15+0x190]
00007583d7bce9c1  movq r12, xmm14
00007583d7bce9c6  movq r11, xmm13
00007583d7bce9cb  mov [r13+rax*1], r12
00007583d7bce9d0  lea rax, [r14+0x188]
00007583d7bce9d7  mov [r13+rax*1], r11
00007583d7bce9dc  lea rax, [r14+0xD0]
00007583d7bce9e3  movups [r13+rax*1], xmm1
00007583d7bce9e9  lea rax, [r14+0xE0]
00007583d7bce9f0  movups [r13+rax*1], xmm15
00007583d7bce9f6  mov eax, 0x420AD0
00007583d7bce9fb  movups xmm1, [r13+rax*1]
00007583d7bcea01  mov eax, 0x420AE0
00007583d7bcea06  movups xmm15, [r13+rax*1]
00007583d7bcea0c  movaps [r15+0x110], xmm1
00007583d7bcea14  movaps [r15+0x130], xmm15
00007583d7bcea1c  lea rax, [r14+0x190]
00007583d7bcea23  mov r12, [r15+0xE8]
00007583d7bcea2a  mov r11, [r15+0xF0]
00007583d7bcea31  mov [r13+rax*1], r12
00007583d7bcea36  lea rax, [r14+0x198]
00007583d7bcea3d  mov [r13+rax*1], r11
00007583d7bcea42  mov eax, 0x430D88
00007583d7bcea47  mov r12d, 0x421DF8D3
00007583d7bcea4d  mov [r13+rax*1], r12d
00007583d7bcea52  lea rax, [r14+0xF0]
00007583d7bcea59  movups [r13+rax*1], xmm1
00007583d7bcea5f  lea rax, [r14+0x100]
00007583d7bcea66  movups [r13+rax*1], xmm15
00007583d7bcea6c  lea rax, [r14+0xD0]
00007583d7bcea73  mov [r15], rax
00007583d7bcea76  mov qword ptr [r15+0x08], 0x430C60
00007583d7bcea7e  mov qword ptr [r15+0x10], 0x12C
00007583d7bcea86  mov qword ptr [r15+0xF0], 0x410284
00007583d7bcea91  mov r14d, [r15+0x320]
00007583d7bcea98  mov eax, 0x410284
00007583d7bcea9d  mov rcx, 0x7583D7BD07C0
00007583d7bceaa7  mov [r15+r14*8+0x328], rax
00007583d7bceaaf  mov [r15+r14*8+0x368], rcx
00007583d7bceab7  add r14d, 0x01
00007583d7bceabb  and r14d, 0x07
00007583d7bceabf  mov [r15+0x320], r14d
00007583d7bceac6  cmp dword ptr [r15+0x318], 0x00
00007583d7bceace  jz 0x00007583D7BCED70
00007583d7bcead4  nop [rax+rax*1], ax
00007583d7bceadd  nop [rax+rax*1], eax
00007583d7bceae5  mov eax, 0x4106BC
00007583d7bceaea  mov [r15+0x100], rax
00007583d7bceaf1  jmp 0x00007583D79FE110
00007583d7bceaf6  int3
00007583d7bceaf7  call 0x00007583D7A0BC20
00007583d7bceafc  jmp 0x00007583D7BCE6CF
00007583d7bceb01  call 0x00007583D7A0A9A0
00007583d7bceb06  jmp 0x00007583D7BCE6DB
00007583d7bceb0b  call 0x00007583D79FF430
00007583d7bceb10  jmp 0x00007583D7BCE6E6
00007583d7bceb15  call 0x00007583D7A0E760
00007583d7bceb1a  jmp 0x00007583D7BCE6F1
00007583d7bceb1f  call 0x00007583D7A0D4E0
00007583d7bceb24  jmp 0x00007583D7BCE6FC
00007583d7bceb29  call 0x00007583D7A0C260
00007583d7bceb2e  jmp 0x00007583D7BCE707
00007583d7bceb33  call 0x00007583D7A0AFE0
00007583d7bceb38  jmp 0x00007583D7BCE71D
00007583d7bceb3d  call 0x00007583D79FF540
00007583d7bceb42  jmp 0x00007583D7BCE728
00007583d7bceb47  call 0x00007583D7A0E880
00007583d7bceb4c  jmp 0x00007583D7BCE733
00007583d7bceb51  call 0x00007583D7A0D600
00007583d7bceb56  jmp 0x00007583D7BCE73E
00007583d7bceb5b  call 0x00007583D7A0C380
00007583d7bceb60  jmp 0x00007583D7BCE749
00007583d7bceb65  call 0x00007583D7A0D4E0
00007583d7bceb6a  jmp 0x00007583D7BCE754
00007583d7bceb6f  call 0x00007583D7A0C260
00007583d7bceb74  jmp 0x00007583D7BCE75F
00007583d7bceb79  call 0x00007583D79FF540
00007583d7bceb7e  jmp 0x00007583D7BCE76A
00007583d7bceb83  call 0x00007583D7A0E880
00007583d7bceb88  jmp 0x00007583D7BCE775
00007583d7bceb8d  call 0x00007583D7A0B100
00007583d7bceb92  jmp 0x00007583D7BCE780
00007583d7bceb97  call 0x00007583D7A0D600
00007583d7bceb9c  jmp 0x00007583D7BCE78B
00007583d7bceba1  call 0x00007583D79FF430
00007583d7bceba6  jmp 0x00007583D7BCE796
00007583d7bcebab  call 0x00007583D7A0E760
00007583d7bcebb0  jmp 0x00007583D7BCE7A1
00007583d7bcebb5  call 0x00007583D7A0C380
00007583d7bcebba  jmp 0x00007583D7BCE7AC
00007583d7bcebbf  call 0x00007583D79FF540
00007583d7bcebc4  jmp 0x00007583D7BCE7B7
00007583d7bcebc9  call 0x00007583D79FF430
00007583d7bcebce  jmp 0x00007583D7BCE7C2
00007583d7bcebd3  call 0x00007583D7A0D4E0
00007583d7bcebd8  jmp 0x00007583D7BCE7CD
00007583d7bcebdd  call 0x00007583D7A0E880
00007583d7bcebe2  jmp 0x00007583D7BCE7E0
00007583d7bcebe7  call 0x00007583D79FF540
00007583d7bcebec  jmp 0x00007583D7BCE7EB
00007583d7bcebf1  call 0x00007583D79FF430
00007583d7bcebf6  jmp 0x00007583D7BCE7F6
00007583d7bcebfb  call 0x00007583D7A0E760
00007583d7bcec00  jmp 0x00007583D7BCE801
00007583d7bcec05  call 0x00007583D7A0D600
00007583d7bcec0a  jmp 0x00007583D7BCE81F
00007583d7bcec0f  call 0x00007583D79FF540
00007583d7bcec14  jmp 0x00007583D7BCE82A
00007583d7bcec19  call 0x00007583D79FF430
00007583d7bcec1e  jmp 0x00007583D7BCE835
00007583d7bcec23  call 0x00007583D7A0D4E0
00007583d7bcec28  jmp 0x00007583D7BCE840
00007583d7bcec2d  call 0x00007583D7A0BC20
00007583d7bcec32  jmp 0x00007583D7BCE870
00007583d7bcec37  call 0x00007583D7A0A9A0
00007583d7bcec3c  jmp 0x00007583D7BCE87C
00007583d7bcec41  call 0x00007583D7A0E880
00007583d7bcec46  jmp 0x00007583D7BCE887
00007583d7bcec4b  call 0x00007583D79FF540
00007583d7bcec50  jmp 0x00007583D7BCE892
00007583d7bcec55  call 0x00007583D79FF430
00007583d7bcec5a  jmp 0x00007583D7BCE89D
00007583d7bcec5f  call 0x00007583D7A0B720
00007583d7bcec64  jmp 0x00007583D7BCE8A7
00007583d7bcec69  call 0x00007583D7A0D600
00007583d7bcec6e  jmp 0x00007583D7BCE8BF
00007583d7bcec73  call 0x00007583D79FF540
00007583d7bcec78  jmp 0x00007583D7BCE8CA
00007583d7bcec7d  call 0x00007583D79FF430
00007583d7bcec82  jmp 0x00007583D7BCE8D5
00007583d7bcec87  call 0x00007583D7AB4CB0
00007583d7bcec8c  jmp 0x00007583D7BCE8E5
00007583d7bcec91  call 0x00007583D7A0E760
00007583d7bcec96  jmp 0x00007583D7BCE8F0
00007583d7bcec9b  call 0x00007583D7A0D4E0
00007583d7bceca0  jmp 0x00007583D7BCE8FB
00007583d7bceca5  call 0x00007583D79FF540
00007583d7bcecaa  jmp 0x00007583D7BCE908
00007583d7bcecaf  call 0x00007583D7A0BC20
00007583d7bcecb4  jmp 0x00007583D7BCE930
00007583d7bcecb9  call 0x00007583D7A0A9A0
00007583d7bcecbe  jmp 0x00007583D7BCE93C
00007583d7bcecc3  call 0x00007583D7A0E880
00007583d7bcecc8  jmp 0x00007583D7BCE949
00007583d7bceccd  call 0x00007583D7A0D600
00007583d7bcecd2  jmp 0x00007583D7BCE956
00007583d7bcecd7  call 0x00007583D79FF430
00007583d7bcecdc  jmp 0x00007583D7BCE961
00007583d7bcece1  call 0x00007583D7A0E760
00007583d7bcece6  jmp 0x00007583D7BCE96C
00007583d7bceceb  call 0x00007583D7A0BC20
00007583d7bcecf0  jmp 0x00007583D7BCE99C
00007583d7bcecf5  call 0x00007583D7A0A9A0
00007583d7bcecfa  jmp 0x00007583D7BCE9A8
00007583d7bcecff  call 0x00007583D7A0BC20
00007583d7bced04  jmp 0x00007583D7BCE9D0
00007583d7bced09  call 0x00007583D7A0A9A0
00007583d7bced0e  jmp 0x00007583D7BCE9DC
00007583d7bced13  call 0x00007583D79FF540
00007583d7bced18  jmp 0x00007583D7BCE9E9
00007583d7bced1d  call 0x00007583D7A0E880
00007583d7bced22  jmp 0x00007583D7BCE9F6
00007583d7bced27  call 0x00007583D79FF430
00007583d7bced2c  jmp 0x00007583D7BCEA01
00007583d7bced31  call 0x00007583D7A0E760
00007583d7bced36  jmp 0x00007583D7BCEA0C
00007583d7bced3b  call 0x00007583D7A0BC20
00007583d7bced40  jmp 0x00007583D7BCEA36
00007583d7bced45  call 0x00007583D7A0A9A0
00007583d7bced4a  jmp 0x00007583D7BCEA42
00007583d7bced4f  call 0x00007583D7A0BAE0
00007583d7bced54  jmp 0x00007583D7BCEA52
00007583d7bced59  call 0x00007583D79FF540
00007583d7bced5e  jmp 0x00007583D7BCEA5F
00007583d7bced63  call 0x00007583D7A0E880
00007583d7bced68  jmp 0x00007583D7BCEA6C
00007583d7bced6d  int3
00007583d7bced6e  nop
00007583d7bced70  mov rax, [r15]
00007583d7bced73  lea r14, [rax+0x20]
00007583d7bced77  mov r12, [r13+r14*1]
00007583d7bced7c  mov r14, [r15+0x10]
00007583d7bced80  lea r11, [r12+r14*1]
00007583d7bced84  mov [r15+0x40], r11
00007583d7bced88  lea r12, [rax+0x20]
00007583d7bced8c  mov [r13+r12*1], r11
00007583d7bced91  test r14, r14
00007583d7bced94  setz r14b
00007583d7bced98  movzx r14, r14b
00007583d7bced9c  mov [rsp+0x414], r14b
00007583d7bceda4  cmp byte ptr [rsp+0x414], 0x00
00007583d7bcedac  jz 0x00007583D7BCEDDE
00007583d7bcedae  cmp dword ptr [r15+0x318], 0x00
00007583d7bcedb6  mov eax, 0x410934
00007583d7bcedbb  mov [r15+0x100], rax
00007583d7bcedc2  jz 0x00007583D79FE0A0
00007583d7bcedc8  nop [rax+rax*1], eax
00007583d7bcedcd  mov eax, 0x410934
00007583d7bcedd2  mov [r15+0x100], rax
00007583d7bcedd9  jmp 0x00007583D79FE110
00007583d7bcedde  cmp dword ptr [r15+0x318], 0x00
00007583d7bcede6  jz 0x00007583D7BCEE30
00007583d7bcedec  nop [rax+rax*1], ax
00007583d7bcedf5  nop [rax+rax*1], eax
00007583d7bcedfd  mov eax, 0x4106CC
00007583d7bcee02  mov [r15+0x100], rax
00007583d7bcee09  jmp 0x00007583D79FE110
00007583d7bcee0e  int3
00007583d7bcee0f  call 0x00007583D7AE27E0
00007583d7bcee14  jmp 0x00007583D7BCED7C
00007583d7bcee19  call 0x00007583D7AC0860
00007583d7bcee1e  jmp 0x00007583D7BCED91
00007583d7bcee23  int3
00007583d7bcee24  nop [rax+rax*1], ax
00007583d7bcee2d  nop [rax], eax
00007583d7bcee30  mov rax, [r15+0xF8]
00007583d7bcee37  lea r14, [rax-0x150]
00007583d7bcee3e  mov [r15+0xF8], r14
00007583d7bcee45  mov rax, [r15]
00007583d7bcee48  lea r12, [rax+0x68]
00007583d7bcee4c  mov r11, [r13+r12*1]
00007583d7bcee51  mov [r15+0x88], r11
00007583d7bcee58  lea r12, [rax+0x28]
00007583d7bcee5c  mov [r15+0x40], r12
00007583d7bcee60  mov [r15+0x48], r14
00007583d7bcee64  mov qword ptr [r15+0x50], 0x420B20
00007583d7bcee6c  lea rax, [r14+0x100]
00007583d7bcee73  mov r12, [r15+0xE8]
00007583d7bcee7a  mov r11, [r15+0xD8]
00007583d7bcee81  mov [r13+rax*1], r12
00007583d7bcee86  lea rax, [r14+0x108]
00007583d7bcee8d  mov [r13+rax*1], r11
00007583d7bcee92  lea rax, [r14+0x110]
00007583d7bcee99  mov r12, [r15+0xD0]
00007583d7bceea0  mov r11, [r15+0xC8]
00007583d7bceea7  mov [r13+rax*1], r12
00007583d7bceeac  lea rax, [r14+0x118]
00007583d7bceeb3  mov [r13+rax*1], r11
00007583d7bceeb8  lea rax, [r14+0x120]
00007583d7bceebf  mov r12, [r15+0xC0]
00007583d7bceec6  mov r11, [r15+0xB8]
00007583d7bceecd  mov [r13+rax*1], r12
00007583d7bceed2  lea rax, [r14+0x128]
00007583d7bceed9  mov [r13+rax*1], r11
00007583d7bceede  lea rax, [r14+0x130]
00007583d7bceee5  mov r12, [r15+0xB0]
00007583d7bceeec  mov r11, [r15+0xA8]
00007583d7bceef3  mov [r13+rax*1], r12
00007583d7bceef8  lea rax, [r14+0x138]
00007583d7bceeff  mov [r13+rax*1], r11
00007583d7bcef04  lea rax, [r14+0x140]
00007583d7bcef0b  mov r12, [r15+0xA0]
00007583d7bcef12  mov r11, [r15+0x98]
00007583d7bcef19  mov [r13+rax*1], r12
00007583d7bcef1e  lea rax, [r14+0x148]
00007583d7bcef25  mov [r13+rax*1], r11
00007583d7bcef2a  cmp dword ptr [r15+0x318], 0x00
00007583d7bcef32  jz 0x00007583D7BCEFD0
00007583d7bcef38  nop [rax+rax*1], ax
00007583d7bcef41  nop [rax+rax*1], eax
00007583d7bcef49  mov eax, 0x410704
00007583d7bcef4e  mov [r15+0x100], rax
00007583d7bcef55  jmp 0x00007583D79FE110
00007583d7bcef5a  int3
00007583d7bcef5b  call 0x00007583D7AC0370
00007583d7bcef60  jmp 0x00007583D7BCEE51
00007583d7bcef65  call 0x00007583D7A0BC20
00007583d7bcef6a  jmp 0x00007583D7BCEE86
00007583d7bcef6f  call 0x00007583D7A0A9A0
00007583d7bcef74  jmp 0x00007583D7BCEE92
00007583d7bcef79  call 0x00007583D7A0BC20
00007583d7bcef7e  jmp 0x00007583D7BCEEAC
00007583d7bcef83  call 0x00007583D7A0A9A0
00007583d7bcef88  jmp 0x00007583D7BCEEB8
00007583d7bcef8d  call 0x00007583D7A0BC20
00007583d7bcef92  jmp 0x00007583D7BCEED2
00007583d7bcef97  call 0x00007583D7A0A9A0
00007583d7bcef9c  jmp 0x00007583D7BCEEDE
00007583d7bcefa1  call 0x00007583D7A0BC20
00007583d7bcefa6  jmp 0x00007583D7BCEEF8
00007583d7bcefab  call 0x00007583D7A0A9A0
00007583d7bcefb0  jmp 0x00007583D7BCEF04
00007583d7bcefb5  call 0x00007583D7A0BC20
00007583d7bcefba  jmp 0x00007583D7BCEF1E
00007583d7bcefbf  call 0x00007583D7A0A9A0
00007583d7bcefc4  jmp 0x00007583D7BCEF2A
00007583d7bcefc9  int3
00007583d7bcefca  nop [rax+rax*1], ax
00007583d7bcefd0  mov rax, [r15+0x08]
00007583d7bcefd4  movzx r14d, byte ptr [r13+rax*1]
00007583d7bcefda  movzx r14d, r14b
00007583d7bcefde  mov [rsp+0x10], r14d
00007583d7bcefe3  mov r14d, r14d
00007583d7bcefe6  mov [r15+0x58], r14
00007583d7bcefea  lea r14, [rax+0x01]
00007583d7bcefee  mov [r15+0x08], r14
00007583d7bceff2  mov rax, [r15+0x88]
00007583d7bceff9  lea r14, [rax+0x01]
00007583d7bceffd  mov r12, [r15]
00007583d7bcf000  lea r11, [r12+0x68]
00007583d7bcf005  mov [r13+r11*1], r14
00007583d7bcf00a  lea r14, [r12+rax*1]
00007583d7bcf00e  mov [r15+0x60], r14
00007583d7bcf012  lea rax, [r14+0x28]
00007583d7bcf016  mov r11d, [rsp+0x10]
00007583d7bcf01b  movzx r14d, r11b
00007583d7bcf01f  mov [r13+rax*1], r14b
00007583d7bcf024  lea rax, [r12+0x68]
00007583d7bcf029  mov r14, [r13+rax*1]
00007583d7bcf02e  mov [r15+0x88], r14
00007583d7bcf035  xor eax, eax
00007583d7bcf037  mov r12d, 0x40
00007583d7bcf03d  cmp r14, r12
00007583d7bcf040  cmc
00007583d7bcf041  lahf
00007583d7bcf042  seto al
00007583d7bcf045  mov [r15+0x108], eax
00007583d7bcf04c  mov eax, [r15+0x108]
00007583d7bcf053  sahf
00007583d7bcf054  jnz 0x00007583D7BCF086
00007583d7bcf056  cmp dword ptr [r15+0x318], 0x00
00007583d7bcf05e  jz 0x00007583D7BCF170
00007583d7bcf064  nop [rax+rax*1], ax
00007583d7bcf06d  nop [rax+rax*1], eax
00007583d7bcf075  mov eax, 0x410724
00007583d7bcf07a  mov [r15+0x100], rax
00007583d7bcf081  jmp 0x00007583D79FE110
00007583d7bcf086  cmp dword ptr [r15+0x318], 0x00
00007583d7bcf08e  jz 0x00007583D7BCF0E0
00007583d7bcf094  nop [rax+rax*1], ax
00007583d7bcf09d  nop [rax+rax*1], eax
00007583d7bcf0a5  mov eax, 0x4106FC
00007583d7bcf0aa  mov [r15+0x100], rax
00007583d7bcf0b1  jmp 0x00007583D79FE110
00007583d7bcf0b6  int3
00007583d7bcf0b7  call 0x00007583D7A0D860
00007583d7bcf0bc  jmp 0x00007583D7BCEFDA
00007583d7bcf0c1  call 0x00007583D7AB36E0
00007583d7bcf0c6  jmp 0x00007583D7BCF00A
00007583d7bcf0cb  call 0x00007583D7A0DD60
00007583d7bcf0d0  jmp 0x00007583D7BCF024
00007583d7bcf0d5  call 0x00007583D7A0DC20
00007583d7bcf0da  jmp 0x00007583D7BCF02E
00007583d7bcf0df  int3
00007583d7bcf0e0  mov rax, [r15+0x10]
00007583d7bcf0e4  lea r14, [rax-0x01]
00007583d7bcf0e8  mov [r15+0x10], r14
00007583d7bcf0ec  test r14, r14
00007583d7bcf0ef  setz r14b
00007583d7bcf0f3  movzx r14, r14b
00007583d7bcf0f7  mov [rsp+0x414], r14b
00007583d7bcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007583d7bcf107  jz 0x00007583D7BCF139
00007583d7bcf109  cmp dword ptr [r15+0x318], 0x00
00007583d7bcf111  jz 0x00007583D7BD0670
00007583d7bcf117  nop [rax+rax*1], ax
00007583d7bcf120  nop [rax+rax*1], eax
00007583d7bcf128  mov eax, 0x41091C
00007583d7bcf12d  mov [r15+0x100], rax
00007583d7bcf134  jmp 0x00007583D79FE110
00007583d7bcf139  cmp dword ptr [r15+0x318], 0x00
00007583d7bcf141  jz 0x00007583D7BCEFD0
00007583d7bcf147  nop [rax+rax*1], ax
00007583d7bcf150  nop [rax+rax*1], eax
00007583d7bcf158  mov eax, 0x410704
00007583d7bcf15d  mov [r15+0x100], rax
00007583d7bcf164  jmp 0x00007583D79FE110
00007583d7bcf169  int3
00007583d7bcf16a  int3
00007583d7bcf16b  nop [rax+rax*1], eax
00007583d7bcf170  mov rax, [r15+0x40]
00007583d7bcf174  movzx r14d, byte ptr [r13+rax*1]
00007583d7bcf17a  movaps xmm1, [r15+0x110]
00007583d7bcf182  pinsrb xmm1, r14d, 0x00
00007583d7bcf189  lea r14, [rax+0x01]
00007583d7bcf18d  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf193  movaps xmm15, [r15+0x120]
00007583d7bcf19b  pinsrb xmm15, r12d, 0x00
00007583d7bcf1a2  lea r14, [rax+0x02]
00007583d7bcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf1ac  movaps xmm14, [r15+0x130]
00007583d7bcf1b4  pinsrb xmm14, r12d, 0x00
00007583d7bcf1bb  lea r14, [rax+0x03]
00007583d7bcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf1c5  movaps xmm13, [r15+0x140]
00007583d7bcf1cd  pinsrb xmm13, r12d, 0x00
00007583d7bcf1d4  lea r14, [rax+0x04]
00007583d7bcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf1de  pinsrb xmm1, r12d, 0x01
00007583d7bcf1e5  lea r14, [rax+0x05]
00007583d7bcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf1ef  pinsrb xmm15, r12d, 0x01
00007583d7bcf1f6  lea r14, [rax+0x06]
00007583d7bcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf200  pinsrb xmm14, r12d, 0x01
00007583d7bcf207  lea r14, [rax+0x07]
00007583d7bcf20b  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf211  pinsrb xmm13, r12d, 0x01
00007583d7bcf218  lea r14, [rax+0x08]
00007583d7bcf21c  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf222  pinsrb xmm1, r12d, 0x02
00007583d7bcf229  lea r14, [rax+0x09]
00007583d7bcf22d  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf233  pinsrb xmm15, r12d, 0x02
00007583d7bcf23a  lea r14, [rax+0x0A]
00007583d7bcf23e  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf244  pinsrb xmm14, r12d, 0x02
00007583d7bcf24b  lea r14, [rax+0x0B]
00007583d7bcf24f  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf255  pinsrb xmm13, r12d, 0x02
00007583d7bcf25c  lea r14, [rax+0x0C]
00007583d7bcf260  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf266  pinsrb xmm1, r12d, 0x03
00007583d7bcf26d  lea r14, [rax+0x0D]
00007583d7bcf271  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf277  pinsrb xmm15, r12d, 0x03
00007583d7bcf27e  lea r14, [rax+0x0E]
00007583d7bcf282  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf288  pinsrb xmm14, r12d, 0x03
00007583d7bcf28f  lea r14, [rax+0x0F]
00007583d7bcf293  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf299  pinsrb xmm13, r12d, 0x03
00007583d7bcf2a0  lea r14, [rax+0x10]
00007583d7bcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf2aa  pinsrb xmm1, r12d, 0x04
00007583d7bcf2b1  lea r14, [rax+0x11]
00007583d7bcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf2bb  pinsrb xmm15, r12d, 0x04
00007583d7bcf2c2  lea r14, [rax+0x12]
00007583d7bcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf2cc  pinsrb xmm14, r12d, 0x04
00007583d7bcf2d3  lea r14, [rax+0x13]
00007583d7bcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf2dd  pinsrb xmm13, r12d, 0x04
00007583d7bcf2e4  lea r14, [rax+0x14]
00007583d7bcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf2ee  pinsrb xmm1, r12d, 0x05
00007583d7bcf2f5  lea r14, [rax+0x15]
00007583d7bcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf2ff  pinsrb xmm15, r12d, 0x05
00007583d7bcf306  lea r14, [rax+0x16]
00007583d7bcf30a  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf310  pinsrb xmm14, r12d, 0x05
00007583d7bcf317  lea r14, [rax+0x17]
00007583d7bcf31b  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf321  pinsrb xmm13, r12d, 0x05
00007583d7bcf328  lea r14, [rax+0x18]
00007583d7bcf32c  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf332  pinsrb xmm1, r12d, 0x06
00007583d7bcf339  lea r14, [rax+0x19]
00007583d7bcf33d  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf343  pinsrb xmm15, r12d, 0x06
00007583d7bcf34a  lea r14, [rax+0x1A]
00007583d7bcf34e  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf354  pinsrb xmm14, r12d, 0x06
00007583d7bcf35b  lea r14, [rax+0x1B]
00007583d7bcf35f  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf365  pinsrb xmm13, r12d, 0x06
00007583d7bcf36c  lea r14, [rax+0x1C]
00007583d7bcf370  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf376  pinsrb xmm1, r12d, 0x07
00007583d7bcf37d  lea r14, [rax+0x1D]
00007583d7bcf381  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf387  pinsrb xmm15, r12d, 0x07
00007583d7bcf38e  lea r14, [rax+0x1E]
00007583d7bcf392  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf398  pinsrb xmm14, r12d, 0x07
00007583d7bcf39f  lea r14, [rax+0x1F]
00007583d7bcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf3a9  pinsrb xmm13, r12d, 0x07
00007583d7bcf3b0  lea r14, [rax+0x20]
00007583d7bcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf3ba  pinsrb xmm1, r12d, 0x08
00007583d7bcf3c1  lea r14, [rax+0x21]
00007583d7bcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf3cb  pinsrb xmm15, r12d, 0x08
00007583d7bcf3d2  lea r14, [rax+0x22]
00007583d7bcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf3dc  pinsrb xmm14, r12d, 0x08
00007583d7bcf3e3  lea r14, [rax+0x23]
00007583d7bcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf3ed  pinsrb xmm13, r12d, 0x08
00007583d7bcf3f4  lea r14, [rax+0x24]
00007583d7bcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf3fe  pinsrb xmm1, r12d, 0x09
00007583d7bcf405  lea r14, [rax+0x25]
00007583d7bcf409  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf40f  pinsrb xmm15, r12d, 0x09
00007583d7bcf416  lea r14, [rax+0x26]
00007583d7bcf41a  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf420  pinsrb xmm14, r12d, 0x09
00007583d7bcf427  lea r14, [rax+0x27]
00007583d7bcf42b  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf431  pinsrb xmm13, r12d, 0x09
00007583d7bcf438  lea r14, [rax+0x28]
00007583d7bcf43c  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf442  pinsrb xmm1, r12d, 0x0A
00007583d7bcf449  lea r14, [rax+0x29]
00007583d7bcf44d  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf453  pinsrb xmm15, r12d, 0x0A
00007583d7bcf45a  lea r14, [rax+0x2A]
00007583d7bcf45e  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf464  pinsrb xmm14, r12d, 0x0A
00007583d7bcf46b  lea r14, [rax+0x2B]
00007583d7bcf46f  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf475  pinsrb xmm13, r12d, 0x0A
00007583d7bcf47c  lea r14, [rax+0x2C]
00007583d7bcf480  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf486  pinsrb xmm1, r12d, 0x0B
00007583d7bcf48d  lea r14, [rax+0x2D]
00007583d7bcf491  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf497  pinsrb xmm15, r12d, 0x0B
00007583d7bcf49e  lea r14, [rax+0x2E]
00007583d7bcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf4a8  pinsrb xmm14, r12d, 0x0B
00007583d7bcf4af  lea r14, [rax+0x2F]
00007583d7bcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf4b9  pinsrb xmm13, r12d, 0x0B
00007583d7bcf4c0  lea r14, [rax+0x30]
00007583d7bcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf4ca  pinsrb xmm1, r12d, 0x0C
00007583d7bcf4d1  lea r14, [rax+0x31]
00007583d7bcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf4db  pinsrb xmm15, r12d, 0x0C
00007583d7bcf4e2  lea r14, [rax+0x32]
00007583d7bcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf4ec  pinsrb xmm14, r12d, 0x0C
00007583d7bcf4f3  lea r14, [rax+0x33]
00007583d7bcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf4fd  pinsrb xmm13, r12d, 0x0C
00007583d7bcf504  lea r14, [rax+0x34]
00007583d7bcf508  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf50e  pinsrb xmm1, r12d, 0x0D
00007583d7bcf515  lea r14, [rax+0x35]
00007583d7bcf519  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf51f  pinsrb xmm15, r12d, 0x0D
00007583d7bcf526  lea r14, [rax+0x36]
00007583d7bcf52a  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf530  pinsrb xmm14, r12d, 0x0D
00007583d7bcf537  lea r14, [rax+0x37]
00007583d7bcf53b  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf541  pinsrb xmm13, r12d, 0x0D
00007583d7bcf548  lea r14, [rax+0x38]
00007583d7bcf54c  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf552  pinsrb xmm1, r12d, 0x0E
00007583d7bcf559  lea r14, [rax+0x39]
00007583d7bcf55d  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf563  pinsrb xmm15, r12d, 0x0E
00007583d7bcf56a  lea r14, [rax+0x3A]
00007583d7bcf56e  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf574  pinsrb xmm14, r12d, 0x0E
00007583d7bcf57b  lea r14, [rax+0x3B]
00007583d7bcf57f  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf585  pinsrb xmm13, r12d, 0x0E
00007583d7bcf58c  lea r14, [rax+0x3C]
00007583d7bcf590  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf596  pinsrb xmm1, r12d, 0x0F
00007583d7bcf59d  movaps [r15+0x110], xmm1
00007583d7bcf5a5  lea r14, [rax+0x3D]
00007583d7bcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf5af  pinsrb xmm15, r12d, 0x0F
00007583d7bcf5b6  movaps [r15+0x120], xmm15
00007583d7bcf5be  lea r14, [rax+0x3E]
00007583d7bcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007583d7bcf5c8  pinsrb xmm14, r12d, 0x0F
00007583d7bcf5cf  movaps [r15+0x130], xmm14
00007583d7bcf5d7  lea r14, [rax+0x3F]
00007583d7bcf5db  movzx eax, byte ptr [r13+r14*1]
00007583d7bcf5e1  pinsrb xmm13, eax, 0x0F
00007583d7bcf5e8  movaps [r15+0x140], xmm13
00007583d7bcf5f0  movq xmm1, qword ptr [r15+0x120]
00007583d7bcf5f9  pmovzxbw xmm1, xmm1
00007583d7bcf5fe  psllw xmm1, 0x00
00007583d7bcf603  movaps [r15+0x150], xmm1
00007583d7bcf60b  movq xmm1, qword ptr [r15+0x130]
00007583d7bcf614  pmovzxbw xmm1, xmm1
00007583d7bcf619  psllw xmm1, 0x00
00007583d7bcf61e  movaps [r15+0x160], xmm1
00007583d7bcf626  movq xmm1, qword ptr [r15+0x110]
00007583d7bcf62f  pmovzxbw xmm1, xmm1
00007583d7bcf634  psllw xmm1, 0x00
00007583d7bcf639  movaps [r15+0x170], xmm1
00007583d7bcf641  movaps xmm15, [r15+0x110]
00007583d7bcf649  pextrq rax, xmm15, 0x01
00007583d7bcf650  movq xmm15, rax
00007583d7bcf655  pmovzxbw xmm15, xmm15
00007583d7bcf65b  psllw xmm15, 0x00
00007583d7bcf661  movaps [r15+0x180], xmm15
00007583d7bcf669  movaps xmm14, [r15+0x120]
00007583d7bcf671  pextrq rax, xmm14, 0x01
00007583d7bcf678  movq xmm14, rax
00007583d7bcf67d  pmovzxbw xmm14, xmm14
00007583d7bcf683  psllw xmm14, 0x00
00007583d7bcf689  movaps [r15+0x210], xmm14
00007583d7bcf691  movaps xmm13, [r15+0x130]
00007583d7bcf699  pextrq rax, xmm13, 0x01
00007583d7bcf6a0  movq xmm13, rax
00007583d7bcf6a5  pmovzxbw xmm13, xmm13
00007583d7bcf6ab  psllw xmm13, 0x00
00007583d7bcf6b1  movaps [r15+0x220], xmm13
00007583d7bcf6b9  movq xmm12, qword ptr [r15+0x140]
00007583d7bcf6c2  pmovzxbw xmm12, xmm12
00007583d7bcf6c8  psllw xmm12, 0x00
00007583d7bcf6ce  movaps [r15+0x250], xmm12
00007583d7bcf6d6  movaps xmm12, [r15+0x140]
00007583d7bcf6de  pextrq rax, xmm12, 0x01
00007583d7bcf6e5  movq xmm12, rax
00007583d7bcf6ea  pmovzxbw xmm12, xmm12
00007583d7bcf6f0  psllw xmm12, 0x00
00007583d7bcf6f6  movaps [r15+0x110], xmm12
00007583d7bcf6fe  movq xmm11, qword ptr [r15+0x150]
00007583d7bcf707  pmovzxwd xmm11, xmm11
00007583d7bcf70d  pslld xmm11, 0x10
00007583d7bcf713  movq xmm10, qword ptr [r15+0x160]
00007583d7bcf71c  pmovzxwd xmm10, xmm10
00007583d7bcf722  pslld xmm10, 0x08
00007583d7bcf728  pextrq rax, xmm1, 0x01
00007583d7bcf72f  movq xmm1, rax
00007583d7bcf734  pmovzxwd xmm1, xmm1
00007583d7bcf739  pslld xmm1, 0x00
00007583d7bcf73e  movaps [r15+0x260], xmm1
00007583d7bcf746  pextrq rax, xmm15, 0x01
00007583d7bcf74d  movq xmm15, rax
00007583d7bcf752  pmovzxwd xmm15, xmm15
00007583d7bcf758  pslld xmm15, 0x00
00007583d7bcf75e  movaps [r15+0x270], xmm15
00007583d7bcf766  movq xmm9, qword ptr [r15+0x170]
00007583d7bcf76f  pmovzxwd xmm9, xmm9
00007583d7bcf775  pslld xmm9, 0x00
00007583d7bcf77b  pextrq rax, xmm14, 0x01
00007583d7bcf782  movq xmm14, rax
00007583d7bcf787  pmovzxwd xmm14, xmm14
00007583d7bcf78d  pslld xmm14, 0x10
00007583d7bcf793  movaps [r15+0x280], xmm14
00007583d7bcf79b  movq xmm8, qword ptr [r15+0x180]
00007583d7bcf7a4  pmovzxwd xmm8, xmm8
00007583d7bcf7aa  pslld xmm8, 0x00
00007583d7bcf7b0  movq xmm7, qword ptr [r15+0x210]
00007583d7bcf7b9  pmovzxwd xmm7, xmm7
00007583d7bcf7be  pslld xmm7, 0x10
00007583d7bcf7c3  movaps xmm6, [r15+0x150]
00007583d7bcf7cb  pextrq rax, xmm6, 0x01
00007583d7bcf7d2  movq xmm6, rax
00007583d7bcf7d7  pmovzxwd xmm6, xmm6
00007583d7bcf7dc  pslld xmm6, 0x10
00007583d7bcf7e1  por xmm11, xmm10
00007583d7bcf7e6  movaps [r15+0x230], xmm11
00007583d7bcf7ee  pextrq rax, xmm13, 0x01
00007583d7bcf7f5  movq xmm13, rax
00007583d7bcf7fa  pmovzxwd xmm13, xmm13
00007583d7bcf800  pslld xmm13, 0x08
00007583d7bcf806  movaps [r15+0x240], xmm13
00007583d7bcf80e  movq xmm10, qword ptr [r15+0x220]
00007583d7bcf817  pmovzxwd xmm10, xmm10
00007583d7bcf81d  pslld xmm10, 0x08
00007583d7bcf823  movaps xmm5, [r15+0x160]
00007583d7bcf82b  pextrq rax, xmm5, 0x01
00007583d7bcf832  movq xmm5, rax
00007583d7bcf837  pmovzxwd xmm5, xmm5
00007583d7bcf83c  pslld xmm5, 0x08
00007583d7bcf841  pslld xmm9, 0x18
00007583d7bcf847  pslld xmm15, 0x18
00007583d7bcf84d  pslld xmm8, 0x18
00007583d7bcf853  movq xmm4, qword ptr [r15+0x250]
00007583d7bcf85c  pmovzxwd xmm4, xmm4
00007583d7bcf861  pslld xmm4, 0x00
00007583d7bcf866  por xmm14, xmm13
00007583d7bcf86b  por xmm7, xmm10
00007583d7bcf870  movaps [r15+0x210], xmm7
00007583d7bcf878  pslld xmm1, 0x18
00007583d7bcf87d  movaps [r15+0x220], xmm1
00007583d7bcf885  por xmm6, xmm5
00007583d7bcf889  por xmm11, xmm9
00007583d7bcf88e  movaps [r15+0x160], xmm11
00007583d7bcf896  pextrq rax, xmm12, 0x01
00007583d7bcf89d  movq xmm13, rax
00007583d7bcf8a2  pmovzxwd xmm13, xmm13
00007583d7bcf8a8  pslld xmm13, 0x00
00007583d7bcf8ae  movaps [r15+0x170], xmm13
00007583d7bcf8b6  movq xmm12, qword ptr [r15+0x110]
00007583d7bcf8bf  pmovzxwd xmm12, xmm12
00007583d7bcf8c5  pslld xmm12, 0x00
00007583d7bcf8cb  por xmm14, xmm15
00007583d7bcf8d0  por xmm7, xmm8
00007583d7bcf8d5  movaps xmm15, [r15+0x250]
00007583d7bcf8dd  pextrq rax, xmm15, 0x01
00007583d7bcf8e4  movq xmm15, rax
00007583d7bcf8e9  pmovzxwd xmm15, xmm15
00007583d7bcf8ef  pslld xmm15, 0x00
00007583d7bcf8f5  movaps [r15+0x180], xmm15
00007583d7bcf8fd  por xmm6, xmm1
00007583d7bcf901  movaps [r15+0x150], xmm6
00007583d7bcf909  por xmm11, xmm4
00007583d7bcf90e  movaps [r15+0x140], xmm11
00007583d7bcf916  por xmm7, xmm12
00007583d7bcf91b  movaps [r15+0x110], xmm7
00007583d7bcf923  por xmm14, xmm13
00007583d7bcf928  movaps [r15+0x120], xmm14
00007583d7bcf930  por xmm6, xmm15
00007583d7bcf935  movaps [r15+0x130], xmm6
00007583d7bcf93d  mov rax, [r15+0xF8]
00007583d7bcf944  lea r14, [rax+0x20]
00007583d7bcf948  movups [r13+r14*1], xmm7
00007583d7bcf94e  lea r14, [rax+0x30]
00007583d7bcf952  movups [r13+r14*1], xmm14
00007583d7bcf958  movups [r13+rax*1], xmm11
00007583d7bcf95e  lea r14, [rax+0x10]
00007583d7bcf962  movups [r13+r14*1], xmm6
00007583d7bcf968  mov r14d, [r13+rax*1]
00007583d7bcf96d  mov rax, [r15+0x48]
00007583d7bcf971  mov [r15+0x68], rax
00007583d7bcf975  mov qword ptr [r15+0x58], 0x04
00007583d7bcf97d  lea r12, [rax+0x04]
00007583d7bcf981  mov r11d, [r13+r12*1]
00007583d7bcf986  mov [rsp+0x10], r11d
00007583d7bcf98b  mov r11d, r11d
00007583d7bcf98e  mov [r15+0x70], r11
00007583d7bcf992  lea r12, [rax+0x38]
00007583d7bcf996  mov r11d, [r13+r12*1]
00007583d7bcf99b  lea r12, [rax+0x24]
00007583d7bcf99f  mov r10d, [r13+r12*1]
00007583d7bcf9a4  mov [rsp+0x20], r10d
00007583d7bcf9a9  mov r10d, r10d
00007583d7bcf9ac  mov [r15+0x90], r10
00007583d7bcf9b3  mov [rsp+0x30], rax
00007583d7bcf9b8  xor eax, eax
00007583d7bcf9ba  mov r12d, 0x04
00007583d7bcf9c0  mov r10d, 0xC0
00007583d7bcf9c6  cmp r12, r10
00007583d7bcf9c9  cmc
00007583d7bcf9ca  lahf
00007583d7bcf9cb  seto al
00007583d7bcf9ce  mov [r15+0x108], eax
00007583d7bcf9d5  mov eax, [rsp+0x10]
00007583d7bcf9d9  mov r12d, [rsp+0x10]
00007583d7bcf9de  shrd eax, r12d, 0x07
00007583d7bcf9e3  mov [rsp+0x10], r11d
00007583d7bcf9e8  mov r10d, [rsp+0x10]
00007583d7bcf9ed  shrd r11d, r10d, 0x11
00007583d7bcf9f2  mov r9d, [rsp+0x20]
00007583d7bcf9f7  lea r8d, [r9d+r14d*1]
00007583d7bcf9fc  rorx r14d, r12d, 0x12
00007583d7bcfa02  xor eax, r14d
00007583d7bcfa05  rorx r14d, r10d, 0x13
00007583d7bcfa0b  xor r11d, r14d
00007583d7bcfa0e  mov [rsp+0x10], r11d
00007583d7bcfa13  mov r11d, r11d
00007583d7bcfa16  mov [r15+0x88], r11
00007583d7bcfa1d  mov [rsp+0x20], r12d
00007583d7bcfa22  shr r12d, 0x03
00007583d7bcfa26  xor eax, r12d
00007583d7bcfa29  mov [rsp+0x40], eax
00007583d7bcfa2d  mov eax, eax
00007583d7bcfa2f  mov [r15+0x80], rax
00007583d7bcfa36  shr r10d, 0x0A
00007583d7bcfa3a  mov eax, [rsp+0x10]
00007583d7bcfa3e  xor eax, r10d
00007583d7bcfa41  mov [rsp+0x10], eax
00007583d7bcfa45  mov eax, eax
00007583d7bcfa47  mov [r15+0x78], rax
00007583d7bcfa4b  mov eax, [rsp+0x40]
00007583d7bcfa4f  lea r14d, [r8d+eax*1]
00007583d7bcfa54  mov eax, [rsp+0x10]
00007583d7bcfa58  lea r12d, [r14d+eax*1]
00007583d7bcfa5d  mov rax, [rsp+0x30]
00007583d7bcfa62  lea r14, [rax+0x40]
00007583d7bcfa66  mov [r13+r14*1], r12d
00007583d7bcfa6b  mov eax, [rsp+0x20]
00007583d7bcfa6f  mov eax, eax
00007583d7bcfa71  mov [r15+0x60], rax
00007583d7bcfa75  mov eax, [r15+0x108]
00007583d7bcfa7c  sahf
00007583d7bcfa7d  jnz 0x00007583D7BCFAAF
00007583d7bcfa7f  cmp dword ptr [r15+0x318], 0x00
00007583d7bcfa87  jz 0x00007583D7BCFF70
00007583d7bcfa8d  nop [rax+rax*1], ax
00007583d7bcfa96  nop [rax+rax*1], eax
00007583d7bcfa9e  mov eax, 0x410820
00007583d7bcfaa3  mov [r15+0x100], rax
00007583d7bcfaaa  jmp 0x00007583D79FE110
00007583d7bcfaaf  cmp dword ptr [r15+0x318], 0x00
00007583d7bcfab7  jz 0x00007583D7BCFDC0
00007583d7bcfabd  nop [rax+rax*1], ax
00007583d7bcfac6  nop [rax+rax*1], eax
00007583d7bcface  mov eax, 0x4107D8
00007583d7bcfad3  mov [r15+0x100], rax
00007583d7bcfada  jmp 0x00007583D79FE110
00007583d7bcfadf  int3
00007583d7bcfae0  call 0x00007583D7A0D860
00007583d7bcfae5  jmp 0x00007583D7BCF17A
00007583d7bcfaea  call 0x00007583D7AE2420
00007583d7bcfaef  jmp 0x00007583D7BCF193
00007583d7bcfaf4  call 0x00007583D7AE2420
00007583d7bcfaf9  jmp 0x00007583D7BCF1AC
00007583d7bcfafe  call 0x00007583D7AE2420
00007583d7bcfb03  jmp 0x00007583D7BCF1C5
00007583d7bcfb08  call 0x00007583D7AE2420
00007583d7bcfb0d  jmp 0x00007583D7BCF1DE
00007583d7bcfb12  call 0x00007583D7AE2420
00007583d7bcfb17  jmp 0x00007583D7BCF1EF
00007583d7bcfb1c  call 0x00007583D7AE2420
00007583d7bcfb21  jmp 0x00007583D7BCF200
00007583d7bcfb26  call 0x00007583D7AE2420
00007583d7bcfb2b  jmp 0x00007583D7BCF211
00007583d7bcfb30  call 0x00007583D7AE2420
00007583d7bcfb35  jmp 0x00007583D7BCF222
00007583d7bcfb3a  call 0x00007583D7AE2420
00007583d7bcfb3f  jmp 0x00007583D7BCF233
00007583d7bcfb44  call 0x00007583D7AE2420
00007583d7bcfb49  jmp 0x00007583D7BCF244
00007583d7bcfb4e  call 0x00007583D7AE2420
00007583d7bcfb53  jmp 0x00007583D7BCF255
00007583d7bcfb58  call 0x00007583D7AE2420
00007583d7bcfb5d  jmp 0x00007583D7BCF266
00007583d7bcfb62  call 0x00007583D7AE2420
00007583d7bcfb67  jmp 0x00007583D7BCF277
00007583d7bcfb6c  call 0x00007583D7AE2420
00007583d7bcfb71  jmp 0x00007583D7BCF288
00007583d7bcfb76  call 0x00007583D7AE2420
00007583d7bcfb7b  jmp 0x00007583D7BCF299
00007583d7bcfb80  call 0x00007583D7AE2420
00007583d7bcfb85  jmp 0x00007583D7BCF2AA
00007583d7bcfb8a  call 0x00007583D7AE2420
00007583d7bcfb8f  jmp 0x00007583D7BCF2BB
00007583d7bcfb94  call 0x00007583D7AE2420
00007583d7bcfb99  jmp 0x00007583D7BCF2CC
00007583d7bcfb9e  call 0x00007583D7AE2420
00007583d7bcfba3  jmp 0x00007583D7BCF2DD
00007583d7bcfba8  call 0x00007583D7AE2420
00007583d7bcfbad  jmp 0x00007583D7BCF2EE
00007583d7bcfbb2  call 0x00007583D7AE2420
00007583d7bcfbb7  jmp 0x00007583D7BCF2FF
00007583d7bcfbbc  call 0x00007583D7AE2420
00007583d7bcfbc1  jmp 0x00007583D7BCF310
00007583d7bcfbc6  call 0x00007583D7AE2420
00007583d7bcfbcb  jmp 0x00007583D7BCF321
00007583d7bcfbd0  call 0x00007583D7AE2420
00007583d7bcfbd5  jmp 0x00007583D7BCF332
00007583d7bcfbda  call 0x00007583D7AE2420
00007583d7bcfbdf  jmp 0x00007583D7BCF343
00007583d7bcfbe4  call 0x00007583D7AE2420
00007583d7bcfbe9  jmp 0x00007583D7BCF354
00007583d7bcfbee  call 0x00007583D7AE2420
00007583d7bcfbf3  jmp 0x00007583D7BCF365
00007583d7bcfbf8  call 0x00007583D7AE2420
00007583d7bcfbfd  jmp 0x00007583D7BCF376
00007583d7bcfc02  call 0x00007583D7AE2420
00007583d7bcfc07  jmp 0x00007583D7BCF387
00007583d7bcfc0c  call 0x00007583D7AE2420
00007583d7bcfc11  jmp 0x00007583D7BCF398
00007583d7bcfc16  call 0x00007583D7AE2420
00007583d7bcfc1b  jmp 0x00007583D7BCF3A9
00007583d7bcfc20  call 0x00007583D7AE2420
00007583d7bcfc25  jmp 0x00007583D7BCF3BA
00007583d7bcfc2a  call 0x00007583D7AE2420
00007583d7bcfc2f  jmp 0x00007583D7BCF3CB
00007583d7bcfc34  call 0x00007583D7AE2420
00007583d7bcfc39  jmp 0x00007583D7BCF3DC
00007583d7bcfc3e  call 0x00007583D7AE2420
00007583d7bcfc43  jmp 0x00007583D7BCF3ED
00007583d7bcfc48  call 0x00007583D7AE2420
00007583d7bcfc4d  jmp 0x00007583D7BCF3FE
00007583d7bcfc52  call 0x00007583D7AE2420
00007583d7bcfc57  jmp 0x00007583D7BCF40F
00007583d7bcfc5c  call 0x00007583D7AE2420
00007583d7bcfc61  jmp 0x00007583D7BCF420
00007583d7bcfc66  call 0x00007583D7AE2420
00007583d7bcfc6b  jmp 0x00007583D7BCF431
00007583d7bcfc70  call 0x00007583D7AE2420
00007583d7bcfc75  jmp 0x00007583D7BCF442
00007583d7bcfc7a  call 0x00007583D7AE2420
00007583d7bcfc7f  jmp 0x00007583D7BCF453
00007583d7bcfc84  call 0x00007583D7AE2420
00007583d7bcfc89  jmp 0x00007583D7BCF464
00007583d7bcfc8e  call 0x00007583D7AE2420
00007583d7bcfc93  jmp 0x00007583D7BCF475
00007583d7bcfc98  call 0x00007583D7AE2420
00007583d7bcfc9d  jmp 0x00007583D7BCF486
00007583d7bcfca2  call 0x00007583D7AE2420
00007583d7bcfca7  jmp 0x00007583D7BCF497
00007583d7bcfcac  call 0x00007583D7AE2420
00007583d7bcfcb1  jmp 0x00007583D7BCF4A8
00007583d7bcfcb6  call 0x00007583D7AE2420
00007583d7bcfcbb  jmp 0x00007583D7BCF4B9
00007583d7bcfcc0  call 0x00007583D7AE2420
00007583d7bcfcc5  jmp 0x00007583D7BCF4CA
00007583d7bcfcca  call 0x00007583D7AE2420
00007583d7bcfccf  jmp 0x00007583D7BCF4DB
00007583d7bcfcd4  call 0x00007583D7AE2420
00007583d7bcfcd9  jmp 0x00007583D7BCF4EC
00007583d7bcfcde  call 0x00007583D7AE2420
00007583d7bcfce3  jmp 0x00007583D7BCF4FD
00007583d7bcfce8  call 0x00007583D7AE2420
00007583d7bcfced  jmp 0x00007583D7BCF50E
00007583d7bcfcf2  call 0x00007583D7AE2420
00007583d7bcfcf7  jmp 0x00007583D7BCF51F
00007583d7bcfcfc  call 0x00007583D7AE2420
00007583d7bcfd01  jmp 0x00007583D7BCF530
00007583d7bcfd06  call 0x00007583D7AE2420
00007583d7bcfd0b  jmp 0x00007583D7BCF541
00007583d7bcfd10  call 0x00007583D7AE2420
00007583d7bcfd15  jmp 0x00007583D7BCF552
00007583d7bcfd1a  call 0x00007583D7AE2420
00007583d7bcfd1f  jmp 0x00007583D7BCF563
00007583d7bcfd24  call 0x00007583D7AE2420
00007583d7bcfd29  jmp 0x00007583D7BCF574
00007583d7bcfd2e  call 0x00007583D7AE2420
00007583d7bcfd33  jmp 0x00007583D7BCF585
00007583d7bcfd38  call 0x00007583D7AE2420
00007583d7bcfd3d  jmp 0x00007583D7BCF596
00007583d7bcfd42  call 0x00007583D7AE2420
00007583d7bcfd47  jmp 0x00007583D7BCF5AF
00007583d7bcfd4c  call 0x00007583D7AE2420
00007583d7bcfd51  jmp 0x00007583D7BCF5C8
00007583d7bcfd56  call 0x00007583D7AD5610
00007583d7bcfd5b  jmp 0x00007583D7BCF5E1
00007583d7bcfd60  call 0x00007583D7ADC580
00007583d7bcfd65  jmp 0x00007583D7BCF94E
00007583d7bcfd6a  call 0x00007583D7AE46C0
00007583d7bcfd6f  jmp 0x00007583D7BCF958
00007583d7bcfd74  call 0x00007583D7A09E90
00007583d7bcfd79  jmp 0x00007583D7BCF95E
00007583d7bcfd7e  call 0x00007583D7ADB310
00007583d7bcfd83  jmp 0x00007583D7BCF968
00007583d7bcfd88  call 0x00007583D7A0DAE0
00007583d7bcfd8d  jmp 0x00007583D7BCF96D
00007583d7bcfd92  call 0x00007583D7AC0230
00007583d7bcfd97  jmp 0x00007583D7BCF986
00007583d7bcfd9c  call 0x00007583D7AC0230
00007583d7bcfda1  jmp 0x00007583D7BCF99B
00007583d7bcfda6  call 0x00007583D7ABEFC0
00007583d7bcfdab  jmp 0x00007583D7BCF9A4
00007583d7bcfdb0  call 0x00007583D7AE2BA0
00007583d7bcfdb5  jmp 0x00007583D7BCFA6B
00007583d7bcfdba  int3
00007583d7bcfdbb  nop [rax+rax*1], eax
00007583d7bcfdc0  mov rax, [r15+0x48]
00007583d7bcfdc4  mov r14, [r15+0x58]
00007583d7bcfdc8  lea r12, [rax+r14*1]
00007583d7bcfdcc  mov [r15+0x68], r12
00007583d7bcfdd0  lea rax, [r14+0x04]
00007583d7bcfdd4  mov [r15+0x58], rax
00007583d7bcfdd8  lea r14, [r12+0x04]
00007583d7bcfddd  mov r11d, [r13+r14*1]
00007583d7bcfde2  mov [rsp+0x10], r11d
00007583d7bcfde7  mov r11d, r11d
00007583d7bcfdea  mov [r15+0x70], r11
00007583d7bcfdee  lea r14, [r12+0x38]
00007583d7bcfdf3  mov r11d, [r13+r14*1]
00007583d7bcfdf8  lea r14, [r12+0x24]
00007583d7bcfdfd  mov r10d, [r13+r14*1]
00007583d7bcfe02  mov [rsp+0x20], r10d
00007583d7bcfe07  mov r10d, r10d
00007583d7bcfe0a  mov [r15+0x90], r10
00007583d7bcfe11  mov [rsp+0x30], rax
00007583d7bcfe16  xor eax, eax
00007583d7bcfe18  mov r14, [rsp+0x30]
00007583d7bcfe1d  mov r10d, 0xC0
00007583d7bcfe23  cmp r14, r10
00007583d7bcfe26  cmc
00007583d7bcfe27  lahf
00007583d7bcfe28  seto al
00007583d7bcfe2b  mov [r15+0x108], eax
00007583d7bcfe32  mov eax, [rsp+0x10]
00007583d7bcfe36  mov r14d, [rsp+0x10]
00007583d7bcfe3b  shrd eax, r14d, 0x07
00007583d7bcfe40  mov [rsp+0x10], r11d
00007583d7bcfe45  mov r10d, [rsp+0x10]
00007583d7bcfe4a  shrd r11d, r10d, 0x11
00007583d7bcfe4f  mov r9d, [r15+0x60]
00007583d7bcfe53  mov r8d, [rsp+0x20]
00007583d7bcfe58  lea ebp, [r8d+r9d*1]
00007583d7bcfe5d  rorx r9d, r14d, 0x12
00007583d7bcfe63  xor eax, r9d
00007583d7bcfe66  rorx r9d, r10d, 0x13
00007583d7bcfe6c  xor r11d, r9d
00007583d7bcfe6f  mov [rsp+0x10], r11d
00007583d7bcfe74  mov r11d, r11d
00007583d7bcfe77  mov [r15+0x88], r11
00007583d7bcfe7e  mov [rsp+0x20], r14d
00007583d7bcfe83  shr r14d, 0x03
00007583d7bcfe87  xor eax, r14d
00007583d7bcfe8a  mov [rsp+0x30], eax
00007583d7bcfe8e  mov eax, eax
00007583d7bcfe90  mov [r15+0x80], rax
00007583d7bcfe97  shr r10d, 0x0A
00007583d7bcfe9b  mov eax, [rsp+0x10]
00007583d7bcfe9f  xor eax, r10d
00007583d7bcfea2  mov [rsp+0x10], eax
00007583d7bcfea6  mov eax, eax
00007583d7bcfea8  mov [r15+0x78], rax
00007583d7bcfeac  mov eax, [rsp+0x30]
00007583d7bcfeb0  lea r14d, [ebp+eax*1]
00007583d7bcfeb6  mov eax, [rsp+0x10]
00007583d7bcfeba  lea r11d, [r14d+eax*1]
00007583d7bcfebf  lea rax, [r12+0x40]
00007583d7bcfec4  mov [r13+rax*1], r11d
00007583d7bcfec9  mov eax, [rsp+0x20]
00007583d7bcfecd  mov eax, eax
00007583d7bcfecf  mov [r15+0x60], rax
00007583d7bcfed3  mov eax, [r15+0x108]
00007583d7bcfeda  sahf
00007583d7bcfedb  jnz 0x00007583D7BCFF0D
00007583d7bcfedd  cmp dword ptr [r15+0x318], 0x00
00007583d7bcfee5  jz 0x00007583D7BCFF70
00007583d7bcfeeb  nop [rax+rax*1], ax
00007583d7bcfef4  nop [rax+rax*1], eax
00007583d7bcfefc  mov eax, 0x410820
00007583d7bcff01  mov [r15+0x100], rax
00007583d7bcff08  jmp 0x00007583D79FE110
00007583d7bcff0d  cmp dword ptr [r15+0x318], 0x00
00007583d7bcff15  jz 0x00007583D7BCFDC0
00007583d7bcff1b  nop [rax+rax*1], ax
00007583d7bcff24  nop [rax+rax*1], eax
00007583d7bcff2c  mov eax, 0x4107D8
00007583d7bcff31  mov [r15+0x100], rax
00007583d7bcff38  jmp 0x00007583D79FE110
00007583d7bcff3d  int3
00007583d7bcff3e  call 0x00007583D7AE1430
00007583d7bcff43  jmp 0x00007583D7BCFDE2
00007583d7bcff48  call 0x00007583D7AE1430
00007583d7bcff4d  jmp 0x00007583D7BCFDF8
00007583d7bcff52  call 0x00007583D7AE01C0
00007583d7bcff57  jmp 0x00007583D7BCFE02
00007583d7bcff5c  call 0x00007583D7A0A860
00007583d7bcff61  jmp 0x00007583D7BCFEC9
00007583d7bcff66  int3
00007583d7bcff67  nop [rax+rax*1], ax
00007583d7bcff70  mov rax, [r15]
00007583d7bcff73  mov r14d, [r13+rax*1]
00007583d7bcff78  lea r12, [rax+0x04]
00007583d7bcff7c  mov r11d, [r13+r12*1]
00007583d7bcff81  mov [rsp+0x10], r14d
00007583d7bcff86  mov r14d, r14d
00007583d7bcff89  mov [r15+0x78], r14
00007583d7bcff8d  mov [rsp+0x20], r11d
00007583d7bcff92  mov r11d, r11d
00007583d7bcff95  mov [r15+0x80], r11
00007583d7bcff9c  lea r14, [rax+0x08]
00007583d7bcffa0  mov r12d, [r13+r14*1]
00007583d7bcffa5  lea r14, [rax+0x0C]
00007583d7bcffa9  mov r11d, [r13+r14*1]
00007583d7bcffae  mov [rsp+0x30], r12d
00007583d7bcffb3  mov r12d, r12d
00007583d7bcffb6  mov [r15+0x70], r12
00007583d7bcffba  mov [rsp+0x40], r11d
00007583d7bcffbf  mov r11d, r11d
00007583d7bcffc2  mov [r15+0x68], r11
00007583d7bcffc6  lea r14, [rax+0x18]
00007583d7bcffca  mov r12d, [r13+r14*1]
00007583d7bcffcf  lea r14, [rax+0x1C]
00007583d7bcffd3  mov r11d, [r13+r14*1]
00007583d7bcffd8  mov [rsp+0x50], r12d
00007583d7bcffdd  mov r12d, r12d
00007583d7bcffe0  mov [r15+0x58], r12
00007583d7bcffe4  mov [rsp+0x60], r11d
00007583d7bcffe9  mov r11d, r11d
00007583d7bcffec  mov [r15+0x60], r11
00007583d7bcfff0  lea r14, [rax+0x10]
00007583d7bcfff4  mov r12d, [r13+r14*1]
00007583d7bcfff9  lea r14, [rax+0x14]
00007583d7bcfffd  mov eax, [r13+r14*1]
00007583d7bd0002  mov [rsp+0x70], r12d
00007583d7bd0007  mov r12d, r12d
00007583d7bd000a  mov [r15+0x18], r12
00007583d7bd000e  mov [rsp+0x80], eax
00007583d7bd0015  mov eax, eax
00007583d7bd0017  mov [r15+0x90], rax
00007583d7bd001e  mov eax, [rsp+0x70]
00007583d7bd0022  mov eax, eax
00007583d7bd0024  mov [r15+0x30], rax
00007583d7bd0028  mov eax, [rsp+0x50]
00007583d7bd002c  mov eax, eax
00007583d7bd002e  mov [r15+0xA0], rax
00007583d7bd0035  mov eax, [rsp+0x30]
00007583d7bd0039  mov eax, eax
00007583d7bd003b  mov [r15+0x28], rax
00007583d7bd003f  mov eax, [rsp+0x20]
00007583d7bd0043  mov eax, eax
00007583d7bd0045  mov [r15+0x98], rax
00007583d7bd004c  mov eax, [rsp+0x10]
00007583d7bd0050  mov eax, eax
00007583d7bd0052  mov [r15+0x38], rax
00007583d7bd0056  mov eax, [rsp+0x70]
00007583d7bd005a  mov r14d, [rsp+0x70]
00007583d7bd005f  shrd eax, r14d, 0x06
00007583d7bd0064  mov [rsp+0x70], r14d
00007583d7bd0069  mov r12d, [rsp+0x80]
00007583d7bd0071  and r14d, r12d
00007583d7bd0074  mov r11d, [rsp+0x10]
00007583d7bd0079  mov r10d, [rsp+0x10]
00007583d7bd007e  shrd r11d, r10d, 0x02
00007583d7bd0083  mov [rsp+0x10], r12d
00007583d7bd0088  mov r12d, r12d
00007583d7bd008b  mov [r15+0x20], r12
00007583d7bd008f  mov r12, [r15+0x50]
00007583d7bd0093  mov r9d, [r13+r12*1]
00007583d7bd0098  mov r12d, [rsp+0x50]
00007583d7bd009d  mov r8d, [rsp+0x70]
00007583d7bd00a2  andn ebp, r8d, r12d
00007583d7bd00a7  mov edi, [rsp+0x60]
00007583d7bd00ab  lea esi, [r14d+edi*1]
00007583d7bd00b0  rorx r14d, r8d, 0x0B
00007583d7bd00b6  xor eax, r14d
00007583d7bd00b9  rorx r14d, r10d, 0x0D
00007583d7bd00bf  xor r11d, r14d
00007583d7bd00c2  lea edi, [esi+ebp*1]
00007583d7bd00c6  mov r14, [r15+0x48]
00007583d7bd00ca  mov ebp, [r13+r14*1]
00007583d7bd00cf  mov r14d, [rsp+0x30]
00007583d7bd00d4  mov esi, [rsp+0x20]
00007583d7bd00d8  and r14d, esi
00007583d7bd00db  mov [rsp+0x20], r14d
00007583d7bd00e0  mov r14d, r14d
00007583d7bd00e3  mov [r15+0xD8], r14
00007583d7bd00ea  lea r14d, [edi+r9d*1]
00007583d7bd00ef  mov r9d, [rsp+0x30]
00007583d7bd00f4  xor r9d, esi
00007583d7bd00f7  rorx edi, r8d, 0x19
00007583d7bd00fd  xor eax, edi
00007583d7bd00ff  and r9d, r10d
00007583d7bd0102  rorx edi, r10d, 0x16
00007583d7bd0108  xor r11d, edi
00007583d7bd010b  mov [rsp+0x30], r11d
00007583d7bd0110  mov r11d, r11d
00007583d7bd0113  mov [r15+0xD0], r11
00007583d7bd011a  lea r11d, [r14d+ebp*1]
00007583d7bd011f  mov r10d, [rsp+0x20]
00007583d7bd0124  xor r9d, r10d
00007583d7bd0127  lea r14d, [r11d+eax*1]
00007583d7bd012c  mov qword ptr [r15+0x88], 0x04
00007583d7bd0137  mov eax, [rsp+0x30]
00007583d7bd013b  lea r11d, [r9d+eax*1]
00007583d7bd0140  mov eax, [rsp+0x40]
00007583d7bd0144  lea r10d, [r14d+eax*1]
00007583d7bd0149  mov r10d, r10d
00007583d7bd014c  mov [r15+0xB8], r10
00007583d7bd0153  xor eax, eax
00007583d7bd0155  mov r10d, 0x04
00007583d7bd015b  mov r9d, 0x100
00007583d7bd0161  cmp r10, r9
00007583d7bd0164  cmc
00007583d7bd0165  lahf
00007583d7bd0166  seto al
00007583d7bd0169  mov [r15+0x108], eax
00007583d7bd0170  lea eax, [r11d+r14d*1]
00007583d7bd0175  mov eax, eax
00007583d7bd0177  mov [r15+0xA8], rax
00007583d7bd017e  mov r12d, r12d
00007583d7bd0181  mov [r15+0xB0], r12
00007583d7bd0188  mov eax, [rsp+0x10]
00007583d7bd018c  mov eax, eax
00007583d7bd018e  mov [r15+0xC0], rax
00007583d7bd0195  mov r8d, r8d
00007583d7bd0198  mov [r15+0xC8], r8
00007583d7bd019f  mov eax, [r15+0x108]
00007583d7bd01a6  sahf
00007583d7bd01a7  jnz 0x00007583D7BD01D9
00007583d7bd01a9  cmp dword ptr [r15+0x318], 0x00
00007583d7bd01b1  jz 0x00007583D7BD04A0
00007583d7bd01b7  nop [rax+rax*1], ax
00007583d7bd01c0  nop [rax+rax*1], eax
00007583d7bd01c8  mov eax, 0x4108E0
00007583d7bd01cd  mov [r15+0x100], rax
00007583d7bd01d4  jmp 0x00007583D79FE110
00007583d7bd01d9  cmp dword ptr [r15+0x318], 0x00
00007583d7bd01e1  jz 0x00007583D7BD0270
00007583d7bd01e7  nop [rax+rax*1], ax
00007583d7bd01f0  nop [rax+rax*1], eax
00007583d7bd01f8  mov eax, 0x410854
00007583d7bd01fd  mov [r15+0x100], rax
00007583d7bd0204  jmp 0x00007583D79FE110
00007583d7bd0209  int3
00007583d7bd020a  call 0x00007583D7A0DAE0
00007583d7bd020f  jmp 0x00007583D7BCFF78
00007583d7bd0214  call 0x00007583D7AC0230
00007583d7bd0219  jmp 0x00007583D7BCFF81
00007583d7bd021e  call 0x00007583D7AE26A0
00007583d7bd0223  jmp 0x00007583D7BCFFA5
00007583d7bd0228  call 0x00007583D7AE1430
00007583d7bd022d  jmp 0x00007583D7BCFFAE
00007583d7bd0232  call 0x00007583D7AE26A0
00007583d7bd0237  jmp 0x00007583D7BCFFCF
00007583d7bd023c  call 0x00007583D7AE1430
00007583d7bd0241  jmp 0x00007583D7BCFFD8
00007583d7bd0246  call 0x00007583D7AE26A0
00007583d7bd024b  jmp 0x00007583D7BCFFF9
00007583d7bd0250  call 0x00007583D7AD5890
00007583d7bd0255  jmp 0x00007583D7BD0002
00007583d7bd025a  call 0x00007583D7ABDD50
00007583d7bd025f  jmp 0x00007583D7BD0098
00007583d7bd0264  call 0x00007583D7ADA580
00007583d7bd0269  jmp 0x00007583D7BD00CF
00007583d7bd026e  int3
00007583d7bd026f  nop
00007583d7bd0270  mov eax, [r15+0xB8]
00007583d7bd0277  mov [rsp+0x10], eax
00007583d7bd027b  mov eax, eax
00007583d7bd027d  mov [r15+0x30], rax
00007583d7bd0281  mov eax, [r15+0xC0]
00007583d7bd0288  mov [rsp+0x20], eax
00007583d7bd028c  mov eax, eax
00007583d7bd028e  mov [r15+0xA0], rax
00007583d7bd0295  mov eax, [r15+0x28]
00007583d7bd0299  mov r14d, [r15+0x98]
00007583d7bd02a0  mov [rsp+0x30], r14d
00007583d7bd02a5  mov r14d, r14d
00007583d7bd02a8  mov [r15+0x28], r14
00007583d7bd02ac  mov r14d, [r15+0x38]
00007583d7bd02b0  mov [rsp+0x40], r14d
00007583d7bd02b5  mov r14d, r14d
00007583d7bd02b8  mov [r15+0x98], r14
00007583d7bd02bf  mov r14d, [r15+0xA8]
00007583d7bd02c6  mov [rsp+0x50], r14d
00007583d7bd02cb  mov r14d, r14d
00007583d7bd02ce  mov [r15+0x38], r14
00007583d7bd02d2  mov r14d, [rsp+0x10]
00007583d7bd02d7  mov r12d, [rsp+0x10]
00007583d7bd02dc  shrd r14d, r12d, 0x06
00007583d7bd02e1  mov r11d, [r15+0xC8]
00007583d7bd02e8  mov [rsp+0x10], r12d
00007583d7bd02ed  and r12d, r11d
00007583d7bd02f0  mov r10d, [rsp+0x50]
00007583d7bd02f5  mov r9d, [rsp+0x50]
00007583d7bd02fa  shrd r10d, r9d, 0x02
00007583d7bd02ff  mov [rsp+0x50], r11d
00007583d7bd0304  mov r11d, r11d
00007583d7bd0307  mov [r15+0x20], r11
00007583d7bd030b  mov r11, [r15+0x88]
00007583d7bd0312  mov r8, [r15+0x50]
00007583d7bd0316  lea rbp, [r8+r11*1]
00007583d7bd031a  mov r8d, [r13+rbp*1]
00007583d7bd031f  mov ebp, [rsp+0x20]
00007583d7bd0323  mov edi, [rsp+0x10]
00007583d7bd0327  andn esi, edi, ebp
00007583d7bd032c  mov edx, [r15+0xB0]
00007583d7bd0333  lea ecx, [r12d+edx*1]
00007583d7bd0338  rorx r12d, edi, 0x0B
00007583d7bd033e  xor r14d, r12d
00007583d7bd0341  rorx r12d, r9d, 0x0D
00007583d7bd0347  xor r10d, r12d
00007583d7bd034a  lea r12d, [ecx+esi*1]
00007583d7bd034f  mov rsi, [r15+0x48]
00007583d7bd0353  lea rdx, [rsi+r11*1]
00007583d7bd0357  mov esi, [r13+rdx*1]
00007583d7bd035c  mov edx, [rsp+0x30]
00007583d7bd0360  mov ecx, [rsp+0x40]
00007583d7bd0364  and edx, ecx
00007583d7bd0366  mov [rsp+0x10], edx
00007583d7bd036a  mov edx, edx
00007583d7bd036c  mov [r15+0xD8], rdx
00007583d7bd0373  lea edx, [r12d+r8d*1]
00007583d7bd0378  mov r12d, [rsp+0x30]
00007583d7bd037d  xor r12d, ecx
00007583d7bd0380  rorx r8d, edi, 0x19
00007583d7bd0386  xor r14d, r8d
00007583d7bd0389  and r12d, r9d
00007583d7bd038c  rorx r8d, r9d, 0x16
00007583d7bd0392  xor r10d, r8d
00007583d7bd0395  mov [rsp+0x20], r10d
00007583d7bd039a  mov r10d, r10d
00007583d7bd039d  mov [r15+0xD0], r10
00007583d7bd03a4  lea r10d, [edx+esi*1]
00007583d7bd03a9  mov r9d, [rsp+0x10]
00007583d7bd03ae  xor r12d, r9d
00007583d7bd03b1  lea r9d, [r10d+r14d*1]
00007583d7bd03b6  lea r14, [r11+0x04]
00007583d7bd03ba  mov [r15+0x88], r14
00007583d7bd03c1  mov r11d, [rsp+0x20]
00007583d7bd03c6  lea r10d, [r12d+r11d*1]
00007583d7bd03cb  lea r11d, [r9d+eax*1]
00007583d7bd03d0  mov r11d, r11d
00007583d7bd03d3  mov [r15+0xB8], r11
00007583d7bd03da  xor eax, eax
00007583d7bd03dc  mov r12d, 0x100
00007583d7bd03e2  cmp r14, r12
00007583d7bd03e5  cmc
00007583d7bd03e6  lahf
00007583d7bd03e7  seto al
00007583d7bd03ea  mov [r15+0x108], eax
00007583d7bd03f1  lea eax, [r10d+r9d*1]
00007583d7bd03f6  mov eax, eax
00007583d7bd03f8  mov [r15+0xA8], rax
00007583d7bd03ff  mov ebp, ebp
00007583d7bd0401  mov [r15+0xB0], rbp
00007583d7bd0408  mov eax, [rsp+0x50]
00007583d7bd040c  mov eax, eax
00007583d7bd040e  mov [r15+0xC0], rax
00007583d7bd0415  mov edi, edi
00007583d7bd0417  mov [r15+0xC8], rdi
00007583d7bd041e  mov eax, [r15+0x108]
00007583d7bd0425  sahf
00007583d7bd0426  jnz 0x00007583D7BD0458
00007583d7bd0428  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0430  jz 0x00007583D7BD04A0
00007583d7bd0436  nop [rax+rax*1], ax
00007583d7bd043f  nop [rax+rax*1], eax
00007583d7bd0447  mov eax, 0x4108E0
00007583d7bd044c  mov [r15+0x100], rax
00007583d7bd0453  jmp 0x00007583D79FE110
00007583d7bd0458  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0460  jz 0x00007583D7BD0270
00007583d7bd0466  nop [rax+rax*1], ax
00007583d7bd046f  nop [rax+rax*1], eax
00007583d7bd0477  mov eax, 0x410854
00007583d7bd047c  mov [r15+0x100], rax
00007583d7bd0483  jmp 0x00007583D79FE110
00007583d7bd0488  int3
00007583d7bd0489  call 0x00007583D7A49010
00007583d7bd048e  jmp 0x00007583D7BD031F
00007583d7bd0493  call 0x00007583D7A25930
00007583d7bd0498  jmp 0x00007583D7BD035C
00007583d7bd049d  int3
00007583d7bd049e  nop
00007583d7bd04a0  mov eax, [r15+0x98]
00007583d7bd04a7  mov r14d, [r15+0x70]
00007583d7bd04ab  lea r12d, [eax+r14d*1]
00007583d7bd04b0  mov eax, [r15+0x28]
00007583d7bd04b4  mov r14d, [r15+0x68]
00007583d7bd04b8  lea r11d, [eax+r14d*1]
00007583d7bd04bd  mov qword ptr [r15+0x88], 0x00
00007583d7bd04c8  mov eax, [r15+0xA8]
00007583d7bd04cf  mov r14d, [r15+0x78]
00007583d7bd04d3  lea r10d, [eax+r14d*1]
00007583d7bd04d8  mov [rsp+0x10], r10d
00007583d7bd04dd  mov r10d, r10d
00007583d7bd04e0  mov [r15+0x78], r10
00007583d7bd04e4  mov eax, [r15+0x38]
00007583d7bd04e8  mov r14d, [r15+0x80]
00007583d7bd04ef  lea r10d, [eax+r14d*1]
00007583d7bd04f4  mov [rsp+0x20], r10d
00007583d7bd04f9  mov r10d, r10d
00007583d7bd04fc  mov [r15+0x80], r10
00007583d7bd0503  mov rax, [r15]
00007583d7bd0506  lea r14, [rax+0x08]
00007583d7bd050a  mov [r13+r14*1], r12d
00007583d7bd050f  lea r14, [rax+0x0C]
00007583d7bd0513  mov [r13+r14*1], r11d
00007583d7bd0518  mov r14d, [r15+0xB8]
00007583d7bd051f  mov r12d, [r15+0x18]
00007583d7bd0523  lea r11d, [r14d+r12d*1]
00007583d7bd0528  mov [rsp+0x30], r11d
00007583d7bd052d  mov r11d, r11d
00007583d7bd0530  mov [r15+0x68], r11
00007583d7bd0534  mov r14d, [r15+0x30]
00007583d7bd0538  mov r12d, [r15+0x90]
00007583d7bd053f  lea r11d, [r14d+r12d*1]
00007583d7bd0544  mov [rsp+0x40], r11d
00007583d7bd0549  mov r11d, r11d
00007583d7bd054c  mov [r15+0x70], r11
00007583d7bd0550  mov r14d, [r15+0x20]
00007583d7bd0554  mov r12d, [r15+0x58]
00007583d7bd0558  lea r11d, [r14d+r12d*1]
00007583d7bd055d  mov [rsp+0x50], r11d
00007583d7bd0562  mov r11d, r11d
00007583d7bd0565  mov [r15+0x58], r11
00007583d7bd0569  mov r14d, [r15+0xA0]
00007583d7bd0570  mov r12d, [r15+0x60]
00007583d7bd0574  lea r11d, [r14d+r12d*1]
00007583d7bd0579  mov [rsp+0x60], r11d
00007583d7bd057e  mov r11d, r11d
00007583d7bd0581  mov [r15+0x60], r11
00007583d7bd0585  mov r14d, [rsp+0x10]
00007583d7bd058a  mov [r13+rax*1], r14d
00007583d7bd058f  lea r14, [rax+0x04]
00007583d7bd0593  mov r12d, [rsp+0x20]
00007583d7bd0598  mov [r13+r14*1], r12d
00007583d7bd059d  lea r14, [rax+0x10]
00007583d7bd05a1  mov r12d, [rsp+0x30]
00007583d7bd05a6  mov [r13+r14*1], r12d
00007583d7bd05ab  lea r14, [rax+0x14]
00007583d7bd05af  mov r12d, [rsp+0x40]
00007583d7bd05b4  mov [r13+r14*1], r12d
00007583d7bd05b9  lea r14, [rax+0x18]
00007583d7bd05bd  mov r12d, [rsp+0x50]
00007583d7bd05c2  mov [r13+r14*1], r12d
00007583d7bd05c7  lea r14, [rax+0x1C]
00007583d7bd05cb  mov r12d, [rsp+0x60]
00007583d7bd05d0  mov [r13+r14*1], r12d
00007583d7bd05d5  lea r14, [rax+0x68]
00007583d7bd05d9  xor eax, eax
00007583d7bd05db  mov [r13+r14*1], rax
00007583d7bd05e0  cmp dword ptr [r15+0x318], 0x00
00007583d7bd05e8  jz 0x00007583D7BCF0E0
00007583d7bd05ee  nop [rax+rax*1], ax
00007583d7bd05f7  nop [rax+rax*1], eax
00007583d7bd05ff  mov eax, 0x4106FC
00007583d7bd0604  mov [r15+0x100], rax
00007583d7bd060b  jmp 0x00007583D79FE110
00007583d7bd0610  int3
00007583d7bd0611  call 0x00007583D7AE2BA0
00007583d7bd0616  jmp 0x00007583D7BD050F
00007583d7bd061b  call 0x00007583D7AE1920
00007583d7bd0620  jmp 0x00007583D7BD0518
00007583d7bd0625  call 0x00007583D7A0DFE0
00007583d7bd062a  jmp 0x00007583D7BD058F
00007583d7bd062f  call 0x00007583D7AE2BA0
00007583d7bd0634  jmp 0x00007583D7BD059D
00007583d7bd0639  call 0x00007583D7AE2BA0
00007583d7bd063e  jmp 0x00007583D7BD05AB
00007583d7bd0643  call 0x00007583D7AE2BA0
00007583d7bd0648  jmp 0x00007583D7BD05B9
00007583d7bd064d  call 0x00007583D7AE2BA0
00007583d7bd0652  jmp 0x00007583D7BD05C7
00007583d7bd0657  call 0x00007583D7AE2BA0
00007583d7bd065c  jmp 0x00007583D7BD05D5
00007583d7bd0661  call 0x00007583D7AD5EB0
00007583d7bd0666  jmp 0x00007583D7BD05E0
00007583d7bd066b  int3
00007583d7bd066c  nop [rax], eax
00007583d7bd0670  mov rax, [r15+0xF8]
00007583d7bd0677  lea r14, [rax+0x140]
00007583d7bd067e  mov r12, [r13+r14*1]
00007583d7bd0683  lea r14, [rax+0x148]
00007583d7bd068a  mov r11, [r13+r14*1]
00007583d7bd068f  mov [r15+0xA0], r12
00007583d7bd0696  mov [r15+0x98], r11
00007583d7bd069d  lea r14, [rax+0x130]
00007583d7bd06a4  mov r12, [r13+r14*1]
00007583d7bd06a9  lea r14, [rax+0x138]
00007583d7bd06b0  mov r11, [r13+r14*1]
00007583d7bd06b5  mov [r15+0xB0], r12
00007583d7bd06bc  mov [r15+0xA8], r11
00007583d7bd06c3  lea r14, [rax+0x120]
00007583d7bd06ca  mov r12, [r13+r14*1]
00007583d7bd06cf  lea r14, [rax+0x128]
00007583d7bd06d6  mov r11, [r13+r14*1]
00007583d7bd06db  mov [r15+0xC0], r12
00007583d7bd06e2  mov [r15+0xB8], r11
00007583d7bd06e9  lea r14, [rax+0x110]
00007583d7bd06f0  mov r12, [r13+r14*1]
00007583d7bd06f5  lea r14, [rax+0x118]
00007583d7bd06fc  mov r11, [r13+r14*1]
00007583d7bd0701  mov [r15+0xD0], r12
00007583d7bd0708  mov [r15+0xC8], r11
00007583d7bd070f  lea r14, [rax+0x100]
00007583d7bd0716  mov r12, [r13+r14*1]
00007583d7bd071b  lea r14, [rax+0x108]
00007583d7bd0722  mov r11, [r13+r14*1]
00007583d7bd0727  mov [r15+0xE8], r12
00007583d7bd072e  mov [r15+0xD8], r11
00007583d7bd0735  lea r14, [rax+0x150]
00007583d7bd073c  mov [r15+0xF8], r14
00007583d7bd0743  mov rax, [r15+0xF0]
00007583d7bd074a  mov [r15+0x100], rax
00007583d7bd0751  jmp 0x00007583D7BCE5C0
00007583d7bd0756  int3
00007583d7bd0757  call 0x00007583D7AE27E0
00007583d7bd075c  jmp 0x00007583D7BD0683
00007583d7bd0761  call 0x00007583D7AE1570
00007583d7bd0766  jmp 0x00007583D7BD068F
00007583d7bd076b  call 0x00007583D7AE27E0
00007583d7bd0770  jmp 0x00007583D7BD06A9
00007583d7bd0775  call 0x00007583D7AE1570
00007583d7bd077a  jmp 0x00007583D7BD06B5
00007583d7bd077f  call 0x00007583D7AE27E0
00007583d7bd0784  jmp 0x00007583D7BD06CF
00007583d7bd0789  call 0x00007583D7AE1570
00007583d7bd078e  jmp 0x00007583D7BD06DB
00007583d7bd0793  call 0x00007583D7AE27E0
00007583d7bd0798  jmp 0x00007583D7BD06F5
00007583d7bd079d  call 0x00007583D7AE1570
00007583d7bd07a2  jmp 0x00007583D7BD0701
00007583d7bd07a7  call 0x00007583D7AE27E0
00007583d7bd07ac  jmp 0x00007583D7BD071B
00007583d7bd07b1  call 0x00007583D7AE1570
00007583d7bd07b6  jmp 0x00007583D7BD0727
00007583d7bd07bb  int3
00007583d7bd07bc  nop [rax], eax
00007583d7bd07c0  mov eax, [r15+0xA0]
00007583d7bd07c7  mov [rsp+0x10], eax
00007583d7bd07cb  xor eax, eax
00007583d7bd07cd  mov r14d, [rsp+0x10]
00007583d7bd07d2  sub r14d, 0x01
00007583d7bd07d6  cmc
00007583d7bd07d7  lahf
00007583d7bd07d8  seto al
00007583d7bd07db  mov [r15+0x108], eax
00007583d7bd07e2  mov r14d, r14d
00007583d7bd07e5  mov [r15+0xA0], r14
00007583d7bd07ec  mov eax, [r15+0x108]
00007583d7bd07f3  sahf
00007583d7bd07f4  jnz 0x00007583D7BD0826
00007583d7bd07f6  cmp dword ptr [r15+0x318], 0x00
00007583d7bd07fe  jz 0x00007583D7BD0900
00007583d7bd0804  nop [rax+rax*1], ax
00007583d7bd080d  nop [rax+rax*1], eax
00007583d7bd0815  mov eax, 0x41028C
00007583d7bd081a  mov [r15+0x100], rax
00007583d7bd0821  jmp 0x00007583D79FE110
00007583d7bd0826  cmp dword ptr [r15+0x318], 0x00
00007583d7bd082e  jz 0x00007583D7BD0860
00007583d7bd0834  nop [rax+rax*1], ax
00007583d7bd083d  nop [rax+rax*1], eax
00007583d7bd0845  mov eax, 0x410274
00007583d7bd084a  mov [r15+0x100], rax
00007583d7bd0851  jmp 0x00007583D79FE110
00007583d7bd0856  int3
00007583d7bd0857  int3
00007583d7bd0858  nop [rax+rax*1], eax
00007583d7bd0860  mov rax, [r15+0xF8]
00007583d7bd0867  lea r14, [rax+0xD0]
00007583d7bd086e  mov [r15], r14
00007583d7bd0871  mov rax, [r15+0x98]
00007583d7bd0878  mov [r15+0x08], rax
00007583d7bd087c  mov qword ptr [r15+0x10], 0x12C
00007583d7bd0884  mov qword ptr [r15+0xF0], 0x410284
00007583d7bd088f  mov r14d, [r15+0x320]
00007583d7bd0896  mov eax, 0x410284
00007583d7bd089b  mov rcx, 0x7583D7BD07C0
00007583d7bd08a5  mov [r15+r14*8+0x328], rax
00007583d7bd08ad  mov [r15+r14*8+0x368], rcx
00007583d7bd08b5  add r14d, 0x01
00007583d7bd08b9  and r14d, 0x07
00007583d7bd08bd  mov [r15+0x320], r14d
00007583d7bd08c4  cmp dword ptr [r15+0x318], 0x00
00007583d7bd08cc  jz 0x00007583D7BCED70
00007583d7bd08d2  nop [rax+rax*1], ax
00007583d7bd08db  nop [rax+rax*1], eax
00007583d7bd08e3  mov eax, 0x4106BC
00007583d7bd08e8  mov [r15+0x100], rax
00007583d7bd08ef  jmp 0x00007583D79FE110
00007583d7bd08f4  int3
00007583d7bd08f5  int3
00007583d7bd08f6  nop [rax+rax*1], ax
00007583d7bd08ff  nop
00007583d7bd0900  mov rax, [r15+0xF8]
00007583d7bd0907  lea r14, [rax+0xF0]
00007583d7bd090e  mov r12, [r13+r14*1]
00007583d7bd0913  mov [r15+0x98], r12
00007583d7bd091a  mov qword ptr [r15+0x40], 0x80
00007583d7bd0922  lea r14, [rax+0xD0]
00007583d7bd0929  mov [r15], r14
00007583d7bd092c  lea r14, [rax+0x14C]
00007583d7bd0933  mov [r15+0x08], r14
00007583d7bd0937  mov qword ptr [r15+0x10], 0x01
00007583d7bd093f  lea r14, [rax+0x14C]
00007583d7bd0946  mov eax, 0x80
00007583d7bd094b  mov [r13+r14*1], al
00007583d7bd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007583d7bd095b  mov r14d, [r15+0x320]
00007583d7bd0962  mov eax, 0x4102A8
00007583d7bd0967  mov rcx, 0x7583D7BD09E0
00007583d7bd0971  mov [r15+r14*8+0x328], rax
00007583d7bd0979  mov [r15+r14*8+0x368], rcx
00007583d7bd0981  add r14d, 0x01
00007583d7bd0985  and r14d, 0x07
00007583d7bd0989  mov [r15+0x320], r14d
00007583d7bd0990  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0998  jz 0x00007583D7BCED70
00007583d7bd099e  nop [rax+rax*1], ax
00007583d7bd09a7  nop [rax+rax*1], eax
00007583d7bd09af  mov eax, 0x4106BC
00007583d7bd09b4  mov [r15+0x100], rax
00007583d7bd09bb  jmp 0x00007583D79FE110
00007583d7bd09c0  int3
00007583d7bd09c1  call 0x00007583D7AE27E0
00007583d7bd09c6  jmp 0x00007583D7BD0913
00007583d7bd09cb  call 0x00007583D7AD5AF0
00007583d7bd09d0  jmp 0x00007583D7BD0950
00007583d7bd09d5  int3
00007583d7bd09d6  nop [rax+rax*1], ax
00007583d7bd09df  nop
00007583d7bd09e0  mov rax, [r15+0xF8]
00007583d7bd09e7  lea r14, [rax+0x138]
00007583d7bd09ee  mov r12, [r13+r14*1]
00007583d7bd09f3  mov [r15+0x40], r12
00007583d7bd09f7  lea r14, [rax+0x148]
00007583d7bd09fe  xor eax, eax
00007583d7bd0a00  mov [r13+r14*1], al
00007583d7bd0a05  xor eax, eax
00007583d7bd0a07  mov r14d, 0x38
00007583d7bd0a0d  cmp r12, r14
00007583d7bd0a10  cmc
00007583d7bd0a11  lahf
00007583d7bd0a12  seto al
00007583d7bd0a15  mov [r15+0x108], eax
00007583d7bd0a1c  mov eax, [r15+0x108]
00007583d7bd0a23  sahf
00007583d7bd0a24  jz 0x00007583D7BD0A56
00007583d7bd0a26  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0a2e  jz 0x00007583D7BD0AA0
00007583d7bd0a34  nop [rax+rax*1], ax
00007583d7bd0a3d  nop [rax+rax*1], eax
00007583d7bd0a45  mov eax, 0x4102B8
00007583d7bd0a4a  mov [r15+0x100], rax
00007583d7bd0a51  jmp 0x00007583D79FE110
00007583d7bd0a56  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0a5e  jz 0x00007583D7BD0BF0
00007583d7bd0a64  nop [rax+rax*1], ax
00007583d7bd0a6d  nop [rax+rax*1], eax
00007583d7bd0a75  mov eax, 0x4102D4
00007583d7bd0a7a  mov [r15+0x100], rax
00007583d7bd0a81  jmp 0x00007583D79FE110
00007583d7bd0a86  int3
00007583d7bd0a87  call 0x00007583D7AE27E0
00007583d7bd0a8c  jmp 0x00007583D7BD09F3
00007583d7bd0a91  call 0x00007583D7AD5AF0
00007583d7bd0a96  jmp 0x00007583D7BD0A05
00007583d7bd0a9b  int3
00007583d7bd0a9c  nop [rax], eax
00007583d7bd0aa0  mov rax, [r15+0xF8]
00007583d7bd0aa7  lea r14, [rax+0xD0]
00007583d7bd0aae  mov [r15], r14
00007583d7bd0ab1  lea r14, [rax+0x148]
00007583d7bd0ab8  mov [r15+0x08], r14
00007583d7bd0abc  mov qword ptr [r15+0x10], 0x01
00007583d7bd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007583d7bd0acf  mov r14d, [r15+0x320]
00007583d7bd0ad6  mov eax, 0x4102C8
00007583d7bd0adb  mov rcx, 0x7583D7BD0B40
00007583d7bd0ae5  mov [r15+r14*8+0x328], rax
00007583d7bd0aed  mov [r15+r14*8+0x368], rcx
00007583d7bd0af5  add r14d, 0x01
00007583d7bd0af9  and r14d, 0x07
00007583d7bd0afd  mov [r15+0x320], r14d
00007583d7bd0b04  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0b0c  jz 0x00007583D7BCED70
00007583d7bd0b12  nop [rax+rax*1], ax
00007583d7bd0b1b  nop [rax+rax*1], eax
00007583d7bd0b23  mov eax, 0x4106BC
00007583d7bd0b28  mov [r15+0x100], rax
00007583d7bd0b2f  jmp 0x00007583D79FE110
00007583d7bd0b34  int3
00007583d7bd0b35  int3
00007583d7bd0b36  nop [rax+rax*1], ax
00007583d7bd0b3f  nop
00007583d7bd0b40  mov rax, [r15+0xF8]
00007583d7bd0b47  lea r14, [rax+0x138]
00007583d7bd0b4e  mov rax, [r13+r14*1]
00007583d7bd0b53  mov [r15+0x40], rax
00007583d7bd0b57  mov [rsp+0x10], rax
00007583d7bd0b5c  xor eax, eax
00007583d7bd0b5e  mov r14, [rsp+0x10]
00007583d7bd0b63  mov r12d, 0x38
00007583d7bd0b69  cmp r14, r12
00007583d7bd0b6c  cmc
00007583d7bd0b6d  lahf
00007583d7bd0b6e  seto al
00007583d7bd0b71  mov [r15+0x108], eax
00007583d7bd0b78  mov eax, [r15+0x108]
00007583d7bd0b7f  sahf
00007583d7bd0b80  jnz 0x00007583D7BD0BB2
00007583d7bd0b82  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0b8a  jz 0x00007583D7BD0BF0
00007583d7bd0b90  nop [rax+rax*1], ax
00007583d7bd0b99  nop [rax+rax*1], eax
00007583d7bd0ba1  mov eax, 0x4102D4
00007583d7bd0ba6  mov [r15+0x100], rax
00007583d7bd0bad  jmp 0x00007583D79FE110
00007583d7bd0bb2  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0bba  jz 0x00007583D7BD0AA0
00007583d7bd0bc0  nop [rax+rax*1], ax
00007583d7bd0bc9  nop [rax+rax*1], eax
00007583d7bd0bd1  mov eax, 0x4102B8
00007583d7bd0bd6  mov [r15+0x100], rax
00007583d7bd0bdd  jmp 0x00007583D79FE110
00007583d7bd0be2  int3
00007583d7bd0be3  call 0x00007583D7AD59C0
00007583d7bd0be8  jmp 0x00007583D7BD0B53
00007583d7bd0bed  int3
00007583d7bd0bee  nop
00007583d7bd0bf0  mov rax, [r15+0x98]
00007583d7bd0bf7  rorx r14, rax, 0x3D
00007583d7bd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007583d7bd0c01  mov rax, [r15+0xF8]
00007583d7bd0c08  lea r12, [rax+0xD0]
00007583d7bd0c0f  mov [r15], r12
00007583d7bd0c12  lea r12, [rax+0x140]
00007583d7bd0c19  mov [r15+0x08], r12
00007583d7bd0c1d  mov qword ptr [r15+0x10], 0x08
00007583d7bd0c25  bswap r14
00007583d7bd0c28  mov [r15+0x40], r14
00007583d7bd0c2c  lea r12, [rax+0x140]
00007583d7bd0c33  mov [r13+r12*1], r14
00007583d7bd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007583d7bd0c43  mov r14d, [r15+0x320]
00007583d7bd0c4a  mov eax, 0x4102F0
00007583d7bd0c4f  mov rcx, 0x7583D7BD0CC0
00007583d7bd0c59  mov [r15+r14*8+0x328], rax
00007583d7bd0c61  mov [r15+r14*8+0x368], rcx
00007583d7bd0c69  add r14d, 0x01
00007583d7bd0c6d  and r14d, 0x07
00007583d7bd0c71  mov [r15+0x320], r14d
00007583d7bd0c78  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0c80  jz 0x00007583D7BCED70
00007583d7bd0c86  nop [rax+rax*1], ax
00007583d7bd0c8f  nop [rax+rax*1], eax
00007583d7bd0c97  mov eax, 0x4106BC
00007583d7bd0c9c  mov [r15+0x100], rax
00007583d7bd0ca3  jmp 0x00007583D79FE110
00007583d7bd0ca8  int3
00007583d7bd0ca9  call 0x00007583D7AC3FE0
00007583d7bd0cae  jmp 0x00007583D7BD0C38
00007583d7bd0cb3  int3
00007583d7bd0cb4  nop [rax+rax*1], ax
00007583d7bd0cbd  nop [rax], eax
00007583d7bd0cc0  mov rax, [r15+0xF8]
00007583d7bd0cc7  lea r14, [rax+0xD0]
00007583d7bd0cce  mov r12d, [r13+r14*1]
00007583d7bd0cd3  lea r14, [rax+0xD4]
00007583d7bd0cda  mov r11d, [r13+r14*1]
00007583d7bd0cdf  lea r14, [rax+0xD8]
00007583d7bd0ce6  mov r10d, [r13+r14*1]
00007583d7bd0ceb  lea r14, [rax+0xDC]
00007583d7bd0cf2  mov r9d, [r13+r14*1]
00007583d7bd0cf7  mov qword ptr [r15+0x48], 0x430C20
00007583d7bd0cff  mov qword ptr [r15+0xA0], 0x00
00007583d7bd0d0a  bswap r12d
00007583d7bd0d0d  bswap r11d
00007583d7bd0d10  mov qword ptr [r15+0x98], 0x430D8C
00007583d7bd0d1b  mov r14d, 0x430C20
00007583d7bd0d21  mov [r13+r14*1], r12d
00007583d7bd0d26  mov r14d, 0x430C24
00007583d7bd0d2c  mov [r13+r14*1], r11d
00007583d7bd0d31  bswap r10d
00007583d7bd0d34  bswap r9d
00007583d7bd0d37  lea r14, [rax+0xE0]
00007583d7bd0d3e  mov r12d, [r13+r14*1]
00007583d7bd0d43  lea r14, [rax+0xE4]
00007583d7bd0d4a  mov r11d, [r13+r14*1]
00007583d7bd0d4f  mov r14d, 0x430C28
00007583d7bd0d55  mov [r13+r14*1], r10d
00007583d7bd0d5a  mov r14d, 0x430C2C
00007583d7bd0d60  mov [r13+r14*1], r9d
00007583d7bd0d65  bswap r12d
00007583d7bd0d68  bswap r11d
00007583d7bd0d6b  mov [rsp+0x10], r11d
00007583d7bd0d70  mov r11d, r11d
00007583d7bd0d73  mov [r15+0x58], r11
00007583d7bd0d77  lea r14, [rax+0xE8]
00007583d7bd0d7e  mov r11d, [r13+r14*1]
00007583d7bd0d83  lea r14, [rax+0xEC]
00007583d7bd0d8a  mov eax, [r13+r14*1]
00007583d7bd0d8f  mov [rsp+0x20], eax
00007583d7bd0d93  mov eax, eax
00007583d7bd0d95  mov [r15+0x60], rax
00007583d7bd0d99  mov eax, 0x430C30
00007583d7bd0d9e  mov [r13+rax*1], r12d
00007583d7bd0da3  mov eax, 0x430C34
00007583d7bd0da8  mov r14d, [rsp+0x10]
00007583d7bd0dad  mov [r13+rax*1], r14d
00007583d7bd0db2  bswap r11d
00007583d7bd0db5  mov [rsp+0x10], r11d
00007583d7bd0dba  mov r11d, r11d
00007583d7bd0dbd  mov [r15+0x40], r11
00007583d7bd0dc1  mov eax, [rsp+0x20]
00007583d7bd0dc5  bswap eax
00007583d7bd0dc7  mov [rsp+0x20], eax
00007583d7bd0dcb  mov eax, eax
00007583d7bd0dcd  mov [r15+0x50], rax
00007583d7bd0dd1  mov eax, 0x430C38
00007583d7bd0dd6  mov r14d, [rsp+0x10]
00007583d7bd0ddb  mov [r13+rax*1], r14d
00007583d7bd0de0  mov eax, 0x430C3C
00007583d7bd0de5  mov r14d, [rsp+0x20]
00007583d7bd0dea  mov [r13+rax*1], r14d
00007583d7bd0def  mov eax, [r15+0xA0]
00007583d7bd0df6  lea r14d, [eax+0x11]
00007583d7bd0dfb  mov r14d, r14d
00007583d7bd0dfe  mov [r15], r14
00007583d7bd0e01  mov qword ptr [r15+0xF0], 0x41034C
00007583d7bd0e0c  mov r14d, [r15+0x320]
00007583d7bd0e13  mov eax, 0x41034C
00007583d7bd0e18  mov rcx, 0x7583D7BD0F90
00007583d7bd0e22  mov [r15+r14*8+0x328], rax
00007583d7bd0e2a  mov [r15+r14*8+0x368], rcx
00007583d7bd0e32  add r14d, 0x01
00007583d7bd0e36  and r14d, 0x07
00007583d7bd0e3a  mov [r15+0x320], r14d
00007583d7bd0e41  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0e49  jz 0x00007583D7BD0F20
00007583d7bd0e4f  nop [rax+rax*1], ax
00007583d7bd0e58  nop [rax+rax*1], eax
00007583d7bd0e60  mov eax, 0x410938
00007583d7bd0e65  mov [r15+0x100], rax
00007583d7bd0e6c  jmp 0x00007583D79FE110
00007583d7bd0e71  int3
00007583d7bd0e72  call 0x00007583D7AE26A0
00007583d7bd0e77  jmp 0x00007583D7BD0CD3
00007583d7bd0e7c  call 0x00007583D7AE1430
00007583d7bd0e81  jmp 0x00007583D7BD0CDF
00007583d7bd0e86  call 0x00007583D7AE01C0
00007583d7bd0e8b  jmp 0x00007583D7BD0CEB
00007583d7bd0e90  call 0x00007583D7ADEF50
00007583d7bd0e95  jmp 0x00007583D7BD0CF7
00007583d7bd0e9a  call 0x00007583D7AE2BA0
00007583d7bd0e9f  jmp 0x00007583D7BD0D26
00007583d7bd0ea4  call 0x00007583D7AE1920
00007583d7bd0ea9  jmp 0x00007583D7BD0D31
00007583d7bd0eae  call 0x00007583D7AE26A0
00007583d7bd0eb3  jmp 0x00007583D7BD0D43
00007583d7bd0eb8  call 0x00007583D7AE1430
00007583d7bd0ebd  jmp 0x00007583D7BD0D4F
00007583d7bd0ec2  call 0x00007583D7AE06B0
00007583d7bd0ec7  jmp 0x00007583D7BD0D5A
00007583d7bd0ecc  call 0x00007583D7ADF440
00007583d7bd0ed1  jmp 0x00007583D7BD0D65
00007583d7bd0ed6  call 0x00007583D7AE1430
00007583d7bd0edb  jmp 0x00007583D7BD0D83
00007583d7bd0ee0  call 0x00007583D7AD5890
00007583d7bd0ee5  jmp 0x00007583D7BD0D8F
00007583d7bd0eea  call 0x00007583D7A0BAE0
00007583d7bd0eef  jmp 0x00007583D7BD0DA3
00007583d7bd0ef4  call 0x00007583D7A0DFE0
00007583d7bd0ef9  jmp 0x00007583D7BD0DB2
00007583d7bd0efe  call 0x00007583D7A0DFE0
00007583d7bd0f03  jmp 0x00007583D7BD0DE0
00007583d7bd0f08  call 0x00007583D7A0DFE0
00007583d7bd0f0d  jmp 0x00007583D7BD0DEF
00007583d7bd0f12  int3
00007583d7bd0f13  nop [rax+rax*1], ax
00007583d7bd0f1c  nop [rax], eax
00007583d7bd0f20  mov eax, [r15]
00007583d7bd0f23  mov [rsp+0x10], eax
00007583d7bd0f27  shr eax, 0x10
00007583d7bd0f2a  mov r14d, [rsp+0x10]
00007583d7bd0f2f  xor r14d, eax
00007583d7bd0f32  imul r14d, r14d, 0x7FEB352D
00007583d7bd0f39  mov eax, 0x846CA68B
00007583d7bd0f3e  mov eax, eax
00007583d7bd0f40  mov [r15+0x48], rax
00007583d7bd0f44  mov [rsp+0x10], r14d
00007583d7bd0f49  shr r14d, 0x0F
00007583d7bd0f4d  mov eax, [rsp+0x10]
00007583d7bd0f51  xor eax, r14d
00007583d7bd0f54  imul eax, eax, 0x846CA68B
00007583d7bd0f5a  mov [rsp+0x10], eax
00007583d7bd0f5e  mov eax, eax
00007583d7bd0f60  mov [r15+0x40], rax
00007583d7bd0f64  mov eax, [rsp+0x10]
00007583d7bd0f68  shr eax, 0x10
00007583d7bd0f6b  mov r14d, [rsp+0x10]
00007583d7bd0f70  xor r14d, eax
00007583d7bd0f73  mov r14d, r14d
00007583d7bd0f76  mov [r15], r14
00007583d7bd0f79  mov rax, [r15+0xF0]
00007583d7bd0f80  mov [r15+0x100], rax
00007583d7bd0f87  jmp 0x00007583D7BCE5C0
00007583d7bd0f8c  int3
00007583d7bd0f8d  int3
00007583d7bd0f8e  nop
00007583d7bd0f90  mov rax, [r15+0xA0]
00007583d7bd0f97  mov [rsp+0x10], rax
00007583d7bd0f9c  shl rax, 0x02
00007583d7bd0fa0  mov r14, [r15+0x98]
00007583d7bd0fa7  lea r12, [r14+rax*1]
00007583d7bd0fab  mov eax, [r15]
00007583d7bd0fae  mov [r13+r12*1], eax
00007583d7bd0fb3  mov rax, [rsp+0x10]
00007583d7bd0fb8  lea r14, [rax+0x01]
00007583d7bd0fbc  mov [r15+0xA0], r14
00007583d7bd0fc3  xor eax, eax
00007583d7bd0fc5  mov r12d, 0x400
00007583d7bd0fcb  cmp r14, r12
00007583d7bd0fce  cmc
00007583d7bd0fcf  lahf
00007583d7bd0fd0  seto al
00007583d7bd0fd3  mov [r15+0x108], eax
00007583d7bd0fda  mov eax, [r15+0x108]
00007583d7bd0fe1  sahf
00007583d7bd0fe2  jnz 0x00007583D7BD1014
00007583d7bd0fe4  cmp dword ptr [r15+0x318], 0x00
00007583d7bd0fec  jz 0x00007583D7BD10E0
00007583d7bd0ff2  nop [rax+rax*1], ax
00007583d7bd0ffb  nop [rax+rax*1], eax
00007583d7bd1003  mov eax, 0x41035C
00007583d7bd1008  mov [r15+0x100], rax
00007583d7bd100f  jmp 0x00007583D79FE110
00007583d7bd1014  cmp dword ptr [r15+0x318], 0x00
00007583d7bd101c  jz 0x00007583D7BD1050
00007583d7bd1022  nop [rax+rax*1], ax
00007583d7bd102b  nop [rax+rax*1], eax
00007583d7bd1033  mov eax, 0x410344
00007583d7bd1038  mov [r15+0x100], rax
00007583d7bd103f  jmp 0x00007583D79FE110
00007583d7bd1044  int3
00007583d7bd1045  call 0x00007583D7AB4B70
00007583d7bd104a  jmp 0x00007583D7BD0FB3
00007583d7bd104f  int3
00007583d7bd1050  mov eax, [r15+0xA0]
00007583d7bd1057  lea r14d, [eax+0x11]
00007583d7bd105c  mov r14d, r14d
00007583d7bd105f  mov [r15], r14
00007583d7bd1062  mov qword ptr [r15+0xF0], 0x41034C
00007583d7bd106d  mov r14d, [r15+0x320]
00007583d7bd1074  mov eax, 0x41034C
00007583d7bd1079  mov rcx, 0x7583D7BD0F90
00007583d7bd1083  mov [r15+r14*8+0x328], rax
00007583d7bd108b  mov [r15+r14*8+0x368], rcx
00007583d7bd1093  add r14d, 0x01
00007583d7bd1097  and r14d, 0x07
00007583d7bd109b  mov [r15+0x320], r14d
00007583d7bd10a2  cmp dword ptr [r15+0x318], 0x00
00007583d7bd10aa  jz 0x00007583D7BD0F20
00007583d7bd10b0  nop [rax+rax*1], ax
00007583d7bd10b9  nop [rax+rax*1], eax
00007583d7bd10c1  mov eax, 0x410938
00007583d7bd10c6  mov [r15+0x100], rax
00007583d7bd10cd  jmp 0x00007583D79FE110
00007583d7bd10d2  int3
00007583d7bd10d3  int3
00007583d7bd10d4  nop [rax+rax*1], ax
00007583d7bd10dd  nop [rax], eax
00007583d7bd10e0  mov qword ptr [r15+0x40], 0x01
00007583d7bd10e8  cmp dword ptr [r15+0x318], 0x00
00007583d7bd10f0  jz 0x00007583D7BD1120
00007583d7bd10f6  nop [rax+rax*1], ax
00007583d7bd10ff  nop [rax+rax*1], eax
00007583d7bd1107  mov eax, 0x410378
00007583d7bd110c  mov [r15+0x100], rax
00007583d7bd1113  jmp 0x00007583D79FE110
00007583d7bd1118  int3
00007583d7bd1119  int3
00007583d7bd111a  nop [rax+rax*1], ax
00007583d7bd1120  mov rax, [r15+0x40]
00007583d7bd1124  mov [rsp+0x10], rax
00007583d7bd1129  shl rax, 0x02
00007583d7bd112d  mov r14, [r15+0x98]
00007583d7bd1134  lea r12, [r14+rax*1]
00007583d7bd1138  mov eax, [r13+r12*1]
00007583d7bd113d  mov [rsp+0x20], eax
00007583d7bd1141  mov eax, eax
00007583d7bd1143  mov [r15+0x48], rax
00007583d7bd1147  mov rax, [rsp+0x10]
00007583d7bd114c  mov [r15+0x50], rax
00007583d7bd1150  mov eax, [r15+0x50]
00007583d7bd1154  lea r12d, [eax-0x01]
00007583d7bd1159  mov r12d, r12d
00007583d7bd115c  mov [r15+0x58], r12
00007583d7bd1160  mov rax, [r15+0x58]
00007583d7bd1164  mov r12d, eax
00007583d7bd1167  mov r12d, r12d
00007583d7bd116a  shl r12, 0x02
00007583d7bd116e  lea rax, [r14+r12*1]
00007583d7bd1172  mov r14d, [r13+rax*1]
00007583d7bd1177  mov [rsp+0x10], r14d
00007583d7bd117c  mov r14d, r14d
00007583d7bd117f  mov [r15+0x60], r14
00007583d7bd1183  xor eax, eax
00007583d7bd1185  mov r14d, [rsp+0x10]
00007583d7bd118a  mov r12d, [rsp+0x20]
00007583d7bd118f  cmp r14d, r12d
00007583d7bd1192  cmc
00007583d7bd1193  lahf
00007583d7bd1194  seto al
00007583d7bd1197  mov [r15+0x108], eax
00007583d7bd119e  mov eax, [r15+0x108]
00007583d7bd11a5  sahf
00007583d7bd11a6  cmc
00007583d7bd11a7  jbe 0x00007583D7BD11D9
00007583d7bd11a9  cmp dword ptr [r15+0x318], 0x00
00007583d7bd11b1  jz 0x00007583D7BD1220
00007583d7bd11b7  nop [rax+rax*1], ax
00007583d7bd11c0  nop [rax+rax*1], eax
00007583d7bd11c8  mov eax, 0x410390
00007583d7bd11cd  mov [r15+0x100], rax
00007583d7bd11d4  jmp 0x00007583D79FE110
00007583d7bd11d9  cmp dword ptr [r15+0x318], 0x00
00007583d7bd11e1  jz 0x00007583D7BD14C0
00007583d7bd11e7  nop [rax+rax*1], ax
00007583d7bd11f0  nop [rax+rax*1], eax
00007583d7bd11f8  mov eax, 0x410368
00007583d7bd11fd  mov [r15+0x100], rax
00007583d7bd1204  jmp 0x00007583D79FE110
00007583d7bd1209  int3
00007583d7bd120a  call 0x00007583D7AB4690
00007583d7bd120f  jmp 0x00007583D7BD113D
00007583d7bd1214  call 0x00007583D7A0DAE0
00007583d7bd1219  jmp 0x00007583D7BD1177
00007583d7bd121e  int3
00007583d7bd121f  nop
00007583d7bd1220  mov rax, [r15+0x50]
00007583d7bd1224  mov [rsp+0x10], rax
00007583d7bd1229  shl rax, 0x02
00007583d7bd122d  mov r14, [r15+0x98]
00007583d7bd1234  lea r12, [r14+rax*1]
00007583d7bd1238  mov eax, [r15+0x60]
00007583d7bd123c  mov [r13+r12*1], eax
00007583d7bd1241  mov rax, [rsp+0x10]
00007583d7bd1246  lea r14, [rax-0x01]
00007583d7bd124a  mov [r15+0x50], r14
00007583d7bd124e  mov rax, [r15+0x58]
00007583d7bd1252  test rax, rax
00007583d7bd1255  setz al
00007583d7bd1258  movzx rax, al
00007583d7bd125c  mov [rsp+0x414], al
00007583d7bd1263  cmp byte ptr [rsp+0x414], 0x00
00007583d7bd126b  jz 0x00007583D7BD129D
00007583d7bd126d  cmp dword ptr [r15+0x318], 0x00
00007583d7bd1275  jz 0x00007583D7BD12E0
00007583d7bd127b  nop [rax+rax*1], ax
00007583d7bd1284  nop [rax+rax*1], eax
00007583d7bd128c  mov eax, 0x41039C
00007583d7bd1291  mov [r15+0x100], rax
00007583d7bd1298  jmp 0x00007583D79FE110
00007583d7bd129d  cmp dword ptr [r15+0x318], 0x00
00007583d7bd12a5  jz 0x00007583D7BD13E0
00007583d7bd12ab  nop [rax+rax*1], ax
00007583d7bd12b4  nop [rax+rax*1], eax
00007583d7bd12bc  mov eax, 0x410380
00007583d7bd12c1  mov [r15+0x100], rax
00007583d7bd12c8  jmp 0x00007583D79FE110
00007583d7bd12cd  int3
00007583d7bd12ce  call 0x00007583D7AB4B70
00007583d7bd12d3  jmp 0x00007583D7BD1241
00007583d7bd12d8  int3
00007583d7bd12d9  nop [rax], eax
00007583d7bd12e0  cmp dword ptr [r15+0x318], 0x00
00007583d7bd12e8  jz 0x00007583D7BD1320
00007583d7bd12ee  nop [rax+rax*1], ax
00007583d7bd12f7  nop [rax+rax*1], eax
00007583d7bd12ff  mov eax, 0x410364
00007583d7bd1304  mov [r15+0x100], rax
00007583d7bd130b  jmp 0x00007583D79FE110
00007583d7bd1310  int3
00007583d7bd1311  int3
00007583d7bd1312  nop [rax+rax*1], ax
00007583d7bd131b  nop [rax+rax*1], eax
00007583d7bd1320  mov qword ptr [r15+0x50], 0x00
00007583d7bd1328  mov rax, [r15+0x40]
00007583d7bd132c  lea r14, [rax+0x01]
00007583d7bd1330  mov [r15+0x40], r14
00007583d7bd1334  mov rax, [r15+0x98]
00007583d7bd133b  mov r12d, [r15+0x48]
00007583d7bd133f  mov [r13+rax*1], r12d
00007583d7bd1344  xor eax, eax
00007583d7bd1346  mov r12d, 0x400
00007583d7bd134c  cmp r14, r12
00007583d7bd134f  cmc
00007583d7bd1350  lahf
00007583d7bd1351  seto al
00007583d7bd1354  mov [r15+0x108], eax
00007583d7bd135b  mov eax, [r15+0x108]
00007583d7bd1362  sahf
00007583d7bd1363  jz 0x00007583D7BD1395
00007583d7bd1365  cmp dword ptr [r15+0x318], 0x00
00007583d7bd136d  jz 0x00007583D7BD1120
00007583d7bd1373  nop [rax+rax*1], ax
00007583d7bd137c  nop [rax+rax*1], eax
00007583d7bd1384  mov eax, 0x410378
00007583d7bd1389  mov [r15+0x100], rax
00007583d7bd1390  jmp 0x00007583D79FE110
00007583d7bd1395  cmp dword ptr [r15+0x318], 0x00
00007583d7bd139d  jz 0x00007583D7BD1580
00007583d7bd13a3  nop [rax+rax*1], ax
00007583d7bd13ac  nop [rax+rax*1], eax
00007583d7bd13b4  mov eax, 0x4103A0
00007583d7bd13b9  mov [r15+0x100], rax
00007583d7bd13c0  jmp 0x00007583D79FE110
00007583d7bd13c5  int3
00007583d7bd13c6  call 0x00007583D7A0BAE0
00007583d7bd13cb  jmp 0x00007583D7BD1344
00007583d7bd13d0  int3
00007583d7bd13d1  nop [rax+rax*1], ax
00007583d7bd13da  nop [rax+rax*1], ax
00007583d7bd13e0  mov eax, [r15+0x50]
00007583d7bd13e4  lea r14d, [eax-0x01]
00007583d7bd13e9  mov r14d, r14d
00007583d7bd13ec  mov [r15+0x58], r14
00007583d7bd13f0  mov rax, [r15+0x58]
00007583d7bd13f4  mov r14d, eax
00007583d7bd13f7  mov r14d, r14d
00007583d7bd13fa  shl r14, 0x02
00007583d7bd13fe  mov rax, [r15+0x98]
00007583d7bd1405  lea r12, [rax+r14*1]
00007583d7bd1409  mov eax, [r13+r12*1]
00007583d7bd140e  mov [rsp+0x10], eax
00007583d7bd1412  mov eax, eax
00007583d7bd1414  mov [r15+0x60], rax
00007583d7bd1418  mov eax, [r15+0x48]
00007583d7bd141c  mov [rsp+0x20], eax
00007583d7bd1420  xor eax, eax
00007583d7bd1422  mov r14d, [rsp+0x10]
00007583d7bd1427  mov r12d, [rsp+0x20]
00007583d7bd142c  cmp r14d, r12d
00007583d7bd142f  cmc
00007583d7bd1430  lahf
00007583d7bd1431  seto al
00007583d7bd1434  mov [r15+0x108], eax
00007583d7bd143b  mov eax, [r15+0x108]
00007583d7bd1442  sahf
00007583d7bd1443  cmc
00007583d7bd1444  jbe 0x00007583D7BD1476
00007583d7bd1446  cmp dword ptr [r15+0x318], 0x00
00007583d7bd144e  jz 0x00007583D7BD1220
00007583d7bd1454  nop [rax+rax*1], ax
00007583d7bd145d  nop [rax+rax*1], eax
00007583d7bd1465  mov eax, 0x410390
00007583d7bd146a  mov [r15+0x100], rax
00007583d7bd1471  jmp 0x00007583D79FE110
00007583d7bd1476  cmp dword ptr [r15+0x318], 0x00
00007583d7bd147e  jz 0x00007583D7BD14C0
00007583d7bd1484  nop [rax+rax*1], ax
00007583d7bd148d  nop [rax+rax*1], eax
00007583d7bd1495  mov eax, 0x410368
00007583d7bd149a  mov [r15+0x100], rax
00007583d7bd14a1  jmp 0x00007583D79FE110
00007583d7bd14a6  int3
00007583d7bd14a7  call 0x00007583D7AB4690
00007583d7bd14ac  jmp 0x00007583D7BD140E
00007583d7bd14b1  int3
00007583d7bd14b2  nop [rax+rax*1], ax
00007583d7bd14bb  nop [rax+rax*1], eax
00007583d7bd14c0  mov rax, [r15+0x40]
00007583d7bd14c4  lea r14, [rax+0x01]
00007583d7bd14c8  mov [r15+0x40], r14
00007583d7bd14cc  mov rax, [r15+0x50]
00007583d7bd14d0  mov r12d, eax
00007583d7bd14d3  mov r12d, r12d
00007583d7bd14d6  shl r12, 0x02
00007583d7bd14da  mov rax, [r15+0x98]
00007583d7bd14e1  lea r11, [rax+r12*1]
00007583d7bd14e5  mov eax, [r15+0x48]
00007583d7bd14e9  mov [r13+r11*1], eax
00007583d7bd14ee  xor eax, eax
00007583d7bd14f0  mov r12d, 0x400
00007583d7bd14f6  cmp r14, r12
00007583d7bd14f9  cmc
00007583d7bd14fa  lahf
00007583d7bd14fb  seto al
00007583d7bd14fe  mov [r15+0x108], eax
00007583d7bd1505  mov eax, [r15+0x108]
00007583d7bd150c  sahf
00007583d7bd150d  jz 0x00007583D7BD153F
00007583d7bd150f  cmp dword ptr [r15+0x318], 0x00
00007583d7bd1517  jz 0x00007583D7BD1120
00007583d7bd151d  nop [rax+rax*1], ax
00007583d7bd1526  nop [rax+rax*1], eax
00007583d7bd152e  mov eax, 0x410378
00007583d7bd1533  mov [r15+0x100], rax
00007583d7bd153a  jmp 0x00007583D79FE110
00007583d7bd153f  cmp dword ptr [r15+0x318], 0x00
00007583d7bd1547  jz 0x00007583D7BD1580
00007583d7bd154d  nop [rax+rax*1], ax
00007583d7bd1556  nop [rax+rax*1], eax
00007583d7bd155e  mov eax, 0x4103A0
00007583d7bd1563  mov [r15+0x100], rax
00007583d7bd156a  jmp 0x00007583D79FE110
00007583d7bd156f  int3
00007583d7bd1570  call 0x00007583D7AA4270
00007583d7bd1575  jmp 0x00007583D7BD14EE
00007583d7bd157a  int3
00007583d7bd157b  nop [rax+rax*1], eax
00007583d7bd1580  mov qword ptr [r15+0x40], 0x430000
00007583d7bd1588  mov eax, 0x430C40
00007583d7bd158d  mov r14, [r13+rax*1]
00007583d7bd1592  mov rax, [r15+0x98]
00007583d7bd1599  mov r12d, [r13+rax*1]
00007583d7bd159e  lea r11, [rax+0x04]
00007583d7bd15a2  mov eax, [r13+r11*1]
00007583d7bd15a7  mov r12d, r12d
00007583d7bd15aa  mov [r15+0x68], r12
00007583d7bd15ae  mov eax, eax
00007583d7bd15b0  mov [r15+0x60], rax
00007583d7bd15b4  mov rax, [r15+0x68]
00007583d7bd15b8  mov [r15+0x68], rax
00007583d7bd15bc  mov qword ptr [r15+0x58], 0x02
00007583d7bd15c4  mov [rsp+0x10], rax
00007583d7bd15c9  xor eax, eax
00007583d7bd15cb  mov r12d, 0x02
00007583d7bd15d1  mov r11d, 0x400
00007583d7bd15d7  cmp r12, r11
00007583d7bd15da  cmc
00007583d7bd15db  lahf
00007583d7bd15dc  seto al
00007583d7bd15df  mov [r15+0x108], eax
00007583d7bd15e6  mov rax, [r15+0x60]
00007583d7bd15ea  mov r12d, 0x02
00007583d7bd15f0  imul rax, r12
00007583d7bd15f4  mov [r15+0x50], rax
00007583d7bd15f8  mov rax, [rsp+0x10]
00007583d7bd15fd  lea r12, [rax+r14*1]
00007583d7bd1601  mov [r15+0x48], r12
00007583d7bd1605  mov eax, [r15+0x108]
00007583d7bd160c  sahf
00007583d7bd160d  jnz 0x00007583D7BD163F
00007583d7bd160f  cmp dword ptr [r15+0x318], 0x00
00007583d7bd1617  jz 0x00007583D7BD17B0
00007583d7bd161d  nop [rax+rax*1], ax
00007583d7bd1626  nop [rax+rax*1], eax
00007583d7bd162e  mov eax, 0x4103D0
00007583d7bd1633  mov [r15+0x100], rax
00007583d7bd163a  jmp 0x00007583D79FE110
00007583d7bd163f  cmp dword ptr [r15+0x318], 0x00
00007583d7bd1647  jz 0x00007583D7BD1690
00007583d7bd164d  nop [rax+rax*1], ax
00007583d7bd1656  nop [rax+rax*1], eax
00007583d7bd165e  mov eax, 0x4103B0
00007583d7bd1663  mov [r15+0x100], rax
00007583d7bd166a  jmp 0x00007583D79FE110
00007583d7bd166f  int3
00007583d7bd1670  call 0x00007583D7A0DC20
00007583d7bd1675  jmp 0x00007583D7BD1592
00007583d7bd167a  call 0x00007583D7A0B5E0
00007583d7bd167f  jmp 0x00007583D7BD159E
00007583d7bd1684  call 0x00007583D7AA3D90
00007583d7bd1689  jmp 0x00007583D7BD15A7
00007583d7bd168e  int3
00007583d7bd168f  nop
00007583d7bd1690  mov rax, [r15+0x98]
00007583d7bd1697  mov r14, [r15+0x58]
00007583d7bd169b  mov [rsp+0x10], r14
00007583d7bd16a0  shl r14, 0x02
00007583d7bd16a4  lea r12, [rax+r14*1]
00007583d7bd16a8  mov eax, [r13+r12*1]
00007583d7bd16ad  lea r14, [r12+0x04]
00007583d7bd16b2  mov r12d, [r13+r14*1]
00007583d7bd16b7  mov eax, eax
00007583d7bd16b9  mov [r15+0x68], rax
00007583d7bd16bd  mov r12d, r12d
00007583d7bd16c0  mov [r15+0x60], r12
00007583d7bd16c4  mov rax, [r15+0x68]
00007583d7bd16c8  mov [rsp+0x20], rax
00007583d7bd16cd  mov r14, [rsp+0x10]
00007583d7bd16d2  imul rax, r14
00007583d7bd16d6  mov r12, [rsp+0x20]
00007583d7bd16db  lea r11, [r12+rax*1]
00007583d7bd16df  mov [r15+0x68], r11
00007583d7bd16e3  lea rax, [r14+0x02]
00007583d7bd16e7  mov [r15+0x58], rax
00007583d7bd16eb  mov [rsp+0x10], rax
00007583d7bd16f0  xor eax, eax
00007583d7bd16f2  mov r14, [rsp+0x10]
00007583d7bd16f7  mov r12d, 0x400
00007583d7bd16fd  cmp r14, r12
00007583d7bd1700  cmc
00007583d7bd1701  lahf
00007583d7bd1702  seto al
00007583d7bd1705  mov [r15+0x108], eax
00007583d7bd170c  mov rax, [r15+0x50]
00007583d7bd1710  mov r12, [r15+0x60]
00007583d7bd1714  imul r14, r12
00007583d7bd1718  lea r12, [rax+r14*1]
00007583d7bd171c  mov [r15+0x50], r12
00007583d7bd1720  mov rax, [r15+0x48]
00007583d7bd1724  lea r14, [r11+rax*1]
00007583d7bd1728  mov [r15+0x48], r14
00007583d7bd172c  mov eax, [r15+0x108]
00007583d7bd1733  sahf
00007583d7bd1734  jnz 0x00007583D7BD1766
00007583d7bd1736  cmp dword ptr [r15+0x318], 0x00
00007583d7bd173e  jz 0x00007583D7BD17B0
00007583d7bd1744  nop [rax+rax*1], ax
00007583d7bd174d  nop [rax+rax*1], eax
00007583d7bd1755  mov eax, 0x4103D0
00007583d7bd175a  mov [r15+0x100], rax
00007583d7bd1761  jmp 0x00007583D79FE110
00007583d7bd1766  cmp dword ptr [r15+0x318], 0x00
00007583d7bd176e  jz 0x00007583D7BD1690
00007583d7bd1774  nop [rax+rax*1], ax
00007583d7bd177d  nop [rax+rax*1], eax
00007583d7bd1785  mov eax, 0x4103B0
00007583d7bd178a  mov [r15+0x100], rax
00007583d7bd1791  jmp 0x00007583D79FE110
00007583d7bd1796  int3
00007583d7bd1797  call 0x00007583D7AB4690
00007583d7bd179c  jmp 0x00007583D7BD16AD
00007583d7bd17a1  call 0x00007583D7AE26A0
00007583d7bd17a6  jmp 0x00007583D7BD16B7
00007583d7bd17ab  int3
00007583d7bd17ac  nop [rax], eax
00007583d7bd17b0  mov qword ptr [r15+0x98], 0x00
00007583d7bd17bb  mov rax, [r15+0x50]
00007583d7bd17bf  mov r14, [r15+0x48]
00007583d7bd17c3  lea r12, [rax+r14*1]
00007583d7bd17c7  mov [r15+0x48], r12
00007583d7bd17cb  mov rax, [r15+0x40]
00007583d7bd17cf  lea r14, [rax+0xC40]
00007583d7bd17d6  mov [r13+r14*1], r12
00007583d7bd17db  mov qword ptr [r15], 0x01
00007583d7bd17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007583d7bd17ed  mov r14d, [r15+0x320]
00007583d7bd17f4  mov eax, 0x4103E8
00007583d7bd17f9  mov rcx, 0x7583D7BD1860
00007583d7bd1803  mov [r15+r14*8+0x328], rax
00007583d7bd180b  mov [r15+r14*8+0x368], rcx
00007583d7bd1813  add r14d, 0x01
00007583d7bd1817  and r14d, 0x07
00007583d7bd181b  mov [r15+0x320], r14d
00007583d7bd1822  cmp dword ptr [r15+0x318], 0x00
00007583d7bd182a  jz 0x00007583D7BD0F20
00007583d7bd1830  nop [rax+rax*1], ax
00007583d7bd1839  nop [rax+rax*1], eax
00007583d7bd1841  mov eax, 0x410938
00007583d7bd1846  mov [r15+0x100], rax
00007583d7bd184d  jmp 0x00007583D79FE110
00007583d7bd1852  int3
00007583d7bd1853  call 0x00007583D7AE2CE0
00007583d7bd1858  jmp 0x00007583D7BD17DB
00007583d7bd185d  int3
00007583d7bd185e  nop
00007583d7bd1860  mov eax, [r15+0x98]
00007583d7bd1867  lea r14d, [eax+0x01]
00007583d7bd186c  mov [rsp+0x10], r14d
00007583d7bd1871  mov r14d, r14d
00007583d7bd1874  mov [r15+0x98], r14
00007583d7bd187b  xor eax, eax
00007583d7bd187d  mov r14d, [rsp+0x10]
00007583d7bd1882  cmp r14d, 0x10000
00007583d7bd1889  cmc
00007583d7bd188a  lahf
00007583d7bd188b  seto al
00007583d7bd188e  mov [r15+0x108], eax
00007583d7bd1895  mov eax, [r15+0x108]
00007583d7bd189c  sahf
00007583d7bd189d  jnz 0x00007583D7BD18CF
00007583d7bd189f  cmp dword ptr [r15+0x318], 0x00
00007583d7bd18a7  jz 0x00007583D7BD19A0
00007583d7bd18ad  nop [rax+rax*1], ax
00007583d7bd18b6  nop [rax+rax*1], eax
00007583d7bd18be  mov eax, 0x4103F4
00007583d7bd18c3  mov [r15+0x100], rax
00007583d7bd18ca  jmp 0x00007583D79FE110
00007583d7bd18cf  cmp dword ptr [r15+0x318], 0x00
00007583d7bd18d7  jz 0x00007583D7BD1910
00007583d7bd18dd  nop [rax+rax*1], ax
00007583d7bd18e6  nop [rax+rax*1], eax
00007583d7bd18ee  mov eax, 0x4103E0
00007583d7bd18f3  mov [r15+0x100], rax
00007583d7bd18fa  jmp 0x00007583D79FE110
00007583d7bd18ff  int3
00007583d7bd1900  int3
00007583d7bd1901  nop [rax+rax*1], ax
00007583d7bd190a  nop [rax+rax*1], ax
00007583d7bd1910  mov eax, [r15]
00007583d7bd1913  mov r14d, [r15+0x98]
00007583d7bd191a  lea r12d, [eax+r14d*1]
00007583d7bd191f  mov r12d, r12d
00007583d7bd1922  mov [r15], r12
00007583d7bd1925  mov qword ptr [r15+0xF0], 0x4103E8
00007583d7bd1930  mov r14d, [r15+0x320]
00007583d7bd1937  mov eax, 0x4103E8
00007583d7bd193c  mov rcx, 0x7583D7BD1860
00007583d7bd1946  mov [r15+r14*8+0x328], rax
00007583d7bd194e  mov [r15+r14*8+0x368], rcx
00007583d7bd1956  add r14d, 0x01
00007583d7bd195a  and r14d, 0x07
00007583d7bd195e  mov [r15+0x320], r14d
00007583d7bd1965  cmp dword ptr [r15+0x318], 0x00
00007583d7bd196d  jz 0x00007583D7BD0F20
00007583d7bd1973  nop [rax+rax*1], ax
00007583d7bd197c  nop [rax+rax*1], eax
00007583d7bd1984  mov eax, 0x410938
00007583d7bd1989  mov [r15+0x100], rax
00007583d7bd1990  jmp 0x00007583D79FE110
00007583d7bd1995  int3
00007583d7bd1996  int3
00007583d7bd1997  nop [rax+rax*1], ax
00007583d7bd19a0  vmovaps xmm1, [0x00007583D77FE010]
00007583d7bd19a8  movq xmm1, xmm1
00007583d7bd19ac  movaps [r15+0x110], xmm1
00007583d7bd19b4  mov eax, 0x420AA0
00007583d7bd19b9  mov r14, [r13+rax*1]
00007583d7bd19be  movq xmm1, r14
00007583d7bd19c3  movaps [r15+0x120], xmm1
00007583d7bd19cb  vmovaps xmm1, [0x00007583D77FE020]
00007583d7bd19d3  movq xmm1, xmm1
00007583d7bd19d7  movaps [r15+0x140], xmm1
00007583d7bd19df  vmovaps xmm1, [0x00007583D77FE030]
00007583d7bd19e7  vpbroadcastq xmm1, xmm1
00007583d7bd19ec  movaps [r15+0x150], xmm1
00007583d7bd19f4  mov qword ptr [r15+0x40], 0x02
00007583d7bd19fc  vmovaps xmm15, [0x00007583D77FE040]
00007583d7bd1a04  movq xmm15, xmm15
00007583d7bd1a09  movaps [r15+0x160], xmm15
00007583d7bd1a11  vmovaps xmm15, [0x00007583D77FE050]
00007583d7bd1a19  vpbroadcastq xmm15, xmm15
00007583d7bd1a1e  movaps [r15+0x130], xmm15
00007583d7bd1a26  mov rax, [r15+0x40]
00007583d7bd1a2a  vmovq xmm14, rax
00007583d7bd1a2f  vpbroadcastq xmm14, xmm14
00007583d7bd1a34  movaps [r15+0x170], xmm14
00007583d7bd1a3c  mov eax, 0x4209D0
00007583d7bd1a41  movups xmm13, [r13+rax*1]
00007583d7bd1a47  mov qword ptr [r15+0x40], 0x431D90
00007583d7bd1a4f  mov eax, [r15]
00007583d7bd1a52  mov r14d, 0x430C48
00007583d7bd1a58  mov [r13+r14*1], eax
00007583d7bd1a5d  mov qword ptr [r15+0x50], 0x431F90
00007583d7bd1a65  vpmovqd xmm12, xmm13
00007583d7bd1a6b  pxor xmm11, xmm11
00007583d7bd1a70  punpcklqdq xmm12, xmm11
00007583d7bd1a75  movaps [r15+0x210], xmm12
00007583d7bd1a7d  movq xmm12, qword ptr [r15+0x140]
00007583d7bd1a86  movq xmm11, qword ptr [r15+0x120]
00007583d7bd1a8f  psubd xmm12, xmm11
00007583d7bd1a94  movq xmm12, xmm12
00007583d7bd1a99  paddq xmm13, xmm14
00007583d7bd1a9e  movaps [r15+0x180], xmm13
00007583d7bd1aa6  movq xmm14, qword ptr [r15+0x160]
00007583d7bd1aaf  paddd xmm11, xmm14
00007583d7bd1ab4  movq xmm11, xmm11
00007583d7bd1ab9  movq xmm11, xmm11
00007583d7bd1abe  movaps [r15+0x120], xmm11
00007583d7bd1ac6  pmovzxdq xmm12, xmm12
00007583d7bd1acc  psllq xmm12, 0x00
00007583d7bd1ad2  movq xmm14, qword ptr [r15+0x210]
00007583d7bd1adb  movq xmm13, qword ptr [r15+0x110]
00007583d7bd1ae4  paddd xmm14, xmm13
00007583d7bd1ae9  movq xmm14, xmm14
00007583d7bd1aee  vcvtuqq2pd xmm12, xmm12
00007583d7bd1af4  pmovzxdq xmm14, xmm14
00007583d7bd1afa  psllq xmm14, 0x00
00007583d7bd1b00  vcvtuqq2pd xmm14, xmm14
00007583d7bd1b06  movaps xmm13, xmm12
00007583d7bd1b0a  mulpd xmm13, xmm1
00007583d7bd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007583d7bd1b15  ptest xmm11, xmm11
00007583d7bd1b1b  jnz 0x00007583D7BD1C0F
00007583d7bd1b21  movaps [r15+0x220], xmm13
00007583d7bd1b29  mov eax, 0x431F90
00007583d7bd1b2e  movups [r13+rax*1], xmm13
00007583d7bd1b34  movaps xmm1, xmm14
00007583d7bd1b38  mulpd xmm1, xmm15
00007583d7bd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007583d7bd1b42  ptest xmm13, xmm13
00007583d7bd1b48  jnz 0x00007583D7BD1D5C
00007583d7bd1b4e  movaps [r15+0x210], xmm1
00007583d7bd1b56  mov eax, 0x431D90
00007583d7bd1b5b  movups [r13+rax*1], xmm1
00007583d7bd1b61  mov qword ptr [r15+0x48], 0x10
00007583d7bd1b69  xor eax, eax
00007583d7bd1b6b  mov r14d, 0x10
00007583d7bd1b71  mov r12d, 0x200
00007583d7bd1b77  cmp r14, r12
00007583d7bd1b7a  cmc
00007583d7bd1b7b  lahf
00007583d7bd1b7c  seto al
00007583d7bd1b7f  mov [r15+0x108], eax
00007583d7bd1b86  mov eax, [r15+0x108]
00007583d7bd1b8d  sahf
00007583d7bd1b8e  jnz 0x00007583D7BD1BC0
00007583d7bd1b90  cmp dword ptr [r15+0x318], 0x00
00007583d7bd1b98  jz 0x00007583D7BD2300
00007583d7bd1b9e  nop [rax+rax*1], ax
00007583d7bd1ba7  nop [rax+rax*1], eax
00007583d7bd1baf  mov eax, 0x410480
00007583d7bd1bb4  mov [r15+0x100], rax
00007583d7bd1bbb  jmp 0x00007583D79FE110
00007583d7bd1bc0  cmp dword ptr [r15+0x318], 0x00
00007583d7bd1bc8  jz 0x00007583D7BD1EB0
00007583d7bd1bce  nop [rax+rax*1], ax
00007583d7bd1bd7  nop [rax+rax*1], eax
00007583d7bd1bdf  mov eax, 0x410440
00007583d7bd1be4  mov [r15+0x100], rax
00007583d7bd1beb  jmp 0x00007583D79FE110
00007583d7bd1bf0  int3
00007583d7bd1bf1  call 0x00007583D7A0DC20
00007583d7bd1bf6  jmp 0x00007583D7BD19BE
00007583d7bd1bfb  call 0x00007583D7A0C260
00007583d7bd1c00  jmp 0x00007583D7BD1A47
00007583d7bd1c05  call 0x00007583D7AD5D70
00007583d7bd1c0a  jmp 0x00007583D7BD1A5D
00007583d7bd1c0f  sub rsp, 0x08
00007583d7bd1c13  push rax
00007583d7bd1c14  push rcx
00007583d7bd1c15  push rdx
00007583d7bd1c16  push rdi
00007583d7bd1c17  push rsi
00007583d7bd1c18  push r8
00007583d7bd1c1a  push r9
00007583d7bd1c1c  push r10
00007583d7bd1c1e  push r11
00007583d7bd1c20  sub rsp, 0xF0
00007583d7bd1c27  vmovaps [rsp], xmm0
00007583d7bd1c2c  vmovaps [rsp+0x10], xmm1
00007583d7bd1c32  vmovaps [rsp+0x20], xmm2
00007583d7bd1c38  vmovaps [rsp+0x30], xmm3
00007583d7bd1c3e  vmovaps [rsp+0x40], xmm4
00007583d7bd1c44  vmovaps [rsp+0x50], xmm5
00007583d7bd1c4a  vmovaps [rsp+0x60], xmm6
00007583d7bd1c50  vmovaps [rsp+0x70], xmm7
00007583d7bd1c56  vmovaps [rsp+0x80], xmm8
00007583d7bd1c5f  vmovaps [rsp+0x90], xmm9
00007583d7bd1c68  vmovaps [rsp+0xA0], xmm10
00007583d7bd1c71  vmovaps [rsp+0xB0], xmm11
00007583d7bd1c7a  vmovaps [rsp+0xC0], xmm12
00007583d7bd1c83  vmovaps [rsp+0xD0], xmm14
00007583d7bd1c8c  vmovaps [rsp+0xE0], xmm15
00007583d7bd1c95  sub rsp, 0x30
00007583d7bd1c99  movaps [rsp], xmm13
00007583d7bd1c9e  movaps [rsp+0x10], xmm12
00007583d7bd1ca4  movaps [rsp+0x20], xmm1
00007583d7bd1ca9  lea rdi, [rsp]
00007583d7bd1cad  mov esi, 0x00
00007583d7bd1cb2  mov rax, 0x5BCB7EA35530
00007583d7bd1cbc  call rax
00007583d7bd1cbe  movaps xmm13, [rsp]
00007583d7bd1cc3  add rsp, 0x30
00007583d7bd1cc7  vmovaps xmm0, [rsp]
00007583d7bd1ccc  vmovaps xmm1, [rsp+0x10]
00007583d7bd1cd2  vmovaps xmm2, [rsp+0x20]
00007583d7bd1cd8  vmovaps xmm3, [rsp+0x30]
00007583d7bd1cde  vmovaps xmm4, [rsp+0x40]
00007583d7bd1ce4  vmovaps xmm5, [rsp+0x50]
00007583d7bd1cea  vmovaps xmm6, [rsp+0x60]
00007583d7bd1cf0  vmovaps xmm7, [rsp+0x70]
00007583d7bd1cf6  vmovaps xmm8, [rsp+0x80]
00007583d7bd1cff  vmovaps xmm9, [rsp+0x90]
00007583d7bd1d08  vmovaps xmm10, [rsp+0xA0]
00007583d7bd1d11  vmovaps xmm11, [rsp+0xB0]
00007583d7bd1d1a  vmovaps xmm12, [rsp+0xC0]
00007583d7bd1d23  vmovaps xmm14, [rsp+0xD0]
00007583d7bd1d2c  vmovaps xmm15, [rsp+0xE0]
00007583d7bd1d35  add rsp, 0xF0
00007583d7bd1d3c  pop r11
00007583d7bd1d3e  pop r10
00007583d7bd1d40  pop r9
00007583d7bd1d42  pop r8
00007583d7bd1d44  pop rsi
00007583d7bd1d45  pop rdi
00007583d7bd1d46  pop rdx
00007583d7bd1d47  pop rcx
00007583d7bd1d48  pop rax
00007583d7bd1d49  add rsp, 0x08
00007583d7bd1d4d  jmp 0x00007583D7BD1B21
00007583d7bd1d52  call 0x00007583D7A0C380
00007583d7bd1d57  jmp 0x00007583D7BD1B34
00007583d7bd1d5c  sub rsp, 0x08
00007583d7bd1d60  push rax
00007583d7bd1d61  push rcx
00007583d7bd1d62  push rdx
00007583d7bd1d63  push rdi
00007583d7bd1d64  push rsi
00007583d7bd1d65  push r8
00007583d7bd1d67  push r9
00007583d7bd1d69  push r10
00007583d7bd1d6b  push r11
00007583d7bd1d6d  sub rsp, 0xF0
00007583d7bd1d74  vmovaps [rsp], xmm0
00007583d7bd1d79  vmovaps [rsp+0x10], xmm2
00007583d7bd1d7f  vmovaps [rsp+0x20], xmm3
00007583d7bd1d85  vmovaps [rsp+0x30], xmm4
00007583d7bd1d8b  vmovaps [rsp+0x40], xmm5
00007583d7bd1d91  vmovaps [rsp+0x50], xmm6
00007583d7bd1d97  vmovaps [rsp+0x60], xmm7
00007583d7bd1d9d  vmovaps [rsp+0x70], xmm8
00007583d7bd1da3  vmovaps [rsp+0x80], xmm9
00007583d7bd1dac  vmovaps [rsp+0x90], xmm10
00007583d7bd1db5  vmovaps [rsp+0xA0], xmm11
00007583d7bd1dbe  vmovaps [rsp+0xB0], xmm12
00007583d7bd1dc7  vmovaps [rsp+0xC0], xmm13
00007583d7bd1dd0  vmovaps [rsp+0xD0], xmm14
00007583d7bd1dd9  vmovaps [rsp+0xE0], xmm15
00007583d7bd1de2  sub rsp, 0x30
00007583d7bd1de6  movaps [rsp], xmm1
00007583d7bd1dea  movaps [rsp+0x10], xmm14
00007583d7bd1df0  movaps [rsp+0x20], xmm15
00007583d7bd1df6  lea rdi, [rsp]
00007583d7bd1dfa  mov esi, 0x00
00007583d7bd1dff  mov rax, 0x5BCB7EA35530
00007583d7bd1e09  call rax
00007583d7bd1e0b  movaps xmm1, [rsp]
00007583d7bd1e0f  add rsp, 0x30
00007583d7bd1e13  vmovaps xmm0, [rsp]
00007583d7bd1e18  vmovaps xmm2, [rsp+0x10]
00007583d7bd1e1e  vmovaps xmm3, [rsp+0x20]
00007583d7bd1e24  vmovaps xmm4, [rsp+0x30]
00007583d7bd1e2a  vmovaps xmm5, [rsp+0x40]
00007583d7bd1e30  vmovaps xmm6, [rsp+0x50]
00007583d7bd1e36  vmovaps xmm7, [rsp+0x60]
00007583d7bd1e3c  vmovaps xmm8, [rsp+0x70]
00007583d7bd1e42  vmovaps xmm9, [rsp+0x80]
00007583d7bd1e4b  vmovaps xmm10, [rsp+0x90]
00007583d7bd1e54  vmovaps xmm11, [rsp+0xA0]
00007583d7bd1e5d  vmovaps xmm12, [rsp+0xB0]
00007583d7bd1e66  vmovaps xmm13, [rsp+0xC0]
00007583d7bd1e6f  vmovaps xmm14, [rsp+0xD0]
00007583d7bd1e78  vmovaps xmm15, [rsp+0xE0]
00007583d7bd1e81  add rsp, 0xF0
00007583d7bd1e88  pop r11
00007583d7bd1e8a  pop r10
00007583d7bd1e8c  pop r9
00007583d7bd1e8e  pop r8
00007583d7bd1e90  pop rsi
00007583d7bd1e91  pop rdi
00007583d7bd1e92  pop rdx
00007583d7bd1e93  pop rcx
00007583d7bd1e94  pop rax
00007583d7bd1e95  add rsp, 0x08
00007583d7bd1e99  jmp 0x00007583D7BD1B4E
00007583d7bd1e9e  call 0x00007583D79FF540
00007583d7bd1ea3  jmp 0x00007583D7BD1B61
00007583d7bd1ea8  int3
00007583d7bd1ea9  nop [rax], eax
00007583d7bd1eb0  movaps xmm1, [r15+0x180]
00007583d7bd1eb8  vpmovqd xmm15, xmm1
00007583d7bd1ebe  pxor xmm14, xmm14
00007583d7bd1ec3  punpcklqdq xmm15, xmm14
00007583d7bd1ec8  movaps [r15+0x210], xmm15
00007583d7bd1ed0  movq xmm15, qword ptr [r15+0x140]
00007583d7bd1ed9  movq xmm14, qword ptr [r15+0x120]
00007583d7bd1ee2  psubd xmm15, xmm14
00007583d7bd1ee7  movq xmm15, xmm15
00007583d7bd1eec  movaps xmm13, [r15+0x170]
00007583d7bd1ef4  paddq xmm1, xmm13
00007583d7bd1ef9  movaps [r15+0x180], xmm1
00007583d7bd1f01  movq xmm1, qword ptr [r15+0x160]
00007583d7bd1f0a  paddd xmm14, xmm1
00007583d7bd1f0f  movq xmm14, xmm14
00007583d7bd1f14  movq xmm14, xmm14
00007583d7bd1f19  movaps [r15+0x120], xmm14
00007583d7bd1f21  pmovzxdq xmm15, xmm15
00007583d7bd1f27  psllq xmm15, 0x00
00007583d7bd1f2d  movq xmm1, qword ptr [r15+0x210]
00007583d7bd1f36  movq xmm14, qword ptr [r15+0x110]
00007583d7bd1f3f  paddd xmm1, xmm14
00007583d7bd1f44  movq xmm1, xmm1
00007583d7bd1f48  vcvtuqq2pd xmm15, xmm15
00007583d7bd1f4e  pmovzxdq xmm1, xmm1
00007583d7bd1f53  psllq xmm1, 0x00
00007583d7bd1f58  vcvtuqq2pd xmm1, xmm1
00007583d7bd1f5e  movaps xmm14, [r15+0x150]
00007583d7bd1f66  movaps xmm13, xmm15
00007583d7bd1f6a  mulpd xmm13, xmm14
00007583d7bd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd1f75  ptest xmm12, xmm12
00007583d7bd1f7b  jnz 0x00007583D7BD205E
00007583d7bd1f81  movaps [r15+0x220], xmm13
00007583d7bd1f89  mov rax, [r15+0x48]
00007583d7bd1f8d  mov r14, [r15+0x50]
00007583d7bd1f91  lea r12, [r14+rax*1]
00007583d7bd1f95  movups [r13+r12*1], xmm13
00007583d7bd1f9b  movaps xmm15, [r15+0x130]
00007583d7bd1fa3  movaps xmm14, xmm1
00007583d7bd1fa7  mulpd xmm14, xmm15
00007583d7bd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007583d7bd1fb2  ptest xmm13, xmm13
00007583d7bd1fb8  jnz 0x00007583D7BD21AC
00007583d7bd1fbe  movaps [r15+0x210], xmm14
00007583d7bd1fc6  mov r14, [r15+0x40]
00007583d7bd1fca  lea r12, [r14+rax*1]
00007583d7bd1fce  movups [r13+r12*1], xmm14
00007583d7bd1fd4  lea r14, [rax+0x10]
00007583d7bd1fd8  mov [r15+0x48], r14
00007583d7bd1fdc  xor eax, eax
00007583d7bd1fde  mov r12d, 0x200
00007583d7bd1fe4  cmp r14, r12
00007583d7bd1fe7  cmc
00007583d7bd1fe8  lahf
00007583d7bd1fe9  seto al
00007583d7bd1fec  mov [r15+0x108], eax
00007583d7bd1ff3  mov eax, [r15+0x108]
00007583d7bd1ffa  sahf
00007583d7bd1ffb  jnz 0x00007583D7BD202D
00007583d7bd1ffd  cmp dword ptr [r15+0x318], 0x00
00007583d7bd2005  jz 0x00007583D7BD2300
00007583d7bd200b  nop [rax+rax*1], ax
00007583d7bd2014  nop [rax+rax*1], eax
00007583d7bd201c  mov eax, 0x410480
00007583d7bd2021  mov [r15+0x100], rax
00007583d7bd2028  jmp 0x00007583D79FE110
00007583d7bd202d  cmp dword ptr [r15+0x318], 0x00
00007583d7bd2035  jz 0x00007583D7BD1EB0
00007583d7bd203b  nop [rax+rax*1], ax
00007583d7bd2044  nop [rax+rax*1], eax
00007583d7bd204c  mov eax, 0x410440
00007583d7bd2051  mov [r15+0x100], rax
00007583d7bd2058  jmp 0x00007583D79FE110
00007583d7bd205d  int3
00007583d7bd205e  sub rsp, 0x08
00007583d7bd2062  push rax
00007583d7bd2063  push rcx
00007583d7bd2064  push rdx
00007583d7bd2065  push rdi
00007583d7bd2066  push rsi
00007583d7bd2067  push r8
00007583d7bd2069  push r9
00007583d7bd206b  push r10
00007583d7bd206d  push r11
00007583d7bd206f  sub rsp, 0xF0
00007583d7bd2076  vmovaps [rsp], xmm0
00007583d7bd207b  vmovaps [rsp+0x10], xmm1
00007583d7bd2081  vmovaps [rsp+0x20], xmm2
00007583d7bd2087  vmovaps [rsp+0x30], xmm3
00007583d7bd208d  vmovaps [rsp+0x40], xmm4
00007583d7bd2093  vmovaps [rsp+0x50], xmm5
00007583d7bd2099  vmovaps [rsp+0x60], xmm6
00007583d7bd209f  vmovaps [rsp+0x70], xmm7
00007583d7bd20a5  vmovaps [rsp+0x80], xmm8
00007583d7bd20ae  vmovaps [rsp+0x90], xmm9
00007583d7bd20b7  vmovaps [rsp+0xA0], xmm10
00007583d7bd20c0  vmovaps [rsp+0xB0], xmm11
00007583d7bd20c9  vmovaps [rsp+0xC0], xmm12
00007583d7bd20d2  vmovaps [rsp+0xD0], xmm14
00007583d7bd20db  vmovaps [rsp+0xE0], xmm15
00007583d7bd20e4  sub rsp, 0x30
00007583d7bd20e8  movaps [rsp], xmm13
00007583d7bd20ed  movaps [rsp+0x10], xmm15
00007583d7bd20f3  movaps [rsp+0x20], xmm14
00007583d7bd20f9  lea rdi, [rsp]
00007583d7bd20fd  mov esi, 0x00
00007583d7bd2102  mov rax, 0x5BCB7EA35530
00007583d7bd210c  call rax
00007583d7bd210e  movaps xmm13, [rsp]
00007583d7bd2113  add rsp, 0x30
00007583d7bd2117  vmovaps xmm0, [rsp]
00007583d7bd211c  vmovaps xmm1, [rsp+0x10]
00007583d7bd2122  vmovaps xmm2, [rsp+0x20]
00007583d7bd2128  vmovaps xmm3, [rsp+0x30]
00007583d7bd212e  vmovaps xmm4, [rsp+0x40]
00007583d7bd2134  vmovaps xmm5, [rsp+0x50]
00007583d7bd213a  vmovaps xmm6, [rsp+0x60]
00007583d7bd2140  vmovaps xmm7, [rsp+0x70]
00007583d7bd2146  vmovaps xmm8, [rsp+0x80]
00007583d7bd214f  vmovaps xmm9, [rsp+0x90]
00007583d7bd2158  vmovaps xmm10, [rsp+0xA0]
00007583d7bd2161  vmovaps xmm11, [rsp+0xB0]
00007583d7bd216a  vmovaps xmm12, [rsp+0xC0]
00007583d7bd2173  vmovaps xmm14, [rsp+0xD0]
00007583d7bd217c  vmovaps xmm15, [rsp+0xE0]
00007583d7bd2185  add rsp, 0xF0
00007583d7bd218c  pop r11
00007583d7bd218e  pop r10
00007583d7bd2190  pop r9
00007583d7bd2192  pop r8
00007583d7bd2194  pop rsi
00007583d7bd2195  pop rdi
00007583d7bd2196  pop rdx
00007583d7bd2197  pop rcx
00007583d7bd2198  pop rax
00007583d7bd2199  add rsp, 0x08
00007583d7bd219d  jmp 0x00007583D7BD1F81
00007583d7bd21a2  call 0x00007583D7AC2240
00007583d7bd21a7  jmp 0x00007583D7BD1F9B
00007583d7bd21ac  sub rsp, 0x08
00007583d7bd21b0  push rax
00007583d7bd21b1  push rcx
00007583d7bd21b2  push rdx
00007583d7bd21b3  push rdi
00007583d7bd21b4  push rsi
00007583d7bd21b5  push r8
00007583d7bd21b7  push r9
00007583d7bd21b9  push r10
00007583d7bd21bb  push r11
00007583d7bd21bd  sub rsp, 0xF0
00007583d7bd21c4  vmovaps [rsp], xmm0
00007583d7bd21c9  vmovaps [rsp+0x10], xmm1
00007583d7bd21cf  vmovaps [rsp+0x20], xmm2
00007583d7bd21d5  vmovaps [rsp+0x30], xmm3
00007583d7bd21db  vmovaps [rsp+0x40], xmm4
00007583d7bd21e1  vmovaps [rsp+0x50], xmm5
00007583d7bd21e7  vmovaps [rsp+0x60], xmm6
00007583d7bd21ed  vmovaps [rsp+0x70], xmm7
00007583d7bd21f3  vmovaps [rsp+0x80], xmm8
00007583d7bd21fc  vmovaps [rsp+0x90], xmm9
00007583d7bd2205  vmovaps [rsp+0xA0], xmm10
00007583d7bd220e  vmovaps [rsp+0xB0], xmm11
00007583d7bd2217  vmovaps [rsp+0xC0], xmm12
00007583d7bd2220  vmovaps [rsp+0xD0], xmm13
00007583d7bd2229  vmovaps [rsp+0xE0], xmm15
00007583d7bd2232  sub rsp, 0x30
00007583d7bd2236  movaps [rsp], xmm14
00007583d7bd223b  movaps [rsp+0x10], xmm1
00007583d7bd2240  movaps [rsp+0x20], xmm15
00007583d7bd2246  lea rdi, [rsp]
00007583d7bd224a  mov esi, 0x00
00007583d7bd224f  mov rax, 0x5BCB7EA35530
00007583d7bd2259  call rax
00007583d7bd225b  movaps xmm14, [rsp]
00007583d7bd2260  add rsp, 0x30
00007583d7bd2264  vmovaps xmm0, [rsp]
00007583d7bd2269  vmovaps xmm1, [rsp+0x10]
00007583d7bd226f  vmovaps xmm2, [rsp+0x20]
00007583d7bd2275  vmovaps xmm3, [rsp+0x30]
00007583d7bd227b  vmovaps xmm4, [rsp+0x40]
00007583d7bd2281  vmovaps xmm5, [rsp+0x50]
00007583d7bd2287  vmovaps xmm6, [rsp+0x60]
00007583d7bd228d  vmovaps xmm7, [rsp+0x70]
00007583d7bd2293  vmovaps xmm8, [rsp+0x80]
00007583d7bd229c  vmovaps xmm9, [rsp+0x90]
00007583d7bd22a5  vmovaps xmm10, [rsp+0xA0]
00007583d7bd22ae  vmovaps xmm11, [rsp+0xB0]
00007583d7bd22b7  vmovaps xmm12, [rsp+0xC0]
00007583d7bd22c0  vmovaps xmm13, [rsp+0xD0]
00007583d7bd22c9  vmovaps xmm15, [rsp+0xE0]
00007583d7bd22d2  add rsp, 0xF0
00007583d7bd22d9  pop r11
00007583d7bd22db  pop r10
00007583d7bd22dd  pop r9
00007583d7bd22df  pop r8
00007583d7bd22e1  pop rsi
00007583d7bd22e2  pop rdi
00007583d7bd22e3  pop rdx
00007583d7bd22e4  pop rcx
00007583d7bd22e5  pop rax
00007583d7bd22e6  add rsp, 0x08
00007583d7bd22ea  jmp 0x00007583D7BD1FBE
00007583d7bd22ef  call 0x00007583D7AC34C0
00007583d7bd22f4  jmp 0x00007583D7BD1FD4
00007583d7bd22f9  int3
00007583d7bd22fa  nop [rax+rax*1], ax
00007583d7bd2300  mov rax, [r15+0x50]
00007583d7bd2304  movups xmm1, [r13+rax*1]
00007583d7bd230a  lea r14, [rax+0x10]
00007583d7bd230e  movups xmm15, [r13+r14*1]
00007583d7bd2314  mov qword ptr [r15+0x48], 0x00
00007583d7bd231c  lea r14, [rax+0x40]
00007583d7bd2320  movups xmm14, [r13+r14*1]
00007583d7bd2326  lea r14, [rax+0x50]
00007583d7bd232a  movups xmm13, [r13+r14*1]
00007583d7bd2330  lea r14, [rax+0x80]
00007583d7bd2337  movups xmm12, [r13+r14*1]
00007583d7bd233d  lea r14, [rax+0x90]
00007583d7bd2344  movups xmm11, [r13+r14*1]
00007583d7bd234a  mov r14, [r15+0xF8]
00007583d7bd2351  movups [r13+r14*1], xmm1
00007583d7bd2357  lea r12, [rax+0x20]
00007583d7bd235b  movups xmm1, [r13+r12*1]
00007583d7bd2361  lea r12, [rax+0x30]
00007583d7bd2365  movups xmm10, [r13+r12*1]
00007583d7bd236b  lea r12, [rax+0xC0]
00007583d7bd2372  movups xmm9, [r13+r12*1]
00007583d7bd2378  lea r12, [rax+0xD0]
00007583d7bd237f  movups xmm8, [r13+r12*1]
00007583d7bd2385  lea r12, [rax+0x100]
00007583d7bd238c  movups xmm7, [r13+r12*1]
00007583d7bd2392  lea r12, [rax+0x110]
00007583d7bd2399  movups xmm6, [r13+r12*1]
00007583d7bd239f  lea r12, [rax+0x140]
00007583d7bd23a6  movups xmm5, [r13+r12*1]
00007583d7bd23ac  lea r12, [rax+0x150]
00007583d7bd23b3  movups xmm4, [r13+r12*1]
00007583d7bd23b9  lea r12, [r14+0xB0]
00007583d7bd23c0  movups [r13+r12*1], xmm10
00007583d7bd23c6  lea r12, [r14+0xC0]
00007583d7bd23cd  movups [r13+r12*1], xmm1
00007583d7bd23d3  lea r12, [rax+0x180]
00007583d7bd23da  movups xmm1, [r13+r12*1]
00007583d7bd23e0  lea r12, [rax+0x190]
00007583d7bd23e7  movups xmm10, [r13+r12*1]
00007583d7bd23ed  lea r12, [rax+0x1C0]
00007583d7bd23f4  movups xmm3, [r13+r12*1]
00007583d7bd23fa  lea r12, [rax+0x1D0]
00007583d7bd2401  movups xmm2, [r13+r12*1]
00007583d7bd2407  lea r12, [rax+0x60]
00007583d7bd240b  vmovaps [rsp+0x10], xmm1
00007583d7bd2411  movups xmm1, [r13+r12*1]
00007583d7bd2417  lea r12, [rax+0x70]
00007583d7bd241b  vmovaps [rsp+0x20], xmm1
00007583d7bd2421  movups xmm1, [r13+r12*1]
00007583d7bd2427  lea r12, [r14+0x70]
00007583d7bd242b  movups [r13+r12*1], xmm10
00007583d7bd2431  lea r12, [r14+0x80]
00007583d7bd2438  vmovaps xmm10, [rsp+0x10]
00007583d7bd243e  movups [r13+r12*1], xmm10
00007583d7bd2444  lea r12, [rax+0xA0]
00007583d7bd244b  movups xmm10, [r13+r12*1]
00007583d7bd2451  lea r12, [rax+0xB0]
00007583d7bd2458  vmovaps [rsp+0x10], xmm1
00007583d7bd245e  movups xmm1, [r13+r12*1]
00007583d7bd2464  lea r12, [r14+0x90]
00007583d7bd246b  movups [r13+r12*1], xmm2
00007583d7bd2471  lea r12, [r14+0xA0]
00007583d7bd2478  movups [r13+r12*1], xmm3
00007583d7bd247e  lea r12, [rax+0xE0]
00007583d7bd2485  movups xmm3, [r13+r12*1]
00007583d7bd248b  lea r12, [rax+0xF0]
00007583d7bd2492  movups xmm2, [r13+r12*1]
00007583d7bd2498  lea r12, [rax+0x120]
00007583d7bd249f  vmovaps [rsp+0x30], xmm1
00007583d7bd24a5  movups xmm1, [r13+r12*1]
00007583d7bd24ab  lea r12, [rax+0x130]
00007583d7bd24b2  vmovaps [rsp+0x40], xmm1
00007583d7bd24b8  movups xmm1, [r13+r12*1]
00007583d7bd24be  vmovaps [rsp+0x50], xmm1
00007583d7bd24c4  vmovaps xmm1, [rsp+0x40]
00007583d7bd24ca  movaps [r15+0x190], xmm1
00007583d7bd24d2  lea r12, [rax+0x160]
00007583d7bd24d9  vmovaps [rsp+0x40], xmm1
00007583d7bd24df  movups xmm1, [r13+r12*1]
00007583d7bd24e5  lea r12, [rax+0x170]
00007583d7bd24ec  vmovaps [rsp+0x60], xmm1
00007583d7bd24f2  movups xmm1, [r13+r12*1]
00007583d7bd24f8  lea r12, [rax+0x1A0]
00007583d7bd24ff  vmovaps [rsp+0x70], xmm1
00007583d7bd2505  movups xmm1, [r13+r12*1]
00007583d7bd250b  lea r12, [rax+0x1B0]
00007583d7bd2512  vmovaps [rsp+0x80], xmm1
00007583d7bd251b  movups xmm1, [r13+r12*1]
00007583d7bd2521  lea r12, [rax+0x1E0]
00007583d7bd2528  vmovaps [rsp+0x90], xmm1
00007583d7bd2531  movups xmm1, [r13+r12*1]
00007583d7bd2537  lea r12, [rax+0x1F0]
00007583d7bd253e  vmovaps [rsp+0xA0], xmm1
00007583d7bd2547  movups xmm1, [r13+r12*1]
00007583d7bd254d  mov qword ptr [r15+0x50], 0x432190
00007583d7bd2555  lea rax, [r14+0x50]
00007583d7bd2559  vmovaps [rsp+0xB0], xmm1
00007583d7bd2562  vmovaps xmm1, [rsp+0x60]
00007583d7bd2568  movups [r13+rax*1], xmm1
00007583d7bd256e  lea rax, [r14+0x60]
00007583d7bd2572  movups [r13+rax*1], xmm5
00007583d7bd2578  lea rax, [r14+0x40]
00007583d7bd257c  vmovaps xmm1, [rsp+0x70]
00007583d7bd2582  movups [r13+rax*1], xmm1
00007583d7bd2588  lea rax, [r14+0x20]
00007583d7bd258c  vmovaps xmm1, [rsp+0xA0]
00007583d7bd2595  movups [r13+rax*1], xmm1
00007583d7bd259b  lea rax, [r14+0x30]
00007583d7bd259f  vmovaps xmm1, [rsp+0x90]
00007583d7bd25a8  movups [r13+rax*1], xmm1
00007583d7bd25ae  lea rax, [r14+0x10]
00007583d7bd25b2  vmovaps xmm1, [rsp+0xB0]
00007583d7bd25bb  movups [r13+rax*1], xmm1
00007583d7bd25c1  mov rax, [r15+0x40]
00007583d7bd25c5  vxorps xmm1, xmm1, xmm1
00007583d7bd25c9  vpbroadcastq xmm1, xmm1
00007583d7bd25ce  vxorps xmm5, xmm5, xmm5
00007583d7bd25d2  vpbroadcastq xmm5, xmm5
00007583d7bd25d7  lea r12, [rax+0x30]
00007583d7bd25db  mov r11, [r13+r12*1]
00007583d7bd25e0  lea r12, [rax+0x38]
00007583d7bd25e4  mov r10, [r13+r12*1]
00007583d7bd25e9  vmovaps [rsp+0x60], xmm1
00007583d7bd25ef  movq xmm1, r11
00007583d7bd25f4  vmovaps [rsp+0x70], xmm1
00007583d7bd25fa  movq xmm1, r10
00007583d7bd25ff  vmovaps [rsp+0x90], xmm1
00007583d7bd2608  vmovaps xmm1, [rsp+0x70]
00007583d7bd260e  movq xmm1, xmm1
00007583d7bd2612  vmovaps [rsp+0x70], xmm1
00007583d7bd2618  vmovaps xmm1, [rsp+0x90]
00007583d7bd2621  movq xmm1, xmm1
00007583d7bd2625  vmovaps [rsp+0x90], xmm1
00007583d7bd262e  movq xmm1, xmm1
00007583d7bd2632  movaps [r15+0x270], xmm1
00007583d7bd263a  vmovaps [rsp+0xA0], xmm7
00007583d7bd2643  vmovaps xmm1, [rsp+0xA0]
00007583d7bd264c  por xmm7, xmm1
00007583d7bd2650  lea r12, [rax+0x20]
00007583d7bd2654  mov r11, [r13+r12*1]
00007583d7bd2659  lea r12, [rax+0x28]
00007583d7bd265d  mov r10, [r13+r12*1]
00007583d7bd2662  movq xmm1, r11
00007583d7bd2667  vmovaps [rsp+0xA0], xmm1
00007583d7bd2670  movq xmm1, r10
00007583d7bd2675  vmovaps [rsp+0xB0], xmm1
00007583d7bd267e  vmovaps xmm1, [rsp+0xA0]
00007583d7bd2687  movq xmm1, xmm1
00007583d7bd268b  vmovaps [rsp+0xA0], xmm1
00007583d7bd2694  vmovaps xmm1, [rsp+0xB0]
00007583d7bd269d  movq xmm1, xmm1
00007583d7bd26a1  vmovaps [rsp+0xB0], xmm2
00007583d7bd26aa  vmovaps [rsp+0xC0], xmm1
00007583d7bd26b3  vmovaps xmm1, [rsp+0xB0]
00007583d7bd26bc  por xmm2, xmm1
00007583d7bd26c0  vmovaps [rsp+0xB0], xmm3
00007583d7bd26c9  vmovaps xmm1, [rsp+0xB0]
00007583d7bd26d2  por xmm3, xmm1
00007583d7bd26d6  vmovaps [rsp+0xB0], xmm4
00007583d7bd26df  vmovaps xmm1, [rsp+0xB0]
00007583d7bd26e8  por xmm4, xmm1
00007583d7bd26ec  vmovaps [rsp+0xB0], xmm9
00007583d7bd26f5  vmovaps xmm1, [rsp+0xB0]
00007583d7bd26fe  por xmm9, xmm1
00007583d7bd2703  lea r12, [rax+0x10]
00007583d7bd2707  mov r11, [r13+r12*1]
00007583d7bd270c  lea r12, [rax+0x18]
00007583d7bd2710  mov r10, [r13+r12*1]
00007583d7bd2715  movq xmm1, r11
00007583d7bd271a  vmovaps [rsp+0xB0], xmm1
00007583d7bd2723  movq xmm1, r10
00007583d7bd2728  vmovaps [rsp+0xD0], xmm1
00007583d7bd2731  vmovaps xmm1, [rsp+0xB0]
00007583d7bd273a  movq xmm1, xmm1
00007583d7bd273e  vmovaps [rsp+0xB0], xmm1
00007583d7bd2747  vmovaps xmm1, [rsp+0xD0]
00007583d7bd2750  movq xmm1, xmm1
00007583d7bd2754  vmovaps [rsp+0xD0], xmm1
00007583d7bd275d  vmovaps xmm1, [rsp+0x80]
00007583d7bd2766  vmovaps [rsp+0xE0], xmm15
00007583d7bd276f  vmovaps xmm15, [rsp+0x80]
00007583d7bd2778  por xmm1, xmm15
00007583d7bd277d  vmovaps xmm15, [rsp+0x10]
00007583d7bd2783  vmovaps [rsp+0x80], xmm1
00007583d7bd278c  vmovaps xmm1, [rsp+0x10]
00007583d7bd2792  por xmm15, xmm1
00007583d7bd2797  vmovaps xmm1, [rsp+0x20]
00007583d7bd279d  vmovaps [rsp+0x10], xmm15
00007583d7bd27a3  vmovaps xmm15, [rsp+0x20]
00007583d7bd27a9  por xmm1, xmm15
00007583d7bd27ae  vmovaps [rsp+0x20], xmm6
00007583d7bd27b4  vmovaps xmm15, [rsp+0x20]
00007583d7bd27ba  por xmm6, xmm15
00007583d7bd27bf  vmovaps [rsp+0x20], xmm11
00007583d7bd27c5  vmovaps xmm15, [rsp+0x20]
00007583d7bd27cb  por xmm11, xmm15
00007583d7bd27d0  vmovaps [rsp+0x20], xmm13
00007583d7bd27d6  vmovaps xmm15, [rsp+0x20]
00007583d7bd27dc  por xmm13, xmm15
00007583d7bd27e1  vmovaps [rsp+0x20], xmm14
00007583d7bd27e7  vmovaps xmm15, [rsp+0x20]
00007583d7bd27ed  por xmm14, xmm15
00007583d7bd27f2  mov r12, [r13+rax*1]
00007583d7bd27f7  vmovq xmm15, r12
00007583d7bd27fc  vpbroadcastq xmm15, xmm15
00007583d7bd2801  vmovaps [rsp+0x20], xmm1
00007583d7bd2807  vxorps xmm1, xmm1, xmm1
00007583d7bd280b  vpbroadcastq xmm1, xmm1
00007583d7bd2810  vmovaps [rsp+0xF0], xmm1
00007583d7bd2819  movups xmm1, [r13+r14*1]
00007583d7bd281f  vmovaps [rsp+0x100], xmm1
00007583d7bd2828  vxorps xmm1, xmm1, xmm1
00007583d7bd282c  vpbroadcastq xmm1, xmm1
00007583d7bd2831  lea r12, [rax+0x08]
00007583d7bd2835  mov rax, [r13+r12*1]
00007583d7bd283a  vmovaps [rsp+0x110], xmm1
00007583d7bd2843  movq xmm1, rax
00007583d7bd2848  movaps [r15+0x240], xmm1
00007583d7bd2850  mov qword ptr [r15+0x60], 0x432190
00007583d7bd2858  mov qword ptr [r15+0x58], 0x40
00007583d7bd2860  vmovaps xmm1, [rsp+0x60]
00007583d7bd2866  vmovaps [rsp+0x60], xmm15
00007583d7bd286c  vmovaps xmm15, [rsp+0x100]
00007583d7bd2875  vmovaps [rsp+0x100], xmm14
00007583d7bd287e  vmovaps xmm14, [rsp+0x60]
00007583d7bd2884  vmovaps [rsp+0x60], xmm13
00007583d7bd288a  vmovaps [rsp+0x120], xmm12
00007583d7bd2893  movaps xmm13, xmm1
00007583d7bd2897  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd28a2  vptest xmm12, xmm12
00007583d7bd28a7  jnz 0x00007583D7BD3482
00007583d7bd28ad  vmovaps xmm1, [rsp+0xE0]
00007583d7bd28b6  movaps xmm15, xmm5
00007583d7bd28ba  vfmadd231pd xmm15, xmm1, xmm14
00007583d7bd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007583d7bd28c5  vptest xmm12, xmm12
00007583d7bd28ca  jnz 0x00007583D7BD35DB
00007583d7bd28d0  vmovaps xmm12, [rsp+0x50]
00007583d7bd28d6  vmovaps xmm5, [rsp+0x50]
00007583d7bd28dc  por xmm12, xmm5
00007583d7bd28e1  vmovaps xmm5, [rsp+0x30]
00007583d7bd28e7  vmovaps [rsp+0x50], xmm1
00007583d7bd28ed  vmovaps xmm1, [rsp+0x30]
00007583d7bd28f3  por xmm5, xmm1
00007583d7bd28f7  vmovaps [rsp+0x30], xmm10
00007583d7bd28fd  vmovaps xmm1, [rsp+0x30]
00007583d7bd2903  por xmm10, xmm1
00007583d7bd2908  vmovaps [rsp+0x30], xmm8
00007583d7bd290e  vmovaps xmm1, [rsp+0x30]
00007583d7bd2914  por xmm8, xmm1
00007583d7bd2919  vmovaps xmm1, [rsp+0x120]
00007583d7bd2922  vmovaps [rsp+0x30], xmm15
00007583d7bd2928  vmovaps xmm15, [rsp+0x120]
00007583d7bd2931  por xmm1, xmm15
00007583d7bd2936  vmovaps xmm15, [rsp+0x50]
00007583d7bd293c  vmovaps [rsp+0xE0], xmm1
00007583d7bd2945  vmovaps xmm1, [rsp+0x50]
00007583d7bd294b  por xmm15, xmm1
00007583d7bd2950  lea rax, [r14+0xC0]
00007583d7bd2957  movups xmm1, [r13+rax*1]
00007583d7bd295d  xor eax, eax
00007583d7bd295f  mov r12d, 0x40
00007583d7bd2965  mov r11d, 0x200
00007583d7bd296b  cmp r12, r11
00007583d7bd296e  cmc
00007583d7bd296f  lahf
00007583d7bd2970  seto al
00007583d7bd2973  mov [r15+0x108], eax
00007583d7bd297a  vmovaps [rsp+0x50], xmm1
00007583d7bd2980  vmovaps xmm1, [rsp+0xF0]
00007583d7bd2989  vmovaps [rsp+0xF0], xmm15
00007583d7bd2992  vmovaps xmm15, [rsp+0x50]
00007583d7bd2998  vmovaps [rsp+0x50], xmm13
00007583d7bd299e  vmovaps [rsp+0x120], xmm12
00007583d7bd29a7  movaps xmm13, xmm1
00007583d7bd29ab  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd29b6  vptest xmm12, xmm12
00007583d7bd29bb  jnz 0x00007583D7BD373D
00007583d7bd29c1  lea rax, [r14+0xB0]
00007583d7bd29c8  movups xmm1, [r13+rax*1]
00007583d7bd29ce  vmovaps xmm15, [rsp+0x110]
00007583d7bd29d7  vmovaps [rsp+0x110], xmm13
00007583d7bd29e0  movaps xmm12, xmm15
00007583d7bd29e4  vfmadd231pd xmm12, xmm1, xmm14
00007583d7bd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007583d7bd29ef  vptest xmm13, xmm13
00007583d7bd29f4  jnz 0x00007583D7BD38A0
00007583d7bd29fa  vmovaps xmm1, [rsp+0x100]
00007583d7bd2a03  vmovaps xmm15, [rsp+0x100]
00007583d7bd2a0c  por xmm1, xmm15
00007583d7bd2a11  movaps [r15+0x210], xmm1
00007583d7bd2a19  vmovaps xmm15, [rsp+0x60]
00007583d7bd2a1f  vmovaps xmm14, [rsp+0x60]
00007583d7bd2a25  por xmm15, xmm14
00007583d7bd2a2a  movaps [r15+0x1C0], xmm15
00007583d7bd2a32  vmovaps [rsp+0x60], xmm11
00007583d7bd2a38  vmovaps xmm14, [rsp+0x60]
00007583d7bd2a3e  por xmm11, xmm14
00007583d7bd2a43  movaps [r15+0x280], xmm11
00007583d7bd2a4b  vmovaps [rsp+0x60], xmm6
00007583d7bd2a51  vmovaps xmm14, [rsp+0x60]
00007583d7bd2a57  por xmm6, xmm14
00007583d7bd2a5c  movaps [r15+0x2A0], xmm6
00007583d7bd2a64  vmovaps xmm14, [rsp+0x20]
00007583d7bd2a6a  vmovaps xmm13, [rsp+0x20]
00007583d7bd2a70  por xmm14, xmm13
00007583d7bd2a75  movaps [r15+0x2E0], xmm14
00007583d7bd2a7d  vmovaps xmm13, [rsp+0x10]
00007583d7bd2a83  vmovaps [rsp+0x20], xmm1
00007583d7bd2a89  vmovaps xmm1, [rsp+0x10]
00007583d7bd2a8f  por xmm13, xmm1
00007583d7bd2a94  movaps [r15+0x1F0], xmm13
00007583d7bd2a9c  vmovaps xmm1, [rsp+0xF0]
00007583d7bd2aa5  vmovaps [rsp+0x10], xmm15
00007583d7bd2aab  vmovaps xmm15, [rsp+0xF0]
00007583d7bd2ab4  por xmm1, xmm15
00007583d7bd2ab9  movaps [r15+0x250], xmm1
00007583d7bd2ac1  vmovaps xmm1, [rsp+0xE0]
00007583d7bd2aca  vmovaps xmm15, [rsp+0xE0]
00007583d7bd2ad3  por xmm1, xmm15
00007583d7bd2ad8  movaps [r15+0x260], xmm1
00007583d7bd2ae0  vmovaps [rsp+0x60], xmm8
00007583d7bd2ae6  vmovaps xmm15, [rsp+0x60]
00007583d7bd2aec  por xmm8, xmm15
00007583d7bd2af1  movaps [r15+0x290], xmm8
00007583d7bd2af9  vmovaps [rsp+0x60], xmm10
00007583d7bd2aff  vmovaps xmm15, [rsp+0x60]
00007583d7bd2b05  por xmm10, xmm15
00007583d7bd2b0a  movaps [r15+0x2C0], xmm10
00007583d7bd2b12  movq xmm15, qword ptr [r15+0x240]
00007583d7bd2b1b  vmovaps [rsp+0x60], xmm15
00007583d7bd2b21  vpermilpd xmm15, xmm15, 0x00
00007583d7bd2b27  vmovaps [rsp+0xE0], xmm1
00007583d7bd2b30  vmovaps xmm1, [rsp+0x50]
00007583d7bd2b36  vmovaps [rsp+0x50], xmm15
00007583d7bd2b3c  vmovaps xmm15, [rsp+0x20]
00007583d7bd2b42  vmovaps [rsp+0x20], xmm14
00007583d7bd2b48  vmovaps xmm14, [rsp+0x50]
00007583d7bd2b4e  vmovaps [rsp+0x50], xmm13
00007583d7bd2b54  vmovaps [rsp+0xF0], xmm12
00007583d7bd2b5d  movaps xmm13, xmm1
00007583d7bd2b61  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd2b6c  vptest xmm12, xmm12
00007583d7bd2b71  jnz 0x00007583D7BD39F9
00007583d7bd2b77  vmovaps xmm1, [rsp+0x60]
00007583d7bd2b7d  vpermilpd xmm1, xmm1, 0x00
00007583d7bd2b83  vmovaps xmm15, [rsp+0x110]
00007583d7bd2b8c  vmovaps xmm14, [rsp+0x20]
00007583d7bd2b92  vmovaps [rsp+0x20], xmm13
00007583d7bd2b98  movaps xmm12, xmm15
00007583d7bd2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007583d7bd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007583d7bd2ba7  vptest xmm13, xmm13
00007583d7bd2bac  jnz 0x00007583D7BD3B52
00007583d7bd2bb2  vmovaps xmm1, [rsp+0x60]
00007583d7bd2bb8  vpermilpd xmm1, xmm1, 0x00
00007583d7bd2bbe  vmovaps xmm15, [rsp+0x30]
00007583d7bd2bc4  vmovaps xmm14, [rsp+0x10]
00007583d7bd2bca  vmovaps [rsp+0x10], xmm12
00007583d7bd2bd0  movaps xmm13, xmm15
00007583d7bd2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007583d7bd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd2bdf  vptest xmm12, xmm12
00007583d7bd2be4  jnz 0x00007583D7BD3CAB
00007583d7bd2bea  vmovaps [rsp+0x30], xmm5
00007583d7bd2bf0  vmovaps xmm1, [rsp+0x30]
00007583d7bd2bf6  por xmm5, xmm1
00007583d7bd2bfa  movaps [r15+0x1D0], xmm5
00007583d7bd2c02  vmovaps xmm1, [rsp+0x60]
00007583d7bd2c08  vpermilpd xmm1, xmm1, 0x00
00007583d7bd2c0e  vmovaps xmm15, [rsp+0xF0]
00007583d7bd2c17  vmovaps xmm14, [rsp+0x50]
00007583d7bd2c1d  vmovaps [rsp+0x30], xmm13
00007583d7bd2c23  movaps xmm12, xmm15
00007583d7bd2c27  vfmadd231pd xmm12, xmm14, xmm1
00007583d7bd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007583d7bd2c32  vptest xmm13, xmm13
00007583d7bd2c37  jnz 0x00007583D7BD3E04
00007583d7bd2c3d  vmovaps xmm1, [rsp+0x80]
00007583d7bd2c46  vmovaps xmm15, [rsp+0x80]
00007583d7bd2c4f  por xmm1, xmm15
00007583d7bd2c54  movaps [r15+0x200], xmm1
00007583d7bd2c5c  vmovaps xmm15, [rsp+0x120]
00007583d7bd2c65  vmovaps xmm14, [rsp+0x120]
00007583d7bd2c6e  por xmm15, xmm14
00007583d7bd2c73  movaps [r15+0x1E0], xmm15
00007583d7bd2c7b  vmovaps [rsp+0x50], xmm4
00007583d7bd2c81  vmovaps xmm13, [rsp+0x50]
00007583d7bd2c87  por xmm4, xmm13
00007583d7bd2c8c  movaps [r15+0x2B0], xmm4
00007583d7bd2c94  vmovaps [rsp+0x50], xmm3
00007583d7bd2c9a  vmovaps xmm13, [rsp+0x50]
00007583d7bd2ca0  por xmm3, xmm13
00007583d7bd2ca5  movaps [r15+0x300], xmm3
00007583d7bd2cad  vmovaps xmm15, [rsp+0xB0]
00007583d7bd2cb6  vpermilpd xmm15, xmm15, 0x00
00007583d7bd2cbc  vmovaps xmm3, [rsp+0x20]
00007583d7bd2cc2  vmovaps [rsp+0x20], xmm1
00007583d7bd2cc8  vmovaps xmm1, [rsp+0xE0]
00007583d7bd2cd1  vmovaps [rsp+0x50], xmm14
00007583d7bd2cd7  vmovaps [rsp+0x60], xmm13
00007583d7bd2cdd  movaps xmm14, xmm3
00007583d7bd2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007583d7bd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007583d7bd2cec  vptest xmm13, xmm13
00007583d7bd2cf1  jnz 0x00007583D7BD3F5D
00007583d7bd2cf7  vmovaps xmm1, [rsp+0xB0]
00007583d7bd2d00  vpermilpd xmm1, xmm1, 0x00
00007583d7bd2d06  vmovaps xmm15, [rsp+0x10]
00007583d7bd2d0c  movaps xmm13, xmm15
00007583d7bd2d10  vfmadd231pd xmm13, xmm10, xmm1
00007583d7bd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007583d7bd2d1b  vptest xmm3, xmm3
00007583d7bd2d20  jnz 0x00007583D7BD40B5
00007583d7bd2d26  vmovaps xmm1, [rsp+0xB0]
00007583d7bd2d2f  vpermilpd xmm1, xmm1, 0x00
00007583d7bd2d35  vmovaps xmm15, [rsp+0x30]
00007583d7bd2d3b  movaps xmm10, xmm15
00007583d7bd2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007583d7bd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007583d7bd2d4a  vptest xmm3, xmm3
00007583d7bd2d4f  jnz 0x00007583D7BD420E
00007583d7bd2d55  vmovaps xmm1, [rsp+0xB0]
00007583d7bd2d5e  vpermilpd xmm1, xmm1, 0x00
00007583d7bd2d64  movaps xmm15, xmm12
00007583d7bd2d68  vfmadd231pd xmm15, xmm5, xmm1
00007583d7bd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007583d7bd2d73  vptest xmm11, xmm11
00007583d7bd2d78  jnz 0x00007583D7BD4367
00007583d7bd2d7e  vmovaps [rsp+0x10], xmm9
00007583d7bd2d84  vmovaps xmm1, [rsp+0x10]
00007583d7bd2d8a  por xmm9, xmm1
00007583d7bd2d8f  movaps [r15+0x180], xmm9
00007583d7bd2d97  vmovaps [rsp+0x10], xmm2
00007583d7bd2d9d  vmovaps xmm1, [rsp+0x10]
00007583d7bd2da3  por xmm2, xmm1
00007583d7bd2da7  movaps [r15+0x2D0], xmm2
00007583d7bd2daf  vmovaps xmm12, [rsp+0xD0]
00007583d7bd2db8  vpermilpd xmm12, xmm12, 0x00
00007583d7bd2dbe  vmovaps xmm11, [rsp+0x60]
00007583d7bd2dc4  movaps xmm5, xmm13
00007583d7bd2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007583d7bd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007583d7bd2dd2  vptest xmm3, xmm3
00007583d7bd2dd7  jnz 0x00007583D7BD44BF
00007583d7bd2ddd  vmovaps xmm13, [rsp+0xD0]
00007583d7bd2de6  vpermilpd xmm13, xmm13, 0x00
00007583d7bd2dec  movaps xmm12, xmm14
00007583d7bd2df0  vfmadd231pd xmm12, xmm9, xmm13
00007583d7bd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007583d7bd2dfb  vptest xmm11, xmm11
00007583d7bd2e00  jnz 0x00007583D7BD4617
00007583d7bd2e06  lea rax, [r14+0x80]
00007583d7bd2e0d  movups xmm14, [r13+rax*1]
00007583d7bd2e13  movaps [r15+0x2F0], xmm14
00007583d7bd2e1b  vmovaps xmm13, [rsp+0xD0]
00007583d7bd2e24  vpermilpd xmm13, xmm13, 0x00
00007583d7bd2e2a  movaps xmm11, xmm10
00007583d7bd2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007583d7bd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007583d7bd2e39  vptest xmm9, xmm9
00007583d7bd2e3e  jnz 0x00007583D7BD477B
00007583d7bd2e44  vmovaps xmm13, [rsp+0xD0]
00007583d7bd2e4d  vpermilpd xmm13, xmm13, 0x00
00007583d7bd2e53  movaps xmm10, xmm15
00007583d7bd2e57  vfmadd231pd xmm10, xmm1, xmm13
00007583d7bd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007583d7bd2e62  vptest xmm9, xmm9
00007583d7bd2e67  jnz 0x00007583D7BD48D5
00007583d7bd2e6d  vmovaps [rsp+0x10], xmm7
00007583d7bd2e73  vmovaps xmm1, [rsp+0x10]
00007583d7bd2e79  por xmm7, xmm1
00007583d7bd2e7d  movaps [r15+0x160], xmm7
00007583d7bd2e85  lea rax, [r14+0x40]
00007583d7bd2e89  movups xmm1, [r13+rax*1]
00007583d7bd2e8f  lea rax, [r14+0x50]
00007583d7bd2e93  movups xmm15, [r13+rax*1]
00007583d7bd2e99  movaps [r15+0x1B0], xmm1
00007583d7bd2ea1  movaps [r15+0x1A0], xmm15
00007583d7bd2ea9  vmovaps xmm13, [rsp+0xA0]
00007583d7bd2eb2  vpermilpd xmm13, xmm13, 0x00
00007583d7bd2eb8  vmovaps xmm9, [rsp+0x40]
00007583d7bd2ebe  movaps xmm8, xmm5
00007583d7bd2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007583d7bd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007583d7bd2ecd  vptest xmm3, xmm3
00007583d7bd2ed2  jnz 0x00007583D7BD4A42
00007583d7bd2ed8  vmovaps xmm13, [rsp+0xA0]
00007583d7bd2ee1  vpermilpd xmm13, xmm13, 0x00
00007583d7bd2ee7  movaps xmm9, xmm12
00007583d7bd2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007583d7bd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007583d7bd2ef6  vptest xmm5, xmm5
00007583d7bd2efb  jnz 0x00007583D7BD4B9B
00007583d7bd2f01  vmovaps xmm13, [rsp+0xA0]
00007583d7bd2f0a  vpermilpd xmm13, xmm13, 0x00
00007583d7bd2f10  movaps xmm12, xmm11
00007583d7bd2f14  vfmadd231pd xmm12, xmm6, xmm13
00007583d7bd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007583d7bd2f1f  vptest xmm7, xmm7
00007583d7bd2f24  jnz 0x00007583D7BD4CF4
00007583d7bd2f2a  vmovaps xmm13, [rsp+0xA0]
00007583d7bd2f33  vpermilpd xmm13, xmm13, 0x00
00007583d7bd2f39  vmovaps xmm11, [rsp+0x50]
00007583d7bd2f3f  movaps xmm7, xmm10
00007583d7bd2f43  vfmadd231pd xmm7, xmm11, xmm13
00007583d7bd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007583d7bd2f4d  vptest xmm6, xmm6
00007583d7bd2f52  jnz 0x00007583D7BD4E4D
00007583d7bd2f58  lea rax, [r14+0x60]
00007583d7bd2f5c  movups xmm13, [r13+rax*1]
00007583d7bd2f62  lea rax, [r14+0x70]
00007583d7bd2f66  movups xmm11, [r13+rax*1]
00007583d7bd2f6c  movaps [r15+0x150], xmm13
00007583d7bd2f74  movaps [r15+0x120], xmm11
00007583d7bd2f7c  vmovaps xmm10, [rsp+0xC0]
00007583d7bd2f85  vpermilpd xmm10, xmm10, 0x00
00007583d7bd2f8b  movaps xmm6, xmm8
00007583d7bd2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007583d7bd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007583d7bd2f99  vptest xmm5, xmm5
00007583d7bd2f9e  jnz 0x00007583D7BD4FB9
00007583d7bd2fa4  vmovaps xmm15, [rsp+0xC0]
00007583d7bd2fad  vpermilpd xmm15, xmm15, 0x00
00007583d7bd2fb3  movaps xmm10, xmm9
00007583d7bd2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007583d7bd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007583d7bd2fc2  vptest xmm8, xmm8
00007583d7bd2fc7  jnz 0x00007583D7BD5111
00007583d7bd2fcd  vmovaps xmm15, [rsp+0xC0]
00007583d7bd2fd6  vpermilpd xmm15, xmm15, 0x00
00007583d7bd2fdc  movaps xmm13, xmm12
00007583d7bd2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007583d7bd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007583d7bd2feb  vptest xmm9, xmm9
00007583d7bd2ff0  jnz 0x00007583D7BD526B
00007583d7bd2ff6  vmovaps xmm15, [rsp+0xC0]
00007583d7bd2fff  vpermilpd xmm15, xmm15, 0x00
00007583d7bd3005  movaps xmm12, xmm7
00007583d7bd3009  vfmadd231pd xmm12, xmm1, xmm15
00007583d7bd300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007583d7bd3014  vptest xmm9, xmm9
00007583d7bd3019  jnz 0x00007583D7BD53C4
00007583d7bd301f  lea rax, [r14+0x20]
00007583d7bd3023  movups xmm1, [r13+rax*1]
00007583d7bd3029  lea rax, [r14+0x30]
00007583d7bd302d  movups xmm15, [r13+rax*1]
00007583d7bd3033  vmovaps xmm9, [rsp+0x70]
00007583d7bd3039  vpermilpd xmm9, xmm9, 0x00
00007583d7bd303f  vmovaps xmm8, [rsp+0x20]
00007583d7bd3045  movaps xmm7, xmm6
00007583d7bd3048  vfmadd231pd xmm7, xmm8, xmm9
00007583d7bd304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007583d7bd3052  vptest xmm5, xmm5
00007583d7bd3057  jnz 0x00007583D7BD5530
00007583d7bd305d  vmovaps xmm9, [rsp+0x70]
00007583d7bd3063  vpermilpd xmm9, xmm9, 0x00
00007583d7bd3069  movaps xmm8, xmm10
00007583d7bd306d  vfmadd231pd xmm8, xmm14, xmm9
00007583d7bd3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007583d7bd3078  vptest xmm6, xmm6
00007583d7bd307d  jnz 0x00007583D7BD5687
00007583d7bd3083  vmovaps xmm14, [rsp+0x70]
00007583d7bd3089  vpermilpd xmm14, xmm14, 0x00
00007583d7bd308f  movaps xmm10, xmm13
00007583d7bd3093  vfmadd231pd xmm10, xmm11, xmm14
00007583d7bd3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007583d7bd309e  vptest xmm9, xmm9
00007583d7bd30a3  jnz 0x00007583D7BD57E1
00007583d7bd30a9  vmovaps xmm14, [rsp+0x70]
00007583d7bd30af  vpermilpd xmm14, xmm14, 0x00
00007583d7bd30b5  movaps xmm13, xmm12
00007583d7bd30b9  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007583d7bd30c4  vptest xmm11, xmm11
00007583d7bd30c9  jnz 0x00007583D7BD593B
00007583d7bd30cf  lea rax, [r14+0x90]
00007583d7bd30d6  movups xmm15, [r13+rax*1]
00007583d7bd30dc  lea rax, [r14+0xA0]
00007583d7bd30e3  movups xmm14, [r13+rax*1]
00007583d7bd30e9  movaps [r15+0x140], xmm15
00007583d7bd30f1  movaps [r15+0x130], xmm14
00007583d7bd30f9  vmovaps xmm12, [rsp+0x90]
00007583d7bd3102  vpermilpd xmm12, xmm12, 0x00
00007583d7bd3108  movaps xmm11, xmm7
00007583d7bd310c  vfmadd231pd xmm11, xmm1, xmm12
00007583d7bd3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007583d7bd3117  vptest xmm9, xmm9
00007583d7bd311c  jnz 0x00007583D7BD5AA9
00007583d7bd3122  movaps [r15+0x220], xmm11
00007583d7bd312a  lea rax, [r14+0x10]
00007583d7bd312e  movups xmm1, [r13+rax*1]
00007583d7bd3134  movaps [r15+0x240], xmm1
00007583d7bd313c  vmovaps xmm12, [rsp+0x90]
00007583d7bd3145  vpermilpd xmm12, xmm12, 0x00
00007583d7bd314b  movaps xmm9, xmm8
00007583d7bd314f  vfmadd231pd xmm9, xmm14, xmm12
00007583d7bd3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007583d7bd315a  vptest xmm7, xmm7
00007583d7bd315f  jnz 0x00007583D7BD5C0B
00007583d7bd3165  movaps [r15+0x110], xmm9
00007583d7bd316d  vmovaps xmm14, [rsp+0x90]
00007583d7bd3176  vpermilpd xmm14, xmm14, 0x00
00007583d7bd317c  movaps xmm12, xmm10
00007583d7bd3180  vfmadd231pd xmm12, xmm15, xmm14
00007583d7bd3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007583d7bd318b  vptest xmm8, xmm8
00007583d7bd3190  jnz 0x00007583D7BD5D65
00007583d7bd3196  movaps [r15+0x170], xmm12
00007583d7bd319e  vmovaps xmm15, [rsp+0x90]
00007583d7bd31a7  vpermilpd xmm15, xmm15, 0x00
00007583d7bd31ad  movaps xmm14, xmm13
00007583d7bd31b1  vfmadd231pd xmm14, xmm1, xmm15
00007583d7bd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007583d7bd31bc  vptest xmm10, xmm10
00007583d7bd31c1  jnz 0x00007583D7BD5EBF
00007583d7bd31c7  movaps [r15+0x230], xmm14
00007583d7bd31cf  mov eax, 0x432190
00007583d7bd31d4  movups [r13+rax*1], xmm9
00007583d7bd31da  mov eax, 0x4321A0
00007583d7bd31df  movups [r13+rax*1], xmm12
00007583d7bd31e5  mov eax, 0x4321B0
00007583d7bd31ea  movups [r13+rax*1], xmm11
00007583d7bd31f0  mov eax, 0x4321C0
00007583d7bd31f5  movups [r13+rax*1], xmm14
00007583d7bd31fb  mov eax, [r15+0x108]
00007583d7bd3202  sahf
00007583d7bd3203  jnz 0x00007583D7BD3235
00007583d7bd3205  cmp dword ptr [r15+0x318], 0x00
00007583d7bd320d  jz 0x00007583D7BD9950
00007583d7bd3213  nop [rax+rax*1], ax
00007583d7bd321c  nop [rax+rax*1], eax
00007583d7bd3224  mov eax, 0x410664
00007583d7bd3229  mov [r15+0x100], rax
00007583d7bd3230  jmp 0x00007583D79FE110
00007583d7bd3235  cmp dword ptr [r15+0x318], 0x00
00007583d7bd323d  jz 0x00007583D7BD6050
00007583d7bd3243  nop [rax+rax*1], ax
00007583d7bd324c  nop [rax+rax*1], eax
00007583d7bd3254  mov eax, 0x4104F0
00007583d7bd3259  mov [r15+0x100], rax
00007583d7bd3260  jmp 0x00007583D79FE110
00007583d7bd3265  int3
00007583d7bd3266  call 0x00007583D79FF430
00007583d7bd326b  jmp 0x00007583D7BD230A
00007583d7bd3270  call 0x00007583D7AE5820
00007583d7bd3275  jmp 0x00007583D7BD2314
00007583d7bd327a  call 0x00007583D7AE45A0
00007583d7bd327f  jmp 0x00007583D7BD2326
00007583d7bd3284  call 0x00007583D7AE3320
00007583d7bd3289  jmp 0x00007583D7BD2330
00007583d7bd328e  call 0x00007583D7AE20A0
00007583d7bd3293  jmp 0x00007583D7BD233D
00007583d7bd3298  call 0x00007583D7AE0E30
00007583d7bd329d  jmp 0x00007583D7BD234A
00007583d7bd32a2  call 0x00007583D7AD6600
00007583d7bd32a7  jmp 0x00007583D7BD2357
00007583d7bd32ac  call 0x00007583D7AB52F0
00007583d7bd32b1  jmp 0x00007583D7BD2361
00007583d7bd32b6  call 0x00007583D7ABE9C0
00007583d7bd32bb  jmp 0x00007583D7BD236B
00007583d7bd32c0  call 0x00007583D7ABD750
00007583d7bd32c5  jmp 0x00007583D7BD2378
00007583d7bd32ca  call 0x00007583D7ABC4E0
00007583d7bd32cf  jmp 0x00007583D7BD2385
00007583d7bd32d4  call 0x00007583D7ABB270
00007583d7bd32d9  jmp 0x00007583D7BD2392
00007583d7bd32de  call 0x00007583D7ABA000
00007583d7bd32e3  jmp 0x00007583D7BD239F
00007583d7bd32e8  call 0x00007583D7AB8D90
00007583d7bd32ed  jmp 0x00007583D7BD23AC
00007583d7bd32f2  call 0x00007583D7AB8A20
00007583d7bd32f7  jmp 0x00007583D7BD23B9
00007583d7bd32fc  call 0x00007583D7ABEAE0
00007583d7bd3301  jmp 0x00007583D7BD23C6
00007583d7bd3306  call 0x00007583D7AB5400
00007583d7bd330b  jmp 0x00007583D7BD23D3
00007583d7bd3310  call 0x00007583D7AB52F0
00007583d7bd3315  jmp 0x00007583D7BD23E0
00007583d7bd331a  call 0x00007583D7ABE9C0
00007583d7bd331f  jmp 0x00007583D7BD23ED
00007583d7bd3324  call 0x00007583D7AB77B0
00007583d7bd3329  jmp 0x00007583D7BD23FA
00007583d7bd332e  call 0x00007583D7AB6550
00007583d7bd3333  jmp 0x00007583D7BD2407
00007583d7bd3338  call 0x00007583D7AB52F0
00007583d7bd333d  jmp 0x00007583D7BD2417
00007583d7bd3342  call 0x00007583D7AB52F0
00007583d7bd3347  jmp 0x00007583D7BD2427
00007583d7bd334c  call 0x00007583D7ABEAE0
00007583d7bd3351  jmp 0x00007583D7BD2431
00007583d7bd3356  call 0x00007583D7ABEAE0
00007583d7bd335b  jmp 0x00007583D7BD2444
00007583d7bd3360  call 0x00007583D7ABE9C0
00007583d7bd3365  jmp 0x00007583D7BD2451
00007583d7bd336a  call 0x00007583D7AB52F0
00007583d7bd336f  jmp 0x00007583D7BD2464
00007583d7bd3374  call 0x00007583D7AB6660
00007583d7bd3379  jmp 0x00007583D7BD2471
00007583d7bd337e  call 0x00007583D7AB78C0
00007583d7bd3383  jmp 0x00007583D7BD247E
00007583d7bd3388  call 0x00007583D7AB77B0
00007583d7bd338d  jmp 0x00007583D7BD248B
00007583d7bd3392  call 0x00007583D7AB6550
00007583d7bd3397  jmp 0x00007583D7BD2498
00007583d7bd339c  call 0x00007583D7AB52F0
00007583d7bd33a1  jmp 0x00007583D7BD24AB
00007583d7bd33a6  call 0x00007583D7AB52F0
00007583d7bd33ab  jmp 0x00007583D7BD24BE
00007583d7bd33b0  call 0x00007583D7AB52F0
00007583d7bd33b5  jmp 0x00007583D7BD24E5
00007583d7bd33ba  call 0x00007583D7AB52F0
00007583d7bd33bf  jmp 0x00007583D7BD24F8
00007583d7bd33c4  call 0x00007583D7AB52F0
00007583d7bd33c9  jmp 0x00007583D7BD250B
00007583d7bd33ce  call 0x00007583D7AB52F0
00007583d7bd33d3  jmp 0x00007583D7BD2521
00007583d7bd33d8  call 0x00007583D7AB52F0
00007583d7bd33dd  jmp 0x00007583D7BD2537
00007583d7bd33e2  call 0x00007583D7AB52F0
00007583d7bd33e7  jmp 0x00007583D7BD254D
00007583d7bd33ec  call 0x00007583D79FF540
00007583d7bd33f1  jmp 0x00007583D7BD256E
00007583d7bd33f6  call 0x00007583D7A02FE0
00007583d7bd33fb  jmp 0x00007583D7BD2578
00007583d7bd3400  call 0x00007583D79FF540
00007583d7bd3405  jmp 0x00007583D7BD2588
00007583d7bd340a  call 0x00007583D79FF540
00007583d7bd340f  jmp 0x00007583D7BD259B
00007583d7bd3414  call 0x00007583D79FF540
00007583d7bd3419  jmp 0x00007583D7BD25AE
00007583d7bd341e  call 0x00007583D79FF540
00007583d7bd3423  jmp 0x00007583D7BD25C1
00007583d7bd3428  call 0x00007583D7AC0370
00007583d7bd342d  jmp 0x00007583D7BD25E0
00007583d7bd3432  call 0x00007583D7ABF100
00007583d7bd3437  jmp 0x00007583D7BD25E9
00007583d7bd343c  call 0x00007583D7AC0370
00007583d7bd3441  jmp 0x00007583D7BD2659
00007583d7bd3446  call 0x00007583D7ABF100
00007583d7bd344b  jmp 0x00007583D7BD2662
00007583d7bd3450  call 0x00007583D7AC0370
00007583d7bd3455  jmp 0x00007583D7BD270C
00007583d7bd345a  call 0x00007583D7ABF100
00007583d7bd345f  jmp 0x00007583D7BD2715
00007583d7bd3464  call 0x00007583D7A0B720
00007583d7bd3469  jmp 0x00007583D7BD27F7
00007583d7bd346e  call 0x00007583D7AD64F0
00007583d7bd3473  jmp 0x00007583D7BD281F
00007583d7bd3478  call 0x00007583D7AB47C0
00007583d7bd347d  jmp 0x00007583D7BD283A
00007583d7bd3482  sub rsp, 0x08
00007583d7bd3486  push rax
00007583d7bd3487  push rcx
00007583d7bd3488  push rdx
00007583d7bd3489  push rdi
00007583d7bd348a  push rsi
00007583d7bd348b  push r8
00007583d7bd348d  push r9
00007583d7bd348f  push r10
00007583d7bd3491  push r11
00007583d7bd3493  sub rsp, 0xF0
00007583d7bd349a  vmovaps [rsp], xmm0
00007583d7bd349f  vmovaps [rsp+0x10], xmm1
00007583d7bd34a5  vmovaps [rsp+0x20], xmm2
00007583d7bd34ab  vmovaps [rsp+0x30], xmm3
00007583d7bd34b1  vmovaps [rsp+0x40], xmm4
00007583d7bd34b7  vmovaps [rsp+0x50], xmm5
00007583d7bd34bd  vmovaps [rsp+0x60], xmm6
00007583d7bd34c3  vmovaps [rsp+0x70], xmm7
00007583d7bd34c9  vmovaps [rsp+0x80], xmm8
00007583d7bd34d2  vmovaps [rsp+0x90], xmm9
00007583d7bd34db  vmovaps [rsp+0xA0], xmm10
00007583d7bd34e4  vmovaps [rsp+0xB0], xmm11
00007583d7bd34ed  vmovaps [rsp+0xC0], xmm12
00007583d7bd34f6  vmovaps [rsp+0xD0], xmm14
00007583d7bd34ff  vmovaps [rsp+0xE0], xmm15
00007583d7bd3508  sub rsp, 0x40
00007583d7bd350c  lea rdi, [rsp]
00007583d7bd3510  lea rsi, [rsp+0x10]
00007583d7bd3515  lea rdx, [rsp+0x20]
00007583d7bd351a  lea rcx, [rsp+0x30]
00007583d7bd351f  mov r8d, 0x00
00007583d7bd3525  lea r9, [r15+0x3A8]
00007583d7bd352c  movaps [rdi], xmm13
00007583d7bd3530  movaps [rsi], xmm1
00007583d7bd3533  movaps [rdx], xmm15
00007583d7bd3537  movaps [rcx], xmm14
00007583d7bd353b  mov rax, 0x5BCB7EA35A50
00007583d7bd3545  call rax
00007583d7bd3547  movaps xmm13, [rsp]
00007583d7bd354c  add rsp, 0x40
00007583d7bd3550  vmovaps xmm0, [rsp]
00007583d7bd3555  vmovaps xmm1, [rsp+0x10]
00007583d7bd355b  vmovaps xmm2, [rsp+0x20]
00007583d7bd3561  vmovaps xmm3, [rsp+0x30]
00007583d7bd3567  vmovaps xmm4, [rsp+0x40]
00007583d7bd356d  vmovaps xmm5, [rsp+0x50]
00007583d7bd3573  vmovaps xmm6, [rsp+0x60]
00007583d7bd3579  vmovaps xmm7, [rsp+0x70]
00007583d7bd357f  vmovaps xmm8, [rsp+0x80]
00007583d7bd3588  vmovaps xmm9, [rsp+0x90]
00007583d7bd3591  vmovaps xmm10, [rsp+0xA0]
00007583d7bd359a  vmovaps xmm11, [rsp+0xB0]
00007583d7bd35a3  vmovaps xmm12, [rsp+0xC0]
00007583d7bd35ac  vmovaps xmm14, [rsp+0xD0]
00007583d7bd35b5  vmovaps xmm15, [rsp+0xE0]
00007583d7bd35be  add rsp, 0xF0
00007583d7bd35c5  pop r11
00007583d7bd35c7  pop r10
00007583d7bd35c9  pop r9
00007583d7bd35cb  pop r8
00007583d7bd35cd  pop rsi
00007583d7bd35ce  pop rdi
00007583d7bd35cf  pop rdx
00007583d7bd35d0  pop rcx
00007583d7bd35d1  pop rax
00007583d7bd35d2  add rsp, 0x08
00007583d7bd35d6  jmp 0x00007583D7BD28AD
00007583d7bd35db  sub rsp, 0x08
00007583d7bd35df  push rax
00007583d7bd35e0  push rcx
00007583d7bd35e1  push rdx
00007583d7bd35e2  push rdi
00007583d7bd35e3  push rsi
00007583d7bd35e4  push r8
00007583d7bd35e6  push r9
00007583d7bd35e8  push r10
00007583d7bd35ea  push r11
00007583d7bd35ec  sub rsp, 0xF0
00007583d7bd35f3  vmovaps [rsp], xmm0
00007583d7bd35f8  vmovaps [rsp+0x10], xmm1
00007583d7bd35fe  vmovaps [rsp+0x20], xmm2
00007583d7bd3604  vmovaps [rsp+0x30], xmm3
00007583d7bd360a  vmovaps [rsp+0x40], xmm4
00007583d7bd3610  vmovaps [rsp+0x50], xmm5
00007583d7bd3616  vmovaps [rsp+0x60], xmm6
00007583d7bd361c  vmovaps [rsp+0x70], xmm7
00007583d7bd3622  vmovaps [rsp+0x80], xmm8
00007583d7bd362b  vmovaps [rsp+0x90], xmm9
00007583d7bd3634  vmovaps [rsp+0xA0], xmm10
00007583d7bd363d  vmovaps [rsp+0xB0], xmm11
00007583d7bd3646  vmovaps [rsp+0xC0], xmm12
00007583d7bd364f  vmovaps [rsp+0xD0], xmm13
00007583d7bd3658  vmovaps [rsp+0xE0], xmm14
00007583d7bd3661  sub rsp, 0x40
00007583d7bd3665  lea rdi, [rsp]
00007583d7bd3669  lea rsi, [rsp+0x10]
00007583d7bd366e  lea rdx, [rsp+0x20]
00007583d7bd3673  lea rcx, [rsp+0x30]
00007583d7bd3678  mov r8d, 0x00
00007583d7bd367e  lea r9, [r15+0x3A8]
00007583d7bd3685  movaps [rdi], xmm15
00007583d7bd3689  movaps [rsi], xmm5
00007583d7bd368c  movaps [rdx], xmm1
00007583d7bd368f  movaps [rcx], xmm14
00007583d7bd3693  mov rax, 0x5BCB7EA35A50
00007583d7bd369d  call rax
00007583d7bd369f  movaps xmm15, [rsp]
00007583d7bd36a4  add rsp, 0x40
00007583d7bd36a8  vmovaps xmm0, [rsp]
00007583d7bd36ad  vmovaps xmm1, [rsp+0x10]
00007583d7bd36b3  vmovaps xmm2, [rsp+0x20]
00007583d7bd36b9  vmovaps xmm3, [rsp+0x30]
00007583d7bd36bf  vmovaps xmm4, [rsp+0x40]
00007583d7bd36c5  vmovaps xmm5, [rsp+0x50]
00007583d7bd36cb  vmovaps xmm6, [rsp+0x60]
00007583d7bd36d1  vmovaps xmm7, [rsp+0x70]
00007583d7bd36d7  vmovaps xmm8, [rsp+0x80]
00007583d7bd36e0  vmovaps xmm9, [rsp+0x90]
00007583d7bd36e9  vmovaps xmm10, [rsp+0xA0]
00007583d7bd36f2  vmovaps xmm11, [rsp+0xB0]
00007583d7bd36fb  vmovaps xmm12, [rsp+0xC0]
00007583d7bd3704  vmovaps xmm13, [rsp+0xD0]
00007583d7bd370d  vmovaps xmm14, [rsp+0xE0]
00007583d7bd3716  add rsp, 0xF0
00007583d7bd371d  pop r11
00007583d7bd371f  pop r10
00007583d7bd3721  pop r9
00007583d7bd3723  pop r8
00007583d7bd3725  pop rsi
00007583d7bd3726  pop rdi
00007583d7bd3727  pop rdx
00007583d7bd3728  pop rcx
00007583d7bd3729  pop rax
00007583d7bd372a  add rsp, 0x08
00007583d7bd372e  jmp 0x00007583D7BD28D0
00007583d7bd3733  call 0x00007583D79FF430
00007583d7bd3738  jmp 0x00007583D7BD295D
00007583d7bd373d  sub rsp, 0x08
00007583d7bd3741  push rax
00007583d7bd3742  push rcx
00007583d7bd3743  push rdx
00007583d7bd3744  push rdi
00007583d7bd3745  push rsi
00007583d7bd3746  push r8
00007583d7bd3748  push r9
00007583d7bd374a  push r10
00007583d7bd374c  push r11
00007583d7bd374e  sub rsp, 0xF0
00007583d7bd3755  vmovaps [rsp], xmm0
00007583d7bd375a  vmovaps [rsp+0x10], xmm1
00007583d7bd3760  vmovaps [rsp+0x20], xmm2
00007583d7bd3766  vmovaps [rsp+0x30], xmm3
00007583d7bd376c  vmovaps [rsp+0x40], xmm4
00007583d7bd3772  vmovaps [rsp+0x50], xmm5
00007583d7bd3778  vmovaps [rsp+0x60], xmm6
00007583d7bd377e  vmovaps [rsp+0x70], xmm7
00007583d7bd3784  vmovaps [rsp+0x80], xmm8
00007583d7bd378d  vmovaps [rsp+0x90], xmm9
00007583d7bd3796  vmovaps [rsp+0xA0], xmm10
00007583d7bd379f  vmovaps [rsp+0xB0], xmm11
00007583d7bd37a8  vmovaps [rsp+0xC0], xmm12
00007583d7bd37b1  vmovaps [rsp+0xD0], xmm14
00007583d7bd37ba  vmovaps [rsp+0xE0], xmm15
00007583d7bd37c3  sub rsp, 0x40
00007583d7bd37c7  lea rdi, [rsp]
00007583d7bd37cb  lea rsi, [rsp+0x10]
00007583d7bd37d0  lea rdx, [rsp+0x20]
00007583d7bd37d5  lea rcx, [rsp+0x30]
00007583d7bd37da  mov r8d, 0x00
00007583d7bd37e0  lea r9, [r15+0x3A8]
00007583d7bd37e7  movaps [rdi], xmm13
00007583d7bd37eb  movaps [rsi], xmm1
00007583d7bd37ee  movaps [rdx], xmm15
00007583d7bd37f2  movaps [rcx], xmm14
00007583d7bd37f6  mov rax, 0x5BCB7EA35A50
00007583d7bd3800  call rax
00007583d7bd3802  movaps xmm13, [rsp]
00007583d7bd3807  add rsp, 0x40
00007583d7bd380b  vmovaps xmm0, [rsp]
00007583d7bd3810  vmovaps xmm1, [rsp+0x10]
00007583d7bd3816  vmovaps xmm2, [rsp+0x20]
00007583d7bd381c  vmovaps xmm3, [rsp+0x30]
00007583d7bd3822  vmovaps xmm4, [rsp+0x40]
00007583d7bd3828  vmovaps xmm5, [rsp+0x50]
00007583d7bd382e  vmovaps xmm6, [rsp+0x60]
00007583d7bd3834  vmovaps xmm7, [rsp+0x70]
00007583d7bd383a  vmovaps xmm8, [rsp+0x80]
00007583d7bd3843  vmovaps xmm9, [rsp+0x90]
00007583d7bd384c  vmovaps xmm10, [rsp+0xA0]
00007583d7bd3855  vmovaps xmm11, [rsp+0xB0]
00007583d7bd385e  vmovaps xmm12, [rsp+0xC0]
00007583d7bd3867  vmovaps xmm14, [rsp+0xD0]
00007583d7bd3870  vmovaps xmm15, [rsp+0xE0]
00007583d7bd3879  add rsp, 0xF0
00007583d7bd3880  pop r11
00007583d7bd3882  pop r10
00007583d7bd3884  pop r9
00007583d7bd3886  pop r8
00007583d7bd3888  pop rsi
00007583d7bd3889  pop rdi
00007583d7bd388a  pop rdx
00007583d7bd388b  pop rcx
00007583d7bd388c  pop rax
00007583d7bd388d  add rsp, 0x08
00007583d7bd3891  jmp 0x00007583D7BD29C1
00007583d7bd3896  call 0x00007583D79FF430
00007583d7bd389b  jmp 0x00007583D7BD29CE
00007583d7bd38a0  sub rsp, 0x08
00007583d7bd38a4  push rax
00007583d7bd38a5  push rcx
00007583d7bd38a6  push rdx
00007583d7bd38a7  push rdi
00007583d7bd38a8  push rsi
00007583d7bd38a9  push r8
00007583d7bd38ab  push r9
00007583d7bd38ad  push r10
00007583d7bd38af  push r11
00007583d7bd38b1  sub rsp, 0xF0
00007583d7bd38b8  vmovaps [rsp], xmm0
00007583d7bd38bd  vmovaps [rsp+0x10], xmm1
00007583d7bd38c3  vmovaps [rsp+0x20], xmm2
00007583d7bd38c9  vmovaps [rsp+0x30], xmm3
00007583d7bd38cf  vmovaps [rsp+0x40], xmm4
00007583d7bd38d5  vmovaps [rsp+0x50], xmm5
00007583d7bd38db  vmovaps [rsp+0x60], xmm6
00007583d7bd38e1  vmovaps [rsp+0x70], xmm7
00007583d7bd38e7  vmovaps [rsp+0x80], xmm8
00007583d7bd38f0  vmovaps [rsp+0x90], xmm9
00007583d7bd38f9  vmovaps [rsp+0xA0], xmm10
00007583d7bd3902  vmovaps [rsp+0xB0], xmm11
00007583d7bd390b  vmovaps [rsp+0xC0], xmm13
00007583d7bd3914  vmovaps [rsp+0xD0], xmm14
00007583d7bd391d  vmovaps [rsp+0xE0], xmm15
00007583d7bd3926  sub rsp, 0x40
00007583d7bd392a  lea rdi, [rsp]
00007583d7bd392e  lea rsi, [rsp+0x10]
00007583d7bd3933  lea rdx, [rsp+0x20]
00007583d7bd3938  lea rcx, [rsp+0x30]
00007583d7bd393d  mov r8d, 0x00
00007583d7bd3943  lea r9, [r15+0x3A8]
00007583d7bd394a  movaps [rdi], xmm12
00007583d7bd394e  movaps [rsi], xmm15
00007583d7bd3952  movaps [rdx], xmm1
00007583d7bd3955  movaps [rcx], xmm14
00007583d7bd3959  mov rax, 0x5BCB7EA35A50
00007583d7bd3963  call rax
00007583d7bd3965  movaps xmm12, [rsp]
00007583d7bd396a  add rsp, 0x40
00007583d7bd396e  vmovaps xmm0, [rsp]
00007583d7bd3973  vmovaps xmm1, [rsp+0x10]
00007583d7bd3979  vmovaps xmm2, [rsp+0x20]
00007583d7bd397f  vmovaps xmm3, [rsp+0x30]
00007583d7bd3985  vmovaps xmm4, [rsp+0x40]
00007583d7bd398b  vmovaps xmm5, [rsp+0x50]
00007583d7bd3991  vmovaps xmm6, [rsp+0x60]
00007583d7bd3997  vmovaps xmm7, [rsp+0x70]
00007583d7bd399d  vmovaps xmm8, [rsp+0x80]
00007583d7bd39a6  vmovaps xmm9, [rsp+0x90]
00007583d7bd39af  vmovaps xmm10, [rsp+0xA0]
00007583d7bd39b8  vmovaps xmm11, [rsp+0xB0]
00007583d7bd39c1  vmovaps xmm13, [rsp+0xC0]
00007583d7bd39ca  vmovaps xmm14, [rsp+0xD0]
00007583d7bd39d3  vmovaps xmm15, [rsp+0xE0]
00007583d7bd39dc  add rsp, 0xF0
00007583d7bd39e3  pop r11
00007583d7bd39e5  pop r10
00007583d7bd39e7  pop r9
00007583d7bd39e9  pop r8
00007583d7bd39eb  pop rsi
00007583d7bd39ec  pop rdi
00007583d7bd39ed  pop rdx
00007583d7bd39ee  pop rcx
00007583d7bd39ef  pop rax
00007583d7bd39f0  add rsp, 0x08
00007583d7bd39f4  jmp 0x00007583D7BD29FA
00007583d7bd39f9  sub rsp, 0x08
00007583d7bd39fd  push rax
00007583d7bd39fe  push rcx
00007583d7bd39ff  push rdx
00007583d7bd3a00  push rdi
00007583d7bd3a01  push rsi
00007583d7bd3a02  push r8
00007583d7bd3a04  push r9
00007583d7bd3a06  push r10
00007583d7bd3a08  push r11
00007583d7bd3a0a  sub rsp, 0xF0
00007583d7bd3a11  vmovaps [rsp], xmm0
00007583d7bd3a16  vmovaps [rsp+0x10], xmm1
00007583d7bd3a1c  vmovaps [rsp+0x20], xmm2
00007583d7bd3a22  vmovaps [rsp+0x30], xmm3
00007583d7bd3a28  vmovaps [rsp+0x40], xmm4
00007583d7bd3a2e  vmovaps [rsp+0x50], xmm5
00007583d7bd3a34  vmovaps [rsp+0x60], xmm6
00007583d7bd3a3a  vmovaps [rsp+0x70], xmm7
00007583d7bd3a40  vmovaps [rsp+0x80], xmm8
00007583d7bd3a49  vmovaps [rsp+0x90], xmm9
00007583d7bd3a52  vmovaps [rsp+0xA0], xmm10
00007583d7bd3a5b  vmovaps [rsp+0xB0], xmm11
00007583d7bd3a64  vmovaps [rsp+0xC0], xmm12
00007583d7bd3a6d  vmovaps [rsp+0xD0], xmm14
00007583d7bd3a76  vmovaps [rsp+0xE0], xmm15
00007583d7bd3a7f  sub rsp, 0x40
00007583d7bd3a83  lea rdi, [rsp]
00007583d7bd3a87  lea rsi, [rsp+0x10]
00007583d7bd3a8c  lea rdx, [rsp+0x20]
00007583d7bd3a91  lea rcx, [rsp+0x30]
00007583d7bd3a96  mov r8d, 0x00
00007583d7bd3a9c  lea r9, [r15+0x3A8]
00007583d7bd3aa3  movaps [rdi], xmm13
00007583d7bd3aa7  movaps [rsi], xmm1
00007583d7bd3aaa  movaps [rdx], xmm15
00007583d7bd3aae  movaps [rcx], xmm14
00007583d7bd3ab2  mov rax, 0x5BCB7EA35A50
00007583d7bd3abc  call rax
00007583d7bd3abe  movaps xmm13, [rsp]
00007583d7bd3ac3  add rsp, 0x40
00007583d7bd3ac7  vmovaps xmm0, [rsp]
00007583d7bd3acc  vmovaps xmm1, [rsp+0x10]
00007583d7bd3ad2  vmovaps xmm2, [rsp+0x20]
00007583d7bd3ad8  vmovaps xmm3, [rsp+0x30]
00007583d7bd3ade  vmovaps xmm4, [rsp+0x40]
00007583d7bd3ae4  vmovaps xmm5, [rsp+0x50]
00007583d7bd3aea  vmovaps xmm6, [rsp+0x60]
00007583d7bd3af0  vmovaps xmm7, [rsp+0x70]
00007583d7bd3af6  vmovaps xmm8, [rsp+0x80]
00007583d7bd3aff  vmovaps xmm9, [rsp+0x90]
00007583d7bd3b08  vmovaps xmm10, [rsp+0xA0]
00007583d7bd3b11  vmovaps xmm11, [rsp+0xB0]
00007583d7bd3b1a  vmovaps xmm12, [rsp+0xC0]
00007583d7bd3b23  vmovaps xmm14, [rsp+0xD0]
00007583d7bd3b2c  vmovaps xmm15, [rsp+0xE0]
00007583d7bd3b35  add rsp, 0xF0
00007583d7bd3b3c  pop r11
00007583d7bd3b3e  pop r10
00007583d7bd3b40  pop r9
00007583d7bd3b42  pop r8
00007583d7bd3b44  pop rsi
00007583d7bd3b45  pop rdi
00007583d7bd3b46  pop rdx
00007583d7bd3b47  pop rcx
00007583d7bd3b48  pop rax
00007583d7bd3b49  add rsp, 0x08
00007583d7bd3b4d  jmp 0x00007583D7BD2B77
00007583d7bd3b52  sub rsp, 0x08
00007583d7bd3b56  push rax
00007583d7bd3b57  push rcx
00007583d7bd3b58  push rdx
00007583d7bd3b59  push rdi
00007583d7bd3b5a  push rsi
00007583d7bd3b5b  push r8
00007583d7bd3b5d  push r9
00007583d7bd3b5f  push r10
00007583d7bd3b61  push r11
00007583d7bd3b63  sub rsp, 0xF0
00007583d7bd3b6a  vmovaps [rsp], xmm0
00007583d7bd3b6f  vmovaps [rsp+0x10], xmm1
00007583d7bd3b75  vmovaps [rsp+0x20], xmm2
00007583d7bd3b7b  vmovaps [rsp+0x30], xmm3
00007583d7bd3b81  vmovaps [rsp+0x40], xmm4
00007583d7bd3b87  vmovaps [rsp+0x50], xmm5
00007583d7bd3b8d  vmovaps [rsp+0x60], xmm6
00007583d7bd3b93  vmovaps [rsp+0x70], xmm7
00007583d7bd3b99  vmovaps [rsp+0x80], xmm8
00007583d7bd3ba2  vmovaps [rsp+0x90], xmm9
00007583d7bd3bab  vmovaps [rsp+0xA0], xmm10
00007583d7bd3bb4  vmovaps [rsp+0xB0], xmm11
00007583d7bd3bbd  vmovaps [rsp+0xC0], xmm13
00007583d7bd3bc6  vmovaps [rsp+0xD0], xmm14
00007583d7bd3bcf  vmovaps [rsp+0xE0], xmm15
00007583d7bd3bd8  sub rsp, 0x40
00007583d7bd3bdc  lea rdi, [rsp]
00007583d7bd3be0  lea rsi, [rsp+0x10]
00007583d7bd3be5  lea rdx, [rsp+0x20]
00007583d7bd3bea  lea rcx, [rsp+0x30]
00007583d7bd3bef  mov r8d, 0x00
00007583d7bd3bf5  lea r9, [r15+0x3A8]
00007583d7bd3bfc  movaps [rdi], xmm12
00007583d7bd3c00  movaps [rsi], xmm15
00007583d7bd3c04  movaps [rdx], xmm14
00007583d7bd3c08  movaps [rcx], xmm1
00007583d7bd3c0b  mov rax, 0x5BCB7EA35A50
00007583d7bd3c15  call rax
00007583d7bd3c17  movaps xmm12, [rsp]
00007583d7bd3c1c  add rsp, 0x40
00007583d7bd3c20  vmovaps xmm0, [rsp]
00007583d7bd3c25  vmovaps xmm1, [rsp+0x10]
00007583d7bd3c2b  vmovaps xmm2, [rsp+0x20]
00007583d7bd3c31  vmovaps xmm3, [rsp+0x30]
00007583d7bd3c37  vmovaps xmm4, [rsp+0x40]
00007583d7bd3c3d  vmovaps xmm5, [rsp+0x50]
00007583d7bd3c43  vmovaps xmm6, [rsp+0x60]
00007583d7bd3c49  vmovaps xmm7, [rsp+0x70]
00007583d7bd3c4f  vmovaps xmm8, [rsp+0x80]
00007583d7bd3c58  vmovaps xmm9, [rsp+0x90]
00007583d7bd3c61  vmovaps xmm10, [rsp+0xA0]
00007583d7bd3c6a  vmovaps xmm11, [rsp+0xB0]
00007583d7bd3c73  vmovaps xmm13, [rsp+0xC0]
00007583d7bd3c7c  vmovaps xmm14, [rsp+0xD0]
00007583d7bd3c85  vmovaps xmm15, [rsp+0xE0]
00007583d7bd3c8e  add rsp, 0xF0
00007583d7bd3c95  pop r11
00007583d7bd3c97  pop r10
00007583d7bd3c99  pop r9
00007583d7bd3c9b  pop r8
00007583d7bd3c9d  pop rsi
00007583d7bd3c9e  pop rdi
00007583d7bd3c9f  pop rdx
00007583d7bd3ca0  pop rcx
00007583d7bd3ca1  pop rax
00007583d7bd3ca2  add rsp, 0x08
00007583d7bd3ca6  jmp 0x00007583D7BD2BB2
00007583d7bd3cab  sub rsp, 0x08
00007583d7bd3caf  push rax
00007583d7bd3cb0  push rcx
00007583d7bd3cb1  push rdx
00007583d7bd3cb2  push rdi
00007583d7bd3cb3  push rsi
00007583d7bd3cb4  push r8
00007583d7bd3cb6  push r9
00007583d7bd3cb8  push r10
00007583d7bd3cba  push r11
00007583d7bd3cbc  sub rsp, 0xF0
00007583d7bd3cc3  vmovaps [rsp], xmm0
00007583d7bd3cc8  vmovaps [rsp+0x10], xmm1
00007583d7bd3cce  vmovaps [rsp+0x20], xmm2
00007583d7bd3cd4  vmovaps [rsp+0x30], xmm3
00007583d7bd3cda  vmovaps [rsp+0x40], xmm4
00007583d7bd3ce0  vmovaps [rsp+0x50], xmm5
00007583d7bd3ce6  vmovaps [rsp+0x60], xmm6
00007583d7bd3cec  vmovaps [rsp+0x70], xmm7
00007583d7bd3cf2  vmovaps [rsp+0x80], xmm8
00007583d7bd3cfb  vmovaps [rsp+0x90], xmm9
00007583d7bd3d04  vmovaps [rsp+0xA0], xmm10
00007583d7bd3d0d  vmovaps [rsp+0xB0], xmm11
00007583d7bd3d16  vmovaps [rsp+0xC0], xmm12
00007583d7bd3d1f  vmovaps [rsp+0xD0], xmm14
00007583d7bd3d28  vmovaps [rsp+0xE0], xmm15
00007583d7bd3d31  sub rsp, 0x40
00007583d7bd3d35  lea rdi, [rsp]
00007583d7bd3d39  lea rsi, [rsp+0x10]
00007583d7bd3d3e  lea rdx, [rsp+0x20]
00007583d7bd3d43  lea rcx, [rsp+0x30]
00007583d7bd3d48  mov r8d, 0x00
00007583d7bd3d4e  lea r9, [r15+0x3A8]
00007583d7bd3d55  movaps [rdi], xmm13
00007583d7bd3d59  movaps [rsi], xmm15
00007583d7bd3d5d  movaps [rdx], xmm14
00007583d7bd3d61  movaps [rcx], xmm1
00007583d7bd3d64  mov rax, 0x5BCB7EA35A50
00007583d7bd3d6e  call rax
00007583d7bd3d70  movaps xmm13, [rsp]
00007583d7bd3d75  add rsp, 0x40
00007583d7bd3d79  vmovaps xmm0, [rsp]
00007583d7bd3d7e  vmovaps xmm1, [rsp+0x10]
00007583d7bd3d84  vmovaps xmm2, [rsp+0x20]
00007583d7bd3d8a  vmovaps xmm3, [rsp+0x30]
00007583d7bd3d90  vmovaps xmm4, [rsp+0x40]
00007583d7bd3d96  vmovaps xmm5, [rsp+0x50]
00007583d7bd3d9c  vmovaps xmm6, [rsp+0x60]
00007583d7bd3da2  vmovaps xmm7, [rsp+0x70]
00007583d7bd3da8  vmovaps xmm8, [rsp+0x80]
00007583d7bd3db1  vmovaps xmm9, [rsp+0x90]
00007583d7bd3dba  vmovaps xmm10, [rsp+0xA0]
00007583d7bd3dc3  vmovaps xmm11, [rsp+0xB0]
00007583d7bd3dcc  vmovaps xmm12, [rsp+0xC0]
00007583d7bd3dd5  vmovaps xmm14, [rsp+0xD0]
00007583d7bd3dde  vmovaps xmm15, [rsp+0xE0]
00007583d7bd3de7  add rsp, 0xF0
00007583d7bd3dee  pop r11
00007583d7bd3df0  pop r10
00007583d7bd3df2  pop r9
00007583d7bd3df4  pop r8
00007583d7bd3df6  pop rsi
00007583d7bd3df7  pop rdi
00007583d7bd3df8  pop rdx
00007583d7bd3df9  pop rcx
00007583d7bd3dfa  pop rax
00007583d7bd3dfb  add rsp, 0x08
00007583d7bd3dff  jmp 0x00007583D7BD2BEA
00007583d7bd3e04  sub rsp, 0x08
00007583d7bd3e08  push rax
00007583d7bd3e09  push rcx
00007583d7bd3e0a  push rdx
00007583d7bd3e0b  push rdi
00007583d7bd3e0c  push rsi
00007583d7bd3e0d  push r8
00007583d7bd3e0f  push r9
00007583d7bd3e11  push r10
00007583d7bd3e13  push r11
00007583d7bd3e15  sub rsp, 0xF0
00007583d7bd3e1c  vmovaps [rsp], xmm0
00007583d7bd3e21  vmovaps [rsp+0x10], xmm1
00007583d7bd3e27  vmovaps [rsp+0x20], xmm2
00007583d7bd3e2d  vmovaps [rsp+0x30], xmm3
00007583d7bd3e33  vmovaps [rsp+0x40], xmm4
00007583d7bd3e39  vmovaps [rsp+0x50], xmm5
00007583d7bd3e3f  vmovaps [rsp+0x60], xmm6
00007583d7bd3e45  vmovaps [rsp+0x70], xmm7
00007583d7bd3e4b  vmovaps [rsp+0x80], xmm8
00007583d7bd3e54  vmovaps [rsp+0x90], xmm9
00007583d7bd3e5d  vmovaps [rsp+0xA0], xmm10
00007583d7bd3e66  vmovaps [rsp+0xB0], xmm11
00007583d7bd3e6f  vmovaps [rsp+0xC0], xmm13
00007583d7bd3e78  vmovaps [rsp+0xD0], xmm14
00007583d7bd3e81  vmovaps [rsp+0xE0], xmm15
00007583d7bd3e8a  sub rsp, 0x40
00007583d7bd3e8e  lea rdi, [rsp]
00007583d7bd3e92  lea rsi, [rsp+0x10]
00007583d7bd3e97  lea rdx, [rsp+0x20]
00007583d7bd3e9c  lea rcx, [rsp+0x30]
00007583d7bd3ea1  mov r8d, 0x00
00007583d7bd3ea7  lea r9, [r15+0x3A8]
00007583d7bd3eae  movaps [rdi], xmm12
00007583d7bd3eb2  movaps [rsi], xmm15
00007583d7bd3eb6  movaps [rdx], xmm14
00007583d7bd3eba  movaps [rcx], xmm1
00007583d7bd3ebd  mov rax, 0x5BCB7EA35A50
00007583d7bd3ec7  call rax
00007583d7bd3ec9  movaps xmm12, [rsp]
00007583d7bd3ece  add rsp, 0x40
00007583d7bd3ed2  vmovaps xmm0, [rsp]
00007583d7bd3ed7  vmovaps xmm1, [rsp+0x10]
00007583d7bd3edd  vmovaps xmm2, [rsp+0x20]
00007583d7bd3ee3  vmovaps xmm3, [rsp+0x30]
00007583d7bd3ee9  vmovaps xmm4, [rsp+0x40]
00007583d7bd3eef  vmovaps xmm5, [rsp+0x50]
00007583d7bd3ef5  vmovaps xmm6, [rsp+0x60]
00007583d7bd3efb  vmovaps xmm7, [rsp+0x70]
00007583d7bd3f01  vmovaps xmm8, [rsp+0x80]
00007583d7bd3f0a  vmovaps xmm9, [rsp+0x90]
00007583d7bd3f13  vmovaps xmm10, [rsp+0xA0]
00007583d7bd3f1c  vmovaps xmm11, [rsp+0xB0]
00007583d7bd3f25  vmovaps xmm13, [rsp+0xC0]
00007583d7bd3f2e  vmovaps xmm14, [rsp+0xD0]
00007583d7bd3f37  vmovaps xmm15, [rsp+0xE0]
00007583d7bd3f40  add rsp, 0xF0
00007583d7bd3f47  pop r11
00007583d7bd3f49  pop r10
00007583d7bd3f4b  pop r9
00007583d7bd3f4d  pop r8
00007583d7bd3f4f  pop rsi
00007583d7bd3f50  pop rdi
00007583d7bd3f51  pop rdx
00007583d7bd3f52  pop rcx
00007583d7bd3f53  pop rax
00007583d7bd3f54  add rsp, 0x08
00007583d7bd3f58  jmp 0x00007583D7BD2C3D
00007583d7bd3f5d  sub rsp, 0x08
00007583d7bd3f61  push rax
00007583d7bd3f62  push rcx
00007583d7bd3f63  push rdx
00007583d7bd3f64  push rdi
00007583d7bd3f65  push rsi
00007583d7bd3f66  push r8
00007583d7bd3f68  push r9
00007583d7bd3f6a  push r10
00007583d7bd3f6c  push r11
00007583d7bd3f6e  sub rsp, 0xF0
00007583d7bd3f75  vmovaps [rsp], xmm0
00007583d7bd3f7a  vmovaps [rsp+0x10], xmm1
00007583d7bd3f80  vmovaps [rsp+0x20], xmm2
00007583d7bd3f86  vmovaps [rsp+0x30], xmm3
00007583d7bd3f8c  vmovaps [rsp+0x40], xmm4
00007583d7bd3f92  vmovaps [rsp+0x50], xmm5
00007583d7bd3f98  vmovaps [rsp+0x60], xmm6
00007583d7bd3f9e  vmovaps [rsp+0x70], xmm7
00007583d7bd3fa4  vmovaps [rsp+0x80], xmm8
00007583d7bd3fad  vmovaps [rsp+0x90], xmm9
00007583d7bd3fb6  vmovaps [rsp+0xA0], xmm10
00007583d7bd3fbf  vmovaps [rsp+0xB0], xmm11
00007583d7bd3fc8  vmovaps [rsp+0xC0], xmm12
00007583d7bd3fd1  vmovaps [rsp+0xD0], xmm13
00007583d7bd3fda  vmovaps [rsp+0xE0], xmm15
00007583d7bd3fe3  sub rsp, 0x40
00007583d7bd3fe7  lea rdi, [rsp]
00007583d7bd3feb  lea rsi, [rsp+0x10]
00007583d7bd3ff0  lea rdx, [rsp+0x20]
00007583d7bd3ff5  lea rcx, [rsp+0x30]
00007583d7bd3ffa  mov r8d, 0x00
00007583d7bd4000  lea r9, [r15+0x3A8]
00007583d7bd4007  movaps [rdi], xmm14
00007583d7bd400b  movaps [rsi], xmm3
00007583d7bd400e  movaps [rdx], xmm1
00007583d7bd4011  movaps [rcx], xmm15
00007583d7bd4015  mov rax, 0x5BCB7EA35A50
00007583d7bd401f  call rax
00007583d7bd4021  movaps xmm14, [rsp]
00007583d7bd4026  add rsp, 0x40
00007583d7bd402a  vmovaps xmm0, [rsp]
00007583d7bd402f  vmovaps xmm1, [rsp+0x10]
00007583d7bd4035  vmovaps xmm2, [rsp+0x20]
00007583d7bd403b  vmovaps xmm3, [rsp+0x30]
00007583d7bd4041  vmovaps xmm4, [rsp+0x40]
00007583d7bd4047  vmovaps xmm5, [rsp+0x50]
00007583d7bd404d  vmovaps xmm6, [rsp+0x60]
00007583d7bd4053  vmovaps xmm7, [rsp+0x70]
00007583d7bd4059  vmovaps xmm8, [rsp+0x80]
00007583d7bd4062  vmovaps xmm9, [rsp+0x90]
00007583d7bd406b  vmovaps xmm10, [rsp+0xA0]
00007583d7bd4074  vmovaps xmm11, [rsp+0xB0]
00007583d7bd407d  vmovaps xmm12, [rsp+0xC0]
00007583d7bd4086  vmovaps xmm13, [rsp+0xD0]
00007583d7bd408f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd4098  add rsp, 0xF0
00007583d7bd409f  pop r11
00007583d7bd40a1  pop r10
00007583d7bd40a3  pop r9
00007583d7bd40a5  pop r8
00007583d7bd40a7  pop rsi
00007583d7bd40a8  pop rdi
00007583d7bd40a9  pop rdx
00007583d7bd40aa  pop rcx
00007583d7bd40ab  pop rax
00007583d7bd40ac  add rsp, 0x08
00007583d7bd40b0  jmp 0x00007583D7BD2CF7
00007583d7bd40b5  sub rsp, 0x08
00007583d7bd40b9  push rax
00007583d7bd40ba  push rcx
00007583d7bd40bb  push rdx
00007583d7bd40bc  push rdi
00007583d7bd40bd  push rsi
00007583d7bd40be  push r8
00007583d7bd40c0  push r9
00007583d7bd40c2  push r10
00007583d7bd40c4  push r11
00007583d7bd40c6  sub rsp, 0xF0
00007583d7bd40cd  vmovaps [rsp], xmm0
00007583d7bd40d2  vmovaps [rsp+0x10], xmm1
00007583d7bd40d8  vmovaps [rsp+0x20], xmm2
00007583d7bd40de  vmovaps [rsp+0x30], xmm3
00007583d7bd40e4  vmovaps [rsp+0x40], xmm4
00007583d7bd40ea  vmovaps [rsp+0x50], xmm5
00007583d7bd40f0  vmovaps [rsp+0x60], xmm6
00007583d7bd40f6  vmovaps [rsp+0x70], xmm7
00007583d7bd40fc  vmovaps [rsp+0x80], xmm8
00007583d7bd4105  vmovaps [rsp+0x90], xmm9
00007583d7bd410e  vmovaps [rsp+0xA0], xmm10
00007583d7bd4117  vmovaps [rsp+0xB0], xmm11
00007583d7bd4120  vmovaps [rsp+0xC0], xmm12
00007583d7bd4129  vmovaps [rsp+0xD0], xmm14
00007583d7bd4132  vmovaps [rsp+0xE0], xmm15
00007583d7bd413b  sub rsp, 0x40
00007583d7bd413f  lea rdi, [rsp]
00007583d7bd4143  lea rsi, [rsp+0x10]
00007583d7bd4148  lea rdx, [rsp+0x20]
00007583d7bd414d  lea rcx, [rsp+0x30]
00007583d7bd4152  mov r8d, 0x00
00007583d7bd4158  lea r9, [r15+0x3A8]
00007583d7bd415f  movaps [rdi], xmm13
00007583d7bd4163  movaps [rsi], xmm15
00007583d7bd4167  movaps [rdx], xmm10
00007583d7bd416b  movaps [rcx], xmm1
00007583d7bd416e  mov rax, 0x5BCB7EA35A50
00007583d7bd4178  call rax
00007583d7bd417a  movaps xmm13, [rsp]
00007583d7bd417f  add rsp, 0x40
00007583d7bd4183  vmovaps xmm0, [rsp]
00007583d7bd4188  vmovaps xmm1, [rsp+0x10]
00007583d7bd418e  vmovaps xmm2, [rsp+0x20]
00007583d7bd4194  vmovaps xmm3, [rsp+0x30]
00007583d7bd419a  vmovaps xmm4, [rsp+0x40]
00007583d7bd41a0  vmovaps xmm5, [rsp+0x50]
00007583d7bd41a6  vmovaps xmm6, [rsp+0x60]
00007583d7bd41ac  vmovaps xmm7, [rsp+0x70]
00007583d7bd41b2  vmovaps xmm8, [rsp+0x80]
00007583d7bd41bb  vmovaps xmm9, [rsp+0x90]
00007583d7bd41c4  vmovaps xmm10, [rsp+0xA0]
00007583d7bd41cd  vmovaps xmm11, [rsp+0xB0]
00007583d7bd41d6  vmovaps xmm12, [rsp+0xC0]
00007583d7bd41df  vmovaps xmm14, [rsp+0xD0]
00007583d7bd41e8  vmovaps xmm15, [rsp+0xE0]
00007583d7bd41f1  add rsp, 0xF0
00007583d7bd41f8  pop r11
00007583d7bd41fa  pop r10
00007583d7bd41fc  pop r9
00007583d7bd41fe  pop r8
00007583d7bd4200  pop rsi
00007583d7bd4201  pop rdi
00007583d7bd4202  pop rdx
00007583d7bd4203  pop rcx
00007583d7bd4204  pop rax
00007583d7bd4205  add rsp, 0x08
00007583d7bd4209  jmp 0x00007583D7BD2D26
00007583d7bd420e  sub rsp, 0x08
00007583d7bd4212  push rax
00007583d7bd4213  push rcx
00007583d7bd4214  push rdx
00007583d7bd4215  push rdi
00007583d7bd4216  push rsi
00007583d7bd4217  push r8
00007583d7bd4219  push r9
00007583d7bd421b  push r10
00007583d7bd421d  push r11
00007583d7bd421f  sub rsp, 0xF0
00007583d7bd4226  vmovaps [rsp], xmm0
00007583d7bd422b  vmovaps [rsp+0x10], xmm1
00007583d7bd4231  vmovaps [rsp+0x20], xmm2
00007583d7bd4237  vmovaps [rsp+0x30], xmm3
00007583d7bd423d  vmovaps [rsp+0x40], xmm4
00007583d7bd4243  vmovaps [rsp+0x50], xmm5
00007583d7bd4249  vmovaps [rsp+0x60], xmm6
00007583d7bd424f  vmovaps [rsp+0x70], xmm7
00007583d7bd4255  vmovaps [rsp+0x80], xmm8
00007583d7bd425e  vmovaps [rsp+0x90], xmm9
00007583d7bd4267  vmovaps [rsp+0xA0], xmm11
00007583d7bd4270  vmovaps [rsp+0xB0], xmm12
00007583d7bd4279  vmovaps [rsp+0xC0], xmm13
00007583d7bd4282  vmovaps [rsp+0xD0], xmm14
00007583d7bd428b  vmovaps [rsp+0xE0], xmm15
00007583d7bd4294  sub rsp, 0x40
00007583d7bd4298  lea rdi, [rsp]
00007583d7bd429c  lea rsi, [rsp+0x10]
00007583d7bd42a1  lea rdx, [rsp+0x20]
00007583d7bd42a6  lea rcx, [rsp+0x30]
00007583d7bd42ab  mov r8d, 0x00
00007583d7bd42b1  lea r9, [r15+0x3A8]
00007583d7bd42b8  movaps [rdi], xmm10
00007583d7bd42bc  movaps [rsi], xmm15
00007583d7bd42c0  movaps [rdx], xmm11
00007583d7bd42c4  movaps [rcx], xmm1
00007583d7bd42c7  mov rax, 0x5BCB7EA35A50
00007583d7bd42d1  call rax
00007583d7bd42d3  movaps xmm10, [rsp]
00007583d7bd42d8  add rsp, 0x40
00007583d7bd42dc  vmovaps xmm0, [rsp]
00007583d7bd42e1  vmovaps xmm1, [rsp+0x10]
00007583d7bd42e7  vmovaps xmm2, [rsp+0x20]
00007583d7bd42ed  vmovaps xmm3, [rsp+0x30]
00007583d7bd42f3  vmovaps xmm4, [rsp+0x40]
00007583d7bd42f9  vmovaps xmm5, [rsp+0x50]
00007583d7bd42ff  vmovaps xmm6, [rsp+0x60]
00007583d7bd4305  vmovaps xmm7, [rsp+0x70]
00007583d7bd430b  vmovaps xmm8, [rsp+0x80]
00007583d7bd4314  vmovaps xmm9, [rsp+0x90]
00007583d7bd431d  vmovaps xmm11, [rsp+0xA0]
00007583d7bd4326  vmovaps xmm12, [rsp+0xB0]
00007583d7bd432f  vmovaps xmm13, [rsp+0xC0]
00007583d7bd4338  vmovaps xmm14, [rsp+0xD0]
00007583d7bd4341  vmovaps xmm15, [rsp+0xE0]
00007583d7bd434a  add rsp, 0xF0
00007583d7bd4351  pop r11
00007583d7bd4353  pop r10
00007583d7bd4355  pop r9
00007583d7bd4357  pop r8
00007583d7bd4359  pop rsi
00007583d7bd435a  pop rdi
00007583d7bd435b  pop rdx
00007583d7bd435c  pop rcx
00007583d7bd435d  pop rax
00007583d7bd435e  add rsp, 0x08
00007583d7bd4362  jmp 0x00007583D7BD2D55
00007583d7bd4367  sub rsp, 0x08
00007583d7bd436b  push rax
00007583d7bd436c  push rcx
00007583d7bd436d  push rdx
00007583d7bd436e  push rdi
00007583d7bd436f  push rsi
00007583d7bd4370  push r8
00007583d7bd4372  push r9
00007583d7bd4374  push r10
00007583d7bd4376  push r11
00007583d7bd4378  sub rsp, 0xF0
00007583d7bd437f  vmovaps [rsp], xmm0
00007583d7bd4384  vmovaps [rsp+0x10], xmm1
00007583d7bd438a  vmovaps [rsp+0x20], xmm2
00007583d7bd4390  vmovaps [rsp+0x30], xmm3
00007583d7bd4396  vmovaps [rsp+0x40], xmm4
00007583d7bd439c  vmovaps [rsp+0x50], xmm5
00007583d7bd43a2  vmovaps [rsp+0x60], xmm6
00007583d7bd43a8  vmovaps [rsp+0x70], xmm7
00007583d7bd43ae  vmovaps [rsp+0x80], xmm8
00007583d7bd43b7  vmovaps [rsp+0x90], xmm9
00007583d7bd43c0  vmovaps [rsp+0xA0], xmm10
00007583d7bd43c9  vmovaps [rsp+0xB0], xmm11
00007583d7bd43d2  vmovaps [rsp+0xC0], xmm12
00007583d7bd43db  vmovaps [rsp+0xD0], xmm13
00007583d7bd43e4  vmovaps [rsp+0xE0], xmm14
00007583d7bd43ed  sub rsp, 0x40
00007583d7bd43f1  lea rdi, [rsp]
00007583d7bd43f5  lea rsi, [rsp+0x10]
00007583d7bd43fa  lea rdx, [rsp+0x20]
00007583d7bd43ff  lea rcx, [rsp+0x30]
00007583d7bd4404  mov r8d, 0x00
00007583d7bd440a  lea r9, [r15+0x3A8]
00007583d7bd4411  movaps [rdi], xmm15
00007583d7bd4415  movaps [rsi], xmm12
00007583d7bd4419  movaps [rdx], xmm5
00007583d7bd441c  movaps [rcx], xmm1
00007583d7bd441f  mov rax, 0x5BCB7EA35A50
00007583d7bd4429  call rax
00007583d7bd442b  movaps xmm15, [rsp]
00007583d7bd4430  add rsp, 0x40
00007583d7bd4434  vmovaps xmm0, [rsp]
00007583d7bd4439  vmovaps xmm1, [rsp+0x10]
00007583d7bd443f  vmovaps xmm2, [rsp+0x20]
00007583d7bd4445  vmovaps xmm3, [rsp+0x30]
00007583d7bd444b  vmovaps xmm4, [rsp+0x40]
00007583d7bd4451  vmovaps xmm5, [rsp+0x50]
00007583d7bd4457  vmovaps xmm6, [rsp+0x60]
00007583d7bd445d  vmovaps xmm7, [rsp+0x70]
00007583d7bd4463  vmovaps xmm8, [rsp+0x80]
00007583d7bd446c  vmovaps xmm9, [rsp+0x90]
00007583d7bd4475  vmovaps xmm10, [rsp+0xA0]
00007583d7bd447e  vmovaps xmm11, [rsp+0xB0]
00007583d7bd4487  vmovaps xmm12, [rsp+0xC0]
00007583d7bd4490  vmovaps xmm13, [rsp+0xD0]
00007583d7bd4499  vmovaps xmm14, [rsp+0xE0]
00007583d7bd44a2  add rsp, 0xF0
00007583d7bd44a9  pop r11
00007583d7bd44ab  pop r10
00007583d7bd44ad  pop r9
00007583d7bd44af  pop r8
00007583d7bd44b1  pop rsi
00007583d7bd44b2  pop rdi
00007583d7bd44b3  pop rdx
00007583d7bd44b4  pop rcx
00007583d7bd44b5  pop rax
00007583d7bd44b6  add rsp, 0x08
00007583d7bd44ba  jmp 0x00007583D7BD2D7E
00007583d7bd44bf  sub rsp, 0x08
00007583d7bd44c3  push rax
00007583d7bd44c4  push rcx
00007583d7bd44c5  push rdx
00007583d7bd44c6  push rdi
00007583d7bd44c7  push rsi
00007583d7bd44c8  push r8
00007583d7bd44ca  push r9
00007583d7bd44cc  push r10
00007583d7bd44ce  push r11
00007583d7bd44d0  sub rsp, 0xF0
00007583d7bd44d7  vmovaps [rsp], xmm0
00007583d7bd44dc  vmovaps [rsp+0x10], xmm1
00007583d7bd44e2  vmovaps [rsp+0x20], xmm2
00007583d7bd44e8  vmovaps [rsp+0x30], xmm3
00007583d7bd44ee  vmovaps [rsp+0x40], xmm4
00007583d7bd44f4  vmovaps [rsp+0x50], xmm6
00007583d7bd44fa  vmovaps [rsp+0x60], xmm7
00007583d7bd4500  vmovaps [rsp+0x70], xmm8
00007583d7bd4506  vmovaps [rsp+0x80], xmm9
00007583d7bd450f  vmovaps [rsp+0x90], xmm10
00007583d7bd4518  vmovaps [rsp+0xA0], xmm11
00007583d7bd4521  vmovaps [rsp+0xB0], xmm12
00007583d7bd452a  vmovaps [rsp+0xC0], xmm13
00007583d7bd4533  vmovaps [rsp+0xD0], xmm14
00007583d7bd453c  vmovaps [rsp+0xE0], xmm15
00007583d7bd4545  sub rsp, 0x40
00007583d7bd4549  lea rdi, [rsp]
00007583d7bd454d  lea rsi, [rsp+0x10]
00007583d7bd4552  lea rdx, [rsp+0x20]
00007583d7bd4557  lea rcx, [rsp+0x30]
00007583d7bd455c  mov r8d, 0x00
00007583d7bd4562  lea r9, [r15+0x3A8]
00007583d7bd4569  movaps [rdi], xmm5
00007583d7bd456c  movaps [rsi], xmm13
00007583d7bd4570  movaps [rdx], xmm11
00007583d7bd4574  movaps [rcx], xmm12
00007583d7bd4578  mov rax, 0x5BCB7EA35A50
00007583d7bd4582  call rax
00007583d7bd4584  movaps xmm5, [rsp]
00007583d7bd4588  add rsp, 0x40
00007583d7bd458c  vmovaps xmm0, [rsp]
00007583d7bd4591  vmovaps xmm1, [rsp+0x10]
00007583d7bd4597  vmovaps xmm2, [rsp+0x20]
00007583d7bd459d  vmovaps xmm3, [rsp+0x30]
00007583d7bd45a3  vmovaps xmm4, [rsp+0x40]
00007583d7bd45a9  vmovaps xmm6, [rsp+0x50]
00007583d7bd45af  vmovaps xmm7, [rsp+0x60]
00007583d7bd45b5  vmovaps xmm8, [rsp+0x70]
00007583d7bd45bb  vmovaps xmm9, [rsp+0x80]
00007583d7bd45c4  vmovaps xmm10, [rsp+0x90]
00007583d7bd45cd  vmovaps xmm11, [rsp+0xA0]
00007583d7bd45d6  vmovaps xmm12, [rsp+0xB0]
00007583d7bd45df  vmovaps xmm13, [rsp+0xC0]
00007583d7bd45e8  vmovaps xmm14, [rsp+0xD0]
00007583d7bd45f1  vmovaps xmm15, [rsp+0xE0]
00007583d7bd45fa  add rsp, 0xF0
00007583d7bd4601  pop r11
00007583d7bd4603  pop r10
00007583d7bd4605  pop r9
00007583d7bd4607  pop r8
00007583d7bd4609  pop rsi
00007583d7bd460a  pop rdi
00007583d7bd460b  pop rdx
00007583d7bd460c  pop rcx
00007583d7bd460d  pop rax
00007583d7bd460e  add rsp, 0x08
00007583d7bd4612  jmp 0x00007583D7BD2DDD
00007583d7bd4617  sub rsp, 0x08
00007583d7bd461b  push rax
00007583d7bd461c  push rcx
00007583d7bd461d  push rdx
00007583d7bd461e  push rdi
00007583d7bd461f  push rsi
00007583d7bd4620  push r8
00007583d7bd4622  push r9
00007583d7bd4624  push r10
00007583d7bd4626  push r11
00007583d7bd4628  sub rsp, 0xF0
00007583d7bd462f  vmovaps [rsp], xmm0
00007583d7bd4634  vmovaps [rsp+0x10], xmm1
00007583d7bd463a  vmovaps [rsp+0x20], xmm2
00007583d7bd4640  vmovaps [rsp+0x30], xmm3
00007583d7bd4646  vmovaps [rsp+0x40], xmm4
00007583d7bd464c  vmovaps [rsp+0x50], xmm5
00007583d7bd4652  vmovaps [rsp+0x60], xmm6
00007583d7bd4658  vmovaps [rsp+0x70], xmm7
00007583d7bd465e  vmovaps [rsp+0x80], xmm8
00007583d7bd4667  vmovaps [rsp+0x90], xmm9
00007583d7bd4670  vmovaps [rsp+0xA0], xmm10
00007583d7bd4679  vmovaps [rsp+0xB0], xmm11
00007583d7bd4682  vmovaps [rsp+0xC0], xmm13
00007583d7bd468b  vmovaps [rsp+0xD0], xmm14
00007583d7bd4694  vmovaps [rsp+0xE0], xmm15
00007583d7bd469d  sub rsp, 0x40
00007583d7bd46a1  lea rdi, [rsp]
00007583d7bd46a5  lea rsi, [rsp+0x10]
00007583d7bd46aa  lea rdx, [rsp+0x20]
00007583d7bd46af  lea rcx, [rsp+0x30]
00007583d7bd46b4  mov r8d, 0x00
00007583d7bd46ba  lea r9, [r15+0x3A8]
00007583d7bd46c1  movaps [rdi], xmm12
00007583d7bd46c5  movaps [rsi], xmm14
00007583d7bd46c9  movaps [rdx], xmm9
00007583d7bd46cd  movaps [rcx], xmm13
00007583d7bd46d1  mov rax, 0x5BCB7EA35A50
00007583d7bd46db  call rax
00007583d7bd46dd  movaps xmm12, [rsp]
00007583d7bd46e2  add rsp, 0x40
00007583d7bd46e6  vmovaps xmm0, [rsp]
00007583d7bd46eb  vmovaps xmm1, [rsp+0x10]
00007583d7bd46f1  vmovaps xmm2, [rsp+0x20]
00007583d7bd46f7  vmovaps xmm3, [rsp+0x30]
00007583d7bd46fd  vmovaps xmm4, [rsp+0x40]
00007583d7bd4703  vmovaps xmm5, [rsp+0x50]
00007583d7bd4709  vmovaps xmm6, [rsp+0x60]
00007583d7bd470f  vmovaps xmm7, [rsp+0x70]
00007583d7bd4715  vmovaps xmm8, [rsp+0x80]
00007583d7bd471e  vmovaps xmm9, [rsp+0x90]
00007583d7bd4727  vmovaps xmm10, [rsp+0xA0]
00007583d7bd4730  vmovaps xmm11, [rsp+0xB0]
00007583d7bd4739  vmovaps xmm13, [rsp+0xC0]
00007583d7bd4742  vmovaps xmm14, [rsp+0xD0]
00007583d7bd474b  vmovaps xmm15, [rsp+0xE0]
00007583d7bd4754  add rsp, 0xF0
00007583d7bd475b  pop r11
00007583d7bd475d  pop r10
00007583d7bd475f  pop r9
00007583d7bd4761  pop r8
00007583d7bd4763  pop rsi
00007583d7bd4764  pop rdi
00007583d7bd4765  pop rdx
00007583d7bd4766  pop rcx
00007583d7bd4767  pop rax
00007583d7bd4768  add rsp, 0x08
00007583d7bd476c  jmp 0x00007583D7BD2E06
00007583d7bd4771  call 0x00007583D7A0D4E0
00007583d7bd4776  jmp 0x00007583D7BD2E13
00007583d7bd477b  sub rsp, 0x08
00007583d7bd477f  push rax
00007583d7bd4780  push rcx
00007583d7bd4781  push rdx
00007583d7bd4782  push rdi
00007583d7bd4783  push rsi
00007583d7bd4784  push r8
00007583d7bd4786  push r9
00007583d7bd4788  push r10
00007583d7bd478a  push r11
00007583d7bd478c  sub rsp, 0xF0
00007583d7bd4793  vmovaps [rsp], xmm0
00007583d7bd4798  vmovaps [rsp+0x10], xmm1
00007583d7bd479e  vmovaps [rsp+0x20], xmm2
00007583d7bd47a4  vmovaps [rsp+0x30], xmm3
00007583d7bd47aa  vmovaps [rsp+0x40], xmm4
00007583d7bd47b0  vmovaps [rsp+0x50], xmm5
00007583d7bd47b6  vmovaps [rsp+0x60], xmm6
00007583d7bd47bc  vmovaps [rsp+0x70], xmm7
00007583d7bd47c2  vmovaps [rsp+0x80], xmm8
00007583d7bd47cb  vmovaps [rsp+0x90], xmm9
00007583d7bd47d4  vmovaps [rsp+0xA0], xmm10
00007583d7bd47dd  vmovaps [rsp+0xB0], xmm12
00007583d7bd47e6  vmovaps [rsp+0xC0], xmm13
00007583d7bd47ef  vmovaps [rsp+0xD0], xmm14
00007583d7bd47f8  vmovaps [rsp+0xE0], xmm15
00007583d7bd4801  sub rsp, 0x40
00007583d7bd4805  lea rdi, [rsp]
00007583d7bd4809  lea rsi, [rsp+0x10]
00007583d7bd480e  lea rdx, [rsp+0x20]
00007583d7bd4813  lea rcx, [rsp+0x30]
00007583d7bd4818  mov r8d, 0x00
00007583d7bd481e  lea r9, [r15+0x3A8]
00007583d7bd4825  movaps [rdi], xmm11
00007583d7bd4829  movaps [rsi], xmm10
00007583d7bd482d  movaps [rdx], xmm8
00007583d7bd4831  movaps [rcx], xmm13
00007583d7bd4835  mov rax, 0x5BCB7EA35A50
00007583d7bd483f  call rax
00007583d7bd4841  movaps xmm11, [rsp]
00007583d7bd4846  add rsp, 0x40
00007583d7bd484a  vmovaps xmm0, [rsp]
00007583d7bd484f  vmovaps xmm1, [rsp+0x10]
00007583d7bd4855  vmovaps xmm2, [rsp+0x20]
00007583d7bd485b  vmovaps xmm3, [rsp+0x30]
00007583d7bd4861  vmovaps xmm4, [rsp+0x40]
00007583d7bd4867  vmovaps xmm5, [rsp+0x50]
00007583d7bd486d  vmovaps xmm6, [rsp+0x60]
00007583d7bd4873  vmovaps xmm7, [rsp+0x70]
00007583d7bd4879  vmovaps xmm8, [rsp+0x80]
00007583d7bd4882  vmovaps xmm9, [rsp+0x90]
00007583d7bd488b  vmovaps xmm10, [rsp+0xA0]
00007583d7bd4894  vmovaps xmm12, [rsp+0xB0]
00007583d7bd489d  vmovaps xmm13, [rsp+0xC0]
00007583d7bd48a6  vmovaps xmm14, [rsp+0xD0]
00007583d7bd48af  vmovaps xmm15, [rsp+0xE0]
00007583d7bd48b8  add rsp, 0xF0
00007583d7bd48bf  pop r11
00007583d7bd48c1  pop r10
00007583d7bd48c3  pop r9
00007583d7bd48c5  pop r8
00007583d7bd48c7  pop rsi
00007583d7bd48c8  pop rdi
00007583d7bd48c9  pop rdx
00007583d7bd48ca  pop rcx
00007583d7bd48cb  pop rax
00007583d7bd48cc  add rsp, 0x08
00007583d7bd48d0  jmp 0x00007583D7BD2E44
00007583d7bd48d5  sub rsp, 0x08
00007583d7bd48d9  push rax
00007583d7bd48da  push rcx
00007583d7bd48db  push rdx
00007583d7bd48dc  push rdi
00007583d7bd48dd  push rsi
00007583d7bd48de  push r8
00007583d7bd48e0  push r9
00007583d7bd48e2  push r10
00007583d7bd48e4  push r11
00007583d7bd48e6  sub rsp, 0xF0
00007583d7bd48ed  vmovaps [rsp], xmm0
00007583d7bd48f2  vmovaps [rsp+0x10], xmm1
00007583d7bd48f8  vmovaps [rsp+0x20], xmm2
00007583d7bd48fe  vmovaps [rsp+0x30], xmm3
00007583d7bd4904  vmovaps [rsp+0x40], xmm4
00007583d7bd490a  vmovaps [rsp+0x50], xmm5
00007583d7bd4910  vmovaps [rsp+0x60], xmm6
00007583d7bd4916  vmovaps [rsp+0x70], xmm7
00007583d7bd491c  vmovaps [rsp+0x80], xmm8
00007583d7bd4925  vmovaps [rsp+0x90], xmm9
00007583d7bd492e  vmovaps [rsp+0xA0], xmm11
00007583d7bd4937  vmovaps [rsp+0xB0], xmm12
00007583d7bd4940  vmovaps [rsp+0xC0], xmm13
00007583d7bd4949  vmovaps [rsp+0xD0], xmm14
00007583d7bd4952  vmovaps [rsp+0xE0], xmm15
00007583d7bd495b  sub rsp, 0x40
00007583d7bd495f  lea rdi, [rsp]
00007583d7bd4963  lea rsi, [rsp+0x10]
00007583d7bd4968  lea rdx, [rsp+0x20]
00007583d7bd496d  lea rcx, [rsp+0x30]
00007583d7bd4972  mov r8d, 0x00
00007583d7bd4978  lea r9, [r15+0x3A8]
00007583d7bd497f  movaps [rdi], xmm10
00007583d7bd4983  movaps [rsi], xmm15
00007583d7bd4987  movaps [rdx], xmm1
00007583d7bd498a  movaps [rcx], xmm13
00007583d7bd498e  mov rax, 0x5BCB7EA35A50
00007583d7bd4998  call rax
00007583d7bd499a  movaps xmm10, [rsp]
00007583d7bd499f  add rsp, 0x40
00007583d7bd49a3  vmovaps xmm0, [rsp]
00007583d7bd49a8  vmovaps xmm1, [rsp+0x10]
00007583d7bd49ae  vmovaps xmm2, [rsp+0x20]
00007583d7bd49b4  vmovaps xmm3, [rsp+0x30]
00007583d7bd49ba  vmovaps xmm4, [rsp+0x40]
00007583d7bd49c0  vmovaps xmm5, [rsp+0x50]
00007583d7bd49c6  vmovaps xmm6, [rsp+0x60]
00007583d7bd49cc  vmovaps xmm7, [rsp+0x70]
00007583d7bd49d2  vmovaps xmm8, [rsp+0x80]
00007583d7bd49db  vmovaps xmm9, [rsp+0x90]
00007583d7bd49e4  vmovaps xmm11, [rsp+0xA0]
00007583d7bd49ed  vmovaps xmm12, [rsp+0xB0]
00007583d7bd49f6  vmovaps xmm13, [rsp+0xC0]
00007583d7bd49ff  vmovaps xmm14, [rsp+0xD0]
00007583d7bd4a08  vmovaps xmm15, [rsp+0xE0]
00007583d7bd4a11  add rsp, 0xF0
00007583d7bd4a18  pop r11
00007583d7bd4a1a  pop r10
00007583d7bd4a1c  pop r9
00007583d7bd4a1e  pop r8
00007583d7bd4a20  pop rsi
00007583d7bd4a21  pop rdi
00007583d7bd4a22  pop rdx
00007583d7bd4a23  pop rcx
00007583d7bd4a24  pop rax
00007583d7bd4a25  add rsp, 0x08
00007583d7bd4a29  jmp 0x00007583D7BD2E6D
00007583d7bd4a2e  call 0x00007583D79FF430
00007583d7bd4a33  jmp 0x00007583D7BD2E8F
00007583d7bd4a38  call 0x00007583D7A0E760
00007583d7bd4a3d  jmp 0x00007583D7BD2E99
00007583d7bd4a42  sub rsp, 0x08
00007583d7bd4a46  push rax
00007583d7bd4a47  push rcx
00007583d7bd4a48  push rdx
00007583d7bd4a49  push rdi
00007583d7bd4a4a  push rsi
00007583d7bd4a4b  push r8
00007583d7bd4a4d  push r9
00007583d7bd4a4f  push r10
00007583d7bd4a51  push r11
00007583d7bd4a53  sub rsp, 0xF0
00007583d7bd4a5a  vmovaps [rsp], xmm0
00007583d7bd4a5f  vmovaps [rsp+0x10], xmm1
00007583d7bd4a65  vmovaps [rsp+0x20], xmm2
00007583d7bd4a6b  vmovaps [rsp+0x30], xmm3
00007583d7bd4a71  vmovaps [rsp+0x40], xmm4
00007583d7bd4a77  vmovaps [rsp+0x50], xmm5
00007583d7bd4a7d  vmovaps [rsp+0x60], xmm6
00007583d7bd4a83  vmovaps [rsp+0x70], xmm7
00007583d7bd4a89  vmovaps [rsp+0x80], xmm9
00007583d7bd4a92  vmovaps [rsp+0x90], xmm10
00007583d7bd4a9b  vmovaps [rsp+0xA0], xmm11
00007583d7bd4aa4  vmovaps [rsp+0xB0], xmm12
00007583d7bd4aad  vmovaps [rsp+0xC0], xmm13
00007583d7bd4ab6  vmovaps [rsp+0xD0], xmm14
00007583d7bd4abf  vmovaps [rsp+0xE0], xmm15
00007583d7bd4ac8  sub rsp, 0x40
00007583d7bd4acc  lea rdi, [rsp]
00007583d7bd4ad0  lea rsi, [rsp+0x10]
00007583d7bd4ad5  lea rdx, [rsp+0x20]
00007583d7bd4ada  lea rcx, [rsp+0x30]
00007583d7bd4adf  mov r8d, 0x00
00007583d7bd4ae5  lea r9, [r15+0x3A8]
00007583d7bd4aec  movaps [rdi], xmm8
00007583d7bd4af0  movaps [rsi], xmm5
00007583d7bd4af3  movaps [rdx], xmm9
00007583d7bd4af7  movaps [rcx], xmm13
00007583d7bd4afb  mov rax, 0x5BCB7EA35A50
00007583d7bd4b05  call rax
00007583d7bd4b07  movaps xmm8, [rsp]
00007583d7bd4b0c  add rsp, 0x40
00007583d7bd4b10  vmovaps xmm0, [rsp]
00007583d7bd4b15  vmovaps xmm1, [rsp+0x10]
00007583d7bd4b1b  vmovaps xmm2, [rsp+0x20]
00007583d7bd4b21  vmovaps xmm3, [rsp+0x30]
00007583d7bd4b27  vmovaps xmm4, [rsp+0x40]
00007583d7bd4b2d  vmovaps xmm5, [rsp+0x50]
00007583d7bd4b33  vmovaps xmm6, [rsp+0x60]
00007583d7bd4b39  vmovaps xmm7, [rsp+0x70]
00007583d7bd4b3f  vmovaps xmm9, [rsp+0x80]
00007583d7bd4b48  vmovaps xmm10, [rsp+0x90]
00007583d7bd4b51  vmovaps xmm11, [rsp+0xA0]
00007583d7bd4b5a  vmovaps xmm12, [rsp+0xB0]
00007583d7bd4b63  vmovaps xmm13, [rsp+0xC0]
00007583d7bd4b6c  vmovaps xmm14, [rsp+0xD0]
00007583d7bd4b75  vmovaps xmm15, [rsp+0xE0]
00007583d7bd4b7e  add rsp, 0xF0
00007583d7bd4b85  pop r11
00007583d7bd4b87  pop r10
00007583d7bd4b89  pop r9
00007583d7bd4b8b  pop r8
00007583d7bd4b8d  pop rsi
00007583d7bd4b8e  pop rdi
00007583d7bd4b8f  pop rdx
00007583d7bd4b90  pop rcx
00007583d7bd4b91  pop rax
00007583d7bd4b92  add rsp, 0x08
00007583d7bd4b96  jmp 0x00007583D7BD2ED8
00007583d7bd4b9b  sub rsp, 0x08
00007583d7bd4b9f  push rax
00007583d7bd4ba0  push rcx
00007583d7bd4ba1  push rdx
00007583d7bd4ba2  push rdi
00007583d7bd4ba3  push rsi
00007583d7bd4ba4  push r8
00007583d7bd4ba6  push r9
00007583d7bd4ba8  push r10
00007583d7bd4baa  push r11
00007583d7bd4bac  sub rsp, 0xF0
00007583d7bd4bb3  vmovaps [rsp], xmm0
00007583d7bd4bb8  vmovaps [rsp+0x10], xmm1
00007583d7bd4bbe  vmovaps [rsp+0x20], xmm2
00007583d7bd4bc4  vmovaps [rsp+0x30], xmm3
00007583d7bd4bca  vmovaps [rsp+0x40], xmm4
00007583d7bd4bd0  vmovaps [rsp+0x50], xmm5
00007583d7bd4bd6  vmovaps [rsp+0x60], xmm6
00007583d7bd4bdc  vmovaps [rsp+0x70], xmm7
00007583d7bd4be2  vmovaps [rsp+0x80], xmm8
00007583d7bd4beb  vmovaps [rsp+0x90], xmm10
00007583d7bd4bf4  vmovaps [rsp+0xA0], xmm11
00007583d7bd4bfd  vmovaps [rsp+0xB0], xmm12
00007583d7bd4c06  vmovaps [rsp+0xC0], xmm13
00007583d7bd4c0f  vmovaps [rsp+0xD0], xmm14
00007583d7bd4c18  vmovaps [rsp+0xE0], xmm15
00007583d7bd4c21  sub rsp, 0x40
00007583d7bd4c25  lea rdi, [rsp]
00007583d7bd4c29  lea rsi, [rsp+0x10]
00007583d7bd4c2e  lea rdx, [rsp+0x20]
00007583d7bd4c33  lea rcx, [rsp+0x30]
00007583d7bd4c38  mov r8d, 0x00
00007583d7bd4c3e  lea r9, [r15+0x3A8]
00007583d7bd4c45  movaps [rdi], xmm9
00007583d7bd4c49  movaps [rsi], xmm12
00007583d7bd4c4d  movaps [rdx], xmm7
00007583d7bd4c50  movaps [rcx], xmm13
00007583d7bd4c54  mov rax, 0x5BCB7EA35A50
00007583d7bd4c5e  call rax
00007583d7bd4c60  movaps xmm9, [rsp]
00007583d7bd4c65  add rsp, 0x40
00007583d7bd4c69  vmovaps xmm0, [rsp]
00007583d7bd4c6e  vmovaps xmm1, [rsp+0x10]
00007583d7bd4c74  vmovaps xmm2, [rsp+0x20]
00007583d7bd4c7a  vmovaps xmm3, [rsp+0x30]
00007583d7bd4c80  vmovaps xmm4, [rsp+0x40]
00007583d7bd4c86  vmovaps xmm5, [rsp+0x50]
00007583d7bd4c8c  vmovaps xmm6, [rsp+0x60]
00007583d7bd4c92  vmovaps xmm7, [rsp+0x70]
00007583d7bd4c98  vmovaps xmm8, [rsp+0x80]
00007583d7bd4ca1  vmovaps xmm10, [rsp+0x90]
00007583d7bd4caa  vmovaps xmm11, [rsp+0xA0]
00007583d7bd4cb3  vmovaps xmm12, [rsp+0xB0]
00007583d7bd4cbc  vmovaps xmm13, [rsp+0xC0]
00007583d7bd4cc5  vmovaps xmm14, [rsp+0xD0]
00007583d7bd4cce  vmovaps xmm15, [rsp+0xE0]
00007583d7bd4cd7  add rsp, 0xF0
00007583d7bd4cde  pop r11
00007583d7bd4ce0  pop r10
00007583d7bd4ce2  pop r9
00007583d7bd4ce4  pop r8
00007583d7bd4ce6  pop rsi
00007583d7bd4ce7  pop rdi
00007583d7bd4ce8  pop rdx
00007583d7bd4ce9  pop rcx
00007583d7bd4cea  pop rax
00007583d7bd4ceb  add rsp, 0x08
00007583d7bd4cef  jmp 0x00007583D7BD2F01
00007583d7bd4cf4  sub rsp, 0x08
00007583d7bd4cf8  push rax
00007583d7bd4cf9  push rcx
00007583d7bd4cfa  push rdx
00007583d7bd4cfb  push rdi
00007583d7bd4cfc  push rsi
00007583d7bd4cfd  push r8
00007583d7bd4cff  push r9
00007583d7bd4d01  push r10
00007583d7bd4d03  push r11
00007583d7bd4d05  sub rsp, 0xF0
00007583d7bd4d0c  vmovaps [rsp], xmm0
00007583d7bd4d11  vmovaps [rsp+0x10], xmm1
00007583d7bd4d17  vmovaps [rsp+0x20], xmm2
00007583d7bd4d1d  vmovaps [rsp+0x30], xmm3
00007583d7bd4d23  vmovaps [rsp+0x40], xmm4
00007583d7bd4d29  vmovaps [rsp+0x50], xmm5
00007583d7bd4d2f  vmovaps [rsp+0x60], xmm6
00007583d7bd4d35  vmovaps [rsp+0x70], xmm7
00007583d7bd4d3b  vmovaps [rsp+0x80], xmm8
00007583d7bd4d44  vmovaps [rsp+0x90], xmm9
00007583d7bd4d4d  vmovaps [rsp+0xA0], xmm10
00007583d7bd4d56  vmovaps [rsp+0xB0], xmm11
00007583d7bd4d5f  vmovaps [rsp+0xC0], xmm13
00007583d7bd4d68  vmovaps [rsp+0xD0], xmm14
00007583d7bd4d71  vmovaps [rsp+0xE0], xmm15
00007583d7bd4d7a  sub rsp, 0x40
00007583d7bd4d7e  lea rdi, [rsp]
00007583d7bd4d82  lea rsi, [rsp+0x10]
00007583d7bd4d87  lea rdx, [rsp+0x20]
00007583d7bd4d8c  lea rcx, [rsp+0x30]
00007583d7bd4d91  mov r8d, 0x00
00007583d7bd4d97  lea r9, [r15+0x3A8]
00007583d7bd4d9e  movaps [rdi], xmm12
00007583d7bd4da2  movaps [rsi], xmm11
00007583d7bd4da6  movaps [rdx], xmm6
00007583d7bd4da9  movaps [rcx], xmm13
00007583d7bd4dad  mov rax, 0x5BCB7EA35A50
00007583d7bd4db7  call rax
00007583d7bd4db9  movaps xmm12, [rsp]
00007583d7bd4dbe  add rsp, 0x40
00007583d7bd4dc2  vmovaps xmm0, [rsp]
00007583d7bd4dc7  vmovaps xmm1, [rsp+0x10]
00007583d7bd4dcd  vmovaps xmm2, [rsp+0x20]
00007583d7bd4dd3  vmovaps xmm3, [rsp+0x30]
00007583d7bd4dd9  vmovaps xmm4, [rsp+0x40]
00007583d7bd4ddf  vmovaps xmm5, [rsp+0x50]
00007583d7bd4de5  vmovaps xmm6, [rsp+0x60]
00007583d7bd4deb  vmovaps xmm7, [rsp+0x70]
00007583d7bd4df1  vmovaps xmm8, [rsp+0x80]
00007583d7bd4dfa  vmovaps xmm9, [rsp+0x90]
00007583d7bd4e03  vmovaps xmm10, [rsp+0xA0]
00007583d7bd4e0c  vmovaps xmm11, [rsp+0xB0]
00007583d7bd4e15  vmovaps xmm13, [rsp+0xC0]
00007583d7bd4e1e  vmovaps xmm14, [rsp+0xD0]
00007583d7bd4e27  vmovaps xmm15, [rsp+0xE0]
00007583d7bd4e30  add rsp, 0xF0
00007583d7bd4e37  pop r11
00007583d7bd4e39  pop r10
00007583d7bd4e3b  pop r9
00007583d7bd4e3d  pop r8
00007583d7bd4e3f  pop rsi
00007583d7bd4e40  pop rdi
00007583d7bd4e41  pop rdx
00007583d7bd4e42  pop rcx
00007583d7bd4e43  pop rax
00007583d7bd4e44  add rsp, 0x08
00007583d7bd4e48  jmp 0x00007583D7BD2F2A
00007583d7bd4e4d  sub rsp, 0x08
00007583d7bd4e51  push rax
00007583d7bd4e52  push rcx
00007583d7bd4e53  push rdx
00007583d7bd4e54  push rdi
00007583d7bd4e55  push rsi
00007583d7bd4e56  push r8
00007583d7bd4e58  push r9
00007583d7bd4e5a  push r10
00007583d7bd4e5c  push r11
00007583d7bd4e5e  sub rsp, 0xF0
00007583d7bd4e65  vmovaps [rsp], xmm0
00007583d7bd4e6a  vmovaps [rsp+0x10], xmm1
00007583d7bd4e70  vmovaps [rsp+0x20], xmm2
00007583d7bd4e76  vmovaps [rsp+0x30], xmm3
00007583d7bd4e7c  vmovaps [rsp+0x40], xmm4
00007583d7bd4e82  vmovaps [rsp+0x50], xmm5
00007583d7bd4e88  vmovaps [rsp+0x60], xmm6
00007583d7bd4e8e  vmovaps [rsp+0x70], xmm8
00007583d7bd4e94  vmovaps [rsp+0x80], xmm9
00007583d7bd4e9d  vmovaps [rsp+0x90], xmm10
00007583d7bd4ea6  vmovaps [rsp+0xA0], xmm11
00007583d7bd4eaf  vmovaps [rsp+0xB0], xmm12
00007583d7bd4eb8  vmovaps [rsp+0xC0], xmm13
00007583d7bd4ec1  vmovaps [rsp+0xD0], xmm14
00007583d7bd4eca  vmovaps [rsp+0xE0], xmm15
00007583d7bd4ed3  sub rsp, 0x40
00007583d7bd4ed7  lea rdi, [rsp]
00007583d7bd4edb  lea rsi, [rsp+0x10]
00007583d7bd4ee0  lea rdx, [rsp+0x20]
00007583d7bd4ee5  lea rcx, [rsp+0x30]
00007583d7bd4eea  mov r8d, 0x00
00007583d7bd4ef0  lea r9, [r15+0x3A8]
00007583d7bd4ef7  movaps [rdi], xmm7
00007583d7bd4efa  movaps [rsi], xmm10
00007583d7bd4efe  movaps [rdx], xmm11
00007583d7bd4f02  movaps [rcx], xmm13
00007583d7bd4f06  mov rax, 0x5BCB7EA35A50
00007583d7bd4f10  call rax
00007583d7bd4f12  movaps xmm7, [rsp]
00007583d7bd4f16  add rsp, 0x40
00007583d7bd4f1a  vmovaps xmm0, [rsp]
00007583d7bd4f1f  vmovaps xmm1, [rsp+0x10]
00007583d7bd4f25  vmovaps xmm2, [rsp+0x20]
00007583d7bd4f2b  vmovaps xmm3, [rsp+0x30]
00007583d7bd4f31  vmovaps xmm4, [rsp+0x40]
00007583d7bd4f37  vmovaps xmm5, [rsp+0x50]
00007583d7bd4f3d  vmovaps xmm6, [rsp+0x60]
00007583d7bd4f43  vmovaps xmm8, [rsp+0x70]
00007583d7bd4f49  vmovaps xmm9, [rsp+0x80]
00007583d7bd4f52  vmovaps xmm10, [rsp+0x90]
00007583d7bd4f5b  vmovaps xmm11, [rsp+0xA0]
00007583d7bd4f64  vmovaps xmm12, [rsp+0xB0]
00007583d7bd4f6d  vmovaps xmm13, [rsp+0xC0]
00007583d7bd4f76  vmovaps xmm14, [rsp+0xD0]
00007583d7bd4f7f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd4f88  add rsp, 0xF0
00007583d7bd4f8f  pop r11
00007583d7bd4f91  pop r10
00007583d7bd4f93  pop r9
00007583d7bd4f95  pop r8
00007583d7bd4f97  pop rsi
00007583d7bd4f98  pop rdi
00007583d7bd4f99  pop rdx
00007583d7bd4f9a  pop rcx
00007583d7bd4f9b  pop rax
00007583d7bd4f9c  add rsp, 0x08
00007583d7bd4fa0  jmp 0x00007583D7BD2F58
00007583d7bd4fa5  call 0x00007583D7A0C260
00007583d7bd4faa  jmp 0x00007583D7BD2F62
00007583d7bd4faf  call 0x00007583D7A09D70
00007583d7bd4fb4  jmp 0x00007583D7BD2F6C
00007583d7bd4fb9  sub rsp, 0x08
00007583d7bd4fbd  push rax
00007583d7bd4fbe  push rcx
00007583d7bd4fbf  push rdx
00007583d7bd4fc0  push rdi
00007583d7bd4fc1  push rsi
00007583d7bd4fc2  push r8
00007583d7bd4fc4  push r9
00007583d7bd4fc6  push r10
00007583d7bd4fc8  push r11
00007583d7bd4fca  sub rsp, 0xF0
00007583d7bd4fd1  vmovaps [rsp], xmm0
00007583d7bd4fd6  vmovaps [rsp+0x10], xmm1
00007583d7bd4fdc  vmovaps [rsp+0x20], xmm2
00007583d7bd4fe2  vmovaps [rsp+0x30], xmm3
00007583d7bd4fe8  vmovaps [rsp+0x40], xmm4
00007583d7bd4fee  vmovaps [rsp+0x50], xmm5
00007583d7bd4ff4  vmovaps [rsp+0x60], xmm7
00007583d7bd4ffa  vmovaps [rsp+0x70], xmm8
00007583d7bd5000  vmovaps [rsp+0x80], xmm9
00007583d7bd5009  vmovaps [rsp+0x90], xmm10
00007583d7bd5012  vmovaps [rsp+0xA0], xmm11
00007583d7bd501b  vmovaps [rsp+0xB0], xmm12
00007583d7bd5024  vmovaps [rsp+0xC0], xmm13
00007583d7bd502d  vmovaps [rsp+0xD0], xmm14
00007583d7bd5036  vmovaps [rsp+0xE0], xmm15
00007583d7bd503f  sub rsp, 0x40
00007583d7bd5043  lea rdi, [rsp]
00007583d7bd5047  lea rsi, [rsp+0x10]
00007583d7bd504c  lea rdx, [rsp+0x20]
00007583d7bd5051  lea rcx, [rsp+0x30]
00007583d7bd5056  mov r8d, 0x00
00007583d7bd505c  lea r9, [r15+0x3A8]
00007583d7bd5063  movaps [rdi], xmm6
00007583d7bd5066  movaps [rsi], xmm8
00007583d7bd506a  movaps [rdx], xmm15
00007583d7bd506e  movaps [rcx], xmm10
00007583d7bd5072  mov rax, 0x5BCB7EA35A50
00007583d7bd507c  call rax
00007583d7bd507e  movaps xmm6, [rsp]
00007583d7bd5082  add rsp, 0x40
00007583d7bd5086  vmovaps xmm0, [rsp]
00007583d7bd508b  vmovaps xmm1, [rsp+0x10]
00007583d7bd5091  vmovaps xmm2, [rsp+0x20]
00007583d7bd5097  vmovaps xmm3, [rsp+0x30]
00007583d7bd509d  vmovaps xmm4, [rsp+0x40]
00007583d7bd50a3  vmovaps xmm5, [rsp+0x50]
00007583d7bd50a9  vmovaps xmm7, [rsp+0x60]
00007583d7bd50af  vmovaps xmm8, [rsp+0x70]
00007583d7bd50b5  vmovaps xmm9, [rsp+0x80]
00007583d7bd50be  vmovaps xmm10, [rsp+0x90]
00007583d7bd50c7  vmovaps xmm11, [rsp+0xA0]
00007583d7bd50d0  vmovaps xmm12, [rsp+0xB0]
00007583d7bd50d9  vmovaps xmm13, [rsp+0xC0]
00007583d7bd50e2  vmovaps xmm14, [rsp+0xD0]
00007583d7bd50eb  vmovaps xmm15, [rsp+0xE0]
00007583d7bd50f4  add rsp, 0xF0
00007583d7bd50fb  pop r11
00007583d7bd50fd  pop r10
00007583d7bd50ff  pop r9
00007583d7bd5101  pop r8
00007583d7bd5103  pop rsi
00007583d7bd5104  pop rdi
00007583d7bd5105  pop rdx
00007583d7bd5106  pop rcx
00007583d7bd5107  pop rax
00007583d7bd5108  add rsp, 0x08
00007583d7bd510c  jmp 0x00007583D7BD2FA4
00007583d7bd5111  sub rsp, 0x08
00007583d7bd5115  push rax
00007583d7bd5116  push rcx
00007583d7bd5117  push rdx
00007583d7bd5118  push rdi
00007583d7bd5119  push rsi
00007583d7bd511a  push r8
00007583d7bd511c  push r9
00007583d7bd511e  push r10
00007583d7bd5120  push r11
00007583d7bd5122  sub rsp, 0xF0
00007583d7bd5129  vmovaps [rsp], xmm0
00007583d7bd512e  vmovaps [rsp+0x10], xmm1
00007583d7bd5134  vmovaps [rsp+0x20], xmm2
00007583d7bd513a  vmovaps [rsp+0x30], xmm3
00007583d7bd5140  vmovaps [rsp+0x40], xmm4
00007583d7bd5146  vmovaps [rsp+0x50], xmm5
00007583d7bd514c  vmovaps [rsp+0x60], xmm6
00007583d7bd5152  vmovaps [rsp+0x70], xmm7
00007583d7bd5158  vmovaps [rsp+0x80], xmm8
00007583d7bd5161  vmovaps [rsp+0x90], xmm9
00007583d7bd516a  vmovaps [rsp+0xA0], xmm11
00007583d7bd5173  vmovaps [rsp+0xB0], xmm12
00007583d7bd517c  vmovaps [rsp+0xC0], xmm13
00007583d7bd5185  vmovaps [rsp+0xD0], xmm14
00007583d7bd518e  vmovaps [rsp+0xE0], xmm15
00007583d7bd5197  sub rsp, 0x40
00007583d7bd519b  lea rdi, [rsp]
00007583d7bd519f  lea rsi, [rsp+0x10]
00007583d7bd51a4  lea rdx, [rsp+0x20]
00007583d7bd51a9  lea rcx, [rsp+0x30]
00007583d7bd51ae  mov r8d, 0x00
00007583d7bd51b4  lea r9, [r15+0x3A8]
00007583d7bd51bb  movaps [rdi], xmm10
00007583d7bd51bf  movaps [rsi], xmm9
00007583d7bd51c3  movaps [rdx], xmm13
00007583d7bd51c7  movaps [rcx], xmm15
00007583d7bd51cb  mov rax, 0x5BCB7EA35A50
00007583d7bd51d5  call rax
00007583d7bd51d7  movaps xmm10, [rsp]
00007583d7bd51dc  add rsp, 0x40
00007583d7bd51e0  vmovaps xmm0, [rsp]
00007583d7bd51e5  vmovaps xmm1, [rsp+0x10]
00007583d7bd51eb  vmovaps xmm2, [rsp+0x20]
00007583d7bd51f1  vmovaps xmm3, [rsp+0x30]
00007583d7bd51f7  vmovaps xmm4, [rsp+0x40]
00007583d7bd51fd  vmovaps xmm5, [rsp+0x50]
00007583d7bd5203  vmovaps xmm6, [rsp+0x60]
00007583d7bd5209  vmovaps xmm7, [rsp+0x70]
00007583d7bd520f  vmovaps xmm8, [rsp+0x80]
00007583d7bd5218  vmovaps xmm9, [rsp+0x90]
00007583d7bd5221  vmovaps xmm11, [rsp+0xA0]
00007583d7bd522a  vmovaps xmm12, [rsp+0xB0]
00007583d7bd5233  vmovaps xmm13, [rsp+0xC0]
00007583d7bd523c  vmovaps xmm14, [rsp+0xD0]
00007583d7bd5245  vmovaps xmm15, [rsp+0xE0]
00007583d7bd524e  add rsp, 0xF0
00007583d7bd5255  pop r11
00007583d7bd5257  pop r10
00007583d7bd5259  pop r9
00007583d7bd525b  pop r8
00007583d7bd525d  pop rsi
00007583d7bd525e  pop rdi
00007583d7bd525f  pop rdx
00007583d7bd5260  pop rcx
00007583d7bd5261  pop rax
00007583d7bd5262  add rsp, 0x08
00007583d7bd5266  jmp 0x00007583D7BD2FCD
00007583d7bd526b  sub rsp, 0x08
00007583d7bd526f  push rax
00007583d7bd5270  push rcx
00007583d7bd5271  push rdx
00007583d7bd5272  push rdi
00007583d7bd5273  push rsi
00007583d7bd5274  push r8
00007583d7bd5276  push r9
00007583d7bd5278  push r10
00007583d7bd527a  push r11
00007583d7bd527c  sub rsp, 0xF0
00007583d7bd5283  vmovaps [rsp], xmm0
00007583d7bd5288  vmovaps [rsp+0x10], xmm1
00007583d7bd528e  vmovaps [rsp+0x20], xmm2
00007583d7bd5294  vmovaps [rsp+0x30], xmm3
00007583d7bd529a  vmovaps [rsp+0x40], xmm4
00007583d7bd52a0  vmovaps [rsp+0x50], xmm5
00007583d7bd52a6  vmovaps [rsp+0x60], xmm6
00007583d7bd52ac  vmovaps [rsp+0x70], xmm7
00007583d7bd52b2  vmovaps [rsp+0x80], xmm8
00007583d7bd52bb  vmovaps [rsp+0x90], xmm9
00007583d7bd52c4  vmovaps [rsp+0xA0], xmm10
00007583d7bd52cd  vmovaps [rsp+0xB0], xmm11
00007583d7bd52d6  vmovaps [rsp+0xC0], xmm12
00007583d7bd52df  vmovaps [rsp+0xD0], xmm14
00007583d7bd52e8  vmovaps [rsp+0xE0], xmm15
00007583d7bd52f1  sub rsp, 0x40
00007583d7bd52f5  lea rdi, [rsp]
00007583d7bd52f9  lea rsi, [rsp+0x10]
00007583d7bd52fe  lea rdx, [rsp+0x20]
00007583d7bd5303  lea rcx, [rsp+0x30]
00007583d7bd5308  mov r8d, 0x00
00007583d7bd530e  lea r9, [r15+0x3A8]
00007583d7bd5315  movaps [rdi], xmm13
00007583d7bd5319  movaps [rsi], xmm12
00007583d7bd531d  movaps [rdx], xmm4
00007583d7bd5320  movaps [rcx], xmm15
00007583d7bd5324  mov rax, 0x5BCB7EA35A50
00007583d7bd532e  call rax
00007583d7bd5330  movaps xmm13, [rsp]
00007583d7bd5335  add rsp, 0x40
00007583d7bd5339  vmovaps xmm0, [rsp]
00007583d7bd533e  vmovaps xmm1, [rsp+0x10]
00007583d7bd5344  vmovaps xmm2, [rsp+0x20]
00007583d7bd534a  vmovaps xmm3, [rsp+0x30]
00007583d7bd5350  vmovaps xmm4, [rsp+0x40]
00007583d7bd5356  vmovaps xmm5, [rsp+0x50]
00007583d7bd535c  vmovaps xmm6, [rsp+0x60]
00007583d7bd5362  vmovaps xmm7, [rsp+0x70]
00007583d7bd5368  vmovaps xmm8, [rsp+0x80]
00007583d7bd5371  vmovaps xmm9, [rsp+0x90]
00007583d7bd537a  vmovaps xmm10, [rsp+0xA0]
00007583d7bd5383  vmovaps xmm11, [rsp+0xB0]
00007583d7bd538c  vmovaps xmm12, [rsp+0xC0]
00007583d7bd5395  vmovaps xmm14, [rsp+0xD0]
00007583d7bd539e  vmovaps xmm15, [rsp+0xE0]
00007583d7bd53a7  add rsp, 0xF0
00007583d7bd53ae  pop r11
00007583d7bd53b0  pop r10
00007583d7bd53b2  pop r9
00007583d7bd53b4  pop r8
00007583d7bd53b6  pop rsi
00007583d7bd53b7  pop rdi
00007583d7bd53b8  pop rdx
00007583d7bd53b9  pop rcx
00007583d7bd53ba  pop rax
00007583d7bd53bb  add rsp, 0x08
00007583d7bd53bf  jmp 0x00007583D7BD2FF6
00007583d7bd53c4  sub rsp, 0x08
00007583d7bd53c8  push rax
00007583d7bd53c9  push rcx
00007583d7bd53ca  push rdx
00007583d7bd53cb  push rdi
00007583d7bd53cc  push rsi
00007583d7bd53cd  push r8
00007583d7bd53cf  push r9
00007583d7bd53d1  push r10
00007583d7bd53d3  push r11
00007583d7bd53d5  sub rsp, 0xF0
00007583d7bd53dc  vmovaps [rsp], xmm0
00007583d7bd53e1  vmovaps [rsp+0x10], xmm1
00007583d7bd53e7  vmovaps [rsp+0x20], xmm2
00007583d7bd53ed  vmovaps [rsp+0x30], xmm3
00007583d7bd53f3  vmovaps [rsp+0x40], xmm4
00007583d7bd53f9  vmovaps [rsp+0x50], xmm5
00007583d7bd53ff  vmovaps [rsp+0x60], xmm6
00007583d7bd5405  vmovaps [rsp+0x70], xmm7
00007583d7bd540b  vmovaps [rsp+0x80], xmm8
00007583d7bd5414  vmovaps [rsp+0x90], xmm9
00007583d7bd541d  vmovaps [rsp+0xA0], xmm10
00007583d7bd5426  vmovaps [rsp+0xB0], xmm11
00007583d7bd542f  vmovaps [rsp+0xC0], xmm13
00007583d7bd5438  vmovaps [rsp+0xD0], xmm14
00007583d7bd5441  vmovaps [rsp+0xE0], xmm15
00007583d7bd544a  sub rsp, 0x40
00007583d7bd544e  lea rdi, [rsp]
00007583d7bd5452  lea rsi, [rsp+0x10]
00007583d7bd5457  lea rdx, [rsp+0x20]
00007583d7bd545c  lea rcx, [rsp+0x30]
00007583d7bd5461  mov r8d, 0x00
00007583d7bd5467  lea r9, [r15+0x3A8]
00007583d7bd546e  movaps [rdi], xmm12
00007583d7bd5472  movaps [rsi], xmm7
00007583d7bd5475  movaps [rdx], xmm1
00007583d7bd5478  movaps [rcx], xmm15
00007583d7bd547c  mov rax, 0x5BCB7EA35A50
00007583d7bd5486  call rax
00007583d7bd5488  movaps xmm12, [rsp]
00007583d7bd548d  add rsp, 0x40
00007583d7bd5491  vmovaps xmm0, [rsp]
00007583d7bd5496  vmovaps xmm1, [rsp+0x10]
00007583d7bd549c  vmovaps xmm2, [rsp+0x20]
00007583d7bd54a2  vmovaps xmm3, [rsp+0x30]
00007583d7bd54a8  vmovaps xmm4, [rsp+0x40]
00007583d7bd54ae  vmovaps xmm5, [rsp+0x50]
00007583d7bd54b4  vmovaps xmm6, [rsp+0x60]
00007583d7bd54ba  vmovaps xmm7, [rsp+0x70]
00007583d7bd54c0  vmovaps xmm8, [rsp+0x80]
00007583d7bd54c9  vmovaps xmm9, [rsp+0x90]
00007583d7bd54d2  vmovaps xmm10, [rsp+0xA0]
00007583d7bd54db  vmovaps xmm11, [rsp+0xB0]
00007583d7bd54e4  vmovaps xmm13, [rsp+0xC0]
00007583d7bd54ed  vmovaps xmm14, [rsp+0xD0]
00007583d7bd54f6  vmovaps xmm15, [rsp+0xE0]
00007583d7bd54ff  add rsp, 0xF0
00007583d7bd5506  pop r11
00007583d7bd5508  pop r10
00007583d7bd550a  pop r9
00007583d7bd550c  pop r8
00007583d7bd550e  pop rsi
00007583d7bd550f  pop rdi
00007583d7bd5510  pop rdx
00007583d7bd5511  pop rcx
00007583d7bd5512  pop rax
00007583d7bd5513  add rsp, 0x08
00007583d7bd5517  jmp 0x00007583D7BD301F
00007583d7bd551c  call 0x00007583D79FF430
00007583d7bd5521  jmp 0x00007583D7BD3029
00007583d7bd5526  call 0x00007583D7A0E760
00007583d7bd552b  jmp 0x00007583D7BD3033
00007583d7bd5530  sub rsp, 0x08
00007583d7bd5534  push rax
00007583d7bd5535  push rcx
00007583d7bd5536  push rdx
00007583d7bd5537  push rdi
00007583d7bd5538  push rsi
00007583d7bd5539  push r8
00007583d7bd553b  push r9
00007583d7bd553d  push r10
00007583d7bd553f  push r11
00007583d7bd5541  sub rsp, 0xF0
00007583d7bd5548  vmovaps [rsp], xmm0
00007583d7bd554d  vmovaps [rsp+0x10], xmm1
00007583d7bd5553  vmovaps [rsp+0x20], xmm2
00007583d7bd5559  vmovaps [rsp+0x30], xmm3
00007583d7bd555f  vmovaps [rsp+0x40], xmm4
00007583d7bd5565  vmovaps [rsp+0x50], xmm5
00007583d7bd556b  vmovaps [rsp+0x60], xmm6
00007583d7bd5571  vmovaps [rsp+0x70], xmm8
00007583d7bd5577  vmovaps [rsp+0x80], xmm9
00007583d7bd5580  vmovaps [rsp+0x90], xmm10
00007583d7bd5589  vmovaps [rsp+0xA0], xmm11
00007583d7bd5592  vmovaps [rsp+0xB0], xmm12
00007583d7bd559b  vmovaps [rsp+0xC0], xmm13
00007583d7bd55a4  vmovaps [rsp+0xD0], xmm14
00007583d7bd55ad  vmovaps [rsp+0xE0], xmm15
00007583d7bd55b6  sub rsp, 0x40
00007583d7bd55ba  lea rdi, [rsp]
00007583d7bd55be  lea rsi, [rsp+0x10]
00007583d7bd55c3  lea rdx, [rsp+0x20]
00007583d7bd55c8  lea rcx, [rsp+0x30]
00007583d7bd55cd  mov r8d, 0x00
00007583d7bd55d3  lea r9, [r15+0x3A8]
00007583d7bd55da  movaps [rdi], xmm7
00007583d7bd55dd  movaps [rsi], xmm6
00007583d7bd55e0  movaps [rdx], xmm8
00007583d7bd55e4  movaps [rcx], xmm9
00007583d7bd55e8  mov rax, 0x5BCB7EA35A50
00007583d7bd55f2  call rax
00007583d7bd55f4  movaps xmm7, [rsp]
00007583d7bd55f8  add rsp, 0x40
00007583d7bd55fc  vmovaps xmm0, [rsp]
00007583d7bd5601  vmovaps xmm1, [rsp+0x10]
00007583d7bd5607  vmovaps xmm2, [rsp+0x20]
00007583d7bd560d  vmovaps xmm3, [rsp+0x30]
00007583d7bd5613  vmovaps xmm4, [rsp+0x40]
00007583d7bd5619  vmovaps xmm5, [rsp+0x50]
00007583d7bd561f  vmovaps xmm6, [rsp+0x60]
00007583d7bd5625  vmovaps xmm8, [rsp+0x70]
00007583d7bd562b  vmovaps xmm9, [rsp+0x80]
00007583d7bd5634  vmovaps xmm10, [rsp+0x90]
00007583d7bd563d  vmovaps xmm11, [rsp+0xA0]
00007583d7bd5646  vmovaps xmm12, [rsp+0xB0]
00007583d7bd564f  vmovaps xmm13, [rsp+0xC0]
00007583d7bd5658  vmovaps xmm14, [rsp+0xD0]
00007583d7bd5661  vmovaps xmm15, [rsp+0xE0]
00007583d7bd566a  add rsp, 0xF0
00007583d7bd5671  pop r11
00007583d7bd5673  pop r10
00007583d7bd5675  pop r9
00007583d7bd5677  pop r8
00007583d7bd5679  pop rsi
00007583d7bd567a  pop rdi
00007583d7bd567b  pop rdx
00007583d7bd567c  pop rcx
00007583d7bd567d  pop rax
00007583d7bd567e  add rsp, 0x08
00007583d7bd5682  jmp 0x00007583D7BD305D
00007583d7bd5687  sub rsp, 0x08
00007583d7bd568b  push rax
00007583d7bd568c  push rcx
00007583d7bd568d  push rdx
00007583d7bd568e  push rdi
00007583d7bd568f  push rsi
00007583d7bd5690  push r8
00007583d7bd5692  push r9
00007583d7bd5694  push r10
00007583d7bd5696  push r11
00007583d7bd5698  sub rsp, 0xF0
00007583d7bd569f  vmovaps [rsp], xmm0
00007583d7bd56a4  vmovaps [rsp+0x10], xmm1
00007583d7bd56aa  vmovaps [rsp+0x20], xmm2
00007583d7bd56b0  vmovaps [rsp+0x30], xmm3
00007583d7bd56b6  vmovaps [rsp+0x40], xmm4
00007583d7bd56bc  vmovaps [rsp+0x50], xmm5
00007583d7bd56c2  vmovaps [rsp+0x60], xmm6
00007583d7bd56c8  vmovaps [rsp+0x70], xmm7
00007583d7bd56ce  vmovaps [rsp+0x80], xmm9
00007583d7bd56d7  vmovaps [rsp+0x90], xmm10
00007583d7bd56e0  vmovaps [rsp+0xA0], xmm11
00007583d7bd56e9  vmovaps [rsp+0xB0], xmm12
00007583d7bd56f2  vmovaps [rsp+0xC0], xmm13
00007583d7bd56fb  vmovaps [rsp+0xD0], xmm14
00007583d7bd5704  vmovaps [rsp+0xE0], xmm15
00007583d7bd570d  sub rsp, 0x40
00007583d7bd5711  lea rdi, [rsp]
00007583d7bd5715  lea rsi, [rsp+0x10]
00007583d7bd571a  lea rdx, [rsp+0x20]
00007583d7bd571f  lea rcx, [rsp+0x30]
00007583d7bd5724  mov r8d, 0x00
00007583d7bd572a  lea r9, [r15+0x3A8]
00007583d7bd5731  movaps [rdi], xmm8
00007583d7bd5735  movaps [rsi], xmm10
00007583d7bd5739  movaps [rdx], xmm14
00007583d7bd573d  movaps [rcx], xmm9
00007583d7bd5741  mov rax, 0x5BCB7EA35A50
00007583d7bd574b  call rax
00007583d7bd574d  movaps xmm8, [rsp]
00007583d7bd5752  add rsp, 0x40
00007583d7bd5756  vmovaps xmm0, [rsp]
00007583d7bd575b  vmovaps xmm1, [rsp+0x10]
00007583d7bd5761  vmovaps xmm2, [rsp+0x20]
00007583d7bd5767  vmovaps xmm3, [rsp+0x30]
00007583d7bd576d  vmovaps xmm4, [rsp+0x40]
00007583d7bd5773  vmovaps xmm5, [rsp+0x50]
00007583d7bd5779  vmovaps xmm6, [rsp+0x60]
00007583d7bd577f  vmovaps xmm7, [rsp+0x70]
00007583d7bd5785  vmovaps xmm9, [rsp+0x80]
00007583d7bd578e  vmovaps xmm10, [rsp+0x90]
00007583d7bd5797  vmovaps xmm11, [rsp+0xA0]
00007583d7bd57a0  vmovaps xmm12, [rsp+0xB0]
00007583d7bd57a9  vmovaps xmm13, [rsp+0xC0]
00007583d7bd57b2  vmovaps xmm14, [rsp+0xD0]
00007583d7bd57bb  vmovaps xmm15, [rsp+0xE0]
00007583d7bd57c4  add rsp, 0xF0
00007583d7bd57cb  pop r11
00007583d7bd57cd  pop r10
00007583d7bd57cf  pop r9
00007583d7bd57d1  pop r8
00007583d7bd57d3  pop rsi
00007583d7bd57d4  pop rdi
00007583d7bd57d5  pop rdx
00007583d7bd57d6  pop rcx
00007583d7bd57d7  pop rax
00007583d7bd57d8  add rsp, 0x08
00007583d7bd57dc  jmp 0x00007583D7BD3083
00007583d7bd57e1  sub rsp, 0x08
00007583d7bd57e5  push rax
00007583d7bd57e6  push rcx
00007583d7bd57e7  push rdx
00007583d7bd57e8  push rdi
00007583d7bd57e9  push rsi
00007583d7bd57ea  push r8
00007583d7bd57ec  push r9
00007583d7bd57ee  push r10
00007583d7bd57f0  push r11
00007583d7bd57f2  sub rsp, 0xF0
00007583d7bd57f9  vmovaps [rsp], xmm0
00007583d7bd57fe  vmovaps [rsp+0x10], xmm1
00007583d7bd5804  vmovaps [rsp+0x20], xmm2
00007583d7bd580a  vmovaps [rsp+0x30], xmm3
00007583d7bd5810  vmovaps [rsp+0x40], xmm4
00007583d7bd5816  vmovaps [rsp+0x50], xmm5
00007583d7bd581c  vmovaps [rsp+0x60], xmm6
00007583d7bd5822  vmovaps [rsp+0x70], xmm7
00007583d7bd5828  vmovaps [rsp+0x80], xmm8
00007583d7bd5831  vmovaps [rsp+0x90], xmm9
00007583d7bd583a  vmovaps [rsp+0xA0], xmm11
00007583d7bd5843  vmovaps [rsp+0xB0], xmm12
00007583d7bd584c  vmovaps [rsp+0xC0], xmm13
00007583d7bd5855  vmovaps [rsp+0xD0], xmm14
00007583d7bd585e  vmovaps [rsp+0xE0], xmm15
00007583d7bd5867  sub rsp, 0x40
00007583d7bd586b  lea rdi, [rsp]
00007583d7bd586f  lea rsi, [rsp+0x10]
00007583d7bd5874  lea rdx, [rsp+0x20]
00007583d7bd5879  lea rcx, [rsp+0x30]
00007583d7bd587e  mov r8d, 0x00
00007583d7bd5884  lea r9, [r15+0x3A8]
00007583d7bd588b  movaps [rdi], xmm10
00007583d7bd588f  movaps [rsi], xmm13
00007583d7bd5893  movaps [rdx], xmm11
00007583d7bd5897  movaps [rcx], xmm14
00007583d7bd589b  mov rax, 0x5BCB7EA35A50
00007583d7bd58a5  call rax
00007583d7bd58a7  movaps xmm10, [rsp]
00007583d7bd58ac  add rsp, 0x40
00007583d7bd58b0  vmovaps xmm0, [rsp]
00007583d7bd58b5  vmovaps xmm1, [rsp+0x10]
00007583d7bd58bb  vmovaps xmm2, [rsp+0x20]
00007583d7bd58c1  vmovaps xmm3, [rsp+0x30]
00007583d7bd58c7  vmovaps xmm4, [rsp+0x40]
00007583d7bd58cd  vmovaps xmm5, [rsp+0x50]
00007583d7bd58d3  vmovaps xmm6, [rsp+0x60]
00007583d7bd58d9  vmovaps xmm7, [rsp+0x70]
00007583d7bd58df  vmovaps xmm8, [rsp+0x80]
00007583d7bd58e8  vmovaps xmm9, [rsp+0x90]
00007583d7bd58f1  vmovaps xmm11, [rsp+0xA0]
00007583d7bd58fa  vmovaps xmm12, [rsp+0xB0]
00007583d7bd5903  vmovaps xmm13, [rsp+0xC0]
00007583d7bd590c  vmovaps xmm14, [rsp+0xD0]
00007583d7bd5915  vmovaps xmm15, [rsp+0xE0]
00007583d7bd591e  add rsp, 0xF0
00007583d7bd5925  pop r11
00007583d7bd5927  pop r10
00007583d7bd5929  pop r9
00007583d7bd592b  pop r8
00007583d7bd592d  pop rsi
00007583d7bd592e  pop rdi
00007583d7bd592f  pop rdx
00007583d7bd5930  pop rcx
00007583d7bd5931  pop rax
00007583d7bd5932  add rsp, 0x08
00007583d7bd5936  jmp 0x00007583D7BD30A9
00007583d7bd593b  sub rsp, 0x08
00007583d7bd593f  push rax
00007583d7bd5940  push rcx
00007583d7bd5941  push rdx
00007583d7bd5942  push rdi
00007583d7bd5943  push rsi
00007583d7bd5944  push r8
00007583d7bd5946  push r9
00007583d7bd5948  push r10
00007583d7bd594a  push r11
00007583d7bd594c  sub rsp, 0xF0
00007583d7bd5953  vmovaps [rsp], xmm0
00007583d7bd5958  vmovaps [rsp+0x10], xmm1
00007583d7bd595e  vmovaps [rsp+0x20], xmm2
00007583d7bd5964  vmovaps [rsp+0x30], xmm3
00007583d7bd596a  vmovaps [rsp+0x40], xmm4
00007583d7bd5970  vmovaps [rsp+0x50], xmm5
00007583d7bd5976  vmovaps [rsp+0x60], xmm6
00007583d7bd597c  vmovaps [rsp+0x70], xmm7
00007583d7bd5982  vmovaps [rsp+0x80], xmm8
00007583d7bd598b  vmovaps [rsp+0x90], xmm9
00007583d7bd5994  vmovaps [rsp+0xA0], xmm10
00007583d7bd599d  vmovaps [rsp+0xB0], xmm11
00007583d7bd59a6  vmovaps [rsp+0xC0], xmm12
00007583d7bd59af  vmovaps [rsp+0xD0], xmm14
00007583d7bd59b8  vmovaps [rsp+0xE0], xmm15
00007583d7bd59c1  sub rsp, 0x40
00007583d7bd59c5  lea rdi, [rsp]
00007583d7bd59c9  lea rsi, [rsp+0x10]
00007583d7bd59ce  lea rdx, [rsp+0x20]
00007583d7bd59d3  lea rcx, [rsp+0x30]
00007583d7bd59d8  mov r8d, 0x00
00007583d7bd59de  lea r9, [r15+0x3A8]
00007583d7bd59e5  movaps [rdi], xmm13
00007583d7bd59e9  movaps [rsi], xmm12
00007583d7bd59ed  movaps [rdx], xmm15
00007583d7bd59f1  movaps [rcx], xmm14
00007583d7bd59f5  mov rax, 0x5BCB7EA35A50
00007583d7bd59ff  call rax
00007583d7bd5a01  movaps xmm13, [rsp]
00007583d7bd5a06  add rsp, 0x40
00007583d7bd5a0a  vmovaps xmm0, [rsp]
00007583d7bd5a0f  vmovaps xmm1, [rsp+0x10]
00007583d7bd5a15  vmovaps xmm2, [rsp+0x20]
00007583d7bd5a1b  vmovaps xmm3, [rsp+0x30]
00007583d7bd5a21  vmovaps xmm4, [rsp+0x40]
00007583d7bd5a27  vmovaps xmm5, [rsp+0x50]
00007583d7bd5a2d  vmovaps xmm6, [rsp+0x60]
00007583d7bd5a33  vmovaps xmm7, [rsp+0x70]
00007583d7bd5a39  vmovaps xmm8, [rsp+0x80]
00007583d7bd5a42  vmovaps xmm9, [rsp+0x90]
00007583d7bd5a4b  vmovaps xmm10, [rsp+0xA0]
00007583d7bd5a54  vmovaps xmm11, [rsp+0xB0]
00007583d7bd5a5d  vmovaps xmm12, [rsp+0xC0]
00007583d7bd5a66  vmovaps xmm14, [rsp+0xD0]
00007583d7bd5a6f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd5a78  add rsp, 0xF0
00007583d7bd5a7f  pop r11
00007583d7bd5a81  pop r10
00007583d7bd5a83  pop r9
00007583d7bd5a85  pop r8
00007583d7bd5a87  pop rsi
00007583d7bd5a88  pop rdi
00007583d7bd5a89  pop rdx
00007583d7bd5a8a  pop rcx
00007583d7bd5a8b  pop rax
00007583d7bd5a8c  add rsp, 0x08
00007583d7bd5a90  jmp 0x00007583D7BD30CF
00007583d7bd5a95  call 0x00007583D7A0E760
00007583d7bd5a9a  jmp 0x00007583D7BD30DC
00007583d7bd5a9f  call 0x00007583D7A0D4E0
00007583d7bd5aa4  jmp 0x00007583D7BD30E9
00007583d7bd5aa9  sub rsp, 0x08
00007583d7bd5aad  push rax
00007583d7bd5aae  push rcx
00007583d7bd5aaf  push rdx
00007583d7bd5ab0  push rdi
00007583d7bd5ab1  push rsi
00007583d7bd5ab2  push r8
00007583d7bd5ab4  push r9
00007583d7bd5ab6  push r10
00007583d7bd5ab8  push r11
00007583d7bd5aba  sub rsp, 0xF0
00007583d7bd5ac1  vmovaps [rsp], xmm0
00007583d7bd5ac6  vmovaps [rsp+0x10], xmm1
00007583d7bd5acc  vmovaps [rsp+0x20], xmm2
00007583d7bd5ad2  vmovaps [rsp+0x30], xmm3
00007583d7bd5ad8  vmovaps [rsp+0x40], xmm4
00007583d7bd5ade  vmovaps [rsp+0x50], xmm5
00007583d7bd5ae4  vmovaps [rsp+0x60], xmm6
00007583d7bd5aea  vmovaps [rsp+0x70], xmm7
00007583d7bd5af0  vmovaps [rsp+0x80], xmm8
00007583d7bd5af9  vmovaps [rsp+0x90], xmm9
00007583d7bd5b02  vmovaps [rsp+0xA0], xmm10
00007583d7bd5b0b  vmovaps [rsp+0xB0], xmm12
00007583d7bd5b14  vmovaps [rsp+0xC0], xmm13
00007583d7bd5b1d  vmovaps [rsp+0xD0], xmm14
00007583d7bd5b26  vmovaps [rsp+0xE0], xmm15
00007583d7bd5b2f  sub rsp, 0x40
00007583d7bd5b33  lea rdi, [rsp]
00007583d7bd5b37  lea rsi, [rsp+0x10]
00007583d7bd5b3c  lea rdx, [rsp+0x20]
00007583d7bd5b41  lea rcx, [rsp+0x30]
00007583d7bd5b46  mov r8d, 0x00
00007583d7bd5b4c  lea r9, [r15+0x3A8]
00007583d7bd5b53  movaps [rdi], xmm11
00007583d7bd5b57  movaps [rsi], xmm7
00007583d7bd5b5a  movaps [rdx], xmm1
00007583d7bd5b5d  movaps [rcx], xmm12
00007583d7bd5b61  mov rax, 0x5BCB7EA35A50
00007583d7bd5b6b  call rax
00007583d7bd5b6d  movaps xmm11, [rsp]
00007583d7bd5b72  add rsp, 0x40
00007583d7bd5b76  vmovaps xmm0, [rsp]
00007583d7bd5b7b  vmovaps xmm1, [rsp+0x10]
00007583d7bd5b81  vmovaps xmm2, [rsp+0x20]
00007583d7bd5b87  vmovaps xmm3, [rsp+0x30]
00007583d7bd5b8d  vmovaps xmm4, [rsp+0x40]
00007583d7bd5b93  vmovaps xmm5, [rsp+0x50]
00007583d7bd5b99  vmovaps xmm6, [rsp+0x60]
00007583d7bd5b9f  vmovaps xmm7, [rsp+0x70]
00007583d7bd5ba5  vmovaps xmm8, [rsp+0x80]
00007583d7bd5bae  vmovaps xmm9, [rsp+0x90]
00007583d7bd5bb7  vmovaps xmm10, [rsp+0xA0]
00007583d7bd5bc0  vmovaps xmm12, [rsp+0xB0]
00007583d7bd5bc9  vmovaps xmm13, [rsp+0xC0]
00007583d7bd5bd2  vmovaps xmm14, [rsp+0xD0]
00007583d7bd5bdb  vmovaps xmm15, [rsp+0xE0]
00007583d7bd5be4  add rsp, 0xF0
00007583d7bd5beb  pop r11
00007583d7bd5bed  pop r10
00007583d7bd5bef  pop r9
00007583d7bd5bf1  pop r8
00007583d7bd5bf3  pop rsi
00007583d7bd5bf4  pop rdi
00007583d7bd5bf5  pop rdx
00007583d7bd5bf6  pop rcx
00007583d7bd5bf7  pop rax
00007583d7bd5bf8  add rsp, 0x08
00007583d7bd5bfc  jmp 0x00007583D7BD3122
00007583d7bd5c01  call 0x00007583D79FF430
00007583d7bd5c06  jmp 0x00007583D7BD3134
00007583d7bd5c0b  sub rsp, 0x08
00007583d7bd5c0f  push rax
00007583d7bd5c10  push rcx
00007583d7bd5c11  push rdx
00007583d7bd5c12  push rdi
00007583d7bd5c13  push rsi
00007583d7bd5c14  push r8
00007583d7bd5c16  push r9
00007583d7bd5c18  push r10
00007583d7bd5c1a  push r11
00007583d7bd5c1c  sub rsp, 0xF0
00007583d7bd5c23  vmovaps [rsp], xmm0
00007583d7bd5c28  vmovaps [rsp+0x10], xmm1
00007583d7bd5c2e  vmovaps [rsp+0x20], xmm2
00007583d7bd5c34  vmovaps [rsp+0x30], xmm3
00007583d7bd5c3a  vmovaps [rsp+0x40], xmm4
00007583d7bd5c40  vmovaps [rsp+0x50], xmm5
00007583d7bd5c46  vmovaps [rsp+0x60], xmm6
00007583d7bd5c4c  vmovaps [rsp+0x70], xmm7
00007583d7bd5c52  vmovaps [rsp+0x80], xmm8
00007583d7bd5c5b  vmovaps [rsp+0x90], xmm10
00007583d7bd5c64  vmovaps [rsp+0xA0], xmm11
00007583d7bd5c6d  vmovaps [rsp+0xB0], xmm12
00007583d7bd5c76  vmovaps [rsp+0xC0], xmm13
00007583d7bd5c7f  vmovaps [rsp+0xD0], xmm14
00007583d7bd5c88  vmovaps [rsp+0xE0], xmm15
00007583d7bd5c91  sub rsp, 0x40
00007583d7bd5c95  lea rdi, [rsp]
00007583d7bd5c99  lea rsi, [rsp+0x10]
00007583d7bd5c9e  lea rdx, [rsp+0x20]
00007583d7bd5ca3  lea rcx, [rsp+0x30]
00007583d7bd5ca8  mov r8d, 0x00
00007583d7bd5cae  lea r9, [r15+0x3A8]
00007583d7bd5cb5  movaps [rdi], xmm9
00007583d7bd5cb9  movaps [rsi], xmm8
00007583d7bd5cbd  movaps [rdx], xmm14
00007583d7bd5cc1  movaps [rcx], xmm12
00007583d7bd5cc5  mov rax, 0x5BCB7EA35A50
00007583d7bd5ccf  call rax
00007583d7bd5cd1  movaps xmm9, [rsp]
00007583d7bd5cd6  add rsp, 0x40
00007583d7bd5cda  vmovaps xmm0, [rsp]
00007583d7bd5cdf  vmovaps xmm1, [rsp+0x10]
00007583d7bd5ce5  vmovaps xmm2, [rsp+0x20]
00007583d7bd5ceb  vmovaps xmm3, [rsp+0x30]
00007583d7bd5cf1  vmovaps xmm4, [rsp+0x40]
00007583d7bd5cf7  vmovaps xmm5, [rsp+0x50]
00007583d7bd5cfd  vmovaps xmm6, [rsp+0x60]
00007583d7bd5d03  vmovaps xmm7, [rsp+0x70]
00007583d7bd5d09  vmovaps xmm8, [rsp+0x80]
00007583d7bd5d12  vmovaps xmm10, [rsp+0x90]
00007583d7bd5d1b  vmovaps xmm11, [rsp+0xA0]
00007583d7bd5d24  vmovaps xmm12, [rsp+0xB0]
00007583d7bd5d2d  vmovaps xmm13, [rsp+0xC0]
00007583d7bd5d36  vmovaps xmm14, [rsp+0xD0]
00007583d7bd5d3f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd5d48  add rsp, 0xF0
00007583d7bd5d4f  pop r11
00007583d7bd5d51  pop r10
00007583d7bd5d53  pop r9
00007583d7bd5d55  pop r8
00007583d7bd5d57  pop rsi
00007583d7bd5d58  pop rdi
00007583d7bd5d59  pop rdx
00007583d7bd5d5a  pop rcx
00007583d7bd5d5b  pop rax
00007583d7bd5d5c  add rsp, 0x08
00007583d7bd5d60  jmp 0x00007583D7BD3165
00007583d7bd5d65  sub rsp, 0x08
00007583d7bd5d69  push rax
00007583d7bd5d6a  push rcx
00007583d7bd5d6b  push rdx
00007583d7bd5d6c  push rdi
00007583d7bd5d6d  push rsi
00007583d7bd5d6e  push r8
00007583d7bd5d70  push r9
00007583d7bd5d72  push r10
00007583d7bd5d74  push r11
00007583d7bd5d76  sub rsp, 0xF0
00007583d7bd5d7d  vmovaps [rsp], xmm0
00007583d7bd5d82  vmovaps [rsp+0x10], xmm1
00007583d7bd5d88  vmovaps [rsp+0x20], xmm2
00007583d7bd5d8e  vmovaps [rsp+0x30], xmm3
00007583d7bd5d94  vmovaps [rsp+0x40], xmm4
00007583d7bd5d9a  vmovaps [rsp+0x50], xmm5
00007583d7bd5da0  vmovaps [rsp+0x60], xmm6
00007583d7bd5da6  vmovaps [rsp+0x70], xmm7
00007583d7bd5dac  vmovaps [rsp+0x80], xmm8
00007583d7bd5db5  vmovaps [rsp+0x90], xmm9
00007583d7bd5dbe  vmovaps [rsp+0xA0], xmm10
00007583d7bd5dc7  vmovaps [rsp+0xB0], xmm11
00007583d7bd5dd0  vmovaps [rsp+0xC0], xmm13
00007583d7bd5dd9  vmovaps [rsp+0xD0], xmm14
00007583d7bd5de2  vmovaps [rsp+0xE0], xmm15
00007583d7bd5deb  sub rsp, 0x40
00007583d7bd5def  lea rdi, [rsp]
00007583d7bd5df3  lea rsi, [rsp+0x10]
00007583d7bd5df8  lea rdx, [rsp+0x20]
00007583d7bd5dfd  lea rcx, [rsp+0x30]
00007583d7bd5e02  mov r8d, 0x00
00007583d7bd5e08  lea r9, [r15+0x3A8]
00007583d7bd5e0f  movaps [rdi], xmm12
00007583d7bd5e13  movaps [rsi], xmm10
00007583d7bd5e17  movaps [rdx], xmm15
00007583d7bd5e1b  movaps [rcx], xmm14
00007583d7bd5e1f  mov rax, 0x5BCB7EA35A50
00007583d7bd5e29  call rax
00007583d7bd5e2b  movaps xmm12, [rsp]
00007583d7bd5e30  add rsp, 0x40
00007583d7bd5e34  vmovaps xmm0, [rsp]
00007583d7bd5e39  vmovaps xmm1, [rsp+0x10]
00007583d7bd5e3f  vmovaps xmm2, [rsp+0x20]
00007583d7bd5e45  vmovaps xmm3, [rsp+0x30]
00007583d7bd5e4b  vmovaps xmm4, [rsp+0x40]
00007583d7bd5e51  vmovaps xmm5, [rsp+0x50]
00007583d7bd5e57  vmovaps xmm6, [rsp+0x60]
00007583d7bd5e5d  vmovaps xmm7, [rsp+0x70]
00007583d7bd5e63  vmovaps xmm8, [rsp+0x80]
00007583d7bd5e6c  vmovaps xmm9, [rsp+0x90]
00007583d7bd5e75  vmovaps xmm10, [rsp+0xA0]
00007583d7bd5e7e  vmovaps xmm11, [rsp+0xB0]
00007583d7bd5e87  vmovaps xmm13, [rsp+0xC0]
00007583d7bd5e90  vmovaps xmm14, [rsp+0xD0]
00007583d7bd5e99  vmovaps xmm15, [rsp+0xE0]
00007583d7bd5ea2  add rsp, 0xF0
00007583d7bd5ea9  pop r11
00007583d7bd5eab  pop r10
00007583d7bd5ead  pop r9
00007583d7bd5eaf  pop r8
00007583d7bd5eb1  pop rsi
00007583d7bd5eb2  pop rdi
00007583d7bd5eb3  pop rdx
00007583d7bd5eb4  pop rcx
00007583d7bd5eb5  pop rax
00007583d7bd5eb6  add rsp, 0x08
00007583d7bd5eba  jmp 0x00007583D7BD3196
00007583d7bd5ebf  sub rsp, 0x08
00007583d7bd5ec3  push rax
00007583d7bd5ec4  push rcx
00007583d7bd5ec5  push rdx
00007583d7bd5ec6  push rdi
00007583d7bd5ec7  push rsi
00007583d7bd5ec8  push r8
00007583d7bd5eca  push r9
00007583d7bd5ecc  push r10
00007583d7bd5ece  push r11
00007583d7bd5ed0  sub rsp, 0xF0
00007583d7bd5ed7  vmovaps [rsp], xmm0
00007583d7bd5edc  vmovaps [rsp+0x10], xmm1
00007583d7bd5ee2  vmovaps [rsp+0x20], xmm2
00007583d7bd5ee8  vmovaps [rsp+0x30], xmm3
00007583d7bd5eee  vmovaps [rsp+0x40], xmm4
00007583d7bd5ef4  vmovaps [rsp+0x50], xmm5
00007583d7bd5efa  vmovaps [rsp+0x60], xmm6
00007583d7bd5f00  vmovaps [rsp+0x70], xmm7
00007583d7bd5f06  vmovaps [rsp+0x80], xmm8
00007583d7bd5f0f  vmovaps [rsp+0x90], xmm9
00007583d7bd5f18  vmovaps [rsp+0xA0], xmm10
00007583d7bd5f21  vmovaps [rsp+0xB0], xmm11
00007583d7bd5f2a  vmovaps [rsp+0xC0], xmm12
00007583d7bd5f33  vmovaps [rsp+0xD0], xmm13
00007583d7bd5f3c  vmovaps [rsp+0xE0], xmm15
00007583d7bd5f45  sub rsp, 0x40
00007583d7bd5f49  lea rdi, [rsp]
00007583d7bd5f4d  lea rsi, [rsp+0x10]
00007583d7bd5f52  lea rdx, [rsp+0x20]
00007583d7bd5f57  lea rcx, [rsp+0x30]
00007583d7bd5f5c  mov r8d, 0x00
00007583d7bd5f62  lea r9, [r15+0x3A8]
00007583d7bd5f69  movaps [rdi], xmm14
00007583d7bd5f6d  movaps [rsi], xmm13
00007583d7bd5f71  movaps [rdx], xmm1
00007583d7bd5f74  movaps [rcx], xmm15
00007583d7bd5f78  mov rax, 0x5BCB7EA35A50
00007583d7bd5f82  call rax
00007583d7bd5f84  movaps xmm14, [rsp]
00007583d7bd5f89  add rsp, 0x40
00007583d7bd5f8d  vmovaps xmm0, [rsp]
00007583d7bd5f92  vmovaps xmm1, [rsp+0x10]
00007583d7bd5f98  vmovaps xmm2, [rsp+0x20]
00007583d7bd5f9e  vmovaps xmm3, [rsp+0x30]
00007583d7bd5fa4  vmovaps xmm4, [rsp+0x40]
00007583d7bd5faa  vmovaps xmm5, [rsp+0x50]
00007583d7bd5fb0  vmovaps xmm6, [rsp+0x60]
00007583d7bd5fb6  vmovaps xmm7, [rsp+0x70]
00007583d7bd5fbc  vmovaps xmm8, [rsp+0x80]
00007583d7bd5fc5  vmovaps xmm9, [rsp+0x90]
00007583d7bd5fce  vmovaps xmm10, [rsp+0xA0]
00007583d7bd5fd7  vmovaps xmm11, [rsp+0xB0]
00007583d7bd5fe0  vmovaps xmm12, [rsp+0xC0]
00007583d7bd5fe9  vmovaps xmm13, [rsp+0xD0]
00007583d7bd5ff2  vmovaps xmm15, [rsp+0xE0]
00007583d7bd5ffb  add rsp, 0xF0
00007583d7bd6002  pop r11
00007583d7bd6004  pop r10
00007583d7bd6006  pop r9
00007583d7bd6008  pop r8
00007583d7bd600a  pop rsi
00007583d7bd600b  pop rdi
00007583d7bd600c  pop rdx
00007583d7bd600d  pop rcx
00007583d7bd600e  pop rax
00007583d7bd600f  add rsp, 0x08
00007583d7bd6013  jmp 0x00007583D7BD31C7
00007583d7bd6018  call 0x00007583D7A079B0
00007583d7bd601d  jmp 0x00007583D7BD31DA
00007583d7bd6022  call 0x00007583D7A0B100
00007583d7bd6027  jmp 0x00007583D7BD31E5
00007583d7bd602c  call 0x00007583D7A09E90
00007583d7bd6031  jmp 0x00007583D7BD31F0
00007583d7bd6036  call 0x00007583D7A0D600
00007583d7bd603b  jmp 0x00007583D7BD31FB
00007583d7bd6040  int3
00007583d7bd6041  nop [rax+rax*1], ax
00007583d7bd604a  nop [rax+rax*1], ax
00007583d7bd6050  mov rax, [r15+0x40]
00007583d7bd6054  mov r14, [r15+0x58]
00007583d7bd6058  lea r12, [rax+r14*1]
00007583d7bd605c  vxorps xmm1, xmm1, xmm1
00007583d7bd6060  vpbroadcastq xmm1, xmm1
00007583d7bd6065  vxorps xmm15, xmm15, xmm15
00007583d7bd606a  vpbroadcastq xmm15, xmm15
00007583d7bd606f  lea rax, [r12+0x30]
00007583d7bd6074  mov r11, [r13+rax*1]
00007583d7bd6079  lea rax, [r12+0x38]
00007583d7bd607e  mov r10, [r13+rax*1]
00007583d7bd6083  movq xmm14, r11
00007583d7bd6088  movq xmm13, r10
00007583d7bd608d  movq xmm14, xmm14
00007583d7bd6092  movq xmm13, xmm13
00007583d7bd6097  vmovaps [rsp+0x10], xmm13
00007583d7bd609d  movq xmm13, xmm13
00007583d7bd60a2  movaps [r15+0x270], xmm13
00007583d7bd60aa  movaps xmm13, [r15+0x160]
00007583d7bd60b2  vmovaps [rsp+0x20], xmm13
00007583d7bd60b8  vmovaps xmm12, [rsp+0x20]
00007583d7bd60be  por xmm13, xmm12
00007583d7bd60c3  lea rax, [r12+0x20]
00007583d7bd60c8  mov r11, [r13+rax*1]
00007583d7bd60cd  lea rax, [r12+0x28]
00007583d7bd60d2  mov r10, [r13+rax*1]
00007583d7bd60d7  movq xmm12, r11
00007583d7bd60dc  movq xmm11, r10
00007583d7bd60e1  movq xmm12, xmm12
00007583d7bd60e6  movq xmm11, xmm11
00007583d7bd60eb  movaps xmm10, [r15+0x2D0]
00007583d7bd60f3  vmovaps [rsp+0x20], xmm10
00007583d7bd60f9  vmovaps xmm9, [rsp+0x20]
00007583d7bd60ff  por xmm10, xmm9
00007583d7bd6104  movaps xmm9, [r15+0x300]
00007583d7bd610c  vmovaps [rsp+0x20], xmm9
00007583d7bd6112  vmovaps xmm8, [rsp+0x20]
00007583d7bd6118  por xmm9, xmm8
00007583d7bd611d  movaps xmm8, [r15+0x2B0]
00007583d7bd6125  vmovaps [rsp+0x20], xmm8
00007583d7bd612b  vmovaps xmm7, [rsp+0x20]
00007583d7bd6131  por xmm8, xmm7
00007583d7bd6136  movaps xmm7, [r15+0x180]
00007583d7bd613e  vmovaps [rsp+0x20], xmm7
00007583d7bd6144  vmovaps xmm6, [rsp+0x20]
00007583d7bd614a  por xmm7, xmm6
00007583d7bd614e  lea rax, [r12+0x10]
00007583d7bd6153  mov r11, [r13+rax*1]
00007583d7bd6158  lea rax, [r12+0x18]
00007583d7bd615d  mov r10, [r13+rax*1]
00007583d7bd6162  movq xmm6, r11
00007583d7bd6167  movq xmm5, r10
00007583d7bd616c  movq xmm6, xmm6
00007583d7bd6170  movq xmm5, xmm5
00007583d7bd6174  movaps xmm4, [r15+0x200]
00007583d7bd617c  vmovaps [rsp+0x20], xmm4
00007583d7bd6182  vmovaps xmm3, [rsp+0x20]
00007583d7bd6188  por xmm4, xmm3
00007583d7bd618c  movaps xmm3, [r15+0x1F0]
00007583d7bd6194  vmovaps [rsp+0x20], xmm3
00007583d7bd619a  vmovaps xmm2, [rsp+0x20]
00007583d7bd61a0  por xmm3, xmm2
00007583d7bd61a4  movaps xmm2, [r15+0x2E0]
00007583d7bd61ac  vmovaps [rsp+0x20], xmm2
00007583d7bd61b2  vmovaps [rsp+0x30], xmm1
00007583d7bd61b8  vmovaps xmm1, [rsp+0x20]
00007583d7bd61be  por xmm2, xmm1
00007583d7bd61c2  movaps xmm1, [r15+0x2A0]
00007583d7bd61ca  vmovaps [rsp+0x20], xmm1
00007583d7bd61d0  vmovaps [rsp+0x40], xmm15
00007583d7bd61d6  vmovaps xmm15, [rsp+0x20]
00007583d7bd61dc  por xmm1, xmm15
00007583d7bd61e1  movaps xmm15, [r15+0x280]
00007583d7bd61e9  vmovaps [rsp+0x20], xmm15
00007583d7bd61ef  vmovaps [rsp+0x50], xmm1
00007583d7bd61f5  vmovaps xmm1, [rsp+0x20]
00007583d7bd61fb  por xmm15, xmm1
00007583d7bd6200  movaps xmm1, [r15+0x1C0]
00007583d7bd6208  vmovaps [rsp+0x20], xmm1
00007583d7bd620e  vmovaps [rsp+0x60], xmm15
00007583d7bd6214  vmovaps xmm15, [rsp+0x20]
00007583d7bd621a  por xmm1, xmm15
00007583d7bd621f  movaps xmm15, [r15+0x210]
00007583d7bd6227  vmovaps [rsp+0x20], xmm15
00007583d7bd622d  vmovaps [rsp+0x70], xmm1
00007583d7bd6233  vmovaps xmm1, [rsp+0x20]
00007583d7bd6239  por xmm15, xmm1
00007583d7bd623e  mov rax, [r13+r12*1]
00007583d7bd6243  vmovq xmm1, rax
00007583d7bd6248  vpbroadcastq xmm1, xmm1
00007583d7bd624d  vmovaps [rsp+0x20], xmm1
00007583d7bd6253  vxorps xmm1, xmm1, xmm1
00007583d7bd6257  vpbroadcastq xmm1, xmm1
00007583d7bd625c  mov rax, [r15+0xF8]
00007583d7bd6263  vmovaps [rsp+0x80], xmm1
00007583d7bd626c  movups xmm1, [r13+rax*1]
00007583d7bd6272  vmovaps [rsp+0x90], xmm1
00007583d7bd627b  vxorps xmm1, xmm1, xmm1
00007583d7bd627f  vpbroadcastq xmm1, xmm1
00007583d7bd6284  lea r11, [r12+0x08]
00007583d7bd6289  mov r12, [r13+r11*1]
00007583d7bd628e  vmovaps [rsp+0xA0], xmm1
00007583d7bd6297  movq xmm1, r12
00007583d7bd629c  movaps [r15+0x240], xmm1
00007583d7bd62a4  mov r12, [r15+0x50]
00007583d7bd62a8  lea r11, [r12+r14*1]
00007583d7bd62ac  mov [r15+0x60], r11
00007583d7bd62b0  lea r12, [r14+0x40]
00007583d7bd62b4  mov [r15+0x58], r12
00007583d7bd62b8  vmovaps xmm1, [rsp+0x30]
00007583d7bd62be  vmovaps [rsp+0x30], xmm15
00007583d7bd62c4  vmovaps xmm15, [rsp+0x90]
00007583d7bd62cd  vmovaps [rsp+0x90], xmm14
00007583d7bd62d6  vmovaps xmm14, [rsp+0x20]
00007583d7bd62dc  vmovaps [rsp+0x20], xmm13
00007583d7bd62e2  vmovaps [rsp+0xB0], xmm12
00007583d7bd62eb  movaps xmm13, xmm1
00007583d7bd62ef  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd62fa  vptest xmm12, xmm12
00007583d7bd62ff  jnz 0x00007583D7BD6D9C
00007583d7bd6305  movaps xmm1, [r15+0x250]
00007583d7bd630d  vmovaps xmm15, [rsp+0x40]
00007583d7bd6313  vmovaps [rsp+0x40], xmm13
00007583d7bd6319  movaps xmm12, xmm15
00007583d7bd631d  vfmadd231pd xmm12, xmm1, xmm14
00007583d7bd6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007583d7bd6328  vptest xmm13, xmm13
00007583d7bd632d  jnz 0x00007583D7BD6EF5
00007583d7bd6333  movaps xmm15, [r15+0x1E0]
00007583d7bd633b  vmovaps [rsp+0xC0], xmm15
00007583d7bd6344  vmovaps xmm13, [rsp+0xC0]
00007583d7bd634d  por xmm15, xmm13
00007583d7bd6352  movaps xmm13, [r15+0x1D0]
00007583d7bd635a  vmovaps [rsp+0xC0], xmm13
00007583d7bd6363  vmovaps [rsp+0xD0], xmm1
00007583d7bd636c  vmovaps xmm1, [rsp+0xC0]
00007583d7bd6375  por xmm13, xmm1
00007583d7bd637a  movaps xmm1, [r15+0x2C0]
00007583d7bd6382  vmovaps [rsp+0xC0], xmm1
00007583d7bd638b  vmovaps [rsp+0xE0], xmm15
00007583d7bd6394  vmovaps xmm15, [rsp+0xC0]
00007583d7bd639d  por xmm1, xmm15
00007583d7bd63a2  movaps xmm15, [r15+0x290]
00007583d7bd63aa  vmovaps [rsp+0xC0], xmm15
00007583d7bd63b3  vmovaps [rsp+0xF0], xmm1
00007583d7bd63bc  vmovaps xmm1, [rsp+0xC0]
00007583d7bd63c5  por xmm15, xmm1
00007583d7bd63ca  movaps xmm1, [r15+0x260]
00007583d7bd63d2  vmovaps [rsp+0xC0], xmm1
00007583d7bd63db  vmovaps [rsp+0x100], xmm15
00007583d7bd63e4  vmovaps xmm15, [rsp+0xC0]
00007583d7bd63ed  por xmm1, xmm15
00007583d7bd63f2  vmovaps xmm15, [rsp+0xD0]
00007583d7bd63fb  vmovaps [rsp+0xC0], xmm1
00007583d7bd6404  vmovaps xmm1, [rsp+0xD0]
00007583d7bd640d  por xmm15, xmm1
00007583d7bd6412  lea r14, [rax+0xC0]
00007583d7bd6419  movups xmm1, [r13+r14*1]
00007583d7bd641f  mov [rsp+0xD0], rax
00007583d7bd6427  xor eax, eax
00007583d7bd6429  mov r14d, 0x200
00007583d7bd642f  cmp r12, r14
00007583d7bd6432  cmc
00007583d7bd6433  lahf
00007583d7bd6434  seto al
00007583d7bd6437  mov [r15+0x108], eax
00007583d7bd643e  vmovaps [rsp+0x110], xmm1
00007583d7bd6447  vmovaps xmm1, [rsp+0x80]
00007583d7bd6450  vmovaps [rsp+0x80], xmm15
00007583d7bd6459  vmovaps xmm15, [rsp+0x110]
00007583d7bd6462  vmovaps [rsp+0x110], xmm13
00007583d7bd646b  vmovaps [rsp+0x120], xmm12
00007583d7bd6474  movaps xmm13, xmm1
00007583d7bd6478  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd6483  vptest xmm12, xmm12
00007583d7bd6488  jnz 0x00007583D7BD7058
00007583d7bd648e  mov rax, [rsp+0xD0]
00007583d7bd6496  lea r14, [rax+0xB0]
00007583d7bd649d  movups xmm1, [r13+r14*1]
00007583d7bd64a3  vmovaps xmm15, [rsp+0xA0]
00007583d7bd64ac  vmovaps [rsp+0xA0], xmm13
00007583d7bd64b5  movaps xmm12, xmm15
00007583d7bd64b9  vfmadd231pd xmm12, xmm1, xmm14
00007583d7bd64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007583d7bd64c4  vptest xmm13, xmm13
00007583d7bd64c9  jnz 0x00007583D7BD71BB
00007583d7bd64cf  vmovaps xmm1, [rsp+0x30]
00007583d7bd64d5  vmovaps xmm15, [rsp+0x30]
00007583d7bd64db  por xmm1, xmm15
00007583d7bd64e0  movaps [r15+0x210], xmm1
00007583d7bd64e8  vmovaps xmm15, [rsp+0x70]
00007583d7bd64ee  vmovaps xmm14, [rsp+0x70]
00007583d7bd64f4  por xmm15, xmm14
00007583d7bd64f9  movaps [r15+0x1C0], xmm15
00007583d7bd6501  vmovaps xmm14, [rsp+0x60]
00007583d7bd6507  vmovaps xmm13, [rsp+0x60]
00007583d7bd650d  por xmm14, xmm13
00007583d7bd6512  movaps [r15+0x280], xmm14
00007583d7bd651a  vmovaps xmm13, [rsp+0x50]
00007583d7bd6520  vmovaps [rsp+0x30], xmm1
00007583d7bd6526  vmovaps xmm1, [rsp+0x50]
00007583d7bd652c  por xmm13, xmm1
00007583d7bd6531  movaps [r15+0x2A0], xmm13
00007583d7bd6539  vmovaps [rsp+0x50], xmm2
00007583d7bd653f  vmovaps xmm1, [rsp+0x50]
00007583d7bd6545  por xmm2, xmm1
00007583d7bd6549  movaps [r15+0x2E0], xmm2
00007583d7bd6551  vmovaps [rsp+0x50], xmm3
00007583d7bd6557  vmovaps xmm1, [rsp+0x50]
00007583d7bd655d  por xmm3, xmm1
00007583d7bd6561  movaps [r15+0x1F0], xmm3
00007583d7bd6569  vmovaps xmm1, [rsp+0x80]
00007583d7bd6572  vmovaps [rsp+0x50], xmm15
00007583d7bd6578  vmovaps xmm15, [rsp+0x80]
00007583d7bd6581  por xmm1, xmm15
00007583d7bd6586  movaps [r15+0x250], xmm1
00007583d7bd658e  vmovaps xmm1, [rsp+0xC0]
00007583d7bd6597  vmovaps xmm15, [rsp+0xC0]
00007583d7bd65a0  por xmm1, xmm15
00007583d7bd65a5  movaps [r15+0x260], xmm1
00007583d7bd65ad  vmovaps xmm15, [rsp+0x100]
00007583d7bd65b6  vmovaps [rsp+0x60], xmm1
00007583d7bd65bc  vmovaps xmm1, [rsp+0x100]
00007583d7bd65c5  por xmm15, xmm1
00007583d7bd65ca  movaps [r15+0x290], xmm15
00007583d7bd65d2  vmovaps xmm1, [rsp+0xF0]
00007583d7bd65db  vmovaps [rsp+0x70], xmm15
00007583d7bd65e1  vmovaps xmm15, [rsp+0xF0]
00007583d7bd65ea  por xmm1, xmm15
00007583d7bd65ef  movaps [r15+0x2C0], xmm1
00007583d7bd65f7  movq xmm15, qword ptr [r15+0x240]
00007583d7bd6600  vmovaps [rsp+0x80], xmm15
00007583d7bd6609  vpermilpd xmm15, xmm15, 0x00
00007583d7bd660f  vmovaps [rsp+0xC0], xmm1
00007583d7bd6618  vmovaps xmm1, [rsp+0x40]
00007583d7bd661e  vmovaps [rsp+0x40], xmm15
00007583d7bd6624  vmovaps xmm15, [rsp+0x30]
00007583d7bd662a  vmovaps [rsp+0x30], xmm14
00007583d7bd6630  vmovaps xmm14, [rsp+0x40]
00007583d7bd6636  vmovaps [rsp+0x40], xmm13
00007583d7bd663c  vmovaps [rsp+0xD0], xmm12
00007583d7bd6645  movaps xmm13, xmm1
00007583d7bd6649  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd6654  vptest xmm12, xmm12
00007583d7bd6659  jnz 0x00007583D7BD7314
00007583d7bd665f  vmovaps xmm1, [rsp+0x80]
00007583d7bd6668  vpermilpd xmm1, xmm1, 0x00
00007583d7bd666e  vmovaps xmm15, [rsp+0xA0]
00007583d7bd6677  movaps xmm14, xmm15
00007583d7bd667b  vfmadd231pd xmm14, xmm2, xmm1
00007583d7bd6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007583d7bd6686  vptest xmm12, xmm12
00007583d7bd668b  jnz 0x00007583D7BD746D
00007583d7bd6691  vmovaps xmm1, [rsp+0x80]
00007583d7bd669a  vpermilpd xmm1, xmm1, 0x00
00007583d7bd66a0  vmovaps xmm15, [rsp+0x120]
00007583d7bd66a9  vmovaps xmm12, [rsp+0x50]
00007583d7bd66af  vmovaps [rsp+0x50], xmm14
00007583d7bd66b5  movaps xmm2, xmm15
00007583d7bd66b9  vfmadd231pd xmm2, xmm12, xmm1
00007583d7bd66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007583d7bd66c3  vptest xmm14, xmm14
00007583d7bd66c8  jnz 0x00007583D7BD75C5
00007583d7bd66ce  vmovaps xmm1, [rsp+0x110]
00007583d7bd66d7  vmovaps xmm15, [rsp+0x110]
00007583d7bd66e0  por xmm1, xmm15
00007583d7bd66e5  movaps [r15+0x1D0], xmm1
00007583d7bd66ed  vmovaps xmm15, [rsp+0x80]
00007583d7bd66f6  vpermilpd xmm15, xmm15, 0x00
00007583d7bd66fc  vmovaps xmm14, [rsp+0xD0]
00007583d7bd6705  vmovaps [rsp+0x80], xmm1
00007583d7bd670e  movaps xmm12, xmm14
00007583d7bd6712  vfmadd231pd xmm12, xmm3, xmm15
00007583d7bd6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007583d7bd671d  vptest xmm1, xmm1
00007583d7bd6722  jnz 0x00007583D7BD771C
00007583d7bd6728  vmovaps [rsp+0xA0], xmm4
00007583d7bd6731  vmovaps xmm1, [rsp+0xA0]
00007583d7bd673a  por xmm4, xmm1
00007583d7bd673e  movaps [r15+0x200], xmm4
00007583d7bd6746  vmovaps xmm1, [rsp+0xE0]
00007583d7bd674f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd6758  por xmm1, xmm15
00007583d7bd675d  movaps [r15+0x1E0], xmm1
00007583d7bd6765  vmovaps [rsp+0xA0], xmm8
00007583d7bd676e  vmovaps xmm1, [rsp+0xA0]
00007583d7bd6777  por xmm8, xmm1
00007583d7bd677c  movaps [r15+0x2B0], xmm8
00007583d7bd6784  vmovaps [rsp+0xA0], xmm9
00007583d7bd678d  vmovaps xmm1, [rsp+0xA0]
00007583d7bd6796  por xmm9, xmm1
00007583d7bd679b  movaps [r15+0x300], xmm9
00007583d7bd67a3  vmovaps [rsp+0xA0], xmm6
00007583d7bd67ac  vpermilpd xmm6, xmm6, 0x00
00007583d7bd67b2  vmovaps xmm14, [rsp+0x60]
00007583d7bd67b8  movaps xmm9, xmm13
00007583d7bd67bc  vfmadd231pd xmm9, xmm14, xmm6
00007583d7bd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007583d7bd67c7  vptest xmm3, xmm3
00007583d7bd67cc  jnz 0x00007583D7BD7875
00007583d7bd67d2  vmovaps xmm14, [rsp+0xA0]
00007583d7bd67db  vpermilpd xmm14, xmm14, 0x00
00007583d7bd67e1  vmovaps xmm13, [rsp+0x50]
00007583d7bd67e7  vmovaps xmm6, [rsp+0xC0]
00007583d7bd67f0  vmovaps [rsp+0x50], xmm1
00007583d7bd67f6  movaps xmm3, xmm13
00007583d7bd67fa  vfmadd231pd xmm3, xmm6, xmm14
00007583d7bd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007583d7bd6804  vptest xmm1, xmm1
00007583d7bd6809  jnz 0x00007583D7BD79CE
00007583d7bd680f  vmovaps xmm1, [rsp+0xA0]
00007583d7bd6818  vpermilpd xmm1, xmm1, 0x00
00007583d7bd681e  vmovaps xmm14, [rsp+0x30]
00007583d7bd6824  movaps xmm6, xmm2
00007583d7bd6827  vfmadd231pd xmm6, xmm14, xmm1
00007583d7bd682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007583d7bd6831  vptest xmm13, xmm13
00007583d7bd6836  jnz 0x00007583D7BD7B25
00007583d7bd683c  vmovaps xmm1, [rsp+0xA0]
00007583d7bd6845  vpermilpd xmm1, xmm1, 0x00
00007583d7bd684b  vmovaps xmm14, [rsp+0x80]
00007583d7bd6854  movaps xmm13, xmm12
00007583d7bd6858  vfmadd231pd xmm13, xmm14, xmm1
00007583d7bd685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007583d7bd6863  vptest xmm2, xmm2
00007583d7bd6868  jnz 0x00007583D7BD7C7B
00007583d7bd686e  vmovaps [rsp+0x30], xmm7
00007583d7bd6874  vmovaps xmm1, [rsp+0x30]
00007583d7bd687a  por xmm7, xmm1
00007583d7bd687e  movaps [r15+0x180], xmm7
00007583d7bd6886  vmovaps [rsp+0x30], xmm10
00007583d7bd688c  vmovaps xmm1, [rsp+0x30]
00007583d7bd6892  por xmm10, xmm1
00007583d7bd6897  movaps [r15+0x2D0], xmm10
00007583d7bd689f  vmovaps [rsp+0x30], xmm5
00007583d7bd68a5  vpermilpd xmm5, xmm5, 0x00
00007583d7bd68ab  vmovaps xmm14, [rsp+0x50]
00007583d7bd68b1  movaps xmm12, xmm3
00007583d7bd68b5  vfmadd231pd xmm12, xmm14, xmm5
00007583d7bd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007583d7bd68c0  vptest xmm10, xmm10
00007583d7bd68c5  jnz 0x00007583D7BD7DD4
00007583d7bd68cb  vmovaps xmm14, [rsp+0x30]
00007583d7bd68d1  vpermilpd xmm14, xmm14, 0x00
00007583d7bd68d7  movaps xmm10, xmm9
00007583d7bd68db  vfmadd231pd xmm10, xmm7, xmm14
00007583d7bd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007583d7bd68e6  vptest xmm5, xmm5
00007583d7bd68eb  jnz 0x00007583D7BD7F2C
00007583d7bd68f1  lea r14, [rax+0x80]
00007583d7bd68f8  movups xmm14, [r13+r14*1]
00007583d7bd68fe  movaps [r15+0x2F0], xmm14
00007583d7bd6906  vmovaps xmm9, [rsp+0x30]
00007583d7bd690c  vpermilpd xmm9, xmm9, 0x00
00007583d7bd6912  vmovaps xmm7, [rsp+0x70]
00007583d7bd6918  movaps xmm5, xmm6
00007583d7bd691b  vfmadd231pd xmm5, xmm7, xmm9
00007583d7bd6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007583d7bd6925  vptest xmm3, xmm3
00007583d7bd692a  jnz 0x00007583D7BD808F
00007583d7bd6930  vmovaps xmm9, [rsp+0x30]
00007583d7bd6936  vpermilpd xmm9, xmm9, 0x00
00007583d7bd693c  movaps xmm7, xmm13
00007583d7bd6940  vfmadd231pd xmm7, xmm1, xmm9
00007583d7bd6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007583d7bd694a  vptest xmm6, xmm6
00007583d7bd694f  jnz 0x00007583D7BD81E5
00007583d7bd6955  vmovaps xmm1, [rsp+0x20]
00007583d7bd695b  vmovaps xmm13, [rsp+0x20]
00007583d7bd6961  por xmm1, xmm13
00007583d7bd6966  movaps [r15+0x160], xmm1
00007583d7bd696e  lea r14, [rax+0x40]
00007583d7bd6972  movups xmm13, [r13+r14*1]
00007583d7bd6978  lea r14, [rax+0x50]
00007583d7bd697c  movups xmm9, [r13+r14*1]
00007583d7bd6982  movaps [r15+0x1B0], xmm13
00007583d7bd698a  movaps [r15+0x1A0], xmm9
00007583d7bd6992  movaps xmm6, [r15+0x190]
00007583d7bd699a  vmovaps xmm3, [rsp+0xB0]
00007583d7bd69a3  vpermilpd xmm3, xmm3, 0x00
00007583d7bd69a9  vmovaps [rsp+0x20], xmm1
00007583d7bd69af  movaps xmm2, xmm12
00007583d7bd69b3  vfmadd231pd xmm2, xmm6, xmm3
00007583d7bd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007583d7bd69bd  vptest xmm1, xmm1
00007583d7bd69c2  jnz 0x00007583D7BD8350
00007583d7bd69c8  vmovaps xmm1, [rsp+0xB0]
00007583d7bd69d1  vpermilpd xmm1, xmm1, 0x00
00007583d7bd69d7  vmovaps xmm12, [rsp+0x20]
00007583d7bd69dd  movaps xmm6, xmm10
00007583d7bd69e1  vfmadd231pd xmm6, xmm12, xmm1
00007583d7bd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007583d7bd69eb  vptest xmm3, xmm3
00007583d7bd69f0  jnz 0x00007583D7BD84A6
00007583d7bd69f6  vmovaps xmm1, [rsp+0xB0]
00007583d7bd69ff  vpermilpd xmm1, xmm1, 0x00
00007583d7bd6a05  vmovaps xmm12, [rsp+0x40]
00007583d7bd6a0b  movaps xmm10, xmm5
00007583d7bd6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007583d7bd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007583d7bd6a1a  vptest xmm3, xmm3
00007583d7bd6a1f  jnz 0x00007583D7BD85FD
00007583d7bd6a25  vmovaps xmm1, [rsp+0xB0]
00007583d7bd6a2e  vpermilpd xmm1, xmm1, 0x00
00007583d7bd6a34  movaps xmm12, xmm7
00007583d7bd6a38  vfmadd231pd xmm12, xmm15, xmm1
00007583d7bd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007583d7bd6a43  vptest xmm5, xmm5
00007583d7bd6a48  jnz 0x00007583D7BD8755
00007583d7bd6a4e  lea r14, [rax+0x60]
00007583d7bd6a52  movups xmm1, [r13+r14*1]
00007583d7bd6a58  lea r14, [rax+0x70]
00007583d7bd6a5c  movups xmm15, [r13+r14*1]
00007583d7bd6a62  movaps [r15+0x150], xmm1
00007583d7bd6a6a  movaps [r15+0x120], xmm15
00007583d7bd6a72  vmovaps [rsp+0x20], xmm11
00007583d7bd6a78  vpermilpd xmm11, xmm11, 0x00
00007583d7bd6a7e  movaps xmm7, xmm2
00007583d7bd6a81  vfmadd231pd xmm7, xmm9, xmm11
00007583d7bd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007583d7bd6a8b  vptest xmm5, xmm5
00007583d7bd6a90  jnz 0x00007583D7BD88C1
00007583d7bd6a96  vmovaps xmm11, [rsp+0x20]
00007583d7bd6a9c  vpermilpd xmm11, xmm11, 0x00
00007583d7bd6aa2  movaps xmm9, xmm6
00007583d7bd6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007583d7bd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007583d7bd6ab1  vptest xmm5, xmm5
00007583d7bd6ab6  jnz 0x00007583D7BD8A18
00007583d7bd6abc  vmovaps xmm1, [rsp+0x20]
00007583d7bd6ac2  vpermilpd xmm1, xmm1, 0x00
00007583d7bd6ac8  movaps xmm11, xmm10
00007583d7bd6acc  vfmadd231pd xmm11, xmm8, xmm1
00007583d7bd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007583d7bd6ad7  vptest xmm6, xmm6
00007583d7bd6adc  jnz 0x00007583D7BD8B70
00007583d7bd6ae2  vmovaps xmm1, [rsp+0x20]
00007583d7bd6ae8  vpermilpd xmm1, xmm1, 0x00
00007583d7bd6aee  movaps xmm10, xmm12
00007583d7bd6af2  vfmadd231pd xmm10, xmm13, xmm1
00007583d7bd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007583d7bd6afd  vptest xmm8, xmm8
00007583d7bd6b02  jnz 0x00007583D7BD8CC9
00007583d7bd6b08  lea r14, [rax+0x20]
00007583d7bd6b0c  movups xmm1, [r13+r14*1]
00007583d7bd6b12  lea r14, [rax+0x30]
00007583d7bd6b16  movups xmm13, [r13+r14*1]
00007583d7bd6b1c  vmovaps xmm12, [rsp+0x90]
00007583d7bd6b25  vpermilpd xmm12, xmm12, 0x00
00007583d7bd6b2b  movaps xmm8, xmm7
00007583d7bd6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007583d7bd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007583d7bd6b3a  vptest xmm6, xmm6
00007583d7bd6b3f  jnz 0x00007583D7BD8E36
00007583d7bd6b45  vmovaps xmm12, [rsp+0x90]
00007583d7bd6b4e  vpermilpd xmm12, xmm12, 0x00
00007583d7bd6b54  movaps xmm7, xmm9
00007583d7bd6b58  vfmadd231pd xmm7, xmm14, xmm12
00007583d7bd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007583d7bd6b62  vptest xmm6, xmm6
00007583d7bd6b67  jnz 0x00007583D7BD8F8E
00007583d7bd6b6d  vmovaps xmm14, [rsp+0x90]
00007583d7bd6b76  vpermilpd xmm14, xmm14, 0x00
00007583d7bd6b7c  movaps xmm12, xmm11
00007583d7bd6b80  vfmadd231pd xmm12, xmm15, xmm14
00007583d7bd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007583d7bd6b8b  vptest xmm9, xmm9
00007583d7bd6b90  jnz 0x00007583D7BD90E6
00007583d7bd6b96  vmovaps xmm15, [rsp+0x90]
00007583d7bd6b9f  vpermilpd xmm15, xmm15, 0x00
00007583d7bd6ba5  movaps xmm11, xmm10
00007583d7bd6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007583d7bd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007583d7bd6bb4  vptest xmm14, xmm14
00007583d7bd6bb9  jnz 0x00007583D7BD9240
00007583d7bd6bbf  lea r14, [rax+0x90]
00007583d7bd6bc6  movups xmm15, [r13+r14*1]
00007583d7bd6bcc  lea r14, [rax+0xA0]
00007583d7bd6bd3  movups xmm14, [r13+r14*1]
00007583d7bd6bd9  movaps [r15+0x140], xmm15
00007583d7bd6be1  movaps [r15+0x130], xmm14
00007583d7bd6be9  vmovaps xmm13, [rsp+0x10]
00007583d7bd6bef  vpermilpd xmm13, xmm13, 0x00
00007583d7bd6bf5  movaps xmm10, xmm8
00007583d7bd6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007583d7bd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007583d7bd6c04  vptest xmm9, xmm9
00007583d7bd6c09  jnz 0x00007583D7BD93AE
00007583d7bd6c0f  movaps [r15+0x220], xmm10
00007583d7bd6c17  lea r14, [rax+0x10]
00007583d7bd6c1b  movups xmm1, [r13+r14*1]
00007583d7bd6c21  movaps [r15+0x240], xmm1
00007583d7bd6c29  vmovaps xmm13, [rsp+0x10]
00007583d7bd6c2f  vpermilpd xmm13, xmm13, 0x00
00007583d7bd6c35  movaps xmm9, xmm7
00007583d7bd6c39  vfmadd231pd xmm9, xmm14, xmm13
00007583d7bd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007583d7bd6c44  vptest xmm8, xmm8
00007583d7bd6c49  jnz 0x00007583D7BD9511
00007583d7bd6c4f  movaps [r15+0x110], xmm9
00007583d7bd6c57  vmovaps xmm14, [rsp+0x10]
00007583d7bd6c5d  vpermilpd xmm14, xmm14, 0x00
00007583d7bd6c63  movaps xmm13, xmm12
00007583d7bd6c67  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007583d7bd6c72  vptest xmm8, xmm8
00007583d7bd6c77  jnz 0x00007583D7BD966A
00007583d7bd6c7d  movaps [r15+0x170], xmm13
00007583d7bd6c85  vmovaps xmm15, [rsp+0x10]
00007583d7bd6c8b  vpermilpd xmm15, xmm15, 0x00
00007583d7bd6c91  movaps xmm14, xmm11
00007583d7bd6c95  vfmadd231pd xmm14, xmm1, xmm15
00007583d7bd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007583d7bd6ca0  vptest xmm12, xmm12
00007583d7bd6ca5  jnz 0x00007583D7BD97C4
00007583d7bd6cab  movaps [r15+0x230], xmm14
00007583d7bd6cb3  movups [r13+r11*1], xmm9
00007583d7bd6cb9  lea rax, [r11+0x10]
00007583d7bd6cbd  movups [r13+rax*1], xmm13
00007583d7bd6cc3  lea rax, [r11+0x20]
00007583d7bd6cc7  movups [r13+rax*1], xmm10
00007583d7bd6ccd  lea rax, [r11+0x30]
00007583d7bd6cd1  movups [r13+rax*1], xmm14
00007583d7bd6cd7  mov eax, [r15+0x108]
00007583d7bd6cde  sahf
00007583d7bd6cdf  jnz 0x00007583D7BD6D11
00007583d7bd6ce1  cmp dword ptr [r15+0x318], 0x00
00007583d7bd6ce9  jz 0x00007583D7BD9950
00007583d7bd6cef  nop [rax+rax*1], ax
00007583d7bd6cf8  nop [rax+rax*1], eax
00007583d7bd6d00  mov eax, 0x410664
00007583d7bd6d05  mov [r15+0x100], rax
00007583d7bd6d0c  jmp 0x00007583D79FE110
00007583d7bd6d11  cmp dword ptr [r15+0x318], 0x00
00007583d7bd6d19  jz 0x00007583D7BD6050
00007583d7bd6d1f  nop [rax+rax*1], ax
00007583d7bd6d28  nop [rax+rax*1], eax
00007583d7bd6d30  mov eax, 0x4104F0
00007583d7bd6d35  mov [r15+0x100], rax
00007583d7bd6d3c  jmp 0x00007583D79FE110
00007583d7bd6d41  int3
00007583d7bd6d42  call 0x00007583D7A0A4B0
00007583d7bd6d47  jmp 0x00007583D7BD6079
00007583d7bd6d4c  call 0x00007583D7A09240
00007583d7bd6d51  jmp 0x00007583D7BD6083
00007583d7bd6d56  call 0x00007583D7A0A4B0
00007583d7bd6d5b  jmp 0x00007583D7BD60CD
00007583d7bd6d60  call 0x00007583D7A09240
00007583d7bd6d65  jmp 0x00007583D7BD60D7
00007583d7bd6d6a  call 0x00007583D7A0A4B0
00007583d7bd6d6f  jmp 0x00007583D7BD6158
00007583d7bd6d74  call 0x00007583D7A09240
00007583d7bd6d79  jmp 0x00007583D7BD6162
00007583d7bd6d7e  call 0x00007583D7AB47C0
00007583d7bd6d83  jmp 0x00007583D7BD6243
00007583d7bd6d88  call 0x00007583D79FF430
00007583d7bd6d8d  jmp 0x00007583D7BD6272
00007583d7bd6d92  call 0x00007583D7AB0CE0
00007583d7bd6d97  jmp 0x00007583D7BD628E
00007583d7bd6d9c  sub rsp, 0x08
00007583d7bd6da0  push rax
00007583d7bd6da1  push rcx
00007583d7bd6da2  push rdx
00007583d7bd6da3  push rdi
00007583d7bd6da4  push rsi
00007583d7bd6da5  push r8
00007583d7bd6da7  push r9
00007583d7bd6da9  push r10
00007583d7bd6dab  push r11
00007583d7bd6dad  sub rsp, 0xF0
00007583d7bd6db4  vmovaps [rsp], xmm0
00007583d7bd6db9  vmovaps [rsp+0x10], xmm1
00007583d7bd6dbf  vmovaps [rsp+0x20], xmm2
00007583d7bd6dc5  vmovaps [rsp+0x30], xmm3
00007583d7bd6dcb  vmovaps [rsp+0x40], xmm4
00007583d7bd6dd1  vmovaps [rsp+0x50], xmm5
00007583d7bd6dd7  vmovaps [rsp+0x60], xmm6
00007583d7bd6ddd  vmovaps [rsp+0x70], xmm7
00007583d7bd6de3  vmovaps [rsp+0x80], xmm8
00007583d7bd6dec  vmovaps [rsp+0x90], xmm9
00007583d7bd6df5  vmovaps [rsp+0xA0], xmm10
00007583d7bd6dfe  vmovaps [rsp+0xB0], xmm11
00007583d7bd6e07  vmovaps [rsp+0xC0], xmm12
00007583d7bd6e10  vmovaps [rsp+0xD0], xmm14
00007583d7bd6e19  vmovaps [rsp+0xE0], xmm15
00007583d7bd6e22  sub rsp, 0x40
00007583d7bd6e26  lea rdi, [rsp]
00007583d7bd6e2a  lea rsi, [rsp+0x10]
00007583d7bd6e2f  lea rdx, [rsp+0x20]
00007583d7bd6e34  lea rcx, [rsp+0x30]
00007583d7bd6e39  mov r8d, 0x00
00007583d7bd6e3f  lea r9, [r15+0x3A8]
00007583d7bd6e46  movaps [rdi], xmm13
00007583d7bd6e4a  movaps [rsi], xmm1
00007583d7bd6e4d  movaps [rdx], xmm15
00007583d7bd6e51  movaps [rcx], xmm14
00007583d7bd6e55  mov rax, 0x5BCB7EA35A50
00007583d7bd6e5f  call rax
00007583d7bd6e61  movaps xmm13, [rsp]
00007583d7bd6e66  add rsp, 0x40
00007583d7bd6e6a  vmovaps xmm0, [rsp]
00007583d7bd6e6f  vmovaps xmm1, [rsp+0x10]
00007583d7bd6e75  vmovaps xmm2, [rsp+0x20]
00007583d7bd6e7b  vmovaps xmm3, [rsp+0x30]
00007583d7bd6e81  vmovaps xmm4, [rsp+0x40]
00007583d7bd6e87  vmovaps xmm5, [rsp+0x50]
00007583d7bd6e8d  vmovaps xmm6, [rsp+0x60]
00007583d7bd6e93  vmovaps xmm7, [rsp+0x70]
00007583d7bd6e99  vmovaps xmm8, [rsp+0x80]
00007583d7bd6ea2  vmovaps xmm9, [rsp+0x90]
00007583d7bd6eab  vmovaps xmm10, [rsp+0xA0]
00007583d7bd6eb4  vmovaps xmm11, [rsp+0xB0]
00007583d7bd6ebd  vmovaps xmm12, [rsp+0xC0]
00007583d7bd6ec6  vmovaps xmm14, [rsp+0xD0]
00007583d7bd6ecf  vmovaps xmm15, [rsp+0xE0]
00007583d7bd6ed8  add rsp, 0xF0
00007583d7bd6edf  pop r11
00007583d7bd6ee1  pop r10
00007583d7bd6ee3  pop r9
00007583d7bd6ee5  pop r8
00007583d7bd6ee7  pop rsi
00007583d7bd6ee8  pop rdi
00007583d7bd6ee9  pop rdx
00007583d7bd6eea  pop rcx
00007583d7bd6eeb  pop rax
00007583d7bd6eec  add rsp, 0x08
00007583d7bd6ef0  jmp 0x00007583D7BD6305
00007583d7bd6ef5  sub rsp, 0x08
00007583d7bd6ef9  push rax
00007583d7bd6efa  push rcx
00007583d7bd6efb  push rdx
00007583d7bd6efc  push rdi
00007583d7bd6efd  push rsi
00007583d7bd6efe  push r8
00007583d7bd6f00  push r9
00007583d7bd6f02  push r10
00007583d7bd6f04  push r11
00007583d7bd6f06  sub rsp, 0xF0
00007583d7bd6f0d  vmovaps [rsp], xmm0
00007583d7bd6f12  vmovaps [rsp+0x10], xmm1
00007583d7bd6f18  vmovaps [rsp+0x20], xmm2
00007583d7bd6f1e  vmovaps [rsp+0x30], xmm3
00007583d7bd6f24  vmovaps [rsp+0x40], xmm4
00007583d7bd6f2a  vmovaps [rsp+0x50], xmm5
00007583d7bd6f30  vmovaps [rsp+0x60], xmm6
00007583d7bd6f36  vmovaps [rsp+0x70], xmm7
00007583d7bd6f3c  vmovaps [rsp+0x80], xmm8
00007583d7bd6f45  vmovaps [rsp+0x90], xmm9
00007583d7bd6f4e  vmovaps [rsp+0xA0], xmm10
00007583d7bd6f57  vmovaps [rsp+0xB0], xmm11
00007583d7bd6f60  vmovaps [rsp+0xC0], xmm13
00007583d7bd6f69  vmovaps [rsp+0xD0], xmm14
00007583d7bd6f72  vmovaps [rsp+0xE0], xmm15
00007583d7bd6f7b  sub rsp, 0x40
00007583d7bd6f7f  lea rdi, [rsp]
00007583d7bd6f83  lea rsi, [rsp+0x10]
00007583d7bd6f88  lea rdx, [rsp+0x20]
00007583d7bd6f8d  lea rcx, [rsp+0x30]
00007583d7bd6f92  mov r8d, 0x00
00007583d7bd6f98  lea r9, [r15+0x3A8]
00007583d7bd6f9f  movaps [rdi], xmm12
00007583d7bd6fa3  movaps [rsi], xmm15
00007583d7bd6fa7  movaps [rdx], xmm1
00007583d7bd6faa  movaps [rcx], xmm14
00007583d7bd6fae  mov rax, 0x5BCB7EA35A50
00007583d7bd6fb8  call rax
00007583d7bd6fba  movaps xmm12, [rsp]
00007583d7bd6fbf  add rsp, 0x40
00007583d7bd6fc3  vmovaps xmm0, [rsp]
00007583d7bd6fc8  vmovaps xmm1, [rsp+0x10]
00007583d7bd6fce  vmovaps xmm2, [rsp+0x20]
00007583d7bd6fd4  vmovaps xmm3, [rsp+0x30]
00007583d7bd6fda  vmovaps xmm4, [rsp+0x40]
00007583d7bd6fe0  vmovaps xmm5, [rsp+0x50]
00007583d7bd6fe6  vmovaps xmm6, [rsp+0x60]
00007583d7bd6fec  vmovaps xmm7, [rsp+0x70]
00007583d7bd6ff2  vmovaps xmm8, [rsp+0x80]
00007583d7bd6ffb  vmovaps xmm9, [rsp+0x90]
00007583d7bd7004  vmovaps xmm10, [rsp+0xA0]
00007583d7bd700d  vmovaps xmm11, [rsp+0xB0]
00007583d7bd7016  vmovaps xmm13, [rsp+0xC0]
00007583d7bd701f  vmovaps xmm14, [rsp+0xD0]
00007583d7bd7028  vmovaps xmm15, [rsp+0xE0]
00007583d7bd7031  add rsp, 0xF0
00007583d7bd7038  pop r11
00007583d7bd703a  pop r10
00007583d7bd703c  pop r9
00007583d7bd703e  pop r8
00007583d7bd7040  pop rsi
00007583d7bd7041  pop rdi
00007583d7bd7042  pop rdx
00007583d7bd7043  pop rcx
00007583d7bd7044  pop rax
00007583d7bd7045  add rsp, 0x08
00007583d7bd7049  jmp 0x00007583D7BD6333
00007583d7bd704e  call 0x00007583D7AD64F0
00007583d7bd7053  jmp 0x00007583D7BD641F
00007583d7bd7058  sub rsp, 0x08
00007583d7bd705c  push rax
00007583d7bd705d  push rcx
00007583d7bd705e  push rdx
00007583d7bd705f  push rdi
00007583d7bd7060  push rsi
00007583d7bd7061  push r8
00007583d7bd7063  push r9
00007583d7bd7065  push r10
00007583d7bd7067  push r11
00007583d7bd7069  sub rsp, 0xF0
00007583d7bd7070  vmovaps [rsp], xmm0
00007583d7bd7075  vmovaps [rsp+0x10], xmm1
00007583d7bd707b  vmovaps [rsp+0x20], xmm2
00007583d7bd7081  vmovaps [rsp+0x30], xmm3
00007583d7bd7087  vmovaps [rsp+0x40], xmm4
00007583d7bd708d  vmovaps [rsp+0x50], xmm5
00007583d7bd7093  vmovaps [rsp+0x60], xmm6
00007583d7bd7099  vmovaps [rsp+0x70], xmm7
00007583d7bd709f  vmovaps [rsp+0x80], xmm8
00007583d7bd70a8  vmovaps [rsp+0x90], xmm9
00007583d7bd70b1  vmovaps [rsp+0xA0], xmm10
00007583d7bd70ba  vmovaps [rsp+0xB0], xmm11
00007583d7bd70c3  vmovaps [rsp+0xC0], xmm12
00007583d7bd70cc  vmovaps [rsp+0xD0], xmm14
00007583d7bd70d5  vmovaps [rsp+0xE0], xmm15
00007583d7bd70de  sub rsp, 0x40
00007583d7bd70e2  lea rdi, [rsp]
00007583d7bd70e6  lea rsi, [rsp+0x10]
00007583d7bd70eb  lea rdx, [rsp+0x20]
00007583d7bd70f0  lea rcx, [rsp+0x30]
00007583d7bd70f5  mov r8d, 0x00
00007583d7bd70fb  lea r9, [r15+0x3A8]
00007583d7bd7102  movaps [rdi], xmm13
00007583d7bd7106  movaps [rsi], xmm1
00007583d7bd7109  movaps [rdx], xmm15
00007583d7bd710d  movaps [rcx], xmm14
00007583d7bd7111  mov rax, 0x5BCB7EA35A50
00007583d7bd711b  call rax
00007583d7bd711d  movaps xmm13, [rsp]
00007583d7bd7122  add rsp, 0x40
00007583d7bd7126  vmovaps xmm0, [rsp]
00007583d7bd712b  vmovaps xmm1, [rsp+0x10]
00007583d7bd7131  vmovaps xmm2, [rsp+0x20]
00007583d7bd7137  vmovaps xmm3, [rsp+0x30]
00007583d7bd713d  vmovaps xmm4, [rsp+0x40]
00007583d7bd7143  vmovaps xmm5, [rsp+0x50]
00007583d7bd7149  vmovaps xmm6, [rsp+0x60]
00007583d7bd714f  vmovaps xmm7, [rsp+0x70]
00007583d7bd7155  vmovaps xmm8, [rsp+0x80]
00007583d7bd715e  vmovaps xmm9, [rsp+0x90]
00007583d7bd7167  vmovaps xmm10, [rsp+0xA0]
00007583d7bd7170  vmovaps xmm11, [rsp+0xB0]
00007583d7bd7179  vmovaps xmm12, [rsp+0xC0]
00007583d7bd7182  vmovaps xmm14, [rsp+0xD0]
00007583d7bd718b  vmovaps xmm15, [rsp+0xE0]
00007583d7bd7194  add rsp, 0xF0
00007583d7bd719b  pop r11
00007583d7bd719d  pop r10
00007583d7bd719f  pop r9
00007583d7bd71a1  pop r8
00007583d7bd71a3  pop rsi
00007583d7bd71a4  pop rdi
00007583d7bd71a5  pop rdx
00007583d7bd71a6  pop rcx
00007583d7bd71a7  pop rax
00007583d7bd71a8  add rsp, 0x08
00007583d7bd71ac  jmp 0x00007583D7BD648E
00007583d7bd71b1  call 0x00007583D7AD64F0
00007583d7bd71b6  jmp 0x00007583D7BD64A3
00007583d7bd71bb  sub rsp, 0x08
00007583d7bd71bf  push rax
00007583d7bd71c0  push rcx
00007583d7bd71c1  push rdx
00007583d7bd71c2  push rdi
00007583d7bd71c3  push rsi
00007583d7bd71c4  push r8
00007583d7bd71c6  push r9
00007583d7bd71c8  push r10
00007583d7bd71ca  push r11
00007583d7bd71cc  sub rsp, 0xF0
00007583d7bd71d3  vmovaps [rsp], xmm0
00007583d7bd71d8  vmovaps [rsp+0x10], xmm1
00007583d7bd71de  vmovaps [rsp+0x20], xmm2
00007583d7bd71e4  vmovaps [rsp+0x30], xmm3
00007583d7bd71ea  vmovaps [rsp+0x40], xmm4
00007583d7bd71f0  vmovaps [rsp+0x50], xmm5
00007583d7bd71f6  vmovaps [rsp+0x60], xmm6
00007583d7bd71fc  vmovaps [rsp+0x70], xmm7
00007583d7bd7202  vmovaps [rsp+0x80], xmm8
00007583d7bd720b  vmovaps [rsp+0x90], xmm9
00007583d7bd7214  vmovaps [rsp+0xA0], xmm10
00007583d7bd721d  vmovaps [rsp+0xB0], xmm11
00007583d7bd7226  vmovaps [rsp+0xC0], xmm13
00007583d7bd722f  vmovaps [rsp+0xD0], xmm14
00007583d7bd7238  vmovaps [rsp+0xE0], xmm15
00007583d7bd7241  sub rsp, 0x40
00007583d7bd7245  lea rdi, [rsp]
00007583d7bd7249  lea rsi, [rsp+0x10]
00007583d7bd724e  lea rdx, [rsp+0x20]
00007583d7bd7253  lea rcx, [rsp+0x30]
00007583d7bd7258  mov r8d, 0x00
00007583d7bd725e  lea r9, [r15+0x3A8]
00007583d7bd7265  movaps [rdi], xmm12
00007583d7bd7269  movaps [rsi], xmm15
00007583d7bd726d  movaps [rdx], xmm1
00007583d7bd7270  movaps [rcx], xmm14
00007583d7bd7274  mov rax, 0x5BCB7EA35A50
00007583d7bd727e  call rax
00007583d7bd7280  movaps xmm12, [rsp]
00007583d7bd7285  add rsp, 0x40
00007583d7bd7289  vmovaps xmm0, [rsp]
00007583d7bd728e  vmovaps xmm1, [rsp+0x10]
00007583d7bd7294  vmovaps xmm2, [rsp+0x20]
00007583d7bd729a  vmovaps xmm3, [rsp+0x30]
00007583d7bd72a0  vmovaps xmm4, [rsp+0x40]
00007583d7bd72a6  vmovaps xmm5, [rsp+0x50]
00007583d7bd72ac  vmovaps xmm6, [rsp+0x60]
00007583d7bd72b2  vmovaps xmm7, [rsp+0x70]
00007583d7bd72b8  vmovaps xmm8, [rsp+0x80]
00007583d7bd72c1  vmovaps xmm9, [rsp+0x90]
00007583d7bd72ca  vmovaps xmm10, [rsp+0xA0]
00007583d7bd72d3  vmovaps xmm11, [rsp+0xB0]
00007583d7bd72dc  vmovaps xmm13, [rsp+0xC0]
00007583d7bd72e5  vmovaps xmm14, [rsp+0xD0]
00007583d7bd72ee  vmovaps xmm15, [rsp+0xE0]
00007583d7bd72f7  add rsp, 0xF0
00007583d7bd72fe  pop r11
00007583d7bd7300  pop r10
00007583d7bd7302  pop r9
00007583d7bd7304  pop r8
00007583d7bd7306  pop rsi
00007583d7bd7307  pop rdi
00007583d7bd7308  pop rdx
00007583d7bd7309  pop rcx
00007583d7bd730a  pop rax
00007583d7bd730b  add rsp, 0x08
00007583d7bd730f  jmp 0x00007583D7BD64CF
00007583d7bd7314  sub rsp, 0x08
00007583d7bd7318  push rax
00007583d7bd7319  push rcx
00007583d7bd731a  push rdx
00007583d7bd731b  push rdi
00007583d7bd731c  push rsi
00007583d7bd731d  push r8
00007583d7bd731f  push r9
00007583d7bd7321  push r10
00007583d7bd7323  push r11
00007583d7bd7325  sub rsp, 0xF0
00007583d7bd732c  vmovaps [rsp], xmm0
00007583d7bd7331  vmovaps [rsp+0x10], xmm1
00007583d7bd7337  vmovaps [rsp+0x20], xmm2
00007583d7bd733d  vmovaps [rsp+0x30], xmm3
00007583d7bd7343  vmovaps [rsp+0x40], xmm4
00007583d7bd7349  vmovaps [rsp+0x50], xmm5
00007583d7bd734f  vmovaps [rsp+0x60], xmm6
00007583d7bd7355  vmovaps [rsp+0x70], xmm7
00007583d7bd735b  vmovaps [rsp+0x80], xmm8
00007583d7bd7364  vmovaps [rsp+0x90], xmm9
00007583d7bd736d  vmovaps [rsp+0xA0], xmm10
00007583d7bd7376  vmovaps [rsp+0xB0], xmm11
00007583d7bd737f  vmovaps [rsp+0xC0], xmm12
00007583d7bd7388  vmovaps [rsp+0xD0], xmm14
00007583d7bd7391  vmovaps [rsp+0xE0], xmm15
00007583d7bd739a  sub rsp, 0x40
00007583d7bd739e  lea rdi, [rsp]
00007583d7bd73a2  lea rsi, [rsp+0x10]
00007583d7bd73a7  lea rdx, [rsp+0x20]
00007583d7bd73ac  lea rcx, [rsp+0x30]
00007583d7bd73b1  mov r8d, 0x00
00007583d7bd73b7  lea r9, [r15+0x3A8]
00007583d7bd73be  movaps [rdi], xmm13
00007583d7bd73c2  movaps [rsi], xmm1
00007583d7bd73c5  movaps [rdx], xmm15
00007583d7bd73c9  movaps [rcx], xmm14
00007583d7bd73cd  mov rax, 0x5BCB7EA35A50
00007583d7bd73d7  call rax
00007583d7bd73d9  movaps xmm13, [rsp]
00007583d7bd73de  add rsp, 0x40
00007583d7bd73e2  vmovaps xmm0, [rsp]
00007583d7bd73e7  vmovaps xmm1, [rsp+0x10]
00007583d7bd73ed  vmovaps xmm2, [rsp+0x20]
00007583d7bd73f3  vmovaps xmm3, [rsp+0x30]
00007583d7bd73f9  vmovaps xmm4, [rsp+0x40]
00007583d7bd73ff  vmovaps xmm5, [rsp+0x50]
00007583d7bd7405  vmovaps xmm6, [rsp+0x60]
00007583d7bd740b  vmovaps xmm7, [rsp+0x70]
00007583d7bd7411  vmovaps xmm8, [rsp+0x80]
00007583d7bd741a  vmovaps xmm9, [rsp+0x90]
00007583d7bd7423  vmovaps xmm10, [rsp+0xA0]
00007583d7bd742c  vmovaps xmm11, [rsp+0xB0]
00007583d7bd7435  vmovaps xmm12, [rsp+0xC0]
00007583d7bd743e  vmovaps xmm14, [rsp+0xD0]
00007583d7bd7447  vmovaps xmm15, [rsp+0xE0]
00007583d7bd7450  add rsp, 0xF0
00007583d7bd7457  pop r11
00007583d7bd7459  pop r10
00007583d7bd745b  pop r9
00007583d7bd745d  pop r8
00007583d7bd745f  pop rsi
00007583d7bd7460  pop rdi
00007583d7bd7461  pop rdx
00007583d7bd7462  pop rcx
00007583d7bd7463  pop rax
00007583d7bd7464  add rsp, 0x08
00007583d7bd7468  jmp 0x00007583D7BD665F
00007583d7bd746d  sub rsp, 0x08
00007583d7bd7471  push rax
00007583d7bd7472  push rcx
00007583d7bd7473  push rdx
00007583d7bd7474  push rdi
00007583d7bd7475  push rsi
00007583d7bd7476  push r8
00007583d7bd7478  push r9
00007583d7bd747a  push r10
00007583d7bd747c  push r11
00007583d7bd747e  sub rsp, 0xF0
00007583d7bd7485  vmovaps [rsp], xmm0
00007583d7bd748a  vmovaps [rsp+0x10], xmm1
00007583d7bd7490  vmovaps [rsp+0x20], xmm2
00007583d7bd7496  vmovaps [rsp+0x30], xmm3
00007583d7bd749c  vmovaps [rsp+0x40], xmm4
00007583d7bd74a2  vmovaps [rsp+0x50], xmm5
00007583d7bd74a8  vmovaps [rsp+0x60], xmm6
00007583d7bd74ae  vmovaps [rsp+0x70], xmm7
00007583d7bd74b4  vmovaps [rsp+0x80], xmm8
00007583d7bd74bd  vmovaps [rsp+0x90], xmm9
00007583d7bd74c6  vmovaps [rsp+0xA0], xmm10
00007583d7bd74cf  vmovaps [rsp+0xB0], xmm11
00007583d7bd74d8  vmovaps [rsp+0xC0], xmm12
00007583d7bd74e1  vmovaps [rsp+0xD0], xmm13
00007583d7bd74ea  vmovaps [rsp+0xE0], xmm15
00007583d7bd74f3  sub rsp, 0x40
00007583d7bd74f7  lea rdi, [rsp]
00007583d7bd74fb  lea rsi, [rsp+0x10]
00007583d7bd7500  lea rdx, [rsp+0x20]
00007583d7bd7505  lea rcx, [rsp+0x30]
00007583d7bd750a  mov r8d, 0x00
00007583d7bd7510  lea r9, [r15+0x3A8]
00007583d7bd7517  movaps [rdi], xmm14
00007583d7bd751b  movaps [rsi], xmm15
00007583d7bd751f  movaps [rdx], xmm2
00007583d7bd7522  movaps [rcx], xmm1
00007583d7bd7525  mov rax, 0x5BCB7EA35A50
00007583d7bd752f  call rax
00007583d7bd7531  movaps xmm14, [rsp]
00007583d7bd7536  add rsp, 0x40
00007583d7bd753a  vmovaps xmm0, [rsp]
00007583d7bd753f  vmovaps xmm1, [rsp+0x10]
00007583d7bd7545  vmovaps xmm2, [rsp+0x20]
00007583d7bd754b  vmovaps xmm3, [rsp+0x30]
00007583d7bd7551  vmovaps xmm4, [rsp+0x40]
00007583d7bd7557  vmovaps xmm5, [rsp+0x50]
00007583d7bd755d  vmovaps xmm6, [rsp+0x60]
00007583d7bd7563  vmovaps xmm7, [rsp+0x70]
00007583d7bd7569  vmovaps xmm8, [rsp+0x80]
00007583d7bd7572  vmovaps xmm9, [rsp+0x90]
00007583d7bd757b  vmovaps xmm10, [rsp+0xA0]
00007583d7bd7584  vmovaps xmm11, [rsp+0xB0]
00007583d7bd758d  vmovaps xmm12, [rsp+0xC0]
00007583d7bd7596  vmovaps xmm13, [rsp+0xD0]
00007583d7bd759f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd75a8  add rsp, 0xF0
00007583d7bd75af  pop r11
00007583d7bd75b1  pop r10
00007583d7bd75b3  pop r9
00007583d7bd75b5  pop r8
00007583d7bd75b7  pop rsi
00007583d7bd75b8  pop rdi
00007583d7bd75b9  pop rdx
00007583d7bd75ba  pop rcx
00007583d7bd75bb  pop rax
00007583d7bd75bc  add rsp, 0x08
00007583d7bd75c0  jmp 0x00007583D7BD6691
00007583d7bd75c5  sub rsp, 0x08
00007583d7bd75c9  push rax
00007583d7bd75ca  push rcx
00007583d7bd75cb  push rdx
00007583d7bd75cc  push rdi
00007583d7bd75cd  push rsi
00007583d7bd75ce  push r8
00007583d7bd75d0  push r9
00007583d7bd75d2  push r10
00007583d7bd75d4  push r11
00007583d7bd75d6  sub rsp, 0xF0
00007583d7bd75dd  vmovaps [rsp], xmm0
00007583d7bd75e2  vmovaps [rsp+0x10], xmm1
00007583d7bd75e8  vmovaps [rsp+0x20], xmm3
00007583d7bd75ee  vmovaps [rsp+0x30], xmm4
00007583d7bd75f4  vmovaps [rsp+0x40], xmm5
00007583d7bd75fa  vmovaps [rsp+0x50], xmm6
00007583d7bd7600  vmovaps [rsp+0x60], xmm7
00007583d7bd7606  vmovaps [rsp+0x70], xmm8
00007583d7bd760c  vmovaps [rsp+0x80], xmm9
00007583d7bd7615  vmovaps [rsp+0x90], xmm10
00007583d7bd761e  vmovaps [rsp+0xA0], xmm11
00007583d7bd7627  vmovaps [rsp+0xB0], xmm12
00007583d7bd7630  vmovaps [rsp+0xC0], xmm13
00007583d7bd7639  vmovaps [rsp+0xD0], xmm14
00007583d7bd7642  vmovaps [rsp+0xE0], xmm15
00007583d7bd764b  sub rsp, 0x40
00007583d7bd764f  lea rdi, [rsp]
00007583d7bd7653  lea rsi, [rsp+0x10]
00007583d7bd7658  lea rdx, [rsp+0x20]
00007583d7bd765d  lea rcx, [rsp+0x30]
00007583d7bd7662  mov r8d, 0x00
00007583d7bd7668  lea r9, [r15+0x3A8]
00007583d7bd766f  movaps [rdi], xmm2
00007583d7bd7672  movaps [rsi], xmm15
00007583d7bd7676  movaps [rdx], xmm12
00007583d7bd767a  movaps [rcx], xmm1
00007583d7bd767d  mov rax, 0x5BCB7EA35A50
00007583d7bd7687  call rax
00007583d7bd7689  movaps xmm2, [rsp]
00007583d7bd768d  add rsp, 0x40
00007583d7bd7691  vmovaps xmm0, [rsp]
00007583d7bd7696  vmovaps xmm1, [rsp+0x10]
00007583d7bd769c  vmovaps xmm3, [rsp+0x20]
00007583d7bd76a2  vmovaps xmm4, [rsp+0x30]
00007583d7bd76a8  vmovaps xmm5, [rsp+0x40]
00007583d7bd76ae  vmovaps xmm6, [rsp+0x50]
00007583d7bd76b4  vmovaps xmm7, [rsp+0x60]
00007583d7bd76ba  vmovaps xmm8, [rsp+0x70]
00007583d7bd76c0  vmovaps xmm9, [rsp+0x80]
00007583d7bd76c9  vmovaps xmm10, [rsp+0x90]
00007583d7bd76d2  vmovaps xmm11, [rsp+0xA0]
00007583d7bd76db  vmovaps xmm12, [rsp+0xB0]
00007583d7bd76e4  vmovaps xmm13, [rsp+0xC0]
00007583d7bd76ed  vmovaps xmm14, [rsp+0xD0]
00007583d7bd76f6  vmovaps xmm15, [rsp+0xE0]
00007583d7bd76ff  add rsp, 0xF0
00007583d7bd7706  pop r11
00007583d7bd7708  pop r10
00007583d7bd770a  pop r9
00007583d7bd770c  pop r8
00007583d7bd770e  pop rsi
00007583d7bd770f  pop rdi
00007583d7bd7710  pop rdx
00007583d7bd7711  pop rcx
00007583d7bd7712  pop rax
00007583d7bd7713  add rsp, 0x08
00007583d7bd7717  jmp 0x00007583D7BD66CE
00007583d7bd771c  sub rsp, 0x08
00007583d7bd7720  push rax
00007583d7bd7721  push rcx
00007583d7bd7722  push rdx
00007583d7bd7723  push rdi
00007583d7bd7724  push rsi
00007583d7bd7725  push r8
00007583d7bd7727  push r9
00007583d7bd7729  push r10
00007583d7bd772b  push r11
00007583d7bd772d  sub rsp, 0xF0
00007583d7bd7734  vmovaps [rsp], xmm0
00007583d7bd7739  vmovaps [rsp+0x10], xmm1
00007583d7bd773f  vmovaps [rsp+0x20], xmm2
00007583d7bd7745  vmovaps [rsp+0x30], xmm3
00007583d7bd774b  vmovaps [rsp+0x40], xmm4
00007583d7bd7751  vmovaps [rsp+0x50], xmm5
00007583d7bd7757  vmovaps [rsp+0x60], xmm6
00007583d7bd775d  vmovaps [rsp+0x70], xmm7
00007583d7bd7763  vmovaps [rsp+0x80], xmm8
00007583d7bd776c  vmovaps [rsp+0x90], xmm9
00007583d7bd7775  vmovaps [rsp+0xA0], xmm10
00007583d7bd777e  vmovaps [rsp+0xB0], xmm11
00007583d7bd7787  vmovaps [rsp+0xC0], xmm13
00007583d7bd7790  vmovaps [rsp+0xD0], xmm14
00007583d7bd7799  vmovaps [rsp+0xE0], xmm15
00007583d7bd77a2  sub rsp, 0x40
00007583d7bd77a6  lea rdi, [rsp]
00007583d7bd77aa  lea rsi, [rsp+0x10]
00007583d7bd77af  lea rdx, [rsp+0x20]
00007583d7bd77b4  lea rcx, [rsp+0x30]
00007583d7bd77b9  mov r8d, 0x00
00007583d7bd77bf  lea r9, [r15+0x3A8]
00007583d7bd77c6  movaps [rdi], xmm12
00007583d7bd77ca  movaps [rsi], xmm14
00007583d7bd77ce  movaps [rdx], xmm3
00007583d7bd77d1  movaps [rcx], xmm15
00007583d7bd77d5  mov rax, 0x5BCB7EA35A50
00007583d7bd77df  call rax
00007583d7bd77e1  movaps xmm12, [rsp]
00007583d7bd77e6  add rsp, 0x40
00007583d7bd77ea  vmovaps xmm0, [rsp]
00007583d7bd77ef  vmovaps xmm1, [rsp+0x10]
00007583d7bd77f5  vmovaps xmm2, [rsp+0x20]
00007583d7bd77fb  vmovaps xmm3, [rsp+0x30]
00007583d7bd7801  vmovaps xmm4, [rsp+0x40]
00007583d7bd7807  vmovaps xmm5, [rsp+0x50]
00007583d7bd780d  vmovaps xmm6, [rsp+0x60]
00007583d7bd7813  vmovaps xmm7, [rsp+0x70]
00007583d7bd7819  vmovaps xmm8, [rsp+0x80]
00007583d7bd7822  vmovaps xmm9, [rsp+0x90]
00007583d7bd782b  vmovaps xmm10, [rsp+0xA0]
00007583d7bd7834  vmovaps xmm11, [rsp+0xB0]
00007583d7bd783d  vmovaps xmm13, [rsp+0xC0]
00007583d7bd7846  vmovaps xmm14, [rsp+0xD0]
00007583d7bd784f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd7858  add rsp, 0xF0
00007583d7bd785f  pop r11
00007583d7bd7861  pop r10
00007583d7bd7863  pop r9
00007583d7bd7865  pop r8
00007583d7bd7867  pop rsi
00007583d7bd7868  pop rdi
00007583d7bd7869  pop rdx
00007583d7bd786a  pop rcx
00007583d7bd786b  pop rax
00007583d7bd786c  add rsp, 0x08
00007583d7bd7870  jmp 0x00007583D7BD6728
00007583d7bd7875  sub rsp, 0x08
00007583d7bd7879  push rax
00007583d7bd787a  push rcx
00007583d7bd787b  push rdx
00007583d7bd787c  push rdi
00007583d7bd787d  push rsi
00007583d7bd787e  push r8
00007583d7bd7880  push r9
00007583d7bd7882  push r10
00007583d7bd7884  push r11
00007583d7bd7886  sub rsp, 0xF0
00007583d7bd788d  vmovaps [rsp], xmm0
00007583d7bd7892  vmovaps [rsp+0x10], xmm1
00007583d7bd7898  vmovaps [rsp+0x20], xmm2
00007583d7bd789e  vmovaps [rsp+0x30], xmm3
00007583d7bd78a4  vmovaps [rsp+0x40], xmm4
00007583d7bd78aa  vmovaps [rsp+0x50], xmm5
00007583d7bd78b0  vmovaps [rsp+0x60], xmm6
00007583d7bd78b6  vmovaps [rsp+0x70], xmm7
00007583d7bd78bc  vmovaps [rsp+0x80], xmm8
00007583d7bd78c5  vmovaps [rsp+0x90], xmm10
00007583d7bd78ce  vmovaps [rsp+0xA0], xmm11
00007583d7bd78d7  vmovaps [rsp+0xB0], xmm12
00007583d7bd78e0  vmovaps [rsp+0xC0], xmm13
00007583d7bd78e9  vmovaps [rsp+0xD0], xmm14
00007583d7bd78f2  vmovaps [rsp+0xE0], xmm15
00007583d7bd78fb  sub rsp, 0x40
00007583d7bd78ff  lea rdi, [rsp]
00007583d7bd7903  lea rsi, [rsp+0x10]
00007583d7bd7908  lea rdx, [rsp+0x20]
00007583d7bd790d  lea rcx, [rsp+0x30]
00007583d7bd7912  mov r8d, 0x00
00007583d7bd7918  lea r9, [r15+0x3A8]
00007583d7bd791f  movaps [rdi], xmm9
00007583d7bd7923  movaps [rsi], xmm13
00007583d7bd7927  movaps [rdx], xmm14
00007583d7bd792b  movaps [rcx], xmm6
00007583d7bd792e  mov rax, 0x5BCB7EA35A50
00007583d7bd7938  call rax
00007583d7bd793a  movaps xmm9, [rsp]
00007583d7bd793f  add rsp, 0x40
00007583d7bd7943  vmovaps xmm0, [rsp]
00007583d7bd7948  vmovaps xmm1, [rsp+0x10]
00007583d7bd794e  vmovaps xmm2, [rsp+0x20]
00007583d7bd7954  vmovaps xmm3, [rsp+0x30]
00007583d7bd795a  vmovaps xmm4, [rsp+0x40]
00007583d7bd7960  vmovaps xmm5, [rsp+0x50]
00007583d7bd7966  vmovaps xmm6, [rsp+0x60]
00007583d7bd796c  vmovaps xmm7, [rsp+0x70]
00007583d7bd7972  vmovaps xmm8, [rsp+0x80]
00007583d7bd797b  vmovaps xmm10, [rsp+0x90]
00007583d7bd7984  vmovaps xmm11, [rsp+0xA0]
00007583d7bd798d  vmovaps xmm12, [rsp+0xB0]
00007583d7bd7996  vmovaps xmm13, [rsp+0xC0]
00007583d7bd799f  vmovaps xmm14, [rsp+0xD0]
00007583d7bd79a8  vmovaps xmm15, [rsp+0xE0]
00007583d7bd79b1  add rsp, 0xF0
00007583d7bd79b8  pop r11
00007583d7bd79ba  pop r10
00007583d7bd79bc  pop r9
00007583d7bd79be  pop r8
00007583d7bd79c0  pop rsi
00007583d7bd79c1  pop rdi
00007583d7bd79c2  pop rdx
00007583d7bd79c3  pop rcx
00007583d7bd79c4  pop rax
00007583d7bd79c5  add rsp, 0x08
00007583d7bd79c9  jmp 0x00007583D7BD67D2
00007583d7bd79ce  sub rsp, 0x08
00007583d7bd79d2  push rax
00007583d7bd79d3  push rcx
00007583d7bd79d4  push rdx
00007583d7bd79d5  push rdi
00007583d7bd79d6  push rsi
00007583d7bd79d7  push r8
00007583d7bd79d9  push r9
00007583d7bd79db  push r10
00007583d7bd79dd  push r11
00007583d7bd79df  sub rsp, 0xF0
00007583d7bd79e6  vmovaps [rsp], xmm0
00007583d7bd79eb  vmovaps [rsp+0x10], xmm1
00007583d7bd79f1  vmovaps [rsp+0x20], xmm2
00007583d7bd79f7  vmovaps [rsp+0x30], xmm4
00007583d7bd79fd  vmovaps [rsp+0x40], xmm5
00007583d7bd7a03  vmovaps [rsp+0x50], xmm6
00007583d7bd7a09  vmovaps [rsp+0x60], xmm7
00007583d7bd7a0f  vmovaps [rsp+0x70], xmm8
00007583d7bd7a15  vmovaps [rsp+0x80], xmm9
00007583d7bd7a1e  vmovaps [rsp+0x90], xmm10
00007583d7bd7a27  vmovaps [rsp+0xA0], xmm11
00007583d7bd7a30  vmovaps [rsp+0xB0], xmm12
00007583d7bd7a39  vmovaps [rsp+0xC0], xmm13
00007583d7bd7a42  vmovaps [rsp+0xD0], xmm14
00007583d7bd7a4b  vmovaps [rsp+0xE0], xmm15
00007583d7bd7a54  sub rsp, 0x40
00007583d7bd7a58  lea rdi, [rsp]
00007583d7bd7a5c  lea rsi, [rsp+0x10]
00007583d7bd7a61  lea rdx, [rsp+0x20]
00007583d7bd7a66  lea rcx, [rsp+0x30]
00007583d7bd7a6b  mov r8d, 0x00
00007583d7bd7a71  lea r9, [r15+0x3A8]
00007583d7bd7a78  movaps [rdi], xmm3
00007583d7bd7a7b  movaps [rsi], xmm13
00007583d7bd7a7f  movaps [rdx], xmm6
00007583d7bd7a82  movaps [rcx], xmm14
00007583d7bd7a86  mov rax, 0x5BCB7EA35A50
00007583d7bd7a90  call rax
00007583d7bd7a92  movaps xmm3, [rsp]
00007583d7bd7a96  add rsp, 0x40
00007583d7bd7a9a  vmovaps xmm0, [rsp]
00007583d7bd7a9f  vmovaps xmm1, [rsp+0x10]
00007583d7bd7aa5  vmovaps xmm2, [rsp+0x20]
00007583d7bd7aab  vmovaps xmm4, [rsp+0x30]
00007583d7bd7ab1  vmovaps xmm5, [rsp+0x40]
00007583d7bd7ab7  vmovaps xmm6, [rsp+0x50]
00007583d7bd7abd  vmovaps xmm7, [rsp+0x60]
00007583d7bd7ac3  vmovaps xmm8, [rsp+0x70]
00007583d7bd7ac9  vmovaps xmm9, [rsp+0x80]
00007583d7bd7ad2  vmovaps xmm10, [rsp+0x90]
00007583d7bd7adb  vmovaps xmm11, [rsp+0xA0]
00007583d7bd7ae4  vmovaps xmm12, [rsp+0xB0]
00007583d7bd7aed  vmovaps xmm13, [rsp+0xC0]
00007583d7bd7af6  vmovaps xmm14, [rsp+0xD0]
00007583d7bd7aff  vmovaps xmm15, [rsp+0xE0]
00007583d7bd7b08  add rsp, 0xF0
00007583d7bd7b0f  pop r11
00007583d7bd7b11  pop r10
00007583d7bd7b13  pop r9
00007583d7bd7b15  pop r8
00007583d7bd7b17  pop rsi
00007583d7bd7b18  pop rdi
00007583d7bd7b19  pop rdx
00007583d7bd7b1a  pop rcx
00007583d7bd7b1b  pop rax
00007583d7bd7b1c  add rsp, 0x08
00007583d7bd7b20  jmp 0x00007583D7BD680F
00007583d7bd7b25  sub rsp, 0x08
00007583d7bd7b29  push rax
00007583d7bd7b2a  push rcx
00007583d7bd7b2b  push rdx
00007583d7bd7b2c  push rdi
00007583d7bd7b2d  push rsi
00007583d7bd7b2e  push r8
00007583d7bd7b30  push r9
00007583d7bd7b32  push r10
00007583d7bd7b34  push r11
00007583d7bd7b36  sub rsp, 0xF0
00007583d7bd7b3d  vmovaps [rsp], xmm0
00007583d7bd7b42  vmovaps [rsp+0x10], xmm1
00007583d7bd7b48  vmovaps [rsp+0x20], xmm2
00007583d7bd7b4e  vmovaps [rsp+0x30], xmm3
00007583d7bd7b54  vmovaps [rsp+0x40], xmm4
00007583d7bd7b5a  vmovaps [rsp+0x50], xmm5
00007583d7bd7b60  vmovaps [rsp+0x60], xmm7
00007583d7bd7b66  vmovaps [rsp+0x70], xmm8
00007583d7bd7b6c  vmovaps [rsp+0x80], xmm9
00007583d7bd7b75  vmovaps [rsp+0x90], xmm10
00007583d7bd7b7e  vmovaps [rsp+0xA0], xmm11
00007583d7bd7b87  vmovaps [rsp+0xB0], xmm12
00007583d7bd7b90  vmovaps [rsp+0xC0], xmm13
00007583d7bd7b99  vmovaps [rsp+0xD0], xmm14
00007583d7bd7ba2  vmovaps [rsp+0xE0], xmm15
00007583d7bd7bab  sub rsp, 0x40
00007583d7bd7baf  lea rdi, [rsp]
00007583d7bd7bb3  lea rsi, [rsp+0x10]
00007583d7bd7bb8  lea rdx, [rsp+0x20]
00007583d7bd7bbd  lea rcx, [rsp+0x30]
00007583d7bd7bc2  mov r8d, 0x00
00007583d7bd7bc8  lea r9, [r15+0x3A8]
00007583d7bd7bcf  movaps [rdi], xmm6
00007583d7bd7bd2  movaps [rsi], xmm2
00007583d7bd7bd5  movaps [rdx], xmm14
00007583d7bd7bd9  movaps [rcx], xmm1
00007583d7bd7bdc  mov rax, 0x5BCB7EA35A50
00007583d7bd7be6  call rax
00007583d7bd7be8  movaps xmm6, [rsp]
00007583d7bd7bec  add rsp, 0x40
00007583d7bd7bf0  vmovaps xmm0, [rsp]
00007583d7bd7bf5  vmovaps xmm1, [rsp+0x10]
00007583d7bd7bfb  vmovaps xmm2, [rsp+0x20]
00007583d7bd7c01  vmovaps xmm3, [rsp+0x30]
00007583d7bd7c07  vmovaps xmm4, [rsp+0x40]
00007583d7bd7c0d  vmovaps xmm5, [rsp+0x50]
00007583d7bd7c13  vmovaps xmm7, [rsp+0x60]
00007583d7bd7c19  vmovaps xmm8, [rsp+0x70]
00007583d7bd7c1f  vmovaps xmm9, [rsp+0x80]
00007583d7bd7c28  vmovaps xmm10, [rsp+0x90]
00007583d7bd7c31  vmovaps xmm11, [rsp+0xA0]
00007583d7bd7c3a  vmovaps xmm12, [rsp+0xB0]
00007583d7bd7c43  vmovaps xmm13, [rsp+0xC0]
00007583d7bd7c4c  vmovaps xmm14, [rsp+0xD0]
00007583d7bd7c55  vmovaps xmm15, [rsp+0xE0]
00007583d7bd7c5e  add rsp, 0xF0
00007583d7bd7c65  pop r11
00007583d7bd7c67  pop r10
00007583d7bd7c69  pop r9
00007583d7bd7c6b  pop r8
00007583d7bd7c6d  pop rsi
00007583d7bd7c6e  pop rdi
00007583d7bd7c6f  pop rdx
00007583d7bd7c70  pop rcx
00007583d7bd7c71  pop rax
00007583d7bd7c72  add rsp, 0x08
00007583d7bd7c76  jmp 0x00007583D7BD683C
00007583d7bd7c7b  sub rsp, 0x08
00007583d7bd7c7f  push rax
00007583d7bd7c80  push rcx
00007583d7bd7c81  push rdx
00007583d7bd7c82  push rdi
00007583d7bd7c83  push rsi
00007583d7bd7c84  push r8
00007583d7bd7c86  push r9
00007583d7bd7c88  push r10
00007583d7bd7c8a  push r11
00007583d7bd7c8c  sub rsp, 0xF0
00007583d7bd7c93  vmovaps [rsp], xmm0
00007583d7bd7c98  vmovaps [rsp+0x10], xmm1
00007583d7bd7c9e  vmovaps [rsp+0x20], xmm2
00007583d7bd7ca4  vmovaps [rsp+0x30], xmm3
00007583d7bd7caa  vmovaps [rsp+0x40], xmm4
00007583d7bd7cb0  vmovaps [rsp+0x50], xmm5
00007583d7bd7cb6  vmovaps [rsp+0x60], xmm6
00007583d7bd7cbc  vmovaps [rsp+0x70], xmm7
00007583d7bd7cc2  vmovaps [rsp+0x80], xmm8
00007583d7bd7ccb  vmovaps [rsp+0x90], xmm9
00007583d7bd7cd4  vmovaps [rsp+0xA0], xmm10
00007583d7bd7cdd  vmovaps [rsp+0xB0], xmm11
00007583d7bd7ce6  vmovaps [rsp+0xC0], xmm12
00007583d7bd7cef  vmovaps [rsp+0xD0], xmm14
00007583d7bd7cf8  vmovaps [rsp+0xE0], xmm15
00007583d7bd7d01  sub rsp, 0x40
00007583d7bd7d05  lea rdi, [rsp]
00007583d7bd7d09  lea rsi, [rsp+0x10]
00007583d7bd7d0e  lea rdx, [rsp+0x20]
00007583d7bd7d13  lea rcx, [rsp+0x30]
00007583d7bd7d18  mov r8d, 0x00
00007583d7bd7d1e  lea r9, [r15+0x3A8]
00007583d7bd7d25  movaps [rdi], xmm13
00007583d7bd7d29  movaps [rsi], xmm12
00007583d7bd7d2d  movaps [rdx], xmm14
00007583d7bd7d31  movaps [rcx], xmm1
00007583d7bd7d34  mov rax, 0x5BCB7EA35A50
00007583d7bd7d3e  call rax
00007583d7bd7d40  movaps xmm13, [rsp]
00007583d7bd7d45  add rsp, 0x40
00007583d7bd7d49  vmovaps xmm0, [rsp]
00007583d7bd7d4e  vmovaps xmm1, [rsp+0x10]
00007583d7bd7d54  vmovaps xmm2, [rsp+0x20]
00007583d7bd7d5a  vmovaps xmm3, [rsp+0x30]
00007583d7bd7d60  vmovaps xmm4, [rsp+0x40]
00007583d7bd7d66  vmovaps xmm5, [rsp+0x50]
00007583d7bd7d6c  vmovaps xmm6, [rsp+0x60]
00007583d7bd7d72  vmovaps xmm7, [rsp+0x70]
00007583d7bd7d78  vmovaps xmm8, [rsp+0x80]
00007583d7bd7d81  vmovaps xmm9, [rsp+0x90]
00007583d7bd7d8a  vmovaps xmm10, [rsp+0xA0]
00007583d7bd7d93  vmovaps xmm11, [rsp+0xB0]
00007583d7bd7d9c  vmovaps xmm12, [rsp+0xC0]
00007583d7bd7da5  vmovaps xmm14, [rsp+0xD0]
00007583d7bd7dae  vmovaps xmm15, [rsp+0xE0]
00007583d7bd7db7  add rsp, 0xF0
00007583d7bd7dbe  pop r11
00007583d7bd7dc0  pop r10
00007583d7bd7dc2  pop r9
00007583d7bd7dc4  pop r8
00007583d7bd7dc6  pop rsi
00007583d7bd7dc7  pop rdi
00007583d7bd7dc8  pop rdx
00007583d7bd7dc9  pop rcx
00007583d7bd7dca  pop rax
00007583d7bd7dcb  add rsp, 0x08
00007583d7bd7dcf  jmp 0x00007583D7BD686E
00007583d7bd7dd4  sub rsp, 0x08
00007583d7bd7dd8  push rax
00007583d7bd7dd9  push rcx
00007583d7bd7dda  push rdx
00007583d7bd7ddb  push rdi
00007583d7bd7ddc  push rsi
00007583d7bd7ddd  push r8
00007583d7bd7ddf  push r9
00007583d7bd7de1  push r10
00007583d7bd7de3  push r11
00007583d7bd7de5  sub rsp, 0xF0
00007583d7bd7dec  vmovaps [rsp], xmm0
00007583d7bd7df1  vmovaps [rsp+0x10], xmm1
00007583d7bd7df7  vmovaps [rsp+0x20], xmm2
00007583d7bd7dfd  vmovaps [rsp+0x30], xmm3
00007583d7bd7e03  vmovaps [rsp+0x40], xmm4
00007583d7bd7e09  vmovaps [rsp+0x50], xmm5
00007583d7bd7e0f  vmovaps [rsp+0x60], xmm6
00007583d7bd7e15  vmovaps [rsp+0x70], xmm7
00007583d7bd7e1b  vmovaps [rsp+0x80], xmm8
00007583d7bd7e24  vmovaps [rsp+0x90], xmm9
00007583d7bd7e2d  vmovaps [rsp+0xA0], xmm10
00007583d7bd7e36  vmovaps [rsp+0xB0], xmm11
00007583d7bd7e3f  vmovaps [rsp+0xC0], xmm13
00007583d7bd7e48  vmovaps [rsp+0xD0], xmm14
00007583d7bd7e51  vmovaps [rsp+0xE0], xmm15
00007583d7bd7e5a  sub rsp, 0x40
00007583d7bd7e5e  lea rdi, [rsp]
00007583d7bd7e62  lea rsi, [rsp+0x10]
00007583d7bd7e67  lea rdx, [rsp+0x20]
00007583d7bd7e6c  lea rcx, [rsp+0x30]
00007583d7bd7e71  mov r8d, 0x00
00007583d7bd7e77  lea r9, [r15+0x3A8]
00007583d7bd7e7e  movaps [rdi], xmm12
00007583d7bd7e82  movaps [rsi], xmm3
00007583d7bd7e85  movaps [rdx], xmm14
00007583d7bd7e89  movaps [rcx], xmm5
00007583d7bd7e8c  mov rax, 0x5BCB7EA35A50
00007583d7bd7e96  call rax
00007583d7bd7e98  movaps xmm12, [rsp]
00007583d7bd7e9d  add rsp, 0x40
00007583d7bd7ea1  vmovaps xmm0, [rsp]
00007583d7bd7ea6  vmovaps xmm1, [rsp+0x10]
00007583d7bd7eac  vmovaps xmm2, [rsp+0x20]
00007583d7bd7eb2  vmovaps xmm3, [rsp+0x30]
00007583d7bd7eb8  vmovaps xmm4, [rsp+0x40]
00007583d7bd7ebe  vmovaps xmm5, [rsp+0x50]
00007583d7bd7ec4  vmovaps xmm6, [rsp+0x60]
00007583d7bd7eca  vmovaps xmm7, [rsp+0x70]
00007583d7bd7ed0  vmovaps xmm8, [rsp+0x80]
00007583d7bd7ed9  vmovaps xmm9, [rsp+0x90]
00007583d7bd7ee2  vmovaps xmm10, [rsp+0xA0]
00007583d7bd7eeb  vmovaps xmm11, [rsp+0xB0]
00007583d7bd7ef4  vmovaps xmm13, [rsp+0xC0]
00007583d7bd7efd  vmovaps xmm14, [rsp+0xD0]
00007583d7bd7f06  vmovaps xmm15, [rsp+0xE0]
00007583d7bd7f0f  add rsp, 0xF0
00007583d7bd7f16  pop r11
00007583d7bd7f18  pop r10
00007583d7bd7f1a  pop r9
00007583d7bd7f1c  pop r8
00007583d7bd7f1e  pop rsi
00007583d7bd7f1f  pop rdi
00007583d7bd7f20  pop rdx
00007583d7bd7f21  pop rcx
00007583d7bd7f22  pop rax
00007583d7bd7f23  add rsp, 0x08
00007583d7bd7f27  jmp 0x00007583D7BD68CB
00007583d7bd7f2c  sub rsp, 0x08
00007583d7bd7f30  push rax
00007583d7bd7f31  push rcx
00007583d7bd7f32  push rdx
00007583d7bd7f33  push rdi
00007583d7bd7f34  push rsi
00007583d7bd7f35  push r8
00007583d7bd7f37  push r9
00007583d7bd7f39  push r10
00007583d7bd7f3b  push r11
00007583d7bd7f3d  sub rsp, 0xF0
00007583d7bd7f44  vmovaps [rsp], xmm0
00007583d7bd7f49  vmovaps [rsp+0x10], xmm1
00007583d7bd7f4f  vmovaps [rsp+0x20], xmm2
00007583d7bd7f55  vmovaps [rsp+0x30], xmm3
00007583d7bd7f5b  vmovaps [rsp+0x40], xmm4
00007583d7bd7f61  vmovaps [rsp+0x50], xmm5
00007583d7bd7f67  vmovaps [rsp+0x60], xmm6
00007583d7bd7f6d  vmovaps [rsp+0x70], xmm7
00007583d7bd7f73  vmovaps [rsp+0x80], xmm8
00007583d7bd7f7c  vmovaps [rsp+0x90], xmm9
00007583d7bd7f85  vmovaps [rsp+0xA0], xmm11
00007583d7bd7f8e  vmovaps [rsp+0xB0], xmm12
00007583d7bd7f97  vmovaps [rsp+0xC0], xmm13
00007583d7bd7fa0  vmovaps [rsp+0xD0], xmm14
00007583d7bd7fa9  vmovaps [rsp+0xE0], xmm15
00007583d7bd7fb2  sub rsp, 0x40
00007583d7bd7fb6  lea rdi, [rsp]
00007583d7bd7fba  lea rsi, [rsp+0x10]
00007583d7bd7fbf  lea rdx, [rsp+0x20]
00007583d7bd7fc4  lea rcx, [rsp+0x30]
00007583d7bd7fc9  mov r8d, 0x00
00007583d7bd7fcf  lea r9, [r15+0x3A8]
00007583d7bd7fd6  movaps [rdi], xmm10
00007583d7bd7fda  movaps [rsi], xmm9
00007583d7bd7fde  movaps [rdx], xmm7
00007583d7bd7fe1  movaps [rcx], xmm14
00007583d7bd7fe5  mov rax, 0x5BCB7EA35A50
00007583d7bd7fef  call rax
00007583d7bd7ff1  movaps xmm10, [rsp]
00007583d7bd7ff6  add rsp, 0x40
00007583d7bd7ffa  vmovaps xmm0, [rsp]
00007583d7bd7fff  vmovaps xmm1, [rsp+0x10]
00007583d7bd8005  vmovaps xmm2, [rsp+0x20]
00007583d7bd800b  vmovaps xmm3, [rsp+0x30]
00007583d7bd8011  vmovaps xmm4, [rsp+0x40]
00007583d7bd8017  vmovaps xmm5, [rsp+0x50]
00007583d7bd801d  vmovaps xmm6, [rsp+0x60]
00007583d7bd8023  vmovaps xmm7, [rsp+0x70]
00007583d7bd8029  vmovaps xmm8, [rsp+0x80]
00007583d7bd8032  vmovaps xmm9, [rsp+0x90]
00007583d7bd803b  vmovaps xmm11, [rsp+0xA0]
00007583d7bd8044  vmovaps xmm12, [rsp+0xB0]
00007583d7bd804d  vmovaps xmm13, [rsp+0xC0]
00007583d7bd8056  vmovaps xmm14, [rsp+0xD0]
00007583d7bd805f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd8068  add rsp, 0xF0
00007583d7bd806f  pop r11
00007583d7bd8071  pop r10
00007583d7bd8073  pop r9
00007583d7bd8075  pop r8
00007583d7bd8077  pop rsi
00007583d7bd8078  pop rdi
00007583d7bd8079  pop rdx
00007583d7bd807a  pop rcx
00007583d7bd807b  pop rax
00007583d7bd807c  add rsp, 0x08
00007583d7bd8080  jmp 0x00007583D7BD68F1
00007583d7bd8085  call 0x00007583D7AE45A0
00007583d7bd808a  jmp 0x00007583D7BD68FE
00007583d7bd808f  sub rsp, 0x08
00007583d7bd8093  push rax
00007583d7bd8094  push rcx
00007583d7bd8095  push rdx
00007583d7bd8096  push rdi
00007583d7bd8097  push rsi
00007583d7bd8098  push r8
00007583d7bd809a  push r9
00007583d7bd809c  push r10
00007583d7bd809e  push r11
00007583d7bd80a0  sub rsp, 0xF0
00007583d7bd80a7  vmovaps [rsp], xmm0
00007583d7bd80ac  vmovaps [rsp+0x10], xmm1
00007583d7bd80b2  vmovaps [rsp+0x20], xmm2
00007583d7bd80b8  vmovaps [rsp+0x30], xmm3
00007583d7bd80be  vmovaps [rsp+0x40], xmm4
00007583d7bd80c4  vmovaps [rsp+0x50], xmm6
00007583d7bd80ca  vmovaps [rsp+0x60], xmm7
00007583d7bd80d0  vmovaps [rsp+0x70], xmm8
00007583d7bd80d6  vmovaps [rsp+0x80], xmm9
00007583d7bd80df  vmovaps [rsp+0x90], xmm10
00007583d7bd80e8  vmovaps [rsp+0xA0], xmm11
00007583d7bd80f1  vmovaps [rsp+0xB0], xmm12
00007583d7bd80fa  vmovaps [rsp+0xC0], xmm13
00007583d7bd8103  vmovaps [rsp+0xD0], xmm14
00007583d7bd810c  vmovaps [rsp+0xE0], xmm15
00007583d7bd8115  sub rsp, 0x40
00007583d7bd8119  lea rdi, [rsp]
00007583d7bd811d  lea rsi, [rsp+0x10]
00007583d7bd8122  lea rdx, [rsp+0x20]
00007583d7bd8127  lea rcx, [rsp+0x30]
00007583d7bd812c  mov r8d, 0x00
00007583d7bd8132  lea r9, [r15+0x3A8]
00007583d7bd8139  movaps [rdi], xmm5
00007583d7bd813c  movaps [rsi], xmm6
00007583d7bd813f  movaps [rdx], xmm7
00007583d7bd8142  movaps [rcx], xmm9
00007583d7bd8146  mov rax, 0x5BCB7EA35A50
00007583d7bd8150  call rax
00007583d7bd8152  movaps xmm5, [rsp]
00007583d7bd8156  add rsp, 0x40
00007583d7bd815a  vmovaps xmm0, [rsp]
00007583d7bd815f  vmovaps xmm1, [rsp+0x10]
00007583d7bd8165  vmovaps xmm2, [rsp+0x20]
00007583d7bd816b  vmovaps xmm3, [rsp+0x30]
00007583d7bd8171  vmovaps xmm4, [rsp+0x40]
00007583d7bd8177  vmovaps xmm6, [rsp+0x50]
00007583d7bd817d  vmovaps xmm7, [rsp+0x60]
00007583d7bd8183  vmovaps xmm8, [rsp+0x70]
00007583d7bd8189  vmovaps xmm9, [rsp+0x80]
00007583d7bd8192  vmovaps xmm10, [rsp+0x90]
00007583d7bd819b  vmovaps xmm11, [rsp+0xA0]
00007583d7bd81a4  vmovaps xmm12, [rsp+0xB0]
00007583d7bd81ad  vmovaps xmm13, [rsp+0xC0]
00007583d7bd81b6  vmovaps xmm14, [rsp+0xD0]
00007583d7bd81bf  vmovaps xmm15, [rsp+0xE0]
00007583d7bd81c8  add rsp, 0xF0
00007583d7bd81cf  pop r11
00007583d7bd81d1  pop r10
00007583d7bd81d3  pop r9
00007583d7bd81d5  pop r8
00007583d7bd81d7  pop rsi
00007583d7bd81d8  pop rdi
00007583d7bd81d9  pop rdx
00007583d7bd81da  pop rcx
00007583d7bd81db  pop rax
00007583d7bd81dc  add rsp, 0x08
00007583d7bd81e0  jmp 0x00007583D7BD6930
00007583d7bd81e5  sub rsp, 0x08
00007583d7bd81e9  push rax
00007583d7bd81ea  push rcx
00007583d7bd81eb  push rdx
00007583d7bd81ec  push rdi
00007583d7bd81ed  push rsi
00007583d7bd81ee  push r8
00007583d7bd81f0  push r9
00007583d7bd81f2  push r10
00007583d7bd81f4  push r11
00007583d7bd81f6  sub rsp, 0xF0
00007583d7bd81fd  vmovaps [rsp], xmm0
00007583d7bd8202  vmovaps [rsp+0x10], xmm1
00007583d7bd8208  vmovaps [rsp+0x20], xmm2
00007583d7bd820e  vmovaps [rsp+0x30], xmm3
00007583d7bd8214  vmovaps [rsp+0x40], xmm4
00007583d7bd821a  vmovaps [rsp+0x50], xmm5
00007583d7bd8220  vmovaps [rsp+0x60], xmm6
00007583d7bd8226  vmovaps [rsp+0x70], xmm8
00007583d7bd822c  vmovaps [rsp+0x80], xmm9
00007583d7bd8235  vmovaps [rsp+0x90], xmm10
00007583d7bd823e  vmovaps [rsp+0xA0], xmm11
00007583d7bd8247  vmovaps [rsp+0xB0], xmm12
00007583d7bd8250  vmovaps [rsp+0xC0], xmm13
00007583d7bd8259  vmovaps [rsp+0xD0], xmm14
00007583d7bd8262  vmovaps [rsp+0xE0], xmm15
00007583d7bd826b  sub rsp, 0x40
00007583d7bd826f  lea rdi, [rsp]
00007583d7bd8273  lea rsi, [rsp+0x10]
00007583d7bd8278  lea rdx, [rsp+0x20]
00007583d7bd827d  lea rcx, [rsp+0x30]
00007583d7bd8282  mov r8d, 0x00
00007583d7bd8288  lea r9, [r15+0x3A8]
00007583d7bd828f  movaps [rdi], xmm7
00007583d7bd8292  movaps [rsi], xmm13
00007583d7bd8296  movaps [rdx], xmm1
00007583d7bd8299  movaps [rcx], xmm9
00007583d7bd829d  mov rax, 0x5BCB7EA35A50
00007583d7bd82a7  call rax
00007583d7bd82a9  movaps xmm7, [rsp]
00007583d7bd82ad  add rsp, 0x40
00007583d7bd82b1  vmovaps xmm0, [rsp]
00007583d7bd82b6  vmovaps xmm1, [rsp+0x10]
00007583d7bd82bc  vmovaps xmm2, [rsp+0x20]
00007583d7bd82c2  vmovaps xmm3, [rsp+0x30]
00007583d7bd82c8  vmovaps xmm4, [rsp+0x40]
00007583d7bd82ce  vmovaps xmm5, [rsp+0x50]
00007583d7bd82d4  vmovaps xmm6, [rsp+0x60]
00007583d7bd82da  vmovaps xmm8, [rsp+0x70]
00007583d7bd82e0  vmovaps xmm9, [rsp+0x80]
00007583d7bd82e9  vmovaps xmm10, [rsp+0x90]
00007583d7bd82f2  vmovaps xmm11, [rsp+0xA0]
00007583d7bd82fb  vmovaps xmm12, [rsp+0xB0]
00007583d7bd8304  vmovaps xmm13, [rsp+0xC0]
00007583d7bd830d  vmovaps xmm14, [rsp+0xD0]
00007583d7bd8316  vmovaps xmm15, [rsp+0xE0]
00007583d7bd831f  add rsp, 0xF0
00007583d7bd8326  pop r11
00007583d7bd8328  pop r10
00007583d7bd832a  pop r9
00007583d7bd832c  pop r8
00007583d7bd832e  pop rsi
00007583d7bd832f  pop rdi
00007583d7bd8330  pop rdx
00007583d7bd8331  pop rcx
00007583d7bd8332  pop rax
00007583d7bd8333  add rsp, 0x08
00007583d7bd8337  jmp 0x00007583D7BD6955
00007583d7bd833c  call 0x00007583D7AE3320
00007583d7bd8341  jmp 0x00007583D7BD6978
00007583d7bd8346  call 0x00007583D7ADE950
00007583d7bd834b  jmp 0x00007583D7BD6982
00007583d7bd8350  sub rsp, 0x08
00007583d7bd8354  push rax
00007583d7bd8355  push rcx
00007583d7bd8356  push rdx
00007583d7bd8357  push rdi
00007583d7bd8358  push rsi
00007583d7bd8359  push r8
00007583d7bd835b  push r9
00007583d7bd835d  push r10
00007583d7bd835f  push r11
00007583d7bd8361  sub rsp, 0xF0
00007583d7bd8368  vmovaps [rsp], xmm0
00007583d7bd836d  vmovaps [rsp+0x10], xmm1
00007583d7bd8373  vmovaps [rsp+0x20], xmm3
00007583d7bd8379  vmovaps [rsp+0x30], xmm4
00007583d7bd837f  vmovaps [rsp+0x40], xmm5
00007583d7bd8385  vmovaps [rsp+0x50], xmm6
00007583d7bd838b  vmovaps [rsp+0x60], xmm7
00007583d7bd8391  vmovaps [rsp+0x70], xmm8
00007583d7bd8397  vmovaps [rsp+0x80], xmm9
00007583d7bd83a0  vmovaps [rsp+0x90], xmm10
00007583d7bd83a9  vmovaps [rsp+0xA0], xmm11
00007583d7bd83b2  vmovaps [rsp+0xB0], xmm12
00007583d7bd83bb  vmovaps [rsp+0xC0], xmm13
00007583d7bd83c4  vmovaps [rsp+0xD0], xmm14
00007583d7bd83cd  vmovaps [rsp+0xE0], xmm15
00007583d7bd83d6  sub rsp, 0x40
00007583d7bd83da  lea rdi, [rsp]
00007583d7bd83de  lea rsi, [rsp+0x10]
00007583d7bd83e3  lea rdx, [rsp+0x20]
00007583d7bd83e8  lea rcx, [rsp+0x30]
00007583d7bd83ed  mov r8d, 0x00
00007583d7bd83f3  lea r9, [r15+0x3A8]
00007583d7bd83fa  movaps [rdi], xmm2
00007583d7bd83fd  movaps [rsi], xmm12
00007583d7bd8401  movaps [rdx], xmm6
00007583d7bd8404  movaps [rcx], xmm3
00007583d7bd8407  mov rax, 0x5BCB7EA35A50
00007583d7bd8411  call rax
00007583d7bd8413  movaps xmm2, [rsp]
00007583d7bd8417  add rsp, 0x40
00007583d7bd841b  vmovaps xmm0, [rsp]
00007583d7bd8420  vmovaps xmm1, [rsp+0x10]
00007583d7bd8426  vmovaps xmm3, [rsp+0x20]
00007583d7bd842c  vmovaps xmm4, [rsp+0x30]
00007583d7bd8432  vmovaps xmm5, [rsp+0x40]
00007583d7bd8438  vmovaps xmm6, [rsp+0x50]
00007583d7bd843e  vmovaps xmm7, [rsp+0x60]
00007583d7bd8444  vmovaps xmm8, [rsp+0x70]
00007583d7bd844a  vmovaps xmm9, [rsp+0x80]
00007583d7bd8453  vmovaps xmm10, [rsp+0x90]
00007583d7bd845c  vmovaps xmm11, [rsp+0xA0]
00007583d7bd8465  vmovaps xmm12, [rsp+0xB0]
00007583d7bd846e  vmovaps xmm13, [rsp+0xC0]
00007583d7bd8477  vmovaps xmm14, [rsp+0xD0]
00007583d7bd8480  vmovaps xmm15, [rsp+0xE0]
00007583d7bd8489  add rsp, 0xF0
00007583d7bd8490  pop r11
00007583d7bd8492  pop r10
00007583d7bd8494  pop r9
00007583d7bd8496  pop r8
00007583d7bd8498  pop rsi
00007583d7bd8499  pop rdi
00007583d7bd849a  pop rdx
00007583d7bd849b  pop rcx
00007583d7bd849c  pop rax
00007583d7bd849d  add rsp, 0x08
00007583d7bd84a1  jmp 0x00007583D7BD69C8
00007583d7bd84a6  sub rsp, 0x08
00007583d7bd84aa  push rax
00007583d7bd84ab  push rcx
00007583d7bd84ac  push rdx
00007583d7bd84ad  push rdi
00007583d7bd84ae  push rsi
00007583d7bd84af  push r8
00007583d7bd84b1  push r9
00007583d7bd84b3  push r10
00007583d7bd84b5  push r11
00007583d7bd84b7  sub rsp, 0xF0
00007583d7bd84be  vmovaps [rsp], xmm0
00007583d7bd84c3  vmovaps [rsp+0x10], xmm1
00007583d7bd84c9  vmovaps [rsp+0x20], xmm2
00007583d7bd84cf  vmovaps [rsp+0x30], xmm3
00007583d7bd84d5  vmovaps [rsp+0x40], xmm4
00007583d7bd84db  vmovaps [rsp+0x50], xmm5
00007583d7bd84e1  vmovaps [rsp+0x60], xmm7
00007583d7bd84e7  vmovaps [rsp+0x70], xmm8
00007583d7bd84ed  vmovaps [rsp+0x80], xmm9
00007583d7bd84f6  vmovaps [rsp+0x90], xmm10
00007583d7bd84ff  vmovaps [rsp+0xA0], xmm11
00007583d7bd8508  vmovaps [rsp+0xB0], xmm12
00007583d7bd8511  vmovaps [rsp+0xC0], xmm13
00007583d7bd851a  vmovaps [rsp+0xD0], xmm14
00007583d7bd8523  vmovaps [rsp+0xE0], xmm15
00007583d7bd852c  sub rsp, 0x40
00007583d7bd8530  lea rdi, [rsp]
00007583d7bd8534  lea rsi, [rsp+0x10]
00007583d7bd8539  lea rdx, [rsp+0x20]
00007583d7bd853e  lea rcx, [rsp+0x30]
00007583d7bd8543  mov r8d, 0x00
00007583d7bd8549  lea r9, [r15+0x3A8]
00007583d7bd8550  movaps [rdi], xmm6
00007583d7bd8553  movaps [rsi], xmm10
00007583d7bd8557  movaps [rdx], xmm12
00007583d7bd855b  movaps [rcx], xmm1
00007583d7bd855e  mov rax, 0x5BCB7EA35A50
00007583d7bd8568  call rax
00007583d7bd856a  movaps xmm6, [rsp]
00007583d7bd856e  add rsp, 0x40
00007583d7bd8572  vmovaps xmm0, [rsp]
00007583d7bd8577  vmovaps xmm1, [rsp+0x10]
00007583d7bd857d  vmovaps xmm2, [rsp+0x20]
00007583d7bd8583  vmovaps xmm3, [rsp+0x30]
00007583d7bd8589  vmovaps xmm4, [rsp+0x40]
00007583d7bd858f  vmovaps xmm5, [rsp+0x50]
00007583d7bd8595  vmovaps xmm7, [rsp+0x60]
00007583d7bd859b  vmovaps xmm8, [rsp+0x70]
00007583d7bd85a1  vmovaps xmm9, [rsp+0x80]
00007583d7bd85aa  vmovaps xmm10, [rsp+0x90]
00007583d7bd85b3  vmovaps xmm11, [rsp+0xA0]
00007583d7bd85bc  vmovaps xmm12, [rsp+0xB0]
00007583d7bd85c5  vmovaps xmm13, [rsp+0xC0]
00007583d7bd85ce  vmovaps xmm14, [rsp+0xD0]
00007583d7bd85d7  vmovaps xmm15, [rsp+0xE0]
00007583d7bd85e0  add rsp, 0xF0
00007583d7bd85e7  pop r11
00007583d7bd85e9  pop r10
00007583d7bd85eb  pop r9
00007583d7bd85ed  pop r8
00007583d7bd85ef  pop rsi
00007583d7bd85f0  pop rdi
00007583d7bd85f1  pop rdx
00007583d7bd85f2  pop rcx
00007583d7bd85f3  pop rax
00007583d7bd85f4  add rsp, 0x08
00007583d7bd85f8  jmp 0x00007583D7BD69F6
00007583d7bd85fd  sub rsp, 0x08
00007583d7bd8601  push rax
00007583d7bd8602  push rcx
00007583d7bd8603  push rdx
00007583d7bd8604  push rdi
00007583d7bd8605  push rsi
00007583d7bd8606  push r8
00007583d7bd8608  push r9
00007583d7bd860a  push r10
00007583d7bd860c  push r11
00007583d7bd860e  sub rsp, 0xF0
00007583d7bd8615  vmovaps [rsp], xmm0
00007583d7bd861a  vmovaps [rsp+0x10], xmm1
00007583d7bd8620  vmovaps [rsp+0x20], xmm2
00007583d7bd8626  vmovaps [rsp+0x30], xmm3
00007583d7bd862c  vmovaps [rsp+0x40], xmm4
00007583d7bd8632  vmovaps [rsp+0x50], xmm5
00007583d7bd8638  vmovaps [rsp+0x60], xmm6
00007583d7bd863e  vmovaps [rsp+0x70], xmm7
00007583d7bd8644  vmovaps [rsp+0x80], xmm8
00007583d7bd864d  vmovaps [rsp+0x90], xmm9
00007583d7bd8656  vmovaps [rsp+0xA0], xmm11
00007583d7bd865f  vmovaps [rsp+0xB0], xmm12
00007583d7bd8668  vmovaps [rsp+0xC0], xmm13
00007583d7bd8671  vmovaps [rsp+0xD0], xmm14
00007583d7bd867a  vmovaps [rsp+0xE0], xmm15
00007583d7bd8683  sub rsp, 0x40
00007583d7bd8687  lea rdi, [rsp]
00007583d7bd868b  lea rsi, [rsp+0x10]
00007583d7bd8690  lea rdx, [rsp+0x20]
00007583d7bd8695  lea rcx, [rsp+0x30]
00007583d7bd869a  mov r8d, 0x00
00007583d7bd86a0  lea r9, [r15+0x3A8]
00007583d7bd86a7  movaps [rdi], xmm10
00007583d7bd86ab  movaps [rsi], xmm5
00007583d7bd86ae  movaps [rdx], xmm12
00007583d7bd86b2  movaps [rcx], xmm1
00007583d7bd86b5  mov rax, 0x5BCB7EA35A50
00007583d7bd86bf  call rax
00007583d7bd86c1  movaps xmm10, [rsp]
00007583d7bd86c6  add rsp, 0x40
00007583d7bd86ca  vmovaps xmm0, [rsp]
00007583d7bd86cf  vmovaps xmm1, [rsp+0x10]
00007583d7bd86d5  vmovaps xmm2, [rsp+0x20]
00007583d7bd86db  vmovaps xmm3, [rsp+0x30]
00007583d7bd86e1  vmovaps xmm4, [rsp+0x40]
00007583d7bd86e7  vmovaps xmm5, [rsp+0x50]
00007583d7bd86ed  vmovaps xmm6, [rsp+0x60]
00007583d7bd86f3  vmovaps xmm7, [rsp+0x70]
00007583d7bd86f9  vmovaps xmm8, [rsp+0x80]
00007583d7bd8702  vmovaps xmm9, [rsp+0x90]
00007583d7bd870b  vmovaps xmm11, [rsp+0xA0]
00007583d7bd8714  vmovaps xmm12, [rsp+0xB0]
00007583d7bd871d  vmovaps xmm13, [rsp+0xC0]
00007583d7bd8726  vmovaps xmm14, [rsp+0xD0]
00007583d7bd872f  vmovaps xmm15, [rsp+0xE0]
00007583d7bd8738  add rsp, 0xF0
00007583d7bd873f  pop r11
00007583d7bd8741  pop r10
00007583d7bd8743  pop r9
00007583d7bd8745  pop r8
00007583d7bd8747  pop rsi
00007583d7bd8748  pop rdi
00007583d7bd8749  pop rdx
00007583d7bd874a  pop rcx
00007583d7bd874b  pop rax
00007583d7bd874c  add rsp, 0x08
00007583d7bd8750  jmp 0x00007583D7BD6A25
00007583d7bd8755  sub rsp, 0x08
00007583d7bd8759  push rax
00007583d7bd875a  push rcx
00007583d7bd875b  push rdx
00007583d7bd875c  push rdi
00007583d7bd875d  push rsi
00007583d7bd875e  push r8
00007583d7bd8760  push r9
00007583d7bd8762  push r10
00007583d7bd8764  push r11
00007583d7bd8766  sub rsp, 0xF0
00007583d7bd876d  vmovaps [rsp], xmm0
00007583d7bd8772  vmovaps [rsp+0x10], xmm1
00007583d7bd8778  vmovaps [rsp+0x20], xmm2
00007583d7bd877e  vmovaps [rsp+0x30], xmm3
00007583d7bd8784  vmovaps [rsp+0x40], xmm4
00007583d7bd878a  vmovaps [rsp+0x50], xmm5
00007583d7bd8790  vmovaps [rsp+0x60], xmm6
00007583d7bd8796  vmovaps [rsp+0x70], xmm7
00007583d7bd879c  vmovaps [rsp+0x80], xmm8
00007583d7bd87a5  vmovaps [rsp+0x90], xmm9
00007583d7bd87ae  vmovaps [rsp+0xA0], xmm10
00007583d7bd87b7  vmovaps [rsp+0xB0], xmm11
00007583d7bd87c0  vmovaps [rsp+0xC0], xmm13
00007583d7bd87c9  vmovaps [rsp+0xD0], xmm14
00007583d7bd87d2  vmovaps [rsp+0xE0], xmm15
00007583d7bd87db  sub rsp, 0x40
00007583d7bd87df  lea rdi, [rsp]
00007583d7bd87e3  lea rsi, [rsp+0x10]
00007583d7bd87e8  lea rdx, [rsp+0x20]
00007583d7bd87ed  lea rcx, [rsp+0x30]
00007583d7bd87f2  mov r8d, 0x00
00007583d7bd87f8  lea r9, [r15+0x3A8]
00007583d7bd87ff  movaps [rdi], xmm12
00007583d7bd8803  movaps [rsi], xmm7
00007583d7bd8806  movaps [rdx], xmm15
00007583d7bd880a  movaps [rcx], xmm1
00007583d7bd880d  mov rax, 0x5BCB7EA35A50
00007583d7bd8817  call rax
00007583d7bd8819  movaps xmm12, [rsp]
00007583d7bd881e  add rsp, 0x40
00007583d7bd8822  vmovaps xmm0, [rsp]
00007583d7bd8827  vmovaps xmm1, [rsp+0x10]
00007583d7bd882d  vmovaps xmm2, [rsp+0x20]
00007583d7bd8833  vmovaps xmm3, [rsp+0x30]
00007583d7bd8839  vmovaps xmm4, [rsp+0x40]
00007583d7bd883f  vmovaps xmm5, [rsp+0x50]
00007583d7bd8845  vmovaps xmm6, [rsp+0x60]
00007583d7bd884b  vmovaps xmm7, [rsp+0x70]
00007583d7bd8851  vmovaps xmm8, [rsp+0x80]
00007583d7bd885a  vmovaps xmm9, [rsp+0x90]
00007583d7bd8863  vmovaps xmm10, [rsp+0xA0]
00007583d7bd886c  vmovaps xmm11, [rsp+0xB0]
00007583d7bd8875  vmovaps xmm13, [rsp+0xC0]
00007583d7bd887e  vmovaps xmm14, [rsp+0xD0]
00007583d7bd8887  vmovaps xmm15, [rsp+0xE0]
00007583d7bd8890  add rsp, 0xF0
00007583d7bd8897  pop r11
00007583d7bd8899  pop r10
00007583d7bd889b  pop r9
00007583d7bd889d  pop r8
00007583d7bd889f  pop rsi
00007583d7bd88a0  pop rdi
00007583d7bd88a1  pop rdx
00007583d7bd88a2  pop rcx
00007583d7bd88a3  pop rax
00007583d7bd88a4  add rsp, 0x08
00007583d7bd88a8  jmp 0x00007583D7BD6A4E
00007583d7bd88ad  call 0x00007583D7AD64F0
00007583d7bd88b2  jmp 0x00007583D7BD6A58
00007583d7bd88b7  call 0x00007583D7AE5820
00007583d7bd88bc  jmp 0x00007583D7BD6A62
00007583d7bd88c1  sub rsp, 0x08
00007583d7bd88c5  push rax
00007583d7bd88c6  push rcx
00007583d7bd88c7  push rdx
00007583d7bd88c8  push rdi
00007583d7bd88c9  push rsi
00007583d7bd88ca  push r8
00007583d7bd88cc  push r9
00007583d7bd88ce  push r10
00007583d7bd88d0  push r11
00007583d7bd88d2  sub rsp, 0xF0
00007583d7bd88d9  vmovaps [rsp], xmm0
00007583d7bd88de  vmovaps [rsp+0x10], xmm1
00007583d7bd88e4  vmovaps [rsp+0x20], xmm2
00007583d7bd88ea  vmovaps [rsp+0x30], xmm3
00007583d7bd88f0  vmovaps [rsp+0x40], xmm4
00007583d7bd88f6  vmovaps [rsp+0x50], xmm5
00007583d7bd88fc  vmovaps [rsp+0x60], xmm6
00007583d7bd8902  vmovaps [rsp+0x70], xmm8
00007583d7bd8908  vmovaps [rsp+0x80], xmm9
00007583d7bd8911  vmovaps [rsp+0x90], xmm10
00007583d7bd891a  vmovaps [rsp+0xA0], xmm11
00007583d7bd8923  vmovaps [rsp+0xB0], xmm12
00007583d7bd892c  vmovaps [rsp+0xC0], xmm13
00007583d7bd8935  vmovaps [rsp+0xD0], xmm14
00007583d7bd893e  vmovaps [rsp+0xE0], xmm15
00007583d7bd8947  sub rsp, 0x40
00007583d7bd894b  lea rdi, [rsp]
00007583d7bd894f  lea rsi, [rsp+0x10]
00007583d7bd8954  lea rdx, [rsp+0x20]
00007583d7bd8959  lea rcx, [rsp+0x30]
00007583d7bd895e  mov r8d, 0x00
00007583d7bd8964  lea r9, [r15+0x3A8]
00007583d7bd896b  movaps [rdi], xmm7
00007583d7bd896e  movaps [rsi], xmm2
00007583d7bd8971  movaps [rdx], xmm9
00007583d7bd8975  movaps [rcx], xmm11
00007583d7bd8979  mov rax, 0x5BCB7EA35A50
00007583d7bd8983  call rax
00007583d7bd8985  movaps xmm7, [rsp]
00007583d7bd8989  add rsp, 0x40
00007583d7bd898d  vmovaps xmm0, [rsp]
00007583d7bd8992  vmovaps xmm1, [rsp+0x10]
00007583d7bd8998  vmovaps xmm2, [rsp+0x20]
00007583d7bd899e  vmovaps xmm3, [rsp+0x30]
00007583d7bd89a4  vmovaps xmm4, [rsp+0x40]
00007583d7bd89aa  vmovaps xmm5, [rsp+0x50]
00007583d7bd89b0  vmovaps xmm6, [rsp+0x60]
00007583d7bd89b6  vmovaps xmm8, [rsp+0x70]
00007583d7bd89bc  vmovaps xmm9, [rsp+0x80]
00007583d7bd89c5  vmovaps xmm10, [rsp+0x90]
00007583d7bd89ce  vmovaps xmm11, [rsp+0xA0]
00007583d7bd89d7  vmovaps xmm12, [rsp+0xB0]
00007583d7bd89e0  vmovaps xmm13, [rsp+0xC0]
00007583d7bd89e9  vmovaps xmm14, [rsp+0xD0]
00007583d7bd89f2  vmovaps xmm15, [rsp+0xE0]
00007583d7bd89fb  add rsp, 0xF0
00007583d7bd8a02  pop r11
00007583d7bd8a04  pop r10
00007583d7bd8a06  pop r9
00007583d7bd8a08  pop r8
00007583d7bd8a0a  pop rsi
00007583d7bd8a0b  pop rdi
00007583d7bd8a0c  pop rdx
00007583d7bd8a0d  pop rcx
00007583d7bd8a0e  pop rax
00007583d7bd8a0f  add rsp, 0x08
00007583d7bd8a13  jmp 0x00007583D7BD6A96
00007583d7bd8a18  sub rsp, 0x08
00007583d7bd8a1c  push rax
00007583d7bd8a1d  push rcx
00007583d7bd8a1e  push rdx
00007583d7bd8a1f  push rdi
00007583d7bd8a20  push rsi
00007583d7bd8a21  push r8
00007583d7bd8a23  push r9
00007583d7bd8a25  push r10
00007583d7bd8a27  push r11
00007583d7bd8a29  sub rsp, 0xF0
00007583d7bd8a30  vmovaps [rsp], xmm0
00007583d7bd8a35  vmovaps [rsp+0x10], xmm1
00007583d7bd8a3b  vmovaps [rsp+0x20], xmm2
00007583d7bd8a41  vmovaps [rsp+0x30], xmm3
00007583d7bd8a47  vmovaps [rsp+0x40], xmm4
00007583d7bd8a4d  vmovaps [rsp+0x50], xmm5
00007583d7bd8a53  vmovaps [rsp+0x60], xmm6
00007583d7bd8a59  vmovaps [rsp+0x70], xmm7
00007583d7bd8a5f  vmovaps [rsp+0x80], xmm8
00007583d7bd8a68  vmovaps [rsp+0x90], xmm10
00007583d7bd8a71  vmovaps [rsp+0xA0], xmm11
00007583d7bd8a7a  vmovaps [rsp+0xB0], xmm12
00007583d7bd8a83  vmovaps [rsp+0xC0], xmm13
00007583d7bd8a8c  vmovaps [rsp+0xD0], xmm14
00007583d7bd8a95  vmovaps [rsp+0xE0], xmm15
00007583d7bd8a9e  sub rsp, 0x40
00007583d7bd8aa2  lea rdi, [rsp]
00007583d7bd8aa6  lea rsi, [rsp+0x10]
00007583d7bd8aab  lea rdx, [rsp+0x20]
00007583d7bd8ab0  lea rcx, [rsp+0x30]
00007583d7bd8ab5  mov r8d, 0x00
00007583d7bd8abb  lea r9, [r15+0x3A8]
00007583d7bd8ac2  movaps [rdi], xmm9
00007583d7bd8ac6  movaps [rsi], xmm6
00007583d7bd8ac9  movaps [rdx], xmm1
00007583d7bd8acc  movaps [rcx], xmm11
00007583d7bd8ad0  mov rax, 0x5BCB7EA35A50
00007583d7bd8ada  call rax
00007583d7bd8adc  movaps xmm9, [rsp]
00007583d7bd8ae1  add rsp, 0x40
00007583d7bd8ae5  vmovaps xmm0, [rsp]
00007583d7bd8aea  vmovaps xmm1, [rsp+0x10]
00007583d7bd8af0  vmovaps xmm2, [rsp+0x20]
00007583d7bd8af6  vmovaps xmm3, [rsp+0x30]
00007583d7bd8afc  vmovaps xmm4, [rsp+0x40]
00007583d7bd8b02  vmovaps xmm5, [rsp+0x50]
00007583d7bd8b08  vmovaps xmm6, [rsp+0x60]
00007583d7bd8b0e  vmovaps xmm7, [rsp+0x70]
00007583d7bd8b14  vmovaps xmm8, [rsp+0x80]
00007583d7bd8b1d  vmovaps xmm10, [rsp+0x90]
00007583d7bd8b26  vmovaps xmm11, [rsp+0xA0]
00007583d7bd8b2f  vmovaps xmm12, [rsp+0xB0]
00007583d7bd8b38  vmovaps xmm13, [rsp+0xC0]
00007583d7bd8b41  vmovaps xmm14, [rsp+0xD0]
00007583d7bd8b4a  vmovaps xmm15, [rsp+0xE0]
00007583d7bd8b53  add rsp, 0xF0
00007583d7bd8b5a  pop r11
00007583d7bd8b5c  pop r10
00007583d7bd8b5e  pop r9
00007583d7bd8b60  pop r8
00007583d7bd8b62  pop rsi
00007583d7bd8b63  pop rdi
00007583d7bd8b64  pop rdx
00007583d7bd8b65  pop rcx
00007583d7bd8b66  pop rax
00007583d7bd8b67  add rsp, 0x08
00007583d7bd8b6b  jmp 0x00007583D7BD6ABC
00007583d7bd8b70  sub rsp, 0x08
00007583d7bd8b74  push rax
00007583d7bd8b75  push rcx
00007583d7bd8b76  push rdx
00007583d7bd8b77  push rdi
00007583d7bd8b78  push rsi
00007583d7bd8b79  push r8
00007583d7bd8b7b  push r9
00007583d7bd8b7d  push r10
00007583d7bd8b7f  push r11
00007583d7bd8b81  sub rsp, 0xF0
00007583d7bd8b88  vmovaps [rsp], xmm0
00007583d7bd8b8d  vmovaps [rsp+0x10], xmm1
00007583d7bd8b93  vmovaps [rsp+0x20], xmm2
00007583d7bd8b99  vmovaps [rsp+0x30], xmm3
00007583d7bd8b9f  vmovaps [rsp+0x40], xmm4
00007583d7bd8ba5  vmovaps [rsp+0x50], xmm5
00007583d7bd8bab  vmovaps [rsp+0x60], xmm6
00007583d7bd8bb1  vmovaps [rsp+0x70], xmm7
00007583d7bd8bb7  vmovaps [rsp+0x80], xmm8
00007583d7bd8bc0  vmovaps [rsp+0x90], xmm9
00007583d7bd8bc9  vmovaps [rsp+0xA0], xmm10
00007583d7bd8bd2  vmovaps [rsp+0xB0], xmm12
00007583d7bd8bdb  vmovaps [rsp+0xC0], xmm13
00007583d7bd8be4  vmovaps [rsp+0xD0], xmm14
00007583d7bd8bed  vmovaps [rsp+0xE0], xmm15
00007583d7bd8bf6  sub rsp, 0x40
00007583d7bd8bfa  lea rdi, [rsp]
00007583d7bd8bfe  lea rsi, [rsp+0x10]
00007583d7bd8c03  lea rdx, [rsp+0x20]
00007583d7bd8c08  lea rcx, [rsp+0x30]
00007583d7bd8c0d  mov r8d, 0x00
00007583d7bd8c13  lea r9, [r15+0x3A8]
00007583d7bd8c1a  movaps [rdi], xmm11
00007583d7bd8c1e  movaps [rsi], xmm10
00007583d7bd8c22  movaps [rdx], xmm8
00007583d7bd8c26  movaps [rcx], xmm1
00007583d7bd8c29  mov rax, 0x5BCB7EA35A50
00007583d7bd8c33  call rax
00007583d7bd8c35  movaps xmm11, [rsp]
00007583d7bd8c3a  add rsp, 0x40
00007583d7bd8c3e  vmovaps xmm0, [rsp]
00007583d7bd8c43  vmovaps xmm1, [rsp+0x10]
00007583d7bd8c49  vmovaps xmm2, [rsp+0x20]
00007583d7bd8c4f  vmovaps xmm3, [rsp+0x30]
00007583d7bd8c55  vmovaps xmm4, [rsp+0x40]
00007583d7bd8c5b  vmovaps xmm5, [rsp+0x50]
00007583d7bd8c61  vmovaps xmm6, [rsp+0x60]
00007583d7bd8c67  vmovaps xmm7, [rsp+0x70]
00007583d7bd8c6d  vmovaps xmm8, [rsp+0x80]
00007583d7bd8c76  vmovaps xmm9, [rsp+0x90]
00007583d7bd8c7f  vmovaps xmm10, [rsp+0xA0]
00007583d7bd8c88  vmovaps xmm12, [rsp+0xB0]
00007583d7bd8c91  vmovaps xmm13, [rsp+0xC0]
00007583d7bd8c9a  vmovaps xmm14, [rsp+0xD0]
00007583d7bd8ca3  vmovaps xmm15, [rsp+0xE0]
00007583d7bd8cac  add rsp, 0xF0
00007583d7bd8cb3  pop r11
00007583d7bd8cb5  pop r10
00007583d7bd8cb7  pop r9
00007583d7bd8cb9  pop r8
00007583d7bd8cbb  pop rsi
00007583d7bd8cbc  pop rdi
00007583d7bd8cbd  pop rdx
00007583d7bd8cbe  pop rcx
00007583d7bd8cbf  pop rax
00007583d7bd8cc0  add rsp, 0x08
00007583d7bd8cc4  jmp 0x00007583D7BD6AE2
00007583d7bd8cc9  sub rsp, 0x08
00007583d7bd8ccd  push rax
00007583d7bd8cce  push rcx
00007583d7bd8ccf  push rdx
00007583d7bd8cd0  push rdi
00007583d7bd8cd1  push rsi
00007583d7bd8cd2  push r8
00007583d7bd8cd4  push r9
00007583d7bd8cd6  push r10
00007583d7bd8cd8  push r11
00007583d7bd8cda  sub rsp, 0xF0
00007583d7bd8ce1  vmovaps [rsp], xmm0
00007583d7bd8ce6  vmovaps [rsp+0x10], xmm1
00007583d7bd8cec  vmovaps [rsp+0x20], xmm2
00007583d7bd8cf2  vmovaps [rsp+0x30], xmm3
00007583d7bd8cf8  vmovaps [rsp+0x40], xmm4
00007583d7bd8cfe  vmovaps [rsp+0x50], xmm5
00007583d7bd8d04  vmovaps [rsp+0x60], xmm6
00007583d7bd8d0a  vmovaps [rsp+0x70], xmm7
00007583d7bd8d10  vmovaps [rsp+0x80], xmm8
00007583d7bd8d19  vmovaps [rsp+0x90], xmm9
00007583d7bd8d22  vmovaps [rsp+0xA0], xmm11
00007583d7bd8d2b  vmovaps [rsp+0xB0], xmm12
00007583d7bd8d34  vmovaps [rsp+0xC0], xmm13
00007583d7bd8d3d  vmovaps [rsp+0xD0], xmm14
00007583d7bd8d46  vmovaps [rsp+0xE0], xmm15
00007583d7bd8d4f  sub rsp, 0x40
00007583d7bd8d53  lea rdi, [rsp]
00007583d7bd8d57  lea rsi, [rsp+0x10]
00007583d7bd8d5c  lea rdx, [rsp+0x20]
00007583d7bd8d61  lea rcx, [rsp+0x30]
00007583d7bd8d66  mov r8d, 0x00
00007583d7bd8d6c  lea r9, [r15+0x3A8]
00007583d7bd8d73  movaps [rdi], xmm10
00007583d7bd8d77  movaps [rsi], xmm12
00007583d7bd8d7b  movaps [rdx], xmm13
00007583d7bd8d7f  movaps [rcx], xmm1
00007583d7bd8d82  mov rax, 0x5BCB7EA35A50
00007583d7bd8d8c  call rax
00007583d7bd8d8e  movaps xmm10, [rsp]
00007583d7bd8d93  add rsp, 0x40
00007583d7bd8d97  vmovaps xmm0, [rsp]
00007583d7bd8d9c  vmovaps xmm1, [rsp+0x10]
00007583d7bd8da2  vmovaps xmm2, [rsp+0x20]
00007583d7bd8da8  vmovaps xmm3, [rsp+0x30]
00007583d7bd8dae  vmovaps xmm4, [rsp+0x40]
00007583d7bd8db4  vmovaps xmm5, [rsp+0x50]
00007583d7bd8dba  vmovaps xmm6, [rsp+0x60]
00007583d7bd8dc0  vmovaps xmm7, [rsp+0x70]
00007583d7bd8dc6  vmovaps xmm8, [rsp+0x80]
00007583d7bd8dcf  vmovaps xmm9, [rsp+0x90]
00007583d7bd8dd8  vmovaps xmm11, [rsp+0xA0]
00007583d7bd8de1  vmovaps xmm12, [rsp+0xB0]
00007583d7bd8dea  vmovaps xmm13, [rsp+0xC0]
00007583d7bd8df3  vmovaps xmm14, [rsp+0xD0]
00007583d7bd8dfc  vmovaps xmm15, [rsp+0xE0]
00007583d7bd8e05  add rsp, 0xF0
00007583d7bd8e0c  pop r11
00007583d7bd8e0e  pop r10
00007583d7bd8e10  pop r9
00007583d7bd8e12  pop r8
00007583d7bd8e14  pop rsi
00007583d7bd8e15  pop rdi
00007583d7bd8e16  pop rdx
00007583d7bd8e17  pop rcx
00007583d7bd8e18  pop rax
00007583d7bd8e19  add rsp, 0x08
00007583d7bd8e1d  jmp 0x00007583D7BD6B08
00007583d7bd8e22  call 0x00007583D7AD64F0
00007583d7bd8e27  jmp 0x00007583D7BD6B12
00007583d7bd8e2c  call 0x00007583D7AE3320
00007583d7bd8e31  jmp 0x00007583D7BD6B1C
00007583d7bd8e36  sub rsp, 0x08
00007583d7bd8e3a  push rax
00007583d7bd8e3b  push rcx
00007583d7bd8e3c  push rdx
00007583d7bd8e3d  push rdi
00007583d7bd8e3e  push rsi
00007583d7bd8e3f  push r8
00007583d7bd8e41  push r9
00007583d7bd8e43  push r10
00007583d7bd8e45  push r11
00007583d7bd8e47  sub rsp, 0xF0
00007583d7bd8e4e  vmovaps [rsp], xmm0
00007583d7bd8e53  vmovaps [rsp+0x10], xmm1
00007583d7bd8e59  vmovaps [rsp+0x20], xmm2
00007583d7bd8e5f  vmovaps [rsp+0x30], xmm3
00007583d7bd8e65  vmovaps [rsp+0x40], xmm4
00007583d7bd8e6b  vmovaps [rsp+0x50], xmm5
00007583d7bd8e71  vmovaps [rsp+0x60], xmm6
00007583d7bd8e77  vmovaps [rsp+0x70], xmm7
00007583d7bd8e7d  vmovaps [rsp+0x80], xmm9
00007583d7bd8e86  vmovaps [rsp+0x90], xmm10
00007583d7bd8e8f  vmovaps [rsp+0xA0], xmm11
00007583d7bd8e98  vmovaps [rsp+0xB0], xmm12
00007583d7bd8ea1  vmovaps [rsp+0xC0], xmm13
00007583d7bd8eaa  vmovaps [rsp+0xD0], xmm14
00007583d7bd8eb3  vmovaps [rsp+0xE0], xmm15
00007583d7bd8ebc  sub rsp, 0x40
00007583d7bd8ec0  lea rdi, [rsp]
00007583d7bd8ec4  lea rsi, [rsp+0x10]
00007583d7bd8ec9  lea rdx, [rsp+0x20]
00007583d7bd8ece  lea rcx, [rsp+0x30]
00007583d7bd8ed3  mov r8d, 0x00
00007583d7bd8ed9  lea r9, [r15+0x3A8]
00007583d7bd8ee0  movaps [rdi], xmm8
00007583d7bd8ee4  movaps [rsi], xmm7
00007583d7bd8ee7  movaps [rdx], xmm4
00007583d7bd8eea  movaps [rcx], xmm12
00007583d7bd8eee  mov rax, 0x5BCB7EA35A50
00007583d7bd8ef8  call rax
00007583d7bd8efa  movaps xmm8, [rsp]
00007583d7bd8eff  add rsp, 0x40
00007583d7bd8f03  vmovaps xmm0, [rsp]
00007583d7bd8f08  vmovaps xmm1, [rsp+0x10]
00007583d7bd8f0e  vmovaps xmm2, [rsp+0x20]
00007583d7bd8f14  vmovaps xmm3, [rsp+0x30]
00007583d7bd8f1a  vmovaps xmm4, [rsp+0x40]
00007583d7bd8f20  vmovaps xmm5, [rsp+0x50]
00007583d7bd8f26  vmovaps xmm6, [rsp+0x60]
00007583d7bd8f2c  vmovaps xmm7, [rsp+0x70]
00007583d7bd8f32  vmovaps xmm9, [rsp+0x80]
00007583d7bd8f3b  vmovaps xmm10, [rsp+0x90]
00007583d7bd8f44  vmovaps xmm11, [rsp+0xA0]
00007583d7bd8f4d  vmovaps xmm12, [rsp+0xB0]
00007583d7bd8f56  vmovaps xmm13, [rsp+0xC0]
00007583d7bd8f5f  vmovaps xmm14, [rsp+0xD0]
00007583d7bd8f68  vmovaps xmm15, [rsp+0xE0]
00007583d7bd8f71  add rsp, 0xF0
00007583d7bd8f78  pop r11
00007583d7bd8f7a  pop r10
00007583d7bd8f7c  pop r9
00007583d7bd8f7e  pop r8
00007583d7bd8f80  pop rsi
00007583d7bd8f81  pop rdi
00007583d7bd8f82  pop rdx
00007583d7bd8f83  pop rcx
00007583d7bd8f84  pop rax
00007583d7bd8f85  add rsp, 0x08
00007583d7bd8f89  jmp 0x00007583D7BD6B45
00007583d7bd8f8e  sub rsp, 0x08
00007583d7bd8f92  push rax
00007583d7bd8f93  push rcx
00007583d7bd8f94  push rdx
00007583d7bd8f95  push rdi
00007583d7bd8f96  push rsi
00007583d7bd8f97  push r8
00007583d7bd8f99  push r9
00007583d7bd8f9b  push r10
00007583d7bd8f9d  push r11
00007583d7bd8f9f  sub rsp, 0xF0
00007583d7bd8fa6  vmovaps [rsp], xmm0
00007583d7bd8fab  vmovaps [rsp+0x10], xmm1
00007583d7bd8fb1  vmovaps [rsp+0x20], xmm2
00007583d7bd8fb7  vmovaps [rsp+0x30], xmm3
00007583d7bd8fbd  vmovaps [rsp+0x40], xmm4
00007583d7bd8fc3  vmovaps [rsp+0x50], xmm5
00007583d7bd8fc9  vmovaps [rsp+0x60], xmm6
00007583d7bd8fcf  vmovaps [rsp+0x70], xmm8
00007583d7bd8fd5  vmovaps [rsp+0x80], xmm9
00007583d7bd8fde  vmovaps [rsp+0x90], xmm10
00007583d7bd8fe7  vmovaps [rsp+0xA0], xmm11
00007583d7bd8ff0  vmovaps [rsp+0xB0], xmm12
00007583d7bd8ff9  vmovaps [rsp+0xC0], xmm13
00007583d7bd9002  vmovaps [rsp+0xD0], xmm14
00007583d7bd900b  vmovaps [rsp+0xE0], xmm15
00007583d7bd9014  sub rsp, 0x40
00007583d7bd9018  lea rdi, [rsp]
00007583d7bd901c  lea rsi, [rsp+0x10]
00007583d7bd9021  lea rdx, [rsp+0x20]
00007583d7bd9026  lea rcx, [rsp+0x30]
00007583d7bd902b  mov r8d, 0x00
00007583d7bd9031  lea r9, [r15+0x3A8]
00007583d7bd9038  movaps [rdi], xmm7
00007583d7bd903b  movaps [rsi], xmm9
00007583d7bd903f  movaps [rdx], xmm14
00007583d7bd9043  movaps [rcx], xmm12
00007583d7bd9047  mov rax, 0x5BCB7EA35A50
00007583d7bd9051  call rax
00007583d7bd9053  movaps xmm7, [rsp]
00007583d7bd9057  add rsp, 0x40
00007583d7bd905b  vmovaps xmm0, [rsp]
00007583d7bd9060  vmovaps xmm1, [rsp+0x10]
00007583d7bd9066  vmovaps xmm2, [rsp+0x20]
00007583d7bd906c  vmovaps xmm3, [rsp+0x30]
00007583d7bd9072  vmovaps xmm4, [rsp+0x40]
00007583d7bd9078  vmovaps xmm5, [rsp+0x50]
00007583d7bd907e  vmovaps xmm6, [rsp+0x60]
00007583d7bd9084  vmovaps xmm8, [rsp+0x70]
00007583d7bd908a  vmovaps xmm9, [rsp+0x80]
00007583d7bd9093  vmovaps xmm10, [rsp+0x90]
00007583d7bd909c  vmovaps xmm11, [rsp+0xA0]
00007583d7bd90a5  vmovaps xmm12, [rsp+0xB0]
00007583d7bd90ae  vmovaps xmm13, [rsp+0xC0]
00007583d7bd90b7  vmovaps xmm14, [rsp+0xD0]
00007583d7bd90c0  vmovaps xmm15, [rsp+0xE0]
00007583d7bd90c9  add rsp, 0xF0
00007583d7bd90d0  pop r11
00007583d7bd90d2  pop r10
00007583d7bd90d4  pop r9
00007583d7bd90d6  pop r8
00007583d7bd90d8  pop rsi
00007583d7bd90d9  pop rdi
00007583d7bd90da  pop rdx
00007583d7bd90db  pop rcx
00007583d7bd90dc  pop rax
00007583d7bd90dd  add rsp, 0x08
00007583d7bd90e1  jmp 0x00007583D7BD6B6D
00007583d7bd90e6  sub rsp, 0x08
00007583d7bd90ea  push rax
00007583d7bd90eb  push rcx
00007583d7bd90ec  push rdx
00007583d7bd90ed  push rdi
00007583d7bd90ee  push rsi
00007583d7bd90ef  push r8
00007583d7bd90f1  push r9
00007583d7bd90f3  push r10
00007583d7bd90f5  push r11
00007583d7bd90f7  sub rsp, 0xF0
00007583d7bd90fe  vmovaps [rsp], xmm0
00007583d7bd9103  vmovaps [rsp+0x10], xmm1
00007583d7bd9109  vmovaps [rsp+0x20], xmm2
00007583d7bd910f  vmovaps [rsp+0x30], xmm3
00007583d7bd9115  vmovaps [rsp+0x40], xmm4
00007583d7bd911b  vmovaps [rsp+0x50], xmm5
00007583d7bd9121  vmovaps [rsp+0x60], xmm6
00007583d7bd9127  vmovaps [rsp+0x70], xmm7
00007583d7bd912d  vmovaps [rsp+0x80], xmm8
00007583d7bd9136  vmovaps [rsp+0x90], xmm9
00007583d7bd913f  vmovaps [rsp+0xA0], xmm10
00007583d7bd9148  vmovaps [rsp+0xB0], xmm11
00007583d7bd9151  vmovaps [rsp+0xC0], xmm13
00007583d7bd915a  vmovaps [rsp+0xD0], xmm14
00007583d7bd9163  vmovaps [rsp+0xE0], xmm15
00007583d7bd916c  sub rsp, 0x40
00007583d7bd9170  lea rdi, [rsp]
00007583d7bd9174  lea rsi, [rsp+0x10]
00007583d7bd9179  lea rdx, [rsp+0x20]
00007583d7bd917e  lea rcx, [rsp+0x30]
00007583d7bd9183  mov r8d, 0x00
00007583d7bd9189  lea r9, [r15+0x3A8]
00007583d7bd9190  movaps [rdi], xmm12
00007583d7bd9194  movaps [rsi], xmm11
00007583d7bd9198  movaps [rdx], xmm15
00007583d7bd919c  movaps [rcx], xmm14
00007583d7bd91a0  mov rax, 0x5BCB7EA35A50
00007583d7bd91aa  call rax
00007583d7bd91ac  movaps xmm12, [rsp]
00007583d7bd91b1  add rsp, 0x40
00007583d7bd91b5  vmovaps xmm0, [rsp]
00007583d7bd91ba  vmovaps xmm1, [rsp+0x10]
00007583d7bd91c0  vmovaps xmm2, [rsp+0x20]
00007583d7bd91c6  vmovaps xmm3, [rsp+0x30]
00007583d7bd91cc  vmovaps xmm4, [rsp+0x40]
00007583d7bd91d2  vmovaps xmm5, [rsp+0x50]
00007583d7bd91d8  vmovaps xmm6, [rsp+0x60]
00007583d7bd91de  vmovaps xmm7, [rsp+0x70]
00007583d7bd91e4  vmovaps xmm8, [rsp+0x80]
00007583d7bd91ed  vmovaps xmm9, [rsp+0x90]
00007583d7bd91f6  vmovaps xmm10, [rsp+0xA0]
00007583d7bd91ff  vmovaps xmm11, [rsp+0xB0]
00007583d7bd9208  vmovaps xmm13, [rsp+0xC0]
00007583d7bd9211  vmovaps xmm14, [rsp+0xD0]
00007583d7bd921a  vmovaps xmm15, [rsp+0xE0]
00007583d7bd9223  add rsp, 0xF0
00007583d7bd922a  pop r11
00007583d7bd922c  pop r10
00007583d7bd922e  pop r9
00007583d7bd9230  pop r8
00007583d7bd9232  pop rsi
00007583d7bd9233  pop rdi
00007583d7bd9234  pop rdx
00007583d7bd9235  pop rcx
00007583d7bd9236  pop rax
00007583d7bd9237  add rsp, 0x08
00007583d7bd923b  jmp 0x00007583D7BD6B96
00007583d7bd9240  sub rsp, 0x08
00007583d7bd9244  push rax
00007583d7bd9245  push rcx
00007583d7bd9246  push rdx
00007583d7bd9247  push rdi
00007583d7bd9248  push rsi
00007583d7bd9249  push r8
00007583d7bd924b  push r9
00007583d7bd924d  push r10
00007583d7bd924f  push r11
00007583d7bd9251  sub rsp, 0xF0
00007583d7bd9258  vmovaps [rsp], xmm0
00007583d7bd925d  vmovaps [rsp+0x10], xmm1
00007583d7bd9263  vmovaps [rsp+0x20], xmm2
00007583d7bd9269  vmovaps [rsp+0x30], xmm3
00007583d7bd926f  vmovaps [rsp+0x40], xmm4
00007583d7bd9275  vmovaps [rsp+0x50], xmm5
00007583d7bd927b  vmovaps [rsp+0x60], xmm6
00007583d7bd9281  vmovaps [rsp+0x70], xmm7
00007583d7bd9287  vmovaps [rsp+0x80], xmm8
00007583d7bd9290  vmovaps [rsp+0x90], xmm9
00007583d7bd9299  vmovaps [rsp+0xA0], xmm10
00007583d7bd92a2  vmovaps [rsp+0xB0], xmm12
00007583d7bd92ab  vmovaps [rsp+0xC0], xmm13
00007583d7bd92b4  vmovaps [rsp+0xD0], xmm14
00007583d7bd92bd  vmovaps [rsp+0xE0], xmm15
00007583d7bd92c6  sub rsp, 0x40
00007583d7bd92ca  lea rdi, [rsp]
00007583d7bd92ce  lea rsi, [rsp+0x10]
00007583d7bd92d3  lea rdx, [rsp+0x20]
00007583d7bd92d8  lea rcx, [rsp+0x30]
00007583d7bd92dd  mov r8d, 0x00
00007583d7bd92e3  lea r9, [r15+0x3A8]
00007583d7bd92ea  movaps [rdi], xmm11
00007583d7bd92ee  movaps [rsi], xmm10
00007583d7bd92f2  movaps [rdx], xmm13
00007583d7bd92f6  movaps [rcx], xmm15
00007583d7bd92fa  mov rax, 0x5BCB7EA35A50
00007583d7bd9304  call rax
00007583d7bd9306  movaps xmm11, [rsp]
00007583d7bd930b  add rsp, 0x40
00007583d7bd930f  vmovaps xmm0, [rsp]
00007583d7bd9314  vmovaps xmm1, [rsp+0x10]
00007583d7bd931a  vmovaps xmm2, [rsp+0x20]
00007583d7bd9320  vmovaps xmm3, [rsp+0x30]
00007583d7bd9326  vmovaps xmm4, [rsp+0x40]
00007583d7bd932c  vmovaps xmm5, [rsp+0x50]
00007583d7bd9332  vmovaps xmm6, [rsp+0x60]
00007583d7bd9338  vmovaps xmm7, [rsp+0x70]
00007583d7bd933e  vmovaps xmm8, [rsp+0x80]
00007583d7bd9347  vmovaps xmm9, [rsp+0x90]
00007583d7bd9350  vmovaps xmm10, [rsp+0xA0]
00007583d7bd9359  vmovaps xmm12, [rsp+0xB0]
00007583d7bd9362  vmovaps xmm13, [rsp+0xC0]
00007583d7bd936b  vmovaps xmm14, [rsp+0xD0]
00007583d7bd9374  vmovaps xmm15, [rsp+0xE0]
00007583d7bd937d  add rsp, 0xF0
00007583d7bd9384  pop r11
00007583d7bd9386  pop r10
00007583d7bd9388  pop r9
00007583d7bd938a  pop r8
00007583d7bd938c  pop rsi
00007583d7bd938d  pop rdi
00007583d7bd938e  pop rdx
00007583d7bd938f  pop rcx
00007583d7bd9390  pop rax
00007583d7bd9391  add rsp, 0x08
00007583d7bd9395  jmp 0x00007583D7BD6BBF
00007583d7bd939a  call 0x00007583D7AE5820
00007583d7bd939f  jmp 0x00007583D7BD6BCC
00007583d7bd93a4  call 0x00007583D7AE45A0
00007583d7bd93a9  jmp 0x00007583D7BD6BD9
00007583d7bd93ae  sub rsp, 0x08
00007583d7bd93b2  push rax
00007583d7bd93b3  push rcx
00007583d7bd93b4  push rdx
00007583d7bd93b5  push rdi
00007583d7bd93b6  push rsi
00007583d7bd93b7  push r8
00007583d7bd93b9  push r9
00007583d7bd93bb  push r10
00007583d7bd93bd  push r11
00007583d7bd93bf  sub rsp, 0xF0
00007583d7bd93c6  vmovaps [rsp], xmm0
00007583d7bd93cb  vmovaps [rsp+0x10], xmm1
00007583d7bd93d1  vmovaps [rsp+0x20], xmm2
00007583d7bd93d7  vmovaps [rsp+0x30], xmm3
00007583d7bd93dd  vmovaps [rsp+0x40], xmm4
00007583d7bd93e3  vmovaps [rsp+0x50], xmm5
00007583d7bd93e9  vmovaps [rsp+0x60], xmm6
00007583d7bd93ef  vmovaps [rsp+0x70], xmm7
00007583d7bd93f5  vmovaps [rsp+0x80], xmm8
00007583d7bd93fe  vmovaps [rsp+0x90], xmm9
00007583d7bd9407  vmovaps [rsp+0xA0], xmm11
00007583d7bd9410  vmovaps [rsp+0xB0], xmm12
00007583d7bd9419  vmovaps [rsp+0xC0], xmm13
00007583d7bd9422  vmovaps [rsp+0xD0], xmm14
00007583d7bd942b  vmovaps [rsp+0xE0], xmm15
00007583d7bd9434  sub rsp, 0x40
00007583d7bd9438  lea rdi, [rsp]
00007583d7bd943c  lea rsi, [rsp+0x10]
00007583d7bd9441  lea rdx, [rsp+0x20]
00007583d7bd9446  lea rcx, [rsp+0x30]
00007583d7bd944b  mov r8d, 0x00
00007583d7bd9451  lea r9, [r15+0x3A8]
00007583d7bd9458  movaps [rdi], xmm10
00007583d7bd945c  movaps [rsi], xmm8
00007583d7bd9460  movaps [rdx], xmm1
00007583d7bd9463  movaps [rcx], xmm13
00007583d7bd9467  mov rax, 0x5BCB7EA35A50
00007583d7bd9471  call rax
00007583d7bd9473  movaps xmm10, [rsp]
00007583d7bd9478  add rsp, 0x40
00007583d7bd947c  vmovaps xmm0, [rsp]
00007583d7bd9481  vmovaps xmm1, [rsp+0x10]
00007583d7bd9487  vmovaps xmm2, [rsp+0x20]
00007583d7bd948d  vmovaps xmm3, [rsp+0x30]
00007583d7bd9493  vmovaps xmm4, [rsp+0x40]
00007583d7bd9499  vmovaps xmm5, [rsp+0x50]
00007583d7bd949f  vmovaps xmm6, [rsp+0x60]
00007583d7bd94a5  vmovaps xmm7, [rsp+0x70]
00007583d7bd94ab  vmovaps xmm8, [rsp+0x80]
00007583d7bd94b4  vmovaps xmm9, [rsp+0x90]
00007583d7bd94bd  vmovaps xmm11, [rsp+0xA0]
00007583d7bd94c6  vmovaps xmm12, [rsp+0xB0]
00007583d7bd94cf  vmovaps xmm13, [rsp+0xC0]
00007583d7bd94d8  vmovaps xmm14, [rsp+0xD0]
00007583d7bd94e1  vmovaps xmm15, [rsp+0xE0]
00007583d7bd94ea  add rsp, 0xF0
00007583d7bd94f1  pop r11
00007583d7bd94f3  pop r10
00007583d7bd94f5  pop r9
00007583d7bd94f7  pop r8
00007583d7bd94f9  pop rsi
00007583d7bd94fa  pop rdi
00007583d7bd94fb  pop rdx
00007583d7bd94fc  pop rcx
00007583d7bd94fd  pop rax
00007583d7bd94fe  add rsp, 0x08
00007583d7bd9502  jmp 0x00007583D7BD6C0F
00007583d7bd9507  call 0x00007583D7AD64F0
00007583d7bd950c  jmp 0x00007583D7BD6C21
00007583d7bd9511  sub rsp, 0x08
00007583d7bd9515  push rax
00007583d7bd9516  push rcx
00007583d7bd9517  push rdx
00007583d7bd9518  push rdi
00007583d7bd9519  push rsi
00007583d7bd951a  push r8
00007583d7bd951c  push r9
00007583d7bd951e  push r10
00007583d7bd9520  push r11
00007583d7bd9522  sub rsp, 0xF0
00007583d7bd9529  vmovaps [rsp], xmm0
00007583d7bd952e  vmovaps [rsp+0x10], xmm1
00007583d7bd9534  vmovaps [rsp+0x20], xmm2
00007583d7bd953a  vmovaps [rsp+0x30], xmm3
00007583d7bd9540  vmovaps [rsp+0x40], xmm4
00007583d7bd9546  vmovaps [rsp+0x50], xmm5
00007583d7bd954c  vmovaps [rsp+0x60], xmm6
00007583d7bd9552  vmovaps [rsp+0x70], xmm7
00007583d7bd9558  vmovaps [rsp+0x80], xmm8
00007583d7bd9561  vmovaps [rsp+0x90], xmm10
00007583d7bd956a  vmovaps [rsp+0xA0], xmm11
00007583d7bd9573  vmovaps [rsp+0xB0], xmm12
00007583d7bd957c  vmovaps [rsp+0xC0], xmm13
00007583d7bd9585  vmovaps [rsp+0xD0], xmm14
00007583d7bd958e  vmovaps [rsp+0xE0], xmm15
00007583d7bd9597  sub rsp, 0x40
00007583d7bd959b  lea rdi, [rsp]
00007583d7bd959f  lea rsi, [rsp+0x10]
00007583d7bd95a4  lea rdx, [rsp+0x20]
00007583d7bd95a9  lea rcx, [rsp+0x30]
00007583d7bd95ae  mov r8d, 0x00
00007583d7bd95b4  lea r9, [r15+0x3A8]
00007583d7bd95bb  movaps [rdi], xmm9
00007583d7bd95bf  movaps [rsi], xmm7
00007583d7bd95c2  movaps [rdx], xmm14
00007583d7bd95c6  movaps [rcx], xmm13
00007583d7bd95ca  mov rax, 0x5BCB7EA35A50
00007583d7bd95d4  call rax
00007583d7bd95d6  movaps xmm9, [rsp]
00007583d7bd95db  add rsp, 0x40
00007583d7bd95df  vmovaps xmm0, [rsp]
00007583d7bd95e4  vmovaps xmm1, [rsp+0x10]
00007583d7bd95ea  vmovaps xmm2, [rsp+0x20]
00007583d7bd95f0  vmovaps xmm3, [rsp+0x30]
00007583d7bd95f6  vmovaps xmm4, [rsp+0x40]
00007583d7bd95fc  vmovaps xmm5, [rsp+0x50]
00007583d7bd9602  vmovaps xmm6, [rsp+0x60]
00007583d7bd9608  vmovaps xmm7, [rsp+0x70]
00007583d7bd960e  vmovaps xmm8, [rsp+0x80]
00007583d7bd9617  vmovaps xmm10, [rsp+0x90]
00007583d7bd9620  vmovaps xmm11, [rsp+0xA0]
00007583d7bd9629  vmovaps xmm12, [rsp+0xB0]
00007583d7bd9632  vmovaps xmm13, [rsp+0xC0]
00007583d7bd963b  vmovaps xmm14, [rsp+0xD0]
00007583d7bd9644  vmovaps xmm15, [rsp+0xE0]
00007583d7bd964d  add rsp, 0xF0
00007583d7bd9654  pop r11
00007583d7bd9656  pop r10
00007583d7bd9658  pop r9
00007583d7bd965a  pop r8
00007583d7bd965c  pop rsi
00007583d7bd965d  pop rdi
00007583d7bd965e  pop rdx
00007583d7bd965f  pop rcx
00007583d7bd9660  pop rax
00007583d7bd9661  add rsp, 0x08
00007583d7bd9665  jmp 0x00007583D7BD6C4F
00007583d7bd966a  sub rsp, 0x08
00007583d7bd966e  push rax
00007583d7bd966f  push rcx
00007583d7bd9670  push rdx
00007583d7bd9671  push rdi
00007583d7bd9672  push rsi
00007583d7bd9673  push r8
00007583d7bd9675  push r9
00007583d7bd9677  push r10
00007583d7bd9679  push r11
00007583d7bd967b  sub rsp, 0xF0
00007583d7bd9682  vmovaps [rsp], xmm0
00007583d7bd9687  vmovaps [rsp+0x10], xmm1
00007583d7bd968d  vmovaps [rsp+0x20], xmm2
00007583d7bd9693  vmovaps [rsp+0x30], xmm3
00007583d7bd9699  vmovaps [rsp+0x40], xmm4
00007583d7bd969f  vmovaps [rsp+0x50], xmm5
00007583d7bd96a5  vmovaps [rsp+0x60], xmm6
00007583d7bd96ab  vmovaps [rsp+0x70], xmm7
00007583d7bd96b1  vmovaps [rsp+0x80], xmm8
00007583d7bd96ba  vmovaps [rsp+0x90], xmm9
00007583d7bd96c3  vmovaps [rsp+0xA0], xmm10
00007583d7bd96cc  vmovaps [rsp+0xB0], xmm11
00007583d7bd96d5  vmovaps [rsp+0xC0], xmm12
00007583d7bd96de  vmovaps [rsp+0xD0], xmm14
00007583d7bd96e7  vmovaps [rsp+0xE0], xmm15
00007583d7bd96f0  sub rsp, 0x40
00007583d7bd96f4  lea rdi, [rsp]
00007583d7bd96f8  lea rsi, [rsp+0x10]
00007583d7bd96fd  lea rdx, [rsp+0x20]
00007583d7bd9702  lea rcx, [rsp+0x30]
00007583d7bd9707  mov r8d, 0x00
00007583d7bd970d  lea r9, [r15+0x3A8]
00007583d7bd9714  movaps [rdi], xmm13
00007583d7bd9718  movaps [rsi], xmm12
00007583d7bd971c  movaps [rdx], xmm15
00007583d7bd9720  movaps [rcx], xmm14
00007583d7bd9724  mov rax, 0x5BCB7EA35A50
00007583d7bd972e  call rax
00007583d7bd9730  movaps xmm13, [rsp]
00007583d7bd9735  add rsp, 0x40
00007583d7bd9739  vmovaps xmm0, [rsp]
00007583d7bd973e  vmovaps xmm1, [rsp+0x10]
00007583d7bd9744  vmovaps xmm2, [rsp+0x20]
00007583d7bd974a  vmovaps xmm3, [rsp+0x30]
00007583d7bd9750  vmovaps xmm4, [rsp+0x40]
00007583d7bd9756  vmovaps xmm5, [rsp+0x50]
00007583d7bd975c  vmovaps xmm6, [rsp+0x60]
00007583d7bd9762  vmovaps xmm7, [rsp+0x70]
00007583d7bd9768  vmovaps xmm8, [rsp+0x80]
00007583d7bd9771  vmovaps xmm9, [rsp+0x90]
00007583d7bd977a  vmovaps xmm10, [rsp+0xA0]
00007583d7bd9783  vmovaps xmm11, [rsp+0xB0]
00007583d7bd978c  vmovaps xmm12, [rsp+0xC0]
00007583d7bd9795  vmovaps xmm14, [rsp+0xD0]
00007583d7bd979e  vmovaps xmm15, [rsp+0xE0]
00007583d7bd97a7  add rsp, 0xF0
00007583d7bd97ae  pop r11
00007583d7bd97b0  pop r10
00007583d7bd97b2  pop r9
00007583d7bd97b4  pop r8
00007583d7bd97b6  pop rsi
00007583d7bd97b7  pop rdi
00007583d7bd97b8  pop rdx
00007583d7bd97b9  pop rcx
00007583d7bd97ba  pop rax
00007583d7bd97bb  add rsp, 0x08
00007583d7bd97bf  jmp 0x00007583D7BD6C7D
00007583d7bd97c4  sub rsp, 0x08
00007583d7bd97c8  push rax
00007583d7bd97c9  push rcx
00007583d7bd97ca  push rdx
00007583d7bd97cb  push rdi
00007583d7bd97cc  push rsi
00007583d7bd97cd  push r8
00007583d7bd97cf  push r9
00007583d7bd97d1  push r10
00007583d7bd97d3  push r11
00007583d7bd97d5  sub rsp, 0xF0
00007583d7bd97dc  vmovaps [rsp], xmm0
00007583d7bd97e1  vmovaps [rsp+0x10], xmm1
00007583d7bd97e7  vmovaps [rsp+0x20], xmm2
00007583d7bd97ed  vmovaps [rsp+0x30], xmm3
00007583d7bd97f3  vmovaps [rsp+0x40], xmm4
00007583d7bd97f9  vmovaps [rsp+0x50], xmm5
00007583d7bd97ff  vmovaps [rsp+0x60], xmm6
00007583d7bd9805  vmovaps [rsp+0x70], xmm7
00007583d7bd980b  vmovaps [rsp+0x80], xmm8
00007583d7bd9814  vmovaps [rsp+0x90], xmm9
00007583d7bd981d  vmovaps [rsp+0xA0], xmm10
00007583d7bd9826  vmovaps [rsp+0xB0], xmm11
00007583d7bd982f  vmovaps [rsp+0xC0], xmm12
00007583d7bd9838  vmovaps [rsp+0xD0], xmm13
00007583d7bd9841  vmovaps [rsp+0xE0], xmm15
00007583d7bd984a  sub rsp, 0x40
00007583d7bd984e  lea rdi, [rsp]
00007583d7bd9852  lea rsi, [rsp+0x10]
00007583d7bd9857  lea rdx, [rsp+0x20]
00007583d7bd985c  lea rcx, [rsp+0x30]
00007583d7bd9861  mov r8d, 0x00
00007583d7bd9867  lea r9, [r15+0x3A8]
00007583d7bd986e  movaps [rdi], xmm14
00007583d7bd9872  movaps [rsi], xmm11
00007583d7bd9876  movaps [rdx], xmm1
00007583d7bd9879  movaps [rcx], xmm15
00007583d7bd987d  mov rax, 0x5BCB7EA35A50
00007583d7bd9887  call rax
00007583d7bd9889  movaps xmm14, [rsp]
00007583d7bd988e  add rsp, 0x40
00007583d7bd9892  vmovaps xmm0, [rsp]
00007583d7bd9897  vmovaps xmm1, [rsp+0x10]
00007583d7bd989d  vmovaps xmm2, [rsp+0x20]
00007583d7bd98a3  vmovaps xmm3, [rsp+0x30]
00007583d7bd98a9  vmovaps xmm4, [rsp+0x40]
00007583d7bd98af  vmovaps xmm5, [rsp+0x50]
00007583d7bd98b5  vmovaps xmm6, [rsp+0x60]
00007583d7bd98bb  vmovaps xmm7, [rsp+0x70]
00007583d7bd98c1  vmovaps xmm8, [rsp+0x80]
00007583d7bd98ca  vmovaps xmm9, [rsp+0x90]
00007583d7bd98d3  vmovaps xmm10, [rsp+0xA0]
00007583d7bd98dc  vmovaps xmm11, [rsp+0xB0]
00007583d7bd98e5  vmovaps xmm12, [rsp+0xC0]
00007583d7bd98ee  vmovaps xmm13, [rsp+0xD0]
00007583d7bd98f7  vmovaps xmm15, [rsp+0xE0]
00007583d7bd9900  add rsp, 0xF0
00007583d7bd9907  pop r11
00007583d7bd9909  pop r10
00007583d7bd990b  pop r9
00007583d7bd990d  pop r8
00007583d7bd990f  pop rsi
00007583d7bd9910  pop rdi
00007583d7bd9911  pop rdx
00007583d7bd9912  pop rcx
00007583d7bd9913  pop rax
00007583d7bd9914  add rsp, 0x08
00007583d7bd9918  jmp 0x00007583D7BD6CAB
00007583d7bd991d  call 0x00007583D7AACF70
00007583d7bd9922  jmp 0x00007583D7BD6CB9
00007583d7bd9927  call 0x00007583D7A0C380
00007583d7bd992c  jmp 0x00007583D7BD6CC3
00007583d7bd9931  call 0x00007583D7A08C20
00007583d7bd9936  jmp 0x00007583D7BD6CCD
00007583d7bd993b  call 0x00007583D7A0D600
00007583d7bd9940  jmp 0x00007583D7BD6CD7
00007583d7bd9945  int3
00007583d7bd9946  nop [rax+rax*1], ax
00007583d7bd994f  nop
00007583d7bd9950  mov eax, [r15+0x48]
00007583d7bd9954  lea r14d, [eax+0x01]
00007583d7bd9959  mov [rsp+0x10], r14d
00007583d7bd995e  mov r14d, r14d
00007583d7bd9961  mov [r15+0x48], r14
00007583d7bd9965  xor eax, eax
00007583d7bd9967  mov r14d, [rsp+0x10]
00007583d7bd996c  cmp r14d, 0x1F4
00007583d7bd9973  cmc
00007583d7bd9974  lahf
00007583d7bd9975  seto al
00007583d7bd9978  mov [r15+0x108], eax
00007583d7bd997f  mov eax, [r15+0x108]
00007583d7bd9986  sahf
00007583d7bd9987  jnz 0x00007583D7BD99B9
00007583d7bd9989  cmp dword ptr [r15+0x318], 0x00
00007583d7bd9991  jz 0x00007583D7BDD2E0
00007583d7bd9997  nop [rax+rax*1], ax
00007583d7bd99a0  nop [rax+rax*1], eax
00007583d7bd99a8  mov eax, 0x410670
00007583d7bd99ad  mov [r15+0x100], rax
00007583d7bd99b4  jmp 0x00007583D79FE110
00007583d7bd99b9  cmp dword ptr [r15+0x318], 0x00
00007583d7bd99c1  jz 0x00007583D7BD99F0
00007583d7bd99c7  nop [rax+rax*1], ax
00007583d7bd99d0  nop [rax+rax*1], eax
00007583d7bd99d8  mov eax, 0x4104EC
00007583d7bd99dd  mov [r15+0x100], rax
00007583d7bd99e4  jmp 0x00007583D79FE110
00007583d7bd99e9  int3
00007583d7bd99ea  int3
00007583d7bd99eb  nop [rax+rax*1], eax
00007583d7bd99f0  mov rax, [r15+0x40]
00007583d7bd99f4  vxorps xmm1, xmm1, xmm1
00007583d7bd99f8  vpbroadcastq xmm1, xmm1
00007583d7bd99fd  vxorps xmm15, xmm15, xmm15
00007583d7bd9a02  vpbroadcastq xmm15, xmm15
00007583d7bd9a07  lea r14, [rax+0x30]
00007583d7bd9a0b  mov r12, [r13+r14*1]
00007583d7bd9a10  lea r14, [rax+0x38]
00007583d7bd9a14  mov r11, [r13+r14*1]
00007583d7bd9a19  movq xmm14, r12
00007583d7bd9a1e  movq xmm13, r11
00007583d7bd9a23  movq xmm14, xmm14
00007583d7bd9a28  movq xmm13, xmm13
00007583d7bd9a2d  vmovaps [rsp+0x10], xmm13
00007583d7bd9a33  movq xmm13, xmm13
00007583d7bd9a38  movaps [r15+0x270], xmm13
00007583d7bd9a40  movaps xmm13, [r15+0x160]
00007583d7bd9a48  vmovaps [rsp+0x20], xmm13
00007583d7bd9a4e  vmovaps xmm12, [rsp+0x20]
00007583d7bd9a54  por xmm13, xmm12
00007583d7bd9a59  lea r14, [rax+0x20]
00007583d7bd9a5d  mov r12, [r13+r14*1]
00007583d7bd9a62  lea r14, [rax+0x28]
00007583d7bd9a66  mov r11, [r13+r14*1]
00007583d7bd9a6b  movq xmm12, r12
00007583d7bd9a70  movq xmm11, r11
00007583d7bd9a75  movq xmm12, xmm12
00007583d7bd9a7a  movq xmm11, xmm11
00007583d7bd9a7f  movaps xmm10, [r15+0x2D0]
00007583d7bd9a87  vmovaps [rsp+0x20], xmm10
00007583d7bd9a8d  vmovaps xmm9, [rsp+0x20]
00007583d7bd9a93  por xmm10, xmm9
00007583d7bd9a98  movaps xmm9, [r15+0x300]
00007583d7bd9aa0  vmovaps [rsp+0x20], xmm9
00007583d7bd9aa6  vmovaps xmm8, [rsp+0x20]
00007583d7bd9aac  por xmm9, xmm8
00007583d7bd9ab1  movaps xmm8, [r15+0x2B0]
00007583d7bd9ab9  vmovaps [rsp+0x20], xmm8
00007583d7bd9abf  vmovaps xmm7, [rsp+0x20]
00007583d7bd9ac5  por xmm8, xmm7
00007583d7bd9aca  movaps xmm7, [r15+0x180]
00007583d7bd9ad2  vmovaps [rsp+0x20], xmm7
00007583d7bd9ad8  vmovaps xmm6, [rsp+0x20]
00007583d7bd9ade  por xmm7, xmm6
00007583d7bd9ae2  lea r14, [rax+0x10]
00007583d7bd9ae6  mov r12, [r13+r14*1]
00007583d7bd9aeb  lea r14, [rax+0x18]
00007583d7bd9aef  mov r11, [r13+r14*1]
00007583d7bd9af4  movq xmm6, r12
00007583d7bd9af9  movq xmm5, r11
00007583d7bd9afe  movq xmm6, xmm6
00007583d7bd9b02  movq xmm5, xmm5
00007583d7bd9b06  movaps xmm4, [r15+0x200]
00007583d7bd9b0e  vmovaps [rsp+0x20], xmm4
00007583d7bd9b14  vmovaps xmm3, [rsp+0x20]
00007583d7bd9b1a  por xmm4, xmm3
00007583d7bd9b1e  movaps xmm3, [r15+0x1F0]
00007583d7bd9b26  vmovaps [rsp+0x20], xmm3
00007583d7bd9b2c  vmovaps xmm2, [rsp+0x20]
00007583d7bd9b32  por xmm3, xmm2
00007583d7bd9b36  movaps xmm2, [r15+0x2E0]
00007583d7bd9b3e  vmovaps [rsp+0x20], xmm2
00007583d7bd9b44  vmovaps [rsp+0x30], xmm1
00007583d7bd9b4a  vmovaps xmm1, [rsp+0x20]
00007583d7bd9b50  por xmm2, xmm1
00007583d7bd9b54  movaps xmm1, [r15+0x2A0]
00007583d7bd9b5c  vmovaps [rsp+0x20], xmm1
00007583d7bd9b62  vmovaps [rsp+0x40], xmm15
00007583d7bd9b68  vmovaps xmm15, [rsp+0x20]
00007583d7bd9b6e  por xmm1, xmm15
00007583d7bd9b73  movaps xmm15, [r15+0x280]
00007583d7bd9b7b  vmovaps [rsp+0x20], xmm15
00007583d7bd9b81  vmovaps [rsp+0x50], xmm1
00007583d7bd9b87  vmovaps xmm1, [rsp+0x20]
00007583d7bd9b8d  por xmm15, xmm1
00007583d7bd9b92  movaps xmm1, [r15+0x1C0]
00007583d7bd9b9a  vmovaps [rsp+0x20], xmm1
00007583d7bd9ba0  vmovaps [rsp+0x60], xmm15
00007583d7bd9ba6  vmovaps xmm15, [rsp+0x20]
00007583d7bd9bac  por xmm1, xmm15
00007583d7bd9bb1  movaps xmm15, [r15+0x210]
00007583d7bd9bb9  vmovaps [rsp+0x20], xmm15
00007583d7bd9bbf  vmovaps [rsp+0x70], xmm1
00007583d7bd9bc5  vmovaps xmm1, [rsp+0x20]
00007583d7bd9bcb  por xmm15, xmm1
00007583d7bd9bd0  mov r14, [r13+rax*1]
00007583d7bd9bd5  vmovq xmm1, r14
00007583d7bd9bda  vpbroadcastq xmm1, xmm1
00007583d7bd9bdf  vmovaps [rsp+0x20], xmm1
00007583d7bd9be5  vxorps xmm1, xmm1, xmm1
00007583d7bd9be9  vpbroadcastq xmm1, xmm1
00007583d7bd9bee  mov r14, [r15+0xF8]
00007583d7bd9bf5  vmovaps [rsp+0x80], xmm1
00007583d7bd9bfe  movups xmm1, [r13+r14*1]
00007583d7bd9c04  vmovaps [rsp+0x90], xmm1
00007583d7bd9c0d  vxorps xmm1, xmm1, xmm1
00007583d7bd9c11  vpbroadcastq xmm1, xmm1
00007583d7bd9c16  lea r12, [rax+0x08]
00007583d7bd9c1a  mov rax, [r13+r12*1]
00007583d7bd9c1f  vmovaps [rsp+0xA0], xmm1
00007583d7bd9c28  movq xmm1, rax
00007583d7bd9c2d  movaps [r15+0x240], xmm1
00007583d7bd9c35  mov rax, [r15+0x50]
00007583d7bd9c39  mov [r15+0x60], rax
00007583d7bd9c3d  mov qword ptr [r15+0x58], 0x40
00007583d7bd9c45  vmovaps xmm1, [rsp+0x30]
00007583d7bd9c4b  vmovaps [rsp+0x30], xmm15
00007583d7bd9c51  vmovaps xmm15, [rsp+0x90]
00007583d7bd9c5a  vmovaps [rsp+0x90], xmm14
00007583d7bd9c63  vmovaps xmm14, [rsp+0x20]
00007583d7bd9c69  vmovaps [rsp+0x20], xmm13
00007583d7bd9c6f  vmovaps [rsp+0xB0], xmm12
00007583d7bd9c78  movaps xmm13, xmm1
00007583d7bd9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd9c87  vptest xmm12, xmm12
00007583d7bd9c8c  jnz 0x00007583D7BDA72F
00007583d7bd9c92  movaps xmm1, [r15+0x250]
00007583d7bd9c9a  vmovaps xmm15, [rsp+0x40]
00007583d7bd9ca0  vmovaps [rsp+0x40], xmm13
00007583d7bd9ca6  movaps xmm12, xmm15
00007583d7bd9caa  vfmadd231pd xmm12, xmm1, xmm14
00007583d7bd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007583d7bd9cb5  vptest xmm13, xmm13
00007583d7bd9cba  jnz 0x00007583D7BDA888
00007583d7bd9cc0  movaps xmm15, [r15+0x1E0]
00007583d7bd9cc8  vmovaps [rsp+0xC0], xmm15
00007583d7bd9cd1  vmovaps xmm13, [rsp+0xC0]
00007583d7bd9cda  por xmm15, xmm13
00007583d7bd9cdf  movaps xmm13, [r15+0x1D0]
00007583d7bd9ce7  vmovaps [rsp+0xC0], xmm13
00007583d7bd9cf0  vmovaps [rsp+0xD0], xmm1
00007583d7bd9cf9  vmovaps xmm1, [rsp+0xC0]
00007583d7bd9d02  por xmm13, xmm1
00007583d7bd9d07  movaps xmm1, [r15+0x2C0]
00007583d7bd9d0f  vmovaps [rsp+0xC0], xmm1
00007583d7bd9d18  vmovaps [rsp+0xE0], xmm15
00007583d7bd9d21  vmovaps xmm15, [rsp+0xC0]
00007583d7bd9d2a  por xmm1, xmm15
00007583d7bd9d2f  movaps xmm15, [r15+0x290]
00007583d7bd9d37  vmovaps [rsp+0xC0], xmm15
00007583d7bd9d40  vmovaps [rsp+0xF0], xmm1
00007583d7bd9d49  vmovaps xmm1, [rsp+0xC0]
00007583d7bd9d52  por xmm15, xmm1
00007583d7bd9d57  movaps xmm1, [r15+0x260]
00007583d7bd9d5f  vmovaps [rsp+0xC0], xmm1
00007583d7bd9d68  vmovaps [rsp+0x100], xmm15
00007583d7bd9d71  vmovaps xmm15, [rsp+0xC0]
00007583d7bd9d7a  por xmm1, xmm15
00007583d7bd9d7f  vmovaps xmm15, [rsp+0xD0]
00007583d7bd9d88  vmovaps [rsp+0xC0], xmm1
00007583d7bd9d91  vmovaps xmm1, [rsp+0xD0]
00007583d7bd9d9a  por xmm15, xmm1
00007583d7bd9d9f  lea r12, [r14+0xC0]
00007583d7bd9da6  movups xmm1, [r13+r12*1]
00007583d7bd9dac  mov [rsp+0xD0], rax
00007583d7bd9db4  xor eax, eax
00007583d7bd9db6  mov r12d, 0x40
00007583d7bd9dbc  mov r11d, 0x200
00007583d7bd9dc2  cmp r12, r11
00007583d7bd9dc5  cmc
00007583d7bd9dc6  lahf
00007583d7bd9dc7  seto al
00007583d7bd9dca  mov [r15+0x108], eax
00007583d7bd9dd1  vmovaps [rsp+0x110], xmm1
00007583d7bd9dda  vmovaps xmm1, [rsp+0x80]
00007583d7bd9de3  vmovaps [rsp+0x80], xmm15
00007583d7bd9dec  vmovaps xmm15, [rsp+0x110]
00007583d7bd9df5  vmovaps [rsp+0x110], xmm13
00007583d7bd9dfe  vmovaps [rsp+0x120], xmm12
00007583d7bd9e07  movaps xmm13, xmm1
00007583d7bd9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd9e16  vptest xmm12, xmm12
00007583d7bd9e1b  jnz 0x00007583D7BDA9EB
00007583d7bd9e21  lea rax, [r14+0xB0]
00007583d7bd9e28  movups xmm1, [r13+rax*1]
00007583d7bd9e2e  vmovaps xmm15, [rsp+0xA0]
00007583d7bd9e37  vmovaps [rsp+0xA0], xmm13
00007583d7bd9e40  movaps xmm12, xmm15
00007583d7bd9e44  vfmadd231pd xmm12, xmm1, xmm14
00007583d7bd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007583d7bd9e4f  vptest xmm13, xmm13
00007583d7bd9e54  jnz 0x00007583D7BDAB4E
00007583d7bd9e5a  vmovaps xmm1, [rsp+0x30]
00007583d7bd9e60  vmovaps xmm15, [rsp+0x30]
00007583d7bd9e66  por xmm1, xmm15
00007583d7bd9e6b  movaps [r15+0x210], xmm1
00007583d7bd9e73  vmovaps xmm15, [rsp+0x70]
00007583d7bd9e79  vmovaps xmm14, [rsp+0x70]
00007583d7bd9e7f  por xmm15, xmm14
00007583d7bd9e84  movaps [r15+0x1C0], xmm15
00007583d7bd9e8c  vmovaps xmm14, [rsp+0x60]
00007583d7bd9e92  vmovaps xmm13, [rsp+0x60]
00007583d7bd9e98  por xmm14, xmm13
00007583d7bd9e9d  movaps [r15+0x280], xmm14
00007583d7bd9ea5  vmovaps xmm13, [rsp+0x50]
00007583d7bd9eab  vmovaps [rsp+0x30], xmm1
00007583d7bd9eb1  vmovaps xmm1, [rsp+0x50]
00007583d7bd9eb7  por xmm13, xmm1
00007583d7bd9ebc  movaps [r15+0x2A0], xmm13
00007583d7bd9ec4  vmovaps [rsp+0x50], xmm2
00007583d7bd9eca  vmovaps xmm1, [rsp+0x50]
00007583d7bd9ed0  por xmm2, xmm1
00007583d7bd9ed4  movaps [r15+0x2E0], xmm2
00007583d7bd9edc  vmovaps [rsp+0x50], xmm3
00007583d7bd9ee2  vmovaps xmm1, [rsp+0x50]
00007583d7bd9ee8  por xmm3, xmm1
00007583d7bd9eec  movaps [r15+0x1F0], xmm3
00007583d7bd9ef4  vmovaps xmm1, [rsp+0x80]
00007583d7bd9efd  vmovaps [rsp+0x50], xmm15
00007583d7bd9f03  vmovaps xmm15, [rsp+0x80]
00007583d7bd9f0c  por xmm1, xmm15
00007583d7bd9f11  movaps [r15+0x250], xmm1
00007583d7bd9f19  vmovaps xmm1, [rsp+0xC0]
00007583d7bd9f22  vmovaps xmm15, [rsp+0xC0]
00007583d7bd9f2b  por xmm1, xmm15
00007583d7bd9f30  movaps [r15+0x260], xmm1
00007583d7bd9f38  vmovaps xmm15, [rsp+0x100]
00007583d7bd9f41  vmovaps [rsp+0x60], xmm1
00007583d7bd9f47  vmovaps xmm1, [rsp+0x100]
00007583d7bd9f50  por xmm15, xmm1
00007583d7bd9f55  movaps [r15+0x290], xmm15
00007583d7bd9f5d  vmovaps xmm1, [rsp+0xF0]
00007583d7bd9f66  vmovaps [rsp+0x70], xmm15
00007583d7bd9f6c  vmovaps xmm15, [rsp+0xF0]
00007583d7bd9f75  por xmm1, xmm15
00007583d7bd9f7a  movaps [r15+0x2C0], xmm1
00007583d7bd9f82  movq xmm15, qword ptr [r15+0x240]
00007583d7bd9f8b  vmovaps [rsp+0x80], xmm15
00007583d7bd9f94  vpermilpd xmm15, xmm15, 0x00
00007583d7bd9f9a  vmovaps [rsp+0xC0], xmm1
00007583d7bd9fa3  vmovaps xmm1, [rsp+0x40]
00007583d7bd9fa9  vmovaps [rsp+0x40], xmm15
00007583d7bd9faf  vmovaps xmm15, [rsp+0x30]
00007583d7bd9fb5  vmovaps [rsp+0x30], xmm14
00007583d7bd9fbb  vmovaps xmm14, [rsp+0x40]
00007583d7bd9fc1  vmovaps [rsp+0x40], xmm13
00007583d7bd9fc7  vmovaps [rsp+0xF0], xmm12
00007583d7bd9fd0  movaps xmm13, xmm1
00007583d7bd9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007583d7bd9fdf  vptest xmm12, xmm12
00007583d7bd9fe4  jnz 0x00007583D7BDACA7
00007583d7bd9fea  vmovaps xmm1, [rsp+0x80]
00007583d7bd9ff3  vpermilpd xmm1, xmm1, 0x00
00007583d7bd9ff9  vmovaps xmm15, [rsp+0xA0]
00007583d7bda002  movaps xmm14, xmm15
00007583d7bda006  vfmadd231pd xmm14, xmm2, xmm1
00007583d7bda00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007583d7bda011  vptest xmm12, xmm12
00007583d7bda016  jnz 0x00007583D7BDAE00
00007583d7bda01c  vmovaps xmm1, [rsp+0x80]
00007583d7bda025  vpermilpd xmm1, xmm1, 0x00
00007583d7bda02b  vmovaps xmm15, [rsp+0x120]
00007583d7bda034  vmovaps xmm12, [rsp+0x50]
00007583d7bda03a  vmovaps [rsp+0x50], xmm14
00007583d7bda040  movaps xmm2, xmm15
00007583d7bda044  vfmadd231pd xmm2, xmm12, xmm1
00007583d7bda049  vcmppd xmm14, xmm2, xmm2, 0x03
00007583d7bda04e  vptest xmm14, xmm14
00007583d7bda053  jnz 0x00007583D7BDAF58
00007583d7bda059  vmovaps xmm1, [rsp+0x110]
00007583d7bda062  vmovaps xmm15, [rsp+0x110]
00007583d7bda06b  por xmm1, xmm15
00007583d7bda070  movaps [r15+0x1D0], xmm1
00007583d7bda078  vmovaps xmm15, [rsp+0x80]
00007583d7bda081  vpermilpd xmm15, xmm15, 0x00
00007583d7bda087  vmovaps xmm14, [rsp+0xF0]
00007583d7bda090  vmovaps [rsp+0x80], xmm1
00007583d7bda099  movaps xmm12, xmm14
00007583d7bda09d  vfmadd231pd xmm12, xmm3, xmm15
00007583d7bda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007583d7bda0a8  vptest xmm1, xmm1
00007583d7bda0ad  jnz 0x00007583D7BDB0AF
00007583d7bda0b3  vmovaps [rsp+0xA0], xmm4
00007583d7bda0bc  vmovaps xmm1, [rsp+0xA0]
00007583d7bda0c5  por xmm4, xmm1
00007583d7bda0c9  movaps [r15+0x200], xmm4
00007583d7bda0d1  vmovaps xmm1, [rsp+0xE0]
00007583d7bda0da  vmovaps xmm15, [rsp+0xE0]
00007583d7bda0e3  por xmm1, xmm15
00007583d7bda0e8  movaps [r15+0x1E0], xmm1
00007583d7bda0f0  vmovaps [rsp+0xA0], xmm8
00007583d7bda0f9  vmovaps xmm1, [rsp+0xA0]
00007583d7bda102  por xmm8, xmm1
00007583d7bda107  movaps [r15+0x2B0], xmm8
00007583d7bda10f  vmovaps [rsp+0xA0], xmm9
00007583d7bda118  vmovaps xmm1, [rsp+0xA0]
00007583d7bda121  por xmm9, xmm1
00007583d7bda126  movaps [r15+0x300], xmm9
00007583d7bda12e  vmovaps [rsp+0xA0], xmm6
00007583d7bda137  vpermilpd xmm6, xmm6, 0x00
00007583d7bda13d  vmovaps xmm14, [rsp+0x60]
00007583d7bda143  movaps xmm9, xmm13
00007583d7bda147  vfmadd231pd xmm9, xmm14, xmm6
00007583d7bda14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007583d7bda152  vptest xmm3, xmm3
00007583d7bda157  jnz 0x00007583D7BDB208
00007583d7bda15d  vmovaps xmm14, [rsp+0xA0]
00007583d7bda166  vpermilpd xmm14, xmm14, 0x00
00007583d7bda16c  vmovaps xmm13, [rsp+0x50]
00007583d7bda172  vmovaps xmm6, [rsp+0xC0]
00007583d7bda17b  vmovaps [rsp+0x50], xmm1
00007583d7bda181  movaps xmm3, xmm13
00007583d7bda185  vfmadd231pd xmm3, xmm6, xmm14
00007583d7bda18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007583d7bda18f  vptest xmm1, xmm1
00007583d7bda194  jnz 0x00007583D7BDB361
00007583d7bda19a  vmovaps xmm1, [rsp+0xA0]
00007583d7bda1a3  vpermilpd xmm1, xmm1, 0x00
00007583d7bda1a9  vmovaps xmm14, [rsp+0x30]
00007583d7bda1af  movaps xmm6, xmm2
00007583d7bda1b2  vfmadd231pd xmm6, xmm14, xmm1
00007583d7bda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007583d7bda1bc  vptest xmm13, xmm13
00007583d7bda1c1  jnz 0x00007583D7BDB4B8
00007583d7bda1c7  vmovaps xmm1, [rsp+0xA0]
00007583d7bda1d0  vpermilpd xmm1, xmm1, 0x00
00007583d7bda1d6  vmovaps xmm14, [rsp+0x80]
00007583d7bda1df  movaps xmm13, xmm12
00007583d7bda1e3  vfmadd231pd xmm13, xmm14, xmm1
00007583d7bda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007583d7bda1ee  vptest xmm2, xmm2
00007583d7bda1f3  jnz 0x00007583D7BDB60E
00007583d7bda1f9  vmovaps [rsp+0x30], xmm7
00007583d7bda1ff  vmovaps xmm1, [rsp+0x30]
00007583d7bda205  por xmm7, xmm1
00007583d7bda209  movaps [r15+0x180], xmm7
00007583d7bda211  vmovaps [rsp+0x30], xmm10
00007583d7bda217  vmovaps xmm1, [rsp+0x30]
00007583d7bda21d  por xmm10, xmm1
00007583d7bda222  movaps [r15+0x2D0], xmm10
00007583d7bda22a  vmovaps [rsp+0x30], xmm5
00007583d7bda230  vpermilpd xmm5, xmm5, 0x00
00007583d7bda236  vmovaps xmm14, [rsp+0x50]
00007583d7bda23c  movaps xmm12, xmm3
00007583d7bda240  vfmadd231pd xmm12, xmm14, xmm5
00007583d7bda245  vcmppd xmm10, xmm12, xmm12, 0x03
00007583d7bda24b  vptest xmm10, xmm10
00007583d7bda250  jnz 0x00007583D7BDB767
00007583d7bda256  vmovaps xmm14, [rsp+0x30]
00007583d7bda25c  vpermilpd xmm14, xmm14, 0x00
00007583d7bda262  movaps xmm10, xmm9
00007583d7bda266  vfmadd231pd xmm10, xmm7, xmm14
00007583d7bda26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007583d7bda271  vptest xmm5, xmm5
00007583d7bda276  jnz 0x00007583D7BDB8BF
00007583d7bda27c  lea rax, [r14+0x80]
00007583d7bda283  movups xmm14, [r13+rax*1]
00007583d7bda289  movaps [r15+0x2F0], xmm14
00007583d7bda291  vmovaps xmm9, [rsp+0x30]
00007583d7bda297  vpermilpd xmm9, xmm9, 0x00
00007583d7bda29d  vmovaps xmm7, [rsp+0x70]
00007583d7bda2a3  movaps xmm5, xmm6
00007583d7bda2a6  vfmadd231pd xmm5, xmm7, xmm9
00007583d7bda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007583d7bda2b0  vptest xmm3, xmm3
00007583d7bda2b5  jnz 0x00007583D7BDBA22
00007583d7bda2bb  vmovaps xmm9, [rsp+0x30]
00007583d7bda2c1  vpermilpd xmm9, xmm9, 0x00
00007583d7bda2c7  movaps xmm7, xmm13
00007583d7bda2cb  vfmadd231pd xmm7, xmm1, xmm9
00007583d7bda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007583d7bda2d5  vptest xmm6, xmm6
00007583d7bda2da  jnz 0x00007583D7BDBB78
00007583d7bda2e0  vmovaps xmm1, [rsp+0x20]
00007583d7bda2e6  vmovaps xmm13, [rsp+0x20]
00007583d7bda2ec  por xmm1, xmm13
00007583d7bda2f1  movaps [r15+0x160], xmm1
00007583d7bda2f9  lea rax, [r14+0x40]
00007583d7bda2fd  movups xmm13, [r13+rax*1]
00007583d7bda303  lea rax, [r14+0x50]
00007583d7bda307  movups xmm9, [r13+rax*1]
00007583d7bda30d  movaps [r15+0x1B0], xmm13
00007583d7bda315  movaps [r15+0x1A0], xmm9
00007583d7bda31d  movaps xmm6, [r15+0x190]
00007583d7bda325  vmovaps xmm3, [rsp+0xB0]
00007583d7bda32e  vpermilpd xmm3, xmm3, 0x00
00007583d7bda334  vmovaps [rsp+0x20], xmm1
00007583d7bda33a  movaps xmm2, xmm12
00007583d7bda33e  vfmadd231pd xmm2, xmm6, xmm3
00007583d7bda343  vcmppd xmm1, xmm2, xmm2, 0x03
00007583d7bda348  vptest xmm1, xmm1
00007583d7bda34d  jnz 0x00007583D7BDBCE3
00007583d7bda353  vmovaps xmm1, [rsp+0xB0]
00007583d7bda35c  vpermilpd xmm1, xmm1, 0x00
00007583d7bda362  vmovaps xmm12, [rsp+0x20]
00007583d7bda368  movaps xmm6, xmm10
00007583d7bda36c  vfmadd231pd xmm6, xmm12, xmm1
00007583d7bda371  vcmppd xmm3, xmm6, xmm6, 0x03
00007583d7bda376  vptest xmm3, xmm3
00007583d7bda37b  jnz 0x00007583D7BDBE39
00007583d7bda381  vmovaps xmm1, [rsp+0xB0]
00007583d7bda38a  vpermilpd xmm1, xmm1, 0x00
00007583d7bda390  vmovaps xmm12, [rsp+0x40]
00007583d7bda396  movaps xmm10, xmm5
00007583d7bda39a  vfmadd231pd xmm10, xmm12, xmm1
00007583d7bda39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007583d7bda3a5  vptest xmm3, xmm3
00007583d7bda3aa  jnz 0x00007583D7BDBF90
00007583d7bda3b0  vmovaps xmm1, [rsp+0xB0]
00007583d7bda3b9  vpermilpd xmm1, xmm1, 0x00
00007583d7bda3bf  movaps xmm12, xmm7
00007583d7bda3c3  vfmadd231pd xmm12, xmm15, xmm1
00007583d7bda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007583d7bda3ce  vptest xmm5, xmm5
00007583d7bda3d3  jnz 0x00007583D7BDC0E8
00007583d7bda3d9  lea rax, [r14+0x60]
00007583d7bda3dd  movups xmm1, [r13+rax*1]
00007583d7bda3e3  lea rax, [r14+0x70]
00007583d7bda3e7  movups xmm15, [r13+rax*1]
00007583d7bda3ed  movaps [r15+0x150], xmm1
00007583d7bda3f5  movaps [r15+0x120], xmm15
00007583d7bda3fd  vmovaps [rsp+0x20], xmm11
00007583d7bda403  vpermilpd xmm11, xmm11, 0x00
00007583d7bda409  movaps xmm7, xmm2
00007583d7bda40c  vfmadd231pd xmm7, xmm9, xmm11
00007583d7bda411  vcmppd xmm5, xmm7, xmm7, 0x03
00007583d7bda416  vptest xmm5, xmm5
00007583d7bda41b  jnz 0x00007583D7BDC254
00007583d7bda421  vmovaps xmm11, [rsp+0x20]
00007583d7bda427  vpermilpd xmm11, xmm11, 0x00
00007583d7bda42d  movaps xmm9, xmm6
00007583d7bda431  vfmadd231pd xmm9, xmm1, xmm11
00007583d7bda436  vcmppd xmm5, xmm9, xmm9, 0x03
00007583d7bda43c  vptest xmm5, xmm5
00007583d7bda441  jnz 0x00007583D7BDC3AB
00007583d7bda447  vmovaps xmm1, [rsp+0x20]
00007583d7bda44d  vpermilpd xmm1, xmm1, 0x00
00007583d7bda453  movaps xmm11, xmm10
00007583d7bda457  vfmadd231pd xmm11, xmm8, xmm1
00007583d7bda45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007583d7bda462  vptest xmm6, xmm6
00007583d7bda467  jnz 0x00007583D7BDC503
00007583d7bda46d  vmovaps xmm1, [rsp+0x20]
00007583d7bda473  vpermilpd xmm1, xmm1, 0x00
00007583d7bda479  movaps xmm10, xmm12
00007583d7bda47d  vfmadd231pd xmm10, xmm13, xmm1
00007583d7bda482  vcmppd xmm8, xmm10, xmm10, 0x03
00007583d7bda488  vptest xmm8, xmm8
00007583d7bda48d  jnz 0x00007583D7BDC65C
00007583d7bda493  lea rax, [r14+0x20]
00007583d7bda497  movups xmm1, [r13+rax*1]
00007583d7bda49d  lea rax, [r14+0x30]
00007583d7bda4a1  movups xmm13, [r13+rax*1]
00007583d7bda4a7  vmovaps xmm12, [rsp+0x90]
00007583d7bda4b0  vpermilpd xmm12, xmm12, 0x00
00007583d7bda4b6  movaps xmm8, xmm7
00007583d7bda4ba  vfmadd231pd xmm8, xmm4, xmm12
00007583d7bda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007583d7bda4c5  vptest xmm6, xmm6
00007583d7bda4ca  jnz 0x00007583D7BDC7C9
00007583d7bda4d0  vmovaps xmm12, [rsp+0x90]
00007583d7bda4d9  vpermilpd xmm12, xmm12, 0x00
00007583d7bda4df  movaps xmm7, xmm9
00007583d7bda4e3  vfmadd231pd xmm7, xmm14, xmm12
00007583d7bda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007583d7bda4ed  vptest xmm6, xmm6
00007583d7bda4f2  jnz 0x00007583D7BDC921
00007583d7bda4f8  vmovaps xmm14, [rsp+0x90]
00007583d7bda501  vpermilpd xmm14, xmm14, 0x00
00007583d7bda507  movaps xmm12, xmm11
00007583d7bda50b  vfmadd231pd xmm12, xmm15, xmm14
00007583d7bda510  vcmppd xmm9, xmm12, xmm12, 0x03
00007583d7bda516  vptest xmm9, xmm9
00007583d7bda51b  jnz 0x00007583D7BDCA79
00007583d7bda521  vmovaps xmm15, [rsp+0x90]
00007583d7bda52a  vpermilpd xmm15, xmm15, 0x00
00007583d7bda530  movaps xmm11, xmm10
00007583d7bda534  vfmadd231pd xmm11, xmm13, xmm15
00007583d7bda539  vcmppd xmm14, xmm11, xmm11, 0x03
00007583d7bda53f  vptest xmm14, xmm14
00007583d7bda544  jnz 0x00007583D7BDCBD3
00007583d7bda54a  lea rax, [r14+0x90]
00007583d7bda551  movups xmm15, [r13+rax*1]
00007583d7bda557  lea rax, [r14+0xA0]
00007583d7bda55e  movups xmm14, [r13+rax*1]
00007583d7bda564  movaps [r15+0x140], xmm15
00007583d7bda56c  movaps [r15+0x130], xmm14
00007583d7bda574  vmovaps xmm13, [rsp+0x10]
00007583d7bda57a  vpermilpd xmm13, xmm13, 0x00
00007583d7bda580  movaps xmm10, xmm8
00007583d7bda584  vfmadd231pd xmm10, xmm1, xmm13
00007583d7bda589  vcmppd xmm9, xmm10, xmm10, 0x03
00007583d7bda58f  vptest xmm9, xmm9
00007583d7bda594  jnz 0x00007583D7BDCD41
00007583d7bda59a  movaps [r15+0x220], xmm10
00007583d7bda5a2  lea rax, [r14+0x10]
00007583d7bda5a6  movups xmm1, [r13+rax*1]
00007583d7bda5ac  movaps [r15+0x240], xmm1
00007583d7bda5b4  vmovaps xmm13, [rsp+0x10]
00007583d7bda5ba  vpermilpd xmm13, xmm13, 0x00
00007583d7bda5c0  movaps xmm9, xmm7
00007583d7bda5c4  vfmadd231pd xmm9, xmm14, xmm13
00007583d7bda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007583d7bda5cf  vptest xmm8, xmm8
00007583d7bda5d4  jnz 0x00007583D7BDCEA4
00007583d7bda5da  movaps [r15+0x110], xmm9
00007583d7bda5e2  vmovaps xmm14, [rsp+0x10]
00007583d7bda5e8  vpermilpd xmm14, xmm14, 0x00
00007583d7bda5ee  movaps xmm13, xmm12
00007583d7bda5f2  vfmadd231pd xmm13, xmm15, xmm14
00007583d7bda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007583d7bda5fd  vptest xmm8, xmm8
00007583d7bda602  jnz 0x00007583D7BDCFFD
00007583d7bda608  movaps [r15+0x170], xmm13
00007583d7bda610  vmovaps xmm15, [rsp+0x10]
00007583d7bda616  vpermilpd xmm15, xmm15, 0x00
00007583d7bda61c  movaps xmm14, xmm11
00007583d7bda620  vfmadd231pd xmm14, xmm1, xmm15
00007583d7bda625  vcmppd xmm12, xmm14, xmm14, 0x03
00007583d7bda62b  vptest xmm12, xmm12
00007583d7bda630  jnz 0x00007583D7BDD157
00007583d7bda636  movaps [r15+0x230], xmm14
00007583d7bda63e  mov rax, [rsp+0xD0]
00007583d7bda646  movups [r13+rax*1], xmm9
00007583d7bda64c  lea r14, [rax+0x10]
00007583d7bda650  movups [r13+r14*1], xmm13
00007583d7bda656  lea r14, [rax+0x20]
00007583d7bda65a  movups [r13+r14*1], xmm10
00007583d7bda660  lea r14, [rax+0x30]
00007583d7bda664  movups [r13+r14*1], xmm14
00007583d7bda66a  mov eax, [r15+0x108]
00007583d7bda671  sahf
00007583d7bda672  jnz 0x00007583D7BDA6A4
00007583d7bda674  cmp dword ptr [r15+0x318], 0x00
00007583d7bda67c  jz 0x00007583D7BD9950
00007583d7bda682  nop [rax+rax*1], ax
00007583d7bda68b  nop [rax+rax*1], eax
00007583d7bda693  mov eax, 0x410664
00007583d7bda698  mov [r15+0x100], rax
00007583d7bda69f  jmp 0x00007583D79FE110
00007583d7bda6a4  cmp dword ptr [r15+0x318], 0x00
00007583d7bda6ac  jz 0x00007583D7BD6050
00007583d7bda6b2  nop [rax+rax*1], ax
00007583d7bda6bb  nop [rax+rax*1], eax
00007583d7bda6c3  mov eax, 0x4104F0
00007583d7bda6c8  mov [r15+0x100], rax
00007583d7bda6cf  jmp 0x00007583D79FE110
00007583d7bda6d4  int3
00007583d7bda6d5  call 0x00007583D7AE27E0
00007583d7bda6da  jmp 0x00007583D7BD9A10
00007583d7bda6df  call 0x00007583D7AE1570
00007583d7bda6e4  jmp 0x00007583D7BD9A19
00007583d7bda6e9  call 0x00007583D7AE27E0
00007583d7bda6ee  jmp 0x00007583D7BD9A62
00007583d7bda6f3  call 0x00007583D7AE1570
00007583d7bda6f8  jmp 0x00007583D7BD9A6B
00007583d7bda6fd  call 0x00007583D7AE27E0
00007583d7bda702  jmp 0x00007583D7BD9AEB
00007583d7bda707  call 0x00007583D7AE1570
00007583d7bda70c  jmp 0x00007583D7BD9AF4
00007583d7bda711  call 0x00007583D7A0DC20
00007583d7bda716  jmp 0x00007583D7BD9BD5
00007583d7bda71b  call 0x00007583D7AD64F0
00007583d7bda720  jmp 0x00007583D7BD9C04
00007583d7bda725  call 0x00007583D7AB47C0
00007583d7bda72a  jmp 0x00007583D7BD9C1F
00007583d7bda72f  sub rsp, 0x08
00007583d7bda733  push rax
00007583d7bda734  push rcx
00007583d7bda735  push rdx
00007583d7bda736  push rdi
00007583d7bda737  push rsi
00007583d7bda738  push r8
00007583d7bda73a  push r9
00007583d7bda73c  push r10
00007583d7bda73e  push r11
00007583d7bda740  sub rsp, 0xF0
00007583d7bda747  vmovaps [rsp], xmm0
00007583d7bda74c  vmovaps [rsp+0x10], xmm1
00007583d7bda752  vmovaps [rsp+0x20], xmm2
00007583d7bda758  vmovaps [rsp+0x30], xmm3
00007583d7bda75e  vmovaps [rsp+0x40], xmm4
00007583d7bda764  vmovaps [rsp+0x50], xmm5
00007583d7bda76a  vmovaps [rsp+0x60], xmm6
00007583d7bda770  vmovaps [rsp+0x70], xmm7
00007583d7bda776  vmovaps [rsp+0x80], xmm8
00007583d7bda77f  vmovaps [rsp+0x90], xmm9
00007583d7bda788  vmovaps [rsp+0xA0], xmm10
00007583d7bda791  vmovaps [rsp+0xB0], xmm11
00007583d7bda79a  vmovaps [rsp+0xC0], xmm12
00007583d7bda7a3  vmovaps [rsp+0xD0], xmm14
00007583d7bda7ac  vmovaps [rsp+0xE0], xmm15
00007583d7bda7b5  sub rsp, 0x40
00007583d7bda7b9  lea rdi, [rsp]
00007583d7bda7bd  lea rsi, [rsp+0x10]
00007583d7bda7c2  lea rdx, [rsp+0x20]
00007583d7bda7c7  lea rcx, [rsp+0x30]
00007583d7bda7cc  mov r8d, 0x00
00007583d7bda7d2  lea r9, [r15+0x3A8]
00007583d7bda7d9  movaps [rdi], xmm13
00007583d7bda7dd  movaps [rsi], xmm1
00007583d7bda7e0  movaps [rdx], xmm15
00007583d7bda7e4  movaps [rcx], xmm14
00007583d7bda7e8  mov rax, 0x5BCB7EA35A50
00007583d7bda7f2  call rax
00007583d7bda7f4  movaps xmm13, [rsp]
00007583d7bda7f9  add rsp, 0x40
00007583d7bda7fd  vmovaps xmm0, [rsp]
00007583d7bda802  vmovaps xmm1, [rsp+0x10]
00007583d7bda808  vmovaps xmm2, [rsp+0x20]
00007583d7bda80e  vmovaps xmm3, [rsp+0x30]
00007583d7bda814  vmovaps xmm4, [rsp+0x40]
00007583d7bda81a  vmovaps xmm5, [rsp+0x50]
00007583d7bda820  vmovaps xmm6, [rsp+0x60]
00007583d7bda826  vmovaps xmm7, [rsp+0x70]
00007583d7bda82c  vmovaps xmm8, [rsp+0x80]
00007583d7bda835  vmovaps xmm9, [rsp+0x90]
00007583d7bda83e  vmovaps xmm10, [rsp+0xA0]
00007583d7bda847  vmovaps xmm11, [rsp+0xB0]
00007583d7bda850  vmovaps xmm12, [rsp+0xC0]
00007583d7bda859  vmovaps xmm14, [rsp+0xD0]
00007583d7bda862  vmovaps xmm15, [rsp+0xE0]
00007583d7bda86b  add rsp, 0xF0
00007583d7bda872  pop r11
00007583d7bda874  pop r10
00007583d7bda876  pop r9
00007583d7bda878  pop r8
00007583d7bda87a  pop rsi
00007583d7bda87b  pop rdi
00007583d7bda87c  pop rdx
00007583d7bda87d  pop rcx
00007583d7bda87e  pop rax
00007583d7bda87f  add rsp, 0x08
00007583d7bda883  jmp 0x00007583D7BD9C92
00007583d7bda888  sub rsp, 0x08
00007583d7bda88c  push rax
00007583d7bda88d  push rcx
00007583d7bda88e  push rdx
00007583d7bda88f  push rdi
00007583d7bda890  push rsi
00007583d7bda891  push r8
00007583d7bda893  push r9
00007583d7bda895  push r10
00007583d7bda897  push r11
00007583d7bda899  sub rsp, 0xF0
00007583d7bda8a0  vmovaps [rsp], xmm0
00007583d7bda8a5  vmovaps [rsp+0x10], xmm1
00007583d7bda8ab  vmovaps [rsp+0x20], xmm2
00007583d7bda8b1  vmovaps [rsp+0x30], xmm3
00007583d7bda8b7  vmovaps [rsp+0x40], xmm4
00007583d7bda8bd  vmovaps [rsp+0x50], xmm5
00007583d7bda8c3  vmovaps [rsp+0x60], xmm6
00007583d7bda8c9  vmovaps [rsp+0x70], xmm7
00007583d7bda8cf  vmovaps [rsp+0x80], xmm8
00007583d7bda8d8  vmovaps [rsp+0x90], xmm9
00007583d7bda8e1  vmovaps [rsp+0xA0], xmm10
00007583d7bda8ea  vmovaps [rsp+0xB0], xmm11
00007583d7bda8f3  vmovaps [rsp+0xC0], xmm13
00007583d7bda8fc  vmovaps [rsp+0xD0], xmm14
00007583d7bda905  vmovaps [rsp+0xE0], xmm15
00007583d7bda90e  sub rsp, 0x40
00007583d7bda912  lea rdi, [rsp]
00007583d7bda916  lea rsi, [rsp+0x10]
00007583d7bda91b  lea rdx, [rsp+0x20]
00007583d7bda920  lea rcx, [rsp+0x30]
00007583d7bda925  mov r8d, 0x00
00007583d7bda92b  lea r9, [r15+0x3A8]
00007583d7bda932  movaps [rdi], xmm12
00007583d7bda936  movaps [rsi], xmm15
00007583d7bda93a  movaps [rdx], xmm1
00007583d7bda93d  movaps [rcx], xmm14
00007583d7bda941  mov rax, 0x5BCB7EA35A50
00007583d7bda94b  call rax
00007583d7bda94d  movaps xmm12, [rsp]
00007583d7bda952  add rsp, 0x40
00007583d7bda956  vmovaps xmm0, [rsp]
00007583d7bda95b  vmovaps xmm1, [rsp+0x10]
00007583d7bda961  vmovaps xmm2, [rsp+0x20]
00007583d7bda967  vmovaps xmm3, [rsp+0x30]
00007583d7bda96d  vmovaps xmm4, [rsp+0x40]
00007583d7bda973  vmovaps xmm5, [rsp+0x50]
00007583d7bda979  vmovaps xmm6, [rsp+0x60]
00007583d7bda97f  vmovaps xmm7, [rsp+0x70]
00007583d7bda985  vmovaps xmm8, [rsp+0x80]
00007583d7bda98e  vmovaps xmm9, [rsp+0x90]
00007583d7bda997  vmovaps xmm10, [rsp+0xA0]
00007583d7bda9a0  vmovaps xmm11, [rsp+0xB0]
00007583d7bda9a9  vmovaps xmm13, [rsp+0xC0]
00007583d7bda9b2  vmovaps xmm14, [rsp+0xD0]
00007583d7bda9bb  vmovaps xmm15, [rsp+0xE0]
00007583d7bda9c4  add rsp, 0xF0
00007583d7bda9cb  pop r11
00007583d7bda9cd  pop r10
00007583d7bda9cf  pop r9
00007583d7bda9d1  pop r8
00007583d7bda9d3  pop rsi
00007583d7bda9d4  pop rdi
00007583d7bda9d5  pop rdx
00007583d7bda9d6  pop rcx
00007583d7bda9d7  pop rax
00007583d7bda9d8  add rsp, 0x08
00007583d7bda9dc  jmp 0x00007583D7BD9CC0
00007583d7bda9e1  call 0x00007583D7AB52F0
00007583d7bda9e6  jmp 0x00007583D7BD9DAC
00007583d7bda9eb  sub rsp, 0x08
00007583d7bda9ef  push rax
00007583d7bda9f0  push rcx
00007583d7bda9f1  push rdx
00007583d7bda9f2  push rdi
00007583d7bda9f3  push rsi
00007583d7bda9f4  push r8
00007583d7bda9f6  push r9
00007583d7bda9f8  push r10
00007583d7bda9fa  push r11
00007583d7bda9fc  sub rsp, 0xF0
00007583d7bdaa03  vmovaps [rsp], xmm0
00007583d7bdaa08  vmovaps [rsp+0x10], xmm1
00007583d7bdaa0e  vmovaps [rsp+0x20], xmm2
00007583d7bdaa14  vmovaps [rsp+0x30], xmm3
00007583d7bdaa1a  vmovaps [rsp+0x40], xmm4
00007583d7bdaa20  vmovaps [rsp+0x50], xmm5
00007583d7bdaa26  vmovaps [rsp+0x60], xmm6
00007583d7bdaa2c  vmovaps [rsp+0x70], xmm7
00007583d7bdaa32  vmovaps [rsp+0x80], xmm8
00007583d7bdaa3b  vmovaps [rsp+0x90], xmm9
00007583d7bdaa44  vmovaps [rsp+0xA0], xmm10
00007583d7bdaa4d  vmovaps [rsp+0xB0], xmm11
00007583d7bdaa56  vmovaps [rsp+0xC0], xmm12
00007583d7bdaa5f  vmovaps [rsp+0xD0], xmm14
00007583d7bdaa68  vmovaps [rsp+0xE0], xmm15
00007583d7bdaa71  sub rsp, 0x40
00007583d7bdaa75  lea rdi, [rsp]
00007583d7bdaa79  lea rsi, [rsp+0x10]
00007583d7bdaa7e  lea rdx, [rsp+0x20]
00007583d7bdaa83  lea rcx, [rsp+0x30]
00007583d7bdaa88  mov r8d, 0x00
00007583d7bdaa8e  lea r9, [r15+0x3A8]
00007583d7bdaa95  movaps [rdi], xmm13
00007583d7bdaa99  movaps [rsi], xmm1
00007583d7bdaa9c  movaps [rdx], xmm15
00007583d7bdaaa0  movaps [rcx], xmm14
00007583d7bdaaa4  mov rax, 0x5BCB7EA35A50
00007583d7bdaaae  call rax
00007583d7bdaab0  movaps xmm13, [rsp]
00007583d7bdaab5  add rsp, 0x40
00007583d7bdaab9  vmovaps xmm0, [rsp]
00007583d7bdaabe  vmovaps xmm1, [rsp+0x10]
00007583d7bdaac4  vmovaps xmm2, [rsp+0x20]
00007583d7bdaaca  vmovaps xmm3, [rsp+0x30]
00007583d7bdaad0  vmovaps xmm4, [rsp+0x40]
00007583d7bdaad6  vmovaps xmm5, [rsp+0x50]
00007583d7bdaadc  vmovaps xmm6, [rsp+0x60]
00007583d7bdaae2  vmovaps xmm7, [rsp+0x70]
00007583d7bdaae8  vmovaps xmm8, [rsp+0x80]
00007583d7bdaaf1  vmovaps xmm9, [rsp+0x90]
00007583d7bdaafa  vmovaps xmm10, [rsp+0xA0]
00007583d7bdab03  vmovaps xmm11, [rsp+0xB0]
00007583d7bdab0c  vmovaps xmm12, [rsp+0xC0]
00007583d7bdab15  vmovaps xmm14, [rsp+0xD0]
00007583d7bdab1e  vmovaps xmm15, [rsp+0xE0]
00007583d7bdab27  add rsp, 0xF0
00007583d7bdab2e  pop r11
00007583d7bdab30  pop r10
00007583d7bdab32  pop r9
00007583d7bdab34  pop r8
00007583d7bdab36  pop rsi
00007583d7bdab37  pop rdi
00007583d7bdab38  pop rdx
00007583d7bdab39  pop rcx
00007583d7bdab3a  pop rax
00007583d7bdab3b  add rsp, 0x08
00007583d7bdab3f  jmp 0x00007583D7BD9E21
00007583d7bdab44  call 0x00007583D79FF430
00007583d7bdab49  jmp 0x00007583D7BD9E2E
00007583d7bdab4e  sub rsp, 0x08
00007583d7bdab52  push rax
00007583d7bdab53  push rcx
00007583d7bdab54  push rdx
00007583d7bdab55  push rdi
00007583d7bdab56  push rsi
00007583d7bdab57  push r8
00007583d7bdab59  push r9
00007583d7bdab5b  push r10
00007583d7bdab5d  push r11
00007583d7bdab5f  sub rsp, 0xF0
00007583d7bdab66  vmovaps [rsp], xmm0
00007583d7bdab6b  vmovaps [rsp+0x10], xmm1
00007583d7bdab71  vmovaps [rsp+0x20], xmm2
00007583d7bdab77  vmovaps [rsp+0x30], xmm3
00007583d7bdab7d  vmovaps [rsp+0x40], xmm4
00007583d7bdab83  vmovaps [rsp+0x50], xmm5
00007583d7bdab89  vmovaps [rsp+0x60], xmm6
00007583d7bdab8f  vmovaps [rsp+0x70], xmm7
00007583d7bdab95  vmovaps [rsp+0x80], xmm8
00007583d7bdab9e  vmovaps [rsp+0x90], xmm9
00007583d7bdaba7  vmovaps [rsp+0xA0], xmm10
00007583d7bdabb0  vmovaps [rsp+0xB0], xmm11
00007583d7bdabb9  vmovaps [rsp+0xC0], xmm13
00007583d7bdabc2  vmovaps [rsp+0xD0], xmm14
00007583d7bdabcb  vmovaps [rsp+0xE0], xmm15
00007583d7bdabd4  sub rsp, 0x40
00007583d7bdabd8  lea rdi, [rsp]
00007583d7bdabdc  lea rsi, [rsp+0x10]
00007583d7bdabe1  lea rdx, [rsp+0x20]
00007583d7bdabe6  lea rcx, [rsp+0x30]
00007583d7bdabeb  mov r8d, 0x00
00007583d7bdabf1  lea r9, [r15+0x3A8]
00007583d7bdabf8  movaps [rdi], xmm12
00007583d7bdabfc  movaps [rsi], xmm15
00007583d7bdac00  movaps [rdx], xmm1
00007583d7bdac03  movaps [rcx], xmm14
00007583d7bdac07  mov rax, 0x5BCB7EA35A50
00007583d7bdac11  call rax
00007583d7bdac13  movaps xmm12, [rsp]
00007583d7bdac18  add rsp, 0x40
00007583d7bdac1c  vmovaps xmm0, [rsp]
00007583d7bdac21  vmovaps xmm1, [rsp+0x10]
00007583d7bdac27  vmovaps xmm2, [rsp+0x20]
00007583d7bdac2d  vmovaps xmm3, [rsp+0x30]
00007583d7bdac33  vmovaps xmm4, [rsp+0x40]
00007583d7bdac39  vmovaps xmm5, [rsp+0x50]
00007583d7bdac3f  vmovaps xmm6, [rsp+0x60]
00007583d7bdac45  vmovaps xmm7, [rsp+0x70]
00007583d7bdac4b  vmovaps xmm8, [rsp+0x80]
00007583d7bdac54  vmovaps xmm9, [rsp+0x90]
00007583d7bdac5d  vmovaps xmm10, [rsp+0xA0]
00007583d7bdac66  vmovaps xmm11, [rsp+0xB0]
00007583d7bdac6f  vmovaps xmm13, [rsp+0xC0]
00007583d7bdac78  vmovaps xmm14, [rsp+0xD0]
00007583d7bdac81  vmovaps xmm15, [rsp+0xE0]
00007583d7bdac8a  add rsp, 0xF0
00007583d7bdac91  pop r11
00007583d7bdac93  pop r10
00007583d7bdac95  pop r9
00007583d7bdac97  pop r8
00007583d7bdac99  pop rsi
00007583d7bdac9a  pop rdi
00007583d7bdac9b  pop rdx
00007583d7bdac9c  pop rcx
00007583d7bdac9d  pop rax
00007583d7bdac9e  add rsp, 0x08
00007583d7bdaca2  jmp 0x00007583D7BD9E5A
00007583d7bdaca7  sub rsp, 0x08
00007583d7bdacab  push rax
00007583d7bdacac  push rcx
00007583d7bdacad  push rdx
00007583d7bdacae  push rdi
00007583d7bdacaf  push rsi
00007583d7bdacb0  push r8
00007583d7bdacb2  push r9
00007583d7bdacb4  push r10
00007583d7bdacb6  push r11
00007583d7bdacb8  sub rsp, 0xF0
00007583d7bdacbf  vmovaps [rsp], xmm0
00007583d7bdacc4  vmovaps [rsp+0x10], xmm1
00007583d7bdacca  vmovaps [rsp+0x20], xmm2
00007583d7bdacd0  vmovaps [rsp+0x30], xmm3
00007583d7bdacd6  vmovaps [rsp+0x40], xmm4
00007583d7bdacdc  vmovaps [rsp+0x50], xmm5
00007583d7bdace2  vmovaps [rsp+0x60], xmm6
00007583d7bdace8  vmovaps [rsp+0x70], xmm7
00007583d7bdacee  vmovaps [rsp+0x80], xmm8
00007583d7bdacf7  vmovaps [rsp+0x90], xmm9
00007583d7bdad00  vmovaps [rsp+0xA0], xmm10
00007583d7bdad09  vmovaps [rsp+0xB0], xmm11
00007583d7bdad12  vmovaps [rsp+0xC0], xmm12
00007583d7bdad1b  vmovaps [rsp+0xD0], xmm14
00007583d7bdad24  vmovaps [rsp+0xE0], xmm15
00007583d7bdad2d  sub rsp, 0x40
00007583d7bdad31  lea rdi, [rsp]
00007583d7bdad35  lea rsi, [rsp+0x10]
00007583d7bdad3a  lea rdx, [rsp+0x20]
00007583d7bdad3f  lea rcx, [rsp+0x30]
00007583d7bdad44  mov r8d, 0x00
00007583d7bdad4a  lea r9, [r15+0x3A8]
00007583d7bdad51  movaps [rdi], xmm13
00007583d7bdad55  movaps [rsi], xmm1
00007583d7bdad58  movaps [rdx], xmm15
00007583d7bdad5c  movaps [rcx], xmm14
00007583d7bdad60  mov rax, 0x5BCB7EA35A50
00007583d7bdad6a  call rax
00007583d7bdad6c  movaps xmm13, [rsp]
00007583d7bdad71  add rsp, 0x40
00007583d7bdad75  vmovaps xmm0, [rsp]
00007583d7bdad7a  vmovaps xmm1, [rsp+0x10]
00007583d7bdad80  vmovaps xmm2, [rsp+0x20]
00007583d7bdad86  vmovaps xmm3, [rsp+0x30]
00007583d7bdad8c  vmovaps xmm4, [rsp+0x40]
00007583d7bdad92  vmovaps xmm5, [rsp+0x50]
00007583d7bdad98  vmovaps xmm6, [rsp+0x60]
00007583d7bdad9e  vmovaps xmm7, [rsp+0x70]
00007583d7bdada4  vmovaps xmm8, [rsp+0x80]
00007583d7bdadad  vmovaps xmm9, [rsp+0x90]
00007583d7bdadb6  vmovaps xmm10, [rsp+0xA0]
00007583d7bdadbf  vmovaps xmm11, [rsp+0xB0]
00007583d7bdadc8  vmovaps xmm12, [rsp+0xC0]
00007583d7bdadd1  vmovaps xmm14, [rsp+0xD0]
00007583d7bdadda  vmovaps xmm15, [rsp+0xE0]
00007583d7bdade3  add rsp, 0xF0
00007583d7bdadea  pop r11
00007583d7bdadec  pop r10
00007583d7bdadee  pop r9
00007583d7bdadf0  pop r8
00007583d7bdadf2  pop rsi
00007583d7bdadf3  pop rdi
00007583d7bdadf4  pop rdx
00007583d7bdadf5  pop rcx
00007583d7bdadf6  pop rax
00007583d7bdadf7  add rsp, 0x08
00007583d7bdadfb  jmp 0x00007583D7BD9FEA
00007583d7bdae00  sub rsp, 0x08
00007583d7bdae04  push rax
00007583d7bdae05  push rcx
00007583d7bdae06  push rdx
00007583d7bdae07  push rdi
00007583d7bdae08  push rsi
00007583d7bdae09  push r8
00007583d7bdae0b  push r9
00007583d7bdae0d  push r10
00007583d7bdae0f  push r11
00007583d7bdae11  sub rsp, 0xF0
00007583d7bdae18  vmovaps [rsp], xmm0
00007583d7bdae1d  vmovaps [rsp+0x10], xmm1
00007583d7bdae23  vmovaps [rsp+0x20], xmm2
00007583d7bdae29  vmovaps [rsp+0x30], xmm3
00007583d7bdae2f  vmovaps [rsp+0x40], xmm4
00007583d7bdae35  vmovaps [rsp+0x50], xmm5
00007583d7bdae3b  vmovaps [rsp+0x60], xmm6
00007583d7bdae41  vmovaps [rsp+0x70], xmm7
00007583d7bdae47  vmovaps [rsp+0x80], xmm8
00007583d7bdae50  vmovaps [rsp+0x90], xmm9
00007583d7bdae59  vmovaps [rsp+0xA0], xmm10
00007583d7bdae62  vmovaps [rsp+0xB0], xmm11
00007583d7bdae6b  vmovaps [rsp+0xC0], xmm12
00007583d7bdae74  vmovaps [rsp+0xD0], xmm13
00007583d7bdae7d  vmovaps [rsp+0xE0], xmm15
00007583d7bdae86  sub rsp, 0x40
00007583d7bdae8a  lea rdi, [rsp]
00007583d7bdae8e  lea rsi, [rsp+0x10]
00007583d7bdae93  lea rdx, [rsp+0x20]
00007583d7bdae98  lea rcx, [rsp+0x30]
00007583d7bdae9d  mov r8d, 0x00
00007583d7bdaea3  lea r9, [r15+0x3A8]
00007583d7bdaeaa  movaps [rdi], xmm14
00007583d7bdaeae  movaps [rsi], xmm15
00007583d7bdaeb2  movaps [rdx], xmm2
00007583d7bdaeb5  movaps [rcx], xmm1
00007583d7bdaeb8  mov rax, 0x5BCB7EA35A50
00007583d7bdaec2  call rax
00007583d7bdaec4  movaps xmm14, [rsp]
00007583d7bdaec9  add rsp, 0x40
00007583d7bdaecd  vmovaps xmm0, [rsp]
00007583d7bdaed2  vmovaps xmm1, [rsp+0x10]
00007583d7bdaed8  vmovaps xmm2, [rsp+0x20]
00007583d7bdaede  vmovaps xmm3, [rsp+0x30]
00007583d7bdaee4  vmovaps xmm4, [rsp+0x40]
00007583d7bdaeea  vmovaps xmm5, [rsp+0x50]
00007583d7bdaef0  vmovaps xmm6, [rsp+0x60]
00007583d7bdaef6  vmovaps xmm7, [rsp+0x70]
00007583d7bdaefc  vmovaps xmm8, [rsp+0x80]
00007583d7bdaf05  vmovaps xmm9, [rsp+0x90]
00007583d7bdaf0e  vmovaps xmm10, [rsp+0xA0]
00007583d7bdaf17  vmovaps xmm11, [rsp+0xB0]
00007583d7bdaf20  vmovaps xmm12, [rsp+0xC0]
00007583d7bdaf29  vmovaps xmm13, [rsp+0xD0]
00007583d7bdaf32  vmovaps xmm15, [rsp+0xE0]
00007583d7bdaf3b  add rsp, 0xF0
00007583d7bdaf42  pop r11
00007583d7bdaf44  pop r10
00007583d7bdaf46  pop r9
00007583d7bdaf48  pop r8
00007583d7bdaf4a  pop rsi
00007583d7bdaf4b  pop rdi
00007583d7bdaf4c  pop rdx
00007583d7bdaf4d  pop rcx
00007583d7bdaf4e  pop rax
00007583d7bdaf4f  add rsp, 0x08
00007583d7bdaf53  jmp 0x00007583D7BDA01C
00007583d7bdaf58  sub rsp, 0x08
00007583d7bdaf5c  push rax
00007583d7bdaf5d  push rcx
00007583d7bdaf5e  push rdx
00007583d7bdaf5f  push rdi
00007583d7bdaf60  push rsi
00007583d7bdaf61  push r8
00007583d7bdaf63  push r9
00007583d7bdaf65  push r10
00007583d7bdaf67  push r11
00007583d7bdaf69  sub rsp, 0xF0
00007583d7bdaf70  vmovaps [rsp], xmm0
00007583d7bdaf75  vmovaps [rsp+0x10], xmm1
00007583d7bdaf7b  vmovaps [rsp+0x20], xmm3
00007583d7bdaf81  vmovaps [rsp+0x30], xmm4
00007583d7bdaf87  vmovaps [rsp+0x40], xmm5
00007583d7bdaf8d  vmovaps [rsp+0x50], xmm6
00007583d7bdaf93  vmovaps [rsp+0x60], xmm7
00007583d7bdaf99  vmovaps [rsp+0x70], xmm8
00007583d7bdaf9f  vmovaps [rsp+0x80], xmm9
00007583d7bdafa8  vmovaps [rsp+0x90], xmm10
00007583d7bdafb1  vmovaps [rsp+0xA0], xmm11
00007583d7bdafba  vmovaps [rsp+0xB0], xmm12
00007583d7bdafc3  vmovaps [rsp+0xC0], xmm13
00007583d7bdafcc  vmovaps [rsp+0xD0], xmm14
00007583d7bdafd5  vmovaps [rsp+0xE0], xmm15
00007583d7bdafde  sub rsp, 0x40
00007583d7bdafe2  lea rdi, [rsp]
00007583d7bdafe6  lea rsi, [rsp+0x10]
00007583d7bdafeb  lea rdx, [rsp+0x20]
00007583d7bdaff0  lea rcx, [rsp+0x30]
00007583d7bdaff5  mov r8d, 0x00
00007583d7bdaffb  lea r9, [r15+0x3A8]
00007583d7bdb002  movaps [rdi], xmm2
00007583d7bdb005  movaps [rsi], xmm15
00007583d7bdb009  movaps [rdx], xmm12
00007583d7bdb00d  movaps [rcx], xmm1
00007583d7bdb010  mov rax, 0x5BCB7EA35A50
00007583d7bdb01a  call rax
00007583d7bdb01c  movaps xmm2, [rsp]
00007583d7bdb020  add rsp, 0x40
00007583d7bdb024  vmovaps xmm0, [rsp]
00007583d7bdb029  vmovaps xmm1, [rsp+0x10]
00007583d7bdb02f  vmovaps xmm3, [rsp+0x20]
00007583d7bdb035  vmovaps xmm4, [rsp+0x30]
00007583d7bdb03b  vmovaps xmm5, [rsp+0x40]
00007583d7bdb041  vmovaps xmm6, [rsp+0x50]
00007583d7bdb047  vmovaps xmm7, [rsp+0x60]
00007583d7bdb04d  vmovaps xmm8, [rsp+0x70]
00007583d7bdb053  vmovaps xmm9, [rsp+0x80]
00007583d7bdb05c  vmovaps xmm10, [rsp+0x90]
00007583d7bdb065  vmovaps xmm11, [rsp+0xA0]
00007583d7bdb06e  vmovaps xmm12, [rsp+0xB0]
00007583d7bdb077  vmovaps xmm13, [rsp+0xC0]
00007583d7bdb080  vmovaps xmm14, [rsp+0xD0]
00007583d7bdb089  vmovaps xmm15, [rsp+0xE0]
00007583d7bdb092  add rsp, 0xF0
00007583d7bdb099  pop r11
00007583d7bdb09b  pop r10
00007583d7bdb09d  pop r9
00007583d7bdb09f  pop r8
00007583d7bdb0a1  pop rsi
00007583d7bdb0a2  pop rdi
00007583d7bdb0a3  pop rdx
00007583d7bdb0a4  pop rcx
00007583d7bdb0a5  pop rax
00007583d7bdb0a6  add rsp, 0x08
00007583d7bdb0aa  jmp 0x00007583D7BDA059
00007583d7bdb0af  sub rsp, 0x08
00007583d7bdb0b3  push rax
00007583d7bdb0b4  push rcx
00007583d7bdb0b5  push rdx
00007583d7bdb0b6  push rdi
00007583d7bdb0b7  push rsi
00007583d7bdb0b8  push r8
00007583d7bdb0ba  push r9
00007583d7bdb0bc  push r10
00007583d7bdb0be  push r11
00007583d7bdb0c0  sub rsp, 0xF0
00007583d7bdb0c7  vmovaps [rsp], xmm0
00007583d7bdb0cc  vmovaps [rsp+0x10], xmm1
00007583d7bdb0d2  vmovaps [rsp+0x20], xmm2
00007583d7bdb0d8  vmovaps [rsp+0x30], xmm3
00007583d7bdb0de  vmovaps [rsp+0x40], xmm4
00007583d7bdb0e4  vmovaps [rsp+0x50], xmm5
00007583d7bdb0ea  vmovaps [rsp+0x60], xmm6
00007583d7bdb0f0  vmovaps [rsp+0x70], xmm7
00007583d7bdb0f6  vmovaps [rsp+0x80], xmm8
00007583d7bdb0ff  vmovaps [rsp+0x90], xmm9
00007583d7bdb108  vmovaps [rsp+0xA0], xmm10
00007583d7bdb111  vmovaps [rsp+0xB0], xmm11
00007583d7bdb11a  vmovaps [rsp+0xC0], xmm13
00007583d7bdb123  vmovaps [rsp+0xD0], xmm14
00007583d7bdb12c  vmovaps [rsp+0xE0], xmm15
00007583d7bdb135  sub rsp, 0x40
00007583d7bdb139  lea rdi, [rsp]
00007583d7bdb13d  lea rsi, [rsp+0x10]
00007583d7bdb142  lea rdx, [rsp+0x20]
00007583d7bdb147  lea rcx, [rsp+0x30]
00007583d7bdb14c  mov r8d, 0x00
00007583d7bdb152  lea r9, [r15+0x3A8]
00007583d7bdb159  movaps [rdi], xmm12
00007583d7bdb15d  movaps [rsi], xmm14
00007583d7bdb161  movaps [rdx], xmm3
00007583d7bdb164  movaps [rcx], xmm15
00007583d7bdb168  mov rax, 0x5BCB7EA35A50
00007583d7bdb172  call rax
00007583d7bdb174  movaps xmm12, [rsp]
00007583d7bdb179  add rsp, 0x40
00007583d7bdb17d  vmovaps xmm0, [rsp]
00007583d7bdb182  vmovaps xmm1, [rsp+0x10]
00007583d7bdb188  vmovaps xmm2, [rsp+0x20]
00007583d7bdb18e  vmovaps xmm3, [rsp+0x30]
00007583d7bdb194  vmovaps xmm4, [rsp+0x40]
00007583d7bdb19a  vmovaps xmm5, [rsp+0x50]
00007583d7bdb1a0  vmovaps xmm6, [rsp+0x60]
00007583d7bdb1a6  vmovaps xmm7, [rsp+0x70]
00007583d7bdb1ac  vmovaps xmm8, [rsp+0x80]
00007583d7bdb1b5  vmovaps xmm9, [rsp+0x90]
00007583d7bdb1be  vmovaps xmm10, [rsp+0xA0]
00007583d7bdb1c7  vmovaps xmm11, [rsp+0xB0]
00007583d7bdb1d0  vmovaps xmm13, [rsp+0xC0]
00007583d7bdb1d9  vmovaps xmm14, [rsp+0xD0]
00007583d7bdb1e2  vmovaps xmm15, [rsp+0xE0]
00007583d7bdb1eb  add rsp, 0xF0
00007583d7bdb1f2  pop r11
00007583d7bdb1f4  pop r10
00007583d7bdb1f6  pop r9
00007583d7bdb1f8  pop r8
00007583d7bdb1fa  pop rsi
00007583d7bdb1fb  pop rdi
00007583d7bdb1fc  pop rdx
00007583d7bdb1fd  pop rcx
00007583d7bdb1fe  pop rax
00007583d7bdb1ff  add rsp, 0x08
00007583d7bdb203  jmp 0x00007583D7BDA0B3
00007583d7bdb208  sub rsp, 0x08
00007583d7bdb20c  push rax
00007583d7bdb20d  push rcx
00007583d7bdb20e  push rdx
00007583d7bdb20f  push rdi
00007583d7bdb210  push rsi
00007583d7bdb211  push r8
00007583d7bdb213  push r9
00007583d7bdb215  push r10
00007583d7bdb217  push r11
00007583d7bdb219  sub rsp, 0xF0
00007583d7bdb220  vmovaps [rsp], xmm0
00007583d7bdb225  vmovaps [rsp+0x10], xmm1
00007583d7bdb22b  vmovaps [rsp+0x20], xmm2
00007583d7bdb231  vmovaps [rsp+0x30], xmm3
00007583d7bdb237  vmovaps [rsp+0x40], xmm4
00007583d7bdb23d  vmovaps [rsp+0x50], xmm5
00007583d7bdb243  vmovaps [rsp+0x60], xmm6
00007583d7bdb249  vmovaps [rsp+0x70], xmm7
00007583d7bdb24f  vmovaps [rsp+0x80], xmm8
00007583d7bdb258  vmovaps [rsp+0x90], xmm10
00007583d7bdb261  vmovaps [rsp+0xA0], xmm11
00007583d7bdb26a  vmovaps [rsp+0xB0], xmm12
00007583d7bdb273  vmovaps [rsp+0xC0], xmm13
00007583d7bdb27c  vmovaps [rsp+0xD0], xmm14
00007583d7bdb285  vmovaps [rsp+0xE0], xmm15
00007583d7bdb28e  sub rsp, 0x40
00007583d7bdb292  lea rdi, [rsp]
00007583d7bdb296  lea rsi, [rsp+0x10]
00007583d7bdb29b  lea rdx, [rsp+0x20]
00007583d7bdb2a0  lea rcx, [rsp+0x30]
00007583d7bdb2a5  mov r8d, 0x00
00007583d7bdb2ab  lea r9, [r15+0x3A8]
00007583d7bdb2b2  movaps [rdi], xmm9
00007583d7bdb2b6  movaps [rsi], xmm13
00007583d7bdb2ba  movaps [rdx], xmm14
00007583d7bdb2be  movaps [rcx], xmm6
00007583d7bdb2c1  mov rax, 0x5BCB7EA35A50
00007583d7bdb2cb  call rax
00007583d7bdb2cd  movaps xmm9, [rsp]
00007583d7bdb2d2  add rsp, 0x40
00007583d7bdb2d6  vmovaps xmm0, [rsp]
00007583d7bdb2db  vmovaps xmm1, [rsp+0x10]
00007583d7bdb2e1  vmovaps xmm2, [rsp+0x20]
00007583d7bdb2e7  vmovaps xmm3, [rsp+0x30]
00007583d7bdb2ed  vmovaps xmm4, [rsp+0x40]
00007583d7bdb2f3  vmovaps xmm5, [rsp+0x50]
00007583d7bdb2f9  vmovaps xmm6, [rsp+0x60]
00007583d7bdb2ff  vmovaps xmm7, [rsp+0x70]
00007583d7bdb305  vmovaps xmm8, [rsp+0x80]
00007583d7bdb30e  vmovaps xmm10, [rsp+0x90]
00007583d7bdb317  vmovaps xmm11, [rsp+0xA0]
00007583d7bdb320  vmovaps xmm12, [rsp+0xB0]
00007583d7bdb329  vmovaps xmm13, [rsp+0xC0]
00007583d7bdb332  vmovaps xmm14, [rsp+0xD0]
00007583d7bdb33b  vmovaps xmm15, [rsp+0xE0]
00007583d7bdb344  add rsp, 0xF0
00007583d7bdb34b  pop r11
00007583d7bdb34d  pop r10
00007583d7bdb34f  pop r9
00007583d7bdb351  pop r8
00007583d7bdb353  pop rsi
00007583d7bdb354  pop rdi
00007583d7bdb355  pop rdx
00007583d7bdb356  pop rcx
00007583d7bdb357  pop rax
00007583d7bdb358  add rsp, 0x08
00007583d7bdb35c  jmp 0x00007583D7BDA15D
00007583d7bdb361  sub rsp, 0x08
00007583d7bdb365  push rax
00007583d7bdb366  push rcx
00007583d7bdb367  push rdx
00007583d7bdb368  push rdi
00007583d7bdb369  push rsi
00007583d7bdb36a  push r8
00007583d7bdb36c  push r9
00007583d7bdb36e  push r10
00007583d7bdb370  push r11
00007583d7bdb372  sub rsp, 0xF0
00007583d7bdb379  vmovaps [rsp], xmm0
00007583d7bdb37e  vmovaps [rsp+0x10], xmm1
00007583d7bdb384  vmovaps [rsp+0x20], xmm2
00007583d7bdb38a  vmovaps [rsp+0x30], xmm4
00007583d7bdb390  vmovaps [rsp+0x40], xmm5
00007583d7bdb396  vmovaps [rsp+0x50], xmm6
00007583d7bdb39c  vmovaps [rsp+0x60], xmm7
00007583d7bdb3a2  vmovaps [rsp+0x70], xmm8
00007583d7bdb3a8  vmovaps [rsp+0x80], xmm9
00007583d7bdb3b1  vmovaps [rsp+0x90], xmm10
00007583d7bdb3ba  vmovaps [rsp+0xA0], xmm11
00007583d7bdb3c3  vmovaps [rsp+0xB0], xmm12
00007583d7bdb3cc  vmovaps [rsp+0xC0], xmm13
00007583d7bdb3d5  vmovaps [rsp+0xD0], xmm14
00007583d7bdb3de  vmovaps [rsp+0xE0], xmm15
00007583d7bdb3e7  sub rsp, 0x40
00007583d7bdb3eb  lea rdi, [rsp]
00007583d7bdb3ef  lea rsi, [rsp+0x10]
00007583d7bdb3f4  lea rdx, [rsp+0x20]
00007583d7bdb3f9  lea rcx, [rsp+0x30]
00007583d7bdb3fe  mov r8d, 0x00
00007583d7bdb404  lea r9, [r15+0x3A8]
00007583d7bdb40b  movaps [rdi], xmm3
00007583d7bdb40e  movaps [rsi], xmm13
00007583d7bdb412  movaps [rdx], xmm6
00007583d7bdb415  movaps [rcx], xmm14
00007583d7bdb419  mov rax, 0x5BCB7EA35A50
00007583d7bdb423  call rax
00007583d7bdb425  movaps xmm3, [rsp]
00007583d7bdb429  add rsp, 0x40
00007583d7bdb42d  vmovaps xmm0, [rsp]
00007583d7bdb432  vmovaps xmm1, [rsp+0x10]
00007583d7bdb438  vmovaps xmm2, [rsp+0x20]
00007583d7bdb43e  vmovaps xmm4, [rsp+0x30]
00007583d7bdb444  vmovaps xmm5, [rsp+0x40]
00007583d7bdb44a  vmovaps xmm6, [rsp+0x50]
00007583d7bdb450  vmovaps xmm7, [rsp+0x60]
00007583d7bdb456  vmovaps xmm8, [rsp+0x70]
00007583d7bdb45c  vmovaps xmm9, [rsp+0x80]
00007583d7bdb465  vmovaps xmm10, [rsp+0x90]
00007583d7bdb46e  vmovaps xmm11, [rsp+0xA0]
00007583d7bdb477  vmovaps xmm12, [rsp+0xB0]
00007583d7bdb480  vmovaps xmm13, [rsp+0xC0]
00007583d7bdb489  vmovaps xmm14, [rsp+0xD0]
00007583d7bdb492  vmovaps xmm15, [rsp+0xE0]
00007583d7bdb49b  add rsp, 0xF0
00007583d7bdb4a2  pop r11
00007583d7bdb4a4  pop r10
00007583d7bdb4a6  pop r9
00007583d7bdb4a8  pop r8
00007583d7bdb4aa  pop rsi
00007583d7bdb4ab  pop rdi
00007583d7bdb4ac  pop rdx
00007583d7bdb4ad  pop rcx
00007583d7bdb4ae  pop rax
00007583d7bdb4af  add rsp, 0x08
00007583d7bdb4b3  jmp 0x00007583D7BDA19A
00007583d7bdb4b8  sub rsp, 0x08
00007583d7bdb4bc  push rax
00007583d7bdb4bd  push rcx
00007583d7bdb4be  push rdx
00007583d7bdb4bf  push rdi
00007583d7bdb4c0  push rsi
00007583d7bdb4c1  push r8
00007583d7bdb4c3  push r9
00007583d7bdb4c5  push r10
00007583d7bdb4c7  push r11
00007583d7bdb4c9  sub rsp, 0xF0
00007583d7bdb4d0  vmovaps [rsp], xmm0
00007583d7bdb4d5  vmovaps [rsp+0x10], xmm1
00007583d7bdb4db  vmovaps [rsp+0x20], xmm2
00007583d7bdb4e1  vmovaps [rsp+0x30], xmm3
00007583d7bdb4e7  vmovaps [rsp+0x40], xmm4
00007583d7bdb4ed  vmovaps [rsp+0x50], xmm5
00007583d7bdb4f3  vmovaps [rsp+0x60], xmm7
00007583d7bdb4f9  vmovaps [rsp+0x70], xmm8
00007583d7bdb4ff  vmovaps [rsp+0x80], xmm9
00007583d7bdb508  vmovaps [rsp+0x90], xmm10
00007583d7bdb511  vmovaps [rsp+0xA0], xmm11
00007583d7bdb51a  vmovaps [rsp+0xB0], xmm12
00007583d7bdb523  vmovaps [rsp+0xC0], xmm13
00007583d7bdb52c  vmovaps [rsp+0xD0], xmm14
00007583d7bdb535  vmovaps [rsp+0xE0], xmm15
00007583d7bdb53e  sub rsp, 0x40
00007583d7bdb542  lea rdi, [rsp]
00007583d7bdb546  lea rsi, [rsp+0x10]
00007583d7bdb54b  lea rdx, [rsp+0x20]
00007583d7bdb550  lea rcx, [rsp+0x30]
00007583d7bdb555  mov r8d, 0x00
00007583d7bdb55b  lea r9, [r15+0x3A8]
00007583d7bdb562  movaps [rdi], xmm6
00007583d7bdb565  movaps [rsi], xmm2
00007583d7bdb568  movaps [rdx], xmm14
00007583d7bdb56c  movaps [rcx], xmm1
00007583d7bdb56f  mov rax, 0x5BCB7EA35A50
00007583d7bdb579  call rax
00007583d7bdb57b  movaps xmm6, [rsp]
00007583d7bdb57f  add rsp, 0x40
00007583d7bdb583  vmovaps xmm0, [rsp]
00007583d7bdb588  vmovaps xmm1, [rsp+0x10]
00007583d7bdb58e  vmovaps xmm2, [rsp+0x20]
00007583d7bdb594  vmovaps xmm3, [rsp+0x30]
00007583d7bdb59a  vmovaps xmm4, [rsp+0x40]
00007583d7bdb5a0  vmovaps xmm5, [rsp+0x50]
00007583d7bdb5a6  vmovaps xmm7, [rsp+0x60]
00007583d7bdb5ac  vmovaps xmm8, [rsp+0x70]
00007583d7bdb5b2  vmovaps xmm9, [rsp+0x80]
00007583d7bdb5bb  vmovaps xmm10, [rsp+0x90]
00007583d7bdb5c4  vmovaps xmm11, [rsp+0xA0]
00007583d7bdb5cd  vmovaps xmm12, [rsp+0xB0]
00007583d7bdb5d6  vmovaps xmm13, [rsp+0xC0]
00007583d7bdb5df  vmovaps xmm14, [rsp+0xD0]
00007583d7bdb5e8  vmovaps xmm15, [rsp+0xE0]
00007583d7bdb5f1  add rsp, 0xF0
00007583d7bdb5f8  pop r11
00007583d7bdb5fa  pop r10
00007583d7bdb5fc  pop r9
00007583d7bdb5fe  pop r8
00007583d7bdb600  pop rsi
00007583d7bdb601  pop rdi
00007583d7bdb602  pop rdx
00007583d7bdb603  pop rcx
00007583d7bdb604  pop rax
00007583d7bdb605  add rsp, 0x08
00007583d7bdb609  jmp 0x00007583D7BDA1C7
00007583d7bdb60e  sub rsp, 0x08
00007583d7bdb612  push rax
00007583d7bdb613  push rcx
00007583d7bdb614  push rdx
00007583d7bdb615  push rdi
00007583d7bdb616  push rsi
00007583d7bdb617  push r8
00007583d7bdb619  push r9
00007583d7bdb61b  push r10
00007583d7bdb61d  push r11
00007583d7bdb61f  sub rsp, 0xF0
00007583d7bdb626  vmovaps [rsp], xmm0
00007583d7bdb62b  vmovaps [rsp+0x10], xmm1
00007583d7bdb631  vmovaps [rsp+0x20], xmm2
00007583d7bdb637  vmovaps [rsp+0x30], xmm3
00007583d7bdb63d  vmovaps [rsp+0x40], xmm4
00007583d7bdb643  vmovaps [rsp+0x50], xmm5
00007583d7bdb649  vmovaps [rsp+0x60], xmm6
00007583d7bdb64f  vmovaps [rsp+0x70], xmm7
00007583d7bdb655  vmovaps [rsp+0x80], xmm8
00007583d7bdb65e  vmovaps [rsp+0x90], xmm9
00007583d7bdb667  vmovaps [rsp+0xA0], xmm10
00007583d7bdb670  vmovaps [rsp+0xB0], xmm11
00007583d7bdb679  vmovaps [rsp+0xC0], xmm12
00007583d7bdb682  vmovaps [rsp+0xD0], xmm14
00007583d7bdb68b  vmovaps [rsp+0xE0], xmm15
00007583d7bdb694  sub rsp, 0x40
00007583d7bdb698  lea rdi, [rsp]
00007583d7bdb69c  lea rsi, [rsp+0x10]
00007583d7bdb6a1  lea rdx, [rsp+0x20]
00007583d7bdb6a6  lea rcx, [rsp+0x30]
00007583d7bdb6ab  mov r8d, 0x00
00007583d7bdb6b1  lea r9, [r15+0x3A8]
00007583d7bdb6b8  movaps [rdi], xmm13
00007583d7bdb6bc  movaps [rsi], xmm12
00007583d7bdb6c0  movaps [rdx], xmm14
00007583d7bdb6c4  movaps [rcx], xmm1
00007583d7bdb6c7  mov rax, 0x5BCB7EA35A50
00007583d7bdb6d1  call rax
00007583d7bdb6d3  movaps xmm13, [rsp]
00007583d7bdb6d8  add rsp, 0x40
00007583d7bdb6dc  vmovaps xmm0, [rsp]
00007583d7bdb6e1  vmovaps xmm1, [rsp+0x10]
00007583d7bdb6e7  vmovaps xmm2, [rsp+0x20]
00007583d7bdb6ed  vmovaps xmm3, [rsp+0x30]
00007583d7bdb6f3  vmovaps xmm4, [rsp+0x40]
00007583d7bdb6f9  vmovaps xmm5, [rsp+0x50]
00007583d7bdb6ff  vmovaps xmm6, [rsp+0x60]
00007583d7bdb705  vmovaps xmm7, [rsp+0x70]
00007583d7bdb70b  vmovaps xmm8, [rsp+0x80]
00007583d7bdb714  vmovaps xmm9, [rsp+0x90]
00007583d7bdb71d  vmovaps xmm10, [rsp+0xA0]
00007583d7bdb726  vmovaps xmm11, [rsp+0xB0]
00007583d7bdb72f  vmovaps xmm12, [rsp+0xC0]
00007583d7bdb738  vmovaps xmm14, [rsp+0xD0]
00007583d7bdb741  vmovaps xmm15, [rsp+0xE0]
00007583d7bdb74a  add rsp, 0xF0
00007583d7bdb751  pop r11
00007583d7bdb753  pop r10
00007583d7bdb755  pop r9
00007583d7bdb757  pop r8
00007583d7bdb759  pop rsi
00007583d7bdb75a  pop rdi
00007583d7bdb75b  pop rdx
00007583d7bdb75c  pop rcx
00007583d7bdb75d  pop rax
00007583d7bdb75e  add rsp, 0x08
00007583d7bdb762  jmp 0x00007583D7BDA1F9
00007583d7bdb767  sub rsp, 0x08
00007583d7bdb76b  push rax
00007583d7bdb76c  push rcx
00007583d7bdb76d  push rdx
00007583d7bdb76e  push rdi
00007583d7bdb76f  push rsi
00007583d7bdb770  push r8
00007583d7bdb772  push r9
00007583d7bdb774  push r10
00007583d7bdb776  push r11
00007583d7bdb778  sub rsp, 0xF0
00007583d7bdb77f  vmovaps [rsp], xmm0
00007583d7bdb784  vmovaps [rsp+0x10], xmm1
00007583d7bdb78a  vmovaps [rsp+0x20], xmm2
00007583d7bdb790  vmovaps [rsp+0x30], xmm3
00007583d7bdb796  vmovaps [rsp+0x40], xmm4
00007583d7bdb79c  vmovaps [rsp+0x50], xmm5
00007583d7bdb7a2  vmovaps [rsp+0x60], xmm6
00007583d7bdb7a8  vmovaps [rsp+0x70], xmm7
00007583d7bdb7ae  vmovaps [rsp+0x80], xmm8
00007583d7bdb7b7  vmovaps [rsp+0x90], xmm9
00007583d7bdb7c0  vmovaps [rsp+0xA0], xmm10
00007583d7bdb7c9  vmovaps [rsp+0xB0], xmm11
00007583d7bdb7d2  vmovaps [rsp+0xC0], xmm13
00007583d7bdb7db  vmovaps [rsp+0xD0], xmm14
00007583d7bdb7e4  vmovaps [rsp+0xE0], xmm15
00007583d7bdb7ed  sub rsp, 0x40
00007583d7bdb7f1  lea rdi, [rsp]
00007583d7bdb7f5  lea rsi, [rsp+0x10]
00007583d7bdb7fa  lea rdx, [rsp+0x20]
00007583d7bdb7ff  lea rcx, [rsp+0x30]
00007583d7bdb804  mov r8d, 0x00
00007583d7bdb80a  lea r9, [r15+0x3A8]
00007583d7bdb811  movaps [rdi], xmm12
00007583d7bdb815  movaps [rsi], xmm3
00007583d7bdb818  movaps [rdx], xmm14
00007583d7bdb81c  movaps [rcx], xmm5
00007583d7bdb81f  mov rax, 0x5BCB7EA35A50
00007583d7bdb829  call rax
00007583d7bdb82b  movaps xmm12, [rsp]
00007583d7bdb830  add rsp, 0x40
00007583d7bdb834  vmovaps xmm0, [rsp]
00007583d7bdb839  vmovaps xmm1, [rsp+0x10]
00007583d7bdb83f  vmovaps xmm2, [rsp+0x20]
00007583d7bdb845  vmovaps xmm3, [rsp+0x30]
00007583d7bdb84b  vmovaps xmm4, [rsp+0x40]
00007583d7bdb851  vmovaps xmm5, [rsp+0x50]
00007583d7bdb857  vmovaps xmm6, [rsp+0x60]
00007583d7bdb85d  vmovaps xmm7, [rsp+0x70]
00007583d7bdb863  vmovaps xmm8, [rsp+0x80]
00007583d7bdb86c  vmovaps xmm9, [rsp+0x90]
00007583d7bdb875  vmovaps xmm10, [rsp+0xA0]
00007583d7bdb87e  vmovaps xmm11, [rsp+0xB0]
00007583d7bdb887  vmovaps xmm13, [rsp+0xC0]
00007583d7bdb890  vmovaps xmm14, [rsp+0xD0]
00007583d7bdb899  vmovaps xmm15, [rsp+0xE0]
00007583d7bdb8a2  add rsp, 0xF0
00007583d7bdb8a9  pop r11
00007583d7bdb8ab  pop r10
00007583d7bdb8ad  pop r9
00007583d7bdb8af  pop r8
00007583d7bdb8b1  pop rsi
00007583d7bdb8b2  pop rdi
00007583d7bdb8b3  pop rdx
00007583d7bdb8b4  pop rcx
00007583d7bdb8b5  pop rax
00007583d7bdb8b6  add rsp, 0x08
00007583d7bdb8ba  jmp 0x00007583D7BDA256
00007583d7bdb8bf  sub rsp, 0x08
00007583d7bdb8c3  push rax
00007583d7bdb8c4  push rcx
00007583d7bdb8c5  push rdx
00007583d7bdb8c6  push rdi
00007583d7bdb8c7  push rsi
00007583d7bdb8c8  push r8
00007583d7bdb8ca  push r9
00007583d7bdb8cc  push r10
00007583d7bdb8ce  push r11
00007583d7bdb8d0  sub rsp, 0xF0
00007583d7bdb8d7  vmovaps [rsp], xmm0
00007583d7bdb8dc  vmovaps [rsp+0x10], xmm1
00007583d7bdb8e2  vmovaps [rsp+0x20], xmm2
00007583d7bdb8e8  vmovaps [rsp+0x30], xmm3
00007583d7bdb8ee  vmovaps [rsp+0x40], xmm4
00007583d7bdb8f4  vmovaps [rsp+0x50], xmm5
00007583d7bdb8fa  vmovaps [rsp+0x60], xmm6
00007583d7bdb900  vmovaps [rsp+0x70], xmm7
00007583d7bdb906  vmovaps [rsp+0x80], xmm8
00007583d7bdb90f  vmovaps [rsp+0x90], xmm9
00007583d7bdb918  vmovaps [rsp+0xA0], xmm11
00007583d7bdb921  vmovaps [rsp+0xB0], xmm12
00007583d7bdb92a  vmovaps [rsp+0xC0], xmm13
00007583d7bdb933  vmovaps [rsp+0xD0], xmm14
00007583d7bdb93c  vmovaps [rsp+0xE0], xmm15
00007583d7bdb945  sub rsp, 0x40
00007583d7bdb949  lea rdi, [rsp]
00007583d7bdb94d  lea rsi, [rsp+0x10]
00007583d7bdb952  lea rdx, [rsp+0x20]
00007583d7bdb957  lea rcx, [rsp+0x30]
00007583d7bdb95c  mov r8d, 0x00
00007583d7bdb962  lea r9, [r15+0x3A8]
00007583d7bdb969  movaps [rdi], xmm10
00007583d7bdb96d  movaps [rsi], xmm9
00007583d7bdb971  movaps [rdx], xmm7
00007583d7bdb974  movaps [rcx], xmm14
00007583d7bdb978  mov rax, 0x5BCB7EA35A50
00007583d7bdb982  call rax
00007583d7bdb984  movaps xmm10, [rsp]
00007583d7bdb989  add rsp, 0x40
00007583d7bdb98d  vmovaps xmm0, [rsp]
00007583d7bdb992  vmovaps xmm1, [rsp+0x10]
00007583d7bdb998  vmovaps xmm2, [rsp+0x20]
00007583d7bdb99e  vmovaps xmm3, [rsp+0x30]
00007583d7bdb9a4  vmovaps xmm4, [rsp+0x40]
00007583d7bdb9aa  vmovaps xmm5, [rsp+0x50]
00007583d7bdb9b0  vmovaps xmm6, [rsp+0x60]
00007583d7bdb9b6  vmovaps xmm7, [rsp+0x70]
00007583d7bdb9bc  vmovaps xmm8, [rsp+0x80]
00007583d7bdb9c5  vmovaps xmm9, [rsp+0x90]
00007583d7bdb9ce  vmovaps xmm11, [rsp+0xA0]
00007583d7bdb9d7  vmovaps xmm12, [rsp+0xB0]
00007583d7bdb9e0  vmovaps xmm13, [rsp+0xC0]
00007583d7bdb9e9  vmovaps xmm14, [rsp+0xD0]
00007583d7bdb9f2  vmovaps xmm15, [rsp+0xE0]
00007583d7bdb9fb  add rsp, 0xF0
00007583d7bdba02  pop r11
00007583d7bdba04  pop r10
00007583d7bdba06  pop r9
00007583d7bdba08  pop r8
00007583d7bdba0a  pop rsi
00007583d7bdba0b  pop rdi
00007583d7bdba0c  pop rdx
00007583d7bdba0d  pop rcx
00007583d7bdba0e  pop rax
00007583d7bdba0f  add rsp, 0x08
00007583d7bdba13  jmp 0x00007583D7BDA27C
00007583d7bdba18  call 0x00007583D7A0D4E0
00007583d7bdba1d  jmp 0x00007583D7BDA289
00007583d7bdba22  sub rsp, 0x08
00007583d7bdba26  push rax
00007583d7bdba27  push rcx
00007583d7bdba28  push rdx
00007583d7bdba29  push rdi
00007583d7bdba2a  push rsi
00007583d7bdba2b  push r8
00007583d7bdba2d  push r9
00007583d7bdba2f  push r10
00007583d7bdba31  push r11
00007583d7bdba33  sub rsp, 0xF0
00007583d7bdba3a  vmovaps [rsp], xmm0
00007583d7bdba3f  vmovaps [rsp+0x10], xmm1
00007583d7bdba45  vmovaps [rsp+0x20], xmm2
00007583d7bdba4b  vmovaps [rsp+0x30], xmm3
00007583d7bdba51  vmovaps [rsp+0x40], xmm4
00007583d7bdba57  vmovaps [rsp+0x50], xmm6
00007583d7bdba5d  vmovaps [rsp+0x60], xmm7
00007583d7bdba63  vmovaps [rsp+0x70], xmm8
00007583d7bdba69  vmovaps [rsp+0x80], xmm9
00007583d7bdba72  vmovaps [rsp+0x90], xmm10
00007583d7bdba7b  vmovaps [rsp+0xA0], xmm11
00007583d7bdba84  vmovaps [rsp+0xB0], xmm12
00007583d7bdba8d  vmovaps [rsp+0xC0], xmm13
00007583d7bdba96  vmovaps [rsp+0xD0], xmm14
00007583d7bdba9f  vmovaps [rsp+0xE0], xmm15
00007583d7bdbaa8  sub rsp, 0x40
00007583d7bdbaac  lea rdi, [rsp]
00007583d7bdbab0  lea rsi, [rsp+0x10]
00007583d7bdbab5  lea rdx, [rsp+0x20]
00007583d7bdbaba  lea rcx, [rsp+0x30]
00007583d7bdbabf  mov r8d, 0x00
00007583d7bdbac5  lea r9, [r15+0x3A8]
00007583d7bdbacc  movaps [rdi], xmm5
00007583d7bdbacf  movaps [rsi], xmm6
00007583d7bdbad2  movaps [rdx], xmm7
00007583d7bdbad5  movaps [rcx], xmm9
00007583d7bdbad9  mov rax, 0x5BCB7EA35A50
00007583d7bdbae3  call rax
00007583d7bdbae5  movaps xmm5, [rsp]
00007583d7bdbae9  add rsp, 0x40
00007583d7bdbaed  vmovaps xmm0, [rsp]
00007583d7bdbaf2  vmovaps xmm1, [rsp+0x10]
00007583d7bdbaf8  vmovaps xmm2, [rsp+0x20]
00007583d7bdbafe  vmovaps xmm3, [rsp+0x30]
00007583d7bdbb04  vmovaps xmm4, [rsp+0x40]
00007583d7bdbb0a  vmovaps xmm6, [rsp+0x50]
00007583d7bdbb10  vmovaps xmm7, [rsp+0x60]
00007583d7bdbb16  vmovaps xmm8, [rsp+0x70]
00007583d7bdbb1c  vmovaps xmm9, [rsp+0x80]
00007583d7bdbb25  vmovaps xmm10, [rsp+0x90]
00007583d7bdbb2e  vmovaps xmm11, [rsp+0xA0]
00007583d7bdbb37  vmovaps xmm12, [rsp+0xB0]
00007583d7bdbb40  vmovaps xmm13, [rsp+0xC0]
00007583d7bdbb49  vmovaps xmm14, [rsp+0xD0]
00007583d7bdbb52  vmovaps xmm15, [rsp+0xE0]
00007583d7bdbb5b  add rsp, 0xF0
00007583d7bdbb62  pop r11
00007583d7bdbb64  pop r10
00007583d7bdbb66  pop r9
00007583d7bdbb68  pop r8
00007583d7bdbb6a  pop rsi
00007583d7bdbb6b  pop rdi
00007583d7bdbb6c  pop rdx
00007583d7bdbb6d  pop rcx
00007583d7bdbb6e  pop rax
00007583d7bdbb6f  add rsp, 0x08
00007583d7bdbb73  jmp 0x00007583D7BDA2BB
00007583d7bdbb78  sub rsp, 0x08
00007583d7bdbb7c  push rax
00007583d7bdbb7d  push rcx
00007583d7bdbb7e  push rdx
00007583d7bdbb7f  push rdi
00007583d7bdbb80  push rsi
00007583d7bdbb81  push r8
00007583d7bdbb83  push r9
00007583d7bdbb85  push r10
00007583d7bdbb87  push r11
00007583d7bdbb89  sub rsp, 0xF0
00007583d7bdbb90  vmovaps [rsp], xmm0
00007583d7bdbb95  vmovaps [rsp+0x10], xmm1
00007583d7bdbb9b  vmovaps [rsp+0x20], xmm2
00007583d7bdbba1  vmovaps [rsp+0x30], xmm3
00007583d7bdbba7  vmovaps [rsp+0x40], xmm4
00007583d7bdbbad  vmovaps [rsp+0x50], xmm5
00007583d7bdbbb3  vmovaps [rsp+0x60], xmm6
00007583d7bdbbb9  vmovaps [rsp+0x70], xmm8
00007583d7bdbbbf  vmovaps [rsp+0x80], xmm9
00007583d7bdbbc8  vmovaps [rsp+0x90], xmm10
00007583d7bdbbd1  vmovaps [rsp+0xA0], xmm11
00007583d7bdbbda  vmovaps [rsp+0xB0], xmm12
00007583d7bdbbe3  vmovaps [rsp+0xC0], xmm13
00007583d7bdbbec  vmovaps [rsp+0xD0], xmm14
00007583d7bdbbf5  vmovaps [rsp+0xE0], xmm15
00007583d7bdbbfe  sub rsp, 0x40
00007583d7bdbc02  lea rdi, [rsp]
00007583d7bdbc06  lea rsi, [rsp+0x10]
00007583d7bdbc0b  lea rdx, [rsp+0x20]
00007583d7bdbc10  lea rcx, [rsp+0x30]
00007583d7bdbc15  mov r8d, 0x00
00007583d7bdbc1b  lea r9, [r15+0x3A8]
00007583d7bdbc22  movaps [rdi], xmm7
00007583d7bdbc25  movaps [rsi], xmm13
00007583d7bdbc29  movaps [rdx], xmm1
00007583d7bdbc2c  movaps [rcx], xmm9
00007583d7bdbc30  mov rax, 0x5BCB7EA35A50
00007583d7bdbc3a  call rax
00007583d7bdbc3c  movaps xmm7, [rsp]
00007583d7bdbc40  add rsp, 0x40
00007583d7bdbc44  vmovaps xmm0, [rsp]
00007583d7bdbc49  vmovaps xmm1, [rsp+0x10]
00007583d7bdbc4f  vmovaps xmm2, [rsp+0x20]
00007583d7bdbc55  vmovaps xmm3, [rsp+0x30]
00007583d7bdbc5b  vmovaps xmm4, [rsp+0x40]
00007583d7bdbc61  vmovaps xmm5, [rsp+0x50]
00007583d7bdbc67  vmovaps xmm6, [rsp+0x60]
00007583d7bdbc6d  vmovaps xmm8, [rsp+0x70]
00007583d7bdbc73  vmovaps xmm9, [rsp+0x80]
00007583d7bdbc7c  vmovaps xmm10, [rsp+0x90]
00007583d7bdbc85  vmovaps xmm11, [rsp+0xA0]
00007583d7bdbc8e  vmovaps xmm12, [rsp+0xB0]
00007583d7bdbc97  vmovaps xmm13, [rsp+0xC0]
00007583d7bdbca0  vmovaps xmm14, [rsp+0xD0]
00007583d7bdbca9  vmovaps xmm15, [rsp+0xE0]
00007583d7bdbcb2  add rsp, 0xF0
00007583d7bdbcb9  pop r11
00007583d7bdbcbb  pop r10
00007583d7bdbcbd  pop r9
00007583d7bdbcbf  pop r8
00007583d7bdbcc1  pop rsi
00007583d7bdbcc2  pop rdi
00007583d7bdbcc3  pop rdx
00007583d7bdbcc4  pop rcx
00007583d7bdbcc5  pop rax
00007583d7bdbcc6  add rsp, 0x08
00007583d7bdbcca  jmp 0x00007583D7BDA2E0
00007583d7bdbccf  call 0x00007583D7A0C260
00007583d7bdbcd4  jmp 0x00007583D7BDA303
00007583d7bdbcd9  call 0x00007583D7A07890
00007583d7bdbcde  jmp 0x00007583D7BDA30D
00007583d7bdbce3  sub rsp, 0x08
00007583d7bdbce7  push rax
00007583d7bdbce8  push rcx
00007583d7bdbce9  push rdx
00007583d7bdbcea  push rdi
00007583d7bdbceb  push rsi
00007583d7bdbcec  push r8
00007583d7bdbcee  push r9
00007583d7bdbcf0  push r10
00007583d7bdbcf2  push r11
00007583d7bdbcf4  sub rsp, 0xF0
00007583d7bdbcfb  vmovaps [rsp], xmm0
00007583d7bdbd00  vmovaps [rsp+0x10], xmm1
00007583d7bdbd06  vmovaps [rsp+0x20], xmm3
00007583d7bdbd0c  vmovaps [rsp+0x30], xmm4
00007583d7bdbd12  vmovaps [rsp+0x40], xmm5
00007583d7bdbd18  vmovaps [rsp+0x50], xmm6
00007583d7bdbd1e  vmovaps [rsp+0x60], xmm7
00007583d7bdbd24  vmovaps [rsp+0x70], xmm8
00007583d7bdbd2a  vmovaps [rsp+0x80], xmm9
00007583d7bdbd33  vmovaps [rsp+0x90], xmm10
00007583d7bdbd3c  vmovaps [rsp+0xA0], xmm11
00007583d7bdbd45  vmovaps [rsp+0xB0], xmm12
00007583d7bdbd4e  vmovaps [rsp+0xC0], xmm13
00007583d7bdbd57  vmovaps [rsp+0xD0], xmm14
00007583d7bdbd60  vmovaps [rsp+0xE0], xmm15
00007583d7bdbd69  sub rsp, 0x40
00007583d7bdbd6d  lea rdi, [rsp]
00007583d7bdbd71  lea rsi, [rsp+0x10]
00007583d7bdbd76  lea rdx, [rsp+0x20]
00007583d7bdbd7b  lea rcx, [rsp+0x30]
00007583d7bdbd80  mov r8d, 0x00
00007583d7bdbd86  lea r9, [r15+0x3A8]
00007583d7bdbd8d  movaps [rdi], xmm2
00007583d7bdbd90  movaps [rsi], xmm12
00007583d7bdbd94  movaps [rdx], xmm6
00007583d7bdbd97  movaps [rcx], xmm3
00007583d7bdbd9a  mov rax, 0x5BCB7EA35A50
00007583d7bdbda4  call rax
00007583d7bdbda6  movaps xmm2, [rsp]
00007583d7bdbdaa  add rsp, 0x40
00007583d7bdbdae  vmovaps xmm0, [rsp]
00007583d7bdbdb3  vmovaps xmm1, [rsp+0x10]
00007583d7bdbdb9  vmovaps xmm3, [rsp+0x20]
00007583d7bdbdbf  vmovaps xmm4, [rsp+0x30]
00007583d7bdbdc5  vmovaps xmm5, [rsp+0x40]
00007583d7bdbdcb  vmovaps xmm6, [rsp+0x50]
00007583d7bdbdd1  vmovaps xmm7, [rsp+0x60]
00007583d7bdbdd7  vmovaps xmm8, [rsp+0x70]
00007583d7bdbddd  vmovaps xmm9, [rsp+0x80]
00007583d7bdbde6  vmovaps xmm10, [rsp+0x90]
00007583d7bdbdef  vmovaps xmm11, [rsp+0xA0]
00007583d7bdbdf8  vmovaps xmm12, [rsp+0xB0]
00007583d7bdbe01  vmovaps xmm13, [rsp+0xC0]
00007583d7bdbe0a  vmovaps xmm14, [rsp+0xD0]
00007583d7bdbe13  vmovaps xmm15, [rsp+0xE0]
00007583d7bdbe1c  add rsp, 0xF0
00007583d7bdbe23  pop r11
00007583d7bdbe25  pop r10
00007583d7bdbe27  pop r9
00007583d7bdbe29  pop r8
00007583d7bdbe2b  pop rsi
00007583d7bdbe2c  pop rdi
00007583d7bdbe2d  pop rdx
00007583d7bdbe2e  pop rcx
00007583d7bdbe2f  pop rax
00007583d7bdbe30  add rsp, 0x08
00007583d7bdbe34  jmp 0x00007583D7BDA353
00007583d7bdbe39  sub rsp, 0x08
00007583d7bdbe3d  push rax
00007583d7bdbe3e  push rcx
00007583d7bdbe3f  push rdx
00007583d7bdbe40  push rdi
00007583d7bdbe41  push rsi
00007583d7bdbe42  push r8
00007583d7bdbe44  push r9
00007583d7bdbe46  push r10
00007583d7bdbe48  push r11
00007583d7bdbe4a  sub rsp, 0xF0
00007583d7bdbe51  vmovaps [rsp], xmm0
00007583d7bdbe56  vmovaps [rsp+0x10], xmm1
00007583d7bdbe5c  vmovaps [rsp+0x20], xmm2
00007583d7bdbe62  vmovaps [rsp+0x30], xmm3
00007583d7bdbe68  vmovaps [rsp+0x40], xmm4
00007583d7bdbe6e  vmovaps [rsp+0x50], xmm5
00007583d7bdbe74  vmovaps [rsp+0x60], xmm7
00007583d7bdbe7a  vmovaps [rsp+0x70], xmm8
00007583d7bdbe80  vmovaps [rsp+0x80], xmm9
00007583d7bdbe89  vmovaps [rsp+0x90], xmm10
00007583d7bdbe92  vmovaps [rsp+0xA0], xmm11
00007583d7bdbe9b  vmovaps [rsp+0xB0], xmm12
00007583d7bdbea4  vmovaps [rsp+0xC0], xmm13
00007583d7bdbead  vmovaps [rsp+0xD0], xmm14
00007583d7bdbeb6  vmovaps [rsp+0xE0], xmm15
00007583d7bdbebf  sub rsp, 0x40
00007583d7bdbec3  lea rdi, [rsp]
00007583d7bdbec7  lea rsi, [rsp+0x10]
00007583d7bdbecc  lea rdx, [rsp+0x20]
00007583d7bdbed1  lea rcx, [rsp+0x30]
00007583d7bdbed6  mov r8d, 0x00
00007583d7bdbedc  lea r9, [r15+0x3A8]
00007583d7bdbee3  movaps [rdi], xmm6
00007583d7bdbee6  movaps [rsi], xmm10
00007583d7bdbeea  movaps [rdx], xmm12
00007583d7bdbeee  movaps [rcx], xmm1
00007583d7bdbef1  mov rax, 0x5BCB7EA35A50
00007583d7bdbefb  call rax
00007583d7bdbefd  movaps xmm6, [rsp]
00007583d7bdbf01  add rsp, 0x40
00007583d7bdbf05  vmovaps xmm0, [rsp]
00007583d7bdbf0a  vmovaps xmm1, [rsp+0x10]
00007583d7bdbf10  vmovaps xmm2, [rsp+0x20]
00007583d7bdbf16  vmovaps xmm3, [rsp+0x30]
00007583d7bdbf1c  vmovaps xmm4, [rsp+0x40]
00007583d7bdbf22  vmovaps xmm5, [rsp+0x50]
00007583d7bdbf28  vmovaps xmm7, [rsp+0x60]
00007583d7bdbf2e  vmovaps xmm8, [rsp+0x70]
00007583d7bdbf34  vmovaps xmm9, [rsp+0x80]
00007583d7bdbf3d  vmovaps xmm10, [rsp+0x90]
00007583d7bdbf46  vmovaps xmm11, [rsp+0xA0]
00007583d7bdbf4f  vmovaps xmm12, [rsp+0xB0]
00007583d7bdbf58  vmovaps xmm13, [rsp+0xC0]
00007583d7bdbf61  vmovaps xmm14, [rsp+0xD0]
00007583d7bdbf6a  vmovaps xmm15, [rsp+0xE0]
00007583d7bdbf73  add rsp, 0xF0
00007583d7bdbf7a  pop r11
00007583d7bdbf7c  pop r10
00007583d7bdbf7e  pop r9
00007583d7bdbf80  pop r8
00007583d7bdbf82  pop rsi
00007583d7bdbf83  pop rdi
00007583d7bdbf84  pop rdx
00007583d7bdbf85  pop rcx
00007583d7bdbf86  pop rax
00007583d7bdbf87  add rsp, 0x08
00007583d7bdbf8b  jmp 0x00007583D7BDA381
00007583d7bdbf90  sub rsp, 0x08
00007583d7bdbf94  push rax
00007583d7bdbf95  push rcx
00007583d7bdbf96  push rdx
00007583d7bdbf97  push rdi
00007583d7bdbf98  push rsi
00007583d7bdbf99  push r8
00007583d7bdbf9b  push r9
00007583d7bdbf9d  push r10
00007583d7bdbf9f  push r11
00007583d7bdbfa1  sub rsp, 0xF0
00007583d7bdbfa8  vmovaps [rsp], xmm0
00007583d7bdbfad  vmovaps [rsp+0x10], xmm1
00007583d7bdbfb3  vmovaps [rsp+0x20], xmm2
00007583d7bdbfb9  vmovaps [rsp+0x30], xmm3
00007583d7bdbfbf  vmovaps [rsp+0x40], xmm4
00007583d7bdbfc5  vmovaps [rsp+0x50], xmm5
00007583d7bdbfcb  vmovaps [rsp+0x60], xmm6
00007583d7bdbfd1  vmovaps [rsp+0x70], xmm7
00007583d7bdbfd7  vmovaps [rsp+0x80], xmm8
00007583d7bdbfe0  vmovaps [rsp+0x90], xmm9
00007583d7bdbfe9  vmovaps [rsp+0xA0], xmm11
00007583d7bdbff2  vmovaps [rsp+0xB0], xmm12
00007583d7bdbffb  vmovaps [rsp+0xC0], xmm13
00007583d7bdc004  vmovaps [rsp+0xD0], xmm14
00007583d7bdc00d  vmovaps [rsp+0xE0], xmm15
00007583d7bdc016  sub rsp, 0x40
00007583d7bdc01a  lea rdi, [rsp]
00007583d7bdc01e  lea rsi, [rsp+0x10]
00007583d7bdc023  lea rdx, [rsp+0x20]
00007583d7bdc028  lea rcx, [rsp+0x30]
00007583d7bdc02d  mov r8d, 0x00
00007583d7bdc033  lea r9, [r15+0x3A8]
00007583d7bdc03a  movaps [rdi], xmm10
00007583d7bdc03e  movaps [rsi], xmm5
00007583d7bdc041  movaps [rdx], xmm12
00007583d7bdc045  movaps [rcx], xmm1
00007583d7bdc048  mov rax, 0x5BCB7EA35A50
00007583d7bdc052  call rax
00007583d7bdc054  movaps xmm10, [rsp]
00007583d7bdc059  add rsp, 0x40
00007583d7bdc05d  vmovaps xmm0, [rsp]
00007583d7bdc062  vmovaps xmm1, [rsp+0x10]
00007583d7bdc068  vmovaps xmm2, [rsp+0x20]
00007583d7bdc06e  vmovaps xmm3, [rsp+0x30]
00007583d7bdc074  vmovaps xmm4, [rsp+0x40]
00007583d7bdc07a  vmovaps xmm5, [rsp+0x50]
00007583d7bdc080  vmovaps xmm6, [rsp+0x60]
00007583d7bdc086  vmovaps xmm7, [rsp+0x70]
00007583d7bdc08c  vmovaps xmm8, [rsp+0x80]
00007583d7bdc095  vmovaps xmm9, [rsp+0x90]
00007583d7bdc09e  vmovaps xmm11, [rsp+0xA0]
00007583d7bdc0a7  vmovaps xmm12, [rsp+0xB0]
00007583d7bdc0b0  vmovaps xmm13, [rsp+0xC0]
00007583d7bdc0b9  vmovaps xmm14, [rsp+0xD0]
00007583d7bdc0c2  vmovaps xmm15, [rsp+0xE0]
00007583d7bdc0cb  add rsp, 0xF0
00007583d7bdc0d2  pop r11
00007583d7bdc0d4  pop r10
00007583d7bdc0d6  pop r9
00007583d7bdc0d8  pop r8
00007583d7bdc0da  pop rsi
00007583d7bdc0db  pop rdi
00007583d7bdc0dc  pop rdx
00007583d7bdc0dd  pop rcx
00007583d7bdc0de  pop rax
00007583d7bdc0df  add rsp, 0x08
00007583d7bdc0e3  jmp 0x00007583D7BDA3B0
00007583d7bdc0e8  sub rsp, 0x08
00007583d7bdc0ec  push rax
00007583d7bdc0ed  push rcx
00007583d7bdc0ee  push rdx
00007583d7bdc0ef  push rdi
00007583d7bdc0f0  push rsi
00007583d7bdc0f1  push r8
00007583d7bdc0f3  push r9
00007583d7bdc0f5  push r10
00007583d7bdc0f7  push r11
00007583d7bdc0f9  sub rsp, 0xF0
00007583d7bdc100  vmovaps [rsp], xmm0
00007583d7bdc105  vmovaps [rsp+0x10], xmm1
00007583d7bdc10b  vmovaps [rsp+0x20], xmm2
00007583d7bdc111  vmovaps [rsp+0x30], xmm3
00007583d7bdc117  vmovaps [rsp+0x40], xmm4
00007583d7bdc11d  vmovaps [rsp+0x50], xmm5
00007583d7bdc123  vmovaps [rsp+0x60], xmm6
00007583d7bdc129  vmovaps [rsp+0x70], xmm7
00007583d7bdc12f  vmovaps [rsp+0x80], xmm8
00007583d7bdc138  vmovaps [rsp+0x90], xmm9
00007583d7bdc141  vmovaps [rsp+0xA0], xmm10
00007583d7bdc14a  vmovaps [rsp+0xB0], xmm11
00007583d7bdc153  vmovaps [rsp+0xC0], xmm13
00007583d7bdc15c  vmovaps [rsp+0xD0], xmm14
00007583d7bdc165  vmovaps [rsp+0xE0], xmm15
00007583d7bdc16e  sub rsp, 0x40
00007583d7bdc172  lea rdi, [rsp]
00007583d7bdc176  lea rsi, [rsp+0x10]
00007583d7bdc17b  lea rdx, [rsp+0x20]
00007583d7bdc180  lea rcx, [rsp+0x30]
00007583d7bdc185  mov r8d, 0x00
00007583d7bdc18b  lea r9, [r15+0x3A8]
00007583d7bdc192  movaps [rdi], xmm12
00007583d7bdc196  movaps [rsi], xmm7
00007583d7bdc199  movaps [rdx], xmm15
00007583d7bdc19d  movaps [rcx], xmm1
00007583d7bdc1a0  mov rax, 0x5BCB7EA35A50
00007583d7bdc1aa  call rax
00007583d7bdc1ac  movaps xmm12, [rsp]
00007583d7bdc1b1  add rsp, 0x40
00007583d7bdc1b5  vmovaps xmm0, [rsp]
00007583d7bdc1ba  vmovaps xmm1, [rsp+0x10]
00007583d7bdc1c0  vmovaps xmm2, [rsp+0x20]
00007583d7bdc1c6  vmovaps xmm3, [rsp+0x30]
00007583d7bdc1cc  vmovaps xmm4, [rsp+0x40]
00007583d7bdc1d2  vmovaps xmm5, [rsp+0x50]
00007583d7bdc1d8  vmovaps xmm6, [rsp+0x60]
00007583d7bdc1de  vmovaps xmm7, [rsp+0x70]
00007583d7bdc1e4  vmovaps xmm8, [rsp+0x80]
00007583d7bdc1ed  vmovaps xmm9, [rsp+0x90]
00007583d7bdc1f6  vmovaps xmm10, [rsp+0xA0]
00007583d7bdc1ff  vmovaps xmm11, [rsp+0xB0]
00007583d7bdc208  vmovaps xmm13, [rsp+0xC0]
00007583d7bdc211  vmovaps xmm14, [rsp+0xD0]
00007583d7bdc21a  vmovaps xmm15, [rsp+0xE0]
00007583d7bdc223  add rsp, 0xF0
00007583d7bdc22a  pop r11
00007583d7bdc22c  pop r10
00007583d7bdc22e  pop r9
00007583d7bdc230  pop r8
00007583d7bdc232  pop rsi
00007583d7bdc233  pop rdi
00007583d7bdc234  pop rdx
00007583d7bdc235  pop rcx
00007583d7bdc236  pop rax
00007583d7bdc237  add rsp, 0x08
00007583d7bdc23b  jmp 0x00007583D7BDA3D9
00007583d7bdc240  call 0x00007583D79FF430
00007583d7bdc245  jmp 0x00007583D7BDA3E3
00007583d7bdc24a  call 0x00007583D7A0E760
00007583d7bdc24f  jmp 0x00007583D7BDA3ED
00007583d7bdc254  sub rsp, 0x08
00007583d7bdc258  push rax
00007583d7bdc259  push rcx
00007583d7bdc25a  push rdx
00007583d7bdc25b  push rdi
00007583d7bdc25c  push rsi
00007583d7bdc25d  push r8
00007583d7bdc25f  push r9
00007583d7bdc261  push r10
00007583d7bdc263  push r11
00007583d7bdc265  sub rsp, 0xF0
00007583d7bdc26c  vmovaps [rsp], xmm0
00007583d7bdc271  vmovaps [rsp+0x10], xmm1
00007583d7bdc277  vmovaps [rsp+0x20], xmm2
00007583d7bdc27d  vmovaps [rsp+0x30], xmm3
00007583d7bdc283  vmovaps [rsp+0x40], xmm4
00007583d7bdc289  vmovaps [rsp+0x50], xmm5
00007583d7bdc28f  vmovaps [rsp+0x60], xmm6
00007583d7bdc295  vmovaps [rsp+0x70], xmm8
00007583d7bdc29b  vmovaps [rsp+0x80], xmm9
00007583d7bdc2a4  vmovaps [rsp+0x90], xmm10
00007583d7bdc2ad  vmovaps [rsp+0xA0], xmm11
00007583d7bdc2b6  vmovaps [rsp+0xB0], xmm12
00007583d7bdc2bf  vmovaps [rsp+0xC0], xmm13
00007583d7bdc2c8  vmovaps [rsp+0xD0], xmm14
00007583d7bdc2d1  vmovaps [rsp+0xE0], xmm15
00007583d7bdc2da  sub rsp, 0x40
00007583d7bdc2de  lea rdi, [rsp]
00007583d7bdc2e2  lea rsi, [rsp+0x10]
00007583d7bdc2e7  lea rdx, [rsp+0x20]
00007583d7bdc2ec  lea rcx, [rsp+0x30]
00007583d7bdc2f1  mov r8d, 0x00
00007583d7bdc2f7  lea r9, [r15+0x3A8]
00007583d7bdc2fe  movaps [rdi], xmm7
00007583d7bdc301  movaps [rsi], xmm2
00007583d7bdc304  movaps [rdx], xmm9
00007583d7bdc308  movaps [rcx], xmm11
00007583d7bdc30c  mov rax, 0x5BCB7EA35A50
00007583d7bdc316  call rax
00007583d7bdc318  movaps xmm7, [rsp]
00007583d7bdc31c  add rsp, 0x40
00007583d7bdc320  vmovaps xmm0, [rsp]
00007583d7bdc325  vmovaps xmm1, [rsp+0x10]
00007583d7bdc32b  vmovaps xmm2, [rsp+0x20]
00007583d7bdc331  vmovaps xmm3, [rsp+0x30]
00007583d7bdc337  vmovaps xmm4, [rsp+0x40]
00007583d7bdc33d  vmovaps xmm5, [rsp+0x50]
00007583d7bdc343  vmovaps xmm6, [rsp+0x60]
00007583d7bdc349  vmovaps xmm8, [rsp+0x70]
00007583d7bdc34f  vmovaps xmm9, [rsp+0x80]
00007583d7bdc358  vmovaps xmm10, [rsp+0x90]
00007583d7bdc361  vmovaps xmm11, [rsp+0xA0]
00007583d7bdc36a  vmovaps xmm12, [rsp+0xB0]
00007583d7bdc373  vmovaps xmm13, [rsp+0xC0]
00007583d7bdc37c  vmovaps xmm14, [rsp+0xD0]
00007583d7bdc385  vmovaps xmm15, [rsp+0xE0]
00007583d7bdc38e  add rsp, 0xF0
00007583d7bdc395  pop r11
00007583d7bdc397  pop r10
00007583d7bdc399  pop r9
00007583d7bdc39b  pop r8
00007583d7bdc39d  pop rsi
00007583d7bdc39e  pop rdi
00007583d7bdc39f  pop rdx
00007583d7bdc3a0  pop rcx
00007583d7bdc3a1  pop rax
00007583d7bdc3a2  add rsp, 0x08
00007583d7bdc3a6  jmp 0x00007583D7BDA421
00007583d7bdc3ab  sub rsp, 0x08
00007583d7bdc3af  push rax
00007583d7bdc3b0  push rcx
00007583d7bdc3b1  push rdx
00007583d7bdc3b2  push rdi
00007583d7bdc3b3  push rsi
00007583d7bdc3b4  push r8
00007583d7bdc3b6  push r9
00007583d7bdc3b8  push r10
00007583d7bdc3ba  push r11
00007583d7bdc3bc  sub rsp, 0xF0
00007583d7bdc3c3  vmovaps [rsp], xmm0
00007583d7bdc3c8  vmovaps [rsp+0x10], xmm1
00007583d7bdc3ce  vmovaps [rsp+0x20], xmm2
00007583d7bdc3d4  vmovaps [rsp+0x30], xmm3
00007583d7bdc3da  vmovaps [rsp+0x40], xmm4
00007583d7bdc3e0  vmovaps [rsp+0x50], xmm5
00007583d7bdc3e6  vmovaps [rsp+0x60], xmm6
00007583d7bdc3ec  vmovaps [rsp+0x70], xmm7
00007583d7bdc3f2  vmovaps [rsp+0x80], xmm8
00007583d7bdc3fb  vmovaps [rsp+0x90], xmm10
00007583d7bdc404  vmovaps [rsp+0xA0], xmm11
00007583d7bdc40d  vmovaps [rsp+0xB0], xmm12
00007583d7bdc416  vmovaps [rsp+0xC0], xmm13
00007583d7bdc41f  vmovaps [rsp+0xD0], xmm14
00007583d7bdc428  vmovaps [rsp+0xE0], xmm15
00007583d7bdc431  sub rsp, 0x40
00007583d7bdc435  lea rdi, [rsp]
00007583d7bdc439  lea rsi, [rsp+0x10]
00007583d7bdc43e  lea rdx, [rsp+0x20]
00007583d7bdc443  lea rcx, [rsp+0x30]
00007583d7bdc448  mov r8d, 0x00
00007583d7bdc44e  lea r9, [r15+0x3A8]
00007583d7bdc455  movaps [rdi], xmm9
00007583d7bdc459  movaps [rsi], xmm6
00007583d7bdc45c  movaps [rdx], xmm1
00007583d7bdc45f  movaps [rcx], xmm11
00007583d7bdc463  mov rax, 0x5BCB7EA35A50
00007583d7bdc46d  call rax
00007583d7bdc46f  movaps xmm9, [rsp]
00007583d7bdc474  add rsp, 0x40
00007583d7bdc478  vmovaps xmm0, [rsp]
00007583d7bdc47d  vmovaps xmm1, [rsp+0x10]
00007583d7bdc483  vmovaps xmm2, [rsp+0x20]
00007583d7bdc489  vmovaps xmm3, [rsp+0x30]
00007583d7bdc48f  vmovaps xmm4, [rsp+0x40]
00007583d7bdc495  vmovaps xmm5, [rsp+0x50]
00007583d7bdc49b  vmovaps xmm6, [rsp+0x60]
00007583d7bdc4a1  vmovaps xmm7, [rsp+0x70]
00007583d7bdc4a7  vmovaps xmm8, [rsp+0x80]
00007583d7bdc4b0  vmovaps xmm10, [rsp+0x90]
00007583d7bdc4b9  vmovaps xmm11, [rsp+0xA0]
00007583d7bdc4c2  vmovaps xmm12, [rsp+0xB0]
00007583d7bdc4cb  vmovaps xmm13, [rsp+0xC0]
00007583d7bdc4d4  vmovaps xmm14, [rsp+0xD0]
00007583d7bdc4dd  vmovaps xmm15, [rsp+0xE0]
00007583d7bdc4e6  add rsp, 0xF0
00007583d7bdc4ed  pop r11
00007583d7bdc4ef  pop r10
00007583d7bdc4f1  pop r9
00007583d7bdc4f3  pop r8
00007583d7bdc4f5  pop rsi
00007583d7bdc4f6  pop rdi
00007583d7bdc4f7  pop rdx
00007583d7bdc4f8  pop rcx
00007583d7bdc4f9  pop rax
00007583d7bdc4fa  add rsp, 0x08
00007583d7bdc4fe  jmp 0x00007583D7BDA447
00007583d7bdc503  sub rsp, 0x08
00007583d7bdc507  push rax
00007583d7bdc508  push rcx
00007583d7bdc509  push rdx
00007583d7bdc50a  push rdi
00007583d7bdc50b  push rsi
00007583d7bdc50c  push r8
00007583d7bdc50e  push r9
00007583d7bdc510  push r10
00007583d7bdc512  push r11
00007583d7bdc514  sub rsp, 0xF0
00007583d7bdc51b  vmovaps [rsp], xmm0
00007583d7bdc520  vmovaps [rsp+0x10], xmm1
00007583d7bdc526  vmovaps [rsp+0x20], xmm2
00007583d7bdc52c  vmovaps [rsp+0x30], xmm3
00007583d7bdc532  vmovaps [rsp+0x40], xmm4
00007583d7bdc538  vmovaps [rsp+0x50], xmm5
00007583d7bdc53e  vmovaps [rsp+0x60], xmm6
00007583d7bdc544  vmovaps [rsp+0x70], xmm7
00007583d7bdc54a  vmovaps [rsp+0x80], xmm8
00007583d7bdc553  vmovaps [rsp+0x90], xmm9
00007583d7bdc55c  vmovaps [rsp+0xA0], xmm10
00007583d7bdc565  vmovaps [rsp+0xB0], xmm12
00007583d7bdc56e  vmovaps [rsp+0xC0], xmm13
00007583d7bdc577  vmovaps [rsp+0xD0], xmm14
00007583d7bdc580  vmovaps [rsp+0xE0], xmm15
00007583d7bdc589  sub rsp, 0x40
00007583d7bdc58d  lea rdi, [rsp]
00007583d7bdc591  lea rsi, [rsp+0x10]
00007583d7bdc596  lea rdx, [rsp+0x20]
00007583d7bdc59b  lea rcx, [rsp+0x30]
00007583d7bdc5a0  mov r8d, 0x00
00007583d7bdc5a6  lea r9, [r15+0x3A8]
00007583d7bdc5ad  movaps [rdi], xmm11
00007583d7bdc5b1  movaps [rsi], xmm10
00007583d7bdc5b5  movaps [rdx], xmm8
00007583d7bdc5b9  movaps [rcx], xmm1
00007583d7bdc5bc  mov rax, 0x5BCB7EA35A50
00007583d7bdc5c6  call rax
00007583d7bdc5c8  movaps xmm11, [rsp]
00007583d7bdc5cd  add rsp, 0x40
00007583d7bdc5d1  vmovaps xmm0, [rsp]
00007583d7bdc5d6  vmovaps xmm1, [rsp+0x10]
00007583d7bdc5dc  vmovaps xmm2, [rsp+0x20]
00007583d7bdc5e2  vmovaps xmm3, [rsp+0x30]
00007583d7bdc5e8  vmovaps xmm4, [rsp+0x40]
00007583d7bdc5ee  vmovaps xmm5, [rsp+0x50]
00007583d7bdc5f4  vmovaps xmm6, [rsp+0x60]
00007583d7bdc5fa  vmovaps xmm7, [rsp+0x70]
00007583d7bdc600  vmovaps xmm8, [rsp+0x80]
00007583d7bdc609  vmovaps xmm9, [rsp+0x90]
00007583d7bdc612  vmovaps xmm10, [rsp+0xA0]
00007583d7bdc61b  vmovaps xmm12, [rsp+0xB0]
00007583d7bdc624  vmovaps xmm13, [rsp+0xC0]
00007583d7bdc62d  vmovaps xmm14, [rsp+0xD0]
00007583d7bdc636  vmovaps xmm15, [rsp+0xE0]
00007583d7bdc63f  add rsp, 0xF0
00007583d7bdc646  pop r11
00007583d7bdc648  pop r10
00007583d7bdc64a  pop r9
00007583d7bdc64c  pop r8
00007583d7bdc64e  pop rsi
00007583d7bdc64f  pop rdi
00007583d7bdc650  pop rdx
00007583d7bdc651  pop rcx
00007583d7bdc652  pop rax
00007583d7bdc653  add rsp, 0x08
00007583d7bdc657  jmp 0x00007583D7BDA46D
00007583d7bdc65c  sub rsp, 0x08
00007583d7bdc660  push rax
00007583d7bdc661  push rcx
00007583d7bdc662  push rdx
00007583d7bdc663  push rdi
00007583d7bdc664  push rsi
00007583d7bdc665  push r8
00007583d7bdc667  push r9
00007583d7bdc669  push r10
00007583d7bdc66b  push r11
00007583d7bdc66d  sub rsp, 0xF0
00007583d7bdc674  vmovaps [rsp], xmm0
00007583d7bdc679  vmovaps [rsp+0x10], xmm1
00007583d7bdc67f  vmovaps [rsp+0x20], xmm2
00007583d7bdc685  vmovaps [rsp+0x30], xmm3
00007583d7bdc68b  vmovaps [rsp+0x40], xmm4
00007583d7bdc691  vmovaps [rsp+0x50], xmm5
00007583d7bdc697  vmovaps [rsp+0x60], xmm6
00007583d7bdc69d  vmovaps [rsp+0x70], xmm7
00007583d7bdc6a3  vmovaps [rsp+0x80], xmm8
00007583d7bdc6ac  vmovaps [rsp+0x90], xmm9
00007583d7bdc6b5  vmovaps [rsp+0xA0], xmm11
00007583d7bdc6be  vmovaps [rsp+0xB0], xmm12
00007583d7bdc6c7  vmovaps [rsp+0xC0], xmm13
00007583d7bdc6d0  vmovaps [rsp+0xD0], xmm14
00007583d7bdc6d9  vmovaps [rsp+0xE0], xmm15
00007583d7bdc6e2  sub rsp, 0x40
00007583d7bdc6e6  lea rdi, [rsp]
00007583d7bdc6ea  lea rsi, [rsp+0x10]
00007583d7bdc6ef  lea rdx, [rsp+0x20]
00007583d7bdc6f4  lea rcx, [rsp+0x30]
00007583d7bdc6f9  mov r8d, 0x00
00007583d7bdc6ff  lea r9, [r15+0x3A8]
00007583d7bdc706  movaps [rdi], xmm10
00007583d7bdc70a  movaps [rsi], xmm12
00007583d7bdc70e  movaps [rdx], xmm13
00007583d7bdc712  movaps [rcx], xmm1
00007583d7bdc715  mov rax, 0x5BCB7EA35A50
00007583d7bdc71f  call rax
00007583d7bdc721  movaps xmm10, [rsp]
00007583d7bdc726  add rsp, 0x40
00007583d7bdc72a  vmovaps xmm0, [rsp]
00007583d7bdc72f  vmovaps xmm1, [rsp+0x10]
00007583d7bdc735  vmovaps xmm2, [rsp+0x20]
00007583d7bdc73b  vmovaps xmm3, [rsp+0x30]
00007583d7bdc741  vmovaps xmm4, [rsp+0x40]
00007583d7bdc747  vmovaps xmm5, [rsp+0x50]
00007583d7bdc74d  vmovaps xmm6, [rsp+0x60]
00007583d7bdc753  vmovaps xmm7, [rsp+0x70]
00007583d7bdc759  vmovaps xmm8, [rsp+0x80]
00007583d7bdc762  vmovaps xmm9, [rsp+0x90]
00007583d7bdc76b  vmovaps xmm11, [rsp+0xA0]
00007583d7bdc774  vmovaps xmm12, [rsp+0xB0]
00007583d7bdc77d  vmovaps xmm13, [rsp+0xC0]
00007583d7bdc786  vmovaps xmm14, [rsp+0xD0]
00007583d7bdc78f  vmovaps xmm15, [rsp+0xE0]
00007583d7bdc798  add rsp, 0xF0
00007583d7bdc79f  pop r11
00007583d7bdc7a1  pop r10
00007583d7bdc7a3  pop r9
00007583d7bdc7a5  pop r8
00007583d7bdc7a7  pop rsi
00007583d7bdc7a8  pop rdi
00007583d7bdc7a9  pop rdx
00007583d7bdc7aa  pop rcx
00007583d7bdc7ab  pop rax
00007583d7bdc7ac  add rsp, 0x08
00007583d7bdc7b0  jmp 0x00007583D7BDA493
00007583d7bdc7b5  call 0x00007583D79FF430
00007583d7bdc7ba  jmp 0x00007583D7BDA49D
00007583d7bdc7bf  call 0x00007583D7A0C260
00007583d7bdc7c4  jmp 0x00007583D7BDA4A7
00007583d7bdc7c9  sub rsp, 0x08
00007583d7bdc7cd  push rax
00007583d7bdc7ce  push rcx
00007583d7bdc7cf  push rdx
00007583d7bdc7d0  push rdi
00007583d7bdc7d1  push rsi
00007583d7bdc7d2  push r8
00007583d7bdc7d4  push r9
00007583d7bdc7d6  push r10
00007583d7bdc7d8  push r11
00007583d7bdc7da  sub rsp, 0xF0
00007583d7bdc7e1  vmovaps [rsp], xmm0
00007583d7bdc7e6  vmovaps [rsp+0x10], xmm1
00007583d7bdc7ec  vmovaps [rsp+0x20], xmm2
00007583d7bdc7f2  vmovaps [rsp+0x30], xmm3
00007583d7bdc7f8  vmovaps [rsp+0x40], xmm4
00007583d7bdc7fe  vmovaps [rsp+0x50], xmm5
00007583d7bdc804  vmovaps [rsp+0x60], xmm6
00007583d7bdc80a  vmovaps [rsp+0x70], xmm7
00007583d7bdc810  vmovaps [rsp+0x80], xmm9
00007583d7bdc819  vmovaps [rsp+0x90], xmm10
00007583d7bdc822  vmovaps [rsp+0xA0], xmm11
00007583d7bdc82b  vmovaps [rsp+0xB0], xmm12
00007583d7bdc834  vmovaps [rsp+0xC0], xmm13
00007583d7bdc83d  vmovaps [rsp+0xD0], xmm14
00007583d7bdc846  vmovaps [rsp+0xE0], xmm15
00007583d7bdc84f  sub rsp, 0x40
00007583d7bdc853  lea rdi, [rsp]
00007583d7bdc857  lea rsi, [rsp+0x10]
00007583d7bdc85c  lea rdx, [rsp+0x20]
00007583d7bdc861  lea rcx, [rsp+0x30]
00007583d7bdc866  mov r8d, 0x00
00007583d7bdc86c  lea r9, [r15+0x3A8]
00007583d7bdc873  movaps [rdi], xmm8
00007583d7bdc877  movaps [rsi], xmm7
00007583d7bdc87a  movaps [rdx], xmm4
00007583d7bdc87d  movaps [rcx], xmm12
00007583d7bdc881  mov rax, 0x5BCB7EA35A50
00007583d7bdc88b  call rax
00007583d7bdc88d  movaps xmm8, [rsp]
00007583d7bdc892  add rsp, 0x40
00007583d7bdc896  vmovaps xmm0, [rsp]
00007583d7bdc89b  vmovaps xmm1, [rsp+0x10]
00007583d7bdc8a1  vmovaps xmm2, [rsp+0x20]
00007583d7bdc8a7  vmovaps xmm3, [rsp+0x30]
00007583d7bdc8ad  vmovaps xmm4, [rsp+0x40]
00007583d7bdc8b3  vmovaps xmm5, [rsp+0x50]
00007583d7bdc8b9  vmovaps xmm6, [rsp+0x60]
00007583d7bdc8bf  vmovaps xmm7, [rsp+0x70]
00007583d7bdc8c5  vmovaps xmm9, [rsp+0x80]
00007583d7bdc8ce  vmovaps xmm10, [rsp+0x90]
00007583d7bdc8d7  vmovaps xmm11, [rsp+0xA0]
00007583d7bdc8e0  vmovaps xmm12, [rsp+0xB0]
00007583d7bdc8e9  vmovaps xmm13, [rsp+0xC0]
00007583d7bdc8f2  vmovaps xmm14, [rsp+0xD0]
00007583d7bdc8fb  vmovaps xmm15, [rsp+0xE0]
00007583d7bdc904  add rsp, 0xF0
00007583d7bdc90b  pop r11
00007583d7bdc90d  pop r10
00007583d7bdc90f  pop r9
00007583d7bdc911  pop r8
00007583d7bdc913  pop rsi
00007583d7bdc914  pop rdi
00007583d7bdc915  pop rdx
00007583d7bdc916  pop rcx
00007583d7bdc917  pop rax
00007583d7bdc918  add rsp, 0x08
00007583d7bdc91c  jmp 0x00007583D7BDA4D0
00007583d7bdc921  sub rsp, 0x08
00007583d7bdc925  push rax
00007583d7bdc926  push rcx
00007583d7bdc927  push rdx
00007583d7bdc928  push rdi
00007583d7bdc929  push rsi
00007583d7bdc92a  push r8
00007583d7bdc92c  push r9
00007583d7bdc92e  push r10
00007583d7bdc930  push r11
00007583d7bdc932  sub rsp, 0xF0
00007583d7bdc939  vmovaps [rsp], xmm0
00007583d7bdc93e  vmovaps [rsp+0x10], xmm1
00007583d7bdc944  vmovaps [rsp+0x20], xmm2
00007583d7bdc94a  vmovaps [rsp+0x30], xmm3
00007583d7bdc950  vmovaps [rsp+0x40], xmm4
00007583d7bdc956  vmovaps [rsp+0x50], xmm5
00007583d7bdc95c  vmovaps [rsp+0x60], xmm6
00007583d7bdc962  vmovaps [rsp+0x70], xmm8
00007583d7bdc968  vmovaps [rsp+0x80], xmm9
00007583d7bdc971  vmovaps [rsp+0x90], xmm10
00007583d7bdc97a  vmovaps [rsp+0xA0], xmm11
00007583d7bdc983  vmovaps [rsp+0xB0], xmm12
00007583d7bdc98c  vmovaps [rsp+0xC0], xmm13
00007583d7bdc995  vmovaps [rsp+0xD0], xmm14
00007583d7bdc99e  vmovaps [rsp+0xE0], xmm15
00007583d7bdc9a7  sub rsp, 0x40
00007583d7bdc9ab  lea rdi, [rsp]
00007583d7bdc9af  lea rsi, [rsp+0x10]
00007583d7bdc9b4  lea rdx, [rsp+0x20]
00007583d7bdc9b9  lea rcx, [rsp+0x30]
00007583d7bdc9be  mov r8d, 0x00
00007583d7bdc9c4  lea r9, [r15+0x3A8]
00007583d7bdc9cb  movaps [rdi], xmm7
00007583d7bdc9ce  movaps [rsi], xmm9
00007583d7bdc9d2  movaps [rdx], xmm14
00007583d7bdc9d6  movaps [rcx], xmm12
00007583d7bdc9da  mov rax, 0x5BCB7EA35A50
00007583d7bdc9e4  call rax
00007583d7bdc9e6  movaps xmm7, [rsp]
00007583d7bdc9ea  add rsp, 0x40
00007583d7bdc9ee  vmovaps xmm0, [rsp]
00007583d7bdc9f3  vmovaps xmm1, [rsp+0x10]
00007583d7bdc9f9  vmovaps xmm2, [rsp+0x20]
00007583d7bdc9ff  vmovaps xmm3, [rsp+0x30]
00007583d7bdca05  vmovaps xmm4, [rsp+0x40]
00007583d7bdca0b  vmovaps xmm5, [rsp+0x50]
00007583d7bdca11  vmovaps xmm6, [rsp+0x60]
00007583d7bdca17  vmovaps xmm8, [rsp+0x70]
00007583d7bdca1d  vmovaps xmm9, [rsp+0x80]
00007583d7bdca26  vmovaps xmm10, [rsp+0x90]
00007583d7bdca2f  vmovaps xmm11, [rsp+0xA0]
00007583d7bdca38  vmovaps xmm12, [rsp+0xB0]
00007583d7bdca41  vmovaps xmm13, [rsp+0xC0]
00007583d7bdca4a  vmovaps xmm14, [rsp+0xD0]
00007583d7bdca53  vmovaps xmm15, [rsp+0xE0]
00007583d7bdca5c  add rsp, 0xF0
00007583d7bdca63  pop r11
00007583d7bdca65  pop r10
00007583d7bdca67  pop r9
00007583d7bdca69  pop r8
00007583d7bdca6b  pop rsi
00007583d7bdca6c  pop rdi
00007583d7bdca6d  pop rdx
00007583d7bdca6e  pop rcx
00007583d7bdca6f  pop rax
00007583d7bdca70  add rsp, 0x08
00007583d7bdca74  jmp 0x00007583D7BDA4F8
00007583d7bdca79  sub rsp, 0x08
00007583d7bdca7d  push rax
00007583d7bdca7e  push rcx
00007583d7bdca7f  push rdx
00007583d7bdca80  push rdi
00007583d7bdca81  push rsi
00007583d7bdca82  push r8
00007583d7bdca84  push r9
00007583d7bdca86  push r10
00007583d7bdca88  push r11
00007583d7bdca8a  sub rsp, 0xF0
00007583d7bdca91  vmovaps [rsp], xmm0
00007583d7bdca96  vmovaps [rsp+0x10], xmm1
00007583d7bdca9c  vmovaps [rsp+0x20], xmm2
00007583d7bdcaa2  vmovaps [rsp+0x30], xmm3
00007583d7bdcaa8  vmovaps [rsp+0x40], xmm4
00007583d7bdcaae  vmovaps [rsp+0x50], xmm5
00007583d7bdcab4  vmovaps [rsp+0x60], xmm6
00007583d7bdcaba  vmovaps [rsp+0x70], xmm7
00007583d7bdcac0  vmovaps [rsp+0x80], xmm8
00007583d7bdcac9  vmovaps [rsp+0x90], xmm9
00007583d7bdcad2  vmovaps [rsp+0xA0], xmm10
00007583d7bdcadb  vmovaps [rsp+0xB0], xmm11
00007583d7bdcae4  vmovaps [rsp+0xC0], xmm13
00007583d7bdcaed  vmovaps [rsp+0xD0], xmm14
00007583d7bdcaf6  vmovaps [rsp+0xE0], xmm15
00007583d7bdcaff  sub rsp, 0x40
00007583d7bdcb03  lea rdi, [rsp]
00007583d7bdcb07  lea rsi, [rsp+0x10]
00007583d7bdcb0c  lea rdx, [rsp+0x20]
00007583d7bdcb11  lea rcx, [rsp+0x30]
00007583d7bdcb16  mov r8d, 0x00
00007583d7bdcb1c  lea r9, [r15+0x3A8]
00007583d7bdcb23  movaps [rdi], xmm12
00007583d7bdcb27  movaps [rsi], xmm11
00007583d7bdcb2b  movaps [rdx], xmm15
00007583d7bdcb2f  movaps [rcx], xmm14
00007583d7bdcb33  mov rax, 0x5BCB7EA35A50
00007583d7bdcb3d  call rax
00007583d7bdcb3f  movaps xmm12, [rsp]
00007583d7bdcb44  add rsp, 0x40
00007583d7bdcb48  vmovaps xmm0, [rsp]
00007583d7bdcb4d  vmovaps xmm1, [rsp+0x10]
00007583d7bdcb53  vmovaps xmm2, [rsp+0x20]
00007583d7bdcb59  vmovaps xmm3, [rsp+0x30]
00007583d7bdcb5f  vmovaps xmm4, [rsp+0x40]
00007583d7bdcb65  vmovaps xmm5, [rsp+0x50]
00007583d7bdcb6b  vmovaps xmm6, [rsp+0x60]
00007583d7bdcb71  vmovaps xmm7, [rsp+0x70]
00007583d7bdcb77  vmovaps xmm8, [rsp+0x80]
00007583d7bdcb80  vmovaps xmm9, [rsp+0x90]
00007583d7bdcb89  vmovaps xmm10, [rsp+0xA0]
00007583d7bdcb92  vmovaps xmm11, [rsp+0xB0]
00007583d7bdcb9b  vmovaps xmm13, [rsp+0xC0]
00007583d7bdcba4  vmovaps xmm14, [rsp+0xD0]
00007583d7bdcbad  vmovaps xmm15, [rsp+0xE0]
00007583d7bdcbb6  add rsp, 0xF0
00007583d7bdcbbd  pop r11
00007583d7bdcbbf  pop r10
00007583d7bdcbc1  pop r9
00007583d7bdcbc3  pop r8
00007583d7bdcbc5  pop rsi
00007583d7bdcbc6  pop rdi
00007583d7bdcbc7  pop rdx
00007583d7bdcbc8  pop rcx
00007583d7bdcbc9  pop rax
00007583d7bdcbca  add rsp, 0x08
00007583d7bdcbce  jmp 0x00007583D7BDA521
00007583d7bdcbd3  sub rsp, 0x08
00007583d7bdcbd7  push rax
00007583d7bdcbd8  push rcx
00007583d7bdcbd9  push rdx
00007583d7bdcbda  push rdi
00007583d7bdcbdb  push rsi
00007583d7bdcbdc  push r8
00007583d7bdcbde  push r9
00007583d7bdcbe0  push r10
00007583d7bdcbe2  push r11
00007583d7bdcbe4  sub rsp, 0xF0
00007583d7bdcbeb  vmovaps [rsp], xmm0
00007583d7bdcbf0  vmovaps [rsp+0x10], xmm1
00007583d7bdcbf6  vmovaps [rsp+0x20], xmm2
00007583d7bdcbfc  vmovaps [rsp+0x30], xmm3
00007583d7bdcc02  vmovaps [rsp+0x40], xmm4
00007583d7bdcc08  vmovaps [rsp+0x50], xmm5
00007583d7bdcc0e  vmovaps [rsp+0x60], xmm6
00007583d7bdcc14  vmovaps [rsp+0x70], xmm7
00007583d7bdcc1a  vmovaps [rsp+0x80], xmm8
00007583d7bdcc23  vmovaps [rsp+0x90], xmm9
00007583d7bdcc2c  vmovaps [rsp+0xA0], xmm10
00007583d7bdcc35  vmovaps [rsp+0xB0], xmm12
00007583d7bdcc3e  vmovaps [rsp+0xC0], xmm13
00007583d7bdcc47  vmovaps [rsp+0xD0], xmm14
00007583d7bdcc50  vmovaps [rsp+0xE0], xmm15
00007583d7bdcc59  sub rsp, 0x40
00007583d7bdcc5d  lea rdi, [rsp]
00007583d7bdcc61  lea rsi, [rsp+0x10]
00007583d7bdcc66  lea rdx, [rsp+0x20]
00007583d7bdcc6b  lea rcx, [rsp+0x30]
00007583d7bdcc70  mov r8d, 0x00
00007583d7bdcc76  lea r9, [r15+0x3A8]
00007583d7bdcc7d  movaps [rdi], xmm11
00007583d7bdcc81  movaps [rsi], xmm10
00007583d7bdcc85  movaps [rdx], xmm13
00007583d7bdcc89  movaps [rcx], xmm15
00007583d7bdcc8d  mov rax, 0x5BCB7EA35A50
00007583d7bdcc97  call rax
00007583d7bdcc99  movaps xmm11, [rsp]
00007583d7bdcc9e  add rsp, 0x40
00007583d7bdcca2  vmovaps xmm0, [rsp]
00007583d7bdcca7  vmovaps xmm1, [rsp+0x10]
00007583d7bdccad  vmovaps xmm2, [rsp+0x20]
00007583d7bdccb3  vmovaps xmm3, [rsp+0x30]
00007583d7bdccb9  vmovaps xmm4, [rsp+0x40]
00007583d7bdccbf  vmovaps xmm5, [rsp+0x50]
00007583d7bdccc5  vmovaps xmm6, [rsp+0x60]
00007583d7bdcccb  vmovaps xmm7, [rsp+0x70]
00007583d7bdccd1  vmovaps xmm8, [rsp+0x80]
00007583d7bdccda  vmovaps xmm9, [rsp+0x90]
00007583d7bdcce3  vmovaps xmm10, [rsp+0xA0]
00007583d7bdccec  vmovaps xmm12, [rsp+0xB0]
00007583d7bdccf5  vmovaps xmm13, [rsp+0xC0]
00007583d7bdccfe  vmovaps xmm14, [rsp+0xD0]
00007583d7bdcd07  vmovaps xmm15, [rsp+0xE0]
00007583d7bdcd10  add rsp, 0xF0
00007583d7bdcd17  pop r11
00007583d7bdcd19  pop r10
00007583d7bdcd1b  pop r9
00007583d7bdcd1d  pop r8
00007583d7bdcd1f  pop rsi
00007583d7bdcd20  pop rdi
00007583d7bdcd21  pop rdx
00007583d7bdcd22  pop rcx
00007583d7bdcd23  pop rax
00007583d7bdcd24  add rsp, 0x08
00007583d7bdcd28  jmp 0x00007583D7BDA54A
00007583d7bdcd2d  call 0x00007583D7A0E760
00007583d7bdcd32  jmp 0x00007583D7BDA557
00007583d7bdcd37  call 0x00007583D7A0D4E0
00007583d7bdcd3c  jmp 0x00007583D7BDA564
00007583d7bdcd41  sub rsp, 0x08
00007583d7bdcd45  push rax
00007583d7bdcd46  push rcx
00007583d7bdcd47  push rdx
00007583d7bdcd48  push rdi
00007583d7bdcd49  push rsi
00007583d7bdcd4a  push r8
00007583d7bdcd4c  push r9
00007583d7bdcd4e  push r10
00007583d7bdcd50  push r11
00007583d7bdcd52  sub rsp, 0xF0
00007583d7bdcd59  vmovaps [rsp], xmm0
00007583d7bdcd5e  vmovaps [rsp+0x10], xmm1
00007583d7bdcd64  vmovaps [rsp+0x20], xmm2
00007583d7bdcd6a  vmovaps [rsp+0x30], xmm3
00007583d7bdcd70  vmovaps [rsp+0x40], xmm4
00007583d7bdcd76  vmovaps [rsp+0x50], xmm5
00007583d7bdcd7c  vmovaps [rsp+0x60], xmm6
00007583d7bdcd82  vmovaps [rsp+0x70], xmm7
00007583d7bdcd88  vmovaps [rsp+0x80], xmm8
00007583d7bdcd91  vmovaps [rsp+0x90], xmm9
00007583d7bdcd9a  vmovaps [rsp+0xA0], xmm11
00007583d7bdcda3  vmovaps [rsp+0xB0], xmm12
00007583d7bdcdac  vmovaps [rsp+0xC0], xmm13
00007583d7bdcdb5  vmovaps [rsp+0xD0], xmm14
00007583d7bdcdbe  vmovaps [rsp+0xE0], xmm15
00007583d7bdcdc7  sub rsp, 0x40
00007583d7bdcdcb  lea rdi, [rsp]
00007583d7bdcdcf  lea rsi, [rsp+0x10]
00007583d7bdcdd4  lea rdx, [rsp+0x20]
00007583d7bdcdd9  lea rcx, [rsp+0x30]
00007583d7bdcdde  mov r8d, 0x00
00007583d7bdcde4  lea r9, [r15+0x3A8]
00007583d7bdcdeb  movaps [rdi], xmm10
00007583d7bdcdef  movaps [rsi], xmm8
00007583d7bdcdf3  movaps [rdx], xmm1
00007583d7bdcdf6  movaps [rcx], xmm13
00007583d7bdcdfa  mov rax, 0x5BCB7EA35A50
00007583d7bdce04  call rax
00007583d7bdce06  movaps xmm10, [rsp]
00007583d7bdce0b  add rsp, 0x40
00007583d7bdce0f  vmovaps xmm0, [rsp]
00007583d7bdce14  vmovaps xmm1, [rsp+0x10]
00007583d7bdce1a  vmovaps xmm2, [rsp+0x20]
00007583d7bdce20  vmovaps xmm3, [rsp+0x30]
00007583d7bdce26  vmovaps xmm4, [rsp+0x40]
00007583d7bdce2c  vmovaps xmm5, [rsp+0x50]
00007583d7bdce32  vmovaps xmm6, [rsp+0x60]
00007583d7bdce38  vmovaps xmm7, [rsp+0x70]
00007583d7bdce3e  vmovaps xmm8, [rsp+0x80]
00007583d7bdce47  vmovaps xmm9, [rsp+0x90]
00007583d7bdce50  vmovaps xmm11, [rsp+0xA0]
00007583d7bdce59  vmovaps xmm12, [rsp+0xB0]
00007583d7bdce62  vmovaps xmm13, [rsp+0xC0]
00007583d7bdce6b  vmovaps xmm14, [rsp+0xD0]
00007583d7bdce74  vmovaps xmm15, [rsp+0xE0]
00007583d7bdce7d  add rsp, 0xF0
00007583d7bdce84  pop r11
00007583d7bdce86  pop r10
00007583d7bdce88  pop r9
00007583d7bdce8a  pop r8
00007583d7bdce8c  pop rsi
00007583d7bdce8d  pop rdi
00007583d7bdce8e  pop rdx
00007583d7bdce8f  pop rcx
00007583d7bdce90  pop rax
00007583d7bdce91  add rsp, 0x08
00007583d7bdce95  jmp 0x00007583D7BDA59A
00007583d7bdce9a  call 0x00007583D79FF430
00007583d7bdce9f  jmp 0x00007583D7BDA5AC
00007583d7bdcea4  sub rsp, 0x08
00007583d7bdcea8  push rax
00007583d7bdcea9  push rcx
00007583d7bdceaa  push rdx
00007583d7bdceab  push rdi
00007583d7bdceac  push rsi
00007583d7bdcead  push r8
00007583d7bdceaf  push r9
00007583d7bdceb1  push r10
00007583d7bdceb3  push r11
00007583d7bdceb5  sub rsp, 0xF0
00007583d7bdcebc  vmovaps [rsp], xmm0
00007583d7bdcec1  vmovaps [rsp+0x10], xmm1
00007583d7bdcec7  vmovaps [rsp+0x20], xmm2
00007583d7bdcecd  vmovaps [rsp+0x30], xmm3
00007583d7bdced3  vmovaps [rsp+0x40], xmm4
00007583d7bdced9  vmovaps [rsp+0x50], xmm5
00007583d7bdcedf  vmovaps [rsp+0x60], xmm6
00007583d7bdcee5  vmovaps [rsp+0x70], xmm7
00007583d7bdceeb  vmovaps [rsp+0x80], xmm8
00007583d7bdcef4  vmovaps [rsp+0x90], xmm10
00007583d7bdcefd  vmovaps [rsp+0xA0], xmm11
00007583d7bdcf06  vmovaps [rsp+0xB0], xmm12
00007583d7bdcf0f  vmovaps [rsp+0xC0], xmm13
00007583d7bdcf18  vmovaps [rsp+0xD0], xmm14
00007583d7bdcf21  vmovaps [rsp+0xE0], xmm15
00007583d7bdcf2a  sub rsp, 0x40
00007583d7bdcf2e  lea rdi, [rsp]
00007583d7bdcf32  lea rsi, [rsp+0x10]
00007583d7bdcf37  lea rdx, [rsp+0x20]
00007583d7bdcf3c  lea rcx, [rsp+0x30]
00007583d7bdcf41  mov r8d, 0x00
00007583d7bdcf47  lea r9, [r15+0x3A8]
00007583d7bdcf4e  movaps [rdi], xmm9
00007583d7bdcf52  movaps [rsi], xmm7
00007583d7bdcf55  movaps [rdx], xmm14
00007583d7bdcf59  movaps [rcx], xmm13
00007583d7bdcf5d  mov rax, 0x5BCB7EA35A50
00007583d7bdcf67  call rax
00007583d7bdcf69  movaps xmm9, [rsp]
00007583d7bdcf6e  add rsp, 0x40
00007583d7bdcf72  vmovaps xmm0, [rsp]
00007583d7bdcf77  vmovaps xmm1, [rsp+0x10]
00007583d7bdcf7d  vmovaps xmm2, [rsp+0x20]
00007583d7bdcf83  vmovaps xmm3, [rsp+0x30]
00007583d7bdcf89  vmovaps xmm4, [rsp+0x40]
00007583d7bdcf8f  vmovaps xmm5, [rsp+0x50]
00007583d7bdcf95  vmovaps xmm6, [rsp+0x60]
00007583d7bdcf9b  vmovaps xmm7, [rsp+0x70]
00007583d7bdcfa1  vmovaps xmm8, [rsp+0x80]
00007583d7bdcfaa  vmovaps xmm10, [rsp+0x90]
00007583d7bdcfb3  vmovaps xmm11, [rsp+0xA0]
00007583d7bdcfbc  vmovaps xmm12, [rsp+0xB0]
00007583d7bdcfc5  vmovaps xmm13, [rsp+0xC0]
00007583d7bdcfce  vmovaps xmm14, [rsp+0xD0]
00007583d7bdcfd7  vmovaps xmm15, [rsp+0xE0]
00007583d7bdcfe0  add rsp, 0xF0
00007583d7bdcfe7  pop r11
00007583d7bdcfe9  pop r10
00007583d7bdcfeb  pop r9
00007583d7bdcfed  pop r8
00007583d7bdcfef  pop rsi
00007583d7bdcff0  pop rdi
00007583d7bdcff1  pop rdx
00007583d7bdcff2  pop rcx
00007583d7bdcff3  pop rax
00007583d7bdcff4  add rsp, 0x08
00007583d7bdcff8  jmp 0x00007583D7BDA5DA
00007583d7bdcffd  sub rsp, 0x08
00007583d7bdd001  push rax
00007583d7bdd002  push rcx
00007583d7bdd003  push rdx
00007583d7bdd004  push rdi
00007583d7bdd005  push rsi
00007583d7bdd006  push r8
00007583d7bdd008  push r9
00007583d7bdd00a  push r10
00007583d7bdd00c  push r11
00007583d7bdd00e  sub rsp, 0xF0
00007583d7bdd015  vmovaps [rsp], xmm0
00007583d7bdd01a  vmovaps [rsp+0x10], xmm1
00007583d7bdd020  vmovaps [rsp+0x20], xmm2
00007583d7bdd026  vmovaps [rsp+0x30], xmm3
00007583d7bdd02c  vmovaps [rsp+0x40], xmm4
00007583d7bdd032  vmovaps [rsp+0x50], xmm5
00007583d7bdd038  vmovaps [rsp+0x60], xmm6
00007583d7bdd03e  vmovaps [rsp+0x70], xmm7
00007583d7bdd044  vmovaps [rsp+0x80], xmm8
00007583d7bdd04d  vmovaps [rsp+0x90], xmm9
00007583d7bdd056  vmovaps [rsp+0xA0], xmm10
00007583d7bdd05f  vmovaps [rsp+0xB0], xmm11
00007583d7bdd068  vmovaps [rsp+0xC0], xmm12
00007583d7bdd071  vmovaps [rsp+0xD0], xmm14
00007583d7bdd07a  vmovaps [rsp+0xE0], xmm15
00007583d7bdd083  sub rsp, 0x40
00007583d7bdd087  lea rdi, [rsp]
00007583d7bdd08b  lea rsi, [rsp+0x10]
00007583d7bdd090  lea rdx, [rsp+0x20]
00007583d7bdd095  lea rcx, [rsp+0x30]
00007583d7bdd09a  mov r8d, 0x00
00007583d7bdd0a0  lea r9, [r15+0x3A8]
00007583d7bdd0a7  movaps [rdi], xmm13
00007583d7bdd0ab  movaps [rsi], xmm12
00007583d7bdd0af  movaps [rdx], xmm15
00007583d7bdd0b3  movaps [rcx], xmm14
00007583d7bdd0b7  mov rax, 0x5BCB7EA35A50
00007583d7bdd0c1  call rax
00007583d7bdd0c3  movaps xmm13, [rsp]
00007583d7bdd0c8  add rsp, 0x40
00007583d7bdd0cc  vmovaps xmm0, [rsp]
00007583d7bdd0d1  vmovaps xmm1, [rsp+0x10]
00007583d7bdd0d7  vmovaps xmm2, [rsp+0x20]
00007583d7bdd0dd  vmovaps xmm3, [rsp+0x30]
00007583d7bdd0e3  vmovaps xmm4, [rsp+0x40]
00007583d7bdd0e9  vmovaps xmm5, [rsp+0x50]
00007583d7bdd0ef  vmovaps xmm6, [rsp+0x60]
00007583d7bdd0f5  vmovaps xmm7, [rsp+0x70]
00007583d7bdd0fb  vmovaps xmm8, [rsp+0x80]
00007583d7bdd104  vmovaps xmm9, [rsp+0x90]
00007583d7bdd10d  vmovaps xmm10, [rsp+0xA0]
00007583d7bdd116  vmovaps xmm11, [rsp+0xB0]
00007583d7bdd11f  vmovaps xmm12, [rsp+0xC0]
00007583d7bdd128  vmovaps xmm14, [rsp+0xD0]
00007583d7bdd131  vmovaps xmm15, [rsp+0xE0]
00007583d7bdd13a  add rsp, 0xF0
00007583d7bdd141  pop r11
00007583d7bdd143  pop r10
00007583d7bdd145  pop r9
00007583d7bdd147  pop r8
00007583d7bdd149  pop rsi
00007583d7bdd14a  pop rdi
00007583d7bdd14b  pop rdx
00007583d7bdd14c  pop rcx
00007583d7bdd14d  pop rax
00007583d7bdd14e  add rsp, 0x08
00007583d7bdd152  jmp 0x00007583D7BDA608
00007583d7bdd157  sub rsp, 0x08
00007583d7bdd15b  push rax
00007583d7bdd15c  push rcx
00007583d7bdd15d  push rdx
00007583d7bdd15e  push rdi
00007583d7bdd15f  push rsi
00007583d7bdd160  push r8
00007583d7bdd162  push r9
00007583d7bdd164  push r10
00007583d7bdd166  push r11
00007583d7bdd168  sub rsp, 0xF0
00007583d7bdd16f  vmovaps [rsp], xmm0
00007583d7bdd174  vmovaps [rsp+0x10], xmm1
00007583d7bdd17a  vmovaps [rsp+0x20], xmm2
00007583d7bdd180  vmovaps [rsp+0x30], xmm3
00007583d7bdd186  vmovaps [rsp+0x40], xmm4
00007583d7bdd18c  vmovaps [rsp+0x50], xmm5
00007583d7bdd192  vmovaps [rsp+0x60], xmm6
00007583d7bdd198  vmovaps [rsp+0x70], xmm7
00007583d7bdd19e  vmovaps [rsp+0x80], xmm8
00007583d7bdd1a7  vmovaps [rsp+0x90], xmm9
00007583d7bdd1b0  vmovaps [rsp+0xA0], xmm10
00007583d7bdd1b9  vmovaps [rsp+0xB0], xmm11
00007583d7bdd1c2  vmovaps [rsp+0xC0], xmm12
00007583d7bdd1cb  vmovaps [rsp+0xD0], xmm13
00007583d7bdd1d4  vmovaps [rsp+0xE0], xmm15
00007583d7bdd1dd  sub rsp, 0x40
00007583d7bdd1e1  lea rdi, [rsp]
00007583d7bdd1e5  lea rsi, [rsp+0x10]
00007583d7bdd1ea  lea rdx, [rsp+0x20]
00007583d7bdd1ef  lea rcx, [rsp+0x30]
00007583d7bdd1f4  mov r8d, 0x00
00007583d7bdd1fa  lea r9, [r15+0x3A8]
00007583d7bdd201  movaps [rdi], xmm14
00007583d7bdd205  movaps [rsi], xmm11
00007583d7bdd209  movaps [rdx], xmm1
00007583d7bdd20c  movaps [rcx], xmm15
00007583d7bdd210  mov rax, 0x5BCB7EA35A50
00007583d7bdd21a  call rax
00007583d7bdd21c  movaps xmm14, [rsp]
00007583d7bdd221  add rsp, 0x40
00007583d7bdd225  vmovaps xmm0, [rsp]
00007583d7bdd22a  vmovaps xmm1, [rsp+0x10]
00007583d7bdd230  vmovaps xmm2, [rsp+0x20]
00007583d7bdd236  vmovaps xmm3, [rsp+0x30]
00007583d7bdd23c  vmovaps xmm4, [rsp+0x40]
00007583d7bdd242  vmovaps xmm5, [rsp+0x50]
00007583d7bdd248  vmovaps xmm6, [rsp+0x60]
00007583d7bdd24e  vmovaps xmm7, [rsp+0x70]
00007583d7bdd254  vmovaps xmm8, [rsp+0x80]
00007583d7bdd25d  vmovaps xmm9, [rsp+0x90]
00007583d7bdd266  vmovaps xmm10, [rsp+0xA0]
00007583d7bdd26f  vmovaps xmm11, [rsp+0xB0]
00007583d7bdd278  vmovaps xmm12, [rsp+0xC0]
00007583d7bdd281  vmovaps xmm13, [rsp+0xD0]
00007583d7bdd28a  vmovaps xmm15, [rsp+0xE0]
00007583d7bdd293  add rsp, 0xF0
00007583d7bdd29a  pop r11
00007583d7bdd29c  pop r10
00007583d7bdd29e  pop r9
00007583d7bdd2a0  pop r8
00007583d7bdd2a2  pop rsi
00007583d7bdd2a3  pop rdi
00007583d7bdd2a4  pop rdx
00007583d7bdd2a5  pop rcx
00007583d7bdd2a6  pop rax
00007583d7bdd2a7  add rsp, 0x08
00007583d7bdd2ab  jmp 0x00007583D7BDA636
00007583d7bdd2b0  call 0x00007583D7A079B0
00007583d7bdd2b5  jmp 0x00007583D7BDA64C
00007583d7bdd2ba  call 0x00007583D7AE3440
00007583d7bdd2bf  jmp 0x00007583D7BDA656
00007583d7bdd2c4  call 0x00007583D7ADFCE0
00007583d7bdd2c9  jmp 0x00007583D7BDA660
00007583d7bdd2ce  call 0x00007583D7AE46C0
00007583d7bdd2d3  jmp 0x00007583D7BDA66A
00007583d7bdd2d8  int3
00007583d7bdd2d9  nop [rax], eax
00007583d7bdd2e0  mov qword ptr [r15+0x40], 0x430000
00007583d7bdd2e8  mov eax, 0x430C50
00007583d7bdd2ed  mov r14, [r13+rax*1]
00007583d7bdd2f2  movq xmm1, r14
00007583d7bdd2f7  mov rax, [r15+0x50]
00007583d7bdd2fb  movups xmm15, [r13+rax*1]
00007583d7bdd301  movaps [r15+0x120], xmm15
00007583d7bdd309  mov qword ptr [r15+0x48], 0x10
00007583d7bdd311  xor eax, eax
00007583d7bdd313  mov r14d, 0x10
00007583d7bdd319  mov r12d, 0x200
00007583d7bdd31f  cmp r14, r12
00007583d7bdd322  cmc
00007583d7bdd323  lahf
00007583d7bdd324  seto al
00007583d7bdd327  mov [r15+0x108], eax
00007583d7bdd32e  pextrq rax, xmm15, 0x01
00007583d7bdd335  movq xmm14, rax
00007583d7bdd33a  movaps [r15+0x130], xmm14
00007583d7bdd342  movq rax, xmm1
00007583d7bdd347  movq r14, xmm15
00007583d7bdd34c  vmovq xmm1, rax
00007583d7bdd351  vmovq xmm15, r14
00007583d7bdd356  movaps xmm13, xmm1
00007583d7bdd35a  addsd xmm13, xmm15
00007583d7bdd35f  ucomisd xmm13, xmm13
00007583d7bdd364  jp 0x00007583D7BDD423
00007583d7bdd36a  movq xmm13, xmm13
00007583d7bdd36f  movq rax, xmm13
00007583d7bdd374  movq r14, xmm14
00007583d7bdd379  vmovq xmm1, rax
00007583d7bdd37e  vmovq xmm15, r14
00007583d7bdd383  movaps xmm14, xmm1
00007583d7bdd387  addsd xmm14, xmm15
00007583d7bdd38c  ucomisd xmm14, xmm14
00007583d7bdd391  jp 0x00007583D7BDD46B
00007583d7bdd397  movq xmm14, xmm14
00007583d7bdd39c  movaps [r15+0x110], xmm14
00007583d7bdd3a4  mov eax, [r15+0x108]
00007583d7bdd3ab  sahf
00007583d7bdd3ac  jnz 0x00007583D7BDD3DE
00007583d7bdd3ae  cmp dword ptr [r15+0x318], 0x00
00007583d7bdd3b6  jz 0x00007583D7BDD680
00007583d7bdd3bc  nop [rax+rax*1], ax
00007583d7bdd3c5  nop [rax+rax*1], eax
00007583d7bdd3cd  mov eax, 0x410698
00007583d7bdd3d2  mov [r15+0x100], rax
00007583d7bdd3d9  jmp 0x00007583D79FE110
00007583d7bdd3de  cmp dword ptr [r15+0x318], 0x00
00007583d7bdd3e6  jz 0x00007583D7BDD4C0
00007583d7bdd3ec  nop [rax+rax*1], ax
00007583d7bdd3f5  nop [rax+rax*1], eax
00007583d7bdd3fd  mov eax, 0x41067C
00007583d7bdd402  mov [r15+0x100], rax
00007583d7bdd409  jmp 0x00007583D79FE110
00007583d7bdd40e  int3
00007583d7bdd40f  call 0x00007583D7A0DC20
00007583d7bdd414  jmp 0x00007583D7BDD2F2
00007583d7bdd419  call 0x00007583D7A0E760
00007583d7bdd41e  jmp 0x00007583D7BDD301
00007583d7bdd423  ucomisd xmm1, xmm15
00007583d7bdd428  jp 0x00007583D7BDD437
00007583d7bdd42a  movaps xmm13, [0x00007583D77FE060]
00007583d7bdd432  jmp 0x00007583D7BDD36A
00007583d7bdd437  vxorps xmm0, xmm1, xmm15
00007583d7bdd43c  pextrw eax, xmm0, 0x03
00007583d7bdd441  and eax, 0x7FF8
00007583d7bdd446  cmp eax, 0x08
00007583d7bdd449  jnz 0x00007583D7BDD36A
00007583d7bdd44f  movq rax, xmm15
00007583d7bdd454  shl rax, 0x0D
00007583d7bdd458  jbe 0x00007583D7BDD36A
00007583d7bdd45e  vorps xmm13, xmm15, [0x00007583D77FE070]
00007583d7bdd466  jmp 0x00007583D7BDD36A
00007583d7bdd46b  ucomisd xmm1, xmm15
00007583d7bdd470  jp 0x00007583D7BDD47F
00007583d7bdd472  movaps xmm14, [0x00007583D77FE060]
00007583d7bdd47a  jmp 0x00007583D7BDD397
00007583d7bdd47f  vxorps xmm0, xmm1, xmm15
00007583d7bdd484  pextrw eax, xmm0, 0x03
00007583d7bdd489  and eax, 0x7FF8
00007583d7bdd48e  cmp eax, 0x08
00007583d7bdd491  jnz 0x00007583D7BDD397
00007583d7bdd497  movq rax, xmm15
00007583d7bdd49c  shl rax, 0x0D
00007583d7bdd4a0  jbe 0x00007583D7BDD397
00007583d7bdd4a6  vorps xmm14, xmm15, [0x00007583D77FE070]
00007583d7bdd4ae  jmp 0x00007583D7BDD397
00007583d7bdd4b3  int3
00007583d7bdd4b4  nop [rax+rax*1], ax
00007583d7bdd4bd  nop [rax], eax
00007583d7bdd4c0  mov rax, [r15+0x48]
00007583d7bdd4c4  mov r14, [r15+0x50]
00007583d7bdd4c8  lea r12, [r14+rax*1]
00007583d7bdd4cc  movups xmm1, [r13+r12*1]
00007583d7bdd4d2  movaps [r15+0x120], xmm1
00007583d7bdd4da  lea r14, [rax+0x10]
00007583d7bdd4de  mov [r15+0x48], r14
00007583d7bdd4e2  xor eax, eax
00007583d7bdd4e4  mov r12d, 0x200
00007583d7bdd4ea  cmp r14, r12
00007583d7bdd4ed  cmc
00007583d7bdd4ee  lahf
00007583d7bdd4ef  seto al
00007583d7bdd4f2  mov [r15+0x108], eax
00007583d7bdd4f9  pextrq rax, xmm1, 0x01
00007583d7bdd500  movq xmm15, rax
00007583d7bdd505  movaps [r15+0x130], xmm15
00007583d7bdd50d  movaps xmm14, [r15+0x110]
00007583d7bdd515  movq rax, xmm14
00007583d7bdd51a  movq r14, xmm1
00007583d7bdd51f  vmovq xmm1, rax
00007583d7bdd524  vmovq xmm14, r14
00007583d7bdd529  movaps xmm13, xmm1
00007583d7bdd52d  addsd xmm13, xmm14
00007583d7bdd532  ucomisd xmm13, xmm13
00007583d7bdd537  jp 0x00007583D7BDD5EC
00007583d7bdd53d  movq xmm13, xmm13
00007583d7bdd542  movq rax, xmm13
00007583d7bdd547  movq r14, xmm15
00007583d7bdd54c  vmovq xmm1, rax
00007583d7bdd551  vmovq xmm15, r14
00007583d7bdd556  movaps xmm14, xmm1
00007583d7bdd55a  addsd xmm14, xmm15
00007583d7bdd55f  ucomisd xmm14, xmm14
00007583d7bdd564  jp 0x00007583D7BDD634
00007583d7bdd56a  movq xmm14, xmm14
00007583d7bdd56f  movaps [r15+0x110], xmm14
00007583d7bdd577  mov eax, [r15+0x108]
00007583d7bdd57e  sahf
00007583d7bdd57f  jnz 0x00007583D7BDD5B1
00007583d7bdd581  cmp dword ptr [r15+0x318], 0x00
00007583d7bdd589  jz 0x00007583D7BDD680
00007583d7bdd58f  nop [rax+rax*1], ax
00007583d7bdd598  nop [rax+rax*1], eax
00007583d7bdd5a0  mov eax, 0x410698
00007583d7bdd5a5  mov [r15+0x100], rax
00007583d7bdd5ac  jmp 0x00007583D79FE110
00007583d7bdd5b1  cmp dword ptr [r15+0x318], 0x00
00007583d7bdd5b9  jz 0x00007583D7BDD4C0
00007583d7bdd5bf  nop [rax+rax*1], ax
00007583d7bdd5c8  nop [rax+rax*1], eax
00007583d7bdd5d0  mov eax, 0x41067C
00007583d7bdd5d5  mov [r15+0x100], rax
00007583d7bdd5dc  jmp 0x00007583D79FE110
00007583d7bdd5e1  int3
00007583d7bdd5e2  call 0x00007583D7AB52F0
00007583d7bdd5e7  jmp 0x00007583D7BDD4D2
00007583d7bdd5ec  ucomisd xmm1, xmm14
00007583d7bdd5f1  jp 0x00007583D7BDD600
00007583d7bdd5f3  movaps xmm13, [0x00007583D77FE060]
00007583d7bdd5fb  jmp 0x00007583D7BDD53D
00007583d7bdd600  vxorps xmm0, xmm1, xmm14
00007583d7bdd605  pextrw eax, xmm0, 0x03
00007583d7bdd60a  and eax, 0x7FF8
00007583d7bdd60f  cmp eax, 0x08
00007583d7bdd612  jnz 0x00007583D7BDD53D
00007583d7bdd618  movq rax, xmm14
00007583d7bdd61d  shl rax, 0x0D
00007583d7bdd621  jbe 0x00007583D7BDD53D
00007583d7bdd627  vorps xmm13, xmm14, [0x00007583D77FE070]
00007583d7bdd62f  jmp 0x00007583D7BDD53D
00007583d7bdd634  ucomisd xmm1, xmm15
00007583d7bdd639  jp 0x00007583D7BDD648
00007583d7bdd63b  movaps xmm14, [0x00007583D77FE060]
00007583d7bdd643  jmp 0x00007583D7BDD56A
00007583d7bdd648  vxorps xmm0, xmm1, xmm15
00007583d7bdd64d  pextrw eax, xmm0, 0x03
00007583d7bdd652  and eax, 0x7FF8
00007583d7bdd657  cmp eax, 0x08
00007583d7bdd65a  jnz 0x00007583D7BDD56A
00007583d7bdd660  movq rax, xmm15
00007583d7bdd665  shl rax, 0x0D
00007583d7bdd669  jbe 0x00007583D7BDD56A
00007583d7bdd66f  vorps xmm14, xmm15, [0x00007583D77FE070]
00007583d7bdd677  jmp 0x00007583D7BDD56A
00007583d7bdd67c  int3
00007583d7bdd67d  nop [rax], eax
00007583d7bdd680  mov rax, [r15+0xF8]
00007583d7bdd687  lea r14, [rax+0x1A0]
00007583d7bdd68e  mov r12, [r13+r14*1]
00007583d7bdd693  lea r14, [rax+0x1A8]
00007583d7bdd69a  mov r11, [r13+r14*1]
00007583d7bdd69f  mov [r15+0xA0], r12
00007583d7bdd6a6  mov [r15+0x98], r11
00007583d7bdd6ad  mov r14, [r15+0x40]
00007583d7bdd6b1  lea r12, [r14+0xC50]
00007583d7bdd6b8  movaps xmm1, [r15+0x110]
00007583d7bdd6c0  movq r14, xmm1
00007583d7bdd6c5  mov [r13+r12*1], r14
00007583d7bdd6ca  lea r14, [rax+0x190]
00007583d7bdd6d1  mov r12, [r13+r14*1]
00007583d7bdd6d6  lea r14, [rax+0x198]
00007583d7bdd6dd  mov r11, [r13+r14*1]
00007583d7bdd6e2  mov [r15+0xE8], r12
00007583d7bdd6e9  mov [r15+0xF0], r11
00007583d7bdd6f0  lea r14, [rax+0x180]
00007583d7bdd6f7  mov r12, [r13+r14*1]
00007583d7bdd6fc  lea r14, [rax+0x188]
00007583d7bdd703  mov r10, [r13+r14*1]
00007583d7bdd708  movq xmm1, r12
00007583d7bdd70d  movq xmm15, r10
00007583d7bdd712  movq xmm1, xmm1
00007583d7bdd716  movq xmm1, xmm1
00007583d7bdd71a  movaps [r15+0x1A0], xmm1
00007583d7bdd722  movq xmm15, xmm15
00007583d7bdd727  movq xmm15, xmm15
00007583d7bdd72c  movaps [r15+0x190], xmm15
00007583d7bdd734  lea r14, [rax+0x170]
00007583d7bdd73b  mov r12, [r13+r14*1]
00007583d7bdd740  lea r14, [rax+0x178]
00007583d7bdd747  mov r10, [r13+r14*1]
00007583d7bdd74c  movq xmm1, r12
00007583d7bdd751  movq xmm15, r10
00007583d7bdd756  movq xmm1, xmm1
00007583d7bdd75a  movq xmm1, xmm1
00007583d7bdd75e  movaps [r15+0x1C0], xmm1
00007583d7bdd766  movq xmm15, xmm15
00007583d7bdd76b  movq xmm15, xmm15
00007583d7bdd770  movaps [r15+0x1B0], xmm15
00007583d7bdd778  lea r14, [rax+0x160]
00007583d7bdd77f  mov r12, [r13+r14*1]
00007583d7bdd784  lea r14, [rax+0x168]
00007583d7bdd78b  mov r10, [r13+r14*1]
00007583d7bdd790  movq xmm1, r12
00007583d7bdd795  movq xmm15, r10
00007583d7bdd79a  movq xmm1, xmm1
00007583d7bdd79e  movq xmm1, xmm1
00007583d7bdd7a2  movaps [r15+0x1E0], xmm1
00007583d7bdd7aa  movq xmm15, xmm15
00007583d7bdd7af  movq xmm15, xmm15
00007583d7bdd7b4  movaps [r15+0x1D0], xmm15
00007583d7bdd7bc  lea r14, [rax+0x150]
00007583d7bdd7c3  mov r12, [r13+r14*1]
00007583d7bdd7c8  lea r14, [rax+0x158]
00007583d7bdd7cf  mov r10, [r13+r14*1]
00007583d7bdd7d4  movq xmm1, r12
00007583d7bdd7d9  movq xmm15, r10
00007583d7bdd7de  movq xmm1, xmm1
00007583d7bdd7e2  movq xmm1, xmm1
00007583d7bdd7e6  movaps [r15+0x200], xmm1
00007583d7bdd7ee  movq xmm15, xmm15
00007583d7bdd7f3  movq xmm15, xmm15
00007583d7bdd7f8  movaps [r15+0x1F0], xmm15
00007583d7bdd800  lea r14, [rax+0x1B0]
00007583d7bdd807  mov [r15+0xF8], r14
00007583d7bdd80e  mov [r15+0x100], r11
00007583d7bdd815  jmp 0x00007583D7BCE5C0
00007583d7bdd81a  int3
00007583d7bdd81b  call 0x00007583D7AE27E0
00007583d7bdd820  jmp 0x00007583D7BDD693
00007583d7bdd825  call 0x00007583D7AE1570
00007583d7bdd82a  jmp 0x00007583D7BDD69F
00007583d7bdd82f  call 0x00007583D7AC3FE0
00007583d7bdd834  jmp 0x00007583D7BDD6CA
00007583d7bdd839  call 0x00007583D7AE27E0
00007583d7bdd83e  jmp 0x00007583D7BDD6D6
00007583d7bdd843  call 0x00007583D7AE1570
00007583d7bdd848  jmp 0x00007583D7BDD6E2
00007583d7bdd84d  call 0x00007583D7AE27E0
00007583d7bdd852  jmp 0x00007583D7BDD6FC
00007583d7bdd857  call 0x00007583D7AE0300
00007583d7bdd85c  jmp 0x00007583D7BDD708
00007583d7bdd861  call 0x00007583D7AE27E0
00007583d7bdd866  jmp 0x00007583D7BDD740
00007583d7bdd86b  call 0x00007583D7AE0300
00007583d7bdd870  jmp 0x00007583D7BDD74C
00007583d7bdd875  call 0x00007583D7AE27E0
00007583d7bdd87a  jmp 0x00007583D7BDD784
00007583d7bdd87f  call 0x00007583D7AE0300
00007583d7bdd884  jmp 0x00007583D7BDD790
00007583d7bdd889  call 0x00007583D7AE27E0
00007583d7bdd88e  jmp 0x00007583D7BDD7C8
00007583d7bdd893  call 0x00007583D7AE0300
00007583d7bdd898  jmp 0x00007583D7BDD7D4
00007583d7bdd89d  int3
00007583d7bdd89e  nop
00007583d7bdd8a0  mov qword ptr [r15+0x100], 0x04
00007583d7bdd8ab  mov esi, 0x00
00007583d7bdd8b0  mov edx, 0x09
00007583d7bdd8b5  mov rdi, 0x7FFFC9BCDAE0
00007583d7bdd8bf  mov rax, 0x5BCB7E8C8970
00007583d7bdd8c9  call rax
00007583d7bdd8cb  cmp dword ptr [r15+0x318], 0x00
00007583d7bdd8d3  jnz 0x00007583D79FE110
00007583d7bdd8d9  jmp 0x00007583D79FE0A0
00007583d7bdd8de  int3
00007583d7bdd8df  int3
