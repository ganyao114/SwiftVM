00007b4681bce69b  nop [rax+rax*1], eax
00007b4681bce6a0  mov rax, [r15+0xF8]
00007b4681bce6a7  lea r14, [rax-0x1B0]
00007b4681bce6ae  mov [r15+0xF8], r14
00007b4681bce6b5  lea rax, [r14+0x1A0]
00007b4681bce6bc  mov r12, [r15+0xA0]
00007b4681bce6c3  mov r11, [r15+0x98]
00007b4681bce6ca  mov [r13+rax*1], r12
00007b4681bce6cf  lea rax, [r14+0x1A8]
00007b4681bce6d6  mov [r13+rax*1], r11
00007b4681bce6db  mov eax, 0x420A30
00007b4681bce6e0  movups xmm1, [r13+rax*1]
00007b4681bce6e6  mov eax, 0x4209C0
00007b4681bce6eb  movups xmm15, [r13+rax*1]
00007b4681bce6f1  mov eax, 0x420A50
00007b4681bce6f6  movups xmm14, [r13+rax*1]
00007b4681bce6fc  mov eax, 0x4209F0
00007b4681bce701  movups xmm13, [r13+rax*1]
00007b4681bce707  mov qword ptr [r15+0x98], 0x430C60
00007b4681bce712  mov eax, 0x420A60
00007b4681bce717  movups xmm12, [r13+rax*1]
00007b4681bce71d  mov eax, 0x430C60
00007b4681bce722  movups [r13+rax*1], xmm1
00007b4681bce728  mov eax, 0x430C70
00007b4681bce72d  movups [r13+rax*1], xmm15
00007b4681bce733  mov eax, 0x430C80
00007b4681bce738  movups [r13+rax*1], xmm14
00007b4681bce73e  mov eax, 0x430C90
00007b4681bce743  movups [r13+rax*1], xmm13
00007b4681bce749  mov eax, 0x4209B0
00007b4681bce74e  movups xmm14, [r13+rax*1]
00007b4681bce754  mov eax, 0x4209A0
00007b4681bce759  movups xmm13, [r13+rax*1]
00007b4681bce75f  mov eax, 0x430D60
00007b4681bce764  movups [r13+rax*1], xmm1
00007b4681bce76a  mov eax, 0x430D70
00007b4681bce76f  movups [r13+rax*1], xmm15
00007b4681bce775  mov eax, 0x430CA0
00007b4681bce77a  movups [r13+rax*1], xmm12
00007b4681bce780  mov eax, 0x430CB0
00007b4681bce785  movups [r13+rax*1], xmm14
00007b4681bce78b  mov eax, 0x420990
00007b4681bce790  movups xmm1, [r13+rax*1]
00007b4681bce796  mov eax, 0x420A00
00007b4681bce79b  movups xmm15, [r13+rax*1]
00007b4681bce7a1  mov eax, 0x430CC0
00007b4681bce7a6  movups [r13+rax*1], xmm13
00007b4681bce7ac  mov eax, 0x430CD0
00007b4681bce7b1  movups [r13+rax*1], xmm1
00007b4681bce7b7  mov eax, 0x420A10
00007b4681bce7bc  movups xmm1, [r13+rax*1]
00007b4681bce7c2  mov eax, 0x4209E0
00007b4681bce7c7  movups xmm14, [r13+rax*1]
00007b4681bce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007b4681bce7d5  mov eax, 0x430CE0
00007b4681bce7da  movups [r13+rax*1], xmm15
00007b4681bce7e0  mov eax, 0x430CF0
00007b4681bce7e5  movups [r13+rax*1], xmm1
00007b4681bce7eb  mov eax, 0x420A80
00007b4681bce7f0  movups xmm1, [r13+rax*1]
00007b4681bce7f6  mov eax, 0x420A90
00007b4681bce7fb  movups xmm15, [r13+rax*1]
00007b4681bce801  movaps [r15+0x150], xmm15
00007b4681bce809  mov qword ptr [r15+0xA0], 0x3E8
00007b4681bce814  mov eax, 0x430D00
00007b4681bce819  movups [r13+rax*1], xmm14
00007b4681bce81f  mov eax, 0x430D10
00007b4681bce824  movups [r13+rax*1], xmm1
00007b4681bce82a  mov eax, 0x420A70
00007b4681bce82f  movups xmm1, [r13+rax*1]
00007b4681bce835  mov eax, 0x420A20
00007b4681bce83a  movups xmm14, [r13+rax*1]
00007b4681bce840  movaps [r15+0x140], xmm14
00007b4681bce848  lea rax, [r14+0x150]
00007b4681bce84f  movq xmm13, qword ptr [r15+0x200]
00007b4681bce858  movq xmm12, qword ptr [r15+0x1F0]
00007b4681bce861  movq r12, xmm13
00007b4681bce866  movq r11, xmm12
00007b4681bce86b  mov [r13+rax*1], r12
00007b4681bce870  lea rax, [r14+0x158]
00007b4681bce877  mov [r13+rax*1], r11
00007b4681bce87c  mov eax, 0x430D20
00007b4681bce881  movups [r13+rax*1], xmm15
00007b4681bce887  mov eax, 0x430D30
00007b4681bce88c  movups [r13+rax*1], xmm1
00007b4681bce892  mov eax, 0x420A40
00007b4681bce897  movups xmm1, [r13+rax*1]
00007b4681bce89d  mov eax, 0x420AA8
00007b4681bce8a2  mov r12, [r13+rax*1]
00007b4681bce8a7  movq xmm15, r12
00007b4681bce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007b4681bce8b4  mov eax, 0x430D40
00007b4681bce8b9  movups [r13+rax*1], xmm14
00007b4681bce8bf  mov eax, 0x430D50
00007b4681bce8c4  movups [r13+rax*1], xmm1
00007b4681bce8ca  mov eax, 0x420B10
00007b4681bce8cf  movups xmm1, [r13+rax*1]
00007b4681bce8d5  movq rax, xmm15
00007b4681bce8da  mov r12d, 0x430D80
00007b4681bce8e0  mov [r13+r12*1], rax
00007b4681bce8e5  mov eax, 0x420AF0
00007b4681bce8ea  movups xmm15, [r13+rax*1]
00007b4681bce8f0  mov eax, 0x420B00
00007b4681bce8f5  movups xmm14, [r13+rax*1]
00007b4681bce8fb  lea rax, [r14+0x130]
00007b4681bce902  movups [r13+rax*1], xmm1
00007b4681bce908  lea rax, [r14+0x160]
00007b4681bce90f  movq xmm1, qword ptr [r15+0x1E0]
00007b4681bce918  movq xmm13, qword ptr [r15+0x1D0]
00007b4681bce921  movq r12, xmm1
00007b4681bce926  movq r11, xmm13
00007b4681bce92b  mov [r13+rax*1], r12
00007b4681bce930  lea rax, [r14+0x168]
00007b4681bce937  mov [r13+rax*1], r11
00007b4681bce93c  lea rax, [r14+0x110]
00007b4681bce943  movups [r13+rax*1], xmm15
00007b4681bce949  lea rax, [r14+0x120]
00007b4681bce950  movups [r13+rax*1], xmm14
00007b4681bce956  mov eax, 0x420AB0
00007b4681bce95b  movups xmm1, [r13+rax*1]
00007b4681bce961  mov eax, 0x420AC0
00007b4681bce966  movups xmm15, [r13+rax*1]
00007b4681bce96c  movaps [r15+0x120], xmm15
00007b4681bce974  lea rax, [r14+0x170]
00007b4681bce97b  movq xmm14, qword ptr [r15+0x1C0]
00007b4681bce984  movq xmm13, qword ptr [r15+0x1B0]
00007b4681bce98d  movq r12, xmm14
00007b4681bce992  movq r11, xmm13
00007b4681bce997  mov [r13+rax*1], r12
00007b4681bce99c  lea rax, [r14+0x178]
00007b4681bce9a3  mov [r13+rax*1], r11
00007b4681bce9a8  lea rax, [r14+0x180]
00007b4681bce9af  movq xmm14, qword ptr [r15+0x1A0]
00007b4681bce9b8  movq xmm13, qword ptr [r15+0x190]
00007b4681bce9c1  movq r12, xmm14
00007b4681bce9c6  movq r11, xmm13
00007b4681bce9cb  mov [r13+rax*1], r12
00007b4681bce9d0  lea rax, [r14+0x188]
00007b4681bce9d7  mov [r13+rax*1], r11
00007b4681bce9dc  lea rax, [r14+0xD0]
00007b4681bce9e3  movups [r13+rax*1], xmm1
00007b4681bce9e9  lea rax, [r14+0xE0]
00007b4681bce9f0  movups [r13+rax*1], xmm15
00007b4681bce9f6  mov eax, 0x420AD0
00007b4681bce9fb  movups xmm1, [r13+rax*1]
00007b4681bcea01  mov eax, 0x420AE0
00007b4681bcea06  movups xmm15, [r13+rax*1]
00007b4681bcea0c  movaps [r15+0x110], xmm1
00007b4681bcea14  movaps [r15+0x130], xmm15
00007b4681bcea1c  lea rax, [r14+0x190]
00007b4681bcea23  mov r12, [r15+0xE8]
00007b4681bcea2a  mov r11, [r15+0xF0]
00007b4681bcea31  mov [r13+rax*1], r12
00007b4681bcea36  lea rax, [r14+0x198]
00007b4681bcea3d  mov [r13+rax*1], r11
00007b4681bcea42  mov eax, 0x430D88
00007b4681bcea47  mov r12d, 0x421DF8D3
00007b4681bcea4d  mov [r13+rax*1], r12d
00007b4681bcea52  lea rax, [r14+0xF0]
00007b4681bcea59  movups [r13+rax*1], xmm1
00007b4681bcea5f  lea rax, [r14+0x100]
00007b4681bcea66  movups [r13+rax*1], xmm15
00007b4681bcea6c  lea rax, [r14+0xD0]
00007b4681bcea73  mov [r15], rax
00007b4681bcea76  mov qword ptr [r15+0x08], 0x430C60
00007b4681bcea7e  mov qword ptr [r15+0x10], 0x12C
00007b4681bcea86  mov qword ptr [r15+0xF0], 0x410284
00007b4681bcea91  mov r14d, [r15+0x320]
00007b4681bcea98  mov eax, 0x410284
00007b4681bcea9d  mov rcx, 0x7B4681BD07C0
00007b4681bceaa7  mov [r15+r14*8+0x328], rax
00007b4681bceaaf  mov [r15+r14*8+0x368], rcx
00007b4681bceab7  add r14d, 0x01
00007b4681bceabb  and r14d, 0x07
00007b4681bceabf  mov [r15+0x320], r14d
00007b4681bceac6  cmp dword ptr [r15+0x318], 0x00
00007b4681bceace  jz 0x00007B4681BCED70
00007b4681bcead4  nop [rax+rax*1], ax
00007b4681bceadd  nop [rax+rax*1], eax
00007b4681bceae5  mov eax, 0x4106BC
00007b4681bceaea  mov [r15+0x100], rax
00007b4681bceaf1  jmp 0x00007B46819FE110
00007b4681bceaf6  int3
00007b4681bceaf7  call 0x00007B4681A0BC20
00007b4681bceafc  jmp 0x00007B4681BCE6CF
00007b4681bceb01  call 0x00007B4681A0A9A0
00007b4681bceb06  jmp 0x00007B4681BCE6DB
00007b4681bceb0b  call 0x00007B46819FF430
00007b4681bceb10  jmp 0x00007B4681BCE6E6
00007b4681bceb15  call 0x00007B4681A0E760
00007b4681bceb1a  jmp 0x00007B4681BCE6F1
00007b4681bceb1f  call 0x00007B4681A0D4E0
00007b4681bceb24  jmp 0x00007B4681BCE6FC
00007b4681bceb29  call 0x00007B4681A0C260
00007b4681bceb2e  jmp 0x00007B4681BCE707
00007b4681bceb33  call 0x00007B4681A0AFE0
00007b4681bceb38  jmp 0x00007B4681BCE71D
00007b4681bceb3d  call 0x00007B46819FF540
00007b4681bceb42  jmp 0x00007B4681BCE728
00007b4681bceb47  call 0x00007B4681A0E880
00007b4681bceb4c  jmp 0x00007B4681BCE733
00007b4681bceb51  call 0x00007B4681A0D600
00007b4681bceb56  jmp 0x00007B4681BCE73E
00007b4681bceb5b  call 0x00007B4681A0C380
00007b4681bceb60  jmp 0x00007B4681BCE749
00007b4681bceb65  call 0x00007B4681A0D4E0
00007b4681bceb6a  jmp 0x00007B4681BCE754
00007b4681bceb6f  call 0x00007B4681A0C260
00007b4681bceb74  jmp 0x00007B4681BCE75F
00007b4681bceb79  call 0x00007B46819FF540
00007b4681bceb7e  jmp 0x00007B4681BCE76A
00007b4681bceb83  call 0x00007B4681A0E880
00007b4681bceb88  jmp 0x00007B4681BCE775
00007b4681bceb8d  call 0x00007B4681A0B100
00007b4681bceb92  jmp 0x00007B4681BCE780
00007b4681bceb97  call 0x00007B4681A0D600
00007b4681bceb9c  jmp 0x00007B4681BCE78B
00007b4681bceba1  call 0x00007B46819FF430
00007b4681bceba6  jmp 0x00007B4681BCE796
00007b4681bcebab  call 0x00007B4681A0E760
00007b4681bcebb0  jmp 0x00007B4681BCE7A1
00007b4681bcebb5  call 0x00007B4681A0C380
00007b4681bcebba  jmp 0x00007B4681BCE7AC
00007b4681bcebbf  call 0x00007B46819FF540
00007b4681bcebc4  jmp 0x00007B4681BCE7B7
00007b4681bcebc9  call 0x00007B46819FF430
00007b4681bcebce  jmp 0x00007B4681BCE7C2
00007b4681bcebd3  call 0x00007B4681A0D4E0
00007b4681bcebd8  jmp 0x00007B4681BCE7CD
00007b4681bcebdd  call 0x00007B4681A0E880
00007b4681bcebe2  jmp 0x00007B4681BCE7E0
00007b4681bcebe7  call 0x00007B46819FF540
00007b4681bcebec  jmp 0x00007B4681BCE7EB
00007b4681bcebf1  call 0x00007B46819FF430
00007b4681bcebf6  jmp 0x00007B4681BCE7F6
00007b4681bcebfb  call 0x00007B4681A0E760
00007b4681bcec00  jmp 0x00007B4681BCE801
00007b4681bcec05  call 0x00007B4681A0D600
00007b4681bcec0a  jmp 0x00007B4681BCE81F
00007b4681bcec0f  call 0x00007B46819FF540
00007b4681bcec14  jmp 0x00007B4681BCE82A
00007b4681bcec19  call 0x00007B46819FF430
00007b4681bcec1e  jmp 0x00007B4681BCE835
00007b4681bcec23  call 0x00007B4681A0D4E0
00007b4681bcec28  jmp 0x00007B4681BCE840
00007b4681bcec2d  call 0x00007B4681A0BC20
00007b4681bcec32  jmp 0x00007B4681BCE870
00007b4681bcec37  call 0x00007B4681A0A9A0
00007b4681bcec3c  jmp 0x00007B4681BCE87C
00007b4681bcec41  call 0x00007B4681A0E880
00007b4681bcec46  jmp 0x00007B4681BCE887
00007b4681bcec4b  call 0x00007B46819FF540
00007b4681bcec50  jmp 0x00007B4681BCE892
00007b4681bcec55  call 0x00007B46819FF430
00007b4681bcec5a  jmp 0x00007B4681BCE89D
00007b4681bcec5f  call 0x00007B4681A0B720
00007b4681bcec64  jmp 0x00007B4681BCE8A7
00007b4681bcec69  call 0x00007B4681A0D600
00007b4681bcec6e  jmp 0x00007B4681BCE8BF
00007b4681bcec73  call 0x00007B46819FF540
00007b4681bcec78  jmp 0x00007B4681BCE8CA
00007b4681bcec7d  call 0x00007B46819FF430
00007b4681bcec82  jmp 0x00007B4681BCE8D5
00007b4681bcec87  call 0x00007B4681AB4CB0
00007b4681bcec8c  jmp 0x00007B4681BCE8E5
00007b4681bcec91  call 0x00007B4681A0E760
00007b4681bcec96  jmp 0x00007B4681BCE8F0
00007b4681bcec9b  call 0x00007B4681A0D4E0
00007b4681bceca0  jmp 0x00007B4681BCE8FB
00007b4681bceca5  call 0x00007B46819FF540
00007b4681bcecaa  jmp 0x00007B4681BCE908
00007b4681bcecaf  call 0x00007B4681A0BC20
00007b4681bcecb4  jmp 0x00007B4681BCE930
00007b4681bcecb9  call 0x00007B4681A0A9A0
00007b4681bcecbe  jmp 0x00007B4681BCE93C
00007b4681bcecc3  call 0x00007B4681A0E880
00007b4681bcecc8  jmp 0x00007B4681BCE949
00007b4681bceccd  call 0x00007B4681A0D600
00007b4681bcecd2  jmp 0x00007B4681BCE956
00007b4681bcecd7  call 0x00007B46819FF430
00007b4681bcecdc  jmp 0x00007B4681BCE961
00007b4681bcece1  call 0x00007B4681A0E760
00007b4681bcece6  jmp 0x00007B4681BCE96C
00007b4681bceceb  call 0x00007B4681A0BC20
00007b4681bcecf0  jmp 0x00007B4681BCE99C
00007b4681bcecf5  call 0x00007B4681A0A9A0
00007b4681bcecfa  jmp 0x00007B4681BCE9A8
00007b4681bcecff  call 0x00007B4681A0BC20
00007b4681bced04  jmp 0x00007B4681BCE9D0
00007b4681bced09  call 0x00007B4681A0A9A0
00007b4681bced0e  jmp 0x00007B4681BCE9DC
00007b4681bced13  call 0x00007B46819FF540
00007b4681bced18  jmp 0x00007B4681BCE9E9
00007b4681bced1d  call 0x00007B4681A0E880
00007b4681bced22  jmp 0x00007B4681BCE9F6
00007b4681bced27  call 0x00007B46819FF430
00007b4681bced2c  jmp 0x00007B4681BCEA01
00007b4681bced31  call 0x00007B4681A0E760
00007b4681bced36  jmp 0x00007B4681BCEA0C
00007b4681bced3b  call 0x00007B4681A0BC20
00007b4681bced40  jmp 0x00007B4681BCEA36
00007b4681bced45  call 0x00007B4681A0A9A0
00007b4681bced4a  jmp 0x00007B4681BCEA42
00007b4681bced4f  call 0x00007B4681A0BAE0
00007b4681bced54  jmp 0x00007B4681BCEA52
00007b4681bced59  call 0x00007B46819FF540
00007b4681bced5e  jmp 0x00007B4681BCEA5F
00007b4681bced63  call 0x00007B4681A0E880
00007b4681bced68  jmp 0x00007B4681BCEA6C
00007b4681bced6d  int3
00007b4681bced6e  nop
00007b4681bced70  mov rax, [r15]
00007b4681bced73  lea r14, [rax+0x20]
00007b4681bced77  mov r12, [r13+r14*1]
00007b4681bced7c  mov r14, [r15+0x10]
00007b4681bced80  lea r11, [r12+r14*1]
00007b4681bced84  mov [r15+0x40], r11
00007b4681bced88  lea r12, [rax+0x20]
00007b4681bced8c  mov [r13+r12*1], r11
00007b4681bced91  test r14, r14
00007b4681bced94  setz r14b
00007b4681bced98  movzx r14, r14b
00007b4681bced9c  mov [rsp+0x414], r14b
00007b4681bceda4  cmp byte ptr [rsp+0x414], 0x00
00007b4681bcedac  jz 0x00007B4681BCEDDE
00007b4681bcedae  cmp dword ptr [r15+0x318], 0x00
00007b4681bcedb6  mov eax, 0x410934
00007b4681bcedbb  mov [r15+0x100], rax
00007b4681bcedc2  jz 0x00007B46819FE0A0
00007b4681bcedc8  nop [rax+rax*1], eax
00007b4681bcedcd  mov eax, 0x410934
00007b4681bcedd2  mov [r15+0x100], rax
00007b4681bcedd9  jmp 0x00007B46819FE110
00007b4681bcedde  cmp dword ptr [r15+0x318], 0x00
00007b4681bcede6  jz 0x00007B4681BCEE30
00007b4681bcedec  nop [rax+rax*1], ax
00007b4681bcedf5  nop [rax+rax*1], eax
00007b4681bcedfd  mov eax, 0x4106CC
00007b4681bcee02  mov [r15+0x100], rax
00007b4681bcee09  jmp 0x00007B46819FE110
00007b4681bcee0e  int3
00007b4681bcee0f  call 0x00007B4681AE27E0
00007b4681bcee14  jmp 0x00007B4681BCED7C
00007b4681bcee19  call 0x00007B4681AC0860
00007b4681bcee1e  jmp 0x00007B4681BCED91
00007b4681bcee23  int3
00007b4681bcee24  nop [rax+rax*1], ax
00007b4681bcee2d  nop [rax], eax
00007b4681bcee30  mov rax, [r15+0xF8]
00007b4681bcee37  lea r14, [rax-0x150]
00007b4681bcee3e  mov [r15+0xF8], r14
00007b4681bcee45  mov rax, [r15]
00007b4681bcee48  lea r12, [rax+0x68]
00007b4681bcee4c  mov r11, [r13+r12*1]
00007b4681bcee51  mov [r15+0x88], r11
00007b4681bcee58  lea r12, [rax+0x28]
00007b4681bcee5c  mov [r15+0x40], r12
00007b4681bcee60  mov [r15+0x48], r14
00007b4681bcee64  mov qword ptr [r15+0x50], 0x420B20
00007b4681bcee6c  lea rax, [r14+0x100]
00007b4681bcee73  mov r12, [r15+0xE8]
00007b4681bcee7a  mov r11, [r15+0xD8]
00007b4681bcee81  mov [r13+rax*1], r12
00007b4681bcee86  lea rax, [r14+0x108]
00007b4681bcee8d  mov [r13+rax*1], r11
00007b4681bcee92  lea rax, [r14+0x110]
00007b4681bcee99  mov r12, [r15+0xD0]
00007b4681bceea0  mov r11, [r15+0xC8]
00007b4681bceea7  mov [r13+rax*1], r12
00007b4681bceeac  lea rax, [r14+0x118]
00007b4681bceeb3  mov [r13+rax*1], r11
00007b4681bceeb8  lea rax, [r14+0x120]
00007b4681bceebf  mov r12, [r15+0xC0]
00007b4681bceec6  mov r11, [r15+0xB8]
00007b4681bceecd  mov [r13+rax*1], r12
00007b4681bceed2  lea rax, [r14+0x128]
00007b4681bceed9  mov [r13+rax*1], r11
00007b4681bceede  lea rax, [r14+0x130]
00007b4681bceee5  mov r12, [r15+0xB0]
00007b4681bceeec  mov r11, [r15+0xA8]
00007b4681bceef3  mov [r13+rax*1], r12
00007b4681bceef8  lea rax, [r14+0x138]
00007b4681bceeff  mov [r13+rax*1], r11
00007b4681bcef04  lea rax, [r14+0x140]
00007b4681bcef0b  mov r12, [r15+0xA0]
00007b4681bcef12  mov r11, [r15+0x98]
00007b4681bcef19  mov [r13+rax*1], r12
00007b4681bcef1e  lea rax, [r14+0x148]
00007b4681bcef25  mov [r13+rax*1], r11
00007b4681bcef2a  cmp dword ptr [r15+0x318], 0x00
00007b4681bcef32  jz 0x00007B4681BCEFD0
00007b4681bcef38  nop [rax+rax*1], ax
00007b4681bcef41  nop [rax+rax*1], eax
00007b4681bcef49  mov eax, 0x410704
00007b4681bcef4e  mov [r15+0x100], rax
00007b4681bcef55  jmp 0x00007B46819FE110
00007b4681bcef5a  int3
00007b4681bcef5b  call 0x00007B4681AC0370
00007b4681bcef60  jmp 0x00007B4681BCEE51
00007b4681bcef65  call 0x00007B4681A0BC20
00007b4681bcef6a  jmp 0x00007B4681BCEE86
00007b4681bcef6f  call 0x00007B4681A0A9A0
00007b4681bcef74  jmp 0x00007B4681BCEE92
00007b4681bcef79  call 0x00007B4681A0BC20
00007b4681bcef7e  jmp 0x00007B4681BCEEAC
00007b4681bcef83  call 0x00007B4681A0A9A0
00007b4681bcef88  jmp 0x00007B4681BCEEB8
00007b4681bcef8d  call 0x00007B4681A0BC20
00007b4681bcef92  jmp 0x00007B4681BCEED2
00007b4681bcef97  call 0x00007B4681A0A9A0
00007b4681bcef9c  jmp 0x00007B4681BCEEDE
00007b4681bcefa1  call 0x00007B4681A0BC20
00007b4681bcefa6  jmp 0x00007B4681BCEEF8
00007b4681bcefab  call 0x00007B4681A0A9A0
00007b4681bcefb0  jmp 0x00007B4681BCEF04
00007b4681bcefb5  call 0x00007B4681A0BC20
00007b4681bcefba  jmp 0x00007B4681BCEF1E
00007b4681bcefbf  call 0x00007B4681A0A9A0
00007b4681bcefc4  jmp 0x00007B4681BCEF2A
00007b4681bcefc9  int3
00007b4681bcefca  nop [rax+rax*1], ax
00007b4681bcefd0  mov rax, [r15+0x08]
00007b4681bcefd4  movzx r14d, byte ptr [r13+rax*1]
00007b4681bcefda  movzx r14d, r14b
00007b4681bcefde  mov [rsp+0x10], r14d
00007b4681bcefe3  mov r14d, r14d
00007b4681bcefe6  mov [r15+0x58], r14
00007b4681bcefea  lea r14, [rax+0x01]
00007b4681bcefee  mov [r15+0x08], r14
00007b4681bceff2  mov rax, [r15+0x88]
00007b4681bceff9  lea r14, [rax+0x01]
00007b4681bceffd  mov r12, [r15]
00007b4681bcf000  lea r11, [r12+0x68]
00007b4681bcf005  mov [r13+r11*1], r14
00007b4681bcf00a  lea r14, [r12+rax*1]
00007b4681bcf00e  mov [r15+0x60], r14
00007b4681bcf012  lea rax, [r14+0x28]
00007b4681bcf016  mov r11d, [rsp+0x10]
00007b4681bcf01b  movzx r14d, r11b
00007b4681bcf01f  mov [r13+rax*1], r14b
00007b4681bcf024  lea rax, [r12+0x68]
00007b4681bcf029  mov r14, [r13+rax*1]
00007b4681bcf02e  mov [r15+0x88], r14
00007b4681bcf035  xor eax, eax
00007b4681bcf037  mov r12d, 0x40
00007b4681bcf03d  cmp r14, r12
00007b4681bcf040  cmc
00007b4681bcf041  lahf
00007b4681bcf042  seto al
00007b4681bcf045  mov [r15+0x108], eax
00007b4681bcf04c  mov eax, [r15+0x108]
00007b4681bcf053  sahf
00007b4681bcf054  jnz 0x00007B4681BCF086
00007b4681bcf056  cmp dword ptr [r15+0x318], 0x00
00007b4681bcf05e  jz 0x00007B4681BCF170
00007b4681bcf064  nop [rax+rax*1], ax
00007b4681bcf06d  nop [rax+rax*1], eax
00007b4681bcf075  mov eax, 0x410724
00007b4681bcf07a  mov [r15+0x100], rax
00007b4681bcf081  jmp 0x00007B46819FE110
00007b4681bcf086  cmp dword ptr [r15+0x318], 0x00
00007b4681bcf08e  jz 0x00007B4681BCF0E0
00007b4681bcf094  nop [rax+rax*1], ax
00007b4681bcf09d  nop [rax+rax*1], eax
00007b4681bcf0a5  mov eax, 0x4106FC
00007b4681bcf0aa  mov [r15+0x100], rax
00007b4681bcf0b1  jmp 0x00007B46819FE110
00007b4681bcf0b6  int3
00007b4681bcf0b7  call 0x00007B4681A0D860
00007b4681bcf0bc  jmp 0x00007B4681BCEFDA
00007b4681bcf0c1  call 0x00007B4681AB36E0
00007b4681bcf0c6  jmp 0x00007B4681BCF00A
00007b4681bcf0cb  call 0x00007B4681A0DD60
00007b4681bcf0d0  jmp 0x00007B4681BCF024
00007b4681bcf0d5  call 0x00007B4681A0DC20
00007b4681bcf0da  jmp 0x00007B4681BCF02E
00007b4681bcf0df  int3
00007b4681bcf0e0  mov rax, [r15+0x10]
00007b4681bcf0e4  lea r14, [rax-0x01]
00007b4681bcf0e8  mov [r15+0x10], r14
00007b4681bcf0ec  test r14, r14
00007b4681bcf0ef  setz r14b
00007b4681bcf0f3  movzx r14, r14b
00007b4681bcf0f7  mov [rsp+0x414], r14b
00007b4681bcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007b4681bcf107  jz 0x00007B4681BCF139
00007b4681bcf109  cmp dword ptr [r15+0x318], 0x00
00007b4681bcf111  jz 0x00007B4681BD0670
00007b4681bcf117  nop [rax+rax*1], ax
00007b4681bcf120  nop [rax+rax*1], eax
00007b4681bcf128  mov eax, 0x41091C
00007b4681bcf12d  mov [r15+0x100], rax
00007b4681bcf134  jmp 0x00007B46819FE110
00007b4681bcf139  cmp dword ptr [r15+0x318], 0x00
00007b4681bcf141  jz 0x00007B4681BCEFD0
00007b4681bcf147  nop [rax+rax*1], ax
00007b4681bcf150  nop [rax+rax*1], eax
00007b4681bcf158  mov eax, 0x410704
00007b4681bcf15d  mov [r15+0x100], rax
00007b4681bcf164  jmp 0x00007B46819FE110
00007b4681bcf169  int3
00007b4681bcf16a  int3
00007b4681bcf16b  nop [rax+rax*1], eax
00007b4681bcf170  mov rax, [r15+0x40]
00007b4681bcf174  movzx r14d, byte ptr [r13+rax*1]
00007b4681bcf17a  movaps xmm1, [r15+0x110]
00007b4681bcf182  pinsrb xmm1, r14d, 0x00
00007b4681bcf189  lea r14, [rax+0x01]
00007b4681bcf18d  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf193  movaps xmm15, [r15+0x120]
00007b4681bcf19b  pinsrb xmm15, r12d, 0x00
00007b4681bcf1a2  lea r14, [rax+0x02]
00007b4681bcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf1ac  movaps xmm14, [r15+0x130]
00007b4681bcf1b4  pinsrb xmm14, r12d, 0x00
00007b4681bcf1bb  lea r14, [rax+0x03]
00007b4681bcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf1c5  movaps xmm13, [r15+0x140]
00007b4681bcf1cd  pinsrb xmm13, r12d, 0x00
00007b4681bcf1d4  lea r14, [rax+0x04]
00007b4681bcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf1de  pinsrb xmm1, r12d, 0x01
00007b4681bcf1e5  lea r14, [rax+0x05]
00007b4681bcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf1ef  pinsrb xmm15, r12d, 0x01
00007b4681bcf1f6  lea r14, [rax+0x06]
00007b4681bcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf200  pinsrb xmm14, r12d, 0x01
00007b4681bcf207  lea r14, [rax+0x07]
00007b4681bcf20b  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf211  pinsrb xmm13, r12d, 0x01
00007b4681bcf218  lea r14, [rax+0x08]
00007b4681bcf21c  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf222  pinsrb xmm1, r12d, 0x02
00007b4681bcf229  lea r14, [rax+0x09]
00007b4681bcf22d  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf233  pinsrb xmm15, r12d, 0x02
00007b4681bcf23a  lea r14, [rax+0x0A]
00007b4681bcf23e  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf244  pinsrb xmm14, r12d, 0x02
00007b4681bcf24b  lea r14, [rax+0x0B]
00007b4681bcf24f  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf255  pinsrb xmm13, r12d, 0x02
00007b4681bcf25c  lea r14, [rax+0x0C]
00007b4681bcf260  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf266  pinsrb xmm1, r12d, 0x03
00007b4681bcf26d  lea r14, [rax+0x0D]
00007b4681bcf271  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf277  pinsrb xmm15, r12d, 0x03
00007b4681bcf27e  lea r14, [rax+0x0E]
00007b4681bcf282  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf288  pinsrb xmm14, r12d, 0x03
00007b4681bcf28f  lea r14, [rax+0x0F]
00007b4681bcf293  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf299  pinsrb xmm13, r12d, 0x03
00007b4681bcf2a0  lea r14, [rax+0x10]
00007b4681bcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf2aa  pinsrb xmm1, r12d, 0x04
00007b4681bcf2b1  lea r14, [rax+0x11]
00007b4681bcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf2bb  pinsrb xmm15, r12d, 0x04
00007b4681bcf2c2  lea r14, [rax+0x12]
00007b4681bcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf2cc  pinsrb xmm14, r12d, 0x04
00007b4681bcf2d3  lea r14, [rax+0x13]
00007b4681bcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf2dd  pinsrb xmm13, r12d, 0x04
00007b4681bcf2e4  lea r14, [rax+0x14]
00007b4681bcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf2ee  pinsrb xmm1, r12d, 0x05
00007b4681bcf2f5  lea r14, [rax+0x15]
00007b4681bcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf2ff  pinsrb xmm15, r12d, 0x05
00007b4681bcf306  lea r14, [rax+0x16]
00007b4681bcf30a  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf310  pinsrb xmm14, r12d, 0x05
00007b4681bcf317  lea r14, [rax+0x17]
00007b4681bcf31b  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf321  pinsrb xmm13, r12d, 0x05
00007b4681bcf328  lea r14, [rax+0x18]
00007b4681bcf32c  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf332  pinsrb xmm1, r12d, 0x06
00007b4681bcf339  lea r14, [rax+0x19]
00007b4681bcf33d  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf343  pinsrb xmm15, r12d, 0x06
00007b4681bcf34a  lea r14, [rax+0x1A]
00007b4681bcf34e  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf354  pinsrb xmm14, r12d, 0x06
00007b4681bcf35b  lea r14, [rax+0x1B]
00007b4681bcf35f  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf365  pinsrb xmm13, r12d, 0x06
00007b4681bcf36c  lea r14, [rax+0x1C]
00007b4681bcf370  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf376  pinsrb xmm1, r12d, 0x07
00007b4681bcf37d  lea r14, [rax+0x1D]
00007b4681bcf381  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf387  pinsrb xmm15, r12d, 0x07
00007b4681bcf38e  lea r14, [rax+0x1E]
00007b4681bcf392  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf398  pinsrb xmm14, r12d, 0x07
00007b4681bcf39f  lea r14, [rax+0x1F]
00007b4681bcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf3a9  pinsrb xmm13, r12d, 0x07
00007b4681bcf3b0  lea r14, [rax+0x20]
00007b4681bcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf3ba  pinsrb xmm1, r12d, 0x08
00007b4681bcf3c1  lea r14, [rax+0x21]
00007b4681bcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf3cb  pinsrb xmm15, r12d, 0x08
00007b4681bcf3d2  lea r14, [rax+0x22]
00007b4681bcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf3dc  pinsrb xmm14, r12d, 0x08
00007b4681bcf3e3  lea r14, [rax+0x23]
00007b4681bcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf3ed  pinsrb xmm13, r12d, 0x08
00007b4681bcf3f4  lea r14, [rax+0x24]
00007b4681bcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf3fe  pinsrb xmm1, r12d, 0x09
00007b4681bcf405  lea r14, [rax+0x25]
00007b4681bcf409  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf40f  pinsrb xmm15, r12d, 0x09
00007b4681bcf416  lea r14, [rax+0x26]
00007b4681bcf41a  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf420  pinsrb xmm14, r12d, 0x09
00007b4681bcf427  lea r14, [rax+0x27]
00007b4681bcf42b  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf431  pinsrb xmm13, r12d, 0x09
00007b4681bcf438  lea r14, [rax+0x28]
00007b4681bcf43c  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf442  pinsrb xmm1, r12d, 0x0A
00007b4681bcf449  lea r14, [rax+0x29]
00007b4681bcf44d  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf453  pinsrb xmm15, r12d, 0x0A
00007b4681bcf45a  lea r14, [rax+0x2A]
00007b4681bcf45e  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf464  pinsrb xmm14, r12d, 0x0A
00007b4681bcf46b  lea r14, [rax+0x2B]
00007b4681bcf46f  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf475  pinsrb xmm13, r12d, 0x0A
00007b4681bcf47c  lea r14, [rax+0x2C]
00007b4681bcf480  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf486  pinsrb xmm1, r12d, 0x0B
00007b4681bcf48d  lea r14, [rax+0x2D]
00007b4681bcf491  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf497  pinsrb xmm15, r12d, 0x0B
00007b4681bcf49e  lea r14, [rax+0x2E]
00007b4681bcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf4a8  pinsrb xmm14, r12d, 0x0B
00007b4681bcf4af  lea r14, [rax+0x2F]
00007b4681bcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf4b9  pinsrb xmm13, r12d, 0x0B
00007b4681bcf4c0  lea r14, [rax+0x30]
00007b4681bcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf4ca  pinsrb xmm1, r12d, 0x0C
00007b4681bcf4d1  lea r14, [rax+0x31]
00007b4681bcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf4db  pinsrb xmm15, r12d, 0x0C
00007b4681bcf4e2  lea r14, [rax+0x32]
00007b4681bcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf4ec  pinsrb xmm14, r12d, 0x0C
00007b4681bcf4f3  lea r14, [rax+0x33]
00007b4681bcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf4fd  pinsrb xmm13, r12d, 0x0C
00007b4681bcf504  lea r14, [rax+0x34]
00007b4681bcf508  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf50e  pinsrb xmm1, r12d, 0x0D
00007b4681bcf515  lea r14, [rax+0x35]
00007b4681bcf519  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf51f  pinsrb xmm15, r12d, 0x0D
00007b4681bcf526  lea r14, [rax+0x36]
00007b4681bcf52a  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf530  pinsrb xmm14, r12d, 0x0D
00007b4681bcf537  lea r14, [rax+0x37]
00007b4681bcf53b  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf541  pinsrb xmm13, r12d, 0x0D
00007b4681bcf548  lea r14, [rax+0x38]
00007b4681bcf54c  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf552  pinsrb xmm1, r12d, 0x0E
00007b4681bcf559  lea r14, [rax+0x39]
00007b4681bcf55d  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf563  pinsrb xmm15, r12d, 0x0E
00007b4681bcf56a  lea r14, [rax+0x3A]
00007b4681bcf56e  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf574  pinsrb xmm14, r12d, 0x0E
00007b4681bcf57b  lea r14, [rax+0x3B]
00007b4681bcf57f  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf585  pinsrb xmm13, r12d, 0x0E
00007b4681bcf58c  lea r14, [rax+0x3C]
00007b4681bcf590  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf596  pinsrb xmm1, r12d, 0x0F
00007b4681bcf59d  movaps [r15+0x110], xmm1
00007b4681bcf5a5  lea r14, [rax+0x3D]
00007b4681bcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf5af  pinsrb xmm15, r12d, 0x0F
00007b4681bcf5b6  movaps [r15+0x120], xmm15
00007b4681bcf5be  lea r14, [rax+0x3E]
00007b4681bcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007b4681bcf5c8  pinsrb xmm14, r12d, 0x0F
00007b4681bcf5cf  movaps [r15+0x130], xmm14
00007b4681bcf5d7  lea r14, [rax+0x3F]
00007b4681bcf5db  movzx eax, byte ptr [r13+r14*1]
00007b4681bcf5e1  pinsrb xmm13, eax, 0x0F
00007b4681bcf5e8  movaps [r15+0x140], xmm13
00007b4681bcf5f0  movq xmm1, qword ptr [r15+0x120]
00007b4681bcf5f9  pmovzxbw xmm1, xmm1
00007b4681bcf5fe  psllw xmm1, 0x00
00007b4681bcf603  movaps [r15+0x150], xmm1
00007b4681bcf60b  movq xmm1, qword ptr [r15+0x130]
00007b4681bcf614  pmovzxbw xmm1, xmm1
00007b4681bcf619  psllw xmm1, 0x00
00007b4681bcf61e  movaps [r15+0x160], xmm1
00007b4681bcf626  movq xmm1, qword ptr [r15+0x110]
00007b4681bcf62f  pmovzxbw xmm1, xmm1
00007b4681bcf634  psllw xmm1, 0x00
00007b4681bcf639  movaps [r15+0x170], xmm1
00007b4681bcf641  movaps xmm15, [r15+0x110]
00007b4681bcf649  pextrq rax, xmm15, 0x01
00007b4681bcf650  movq xmm15, rax
00007b4681bcf655  pmovzxbw xmm15, xmm15
00007b4681bcf65b  psllw xmm15, 0x00
00007b4681bcf661  movaps [r15+0x180], xmm15
00007b4681bcf669  movaps xmm14, [r15+0x120]
00007b4681bcf671  pextrq rax, xmm14, 0x01
00007b4681bcf678  movq xmm14, rax
00007b4681bcf67d  pmovzxbw xmm14, xmm14
00007b4681bcf683  psllw xmm14, 0x00
00007b4681bcf689  movaps [r15+0x210], xmm14
00007b4681bcf691  movaps xmm13, [r15+0x130]
00007b4681bcf699  pextrq rax, xmm13, 0x01
00007b4681bcf6a0  movq xmm13, rax
00007b4681bcf6a5  pmovzxbw xmm13, xmm13
00007b4681bcf6ab  psllw xmm13, 0x00
00007b4681bcf6b1  movaps [r15+0x220], xmm13
00007b4681bcf6b9  movq xmm12, qword ptr [r15+0x140]
00007b4681bcf6c2  pmovzxbw xmm12, xmm12
00007b4681bcf6c8  psllw xmm12, 0x00
00007b4681bcf6ce  movaps [r15+0x250], xmm12
00007b4681bcf6d6  movaps xmm12, [r15+0x140]
00007b4681bcf6de  pextrq rax, xmm12, 0x01
00007b4681bcf6e5  movq xmm12, rax
00007b4681bcf6ea  pmovzxbw xmm12, xmm12
00007b4681bcf6f0  psllw xmm12, 0x00
00007b4681bcf6f6  movaps [r15+0x110], xmm12
00007b4681bcf6fe  movq xmm11, qword ptr [r15+0x150]
00007b4681bcf707  pmovzxwd xmm11, xmm11
00007b4681bcf70d  pslld xmm11, 0x10
00007b4681bcf713  movq xmm10, qword ptr [r15+0x160]
00007b4681bcf71c  pmovzxwd xmm10, xmm10
00007b4681bcf722  pslld xmm10, 0x08
00007b4681bcf728  pextrq rax, xmm1, 0x01
00007b4681bcf72f  movq xmm1, rax
00007b4681bcf734  pmovzxwd xmm1, xmm1
00007b4681bcf739  pslld xmm1, 0x00
00007b4681bcf73e  movaps [r15+0x260], xmm1
00007b4681bcf746  pextrq rax, xmm15, 0x01
00007b4681bcf74d  movq xmm15, rax
00007b4681bcf752  pmovzxwd xmm15, xmm15
00007b4681bcf758  pslld xmm15, 0x00
00007b4681bcf75e  movaps [r15+0x270], xmm15
00007b4681bcf766  movq xmm9, qword ptr [r15+0x170]
00007b4681bcf76f  pmovzxwd xmm9, xmm9
00007b4681bcf775  pslld xmm9, 0x00
00007b4681bcf77b  pextrq rax, xmm14, 0x01
00007b4681bcf782  movq xmm14, rax
00007b4681bcf787  pmovzxwd xmm14, xmm14
00007b4681bcf78d  pslld xmm14, 0x10
00007b4681bcf793  movaps [r15+0x280], xmm14
00007b4681bcf79b  movq xmm8, qword ptr [r15+0x180]
00007b4681bcf7a4  pmovzxwd xmm8, xmm8
00007b4681bcf7aa  pslld xmm8, 0x00
00007b4681bcf7b0  movq xmm7, qword ptr [r15+0x210]
00007b4681bcf7b9  pmovzxwd xmm7, xmm7
00007b4681bcf7be  pslld xmm7, 0x10
00007b4681bcf7c3  movaps xmm6, [r15+0x150]
00007b4681bcf7cb  pextrq rax, xmm6, 0x01
00007b4681bcf7d2  movq xmm6, rax
00007b4681bcf7d7  pmovzxwd xmm6, xmm6
00007b4681bcf7dc  pslld xmm6, 0x10
00007b4681bcf7e1  por xmm11, xmm10
00007b4681bcf7e6  movaps [r15+0x230], xmm11
00007b4681bcf7ee  pextrq rax, xmm13, 0x01
00007b4681bcf7f5  movq xmm13, rax
00007b4681bcf7fa  pmovzxwd xmm13, xmm13
00007b4681bcf800  pslld xmm13, 0x08
00007b4681bcf806  movaps [r15+0x240], xmm13
00007b4681bcf80e  movq xmm10, qword ptr [r15+0x220]
00007b4681bcf817  pmovzxwd xmm10, xmm10
00007b4681bcf81d  pslld xmm10, 0x08
00007b4681bcf823  movaps xmm5, [r15+0x160]
00007b4681bcf82b  pextrq rax, xmm5, 0x01
00007b4681bcf832  movq xmm5, rax
00007b4681bcf837  pmovzxwd xmm5, xmm5
00007b4681bcf83c  pslld xmm5, 0x08
00007b4681bcf841  pslld xmm9, 0x18
00007b4681bcf847  pslld xmm15, 0x18
00007b4681bcf84d  pslld xmm8, 0x18
00007b4681bcf853  movq xmm4, qword ptr [r15+0x250]
00007b4681bcf85c  pmovzxwd xmm4, xmm4
00007b4681bcf861  pslld xmm4, 0x00
00007b4681bcf866  por xmm14, xmm13
00007b4681bcf86b  por xmm7, xmm10
00007b4681bcf870  movaps [r15+0x210], xmm7
00007b4681bcf878  pslld xmm1, 0x18
00007b4681bcf87d  movaps [r15+0x220], xmm1
00007b4681bcf885  por xmm6, xmm5
00007b4681bcf889  por xmm11, xmm9
00007b4681bcf88e  movaps [r15+0x160], xmm11
00007b4681bcf896  pextrq rax, xmm12, 0x01
00007b4681bcf89d  movq xmm13, rax
00007b4681bcf8a2  pmovzxwd xmm13, xmm13
00007b4681bcf8a8  pslld xmm13, 0x00
00007b4681bcf8ae  movaps [r15+0x170], xmm13
00007b4681bcf8b6  movq xmm12, qword ptr [r15+0x110]
00007b4681bcf8bf  pmovzxwd xmm12, xmm12
00007b4681bcf8c5  pslld xmm12, 0x00
00007b4681bcf8cb  por xmm14, xmm15
00007b4681bcf8d0  por xmm7, xmm8
00007b4681bcf8d5  movaps xmm15, [r15+0x250]
00007b4681bcf8dd  pextrq rax, xmm15, 0x01
00007b4681bcf8e4  movq xmm15, rax
00007b4681bcf8e9  pmovzxwd xmm15, xmm15
00007b4681bcf8ef  pslld xmm15, 0x00
00007b4681bcf8f5  movaps [r15+0x180], xmm15
00007b4681bcf8fd  por xmm6, xmm1
00007b4681bcf901  movaps [r15+0x150], xmm6
00007b4681bcf909  por xmm11, xmm4
00007b4681bcf90e  movaps [r15+0x140], xmm11
00007b4681bcf916  por xmm7, xmm12
00007b4681bcf91b  movaps [r15+0x110], xmm7
00007b4681bcf923  por xmm14, xmm13
00007b4681bcf928  movaps [r15+0x120], xmm14
00007b4681bcf930  por xmm6, xmm15
00007b4681bcf935  movaps [r15+0x130], xmm6
00007b4681bcf93d  mov rax, [r15+0xF8]
00007b4681bcf944  lea r14, [rax+0x20]
00007b4681bcf948  movups [r13+r14*1], xmm7
00007b4681bcf94e  lea r14, [rax+0x30]
00007b4681bcf952  movups [r13+r14*1], xmm14
00007b4681bcf958  movups [r13+rax*1], xmm11
00007b4681bcf95e  lea r14, [rax+0x10]
00007b4681bcf962  movups [r13+r14*1], xmm6
00007b4681bcf968  mov r14d, [r13+rax*1]
00007b4681bcf96d  mov rax, [r15+0x48]
00007b4681bcf971  mov [r15+0x68], rax
00007b4681bcf975  mov qword ptr [r15+0x58], 0x04
00007b4681bcf97d  lea r12, [rax+0x04]
00007b4681bcf981  mov r11d, [r13+r12*1]
00007b4681bcf986  mov [rsp+0x10], r11d
00007b4681bcf98b  mov r11d, r11d
00007b4681bcf98e  mov [r15+0x70], r11
00007b4681bcf992  lea r12, [rax+0x38]
00007b4681bcf996  mov r11d, [r13+r12*1]
00007b4681bcf99b  lea r12, [rax+0x24]
00007b4681bcf99f  mov r10d, [r13+r12*1]
00007b4681bcf9a4  mov [rsp+0x20], r10d
00007b4681bcf9a9  mov r10d, r10d
00007b4681bcf9ac  mov [r15+0x90], r10
00007b4681bcf9b3  mov [rsp+0x30], rax
00007b4681bcf9b8  xor eax, eax
00007b4681bcf9ba  mov r12d, 0x04
00007b4681bcf9c0  mov r10d, 0xC0
00007b4681bcf9c6  cmp r12, r10
00007b4681bcf9c9  cmc
00007b4681bcf9ca  lahf
00007b4681bcf9cb  seto al
00007b4681bcf9ce  mov [r15+0x108], eax
00007b4681bcf9d5  mov eax, [rsp+0x10]
00007b4681bcf9d9  mov r12d, [rsp+0x10]
00007b4681bcf9de  shrd eax, r12d, 0x07
00007b4681bcf9e3  mov [rsp+0x10], r11d
00007b4681bcf9e8  mov r10d, [rsp+0x10]
00007b4681bcf9ed  shrd r11d, r10d, 0x11
00007b4681bcf9f2  mov r9d, [rsp+0x20]
00007b4681bcf9f7  lea r8d, [r9d+r14d*1]
00007b4681bcf9fc  rorx r14d, r12d, 0x12
00007b4681bcfa02  xor eax, r14d
00007b4681bcfa05  rorx r14d, r10d, 0x13
00007b4681bcfa0b  xor r11d, r14d
00007b4681bcfa0e  mov [rsp+0x10], r11d
00007b4681bcfa13  mov r11d, r11d
00007b4681bcfa16  mov [r15+0x88], r11
00007b4681bcfa1d  mov [rsp+0x20], r12d
00007b4681bcfa22  shr r12d, 0x03
00007b4681bcfa26  xor eax, r12d
00007b4681bcfa29  mov [rsp+0x40], eax
00007b4681bcfa2d  mov eax, eax
00007b4681bcfa2f  mov [r15+0x80], rax
00007b4681bcfa36  shr r10d, 0x0A
00007b4681bcfa3a  mov eax, [rsp+0x10]
00007b4681bcfa3e  xor eax, r10d
00007b4681bcfa41  mov [rsp+0x10], eax
00007b4681bcfa45  mov eax, eax
00007b4681bcfa47  mov [r15+0x78], rax
00007b4681bcfa4b  mov eax, [rsp+0x40]
00007b4681bcfa4f  lea r14d, [r8d+eax*1]
00007b4681bcfa54  mov eax, [rsp+0x10]
00007b4681bcfa58  lea r12d, [r14d+eax*1]
00007b4681bcfa5d  mov rax, [rsp+0x30]
00007b4681bcfa62  lea r14, [rax+0x40]
00007b4681bcfa66  mov [r13+r14*1], r12d
00007b4681bcfa6b  mov eax, [rsp+0x20]
00007b4681bcfa6f  mov eax, eax
00007b4681bcfa71  mov [r15+0x60], rax
00007b4681bcfa75  mov eax, [r15+0x108]
00007b4681bcfa7c  sahf
00007b4681bcfa7d  jnz 0x00007B4681BCFAAF
00007b4681bcfa7f  cmp dword ptr [r15+0x318], 0x00
00007b4681bcfa87  jz 0x00007B4681BCFF70
00007b4681bcfa8d  nop [rax+rax*1], ax
00007b4681bcfa96  nop [rax+rax*1], eax
00007b4681bcfa9e  mov eax, 0x410820
00007b4681bcfaa3  mov [r15+0x100], rax
00007b4681bcfaaa  jmp 0x00007B46819FE110
00007b4681bcfaaf  cmp dword ptr [r15+0x318], 0x00
00007b4681bcfab7  jz 0x00007B4681BCFDC0
00007b4681bcfabd  nop [rax+rax*1], ax
00007b4681bcfac6  nop [rax+rax*1], eax
00007b4681bcface  mov eax, 0x4107D8
00007b4681bcfad3  mov [r15+0x100], rax
00007b4681bcfada  jmp 0x00007B46819FE110
00007b4681bcfadf  int3
00007b4681bcfae0  call 0x00007B4681A0D860
00007b4681bcfae5  jmp 0x00007B4681BCF17A
00007b4681bcfaea  call 0x00007B4681AE2420
00007b4681bcfaef  jmp 0x00007B4681BCF193
00007b4681bcfaf4  call 0x00007B4681AE2420
00007b4681bcfaf9  jmp 0x00007B4681BCF1AC
00007b4681bcfafe  call 0x00007B4681AE2420
00007b4681bcfb03  jmp 0x00007B4681BCF1C5
00007b4681bcfb08  call 0x00007B4681AE2420
00007b4681bcfb0d  jmp 0x00007B4681BCF1DE
00007b4681bcfb12  call 0x00007B4681AE2420
00007b4681bcfb17  jmp 0x00007B4681BCF1EF
00007b4681bcfb1c  call 0x00007B4681AE2420
00007b4681bcfb21  jmp 0x00007B4681BCF200
00007b4681bcfb26  call 0x00007B4681AE2420
00007b4681bcfb2b  jmp 0x00007B4681BCF211
00007b4681bcfb30  call 0x00007B4681AE2420
00007b4681bcfb35  jmp 0x00007B4681BCF222
00007b4681bcfb3a  call 0x00007B4681AE2420
00007b4681bcfb3f  jmp 0x00007B4681BCF233
00007b4681bcfb44  call 0x00007B4681AE2420
00007b4681bcfb49  jmp 0x00007B4681BCF244
00007b4681bcfb4e  call 0x00007B4681AE2420
00007b4681bcfb53  jmp 0x00007B4681BCF255
00007b4681bcfb58  call 0x00007B4681AE2420
00007b4681bcfb5d  jmp 0x00007B4681BCF266
00007b4681bcfb62  call 0x00007B4681AE2420
00007b4681bcfb67  jmp 0x00007B4681BCF277
00007b4681bcfb6c  call 0x00007B4681AE2420
00007b4681bcfb71  jmp 0x00007B4681BCF288
00007b4681bcfb76  call 0x00007B4681AE2420
00007b4681bcfb7b  jmp 0x00007B4681BCF299
00007b4681bcfb80  call 0x00007B4681AE2420
00007b4681bcfb85  jmp 0x00007B4681BCF2AA
00007b4681bcfb8a  call 0x00007B4681AE2420
00007b4681bcfb8f  jmp 0x00007B4681BCF2BB
00007b4681bcfb94  call 0x00007B4681AE2420
00007b4681bcfb99  jmp 0x00007B4681BCF2CC
00007b4681bcfb9e  call 0x00007B4681AE2420
00007b4681bcfba3  jmp 0x00007B4681BCF2DD
00007b4681bcfba8  call 0x00007B4681AE2420
00007b4681bcfbad  jmp 0x00007B4681BCF2EE
00007b4681bcfbb2  call 0x00007B4681AE2420
00007b4681bcfbb7  jmp 0x00007B4681BCF2FF
00007b4681bcfbbc  call 0x00007B4681AE2420
00007b4681bcfbc1  jmp 0x00007B4681BCF310
00007b4681bcfbc6  call 0x00007B4681AE2420
00007b4681bcfbcb  jmp 0x00007B4681BCF321
00007b4681bcfbd0  call 0x00007B4681AE2420
00007b4681bcfbd5  jmp 0x00007B4681BCF332
00007b4681bcfbda  call 0x00007B4681AE2420
00007b4681bcfbdf  jmp 0x00007B4681BCF343
00007b4681bcfbe4  call 0x00007B4681AE2420
00007b4681bcfbe9  jmp 0x00007B4681BCF354
00007b4681bcfbee  call 0x00007B4681AE2420
00007b4681bcfbf3  jmp 0x00007B4681BCF365
00007b4681bcfbf8  call 0x00007B4681AE2420
00007b4681bcfbfd  jmp 0x00007B4681BCF376
00007b4681bcfc02  call 0x00007B4681AE2420
00007b4681bcfc07  jmp 0x00007B4681BCF387
00007b4681bcfc0c  call 0x00007B4681AE2420
00007b4681bcfc11  jmp 0x00007B4681BCF398
00007b4681bcfc16  call 0x00007B4681AE2420
00007b4681bcfc1b  jmp 0x00007B4681BCF3A9
00007b4681bcfc20  call 0x00007B4681AE2420
00007b4681bcfc25  jmp 0x00007B4681BCF3BA
00007b4681bcfc2a  call 0x00007B4681AE2420
00007b4681bcfc2f  jmp 0x00007B4681BCF3CB
00007b4681bcfc34  call 0x00007B4681AE2420
00007b4681bcfc39  jmp 0x00007B4681BCF3DC
00007b4681bcfc3e  call 0x00007B4681AE2420
00007b4681bcfc43  jmp 0x00007B4681BCF3ED
00007b4681bcfc48  call 0x00007B4681AE2420
00007b4681bcfc4d  jmp 0x00007B4681BCF3FE
00007b4681bcfc52  call 0x00007B4681AE2420
00007b4681bcfc57  jmp 0x00007B4681BCF40F
00007b4681bcfc5c  call 0x00007B4681AE2420
00007b4681bcfc61  jmp 0x00007B4681BCF420
00007b4681bcfc66  call 0x00007B4681AE2420
00007b4681bcfc6b  jmp 0x00007B4681BCF431
00007b4681bcfc70  call 0x00007B4681AE2420
00007b4681bcfc75  jmp 0x00007B4681BCF442
00007b4681bcfc7a  call 0x00007B4681AE2420
00007b4681bcfc7f  jmp 0x00007B4681BCF453
00007b4681bcfc84  call 0x00007B4681AE2420
00007b4681bcfc89  jmp 0x00007B4681BCF464
00007b4681bcfc8e  call 0x00007B4681AE2420
00007b4681bcfc93  jmp 0x00007B4681BCF475
00007b4681bcfc98  call 0x00007B4681AE2420
00007b4681bcfc9d  jmp 0x00007B4681BCF486
00007b4681bcfca2  call 0x00007B4681AE2420
00007b4681bcfca7  jmp 0x00007B4681BCF497
00007b4681bcfcac  call 0x00007B4681AE2420
00007b4681bcfcb1  jmp 0x00007B4681BCF4A8
00007b4681bcfcb6  call 0x00007B4681AE2420
00007b4681bcfcbb  jmp 0x00007B4681BCF4B9
00007b4681bcfcc0  call 0x00007B4681AE2420
00007b4681bcfcc5  jmp 0x00007B4681BCF4CA
00007b4681bcfcca  call 0x00007B4681AE2420
00007b4681bcfccf  jmp 0x00007B4681BCF4DB
00007b4681bcfcd4  call 0x00007B4681AE2420
00007b4681bcfcd9  jmp 0x00007B4681BCF4EC
00007b4681bcfcde  call 0x00007B4681AE2420
00007b4681bcfce3  jmp 0x00007B4681BCF4FD
00007b4681bcfce8  call 0x00007B4681AE2420
00007b4681bcfced  jmp 0x00007B4681BCF50E
00007b4681bcfcf2  call 0x00007B4681AE2420
00007b4681bcfcf7  jmp 0x00007B4681BCF51F
00007b4681bcfcfc  call 0x00007B4681AE2420
00007b4681bcfd01  jmp 0x00007B4681BCF530
00007b4681bcfd06  call 0x00007B4681AE2420
00007b4681bcfd0b  jmp 0x00007B4681BCF541
00007b4681bcfd10  call 0x00007B4681AE2420
00007b4681bcfd15  jmp 0x00007B4681BCF552
00007b4681bcfd1a  call 0x00007B4681AE2420
00007b4681bcfd1f  jmp 0x00007B4681BCF563
00007b4681bcfd24  call 0x00007B4681AE2420
00007b4681bcfd29  jmp 0x00007B4681BCF574
00007b4681bcfd2e  call 0x00007B4681AE2420
00007b4681bcfd33  jmp 0x00007B4681BCF585
00007b4681bcfd38  call 0x00007B4681AE2420
00007b4681bcfd3d  jmp 0x00007B4681BCF596
00007b4681bcfd42  call 0x00007B4681AE2420
00007b4681bcfd47  jmp 0x00007B4681BCF5AF
00007b4681bcfd4c  call 0x00007B4681AE2420
00007b4681bcfd51  jmp 0x00007B4681BCF5C8
00007b4681bcfd56  call 0x00007B4681AD5610
00007b4681bcfd5b  jmp 0x00007B4681BCF5E1
00007b4681bcfd60  call 0x00007B4681ADC580
00007b4681bcfd65  jmp 0x00007B4681BCF94E
00007b4681bcfd6a  call 0x00007B4681AE46C0
00007b4681bcfd6f  jmp 0x00007B4681BCF958
00007b4681bcfd74  call 0x00007B4681A09E90
00007b4681bcfd79  jmp 0x00007B4681BCF95E
00007b4681bcfd7e  call 0x00007B4681ADB310
00007b4681bcfd83  jmp 0x00007B4681BCF968
00007b4681bcfd88  call 0x00007B4681A0DAE0
00007b4681bcfd8d  jmp 0x00007B4681BCF96D
00007b4681bcfd92  call 0x00007B4681AC0230
00007b4681bcfd97  jmp 0x00007B4681BCF986
00007b4681bcfd9c  call 0x00007B4681AC0230
00007b4681bcfda1  jmp 0x00007B4681BCF99B
00007b4681bcfda6  call 0x00007B4681ABEFC0
00007b4681bcfdab  jmp 0x00007B4681BCF9A4
00007b4681bcfdb0  call 0x00007B4681AE2BA0
00007b4681bcfdb5  jmp 0x00007B4681BCFA6B
00007b4681bcfdba  int3
00007b4681bcfdbb  nop [rax+rax*1], eax
00007b4681bcfdc0  mov rax, [r15+0x48]
00007b4681bcfdc4  mov r14, [r15+0x58]
00007b4681bcfdc8  lea r12, [rax+r14*1]
00007b4681bcfdcc  mov [r15+0x68], r12
00007b4681bcfdd0  lea rax, [r14+0x04]
00007b4681bcfdd4  mov [r15+0x58], rax
00007b4681bcfdd8  lea r14, [r12+0x04]
00007b4681bcfddd  mov r11d, [r13+r14*1]
00007b4681bcfde2  mov [rsp+0x10], r11d
00007b4681bcfde7  mov r11d, r11d
00007b4681bcfdea  mov [r15+0x70], r11
00007b4681bcfdee  lea r14, [r12+0x38]
00007b4681bcfdf3  mov r11d, [r13+r14*1]
00007b4681bcfdf8  lea r14, [r12+0x24]
00007b4681bcfdfd  mov r10d, [r13+r14*1]
00007b4681bcfe02  mov [rsp+0x20], r10d
00007b4681bcfe07  mov r10d, r10d
00007b4681bcfe0a  mov [r15+0x90], r10
00007b4681bcfe11  mov [rsp+0x30], rax
00007b4681bcfe16  xor eax, eax
00007b4681bcfe18  mov r14, [rsp+0x30]
00007b4681bcfe1d  mov r10d, 0xC0
00007b4681bcfe23  cmp r14, r10
00007b4681bcfe26  cmc
00007b4681bcfe27  lahf
00007b4681bcfe28  seto al
00007b4681bcfe2b  mov [r15+0x108], eax
00007b4681bcfe32  mov eax, [rsp+0x10]
00007b4681bcfe36  mov r14d, [rsp+0x10]
00007b4681bcfe3b  shrd eax, r14d, 0x07
00007b4681bcfe40  mov [rsp+0x10], r11d
00007b4681bcfe45  mov r10d, [rsp+0x10]
00007b4681bcfe4a  shrd r11d, r10d, 0x11
00007b4681bcfe4f  mov r9d, [r15+0x60]
00007b4681bcfe53  mov r8d, [rsp+0x20]
00007b4681bcfe58  lea ebp, [r8d+r9d*1]
00007b4681bcfe5d  rorx r9d, r14d, 0x12
00007b4681bcfe63  xor eax, r9d
00007b4681bcfe66  rorx r9d, r10d, 0x13
00007b4681bcfe6c  xor r11d, r9d
00007b4681bcfe6f  mov [rsp+0x10], r11d
00007b4681bcfe74  mov r11d, r11d
00007b4681bcfe77  mov [r15+0x88], r11
00007b4681bcfe7e  mov [rsp+0x20], r14d
00007b4681bcfe83  shr r14d, 0x03
00007b4681bcfe87  xor eax, r14d
00007b4681bcfe8a  mov [rsp+0x30], eax
00007b4681bcfe8e  mov eax, eax
00007b4681bcfe90  mov [r15+0x80], rax
00007b4681bcfe97  shr r10d, 0x0A
00007b4681bcfe9b  mov eax, [rsp+0x10]
00007b4681bcfe9f  xor eax, r10d
00007b4681bcfea2  mov [rsp+0x10], eax
00007b4681bcfea6  mov eax, eax
00007b4681bcfea8  mov [r15+0x78], rax
00007b4681bcfeac  mov eax, [rsp+0x30]
00007b4681bcfeb0  lea r14d, [ebp+eax*1]
00007b4681bcfeb6  mov eax, [rsp+0x10]
00007b4681bcfeba  lea r11d, [r14d+eax*1]
00007b4681bcfebf  lea rax, [r12+0x40]
00007b4681bcfec4  mov [r13+rax*1], r11d
00007b4681bcfec9  mov eax, [rsp+0x20]
00007b4681bcfecd  mov eax, eax
00007b4681bcfecf  mov [r15+0x60], rax
00007b4681bcfed3  mov eax, [r15+0x108]
00007b4681bcfeda  sahf
00007b4681bcfedb  jnz 0x00007B4681BCFF0D
00007b4681bcfedd  cmp dword ptr [r15+0x318], 0x00
00007b4681bcfee5  jz 0x00007B4681BCFF70
00007b4681bcfeeb  nop [rax+rax*1], ax
00007b4681bcfef4  nop [rax+rax*1], eax
00007b4681bcfefc  mov eax, 0x410820
00007b4681bcff01  mov [r15+0x100], rax
00007b4681bcff08  jmp 0x00007B46819FE110
00007b4681bcff0d  cmp dword ptr [r15+0x318], 0x00
00007b4681bcff15  jz 0x00007B4681BCFDC0
00007b4681bcff1b  nop [rax+rax*1], ax
00007b4681bcff24  nop [rax+rax*1], eax
00007b4681bcff2c  mov eax, 0x4107D8
00007b4681bcff31  mov [r15+0x100], rax
00007b4681bcff38  jmp 0x00007B46819FE110
00007b4681bcff3d  int3
00007b4681bcff3e  call 0x00007B4681AE1430
00007b4681bcff43  jmp 0x00007B4681BCFDE2
00007b4681bcff48  call 0x00007B4681AE1430
00007b4681bcff4d  jmp 0x00007B4681BCFDF8
00007b4681bcff52  call 0x00007B4681AE01C0
00007b4681bcff57  jmp 0x00007B4681BCFE02
00007b4681bcff5c  call 0x00007B4681A0A860
00007b4681bcff61  jmp 0x00007B4681BCFEC9
00007b4681bcff66  int3
00007b4681bcff67  nop [rax+rax*1], ax
00007b4681bcff70  mov rax, [r15]
00007b4681bcff73  mov r14d, [r13+rax*1]
00007b4681bcff78  lea r12, [rax+0x04]
00007b4681bcff7c  mov r11d, [r13+r12*1]
00007b4681bcff81  mov [rsp+0x10], r14d
00007b4681bcff86  mov r14d, r14d
00007b4681bcff89  mov [r15+0x78], r14
00007b4681bcff8d  mov [rsp+0x20], r11d
00007b4681bcff92  mov r11d, r11d
00007b4681bcff95  mov [r15+0x80], r11
00007b4681bcff9c  lea r14, [rax+0x08]
00007b4681bcffa0  mov r12d, [r13+r14*1]
00007b4681bcffa5  lea r14, [rax+0x0C]
00007b4681bcffa9  mov r11d, [r13+r14*1]
00007b4681bcffae  mov [rsp+0x30], r12d
00007b4681bcffb3  mov r12d, r12d
00007b4681bcffb6  mov [r15+0x70], r12
00007b4681bcffba  mov [rsp+0x40], r11d
00007b4681bcffbf  mov r11d, r11d
00007b4681bcffc2  mov [r15+0x68], r11
00007b4681bcffc6  lea r14, [rax+0x18]
00007b4681bcffca  mov r12d, [r13+r14*1]
00007b4681bcffcf  lea r14, [rax+0x1C]
00007b4681bcffd3  mov r11d, [r13+r14*1]
00007b4681bcffd8  mov [rsp+0x50], r12d
00007b4681bcffdd  mov r12d, r12d
00007b4681bcffe0  mov [r15+0x58], r12
00007b4681bcffe4  mov [rsp+0x60], r11d
00007b4681bcffe9  mov r11d, r11d
00007b4681bcffec  mov [r15+0x60], r11
00007b4681bcfff0  lea r14, [rax+0x10]
00007b4681bcfff4  mov r12d, [r13+r14*1]
00007b4681bcfff9  lea r14, [rax+0x14]
00007b4681bcfffd  mov eax, [r13+r14*1]
00007b4681bd0002  mov [rsp+0x70], r12d
00007b4681bd0007  mov r12d, r12d
00007b4681bd000a  mov [r15+0x18], r12
00007b4681bd000e  mov [rsp+0x80], eax
00007b4681bd0015  mov eax, eax
00007b4681bd0017  mov [r15+0x90], rax
00007b4681bd001e  mov eax, [rsp+0x70]
00007b4681bd0022  mov eax, eax
00007b4681bd0024  mov [r15+0x30], rax
00007b4681bd0028  mov eax, [rsp+0x50]
00007b4681bd002c  mov eax, eax
00007b4681bd002e  mov [r15+0xA0], rax
00007b4681bd0035  mov eax, [rsp+0x30]
00007b4681bd0039  mov eax, eax
00007b4681bd003b  mov [r15+0x28], rax
00007b4681bd003f  mov eax, [rsp+0x20]
00007b4681bd0043  mov eax, eax
00007b4681bd0045  mov [r15+0x98], rax
00007b4681bd004c  mov eax, [rsp+0x10]
00007b4681bd0050  mov eax, eax
00007b4681bd0052  mov [r15+0x38], rax
00007b4681bd0056  mov eax, [rsp+0x70]
00007b4681bd005a  mov r14d, [rsp+0x70]
00007b4681bd005f  shrd eax, r14d, 0x06
00007b4681bd0064  mov [rsp+0x70], r14d
00007b4681bd0069  mov r12d, [rsp+0x80]
00007b4681bd0071  and r14d, r12d
00007b4681bd0074  mov r11d, [rsp+0x10]
00007b4681bd0079  mov r10d, [rsp+0x10]
00007b4681bd007e  shrd r11d, r10d, 0x02
00007b4681bd0083  mov [rsp+0x10], r12d
00007b4681bd0088  mov r12d, r12d
00007b4681bd008b  mov [r15+0x20], r12
00007b4681bd008f  mov r12, [r15+0x50]
00007b4681bd0093  mov r9d, [r13+r12*1]
00007b4681bd0098  mov r12d, [rsp+0x50]
00007b4681bd009d  mov r8d, [rsp+0x70]
00007b4681bd00a2  andn ebp, r8d, r12d
00007b4681bd00a7  mov edi, [rsp+0x60]
00007b4681bd00ab  lea esi, [r14d+edi*1]
00007b4681bd00b0  rorx r14d, r8d, 0x0B
00007b4681bd00b6  xor eax, r14d
00007b4681bd00b9  rorx r14d, r10d, 0x0D
00007b4681bd00bf  xor r11d, r14d
00007b4681bd00c2  lea edi, [esi+ebp*1]
00007b4681bd00c6  mov r14, [r15+0x48]
00007b4681bd00ca  mov ebp, [r13+r14*1]
00007b4681bd00cf  mov r14d, [rsp+0x30]
00007b4681bd00d4  mov esi, [rsp+0x20]
00007b4681bd00d8  and r14d, esi
00007b4681bd00db  mov [rsp+0x20], r14d
00007b4681bd00e0  mov r14d, r14d
00007b4681bd00e3  mov [r15+0xD8], r14
00007b4681bd00ea  lea r14d, [edi+r9d*1]
00007b4681bd00ef  mov r9d, [rsp+0x30]
00007b4681bd00f4  xor r9d, esi
00007b4681bd00f7  rorx edi, r8d, 0x19
00007b4681bd00fd  xor eax, edi
00007b4681bd00ff  and r9d, r10d
00007b4681bd0102  rorx edi, r10d, 0x16
00007b4681bd0108  xor r11d, edi
00007b4681bd010b  mov [rsp+0x30], r11d
00007b4681bd0110  mov r11d, r11d
00007b4681bd0113  mov [r15+0xD0], r11
00007b4681bd011a  lea r11d, [r14d+ebp*1]
00007b4681bd011f  mov r10d, [rsp+0x20]
00007b4681bd0124  xor r9d, r10d
00007b4681bd0127  lea r14d, [r11d+eax*1]
00007b4681bd012c  mov qword ptr [r15+0x88], 0x04
00007b4681bd0137  mov eax, [rsp+0x30]
00007b4681bd013b  lea r11d, [r9d+eax*1]
00007b4681bd0140  mov eax, [rsp+0x40]
00007b4681bd0144  lea r10d, [r14d+eax*1]
00007b4681bd0149  mov r10d, r10d
00007b4681bd014c  mov [r15+0xB8], r10
00007b4681bd0153  xor eax, eax
00007b4681bd0155  mov r10d, 0x04
00007b4681bd015b  mov r9d, 0x100
00007b4681bd0161  cmp r10, r9
00007b4681bd0164  cmc
00007b4681bd0165  lahf
00007b4681bd0166  seto al
00007b4681bd0169  mov [r15+0x108], eax
00007b4681bd0170  lea eax, [r11d+r14d*1]
00007b4681bd0175  mov eax, eax
00007b4681bd0177  mov [r15+0xA8], rax
00007b4681bd017e  mov r12d, r12d
00007b4681bd0181  mov [r15+0xB0], r12
00007b4681bd0188  mov eax, [rsp+0x10]
00007b4681bd018c  mov eax, eax
00007b4681bd018e  mov [r15+0xC0], rax
00007b4681bd0195  mov r8d, r8d
00007b4681bd0198  mov [r15+0xC8], r8
00007b4681bd019f  mov eax, [r15+0x108]
00007b4681bd01a6  sahf
00007b4681bd01a7  jnz 0x00007B4681BD01D9
00007b4681bd01a9  cmp dword ptr [r15+0x318], 0x00
00007b4681bd01b1  jz 0x00007B4681BD04A0
00007b4681bd01b7  nop [rax+rax*1], ax
00007b4681bd01c0  nop [rax+rax*1], eax
00007b4681bd01c8  mov eax, 0x4108E0
00007b4681bd01cd  mov [r15+0x100], rax
00007b4681bd01d4  jmp 0x00007B46819FE110
00007b4681bd01d9  cmp dword ptr [r15+0x318], 0x00
00007b4681bd01e1  jz 0x00007B4681BD0270
00007b4681bd01e7  nop [rax+rax*1], ax
00007b4681bd01f0  nop [rax+rax*1], eax
00007b4681bd01f8  mov eax, 0x410854
00007b4681bd01fd  mov [r15+0x100], rax
00007b4681bd0204  jmp 0x00007B46819FE110
00007b4681bd0209  int3
00007b4681bd020a  call 0x00007B4681A0DAE0
00007b4681bd020f  jmp 0x00007B4681BCFF78
00007b4681bd0214  call 0x00007B4681AC0230
00007b4681bd0219  jmp 0x00007B4681BCFF81
00007b4681bd021e  call 0x00007B4681AE26A0
00007b4681bd0223  jmp 0x00007B4681BCFFA5
00007b4681bd0228  call 0x00007B4681AE1430
00007b4681bd022d  jmp 0x00007B4681BCFFAE
00007b4681bd0232  call 0x00007B4681AE26A0
00007b4681bd0237  jmp 0x00007B4681BCFFCF
00007b4681bd023c  call 0x00007B4681AE1430
00007b4681bd0241  jmp 0x00007B4681BCFFD8
00007b4681bd0246  call 0x00007B4681AE26A0
00007b4681bd024b  jmp 0x00007B4681BCFFF9
00007b4681bd0250  call 0x00007B4681AD5890
00007b4681bd0255  jmp 0x00007B4681BD0002
00007b4681bd025a  call 0x00007B4681ABDD50
00007b4681bd025f  jmp 0x00007B4681BD0098
00007b4681bd0264  call 0x00007B4681ADA580
00007b4681bd0269  jmp 0x00007B4681BD00CF
00007b4681bd026e  int3
00007b4681bd026f  nop
00007b4681bd0270  mov eax, [r15+0xB8]
00007b4681bd0277  mov [rsp+0x10], eax
00007b4681bd027b  mov eax, eax
00007b4681bd027d  mov [r15+0x30], rax
00007b4681bd0281  mov eax, [r15+0xC0]
00007b4681bd0288  mov [rsp+0x20], eax
00007b4681bd028c  mov eax, eax
00007b4681bd028e  mov [r15+0xA0], rax
00007b4681bd0295  mov eax, [r15+0x28]
00007b4681bd0299  mov r14d, [r15+0x98]
00007b4681bd02a0  mov [rsp+0x30], r14d
00007b4681bd02a5  mov r14d, r14d
00007b4681bd02a8  mov [r15+0x28], r14
00007b4681bd02ac  mov r14d, [r15+0x38]
00007b4681bd02b0  mov [rsp+0x40], r14d
00007b4681bd02b5  mov r14d, r14d
00007b4681bd02b8  mov [r15+0x98], r14
00007b4681bd02bf  mov r14d, [r15+0xA8]
00007b4681bd02c6  mov [rsp+0x50], r14d
00007b4681bd02cb  mov r14d, r14d
00007b4681bd02ce  mov [r15+0x38], r14
00007b4681bd02d2  mov r14d, [rsp+0x10]
00007b4681bd02d7  mov r12d, [rsp+0x10]
00007b4681bd02dc  shrd r14d, r12d, 0x06
00007b4681bd02e1  mov r11d, [r15+0xC8]
00007b4681bd02e8  mov [rsp+0x10], r12d
00007b4681bd02ed  and r12d, r11d
00007b4681bd02f0  mov r10d, [rsp+0x50]
00007b4681bd02f5  mov r9d, [rsp+0x50]
00007b4681bd02fa  shrd r10d, r9d, 0x02
00007b4681bd02ff  mov [rsp+0x50], r11d
00007b4681bd0304  mov r11d, r11d
00007b4681bd0307  mov [r15+0x20], r11
00007b4681bd030b  mov r11, [r15+0x88]
00007b4681bd0312  mov r8, [r15+0x50]
00007b4681bd0316  lea rbp, [r8+r11*1]
00007b4681bd031a  mov r8d, [r13+rbp*1]
00007b4681bd031f  mov ebp, [rsp+0x20]
00007b4681bd0323  mov edi, [rsp+0x10]
00007b4681bd0327  andn esi, edi, ebp
00007b4681bd032c  mov edx, [r15+0xB0]
00007b4681bd0333  lea ecx, [r12d+edx*1]
00007b4681bd0338  rorx r12d, edi, 0x0B
00007b4681bd033e  xor r14d, r12d
00007b4681bd0341  rorx r12d, r9d, 0x0D
00007b4681bd0347  xor r10d, r12d
00007b4681bd034a  lea r12d, [ecx+esi*1]
00007b4681bd034f  mov rsi, [r15+0x48]
00007b4681bd0353  lea rdx, [rsi+r11*1]
00007b4681bd0357  mov esi, [r13+rdx*1]
00007b4681bd035c  mov edx, [rsp+0x30]
00007b4681bd0360  mov ecx, [rsp+0x40]
00007b4681bd0364  and edx, ecx
00007b4681bd0366  mov [rsp+0x10], edx
00007b4681bd036a  mov edx, edx
00007b4681bd036c  mov [r15+0xD8], rdx
00007b4681bd0373  lea edx, [r12d+r8d*1]
00007b4681bd0378  mov r12d, [rsp+0x30]
00007b4681bd037d  xor r12d, ecx
00007b4681bd0380  rorx r8d, edi, 0x19
00007b4681bd0386  xor r14d, r8d
00007b4681bd0389  and r12d, r9d
00007b4681bd038c  rorx r8d, r9d, 0x16
00007b4681bd0392  xor r10d, r8d
00007b4681bd0395  mov [rsp+0x20], r10d
00007b4681bd039a  mov r10d, r10d
00007b4681bd039d  mov [r15+0xD0], r10
00007b4681bd03a4  lea r10d, [edx+esi*1]
00007b4681bd03a9  mov r9d, [rsp+0x10]
00007b4681bd03ae  xor r12d, r9d
00007b4681bd03b1  lea r9d, [r10d+r14d*1]
00007b4681bd03b6  lea r14, [r11+0x04]
00007b4681bd03ba  mov [r15+0x88], r14
00007b4681bd03c1  mov r11d, [rsp+0x20]
00007b4681bd03c6  lea r10d, [r12d+r11d*1]
00007b4681bd03cb  lea r11d, [r9d+eax*1]
00007b4681bd03d0  mov r11d, r11d
00007b4681bd03d3  mov [r15+0xB8], r11
00007b4681bd03da  xor eax, eax
00007b4681bd03dc  mov r12d, 0x100
00007b4681bd03e2  cmp r14, r12
00007b4681bd03e5  cmc
00007b4681bd03e6  lahf
00007b4681bd03e7  seto al
00007b4681bd03ea  mov [r15+0x108], eax
00007b4681bd03f1  lea eax, [r10d+r9d*1]
00007b4681bd03f6  mov eax, eax
00007b4681bd03f8  mov [r15+0xA8], rax
00007b4681bd03ff  mov ebp, ebp
00007b4681bd0401  mov [r15+0xB0], rbp
00007b4681bd0408  mov eax, [rsp+0x50]
00007b4681bd040c  mov eax, eax
00007b4681bd040e  mov [r15+0xC0], rax
00007b4681bd0415  mov edi, edi
00007b4681bd0417  mov [r15+0xC8], rdi
00007b4681bd041e  mov eax, [r15+0x108]
00007b4681bd0425  sahf
00007b4681bd0426  jnz 0x00007B4681BD0458
00007b4681bd0428  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0430  jz 0x00007B4681BD04A0
00007b4681bd0436  nop [rax+rax*1], ax
00007b4681bd043f  nop [rax+rax*1], eax
00007b4681bd0447  mov eax, 0x4108E0
00007b4681bd044c  mov [r15+0x100], rax
00007b4681bd0453  jmp 0x00007B46819FE110
00007b4681bd0458  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0460  jz 0x00007B4681BD0270
00007b4681bd0466  nop [rax+rax*1], ax
00007b4681bd046f  nop [rax+rax*1], eax
00007b4681bd0477  mov eax, 0x410854
00007b4681bd047c  mov [r15+0x100], rax
00007b4681bd0483  jmp 0x00007B46819FE110
00007b4681bd0488  int3
00007b4681bd0489  call 0x00007B4681A49010
00007b4681bd048e  jmp 0x00007B4681BD031F
00007b4681bd0493  call 0x00007B4681A25930
00007b4681bd0498  jmp 0x00007B4681BD035C
00007b4681bd049d  int3
00007b4681bd049e  nop
00007b4681bd04a0  mov eax, [r15+0x98]
00007b4681bd04a7  mov r14d, [r15+0x70]
00007b4681bd04ab  lea r12d, [eax+r14d*1]
00007b4681bd04b0  mov eax, [r15+0x28]
00007b4681bd04b4  mov r14d, [r15+0x68]
00007b4681bd04b8  lea r11d, [eax+r14d*1]
00007b4681bd04bd  mov qword ptr [r15+0x88], 0x00
00007b4681bd04c8  mov eax, [r15+0xA8]
00007b4681bd04cf  mov r14d, [r15+0x78]
00007b4681bd04d3  lea r10d, [eax+r14d*1]
00007b4681bd04d8  mov [rsp+0x10], r10d
00007b4681bd04dd  mov r10d, r10d
00007b4681bd04e0  mov [r15+0x78], r10
00007b4681bd04e4  mov eax, [r15+0x38]
00007b4681bd04e8  mov r14d, [r15+0x80]
00007b4681bd04ef  lea r10d, [eax+r14d*1]
00007b4681bd04f4  mov [rsp+0x20], r10d
00007b4681bd04f9  mov r10d, r10d
00007b4681bd04fc  mov [r15+0x80], r10
00007b4681bd0503  mov rax, [r15]
00007b4681bd0506  lea r14, [rax+0x08]
00007b4681bd050a  mov [r13+r14*1], r12d
00007b4681bd050f  lea r14, [rax+0x0C]
00007b4681bd0513  mov [r13+r14*1], r11d
00007b4681bd0518  mov r14d, [r15+0xB8]
00007b4681bd051f  mov r12d, [r15+0x18]
00007b4681bd0523  lea r11d, [r14d+r12d*1]
00007b4681bd0528  mov [rsp+0x30], r11d
00007b4681bd052d  mov r11d, r11d
00007b4681bd0530  mov [r15+0x68], r11
00007b4681bd0534  mov r14d, [r15+0x30]
00007b4681bd0538  mov r12d, [r15+0x90]
00007b4681bd053f  lea r11d, [r14d+r12d*1]
00007b4681bd0544  mov [rsp+0x40], r11d
00007b4681bd0549  mov r11d, r11d
00007b4681bd054c  mov [r15+0x70], r11
00007b4681bd0550  mov r14d, [r15+0x20]
00007b4681bd0554  mov r12d, [r15+0x58]
00007b4681bd0558  lea r11d, [r14d+r12d*1]
00007b4681bd055d  mov [rsp+0x50], r11d
00007b4681bd0562  mov r11d, r11d
00007b4681bd0565  mov [r15+0x58], r11
00007b4681bd0569  mov r14d, [r15+0xA0]
00007b4681bd0570  mov r12d, [r15+0x60]
00007b4681bd0574  lea r11d, [r14d+r12d*1]
00007b4681bd0579  mov [rsp+0x60], r11d
00007b4681bd057e  mov r11d, r11d
00007b4681bd0581  mov [r15+0x60], r11
00007b4681bd0585  mov r14d, [rsp+0x10]
00007b4681bd058a  mov [r13+rax*1], r14d
00007b4681bd058f  lea r14, [rax+0x04]
00007b4681bd0593  mov r12d, [rsp+0x20]
00007b4681bd0598  mov [r13+r14*1], r12d
00007b4681bd059d  lea r14, [rax+0x10]
00007b4681bd05a1  mov r12d, [rsp+0x30]
00007b4681bd05a6  mov [r13+r14*1], r12d
00007b4681bd05ab  lea r14, [rax+0x14]
00007b4681bd05af  mov r12d, [rsp+0x40]
00007b4681bd05b4  mov [r13+r14*1], r12d
00007b4681bd05b9  lea r14, [rax+0x18]
00007b4681bd05bd  mov r12d, [rsp+0x50]
00007b4681bd05c2  mov [r13+r14*1], r12d
00007b4681bd05c7  lea r14, [rax+0x1C]
00007b4681bd05cb  mov r12d, [rsp+0x60]
00007b4681bd05d0  mov [r13+r14*1], r12d
00007b4681bd05d5  lea r14, [rax+0x68]
00007b4681bd05d9  xor eax, eax
00007b4681bd05db  mov [r13+r14*1], rax
00007b4681bd05e0  cmp dword ptr [r15+0x318], 0x00
00007b4681bd05e8  jz 0x00007B4681BCF0E0
00007b4681bd05ee  nop [rax+rax*1], ax
00007b4681bd05f7  nop [rax+rax*1], eax
00007b4681bd05ff  mov eax, 0x4106FC
00007b4681bd0604  mov [r15+0x100], rax
00007b4681bd060b  jmp 0x00007B46819FE110
00007b4681bd0610  int3
00007b4681bd0611  call 0x00007B4681AE2BA0
00007b4681bd0616  jmp 0x00007B4681BD050F
00007b4681bd061b  call 0x00007B4681AE1920
00007b4681bd0620  jmp 0x00007B4681BD0518
00007b4681bd0625  call 0x00007B4681A0DFE0
00007b4681bd062a  jmp 0x00007B4681BD058F
00007b4681bd062f  call 0x00007B4681AE2BA0
00007b4681bd0634  jmp 0x00007B4681BD059D
00007b4681bd0639  call 0x00007B4681AE2BA0
00007b4681bd063e  jmp 0x00007B4681BD05AB
00007b4681bd0643  call 0x00007B4681AE2BA0
00007b4681bd0648  jmp 0x00007B4681BD05B9
00007b4681bd064d  call 0x00007B4681AE2BA0
00007b4681bd0652  jmp 0x00007B4681BD05C7
00007b4681bd0657  call 0x00007B4681AE2BA0
00007b4681bd065c  jmp 0x00007B4681BD05D5
00007b4681bd0661  call 0x00007B4681AD5EB0
00007b4681bd0666  jmp 0x00007B4681BD05E0
00007b4681bd066b  int3
00007b4681bd066c  nop [rax], eax
00007b4681bd0670  mov rax, [r15+0xF8]
00007b4681bd0677  lea r14, [rax+0x140]
00007b4681bd067e  mov r12, [r13+r14*1]
00007b4681bd0683  lea r14, [rax+0x148]
00007b4681bd068a  mov r11, [r13+r14*1]
00007b4681bd068f  mov [r15+0xA0], r12
00007b4681bd0696  mov [r15+0x98], r11
00007b4681bd069d  lea r14, [rax+0x130]
00007b4681bd06a4  mov r12, [r13+r14*1]
00007b4681bd06a9  lea r14, [rax+0x138]
00007b4681bd06b0  mov r11, [r13+r14*1]
00007b4681bd06b5  mov [r15+0xB0], r12
00007b4681bd06bc  mov [r15+0xA8], r11
00007b4681bd06c3  lea r14, [rax+0x120]
00007b4681bd06ca  mov r12, [r13+r14*1]
00007b4681bd06cf  lea r14, [rax+0x128]
00007b4681bd06d6  mov r11, [r13+r14*1]
00007b4681bd06db  mov [r15+0xC0], r12
00007b4681bd06e2  mov [r15+0xB8], r11
00007b4681bd06e9  lea r14, [rax+0x110]
00007b4681bd06f0  mov r12, [r13+r14*1]
00007b4681bd06f5  lea r14, [rax+0x118]
00007b4681bd06fc  mov r11, [r13+r14*1]
00007b4681bd0701  mov [r15+0xD0], r12
00007b4681bd0708  mov [r15+0xC8], r11
00007b4681bd070f  lea r14, [rax+0x100]
00007b4681bd0716  mov r12, [r13+r14*1]
00007b4681bd071b  lea r14, [rax+0x108]
00007b4681bd0722  mov r11, [r13+r14*1]
00007b4681bd0727  mov [r15+0xE8], r12
00007b4681bd072e  mov [r15+0xD8], r11
00007b4681bd0735  lea r14, [rax+0x150]
00007b4681bd073c  mov [r15+0xF8], r14
00007b4681bd0743  mov rax, [r15+0xF0]
00007b4681bd074a  mov [r15+0x100], rax
00007b4681bd0751  jmp 0x00007B4681BCE5C0
00007b4681bd0756  int3
00007b4681bd0757  call 0x00007B4681AE27E0
00007b4681bd075c  jmp 0x00007B4681BD0683
00007b4681bd0761  call 0x00007B4681AE1570
00007b4681bd0766  jmp 0x00007B4681BD068F
00007b4681bd076b  call 0x00007B4681AE27E0
00007b4681bd0770  jmp 0x00007B4681BD06A9
00007b4681bd0775  call 0x00007B4681AE1570
00007b4681bd077a  jmp 0x00007B4681BD06B5
00007b4681bd077f  call 0x00007B4681AE27E0
00007b4681bd0784  jmp 0x00007B4681BD06CF
00007b4681bd0789  call 0x00007B4681AE1570
00007b4681bd078e  jmp 0x00007B4681BD06DB
00007b4681bd0793  call 0x00007B4681AE27E0
00007b4681bd0798  jmp 0x00007B4681BD06F5
00007b4681bd079d  call 0x00007B4681AE1570
00007b4681bd07a2  jmp 0x00007B4681BD0701
00007b4681bd07a7  call 0x00007B4681AE27E0
00007b4681bd07ac  jmp 0x00007B4681BD071B
00007b4681bd07b1  call 0x00007B4681AE1570
00007b4681bd07b6  jmp 0x00007B4681BD0727
00007b4681bd07bb  int3
00007b4681bd07bc  nop [rax], eax
00007b4681bd07c0  mov eax, [r15+0xA0]
00007b4681bd07c7  mov [rsp+0x10], eax
00007b4681bd07cb  xor eax, eax
00007b4681bd07cd  mov r14d, [rsp+0x10]
00007b4681bd07d2  sub r14d, 0x01
00007b4681bd07d6  cmc
00007b4681bd07d7  lahf
00007b4681bd07d8  seto al
00007b4681bd07db  mov [r15+0x108], eax
00007b4681bd07e2  mov r14d, r14d
00007b4681bd07e5  mov [r15+0xA0], r14
00007b4681bd07ec  mov eax, [r15+0x108]
00007b4681bd07f3  sahf
00007b4681bd07f4  jnz 0x00007B4681BD0826
00007b4681bd07f6  cmp dword ptr [r15+0x318], 0x00
00007b4681bd07fe  jz 0x00007B4681BD0900
00007b4681bd0804  nop [rax+rax*1], ax
00007b4681bd080d  nop [rax+rax*1], eax
00007b4681bd0815  mov eax, 0x41028C
00007b4681bd081a  mov [r15+0x100], rax
00007b4681bd0821  jmp 0x00007B46819FE110
00007b4681bd0826  cmp dword ptr [r15+0x318], 0x00
00007b4681bd082e  jz 0x00007B4681BD0860
00007b4681bd0834  nop [rax+rax*1], ax
00007b4681bd083d  nop [rax+rax*1], eax
00007b4681bd0845  mov eax, 0x410274
00007b4681bd084a  mov [r15+0x100], rax
00007b4681bd0851  jmp 0x00007B46819FE110
00007b4681bd0856  int3
00007b4681bd0857  int3
00007b4681bd0858  nop [rax+rax*1], eax
00007b4681bd0860  mov rax, [r15+0xF8]
00007b4681bd0867  lea r14, [rax+0xD0]
00007b4681bd086e  mov [r15], r14
00007b4681bd0871  mov rax, [r15+0x98]
00007b4681bd0878  mov [r15+0x08], rax
00007b4681bd087c  mov qword ptr [r15+0x10], 0x12C
00007b4681bd0884  mov qword ptr [r15+0xF0], 0x410284
00007b4681bd088f  mov r14d, [r15+0x320]
00007b4681bd0896  mov eax, 0x410284
00007b4681bd089b  mov rcx, 0x7B4681BD07C0
00007b4681bd08a5  mov [r15+r14*8+0x328], rax
00007b4681bd08ad  mov [r15+r14*8+0x368], rcx
00007b4681bd08b5  add r14d, 0x01
00007b4681bd08b9  and r14d, 0x07
00007b4681bd08bd  mov [r15+0x320], r14d
00007b4681bd08c4  cmp dword ptr [r15+0x318], 0x00
00007b4681bd08cc  jz 0x00007B4681BCED70
00007b4681bd08d2  nop [rax+rax*1], ax
00007b4681bd08db  nop [rax+rax*1], eax
00007b4681bd08e3  mov eax, 0x4106BC
00007b4681bd08e8  mov [r15+0x100], rax
00007b4681bd08ef  jmp 0x00007B46819FE110
00007b4681bd08f4  int3
00007b4681bd08f5  int3
00007b4681bd08f6  nop [rax+rax*1], ax
00007b4681bd08ff  nop
00007b4681bd0900  mov rax, [r15+0xF8]
00007b4681bd0907  lea r14, [rax+0xF0]
00007b4681bd090e  mov r12, [r13+r14*1]
00007b4681bd0913  mov [r15+0x98], r12
00007b4681bd091a  mov qword ptr [r15+0x40], 0x80
00007b4681bd0922  lea r14, [rax+0xD0]
00007b4681bd0929  mov [r15], r14
00007b4681bd092c  lea r14, [rax+0x14C]
00007b4681bd0933  mov [r15+0x08], r14
00007b4681bd0937  mov qword ptr [r15+0x10], 0x01
00007b4681bd093f  lea r14, [rax+0x14C]
00007b4681bd0946  mov eax, 0x80
00007b4681bd094b  mov [r13+r14*1], al
00007b4681bd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007b4681bd095b  mov r14d, [r15+0x320]
00007b4681bd0962  mov eax, 0x4102A8
00007b4681bd0967  mov rcx, 0x7B4681BD09E0
00007b4681bd0971  mov [r15+r14*8+0x328], rax
00007b4681bd0979  mov [r15+r14*8+0x368], rcx
00007b4681bd0981  add r14d, 0x01
00007b4681bd0985  and r14d, 0x07
00007b4681bd0989  mov [r15+0x320], r14d
00007b4681bd0990  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0998  jz 0x00007B4681BCED70
00007b4681bd099e  nop [rax+rax*1], ax
00007b4681bd09a7  nop [rax+rax*1], eax
00007b4681bd09af  mov eax, 0x4106BC
00007b4681bd09b4  mov [r15+0x100], rax
00007b4681bd09bb  jmp 0x00007B46819FE110
00007b4681bd09c0  int3
00007b4681bd09c1  call 0x00007B4681AE27E0
00007b4681bd09c6  jmp 0x00007B4681BD0913
00007b4681bd09cb  call 0x00007B4681AD5AF0
00007b4681bd09d0  jmp 0x00007B4681BD0950
00007b4681bd09d5  int3
00007b4681bd09d6  nop [rax+rax*1], ax
00007b4681bd09df  nop
00007b4681bd09e0  mov rax, [r15+0xF8]
00007b4681bd09e7  lea r14, [rax+0x138]
00007b4681bd09ee  mov r12, [r13+r14*1]
00007b4681bd09f3  mov [r15+0x40], r12
00007b4681bd09f7  lea r14, [rax+0x148]
00007b4681bd09fe  xor eax, eax
00007b4681bd0a00  mov [r13+r14*1], al
00007b4681bd0a05  xor eax, eax
00007b4681bd0a07  mov r14d, 0x38
00007b4681bd0a0d  cmp r12, r14
00007b4681bd0a10  cmc
00007b4681bd0a11  lahf
00007b4681bd0a12  seto al
00007b4681bd0a15  mov [r15+0x108], eax
00007b4681bd0a1c  mov eax, [r15+0x108]
00007b4681bd0a23  sahf
00007b4681bd0a24  jz 0x00007B4681BD0A56
00007b4681bd0a26  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0a2e  jz 0x00007B4681BD0AA0
00007b4681bd0a34  nop [rax+rax*1], ax
00007b4681bd0a3d  nop [rax+rax*1], eax
00007b4681bd0a45  mov eax, 0x4102B8
00007b4681bd0a4a  mov [r15+0x100], rax
00007b4681bd0a51  jmp 0x00007B46819FE110
00007b4681bd0a56  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0a5e  jz 0x00007B4681BD0BF0
00007b4681bd0a64  nop [rax+rax*1], ax
00007b4681bd0a6d  nop [rax+rax*1], eax
00007b4681bd0a75  mov eax, 0x4102D4
00007b4681bd0a7a  mov [r15+0x100], rax
00007b4681bd0a81  jmp 0x00007B46819FE110
00007b4681bd0a86  int3
00007b4681bd0a87  call 0x00007B4681AE27E0
00007b4681bd0a8c  jmp 0x00007B4681BD09F3
00007b4681bd0a91  call 0x00007B4681AD5AF0
00007b4681bd0a96  jmp 0x00007B4681BD0A05
00007b4681bd0a9b  int3
00007b4681bd0a9c  nop [rax], eax
00007b4681bd0aa0  mov rax, [r15+0xF8]
00007b4681bd0aa7  lea r14, [rax+0xD0]
00007b4681bd0aae  mov [r15], r14
00007b4681bd0ab1  lea r14, [rax+0x148]
00007b4681bd0ab8  mov [r15+0x08], r14
00007b4681bd0abc  mov qword ptr [r15+0x10], 0x01
00007b4681bd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007b4681bd0acf  mov r14d, [r15+0x320]
00007b4681bd0ad6  mov eax, 0x4102C8
00007b4681bd0adb  mov rcx, 0x7B4681BD0B40
00007b4681bd0ae5  mov [r15+r14*8+0x328], rax
00007b4681bd0aed  mov [r15+r14*8+0x368], rcx
00007b4681bd0af5  add r14d, 0x01
00007b4681bd0af9  and r14d, 0x07
00007b4681bd0afd  mov [r15+0x320], r14d
00007b4681bd0b04  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0b0c  jz 0x00007B4681BCED70
00007b4681bd0b12  nop [rax+rax*1], ax
00007b4681bd0b1b  nop [rax+rax*1], eax
00007b4681bd0b23  mov eax, 0x4106BC
00007b4681bd0b28  mov [r15+0x100], rax
00007b4681bd0b2f  jmp 0x00007B46819FE110
00007b4681bd0b34  int3
00007b4681bd0b35  int3
00007b4681bd0b36  nop [rax+rax*1], ax
00007b4681bd0b3f  nop
00007b4681bd0b40  mov rax, [r15+0xF8]
00007b4681bd0b47  lea r14, [rax+0x138]
00007b4681bd0b4e  mov rax, [r13+r14*1]
00007b4681bd0b53  mov [r15+0x40], rax
00007b4681bd0b57  mov [rsp+0x10], rax
00007b4681bd0b5c  xor eax, eax
00007b4681bd0b5e  mov r14, [rsp+0x10]
00007b4681bd0b63  mov r12d, 0x38
00007b4681bd0b69  cmp r14, r12
00007b4681bd0b6c  cmc
00007b4681bd0b6d  lahf
00007b4681bd0b6e  seto al
00007b4681bd0b71  mov [r15+0x108], eax
00007b4681bd0b78  mov eax, [r15+0x108]
00007b4681bd0b7f  sahf
00007b4681bd0b80  jnz 0x00007B4681BD0BB2
00007b4681bd0b82  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0b8a  jz 0x00007B4681BD0BF0
00007b4681bd0b90  nop [rax+rax*1], ax
00007b4681bd0b99  nop [rax+rax*1], eax
00007b4681bd0ba1  mov eax, 0x4102D4
00007b4681bd0ba6  mov [r15+0x100], rax
00007b4681bd0bad  jmp 0x00007B46819FE110
00007b4681bd0bb2  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0bba  jz 0x00007B4681BD0AA0
00007b4681bd0bc0  nop [rax+rax*1], ax
00007b4681bd0bc9  nop [rax+rax*1], eax
00007b4681bd0bd1  mov eax, 0x4102B8
00007b4681bd0bd6  mov [r15+0x100], rax
00007b4681bd0bdd  jmp 0x00007B46819FE110
00007b4681bd0be2  int3
00007b4681bd0be3  call 0x00007B4681AD59C0
00007b4681bd0be8  jmp 0x00007B4681BD0B53
00007b4681bd0bed  int3
00007b4681bd0bee  nop
00007b4681bd0bf0  mov rax, [r15+0x98]
00007b4681bd0bf7  rorx r14, rax, 0x3D
00007b4681bd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007b4681bd0c01  mov rax, [r15+0xF8]
00007b4681bd0c08  lea r12, [rax+0xD0]
00007b4681bd0c0f  mov [r15], r12
00007b4681bd0c12  lea r12, [rax+0x140]
00007b4681bd0c19  mov [r15+0x08], r12
00007b4681bd0c1d  mov qword ptr [r15+0x10], 0x08
00007b4681bd0c25  bswap r14
00007b4681bd0c28  mov [r15+0x40], r14
00007b4681bd0c2c  lea r12, [rax+0x140]
00007b4681bd0c33  mov [r13+r12*1], r14
00007b4681bd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007b4681bd0c43  mov r14d, [r15+0x320]
00007b4681bd0c4a  mov eax, 0x4102F0
00007b4681bd0c4f  mov rcx, 0x7B4681BD0CC0
00007b4681bd0c59  mov [r15+r14*8+0x328], rax
00007b4681bd0c61  mov [r15+r14*8+0x368], rcx
00007b4681bd0c69  add r14d, 0x01
00007b4681bd0c6d  and r14d, 0x07
00007b4681bd0c71  mov [r15+0x320], r14d
00007b4681bd0c78  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0c80  jz 0x00007B4681BCED70
00007b4681bd0c86  nop [rax+rax*1], ax
00007b4681bd0c8f  nop [rax+rax*1], eax
00007b4681bd0c97  mov eax, 0x4106BC
00007b4681bd0c9c  mov [r15+0x100], rax
00007b4681bd0ca3  jmp 0x00007B46819FE110
00007b4681bd0ca8  int3
00007b4681bd0ca9  call 0x00007B4681AC3FE0
00007b4681bd0cae  jmp 0x00007B4681BD0C38
00007b4681bd0cb3  int3
00007b4681bd0cb4  nop [rax+rax*1], ax
00007b4681bd0cbd  nop [rax], eax
00007b4681bd0cc0  mov rax, [r15+0xF8]
00007b4681bd0cc7  lea r14, [rax+0xD0]
00007b4681bd0cce  mov r12d, [r13+r14*1]
00007b4681bd0cd3  lea r14, [rax+0xD4]
00007b4681bd0cda  mov r11d, [r13+r14*1]
00007b4681bd0cdf  lea r14, [rax+0xD8]
00007b4681bd0ce6  mov r10d, [r13+r14*1]
00007b4681bd0ceb  lea r14, [rax+0xDC]
00007b4681bd0cf2  mov r9d, [r13+r14*1]
00007b4681bd0cf7  mov qword ptr [r15+0x48], 0x430C20
00007b4681bd0cff  mov qword ptr [r15+0xA0], 0x00
00007b4681bd0d0a  bswap r12d
00007b4681bd0d0d  bswap r11d
00007b4681bd0d10  mov qword ptr [r15+0x98], 0x430D8C
00007b4681bd0d1b  mov r14d, 0x430C20
00007b4681bd0d21  mov [r13+r14*1], r12d
00007b4681bd0d26  mov r14d, 0x430C24
00007b4681bd0d2c  mov [r13+r14*1], r11d
00007b4681bd0d31  bswap r10d
00007b4681bd0d34  bswap r9d
00007b4681bd0d37  lea r14, [rax+0xE0]
00007b4681bd0d3e  mov r12d, [r13+r14*1]
00007b4681bd0d43  lea r14, [rax+0xE4]
00007b4681bd0d4a  mov r11d, [r13+r14*1]
00007b4681bd0d4f  mov r14d, 0x430C28
00007b4681bd0d55  mov [r13+r14*1], r10d
00007b4681bd0d5a  mov r14d, 0x430C2C
00007b4681bd0d60  mov [r13+r14*1], r9d
00007b4681bd0d65  bswap r12d
00007b4681bd0d68  bswap r11d
00007b4681bd0d6b  mov [rsp+0x10], r11d
00007b4681bd0d70  mov r11d, r11d
00007b4681bd0d73  mov [r15+0x58], r11
00007b4681bd0d77  lea r14, [rax+0xE8]
00007b4681bd0d7e  mov r11d, [r13+r14*1]
00007b4681bd0d83  lea r14, [rax+0xEC]
00007b4681bd0d8a  mov eax, [r13+r14*1]
00007b4681bd0d8f  mov [rsp+0x20], eax
00007b4681bd0d93  mov eax, eax
00007b4681bd0d95  mov [r15+0x60], rax
00007b4681bd0d99  mov eax, 0x430C30
00007b4681bd0d9e  mov [r13+rax*1], r12d
00007b4681bd0da3  mov eax, 0x430C34
00007b4681bd0da8  mov r14d, [rsp+0x10]
00007b4681bd0dad  mov [r13+rax*1], r14d
00007b4681bd0db2  bswap r11d
00007b4681bd0db5  mov [rsp+0x10], r11d
00007b4681bd0dba  mov r11d, r11d
00007b4681bd0dbd  mov [r15+0x40], r11
00007b4681bd0dc1  mov eax, [rsp+0x20]
00007b4681bd0dc5  bswap eax
00007b4681bd0dc7  mov [rsp+0x20], eax
00007b4681bd0dcb  mov eax, eax
00007b4681bd0dcd  mov [r15+0x50], rax
00007b4681bd0dd1  mov eax, 0x430C38
00007b4681bd0dd6  mov r14d, [rsp+0x10]
00007b4681bd0ddb  mov [r13+rax*1], r14d
00007b4681bd0de0  mov eax, 0x430C3C
00007b4681bd0de5  mov r14d, [rsp+0x20]
00007b4681bd0dea  mov [r13+rax*1], r14d
00007b4681bd0def  mov eax, [r15+0xA0]
00007b4681bd0df6  lea r14d, [eax+0x11]
00007b4681bd0dfb  mov r14d, r14d
00007b4681bd0dfe  mov [r15], r14
00007b4681bd0e01  mov qword ptr [r15+0xF0], 0x41034C
00007b4681bd0e0c  mov r14d, [r15+0x320]
00007b4681bd0e13  mov eax, 0x41034C
00007b4681bd0e18  mov rcx, 0x7B4681BD0F90
00007b4681bd0e22  mov [r15+r14*8+0x328], rax
00007b4681bd0e2a  mov [r15+r14*8+0x368], rcx
00007b4681bd0e32  add r14d, 0x01
00007b4681bd0e36  and r14d, 0x07
00007b4681bd0e3a  mov [r15+0x320], r14d
00007b4681bd0e41  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0e49  jz 0x00007B4681BD0F20
00007b4681bd0e4f  nop [rax+rax*1], ax
00007b4681bd0e58  nop [rax+rax*1], eax
00007b4681bd0e60  mov eax, 0x410938
00007b4681bd0e65  mov [r15+0x100], rax
00007b4681bd0e6c  jmp 0x00007B46819FE110
00007b4681bd0e71  int3
00007b4681bd0e72  call 0x00007B4681AE26A0
00007b4681bd0e77  jmp 0x00007B4681BD0CD3
00007b4681bd0e7c  call 0x00007B4681AE1430
00007b4681bd0e81  jmp 0x00007B4681BD0CDF
00007b4681bd0e86  call 0x00007B4681AE01C0
00007b4681bd0e8b  jmp 0x00007B4681BD0CEB
00007b4681bd0e90  call 0x00007B4681ADEF50
00007b4681bd0e95  jmp 0x00007B4681BD0CF7
00007b4681bd0e9a  call 0x00007B4681AE2BA0
00007b4681bd0e9f  jmp 0x00007B4681BD0D26
00007b4681bd0ea4  call 0x00007B4681AE1920
00007b4681bd0ea9  jmp 0x00007B4681BD0D31
00007b4681bd0eae  call 0x00007B4681AE26A0
00007b4681bd0eb3  jmp 0x00007B4681BD0D43
00007b4681bd0eb8  call 0x00007B4681AE1430
00007b4681bd0ebd  jmp 0x00007B4681BD0D4F
00007b4681bd0ec2  call 0x00007B4681AE06B0
00007b4681bd0ec7  jmp 0x00007B4681BD0D5A
00007b4681bd0ecc  call 0x00007B4681ADF440
00007b4681bd0ed1  jmp 0x00007B4681BD0D65
00007b4681bd0ed6  call 0x00007B4681AE1430
00007b4681bd0edb  jmp 0x00007B4681BD0D83
00007b4681bd0ee0  call 0x00007B4681AD5890
00007b4681bd0ee5  jmp 0x00007B4681BD0D8F
00007b4681bd0eea  call 0x00007B4681A0BAE0
00007b4681bd0eef  jmp 0x00007B4681BD0DA3
00007b4681bd0ef4  call 0x00007B4681A0DFE0
00007b4681bd0ef9  jmp 0x00007B4681BD0DB2
00007b4681bd0efe  call 0x00007B4681A0DFE0
00007b4681bd0f03  jmp 0x00007B4681BD0DE0
00007b4681bd0f08  call 0x00007B4681A0DFE0
00007b4681bd0f0d  jmp 0x00007B4681BD0DEF
00007b4681bd0f12  int3
00007b4681bd0f13  nop [rax+rax*1], ax
00007b4681bd0f1c  nop [rax], eax
00007b4681bd0f20  mov eax, [r15]
00007b4681bd0f23  mov [rsp+0x10], eax
00007b4681bd0f27  shr eax, 0x10
00007b4681bd0f2a  mov r14d, [rsp+0x10]
00007b4681bd0f2f  xor r14d, eax
00007b4681bd0f32  imul r14d, r14d, 0x7FEB352D
00007b4681bd0f39  mov eax, 0x846CA68B
00007b4681bd0f3e  mov eax, eax
00007b4681bd0f40  mov [r15+0x48], rax
00007b4681bd0f44  mov [rsp+0x10], r14d
00007b4681bd0f49  shr r14d, 0x0F
00007b4681bd0f4d  mov eax, [rsp+0x10]
00007b4681bd0f51  xor eax, r14d
00007b4681bd0f54  imul eax, eax, 0x846CA68B
00007b4681bd0f5a  mov [rsp+0x10], eax
00007b4681bd0f5e  mov eax, eax
00007b4681bd0f60  mov [r15+0x40], rax
00007b4681bd0f64  mov eax, [rsp+0x10]
00007b4681bd0f68  shr eax, 0x10
00007b4681bd0f6b  mov r14d, [rsp+0x10]
00007b4681bd0f70  xor r14d, eax
00007b4681bd0f73  mov r14d, r14d
00007b4681bd0f76  mov [r15], r14
00007b4681bd0f79  mov rax, [r15+0xF0]
00007b4681bd0f80  mov [r15+0x100], rax
00007b4681bd0f87  jmp 0x00007B4681BCE5C0
00007b4681bd0f8c  int3
00007b4681bd0f8d  int3
00007b4681bd0f8e  nop
00007b4681bd0f90  mov rax, [r15+0xA0]
00007b4681bd0f97  mov [rsp+0x10], rax
00007b4681bd0f9c  shl rax, 0x02
00007b4681bd0fa0  mov r14, [r15+0x98]
00007b4681bd0fa7  lea r12, [r14+rax*1]
00007b4681bd0fab  mov eax, [r15]
00007b4681bd0fae  mov [r13+r12*1], eax
00007b4681bd0fb3  mov rax, [rsp+0x10]
00007b4681bd0fb8  lea r14, [rax+0x01]
00007b4681bd0fbc  mov [r15+0xA0], r14
00007b4681bd0fc3  xor eax, eax
00007b4681bd0fc5  mov r12d, 0x400
00007b4681bd0fcb  cmp r14, r12
00007b4681bd0fce  cmc
00007b4681bd0fcf  lahf
00007b4681bd0fd0  seto al
00007b4681bd0fd3  mov [r15+0x108], eax
00007b4681bd0fda  mov eax, [r15+0x108]
00007b4681bd0fe1  sahf
00007b4681bd0fe2  jnz 0x00007B4681BD1014
00007b4681bd0fe4  cmp dword ptr [r15+0x318], 0x00
00007b4681bd0fec  jz 0x00007B4681BD10E0
00007b4681bd0ff2  nop [rax+rax*1], ax
00007b4681bd0ffb  nop [rax+rax*1], eax
00007b4681bd1003  mov eax, 0x41035C
00007b4681bd1008  mov [r15+0x100], rax
00007b4681bd100f  jmp 0x00007B46819FE110
00007b4681bd1014  cmp dword ptr [r15+0x318], 0x00
00007b4681bd101c  jz 0x00007B4681BD1050
00007b4681bd1022  nop [rax+rax*1], ax
00007b4681bd102b  nop [rax+rax*1], eax
00007b4681bd1033  mov eax, 0x410344
00007b4681bd1038  mov [r15+0x100], rax
00007b4681bd103f  jmp 0x00007B46819FE110
00007b4681bd1044  int3
00007b4681bd1045  call 0x00007B4681AB4B70
00007b4681bd104a  jmp 0x00007B4681BD0FB3
00007b4681bd104f  int3
00007b4681bd1050  mov eax, [r15+0xA0]
00007b4681bd1057  lea r14d, [eax+0x11]
00007b4681bd105c  mov r14d, r14d
00007b4681bd105f  mov [r15], r14
00007b4681bd1062  mov qword ptr [r15+0xF0], 0x41034C
00007b4681bd106d  mov r14d, [r15+0x320]
00007b4681bd1074  mov eax, 0x41034C
00007b4681bd1079  mov rcx, 0x7B4681BD0F90
00007b4681bd1083  mov [r15+r14*8+0x328], rax
00007b4681bd108b  mov [r15+r14*8+0x368], rcx
00007b4681bd1093  add r14d, 0x01
00007b4681bd1097  and r14d, 0x07
00007b4681bd109b  mov [r15+0x320], r14d
00007b4681bd10a2  cmp dword ptr [r15+0x318], 0x00
00007b4681bd10aa  jz 0x00007B4681BD0F20
00007b4681bd10b0  nop [rax+rax*1], ax
00007b4681bd10b9  nop [rax+rax*1], eax
00007b4681bd10c1  mov eax, 0x410938
00007b4681bd10c6  mov [r15+0x100], rax
00007b4681bd10cd  jmp 0x00007B46819FE110
00007b4681bd10d2  int3
00007b4681bd10d3  int3
00007b4681bd10d4  nop [rax+rax*1], ax
00007b4681bd10dd  nop [rax], eax
00007b4681bd10e0  mov qword ptr [r15+0x40], 0x01
00007b4681bd10e8  cmp dword ptr [r15+0x318], 0x00
00007b4681bd10f0  jz 0x00007B4681BD1120
00007b4681bd10f6  nop [rax+rax*1], ax
00007b4681bd10ff  nop [rax+rax*1], eax
00007b4681bd1107  mov eax, 0x410378
00007b4681bd110c  mov [r15+0x100], rax
00007b4681bd1113  jmp 0x00007B46819FE110
00007b4681bd1118  int3
00007b4681bd1119  int3
00007b4681bd111a  nop [rax+rax*1], ax
00007b4681bd1120  mov rax, [r15+0x40]
00007b4681bd1124  mov [rsp+0x10], rax
00007b4681bd1129  shl rax, 0x02
00007b4681bd112d  mov r14, [r15+0x98]
00007b4681bd1134  lea r12, [r14+rax*1]
00007b4681bd1138  mov eax, [r13+r12*1]
00007b4681bd113d  mov [rsp+0x20], eax
00007b4681bd1141  mov eax, eax
00007b4681bd1143  mov [r15+0x48], rax
00007b4681bd1147  mov rax, [rsp+0x10]
00007b4681bd114c  mov [r15+0x50], rax
00007b4681bd1150  mov eax, [r15+0x50]
00007b4681bd1154  lea r12d, [eax-0x01]
00007b4681bd1159  mov r12d, r12d
00007b4681bd115c  mov [r15+0x58], r12
00007b4681bd1160  mov rax, [r15+0x58]
00007b4681bd1164  mov r12d, eax
00007b4681bd1167  mov r12d, r12d
00007b4681bd116a  shl r12, 0x02
00007b4681bd116e  lea rax, [r14+r12*1]
00007b4681bd1172  mov r14d, [r13+rax*1]
00007b4681bd1177  mov [rsp+0x10], r14d
00007b4681bd117c  mov r14d, r14d
00007b4681bd117f  mov [r15+0x60], r14
00007b4681bd1183  xor eax, eax
00007b4681bd1185  mov r14d, [rsp+0x10]
00007b4681bd118a  mov r12d, [rsp+0x20]
00007b4681bd118f  cmp r14d, r12d
00007b4681bd1192  cmc
00007b4681bd1193  lahf
00007b4681bd1194  seto al
00007b4681bd1197  mov [r15+0x108], eax
00007b4681bd119e  mov eax, [r15+0x108]
00007b4681bd11a5  sahf
00007b4681bd11a6  cmc
00007b4681bd11a7  jbe 0x00007B4681BD11D9
00007b4681bd11a9  cmp dword ptr [r15+0x318], 0x00
00007b4681bd11b1  jz 0x00007B4681BD1220
00007b4681bd11b7  nop [rax+rax*1], ax
00007b4681bd11c0  nop [rax+rax*1], eax
00007b4681bd11c8  mov eax, 0x410390
00007b4681bd11cd  mov [r15+0x100], rax
00007b4681bd11d4  jmp 0x00007B46819FE110
00007b4681bd11d9  cmp dword ptr [r15+0x318], 0x00
00007b4681bd11e1  jz 0x00007B4681BD14C0
00007b4681bd11e7  nop [rax+rax*1], ax
00007b4681bd11f0  nop [rax+rax*1], eax
00007b4681bd11f8  mov eax, 0x410368
00007b4681bd11fd  mov [r15+0x100], rax
00007b4681bd1204  jmp 0x00007B46819FE110
00007b4681bd1209  int3
00007b4681bd120a  call 0x00007B4681AB4690
00007b4681bd120f  jmp 0x00007B4681BD113D
00007b4681bd1214  call 0x00007B4681A0DAE0
00007b4681bd1219  jmp 0x00007B4681BD1177
00007b4681bd121e  int3
00007b4681bd121f  nop
00007b4681bd1220  mov rax, [r15+0x50]
00007b4681bd1224  mov [rsp+0x10], rax
00007b4681bd1229  shl rax, 0x02
00007b4681bd122d  mov r14, [r15+0x98]
00007b4681bd1234  lea r12, [r14+rax*1]
00007b4681bd1238  mov eax, [r15+0x60]
00007b4681bd123c  mov [r13+r12*1], eax
00007b4681bd1241  mov rax, [rsp+0x10]
00007b4681bd1246  lea r14, [rax-0x01]
00007b4681bd124a  mov [r15+0x50], r14
00007b4681bd124e  mov rax, [r15+0x58]
00007b4681bd1252  test rax, rax
00007b4681bd1255  setz al
00007b4681bd1258  movzx rax, al
00007b4681bd125c  mov [rsp+0x414], al
00007b4681bd1263  cmp byte ptr [rsp+0x414], 0x00
00007b4681bd126b  jz 0x00007B4681BD129D
00007b4681bd126d  cmp dword ptr [r15+0x318], 0x00
00007b4681bd1275  jz 0x00007B4681BD12E0
00007b4681bd127b  nop [rax+rax*1], ax
00007b4681bd1284  nop [rax+rax*1], eax
00007b4681bd128c  mov eax, 0x41039C
00007b4681bd1291  mov [r15+0x100], rax
00007b4681bd1298  jmp 0x00007B46819FE110
00007b4681bd129d  cmp dword ptr [r15+0x318], 0x00
00007b4681bd12a5  jz 0x00007B4681BD13E0
00007b4681bd12ab  nop [rax+rax*1], ax
00007b4681bd12b4  nop [rax+rax*1], eax
00007b4681bd12bc  mov eax, 0x410380
00007b4681bd12c1  mov [r15+0x100], rax
00007b4681bd12c8  jmp 0x00007B46819FE110
00007b4681bd12cd  int3
00007b4681bd12ce  call 0x00007B4681AB4B70
00007b4681bd12d3  jmp 0x00007B4681BD1241
00007b4681bd12d8  int3
00007b4681bd12d9  nop [rax], eax
00007b4681bd12e0  cmp dword ptr [r15+0x318], 0x00
00007b4681bd12e8  jz 0x00007B4681BD1320
00007b4681bd12ee  nop [rax+rax*1], ax
00007b4681bd12f7  nop [rax+rax*1], eax
00007b4681bd12ff  mov eax, 0x410364
00007b4681bd1304  mov [r15+0x100], rax
00007b4681bd130b  jmp 0x00007B46819FE110
00007b4681bd1310  int3
00007b4681bd1311  int3
00007b4681bd1312  nop [rax+rax*1], ax
00007b4681bd131b  nop [rax+rax*1], eax
00007b4681bd1320  mov qword ptr [r15+0x50], 0x00
00007b4681bd1328  mov rax, [r15+0x40]
00007b4681bd132c  lea r14, [rax+0x01]
00007b4681bd1330  mov [r15+0x40], r14
00007b4681bd1334  mov rax, [r15+0x98]
00007b4681bd133b  mov r12d, [r15+0x48]
00007b4681bd133f  mov [r13+rax*1], r12d
00007b4681bd1344  xor eax, eax
00007b4681bd1346  mov r12d, 0x400
00007b4681bd134c  cmp r14, r12
00007b4681bd134f  cmc
00007b4681bd1350  lahf
00007b4681bd1351  seto al
00007b4681bd1354  mov [r15+0x108], eax
00007b4681bd135b  mov eax, [r15+0x108]
00007b4681bd1362  sahf
00007b4681bd1363  jz 0x00007B4681BD1395
00007b4681bd1365  cmp dword ptr [r15+0x318], 0x00
00007b4681bd136d  jz 0x00007B4681BD1120
00007b4681bd1373  nop [rax+rax*1], ax
00007b4681bd137c  nop [rax+rax*1], eax
00007b4681bd1384  mov eax, 0x410378
00007b4681bd1389  mov [r15+0x100], rax
00007b4681bd1390  jmp 0x00007B46819FE110
00007b4681bd1395  cmp dword ptr [r15+0x318], 0x00
00007b4681bd139d  jz 0x00007B4681BD1580
00007b4681bd13a3  nop [rax+rax*1], ax
00007b4681bd13ac  nop [rax+rax*1], eax
00007b4681bd13b4  mov eax, 0x4103A0
00007b4681bd13b9  mov [r15+0x100], rax
00007b4681bd13c0  jmp 0x00007B46819FE110
00007b4681bd13c5  int3
00007b4681bd13c6  call 0x00007B4681A0BAE0
00007b4681bd13cb  jmp 0x00007B4681BD1344
00007b4681bd13d0  int3
00007b4681bd13d1  nop [rax+rax*1], ax
00007b4681bd13da  nop [rax+rax*1], ax
00007b4681bd13e0  mov eax, [r15+0x50]
00007b4681bd13e4  lea r14d, [eax-0x01]
00007b4681bd13e9  mov r14d, r14d
00007b4681bd13ec  mov [r15+0x58], r14
00007b4681bd13f0  mov rax, [r15+0x58]
00007b4681bd13f4  mov r14d, eax
00007b4681bd13f7  mov r14d, r14d
00007b4681bd13fa  shl r14, 0x02
00007b4681bd13fe  mov rax, [r15+0x98]
00007b4681bd1405  lea r12, [rax+r14*1]
00007b4681bd1409  mov eax, [r13+r12*1]
00007b4681bd140e  mov [rsp+0x10], eax
00007b4681bd1412  mov eax, eax
00007b4681bd1414  mov [r15+0x60], rax
00007b4681bd1418  mov eax, [r15+0x48]
00007b4681bd141c  mov [rsp+0x20], eax
00007b4681bd1420  xor eax, eax
00007b4681bd1422  mov r14d, [rsp+0x10]
00007b4681bd1427  mov r12d, [rsp+0x20]
00007b4681bd142c  cmp r14d, r12d
00007b4681bd142f  cmc
00007b4681bd1430  lahf
00007b4681bd1431  seto al
00007b4681bd1434  mov [r15+0x108], eax
00007b4681bd143b  mov eax, [r15+0x108]
00007b4681bd1442  sahf
00007b4681bd1443  cmc
00007b4681bd1444  jbe 0x00007B4681BD1476
00007b4681bd1446  cmp dword ptr [r15+0x318], 0x00
00007b4681bd144e  jz 0x00007B4681BD1220
00007b4681bd1454  nop [rax+rax*1], ax
00007b4681bd145d  nop [rax+rax*1], eax
00007b4681bd1465  mov eax, 0x410390
00007b4681bd146a  mov [r15+0x100], rax
00007b4681bd1471  jmp 0x00007B46819FE110
00007b4681bd1476  cmp dword ptr [r15+0x318], 0x00
00007b4681bd147e  jz 0x00007B4681BD14C0
00007b4681bd1484  nop [rax+rax*1], ax
00007b4681bd148d  nop [rax+rax*1], eax
00007b4681bd1495  mov eax, 0x410368
00007b4681bd149a  mov [r15+0x100], rax
00007b4681bd14a1  jmp 0x00007B46819FE110
00007b4681bd14a6  int3
00007b4681bd14a7  call 0x00007B4681AB4690
00007b4681bd14ac  jmp 0x00007B4681BD140E
00007b4681bd14b1  int3
00007b4681bd14b2  nop [rax+rax*1], ax
00007b4681bd14bb  nop [rax+rax*1], eax
00007b4681bd14c0  mov rax, [r15+0x40]
00007b4681bd14c4  lea r14, [rax+0x01]
00007b4681bd14c8  mov [r15+0x40], r14
00007b4681bd14cc  mov rax, [r15+0x50]
00007b4681bd14d0  mov r12d, eax
00007b4681bd14d3  mov r12d, r12d
00007b4681bd14d6  shl r12, 0x02
00007b4681bd14da  mov rax, [r15+0x98]
00007b4681bd14e1  lea r11, [rax+r12*1]
00007b4681bd14e5  mov eax, [r15+0x48]
00007b4681bd14e9  mov [r13+r11*1], eax
00007b4681bd14ee  xor eax, eax
00007b4681bd14f0  mov r12d, 0x400
00007b4681bd14f6  cmp r14, r12
00007b4681bd14f9  cmc
00007b4681bd14fa  lahf
00007b4681bd14fb  seto al
00007b4681bd14fe  mov [r15+0x108], eax
00007b4681bd1505  mov eax, [r15+0x108]
00007b4681bd150c  sahf
00007b4681bd150d  jz 0x00007B4681BD153F
00007b4681bd150f  cmp dword ptr [r15+0x318], 0x00
00007b4681bd1517  jz 0x00007B4681BD1120
00007b4681bd151d  nop [rax+rax*1], ax
00007b4681bd1526  nop [rax+rax*1], eax
00007b4681bd152e  mov eax, 0x410378
00007b4681bd1533  mov [r15+0x100], rax
00007b4681bd153a  jmp 0x00007B46819FE110
00007b4681bd153f  cmp dword ptr [r15+0x318], 0x00
00007b4681bd1547  jz 0x00007B4681BD1580
00007b4681bd154d  nop [rax+rax*1], ax
00007b4681bd1556  nop [rax+rax*1], eax
00007b4681bd155e  mov eax, 0x4103A0
00007b4681bd1563  mov [r15+0x100], rax
00007b4681bd156a  jmp 0x00007B46819FE110
00007b4681bd156f  int3
00007b4681bd1570  call 0x00007B4681AA4270
00007b4681bd1575  jmp 0x00007B4681BD14EE
00007b4681bd157a  int3
00007b4681bd157b  nop [rax+rax*1], eax
00007b4681bd1580  mov qword ptr [r15+0x40], 0x430000
00007b4681bd1588  mov eax, 0x430C40
00007b4681bd158d  mov r14, [r13+rax*1]
00007b4681bd1592  mov rax, [r15+0x98]
00007b4681bd1599  mov r12d, [r13+rax*1]
00007b4681bd159e  lea r11, [rax+0x04]
00007b4681bd15a2  mov eax, [r13+r11*1]
00007b4681bd15a7  mov r12d, r12d
00007b4681bd15aa  mov [r15+0x68], r12
00007b4681bd15ae  mov eax, eax
00007b4681bd15b0  mov [r15+0x60], rax
00007b4681bd15b4  mov rax, [r15+0x68]
00007b4681bd15b8  mov [r15+0x68], rax
00007b4681bd15bc  mov qword ptr [r15+0x58], 0x02
00007b4681bd15c4  mov [rsp+0x10], rax
00007b4681bd15c9  xor eax, eax
00007b4681bd15cb  mov r12d, 0x02
00007b4681bd15d1  mov r11d, 0x400
00007b4681bd15d7  cmp r12, r11
00007b4681bd15da  cmc
00007b4681bd15db  lahf
00007b4681bd15dc  seto al
00007b4681bd15df  mov [r15+0x108], eax
00007b4681bd15e6  mov rax, [r15+0x60]
00007b4681bd15ea  mov r12d, 0x02
00007b4681bd15f0  imul rax, r12
00007b4681bd15f4  mov [r15+0x50], rax
00007b4681bd15f8  mov rax, [rsp+0x10]
00007b4681bd15fd  lea r12, [rax+r14*1]
00007b4681bd1601  mov [r15+0x48], r12
00007b4681bd1605  mov eax, [r15+0x108]
00007b4681bd160c  sahf
00007b4681bd160d  jnz 0x00007B4681BD163F
00007b4681bd160f  cmp dword ptr [r15+0x318], 0x00
00007b4681bd1617  jz 0x00007B4681BD17B0
00007b4681bd161d  nop [rax+rax*1], ax
00007b4681bd1626  nop [rax+rax*1], eax
00007b4681bd162e  mov eax, 0x4103D0
00007b4681bd1633  mov [r15+0x100], rax
00007b4681bd163a  jmp 0x00007B46819FE110
00007b4681bd163f  cmp dword ptr [r15+0x318], 0x00
00007b4681bd1647  jz 0x00007B4681BD1690
00007b4681bd164d  nop [rax+rax*1], ax
00007b4681bd1656  nop [rax+rax*1], eax
00007b4681bd165e  mov eax, 0x4103B0
00007b4681bd1663  mov [r15+0x100], rax
00007b4681bd166a  jmp 0x00007B46819FE110
00007b4681bd166f  int3
00007b4681bd1670  call 0x00007B4681A0DC20
00007b4681bd1675  jmp 0x00007B4681BD1592
00007b4681bd167a  call 0x00007B4681A0B5E0
00007b4681bd167f  jmp 0x00007B4681BD159E
00007b4681bd1684  call 0x00007B4681AA3D90
00007b4681bd1689  jmp 0x00007B4681BD15A7
00007b4681bd168e  int3
00007b4681bd168f  nop
00007b4681bd1690  mov rax, [r15+0x98]
00007b4681bd1697  mov r14, [r15+0x58]
00007b4681bd169b  mov [rsp+0x10], r14
00007b4681bd16a0  shl r14, 0x02
00007b4681bd16a4  lea r12, [rax+r14*1]
00007b4681bd16a8  mov eax, [r13+r12*1]
00007b4681bd16ad  lea r14, [r12+0x04]
00007b4681bd16b2  mov r12d, [r13+r14*1]
00007b4681bd16b7  mov eax, eax
00007b4681bd16b9  mov [r15+0x68], rax
00007b4681bd16bd  mov r12d, r12d
00007b4681bd16c0  mov [r15+0x60], r12
00007b4681bd16c4  mov rax, [r15+0x68]
00007b4681bd16c8  mov [rsp+0x20], rax
00007b4681bd16cd  mov r14, [rsp+0x10]
00007b4681bd16d2  imul rax, r14
00007b4681bd16d6  mov r12, [rsp+0x20]
00007b4681bd16db  lea r11, [r12+rax*1]
00007b4681bd16df  mov [r15+0x68], r11
00007b4681bd16e3  lea rax, [r14+0x02]
00007b4681bd16e7  mov [r15+0x58], rax
00007b4681bd16eb  mov [rsp+0x10], rax
00007b4681bd16f0  xor eax, eax
00007b4681bd16f2  mov r14, [rsp+0x10]
00007b4681bd16f7  mov r12d, 0x400
00007b4681bd16fd  cmp r14, r12
00007b4681bd1700  cmc
00007b4681bd1701  lahf
00007b4681bd1702  seto al
00007b4681bd1705  mov [r15+0x108], eax
00007b4681bd170c  mov rax, [r15+0x50]
00007b4681bd1710  mov r12, [r15+0x60]
00007b4681bd1714  imul r14, r12
00007b4681bd1718  lea r12, [rax+r14*1]
00007b4681bd171c  mov [r15+0x50], r12
00007b4681bd1720  mov rax, [r15+0x48]
00007b4681bd1724  lea r14, [r11+rax*1]
00007b4681bd1728  mov [r15+0x48], r14
00007b4681bd172c  mov eax, [r15+0x108]
00007b4681bd1733  sahf
00007b4681bd1734  jnz 0x00007B4681BD1766
00007b4681bd1736  cmp dword ptr [r15+0x318], 0x00
00007b4681bd173e  jz 0x00007B4681BD17B0
00007b4681bd1744  nop [rax+rax*1], ax
00007b4681bd174d  nop [rax+rax*1], eax
00007b4681bd1755  mov eax, 0x4103D0
00007b4681bd175a  mov [r15+0x100], rax
00007b4681bd1761  jmp 0x00007B46819FE110
00007b4681bd1766  cmp dword ptr [r15+0x318], 0x00
00007b4681bd176e  jz 0x00007B4681BD1690
00007b4681bd1774  nop [rax+rax*1], ax
00007b4681bd177d  nop [rax+rax*1], eax
00007b4681bd1785  mov eax, 0x4103B0
00007b4681bd178a  mov [r15+0x100], rax
00007b4681bd1791  jmp 0x00007B46819FE110
00007b4681bd1796  int3
00007b4681bd1797  call 0x00007B4681AB4690
00007b4681bd179c  jmp 0x00007B4681BD16AD
00007b4681bd17a1  call 0x00007B4681AE26A0
00007b4681bd17a6  jmp 0x00007B4681BD16B7
00007b4681bd17ab  int3
00007b4681bd17ac  nop [rax], eax
00007b4681bd17b0  mov qword ptr [r15+0x98], 0x00
00007b4681bd17bb  mov rax, [r15+0x50]
00007b4681bd17bf  mov r14, [r15+0x48]
00007b4681bd17c3  lea r12, [rax+r14*1]
00007b4681bd17c7  mov [r15+0x48], r12
00007b4681bd17cb  mov rax, [r15+0x40]
00007b4681bd17cf  lea r14, [rax+0xC40]
00007b4681bd17d6  mov [r13+r14*1], r12
00007b4681bd17db  mov qword ptr [r15], 0x01
00007b4681bd17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007b4681bd17ed  mov r14d, [r15+0x320]
00007b4681bd17f4  mov eax, 0x4103E8
00007b4681bd17f9  mov rcx, 0x7B4681BD1860
00007b4681bd1803  mov [r15+r14*8+0x328], rax
00007b4681bd180b  mov [r15+r14*8+0x368], rcx
00007b4681bd1813  add r14d, 0x01
00007b4681bd1817  and r14d, 0x07
00007b4681bd181b  mov [r15+0x320], r14d
00007b4681bd1822  cmp dword ptr [r15+0x318], 0x00
00007b4681bd182a  jz 0x00007B4681BD0F20
00007b4681bd1830  nop [rax+rax*1], ax
00007b4681bd1839  nop [rax+rax*1], eax
00007b4681bd1841  mov eax, 0x410938
00007b4681bd1846  mov [r15+0x100], rax
00007b4681bd184d  jmp 0x00007B46819FE110
00007b4681bd1852  int3
00007b4681bd1853  call 0x00007B4681AE2CE0
00007b4681bd1858  jmp 0x00007B4681BD17DB
00007b4681bd185d  int3
00007b4681bd185e  nop
00007b4681bd1860  mov eax, [r15+0x98]
00007b4681bd1867  lea r14d, [eax+0x01]
00007b4681bd186c  mov [rsp+0x10], r14d
00007b4681bd1871  mov r14d, r14d
00007b4681bd1874  mov [r15+0x98], r14
00007b4681bd187b  xor eax, eax
00007b4681bd187d  mov r14d, [rsp+0x10]
00007b4681bd1882  cmp r14d, 0x10000
00007b4681bd1889  cmc
00007b4681bd188a  lahf
00007b4681bd188b  seto al
00007b4681bd188e  mov [r15+0x108], eax
00007b4681bd1895  mov eax, [r15+0x108]
00007b4681bd189c  sahf
00007b4681bd189d  jnz 0x00007B4681BD18CF
00007b4681bd189f  cmp dword ptr [r15+0x318], 0x00
00007b4681bd18a7  jz 0x00007B4681BD19A0
00007b4681bd18ad  nop [rax+rax*1], ax
00007b4681bd18b6  nop [rax+rax*1], eax
00007b4681bd18be  mov eax, 0x4103F4
00007b4681bd18c3  mov [r15+0x100], rax
00007b4681bd18ca  jmp 0x00007B46819FE110
00007b4681bd18cf  cmp dword ptr [r15+0x318], 0x00
00007b4681bd18d7  jz 0x00007B4681BD1910
00007b4681bd18dd  nop [rax+rax*1], ax
00007b4681bd18e6  nop [rax+rax*1], eax
00007b4681bd18ee  mov eax, 0x4103E0
00007b4681bd18f3  mov [r15+0x100], rax
00007b4681bd18fa  jmp 0x00007B46819FE110
00007b4681bd18ff  int3
00007b4681bd1900  int3
00007b4681bd1901  nop [rax+rax*1], ax
00007b4681bd190a  nop [rax+rax*1], ax
00007b4681bd1910  mov eax, [r15]
00007b4681bd1913  mov r14d, [r15+0x98]
00007b4681bd191a  lea r12d, [eax+r14d*1]
00007b4681bd191f  mov r12d, r12d
00007b4681bd1922  mov [r15], r12
00007b4681bd1925  mov qword ptr [r15+0xF0], 0x4103E8
00007b4681bd1930  mov r14d, [r15+0x320]
00007b4681bd1937  mov eax, 0x4103E8
00007b4681bd193c  mov rcx, 0x7B4681BD1860
00007b4681bd1946  mov [r15+r14*8+0x328], rax
00007b4681bd194e  mov [r15+r14*8+0x368], rcx
00007b4681bd1956  add r14d, 0x01
00007b4681bd195a  and r14d, 0x07
00007b4681bd195e  mov [r15+0x320], r14d
00007b4681bd1965  cmp dword ptr [r15+0x318], 0x00
00007b4681bd196d  jz 0x00007B4681BD0F20
00007b4681bd1973  nop [rax+rax*1], ax
00007b4681bd197c  nop [rax+rax*1], eax
00007b4681bd1984  mov eax, 0x410938
00007b4681bd1989  mov [r15+0x100], rax
00007b4681bd1990  jmp 0x00007B46819FE110
00007b4681bd1995  int3
00007b4681bd1996  int3
00007b4681bd1997  nop [rax+rax*1], ax
00007b4681bd19a0  vmovaps xmm1, [0x00007B46817FE010]
00007b4681bd19a8  movq xmm1, xmm1
00007b4681bd19ac  movaps [r15+0x110], xmm1
00007b4681bd19b4  mov eax, 0x420AA0
00007b4681bd19b9  mov r14, [r13+rax*1]
00007b4681bd19be  movq xmm1, r14
00007b4681bd19c3  movaps [r15+0x120], xmm1
00007b4681bd19cb  vmovaps xmm1, [0x00007B46817FE020]
00007b4681bd19d3  movq xmm1, xmm1
00007b4681bd19d7  movaps [r15+0x140], xmm1
00007b4681bd19df  vmovaps xmm1, [0x00007B46817FE030]
00007b4681bd19e7  vpbroadcastq xmm1, xmm1
00007b4681bd19ec  movaps [r15+0x150], xmm1
00007b4681bd19f4  mov qword ptr [r15+0x40], 0x02
00007b4681bd19fc  vmovaps xmm15, [0x00007B46817FE040]
00007b4681bd1a04  movq xmm15, xmm15
00007b4681bd1a09  movaps [r15+0x160], xmm15
00007b4681bd1a11  vmovaps xmm15, [0x00007B46817FE050]
00007b4681bd1a19  vpbroadcastq xmm15, xmm15
00007b4681bd1a1e  movaps [r15+0x130], xmm15
00007b4681bd1a26  mov rax, [r15+0x40]
00007b4681bd1a2a  vmovq xmm14, rax
00007b4681bd1a2f  vpbroadcastq xmm14, xmm14
00007b4681bd1a34  movaps [r15+0x170], xmm14
00007b4681bd1a3c  mov eax, 0x4209D0
00007b4681bd1a41  movups xmm13, [r13+rax*1]
00007b4681bd1a47  mov qword ptr [r15+0x40], 0x431D90
00007b4681bd1a4f  mov eax, [r15]
00007b4681bd1a52  mov r14d, 0x430C48
00007b4681bd1a58  mov [r13+r14*1], eax
00007b4681bd1a5d  mov qword ptr [r15+0x50], 0x431F90
00007b4681bd1a65  vpmovqd xmm12, xmm13
00007b4681bd1a6b  pxor xmm11, xmm11
00007b4681bd1a70  punpcklqdq xmm12, xmm11
00007b4681bd1a75  movaps [r15+0x210], xmm12
00007b4681bd1a7d  movq xmm12, qword ptr [r15+0x140]
00007b4681bd1a86  movq xmm11, qword ptr [r15+0x120]
00007b4681bd1a8f  psubd xmm12, xmm11
00007b4681bd1a94  movq xmm12, xmm12
00007b4681bd1a99  paddq xmm13, xmm14
00007b4681bd1a9e  movaps [r15+0x180], xmm13
00007b4681bd1aa6  movq xmm14, qword ptr [r15+0x160]
00007b4681bd1aaf  paddd xmm11, xmm14
00007b4681bd1ab4  movq xmm11, xmm11
00007b4681bd1ab9  movq xmm11, xmm11
00007b4681bd1abe  movaps [r15+0x120], xmm11
00007b4681bd1ac6  pmovzxdq xmm12, xmm12
00007b4681bd1acc  psllq xmm12, 0x00
00007b4681bd1ad2  movq xmm14, qword ptr [r15+0x210]
00007b4681bd1adb  movq xmm13, qword ptr [r15+0x110]
00007b4681bd1ae4  paddd xmm14, xmm13
00007b4681bd1ae9  movq xmm14, xmm14
00007b4681bd1aee  vcvtuqq2pd xmm12, xmm12
00007b4681bd1af4  pmovzxdq xmm14, xmm14
00007b4681bd1afa  psllq xmm14, 0x00
00007b4681bd1b00  vcvtuqq2pd xmm14, xmm14
00007b4681bd1b06  movaps xmm13, xmm12
00007b4681bd1b0a  mulpd xmm13, xmm1
00007b4681bd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007b4681bd1b15  ptest xmm11, xmm11
00007b4681bd1b1b  jnz 0x00007B4681BD1C0F
00007b4681bd1b21  movaps [r15+0x220], xmm13
00007b4681bd1b29  mov eax, 0x431F90
00007b4681bd1b2e  movups [r13+rax*1], xmm13
00007b4681bd1b34  movaps xmm1, xmm14
00007b4681bd1b38  mulpd xmm1, xmm15
00007b4681bd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007b4681bd1b42  ptest xmm13, xmm13
00007b4681bd1b48  jnz 0x00007B4681BD1D5C
00007b4681bd1b4e  movaps [r15+0x210], xmm1
00007b4681bd1b56  mov eax, 0x431D90
00007b4681bd1b5b  movups [r13+rax*1], xmm1
00007b4681bd1b61  mov qword ptr [r15+0x48], 0x10
00007b4681bd1b69  xor eax, eax
00007b4681bd1b6b  mov r14d, 0x10
00007b4681bd1b71  mov r12d, 0x200
00007b4681bd1b77  cmp r14, r12
00007b4681bd1b7a  cmc
00007b4681bd1b7b  lahf
00007b4681bd1b7c  seto al
00007b4681bd1b7f  mov [r15+0x108], eax
00007b4681bd1b86  mov eax, [r15+0x108]
00007b4681bd1b8d  sahf
00007b4681bd1b8e  jnz 0x00007B4681BD1BC0
00007b4681bd1b90  cmp dword ptr [r15+0x318], 0x00
00007b4681bd1b98  jz 0x00007B4681BD2300
00007b4681bd1b9e  nop [rax+rax*1], ax
00007b4681bd1ba7  nop [rax+rax*1], eax
00007b4681bd1baf  mov eax, 0x410480
00007b4681bd1bb4  mov [r15+0x100], rax
00007b4681bd1bbb  jmp 0x00007B46819FE110
00007b4681bd1bc0  cmp dword ptr [r15+0x318], 0x00
00007b4681bd1bc8  jz 0x00007B4681BD1EB0
00007b4681bd1bce  nop [rax+rax*1], ax
00007b4681bd1bd7  nop [rax+rax*1], eax
00007b4681bd1bdf  mov eax, 0x410440
00007b4681bd1be4  mov [r15+0x100], rax
00007b4681bd1beb  jmp 0x00007B46819FE110
00007b4681bd1bf0  int3
00007b4681bd1bf1  call 0x00007B4681A0DC20
00007b4681bd1bf6  jmp 0x00007B4681BD19BE
00007b4681bd1bfb  call 0x00007B4681A0C260
00007b4681bd1c00  jmp 0x00007B4681BD1A47
00007b4681bd1c05  call 0x00007B4681AD5D70
00007b4681bd1c0a  jmp 0x00007B4681BD1A5D
00007b4681bd1c0f  sub rsp, 0x08
00007b4681bd1c13  push rax
00007b4681bd1c14  push rcx
00007b4681bd1c15  push rdx
00007b4681bd1c16  push rdi
00007b4681bd1c17  push rsi
00007b4681bd1c18  push r8
00007b4681bd1c1a  push r9
00007b4681bd1c1c  push r10
00007b4681bd1c1e  push r11
00007b4681bd1c20  sub rsp, 0xF0
00007b4681bd1c27  vmovaps [rsp], xmm0
00007b4681bd1c2c  vmovaps [rsp+0x10], xmm1
00007b4681bd1c32  vmovaps [rsp+0x20], xmm2
00007b4681bd1c38  vmovaps [rsp+0x30], xmm3
00007b4681bd1c3e  vmovaps [rsp+0x40], xmm4
00007b4681bd1c44  vmovaps [rsp+0x50], xmm5
00007b4681bd1c4a  vmovaps [rsp+0x60], xmm6
00007b4681bd1c50  vmovaps [rsp+0x70], xmm7
00007b4681bd1c56  vmovaps [rsp+0x80], xmm8
00007b4681bd1c5f  vmovaps [rsp+0x90], xmm9
00007b4681bd1c68  vmovaps [rsp+0xA0], xmm10
00007b4681bd1c71  vmovaps [rsp+0xB0], xmm11
00007b4681bd1c7a  vmovaps [rsp+0xC0], xmm12
00007b4681bd1c83  vmovaps [rsp+0xD0], xmm14
00007b4681bd1c8c  vmovaps [rsp+0xE0], xmm15
00007b4681bd1c95  sub rsp, 0x30
00007b4681bd1c99  movaps [rsp], xmm13
00007b4681bd1c9e  movaps [rsp+0x10], xmm12
00007b4681bd1ca4  movaps [rsp+0x20], xmm1
00007b4681bd1ca9  lea rdi, [rsp]
00007b4681bd1cad  mov esi, 0x00
00007b4681bd1cb2  mov rax, 0x5668589B5530
00007b4681bd1cbc  call rax
00007b4681bd1cbe  movaps xmm13, [rsp]
00007b4681bd1cc3  add rsp, 0x30
00007b4681bd1cc7  vmovaps xmm0, [rsp]
00007b4681bd1ccc  vmovaps xmm1, [rsp+0x10]
00007b4681bd1cd2  vmovaps xmm2, [rsp+0x20]
00007b4681bd1cd8  vmovaps xmm3, [rsp+0x30]
00007b4681bd1cde  vmovaps xmm4, [rsp+0x40]
00007b4681bd1ce4  vmovaps xmm5, [rsp+0x50]
00007b4681bd1cea  vmovaps xmm6, [rsp+0x60]
00007b4681bd1cf0  vmovaps xmm7, [rsp+0x70]
00007b4681bd1cf6  vmovaps xmm8, [rsp+0x80]
00007b4681bd1cff  vmovaps xmm9, [rsp+0x90]
00007b4681bd1d08  vmovaps xmm10, [rsp+0xA0]
00007b4681bd1d11  vmovaps xmm11, [rsp+0xB0]
00007b4681bd1d1a  vmovaps xmm12, [rsp+0xC0]
00007b4681bd1d23  vmovaps xmm14, [rsp+0xD0]
00007b4681bd1d2c  vmovaps xmm15, [rsp+0xE0]
00007b4681bd1d35  add rsp, 0xF0
00007b4681bd1d3c  pop r11
00007b4681bd1d3e  pop r10
00007b4681bd1d40  pop r9
00007b4681bd1d42  pop r8
00007b4681bd1d44  pop rsi
00007b4681bd1d45  pop rdi
00007b4681bd1d46  pop rdx
00007b4681bd1d47  pop rcx
00007b4681bd1d48  pop rax
00007b4681bd1d49  add rsp, 0x08
00007b4681bd1d4d  jmp 0x00007B4681BD1B21
00007b4681bd1d52  call 0x00007B4681A0C380
00007b4681bd1d57  jmp 0x00007B4681BD1B34
00007b4681bd1d5c  sub rsp, 0x08
00007b4681bd1d60  push rax
00007b4681bd1d61  push rcx
00007b4681bd1d62  push rdx
00007b4681bd1d63  push rdi
00007b4681bd1d64  push rsi
00007b4681bd1d65  push r8
00007b4681bd1d67  push r9
00007b4681bd1d69  push r10
00007b4681bd1d6b  push r11
00007b4681bd1d6d  sub rsp, 0xF0
00007b4681bd1d74  vmovaps [rsp], xmm0
00007b4681bd1d79  vmovaps [rsp+0x10], xmm2
00007b4681bd1d7f  vmovaps [rsp+0x20], xmm3
00007b4681bd1d85  vmovaps [rsp+0x30], xmm4
00007b4681bd1d8b  vmovaps [rsp+0x40], xmm5
00007b4681bd1d91  vmovaps [rsp+0x50], xmm6
00007b4681bd1d97  vmovaps [rsp+0x60], xmm7
00007b4681bd1d9d  vmovaps [rsp+0x70], xmm8
00007b4681bd1da3  vmovaps [rsp+0x80], xmm9
00007b4681bd1dac  vmovaps [rsp+0x90], xmm10
00007b4681bd1db5  vmovaps [rsp+0xA0], xmm11
00007b4681bd1dbe  vmovaps [rsp+0xB0], xmm12
00007b4681bd1dc7  vmovaps [rsp+0xC0], xmm13
00007b4681bd1dd0  vmovaps [rsp+0xD0], xmm14
00007b4681bd1dd9  vmovaps [rsp+0xE0], xmm15
00007b4681bd1de2  sub rsp, 0x30
00007b4681bd1de6  movaps [rsp], xmm1
00007b4681bd1dea  movaps [rsp+0x10], xmm14
00007b4681bd1df0  movaps [rsp+0x20], xmm15
00007b4681bd1df6  lea rdi, [rsp]
00007b4681bd1dfa  mov esi, 0x00
00007b4681bd1dff  mov rax, 0x5668589B5530
00007b4681bd1e09  call rax
00007b4681bd1e0b  movaps xmm1, [rsp]
00007b4681bd1e0f  add rsp, 0x30
00007b4681bd1e13  vmovaps xmm0, [rsp]
00007b4681bd1e18  vmovaps xmm2, [rsp+0x10]
00007b4681bd1e1e  vmovaps xmm3, [rsp+0x20]
00007b4681bd1e24  vmovaps xmm4, [rsp+0x30]
00007b4681bd1e2a  vmovaps xmm5, [rsp+0x40]
00007b4681bd1e30  vmovaps xmm6, [rsp+0x50]
00007b4681bd1e36  vmovaps xmm7, [rsp+0x60]
00007b4681bd1e3c  vmovaps xmm8, [rsp+0x70]
00007b4681bd1e42  vmovaps xmm9, [rsp+0x80]
00007b4681bd1e4b  vmovaps xmm10, [rsp+0x90]
00007b4681bd1e54  vmovaps xmm11, [rsp+0xA0]
00007b4681bd1e5d  vmovaps xmm12, [rsp+0xB0]
00007b4681bd1e66  vmovaps xmm13, [rsp+0xC0]
00007b4681bd1e6f  vmovaps xmm14, [rsp+0xD0]
00007b4681bd1e78  vmovaps xmm15, [rsp+0xE0]
00007b4681bd1e81  add rsp, 0xF0
00007b4681bd1e88  pop r11
00007b4681bd1e8a  pop r10
00007b4681bd1e8c  pop r9
00007b4681bd1e8e  pop r8
00007b4681bd1e90  pop rsi
00007b4681bd1e91  pop rdi
00007b4681bd1e92  pop rdx
00007b4681bd1e93  pop rcx
00007b4681bd1e94  pop rax
00007b4681bd1e95  add rsp, 0x08
00007b4681bd1e99  jmp 0x00007B4681BD1B4E
00007b4681bd1e9e  call 0x00007B46819FF540
00007b4681bd1ea3  jmp 0x00007B4681BD1B61
00007b4681bd1ea8  int3
00007b4681bd1ea9  nop [rax], eax
00007b4681bd1eb0  movaps xmm1, [r15+0x180]
00007b4681bd1eb8  vpmovqd xmm15, xmm1
00007b4681bd1ebe  pxor xmm14, xmm14
00007b4681bd1ec3  punpcklqdq xmm15, xmm14
00007b4681bd1ec8  movaps [r15+0x210], xmm15
00007b4681bd1ed0  movq xmm15, qword ptr [r15+0x140]
00007b4681bd1ed9  movq xmm14, qword ptr [r15+0x120]
00007b4681bd1ee2  psubd xmm15, xmm14
00007b4681bd1ee7  movq xmm15, xmm15
00007b4681bd1eec  movaps xmm13, [r15+0x170]
00007b4681bd1ef4  paddq xmm1, xmm13
00007b4681bd1ef9  movaps [r15+0x180], xmm1
00007b4681bd1f01  movq xmm1, qword ptr [r15+0x160]
00007b4681bd1f0a  paddd xmm14, xmm1
00007b4681bd1f0f  movq xmm14, xmm14
00007b4681bd1f14  movq xmm14, xmm14
00007b4681bd1f19  movaps [r15+0x120], xmm14
00007b4681bd1f21  pmovzxdq xmm15, xmm15
00007b4681bd1f27  psllq xmm15, 0x00
00007b4681bd1f2d  movq xmm1, qword ptr [r15+0x210]
00007b4681bd1f36  movq xmm14, qword ptr [r15+0x110]
00007b4681bd1f3f  paddd xmm1, xmm14
00007b4681bd1f44  movq xmm1, xmm1
00007b4681bd1f48  vcvtuqq2pd xmm15, xmm15
00007b4681bd1f4e  pmovzxdq xmm1, xmm1
00007b4681bd1f53  psllq xmm1, 0x00
00007b4681bd1f58  vcvtuqq2pd xmm1, xmm1
00007b4681bd1f5e  movaps xmm14, [r15+0x150]
00007b4681bd1f66  movaps xmm13, xmm15
00007b4681bd1f6a  mulpd xmm13, xmm14
00007b4681bd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd1f75  ptest xmm12, xmm12
00007b4681bd1f7b  jnz 0x00007B4681BD205E
00007b4681bd1f81  movaps [r15+0x220], xmm13
00007b4681bd1f89  mov rax, [r15+0x48]
00007b4681bd1f8d  mov r14, [r15+0x50]
00007b4681bd1f91  lea r12, [r14+rax*1]
00007b4681bd1f95  movups [r13+r12*1], xmm13
00007b4681bd1f9b  movaps xmm15, [r15+0x130]
00007b4681bd1fa3  movaps xmm14, xmm1
00007b4681bd1fa7  mulpd xmm14, xmm15
00007b4681bd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007b4681bd1fb2  ptest xmm13, xmm13
00007b4681bd1fb8  jnz 0x00007B4681BD21AC
00007b4681bd1fbe  movaps [r15+0x210], xmm14
00007b4681bd1fc6  mov r14, [r15+0x40]
00007b4681bd1fca  lea r12, [r14+rax*1]
00007b4681bd1fce  movups [r13+r12*1], xmm14
00007b4681bd1fd4  lea r14, [rax+0x10]
00007b4681bd1fd8  mov [r15+0x48], r14
00007b4681bd1fdc  xor eax, eax
00007b4681bd1fde  mov r12d, 0x200
00007b4681bd1fe4  cmp r14, r12
00007b4681bd1fe7  cmc
00007b4681bd1fe8  lahf
00007b4681bd1fe9  seto al
00007b4681bd1fec  mov [r15+0x108], eax
00007b4681bd1ff3  mov eax, [r15+0x108]
00007b4681bd1ffa  sahf
00007b4681bd1ffb  jnz 0x00007B4681BD202D
00007b4681bd1ffd  cmp dword ptr [r15+0x318], 0x00
00007b4681bd2005  jz 0x00007B4681BD2300
00007b4681bd200b  nop [rax+rax*1], ax
00007b4681bd2014  nop [rax+rax*1], eax
00007b4681bd201c  mov eax, 0x410480
00007b4681bd2021  mov [r15+0x100], rax
00007b4681bd2028  jmp 0x00007B46819FE110
00007b4681bd202d  cmp dword ptr [r15+0x318], 0x00
00007b4681bd2035  jz 0x00007B4681BD1EB0
00007b4681bd203b  nop [rax+rax*1], ax
00007b4681bd2044  nop [rax+rax*1], eax
00007b4681bd204c  mov eax, 0x410440
00007b4681bd2051  mov [r15+0x100], rax
00007b4681bd2058  jmp 0x00007B46819FE110
00007b4681bd205d  int3
00007b4681bd205e  sub rsp, 0x08
00007b4681bd2062  push rax
00007b4681bd2063  push rcx
00007b4681bd2064  push rdx
00007b4681bd2065  push rdi
00007b4681bd2066  push rsi
00007b4681bd2067  push r8
00007b4681bd2069  push r9
00007b4681bd206b  push r10
00007b4681bd206d  push r11
00007b4681bd206f  sub rsp, 0xF0
00007b4681bd2076  vmovaps [rsp], xmm0
00007b4681bd207b  vmovaps [rsp+0x10], xmm1
00007b4681bd2081  vmovaps [rsp+0x20], xmm2
00007b4681bd2087  vmovaps [rsp+0x30], xmm3
00007b4681bd208d  vmovaps [rsp+0x40], xmm4
00007b4681bd2093  vmovaps [rsp+0x50], xmm5
00007b4681bd2099  vmovaps [rsp+0x60], xmm6
00007b4681bd209f  vmovaps [rsp+0x70], xmm7
00007b4681bd20a5  vmovaps [rsp+0x80], xmm8
00007b4681bd20ae  vmovaps [rsp+0x90], xmm9
00007b4681bd20b7  vmovaps [rsp+0xA0], xmm10
00007b4681bd20c0  vmovaps [rsp+0xB0], xmm11
00007b4681bd20c9  vmovaps [rsp+0xC0], xmm12
00007b4681bd20d2  vmovaps [rsp+0xD0], xmm14
00007b4681bd20db  vmovaps [rsp+0xE0], xmm15
00007b4681bd20e4  sub rsp, 0x30
00007b4681bd20e8  movaps [rsp], xmm13
00007b4681bd20ed  movaps [rsp+0x10], xmm15
00007b4681bd20f3  movaps [rsp+0x20], xmm14
00007b4681bd20f9  lea rdi, [rsp]
00007b4681bd20fd  mov esi, 0x00
00007b4681bd2102  mov rax, 0x5668589B5530
00007b4681bd210c  call rax
00007b4681bd210e  movaps xmm13, [rsp]
00007b4681bd2113  add rsp, 0x30
00007b4681bd2117  vmovaps xmm0, [rsp]
00007b4681bd211c  vmovaps xmm1, [rsp+0x10]
00007b4681bd2122  vmovaps xmm2, [rsp+0x20]
00007b4681bd2128  vmovaps xmm3, [rsp+0x30]
00007b4681bd212e  vmovaps xmm4, [rsp+0x40]
00007b4681bd2134  vmovaps xmm5, [rsp+0x50]
00007b4681bd213a  vmovaps xmm6, [rsp+0x60]
00007b4681bd2140  vmovaps xmm7, [rsp+0x70]
00007b4681bd2146  vmovaps xmm8, [rsp+0x80]
00007b4681bd214f  vmovaps xmm9, [rsp+0x90]
00007b4681bd2158  vmovaps xmm10, [rsp+0xA0]
00007b4681bd2161  vmovaps xmm11, [rsp+0xB0]
00007b4681bd216a  vmovaps xmm12, [rsp+0xC0]
00007b4681bd2173  vmovaps xmm14, [rsp+0xD0]
00007b4681bd217c  vmovaps xmm15, [rsp+0xE0]
00007b4681bd2185  add rsp, 0xF0
00007b4681bd218c  pop r11
00007b4681bd218e  pop r10
00007b4681bd2190  pop r9
00007b4681bd2192  pop r8
00007b4681bd2194  pop rsi
00007b4681bd2195  pop rdi
00007b4681bd2196  pop rdx
00007b4681bd2197  pop rcx
00007b4681bd2198  pop rax
00007b4681bd2199  add rsp, 0x08
00007b4681bd219d  jmp 0x00007B4681BD1F81
00007b4681bd21a2  call 0x00007B4681AC2240
00007b4681bd21a7  jmp 0x00007B4681BD1F9B
00007b4681bd21ac  sub rsp, 0x08
00007b4681bd21b0  push rax
00007b4681bd21b1  push rcx
00007b4681bd21b2  push rdx
00007b4681bd21b3  push rdi
00007b4681bd21b4  push rsi
00007b4681bd21b5  push r8
00007b4681bd21b7  push r9
00007b4681bd21b9  push r10
00007b4681bd21bb  push r11
00007b4681bd21bd  sub rsp, 0xF0
00007b4681bd21c4  vmovaps [rsp], xmm0
00007b4681bd21c9  vmovaps [rsp+0x10], xmm1
00007b4681bd21cf  vmovaps [rsp+0x20], xmm2
00007b4681bd21d5  vmovaps [rsp+0x30], xmm3
00007b4681bd21db  vmovaps [rsp+0x40], xmm4
00007b4681bd21e1  vmovaps [rsp+0x50], xmm5
00007b4681bd21e7  vmovaps [rsp+0x60], xmm6
00007b4681bd21ed  vmovaps [rsp+0x70], xmm7
00007b4681bd21f3  vmovaps [rsp+0x80], xmm8
00007b4681bd21fc  vmovaps [rsp+0x90], xmm9
00007b4681bd2205  vmovaps [rsp+0xA0], xmm10
00007b4681bd220e  vmovaps [rsp+0xB0], xmm11
00007b4681bd2217  vmovaps [rsp+0xC0], xmm12
00007b4681bd2220  vmovaps [rsp+0xD0], xmm13
00007b4681bd2229  vmovaps [rsp+0xE0], xmm15
00007b4681bd2232  sub rsp, 0x30
00007b4681bd2236  movaps [rsp], xmm14
00007b4681bd223b  movaps [rsp+0x10], xmm1
00007b4681bd2240  movaps [rsp+0x20], xmm15
00007b4681bd2246  lea rdi, [rsp]
00007b4681bd224a  mov esi, 0x00
00007b4681bd224f  mov rax, 0x5668589B5530
00007b4681bd2259  call rax
00007b4681bd225b  movaps xmm14, [rsp]
00007b4681bd2260  add rsp, 0x30
00007b4681bd2264  vmovaps xmm0, [rsp]
00007b4681bd2269  vmovaps xmm1, [rsp+0x10]
00007b4681bd226f  vmovaps xmm2, [rsp+0x20]
00007b4681bd2275  vmovaps xmm3, [rsp+0x30]
00007b4681bd227b  vmovaps xmm4, [rsp+0x40]
00007b4681bd2281  vmovaps xmm5, [rsp+0x50]
00007b4681bd2287  vmovaps xmm6, [rsp+0x60]
00007b4681bd228d  vmovaps xmm7, [rsp+0x70]
00007b4681bd2293  vmovaps xmm8, [rsp+0x80]
00007b4681bd229c  vmovaps xmm9, [rsp+0x90]
00007b4681bd22a5  vmovaps xmm10, [rsp+0xA0]
00007b4681bd22ae  vmovaps xmm11, [rsp+0xB0]
00007b4681bd22b7  vmovaps xmm12, [rsp+0xC0]
00007b4681bd22c0  vmovaps xmm13, [rsp+0xD0]
00007b4681bd22c9  vmovaps xmm15, [rsp+0xE0]
00007b4681bd22d2  add rsp, 0xF0
00007b4681bd22d9  pop r11
00007b4681bd22db  pop r10
00007b4681bd22dd  pop r9
00007b4681bd22df  pop r8
00007b4681bd22e1  pop rsi
00007b4681bd22e2  pop rdi
00007b4681bd22e3  pop rdx
00007b4681bd22e4  pop rcx
00007b4681bd22e5  pop rax
00007b4681bd22e6  add rsp, 0x08
00007b4681bd22ea  jmp 0x00007B4681BD1FBE
00007b4681bd22ef  call 0x00007B4681AC34C0
00007b4681bd22f4  jmp 0x00007B4681BD1FD4
00007b4681bd22f9  int3
00007b4681bd22fa  nop [rax+rax*1], ax
00007b4681bd2300  mov rax, [r15+0x50]
00007b4681bd2304  movups xmm1, [r13+rax*1]
00007b4681bd230a  lea r14, [rax+0x10]
00007b4681bd230e  movups xmm15, [r13+r14*1]
00007b4681bd2314  mov qword ptr [r15+0x48], 0x00
00007b4681bd231c  lea r14, [rax+0x40]
00007b4681bd2320  movups xmm14, [r13+r14*1]
00007b4681bd2326  lea r14, [rax+0x50]
00007b4681bd232a  movups xmm13, [r13+r14*1]
00007b4681bd2330  lea r14, [rax+0x80]
00007b4681bd2337  movups xmm12, [r13+r14*1]
00007b4681bd233d  lea r14, [rax+0x90]
00007b4681bd2344  movups xmm11, [r13+r14*1]
00007b4681bd234a  mov r14, [r15+0xF8]
00007b4681bd2351  movups [r13+r14*1], xmm1
00007b4681bd2357  lea r12, [rax+0x20]
00007b4681bd235b  movups xmm1, [r13+r12*1]
00007b4681bd2361  lea r12, [rax+0x30]
00007b4681bd2365  movups xmm10, [r13+r12*1]
00007b4681bd236b  lea r12, [rax+0xC0]
00007b4681bd2372  movups xmm9, [r13+r12*1]
00007b4681bd2378  lea r12, [rax+0xD0]
00007b4681bd237f  movups xmm8, [r13+r12*1]
00007b4681bd2385  lea r12, [rax+0x100]
00007b4681bd238c  movups xmm7, [r13+r12*1]
00007b4681bd2392  lea r12, [rax+0x110]
00007b4681bd2399  movups xmm6, [r13+r12*1]
00007b4681bd239f  lea r12, [rax+0x140]
00007b4681bd23a6  movups xmm5, [r13+r12*1]
00007b4681bd23ac  lea r12, [rax+0x150]
00007b4681bd23b3  movups xmm4, [r13+r12*1]
00007b4681bd23b9  lea r12, [r14+0xB0]
00007b4681bd23c0  movups [r13+r12*1], xmm10
00007b4681bd23c6  lea r12, [r14+0xC0]
00007b4681bd23cd  movups [r13+r12*1], xmm1
00007b4681bd23d3  lea r12, [rax+0x180]
00007b4681bd23da  movups xmm1, [r13+r12*1]
00007b4681bd23e0  lea r12, [rax+0x190]
00007b4681bd23e7  movups xmm10, [r13+r12*1]
00007b4681bd23ed  lea r12, [rax+0x1C0]
00007b4681bd23f4  movups xmm3, [r13+r12*1]
00007b4681bd23fa  lea r12, [rax+0x1D0]
00007b4681bd2401  movups xmm2, [r13+r12*1]
00007b4681bd2407  lea r12, [rax+0x60]
00007b4681bd240b  vmovaps [rsp+0x10], xmm1
00007b4681bd2411  movups xmm1, [r13+r12*1]
00007b4681bd2417  lea r12, [rax+0x70]
00007b4681bd241b  vmovaps [rsp+0x20], xmm1
00007b4681bd2421  movups xmm1, [r13+r12*1]
00007b4681bd2427  lea r12, [r14+0x70]
00007b4681bd242b  movups [r13+r12*1], xmm10
00007b4681bd2431  lea r12, [r14+0x80]
00007b4681bd2438  vmovaps xmm10, [rsp+0x10]
00007b4681bd243e  movups [r13+r12*1], xmm10
00007b4681bd2444  lea r12, [rax+0xA0]
00007b4681bd244b  movups xmm10, [r13+r12*1]
00007b4681bd2451  lea r12, [rax+0xB0]
00007b4681bd2458  vmovaps [rsp+0x10], xmm1
00007b4681bd245e  movups xmm1, [r13+r12*1]
00007b4681bd2464  lea r12, [r14+0x90]
00007b4681bd246b  movups [r13+r12*1], xmm2
00007b4681bd2471  lea r12, [r14+0xA0]
00007b4681bd2478  movups [r13+r12*1], xmm3
00007b4681bd247e  lea r12, [rax+0xE0]
00007b4681bd2485  movups xmm3, [r13+r12*1]
00007b4681bd248b  lea r12, [rax+0xF0]
00007b4681bd2492  movups xmm2, [r13+r12*1]
00007b4681bd2498  lea r12, [rax+0x120]
00007b4681bd249f  vmovaps [rsp+0x30], xmm1
00007b4681bd24a5  movups xmm1, [r13+r12*1]
00007b4681bd24ab  lea r12, [rax+0x130]
00007b4681bd24b2  vmovaps [rsp+0x40], xmm1
00007b4681bd24b8  movups xmm1, [r13+r12*1]
00007b4681bd24be  vmovaps [rsp+0x50], xmm1
00007b4681bd24c4  vmovaps xmm1, [rsp+0x40]
00007b4681bd24ca  movaps [r15+0x190], xmm1
00007b4681bd24d2  lea r12, [rax+0x160]
00007b4681bd24d9  vmovaps [rsp+0x40], xmm1
00007b4681bd24df  movups xmm1, [r13+r12*1]
00007b4681bd24e5  lea r12, [rax+0x170]
00007b4681bd24ec  vmovaps [rsp+0x60], xmm1
00007b4681bd24f2  movups xmm1, [r13+r12*1]
00007b4681bd24f8  lea r12, [rax+0x1A0]
00007b4681bd24ff  vmovaps [rsp+0x70], xmm1
00007b4681bd2505  movups xmm1, [r13+r12*1]
00007b4681bd250b  lea r12, [rax+0x1B0]
00007b4681bd2512  vmovaps [rsp+0x80], xmm1
00007b4681bd251b  movups xmm1, [r13+r12*1]
00007b4681bd2521  lea r12, [rax+0x1E0]
00007b4681bd2528  vmovaps [rsp+0x90], xmm1
00007b4681bd2531  movups xmm1, [r13+r12*1]
00007b4681bd2537  lea r12, [rax+0x1F0]
00007b4681bd253e  vmovaps [rsp+0xA0], xmm1
00007b4681bd2547  movups xmm1, [r13+r12*1]
00007b4681bd254d  mov qword ptr [r15+0x50], 0x432190
00007b4681bd2555  lea rax, [r14+0x50]
00007b4681bd2559  vmovaps [rsp+0xB0], xmm1
00007b4681bd2562  vmovaps xmm1, [rsp+0x60]
00007b4681bd2568  movups [r13+rax*1], xmm1
00007b4681bd256e  lea rax, [r14+0x60]
00007b4681bd2572  movups [r13+rax*1], xmm5
00007b4681bd2578  lea rax, [r14+0x40]
00007b4681bd257c  vmovaps xmm1, [rsp+0x70]
00007b4681bd2582  movups [r13+rax*1], xmm1
00007b4681bd2588  lea rax, [r14+0x20]
00007b4681bd258c  vmovaps xmm1, [rsp+0xA0]
00007b4681bd2595  movups [r13+rax*1], xmm1
00007b4681bd259b  lea rax, [r14+0x30]
00007b4681bd259f  vmovaps xmm1, [rsp+0x90]
00007b4681bd25a8  movups [r13+rax*1], xmm1
00007b4681bd25ae  lea rax, [r14+0x10]
00007b4681bd25b2  vmovaps xmm1, [rsp+0xB0]
00007b4681bd25bb  movups [r13+rax*1], xmm1
00007b4681bd25c1  mov rax, [r15+0x40]
00007b4681bd25c5  vxorps xmm1, xmm1, xmm1
00007b4681bd25c9  vpbroadcastq xmm1, xmm1
00007b4681bd25ce  vxorps xmm5, xmm5, xmm5
00007b4681bd25d2  vpbroadcastq xmm5, xmm5
00007b4681bd25d7  lea r12, [rax+0x30]
00007b4681bd25db  mov r11, [r13+r12*1]
00007b4681bd25e0  lea r12, [rax+0x38]
00007b4681bd25e4  mov r10, [r13+r12*1]
00007b4681bd25e9  vmovaps [rsp+0x60], xmm1
00007b4681bd25ef  movq xmm1, r11
00007b4681bd25f4  vmovaps [rsp+0x70], xmm1
00007b4681bd25fa  movq xmm1, r10
00007b4681bd25ff  vmovaps [rsp+0x90], xmm1
00007b4681bd2608  vmovaps xmm1, [rsp+0x70]
00007b4681bd260e  movq xmm1, xmm1
00007b4681bd2612  vmovaps [rsp+0x70], xmm1
00007b4681bd2618  vmovaps xmm1, [rsp+0x90]
00007b4681bd2621  movq xmm1, xmm1
00007b4681bd2625  vmovaps [rsp+0x90], xmm1
00007b4681bd262e  movq xmm1, xmm1
00007b4681bd2632  movaps [r15+0x270], xmm1
00007b4681bd263a  vmovaps [rsp+0xA0], xmm7
00007b4681bd2643  vmovaps xmm1, [rsp+0xA0]
00007b4681bd264c  por xmm7, xmm1
00007b4681bd2650  lea r12, [rax+0x20]
00007b4681bd2654  mov r11, [r13+r12*1]
00007b4681bd2659  lea r12, [rax+0x28]
00007b4681bd265d  mov r10, [r13+r12*1]
00007b4681bd2662  movq xmm1, r11
00007b4681bd2667  vmovaps [rsp+0xA0], xmm1
00007b4681bd2670  movq xmm1, r10
00007b4681bd2675  vmovaps [rsp+0xB0], xmm1
00007b4681bd267e  vmovaps xmm1, [rsp+0xA0]
00007b4681bd2687  movq xmm1, xmm1
00007b4681bd268b  vmovaps [rsp+0xA0], xmm1
00007b4681bd2694  vmovaps xmm1, [rsp+0xB0]
00007b4681bd269d  movq xmm1, xmm1
00007b4681bd26a1  vmovaps [rsp+0xB0], xmm2
00007b4681bd26aa  vmovaps [rsp+0xC0], xmm1
00007b4681bd26b3  vmovaps xmm1, [rsp+0xB0]
00007b4681bd26bc  por xmm2, xmm1
00007b4681bd26c0  vmovaps [rsp+0xB0], xmm3
00007b4681bd26c9  vmovaps xmm1, [rsp+0xB0]
00007b4681bd26d2  por xmm3, xmm1
00007b4681bd26d6  vmovaps [rsp+0xB0], xmm4
00007b4681bd26df  vmovaps xmm1, [rsp+0xB0]
00007b4681bd26e8  por xmm4, xmm1
00007b4681bd26ec  vmovaps [rsp+0xB0], xmm9
00007b4681bd26f5  vmovaps xmm1, [rsp+0xB0]
00007b4681bd26fe  por xmm9, xmm1
00007b4681bd2703  lea r12, [rax+0x10]
00007b4681bd2707  mov r11, [r13+r12*1]
00007b4681bd270c  lea r12, [rax+0x18]
00007b4681bd2710  mov r10, [r13+r12*1]
00007b4681bd2715  movq xmm1, r11
00007b4681bd271a  vmovaps [rsp+0xB0], xmm1
00007b4681bd2723  movq xmm1, r10
00007b4681bd2728  vmovaps [rsp+0xD0], xmm1
00007b4681bd2731  vmovaps xmm1, [rsp+0xB0]
00007b4681bd273a  movq xmm1, xmm1
00007b4681bd273e  vmovaps [rsp+0xB0], xmm1
00007b4681bd2747  vmovaps xmm1, [rsp+0xD0]
00007b4681bd2750  movq xmm1, xmm1
00007b4681bd2754  vmovaps [rsp+0xD0], xmm1
00007b4681bd275d  vmovaps xmm1, [rsp+0x80]
00007b4681bd2766  vmovaps [rsp+0xE0], xmm15
00007b4681bd276f  vmovaps xmm15, [rsp+0x80]
00007b4681bd2778  por xmm1, xmm15
00007b4681bd277d  vmovaps xmm15, [rsp+0x10]
00007b4681bd2783  vmovaps [rsp+0x80], xmm1
00007b4681bd278c  vmovaps xmm1, [rsp+0x10]
00007b4681bd2792  por xmm15, xmm1
00007b4681bd2797  vmovaps xmm1, [rsp+0x20]
00007b4681bd279d  vmovaps [rsp+0x10], xmm15
00007b4681bd27a3  vmovaps xmm15, [rsp+0x20]
00007b4681bd27a9  por xmm1, xmm15
00007b4681bd27ae  vmovaps [rsp+0x20], xmm6
00007b4681bd27b4  vmovaps xmm15, [rsp+0x20]
00007b4681bd27ba  por xmm6, xmm15
00007b4681bd27bf  vmovaps [rsp+0x20], xmm11
00007b4681bd27c5  vmovaps xmm15, [rsp+0x20]
00007b4681bd27cb  por xmm11, xmm15
00007b4681bd27d0  vmovaps [rsp+0x20], xmm13
00007b4681bd27d6  vmovaps xmm15, [rsp+0x20]
00007b4681bd27dc  por xmm13, xmm15
00007b4681bd27e1  vmovaps [rsp+0x20], xmm14
00007b4681bd27e7  vmovaps xmm15, [rsp+0x20]
00007b4681bd27ed  por xmm14, xmm15
00007b4681bd27f2  mov r12, [r13+rax*1]
00007b4681bd27f7  vmovq xmm15, r12
00007b4681bd27fc  vpbroadcastq xmm15, xmm15
00007b4681bd2801  vmovaps [rsp+0x20], xmm1
00007b4681bd2807  vxorps xmm1, xmm1, xmm1
00007b4681bd280b  vpbroadcastq xmm1, xmm1
00007b4681bd2810  vmovaps [rsp+0xF0], xmm1
00007b4681bd2819  movups xmm1, [r13+r14*1]
00007b4681bd281f  vmovaps [rsp+0x100], xmm1
00007b4681bd2828  vxorps xmm1, xmm1, xmm1
00007b4681bd282c  vpbroadcastq xmm1, xmm1
00007b4681bd2831  lea r12, [rax+0x08]
00007b4681bd2835  mov rax, [r13+r12*1]
00007b4681bd283a  vmovaps [rsp+0x110], xmm1
00007b4681bd2843  movq xmm1, rax
00007b4681bd2848  movaps [r15+0x240], xmm1
00007b4681bd2850  mov qword ptr [r15+0x60], 0x432190
00007b4681bd2858  mov qword ptr [r15+0x58], 0x40
00007b4681bd2860  vmovaps xmm1, [rsp+0x60]
00007b4681bd2866  vmovaps [rsp+0x60], xmm15
00007b4681bd286c  vmovaps xmm15, [rsp+0x100]
00007b4681bd2875  vmovaps [rsp+0x100], xmm14
00007b4681bd287e  vmovaps xmm14, [rsp+0x60]
00007b4681bd2884  vmovaps [rsp+0x60], xmm13
00007b4681bd288a  vmovaps [rsp+0x120], xmm12
00007b4681bd2893  movaps xmm13, xmm1
00007b4681bd2897  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd28a2  vptest xmm12, xmm12
00007b4681bd28a7  jnz 0x00007B4681BD3482
00007b4681bd28ad  vmovaps xmm1, [rsp+0xE0]
00007b4681bd28b6  movaps xmm15, xmm5
00007b4681bd28ba  vfmadd231pd xmm15, xmm1, xmm14
00007b4681bd28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007b4681bd28c5  vptest xmm12, xmm12
00007b4681bd28ca  jnz 0x00007B4681BD35DB
00007b4681bd28d0  vmovaps xmm12, [rsp+0x50]
00007b4681bd28d6  vmovaps xmm5, [rsp+0x50]
00007b4681bd28dc  por xmm12, xmm5
00007b4681bd28e1  vmovaps xmm5, [rsp+0x30]
00007b4681bd28e7  vmovaps [rsp+0x50], xmm1
00007b4681bd28ed  vmovaps xmm1, [rsp+0x30]
00007b4681bd28f3  por xmm5, xmm1
00007b4681bd28f7  vmovaps [rsp+0x30], xmm10
00007b4681bd28fd  vmovaps xmm1, [rsp+0x30]
00007b4681bd2903  por xmm10, xmm1
00007b4681bd2908  vmovaps [rsp+0x30], xmm8
00007b4681bd290e  vmovaps xmm1, [rsp+0x30]
00007b4681bd2914  por xmm8, xmm1
00007b4681bd2919  vmovaps xmm1, [rsp+0x120]
00007b4681bd2922  vmovaps [rsp+0x30], xmm15
00007b4681bd2928  vmovaps xmm15, [rsp+0x120]
00007b4681bd2931  por xmm1, xmm15
00007b4681bd2936  vmovaps xmm15, [rsp+0x50]
00007b4681bd293c  vmovaps [rsp+0xE0], xmm1
00007b4681bd2945  vmovaps xmm1, [rsp+0x50]
00007b4681bd294b  por xmm15, xmm1
00007b4681bd2950  lea rax, [r14+0xC0]
00007b4681bd2957  movups xmm1, [r13+rax*1]
00007b4681bd295d  xor eax, eax
00007b4681bd295f  mov r12d, 0x40
00007b4681bd2965  mov r11d, 0x200
00007b4681bd296b  cmp r12, r11
00007b4681bd296e  cmc
00007b4681bd296f  lahf
00007b4681bd2970  seto al
00007b4681bd2973  mov [r15+0x108], eax
00007b4681bd297a  vmovaps [rsp+0x50], xmm1
00007b4681bd2980  vmovaps xmm1, [rsp+0xF0]
00007b4681bd2989  vmovaps [rsp+0xF0], xmm15
00007b4681bd2992  vmovaps xmm15, [rsp+0x50]
00007b4681bd2998  vmovaps [rsp+0x50], xmm13
00007b4681bd299e  vmovaps [rsp+0x120], xmm12
00007b4681bd29a7  movaps xmm13, xmm1
00007b4681bd29ab  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd29b6  vptest xmm12, xmm12
00007b4681bd29bb  jnz 0x00007B4681BD373D
00007b4681bd29c1  lea rax, [r14+0xB0]
00007b4681bd29c8  movups xmm1, [r13+rax*1]
00007b4681bd29ce  vmovaps xmm15, [rsp+0x110]
00007b4681bd29d7  vmovaps [rsp+0x110], xmm13
00007b4681bd29e0  movaps xmm12, xmm15
00007b4681bd29e4  vfmadd231pd xmm12, xmm1, xmm14
00007b4681bd29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007b4681bd29ef  vptest xmm13, xmm13
00007b4681bd29f4  jnz 0x00007B4681BD38A0
00007b4681bd29fa  vmovaps xmm1, [rsp+0x100]
00007b4681bd2a03  vmovaps xmm15, [rsp+0x100]
00007b4681bd2a0c  por xmm1, xmm15
00007b4681bd2a11  movaps [r15+0x210], xmm1
00007b4681bd2a19  vmovaps xmm15, [rsp+0x60]
00007b4681bd2a1f  vmovaps xmm14, [rsp+0x60]
00007b4681bd2a25  por xmm15, xmm14
00007b4681bd2a2a  movaps [r15+0x1C0], xmm15
00007b4681bd2a32  vmovaps [rsp+0x60], xmm11
00007b4681bd2a38  vmovaps xmm14, [rsp+0x60]
00007b4681bd2a3e  por xmm11, xmm14
00007b4681bd2a43  movaps [r15+0x280], xmm11
00007b4681bd2a4b  vmovaps [rsp+0x60], xmm6
00007b4681bd2a51  vmovaps xmm14, [rsp+0x60]
00007b4681bd2a57  por xmm6, xmm14
00007b4681bd2a5c  movaps [r15+0x2A0], xmm6
00007b4681bd2a64  vmovaps xmm14, [rsp+0x20]
00007b4681bd2a6a  vmovaps xmm13, [rsp+0x20]
00007b4681bd2a70  por xmm14, xmm13
00007b4681bd2a75  movaps [r15+0x2E0], xmm14
00007b4681bd2a7d  vmovaps xmm13, [rsp+0x10]
00007b4681bd2a83  vmovaps [rsp+0x20], xmm1
00007b4681bd2a89  vmovaps xmm1, [rsp+0x10]
00007b4681bd2a8f  por xmm13, xmm1
00007b4681bd2a94  movaps [r15+0x1F0], xmm13
00007b4681bd2a9c  vmovaps xmm1, [rsp+0xF0]
00007b4681bd2aa5  vmovaps [rsp+0x10], xmm15
00007b4681bd2aab  vmovaps xmm15, [rsp+0xF0]
00007b4681bd2ab4  por xmm1, xmm15
00007b4681bd2ab9  movaps [r15+0x250], xmm1
00007b4681bd2ac1  vmovaps xmm1, [rsp+0xE0]
00007b4681bd2aca  vmovaps xmm15, [rsp+0xE0]
00007b4681bd2ad3  por xmm1, xmm15
00007b4681bd2ad8  movaps [r15+0x260], xmm1
00007b4681bd2ae0  vmovaps [rsp+0x60], xmm8
00007b4681bd2ae6  vmovaps xmm15, [rsp+0x60]
00007b4681bd2aec  por xmm8, xmm15
00007b4681bd2af1  movaps [r15+0x290], xmm8
00007b4681bd2af9  vmovaps [rsp+0x60], xmm10
00007b4681bd2aff  vmovaps xmm15, [rsp+0x60]
00007b4681bd2b05  por xmm10, xmm15
00007b4681bd2b0a  movaps [r15+0x2C0], xmm10
00007b4681bd2b12  movq xmm15, qword ptr [r15+0x240]
00007b4681bd2b1b  vmovaps [rsp+0x60], xmm15
00007b4681bd2b21  vpermilpd xmm15, xmm15, 0x00
00007b4681bd2b27  vmovaps [rsp+0xE0], xmm1
00007b4681bd2b30  vmovaps xmm1, [rsp+0x50]
00007b4681bd2b36  vmovaps [rsp+0x50], xmm15
00007b4681bd2b3c  vmovaps xmm15, [rsp+0x20]
00007b4681bd2b42  vmovaps [rsp+0x20], xmm14
00007b4681bd2b48  vmovaps xmm14, [rsp+0x50]
00007b4681bd2b4e  vmovaps [rsp+0x50], xmm13
00007b4681bd2b54  vmovaps [rsp+0xF0], xmm12
00007b4681bd2b5d  movaps xmm13, xmm1
00007b4681bd2b61  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd2b6c  vptest xmm12, xmm12
00007b4681bd2b71  jnz 0x00007B4681BD39F9
00007b4681bd2b77  vmovaps xmm1, [rsp+0x60]
00007b4681bd2b7d  vpermilpd xmm1, xmm1, 0x00
00007b4681bd2b83  vmovaps xmm15, [rsp+0x110]
00007b4681bd2b8c  vmovaps xmm14, [rsp+0x20]
00007b4681bd2b92  vmovaps [rsp+0x20], xmm13
00007b4681bd2b98  movaps xmm12, xmm15
00007b4681bd2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007b4681bd2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007b4681bd2ba7  vptest xmm13, xmm13
00007b4681bd2bac  jnz 0x00007B4681BD3B52
00007b4681bd2bb2  vmovaps xmm1, [rsp+0x60]
00007b4681bd2bb8  vpermilpd xmm1, xmm1, 0x00
00007b4681bd2bbe  vmovaps xmm15, [rsp+0x30]
00007b4681bd2bc4  vmovaps xmm14, [rsp+0x10]
00007b4681bd2bca  vmovaps [rsp+0x10], xmm12
00007b4681bd2bd0  movaps xmm13, xmm15
00007b4681bd2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007b4681bd2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd2bdf  vptest xmm12, xmm12
00007b4681bd2be4  jnz 0x00007B4681BD3CAB
00007b4681bd2bea  vmovaps [rsp+0x30], xmm5
00007b4681bd2bf0  vmovaps xmm1, [rsp+0x30]
00007b4681bd2bf6  por xmm5, xmm1
00007b4681bd2bfa  movaps [r15+0x1D0], xmm5
00007b4681bd2c02  vmovaps xmm1, [rsp+0x60]
00007b4681bd2c08  vpermilpd xmm1, xmm1, 0x00
00007b4681bd2c0e  vmovaps xmm15, [rsp+0xF0]
00007b4681bd2c17  vmovaps xmm14, [rsp+0x50]
00007b4681bd2c1d  vmovaps [rsp+0x30], xmm13
00007b4681bd2c23  movaps xmm12, xmm15
00007b4681bd2c27  vfmadd231pd xmm12, xmm14, xmm1
00007b4681bd2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007b4681bd2c32  vptest xmm13, xmm13
00007b4681bd2c37  jnz 0x00007B4681BD3E04
00007b4681bd2c3d  vmovaps xmm1, [rsp+0x80]
00007b4681bd2c46  vmovaps xmm15, [rsp+0x80]
00007b4681bd2c4f  por xmm1, xmm15
00007b4681bd2c54  movaps [r15+0x200], xmm1
00007b4681bd2c5c  vmovaps xmm15, [rsp+0x120]
00007b4681bd2c65  vmovaps xmm14, [rsp+0x120]
00007b4681bd2c6e  por xmm15, xmm14
00007b4681bd2c73  movaps [r15+0x1E0], xmm15
00007b4681bd2c7b  vmovaps [rsp+0x50], xmm4
00007b4681bd2c81  vmovaps xmm13, [rsp+0x50]
00007b4681bd2c87  por xmm4, xmm13
00007b4681bd2c8c  movaps [r15+0x2B0], xmm4
00007b4681bd2c94  vmovaps [rsp+0x50], xmm3
00007b4681bd2c9a  vmovaps xmm13, [rsp+0x50]
00007b4681bd2ca0  por xmm3, xmm13
00007b4681bd2ca5  movaps [r15+0x300], xmm3
00007b4681bd2cad  vmovaps xmm15, [rsp+0xB0]
00007b4681bd2cb6  vpermilpd xmm15, xmm15, 0x00
00007b4681bd2cbc  vmovaps xmm3, [rsp+0x20]
00007b4681bd2cc2  vmovaps [rsp+0x20], xmm1
00007b4681bd2cc8  vmovaps xmm1, [rsp+0xE0]
00007b4681bd2cd1  vmovaps [rsp+0x50], xmm14
00007b4681bd2cd7  vmovaps [rsp+0x60], xmm13
00007b4681bd2cdd  movaps xmm14, xmm3
00007b4681bd2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007b4681bd2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007b4681bd2cec  vptest xmm13, xmm13
00007b4681bd2cf1  jnz 0x00007B4681BD3F5D
00007b4681bd2cf7  vmovaps xmm1, [rsp+0xB0]
00007b4681bd2d00  vpermilpd xmm1, xmm1, 0x00
00007b4681bd2d06  vmovaps xmm15, [rsp+0x10]
00007b4681bd2d0c  movaps xmm13, xmm15
00007b4681bd2d10  vfmadd231pd xmm13, xmm10, xmm1
00007b4681bd2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007b4681bd2d1b  vptest xmm3, xmm3
00007b4681bd2d20  jnz 0x00007B4681BD40B5
00007b4681bd2d26  vmovaps xmm1, [rsp+0xB0]
00007b4681bd2d2f  vpermilpd xmm1, xmm1, 0x00
00007b4681bd2d35  vmovaps xmm15, [rsp+0x30]
00007b4681bd2d3b  movaps xmm10, xmm15
00007b4681bd2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007b4681bd2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007b4681bd2d4a  vptest xmm3, xmm3
00007b4681bd2d4f  jnz 0x00007B4681BD420E
00007b4681bd2d55  vmovaps xmm1, [rsp+0xB0]
00007b4681bd2d5e  vpermilpd xmm1, xmm1, 0x00
00007b4681bd2d64  movaps xmm15, xmm12
00007b4681bd2d68  vfmadd231pd xmm15, xmm5, xmm1
00007b4681bd2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007b4681bd2d73  vptest xmm11, xmm11
00007b4681bd2d78  jnz 0x00007B4681BD4367
00007b4681bd2d7e  vmovaps [rsp+0x10], xmm9
00007b4681bd2d84  vmovaps xmm1, [rsp+0x10]
00007b4681bd2d8a  por xmm9, xmm1
00007b4681bd2d8f  movaps [r15+0x180], xmm9
00007b4681bd2d97  vmovaps [rsp+0x10], xmm2
00007b4681bd2d9d  vmovaps xmm1, [rsp+0x10]
00007b4681bd2da3  por xmm2, xmm1
00007b4681bd2da7  movaps [r15+0x2D0], xmm2
00007b4681bd2daf  vmovaps xmm12, [rsp+0xD0]
00007b4681bd2db8  vpermilpd xmm12, xmm12, 0x00
00007b4681bd2dbe  vmovaps xmm11, [rsp+0x60]
00007b4681bd2dc4  movaps xmm5, xmm13
00007b4681bd2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007b4681bd2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007b4681bd2dd2  vptest xmm3, xmm3
00007b4681bd2dd7  jnz 0x00007B4681BD44BF
00007b4681bd2ddd  vmovaps xmm13, [rsp+0xD0]
00007b4681bd2de6  vpermilpd xmm13, xmm13, 0x00
00007b4681bd2dec  movaps xmm12, xmm14
00007b4681bd2df0  vfmadd231pd xmm12, xmm9, xmm13
00007b4681bd2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007b4681bd2dfb  vptest xmm11, xmm11
00007b4681bd2e00  jnz 0x00007B4681BD4617
00007b4681bd2e06  lea rax, [r14+0x80]
00007b4681bd2e0d  movups xmm14, [r13+rax*1]
00007b4681bd2e13  movaps [r15+0x2F0], xmm14
00007b4681bd2e1b  vmovaps xmm13, [rsp+0xD0]
00007b4681bd2e24  vpermilpd xmm13, xmm13, 0x00
00007b4681bd2e2a  movaps xmm11, xmm10
00007b4681bd2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007b4681bd2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007b4681bd2e39  vptest xmm9, xmm9
00007b4681bd2e3e  jnz 0x00007B4681BD477B
00007b4681bd2e44  vmovaps xmm13, [rsp+0xD0]
00007b4681bd2e4d  vpermilpd xmm13, xmm13, 0x00
00007b4681bd2e53  movaps xmm10, xmm15
00007b4681bd2e57  vfmadd231pd xmm10, xmm1, xmm13
00007b4681bd2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007b4681bd2e62  vptest xmm9, xmm9
00007b4681bd2e67  jnz 0x00007B4681BD48D5
00007b4681bd2e6d  vmovaps [rsp+0x10], xmm7
00007b4681bd2e73  vmovaps xmm1, [rsp+0x10]
00007b4681bd2e79  por xmm7, xmm1
00007b4681bd2e7d  movaps [r15+0x160], xmm7
00007b4681bd2e85  lea rax, [r14+0x40]
00007b4681bd2e89  movups xmm1, [r13+rax*1]
00007b4681bd2e8f  lea rax, [r14+0x50]
00007b4681bd2e93  movups xmm15, [r13+rax*1]
00007b4681bd2e99  movaps [r15+0x1B0], xmm1
00007b4681bd2ea1  movaps [r15+0x1A0], xmm15
00007b4681bd2ea9  vmovaps xmm13, [rsp+0xA0]
00007b4681bd2eb2  vpermilpd xmm13, xmm13, 0x00
00007b4681bd2eb8  vmovaps xmm9, [rsp+0x40]
00007b4681bd2ebe  movaps xmm8, xmm5
00007b4681bd2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007b4681bd2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007b4681bd2ecd  vptest xmm3, xmm3
00007b4681bd2ed2  jnz 0x00007B4681BD4A42
00007b4681bd2ed8  vmovaps xmm13, [rsp+0xA0]
00007b4681bd2ee1  vpermilpd xmm13, xmm13, 0x00
00007b4681bd2ee7  movaps xmm9, xmm12
00007b4681bd2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007b4681bd2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007b4681bd2ef6  vptest xmm5, xmm5
00007b4681bd2efb  jnz 0x00007B4681BD4B9B
00007b4681bd2f01  vmovaps xmm13, [rsp+0xA0]
00007b4681bd2f0a  vpermilpd xmm13, xmm13, 0x00
00007b4681bd2f10  movaps xmm12, xmm11
00007b4681bd2f14  vfmadd231pd xmm12, xmm6, xmm13
00007b4681bd2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007b4681bd2f1f  vptest xmm7, xmm7
00007b4681bd2f24  jnz 0x00007B4681BD4CF4
00007b4681bd2f2a  vmovaps xmm13, [rsp+0xA0]
00007b4681bd2f33  vpermilpd xmm13, xmm13, 0x00
00007b4681bd2f39  vmovaps xmm11, [rsp+0x50]
00007b4681bd2f3f  movaps xmm7, xmm10
00007b4681bd2f43  vfmadd231pd xmm7, xmm11, xmm13
00007b4681bd2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007b4681bd2f4d  vptest xmm6, xmm6
00007b4681bd2f52  jnz 0x00007B4681BD4E4D
00007b4681bd2f58  lea rax, [r14+0x60]
00007b4681bd2f5c  movups xmm13, [r13+rax*1]
00007b4681bd2f62  lea rax, [r14+0x70]
00007b4681bd2f66  movups xmm11, [r13+rax*1]
00007b4681bd2f6c  movaps [r15+0x150], xmm13
00007b4681bd2f74  movaps [r15+0x120], xmm11
00007b4681bd2f7c  vmovaps xmm10, [rsp+0xC0]
00007b4681bd2f85  vpermilpd xmm10, xmm10, 0x00
00007b4681bd2f8b  movaps xmm6, xmm8
00007b4681bd2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007b4681bd2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007b4681bd2f99  vptest xmm5, xmm5
00007b4681bd2f9e  jnz 0x00007B4681BD4FB9
00007b4681bd2fa4  vmovaps xmm15, [rsp+0xC0]
00007b4681bd2fad  vpermilpd xmm15, xmm15, 0x00
00007b4681bd2fb3  movaps xmm10, xmm9
00007b4681bd2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007b4681bd2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007b4681bd2fc2  vptest xmm8, xmm8
00007b4681bd2fc7  jnz 0x00007B4681BD5111
00007b4681bd2fcd  vmovaps xmm15, [rsp+0xC0]
00007b4681bd2fd6  vpermilpd xmm15, xmm15, 0x00
00007b4681bd2fdc  movaps xmm13, xmm12
00007b4681bd2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007b4681bd2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007b4681bd2feb  vptest xmm9, xmm9
00007b4681bd2ff0  jnz 0x00007B4681BD526B
00007b4681bd2ff6  vmovaps xmm15, [rsp+0xC0]
00007b4681bd2fff  vpermilpd xmm15, xmm15, 0x00
00007b4681bd3005  movaps xmm12, xmm7
00007b4681bd3009  vfmadd231pd xmm12, xmm1, xmm15
00007b4681bd300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007b4681bd3014  vptest xmm9, xmm9
00007b4681bd3019  jnz 0x00007B4681BD53C4
00007b4681bd301f  lea rax, [r14+0x20]
00007b4681bd3023  movups xmm1, [r13+rax*1]
00007b4681bd3029  lea rax, [r14+0x30]
00007b4681bd302d  movups xmm15, [r13+rax*1]
00007b4681bd3033  vmovaps xmm9, [rsp+0x70]
00007b4681bd3039  vpermilpd xmm9, xmm9, 0x00
00007b4681bd303f  vmovaps xmm8, [rsp+0x20]
00007b4681bd3045  movaps xmm7, xmm6
00007b4681bd3048  vfmadd231pd xmm7, xmm8, xmm9
00007b4681bd304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007b4681bd3052  vptest xmm5, xmm5
00007b4681bd3057  jnz 0x00007B4681BD5530
00007b4681bd305d  vmovaps xmm9, [rsp+0x70]
00007b4681bd3063  vpermilpd xmm9, xmm9, 0x00
00007b4681bd3069  movaps xmm8, xmm10
00007b4681bd306d  vfmadd231pd xmm8, xmm14, xmm9
00007b4681bd3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007b4681bd3078  vptest xmm6, xmm6
00007b4681bd307d  jnz 0x00007B4681BD5687
00007b4681bd3083  vmovaps xmm14, [rsp+0x70]
00007b4681bd3089  vpermilpd xmm14, xmm14, 0x00
00007b4681bd308f  movaps xmm10, xmm13
00007b4681bd3093  vfmadd231pd xmm10, xmm11, xmm14
00007b4681bd3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007b4681bd309e  vptest xmm9, xmm9
00007b4681bd30a3  jnz 0x00007B4681BD57E1
00007b4681bd30a9  vmovaps xmm14, [rsp+0x70]
00007b4681bd30af  vpermilpd xmm14, xmm14, 0x00
00007b4681bd30b5  movaps xmm13, xmm12
00007b4681bd30b9  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007b4681bd30c4  vptest xmm11, xmm11
00007b4681bd30c9  jnz 0x00007B4681BD593B
00007b4681bd30cf  lea rax, [r14+0x90]
00007b4681bd30d6  movups xmm15, [r13+rax*1]
00007b4681bd30dc  lea rax, [r14+0xA0]
00007b4681bd30e3  movups xmm14, [r13+rax*1]
00007b4681bd30e9  movaps [r15+0x140], xmm15
00007b4681bd30f1  movaps [r15+0x130], xmm14
00007b4681bd30f9  vmovaps xmm12, [rsp+0x90]
00007b4681bd3102  vpermilpd xmm12, xmm12, 0x00
00007b4681bd3108  movaps xmm11, xmm7
00007b4681bd310c  vfmadd231pd xmm11, xmm1, xmm12
00007b4681bd3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007b4681bd3117  vptest xmm9, xmm9
00007b4681bd311c  jnz 0x00007B4681BD5AA9
00007b4681bd3122  movaps [r15+0x220], xmm11
00007b4681bd312a  lea rax, [r14+0x10]
00007b4681bd312e  movups xmm1, [r13+rax*1]
00007b4681bd3134  movaps [r15+0x240], xmm1
00007b4681bd313c  vmovaps xmm12, [rsp+0x90]
00007b4681bd3145  vpermilpd xmm12, xmm12, 0x00
00007b4681bd314b  movaps xmm9, xmm8
00007b4681bd314f  vfmadd231pd xmm9, xmm14, xmm12
00007b4681bd3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007b4681bd315a  vptest xmm7, xmm7
00007b4681bd315f  jnz 0x00007B4681BD5C0B
00007b4681bd3165  movaps [r15+0x110], xmm9
00007b4681bd316d  vmovaps xmm14, [rsp+0x90]
00007b4681bd3176  vpermilpd xmm14, xmm14, 0x00
00007b4681bd317c  movaps xmm12, xmm10
00007b4681bd3180  vfmadd231pd xmm12, xmm15, xmm14
00007b4681bd3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007b4681bd318b  vptest xmm8, xmm8
00007b4681bd3190  jnz 0x00007B4681BD5D65
00007b4681bd3196  movaps [r15+0x170], xmm12
00007b4681bd319e  vmovaps xmm15, [rsp+0x90]
00007b4681bd31a7  vpermilpd xmm15, xmm15, 0x00
00007b4681bd31ad  movaps xmm14, xmm13
00007b4681bd31b1  vfmadd231pd xmm14, xmm1, xmm15
00007b4681bd31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007b4681bd31bc  vptest xmm10, xmm10
00007b4681bd31c1  jnz 0x00007B4681BD5EBF
00007b4681bd31c7  movaps [r15+0x230], xmm14
00007b4681bd31cf  mov eax, 0x432190
00007b4681bd31d4  movups [r13+rax*1], xmm9
00007b4681bd31da  mov eax, 0x4321A0
00007b4681bd31df  movups [r13+rax*1], xmm12
00007b4681bd31e5  mov eax, 0x4321B0
00007b4681bd31ea  movups [r13+rax*1], xmm11
00007b4681bd31f0  mov eax, 0x4321C0
00007b4681bd31f5  movups [r13+rax*1], xmm14
00007b4681bd31fb  mov eax, [r15+0x108]
00007b4681bd3202  sahf
00007b4681bd3203  jnz 0x00007B4681BD3235
00007b4681bd3205  cmp dword ptr [r15+0x318], 0x00
00007b4681bd320d  jz 0x00007B4681BD9950
00007b4681bd3213  nop [rax+rax*1], ax
00007b4681bd321c  nop [rax+rax*1], eax
00007b4681bd3224  mov eax, 0x410664
00007b4681bd3229  mov [r15+0x100], rax
00007b4681bd3230  jmp 0x00007B46819FE110
00007b4681bd3235  cmp dword ptr [r15+0x318], 0x00
00007b4681bd323d  jz 0x00007B4681BD6050
00007b4681bd3243  nop [rax+rax*1], ax
00007b4681bd324c  nop [rax+rax*1], eax
00007b4681bd3254  mov eax, 0x4104F0
00007b4681bd3259  mov [r15+0x100], rax
00007b4681bd3260  jmp 0x00007B46819FE110
00007b4681bd3265  int3
00007b4681bd3266  call 0x00007B46819FF430
00007b4681bd326b  jmp 0x00007B4681BD230A
00007b4681bd3270  call 0x00007B4681AE5820
00007b4681bd3275  jmp 0x00007B4681BD2314
00007b4681bd327a  call 0x00007B4681AE45A0
00007b4681bd327f  jmp 0x00007B4681BD2326
00007b4681bd3284  call 0x00007B4681AE3320
00007b4681bd3289  jmp 0x00007B4681BD2330
00007b4681bd328e  call 0x00007B4681AE20A0
00007b4681bd3293  jmp 0x00007B4681BD233D
00007b4681bd3298  call 0x00007B4681AE0E30
00007b4681bd329d  jmp 0x00007B4681BD234A
00007b4681bd32a2  call 0x00007B4681AD6600
00007b4681bd32a7  jmp 0x00007B4681BD2357
00007b4681bd32ac  call 0x00007B4681AB52F0
00007b4681bd32b1  jmp 0x00007B4681BD2361
00007b4681bd32b6  call 0x00007B4681ABE9C0
00007b4681bd32bb  jmp 0x00007B4681BD236B
00007b4681bd32c0  call 0x00007B4681ABD750
00007b4681bd32c5  jmp 0x00007B4681BD2378
00007b4681bd32ca  call 0x00007B4681ABC4E0
00007b4681bd32cf  jmp 0x00007B4681BD2385
00007b4681bd32d4  call 0x00007B4681ABB270
00007b4681bd32d9  jmp 0x00007B4681BD2392
00007b4681bd32de  call 0x00007B4681ABA000
00007b4681bd32e3  jmp 0x00007B4681BD239F
00007b4681bd32e8  call 0x00007B4681AB8D90
00007b4681bd32ed  jmp 0x00007B4681BD23AC
00007b4681bd32f2  call 0x00007B4681AB8A20
00007b4681bd32f7  jmp 0x00007B4681BD23B9
00007b4681bd32fc  call 0x00007B4681ABEAE0
00007b4681bd3301  jmp 0x00007B4681BD23C6
00007b4681bd3306  call 0x00007B4681AB5400
00007b4681bd330b  jmp 0x00007B4681BD23D3
00007b4681bd3310  call 0x00007B4681AB52F0
00007b4681bd3315  jmp 0x00007B4681BD23E0
00007b4681bd331a  call 0x00007B4681ABE9C0
00007b4681bd331f  jmp 0x00007B4681BD23ED
00007b4681bd3324  call 0x00007B4681AB77B0
00007b4681bd3329  jmp 0x00007B4681BD23FA
00007b4681bd332e  call 0x00007B4681AB6550
00007b4681bd3333  jmp 0x00007B4681BD2407
00007b4681bd3338  call 0x00007B4681AB52F0
00007b4681bd333d  jmp 0x00007B4681BD2417
00007b4681bd3342  call 0x00007B4681AB52F0
00007b4681bd3347  jmp 0x00007B4681BD2427
00007b4681bd334c  call 0x00007B4681ABEAE0
00007b4681bd3351  jmp 0x00007B4681BD2431
00007b4681bd3356  call 0x00007B4681ABEAE0
00007b4681bd335b  jmp 0x00007B4681BD2444
00007b4681bd3360  call 0x00007B4681ABE9C0
00007b4681bd3365  jmp 0x00007B4681BD2451
00007b4681bd336a  call 0x00007B4681AB52F0
00007b4681bd336f  jmp 0x00007B4681BD2464
00007b4681bd3374  call 0x00007B4681AB6660
00007b4681bd3379  jmp 0x00007B4681BD2471
00007b4681bd337e  call 0x00007B4681AB78C0
00007b4681bd3383  jmp 0x00007B4681BD247E
00007b4681bd3388  call 0x00007B4681AB77B0
00007b4681bd338d  jmp 0x00007B4681BD248B
00007b4681bd3392  call 0x00007B4681AB6550
00007b4681bd3397  jmp 0x00007B4681BD2498
00007b4681bd339c  call 0x00007B4681AB52F0
00007b4681bd33a1  jmp 0x00007B4681BD24AB
00007b4681bd33a6  call 0x00007B4681AB52F0
00007b4681bd33ab  jmp 0x00007B4681BD24BE
00007b4681bd33b0  call 0x00007B4681AB52F0
00007b4681bd33b5  jmp 0x00007B4681BD24E5
00007b4681bd33ba  call 0x00007B4681AB52F0
00007b4681bd33bf  jmp 0x00007B4681BD24F8
00007b4681bd33c4  call 0x00007B4681AB52F0
00007b4681bd33c9  jmp 0x00007B4681BD250B
00007b4681bd33ce  call 0x00007B4681AB52F0
00007b4681bd33d3  jmp 0x00007B4681BD2521
00007b4681bd33d8  call 0x00007B4681AB52F0
00007b4681bd33dd  jmp 0x00007B4681BD2537
00007b4681bd33e2  call 0x00007B4681AB52F0
00007b4681bd33e7  jmp 0x00007B4681BD254D
00007b4681bd33ec  call 0x00007B46819FF540
00007b4681bd33f1  jmp 0x00007B4681BD256E
00007b4681bd33f6  call 0x00007B4681A02FE0
00007b4681bd33fb  jmp 0x00007B4681BD2578
00007b4681bd3400  call 0x00007B46819FF540
00007b4681bd3405  jmp 0x00007B4681BD2588
00007b4681bd340a  call 0x00007B46819FF540
00007b4681bd340f  jmp 0x00007B4681BD259B
00007b4681bd3414  call 0x00007B46819FF540
00007b4681bd3419  jmp 0x00007B4681BD25AE
00007b4681bd341e  call 0x00007B46819FF540
00007b4681bd3423  jmp 0x00007B4681BD25C1
00007b4681bd3428  call 0x00007B4681AC0370
00007b4681bd342d  jmp 0x00007B4681BD25E0
00007b4681bd3432  call 0x00007B4681ABF100
00007b4681bd3437  jmp 0x00007B4681BD25E9
00007b4681bd343c  call 0x00007B4681AC0370
00007b4681bd3441  jmp 0x00007B4681BD2659
00007b4681bd3446  call 0x00007B4681ABF100
00007b4681bd344b  jmp 0x00007B4681BD2662
00007b4681bd3450  call 0x00007B4681AC0370
00007b4681bd3455  jmp 0x00007B4681BD270C
00007b4681bd345a  call 0x00007B4681ABF100
00007b4681bd345f  jmp 0x00007B4681BD2715
00007b4681bd3464  call 0x00007B4681A0B720
00007b4681bd3469  jmp 0x00007B4681BD27F7
00007b4681bd346e  call 0x00007B4681AD64F0
00007b4681bd3473  jmp 0x00007B4681BD281F
00007b4681bd3478  call 0x00007B4681AB47C0
00007b4681bd347d  jmp 0x00007B4681BD283A
00007b4681bd3482  sub rsp, 0x08
00007b4681bd3486  push rax
00007b4681bd3487  push rcx
00007b4681bd3488  push rdx
00007b4681bd3489  push rdi
00007b4681bd348a  push rsi
00007b4681bd348b  push r8
00007b4681bd348d  push r9
00007b4681bd348f  push r10
00007b4681bd3491  push r11
00007b4681bd3493  sub rsp, 0xF0
00007b4681bd349a  vmovaps [rsp], xmm0
00007b4681bd349f  vmovaps [rsp+0x10], xmm1
00007b4681bd34a5  vmovaps [rsp+0x20], xmm2
00007b4681bd34ab  vmovaps [rsp+0x30], xmm3
00007b4681bd34b1  vmovaps [rsp+0x40], xmm4
00007b4681bd34b7  vmovaps [rsp+0x50], xmm5
00007b4681bd34bd  vmovaps [rsp+0x60], xmm6
00007b4681bd34c3  vmovaps [rsp+0x70], xmm7
00007b4681bd34c9  vmovaps [rsp+0x80], xmm8
00007b4681bd34d2  vmovaps [rsp+0x90], xmm9
00007b4681bd34db  vmovaps [rsp+0xA0], xmm10
00007b4681bd34e4  vmovaps [rsp+0xB0], xmm11
00007b4681bd34ed  vmovaps [rsp+0xC0], xmm12
00007b4681bd34f6  vmovaps [rsp+0xD0], xmm14
00007b4681bd34ff  vmovaps [rsp+0xE0], xmm15
00007b4681bd3508  sub rsp, 0x40
00007b4681bd350c  lea rdi, [rsp]
00007b4681bd3510  lea rsi, [rsp+0x10]
00007b4681bd3515  lea rdx, [rsp+0x20]
00007b4681bd351a  lea rcx, [rsp+0x30]
00007b4681bd351f  mov r8d, 0x00
00007b4681bd3525  lea r9, [r15+0x3A8]
00007b4681bd352c  movaps [rdi], xmm13
00007b4681bd3530  movaps [rsi], xmm1
00007b4681bd3533  movaps [rdx], xmm15
00007b4681bd3537  movaps [rcx], xmm14
00007b4681bd353b  mov rax, 0x5668589B5A50
00007b4681bd3545  call rax
00007b4681bd3547  movaps xmm13, [rsp]
00007b4681bd354c  add rsp, 0x40
00007b4681bd3550  vmovaps xmm0, [rsp]
00007b4681bd3555  vmovaps xmm1, [rsp+0x10]
00007b4681bd355b  vmovaps xmm2, [rsp+0x20]
00007b4681bd3561  vmovaps xmm3, [rsp+0x30]
00007b4681bd3567  vmovaps xmm4, [rsp+0x40]
00007b4681bd356d  vmovaps xmm5, [rsp+0x50]
00007b4681bd3573  vmovaps xmm6, [rsp+0x60]
00007b4681bd3579  vmovaps xmm7, [rsp+0x70]
00007b4681bd357f  vmovaps xmm8, [rsp+0x80]
00007b4681bd3588  vmovaps xmm9, [rsp+0x90]
00007b4681bd3591  vmovaps xmm10, [rsp+0xA0]
00007b4681bd359a  vmovaps xmm11, [rsp+0xB0]
00007b4681bd35a3  vmovaps xmm12, [rsp+0xC0]
00007b4681bd35ac  vmovaps xmm14, [rsp+0xD0]
00007b4681bd35b5  vmovaps xmm15, [rsp+0xE0]
00007b4681bd35be  add rsp, 0xF0
00007b4681bd35c5  pop r11
00007b4681bd35c7  pop r10
00007b4681bd35c9  pop r9
00007b4681bd35cb  pop r8
00007b4681bd35cd  pop rsi
00007b4681bd35ce  pop rdi
00007b4681bd35cf  pop rdx
00007b4681bd35d0  pop rcx
00007b4681bd35d1  pop rax
00007b4681bd35d2  add rsp, 0x08
00007b4681bd35d6  jmp 0x00007B4681BD28AD
00007b4681bd35db  sub rsp, 0x08
00007b4681bd35df  push rax
00007b4681bd35e0  push rcx
00007b4681bd35e1  push rdx
00007b4681bd35e2  push rdi
00007b4681bd35e3  push rsi
00007b4681bd35e4  push r8
00007b4681bd35e6  push r9
00007b4681bd35e8  push r10
00007b4681bd35ea  push r11
00007b4681bd35ec  sub rsp, 0xF0
00007b4681bd35f3  vmovaps [rsp], xmm0
00007b4681bd35f8  vmovaps [rsp+0x10], xmm1
00007b4681bd35fe  vmovaps [rsp+0x20], xmm2
00007b4681bd3604  vmovaps [rsp+0x30], xmm3
00007b4681bd360a  vmovaps [rsp+0x40], xmm4
00007b4681bd3610  vmovaps [rsp+0x50], xmm5
00007b4681bd3616  vmovaps [rsp+0x60], xmm6
00007b4681bd361c  vmovaps [rsp+0x70], xmm7
00007b4681bd3622  vmovaps [rsp+0x80], xmm8
00007b4681bd362b  vmovaps [rsp+0x90], xmm9
00007b4681bd3634  vmovaps [rsp+0xA0], xmm10
00007b4681bd363d  vmovaps [rsp+0xB0], xmm11
00007b4681bd3646  vmovaps [rsp+0xC0], xmm12
00007b4681bd364f  vmovaps [rsp+0xD0], xmm13
00007b4681bd3658  vmovaps [rsp+0xE0], xmm14
00007b4681bd3661  sub rsp, 0x40
00007b4681bd3665  lea rdi, [rsp]
00007b4681bd3669  lea rsi, [rsp+0x10]
00007b4681bd366e  lea rdx, [rsp+0x20]
00007b4681bd3673  lea rcx, [rsp+0x30]
00007b4681bd3678  mov r8d, 0x00
00007b4681bd367e  lea r9, [r15+0x3A8]
00007b4681bd3685  movaps [rdi], xmm15
00007b4681bd3689  movaps [rsi], xmm5
00007b4681bd368c  movaps [rdx], xmm1
00007b4681bd368f  movaps [rcx], xmm14
00007b4681bd3693  mov rax, 0x5668589B5A50
00007b4681bd369d  call rax
00007b4681bd369f  movaps xmm15, [rsp]
00007b4681bd36a4  add rsp, 0x40
00007b4681bd36a8  vmovaps xmm0, [rsp]
00007b4681bd36ad  vmovaps xmm1, [rsp+0x10]
00007b4681bd36b3  vmovaps xmm2, [rsp+0x20]
00007b4681bd36b9  vmovaps xmm3, [rsp+0x30]
00007b4681bd36bf  vmovaps xmm4, [rsp+0x40]
00007b4681bd36c5  vmovaps xmm5, [rsp+0x50]
00007b4681bd36cb  vmovaps xmm6, [rsp+0x60]
00007b4681bd36d1  vmovaps xmm7, [rsp+0x70]
00007b4681bd36d7  vmovaps xmm8, [rsp+0x80]
00007b4681bd36e0  vmovaps xmm9, [rsp+0x90]
00007b4681bd36e9  vmovaps xmm10, [rsp+0xA0]
00007b4681bd36f2  vmovaps xmm11, [rsp+0xB0]
00007b4681bd36fb  vmovaps xmm12, [rsp+0xC0]
00007b4681bd3704  vmovaps xmm13, [rsp+0xD0]
00007b4681bd370d  vmovaps xmm14, [rsp+0xE0]
00007b4681bd3716  add rsp, 0xF0
00007b4681bd371d  pop r11
00007b4681bd371f  pop r10
00007b4681bd3721  pop r9
00007b4681bd3723  pop r8
00007b4681bd3725  pop rsi
00007b4681bd3726  pop rdi
00007b4681bd3727  pop rdx
00007b4681bd3728  pop rcx
00007b4681bd3729  pop rax
00007b4681bd372a  add rsp, 0x08
00007b4681bd372e  jmp 0x00007B4681BD28D0
00007b4681bd3733  call 0x00007B46819FF430
00007b4681bd3738  jmp 0x00007B4681BD295D
00007b4681bd373d  sub rsp, 0x08
00007b4681bd3741  push rax
00007b4681bd3742  push rcx
00007b4681bd3743  push rdx
00007b4681bd3744  push rdi
00007b4681bd3745  push rsi
00007b4681bd3746  push r8
00007b4681bd3748  push r9
00007b4681bd374a  push r10
00007b4681bd374c  push r11
00007b4681bd374e  sub rsp, 0xF0
00007b4681bd3755  vmovaps [rsp], xmm0
00007b4681bd375a  vmovaps [rsp+0x10], xmm1
00007b4681bd3760  vmovaps [rsp+0x20], xmm2
00007b4681bd3766  vmovaps [rsp+0x30], xmm3
00007b4681bd376c  vmovaps [rsp+0x40], xmm4
00007b4681bd3772  vmovaps [rsp+0x50], xmm5
00007b4681bd3778  vmovaps [rsp+0x60], xmm6
00007b4681bd377e  vmovaps [rsp+0x70], xmm7
00007b4681bd3784  vmovaps [rsp+0x80], xmm8
00007b4681bd378d  vmovaps [rsp+0x90], xmm9
00007b4681bd3796  vmovaps [rsp+0xA0], xmm10
00007b4681bd379f  vmovaps [rsp+0xB0], xmm11
00007b4681bd37a8  vmovaps [rsp+0xC0], xmm12
00007b4681bd37b1  vmovaps [rsp+0xD0], xmm14
00007b4681bd37ba  vmovaps [rsp+0xE0], xmm15
00007b4681bd37c3  sub rsp, 0x40
00007b4681bd37c7  lea rdi, [rsp]
00007b4681bd37cb  lea rsi, [rsp+0x10]
00007b4681bd37d0  lea rdx, [rsp+0x20]
00007b4681bd37d5  lea rcx, [rsp+0x30]
00007b4681bd37da  mov r8d, 0x00
00007b4681bd37e0  lea r9, [r15+0x3A8]
00007b4681bd37e7  movaps [rdi], xmm13
00007b4681bd37eb  movaps [rsi], xmm1
00007b4681bd37ee  movaps [rdx], xmm15
00007b4681bd37f2  movaps [rcx], xmm14
00007b4681bd37f6  mov rax, 0x5668589B5A50
00007b4681bd3800  call rax
00007b4681bd3802  movaps xmm13, [rsp]
00007b4681bd3807  add rsp, 0x40
00007b4681bd380b  vmovaps xmm0, [rsp]
00007b4681bd3810  vmovaps xmm1, [rsp+0x10]
00007b4681bd3816  vmovaps xmm2, [rsp+0x20]
00007b4681bd381c  vmovaps xmm3, [rsp+0x30]
00007b4681bd3822  vmovaps xmm4, [rsp+0x40]
00007b4681bd3828  vmovaps xmm5, [rsp+0x50]
00007b4681bd382e  vmovaps xmm6, [rsp+0x60]
00007b4681bd3834  vmovaps xmm7, [rsp+0x70]
00007b4681bd383a  vmovaps xmm8, [rsp+0x80]
00007b4681bd3843  vmovaps xmm9, [rsp+0x90]
00007b4681bd384c  vmovaps xmm10, [rsp+0xA0]
00007b4681bd3855  vmovaps xmm11, [rsp+0xB0]
00007b4681bd385e  vmovaps xmm12, [rsp+0xC0]
00007b4681bd3867  vmovaps xmm14, [rsp+0xD0]
00007b4681bd3870  vmovaps xmm15, [rsp+0xE0]
00007b4681bd3879  add rsp, 0xF0
00007b4681bd3880  pop r11
00007b4681bd3882  pop r10
00007b4681bd3884  pop r9
00007b4681bd3886  pop r8
00007b4681bd3888  pop rsi
00007b4681bd3889  pop rdi
00007b4681bd388a  pop rdx
00007b4681bd388b  pop rcx
00007b4681bd388c  pop rax
00007b4681bd388d  add rsp, 0x08
00007b4681bd3891  jmp 0x00007B4681BD29C1
00007b4681bd3896  call 0x00007B46819FF430
00007b4681bd389b  jmp 0x00007B4681BD29CE
00007b4681bd38a0  sub rsp, 0x08
00007b4681bd38a4  push rax
00007b4681bd38a5  push rcx
00007b4681bd38a6  push rdx
00007b4681bd38a7  push rdi
00007b4681bd38a8  push rsi
00007b4681bd38a9  push r8
00007b4681bd38ab  push r9
00007b4681bd38ad  push r10
00007b4681bd38af  push r11
00007b4681bd38b1  sub rsp, 0xF0
00007b4681bd38b8  vmovaps [rsp], xmm0
00007b4681bd38bd  vmovaps [rsp+0x10], xmm1
00007b4681bd38c3  vmovaps [rsp+0x20], xmm2
00007b4681bd38c9  vmovaps [rsp+0x30], xmm3
00007b4681bd38cf  vmovaps [rsp+0x40], xmm4
00007b4681bd38d5  vmovaps [rsp+0x50], xmm5
00007b4681bd38db  vmovaps [rsp+0x60], xmm6
00007b4681bd38e1  vmovaps [rsp+0x70], xmm7
00007b4681bd38e7  vmovaps [rsp+0x80], xmm8
00007b4681bd38f0  vmovaps [rsp+0x90], xmm9
00007b4681bd38f9  vmovaps [rsp+0xA0], xmm10
00007b4681bd3902  vmovaps [rsp+0xB0], xmm11
00007b4681bd390b  vmovaps [rsp+0xC0], xmm13
00007b4681bd3914  vmovaps [rsp+0xD0], xmm14
00007b4681bd391d  vmovaps [rsp+0xE0], xmm15
00007b4681bd3926  sub rsp, 0x40
00007b4681bd392a  lea rdi, [rsp]
00007b4681bd392e  lea rsi, [rsp+0x10]
00007b4681bd3933  lea rdx, [rsp+0x20]
00007b4681bd3938  lea rcx, [rsp+0x30]
00007b4681bd393d  mov r8d, 0x00
00007b4681bd3943  lea r9, [r15+0x3A8]
00007b4681bd394a  movaps [rdi], xmm12
00007b4681bd394e  movaps [rsi], xmm15
00007b4681bd3952  movaps [rdx], xmm1
00007b4681bd3955  movaps [rcx], xmm14
00007b4681bd3959  mov rax, 0x5668589B5A50
00007b4681bd3963  call rax
00007b4681bd3965  movaps xmm12, [rsp]
00007b4681bd396a  add rsp, 0x40
00007b4681bd396e  vmovaps xmm0, [rsp]
00007b4681bd3973  vmovaps xmm1, [rsp+0x10]
00007b4681bd3979  vmovaps xmm2, [rsp+0x20]
00007b4681bd397f  vmovaps xmm3, [rsp+0x30]
00007b4681bd3985  vmovaps xmm4, [rsp+0x40]
00007b4681bd398b  vmovaps xmm5, [rsp+0x50]
00007b4681bd3991  vmovaps xmm6, [rsp+0x60]
00007b4681bd3997  vmovaps xmm7, [rsp+0x70]
00007b4681bd399d  vmovaps xmm8, [rsp+0x80]
00007b4681bd39a6  vmovaps xmm9, [rsp+0x90]
00007b4681bd39af  vmovaps xmm10, [rsp+0xA0]
00007b4681bd39b8  vmovaps xmm11, [rsp+0xB0]
00007b4681bd39c1  vmovaps xmm13, [rsp+0xC0]
00007b4681bd39ca  vmovaps xmm14, [rsp+0xD0]
00007b4681bd39d3  vmovaps xmm15, [rsp+0xE0]
00007b4681bd39dc  add rsp, 0xF0
00007b4681bd39e3  pop r11
00007b4681bd39e5  pop r10
00007b4681bd39e7  pop r9
00007b4681bd39e9  pop r8
00007b4681bd39eb  pop rsi
00007b4681bd39ec  pop rdi
00007b4681bd39ed  pop rdx
00007b4681bd39ee  pop rcx
00007b4681bd39ef  pop rax
00007b4681bd39f0  add rsp, 0x08
00007b4681bd39f4  jmp 0x00007B4681BD29FA
00007b4681bd39f9  sub rsp, 0x08
00007b4681bd39fd  push rax
00007b4681bd39fe  push rcx
00007b4681bd39ff  push rdx
00007b4681bd3a00  push rdi
00007b4681bd3a01  push rsi
00007b4681bd3a02  push r8
00007b4681bd3a04  push r9
00007b4681bd3a06  push r10
00007b4681bd3a08  push r11
00007b4681bd3a0a  sub rsp, 0xF0
00007b4681bd3a11  vmovaps [rsp], xmm0
00007b4681bd3a16  vmovaps [rsp+0x10], xmm1
00007b4681bd3a1c  vmovaps [rsp+0x20], xmm2
00007b4681bd3a22  vmovaps [rsp+0x30], xmm3
00007b4681bd3a28  vmovaps [rsp+0x40], xmm4
00007b4681bd3a2e  vmovaps [rsp+0x50], xmm5
00007b4681bd3a34  vmovaps [rsp+0x60], xmm6
00007b4681bd3a3a  vmovaps [rsp+0x70], xmm7
00007b4681bd3a40  vmovaps [rsp+0x80], xmm8
00007b4681bd3a49  vmovaps [rsp+0x90], xmm9
00007b4681bd3a52  vmovaps [rsp+0xA0], xmm10
00007b4681bd3a5b  vmovaps [rsp+0xB0], xmm11
00007b4681bd3a64  vmovaps [rsp+0xC0], xmm12
00007b4681bd3a6d  vmovaps [rsp+0xD0], xmm14
00007b4681bd3a76  vmovaps [rsp+0xE0], xmm15
00007b4681bd3a7f  sub rsp, 0x40
00007b4681bd3a83  lea rdi, [rsp]
00007b4681bd3a87  lea rsi, [rsp+0x10]
00007b4681bd3a8c  lea rdx, [rsp+0x20]
00007b4681bd3a91  lea rcx, [rsp+0x30]
00007b4681bd3a96  mov r8d, 0x00
00007b4681bd3a9c  lea r9, [r15+0x3A8]
00007b4681bd3aa3  movaps [rdi], xmm13
00007b4681bd3aa7  movaps [rsi], xmm1
00007b4681bd3aaa  movaps [rdx], xmm15
00007b4681bd3aae  movaps [rcx], xmm14
00007b4681bd3ab2  mov rax, 0x5668589B5A50
00007b4681bd3abc  call rax
00007b4681bd3abe  movaps xmm13, [rsp]
00007b4681bd3ac3  add rsp, 0x40
00007b4681bd3ac7  vmovaps xmm0, [rsp]
00007b4681bd3acc  vmovaps xmm1, [rsp+0x10]
00007b4681bd3ad2  vmovaps xmm2, [rsp+0x20]
00007b4681bd3ad8  vmovaps xmm3, [rsp+0x30]
00007b4681bd3ade  vmovaps xmm4, [rsp+0x40]
00007b4681bd3ae4  vmovaps xmm5, [rsp+0x50]
00007b4681bd3aea  vmovaps xmm6, [rsp+0x60]
00007b4681bd3af0  vmovaps xmm7, [rsp+0x70]
00007b4681bd3af6  vmovaps xmm8, [rsp+0x80]
00007b4681bd3aff  vmovaps xmm9, [rsp+0x90]
00007b4681bd3b08  vmovaps xmm10, [rsp+0xA0]
00007b4681bd3b11  vmovaps xmm11, [rsp+0xB0]
00007b4681bd3b1a  vmovaps xmm12, [rsp+0xC0]
00007b4681bd3b23  vmovaps xmm14, [rsp+0xD0]
00007b4681bd3b2c  vmovaps xmm15, [rsp+0xE0]
00007b4681bd3b35  add rsp, 0xF0
00007b4681bd3b3c  pop r11
00007b4681bd3b3e  pop r10
00007b4681bd3b40  pop r9
00007b4681bd3b42  pop r8
00007b4681bd3b44  pop rsi
00007b4681bd3b45  pop rdi
00007b4681bd3b46  pop rdx
00007b4681bd3b47  pop rcx
00007b4681bd3b48  pop rax
00007b4681bd3b49  add rsp, 0x08
00007b4681bd3b4d  jmp 0x00007B4681BD2B77
00007b4681bd3b52  sub rsp, 0x08
00007b4681bd3b56  push rax
00007b4681bd3b57  push rcx
00007b4681bd3b58  push rdx
00007b4681bd3b59  push rdi
00007b4681bd3b5a  push rsi
00007b4681bd3b5b  push r8
00007b4681bd3b5d  push r9
00007b4681bd3b5f  push r10
00007b4681bd3b61  push r11
00007b4681bd3b63  sub rsp, 0xF0
00007b4681bd3b6a  vmovaps [rsp], xmm0
00007b4681bd3b6f  vmovaps [rsp+0x10], xmm1
00007b4681bd3b75  vmovaps [rsp+0x20], xmm2
00007b4681bd3b7b  vmovaps [rsp+0x30], xmm3
00007b4681bd3b81  vmovaps [rsp+0x40], xmm4
00007b4681bd3b87  vmovaps [rsp+0x50], xmm5
00007b4681bd3b8d  vmovaps [rsp+0x60], xmm6
00007b4681bd3b93  vmovaps [rsp+0x70], xmm7
00007b4681bd3b99  vmovaps [rsp+0x80], xmm8
00007b4681bd3ba2  vmovaps [rsp+0x90], xmm9
00007b4681bd3bab  vmovaps [rsp+0xA0], xmm10
00007b4681bd3bb4  vmovaps [rsp+0xB0], xmm11
00007b4681bd3bbd  vmovaps [rsp+0xC0], xmm13
00007b4681bd3bc6  vmovaps [rsp+0xD0], xmm14
00007b4681bd3bcf  vmovaps [rsp+0xE0], xmm15
00007b4681bd3bd8  sub rsp, 0x40
00007b4681bd3bdc  lea rdi, [rsp]
00007b4681bd3be0  lea rsi, [rsp+0x10]
00007b4681bd3be5  lea rdx, [rsp+0x20]
00007b4681bd3bea  lea rcx, [rsp+0x30]
00007b4681bd3bef  mov r8d, 0x00
00007b4681bd3bf5  lea r9, [r15+0x3A8]
00007b4681bd3bfc  movaps [rdi], xmm12
00007b4681bd3c00  movaps [rsi], xmm15
00007b4681bd3c04  movaps [rdx], xmm14
00007b4681bd3c08  movaps [rcx], xmm1
00007b4681bd3c0b  mov rax, 0x5668589B5A50
00007b4681bd3c15  call rax
00007b4681bd3c17  movaps xmm12, [rsp]
00007b4681bd3c1c  add rsp, 0x40
00007b4681bd3c20  vmovaps xmm0, [rsp]
00007b4681bd3c25  vmovaps xmm1, [rsp+0x10]
00007b4681bd3c2b  vmovaps xmm2, [rsp+0x20]
00007b4681bd3c31  vmovaps xmm3, [rsp+0x30]
00007b4681bd3c37  vmovaps xmm4, [rsp+0x40]
00007b4681bd3c3d  vmovaps xmm5, [rsp+0x50]
00007b4681bd3c43  vmovaps xmm6, [rsp+0x60]
00007b4681bd3c49  vmovaps xmm7, [rsp+0x70]
00007b4681bd3c4f  vmovaps xmm8, [rsp+0x80]
00007b4681bd3c58  vmovaps xmm9, [rsp+0x90]
00007b4681bd3c61  vmovaps xmm10, [rsp+0xA0]
00007b4681bd3c6a  vmovaps xmm11, [rsp+0xB0]
00007b4681bd3c73  vmovaps xmm13, [rsp+0xC0]
00007b4681bd3c7c  vmovaps xmm14, [rsp+0xD0]
00007b4681bd3c85  vmovaps xmm15, [rsp+0xE0]
00007b4681bd3c8e  add rsp, 0xF0
00007b4681bd3c95  pop r11
00007b4681bd3c97  pop r10
00007b4681bd3c99  pop r9
00007b4681bd3c9b  pop r8
00007b4681bd3c9d  pop rsi
00007b4681bd3c9e  pop rdi
00007b4681bd3c9f  pop rdx
00007b4681bd3ca0  pop rcx
00007b4681bd3ca1  pop rax
00007b4681bd3ca2  add rsp, 0x08
00007b4681bd3ca6  jmp 0x00007B4681BD2BB2
00007b4681bd3cab  sub rsp, 0x08
00007b4681bd3caf  push rax
00007b4681bd3cb0  push rcx
00007b4681bd3cb1  push rdx
00007b4681bd3cb2  push rdi
00007b4681bd3cb3  push rsi
00007b4681bd3cb4  push r8
00007b4681bd3cb6  push r9
00007b4681bd3cb8  push r10
00007b4681bd3cba  push r11
00007b4681bd3cbc  sub rsp, 0xF0
00007b4681bd3cc3  vmovaps [rsp], xmm0
00007b4681bd3cc8  vmovaps [rsp+0x10], xmm1
00007b4681bd3cce  vmovaps [rsp+0x20], xmm2
00007b4681bd3cd4  vmovaps [rsp+0x30], xmm3
00007b4681bd3cda  vmovaps [rsp+0x40], xmm4
00007b4681bd3ce0  vmovaps [rsp+0x50], xmm5
00007b4681bd3ce6  vmovaps [rsp+0x60], xmm6
00007b4681bd3cec  vmovaps [rsp+0x70], xmm7
00007b4681bd3cf2  vmovaps [rsp+0x80], xmm8
00007b4681bd3cfb  vmovaps [rsp+0x90], xmm9
00007b4681bd3d04  vmovaps [rsp+0xA0], xmm10
00007b4681bd3d0d  vmovaps [rsp+0xB0], xmm11
00007b4681bd3d16  vmovaps [rsp+0xC0], xmm12
00007b4681bd3d1f  vmovaps [rsp+0xD0], xmm14
00007b4681bd3d28  vmovaps [rsp+0xE0], xmm15
00007b4681bd3d31  sub rsp, 0x40
00007b4681bd3d35  lea rdi, [rsp]
00007b4681bd3d39  lea rsi, [rsp+0x10]
00007b4681bd3d3e  lea rdx, [rsp+0x20]
00007b4681bd3d43  lea rcx, [rsp+0x30]
00007b4681bd3d48  mov r8d, 0x00
00007b4681bd3d4e  lea r9, [r15+0x3A8]
00007b4681bd3d55  movaps [rdi], xmm13
00007b4681bd3d59  movaps [rsi], xmm15
00007b4681bd3d5d  movaps [rdx], xmm14
00007b4681bd3d61  movaps [rcx], xmm1
00007b4681bd3d64  mov rax, 0x5668589B5A50
00007b4681bd3d6e  call rax
00007b4681bd3d70  movaps xmm13, [rsp]
00007b4681bd3d75  add rsp, 0x40
00007b4681bd3d79  vmovaps xmm0, [rsp]
00007b4681bd3d7e  vmovaps xmm1, [rsp+0x10]
00007b4681bd3d84  vmovaps xmm2, [rsp+0x20]
00007b4681bd3d8a  vmovaps xmm3, [rsp+0x30]
00007b4681bd3d90  vmovaps xmm4, [rsp+0x40]
00007b4681bd3d96  vmovaps xmm5, [rsp+0x50]
00007b4681bd3d9c  vmovaps xmm6, [rsp+0x60]
00007b4681bd3da2  vmovaps xmm7, [rsp+0x70]
00007b4681bd3da8  vmovaps xmm8, [rsp+0x80]
00007b4681bd3db1  vmovaps xmm9, [rsp+0x90]
00007b4681bd3dba  vmovaps xmm10, [rsp+0xA0]
00007b4681bd3dc3  vmovaps xmm11, [rsp+0xB0]
00007b4681bd3dcc  vmovaps xmm12, [rsp+0xC0]
00007b4681bd3dd5  vmovaps xmm14, [rsp+0xD0]
00007b4681bd3dde  vmovaps xmm15, [rsp+0xE0]
00007b4681bd3de7  add rsp, 0xF0
00007b4681bd3dee  pop r11
00007b4681bd3df0  pop r10
00007b4681bd3df2  pop r9
00007b4681bd3df4  pop r8
00007b4681bd3df6  pop rsi
00007b4681bd3df7  pop rdi
00007b4681bd3df8  pop rdx
00007b4681bd3df9  pop rcx
00007b4681bd3dfa  pop rax
00007b4681bd3dfb  add rsp, 0x08
00007b4681bd3dff  jmp 0x00007B4681BD2BEA
00007b4681bd3e04  sub rsp, 0x08
00007b4681bd3e08  push rax
00007b4681bd3e09  push rcx
00007b4681bd3e0a  push rdx
00007b4681bd3e0b  push rdi
00007b4681bd3e0c  push rsi
00007b4681bd3e0d  push r8
00007b4681bd3e0f  push r9
00007b4681bd3e11  push r10
00007b4681bd3e13  push r11
00007b4681bd3e15  sub rsp, 0xF0
00007b4681bd3e1c  vmovaps [rsp], xmm0
00007b4681bd3e21  vmovaps [rsp+0x10], xmm1
00007b4681bd3e27  vmovaps [rsp+0x20], xmm2
00007b4681bd3e2d  vmovaps [rsp+0x30], xmm3
00007b4681bd3e33  vmovaps [rsp+0x40], xmm4
00007b4681bd3e39  vmovaps [rsp+0x50], xmm5
00007b4681bd3e3f  vmovaps [rsp+0x60], xmm6
00007b4681bd3e45  vmovaps [rsp+0x70], xmm7
00007b4681bd3e4b  vmovaps [rsp+0x80], xmm8
00007b4681bd3e54  vmovaps [rsp+0x90], xmm9
00007b4681bd3e5d  vmovaps [rsp+0xA0], xmm10
00007b4681bd3e66  vmovaps [rsp+0xB0], xmm11
00007b4681bd3e6f  vmovaps [rsp+0xC0], xmm13
00007b4681bd3e78  vmovaps [rsp+0xD0], xmm14
00007b4681bd3e81  vmovaps [rsp+0xE0], xmm15
00007b4681bd3e8a  sub rsp, 0x40
00007b4681bd3e8e  lea rdi, [rsp]
00007b4681bd3e92  lea rsi, [rsp+0x10]
00007b4681bd3e97  lea rdx, [rsp+0x20]
00007b4681bd3e9c  lea rcx, [rsp+0x30]
00007b4681bd3ea1  mov r8d, 0x00
00007b4681bd3ea7  lea r9, [r15+0x3A8]
00007b4681bd3eae  movaps [rdi], xmm12
00007b4681bd3eb2  movaps [rsi], xmm15
00007b4681bd3eb6  movaps [rdx], xmm14
00007b4681bd3eba  movaps [rcx], xmm1
00007b4681bd3ebd  mov rax, 0x5668589B5A50
00007b4681bd3ec7  call rax
00007b4681bd3ec9  movaps xmm12, [rsp]
00007b4681bd3ece  add rsp, 0x40
00007b4681bd3ed2  vmovaps xmm0, [rsp]
00007b4681bd3ed7  vmovaps xmm1, [rsp+0x10]
00007b4681bd3edd  vmovaps xmm2, [rsp+0x20]
00007b4681bd3ee3  vmovaps xmm3, [rsp+0x30]
00007b4681bd3ee9  vmovaps xmm4, [rsp+0x40]
00007b4681bd3eef  vmovaps xmm5, [rsp+0x50]
00007b4681bd3ef5  vmovaps xmm6, [rsp+0x60]
00007b4681bd3efb  vmovaps xmm7, [rsp+0x70]
00007b4681bd3f01  vmovaps xmm8, [rsp+0x80]
00007b4681bd3f0a  vmovaps xmm9, [rsp+0x90]
00007b4681bd3f13  vmovaps xmm10, [rsp+0xA0]
00007b4681bd3f1c  vmovaps xmm11, [rsp+0xB0]
00007b4681bd3f25  vmovaps xmm13, [rsp+0xC0]
00007b4681bd3f2e  vmovaps xmm14, [rsp+0xD0]
00007b4681bd3f37  vmovaps xmm15, [rsp+0xE0]
00007b4681bd3f40  add rsp, 0xF0
00007b4681bd3f47  pop r11
00007b4681bd3f49  pop r10
00007b4681bd3f4b  pop r9
00007b4681bd3f4d  pop r8
00007b4681bd3f4f  pop rsi
00007b4681bd3f50  pop rdi
00007b4681bd3f51  pop rdx
00007b4681bd3f52  pop rcx
00007b4681bd3f53  pop rax
00007b4681bd3f54  add rsp, 0x08
00007b4681bd3f58  jmp 0x00007B4681BD2C3D
00007b4681bd3f5d  sub rsp, 0x08
00007b4681bd3f61  push rax
00007b4681bd3f62  push rcx
00007b4681bd3f63  push rdx
00007b4681bd3f64  push rdi
00007b4681bd3f65  push rsi
00007b4681bd3f66  push r8
00007b4681bd3f68  push r9
00007b4681bd3f6a  push r10
00007b4681bd3f6c  push r11
00007b4681bd3f6e  sub rsp, 0xF0
00007b4681bd3f75  vmovaps [rsp], xmm0
00007b4681bd3f7a  vmovaps [rsp+0x10], xmm1
00007b4681bd3f80  vmovaps [rsp+0x20], xmm2
00007b4681bd3f86  vmovaps [rsp+0x30], xmm3
00007b4681bd3f8c  vmovaps [rsp+0x40], xmm4
00007b4681bd3f92  vmovaps [rsp+0x50], xmm5
00007b4681bd3f98  vmovaps [rsp+0x60], xmm6
00007b4681bd3f9e  vmovaps [rsp+0x70], xmm7
00007b4681bd3fa4  vmovaps [rsp+0x80], xmm8
00007b4681bd3fad  vmovaps [rsp+0x90], xmm9
00007b4681bd3fb6  vmovaps [rsp+0xA0], xmm10
00007b4681bd3fbf  vmovaps [rsp+0xB0], xmm11
00007b4681bd3fc8  vmovaps [rsp+0xC0], xmm12
00007b4681bd3fd1  vmovaps [rsp+0xD0], xmm13
00007b4681bd3fda  vmovaps [rsp+0xE0], xmm15
00007b4681bd3fe3  sub rsp, 0x40
00007b4681bd3fe7  lea rdi, [rsp]
00007b4681bd3feb  lea rsi, [rsp+0x10]
00007b4681bd3ff0  lea rdx, [rsp+0x20]
00007b4681bd3ff5  lea rcx, [rsp+0x30]
00007b4681bd3ffa  mov r8d, 0x00
00007b4681bd4000  lea r9, [r15+0x3A8]
00007b4681bd4007  movaps [rdi], xmm14
00007b4681bd400b  movaps [rsi], xmm3
00007b4681bd400e  movaps [rdx], xmm1
00007b4681bd4011  movaps [rcx], xmm15
00007b4681bd4015  mov rax, 0x5668589B5A50
00007b4681bd401f  call rax
00007b4681bd4021  movaps xmm14, [rsp]
00007b4681bd4026  add rsp, 0x40
00007b4681bd402a  vmovaps xmm0, [rsp]
00007b4681bd402f  vmovaps xmm1, [rsp+0x10]
00007b4681bd4035  vmovaps xmm2, [rsp+0x20]
00007b4681bd403b  vmovaps xmm3, [rsp+0x30]
00007b4681bd4041  vmovaps xmm4, [rsp+0x40]
00007b4681bd4047  vmovaps xmm5, [rsp+0x50]
00007b4681bd404d  vmovaps xmm6, [rsp+0x60]
00007b4681bd4053  vmovaps xmm7, [rsp+0x70]
00007b4681bd4059  vmovaps xmm8, [rsp+0x80]
00007b4681bd4062  vmovaps xmm9, [rsp+0x90]
00007b4681bd406b  vmovaps xmm10, [rsp+0xA0]
00007b4681bd4074  vmovaps xmm11, [rsp+0xB0]
00007b4681bd407d  vmovaps xmm12, [rsp+0xC0]
00007b4681bd4086  vmovaps xmm13, [rsp+0xD0]
00007b4681bd408f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd4098  add rsp, 0xF0
00007b4681bd409f  pop r11
00007b4681bd40a1  pop r10
00007b4681bd40a3  pop r9
00007b4681bd40a5  pop r8
00007b4681bd40a7  pop rsi
00007b4681bd40a8  pop rdi
00007b4681bd40a9  pop rdx
00007b4681bd40aa  pop rcx
00007b4681bd40ab  pop rax
00007b4681bd40ac  add rsp, 0x08
00007b4681bd40b0  jmp 0x00007B4681BD2CF7
00007b4681bd40b5  sub rsp, 0x08
00007b4681bd40b9  push rax
00007b4681bd40ba  push rcx
00007b4681bd40bb  push rdx
00007b4681bd40bc  push rdi
00007b4681bd40bd  push rsi
00007b4681bd40be  push r8
00007b4681bd40c0  push r9
00007b4681bd40c2  push r10
00007b4681bd40c4  push r11
00007b4681bd40c6  sub rsp, 0xF0
00007b4681bd40cd  vmovaps [rsp], xmm0
00007b4681bd40d2  vmovaps [rsp+0x10], xmm1
00007b4681bd40d8  vmovaps [rsp+0x20], xmm2
00007b4681bd40de  vmovaps [rsp+0x30], xmm3
00007b4681bd40e4  vmovaps [rsp+0x40], xmm4
00007b4681bd40ea  vmovaps [rsp+0x50], xmm5
00007b4681bd40f0  vmovaps [rsp+0x60], xmm6
00007b4681bd40f6  vmovaps [rsp+0x70], xmm7
00007b4681bd40fc  vmovaps [rsp+0x80], xmm8
00007b4681bd4105  vmovaps [rsp+0x90], xmm9
00007b4681bd410e  vmovaps [rsp+0xA0], xmm10
00007b4681bd4117  vmovaps [rsp+0xB0], xmm11
00007b4681bd4120  vmovaps [rsp+0xC0], xmm12
00007b4681bd4129  vmovaps [rsp+0xD0], xmm14
00007b4681bd4132  vmovaps [rsp+0xE0], xmm15
00007b4681bd413b  sub rsp, 0x40
00007b4681bd413f  lea rdi, [rsp]
00007b4681bd4143  lea rsi, [rsp+0x10]
00007b4681bd4148  lea rdx, [rsp+0x20]
00007b4681bd414d  lea rcx, [rsp+0x30]
00007b4681bd4152  mov r8d, 0x00
00007b4681bd4158  lea r9, [r15+0x3A8]
00007b4681bd415f  movaps [rdi], xmm13
00007b4681bd4163  movaps [rsi], xmm15
00007b4681bd4167  movaps [rdx], xmm10
00007b4681bd416b  movaps [rcx], xmm1
00007b4681bd416e  mov rax, 0x5668589B5A50
00007b4681bd4178  call rax
00007b4681bd417a  movaps xmm13, [rsp]
00007b4681bd417f  add rsp, 0x40
00007b4681bd4183  vmovaps xmm0, [rsp]
00007b4681bd4188  vmovaps xmm1, [rsp+0x10]
00007b4681bd418e  vmovaps xmm2, [rsp+0x20]
00007b4681bd4194  vmovaps xmm3, [rsp+0x30]
00007b4681bd419a  vmovaps xmm4, [rsp+0x40]
00007b4681bd41a0  vmovaps xmm5, [rsp+0x50]
00007b4681bd41a6  vmovaps xmm6, [rsp+0x60]
00007b4681bd41ac  vmovaps xmm7, [rsp+0x70]
00007b4681bd41b2  vmovaps xmm8, [rsp+0x80]
00007b4681bd41bb  vmovaps xmm9, [rsp+0x90]
00007b4681bd41c4  vmovaps xmm10, [rsp+0xA0]
00007b4681bd41cd  vmovaps xmm11, [rsp+0xB0]
00007b4681bd41d6  vmovaps xmm12, [rsp+0xC0]
00007b4681bd41df  vmovaps xmm14, [rsp+0xD0]
00007b4681bd41e8  vmovaps xmm15, [rsp+0xE0]
00007b4681bd41f1  add rsp, 0xF0
00007b4681bd41f8  pop r11
00007b4681bd41fa  pop r10
00007b4681bd41fc  pop r9
00007b4681bd41fe  pop r8
00007b4681bd4200  pop rsi
00007b4681bd4201  pop rdi
00007b4681bd4202  pop rdx
00007b4681bd4203  pop rcx
00007b4681bd4204  pop rax
00007b4681bd4205  add rsp, 0x08
00007b4681bd4209  jmp 0x00007B4681BD2D26
00007b4681bd420e  sub rsp, 0x08
00007b4681bd4212  push rax
00007b4681bd4213  push rcx
00007b4681bd4214  push rdx
00007b4681bd4215  push rdi
00007b4681bd4216  push rsi
00007b4681bd4217  push r8
00007b4681bd4219  push r9
00007b4681bd421b  push r10
00007b4681bd421d  push r11
00007b4681bd421f  sub rsp, 0xF0
00007b4681bd4226  vmovaps [rsp], xmm0
00007b4681bd422b  vmovaps [rsp+0x10], xmm1
00007b4681bd4231  vmovaps [rsp+0x20], xmm2
00007b4681bd4237  vmovaps [rsp+0x30], xmm3
00007b4681bd423d  vmovaps [rsp+0x40], xmm4
00007b4681bd4243  vmovaps [rsp+0x50], xmm5
00007b4681bd4249  vmovaps [rsp+0x60], xmm6
00007b4681bd424f  vmovaps [rsp+0x70], xmm7
00007b4681bd4255  vmovaps [rsp+0x80], xmm8
00007b4681bd425e  vmovaps [rsp+0x90], xmm9
00007b4681bd4267  vmovaps [rsp+0xA0], xmm11
00007b4681bd4270  vmovaps [rsp+0xB0], xmm12
00007b4681bd4279  vmovaps [rsp+0xC0], xmm13
00007b4681bd4282  vmovaps [rsp+0xD0], xmm14
00007b4681bd428b  vmovaps [rsp+0xE0], xmm15
00007b4681bd4294  sub rsp, 0x40
00007b4681bd4298  lea rdi, [rsp]
00007b4681bd429c  lea rsi, [rsp+0x10]
00007b4681bd42a1  lea rdx, [rsp+0x20]
00007b4681bd42a6  lea rcx, [rsp+0x30]
00007b4681bd42ab  mov r8d, 0x00
00007b4681bd42b1  lea r9, [r15+0x3A8]
00007b4681bd42b8  movaps [rdi], xmm10
00007b4681bd42bc  movaps [rsi], xmm15
00007b4681bd42c0  movaps [rdx], xmm11
00007b4681bd42c4  movaps [rcx], xmm1
00007b4681bd42c7  mov rax, 0x5668589B5A50
00007b4681bd42d1  call rax
00007b4681bd42d3  movaps xmm10, [rsp]
00007b4681bd42d8  add rsp, 0x40
00007b4681bd42dc  vmovaps xmm0, [rsp]
00007b4681bd42e1  vmovaps xmm1, [rsp+0x10]
00007b4681bd42e7  vmovaps xmm2, [rsp+0x20]
00007b4681bd42ed  vmovaps xmm3, [rsp+0x30]
00007b4681bd42f3  vmovaps xmm4, [rsp+0x40]
00007b4681bd42f9  vmovaps xmm5, [rsp+0x50]
00007b4681bd42ff  vmovaps xmm6, [rsp+0x60]
00007b4681bd4305  vmovaps xmm7, [rsp+0x70]
00007b4681bd430b  vmovaps xmm8, [rsp+0x80]
00007b4681bd4314  vmovaps xmm9, [rsp+0x90]
00007b4681bd431d  vmovaps xmm11, [rsp+0xA0]
00007b4681bd4326  vmovaps xmm12, [rsp+0xB0]
00007b4681bd432f  vmovaps xmm13, [rsp+0xC0]
00007b4681bd4338  vmovaps xmm14, [rsp+0xD0]
00007b4681bd4341  vmovaps xmm15, [rsp+0xE0]
00007b4681bd434a  add rsp, 0xF0
00007b4681bd4351  pop r11
00007b4681bd4353  pop r10
00007b4681bd4355  pop r9
00007b4681bd4357  pop r8
00007b4681bd4359  pop rsi
00007b4681bd435a  pop rdi
00007b4681bd435b  pop rdx
00007b4681bd435c  pop rcx
00007b4681bd435d  pop rax
00007b4681bd435e  add rsp, 0x08
00007b4681bd4362  jmp 0x00007B4681BD2D55
00007b4681bd4367  sub rsp, 0x08
00007b4681bd436b  push rax
00007b4681bd436c  push rcx
00007b4681bd436d  push rdx
00007b4681bd436e  push rdi
00007b4681bd436f  push rsi
00007b4681bd4370  push r8
00007b4681bd4372  push r9
00007b4681bd4374  push r10
00007b4681bd4376  push r11
00007b4681bd4378  sub rsp, 0xF0
00007b4681bd437f  vmovaps [rsp], xmm0
00007b4681bd4384  vmovaps [rsp+0x10], xmm1
00007b4681bd438a  vmovaps [rsp+0x20], xmm2
00007b4681bd4390  vmovaps [rsp+0x30], xmm3
00007b4681bd4396  vmovaps [rsp+0x40], xmm4
00007b4681bd439c  vmovaps [rsp+0x50], xmm5
00007b4681bd43a2  vmovaps [rsp+0x60], xmm6
00007b4681bd43a8  vmovaps [rsp+0x70], xmm7
00007b4681bd43ae  vmovaps [rsp+0x80], xmm8
00007b4681bd43b7  vmovaps [rsp+0x90], xmm9
00007b4681bd43c0  vmovaps [rsp+0xA0], xmm10
00007b4681bd43c9  vmovaps [rsp+0xB0], xmm11
00007b4681bd43d2  vmovaps [rsp+0xC0], xmm12
00007b4681bd43db  vmovaps [rsp+0xD0], xmm13
00007b4681bd43e4  vmovaps [rsp+0xE0], xmm14
00007b4681bd43ed  sub rsp, 0x40
00007b4681bd43f1  lea rdi, [rsp]
00007b4681bd43f5  lea rsi, [rsp+0x10]
00007b4681bd43fa  lea rdx, [rsp+0x20]
00007b4681bd43ff  lea rcx, [rsp+0x30]
00007b4681bd4404  mov r8d, 0x00
00007b4681bd440a  lea r9, [r15+0x3A8]
00007b4681bd4411  movaps [rdi], xmm15
00007b4681bd4415  movaps [rsi], xmm12
00007b4681bd4419  movaps [rdx], xmm5
00007b4681bd441c  movaps [rcx], xmm1
00007b4681bd441f  mov rax, 0x5668589B5A50
00007b4681bd4429  call rax
00007b4681bd442b  movaps xmm15, [rsp]
00007b4681bd4430  add rsp, 0x40
00007b4681bd4434  vmovaps xmm0, [rsp]
00007b4681bd4439  vmovaps xmm1, [rsp+0x10]
00007b4681bd443f  vmovaps xmm2, [rsp+0x20]
00007b4681bd4445  vmovaps xmm3, [rsp+0x30]
00007b4681bd444b  vmovaps xmm4, [rsp+0x40]
00007b4681bd4451  vmovaps xmm5, [rsp+0x50]
00007b4681bd4457  vmovaps xmm6, [rsp+0x60]
00007b4681bd445d  vmovaps xmm7, [rsp+0x70]
00007b4681bd4463  vmovaps xmm8, [rsp+0x80]
00007b4681bd446c  vmovaps xmm9, [rsp+0x90]
00007b4681bd4475  vmovaps xmm10, [rsp+0xA0]
00007b4681bd447e  vmovaps xmm11, [rsp+0xB0]
00007b4681bd4487  vmovaps xmm12, [rsp+0xC0]
00007b4681bd4490  vmovaps xmm13, [rsp+0xD0]
00007b4681bd4499  vmovaps xmm14, [rsp+0xE0]
00007b4681bd44a2  add rsp, 0xF0
00007b4681bd44a9  pop r11
00007b4681bd44ab  pop r10
00007b4681bd44ad  pop r9
00007b4681bd44af  pop r8
00007b4681bd44b1  pop rsi
00007b4681bd44b2  pop rdi
00007b4681bd44b3  pop rdx
00007b4681bd44b4  pop rcx
00007b4681bd44b5  pop rax
00007b4681bd44b6  add rsp, 0x08
00007b4681bd44ba  jmp 0x00007B4681BD2D7E
00007b4681bd44bf  sub rsp, 0x08
00007b4681bd44c3  push rax
00007b4681bd44c4  push rcx
00007b4681bd44c5  push rdx
00007b4681bd44c6  push rdi
00007b4681bd44c7  push rsi
00007b4681bd44c8  push r8
00007b4681bd44ca  push r9
00007b4681bd44cc  push r10
00007b4681bd44ce  push r11
00007b4681bd44d0  sub rsp, 0xF0
00007b4681bd44d7  vmovaps [rsp], xmm0
00007b4681bd44dc  vmovaps [rsp+0x10], xmm1
00007b4681bd44e2  vmovaps [rsp+0x20], xmm2
00007b4681bd44e8  vmovaps [rsp+0x30], xmm3
00007b4681bd44ee  vmovaps [rsp+0x40], xmm4
00007b4681bd44f4  vmovaps [rsp+0x50], xmm6
00007b4681bd44fa  vmovaps [rsp+0x60], xmm7
00007b4681bd4500  vmovaps [rsp+0x70], xmm8
00007b4681bd4506  vmovaps [rsp+0x80], xmm9
00007b4681bd450f  vmovaps [rsp+0x90], xmm10
00007b4681bd4518  vmovaps [rsp+0xA0], xmm11
00007b4681bd4521  vmovaps [rsp+0xB0], xmm12
00007b4681bd452a  vmovaps [rsp+0xC0], xmm13
00007b4681bd4533  vmovaps [rsp+0xD0], xmm14
00007b4681bd453c  vmovaps [rsp+0xE0], xmm15
00007b4681bd4545  sub rsp, 0x40
00007b4681bd4549  lea rdi, [rsp]
00007b4681bd454d  lea rsi, [rsp+0x10]
00007b4681bd4552  lea rdx, [rsp+0x20]
00007b4681bd4557  lea rcx, [rsp+0x30]
00007b4681bd455c  mov r8d, 0x00
00007b4681bd4562  lea r9, [r15+0x3A8]
00007b4681bd4569  movaps [rdi], xmm5
00007b4681bd456c  movaps [rsi], xmm13
00007b4681bd4570  movaps [rdx], xmm11
00007b4681bd4574  movaps [rcx], xmm12
00007b4681bd4578  mov rax, 0x5668589B5A50
00007b4681bd4582  call rax
00007b4681bd4584  movaps xmm5, [rsp]
00007b4681bd4588  add rsp, 0x40
00007b4681bd458c  vmovaps xmm0, [rsp]
00007b4681bd4591  vmovaps xmm1, [rsp+0x10]
00007b4681bd4597  vmovaps xmm2, [rsp+0x20]
00007b4681bd459d  vmovaps xmm3, [rsp+0x30]
00007b4681bd45a3  vmovaps xmm4, [rsp+0x40]
00007b4681bd45a9  vmovaps xmm6, [rsp+0x50]
00007b4681bd45af  vmovaps xmm7, [rsp+0x60]
00007b4681bd45b5  vmovaps xmm8, [rsp+0x70]
00007b4681bd45bb  vmovaps xmm9, [rsp+0x80]
00007b4681bd45c4  vmovaps xmm10, [rsp+0x90]
00007b4681bd45cd  vmovaps xmm11, [rsp+0xA0]
00007b4681bd45d6  vmovaps xmm12, [rsp+0xB0]
00007b4681bd45df  vmovaps xmm13, [rsp+0xC0]
00007b4681bd45e8  vmovaps xmm14, [rsp+0xD0]
00007b4681bd45f1  vmovaps xmm15, [rsp+0xE0]
00007b4681bd45fa  add rsp, 0xF0
00007b4681bd4601  pop r11
00007b4681bd4603  pop r10
00007b4681bd4605  pop r9
00007b4681bd4607  pop r8
00007b4681bd4609  pop rsi
00007b4681bd460a  pop rdi
00007b4681bd460b  pop rdx
00007b4681bd460c  pop rcx
00007b4681bd460d  pop rax
00007b4681bd460e  add rsp, 0x08
00007b4681bd4612  jmp 0x00007B4681BD2DDD
00007b4681bd4617  sub rsp, 0x08
00007b4681bd461b  push rax
00007b4681bd461c  push rcx
00007b4681bd461d  push rdx
00007b4681bd461e  push rdi
00007b4681bd461f  push rsi
00007b4681bd4620  push r8
00007b4681bd4622  push r9
00007b4681bd4624  push r10
00007b4681bd4626  push r11
00007b4681bd4628  sub rsp, 0xF0
00007b4681bd462f  vmovaps [rsp], xmm0
00007b4681bd4634  vmovaps [rsp+0x10], xmm1
00007b4681bd463a  vmovaps [rsp+0x20], xmm2
00007b4681bd4640  vmovaps [rsp+0x30], xmm3
00007b4681bd4646  vmovaps [rsp+0x40], xmm4
00007b4681bd464c  vmovaps [rsp+0x50], xmm5
00007b4681bd4652  vmovaps [rsp+0x60], xmm6
00007b4681bd4658  vmovaps [rsp+0x70], xmm7
00007b4681bd465e  vmovaps [rsp+0x80], xmm8
00007b4681bd4667  vmovaps [rsp+0x90], xmm9
00007b4681bd4670  vmovaps [rsp+0xA0], xmm10
00007b4681bd4679  vmovaps [rsp+0xB0], xmm11
00007b4681bd4682  vmovaps [rsp+0xC0], xmm13
00007b4681bd468b  vmovaps [rsp+0xD0], xmm14
00007b4681bd4694  vmovaps [rsp+0xE0], xmm15
00007b4681bd469d  sub rsp, 0x40
00007b4681bd46a1  lea rdi, [rsp]
00007b4681bd46a5  lea rsi, [rsp+0x10]
00007b4681bd46aa  lea rdx, [rsp+0x20]
00007b4681bd46af  lea rcx, [rsp+0x30]
00007b4681bd46b4  mov r8d, 0x00
00007b4681bd46ba  lea r9, [r15+0x3A8]
00007b4681bd46c1  movaps [rdi], xmm12
00007b4681bd46c5  movaps [rsi], xmm14
00007b4681bd46c9  movaps [rdx], xmm9
00007b4681bd46cd  movaps [rcx], xmm13
00007b4681bd46d1  mov rax, 0x5668589B5A50
00007b4681bd46db  call rax
00007b4681bd46dd  movaps xmm12, [rsp]
00007b4681bd46e2  add rsp, 0x40
00007b4681bd46e6  vmovaps xmm0, [rsp]
00007b4681bd46eb  vmovaps xmm1, [rsp+0x10]
00007b4681bd46f1  vmovaps xmm2, [rsp+0x20]
00007b4681bd46f7  vmovaps xmm3, [rsp+0x30]
00007b4681bd46fd  vmovaps xmm4, [rsp+0x40]
00007b4681bd4703  vmovaps xmm5, [rsp+0x50]
00007b4681bd4709  vmovaps xmm6, [rsp+0x60]
00007b4681bd470f  vmovaps xmm7, [rsp+0x70]
00007b4681bd4715  vmovaps xmm8, [rsp+0x80]
00007b4681bd471e  vmovaps xmm9, [rsp+0x90]
00007b4681bd4727  vmovaps xmm10, [rsp+0xA0]
00007b4681bd4730  vmovaps xmm11, [rsp+0xB0]
00007b4681bd4739  vmovaps xmm13, [rsp+0xC0]
00007b4681bd4742  vmovaps xmm14, [rsp+0xD0]
00007b4681bd474b  vmovaps xmm15, [rsp+0xE0]
00007b4681bd4754  add rsp, 0xF0
00007b4681bd475b  pop r11
00007b4681bd475d  pop r10
00007b4681bd475f  pop r9
00007b4681bd4761  pop r8
00007b4681bd4763  pop rsi
00007b4681bd4764  pop rdi
00007b4681bd4765  pop rdx
00007b4681bd4766  pop rcx
00007b4681bd4767  pop rax
00007b4681bd4768  add rsp, 0x08
00007b4681bd476c  jmp 0x00007B4681BD2E06
00007b4681bd4771  call 0x00007B4681A0D4E0
00007b4681bd4776  jmp 0x00007B4681BD2E13
00007b4681bd477b  sub rsp, 0x08
00007b4681bd477f  push rax
00007b4681bd4780  push rcx
00007b4681bd4781  push rdx
00007b4681bd4782  push rdi
00007b4681bd4783  push rsi
00007b4681bd4784  push r8
00007b4681bd4786  push r9
00007b4681bd4788  push r10
00007b4681bd478a  push r11
00007b4681bd478c  sub rsp, 0xF0
00007b4681bd4793  vmovaps [rsp], xmm0
00007b4681bd4798  vmovaps [rsp+0x10], xmm1
00007b4681bd479e  vmovaps [rsp+0x20], xmm2
00007b4681bd47a4  vmovaps [rsp+0x30], xmm3
00007b4681bd47aa  vmovaps [rsp+0x40], xmm4
00007b4681bd47b0  vmovaps [rsp+0x50], xmm5
00007b4681bd47b6  vmovaps [rsp+0x60], xmm6
00007b4681bd47bc  vmovaps [rsp+0x70], xmm7
00007b4681bd47c2  vmovaps [rsp+0x80], xmm8
00007b4681bd47cb  vmovaps [rsp+0x90], xmm9
00007b4681bd47d4  vmovaps [rsp+0xA0], xmm10
00007b4681bd47dd  vmovaps [rsp+0xB0], xmm12
00007b4681bd47e6  vmovaps [rsp+0xC0], xmm13
00007b4681bd47ef  vmovaps [rsp+0xD0], xmm14
00007b4681bd47f8  vmovaps [rsp+0xE0], xmm15
00007b4681bd4801  sub rsp, 0x40
00007b4681bd4805  lea rdi, [rsp]
00007b4681bd4809  lea rsi, [rsp+0x10]
00007b4681bd480e  lea rdx, [rsp+0x20]
00007b4681bd4813  lea rcx, [rsp+0x30]
00007b4681bd4818  mov r8d, 0x00
00007b4681bd481e  lea r9, [r15+0x3A8]
00007b4681bd4825  movaps [rdi], xmm11
00007b4681bd4829  movaps [rsi], xmm10
00007b4681bd482d  movaps [rdx], xmm8
00007b4681bd4831  movaps [rcx], xmm13
00007b4681bd4835  mov rax, 0x5668589B5A50
00007b4681bd483f  call rax
00007b4681bd4841  movaps xmm11, [rsp]
00007b4681bd4846  add rsp, 0x40
00007b4681bd484a  vmovaps xmm0, [rsp]
00007b4681bd484f  vmovaps xmm1, [rsp+0x10]
00007b4681bd4855  vmovaps xmm2, [rsp+0x20]
00007b4681bd485b  vmovaps xmm3, [rsp+0x30]
00007b4681bd4861  vmovaps xmm4, [rsp+0x40]
00007b4681bd4867  vmovaps xmm5, [rsp+0x50]
00007b4681bd486d  vmovaps xmm6, [rsp+0x60]
00007b4681bd4873  vmovaps xmm7, [rsp+0x70]
00007b4681bd4879  vmovaps xmm8, [rsp+0x80]
00007b4681bd4882  vmovaps xmm9, [rsp+0x90]
00007b4681bd488b  vmovaps xmm10, [rsp+0xA0]
00007b4681bd4894  vmovaps xmm12, [rsp+0xB0]
00007b4681bd489d  vmovaps xmm13, [rsp+0xC0]
00007b4681bd48a6  vmovaps xmm14, [rsp+0xD0]
00007b4681bd48af  vmovaps xmm15, [rsp+0xE0]
00007b4681bd48b8  add rsp, 0xF0
00007b4681bd48bf  pop r11
00007b4681bd48c1  pop r10
00007b4681bd48c3  pop r9
00007b4681bd48c5  pop r8
00007b4681bd48c7  pop rsi
00007b4681bd48c8  pop rdi
00007b4681bd48c9  pop rdx
00007b4681bd48ca  pop rcx
00007b4681bd48cb  pop rax
00007b4681bd48cc  add rsp, 0x08
00007b4681bd48d0  jmp 0x00007B4681BD2E44
00007b4681bd48d5  sub rsp, 0x08
00007b4681bd48d9  push rax
00007b4681bd48da  push rcx
00007b4681bd48db  push rdx
00007b4681bd48dc  push rdi
00007b4681bd48dd  push rsi
00007b4681bd48de  push r8
00007b4681bd48e0  push r9
00007b4681bd48e2  push r10
00007b4681bd48e4  push r11
00007b4681bd48e6  sub rsp, 0xF0
00007b4681bd48ed  vmovaps [rsp], xmm0
00007b4681bd48f2  vmovaps [rsp+0x10], xmm1
00007b4681bd48f8  vmovaps [rsp+0x20], xmm2
00007b4681bd48fe  vmovaps [rsp+0x30], xmm3
00007b4681bd4904  vmovaps [rsp+0x40], xmm4
00007b4681bd490a  vmovaps [rsp+0x50], xmm5
00007b4681bd4910  vmovaps [rsp+0x60], xmm6
00007b4681bd4916  vmovaps [rsp+0x70], xmm7
00007b4681bd491c  vmovaps [rsp+0x80], xmm8
00007b4681bd4925  vmovaps [rsp+0x90], xmm9
00007b4681bd492e  vmovaps [rsp+0xA0], xmm11
00007b4681bd4937  vmovaps [rsp+0xB0], xmm12
00007b4681bd4940  vmovaps [rsp+0xC0], xmm13
00007b4681bd4949  vmovaps [rsp+0xD0], xmm14
00007b4681bd4952  vmovaps [rsp+0xE0], xmm15
00007b4681bd495b  sub rsp, 0x40
00007b4681bd495f  lea rdi, [rsp]
00007b4681bd4963  lea rsi, [rsp+0x10]
00007b4681bd4968  lea rdx, [rsp+0x20]
00007b4681bd496d  lea rcx, [rsp+0x30]
00007b4681bd4972  mov r8d, 0x00
00007b4681bd4978  lea r9, [r15+0x3A8]
00007b4681bd497f  movaps [rdi], xmm10
00007b4681bd4983  movaps [rsi], xmm15
00007b4681bd4987  movaps [rdx], xmm1
00007b4681bd498a  movaps [rcx], xmm13
00007b4681bd498e  mov rax, 0x5668589B5A50
00007b4681bd4998  call rax
00007b4681bd499a  movaps xmm10, [rsp]
00007b4681bd499f  add rsp, 0x40
00007b4681bd49a3  vmovaps xmm0, [rsp]
00007b4681bd49a8  vmovaps xmm1, [rsp+0x10]
00007b4681bd49ae  vmovaps xmm2, [rsp+0x20]
00007b4681bd49b4  vmovaps xmm3, [rsp+0x30]
00007b4681bd49ba  vmovaps xmm4, [rsp+0x40]
00007b4681bd49c0  vmovaps xmm5, [rsp+0x50]
00007b4681bd49c6  vmovaps xmm6, [rsp+0x60]
00007b4681bd49cc  vmovaps xmm7, [rsp+0x70]
00007b4681bd49d2  vmovaps xmm8, [rsp+0x80]
00007b4681bd49db  vmovaps xmm9, [rsp+0x90]
00007b4681bd49e4  vmovaps xmm11, [rsp+0xA0]
00007b4681bd49ed  vmovaps xmm12, [rsp+0xB0]
00007b4681bd49f6  vmovaps xmm13, [rsp+0xC0]
00007b4681bd49ff  vmovaps xmm14, [rsp+0xD0]
00007b4681bd4a08  vmovaps xmm15, [rsp+0xE0]
00007b4681bd4a11  add rsp, 0xF0
00007b4681bd4a18  pop r11
00007b4681bd4a1a  pop r10
00007b4681bd4a1c  pop r9
00007b4681bd4a1e  pop r8
00007b4681bd4a20  pop rsi
00007b4681bd4a21  pop rdi
00007b4681bd4a22  pop rdx
00007b4681bd4a23  pop rcx
00007b4681bd4a24  pop rax
00007b4681bd4a25  add rsp, 0x08
00007b4681bd4a29  jmp 0x00007B4681BD2E6D
00007b4681bd4a2e  call 0x00007B46819FF430
00007b4681bd4a33  jmp 0x00007B4681BD2E8F
00007b4681bd4a38  call 0x00007B4681A0E760
00007b4681bd4a3d  jmp 0x00007B4681BD2E99
00007b4681bd4a42  sub rsp, 0x08
00007b4681bd4a46  push rax
00007b4681bd4a47  push rcx
00007b4681bd4a48  push rdx
00007b4681bd4a49  push rdi
00007b4681bd4a4a  push rsi
00007b4681bd4a4b  push r8
00007b4681bd4a4d  push r9
00007b4681bd4a4f  push r10
00007b4681bd4a51  push r11
00007b4681bd4a53  sub rsp, 0xF0
00007b4681bd4a5a  vmovaps [rsp], xmm0
00007b4681bd4a5f  vmovaps [rsp+0x10], xmm1
00007b4681bd4a65  vmovaps [rsp+0x20], xmm2
00007b4681bd4a6b  vmovaps [rsp+0x30], xmm3
00007b4681bd4a71  vmovaps [rsp+0x40], xmm4
00007b4681bd4a77  vmovaps [rsp+0x50], xmm5
00007b4681bd4a7d  vmovaps [rsp+0x60], xmm6
00007b4681bd4a83  vmovaps [rsp+0x70], xmm7
00007b4681bd4a89  vmovaps [rsp+0x80], xmm9
00007b4681bd4a92  vmovaps [rsp+0x90], xmm10
00007b4681bd4a9b  vmovaps [rsp+0xA0], xmm11
00007b4681bd4aa4  vmovaps [rsp+0xB0], xmm12
00007b4681bd4aad  vmovaps [rsp+0xC0], xmm13
00007b4681bd4ab6  vmovaps [rsp+0xD0], xmm14
00007b4681bd4abf  vmovaps [rsp+0xE0], xmm15
00007b4681bd4ac8  sub rsp, 0x40
00007b4681bd4acc  lea rdi, [rsp]
00007b4681bd4ad0  lea rsi, [rsp+0x10]
00007b4681bd4ad5  lea rdx, [rsp+0x20]
00007b4681bd4ada  lea rcx, [rsp+0x30]
00007b4681bd4adf  mov r8d, 0x00
00007b4681bd4ae5  lea r9, [r15+0x3A8]
00007b4681bd4aec  movaps [rdi], xmm8
00007b4681bd4af0  movaps [rsi], xmm5
00007b4681bd4af3  movaps [rdx], xmm9
00007b4681bd4af7  movaps [rcx], xmm13
00007b4681bd4afb  mov rax, 0x5668589B5A50
00007b4681bd4b05  call rax
00007b4681bd4b07  movaps xmm8, [rsp]
00007b4681bd4b0c  add rsp, 0x40
00007b4681bd4b10  vmovaps xmm0, [rsp]
00007b4681bd4b15  vmovaps xmm1, [rsp+0x10]
00007b4681bd4b1b  vmovaps xmm2, [rsp+0x20]
00007b4681bd4b21  vmovaps xmm3, [rsp+0x30]
00007b4681bd4b27  vmovaps xmm4, [rsp+0x40]
00007b4681bd4b2d  vmovaps xmm5, [rsp+0x50]
00007b4681bd4b33  vmovaps xmm6, [rsp+0x60]
00007b4681bd4b39  vmovaps xmm7, [rsp+0x70]
00007b4681bd4b3f  vmovaps xmm9, [rsp+0x80]
00007b4681bd4b48  vmovaps xmm10, [rsp+0x90]
00007b4681bd4b51  vmovaps xmm11, [rsp+0xA0]
00007b4681bd4b5a  vmovaps xmm12, [rsp+0xB0]
00007b4681bd4b63  vmovaps xmm13, [rsp+0xC0]
00007b4681bd4b6c  vmovaps xmm14, [rsp+0xD0]
00007b4681bd4b75  vmovaps xmm15, [rsp+0xE0]
00007b4681bd4b7e  add rsp, 0xF0
00007b4681bd4b85  pop r11
00007b4681bd4b87  pop r10
00007b4681bd4b89  pop r9
00007b4681bd4b8b  pop r8
00007b4681bd4b8d  pop rsi
00007b4681bd4b8e  pop rdi
00007b4681bd4b8f  pop rdx
00007b4681bd4b90  pop rcx
00007b4681bd4b91  pop rax
00007b4681bd4b92  add rsp, 0x08
00007b4681bd4b96  jmp 0x00007B4681BD2ED8
00007b4681bd4b9b  sub rsp, 0x08
00007b4681bd4b9f  push rax
00007b4681bd4ba0  push rcx
00007b4681bd4ba1  push rdx
00007b4681bd4ba2  push rdi
00007b4681bd4ba3  push rsi
00007b4681bd4ba4  push r8
00007b4681bd4ba6  push r9
00007b4681bd4ba8  push r10
00007b4681bd4baa  push r11
00007b4681bd4bac  sub rsp, 0xF0
00007b4681bd4bb3  vmovaps [rsp], xmm0
00007b4681bd4bb8  vmovaps [rsp+0x10], xmm1
00007b4681bd4bbe  vmovaps [rsp+0x20], xmm2
00007b4681bd4bc4  vmovaps [rsp+0x30], xmm3
00007b4681bd4bca  vmovaps [rsp+0x40], xmm4
00007b4681bd4bd0  vmovaps [rsp+0x50], xmm5
00007b4681bd4bd6  vmovaps [rsp+0x60], xmm6
00007b4681bd4bdc  vmovaps [rsp+0x70], xmm7
00007b4681bd4be2  vmovaps [rsp+0x80], xmm8
00007b4681bd4beb  vmovaps [rsp+0x90], xmm10
00007b4681bd4bf4  vmovaps [rsp+0xA0], xmm11
00007b4681bd4bfd  vmovaps [rsp+0xB0], xmm12
00007b4681bd4c06  vmovaps [rsp+0xC0], xmm13
00007b4681bd4c0f  vmovaps [rsp+0xD0], xmm14
00007b4681bd4c18  vmovaps [rsp+0xE0], xmm15
00007b4681bd4c21  sub rsp, 0x40
00007b4681bd4c25  lea rdi, [rsp]
00007b4681bd4c29  lea rsi, [rsp+0x10]
00007b4681bd4c2e  lea rdx, [rsp+0x20]
00007b4681bd4c33  lea rcx, [rsp+0x30]
00007b4681bd4c38  mov r8d, 0x00
00007b4681bd4c3e  lea r9, [r15+0x3A8]
00007b4681bd4c45  movaps [rdi], xmm9
00007b4681bd4c49  movaps [rsi], xmm12
00007b4681bd4c4d  movaps [rdx], xmm7
00007b4681bd4c50  movaps [rcx], xmm13
00007b4681bd4c54  mov rax, 0x5668589B5A50
00007b4681bd4c5e  call rax
00007b4681bd4c60  movaps xmm9, [rsp]
00007b4681bd4c65  add rsp, 0x40
00007b4681bd4c69  vmovaps xmm0, [rsp]
00007b4681bd4c6e  vmovaps xmm1, [rsp+0x10]
00007b4681bd4c74  vmovaps xmm2, [rsp+0x20]
00007b4681bd4c7a  vmovaps xmm3, [rsp+0x30]
00007b4681bd4c80  vmovaps xmm4, [rsp+0x40]
00007b4681bd4c86  vmovaps xmm5, [rsp+0x50]
00007b4681bd4c8c  vmovaps xmm6, [rsp+0x60]
00007b4681bd4c92  vmovaps xmm7, [rsp+0x70]
00007b4681bd4c98  vmovaps xmm8, [rsp+0x80]
00007b4681bd4ca1  vmovaps xmm10, [rsp+0x90]
00007b4681bd4caa  vmovaps xmm11, [rsp+0xA0]
00007b4681bd4cb3  vmovaps xmm12, [rsp+0xB0]
00007b4681bd4cbc  vmovaps xmm13, [rsp+0xC0]
00007b4681bd4cc5  vmovaps xmm14, [rsp+0xD0]
00007b4681bd4cce  vmovaps xmm15, [rsp+0xE0]
00007b4681bd4cd7  add rsp, 0xF0
00007b4681bd4cde  pop r11
00007b4681bd4ce0  pop r10
00007b4681bd4ce2  pop r9
00007b4681bd4ce4  pop r8
00007b4681bd4ce6  pop rsi
00007b4681bd4ce7  pop rdi
00007b4681bd4ce8  pop rdx
00007b4681bd4ce9  pop rcx
00007b4681bd4cea  pop rax
00007b4681bd4ceb  add rsp, 0x08
00007b4681bd4cef  jmp 0x00007B4681BD2F01
00007b4681bd4cf4  sub rsp, 0x08
00007b4681bd4cf8  push rax
00007b4681bd4cf9  push rcx
00007b4681bd4cfa  push rdx
00007b4681bd4cfb  push rdi
00007b4681bd4cfc  push rsi
00007b4681bd4cfd  push r8
00007b4681bd4cff  push r9
00007b4681bd4d01  push r10
00007b4681bd4d03  push r11
00007b4681bd4d05  sub rsp, 0xF0
00007b4681bd4d0c  vmovaps [rsp], xmm0
00007b4681bd4d11  vmovaps [rsp+0x10], xmm1
00007b4681bd4d17  vmovaps [rsp+0x20], xmm2
00007b4681bd4d1d  vmovaps [rsp+0x30], xmm3
00007b4681bd4d23  vmovaps [rsp+0x40], xmm4
00007b4681bd4d29  vmovaps [rsp+0x50], xmm5
00007b4681bd4d2f  vmovaps [rsp+0x60], xmm6
00007b4681bd4d35  vmovaps [rsp+0x70], xmm7
00007b4681bd4d3b  vmovaps [rsp+0x80], xmm8
00007b4681bd4d44  vmovaps [rsp+0x90], xmm9
00007b4681bd4d4d  vmovaps [rsp+0xA0], xmm10
00007b4681bd4d56  vmovaps [rsp+0xB0], xmm11
00007b4681bd4d5f  vmovaps [rsp+0xC0], xmm13
00007b4681bd4d68  vmovaps [rsp+0xD0], xmm14
00007b4681bd4d71  vmovaps [rsp+0xE0], xmm15
00007b4681bd4d7a  sub rsp, 0x40
00007b4681bd4d7e  lea rdi, [rsp]
00007b4681bd4d82  lea rsi, [rsp+0x10]
00007b4681bd4d87  lea rdx, [rsp+0x20]
00007b4681bd4d8c  lea rcx, [rsp+0x30]
00007b4681bd4d91  mov r8d, 0x00
00007b4681bd4d97  lea r9, [r15+0x3A8]
00007b4681bd4d9e  movaps [rdi], xmm12
00007b4681bd4da2  movaps [rsi], xmm11
00007b4681bd4da6  movaps [rdx], xmm6
00007b4681bd4da9  movaps [rcx], xmm13
00007b4681bd4dad  mov rax, 0x5668589B5A50
00007b4681bd4db7  call rax
00007b4681bd4db9  movaps xmm12, [rsp]
00007b4681bd4dbe  add rsp, 0x40
00007b4681bd4dc2  vmovaps xmm0, [rsp]
00007b4681bd4dc7  vmovaps xmm1, [rsp+0x10]
00007b4681bd4dcd  vmovaps xmm2, [rsp+0x20]
00007b4681bd4dd3  vmovaps xmm3, [rsp+0x30]
00007b4681bd4dd9  vmovaps xmm4, [rsp+0x40]
00007b4681bd4ddf  vmovaps xmm5, [rsp+0x50]
00007b4681bd4de5  vmovaps xmm6, [rsp+0x60]
00007b4681bd4deb  vmovaps xmm7, [rsp+0x70]
00007b4681bd4df1  vmovaps xmm8, [rsp+0x80]
00007b4681bd4dfa  vmovaps xmm9, [rsp+0x90]
00007b4681bd4e03  vmovaps xmm10, [rsp+0xA0]
00007b4681bd4e0c  vmovaps xmm11, [rsp+0xB0]
00007b4681bd4e15  vmovaps xmm13, [rsp+0xC0]
00007b4681bd4e1e  vmovaps xmm14, [rsp+0xD0]
00007b4681bd4e27  vmovaps xmm15, [rsp+0xE0]
00007b4681bd4e30  add rsp, 0xF0
00007b4681bd4e37  pop r11
00007b4681bd4e39  pop r10
00007b4681bd4e3b  pop r9
00007b4681bd4e3d  pop r8
00007b4681bd4e3f  pop rsi
00007b4681bd4e40  pop rdi
00007b4681bd4e41  pop rdx
00007b4681bd4e42  pop rcx
00007b4681bd4e43  pop rax
00007b4681bd4e44  add rsp, 0x08
00007b4681bd4e48  jmp 0x00007B4681BD2F2A
00007b4681bd4e4d  sub rsp, 0x08
00007b4681bd4e51  push rax
00007b4681bd4e52  push rcx
00007b4681bd4e53  push rdx
00007b4681bd4e54  push rdi
00007b4681bd4e55  push rsi
00007b4681bd4e56  push r8
00007b4681bd4e58  push r9
00007b4681bd4e5a  push r10
00007b4681bd4e5c  push r11
00007b4681bd4e5e  sub rsp, 0xF0
00007b4681bd4e65  vmovaps [rsp], xmm0
00007b4681bd4e6a  vmovaps [rsp+0x10], xmm1
00007b4681bd4e70  vmovaps [rsp+0x20], xmm2
00007b4681bd4e76  vmovaps [rsp+0x30], xmm3
00007b4681bd4e7c  vmovaps [rsp+0x40], xmm4
00007b4681bd4e82  vmovaps [rsp+0x50], xmm5
00007b4681bd4e88  vmovaps [rsp+0x60], xmm6
00007b4681bd4e8e  vmovaps [rsp+0x70], xmm8
00007b4681bd4e94  vmovaps [rsp+0x80], xmm9
00007b4681bd4e9d  vmovaps [rsp+0x90], xmm10
00007b4681bd4ea6  vmovaps [rsp+0xA0], xmm11
00007b4681bd4eaf  vmovaps [rsp+0xB0], xmm12
00007b4681bd4eb8  vmovaps [rsp+0xC0], xmm13
00007b4681bd4ec1  vmovaps [rsp+0xD0], xmm14
00007b4681bd4eca  vmovaps [rsp+0xE0], xmm15
00007b4681bd4ed3  sub rsp, 0x40
00007b4681bd4ed7  lea rdi, [rsp]
00007b4681bd4edb  lea rsi, [rsp+0x10]
00007b4681bd4ee0  lea rdx, [rsp+0x20]
00007b4681bd4ee5  lea rcx, [rsp+0x30]
00007b4681bd4eea  mov r8d, 0x00
00007b4681bd4ef0  lea r9, [r15+0x3A8]
00007b4681bd4ef7  movaps [rdi], xmm7
00007b4681bd4efa  movaps [rsi], xmm10
00007b4681bd4efe  movaps [rdx], xmm11
00007b4681bd4f02  movaps [rcx], xmm13
00007b4681bd4f06  mov rax, 0x5668589B5A50
00007b4681bd4f10  call rax
00007b4681bd4f12  movaps xmm7, [rsp]
00007b4681bd4f16  add rsp, 0x40
00007b4681bd4f1a  vmovaps xmm0, [rsp]
00007b4681bd4f1f  vmovaps xmm1, [rsp+0x10]
00007b4681bd4f25  vmovaps xmm2, [rsp+0x20]
00007b4681bd4f2b  vmovaps xmm3, [rsp+0x30]
00007b4681bd4f31  vmovaps xmm4, [rsp+0x40]
00007b4681bd4f37  vmovaps xmm5, [rsp+0x50]
00007b4681bd4f3d  vmovaps xmm6, [rsp+0x60]
00007b4681bd4f43  vmovaps xmm8, [rsp+0x70]
00007b4681bd4f49  vmovaps xmm9, [rsp+0x80]
00007b4681bd4f52  vmovaps xmm10, [rsp+0x90]
00007b4681bd4f5b  vmovaps xmm11, [rsp+0xA0]
00007b4681bd4f64  vmovaps xmm12, [rsp+0xB0]
00007b4681bd4f6d  vmovaps xmm13, [rsp+0xC0]
00007b4681bd4f76  vmovaps xmm14, [rsp+0xD0]
00007b4681bd4f7f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd4f88  add rsp, 0xF0
00007b4681bd4f8f  pop r11
00007b4681bd4f91  pop r10
00007b4681bd4f93  pop r9
00007b4681bd4f95  pop r8
00007b4681bd4f97  pop rsi
00007b4681bd4f98  pop rdi
00007b4681bd4f99  pop rdx
00007b4681bd4f9a  pop rcx
00007b4681bd4f9b  pop rax
00007b4681bd4f9c  add rsp, 0x08
00007b4681bd4fa0  jmp 0x00007B4681BD2F58
00007b4681bd4fa5  call 0x00007B4681A0C260
00007b4681bd4faa  jmp 0x00007B4681BD2F62
00007b4681bd4faf  call 0x00007B4681A09D70
00007b4681bd4fb4  jmp 0x00007B4681BD2F6C
00007b4681bd4fb9  sub rsp, 0x08
00007b4681bd4fbd  push rax
00007b4681bd4fbe  push rcx
00007b4681bd4fbf  push rdx
00007b4681bd4fc0  push rdi
00007b4681bd4fc1  push rsi
00007b4681bd4fc2  push r8
00007b4681bd4fc4  push r9
00007b4681bd4fc6  push r10
00007b4681bd4fc8  push r11
00007b4681bd4fca  sub rsp, 0xF0
00007b4681bd4fd1  vmovaps [rsp], xmm0
00007b4681bd4fd6  vmovaps [rsp+0x10], xmm1
00007b4681bd4fdc  vmovaps [rsp+0x20], xmm2
00007b4681bd4fe2  vmovaps [rsp+0x30], xmm3
00007b4681bd4fe8  vmovaps [rsp+0x40], xmm4
00007b4681bd4fee  vmovaps [rsp+0x50], xmm5
00007b4681bd4ff4  vmovaps [rsp+0x60], xmm7
00007b4681bd4ffa  vmovaps [rsp+0x70], xmm8
00007b4681bd5000  vmovaps [rsp+0x80], xmm9
00007b4681bd5009  vmovaps [rsp+0x90], xmm10
00007b4681bd5012  vmovaps [rsp+0xA0], xmm11
00007b4681bd501b  vmovaps [rsp+0xB0], xmm12
00007b4681bd5024  vmovaps [rsp+0xC0], xmm13
00007b4681bd502d  vmovaps [rsp+0xD0], xmm14
00007b4681bd5036  vmovaps [rsp+0xE0], xmm15
00007b4681bd503f  sub rsp, 0x40
00007b4681bd5043  lea rdi, [rsp]
00007b4681bd5047  lea rsi, [rsp+0x10]
00007b4681bd504c  lea rdx, [rsp+0x20]
00007b4681bd5051  lea rcx, [rsp+0x30]
00007b4681bd5056  mov r8d, 0x00
00007b4681bd505c  lea r9, [r15+0x3A8]
00007b4681bd5063  movaps [rdi], xmm6
00007b4681bd5066  movaps [rsi], xmm8
00007b4681bd506a  movaps [rdx], xmm15
00007b4681bd506e  movaps [rcx], xmm10
00007b4681bd5072  mov rax, 0x5668589B5A50
00007b4681bd507c  call rax
00007b4681bd507e  movaps xmm6, [rsp]
00007b4681bd5082  add rsp, 0x40
00007b4681bd5086  vmovaps xmm0, [rsp]
00007b4681bd508b  vmovaps xmm1, [rsp+0x10]
00007b4681bd5091  vmovaps xmm2, [rsp+0x20]
00007b4681bd5097  vmovaps xmm3, [rsp+0x30]
00007b4681bd509d  vmovaps xmm4, [rsp+0x40]
00007b4681bd50a3  vmovaps xmm5, [rsp+0x50]
00007b4681bd50a9  vmovaps xmm7, [rsp+0x60]
00007b4681bd50af  vmovaps xmm8, [rsp+0x70]
00007b4681bd50b5  vmovaps xmm9, [rsp+0x80]
00007b4681bd50be  vmovaps xmm10, [rsp+0x90]
00007b4681bd50c7  vmovaps xmm11, [rsp+0xA0]
00007b4681bd50d0  vmovaps xmm12, [rsp+0xB0]
00007b4681bd50d9  vmovaps xmm13, [rsp+0xC0]
00007b4681bd50e2  vmovaps xmm14, [rsp+0xD0]
00007b4681bd50eb  vmovaps xmm15, [rsp+0xE0]
00007b4681bd50f4  add rsp, 0xF0
00007b4681bd50fb  pop r11
00007b4681bd50fd  pop r10
00007b4681bd50ff  pop r9
00007b4681bd5101  pop r8
00007b4681bd5103  pop rsi
00007b4681bd5104  pop rdi
00007b4681bd5105  pop rdx
00007b4681bd5106  pop rcx
00007b4681bd5107  pop rax
00007b4681bd5108  add rsp, 0x08
00007b4681bd510c  jmp 0x00007B4681BD2FA4
00007b4681bd5111  sub rsp, 0x08
00007b4681bd5115  push rax
00007b4681bd5116  push rcx
00007b4681bd5117  push rdx
00007b4681bd5118  push rdi
00007b4681bd5119  push rsi
00007b4681bd511a  push r8
00007b4681bd511c  push r9
00007b4681bd511e  push r10
00007b4681bd5120  push r11
00007b4681bd5122  sub rsp, 0xF0
00007b4681bd5129  vmovaps [rsp], xmm0
00007b4681bd512e  vmovaps [rsp+0x10], xmm1
00007b4681bd5134  vmovaps [rsp+0x20], xmm2
00007b4681bd513a  vmovaps [rsp+0x30], xmm3
00007b4681bd5140  vmovaps [rsp+0x40], xmm4
00007b4681bd5146  vmovaps [rsp+0x50], xmm5
00007b4681bd514c  vmovaps [rsp+0x60], xmm6
00007b4681bd5152  vmovaps [rsp+0x70], xmm7
00007b4681bd5158  vmovaps [rsp+0x80], xmm8
00007b4681bd5161  vmovaps [rsp+0x90], xmm9
00007b4681bd516a  vmovaps [rsp+0xA0], xmm11
00007b4681bd5173  vmovaps [rsp+0xB0], xmm12
00007b4681bd517c  vmovaps [rsp+0xC0], xmm13
00007b4681bd5185  vmovaps [rsp+0xD0], xmm14
00007b4681bd518e  vmovaps [rsp+0xE0], xmm15
00007b4681bd5197  sub rsp, 0x40
00007b4681bd519b  lea rdi, [rsp]
00007b4681bd519f  lea rsi, [rsp+0x10]
00007b4681bd51a4  lea rdx, [rsp+0x20]
00007b4681bd51a9  lea rcx, [rsp+0x30]
00007b4681bd51ae  mov r8d, 0x00
00007b4681bd51b4  lea r9, [r15+0x3A8]
00007b4681bd51bb  movaps [rdi], xmm10
00007b4681bd51bf  movaps [rsi], xmm9
00007b4681bd51c3  movaps [rdx], xmm13
00007b4681bd51c7  movaps [rcx], xmm15
00007b4681bd51cb  mov rax, 0x5668589B5A50
00007b4681bd51d5  call rax
00007b4681bd51d7  movaps xmm10, [rsp]
00007b4681bd51dc  add rsp, 0x40
00007b4681bd51e0  vmovaps xmm0, [rsp]
00007b4681bd51e5  vmovaps xmm1, [rsp+0x10]
00007b4681bd51eb  vmovaps xmm2, [rsp+0x20]
00007b4681bd51f1  vmovaps xmm3, [rsp+0x30]
00007b4681bd51f7  vmovaps xmm4, [rsp+0x40]
00007b4681bd51fd  vmovaps xmm5, [rsp+0x50]
00007b4681bd5203  vmovaps xmm6, [rsp+0x60]
00007b4681bd5209  vmovaps xmm7, [rsp+0x70]
00007b4681bd520f  vmovaps xmm8, [rsp+0x80]
00007b4681bd5218  vmovaps xmm9, [rsp+0x90]
00007b4681bd5221  vmovaps xmm11, [rsp+0xA0]
00007b4681bd522a  vmovaps xmm12, [rsp+0xB0]
00007b4681bd5233  vmovaps xmm13, [rsp+0xC0]
00007b4681bd523c  vmovaps xmm14, [rsp+0xD0]
00007b4681bd5245  vmovaps xmm15, [rsp+0xE0]
00007b4681bd524e  add rsp, 0xF0
00007b4681bd5255  pop r11
00007b4681bd5257  pop r10
00007b4681bd5259  pop r9
00007b4681bd525b  pop r8
00007b4681bd525d  pop rsi
00007b4681bd525e  pop rdi
00007b4681bd525f  pop rdx
00007b4681bd5260  pop rcx
00007b4681bd5261  pop rax
00007b4681bd5262  add rsp, 0x08
00007b4681bd5266  jmp 0x00007B4681BD2FCD
00007b4681bd526b  sub rsp, 0x08
00007b4681bd526f  push rax
00007b4681bd5270  push rcx
00007b4681bd5271  push rdx
00007b4681bd5272  push rdi
00007b4681bd5273  push rsi
00007b4681bd5274  push r8
00007b4681bd5276  push r9
00007b4681bd5278  push r10
00007b4681bd527a  push r11
00007b4681bd527c  sub rsp, 0xF0
00007b4681bd5283  vmovaps [rsp], xmm0
00007b4681bd5288  vmovaps [rsp+0x10], xmm1
00007b4681bd528e  vmovaps [rsp+0x20], xmm2
00007b4681bd5294  vmovaps [rsp+0x30], xmm3
00007b4681bd529a  vmovaps [rsp+0x40], xmm4
00007b4681bd52a0  vmovaps [rsp+0x50], xmm5
00007b4681bd52a6  vmovaps [rsp+0x60], xmm6
00007b4681bd52ac  vmovaps [rsp+0x70], xmm7
00007b4681bd52b2  vmovaps [rsp+0x80], xmm8
00007b4681bd52bb  vmovaps [rsp+0x90], xmm9
00007b4681bd52c4  vmovaps [rsp+0xA0], xmm10
00007b4681bd52cd  vmovaps [rsp+0xB0], xmm11
00007b4681bd52d6  vmovaps [rsp+0xC0], xmm12
00007b4681bd52df  vmovaps [rsp+0xD0], xmm14
00007b4681bd52e8  vmovaps [rsp+0xE0], xmm15
00007b4681bd52f1  sub rsp, 0x40
00007b4681bd52f5  lea rdi, [rsp]
00007b4681bd52f9  lea rsi, [rsp+0x10]
00007b4681bd52fe  lea rdx, [rsp+0x20]
00007b4681bd5303  lea rcx, [rsp+0x30]
00007b4681bd5308  mov r8d, 0x00
00007b4681bd530e  lea r9, [r15+0x3A8]
00007b4681bd5315  movaps [rdi], xmm13
00007b4681bd5319  movaps [rsi], xmm12
00007b4681bd531d  movaps [rdx], xmm4
00007b4681bd5320  movaps [rcx], xmm15
00007b4681bd5324  mov rax, 0x5668589B5A50
00007b4681bd532e  call rax
00007b4681bd5330  movaps xmm13, [rsp]
00007b4681bd5335  add rsp, 0x40
00007b4681bd5339  vmovaps xmm0, [rsp]
00007b4681bd533e  vmovaps xmm1, [rsp+0x10]
00007b4681bd5344  vmovaps xmm2, [rsp+0x20]
00007b4681bd534a  vmovaps xmm3, [rsp+0x30]
00007b4681bd5350  vmovaps xmm4, [rsp+0x40]
00007b4681bd5356  vmovaps xmm5, [rsp+0x50]
00007b4681bd535c  vmovaps xmm6, [rsp+0x60]
00007b4681bd5362  vmovaps xmm7, [rsp+0x70]
00007b4681bd5368  vmovaps xmm8, [rsp+0x80]
00007b4681bd5371  vmovaps xmm9, [rsp+0x90]
00007b4681bd537a  vmovaps xmm10, [rsp+0xA0]
00007b4681bd5383  vmovaps xmm11, [rsp+0xB0]
00007b4681bd538c  vmovaps xmm12, [rsp+0xC0]
00007b4681bd5395  vmovaps xmm14, [rsp+0xD0]
00007b4681bd539e  vmovaps xmm15, [rsp+0xE0]
00007b4681bd53a7  add rsp, 0xF0
00007b4681bd53ae  pop r11
00007b4681bd53b0  pop r10
00007b4681bd53b2  pop r9
00007b4681bd53b4  pop r8
00007b4681bd53b6  pop rsi
00007b4681bd53b7  pop rdi
00007b4681bd53b8  pop rdx
00007b4681bd53b9  pop rcx
00007b4681bd53ba  pop rax
00007b4681bd53bb  add rsp, 0x08
00007b4681bd53bf  jmp 0x00007B4681BD2FF6
00007b4681bd53c4  sub rsp, 0x08
00007b4681bd53c8  push rax
00007b4681bd53c9  push rcx
00007b4681bd53ca  push rdx
00007b4681bd53cb  push rdi
00007b4681bd53cc  push rsi
00007b4681bd53cd  push r8
00007b4681bd53cf  push r9
00007b4681bd53d1  push r10
00007b4681bd53d3  push r11
00007b4681bd53d5  sub rsp, 0xF0
00007b4681bd53dc  vmovaps [rsp], xmm0
00007b4681bd53e1  vmovaps [rsp+0x10], xmm1
00007b4681bd53e7  vmovaps [rsp+0x20], xmm2
00007b4681bd53ed  vmovaps [rsp+0x30], xmm3
00007b4681bd53f3  vmovaps [rsp+0x40], xmm4
00007b4681bd53f9  vmovaps [rsp+0x50], xmm5
00007b4681bd53ff  vmovaps [rsp+0x60], xmm6
00007b4681bd5405  vmovaps [rsp+0x70], xmm7
00007b4681bd540b  vmovaps [rsp+0x80], xmm8
00007b4681bd5414  vmovaps [rsp+0x90], xmm9
00007b4681bd541d  vmovaps [rsp+0xA0], xmm10
00007b4681bd5426  vmovaps [rsp+0xB0], xmm11
00007b4681bd542f  vmovaps [rsp+0xC0], xmm13
00007b4681bd5438  vmovaps [rsp+0xD0], xmm14
00007b4681bd5441  vmovaps [rsp+0xE0], xmm15
00007b4681bd544a  sub rsp, 0x40
00007b4681bd544e  lea rdi, [rsp]
00007b4681bd5452  lea rsi, [rsp+0x10]
00007b4681bd5457  lea rdx, [rsp+0x20]
00007b4681bd545c  lea rcx, [rsp+0x30]
00007b4681bd5461  mov r8d, 0x00
00007b4681bd5467  lea r9, [r15+0x3A8]
00007b4681bd546e  movaps [rdi], xmm12
00007b4681bd5472  movaps [rsi], xmm7
00007b4681bd5475  movaps [rdx], xmm1
00007b4681bd5478  movaps [rcx], xmm15
00007b4681bd547c  mov rax, 0x5668589B5A50
00007b4681bd5486  call rax
00007b4681bd5488  movaps xmm12, [rsp]
00007b4681bd548d  add rsp, 0x40
00007b4681bd5491  vmovaps xmm0, [rsp]
00007b4681bd5496  vmovaps xmm1, [rsp+0x10]
00007b4681bd549c  vmovaps xmm2, [rsp+0x20]
00007b4681bd54a2  vmovaps xmm3, [rsp+0x30]
00007b4681bd54a8  vmovaps xmm4, [rsp+0x40]
00007b4681bd54ae  vmovaps xmm5, [rsp+0x50]
00007b4681bd54b4  vmovaps xmm6, [rsp+0x60]
00007b4681bd54ba  vmovaps xmm7, [rsp+0x70]
00007b4681bd54c0  vmovaps xmm8, [rsp+0x80]
00007b4681bd54c9  vmovaps xmm9, [rsp+0x90]
00007b4681bd54d2  vmovaps xmm10, [rsp+0xA0]
00007b4681bd54db  vmovaps xmm11, [rsp+0xB0]
00007b4681bd54e4  vmovaps xmm13, [rsp+0xC0]
00007b4681bd54ed  vmovaps xmm14, [rsp+0xD0]
00007b4681bd54f6  vmovaps xmm15, [rsp+0xE0]
00007b4681bd54ff  add rsp, 0xF0
00007b4681bd5506  pop r11
00007b4681bd5508  pop r10
00007b4681bd550a  pop r9
00007b4681bd550c  pop r8
00007b4681bd550e  pop rsi
00007b4681bd550f  pop rdi
00007b4681bd5510  pop rdx
00007b4681bd5511  pop rcx
00007b4681bd5512  pop rax
00007b4681bd5513  add rsp, 0x08
00007b4681bd5517  jmp 0x00007B4681BD301F
00007b4681bd551c  call 0x00007B46819FF430
00007b4681bd5521  jmp 0x00007B4681BD3029
00007b4681bd5526  call 0x00007B4681A0E760
00007b4681bd552b  jmp 0x00007B4681BD3033
00007b4681bd5530  sub rsp, 0x08
00007b4681bd5534  push rax
00007b4681bd5535  push rcx
00007b4681bd5536  push rdx
00007b4681bd5537  push rdi
00007b4681bd5538  push rsi
00007b4681bd5539  push r8
00007b4681bd553b  push r9
00007b4681bd553d  push r10
00007b4681bd553f  push r11
00007b4681bd5541  sub rsp, 0xF0
00007b4681bd5548  vmovaps [rsp], xmm0
00007b4681bd554d  vmovaps [rsp+0x10], xmm1
00007b4681bd5553  vmovaps [rsp+0x20], xmm2
00007b4681bd5559  vmovaps [rsp+0x30], xmm3
00007b4681bd555f  vmovaps [rsp+0x40], xmm4
00007b4681bd5565  vmovaps [rsp+0x50], xmm5
00007b4681bd556b  vmovaps [rsp+0x60], xmm6
00007b4681bd5571  vmovaps [rsp+0x70], xmm8
00007b4681bd5577  vmovaps [rsp+0x80], xmm9
00007b4681bd5580  vmovaps [rsp+0x90], xmm10
00007b4681bd5589  vmovaps [rsp+0xA0], xmm11
00007b4681bd5592  vmovaps [rsp+0xB0], xmm12
00007b4681bd559b  vmovaps [rsp+0xC0], xmm13
00007b4681bd55a4  vmovaps [rsp+0xD0], xmm14
00007b4681bd55ad  vmovaps [rsp+0xE0], xmm15
00007b4681bd55b6  sub rsp, 0x40
00007b4681bd55ba  lea rdi, [rsp]
00007b4681bd55be  lea rsi, [rsp+0x10]
00007b4681bd55c3  lea rdx, [rsp+0x20]
00007b4681bd55c8  lea rcx, [rsp+0x30]
00007b4681bd55cd  mov r8d, 0x00
00007b4681bd55d3  lea r9, [r15+0x3A8]
00007b4681bd55da  movaps [rdi], xmm7
00007b4681bd55dd  movaps [rsi], xmm6
00007b4681bd55e0  movaps [rdx], xmm8
00007b4681bd55e4  movaps [rcx], xmm9
00007b4681bd55e8  mov rax, 0x5668589B5A50
00007b4681bd55f2  call rax
00007b4681bd55f4  movaps xmm7, [rsp]
00007b4681bd55f8  add rsp, 0x40
00007b4681bd55fc  vmovaps xmm0, [rsp]
00007b4681bd5601  vmovaps xmm1, [rsp+0x10]
00007b4681bd5607  vmovaps xmm2, [rsp+0x20]
00007b4681bd560d  vmovaps xmm3, [rsp+0x30]
00007b4681bd5613  vmovaps xmm4, [rsp+0x40]
00007b4681bd5619  vmovaps xmm5, [rsp+0x50]
00007b4681bd561f  vmovaps xmm6, [rsp+0x60]
00007b4681bd5625  vmovaps xmm8, [rsp+0x70]
00007b4681bd562b  vmovaps xmm9, [rsp+0x80]
00007b4681bd5634  vmovaps xmm10, [rsp+0x90]
00007b4681bd563d  vmovaps xmm11, [rsp+0xA0]
00007b4681bd5646  vmovaps xmm12, [rsp+0xB0]
00007b4681bd564f  vmovaps xmm13, [rsp+0xC0]
00007b4681bd5658  vmovaps xmm14, [rsp+0xD0]
00007b4681bd5661  vmovaps xmm15, [rsp+0xE0]
00007b4681bd566a  add rsp, 0xF0
00007b4681bd5671  pop r11
00007b4681bd5673  pop r10
00007b4681bd5675  pop r9
00007b4681bd5677  pop r8
00007b4681bd5679  pop rsi
00007b4681bd567a  pop rdi
00007b4681bd567b  pop rdx
00007b4681bd567c  pop rcx
00007b4681bd567d  pop rax
00007b4681bd567e  add rsp, 0x08
00007b4681bd5682  jmp 0x00007B4681BD305D
00007b4681bd5687  sub rsp, 0x08
00007b4681bd568b  push rax
00007b4681bd568c  push rcx
00007b4681bd568d  push rdx
00007b4681bd568e  push rdi
00007b4681bd568f  push rsi
00007b4681bd5690  push r8
00007b4681bd5692  push r9
00007b4681bd5694  push r10
00007b4681bd5696  push r11
00007b4681bd5698  sub rsp, 0xF0
00007b4681bd569f  vmovaps [rsp], xmm0
00007b4681bd56a4  vmovaps [rsp+0x10], xmm1
00007b4681bd56aa  vmovaps [rsp+0x20], xmm2
00007b4681bd56b0  vmovaps [rsp+0x30], xmm3
00007b4681bd56b6  vmovaps [rsp+0x40], xmm4
00007b4681bd56bc  vmovaps [rsp+0x50], xmm5
00007b4681bd56c2  vmovaps [rsp+0x60], xmm6
00007b4681bd56c8  vmovaps [rsp+0x70], xmm7
00007b4681bd56ce  vmovaps [rsp+0x80], xmm9
00007b4681bd56d7  vmovaps [rsp+0x90], xmm10
00007b4681bd56e0  vmovaps [rsp+0xA0], xmm11
00007b4681bd56e9  vmovaps [rsp+0xB0], xmm12
00007b4681bd56f2  vmovaps [rsp+0xC0], xmm13
00007b4681bd56fb  vmovaps [rsp+0xD0], xmm14
00007b4681bd5704  vmovaps [rsp+0xE0], xmm15
00007b4681bd570d  sub rsp, 0x40
00007b4681bd5711  lea rdi, [rsp]
00007b4681bd5715  lea rsi, [rsp+0x10]
00007b4681bd571a  lea rdx, [rsp+0x20]
00007b4681bd571f  lea rcx, [rsp+0x30]
00007b4681bd5724  mov r8d, 0x00
00007b4681bd572a  lea r9, [r15+0x3A8]
00007b4681bd5731  movaps [rdi], xmm8
00007b4681bd5735  movaps [rsi], xmm10
00007b4681bd5739  movaps [rdx], xmm14
00007b4681bd573d  movaps [rcx], xmm9
00007b4681bd5741  mov rax, 0x5668589B5A50
00007b4681bd574b  call rax
00007b4681bd574d  movaps xmm8, [rsp]
00007b4681bd5752  add rsp, 0x40
00007b4681bd5756  vmovaps xmm0, [rsp]
00007b4681bd575b  vmovaps xmm1, [rsp+0x10]
00007b4681bd5761  vmovaps xmm2, [rsp+0x20]
00007b4681bd5767  vmovaps xmm3, [rsp+0x30]
00007b4681bd576d  vmovaps xmm4, [rsp+0x40]
00007b4681bd5773  vmovaps xmm5, [rsp+0x50]
00007b4681bd5779  vmovaps xmm6, [rsp+0x60]
00007b4681bd577f  vmovaps xmm7, [rsp+0x70]
00007b4681bd5785  vmovaps xmm9, [rsp+0x80]
00007b4681bd578e  vmovaps xmm10, [rsp+0x90]
00007b4681bd5797  vmovaps xmm11, [rsp+0xA0]
00007b4681bd57a0  vmovaps xmm12, [rsp+0xB0]
00007b4681bd57a9  vmovaps xmm13, [rsp+0xC0]
00007b4681bd57b2  vmovaps xmm14, [rsp+0xD0]
00007b4681bd57bb  vmovaps xmm15, [rsp+0xE0]
00007b4681bd57c4  add rsp, 0xF0
00007b4681bd57cb  pop r11
00007b4681bd57cd  pop r10
00007b4681bd57cf  pop r9
00007b4681bd57d1  pop r8
00007b4681bd57d3  pop rsi
00007b4681bd57d4  pop rdi
00007b4681bd57d5  pop rdx
00007b4681bd57d6  pop rcx
00007b4681bd57d7  pop rax
00007b4681bd57d8  add rsp, 0x08
00007b4681bd57dc  jmp 0x00007B4681BD3083
00007b4681bd57e1  sub rsp, 0x08
00007b4681bd57e5  push rax
00007b4681bd57e6  push rcx
00007b4681bd57e7  push rdx
00007b4681bd57e8  push rdi
00007b4681bd57e9  push rsi
00007b4681bd57ea  push r8
00007b4681bd57ec  push r9
00007b4681bd57ee  push r10
00007b4681bd57f0  push r11
00007b4681bd57f2  sub rsp, 0xF0
00007b4681bd57f9  vmovaps [rsp], xmm0
00007b4681bd57fe  vmovaps [rsp+0x10], xmm1
00007b4681bd5804  vmovaps [rsp+0x20], xmm2
00007b4681bd580a  vmovaps [rsp+0x30], xmm3
00007b4681bd5810  vmovaps [rsp+0x40], xmm4
00007b4681bd5816  vmovaps [rsp+0x50], xmm5
00007b4681bd581c  vmovaps [rsp+0x60], xmm6
00007b4681bd5822  vmovaps [rsp+0x70], xmm7
00007b4681bd5828  vmovaps [rsp+0x80], xmm8
00007b4681bd5831  vmovaps [rsp+0x90], xmm9
00007b4681bd583a  vmovaps [rsp+0xA0], xmm11
00007b4681bd5843  vmovaps [rsp+0xB0], xmm12
00007b4681bd584c  vmovaps [rsp+0xC0], xmm13
00007b4681bd5855  vmovaps [rsp+0xD0], xmm14
00007b4681bd585e  vmovaps [rsp+0xE0], xmm15
00007b4681bd5867  sub rsp, 0x40
00007b4681bd586b  lea rdi, [rsp]
00007b4681bd586f  lea rsi, [rsp+0x10]
00007b4681bd5874  lea rdx, [rsp+0x20]
00007b4681bd5879  lea rcx, [rsp+0x30]
00007b4681bd587e  mov r8d, 0x00
00007b4681bd5884  lea r9, [r15+0x3A8]
00007b4681bd588b  movaps [rdi], xmm10
00007b4681bd588f  movaps [rsi], xmm13
00007b4681bd5893  movaps [rdx], xmm11
00007b4681bd5897  movaps [rcx], xmm14
00007b4681bd589b  mov rax, 0x5668589B5A50
00007b4681bd58a5  call rax
00007b4681bd58a7  movaps xmm10, [rsp]
00007b4681bd58ac  add rsp, 0x40
00007b4681bd58b0  vmovaps xmm0, [rsp]
00007b4681bd58b5  vmovaps xmm1, [rsp+0x10]
00007b4681bd58bb  vmovaps xmm2, [rsp+0x20]
00007b4681bd58c1  vmovaps xmm3, [rsp+0x30]
00007b4681bd58c7  vmovaps xmm4, [rsp+0x40]
00007b4681bd58cd  vmovaps xmm5, [rsp+0x50]
00007b4681bd58d3  vmovaps xmm6, [rsp+0x60]
00007b4681bd58d9  vmovaps xmm7, [rsp+0x70]
00007b4681bd58df  vmovaps xmm8, [rsp+0x80]
00007b4681bd58e8  vmovaps xmm9, [rsp+0x90]
00007b4681bd58f1  vmovaps xmm11, [rsp+0xA0]
00007b4681bd58fa  vmovaps xmm12, [rsp+0xB0]
00007b4681bd5903  vmovaps xmm13, [rsp+0xC0]
00007b4681bd590c  vmovaps xmm14, [rsp+0xD0]
00007b4681bd5915  vmovaps xmm15, [rsp+0xE0]
00007b4681bd591e  add rsp, 0xF0
00007b4681bd5925  pop r11
00007b4681bd5927  pop r10
00007b4681bd5929  pop r9
00007b4681bd592b  pop r8
00007b4681bd592d  pop rsi
00007b4681bd592e  pop rdi
00007b4681bd592f  pop rdx
00007b4681bd5930  pop rcx
00007b4681bd5931  pop rax
00007b4681bd5932  add rsp, 0x08
00007b4681bd5936  jmp 0x00007B4681BD30A9
00007b4681bd593b  sub rsp, 0x08
00007b4681bd593f  push rax
00007b4681bd5940  push rcx
00007b4681bd5941  push rdx
00007b4681bd5942  push rdi
00007b4681bd5943  push rsi
00007b4681bd5944  push r8
00007b4681bd5946  push r9
00007b4681bd5948  push r10
00007b4681bd594a  push r11
00007b4681bd594c  sub rsp, 0xF0
00007b4681bd5953  vmovaps [rsp], xmm0
00007b4681bd5958  vmovaps [rsp+0x10], xmm1
00007b4681bd595e  vmovaps [rsp+0x20], xmm2
00007b4681bd5964  vmovaps [rsp+0x30], xmm3
00007b4681bd596a  vmovaps [rsp+0x40], xmm4
00007b4681bd5970  vmovaps [rsp+0x50], xmm5
00007b4681bd5976  vmovaps [rsp+0x60], xmm6
00007b4681bd597c  vmovaps [rsp+0x70], xmm7
00007b4681bd5982  vmovaps [rsp+0x80], xmm8
00007b4681bd598b  vmovaps [rsp+0x90], xmm9
00007b4681bd5994  vmovaps [rsp+0xA0], xmm10
00007b4681bd599d  vmovaps [rsp+0xB0], xmm11
00007b4681bd59a6  vmovaps [rsp+0xC0], xmm12
00007b4681bd59af  vmovaps [rsp+0xD0], xmm14
00007b4681bd59b8  vmovaps [rsp+0xE0], xmm15
00007b4681bd59c1  sub rsp, 0x40
00007b4681bd59c5  lea rdi, [rsp]
00007b4681bd59c9  lea rsi, [rsp+0x10]
00007b4681bd59ce  lea rdx, [rsp+0x20]
00007b4681bd59d3  lea rcx, [rsp+0x30]
00007b4681bd59d8  mov r8d, 0x00
00007b4681bd59de  lea r9, [r15+0x3A8]
00007b4681bd59e5  movaps [rdi], xmm13
00007b4681bd59e9  movaps [rsi], xmm12
00007b4681bd59ed  movaps [rdx], xmm15
00007b4681bd59f1  movaps [rcx], xmm14
00007b4681bd59f5  mov rax, 0x5668589B5A50
00007b4681bd59ff  call rax
00007b4681bd5a01  movaps xmm13, [rsp]
00007b4681bd5a06  add rsp, 0x40
00007b4681bd5a0a  vmovaps xmm0, [rsp]
00007b4681bd5a0f  vmovaps xmm1, [rsp+0x10]
00007b4681bd5a15  vmovaps xmm2, [rsp+0x20]
00007b4681bd5a1b  vmovaps xmm3, [rsp+0x30]
00007b4681bd5a21  vmovaps xmm4, [rsp+0x40]
00007b4681bd5a27  vmovaps xmm5, [rsp+0x50]
00007b4681bd5a2d  vmovaps xmm6, [rsp+0x60]
00007b4681bd5a33  vmovaps xmm7, [rsp+0x70]
00007b4681bd5a39  vmovaps xmm8, [rsp+0x80]
00007b4681bd5a42  vmovaps xmm9, [rsp+0x90]
00007b4681bd5a4b  vmovaps xmm10, [rsp+0xA0]
00007b4681bd5a54  vmovaps xmm11, [rsp+0xB0]
00007b4681bd5a5d  vmovaps xmm12, [rsp+0xC0]
00007b4681bd5a66  vmovaps xmm14, [rsp+0xD0]
00007b4681bd5a6f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd5a78  add rsp, 0xF0
00007b4681bd5a7f  pop r11
00007b4681bd5a81  pop r10
00007b4681bd5a83  pop r9
00007b4681bd5a85  pop r8
00007b4681bd5a87  pop rsi
00007b4681bd5a88  pop rdi
00007b4681bd5a89  pop rdx
00007b4681bd5a8a  pop rcx
00007b4681bd5a8b  pop rax
00007b4681bd5a8c  add rsp, 0x08
00007b4681bd5a90  jmp 0x00007B4681BD30CF
00007b4681bd5a95  call 0x00007B4681A0E760
00007b4681bd5a9a  jmp 0x00007B4681BD30DC
00007b4681bd5a9f  call 0x00007B4681A0D4E0
00007b4681bd5aa4  jmp 0x00007B4681BD30E9
00007b4681bd5aa9  sub rsp, 0x08
00007b4681bd5aad  push rax
00007b4681bd5aae  push rcx
00007b4681bd5aaf  push rdx
00007b4681bd5ab0  push rdi
00007b4681bd5ab1  push rsi
00007b4681bd5ab2  push r8
00007b4681bd5ab4  push r9
00007b4681bd5ab6  push r10
00007b4681bd5ab8  push r11
00007b4681bd5aba  sub rsp, 0xF0
00007b4681bd5ac1  vmovaps [rsp], xmm0
00007b4681bd5ac6  vmovaps [rsp+0x10], xmm1
00007b4681bd5acc  vmovaps [rsp+0x20], xmm2
00007b4681bd5ad2  vmovaps [rsp+0x30], xmm3
00007b4681bd5ad8  vmovaps [rsp+0x40], xmm4
00007b4681bd5ade  vmovaps [rsp+0x50], xmm5
00007b4681bd5ae4  vmovaps [rsp+0x60], xmm6
00007b4681bd5aea  vmovaps [rsp+0x70], xmm7
00007b4681bd5af0  vmovaps [rsp+0x80], xmm8
00007b4681bd5af9  vmovaps [rsp+0x90], xmm9
00007b4681bd5b02  vmovaps [rsp+0xA0], xmm10
00007b4681bd5b0b  vmovaps [rsp+0xB0], xmm12
00007b4681bd5b14  vmovaps [rsp+0xC0], xmm13
00007b4681bd5b1d  vmovaps [rsp+0xD0], xmm14
00007b4681bd5b26  vmovaps [rsp+0xE0], xmm15
00007b4681bd5b2f  sub rsp, 0x40
00007b4681bd5b33  lea rdi, [rsp]
00007b4681bd5b37  lea rsi, [rsp+0x10]
00007b4681bd5b3c  lea rdx, [rsp+0x20]
00007b4681bd5b41  lea rcx, [rsp+0x30]
00007b4681bd5b46  mov r8d, 0x00
00007b4681bd5b4c  lea r9, [r15+0x3A8]
00007b4681bd5b53  movaps [rdi], xmm11
00007b4681bd5b57  movaps [rsi], xmm7
00007b4681bd5b5a  movaps [rdx], xmm1
00007b4681bd5b5d  movaps [rcx], xmm12
00007b4681bd5b61  mov rax, 0x5668589B5A50
00007b4681bd5b6b  call rax
00007b4681bd5b6d  movaps xmm11, [rsp]
00007b4681bd5b72  add rsp, 0x40
00007b4681bd5b76  vmovaps xmm0, [rsp]
00007b4681bd5b7b  vmovaps xmm1, [rsp+0x10]
00007b4681bd5b81  vmovaps xmm2, [rsp+0x20]
00007b4681bd5b87  vmovaps xmm3, [rsp+0x30]
00007b4681bd5b8d  vmovaps xmm4, [rsp+0x40]
00007b4681bd5b93  vmovaps xmm5, [rsp+0x50]
00007b4681bd5b99  vmovaps xmm6, [rsp+0x60]
00007b4681bd5b9f  vmovaps xmm7, [rsp+0x70]
00007b4681bd5ba5  vmovaps xmm8, [rsp+0x80]
00007b4681bd5bae  vmovaps xmm9, [rsp+0x90]
00007b4681bd5bb7  vmovaps xmm10, [rsp+0xA0]
00007b4681bd5bc0  vmovaps xmm12, [rsp+0xB0]
00007b4681bd5bc9  vmovaps xmm13, [rsp+0xC0]
00007b4681bd5bd2  vmovaps xmm14, [rsp+0xD0]
00007b4681bd5bdb  vmovaps xmm15, [rsp+0xE0]
00007b4681bd5be4  add rsp, 0xF0
00007b4681bd5beb  pop r11
00007b4681bd5bed  pop r10
00007b4681bd5bef  pop r9
00007b4681bd5bf1  pop r8
00007b4681bd5bf3  pop rsi
00007b4681bd5bf4  pop rdi
00007b4681bd5bf5  pop rdx
00007b4681bd5bf6  pop rcx
00007b4681bd5bf7  pop rax
00007b4681bd5bf8  add rsp, 0x08
00007b4681bd5bfc  jmp 0x00007B4681BD3122
00007b4681bd5c01  call 0x00007B46819FF430
00007b4681bd5c06  jmp 0x00007B4681BD3134
00007b4681bd5c0b  sub rsp, 0x08
00007b4681bd5c0f  push rax
00007b4681bd5c10  push rcx
00007b4681bd5c11  push rdx
00007b4681bd5c12  push rdi
00007b4681bd5c13  push rsi
00007b4681bd5c14  push r8
00007b4681bd5c16  push r9
00007b4681bd5c18  push r10
00007b4681bd5c1a  push r11
00007b4681bd5c1c  sub rsp, 0xF0
00007b4681bd5c23  vmovaps [rsp], xmm0
00007b4681bd5c28  vmovaps [rsp+0x10], xmm1
00007b4681bd5c2e  vmovaps [rsp+0x20], xmm2
00007b4681bd5c34  vmovaps [rsp+0x30], xmm3
00007b4681bd5c3a  vmovaps [rsp+0x40], xmm4
00007b4681bd5c40  vmovaps [rsp+0x50], xmm5
00007b4681bd5c46  vmovaps [rsp+0x60], xmm6
00007b4681bd5c4c  vmovaps [rsp+0x70], xmm7
00007b4681bd5c52  vmovaps [rsp+0x80], xmm8
00007b4681bd5c5b  vmovaps [rsp+0x90], xmm10
00007b4681bd5c64  vmovaps [rsp+0xA0], xmm11
00007b4681bd5c6d  vmovaps [rsp+0xB0], xmm12
00007b4681bd5c76  vmovaps [rsp+0xC0], xmm13
00007b4681bd5c7f  vmovaps [rsp+0xD0], xmm14
00007b4681bd5c88  vmovaps [rsp+0xE0], xmm15
00007b4681bd5c91  sub rsp, 0x40
00007b4681bd5c95  lea rdi, [rsp]
00007b4681bd5c99  lea rsi, [rsp+0x10]
00007b4681bd5c9e  lea rdx, [rsp+0x20]
00007b4681bd5ca3  lea rcx, [rsp+0x30]
00007b4681bd5ca8  mov r8d, 0x00
00007b4681bd5cae  lea r9, [r15+0x3A8]
00007b4681bd5cb5  movaps [rdi], xmm9
00007b4681bd5cb9  movaps [rsi], xmm8
00007b4681bd5cbd  movaps [rdx], xmm14
00007b4681bd5cc1  movaps [rcx], xmm12
00007b4681bd5cc5  mov rax, 0x5668589B5A50
00007b4681bd5ccf  call rax
00007b4681bd5cd1  movaps xmm9, [rsp]
00007b4681bd5cd6  add rsp, 0x40
00007b4681bd5cda  vmovaps xmm0, [rsp]
00007b4681bd5cdf  vmovaps xmm1, [rsp+0x10]
00007b4681bd5ce5  vmovaps xmm2, [rsp+0x20]
00007b4681bd5ceb  vmovaps xmm3, [rsp+0x30]
00007b4681bd5cf1  vmovaps xmm4, [rsp+0x40]
00007b4681bd5cf7  vmovaps xmm5, [rsp+0x50]
00007b4681bd5cfd  vmovaps xmm6, [rsp+0x60]
00007b4681bd5d03  vmovaps xmm7, [rsp+0x70]
00007b4681bd5d09  vmovaps xmm8, [rsp+0x80]
00007b4681bd5d12  vmovaps xmm10, [rsp+0x90]
00007b4681bd5d1b  vmovaps xmm11, [rsp+0xA0]
00007b4681bd5d24  vmovaps xmm12, [rsp+0xB0]
00007b4681bd5d2d  vmovaps xmm13, [rsp+0xC0]
00007b4681bd5d36  vmovaps xmm14, [rsp+0xD0]
00007b4681bd5d3f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd5d48  add rsp, 0xF0
00007b4681bd5d4f  pop r11
00007b4681bd5d51  pop r10
00007b4681bd5d53  pop r9
00007b4681bd5d55  pop r8
00007b4681bd5d57  pop rsi
00007b4681bd5d58  pop rdi
00007b4681bd5d59  pop rdx
00007b4681bd5d5a  pop rcx
00007b4681bd5d5b  pop rax
00007b4681bd5d5c  add rsp, 0x08
00007b4681bd5d60  jmp 0x00007B4681BD3165
00007b4681bd5d65  sub rsp, 0x08
00007b4681bd5d69  push rax
00007b4681bd5d6a  push rcx
00007b4681bd5d6b  push rdx
00007b4681bd5d6c  push rdi
00007b4681bd5d6d  push rsi
00007b4681bd5d6e  push r8
00007b4681bd5d70  push r9
00007b4681bd5d72  push r10
00007b4681bd5d74  push r11
00007b4681bd5d76  sub rsp, 0xF0
00007b4681bd5d7d  vmovaps [rsp], xmm0
00007b4681bd5d82  vmovaps [rsp+0x10], xmm1
00007b4681bd5d88  vmovaps [rsp+0x20], xmm2
00007b4681bd5d8e  vmovaps [rsp+0x30], xmm3
00007b4681bd5d94  vmovaps [rsp+0x40], xmm4
00007b4681bd5d9a  vmovaps [rsp+0x50], xmm5
00007b4681bd5da0  vmovaps [rsp+0x60], xmm6
00007b4681bd5da6  vmovaps [rsp+0x70], xmm7
00007b4681bd5dac  vmovaps [rsp+0x80], xmm8
00007b4681bd5db5  vmovaps [rsp+0x90], xmm9
00007b4681bd5dbe  vmovaps [rsp+0xA0], xmm10
00007b4681bd5dc7  vmovaps [rsp+0xB0], xmm11
00007b4681bd5dd0  vmovaps [rsp+0xC0], xmm13
00007b4681bd5dd9  vmovaps [rsp+0xD0], xmm14
00007b4681bd5de2  vmovaps [rsp+0xE0], xmm15
00007b4681bd5deb  sub rsp, 0x40
00007b4681bd5def  lea rdi, [rsp]
00007b4681bd5df3  lea rsi, [rsp+0x10]
00007b4681bd5df8  lea rdx, [rsp+0x20]
00007b4681bd5dfd  lea rcx, [rsp+0x30]
00007b4681bd5e02  mov r8d, 0x00
00007b4681bd5e08  lea r9, [r15+0x3A8]
00007b4681bd5e0f  movaps [rdi], xmm12
00007b4681bd5e13  movaps [rsi], xmm10
00007b4681bd5e17  movaps [rdx], xmm15
00007b4681bd5e1b  movaps [rcx], xmm14
00007b4681bd5e1f  mov rax, 0x5668589B5A50
00007b4681bd5e29  call rax
00007b4681bd5e2b  movaps xmm12, [rsp]
00007b4681bd5e30  add rsp, 0x40
00007b4681bd5e34  vmovaps xmm0, [rsp]
00007b4681bd5e39  vmovaps xmm1, [rsp+0x10]
00007b4681bd5e3f  vmovaps xmm2, [rsp+0x20]
00007b4681bd5e45  vmovaps xmm3, [rsp+0x30]
00007b4681bd5e4b  vmovaps xmm4, [rsp+0x40]
00007b4681bd5e51  vmovaps xmm5, [rsp+0x50]
00007b4681bd5e57  vmovaps xmm6, [rsp+0x60]
00007b4681bd5e5d  vmovaps xmm7, [rsp+0x70]
00007b4681bd5e63  vmovaps xmm8, [rsp+0x80]
00007b4681bd5e6c  vmovaps xmm9, [rsp+0x90]
00007b4681bd5e75  vmovaps xmm10, [rsp+0xA0]
00007b4681bd5e7e  vmovaps xmm11, [rsp+0xB0]
00007b4681bd5e87  vmovaps xmm13, [rsp+0xC0]
00007b4681bd5e90  vmovaps xmm14, [rsp+0xD0]
00007b4681bd5e99  vmovaps xmm15, [rsp+0xE0]
00007b4681bd5ea2  add rsp, 0xF0
00007b4681bd5ea9  pop r11
00007b4681bd5eab  pop r10
00007b4681bd5ead  pop r9
00007b4681bd5eaf  pop r8
00007b4681bd5eb1  pop rsi
00007b4681bd5eb2  pop rdi
00007b4681bd5eb3  pop rdx
00007b4681bd5eb4  pop rcx
00007b4681bd5eb5  pop rax
00007b4681bd5eb6  add rsp, 0x08
00007b4681bd5eba  jmp 0x00007B4681BD3196
00007b4681bd5ebf  sub rsp, 0x08
00007b4681bd5ec3  push rax
00007b4681bd5ec4  push rcx
00007b4681bd5ec5  push rdx
00007b4681bd5ec6  push rdi
00007b4681bd5ec7  push rsi
00007b4681bd5ec8  push r8
00007b4681bd5eca  push r9
00007b4681bd5ecc  push r10
00007b4681bd5ece  push r11
00007b4681bd5ed0  sub rsp, 0xF0
00007b4681bd5ed7  vmovaps [rsp], xmm0
00007b4681bd5edc  vmovaps [rsp+0x10], xmm1
00007b4681bd5ee2  vmovaps [rsp+0x20], xmm2
00007b4681bd5ee8  vmovaps [rsp+0x30], xmm3
00007b4681bd5eee  vmovaps [rsp+0x40], xmm4
00007b4681bd5ef4  vmovaps [rsp+0x50], xmm5
00007b4681bd5efa  vmovaps [rsp+0x60], xmm6
00007b4681bd5f00  vmovaps [rsp+0x70], xmm7
00007b4681bd5f06  vmovaps [rsp+0x80], xmm8
00007b4681bd5f0f  vmovaps [rsp+0x90], xmm9
00007b4681bd5f18  vmovaps [rsp+0xA0], xmm10
00007b4681bd5f21  vmovaps [rsp+0xB0], xmm11
00007b4681bd5f2a  vmovaps [rsp+0xC0], xmm12
00007b4681bd5f33  vmovaps [rsp+0xD0], xmm13
00007b4681bd5f3c  vmovaps [rsp+0xE0], xmm15
00007b4681bd5f45  sub rsp, 0x40
00007b4681bd5f49  lea rdi, [rsp]
00007b4681bd5f4d  lea rsi, [rsp+0x10]
00007b4681bd5f52  lea rdx, [rsp+0x20]
00007b4681bd5f57  lea rcx, [rsp+0x30]
00007b4681bd5f5c  mov r8d, 0x00
00007b4681bd5f62  lea r9, [r15+0x3A8]
00007b4681bd5f69  movaps [rdi], xmm14
00007b4681bd5f6d  movaps [rsi], xmm13
00007b4681bd5f71  movaps [rdx], xmm1
00007b4681bd5f74  movaps [rcx], xmm15
00007b4681bd5f78  mov rax, 0x5668589B5A50
00007b4681bd5f82  call rax
00007b4681bd5f84  movaps xmm14, [rsp]
00007b4681bd5f89  add rsp, 0x40
00007b4681bd5f8d  vmovaps xmm0, [rsp]
00007b4681bd5f92  vmovaps xmm1, [rsp+0x10]
00007b4681bd5f98  vmovaps xmm2, [rsp+0x20]
00007b4681bd5f9e  vmovaps xmm3, [rsp+0x30]
00007b4681bd5fa4  vmovaps xmm4, [rsp+0x40]
00007b4681bd5faa  vmovaps xmm5, [rsp+0x50]
00007b4681bd5fb0  vmovaps xmm6, [rsp+0x60]
00007b4681bd5fb6  vmovaps xmm7, [rsp+0x70]
00007b4681bd5fbc  vmovaps xmm8, [rsp+0x80]
00007b4681bd5fc5  vmovaps xmm9, [rsp+0x90]
00007b4681bd5fce  vmovaps xmm10, [rsp+0xA0]
00007b4681bd5fd7  vmovaps xmm11, [rsp+0xB0]
00007b4681bd5fe0  vmovaps xmm12, [rsp+0xC0]
00007b4681bd5fe9  vmovaps xmm13, [rsp+0xD0]
00007b4681bd5ff2  vmovaps xmm15, [rsp+0xE0]
00007b4681bd5ffb  add rsp, 0xF0
00007b4681bd6002  pop r11
00007b4681bd6004  pop r10
00007b4681bd6006  pop r9
00007b4681bd6008  pop r8
00007b4681bd600a  pop rsi
00007b4681bd600b  pop rdi
00007b4681bd600c  pop rdx
00007b4681bd600d  pop rcx
00007b4681bd600e  pop rax
00007b4681bd600f  add rsp, 0x08
00007b4681bd6013  jmp 0x00007B4681BD31C7
00007b4681bd6018  call 0x00007B4681A079B0
00007b4681bd601d  jmp 0x00007B4681BD31DA
00007b4681bd6022  call 0x00007B4681A0B100
00007b4681bd6027  jmp 0x00007B4681BD31E5
00007b4681bd602c  call 0x00007B4681A09E90
00007b4681bd6031  jmp 0x00007B4681BD31F0
00007b4681bd6036  call 0x00007B4681A0D600
00007b4681bd603b  jmp 0x00007B4681BD31FB
00007b4681bd6040  int3
00007b4681bd6041  nop [rax+rax*1], ax
00007b4681bd604a  nop [rax+rax*1], ax
00007b4681bd6050  mov rax, [r15+0x40]
00007b4681bd6054  mov r14, [r15+0x58]
00007b4681bd6058  lea r12, [rax+r14*1]
00007b4681bd605c  vxorps xmm1, xmm1, xmm1
00007b4681bd6060  vpbroadcastq xmm1, xmm1
00007b4681bd6065  vxorps xmm15, xmm15, xmm15
00007b4681bd606a  vpbroadcastq xmm15, xmm15
00007b4681bd606f  lea rax, [r12+0x30]
00007b4681bd6074  mov r11, [r13+rax*1]
00007b4681bd6079  lea rax, [r12+0x38]
00007b4681bd607e  mov r10, [r13+rax*1]
00007b4681bd6083  movq xmm14, r11
00007b4681bd6088  movq xmm13, r10
00007b4681bd608d  movq xmm14, xmm14
00007b4681bd6092  movq xmm13, xmm13
00007b4681bd6097  vmovaps [rsp+0x10], xmm13
00007b4681bd609d  movq xmm13, xmm13
00007b4681bd60a2  movaps [r15+0x270], xmm13
00007b4681bd60aa  movaps xmm13, [r15+0x160]
00007b4681bd60b2  vmovaps [rsp+0x20], xmm13
00007b4681bd60b8  vmovaps xmm12, [rsp+0x20]
00007b4681bd60be  por xmm13, xmm12
00007b4681bd60c3  lea rax, [r12+0x20]
00007b4681bd60c8  mov r11, [r13+rax*1]
00007b4681bd60cd  lea rax, [r12+0x28]
00007b4681bd60d2  mov r10, [r13+rax*1]
00007b4681bd60d7  movq xmm12, r11
00007b4681bd60dc  movq xmm11, r10
00007b4681bd60e1  movq xmm12, xmm12
00007b4681bd60e6  movq xmm11, xmm11
00007b4681bd60eb  movaps xmm10, [r15+0x2D0]
00007b4681bd60f3  vmovaps [rsp+0x20], xmm10
00007b4681bd60f9  vmovaps xmm9, [rsp+0x20]
00007b4681bd60ff  por xmm10, xmm9
00007b4681bd6104  movaps xmm9, [r15+0x300]
00007b4681bd610c  vmovaps [rsp+0x20], xmm9
00007b4681bd6112  vmovaps xmm8, [rsp+0x20]
00007b4681bd6118  por xmm9, xmm8
00007b4681bd611d  movaps xmm8, [r15+0x2B0]
00007b4681bd6125  vmovaps [rsp+0x20], xmm8
00007b4681bd612b  vmovaps xmm7, [rsp+0x20]
00007b4681bd6131  por xmm8, xmm7
00007b4681bd6136  movaps xmm7, [r15+0x180]
00007b4681bd613e  vmovaps [rsp+0x20], xmm7
00007b4681bd6144  vmovaps xmm6, [rsp+0x20]
00007b4681bd614a  por xmm7, xmm6
00007b4681bd614e  lea rax, [r12+0x10]
00007b4681bd6153  mov r11, [r13+rax*1]
00007b4681bd6158  lea rax, [r12+0x18]
00007b4681bd615d  mov r10, [r13+rax*1]
00007b4681bd6162  movq xmm6, r11
00007b4681bd6167  movq xmm5, r10
00007b4681bd616c  movq xmm6, xmm6
00007b4681bd6170  movq xmm5, xmm5
00007b4681bd6174  movaps xmm4, [r15+0x200]
00007b4681bd617c  vmovaps [rsp+0x20], xmm4
00007b4681bd6182  vmovaps xmm3, [rsp+0x20]
00007b4681bd6188  por xmm4, xmm3
00007b4681bd618c  movaps xmm3, [r15+0x1F0]
00007b4681bd6194  vmovaps [rsp+0x20], xmm3
00007b4681bd619a  vmovaps xmm2, [rsp+0x20]
00007b4681bd61a0  por xmm3, xmm2
00007b4681bd61a4  movaps xmm2, [r15+0x2E0]
00007b4681bd61ac  vmovaps [rsp+0x20], xmm2
00007b4681bd61b2  vmovaps [rsp+0x30], xmm1
00007b4681bd61b8  vmovaps xmm1, [rsp+0x20]
00007b4681bd61be  por xmm2, xmm1
00007b4681bd61c2  movaps xmm1, [r15+0x2A0]
00007b4681bd61ca  vmovaps [rsp+0x20], xmm1
00007b4681bd61d0  vmovaps [rsp+0x40], xmm15
00007b4681bd61d6  vmovaps xmm15, [rsp+0x20]
00007b4681bd61dc  por xmm1, xmm15
00007b4681bd61e1  movaps xmm15, [r15+0x280]
00007b4681bd61e9  vmovaps [rsp+0x20], xmm15
00007b4681bd61ef  vmovaps [rsp+0x50], xmm1
00007b4681bd61f5  vmovaps xmm1, [rsp+0x20]
00007b4681bd61fb  por xmm15, xmm1
00007b4681bd6200  movaps xmm1, [r15+0x1C0]
00007b4681bd6208  vmovaps [rsp+0x20], xmm1
00007b4681bd620e  vmovaps [rsp+0x60], xmm15
00007b4681bd6214  vmovaps xmm15, [rsp+0x20]
00007b4681bd621a  por xmm1, xmm15
00007b4681bd621f  movaps xmm15, [r15+0x210]
00007b4681bd6227  vmovaps [rsp+0x20], xmm15
00007b4681bd622d  vmovaps [rsp+0x70], xmm1
00007b4681bd6233  vmovaps xmm1, [rsp+0x20]
00007b4681bd6239  por xmm15, xmm1
00007b4681bd623e  mov rax, [r13+r12*1]
00007b4681bd6243  vmovq xmm1, rax
00007b4681bd6248  vpbroadcastq xmm1, xmm1
00007b4681bd624d  vmovaps [rsp+0x20], xmm1
00007b4681bd6253  vxorps xmm1, xmm1, xmm1
00007b4681bd6257  vpbroadcastq xmm1, xmm1
00007b4681bd625c  mov rax, [r15+0xF8]
00007b4681bd6263  vmovaps [rsp+0x80], xmm1
00007b4681bd626c  movups xmm1, [r13+rax*1]
00007b4681bd6272  vmovaps [rsp+0x90], xmm1
00007b4681bd627b  vxorps xmm1, xmm1, xmm1
00007b4681bd627f  vpbroadcastq xmm1, xmm1
00007b4681bd6284  lea r11, [r12+0x08]
00007b4681bd6289  mov r12, [r13+r11*1]
00007b4681bd628e  vmovaps [rsp+0xA0], xmm1
00007b4681bd6297  movq xmm1, r12
00007b4681bd629c  movaps [r15+0x240], xmm1
00007b4681bd62a4  mov r12, [r15+0x50]
00007b4681bd62a8  lea r11, [r12+r14*1]
00007b4681bd62ac  mov [r15+0x60], r11
00007b4681bd62b0  lea r12, [r14+0x40]
00007b4681bd62b4  mov [r15+0x58], r12
00007b4681bd62b8  vmovaps xmm1, [rsp+0x30]
00007b4681bd62be  vmovaps [rsp+0x30], xmm15
00007b4681bd62c4  vmovaps xmm15, [rsp+0x90]
00007b4681bd62cd  vmovaps [rsp+0x90], xmm14
00007b4681bd62d6  vmovaps xmm14, [rsp+0x20]
00007b4681bd62dc  vmovaps [rsp+0x20], xmm13
00007b4681bd62e2  vmovaps [rsp+0xB0], xmm12
00007b4681bd62eb  movaps xmm13, xmm1
00007b4681bd62ef  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd62fa  vptest xmm12, xmm12
00007b4681bd62ff  jnz 0x00007B4681BD6D9C
00007b4681bd6305  movaps xmm1, [r15+0x250]
00007b4681bd630d  vmovaps xmm15, [rsp+0x40]
00007b4681bd6313  vmovaps [rsp+0x40], xmm13
00007b4681bd6319  movaps xmm12, xmm15
00007b4681bd631d  vfmadd231pd xmm12, xmm1, xmm14
00007b4681bd6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007b4681bd6328  vptest xmm13, xmm13
00007b4681bd632d  jnz 0x00007B4681BD6EF5
00007b4681bd6333  movaps xmm15, [r15+0x1E0]
00007b4681bd633b  vmovaps [rsp+0xC0], xmm15
00007b4681bd6344  vmovaps xmm13, [rsp+0xC0]
00007b4681bd634d  por xmm15, xmm13
00007b4681bd6352  movaps xmm13, [r15+0x1D0]
00007b4681bd635a  vmovaps [rsp+0xC0], xmm13
00007b4681bd6363  vmovaps [rsp+0xD0], xmm1
00007b4681bd636c  vmovaps xmm1, [rsp+0xC0]
00007b4681bd6375  por xmm13, xmm1
00007b4681bd637a  movaps xmm1, [r15+0x2C0]
00007b4681bd6382  vmovaps [rsp+0xC0], xmm1
00007b4681bd638b  vmovaps [rsp+0xE0], xmm15
00007b4681bd6394  vmovaps xmm15, [rsp+0xC0]
00007b4681bd639d  por xmm1, xmm15
00007b4681bd63a2  movaps xmm15, [r15+0x290]
00007b4681bd63aa  vmovaps [rsp+0xC0], xmm15
00007b4681bd63b3  vmovaps [rsp+0xF0], xmm1
00007b4681bd63bc  vmovaps xmm1, [rsp+0xC0]
00007b4681bd63c5  por xmm15, xmm1
00007b4681bd63ca  movaps xmm1, [r15+0x260]
00007b4681bd63d2  vmovaps [rsp+0xC0], xmm1
00007b4681bd63db  vmovaps [rsp+0x100], xmm15
00007b4681bd63e4  vmovaps xmm15, [rsp+0xC0]
00007b4681bd63ed  por xmm1, xmm15
00007b4681bd63f2  vmovaps xmm15, [rsp+0xD0]
00007b4681bd63fb  vmovaps [rsp+0xC0], xmm1
00007b4681bd6404  vmovaps xmm1, [rsp+0xD0]
00007b4681bd640d  por xmm15, xmm1
00007b4681bd6412  lea r14, [rax+0xC0]
00007b4681bd6419  movups xmm1, [r13+r14*1]
00007b4681bd641f  mov [rsp+0xD0], rax
00007b4681bd6427  xor eax, eax
00007b4681bd6429  mov r14d, 0x200
00007b4681bd642f  cmp r12, r14
00007b4681bd6432  cmc
00007b4681bd6433  lahf
00007b4681bd6434  seto al
00007b4681bd6437  mov [r15+0x108], eax
00007b4681bd643e  vmovaps [rsp+0x110], xmm1
00007b4681bd6447  vmovaps xmm1, [rsp+0x80]
00007b4681bd6450  vmovaps [rsp+0x80], xmm15
00007b4681bd6459  vmovaps xmm15, [rsp+0x110]
00007b4681bd6462  vmovaps [rsp+0x110], xmm13
00007b4681bd646b  vmovaps [rsp+0x120], xmm12
00007b4681bd6474  movaps xmm13, xmm1
00007b4681bd6478  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd6483  vptest xmm12, xmm12
00007b4681bd6488  jnz 0x00007B4681BD7058
00007b4681bd648e  mov rax, [rsp+0xD0]
00007b4681bd6496  lea r14, [rax+0xB0]
00007b4681bd649d  movups xmm1, [r13+r14*1]
00007b4681bd64a3  vmovaps xmm15, [rsp+0xA0]
00007b4681bd64ac  vmovaps [rsp+0xA0], xmm13
00007b4681bd64b5  movaps xmm12, xmm15
00007b4681bd64b9  vfmadd231pd xmm12, xmm1, xmm14
00007b4681bd64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007b4681bd64c4  vptest xmm13, xmm13
00007b4681bd64c9  jnz 0x00007B4681BD71BB
00007b4681bd64cf  vmovaps xmm1, [rsp+0x30]
00007b4681bd64d5  vmovaps xmm15, [rsp+0x30]
00007b4681bd64db  por xmm1, xmm15
00007b4681bd64e0  movaps [r15+0x210], xmm1
00007b4681bd64e8  vmovaps xmm15, [rsp+0x70]
00007b4681bd64ee  vmovaps xmm14, [rsp+0x70]
00007b4681bd64f4  por xmm15, xmm14
00007b4681bd64f9  movaps [r15+0x1C0], xmm15
00007b4681bd6501  vmovaps xmm14, [rsp+0x60]
00007b4681bd6507  vmovaps xmm13, [rsp+0x60]
00007b4681bd650d  por xmm14, xmm13
00007b4681bd6512  movaps [r15+0x280], xmm14
00007b4681bd651a  vmovaps xmm13, [rsp+0x50]
00007b4681bd6520  vmovaps [rsp+0x30], xmm1
00007b4681bd6526  vmovaps xmm1, [rsp+0x50]
00007b4681bd652c  por xmm13, xmm1
00007b4681bd6531  movaps [r15+0x2A0], xmm13
00007b4681bd6539  vmovaps [rsp+0x50], xmm2
00007b4681bd653f  vmovaps xmm1, [rsp+0x50]
00007b4681bd6545  por xmm2, xmm1
00007b4681bd6549  movaps [r15+0x2E0], xmm2
00007b4681bd6551  vmovaps [rsp+0x50], xmm3
00007b4681bd6557  vmovaps xmm1, [rsp+0x50]
00007b4681bd655d  por xmm3, xmm1
00007b4681bd6561  movaps [r15+0x1F0], xmm3
00007b4681bd6569  vmovaps xmm1, [rsp+0x80]
00007b4681bd6572  vmovaps [rsp+0x50], xmm15
00007b4681bd6578  vmovaps xmm15, [rsp+0x80]
00007b4681bd6581  por xmm1, xmm15
00007b4681bd6586  movaps [r15+0x250], xmm1
00007b4681bd658e  vmovaps xmm1, [rsp+0xC0]
00007b4681bd6597  vmovaps xmm15, [rsp+0xC0]
00007b4681bd65a0  por xmm1, xmm15
00007b4681bd65a5  movaps [r15+0x260], xmm1
00007b4681bd65ad  vmovaps xmm15, [rsp+0x100]
00007b4681bd65b6  vmovaps [rsp+0x60], xmm1
00007b4681bd65bc  vmovaps xmm1, [rsp+0x100]
00007b4681bd65c5  por xmm15, xmm1
00007b4681bd65ca  movaps [r15+0x290], xmm15
00007b4681bd65d2  vmovaps xmm1, [rsp+0xF0]
00007b4681bd65db  vmovaps [rsp+0x70], xmm15
00007b4681bd65e1  vmovaps xmm15, [rsp+0xF0]
00007b4681bd65ea  por xmm1, xmm15
00007b4681bd65ef  movaps [r15+0x2C0], xmm1
00007b4681bd65f7  movq xmm15, qword ptr [r15+0x240]
00007b4681bd6600  vmovaps [rsp+0x80], xmm15
00007b4681bd6609  vpermilpd xmm15, xmm15, 0x00
00007b4681bd660f  vmovaps [rsp+0xC0], xmm1
00007b4681bd6618  vmovaps xmm1, [rsp+0x40]
00007b4681bd661e  vmovaps [rsp+0x40], xmm15
00007b4681bd6624  vmovaps xmm15, [rsp+0x30]
00007b4681bd662a  vmovaps [rsp+0x30], xmm14
00007b4681bd6630  vmovaps xmm14, [rsp+0x40]
00007b4681bd6636  vmovaps [rsp+0x40], xmm13
00007b4681bd663c  vmovaps [rsp+0xD0], xmm12
00007b4681bd6645  movaps xmm13, xmm1
00007b4681bd6649  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd6654  vptest xmm12, xmm12
00007b4681bd6659  jnz 0x00007B4681BD7314
00007b4681bd665f  vmovaps xmm1, [rsp+0x80]
00007b4681bd6668  vpermilpd xmm1, xmm1, 0x00
00007b4681bd666e  vmovaps xmm15, [rsp+0xA0]
00007b4681bd6677  movaps xmm14, xmm15
00007b4681bd667b  vfmadd231pd xmm14, xmm2, xmm1
00007b4681bd6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007b4681bd6686  vptest xmm12, xmm12
00007b4681bd668b  jnz 0x00007B4681BD746D
00007b4681bd6691  vmovaps xmm1, [rsp+0x80]
00007b4681bd669a  vpermilpd xmm1, xmm1, 0x00
00007b4681bd66a0  vmovaps xmm15, [rsp+0x120]
00007b4681bd66a9  vmovaps xmm12, [rsp+0x50]
00007b4681bd66af  vmovaps [rsp+0x50], xmm14
00007b4681bd66b5  movaps xmm2, xmm15
00007b4681bd66b9  vfmadd231pd xmm2, xmm12, xmm1
00007b4681bd66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007b4681bd66c3  vptest xmm14, xmm14
00007b4681bd66c8  jnz 0x00007B4681BD75C5
00007b4681bd66ce  vmovaps xmm1, [rsp+0x110]
00007b4681bd66d7  vmovaps xmm15, [rsp+0x110]
00007b4681bd66e0  por xmm1, xmm15
00007b4681bd66e5  movaps [r15+0x1D0], xmm1
00007b4681bd66ed  vmovaps xmm15, [rsp+0x80]
00007b4681bd66f6  vpermilpd xmm15, xmm15, 0x00
00007b4681bd66fc  vmovaps xmm14, [rsp+0xD0]
00007b4681bd6705  vmovaps [rsp+0x80], xmm1
00007b4681bd670e  movaps xmm12, xmm14
00007b4681bd6712  vfmadd231pd xmm12, xmm3, xmm15
00007b4681bd6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007b4681bd671d  vptest xmm1, xmm1
00007b4681bd6722  jnz 0x00007B4681BD771C
00007b4681bd6728  vmovaps [rsp+0xA0], xmm4
00007b4681bd6731  vmovaps xmm1, [rsp+0xA0]
00007b4681bd673a  por xmm4, xmm1
00007b4681bd673e  movaps [r15+0x200], xmm4
00007b4681bd6746  vmovaps xmm1, [rsp+0xE0]
00007b4681bd674f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd6758  por xmm1, xmm15
00007b4681bd675d  movaps [r15+0x1E0], xmm1
00007b4681bd6765  vmovaps [rsp+0xA0], xmm8
00007b4681bd676e  vmovaps xmm1, [rsp+0xA0]
00007b4681bd6777  por xmm8, xmm1
00007b4681bd677c  movaps [r15+0x2B0], xmm8
00007b4681bd6784  vmovaps [rsp+0xA0], xmm9
00007b4681bd678d  vmovaps xmm1, [rsp+0xA0]
00007b4681bd6796  por xmm9, xmm1
00007b4681bd679b  movaps [r15+0x300], xmm9
00007b4681bd67a3  vmovaps [rsp+0xA0], xmm6
00007b4681bd67ac  vpermilpd xmm6, xmm6, 0x00
00007b4681bd67b2  vmovaps xmm14, [rsp+0x60]
00007b4681bd67b8  movaps xmm9, xmm13
00007b4681bd67bc  vfmadd231pd xmm9, xmm14, xmm6
00007b4681bd67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007b4681bd67c7  vptest xmm3, xmm3
00007b4681bd67cc  jnz 0x00007B4681BD7875
00007b4681bd67d2  vmovaps xmm14, [rsp+0xA0]
00007b4681bd67db  vpermilpd xmm14, xmm14, 0x00
00007b4681bd67e1  vmovaps xmm13, [rsp+0x50]
00007b4681bd67e7  vmovaps xmm6, [rsp+0xC0]
00007b4681bd67f0  vmovaps [rsp+0x50], xmm1
00007b4681bd67f6  movaps xmm3, xmm13
00007b4681bd67fa  vfmadd231pd xmm3, xmm6, xmm14
00007b4681bd67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007b4681bd6804  vptest xmm1, xmm1
00007b4681bd6809  jnz 0x00007B4681BD79CE
00007b4681bd680f  vmovaps xmm1, [rsp+0xA0]
00007b4681bd6818  vpermilpd xmm1, xmm1, 0x00
00007b4681bd681e  vmovaps xmm14, [rsp+0x30]
00007b4681bd6824  movaps xmm6, xmm2
00007b4681bd6827  vfmadd231pd xmm6, xmm14, xmm1
00007b4681bd682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007b4681bd6831  vptest xmm13, xmm13
00007b4681bd6836  jnz 0x00007B4681BD7B25
00007b4681bd683c  vmovaps xmm1, [rsp+0xA0]
00007b4681bd6845  vpermilpd xmm1, xmm1, 0x00
00007b4681bd684b  vmovaps xmm14, [rsp+0x80]
00007b4681bd6854  movaps xmm13, xmm12
00007b4681bd6858  vfmadd231pd xmm13, xmm14, xmm1
00007b4681bd685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007b4681bd6863  vptest xmm2, xmm2
00007b4681bd6868  jnz 0x00007B4681BD7C7B
00007b4681bd686e  vmovaps [rsp+0x30], xmm7
00007b4681bd6874  vmovaps xmm1, [rsp+0x30]
00007b4681bd687a  por xmm7, xmm1
00007b4681bd687e  movaps [r15+0x180], xmm7
00007b4681bd6886  vmovaps [rsp+0x30], xmm10
00007b4681bd688c  vmovaps xmm1, [rsp+0x30]
00007b4681bd6892  por xmm10, xmm1
00007b4681bd6897  movaps [r15+0x2D0], xmm10
00007b4681bd689f  vmovaps [rsp+0x30], xmm5
00007b4681bd68a5  vpermilpd xmm5, xmm5, 0x00
00007b4681bd68ab  vmovaps xmm14, [rsp+0x50]
00007b4681bd68b1  movaps xmm12, xmm3
00007b4681bd68b5  vfmadd231pd xmm12, xmm14, xmm5
00007b4681bd68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007b4681bd68c0  vptest xmm10, xmm10
00007b4681bd68c5  jnz 0x00007B4681BD7DD4
00007b4681bd68cb  vmovaps xmm14, [rsp+0x30]
00007b4681bd68d1  vpermilpd xmm14, xmm14, 0x00
00007b4681bd68d7  movaps xmm10, xmm9
00007b4681bd68db  vfmadd231pd xmm10, xmm7, xmm14
00007b4681bd68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007b4681bd68e6  vptest xmm5, xmm5
00007b4681bd68eb  jnz 0x00007B4681BD7F2C
00007b4681bd68f1  lea r14, [rax+0x80]
00007b4681bd68f8  movups xmm14, [r13+r14*1]
00007b4681bd68fe  movaps [r15+0x2F0], xmm14
00007b4681bd6906  vmovaps xmm9, [rsp+0x30]
00007b4681bd690c  vpermilpd xmm9, xmm9, 0x00
00007b4681bd6912  vmovaps xmm7, [rsp+0x70]
00007b4681bd6918  movaps xmm5, xmm6
00007b4681bd691b  vfmadd231pd xmm5, xmm7, xmm9
00007b4681bd6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007b4681bd6925  vptest xmm3, xmm3
00007b4681bd692a  jnz 0x00007B4681BD808F
00007b4681bd6930  vmovaps xmm9, [rsp+0x30]
00007b4681bd6936  vpermilpd xmm9, xmm9, 0x00
00007b4681bd693c  movaps xmm7, xmm13
00007b4681bd6940  vfmadd231pd xmm7, xmm1, xmm9
00007b4681bd6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007b4681bd694a  vptest xmm6, xmm6
00007b4681bd694f  jnz 0x00007B4681BD81E5
00007b4681bd6955  vmovaps xmm1, [rsp+0x20]
00007b4681bd695b  vmovaps xmm13, [rsp+0x20]
00007b4681bd6961  por xmm1, xmm13
00007b4681bd6966  movaps [r15+0x160], xmm1
00007b4681bd696e  lea r14, [rax+0x40]
00007b4681bd6972  movups xmm13, [r13+r14*1]
00007b4681bd6978  lea r14, [rax+0x50]
00007b4681bd697c  movups xmm9, [r13+r14*1]
00007b4681bd6982  movaps [r15+0x1B0], xmm13
00007b4681bd698a  movaps [r15+0x1A0], xmm9
00007b4681bd6992  movaps xmm6, [r15+0x190]
00007b4681bd699a  vmovaps xmm3, [rsp+0xB0]
00007b4681bd69a3  vpermilpd xmm3, xmm3, 0x00
00007b4681bd69a9  vmovaps [rsp+0x20], xmm1
00007b4681bd69af  movaps xmm2, xmm12
00007b4681bd69b3  vfmadd231pd xmm2, xmm6, xmm3
00007b4681bd69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007b4681bd69bd  vptest xmm1, xmm1
00007b4681bd69c2  jnz 0x00007B4681BD8350
00007b4681bd69c8  vmovaps xmm1, [rsp+0xB0]
00007b4681bd69d1  vpermilpd xmm1, xmm1, 0x00
00007b4681bd69d7  vmovaps xmm12, [rsp+0x20]
00007b4681bd69dd  movaps xmm6, xmm10
00007b4681bd69e1  vfmadd231pd xmm6, xmm12, xmm1
00007b4681bd69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007b4681bd69eb  vptest xmm3, xmm3
00007b4681bd69f0  jnz 0x00007B4681BD84A6
00007b4681bd69f6  vmovaps xmm1, [rsp+0xB0]
00007b4681bd69ff  vpermilpd xmm1, xmm1, 0x00
00007b4681bd6a05  vmovaps xmm12, [rsp+0x40]
00007b4681bd6a0b  movaps xmm10, xmm5
00007b4681bd6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007b4681bd6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007b4681bd6a1a  vptest xmm3, xmm3
00007b4681bd6a1f  jnz 0x00007B4681BD85FD
00007b4681bd6a25  vmovaps xmm1, [rsp+0xB0]
00007b4681bd6a2e  vpermilpd xmm1, xmm1, 0x00
00007b4681bd6a34  movaps xmm12, xmm7
00007b4681bd6a38  vfmadd231pd xmm12, xmm15, xmm1
00007b4681bd6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007b4681bd6a43  vptest xmm5, xmm5
00007b4681bd6a48  jnz 0x00007B4681BD8755
00007b4681bd6a4e  lea r14, [rax+0x60]
00007b4681bd6a52  movups xmm1, [r13+r14*1]
00007b4681bd6a58  lea r14, [rax+0x70]
00007b4681bd6a5c  movups xmm15, [r13+r14*1]
00007b4681bd6a62  movaps [r15+0x150], xmm1
00007b4681bd6a6a  movaps [r15+0x120], xmm15
00007b4681bd6a72  vmovaps [rsp+0x20], xmm11
00007b4681bd6a78  vpermilpd xmm11, xmm11, 0x00
00007b4681bd6a7e  movaps xmm7, xmm2
00007b4681bd6a81  vfmadd231pd xmm7, xmm9, xmm11
00007b4681bd6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007b4681bd6a8b  vptest xmm5, xmm5
00007b4681bd6a90  jnz 0x00007B4681BD88C1
00007b4681bd6a96  vmovaps xmm11, [rsp+0x20]
00007b4681bd6a9c  vpermilpd xmm11, xmm11, 0x00
00007b4681bd6aa2  movaps xmm9, xmm6
00007b4681bd6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007b4681bd6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007b4681bd6ab1  vptest xmm5, xmm5
00007b4681bd6ab6  jnz 0x00007B4681BD8A18
00007b4681bd6abc  vmovaps xmm1, [rsp+0x20]
00007b4681bd6ac2  vpermilpd xmm1, xmm1, 0x00
00007b4681bd6ac8  movaps xmm11, xmm10
00007b4681bd6acc  vfmadd231pd xmm11, xmm8, xmm1
00007b4681bd6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007b4681bd6ad7  vptest xmm6, xmm6
00007b4681bd6adc  jnz 0x00007B4681BD8B70
00007b4681bd6ae2  vmovaps xmm1, [rsp+0x20]
00007b4681bd6ae8  vpermilpd xmm1, xmm1, 0x00
00007b4681bd6aee  movaps xmm10, xmm12
00007b4681bd6af2  vfmadd231pd xmm10, xmm13, xmm1
00007b4681bd6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007b4681bd6afd  vptest xmm8, xmm8
00007b4681bd6b02  jnz 0x00007B4681BD8CC9
00007b4681bd6b08  lea r14, [rax+0x20]
00007b4681bd6b0c  movups xmm1, [r13+r14*1]
00007b4681bd6b12  lea r14, [rax+0x30]
00007b4681bd6b16  movups xmm13, [r13+r14*1]
00007b4681bd6b1c  vmovaps xmm12, [rsp+0x90]
00007b4681bd6b25  vpermilpd xmm12, xmm12, 0x00
00007b4681bd6b2b  movaps xmm8, xmm7
00007b4681bd6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007b4681bd6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007b4681bd6b3a  vptest xmm6, xmm6
00007b4681bd6b3f  jnz 0x00007B4681BD8E36
00007b4681bd6b45  vmovaps xmm12, [rsp+0x90]
00007b4681bd6b4e  vpermilpd xmm12, xmm12, 0x00
00007b4681bd6b54  movaps xmm7, xmm9
00007b4681bd6b58  vfmadd231pd xmm7, xmm14, xmm12
00007b4681bd6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007b4681bd6b62  vptest xmm6, xmm6
00007b4681bd6b67  jnz 0x00007B4681BD8F8E
00007b4681bd6b6d  vmovaps xmm14, [rsp+0x90]
00007b4681bd6b76  vpermilpd xmm14, xmm14, 0x00
00007b4681bd6b7c  movaps xmm12, xmm11
00007b4681bd6b80  vfmadd231pd xmm12, xmm15, xmm14
00007b4681bd6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007b4681bd6b8b  vptest xmm9, xmm9
00007b4681bd6b90  jnz 0x00007B4681BD90E6
00007b4681bd6b96  vmovaps xmm15, [rsp+0x90]
00007b4681bd6b9f  vpermilpd xmm15, xmm15, 0x00
00007b4681bd6ba5  movaps xmm11, xmm10
00007b4681bd6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007b4681bd6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007b4681bd6bb4  vptest xmm14, xmm14
00007b4681bd6bb9  jnz 0x00007B4681BD9240
00007b4681bd6bbf  lea r14, [rax+0x90]
00007b4681bd6bc6  movups xmm15, [r13+r14*1]
00007b4681bd6bcc  lea r14, [rax+0xA0]
00007b4681bd6bd3  movups xmm14, [r13+r14*1]
00007b4681bd6bd9  movaps [r15+0x140], xmm15
00007b4681bd6be1  movaps [r15+0x130], xmm14
00007b4681bd6be9  vmovaps xmm13, [rsp+0x10]
00007b4681bd6bef  vpermilpd xmm13, xmm13, 0x00
00007b4681bd6bf5  movaps xmm10, xmm8
00007b4681bd6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007b4681bd6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007b4681bd6c04  vptest xmm9, xmm9
00007b4681bd6c09  jnz 0x00007B4681BD93AE
00007b4681bd6c0f  movaps [r15+0x220], xmm10
00007b4681bd6c17  lea r14, [rax+0x10]
00007b4681bd6c1b  movups xmm1, [r13+r14*1]
00007b4681bd6c21  movaps [r15+0x240], xmm1
00007b4681bd6c29  vmovaps xmm13, [rsp+0x10]
00007b4681bd6c2f  vpermilpd xmm13, xmm13, 0x00
00007b4681bd6c35  movaps xmm9, xmm7
00007b4681bd6c39  vfmadd231pd xmm9, xmm14, xmm13
00007b4681bd6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007b4681bd6c44  vptest xmm8, xmm8
00007b4681bd6c49  jnz 0x00007B4681BD9511
00007b4681bd6c4f  movaps [r15+0x110], xmm9
00007b4681bd6c57  vmovaps xmm14, [rsp+0x10]
00007b4681bd6c5d  vpermilpd xmm14, xmm14, 0x00
00007b4681bd6c63  movaps xmm13, xmm12
00007b4681bd6c67  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007b4681bd6c72  vptest xmm8, xmm8
00007b4681bd6c77  jnz 0x00007B4681BD966A
00007b4681bd6c7d  movaps [r15+0x170], xmm13
00007b4681bd6c85  vmovaps xmm15, [rsp+0x10]
00007b4681bd6c8b  vpermilpd xmm15, xmm15, 0x00
00007b4681bd6c91  movaps xmm14, xmm11
00007b4681bd6c95  vfmadd231pd xmm14, xmm1, xmm15
00007b4681bd6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007b4681bd6ca0  vptest xmm12, xmm12
00007b4681bd6ca5  jnz 0x00007B4681BD97C4
00007b4681bd6cab  movaps [r15+0x230], xmm14
00007b4681bd6cb3  movups [r13+r11*1], xmm9
00007b4681bd6cb9  lea rax, [r11+0x10]
00007b4681bd6cbd  movups [r13+rax*1], xmm13
00007b4681bd6cc3  lea rax, [r11+0x20]
00007b4681bd6cc7  movups [r13+rax*1], xmm10
00007b4681bd6ccd  lea rax, [r11+0x30]
00007b4681bd6cd1  movups [r13+rax*1], xmm14
00007b4681bd6cd7  mov eax, [r15+0x108]
00007b4681bd6cde  sahf
00007b4681bd6cdf  jnz 0x00007B4681BD6D11
00007b4681bd6ce1  cmp dword ptr [r15+0x318], 0x00
00007b4681bd6ce9  jz 0x00007B4681BD9950
00007b4681bd6cef  nop [rax+rax*1], ax
00007b4681bd6cf8  nop [rax+rax*1], eax
00007b4681bd6d00  mov eax, 0x410664
00007b4681bd6d05  mov [r15+0x100], rax
00007b4681bd6d0c  jmp 0x00007B46819FE110
00007b4681bd6d11  cmp dword ptr [r15+0x318], 0x00
00007b4681bd6d19  jz 0x00007B4681BD6050
00007b4681bd6d1f  nop [rax+rax*1], ax
00007b4681bd6d28  nop [rax+rax*1], eax
00007b4681bd6d30  mov eax, 0x4104F0
00007b4681bd6d35  mov [r15+0x100], rax
00007b4681bd6d3c  jmp 0x00007B46819FE110
00007b4681bd6d41  int3
00007b4681bd6d42  call 0x00007B4681A0A4B0
00007b4681bd6d47  jmp 0x00007B4681BD6079
00007b4681bd6d4c  call 0x00007B4681A09240
00007b4681bd6d51  jmp 0x00007B4681BD6083
00007b4681bd6d56  call 0x00007B4681A0A4B0
00007b4681bd6d5b  jmp 0x00007B4681BD60CD
00007b4681bd6d60  call 0x00007B4681A09240
00007b4681bd6d65  jmp 0x00007B4681BD60D7
00007b4681bd6d6a  call 0x00007B4681A0A4B0
00007b4681bd6d6f  jmp 0x00007B4681BD6158
00007b4681bd6d74  call 0x00007B4681A09240
00007b4681bd6d79  jmp 0x00007B4681BD6162
00007b4681bd6d7e  call 0x00007B4681AB47C0
00007b4681bd6d83  jmp 0x00007B4681BD6243
00007b4681bd6d88  call 0x00007B46819FF430
00007b4681bd6d8d  jmp 0x00007B4681BD6272
00007b4681bd6d92  call 0x00007B4681AB0CE0
00007b4681bd6d97  jmp 0x00007B4681BD628E
00007b4681bd6d9c  sub rsp, 0x08
00007b4681bd6da0  push rax
00007b4681bd6da1  push rcx
00007b4681bd6da2  push rdx
00007b4681bd6da3  push rdi
00007b4681bd6da4  push rsi
00007b4681bd6da5  push r8
00007b4681bd6da7  push r9
00007b4681bd6da9  push r10
00007b4681bd6dab  push r11
00007b4681bd6dad  sub rsp, 0xF0
00007b4681bd6db4  vmovaps [rsp], xmm0
00007b4681bd6db9  vmovaps [rsp+0x10], xmm1
00007b4681bd6dbf  vmovaps [rsp+0x20], xmm2
00007b4681bd6dc5  vmovaps [rsp+0x30], xmm3
00007b4681bd6dcb  vmovaps [rsp+0x40], xmm4
00007b4681bd6dd1  vmovaps [rsp+0x50], xmm5
00007b4681bd6dd7  vmovaps [rsp+0x60], xmm6
00007b4681bd6ddd  vmovaps [rsp+0x70], xmm7
00007b4681bd6de3  vmovaps [rsp+0x80], xmm8
00007b4681bd6dec  vmovaps [rsp+0x90], xmm9
00007b4681bd6df5  vmovaps [rsp+0xA0], xmm10
00007b4681bd6dfe  vmovaps [rsp+0xB0], xmm11
00007b4681bd6e07  vmovaps [rsp+0xC0], xmm12
00007b4681bd6e10  vmovaps [rsp+0xD0], xmm14
00007b4681bd6e19  vmovaps [rsp+0xE0], xmm15
00007b4681bd6e22  sub rsp, 0x40
00007b4681bd6e26  lea rdi, [rsp]
00007b4681bd6e2a  lea rsi, [rsp+0x10]
00007b4681bd6e2f  lea rdx, [rsp+0x20]
00007b4681bd6e34  lea rcx, [rsp+0x30]
00007b4681bd6e39  mov r8d, 0x00
00007b4681bd6e3f  lea r9, [r15+0x3A8]
00007b4681bd6e46  movaps [rdi], xmm13
00007b4681bd6e4a  movaps [rsi], xmm1
00007b4681bd6e4d  movaps [rdx], xmm15
00007b4681bd6e51  movaps [rcx], xmm14
00007b4681bd6e55  mov rax, 0x5668589B5A50
00007b4681bd6e5f  call rax
00007b4681bd6e61  movaps xmm13, [rsp]
00007b4681bd6e66  add rsp, 0x40
00007b4681bd6e6a  vmovaps xmm0, [rsp]
00007b4681bd6e6f  vmovaps xmm1, [rsp+0x10]
00007b4681bd6e75  vmovaps xmm2, [rsp+0x20]
00007b4681bd6e7b  vmovaps xmm3, [rsp+0x30]
00007b4681bd6e81  vmovaps xmm4, [rsp+0x40]
00007b4681bd6e87  vmovaps xmm5, [rsp+0x50]
00007b4681bd6e8d  vmovaps xmm6, [rsp+0x60]
00007b4681bd6e93  vmovaps xmm7, [rsp+0x70]
00007b4681bd6e99  vmovaps xmm8, [rsp+0x80]
00007b4681bd6ea2  vmovaps xmm9, [rsp+0x90]
00007b4681bd6eab  vmovaps xmm10, [rsp+0xA0]
00007b4681bd6eb4  vmovaps xmm11, [rsp+0xB0]
00007b4681bd6ebd  vmovaps xmm12, [rsp+0xC0]
00007b4681bd6ec6  vmovaps xmm14, [rsp+0xD0]
00007b4681bd6ecf  vmovaps xmm15, [rsp+0xE0]
00007b4681bd6ed8  add rsp, 0xF0
00007b4681bd6edf  pop r11
00007b4681bd6ee1  pop r10
00007b4681bd6ee3  pop r9
00007b4681bd6ee5  pop r8
00007b4681bd6ee7  pop rsi
00007b4681bd6ee8  pop rdi
00007b4681bd6ee9  pop rdx
00007b4681bd6eea  pop rcx
00007b4681bd6eeb  pop rax
00007b4681bd6eec  add rsp, 0x08
00007b4681bd6ef0  jmp 0x00007B4681BD6305
00007b4681bd6ef5  sub rsp, 0x08
00007b4681bd6ef9  push rax
00007b4681bd6efa  push rcx
00007b4681bd6efb  push rdx
00007b4681bd6efc  push rdi
00007b4681bd6efd  push rsi
00007b4681bd6efe  push r8
00007b4681bd6f00  push r9
00007b4681bd6f02  push r10
00007b4681bd6f04  push r11
00007b4681bd6f06  sub rsp, 0xF0
00007b4681bd6f0d  vmovaps [rsp], xmm0
00007b4681bd6f12  vmovaps [rsp+0x10], xmm1
00007b4681bd6f18  vmovaps [rsp+0x20], xmm2
00007b4681bd6f1e  vmovaps [rsp+0x30], xmm3
00007b4681bd6f24  vmovaps [rsp+0x40], xmm4
00007b4681bd6f2a  vmovaps [rsp+0x50], xmm5
00007b4681bd6f30  vmovaps [rsp+0x60], xmm6
00007b4681bd6f36  vmovaps [rsp+0x70], xmm7
00007b4681bd6f3c  vmovaps [rsp+0x80], xmm8
00007b4681bd6f45  vmovaps [rsp+0x90], xmm9
00007b4681bd6f4e  vmovaps [rsp+0xA0], xmm10
00007b4681bd6f57  vmovaps [rsp+0xB0], xmm11
00007b4681bd6f60  vmovaps [rsp+0xC0], xmm13
00007b4681bd6f69  vmovaps [rsp+0xD0], xmm14
00007b4681bd6f72  vmovaps [rsp+0xE0], xmm15
00007b4681bd6f7b  sub rsp, 0x40
00007b4681bd6f7f  lea rdi, [rsp]
00007b4681bd6f83  lea rsi, [rsp+0x10]
00007b4681bd6f88  lea rdx, [rsp+0x20]
00007b4681bd6f8d  lea rcx, [rsp+0x30]
00007b4681bd6f92  mov r8d, 0x00
00007b4681bd6f98  lea r9, [r15+0x3A8]
00007b4681bd6f9f  movaps [rdi], xmm12
00007b4681bd6fa3  movaps [rsi], xmm15
00007b4681bd6fa7  movaps [rdx], xmm1
00007b4681bd6faa  movaps [rcx], xmm14
00007b4681bd6fae  mov rax, 0x5668589B5A50
00007b4681bd6fb8  call rax
00007b4681bd6fba  movaps xmm12, [rsp]
00007b4681bd6fbf  add rsp, 0x40
00007b4681bd6fc3  vmovaps xmm0, [rsp]
00007b4681bd6fc8  vmovaps xmm1, [rsp+0x10]
00007b4681bd6fce  vmovaps xmm2, [rsp+0x20]
00007b4681bd6fd4  vmovaps xmm3, [rsp+0x30]
00007b4681bd6fda  vmovaps xmm4, [rsp+0x40]
00007b4681bd6fe0  vmovaps xmm5, [rsp+0x50]
00007b4681bd6fe6  vmovaps xmm6, [rsp+0x60]
00007b4681bd6fec  vmovaps xmm7, [rsp+0x70]
00007b4681bd6ff2  vmovaps xmm8, [rsp+0x80]
00007b4681bd6ffb  vmovaps xmm9, [rsp+0x90]
00007b4681bd7004  vmovaps xmm10, [rsp+0xA0]
00007b4681bd700d  vmovaps xmm11, [rsp+0xB0]
00007b4681bd7016  vmovaps xmm13, [rsp+0xC0]
00007b4681bd701f  vmovaps xmm14, [rsp+0xD0]
00007b4681bd7028  vmovaps xmm15, [rsp+0xE0]
00007b4681bd7031  add rsp, 0xF0
00007b4681bd7038  pop r11
00007b4681bd703a  pop r10
00007b4681bd703c  pop r9
00007b4681bd703e  pop r8
00007b4681bd7040  pop rsi
00007b4681bd7041  pop rdi
00007b4681bd7042  pop rdx
00007b4681bd7043  pop rcx
00007b4681bd7044  pop rax
00007b4681bd7045  add rsp, 0x08
00007b4681bd7049  jmp 0x00007B4681BD6333
00007b4681bd704e  call 0x00007B4681AD64F0
00007b4681bd7053  jmp 0x00007B4681BD641F
00007b4681bd7058  sub rsp, 0x08
00007b4681bd705c  push rax
00007b4681bd705d  push rcx
00007b4681bd705e  push rdx
00007b4681bd705f  push rdi
00007b4681bd7060  push rsi
00007b4681bd7061  push r8
00007b4681bd7063  push r9
00007b4681bd7065  push r10
00007b4681bd7067  push r11
00007b4681bd7069  sub rsp, 0xF0
00007b4681bd7070  vmovaps [rsp], xmm0
00007b4681bd7075  vmovaps [rsp+0x10], xmm1
00007b4681bd707b  vmovaps [rsp+0x20], xmm2
00007b4681bd7081  vmovaps [rsp+0x30], xmm3
00007b4681bd7087  vmovaps [rsp+0x40], xmm4
00007b4681bd708d  vmovaps [rsp+0x50], xmm5
00007b4681bd7093  vmovaps [rsp+0x60], xmm6
00007b4681bd7099  vmovaps [rsp+0x70], xmm7
00007b4681bd709f  vmovaps [rsp+0x80], xmm8
00007b4681bd70a8  vmovaps [rsp+0x90], xmm9
00007b4681bd70b1  vmovaps [rsp+0xA0], xmm10
00007b4681bd70ba  vmovaps [rsp+0xB0], xmm11
00007b4681bd70c3  vmovaps [rsp+0xC0], xmm12
00007b4681bd70cc  vmovaps [rsp+0xD0], xmm14
00007b4681bd70d5  vmovaps [rsp+0xE0], xmm15
00007b4681bd70de  sub rsp, 0x40
00007b4681bd70e2  lea rdi, [rsp]
00007b4681bd70e6  lea rsi, [rsp+0x10]
00007b4681bd70eb  lea rdx, [rsp+0x20]
00007b4681bd70f0  lea rcx, [rsp+0x30]
00007b4681bd70f5  mov r8d, 0x00
00007b4681bd70fb  lea r9, [r15+0x3A8]
00007b4681bd7102  movaps [rdi], xmm13
00007b4681bd7106  movaps [rsi], xmm1
00007b4681bd7109  movaps [rdx], xmm15
00007b4681bd710d  movaps [rcx], xmm14
00007b4681bd7111  mov rax, 0x5668589B5A50
00007b4681bd711b  call rax
00007b4681bd711d  movaps xmm13, [rsp]
00007b4681bd7122  add rsp, 0x40
00007b4681bd7126  vmovaps xmm0, [rsp]
00007b4681bd712b  vmovaps xmm1, [rsp+0x10]
00007b4681bd7131  vmovaps xmm2, [rsp+0x20]
00007b4681bd7137  vmovaps xmm3, [rsp+0x30]
00007b4681bd713d  vmovaps xmm4, [rsp+0x40]
00007b4681bd7143  vmovaps xmm5, [rsp+0x50]
00007b4681bd7149  vmovaps xmm6, [rsp+0x60]
00007b4681bd714f  vmovaps xmm7, [rsp+0x70]
00007b4681bd7155  vmovaps xmm8, [rsp+0x80]
00007b4681bd715e  vmovaps xmm9, [rsp+0x90]
00007b4681bd7167  vmovaps xmm10, [rsp+0xA0]
00007b4681bd7170  vmovaps xmm11, [rsp+0xB0]
00007b4681bd7179  vmovaps xmm12, [rsp+0xC0]
00007b4681bd7182  vmovaps xmm14, [rsp+0xD0]
00007b4681bd718b  vmovaps xmm15, [rsp+0xE0]
00007b4681bd7194  add rsp, 0xF0
00007b4681bd719b  pop r11
00007b4681bd719d  pop r10
00007b4681bd719f  pop r9
00007b4681bd71a1  pop r8
00007b4681bd71a3  pop rsi
00007b4681bd71a4  pop rdi
00007b4681bd71a5  pop rdx
00007b4681bd71a6  pop rcx
00007b4681bd71a7  pop rax
00007b4681bd71a8  add rsp, 0x08
00007b4681bd71ac  jmp 0x00007B4681BD648E
00007b4681bd71b1  call 0x00007B4681AD64F0
00007b4681bd71b6  jmp 0x00007B4681BD64A3
00007b4681bd71bb  sub rsp, 0x08
00007b4681bd71bf  push rax
00007b4681bd71c0  push rcx
00007b4681bd71c1  push rdx
00007b4681bd71c2  push rdi
00007b4681bd71c3  push rsi
00007b4681bd71c4  push r8
00007b4681bd71c6  push r9
00007b4681bd71c8  push r10
00007b4681bd71ca  push r11
00007b4681bd71cc  sub rsp, 0xF0
00007b4681bd71d3  vmovaps [rsp], xmm0
00007b4681bd71d8  vmovaps [rsp+0x10], xmm1
00007b4681bd71de  vmovaps [rsp+0x20], xmm2
00007b4681bd71e4  vmovaps [rsp+0x30], xmm3
00007b4681bd71ea  vmovaps [rsp+0x40], xmm4
00007b4681bd71f0  vmovaps [rsp+0x50], xmm5
00007b4681bd71f6  vmovaps [rsp+0x60], xmm6
00007b4681bd71fc  vmovaps [rsp+0x70], xmm7
00007b4681bd7202  vmovaps [rsp+0x80], xmm8
00007b4681bd720b  vmovaps [rsp+0x90], xmm9
00007b4681bd7214  vmovaps [rsp+0xA0], xmm10
00007b4681bd721d  vmovaps [rsp+0xB0], xmm11
00007b4681bd7226  vmovaps [rsp+0xC0], xmm13
00007b4681bd722f  vmovaps [rsp+0xD0], xmm14
00007b4681bd7238  vmovaps [rsp+0xE0], xmm15
00007b4681bd7241  sub rsp, 0x40
00007b4681bd7245  lea rdi, [rsp]
00007b4681bd7249  lea rsi, [rsp+0x10]
00007b4681bd724e  lea rdx, [rsp+0x20]
00007b4681bd7253  lea rcx, [rsp+0x30]
00007b4681bd7258  mov r8d, 0x00
00007b4681bd725e  lea r9, [r15+0x3A8]
00007b4681bd7265  movaps [rdi], xmm12
00007b4681bd7269  movaps [rsi], xmm15
00007b4681bd726d  movaps [rdx], xmm1
00007b4681bd7270  movaps [rcx], xmm14
00007b4681bd7274  mov rax, 0x5668589B5A50
00007b4681bd727e  call rax
00007b4681bd7280  movaps xmm12, [rsp]
00007b4681bd7285  add rsp, 0x40
00007b4681bd7289  vmovaps xmm0, [rsp]
00007b4681bd728e  vmovaps xmm1, [rsp+0x10]
00007b4681bd7294  vmovaps xmm2, [rsp+0x20]
00007b4681bd729a  vmovaps xmm3, [rsp+0x30]
00007b4681bd72a0  vmovaps xmm4, [rsp+0x40]
00007b4681bd72a6  vmovaps xmm5, [rsp+0x50]
00007b4681bd72ac  vmovaps xmm6, [rsp+0x60]
00007b4681bd72b2  vmovaps xmm7, [rsp+0x70]
00007b4681bd72b8  vmovaps xmm8, [rsp+0x80]
00007b4681bd72c1  vmovaps xmm9, [rsp+0x90]
00007b4681bd72ca  vmovaps xmm10, [rsp+0xA0]
00007b4681bd72d3  vmovaps xmm11, [rsp+0xB0]
00007b4681bd72dc  vmovaps xmm13, [rsp+0xC0]
00007b4681bd72e5  vmovaps xmm14, [rsp+0xD0]
00007b4681bd72ee  vmovaps xmm15, [rsp+0xE0]
00007b4681bd72f7  add rsp, 0xF0
00007b4681bd72fe  pop r11
00007b4681bd7300  pop r10
00007b4681bd7302  pop r9
00007b4681bd7304  pop r8
00007b4681bd7306  pop rsi
00007b4681bd7307  pop rdi
00007b4681bd7308  pop rdx
00007b4681bd7309  pop rcx
00007b4681bd730a  pop rax
00007b4681bd730b  add rsp, 0x08
00007b4681bd730f  jmp 0x00007B4681BD64CF
00007b4681bd7314  sub rsp, 0x08
00007b4681bd7318  push rax
00007b4681bd7319  push rcx
00007b4681bd731a  push rdx
00007b4681bd731b  push rdi
00007b4681bd731c  push rsi
00007b4681bd731d  push r8
00007b4681bd731f  push r9
00007b4681bd7321  push r10
00007b4681bd7323  push r11
00007b4681bd7325  sub rsp, 0xF0
00007b4681bd732c  vmovaps [rsp], xmm0
00007b4681bd7331  vmovaps [rsp+0x10], xmm1
00007b4681bd7337  vmovaps [rsp+0x20], xmm2
00007b4681bd733d  vmovaps [rsp+0x30], xmm3
00007b4681bd7343  vmovaps [rsp+0x40], xmm4
00007b4681bd7349  vmovaps [rsp+0x50], xmm5
00007b4681bd734f  vmovaps [rsp+0x60], xmm6
00007b4681bd7355  vmovaps [rsp+0x70], xmm7
00007b4681bd735b  vmovaps [rsp+0x80], xmm8
00007b4681bd7364  vmovaps [rsp+0x90], xmm9
00007b4681bd736d  vmovaps [rsp+0xA0], xmm10
00007b4681bd7376  vmovaps [rsp+0xB0], xmm11
00007b4681bd737f  vmovaps [rsp+0xC0], xmm12
00007b4681bd7388  vmovaps [rsp+0xD0], xmm14
00007b4681bd7391  vmovaps [rsp+0xE0], xmm15
00007b4681bd739a  sub rsp, 0x40
00007b4681bd739e  lea rdi, [rsp]
00007b4681bd73a2  lea rsi, [rsp+0x10]
00007b4681bd73a7  lea rdx, [rsp+0x20]
00007b4681bd73ac  lea rcx, [rsp+0x30]
00007b4681bd73b1  mov r8d, 0x00
00007b4681bd73b7  lea r9, [r15+0x3A8]
00007b4681bd73be  movaps [rdi], xmm13
00007b4681bd73c2  movaps [rsi], xmm1
00007b4681bd73c5  movaps [rdx], xmm15
00007b4681bd73c9  movaps [rcx], xmm14
00007b4681bd73cd  mov rax, 0x5668589B5A50
00007b4681bd73d7  call rax
00007b4681bd73d9  movaps xmm13, [rsp]
00007b4681bd73de  add rsp, 0x40
00007b4681bd73e2  vmovaps xmm0, [rsp]
00007b4681bd73e7  vmovaps xmm1, [rsp+0x10]
00007b4681bd73ed  vmovaps xmm2, [rsp+0x20]
00007b4681bd73f3  vmovaps xmm3, [rsp+0x30]
00007b4681bd73f9  vmovaps xmm4, [rsp+0x40]
00007b4681bd73ff  vmovaps xmm5, [rsp+0x50]
00007b4681bd7405  vmovaps xmm6, [rsp+0x60]
00007b4681bd740b  vmovaps xmm7, [rsp+0x70]
00007b4681bd7411  vmovaps xmm8, [rsp+0x80]
00007b4681bd741a  vmovaps xmm9, [rsp+0x90]
00007b4681bd7423  vmovaps xmm10, [rsp+0xA0]
00007b4681bd742c  vmovaps xmm11, [rsp+0xB0]
00007b4681bd7435  vmovaps xmm12, [rsp+0xC0]
00007b4681bd743e  vmovaps xmm14, [rsp+0xD0]
00007b4681bd7447  vmovaps xmm15, [rsp+0xE0]
00007b4681bd7450  add rsp, 0xF0
00007b4681bd7457  pop r11
00007b4681bd7459  pop r10
00007b4681bd745b  pop r9
00007b4681bd745d  pop r8
00007b4681bd745f  pop rsi
00007b4681bd7460  pop rdi
00007b4681bd7461  pop rdx
00007b4681bd7462  pop rcx
00007b4681bd7463  pop rax
00007b4681bd7464  add rsp, 0x08
00007b4681bd7468  jmp 0x00007B4681BD665F
00007b4681bd746d  sub rsp, 0x08
00007b4681bd7471  push rax
00007b4681bd7472  push rcx
00007b4681bd7473  push rdx
00007b4681bd7474  push rdi
00007b4681bd7475  push rsi
00007b4681bd7476  push r8
00007b4681bd7478  push r9
00007b4681bd747a  push r10
00007b4681bd747c  push r11
00007b4681bd747e  sub rsp, 0xF0
00007b4681bd7485  vmovaps [rsp], xmm0
00007b4681bd748a  vmovaps [rsp+0x10], xmm1
00007b4681bd7490  vmovaps [rsp+0x20], xmm2
00007b4681bd7496  vmovaps [rsp+0x30], xmm3
00007b4681bd749c  vmovaps [rsp+0x40], xmm4
00007b4681bd74a2  vmovaps [rsp+0x50], xmm5
00007b4681bd74a8  vmovaps [rsp+0x60], xmm6
00007b4681bd74ae  vmovaps [rsp+0x70], xmm7
00007b4681bd74b4  vmovaps [rsp+0x80], xmm8
00007b4681bd74bd  vmovaps [rsp+0x90], xmm9
00007b4681bd74c6  vmovaps [rsp+0xA0], xmm10
00007b4681bd74cf  vmovaps [rsp+0xB0], xmm11
00007b4681bd74d8  vmovaps [rsp+0xC0], xmm12
00007b4681bd74e1  vmovaps [rsp+0xD0], xmm13
00007b4681bd74ea  vmovaps [rsp+0xE0], xmm15
00007b4681bd74f3  sub rsp, 0x40
00007b4681bd74f7  lea rdi, [rsp]
00007b4681bd74fb  lea rsi, [rsp+0x10]
00007b4681bd7500  lea rdx, [rsp+0x20]
00007b4681bd7505  lea rcx, [rsp+0x30]
00007b4681bd750a  mov r8d, 0x00
00007b4681bd7510  lea r9, [r15+0x3A8]
00007b4681bd7517  movaps [rdi], xmm14
00007b4681bd751b  movaps [rsi], xmm15
00007b4681bd751f  movaps [rdx], xmm2
00007b4681bd7522  movaps [rcx], xmm1
00007b4681bd7525  mov rax, 0x5668589B5A50
00007b4681bd752f  call rax
00007b4681bd7531  movaps xmm14, [rsp]
00007b4681bd7536  add rsp, 0x40
00007b4681bd753a  vmovaps xmm0, [rsp]
00007b4681bd753f  vmovaps xmm1, [rsp+0x10]
00007b4681bd7545  vmovaps xmm2, [rsp+0x20]
00007b4681bd754b  vmovaps xmm3, [rsp+0x30]
00007b4681bd7551  vmovaps xmm4, [rsp+0x40]
00007b4681bd7557  vmovaps xmm5, [rsp+0x50]
00007b4681bd755d  vmovaps xmm6, [rsp+0x60]
00007b4681bd7563  vmovaps xmm7, [rsp+0x70]
00007b4681bd7569  vmovaps xmm8, [rsp+0x80]
00007b4681bd7572  vmovaps xmm9, [rsp+0x90]
00007b4681bd757b  vmovaps xmm10, [rsp+0xA0]
00007b4681bd7584  vmovaps xmm11, [rsp+0xB0]
00007b4681bd758d  vmovaps xmm12, [rsp+0xC0]
00007b4681bd7596  vmovaps xmm13, [rsp+0xD0]
00007b4681bd759f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd75a8  add rsp, 0xF0
00007b4681bd75af  pop r11
00007b4681bd75b1  pop r10
00007b4681bd75b3  pop r9
00007b4681bd75b5  pop r8
00007b4681bd75b7  pop rsi
00007b4681bd75b8  pop rdi
00007b4681bd75b9  pop rdx
00007b4681bd75ba  pop rcx
00007b4681bd75bb  pop rax
00007b4681bd75bc  add rsp, 0x08
00007b4681bd75c0  jmp 0x00007B4681BD6691
00007b4681bd75c5  sub rsp, 0x08
00007b4681bd75c9  push rax
00007b4681bd75ca  push rcx
00007b4681bd75cb  push rdx
00007b4681bd75cc  push rdi
00007b4681bd75cd  push rsi
00007b4681bd75ce  push r8
00007b4681bd75d0  push r9
00007b4681bd75d2  push r10
00007b4681bd75d4  push r11
00007b4681bd75d6  sub rsp, 0xF0
00007b4681bd75dd  vmovaps [rsp], xmm0
00007b4681bd75e2  vmovaps [rsp+0x10], xmm1
00007b4681bd75e8  vmovaps [rsp+0x20], xmm3
00007b4681bd75ee  vmovaps [rsp+0x30], xmm4
00007b4681bd75f4  vmovaps [rsp+0x40], xmm5
00007b4681bd75fa  vmovaps [rsp+0x50], xmm6
00007b4681bd7600  vmovaps [rsp+0x60], xmm7
00007b4681bd7606  vmovaps [rsp+0x70], xmm8
00007b4681bd760c  vmovaps [rsp+0x80], xmm9
00007b4681bd7615  vmovaps [rsp+0x90], xmm10
00007b4681bd761e  vmovaps [rsp+0xA0], xmm11
00007b4681bd7627  vmovaps [rsp+0xB0], xmm12
00007b4681bd7630  vmovaps [rsp+0xC0], xmm13
00007b4681bd7639  vmovaps [rsp+0xD0], xmm14
00007b4681bd7642  vmovaps [rsp+0xE0], xmm15
00007b4681bd764b  sub rsp, 0x40
00007b4681bd764f  lea rdi, [rsp]
00007b4681bd7653  lea rsi, [rsp+0x10]
00007b4681bd7658  lea rdx, [rsp+0x20]
00007b4681bd765d  lea rcx, [rsp+0x30]
00007b4681bd7662  mov r8d, 0x00
00007b4681bd7668  lea r9, [r15+0x3A8]
00007b4681bd766f  movaps [rdi], xmm2
00007b4681bd7672  movaps [rsi], xmm15
00007b4681bd7676  movaps [rdx], xmm12
00007b4681bd767a  movaps [rcx], xmm1
00007b4681bd767d  mov rax, 0x5668589B5A50
00007b4681bd7687  call rax
00007b4681bd7689  movaps xmm2, [rsp]
00007b4681bd768d  add rsp, 0x40
00007b4681bd7691  vmovaps xmm0, [rsp]
00007b4681bd7696  vmovaps xmm1, [rsp+0x10]
00007b4681bd769c  vmovaps xmm3, [rsp+0x20]
00007b4681bd76a2  vmovaps xmm4, [rsp+0x30]
00007b4681bd76a8  vmovaps xmm5, [rsp+0x40]
00007b4681bd76ae  vmovaps xmm6, [rsp+0x50]
00007b4681bd76b4  vmovaps xmm7, [rsp+0x60]
00007b4681bd76ba  vmovaps xmm8, [rsp+0x70]
00007b4681bd76c0  vmovaps xmm9, [rsp+0x80]
00007b4681bd76c9  vmovaps xmm10, [rsp+0x90]
00007b4681bd76d2  vmovaps xmm11, [rsp+0xA0]
00007b4681bd76db  vmovaps xmm12, [rsp+0xB0]
00007b4681bd76e4  vmovaps xmm13, [rsp+0xC0]
00007b4681bd76ed  vmovaps xmm14, [rsp+0xD0]
00007b4681bd76f6  vmovaps xmm15, [rsp+0xE0]
00007b4681bd76ff  add rsp, 0xF0
00007b4681bd7706  pop r11
00007b4681bd7708  pop r10
00007b4681bd770a  pop r9
00007b4681bd770c  pop r8
00007b4681bd770e  pop rsi
00007b4681bd770f  pop rdi
00007b4681bd7710  pop rdx
00007b4681bd7711  pop rcx
00007b4681bd7712  pop rax
00007b4681bd7713  add rsp, 0x08
00007b4681bd7717  jmp 0x00007B4681BD66CE
00007b4681bd771c  sub rsp, 0x08
00007b4681bd7720  push rax
00007b4681bd7721  push rcx
00007b4681bd7722  push rdx
00007b4681bd7723  push rdi
00007b4681bd7724  push rsi
00007b4681bd7725  push r8
00007b4681bd7727  push r9
00007b4681bd7729  push r10
00007b4681bd772b  push r11
00007b4681bd772d  sub rsp, 0xF0
00007b4681bd7734  vmovaps [rsp], xmm0
00007b4681bd7739  vmovaps [rsp+0x10], xmm1
00007b4681bd773f  vmovaps [rsp+0x20], xmm2
00007b4681bd7745  vmovaps [rsp+0x30], xmm3
00007b4681bd774b  vmovaps [rsp+0x40], xmm4
00007b4681bd7751  vmovaps [rsp+0x50], xmm5
00007b4681bd7757  vmovaps [rsp+0x60], xmm6
00007b4681bd775d  vmovaps [rsp+0x70], xmm7
00007b4681bd7763  vmovaps [rsp+0x80], xmm8
00007b4681bd776c  vmovaps [rsp+0x90], xmm9
00007b4681bd7775  vmovaps [rsp+0xA0], xmm10
00007b4681bd777e  vmovaps [rsp+0xB0], xmm11
00007b4681bd7787  vmovaps [rsp+0xC0], xmm13
00007b4681bd7790  vmovaps [rsp+0xD0], xmm14
00007b4681bd7799  vmovaps [rsp+0xE0], xmm15
00007b4681bd77a2  sub rsp, 0x40
00007b4681bd77a6  lea rdi, [rsp]
00007b4681bd77aa  lea rsi, [rsp+0x10]
00007b4681bd77af  lea rdx, [rsp+0x20]
00007b4681bd77b4  lea rcx, [rsp+0x30]
00007b4681bd77b9  mov r8d, 0x00
00007b4681bd77bf  lea r9, [r15+0x3A8]
00007b4681bd77c6  movaps [rdi], xmm12
00007b4681bd77ca  movaps [rsi], xmm14
00007b4681bd77ce  movaps [rdx], xmm3
00007b4681bd77d1  movaps [rcx], xmm15
00007b4681bd77d5  mov rax, 0x5668589B5A50
00007b4681bd77df  call rax
00007b4681bd77e1  movaps xmm12, [rsp]
00007b4681bd77e6  add rsp, 0x40
00007b4681bd77ea  vmovaps xmm0, [rsp]
00007b4681bd77ef  vmovaps xmm1, [rsp+0x10]
00007b4681bd77f5  vmovaps xmm2, [rsp+0x20]
00007b4681bd77fb  vmovaps xmm3, [rsp+0x30]
00007b4681bd7801  vmovaps xmm4, [rsp+0x40]
00007b4681bd7807  vmovaps xmm5, [rsp+0x50]
00007b4681bd780d  vmovaps xmm6, [rsp+0x60]
00007b4681bd7813  vmovaps xmm7, [rsp+0x70]
00007b4681bd7819  vmovaps xmm8, [rsp+0x80]
00007b4681bd7822  vmovaps xmm9, [rsp+0x90]
00007b4681bd782b  vmovaps xmm10, [rsp+0xA0]
00007b4681bd7834  vmovaps xmm11, [rsp+0xB0]
00007b4681bd783d  vmovaps xmm13, [rsp+0xC0]
00007b4681bd7846  vmovaps xmm14, [rsp+0xD0]
00007b4681bd784f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd7858  add rsp, 0xF0
00007b4681bd785f  pop r11
00007b4681bd7861  pop r10
00007b4681bd7863  pop r9
00007b4681bd7865  pop r8
00007b4681bd7867  pop rsi
00007b4681bd7868  pop rdi
00007b4681bd7869  pop rdx
00007b4681bd786a  pop rcx
00007b4681bd786b  pop rax
00007b4681bd786c  add rsp, 0x08
00007b4681bd7870  jmp 0x00007B4681BD6728
00007b4681bd7875  sub rsp, 0x08
00007b4681bd7879  push rax
00007b4681bd787a  push rcx
00007b4681bd787b  push rdx
00007b4681bd787c  push rdi
00007b4681bd787d  push rsi
00007b4681bd787e  push r8
00007b4681bd7880  push r9
00007b4681bd7882  push r10
00007b4681bd7884  push r11
00007b4681bd7886  sub rsp, 0xF0
00007b4681bd788d  vmovaps [rsp], xmm0
00007b4681bd7892  vmovaps [rsp+0x10], xmm1
00007b4681bd7898  vmovaps [rsp+0x20], xmm2
00007b4681bd789e  vmovaps [rsp+0x30], xmm3
00007b4681bd78a4  vmovaps [rsp+0x40], xmm4
00007b4681bd78aa  vmovaps [rsp+0x50], xmm5
00007b4681bd78b0  vmovaps [rsp+0x60], xmm6
00007b4681bd78b6  vmovaps [rsp+0x70], xmm7
00007b4681bd78bc  vmovaps [rsp+0x80], xmm8
00007b4681bd78c5  vmovaps [rsp+0x90], xmm10
00007b4681bd78ce  vmovaps [rsp+0xA0], xmm11
00007b4681bd78d7  vmovaps [rsp+0xB0], xmm12
00007b4681bd78e0  vmovaps [rsp+0xC0], xmm13
00007b4681bd78e9  vmovaps [rsp+0xD0], xmm14
00007b4681bd78f2  vmovaps [rsp+0xE0], xmm15
00007b4681bd78fb  sub rsp, 0x40
00007b4681bd78ff  lea rdi, [rsp]
00007b4681bd7903  lea rsi, [rsp+0x10]
00007b4681bd7908  lea rdx, [rsp+0x20]
00007b4681bd790d  lea rcx, [rsp+0x30]
00007b4681bd7912  mov r8d, 0x00
00007b4681bd7918  lea r9, [r15+0x3A8]
00007b4681bd791f  movaps [rdi], xmm9
00007b4681bd7923  movaps [rsi], xmm13
00007b4681bd7927  movaps [rdx], xmm14
00007b4681bd792b  movaps [rcx], xmm6
00007b4681bd792e  mov rax, 0x5668589B5A50
00007b4681bd7938  call rax
00007b4681bd793a  movaps xmm9, [rsp]
00007b4681bd793f  add rsp, 0x40
00007b4681bd7943  vmovaps xmm0, [rsp]
00007b4681bd7948  vmovaps xmm1, [rsp+0x10]
00007b4681bd794e  vmovaps xmm2, [rsp+0x20]
00007b4681bd7954  vmovaps xmm3, [rsp+0x30]
00007b4681bd795a  vmovaps xmm4, [rsp+0x40]
00007b4681bd7960  vmovaps xmm5, [rsp+0x50]
00007b4681bd7966  vmovaps xmm6, [rsp+0x60]
00007b4681bd796c  vmovaps xmm7, [rsp+0x70]
00007b4681bd7972  vmovaps xmm8, [rsp+0x80]
00007b4681bd797b  vmovaps xmm10, [rsp+0x90]
00007b4681bd7984  vmovaps xmm11, [rsp+0xA0]
00007b4681bd798d  vmovaps xmm12, [rsp+0xB0]
00007b4681bd7996  vmovaps xmm13, [rsp+0xC0]
00007b4681bd799f  vmovaps xmm14, [rsp+0xD0]
00007b4681bd79a8  vmovaps xmm15, [rsp+0xE0]
00007b4681bd79b1  add rsp, 0xF0
00007b4681bd79b8  pop r11
00007b4681bd79ba  pop r10
00007b4681bd79bc  pop r9
00007b4681bd79be  pop r8
00007b4681bd79c0  pop rsi
00007b4681bd79c1  pop rdi
00007b4681bd79c2  pop rdx
00007b4681bd79c3  pop rcx
00007b4681bd79c4  pop rax
00007b4681bd79c5  add rsp, 0x08
00007b4681bd79c9  jmp 0x00007B4681BD67D2
00007b4681bd79ce  sub rsp, 0x08
00007b4681bd79d2  push rax
00007b4681bd79d3  push rcx
00007b4681bd79d4  push rdx
00007b4681bd79d5  push rdi
00007b4681bd79d6  push rsi
00007b4681bd79d7  push r8
00007b4681bd79d9  push r9
00007b4681bd79db  push r10
00007b4681bd79dd  push r11
00007b4681bd79df  sub rsp, 0xF0
00007b4681bd79e6  vmovaps [rsp], xmm0
00007b4681bd79eb  vmovaps [rsp+0x10], xmm1
00007b4681bd79f1  vmovaps [rsp+0x20], xmm2
00007b4681bd79f7  vmovaps [rsp+0x30], xmm4
00007b4681bd79fd  vmovaps [rsp+0x40], xmm5
00007b4681bd7a03  vmovaps [rsp+0x50], xmm6
00007b4681bd7a09  vmovaps [rsp+0x60], xmm7
00007b4681bd7a0f  vmovaps [rsp+0x70], xmm8
00007b4681bd7a15  vmovaps [rsp+0x80], xmm9
00007b4681bd7a1e  vmovaps [rsp+0x90], xmm10
00007b4681bd7a27  vmovaps [rsp+0xA0], xmm11
00007b4681bd7a30  vmovaps [rsp+0xB0], xmm12
00007b4681bd7a39  vmovaps [rsp+0xC0], xmm13
00007b4681bd7a42  vmovaps [rsp+0xD0], xmm14
00007b4681bd7a4b  vmovaps [rsp+0xE0], xmm15
00007b4681bd7a54  sub rsp, 0x40
00007b4681bd7a58  lea rdi, [rsp]
00007b4681bd7a5c  lea rsi, [rsp+0x10]
00007b4681bd7a61  lea rdx, [rsp+0x20]
00007b4681bd7a66  lea rcx, [rsp+0x30]
00007b4681bd7a6b  mov r8d, 0x00
00007b4681bd7a71  lea r9, [r15+0x3A8]
00007b4681bd7a78  movaps [rdi], xmm3
00007b4681bd7a7b  movaps [rsi], xmm13
00007b4681bd7a7f  movaps [rdx], xmm6
00007b4681bd7a82  movaps [rcx], xmm14
00007b4681bd7a86  mov rax, 0x5668589B5A50
00007b4681bd7a90  call rax
00007b4681bd7a92  movaps xmm3, [rsp]
00007b4681bd7a96  add rsp, 0x40
00007b4681bd7a9a  vmovaps xmm0, [rsp]
00007b4681bd7a9f  vmovaps xmm1, [rsp+0x10]
00007b4681bd7aa5  vmovaps xmm2, [rsp+0x20]
00007b4681bd7aab  vmovaps xmm4, [rsp+0x30]
00007b4681bd7ab1  vmovaps xmm5, [rsp+0x40]
00007b4681bd7ab7  vmovaps xmm6, [rsp+0x50]
00007b4681bd7abd  vmovaps xmm7, [rsp+0x60]
00007b4681bd7ac3  vmovaps xmm8, [rsp+0x70]
00007b4681bd7ac9  vmovaps xmm9, [rsp+0x80]
00007b4681bd7ad2  vmovaps xmm10, [rsp+0x90]
00007b4681bd7adb  vmovaps xmm11, [rsp+0xA0]
00007b4681bd7ae4  vmovaps xmm12, [rsp+0xB0]
00007b4681bd7aed  vmovaps xmm13, [rsp+0xC0]
00007b4681bd7af6  vmovaps xmm14, [rsp+0xD0]
00007b4681bd7aff  vmovaps xmm15, [rsp+0xE0]
00007b4681bd7b08  add rsp, 0xF0
00007b4681bd7b0f  pop r11
00007b4681bd7b11  pop r10
00007b4681bd7b13  pop r9
00007b4681bd7b15  pop r8
00007b4681bd7b17  pop rsi
00007b4681bd7b18  pop rdi
00007b4681bd7b19  pop rdx
00007b4681bd7b1a  pop rcx
00007b4681bd7b1b  pop rax
00007b4681bd7b1c  add rsp, 0x08
00007b4681bd7b20  jmp 0x00007B4681BD680F
00007b4681bd7b25  sub rsp, 0x08
00007b4681bd7b29  push rax
00007b4681bd7b2a  push rcx
00007b4681bd7b2b  push rdx
00007b4681bd7b2c  push rdi
00007b4681bd7b2d  push rsi
00007b4681bd7b2e  push r8
00007b4681bd7b30  push r9
00007b4681bd7b32  push r10
00007b4681bd7b34  push r11
00007b4681bd7b36  sub rsp, 0xF0
00007b4681bd7b3d  vmovaps [rsp], xmm0
00007b4681bd7b42  vmovaps [rsp+0x10], xmm1
00007b4681bd7b48  vmovaps [rsp+0x20], xmm2
00007b4681bd7b4e  vmovaps [rsp+0x30], xmm3
00007b4681bd7b54  vmovaps [rsp+0x40], xmm4
00007b4681bd7b5a  vmovaps [rsp+0x50], xmm5
00007b4681bd7b60  vmovaps [rsp+0x60], xmm7
00007b4681bd7b66  vmovaps [rsp+0x70], xmm8
00007b4681bd7b6c  vmovaps [rsp+0x80], xmm9
00007b4681bd7b75  vmovaps [rsp+0x90], xmm10
00007b4681bd7b7e  vmovaps [rsp+0xA0], xmm11
00007b4681bd7b87  vmovaps [rsp+0xB0], xmm12
00007b4681bd7b90  vmovaps [rsp+0xC0], xmm13
00007b4681bd7b99  vmovaps [rsp+0xD0], xmm14
00007b4681bd7ba2  vmovaps [rsp+0xE0], xmm15
00007b4681bd7bab  sub rsp, 0x40
00007b4681bd7baf  lea rdi, [rsp]
00007b4681bd7bb3  lea rsi, [rsp+0x10]
00007b4681bd7bb8  lea rdx, [rsp+0x20]
00007b4681bd7bbd  lea rcx, [rsp+0x30]
00007b4681bd7bc2  mov r8d, 0x00
00007b4681bd7bc8  lea r9, [r15+0x3A8]
00007b4681bd7bcf  movaps [rdi], xmm6
00007b4681bd7bd2  movaps [rsi], xmm2
00007b4681bd7bd5  movaps [rdx], xmm14
00007b4681bd7bd9  movaps [rcx], xmm1
00007b4681bd7bdc  mov rax, 0x5668589B5A50
00007b4681bd7be6  call rax
00007b4681bd7be8  movaps xmm6, [rsp]
00007b4681bd7bec  add rsp, 0x40
00007b4681bd7bf0  vmovaps xmm0, [rsp]
00007b4681bd7bf5  vmovaps xmm1, [rsp+0x10]
00007b4681bd7bfb  vmovaps xmm2, [rsp+0x20]
00007b4681bd7c01  vmovaps xmm3, [rsp+0x30]
00007b4681bd7c07  vmovaps xmm4, [rsp+0x40]
00007b4681bd7c0d  vmovaps xmm5, [rsp+0x50]
00007b4681bd7c13  vmovaps xmm7, [rsp+0x60]
00007b4681bd7c19  vmovaps xmm8, [rsp+0x70]
00007b4681bd7c1f  vmovaps xmm9, [rsp+0x80]
00007b4681bd7c28  vmovaps xmm10, [rsp+0x90]
00007b4681bd7c31  vmovaps xmm11, [rsp+0xA0]
00007b4681bd7c3a  vmovaps xmm12, [rsp+0xB0]
00007b4681bd7c43  vmovaps xmm13, [rsp+0xC0]
00007b4681bd7c4c  vmovaps xmm14, [rsp+0xD0]
00007b4681bd7c55  vmovaps xmm15, [rsp+0xE0]
00007b4681bd7c5e  add rsp, 0xF0
00007b4681bd7c65  pop r11
00007b4681bd7c67  pop r10
00007b4681bd7c69  pop r9
00007b4681bd7c6b  pop r8
00007b4681bd7c6d  pop rsi
00007b4681bd7c6e  pop rdi
00007b4681bd7c6f  pop rdx
00007b4681bd7c70  pop rcx
00007b4681bd7c71  pop rax
00007b4681bd7c72  add rsp, 0x08
00007b4681bd7c76  jmp 0x00007B4681BD683C
00007b4681bd7c7b  sub rsp, 0x08
00007b4681bd7c7f  push rax
00007b4681bd7c80  push rcx
00007b4681bd7c81  push rdx
00007b4681bd7c82  push rdi
00007b4681bd7c83  push rsi
00007b4681bd7c84  push r8
00007b4681bd7c86  push r9
00007b4681bd7c88  push r10
00007b4681bd7c8a  push r11
00007b4681bd7c8c  sub rsp, 0xF0
00007b4681bd7c93  vmovaps [rsp], xmm0
00007b4681bd7c98  vmovaps [rsp+0x10], xmm1
00007b4681bd7c9e  vmovaps [rsp+0x20], xmm2
00007b4681bd7ca4  vmovaps [rsp+0x30], xmm3
00007b4681bd7caa  vmovaps [rsp+0x40], xmm4
00007b4681bd7cb0  vmovaps [rsp+0x50], xmm5
00007b4681bd7cb6  vmovaps [rsp+0x60], xmm6
00007b4681bd7cbc  vmovaps [rsp+0x70], xmm7
00007b4681bd7cc2  vmovaps [rsp+0x80], xmm8
00007b4681bd7ccb  vmovaps [rsp+0x90], xmm9
00007b4681bd7cd4  vmovaps [rsp+0xA0], xmm10
00007b4681bd7cdd  vmovaps [rsp+0xB0], xmm11
00007b4681bd7ce6  vmovaps [rsp+0xC0], xmm12
00007b4681bd7cef  vmovaps [rsp+0xD0], xmm14
00007b4681bd7cf8  vmovaps [rsp+0xE0], xmm15
00007b4681bd7d01  sub rsp, 0x40
00007b4681bd7d05  lea rdi, [rsp]
00007b4681bd7d09  lea rsi, [rsp+0x10]
00007b4681bd7d0e  lea rdx, [rsp+0x20]
00007b4681bd7d13  lea rcx, [rsp+0x30]
00007b4681bd7d18  mov r8d, 0x00
00007b4681bd7d1e  lea r9, [r15+0x3A8]
00007b4681bd7d25  movaps [rdi], xmm13
00007b4681bd7d29  movaps [rsi], xmm12
00007b4681bd7d2d  movaps [rdx], xmm14
00007b4681bd7d31  movaps [rcx], xmm1
00007b4681bd7d34  mov rax, 0x5668589B5A50
00007b4681bd7d3e  call rax
00007b4681bd7d40  movaps xmm13, [rsp]
00007b4681bd7d45  add rsp, 0x40
00007b4681bd7d49  vmovaps xmm0, [rsp]
00007b4681bd7d4e  vmovaps xmm1, [rsp+0x10]
00007b4681bd7d54  vmovaps xmm2, [rsp+0x20]
00007b4681bd7d5a  vmovaps xmm3, [rsp+0x30]
00007b4681bd7d60  vmovaps xmm4, [rsp+0x40]
00007b4681bd7d66  vmovaps xmm5, [rsp+0x50]
00007b4681bd7d6c  vmovaps xmm6, [rsp+0x60]
00007b4681bd7d72  vmovaps xmm7, [rsp+0x70]
00007b4681bd7d78  vmovaps xmm8, [rsp+0x80]
00007b4681bd7d81  vmovaps xmm9, [rsp+0x90]
00007b4681bd7d8a  vmovaps xmm10, [rsp+0xA0]
00007b4681bd7d93  vmovaps xmm11, [rsp+0xB0]
00007b4681bd7d9c  vmovaps xmm12, [rsp+0xC0]
00007b4681bd7da5  vmovaps xmm14, [rsp+0xD0]
00007b4681bd7dae  vmovaps xmm15, [rsp+0xE0]
00007b4681bd7db7  add rsp, 0xF0
00007b4681bd7dbe  pop r11
00007b4681bd7dc0  pop r10
00007b4681bd7dc2  pop r9
00007b4681bd7dc4  pop r8
00007b4681bd7dc6  pop rsi
00007b4681bd7dc7  pop rdi
00007b4681bd7dc8  pop rdx
00007b4681bd7dc9  pop rcx
00007b4681bd7dca  pop rax
00007b4681bd7dcb  add rsp, 0x08
00007b4681bd7dcf  jmp 0x00007B4681BD686E
00007b4681bd7dd4  sub rsp, 0x08
00007b4681bd7dd8  push rax
00007b4681bd7dd9  push rcx
00007b4681bd7dda  push rdx
00007b4681bd7ddb  push rdi
00007b4681bd7ddc  push rsi
00007b4681bd7ddd  push r8
00007b4681bd7ddf  push r9
00007b4681bd7de1  push r10
00007b4681bd7de3  push r11
00007b4681bd7de5  sub rsp, 0xF0
00007b4681bd7dec  vmovaps [rsp], xmm0
00007b4681bd7df1  vmovaps [rsp+0x10], xmm1
00007b4681bd7df7  vmovaps [rsp+0x20], xmm2
00007b4681bd7dfd  vmovaps [rsp+0x30], xmm3
00007b4681bd7e03  vmovaps [rsp+0x40], xmm4
00007b4681bd7e09  vmovaps [rsp+0x50], xmm5
00007b4681bd7e0f  vmovaps [rsp+0x60], xmm6
00007b4681bd7e15  vmovaps [rsp+0x70], xmm7
00007b4681bd7e1b  vmovaps [rsp+0x80], xmm8
00007b4681bd7e24  vmovaps [rsp+0x90], xmm9
00007b4681bd7e2d  vmovaps [rsp+0xA0], xmm10
00007b4681bd7e36  vmovaps [rsp+0xB0], xmm11
00007b4681bd7e3f  vmovaps [rsp+0xC0], xmm13
00007b4681bd7e48  vmovaps [rsp+0xD0], xmm14
00007b4681bd7e51  vmovaps [rsp+0xE0], xmm15
00007b4681bd7e5a  sub rsp, 0x40
00007b4681bd7e5e  lea rdi, [rsp]
00007b4681bd7e62  lea rsi, [rsp+0x10]
00007b4681bd7e67  lea rdx, [rsp+0x20]
00007b4681bd7e6c  lea rcx, [rsp+0x30]
00007b4681bd7e71  mov r8d, 0x00
00007b4681bd7e77  lea r9, [r15+0x3A8]
00007b4681bd7e7e  movaps [rdi], xmm12
00007b4681bd7e82  movaps [rsi], xmm3
00007b4681bd7e85  movaps [rdx], xmm14
00007b4681bd7e89  movaps [rcx], xmm5
00007b4681bd7e8c  mov rax, 0x5668589B5A50
00007b4681bd7e96  call rax
00007b4681bd7e98  movaps xmm12, [rsp]
00007b4681bd7e9d  add rsp, 0x40
00007b4681bd7ea1  vmovaps xmm0, [rsp]
00007b4681bd7ea6  vmovaps xmm1, [rsp+0x10]
00007b4681bd7eac  vmovaps xmm2, [rsp+0x20]
00007b4681bd7eb2  vmovaps xmm3, [rsp+0x30]
00007b4681bd7eb8  vmovaps xmm4, [rsp+0x40]
00007b4681bd7ebe  vmovaps xmm5, [rsp+0x50]
00007b4681bd7ec4  vmovaps xmm6, [rsp+0x60]
00007b4681bd7eca  vmovaps xmm7, [rsp+0x70]
00007b4681bd7ed0  vmovaps xmm8, [rsp+0x80]
00007b4681bd7ed9  vmovaps xmm9, [rsp+0x90]
00007b4681bd7ee2  vmovaps xmm10, [rsp+0xA0]
00007b4681bd7eeb  vmovaps xmm11, [rsp+0xB0]
00007b4681bd7ef4  vmovaps xmm13, [rsp+0xC0]
00007b4681bd7efd  vmovaps xmm14, [rsp+0xD0]
00007b4681bd7f06  vmovaps xmm15, [rsp+0xE0]
00007b4681bd7f0f  add rsp, 0xF0
00007b4681bd7f16  pop r11
00007b4681bd7f18  pop r10
00007b4681bd7f1a  pop r9
00007b4681bd7f1c  pop r8
00007b4681bd7f1e  pop rsi
00007b4681bd7f1f  pop rdi
00007b4681bd7f20  pop rdx
00007b4681bd7f21  pop rcx
00007b4681bd7f22  pop rax
00007b4681bd7f23  add rsp, 0x08
00007b4681bd7f27  jmp 0x00007B4681BD68CB
00007b4681bd7f2c  sub rsp, 0x08
00007b4681bd7f30  push rax
00007b4681bd7f31  push rcx
00007b4681bd7f32  push rdx
00007b4681bd7f33  push rdi
00007b4681bd7f34  push rsi
00007b4681bd7f35  push r8
00007b4681bd7f37  push r9
00007b4681bd7f39  push r10
00007b4681bd7f3b  push r11
00007b4681bd7f3d  sub rsp, 0xF0
00007b4681bd7f44  vmovaps [rsp], xmm0
00007b4681bd7f49  vmovaps [rsp+0x10], xmm1
00007b4681bd7f4f  vmovaps [rsp+0x20], xmm2
00007b4681bd7f55  vmovaps [rsp+0x30], xmm3
00007b4681bd7f5b  vmovaps [rsp+0x40], xmm4
00007b4681bd7f61  vmovaps [rsp+0x50], xmm5
00007b4681bd7f67  vmovaps [rsp+0x60], xmm6
00007b4681bd7f6d  vmovaps [rsp+0x70], xmm7
00007b4681bd7f73  vmovaps [rsp+0x80], xmm8
00007b4681bd7f7c  vmovaps [rsp+0x90], xmm9
00007b4681bd7f85  vmovaps [rsp+0xA0], xmm11
00007b4681bd7f8e  vmovaps [rsp+0xB0], xmm12
00007b4681bd7f97  vmovaps [rsp+0xC0], xmm13
00007b4681bd7fa0  vmovaps [rsp+0xD0], xmm14
00007b4681bd7fa9  vmovaps [rsp+0xE0], xmm15
00007b4681bd7fb2  sub rsp, 0x40
00007b4681bd7fb6  lea rdi, [rsp]
00007b4681bd7fba  lea rsi, [rsp+0x10]
00007b4681bd7fbf  lea rdx, [rsp+0x20]
00007b4681bd7fc4  lea rcx, [rsp+0x30]
00007b4681bd7fc9  mov r8d, 0x00
00007b4681bd7fcf  lea r9, [r15+0x3A8]
00007b4681bd7fd6  movaps [rdi], xmm10
00007b4681bd7fda  movaps [rsi], xmm9
00007b4681bd7fde  movaps [rdx], xmm7
00007b4681bd7fe1  movaps [rcx], xmm14
00007b4681bd7fe5  mov rax, 0x5668589B5A50
00007b4681bd7fef  call rax
00007b4681bd7ff1  movaps xmm10, [rsp]
00007b4681bd7ff6  add rsp, 0x40
00007b4681bd7ffa  vmovaps xmm0, [rsp]
00007b4681bd7fff  vmovaps xmm1, [rsp+0x10]
00007b4681bd8005  vmovaps xmm2, [rsp+0x20]
00007b4681bd800b  vmovaps xmm3, [rsp+0x30]
00007b4681bd8011  vmovaps xmm4, [rsp+0x40]
00007b4681bd8017  vmovaps xmm5, [rsp+0x50]
00007b4681bd801d  vmovaps xmm6, [rsp+0x60]
00007b4681bd8023  vmovaps xmm7, [rsp+0x70]
00007b4681bd8029  vmovaps xmm8, [rsp+0x80]
00007b4681bd8032  vmovaps xmm9, [rsp+0x90]
00007b4681bd803b  vmovaps xmm11, [rsp+0xA0]
00007b4681bd8044  vmovaps xmm12, [rsp+0xB0]
00007b4681bd804d  vmovaps xmm13, [rsp+0xC0]
00007b4681bd8056  vmovaps xmm14, [rsp+0xD0]
00007b4681bd805f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd8068  add rsp, 0xF0
00007b4681bd806f  pop r11
00007b4681bd8071  pop r10
00007b4681bd8073  pop r9
00007b4681bd8075  pop r8
00007b4681bd8077  pop rsi
00007b4681bd8078  pop rdi
00007b4681bd8079  pop rdx
00007b4681bd807a  pop rcx
00007b4681bd807b  pop rax
00007b4681bd807c  add rsp, 0x08
00007b4681bd8080  jmp 0x00007B4681BD68F1
00007b4681bd8085  call 0x00007B4681AE45A0
00007b4681bd808a  jmp 0x00007B4681BD68FE
00007b4681bd808f  sub rsp, 0x08
00007b4681bd8093  push rax
00007b4681bd8094  push rcx
00007b4681bd8095  push rdx
00007b4681bd8096  push rdi
00007b4681bd8097  push rsi
00007b4681bd8098  push r8
00007b4681bd809a  push r9
00007b4681bd809c  push r10
00007b4681bd809e  push r11
00007b4681bd80a0  sub rsp, 0xF0
00007b4681bd80a7  vmovaps [rsp], xmm0
00007b4681bd80ac  vmovaps [rsp+0x10], xmm1
00007b4681bd80b2  vmovaps [rsp+0x20], xmm2
00007b4681bd80b8  vmovaps [rsp+0x30], xmm3
00007b4681bd80be  vmovaps [rsp+0x40], xmm4
00007b4681bd80c4  vmovaps [rsp+0x50], xmm6
00007b4681bd80ca  vmovaps [rsp+0x60], xmm7
00007b4681bd80d0  vmovaps [rsp+0x70], xmm8
00007b4681bd80d6  vmovaps [rsp+0x80], xmm9
00007b4681bd80df  vmovaps [rsp+0x90], xmm10
00007b4681bd80e8  vmovaps [rsp+0xA0], xmm11
00007b4681bd80f1  vmovaps [rsp+0xB0], xmm12
00007b4681bd80fa  vmovaps [rsp+0xC0], xmm13
00007b4681bd8103  vmovaps [rsp+0xD0], xmm14
00007b4681bd810c  vmovaps [rsp+0xE0], xmm15
00007b4681bd8115  sub rsp, 0x40
00007b4681bd8119  lea rdi, [rsp]
00007b4681bd811d  lea rsi, [rsp+0x10]
00007b4681bd8122  lea rdx, [rsp+0x20]
00007b4681bd8127  lea rcx, [rsp+0x30]
00007b4681bd812c  mov r8d, 0x00
00007b4681bd8132  lea r9, [r15+0x3A8]
00007b4681bd8139  movaps [rdi], xmm5
00007b4681bd813c  movaps [rsi], xmm6
00007b4681bd813f  movaps [rdx], xmm7
00007b4681bd8142  movaps [rcx], xmm9
00007b4681bd8146  mov rax, 0x5668589B5A50
00007b4681bd8150  call rax
00007b4681bd8152  movaps xmm5, [rsp]
00007b4681bd8156  add rsp, 0x40
00007b4681bd815a  vmovaps xmm0, [rsp]
00007b4681bd815f  vmovaps xmm1, [rsp+0x10]
00007b4681bd8165  vmovaps xmm2, [rsp+0x20]
00007b4681bd816b  vmovaps xmm3, [rsp+0x30]
00007b4681bd8171  vmovaps xmm4, [rsp+0x40]
00007b4681bd8177  vmovaps xmm6, [rsp+0x50]
00007b4681bd817d  vmovaps xmm7, [rsp+0x60]
00007b4681bd8183  vmovaps xmm8, [rsp+0x70]
00007b4681bd8189  vmovaps xmm9, [rsp+0x80]
00007b4681bd8192  vmovaps xmm10, [rsp+0x90]
00007b4681bd819b  vmovaps xmm11, [rsp+0xA0]
00007b4681bd81a4  vmovaps xmm12, [rsp+0xB0]
00007b4681bd81ad  vmovaps xmm13, [rsp+0xC0]
00007b4681bd81b6  vmovaps xmm14, [rsp+0xD0]
00007b4681bd81bf  vmovaps xmm15, [rsp+0xE0]
00007b4681bd81c8  add rsp, 0xF0
00007b4681bd81cf  pop r11
00007b4681bd81d1  pop r10
00007b4681bd81d3  pop r9
00007b4681bd81d5  pop r8
00007b4681bd81d7  pop rsi
00007b4681bd81d8  pop rdi
00007b4681bd81d9  pop rdx
00007b4681bd81da  pop rcx
00007b4681bd81db  pop rax
00007b4681bd81dc  add rsp, 0x08
00007b4681bd81e0  jmp 0x00007B4681BD6930
00007b4681bd81e5  sub rsp, 0x08
00007b4681bd81e9  push rax
00007b4681bd81ea  push rcx
00007b4681bd81eb  push rdx
00007b4681bd81ec  push rdi
00007b4681bd81ed  push rsi
00007b4681bd81ee  push r8
00007b4681bd81f0  push r9
00007b4681bd81f2  push r10
00007b4681bd81f4  push r11
00007b4681bd81f6  sub rsp, 0xF0
00007b4681bd81fd  vmovaps [rsp], xmm0
00007b4681bd8202  vmovaps [rsp+0x10], xmm1
00007b4681bd8208  vmovaps [rsp+0x20], xmm2
00007b4681bd820e  vmovaps [rsp+0x30], xmm3
00007b4681bd8214  vmovaps [rsp+0x40], xmm4
00007b4681bd821a  vmovaps [rsp+0x50], xmm5
00007b4681bd8220  vmovaps [rsp+0x60], xmm6
00007b4681bd8226  vmovaps [rsp+0x70], xmm8
00007b4681bd822c  vmovaps [rsp+0x80], xmm9
00007b4681bd8235  vmovaps [rsp+0x90], xmm10
00007b4681bd823e  vmovaps [rsp+0xA0], xmm11
00007b4681bd8247  vmovaps [rsp+0xB0], xmm12
00007b4681bd8250  vmovaps [rsp+0xC0], xmm13
00007b4681bd8259  vmovaps [rsp+0xD0], xmm14
00007b4681bd8262  vmovaps [rsp+0xE0], xmm15
00007b4681bd826b  sub rsp, 0x40
00007b4681bd826f  lea rdi, [rsp]
00007b4681bd8273  lea rsi, [rsp+0x10]
00007b4681bd8278  lea rdx, [rsp+0x20]
00007b4681bd827d  lea rcx, [rsp+0x30]
00007b4681bd8282  mov r8d, 0x00
00007b4681bd8288  lea r9, [r15+0x3A8]
00007b4681bd828f  movaps [rdi], xmm7
00007b4681bd8292  movaps [rsi], xmm13
00007b4681bd8296  movaps [rdx], xmm1
00007b4681bd8299  movaps [rcx], xmm9
00007b4681bd829d  mov rax, 0x5668589B5A50
00007b4681bd82a7  call rax
00007b4681bd82a9  movaps xmm7, [rsp]
00007b4681bd82ad  add rsp, 0x40
00007b4681bd82b1  vmovaps xmm0, [rsp]
00007b4681bd82b6  vmovaps xmm1, [rsp+0x10]
00007b4681bd82bc  vmovaps xmm2, [rsp+0x20]
00007b4681bd82c2  vmovaps xmm3, [rsp+0x30]
00007b4681bd82c8  vmovaps xmm4, [rsp+0x40]
00007b4681bd82ce  vmovaps xmm5, [rsp+0x50]
00007b4681bd82d4  vmovaps xmm6, [rsp+0x60]
00007b4681bd82da  vmovaps xmm8, [rsp+0x70]
00007b4681bd82e0  vmovaps xmm9, [rsp+0x80]
00007b4681bd82e9  vmovaps xmm10, [rsp+0x90]
00007b4681bd82f2  vmovaps xmm11, [rsp+0xA0]
00007b4681bd82fb  vmovaps xmm12, [rsp+0xB0]
00007b4681bd8304  vmovaps xmm13, [rsp+0xC0]
00007b4681bd830d  vmovaps xmm14, [rsp+0xD0]
00007b4681bd8316  vmovaps xmm15, [rsp+0xE0]
00007b4681bd831f  add rsp, 0xF0
00007b4681bd8326  pop r11
00007b4681bd8328  pop r10
00007b4681bd832a  pop r9
00007b4681bd832c  pop r8
00007b4681bd832e  pop rsi
00007b4681bd832f  pop rdi
00007b4681bd8330  pop rdx
00007b4681bd8331  pop rcx
00007b4681bd8332  pop rax
00007b4681bd8333  add rsp, 0x08
00007b4681bd8337  jmp 0x00007B4681BD6955
00007b4681bd833c  call 0x00007B4681AE3320
00007b4681bd8341  jmp 0x00007B4681BD6978
00007b4681bd8346  call 0x00007B4681ADE950
00007b4681bd834b  jmp 0x00007B4681BD6982
00007b4681bd8350  sub rsp, 0x08
00007b4681bd8354  push rax
00007b4681bd8355  push rcx
00007b4681bd8356  push rdx
00007b4681bd8357  push rdi
00007b4681bd8358  push rsi
00007b4681bd8359  push r8
00007b4681bd835b  push r9
00007b4681bd835d  push r10
00007b4681bd835f  push r11
00007b4681bd8361  sub rsp, 0xF0
00007b4681bd8368  vmovaps [rsp], xmm0
00007b4681bd836d  vmovaps [rsp+0x10], xmm1
00007b4681bd8373  vmovaps [rsp+0x20], xmm3
00007b4681bd8379  vmovaps [rsp+0x30], xmm4
00007b4681bd837f  vmovaps [rsp+0x40], xmm5
00007b4681bd8385  vmovaps [rsp+0x50], xmm6
00007b4681bd838b  vmovaps [rsp+0x60], xmm7
00007b4681bd8391  vmovaps [rsp+0x70], xmm8
00007b4681bd8397  vmovaps [rsp+0x80], xmm9
00007b4681bd83a0  vmovaps [rsp+0x90], xmm10
00007b4681bd83a9  vmovaps [rsp+0xA0], xmm11
00007b4681bd83b2  vmovaps [rsp+0xB0], xmm12
00007b4681bd83bb  vmovaps [rsp+0xC0], xmm13
00007b4681bd83c4  vmovaps [rsp+0xD0], xmm14
00007b4681bd83cd  vmovaps [rsp+0xE0], xmm15
00007b4681bd83d6  sub rsp, 0x40
00007b4681bd83da  lea rdi, [rsp]
00007b4681bd83de  lea rsi, [rsp+0x10]
00007b4681bd83e3  lea rdx, [rsp+0x20]
00007b4681bd83e8  lea rcx, [rsp+0x30]
00007b4681bd83ed  mov r8d, 0x00
00007b4681bd83f3  lea r9, [r15+0x3A8]
00007b4681bd83fa  movaps [rdi], xmm2
00007b4681bd83fd  movaps [rsi], xmm12
00007b4681bd8401  movaps [rdx], xmm6
00007b4681bd8404  movaps [rcx], xmm3
00007b4681bd8407  mov rax, 0x5668589B5A50
00007b4681bd8411  call rax
00007b4681bd8413  movaps xmm2, [rsp]
00007b4681bd8417  add rsp, 0x40
00007b4681bd841b  vmovaps xmm0, [rsp]
00007b4681bd8420  vmovaps xmm1, [rsp+0x10]
00007b4681bd8426  vmovaps xmm3, [rsp+0x20]
00007b4681bd842c  vmovaps xmm4, [rsp+0x30]
00007b4681bd8432  vmovaps xmm5, [rsp+0x40]
00007b4681bd8438  vmovaps xmm6, [rsp+0x50]
00007b4681bd843e  vmovaps xmm7, [rsp+0x60]
00007b4681bd8444  vmovaps xmm8, [rsp+0x70]
00007b4681bd844a  vmovaps xmm9, [rsp+0x80]
00007b4681bd8453  vmovaps xmm10, [rsp+0x90]
00007b4681bd845c  vmovaps xmm11, [rsp+0xA0]
00007b4681bd8465  vmovaps xmm12, [rsp+0xB0]
00007b4681bd846e  vmovaps xmm13, [rsp+0xC0]
00007b4681bd8477  vmovaps xmm14, [rsp+0xD0]
00007b4681bd8480  vmovaps xmm15, [rsp+0xE0]
00007b4681bd8489  add rsp, 0xF0
00007b4681bd8490  pop r11
00007b4681bd8492  pop r10
00007b4681bd8494  pop r9
00007b4681bd8496  pop r8
00007b4681bd8498  pop rsi
00007b4681bd8499  pop rdi
00007b4681bd849a  pop rdx
00007b4681bd849b  pop rcx
00007b4681bd849c  pop rax
00007b4681bd849d  add rsp, 0x08
00007b4681bd84a1  jmp 0x00007B4681BD69C8
00007b4681bd84a6  sub rsp, 0x08
00007b4681bd84aa  push rax
00007b4681bd84ab  push rcx
00007b4681bd84ac  push rdx
00007b4681bd84ad  push rdi
00007b4681bd84ae  push rsi
00007b4681bd84af  push r8
00007b4681bd84b1  push r9
00007b4681bd84b3  push r10
00007b4681bd84b5  push r11
00007b4681bd84b7  sub rsp, 0xF0
00007b4681bd84be  vmovaps [rsp], xmm0
00007b4681bd84c3  vmovaps [rsp+0x10], xmm1
00007b4681bd84c9  vmovaps [rsp+0x20], xmm2
00007b4681bd84cf  vmovaps [rsp+0x30], xmm3
00007b4681bd84d5  vmovaps [rsp+0x40], xmm4
00007b4681bd84db  vmovaps [rsp+0x50], xmm5
00007b4681bd84e1  vmovaps [rsp+0x60], xmm7
00007b4681bd84e7  vmovaps [rsp+0x70], xmm8
00007b4681bd84ed  vmovaps [rsp+0x80], xmm9
00007b4681bd84f6  vmovaps [rsp+0x90], xmm10
00007b4681bd84ff  vmovaps [rsp+0xA0], xmm11
00007b4681bd8508  vmovaps [rsp+0xB0], xmm12
00007b4681bd8511  vmovaps [rsp+0xC0], xmm13
00007b4681bd851a  vmovaps [rsp+0xD0], xmm14
00007b4681bd8523  vmovaps [rsp+0xE0], xmm15
00007b4681bd852c  sub rsp, 0x40
00007b4681bd8530  lea rdi, [rsp]
00007b4681bd8534  lea rsi, [rsp+0x10]
00007b4681bd8539  lea rdx, [rsp+0x20]
00007b4681bd853e  lea rcx, [rsp+0x30]
00007b4681bd8543  mov r8d, 0x00
00007b4681bd8549  lea r9, [r15+0x3A8]
00007b4681bd8550  movaps [rdi], xmm6
00007b4681bd8553  movaps [rsi], xmm10
00007b4681bd8557  movaps [rdx], xmm12
00007b4681bd855b  movaps [rcx], xmm1
00007b4681bd855e  mov rax, 0x5668589B5A50
00007b4681bd8568  call rax
00007b4681bd856a  movaps xmm6, [rsp]
00007b4681bd856e  add rsp, 0x40
00007b4681bd8572  vmovaps xmm0, [rsp]
00007b4681bd8577  vmovaps xmm1, [rsp+0x10]
00007b4681bd857d  vmovaps xmm2, [rsp+0x20]
00007b4681bd8583  vmovaps xmm3, [rsp+0x30]
00007b4681bd8589  vmovaps xmm4, [rsp+0x40]
00007b4681bd858f  vmovaps xmm5, [rsp+0x50]
00007b4681bd8595  vmovaps xmm7, [rsp+0x60]
00007b4681bd859b  vmovaps xmm8, [rsp+0x70]
00007b4681bd85a1  vmovaps xmm9, [rsp+0x80]
00007b4681bd85aa  vmovaps xmm10, [rsp+0x90]
00007b4681bd85b3  vmovaps xmm11, [rsp+0xA0]
00007b4681bd85bc  vmovaps xmm12, [rsp+0xB0]
00007b4681bd85c5  vmovaps xmm13, [rsp+0xC0]
00007b4681bd85ce  vmovaps xmm14, [rsp+0xD0]
00007b4681bd85d7  vmovaps xmm15, [rsp+0xE0]
00007b4681bd85e0  add rsp, 0xF0
00007b4681bd85e7  pop r11
00007b4681bd85e9  pop r10
00007b4681bd85eb  pop r9
00007b4681bd85ed  pop r8
00007b4681bd85ef  pop rsi
00007b4681bd85f0  pop rdi
00007b4681bd85f1  pop rdx
00007b4681bd85f2  pop rcx
00007b4681bd85f3  pop rax
00007b4681bd85f4  add rsp, 0x08
00007b4681bd85f8  jmp 0x00007B4681BD69F6
00007b4681bd85fd  sub rsp, 0x08
00007b4681bd8601  push rax
00007b4681bd8602  push rcx
00007b4681bd8603  push rdx
00007b4681bd8604  push rdi
00007b4681bd8605  push rsi
00007b4681bd8606  push r8
00007b4681bd8608  push r9
00007b4681bd860a  push r10
00007b4681bd860c  push r11
00007b4681bd860e  sub rsp, 0xF0
00007b4681bd8615  vmovaps [rsp], xmm0
00007b4681bd861a  vmovaps [rsp+0x10], xmm1
00007b4681bd8620  vmovaps [rsp+0x20], xmm2
00007b4681bd8626  vmovaps [rsp+0x30], xmm3
00007b4681bd862c  vmovaps [rsp+0x40], xmm4
00007b4681bd8632  vmovaps [rsp+0x50], xmm5
00007b4681bd8638  vmovaps [rsp+0x60], xmm6
00007b4681bd863e  vmovaps [rsp+0x70], xmm7
00007b4681bd8644  vmovaps [rsp+0x80], xmm8
00007b4681bd864d  vmovaps [rsp+0x90], xmm9
00007b4681bd8656  vmovaps [rsp+0xA0], xmm11
00007b4681bd865f  vmovaps [rsp+0xB0], xmm12
00007b4681bd8668  vmovaps [rsp+0xC0], xmm13
00007b4681bd8671  vmovaps [rsp+0xD0], xmm14
00007b4681bd867a  vmovaps [rsp+0xE0], xmm15
00007b4681bd8683  sub rsp, 0x40
00007b4681bd8687  lea rdi, [rsp]
00007b4681bd868b  lea rsi, [rsp+0x10]
00007b4681bd8690  lea rdx, [rsp+0x20]
00007b4681bd8695  lea rcx, [rsp+0x30]
00007b4681bd869a  mov r8d, 0x00
00007b4681bd86a0  lea r9, [r15+0x3A8]
00007b4681bd86a7  movaps [rdi], xmm10
00007b4681bd86ab  movaps [rsi], xmm5
00007b4681bd86ae  movaps [rdx], xmm12
00007b4681bd86b2  movaps [rcx], xmm1
00007b4681bd86b5  mov rax, 0x5668589B5A50
00007b4681bd86bf  call rax
00007b4681bd86c1  movaps xmm10, [rsp]
00007b4681bd86c6  add rsp, 0x40
00007b4681bd86ca  vmovaps xmm0, [rsp]
00007b4681bd86cf  vmovaps xmm1, [rsp+0x10]
00007b4681bd86d5  vmovaps xmm2, [rsp+0x20]
00007b4681bd86db  vmovaps xmm3, [rsp+0x30]
00007b4681bd86e1  vmovaps xmm4, [rsp+0x40]
00007b4681bd86e7  vmovaps xmm5, [rsp+0x50]
00007b4681bd86ed  vmovaps xmm6, [rsp+0x60]
00007b4681bd86f3  vmovaps xmm7, [rsp+0x70]
00007b4681bd86f9  vmovaps xmm8, [rsp+0x80]
00007b4681bd8702  vmovaps xmm9, [rsp+0x90]
00007b4681bd870b  vmovaps xmm11, [rsp+0xA0]
00007b4681bd8714  vmovaps xmm12, [rsp+0xB0]
00007b4681bd871d  vmovaps xmm13, [rsp+0xC0]
00007b4681bd8726  vmovaps xmm14, [rsp+0xD0]
00007b4681bd872f  vmovaps xmm15, [rsp+0xE0]
00007b4681bd8738  add rsp, 0xF0
00007b4681bd873f  pop r11
00007b4681bd8741  pop r10
00007b4681bd8743  pop r9
00007b4681bd8745  pop r8
00007b4681bd8747  pop rsi
00007b4681bd8748  pop rdi
00007b4681bd8749  pop rdx
00007b4681bd874a  pop rcx
00007b4681bd874b  pop rax
00007b4681bd874c  add rsp, 0x08
00007b4681bd8750  jmp 0x00007B4681BD6A25
00007b4681bd8755  sub rsp, 0x08
00007b4681bd8759  push rax
00007b4681bd875a  push rcx
00007b4681bd875b  push rdx
00007b4681bd875c  push rdi
00007b4681bd875d  push rsi
00007b4681bd875e  push r8
00007b4681bd8760  push r9
00007b4681bd8762  push r10
00007b4681bd8764  push r11
00007b4681bd8766  sub rsp, 0xF0
00007b4681bd876d  vmovaps [rsp], xmm0
00007b4681bd8772  vmovaps [rsp+0x10], xmm1
00007b4681bd8778  vmovaps [rsp+0x20], xmm2
00007b4681bd877e  vmovaps [rsp+0x30], xmm3
00007b4681bd8784  vmovaps [rsp+0x40], xmm4
00007b4681bd878a  vmovaps [rsp+0x50], xmm5
00007b4681bd8790  vmovaps [rsp+0x60], xmm6
00007b4681bd8796  vmovaps [rsp+0x70], xmm7
00007b4681bd879c  vmovaps [rsp+0x80], xmm8
00007b4681bd87a5  vmovaps [rsp+0x90], xmm9
00007b4681bd87ae  vmovaps [rsp+0xA0], xmm10
00007b4681bd87b7  vmovaps [rsp+0xB0], xmm11
00007b4681bd87c0  vmovaps [rsp+0xC0], xmm13
00007b4681bd87c9  vmovaps [rsp+0xD0], xmm14
00007b4681bd87d2  vmovaps [rsp+0xE0], xmm15
00007b4681bd87db  sub rsp, 0x40
00007b4681bd87df  lea rdi, [rsp]
00007b4681bd87e3  lea rsi, [rsp+0x10]
00007b4681bd87e8  lea rdx, [rsp+0x20]
00007b4681bd87ed  lea rcx, [rsp+0x30]
00007b4681bd87f2  mov r8d, 0x00
00007b4681bd87f8  lea r9, [r15+0x3A8]
00007b4681bd87ff  movaps [rdi], xmm12
00007b4681bd8803  movaps [rsi], xmm7
00007b4681bd8806  movaps [rdx], xmm15
00007b4681bd880a  movaps [rcx], xmm1
00007b4681bd880d  mov rax, 0x5668589B5A50
00007b4681bd8817  call rax
00007b4681bd8819  movaps xmm12, [rsp]
00007b4681bd881e  add rsp, 0x40
00007b4681bd8822  vmovaps xmm0, [rsp]
00007b4681bd8827  vmovaps xmm1, [rsp+0x10]
00007b4681bd882d  vmovaps xmm2, [rsp+0x20]
00007b4681bd8833  vmovaps xmm3, [rsp+0x30]
00007b4681bd8839  vmovaps xmm4, [rsp+0x40]
00007b4681bd883f  vmovaps xmm5, [rsp+0x50]
00007b4681bd8845  vmovaps xmm6, [rsp+0x60]
00007b4681bd884b  vmovaps xmm7, [rsp+0x70]
00007b4681bd8851  vmovaps xmm8, [rsp+0x80]
00007b4681bd885a  vmovaps xmm9, [rsp+0x90]
00007b4681bd8863  vmovaps xmm10, [rsp+0xA0]
00007b4681bd886c  vmovaps xmm11, [rsp+0xB0]
00007b4681bd8875  vmovaps xmm13, [rsp+0xC0]
00007b4681bd887e  vmovaps xmm14, [rsp+0xD0]
00007b4681bd8887  vmovaps xmm15, [rsp+0xE0]
00007b4681bd8890  add rsp, 0xF0
00007b4681bd8897  pop r11
00007b4681bd8899  pop r10
00007b4681bd889b  pop r9
00007b4681bd889d  pop r8
00007b4681bd889f  pop rsi
00007b4681bd88a0  pop rdi
00007b4681bd88a1  pop rdx
00007b4681bd88a2  pop rcx
00007b4681bd88a3  pop rax
00007b4681bd88a4  add rsp, 0x08
00007b4681bd88a8  jmp 0x00007B4681BD6A4E
00007b4681bd88ad  call 0x00007B4681AD64F0
00007b4681bd88b2  jmp 0x00007B4681BD6A58
00007b4681bd88b7  call 0x00007B4681AE5820
00007b4681bd88bc  jmp 0x00007B4681BD6A62
00007b4681bd88c1  sub rsp, 0x08
00007b4681bd88c5  push rax
00007b4681bd88c6  push rcx
00007b4681bd88c7  push rdx
00007b4681bd88c8  push rdi
00007b4681bd88c9  push rsi
00007b4681bd88ca  push r8
00007b4681bd88cc  push r9
00007b4681bd88ce  push r10
00007b4681bd88d0  push r11
00007b4681bd88d2  sub rsp, 0xF0
00007b4681bd88d9  vmovaps [rsp], xmm0
00007b4681bd88de  vmovaps [rsp+0x10], xmm1
00007b4681bd88e4  vmovaps [rsp+0x20], xmm2
00007b4681bd88ea  vmovaps [rsp+0x30], xmm3
00007b4681bd88f0  vmovaps [rsp+0x40], xmm4
00007b4681bd88f6  vmovaps [rsp+0x50], xmm5
00007b4681bd88fc  vmovaps [rsp+0x60], xmm6
00007b4681bd8902  vmovaps [rsp+0x70], xmm8
00007b4681bd8908  vmovaps [rsp+0x80], xmm9
00007b4681bd8911  vmovaps [rsp+0x90], xmm10
00007b4681bd891a  vmovaps [rsp+0xA0], xmm11
00007b4681bd8923  vmovaps [rsp+0xB0], xmm12
00007b4681bd892c  vmovaps [rsp+0xC0], xmm13
00007b4681bd8935  vmovaps [rsp+0xD0], xmm14
00007b4681bd893e  vmovaps [rsp+0xE0], xmm15
00007b4681bd8947  sub rsp, 0x40
00007b4681bd894b  lea rdi, [rsp]
00007b4681bd894f  lea rsi, [rsp+0x10]
00007b4681bd8954  lea rdx, [rsp+0x20]
00007b4681bd8959  lea rcx, [rsp+0x30]
00007b4681bd895e  mov r8d, 0x00
00007b4681bd8964  lea r9, [r15+0x3A8]
00007b4681bd896b  movaps [rdi], xmm7
00007b4681bd896e  movaps [rsi], xmm2
00007b4681bd8971  movaps [rdx], xmm9
00007b4681bd8975  movaps [rcx], xmm11
00007b4681bd8979  mov rax, 0x5668589B5A50
00007b4681bd8983  call rax
00007b4681bd8985  movaps xmm7, [rsp]
00007b4681bd8989  add rsp, 0x40
00007b4681bd898d  vmovaps xmm0, [rsp]
00007b4681bd8992  vmovaps xmm1, [rsp+0x10]
00007b4681bd8998  vmovaps xmm2, [rsp+0x20]
00007b4681bd899e  vmovaps xmm3, [rsp+0x30]
00007b4681bd89a4  vmovaps xmm4, [rsp+0x40]
00007b4681bd89aa  vmovaps xmm5, [rsp+0x50]
00007b4681bd89b0  vmovaps xmm6, [rsp+0x60]
00007b4681bd89b6  vmovaps xmm8, [rsp+0x70]
00007b4681bd89bc  vmovaps xmm9, [rsp+0x80]
00007b4681bd89c5  vmovaps xmm10, [rsp+0x90]
00007b4681bd89ce  vmovaps xmm11, [rsp+0xA0]
00007b4681bd89d7  vmovaps xmm12, [rsp+0xB0]
00007b4681bd89e0  vmovaps xmm13, [rsp+0xC0]
00007b4681bd89e9  vmovaps xmm14, [rsp+0xD0]
00007b4681bd89f2  vmovaps xmm15, [rsp+0xE0]
00007b4681bd89fb  add rsp, 0xF0
00007b4681bd8a02  pop r11
00007b4681bd8a04  pop r10
00007b4681bd8a06  pop r9
00007b4681bd8a08  pop r8
00007b4681bd8a0a  pop rsi
00007b4681bd8a0b  pop rdi
00007b4681bd8a0c  pop rdx
00007b4681bd8a0d  pop rcx
00007b4681bd8a0e  pop rax
00007b4681bd8a0f  add rsp, 0x08
00007b4681bd8a13  jmp 0x00007B4681BD6A96
00007b4681bd8a18  sub rsp, 0x08
00007b4681bd8a1c  push rax
00007b4681bd8a1d  push rcx
00007b4681bd8a1e  push rdx
00007b4681bd8a1f  push rdi
00007b4681bd8a20  push rsi
00007b4681bd8a21  push r8
00007b4681bd8a23  push r9
00007b4681bd8a25  push r10
00007b4681bd8a27  push r11
00007b4681bd8a29  sub rsp, 0xF0
00007b4681bd8a30  vmovaps [rsp], xmm0
00007b4681bd8a35  vmovaps [rsp+0x10], xmm1
00007b4681bd8a3b  vmovaps [rsp+0x20], xmm2
00007b4681bd8a41  vmovaps [rsp+0x30], xmm3
00007b4681bd8a47  vmovaps [rsp+0x40], xmm4
00007b4681bd8a4d  vmovaps [rsp+0x50], xmm5
00007b4681bd8a53  vmovaps [rsp+0x60], xmm6
00007b4681bd8a59  vmovaps [rsp+0x70], xmm7
00007b4681bd8a5f  vmovaps [rsp+0x80], xmm8
00007b4681bd8a68  vmovaps [rsp+0x90], xmm10
00007b4681bd8a71  vmovaps [rsp+0xA0], xmm11
00007b4681bd8a7a  vmovaps [rsp+0xB0], xmm12
00007b4681bd8a83  vmovaps [rsp+0xC0], xmm13
00007b4681bd8a8c  vmovaps [rsp+0xD0], xmm14
00007b4681bd8a95  vmovaps [rsp+0xE0], xmm15
00007b4681bd8a9e  sub rsp, 0x40
00007b4681bd8aa2  lea rdi, [rsp]
00007b4681bd8aa6  lea rsi, [rsp+0x10]
00007b4681bd8aab  lea rdx, [rsp+0x20]
00007b4681bd8ab0  lea rcx, [rsp+0x30]
00007b4681bd8ab5  mov r8d, 0x00
00007b4681bd8abb  lea r9, [r15+0x3A8]
00007b4681bd8ac2  movaps [rdi], xmm9
00007b4681bd8ac6  movaps [rsi], xmm6
00007b4681bd8ac9  movaps [rdx], xmm1
00007b4681bd8acc  movaps [rcx], xmm11
00007b4681bd8ad0  mov rax, 0x5668589B5A50
00007b4681bd8ada  call rax
00007b4681bd8adc  movaps xmm9, [rsp]
00007b4681bd8ae1  add rsp, 0x40
00007b4681bd8ae5  vmovaps xmm0, [rsp]
00007b4681bd8aea  vmovaps xmm1, [rsp+0x10]
00007b4681bd8af0  vmovaps xmm2, [rsp+0x20]
00007b4681bd8af6  vmovaps xmm3, [rsp+0x30]
00007b4681bd8afc  vmovaps xmm4, [rsp+0x40]
00007b4681bd8b02  vmovaps xmm5, [rsp+0x50]
00007b4681bd8b08  vmovaps xmm6, [rsp+0x60]
00007b4681bd8b0e  vmovaps xmm7, [rsp+0x70]
00007b4681bd8b14  vmovaps xmm8, [rsp+0x80]
00007b4681bd8b1d  vmovaps xmm10, [rsp+0x90]
00007b4681bd8b26  vmovaps xmm11, [rsp+0xA0]
00007b4681bd8b2f  vmovaps xmm12, [rsp+0xB0]
00007b4681bd8b38  vmovaps xmm13, [rsp+0xC0]
00007b4681bd8b41  vmovaps xmm14, [rsp+0xD0]
00007b4681bd8b4a  vmovaps xmm15, [rsp+0xE0]
00007b4681bd8b53  add rsp, 0xF0
00007b4681bd8b5a  pop r11
00007b4681bd8b5c  pop r10
00007b4681bd8b5e  pop r9
00007b4681bd8b60  pop r8
00007b4681bd8b62  pop rsi
00007b4681bd8b63  pop rdi
00007b4681bd8b64  pop rdx
00007b4681bd8b65  pop rcx
00007b4681bd8b66  pop rax
00007b4681bd8b67  add rsp, 0x08
00007b4681bd8b6b  jmp 0x00007B4681BD6ABC
00007b4681bd8b70  sub rsp, 0x08
00007b4681bd8b74  push rax
00007b4681bd8b75  push rcx
00007b4681bd8b76  push rdx
00007b4681bd8b77  push rdi
00007b4681bd8b78  push rsi
00007b4681bd8b79  push r8
00007b4681bd8b7b  push r9
00007b4681bd8b7d  push r10
00007b4681bd8b7f  push r11
00007b4681bd8b81  sub rsp, 0xF0
00007b4681bd8b88  vmovaps [rsp], xmm0
00007b4681bd8b8d  vmovaps [rsp+0x10], xmm1
00007b4681bd8b93  vmovaps [rsp+0x20], xmm2
00007b4681bd8b99  vmovaps [rsp+0x30], xmm3
00007b4681bd8b9f  vmovaps [rsp+0x40], xmm4
00007b4681bd8ba5  vmovaps [rsp+0x50], xmm5
00007b4681bd8bab  vmovaps [rsp+0x60], xmm6
00007b4681bd8bb1  vmovaps [rsp+0x70], xmm7
00007b4681bd8bb7  vmovaps [rsp+0x80], xmm8
00007b4681bd8bc0  vmovaps [rsp+0x90], xmm9
00007b4681bd8bc9  vmovaps [rsp+0xA0], xmm10
00007b4681bd8bd2  vmovaps [rsp+0xB0], xmm12
00007b4681bd8bdb  vmovaps [rsp+0xC0], xmm13
00007b4681bd8be4  vmovaps [rsp+0xD0], xmm14
00007b4681bd8bed  vmovaps [rsp+0xE0], xmm15
00007b4681bd8bf6  sub rsp, 0x40
00007b4681bd8bfa  lea rdi, [rsp]
00007b4681bd8bfe  lea rsi, [rsp+0x10]
00007b4681bd8c03  lea rdx, [rsp+0x20]
00007b4681bd8c08  lea rcx, [rsp+0x30]
00007b4681bd8c0d  mov r8d, 0x00
00007b4681bd8c13  lea r9, [r15+0x3A8]
00007b4681bd8c1a  movaps [rdi], xmm11
00007b4681bd8c1e  movaps [rsi], xmm10
00007b4681bd8c22  movaps [rdx], xmm8
00007b4681bd8c26  movaps [rcx], xmm1
00007b4681bd8c29  mov rax, 0x5668589B5A50
00007b4681bd8c33  call rax
00007b4681bd8c35  movaps xmm11, [rsp]
00007b4681bd8c3a  add rsp, 0x40
00007b4681bd8c3e  vmovaps xmm0, [rsp]
00007b4681bd8c43  vmovaps xmm1, [rsp+0x10]
00007b4681bd8c49  vmovaps xmm2, [rsp+0x20]
00007b4681bd8c4f  vmovaps xmm3, [rsp+0x30]
00007b4681bd8c55  vmovaps xmm4, [rsp+0x40]
00007b4681bd8c5b  vmovaps xmm5, [rsp+0x50]
00007b4681bd8c61  vmovaps xmm6, [rsp+0x60]
00007b4681bd8c67  vmovaps xmm7, [rsp+0x70]
00007b4681bd8c6d  vmovaps xmm8, [rsp+0x80]
00007b4681bd8c76  vmovaps xmm9, [rsp+0x90]
00007b4681bd8c7f  vmovaps xmm10, [rsp+0xA0]
00007b4681bd8c88  vmovaps xmm12, [rsp+0xB0]
00007b4681bd8c91  vmovaps xmm13, [rsp+0xC0]
00007b4681bd8c9a  vmovaps xmm14, [rsp+0xD0]
00007b4681bd8ca3  vmovaps xmm15, [rsp+0xE0]
00007b4681bd8cac  add rsp, 0xF0
00007b4681bd8cb3  pop r11
00007b4681bd8cb5  pop r10
00007b4681bd8cb7  pop r9
00007b4681bd8cb9  pop r8
00007b4681bd8cbb  pop rsi
00007b4681bd8cbc  pop rdi
00007b4681bd8cbd  pop rdx
00007b4681bd8cbe  pop rcx
00007b4681bd8cbf  pop rax
00007b4681bd8cc0  add rsp, 0x08
00007b4681bd8cc4  jmp 0x00007B4681BD6AE2
00007b4681bd8cc9  sub rsp, 0x08
00007b4681bd8ccd  push rax
00007b4681bd8cce  push rcx
00007b4681bd8ccf  push rdx
00007b4681bd8cd0  push rdi
00007b4681bd8cd1  push rsi
00007b4681bd8cd2  push r8
00007b4681bd8cd4  push r9
00007b4681bd8cd6  push r10
00007b4681bd8cd8  push r11
00007b4681bd8cda  sub rsp, 0xF0
00007b4681bd8ce1  vmovaps [rsp], xmm0
00007b4681bd8ce6  vmovaps [rsp+0x10], xmm1
00007b4681bd8cec  vmovaps [rsp+0x20], xmm2
00007b4681bd8cf2  vmovaps [rsp+0x30], xmm3
00007b4681bd8cf8  vmovaps [rsp+0x40], xmm4
00007b4681bd8cfe  vmovaps [rsp+0x50], xmm5
00007b4681bd8d04  vmovaps [rsp+0x60], xmm6
00007b4681bd8d0a  vmovaps [rsp+0x70], xmm7
00007b4681bd8d10  vmovaps [rsp+0x80], xmm8
00007b4681bd8d19  vmovaps [rsp+0x90], xmm9
00007b4681bd8d22  vmovaps [rsp+0xA0], xmm11
00007b4681bd8d2b  vmovaps [rsp+0xB0], xmm12
00007b4681bd8d34  vmovaps [rsp+0xC0], xmm13
00007b4681bd8d3d  vmovaps [rsp+0xD0], xmm14
00007b4681bd8d46  vmovaps [rsp+0xE0], xmm15
00007b4681bd8d4f  sub rsp, 0x40
00007b4681bd8d53  lea rdi, [rsp]
00007b4681bd8d57  lea rsi, [rsp+0x10]
00007b4681bd8d5c  lea rdx, [rsp+0x20]
00007b4681bd8d61  lea rcx, [rsp+0x30]
00007b4681bd8d66  mov r8d, 0x00
00007b4681bd8d6c  lea r9, [r15+0x3A8]
00007b4681bd8d73  movaps [rdi], xmm10
00007b4681bd8d77  movaps [rsi], xmm12
00007b4681bd8d7b  movaps [rdx], xmm13
00007b4681bd8d7f  movaps [rcx], xmm1
00007b4681bd8d82  mov rax, 0x5668589B5A50
00007b4681bd8d8c  call rax
00007b4681bd8d8e  movaps xmm10, [rsp]
00007b4681bd8d93  add rsp, 0x40
00007b4681bd8d97  vmovaps xmm0, [rsp]
00007b4681bd8d9c  vmovaps xmm1, [rsp+0x10]
00007b4681bd8da2  vmovaps xmm2, [rsp+0x20]
00007b4681bd8da8  vmovaps xmm3, [rsp+0x30]
00007b4681bd8dae  vmovaps xmm4, [rsp+0x40]
00007b4681bd8db4  vmovaps xmm5, [rsp+0x50]
00007b4681bd8dba  vmovaps xmm6, [rsp+0x60]
00007b4681bd8dc0  vmovaps xmm7, [rsp+0x70]
00007b4681bd8dc6  vmovaps xmm8, [rsp+0x80]
00007b4681bd8dcf  vmovaps xmm9, [rsp+0x90]
00007b4681bd8dd8  vmovaps xmm11, [rsp+0xA0]
00007b4681bd8de1  vmovaps xmm12, [rsp+0xB0]
00007b4681bd8dea  vmovaps xmm13, [rsp+0xC0]
00007b4681bd8df3  vmovaps xmm14, [rsp+0xD0]
00007b4681bd8dfc  vmovaps xmm15, [rsp+0xE0]
00007b4681bd8e05  add rsp, 0xF0
00007b4681bd8e0c  pop r11
00007b4681bd8e0e  pop r10
00007b4681bd8e10  pop r9
00007b4681bd8e12  pop r8
00007b4681bd8e14  pop rsi
00007b4681bd8e15  pop rdi
00007b4681bd8e16  pop rdx
00007b4681bd8e17  pop rcx
00007b4681bd8e18  pop rax
00007b4681bd8e19  add rsp, 0x08
00007b4681bd8e1d  jmp 0x00007B4681BD6B08
00007b4681bd8e22  call 0x00007B4681AD64F0
00007b4681bd8e27  jmp 0x00007B4681BD6B12
00007b4681bd8e2c  call 0x00007B4681AE3320
00007b4681bd8e31  jmp 0x00007B4681BD6B1C
00007b4681bd8e36  sub rsp, 0x08
00007b4681bd8e3a  push rax
00007b4681bd8e3b  push rcx
00007b4681bd8e3c  push rdx
00007b4681bd8e3d  push rdi
00007b4681bd8e3e  push rsi
00007b4681bd8e3f  push r8
00007b4681bd8e41  push r9
00007b4681bd8e43  push r10
00007b4681bd8e45  push r11
00007b4681bd8e47  sub rsp, 0xF0
00007b4681bd8e4e  vmovaps [rsp], xmm0
00007b4681bd8e53  vmovaps [rsp+0x10], xmm1
00007b4681bd8e59  vmovaps [rsp+0x20], xmm2
00007b4681bd8e5f  vmovaps [rsp+0x30], xmm3
00007b4681bd8e65  vmovaps [rsp+0x40], xmm4
00007b4681bd8e6b  vmovaps [rsp+0x50], xmm5
00007b4681bd8e71  vmovaps [rsp+0x60], xmm6
00007b4681bd8e77  vmovaps [rsp+0x70], xmm7
00007b4681bd8e7d  vmovaps [rsp+0x80], xmm9
00007b4681bd8e86  vmovaps [rsp+0x90], xmm10
00007b4681bd8e8f  vmovaps [rsp+0xA0], xmm11
00007b4681bd8e98  vmovaps [rsp+0xB0], xmm12
00007b4681bd8ea1  vmovaps [rsp+0xC0], xmm13
00007b4681bd8eaa  vmovaps [rsp+0xD0], xmm14
00007b4681bd8eb3  vmovaps [rsp+0xE0], xmm15
00007b4681bd8ebc  sub rsp, 0x40
00007b4681bd8ec0  lea rdi, [rsp]
00007b4681bd8ec4  lea rsi, [rsp+0x10]
00007b4681bd8ec9  lea rdx, [rsp+0x20]
00007b4681bd8ece  lea rcx, [rsp+0x30]
00007b4681bd8ed3  mov r8d, 0x00
00007b4681bd8ed9  lea r9, [r15+0x3A8]
00007b4681bd8ee0  movaps [rdi], xmm8
00007b4681bd8ee4  movaps [rsi], xmm7
00007b4681bd8ee7  movaps [rdx], xmm4
00007b4681bd8eea  movaps [rcx], xmm12
00007b4681bd8eee  mov rax, 0x5668589B5A50
00007b4681bd8ef8  call rax
00007b4681bd8efa  movaps xmm8, [rsp]
00007b4681bd8eff  add rsp, 0x40
00007b4681bd8f03  vmovaps xmm0, [rsp]
00007b4681bd8f08  vmovaps xmm1, [rsp+0x10]
00007b4681bd8f0e  vmovaps xmm2, [rsp+0x20]
00007b4681bd8f14  vmovaps xmm3, [rsp+0x30]
00007b4681bd8f1a  vmovaps xmm4, [rsp+0x40]
00007b4681bd8f20  vmovaps xmm5, [rsp+0x50]
00007b4681bd8f26  vmovaps xmm6, [rsp+0x60]
00007b4681bd8f2c  vmovaps xmm7, [rsp+0x70]
00007b4681bd8f32  vmovaps xmm9, [rsp+0x80]
00007b4681bd8f3b  vmovaps xmm10, [rsp+0x90]
00007b4681bd8f44  vmovaps xmm11, [rsp+0xA0]
00007b4681bd8f4d  vmovaps xmm12, [rsp+0xB0]
00007b4681bd8f56  vmovaps xmm13, [rsp+0xC0]
00007b4681bd8f5f  vmovaps xmm14, [rsp+0xD0]
00007b4681bd8f68  vmovaps xmm15, [rsp+0xE0]
00007b4681bd8f71  add rsp, 0xF0
00007b4681bd8f78  pop r11
00007b4681bd8f7a  pop r10
00007b4681bd8f7c  pop r9
00007b4681bd8f7e  pop r8
00007b4681bd8f80  pop rsi
00007b4681bd8f81  pop rdi
00007b4681bd8f82  pop rdx
00007b4681bd8f83  pop rcx
00007b4681bd8f84  pop rax
00007b4681bd8f85  add rsp, 0x08
00007b4681bd8f89  jmp 0x00007B4681BD6B45
00007b4681bd8f8e  sub rsp, 0x08
00007b4681bd8f92  push rax
00007b4681bd8f93  push rcx
00007b4681bd8f94  push rdx
00007b4681bd8f95  push rdi
00007b4681bd8f96  push rsi
00007b4681bd8f97  push r8
00007b4681bd8f99  push r9
00007b4681bd8f9b  push r10
00007b4681bd8f9d  push r11
00007b4681bd8f9f  sub rsp, 0xF0
00007b4681bd8fa6  vmovaps [rsp], xmm0
00007b4681bd8fab  vmovaps [rsp+0x10], xmm1
00007b4681bd8fb1  vmovaps [rsp+0x20], xmm2
00007b4681bd8fb7  vmovaps [rsp+0x30], xmm3
00007b4681bd8fbd  vmovaps [rsp+0x40], xmm4
00007b4681bd8fc3  vmovaps [rsp+0x50], xmm5
00007b4681bd8fc9  vmovaps [rsp+0x60], xmm6
00007b4681bd8fcf  vmovaps [rsp+0x70], xmm8
00007b4681bd8fd5  vmovaps [rsp+0x80], xmm9
00007b4681bd8fde  vmovaps [rsp+0x90], xmm10
00007b4681bd8fe7  vmovaps [rsp+0xA0], xmm11
00007b4681bd8ff0  vmovaps [rsp+0xB0], xmm12
00007b4681bd8ff9  vmovaps [rsp+0xC0], xmm13
00007b4681bd9002  vmovaps [rsp+0xD0], xmm14
00007b4681bd900b  vmovaps [rsp+0xE0], xmm15
00007b4681bd9014  sub rsp, 0x40
00007b4681bd9018  lea rdi, [rsp]
00007b4681bd901c  lea rsi, [rsp+0x10]
00007b4681bd9021  lea rdx, [rsp+0x20]
00007b4681bd9026  lea rcx, [rsp+0x30]
00007b4681bd902b  mov r8d, 0x00
00007b4681bd9031  lea r9, [r15+0x3A8]
00007b4681bd9038  movaps [rdi], xmm7
00007b4681bd903b  movaps [rsi], xmm9
00007b4681bd903f  movaps [rdx], xmm14
00007b4681bd9043  movaps [rcx], xmm12
00007b4681bd9047  mov rax, 0x5668589B5A50
00007b4681bd9051  call rax
00007b4681bd9053  movaps xmm7, [rsp]
00007b4681bd9057  add rsp, 0x40
00007b4681bd905b  vmovaps xmm0, [rsp]
00007b4681bd9060  vmovaps xmm1, [rsp+0x10]
00007b4681bd9066  vmovaps xmm2, [rsp+0x20]
00007b4681bd906c  vmovaps xmm3, [rsp+0x30]
00007b4681bd9072  vmovaps xmm4, [rsp+0x40]
00007b4681bd9078  vmovaps xmm5, [rsp+0x50]
00007b4681bd907e  vmovaps xmm6, [rsp+0x60]
00007b4681bd9084  vmovaps xmm8, [rsp+0x70]
00007b4681bd908a  vmovaps xmm9, [rsp+0x80]
00007b4681bd9093  vmovaps xmm10, [rsp+0x90]
00007b4681bd909c  vmovaps xmm11, [rsp+0xA0]
00007b4681bd90a5  vmovaps xmm12, [rsp+0xB0]
00007b4681bd90ae  vmovaps xmm13, [rsp+0xC0]
00007b4681bd90b7  vmovaps xmm14, [rsp+0xD0]
00007b4681bd90c0  vmovaps xmm15, [rsp+0xE0]
00007b4681bd90c9  add rsp, 0xF0
00007b4681bd90d0  pop r11
00007b4681bd90d2  pop r10
00007b4681bd90d4  pop r9
00007b4681bd90d6  pop r8
00007b4681bd90d8  pop rsi
00007b4681bd90d9  pop rdi
00007b4681bd90da  pop rdx
00007b4681bd90db  pop rcx
00007b4681bd90dc  pop rax
00007b4681bd90dd  add rsp, 0x08
00007b4681bd90e1  jmp 0x00007B4681BD6B6D
00007b4681bd90e6  sub rsp, 0x08
00007b4681bd90ea  push rax
00007b4681bd90eb  push rcx
00007b4681bd90ec  push rdx
00007b4681bd90ed  push rdi
00007b4681bd90ee  push rsi
00007b4681bd90ef  push r8
00007b4681bd90f1  push r9
00007b4681bd90f3  push r10
00007b4681bd90f5  push r11
00007b4681bd90f7  sub rsp, 0xF0
00007b4681bd90fe  vmovaps [rsp], xmm0
00007b4681bd9103  vmovaps [rsp+0x10], xmm1
00007b4681bd9109  vmovaps [rsp+0x20], xmm2
00007b4681bd910f  vmovaps [rsp+0x30], xmm3
00007b4681bd9115  vmovaps [rsp+0x40], xmm4
00007b4681bd911b  vmovaps [rsp+0x50], xmm5
00007b4681bd9121  vmovaps [rsp+0x60], xmm6
00007b4681bd9127  vmovaps [rsp+0x70], xmm7
00007b4681bd912d  vmovaps [rsp+0x80], xmm8
00007b4681bd9136  vmovaps [rsp+0x90], xmm9
00007b4681bd913f  vmovaps [rsp+0xA0], xmm10
00007b4681bd9148  vmovaps [rsp+0xB0], xmm11
00007b4681bd9151  vmovaps [rsp+0xC0], xmm13
00007b4681bd915a  vmovaps [rsp+0xD0], xmm14
00007b4681bd9163  vmovaps [rsp+0xE0], xmm15
00007b4681bd916c  sub rsp, 0x40
00007b4681bd9170  lea rdi, [rsp]
00007b4681bd9174  lea rsi, [rsp+0x10]
00007b4681bd9179  lea rdx, [rsp+0x20]
00007b4681bd917e  lea rcx, [rsp+0x30]
00007b4681bd9183  mov r8d, 0x00
00007b4681bd9189  lea r9, [r15+0x3A8]
00007b4681bd9190  movaps [rdi], xmm12
00007b4681bd9194  movaps [rsi], xmm11
00007b4681bd9198  movaps [rdx], xmm15
00007b4681bd919c  movaps [rcx], xmm14
00007b4681bd91a0  mov rax, 0x5668589B5A50
00007b4681bd91aa  call rax
00007b4681bd91ac  movaps xmm12, [rsp]
00007b4681bd91b1  add rsp, 0x40
00007b4681bd91b5  vmovaps xmm0, [rsp]
00007b4681bd91ba  vmovaps xmm1, [rsp+0x10]
00007b4681bd91c0  vmovaps xmm2, [rsp+0x20]
00007b4681bd91c6  vmovaps xmm3, [rsp+0x30]
00007b4681bd91cc  vmovaps xmm4, [rsp+0x40]
00007b4681bd91d2  vmovaps xmm5, [rsp+0x50]
00007b4681bd91d8  vmovaps xmm6, [rsp+0x60]
00007b4681bd91de  vmovaps xmm7, [rsp+0x70]
00007b4681bd91e4  vmovaps xmm8, [rsp+0x80]
00007b4681bd91ed  vmovaps xmm9, [rsp+0x90]
00007b4681bd91f6  vmovaps xmm10, [rsp+0xA0]
00007b4681bd91ff  vmovaps xmm11, [rsp+0xB0]
00007b4681bd9208  vmovaps xmm13, [rsp+0xC0]
00007b4681bd9211  vmovaps xmm14, [rsp+0xD0]
00007b4681bd921a  vmovaps xmm15, [rsp+0xE0]
00007b4681bd9223  add rsp, 0xF0
00007b4681bd922a  pop r11
00007b4681bd922c  pop r10
00007b4681bd922e  pop r9
00007b4681bd9230  pop r8
00007b4681bd9232  pop rsi
00007b4681bd9233  pop rdi
00007b4681bd9234  pop rdx
00007b4681bd9235  pop rcx
00007b4681bd9236  pop rax
00007b4681bd9237  add rsp, 0x08
00007b4681bd923b  jmp 0x00007B4681BD6B96
00007b4681bd9240  sub rsp, 0x08
00007b4681bd9244  push rax
00007b4681bd9245  push rcx
00007b4681bd9246  push rdx
00007b4681bd9247  push rdi
00007b4681bd9248  push rsi
00007b4681bd9249  push r8
00007b4681bd924b  push r9
00007b4681bd924d  push r10
00007b4681bd924f  push r11
00007b4681bd9251  sub rsp, 0xF0
00007b4681bd9258  vmovaps [rsp], xmm0
00007b4681bd925d  vmovaps [rsp+0x10], xmm1
00007b4681bd9263  vmovaps [rsp+0x20], xmm2
00007b4681bd9269  vmovaps [rsp+0x30], xmm3
00007b4681bd926f  vmovaps [rsp+0x40], xmm4
00007b4681bd9275  vmovaps [rsp+0x50], xmm5
00007b4681bd927b  vmovaps [rsp+0x60], xmm6
00007b4681bd9281  vmovaps [rsp+0x70], xmm7
00007b4681bd9287  vmovaps [rsp+0x80], xmm8
00007b4681bd9290  vmovaps [rsp+0x90], xmm9
00007b4681bd9299  vmovaps [rsp+0xA0], xmm10
00007b4681bd92a2  vmovaps [rsp+0xB0], xmm12
00007b4681bd92ab  vmovaps [rsp+0xC0], xmm13
00007b4681bd92b4  vmovaps [rsp+0xD0], xmm14
00007b4681bd92bd  vmovaps [rsp+0xE0], xmm15
00007b4681bd92c6  sub rsp, 0x40
00007b4681bd92ca  lea rdi, [rsp]
00007b4681bd92ce  lea rsi, [rsp+0x10]
00007b4681bd92d3  lea rdx, [rsp+0x20]
00007b4681bd92d8  lea rcx, [rsp+0x30]
00007b4681bd92dd  mov r8d, 0x00
00007b4681bd92e3  lea r9, [r15+0x3A8]
00007b4681bd92ea  movaps [rdi], xmm11
00007b4681bd92ee  movaps [rsi], xmm10
00007b4681bd92f2  movaps [rdx], xmm13
00007b4681bd92f6  movaps [rcx], xmm15
00007b4681bd92fa  mov rax, 0x5668589B5A50
00007b4681bd9304  call rax
00007b4681bd9306  movaps xmm11, [rsp]
00007b4681bd930b  add rsp, 0x40
00007b4681bd930f  vmovaps xmm0, [rsp]
00007b4681bd9314  vmovaps xmm1, [rsp+0x10]
00007b4681bd931a  vmovaps xmm2, [rsp+0x20]
00007b4681bd9320  vmovaps xmm3, [rsp+0x30]
00007b4681bd9326  vmovaps xmm4, [rsp+0x40]
00007b4681bd932c  vmovaps xmm5, [rsp+0x50]
00007b4681bd9332  vmovaps xmm6, [rsp+0x60]
00007b4681bd9338  vmovaps xmm7, [rsp+0x70]
00007b4681bd933e  vmovaps xmm8, [rsp+0x80]
00007b4681bd9347  vmovaps xmm9, [rsp+0x90]
00007b4681bd9350  vmovaps xmm10, [rsp+0xA0]
00007b4681bd9359  vmovaps xmm12, [rsp+0xB0]
00007b4681bd9362  vmovaps xmm13, [rsp+0xC0]
00007b4681bd936b  vmovaps xmm14, [rsp+0xD0]
00007b4681bd9374  vmovaps xmm15, [rsp+0xE0]
00007b4681bd937d  add rsp, 0xF0
00007b4681bd9384  pop r11
00007b4681bd9386  pop r10
00007b4681bd9388  pop r9
00007b4681bd938a  pop r8
00007b4681bd938c  pop rsi
00007b4681bd938d  pop rdi
00007b4681bd938e  pop rdx
00007b4681bd938f  pop rcx
00007b4681bd9390  pop rax
00007b4681bd9391  add rsp, 0x08
00007b4681bd9395  jmp 0x00007B4681BD6BBF
00007b4681bd939a  call 0x00007B4681AE5820
00007b4681bd939f  jmp 0x00007B4681BD6BCC
00007b4681bd93a4  call 0x00007B4681AE45A0
00007b4681bd93a9  jmp 0x00007B4681BD6BD9
00007b4681bd93ae  sub rsp, 0x08
00007b4681bd93b2  push rax
00007b4681bd93b3  push rcx
00007b4681bd93b4  push rdx
00007b4681bd93b5  push rdi
00007b4681bd93b6  push rsi
00007b4681bd93b7  push r8
00007b4681bd93b9  push r9
00007b4681bd93bb  push r10
00007b4681bd93bd  push r11
00007b4681bd93bf  sub rsp, 0xF0
00007b4681bd93c6  vmovaps [rsp], xmm0
00007b4681bd93cb  vmovaps [rsp+0x10], xmm1
00007b4681bd93d1  vmovaps [rsp+0x20], xmm2
00007b4681bd93d7  vmovaps [rsp+0x30], xmm3
00007b4681bd93dd  vmovaps [rsp+0x40], xmm4
00007b4681bd93e3  vmovaps [rsp+0x50], xmm5
00007b4681bd93e9  vmovaps [rsp+0x60], xmm6
00007b4681bd93ef  vmovaps [rsp+0x70], xmm7
00007b4681bd93f5  vmovaps [rsp+0x80], xmm8
00007b4681bd93fe  vmovaps [rsp+0x90], xmm9
00007b4681bd9407  vmovaps [rsp+0xA0], xmm11
00007b4681bd9410  vmovaps [rsp+0xB0], xmm12
00007b4681bd9419  vmovaps [rsp+0xC0], xmm13
00007b4681bd9422  vmovaps [rsp+0xD0], xmm14
00007b4681bd942b  vmovaps [rsp+0xE0], xmm15
00007b4681bd9434  sub rsp, 0x40
00007b4681bd9438  lea rdi, [rsp]
00007b4681bd943c  lea rsi, [rsp+0x10]
00007b4681bd9441  lea rdx, [rsp+0x20]
00007b4681bd9446  lea rcx, [rsp+0x30]
00007b4681bd944b  mov r8d, 0x00
00007b4681bd9451  lea r9, [r15+0x3A8]
00007b4681bd9458  movaps [rdi], xmm10
00007b4681bd945c  movaps [rsi], xmm8
00007b4681bd9460  movaps [rdx], xmm1
00007b4681bd9463  movaps [rcx], xmm13
00007b4681bd9467  mov rax, 0x5668589B5A50
00007b4681bd9471  call rax
00007b4681bd9473  movaps xmm10, [rsp]
00007b4681bd9478  add rsp, 0x40
00007b4681bd947c  vmovaps xmm0, [rsp]
00007b4681bd9481  vmovaps xmm1, [rsp+0x10]
00007b4681bd9487  vmovaps xmm2, [rsp+0x20]
00007b4681bd948d  vmovaps xmm3, [rsp+0x30]
00007b4681bd9493  vmovaps xmm4, [rsp+0x40]
00007b4681bd9499  vmovaps xmm5, [rsp+0x50]
00007b4681bd949f  vmovaps xmm6, [rsp+0x60]
00007b4681bd94a5  vmovaps xmm7, [rsp+0x70]
00007b4681bd94ab  vmovaps xmm8, [rsp+0x80]
00007b4681bd94b4  vmovaps xmm9, [rsp+0x90]
00007b4681bd94bd  vmovaps xmm11, [rsp+0xA0]
00007b4681bd94c6  vmovaps xmm12, [rsp+0xB0]
00007b4681bd94cf  vmovaps xmm13, [rsp+0xC0]
00007b4681bd94d8  vmovaps xmm14, [rsp+0xD0]
00007b4681bd94e1  vmovaps xmm15, [rsp+0xE0]
00007b4681bd94ea  add rsp, 0xF0
00007b4681bd94f1  pop r11
00007b4681bd94f3  pop r10
00007b4681bd94f5  pop r9
00007b4681bd94f7  pop r8
00007b4681bd94f9  pop rsi
00007b4681bd94fa  pop rdi
00007b4681bd94fb  pop rdx
00007b4681bd94fc  pop rcx
00007b4681bd94fd  pop rax
00007b4681bd94fe  add rsp, 0x08
00007b4681bd9502  jmp 0x00007B4681BD6C0F
00007b4681bd9507  call 0x00007B4681AD64F0
00007b4681bd950c  jmp 0x00007B4681BD6C21
00007b4681bd9511  sub rsp, 0x08
00007b4681bd9515  push rax
00007b4681bd9516  push rcx
00007b4681bd9517  push rdx
00007b4681bd9518  push rdi
00007b4681bd9519  push rsi
00007b4681bd951a  push r8
00007b4681bd951c  push r9
00007b4681bd951e  push r10
00007b4681bd9520  push r11
00007b4681bd9522  sub rsp, 0xF0
00007b4681bd9529  vmovaps [rsp], xmm0
00007b4681bd952e  vmovaps [rsp+0x10], xmm1
00007b4681bd9534  vmovaps [rsp+0x20], xmm2
00007b4681bd953a  vmovaps [rsp+0x30], xmm3
00007b4681bd9540  vmovaps [rsp+0x40], xmm4
00007b4681bd9546  vmovaps [rsp+0x50], xmm5
00007b4681bd954c  vmovaps [rsp+0x60], xmm6
00007b4681bd9552  vmovaps [rsp+0x70], xmm7
00007b4681bd9558  vmovaps [rsp+0x80], xmm8
00007b4681bd9561  vmovaps [rsp+0x90], xmm10
00007b4681bd956a  vmovaps [rsp+0xA0], xmm11
00007b4681bd9573  vmovaps [rsp+0xB0], xmm12
00007b4681bd957c  vmovaps [rsp+0xC0], xmm13
00007b4681bd9585  vmovaps [rsp+0xD0], xmm14
00007b4681bd958e  vmovaps [rsp+0xE0], xmm15
00007b4681bd9597  sub rsp, 0x40
00007b4681bd959b  lea rdi, [rsp]
00007b4681bd959f  lea rsi, [rsp+0x10]
00007b4681bd95a4  lea rdx, [rsp+0x20]
00007b4681bd95a9  lea rcx, [rsp+0x30]
00007b4681bd95ae  mov r8d, 0x00
00007b4681bd95b4  lea r9, [r15+0x3A8]
00007b4681bd95bb  movaps [rdi], xmm9
00007b4681bd95bf  movaps [rsi], xmm7
00007b4681bd95c2  movaps [rdx], xmm14
00007b4681bd95c6  movaps [rcx], xmm13
00007b4681bd95ca  mov rax, 0x5668589B5A50
00007b4681bd95d4  call rax
00007b4681bd95d6  movaps xmm9, [rsp]
00007b4681bd95db  add rsp, 0x40
00007b4681bd95df  vmovaps xmm0, [rsp]
00007b4681bd95e4  vmovaps xmm1, [rsp+0x10]
00007b4681bd95ea  vmovaps xmm2, [rsp+0x20]
00007b4681bd95f0  vmovaps xmm3, [rsp+0x30]
00007b4681bd95f6  vmovaps xmm4, [rsp+0x40]
00007b4681bd95fc  vmovaps xmm5, [rsp+0x50]
00007b4681bd9602  vmovaps xmm6, [rsp+0x60]
00007b4681bd9608  vmovaps xmm7, [rsp+0x70]
00007b4681bd960e  vmovaps xmm8, [rsp+0x80]
00007b4681bd9617  vmovaps xmm10, [rsp+0x90]
00007b4681bd9620  vmovaps xmm11, [rsp+0xA0]
00007b4681bd9629  vmovaps xmm12, [rsp+0xB0]
00007b4681bd9632  vmovaps xmm13, [rsp+0xC0]
00007b4681bd963b  vmovaps xmm14, [rsp+0xD0]
00007b4681bd9644  vmovaps xmm15, [rsp+0xE0]
00007b4681bd964d  add rsp, 0xF0
00007b4681bd9654  pop r11
00007b4681bd9656  pop r10
00007b4681bd9658  pop r9
00007b4681bd965a  pop r8
00007b4681bd965c  pop rsi
00007b4681bd965d  pop rdi
00007b4681bd965e  pop rdx
00007b4681bd965f  pop rcx
00007b4681bd9660  pop rax
00007b4681bd9661  add rsp, 0x08
00007b4681bd9665  jmp 0x00007B4681BD6C4F
00007b4681bd966a  sub rsp, 0x08
00007b4681bd966e  push rax
00007b4681bd966f  push rcx
00007b4681bd9670  push rdx
00007b4681bd9671  push rdi
00007b4681bd9672  push rsi
00007b4681bd9673  push r8
00007b4681bd9675  push r9
00007b4681bd9677  push r10
00007b4681bd9679  push r11
00007b4681bd967b  sub rsp, 0xF0
00007b4681bd9682  vmovaps [rsp], xmm0
00007b4681bd9687  vmovaps [rsp+0x10], xmm1
00007b4681bd968d  vmovaps [rsp+0x20], xmm2
00007b4681bd9693  vmovaps [rsp+0x30], xmm3
00007b4681bd9699  vmovaps [rsp+0x40], xmm4
00007b4681bd969f  vmovaps [rsp+0x50], xmm5
00007b4681bd96a5  vmovaps [rsp+0x60], xmm6
00007b4681bd96ab  vmovaps [rsp+0x70], xmm7
00007b4681bd96b1  vmovaps [rsp+0x80], xmm8
00007b4681bd96ba  vmovaps [rsp+0x90], xmm9
00007b4681bd96c3  vmovaps [rsp+0xA0], xmm10
00007b4681bd96cc  vmovaps [rsp+0xB0], xmm11
00007b4681bd96d5  vmovaps [rsp+0xC0], xmm12
00007b4681bd96de  vmovaps [rsp+0xD0], xmm14
00007b4681bd96e7  vmovaps [rsp+0xE0], xmm15
00007b4681bd96f0  sub rsp, 0x40
00007b4681bd96f4  lea rdi, [rsp]
00007b4681bd96f8  lea rsi, [rsp+0x10]
00007b4681bd96fd  lea rdx, [rsp+0x20]
00007b4681bd9702  lea rcx, [rsp+0x30]
00007b4681bd9707  mov r8d, 0x00
00007b4681bd970d  lea r9, [r15+0x3A8]
00007b4681bd9714  movaps [rdi], xmm13
00007b4681bd9718  movaps [rsi], xmm12
00007b4681bd971c  movaps [rdx], xmm15
00007b4681bd9720  movaps [rcx], xmm14
00007b4681bd9724  mov rax, 0x5668589B5A50
00007b4681bd972e  call rax
00007b4681bd9730  movaps xmm13, [rsp]
00007b4681bd9735  add rsp, 0x40
00007b4681bd9739  vmovaps xmm0, [rsp]
00007b4681bd973e  vmovaps xmm1, [rsp+0x10]
00007b4681bd9744  vmovaps xmm2, [rsp+0x20]
00007b4681bd974a  vmovaps xmm3, [rsp+0x30]
00007b4681bd9750  vmovaps xmm4, [rsp+0x40]
00007b4681bd9756  vmovaps xmm5, [rsp+0x50]
00007b4681bd975c  vmovaps xmm6, [rsp+0x60]
00007b4681bd9762  vmovaps xmm7, [rsp+0x70]
00007b4681bd9768  vmovaps xmm8, [rsp+0x80]
00007b4681bd9771  vmovaps xmm9, [rsp+0x90]
00007b4681bd977a  vmovaps xmm10, [rsp+0xA0]
00007b4681bd9783  vmovaps xmm11, [rsp+0xB0]
00007b4681bd978c  vmovaps xmm12, [rsp+0xC0]
00007b4681bd9795  vmovaps xmm14, [rsp+0xD0]
00007b4681bd979e  vmovaps xmm15, [rsp+0xE0]
00007b4681bd97a7  add rsp, 0xF0
00007b4681bd97ae  pop r11
00007b4681bd97b0  pop r10
00007b4681bd97b2  pop r9
00007b4681bd97b4  pop r8
00007b4681bd97b6  pop rsi
00007b4681bd97b7  pop rdi
00007b4681bd97b8  pop rdx
00007b4681bd97b9  pop rcx
00007b4681bd97ba  pop rax
00007b4681bd97bb  add rsp, 0x08
00007b4681bd97bf  jmp 0x00007B4681BD6C7D
00007b4681bd97c4  sub rsp, 0x08
00007b4681bd97c8  push rax
00007b4681bd97c9  push rcx
00007b4681bd97ca  push rdx
00007b4681bd97cb  push rdi
00007b4681bd97cc  push rsi
00007b4681bd97cd  push r8
00007b4681bd97cf  push r9
00007b4681bd97d1  push r10
00007b4681bd97d3  push r11
00007b4681bd97d5  sub rsp, 0xF0
00007b4681bd97dc  vmovaps [rsp], xmm0
00007b4681bd97e1  vmovaps [rsp+0x10], xmm1
00007b4681bd97e7  vmovaps [rsp+0x20], xmm2
00007b4681bd97ed  vmovaps [rsp+0x30], xmm3
00007b4681bd97f3  vmovaps [rsp+0x40], xmm4
00007b4681bd97f9  vmovaps [rsp+0x50], xmm5
00007b4681bd97ff  vmovaps [rsp+0x60], xmm6
00007b4681bd9805  vmovaps [rsp+0x70], xmm7
00007b4681bd980b  vmovaps [rsp+0x80], xmm8
00007b4681bd9814  vmovaps [rsp+0x90], xmm9
00007b4681bd981d  vmovaps [rsp+0xA0], xmm10
00007b4681bd9826  vmovaps [rsp+0xB0], xmm11
00007b4681bd982f  vmovaps [rsp+0xC0], xmm12
00007b4681bd9838  vmovaps [rsp+0xD0], xmm13
00007b4681bd9841  vmovaps [rsp+0xE0], xmm15
00007b4681bd984a  sub rsp, 0x40
00007b4681bd984e  lea rdi, [rsp]
00007b4681bd9852  lea rsi, [rsp+0x10]
00007b4681bd9857  lea rdx, [rsp+0x20]
00007b4681bd985c  lea rcx, [rsp+0x30]
00007b4681bd9861  mov r8d, 0x00
00007b4681bd9867  lea r9, [r15+0x3A8]
00007b4681bd986e  movaps [rdi], xmm14
00007b4681bd9872  movaps [rsi], xmm11
00007b4681bd9876  movaps [rdx], xmm1
00007b4681bd9879  movaps [rcx], xmm15
00007b4681bd987d  mov rax, 0x5668589B5A50
00007b4681bd9887  call rax
00007b4681bd9889  movaps xmm14, [rsp]
00007b4681bd988e  add rsp, 0x40
00007b4681bd9892  vmovaps xmm0, [rsp]
00007b4681bd9897  vmovaps xmm1, [rsp+0x10]
00007b4681bd989d  vmovaps xmm2, [rsp+0x20]
00007b4681bd98a3  vmovaps xmm3, [rsp+0x30]
00007b4681bd98a9  vmovaps xmm4, [rsp+0x40]
00007b4681bd98af  vmovaps xmm5, [rsp+0x50]
00007b4681bd98b5  vmovaps xmm6, [rsp+0x60]
00007b4681bd98bb  vmovaps xmm7, [rsp+0x70]
00007b4681bd98c1  vmovaps xmm8, [rsp+0x80]
00007b4681bd98ca  vmovaps xmm9, [rsp+0x90]
00007b4681bd98d3  vmovaps xmm10, [rsp+0xA0]
00007b4681bd98dc  vmovaps xmm11, [rsp+0xB0]
00007b4681bd98e5  vmovaps xmm12, [rsp+0xC0]
00007b4681bd98ee  vmovaps xmm13, [rsp+0xD0]
00007b4681bd98f7  vmovaps xmm15, [rsp+0xE0]
00007b4681bd9900  add rsp, 0xF0
00007b4681bd9907  pop r11
00007b4681bd9909  pop r10
00007b4681bd990b  pop r9
00007b4681bd990d  pop r8
00007b4681bd990f  pop rsi
00007b4681bd9910  pop rdi
00007b4681bd9911  pop rdx
00007b4681bd9912  pop rcx
00007b4681bd9913  pop rax
00007b4681bd9914  add rsp, 0x08
00007b4681bd9918  jmp 0x00007B4681BD6CAB
00007b4681bd991d  call 0x00007B4681AACF70
00007b4681bd9922  jmp 0x00007B4681BD6CB9
00007b4681bd9927  call 0x00007B4681A0C380
00007b4681bd992c  jmp 0x00007B4681BD6CC3
00007b4681bd9931  call 0x00007B4681A08C20
00007b4681bd9936  jmp 0x00007B4681BD6CCD
00007b4681bd993b  call 0x00007B4681A0D600
00007b4681bd9940  jmp 0x00007B4681BD6CD7
00007b4681bd9945  int3
00007b4681bd9946  nop [rax+rax*1], ax
00007b4681bd994f  nop
00007b4681bd9950  mov eax, [r15+0x48]
00007b4681bd9954  lea r14d, [eax+0x01]
00007b4681bd9959  mov [rsp+0x10], r14d
00007b4681bd995e  mov r14d, r14d
00007b4681bd9961  mov [r15+0x48], r14
00007b4681bd9965  xor eax, eax
00007b4681bd9967  mov r14d, [rsp+0x10]
00007b4681bd996c  cmp r14d, 0x1F4
00007b4681bd9973  cmc
00007b4681bd9974  lahf
00007b4681bd9975  seto al
00007b4681bd9978  mov [r15+0x108], eax
00007b4681bd997f  mov eax, [r15+0x108]
00007b4681bd9986  sahf
00007b4681bd9987  jnz 0x00007B4681BD99B9
00007b4681bd9989  cmp dword ptr [r15+0x318], 0x00
00007b4681bd9991  jz 0x00007B4681BDD2E0
00007b4681bd9997  nop [rax+rax*1], ax
00007b4681bd99a0  nop [rax+rax*1], eax
00007b4681bd99a8  mov eax, 0x410670
00007b4681bd99ad  mov [r15+0x100], rax
00007b4681bd99b4  jmp 0x00007B46819FE110
00007b4681bd99b9  cmp dword ptr [r15+0x318], 0x00
00007b4681bd99c1  jz 0x00007B4681BD99F0
00007b4681bd99c7  nop [rax+rax*1], ax
00007b4681bd99d0  nop [rax+rax*1], eax
00007b4681bd99d8  mov eax, 0x4104EC
00007b4681bd99dd  mov [r15+0x100], rax
00007b4681bd99e4  jmp 0x00007B46819FE110
00007b4681bd99e9  int3
00007b4681bd99ea  int3
00007b4681bd99eb  nop [rax+rax*1], eax
00007b4681bd99f0  mov rax, [r15+0x40]
00007b4681bd99f4  vxorps xmm1, xmm1, xmm1
00007b4681bd99f8  vpbroadcastq xmm1, xmm1
00007b4681bd99fd  vxorps xmm15, xmm15, xmm15
00007b4681bd9a02  vpbroadcastq xmm15, xmm15
00007b4681bd9a07  lea r14, [rax+0x30]
00007b4681bd9a0b  mov r12, [r13+r14*1]
00007b4681bd9a10  lea r14, [rax+0x38]
00007b4681bd9a14  mov r11, [r13+r14*1]
00007b4681bd9a19  movq xmm14, r12
00007b4681bd9a1e  movq xmm13, r11
00007b4681bd9a23  movq xmm14, xmm14
00007b4681bd9a28  movq xmm13, xmm13
00007b4681bd9a2d  vmovaps [rsp+0x10], xmm13
00007b4681bd9a33  movq xmm13, xmm13
00007b4681bd9a38  movaps [r15+0x270], xmm13
00007b4681bd9a40  movaps xmm13, [r15+0x160]
00007b4681bd9a48  vmovaps [rsp+0x20], xmm13
00007b4681bd9a4e  vmovaps xmm12, [rsp+0x20]
00007b4681bd9a54  por xmm13, xmm12
00007b4681bd9a59  lea r14, [rax+0x20]
00007b4681bd9a5d  mov r12, [r13+r14*1]
00007b4681bd9a62  lea r14, [rax+0x28]
00007b4681bd9a66  mov r11, [r13+r14*1]
00007b4681bd9a6b  movq xmm12, r12
00007b4681bd9a70  movq xmm11, r11
00007b4681bd9a75  movq xmm12, xmm12
00007b4681bd9a7a  movq xmm11, xmm11
00007b4681bd9a7f  movaps xmm10, [r15+0x2D0]
00007b4681bd9a87  vmovaps [rsp+0x20], xmm10
00007b4681bd9a8d  vmovaps xmm9, [rsp+0x20]
00007b4681bd9a93  por xmm10, xmm9
00007b4681bd9a98  movaps xmm9, [r15+0x300]
00007b4681bd9aa0  vmovaps [rsp+0x20], xmm9
00007b4681bd9aa6  vmovaps xmm8, [rsp+0x20]
00007b4681bd9aac  por xmm9, xmm8
00007b4681bd9ab1  movaps xmm8, [r15+0x2B0]
00007b4681bd9ab9  vmovaps [rsp+0x20], xmm8
00007b4681bd9abf  vmovaps xmm7, [rsp+0x20]
00007b4681bd9ac5  por xmm8, xmm7
00007b4681bd9aca  movaps xmm7, [r15+0x180]
00007b4681bd9ad2  vmovaps [rsp+0x20], xmm7
00007b4681bd9ad8  vmovaps xmm6, [rsp+0x20]
00007b4681bd9ade  por xmm7, xmm6
00007b4681bd9ae2  lea r14, [rax+0x10]
00007b4681bd9ae6  mov r12, [r13+r14*1]
00007b4681bd9aeb  lea r14, [rax+0x18]
00007b4681bd9aef  mov r11, [r13+r14*1]
00007b4681bd9af4  movq xmm6, r12
00007b4681bd9af9  movq xmm5, r11
00007b4681bd9afe  movq xmm6, xmm6
00007b4681bd9b02  movq xmm5, xmm5
00007b4681bd9b06  movaps xmm4, [r15+0x200]
00007b4681bd9b0e  vmovaps [rsp+0x20], xmm4
00007b4681bd9b14  vmovaps xmm3, [rsp+0x20]
00007b4681bd9b1a  por xmm4, xmm3
00007b4681bd9b1e  movaps xmm3, [r15+0x1F0]
00007b4681bd9b26  vmovaps [rsp+0x20], xmm3
00007b4681bd9b2c  vmovaps xmm2, [rsp+0x20]
00007b4681bd9b32  por xmm3, xmm2
00007b4681bd9b36  movaps xmm2, [r15+0x2E0]
00007b4681bd9b3e  vmovaps [rsp+0x20], xmm2
00007b4681bd9b44  vmovaps [rsp+0x30], xmm1
00007b4681bd9b4a  vmovaps xmm1, [rsp+0x20]
00007b4681bd9b50  por xmm2, xmm1
00007b4681bd9b54  movaps xmm1, [r15+0x2A0]
00007b4681bd9b5c  vmovaps [rsp+0x20], xmm1
00007b4681bd9b62  vmovaps [rsp+0x40], xmm15
00007b4681bd9b68  vmovaps xmm15, [rsp+0x20]
00007b4681bd9b6e  por xmm1, xmm15
00007b4681bd9b73  movaps xmm15, [r15+0x280]
00007b4681bd9b7b  vmovaps [rsp+0x20], xmm15
00007b4681bd9b81  vmovaps [rsp+0x50], xmm1
00007b4681bd9b87  vmovaps xmm1, [rsp+0x20]
00007b4681bd9b8d  por xmm15, xmm1
00007b4681bd9b92  movaps xmm1, [r15+0x1C0]
00007b4681bd9b9a  vmovaps [rsp+0x20], xmm1
00007b4681bd9ba0  vmovaps [rsp+0x60], xmm15
00007b4681bd9ba6  vmovaps xmm15, [rsp+0x20]
00007b4681bd9bac  por xmm1, xmm15
00007b4681bd9bb1  movaps xmm15, [r15+0x210]
00007b4681bd9bb9  vmovaps [rsp+0x20], xmm15
00007b4681bd9bbf  vmovaps [rsp+0x70], xmm1
00007b4681bd9bc5  vmovaps xmm1, [rsp+0x20]
00007b4681bd9bcb  por xmm15, xmm1
00007b4681bd9bd0  mov r14, [r13+rax*1]
00007b4681bd9bd5  vmovq xmm1, r14
00007b4681bd9bda  vpbroadcastq xmm1, xmm1
00007b4681bd9bdf  vmovaps [rsp+0x20], xmm1
00007b4681bd9be5  vxorps xmm1, xmm1, xmm1
00007b4681bd9be9  vpbroadcastq xmm1, xmm1
00007b4681bd9bee  mov r14, [r15+0xF8]
00007b4681bd9bf5  vmovaps [rsp+0x80], xmm1
00007b4681bd9bfe  movups xmm1, [r13+r14*1]
00007b4681bd9c04  vmovaps [rsp+0x90], xmm1
00007b4681bd9c0d  vxorps xmm1, xmm1, xmm1
00007b4681bd9c11  vpbroadcastq xmm1, xmm1
00007b4681bd9c16  lea r12, [rax+0x08]
00007b4681bd9c1a  mov rax, [r13+r12*1]
00007b4681bd9c1f  vmovaps [rsp+0xA0], xmm1
00007b4681bd9c28  movq xmm1, rax
00007b4681bd9c2d  movaps [r15+0x240], xmm1
00007b4681bd9c35  mov rax, [r15+0x50]
00007b4681bd9c39  mov [r15+0x60], rax
00007b4681bd9c3d  mov qword ptr [r15+0x58], 0x40
00007b4681bd9c45  vmovaps xmm1, [rsp+0x30]
00007b4681bd9c4b  vmovaps [rsp+0x30], xmm15
00007b4681bd9c51  vmovaps xmm15, [rsp+0x90]
00007b4681bd9c5a  vmovaps [rsp+0x90], xmm14
00007b4681bd9c63  vmovaps xmm14, [rsp+0x20]
00007b4681bd9c69  vmovaps [rsp+0x20], xmm13
00007b4681bd9c6f  vmovaps [rsp+0xB0], xmm12
00007b4681bd9c78  movaps xmm13, xmm1
00007b4681bd9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd9c87  vptest xmm12, xmm12
00007b4681bd9c8c  jnz 0x00007B4681BDA72F
00007b4681bd9c92  movaps xmm1, [r15+0x250]
00007b4681bd9c9a  vmovaps xmm15, [rsp+0x40]
00007b4681bd9ca0  vmovaps [rsp+0x40], xmm13
00007b4681bd9ca6  movaps xmm12, xmm15
00007b4681bd9caa  vfmadd231pd xmm12, xmm1, xmm14
00007b4681bd9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007b4681bd9cb5  vptest xmm13, xmm13
00007b4681bd9cba  jnz 0x00007B4681BDA888
00007b4681bd9cc0  movaps xmm15, [r15+0x1E0]
00007b4681bd9cc8  vmovaps [rsp+0xC0], xmm15
00007b4681bd9cd1  vmovaps xmm13, [rsp+0xC0]
00007b4681bd9cda  por xmm15, xmm13
00007b4681bd9cdf  movaps xmm13, [r15+0x1D0]
00007b4681bd9ce7  vmovaps [rsp+0xC0], xmm13
00007b4681bd9cf0  vmovaps [rsp+0xD0], xmm1
00007b4681bd9cf9  vmovaps xmm1, [rsp+0xC0]
00007b4681bd9d02  por xmm13, xmm1
00007b4681bd9d07  movaps xmm1, [r15+0x2C0]
00007b4681bd9d0f  vmovaps [rsp+0xC0], xmm1
00007b4681bd9d18  vmovaps [rsp+0xE0], xmm15
00007b4681bd9d21  vmovaps xmm15, [rsp+0xC0]
00007b4681bd9d2a  por xmm1, xmm15
00007b4681bd9d2f  movaps xmm15, [r15+0x290]
00007b4681bd9d37  vmovaps [rsp+0xC0], xmm15
00007b4681bd9d40  vmovaps [rsp+0xF0], xmm1
00007b4681bd9d49  vmovaps xmm1, [rsp+0xC0]
00007b4681bd9d52  por xmm15, xmm1
00007b4681bd9d57  movaps xmm1, [r15+0x260]
00007b4681bd9d5f  vmovaps [rsp+0xC0], xmm1
00007b4681bd9d68  vmovaps [rsp+0x100], xmm15
00007b4681bd9d71  vmovaps xmm15, [rsp+0xC0]
00007b4681bd9d7a  por xmm1, xmm15
00007b4681bd9d7f  vmovaps xmm15, [rsp+0xD0]
00007b4681bd9d88  vmovaps [rsp+0xC0], xmm1
00007b4681bd9d91  vmovaps xmm1, [rsp+0xD0]
00007b4681bd9d9a  por xmm15, xmm1
00007b4681bd9d9f  lea r12, [r14+0xC0]
00007b4681bd9da6  movups xmm1, [r13+r12*1]
00007b4681bd9dac  mov [rsp+0xD0], rax
00007b4681bd9db4  xor eax, eax
00007b4681bd9db6  mov r12d, 0x40
00007b4681bd9dbc  mov r11d, 0x200
00007b4681bd9dc2  cmp r12, r11
00007b4681bd9dc5  cmc
00007b4681bd9dc6  lahf
00007b4681bd9dc7  seto al
00007b4681bd9dca  mov [r15+0x108], eax
00007b4681bd9dd1  vmovaps [rsp+0x110], xmm1
00007b4681bd9dda  vmovaps xmm1, [rsp+0x80]
00007b4681bd9de3  vmovaps [rsp+0x80], xmm15
00007b4681bd9dec  vmovaps xmm15, [rsp+0x110]
00007b4681bd9df5  vmovaps [rsp+0x110], xmm13
00007b4681bd9dfe  vmovaps [rsp+0x120], xmm12
00007b4681bd9e07  movaps xmm13, xmm1
00007b4681bd9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd9e16  vptest xmm12, xmm12
00007b4681bd9e1b  jnz 0x00007B4681BDA9EB
00007b4681bd9e21  lea rax, [r14+0xB0]
00007b4681bd9e28  movups xmm1, [r13+rax*1]
00007b4681bd9e2e  vmovaps xmm15, [rsp+0xA0]
00007b4681bd9e37  vmovaps [rsp+0xA0], xmm13
00007b4681bd9e40  movaps xmm12, xmm15
00007b4681bd9e44  vfmadd231pd xmm12, xmm1, xmm14
00007b4681bd9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007b4681bd9e4f  vptest xmm13, xmm13
00007b4681bd9e54  jnz 0x00007B4681BDAB4E
00007b4681bd9e5a  vmovaps xmm1, [rsp+0x30]
00007b4681bd9e60  vmovaps xmm15, [rsp+0x30]
00007b4681bd9e66  por xmm1, xmm15
00007b4681bd9e6b  movaps [r15+0x210], xmm1
00007b4681bd9e73  vmovaps xmm15, [rsp+0x70]
00007b4681bd9e79  vmovaps xmm14, [rsp+0x70]
00007b4681bd9e7f  por xmm15, xmm14
00007b4681bd9e84  movaps [r15+0x1C0], xmm15
00007b4681bd9e8c  vmovaps xmm14, [rsp+0x60]
00007b4681bd9e92  vmovaps xmm13, [rsp+0x60]
00007b4681bd9e98  por xmm14, xmm13
00007b4681bd9e9d  movaps [r15+0x280], xmm14
00007b4681bd9ea5  vmovaps xmm13, [rsp+0x50]
00007b4681bd9eab  vmovaps [rsp+0x30], xmm1
00007b4681bd9eb1  vmovaps xmm1, [rsp+0x50]
00007b4681bd9eb7  por xmm13, xmm1
00007b4681bd9ebc  movaps [r15+0x2A0], xmm13
00007b4681bd9ec4  vmovaps [rsp+0x50], xmm2
00007b4681bd9eca  vmovaps xmm1, [rsp+0x50]
00007b4681bd9ed0  por xmm2, xmm1
00007b4681bd9ed4  movaps [r15+0x2E0], xmm2
00007b4681bd9edc  vmovaps [rsp+0x50], xmm3
00007b4681bd9ee2  vmovaps xmm1, [rsp+0x50]
00007b4681bd9ee8  por xmm3, xmm1
00007b4681bd9eec  movaps [r15+0x1F0], xmm3
00007b4681bd9ef4  vmovaps xmm1, [rsp+0x80]
00007b4681bd9efd  vmovaps [rsp+0x50], xmm15
00007b4681bd9f03  vmovaps xmm15, [rsp+0x80]
00007b4681bd9f0c  por xmm1, xmm15
00007b4681bd9f11  movaps [r15+0x250], xmm1
00007b4681bd9f19  vmovaps xmm1, [rsp+0xC0]
00007b4681bd9f22  vmovaps xmm15, [rsp+0xC0]
00007b4681bd9f2b  por xmm1, xmm15
00007b4681bd9f30  movaps [r15+0x260], xmm1
00007b4681bd9f38  vmovaps xmm15, [rsp+0x100]
00007b4681bd9f41  vmovaps [rsp+0x60], xmm1
00007b4681bd9f47  vmovaps xmm1, [rsp+0x100]
00007b4681bd9f50  por xmm15, xmm1
00007b4681bd9f55  movaps [r15+0x290], xmm15
00007b4681bd9f5d  vmovaps xmm1, [rsp+0xF0]
00007b4681bd9f66  vmovaps [rsp+0x70], xmm15
00007b4681bd9f6c  vmovaps xmm15, [rsp+0xF0]
00007b4681bd9f75  por xmm1, xmm15
00007b4681bd9f7a  movaps [r15+0x2C0], xmm1
00007b4681bd9f82  movq xmm15, qword ptr [r15+0x240]
00007b4681bd9f8b  vmovaps [rsp+0x80], xmm15
00007b4681bd9f94  vpermilpd xmm15, xmm15, 0x00
00007b4681bd9f9a  vmovaps [rsp+0xC0], xmm1
00007b4681bd9fa3  vmovaps xmm1, [rsp+0x40]
00007b4681bd9fa9  vmovaps [rsp+0x40], xmm15
00007b4681bd9faf  vmovaps xmm15, [rsp+0x30]
00007b4681bd9fb5  vmovaps [rsp+0x30], xmm14
00007b4681bd9fbb  vmovaps xmm14, [rsp+0x40]
00007b4681bd9fc1  vmovaps [rsp+0x40], xmm13
00007b4681bd9fc7  vmovaps [rsp+0xF0], xmm12
00007b4681bd9fd0  movaps xmm13, xmm1
00007b4681bd9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bd9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007b4681bd9fdf  vptest xmm12, xmm12
00007b4681bd9fe4  jnz 0x00007B4681BDACA7
00007b4681bd9fea  vmovaps xmm1, [rsp+0x80]
00007b4681bd9ff3  vpermilpd xmm1, xmm1, 0x00
00007b4681bd9ff9  vmovaps xmm15, [rsp+0xA0]
00007b4681bda002  movaps xmm14, xmm15
00007b4681bda006  vfmadd231pd xmm14, xmm2, xmm1
00007b4681bda00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007b4681bda011  vptest xmm12, xmm12
00007b4681bda016  jnz 0x00007B4681BDAE00
00007b4681bda01c  vmovaps xmm1, [rsp+0x80]
00007b4681bda025  vpermilpd xmm1, xmm1, 0x00
00007b4681bda02b  vmovaps xmm15, [rsp+0x120]
00007b4681bda034  vmovaps xmm12, [rsp+0x50]
00007b4681bda03a  vmovaps [rsp+0x50], xmm14
00007b4681bda040  movaps xmm2, xmm15
00007b4681bda044  vfmadd231pd xmm2, xmm12, xmm1
00007b4681bda049  vcmppd xmm14, xmm2, xmm2, 0x03
00007b4681bda04e  vptest xmm14, xmm14
00007b4681bda053  jnz 0x00007B4681BDAF58
00007b4681bda059  vmovaps xmm1, [rsp+0x110]
00007b4681bda062  vmovaps xmm15, [rsp+0x110]
00007b4681bda06b  por xmm1, xmm15
00007b4681bda070  movaps [r15+0x1D0], xmm1
00007b4681bda078  vmovaps xmm15, [rsp+0x80]
00007b4681bda081  vpermilpd xmm15, xmm15, 0x00
00007b4681bda087  vmovaps xmm14, [rsp+0xF0]
00007b4681bda090  vmovaps [rsp+0x80], xmm1
00007b4681bda099  movaps xmm12, xmm14
00007b4681bda09d  vfmadd231pd xmm12, xmm3, xmm15
00007b4681bda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007b4681bda0a8  vptest xmm1, xmm1
00007b4681bda0ad  jnz 0x00007B4681BDB0AF
00007b4681bda0b3  vmovaps [rsp+0xA0], xmm4
00007b4681bda0bc  vmovaps xmm1, [rsp+0xA0]
00007b4681bda0c5  por xmm4, xmm1
00007b4681bda0c9  movaps [r15+0x200], xmm4
00007b4681bda0d1  vmovaps xmm1, [rsp+0xE0]
00007b4681bda0da  vmovaps xmm15, [rsp+0xE0]
00007b4681bda0e3  por xmm1, xmm15
00007b4681bda0e8  movaps [r15+0x1E0], xmm1
00007b4681bda0f0  vmovaps [rsp+0xA0], xmm8
00007b4681bda0f9  vmovaps xmm1, [rsp+0xA0]
00007b4681bda102  por xmm8, xmm1
00007b4681bda107  movaps [r15+0x2B0], xmm8
00007b4681bda10f  vmovaps [rsp+0xA0], xmm9
00007b4681bda118  vmovaps xmm1, [rsp+0xA0]
00007b4681bda121  por xmm9, xmm1
00007b4681bda126  movaps [r15+0x300], xmm9
00007b4681bda12e  vmovaps [rsp+0xA0], xmm6
00007b4681bda137  vpermilpd xmm6, xmm6, 0x00
00007b4681bda13d  vmovaps xmm14, [rsp+0x60]
00007b4681bda143  movaps xmm9, xmm13
00007b4681bda147  vfmadd231pd xmm9, xmm14, xmm6
00007b4681bda14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007b4681bda152  vptest xmm3, xmm3
00007b4681bda157  jnz 0x00007B4681BDB208
00007b4681bda15d  vmovaps xmm14, [rsp+0xA0]
00007b4681bda166  vpermilpd xmm14, xmm14, 0x00
00007b4681bda16c  vmovaps xmm13, [rsp+0x50]
00007b4681bda172  vmovaps xmm6, [rsp+0xC0]
00007b4681bda17b  vmovaps [rsp+0x50], xmm1
00007b4681bda181  movaps xmm3, xmm13
00007b4681bda185  vfmadd231pd xmm3, xmm6, xmm14
00007b4681bda18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007b4681bda18f  vptest xmm1, xmm1
00007b4681bda194  jnz 0x00007B4681BDB361
00007b4681bda19a  vmovaps xmm1, [rsp+0xA0]
00007b4681bda1a3  vpermilpd xmm1, xmm1, 0x00
00007b4681bda1a9  vmovaps xmm14, [rsp+0x30]
00007b4681bda1af  movaps xmm6, xmm2
00007b4681bda1b2  vfmadd231pd xmm6, xmm14, xmm1
00007b4681bda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007b4681bda1bc  vptest xmm13, xmm13
00007b4681bda1c1  jnz 0x00007B4681BDB4B8
00007b4681bda1c7  vmovaps xmm1, [rsp+0xA0]
00007b4681bda1d0  vpermilpd xmm1, xmm1, 0x00
00007b4681bda1d6  vmovaps xmm14, [rsp+0x80]
00007b4681bda1df  movaps xmm13, xmm12
00007b4681bda1e3  vfmadd231pd xmm13, xmm14, xmm1
00007b4681bda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007b4681bda1ee  vptest xmm2, xmm2
00007b4681bda1f3  jnz 0x00007B4681BDB60E
00007b4681bda1f9  vmovaps [rsp+0x30], xmm7
00007b4681bda1ff  vmovaps xmm1, [rsp+0x30]
00007b4681bda205  por xmm7, xmm1
00007b4681bda209  movaps [r15+0x180], xmm7
00007b4681bda211  vmovaps [rsp+0x30], xmm10
00007b4681bda217  vmovaps xmm1, [rsp+0x30]
00007b4681bda21d  por xmm10, xmm1
00007b4681bda222  movaps [r15+0x2D0], xmm10
00007b4681bda22a  vmovaps [rsp+0x30], xmm5
00007b4681bda230  vpermilpd xmm5, xmm5, 0x00
00007b4681bda236  vmovaps xmm14, [rsp+0x50]
00007b4681bda23c  movaps xmm12, xmm3
00007b4681bda240  vfmadd231pd xmm12, xmm14, xmm5
00007b4681bda245  vcmppd xmm10, xmm12, xmm12, 0x03
00007b4681bda24b  vptest xmm10, xmm10
00007b4681bda250  jnz 0x00007B4681BDB767
00007b4681bda256  vmovaps xmm14, [rsp+0x30]
00007b4681bda25c  vpermilpd xmm14, xmm14, 0x00
00007b4681bda262  movaps xmm10, xmm9
00007b4681bda266  vfmadd231pd xmm10, xmm7, xmm14
00007b4681bda26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007b4681bda271  vptest xmm5, xmm5
00007b4681bda276  jnz 0x00007B4681BDB8BF
00007b4681bda27c  lea rax, [r14+0x80]
00007b4681bda283  movups xmm14, [r13+rax*1]
00007b4681bda289  movaps [r15+0x2F0], xmm14
00007b4681bda291  vmovaps xmm9, [rsp+0x30]
00007b4681bda297  vpermilpd xmm9, xmm9, 0x00
00007b4681bda29d  vmovaps xmm7, [rsp+0x70]
00007b4681bda2a3  movaps xmm5, xmm6
00007b4681bda2a6  vfmadd231pd xmm5, xmm7, xmm9
00007b4681bda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007b4681bda2b0  vptest xmm3, xmm3
00007b4681bda2b5  jnz 0x00007B4681BDBA22
00007b4681bda2bb  vmovaps xmm9, [rsp+0x30]
00007b4681bda2c1  vpermilpd xmm9, xmm9, 0x00
00007b4681bda2c7  movaps xmm7, xmm13
00007b4681bda2cb  vfmadd231pd xmm7, xmm1, xmm9
00007b4681bda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007b4681bda2d5  vptest xmm6, xmm6
00007b4681bda2da  jnz 0x00007B4681BDBB78
00007b4681bda2e0  vmovaps xmm1, [rsp+0x20]
00007b4681bda2e6  vmovaps xmm13, [rsp+0x20]
00007b4681bda2ec  por xmm1, xmm13
00007b4681bda2f1  movaps [r15+0x160], xmm1
00007b4681bda2f9  lea rax, [r14+0x40]
00007b4681bda2fd  movups xmm13, [r13+rax*1]
00007b4681bda303  lea rax, [r14+0x50]
00007b4681bda307  movups xmm9, [r13+rax*1]
00007b4681bda30d  movaps [r15+0x1B0], xmm13
00007b4681bda315  movaps [r15+0x1A0], xmm9
00007b4681bda31d  movaps xmm6, [r15+0x190]
00007b4681bda325  vmovaps xmm3, [rsp+0xB0]
00007b4681bda32e  vpermilpd xmm3, xmm3, 0x00
00007b4681bda334  vmovaps [rsp+0x20], xmm1
00007b4681bda33a  movaps xmm2, xmm12
00007b4681bda33e  vfmadd231pd xmm2, xmm6, xmm3
00007b4681bda343  vcmppd xmm1, xmm2, xmm2, 0x03
00007b4681bda348  vptest xmm1, xmm1
00007b4681bda34d  jnz 0x00007B4681BDBCE3
00007b4681bda353  vmovaps xmm1, [rsp+0xB0]
00007b4681bda35c  vpermilpd xmm1, xmm1, 0x00
00007b4681bda362  vmovaps xmm12, [rsp+0x20]
00007b4681bda368  movaps xmm6, xmm10
00007b4681bda36c  vfmadd231pd xmm6, xmm12, xmm1
00007b4681bda371  vcmppd xmm3, xmm6, xmm6, 0x03
00007b4681bda376  vptest xmm3, xmm3
00007b4681bda37b  jnz 0x00007B4681BDBE39
00007b4681bda381  vmovaps xmm1, [rsp+0xB0]
00007b4681bda38a  vpermilpd xmm1, xmm1, 0x00
00007b4681bda390  vmovaps xmm12, [rsp+0x40]
00007b4681bda396  movaps xmm10, xmm5
00007b4681bda39a  vfmadd231pd xmm10, xmm12, xmm1
00007b4681bda39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007b4681bda3a5  vptest xmm3, xmm3
00007b4681bda3aa  jnz 0x00007B4681BDBF90
00007b4681bda3b0  vmovaps xmm1, [rsp+0xB0]
00007b4681bda3b9  vpermilpd xmm1, xmm1, 0x00
00007b4681bda3bf  movaps xmm12, xmm7
00007b4681bda3c3  vfmadd231pd xmm12, xmm15, xmm1
00007b4681bda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007b4681bda3ce  vptest xmm5, xmm5
00007b4681bda3d3  jnz 0x00007B4681BDC0E8
00007b4681bda3d9  lea rax, [r14+0x60]
00007b4681bda3dd  movups xmm1, [r13+rax*1]
00007b4681bda3e3  lea rax, [r14+0x70]
00007b4681bda3e7  movups xmm15, [r13+rax*1]
00007b4681bda3ed  movaps [r15+0x150], xmm1
00007b4681bda3f5  movaps [r15+0x120], xmm15
00007b4681bda3fd  vmovaps [rsp+0x20], xmm11
00007b4681bda403  vpermilpd xmm11, xmm11, 0x00
00007b4681bda409  movaps xmm7, xmm2
00007b4681bda40c  vfmadd231pd xmm7, xmm9, xmm11
00007b4681bda411  vcmppd xmm5, xmm7, xmm7, 0x03
00007b4681bda416  vptest xmm5, xmm5
00007b4681bda41b  jnz 0x00007B4681BDC254
00007b4681bda421  vmovaps xmm11, [rsp+0x20]
00007b4681bda427  vpermilpd xmm11, xmm11, 0x00
00007b4681bda42d  movaps xmm9, xmm6
00007b4681bda431  vfmadd231pd xmm9, xmm1, xmm11
00007b4681bda436  vcmppd xmm5, xmm9, xmm9, 0x03
00007b4681bda43c  vptest xmm5, xmm5
00007b4681bda441  jnz 0x00007B4681BDC3AB
00007b4681bda447  vmovaps xmm1, [rsp+0x20]
00007b4681bda44d  vpermilpd xmm1, xmm1, 0x00
00007b4681bda453  movaps xmm11, xmm10
00007b4681bda457  vfmadd231pd xmm11, xmm8, xmm1
00007b4681bda45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007b4681bda462  vptest xmm6, xmm6
00007b4681bda467  jnz 0x00007B4681BDC503
00007b4681bda46d  vmovaps xmm1, [rsp+0x20]
00007b4681bda473  vpermilpd xmm1, xmm1, 0x00
00007b4681bda479  movaps xmm10, xmm12
00007b4681bda47d  vfmadd231pd xmm10, xmm13, xmm1
00007b4681bda482  vcmppd xmm8, xmm10, xmm10, 0x03
00007b4681bda488  vptest xmm8, xmm8
00007b4681bda48d  jnz 0x00007B4681BDC65C
00007b4681bda493  lea rax, [r14+0x20]
00007b4681bda497  movups xmm1, [r13+rax*1]
00007b4681bda49d  lea rax, [r14+0x30]
00007b4681bda4a1  movups xmm13, [r13+rax*1]
00007b4681bda4a7  vmovaps xmm12, [rsp+0x90]
00007b4681bda4b0  vpermilpd xmm12, xmm12, 0x00
00007b4681bda4b6  movaps xmm8, xmm7
00007b4681bda4ba  vfmadd231pd xmm8, xmm4, xmm12
00007b4681bda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007b4681bda4c5  vptest xmm6, xmm6
00007b4681bda4ca  jnz 0x00007B4681BDC7C9
00007b4681bda4d0  vmovaps xmm12, [rsp+0x90]
00007b4681bda4d9  vpermilpd xmm12, xmm12, 0x00
00007b4681bda4df  movaps xmm7, xmm9
00007b4681bda4e3  vfmadd231pd xmm7, xmm14, xmm12
00007b4681bda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007b4681bda4ed  vptest xmm6, xmm6
00007b4681bda4f2  jnz 0x00007B4681BDC921
00007b4681bda4f8  vmovaps xmm14, [rsp+0x90]
00007b4681bda501  vpermilpd xmm14, xmm14, 0x00
00007b4681bda507  movaps xmm12, xmm11
00007b4681bda50b  vfmadd231pd xmm12, xmm15, xmm14
00007b4681bda510  vcmppd xmm9, xmm12, xmm12, 0x03
00007b4681bda516  vptest xmm9, xmm9
00007b4681bda51b  jnz 0x00007B4681BDCA79
00007b4681bda521  vmovaps xmm15, [rsp+0x90]
00007b4681bda52a  vpermilpd xmm15, xmm15, 0x00
00007b4681bda530  movaps xmm11, xmm10
00007b4681bda534  vfmadd231pd xmm11, xmm13, xmm15
00007b4681bda539  vcmppd xmm14, xmm11, xmm11, 0x03
00007b4681bda53f  vptest xmm14, xmm14
00007b4681bda544  jnz 0x00007B4681BDCBD3
00007b4681bda54a  lea rax, [r14+0x90]
00007b4681bda551  movups xmm15, [r13+rax*1]
00007b4681bda557  lea rax, [r14+0xA0]
00007b4681bda55e  movups xmm14, [r13+rax*1]
00007b4681bda564  movaps [r15+0x140], xmm15
00007b4681bda56c  movaps [r15+0x130], xmm14
00007b4681bda574  vmovaps xmm13, [rsp+0x10]
00007b4681bda57a  vpermilpd xmm13, xmm13, 0x00
00007b4681bda580  movaps xmm10, xmm8
00007b4681bda584  vfmadd231pd xmm10, xmm1, xmm13
00007b4681bda589  vcmppd xmm9, xmm10, xmm10, 0x03
00007b4681bda58f  vptest xmm9, xmm9
00007b4681bda594  jnz 0x00007B4681BDCD41
00007b4681bda59a  movaps [r15+0x220], xmm10
00007b4681bda5a2  lea rax, [r14+0x10]
00007b4681bda5a6  movups xmm1, [r13+rax*1]
00007b4681bda5ac  movaps [r15+0x240], xmm1
00007b4681bda5b4  vmovaps xmm13, [rsp+0x10]
00007b4681bda5ba  vpermilpd xmm13, xmm13, 0x00
00007b4681bda5c0  movaps xmm9, xmm7
00007b4681bda5c4  vfmadd231pd xmm9, xmm14, xmm13
00007b4681bda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007b4681bda5cf  vptest xmm8, xmm8
00007b4681bda5d4  jnz 0x00007B4681BDCEA4
00007b4681bda5da  movaps [r15+0x110], xmm9
00007b4681bda5e2  vmovaps xmm14, [rsp+0x10]
00007b4681bda5e8  vpermilpd xmm14, xmm14, 0x00
00007b4681bda5ee  movaps xmm13, xmm12
00007b4681bda5f2  vfmadd231pd xmm13, xmm15, xmm14
00007b4681bda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007b4681bda5fd  vptest xmm8, xmm8
00007b4681bda602  jnz 0x00007B4681BDCFFD
00007b4681bda608  movaps [r15+0x170], xmm13
00007b4681bda610  vmovaps xmm15, [rsp+0x10]
00007b4681bda616  vpermilpd xmm15, xmm15, 0x00
00007b4681bda61c  movaps xmm14, xmm11
00007b4681bda620  vfmadd231pd xmm14, xmm1, xmm15
00007b4681bda625  vcmppd xmm12, xmm14, xmm14, 0x03
00007b4681bda62b  vptest xmm12, xmm12
00007b4681bda630  jnz 0x00007B4681BDD157
00007b4681bda636  movaps [r15+0x230], xmm14
00007b4681bda63e  mov rax, [rsp+0xD0]
00007b4681bda646  movups [r13+rax*1], xmm9
00007b4681bda64c  lea r14, [rax+0x10]
00007b4681bda650  movups [r13+r14*1], xmm13
00007b4681bda656  lea r14, [rax+0x20]
00007b4681bda65a  movups [r13+r14*1], xmm10
00007b4681bda660  lea r14, [rax+0x30]
00007b4681bda664  movups [r13+r14*1], xmm14
00007b4681bda66a  mov eax, [r15+0x108]
00007b4681bda671  sahf
00007b4681bda672  jnz 0x00007B4681BDA6A4
00007b4681bda674  cmp dword ptr [r15+0x318], 0x00
00007b4681bda67c  jz 0x00007B4681BD9950
00007b4681bda682  nop [rax+rax*1], ax
00007b4681bda68b  nop [rax+rax*1], eax
00007b4681bda693  mov eax, 0x410664
00007b4681bda698  mov [r15+0x100], rax
00007b4681bda69f  jmp 0x00007B46819FE110
00007b4681bda6a4  cmp dword ptr [r15+0x318], 0x00
00007b4681bda6ac  jz 0x00007B4681BD6050
00007b4681bda6b2  nop [rax+rax*1], ax
00007b4681bda6bb  nop [rax+rax*1], eax
00007b4681bda6c3  mov eax, 0x4104F0
00007b4681bda6c8  mov [r15+0x100], rax
00007b4681bda6cf  jmp 0x00007B46819FE110
00007b4681bda6d4  int3
00007b4681bda6d5  call 0x00007B4681AE27E0
00007b4681bda6da  jmp 0x00007B4681BD9A10
00007b4681bda6df  call 0x00007B4681AE1570
00007b4681bda6e4  jmp 0x00007B4681BD9A19
00007b4681bda6e9  call 0x00007B4681AE27E0
00007b4681bda6ee  jmp 0x00007B4681BD9A62
00007b4681bda6f3  call 0x00007B4681AE1570
00007b4681bda6f8  jmp 0x00007B4681BD9A6B
00007b4681bda6fd  call 0x00007B4681AE27E0
00007b4681bda702  jmp 0x00007B4681BD9AEB
00007b4681bda707  call 0x00007B4681AE1570
00007b4681bda70c  jmp 0x00007B4681BD9AF4
00007b4681bda711  call 0x00007B4681A0DC20
00007b4681bda716  jmp 0x00007B4681BD9BD5
00007b4681bda71b  call 0x00007B4681AD64F0
00007b4681bda720  jmp 0x00007B4681BD9C04
00007b4681bda725  call 0x00007B4681AB47C0
00007b4681bda72a  jmp 0x00007B4681BD9C1F
00007b4681bda72f  sub rsp, 0x08
00007b4681bda733  push rax
00007b4681bda734  push rcx
00007b4681bda735  push rdx
00007b4681bda736  push rdi
00007b4681bda737  push rsi
00007b4681bda738  push r8
00007b4681bda73a  push r9
00007b4681bda73c  push r10
00007b4681bda73e  push r11
00007b4681bda740  sub rsp, 0xF0
00007b4681bda747  vmovaps [rsp], xmm0
00007b4681bda74c  vmovaps [rsp+0x10], xmm1
00007b4681bda752  vmovaps [rsp+0x20], xmm2
00007b4681bda758  vmovaps [rsp+0x30], xmm3
00007b4681bda75e  vmovaps [rsp+0x40], xmm4
00007b4681bda764  vmovaps [rsp+0x50], xmm5
00007b4681bda76a  vmovaps [rsp+0x60], xmm6
00007b4681bda770  vmovaps [rsp+0x70], xmm7
00007b4681bda776  vmovaps [rsp+0x80], xmm8
00007b4681bda77f  vmovaps [rsp+0x90], xmm9
00007b4681bda788  vmovaps [rsp+0xA0], xmm10
00007b4681bda791  vmovaps [rsp+0xB0], xmm11
00007b4681bda79a  vmovaps [rsp+0xC0], xmm12
00007b4681bda7a3  vmovaps [rsp+0xD0], xmm14
00007b4681bda7ac  vmovaps [rsp+0xE0], xmm15
00007b4681bda7b5  sub rsp, 0x40
00007b4681bda7b9  lea rdi, [rsp]
00007b4681bda7bd  lea rsi, [rsp+0x10]
00007b4681bda7c2  lea rdx, [rsp+0x20]
00007b4681bda7c7  lea rcx, [rsp+0x30]
00007b4681bda7cc  mov r8d, 0x00
00007b4681bda7d2  lea r9, [r15+0x3A8]
00007b4681bda7d9  movaps [rdi], xmm13
00007b4681bda7dd  movaps [rsi], xmm1
00007b4681bda7e0  movaps [rdx], xmm15
00007b4681bda7e4  movaps [rcx], xmm14
00007b4681bda7e8  mov rax, 0x5668589B5A50
00007b4681bda7f2  call rax
00007b4681bda7f4  movaps xmm13, [rsp]
00007b4681bda7f9  add rsp, 0x40
00007b4681bda7fd  vmovaps xmm0, [rsp]
00007b4681bda802  vmovaps xmm1, [rsp+0x10]
00007b4681bda808  vmovaps xmm2, [rsp+0x20]
00007b4681bda80e  vmovaps xmm3, [rsp+0x30]
00007b4681bda814  vmovaps xmm4, [rsp+0x40]
00007b4681bda81a  vmovaps xmm5, [rsp+0x50]
00007b4681bda820  vmovaps xmm6, [rsp+0x60]
00007b4681bda826  vmovaps xmm7, [rsp+0x70]
00007b4681bda82c  vmovaps xmm8, [rsp+0x80]
00007b4681bda835  vmovaps xmm9, [rsp+0x90]
00007b4681bda83e  vmovaps xmm10, [rsp+0xA0]
00007b4681bda847  vmovaps xmm11, [rsp+0xB0]
00007b4681bda850  vmovaps xmm12, [rsp+0xC0]
00007b4681bda859  vmovaps xmm14, [rsp+0xD0]
00007b4681bda862  vmovaps xmm15, [rsp+0xE0]
00007b4681bda86b  add rsp, 0xF0
00007b4681bda872  pop r11
00007b4681bda874  pop r10
00007b4681bda876  pop r9
00007b4681bda878  pop r8
00007b4681bda87a  pop rsi
00007b4681bda87b  pop rdi
00007b4681bda87c  pop rdx
00007b4681bda87d  pop rcx
00007b4681bda87e  pop rax
00007b4681bda87f  add rsp, 0x08
00007b4681bda883  jmp 0x00007B4681BD9C92
00007b4681bda888  sub rsp, 0x08
00007b4681bda88c  push rax
00007b4681bda88d  push rcx
00007b4681bda88e  push rdx
00007b4681bda88f  push rdi
00007b4681bda890  push rsi
00007b4681bda891  push r8
00007b4681bda893  push r9
00007b4681bda895  push r10
00007b4681bda897  push r11
00007b4681bda899  sub rsp, 0xF0
00007b4681bda8a0  vmovaps [rsp], xmm0
00007b4681bda8a5  vmovaps [rsp+0x10], xmm1
00007b4681bda8ab  vmovaps [rsp+0x20], xmm2
00007b4681bda8b1  vmovaps [rsp+0x30], xmm3
00007b4681bda8b7  vmovaps [rsp+0x40], xmm4
00007b4681bda8bd  vmovaps [rsp+0x50], xmm5
00007b4681bda8c3  vmovaps [rsp+0x60], xmm6
00007b4681bda8c9  vmovaps [rsp+0x70], xmm7
00007b4681bda8cf  vmovaps [rsp+0x80], xmm8
00007b4681bda8d8  vmovaps [rsp+0x90], xmm9
00007b4681bda8e1  vmovaps [rsp+0xA0], xmm10
00007b4681bda8ea  vmovaps [rsp+0xB0], xmm11
00007b4681bda8f3  vmovaps [rsp+0xC0], xmm13
00007b4681bda8fc  vmovaps [rsp+0xD0], xmm14
00007b4681bda905  vmovaps [rsp+0xE0], xmm15
00007b4681bda90e  sub rsp, 0x40
00007b4681bda912  lea rdi, [rsp]
00007b4681bda916  lea rsi, [rsp+0x10]
00007b4681bda91b  lea rdx, [rsp+0x20]
00007b4681bda920  lea rcx, [rsp+0x30]
00007b4681bda925  mov r8d, 0x00
00007b4681bda92b  lea r9, [r15+0x3A8]
00007b4681bda932  movaps [rdi], xmm12
00007b4681bda936  movaps [rsi], xmm15
00007b4681bda93a  movaps [rdx], xmm1
00007b4681bda93d  movaps [rcx], xmm14
00007b4681bda941  mov rax, 0x5668589B5A50
00007b4681bda94b  call rax
00007b4681bda94d  movaps xmm12, [rsp]
00007b4681bda952  add rsp, 0x40
00007b4681bda956  vmovaps xmm0, [rsp]
00007b4681bda95b  vmovaps xmm1, [rsp+0x10]
00007b4681bda961  vmovaps xmm2, [rsp+0x20]
00007b4681bda967  vmovaps xmm3, [rsp+0x30]
00007b4681bda96d  vmovaps xmm4, [rsp+0x40]
00007b4681bda973  vmovaps xmm5, [rsp+0x50]
00007b4681bda979  vmovaps xmm6, [rsp+0x60]
00007b4681bda97f  vmovaps xmm7, [rsp+0x70]
00007b4681bda985  vmovaps xmm8, [rsp+0x80]
00007b4681bda98e  vmovaps xmm9, [rsp+0x90]
00007b4681bda997  vmovaps xmm10, [rsp+0xA0]
00007b4681bda9a0  vmovaps xmm11, [rsp+0xB0]
00007b4681bda9a9  vmovaps xmm13, [rsp+0xC0]
00007b4681bda9b2  vmovaps xmm14, [rsp+0xD0]
00007b4681bda9bb  vmovaps xmm15, [rsp+0xE0]
00007b4681bda9c4  add rsp, 0xF0
00007b4681bda9cb  pop r11
00007b4681bda9cd  pop r10
00007b4681bda9cf  pop r9
00007b4681bda9d1  pop r8
00007b4681bda9d3  pop rsi
00007b4681bda9d4  pop rdi
00007b4681bda9d5  pop rdx
00007b4681bda9d6  pop rcx
00007b4681bda9d7  pop rax
00007b4681bda9d8  add rsp, 0x08
00007b4681bda9dc  jmp 0x00007B4681BD9CC0
00007b4681bda9e1  call 0x00007B4681AB52F0
00007b4681bda9e6  jmp 0x00007B4681BD9DAC
00007b4681bda9eb  sub rsp, 0x08
00007b4681bda9ef  push rax
00007b4681bda9f0  push rcx
00007b4681bda9f1  push rdx
00007b4681bda9f2  push rdi
00007b4681bda9f3  push rsi
00007b4681bda9f4  push r8
00007b4681bda9f6  push r9
00007b4681bda9f8  push r10
00007b4681bda9fa  push r11
00007b4681bda9fc  sub rsp, 0xF0
00007b4681bdaa03  vmovaps [rsp], xmm0
00007b4681bdaa08  vmovaps [rsp+0x10], xmm1
00007b4681bdaa0e  vmovaps [rsp+0x20], xmm2
00007b4681bdaa14  vmovaps [rsp+0x30], xmm3
00007b4681bdaa1a  vmovaps [rsp+0x40], xmm4
00007b4681bdaa20  vmovaps [rsp+0x50], xmm5
00007b4681bdaa26  vmovaps [rsp+0x60], xmm6
00007b4681bdaa2c  vmovaps [rsp+0x70], xmm7
00007b4681bdaa32  vmovaps [rsp+0x80], xmm8
00007b4681bdaa3b  vmovaps [rsp+0x90], xmm9
00007b4681bdaa44  vmovaps [rsp+0xA0], xmm10
00007b4681bdaa4d  vmovaps [rsp+0xB0], xmm11
00007b4681bdaa56  vmovaps [rsp+0xC0], xmm12
00007b4681bdaa5f  vmovaps [rsp+0xD0], xmm14
00007b4681bdaa68  vmovaps [rsp+0xE0], xmm15
00007b4681bdaa71  sub rsp, 0x40
00007b4681bdaa75  lea rdi, [rsp]
00007b4681bdaa79  lea rsi, [rsp+0x10]
00007b4681bdaa7e  lea rdx, [rsp+0x20]
00007b4681bdaa83  lea rcx, [rsp+0x30]
00007b4681bdaa88  mov r8d, 0x00
00007b4681bdaa8e  lea r9, [r15+0x3A8]
00007b4681bdaa95  movaps [rdi], xmm13
00007b4681bdaa99  movaps [rsi], xmm1
00007b4681bdaa9c  movaps [rdx], xmm15
00007b4681bdaaa0  movaps [rcx], xmm14
00007b4681bdaaa4  mov rax, 0x5668589B5A50
00007b4681bdaaae  call rax
00007b4681bdaab0  movaps xmm13, [rsp]
00007b4681bdaab5  add rsp, 0x40
00007b4681bdaab9  vmovaps xmm0, [rsp]
00007b4681bdaabe  vmovaps xmm1, [rsp+0x10]
00007b4681bdaac4  vmovaps xmm2, [rsp+0x20]
00007b4681bdaaca  vmovaps xmm3, [rsp+0x30]
00007b4681bdaad0  vmovaps xmm4, [rsp+0x40]
00007b4681bdaad6  vmovaps xmm5, [rsp+0x50]
00007b4681bdaadc  vmovaps xmm6, [rsp+0x60]
00007b4681bdaae2  vmovaps xmm7, [rsp+0x70]
00007b4681bdaae8  vmovaps xmm8, [rsp+0x80]
00007b4681bdaaf1  vmovaps xmm9, [rsp+0x90]
00007b4681bdaafa  vmovaps xmm10, [rsp+0xA0]
00007b4681bdab03  vmovaps xmm11, [rsp+0xB0]
00007b4681bdab0c  vmovaps xmm12, [rsp+0xC0]
00007b4681bdab15  vmovaps xmm14, [rsp+0xD0]
00007b4681bdab1e  vmovaps xmm15, [rsp+0xE0]
00007b4681bdab27  add rsp, 0xF0
00007b4681bdab2e  pop r11
00007b4681bdab30  pop r10
00007b4681bdab32  pop r9
00007b4681bdab34  pop r8
00007b4681bdab36  pop rsi
00007b4681bdab37  pop rdi
00007b4681bdab38  pop rdx
00007b4681bdab39  pop rcx
00007b4681bdab3a  pop rax
00007b4681bdab3b  add rsp, 0x08
00007b4681bdab3f  jmp 0x00007B4681BD9E21
00007b4681bdab44  call 0x00007B46819FF430
00007b4681bdab49  jmp 0x00007B4681BD9E2E
00007b4681bdab4e  sub rsp, 0x08
00007b4681bdab52  push rax
00007b4681bdab53  push rcx
00007b4681bdab54  push rdx
00007b4681bdab55  push rdi
00007b4681bdab56  push rsi
00007b4681bdab57  push r8
00007b4681bdab59  push r9
00007b4681bdab5b  push r10
00007b4681bdab5d  push r11
00007b4681bdab5f  sub rsp, 0xF0
00007b4681bdab66  vmovaps [rsp], xmm0
00007b4681bdab6b  vmovaps [rsp+0x10], xmm1
00007b4681bdab71  vmovaps [rsp+0x20], xmm2
00007b4681bdab77  vmovaps [rsp+0x30], xmm3
00007b4681bdab7d  vmovaps [rsp+0x40], xmm4
00007b4681bdab83  vmovaps [rsp+0x50], xmm5
00007b4681bdab89  vmovaps [rsp+0x60], xmm6
00007b4681bdab8f  vmovaps [rsp+0x70], xmm7
00007b4681bdab95  vmovaps [rsp+0x80], xmm8
00007b4681bdab9e  vmovaps [rsp+0x90], xmm9
00007b4681bdaba7  vmovaps [rsp+0xA0], xmm10
00007b4681bdabb0  vmovaps [rsp+0xB0], xmm11
00007b4681bdabb9  vmovaps [rsp+0xC0], xmm13
00007b4681bdabc2  vmovaps [rsp+0xD0], xmm14
00007b4681bdabcb  vmovaps [rsp+0xE0], xmm15
00007b4681bdabd4  sub rsp, 0x40
00007b4681bdabd8  lea rdi, [rsp]
00007b4681bdabdc  lea rsi, [rsp+0x10]
00007b4681bdabe1  lea rdx, [rsp+0x20]
00007b4681bdabe6  lea rcx, [rsp+0x30]
00007b4681bdabeb  mov r8d, 0x00
00007b4681bdabf1  lea r9, [r15+0x3A8]
00007b4681bdabf8  movaps [rdi], xmm12
00007b4681bdabfc  movaps [rsi], xmm15
00007b4681bdac00  movaps [rdx], xmm1
00007b4681bdac03  movaps [rcx], xmm14
00007b4681bdac07  mov rax, 0x5668589B5A50
00007b4681bdac11  call rax
00007b4681bdac13  movaps xmm12, [rsp]
00007b4681bdac18  add rsp, 0x40
00007b4681bdac1c  vmovaps xmm0, [rsp]
00007b4681bdac21  vmovaps xmm1, [rsp+0x10]
00007b4681bdac27  vmovaps xmm2, [rsp+0x20]
00007b4681bdac2d  vmovaps xmm3, [rsp+0x30]
00007b4681bdac33  vmovaps xmm4, [rsp+0x40]
00007b4681bdac39  vmovaps xmm5, [rsp+0x50]
00007b4681bdac3f  vmovaps xmm6, [rsp+0x60]
00007b4681bdac45  vmovaps xmm7, [rsp+0x70]
00007b4681bdac4b  vmovaps xmm8, [rsp+0x80]
00007b4681bdac54  vmovaps xmm9, [rsp+0x90]
00007b4681bdac5d  vmovaps xmm10, [rsp+0xA0]
00007b4681bdac66  vmovaps xmm11, [rsp+0xB0]
00007b4681bdac6f  vmovaps xmm13, [rsp+0xC0]
00007b4681bdac78  vmovaps xmm14, [rsp+0xD0]
00007b4681bdac81  vmovaps xmm15, [rsp+0xE0]
00007b4681bdac8a  add rsp, 0xF0
00007b4681bdac91  pop r11
00007b4681bdac93  pop r10
00007b4681bdac95  pop r9
00007b4681bdac97  pop r8
00007b4681bdac99  pop rsi
00007b4681bdac9a  pop rdi
00007b4681bdac9b  pop rdx
00007b4681bdac9c  pop rcx
00007b4681bdac9d  pop rax
00007b4681bdac9e  add rsp, 0x08
00007b4681bdaca2  jmp 0x00007B4681BD9E5A
00007b4681bdaca7  sub rsp, 0x08
00007b4681bdacab  push rax
00007b4681bdacac  push rcx
00007b4681bdacad  push rdx
00007b4681bdacae  push rdi
00007b4681bdacaf  push rsi
00007b4681bdacb0  push r8
00007b4681bdacb2  push r9
00007b4681bdacb4  push r10
00007b4681bdacb6  push r11
00007b4681bdacb8  sub rsp, 0xF0
00007b4681bdacbf  vmovaps [rsp], xmm0
00007b4681bdacc4  vmovaps [rsp+0x10], xmm1
00007b4681bdacca  vmovaps [rsp+0x20], xmm2
00007b4681bdacd0  vmovaps [rsp+0x30], xmm3
00007b4681bdacd6  vmovaps [rsp+0x40], xmm4
00007b4681bdacdc  vmovaps [rsp+0x50], xmm5
00007b4681bdace2  vmovaps [rsp+0x60], xmm6
00007b4681bdace8  vmovaps [rsp+0x70], xmm7
00007b4681bdacee  vmovaps [rsp+0x80], xmm8
00007b4681bdacf7  vmovaps [rsp+0x90], xmm9
00007b4681bdad00  vmovaps [rsp+0xA0], xmm10
00007b4681bdad09  vmovaps [rsp+0xB0], xmm11
00007b4681bdad12  vmovaps [rsp+0xC0], xmm12
00007b4681bdad1b  vmovaps [rsp+0xD0], xmm14
00007b4681bdad24  vmovaps [rsp+0xE0], xmm15
00007b4681bdad2d  sub rsp, 0x40
00007b4681bdad31  lea rdi, [rsp]
00007b4681bdad35  lea rsi, [rsp+0x10]
00007b4681bdad3a  lea rdx, [rsp+0x20]
00007b4681bdad3f  lea rcx, [rsp+0x30]
00007b4681bdad44  mov r8d, 0x00
00007b4681bdad4a  lea r9, [r15+0x3A8]
00007b4681bdad51  movaps [rdi], xmm13
00007b4681bdad55  movaps [rsi], xmm1
00007b4681bdad58  movaps [rdx], xmm15
00007b4681bdad5c  movaps [rcx], xmm14
00007b4681bdad60  mov rax, 0x5668589B5A50
00007b4681bdad6a  call rax
00007b4681bdad6c  movaps xmm13, [rsp]
00007b4681bdad71  add rsp, 0x40
00007b4681bdad75  vmovaps xmm0, [rsp]
00007b4681bdad7a  vmovaps xmm1, [rsp+0x10]
00007b4681bdad80  vmovaps xmm2, [rsp+0x20]
00007b4681bdad86  vmovaps xmm3, [rsp+0x30]
00007b4681bdad8c  vmovaps xmm4, [rsp+0x40]
00007b4681bdad92  vmovaps xmm5, [rsp+0x50]
00007b4681bdad98  vmovaps xmm6, [rsp+0x60]
00007b4681bdad9e  vmovaps xmm7, [rsp+0x70]
00007b4681bdada4  vmovaps xmm8, [rsp+0x80]
00007b4681bdadad  vmovaps xmm9, [rsp+0x90]
00007b4681bdadb6  vmovaps xmm10, [rsp+0xA0]
00007b4681bdadbf  vmovaps xmm11, [rsp+0xB0]
00007b4681bdadc8  vmovaps xmm12, [rsp+0xC0]
00007b4681bdadd1  vmovaps xmm14, [rsp+0xD0]
00007b4681bdadda  vmovaps xmm15, [rsp+0xE0]
00007b4681bdade3  add rsp, 0xF0
00007b4681bdadea  pop r11
00007b4681bdadec  pop r10
00007b4681bdadee  pop r9
00007b4681bdadf0  pop r8
00007b4681bdadf2  pop rsi
00007b4681bdadf3  pop rdi
00007b4681bdadf4  pop rdx
00007b4681bdadf5  pop rcx
00007b4681bdadf6  pop rax
00007b4681bdadf7  add rsp, 0x08
00007b4681bdadfb  jmp 0x00007B4681BD9FEA
00007b4681bdae00  sub rsp, 0x08
00007b4681bdae04  push rax
00007b4681bdae05  push rcx
00007b4681bdae06  push rdx
00007b4681bdae07  push rdi
00007b4681bdae08  push rsi
00007b4681bdae09  push r8
00007b4681bdae0b  push r9
00007b4681bdae0d  push r10
00007b4681bdae0f  push r11
00007b4681bdae11  sub rsp, 0xF0
00007b4681bdae18  vmovaps [rsp], xmm0
00007b4681bdae1d  vmovaps [rsp+0x10], xmm1
00007b4681bdae23  vmovaps [rsp+0x20], xmm2
00007b4681bdae29  vmovaps [rsp+0x30], xmm3
00007b4681bdae2f  vmovaps [rsp+0x40], xmm4
00007b4681bdae35  vmovaps [rsp+0x50], xmm5
00007b4681bdae3b  vmovaps [rsp+0x60], xmm6
00007b4681bdae41  vmovaps [rsp+0x70], xmm7
00007b4681bdae47  vmovaps [rsp+0x80], xmm8
00007b4681bdae50  vmovaps [rsp+0x90], xmm9
00007b4681bdae59  vmovaps [rsp+0xA0], xmm10
00007b4681bdae62  vmovaps [rsp+0xB0], xmm11
00007b4681bdae6b  vmovaps [rsp+0xC0], xmm12
00007b4681bdae74  vmovaps [rsp+0xD0], xmm13
00007b4681bdae7d  vmovaps [rsp+0xE0], xmm15
00007b4681bdae86  sub rsp, 0x40
00007b4681bdae8a  lea rdi, [rsp]
00007b4681bdae8e  lea rsi, [rsp+0x10]
00007b4681bdae93  lea rdx, [rsp+0x20]
00007b4681bdae98  lea rcx, [rsp+0x30]
00007b4681bdae9d  mov r8d, 0x00
00007b4681bdaea3  lea r9, [r15+0x3A8]
00007b4681bdaeaa  movaps [rdi], xmm14
00007b4681bdaeae  movaps [rsi], xmm15
00007b4681bdaeb2  movaps [rdx], xmm2
00007b4681bdaeb5  movaps [rcx], xmm1
00007b4681bdaeb8  mov rax, 0x5668589B5A50
00007b4681bdaec2  call rax
00007b4681bdaec4  movaps xmm14, [rsp]
00007b4681bdaec9  add rsp, 0x40
00007b4681bdaecd  vmovaps xmm0, [rsp]
00007b4681bdaed2  vmovaps xmm1, [rsp+0x10]
00007b4681bdaed8  vmovaps xmm2, [rsp+0x20]
00007b4681bdaede  vmovaps xmm3, [rsp+0x30]
00007b4681bdaee4  vmovaps xmm4, [rsp+0x40]
00007b4681bdaeea  vmovaps xmm5, [rsp+0x50]
00007b4681bdaef0  vmovaps xmm6, [rsp+0x60]
00007b4681bdaef6  vmovaps xmm7, [rsp+0x70]
00007b4681bdaefc  vmovaps xmm8, [rsp+0x80]
00007b4681bdaf05  vmovaps xmm9, [rsp+0x90]
00007b4681bdaf0e  vmovaps xmm10, [rsp+0xA0]
00007b4681bdaf17  vmovaps xmm11, [rsp+0xB0]
00007b4681bdaf20  vmovaps xmm12, [rsp+0xC0]
00007b4681bdaf29  vmovaps xmm13, [rsp+0xD0]
00007b4681bdaf32  vmovaps xmm15, [rsp+0xE0]
00007b4681bdaf3b  add rsp, 0xF0
00007b4681bdaf42  pop r11
00007b4681bdaf44  pop r10
00007b4681bdaf46  pop r9
00007b4681bdaf48  pop r8
00007b4681bdaf4a  pop rsi
00007b4681bdaf4b  pop rdi
00007b4681bdaf4c  pop rdx
00007b4681bdaf4d  pop rcx
00007b4681bdaf4e  pop rax
00007b4681bdaf4f  add rsp, 0x08
00007b4681bdaf53  jmp 0x00007B4681BDA01C
00007b4681bdaf58  sub rsp, 0x08
00007b4681bdaf5c  push rax
00007b4681bdaf5d  push rcx
00007b4681bdaf5e  push rdx
00007b4681bdaf5f  push rdi
00007b4681bdaf60  push rsi
00007b4681bdaf61  push r8
00007b4681bdaf63  push r9
00007b4681bdaf65  push r10
00007b4681bdaf67  push r11
00007b4681bdaf69  sub rsp, 0xF0
00007b4681bdaf70  vmovaps [rsp], xmm0
00007b4681bdaf75  vmovaps [rsp+0x10], xmm1
00007b4681bdaf7b  vmovaps [rsp+0x20], xmm3
00007b4681bdaf81  vmovaps [rsp+0x30], xmm4
00007b4681bdaf87  vmovaps [rsp+0x40], xmm5
00007b4681bdaf8d  vmovaps [rsp+0x50], xmm6
00007b4681bdaf93  vmovaps [rsp+0x60], xmm7
00007b4681bdaf99  vmovaps [rsp+0x70], xmm8
00007b4681bdaf9f  vmovaps [rsp+0x80], xmm9
00007b4681bdafa8  vmovaps [rsp+0x90], xmm10
00007b4681bdafb1  vmovaps [rsp+0xA0], xmm11
00007b4681bdafba  vmovaps [rsp+0xB0], xmm12
00007b4681bdafc3  vmovaps [rsp+0xC0], xmm13
00007b4681bdafcc  vmovaps [rsp+0xD0], xmm14
00007b4681bdafd5  vmovaps [rsp+0xE0], xmm15
00007b4681bdafde  sub rsp, 0x40
00007b4681bdafe2  lea rdi, [rsp]
00007b4681bdafe6  lea rsi, [rsp+0x10]
00007b4681bdafeb  lea rdx, [rsp+0x20]
00007b4681bdaff0  lea rcx, [rsp+0x30]
00007b4681bdaff5  mov r8d, 0x00
00007b4681bdaffb  lea r9, [r15+0x3A8]
00007b4681bdb002  movaps [rdi], xmm2
00007b4681bdb005  movaps [rsi], xmm15
00007b4681bdb009  movaps [rdx], xmm12
00007b4681bdb00d  movaps [rcx], xmm1
00007b4681bdb010  mov rax, 0x5668589B5A50
00007b4681bdb01a  call rax
00007b4681bdb01c  movaps xmm2, [rsp]
00007b4681bdb020  add rsp, 0x40
00007b4681bdb024  vmovaps xmm0, [rsp]
00007b4681bdb029  vmovaps xmm1, [rsp+0x10]
00007b4681bdb02f  vmovaps xmm3, [rsp+0x20]
00007b4681bdb035  vmovaps xmm4, [rsp+0x30]
00007b4681bdb03b  vmovaps xmm5, [rsp+0x40]
00007b4681bdb041  vmovaps xmm6, [rsp+0x50]
00007b4681bdb047  vmovaps xmm7, [rsp+0x60]
00007b4681bdb04d  vmovaps xmm8, [rsp+0x70]
00007b4681bdb053  vmovaps xmm9, [rsp+0x80]
00007b4681bdb05c  vmovaps xmm10, [rsp+0x90]
00007b4681bdb065  vmovaps xmm11, [rsp+0xA0]
00007b4681bdb06e  vmovaps xmm12, [rsp+0xB0]
00007b4681bdb077  vmovaps xmm13, [rsp+0xC0]
00007b4681bdb080  vmovaps xmm14, [rsp+0xD0]
00007b4681bdb089  vmovaps xmm15, [rsp+0xE0]
00007b4681bdb092  add rsp, 0xF0
00007b4681bdb099  pop r11
00007b4681bdb09b  pop r10
00007b4681bdb09d  pop r9
00007b4681bdb09f  pop r8
00007b4681bdb0a1  pop rsi
00007b4681bdb0a2  pop rdi
00007b4681bdb0a3  pop rdx
00007b4681bdb0a4  pop rcx
00007b4681bdb0a5  pop rax
00007b4681bdb0a6  add rsp, 0x08
00007b4681bdb0aa  jmp 0x00007B4681BDA059
00007b4681bdb0af  sub rsp, 0x08
00007b4681bdb0b3  push rax
00007b4681bdb0b4  push rcx
00007b4681bdb0b5  push rdx
00007b4681bdb0b6  push rdi
00007b4681bdb0b7  push rsi
00007b4681bdb0b8  push r8
00007b4681bdb0ba  push r9
00007b4681bdb0bc  push r10
00007b4681bdb0be  push r11
00007b4681bdb0c0  sub rsp, 0xF0
00007b4681bdb0c7  vmovaps [rsp], xmm0
00007b4681bdb0cc  vmovaps [rsp+0x10], xmm1
00007b4681bdb0d2  vmovaps [rsp+0x20], xmm2
00007b4681bdb0d8  vmovaps [rsp+0x30], xmm3
00007b4681bdb0de  vmovaps [rsp+0x40], xmm4
00007b4681bdb0e4  vmovaps [rsp+0x50], xmm5
00007b4681bdb0ea  vmovaps [rsp+0x60], xmm6
00007b4681bdb0f0  vmovaps [rsp+0x70], xmm7
00007b4681bdb0f6  vmovaps [rsp+0x80], xmm8
00007b4681bdb0ff  vmovaps [rsp+0x90], xmm9
00007b4681bdb108  vmovaps [rsp+0xA0], xmm10
00007b4681bdb111  vmovaps [rsp+0xB0], xmm11
00007b4681bdb11a  vmovaps [rsp+0xC0], xmm13
00007b4681bdb123  vmovaps [rsp+0xD0], xmm14
00007b4681bdb12c  vmovaps [rsp+0xE0], xmm15
00007b4681bdb135  sub rsp, 0x40
00007b4681bdb139  lea rdi, [rsp]
00007b4681bdb13d  lea rsi, [rsp+0x10]
00007b4681bdb142  lea rdx, [rsp+0x20]
00007b4681bdb147  lea rcx, [rsp+0x30]
00007b4681bdb14c  mov r8d, 0x00
00007b4681bdb152  lea r9, [r15+0x3A8]
00007b4681bdb159  movaps [rdi], xmm12
00007b4681bdb15d  movaps [rsi], xmm14
00007b4681bdb161  movaps [rdx], xmm3
00007b4681bdb164  movaps [rcx], xmm15
00007b4681bdb168  mov rax, 0x5668589B5A50
00007b4681bdb172  call rax
00007b4681bdb174  movaps xmm12, [rsp]
00007b4681bdb179  add rsp, 0x40
00007b4681bdb17d  vmovaps xmm0, [rsp]
00007b4681bdb182  vmovaps xmm1, [rsp+0x10]
00007b4681bdb188  vmovaps xmm2, [rsp+0x20]
00007b4681bdb18e  vmovaps xmm3, [rsp+0x30]
00007b4681bdb194  vmovaps xmm4, [rsp+0x40]
00007b4681bdb19a  vmovaps xmm5, [rsp+0x50]
00007b4681bdb1a0  vmovaps xmm6, [rsp+0x60]
00007b4681bdb1a6  vmovaps xmm7, [rsp+0x70]
00007b4681bdb1ac  vmovaps xmm8, [rsp+0x80]
00007b4681bdb1b5  vmovaps xmm9, [rsp+0x90]
00007b4681bdb1be  vmovaps xmm10, [rsp+0xA0]
00007b4681bdb1c7  vmovaps xmm11, [rsp+0xB0]
00007b4681bdb1d0  vmovaps xmm13, [rsp+0xC0]
00007b4681bdb1d9  vmovaps xmm14, [rsp+0xD0]
00007b4681bdb1e2  vmovaps xmm15, [rsp+0xE0]
00007b4681bdb1eb  add rsp, 0xF0
00007b4681bdb1f2  pop r11
00007b4681bdb1f4  pop r10
00007b4681bdb1f6  pop r9
00007b4681bdb1f8  pop r8
00007b4681bdb1fa  pop rsi
00007b4681bdb1fb  pop rdi
00007b4681bdb1fc  pop rdx
00007b4681bdb1fd  pop rcx
00007b4681bdb1fe  pop rax
00007b4681bdb1ff  add rsp, 0x08
00007b4681bdb203  jmp 0x00007B4681BDA0B3
00007b4681bdb208  sub rsp, 0x08
00007b4681bdb20c  push rax
00007b4681bdb20d  push rcx
00007b4681bdb20e  push rdx
00007b4681bdb20f  push rdi
00007b4681bdb210  push rsi
00007b4681bdb211  push r8
00007b4681bdb213  push r9
00007b4681bdb215  push r10
00007b4681bdb217  push r11
00007b4681bdb219  sub rsp, 0xF0
00007b4681bdb220  vmovaps [rsp], xmm0
00007b4681bdb225  vmovaps [rsp+0x10], xmm1
00007b4681bdb22b  vmovaps [rsp+0x20], xmm2
00007b4681bdb231  vmovaps [rsp+0x30], xmm3
00007b4681bdb237  vmovaps [rsp+0x40], xmm4
00007b4681bdb23d  vmovaps [rsp+0x50], xmm5
00007b4681bdb243  vmovaps [rsp+0x60], xmm6
00007b4681bdb249  vmovaps [rsp+0x70], xmm7
00007b4681bdb24f  vmovaps [rsp+0x80], xmm8
00007b4681bdb258  vmovaps [rsp+0x90], xmm10
00007b4681bdb261  vmovaps [rsp+0xA0], xmm11
00007b4681bdb26a  vmovaps [rsp+0xB0], xmm12
00007b4681bdb273  vmovaps [rsp+0xC0], xmm13
00007b4681bdb27c  vmovaps [rsp+0xD0], xmm14
00007b4681bdb285  vmovaps [rsp+0xE0], xmm15
00007b4681bdb28e  sub rsp, 0x40
00007b4681bdb292  lea rdi, [rsp]
00007b4681bdb296  lea rsi, [rsp+0x10]
00007b4681bdb29b  lea rdx, [rsp+0x20]
00007b4681bdb2a0  lea rcx, [rsp+0x30]
00007b4681bdb2a5  mov r8d, 0x00
00007b4681bdb2ab  lea r9, [r15+0x3A8]
00007b4681bdb2b2  movaps [rdi], xmm9
00007b4681bdb2b6  movaps [rsi], xmm13
00007b4681bdb2ba  movaps [rdx], xmm14
00007b4681bdb2be  movaps [rcx], xmm6
00007b4681bdb2c1  mov rax, 0x5668589B5A50
00007b4681bdb2cb  call rax
00007b4681bdb2cd  movaps xmm9, [rsp]
00007b4681bdb2d2  add rsp, 0x40
00007b4681bdb2d6  vmovaps xmm0, [rsp]
00007b4681bdb2db  vmovaps xmm1, [rsp+0x10]
00007b4681bdb2e1  vmovaps xmm2, [rsp+0x20]
00007b4681bdb2e7  vmovaps xmm3, [rsp+0x30]
00007b4681bdb2ed  vmovaps xmm4, [rsp+0x40]
00007b4681bdb2f3  vmovaps xmm5, [rsp+0x50]
00007b4681bdb2f9  vmovaps xmm6, [rsp+0x60]
00007b4681bdb2ff  vmovaps xmm7, [rsp+0x70]
00007b4681bdb305  vmovaps xmm8, [rsp+0x80]
00007b4681bdb30e  vmovaps xmm10, [rsp+0x90]
00007b4681bdb317  vmovaps xmm11, [rsp+0xA0]
00007b4681bdb320  vmovaps xmm12, [rsp+0xB0]
00007b4681bdb329  vmovaps xmm13, [rsp+0xC0]
00007b4681bdb332  vmovaps xmm14, [rsp+0xD0]
00007b4681bdb33b  vmovaps xmm15, [rsp+0xE0]
00007b4681bdb344  add rsp, 0xF0
00007b4681bdb34b  pop r11
00007b4681bdb34d  pop r10
00007b4681bdb34f  pop r9
00007b4681bdb351  pop r8
00007b4681bdb353  pop rsi
00007b4681bdb354  pop rdi
00007b4681bdb355  pop rdx
00007b4681bdb356  pop rcx
00007b4681bdb357  pop rax
00007b4681bdb358  add rsp, 0x08
00007b4681bdb35c  jmp 0x00007B4681BDA15D
00007b4681bdb361  sub rsp, 0x08
00007b4681bdb365  push rax
00007b4681bdb366  push rcx
00007b4681bdb367  push rdx
00007b4681bdb368  push rdi
00007b4681bdb369  push rsi
00007b4681bdb36a  push r8
00007b4681bdb36c  push r9
00007b4681bdb36e  push r10
00007b4681bdb370  push r11
00007b4681bdb372  sub rsp, 0xF0
00007b4681bdb379  vmovaps [rsp], xmm0
00007b4681bdb37e  vmovaps [rsp+0x10], xmm1
00007b4681bdb384  vmovaps [rsp+0x20], xmm2
00007b4681bdb38a  vmovaps [rsp+0x30], xmm4
00007b4681bdb390  vmovaps [rsp+0x40], xmm5
00007b4681bdb396  vmovaps [rsp+0x50], xmm6
00007b4681bdb39c  vmovaps [rsp+0x60], xmm7
00007b4681bdb3a2  vmovaps [rsp+0x70], xmm8
00007b4681bdb3a8  vmovaps [rsp+0x80], xmm9
00007b4681bdb3b1  vmovaps [rsp+0x90], xmm10
00007b4681bdb3ba  vmovaps [rsp+0xA0], xmm11
00007b4681bdb3c3  vmovaps [rsp+0xB0], xmm12
00007b4681bdb3cc  vmovaps [rsp+0xC0], xmm13
00007b4681bdb3d5  vmovaps [rsp+0xD0], xmm14
00007b4681bdb3de  vmovaps [rsp+0xE0], xmm15
00007b4681bdb3e7  sub rsp, 0x40
00007b4681bdb3eb  lea rdi, [rsp]
00007b4681bdb3ef  lea rsi, [rsp+0x10]
00007b4681bdb3f4  lea rdx, [rsp+0x20]
00007b4681bdb3f9  lea rcx, [rsp+0x30]
00007b4681bdb3fe  mov r8d, 0x00
00007b4681bdb404  lea r9, [r15+0x3A8]
00007b4681bdb40b  movaps [rdi], xmm3
00007b4681bdb40e  movaps [rsi], xmm13
00007b4681bdb412  movaps [rdx], xmm6
00007b4681bdb415  movaps [rcx], xmm14
00007b4681bdb419  mov rax, 0x5668589B5A50
00007b4681bdb423  call rax
00007b4681bdb425  movaps xmm3, [rsp]
00007b4681bdb429  add rsp, 0x40
00007b4681bdb42d  vmovaps xmm0, [rsp]
00007b4681bdb432  vmovaps xmm1, [rsp+0x10]
00007b4681bdb438  vmovaps xmm2, [rsp+0x20]
00007b4681bdb43e  vmovaps xmm4, [rsp+0x30]
00007b4681bdb444  vmovaps xmm5, [rsp+0x40]
00007b4681bdb44a  vmovaps xmm6, [rsp+0x50]
00007b4681bdb450  vmovaps xmm7, [rsp+0x60]
00007b4681bdb456  vmovaps xmm8, [rsp+0x70]
00007b4681bdb45c  vmovaps xmm9, [rsp+0x80]
00007b4681bdb465  vmovaps xmm10, [rsp+0x90]
00007b4681bdb46e  vmovaps xmm11, [rsp+0xA0]
00007b4681bdb477  vmovaps xmm12, [rsp+0xB0]
00007b4681bdb480  vmovaps xmm13, [rsp+0xC0]
00007b4681bdb489  vmovaps xmm14, [rsp+0xD0]
00007b4681bdb492  vmovaps xmm15, [rsp+0xE0]
00007b4681bdb49b  add rsp, 0xF0
00007b4681bdb4a2  pop r11
00007b4681bdb4a4  pop r10
00007b4681bdb4a6  pop r9
00007b4681bdb4a8  pop r8
00007b4681bdb4aa  pop rsi
00007b4681bdb4ab  pop rdi
00007b4681bdb4ac  pop rdx
00007b4681bdb4ad  pop rcx
00007b4681bdb4ae  pop rax
00007b4681bdb4af  add rsp, 0x08
00007b4681bdb4b3  jmp 0x00007B4681BDA19A
00007b4681bdb4b8  sub rsp, 0x08
00007b4681bdb4bc  push rax
00007b4681bdb4bd  push rcx
00007b4681bdb4be  push rdx
00007b4681bdb4bf  push rdi
00007b4681bdb4c0  push rsi
00007b4681bdb4c1  push r8
00007b4681bdb4c3  push r9
00007b4681bdb4c5  push r10
00007b4681bdb4c7  push r11
00007b4681bdb4c9  sub rsp, 0xF0
00007b4681bdb4d0  vmovaps [rsp], xmm0
00007b4681bdb4d5  vmovaps [rsp+0x10], xmm1
00007b4681bdb4db  vmovaps [rsp+0x20], xmm2
00007b4681bdb4e1  vmovaps [rsp+0x30], xmm3
00007b4681bdb4e7  vmovaps [rsp+0x40], xmm4
00007b4681bdb4ed  vmovaps [rsp+0x50], xmm5
00007b4681bdb4f3  vmovaps [rsp+0x60], xmm7
00007b4681bdb4f9  vmovaps [rsp+0x70], xmm8
00007b4681bdb4ff  vmovaps [rsp+0x80], xmm9
00007b4681bdb508  vmovaps [rsp+0x90], xmm10
00007b4681bdb511  vmovaps [rsp+0xA0], xmm11
00007b4681bdb51a  vmovaps [rsp+0xB0], xmm12
00007b4681bdb523  vmovaps [rsp+0xC0], xmm13
00007b4681bdb52c  vmovaps [rsp+0xD0], xmm14
00007b4681bdb535  vmovaps [rsp+0xE0], xmm15
00007b4681bdb53e  sub rsp, 0x40
00007b4681bdb542  lea rdi, [rsp]
00007b4681bdb546  lea rsi, [rsp+0x10]
00007b4681bdb54b  lea rdx, [rsp+0x20]
00007b4681bdb550  lea rcx, [rsp+0x30]
00007b4681bdb555  mov r8d, 0x00
00007b4681bdb55b  lea r9, [r15+0x3A8]
00007b4681bdb562  movaps [rdi], xmm6
00007b4681bdb565  movaps [rsi], xmm2
00007b4681bdb568  movaps [rdx], xmm14
00007b4681bdb56c  movaps [rcx], xmm1
00007b4681bdb56f  mov rax, 0x5668589B5A50
00007b4681bdb579  call rax
00007b4681bdb57b  movaps xmm6, [rsp]
00007b4681bdb57f  add rsp, 0x40
00007b4681bdb583  vmovaps xmm0, [rsp]
00007b4681bdb588  vmovaps xmm1, [rsp+0x10]
00007b4681bdb58e  vmovaps xmm2, [rsp+0x20]
00007b4681bdb594  vmovaps xmm3, [rsp+0x30]
00007b4681bdb59a  vmovaps xmm4, [rsp+0x40]
00007b4681bdb5a0  vmovaps xmm5, [rsp+0x50]
00007b4681bdb5a6  vmovaps xmm7, [rsp+0x60]
00007b4681bdb5ac  vmovaps xmm8, [rsp+0x70]
00007b4681bdb5b2  vmovaps xmm9, [rsp+0x80]
00007b4681bdb5bb  vmovaps xmm10, [rsp+0x90]
00007b4681bdb5c4  vmovaps xmm11, [rsp+0xA0]
00007b4681bdb5cd  vmovaps xmm12, [rsp+0xB0]
00007b4681bdb5d6  vmovaps xmm13, [rsp+0xC0]
00007b4681bdb5df  vmovaps xmm14, [rsp+0xD0]
00007b4681bdb5e8  vmovaps xmm15, [rsp+0xE0]
00007b4681bdb5f1  add rsp, 0xF0
00007b4681bdb5f8  pop r11
00007b4681bdb5fa  pop r10
00007b4681bdb5fc  pop r9
00007b4681bdb5fe  pop r8
00007b4681bdb600  pop rsi
00007b4681bdb601  pop rdi
00007b4681bdb602  pop rdx
00007b4681bdb603  pop rcx
00007b4681bdb604  pop rax
00007b4681bdb605  add rsp, 0x08
00007b4681bdb609  jmp 0x00007B4681BDA1C7
00007b4681bdb60e  sub rsp, 0x08
00007b4681bdb612  push rax
00007b4681bdb613  push rcx
00007b4681bdb614  push rdx
00007b4681bdb615  push rdi
00007b4681bdb616  push rsi
00007b4681bdb617  push r8
00007b4681bdb619  push r9
00007b4681bdb61b  push r10
00007b4681bdb61d  push r11
00007b4681bdb61f  sub rsp, 0xF0
00007b4681bdb626  vmovaps [rsp], xmm0
00007b4681bdb62b  vmovaps [rsp+0x10], xmm1
00007b4681bdb631  vmovaps [rsp+0x20], xmm2
00007b4681bdb637  vmovaps [rsp+0x30], xmm3
00007b4681bdb63d  vmovaps [rsp+0x40], xmm4
00007b4681bdb643  vmovaps [rsp+0x50], xmm5
00007b4681bdb649  vmovaps [rsp+0x60], xmm6
00007b4681bdb64f  vmovaps [rsp+0x70], xmm7
00007b4681bdb655  vmovaps [rsp+0x80], xmm8
00007b4681bdb65e  vmovaps [rsp+0x90], xmm9
00007b4681bdb667  vmovaps [rsp+0xA0], xmm10
00007b4681bdb670  vmovaps [rsp+0xB0], xmm11
00007b4681bdb679  vmovaps [rsp+0xC0], xmm12
00007b4681bdb682  vmovaps [rsp+0xD0], xmm14
00007b4681bdb68b  vmovaps [rsp+0xE0], xmm15
00007b4681bdb694  sub rsp, 0x40
00007b4681bdb698  lea rdi, [rsp]
00007b4681bdb69c  lea rsi, [rsp+0x10]
00007b4681bdb6a1  lea rdx, [rsp+0x20]
00007b4681bdb6a6  lea rcx, [rsp+0x30]
00007b4681bdb6ab  mov r8d, 0x00
00007b4681bdb6b1  lea r9, [r15+0x3A8]
00007b4681bdb6b8  movaps [rdi], xmm13
00007b4681bdb6bc  movaps [rsi], xmm12
00007b4681bdb6c0  movaps [rdx], xmm14
00007b4681bdb6c4  movaps [rcx], xmm1
00007b4681bdb6c7  mov rax, 0x5668589B5A50
00007b4681bdb6d1  call rax
00007b4681bdb6d3  movaps xmm13, [rsp]
00007b4681bdb6d8  add rsp, 0x40
00007b4681bdb6dc  vmovaps xmm0, [rsp]
00007b4681bdb6e1  vmovaps xmm1, [rsp+0x10]
00007b4681bdb6e7  vmovaps xmm2, [rsp+0x20]
00007b4681bdb6ed  vmovaps xmm3, [rsp+0x30]
00007b4681bdb6f3  vmovaps xmm4, [rsp+0x40]
00007b4681bdb6f9  vmovaps xmm5, [rsp+0x50]
00007b4681bdb6ff  vmovaps xmm6, [rsp+0x60]
00007b4681bdb705  vmovaps xmm7, [rsp+0x70]
00007b4681bdb70b  vmovaps xmm8, [rsp+0x80]
00007b4681bdb714  vmovaps xmm9, [rsp+0x90]
00007b4681bdb71d  vmovaps xmm10, [rsp+0xA0]
00007b4681bdb726  vmovaps xmm11, [rsp+0xB0]
00007b4681bdb72f  vmovaps xmm12, [rsp+0xC0]
00007b4681bdb738  vmovaps xmm14, [rsp+0xD0]
00007b4681bdb741  vmovaps xmm15, [rsp+0xE0]
00007b4681bdb74a  add rsp, 0xF0
00007b4681bdb751  pop r11
00007b4681bdb753  pop r10
00007b4681bdb755  pop r9
00007b4681bdb757  pop r8
00007b4681bdb759  pop rsi
00007b4681bdb75a  pop rdi
00007b4681bdb75b  pop rdx
00007b4681bdb75c  pop rcx
00007b4681bdb75d  pop rax
00007b4681bdb75e  add rsp, 0x08
00007b4681bdb762  jmp 0x00007B4681BDA1F9
00007b4681bdb767  sub rsp, 0x08
00007b4681bdb76b  push rax
00007b4681bdb76c  push rcx
00007b4681bdb76d  push rdx
00007b4681bdb76e  push rdi
00007b4681bdb76f  push rsi
00007b4681bdb770  push r8
00007b4681bdb772  push r9
00007b4681bdb774  push r10
00007b4681bdb776  push r11
00007b4681bdb778  sub rsp, 0xF0
00007b4681bdb77f  vmovaps [rsp], xmm0
00007b4681bdb784  vmovaps [rsp+0x10], xmm1
00007b4681bdb78a  vmovaps [rsp+0x20], xmm2
00007b4681bdb790  vmovaps [rsp+0x30], xmm3
00007b4681bdb796  vmovaps [rsp+0x40], xmm4
00007b4681bdb79c  vmovaps [rsp+0x50], xmm5
00007b4681bdb7a2  vmovaps [rsp+0x60], xmm6
00007b4681bdb7a8  vmovaps [rsp+0x70], xmm7
00007b4681bdb7ae  vmovaps [rsp+0x80], xmm8
00007b4681bdb7b7  vmovaps [rsp+0x90], xmm9
00007b4681bdb7c0  vmovaps [rsp+0xA0], xmm10
00007b4681bdb7c9  vmovaps [rsp+0xB0], xmm11
00007b4681bdb7d2  vmovaps [rsp+0xC0], xmm13
00007b4681bdb7db  vmovaps [rsp+0xD0], xmm14
00007b4681bdb7e4  vmovaps [rsp+0xE0], xmm15
00007b4681bdb7ed  sub rsp, 0x40
00007b4681bdb7f1  lea rdi, [rsp]
00007b4681bdb7f5  lea rsi, [rsp+0x10]
00007b4681bdb7fa  lea rdx, [rsp+0x20]
00007b4681bdb7ff  lea rcx, [rsp+0x30]
00007b4681bdb804  mov r8d, 0x00
00007b4681bdb80a  lea r9, [r15+0x3A8]
00007b4681bdb811  movaps [rdi], xmm12
00007b4681bdb815  movaps [rsi], xmm3
00007b4681bdb818  movaps [rdx], xmm14
00007b4681bdb81c  movaps [rcx], xmm5
00007b4681bdb81f  mov rax, 0x5668589B5A50
00007b4681bdb829  call rax
00007b4681bdb82b  movaps xmm12, [rsp]
00007b4681bdb830  add rsp, 0x40
00007b4681bdb834  vmovaps xmm0, [rsp]
00007b4681bdb839  vmovaps xmm1, [rsp+0x10]
00007b4681bdb83f  vmovaps xmm2, [rsp+0x20]
00007b4681bdb845  vmovaps xmm3, [rsp+0x30]
00007b4681bdb84b  vmovaps xmm4, [rsp+0x40]
00007b4681bdb851  vmovaps xmm5, [rsp+0x50]
00007b4681bdb857  vmovaps xmm6, [rsp+0x60]
00007b4681bdb85d  vmovaps xmm7, [rsp+0x70]
00007b4681bdb863  vmovaps xmm8, [rsp+0x80]
00007b4681bdb86c  vmovaps xmm9, [rsp+0x90]
00007b4681bdb875  vmovaps xmm10, [rsp+0xA0]
00007b4681bdb87e  vmovaps xmm11, [rsp+0xB0]
00007b4681bdb887  vmovaps xmm13, [rsp+0xC0]
00007b4681bdb890  vmovaps xmm14, [rsp+0xD0]
00007b4681bdb899  vmovaps xmm15, [rsp+0xE0]
00007b4681bdb8a2  add rsp, 0xF0
00007b4681bdb8a9  pop r11
00007b4681bdb8ab  pop r10
00007b4681bdb8ad  pop r9
00007b4681bdb8af  pop r8
00007b4681bdb8b1  pop rsi
00007b4681bdb8b2  pop rdi
00007b4681bdb8b3  pop rdx
00007b4681bdb8b4  pop rcx
00007b4681bdb8b5  pop rax
00007b4681bdb8b6  add rsp, 0x08
00007b4681bdb8ba  jmp 0x00007B4681BDA256
00007b4681bdb8bf  sub rsp, 0x08
00007b4681bdb8c3  push rax
00007b4681bdb8c4  push rcx
00007b4681bdb8c5  push rdx
00007b4681bdb8c6  push rdi
00007b4681bdb8c7  push rsi
00007b4681bdb8c8  push r8
00007b4681bdb8ca  push r9
00007b4681bdb8cc  push r10
00007b4681bdb8ce  push r11
00007b4681bdb8d0  sub rsp, 0xF0
00007b4681bdb8d7  vmovaps [rsp], xmm0
00007b4681bdb8dc  vmovaps [rsp+0x10], xmm1
00007b4681bdb8e2  vmovaps [rsp+0x20], xmm2
00007b4681bdb8e8  vmovaps [rsp+0x30], xmm3
00007b4681bdb8ee  vmovaps [rsp+0x40], xmm4
00007b4681bdb8f4  vmovaps [rsp+0x50], xmm5
00007b4681bdb8fa  vmovaps [rsp+0x60], xmm6
00007b4681bdb900  vmovaps [rsp+0x70], xmm7
00007b4681bdb906  vmovaps [rsp+0x80], xmm8
00007b4681bdb90f  vmovaps [rsp+0x90], xmm9
00007b4681bdb918  vmovaps [rsp+0xA0], xmm11
00007b4681bdb921  vmovaps [rsp+0xB0], xmm12
00007b4681bdb92a  vmovaps [rsp+0xC0], xmm13
00007b4681bdb933  vmovaps [rsp+0xD0], xmm14
00007b4681bdb93c  vmovaps [rsp+0xE0], xmm15
00007b4681bdb945  sub rsp, 0x40
00007b4681bdb949  lea rdi, [rsp]
00007b4681bdb94d  lea rsi, [rsp+0x10]
00007b4681bdb952  lea rdx, [rsp+0x20]
00007b4681bdb957  lea rcx, [rsp+0x30]
00007b4681bdb95c  mov r8d, 0x00
00007b4681bdb962  lea r9, [r15+0x3A8]
00007b4681bdb969  movaps [rdi], xmm10
00007b4681bdb96d  movaps [rsi], xmm9
00007b4681bdb971  movaps [rdx], xmm7
00007b4681bdb974  movaps [rcx], xmm14
00007b4681bdb978  mov rax, 0x5668589B5A50
00007b4681bdb982  call rax
00007b4681bdb984  movaps xmm10, [rsp]
00007b4681bdb989  add rsp, 0x40
00007b4681bdb98d  vmovaps xmm0, [rsp]
00007b4681bdb992  vmovaps xmm1, [rsp+0x10]
00007b4681bdb998  vmovaps xmm2, [rsp+0x20]
00007b4681bdb99e  vmovaps xmm3, [rsp+0x30]
00007b4681bdb9a4  vmovaps xmm4, [rsp+0x40]
00007b4681bdb9aa  vmovaps xmm5, [rsp+0x50]
00007b4681bdb9b0  vmovaps xmm6, [rsp+0x60]
00007b4681bdb9b6  vmovaps xmm7, [rsp+0x70]
00007b4681bdb9bc  vmovaps xmm8, [rsp+0x80]
00007b4681bdb9c5  vmovaps xmm9, [rsp+0x90]
00007b4681bdb9ce  vmovaps xmm11, [rsp+0xA0]
00007b4681bdb9d7  vmovaps xmm12, [rsp+0xB0]
00007b4681bdb9e0  vmovaps xmm13, [rsp+0xC0]
00007b4681bdb9e9  vmovaps xmm14, [rsp+0xD0]
00007b4681bdb9f2  vmovaps xmm15, [rsp+0xE0]
00007b4681bdb9fb  add rsp, 0xF0
00007b4681bdba02  pop r11
00007b4681bdba04  pop r10
00007b4681bdba06  pop r9
00007b4681bdba08  pop r8
00007b4681bdba0a  pop rsi
00007b4681bdba0b  pop rdi
00007b4681bdba0c  pop rdx
00007b4681bdba0d  pop rcx
00007b4681bdba0e  pop rax
00007b4681bdba0f  add rsp, 0x08
00007b4681bdba13  jmp 0x00007B4681BDA27C
00007b4681bdba18  call 0x00007B4681A0D4E0
00007b4681bdba1d  jmp 0x00007B4681BDA289
00007b4681bdba22  sub rsp, 0x08
00007b4681bdba26  push rax
00007b4681bdba27  push rcx
00007b4681bdba28  push rdx
00007b4681bdba29  push rdi
00007b4681bdba2a  push rsi
00007b4681bdba2b  push r8
00007b4681bdba2d  push r9
00007b4681bdba2f  push r10
00007b4681bdba31  push r11
00007b4681bdba33  sub rsp, 0xF0
00007b4681bdba3a  vmovaps [rsp], xmm0
00007b4681bdba3f  vmovaps [rsp+0x10], xmm1
00007b4681bdba45  vmovaps [rsp+0x20], xmm2
00007b4681bdba4b  vmovaps [rsp+0x30], xmm3
00007b4681bdba51  vmovaps [rsp+0x40], xmm4
00007b4681bdba57  vmovaps [rsp+0x50], xmm6
00007b4681bdba5d  vmovaps [rsp+0x60], xmm7
00007b4681bdba63  vmovaps [rsp+0x70], xmm8
00007b4681bdba69  vmovaps [rsp+0x80], xmm9
00007b4681bdba72  vmovaps [rsp+0x90], xmm10
00007b4681bdba7b  vmovaps [rsp+0xA0], xmm11
00007b4681bdba84  vmovaps [rsp+0xB0], xmm12
00007b4681bdba8d  vmovaps [rsp+0xC0], xmm13
00007b4681bdba96  vmovaps [rsp+0xD0], xmm14
00007b4681bdba9f  vmovaps [rsp+0xE0], xmm15
00007b4681bdbaa8  sub rsp, 0x40
00007b4681bdbaac  lea rdi, [rsp]
00007b4681bdbab0  lea rsi, [rsp+0x10]
00007b4681bdbab5  lea rdx, [rsp+0x20]
00007b4681bdbaba  lea rcx, [rsp+0x30]
00007b4681bdbabf  mov r8d, 0x00
00007b4681bdbac5  lea r9, [r15+0x3A8]
00007b4681bdbacc  movaps [rdi], xmm5
00007b4681bdbacf  movaps [rsi], xmm6
00007b4681bdbad2  movaps [rdx], xmm7
00007b4681bdbad5  movaps [rcx], xmm9
00007b4681bdbad9  mov rax, 0x5668589B5A50
00007b4681bdbae3  call rax
00007b4681bdbae5  movaps xmm5, [rsp]
00007b4681bdbae9  add rsp, 0x40
00007b4681bdbaed  vmovaps xmm0, [rsp]
00007b4681bdbaf2  vmovaps xmm1, [rsp+0x10]
00007b4681bdbaf8  vmovaps xmm2, [rsp+0x20]
00007b4681bdbafe  vmovaps xmm3, [rsp+0x30]
00007b4681bdbb04  vmovaps xmm4, [rsp+0x40]
00007b4681bdbb0a  vmovaps xmm6, [rsp+0x50]
00007b4681bdbb10  vmovaps xmm7, [rsp+0x60]
00007b4681bdbb16  vmovaps xmm8, [rsp+0x70]
00007b4681bdbb1c  vmovaps xmm9, [rsp+0x80]
00007b4681bdbb25  vmovaps xmm10, [rsp+0x90]
00007b4681bdbb2e  vmovaps xmm11, [rsp+0xA0]
00007b4681bdbb37  vmovaps xmm12, [rsp+0xB0]
00007b4681bdbb40  vmovaps xmm13, [rsp+0xC0]
00007b4681bdbb49  vmovaps xmm14, [rsp+0xD0]
00007b4681bdbb52  vmovaps xmm15, [rsp+0xE0]
00007b4681bdbb5b  add rsp, 0xF0
00007b4681bdbb62  pop r11
00007b4681bdbb64  pop r10
00007b4681bdbb66  pop r9
00007b4681bdbb68  pop r8
00007b4681bdbb6a  pop rsi
00007b4681bdbb6b  pop rdi
00007b4681bdbb6c  pop rdx
00007b4681bdbb6d  pop rcx
00007b4681bdbb6e  pop rax
00007b4681bdbb6f  add rsp, 0x08
00007b4681bdbb73  jmp 0x00007B4681BDA2BB
00007b4681bdbb78  sub rsp, 0x08
00007b4681bdbb7c  push rax
00007b4681bdbb7d  push rcx
00007b4681bdbb7e  push rdx
00007b4681bdbb7f  push rdi
00007b4681bdbb80  push rsi
00007b4681bdbb81  push r8
00007b4681bdbb83  push r9
00007b4681bdbb85  push r10
00007b4681bdbb87  push r11
00007b4681bdbb89  sub rsp, 0xF0
00007b4681bdbb90  vmovaps [rsp], xmm0
00007b4681bdbb95  vmovaps [rsp+0x10], xmm1
00007b4681bdbb9b  vmovaps [rsp+0x20], xmm2
00007b4681bdbba1  vmovaps [rsp+0x30], xmm3
00007b4681bdbba7  vmovaps [rsp+0x40], xmm4
00007b4681bdbbad  vmovaps [rsp+0x50], xmm5
00007b4681bdbbb3  vmovaps [rsp+0x60], xmm6
00007b4681bdbbb9  vmovaps [rsp+0x70], xmm8
00007b4681bdbbbf  vmovaps [rsp+0x80], xmm9
00007b4681bdbbc8  vmovaps [rsp+0x90], xmm10
00007b4681bdbbd1  vmovaps [rsp+0xA0], xmm11
00007b4681bdbbda  vmovaps [rsp+0xB0], xmm12
00007b4681bdbbe3  vmovaps [rsp+0xC0], xmm13
00007b4681bdbbec  vmovaps [rsp+0xD0], xmm14
00007b4681bdbbf5  vmovaps [rsp+0xE0], xmm15
00007b4681bdbbfe  sub rsp, 0x40
00007b4681bdbc02  lea rdi, [rsp]
00007b4681bdbc06  lea rsi, [rsp+0x10]
00007b4681bdbc0b  lea rdx, [rsp+0x20]
00007b4681bdbc10  lea rcx, [rsp+0x30]
00007b4681bdbc15  mov r8d, 0x00
00007b4681bdbc1b  lea r9, [r15+0x3A8]
00007b4681bdbc22  movaps [rdi], xmm7
00007b4681bdbc25  movaps [rsi], xmm13
00007b4681bdbc29  movaps [rdx], xmm1
00007b4681bdbc2c  movaps [rcx], xmm9
00007b4681bdbc30  mov rax, 0x5668589B5A50
00007b4681bdbc3a  call rax
00007b4681bdbc3c  movaps xmm7, [rsp]
00007b4681bdbc40  add rsp, 0x40
00007b4681bdbc44  vmovaps xmm0, [rsp]
00007b4681bdbc49  vmovaps xmm1, [rsp+0x10]
00007b4681bdbc4f  vmovaps xmm2, [rsp+0x20]
00007b4681bdbc55  vmovaps xmm3, [rsp+0x30]
00007b4681bdbc5b  vmovaps xmm4, [rsp+0x40]
00007b4681bdbc61  vmovaps xmm5, [rsp+0x50]
00007b4681bdbc67  vmovaps xmm6, [rsp+0x60]
00007b4681bdbc6d  vmovaps xmm8, [rsp+0x70]
00007b4681bdbc73  vmovaps xmm9, [rsp+0x80]
00007b4681bdbc7c  vmovaps xmm10, [rsp+0x90]
00007b4681bdbc85  vmovaps xmm11, [rsp+0xA0]
00007b4681bdbc8e  vmovaps xmm12, [rsp+0xB0]
00007b4681bdbc97  vmovaps xmm13, [rsp+0xC0]
00007b4681bdbca0  vmovaps xmm14, [rsp+0xD0]
00007b4681bdbca9  vmovaps xmm15, [rsp+0xE0]
00007b4681bdbcb2  add rsp, 0xF0
00007b4681bdbcb9  pop r11
00007b4681bdbcbb  pop r10
00007b4681bdbcbd  pop r9
00007b4681bdbcbf  pop r8
00007b4681bdbcc1  pop rsi
00007b4681bdbcc2  pop rdi
00007b4681bdbcc3  pop rdx
00007b4681bdbcc4  pop rcx
00007b4681bdbcc5  pop rax
00007b4681bdbcc6  add rsp, 0x08
00007b4681bdbcca  jmp 0x00007B4681BDA2E0
00007b4681bdbccf  call 0x00007B4681A0C260
00007b4681bdbcd4  jmp 0x00007B4681BDA303
00007b4681bdbcd9  call 0x00007B4681A07890
00007b4681bdbcde  jmp 0x00007B4681BDA30D
00007b4681bdbce3  sub rsp, 0x08
00007b4681bdbce7  push rax
00007b4681bdbce8  push rcx
00007b4681bdbce9  push rdx
00007b4681bdbcea  push rdi
00007b4681bdbceb  push rsi
00007b4681bdbcec  push r8
00007b4681bdbcee  push r9
00007b4681bdbcf0  push r10
00007b4681bdbcf2  push r11
00007b4681bdbcf4  sub rsp, 0xF0
00007b4681bdbcfb  vmovaps [rsp], xmm0
00007b4681bdbd00  vmovaps [rsp+0x10], xmm1
00007b4681bdbd06  vmovaps [rsp+0x20], xmm3
00007b4681bdbd0c  vmovaps [rsp+0x30], xmm4
00007b4681bdbd12  vmovaps [rsp+0x40], xmm5
00007b4681bdbd18  vmovaps [rsp+0x50], xmm6
00007b4681bdbd1e  vmovaps [rsp+0x60], xmm7
00007b4681bdbd24  vmovaps [rsp+0x70], xmm8
00007b4681bdbd2a  vmovaps [rsp+0x80], xmm9
00007b4681bdbd33  vmovaps [rsp+0x90], xmm10
00007b4681bdbd3c  vmovaps [rsp+0xA0], xmm11
00007b4681bdbd45  vmovaps [rsp+0xB0], xmm12
00007b4681bdbd4e  vmovaps [rsp+0xC0], xmm13
00007b4681bdbd57  vmovaps [rsp+0xD0], xmm14
00007b4681bdbd60  vmovaps [rsp+0xE0], xmm15
00007b4681bdbd69  sub rsp, 0x40
00007b4681bdbd6d  lea rdi, [rsp]
00007b4681bdbd71  lea rsi, [rsp+0x10]
00007b4681bdbd76  lea rdx, [rsp+0x20]
00007b4681bdbd7b  lea rcx, [rsp+0x30]
00007b4681bdbd80  mov r8d, 0x00
00007b4681bdbd86  lea r9, [r15+0x3A8]
00007b4681bdbd8d  movaps [rdi], xmm2
00007b4681bdbd90  movaps [rsi], xmm12
00007b4681bdbd94  movaps [rdx], xmm6
00007b4681bdbd97  movaps [rcx], xmm3
00007b4681bdbd9a  mov rax, 0x5668589B5A50
00007b4681bdbda4  call rax
00007b4681bdbda6  movaps xmm2, [rsp]
00007b4681bdbdaa  add rsp, 0x40
00007b4681bdbdae  vmovaps xmm0, [rsp]
00007b4681bdbdb3  vmovaps xmm1, [rsp+0x10]
00007b4681bdbdb9  vmovaps xmm3, [rsp+0x20]
00007b4681bdbdbf  vmovaps xmm4, [rsp+0x30]
00007b4681bdbdc5  vmovaps xmm5, [rsp+0x40]
00007b4681bdbdcb  vmovaps xmm6, [rsp+0x50]
00007b4681bdbdd1  vmovaps xmm7, [rsp+0x60]
00007b4681bdbdd7  vmovaps xmm8, [rsp+0x70]
00007b4681bdbddd  vmovaps xmm9, [rsp+0x80]
00007b4681bdbde6  vmovaps xmm10, [rsp+0x90]
00007b4681bdbdef  vmovaps xmm11, [rsp+0xA0]
00007b4681bdbdf8  vmovaps xmm12, [rsp+0xB0]
00007b4681bdbe01  vmovaps xmm13, [rsp+0xC0]
00007b4681bdbe0a  vmovaps xmm14, [rsp+0xD0]
00007b4681bdbe13  vmovaps xmm15, [rsp+0xE0]
00007b4681bdbe1c  add rsp, 0xF0
00007b4681bdbe23  pop r11
00007b4681bdbe25  pop r10
00007b4681bdbe27  pop r9
00007b4681bdbe29  pop r8
00007b4681bdbe2b  pop rsi
00007b4681bdbe2c  pop rdi
00007b4681bdbe2d  pop rdx
00007b4681bdbe2e  pop rcx
00007b4681bdbe2f  pop rax
00007b4681bdbe30  add rsp, 0x08
00007b4681bdbe34  jmp 0x00007B4681BDA353
00007b4681bdbe39  sub rsp, 0x08
00007b4681bdbe3d  push rax
00007b4681bdbe3e  push rcx
00007b4681bdbe3f  push rdx
00007b4681bdbe40  push rdi
00007b4681bdbe41  push rsi
00007b4681bdbe42  push r8
00007b4681bdbe44  push r9
00007b4681bdbe46  push r10
00007b4681bdbe48  push r11
00007b4681bdbe4a  sub rsp, 0xF0
00007b4681bdbe51  vmovaps [rsp], xmm0
00007b4681bdbe56  vmovaps [rsp+0x10], xmm1
00007b4681bdbe5c  vmovaps [rsp+0x20], xmm2
00007b4681bdbe62  vmovaps [rsp+0x30], xmm3
00007b4681bdbe68  vmovaps [rsp+0x40], xmm4
00007b4681bdbe6e  vmovaps [rsp+0x50], xmm5
00007b4681bdbe74  vmovaps [rsp+0x60], xmm7
00007b4681bdbe7a  vmovaps [rsp+0x70], xmm8
00007b4681bdbe80  vmovaps [rsp+0x80], xmm9
00007b4681bdbe89  vmovaps [rsp+0x90], xmm10
00007b4681bdbe92  vmovaps [rsp+0xA0], xmm11
00007b4681bdbe9b  vmovaps [rsp+0xB0], xmm12
00007b4681bdbea4  vmovaps [rsp+0xC0], xmm13
00007b4681bdbead  vmovaps [rsp+0xD0], xmm14
00007b4681bdbeb6  vmovaps [rsp+0xE0], xmm15
00007b4681bdbebf  sub rsp, 0x40
00007b4681bdbec3  lea rdi, [rsp]
00007b4681bdbec7  lea rsi, [rsp+0x10]
00007b4681bdbecc  lea rdx, [rsp+0x20]
00007b4681bdbed1  lea rcx, [rsp+0x30]
00007b4681bdbed6  mov r8d, 0x00
00007b4681bdbedc  lea r9, [r15+0x3A8]
00007b4681bdbee3  movaps [rdi], xmm6
00007b4681bdbee6  movaps [rsi], xmm10
00007b4681bdbeea  movaps [rdx], xmm12
00007b4681bdbeee  movaps [rcx], xmm1
00007b4681bdbef1  mov rax, 0x5668589B5A50
00007b4681bdbefb  call rax
00007b4681bdbefd  movaps xmm6, [rsp]
00007b4681bdbf01  add rsp, 0x40
00007b4681bdbf05  vmovaps xmm0, [rsp]
00007b4681bdbf0a  vmovaps xmm1, [rsp+0x10]
00007b4681bdbf10  vmovaps xmm2, [rsp+0x20]
00007b4681bdbf16  vmovaps xmm3, [rsp+0x30]
00007b4681bdbf1c  vmovaps xmm4, [rsp+0x40]
00007b4681bdbf22  vmovaps xmm5, [rsp+0x50]
00007b4681bdbf28  vmovaps xmm7, [rsp+0x60]
00007b4681bdbf2e  vmovaps xmm8, [rsp+0x70]
00007b4681bdbf34  vmovaps xmm9, [rsp+0x80]
00007b4681bdbf3d  vmovaps xmm10, [rsp+0x90]
00007b4681bdbf46  vmovaps xmm11, [rsp+0xA0]
00007b4681bdbf4f  vmovaps xmm12, [rsp+0xB0]
00007b4681bdbf58  vmovaps xmm13, [rsp+0xC0]
00007b4681bdbf61  vmovaps xmm14, [rsp+0xD0]
00007b4681bdbf6a  vmovaps xmm15, [rsp+0xE0]
00007b4681bdbf73  add rsp, 0xF0
00007b4681bdbf7a  pop r11
00007b4681bdbf7c  pop r10
00007b4681bdbf7e  pop r9
00007b4681bdbf80  pop r8
00007b4681bdbf82  pop rsi
00007b4681bdbf83  pop rdi
00007b4681bdbf84  pop rdx
00007b4681bdbf85  pop rcx
00007b4681bdbf86  pop rax
00007b4681bdbf87  add rsp, 0x08
00007b4681bdbf8b  jmp 0x00007B4681BDA381
00007b4681bdbf90  sub rsp, 0x08
00007b4681bdbf94  push rax
00007b4681bdbf95  push rcx
00007b4681bdbf96  push rdx
00007b4681bdbf97  push rdi
00007b4681bdbf98  push rsi
00007b4681bdbf99  push r8
00007b4681bdbf9b  push r9
00007b4681bdbf9d  push r10
00007b4681bdbf9f  push r11
00007b4681bdbfa1  sub rsp, 0xF0
00007b4681bdbfa8  vmovaps [rsp], xmm0
00007b4681bdbfad  vmovaps [rsp+0x10], xmm1
00007b4681bdbfb3  vmovaps [rsp+0x20], xmm2
00007b4681bdbfb9  vmovaps [rsp+0x30], xmm3
00007b4681bdbfbf  vmovaps [rsp+0x40], xmm4
00007b4681bdbfc5  vmovaps [rsp+0x50], xmm5
00007b4681bdbfcb  vmovaps [rsp+0x60], xmm6
00007b4681bdbfd1  vmovaps [rsp+0x70], xmm7
00007b4681bdbfd7  vmovaps [rsp+0x80], xmm8
00007b4681bdbfe0  vmovaps [rsp+0x90], xmm9
00007b4681bdbfe9  vmovaps [rsp+0xA0], xmm11
00007b4681bdbff2  vmovaps [rsp+0xB0], xmm12
00007b4681bdbffb  vmovaps [rsp+0xC0], xmm13
00007b4681bdc004  vmovaps [rsp+0xD0], xmm14
00007b4681bdc00d  vmovaps [rsp+0xE0], xmm15
00007b4681bdc016  sub rsp, 0x40
00007b4681bdc01a  lea rdi, [rsp]
00007b4681bdc01e  lea rsi, [rsp+0x10]
00007b4681bdc023  lea rdx, [rsp+0x20]
00007b4681bdc028  lea rcx, [rsp+0x30]
00007b4681bdc02d  mov r8d, 0x00
00007b4681bdc033  lea r9, [r15+0x3A8]
00007b4681bdc03a  movaps [rdi], xmm10
00007b4681bdc03e  movaps [rsi], xmm5
00007b4681bdc041  movaps [rdx], xmm12
00007b4681bdc045  movaps [rcx], xmm1
00007b4681bdc048  mov rax, 0x5668589B5A50
00007b4681bdc052  call rax
00007b4681bdc054  movaps xmm10, [rsp]
00007b4681bdc059  add rsp, 0x40
00007b4681bdc05d  vmovaps xmm0, [rsp]
00007b4681bdc062  vmovaps xmm1, [rsp+0x10]
00007b4681bdc068  vmovaps xmm2, [rsp+0x20]
00007b4681bdc06e  vmovaps xmm3, [rsp+0x30]
00007b4681bdc074  vmovaps xmm4, [rsp+0x40]
00007b4681bdc07a  vmovaps xmm5, [rsp+0x50]
00007b4681bdc080  vmovaps xmm6, [rsp+0x60]
00007b4681bdc086  vmovaps xmm7, [rsp+0x70]
00007b4681bdc08c  vmovaps xmm8, [rsp+0x80]
00007b4681bdc095  vmovaps xmm9, [rsp+0x90]
00007b4681bdc09e  vmovaps xmm11, [rsp+0xA0]
00007b4681bdc0a7  vmovaps xmm12, [rsp+0xB0]
00007b4681bdc0b0  vmovaps xmm13, [rsp+0xC0]
00007b4681bdc0b9  vmovaps xmm14, [rsp+0xD0]
00007b4681bdc0c2  vmovaps xmm15, [rsp+0xE0]
00007b4681bdc0cb  add rsp, 0xF0
00007b4681bdc0d2  pop r11
00007b4681bdc0d4  pop r10
00007b4681bdc0d6  pop r9
00007b4681bdc0d8  pop r8
00007b4681bdc0da  pop rsi
00007b4681bdc0db  pop rdi
00007b4681bdc0dc  pop rdx
00007b4681bdc0dd  pop rcx
00007b4681bdc0de  pop rax
00007b4681bdc0df  add rsp, 0x08
00007b4681bdc0e3  jmp 0x00007B4681BDA3B0
00007b4681bdc0e8  sub rsp, 0x08
00007b4681bdc0ec  push rax
00007b4681bdc0ed  push rcx
00007b4681bdc0ee  push rdx
00007b4681bdc0ef  push rdi
00007b4681bdc0f0  push rsi
00007b4681bdc0f1  push r8
00007b4681bdc0f3  push r9
00007b4681bdc0f5  push r10
00007b4681bdc0f7  push r11
00007b4681bdc0f9  sub rsp, 0xF0
00007b4681bdc100  vmovaps [rsp], xmm0
00007b4681bdc105  vmovaps [rsp+0x10], xmm1
00007b4681bdc10b  vmovaps [rsp+0x20], xmm2
00007b4681bdc111  vmovaps [rsp+0x30], xmm3
00007b4681bdc117  vmovaps [rsp+0x40], xmm4
00007b4681bdc11d  vmovaps [rsp+0x50], xmm5
00007b4681bdc123  vmovaps [rsp+0x60], xmm6
00007b4681bdc129  vmovaps [rsp+0x70], xmm7
00007b4681bdc12f  vmovaps [rsp+0x80], xmm8
00007b4681bdc138  vmovaps [rsp+0x90], xmm9
00007b4681bdc141  vmovaps [rsp+0xA0], xmm10
00007b4681bdc14a  vmovaps [rsp+0xB0], xmm11
00007b4681bdc153  vmovaps [rsp+0xC0], xmm13
00007b4681bdc15c  vmovaps [rsp+0xD0], xmm14
00007b4681bdc165  vmovaps [rsp+0xE0], xmm15
00007b4681bdc16e  sub rsp, 0x40
00007b4681bdc172  lea rdi, [rsp]
00007b4681bdc176  lea rsi, [rsp+0x10]
00007b4681bdc17b  lea rdx, [rsp+0x20]
00007b4681bdc180  lea rcx, [rsp+0x30]
00007b4681bdc185  mov r8d, 0x00
00007b4681bdc18b  lea r9, [r15+0x3A8]
00007b4681bdc192  movaps [rdi], xmm12
00007b4681bdc196  movaps [rsi], xmm7
00007b4681bdc199  movaps [rdx], xmm15
00007b4681bdc19d  movaps [rcx], xmm1
00007b4681bdc1a0  mov rax, 0x5668589B5A50
00007b4681bdc1aa  call rax
00007b4681bdc1ac  movaps xmm12, [rsp]
00007b4681bdc1b1  add rsp, 0x40
00007b4681bdc1b5  vmovaps xmm0, [rsp]
00007b4681bdc1ba  vmovaps xmm1, [rsp+0x10]
00007b4681bdc1c0  vmovaps xmm2, [rsp+0x20]
00007b4681bdc1c6  vmovaps xmm3, [rsp+0x30]
00007b4681bdc1cc  vmovaps xmm4, [rsp+0x40]
00007b4681bdc1d2  vmovaps xmm5, [rsp+0x50]
00007b4681bdc1d8  vmovaps xmm6, [rsp+0x60]
00007b4681bdc1de  vmovaps xmm7, [rsp+0x70]
00007b4681bdc1e4  vmovaps xmm8, [rsp+0x80]
00007b4681bdc1ed  vmovaps xmm9, [rsp+0x90]
00007b4681bdc1f6  vmovaps xmm10, [rsp+0xA0]
00007b4681bdc1ff  vmovaps xmm11, [rsp+0xB0]
00007b4681bdc208  vmovaps xmm13, [rsp+0xC0]
00007b4681bdc211  vmovaps xmm14, [rsp+0xD0]
00007b4681bdc21a  vmovaps xmm15, [rsp+0xE0]
00007b4681bdc223  add rsp, 0xF0
00007b4681bdc22a  pop r11
00007b4681bdc22c  pop r10
00007b4681bdc22e  pop r9
00007b4681bdc230  pop r8
00007b4681bdc232  pop rsi
00007b4681bdc233  pop rdi
00007b4681bdc234  pop rdx
00007b4681bdc235  pop rcx
00007b4681bdc236  pop rax
00007b4681bdc237  add rsp, 0x08
00007b4681bdc23b  jmp 0x00007B4681BDA3D9
00007b4681bdc240  call 0x00007B46819FF430
00007b4681bdc245  jmp 0x00007B4681BDA3E3
00007b4681bdc24a  call 0x00007B4681A0E760
00007b4681bdc24f  jmp 0x00007B4681BDA3ED
00007b4681bdc254  sub rsp, 0x08
00007b4681bdc258  push rax
00007b4681bdc259  push rcx
00007b4681bdc25a  push rdx
00007b4681bdc25b  push rdi
00007b4681bdc25c  push rsi
00007b4681bdc25d  push r8
00007b4681bdc25f  push r9
00007b4681bdc261  push r10
00007b4681bdc263  push r11
00007b4681bdc265  sub rsp, 0xF0
00007b4681bdc26c  vmovaps [rsp], xmm0
00007b4681bdc271  vmovaps [rsp+0x10], xmm1
00007b4681bdc277  vmovaps [rsp+0x20], xmm2
00007b4681bdc27d  vmovaps [rsp+0x30], xmm3
00007b4681bdc283  vmovaps [rsp+0x40], xmm4
00007b4681bdc289  vmovaps [rsp+0x50], xmm5
00007b4681bdc28f  vmovaps [rsp+0x60], xmm6
00007b4681bdc295  vmovaps [rsp+0x70], xmm8
00007b4681bdc29b  vmovaps [rsp+0x80], xmm9
00007b4681bdc2a4  vmovaps [rsp+0x90], xmm10
00007b4681bdc2ad  vmovaps [rsp+0xA0], xmm11
00007b4681bdc2b6  vmovaps [rsp+0xB0], xmm12
00007b4681bdc2bf  vmovaps [rsp+0xC0], xmm13
00007b4681bdc2c8  vmovaps [rsp+0xD0], xmm14
00007b4681bdc2d1  vmovaps [rsp+0xE0], xmm15
00007b4681bdc2da  sub rsp, 0x40
00007b4681bdc2de  lea rdi, [rsp]
00007b4681bdc2e2  lea rsi, [rsp+0x10]
00007b4681bdc2e7  lea rdx, [rsp+0x20]
00007b4681bdc2ec  lea rcx, [rsp+0x30]
00007b4681bdc2f1  mov r8d, 0x00
00007b4681bdc2f7  lea r9, [r15+0x3A8]
00007b4681bdc2fe  movaps [rdi], xmm7
00007b4681bdc301  movaps [rsi], xmm2
00007b4681bdc304  movaps [rdx], xmm9
00007b4681bdc308  movaps [rcx], xmm11
00007b4681bdc30c  mov rax, 0x5668589B5A50
00007b4681bdc316  call rax
00007b4681bdc318  movaps xmm7, [rsp]
00007b4681bdc31c  add rsp, 0x40
00007b4681bdc320  vmovaps xmm0, [rsp]
00007b4681bdc325  vmovaps xmm1, [rsp+0x10]
00007b4681bdc32b  vmovaps xmm2, [rsp+0x20]
00007b4681bdc331  vmovaps xmm3, [rsp+0x30]
00007b4681bdc337  vmovaps xmm4, [rsp+0x40]
00007b4681bdc33d  vmovaps xmm5, [rsp+0x50]
00007b4681bdc343  vmovaps xmm6, [rsp+0x60]
00007b4681bdc349  vmovaps xmm8, [rsp+0x70]
00007b4681bdc34f  vmovaps xmm9, [rsp+0x80]
00007b4681bdc358  vmovaps xmm10, [rsp+0x90]
00007b4681bdc361  vmovaps xmm11, [rsp+0xA0]
00007b4681bdc36a  vmovaps xmm12, [rsp+0xB0]
00007b4681bdc373  vmovaps xmm13, [rsp+0xC0]
00007b4681bdc37c  vmovaps xmm14, [rsp+0xD0]
00007b4681bdc385  vmovaps xmm15, [rsp+0xE0]
00007b4681bdc38e  add rsp, 0xF0
00007b4681bdc395  pop r11
00007b4681bdc397  pop r10
00007b4681bdc399  pop r9
00007b4681bdc39b  pop r8
00007b4681bdc39d  pop rsi
00007b4681bdc39e  pop rdi
00007b4681bdc39f  pop rdx
00007b4681bdc3a0  pop rcx
00007b4681bdc3a1  pop rax
00007b4681bdc3a2  add rsp, 0x08
00007b4681bdc3a6  jmp 0x00007B4681BDA421
00007b4681bdc3ab  sub rsp, 0x08
00007b4681bdc3af  push rax
00007b4681bdc3b0  push rcx
00007b4681bdc3b1  push rdx
00007b4681bdc3b2  push rdi
00007b4681bdc3b3  push rsi
00007b4681bdc3b4  push r8
00007b4681bdc3b6  push r9
00007b4681bdc3b8  push r10
00007b4681bdc3ba  push r11
00007b4681bdc3bc  sub rsp, 0xF0
00007b4681bdc3c3  vmovaps [rsp], xmm0
00007b4681bdc3c8  vmovaps [rsp+0x10], xmm1
00007b4681bdc3ce  vmovaps [rsp+0x20], xmm2
00007b4681bdc3d4  vmovaps [rsp+0x30], xmm3
00007b4681bdc3da  vmovaps [rsp+0x40], xmm4
00007b4681bdc3e0  vmovaps [rsp+0x50], xmm5
00007b4681bdc3e6  vmovaps [rsp+0x60], xmm6
00007b4681bdc3ec  vmovaps [rsp+0x70], xmm7
00007b4681bdc3f2  vmovaps [rsp+0x80], xmm8
00007b4681bdc3fb  vmovaps [rsp+0x90], xmm10
00007b4681bdc404  vmovaps [rsp+0xA0], xmm11
00007b4681bdc40d  vmovaps [rsp+0xB0], xmm12
00007b4681bdc416  vmovaps [rsp+0xC0], xmm13
00007b4681bdc41f  vmovaps [rsp+0xD0], xmm14
00007b4681bdc428  vmovaps [rsp+0xE0], xmm15
00007b4681bdc431  sub rsp, 0x40
00007b4681bdc435  lea rdi, [rsp]
00007b4681bdc439  lea rsi, [rsp+0x10]
00007b4681bdc43e  lea rdx, [rsp+0x20]
00007b4681bdc443  lea rcx, [rsp+0x30]
00007b4681bdc448  mov r8d, 0x00
00007b4681bdc44e  lea r9, [r15+0x3A8]
00007b4681bdc455  movaps [rdi], xmm9
00007b4681bdc459  movaps [rsi], xmm6
00007b4681bdc45c  movaps [rdx], xmm1
00007b4681bdc45f  movaps [rcx], xmm11
00007b4681bdc463  mov rax, 0x5668589B5A50
00007b4681bdc46d  call rax
00007b4681bdc46f  movaps xmm9, [rsp]
00007b4681bdc474  add rsp, 0x40
00007b4681bdc478  vmovaps xmm0, [rsp]
00007b4681bdc47d  vmovaps xmm1, [rsp+0x10]
00007b4681bdc483  vmovaps xmm2, [rsp+0x20]
00007b4681bdc489  vmovaps xmm3, [rsp+0x30]
00007b4681bdc48f  vmovaps xmm4, [rsp+0x40]
00007b4681bdc495  vmovaps xmm5, [rsp+0x50]
00007b4681bdc49b  vmovaps xmm6, [rsp+0x60]
00007b4681bdc4a1  vmovaps xmm7, [rsp+0x70]
00007b4681bdc4a7  vmovaps xmm8, [rsp+0x80]
00007b4681bdc4b0  vmovaps xmm10, [rsp+0x90]
00007b4681bdc4b9  vmovaps xmm11, [rsp+0xA0]
00007b4681bdc4c2  vmovaps xmm12, [rsp+0xB0]
00007b4681bdc4cb  vmovaps xmm13, [rsp+0xC0]
00007b4681bdc4d4  vmovaps xmm14, [rsp+0xD0]
00007b4681bdc4dd  vmovaps xmm15, [rsp+0xE0]
00007b4681bdc4e6  add rsp, 0xF0
00007b4681bdc4ed  pop r11
00007b4681bdc4ef  pop r10
00007b4681bdc4f1  pop r9
00007b4681bdc4f3  pop r8
00007b4681bdc4f5  pop rsi
00007b4681bdc4f6  pop rdi
00007b4681bdc4f7  pop rdx
00007b4681bdc4f8  pop rcx
00007b4681bdc4f9  pop rax
00007b4681bdc4fa  add rsp, 0x08
00007b4681bdc4fe  jmp 0x00007B4681BDA447
00007b4681bdc503  sub rsp, 0x08
00007b4681bdc507  push rax
00007b4681bdc508  push rcx
00007b4681bdc509  push rdx
00007b4681bdc50a  push rdi
00007b4681bdc50b  push rsi
00007b4681bdc50c  push r8
00007b4681bdc50e  push r9
00007b4681bdc510  push r10
00007b4681bdc512  push r11
00007b4681bdc514  sub rsp, 0xF0
00007b4681bdc51b  vmovaps [rsp], xmm0
00007b4681bdc520  vmovaps [rsp+0x10], xmm1
00007b4681bdc526  vmovaps [rsp+0x20], xmm2
00007b4681bdc52c  vmovaps [rsp+0x30], xmm3
00007b4681bdc532  vmovaps [rsp+0x40], xmm4
00007b4681bdc538  vmovaps [rsp+0x50], xmm5
00007b4681bdc53e  vmovaps [rsp+0x60], xmm6
00007b4681bdc544  vmovaps [rsp+0x70], xmm7
00007b4681bdc54a  vmovaps [rsp+0x80], xmm8
00007b4681bdc553  vmovaps [rsp+0x90], xmm9
00007b4681bdc55c  vmovaps [rsp+0xA0], xmm10
00007b4681bdc565  vmovaps [rsp+0xB0], xmm12
00007b4681bdc56e  vmovaps [rsp+0xC0], xmm13
00007b4681bdc577  vmovaps [rsp+0xD0], xmm14
00007b4681bdc580  vmovaps [rsp+0xE0], xmm15
00007b4681bdc589  sub rsp, 0x40
00007b4681bdc58d  lea rdi, [rsp]
00007b4681bdc591  lea rsi, [rsp+0x10]
00007b4681bdc596  lea rdx, [rsp+0x20]
00007b4681bdc59b  lea rcx, [rsp+0x30]
00007b4681bdc5a0  mov r8d, 0x00
00007b4681bdc5a6  lea r9, [r15+0x3A8]
00007b4681bdc5ad  movaps [rdi], xmm11
00007b4681bdc5b1  movaps [rsi], xmm10
00007b4681bdc5b5  movaps [rdx], xmm8
00007b4681bdc5b9  movaps [rcx], xmm1
00007b4681bdc5bc  mov rax, 0x5668589B5A50
00007b4681bdc5c6  call rax
00007b4681bdc5c8  movaps xmm11, [rsp]
00007b4681bdc5cd  add rsp, 0x40
00007b4681bdc5d1  vmovaps xmm0, [rsp]
00007b4681bdc5d6  vmovaps xmm1, [rsp+0x10]
00007b4681bdc5dc  vmovaps xmm2, [rsp+0x20]
00007b4681bdc5e2  vmovaps xmm3, [rsp+0x30]
00007b4681bdc5e8  vmovaps xmm4, [rsp+0x40]
00007b4681bdc5ee  vmovaps xmm5, [rsp+0x50]
00007b4681bdc5f4  vmovaps xmm6, [rsp+0x60]
00007b4681bdc5fa  vmovaps xmm7, [rsp+0x70]
00007b4681bdc600  vmovaps xmm8, [rsp+0x80]
00007b4681bdc609  vmovaps xmm9, [rsp+0x90]
00007b4681bdc612  vmovaps xmm10, [rsp+0xA0]
00007b4681bdc61b  vmovaps xmm12, [rsp+0xB0]
00007b4681bdc624  vmovaps xmm13, [rsp+0xC0]
00007b4681bdc62d  vmovaps xmm14, [rsp+0xD0]
00007b4681bdc636  vmovaps xmm15, [rsp+0xE0]
00007b4681bdc63f  add rsp, 0xF0
00007b4681bdc646  pop r11
00007b4681bdc648  pop r10
00007b4681bdc64a  pop r9
00007b4681bdc64c  pop r8
00007b4681bdc64e  pop rsi
00007b4681bdc64f  pop rdi
00007b4681bdc650  pop rdx
00007b4681bdc651  pop rcx
00007b4681bdc652  pop rax
00007b4681bdc653  add rsp, 0x08
00007b4681bdc657  jmp 0x00007B4681BDA46D
00007b4681bdc65c  sub rsp, 0x08
00007b4681bdc660  push rax
00007b4681bdc661  push rcx
00007b4681bdc662  push rdx
00007b4681bdc663  push rdi
00007b4681bdc664  push rsi
00007b4681bdc665  push r8
00007b4681bdc667  push r9
00007b4681bdc669  push r10
00007b4681bdc66b  push r11
00007b4681bdc66d  sub rsp, 0xF0
00007b4681bdc674  vmovaps [rsp], xmm0
00007b4681bdc679  vmovaps [rsp+0x10], xmm1
00007b4681bdc67f  vmovaps [rsp+0x20], xmm2
00007b4681bdc685  vmovaps [rsp+0x30], xmm3
00007b4681bdc68b  vmovaps [rsp+0x40], xmm4
00007b4681bdc691  vmovaps [rsp+0x50], xmm5
00007b4681bdc697  vmovaps [rsp+0x60], xmm6
00007b4681bdc69d  vmovaps [rsp+0x70], xmm7
00007b4681bdc6a3  vmovaps [rsp+0x80], xmm8
00007b4681bdc6ac  vmovaps [rsp+0x90], xmm9
00007b4681bdc6b5  vmovaps [rsp+0xA0], xmm11
00007b4681bdc6be  vmovaps [rsp+0xB0], xmm12
00007b4681bdc6c7  vmovaps [rsp+0xC0], xmm13
00007b4681bdc6d0  vmovaps [rsp+0xD0], xmm14
00007b4681bdc6d9  vmovaps [rsp+0xE0], xmm15
00007b4681bdc6e2  sub rsp, 0x40
00007b4681bdc6e6  lea rdi, [rsp]
00007b4681bdc6ea  lea rsi, [rsp+0x10]
00007b4681bdc6ef  lea rdx, [rsp+0x20]
00007b4681bdc6f4  lea rcx, [rsp+0x30]
00007b4681bdc6f9  mov r8d, 0x00
00007b4681bdc6ff  lea r9, [r15+0x3A8]
00007b4681bdc706  movaps [rdi], xmm10
00007b4681bdc70a  movaps [rsi], xmm12
00007b4681bdc70e  movaps [rdx], xmm13
00007b4681bdc712  movaps [rcx], xmm1
00007b4681bdc715  mov rax, 0x5668589B5A50
00007b4681bdc71f  call rax
00007b4681bdc721  movaps xmm10, [rsp]
00007b4681bdc726  add rsp, 0x40
00007b4681bdc72a  vmovaps xmm0, [rsp]
00007b4681bdc72f  vmovaps xmm1, [rsp+0x10]
00007b4681bdc735  vmovaps xmm2, [rsp+0x20]
00007b4681bdc73b  vmovaps xmm3, [rsp+0x30]
00007b4681bdc741  vmovaps xmm4, [rsp+0x40]
00007b4681bdc747  vmovaps xmm5, [rsp+0x50]
00007b4681bdc74d  vmovaps xmm6, [rsp+0x60]
00007b4681bdc753  vmovaps xmm7, [rsp+0x70]
00007b4681bdc759  vmovaps xmm8, [rsp+0x80]
00007b4681bdc762  vmovaps xmm9, [rsp+0x90]
00007b4681bdc76b  vmovaps xmm11, [rsp+0xA0]
00007b4681bdc774  vmovaps xmm12, [rsp+0xB0]
00007b4681bdc77d  vmovaps xmm13, [rsp+0xC0]
00007b4681bdc786  vmovaps xmm14, [rsp+0xD0]
00007b4681bdc78f  vmovaps xmm15, [rsp+0xE0]
00007b4681bdc798  add rsp, 0xF0
00007b4681bdc79f  pop r11
00007b4681bdc7a1  pop r10
00007b4681bdc7a3  pop r9
00007b4681bdc7a5  pop r8
00007b4681bdc7a7  pop rsi
00007b4681bdc7a8  pop rdi
00007b4681bdc7a9  pop rdx
00007b4681bdc7aa  pop rcx
00007b4681bdc7ab  pop rax
00007b4681bdc7ac  add rsp, 0x08
00007b4681bdc7b0  jmp 0x00007B4681BDA493
00007b4681bdc7b5  call 0x00007B46819FF430
00007b4681bdc7ba  jmp 0x00007B4681BDA49D
00007b4681bdc7bf  call 0x00007B4681A0C260
00007b4681bdc7c4  jmp 0x00007B4681BDA4A7
00007b4681bdc7c9  sub rsp, 0x08
00007b4681bdc7cd  push rax
00007b4681bdc7ce  push rcx
00007b4681bdc7cf  push rdx
00007b4681bdc7d0  push rdi
00007b4681bdc7d1  push rsi
00007b4681bdc7d2  push r8
00007b4681bdc7d4  push r9
00007b4681bdc7d6  push r10
00007b4681bdc7d8  push r11
00007b4681bdc7da  sub rsp, 0xF0
00007b4681bdc7e1  vmovaps [rsp], xmm0
00007b4681bdc7e6  vmovaps [rsp+0x10], xmm1
00007b4681bdc7ec  vmovaps [rsp+0x20], xmm2
00007b4681bdc7f2  vmovaps [rsp+0x30], xmm3
00007b4681bdc7f8  vmovaps [rsp+0x40], xmm4
00007b4681bdc7fe  vmovaps [rsp+0x50], xmm5
00007b4681bdc804  vmovaps [rsp+0x60], xmm6
00007b4681bdc80a  vmovaps [rsp+0x70], xmm7
00007b4681bdc810  vmovaps [rsp+0x80], xmm9
00007b4681bdc819  vmovaps [rsp+0x90], xmm10
00007b4681bdc822  vmovaps [rsp+0xA0], xmm11
00007b4681bdc82b  vmovaps [rsp+0xB0], xmm12
00007b4681bdc834  vmovaps [rsp+0xC0], xmm13
00007b4681bdc83d  vmovaps [rsp+0xD0], xmm14
00007b4681bdc846  vmovaps [rsp+0xE0], xmm15
00007b4681bdc84f  sub rsp, 0x40
00007b4681bdc853  lea rdi, [rsp]
00007b4681bdc857  lea rsi, [rsp+0x10]
00007b4681bdc85c  lea rdx, [rsp+0x20]
00007b4681bdc861  lea rcx, [rsp+0x30]
00007b4681bdc866  mov r8d, 0x00
00007b4681bdc86c  lea r9, [r15+0x3A8]
00007b4681bdc873  movaps [rdi], xmm8
00007b4681bdc877  movaps [rsi], xmm7
00007b4681bdc87a  movaps [rdx], xmm4
00007b4681bdc87d  movaps [rcx], xmm12
00007b4681bdc881  mov rax, 0x5668589B5A50
00007b4681bdc88b  call rax
00007b4681bdc88d  movaps xmm8, [rsp]
00007b4681bdc892  add rsp, 0x40
00007b4681bdc896  vmovaps xmm0, [rsp]
00007b4681bdc89b  vmovaps xmm1, [rsp+0x10]
00007b4681bdc8a1  vmovaps xmm2, [rsp+0x20]
00007b4681bdc8a7  vmovaps xmm3, [rsp+0x30]
00007b4681bdc8ad  vmovaps xmm4, [rsp+0x40]
00007b4681bdc8b3  vmovaps xmm5, [rsp+0x50]
00007b4681bdc8b9  vmovaps xmm6, [rsp+0x60]
00007b4681bdc8bf  vmovaps xmm7, [rsp+0x70]
00007b4681bdc8c5  vmovaps xmm9, [rsp+0x80]
00007b4681bdc8ce  vmovaps xmm10, [rsp+0x90]
00007b4681bdc8d7  vmovaps xmm11, [rsp+0xA0]
00007b4681bdc8e0  vmovaps xmm12, [rsp+0xB0]
00007b4681bdc8e9  vmovaps xmm13, [rsp+0xC0]
00007b4681bdc8f2  vmovaps xmm14, [rsp+0xD0]
00007b4681bdc8fb  vmovaps xmm15, [rsp+0xE0]
00007b4681bdc904  add rsp, 0xF0
00007b4681bdc90b  pop r11
00007b4681bdc90d  pop r10
00007b4681bdc90f  pop r9
00007b4681bdc911  pop r8
00007b4681bdc913  pop rsi
00007b4681bdc914  pop rdi
00007b4681bdc915  pop rdx
00007b4681bdc916  pop rcx
00007b4681bdc917  pop rax
00007b4681bdc918  add rsp, 0x08
00007b4681bdc91c  jmp 0x00007B4681BDA4D0
00007b4681bdc921  sub rsp, 0x08
00007b4681bdc925  push rax
00007b4681bdc926  push rcx
00007b4681bdc927  push rdx
00007b4681bdc928  push rdi
00007b4681bdc929  push rsi
00007b4681bdc92a  push r8
00007b4681bdc92c  push r9
00007b4681bdc92e  push r10
00007b4681bdc930  push r11
00007b4681bdc932  sub rsp, 0xF0
00007b4681bdc939  vmovaps [rsp], xmm0
00007b4681bdc93e  vmovaps [rsp+0x10], xmm1
00007b4681bdc944  vmovaps [rsp+0x20], xmm2
00007b4681bdc94a  vmovaps [rsp+0x30], xmm3
00007b4681bdc950  vmovaps [rsp+0x40], xmm4
00007b4681bdc956  vmovaps [rsp+0x50], xmm5
00007b4681bdc95c  vmovaps [rsp+0x60], xmm6
00007b4681bdc962  vmovaps [rsp+0x70], xmm8
00007b4681bdc968  vmovaps [rsp+0x80], xmm9
00007b4681bdc971  vmovaps [rsp+0x90], xmm10
00007b4681bdc97a  vmovaps [rsp+0xA0], xmm11
00007b4681bdc983  vmovaps [rsp+0xB0], xmm12
00007b4681bdc98c  vmovaps [rsp+0xC0], xmm13
00007b4681bdc995  vmovaps [rsp+0xD0], xmm14
00007b4681bdc99e  vmovaps [rsp+0xE0], xmm15
00007b4681bdc9a7  sub rsp, 0x40
00007b4681bdc9ab  lea rdi, [rsp]
00007b4681bdc9af  lea rsi, [rsp+0x10]
00007b4681bdc9b4  lea rdx, [rsp+0x20]
00007b4681bdc9b9  lea rcx, [rsp+0x30]
00007b4681bdc9be  mov r8d, 0x00
00007b4681bdc9c4  lea r9, [r15+0x3A8]
00007b4681bdc9cb  movaps [rdi], xmm7
00007b4681bdc9ce  movaps [rsi], xmm9
00007b4681bdc9d2  movaps [rdx], xmm14
00007b4681bdc9d6  movaps [rcx], xmm12
00007b4681bdc9da  mov rax, 0x5668589B5A50
00007b4681bdc9e4  call rax
00007b4681bdc9e6  movaps xmm7, [rsp]
00007b4681bdc9ea  add rsp, 0x40
00007b4681bdc9ee  vmovaps xmm0, [rsp]
00007b4681bdc9f3  vmovaps xmm1, [rsp+0x10]
00007b4681bdc9f9  vmovaps xmm2, [rsp+0x20]
00007b4681bdc9ff  vmovaps xmm3, [rsp+0x30]
00007b4681bdca05  vmovaps xmm4, [rsp+0x40]
00007b4681bdca0b  vmovaps xmm5, [rsp+0x50]
00007b4681bdca11  vmovaps xmm6, [rsp+0x60]
00007b4681bdca17  vmovaps xmm8, [rsp+0x70]
00007b4681bdca1d  vmovaps xmm9, [rsp+0x80]
00007b4681bdca26  vmovaps xmm10, [rsp+0x90]
00007b4681bdca2f  vmovaps xmm11, [rsp+0xA0]
00007b4681bdca38  vmovaps xmm12, [rsp+0xB0]
00007b4681bdca41  vmovaps xmm13, [rsp+0xC0]
00007b4681bdca4a  vmovaps xmm14, [rsp+0xD0]
00007b4681bdca53  vmovaps xmm15, [rsp+0xE0]
00007b4681bdca5c  add rsp, 0xF0
00007b4681bdca63  pop r11
00007b4681bdca65  pop r10
00007b4681bdca67  pop r9
00007b4681bdca69  pop r8
00007b4681bdca6b  pop rsi
00007b4681bdca6c  pop rdi
00007b4681bdca6d  pop rdx
00007b4681bdca6e  pop rcx
00007b4681bdca6f  pop rax
00007b4681bdca70  add rsp, 0x08
00007b4681bdca74  jmp 0x00007B4681BDA4F8
00007b4681bdca79  sub rsp, 0x08
00007b4681bdca7d  push rax
00007b4681bdca7e  push rcx
00007b4681bdca7f  push rdx
00007b4681bdca80  push rdi
00007b4681bdca81  push rsi
00007b4681bdca82  push r8
00007b4681bdca84  push r9
00007b4681bdca86  push r10
00007b4681bdca88  push r11
00007b4681bdca8a  sub rsp, 0xF0
00007b4681bdca91  vmovaps [rsp], xmm0
00007b4681bdca96  vmovaps [rsp+0x10], xmm1
00007b4681bdca9c  vmovaps [rsp+0x20], xmm2
00007b4681bdcaa2  vmovaps [rsp+0x30], xmm3
00007b4681bdcaa8  vmovaps [rsp+0x40], xmm4
00007b4681bdcaae  vmovaps [rsp+0x50], xmm5
00007b4681bdcab4  vmovaps [rsp+0x60], xmm6
00007b4681bdcaba  vmovaps [rsp+0x70], xmm7
00007b4681bdcac0  vmovaps [rsp+0x80], xmm8
00007b4681bdcac9  vmovaps [rsp+0x90], xmm9
00007b4681bdcad2  vmovaps [rsp+0xA0], xmm10
00007b4681bdcadb  vmovaps [rsp+0xB0], xmm11
00007b4681bdcae4  vmovaps [rsp+0xC0], xmm13
00007b4681bdcaed  vmovaps [rsp+0xD0], xmm14
00007b4681bdcaf6  vmovaps [rsp+0xE0], xmm15
00007b4681bdcaff  sub rsp, 0x40
00007b4681bdcb03  lea rdi, [rsp]
00007b4681bdcb07  lea rsi, [rsp+0x10]
00007b4681bdcb0c  lea rdx, [rsp+0x20]
00007b4681bdcb11  lea rcx, [rsp+0x30]
00007b4681bdcb16  mov r8d, 0x00
00007b4681bdcb1c  lea r9, [r15+0x3A8]
00007b4681bdcb23  movaps [rdi], xmm12
00007b4681bdcb27  movaps [rsi], xmm11
00007b4681bdcb2b  movaps [rdx], xmm15
00007b4681bdcb2f  movaps [rcx], xmm14
00007b4681bdcb33  mov rax, 0x5668589B5A50
00007b4681bdcb3d  call rax
00007b4681bdcb3f  movaps xmm12, [rsp]
00007b4681bdcb44  add rsp, 0x40
00007b4681bdcb48  vmovaps xmm0, [rsp]
00007b4681bdcb4d  vmovaps xmm1, [rsp+0x10]
00007b4681bdcb53  vmovaps xmm2, [rsp+0x20]
00007b4681bdcb59  vmovaps xmm3, [rsp+0x30]
00007b4681bdcb5f  vmovaps xmm4, [rsp+0x40]
00007b4681bdcb65  vmovaps xmm5, [rsp+0x50]
00007b4681bdcb6b  vmovaps xmm6, [rsp+0x60]
00007b4681bdcb71  vmovaps xmm7, [rsp+0x70]
00007b4681bdcb77  vmovaps xmm8, [rsp+0x80]
00007b4681bdcb80  vmovaps xmm9, [rsp+0x90]
00007b4681bdcb89  vmovaps xmm10, [rsp+0xA0]
00007b4681bdcb92  vmovaps xmm11, [rsp+0xB0]
00007b4681bdcb9b  vmovaps xmm13, [rsp+0xC0]
00007b4681bdcba4  vmovaps xmm14, [rsp+0xD0]
00007b4681bdcbad  vmovaps xmm15, [rsp+0xE0]
00007b4681bdcbb6  add rsp, 0xF0
00007b4681bdcbbd  pop r11
00007b4681bdcbbf  pop r10
00007b4681bdcbc1  pop r9
00007b4681bdcbc3  pop r8
00007b4681bdcbc5  pop rsi
00007b4681bdcbc6  pop rdi
00007b4681bdcbc7  pop rdx
00007b4681bdcbc8  pop rcx
00007b4681bdcbc9  pop rax
00007b4681bdcbca  add rsp, 0x08
00007b4681bdcbce  jmp 0x00007B4681BDA521
00007b4681bdcbd3  sub rsp, 0x08
00007b4681bdcbd7  push rax
00007b4681bdcbd8  push rcx
00007b4681bdcbd9  push rdx
00007b4681bdcbda  push rdi
00007b4681bdcbdb  push rsi
00007b4681bdcbdc  push r8
00007b4681bdcbde  push r9
00007b4681bdcbe0  push r10
00007b4681bdcbe2  push r11
00007b4681bdcbe4  sub rsp, 0xF0
00007b4681bdcbeb  vmovaps [rsp], xmm0
00007b4681bdcbf0  vmovaps [rsp+0x10], xmm1
00007b4681bdcbf6  vmovaps [rsp+0x20], xmm2
00007b4681bdcbfc  vmovaps [rsp+0x30], xmm3
00007b4681bdcc02  vmovaps [rsp+0x40], xmm4
00007b4681bdcc08  vmovaps [rsp+0x50], xmm5
00007b4681bdcc0e  vmovaps [rsp+0x60], xmm6
00007b4681bdcc14  vmovaps [rsp+0x70], xmm7
00007b4681bdcc1a  vmovaps [rsp+0x80], xmm8
00007b4681bdcc23  vmovaps [rsp+0x90], xmm9
00007b4681bdcc2c  vmovaps [rsp+0xA0], xmm10
00007b4681bdcc35  vmovaps [rsp+0xB0], xmm12
00007b4681bdcc3e  vmovaps [rsp+0xC0], xmm13
00007b4681bdcc47  vmovaps [rsp+0xD0], xmm14
00007b4681bdcc50  vmovaps [rsp+0xE0], xmm15
00007b4681bdcc59  sub rsp, 0x40
00007b4681bdcc5d  lea rdi, [rsp]
00007b4681bdcc61  lea rsi, [rsp+0x10]
00007b4681bdcc66  lea rdx, [rsp+0x20]
00007b4681bdcc6b  lea rcx, [rsp+0x30]
00007b4681bdcc70  mov r8d, 0x00
00007b4681bdcc76  lea r9, [r15+0x3A8]
00007b4681bdcc7d  movaps [rdi], xmm11
00007b4681bdcc81  movaps [rsi], xmm10
00007b4681bdcc85  movaps [rdx], xmm13
00007b4681bdcc89  movaps [rcx], xmm15
00007b4681bdcc8d  mov rax, 0x5668589B5A50
00007b4681bdcc97  call rax
00007b4681bdcc99  movaps xmm11, [rsp]
00007b4681bdcc9e  add rsp, 0x40
00007b4681bdcca2  vmovaps xmm0, [rsp]
00007b4681bdcca7  vmovaps xmm1, [rsp+0x10]
00007b4681bdccad  vmovaps xmm2, [rsp+0x20]
00007b4681bdccb3  vmovaps xmm3, [rsp+0x30]
00007b4681bdccb9  vmovaps xmm4, [rsp+0x40]
00007b4681bdccbf  vmovaps xmm5, [rsp+0x50]
00007b4681bdccc5  vmovaps xmm6, [rsp+0x60]
00007b4681bdcccb  vmovaps xmm7, [rsp+0x70]
00007b4681bdccd1  vmovaps xmm8, [rsp+0x80]
00007b4681bdccda  vmovaps xmm9, [rsp+0x90]
00007b4681bdcce3  vmovaps xmm10, [rsp+0xA0]
00007b4681bdccec  vmovaps xmm12, [rsp+0xB0]
00007b4681bdccf5  vmovaps xmm13, [rsp+0xC0]
00007b4681bdccfe  vmovaps xmm14, [rsp+0xD0]
00007b4681bdcd07  vmovaps xmm15, [rsp+0xE0]
00007b4681bdcd10  add rsp, 0xF0
00007b4681bdcd17  pop r11
00007b4681bdcd19  pop r10
00007b4681bdcd1b  pop r9
00007b4681bdcd1d  pop r8
00007b4681bdcd1f  pop rsi
00007b4681bdcd20  pop rdi
00007b4681bdcd21  pop rdx
00007b4681bdcd22  pop rcx
00007b4681bdcd23  pop rax
00007b4681bdcd24  add rsp, 0x08
00007b4681bdcd28  jmp 0x00007B4681BDA54A
00007b4681bdcd2d  call 0x00007B4681A0E760
00007b4681bdcd32  jmp 0x00007B4681BDA557
00007b4681bdcd37  call 0x00007B4681A0D4E0
00007b4681bdcd3c  jmp 0x00007B4681BDA564
00007b4681bdcd41  sub rsp, 0x08
00007b4681bdcd45  push rax
00007b4681bdcd46  push rcx
00007b4681bdcd47  push rdx
00007b4681bdcd48  push rdi
00007b4681bdcd49  push rsi
00007b4681bdcd4a  push r8
00007b4681bdcd4c  push r9
00007b4681bdcd4e  push r10
00007b4681bdcd50  push r11
00007b4681bdcd52  sub rsp, 0xF0
00007b4681bdcd59  vmovaps [rsp], xmm0
00007b4681bdcd5e  vmovaps [rsp+0x10], xmm1
00007b4681bdcd64  vmovaps [rsp+0x20], xmm2
00007b4681bdcd6a  vmovaps [rsp+0x30], xmm3
00007b4681bdcd70  vmovaps [rsp+0x40], xmm4
00007b4681bdcd76  vmovaps [rsp+0x50], xmm5
00007b4681bdcd7c  vmovaps [rsp+0x60], xmm6
00007b4681bdcd82  vmovaps [rsp+0x70], xmm7
00007b4681bdcd88  vmovaps [rsp+0x80], xmm8
00007b4681bdcd91  vmovaps [rsp+0x90], xmm9
00007b4681bdcd9a  vmovaps [rsp+0xA0], xmm11
00007b4681bdcda3  vmovaps [rsp+0xB0], xmm12
00007b4681bdcdac  vmovaps [rsp+0xC0], xmm13
00007b4681bdcdb5  vmovaps [rsp+0xD0], xmm14
00007b4681bdcdbe  vmovaps [rsp+0xE0], xmm15
00007b4681bdcdc7  sub rsp, 0x40
00007b4681bdcdcb  lea rdi, [rsp]
00007b4681bdcdcf  lea rsi, [rsp+0x10]
00007b4681bdcdd4  lea rdx, [rsp+0x20]
00007b4681bdcdd9  lea rcx, [rsp+0x30]
00007b4681bdcdde  mov r8d, 0x00
00007b4681bdcde4  lea r9, [r15+0x3A8]
00007b4681bdcdeb  movaps [rdi], xmm10
00007b4681bdcdef  movaps [rsi], xmm8
00007b4681bdcdf3  movaps [rdx], xmm1
00007b4681bdcdf6  movaps [rcx], xmm13
00007b4681bdcdfa  mov rax, 0x5668589B5A50
00007b4681bdce04  call rax
00007b4681bdce06  movaps xmm10, [rsp]
00007b4681bdce0b  add rsp, 0x40
00007b4681bdce0f  vmovaps xmm0, [rsp]
00007b4681bdce14  vmovaps xmm1, [rsp+0x10]
00007b4681bdce1a  vmovaps xmm2, [rsp+0x20]
00007b4681bdce20  vmovaps xmm3, [rsp+0x30]
00007b4681bdce26  vmovaps xmm4, [rsp+0x40]
00007b4681bdce2c  vmovaps xmm5, [rsp+0x50]
00007b4681bdce32  vmovaps xmm6, [rsp+0x60]
00007b4681bdce38  vmovaps xmm7, [rsp+0x70]
00007b4681bdce3e  vmovaps xmm8, [rsp+0x80]
00007b4681bdce47  vmovaps xmm9, [rsp+0x90]
00007b4681bdce50  vmovaps xmm11, [rsp+0xA0]
00007b4681bdce59  vmovaps xmm12, [rsp+0xB0]
00007b4681bdce62  vmovaps xmm13, [rsp+0xC0]
00007b4681bdce6b  vmovaps xmm14, [rsp+0xD0]
00007b4681bdce74  vmovaps xmm15, [rsp+0xE0]
00007b4681bdce7d  add rsp, 0xF0
00007b4681bdce84  pop r11
00007b4681bdce86  pop r10
00007b4681bdce88  pop r9
00007b4681bdce8a  pop r8
00007b4681bdce8c  pop rsi
00007b4681bdce8d  pop rdi
00007b4681bdce8e  pop rdx
00007b4681bdce8f  pop rcx
00007b4681bdce90  pop rax
00007b4681bdce91  add rsp, 0x08
00007b4681bdce95  jmp 0x00007B4681BDA59A
00007b4681bdce9a  call 0x00007B46819FF430
00007b4681bdce9f  jmp 0x00007B4681BDA5AC
00007b4681bdcea4  sub rsp, 0x08
00007b4681bdcea8  push rax
00007b4681bdcea9  push rcx
00007b4681bdceaa  push rdx
00007b4681bdceab  push rdi
00007b4681bdceac  push rsi
00007b4681bdcead  push r8
00007b4681bdceaf  push r9
00007b4681bdceb1  push r10
00007b4681bdceb3  push r11
00007b4681bdceb5  sub rsp, 0xF0
00007b4681bdcebc  vmovaps [rsp], xmm0
00007b4681bdcec1  vmovaps [rsp+0x10], xmm1
00007b4681bdcec7  vmovaps [rsp+0x20], xmm2
00007b4681bdcecd  vmovaps [rsp+0x30], xmm3
00007b4681bdced3  vmovaps [rsp+0x40], xmm4
00007b4681bdced9  vmovaps [rsp+0x50], xmm5
00007b4681bdcedf  vmovaps [rsp+0x60], xmm6
00007b4681bdcee5  vmovaps [rsp+0x70], xmm7
00007b4681bdceeb  vmovaps [rsp+0x80], xmm8
00007b4681bdcef4  vmovaps [rsp+0x90], xmm10
00007b4681bdcefd  vmovaps [rsp+0xA0], xmm11
00007b4681bdcf06  vmovaps [rsp+0xB0], xmm12
00007b4681bdcf0f  vmovaps [rsp+0xC0], xmm13
00007b4681bdcf18  vmovaps [rsp+0xD0], xmm14
00007b4681bdcf21  vmovaps [rsp+0xE0], xmm15
00007b4681bdcf2a  sub rsp, 0x40
00007b4681bdcf2e  lea rdi, [rsp]
00007b4681bdcf32  lea rsi, [rsp+0x10]
00007b4681bdcf37  lea rdx, [rsp+0x20]
00007b4681bdcf3c  lea rcx, [rsp+0x30]
00007b4681bdcf41  mov r8d, 0x00
00007b4681bdcf47  lea r9, [r15+0x3A8]
00007b4681bdcf4e  movaps [rdi], xmm9
00007b4681bdcf52  movaps [rsi], xmm7
00007b4681bdcf55  movaps [rdx], xmm14
00007b4681bdcf59  movaps [rcx], xmm13
00007b4681bdcf5d  mov rax, 0x5668589B5A50
00007b4681bdcf67  call rax
00007b4681bdcf69  movaps xmm9, [rsp]
00007b4681bdcf6e  add rsp, 0x40
00007b4681bdcf72  vmovaps xmm0, [rsp]
00007b4681bdcf77  vmovaps xmm1, [rsp+0x10]
00007b4681bdcf7d  vmovaps xmm2, [rsp+0x20]
00007b4681bdcf83  vmovaps xmm3, [rsp+0x30]
00007b4681bdcf89  vmovaps xmm4, [rsp+0x40]
00007b4681bdcf8f  vmovaps xmm5, [rsp+0x50]
00007b4681bdcf95  vmovaps xmm6, [rsp+0x60]
00007b4681bdcf9b  vmovaps xmm7, [rsp+0x70]
00007b4681bdcfa1  vmovaps xmm8, [rsp+0x80]
00007b4681bdcfaa  vmovaps xmm10, [rsp+0x90]
00007b4681bdcfb3  vmovaps xmm11, [rsp+0xA0]
00007b4681bdcfbc  vmovaps xmm12, [rsp+0xB0]
00007b4681bdcfc5  vmovaps xmm13, [rsp+0xC0]
00007b4681bdcfce  vmovaps xmm14, [rsp+0xD0]
00007b4681bdcfd7  vmovaps xmm15, [rsp+0xE0]
00007b4681bdcfe0  add rsp, 0xF0
00007b4681bdcfe7  pop r11
00007b4681bdcfe9  pop r10
00007b4681bdcfeb  pop r9
00007b4681bdcfed  pop r8
00007b4681bdcfef  pop rsi
00007b4681bdcff0  pop rdi
00007b4681bdcff1  pop rdx
00007b4681bdcff2  pop rcx
00007b4681bdcff3  pop rax
00007b4681bdcff4  add rsp, 0x08
00007b4681bdcff8  jmp 0x00007B4681BDA5DA
00007b4681bdcffd  sub rsp, 0x08
00007b4681bdd001  push rax
00007b4681bdd002  push rcx
00007b4681bdd003  push rdx
00007b4681bdd004  push rdi
00007b4681bdd005  push rsi
00007b4681bdd006  push r8
00007b4681bdd008  push r9
00007b4681bdd00a  push r10
00007b4681bdd00c  push r11
00007b4681bdd00e  sub rsp, 0xF0
00007b4681bdd015  vmovaps [rsp], xmm0
00007b4681bdd01a  vmovaps [rsp+0x10], xmm1
00007b4681bdd020  vmovaps [rsp+0x20], xmm2
00007b4681bdd026  vmovaps [rsp+0x30], xmm3
00007b4681bdd02c  vmovaps [rsp+0x40], xmm4
00007b4681bdd032  vmovaps [rsp+0x50], xmm5
00007b4681bdd038  vmovaps [rsp+0x60], xmm6
00007b4681bdd03e  vmovaps [rsp+0x70], xmm7
00007b4681bdd044  vmovaps [rsp+0x80], xmm8
00007b4681bdd04d  vmovaps [rsp+0x90], xmm9
00007b4681bdd056  vmovaps [rsp+0xA0], xmm10
00007b4681bdd05f  vmovaps [rsp+0xB0], xmm11
00007b4681bdd068  vmovaps [rsp+0xC0], xmm12
00007b4681bdd071  vmovaps [rsp+0xD0], xmm14
00007b4681bdd07a  vmovaps [rsp+0xE0], xmm15
00007b4681bdd083  sub rsp, 0x40
00007b4681bdd087  lea rdi, [rsp]
00007b4681bdd08b  lea rsi, [rsp+0x10]
00007b4681bdd090  lea rdx, [rsp+0x20]
00007b4681bdd095  lea rcx, [rsp+0x30]
00007b4681bdd09a  mov r8d, 0x00
00007b4681bdd0a0  lea r9, [r15+0x3A8]
00007b4681bdd0a7  movaps [rdi], xmm13
00007b4681bdd0ab  movaps [rsi], xmm12
00007b4681bdd0af  movaps [rdx], xmm15
00007b4681bdd0b3  movaps [rcx], xmm14
00007b4681bdd0b7  mov rax, 0x5668589B5A50
00007b4681bdd0c1  call rax
00007b4681bdd0c3  movaps xmm13, [rsp]
00007b4681bdd0c8  add rsp, 0x40
00007b4681bdd0cc  vmovaps xmm0, [rsp]
00007b4681bdd0d1  vmovaps xmm1, [rsp+0x10]
00007b4681bdd0d7  vmovaps xmm2, [rsp+0x20]
00007b4681bdd0dd  vmovaps xmm3, [rsp+0x30]
00007b4681bdd0e3  vmovaps xmm4, [rsp+0x40]
00007b4681bdd0e9  vmovaps xmm5, [rsp+0x50]
00007b4681bdd0ef  vmovaps xmm6, [rsp+0x60]
00007b4681bdd0f5  vmovaps xmm7, [rsp+0x70]
00007b4681bdd0fb  vmovaps xmm8, [rsp+0x80]
00007b4681bdd104  vmovaps xmm9, [rsp+0x90]
00007b4681bdd10d  vmovaps xmm10, [rsp+0xA0]
00007b4681bdd116  vmovaps xmm11, [rsp+0xB0]
00007b4681bdd11f  vmovaps xmm12, [rsp+0xC0]
00007b4681bdd128  vmovaps xmm14, [rsp+0xD0]
00007b4681bdd131  vmovaps xmm15, [rsp+0xE0]
00007b4681bdd13a  add rsp, 0xF0
00007b4681bdd141  pop r11
00007b4681bdd143  pop r10
00007b4681bdd145  pop r9
00007b4681bdd147  pop r8
00007b4681bdd149  pop rsi
00007b4681bdd14a  pop rdi
00007b4681bdd14b  pop rdx
00007b4681bdd14c  pop rcx
00007b4681bdd14d  pop rax
00007b4681bdd14e  add rsp, 0x08
00007b4681bdd152  jmp 0x00007B4681BDA608
00007b4681bdd157  sub rsp, 0x08
00007b4681bdd15b  push rax
00007b4681bdd15c  push rcx
00007b4681bdd15d  push rdx
00007b4681bdd15e  push rdi
00007b4681bdd15f  push rsi
00007b4681bdd160  push r8
00007b4681bdd162  push r9
00007b4681bdd164  push r10
00007b4681bdd166  push r11
00007b4681bdd168  sub rsp, 0xF0
00007b4681bdd16f  vmovaps [rsp], xmm0
00007b4681bdd174  vmovaps [rsp+0x10], xmm1
00007b4681bdd17a  vmovaps [rsp+0x20], xmm2
00007b4681bdd180  vmovaps [rsp+0x30], xmm3
00007b4681bdd186  vmovaps [rsp+0x40], xmm4
00007b4681bdd18c  vmovaps [rsp+0x50], xmm5
00007b4681bdd192  vmovaps [rsp+0x60], xmm6
00007b4681bdd198  vmovaps [rsp+0x70], xmm7
00007b4681bdd19e  vmovaps [rsp+0x80], xmm8
00007b4681bdd1a7  vmovaps [rsp+0x90], xmm9
00007b4681bdd1b0  vmovaps [rsp+0xA0], xmm10
00007b4681bdd1b9  vmovaps [rsp+0xB0], xmm11
00007b4681bdd1c2  vmovaps [rsp+0xC0], xmm12
00007b4681bdd1cb  vmovaps [rsp+0xD0], xmm13
00007b4681bdd1d4  vmovaps [rsp+0xE0], xmm15
00007b4681bdd1dd  sub rsp, 0x40
00007b4681bdd1e1  lea rdi, [rsp]
00007b4681bdd1e5  lea rsi, [rsp+0x10]
00007b4681bdd1ea  lea rdx, [rsp+0x20]
00007b4681bdd1ef  lea rcx, [rsp+0x30]
00007b4681bdd1f4  mov r8d, 0x00
00007b4681bdd1fa  lea r9, [r15+0x3A8]
00007b4681bdd201  movaps [rdi], xmm14
00007b4681bdd205  movaps [rsi], xmm11
00007b4681bdd209  movaps [rdx], xmm1
00007b4681bdd20c  movaps [rcx], xmm15
00007b4681bdd210  mov rax, 0x5668589B5A50
00007b4681bdd21a  call rax
00007b4681bdd21c  movaps xmm14, [rsp]
00007b4681bdd221  add rsp, 0x40
00007b4681bdd225  vmovaps xmm0, [rsp]
00007b4681bdd22a  vmovaps xmm1, [rsp+0x10]
00007b4681bdd230  vmovaps xmm2, [rsp+0x20]
00007b4681bdd236  vmovaps xmm3, [rsp+0x30]
00007b4681bdd23c  vmovaps xmm4, [rsp+0x40]
00007b4681bdd242  vmovaps xmm5, [rsp+0x50]
00007b4681bdd248  vmovaps xmm6, [rsp+0x60]
00007b4681bdd24e  vmovaps xmm7, [rsp+0x70]
00007b4681bdd254  vmovaps xmm8, [rsp+0x80]
00007b4681bdd25d  vmovaps xmm9, [rsp+0x90]
00007b4681bdd266  vmovaps xmm10, [rsp+0xA0]
00007b4681bdd26f  vmovaps xmm11, [rsp+0xB0]
00007b4681bdd278  vmovaps xmm12, [rsp+0xC0]
00007b4681bdd281  vmovaps xmm13, [rsp+0xD0]
00007b4681bdd28a  vmovaps xmm15, [rsp+0xE0]
00007b4681bdd293  add rsp, 0xF0
00007b4681bdd29a  pop r11
00007b4681bdd29c  pop r10
00007b4681bdd29e  pop r9
00007b4681bdd2a0  pop r8
00007b4681bdd2a2  pop rsi
00007b4681bdd2a3  pop rdi
00007b4681bdd2a4  pop rdx
00007b4681bdd2a5  pop rcx
00007b4681bdd2a6  pop rax
00007b4681bdd2a7  add rsp, 0x08
00007b4681bdd2ab  jmp 0x00007B4681BDA636
00007b4681bdd2b0  call 0x00007B4681A079B0
00007b4681bdd2b5  jmp 0x00007B4681BDA64C
00007b4681bdd2ba  call 0x00007B4681AE3440
00007b4681bdd2bf  jmp 0x00007B4681BDA656
00007b4681bdd2c4  call 0x00007B4681ADFCE0
00007b4681bdd2c9  jmp 0x00007B4681BDA660
00007b4681bdd2ce  call 0x00007B4681AE46C0
00007b4681bdd2d3  jmp 0x00007B4681BDA66A
00007b4681bdd2d8  int3
00007b4681bdd2d9  nop [rax], eax
00007b4681bdd2e0  mov qword ptr [r15+0x40], 0x430000
00007b4681bdd2e8  mov eax, 0x430C50
00007b4681bdd2ed  mov r14, [r13+rax*1]
00007b4681bdd2f2  movq xmm1, r14
00007b4681bdd2f7  mov rax, [r15+0x50]
00007b4681bdd2fb  movups xmm15, [r13+rax*1]
00007b4681bdd301  movaps [r15+0x120], xmm15
00007b4681bdd309  mov qword ptr [r15+0x48], 0x10
00007b4681bdd311  xor eax, eax
00007b4681bdd313  mov r14d, 0x10
00007b4681bdd319  mov r12d, 0x200
00007b4681bdd31f  cmp r14, r12
00007b4681bdd322  cmc
00007b4681bdd323  lahf
00007b4681bdd324  seto al
00007b4681bdd327  mov [r15+0x108], eax
00007b4681bdd32e  pextrq rax, xmm15, 0x01
00007b4681bdd335  movq xmm14, rax
00007b4681bdd33a  movaps [r15+0x130], xmm14
00007b4681bdd342  movq rax, xmm1
00007b4681bdd347  movq r14, xmm15
00007b4681bdd34c  vmovq xmm1, rax
00007b4681bdd351  vmovq xmm15, r14
00007b4681bdd356  movaps xmm13, xmm1
00007b4681bdd35a  addsd xmm13, xmm15
00007b4681bdd35f  ucomisd xmm13, xmm13
00007b4681bdd364  jp 0x00007B4681BDD423
00007b4681bdd36a  movq xmm13, xmm13
00007b4681bdd36f  movq rax, xmm13
00007b4681bdd374  movq r14, xmm14
00007b4681bdd379  vmovq xmm1, rax
00007b4681bdd37e  vmovq xmm15, r14
00007b4681bdd383  movaps xmm14, xmm1
00007b4681bdd387  addsd xmm14, xmm15
00007b4681bdd38c  ucomisd xmm14, xmm14
00007b4681bdd391  jp 0x00007B4681BDD46B
00007b4681bdd397  movq xmm14, xmm14
00007b4681bdd39c  movaps [r15+0x110], xmm14
00007b4681bdd3a4  mov eax, [r15+0x108]
00007b4681bdd3ab  sahf
00007b4681bdd3ac  jnz 0x00007B4681BDD3DE
00007b4681bdd3ae  cmp dword ptr [r15+0x318], 0x00
00007b4681bdd3b6  jz 0x00007B4681BDD680
00007b4681bdd3bc  nop [rax+rax*1], ax
00007b4681bdd3c5  nop [rax+rax*1], eax
00007b4681bdd3cd  mov eax, 0x410698
00007b4681bdd3d2  mov [r15+0x100], rax
00007b4681bdd3d9  jmp 0x00007B46819FE110
00007b4681bdd3de  cmp dword ptr [r15+0x318], 0x00
00007b4681bdd3e6  jz 0x00007B4681BDD4C0
00007b4681bdd3ec  nop [rax+rax*1], ax
00007b4681bdd3f5  nop [rax+rax*1], eax
00007b4681bdd3fd  mov eax, 0x41067C
00007b4681bdd402  mov [r15+0x100], rax
00007b4681bdd409  jmp 0x00007B46819FE110
00007b4681bdd40e  int3
00007b4681bdd40f  call 0x00007B4681A0DC20
00007b4681bdd414  jmp 0x00007B4681BDD2F2
00007b4681bdd419  call 0x00007B4681A0E760
00007b4681bdd41e  jmp 0x00007B4681BDD301
00007b4681bdd423  ucomisd xmm1, xmm15
00007b4681bdd428  jp 0x00007B4681BDD437
00007b4681bdd42a  movaps xmm13, [0x00007B46817FE060]
00007b4681bdd432  jmp 0x00007B4681BDD36A
00007b4681bdd437  vxorps xmm0, xmm1, xmm15
00007b4681bdd43c  pextrw eax, xmm0, 0x03
00007b4681bdd441  and eax, 0x7FF8
00007b4681bdd446  cmp eax, 0x08
00007b4681bdd449  jnz 0x00007B4681BDD36A
00007b4681bdd44f  movq rax, xmm15
00007b4681bdd454  shl rax, 0x0D
00007b4681bdd458  jbe 0x00007B4681BDD36A
00007b4681bdd45e  vorps xmm13, xmm15, [0x00007B46817FE070]
00007b4681bdd466  jmp 0x00007B4681BDD36A
00007b4681bdd46b  ucomisd xmm1, xmm15
00007b4681bdd470  jp 0x00007B4681BDD47F
00007b4681bdd472  movaps xmm14, [0x00007B46817FE060]
00007b4681bdd47a  jmp 0x00007B4681BDD397
00007b4681bdd47f  vxorps xmm0, xmm1, xmm15
00007b4681bdd484  pextrw eax, xmm0, 0x03
00007b4681bdd489  and eax, 0x7FF8
00007b4681bdd48e  cmp eax, 0x08
00007b4681bdd491  jnz 0x00007B4681BDD397
00007b4681bdd497  movq rax, xmm15
00007b4681bdd49c  shl rax, 0x0D
00007b4681bdd4a0  jbe 0x00007B4681BDD397
00007b4681bdd4a6  vorps xmm14, xmm15, [0x00007B46817FE070]
00007b4681bdd4ae  jmp 0x00007B4681BDD397
00007b4681bdd4b3  int3
00007b4681bdd4b4  nop [rax+rax*1], ax
00007b4681bdd4bd  nop [rax], eax
00007b4681bdd4c0  mov rax, [r15+0x48]
00007b4681bdd4c4  mov r14, [r15+0x50]
00007b4681bdd4c8  lea r12, [r14+rax*1]
00007b4681bdd4cc  movups xmm1, [r13+r12*1]
00007b4681bdd4d2  movaps [r15+0x120], xmm1
00007b4681bdd4da  lea r14, [rax+0x10]
00007b4681bdd4de  mov [r15+0x48], r14
00007b4681bdd4e2  xor eax, eax
00007b4681bdd4e4  mov r12d, 0x200
00007b4681bdd4ea  cmp r14, r12
00007b4681bdd4ed  cmc
00007b4681bdd4ee  lahf
00007b4681bdd4ef  seto al
00007b4681bdd4f2  mov [r15+0x108], eax
00007b4681bdd4f9  pextrq rax, xmm1, 0x01
00007b4681bdd500  movq xmm15, rax
00007b4681bdd505  movaps [r15+0x130], xmm15
00007b4681bdd50d  movaps xmm14, [r15+0x110]
00007b4681bdd515  movq rax, xmm14
00007b4681bdd51a  movq r14, xmm1
00007b4681bdd51f  vmovq xmm1, rax
00007b4681bdd524  vmovq xmm14, r14
00007b4681bdd529  movaps xmm13, xmm1
00007b4681bdd52d  addsd xmm13, xmm14
00007b4681bdd532  ucomisd xmm13, xmm13
00007b4681bdd537  jp 0x00007B4681BDD5EC
00007b4681bdd53d  movq xmm13, xmm13
00007b4681bdd542  movq rax, xmm13
00007b4681bdd547  movq r14, xmm15
00007b4681bdd54c  vmovq xmm1, rax
00007b4681bdd551  vmovq xmm15, r14
00007b4681bdd556  movaps xmm14, xmm1
00007b4681bdd55a  addsd xmm14, xmm15
00007b4681bdd55f  ucomisd xmm14, xmm14
00007b4681bdd564  jp 0x00007B4681BDD634
00007b4681bdd56a  movq xmm14, xmm14
00007b4681bdd56f  movaps [r15+0x110], xmm14
00007b4681bdd577  mov eax, [r15+0x108]
00007b4681bdd57e  sahf
00007b4681bdd57f  jnz 0x00007B4681BDD5B1
00007b4681bdd581  cmp dword ptr [r15+0x318], 0x00
00007b4681bdd589  jz 0x00007B4681BDD680
00007b4681bdd58f  nop [rax+rax*1], ax
00007b4681bdd598  nop [rax+rax*1], eax
00007b4681bdd5a0  mov eax, 0x410698
00007b4681bdd5a5  mov [r15+0x100], rax
00007b4681bdd5ac  jmp 0x00007B46819FE110
00007b4681bdd5b1  cmp dword ptr [r15+0x318], 0x00
00007b4681bdd5b9  jz 0x00007B4681BDD4C0
00007b4681bdd5bf  nop [rax+rax*1], ax
00007b4681bdd5c8  nop [rax+rax*1], eax
00007b4681bdd5d0  mov eax, 0x41067C
00007b4681bdd5d5  mov [r15+0x100], rax
00007b4681bdd5dc  jmp 0x00007B46819FE110
00007b4681bdd5e1  int3
00007b4681bdd5e2  call 0x00007B4681AB52F0
00007b4681bdd5e7  jmp 0x00007B4681BDD4D2
00007b4681bdd5ec  ucomisd xmm1, xmm14
00007b4681bdd5f1  jp 0x00007B4681BDD600
00007b4681bdd5f3  movaps xmm13, [0x00007B46817FE060]
00007b4681bdd5fb  jmp 0x00007B4681BDD53D
00007b4681bdd600  vxorps xmm0, xmm1, xmm14
00007b4681bdd605  pextrw eax, xmm0, 0x03
00007b4681bdd60a  and eax, 0x7FF8
00007b4681bdd60f  cmp eax, 0x08
00007b4681bdd612  jnz 0x00007B4681BDD53D
00007b4681bdd618  movq rax, xmm14
00007b4681bdd61d  shl rax, 0x0D
00007b4681bdd621  jbe 0x00007B4681BDD53D
00007b4681bdd627  vorps xmm13, xmm14, [0x00007B46817FE070]
00007b4681bdd62f  jmp 0x00007B4681BDD53D
00007b4681bdd634  ucomisd xmm1, xmm15
00007b4681bdd639  jp 0x00007B4681BDD648
00007b4681bdd63b  movaps xmm14, [0x00007B46817FE060]
00007b4681bdd643  jmp 0x00007B4681BDD56A
00007b4681bdd648  vxorps xmm0, xmm1, xmm15
00007b4681bdd64d  pextrw eax, xmm0, 0x03
00007b4681bdd652  and eax, 0x7FF8
00007b4681bdd657  cmp eax, 0x08
00007b4681bdd65a  jnz 0x00007B4681BDD56A
00007b4681bdd660  movq rax, xmm15
00007b4681bdd665  shl rax, 0x0D
00007b4681bdd669  jbe 0x00007B4681BDD56A
00007b4681bdd66f  vorps xmm14, xmm15, [0x00007B46817FE070]
00007b4681bdd677  jmp 0x00007B4681BDD56A
00007b4681bdd67c  int3
00007b4681bdd67d  nop [rax], eax
00007b4681bdd680  mov rax, [r15+0xF8]
00007b4681bdd687  lea r14, [rax+0x1A0]
00007b4681bdd68e  mov r12, [r13+r14*1]
00007b4681bdd693  lea r14, [rax+0x1A8]
00007b4681bdd69a  mov r11, [r13+r14*1]
00007b4681bdd69f  mov [r15+0xA0], r12
00007b4681bdd6a6  mov [r15+0x98], r11
00007b4681bdd6ad  mov r14, [r15+0x40]
00007b4681bdd6b1  lea r12, [r14+0xC50]
00007b4681bdd6b8  movaps xmm1, [r15+0x110]
00007b4681bdd6c0  movq r14, xmm1
00007b4681bdd6c5  mov [r13+r12*1], r14
00007b4681bdd6ca  lea r14, [rax+0x190]
00007b4681bdd6d1  mov r12, [r13+r14*1]
00007b4681bdd6d6  lea r14, [rax+0x198]
00007b4681bdd6dd  mov r11, [r13+r14*1]
00007b4681bdd6e2  mov [r15+0xE8], r12
00007b4681bdd6e9  mov [r15+0xF0], r11
00007b4681bdd6f0  lea r14, [rax+0x180]
00007b4681bdd6f7  mov r12, [r13+r14*1]
00007b4681bdd6fc  lea r14, [rax+0x188]
00007b4681bdd703  mov r10, [r13+r14*1]
00007b4681bdd708  movq xmm1, r12
00007b4681bdd70d  movq xmm15, r10
00007b4681bdd712  movq xmm1, xmm1
00007b4681bdd716  movq xmm1, xmm1
00007b4681bdd71a  movaps [r15+0x1A0], xmm1
00007b4681bdd722  movq xmm15, xmm15
00007b4681bdd727  movq xmm15, xmm15
00007b4681bdd72c  movaps [r15+0x190], xmm15
00007b4681bdd734  lea r14, [rax+0x170]
00007b4681bdd73b  mov r12, [r13+r14*1]
00007b4681bdd740  lea r14, [rax+0x178]
00007b4681bdd747  mov r10, [r13+r14*1]
00007b4681bdd74c  movq xmm1, r12
00007b4681bdd751  movq xmm15, r10
00007b4681bdd756  movq xmm1, xmm1
00007b4681bdd75a  movq xmm1, xmm1
00007b4681bdd75e  movaps [r15+0x1C0], xmm1
00007b4681bdd766  movq xmm15, xmm15
00007b4681bdd76b  movq xmm15, xmm15
00007b4681bdd770  movaps [r15+0x1B0], xmm15
00007b4681bdd778  lea r14, [rax+0x160]
00007b4681bdd77f  mov r12, [r13+r14*1]
00007b4681bdd784  lea r14, [rax+0x168]
00007b4681bdd78b  mov r10, [r13+r14*1]
00007b4681bdd790  movq xmm1, r12
00007b4681bdd795  movq xmm15, r10
00007b4681bdd79a  movq xmm1, xmm1
00007b4681bdd79e  movq xmm1, xmm1
00007b4681bdd7a2  movaps [r15+0x1E0], xmm1
00007b4681bdd7aa  movq xmm15, xmm15
00007b4681bdd7af  movq xmm15, xmm15
00007b4681bdd7b4  movaps [r15+0x1D0], xmm15
00007b4681bdd7bc  lea r14, [rax+0x150]
00007b4681bdd7c3  mov r12, [r13+r14*1]
00007b4681bdd7c8  lea r14, [rax+0x158]
00007b4681bdd7cf  mov r10, [r13+r14*1]
00007b4681bdd7d4  movq xmm1, r12
00007b4681bdd7d9  movq xmm15, r10
00007b4681bdd7de  movq xmm1, xmm1
00007b4681bdd7e2  movq xmm1, xmm1
00007b4681bdd7e6  movaps [r15+0x200], xmm1
00007b4681bdd7ee  movq xmm15, xmm15
00007b4681bdd7f3  movq xmm15, xmm15
00007b4681bdd7f8  movaps [r15+0x1F0], xmm15
00007b4681bdd800  lea r14, [rax+0x1B0]
00007b4681bdd807  mov [r15+0xF8], r14
00007b4681bdd80e  mov [r15+0x100], r11
00007b4681bdd815  jmp 0x00007B4681BCE5C0
00007b4681bdd81a  int3
00007b4681bdd81b  call 0x00007B4681AE27E0
00007b4681bdd820  jmp 0x00007B4681BDD693
00007b4681bdd825  call 0x00007B4681AE1570
00007b4681bdd82a  jmp 0x00007B4681BDD69F
00007b4681bdd82f  call 0x00007B4681AC3FE0
00007b4681bdd834  jmp 0x00007B4681BDD6CA
00007b4681bdd839  call 0x00007B4681AE27E0
00007b4681bdd83e  jmp 0x00007B4681BDD6D6
00007b4681bdd843  call 0x00007B4681AE1570
00007b4681bdd848  jmp 0x00007B4681BDD6E2
00007b4681bdd84d  call 0x00007B4681AE27E0
00007b4681bdd852  jmp 0x00007B4681BDD6FC
00007b4681bdd857  call 0x00007B4681AE0300
00007b4681bdd85c  jmp 0x00007B4681BDD708
00007b4681bdd861  call 0x00007B4681AE27E0
00007b4681bdd866  jmp 0x00007B4681BDD740
00007b4681bdd86b  call 0x00007B4681AE0300
00007b4681bdd870  jmp 0x00007B4681BDD74C
00007b4681bdd875  call 0x00007B4681AE27E0
00007b4681bdd87a  jmp 0x00007B4681BDD784
00007b4681bdd87f  call 0x00007B4681AE0300
00007b4681bdd884  jmp 0x00007B4681BDD790
00007b4681bdd889  call 0x00007B4681AE27E0
00007b4681bdd88e  jmp 0x00007B4681BDD7C8
00007b4681bdd893  call 0x00007B4681AE0300
00007b4681bdd898  jmp 0x00007B4681BDD7D4
00007b4681bdd89d  int3
00007b4681bdd89e  nop
00007b4681bdd8a0  mov qword ptr [r15+0x100], 0x04
00007b4681bdd8ab  mov esi, 0x00
00007b4681bdd8b0  mov edx, 0x09
00007b4681bdd8b5  mov rdi, 0x7FFF12138DF0
00007b4681bdd8bf  mov rax, 0x566858848970
00007b4681bdd8c9  call rax
00007b4681bdd8cb  cmp dword ptr [r15+0x318], 0x00
00007b4681bdd8d3  jnz 0x00007B46819FE110
00007b4681bdd8d9  jmp 0x00007B46819FE0A0
00007b4681bdd8de  int3
00007b4681bdd8df  int3
