00007a44d59ce69b  nop [rax+rax*1], eax
00007a44d59ce6a0  mov rax, [r15+0xF8]
00007a44d59ce6a7  lea r14, [rax-0x1B0]
00007a44d59ce6ae  mov [r15+0xF8], r14
00007a44d59ce6b5  lea rax, [r14+0x1A0]
00007a44d59ce6bc  mov r12, [r15+0xA0]
00007a44d59ce6c3  mov r11, [r15+0x98]
00007a44d59ce6ca  mov [r13+rax*1], r12
00007a44d59ce6cf  lea rax, [r14+0x1A8]
00007a44d59ce6d6  mov [r13+rax*1], r11
00007a44d59ce6db  mov eax, 0x420A30
00007a44d59ce6e0  movups xmm1, [r13+rax*1]
00007a44d59ce6e6  mov eax, 0x4209C0
00007a44d59ce6eb  movups xmm15, [r13+rax*1]
00007a44d59ce6f1  mov eax, 0x420A50
00007a44d59ce6f6  movups xmm14, [r13+rax*1]
00007a44d59ce6fc  mov eax, 0x4209F0
00007a44d59ce701  movups xmm13, [r13+rax*1]
00007a44d59ce707  mov qword ptr [r15+0x98], 0x430C60
00007a44d59ce712  mov eax, 0x420A60
00007a44d59ce717  movups xmm12, [r13+rax*1]
00007a44d59ce71d  mov eax, 0x430C60
00007a44d59ce722  movups [r13+rax*1], xmm1
00007a44d59ce728  mov eax, 0x430C70
00007a44d59ce72d  movups [r13+rax*1], xmm15
00007a44d59ce733  mov eax, 0x430C80
00007a44d59ce738  movups [r13+rax*1], xmm14
00007a44d59ce73e  mov eax, 0x430C90
00007a44d59ce743  movups [r13+rax*1], xmm13
00007a44d59ce749  mov eax, 0x4209B0
00007a44d59ce74e  movups xmm14, [r13+rax*1]
00007a44d59ce754  mov eax, 0x4209A0
00007a44d59ce759  movups xmm13, [r13+rax*1]
00007a44d59ce75f  mov eax, 0x430D60
00007a44d59ce764  movups [r13+rax*1], xmm1
00007a44d59ce76a  mov eax, 0x430D70
00007a44d59ce76f  movups [r13+rax*1], xmm15
00007a44d59ce775  mov eax, 0x430CA0
00007a44d59ce77a  movups [r13+rax*1], xmm12
00007a44d59ce780  mov eax, 0x430CB0
00007a44d59ce785  movups [r13+rax*1], xmm14
00007a44d59ce78b  mov eax, 0x420990
00007a44d59ce790  movups xmm1, [r13+rax*1]
00007a44d59ce796  mov eax, 0x420A00
00007a44d59ce79b  movups xmm15, [r13+rax*1]
00007a44d59ce7a1  mov eax, 0x430CC0
00007a44d59ce7a6  movups [r13+rax*1], xmm13
00007a44d59ce7ac  mov eax, 0x430CD0
00007a44d59ce7b1  movups [r13+rax*1], xmm1
00007a44d59ce7b7  mov eax, 0x420A10
00007a44d59ce7bc  movups xmm1, [r13+rax*1]
00007a44d59ce7c2  mov eax, 0x4209E0
00007a44d59ce7c7  movups xmm14, [r13+rax*1]
00007a44d59ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007a44d59ce7d5  mov eax, 0x430CE0
00007a44d59ce7da  movups [r13+rax*1], xmm15
00007a44d59ce7e0  mov eax, 0x430CF0
00007a44d59ce7e5  movups [r13+rax*1], xmm1
00007a44d59ce7eb  mov eax, 0x420A80
00007a44d59ce7f0  movups xmm1, [r13+rax*1]
00007a44d59ce7f6  mov eax, 0x420A90
00007a44d59ce7fb  movups xmm15, [r13+rax*1]
00007a44d59ce801  movaps [r15+0x150], xmm15
00007a44d59ce809  mov qword ptr [r15+0xA0], 0x3E8
00007a44d59ce814  mov eax, 0x430D00
00007a44d59ce819  movups [r13+rax*1], xmm14
00007a44d59ce81f  mov eax, 0x430D10
00007a44d59ce824  movups [r13+rax*1], xmm1
00007a44d59ce82a  mov eax, 0x420A70
00007a44d59ce82f  movups xmm1, [r13+rax*1]
00007a44d59ce835  mov eax, 0x420A20
00007a44d59ce83a  movups xmm14, [r13+rax*1]
00007a44d59ce840  movaps [r15+0x140], xmm14
00007a44d59ce848  lea rax, [r14+0x150]
00007a44d59ce84f  movq xmm13, qword ptr [r15+0x200]
00007a44d59ce858  movq xmm12, qword ptr [r15+0x1F0]
00007a44d59ce861  movq r12, xmm13
00007a44d59ce866  movq r11, xmm12
00007a44d59ce86b  mov [r13+rax*1], r12
00007a44d59ce870  lea rax, [r14+0x158]
00007a44d59ce877  mov [r13+rax*1], r11
00007a44d59ce87c  mov eax, 0x430D20
00007a44d59ce881  movups [r13+rax*1], xmm15
00007a44d59ce887  mov eax, 0x430D30
00007a44d59ce88c  movups [r13+rax*1], xmm1
00007a44d59ce892  mov eax, 0x420A40
00007a44d59ce897  movups xmm1, [r13+rax*1]
00007a44d59ce89d  mov eax, 0x420AA8
00007a44d59ce8a2  mov r12, [r13+rax*1]
00007a44d59ce8a7  movq xmm15, r12
00007a44d59ce8ac  mov qword ptr [r15+0x40], 0x420AB0
00007a44d59ce8b4  mov eax, 0x430D40
00007a44d59ce8b9  movups [r13+rax*1], xmm14
00007a44d59ce8bf  mov eax, 0x430D50
00007a44d59ce8c4  movups [r13+rax*1], xmm1
00007a44d59ce8ca  mov eax, 0x420B10
00007a44d59ce8cf  movups xmm1, [r13+rax*1]
00007a44d59ce8d5  movq rax, xmm15
00007a44d59ce8da  mov r12d, 0x430D80
00007a44d59ce8e0  mov [r13+r12*1], rax
00007a44d59ce8e5  mov eax, 0x420AF0
00007a44d59ce8ea  movups xmm15, [r13+rax*1]
00007a44d59ce8f0  mov eax, 0x420B00
00007a44d59ce8f5  movups xmm14, [r13+rax*1]
00007a44d59ce8fb  lea rax, [r14+0x130]
00007a44d59ce902  movups [r13+rax*1], xmm1
00007a44d59ce908  lea rax, [r14+0x160]
00007a44d59ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007a44d59ce918  movq xmm13, qword ptr [r15+0x1D0]
00007a44d59ce921  movq r12, xmm1
00007a44d59ce926  movq r11, xmm13
00007a44d59ce92b  mov [r13+rax*1], r12
00007a44d59ce930  lea rax, [r14+0x168]
00007a44d59ce937  mov [r13+rax*1], r11
00007a44d59ce93c  lea rax, [r14+0x110]
00007a44d59ce943  movups [r13+rax*1], xmm15
00007a44d59ce949  lea rax, [r14+0x120]
00007a44d59ce950  movups [r13+rax*1], xmm14
00007a44d59ce956  mov eax, 0x420AB0
00007a44d59ce95b  movups xmm1, [r13+rax*1]
00007a44d59ce961  mov eax, 0x420AC0
00007a44d59ce966  movups xmm15, [r13+rax*1]
00007a44d59ce96c  movaps [r15+0x120], xmm15
00007a44d59ce974  lea rax, [r14+0x170]
00007a44d59ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007a44d59ce984  movq xmm13, qword ptr [r15+0x1B0]
00007a44d59ce98d  movq r12, xmm14
00007a44d59ce992  movq r11, xmm13
00007a44d59ce997  mov [r13+rax*1], r12
00007a44d59ce99c  lea rax, [r14+0x178]
00007a44d59ce9a3  mov [r13+rax*1], r11
00007a44d59ce9a8  lea rax, [r14+0x180]
00007a44d59ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007a44d59ce9b8  movq xmm13, qword ptr [r15+0x190]
00007a44d59ce9c1  movq r12, xmm14
00007a44d59ce9c6  movq r11, xmm13
00007a44d59ce9cb  mov [r13+rax*1], r12
00007a44d59ce9d0  lea rax, [r14+0x188]
00007a44d59ce9d7  mov [r13+rax*1], r11
00007a44d59ce9dc  lea rax, [r14+0xD0]
00007a44d59ce9e3  movups [r13+rax*1], xmm1
00007a44d59ce9e9  lea rax, [r14+0xE0]
00007a44d59ce9f0  movups [r13+rax*1], xmm15
00007a44d59ce9f6  mov eax, 0x420AD0
00007a44d59ce9fb  movups xmm1, [r13+rax*1]
00007a44d59cea01  mov eax, 0x420AE0
00007a44d59cea06  movups xmm15, [r13+rax*1]
00007a44d59cea0c  movaps [r15+0x110], xmm1
00007a44d59cea14  movaps [r15+0x130], xmm15
00007a44d59cea1c  lea rax, [r14+0x190]
00007a44d59cea23  mov r12, [r15+0xE8]
00007a44d59cea2a  mov r11, [r15+0xF0]
00007a44d59cea31  mov [r13+rax*1], r12
00007a44d59cea36  lea rax, [r14+0x198]
00007a44d59cea3d  mov [r13+rax*1], r11
00007a44d59cea42  mov eax, 0x430D88
00007a44d59cea47  mov r12d, 0x421DF8D3
00007a44d59cea4d  mov [r13+rax*1], r12d
00007a44d59cea52  lea rax, [r14+0xF0]
00007a44d59cea59  movups [r13+rax*1], xmm1
00007a44d59cea5f  lea rax, [r14+0x100]
00007a44d59cea66  movups [r13+rax*1], xmm15
00007a44d59cea6c  lea rax, [r14+0xD0]
00007a44d59cea73  mov [r15], rax
00007a44d59cea76  mov qword ptr [r15+0x08], 0x430C60
00007a44d59cea7e  mov qword ptr [r15+0x10], 0x12C
00007a44d59cea86  mov qword ptr [r15+0xF0], 0x410284
00007a44d59cea91  mov r14d, [r15+0x320]
00007a44d59cea98  mov eax, 0x410284
00007a44d59cea9d  mov rcx, 0x7A44D59D07C0
00007a44d59ceaa7  mov [r15+r14*8+0x328], rax
00007a44d59ceaaf  mov [r15+r14*8+0x368], rcx
00007a44d59ceab7  add r14d, 0x01
00007a44d59ceabb  and r14d, 0x07
00007a44d59ceabf  mov [r15+0x320], r14d
00007a44d59ceac6  cmp dword ptr [r15+0x318], 0x00
00007a44d59ceace  jz 0x00007A44D59CED70
00007a44d59cead4  nop [rax+rax*1], ax
00007a44d59ceadd  nop [rax+rax*1], eax
00007a44d59ceae5  mov eax, 0x4106BC
00007a44d59ceaea  mov [r15+0x100], rax
00007a44d59ceaf1  jmp 0x00007A44D57FE110
00007a44d59ceaf6  int3
00007a44d59ceaf7  call 0x00007A44D580BC20
00007a44d59ceafc  jmp 0x00007A44D59CE6CF
00007a44d59ceb01  call 0x00007A44D580A9A0
00007a44d59ceb06  jmp 0x00007A44D59CE6DB
00007a44d59ceb0b  call 0x00007A44D57FF430
00007a44d59ceb10  jmp 0x00007A44D59CE6E6
00007a44d59ceb15  call 0x00007A44D580E760
00007a44d59ceb1a  jmp 0x00007A44D59CE6F1
00007a44d59ceb1f  call 0x00007A44D580D4E0
00007a44d59ceb24  jmp 0x00007A44D59CE6FC
00007a44d59ceb29  call 0x00007A44D580C260
00007a44d59ceb2e  jmp 0x00007A44D59CE707
00007a44d59ceb33  call 0x00007A44D580AFE0
00007a44d59ceb38  jmp 0x00007A44D59CE71D
00007a44d59ceb3d  call 0x00007A44D57FF540
00007a44d59ceb42  jmp 0x00007A44D59CE728
00007a44d59ceb47  call 0x00007A44D580E880
00007a44d59ceb4c  jmp 0x00007A44D59CE733
00007a44d59ceb51  call 0x00007A44D580D600
00007a44d59ceb56  jmp 0x00007A44D59CE73E
00007a44d59ceb5b  call 0x00007A44D580C380
00007a44d59ceb60  jmp 0x00007A44D59CE749
00007a44d59ceb65  call 0x00007A44D580D4E0
00007a44d59ceb6a  jmp 0x00007A44D59CE754
00007a44d59ceb6f  call 0x00007A44D580C260
00007a44d59ceb74  jmp 0x00007A44D59CE75F
00007a44d59ceb79  call 0x00007A44D57FF540
00007a44d59ceb7e  jmp 0x00007A44D59CE76A
00007a44d59ceb83  call 0x00007A44D580E880
00007a44d59ceb88  jmp 0x00007A44D59CE775
00007a44d59ceb8d  call 0x00007A44D580B100
00007a44d59ceb92  jmp 0x00007A44D59CE780
00007a44d59ceb97  call 0x00007A44D580D600
00007a44d59ceb9c  jmp 0x00007A44D59CE78B
00007a44d59ceba1  call 0x00007A44D57FF430
00007a44d59ceba6  jmp 0x00007A44D59CE796
00007a44d59cebab  call 0x00007A44D580E760
00007a44d59cebb0  jmp 0x00007A44D59CE7A1
00007a44d59cebb5  call 0x00007A44D580C380
00007a44d59cebba  jmp 0x00007A44D59CE7AC
00007a44d59cebbf  call 0x00007A44D57FF540
00007a44d59cebc4  jmp 0x00007A44D59CE7B7
00007a44d59cebc9  call 0x00007A44D57FF430
00007a44d59cebce  jmp 0x00007A44D59CE7C2
00007a44d59cebd3  call 0x00007A44D580D4E0
00007a44d59cebd8  jmp 0x00007A44D59CE7CD
00007a44d59cebdd  call 0x00007A44D580E880
00007a44d59cebe2  jmp 0x00007A44D59CE7E0
00007a44d59cebe7  call 0x00007A44D57FF540
00007a44d59cebec  jmp 0x00007A44D59CE7EB
00007a44d59cebf1  call 0x00007A44D57FF430
00007a44d59cebf6  jmp 0x00007A44D59CE7F6
00007a44d59cebfb  call 0x00007A44D580E760
00007a44d59cec00  jmp 0x00007A44D59CE801
00007a44d59cec05  call 0x00007A44D580D600
00007a44d59cec0a  jmp 0x00007A44D59CE81F
00007a44d59cec0f  call 0x00007A44D57FF540
00007a44d59cec14  jmp 0x00007A44D59CE82A
00007a44d59cec19  call 0x00007A44D57FF430
00007a44d59cec1e  jmp 0x00007A44D59CE835
00007a44d59cec23  call 0x00007A44D580D4E0
00007a44d59cec28  jmp 0x00007A44D59CE840
00007a44d59cec2d  call 0x00007A44D580BC20
00007a44d59cec32  jmp 0x00007A44D59CE870
00007a44d59cec37  call 0x00007A44D580A9A0
00007a44d59cec3c  jmp 0x00007A44D59CE87C
00007a44d59cec41  call 0x00007A44D580E880
00007a44d59cec46  jmp 0x00007A44D59CE887
00007a44d59cec4b  call 0x00007A44D57FF540
00007a44d59cec50  jmp 0x00007A44D59CE892
00007a44d59cec55  call 0x00007A44D57FF430
00007a44d59cec5a  jmp 0x00007A44D59CE89D
00007a44d59cec5f  call 0x00007A44D580B720
00007a44d59cec64  jmp 0x00007A44D59CE8A7
00007a44d59cec69  call 0x00007A44D580D600
00007a44d59cec6e  jmp 0x00007A44D59CE8BF
00007a44d59cec73  call 0x00007A44D57FF540
00007a44d59cec78  jmp 0x00007A44D59CE8CA
00007a44d59cec7d  call 0x00007A44D57FF430
00007a44d59cec82  jmp 0x00007A44D59CE8D5
00007a44d59cec87  call 0x00007A44D58B4CB0
00007a44d59cec8c  jmp 0x00007A44D59CE8E5
00007a44d59cec91  call 0x00007A44D580E760
00007a44d59cec96  jmp 0x00007A44D59CE8F0
00007a44d59cec9b  call 0x00007A44D580D4E0
00007a44d59ceca0  jmp 0x00007A44D59CE8FB
00007a44d59ceca5  call 0x00007A44D57FF540
00007a44d59cecaa  jmp 0x00007A44D59CE908
00007a44d59cecaf  call 0x00007A44D580BC20
00007a44d59cecb4  jmp 0x00007A44D59CE930
00007a44d59cecb9  call 0x00007A44D580A9A0
00007a44d59cecbe  jmp 0x00007A44D59CE93C
00007a44d59cecc3  call 0x00007A44D580E880
00007a44d59cecc8  jmp 0x00007A44D59CE949
00007a44d59ceccd  call 0x00007A44D580D600
00007a44d59cecd2  jmp 0x00007A44D59CE956
00007a44d59cecd7  call 0x00007A44D57FF430
00007a44d59cecdc  jmp 0x00007A44D59CE961
00007a44d59cece1  call 0x00007A44D580E760
00007a44d59cece6  jmp 0x00007A44D59CE96C
00007a44d59ceceb  call 0x00007A44D580BC20
00007a44d59cecf0  jmp 0x00007A44D59CE99C
00007a44d59cecf5  call 0x00007A44D580A9A0
00007a44d59cecfa  jmp 0x00007A44D59CE9A8
00007a44d59cecff  call 0x00007A44D580BC20
00007a44d59ced04  jmp 0x00007A44D59CE9D0
00007a44d59ced09  call 0x00007A44D580A9A0
00007a44d59ced0e  jmp 0x00007A44D59CE9DC
00007a44d59ced13  call 0x00007A44D57FF540
00007a44d59ced18  jmp 0x00007A44D59CE9E9
00007a44d59ced1d  call 0x00007A44D580E880
00007a44d59ced22  jmp 0x00007A44D59CE9F6
00007a44d59ced27  call 0x00007A44D57FF430
00007a44d59ced2c  jmp 0x00007A44D59CEA01
00007a44d59ced31  call 0x00007A44D580E760
00007a44d59ced36  jmp 0x00007A44D59CEA0C
00007a44d59ced3b  call 0x00007A44D580BC20
00007a44d59ced40  jmp 0x00007A44D59CEA36
00007a44d59ced45  call 0x00007A44D580A9A0
00007a44d59ced4a  jmp 0x00007A44D59CEA42
00007a44d59ced4f  call 0x00007A44D580BAE0
00007a44d59ced54  jmp 0x00007A44D59CEA52
00007a44d59ced59  call 0x00007A44D57FF540
00007a44d59ced5e  jmp 0x00007A44D59CEA5F
00007a44d59ced63  call 0x00007A44D580E880
00007a44d59ced68  jmp 0x00007A44D59CEA6C
00007a44d59ced6d  int3
00007a44d59ced6e  nop
00007a44d59ced70  mov rax, [r15]
00007a44d59ced73  lea r14, [rax+0x20]
00007a44d59ced77  mov r12, [r13+r14*1]
00007a44d59ced7c  mov r14, [r15+0x10]
00007a44d59ced80  lea r11, [r12+r14*1]
00007a44d59ced84  mov [r15+0x40], r11
00007a44d59ced88  lea r12, [rax+0x20]
00007a44d59ced8c  mov [r13+r12*1], r11
00007a44d59ced91  test r14, r14
00007a44d59ced94  setz r14b
00007a44d59ced98  movzx r14, r14b
00007a44d59ced9c  mov [rsp+0x414], r14b
00007a44d59ceda4  cmp byte ptr [rsp+0x414], 0x00
00007a44d59cedac  jz 0x00007A44D59CEDDE
00007a44d59cedae  cmp dword ptr [r15+0x318], 0x00
00007a44d59cedb6  mov eax, 0x410934
00007a44d59cedbb  mov [r15+0x100], rax
00007a44d59cedc2  jz 0x00007A44D57FE0A0
00007a44d59cedc8  nop [rax+rax*1], eax
00007a44d59cedcd  mov eax, 0x410934
00007a44d59cedd2  mov [r15+0x100], rax
00007a44d59cedd9  jmp 0x00007A44D57FE110
00007a44d59cedde  cmp dword ptr [r15+0x318], 0x00
00007a44d59cede6  jz 0x00007A44D59CEE30
00007a44d59cedec  nop [rax+rax*1], ax
00007a44d59cedf5  nop [rax+rax*1], eax
00007a44d59cedfd  mov eax, 0x4106CC
00007a44d59cee02  mov [r15+0x100], rax
00007a44d59cee09  jmp 0x00007A44D57FE110
00007a44d59cee0e  int3
00007a44d59cee0f  call 0x00007A44D58E27E0
00007a44d59cee14  jmp 0x00007A44D59CED7C
00007a44d59cee19  call 0x00007A44D58C0860
00007a44d59cee1e  jmp 0x00007A44D59CED91
00007a44d59cee23  int3
00007a44d59cee24  nop [rax+rax*1], ax
00007a44d59cee2d  nop [rax], eax
00007a44d59cee30  mov rax, [r15+0xF8]
00007a44d59cee37  lea r14, [rax-0x150]
00007a44d59cee3e  mov [r15+0xF8], r14
00007a44d59cee45  mov rax, [r15]
00007a44d59cee48  lea r12, [rax+0x68]
00007a44d59cee4c  mov r11, [r13+r12*1]
00007a44d59cee51  mov [r15+0x88], r11
00007a44d59cee58  lea r12, [rax+0x28]
00007a44d59cee5c  mov [r15+0x40], r12
00007a44d59cee60  mov [r15+0x48], r14
00007a44d59cee64  mov qword ptr [r15+0x50], 0x420B20
00007a44d59cee6c  lea rax, [r14+0x100]
00007a44d59cee73  mov r12, [r15+0xE8]
00007a44d59cee7a  mov r11, [r15+0xD8]
00007a44d59cee81  mov [r13+rax*1], r12
00007a44d59cee86  lea rax, [r14+0x108]
00007a44d59cee8d  mov [r13+rax*1], r11
00007a44d59cee92  lea rax, [r14+0x110]
00007a44d59cee99  mov r12, [r15+0xD0]
00007a44d59ceea0  mov r11, [r15+0xC8]
00007a44d59ceea7  mov [r13+rax*1], r12
00007a44d59ceeac  lea rax, [r14+0x118]
00007a44d59ceeb3  mov [r13+rax*1], r11
00007a44d59ceeb8  lea rax, [r14+0x120]
00007a44d59ceebf  mov r12, [r15+0xC0]
00007a44d59ceec6  mov r11, [r15+0xB8]
00007a44d59ceecd  mov [r13+rax*1], r12
00007a44d59ceed2  lea rax, [r14+0x128]
00007a44d59ceed9  mov [r13+rax*1], r11
00007a44d59ceede  lea rax, [r14+0x130]
00007a44d59ceee5  mov r12, [r15+0xB0]
00007a44d59ceeec  mov r11, [r15+0xA8]
00007a44d59ceef3  mov [r13+rax*1], r12
00007a44d59ceef8  lea rax, [r14+0x138]
00007a44d59ceeff  mov [r13+rax*1], r11
00007a44d59cef04  lea rax, [r14+0x140]
00007a44d59cef0b  mov r12, [r15+0xA0]
00007a44d59cef12  mov r11, [r15+0x98]
00007a44d59cef19  mov [r13+rax*1], r12
00007a44d59cef1e  lea rax, [r14+0x148]
00007a44d59cef25  mov [r13+rax*1], r11
00007a44d59cef2a  cmp dword ptr [r15+0x318], 0x00
00007a44d59cef32  jz 0x00007A44D59CEFD0
00007a44d59cef38  nop [rax+rax*1], ax
00007a44d59cef41  nop [rax+rax*1], eax
00007a44d59cef49  mov eax, 0x410704
00007a44d59cef4e  mov [r15+0x100], rax
00007a44d59cef55  jmp 0x00007A44D57FE110
00007a44d59cef5a  int3
00007a44d59cef5b  call 0x00007A44D58C0370
00007a44d59cef60  jmp 0x00007A44D59CEE51
00007a44d59cef65  call 0x00007A44D580BC20
00007a44d59cef6a  jmp 0x00007A44D59CEE86
00007a44d59cef6f  call 0x00007A44D580A9A0
00007a44d59cef74  jmp 0x00007A44D59CEE92
00007a44d59cef79  call 0x00007A44D580BC20
00007a44d59cef7e  jmp 0x00007A44D59CEEAC
00007a44d59cef83  call 0x00007A44D580A9A0
00007a44d59cef88  jmp 0x00007A44D59CEEB8
00007a44d59cef8d  call 0x00007A44D580BC20
00007a44d59cef92  jmp 0x00007A44D59CEED2
00007a44d59cef97  call 0x00007A44D580A9A0
00007a44d59cef9c  jmp 0x00007A44D59CEEDE
00007a44d59cefa1  call 0x00007A44D580BC20
00007a44d59cefa6  jmp 0x00007A44D59CEEF8
00007a44d59cefab  call 0x00007A44D580A9A0
00007a44d59cefb0  jmp 0x00007A44D59CEF04
00007a44d59cefb5  call 0x00007A44D580BC20
00007a44d59cefba  jmp 0x00007A44D59CEF1E
00007a44d59cefbf  call 0x00007A44D580A9A0
00007a44d59cefc4  jmp 0x00007A44D59CEF2A
00007a44d59cefc9  int3
00007a44d59cefca  nop [rax+rax*1], ax
00007a44d59cefd0  mov rax, [r15+0x08]
00007a44d59cefd4  movzx r14d, byte ptr [r13+rax*1]
00007a44d59cefda  movzx r14d, r14b
00007a44d59cefde  mov [rsp+0x10], r14d
00007a44d59cefe3  mov r14d, r14d
00007a44d59cefe6  mov [r15+0x58], r14
00007a44d59cefea  lea r14, [rax+0x01]
00007a44d59cefee  mov [r15+0x08], r14
00007a44d59ceff2  mov rax, [r15+0x88]
00007a44d59ceff9  lea r14, [rax+0x01]
00007a44d59ceffd  mov r12, [r15]
00007a44d59cf000  lea r11, [r12+0x68]
00007a44d59cf005  mov [r13+r11*1], r14
00007a44d59cf00a  lea r14, [r12+rax*1]
00007a44d59cf00e  mov [r15+0x60], r14
00007a44d59cf012  lea rax, [r14+0x28]
00007a44d59cf016  mov r11d, [rsp+0x10]
00007a44d59cf01b  movzx r14d, r11b
00007a44d59cf01f  mov [r13+rax*1], r14b
00007a44d59cf024  lea rax, [r12+0x68]
00007a44d59cf029  mov r14, [r13+rax*1]
00007a44d59cf02e  mov [r15+0x88], r14
00007a44d59cf035  xor eax, eax
00007a44d59cf037  mov r12d, 0x40
00007a44d59cf03d  cmp r14, r12
00007a44d59cf040  cmc
00007a44d59cf041  lahf
00007a44d59cf042  seto al
00007a44d59cf045  mov [r15+0x108], eax
00007a44d59cf04c  mov eax, [r15+0x108]
00007a44d59cf053  sahf
00007a44d59cf054  jnz 0x00007A44D59CF086
00007a44d59cf056  cmp dword ptr [r15+0x318], 0x00
00007a44d59cf05e  jz 0x00007A44D59CF170
00007a44d59cf064  nop [rax+rax*1], ax
00007a44d59cf06d  nop [rax+rax*1], eax
00007a44d59cf075  mov eax, 0x410724
00007a44d59cf07a  mov [r15+0x100], rax
00007a44d59cf081  jmp 0x00007A44D57FE110
00007a44d59cf086  cmp dword ptr [r15+0x318], 0x00
00007a44d59cf08e  jz 0x00007A44D59CF0E0
00007a44d59cf094  nop [rax+rax*1], ax
00007a44d59cf09d  nop [rax+rax*1], eax
00007a44d59cf0a5  mov eax, 0x4106FC
00007a44d59cf0aa  mov [r15+0x100], rax
00007a44d59cf0b1  jmp 0x00007A44D57FE110
00007a44d59cf0b6  int3
00007a44d59cf0b7  call 0x00007A44D580D860
00007a44d59cf0bc  jmp 0x00007A44D59CEFDA
00007a44d59cf0c1  call 0x00007A44D58B36E0
00007a44d59cf0c6  jmp 0x00007A44D59CF00A
00007a44d59cf0cb  call 0x00007A44D580DD60
00007a44d59cf0d0  jmp 0x00007A44D59CF024
00007a44d59cf0d5  call 0x00007A44D580DC20
00007a44d59cf0da  jmp 0x00007A44D59CF02E
00007a44d59cf0df  int3
00007a44d59cf0e0  mov rax, [r15+0x10]
00007a44d59cf0e4  lea r14, [rax-0x01]
00007a44d59cf0e8  mov [r15+0x10], r14
00007a44d59cf0ec  test r14, r14
00007a44d59cf0ef  setz r14b
00007a44d59cf0f3  movzx r14, r14b
00007a44d59cf0f7  mov [rsp+0x414], r14b
00007a44d59cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007a44d59cf107  jz 0x00007A44D59CF139
00007a44d59cf109  cmp dword ptr [r15+0x318], 0x00
00007a44d59cf111  jz 0x00007A44D59D0670
00007a44d59cf117  nop [rax+rax*1], ax
00007a44d59cf120  nop [rax+rax*1], eax
00007a44d59cf128  mov eax, 0x41091C
00007a44d59cf12d  mov [r15+0x100], rax
00007a44d59cf134  jmp 0x00007A44D57FE110
00007a44d59cf139  cmp dword ptr [r15+0x318], 0x00
00007a44d59cf141  jz 0x00007A44D59CEFD0
00007a44d59cf147  nop [rax+rax*1], ax
00007a44d59cf150  nop [rax+rax*1], eax
00007a44d59cf158  mov eax, 0x410704
00007a44d59cf15d  mov [r15+0x100], rax
00007a44d59cf164  jmp 0x00007A44D57FE110
00007a44d59cf169  int3
00007a44d59cf16a  int3
00007a44d59cf16b  nop [rax+rax*1], eax
00007a44d59cf170  mov rax, [r15+0x40]
00007a44d59cf174  movzx r14d, byte ptr [r13+rax*1]
00007a44d59cf17a  movaps xmm1, [r15+0x110]
00007a44d59cf182  pinsrb xmm1, r14d, 0x00
00007a44d59cf189  lea r14, [rax+0x01]
00007a44d59cf18d  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf193  movaps xmm15, [r15+0x120]
00007a44d59cf19b  pinsrb xmm15, r12d, 0x00
00007a44d59cf1a2  lea r14, [rax+0x02]
00007a44d59cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf1ac  movaps xmm14, [r15+0x130]
00007a44d59cf1b4  pinsrb xmm14, r12d, 0x00
00007a44d59cf1bb  lea r14, [rax+0x03]
00007a44d59cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf1c5  movaps xmm13, [r15+0x140]
00007a44d59cf1cd  pinsrb xmm13, r12d, 0x00
00007a44d59cf1d4  lea r14, [rax+0x04]
00007a44d59cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf1de  pinsrb xmm1, r12d, 0x01
00007a44d59cf1e5  lea r14, [rax+0x05]
00007a44d59cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf1ef  pinsrb xmm15, r12d, 0x01
00007a44d59cf1f6  lea r14, [rax+0x06]
00007a44d59cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf200  pinsrb xmm14, r12d, 0x01
00007a44d59cf207  lea r14, [rax+0x07]
00007a44d59cf20b  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf211  pinsrb xmm13, r12d, 0x01
00007a44d59cf218  lea r14, [rax+0x08]
00007a44d59cf21c  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf222  pinsrb xmm1, r12d, 0x02
00007a44d59cf229  lea r14, [rax+0x09]
00007a44d59cf22d  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf233  pinsrb xmm15, r12d, 0x02
00007a44d59cf23a  lea r14, [rax+0x0A]
00007a44d59cf23e  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf244  pinsrb xmm14, r12d, 0x02
00007a44d59cf24b  lea r14, [rax+0x0B]
00007a44d59cf24f  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf255  pinsrb xmm13, r12d, 0x02
00007a44d59cf25c  lea r14, [rax+0x0C]
00007a44d59cf260  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf266  pinsrb xmm1, r12d, 0x03
00007a44d59cf26d  lea r14, [rax+0x0D]
00007a44d59cf271  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf277  pinsrb xmm15, r12d, 0x03
00007a44d59cf27e  lea r14, [rax+0x0E]
00007a44d59cf282  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf288  pinsrb xmm14, r12d, 0x03
00007a44d59cf28f  lea r14, [rax+0x0F]
00007a44d59cf293  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf299  pinsrb xmm13, r12d, 0x03
00007a44d59cf2a0  lea r14, [rax+0x10]
00007a44d59cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf2aa  pinsrb xmm1, r12d, 0x04
00007a44d59cf2b1  lea r14, [rax+0x11]
00007a44d59cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf2bb  pinsrb xmm15, r12d, 0x04
00007a44d59cf2c2  lea r14, [rax+0x12]
00007a44d59cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf2cc  pinsrb xmm14, r12d, 0x04
00007a44d59cf2d3  lea r14, [rax+0x13]
00007a44d59cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf2dd  pinsrb xmm13, r12d, 0x04
00007a44d59cf2e4  lea r14, [rax+0x14]
00007a44d59cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf2ee  pinsrb xmm1, r12d, 0x05
00007a44d59cf2f5  lea r14, [rax+0x15]
00007a44d59cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf2ff  pinsrb xmm15, r12d, 0x05
00007a44d59cf306  lea r14, [rax+0x16]
00007a44d59cf30a  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf310  pinsrb xmm14, r12d, 0x05
00007a44d59cf317  lea r14, [rax+0x17]
00007a44d59cf31b  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf321  pinsrb xmm13, r12d, 0x05
00007a44d59cf328  lea r14, [rax+0x18]
00007a44d59cf32c  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf332  pinsrb xmm1, r12d, 0x06
00007a44d59cf339  lea r14, [rax+0x19]
00007a44d59cf33d  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf343  pinsrb xmm15, r12d, 0x06
00007a44d59cf34a  lea r14, [rax+0x1A]
00007a44d59cf34e  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf354  pinsrb xmm14, r12d, 0x06
00007a44d59cf35b  lea r14, [rax+0x1B]
00007a44d59cf35f  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf365  pinsrb xmm13, r12d, 0x06
00007a44d59cf36c  lea r14, [rax+0x1C]
00007a44d59cf370  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf376  pinsrb xmm1, r12d, 0x07
00007a44d59cf37d  lea r14, [rax+0x1D]
00007a44d59cf381  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf387  pinsrb xmm15, r12d, 0x07
00007a44d59cf38e  lea r14, [rax+0x1E]
00007a44d59cf392  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf398  pinsrb xmm14, r12d, 0x07
00007a44d59cf39f  lea r14, [rax+0x1F]
00007a44d59cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf3a9  pinsrb xmm13, r12d, 0x07
00007a44d59cf3b0  lea r14, [rax+0x20]
00007a44d59cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf3ba  pinsrb xmm1, r12d, 0x08
00007a44d59cf3c1  lea r14, [rax+0x21]
00007a44d59cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf3cb  pinsrb xmm15, r12d, 0x08
00007a44d59cf3d2  lea r14, [rax+0x22]
00007a44d59cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf3dc  pinsrb xmm14, r12d, 0x08
00007a44d59cf3e3  lea r14, [rax+0x23]
00007a44d59cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf3ed  pinsrb xmm13, r12d, 0x08
00007a44d59cf3f4  lea r14, [rax+0x24]
00007a44d59cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf3fe  pinsrb xmm1, r12d, 0x09
00007a44d59cf405  lea r14, [rax+0x25]
00007a44d59cf409  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf40f  pinsrb xmm15, r12d, 0x09
00007a44d59cf416  lea r14, [rax+0x26]
00007a44d59cf41a  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf420  pinsrb xmm14, r12d, 0x09
00007a44d59cf427  lea r14, [rax+0x27]
00007a44d59cf42b  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf431  pinsrb xmm13, r12d, 0x09
00007a44d59cf438  lea r14, [rax+0x28]
00007a44d59cf43c  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf442  pinsrb xmm1, r12d, 0x0A
00007a44d59cf449  lea r14, [rax+0x29]
00007a44d59cf44d  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf453  pinsrb xmm15, r12d, 0x0A
00007a44d59cf45a  lea r14, [rax+0x2A]
00007a44d59cf45e  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf464  pinsrb xmm14, r12d, 0x0A
00007a44d59cf46b  lea r14, [rax+0x2B]
00007a44d59cf46f  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf475  pinsrb xmm13, r12d, 0x0A
00007a44d59cf47c  lea r14, [rax+0x2C]
00007a44d59cf480  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf486  pinsrb xmm1, r12d, 0x0B
00007a44d59cf48d  lea r14, [rax+0x2D]
00007a44d59cf491  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf497  pinsrb xmm15, r12d, 0x0B
00007a44d59cf49e  lea r14, [rax+0x2E]
00007a44d59cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf4a8  pinsrb xmm14, r12d, 0x0B
00007a44d59cf4af  lea r14, [rax+0x2F]
00007a44d59cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf4b9  pinsrb xmm13, r12d, 0x0B
00007a44d59cf4c0  lea r14, [rax+0x30]
00007a44d59cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf4ca  pinsrb xmm1, r12d, 0x0C
00007a44d59cf4d1  lea r14, [rax+0x31]
00007a44d59cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf4db  pinsrb xmm15, r12d, 0x0C
00007a44d59cf4e2  lea r14, [rax+0x32]
00007a44d59cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf4ec  pinsrb xmm14, r12d, 0x0C
00007a44d59cf4f3  lea r14, [rax+0x33]
00007a44d59cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf4fd  pinsrb xmm13, r12d, 0x0C
00007a44d59cf504  lea r14, [rax+0x34]
00007a44d59cf508  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf50e  pinsrb xmm1, r12d, 0x0D
00007a44d59cf515  lea r14, [rax+0x35]
00007a44d59cf519  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf51f  pinsrb xmm15, r12d, 0x0D
00007a44d59cf526  lea r14, [rax+0x36]
00007a44d59cf52a  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf530  pinsrb xmm14, r12d, 0x0D
00007a44d59cf537  lea r14, [rax+0x37]
00007a44d59cf53b  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf541  pinsrb xmm13, r12d, 0x0D
00007a44d59cf548  lea r14, [rax+0x38]
00007a44d59cf54c  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf552  pinsrb xmm1, r12d, 0x0E
00007a44d59cf559  lea r14, [rax+0x39]
00007a44d59cf55d  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf563  pinsrb xmm15, r12d, 0x0E
00007a44d59cf56a  lea r14, [rax+0x3A]
00007a44d59cf56e  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf574  pinsrb xmm14, r12d, 0x0E
00007a44d59cf57b  lea r14, [rax+0x3B]
00007a44d59cf57f  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf585  pinsrb xmm13, r12d, 0x0E
00007a44d59cf58c  lea r14, [rax+0x3C]
00007a44d59cf590  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf596  pinsrb xmm1, r12d, 0x0F
00007a44d59cf59d  movaps [r15+0x110], xmm1
00007a44d59cf5a5  lea r14, [rax+0x3D]
00007a44d59cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf5af  pinsrb xmm15, r12d, 0x0F
00007a44d59cf5b6  movaps [r15+0x120], xmm15
00007a44d59cf5be  lea r14, [rax+0x3E]
00007a44d59cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007a44d59cf5c8  pinsrb xmm14, r12d, 0x0F
00007a44d59cf5cf  movaps [r15+0x130], xmm14
00007a44d59cf5d7  lea r14, [rax+0x3F]
00007a44d59cf5db  movzx eax, byte ptr [r13+r14*1]
00007a44d59cf5e1  pinsrb xmm13, eax, 0x0F
00007a44d59cf5e8  movaps [r15+0x140], xmm13
00007a44d59cf5f0  movq xmm1, qword ptr [r15+0x120]
00007a44d59cf5f9  pmovzxbw xmm1, xmm1
00007a44d59cf5fe  psllw xmm1, 0x00
00007a44d59cf603  movaps [r15+0x150], xmm1
00007a44d59cf60b  movq xmm1, qword ptr [r15+0x130]
00007a44d59cf614  pmovzxbw xmm1, xmm1
00007a44d59cf619  psllw xmm1, 0x00
00007a44d59cf61e  movaps [r15+0x160], xmm1
00007a44d59cf626  movq xmm1, qword ptr [r15+0x110]
00007a44d59cf62f  pmovzxbw xmm1, xmm1
00007a44d59cf634  psllw xmm1, 0x00
00007a44d59cf639  movaps [r15+0x170], xmm1
00007a44d59cf641  movaps xmm15, [r15+0x110]
00007a44d59cf649  pextrq rax, xmm15, 0x01
00007a44d59cf650  movq xmm15, rax
00007a44d59cf655  pmovzxbw xmm15, xmm15
00007a44d59cf65b  psllw xmm15, 0x00
00007a44d59cf661  movaps [r15+0x180], xmm15
00007a44d59cf669  movaps xmm14, [r15+0x120]
00007a44d59cf671  pextrq rax, xmm14, 0x01
00007a44d59cf678  movq xmm14, rax
00007a44d59cf67d  pmovzxbw xmm14, xmm14
00007a44d59cf683  psllw xmm14, 0x00
00007a44d59cf689  movaps [r15+0x210], xmm14
00007a44d59cf691  movaps xmm13, [r15+0x130]
00007a44d59cf699  pextrq rax, xmm13, 0x01
00007a44d59cf6a0  movq xmm13, rax
00007a44d59cf6a5  pmovzxbw xmm13, xmm13
00007a44d59cf6ab  psllw xmm13, 0x00
00007a44d59cf6b1  movaps [r15+0x220], xmm13
00007a44d59cf6b9  movq xmm12, qword ptr [r15+0x140]
00007a44d59cf6c2  pmovzxbw xmm12, xmm12
00007a44d59cf6c8  psllw xmm12, 0x00
00007a44d59cf6ce  movaps [r15+0x250], xmm12
00007a44d59cf6d6  movaps xmm12, [r15+0x140]
00007a44d59cf6de  pextrq rax, xmm12, 0x01
00007a44d59cf6e5  movq xmm12, rax
00007a44d59cf6ea  pmovzxbw xmm12, xmm12
00007a44d59cf6f0  psllw xmm12, 0x00
00007a44d59cf6f6  movaps [r15+0x110], xmm12
00007a44d59cf6fe  movq xmm11, qword ptr [r15+0x150]
00007a44d59cf707  pmovzxwd xmm11, xmm11
00007a44d59cf70d  pslld xmm11, 0x10
00007a44d59cf713  movq xmm10, qword ptr [r15+0x160]
00007a44d59cf71c  pmovzxwd xmm10, xmm10
00007a44d59cf722  pslld xmm10, 0x08
00007a44d59cf728  pextrq rax, xmm1, 0x01
00007a44d59cf72f  movq xmm1, rax
00007a44d59cf734  pmovzxwd xmm1, xmm1
00007a44d59cf739  pslld xmm1, 0x00
00007a44d59cf73e  movaps [r15+0x260], xmm1
00007a44d59cf746  pextrq rax, xmm15, 0x01
00007a44d59cf74d  movq xmm15, rax
00007a44d59cf752  pmovzxwd xmm15, xmm15
00007a44d59cf758  pslld xmm15, 0x00
00007a44d59cf75e  movaps [r15+0x270], xmm15
00007a44d59cf766  movq xmm9, qword ptr [r15+0x170]
00007a44d59cf76f  pmovzxwd xmm9, xmm9
00007a44d59cf775  pslld xmm9, 0x00
00007a44d59cf77b  pextrq rax, xmm14, 0x01
00007a44d59cf782  movq xmm14, rax
00007a44d59cf787  pmovzxwd xmm14, xmm14
00007a44d59cf78d  pslld xmm14, 0x10
00007a44d59cf793  movaps [r15+0x280], xmm14
00007a44d59cf79b  movq xmm8, qword ptr [r15+0x180]
00007a44d59cf7a4  pmovzxwd xmm8, xmm8
00007a44d59cf7aa  pslld xmm8, 0x00
00007a44d59cf7b0  movq xmm7, qword ptr [r15+0x210]
00007a44d59cf7b9  pmovzxwd xmm7, xmm7
00007a44d59cf7be  pslld xmm7, 0x10
00007a44d59cf7c3  movaps xmm6, [r15+0x150]
00007a44d59cf7cb  pextrq rax, xmm6, 0x01
00007a44d59cf7d2  movq xmm6, rax
00007a44d59cf7d7  pmovzxwd xmm6, xmm6
00007a44d59cf7dc  pslld xmm6, 0x10
00007a44d59cf7e1  por xmm11, xmm10
00007a44d59cf7e6  movaps [r15+0x230], xmm11
00007a44d59cf7ee  pextrq rax, xmm13, 0x01
00007a44d59cf7f5  movq xmm13, rax
00007a44d59cf7fa  pmovzxwd xmm13, xmm13
00007a44d59cf800  pslld xmm13, 0x08
00007a44d59cf806  movaps [r15+0x240], xmm13
00007a44d59cf80e  movq xmm10, qword ptr [r15+0x220]
00007a44d59cf817  pmovzxwd xmm10, xmm10
00007a44d59cf81d  pslld xmm10, 0x08
00007a44d59cf823  movaps xmm5, [r15+0x160]
00007a44d59cf82b  pextrq rax, xmm5, 0x01
00007a44d59cf832  movq xmm5, rax
00007a44d59cf837  pmovzxwd xmm5, xmm5
00007a44d59cf83c  pslld xmm5, 0x08
00007a44d59cf841  pslld xmm9, 0x18
00007a44d59cf847  pslld xmm15, 0x18
00007a44d59cf84d  pslld xmm8, 0x18
00007a44d59cf853  movq xmm4, qword ptr [r15+0x250]
00007a44d59cf85c  pmovzxwd xmm4, xmm4
00007a44d59cf861  pslld xmm4, 0x00
00007a44d59cf866  por xmm14, xmm13
00007a44d59cf86b  por xmm7, xmm10
00007a44d59cf870  movaps [r15+0x210], xmm7
00007a44d59cf878  pslld xmm1, 0x18
00007a44d59cf87d  movaps [r15+0x220], xmm1
00007a44d59cf885  por xmm6, xmm5
00007a44d59cf889  por xmm11, xmm9
00007a44d59cf88e  movaps [r15+0x160], xmm11
00007a44d59cf896  pextrq rax, xmm12, 0x01
00007a44d59cf89d  movq xmm13, rax
00007a44d59cf8a2  pmovzxwd xmm13, xmm13
00007a44d59cf8a8  pslld xmm13, 0x00
00007a44d59cf8ae  movaps [r15+0x170], xmm13
00007a44d59cf8b6  movq xmm12, qword ptr [r15+0x110]
00007a44d59cf8bf  pmovzxwd xmm12, xmm12
00007a44d59cf8c5  pslld xmm12, 0x00
00007a44d59cf8cb  por xmm14, xmm15
00007a44d59cf8d0  por xmm7, xmm8
00007a44d59cf8d5  movaps xmm15, [r15+0x250]
00007a44d59cf8dd  pextrq rax, xmm15, 0x01
00007a44d59cf8e4  movq xmm15, rax
00007a44d59cf8e9  pmovzxwd xmm15, xmm15
00007a44d59cf8ef  pslld xmm15, 0x00
00007a44d59cf8f5  movaps [r15+0x180], xmm15
00007a44d59cf8fd  por xmm6, xmm1
00007a44d59cf901  movaps [r15+0x150], xmm6
00007a44d59cf909  por xmm11, xmm4
00007a44d59cf90e  movaps [r15+0x140], xmm11
00007a44d59cf916  por xmm7, xmm12
00007a44d59cf91b  movaps [r15+0x110], xmm7
00007a44d59cf923  por xmm14, xmm13
00007a44d59cf928  movaps [r15+0x120], xmm14
00007a44d59cf930  por xmm6, xmm15
00007a44d59cf935  movaps [r15+0x130], xmm6
00007a44d59cf93d  mov rax, [r15+0xF8]
00007a44d59cf944  lea r14, [rax+0x20]
00007a44d59cf948  movups [r13+r14*1], xmm7
00007a44d59cf94e  lea r14, [rax+0x30]
00007a44d59cf952  movups [r13+r14*1], xmm14
00007a44d59cf958  movups [r13+rax*1], xmm11
00007a44d59cf95e  lea r14, [rax+0x10]
00007a44d59cf962  movups [r13+r14*1], xmm6
00007a44d59cf968  mov r14d, [r13+rax*1]
00007a44d59cf96d  mov rax, [r15+0x48]
00007a44d59cf971  mov [r15+0x68], rax
00007a44d59cf975  mov qword ptr [r15+0x58], 0x04
00007a44d59cf97d  lea r12, [rax+0x04]
00007a44d59cf981  mov r11d, [r13+r12*1]
00007a44d59cf986  mov [rsp+0x10], r11d
00007a44d59cf98b  mov r11d, r11d
00007a44d59cf98e  mov [r15+0x70], r11
00007a44d59cf992  lea r12, [rax+0x38]
00007a44d59cf996  mov r11d, [r13+r12*1]
00007a44d59cf99b  lea r12, [rax+0x24]
00007a44d59cf99f  mov r10d, [r13+r12*1]
00007a44d59cf9a4  mov [rsp+0x20], r10d
00007a44d59cf9a9  mov r10d, r10d
00007a44d59cf9ac  mov [r15+0x90], r10
00007a44d59cf9b3  mov [rsp+0x30], rax
00007a44d59cf9b8  xor eax, eax
00007a44d59cf9ba  mov r12d, 0x04
00007a44d59cf9c0  mov r10d, 0xC0
00007a44d59cf9c6  cmp r12, r10
00007a44d59cf9c9  cmc
00007a44d59cf9ca  lahf
00007a44d59cf9cb  seto al
00007a44d59cf9ce  mov [r15+0x108], eax
00007a44d59cf9d5  mov eax, [rsp+0x10]
00007a44d59cf9d9  mov r12d, [rsp+0x10]
00007a44d59cf9de  shrd eax, r12d, 0x07
00007a44d59cf9e3  mov [rsp+0x10], r11d
00007a44d59cf9e8  mov r10d, [rsp+0x10]
00007a44d59cf9ed  shrd r11d, r10d, 0x11
00007a44d59cf9f2  mov r9d, [rsp+0x20]
00007a44d59cf9f7  lea r8d, [r9d+r14d*1]
00007a44d59cf9fc  rorx r14d, r12d, 0x12
00007a44d59cfa02  xor eax, r14d
00007a44d59cfa05  rorx r14d, r10d, 0x13
00007a44d59cfa0b  xor r11d, r14d
00007a44d59cfa0e  mov [rsp+0x10], r11d
00007a44d59cfa13  mov r11d, r11d
00007a44d59cfa16  mov [r15+0x88], r11
00007a44d59cfa1d  mov [rsp+0x20], r12d
00007a44d59cfa22  shr r12d, 0x03
00007a44d59cfa26  xor eax, r12d
00007a44d59cfa29  mov [rsp+0x40], eax
00007a44d59cfa2d  mov eax, eax
00007a44d59cfa2f  mov [r15+0x80], rax
00007a44d59cfa36  shr r10d, 0x0A
00007a44d59cfa3a  mov eax, [rsp+0x10]
00007a44d59cfa3e  xor eax, r10d
00007a44d59cfa41  mov [rsp+0x10], eax
00007a44d59cfa45  mov eax, eax
00007a44d59cfa47  mov [r15+0x78], rax
00007a44d59cfa4b  mov eax, [rsp+0x40]
00007a44d59cfa4f  lea r14d, [r8d+eax*1]
00007a44d59cfa54  mov eax, [rsp+0x10]
00007a44d59cfa58  lea r12d, [r14d+eax*1]
00007a44d59cfa5d  mov rax, [rsp+0x30]
00007a44d59cfa62  lea r14, [rax+0x40]
00007a44d59cfa66  mov [r13+r14*1], r12d
00007a44d59cfa6b  mov eax, [rsp+0x20]
00007a44d59cfa6f  mov eax, eax
00007a44d59cfa71  mov [r15+0x60], rax
00007a44d59cfa75  mov eax, [r15+0x108]
00007a44d59cfa7c  sahf
00007a44d59cfa7d  jnz 0x00007A44D59CFAAF
00007a44d59cfa7f  cmp dword ptr [r15+0x318], 0x00
00007a44d59cfa87  jz 0x00007A44D59CFF70
00007a44d59cfa8d  nop [rax+rax*1], ax
00007a44d59cfa96  nop [rax+rax*1], eax
00007a44d59cfa9e  mov eax, 0x410820
00007a44d59cfaa3  mov [r15+0x100], rax
00007a44d59cfaaa  jmp 0x00007A44D57FE110
00007a44d59cfaaf  cmp dword ptr [r15+0x318], 0x00
00007a44d59cfab7  jz 0x00007A44D59CFDC0
00007a44d59cfabd  nop [rax+rax*1], ax
00007a44d59cfac6  nop [rax+rax*1], eax
00007a44d59cface  mov eax, 0x4107D8
00007a44d59cfad3  mov [r15+0x100], rax
00007a44d59cfada  jmp 0x00007A44D57FE110
00007a44d59cfadf  int3
00007a44d59cfae0  call 0x00007A44D580D860
00007a44d59cfae5  jmp 0x00007A44D59CF17A
00007a44d59cfaea  call 0x00007A44D58E2420
00007a44d59cfaef  jmp 0x00007A44D59CF193
00007a44d59cfaf4  call 0x00007A44D58E2420
00007a44d59cfaf9  jmp 0x00007A44D59CF1AC
00007a44d59cfafe  call 0x00007A44D58E2420
00007a44d59cfb03  jmp 0x00007A44D59CF1C5
00007a44d59cfb08  call 0x00007A44D58E2420
00007a44d59cfb0d  jmp 0x00007A44D59CF1DE
00007a44d59cfb12  call 0x00007A44D58E2420
00007a44d59cfb17  jmp 0x00007A44D59CF1EF
00007a44d59cfb1c  call 0x00007A44D58E2420
00007a44d59cfb21  jmp 0x00007A44D59CF200
00007a44d59cfb26  call 0x00007A44D58E2420
00007a44d59cfb2b  jmp 0x00007A44D59CF211
00007a44d59cfb30  call 0x00007A44D58E2420
00007a44d59cfb35  jmp 0x00007A44D59CF222
00007a44d59cfb3a  call 0x00007A44D58E2420
00007a44d59cfb3f  jmp 0x00007A44D59CF233
00007a44d59cfb44  call 0x00007A44D58E2420
00007a44d59cfb49  jmp 0x00007A44D59CF244
00007a44d59cfb4e  call 0x00007A44D58E2420
00007a44d59cfb53  jmp 0x00007A44D59CF255
00007a44d59cfb58  call 0x00007A44D58E2420
00007a44d59cfb5d  jmp 0x00007A44D59CF266
00007a44d59cfb62  call 0x00007A44D58E2420
00007a44d59cfb67  jmp 0x00007A44D59CF277
00007a44d59cfb6c  call 0x00007A44D58E2420
00007a44d59cfb71  jmp 0x00007A44D59CF288
00007a44d59cfb76  call 0x00007A44D58E2420
00007a44d59cfb7b  jmp 0x00007A44D59CF299
00007a44d59cfb80  call 0x00007A44D58E2420
00007a44d59cfb85  jmp 0x00007A44D59CF2AA
00007a44d59cfb8a  call 0x00007A44D58E2420
00007a44d59cfb8f  jmp 0x00007A44D59CF2BB
00007a44d59cfb94  call 0x00007A44D58E2420
00007a44d59cfb99  jmp 0x00007A44D59CF2CC
00007a44d59cfb9e  call 0x00007A44D58E2420
00007a44d59cfba3  jmp 0x00007A44D59CF2DD
00007a44d59cfba8  call 0x00007A44D58E2420
00007a44d59cfbad  jmp 0x00007A44D59CF2EE
00007a44d59cfbb2  call 0x00007A44D58E2420
00007a44d59cfbb7  jmp 0x00007A44D59CF2FF
00007a44d59cfbbc  call 0x00007A44D58E2420
00007a44d59cfbc1  jmp 0x00007A44D59CF310
00007a44d59cfbc6  call 0x00007A44D58E2420
00007a44d59cfbcb  jmp 0x00007A44D59CF321
00007a44d59cfbd0  call 0x00007A44D58E2420
00007a44d59cfbd5  jmp 0x00007A44D59CF332
00007a44d59cfbda  call 0x00007A44D58E2420
00007a44d59cfbdf  jmp 0x00007A44D59CF343
00007a44d59cfbe4  call 0x00007A44D58E2420
00007a44d59cfbe9  jmp 0x00007A44D59CF354
00007a44d59cfbee  call 0x00007A44D58E2420
00007a44d59cfbf3  jmp 0x00007A44D59CF365
00007a44d59cfbf8  call 0x00007A44D58E2420
00007a44d59cfbfd  jmp 0x00007A44D59CF376
00007a44d59cfc02  call 0x00007A44D58E2420
00007a44d59cfc07  jmp 0x00007A44D59CF387
00007a44d59cfc0c  call 0x00007A44D58E2420
00007a44d59cfc11  jmp 0x00007A44D59CF398
00007a44d59cfc16  call 0x00007A44D58E2420
00007a44d59cfc1b  jmp 0x00007A44D59CF3A9
00007a44d59cfc20  call 0x00007A44D58E2420
00007a44d59cfc25  jmp 0x00007A44D59CF3BA
00007a44d59cfc2a  call 0x00007A44D58E2420
00007a44d59cfc2f  jmp 0x00007A44D59CF3CB
00007a44d59cfc34  call 0x00007A44D58E2420
00007a44d59cfc39  jmp 0x00007A44D59CF3DC
00007a44d59cfc3e  call 0x00007A44D58E2420
00007a44d59cfc43  jmp 0x00007A44D59CF3ED
00007a44d59cfc48  call 0x00007A44D58E2420
00007a44d59cfc4d  jmp 0x00007A44D59CF3FE
00007a44d59cfc52  call 0x00007A44D58E2420
00007a44d59cfc57  jmp 0x00007A44D59CF40F
00007a44d59cfc5c  call 0x00007A44D58E2420
00007a44d59cfc61  jmp 0x00007A44D59CF420
00007a44d59cfc66  call 0x00007A44D58E2420
00007a44d59cfc6b  jmp 0x00007A44D59CF431
00007a44d59cfc70  call 0x00007A44D58E2420
00007a44d59cfc75  jmp 0x00007A44D59CF442
00007a44d59cfc7a  call 0x00007A44D58E2420
00007a44d59cfc7f  jmp 0x00007A44D59CF453
00007a44d59cfc84  call 0x00007A44D58E2420
00007a44d59cfc89  jmp 0x00007A44D59CF464
00007a44d59cfc8e  call 0x00007A44D58E2420
00007a44d59cfc93  jmp 0x00007A44D59CF475
00007a44d59cfc98  call 0x00007A44D58E2420
00007a44d59cfc9d  jmp 0x00007A44D59CF486
00007a44d59cfca2  call 0x00007A44D58E2420
00007a44d59cfca7  jmp 0x00007A44D59CF497
00007a44d59cfcac  call 0x00007A44D58E2420
00007a44d59cfcb1  jmp 0x00007A44D59CF4A8
00007a44d59cfcb6  call 0x00007A44D58E2420
00007a44d59cfcbb  jmp 0x00007A44D59CF4B9
00007a44d59cfcc0  call 0x00007A44D58E2420
00007a44d59cfcc5  jmp 0x00007A44D59CF4CA
00007a44d59cfcca  call 0x00007A44D58E2420
00007a44d59cfccf  jmp 0x00007A44D59CF4DB
00007a44d59cfcd4  call 0x00007A44D58E2420
00007a44d59cfcd9  jmp 0x00007A44D59CF4EC
00007a44d59cfcde  call 0x00007A44D58E2420
00007a44d59cfce3  jmp 0x00007A44D59CF4FD
00007a44d59cfce8  call 0x00007A44D58E2420
00007a44d59cfced  jmp 0x00007A44D59CF50E
00007a44d59cfcf2  call 0x00007A44D58E2420
00007a44d59cfcf7  jmp 0x00007A44D59CF51F
00007a44d59cfcfc  call 0x00007A44D58E2420
00007a44d59cfd01  jmp 0x00007A44D59CF530
00007a44d59cfd06  call 0x00007A44D58E2420
00007a44d59cfd0b  jmp 0x00007A44D59CF541
00007a44d59cfd10  call 0x00007A44D58E2420
00007a44d59cfd15  jmp 0x00007A44D59CF552
00007a44d59cfd1a  call 0x00007A44D58E2420
00007a44d59cfd1f  jmp 0x00007A44D59CF563
00007a44d59cfd24  call 0x00007A44D58E2420
00007a44d59cfd29  jmp 0x00007A44D59CF574
00007a44d59cfd2e  call 0x00007A44D58E2420
00007a44d59cfd33  jmp 0x00007A44D59CF585
00007a44d59cfd38  call 0x00007A44D58E2420
00007a44d59cfd3d  jmp 0x00007A44D59CF596
00007a44d59cfd42  call 0x00007A44D58E2420
00007a44d59cfd47  jmp 0x00007A44D59CF5AF
00007a44d59cfd4c  call 0x00007A44D58E2420
00007a44d59cfd51  jmp 0x00007A44D59CF5C8
00007a44d59cfd56  call 0x00007A44D58D5610
00007a44d59cfd5b  jmp 0x00007A44D59CF5E1
00007a44d59cfd60  call 0x00007A44D58DC580
00007a44d59cfd65  jmp 0x00007A44D59CF94E
00007a44d59cfd6a  call 0x00007A44D58E46C0
00007a44d59cfd6f  jmp 0x00007A44D59CF958
00007a44d59cfd74  call 0x00007A44D5809E90
00007a44d59cfd79  jmp 0x00007A44D59CF95E
00007a44d59cfd7e  call 0x00007A44D58DB310
00007a44d59cfd83  jmp 0x00007A44D59CF968
00007a44d59cfd88  call 0x00007A44D580DAE0
00007a44d59cfd8d  jmp 0x00007A44D59CF96D
00007a44d59cfd92  call 0x00007A44D58C0230
00007a44d59cfd97  jmp 0x00007A44D59CF986
00007a44d59cfd9c  call 0x00007A44D58C0230
00007a44d59cfda1  jmp 0x00007A44D59CF99B
00007a44d59cfda6  call 0x00007A44D58BEFC0
00007a44d59cfdab  jmp 0x00007A44D59CF9A4
00007a44d59cfdb0  call 0x00007A44D58E2BA0
00007a44d59cfdb5  jmp 0x00007A44D59CFA6B
00007a44d59cfdba  int3
00007a44d59cfdbb  nop [rax+rax*1], eax
00007a44d59cfdc0  mov rax, [r15+0x48]
00007a44d59cfdc4  mov r14, [r15+0x58]
00007a44d59cfdc8  lea r12, [rax+r14*1]
00007a44d59cfdcc  mov [r15+0x68], r12
00007a44d59cfdd0  lea rax, [r14+0x04]
00007a44d59cfdd4  mov [r15+0x58], rax
00007a44d59cfdd8  lea r14, [r12+0x04]
00007a44d59cfddd  mov r11d, [r13+r14*1]
00007a44d59cfde2  mov [rsp+0x10], r11d
00007a44d59cfde7  mov r11d, r11d
00007a44d59cfdea  mov [r15+0x70], r11
00007a44d59cfdee  lea r14, [r12+0x38]
00007a44d59cfdf3  mov r11d, [r13+r14*1]
00007a44d59cfdf8  lea r14, [r12+0x24]
00007a44d59cfdfd  mov r10d, [r13+r14*1]
00007a44d59cfe02  mov [rsp+0x20], r10d
00007a44d59cfe07  mov r10d, r10d
00007a44d59cfe0a  mov [r15+0x90], r10
00007a44d59cfe11  mov [rsp+0x30], rax
00007a44d59cfe16  xor eax, eax
00007a44d59cfe18  mov r14, [rsp+0x30]
00007a44d59cfe1d  mov r10d, 0xC0
00007a44d59cfe23  cmp r14, r10
00007a44d59cfe26  cmc
00007a44d59cfe27  lahf
00007a44d59cfe28  seto al
00007a44d59cfe2b  mov [r15+0x108], eax
00007a44d59cfe32  mov eax, [rsp+0x10]
00007a44d59cfe36  mov r14d, [rsp+0x10]
00007a44d59cfe3b  shrd eax, r14d, 0x07
00007a44d59cfe40  mov [rsp+0x10], r11d
00007a44d59cfe45  mov r10d, [rsp+0x10]
00007a44d59cfe4a  shrd r11d, r10d, 0x11
00007a44d59cfe4f  mov r9d, [r15+0x60]
00007a44d59cfe53  mov r8d, [rsp+0x20]
00007a44d59cfe58  lea ebp, [r8d+r9d*1]
00007a44d59cfe5d  rorx r9d, r14d, 0x12
00007a44d59cfe63  xor eax, r9d
00007a44d59cfe66  rorx r9d, r10d, 0x13
00007a44d59cfe6c  xor r11d, r9d
00007a44d59cfe6f  mov [rsp+0x10], r11d
00007a44d59cfe74  mov r11d, r11d
00007a44d59cfe77  mov [r15+0x88], r11
00007a44d59cfe7e  mov [rsp+0x20], r14d
00007a44d59cfe83  shr r14d, 0x03
00007a44d59cfe87  xor eax, r14d
00007a44d59cfe8a  mov [rsp+0x30], eax
00007a44d59cfe8e  mov eax, eax
00007a44d59cfe90  mov [r15+0x80], rax
00007a44d59cfe97  shr r10d, 0x0A
00007a44d59cfe9b  mov eax, [rsp+0x10]
00007a44d59cfe9f  xor eax, r10d
00007a44d59cfea2  mov [rsp+0x10], eax
00007a44d59cfea6  mov eax, eax
00007a44d59cfea8  mov [r15+0x78], rax
00007a44d59cfeac  mov eax, [rsp+0x30]
00007a44d59cfeb0  lea r14d, [ebp+eax*1]
00007a44d59cfeb6  mov eax, [rsp+0x10]
00007a44d59cfeba  lea r11d, [r14d+eax*1]
00007a44d59cfebf  lea rax, [r12+0x40]
00007a44d59cfec4  mov [r13+rax*1], r11d
00007a44d59cfec9  mov eax, [rsp+0x20]
00007a44d59cfecd  mov eax, eax
00007a44d59cfecf  mov [r15+0x60], rax
00007a44d59cfed3  mov eax, [r15+0x108]
00007a44d59cfeda  sahf
00007a44d59cfedb  jnz 0x00007A44D59CFF0D
00007a44d59cfedd  cmp dword ptr [r15+0x318], 0x00
00007a44d59cfee5  jz 0x00007A44D59CFF70
00007a44d59cfeeb  nop [rax+rax*1], ax
00007a44d59cfef4  nop [rax+rax*1], eax
00007a44d59cfefc  mov eax, 0x410820
00007a44d59cff01  mov [r15+0x100], rax
00007a44d59cff08  jmp 0x00007A44D57FE110
00007a44d59cff0d  cmp dword ptr [r15+0x318], 0x00
00007a44d59cff15  jz 0x00007A44D59CFDC0
00007a44d59cff1b  nop [rax+rax*1], ax
00007a44d59cff24  nop [rax+rax*1], eax
00007a44d59cff2c  mov eax, 0x4107D8
00007a44d59cff31  mov [r15+0x100], rax
00007a44d59cff38  jmp 0x00007A44D57FE110
00007a44d59cff3d  int3
00007a44d59cff3e  call 0x00007A44D58E1430
00007a44d59cff43  jmp 0x00007A44D59CFDE2
00007a44d59cff48  call 0x00007A44D58E1430
00007a44d59cff4d  jmp 0x00007A44D59CFDF8
00007a44d59cff52  call 0x00007A44D58E01C0
00007a44d59cff57  jmp 0x00007A44D59CFE02
00007a44d59cff5c  call 0x00007A44D580A860
00007a44d59cff61  jmp 0x00007A44D59CFEC9
00007a44d59cff66  int3
00007a44d59cff67  nop [rax+rax*1], ax
00007a44d59cff70  mov rax, [r15]
00007a44d59cff73  mov r14d, [r13+rax*1]
00007a44d59cff78  lea r12, [rax+0x04]
00007a44d59cff7c  mov r11d, [r13+r12*1]
00007a44d59cff81  mov [rsp+0x10], r14d
00007a44d59cff86  mov r14d, r14d
00007a44d59cff89  mov [r15+0x78], r14
00007a44d59cff8d  mov [rsp+0x20], r11d
00007a44d59cff92  mov r11d, r11d
00007a44d59cff95  mov [r15+0x80], r11
00007a44d59cff9c  lea r14, [rax+0x08]
00007a44d59cffa0  mov r12d, [r13+r14*1]
00007a44d59cffa5  lea r14, [rax+0x0C]
00007a44d59cffa9  mov r11d, [r13+r14*1]
00007a44d59cffae  mov [rsp+0x30], r12d
00007a44d59cffb3  mov r12d, r12d
00007a44d59cffb6  mov [r15+0x70], r12
00007a44d59cffba  mov [rsp+0x40], r11d
00007a44d59cffbf  mov r11d, r11d
00007a44d59cffc2  mov [r15+0x68], r11
00007a44d59cffc6  lea r14, [rax+0x18]
00007a44d59cffca  mov r12d, [r13+r14*1]
00007a44d59cffcf  lea r14, [rax+0x1C]
00007a44d59cffd3  mov r11d, [r13+r14*1]
00007a44d59cffd8  mov [rsp+0x50], r12d
00007a44d59cffdd  mov r12d, r12d
00007a44d59cffe0  mov [r15+0x58], r12
00007a44d59cffe4  mov [rsp+0x60], r11d
00007a44d59cffe9  mov r11d, r11d
00007a44d59cffec  mov [r15+0x60], r11
00007a44d59cfff0  lea r14, [rax+0x10]
00007a44d59cfff4  mov r12d, [r13+r14*1]
00007a44d59cfff9  lea r14, [rax+0x14]
00007a44d59cfffd  mov eax, [r13+r14*1]
00007a44d59d0002  mov [rsp+0x70], r12d
00007a44d59d0007  mov r12d, r12d
00007a44d59d000a  mov [r15+0x18], r12
00007a44d59d000e  mov [rsp+0x80], eax
00007a44d59d0015  mov eax, eax
00007a44d59d0017  mov [r15+0x90], rax
00007a44d59d001e  mov eax, [rsp+0x70]
00007a44d59d0022  mov eax, eax
00007a44d59d0024  mov [r15+0x30], rax
00007a44d59d0028  mov eax, [rsp+0x50]
00007a44d59d002c  mov eax, eax
00007a44d59d002e  mov [r15+0xA0], rax
00007a44d59d0035  mov eax, [rsp+0x30]
00007a44d59d0039  mov eax, eax
00007a44d59d003b  mov [r15+0x28], rax
00007a44d59d003f  mov eax, [rsp+0x20]
00007a44d59d0043  mov eax, eax
00007a44d59d0045  mov [r15+0x98], rax
00007a44d59d004c  mov eax, [rsp+0x10]
00007a44d59d0050  mov eax, eax
00007a44d59d0052  mov [r15+0x38], rax
00007a44d59d0056  mov eax, [rsp+0x70]
00007a44d59d005a  mov r14d, [rsp+0x70]
00007a44d59d005f  shrd eax, r14d, 0x06
00007a44d59d0064  mov [rsp+0x70], r14d
00007a44d59d0069  mov r12d, [rsp+0x80]
00007a44d59d0071  and r14d, r12d
00007a44d59d0074  mov r11d, [rsp+0x10]
00007a44d59d0079  mov r10d, [rsp+0x10]
00007a44d59d007e  shrd r11d, r10d, 0x02
00007a44d59d0083  mov [rsp+0x10], r12d
00007a44d59d0088  mov r12d, r12d
00007a44d59d008b  mov [r15+0x20], r12
00007a44d59d008f  mov r12, [r15+0x50]
00007a44d59d0093  mov r9d, [r13+r12*1]
00007a44d59d0098  mov r12d, [rsp+0x50]
00007a44d59d009d  mov r8d, [rsp+0x70]
00007a44d59d00a2  andn ebp, r8d, r12d
00007a44d59d00a7  mov edi, [rsp+0x60]
00007a44d59d00ab  lea esi, [r14d+edi*1]
00007a44d59d00b0  rorx r14d, r8d, 0x0B
00007a44d59d00b6  xor eax, r14d
00007a44d59d00b9  rorx r14d, r10d, 0x0D
00007a44d59d00bf  xor r11d, r14d
00007a44d59d00c2  lea edi, [esi+ebp*1]
00007a44d59d00c6  mov r14, [r15+0x48]
00007a44d59d00ca  mov ebp, [r13+r14*1]
00007a44d59d00cf  mov r14d, [rsp+0x30]
00007a44d59d00d4  mov esi, [rsp+0x20]
00007a44d59d00d8  and r14d, esi
00007a44d59d00db  mov [rsp+0x20], r14d
00007a44d59d00e0  mov r14d, r14d
00007a44d59d00e3  mov [r15+0xD8], r14
00007a44d59d00ea  lea r14d, [edi+r9d*1]
00007a44d59d00ef  mov r9d, [rsp+0x30]
00007a44d59d00f4  xor r9d, esi
00007a44d59d00f7  rorx edi, r8d, 0x19
00007a44d59d00fd  xor eax, edi
00007a44d59d00ff  and r9d, r10d
00007a44d59d0102  rorx edi, r10d, 0x16
00007a44d59d0108  xor r11d, edi
00007a44d59d010b  mov [rsp+0x30], r11d
00007a44d59d0110  mov r11d, r11d
00007a44d59d0113  mov [r15+0xD0], r11
00007a44d59d011a  lea r11d, [r14d+ebp*1]
00007a44d59d011f  mov r10d, [rsp+0x20]
00007a44d59d0124  xor r9d, r10d
00007a44d59d0127  lea r14d, [r11d+eax*1]
00007a44d59d012c  mov qword ptr [r15+0x88], 0x04
00007a44d59d0137  mov eax, [rsp+0x30]
00007a44d59d013b  lea r11d, [r9d+eax*1]
00007a44d59d0140  mov eax, [rsp+0x40]
00007a44d59d0144  lea r10d, [r14d+eax*1]
00007a44d59d0149  mov r10d, r10d
00007a44d59d014c  mov [r15+0xB8], r10
00007a44d59d0153  xor eax, eax
00007a44d59d0155  mov r10d, 0x04
00007a44d59d015b  mov r9d, 0x100
00007a44d59d0161  cmp r10, r9
00007a44d59d0164  cmc
00007a44d59d0165  lahf
00007a44d59d0166  seto al
00007a44d59d0169  mov [r15+0x108], eax
00007a44d59d0170  lea eax, [r11d+r14d*1]
00007a44d59d0175  mov eax, eax
00007a44d59d0177  mov [r15+0xA8], rax
00007a44d59d017e  mov r12d, r12d
00007a44d59d0181  mov [r15+0xB0], r12
00007a44d59d0188  mov eax, [rsp+0x10]
00007a44d59d018c  mov eax, eax
00007a44d59d018e  mov [r15+0xC0], rax
00007a44d59d0195  mov r8d, r8d
00007a44d59d0198  mov [r15+0xC8], r8
00007a44d59d019f  mov eax, [r15+0x108]
00007a44d59d01a6  sahf
00007a44d59d01a7  jnz 0x00007A44D59D01D9
00007a44d59d01a9  cmp dword ptr [r15+0x318], 0x00
00007a44d59d01b1  jz 0x00007A44D59D04A0
00007a44d59d01b7  nop [rax+rax*1], ax
00007a44d59d01c0  nop [rax+rax*1], eax
00007a44d59d01c8  mov eax, 0x4108E0
00007a44d59d01cd  mov [r15+0x100], rax
00007a44d59d01d4  jmp 0x00007A44D57FE110
00007a44d59d01d9  cmp dword ptr [r15+0x318], 0x00
00007a44d59d01e1  jz 0x00007A44D59D0270
00007a44d59d01e7  nop [rax+rax*1], ax
00007a44d59d01f0  nop [rax+rax*1], eax
00007a44d59d01f8  mov eax, 0x410854
00007a44d59d01fd  mov [r15+0x100], rax
00007a44d59d0204  jmp 0x00007A44D57FE110
00007a44d59d0209  int3
00007a44d59d020a  call 0x00007A44D580DAE0
00007a44d59d020f  jmp 0x00007A44D59CFF78
00007a44d59d0214  call 0x00007A44D58C0230
00007a44d59d0219  jmp 0x00007A44D59CFF81
00007a44d59d021e  call 0x00007A44D58E26A0
00007a44d59d0223  jmp 0x00007A44D59CFFA5
00007a44d59d0228  call 0x00007A44D58E1430
00007a44d59d022d  jmp 0x00007A44D59CFFAE
00007a44d59d0232  call 0x00007A44D58E26A0
00007a44d59d0237  jmp 0x00007A44D59CFFCF
00007a44d59d023c  call 0x00007A44D58E1430
00007a44d59d0241  jmp 0x00007A44D59CFFD8
00007a44d59d0246  call 0x00007A44D58E26A0
00007a44d59d024b  jmp 0x00007A44D59CFFF9
00007a44d59d0250  call 0x00007A44D58D5890
00007a44d59d0255  jmp 0x00007A44D59D0002
00007a44d59d025a  call 0x00007A44D58BDD50
00007a44d59d025f  jmp 0x00007A44D59D0098
00007a44d59d0264  call 0x00007A44D58DA580
00007a44d59d0269  jmp 0x00007A44D59D00CF
00007a44d59d026e  int3
00007a44d59d026f  nop
00007a44d59d0270  mov eax, [r15+0xB8]
00007a44d59d0277  mov [rsp+0x10], eax
00007a44d59d027b  mov eax, eax
00007a44d59d027d  mov [r15+0x30], rax
00007a44d59d0281  mov eax, [r15+0xC0]
00007a44d59d0288  mov [rsp+0x20], eax
00007a44d59d028c  mov eax, eax
00007a44d59d028e  mov [r15+0xA0], rax
00007a44d59d0295  mov eax, [r15+0x28]
00007a44d59d0299  mov r14d, [r15+0x98]
00007a44d59d02a0  mov [rsp+0x30], r14d
00007a44d59d02a5  mov r14d, r14d
00007a44d59d02a8  mov [r15+0x28], r14
00007a44d59d02ac  mov r14d, [r15+0x38]
00007a44d59d02b0  mov [rsp+0x40], r14d
00007a44d59d02b5  mov r14d, r14d
00007a44d59d02b8  mov [r15+0x98], r14
00007a44d59d02bf  mov r14d, [r15+0xA8]
00007a44d59d02c6  mov [rsp+0x50], r14d
00007a44d59d02cb  mov r14d, r14d
00007a44d59d02ce  mov [r15+0x38], r14
00007a44d59d02d2  mov r14d, [rsp+0x10]
00007a44d59d02d7  mov r12d, [rsp+0x10]
00007a44d59d02dc  shrd r14d, r12d, 0x06
00007a44d59d02e1  mov r11d, [r15+0xC8]
00007a44d59d02e8  mov [rsp+0x10], r12d
00007a44d59d02ed  and r12d, r11d
00007a44d59d02f0  mov r10d, [rsp+0x50]
00007a44d59d02f5  mov r9d, [rsp+0x50]
00007a44d59d02fa  shrd r10d, r9d, 0x02
00007a44d59d02ff  mov [rsp+0x50], r11d
00007a44d59d0304  mov r11d, r11d
00007a44d59d0307  mov [r15+0x20], r11
00007a44d59d030b  mov r11, [r15+0x88]
00007a44d59d0312  mov r8, [r15+0x50]
00007a44d59d0316  lea rbp, [r8+r11*1]
00007a44d59d031a  mov r8d, [r13+rbp*1]
00007a44d59d031f  mov ebp, [rsp+0x20]
00007a44d59d0323  mov edi, [rsp+0x10]
00007a44d59d0327  andn esi, edi, ebp
00007a44d59d032c  mov edx, [r15+0xB0]
00007a44d59d0333  lea ecx, [r12d+edx*1]
00007a44d59d0338  rorx r12d, edi, 0x0B
00007a44d59d033e  xor r14d, r12d
00007a44d59d0341  rorx r12d, r9d, 0x0D
00007a44d59d0347  xor r10d, r12d
00007a44d59d034a  lea r12d, [ecx+esi*1]
00007a44d59d034f  mov rsi, [r15+0x48]
00007a44d59d0353  lea rdx, [rsi+r11*1]
00007a44d59d0357  mov esi, [r13+rdx*1]
00007a44d59d035c  mov edx, [rsp+0x30]
00007a44d59d0360  mov ecx, [rsp+0x40]
00007a44d59d0364  and edx, ecx
00007a44d59d0366  mov [rsp+0x10], edx
00007a44d59d036a  mov edx, edx
00007a44d59d036c  mov [r15+0xD8], rdx
00007a44d59d0373  lea edx, [r12d+r8d*1]
00007a44d59d0378  mov r12d, [rsp+0x30]
00007a44d59d037d  xor r12d, ecx
00007a44d59d0380  rorx r8d, edi, 0x19
00007a44d59d0386  xor r14d, r8d
00007a44d59d0389  and r12d, r9d
00007a44d59d038c  rorx r8d, r9d, 0x16
00007a44d59d0392  xor r10d, r8d
00007a44d59d0395  mov [rsp+0x20], r10d
00007a44d59d039a  mov r10d, r10d
00007a44d59d039d  mov [r15+0xD0], r10
00007a44d59d03a4  lea r10d, [edx+esi*1]
00007a44d59d03a9  mov r9d, [rsp+0x10]
00007a44d59d03ae  xor r12d, r9d
00007a44d59d03b1  lea r9d, [r10d+r14d*1]
00007a44d59d03b6  lea r14, [r11+0x04]
00007a44d59d03ba  mov [r15+0x88], r14
00007a44d59d03c1  mov r11d, [rsp+0x20]
00007a44d59d03c6  lea r10d, [r12d+r11d*1]
00007a44d59d03cb  lea r11d, [r9d+eax*1]
00007a44d59d03d0  mov r11d, r11d
00007a44d59d03d3  mov [r15+0xB8], r11
00007a44d59d03da  xor eax, eax
00007a44d59d03dc  mov r12d, 0x100
00007a44d59d03e2  cmp r14, r12
00007a44d59d03e5  cmc
00007a44d59d03e6  lahf
00007a44d59d03e7  seto al
00007a44d59d03ea  mov [r15+0x108], eax
00007a44d59d03f1  lea eax, [r10d+r9d*1]
00007a44d59d03f6  mov eax, eax
00007a44d59d03f8  mov [r15+0xA8], rax
00007a44d59d03ff  mov ebp, ebp
00007a44d59d0401  mov [r15+0xB0], rbp
00007a44d59d0408  mov eax, [rsp+0x50]
00007a44d59d040c  mov eax, eax
00007a44d59d040e  mov [r15+0xC0], rax
00007a44d59d0415  mov edi, edi
00007a44d59d0417  mov [r15+0xC8], rdi
00007a44d59d041e  mov eax, [r15+0x108]
00007a44d59d0425  sahf
00007a44d59d0426  jnz 0x00007A44D59D0458
00007a44d59d0428  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0430  jz 0x00007A44D59D04A0
00007a44d59d0436  nop [rax+rax*1], ax
00007a44d59d043f  nop [rax+rax*1], eax
00007a44d59d0447  mov eax, 0x4108E0
00007a44d59d044c  mov [r15+0x100], rax
00007a44d59d0453  jmp 0x00007A44D57FE110
00007a44d59d0458  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0460  jz 0x00007A44D59D0270
00007a44d59d0466  nop [rax+rax*1], ax
00007a44d59d046f  nop [rax+rax*1], eax
00007a44d59d0477  mov eax, 0x410854
00007a44d59d047c  mov [r15+0x100], rax
00007a44d59d0483  jmp 0x00007A44D57FE110
00007a44d59d0488  int3
00007a44d59d0489  call 0x00007A44D5849010
00007a44d59d048e  jmp 0x00007A44D59D031F
00007a44d59d0493  call 0x00007A44D5825930
00007a44d59d0498  jmp 0x00007A44D59D035C
00007a44d59d049d  int3
00007a44d59d049e  nop
00007a44d59d04a0  mov eax, [r15+0x98]
00007a44d59d04a7  mov r14d, [r15+0x70]
00007a44d59d04ab  lea r12d, [eax+r14d*1]
00007a44d59d04b0  mov eax, [r15+0x28]
00007a44d59d04b4  mov r14d, [r15+0x68]
00007a44d59d04b8  lea r11d, [eax+r14d*1]
00007a44d59d04bd  mov qword ptr [r15+0x88], 0x00
00007a44d59d04c8  mov eax, [r15+0xA8]
00007a44d59d04cf  mov r14d, [r15+0x78]
00007a44d59d04d3  lea r10d, [eax+r14d*1]
00007a44d59d04d8  mov [rsp+0x10], r10d
00007a44d59d04dd  mov r10d, r10d
00007a44d59d04e0  mov [r15+0x78], r10
00007a44d59d04e4  mov eax, [r15+0x38]
00007a44d59d04e8  mov r14d, [r15+0x80]
00007a44d59d04ef  lea r10d, [eax+r14d*1]
00007a44d59d04f4  mov [rsp+0x20], r10d
00007a44d59d04f9  mov r10d, r10d
00007a44d59d04fc  mov [r15+0x80], r10
00007a44d59d0503  mov rax, [r15]
00007a44d59d0506  lea r14, [rax+0x08]
00007a44d59d050a  mov [r13+r14*1], r12d
00007a44d59d050f  lea r14, [rax+0x0C]
00007a44d59d0513  mov [r13+r14*1], r11d
00007a44d59d0518  mov r14d, [r15+0xB8]
00007a44d59d051f  mov r12d, [r15+0x18]
00007a44d59d0523  lea r11d, [r14d+r12d*1]
00007a44d59d0528  mov [rsp+0x30], r11d
00007a44d59d052d  mov r11d, r11d
00007a44d59d0530  mov [r15+0x68], r11
00007a44d59d0534  mov r14d, [r15+0x30]
00007a44d59d0538  mov r12d, [r15+0x90]
00007a44d59d053f  lea r11d, [r14d+r12d*1]
00007a44d59d0544  mov [rsp+0x40], r11d
00007a44d59d0549  mov r11d, r11d
00007a44d59d054c  mov [r15+0x70], r11
00007a44d59d0550  mov r14d, [r15+0x20]
00007a44d59d0554  mov r12d, [r15+0x58]
00007a44d59d0558  lea r11d, [r14d+r12d*1]
00007a44d59d055d  mov [rsp+0x50], r11d
00007a44d59d0562  mov r11d, r11d
00007a44d59d0565  mov [r15+0x58], r11
00007a44d59d0569  mov r14d, [r15+0xA0]
00007a44d59d0570  mov r12d, [r15+0x60]
00007a44d59d0574  lea r11d, [r14d+r12d*1]
00007a44d59d0579  mov [rsp+0x60], r11d
00007a44d59d057e  mov r11d, r11d
00007a44d59d0581  mov [r15+0x60], r11
00007a44d59d0585  mov r14d, [rsp+0x10]
00007a44d59d058a  mov [r13+rax*1], r14d
00007a44d59d058f  lea r14, [rax+0x04]
00007a44d59d0593  mov r12d, [rsp+0x20]
00007a44d59d0598  mov [r13+r14*1], r12d
00007a44d59d059d  lea r14, [rax+0x10]
00007a44d59d05a1  mov r12d, [rsp+0x30]
00007a44d59d05a6  mov [r13+r14*1], r12d
00007a44d59d05ab  lea r14, [rax+0x14]
00007a44d59d05af  mov r12d, [rsp+0x40]
00007a44d59d05b4  mov [r13+r14*1], r12d
00007a44d59d05b9  lea r14, [rax+0x18]
00007a44d59d05bd  mov r12d, [rsp+0x50]
00007a44d59d05c2  mov [r13+r14*1], r12d
00007a44d59d05c7  lea r14, [rax+0x1C]
00007a44d59d05cb  mov r12d, [rsp+0x60]
00007a44d59d05d0  mov [r13+r14*1], r12d
00007a44d59d05d5  lea r14, [rax+0x68]
00007a44d59d05d9  xor eax, eax
00007a44d59d05db  mov [r13+r14*1], rax
00007a44d59d05e0  cmp dword ptr [r15+0x318], 0x00
00007a44d59d05e8  jz 0x00007A44D59CF0E0
00007a44d59d05ee  nop [rax+rax*1], ax
00007a44d59d05f7  nop [rax+rax*1], eax
00007a44d59d05ff  mov eax, 0x4106FC
00007a44d59d0604  mov [r15+0x100], rax
00007a44d59d060b  jmp 0x00007A44D57FE110
00007a44d59d0610  int3
00007a44d59d0611  call 0x00007A44D58E2BA0
00007a44d59d0616  jmp 0x00007A44D59D050F
00007a44d59d061b  call 0x00007A44D58E1920
00007a44d59d0620  jmp 0x00007A44D59D0518
00007a44d59d0625  call 0x00007A44D580DFE0
00007a44d59d062a  jmp 0x00007A44D59D058F
00007a44d59d062f  call 0x00007A44D58E2BA0
00007a44d59d0634  jmp 0x00007A44D59D059D
00007a44d59d0639  call 0x00007A44D58E2BA0
00007a44d59d063e  jmp 0x00007A44D59D05AB
00007a44d59d0643  call 0x00007A44D58E2BA0
00007a44d59d0648  jmp 0x00007A44D59D05B9
00007a44d59d064d  call 0x00007A44D58E2BA0
00007a44d59d0652  jmp 0x00007A44D59D05C7
00007a44d59d0657  call 0x00007A44D58E2BA0
00007a44d59d065c  jmp 0x00007A44D59D05D5
00007a44d59d0661  call 0x00007A44D58D5EB0
00007a44d59d0666  jmp 0x00007A44D59D05E0
00007a44d59d066b  int3
00007a44d59d066c  nop [rax], eax
00007a44d59d0670  mov rax, [r15+0xF8]
00007a44d59d0677  lea r14, [rax+0x140]
00007a44d59d067e  mov r12, [r13+r14*1]
00007a44d59d0683  lea r14, [rax+0x148]
00007a44d59d068a  mov r11, [r13+r14*1]
00007a44d59d068f  mov [r15+0xA0], r12
00007a44d59d0696  mov [r15+0x98], r11
00007a44d59d069d  lea r14, [rax+0x130]
00007a44d59d06a4  mov r12, [r13+r14*1]
00007a44d59d06a9  lea r14, [rax+0x138]
00007a44d59d06b0  mov r11, [r13+r14*1]
00007a44d59d06b5  mov [r15+0xB0], r12
00007a44d59d06bc  mov [r15+0xA8], r11
00007a44d59d06c3  lea r14, [rax+0x120]
00007a44d59d06ca  mov r12, [r13+r14*1]
00007a44d59d06cf  lea r14, [rax+0x128]
00007a44d59d06d6  mov r11, [r13+r14*1]
00007a44d59d06db  mov [r15+0xC0], r12
00007a44d59d06e2  mov [r15+0xB8], r11
00007a44d59d06e9  lea r14, [rax+0x110]
00007a44d59d06f0  mov r12, [r13+r14*1]
00007a44d59d06f5  lea r14, [rax+0x118]
00007a44d59d06fc  mov r11, [r13+r14*1]
00007a44d59d0701  mov [r15+0xD0], r12
00007a44d59d0708  mov [r15+0xC8], r11
00007a44d59d070f  lea r14, [rax+0x100]
00007a44d59d0716  mov r12, [r13+r14*1]
00007a44d59d071b  lea r14, [rax+0x108]
00007a44d59d0722  mov r11, [r13+r14*1]
00007a44d59d0727  mov [r15+0xE8], r12
00007a44d59d072e  mov [r15+0xD8], r11
00007a44d59d0735  lea r14, [rax+0x150]
00007a44d59d073c  mov [r15+0xF8], r14
00007a44d59d0743  mov rax, [r15+0xF0]
00007a44d59d074a  mov [r15+0x100], rax
00007a44d59d0751  jmp 0x00007A44D59CE5C0
00007a44d59d0756  int3
00007a44d59d0757  call 0x00007A44D58E27E0
00007a44d59d075c  jmp 0x00007A44D59D0683
00007a44d59d0761  call 0x00007A44D58E1570
00007a44d59d0766  jmp 0x00007A44D59D068F
00007a44d59d076b  call 0x00007A44D58E27E0
00007a44d59d0770  jmp 0x00007A44D59D06A9
00007a44d59d0775  call 0x00007A44D58E1570
00007a44d59d077a  jmp 0x00007A44D59D06B5
00007a44d59d077f  call 0x00007A44D58E27E0
00007a44d59d0784  jmp 0x00007A44D59D06CF
00007a44d59d0789  call 0x00007A44D58E1570
00007a44d59d078e  jmp 0x00007A44D59D06DB
00007a44d59d0793  call 0x00007A44D58E27E0
00007a44d59d0798  jmp 0x00007A44D59D06F5
00007a44d59d079d  call 0x00007A44D58E1570
00007a44d59d07a2  jmp 0x00007A44D59D0701
00007a44d59d07a7  call 0x00007A44D58E27E0
00007a44d59d07ac  jmp 0x00007A44D59D071B
00007a44d59d07b1  call 0x00007A44D58E1570
00007a44d59d07b6  jmp 0x00007A44D59D0727
00007a44d59d07bb  int3
00007a44d59d07bc  nop [rax], eax
00007a44d59d07c0  mov eax, [r15+0xA0]
00007a44d59d07c7  mov [rsp+0x10], eax
00007a44d59d07cb  xor eax, eax
00007a44d59d07cd  mov r14d, [rsp+0x10]
00007a44d59d07d2  sub r14d, 0x01
00007a44d59d07d6  cmc
00007a44d59d07d7  lahf
00007a44d59d07d8  seto al
00007a44d59d07db  mov [r15+0x108], eax
00007a44d59d07e2  mov r14d, r14d
00007a44d59d07e5  mov [r15+0xA0], r14
00007a44d59d07ec  mov eax, [r15+0x108]
00007a44d59d07f3  sahf
00007a44d59d07f4  jnz 0x00007A44D59D0826
00007a44d59d07f6  cmp dword ptr [r15+0x318], 0x00
00007a44d59d07fe  jz 0x00007A44D59D0900
00007a44d59d0804  nop [rax+rax*1], ax
00007a44d59d080d  nop [rax+rax*1], eax
00007a44d59d0815  mov eax, 0x41028C
00007a44d59d081a  mov [r15+0x100], rax
00007a44d59d0821  jmp 0x00007A44D57FE110
00007a44d59d0826  cmp dword ptr [r15+0x318], 0x00
00007a44d59d082e  jz 0x00007A44D59D0860
00007a44d59d0834  nop [rax+rax*1], ax
00007a44d59d083d  nop [rax+rax*1], eax
00007a44d59d0845  mov eax, 0x410274
00007a44d59d084a  mov [r15+0x100], rax
00007a44d59d0851  jmp 0x00007A44D57FE110
00007a44d59d0856  int3
00007a44d59d0857  int3
00007a44d59d0858  nop [rax+rax*1], eax
00007a44d59d0860  mov rax, [r15+0xF8]
00007a44d59d0867  lea r14, [rax+0xD0]
00007a44d59d086e  mov [r15], r14
00007a44d59d0871  mov rax, [r15+0x98]
00007a44d59d0878  mov [r15+0x08], rax
00007a44d59d087c  mov qword ptr [r15+0x10], 0x12C
00007a44d59d0884  mov qword ptr [r15+0xF0], 0x410284
00007a44d59d088f  mov r14d, [r15+0x320]
00007a44d59d0896  mov eax, 0x410284
00007a44d59d089b  mov rcx, 0x7A44D59D07C0
00007a44d59d08a5  mov [r15+r14*8+0x328], rax
00007a44d59d08ad  mov [r15+r14*8+0x368], rcx
00007a44d59d08b5  add r14d, 0x01
00007a44d59d08b9  and r14d, 0x07
00007a44d59d08bd  mov [r15+0x320], r14d
00007a44d59d08c4  cmp dword ptr [r15+0x318], 0x00
00007a44d59d08cc  jz 0x00007A44D59CED70
00007a44d59d08d2  nop [rax+rax*1], ax
00007a44d59d08db  nop [rax+rax*1], eax
00007a44d59d08e3  mov eax, 0x4106BC
00007a44d59d08e8  mov [r15+0x100], rax
00007a44d59d08ef  jmp 0x00007A44D57FE110
00007a44d59d08f4  int3
00007a44d59d08f5  int3
00007a44d59d08f6  nop [rax+rax*1], ax
00007a44d59d08ff  nop
00007a44d59d0900  mov rax, [r15+0xF8]
00007a44d59d0907  lea r14, [rax+0xF0]
00007a44d59d090e  mov r12, [r13+r14*1]
00007a44d59d0913  mov [r15+0x98], r12
00007a44d59d091a  mov qword ptr [r15+0x40], 0x80
00007a44d59d0922  lea r14, [rax+0xD0]
00007a44d59d0929  mov [r15], r14
00007a44d59d092c  lea r14, [rax+0x14C]
00007a44d59d0933  mov [r15+0x08], r14
00007a44d59d0937  mov qword ptr [r15+0x10], 0x01
00007a44d59d093f  lea r14, [rax+0x14C]
00007a44d59d0946  mov eax, 0x80
00007a44d59d094b  mov [r13+r14*1], al
00007a44d59d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007a44d59d095b  mov r14d, [r15+0x320]
00007a44d59d0962  mov eax, 0x4102A8
00007a44d59d0967  mov rcx, 0x7A44D59D09E0
00007a44d59d0971  mov [r15+r14*8+0x328], rax
00007a44d59d0979  mov [r15+r14*8+0x368], rcx
00007a44d59d0981  add r14d, 0x01
00007a44d59d0985  and r14d, 0x07
00007a44d59d0989  mov [r15+0x320], r14d
00007a44d59d0990  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0998  jz 0x00007A44D59CED70
00007a44d59d099e  nop [rax+rax*1], ax
00007a44d59d09a7  nop [rax+rax*1], eax
00007a44d59d09af  mov eax, 0x4106BC
00007a44d59d09b4  mov [r15+0x100], rax
00007a44d59d09bb  jmp 0x00007A44D57FE110
00007a44d59d09c0  int3
00007a44d59d09c1  call 0x00007A44D58E27E0
00007a44d59d09c6  jmp 0x00007A44D59D0913
00007a44d59d09cb  call 0x00007A44D58D5AF0
00007a44d59d09d0  jmp 0x00007A44D59D0950
00007a44d59d09d5  int3
00007a44d59d09d6  nop [rax+rax*1], ax
00007a44d59d09df  nop
00007a44d59d09e0  mov rax, [r15+0xF8]
00007a44d59d09e7  lea r14, [rax+0x138]
00007a44d59d09ee  mov r12, [r13+r14*1]
00007a44d59d09f3  mov [r15+0x40], r12
00007a44d59d09f7  lea r14, [rax+0x148]
00007a44d59d09fe  xor eax, eax
00007a44d59d0a00  mov [r13+r14*1], al
00007a44d59d0a05  xor eax, eax
00007a44d59d0a07  mov r14d, 0x38
00007a44d59d0a0d  cmp r12, r14
00007a44d59d0a10  cmc
00007a44d59d0a11  lahf
00007a44d59d0a12  seto al
00007a44d59d0a15  mov [r15+0x108], eax
00007a44d59d0a1c  mov eax, [r15+0x108]
00007a44d59d0a23  sahf
00007a44d59d0a24  jz 0x00007A44D59D0A56
00007a44d59d0a26  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0a2e  jz 0x00007A44D59D0AA0
00007a44d59d0a34  nop [rax+rax*1], ax
00007a44d59d0a3d  nop [rax+rax*1], eax
00007a44d59d0a45  mov eax, 0x4102B8
00007a44d59d0a4a  mov [r15+0x100], rax
00007a44d59d0a51  jmp 0x00007A44D57FE110
00007a44d59d0a56  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0a5e  jz 0x00007A44D59D0BF0
00007a44d59d0a64  nop [rax+rax*1], ax
00007a44d59d0a6d  nop [rax+rax*1], eax
00007a44d59d0a75  mov eax, 0x4102D4
00007a44d59d0a7a  mov [r15+0x100], rax
00007a44d59d0a81  jmp 0x00007A44D57FE110
00007a44d59d0a86  int3
00007a44d59d0a87  call 0x00007A44D58E27E0
00007a44d59d0a8c  jmp 0x00007A44D59D09F3
00007a44d59d0a91  call 0x00007A44D58D5AF0
00007a44d59d0a96  jmp 0x00007A44D59D0A05
00007a44d59d0a9b  int3
00007a44d59d0a9c  nop [rax], eax
00007a44d59d0aa0  mov rax, [r15+0xF8]
00007a44d59d0aa7  lea r14, [rax+0xD0]
00007a44d59d0aae  mov [r15], r14
00007a44d59d0ab1  lea r14, [rax+0x148]
00007a44d59d0ab8  mov [r15+0x08], r14
00007a44d59d0abc  mov qword ptr [r15+0x10], 0x01
00007a44d59d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007a44d59d0acf  mov r14d, [r15+0x320]
00007a44d59d0ad6  mov eax, 0x4102C8
00007a44d59d0adb  mov rcx, 0x7A44D59D0B40
00007a44d59d0ae5  mov [r15+r14*8+0x328], rax
00007a44d59d0aed  mov [r15+r14*8+0x368], rcx
00007a44d59d0af5  add r14d, 0x01
00007a44d59d0af9  and r14d, 0x07
00007a44d59d0afd  mov [r15+0x320], r14d
00007a44d59d0b04  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0b0c  jz 0x00007A44D59CED70
00007a44d59d0b12  nop [rax+rax*1], ax
00007a44d59d0b1b  nop [rax+rax*1], eax
00007a44d59d0b23  mov eax, 0x4106BC
00007a44d59d0b28  mov [r15+0x100], rax
00007a44d59d0b2f  jmp 0x00007A44D57FE110
00007a44d59d0b34  int3
00007a44d59d0b35  int3
00007a44d59d0b36  nop [rax+rax*1], ax
00007a44d59d0b3f  nop
00007a44d59d0b40  mov rax, [r15+0xF8]
00007a44d59d0b47  lea r14, [rax+0x138]
00007a44d59d0b4e  mov rax, [r13+r14*1]
00007a44d59d0b53  mov [r15+0x40], rax
00007a44d59d0b57  mov [rsp+0x10], rax
00007a44d59d0b5c  xor eax, eax
00007a44d59d0b5e  mov r14, [rsp+0x10]
00007a44d59d0b63  mov r12d, 0x38
00007a44d59d0b69  cmp r14, r12
00007a44d59d0b6c  cmc
00007a44d59d0b6d  lahf
00007a44d59d0b6e  seto al
00007a44d59d0b71  mov [r15+0x108], eax
00007a44d59d0b78  mov eax, [r15+0x108]
00007a44d59d0b7f  sahf
00007a44d59d0b80  jnz 0x00007A44D59D0BB2
00007a44d59d0b82  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0b8a  jz 0x00007A44D59D0BF0
00007a44d59d0b90  nop [rax+rax*1], ax
00007a44d59d0b99  nop [rax+rax*1], eax
00007a44d59d0ba1  mov eax, 0x4102D4
00007a44d59d0ba6  mov [r15+0x100], rax
00007a44d59d0bad  jmp 0x00007A44D57FE110
00007a44d59d0bb2  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0bba  jz 0x00007A44D59D0AA0
00007a44d59d0bc0  nop [rax+rax*1], ax
00007a44d59d0bc9  nop [rax+rax*1], eax
00007a44d59d0bd1  mov eax, 0x4102B8
00007a44d59d0bd6  mov [r15+0x100], rax
00007a44d59d0bdd  jmp 0x00007A44D57FE110
00007a44d59d0be2  int3
00007a44d59d0be3  call 0x00007A44D58D59C0
00007a44d59d0be8  jmp 0x00007A44D59D0B53
00007a44d59d0bed  int3
00007a44d59d0bee  nop
00007a44d59d0bf0  mov rax, [r15+0x98]
00007a44d59d0bf7  rorx r14, rax, 0x3D
00007a44d59d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007a44d59d0c01  mov rax, [r15+0xF8]
00007a44d59d0c08  lea r12, [rax+0xD0]
00007a44d59d0c0f  mov [r15], r12
00007a44d59d0c12  lea r12, [rax+0x140]
00007a44d59d0c19  mov [r15+0x08], r12
00007a44d59d0c1d  mov qword ptr [r15+0x10], 0x08
00007a44d59d0c25  bswap r14
00007a44d59d0c28  mov [r15+0x40], r14
00007a44d59d0c2c  lea r12, [rax+0x140]
00007a44d59d0c33  mov [r13+r12*1], r14
00007a44d59d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007a44d59d0c43  mov r14d, [r15+0x320]
00007a44d59d0c4a  mov eax, 0x4102F0
00007a44d59d0c4f  mov rcx, 0x7A44D59D0CC0
00007a44d59d0c59  mov [r15+r14*8+0x328], rax
00007a44d59d0c61  mov [r15+r14*8+0x368], rcx
00007a44d59d0c69  add r14d, 0x01
00007a44d59d0c6d  and r14d, 0x07
00007a44d59d0c71  mov [r15+0x320], r14d
00007a44d59d0c78  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0c80  jz 0x00007A44D59CED70
00007a44d59d0c86  nop [rax+rax*1], ax
00007a44d59d0c8f  nop [rax+rax*1], eax
00007a44d59d0c97  mov eax, 0x4106BC
00007a44d59d0c9c  mov [r15+0x100], rax
00007a44d59d0ca3  jmp 0x00007A44D57FE110
00007a44d59d0ca8  int3
00007a44d59d0ca9  call 0x00007A44D58C3FE0
00007a44d59d0cae  jmp 0x00007A44D59D0C38
00007a44d59d0cb3  int3
00007a44d59d0cb4  nop [rax+rax*1], ax
00007a44d59d0cbd  nop [rax], eax
00007a44d59d0cc0  mov rax, [r15+0xF8]
00007a44d59d0cc7  lea r14, [rax+0xD0]
00007a44d59d0cce  mov r12d, [r13+r14*1]
00007a44d59d0cd3  lea r14, [rax+0xD4]
00007a44d59d0cda  mov r11d, [r13+r14*1]
00007a44d59d0cdf  lea r14, [rax+0xD8]
00007a44d59d0ce6  mov r10d, [r13+r14*1]
00007a44d59d0ceb  lea r14, [rax+0xDC]
00007a44d59d0cf2  mov r9d, [r13+r14*1]
00007a44d59d0cf7  mov qword ptr [r15+0x48], 0x430C20
00007a44d59d0cff  mov qword ptr [r15+0xA0], 0x00
00007a44d59d0d0a  bswap r12d
00007a44d59d0d0d  bswap r11d
00007a44d59d0d10  mov qword ptr [r15+0x98], 0x430D8C
00007a44d59d0d1b  mov r14d, 0x430C20
00007a44d59d0d21  mov [r13+r14*1], r12d
00007a44d59d0d26  mov r14d, 0x430C24
00007a44d59d0d2c  mov [r13+r14*1], r11d
00007a44d59d0d31  bswap r10d
00007a44d59d0d34  bswap r9d
00007a44d59d0d37  lea r14, [rax+0xE0]
00007a44d59d0d3e  mov r12d, [r13+r14*1]
00007a44d59d0d43  lea r14, [rax+0xE4]
00007a44d59d0d4a  mov r11d, [r13+r14*1]
00007a44d59d0d4f  mov r14d, 0x430C28
00007a44d59d0d55  mov [r13+r14*1], r10d
00007a44d59d0d5a  mov r14d, 0x430C2C
00007a44d59d0d60  mov [r13+r14*1], r9d
00007a44d59d0d65  bswap r12d
00007a44d59d0d68  bswap r11d
00007a44d59d0d6b  mov [rsp+0x10], r11d
00007a44d59d0d70  mov r11d, r11d
00007a44d59d0d73  mov [r15+0x58], r11
00007a44d59d0d77  lea r14, [rax+0xE8]
00007a44d59d0d7e  mov r11d, [r13+r14*1]
00007a44d59d0d83  lea r14, [rax+0xEC]
00007a44d59d0d8a  mov eax, [r13+r14*1]
00007a44d59d0d8f  mov [rsp+0x20], eax
00007a44d59d0d93  mov eax, eax
00007a44d59d0d95  mov [r15+0x60], rax
00007a44d59d0d99  mov eax, 0x430C30
00007a44d59d0d9e  mov [r13+rax*1], r12d
00007a44d59d0da3  mov eax, 0x430C34
00007a44d59d0da8  mov r14d, [rsp+0x10]
00007a44d59d0dad  mov [r13+rax*1], r14d
00007a44d59d0db2  bswap r11d
00007a44d59d0db5  mov [rsp+0x10], r11d
00007a44d59d0dba  mov r11d, r11d
00007a44d59d0dbd  mov [r15+0x40], r11
00007a44d59d0dc1  mov eax, [rsp+0x20]
00007a44d59d0dc5  bswap eax
00007a44d59d0dc7  mov [rsp+0x20], eax
00007a44d59d0dcb  mov eax, eax
00007a44d59d0dcd  mov [r15+0x50], rax
00007a44d59d0dd1  mov eax, 0x430C38
00007a44d59d0dd6  mov r14d, [rsp+0x10]
00007a44d59d0ddb  mov [r13+rax*1], r14d
00007a44d59d0de0  mov eax, 0x430C3C
00007a44d59d0de5  mov r14d, [rsp+0x20]
00007a44d59d0dea  mov [r13+rax*1], r14d
00007a44d59d0def  mov eax, [r15+0xA0]
00007a44d59d0df6  lea r14d, [eax+0x11]
00007a44d59d0dfb  mov r14d, r14d
00007a44d59d0dfe  mov [r15], r14
00007a44d59d0e01  mov qword ptr [r15+0xF0], 0x41034C
00007a44d59d0e0c  mov r14d, [r15+0x320]
00007a44d59d0e13  mov eax, 0x41034C
00007a44d59d0e18  mov rcx, 0x7A44D59D0F90
00007a44d59d0e22  mov [r15+r14*8+0x328], rax
00007a44d59d0e2a  mov [r15+r14*8+0x368], rcx
00007a44d59d0e32  add r14d, 0x01
00007a44d59d0e36  and r14d, 0x07
00007a44d59d0e3a  mov [r15+0x320], r14d
00007a44d59d0e41  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0e49  jz 0x00007A44D59D0F20
00007a44d59d0e4f  nop [rax+rax*1], ax
00007a44d59d0e58  nop [rax+rax*1], eax
00007a44d59d0e60  mov eax, 0x410938
00007a44d59d0e65  mov [r15+0x100], rax
00007a44d59d0e6c  jmp 0x00007A44D57FE110
00007a44d59d0e71  int3
00007a44d59d0e72  call 0x00007A44D58E26A0
00007a44d59d0e77  jmp 0x00007A44D59D0CD3
00007a44d59d0e7c  call 0x00007A44D58E1430
00007a44d59d0e81  jmp 0x00007A44D59D0CDF
00007a44d59d0e86  call 0x00007A44D58E01C0
00007a44d59d0e8b  jmp 0x00007A44D59D0CEB
00007a44d59d0e90  call 0x00007A44D58DEF50
00007a44d59d0e95  jmp 0x00007A44D59D0CF7
00007a44d59d0e9a  call 0x00007A44D58E2BA0
00007a44d59d0e9f  jmp 0x00007A44D59D0D26
00007a44d59d0ea4  call 0x00007A44D58E1920
00007a44d59d0ea9  jmp 0x00007A44D59D0D31
00007a44d59d0eae  call 0x00007A44D58E26A0
00007a44d59d0eb3  jmp 0x00007A44D59D0D43
00007a44d59d0eb8  call 0x00007A44D58E1430
00007a44d59d0ebd  jmp 0x00007A44D59D0D4F
00007a44d59d0ec2  call 0x00007A44D58E06B0
00007a44d59d0ec7  jmp 0x00007A44D59D0D5A
00007a44d59d0ecc  call 0x00007A44D58DF440
00007a44d59d0ed1  jmp 0x00007A44D59D0D65
00007a44d59d0ed6  call 0x00007A44D58E1430
00007a44d59d0edb  jmp 0x00007A44D59D0D83
00007a44d59d0ee0  call 0x00007A44D58D5890
00007a44d59d0ee5  jmp 0x00007A44D59D0D8F
00007a44d59d0eea  call 0x00007A44D580BAE0
00007a44d59d0eef  jmp 0x00007A44D59D0DA3
00007a44d59d0ef4  call 0x00007A44D580DFE0
00007a44d59d0ef9  jmp 0x00007A44D59D0DB2
00007a44d59d0efe  call 0x00007A44D580DFE0
00007a44d59d0f03  jmp 0x00007A44D59D0DE0
00007a44d59d0f08  call 0x00007A44D580DFE0
00007a44d59d0f0d  jmp 0x00007A44D59D0DEF
00007a44d59d0f12  int3
00007a44d59d0f13  nop [rax+rax*1], ax
00007a44d59d0f1c  nop [rax], eax
00007a44d59d0f20  mov eax, [r15]
00007a44d59d0f23  mov [rsp+0x10], eax
00007a44d59d0f27  shr eax, 0x10
00007a44d59d0f2a  mov r14d, [rsp+0x10]
00007a44d59d0f2f  xor r14d, eax
00007a44d59d0f32  imul r14d, r14d, 0x7FEB352D
00007a44d59d0f39  mov eax, 0x846CA68B
00007a44d59d0f3e  mov eax, eax
00007a44d59d0f40  mov [r15+0x48], rax
00007a44d59d0f44  mov [rsp+0x10], r14d
00007a44d59d0f49  shr r14d, 0x0F
00007a44d59d0f4d  mov eax, [rsp+0x10]
00007a44d59d0f51  xor eax, r14d
00007a44d59d0f54  imul eax, eax, 0x846CA68B
00007a44d59d0f5a  mov [rsp+0x10], eax
00007a44d59d0f5e  mov eax, eax
00007a44d59d0f60  mov [r15+0x40], rax
00007a44d59d0f64  mov eax, [rsp+0x10]
00007a44d59d0f68  shr eax, 0x10
00007a44d59d0f6b  mov r14d, [rsp+0x10]
00007a44d59d0f70  xor r14d, eax
00007a44d59d0f73  mov r14d, r14d
00007a44d59d0f76  mov [r15], r14
00007a44d59d0f79  mov rax, [r15+0xF0]
00007a44d59d0f80  mov [r15+0x100], rax
00007a44d59d0f87  jmp 0x00007A44D59CE5C0
00007a44d59d0f8c  int3
00007a44d59d0f8d  int3
00007a44d59d0f8e  nop
00007a44d59d0f90  mov rax, [r15+0xA0]
00007a44d59d0f97  mov [rsp+0x10], rax
00007a44d59d0f9c  shl rax, 0x02
00007a44d59d0fa0  mov r14, [r15+0x98]
00007a44d59d0fa7  lea r12, [r14+rax*1]
00007a44d59d0fab  mov eax, [r15]
00007a44d59d0fae  mov [r13+r12*1], eax
00007a44d59d0fb3  mov rax, [rsp+0x10]
00007a44d59d0fb8  lea r14, [rax+0x01]
00007a44d59d0fbc  mov [r15+0xA0], r14
00007a44d59d0fc3  xor eax, eax
00007a44d59d0fc5  mov r12d, 0x400
00007a44d59d0fcb  cmp r14, r12
00007a44d59d0fce  cmc
00007a44d59d0fcf  lahf
00007a44d59d0fd0  seto al
00007a44d59d0fd3  mov [r15+0x108], eax
00007a44d59d0fda  mov eax, [r15+0x108]
00007a44d59d0fe1  sahf
00007a44d59d0fe2  jnz 0x00007A44D59D1014
00007a44d59d0fe4  cmp dword ptr [r15+0x318], 0x00
00007a44d59d0fec  jz 0x00007A44D59D10E0
00007a44d59d0ff2  nop [rax+rax*1], ax
00007a44d59d0ffb  nop [rax+rax*1], eax
00007a44d59d1003  mov eax, 0x41035C
00007a44d59d1008  mov [r15+0x100], rax
00007a44d59d100f  jmp 0x00007A44D57FE110
00007a44d59d1014  cmp dword ptr [r15+0x318], 0x00
00007a44d59d101c  jz 0x00007A44D59D1050
00007a44d59d1022  nop [rax+rax*1], ax
00007a44d59d102b  nop [rax+rax*1], eax
00007a44d59d1033  mov eax, 0x410344
00007a44d59d1038  mov [r15+0x100], rax
00007a44d59d103f  jmp 0x00007A44D57FE110
00007a44d59d1044  int3
00007a44d59d1045  call 0x00007A44D58B4B70
00007a44d59d104a  jmp 0x00007A44D59D0FB3
00007a44d59d104f  int3
00007a44d59d1050  mov eax, [r15+0xA0]
00007a44d59d1057  lea r14d, [eax+0x11]
00007a44d59d105c  mov r14d, r14d
00007a44d59d105f  mov [r15], r14
00007a44d59d1062  mov qword ptr [r15+0xF0], 0x41034C
00007a44d59d106d  mov r14d, [r15+0x320]
00007a44d59d1074  mov eax, 0x41034C
00007a44d59d1079  mov rcx, 0x7A44D59D0F90
00007a44d59d1083  mov [r15+r14*8+0x328], rax
00007a44d59d108b  mov [r15+r14*8+0x368], rcx
00007a44d59d1093  add r14d, 0x01
00007a44d59d1097  and r14d, 0x07
00007a44d59d109b  mov [r15+0x320], r14d
00007a44d59d10a2  cmp dword ptr [r15+0x318], 0x00
00007a44d59d10aa  jz 0x00007A44D59D0F20
00007a44d59d10b0  nop [rax+rax*1], ax
00007a44d59d10b9  nop [rax+rax*1], eax
00007a44d59d10c1  mov eax, 0x410938
00007a44d59d10c6  mov [r15+0x100], rax
00007a44d59d10cd  jmp 0x00007A44D57FE110
00007a44d59d10d2  int3
00007a44d59d10d3  int3
00007a44d59d10d4  nop [rax+rax*1], ax
00007a44d59d10dd  nop [rax], eax
00007a44d59d10e0  mov qword ptr [r15+0x40], 0x01
00007a44d59d10e8  cmp dword ptr [r15+0x318], 0x00
00007a44d59d10f0  jz 0x00007A44D59D1120
00007a44d59d10f6  nop [rax+rax*1], ax
00007a44d59d10ff  nop [rax+rax*1], eax
00007a44d59d1107  mov eax, 0x410378
00007a44d59d110c  mov [r15+0x100], rax
00007a44d59d1113  jmp 0x00007A44D57FE110
00007a44d59d1118  int3
00007a44d59d1119  int3
00007a44d59d111a  nop [rax+rax*1], ax
00007a44d59d1120  mov rax, [r15+0x40]
00007a44d59d1124  mov [rsp+0x10], rax
00007a44d59d1129  shl rax, 0x02
00007a44d59d112d  mov r14, [r15+0x98]
00007a44d59d1134  lea r12, [r14+rax*1]
00007a44d59d1138  mov eax, [r13+r12*1]
00007a44d59d113d  mov [rsp+0x20], eax
00007a44d59d1141  mov eax, eax
00007a44d59d1143  mov [r15+0x48], rax
00007a44d59d1147  mov rax, [rsp+0x10]
00007a44d59d114c  mov [r15+0x50], rax
00007a44d59d1150  mov eax, [r15+0x50]
00007a44d59d1154  lea r12d, [eax-0x01]
00007a44d59d1159  mov r12d, r12d
00007a44d59d115c  mov [r15+0x58], r12
00007a44d59d1160  mov rax, [r15+0x58]
00007a44d59d1164  mov r12d, eax
00007a44d59d1167  mov r12d, r12d
00007a44d59d116a  shl r12, 0x02
00007a44d59d116e  lea rax, [r14+r12*1]
00007a44d59d1172  mov r14d, [r13+rax*1]
00007a44d59d1177  mov [rsp+0x10], r14d
00007a44d59d117c  mov r14d, r14d
00007a44d59d117f  mov [r15+0x60], r14
00007a44d59d1183  xor eax, eax
00007a44d59d1185  mov r14d, [rsp+0x10]
00007a44d59d118a  mov r12d, [rsp+0x20]
00007a44d59d118f  cmp r14d, r12d
00007a44d59d1192  cmc
00007a44d59d1193  lahf
00007a44d59d1194  seto al
00007a44d59d1197  mov [r15+0x108], eax
00007a44d59d119e  mov eax, [r15+0x108]
00007a44d59d11a5  sahf
00007a44d59d11a6  cmc
00007a44d59d11a7  jbe 0x00007A44D59D11D9
00007a44d59d11a9  cmp dword ptr [r15+0x318], 0x00
00007a44d59d11b1  jz 0x00007A44D59D1220
00007a44d59d11b7  nop [rax+rax*1], ax
00007a44d59d11c0  nop [rax+rax*1], eax
00007a44d59d11c8  mov eax, 0x410390
00007a44d59d11cd  mov [r15+0x100], rax
00007a44d59d11d4  jmp 0x00007A44D57FE110
00007a44d59d11d9  cmp dword ptr [r15+0x318], 0x00
00007a44d59d11e1  jz 0x00007A44D59D14C0
00007a44d59d11e7  nop [rax+rax*1], ax
00007a44d59d11f0  nop [rax+rax*1], eax
00007a44d59d11f8  mov eax, 0x410368
00007a44d59d11fd  mov [r15+0x100], rax
00007a44d59d1204  jmp 0x00007A44D57FE110
00007a44d59d1209  int3
00007a44d59d120a  call 0x00007A44D58B4690
00007a44d59d120f  jmp 0x00007A44D59D113D
00007a44d59d1214  call 0x00007A44D580DAE0
00007a44d59d1219  jmp 0x00007A44D59D1177
00007a44d59d121e  int3
00007a44d59d121f  nop
00007a44d59d1220  mov rax, [r15+0x50]
00007a44d59d1224  mov [rsp+0x10], rax
00007a44d59d1229  shl rax, 0x02
00007a44d59d122d  mov r14, [r15+0x98]
00007a44d59d1234  lea r12, [r14+rax*1]
00007a44d59d1238  mov eax, [r15+0x60]
00007a44d59d123c  mov [r13+r12*1], eax
00007a44d59d1241  mov rax, [rsp+0x10]
00007a44d59d1246  lea r14, [rax-0x01]
00007a44d59d124a  mov [r15+0x50], r14
00007a44d59d124e  mov rax, [r15+0x58]
00007a44d59d1252  test rax, rax
00007a44d59d1255  setz al
00007a44d59d1258  movzx rax, al
00007a44d59d125c  mov [rsp+0x414], al
00007a44d59d1263  cmp byte ptr [rsp+0x414], 0x00
00007a44d59d126b  jz 0x00007A44D59D129D
00007a44d59d126d  cmp dword ptr [r15+0x318], 0x00
00007a44d59d1275  jz 0x00007A44D59D12E0
00007a44d59d127b  nop [rax+rax*1], ax
00007a44d59d1284  nop [rax+rax*1], eax
00007a44d59d128c  mov eax, 0x41039C
00007a44d59d1291  mov [r15+0x100], rax
00007a44d59d1298  jmp 0x00007A44D57FE110
00007a44d59d129d  cmp dword ptr [r15+0x318], 0x00
00007a44d59d12a5  jz 0x00007A44D59D13E0
00007a44d59d12ab  nop [rax+rax*1], ax
00007a44d59d12b4  nop [rax+rax*1], eax
00007a44d59d12bc  mov eax, 0x410380
00007a44d59d12c1  mov [r15+0x100], rax
00007a44d59d12c8  jmp 0x00007A44D57FE110
00007a44d59d12cd  int3
00007a44d59d12ce  call 0x00007A44D58B4B70
00007a44d59d12d3  jmp 0x00007A44D59D1241
00007a44d59d12d8  int3
00007a44d59d12d9  nop [rax], eax
00007a44d59d12e0  cmp dword ptr [r15+0x318], 0x00
00007a44d59d12e8  jz 0x00007A44D59D1320
00007a44d59d12ee  nop [rax+rax*1], ax
00007a44d59d12f7  nop [rax+rax*1], eax
00007a44d59d12ff  mov eax, 0x410364
00007a44d59d1304  mov [r15+0x100], rax
00007a44d59d130b  jmp 0x00007A44D57FE110
00007a44d59d1310  int3
00007a44d59d1311  int3
00007a44d59d1312  nop [rax+rax*1], ax
00007a44d59d131b  nop [rax+rax*1], eax
00007a44d59d1320  mov qword ptr [r15+0x50], 0x00
00007a44d59d1328  mov rax, [r15+0x40]
00007a44d59d132c  lea r14, [rax+0x01]
00007a44d59d1330  mov [r15+0x40], r14
00007a44d59d1334  mov rax, [r15+0x98]
00007a44d59d133b  mov r12d, [r15+0x48]
00007a44d59d133f  mov [r13+rax*1], r12d
00007a44d59d1344  xor eax, eax
00007a44d59d1346  mov r12d, 0x400
00007a44d59d134c  cmp r14, r12
00007a44d59d134f  cmc
00007a44d59d1350  lahf
00007a44d59d1351  seto al
00007a44d59d1354  mov [r15+0x108], eax
00007a44d59d135b  mov eax, [r15+0x108]
00007a44d59d1362  sahf
00007a44d59d1363  jz 0x00007A44D59D1395
00007a44d59d1365  cmp dword ptr [r15+0x318], 0x00
00007a44d59d136d  jz 0x00007A44D59D1120
00007a44d59d1373  nop [rax+rax*1], ax
00007a44d59d137c  nop [rax+rax*1], eax
00007a44d59d1384  mov eax, 0x410378
00007a44d59d1389  mov [r15+0x100], rax
00007a44d59d1390  jmp 0x00007A44D57FE110
00007a44d59d1395  cmp dword ptr [r15+0x318], 0x00
00007a44d59d139d  jz 0x00007A44D59D1580
00007a44d59d13a3  nop [rax+rax*1], ax
00007a44d59d13ac  nop [rax+rax*1], eax
00007a44d59d13b4  mov eax, 0x4103A0
00007a44d59d13b9  mov [r15+0x100], rax
00007a44d59d13c0  jmp 0x00007A44D57FE110
00007a44d59d13c5  int3
00007a44d59d13c6  call 0x00007A44D580BAE0
00007a44d59d13cb  jmp 0x00007A44D59D1344
00007a44d59d13d0  int3
00007a44d59d13d1  nop [rax+rax*1], ax
00007a44d59d13da  nop [rax+rax*1], ax
00007a44d59d13e0  mov eax, [r15+0x50]
00007a44d59d13e4  lea r14d, [eax-0x01]
00007a44d59d13e9  mov r14d, r14d
00007a44d59d13ec  mov [r15+0x58], r14
00007a44d59d13f0  mov rax, [r15+0x58]
00007a44d59d13f4  mov r14d, eax
00007a44d59d13f7  mov r14d, r14d
00007a44d59d13fa  shl r14, 0x02
00007a44d59d13fe  mov rax, [r15+0x98]
00007a44d59d1405  lea r12, [rax+r14*1]
00007a44d59d1409  mov eax, [r13+r12*1]
00007a44d59d140e  mov [rsp+0x10], eax
00007a44d59d1412  mov eax, eax
00007a44d59d1414  mov [r15+0x60], rax
00007a44d59d1418  mov eax, [r15+0x48]
00007a44d59d141c  mov [rsp+0x20], eax
00007a44d59d1420  xor eax, eax
00007a44d59d1422  mov r14d, [rsp+0x10]
00007a44d59d1427  mov r12d, [rsp+0x20]
00007a44d59d142c  cmp r14d, r12d
00007a44d59d142f  cmc
00007a44d59d1430  lahf
00007a44d59d1431  seto al
00007a44d59d1434  mov [r15+0x108], eax
00007a44d59d143b  mov eax, [r15+0x108]
00007a44d59d1442  sahf
00007a44d59d1443  cmc
00007a44d59d1444  jbe 0x00007A44D59D1476
00007a44d59d1446  cmp dword ptr [r15+0x318], 0x00
00007a44d59d144e  jz 0x00007A44D59D1220
00007a44d59d1454  nop [rax+rax*1], ax
00007a44d59d145d  nop [rax+rax*1], eax
00007a44d59d1465  mov eax, 0x410390
00007a44d59d146a  mov [r15+0x100], rax
00007a44d59d1471  jmp 0x00007A44D57FE110
00007a44d59d1476  cmp dword ptr [r15+0x318], 0x00
00007a44d59d147e  jz 0x00007A44D59D14C0
00007a44d59d1484  nop [rax+rax*1], ax
00007a44d59d148d  nop [rax+rax*1], eax
00007a44d59d1495  mov eax, 0x410368
00007a44d59d149a  mov [r15+0x100], rax
00007a44d59d14a1  jmp 0x00007A44D57FE110
00007a44d59d14a6  int3
00007a44d59d14a7  call 0x00007A44D58B4690
00007a44d59d14ac  jmp 0x00007A44D59D140E
00007a44d59d14b1  int3
00007a44d59d14b2  nop [rax+rax*1], ax
00007a44d59d14bb  nop [rax+rax*1], eax
00007a44d59d14c0  mov rax, [r15+0x40]
00007a44d59d14c4  lea r14, [rax+0x01]
00007a44d59d14c8  mov [r15+0x40], r14
00007a44d59d14cc  mov rax, [r15+0x50]
00007a44d59d14d0  mov r12d, eax
00007a44d59d14d3  mov r12d, r12d
00007a44d59d14d6  shl r12, 0x02
00007a44d59d14da  mov rax, [r15+0x98]
00007a44d59d14e1  lea r11, [rax+r12*1]
00007a44d59d14e5  mov eax, [r15+0x48]
00007a44d59d14e9  mov [r13+r11*1], eax
00007a44d59d14ee  xor eax, eax
00007a44d59d14f0  mov r12d, 0x400
00007a44d59d14f6  cmp r14, r12
00007a44d59d14f9  cmc
00007a44d59d14fa  lahf
00007a44d59d14fb  seto al
00007a44d59d14fe  mov [r15+0x108], eax
00007a44d59d1505  mov eax, [r15+0x108]
00007a44d59d150c  sahf
00007a44d59d150d  jz 0x00007A44D59D153F
00007a44d59d150f  cmp dword ptr [r15+0x318], 0x00
00007a44d59d1517  jz 0x00007A44D59D1120
00007a44d59d151d  nop [rax+rax*1], ax
00007a44d59d1526  nop [rax+rax*1], eax
00007a44d59d152e  mov eax, 0x410378
00007a44d59d1533  mov [r15+0x100], rax
00007a44d59d153a  jmp 0x00007A44D57FE110
00007a44d59d153f  cmp dword ptr [r15+0x318], 0x00
00007a44d59d1547  jz 0x00007A44D59D1580
00007a44d59d154d  nop [rax+rax*1], ax
00007a44d59d1556  nop [rax+rax*1], eax
00007a44d59d155e  mov eax, 0x4103A0
00007a44d59d1563  mov [r15+0x100], rax
00007a44d59d156a  jmp 0x00007A44D57FE110
00007a44d59d156f  int3
00007a44d59d1570  call 0x00007A44D58A4270
00007a44d59d1575  jmp 0x00007A44D59D14EE
00007a44d59d157a  int3
00007a44d59d157b  nop [rax+rax*1], eax
00007a44d59d1580  mov qword ptr [r15+0x40], 0x430000
00007a44d59d1588  mov eax, 0x430C40
00007a44d59d158d  mov r14, [r13+rax*1]
00007a44d59d1592  mov rax, [r15+0x98]
00007a44d59d1599  mov r12d, [r13+rax*1]
00007a44d59d159e  lea r11, [rax+0x04]
00007a44d59d15a2  mov eax, [r13+r11*1]
00007a44d59d15a7  mov r12d, r12d
00007a44d59d15aa  mov [r15+0x68], r12
00007a44d59d15ae  mov eax, eax
00007a44d59d15b0  mov [r15+0x60], rax
00007a44d59d15b4  mov rax, [r15+0x68]
00007a44d59d15b8  mov [r15+0x68], rax
00007a44d59d15bc  mov qword ptr [r15+0x58], 0x02
00007a44d59d15c4  mov [rsp+0x10], rax
00007a44d59d15c9  xor eax, eax
00007a44d59d15cb  mov r12d, 0x02
00007a44d59d15d1  mov r11d, 0x400
00007a44d59d15d7  cmp r12, r11
00007a44d59d15da  cmc
00007a44d59d15db  lahf
00007a44d59d15dc  seto al
00007a44d59d15df  mov [r15+0x108], eax
00007a44d59d15e6  mov rax, [r15+0x60]
00007a44d59d15ea  mov r12d, 0x02
00007a44d59d15f0  imul rax, r12
00007a44d59d15f4  mov [r15+0x50], rax
00007a44d59d15f8  mov rax, [rsp+0x10]
00007a44d59d15fd  lea r12, [rax+r14*1]
00007a44d59d1601  mov [r15+0x48], r12
00007a44d59d1605  mov eax, [r15+0x108]
00007a44d59d160c  sahf
00007a44d59d160d  jnz 0x00007A44D59D163F
00007a44d59d160f  cmp dword ptr [r15+0x318], 0x00
00007a44d59d1617  jz 0x00007A44D59D17B0
00007a44d59d161d  nop [rax+rax*1], ax
00007a44d59d1626  nop [rax+rax*1], eax
00007a44d59d162e  mov eax, 0x4103D0
00007a44d59d1633  mov [r15+0x100], rax
00007a44d59d163a  jmp 0x00007A44D57FE110
00007a44d59d163f  cmp dword ptr [r15+0x318], 0x00
00007a44d59d1647  jz 0x00007A44D59D1690
00007a44d59d164d  nop [rax+rax*1], ax
00007a44d59d1656  nop [rax+rax*1], eax
00007a44d59d165e  mov eax, 0x4103B0
00007a44d59d1663  mov [r15+0x100], rax
00007a44d59d166a  jmp 0x00007A44D57FE110
00007a44d59d166f  int3
00007a44d59d1670  call 0x00007A44D580DC20
00007a44d59d1675  jmp 0x00007A44D59D1592
00007a44d59d167a  call 0x00007A44D580B5E0
00007a44d59d167f  jmp 0x00007A44D59D159E
00007a44d59d1684  call 0x00007A44D58A3D90
00007a44d59d1689  jmp 0x00007A44D59D15A7
00007a44d59d168e  int3
00007a44d59d168f  nop
00007a44d59d1690  mov rax, [r15+0x98]
00007a44d59d1697  mov r14, [r15+0x58]
00007a44d59d169b  mov [rsp+0x10], r14
00007a44d59d16a0  shl r14, 0x02
00007a44d59d16a4  lea r12, [rax+r14*1]
00007a44d59d16a8  mov eax, [r13+r12*1]
00007a44d59d16ad  lea r14, [r12+0x04]
00007a44d59d16b2  mov r12d, [r13+r14*1]
00007a44d59d16b7  mov eax, eax
00007a44d59d16b9  mov [r15+0x68], rax
00007a44d59d16bd  mov r12d, r12d
00007a44d59d16c0  mov [r15+0x60], r12
00007a44d59d16c4  mov rax, [r15+0x68]
00007a44d59d16c8  mov [rsp+0x20], rax
00007a44d59d16cd  mov r14, [rsp+0x10]
00007a44d59d16d2  imul rax, r14
00007a44d59d16d6  mov r12, [rsp+0x20]
00007a44d59d16db  lea r11, [r12+rax*1]
00007a44d59d16df  mov [r15+0x68], r11
00007a44d59d16e3  lea rax, [r14+0x02]
00007a44d59d16e7  mov [r15+0x58], rax
00007a44d59d16eb  mov [rsp+0x10], rax
00007a44d59d16f0  xor eax, eax
00007a44d59d16f2  mov r14, [rsp+0x10]
00007a44d59d16f7  mov r12d, 0x400
00007a44d59d16fd  cmp r14, r12
00007a44d59d1700  cmc
00007a44d59d1701  lahf
00007a44d59d1702  seto al
00007a44d59d1705  mov [r15+0x108], eax
00007a44d59d170c  mov rax, [r15+0x50]
00007a44d59d1710  mov r12, [r15+0x60]
00007a44d59d1714  imul r14, r12
00007a44d59d1718  lea r12, [rax+r14*1]
00007a44d59d171c  mov [r15+0x50], r12
00007a44d59d1720  mov rax, [r15+0x48]
00007a44d59d1724  lea r14, [r11+rax*1]
00007a44d59d1728  mov [r15+0x48], r14
00007a44d59d172c  mov eax, [r15+0x108]
00007a44d59d1733  sahf
00007a44d59d1734  jnz 0x00007A44D59D1766
00007a44d59d1736  cmp dword ptr [r15+0x318], 0x00
00007a44d59d173e  jz 0x00007A44D59D17B0
00007a44d59d1744  nop [rax+rax*1], ax
00007a44d59d174d  nop [rax+rax*1], eax
00007a44d59d1755  mov eax, 0x4103D0
00007a44d59d175a  mov [r15+0x100], rax
00007a44d59d1761  jmp 0x00007A44D57FE110
00007a44d59d1766  cmp dword ptr [r15+0x318], 0x00
00007a44d59d176e  jz 0x00007A44D59D1690
00007a44d59d1774  nop [rax+rax*1], ax
00007a44d59d177d  nop [rax+rax*1], eax
00007a44d59d1785  mov eax, 0x4103B0
00007a44d59d178a  mov [r15+0x100], rax
00007a44d59d1791  jmp 0x00007A44D57FE110
00007a44d59d1796  int3
00007a44d59d1797  call 0x00007A44D58B4690
00007a44d59d179c  jmp 0x00007A44D59D16AD
00007a44d59d17a1  call 0x00007A44D58E26A0
00007a44d59d17a6  jmp 0x00007A44D59D16B7
00007a44d59d17ab  int3
00007a44d59d17ac  nop [rax], eax
00007a44d59d17b0  mov qword ptr [r15+0x98], 0x00
00007a44d59d17bb  mov rax, [r15+0x50]
00007a44d59d17bf  mov r14, [r15+0x48]
00007a44d59d17c3  lea r12, [rax+r14*1]
00007a44d59d17c7  mov [r15+0x48], r12
00007a44d59d17cb  mov rax, [r15+0x40]
00007a44d59d17cf  lea r14, [rax+0xC40]
00007a44d59d17d6  mov [r13+r14*1], r12
00007a44d59d17db  mov qword ptr [r15], 0x01
00007a44d59d17e2  mov qword ptr [r15+0xF0], 0x4103E8
00007a44d59d17ed  mov r14d, [r15+0x320]
00007a44d59d17f4  mov eax, 0x4103E8
00007a44d59d17f9  mov rcx, 0x7A44D59D1860
00007a44d59d1803  mov [r15+r14*8+0x328], rax
00007a44d59d180b  mov [r15+r14*8+0x368], rcx
00007a44d59d1813  add r14d, 0x01
00007a44d59d1817  and r14d, 0x07
00007a44d59d181b  mov [r15+0x320], r14d
00007a44d59d1822  cmp dword ptr [r15+0x318], 0x00
00007a44d59d182a  jz 0x00007A44D59D0F20
00007a44d59d1830  nop [rax+rax*1], ax
00007a44d59d1839  nop [rax+rax*1], eax
00007a44d59d1841  mov eax, 0x410938
00007a44d59d1846  mov [r15+0x100], rax
00007a44d59d184d  jmp 0x00007A44D57FE110
00007a44d59d1852  int3
00007a44d59d1853  call 0x00007A44D58E2CE0
00007a44d59d1858  jmp 0x00007A44D59D17DB
00007a44d59d185d  int3
00007a44d59d185e  nop
00007a44d59d1860  mov eax, [r15+0x98]
00007a44d59d1867  lea r14d, [eax+0x01]
00007a44d59d186c  mov [rsp+0x10], r14d
00007a44d59d1871  mov r14d, r14d
00007a44d59d1874  mov [r15+0x98], r14
00007a44d59d187b  xor eax, eax
00007a44d59d187d  mov r14d, [rsp+0x10]
00007a44d59d1882  cmp r14d, 0x10000
00007a44d59d1889  cmc
00007a44d59d188a  lahf
00007a44d59d188b  seto al
00007a44d59d188e  mov [r15+0x108], eax
00007a44d59d1895  mov eax, [r15+0x108]
00007a44d59d189c  sahf
00007a44d59d189d  jnz 0x00007A44D59D18CF
00007a44d59d189f  cmp dword ptr [r15+0x318], 0x00
00007a44d59d18a7  jz 0x00007A44D59D19A0
00007a44d59d18ad  nop [rax+rax*1], ax
00007a44d59d18b6  nop [rax+rax*1], eax
00007a44d59d18be  mov eax, 0x4103F4
00007a44d59d18c3  mov [r15+0x100], rax
00007a44d59d18ca  jmp 0x00007A44D57FE110
00007a44d59d18cf  cmp dword ptr [r15+0x318], 0x00
00007a44d59d18d7  jz 0x00007A44D59D1910
00007a44d59d18dd  nop [rax+rax*1], ax
00007a44d59d18e6  nop [rax+rax*1], eax
00007a44d59d18ee  mov eax, 0x4103E0
00007a44d59d18f3  mov [r15+0x100], rax
00007a44d59d18fa  jmp 0x00007A44D57FE110
00007a44d59d18ff  int3
00007a44d59d1900  int3
00007a44d59d1901  nop [rax+rax*1], ax
00007a44d59d190a  nop [rax+rax*1], ax
00007a44d59d1910  mov eax, [r15]
00007a44d59d1913  mov r14d, [r15+0x98]
00007a44d59d191a  lea r12d, [eax+r14d*1]
00007a44d59d191f  mov r12d, r12d
00007a44d59d1922  mov [r15], r12
00007a44d59d1925  mov qword ptr [r15+0xF0], 0x4103E8
00007a44d59d1930  mov r14d, [r15+0x320]
00007a44d59d1937  mov eax, 0x4103E8
00007a44d59d193c  mov rcx, 0x7A44D59D1860
00007a44d59d1946  mov [r15+r14*8+0x328], rax
00007a44d59d194e  mov [r15+r14*8+0x368], rcx
00007a44d59d1956  add r14d, 0x01
00007a44d59d195a  and r14d, 0x07
00007a44d59d195e  mov [r15+0x320], r14d
00007a44d59d1965  cmp dword ptr [r15+0x318], 0x00
00007a44d59d196d  jz 0x00007A44D59D0F20
00007a44d59d1973  nop [rax+rax*1], ax
00007a44d59d197c  nop [rax+rax*1], eax
00007a44d59d1984  mov eax, 0x410938
00007a44d59d1989  mov [r15+0x100], rax
00007a44d59d1990  jmp 0x00007A44D57FE110
00007a44d59d1995  int3
00007a44d59d1996  int3
00007a44d59d1997  nop [rax+rax*1], ax
00007a44d59d19a0  vmovaps xmm1, [0x00007A44D55FE010]
00007a44d59d19a8  movq xmm1, xmm1
00007a44d59d19ac  movaps [r15+0x110], xmm1
00007a44d59d19b4  mov eax, 0x420AA0
00007a44d59d19b9  mov r14, [r13+rax*1]
00007a44d59d19be  movq xmm1, r14
00007a44d59d19c3  movaps [r15+0x120], xmm1
00007a44d59d19cb  vmovaps xmm1, [0x00007A44D55FE020]
00007a44d59d19d3  movq xmm1, xmm1
00007a44d59d19d7  movaps [r15+0x140], xmm1
00007a44d59d19df  vmovaps xmm1, [0x00007A44D55FE030]
00007a44d59d19e7  vpbroadcastq xmm1, xmm1
00007a44d59d19ec  movaps [r15+0x150], xmm1
00007a44d59d19f4  mov qword ptr [r15+0x40], 0x02
00007a44d59d19fc  vmovaps xmm15, [0x00007A44D55FE040]
00007a44d59d1a04  movq xmm15, xmm15
00007a44d59d1a09  movaps [r15+0x160], xmm15
00007a44d59d1a11  vmovaps xmm15, [0x00007A44D55FE050]
00007a44d59d1a19  vpbroadcastq xmm15, xmm15
00007a44d59d1a1e  movaps [r15+0x130], xmm15
00007a44d59d1a26  mov rax, [r15+0x40]
00007a44d59d1a2a  vmovq xmm14, rax
00007a44d59d1a2f  vpbroadcastq xmm14, xmm14
00007a44d59d1a34  movaps [r15+0x170], xmm14
00007a44d59d1a3c  mov eax, 0x4209D0
00007a44d59d1a41  movups xmm13, [r13+rax*1]
00007a44d59d1a47  mov qword ptr [r15+0x40], 0x431D90
00007a44d59d1a4f  mov eax, [r15]
00007a44d59d1a52  mov r14d, 0x430C48
00007a44d59d1a58  mov [r13+r14*1], eax
00007a44d59d1a5d  mov qword ptr [r15+0x50], 0x431F90
00007a44d59d1a65  vpmovqd xmm12, xmm13
00007a44d59d1a6b  pxor xmm11, xmm11
00007a44d59d1a70  punpcklqdq xmm12, xmm11
00007a44d59d1a75  movaps [r15+0x210], xmm12
00007a44d59d1a7d  movq xmm12, qword ptr [r15+0x140]
00007a44d59d1a86  movq xmm11, qword ptr [r15+0x120]
00007a44d59d1a8f  psubd xmm12, xmm11
00007a44d59d1a94  movq xmm12, xmm12
00007a44d59d1a99  paddq xmm13, xmm14
00007a44d59d1a9e  movaps [r15+0x180], xmm13
00007a44d59d1aa6  movq xmm14, qword ptr [r15+0x160]
00007a44d59d1aaf  paddd xmm11, xmm14
00007a44d59d1ab4  movq xmm11, xmm11
00007a44d59d1ab9  movq xmm11, xmm11
00007a44d59d1abe  movaps [r15+0x120], xmm11
00007a44d59d1ac6  pmovzxdq xmm12, xmm12
00007a44d59d1acc  psllq xmm12, 0x00
00007a44d59d1ad2  movq xmm14, qword ptr [r15+0x210]
00007a44d59d1adb  movq xmm13, qword ptr [r15+0x110]
00007a44d59d1ae4  paddd xmm14, xmm13
00007a44d59d1ae9  movq xmm14, xmm14
00007a44d59d1aee  vcvtuqq2pd xmm12, xmm12
00007a44d59d1af4  pmovzxdq xmm14, xmm14
00007a44d59d1afa  psllq xmm14, 0x00
00007a44d59d1b00  vcvtuqq2pd xmm14, xmm14
00007a44d59d1b06  movaps xmm13, xmm12
00007a44d59d1b0a  mulpd xmm13, xmm1
00007a44d59d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007a44d59d1b15  ptest xmm11, xmm11
00007a44d59d1b1b  jnz 0x00007A44D59D1C0F
00007a44d59d1b21  movaps [r15+0x220], xmm13
00007a44d59d1b29  mov eax, 0x431F90
00007a44d59d1b2e  movups [r13+rax*1], xmm13
00007a44d59d1b34  movaps xmm1, xmm14
00007a44d59d1b38  mulpd xmm1, xmm15
00007a44d59d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007a44d59d1b42  ptest xmm13, xmm13
00007a44d59d1b48  jnz 0x00007A44D59D1D5C
00007a44d59d1b4e  movaps [r15+0x210], xmm1
00007a44d59d1b56  mov eax, 0x431D90
00007a44d59d1b5b  movups [r13+rax*1], xmm1
00007a44d59d1b61  mov qword ptr [r15+0x48], 0x10
00007a44d59d1b69  xor eax, eax
00007a44d59d1b6b  mov r14d, 0x10
00007a44d59d1b71  mov r12d, 0x200
00007a44d59d1b77  cmp r14, r12
00007a44d59d1b7a  cmc
00007a44d59d1b7b  lahf
00007a44d59d1b7c  seto al
00007a44d59d1b7f  mov [r15+0x108], eax
00007a44d59d1b86  mov eax, [r15+0x108]
00007a44d59d1b8d  sahf
00007a44d59d1b8e  jnz 0x00007A44D59D1BC0
00007a44d59d1b90  cmp dword ptr [r15+0x318], 0x00
00007a44d59d1b98  jz 0x00007A44D59D2300
00007a44d59d1b9e  nop [rax+rax*1], ax
00007a44d59d1ba7  nop [rax+rax*1], eax
00007a44d59d1baf  mov eax, 0x410480
00007a44d59d1bb4  mov [r15+0x100], rax
00007a44d59d1bbb  jmp 0x00007A44D57FE110
00007a44d59d1bc0  cmp dword ptr [r15+0x318], 0x00
00007a44d59d1bc8  jz 0x00007A44D59D1EB0
00007a44d59d1bce  nop [rax+rax*1], ax
00007a44d59d1bd7  nop [rax+rax*1], eax
00007a44d59d1bdf  mov eax, 0x410440
00007a44d59d1be4  mov [r15+0x100], rax
00007a44d59d1beb  jmp 0x00007A44D57FE110
00007a44d59d1bf0  int3
00007a44d59d1bf1  call 0x00007A44D580DC20
00007a44d59d1bf6  jmp 0x00007A44D59D19BE
00007a44d59d1bfb  call 0x00007A44D580C260
00007a44d59d1c00  jmp 0x00007A44D59D1A47
00007a44d59d1c05  call 0x00007A44D58D5D70
00007a44d59d1c0a  jmp 0x00007A44D59D1A5D
00007a44d59d1c0f  sub rsp, 0x08
00007a44d59d1c13  push rax
00007a44d59d1c14  push rcx
00007a44d59d1c15  push rdx
00007a44d59d1c16  push rdi
00007a44d59d1c17  push rsi
00007a44d59d1c18  push r8
00007a44d59d1c1a  push r9
00007a44d59d1c1c  push r10
00007a44d59d1c1e  push r11
00007a44d59d1c20  sub rsp, 0xF0
00007a44d59d1c27  vmovaps [rsp], xmm0
00007a44d59d1c2c  vmovaps [rsp+0x10], xmm1
00007a44d59d1c32  vmovaps [rsp+0x20], xmm2
00007a44d59d1c38  vmovaps [rsp+0x30], xmm3
00007a44d59d1c3e  vmovaps [rsp+0x40], xmm4
00007a44d59d1c44  vmovaps [rsp+0x50], xmm5
00007a44d59d1c4a  vmovaps [rsp+0x60], xmm6
00007a44d59d1c50  vmovaps [rsp+0x70], xmm7
00007a44d59d1c56  vmovaps [rsp+0x80], xmm8
00007a44d59d1c5f  vmovaps [rsp+0x90], xmm9
00007a44d59d1c68  vmovaps [rsp+0xA0], xmm10
00007a44d59d1c71  vmovaps [rsp+0xB0], xmm11
00007a44d59d1c7a  vmovaps [rsp+0xC0], xmm12
00007a44d59d1c83  vmovaps [rsp+0xD0], xmm14
00007a44d59d1c8c  vmovaps [rsp+0xE0], xmm15
00007a44d59d1c95  sub rsp, 0x30
00007a44d59d1c99  movaps [rsp], xmm13
00007a44d59d1c9e  movaps [rsp+0x10], xmm12
00007a44d59d1ca4  movaps [rsp+0x20], xmm1
00007a44d59d1ca9  lea rdi, [rsp]
00007a44d59d1cad  mov esi, 0x00
00007a44d59d1cb2  mov rax, 0x56179A4B1530
00007a44d59d1cbc  call rax
00007a44d59d1cbe  movaps xmm13, [rsp]
00007a44d59d1cc3  add rsp, 0x30
00007a44d59d1cc7  vmovaps xmm0, [rsp]
00007a44d59d1ccc  vmovaps xmm1, [rsp+0x10]
00007a44d59d1cd2  vmovaps xmm2, [rsp+0x20]
00007a44d59d1cd8  vmovaps xmm3, [rsp+0x30]
00007a44d59d1cde  vmovaps xmm4, [rsp+0x40]
00007a44d59d1ce4  vmovaps xmm5, [rsp+0x50]
00007a44d59d1cea  vmovaps xmm6, [rsp+0x60]
00007a44d59d1cf0  vmovaps xmm7, [rsp+0x70]
00007a44d59d1cf6  vmovaps xmm8, [rsp+0x80]
00007a44d59d1cff  vmovaps xmm9, [rsp+0x90]
00007a44d59d1d08  vmovaps xmm10, [rsp+0xA0]
00007a44d59d1d11  vmovaps xmm11, [rsp+0xB0]
00007a44d59d1d1a  vmovaps xmm12, [rsp+0xC0]
00007a44d59d1d23  vmovaps xmm14, [rsp+0xD0]
00007a44d59d1d2c  vmovaps xmm15, [rsp+0xE0]
00007a44d59d1d35  add rsp, 0xF0
00007a44d59d1d3c  pop r11
00007a44d59d1d3e  pop r10
00007a44d59d1d40  pop r9
00007a44d59d1d42  pop r8
00007a44d59d1d44  pop rsi
00007a44d59d1d45  pop rdi
00007a44d59d1d46  pop rdx
00007a44d59d1d47  pop rcx
00007a44d59d1d48  pop rax
00007a44d59d1d49  add rsp, 0x08
00007a44d59d1d4d  jmp 0x00007A44D59D1B21
00007a44d59d1d52  call 0x00007A44D580C380
00007a44d59d1d57  jmp 0x00007A44D59D1B34
00007a44d59d1d5c  sub rsp, 0x08
00007a44d59d1d60  push rax
00007a44d59d1d61  push rcx
00007a44d59d1d62  push rdx
00007a44d59d1d63  push rdi
00007a44d59d1d64  push rsi
00007a44d59d1d65  push r8
00007a44d59d1d67  push r9
00007a44d59d1d69  push r10
00007a44d59d1d6b  push r11
00007a44d59d1d6d  sub rsp, 0xF0
00007a44d59d1d74  vmovaps [rsp], xmm0
00007a44d59d1d79  vmovaps [rsp+0x10], xmm2
00007a44d59d1d7f  vmovaps [rsp+0x20], xmm3
00007a44d59d1d85  vmovaps [rsp+0x30], xmm4
00007a44d59d1d8b  vmovaps [rsp+0x40], xmm5
00007a44d59d1d91  vmovaps [rsp+0x50], xmm6
00007a44d59d1d97  vmovaps [rsp+0x60], xmm7
00007a44d59d1d9d  vmovaps [rsp+0x70], xmm8
00007a44d59d1da3  vmovaps [rsp+0x80], xmm9
00007a44d59d1dac  vmovaps [rsp+0x90], xmm10
00007a44d59d1db5  vmovaps [rsp+0xA0], xmm11
00007a44d59d1dbe  vmovaps [rsp+0xB0], xmm12
00007a44d59d1dc7  vmovaps [rsp+0xC0], xmm13
00007a44d59d1dd0  vmovaps [rsp+0xD0], xmm14
00007a44d59d1dd9  vmovaps [rsp+0xE0], xmm15
00007a44d59d1de2  sub rsp, 0x30
00007a44d59d1de6  movaps [rsp], xmm1
00007a44d59d1dea  movaps [rsp+0x10], xmm14
00007a44d59d1df0  movaps [rsp+0x20], xmm15
00007a44d59d1df6  lea rdi, [rsp]
00007a44d59d1dfa  mov esi, 0x00
00007a44d59d1dff  mov rax, 0x56179A4B1530
00007a44d59d1e09  call rax
00007a44d59d1e0b  movaps xmm1, [rsp]
00007a44d59d1e0f  add rsp, 0x30
00007a44d59d1e13  vmovaps xmm0, [rsp]
00007a44d59d1e18  vmovaps xmm2, [rsp+0x10]
00007a44d59d1e1e  vmovaps xmm3, [rsp+0x20]
00007a44d59d1e24  vmovaps xmm4, [rsp+0x30]
00007a44d59d1e2a  vmovaps xmm5, [rsp+0x40]
00007a44d59d1e30  vmovaps xmm6, [rsp+0x50]
00007a44d59d1e36  vmovaps xmm7, [rsp+0x60]
00007a44d59d1e3c  vmovaps xmm8, [rsp+0x70]
00007a44d59d1e42  vmovaps xmm9, [rsp+0x80]
00007a44d59d1e4b  vmovaps xmm10, [rsp+0x90]
00007a44d59d1e54  vmovaps xmm11, [rsp+0xA0]
00007a44d59d1e5d  vmovaps xmm12, [rsp+0xB0]
00007a44d59d1e66  vmovaps xmm13, [rsp+0xC0]
00007a44d59d1e6f  vmovaps xmm14, [rsp+0xD0]
00007a44d59d1e78  vmovaps xmm15, [rsp+0xE0]
00007a44d59d1e81  add rsp, 0xF0
00007a44d59d1e88  pop r11
00007a44d59d1e8a  pop r10
00007a44d59d1e8c  pop r9
00007a44d59d1e8e  pop r8
00007a44d59d1e90  pop rsi
00007a44d59d1e91  pop rdi
00007a44d59d1e92  pop rdx
00007a44d59d1e93  pop rcx
00007a44d59d1e94  pop rax
00007a44d59d1e95  add rsp, 0x08
00007a44d59d1e99  jmp 0x00007A44D59D1B4E
00007a44d59d1e9e  call 0x00007A44D57FF540
00007a44d59d1ea3  jmp 0x00007A44D59D1B61
00007a44d59d1ea8  int3
00007a44d59d1ea9  nop [rax], eax
00007a44d59d1eb0  movaps xmm1, [r15+0x180]
00007a44d59d1eb8  vpmovqd xmm15, xmm1
00007a44d59d1ebe  pxor xmm14, xmm14
00007a44d59d1ec3  punpcklqdq xmm15, xmm14
00007a44d59d1ec8  movaps [r15+0x210], xmm15
00007a44d59d1ed0  movq xmm15, qword ptr [r15+0x140]
00007a44d59d1ed9  movq xmm14, qword ptr [r15+0x120]
00007a44d59d1ee2  psubd xmm15, xmm14
00007a44d59d1ee7  movq xmm15, xmm15
00007a44d59d1eec  movaps xmm13, [r15+0x170]
00007a44d59d1ef4  paddq xmm1, xmm13
00007a44d59d1ef9  movaps [r15+0x180], xmm1
00007a44d59d1f01  movq xmm1, qword ptr [r15+0x160]
00007a44d59d1f0a  paddd xmm14, xmm1
00007a44d59d1f0f  movq xmm14, xmm14
00007a44d59d1f14  movq xmm14, xmm14
00007a44d59d1f19  movaps [r15+0x120], xmm14
00007a44d59d1f21  pmovzxdq xmm15, xmm15
00007a44d59d1f27  psllq xmm15, 0x00
00007a44d59d1f2d  movq xmm1, qword ptr [r15+0x210]
00007a44d59d1f36  movq xmm14, qword ptr [r15+0x110]
00007a44d59d1f3f  paddd xmm1, xmm14
00007a44d59d1f44  movq xmm1, xmm1
00007a44d59d1f48  vcvtuqq2pd xmm15, xmm15
00007a44d59d1f4e  pmovzxdq xmm1, xmm1
00007a44d59d1f53  psllq xmm1, 0x00
00007a44d59d1f58  vcvtuqq2pd xmm1, xmm1
00007a44d59d1f5e  movaps xmm14, [r15+0x150]
00007a44d59d1f66  movaps xmm13, xmm15
00007a44d59d1f6a  mulpd xmm13, xmm14
00007a44d59d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d1f75  ptest xmm12, xmm12
00007a44d59d1f7b  jnz 0x00007A44D59D205E
00007a44d59d1f81  movaps [r15+0x220], xmm13
00007a44d59d1f89  mov rax, [r15+0x48]
00007a44d59d1f8d  mov r14, [r15+0x50]
00007a44d59d1f91  lea r12, [r14+rax*1]
00007a44d59d1f95  movups [r13+r12*1], xmm13
00007a44d59d1f9b  movaps xmm15, [r15+0x130]
00007a44d59d1fa3  movaps xmm14, xmm1
00007a44d59d1fa7  mulpd xmm14, xmm15
00007a44d59d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007a44d59d1fb2  ptest xmm13, xmm13
00007a44d59d1fb8  jnz 0x00007A44D59D21AC
00007a44d59d1fbe  movaps [r15+0x210], xmm14
00007a44d59d1fc6  mov r14, [r15+0x40]
00007a44d59d1fca  lea r12, [r14+rax*1]
00007a44d59d1fce  movups [r13+r12*1], xmm14
00007a44d59d1fd4  lea r14, [rax+0x10]
00007a44d59d1fd8  mov [r15+0x48], r14
00007a44d59d1fdc  xor eax, eax
00007a44d59d1fde  mov r12d, 0x200
00007a44d59d1fe4  cmp r14, r12
00007a44d59d1fe7  cmc
00007a44d59d1fe8  lahf
00007a44d59d1fe9  seto al
00007a44d59d1fec  mov [r15+0x108], eax
00007a44d59d1ff3  mov eax, [r15+0x108]
00007a44d59d1ffa  sahf
00007a44d59d1ffb  jnz 0x00007A44D59D202D
00007a44d59d1ffd  cmp dword ptr [r15+0x318], 0x00
00007a44d59d2005  jz 0x00007A44D59D2300
00007a44d59d200b  nop [rax+rax*1], ax
00007a44d59d2014  nop [rax+rax*1], eax
00007a44d59d201c  mov eax, 0x410480
00007a44d59d2021  mov [r15+0x100], rax
00007a44d59d2028  jmp 0x00007A44D57FE110
00007a44d59d202d  cmp dword ptr [r15+0x318], 0x00
00007a44d59d2035  jz 0x00007A44D59D1EB0
00007a44d59d203b  nop [rax+rax*1], ax
00007a44d59d2044  nop [rax+rax*1], eax
00007a44d59d204c  mov eax, 0x410440
00007a44d59d2051  mov [r15+0x100], rax
00007a44d59d2058  jmp 0x00007A44D57FE110
00007a44d59d205d  int3
00007a44d59d205e  sub rsp, 0x08
00007a44d59d2062  push rax
00007a44d59d2063  push rcx
00007a44d59d2064  push rdx
00007a44d59d2065  push rdi
00007a44d59d2066  push rsi
00007a44d59d2067  push r8
00007a44d59d2069  push r9
00007a44d59d206b  push r10
00007a44d59d206d  push r11
00007a44d59d206f  sub rsp, 0xF0
00007a44d59d2076  vmovaps [rsp], xmm0
00007a44d59d207b  vmovaps [rsp+0x10], xmm1
00007a44d59d2081  vmovaps [rsp+0x20], xmm2
00007a44d59d2087  vmovaps [rsp+0x30], xmm3
00007a44d59d208d  vmovaps [rsp+0x40], xmm4
00007a44d59d2093  vmovaps [rsp+0x50], xmm5
00007a44d59d2099  vmovaps [rsp+0x60], xmm6
00007a44d59d209f  vmovaps [rsp+0x70], xmm7
00007a44d59d20a5  vmovaps [rsp+0x80], xmm8
00007a44d59d20ae  vmovaps [rsp+0x90], xmm9
00007a44d59d20b7  vmovaps [rsp+0xA0], xmm10
00007a44d59d20c0  vmovaps [rsp+0xB0], xmm11
00007a44d59d20c9  vmovaps [rsp+0xC0], xmm12
00007a44d59d20d2  vmovaps [rsp+0xD0], xmm14
00007a44d59d20db  vmovaps [rsp+0xE0], xmm15
00007a44d59d20e4  sub rsp, 0x30
00007a44d59d20e8  movaps [rsp], xmm13
00007a44d59d20ed  movaps [rsp+0x10], xmm15
00007a44d59d20f3  movaps [rsp+0x20], xmm14
00007a44d59d20f9  lea rdi, [rsp]
00007a44d59d20fd  mov esi, 0x00
00007a44d59d2102  mov rax, 0x56179A4B1530
00007a44d59d210c  call rax
00007a44d59d210e  movaps xmm13, [rsp]
00007a44d59d2113  add rsp, 0x30
00007a44d59d2117  vmovaps xmm0, [rsp]
00007a44d59d211c  vmovaps xmm1, [rsp+0x10]
00007a44d59d2122  vmovaps xmm2, [rsp+0x20]
00007a44d59d2128  vmovaps xmm3, [rsp+0x30]
00007a44d59d212e  vmovaps xmm4, [rsp+0x40]
00007a44d59d2134  vmovaps xmm5, [rsp+0x50]
00007a44d59d213a  vmovaps xmm6, [rsp+0x60]
00007a44d59d2140  vmovaps xmm7, [rsp+0x70]
00007a44d59d2146  vmovaps xmm8, [rsp+0x80]
00007a44d59d214f  vmovaps xmm9, [rsp+0x90]
00007a44d59d2158  vmovaps xmm10, [rsp+0xA0]
00007a44d59d2161  vmovaps xmm11, [rsp+0xB0]
00007a44d59d216a  vmovaps xmm12, [rsp+0xC0]
00007a44d59d2173  vmovaps xmm14, [rsp+0xD0]
00007a44d59d217c  vmovaps xmm15, [rsp+0xE0]
00007a44d59d2185  add rsp, 0xF0
00007a44d59d218c  pop r11
00007a44d59d218e  pop r10
00007a44d59d2190  pop r9
00007a44d59d2192  pop r8
00007a44d59d2194  pop rsi
00007a44d59d2195  pop rdi
00007a44d59d2196  pop rdx
00007a44d59d2197  pop rcx
00007a44d59d2198  pop rax
00007a44d59d2199  add rsp, 0x08
00007a44d59d219d  jmp 0x00007A44D59D1F81
00007a44d59d21a2  call 0x00007A44D58C2240
00007a44d59d21a7  jmp 0x00007A44D59D1F9B
00007a44d59d21ac  sub rsp, 0x08
00007a44d59d21b0  push rax
00007a44d59d21b1  push rcx
00007a44d59d21b2  push rdx
00007a44d59d21b3  push rdi
00007a44d59d21b4  push rsi
00007a44d59d21b5  push r8
00007a44d59d21b7  push r9
00007a44d59d21b9  push r10
00007a44d59d21bb  push r11
00007a44d59d21bd  sub rsp, 0xF0
00007a44d59d21c4  vmovaps [rsp], xmm0
00007a44d59d21c9  vmovaps [rsp+0x10], xmm1
00007a44d59d21cf  vmovaps [rsp+0x20], xmm2
00007a44d59d21d5  vmovaps [rsp+0x30], xmm3
00007a44d59d21db  vmovaps [rsp+0x40], xmm4
00007a44d59d21e1  vmovaps [rsp+0x50], xmm5
00007a44d59d21e7  vmovaps [rsp+0x60], xmm6
00007a44d59d21ed  vmovaps [rsp+0x70], xmm7
00007a44d59d21f3  vmovaps [rsp+0x80], xmm8
00007a44d59d21fc  vmovaps [rsp+0x90], xmm9
00007a44d59d2205  vmovaps [rsp+0xA0], xmm10
00007a44d59d220e  vmovaps [rsp+0xB0], xmm11
00007a44d59d2217  vmovaps [rsp+0xC0], xmm12
00007a44d59d2220  vmovaps [rsp+0xD0], xmm13
00007a44d59d2229  vmovaps [rsp+0xE0], xmm15
00007a44d59d2232  sub rsp, 0x30
00007a44d59d2236  movaps [rsp], xmm14
00007a44d59d223b  movaps [rsp+0x10], xmm1
00007a44d59d2240  movaps [rsp+0x20], xmm15
00007a44d59d2246  lea rdi, [rsp]
00007a44d59d224a  mov esi, 0x00
00007a44d59d224f  mov rax, 0x56179A4B1530
00007a44d59d2259  call rax
00007a44d59d225b  movaps xmm14, [rsp]
00007a44d59d2260  add rsp, 0x30
00007a44d59d2264  vmovaps xmm0, [rsp]
00007a44d59d2269  vmovaps xmm1, [rsp+0x10]
00007a44d59d226f  vmovaps xmm2, [rsp+0x20]
00007a44d59d2275  vmovaps xmm3, [rsp+0x30]
00007a44d59d227b  vmovaps xmm4, [rsp+0x40]
00007a44d59d2281  vmovaps xmm5, [rsp+0x50]
00007a44d59d2287  vmovaps xmm6, [rsp+0x60]
00007a44d59d228d  vmovaps xmm7, [rsp+0x70]
00007a44d59d2293  vmovaps xmm8, [rsp+0x80]
00007a44d59d229c  vmovaps xmm9, [rsp+0x90]
00007a44d59d22a5  vmovaps xmm10, [rsp+0xA0]
00007a44d59d22ae  vmovaps xmm11, [rsp+0xB0]
00007a44d59d22b7  vmovaps xmm12, [rsp+0xC0]
00007a44d59d22c0  vmovaps xmm13, [rsp+0xD0]
00007a44d59d22c9  vmovaps xmm15, [rsp+0xE0]
00007a44d59d22d2  add rsp, 0xF0
00007a44d59d22d9  pop r11
00007a44d59d22db  pop r10
00007a44d59d22dd  pop r9
00007a44d59d22df  pop r8
00007a44d59d22e1  pop rsi
00007a44d59d22e2  pop rdi
00007a44d59d22e3  pop rdx
00007a44d59d22e4  pop rcx
00007a44d59d22e5  pop rax
00007a44d59d22e6  add rsp, 0x08
00007a44d59d22ea  jmp 0x00007A44D59D1FBE
00007a44d59d22ef  call 0x00007A44D58C34C0
00007a44d59d22f4  jmp 0x00007A44D59D1FD4
00007a44d59d22f9  int3
00007a44d59d22fa  nop [rax+rax*1], ax
00007a44d59d2300  mov rax, [r15+0x50]
00007a44d59d2304  movups xmm1, [r13+rax*1]
00007a44d59d230a  lea r14, [rax+0x10]
00007a44d59d230e  movups xmm15, [r13+r14*1]
00007a44d59d2314  mov qword ptr [r15+0x48], 0x00
00007a44d59d231c  lea r14, [rax+0x40]
00007a44d59d2320  movups xmm14, [r13+r14*1]
00007a44d59d2326  lea r14, [rax+0x50]
00007a44d59d232a  movups xmm13, [r13+r14*1]
00007a44d59d2330  lea r14, [rax+0x80]
00007a44d59d2337  movups xmm12, [r13+r14*1]
00007a44d59d233d  lea r14, [rax+0x90]
00007a44d59d2344  movups xmm11, [r13+r14*1]
00007a44d59d234a  mov r14, [r15+0xF8]
00007a44d59d2351  movups [r13+r14*1], xmm1
00007a44d59d2357  lea r12, [rax+0x20]
00007a44d59d235b  movups xmm1, [r13+r12*1]
00007a44d59d2361  lea r12, [rax+0x30]
00007a44d59d2365  movups xmm10, [r13+r12*1]
00007a44d59d236b  lea r12, [rax+0xC0]
00007a44d59d2372  movups xmm9, [r13+r12*1]
00007a44d59d2378  lea r12, [rax+0xD0]
00007a44d59d237f  movups xmm8, [r13+r12*1]
00007a44d59d2385  lea r12, [rax+0x100]
00007a44d59d238c  movups xmm7, [r13+r12*1]
00007a44d59d2392  lea r12, [rax+0x110]
00007a44d59d2399  movups xmm6, [r13+r12*1]
00007a44d59d239f  lea r12, [rax+0x140]
00007a44d59d23a6  movups xmm5, [r13+r12*1]
00007a44d59d23ac  lea r12, [rax+0x150]
00007a44d59d23b3  movups xmm4, [r13+r12*1]
00007a44d59d23b9  lea r12, [r14+0xB0]
00007a44d59d23c0  movups [r13+r12*1], xmm10
00007a44d59d23c6  lea r12, [r14+0xC0]
00007a44d59d23cd  movups [r13+r12*1], xmm1
00007a44d59d23d3  lea r12, [rax+0x180]
00007a44d59d23da  movups xmm1, [r13+r12*1]
00007a44d59d23e0  lea r12, [rax+0x190]
00007a44d59d23e7  movups xmm10, [r13+r12*1]
00007a44d59d23ed  lea r12, [rax+0x1C0]
00007a44d59d23f4  movups xmm3, [r13+r12*1]
00007a44d59d23fa  lea r12, [rax+0x1D0]
00007a44d59d2401  movups xmm2, [r13+r12*1]
00007a44d59d2407  lea r12, [rax+0x60]
00007a44d59d240b  vmovaps [rsp+0x10], xmm1
00007a44d59d2411  movups xmm1, [r13+r12*1]
00007a44d59d2417  lea r12, [rax+0x70]
00007a44d59d241b  vmovaps [rsp+0x20], xmm1
00007a44d59d2421  movups xmm1, [r13+r12*1]
00007a44d59d2427  lea r12, [r14+0x70]
00007a44d59d242b  movups [r13+r12*1], xmm10
00007a44d59d2431  lea r12, [r14+0x80]
00007a44d59d2438  vmovaps xmm10, [rsp+0x10]
00007a44d59d243e  movups [r13+r12*1], xmm10
00007a44d59d2444  lea r12, [rax+0xA0]
00007a44d59d244b  movups xmm10, [r13+r12*1]
00007a44d59d2451  lea r12, [rax+0xB0]
00007a44d59d2458  vmovaps [rsp+0x10], xmm1
00007a44d59d245e  movups xmm1, [r13+r12*1]
00007a44d59d2464  lea r12, [r14+0x90]
00007a44d59d246b  movups [r13+r12*1], xmm2
00007a44d59d2471  lea r12, [r14+0xA0]
00007a44d59d2478  movups [r13+r12*1], xmm3
00007a44d59d247e  lea r12, [rax+0xE0]
00007a44d59d2485  movups xmm3, [r13+r12*1]
00007a44d59d248b  lea r12, [rax+0xF0]
00007a44d59d2492  movups xmm2, [r13+r12*1]
00007a44d59d2498  lea r12, [rax+0x120]
00007a44d59d249f  vmovaps [rsp+0x30], xmm1
00007a44d59d24a5  movups xmm1, [r13+r12*1]
00007a44d59d24ab  lea r12, [rax+0x130]
00007a44d59d24b2  vmovaps [rsp+0x40], xmm1
00007a44d59d24b8  movups xmm1, [r13+r12*1]
00007a44d59d24be  vmovaps [rsp+0x50], xmm1
00007a44d59d24c4  vmovaps xmm1, [rsp+0x40]
00007a44d59d24ca  movaps [r15+0x190], xmm1
00007a44d59d24d2  lea r12, [rax+0x160]
00007a44d59d24d9  vmovaps [rsp+0x40], xmm1
00007a44d59d24df  movups xmm1, [r13+r12*1]
00007a44d59d24e5  lea r12, [rax+0x170]
00007a44d59d24ec  vmovaps [rsp+0x60], xmm1
00007a44d59d24f2  movups xmm1, [r13+r12*1]
00007a44d59d24f8  lea r12, [rax+0x1A0]
00007a44d59d24ff  vmovaps [rsp+0x70], xmm1
00007a44d59d2505  movups xmm1, [r13+r12*1]
00007a44d59d250b  lea r12, [rax+0x1B0]
00007a44d59d2512  vmovaps [rsp+0x80], xmm1
00007a44d59d251b  movups xmm1, [r13+r12*1]
00007a44d59d2521  lea r12, [rax+0x1E0]
00007a44d59d2528  vmovaps [rsp+0x90], xmm1
00007a44d59d2531  movups xmm1, [r13+r12*1]
00007a44d59d2537  lea r12, [rax+0x1F0]
00007a44d59d253e  vmovaps [rsp+0xA0], xmm1
00007a44d59d2547  movups xmm1, [r13+r12*1]
00007a44d59d254d  mov qword ptr [r15+0x50], 0x432190
00007a44d59d2555  lea rax, [r14+0x50]
00007a44d59d2559  vmovaps [rsp+0xB0], xmm1
00007a44d59d2562  vmovaps xmm1, [rsp+0x60]
00007a44d59d2568  movups [r13+rax*1], xmm1
00007a44d59d256e  lea rax, [r14+0x60]
00007a44d59d2572  movups [r13+rax*1], xmm5
00007a44d59d2578  lea rax, [r14+0x40]
00007a44d59d257c  vmovaps xmm1, [rsp+0x70]
00007a44d59d2582  movups [r13+rax*1], xmm1
00007a44d59d2588  lea rax, [r14+0x20]
00007a44d59d258c  vmovaps xmm1, [rsp+0xA0]
00007a44d59d2595  movups [r13+rax*1], xmm1
00007a44d59d259b  lea rax, [r14+0x30]
00007a44d59d259f  vmovaps xmm1, [rsp+0x90]
00007a44d59d25a8  movups [r13+rax*1], xmm1
00007a44d59d25ae  lea rax, [r14+0x10]
00007a44d59d25b2  vmovaps xmm1, [rsp+0xB0]
00007a44d59d25bb  movups [r13+rax*1], xmm1
00007a44d59d25c1  mov rax, [r15+0x40]
00007a44d59d25c5  vxorps xmm1, xmm1, xmm1
00007a44d59d25c9  vpbroadcastq xmm1, xmm1
00007a44d59d25ce  vxorps xmm5, xmm5, xmm5
00007a44d59d25d2  vpbroadcastq xmm5, xmm5
00007a44d59d25d7  lea r12, [rax+0x30]
00007a44d59d25db  mov r11, [r13+r12*1]
00007a44d59d25e0  lea r12, [rax+0x38]
00007a44d59d25e4  mov r10, [r13+r12*1]
00007a44d59d25e9  vmovaps [rsp+0x60], xmm1
00007a44d59d25ef  movq xmm1, r11
00007a44d59d25f4  vmovaps [rsp+0x70], xmm1
00007a44d59d25fa  movq xmm1, r10
00007a44d59d25ff  vmovaps [rsp+0x90], xmm1
00007a44d59d2608  vmovaps xmm1, [rsp+0x70]
00007a44d59d260e  movq xmm1, xmm1
00007a44d59d2612  vmovaps [rsp+0x70], xmm1
00007a44d59d2618  vmovaps xmm1, [rsp+0x90]
00007a44d59d2621  movq xmm1, xmm1
00007a44d59d2625  vmovaps [rsp+0x90], xmm1
00007a44d59d262e  movq xmm1, xmm1
00007a44d59d2632  movaps [r15+0x270], xmm1
00007a44d59d263a  vmovaps [rsp+0xA0], xmm7
00007a44d59d2643  vmovaps xmm1, [rsp+0xA0]
00007a44d59d264c  por xmm7, xmm1
00007a44d59d2650  lea r12, [rax+0x20]
00007a44d59d2654  mov r11, [r13+r12*1]
00007a44d59d2659  lea r12, [rax+0x28]
00007a44d59d265d  mov r10, [r13+r12*1]
00007a44d59d2662  movq xmm1, r11
00007a44d59d2667  vmovaps [rsp+0xA0], xmm1
00007a44d59d2670  movq xmm1, r10
00007a44d59d2675  vmovaps [rsp+0xB0], xmm1
00007a44d59d267e  vmovaps xmm1, [rsp+0xA0]
00007a44d59d2687  movq xmm1, xmm1
00007a44d59d268b  vmovaps [rsp+0xA0], xmm1
00007a44d59d2694  vmovaps xmm1, [rsp+0xB0]
00007a44d59d269d  movq xmm1, xmm1
00007a44d59d26a1  vmovaps [rsp+0xB0], xmm2
00007a44d59d26aa  vmovaps [rsp+0xC0], xmm1
00007a44d59d26b3  vmovaps xmm1, [rsp+0xB0]
00007a44d59d26bc  por xmm2, xmm1
00007a44d59d26c0  vmovaps [rsp+0xB0], xmm3
00007a44d59d26c9  vmovaps xmm1, [rsp+0xB0]
00007a44d59d26d2  por xmm3, xmm1
00007a44d59d26d6  vmovaps [rsp+0xB0], xmm4
00007a44d59d26df  vmovaps xmm1, [rsp+0xB0]
00007a44d59d26e8  por xmm4, xmm1
00007a44d59d26ec  vmovaps [rsp+0xB0], xmm9
00007a44d59d26f5  vmovaps xmm1, [rsp+0xB0]
00007a44d59d26fe  por xmm9, xmm1
00007a44d59d2703  lea r12, [rax+0x10]
00007a44d59d2707  mov r11, [r13+r12*1]
00007a44d59d270c  lea r12, [rax+0x18]
00007a44d59d2710  mov r10, [r13+r12*1]
00007a44d59d2715  movq xmm1, r11
00007a44d59d271a  vmovaps [rsp+0xB0], xmm1
00007a44d59d2723  movq xmm1, r10
00007a44d59d2728  vmovaps [rsp+0xD0], xmm1
00007a44d59d2731  vmovaps xmm1, [rsp+0xB0]
00007a44d59d273a  movq xmm1, xmm1
00007a44d59d273e  vmovaps [rsp+0xB0], xmm1
00007a44d59d2747  vmovaps xmm1, [rsp+0xD0]
00007a44d59d2750  movq xmm1, xmm1
00007a44d59d2754  vmovaps [rsp+0xD0], xmm1
00007a44d59d275d  vmovaps xmm1, [rsp+0x80]
00007a44d59d2766  vmovaps [rsp+0xE0], xmm15
00007a44d59d276f  vmovaps xmm15, [rsp+0x80]
00007a44d59d2778  por xmm1, xmm15
00007a44d59d277d  vmovaps xmm15, [rsp+0x10]
00007a44d59d2783  vmovaps [rsp+0x80], xmm1
00007a44d59d278c  vmovaps xmm1, [rsp+0x10]
00007a44d59d2792  por xmm15, xmm1
00007a44d59d2797  vmovaps xmm1, [rsp+0x20]
00007a44d59d279d  vmovaps [rsp+0x10], xmm15
00007a44d59d27a3  vmovaps xmm15, [rsp+0x20]
00007a44d59d27a9  por xmm1, xmm15
00007a44d59d27ae  vmovaps [rsp+0x20], xmm6
00007a44d59d27b4  vmovaps xmm15, [rsp+0x20]
00007a44d59d27ba  por xmm6, xmm15
00007a44d59d27bf  vmovaps [rsp+0x20], xmm11
00007a44d59d27c5  vmovaps xmm15, [rsp+0x20]
00007a44d59d27cb  por xmm11, xmm15
00007a44d59d27d0  vmovaps [rsp+0x20], xmm13
00007a44d59d27d6  vmovaps xmm15, [rsp+0x20]
00007a44d59d27dc  por xmm13, xmm15
00007a44d59d27e1  vmovaps [rsp+0x20], xmm14
00007a44d59d27e7  vmovaps xmm15, [rsp+0x20]
00007a44d59d27ed  por xmm14, xmm15
00007a44d59d27f2  mov r12, [r13+rax*1]
00007a44d59d27f7  vmovq xmm15, r12
00007a44d59d27fc  vpbroadcastq xmm15, xmm15
00007a44d59d2801  vmovaps [rsp+0x20], xmm1
00007a44d59d2807  vxorps xmm1, xmm1, xmm1
00007a44d59d280b  vpbroadcastq xmm1, xmm1
00007a44d59d2810  vmovaps [rsp+0xF0], xmm1
00007a44d59d2819  movups xmm1, [r13+r14*1]
00007a44d59d281f  vmovaps [rsp+0x100], xmm1
00007a44d59d2828  vxorps xmm1, xmm1, xmm1
00007a44d59d282c  vpbroadcastq xmm1, xmm1
00007a44d59d2831  lea r12, [rax+0x08]
00007a44d59d2835  mov rax, [r13+r12*1]
00007a44d59d283a  vmovaps [rsp+0x110], xmm1
00007a44d59d2843  movq xmm1, rax
00007a44d59d2848  movaps [r15+0x240], xmm1
00007a44d59d2850  mov qword ptr [r15+0x60], 0x432190
00007a44d59d2858  mov qword ptr [r15+0x58], 0x40
00007a44d59d2860  vmovaps xmm1, [rsp+0x60]
00007a44d59d2866  vmovaps [rsp+0x60], xmm15
00007a44d59d286c  vmovaps xmm15, [rsp+0x100]
00007a44d59d2875  vmovaps [rsp+0x100], xmm14
00007a44d59d287e  vmovaps xmm14, [rsp+0x60]
00007a44d59d2884  vmovaps [rsp+0x60], xmm13
00007a44d59d288a  vmovaps [rsp+0x120], xmm12
00007a44d59d2893  movaps xmm13, xmm1
00007a44d59d2897  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d289c  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d28a2  vptest xmm12, xmm12
00007a44d59d28a7  jnz 0x00007A44D59D3482
00007a44d59d28ad  vmovaps xmm1, [rsp+0xE0]
00007a44d59d28b6  movaps xmm15, xmm5
00007a44d59d28ba  vfmadd231pd xmm15, xmm1, xmm14
00007a44d59d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
00007a44d59d28c5  vptest xmm12, xmm12
00007a44d59d28ca  jnz 0x00007A44D59D35DB
00007a44d59d28d0  vmovaps xmm12, [rsp+0x50]
00007a44d59d28d6  vmovaps xmm5, [rsp+0x50]
00007a44d59d28dc  por xmm12, xmm5
00007a44d59d28e1  vmovaps xmm5, [rsp+0x30]
00007a44d59d28e7  vmovaps [rsp+0x50], xmm1
00007a44d59d28ed  vmovaps xmm1, [rsp+0x30]
00007a44d59d28f3  por xmm5, xmm1
00007a44d59d28f7  vmovaps [rsp+0x30], xmm10
00007a44d59d28fd  vmovaps xmm1, [rsp+0x30]
00007a44d59d2903  por xmm10, xmm1
00007a44d59d2908  vmovaps [rsp+0x30], xmm8
00007a44d59d290e  vmovaps xmm1, [rsp+0x30]
00007a44d59d2914  por xmm8, xmm1
00007a44d59d2919  vmovaps xmm1, [rsp+0x120]
00007a44d59d2922  vmovaps [rsp+0x30], xmm15
00007a44d59d2928  vmovaps xmm15, [rsp+0x120]
00007a44d59d2931  por xmm1, xmm15
00007a44d59d2936  vmovaps xmm15, [rsp+0x50]
00007a44d59d293c  vmovaps [rsp+0xE0], xmm1
00007a44d59d2945  vmovaps xmm1, [rsp+0x50]
00007a44d59d294b  por xmm15, xmm1
00007a44d59d2950  lea rax, [r14+0xC0]
00007a44d59d2957  movups xmm1, [r13+rax*1]
00007a44d59d295d  xor eax, eax
00007a44d59d295f  mov r12d, 0x40
00007a44d59d2965  mov r11d, 0x200
00007a44d59d296b  cmp r12, r11
00007a44d59d296e  cmc
00007a44d59d296f  lahf
00007a44d59d2970  seto al
00007a44d59d2973  mov [r15+0x108], eax
00007a44d59d297a  vmovaps [rsp+0x50], xmm1
00007a44d59d2980  vmovaps xmm1, [rsp+0xF0]
00007a44d59d2989  vmovaps [rsp+0xF0], xmm15
00007a44d59d2992  vmovaps xmm15, [rsp+0x50]
00007a44d59d2998  vmovaps [rsp+0x50], xmm13
00007a44d59d299e  vmovaps [rsp+0x120], xmm12
00007a44d59d29a7  movaps xmm13, xmm1
00007a44d59d29ab  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d29b6  vptest xmm12, xmm12
00007a44d59d29bb  jnz 0x00007A44D59D373D
00007a44d59d29c1  lea rax, [r14+0xB0]
00007a44d59d29c8  movups xmm1, [r13+rax*1]
00007a44d59d29ce  vmovaps xmm15, [rsp+0x110]
00007a44d59d29d7  vmovaps [rsp+0x110], xmm13
00007a44d59d29e0  movaps xmm12, xmm15
00007a44d59d29e4  vfmadd231pd xmm12, xmm1, xmm14
00007a44d59d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
00007a44d59d29ef  vptest xmm13, xmm13
00007a44d59d29f4  jnz 0x00007A44D59D38A0
00007a44d59d29fa  vmovaps xmm1, [rsp+0x100]
00007a44d59d2a03  vmovaps xmm15, [rsp+0x100]
00007a44d59d2a0c  por xmm1, xmm15
00007a44d59d2a11  movaps [r15+0x210], xmm1
00007a44d59d2a19  vmovaps xmm15, [rsp+0x60]
00007a44d59d2a1f  vmovaps xmm14, [rsp+0x60]
00007a44d59d2a25  por xmm15, xmm14
00007a44d59d2a2a  movaps [r15+0x1C0], xmm15
00007a44d59d2a32  vmovaps [rsp+0x60], xmm11
00007a44d59d2a38  vmovaps xmm14, [rsp+0x60]
00007a44d59d2a3e  por xmm11, xmm14
00007a44d59d2a43  movaps [r15+0x280], xmm11
00007a44d59d2a4b  vmovaps [rsp+0x60], xmm6
00007a44d59d2a51  vmovaps xmm14, [rsp+0x60]
00007a44d59d2a57  por xmm6, xmm14
00007a44d59d2a5c  movaps [r15+0x2A0], xmm6
00007a44d59d2a64  vmovaps xmm14, [rsp+0x20]
00007a44d59d2a6a  vmovaps xmm13, [rsp+0x20]
00007a44d59d2a70  por xmm14, xmm13
00007a44d59d2a75  movaps [r15+0x2E0], xmm14
00007a44d59d2a7d  vmovaps xmm13, [rsp+0x10]
00007a44d59d2a83  vmovaps [rsp+0x20], xmm1
00007a44d59d2a89  vmovaps xmm1, [rsp+0x10]
00007a44d59d2a8f  por xmm13, xmm1
00007a44d59d2a94  movaps [r15+0x1F0], xmm13
00007a44d59d2a9c  vmovaps xmm1, [rsp+0xF0]
00007a44d59d2aa5  vmovaps [rsp+0x10], xmm15
00007a44d59d2aab  vmovaps xmm15, [rsp+0xF0]
00007a44d59d2ab4  por xmm1, xmm15
00007a44d59d2ab9  movaps [r15+0x250], xmm1
00007a44d59d2ac1  vmovaps xmm1, [rsp+0xE0]
00007a44d59d2aca  vmovaps xmm15, [rsp+0xE0]
00007a44d59d2ad3  por xmm1, xmm15
00007a44d59d2ad8  movaps [r15+0x260], xmm1
00007a44d59d2ae0  vmovaps [rsp+0x60], xmm8
00007a44d59d2ae6  vmovaps xmm15, [rsp+0x60]
00007a44d59d2aec  por xmm8, xmm15
00007a44d59d2af1  movaps [r15+0x290], xmm8
00007a44d59d2af9  vmovaps [rsp+0x60], xmm10
00007a44d59d2aff  vmovaps xmm15, [rsp+0x60]
00007a44d59d2b05  por xmm10, xmm15
00007a44d59d2b0a  movaps [r15+0x2C0], xmm10
00007a44d59d2b12  movq xmm15, qword ptr [r15+0x240]
00007a44d59d2b1b  vmovaps [rsp+0x60], xmm15
00007a44d59d2b21  vpermilpd xmm15, xmm15, 0x00
00007a44d59d2b27  vmovaps [rsp+0xE0], xmm1
00007a44d59d2b30  vmovaps xmm1, [rsp+0x50]
00007a44d59d2b36  vmovaps [rsp+0x50], xmm15
00007a44d59d2b3c  vmovaps xmm15, [rsp+0x20]
00007a44d59d2b42  vmovaps [rsp+0x20], xmm14
00007a44d59d2b48  vmovaps xmm14, [rsp+0x50]
00007a44d59d2b4e  vmovaps [rsp+0x50], xmm13
00007a44d59d2b54  vmovaps [rsp+0xF0], xmm12
00007a44d59d2b5d  movaps xmm13, xmm1
00007a44d59d2b61  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d2b6c  vptest xmm12, xmm12
00007a44d59d2b71  jnz 0x00007A44D59D39F9
00007a44d59d2b77  vmovaps xmm1, [rsp+0x60]
00007a44d59d2b7d  vpermilpd xmm1, xmm1, 0x00
00007a44d59d2b83  vmovaps xmm15, [rsp+0x110]
00007a44d59d2b8c  vmovaps xmm14, [rsp+0x20]
00007a44d59d2b92  vmovaps [rsp+0x20], xmm13
00007a44d59d2b98  movaps xmm12, xmm15
00007a44d59d2b9c  vfmadd231pd xmm12, xmm14, xmm1
00007a44d59d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
00007a44d59d2ba7  vptest xmm13, xmm13
00007a44d59d2bac  jnz 0x00007A44D59D3B52
00007a44d59d2bb2  vmovaps xmm1, [rsp+0x60]
00007a44d59d2bb8  vpermilpd xmm1, xmm1, 0x00
00007a44d59d2bbe  vmovaps xmm15, [rsp+0x30]
00007a44d59d2bc4  vmovaps xmm14, [rsp+0x10]
00007a44d59d2bca  vmovaps [rsp+0x10], xmm12
00007a44d59d2bd0  movaps xmm13, xmm15
00007a44d59d2bd4  vfmadd231pd xmm13, xmm14, xmm1
00007a44d59d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d2bdf  vptest xmm12, xmm12
00007a44d59d2be4  jnz 0x00007A44D59D3CAB
00007a44d59d2bea  vmovaps [rsp+0x30], xmm5
00007a44d59d2bf0  vmovaps xmm1, [rsp+0x30]
00007a44d59d2bf6  por xmm5, xmm1
00007a44d59d2bfa  movaps [r15+0x1D0], xmm5
00007a44d59d2c02  vmovaps xmm1, [rsp+0x60]
00007a44d59d2c08  vpermilpd xmm1, xmm1, 0x00
00007a44d59d2c0e  vmovaps xmm15, [rsp+0xF0]
00007a44d59d2c17  vmovaps xmm14, [rsp+0x50]
00007a44d59d2c1d  vmovaps [rsp+0x30], xmm13
00007a44d59d2c23  movaps xmm12, xmm15
00007a44d59d2c27  vfmadd231pd xmm12, xmm14, xmm1
00007a44d59d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
00007a44d59d2c32  vptest xmm13, xmm13
00007a44d59d2c37  jnz 0x00007A44D59D3E04
00007a44d59d2c3d  vmovaps xmm1, [rsp+0x80]
00007a44d59d2c46  vmovaps xmm15, [rsp+0x80]
00007a44d59d2c4f  por xmm1, xmm15
00007a44d59d2c54  movaps [r15+0x200], xmm1
00007a44d59d2c5c  vmovaps xmm15, [rsp+0x120]
00007a44d59d2c65  vmovaps xmm14, [rsp+0x120]
00007a44d59d2c6e  por xmm15, xmm14
00007a44d59d2c73  movaps [r15+0x1E0], xmm15
00007a44d59d2c7b  vmovaps [rsp+0x50], xmm4
00007a44d59d2c81  vmovaps xmm13, [rsp+0x50]
00007a44d59d2c87  por xmm4, xmm13
00007a44d59d2c8c  movaps [r15+0x2B0], xmm4
00007a44d59d2c94  vmovaps [rsp+0x50], xmm3
00007a44d59d2c9a  vmovaps xmm13, [rsp+0x50]
00007a44d59d2ca0  por xmm3, xmm13
00007a44d59d2ca5  movaps [r15+0x300], xmm3
00007a44d59d2cad  vmovaps xmm15, [rsp+0xB0]
00007a44d59d2cb6  vpermilpd xmm15, xmm15, 0x00
00007a44d59d2cbc  vmovaps xmm3, [rsp+0x20]
00007a44d59d2cc2  vmovaps [rsp+0x20], xmm1
00007a44d59d2cc8  vmovaps xmm1, [rsp+0xE0]
00007a44d59d2cd1  vmovaps [rsp+0x50], xmm14
00007a44d59d2cd7  vmovaps [rsp+0x60], xmm13
00007a44d59d2cdd  movaps xmm14, xmm3
00007a44d59d2ce1  vfmadd231pd xmm14, xmm1, xmm15
00007a44d59d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
00007a44d59d2cec  vptest xmm13, xmm13
00007a44d59d2cf1  jnz 0x00007A44D59D3F5D
00007a44d59d2cf7  vmovaps xmm1, [rsp+0xB0]
00007a44d59d2d00  vpermilpd xmm1, xmm1, 0x00
00007a44d59d2d06  vmovaps xmm15, [rsp+0x10]
00007a44d59d2d0c  movaps xmm13, xmm15
00007a44d59d2d10  vfmadd231pd xmm13, xmm10, xmm1
00007a44d59d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
00007a44d59d2d1b  vptest xmm3, xmm3
00007a44d59d2d20  jnz 0x00007A44D59D40B5
00007a44d59d2d26  vmovaps xmm1, [rsp+0xB0]
00007a44d59d2d2f  vpermilpd xmm1, xmm1, 0x00
00007a44d59d2d35  vmovaps xmm15, [rsp+0x30]
00007a44d59d2d3b  movaps xmm10, xmm15
00007a44d59d2d3f  vfmadd231pd xmm10, xmm11, xmm1
00007a44d59d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
00007a44d59d2d4a  vptest xmm3, xmm3
00007a44d59d2d4f  jnz 0x00007A44D59D420E
00007a44d59d2d55  vmovaps xmm1, [rsp+0xB0]
00007a44d59d2d5e  vpermilpd xmm1, xmm1, 0x00
00007a44d59d2d64  movaps xmm15, xmm12
00007a44d59d2d68  vfmadd231pd xmm15, xmm5, xmm1
00007a44d59d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
00007a44d59d2d73  vptest xmm11, xmm11
00007a44d59d2d78  jnz 0x00007A44D59D4367
00007a44d59d2d7e  vmovaps [rsp+0x10], xmm9
00007a44d59d2d84  vmovaps xmm1, [rsp+0x10]
00007a44d59d2d8a  por xmm9, xmm1
00007a44d59d2d8f  movaps [r15+0x180], xmm9
00007a44d59d2d97  vmovaps [rsp+0x10], xmm2
00007a44d59d2d9d  vmovaps xmm1, [rsp+0x10]
00007a44d59d2da3  por xmm2, xmm1
00007a44d59d2da7  movaps [r15+0x2D0], xmm2
00007a44d59d2daf  vmovaps xmm12, [rsp+0xD0]
00007a44d59d2db8  vpermilpd xmm12, xmm12, 0x00
00007a44d59d2dbe  vmovaps xmm11, [rsp+0x60]
00007a44d59d2dc4  movaps xmm5, xmm13
00007a44d59d2dc8  vfmadd231pd xmm5, xmm11, xmm12
00007a44d59d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
00007a44d59d2dd2  vptest xmm3, xmm3
00007a44d59d2dd7  jnz 0x00007A44D59D44BF
00007a44d59d2ddd  vmovaps xmm13, [rsp+0xD0]
00007a44d59d2de6  vpermilpd xmm13, xmm13, 0x00
00007a44d59d2dec  movaps xmm12, xmm14
00007a44d59d2df0  vfmadd231pd xmm12, xmm9, xmm13
00007a44d59d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
00007a44d59d2dfb  vptest xmm11, xmm11
00007a44d59d2e00  jnz 0x00007A44D59D4617
00007a44d59d2e06  lea rax, [r14+0x80]
00007a44d59d2e0d  movups xmm14, [r13+rax*1]
00007a44d59d2e13  movaps [r15+0x2F0], xmm14
00007a44d59d2e1b  vmovaps xmm13, [rsp+0xD0]
00007a44d59d2e24  vpermilpd xmm13, xmm13, 0x00
00007a44d59d2e2a  movaps xmm11, xmm10
00007a44d59d2e2e  vfmadd231pd xmm11, xmm8, xmm13
00007a44d59d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
00007a44d59d2e39  vptest xmm9, xmm9
00007a44d59d2e3e  jnz 0x00007A44D59D477B
00007a44d59d2e44  vmovaps xmm13, [rsp+0xD0]
00007a44d59d2e4d  vpermilpd xmm13, xmm13, 0x00
00007a44d59d2e53  movaps xmm10, xmm15
00007a44d59d2e57  vfmadd231pd xmm10, xmm1, xmm13
00007a44d59d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
00007a44d59d2e62  vptest xmm9, xmm9
00007a44d59d2e67  jnz 0x00007A44D59D48D5
00007a44d59d2e6d  vmovaps [rsp+0x10], xmm7
00007a44d59d2e73  vmovaps xmm1, [rsp+0x10]
00007a44d59d2e79  por xmm7, xmm1
00007a44d59d2e7d  movaps [r15+0x160], xmm7
00007a44d59d2e85  lea rax, [r14+0x40]
00007a44d59d2e89  movups xmm1, [r13+rax*1]
00007a44d59d2e8f  lea rax, [r14+0x50]
00007a44d59d2e93  movups xmm15, [r13+rax*1]
00007a44d59d2e99  movaps [r15+0x1B0], xmm1
00007a44d59d2ea1  movaps [r15+0x1A0], xmm15
00007a44d59d2ea9  vmovaps xmm13, [rsp+0xA0]
00007a44d59d2eb2  vpermilpd xmm13, xmm13, 0x00
00007a44d59d2eb8  vmovaps xmm9, [rsp+0x40]
00007a44d59d2ebe  movaps xmm8, xmm5
00007a44d59d2ec2  vfmadd231pd xmm8, xmm9, xmm13
00007a44d59d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
00007a44d59d2ecd  vptest xmm3, xmm3
00007a44d59d2ed2  jnz 0x00007A44D59D4A42
00007a44d59d2ed8  vmovaps xmm13, [rsp+0xA0]
00007a44d59d2ee1  vpermilpd xmm13, xmm13, 0x00
00007a44d59d2ee7  movaps xmm9, xmm12
00007a44d59d2eeb  vfmadd231pd xmm9, xmm7, xmm13
00007a44d59d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
00007a44d59d2ef6  vptest xmm5, xmm5
00007a44d59d2efb  jnz 0x00007A44D59D4B9B
00007a44d59d2f01  vmovaps xmm13, [rsp+0xA0]
00007a44d59d2f0a  vpermilpd xmm13, xmm13, 0x00
00007a44d59d2f10  movaps xmm12, xmm11
00007a44d59d2f14  vfmadd231pd xmm12, xmm6, xmm13
00007a44d59d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
00007a44d59d2f1f  vptest xmm7, xmm7
00007a44d59d2f24  jnz 0x00007A44D59D4CF4
00007a44d59d2f2a  vmovaps xmm13, [rsp+0xA0]
00007a44d59d2f33  vpermilpd xmm13, xmm13, 0x00
00007a44d59d2f39  vmovaps xmm11, [rsp+0x50]
00007a44d59d2f3f  movaps xmm7, xmm10
00007a44d59d2f43  vfmadd231pd xmm7, xmm11, xmm13
00007a44d59d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
00007a44d59d2f4d  vptest xmm6, xmm6
00007a44d59d2f52  jnz 0x00007A44D59D4E4D
00007a44d59d2f58  lea rax, [r14+0x60]
00007a44d59d2f5c  movups xmm13, [r13+rax*1]
00007a44d59d2f62  lea rax, [r14+0x70]
00007a44d59d2f66  movups xmm11, [r13+rax*1]
00007a44d59d2f6c  movaps [r15+0x150], xmm13
00007a44d59d2f74  movaps [r15+0x120], xmm11
00007a44d59d2f7c  vmovaps xmm10, [rsp+0xC0]
00007a44d59d2f85  vpermilpd xmm10, xmm10, 0x00
00007a44d59d2f8b  movaps xmm6, xmm8
00007a44d59d2f8f  vfmadd231pd xmm6, xmm15, xmm10
00007a44d59d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
00007a44d59d2f99  vptest xmm5, xmm5
00007a44d59d2f9e  jnz 0x00007A44D59D4FB9
00007a44d59d2fa4  vmovaps xmm15, [rsp+0xC0]
00007a44d59d2fad  vpermilpd xmm15, xmm15, 0x00
00007a44d59d2fb3  movaps xmm10, xmm9
00007a44d59d2fb7  vfmadd231pd xmm10, xmm13, xmm15
00007a44d59d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
00007a44d59d2fc2  vptest xmm8, xmm8
00007a44d59d2fc7  jnz 0x00007A44D59D5111
00007a44d59d2fcd  vmovaps xmm15, [rsp+0xC0]
00007a44d59d2fd6  vpermilpd xmm15, xmm15, 0x00
00007a44d59d2fdc  movaps xmm13, xmm12
00007a44d59d2fe0  vfmadd231pd xmm13, xmm4, xmm15
00007a44d59d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
00007a44d59d2feb  vptest xmm9, xmm9
00007a44d59d2ff0  jnz 0x00007A44D59D526B
00007a44d59d2ff6  vmovaps xmm15, [rsp+0xC0]
00007a44d59d2fff  vpermilpd xmm15, xmm15, 0x00
00007a44d59d3005  movaps xmm12, xmm7
00007a44d59d3009  vfmadd231pd xmm12, xmm1, xmm15
00007a44d59d300e  vcmppd xmm9, xmm12, xmm12, 0x03
00007a44d59d3014  vptest xmm9, xmm9
00007a44d59d3019  jnz 0x00007A44D59D53C4
00007a44d59d301f  lea rax, [r14+0x20]
00007a44d59d3023  movups xmm1, [r13+rax*1]
00007a44d59d3029  lea rax, [r14+0x30]
00007a44d59d302d  movups xmm15, [r13+rax*1]
00007a44d59d3033  vmovaps xmm9, [rsp+0x70]
00007a44d59d3039  vpermilpd xmm9, xmm9, 0x00
00007a44d59d303f  vmovaps xmm8, [rsp+0x20]
00007a44d59d3045  movaps xmm7, xmm6
00007a44d59d3048  vfmadd231pd xmm7, xmm8, xmm9
00007a44d59d304d  vcmppd xmm5, xmm7, xmm7, 0x03
00007a44d59d3052  vptest xmm5, xmm5
00007a44d59d3057  jnz 0x00007A44D59D5530
00007a44d59d305d  vmovaps xmm9, [rsp+0x70]
00007a44d59d3063  vpermilpd xmm9, xmm9, 0x00
00007a44d59d3069  movaps xmm8, xmm10
00007a44d59d306d  vfmadd231pd xmm8, xmm14, xmm9
00007a44d59d3072  vcmppd xmm6, xmm8, xmm8, 0x03
00007a44d59d3078  vptest xmm6, xmm6
00007a44d59d307d  jnz 0x00007A44D59D5687
00007a44d59d3083  vmovaps xmm14, [rsp+0x70]
00007a44d59d3089  vpermilpd xmm14, xmm14, 0x00
00007a44d59d308f  movaps xmm10, xmm13
00007a44d59d3093  vfmadd231pd xmm10, xmm11, xmm14
00007a44d59d3098  vcmppd xmm9, xmm10, xmm10, 0x03
00007a44d59d309e  vptest xmm9, xmm9
00007a44d59d30a3  jnz 0x00007A44D59D57E1
00007a44d59d30a9  vmovaps xmm14, [rsp+0x70]
00007a44d59d30af  vpermilpd xmm14, xmm14, 0x00
00007a44d59d30b5  movaps xmm13, xmm12
00007a44d59d30b9  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d30be  vcmppd xmm11, xmm13, xmm13, 0x03
00007a44d59d30c4  vptest xmm11, xmm11
00007a44d59d30c9  jnz 0x00007A44D59D593B
00007a44d59d30cf  lea rax, [r14+0x90]
00007a44d59d30d6  movups xmm15, [r13+rax*1]
00007a44d59d30dc  lea rax, [r14+0xA0]
00007a44d59d30e3  movups xmm14, [r13+rax*1]
00007a44d59d30e9  movaps [r15+0x140], xmm15
00007a44d59d30f1  movaps [r15+0x130], xmm14
00007a44d59d30f9  vmovaps xmm12, [rsp+0x90]
00007a44d59d3102  vpermilpd xmm12, xmm12, 0x00
00007a44d59d3108  movaps xmm11, xmm7
00007a44d59d310c  vfmadd231pd xmm11, xmm1, xmm12
00007a44d59d3111  vcmppd xmm9, xmm11, xmm11, 0x03
00007a44d59d3117  vptest xmm9, xmm9
00007a44d59d311c  jnz 0x00007A44D59D5AA9
00007a44d59d3122  movaps [r15+0x220], xmm11
00007a44d59d312a  lea rax, [r14+0x10]
00007a44d59d312e  movups xmm1, [r13+rax*1]
00007a44d59d3134  movaps [r15+0x240], xmm1
00007a44d59d313c  vmovaps xmm12, [rsp+0x90]
00007a44d59d3145  vpermilpd xmm12, xmm12, 0x00
00007a44d59d314b  movaps xmm9, xmm8
00007a44d59d314f  vfmadd231pd xmm9, xmm14, xmm12
00007a44d59d3154  vcmppd xmm7, xmm9, xmm9, 0x03
00007a44d59d315a  vptest xmm7, xmm7
00007a44d59d315f  jnz 0x00007A44D59D5C0B
00007a44d59d3165  movaps [r15+0x110], xmm9
00007a44d59d316d  vmovaps xmm14, [rsp+0x90]
00007a44d59d3176  vpermilpd xmm14, xmm14, 0x00
00007a44d59d317c  movaps xmm12, xmm10
00007a44d59d3180  vfmadd231pd xmm12, xmm15, xmm14
00007a44d59d3185  vcmppd xmm8, xmm12, xmm12, 0x03
00007a44d59d318b  vptest xmm8, xmm8
00007a44d59d3190  jnz 0x00007A44D59D5D65
00007a44d59d3196  movaps [r15+0x170], xmm12
00007a44d59d319e  vmovaps xmm15, [rsp+0x90]
00007a44d59d31a7  vpermilpd xmm15, xmm15, 0x00
00007a44d59d31ad  movaps xmm14, xmm13
00007a44d59d31b1  vfmadd231pd xmm14, xmm1, xmm15
00007a44d59d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
00007a44d59d31bc  vptest xmm10, xmm10
00007a44d59d31c1  jnz 0x00007A44D59D5EBF
00007a44d59d31c7  movaps [r15+0x230], xmm14
00007a44d59d31cf  mov eax, 0x432190
00007a44d59d31d4  movups [r13+rax*1], xmm9
00007a44d59d31da  mov eax, 0x4321A0
00007a44d59d31df  movups [r13+rax*1], xmm12
00007a44d59d31e5  mov eax, 0x4321B0
00007a44d59d31ea  movups [r13+rax*1], xmm11
00007a44d59d31f0  mov eax, 0x4321C0
00007a44d59d31f5  movups [r13+rax*1], xmm14
00007a44d59d31fb  mov eax, [r15+0x108]
00007a44d59d3202  sahf
00007a44d59d3203  jnz 0x00007A44D59D3235
00007a44d59d3205  cmp dword ptr [r15+0x318], 0x00
00007a44d59d320d  jz 0x00007A44D59D9950
00007a44d59d3213  nop [rax+rax*1], ax
00007a44d59d321c  nop [rax+rax*1], eax
00007a44d59d3224  mov eax, 0x410664
00007a44d59d3229  mov [r15+0x100], rax
00007a44d59d3230  jmp 0x00007A44D57FE110
00007a44d59d3235  cmp dword ptr [r15+0x318], 0x00
00007a44d59d323d  jz 0x00007A44D59D6050
00007a44d59d3243  nop [rax+rax*1], ax
00007a44d59d324c  nop [rax+rax*1], eax
00007a44d59d3254  mov eax, 0x4104F0
00007a44d59d3259  mov [r15+0x100], rax
00007a44d59d3260  jmp 0x00007A44D57FE110
00007a44d59d3265  int3
00007a44d59d3266  call 0x00007A44D57FF430
00007a44d59d326b  jmp 0x00007A44D59D230A
00007a44d59d3270  call 0x00007A44D58E5820
00007a44d59d3275  jmp 0x00007A44D59D2314
00007a44d59d327a  call 0x00007A44D58E45A0
00007a44d59d327f  jmp 0x00007A44D59D2326
00007a44d59d3284  call 0x00007A44D58E3320
00007a44d59d3289  jmp 0x00007A44D59D2330
00007a44d59d328e  call 0x00007A44D58E20A0
00007a44d59d3293  jmp 0x00007A44D59D233D
00007a44d59d3298  call 0x00007A44D58E0E30
00007a44d59d329d  jmp 0x00007A44D59D234A
00007a44d59d32a2  call 0x00007A44D58D6600
00007a44d59d32a7  jmp 0x00007A44D59D2357
00007a44d59d32ac  call 0x00007A44D58B52F0
00007a44d59d32b1  jmp 0x00007A44D59D2361
00007a44d59d32b6  call 0x00007A44D58BE9C0
00007a44d59d32bb  jmp 0x00007A44D59D236B
00007a44d59d32c0  call 0x00007A44D58BD750
00007a44d59d32c5  jmp 0x00007A44D59D2378
00007a44d59d32ca  call 0x00007A44D58BC4E0
00007a44d59d32cf  jmp 0x00007A44D59D2385
00007a44d59d32d4  call 0x00007A44D58BB270
00007a44d59d32d9  jmp 0x00007A44D59D2392
00007a44d59d32de  call 0x00007A44D58BA000
00007a44d59d32e3  jmp 0x00007A44D59D239F
00007a44d59d32e8  call 0x00007A44D58B8D90
00007a44d59d32ed  jmp 0x00007A44D59D23AC
00007a44d59d32f2  call 0x00007A44D58B8A20
00007a44d59d32f7  jmp 0x00007A44D59D23B9
00007a44d59d32fc  call 0x00007A44D58BEAE0
00007a44d59d3301  jmp 0x00007A44D59D23C6
00007a44d59d3306  call 0x00007A44D58B5400
00007a44d59d330b  jmp 0x00007A44D59D23D3
00007a44d59d3310  call 0x00007A44D58B52F0
00007a44d59d3315  jmp 0x00007A44D59D23E0
00007a44d59d331a  call 0x00007A44D58BE9C0
00007a44d59d331f  jmp 0x00007A44D59D23ED
00007a44d59d3324  call 0x00007A44D58B77B0
00007a44d59d3329  jmp 0x00007A44D59D23FA
00007a44d59d332e  call 0x00007A44D58B6550
00007a44d59d3333  jmp 0x00007A44D59D2407
00007a44d59d3338  call 0x00007A44D58B52F0
00007a44d59d333d  jmp 0x00007A44D59D2417
00007a44d59d3342  call 0x00007A44D58B52F0
00007a44d59d3347  jmp 0x00007A44D59D2427
00007a44d59d334c  call 0x00007A44D58BEAE0
00007a44d59d3351  jmp 0x00007A44D59D2431
00007a44d59d3356  call 0x00007A44D58BEAE0
00007a44d59d335b  jmp 0x00007A44D59D2444
00007a44d59d3360  call 0x00007A44D58BE9C0
00007a44d59d3365  jmp 0x00007A44D59D2451
00007a44d59d336a  call 0x00007A44D58B52F0
00007a44d59d336f  jmp 0x00007A44D59D2464
00007a44d59d3374  call 0x00007A44D58B6660
00007a44d59d3379  jmp 0x00007A44D59D2471
00007a44d59d337e  call 0x00007A44D58B78C0
00007a44d59d3383  jmp 0x00007A44D59D247E
00007a44d59d3388  call 0x00007A44D58B77B0
00007a44d59d338d  jmp 0x00007A44D59D248B
00007a44d59d3392  call 0x00007A44D58B6550
00007a44d59d3397  jmp 0x00007A44D59D2498
00007a44d59d339c  call 0x00007A44D58B52F0
00007a44d59d33a1  jmp 0x00007A44D59D24AB
00007a44d59d33a6  call 0x00007A44D58B52F0
00007a44d59d33ab  jmp 0x00007A44D59D24BE
00007a44d59d33b0  call 0x00007A44D58B52F0
00007a44d59d33b5  jmp 0x00007A44D59D24E5
00007a44d59d33ba  call 0x00007A44D58B52F0
00007a44d59d33bf  jmp 0x00007A44D59D24F8
00007a44d59d33c4  call 0x00007A44D58B52F0
00007a44d59d33c9  jmp 0x00007A44D59D250B
00007a44d59d33ce  call 0x00007A44D58B52F0
00007a44d59d33d3  jmp 0x00007A44D59D2521
00007a44d59d33d8  call 0x00007A44D58B52F0
00007a44d59d33dd  jmp 0x00007A44D59D2537
00007a44d59d33e2  call 0x00007A44D58B52F0
00007a44d59d33e7  jmp 0x00007A44D59D254D
00007a44d59d33ec  call 0x00007A44D57FF540
00007a44d59d33f1  jmp 0x00007A44D59D256E
00007a44d59d33f6  call 0x00007A44D5802FE0
00007a44d59d33fb  jmp 0x00007A44D59D2578
00007a44d59d3400  call 0x00007A44D57FF540
00007a44d59d3405  jmp 0x00007A44D59D2588
00007a44d59d340a  call 0x00007A44D57FF540
00007a44d59d340f  jmp 0x00007A44D59D259B
00007a44d59d3414  call 0x00007A44D57FF540
00007a44d59d3419  jmp 0x00007A44D59D25AE
00007a44d59d341e  call 0x00007A44D57FF540
00007a44d59d3423  jmp 0x00007A44D59D25C1
00007a44d59d3428  call 0x00007A44D58C0370
00007a44d59d342d  jmp 0x00007A44D59D25E0
00007a44d59d3432  call 0x00007A44D58BF100
00007a44d59d3437  jmp 0x00007A44D59D25E9
00007a44d59d343c  call 0x00007A44D58C0370
00007a44d59d3441  jmp 0x00007A44D59D2659
00007a44d59d3446  call 0x00007A44D58BF100
00007a44d59d344b  jmp 0x00007A44D59D2662
00007a44d59d3450  call 0x00007A44D58C0370
00007a44d59d3455  jmp 0x00007A44D59D270C
00007a44d59d345a  call 0x00007A44D58BF100
00007a44d59d345f  jmp 0x00007A44D59D2715
00007a44d59d3464  call 0x00007A44D580B720
00007a44d59d3469  jmp 0x00007A44D59D27F7
00007a44d59d346e  call 0x00007A44D58D64F0
00007a44d59d3473  jmp 0x00007A44D59D281F
00007a44d59d3478  call 0x00007A44D58B47C0
00007a44d59d347d  jmp 0x00007A44D59D283A
00007a44d59d3482  sub rsp, 0x08
00007a44d59d3486  push rax
00007a44d59d3487  push rcx
00007a44d59d3488  push rdx
00007a44d59d3489  push rdi
00007a44d59d348a  push rsi
00007a44d59d348b  push r8
00007a44d59d348d  push r9
00007a44d59d348f  push r10
00007a44d59d3491  push r11
00007a44d59d3493  sub rsp, 0xF0
00007a44d59d349a  vmovaps [rsp], xmm0
00007a44d59d349f  vmovaps [rsp+0x10], xmm1
00007a44d59d34a5  vmovaps [rsp+0x20], xmm2
00007a44d59d34ab  vmovaps [rsp+0x30], xmm3
00007a44d59d34b1  vmovaps [rsp+0x40], xmm4
00007a44d59d34b7  vmovaps [rsp+0x50], xmm5
00007a44d59d34bd  vmovaps [rsp+0x60], xmm6
00007a44d59d34c3  vmovaps [rsp+0x70], xmm7
00007a44d59d34c9  vmovaps [rsp+0x80], xmm8
00007a44d59d34d2  vmovaps [rsp+0x90], xmm9
00007a44d59d34db  vmovaps [rsp+0xA0], xmm10
00007a44d59d34e4  vmovaps [rsp+0xB0], xmm11
00007a44d59d34ed  vmovaps [rsp+0xC0], xmm12
00007a44d59d34f6  vmovaps [rsp+0xD0], xmm14
00007a44d59d34ff  vmovaps [rsp+0xE0], xmm15
00007a44d59d3508  sub rsp, 0x40
00007a44d59d350c  lea rdi, [rsp]
00007a44d59d3510  lea rsi, [rsp+0x10]
00007a44d59d3515  lea rdx, [rsp+0x20]
00007a44d59d351a  lea rcx, [rsp+0x30]
00007a44d59d351f  mov r8d, 0x00
00007a44d59d3525  lea r9, [r15+0x3A8]
00007a44d59d352c  movaps [rdi], xmm13
00007a44d59d3530  movaps [rsi], xmm1
00007a44d59d3533  movaps [rdx], xmm15
00007a44d59d3537  movaps [rcx], xmm14
00007a44d59d353b  mov rax, 0x56179A4B1A50
00007a44d59d3545  call rax
00007a44d59d3547  movaps xmm13, [rsp]
00007a44d59d354c  add rsp, 0x40
00007a44d59d3550  vmovaps xmm0, [rsp]
00007a44d59d3555  vmovaps xmm1, [rsp+0x10]
00007a44d59d355b  vmovaps xmm2, [rsp+0x20]
00007a44d59d3561  vmovaps xmm3, [rsp+0x30]
00007a44d59d3567  vmovaps xmm4, [rsp+0x40]
00007a44d59d356d  vmovaps xmm5, [rsp+0x50]
00007a44d59d3573  vmovaps xmm6, [rsp+0x60]
00007a44d59d3579  vmovaps xmm7, [rsp+0x70]
00007a44d59d357f  vmovaps xmm8, [rsp+0x80]
00007a44d59d3588  vmovaps xmm9, [rsp+0x90]
00007a44d59d3591  vmovaps xmm10, [rsp+0xA0]
00007a44d59d359a  vmovaps xmm11, [rsp+0xB0]
00007a44d59d35a3  vmovaps xmm12, [rsp+0xC0]
00007a44d59d35ac  vmovaps xmm14, [rsp+0xD0]
00007a44d59d35b5  vmovaps xmm15, [rsp+0xE0]
00007a44d59d35be  add rsp, 0xF0
00007a44d59d35c5  pop r11
00007a44d59d35c7  pop r10
00007a44d59d35c9  pop r9
00007a44d59d35cb  pop r8
00007a44d59d35cd  pop rsi
00007a44d59d35ce  pop rdi
00007a44d59d35cf  pop rdx
00007a44d59d35d0  pop rcx
00007a44d59d35d1  pop rax
00007a44d59d35d2  add rsp, 0x08
00007a44d59d35d6  jmp 0x00007A44D59D28AD
00007a44d59d35db  sub rsp, 0x08
00007a44d59d35df  push rax
00007a44d59d35e0  push rcx
00007a44d59d35e1  push rdx
00007a44d59d35e2  push rdi
00007a44d59d35e3  push rsi
00007a44d59d35e4  push r8
00007a44d59d35e6  push r9
00007a44d59d35e8  push r10
00007a44d59d35ea  push r11
00007a44d59d35ec  sub rsp, 0xF0
00007a44d59d35f3  vmovaps [rsp], xmm0
00007a44d59d35f8  vmovaps [rsp+0x10], xmm1
00007a44d59d35fe  vmovaps [rsp+0x20], xmm2
00007a44d59d3604  vmovaps [rsp+0x30], xmm3
00007a44d59d360a  vmovaps [rsp+0x40], xmm4
00007a44d59d3610  vmovaps [rsp+0x50], xmm5
00007a44d59d3616  vmovaps [rsp+0x60], xmm6
00007a44d59d361c  vmovaps [rsp+0x70], xmm7
00007a44d59d3622  vmovaps [rsp+0x80], xmm8
00007a44d59d362b  vmovaps [rsp+0x90], xmm9
00007a44d59d3634  vmovaps [rsp+0xA0], xmm10
00007a44d59d363d  vmovaps [rsp+0xB0], xmm11
00007a44d59d3646  vmovaps [rsp+0xC0], xmm12
00007a44d59d364f  vmovaps [rsp+0xD0], xmm13
00007a44d59d3658  vmovaps [rsp+0xE0], xmm14
00007a44d59d3661  sub rsp, 0x40
00007a44d59d3665  lea rdi, [rsp]
00007a44d59d3669  lea rsi, [rsp+0x10]
00007a44d59d366e  lea rdx, [rsp+0x20]
00007a44d59d3673  lea rcx, [rsp+0x30]
00007a44d59d3678  mov r8d, 0x00
00007a44d59d367e  lea r9, [r15+0x3A8]
00007a44d59d3685  movaps [rdi], xmm15
00007a44d59d3689  movaps [rsi], xmm5
00007a44d59d368c  movaps [rdx], xmm1
00007a44d59d368f  movaps [rcx], xmm14
00007a44d59d3693  mov rax, 0x56179A4B1A50
00007a44d59d369d  call rax
00007a44d59d369f  movaps xmm15, [rsp]
00007a44d59d36a4  add rsp, 0x40
00007a44d59d36a8  vmovaps xmm0, [rsp]
00007a44d59d36ad  vmovaps xmm1, [rsp+0x10]
00007a44d59d36b3  vmovaps xmm2, [rsp+0x20]
00007a44d59d36b9  vmovaps xmm3, [rsp+0x30]
00007a44d59d36bf  vmovaps xmm4, [rsp+0x40]
00007a44d59d36c5  vmovaps xmm5, [rsp+0x50]
00007a44d59d36cb  vmovaps xmm6, [rsp+0x60]
00007a44d59d36d1  vmovaps xmm7, [rsp+0x70]
00007a44d59d36d7  vmovaps xmm8, [rsp+0x80]
00007a44d59d36e0  vmovaps xmm9, [rsp+0x90]
00007a44d59d36e9  vmovaps xmm10, [rsp+0xA0]
00007a44d59d36f2  vmovaps xmm11, [rsp+0xB0]
00007a44d59d36fb  vmovaps xmm12, [rsp+0xC0]
00007a44d59d3704  vmovaps xmm13, [rsp+0xD0]
00007a44d59d370d  vmovaps xmm14, [rsp+0xE0]
00007a44d59d3716  add rsp, 0xF0
00007a44d59d371d  pop r11
00007a44d59d371f  pop r10
00007a44d59d3721  pop r9
00007a44d59d3723  pop r8
00007a44d59d3725  pop rsi
00007a44d59d3726  pop rdi
00007a44d59d3727  pop rdx
00007a44d59d3728  pop rcx
00007a44d59d3729  pop rax
00007a44d59d372a  add rsp, 0x08
00007a44d59d372e  jmp 0x00007A44D59D28D0
00007a44d59d3733  call 0x00007A44D57FF430
00007a44d59d3738  jmp 0x00007A44D59D295D
00007a44d59d373d  sub rsp, 0x08
00007a44d59d3741  push rax
00007a44d59d3742  push rcx
00007a44d59d3743  push rdx
00007a44d59d3744  push rdi
00007a44d59d3745  push rsi
00007a44d59d3746  push r8
00007a44d59d3748  push r9
00007a44d59d374a  push r10
00007a44d59d374c  push r11
00007a44d59d374e  sub rsp, 0xF0
00007a44d59d3755  vmovaps [rsp], xmm0
00007a44d59d375a  vmovaps [rsp+0x10], xmm1
00007a44d59d3760  vmovaps [rsp+0x20], xmm2
00007a44d59d3766  vmovaps [rsp+0x30], xmm3
00007a44d59d376c  vmovaps [rsp+0x40], xmm4
00007a44d59d3772  vmovaps [rsp+0x50], xmm5
00007a44d59d3778  vmovaps [rsp+0x60], xmm6
00007a44d59d377e  vmovaps [rsp+0x70], xmm7
00007a44d59d3784  vmovaps [rsp+0x80], xmm8
00007a44d59d378d  vmovaps [rsp+0x90], xmm9
00007a44d59d3796  vmovaps [rsp+0xA0], xmm10
00007a44d59d379f  vmovaps [rsp+0xB0], xmm11
00007a44d59d37a8  vmovaps [rsp+0xC0], xmm12
00007a44d59d37b1  vmovaps [rsp+0xD0], xmm14
00007a44d59d37ba  vmovaps [rsp+0xE0], xmm15
00007a44d59d37c3  sub rsp, 0x40
00007a44d59d37c7  lea rdi, [rsp]
00007a44d59d37cb  lea rsi, [rsp+0x10]
00007a44d59d37d0  lea rdx, [rsp+0x20]
00007a44d59d37d5  lea rcx, [rsp+0x30]
00007a44d59d37da  mov r8d, 0x00
00007a44d59d37e0  lea r9, [r15+0x3A8]
00007a44d59d37e7  movaps [rdi], xmm13
00007a44d59d37eb  movaps [rsi], xmm1
00007a44d59d37ee  movaps [rdx], xmm15
00007a44d59d37f2  movaps [rcx], xmm14
00007a44d59d37f6  mov rax, 0x56179A4B1A50
00007a44d59d3800  call rax
00007a44d59d3802  movaps xmm13, [rsp]
00007a44d59d3807  add rsp, 0x40
00007a44d59d380b  vmovaps xmm0, [rsp]
00007a44d59d3810  vmovaps xmm1, [rsp+0x10]
00007a44d59d3816  vmovaps xmm2, [rsp+0x20]
00007a44d59d381c  vmovaps xmm3, [rsp+0x30]
00007a44d59d3822  vmovaps xmm4, [rsp+0x40]
00007a44d59d3828  vmovaps xmm5, [rsp+0x50]
00007a44d59d382e  vmovaps xmm6, [rsp+0x60]
00007a44d59d3834  vmovaps xmm7, [rsp+0x70]
00007a44d59d383a  vmovaps xmm8, [rsp+0x80]
00007a44d59d3843  vmovaps xmm9, [rsp+0x90]
00007a44d59d384c  vmovaps xmm10, [rsp+0xA0]
00007a44d59d3855  vmovaps xmm11, [rsp+0xB0]
00007a44d59d385e  vmovaps xmm12, [rsp+0xC0]
00007a44d59d3867  vmovaps xmm14, [rsp+0xD0]
00007a44d59d3870  vmovaps xmm15, [rsp+0xE0]
00007a44d59d3879  add rsp, 0xF0
00007a44d59d3880  pop r11
00007a44d59d3882  pop r10
00007a44d59d3884  pop r9
00007a44d59d3886  pop r8
00007a44d59d3888  pop rsi
00007a44d59d3889  pop rdi
00007a44d59d388a  pop rdx
00007a44d59d388b  pop rcx
00007a44d59d388c  pop rax
00007a44d59d388d  add rsp, 0x08
00007a44d59d3891  jmp 0x00007A44D59D29C1
00007a44d59d3896  call 0x00007A44D57FF430
00007a44d59d389b  jmp 0x00007A44D59D29CE
00007a44d59d38a0  sub rsp, 0x08
00007a44d59d38a4  push rax
00007a44d59d38a5  push rcx
00007a44d59d38a6  push rdx
00007a44d59d38a7  push rdi
00007a44d59d38a8  push rsi
00007a44d59d38a9  push r8
00007a44d59d38ab  push r9
00007a44d59d38ad  push r10
00007a44d59d38af  push r11
00007a44d59d38b1  sub rsp, 0xF0
00007a44d59d38b8  vmovaps [rsp], xmm0
00007a44d59d38bd  vmovaps [rsp+0x10], xmm1
00007a44d59d38c3  vmovaps [rsp+0x20], xmm2
00007a44d59d38c9  vmovaps [rsp+0x30], xmm3
00007a44d59d38cf  vmovaps [rsp+0x40], xmm4
00007a44d59d38d5  vmovaps [rsp+0x50], xmm5
00007a44d59d38db  vmovaps [rsp+0x60], xmm6
00007a44d59d38e1  vmovaps [rsp+0x70], xmm7
00007a44d59d38e7  vmovaps [rsp+0x80], xmm8
00007a44d59d38f0  vmovaps [rsp+0x90], xmm9
00007a44d59d38f9  vmovaps [rsp+0xA0], xmm10
00007a44d59d3902  vmovaps [rsp+0xB0], xmm11
00007a44d59d390b  vmovaps [rsp+0xC0], xmm13
00007a44d59d3914  vmovaps [rsp+0xD0], xmm14
00007a44d59d391d  vmovaps [rsp+0xE0], xmm15
00007a44d59d3926  sub rsp, 0x40
00007a44d59d392a  lea rdi, [rsp]
00007a44d59d392e  lea rsi, [rsp+0x10]
00007a44d59d3933  lea rdx, [rsp+0x20]
00007a44d59d3938  lea rcx, [rsp+0x30]
00007a44d59d393d  mov r8d, 0x00
00007a44d59d3943  lea r9, [r15+0x3A8]
00007a44d59d394a  movaps [rdi], xmm12
00007a44d59d394e  movaps [rsi], xmm15
00007a44d59d3952  movaps [rdx], xmm1
00007a44d59d3955  movaps [rcx], xmm14
00007a44d59d3959  mov rax, 0x56179A4B1A50
00007a44d59d3963  call rax
00007a44d59d3965  movaps xmm12, [rsp]
00007a44d59d396a  add rsp, 0x40
00007a44d59d396e  vmovaps xmm0, [rsp]
00007a44d59d3973  vmovaps xmm1, [rsp+0x10]
00007a44d59d3979  vmovaps xmm2, [rsp+0x20]
00007a44d59d397f  vmovaps xmm3, [rsp+0x30]
00007a44d59d3985  vmovaps xmm4, [rsp+0x40]
00007a44d59d398b  vmovaps xmm5, [rsp+0x50]
00007a44d59d3991  vmovaps xmm6, [rsp+0x60]
00007a44d59d3997  vmovaps xmm7, [rsp+0x70]
00007a44d59d399d  vmovaps xmm8, [rsp+0x80]
00007a44d59d39a6  vmovaps xmm9, [rsp+0x90]
00007a44d59d39af  vmovaps xmm10, [rsp+0xA0]
00007a44d59d39b8  vmovaps xmm11, [rsp+0xB0]
00007a44d59d39c1  vmovaps xmm13, [rsp+0xC0]
00007a44d59d39ca  vmovaps xmm14, [rsp+0xD0]
00007a44d59d39d3  vmovaps xmm15, [rsp+0xE0]
00007a44d59d39dc  add rsp, 0xF0
00007a44d59d39e3  pop r11
00007a44d59d39e5  pop r10
00007a44d59d39e7  pop r9
00007a44d59d39e9  pop r8
00007a44d59d39eb  pop rsi
00007a44d59d39ec  pop rdi
00007a44d59d39ed  pop rdx
00007a44d59d39ee  pop rcx
00007a44d59d39ef  pop rax
00007a44d59d39f0  add rsp, 0x08
00007a44d59d39f4  jmp 0x00007A44D59D29FA
00007a44d59d39f9  sub rsp, 0x08
00007a44d59d39fd  push rax
00007a44d59d39fe  push rcx
00007a44d59d39ff  push rdx
00007a44d59d3a00  push rdi
00007a44d59d3a01  push rsi
00007a44d59d3a02  push r8
00007a44d59d3a04  push r9
00007a44d59d3a06  push r10
00007a44d59d3a08  push r11
00007a44d59d3a0a  sub rsp, 0xF0
00007a44d59d3a11  vmovaps [rsp], xmm0
00007a44d59d3a16  vmovaps [rsp+0x10], xmm1
00007a44d59d3a1c  vmovaps [rsp+0x20], xmm2
00007a44d59d3a22  vmovaps [rsp+0x30], xmm3
00007a44d59d3a28  vmovaps [rsp+0x40], xmm4
00007a44d59d3a2e  vmovaps [rsp+0x50], xmm5
00007a44d59d3a34  vmovaps [rsp+0x60], xmm6
00007a44d59d3a3a  vmovaps [rsp+0x70], xmm7
00007a44d59d3a40  vmovaps [rsp+0x80], xmm8
00007a44d59d3a49  vmovaps [rsp+0x90], xmm9
00007a44d59d3a52  vmovaps [rsp+0xA0], xmm10
00007a44d59d3a5b  vmovaps [rsp+0xB0], xmm11
00007a44d59d3a64  vmovaps [rsp+0xC0], xmm12
00007a44d59d3a6d  vmovaps [rsp+0xD0], xmm14
00007a44d59d3a76  vmovaps [rsp+0xE0], xmm15
00007a44d59d3a7f  sub rsp, 0x40
00007a44d59d3a83  lea rdi, [rsp]
00007a44d59d3a87  lea rsi, [rsp+0x10]
00007a44d59d3a8c  lea rdx, [rsp+0x20]
00007a44d59d3a91  lea rcx, [rsp+0x30]
00007a44d59d3a96  mov r8d, 0x00
00007a44d59d3a9c  lea r9, [r15+0x3A8]
00007a44d59d3aa3  movaps [rdi], xmm13
00007a44d59d3aa7  movaps [rsi], xmm1
00007a44d59d3aaa  movaps [rdx], xmm15
00007a44d59d3aae  movaps [rcx], xmm14
00007a44d59d3ab2  mov rax, 0x56179A4B1A50
00007a44d59d3abc  call rax
00007a44d59d3abe  movaps xmm13, [rsp]
00007a44d59d3ac3  add rsp, 0x40
00007a44d59d3ac7  vmovaps xmm0, [rsp]
00007a44d59d3acc  vmovaps xmm1, [rsp+0x10]
00007a44d59d3ad2  vmovaps xmm2, [rsp+0x20]
00007a44d59d3ad8  vmovaps xmm3, [rsp+0x30]
00007a44d59d3ade  vmovaps xmm4, [rsp+0x40]
00007a44d59d3ae4  vmovaps xmm5, [rsp+0x50]
00007a44d59d3aea  vmovaps xmm6, [rsp+0x60]
00007a44d59d3af0  vmovaps xmm7, [rsp+0x70]
00007a44d59d3af6  vmovaps xmm8, [rsp+0x80]
00007a44d59d3aff  vmovaps xmm9, [rsp+0x90]
00007a44d59d3b08  vmovaps xmm10, [rsp+0xA0]
00007a44d59d3b11  vmovaps xmm11, [rsp+0xB0]
00007a44d59d3b1a  vmovaps xmm12, [rsp+0xC0]
00007a44d59d3b23  vmovaps xmm14, [rsp+0xD0]
00007a44d59d3b2c  vmovaps xmm15, [rsp+0xE0]
00007a44d59d3b35  add rsp, 0xF0
00007a44d59d3b3c  pop r11
00007a44d59d3b3e  pop r10
00007a44d59d3b40  pop r9
00007a44d59d3b42  pop r8
00007a44d59d3b44  pop rsi
00007a44d59d3b45  pop rdi
00007a44d59d3b46  pop rdx
00007a44d59d3b47  pop rcx
00007a44d59d3b48  pop rax
00007a44d59d3b49  add rsp, 0x08
00007a44d59d3b4d  jmp 0x00007A44D59D2B77
00007a44d59d3b52  sub rsp, 0x08
00007a44d59d3b56  push rax
00007a44d59d3b57  push rcx
00007a44d59d3b58  push rdx
00007a44d59d3b59  push rdi
00007a44d59d3b5a  push rsi
00007a44d59d3b5b  push r8
00007a44d59d3b5d  push r9
00007a44d59d3b5f  push r10
00007a44d59d3b61  push r11
00007a44d59d3b63  sub rsp, 0xF0
00007a44d59d3b6a  vmovaps [rsp], xmm0
00007a44d59d3b6f  vmovaps [rsp+0x10], xmm1
00007a44d59d3b75  vmovaps [rsp+0x20], xmm2
00007a44d59d3b7b  vmovaps [rsp+0x30], xmm3
00007a44d59d3b81  vmovaps [rsp+0x40], xmm4
00007a44d59d3b87  vmovaps [rsp+0x50], xmm5
00007a44d59d3b8d  vmovaps [rsp+0x60], xmm6
00007a44d59d3b93  vmovaps [rsp+0x70], xmm7
00007a44d59d3b99  vmovaps [rsp+0x80], xmm8
00007a44d59d3ba2  vmovaps [rsp+0x90], xmm9
00007a44d59d3bab  vmovaps [rsp+0xA0], xmm10
00007a44d59d3bb4  vmovaps [rsp+0xB0], xmm11
00007a44d59d3bbd  vmovaps [rsp+0xC0], xmm13
00007a44d59d3bc6  vmovaps [rsp+0xD0], xmm14
00007a44d59d3bcf  vmovaps [rsp+0xE0], xmm15
00007a44d59d3bd8  sub rsp, 0x40
00007a44d59d3bdc  lea rdi, [rsp]
00007a44d59d3be0  lea rsi, [rsp+0x10]
00007a44d59d3be5  lea rdx, [rsp+0x20]
00007a44d59d3bea  lea rcx, [rsp+0x30]
00007a44d59d3bef  mov r8d, 0x00
00007a44d59d3bf5  lea r9, [r15+0x3A8]
00007a44d59d3bfc  movaps [rdi], xmm12
00007a44d59d3c00  movaps [rsi], xmm15
00007a44d59d3c04  movaps [rdx], xmm14
00007a44d59d3c08  movaps [rcx], xmm1
00007a44d59d3c0b  mov rax, 0x56179A4B1A50
00007a44d59d3c15  call rax
00007a44d59d3c17  movaps xmm12, [rsp]
00007a44d59d3c1c  add rsp, 0x40
00007a44d59d3c20  vmovaps xmm0, [rsp]
00007a44d59d3c25  vmovaps xmm1, [rsp+0x10]
00007a44d59d3c2b  vmovaps xmm2, [rsp+0x20]
00007a44d59d3c31  vmovaps xmm3, [rsp+0x30]
00007a44d59d3c37  vmovaps xmm4, [rsp+0x40]
00007a44d59d3c3d  vmovaps xmm5, [rsp+0x50]
00007a44d59d3c43  vmovaps xmm6, [rsp+0x60]
00007a44d59d3c49  vmovaps xmm7, [rsp+0x70]
00007a44d59d3c4f  vmovaps xmm8, [rsp+0x80]
00007a44d59d3c58  vmovaps xmm9, [rsp+0x90]
00007a44d59d3c61  vmovaps xmm10, [rsp+0xA0]
00007a44d59d3c6a  vmovaps xmm11, [rsp+0xB0]
00007a44d59d3c73  vmovaps xmm13, [rsp+0xC0]
00007a44d59d3c7c  vmovaps xmm14, [rsp+0xD0]
00007a44d59d3c85  vmovaps xmm15, [rsp+0xE0]
00007a44d59d3c8e  add rsp, 0xF0
00007a44d59d3c95  pop r11
00007a44d59d3c97  pop r10
00007a44d59d3c99  pop r9
00007a44d59d3c9b  pop r8
00007a44d59d3c9d  pop rsi
00007a44d59d3c9e  pop rdi
00007a44d59d3c9f  pop rdx
00007a44d59d3ca0  pop rcx
00007a44d59d3ca1  pop rax
00007a44d59d3ca2  add rsp, 0x08
00007a44d59d3ca6  jmp 0x00007A44D59D2BB2
00007a44d59d3cab  sub rsp, 0x08
00007a44d59d3caf  push rax
00007a44d59d3cb0  push rcx
00007a44d59d3cb1  push rdx
00007a44d59d3cb2  push rdi
00007a44d59d3cb3  push rsi
00007a44d59d3cb4  push r8
00007a44d59d3cb6  push r9
00007a44d59d3cb8  push r10
00007a44d59d3cba  push r11
00007a44d59d3cbc  sub rsp, 0xF0
00007a44d59d3cc3  vmovaps [rsp], xmm0
00007a44d59d3cc8  vmovaps [rsp+0x10], xmm1
00007a44d59d3cce  vmovaps [rsp+0x20], xmm2
00007a44d59d3cd4  vmovaps [rsp+0x30], xmm3
00007a44d59d3cda  vmovaps [rsp+0x40], xmm4
00007a44d59d3ce0  vmovaps [rsp+0x50], xmm5
00007a44d59d3ce6  vmovaps [rsp+0x60], xmm6
00007a44d59d3cec  vmovaps [rsp+0x70], xmm7
00007a44d59d3cf2  vmovaps [rsp+0x80], xmm8
00007a44d59d3cfb  vmovaps [rsp+0x90], xmm9
00007a44d59d3d04  vmovaps [rsp+0xA0], xmm10
00007a44d59d3d0d  vmovaps [rsp+0xB0], xmm11
00007a44d59d3d16  vmovaps [rsp+0xC0], xmm12
00007a44d59d3d1f  vmovaps [rsp+0xD0], xmm14
00007a44d59d3d28  vmovaps [rsp+0xE0], xmm15
00007a44d59d3d31  sub rsp, 0x40
00007a44d59d3d35  lea rdi, [rsp]
00007a44d59d3d39  lea rsi, [rsp+0x10]
00007a44d59d3d3e  lea rdx, [rsp+0x20]
00007a44d59d3d43  lea rcx, [rsp+0x30]
00007a44d59d3d48  mov r8d, 0x00
00007a44d59d3d4e  lea r9, [r15+0x3A8]
00007a44d59d3d55  movaps [rdi], xmm13
00007a44d59d3d59  movaps [rsi], xmm15
00007a44d59d3d5d  movaps [rdx], xmm14
00007a44d59d3d61  movaps [rcx], xmm1
00007a44d59d3d64  mov rax, 0x56179A4B1A50
00007a44d59d3d6e  call rax
00007a44d59d3d70  movaps xmm13, [rsp]
00007a44d59d3d75  add rsp, 0x40
00007a44d59d3d79  vmovaps xmm0, [rsp]
00007a44d59d3d7e  vmovaps xmm1, [rsp+0x10]
00007a44d59d3d84  vmovaps xmm2, [rsp+0x20]
00007a44d59d3d8a  vmovaps xmm3, [rsp+0x30]
00007a44d59d3d90  vmovaps xmm4, [rsp+0x40]
00007a44d59d3d96  vmovaps xmm5, [rsp+0x50]
00007a44d59d3d9c  vmovaps xmm6, [rsp+0x60]
00007a44d59d3da2  vmovaps xmm7, [rsp+0x70]
00007a44d59d3da8  vmovaps xmm8, [rsp+0x80]
00007a44d59d3db1  vmovaps xmm9, [rsp+0x90]
00007a44d59d3dba  vmovaps xmm10, [rsp+0xA0]
00007a44d59d3dc3  vmovaps xmm11, [rsp+0xB0]
00007a44d59d3dcc  vmovaps xmm12, [rsp+0xC0]
00007a44d59d3dd5  vmovaps xmm14, [rsp+0xD0]
00007a44d59d3dde  vmovaps xmm15, [rsp+0xE0]
00007a44d59d3de7  add rsp, 0xF0
00007a44d59d3dee  pop r11
00007a44d59d3df0  pop r10
00007a44d59d3df2  pop r9
00007a44d59d3df4  pop r8
00007a44d59d3df6  pop rsi
00007a44d59d3df7  pop rdi
00007a44d59d3df8  pop rdx
00007a44d59d3df9  pop rcx
00007a44d59d3dfa  pop rax
00007a44d59d3dfb  add rsp, 0x08
00007a44d59d3dff  jmp 0x00007A44D59D2BEA
00007a44d59d3e04  sub rsp, 0x08
00007a44d59d3e08  push rax
00007a44d59d3e09  push rcx
00007a44d59d3e0a  push rdx
00007a44d59d3e0b  push rdi
00007a44d59d3e0c  push rsi
00007a44d59d3e0d  push r8
00007a44d59d3e0f  push r9
00007a44d59d3e11  push r10
00007a44d59d3e13  push r11
00007a44d59d3e15  sub rsp, 0xF0
00007a44d59d3e1c  vmovaps [rsp], xmm0
00007a44d59d3e21  vmovaps [rsp+0x10], xmm1
00007a44d59d3e27  vmovaps [rsp+0x20], xmm2
00007a44d59d3e2d  vmovaps [rsp+0x30], xmm3
00007a44d59d3e33  vmovaps [rsp+0x40], xmm4
00007a44d59d3e39  vmovaps [rsp+0x50], xmm5
00007a44d59d3e3f  vmovaps [rsp+0x60], xmm6
00007a44d59d3e45  vmovaps [rsp+0x70], xmm7
00007a44d59d3e4b  vmovaps [rsp+0x80], xmm8
00007a44d59d3e54  vmovaps [rsp+0x90], xmm9
00007a44d59d3e5d  vmovaps [rsp+0xA0], xmm10
00007a44d59d3e66  vmovaps [rsp+0xB0], xmm11
00007a44d59d3e6f  vmovaps [rsp+0xC0], xmm13
00007a44d59d3e78  vmovaps [rsp+0xD0], xmm14
00007a44d59d3e81  vmovaps [rsp+0xE0], xmm15
00007a44d59d3e8a  sub rsp, 0x40
00007a44d59d3e8e  lea rdi, [rsp]
00007a44d59d3e92  lea rsi, [rsp+0x10]
00007a44d59d3e97  lea rdx, [rsp+0x20]
00007a44d59d3e9c  lea rcx, [rsp+0x30]
00007a44d59d3ea1  mov r8d, 0x00
00007a44d59d3ea7  lea r9, [r15+0x3A8]
00007a44d59d3eae  movaps [rdi], xmm12
00007a44d59d3eb2  movaps [rsi], xmm15
00007a44d59d3eb6  movaps [rdx], xmm14
00007a44d59d3eba  movaps [rcx], xmm1
00007a44d59d3ebd  mov rax, 0x56179A4B1A50
00007a44d59d3ec7  call rax
00007a44d59d3ec9  movaps xmm12, [rsp]
00007a44d59d3ece  add rsp, 0x40
00007a44d59d3ed2  vmovaps xmm0, [rsp]
00007a44d59d3ed7  vmovaps xmm1, [rsp+0x10]
00007a44d59d3edd  vmovaps xmm2, [rsp+0x20]
00007a44d59d3ee3  vmovaps xmm3, [rsp+0x30]
00007a44d59d3ee9  vmovaps xmm4, [rsp+0x40]
00007a44d59d3eef  vmovaps xmm5, [rsp+0x50]
00007a44d59d3ef5  vmovaps xmm6, [rsp+0x60]
00007a44d59d3efb  vmovaps xmm7, [rsp+0x70]
00007a44d59d3f01  vmovaps xmm8, [rsp+0x80]
00007a44d59d3f0a  vmovaps xmm9, [rsp+0x90]
00007a44d59d3f13  vmovaps xmm10, [rsp+0xA0]
00007a44d59d3f1c  vmovaps xmm11, [rsp+0xB0]
00007a44d59d3f25  vmovaps xmm13, [rsp+0xC0]
00007a44d59d3f2e  vmovaps xmm14, [rsp+0xD0]
00007a44d59d3f37  vmovaps xmm15, [rsp+0xE0]
00007a44d59d3f40  add rsp, 0xF0
00007a44d59d3f47  pop r11
00007a44d59d3f49  pop r10
00007a44d59d3f4b  pop r9
00007a44d59d3f4d  pop r8
00007a44d59d3f4f  pop rsi
00007a44d59d3f50  pop rdi
00007a44d59d3f51  pop rdx
00007a44d59d3f52  pop rcx
00007a44d59d3f53  pop rax
00007a44d59d3f54  add rsp, 0x08
00007a44d59d3f58  jmp 0x00007A44D59D2C3D
00007a44d59d3f5d  sub rsp, 0x08
00007a44d59d3f61  push rax
00007a44d59d3f62  push rcx
00007a44d59d3f63  push rdx
00007a44d59d3f64  push rdi
00007a44d59d3f65  push rsi
00007a44d59d3f66  push r8
00007a44d59d3f68  push r9
00007a44d59d3f6a  push r10
00007a44d59d3f6c  push r11
00007a44d59d3f6e  sub rsp, 0xF0
00007a44d59d3f75  vmovaps [rsp], xmm0
00007a44d59d3f7a  vmovaps [rsp+0x10], xmm1
00007a44d59d3f80  vmovaps [rsp+0x20], xmm2
00007a44d59d3f86  vmovaps [rsp+0x30], xmm3
00007a44d59d3f8c  vmovaps [rsp+0x40], xmm4
00007a44d59d3f92  vmovaps [rsp+0x50], xmm5
00007a44d59d3f98  vmovaps [rsp+0x60], xmm6
00007a44d59d3f9e  vmovaps [rsp+0x70], xmm7
00007a44d59d3fa4  vmovaps [rsp+0x80], xmm8
00007a44d59d3fad  vmovaps [rsp+0x90], xmm9
00007a44d59d3fb6  vmovaps [rsp+0xA0], xmm10
00007a44d59d3fbf  vmovaps [rsp+0xB0], xmm11
00007a44d59d3fc8  vmovaps [rsp+0xC0], xmm12
00007a44d59d3fd1  vmovaps [rsp+0xD0], xmm13
00007a44d59d3fda  vmovaps [rsp+0xE0], xmm15
00007a44d59d3fe3  sub rsp, 0x40
00007a44d59d3fe7  lea rdi, [rsp]
00007a44d59d3feb  lea rsi, [rsp+0x10]
00007a44d59d3ff0  lea rdx, [rsp+0x20]
00007a44d59d3ff5  lea rcx, [rsp+0x30]
00007a44d59d3ffa  mov r8d, 0x00
00007a44d59d4000  lea r9, [r15+0x3A8]
00007a44d59d4007  movaps [rdi], xmm14
00007a44d59d400b  movaps [rsi], xmm3
00007a44d59d400e  movaps [rdx], xmm1
00007a44d59d4011  movaps [rcx], xmm15
00007a44d59d4015  mov rax, 0x56179A4B1A50
00007a44d59d401f  call rax
00007a44d59d4021  movaps xmm14, [rsp]
00007a44d59d4026  add rsp, 0x40
00007a44d59d402a  vmovaps xmm0, [rsp]
00007a44d59d402f  vmovaps xmm1, [rsp+0x10]
00007a44d59d4035  vmovaps xmm2, [rsp+0x20]
00007a44d59d403b  vmovaps xmm3, [rsp+0x30]
00007a44d59d4041  vmovaps xmm4, [rsp+0x40]
00007a44d59d4047  vmovaps xmm5, [rsp+0x50]
00007a44d59d404d  vmovaps xmm6, [rsp+0x60]
00007a44d59d4053  vmovaps xmm7, [rsp+0x70]
00007a44d59d4059  vmovaps xmm8, [rsp+0x80]
00007a44d59d4062  vmovaps xmm9, [rsp+0x90]
00007a44d59d406b  vmovaps xmm10, [rsp+0xA0]
00007a44d59d4074  vmovaps xmm11, [rsp+0xB0]
00007a44d59d407d  vmovaps xmm12, [rsp+0xC0]
00007a44d59d4086  vmovaps xmm13, [rsp+0xD0]
00007a44d59d408f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d4098  add rsp, 0xF0
00007a44d59d409f  pop r11
00007a44d59d40a1  pop r10
00007a44d59d40a3  pop r9
00007a44d59d40a5  pop r8
00007a44d59d40a7  pop rsi
00007a44d59d40a8  pop rdi
00007a44d59d40a9  pop rdx
00007a44d59d40aa  pop rcx
00007a44d59d40ab  pop rax
00007a44d59d40ac  add rsp, 0x08
00007a44d59d40b0  jmp 0x00007A44D59D2CF7
00007a44d59d40b5  sub rsp, 0x08
00007a44d59d40b9  push rax
00007a44d59d40ba  push rcx
00007a44d59d40bb  push rdx
00007a44d59d40bc  push rdi
00007a44d59d40bd  push rsi
00007a44d59d40be  push r8
00007a44d59d40c0  push r9
00007a44d59d40c2  push r10
00007a44d59d40c4  push r11
00007a44d59d40c6  sub rsp, 0xF0
00007a44d59d40cd  vmovaps [rsp], xmm0
00007a44d59d40d2  vmovaps [rsp+0x10], xmm1
00007a44d59d40d8  vmovaps [rsp+0x20], xmm2
00007a44d59d40de  vmovaps [rsp+0x30], xmm3
00007a44d59d40e4  vmovaps [rsp+0x40], xmm4
00007a44d59d40ea  vmovaps [rsp+0x50], xmm5
00007a44d59d40f0  vmovaps [rsp+0x60], xmm6
00007a44d59d40f6  vmovaps [rsp+0x70], xmm7
00007a44d59d40fc  vmovaps [rsp+0x80], xmm8
00007a44d59d4105  vmovaps [rsp+0x90], xmm9
00007a44d59d410e  vmovaps [rsp+0xA0], xmm10
00007a44d59d4117  vmovaps [rsp+0xB0], xmm11
00007a44d59d4120  vmovaps [rsp+0xC0], xmm12
00007a44d59d4129  vmovaps [rsp+0xD0], xmm14
00007a44d59d4132  vmovaps [rsp+0xE0], xmm15
00007a44d59d413b  sub rsp, 0x40
00007a44d59d413f  lea rdi, [rsp]
00007a44d59d4143  lea rsi, [rsp+0x10]
00007a44d59d4148  lea rdx, [rsp+0x20]
00007a44d59d414d  lea rcx, [rsp+0x30]
00007a44d59d4152  mov r8d, 0x00
00007a44d59d4158  lea r9, [r15+0x3A8]
00007a44d59d415f  movaps [rdi], xmm13
00007a44d59d4163  movaps [rsi], xmm15
00007a44d59d4167  movaps [rdx], xmm10
00007a44d59d416b  movaps [rcx], xmm1
00007a44d59d416e  mov rax, 0x56179A4B1A50
00007a44d59d4178  call rax
00007a44d59d417a  movaps xmm13, [rsp]
00007a44d59d417f  add rsp, 0x40
00007a44d59d4183  vmovaps xmm0, [rsp]
00007a44d59d4188  vmovaps xmm1, [rsp+0x10]
00007a44d59d418e  vmovaps xmm2, [rsp+0x20]
00007a44d59d4194  vmovaps xmm3, [rsp+0x30]
00007a44d59d419a  vmovaps xmm4, [rsp+0x40]
00007a44d59d41a0  vmovaps xmm5, [rsp+0x50]
00007a44d59d41a6  vmovaps xmm6, [rsp+0x60]
00007a44d59d41ac  vmovaps xmm7, [rsp+0x70]
00007a44d59d41b2  vmovaps xmm8, [rsp+0x80]
00007a44d59d41bb  vmovaps xmm9, [rsp+0x90]
00007a44d59d41c4  vmovaps xmm10, [rsp+0xA0]
00007a44d59d41cd  vmovaps xmm11, [rsp+0xB0]
00007a44d59d41d6  vmovaps xmm12, [rsp+0xC0]
00007a44d59d41df  vmovaps xmm14, [rsp+0xD0]
00007a44d59d41e8  vmovaps xmm15, [rsp+0xE0]
00007a44d59d41f1  add rsp, 0xF0
00007a44d59d41f8  pop r11
00007a44d59d41fa  pop r10
00007a44d59d41fc  pop r9
00007a44d59d41fe  pop r8
00007a44d59d4200  pop rsi
00007a44d59d4201  pop rdi
00007a44d59d4202  pop rdx
00007a44d59d4203  pop rcx
00007a44d59d4204  pop rax
00007a44d59d4205  add rsp, 0x08
00007a44d59d4209  jmp 0x00007A44D59D2D26
00007a44d59d420e  sub rsp, 0x08
00007a44d59d4212  push rax
00007a44d59d4213  push rcx
00007a44d59d4214  push rdx
00007a44d59d4215  push rdi
00007a44d59d4216  push rsi
00007a44d59d4217  push r8
00007a44d59d4219  push r9
00007a44d59d421b  push r10
00007a44d59d421d  push r11
00007a44d59d421f  sub rsp, 0xF0
00007a44d59d4226  vmovaps [rsp], xmm0
00007a44d59d422b  vmovaps [rsp+0x10], xmm1
00007a44d59d4231  vmovaps [rsp+0x20], xmm2
00007a44d59d4237  vmovaps [rsp+0x30], xmm3
00007a44d59d423d  vmovaps [rsp+0x40], xmm4
00007a44d59d4243  vmovaps [rsp+0x50], xmm5
00007a44d59d4249  vmovaps [rsp+0x60], xmm6
00007a44d59d424f  vmovaps [rsp+0x70], xmm7
00007a44d59d4255  vmovaps [rsp+0x80], xmm8
00007a44d59d425e  vmovaps [rsp+0x90], xmm9
00007a44d59d4267  vmovaps [rsp+0xA0], xmm11
00007a44d59d4270  vmovaps [rsp+0xB0], xmm12
00007a44d59d4279  vmovaps [rsp+0xC0], xmm13
00007a44d59d4282  vmovaps [rsp+0xD0], xmm14
00007a44d59d428b  vmovaps [rsp+0xE0], xmm15
00007a44d59d4294  sub rsp, 0x40
00007a44d59d4298  lea rdi, [rsp]
00007a44d59d429c  lea rsi, [rsp+0x10]
00007a44d59d42a1  lea rdx, [rsp+0x20]
00007a44d59d42a6  lea rcx, [rsp+0x30]
00007a44d59d42ab  mov r8d, 0x00
00007a44d59d42b1  lea r9, [r15+0x3A8]
00007a44d59d42b8  movaps [rdi], xmm10
00007a44d59d42bc  movaps [rsi], xmm15
00007a44d59d42c0  movaps [rdx], xmm11
00007a44d59d42c4  movaps [rcx], xmm1
00007a44d59d42c7  mov rax, 0x56179A4B1A50
00007a44d59d42d1  call rax
00007a44d59d42d3  movaps xmm10, [rsp]
00007a44d59d42d8  add rsp, 0x40
00007a44d59d42dc  vmovaps xmm0, [rsp]
00007a44d59d42e1  vmovaps xmm1, [rsp+0x10]
00007a44d59d42e7  vmovaps xmm2, [rsp+0x20]
00007a44d59d42ed  vmovaps xmm3, [rsp+0x30]
00007a44d59d42f3  vmovaps xmm4, [rsp+0x40]
00007a44d59d42f9  vmovaps xmm5, [rsp+0x50]
00007a44d59d42ff  vmovaps xmm6, [rsp+0x60]
00007a44d59d4305  vmovaps xmm7, [rsp+0x70]
00007a44d59d430b  vmovaps xmm8, [rsp+0x80]
00007a44d59d4314  vmovaps xmm9, [rsp+0x90]
00007a44d59d431d  vmovaps xmm11, [rsp+0xA0]
00007a44d59d4326  vmovaps xmm12, [rsp+0xB0]
00007a44d59d432f  vmovaps xmm13, [rsp+0xC0]
00007a44d59d4338  vmovaps xmm14, [rsp+0xD0]
00007a44d59d4341  vmovaps xmm15, [rsp+0xE0]
00007a44d59d434a  add rsp, 0xF0
00007a44d59d4351  pop r11
00007a44d59d4353  pop r10
00007a44d59d4355  pop r9
00007a44d59d4357  pop r8
00007a44d59d4359  pop rsi
00007a44d59d435a  pop rdi
00007a44d59d435b  pop rdx
00007a44d59d435c  pop rcx
00007a44d59d435d  pop rax
00007a44d59d435e  add rsp, 0x08
00007a44d59d4362  jmp 0x00007A44D59D2D55
00007a44d59d4367  sub rsp, 0x08
00007a44d59d436b  push rax
00007a44d59d436c  push rcx
00007a44d59d436d  push rdx
00007a44d59d436e  push rdi
00007a44d59d436f  push rsi
00007a44d59d4370  push r8
00007a44d59d4372  push r9
00007a44d59d4374  push r10
00007a44d59d4376  push r11
00007a44d59d4378  sub rsp, 0xF0
00007a44d59d437f  vmovaps [rsp], xmm0
00007a44d59d4384  vmovaps [rsp+0x10], xmm1
00007a44d59d438a  vmovaps [rsp+0x20], xmm2
00007a44d59d4390  vmovaps [rsp+0x30], xmm3
00007a44d59d4396  vmovaps [rsp+0x40], xmm4
00007a44d59d439c  vmovaps [rsp+0x50], xmm5
00007a44d59d43a2  vmovaps [rsp+0x60], xmm6
00007a44d59d43a8  vmovaps [rsp+0x70], xmm7
00007a44d59d43ae  vmovaps [rsp+0x80], xmm8
00007a44d59d43b7  vmovaps [rsp+0x90], xmm9
00007a44d59d43c0  vmovaps [rsp+0xA0], xmm10
00007a44d59d43c9  vmovaps [rsp+0xB0], xmm11
00007a44d59d43d2  vmovaps [rsp+0xC0], xmm12
00007a44d59d43db  vmovaps [rsp+0xD0], xmm13
00007a44d59d43e4  vmovaps [rsp+0xE0], xmm14
00007a44d59d43ed  sub rsp, 0x40
00007a44d59d43f1  lea rdi, [rsp]
00007a44d59d43f5  lea rsi, [rsp+0x10]
00007a44d59d43fa  lea rdx, [rsp+0x20]
00007a44d59d43ff  lea rcx, [rsp+0x30]
00007a44d59d4404  mov r8d, 0x00
00007a44d59d440a  lea r9, [r15+0x3A8]
00007a44d59d4411  movaps [rdi], xmm15
00007a44d59d4415  movaps [rsi], xmm12
00007a44d59d4419  movaps [rdx], xmm5
00007a44d59d441c  movaps [rcx], xmm1
00007a44d59d441f  mov rax, 0x56179A4B1A50
00007a44d59d4429  call rax
00007a44d59d442b  movaps xmm15, [rsp]
00007a44d59d4430  add rsp, 0x40
00007a44d59d4434  vmovaps xmm0, [rsp]
00007a44d59d4439  vmovaps xmm1, [rsp+0x10]
00007a44d59d443f  vmovaps xmm2, [rsp+0x20]
00007a44d59d4445  vmovaps xmm3, [rsp+0x30]
00007a44d59d444b  vmovaps xmm4, [rsp+0x40]
00007a44d59d4451  vmovaps xmm5, [rsp+0x50]
00007a44d59d4457  vmovaps xmm6, [rsp+0x60]
00007a44d59d445d  vmovaps xmm7, [rsp+0x70]
00007a44d59d4463  vmovaps xmm8, [rsp+0x80]
00007a44d59d446c  vmovaps xmm9, [rsp+0x90]
00007a44d59d4475  vmovaps xmm10, [rsp+0xA0]
00007a44d59d447e  vmovaps xmm11, [rsp+0xB0]
00007a44d59d4487  vmovaps xmm12, [rsp+0xC0]
00007a44d59d4490  vmovaps xmm13, [rsp+0xD0]
00007a44d59d4499  vmovaps xmm14, [rsp+0xE0]
00007a44d59d44a2  add rsp, 0xF0
00007a44d59d44a9  pop r11
00007a44d59d44ab  pop r10
00007a44d59d44ad  pop r9
00007a44d59d44af  pop r8
00007a44d59d44b1  pop rsi
00007a44d59d44b2  pop rdi
00007a44d59d44b3  pop rdx
00007a44d59d44b4  pop rcx
00007a44d59d44b5  pop rax
00007a44d59d44b6  add rsp, 0x08
00007a44d59d44ba  jmp 0x00007A44D59D2D7E
00007a44d59d44bf  sub rsp, 0x08
00007a44d59d44c3  push rax
00007a44d59d44c4  push rcx
00007a44d59d44c5  push rdx
00007a44d59d44c6  push rdi
00007a44d59d44c7  push rsi
00007a44d59d44c8  push r8
00007a44d59d44ca  push r9
00007a44d59d44cc  push r10
00007a44d59d44ce  push r11
00007a44d59d44d0  sub rsp, 0xF0
00007a44d59d44d7  vmovaps [rsp], xmm0
00007a44d59d44dc  vmovaps [rsp+0x10], xmm1
00007a44d59d44e2  vmovaps [rsp+0x20], xmm2
00007a44d59d44e8  vmovaps [rsp+0x30], xmm3
00007a44d59d44ee  vmovaps [rsp+0x40], xmm4
00007a44d59d44f4  vmovaps [rsp+0x50], xmm6
00007a44d59d44fa  vmovaps [rsp+0x60], xmm7
00007a44d59d4500  vmovaps [rsp+0x70], xmm8
00007a44d59d4506  vmovaps [rsp+0x80], xmm9
00007a44d59d450f  vmovaps [rsp+0x90], xmm10
00007a44d59d4518  vmovaps [rsp+0xA0], xmm11
00007a44d59d4521  vmovaps [rsp+0xB0], xmm12
00007a44d59d452a  vmovaps [rsp+0xC0], xmm13
00007a44d59d4533  vmovaps [rsp+0xD0], xmm14
00007a44d59d453c  vmovaps [rsp+0xE0], xmm15
00007a44d59d4545  sub rsp, 0x40
00007a44d59d4549  lea rdi, [rsp]
00007a44d59d454d  lea rsi, [rsp+0x10]
00007a44d59d4552  lea rdx, [rsp+0x20]
00007a44d59d4557  lea rcx, [rsp+0x30]
00007a44d59d455c  mov r8d, 0x00
00007a44d59d4562  lea r9, [r15+0x3A8]
00007a44d59d4569  movaps [rdi], xmm5
00007a44d59d456c  movaps [rsi], xmm13
00007a44d59d4570  movaps [rdx], xmm11
00007a44d59d4574  movaps [rcx], xmm12
00007a44d59d4578  mov rax, 0x56179A4B1A50
00007a44d59d4582  call rax
00007a44d59d4584  movaps xmm5, [rsp]
00007a44d59d4588  add rsp, 0x40
00007a44d59d458c  vmovaps xmm0, [rsp]
00007a44d59d4591  vmovaps xmm1, [rsp+0x10]
00007a44d59d4597  vmovaps xmm2, [rsp+0x20]
00007a44d59d459d  vmovaps xmm3, [rsp+0x30]
00007a44d59d45a3  vmovaps xmm4, [rsp+0x40]
00007a44d59d45a9  vmovaps xmm6, [rsp+0x50]
00007a44d59d45af  vmovaps xmm7, [rsp+0x60]
00007a44d59d45b5  vmovaps xmm8, [rsp+0x70]
00007a44d59d45bb  vmovaps xmm9, [rsp+0x80]
00007a44d59d45c4  vmovaps xmm10, [rsp+0x90]
00007a44d59d45cd  vmovaps xmm11, [rsp+0xA0]
00007a44d59d45d6  vmovaps xmm12, [rsp+0xB0]
00007a44d59d45df  vmovaps xmm13, [rsp+0xC0]
00007a44d59d45e8  vmovaps xmm14, [rsp+0xD0]
00007a44d59d45f1  vmovaps xmm15, [rsp+0xE0]
00007a44d59d45fa  add rsp, 0xF0
00007a44d59d4601  pop r11
00007a44d59d4603  pop r10
00007a44d59d4605  pop r9
00007a44d59d4607  pop r8
00007a44d59d4609  pop rsi
00007a44d59d460a  pop rdi
00007a44d59d460b  pop rdx
00007a44d59d460c  pop rcx
00007a44d59d460d  pop rax
00007a44d59d460e  add rsp, 0x08
00007a44d59d4612  jmp 0x00007A44D59D2DDD
00007a44d59d4617  sub rsp, 0x08
00007a44d59d461b  push rax
00007a44d59d461c  push rcx
00007a44d59d461d  push rdx
00007a44d59d461e  push rdi
00007a44d59d461f  push rsi
00007a44d59d4620  push r8
00007a44d59d4622  push r9
00007a44d59d4624  push r10
00007a44d59d4626  push r11
00007a44d59d4628  sub rsp, 0xF0
00007a44d59d462f  vmovaps [rsp], xmm0
00007a44d59d4634  vmovaps [rsp+0x10], xmm1
00007a44d59d463a  vmovaps [rsp+0x20], xmm2
00007a44d59d4640  vmovaps [rsp+0x30], xmm3
00007a44d59d4646  vmovaps [rsp+0x40], xmm4
00007a44d59d464c  vmovaps [rsp+0x50], xmm5
00007a44d59d4652  vmovaps [rsp+0x60], xmm6
00007a44d59d4658  vmovaps [rsp+0x70], xmm7
00007a44d59d465e  vmovaps [rsp+0x80], xmm8
00007a44d59d4667  vmovaps [rsp+0x90], xmm9
00007a44d59d4670  vmovaps [rsp+0xA0], xmm10
00007a44d59d4679  vmovaps [rsp+0xB0], xmm11
00007a44d59d4682  vmovaps [rsp+0xC0], xmm13
00007a44d59d468b  vmovaps [rsp+0xD0], xmm14
00007a44d59d4694  vmovaps [rsp+0xE0], xmm15
00007a44d59d469d  sub rsp, 0x40
00007a44d59d46a1  lea rdi, [rsp]
00007a44d59d46a5  lea rsi, [rsp+0x10]
00007a44d59d46aa  lea rdx, [rsp+0x20]
00007a44d59d46af  lea rcx, [rsp+0x30]
00007a44d59d46b4  mov r8d, 0x00
00007a44d59d46ba  lea r9, [r15+0x3A8]
00007a44d59d46c1  movaps [rdi], xmm12
00007a44d59d46c5  movaps [rsi], xmm14
00007a44d59d46c9  movaps [rdx], xmm9
00007a44d59d46cd  movaps [rcx], xmm13
00007a44d59d46d1  mov rax, 0x56179A4B1A50
00007a44d59d46db  call rax
00007a44d59d46dd  movaps xmm12, [rsp]
00007a44d59d46e2  add rsp, 0x40
00007a44d59d46e6  vmovaps xmm0, [rsp]
00007a44d59d46eb  vmovaps xmm1, [rsp+0x10]
00007a44d59d46f1  vmovaps xmm2, [rsp+0x20]
00007a44d59d46f7  vmovaps xmm3, [rsp+0x30]
00007a44d59d46fd  vmovaps xmm4, [rsp+0x40]
00007a44d59d4703  vmovaps xmm5, [rsp+0x50]
00007a44d59d4709  vmovaps xmm6, [rsp+0x60]
00007a44d59d470f  vmovaps xmm7, [rsp+0x70]
00007a44d59d4715  vmovaps xmm8, [rsp+0x80]
00007a44d59d471e  vmovaps xmm9, [rsp+0x90]
00007a44d59d4727  vmovaps xmm10, [rsp+0xA0]
00007a44d59d4730  vmovaps xmm11, [rsp+0xB0]
00007a44d59d4739  vmovaps xmm13, [rsp+0xC0]
00007a44d59d4742  vmovaps xmm14, [rsp+0xD0]
00007a44d59d474b  vmovaps xmm15, [rsp+0xE0]
00007a44d59d4754  add rsp, 0xF0
00007a44d59d475b  pop r11
00007a44d59d475d  pop r10
00007a44d59d475f  pop r9
00007a44d59d4761  pop r8
00007a44d59d4763  pop rsi
00007a44d59d4764  pop rdi
00007a44d59d4765  pop rdx
00007a44d59d4766  pop rcx
00007a44d59d4767  pop rax
00007a44d59d4768  add rsp, 0x08
00007a44d59d476c  jmp 0x00007A44D59D2E06
00007a44d59d4771  call 0x00007A44D580D4E0
00007a44d59d4776  jmp 0x00007A44D59D2E13
00007a44d59d477b  sub rsp, 0x08
00007a44d59d477f  push rax
00007a44d59d4780  push rcx
00007a44d59d4781  push rdx
00007a44d59d4782  push rdi
00007a44d59d4783  push rsi
00007a44d59d4784  push r8
00007a44d59d4786  push r9
00007a44d59d4788  push r10
00007a44d59d478a  push r11
00007a44d59d478c  sub rsp, 0xF0
00007a44d59d4793  vmovaps [rsp], xmm0
00007a44d59d4798  vmovaps [rsp+0x10], xmm1
00007a44d59d479e  vmovaps [rsp+0x20], xmm2
00007a44d59d47a4  vmovaps [rsp+0x30], xmm3
00007a44d59d47aa  vmovaps [rsp+0x40], xmm4
00007a44d59d47b0  vmovaps [rsp+0x50], xmm5
00007a44d59d47b6  vmovaps [rsp+0x60], xmm6
00007a44d59d47bc  vmovaps [rsp+0x70], xmm7
00007a44d59d47c2  vmovaps [rsp+0x80], xmm8
00007a44d59d47cb  vmovaps [rsp+0x90], xmm9
00007a44d59d47d4  vmovaps [rsp+0xA0], xmm10
00007a44d59d47dd  vmovaps [rsp+0xB0], xmm12
00007a44d59d47e6  vmovaps [rsp+0xC0], xmm13
00007a44d59d47ef  vmovaps [rsp+0xD0], xmm14
00007a44d59d47f8  vmovaps [rsp+0xE0], xmm15
00007a44d59d4801  sub rsp, 0x40
00007a44d59d4805  lea rdi, [rsp]
00007a44d59d4809  lea rsi, [rsp+0x10]
00007a44d59d480e  lea rdx, [rsp+0x20]
00007a44d59d4813  lea rcx, [rsp+0x30]
00007a44d59d4818  mov r8d, 0x00
00007a44d59d481e  lea r9, [r15+0x3A8]
00007a44d59d4825  movaps [rdi], xmm11
00007a44d59d4829  movaps [rsi], xmm10
00007a44d59d482d  movaps [rdx], xmm8
00007a44d59d4831  movaps [rcx], xmm13
00007a44d59d4835  mov rax, 0x56179A4B1A50
00007a44d59d483f  call rax
00007a44d59d4841  movaps xmm11, [rsp]
00007a44d59d4846  add rsp, 0x40
00007a44d59d484a  vmovaps xmm0, [rsp]
00007a44d59d484f  vmovaps xmm1, [rsp+0x10]
00007a44d59d4855  vmovaps xmm2, [rsp+0x20]
00007a44d59d485b  vmovaps xmm3, [rsp+0x30]
00007a44d59d4861  vmovaps xmm4, [rsp+0x40]
00007a44d59d4867  vmovaps xmm5, [rsp+0x50]
00007a44d59d486d  vmovaps xmm6, [rsp+0x60]
00007a44d59d4873  vmovaps xmm7, [rsp+0x70]
00007a44d59d4879  vmovaps xmm8, [rsp+0x80]
00007a44d59d4882  vmovaps xmm9, [rsp+0x90]
00007a44d59d488b  vmovaps xmm10, [rsp+0xA0]
00007a44d59d4894  vmovaps xmm12, [rsp+0xB0]
00007a44d59d489d  vmovaps xmm13, [rsp+0xC0]
00007a44d59d48a6  vmovaps xmm14, [rsp+0xD0]
00007a44d59d48af  vmovaps xmm15, [rsp+0xE0]
00007a44d59d48b8  add rsp, 0xF0
00007a44d59d48bf  pop r11
00007a44d59d48c1  pop r10
00007a44d59d48c3  pop r9
00007a44d59d48c5  pop r8
00007a44d59d48c7  pop rsi
00007a44d59d48c8  pop rdi
00007a44d59d48c9  pop rdx
00007a44d59d48ca  pop rcx
00007a44d59d48cb  pop rax
00007a44d59d48cc  add rsp, 0x08
00007a44d59d48d0  jmp 0x00007A44D59D2E44
00007a44d59d48d5  sub rsp, 0x08
00007a44d59d48d9  push rax
00007a44d59d48da  push rcx
00007a44d59d48db  push rdx
00007a44d59d48dc  push rdi
00007a44d59d48dd  push rsi
00007a44d59d48de  push r8
00007a44d59d48e0  push r9
00007a44d59d48e2  push r10
00007a44d59d48e4  push r11
00007a44d59d48e6  sub rsp, 0xF0
00007a44d59d48ed  vmovaps [rsp], xmm0
00007a44d59d48f2  vmovaps [rsp+0x10], xmm1
00007a44d59d48f8  vmovaps [rsp+0x20], xmm2
00007a44d59d48fe  vmovaps [rsp+0x30], xmm3
00007a44d59d4904  vmovaps [rsp+0x40], xmm4
00007a44d59d490a  vmovaps [rsp+0x50], xmm5
00007a44d59d4910  vmovaps [rsp+0x60], xmm6
00007a44d59d4916  vmovaps [rsp+0x70], xmm7
00007a44d59d491c  vmovaps [rsp+0x80], xmm8
00007a44d59d4925  vmovaps [rsp+0x90], xmm9
00007a44d59d492e  vmovaps [rsp+0xA0], xmm11
00007a44d59d4937  vmovaps [rsp+0xB0], xmm12
00007a44d59d4940  vmovaps [rsp+0xC0], xmm13
00007a44d59d4949  vmovaps [rsp+0xD0], xmm14
00007a44d59d4952  vmovaps [rsp+0xE0], xmm15
00007a44d59d495b  sub rsp, 0x40
00007a44d59d495f  lea rdi, [rsp]
00007a44d59d4963  lea rsi, [rsp+0x10]
00007a44d59d4968  lea rdx, [rsp+0x20]
00007a44d59d496d  lea rcx, [rsp+0x30]
00007a44d59d4972  mov r8d, 0x00
00007a44d59d4978  lea r9, [r15+0x3A8]
00007a44d59d497f  movaps [rdi], xmm10
00007a44d59d4983  movaps [rsi], xmm15
00007a44d59d4987  movaps [rdx], xmm1
00007a44d59d498a  movaps [rcx], xmm13
00007a44d59d498e  mov rax, 0x56179A4B1A50
00007a44d59d4998  call rax
00007a44d59d499a  movaps xmm10, [rsp]
00007a44d59d499f  add rsp, 0x40
00007a44d59d49a3  vmovaps xmm0, [rsp]
00007a44d59d49a8  vmovaps xmm1, [rsp+0x10]
00007a44d59d49ae  vmovaps xmm2, [rsp+0x20]
00007a44d59d49b4  vmovaps xmm3, [rsp+0x30]
00007a44d59d49ba  vmovaps xmm4, [rsp+0x40]
00007a44d59d49c0  vmovaps xmm5, [rsp+0x50]
00007a44d59d49c6  vmovaps xmm6, [rsp+0x60]
00007a44d59d49cc  vmovaps xmm7, [rsp+0x70]
00007a44d59d49d2  vmovaps xmm8, [rsp+0x80]
00007a44d59d49db  vmovaps xmm9, [rsp+0x90]
00007a44d59d49e4  vmovaps xmm11, [rsp+0xA0]
00007a44d59d49ed  vmovaps xmm12, [rsp+0xB0]
00007a44d59d49f6  vmovaps xmm13, [rsp+0xC0]
00007a44d59d49ff  vmovaps xmm14, [rsp+0xD0]
00007a44d59d4a08  vmovaps xmm15, [rsp+0xE0]
00007a44d59d4a11  add rsp, 0xF0
00007a44d59d4a18  pop r11
00007a44d59d4a1a  pop r10
00007a44d59d4a1c  pop r9
00007a44d59d4a1e  pop r8
00007a44d59d4a20  pop rsi
00007a44d59d4a21  pop rdi
00007a44d59d4a22  pop rdx
00007a44d59d4a23  pop rcx
00007a44d59d4a24  pop rax
00007a44d59d4a25  add rsp, 0x08
00007a44d59d4a29  jmp 0x00007A44D59D2E6D
00007a44d59d4a2e  call 0x00007A44D57FF430
00007a44d59d4a33  jmp 0x00007A44D59D2E8F
00007a44d59d4a38  call 0x00007A44D580E760
00007a44d59d4a3d  jmp 0x00007A44D59D2E99
00007a44d59d4a42  sub rsp, 0x08
00007a44d59d4a46  push rax
00007a44d59d4a47  push rcx
00007a44d59d4a48  push rdx
00007a44d59d4a49  push rdi
00007a44d59d4a4a  push rsi
00007a44d59d4a4b  push r8
00007a44d59d4a4d  push r9
00007a44d59d4a4f  push r10
00007a44d59d4a51  push r11
00007a44d59d4a53  sub rsp, 0xF0
00007a44d59d4a5a  vmovaps [rsp], xmm0
00007a44d59d4a5f  vmovaps [rsp+0x10], xmm1
00007a44d59d4a65  vmovaps [rsp+0x20], xmm2
00007a44d59d4a6b  vmovaps [rsp+0x30], xmm3
00007a44d59d4a71  vmovaps [rsp+0x40], xmm4
00007a44d59d4a77  vmovaps [rsp+0x50], xmm5
00007a44d59d4a7d  vmovaps [rsp+0x60], xmm6
00007a44d59d4a83  vmovaps [rsp+0x70], xmm7
00007a44d59d4a89  vmovaps [rsp+0x80], xmm9
00007a44d59d4a92  vmovaps [rsp+0x90], xmm10
00007a44d59d4a9b  vmovaps [rsp+0xA0], xmm11
00007a44d59d4aa4  vmovaps [rsp+0xB0], xmm12
00007a44d59d4aad  vmovaps [rsp+0xC0], xmm13
00007a44d59d4ab6  vmovaps [rsp+0xD0], xmm14
00007a44d59d4abf  vmovaps [rsp+0xE0], xmm15
00007a44d59d4ac8  sub rsp, 0x40
00007a44d59d4acc  lea rdi, [rsp]
00007a44d59d4ad0  lea rsi, [rsp+0x10]
00007a44d59d4ad5  lea rdx, [rsp+0x20]
00007a44d59d4ada  lea rcx, [rsp+0x30]
00007a44d59d4adf  mov r8d, 0x00
00007a44d59d4ae5  lea r9, [r15+0x3A8]
00007a44d59d4aec  movaps [rdi], xmm8
00007a44d59d4af0  movaps [rsi], xmm5
00007a44d59d4af3  movaps [rdx], xmm9
00007a44d59d4af7  movaps [rcx], xmm13
00007a44d59d4afb  mov rax, 0x56179A4B1A50
00007a44d59d4b05  call rax
00007a44d59d4b07  movaps xmm8, [rsp]
00007a44d59d4b0c  add rsp, 0x40
00007a44d59d4b10  vmovaps xmm0, [rsp]
00007a44d59d4b15  vmovaps xmm1, [rsp+0x10]
00007a44d59d4b1b  vmovaps xmm2, [rsp+0x20]
00007a44d59d4b21  vmovaps xmm3, [rsp+0x30]
00007a44d59d4b27  vmovaps xmm4, [rsp+0x40]
00007a44d59d4b2d  vmovaps xmm5, [rsp+0x50]
00007a44d59d4b33  vmovaps xmm6, [rsp+0x60]
00007a44d59d4b39  vmovaps xmm7, [rsp+0x70]
00007a44d59d4b3f  vmovaps xmm9, [rsp+0x80]
00007a44d59d4b48  vmovaps xmm10, [rsp+0x90]
00007a44d59d4b51  vmovaps xmm11, [rsp+0xA0]
00007a44d59d4b5a  vmovaps xmm12, [rsp+0xB0]
00007a44d59d4b63  vmovaps xmm13, [rsp+0xC0]
00007a44d59d4b6c  vmovaps xmm14, [rsp+0xD0]
00007a44d59d4b75  vmovaps xmm15, [rsp+0xE0]
00007a44d59d4b7e  add rsp, 0xF0
00007a44d59d4b85  pop r11
00007a44d59d4b87  pop r10
00007a44d59d4b89  pop r9
00007a44d59d4b8b  pop r8
00007a44d59d4b8d  pop rsi
00007a44d59d4b8e  pop rdi
00007a44d59d4b8f  pop rdx
00007a44d59d4b90  pop rcx
00007a44d59d4b91  pop rax
00007a44d59d4b92  add rsp, 0x08
00007a44d59d4b96  jmp 0x00007A44D59D2ED8
00007a44d59d4b9b  sub rsp, 0x08
00007a44d59d4b9f  push rax
00007a44d59d4ba0  push rcx
00007a44d59d4ba1  push rdx
00007a44d59d4ba2  push rdi
00007a44d59d4ba3  push rsi
00007a44d59d4ba4  push r8
00007a44d59d4ba6  push r9
00007a44d59d4ba8  push r10
00007a44d59d4baa  push r11
00007a44d59d4bac  sub rsp, 0xF0
00007a44d59d4bb3  vmovaps [rsp], xmm0
00007a44d59d4bb8  vmovaps [rsp+0x10], xmm1
00007a44d59d4bbe  vmovaps [rsp+0x20], xmm2
00007a44d59d4bc4  vmovaps [rsp+0x30], xmm3
00007a44d59d4bca  vmovaps [rsp+0x40], xmm4
00007a44d59d4bd0  vmovaps [rsp+0x50], xmm5
00007a44d59d4bd6  vmovaps [rsp+0x60], xmm6
00007a44d59d4bdc  vmovaps [rsp+0x70], xmm7
00007a44d59d4be2  vmovaps [rsp+0x80], xmm8
00007a44d59d4beb  vmovaps [rsp+0x90], xmm10
00007a44d59d4bf4  vmovaps [rsp+0xA0], xmm11
00007a44d59d4bfd  vmovaps [rsp+0xB0], xmm12
00007a44d59d4c06  vmovaps [rsp+0xC0], xmm13
00007a44d59d4c0f  vmovaps [rsp+0xD0], xmm14
00007a44d59d4c18  vmovaps [rsp+0xE0], xmm15
00007a44d59d4c21  sub rsp, 0x40
00007a44d59d4c25  lea rdi, [rsp]
00007a44d59d4c29  lea rsi, [rsp+0x10]
00007a44d59d4c2e  lea rdx, [rsp+0x20]
00007a44d59d4c33  lea rcx, [rsp+0x30]
00007a44d59d4c38  mov r8d, 0x00
00007a44d59d4c3e  lea r9, [r15+0x3A8]
00007a44d59d4c45  movaps [rdi], xmm9
00007a44d59d4c49  movaps [rsi], xmm12
00007a44d59d4c4d  movaps [rdx], xmm7
00007a44d59d4c50  movaps [rcx], xmm13
00007a44d59d4c54  mov rax, 0x56179A4B1A50
00007a44d59d4c5e  call rax
00007a44d59d4c60  movaps xmm9, [rsp]
00007a44d59d4c65  add rsp, 0x40
00007a44d59d4c69  vmovaps xmm0, [rsp]
00007a44d59d4c6e  vmovaps xmm1, [rsp+0x10]
00007a44d59d4c74  vmovaps xmm2, [rsp+0x20]
00007a44d59d4c7a  vmovaps xmm3, [rsp+0x30]
00007a44d59d4c80  vmovaps xmm4, [rsp+0x40]
00007a44d59d4c86  vmovaps xmm5, [rsp+0x50]
00007a44d59d4c8c  vmovaps xmm6, [rsp+0x60]
00007a44d59d4c92  vmovaps xmm7, [rsp+0x70]
00007a44d59d4c98  vmovaps xmm8, [rsp+0x80]
00007a44d59d4ca1  vmovaps xmm10, [rsp+0x90]
00007a44d59d4caa  vmovaps xmm11, [rsp+0xA0]
00007a44d59d4cb3  vmovaps xmm12, [rsp+0xB0]
00007a44d59d4cbc  vmovaps xmm13, [rsp+0xC0]
00007a44d59d4cc5  vmovaps xmm14, [rsp+0xD0]
00007a44d59d4cce  vmovaps xmm15, [rsp+0xE0]
00007a44d59d4cd7  add rsp, 0xF0
00007a44d59d4cde  pop r11
00007a44d59d4ce0  pop r10
00007a44d59d4ce2  pop r9
00007a44d59d4ce4  pop r8
00007a44d59d4ce6  pop rsi
00007a44d59d4ce7  pop rdi
00007a44d59d4ce8  pop rdx
00007a44d59d4ce9  pop rcx
00007a44d59d4cea  pop rax
00007a44d59d4ceb  add rsp, 0x08
00007a44d59d4cef  jmp 0x00007A44D59D2F01
00007a44d59d4cf4  sub rsp, 0x08
00007a44d59d4cf8  push rax
00007a44d59d4cf9  push rcx
00007a44d59d4cfa  push rdx
00007a44d59d4cfb  push rdi
00007a44d59d4cfc  push rsi
00007a44d59d4cfd  push r8
00007a44d59d4cff  push r9
00007a44d59d4d01  push r10
00007a44d59d4d03  push r11
00007a44d59d4d05  sub rsp, 0xF0
00007a44d59d4d0c  vmovaps [rsp], xmm0
00007a44d59d4d11  vmovaps [rsp+0x10], xmm1
00007a44d59d4d17  vmovaps [rsp+0x20], xmm2
00007a44d59d4d1d  vmovaps [rsp+0x30], xmm3
00007a44d59d4d23  vmovaps [rsp+0x40], xmm4
00007a44d59d4d29  vmovaps [rsp+0x50], xmm5
00007a44d59d4d2f  vmovaps [rsp+0x60], xmm6
00007a44d59d4d35  vmovaps [rsp+0x70], xmm7
00007a44d59d4d3b  vmovaps [rsp+0x80], xmm8
00007a44d59d4d44  vmovaps [rsp+0x90], xmm9
00007a44d59d4d4d  vmovaps [rsp+0xA0], xmm10
00007a44d59d4d56  vmovaps [rsp+0xB0], xmm11
00007a44d59d4d5f  vmovaps [rsp+0xC0], xmm13
00007a44d59d4d68  vmovaps [rsp+0xD0], xmm14
00007a44d59d4d71  vmovaps [rsp+0xE0], xmm15
00007a44d59d4d7a  sub rsp, 0x40
00007a44d59d4d7e  lea rdi, [rsp]
00007a44d59d4d82  lea rsi, [rsp+0x10]
00007a44d59d4d87  lea rdx, [rsp+0x20]
00007a44d59d4d8c  lea rcx, [rsp+0x30]
00007a44d59d4d91  mov r8d, 0x00
00007a44d59d4d97  lea r9, [r15+0x3A8]
00007a44d59d4d9e  movaps [rdi], xmm12
00007a44d59d4da2  movaps [rsi], xmm11
00007a44d59d4da6  movaps [rdx], xmm6
00007a44d59d4da9  movaps [rcx], xmm13
00007a44d59d4dad  mov rax, 0x56179A4B1A50
00007a44d59d4db7  call rax
00007a44d59d4db9  movaps xmm12, [rsp]
00007a44d59d4dbe  add rsp, 0x40
00007a44d59d4dc2  vmovaps xmm0, [rsp]
00007a44d59d4dc7  vmovaps xmm1, [rsp+0x10]
00007a44d59d4dcd  vmovaps xmm2, [rsp+0x20]
00007a44d59d4dd3  vmovaps xmm3, [rsp+0x30]
00007a44d59d4dd9  vmovaps xmm4, [rsp+0x40]
00007a44d59d4ddf  vmovaps xmm5, [rsp+0x50]
00007a44d59d4de5  vmovaps xmm6, [rsp+0x60]
00007a44d59d4deb  vmovaps xmm7, [rsp+0x70]
00007a44d59d4df1  vmovaps xmm8, [rsp+0x80]
00007a44d59d4dfa  vmovaps xmm9, [rsp+0x90]
00007a44d59d4e03  vmovaps xmm10, [rsp+0xA0]
00007a44d59d4e0c  vmovaps xmm11, [rsp+0xB0]
00007a44d59d4e15  vmovaps xmm13, [rsp+0xC0]
00007a44d59d4e1e  vmovaps xmm14, [rsp+0xD0]
00007a44d59d4e27  vmovaps xmm15, [rsp+0xE0]
00007a44d59d4e30  add rsp, 0xF0
00007a44d59d4e37  pop r11
00007a44d59d4e39  pop r10
00007a44d59d4e3b  pop r9
00007a44d59d4e3d  pop r8
00007a44d59d4e3f  pop rsi
00007a44d59d4e40  pop rdi
00007a44d59d4e41  pop rdx
00007a44d59d4e42  pop rcx
00007a44d59d4e43  pop rax
00007a44d59d4e44  add rsp, 0x08
00007a44d59d4e48  jmp 0x00007A44D59D2F2A
00007a44d59d4e4d  sub rsp, 0x08
00007a44d59d4e51  push rax
00007a44d59d4e52  push rcx
00007a44d59d4e53  push rdx
00007a44d59d4e54  push rdi
00007a44d59d4e55  push rsi
00007a44d59d4e56  push r8
00007a44d59d4e58  push r9
00007a44d59d4e5a  push r10
00007a44d59d4e5c  push r11
00007a44d59d4e5e  sub rsp, 0xF0
00007a44d59d4e65  vmovaps [rsp], xmm0
00007a44d59d4e6a  vmovaps [rsp+0x10], xmm1
00007a44d59d4e70  vmovaps [rsp+0x20], xmm2
00007a44d59d4e76  vmovaps [rsp+0x30], xmm3
00007a44d59d4e7c  vmovaps [rsp+0x40], xmm4
00007a44d59d4e82  vmovaps [rsp+0x50], xmm5
00007a44d59d4e88  vmovaps [rsp+0x60], xmm6
00007a44d59d4e8e  vmovaps [rsp+0x70], xmm8
00007a44d59d4e94  vmovaps [rsp+0x80], xmm9
00007a44d59d4e9d  vmovaps [rsp+0x90], xmm10
00007a44d59d4ea6  vmovaps [rsp+0xA0], xmm11
00007a44d59d4eaf  vmovaps [rsp+0xB0], xmm12
00007a44d59d4eb8  vmovaps [rsp+0xC0], xmm13
00007a44d59d4ec1  vmovaps [rsp+0xD0], xmm14
00007a44d59d4eca  vmovaps [rsp+0xE0], xmm15
00007a44d59d4ed3  sub rsp, 0x40
00007a44d59d4ed7  lea rdi, [rsp]
00007a44d59d4edb  lea rsi, [rsp+0x10]
00007a44d59d4ee0  lea rdx, [rsp+0x20]
00007a44d59d4ee5  lea rcx, [rsp+0x30]
00007a44d59d4eea  mov r8d, 0x00
00007a44d59d4ef0  lea r9, [r15+0x3A8]
00007a44d59d4ef7  movaps [rdi], xmm7
00007a44d59d4efa  movaps [rsi], xmm10
00007a44d59d4efe  movaps [rdx], xmm11
00007a44d59d4f02  movaps [rcx], xmm13
00007a44d59d4f06  mov rax, 0x56179A4B1A50
00007a44d59d4f10  call rax
00007a44d59d4f12  movaps xmm7, [rsp]
00007a44d59d4f16  add rsp, 0x40
00007a44d59d4f1a  vmovaps xmm0, [rsp]
00007a44d59d4f1f  vmovaps xmm1, [rsp+0x10]
00007a44d59d4f25  vmovaps xmm2, [rsp+0x20]
00007a44d59d4f2b  vmovaps xmm3, [rsp+0x30]
00007a44d59d4f31  vmovaps xmm4, [rsp+0x40]
00007a44d59d4f37  vmovaps xmm5, [rsp+0x50]
00007a44d59d4f3d  vmovaps xmm6, [rsp+0x60]
00007a44d59d4f43  vmovaps xmm8, [rsp+0x70]
00007a44d59d4f49  vmovaps xmm9, [rsp+0x80]
00007a44d59d4f52  vmovaps xmm10, [rsp+0x90]
00007a44d59d4f5b  vmovaps xmm11, [rsp+0xA0]
00007a44d59d4f64  vmovaps xmm12, [rsp+0xB0]
00007a44d59d4f6d  vmovaps xmm13, [rsp+0xC0]
00007a44d59d4f76  vmovaps xmm14, [rsp+0xD0]
00007a44d59d4f7f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d4f88  add rsp, 0xF0
00007a44d59d4f8f  pop r11
00007a44d59d4f91  pop r10
00007a44d59d4f93  pop r9
00007a44d59d4f95  pop r8
00007a44d59d4f97  pop rsi
00007a44d59d4f98  pop rdi
00007a44d59d4f99  pop rdx
00007a44d59d4f9a  pop rcx
00007a44d59d4f9b  pop rax
00007a44d59d4f9c  add rsp, 0x08
00007a44d59d4fa0  jmp 0x00007A44D59D2F58
00007a44d59d4fa5  call 0x00007A44D580C260
00007a44d59d4faa  jmp 0x00007A44D59D2F62
00007a44d59d4faf  call 0x00007A44D5809D70
00007a44d59d4fb4  jmp 0x00007A44D59D2F6C
00007a44d59d4fb9  sub rsp, 0x08
00007a44d59d4fbd  push rax
00007a44d59d4fbe  push rcx
00007a44d59d4fbf  push rdx
00007a44d59d4fc0  push rdi
00007a44d59d4fc1  push rsi
00007a44d59d4fc2  push r8
00007a44d59d4fc4  push r9
00007a44d59d4fc6  push r10
00007a44d59d4fc8  push r11
00007a44d59d4fca  sub rsp, 0xF0
00007a44d59d4fd1  vmovaps [rsp], xmm0
00007a44d59d4fd6  vmovaps [rsp+0x10], xmm1
00007a44d59d4fdc  vmovaps [rsp+0x20], xmm2
00007a44d59d4fe2  vmovaps [rsp+0x30], xmm3
00007a44d59d4fe8  vmovaps [rsp+0x40], xmm4
00007a44d59d4fee  vmovaps [rsp+0x50], xmm5
00007a44d59d4ff4  vmovaps [rsp+0x60], xmm7
00007a44d59d4ffa  vmovaps [rsp+0x70], xmm8
00007a44d59d5000  vmovaps [rsp+0x80], xmm9
00007a44d59d5009  vmovaps [rsp+0x90], xmm10
00007a44d59d5012  vmovaps [rsp+0xA0], xmm11
00007a44d59d501b  vmovaps [rsp+0xB0], xmm12
00007a44d59d5024  vmovaps [rsp+0xC0], xmm13
00007a44d59d502d  vmovaps [rsp+0xD0], xmm14
00007a44d59d5036  vmovaps [rsp+0xE0], xmm15
00007a44d59d503f  sub rsp, 0x40
00007a44d59d5043  lea rdi, [rsp]
00007a44d59d5047  lea rsi, [rsp+0x10]
00007a44d59d504c  lea rdx, [rsp+0x20]
00007a44d59d5051  lea rcx, [rsp+0x30]
00007a44d59d5056  mov r8d, 0x00
00007a44d59d505c  lea r9, [r15+0x3A8]
00007a44d59d5063  movaps [rdi], xmm6
00007a44d59d5066  movaps [rsi], xmm8
00007a44d59d506a  movaps [rdx], xmm15
00007a44d59d506e  movaps [rcx], xmm10
00007a44d59d5072  mov rax, 0x56179A4B1A50
00007a44d59d507c  call rax
00007a44d59d507e  movaps xmm6, [rsp]
00007a44d59d5082  add rsp, 0x40
00007a44d59d5086  vmovaps xmm0, [rsp]
00007a44d59d508b  vmovaps xmm1, [rsp+0x10]
00007a44d59d5091  vmovaps xmm2, [rsp+0x20]
00007a44d59d5097  vmovaps xmm3, [rsp+0x30]
00007a44d59d509d  vmovaps xmm4, [rsp+0x40]
00007a44d59d50a3  vmovaps xmm5, [rsp+0x50]
00007a44d59d50a9  vmovaps xmm7, [rsp+0x60]
00007a44d59d50af  vmovaps xmm8, [rsp+0x70]
00007a44d59d50b5  vmovaps xmm9, [rsp+0x80]
00007a44d59d50be  vmovaps xmm10, [rsp+0x90]
00007a44d59d50c7  vmovaps xmm11, [rsp+0xA0]
00007a44d59d50d0  vmovaps xmm12, [rsp+0xB0]
00007a44d59d50d9  vmovaps xmm13, [rsp+0xC0]
00007a44d59d50e2  vmovaps xmm14, [rsp+0xD0]
00007a44d59d50eb  vmovaps xmm15, [rsp+0xE0]
00007a44d59d50f4  add rsp, 0xF0
00007a44d59d50fb  pop r11
00007a44d59d50fd  pop r10
00007a44d59d50ff  pop r9
00007a44d59d5101  pop r8
00007a44d59d5103  pop rsi
00007a44d59d5104  pop rdi
00007a44d59d5105  pop rdx
00007a44d59d5106  pop rcx
00007a44d59d5107  pop rax
00007a44d59d5108  add rsp, 0x08
00007a44d59d510c  jmp 0x00007A44D59D2FA4
00007a44d59d5111  sub rsp, 0x08
00007a44d59d5115  push rax
00007a44d59d5116  push rcx
00007a44d59d5117  push rdx
00007a44d59d5118  push rdi
00007a44d59d5119  push rsi
00007a44d59d511a  push r8
00007a44d59d511c  push r9
00007a44d59d511e  push r10
00007a44d59d5120  push r11
00007a44d59d5122  sub rsp, 0xF0
00007a44d59d5129  vmovaps [rsp], xmm0
00007a44d59d512e  vmovaps [rsp+0x10], xmm1
00007a44d59d5134  vmovaps [rsp+0x20], xmm2
00007a44d59d513a  vmovaps [rsp+0x30], xmm3
00007a44d59d5140  vmovaps [rsp+0x40], xmm4
00007a44d59d5146  vmovaps [rsp+0x50], xmm5
00007a44d59d514c  vmovaps [rsp+0x60], xmm6
00007a44d59d5152  vmovaps [rsp+0x70], xmm7
00007a44d59d5158  vmovaps [rsp+0x80], xmm8
00007a44d59d5161  vmovaps [rsp+0x90], xmm9
00007a44d59d516a  vmovaps [rsp+0xA0], xmm11
00007a44d59d5173  vmovaps [rsp+0xB0], xmm12
00007a44d59d517c  vmovaps [rsp+0xC0], xmm13
00007a44d59d5185  vmovaps [rsp+0xD0], xmm14
00007a44d59d518e  vmovaps [rsp+0xE0], xmm15
00007a44d59d5197  sub rsp, 0x40
00007a44d59d519b  lea rdi, [rsp]
00007a44d59d519f  lea rsi, [rsp+0x10]
00007a44d59d51a4  lea rdx, [rsp+0x20]
00007a44d59d51a9  lea rcx, [rsp+0x30]
00007a44d59d51ae  mov r8d, 0x00
00007a44d59d51b4  lea r9, [r15+0x3A8]
00007a44d59d51bb  movaps [rdi], xmm10
00007a44d59d51bf  movaps [rsi], xmm9
00007a44d59d51c3  movaps [rdx], xmm13
00007a44d59d51c7  movaps [rcx], xmm15
00007a44d59d51cb  mov rax, 0x56179A4B1A50
00007a44d59d51d5  call rax
00007a44d59d51d7  movaps xmm10, [rsp]
00007a44d59d51dc  add rsp, 0x40
00007a44d59d51e0  vmovaps xmm0, [rsp]
00007a44d59d51e5  vmovaps xmm1, [rsp+0x10]
00007a44d59d51eb  vmovaps xmm2, [rsp+0x20]
00007a44d59d51f1  vmovaps xmm3, [rsp+0x30]
00007a44d59d51f7  vmovaps xmm4, [rsp+0x40]
00007a44d59d51fd  vmovaps xmm5, [rsp+0x50]
00007a44d59d5203  vmovaps xmm6, [rsp+0x60]
00007a44d59d5209  vmovaps xmm7, [rsp+0x70]
00007a44d59d520f  vmovaps xmm8, [rsp+0x80]
00007a44d59d5218  vmovaps xmm9, [rsp+0x90]
00007a44d59d5221  vmovaps xmm11, [rsp+0xA0]
00007a44d59d522a  vmovaps xmm12, [rsp+0xB0]
00007a44d59d5233  vmovaps xmm13, [rsp+0xC0]
00007a44d59d523c  vmovaps xmm14, [rsp+0xD0]
00007a44d59d5245  vmovaps xmm15, [rsp+0xE0]
00007a44d59d524e  add rsp, 0xF0
00007a44d59d5255  pop r11
00007a44d59d5257  pop r10
00007a44d59d5259  pop r9
00007a44d59d525b  pop r8
00007a44d59d525d  pop rsi
00007a44d59d525e  pop rdi
00007a44d59d525f  pop rdx
00007a44d59d5260  pop rcx
00007a44d59d5261  pop rax
00007a44d59d5262  add rsp, 0x08
00007a44d59d5266  jmp 0x00007A44D59D2FCD
00007a44d59d526b  sub rsp, 0x08
00007a44d59d526f  push rax
00007a44d59d5270  push rcx
00007a44d59d5271  push rdx
00007a44d59d5272  push rdi
00007a44d59d5273  push rsi
00007a44d59d5274  push r8
00007a44d59d5276  push r9
00007a44d59d5278  push r10
00007a44d59d527a  push r11
00007a44d59d527c  sub rsp, 0xF0
00007a44d59d5283  vmovaps [rsp], xmm0
00007a44d59d5288  vmovaps [rsp+0x10], xmm1
00007a44d59d528e  vmovaps [rsp+0x20], xmm2
00007a44d59d5294  vmovaps [rsp+0x30], xmm3
00007a44d59d529a  vmovaps [rsp+0x40], xmm4
00007a44d59d52a0  vmovaps [rsp+0x50], xmm5
00007a44d59d52a6  vmovaps [rsp+0x60], xmm6
00007a44d59d52ac  vmovaps [rsp+0x70], xmm7
00007a44d59d52b2  vmovaps [rsp+0x80], xmm8
00007a44d59d52bb  vmovaps [rsp+0x90], xmm9
00007a44d59d52c4  vmovaps [rsp+0xA0], xmm10
00007a44d59d52cd  vmovaps [rsp+0xB0], xmm11
00007a44d59d52d6  vmovaps [rsp+0xC0], xmm12
00007a44d59d52df  vmovaps [rsp+0xD0], xmm14
00007a44d59d52e8  vmovaps [rsp+0xE0], xmm15
00007a44d59d52f1  sub rsp, 0x40
00007a44d59d52f5  lea rdi, [rsp]
00007a44d59d52f9  lea rsi, [rsp+0x10]
00007a44d59d52fe  lea rdx, [rsp+0x20]
00007a44d59d5303  lea rcx, [rsp+0x30]
00007a44d59d5308  mov r8d, 0x00
00007a44d59d530e  lea r9, [r15+0x3A8]
00007a44d59d5315  movaps [rdi], xmm13
00007a44d59d5319  movaps [rsi], xmm12
00007a44d59d531d  movaps [rdx], xmm4
00007a44d59d5320  movaps [rcx], xmm15
00007a44d59d5324  mov rax, 0x56179A4B1A50
00007a44d59d532e  call rax
00007a44d59d5330  movaps xmm13, [rsp]
00007a44d59d5335  add rsp, 0x40
00007a44d59d5339  vmovaps xmm0, [rsp]
00007a44d59d533e  vmovaps xmm1, [rsp+0x10]
00007a44d59d5344  vmovaps xmm2, [rsp+0x20]
00007a44d59d534a  vmovaps xmm3, [rsp+0x30]
00007a44d59d5350  vmovaps xmm4, [rsp+0x40]
00007a44d59d5356  vmovaps xmm5, [rsp+0x50]
00007a44d59d535c  vmovaps xmm6, [rsp+0x60]
00007a44d59d5362  vmovaps xmm7, [rsp+0x70]
00007a44d59d5368  vmovaps xmm8, [rsp+0x80]
00007a44d59d5371  vmovaps xmm9, [rsp+0x90]
00007a44d59d537a  vmovaps xmm10, [rsp+0xA0]
00007a44d59d5383  vmovaps xmm11, [rsp+0xB0]
00007a44d59d538c  vmovaps xmm12, [rsp+0xC0]
00007a44d59d5395  vmovaps xmm14, [rsp+0xD0]
00007a44d59d539e  vmovaps xmm15, [rsp+0xE0]
00007a44d59d53a7  add rsp, 0xF0
00007a44d59d53ae  pop r11
00007a44d59d53b0  pop r10
00007a44d59d53b2  pop r9
00007a44d59d53b4  pop r8
00007a44d59d53b6  pop rsi
00007a44d59d53b7  pop rdi
00007a44d59d53b8  pop rdx
00007a44d59d53b9  pop rcx
00007a44d59d53ba  pop rax
00007a44d59d53bb  add rsp, 0x08
00007a44d59d53bf  jmp 0x00007A44D59D2FF6
00007a44d59d53c4  sub rsp, 0x08
00007a44d59d53c8  push rax
00007a44d59d53c9  push rcx
00007a44d59d53ca  push rdx
00007a44d59d53cb  push rdi
00007a44d59d53cc  push rsi
00007a44d59d53cd  push r8
00007a44d59d53cf  push r9
00007a44d59d53d1  push r10
00007a44d59d53d3  push r11
00007a44d59d53d5  sub rsp, 0xF0
00007a44d59d53dc  vmovaps [rsp], xmm0
00007a44d59d53e1  vmovaps [rsp+0x10], xmm1
00007a44d59d53e7  vmovaps [rsp+0x20], xmm2
00007a44d59d53ed  vmovaps [rsp+0x30], xmm3
00007a44d59d53f3  vmovaps [rsp+0x40], xmm4
00007a44d59d53f9  vmovaps [rsp+0x50], xmm5
00007a44d59d53ff  vmovaps [rsp+0x60], xmm6
00007a44d59d5405  vmovaps [rsp+0x70], xmm7
00007a44d59d540b  vmovaps [rsp+0x80], xmm8
00007a44d59d5414  vmovaps [rsp+0x90], xmm9
00007a44d59d541d  vmovaps [rsp+0xA0], xmm10
00007a44d59d5426  vmovaps [rsp+0xB0], xmm11
00007a44d59d542f  vmovaps [rsp+0xC0], xmm13
00007a44d59d5438  vmovaps [rsp+0xD0], xmm14
00007a44d59d5441  vmovaps [rsp+0xE0], xmm15
00007a44d59d544a  sub rsp, 0x40
00007a44d59d544e  lea rdi, [rsp]
00007a44d59d5452  lea rsi, [rsp+0x10]
00007a44d59d5457  lea rdx, [rsp+0x20]
00007a44d59d545c  lea rcx, [rsp+0x30]
00007a44d59d5461  mov r8d, 0x00
00007a44d59d5467  lea r9, [r15+0x3A8]
00007a44d59d546e  movaps [rdi], xmm12
00007a44d59d5472  movaps [rsi], xmm7
00007a44d59d5475  movaps [rdx], xmm1
00007a44d59d5478  movaps [rcx], xmm15
00007a44d59d547c  mov rax, 0x56179A4B1A50
00007a44d59d5486  call rax
00007a44d59d5488  movaps xmm12, [rsp]
00007a44d59d548d  add rsp, 0x40
00007a44d59d5491  vmovaps xmm0, [rsp]
00007a44d59d5496  vmovaps xmm1, [rsp+0x10]
00007a44d59d549c  vmovaps xmm2, [rsp+0x20]
00007a44d59d54a2  vmovaps xmm3, [rsp+0x30]
00007a44d59d54a8  vmovaps xmm4, [rsp+0x40]
00007a44d59d54ae  vmovaps xmm5, [rsp+0x50]
00007a44d59d54b4  vmovaps xmm6, [rsp+0x60]
00007a44d59d54ba  vmovaps xmm7, [rsp+0x70]
00007a44d59d54c0  vmovaps xmm8, [rsp+0x80]
00007a44d59d54c9  vmovaps xmm9, [rsp+0x90]
00007a44d59d54d2  vmovaps xmm10, [rsp+0xA0]
00007a44d59d54db  vmovaps xmm11, [rsp+0xB0]
00007a44d59d54e4  vmovaps xmm13, [rsp+0xC0]
00007a44d59d54ed  vmovaps xmm14, [rsp+0xD0]
00007a44d59d54f6  vmovaps xmm15, [rsp+0xE0]
00007a44d59d54ff  add rsp, 0xF0
00007a44d59d5506  pop r11
00007a44d59d5508  pop r10
00007a44d59d550a  pop r9
00007a44d59d550c  pop r8
00007a44d59d550e  pop rsi
00007a44d59d550f  pop rdi
00007a44d59d5510  pop rdx
00007a44d59d5511  pop rcx
00007a44d59d5512  pop rax
00007a44d59d5513  add rsp, 0x08
00007a44d59d5517  jmp 0x00007A44D59D301F
00007a44d59d551c  call 0x00007A44D57FF430
00007a44d59d5521  jmp 0x00007A44D59D3029
00007a44d59d5526  call 0x00007A44D580E760
00007a44d59d552b  jmp 0x00007A44D59D3033
00007a44d59d5530  sub rsp, 0x08
00007a44d59d5534  push rax
00007a44d59d5535  push rcx
00007a44d59d5536  push rdx
00007a44d59d5537  push rdi
00007a44d59d5538  push rsi
00007a44d59d5539  push r8
00007a44d59d553b  push r9
00007a44d59d553d  push r10
00007a44d59d553f  push r11
00007a44d59d5541  sub rsp, 0xF0
00007a44d59d5548  vmovaps [rsp], xmm0
00007a44d59d554d  vmovaps [rsp+0x10], xmm1
00007a44d59d5553  vmovaps [rsp+0x20], xmm2
00007a44d59d5559  vmovaps [rsp+0x30], xmm3
00007a44d59d555f  vmovaps [rsp+0x40], xmm4
00007a44d59d5565  vmovaps [rsp+0x50], xmm5
00007a44d59d556b  vmovaps [rsp+0x60], xmm6
00007a44d59d5571  vmovaps [rsp+0x70], xmm8
00007a44d59d5577  vmovaps [rsp+0x80], xmm9
00007a44d59d5580  vmovaps [rsp+0x90], xmm10
00007a44d59d5589  vmovaps [rsp+0xA0], xmm11
00007a44d59d5592  vmovaps [rsp+0xB0], xmm12
00007a44d59d559b  vmovaps [rsp+0xC0], xmm13
00007a44d59d55a4  vmovaps [rsp+0xD0], xmm14
00007a44d59d55ad  vmovaps [rsp+0xE0], xmm15
00007a44d59d55b6  sub rsp, 0x40
00007a44d59d55ba  lea rdi, [rsp]
00007a44d59d55be  lea rsi, [rsp+0x10]
00007a44d59d55c3  lea rdx, [rsp+0x20]
00007a44d59d55c8  lea rcx, [rsp+0x30]
00007a44d59d55cd  mov r8d, 0x00
00007a44d59d55d3  lea r9, [r15+0x3A8]
00007a44d59d55da  movaps [rdi], xmm7
00007a44d59d55dd  movaps [rsi], xmm6
00007a44d59d55e0  movaps [rdx], xmm8
00007a44d59d55e4  movaps [rcx], xmm9
00007a44d59d55e8  mov rax, 0x56179A4B1A50
00007a44d59d55f2  call rax
00007a44d59d55f4  movaps xmm7, [rsp]
00007a44d59d55f8  add rsp, 0x40
00007a44d59d55fc  vmovaps xmm0, [rsp]
00007a44d59d5601  vmovaps xmm1, [rsp+0x10]
00007a44d59d5607  vmovaps xmm2, [rsp+0x20]
00007a44d59d560d  vmovaps xmm3, [rsp+0x30]
00007a44d59d5613  vmovaps xmm4, [rsp+0x40]
00007a44d59d5619  vmovaps xmm5, [rsp+0x50]
00007a44d59d561f  vmovaps xmm6, [rsp+0x60]
00007a44d59d5625  vmovaps xmm8, [rsp+0x70]
00007a44d59d562b  vmovaps xmm9, [rsp+0x80]
00007a44d59d5634  vmovaps xmm10, [rsp+0x90]
00007a44d59d563d  vmovaps xmm11, [rsp+0xA0]
00007a44d59d5646  vmovaps xmm12, [rsp+0xB0]
00007a44d59d564f  vmovaps xmm13, [rsp+0xC0]
00007a44d59d5658  vmovaps xmm14, [rsp+0xD0]
00007a44d59d5661  vmovaps xmm15, [rsp+0xE0]
00007a44d59d566a  add rsp, 0xF0
00007a44d59d5671  pop r11
00007a44d59d5673  pop r10
00007a44d59d5675  pop r9
00007a44d59d5677  pop r8
00007a44d59d5679  pop rsi
00007a44d59d567a  pop rdi
00007a44d59d567b  pop rdx
00007a44d59d567c  pop rcx
00007a44d59d567d  pop rax
00007a44d59d567e  add rsp, 0x08
00007a44d59d5682  jmp 0x00007A44D59D305D
00007a44d59d5687  sub rsp, 0x08
00007a44d59d568b  push rax
00007a44d59d568c  push rcx
00007a44d59d568d  push rdx
00007a44d59d568e  push rdi
00007a44d59d568f  push rsi
00007a44d59d5690  push r8
00007a44d59d5692  push r9
00007a44d59d5694  push r10
00007a44d59d5696  push r11
00007a44d59d5698  sub rsp, 0xF0
00007a44d59d569f  vmovaps [rsp], xmm0
00007a44d59d56a4  vmovaps [rsp+0x10], xmm1
00007a44d59d56aa  vmovaps [rsp+0x20], xmm2
00007a44d59d56b0  vmovaps [rsp+0x30], xmm3
00007a44d59d56b6  vmovaps [rsp+0x40], xmm4
00007a44d59d56bc  vmovaps [rsp+0x50], xmm5
00007a44d59d56c2  vmovaps [rsp+0x60], xmm6
00007a44d59d56c8  vmovaps [rsp+0x70], xmm7
00007a44d59d56ce  vmovaps [rsp+0x80], xmm9
00007a44d59d56d7  vmovaps [rsp+0x90], xmm10
00007a44d59d56e0  vmovaps [rsp+0xA0], xmm11
00007a44d59d56e9  vmovaps [rsp+0xB0], xmm12
00007a44d59d56f2  vmovaps [rsp+0xC0], xmm13
00007a44d59d56fb  vmovaps [rsp+0xD0], xmm14
00007a44d59d5704  vmovaps [rsp+0xE0], xmm15
00007a44d59d570d  sub rsp, 0x40
00007a44d59d5711  lea rdi, [rsp]
00007a44d59d5715  lea rsi, [rsp+0x10]
00007a44d59d571a  lea rdx, [rsp+0x20]
00007a44d59d571f  lea rcx, [rsp+0x30]
00007a44d59d5724  mov r8d, 0x00
00007a44d59d572a  lea r9, [r15+0x3A8]
00007a44d59d5731  movaps [rdi], xmm8
00007a44d59d5735  movaps [rsi], xmm10
00007a44d59d5739  movaps [rdx], xmm14
00007a44d59d573d  movaps [rcx], xmm9
00007a44d59d5741  mov rax, 0x56179A4B1A50
00007a44d59d574b  call rax
00007a44d59d574d  movaps xmm8, [rsp]
00007a44d59d5752  add rsp, 0x40
00007a44d59d5756  vmovaps xmm0, [rsp]
00007a44d59d575b  vmovaps xmm1, [rsp+0x10]
00007a44d59d5761  vmovaps xmm2, [rsp+0x20]
00007a44d59d5767  vmovaps xmm3, [rsp+0x30]
00007a44d59d576d  vmovaps xmm4, [rsp+0x40]
00007a44d59d5773  vmovaps xmm5, [rsp+0x50]
00007a44d59d5779  vmovaps xmm6, [rsp+0x60]
00007a44d59d577f  vmovaps xmm7, [rsp+0x70]
00007a44d59d5785  vmovaps xmm9, [rsp+0x80]
00007a44d59d578e  vmovaps xmm10, [rsp+0x90]
00007a44d59d5797  vmovaps xmm11, [rsp+0xA0]
00007a44d59d57a0  vmovaps xmm12, [rsp+0xB0]
00007a44d59d57a9  vmovaps xmm13, [rsp+0xC0]
00007a44d59d57b2  vmovaps xmm14, [rsp+0xD0]
00007a44d59d57bb  vmovaps xmm15, [rsp+0xE0]
00007a44d59d57c4  add rsp, 0xF0
00007a44d59d57cb  pop r11
00007a44d59d57cd  pop r10
00007a44d59d57cf  pop r9
00007a44d59d57d1  pop r8
00007a44d59d57d3  pop rsi
00007a44d59d57d4  pop rdi
00007a44d59d57d5  pop rdx
00007a44d59d57d6  pop rcx
00007a44d59d57d7  pop rax
00007a44d59d57d8  add rsp, 0x08
00007a44d59d57dc  jmp 0x00007A44D59D3083
00007a44d59d57e1  sub rsp, 0x08
00007a44d59d57e5  push rax
00007a44d59d57e6  push rcx
00007a44d59d57e7  push rdx
00007a44d59d57e8  push rdi
00007a44d59d57e9  push rsi
00007a44d59d57ea  push r8
00007a44d59d57ec  push r9
00007a44d59d57ee  push r10
00007a44d59d57f0  push r11
00007a44d59d57f2  sub rsp, 0xF0
00007a44d59d57f9  vmovaps [rsp], xmm0
00007a44d59d57fe  vmovaps [rsp+0x10], xmm1
00007a44d59d5804  vmovaps [rsp+0x20], xmm2
00007a44d59d580a  vmovaps [rsp+0x30], xmm3
00007a44d59d5810  vmovaps [rsp+0x40], xmm4
00007a44d59d5816  vmovaps [rsp+0x50], xmm5
00007a44d59d581c  vmovaps [rsp+0x60], xmm6
00007a44d59d5822  vmovaps [rsp+0x70], xmm7
00007a44d59d5828  vmovaps [rsp+0x80], xmm8
00007a44d59d5831  vmovaps [rsp+0x90], xmm9
00007a44d59d583a  vmovaps [rsp+0xA0], xmm11
00007a44d59d5843  vmovaps [rsp+0xB0], xmm12
00007a44d59d584c  vmovaps [rsp+0xC0], xmm13
00007a44d59d5855  vmovaps [rsp+0xD0], xmm14
00007a44d59d585e  vmovaps [rsp+0xE0], xmm15
00007a44d59d5867  sub rsp, 0x40
00007a44d59d586b  lea rdi, [rsp]
00007a44d59d586f  lea rsi, [rsp+0x10]
00007a44d59d5874  lea rdx, [rsp+0x20]
00007a44d59d5879  lea rcx, [rsp+0x30]
00007a44d59d587e  mov r8d, 0x00
00007a44d59d5884  lea r9, [r15+0x3A8]
00007a44d59d588b  movaps [rdi], xmm10
00007a44d59d588f  movaps [rsi], xmm13
00007a44d59d5893  movaps [rdx], xmm11
00007a44d59d5897  movaps [rcx], xmm14
00007a44d59d589b  mov rax, 0x56179A4B1A50
00007a44d59d58a5  call rax
00007a44d59d58a7  movaps xmm10, [rsp]
00007a44d59d58ac  add rsp, 0x40
00007a44d59d58b0  vmovaps xmm0, [rsp]
00007a44d59d58b5  vmovaps xmm1, [rsp+0x10]
00007a44d59d58bb  vmovaps xmm2, [rsp+0x20]
00007a44d59d58c1  vmovaps xmm3, [rsp+0x30]
00007a44d59d58c7  vmovaps xmm4, [rsp+0x40]
00007a44d59d58cd  vmovaps xmm5, [rsp+0x50]
00007a44d59d58d3  vmovaps xmm6, [rsp+0x60]
00007a44d59d58d9  vmovaps xmm7, [rsp+0x70]
00007a44d59d58df  vmovaps xmm8, [rsp+0x80]
00007a44d59d58e8  vmovaps xmm9, [rsp+0x90]
00007a44d59d58f1  vmovaps xmm11, [rsp+0xA0]
00007a44d59d58fa  vmovaps xmm12, [rsp+0xB0]
00007a44d59d5903  vmovaps xmm13, [rsp+0xC0]
00007a44d59d590c  vmovaps xmm14, [rsp+0xD0]
00007a44d59d5915  vmovaps xmm15, [rsp+0xE0]
00007a44d59d591e  add rsp, 0xF0
00007a44d59d5925  pop r11
00007a44d59d5927  pop r10
00007a44d59d5929  pop r9
00007a44d59d592b  pop r8
00007a44d59d592d  pop rsi
00007a44d59d592e  pop rdi
00007a44d59d592f  pop rdx
00007a44d59d5930  pop rcx
00007a44d59d5931  pop rax
00007a44d59d5932  add rsp, 0x08
00007a44d59d5936  jmp 0x00007A44D59D30A9
00007a44d59d593b  sub rsp, 0x08
00007a44d59d593f  push rax
00007a44d59d5940  push rcx
00007a44d59d5941  push rdx
00007a44d59d5942  push rdi
00007a44d59d5943  push rsi
00007a44d59d5944  push r8
00007a44d59d5946  push r9
00007a44d59d5948  push r10
00007a44d59d594a  push r11
00007a44d59d594c  sub rsp, 0xF0
00007a44d59d5953  vmovaps [rsp], xmm0
00007a44d59d5958  vmovaps [rsp+0x10], xmm1
00007a44d59d595e  vmovaps [rsp+0x20], xmm2
00007a44d59d5964  vmovaps [rsp+0x30], xmm3
00007a44d59d596a  vmovaps [rsp+0x40], xmm4
00007a44d59d5970  vmovaps [rsp+0x50], xmm5
00007a44d59d5976  vmovaps [rsp+0x60], xmm6
00007a44d59d597c  vmovaps [rsp+0x70], xmm7
00007a44d59d5982  vmovaps [rsp+0x80], xmm8
00007a44d59d598b  vmovaps [rsp+0x90], xmm9
00007a44d59d5994  vmovaps [rsp+0xA0], xmm10
00007a44d59d599d  vmovaps [rsp+0xB0], xmm11
00007a44d59d59a6  vmovaps [rsp+0xC0], xmm12
00007a44d59d59af  vmovaps [rsp+0xD0], xmm14
00007a44d59d59b8  vmovaps [rsp+0xE0], xmm15
00007a44d59d59c1  sub rsp, 0x40
00007a44d59d59c5  lea rdi, [rsp]
00007a44d59d59c9  lea rsi, [rsp+0x10]
00007a44d59d59ce  lea rdx, [rsp+0x20]
00007a44d59d59d3  lea rcx, [rsp+0x30]
00007a44d59d59d8  mov r8d, 0x00
00007a44d59d59de  lea r9, [r15+0x3A8]
00007a44d59d59e5  movaps [rdi], xmm13
00007a44d59d59e9  movaps [rsi], xmm12
00007a44d59d59ed  movaps [rdx], xmm15
00007a44d59d59f1  movaps [rcx], xmm14
00007a44d59d59f5  mov rax, 0x56179A4B1A50
00007a44d59d59ff  call rax
00007a44d59d5a01  movaps xmm13, [rsp]
00007a44d59d5a06  add rsp, 0x40
00007a44d59d5a0a  vmovaps xmm0, [rsp]
00007a44d59d5a0f  vmovaps xmm1, [rsp+0x10]
00007a44d59d5a15  vmovaps xmm2, [rsp+0x20]
00007a44d59d5a1b  vmovaps xmm3, [rsp+0x30]
00007a44d59d5a21  vmovaps xmm4, [rsp+0x40]
00007a44d59d5a27  vmovaps xmm5, [rsp+0x50]
00007a44d59d5a2d  vmovaps xmm6, [rsp+0x60]
00007a44d59d5a33  vmovaps xmm7, [rsp+0x70]
00007a44d59d5a39  vmovaps xmm8, [rsp+0x80]
00007a44d59d5a42  vmovaps xmm9, [rsp+0x90]
00007a44d59d5a4b  vmovaps xmm10, [rsp+0xA0]
00007a44d59d5a54  vmovaps xmm11, [rsp+0xB0]
00007a44d59d5a5d  vmovaps xmm12, [rsp+0xC0]
00007a44d59d5a66  vmovaps xmm14, [rsp+0xD0]
00007a44d59d5a6f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d5a78  add rsp, 0xF0
00007a44d59d5a7f  pop r11
00007a44d59d5a81  pop r10
00007a44d59d5a83  pop r9
00007a44d59d5a85  pop r8
00007a44d59d5a87  pop rsi
00007a44d59d5a88  pop rdi
00007a44d59d5a89  pop rdx
00007a44d59d5a8a  pop rcx
00007a44d59d5a8b  pop rax
00007a44d59d5a8c  add rsp, 0x08
00007a44d59d5a90  jmp 0x00007A44D59D30CF
00007a44d59d5a95  call 0x00007A44D580E760
00007a44d59d5a9a  jmp 0x00007A44D59D30DC
00007a44d59d5a9f  call 0x00007A44D580D4E0
00007a44d59d5aa4  jmp 0x00007A44D59D30E9
00007a44d59d5aa9  sub rsp, 0x08
00007a44d59d5aad  push rax
00007a44d59d5aae  push rcx
00007a44d59d5aaf  push rdx
00007a44d59d5ab0  push rdi
00007a44d59d5ab1  push rsi
00007a44d59d5ab2  push r8
00007a44d59d5ab4  push r9
00007a44d59d5ab6  push r10
00007a44d59d5ab8  push r11
00007a44d59d5aba  sub rsp, 0xF0
00007a44d59d5ac1  vmovaps [rsp], xmm0
00007a44d59d5ac6  vmovaps [rsp+0x10], xmm1
00007a44d59d5acc  vmovaps [rsp+0x20], xmm2
00007a44d59d5ad2  vmovaps [rsp+0x30], xmm3
00007a44d59d5ad8  vmovaps [rsp+0x40], xmm4
00007a44d59d5ade  vmovaps [rsp+0x50], xmm5
00007a44d59d5ae4  vmovaps [rsp+0x60], xmm6
00007a44d59d5aea  vmovaps [rsp+0x70], xmm7
00007a44d59d5af0  vmovaps [rsp+0x80], xmm8
00007a44d59d5af9  vmovaps [rsp+0x90], xmm9
00007a44d59d5b02  vmovaps [rsp+0xA0], xmm10
00007a44d59d5b0b  vmovaps [rsp+0xB0], xmm12
00007a44d59d5b14  vmovaps [rsp+0xC0], xmm13
00007a44d59d5b1d  vmovaps [rsp+0xD0], xmm14
00007a44d59d5b26  vmovaps [rsp+0xE0], xmm15
00007a44d59d5b2f  sub rsp, 0x40
00007a44d59d5b33  lea rdi, [rsp]
00007a44d59d5b37  lea rsi, [rsp+0x10]
00007a44d59d5b3c  lea rdx, [rsp+0x20]
00007a44d59d5b41  lea rcx, [rsp+0x30]
00007a44d59d5b46  mov r8d, 0x00
00007a44d59d5b4c  lea r9, [r15+0x3A8]
00007a44d59d5b53  movaps [rdi], xmm11
00007a44d59d5b57  movaps [rsi], xmm7
00007a44d59d5b5a  movaps [rdx], xmm1
00007a44d59d5b5d  movaps [rcx], xmm12
00007a44d59d5b61  mov rax, 0x56179A4B1A50
00007a44d59d5b6b  call rax
00007a44d59d5b6d  movaps xmm11, [rsp]
00007a44d59d5b72  add rsp, 0x40
00007a44d59d5b76  vmovaps xmm0, [rsp]
00007a44d59d5b7b  vmovaps xmm1, [rsp+0x10]
00007a44d59d5b81  vmovaps xmm2, [rsp+0x20]
00007a44d59d5b87  vmovaps xmm3, [rsp+0x30]
00007a44d59d5b8d  vmovaps xmm4, [rsp+0x40]
00007a44d59d5b93  vmovaps xmm5, [rsp+0x50]
00007a44d59d5b99  vmovaps xmm6, [rsp+0x60]
00007a44d59d5b9f  vmovaps xmm7, [rsp+0x70]
00007a44d59d5ba5  vmovaps xmm8, [rsp+0x80]
00007a44d59d5bae  vmovaps xmm9, [rsp+0x90]
00007a44d59d5bb7  vmovaps xmm10, [rsp+0xA0]
00007a44d59d5bc0  vmovaps xmm12, [rsp+0xB0]
00007a44d59d5bc9  vmovaps xmm13, [rsp+0xC0]
00007a44d59d5bd2  vmovaps xmm14, [rsp+0xD0]
00007a44d59d5bdb  vmovaps xmm15, [rsp+0xE0]
00007a44d59d5be4  add rsp, 0xF0
00007a44d59d5beb  pop r11
00007a44d59d5bed  pop r10
00007a44d59d5bef  pop r9
00007a44d59d5bf1  pop r8
00007a44d59d5bf3  pop rsi
00007a44d59d5bf4  pop rdi
00007a44d59d5bf5  pop rdx
00007a44d59d5bf6  pop rcx
00007a44d59d5bf7  pop rax
00007a44d59d5bf8  add rsp, 0x08
00007a44d59d5bfc  jmp 0x00007A44D59D3122
00007a44d59d5c01  call 0x00007A44D57FF430
00007a44d59d5c06  jmp 0x00007A44D59D3134
00007a44d59d5c0b  sub rsp, 0x08
00007a44d59d5c0f  push rax
00007a44d59d5c10  push rcx
00007a44d59d5c11  push rdx
00007a44d59d5c12  push rdi
00007a44d59d5c13  push rsi
00007a44d59d5c14  push r8
00007a44d59d5c16  push r9
00007a44d59d5c18  push r10
00007a44d59d5c1a  push r11
00007a44d59d5c1c  sub rsp, 0xF0
00007a44d59d5c23  vmovaps [rsp], xmm0
00007a44d59d5c28  vmovaps [rsp+0x10], xmm1
00007a44d59d5c2e  vmovaps [rsp+0x20], xmm2
00007a44d59d5c34  vmovaps [rsp+0x30], xmm3
00007a44d59d5c3a  vmovaps [rsp+0x40], xmm4
00007a44d59d5c40  vmovaps [rsp+0x50], xmm5
00007a44d59d5c46  vmovaps [rsp+0x60], xmm6
00007a44d59d5c4c  vmovaps [rsp+0x70], xmm7
00007a44d59d5c52  vmovaps [rsp+0x80], xmm8
00007a44d59d5c5b  vmovaps [rsp+0x90], xmm10
00007a44d59d5c64  vmovaps [rsp+0xA0], xmm11
00007a44d59d5c6d  vmovaps [rsp+0xB0], xmm12
00007a44d59d5c76  vmovaps [rsp+0xC0], xmm13
00007a44d59d5c7f  vmovaps [rsp+0xD0], xmm14
00007a44d59d5c88  vmovaps [rsp+0xE0], xmm15
00007a44d59d5c91  sub rsp, 0x40
00007a44d59d5c95  lea rdi, [rsp]
00007a44d59d5c99  lea rsi, [rsp+0x10]
00007a44d59d5c9e  lea rdx, [rsp+0x20]
00007a44d59d5ca3  lea rcx, [rsp+0x30]
00007a44d59d5ca8  mov r8d, 0x00
00007a44d59d5cae  lea r9, [r15+0x3A8]
00007a44d59d5cb5  movaps [rdi], xmm9
00007a44d59d5cb9  movaps [rsi], xmm8
00007a44d59d5cbd  movaps [rdx], xmm14
00007a44d59d5cc1  movaps [rcx], xmm12
00007a44d59d5cc5  mov rax, 0x56179A4B1A50
00007a44d59d5ccf  call rax
00007a44d59d5cd1  movaps xmm9, [rsp]
00007a44d59d5cd6  add rsp, 0x40
00007a44d59d5cda  vmovaps xmm0, [rsp]
00007a44d59d5cdf  vmovaps xmm1, [rsp+0x10]
00007a44d59d5ce5  vmovaps xmm2, [rsp+0x20]
00007a44d59d5ceb  vmovaps xmm3, [rsp+0x30]
00007a44d59d5cf1  vmovaps xmm4, [rsp+0x40]
00007a44d59d5cf7  vmovaps xmm5, [rsp+0x50]
00007a44d59d5cfd  vmovaps xmm6, [rsp+0x60]
00007a44d59d5d03  vmovaps xmm7, [rsp+0x70]
00007a44d59d5d09  vmovaps xmm8, [rsp+0x80]
00007a44d59d5d12  vmovaps xmm10, [rsp+0x90]
00007a44d59d5d1b  vmovaps xmm11, [rsp+0xA0]
00007a44d59d5d24  vmovaps xmm12, [rsp+0xB0]
00007a44d59d5d2d  vmovaps xmm13, [rsp+0xC0]
00007a44d59d5d36  vmovaps xmm14, [rsp+0xD0]
00007a44d59d5d3f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d5d48  add rsp, 0xF0
00007a44d59d5d4f  pop r11
00007a44d59d5d51  pop r10
00007a44d59d5d53  pop r9
00007a44d59d5d55  pop r8
00007a44d59d5d57  pop rsi
00007a44d59d5d58  pop rdi
00007a44d59d5d59  pop rdx
00007a44d59d5d5a  pop rcx
00007a44d59d5d5b  pop rax
00007a44d59d5d5c  add rsp, 0x08
00007a44d59d5d60  jmp 0x00007A44D59D3165
00007a44d59d5d65  sub rsp, 0x08
00007a44d59d5d69  push rax
00007a44d59d5d6a  push rcx
00007a44d59d5d6b  push rdx
00007a44d59d5d6c  push rdi
00007a44d59d5d6d  push rsi
00007a44d59d5d6e  push r8
00007a44d59d5d70  push r9
00007a44d59d5d72  push r10
00007a44d59d5d74  push r11
00007a44d59d5d76  sub rsp, 0xF0
00007a44d59d5d7d  vmovaps [rsp], xmm0
00007a44d59d5d82  vmovaps [rsp+0x10], xmm1
00007a44d59d5d88  vmovaps [rsp+0x20], xmm2
00007a44d59d5d8e  vmovaps [rsp+0x30], xmm3
00007a44d59d5d94  vmovaps [rsp+0x40], xmm4
00007a44d59d5d9a  vmovaps [rsp+0x50], xmm5
00007a44d59d5da0  vmovaps [rsp+0x60], xmm6
00007a44d59d5da6  vmovaps [rsp+0x70], xmm7
00007a44d59d5dac  vmovaps [rsp+0x80], xmm8
00007a44d59d5db5  vmovaps [rsp+0x90], xmm9
00007a44d59d5dbe  vmovaps [rsp+0xA0], xmm10
00007a44d59d5dc7  vmovaps [rsp+0xB0], xmm11
00007a44d59d5dd0  vmovaps [rsp+0xC0], xmm13
00007a44d59d5dd9  vmovaps [rsp+0xD0], xmm14
00007a44d59d5de2  vmovaps [rsp+0xE0], xmm15
00007a44d59d5deb  sub rsp, 0x40
00007a44d59d5def  lea rdi, [rsp]
00007a44d59d5df3  lea rsi, [rsp+0x10]
00007a44d59d5df8  lea rdx, [rsp+0x20]
00007a44d59d5dfd  lea rcx, [rsp+0x30]
00007a44d59d5e02  mov r8d, 0x00
00007a44d59d5e08  lea r9, [r15+0x3A8]
00007a44d59d5e0f  movaps [rdi], xmm12
00007a44d59d5e13  movaps [rsi], xmm10
00007a44d59d5e17  movaps [rdx], xmm15
00007a44d59d5e1b  movaps [rcx], xmm14
00007a44d59d5e1f  mov rax, 0x56179A4B1A50
00007a44d59d5e29  call rax
00007a44d59d5e2b  movaps xmm12, [rsp]
00007a44d59d5e30  add rsp, 0x40
00007a44d59d5e34  vmovaps xmm0, [rsp]
00007a44d59d5e39  vmovaps xmm1, [rsp+0x10]
00007a44d59d5e3f  vmovaps xmm2, [rsp+0x20]
00007a44d59d5e45  vmovaps xmm3, [rsp+0x30]
00007a44d59d5e4b  vmovaps xmm4, [rsp+0x40]
00007a44d59d5e51  vmovaps xmm5, [rsp+0x50]
00007a44d59d5e57  vmovaps xmm6, [rsp+0x60]
00007a44d59d5e5d  vmovaps xmm7, [rsp+0x70]
00007a44d59d5e63  vmovaps xmm8, [rsp+0x80]
00007a44d59d5e6c  vmovaps xmm9, [rsp+0x90]
00007a44d59d5e75  vmovaps xmm10, [rsp+0xA0]
00007a44d59d5e7e  vmovaps xmm11, [rsp+0xB0]
00007a44d59d5e87  vmovaps xmm13, [rsp+0xC0]
00007a44d59d5e90  vmovaps xmm14, [rsp+0xD0]
00007a44d59d5e99  vmovaps xmm15, [rsp+0xE0]
00007a44d59d5ea2  add rsp, 0xF0
00007a44d59d5ea9  pop r11
00007a44d59d5eab  pop r10
00007a44d59d5ead  pop r9
00007a44d59d5eaf  pop r8
00007a44d59d5eb1  pop rsi
00007a44d59d5eb2  pop rdi
00007a44d59d5eb3  pop rdx
00007a44d59d5eb4  pop rcx
00007a44d59d5eb5  pop rax
00007a44d59d5eb6  add rsp, 0x08
00007a44d59d5eba  jmp 0x00007A44D59D3196
00007a44d59d5ebf  sub rsp, 0x08
00007a44d59d5ec3  push rax
00007a44d59d5ec4  push rcx
00007a44d59d5ec5  push rdx
00007a44d59d5ec6  push rdi
00007a44d59d5ec7  push rsi
00007a44d59d5ec8  push r8
00007a44d59d5eca  push r9
00007a44d59d5ecc  push r10
00007a44d59d5ece  push r11
00007a44d59d5ed0  sub rsp, 0xF0
00007a44d59d5ed7  vmovaps [rsp], xmm0
00007a44d59d5edc  vmovaps [rsp+0x10], xmm1
00007a44d59d5ee2  vmovaps [rsp+0x20], xmm2
00007a44d59d5ee8  vmovaps [rsp+0x30], xmm3
00007a44d59d5eee  vmovaps [rsp+0x40], xmm4
00007a44d59d5ef4  vmovaps [rsp+0x50], xmm5
00007a44d59d5efa  vmovaps [rsp+0x60], xmm6
00007a44d59d5f00  vmovaps [rsp+0x70], xmm7
00007a44d59d5f06  vmovaps [rsp+0x80], xmm8
00007a44d59d5f0f  vmovaps [rsp+0x90], xmm9
00007a44d59d5f18  vmovaps [rsp+0xA0], xmm10
00007a44d59d5f21  vmovaps [rsp+0xB0], xmm11
00007a44d59d5f2a  vmovaps [rsp+0xC0], xmm12
00007a44d59d5f33  vmovaps [rsp+0xD0], xmm13
00007a44d59d5f3c  vmovaps [rsp+0xE0], xmm15
00007a44d59d5f45  sub rsp, 0x40
00007a44d59d5f49  lea rdi, [rsp]
00007a44d59d5f4d  lea rsi, [rsp+0x10]
00007a44d59d5f52  lea rdx, [rsp+0x20]
00007a44d59d5f57  lea rcx, [rsp+0x30]
00007a44d59d5f5c  mov r8d, 0x00
00007a44d59d5f62  lea r9, [r15+0x3A8]
00007a44d59d5f69  movaps [rdi], xmm14
00007a44d59d5f6d  movaps [rsi], xmm13
00007a44d59d5f71  movaps [rdx], xmm1
00007a44d59d5f74  movaps [rcx], xmm15
00007a44d59d5f78  mov rax, 0x56179A4B1A50
00007a44d59d5f82  call rax
00007a44d59d5f84  movaps xmm14, [rsp]
00007a44d59d5f89  add rsp, 0x40
00007a44d59d5f8d  vmovaps xmm0, [rsp]
00007a44d59d5f92  vmovaps xmm1, [rsp+0x10]
00007a44d59d5f98  vmovaps xmm2, [rsp+0x20]
00007a44d59d5f9e  vmovaps xmm3, [rsp+0x30]
00007a44d59d5fa4  vmovaps xmm4, [rsp+0x40]
00007a44d59d5faa  vmovaps xmm5, [rsp+0x50]
00007a44d59d5fb0  vmovaps xmm6, [rsp+0x60]
00007a44d59d5fb6  vmovaps xmm7, [rsp+0x70]
00007a44d59d5fbc  vmovaps xmm8, [rsp+0x80]
00007a44d59d5fc5  vmovaps xmm9, [rsp+0x90]
00007a44d59d5fce  vmovaps xmm10, [rsp+0xA0]
00007a44d59d5fd7  vmovaps xmm11, [rsp+0xB0]
00007a44d59d5fe0  vmovaps xmm12, [rsp+0xC0]
00007a44d59d5fe9  vmovaps xmm13, [rsp+0xD0]
00007a44d59d5ff2  vmovaps xmm15, [rsp+0xE0]
00007a44d59d5ffb  add rsp, 0xF0
00007a44d59d6002  pop r11
00007a44d59d6004  pop r10
00007a44d59d6006  pop r9
00007a44d59d6008  pop r8
00007a44d59d600a  pop rsi
00007a44d59d600b  pop rdi
00007a44d59d600c  pop rdx
00007a44d59d600d  pop rcx
00007a44d59d600e  pop rax
00007a44d59d600f  add rsp, 0x08
00007a44d59d6013  jmp 0x00007A44D59D31C7
00007a44d59d6018  call 0x00007A44D58079B0
00007a44d59d601d  jmp 0x00007A44D59D31DA
00007a44d59d6022  call 0x00007A44D580B100
00007a44d59d6027  jmp 0x00007A44D59D31E5
00007a44d59d602c  call 0x00007A44D5809E90
00007a44d59d6031  jmp 0x00007A44D59D31F0
00007a44d59d6036  call 0x00007A44D580D600
00007a44d59d603b  jmp 0x00007A44D59D31FB
00007a44d59d6040  int3
00007a44d59d6041  nop [rax+rax*1], ax
00007a44d59d604a  nop [rax+rax*1], ax
00007a44d59d6050  mov rax, [r15+0x40]
00007a44d59d6054  mov r14, [r15+0x58]
00007a44d59d6058  lea r12, [rax+r14*1]
00007a44d59d605c  vxorps xmm1, xmm1, xmm1
00007a44d59d6060  vpbroadcastq xmm1, xmm1
00007a44d59d6065  vxorps xmm15, xmm15, xmm15
00007a44d59d606a  vpbroadcastq xmm15, xmm15
00007a44d59d606f  lea rax, [r12+0x30]
00007a44d59d6074  mov r11, [r13+rax*1]
00007a44d59d6079  lea rax, [r12+0x38]
00007a44d59d607e  mov r10, [r13+rax*1]
00007a44d59d6083  movq xmm14, r11
00007a44d59d6088  movq xmm13, r10
00007a44d59d608d  movq xmm14, xmm14
00007a44d59d6092  movq xmm13, xmm13
00007a44d59d6097  vmovaps [rsp+0x10], xmm13
00007a44d59d609d  movq xmm13, xmm13
00007a44d59d60a2  movaps [r15+0x270], xmm13
00007a44d59d60aa  movaps xmm13, [r15+0x160]
00007a44d59d60b2  vmovaps [rsp+0x20], xmm13
00007a44d59d60b8  vmovaps xmm12, [rsp+0x20]
00007a44d59d60be  por xmm13, xmm12
00007a44d59d60c3  lea rax, [r12+0x20]
00007a44d59d60c8  mov r11, [r13+rax*1]
00007a44d59d60cd  lea rax, [r12+0x28]
00007a44d59d60d2  mov r10, [r13+rax*1]
00007a44d59d60d7  movq xmm12, r11
00007a44d59d60dc  movq xmm11, r10
00007a44d59d60e1  movq xmm12, xmm12
00007a44d59d60e6  movq xmm11, xmm11
00007a44d59d60eb  movaps xmm10, [r15+0x2D0]
00007a44d59d60f3  vmovaps [rsp+0x20], xmm10
00007a44d59d60f9  vmovaps xmm9, [rsp+0x20]
00007a44d59d60ff  por xmm10, xmm9
00007a44d59d6104  movaps xmm9, [r15+0x300]
00007a44d59d610c  vmovaps [rsp+0x20], xmm9
00007a44d59d6112  vmovaps xmm8, [rsp+0x20]
00007a44d59d6118  por xmm9, xmm8
00007a44d59d611d  movaps xmm8, [r15+0x2B0]
00007a44d59d6125  vmovaps [rsp+0x20], xmm8
00007a44d59d612b  vmovaps xmm7, [rsp+0x20]
00007a44d59d6131  por xmm8, xmm7
00007a44d59d6136  movaps xmm7, [r15+0x180]
00007a44d59d613e  vmovaps [rsp+0x20], xmm7
00007a44d59d6144  vmovaps xmm6, [rsp+0x20]
00007a44d59d614a  por xmm7, xmm6
00007a44d59d614e  lea rax, [r12+0x10]
00007a44d59d6153  mov r11, [r13+rax*1]
00007a44d59d6158  lea rax, [r12+0x18]
00007a44d59d615d  mov r10, [r13+rax*1]
00007a44d59d6162  movq xmm6, r11
00007a44d59d6167  movq xmm5, r10
00007a44d59d616c  movq xmm6, xmm6
00007a44d59d6170  movq xmm5, xmm5
00007a44d59d6174  movaps xmm4, [r15+0x200]
00007a44d59d617c  vmovaps [rsp+0x20], xmm4
00007a44d59d6182  vmovaps xmm3, [rsp+0x20]
00007a44d59d6188  por xmm4, xmm3
00007a44d59d618c  movaps xmm3, [r15+0x1F0]
00007a44d59d6194  vmovaps [rsp+0x20], xmm3
00007a44d59d619a  vmovaps xmm2, [rsp+0x20]
00007a44d59d61a0  por xmm3, xmm2
00007a44d59d61a4  movaps xmm2, [r15+0x2E0]
00007a44d59d61ac  vmovaps [rsp+0x20], xmm2
00007a44d59d61b2  vmovaps [rsp+0x30], xmm1
00007a44d59d61b8  vmovaps xmm1, [rsp+0x20]
00007a44d59d61be  por xmm2, xmm1
00007a44d59d61c2  movaps xmm1, [r15+0x2A0]
00007a44d59d61ca  vmovaps [rsp+0x20], xmm1
00007a44d59d61d0  vmovaps [rsp+0x40], xmm15
00007a44d59d61d6  vmovaps xmm15, [rsp+0x20]
00007a44d59d61dc  por xmm1, xmm15
00007a44d59d61e1  movaps xmm15, [r15+0x280]
00007a44d59d61e9  vmovaps [rsp+0x20], xmm15
00007a44d59d61ef  vmovaps [rsp+0x50], xmm1
00007a44d59d61f5  vmovaps xmm1, [rsp+0x20]
00007a44d59d61fb  por xmm15, xmm1
00007a44d59d6200  movaps xmm1, [r15+0x1C0]
00007a44d59d6208  vmovaps [rsp+0x20], xmm1
00007a44d59d620e  vmovaps [rsp+0x60], xmm15
00007a44d59d6214  vmovaps xmm15, [rsp+0x20]
00007a44d59d621a  por xmm1, xmm15
00007a44d59d621f  movaps xmm15, [r15+0x210]
00007a44d59d6227  vmovaps [rsp+0x20], xmm15
00007a44d59d622d  vmovaps [rsp+0x70], xmm1
00007a44d59d6233  vmovaps xmm1, [rsp+0x20]
00007a44d59d6239  por xmm15, xmm1
00007a44d59d623e  mov rax, [r13+r12*1]
00007a44d59d6243  vmovq xmm1, rax
00007a44d59d6248  vpbroadcastq xmm1, xmm1
00007a44d59d624d  vmovaps [rsp+0x20], xmm1
00007a44d59d6253  vxorps xmm1, xmm1, xmm1
00007a44d59d6257  vpbroadcastq xmm1, xmm1
00007a44d59d625c  mov rax, [r15+0xF8]
00007a44d59d6263  vmovaps [rsp+0x80], xmm1
00007a44d59d626c  movups xmm1, [r13+rax*1]
00007a44d59d6272  vmovaps [rsp+0x90], xmm1
00007a44d59d627b  vxorps xmm1, xmm1, xmm1
00007a44d59d627f  vpbroadcastq xmm1, xmm1
00007a44d59d6284  lea r11, [r12+0x08]
00007a44d59d6289  mov r12, [r13+r11*1]
00007a44d59d628e  vmovaps [rsp+0xA0], xmm1
00007a44d59d6297  movq xmm1, r12
00007a44d59d629c  movaps [r15+0x240], xmm1
00007a44d59d62a4  mov r12, [r15+0x50]
00007a44d59d62a8  lea r11, [r12+r14*1]
00007a44d59d62ac  mov [r15+0x60], r11
00007a44d59d62b0  lea r12, [r14+0x40]
00007a44d59d62b4  mov [r15+0x58], r12
00007a44d59d62b8  vmovaps xmm1, [rsp+0x30]
00007a44d59d62be  vmovaps [rsp+0x30], xmm15
00007a44d59d62c4  vmovaps xmm15, [rsp+0x90]
00007a44d59d62cd  vmovaps [rsp+0x90], xmm14
00007a44d59d62d6  vmovaps xmm14, [rsp+0x20]
00007a44d59d62dc  vmovaps [rsp+0x20], xmm13
00007a44d59d62e2  vmovaps [rsp+0xB0], xmm12
00007a44d59d62eb  movaps xmm13, xmm1
00007a44d59d62ef  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d62fa  vptest xmm12, xmm12
00007a44d59d62ff  jnz 0x00007A44D59D6D9C
00007a44d59d6305  movaps xmm1, [r15+0x250]
00007a44d59d630d  vmovaps xmm15, [rsp+0x40]
00007a44d59d6313  vmovaps [rsp+0x40], xmm13
00007a44d59d6319  movaps xmm12, xmm15
00007a44d59d631d  vfmadd231pd xmm12, xmm1, xmm14
00007a44d59d6322  vcmppd xmm13, xmm12, xmm12, 0x03
00007a44d59d6328  vptest xmm13, xmm13
00007a44d59d632d  jnz 0x00007A44D59D6EF5
00007a44d59d6333  movaps xmm15, [r15+0x1E0]
00007a44d59d633b  vmovaps [rsp+0xC0], xmm15
00007a44d59d6344  vmovaps xmm13, [rsp+0xC0]
00007a44d59d634d  por xmm15, xmm13
00007a44d59d6352  movaps xmm13, [r15+0x1D0]
00007a44d59d635a  vmovaps [rsp+0xC0], xmm13
00007a44d59d6363  vmovaps [rsp+0xD0], xmm1
00007a44d59d636c  vmovaps xmm1, [rsp+0xC0]
00007a44d59d6375  por xmm13, xmm1
00007a44d59d637a  movaps xmm1, [r15+0x2C0]
00007a44d59d6382  vmovaps [rsp+0xC0], xmm1
00007a44d59d638b  vmovaps [rsp+0xE0], xmm15
00007a44d59d6394  vmovaps xmm15, [rsp+0xC0]
00007a44d59d639d  por xmm1, xmm15
00007a44d59d63a2  movaps xmm15, [r15+0x290]
00007a44d59d63aa  vmovaps [rsp+0xC0], xmm15
00007a44d59d63b3  vmovaps [rsp+0xF0], xmm1
00007a44d59d63bc  vmovaps xmm1, [rsp+0xC0]
00007a44d59d63c5  por xmm15, xmm1
00007a44d59d63ca  movaps xmm1, [r15+0x260]
00007a44d59d63d2  vmovaps [rsp+0xC0], xmm1
00007a44d59d63db  vmovaps [rsp+0x100], xmm15
00007a44d59d63e4  vmovaps xmm15, [rsp+0xC0]
00007a44d59d63ed  por xmm1, xmm15
00007a44d59d63f2  vmovaps xmm15, [rsp+0xD0]
00007a44d59d63fb  vmovaps [rsp+0xC0], xmm1
00007a44d59d6404  vmovaps xmm1, [rsp+0xD0]
00007a44d59d640d  por xmm15, xmm1
00007a44d59d6412  lea r14, [rax+0xC0]
00007a44d59d6419  movups xmm1, [r13+r14*1]
00007a44d59d641f  mov [rsp+0xD0], rax
00007a44d59d6427  xor eax, eax
00007a44d59d6429  mov r14d, 0x200
00007a44d59d642f  cmp r12, r14
00007a44d59d6432  cmc
00007a44d59d6433  lahf
00007a44d59d6434  seto al
00007a44d59d6437  mov [r15+0x108], eax
00007a44d59d643e  vmovaps [rsp+0x110], xmm1
00007a44d59d6447  vmovaps xmm1, [rsp+0x80]
00007a44d59d6450  vmovaps [rsp+0x80], xmm15
00007a44d59d6459  vmovaps xmm15, [rsp+0x110]
00007a44d59d6462  vmovaps [rsp+0x110], xmm13
00007a44d59d646b  vmovaps [rsp+0x120], xmm12
00007a44d59d6474  movaps xmm13, xmm1
00007a44d59d6478  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d647d  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d6483  vptest xmm12, xmm12
00007a44d59d6488  jnz 0x00007A44D59D7058
00007a44d59d648e  mov rax, [rsp+0xD0]
00007a44d59d6496  lea r14, [rax+0xB0]
00007a44d59d649d  movups xmm1, [r13+r14*1]
00007a44d59d64a3  vmovaps xmm15, [rsp+0xA0]
00007a44d59d64ac  vmovaps [rsp+0xA0], xmm13
00007a44d59d64b5  movaps xmm12, xmm15
00007a44d59d64b9  vfmadd231pd xmm12, xmm1, xmm14
00007a44d59d64be  vcmppd xmm13, xmm12, xmm12, 0x03
00007a44d59d64c4  vptest xmm13, xmm13
00007a44d59d64c9  jnz 0x00007A44D59D71BB
00007a44d59d64cf  vmovaps xmm1, [rsp+0x30]
00007a44d59d64d5  vmovaps xmm15, [rsp+0x30]
00007a44d59d64db  por xmm1, xmm15
00007a44d59d64e0  movaps [r15+0x210], xmm1
00007a44d59d64e8  vmovaps xmm15, [rsp+0x70]
00007a44d59d64ee  vmovaps xmm14, [rsp+0x70]
00007a44d59d64f4  por xmm15, xmm14
00007a44d59d64f9  movaps [r15+0x1C0], xmm15
00007a44d59d6501  vmovaps xmm14, [rsp+0x60]
00007a44d59d6507  vmovaps xmm13, [rsp+0x60]
00007a44d59d650d  por xmm14, xmm13
00007a44d59d6512  movaps [r15+0x280], xmm14
00007a44d59d651a  vmovaps xmm13, [rsp+0x50]
00007a44d59d6520  vmovaps [rsp+0x30], xmm1
00007a44d59d6526  vmovaps xmm1, [rsp+0x50]
00007a44d59d652c  por xmm13, xmm1
00007a44d59d6531  movaps [r15+0x2A0], xmm13
00007a44d59d6539  vmovaps [rsp+0x50], xmm2
00007a44d59d653f  vmovaps xmm1, [rsp+0x50]
00007a44d59d6545  por xmm2, xmm1
00007a44d59d6549  movaps [r15+0x2E0], xmm2
00007a44d59d6551  vmovaps [rsp+0x50], xmm3
00007a44d59d6557  vmovaps xmm1, [rsp+0x50]
00007a44d59d655d  por xmm3, xmm1
00007a44d59d6561  movaps [r15+0x1F0], xmm3
00007a44d59d6569  vmovaps xmm1, [rsp+0x80]
00007a44d59d6572  vmovaps [rsp+0x50], xmm15
00007a44d59d6578  vmovaps xmm15, [rsp+0x80]
00007a44d59d6581  por xmm1, xmm15
00007a44d59d6586  movaps [r15+0x250], xmm1
00007a44d59d658e  vmovaps xmm1, [rsp+0xC0]
00007a44d59d6597  vmovaps xmm15, [rsp+0xC0]
00007a44d59d65a0  por xmm1, xmm15
00007a44d59d65a5  movaps [r15+0x260], xmm1
00007a44d59d65ad  vmovaps xmm15, [rsp+0x100]
00007a44d59d65b6  vmovaps [rsp+0x60], xmm1
00007a44d59d65bc  vmovaps xmm1, [rsp+0x100]
00007a44d59d65c5  por xmm15, xmm1
00007a44d59d65ca  movaps [r15+0x290], xmm15
00007a44d59d65d2  vmovaps xmm1, [rsp+0xF0]
00007a44d59d65db  vmovaps [rsp+0x70], xmm15
00007a44d59d65e1  vmovaps xmm15, [rsp+0xF0]
00007a44d59d65ea  por xmm1, xmm15
00007a44d59d65ef  movaps [r15+0x2C0], xmm1
00007a44d59d65f7  movq xmm15, qword ptr [r15+0x240]
00007a44d59d6600  vmovaps [rsp+0x80], xmm15
00007a44d59d6609  vpermilpd xmm15, xmm15, 0x00
00007a44d59d660f  vmovaps [rsp+0xC0], xmm1
00007a44d59d6618  vmovaps xmm1, [rsp+0x40]
00007a44d59d661e  vmovaps [rsp+0x40], xmm15
00007a44d59d6624  vmovaps xmm15, [rsp+0x30]
00007a44d59d662a  vmovaps [rsp+0x30], xmm14
00007a44d59d6630  vmovaps xmm14, [rsp+0x40]
00007a44d59d6636  vmovaps [rsp+0x40], xmm13
00007a44d59d663c  vmovaps [rsp+0xD0], xmm12
00007a44d59d6645  movaps xmm13, xmm1
00007a44d59d6649  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d664e  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d6654  vptest xmm12, xmm12
00007a44d59d6659  jnz 0x00007A44D59D7314
00007a44d59d665f  vmovaps xmm1, [rsp+0x80]
00007a44d59d6668  vpermilpd xmm1, xmm1, 0x00
00007a44d59d666e  vmovaps xmm15, [rsp+0xA0]
00007a44d59d6677  movaps xmm14, xmm15
00007a44d59d667b  vfmadd231pd xmm14, xmm2, xmm1
00007a44d59d6680  vcmppd xmm12, xmm14, xmm14, 0x03
00007a44d59d6686  vptest xmm12, xmm12
00007a44d59d668b  jnz 0x00007A44D59D746D
00007a44d59d6691  vmovaps xmm1, [rsp+0x80]
00007a44d59d669a  vpermilpd xmm1, xmm1, 0x00
00007a44d59d66a0  vmovaps xmm15, [rsp+0x120]
00007a44d59d66a9  vmovaps xmm12, [rsp+0x50]
00007a44d59d66af  vmovaps [rsp+0x50], xmm14
00007a44d59d66b5  movaps xmm2, xmm15
00007a44d59d66b9  vfmadd231pd xmm2, xmm12, xmm1
00007a44d59d66be  vcmppd xmm14, xmm2, xmm2, 0x03
00007a44d59d66c3  vptest xmm14, xmm14
00007a44d59d66c8  jnz 0x00007A44D59D75C5
00007a44d59d66ce  vmovaps xmm1, [rsp+0x110]
00007a44d59d66d7  vmovaps xmm15, [rsp+0x110]
00007a44d59d66e0  por xmm1, xmm15
00007a44d59d66e5  movaps [r15+0x1D0], xmm1
00007a44d59d66ed  vmovaps xmm15, [rsp+0x80]
00007a44d59d66f6  vpermilpd xmm15, xmm15, 0x00
00007a44d59d66fc  vmovaps xmm14, [rsp+0xD0]
00007a44d59d6705  vmovaps [rsp+0x80], xmm1
00007a44d59d670e  movaps xmm12, xmm14
00007a44d59d6712  vfmadd231pd xmm12, xmm3, xmm15
00007a44d59d6717  vcmppd xmm1, xmm12, xmm12, 0x03
00007a44d59d671d  vptest xmm1, xmm1
00007a44d59d6722  jnz 0x00007A44D59D771C
00007a44d59d6728  vmovaps [rsp+0xA0], xmm4
00007a44d59d6731  vmovaps xmm1, [rsp+0xA0]
00007a44d59d673a  por xmm4, xmm1
00007a44d59d673e  movaps [r15+0x200], xmm4
00007a44d59d6746  vmovaps xmm1, [rsp+0xE0]
00007a44d59d674f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d6758  por xmm1, xmm15
00007a44d59d675d  movaps [r15+0x1E0], xmm1
00007a44d59d6765  vmovaps [rsp+0xA0], xmm8
00007a44d59d676e  vmovaps xmm1, [rsp+0xA0]
00007a44d59d6777  por xmm8, xmm1
00007a44d59d677c  movaps [r15+0x2B0], xmm8
00007a44d59d6784  vmovaps [rsp+0xA0], xmm9
00007a44d59d678d  vmovaps xmm1, [rsp+0xA0]
00007a44d59d6796  por xmm9, xmm1
00007a44d59d679b  movaps [r15+0x300], xmm9
00007a44d59d67a3  vmovaps [rsp+0xA0], xmm6
00007a44d59d67ac  vpermilpd xmm6, xmm6, 0x00
00007a44d59d67b2  vmovaps xmm14, [rsp+0x60]
00007a44d59d67b8  movaps xmm9, xmm13
00007a44d59d67bc  vfmadd231pd xmm9, xmm14, xmm6
00007a44d59d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
00007a44d59d67c7  vptest xmm3, xmm3
00007a44d59d67cc  jnz 0x00007A44D59D7875
00007a44d59d67d2  vmovaps xmm14, [rsp+0xA0]
00007a44d59d67db  vpermilpd xmm14, xmm14, 0x00
00007a44d59d67e1  vmovaps xmm13, [rsp+0x50]
00007a44d59d67e7  vmovaps xmm6, [rsp+0xC0]
00007a44d59d67f0  vmovaps [rsp+0x50], xmm1
00007a44d59d67f6  movaps xmm3, xmm13
00007a44d59d67fa  vfmadd231pd xmm3, xmm6, xmm14
00007a44d59d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
00007a44d59d6804  vptest xmm1, xmm1
00007a44d59d6809  jnz 0x00007A44D59D79CE
00007a44d59d680f  vmovaps xmm1, [rsp+0xA0]
00007a44d59d6818  vpermilpd xmm1, xmm1, 0x00
00007a44d59d681e  vmovaps xmm14, [rsp+0x30]
00007a44d59d6824  movaps xmm6, xmm2
00007a44d59d6827  vfmadd231pd xmm6, xmm14, xmm1
00007a44d59d682c  vcmppd xmm13, xmm6, xmm6, 0x03
00007a44d59d6831  vptest xmm13, xmm13
00007a44d59d6836  jnz 0x00007A44D59D7B25
00007a44d59d683c  vmovaps xmm1, [rsp+0xA0]
00007a44d59d6845  vpermilpd xmm1, xmm1, 0x00
00007a44d59d684b  vmovaps xmm14, [rsp+0x80]
00007a44d59d6854  movaps xmm13, xmm12
00007a44d59d6858  vfmadd231pd xmm13, xmm14, xmm1
00007a44d59d685d  vcmppd xmm2, xmm13, xmm13, 0x03
00007a44d59d6863  vptest xmm2, xmm2
00007a44d59d6868  jnz 0x00007A44D59D7C7B
00007a44d59d686e  vmovaps [rsp+0x30], xmm7
00007a44d59d6874  vmovaps xmm1, [rsp+0x30]
00007a44d59d687a  por xmm7, xmm1
00007a44d59d687e  movaps [r15+0x180], xmm7
00007a44d59d6886  vmovaps [rsp+0x30], xmm10
00007a44d59d688c  vmovaps xmm1, [rsp+0x30]
00007a44d59d6892  por xmm10, xmm1
00007a44d59d6897  movaps [r15+0x2D0], xmm10
00007a44d59d689f  vmovaps [rsp+0x30], xmm5
00007a44d59d68a5  vpermilpd xmm5, xmm5, 0x00
00007a44d59d68ab  vmovaps xmm14, [rsp+0x50]
00007a44d59d68b1  movaps xmm12, xmm3
00007a44d59d68b5  vfmadd231pd xmm12, xmm14, xmm5
00007a44d59d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
00007a44d59d68c0  vptest xmm10, xmm10
00007a44d59d68c5  jnz 0x00007A44D59D7DD4
00007a44d59d68cb  vmovaps xmm14, [rsp+0x30]
00007a44d59d68d1  vpermilpd xmm14, xmm14, 0x00
00007a44d59d68d7  movaps xmm10, xmm9
00007a44d59d68db  vfmadd231pd xmm10, xmm7, xmm14
00007a44d59d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
00007a44d59d68e6  vptest xmm5, xmm5
00007a44d59d68eb  jnz 0x00007A44D59D7F2C
00007a44d59d68f1  lea r14, [rax+0x80]
00007a44d59d68f8  movups xmm14, [r13+r14*1]
00007a44d59d68fe  movaps [r15+0x2F0], xmm14
00007a44d59d6906  vmovaps xmm9, [rsp+0x30]
00007a44d59d690c  vpermilpd xmm9, xmm9, 0x00
00007a44d59d6912  vmovaps xmm7, [rsp+0x70]
00007a44d59d6918  movaps xmm5, xmm6
00007a44d59d691b  vfmadd231pd xmm5, xmm7, xmm9
00007a44d59d6920  vcmppd xmm3, xmm5, xmm5, 0x03
00007a44d59d6925  vptest xmm3, xmm3
00007a44d59d692a  jnz 0x00007A44D59D808F
00007a44d59d6930  vmovaps xmm9, [rsp+0x30]
00007a44d59d6936  vpermilpd xmm9, xmm9, 0x00
00007a44d59d693c  movaps xmm7, xmm13
00007a44d59d6940  vfmadd231pd xmm7, xmm1, xmm9
00007a44d59d6945  vcmppd xmm6, xmm7, xmm7, 0x03
00007a44d59d694a  vptest xmm6, xmm6
00007a44d59d694f  jnz 0x00007A44D59D81E5
00007a44d59d6955  vmovaps xmm1, [rsp+0x20]
00007a44d59d695b  vmovaps xmm13, [rsp+0x20]
00007a44d59d6961  por xmm1, xmm13
00007a44d59d6966  movaps [r15+0x160], xmm1
00007a44d59d696e  lea r14, [rax+0x40]
00007a44d59d6972  movups xmm13, [r13+r14*1]
00007a44d59d6978  lea r14, [rax+0x50]
00007a44d59d697c  movups xmm9, [r13+r14*1]
00007a44d59d6982  movaps [r15+0x1B0], xmm13
00007a44d59d698a  movaps [r15+0x1A0], xmm9
00007a44d59d6992  movaps xmm6, [r15+0x190]
00007a44d59d699a  vmovaps xmm3, [rsp+0xB0]
00007a44d59d69a3  vpermilpd xmm3, xmm3, 0x00
00007a44d59d69a9  vmovaps [rsp+0x20], xmm1
00007a44d59d69af  movaps xmm2, xmm12
00007a44d59d69b3  vfmadd231pd xmm2, xmm6, xmm3
00007a44d59d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
00007a44d59d69bd  vptest xmm1, xmm1
00007a44d59d69c2  jnz 0x00007A44D59D8350
00007a44d59d69c8  vmovaps xmm1, [rsp+0xB0]
00007a44d59d69d1  vpermilpd xmm1, xmm1, 0x00
00007a44d59d69d7  vmovaps xmm12, [rsp+0x20]
00007a44d59d69dd  movaps xmm6, xmm10
00007a44d59d69e1  vfmadd231pd xmm6, xmm12, xmm1
00007a44d59d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
00007a44d59d69eb  vptest xmm3, xmm3
00007a44d59d69f0  jnz 0x00007A44D59D84A6
00007a44d59d69f6  vmovaps xmm1, [rsp+0xB0]
00007a44d59d69ff  vpermilpd xmm1, xmm1, 0x00
00007a44d59d6a05  vmovaps xmm12, [rsp+0x40]
00007a44d59d6a0b  movaps xmm10, xmm5
00007a44d59d6a0f  vfmadd231pd xmm10, xmm12, xmm1
00007a44d59d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
00007a44d59d6a1a  vptest xmm3, xmm3
00007a44d59d6a1f  jnz 0x00007A44D59D85FD
00007a44d59d6a25  vmovaps xmm1, [rsp+0xB0]
00007a44d59d6a2e  vpermilpd xmm1, xmm1, 0x00
00007a44d59d6a34  movaps xmm12, xmm7
00007a44d59d6a38  vfmadd231pd xmm12, xmm15, xmm1
00007a44d59d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
00007a44d59d6a43  vptest xmm5, xmm5
00007a44d59d6a48  jnz 0x00007A44D59D8755
00007a44d59d6a4e  lea r14, [rax+0x60]
00007a44d59d6a52  movups xmm1, [r13+r14*1]
00007a44d59d6a58  lea r14, [rax+0x70]
00007a44d59d6a5c  movups xmm15, [r13+r14*1]
00007a44d59d6a62  movaps [r15+0x150], xmm1
00007a44d59d6a6a  movaps [r15+0x120], xmm15
00007a44d59d6a72  vmovaps [rsp+0x20], xmm11
00007a44d59d6a78  vpermilpd xmm11, xmm11, 0x00
00007a44d59d6a7e  movaps xmm7, xmm2
00007a44d59d6a81  vfmadd231pd xmm7, xmm9, xmm11
00007a44d59d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
00007a44d59d6a8b  vptest xmm5, xmm5
00007a44d59d6a90  jnz 0x00007A44D59D88C1
00007a44d59d6a96  vmovaps xmm11, [rsp+0x20]
00007a44d59d6a9c  vpermilpd xmm11, xmm11, 0x00
00007a44d59d6aa2  movaps xmm9, xmm6
00007a44d59d6aa6  vfmadd231pd xmm9, xmm1, xmm11
00007a44d59d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
00007a44d59d6ab1  vptest xmm5, xmm5
00007a44d59d6ab6  jnz 0x00007A44D59D8A18
00007a44d59d6abc  vmovaps xmm1, [rsp+0x20]
00007a44d59d6ac2  vpermilpd xmm1, xmm1, 0x00
00007a44d59d6ac8  movaps xmm11, xmm10
00007a44d59d6acc  vfmadd231pd xmm11, xmm8, xmm1
00007a44d59d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
00007a44d59d6ad7  vptest xmm6, xmm6
00007a44d59d6adc  jnz 0x00007A44D59D8B70
00007a44d59d6ae2  vmovaps xmm1, [rsp+0x20]
00007a44d59d6ae8  vpermilpd xmm1, xmm1, 0x00
00007a44d59d6aee  movaps xmm10, xmm12
00007a44d59d6af2  vfmadd231pd xmm10, xmm13, xmm1
00007a44d59d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
00007a44d59d6afd  vptest xmm8, xmm8
00007a44d59d6b02  jnz 0x00007A44D59D8CC9
00007a44d59d6b08  lea r14, [rax+0x20]
00007a44d59d6b0c  movups xmm1, [r13+r14*1]
00007a44d59d6b12  lea r14, [rax+0x30]
00007a44d59d6b16  movups xmm13, [r13+r14*1]
00007a44d59d6b1c  vmovaps xmm12, [rsp+0x90]
00007a44d59d6b25  vpermilpd xmm12, xmm12, 0x00
00007a44d59d6b2b  movaps xmm8, xmm7
00007a44d59d6b2f  vfmadd231pd xmm8, xmm4, xmm12
00007a44d59d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
00007a44d59d6b3a  vptest xmm6, xmm6
00007a44d59d6b3f  jnz 0x00007A44D59D8E36
00007a44d59d6b45  vmovaps xmm12, [rsp+0x90]
00007a44d59d6b4e  vpermilpd xmm12, xmm12, 0x00
00007a44d59d6b54  movaps xmm7, xmm9
00007a44d59d6b58  vfmadd231pd xmm7, xmm14, xmm12
00007a44d59d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
00007a44d59d6b62  vptest xmm6, xmm6
00007a44d59d6b67  jnz 0x00007A44D59D8F8E
00007a44d59d6b6d  vmovaps xmm14, [rsp+0x90]
00007a44d59d6b76  vpermilpd xmm14, xmm14, 0x00
00007a44d59d6b7c  movaps xmm12, xmm11
00007a44d59d6b80  vfmadd231pd xmm12, xmm15, xmm14
00007a44d59d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
00007a44d59d6b8b  vptest xmm9, xmm9
00007a44d59d6b90  jnz 0x00007A44D59D90E6
00007a44d59d6b96  vmovaps xmm15, [rsp+0x90]
00007a44d59d6b9f  vpermilpd xmm15, xmm15, 0x00
00007a44d59d6ba5  movaps xmm11, xmm10
00007a44d59d6ba9  vfmadd231pd xmm11, xmm13, xmm15
00007a44d59d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
00007a44d59d6bb4  vptest xmm14, xmm14
00007a44d59d6bb9  jnz 0x00007A44D59D9240
00007a44d59d6bbf  lea r14, [rax+0x90]
00007a44d59d6bc6  movups xmm15, [r13+r14*1]
00007a44d59d6bcc  lea r14, [rax+0xA0]
00007a44d59d6bd3  movups xmm14, [r13+r14*1]
00007a44d59d6bd9  movaps [r15+0x140], xmm15
00007a44d59d6be1  movaps [r15+0x130], xmm14
00007a44d59d6be9  vmovaps xmm13, [rsp+0x10]
00007a44d59d6bef  vpermilpd xmm13, xmm13, 0x00
00007a44d59d6bf5  movaps xmm10, xmm8
00007a44d59d6bf9  vfmadd231pd xmm10, xmm1, xmm13
00007a44d59d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
00007a44d59d6c04  vptest xmm9, xmm9
00007a44d59d6c09  jnz 0x00007A44D59D93AE
00007a44d59d6c0f  movaps [r15+0x220], xmm10
00007a44d59d6c17  lea r14, [rax+0x10]
00007a44d59d6c1b  movups xmm1, [r13+r14*1]
00007a44d59d6c21  movaps [r15+0x240], xmm1
00007a44d59d6c29  vmovaps xmm13, [rsp+0x10]
00007a44d59d6c2f  vpermilpd xmm13, xmm13, 0x00
00007a44d59d6c35  movaps xmm9, xmm7
00007a44d59d6c39  vfmadd231pd xmm9, xmm14, xmm13
00007a44d59d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
00007a44d59d6c44  vptest xmm8, xmm8
00007a44d59d6c49  jnz 0x00007A44D59D9511
00007a44d59d6c4f  movaps [r15+0x110], xmm9
00007a44d59d6c57  vmovaps xmm14, [rsp+0x10]
00007a44d59d6c5d  vpermilpd xmm14, xmm14, 0x00
00007a44d59d6c63  movaps xmm13, xmm12
00007a44d59d6c67  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
00007a44d59d6c72  vptest xmm8, xmm8
00007a44d59d6c77  jnz 0x00007A44D59D966A
00007a44d59d6c7d  movaps [r15+0x170], xmm13
00007a44d59d6c85  vmovaps xmm15, [rsp+0x10]
00007a44d59d6c8b  vpermilpd xmm15, xmm15, 0x00
00007a44d59d6c91  movaps xmm14, xmm11
00007a44d59d6c95  vfmadd231pd xmm14, xmm1, xmm15
00007a44d59d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
00007a44d59d6ca0  vptest xmm12, xmm12
00007a44d59d6ca5  jnz 0x00007A44D59D97C4
00007a44d59d6cab  movaps [r15+0x230], xmm14
00007a44d59d6cb3  movups [r13+r11*1], xmm9
00007a44d59d6cb9  lea rax, [r11+0x10]
00007a44d59d6cbd  movups [r13+rax*1], xmm13
00007a44d59d6cc3  lea rax, [r11+0x20]
00007a44d59d6cc7  movups [r13+rax*1], xmm10
00007a44d59d6ccd  lea rax, [r11+0x30]
00007a44d59d6cd1  movups [r13+rax*1], xmm14
00007a44d59d6cd7  mov eax, [r15+0x108]
00007a44d59d6cde  sahf
00007a44d59d6cdf  jnz 0x00007A44D59D6D11
00007a44d59d6ce1  cmp dword ptr [r15+0x318], 0x00
00007a44d59d6ce9  jz 0x00007A44D59D9950
00007a44d59d6cef  nop [rax+rax*1], ax
00007a44d59d6cf8  nop [rax+rax*1], eax
00007a44d59d6d00  mov eax, 0x410664
00007a44d59d6d05  mov [r15+0x100], rax
00007a44d59d6d0c  jmp 0x00007A44D57FE110
00007a44d59d6d11  cmp dword ptr [r15+0x318], 0x00
00007a44d59d6d19  jz 0x00007A44D59D6050
00007a44d59d6d1f  nop [rax+rax*1], ax
00007a44d59d6d28  nop [rax+rax*1], eax
00007a44d59d6d30  mov eax, 0x4104F0
00007a44d59d6d35  mov [r15+0x100], rax
00007a44d59d6d3c  jmp 0x00007A44D57FE110
00007a44d59d6d41  int3
00007a44d59d6d42  call 0x00007A44D580A4B0
00007a44d59d6d47  jmp 0x00007A44D59D6079
00007a44d59d6d4c  call 0x00007A44D5809240
00007a44d59d6d51  jmp 0x00007A44D59D6083
00007a44d59d6d56  call 0x00007A44D580A4B0
00007a44d59d6d5b  jmp 0x00007A44D59D60CD
00007a44d59d6d60  call 0x00007A44D5809240
00007a44d59d6d65  jmp 0x00007A44D59D60D7
00007a44d59d6d6a  call 0x00007A44D580A4B0
00007a44d59d6d6f  jmp 0x00007A44D59D6158
00007a44d59d6d74  call 0x00007A44D5809240
00007a44d59d6d79  jmp 0x00007A44D59D6162
00007a44d59d6d7e  call 0x00007A44D58B47C0
00007a44d59d6d83  jmp 0x00007A44D59D6243
00007a44d59d6d88  call 0x00007A44D57FF430
00007a44d59d6d8d  jmp 0x00007A44D59D6272
00007a44d59d6d92  call 0x00007A44D58B0CE0
00007a44d59d6d97  jmp 0x00007A44D59D628E
00007a44d59d6d9c  sub rsp, 0x08
00007a44d59d6da0  push rax
00007a44d59d6da1  push rcx
00007a44d59d6da2  push rdx
00007a44d59d6da3  push rdi
00007a44d59d6da4  push rsi
00007a44d59d6da5  push r8
00007a44d59d6da7  push r9
00007a44d59d6da9  push r10
00007a44d59d6dab  push r11
00007a44d59d6dad  sub rsp, 0xF0
00007a44d59d6db4  vmovaps [rsp], xmm0
00007a44d59d6db9  vmovaps [rsp+0x10], xmm1
00007a44d59d6dbf  vmovaps [rsp+0x20], xmm2
00007a44d59d6dc5  vmovaps [rsp+0x30], xmm3
00007a44d59d6dcb  vmovaps [rsp+0x40], xmm4
00007a44d59d6dd1  vmovaps [rsp+0x50], xmm5
00007a44d59d6dd7  vmovaps [rsp+0x60], xmm6
00007a44d59d6ddd  vmovaps [rsp+0x70], xmm7
00007a44d59d6de3  vmovaps [rsp+0x80], xmm8
00007a44d59d6dec  vmovaps [rsp+0x90], xmm9
00007a44d59d6df5  vmovaps [rsp+0xA0], xmm10
00007a44d59d6dfe  vmovaps [rsp+0xB0], xmm11
00007a44d59d6e07  vmovaps [rsp+0xC0], xmm12
00007a44d59d6e10  vmovaps [rsp+0xD0], xmm14
00007a44d59d6e19  vmovaps [rsp+0xE0], xmm15
00007a44d59d6e22  sub rsp, 0x40
00007a44d59d6e26  lea rdi, [rsp]
00007a44d59d6e2a  lea rsi, [rsp+0x10]
00007a44d59d6e2f  lea rdx, [rsp+0x20]
00007a44d59d6e34  lea rcx, [rsp+0x30]
00007a44d59d6e39  mov r8d, 0x00
00007a44d59d6e3f  lea r9, [r15+0x3A8]
00007a44d59d6e46  movaps [rdi], xmm13
00007a44d59d6e4a  movaps [rsi], xmm1
00007a44d59d6e4d  movaps [rdx], xmm15
00007a44d59d6e51  movaps [rcx], xmm14
00007a44d59d6e55  mov rax, 0x56179A4B1A50
00007a44d59d6e5f  call rax
00007a44d59d6e61  movaps xmm13, [rsp]
00007a44d59d6e66  add rsp, 0x40
00007a44d59d6e6a  vmovaps xmm0, [rsp]
00007a44d59d6e6f  vmovaps xmm1, [rsp+0x10]
00007a44d59d6e75  vmovaps xmm2, [rsp+0x20]
00007a44d59d6e7b  vmovaps xmm3, [rsp+0x30]
00007a44d59d6e81  vmovaps xmm4, [rsp+0x40]
00007a44d59d6e87  vmovaps xmm5, [rsp+0x50]
00007a44d59d6e8d  vmovaps xmm6, [rsp+0x60]
00007a44d59d6e93  vmovaps xmm7, [rsp+0x70]
00007a44d59d6e99  vmovaps xmm8, [rsp+0x80]
00007a44d59d6ea2  vmovaps xmm9, [rsp+0x90]
00007a44d59d6eab  vmovaps xmm10, [rsp+0xA0]
00007a44d59d6eb4  vmovaps xmm11, [rsp+0xB0]
00007a44d59d6ebd  vmovaps xmm12, [rsp+0xC0]
00007a44d59d6ec6  vmovaps xmm14, [rsp+0xD0]
00007a44d59d6ecf  vmovaps xmm15, [rsp+0xE0]
00007a44d59d6ed8  add rsp, 0xF0
00007a44d59d6edf  pop r11
00007a44d59d6ee1  pop r10
00007a44d59d6ee3  pop r9
00007a44d59d6ee5  pop r8
00007a44d59d6ee7  pop rsi
00007a44d59d6ee8  pop rdi
00007a44d59d6ee9  pop rdx
00007a44d59d6eea  pop rcx
00007a44d59d6eeb  pop rax
00007a44d59d6eec  add rsp, 0x08
00007a44d59d6ef0  jmp 0x00007A44D59D6305
00007a44d59d6ef5  sub rsp, 0x08
00007a44d59d6ef9  push rax
00007a44d59d6efa  push rcx
00007a44d59d6efb  push rdx
00007a44d59d6efc  push rdi
00007a44d59d6efd  push rsi
00007a44d59d6efe  push r8
00007a44d59d6f00  push r9
00007a44d59d6f02  push r10
00007a44d59d6f04  push r11
00007a44d59d6f06  sub rsp, 0xF0
00007a44d59d6f0d  vmovaps [rsp], xmm0
00007a44d59d6f12  vmovaps [rsp+0x10], xmm1
00007a44d59d6f18  vmovaps [rsp+0x20], xmm2
00007a44d59d6f1e  vmovaps [rsp+0x30], xmm3
00007a44d59d6f24  vmovaps [rsp+0x40], xmm4
00007a44d59d6f2a  vmovaps [rsp+0x50], xmm5
00007a44d59d6f30  vmovaps [rsp+0x60], xmm6
00007a44d59d6f36  vmovaps [rsp+0x70], xmm7
00007a44d59d6f3c  vmovaps [rsp+0x80], xmm8
00007a44d59d6f45  vmovaps [rsp+0x90], xmm9
00007a44d59d6f4e  vmovaps [rsp+0xA0], xmm10
00007a44d59d6f57  vmovaps [rsp+0xB0], xmm11
00007a44d59d6f60  vmovaps [rsp+0xC0], xmm13
00007a44d59d6f69  vmovaps [rsp+0xD0], xmm14
00007a44d59d6f72  vmovaps [rsp+0xE0], xmm15
00007a44d59d6f7b  sub rsp, 0x40
00007a44d59d6f7f  lea rdi, [rsp]
00007a44d59d6f83  lea rsi, [rsp+0x10]
00007a44d59d6f88  lea rdx, [rsp+0x20]
00007a44d59d6f8d  lea rcx, [rsp+0x30]
00007a44d59d6f92  mov r8d, 0x00
00007a44d59d6f98  lea r9, [r15+0x3A8]
00007a44d59d6f9f  movaps [rdi], xmm12
00007a44d59d6fa3  movaps [rsi], xmm15
00007a44d59d6fa7  movaps [rdx], xmm1
00007a44d59d6faa  movaps [rcx], xmm14
00007a44d59d6fae  mov rax, 0x56179A4B1A50
00007a44d59d6fb8  call rax
00007a44d59d6fba  movaps xmm12, [rsp]
00007a44d59d6fbf  add rsp, 0x40
00007a44d59d6fc3  vmovaps xmm0, [rsp]
00007a44d59d6fc8  vmovaps xmm1, [rsp+0x10]
00007a44d59d6fce  vmovaps xmm2, [rsp+0x20]
00007a44d59d6fd4  vmovaps xmm3, [rsp+0x30]
00007a44d59d6fda  vmovaps xmm4, [rsp+0x40]
00007a44d59d6fe0  vmovaps xmm5, [rsp+0x50]
00007a44d59d6fe6  vmovaps xmm6, [rsp+0x60]
00007a44d59d6fec  vmovaps xmm7, [rsp+0x70]
00007a44d59d6ff2  vmovaps xmm8, [rsp+0x80]
00007a44d59d6ffb  vmovaps xmm9, [rsp+0x90]
00007a44d59d7004  vmovaps xmm10, [rsp+0xA0]
00007a44d59d700d  vmovaps xmm11, [rsp+0xB0]
00007a44d59d7016  vmovaps xmm13, [rsp+0xC0]
00007a44d59d701f  vmovaps xmm14, [rsp+0xD0]
00007a44d59d7028  vmovaps xmm15, [rsp+0xE0]
00007a44d59d7031  add rsp, 0xF0
00007a44d59d7038  pop r11
00007a44d59d703a  pop r10
00007a44d59d703c  pop r9
00007a44d59d703e  pop r8
00007a44d59d7040  pop rsi
00007a44d59d7041  pop rdi
00007a44d59d7042  pop rdx
00007a44d59d7043  pop rcx
00007a44d59d7044  pop rax
00007a44d59d7045  add rsp, 0x08
00007a44d59d7049  jmp 0x00007A44D59D6333
00007a44d59d704e  call 0x00007A44D58D64F0
00007a44d59d7053  jmp 0x00007A44D59D641F
00007a44d59d7058  sub rsp, 0x08
00007a44d59d705c  push rax
00007a44d59d705d  push rcx
00007a44d59d705e  push rdx
00007a44d59d705f  push rdi
00007a44d59d7060  push rsi
00007a44d59d7061  push r8
00007a44d59d7063  push r9
00007a44d59d7065  push r10
00007a44d59d7067  push r11
00007a44d59d7069  sub rsp, 0xF0
00007a44d59d7070  vmovaps [rsp], xmm0
00007a44d59d7075  vmovaps [rsp+0x10], xmm1
00007a44d59d707b  vmovaps [rsp+0x20], xmm2
00007a44d59d7081  vmovaps [rsp+0x30], xmm3
00007a44d59d7087  vmovaps [rsp+0x40], xmm4
00007a44d59d708d  vmovaps [rsp+0x50], xmm5
00007a44d59d7093  vmovaps [rsp+0x60], xmm6
00007a44d59d7099  vmovaps [rsp+0x70], xmm7
00007a44d59d709f  vmovaps [rsp+0x80], xmm8
00007a44d59d70a8  vmovaps [rsp+0x90], xmm9
00007a44d59d70b1  vmovaps [rsp+0xA0], xmm10
00007a44d59d70ba  vmovaps [rsp+0xB0], xmm11
00007a44d59d70c3  vmovaps [rsp+0xC0], xmm12
00007a44d59d70cc  vmovaps [rsp+0xD0], xmm14
00007a44d59d70d5  vmovaps [rsp+0xE0], xmm15
00007a44d59d70de  sub rsp, 0x40
00007a44d59d70e2  lea rdi, [rsp]
00007a44d59d70e6  lea rsi, [rsp+0x10]
00007a44d59d70eb  lea rdx, [rsp+0x20]
00007a44d59d70f0  lea rcx, [rsp+0x30]
00007a44d59d70f5  mov r8d, 0x00
00007a44d59d70fb  lea r9, [r15+0x3A8]
00007a44d59d7102  movaps [rdi], xmm13
00007a44d59d7106  movaps [rsi], xmm1
00007a44d59d7109  movaps [rdx], xmm15
00007a44d59d710d  movaps [rcx], xmm14
00007a44d59d7111  mov rax, 0x56179A4B1A50
00007a44d59d711b  call rax
00007a44d59d711d  movaps xmm13, [rsp]
00007a44d59d7122  add rsp, 0x40
00007a44d59d7126  vmovaps xmm0, [rsp]
00007a44d59d712b  vmovaps xmm1, [rsp+0x10]
00007a44d59d7131  vmovaps xmm2, [rsp+0x20]
00007a44d59d7137  vmovaps xmm3, [rsp+0x30]
00007a44d59d713d  vmovaps xmm4, [rsp+0x40]
00007a44d59d7143  vmovaps xmm5, [rsp+0x50]
00007a44d59d7149  vmovaps xmm6, [rsp+0x60]
00007a44d59d714f  vmovaps xmm7, [rsp+0x70]
00007a44d59d7155  vmovaps xmm8, [rsp+0x80]
00007a44d59d715e  vmovaps xmm9, [rsp+0x90]
00007a44d59d7167  vmovaps xmm10, [rsp+0xA0]
00007a44d59d7170  vmovaps xmm11, [rsp+0xB0]
00007a44d59d7179  vmovaps xmm12, [rsp+0xC0]
00007a44d59d7182  vmovaps xmm14, [rsp+0xD0]
00007a44d59d718b  vmovaps xmm15, [rsp+0xE0]
00007a44d59d7194  add rsp, 0xF0
00007a44d59d719b  pop r11
00007a44d59d719d  pop r10
00007a44d59d719f  pop r9
00007a44d59d71a1  pop r8
00007a44d59d71a3  pop rsi
00007a44d59d71a4  pop rdi
00007a44d59d71a5  pop rdx
00007a44d59d71a6  pop rcx
00007a44d59d71a7  pop rax
00007a44d59d71a8  add rsp, 0x08
00007a44d59d71ac  jmp 0x00007A44D59D648E
00007a44d59d71b1  call 0x00007A44D58D64F0
00007a44d59d71b6  jmp 0x00007A44D59D64A3
00007a44d59d71bb  sub rsp, 0x08
00007a44d59d71bf  push rax
00007a44d59d71c0  push rcx
00007a44d59d71c1  push rdx
00007a44d59d71c2  push rdi
00007a44d59d71c3  push rsi
00007a44d59d71c4  push r8
00007a44d59d71c6  push r9
00007a44d59d71c8  push r10
00007a44d59d71ca  push r11
00007a44d59d71cc  sub rsp, 0xF0
00007a44d59d71d3  vmovaps [rsp], xmm0
00007a44d59d71d8  vmovaps [rsp+0x10], xmm1
00007a44d59d71de  vmovaps [rsp+0x20], xmm2
00007a44d59d71e4  vmovaps [rsp+0x30], xmm3
00007a44d59d71ea  vmovaps [rsp+0x40], xmm4
00007a44d59d71f0  vmovaps [rsp+0x50], xmm5
00007a44d59d71f6  vmovaps [rsp+0x60], xmm6
00007a44d59d71fc  vmovaps [rsp+0x70], xmm7
00007a44d59d7202  vmovaps [rsp+0x80], xmm8
00007a44d59d720b  vmovaps [rsp+0x90], xmm9
00007a44d59d7214  vmovaps [rsp+0xA0], xmm10
00007a44d59d721d  vmovaps [rsp+0xB0], xmm11
00007a44d59d7226  vmovaps [rsp+0xC0], xmm13
00007a44d59d722f  vmovaps [rsp+0xD0], xmm14
00007a44d59d7238  vmovaps [rsp+0xE0], xmm15
00007a44d59d7241  sub rsp, 0x40
00007a44d59d7245  lea rdi, [rsp]
00007a44d59d7249  lea rsi, [rsp+0x10]
00007a44d59d724e  lea rdx, [rsp+0x20]
00007a44d59d7253  lea rcx, [rsp+0x30]
00007a44d59d7258  mov r8d, 0x00
00007a44d59d725e  lea r9, [r15+0x3A8]
00007a44d59d7265  movaps [rdi], xmm12
00007a44d59d7269  movaps [rsi], xmm15
00007a44d59d726d  movaps [rdx], xmm1
00007a44d59d7270  movaps [rcx], xmm14
00007a44d59d7274  mov rax, 0x56179A4B1A50
00007a44d59d727e  call rax
00007a44d59d7280  movaps xmm12, [rsp]
00007a44d59d7285  add rsp, 0x40
00007a44d59d7289  vmovaps xmm0, [rsp]
00007a44d59d728e  vmovaps xmm1, [rsp+0x10]
00007a44d59d7294  vmovaps xmm2, [rsp+0x20]
00007a44d59d729a  vmovaps xmm3, [rsp+0x30]
00007a44d59d72a0  vmovaps xmm4, [rsp+0x40]
00007a44d59d72a6  vmovaps xmm5, [rsp+0x50]
00007a44d59d72ac  vmovaps xmm6, [rsp+0x60]
00007a44d59d72b2  vmovaps xmm7, [rsp+0x70]
00007a44d59d72b8  vmovaps xmm8, [rsp+0x80]
00007a44d59d72c1  vmovaps xmm9, [rsp+0x90]
00007a44d59d72ca  vmovaps xmm10, [rsp+0xA0]
00007a44d59d72d3  vmovaps xmm11, [rsp+0xB0]
00007a44d59d72dc  vmovaps xmm13, [rsp+0xC0]
00007a44d59d72e5  vmovaps xmm14, [rsp+0xD0]
00007a44d59d72ee  vmovaps xmm15, [rsp+0xE0]
00007a44d59d72f7  add rsp, 0xF0
00007a44d59d72fe  pop r11
00007a44d59d7300  pop r10
00007a44d59d7302  pop r9
00007a44d59d7304  pop r8
00007a44d59d7306  pop rsi
00007a44d59d7307  pop rdi
00007a44d59d7308  pop rdx
00007a44d59d7309  pop rcx
00007a44d59d730a  pop rax
00007a44d59d730b  add rsp, 0x08
00007a44d59d730f  jmp 0x00007A44D59D64CF
00007a44d59d7314  sub rsp, 0x08
00007a44d59d7318  push rax
00007a44d59d7319  push rcx
00007a44d59d731a  push rdx
00007a44d59d731b  push rdi
00007a44d59d731c  push rsi
00007a44d59d731d  push r8
00007a44d59d731f  push r9
00007a44d59d7321  push r10
00007a44d59d7323  push r11
00007a44d59d7325  sub rsp, 0xF0
00007a44d59d732c  vmovaps [rsp], xmm0
00007a44d59d7331  vmovaps [rsp+0x10], xmm1
00007a44d59d7337  vmovaps [rsp+0x20], xmm2
00007a44d59d733d  vmovaps [rsp+0x30], xmm3
00007a44d59d7343  vmovaps [rsp+0x40], xmm4
00007a44d59d7349  vmovaps [rsp+0x50], xmm5
00007a44d59d734f  vmovaps [rsp+0x60], xmm6
00007a44d59d7355  vmovaps [rsp+0x70], xmm7
00007a44d59d735b  vmovaps [rsp+0x80], xmm8
00007a44d59d7364  vmovaps [rsp+0x90], xmm9
00007a44d59d736d  vmovaps [rsp+0xA0], xmm10
00007a44d59d7376  vmovaps [rsp+0xB0], xmm11
00007a44d59d737f  vmovaps [rsp+0xC0], xmm12
00007a44d59d7388  vmovaps [rsp+0xD0], xmm14
00007a44d59d7391  vmovaps [rsp+0xE0], xmm15
00007a44d59d739a  sub rsp, 0x40
00007a44d59d739e  lea rdi, [rsp]
00007a44d59d73a2  lea rsi, [rsp+0x10]
00007a44d59d73a7  lea rdx, [rsp+0x20]
00007a44d59d73ac  lea rcx, [rsp+0x30]
00007a44d59d73b1  mov r8d, 0x00
00007a44d59d73b7  lea r9, [r15+0x3A8]
00007a44d59d73be  movaps [rdi], xmm13
00007a44d59d73c2  movaps [rsi], xmm1
00007a44d59d73c5  movaps [rdx], xmm15
00007a44d59d73c9  movaps [rcx], xmm14
00007a44d59d73cd  mov rax, 0x56179A4B1A50
00007a44d59d73d7  call rax
00007a44d59d73d9  movaps xmm13, [rsp]
00007a44d59d73de  add rsp, 0x40
00007a44d59d73e2  vmovaps xmm0, [rsp]
00007a44d59d73e7  vmovaps xmm1, [rsp+0x10]
00007a44d59d73ed  vmovaps xmm2, [rsp+0x20]
00007a44d59d73f3  vmovaps xmm3, [rsp+0x30]
00007a44d59d73f9  vmovaps xmm4, [rsp+0x40]
00007a44d59d73ff  vmovaps xmm5, [rsp+0x50]
00007a44d59d7405  vmovaps xmm6, [rsp+0x60]
00007a44d59d740b  vmovaps xmm7, [rsp+0x70]
00007a44d59d7411  vmovaps xmm8, [rsp+0x80]
00007a44d59d741a  vmovaps xmm9, [rsp+0x90]
00007a44d59d7423  vmovaps xmm10, [rsp+0xA0]
00007a44d59d742c  vmovaps xmm11, [rsp+0xB0]
00007a44d59d7435  vmovaps xmm12, [rsp+0xC0]
00007a44d59d743e  vmovaps xmm14, [rsp+0xD0]
00007a44d59d7447  vmovaps xmm15, [rsp+0xE0]
00007a44d59d7450  add rsp, 0xF0
00007a44d59d7457  pop r11
00007a44d59d7459  pop r10
00007a44d59d745b  pop r9
00007a44d59d745d  pop r8
00007a44d59d745f  pop rsi
00007a44d59d7460  pop rdi
00007a44d59d7461  pop rdx
00007a44d59d7462  pop rcx
00007a44d59d7463  pop rax
00007a44d59d7464  add rsp, 0x08
00007a44d59d7468  jmp 0x00007A44D59D665F
00007a44d59d746d  sub rsp, 0x08
00007a44d59d7471  push rax
00007a44d59d7472  push rcx
00007a44d59d7473  push rdx
00007a44d59d7474  push rdi
00007a44d59d7475  push rsi
00007a44d59d7476  push r8
00007a44d59d7478  push r9
00007a44d59d747a  push r10
00007a44d59d747c  push r11
00007a44d59d747e  sub rsp, 0xF0
00007a44d59d7485  vmovaps [rsp], xmm0
00007a44d59d748a  vmovaps [rsp+0x10], xmm1
00007a44d59d7490  vmovaps [rsp+0x20], xmm2
00007a44d59d7496  vmovaps [rsp+0x30], xmm3
00007a44d59d749c  vmovaps [rsp+0x40], xmm4
00007a44d59d74a2  vmovaps [rsp+0x50], xmm5
00007a44d59d74a8  vmovaps [rsp+0x60], xmm6
00007a44d59d74ae  vmovaps [rsp+0x70], xmm7
00007a44d59d74b4  vmovaps [rsp+0x80], xmm8
00007a44d59d74bd  vmovaps [rsp+0x90], xmm9
00007a44d59d74c6  vmovaps [rsp+0xA0], xmm10
00007a44d59d74cf  vmovaps [rsp+0xB0], xmm11
00007a44d59d74d8  vmovaps [rsp+0xC0], xmm12
00007a44d59d74e1  vmovaps [rsp+0xD0], xmm13
00007a44d59d74ea  vmovaps [rsp+0xE0], xmm15
00007a44d59d74f3  sub rsp, 0x40
00007a44d59d74f7  lea rdi, [rsp]
00007a44d59d74fb  lea rsi, [rsp+0x10]
00007a44d59d7500  lea rdx, [rsp+0x20]
00007a44d59d7505  lea rcx, [rsp+0x30]
00007a44d59d750a  mov r8d, 0x00
00007a44d59d7510  lea r9, [r15+0x3A8]
00007a44d59d7517  movaps [rdi], xmm14
00007a44d59d751b  movaps [rsi], xmm15
00007a44d59d751f  movaps [rdx], xmm2
00007a44d59d7522  movaps [rcx], xmm1
00007a44d59d7525  mov rax, 0x56179A4B1A50
00007a44d59d752f  call rax
00007a44d59d7531  movaps xmm14, [rsp]
00007a44d59d7536  add rsp, 0x40
00007a44d59d753a  vmovaps xmm0, [rsp]
00007a44d59d753f  vmovaps xmm1, [rsp+0x10]
00007a44d59d7545  vmovaps xmm2, [rsp+0x20]
00007a44d59d754b  vmovaps xmm3, [rsp+0x30]
00007a44d59d7551  vmovaps xmm4, [rsp+0x40]
00007a44d59d7557  vmovaps xmm5, [rsp+0x50]
00007a44d59d755d  vmovaps xmm6, [rsp+0x60]
00007a44d59d7563  vmovaps xmm7, [rsp+0x70]
00007a44d59d7569  vmovaps xmm8, [rsp+0x80]
00007a44d59d7572  vmovaps xmm9, [rsp+0x90]
00007a44d59d757b  vmovaps xmm10, [rsp+0xA0]
00007a44d59d7584  vmovaps xmm11, [rsp+0xB0]
00007a44d59d758d  vmovaps xmm12, [rsp+0xC0]
00007a44d59d7596  vmovaps xmm13, [rsp+0xD0]
00007a44d59d759f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d75a8  add rsp, 0xF0
00007a44d59d75af  pop r11
00007a44d59d75b1  pop r10
00007a44d59d75b3  pop r9
00007a44d59d75b5  pop r8
00007a44d59d75b7  pop rsi
00007a44d59d75b8  pop rdi
00007a44d59d75b9  pop rdx
00007a44d59d75ba  pop rcx
00007a44d59d75bb  pop rax
00007a44d59d75bc  add rsp, 0x08
00007a44d59d75c0  jmp 0x00007A44D59D6691
00007a44d59d75c5  sub rsp, 0x08
00007a44d59d75c9  push rax
00007a44d59d75ca  push rcx
00007a44d59d75cb  push rdx
00007a44d59d75cc  push rdi
00007a44d59d75cd  push rsi
00007a44d59d75ce  push r8
00007a44d59d75d0  push r9
00007a44d59d75d2  push r10
00007a44d59d75d4  push r11
00007a44d59d75d6  sub rsp, 0xF0
00007a44d59d75dd  vmovaps [rsp], xmm0
00007a44d59d75e2  vmovaps [rsp+0x10], xmm1
00007a44d59d75e8  vmovaps [rsp+0x20], xmm3
00007a44d59d75ee  vmovaps [rsp+0x30], xmm4
00007a44d59d75f4  vmovaps [rsp+0x40], xmm5
00007a44d59d75fa  vmovaps [rsp+0x50], xmm6
00007a44d59d7600  vmovaps [rsp+0x60], xmm7
00007a44d59d7606  vmovaps [rsp+0x70], xmm8
00007a44d59d760c  vmovaps [rsp+0x80], xmm9
00007a44d59d7615  vmovaps [rsp+0x90], xmm10
00007a44d59d761e  vmovaps [rsp+0xA0], xmm11
00007a44d59d7627  vmovaps [rsp+0xB0], xmm12
00007a44d59d7630  vmovaps [rsp+0xC0], xmm13
00007a44d59d7639  vmovaps [rsp+0xD0], xmm14
00007a44d59d7642  vmovaps [rsp+0xE0], xmm15
00007a44d59d764b  sub rsp, 0x40
00007a44d59d764f  lea rdi, [rsp]
00007a44d59d7653  lea rsi, [rsp+0x10]
00007a44d59d7658  lea rdx, [rsp+0x20]
00007a44d59d765d  lea rcx, [rsp+0x30]
00007a44d59d7662  mov r8d, 0x00
00007a44d59d7668  lea r9, [r15+0x3A8]
00007a44d59d766f  movaps [rdi], xmm2
00007a44d59d7672  movaps [rsi], xmm15
00007a44d59d7676  movaps [rdx], xmm12
00007a44d59d767a  movaps [rcx], xmm1
00007a44d59d767d  mov rax, 0x56179A4B1A50
00007a44d59d7687  call rax
00007a44d59d7689  movaps xmm2, [rsp]
00007a44d59d768d  add rsp, 0x40
00007a44d59d7691  vmovaps xmm0, [rsp]
00007a44d59d7696  vmovaps xmm1, [rsp+0x10]
00007a44d59d769c  vmovaps xmm3, [rsp+0x20]
00007a44d59d76a2  vmovaps xmm4, [rsp+0x30]
00007a44d59d76a8  vmovaps xmm5, [rsp+0x40]
00007a44d59d76ae  vmovaps xmm6, [rsp+0x50]
00007a44d59d76b4  vmovaps xmm7, [rsp+0x60]
00007a44d59d76ba  vmovaps xmm8, [rsp+0x70]
00007a44d59d76c0  vmovaps xmm9, [rsp+0x80]
00007a44d59d76c9  vmovaps xmm10, [rsp+0x90]
00007a44d59d76d2  vmovaps xmm11, [rsp+0xA0]
00007a44d59d76db  vmovaps xmm12, [rsp+0xB0]
00007a44d59d76e4  vmovaps xmm13, [rsp+0xC0]
00007a44d59d76ed  vmovaps xmm14, [rsp+0xD0]
00007a44d59d76f6  vmovaps xmm15, [rsp+0xE0]
00007a44d59d76ff  add rsp, 0xF0
00007a44d59d7706  pop r11
00007a44d59d7708  pop r10
00007a44d59d770a  pop r9
00007a44d59d770c  pop r8
00007a44d59d770e  pop rsi
00007a44d59d770f  pop rdi
00007a44d59d7710  pop rdx
00007a44d59d7711  pop rcx
00007a44d59d7712  pop rax
00007a44d59d7713  add rsp, 0x08
00007a44d59d7717  jmp 0x00007A44D59D66CE
00007a44d59d771c  sub rsp, 0x08
00007a44d59d7720  push rax
00007a44d59d7721  push rcx
00007a44d59d7722  push rdx
00007a44d59d7723  push rdi
00007a44d59d7724  push rsi
00007a44d59d7725  push r8
00007a44d59d7727  push r9
00007a44d59d7729  push r10
00007a44d59d772b  push r11
00007a44d59d772d  sub rsp, 0xF0
00007a44d59d7734  vmovaps [rsp], xmm0
00007a44d59d7739  vmovaps [rsp+0x10], xmm1
00007a44d59d773f  vmovaps [rsp+0x20], xmm2
00007a44d59d7745  vmovaps [rsp+0x30], xmm3
00007a44d59d774b  vmovaps [rsp+0x40], xmm4
00007a44d59d7751  vmovaps [rsp+0x50], xmm5
00007a44d59d7757  vmovaps [rsp+0x60], xmm6
00007a44d59d775d  vmovaps [rsp+0x70], xmm7
00007a44d59d7763  vmovaps [rsp+0x80], xmm8
00007a44d59d776c  vmovaps [rsp+0x90], xmm9
00007a44d59d7775  vmovaps [rsp+0xA0], xmm10
00007a44d59d777e  vmovaps [rsp+0xB0], xmm11
00007a44d59d7787  vmovaps [rsp+0xC0], xmm13
00007a44d59d7790  vmovaps [rsp+0xD0], xmm14
00007a44d59d7799  vmovaps [rsp+0xE0], xmm15
00007a44d59d77a2  sub rsp, 0x40
00007a44d59d77a6  lea rdi, [rsp]
00007a44d59d77aa  lea rsi, [rsp+0x10]
00007a44d59d77af  lea rdx, [rsp+0x20]
00007a44d59d77b4  lea rcx, [rsp+0x30]
00007a44d59d77b9  mov r8d, 0x00
00007a44d59d77bf  lea r9, [r15+0x3A8]
00007a44d59d77c6  movaps [rdi], xmm12
00007a44d59d77ca  movaps [rsi], xmm14
00007a44d59d77ce  movaps [rdx], xmm3
00007a44d59d77d1  movaps [rcx], xmm15
00007a44d59d77d5  mov rax, 0x56179A4B1A50
00007a44d59d77df  call rax
00007a44d59d77e1  movaps xmm12, [rsp]
00007a44d59d77e6  add rsp, 0x40
00007a44d59d77ea  vmovaps xmm0, [rsp]
00007a44d59d77ef  vmovaps xmm1, [rsp+0x10]
00007a44d59d77f5  vmovaps xmm2, [rsp+0x20]
00007a44d59d77fb  vmovaps xmm3, [rsp+0x30]
00007a44d59d7801  vmovaps xmm4, [rsp+0x40]
00007a44d59d7807  vmovaps xmm5, [rsp+0x50]
00007a44d59d780d  vmovaps xmm6, [rsp+0x60]
00007a44d59d7813  vmovaps xmm7, [rsp+0x70]
00007a44d59d7819  vmovaps xmm8, [rsp+0x80]
00007a44d59d7822  vmovaps xmm9, [rsp+0x90]
00007a44d59d782b  vmovaps xmm10, [rsp+0xA0]
00007a44d59d7834  vmovaps xmm11, [rsp+0xB0]
00007a44d59d783d  vmovaps xmm13, [rsp+0xC0]
00007a44d59d7846  vmovaps xmm14, [rsp+0xD0]
00007a44d59d784f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d7858  add rsp, 0xF0
00007a44d59d785f  pop r11
00007a44d59d7861  pop r10
00007a44d59d7863  pop r9
00007a44d59d7865  pop r8
00007a44d59d7867  pop rsi
00007a44d59d7868  pop rdi
00007a44d59d7869  pop rdx
00007a44d59d786a  pop rcx
00007a44d59d786b  pop rax
00007a44d59d786c  add rsp, 0x08
00007a44d59d7870  jmp 0x00007A44D59D6728
00007a44d59d7875  sub rsp, 0x08
00007a44d59d7879  push rax
00007a44d59d787a  push rcx
00007a44d59d787b  push rdx
00007a44d59d787c  push rdi
00007a44d59d787d  push rsi
00007a44d59d787e  push r8
00007a44d59d7880  push r9
00007a44d59d7882  push r10
00007a44d59d7884  push r11
00007a44d59d7886  sub rsp, 0xF0
00007a44d59d788d  vmovaps [rsp], xmm0
00007a44d59d7892  vmovaps [rsp+0x10], xmm1
00007a44d59d7898  vmovaps [rsp+0x20], xmm2
00007a44d59d789e  vmovaps [rsp+0x30], xmm3
00007a44d59d78a4  vmovaps [rsp+0x40], xmm4
00007a44d59d78aa  vmovaps [rsp+0x50], xmm5
00007a44d59d78b0  vmovaps [rsp+0x60], xmm6
00007a44d59d78b6  vmovaps [rsp+0x70], xmm7
00007a44d59d78bc  vmovaps [rsp+0x80], xmm8
00007a44d59d78c5  vmovaps [rsp+0x90], xmm10
00007a44d59d78ce  vmovaps [rsp+0xA0], xmm11
00007a44d59d78d7  vmovaps [rsp+0xB0], xmm12
00007a44d59d78e0  vmovaps [rsp+0xC0], xmm13
00007a44d59d78e9  vmovaps [rsp+0xD0], xmm14
00007a44d59d78f2  vmovaps [rsp+0xE0], xmm15
00007a44d59d78fb  sub rsp, 0x40
00007a44d59d78ff  lea rdi, [rsp]
00007a44d59d7903  lea rsi, [rsp+0x10]
00007a44d59d7908  lea rdx, [rsp+0x20]
00007a44d59d790d  lea rcx, [rsp+0x30]
00007a44d59d7912  mov r8d, 0x00
00007a44d59d7918  lea r9, [r15+0x3A8]
00007a44d59d791f  movaps [rdi], xmm9
00007a44d59d7923  movaps [rsi], xmm13
00007a44d59d7927  movaps [rdx], xmm14
00007a44d59d792b  movaps [rcx], xmm6
00007a44d59d792e  mov rax, 0x56179A4B1A50
00007a44d59d7938  call rax
00007a44d59d793a  movaps xmm9, [rsp]
00007a44d59d793f  add rsp, 0x40
00007a44d59d7943  vmovaps xmm0, [rsp]
00007a44d59d7948  vmovaps xmm1, [rsp+0x10]
00007a44d59d794e  vmovaps xmm2, [rsp+0x20]
00007a44d59d7954  vmovaps xmm3, [rsp+0x30]
00007a44d59d795a  vmovaps xmm4, [rsp+0x40]
00007a44d59d7960  vmovaps xmm5, [rsp+0x50]
00007a44d59d7966  vmovaps xmm6, [rsp+0x60]
00007a44d59d796c  vmovaps xmm7, [rsp+0x70]
00007a44d59d7972  vmovaps xmm8, [rsp+0x80]
00007a44d59d797b  vmovaps xmm10, [rsp+0x90]
00007a44d59d7984  vmovaps xmm11, [rsp+0xA0]
00007a44d59d798d  vmovaps xmm12, [rsp+0xB0]
00007a44d59d7996  vmovaps xmm13, [rsp+0xC0]
00007a44d59d799f  vmovaps xmm14, [rsp+0xD0]
00007a44d59d79a8  vmovaps xmm15, [rsp+0xE0]
00007a44d59d79b1  add rsp, 0xF0
00007a44d59d79b8  pop r11
00007a44d59d79ba  pop r10
00007a44d59d79bc  pop r9
00007a44d59d79be  pop r8
00007a44d59d79c0  pop rsi
00007a44d59d79c1  pop rdi
00007a44d59d79c2  pop rdx
00007a44d59d79c3  pop rcx
00007a44d59d79c4  pop rax
00007a44d59d79c5  add rsp, 0x08
00007a44d59d79c9  jmp 0x00007A44D59D67D2
00007a44d59d79ce  sub rsp, 0x08
00007a44d59d79d2  push rax
00007a44d59d79d3  push rcx
00007a44d59d79d4  push rdx
00007a44d59d79d5  push rdi
00007a44d59d79d6  push rsi
00007a44d59d79d7  push r8
00007a44d59d79d9  push r9
00007a44d59d79db  push r10
00007a44d59d79dd  push r11
00007a44d59d79df  sub rsp, 0xF0
00007a44d59d79e6  vmovaps [rsp], xmm0
00007a44d59d79eb  vmovaps [rsp+0x10], xmm1
00007a44d59d79f1  vmovaps [rsp+0x20], xmm2
00007a44d59d79f7  vmovaps [rsp+0x30], xmm4
00007a44d59d79fd  vmovaps [rsp+0x40], xmm5
00007a44d59d7a03  vmovaps [rsp+0x50], xmm6
00007a44d59d7a09  vmovaps [rsp+0x60], xmm7
00007a44d59d7a0f  vmovaps [rsp+0x70], xmm8
00007a44d59d7a15  vmovaps [rsp+0x80], xmm9
00007a44d59d7a1e  vmovaps [rsp+0x90], xmm10
00007a44d59d7a27  vmovaps [rsp+0xA0], xmm11
00007a44d59d7a30  vmovaps [rsp+0xB0], xmm12
00007a44d59d7a39  vmovaps [rsp+0xC0], xmm13
00007a44d59d7a42  vmovaps [rsp+0xD0], xmm14
00007a44d59d7a4b  vmovaps [rsp+0xE0], xmm15
00007a44d59d7a54  sub rsp, 0x40
00007a44d59d7a58  lea rdi, [rsp]
00007a44d59d7a5c  lea rsi, [rsp+0x10]
00007a44d59d7a61  lea rdx, [rsp+0x20]
00007a44d59d7a66  lea rcx, [rsp+0x30]
00007a44d59d7a6b  mov r8d, 0x00
00007a44d59d7a71  lea r9, [r15+0x3A8]
00007a44d59d7a78  movaps [rdi], xmm3
00007a44d59d7a7b  movaps [rsi], xmm13
00007a44d59d7a7f  movaps [rdx], xmm6
00007a44d59d7a82  movaps [rcx], xmm14
00007a44d59d7a86  mov rax, 0x56179A4B1A50
00007a44d59d7a90  call rax
00007a44d59d7a92  movaps xmm3, [rsp]
00007a44d59d7a96  add rsp, 0x40
00007a44d59d7a9a  vmovaps xmm0, [rsp]
00007a44d59d7a9f  vmovaps xmm1, [rsp+0x10]
00007a44d59d7aa5  vmovaps xmm2, [rsp+0x20]
00007a44d59d7aab  vmovaps xmm4, [rsp+0x30]
00007a44d59d7ab1  vmovaps xmm5, [rsp+0x40]
00007a44d59d7ab7  vmovaps xmm6, [rsp+0x50]
00007a44d59d7abd  vmovaps xmm7, [rsp+0x60]
00007a44d59d7ac3  vmovaps xmm8, [rsp+0x70]
00007a44d59d7ac9  vmovaps xmm9, [rsp+0x80]
00007a44d59d7ad2  vmovaps xmm10, [rsp+0x90]
00007a44d59d7adb  vmovaps xmm11, [rsp+0xA0]
00007a44d59d7ae4  vmovaps xmm12, [rsp+0xB0]
00007a44d59d7aed  vmovaps xmm13, [rsp+0xC0]
00007a44d59d7af6  vmovaps xmm14, [rsp+0xD0]
00007a44d59d7aff  vmovaps xmm15, [rsp+0xE0]
00007a44d59d7b08  add rsp, 0xF0
00007a44d59d7b0f  pop r11
00007a44d59d7b11  pop r10
00007a44d59d7b13  pop r9
00007a44d59d7b15  pop r8
00007a44d59d7b17  pop rsi
00007a44d59d7b18  pop rdi
00007a44d59d7b19  pop rdx
00007a44d59d7b1a  pop rcx
00007a44d59d7b1b  pop rax
00007a44d59d7b1c  add rsp, 0x08
00007a44d59d7b20  jmp 0x00007A44D59D680F
00007a44d59d7b25  sub rsp, 0x08
00007a44d59d7b29  push rax
00007a44d59d7b2a  push rcx
00007a44d59d7b2b  push rdx
00007a44d59d7b2c  push rdi
00007a44d59d7b2d  push rsi
00007a44d59d7b2e  push r8
00007a44d59d7b30  push r9
00007a44d59d7b32  push r10
00007a44d59d7b34  push r11
00007a44d59d7b36  sub rsp, 0xF0
00007a44d59d7b3d  vmovaps [rsp], xmm0
00007a44d59d7b42  vmovaps [rsp+0x10], xmm1
00007a44d59d7b48  vmovaps [rsp+0x20], xmm2
00007a44d59d7b4e  vmovaps [rsp+0x30], xmm3
00007a44d59d7b54  vmovaps [rsp+0x40], xmm4
00007a44d59d7b5a  vmovaps [rsp+0x50], xmm5
00007a44d59d7b60  vmovaps [rsp+0x60], xmm7
00007a44d59d7b66  vmovaps [rsp+0x70], xmm8
00007a44d59d7b6c  vmovaps [rsp+0x80], xmm9
00007a44d59d7b75  vmovaps [rsp+0x90], xmm10
00007a44d59d7b7e  vmovaps [rsp+0xA0], xmm11
00007a44d59d7b87  vmovaps [rsp+0xB0], xmm12
00007a44d59d7b90  vmovaps [rsp+0xC0], xmm13
00007a44d59d7b99  vmovaps [rsp+0xD0], xmm14
00007a44d59d7ba2  vmovaps [rsp+0xE0], xmm15
00007a44d59d7bab  sub rsp, 0x40
00007a44d59d7baf  lea rdi, [rsp]
00007a44d59d7bb3  lea rsi, [rsp+0x10]
00007a44d59d7bb8  lea rdx, [rsp+0x20]
00007a44d59d7bbd  lea rcx, [rsp+0x30]
00007a44d59d7bc2  mov r8d, 0x00
00007a44d59d7bc8  lea r9, [r15+0x3A8]
00007a44d59d7bcf  movaps [rdi], xmm6
00007a44d59d7bd2  movaps [rsi], xmm2
00007a44d59d7bd5  movaps [rdx], xmm14
00007a44d59d7bd9  movaps [rcx], xmm1
00007a44d59d7bdc  mov rax, 0x56179A4B1A50
00007a44d59d7be6  call rax
00007a44d59d7be8  movaps xmm6, [rsp]
00007a44d59d7bec  add rsp, 0x40
00007a44d59d7bf0  vmovaps xmm0, [rsp]
00007a44d59d7bf5  vmovaps xmm1, [rsp+0x10]
00007a44d59d7bfb  vmovaps xmm2, [rsp+0x20]
00007a44d59d7c01  vmovaps xmm3, [rsp+0x30]
00007a44d59d7c07  vmovaps xmm4, [rsp+0x40]
00007a44d59d7c0d  vmovaps xmm5, [rsp+0x50]
00007a44d59d7c13  vmovaps xmm7, [rsp+0x60]
00007a44d59d7c19  vmovaps xmm8, [rsp+0x70]
00007a44d59d7c1f  vmovaps xmm9, [rsp+0x80]
00007a44d59d7c28  vmovaps xmm10, [rsp+0x90]
00007a44d59d7c31  vmovaps xmm11, [rsp+0xA0]
00007a44d59d7c3a  vmovaps xmm12, [rsp+0xB0]
00007a44d59d7c43  vmovaps xmm13, [rsp+0xC0]
00007a44d59d7c4c  vmovaps xmm14, [rsp+0xD0]
00007a44d59d7c55  vmovaps xmm15, [rsp+0xE0]
00007a44d59d7c5e  add rsp, 0xF0
00007a44d59d7c65  pop r11
00007a44d59d7c67  pop r10
00007a44d59d7c69  pop r9
00007a44d59d7c6b  pop r8
00007a44d59d7c6d  pop rsi
00007a44d59d7c6e  pop rdi
00007a44d59d7c6f  pop rdx
00007a44d59d7c70  pop rcx
00007a44d59d7c71  pop rax
00007a44d59d7c72  add rsp, 0x08
00007a44d59d7c76  jmp 0x00007A44D59D683C
00007a44d59d7c7b  sub rsp, 0x08
00007a44d59d7c7f  push rax
00007a44d59d7c80  push rcx
00007a44d59d7c81  push rdx
00007a44d59d7c82  push rdi
00007a44d59d7c83  push rsi
00007a44d59d7c84  push r8
00007a44d59d7c86  push r9
00007a44d59d7c88  push r10
00007a44d59d7c8a  push r11
00007a44d59d7c8c  sub rsp, 0xF0
00007a44d59d7c93  vmovaps [rsp], xmm0
00007a44d59d7c98  vmovaps [rsp+0x10], xmm1
00007a44d59d7c9e  vmovaps [rsp+0x20], xmm2
00007a44d59d7ca4  vmovaps [rsp+0x30], xmm3
00007a44d59d7caa  vmovaps [rsp+0x40], xmm4
00007a44d59d7cb0  vmovaps [rsp+0x50], xmm5
00007a44d59d7cb6  vmovaps [rsp+0x60], xmm6
00007a44d59d7cbc  vmovaps [rsp+0x70], xmm7
00007a44d59d7cc2  vmovaps [rsp+0x80], xmm8
00007a44d59d7ccb  vmovaps [rsp+0x90], xmm9
00007a44d59d7cd4  vmovaps [rsp+0xA0], xmm10
00007a44d59d7cdd  vmovaps [rsp+0xB0], xmm11
00007a44d59d7ce6  vmovaps [rsp+0xC0], xmm12
00007a44d59d7cef  vmovaps [rsp+0xD0], xmm14
00007a44d59d7cf8  vmovaps [rsp+0xE0], xmm15
00007a44d59d7d01  sub rsp, 0x40
00007a44d59d7d05  lea rdi, [rsp]
00007a44d59d7d09  lea rsi, [rsp+0x10]
00007a44d59d7d0e  lea rdx, [rsp+0x20]
00007a44d59d7d13  lea rcx, [rsp+0x30]
00007a44d59d7d18  mov r8d, 0x00
00007a44d59d7d1e  lea r9, [r15+0x3A8]
00007a44d59d7d25  movaps [rdi], xmm13
00007a44d59d7d29  movaps [rsi], xmm12
00007a44d59d7d2d  movaps [rdx], xmm14
00007a44d59d7d31  movaps [rcx], xmm1
00007a44d59d7d34  mov rax, 0x56179A4B1A50
00007a44d59d7d3e  call rax
00007a44d59d7d40  movaps xmm13, [rsp]
00007a44d59d7d45  add rsp, 0x40
00007a44d59d7d49  vmovaps xmm0, [rsp]
00007a44d59d7d4e  vmovaps xmm1, [rsp+0x10]
00007a44d59d7d54  vmovaps xmm2, [rsp+0x20]
00007a44d59d7d5a  vmovaps xmm3, [rsp+0x30]
00007a44d59d7d60  vmovaps xmm4, [rsp+0x40]
00007a44d59d7d66  vmovaps xmm5, [rsp+0x50]
00007a44d59d7d6c  vmovaps xmm6, [rsp+0x60]
00007a44d59d7d72  vmovaps xmm7, [rsp+0x70]
00007a44d59d7d78  vmovaps xmm8, [rsp+0x80]
00007a44d59d7d81  vmovaps xmm9, [rsp+0x90]
00007a44d59d7d8a  vmovaps xmm10, [rsp+0xA0]
00007a44d59d7d93  vmovaps xmm11, [rsp+0xB0]
00007a44d59d7d9c  vmovaps xmm12, [rsp+0xC0]
00007a44d59d7da5  vmovaps xmm14, [rsp+0xD0]
00007a44d59d7dae  vmovaps xmm15, [rsp+0xE0]
00007a44d59d7db7  add rsp, 0xF0
00007a44d59d7dbe  pop r11
00007a44d59d7dc0  pop r10
00007a44d59d7dc2  pop r9
00007a44d59d7dc4  pop r8
00007a44d59d7dc6  pop rsi
00007a44d59d7dc7  pop rdi
00007a44d59d7dc8  pop rdx
00007a44d59d7dc9  pop rcx
00007a44d59d7dca  pop rax
00007a44d59d7dcb  add rsp, 0x08
00007a44d59d7dcf  jmp 0x00007A44D59D686E
00007a44d59d7dd4  sub rsp, 0x08
00007a44d59d7dd8  push rax
00007a44d59d7dd9  push rcx
00007a44d59d7dda  push rdx
00007a44d59d7ddb  push rdi
00007a44d59d7ddc  push rsi
00007a44d59d7ddd  push r8
00007a44d59d7ddf  push r9
00007a44d59d7de1  push r10
00007a44d59d7de3  push r11
00007a44d59d7de5  sub rsp, 0xF0
00007a44d59d7dec  vmovaps [rsp], xmm0
00007a44d59d7df1  vmovaps [rsp+0x10], xmm1
00007a44d59d7df7  vmovaps [rsp+0x20], xmm2
00007a44d59d7dfd  vmovaps [rsp+0x30], xmm3
00007a44d59d7e03  vmovaps [rsp+0x40], xmm4
00007a44d59d7e09  vmovaps [rsp+0x50], xmm5
00007a44d59d7e0f  vmovaps [rsp+0x60], xmm6
00007a44d59d7e15  vmovaps [rsp+0x70], xmm7
00007a44d59d7e1b  vmovaps [rsp+0x80], xmm8
00007a44d59d7e24  vmovaps [rsp+0x90], xmm9
00007a44d59d7e2d  vmovaps [rsp+0xA0], xmm10
00007a44d59d7e36  vmovaps [rsp+0xB0], xmm11
00007a44d59d7e3f  vmovaps [rsp+0xC0], xmm13
00007a44d59d7e48  vmovaps [rsp+0xD0], xmm14
00007a44d59d7e51  vmovaps [rsp+0xE0], xmm15
00007a44d59d7e5a  sub rsp, 0x40
00007a44d59d7e5e  lea rdi, [rsp]
00007a44d59d7e62  lea rsi, [rsp+0x10]
00007a44d59d7e67  lea rdx, [rsp+0x20]
00007a44d59d7e6c  lea rcx, [rsp+0x30]
00007a44d59d7e71  mov r8d, 0x00
00007a44d59d7e77  lea r9, [r15+0x3A8]
00007a44d59d7e7e  movaps [rdi], xmm12
00007a44d59d7e82  movaps [rsi], xmm3
00007a44d59d7e85  movaps [rdx], xmm14
00007a44d59d7e89  movaps [rcx], xmm5
00007a44d59d7e8c  mov rax, 0x56179A4B1A50
00007a44d59d7e96  call rax
00007a44d59d7e98  movaps xmm12, [rsp]
00007a44d59d7e9d  add rsp, 0x40
00007a44d59d7ea1  vmovaps xmm0, [rsp]
00007a44d59d7ea6  vmovaps xmm1, [rsp+0x10]
00007a44d59d7eac  vmovaps xmm2, [rsp+0x20]
00007a44d59d7eb2  vmovaps xmm3, [rsp+0x30]
00007a44d59d7eb8  vmovaps xmm4, [rsp+0x40]
00007a44d59d7ebe  vmovaps xmm5, [rsp+0x50]
00007a44d59d7ec4  vmovaps xmm6, [rsp+0x60]
00007a44d59d7eca  vmovaps xmm7, [rsp+0x70]
00007a44d59d7ed0  vmovaps xmm8, [rsp+0x80]
00007a44d59d7ed9  vmovaps xmm9, [rsp+0x90]
00007a44d59d7ee2  vmovaps xmm10, [rsp+0xA0]
00007a44d59d7eeb  vmovaps xmm11, [rsp+0xB0]
00007a44d59d7ef4  vmovaps xmm13, [rsp+0xC0]
00007a44d59d7efd  vmovaps xmm14, [rsp+0xD0]
00007a44d59d7f06  vmovaps xmm15, [rsp+0xE0]
00007a44d59d7f0f  add rsp, 0xF0
00007a44d59d7f16  pop r11
00007a44d59d7f18  pop r10
00007a44d59d7f1a  pop r9
00007a44d59d7f1c  pop r8
00007a44d59d7f1e  pop rsi
00007a44d59d7f1f  pop rdi
00007a44d59d7f20  pop rdx
00007a44d59d7f21  pop rcx
00007a44d59d7f22  pop rax
00007a44d59d7f23  add rsp, 0x08
00007a44d59d7f27  jmp 0x00007A44D59D68CB
00007a44d59d7f2c  sub rsp, 0x08
00007a44d59d7f30  push rax
00007a44d59d7f31  push rcx
00007a44d59d7f32  push rdx
00007a44d59d7f33  push rdi
00007a44d59d7f34  push rsi
00007a44d59d7f35  push r8
00007a44d59d7f37  push r9
00007a44d59d7f39  push r10
00007a44d59d7f3b  push r11
00007a44d59d7f3d  sub rsp, 0xF0
00007a44d59d7f44  vmovaps [rsp], xmm0
00007a44d59d7f49  vmovaps [rsp+0x10], xmm1
00007a44d59d7f4f  vmovaps [rsp+0x20], xmm2
00007a44d59d7f55  vmovaps [rsp+0x30], xmm3
00007a44d59d7f5b  vmovaps [rsp+0x40], xmm4
00007a44d59d7f61  vmovaps [rsp+0x50], xmm5
00007a44d59d7f67  vmovaps [rsp+0x60], xmm6
00007a44d59d7f6d  vmovaps [rsp+0x70], xmm7
00007a44d59d7f73  vmovaps [rsp+0x80], xmm8
00007a44d59d7f7c  vmovaps [rsp+0x90], xmm9
00007a44d59d7f85  vmovaps [rsp+0xA0], xmm11
00007a44d59d7f8e  vmovaps [rsp+0xB0], xmm12
00007a44d59d7f97  vmovaps [rsp+0xC0], xmm13
00007a44d59d7fa0  vmovaps [rsp+0xD0], xmm14
00007a44d59d7fa9  vmovaps [rsp+0xE0], xmm15
00007a44d59d7fb2  sub rsp, 0x40
00007a44d59d7fb6  lea rdi, [rsp]
00007a44d59d7fba  lea rsi, [rsp+0x10]
00007a44d59d7fbf  lea rdx, [rsp+0x20]
00007a44d59d7fc4  lea rcx, [rsp+0x30]
00007a44d59d7fc9  mov r8d, 0x00
00007a44d59d7fcf  lea r9, [r15+0x3A8]
00007a44d59d7fd6  movaps [rdi], xmm10
00007a44d59d7fda  movaps [rsi], xmm9
00007a44d59d7fde  movaps [rdx], xmm7
00007a44d59d7fe1  movaps [rcx], xmm14
00007a44d59d7fe5  mov rax, 0x56179A4B1A50
00007a44d59d7fef  call rax
00007a44d59d7ff1  movaps xmm10, [rsp]
00007a44d59d7ff6  add rsp, 0x40
00007a44d59d7ffa  vmovaps xmm0, [rsp]
00007a44d59d7fff  vmovaps xmm1, [rsp+0x10]
00007a44d59d8005  vmovaps xmm2, [rsp+0x20]
00007a44d59d800b  vmovaps xmm3, [rsp+0x30]
00007a44d59d8011  vmovaps xmm4, [rsp+0x40]
00007a44d59d8017  vmovaps xmm5, [rsp+0x50]
00007a44d59d801d  vmovaps xmm6, [rsp+0x60]
00007a44d59d8023  vmovaps xmm7, [rsp+0x70]
00007a44d59d8029  vmovaps xmm8, [rsp+0x80]
00007a44d59d8032  vmovaps xmm9, [rsp+0x90]
00007a44d59d803b  vmovaps xmm11, [rsp+0xA0]
00007a44d59d8044  vmovaps xmm12, [rsp+0xB0]
00007a44d59d804d  vmovaps xmm13, [rsp+0xC0]
00007a44d59d8056  vmovaps xmm14, [rsp+0xD0]
00007a44d59d805f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d8068  add rsp, 0xF0
00007a44d59d806f  pop r11
00007a44d59d8071  pop r10
00007a44d59d8073  pop r9
00007a44d59d8075  pop r8
00007a44d59d8077  pop rsi
00007a44d59d8078  pop rdi
00007a44d59d8079  pop rdx
00007a44d59d807a  pop rcx
00007a44d59d807b  pop rax
00007a44d59d807c  add rsp, 0x08
00007a44d59d8080  jmp 0x00007A44D59D68F1
00007a44d59d8085  call 0x00007A44D58E45A0
00007a44d59d808a  jmp 0x00007A44D59D68FE
00007a44d59d808f  sub rsp, 0x08
00007a44d59d8093  push rax
00007a44d59d8094  push rcx
00007a44d59d8095  push rdx
00007a44d59d8096  push rdi
00007a44d59d8097  push rsi
00007a44d59d8098  push r8
00007a44d59d809a  push r9
00007a44d59d809c  push r10
00007a44d59d809e  push r11
00007a44d59d80a0  sub rsp, 0xF0
00007a44d59d80a7  vmovaps [rsp], xmm0
00007a44d59d80ac  vmovaps [rsp+0x10], xmm1
00007a44d59d80b2  vmovaps [rsp+0x20], xmm2
00007a44d59d80b8  vmovaps [rsp+0x30], xmm3
00007a44d59d80be  vmovaps [rsp+0x40], xmm4
00007a44d59d80c4  vmovaps [rsp+0x50], xmm6
00007a44d59d80ca  vmovaps [rsp+0x60], xmm7
00007a44d59d80d0  vmovaps [rsp+0x70], xmm8
00007a44d59d80d6  vmovaps [rsp+0x80], xmm9
00007a44d59d80df  vmovaps [rsp+0x90], xmm10
00007a44d59d80e8  vmovaps [rsp+0xA0], xmm11
00007a44d59d80f1  vmovaps [rsp+0xB0], xmm12
00007a44d59d80fa  vmovaps [rsp+0xC0], xmm13
00007a44d59d8103  vmovaps [rsp+0xD0], xmm14
00007a44d59d810c  vmovaps [rsp+0xE0], xmm15
00007a44d59d8115  sub rsp, 0x40
00007a44d59d8119  lea rdi, [rsp]
00007a44d59d811d  lea rsi, [rsp+0x10]
00007a44d59d8122  lea rdx, [rsp+0x20]
00007a44d59d8127  lea rcx, [rsp+0x30]
00007a44d59d812c  mov r8d, 0x00
00007a44d59d8132  lea r9, [r15+0x3A8]
00007a44d59d8139  movaps [rdi], xmm5
00007a44d59d813c  movaps [rsi], xmm6
00007a44d59d813f  movaps [rdx], xmm7
00007a44d59d8142  movaps [rcx], xmm9
00007a44d59d8146  mov rax, 0x56179A4B1A50
00007a44d59d8150  call rax
00007a44d59d8152  movaps xmm5, [rsp]
00007a44d59d8156  add rsp, 0x40
00007a44d59d815a  vmovaps xmm0, [rsp]
00007a44d59d815f  vmovaps xmm1, [rsp+0x10]
00007a44d59d8165  vmovaps xmm2, [rsp+0x20]
00007a44d59d816b  vmovaps xmm3, [rsp+0x30]
00007a44d59d8171  vmovaps xmm4, [rsp+0x40]
00007a44d59d8177  vmovaps xmm6, [rsp+0x50]
00007a44d59d817d  vmovaps xmm7, [rsp+0x60]
00007a44d59d8183  vmovaps xmm8, [rsp+0x70]
00007a44d59d8189  vmovaps xmm9, [rsp+0x80]
00007a44d59d8192  vmovaps xmm10, [rsp+0x90]
00007a44d59d819b  vmovaps xmm11, [rsp+0xA0]
00007a44d59d81a4  vmovaps xmm12, [rsp+0xB0]
00007a44d59d81ad  vmovaps xmm13, [rsp+0xC0]
00007a44d59d81b6  vmovaps xmm14, [rsp+0xD0]
00007a44d59d81bf  vmovaps xmm15, [rsp+0xE0]
00007a44d59d81c8  add rsp, 0xF0
00007a44d59d81cf  pop r11
00007a44d59d81d1  pop r10
00007a44d59d81d3  pop r9
00007a44d59d81d5  pop r8
00007a44d59d81d7  pop rsi
00007a44d59d81d8  pop rdi
00007a44d59d81d9  pop rdx
00007a44d59d81da  pop rcx
00007a44d59d81db  pop rax
00007a44d59d81dc  add rsp, 0x08
00007a44d59d81e0  jmp 0x00007A44D59D6930
00007a44d59d81e5  sub rsp, 0x08
00007a44d59d81e9  push rax
00007a44d59d81ea  push rcx
00007a44d59d81eb  push rdx
00007a44d59d81ec  push rdi
00007a44d59d81ed  push rsi
00007a44d59d81ee  push r8
00007a44d59d81f0  push r9
00007a44d59d81f2  push r10
00007a44d59d81f4  push r11
00007a44d59d81f6  sub rsp, 0xF0
00007a44d59d81fd  vmovaps [rsp], xmm0
00007a44d59d8202  vmovaps [rsp+0x10], xmm1
00007a44d59d8208  vmovaps [rsp+0x20], xmm2
00007a44d59d820e  vmovaps [rsp+0x30], xmm3
00007a44d59d8214  vmovaps [rsp+0x40], xmm4
00007a44d59d821a  vmovaps [rsp+0x50], xmm5
00007a44d59d8220  vmovaps [rsp+0x60], xmm6
00007a44d59d8226  vmovaps [rsp+0x70], xmm8
00007a44d59d822c  vmovaps [rsp+0x80], xmm9
00007a44d59d8235  vmovaps [rsp+0x90], xmm10
00007a44d59d823e  vmovaps [rsp+0xA0], xmm11
00007a44d59d8247  vmovaps [rsp+0xB0], xmm12
00007a44d59d8250  vmovaps [rsp+0xC0], xmm13
00007a44d59d8259  vmovaps [rsp+0xD0], xmm14
00007a44d59d8262  vmovaps [rsp+0xE0], xmm15
00007a44d59d826b  sub rsp, 0x40
00007a44d59d826f  lea rdi, [rsp]
00007a44d59d8273  lea rsi, [rsp+0x10]
00007a44d59d8278  lea rdx, [rsp+0x20]
00007a44d59d827d  lea rcx, [rsp+0x30]
00007a44d59d8282  mov r8d, 0x00
00007a44d59d8288  lea r9, [r15+0x3A8]
00007a44d59d828f  movaps [rdi], xmm7
00007a44d59d8292  movaps [rsi], xmm13
00007a44d59d8296  movaps [rdx], xmm1
00007a44d59d8299  movaps [rcx], xmm9
00007a44d59d829d  mov rax, 0x56179A4B1A50
00007a44d59d82a7  call rax
00007a44d59d82a9  movaps xmm7, [rsp]
00007a44d59d82ad  add rsp, 0x40
00007a44d59d82b1  vmovaps xmm0, [rsp]
00007a44d59d82b6  vmovaps xmm1, [rsp+0x10]
00007a44d59d82bc  vmovaps xmm2, [rsp+0x20]
00007a44d59d82c2  vmovaps xmm3, [rsp+0x30]
00007a44d59d82c8  vmovaps xmm4, [rsp+0x40]
00007a44d59d82ce  vmovaps xmm5, [rsp+0x50]
00007a44d59d82d4  vmovaps xmm6, [rsp+0x60]
00007a44d59d82da  vmovaps xmm8, [rsp+0x70]
00007a44d59d82e0  vmovaps xmm9, [rsp+0x80]
00007a44d59d82e9  vmovaps xmm10, [rsp+0x90]
00007a44d59d82f2  vmovaps xmm11, [rsp+0xA0]
00007a44d59d82fb  vmovaps xmm12, [rsp+0xB0]
00007a44d59d8304  vmovaps xmm13, [rsp+0xC0]
00007a44d59d830d  vmovaps xmm14, [rsp+0xD0]
00007a44d59d8316  vmovaps xmm15, [rsp+0xE0]
00007a44d59d831f  add rsp, 0xF0
00007a44d59d8326  pop r11
00007a44d59d8328  pop r10
00007a44d59d832a  pop r9
00007a44d59d832c  pop r8
00007a44d59d832e  pop rsi
00007a44d59d832f  pop rdi
00007a44d59d8330  pop rdx
00007a44d59d8331  pop rcx
00007a44d59d8332  pop rax
00007a44d59d8333  add rsp, 0x08
00007a44d59d8337  jmp 0x00007A44D59D6955
00007a44d59d833c  call 0x00007A44D58E3320
00007a44d59d8341  jmp 0x00007A44D59D6978
00007a44d59d8346  call 0x00007A44D58DE950
00007a44d59d834b  jmp 0x00007A44D59D6982
00007a44d59d8350  sub rsp, 0x08
00007a44d59d8354  push rax
00007a44d59d8355  push rcx
00007a44d59d8356  push rdx
00007a44d59d8357  push rdi
00007a44d59d8358  push rsi
00007a44d59d8359  push r8
00007a44d59d835b  push r9
00007a44d59d835d  push r10
00007a44d59d835f  push r11
00007a44d59d8361  sub rsp, 0xF0
00007a44d59d8368  vmovaps [rsp], xmm0
00007a44d59d836d  vmovaps [rsp+0x10], xmm1
00007a44d59d8373  vmovaps [rsp+0x20], xmm3
00007a44d59d8379  vmovaps [rsp+0x30], xmm4
00007a44d59d837f  vmovaps [rsp+0x40], xmm5
00007a44d59d8385  vmovaps [rsp+0x50], xmm6
00007a44d59d838b  vmovaps [rsp+0x60], xmm7
00007a44d59d8391  vmovaps [rsp+0x70], xmm8
00007a44d59d8397  vmovaps [rsp+0x80], xmm9
00007a44d59d83a0  vmovaps [rsp+0x90], xmm10
00007a44d59d83a9  vmovaps [rsp+0xA0], xmm11
00007a44d59d83b2  vmovaps [rsp+0xB0], xmm12
00007a44d59d83bb  vmovaps [rsp+0xC0], xmm13
00007a44d59d83c4  vmovaps [rsp+0xD0], xmm14
00007a44d59d83cd  vmovaps [rsp+0xE0], xmm15
00007a44d59d83d6  sub rsp, 0x40
00007a44d59d83da  lea rdi, [rsp]
00007a44d59d83de  lea rsi, [rsp+0x10]
00007a44d59d83e3  lea rdx, [rsp+0x20]
00007a44d59d83e8  lea rcx, [rsp+0x30]
00007a44d59d83ed  mov r8d, 0x00
00007a44d59d83f3  lea r9, [r15+0x3A8]
00007a44d59d83fa  movaps [rdi], xmm2
00007a44d59d83fd  movaps [rsi], xmm12
00007a44d59d8401  movaps [rdx], xmm6
00007a44d59d8404  movaps [rcx], xmm3
00007a44d59d8407  mov rax, 0x56179A4B1A50
00007a44d59d8411  call rax
00007a44d59d8413  movaps xmm2, [rsp]
00007a44d59d8417  add rsp, 0x40
00007a44d59d841b  vmovaps xmm0, [rsp]
00007a44d59d8420  vmovaps xmm1, [rsp+0x10]
00007a44d59d8426  vmovaps xmm3, [rsp+0x20]
00007a44d59d842c  vmovaps xmm4, [rsp+0x30]
00007a44d59d8432  vmovaps xmm5, [rsp+0x40]
00007a44d59d8438  vmovaps xmm6, [rsp+0x50]
00007a44d59d843e  vmovaps xmm7, [rsp+0x60]
00007a44d59d8444  vmovaps xmm8, [rsp+0x70]
00007a44d59d844a  vmovaps xmm9, [rsp+0x80]
00007a44d59d8453  vmovaps xmm10, [rsp+0x90]
00007a44d59d845c  vmovaps xmm11, [rsp+0xA0]
00007a44d59d8465  vmovaps xmm12, [rsp+0xB0]
00007a44d59d846e  vmovaps xmm13, [rsp+0xC0]
00007a44d59d8477  vmovaps xmm14, [rsp+0xD0]
00007a44d59d8480  vmovaps xmm15, [rsp+0xE0]
00007a44d59d8489  add rsp, 0xF0
00007a44d59d8490  pop r11
00007a44d59d8492  pop r10
00007a44d59d8494  pop r9
00007a44d59d8496  pop r8
00007a44d59d8498  pop rsi
00007a44d59d8499  pop rdi
00007a44d59d849a  pop rdx
00007a44d59d849b  pop rcx
00007a44d59d849c  pop rax
00007a44d59d849d  add rsp, 0x08
00007a44d59d84a1  jmp 0x00007A44D59D69C8
00007a44d59d84a6  sub rsp, 0x08
00007a44d59d84aa  push rax
00007a44d59d84ab  push rcx
00007a44d59d84ac  push rdx
00007a44d59d84ad  push rdi
00007a44d59d84ae  push rsi
00007a44d59d84af  push r8
00007a44d59d84b1  push r9
00007a44d59d84b3  push r10
00007a44d59d84b5  push r11
00007a44d59d84b7  sub rsp, 0xF0
00007a44d59d84be  vmovaps [rsp], xmm0
00007a44d59d84c3  vmovaps [rsp+0x10], xmm1
00007a44d59d84c9  vmovaps [rsp+0x20], xmm2
00007a44d59d84cf  vmovaps [rsp+0x30], xmm3
00007a44d59d84d5  vmovaps [rsp+0x40], xmm4
00007a44d59d84db  vmovaps [rsp+0x50], xmm5
00007a44d59d84e1  vmovaps [rsp+0x60], xmm7
00007a44d59d84e7  vmovaps [rsp+0x70], xmm8
00007a44d59d84ed  vmovaps [rsp+0x80], xmm9
00007a44d59d84f6  vmovaps [rsp+0x90], xmm10
00007a44d59d84ff  vmovaps [rsp+0xA0], xmm11
00007a44d59d8508  vmovaps [rsp+0xB0], xmm12
00007a44d59d8511  vmovaps [rsp+0xC0], xmm13
00007a44d59d851a  vmovaps [rsp+0xD0], xmm14
00007a44d59d8523  vmovaps [rsp+0xE0], xmm15
00007a44d59d852c  sub rsp, 0x40
00007a44d59d8530  lea rdi, [rsp]
00007a44d59d8534  lea rsi, [rsp+0x10]
00007a44d59d8539  lea rdx, [rsp+0x20]
00007a44d59d853e  lea rcx, [rsp+0x30]
00007a44d59d8543  mov r8d, 0x00
00007a44d59d8549  lea r9, [r15+0x3A8]
00007a44d59d8550  movaps [rdi], xmm6
00007a44d59d8553  movaps [rsi], xmm10
00007a44d59d8557  movaps [rdx], xmm12
00007a44d59d855b  movaps [rcx], xmm1
00007a44d59d855e  mov rax, 0x56179A4B1A50
00007a44d59d8568  call rax
00007a44d59d856a  movaps xmm6, [rsp]
00007a44d59d856e  add rsp, 0x40
00007a44d59d8572  vmovaps xmm0, [rsp]
00007a44d59d8577  vmovaps xmm1, [rsp+0x10]
00007a44d59d857d  vmovaps xmm2, [rsp+0x20]
00007a44d59d8583  vmovaps xmm3, [rsp+0x30]
00007a44d59d8589  vmovaps xmm4, [rsp+0x40]
00007a44d59d858f  vmovaps xmm5, [rsp+0x50]
00007a44d59d8595  vmovaps xmm7, [rsp+0x60]
00007a44d59d859b  vmovaps xmm8, [rsp+0x70]
00007a44d59d85a1  vmovaps xmm9, [rsp+0x80]
00007a44d59d85aa  vmovaps xmm10, [rsp+0x90]
00007a44d59d85b3  vmovaps xmm11, [rsp+0xA0]
00007a44d59d85bc  vmovaps xmm12, [rsp+0xB0]
00007a44d59d85c5  vmovaps xmm13, [rsp+0xC0]
00007a44d59d85ce  vmovaps xmm14, [rsp+0xD0]
00007a44d59d85d7  vmovaps xmm15, [rsp+0xE0]
00007a44d59d85e0  add rsp, 0xF0
00007a44d59d85e7  pop r11
00007a44d59d85e9  pop r10
00007a44d59d85eb  pop r9
00007a44d59d85ed  pop r8
00007a44d59d85ef  pop rsi
00007a44d59d85f0  pop rdi
00007a44d59d85f1  pop rdx
00007a44d59d85f2  pop rcx
00007a44d59d85f3  pop rax
00007a44d59d85f4  add rsp, 0x08
00007a44d59d85f8  jmp 0x00007A44D59D69F6
00007a44d59d85fd  sub rsp, 0x08
00007a44d59d8601  push rax
00007a44d59d8602  push rcx
00007a44d59d8603  push rdx
00007a44d59d8604  push rdi
00007a44d59d8605  push rsi
00007a44d59d8606  push r8
00007a44d59d8608  push r9
00007a44d59d860a  push r10
00007a44d59d860c  push r11
00007a44d59d860e  sub rsp, 0xF0
00007a44d59d8615  vmovaps [rsp], xmm0
00007a44d59d861a  vmovaps [rsp+0x10], xmm1
00007a44d59d8620  vmovaps [rsp+0x20], xmm2
00007a44d59d8626  vmovaps [rsp+0x30], xmm3
00007a44d59d862c  vmovaps [rsp+0x40], xmm4
00007a44d59d8632  vmovaps [rsp+0x50], xmm5
00007a44d59d8638  vmovaps [rsp+0x60], xmm6
00007a44d59d863e  vmovaps [rsp+0x70], xmm7
00007a44d59d8644  vmovaps [rsp+0x80], xmm8
00007a44d59d864d  vmovaps [rsp+0x90], xmm9
00007a44d59d8656  vmovaps [rsp+0xA0], xmm11
00007a44d59d865f  vmovaps [rsp+0xB0], xmm12
00007a44d59d8668  vmovaps [rsp+0xC0], xmm13
00007a44d59d8671  vmovaps [rsp+0xD0], xmm14
00007a44d59d867a  vmovaps [rsp+0xE0], xmm15
00007a44d59d8683  sub rsp, 0x40
00007a44d59d8687  lea rdi, [rsp]
00007a44d59d868b  lea rsi, [rsp+0x10]
00007a44d59d8690  lea rdx, [rsp+0x20]
00007a44d59d8695  lea rcx, [rsp+0x30]
00007a44d59d869a  mov r8d, 0x00
00007a44d59d86a0  lea r9, [r15+0x3A8]
00007a44d59d86a7  movaps [rdi], xmm10
00007a44d59d86ab  movaps [rsi], xmm5
00007a44d59d86ae  movaps [rdx], xmm12
00007a44d59d86b2  movaps [rcx], xmm1
00007a44d59d86b5  mov rax, 0x56179A4B1A50
00007a44d59d86bf  call rax
00007a44d59d86c1  movaps xmm10, [rsp]
00007a44d59d86c6  add rsp, 0x40
00007a44d59d86ca  vmovaps xmm0, [rsp]
00007a44d59d86cf  vmovaps xmm1, [rsp+0x10]
00007a44d59d86d5  vmovaps xmm2, [rsp+0x20]
00007a44d59d86db  vmovaps xmm3, [rsp+0x30]
00007a44d59d86e1  vmovaps xmm4, [rsp+0x40]
00007a44d59d86e7  vmovaps xmm5, [rsp+0x50]
00007a44d59d86ed  vmovaps xmm6, [rsp+0x60]
00007a44d59d86f3  vmovaps xmm7, [rsp+0x70]
00007a44d59d86f9  vmovaps xmm8, [rsp+0x80]
00007a44d59d8702  vmovaps xmm9, [rsp+0x90]
00007a44d59d870b  vmovaps xmm11, [rsp+0xA0]
00007a44d59d8714  vmovaps xmm12, [rsp+0xB0]
00007a44d59d871d  vmovaps xmm13, [rsp+0xC0]
00007a44d59d8726  vmovaps xmm14, [rsp+0xD0]
00007a44d59d872f  vmovaps xmm15, [rsp+0xE0]
00007a44d59d8738  add rsp, 0xF0
00007a44d59d873f  pop r11
00007a44d59d8741  pop r10
00007a44d59d8743  pop r9
00007a44d59d8745  pop r8
00007a44d59d8747  pop rsi
00007a44d59d8748  pop rdi
00007a44d59d8749  pop rdx
00007a44d59d874a  pop rcx
00007a44d59d874b  pop rax
00007a44d59d874c  add rsp, 0x08
00007a44d59d8750  jmp 0x00007A44D59D6A25
00007a44d59d8755  sub rsp, 0x08
00007a44d59d8759  push rax
00007a44d59d875a  push rcx
00007a44d59d875b  push rdx
00007a44d59d875c  push rdi
00007a44d59d875d  push rsi
00007a44d59d875e  push r8
00007a44d59d8760  push r9
00007a44d59d8762  push r10
00007a44d59d8764  push r11
00007a44d59d8766  sub rsp, 0xF0
00007a44d59d876d  vmovaps [rsp], xmm0
00007a44d59d8772  vmovaps [rsp+0x10], xmm1
00007a44d59d8778  vmovaps [rsp+0x20], xmm2
00007a44d59d877e  vmovaps [rsp+0x30], xmm3
00007a44d59d8784  vmovaps [rsp+0x40], xmm4
00007a44d59d878a  vmovaps [rsp+0x50], xmm5
00007a44d59d8790  vmovaps [rsp+0x60], xmm6
00007a44d59d8796  vmovaps [rsp+0x70], xmm7
00007a44d59d879c  vmovaps [rsp+0x80], xmm8
00007a44d59d87a5  vmovaps [rsp+0x90], xmm9
00007a44d59d87ae  vmovaps [rsp+0xA0], xmm10
00007a44d59d87b7  vmovaps [rsp+0xB0], xmm11
00007a44d59d87c0  vmovaps [rsp+0xC0], xmm13
00007a44d59d87c9  vmovaps [rsp+0xD0], xmm14
00007a44d59d87d2  vmovaps [rsp+0xE0], xmm15
00007a44d59d87db  sub rsp, 0x40
00007a44d59d87df  lea rdi, [rsp]
00007a44d59d87e3  lea rsi, [rsp+0x10]
00007a44d59d87e8  lea rdx, [rsp+0x20]
00007a44d59d87ed  lea rcx, [rsp+0x30]
00007a44d59d87f2  mov r8d, 0x00
00007a44d59d87f8  lea r9, [r15+0x3A8]
00007a44d59d87ff  movaps [rdi], xmm12
00007a44d59d8803  movaps [rsi], xmm7
00007a44d59d8806  movaps [rdx], xmm15
00007a44d59d880a  movaps [rcx], xmm1
00007a44d59d880d  mov rax, 0x56179A4B1A50
00007a44d59d8817  call rax
00007a44d59d8819  movaps xmm12, [rsp]
00007a44d59d881e  add rsp, 0x40
00007a44d59d8822  vmovaps xmm0, [rsp]
00007a44d59d8827  vmovaps xmm1, [rsp+0x10]
00007a44d59d882d  vmovaps xmm2, [rsp+0x20]
00007a44d59d8833  vmovaps xmm3, [rsp+0x30]
00007a44d59d8839  vmovaps xmm4, [rsp+0x40]
00007a44d59d883f  vmovaps xmm5, [rsp+0x50]
00007a44d59d8845  vmovaps xmm6, [rsp+0x60]
00007a44d59d884b  vmovaps xmm7, [rsp+0x70]
00007a44d59d8851  vmovaps xmm8, [rsp+0x80]
00007a44d59d885a  vmovaps xmm9, [rsp+0x90]
00007a44d59d8863  vmovaps xmm10, [rsp+0xA0]
00007a44d59d886c  vmovaps xmm11, [rsp+0xB0]
00007a44d59d8875  vmovaps xmm13, [rsp+0xC0]
00007a44d59d887e  vmovaps xmm14, [rsp+0xD0]
00007a44d59d8887  vmovaps xmm15, [rsp+0xE0]
00007a44d59d8890  add rsp, 0xF0
00007a44d59d8897  pop r11
00007a44d59d8899  pop r10
00007a44d59d889b  pop r9
00007a44d59d889d  pop r8
00007a44d59d889f  pop rsi
00007a44d59d88a0  pop rdi
00007a44d59d88a1  pop rdx
00007a44d59d88a2  pop rcx
00007a44d59d88a3  pop rax
00007a44d59d88a4  add rsp, 0x08
00007a44d59d88a8  jmp 0x00007A44D59D6A4E
00007a44d59d88ad  call 0x00007A44D58D64F0
00007a44d59d88b2  jmp 0x00007A44D59D6A58
00007a44d59d88b7  call 0x00007A44D58E5820
00007a44d59d88bc  jmp 0x00007A44D59D6A62
00007a44d59d88c1  sub rsp, 0x08
00007a44d59d88c5  push rax
00007a44d59d88c6  push rcx
00007a44d59d88c7  push rdx
00007a44d59d88c8  push rdi
00007a44d59d88c9  push rsi
00007a44d59d88ca  push r8
00007a44d59d88cc  push r9
00007a44d59d88ce  push r10
00007a44d59d88d0  push r11
00007a44d59d88d2  sub rsp, 0xF0
00007a44d59d88d9  vmovaps [rsp], xmm0
00007a44d59d88de  vmovaps [rsp+0x10], xmm1
00007a44d59d88e4  vmovaps [rsp+0x20], xmm2
00007a44d59d88ea  vmovaps [rsp+0x30], xmm3
00007a44d59d88f0  vmovaps [rsp+0x40], xmm4
00007a44d59d88f6  vmovaps [rsp+0x50], xmm5
00007a44d59d88fc  vmovaps [rsp+0x60], xmm6
00007a44d59d8902  vmovaps [rsp+0x70], xmm8
00007a44d59d8908  vmovaps [rsp+0x80], xmm9
00007a44d59d8911  vmovaps [rsp+0x90], xmm10
00007a44d59d891a  vmovaps [rsp+0xA0], xmm11
00007a44d59d8923  vmovaps [rsp+0xB0], xmm12
00007a44d59d892c  vmovaps [rsp+0xC0], xmm13
00007a44d59d8935  vmovaps [rsp+0xD0], xmm14
00007a44d59d893e  vmovaps [rsp+0xE0], xmm15
00007a44d59d8947  sub rsp, 0x40
00007a44d59d894b  lea rdi, [rsp]
00007a44d59d894f  lea rsi, [rsp+0x10]
00007a44d59d8954  lea rdx, [rsp+0x20]
00007a44d59d8959  lea rcx, [rsp+0x30]
00007a44d59d895e  mov r8d, 0x00
00007a44d59d8964  lea r9, [r15+0x3A8]
00007a44d59d896b  movaps [rdi], xmm7
00007a44d59d896e  movaps [rsi], xmm2
00007a44d59d8971  movaps [rdx], xmm9
00007a44d59d8975  movaps [rcx], xmm11
00007a44d59d8979  mov rax, 0x56179A4B1A50
00007a44d59d8983  call rax
00007a44d59d8985  movaps xmm7, [rsp]
00007a44d59d8989  add rsp, 0x40
00007a44d59d898d  vmovaps xmm0, [rsp]
00007a44d59d8992  vmovaps xmm1, [rsp+0x10]
00007a44d59d8998  vmovaps xmm2, [rsp+0x20]
00007a44d59d899e  vmovaps xmm3, [rsp+0x30]
00007a44d59d89a4  vmovaps xmm4, [rsp+0x40]
00007a44d59d89aa  vmovaps xmm5, [rsp+0x50]
00007a44d59d89b0  vmovaps xmm6, [rsp+0x60]
00007a44d59d89b6  vmovaps xmm8, [rsp+0x70]
00007a44d59d89bc  vmovaps xmm9, [rsp+0x80]
00007a44d59d89c5  vmovaps xmm10, [rsp+0x90]
00007a44d59d89ce  vmovaps xmm11, [rsp+0xA0]
00007a44d59d89d7  vmovaps xmm12, [rsp+0xB0]
00007a44d59d89e0  vmovaps xmm13, [rsp+0xC0]
00007a44d59d89e9  vmovaps xmm14, [rsp+0xD0]
00007a44d59d89f2  vmovaps xmm15, [rsp+0xE0]
00007a44d59d89fb  add rsp, 0xF0
00007a44d59d8a02  pop r11
00007a44d59d8a04  pop r10
00007a44d59d8a06  pop r9
00007a44d59d8a08  pop r8
00007a44d59d8a0a  pop rsi
00007a44d59d8a0b  pop rdi
00007a44d59d8a0c  pop rdx
00007a44d59d8a0d  pop rcx
00007a44d59d8a0e  pop rax
00007a44d59d8a0f  add rsp, 0x08
00007a44d59d8a13  jmp 0x00007A44D59D6A96
00007a44d59d8a18  sub rsp, 0x08
00007a44d59d8a1c  push rax
00007a44d59d8a1d  push rcx
00007a44d59d8a1e  push rdx
00007a44d59d8a1f  push rdi
00007a44d59d8a20  push rsi
00007a44d59d8a21  push r8
00007a44d59d8a23  push r9
00007a44d59d8a25  push r10
00007a44d59d8a27  push r11
00007a44d59d8a29  sub rsp, 0xF0
00007a44d59d8a30  vmovaps [rsp], xmm0
00007a44d59d8a35  vmovaps [rsp+0x10], xmm1
00007a44d59d8a3b  vmovaps [rsp+0x20], xmm2
00007a44d59d8a41  vmovaps [rsp+0x30], xmm3
00007a44d59d8a47  vmovaps [rsp+0x40], xmm4
00007a44d59d8a4d  vmovaps [rsp+0x50], xmm5
00007a44d59d8a53  vmovaps [rsp+0x60], xmm6
00007a44d59d8a59  vmovaps [rsp+0x70], xmm7
00007a44d59d8a5f  vmovaps [rsp+0x80], xmm8
00007a44d59d8a68  vmovaps [rsp+0x90], xmm10
00007a44d59d8a71  vmovaps [rsp+0xA0], xmm11
00007a44d59d8a7a  vmovaps [rsp+0xB0], xmm12
00007a44d59d8a83  vmovaps [rsp+0xC0], xmm13
00007a44d59d8a8c  vmovaps [rsp+0xD0], xmm14
00007a44d59d8a95  vmovaps [rsp+0xE0], xmm15
00007a44d59d8a9e  sub rsp, 0x40
00007a44d59d8aa2  lea rdi, [rsp]
00007a44d59d8aa6  lea rsi, [rsp+0x10]
00007a44d59d8aab  lea rdx, [rsp+0x20]
00007a44d59d8ab0  lea rcx, [rsp+0x30]
00007a44d59d8ab5  mov r8d, 0x00
00007a44d59d8abb  lea r9, [r15+0x3A8]
00007a44d59d8ac2  movaps [rdi], xmm9
00007a44d59d8ac6  movaps [rsi], xmm6
00007a44d59d8ac9  movaps [rdx], xmm1
00007a44d59d8acc  movaps [rcx], xmm11
00007a44d59d8ad0  mov rax, 0x56179A4B1A50
00007a44d59d8ada  call rax
00007a44d59d8adc  movaps xmm9, [rsp]
00007a44d59d8ae1  add rsp, 0x40
00007a44d59d8ae5  vmovaps xmm0, [rsp]
00007a44d59d8aea  vmovaps xmm1, [rsp+0x10]
00007a44d59d8af0  vmovaps xmm2, [rsp+0x20]
00007a44d59d8af6  vmovaps xmm3, [rsp+0x30]
00007a44d59d8afc  vmovaps xmm4, [rsp+0x40]
00007a44d59d8b02  vmovaps xmm5, [rsp+0x50]
00007a44d59d8b08  vmovaps xmm6, [rsp+0x60]
00007a44d59d8b0e  vmovaps xmm7, [rsp+0x70]
00007a44d59d8b14  vmovaps xmm8, [rsp+0x80]
00007a44d59d8b1d  vmovaps xmm10, [rsp+0x90]
00007a44d59d8b26  vmovaps xmm11, [rsp+0xA0]
00007a44d59d8b2f  vmovaps xmm12, [rsp+0xB0]
00007a44d59d8b38  vmovaps xmm13, [rsp+0xC0]
00007a44d59d8b41  vmovaps xmm14, [rsp+0xD0]
00007a44d59d8b4a  vmovaps xmm15, [rsp+0xE0]
00007a44d59d8b53  add rsp, 0xF0
00007a44d59d8b5a  pop r11
00007a44d59d8b5c  pop r10
00007a44d59d8b5e  pop r9
00007a44d59d8b60  pop r8
00007a44d59d8b62  pop rsi
00007a44d59d8b63  pop rdi
00007a44d59d8b64  pop rdx
00007a44d59d8b65  pop rcx
00007a44d59d8b66  pop rax
00007a44d59d8b67  add rsp, 0x08
00007a44d59d8b6b  jmp 0x00007A44D59D6ABC
00007a44d59d8b70  sub rsp, 0x08
00007a44d59d8b74  push rax
00007a44d59d8b75  push rcx
00007a44d59d8b76  push rdx
00007a44d59d8b77  push rdi
00007a44d59d8b78  push rsi
00007a44d59d8b79  push r8
00007a44d59d8b7b  push r9
00007a44d59d8b7d  push r10
00007a44d59d8b7f  push r11
00007a44d59d8b81  sub rsp, 0xF0
00007a44d59d8b88  vmovaps [rsp], xmm0
00007a44d59d8b8d  vmovaps [rsp+0x10], xmm1
00007a44d59d8b93  vmovaps [rsp+0x20], xmm2
00007a44d59d8b99  vmovaps [rsp+0x30], xmm3
00007a44d59d8b9f  vmovaps [rsp+0x40], xmm4
00007a44d59d8ba5  vmovaps [rsp+0x50], xmm5
00007a44d59d8bab  vmovaps [rsp+0x60], xmm6
00007a44d59d8bb1  vmovaps [rsp+0x70], xmm7
00007a44d59d8bb7  vmovaps [rsp+0x80], xmm8
00007a44d59d8bc0  vmovaps [rsp+0x90], xmm9
00007a44d59d8bc9  vmovaps [rsp+0xA0], xmm10
00007a44d59d8bd2  vmovaps [rsp+0xB0], xmm12
00007a44d59d8bdb  vmovaps [rsp+0xC0], xmm13
00007a44d59d8be4  vmovaps [rsp+0xD0], xmm14
00007a44d59d8bed  vmovaps [rsp+0xE0], xmm15
00007a44d59d8bf6  sub rsp, 0x40
00007a44d59d8bfa  lea rdi, [rsp]
00007a44d59d8bfe  lea rsi, [rsp+0x10]
00007a44d59d8c03  lea rdx, [rsp+0x20]
00007a44d59d8c08  lea rcx, [rsp+0x30]
00007a44d59d8c0d  mov r8d, 0x00
00007a44d59d8c13  lea r9, [r15+0x3A8]
00007a44d59d8c1a  movaps [rdi], xmm11
00007a44d59d8c1e  movaps [rsi], xmm10
00007a44d59d8c22  movaps [rdx], xmm8
00007a44d59d8c26  movaps [rcx], xmm1
00007a44d59d8c29  mov rax, 0x56179A4B1A50
00007a44d59d8c33  call rax
00007a44d59d8c35  movaps xmm11, [rsp]
00007a44d59d8c3a  add rsp, 0x40
00007a44d59d8c3e  vmovaps xmm0, [rsp]
00007a44d59d8c43  vmovaps xmm1, [rsp+0x10]
00007a44d59d8c49  vmovaps xmm2, [rsp+0x20]
00007a44d59d8c4f  vmovaps xmm3, [rsp+0x30]
00007a44d59d8c55  vmovaps xmm4, [rsp+0x40]
00007a44d59d8c5b  vmovaps xmm5, [rsp+0x50]
00007a44d59d8c61  vmovaps xmm6, [rsp+0x60]
00007a44d59d8c67  vmovaps xmm7, [rsp+0x70]
00007a44d59d8c6d  vmovaps xmm8, [rsp+0x80]
00007a44d59d8c76  vmovaps xmm9, [rsp+0x90]
00007a44d59d8c7f  vmovaps xmm10, [rsp+0xA0]
00007a44d59d8c88  vmovaps xmm12, [rsp+0xB0]
00007a44d59d8c91  vmovaps xmm13, [rsp+0xC0]
00007a44d59d8c9a  vmovaps xmm14, [rsp+0xD0]
00007a44d59d8ca3  vmovaps xmm15, [rsp+0xE0]
00007a44d59d8cac  add rsp, 0xF0
00007a44d59d8cb3  pop r11
00007a44d59d8cb5  pop r10
00007a44d59d8cb7  pop r9
00007a44d59d8cb9  pop r8
00007a44d59d8cbb  pop rsi
00007a44d59d8cbc  pop rdi
00007a44d59d8cbd  pop rdx
00007a44d59d8cbe  pop rcx
00007a44d59d8cbf  pop rax
00007a44d59d8cc0  add rsp, 0x08
00007a44d59d8cc4  jmp 0x00007A44D59D6AE2
00007a44d59d8cc9  sub rsp, 0x08
00007a44d59d8ccd  push rax
00007a44d59d8cce  push rcx
00007a44d59d8ccf  push rdx
00007a44d59d8cd0  push rdi
00007a44d59d8cd1  push rsi
00007a44d59d8cd2  push r8
00007a44d59d8cd4  push r9
00007a44d59d8cd6  push r10
00007a44d59d8cd8  push r11
00007a44d59d8cda  sub rsp, 0xF0
00007a44d59d8ce1  vmovaps [rsp], xmm0
00007a44d59d8ce6  vmovaps [rsp+0x10], xmm1
00007a44d59d8cec  vmovaps [rsp+0x20], xmm2
00007a44d59d8cf2  vmovaps [rsp+0x30], xmm3
00007a44d59d8cf8  vmovaps [rsp+0x40], xmm4
00007a44d59d8cfe  vmovaps [rsp+0x50], xmm5
00007a44d59d8d04  vmovaps [rsp+0x60], xmm6
00007a44d59d8d0a  vmovaps [rsp+0x70], xmm7
00007a44d59d8d10  vmovaps [rsp+0x80], xmm8
00007a44d59d8d19  vmovaps [rsp+0x90], xmm9
00007a44d59d8d22  vmovaps [rsp+0xA0], xmm11
00007a44d59d8d2b  vmovaps [rsp+0xB0], xmm12
00007a44d59d8d34  vmovaps [rsp+0xC0], xmm13
00007a44d59d8d3d  vmovaps [rsp+0xD0], xmm14
00007a44d59d8d46  vmovaps [rsp+0xE0], xmm15
00007a44d59d8d4f  sub rsp, 0x40
00007a44d59d8d53  lea rdi, [rsp]
00007a44d59d8d57  lea rsi, [rsp+0x10]
00007a44d59d8d5c  lea rdx, [rsp+0x20]
00007a44d59d8d61  lea rcx, [rsp+0x30]
00007a44d59d8d66  mov r8d, 0x00
00007a44d59d8d6c  lea r9, [r15+0x3A8]
00007a44d59d8d73  movaps [rdi], xmm10
00007a44d59d8d77  movaps [rsi], xmm12
00007a44d59d8d7b  movaps [rdx], xmm13
00007a44d59d8d7f  movaps [rcx], xmm1
00007a44d59d8d82  mov rax, 0x56179A4B1A50
00007a44d59d8d8c  call rax
00007a44d59d8d8e  movaps xmm10, [rsp]
00007a44d59d8d93  add rsp, 0x40
00007a44d59d8d97  vmovaps xmm0, [rsp]
00007a44d59d8d9c  vmovaps xmm1, [rsp+0x10]
00007a44d59d8da2  vmovaps xmm2, [rsp+0x20]
00007a44d59d8da8  vmovaps xmm3, [rsp+0x30]
00007a44d59d8dae  vmovaps xmm4, [rsp+0x40]
00007a44d59d8db4  vmovaps xmm5, [rsp+0x50]
00007a44d59d8dba  vmovaps xmm6, [rsp+0x60]
00007a44d59d8dc0  vmovaps xmm7, [rsp+0x70]
00007a44d59d8dc6  vmovaps xmm8, [rsp+0x80]
00007a44d59d8dcf  vmovaps xmm9, [rsp+0x90]
00007a44d59d8dd8  vmovaps xmm11, [rsp+0xA0]
00007a44d59d8de1  vmovaps xmm12, [rsp+0xB0]
00007a44d59d8dea  vmovaps xmm13, [rsp+0xC0]
00007a44d59d8df3  vmovaps xmm14, [rsp+0xD0]
00007a44d59d8dfc  vmovaps xmm15, [rsp+0xE0]
00007a44d59d8e05  add rsp, 0xF0
00007a44d59d8e0c  pop r11
00007a44d59d8e0e  pop r10
00007a44d59d8e10  pop r9
00007a44d59d8e12  pop r8
00007a44d59d8e14  pop rsi
00007a44d59d8e15  pop rdi
00007a44d59d8e16  pop rdx
00007a44d59d8e17  pop rcx
00007a44d59d8e18  pop rax
00007a44d59d8e19  add rsp, 0x08
00007a44d59d8e1d  jmp 0x00007A44D59D6B08
00007a44d59d8e22  call 0x00007A44D58D64F0
00007a44d59d8e27  jmp 0x00007A44D59D6B12
00007a44d59d8e2c  call 0x00007A44D58E3320
00007a44d59d8e31  jmp 0x00007A44D59D6B1C
00007a44d59d8e36  sub rsp, 0x08
00007a44d59d8e3a  push rax
00007a44d59d8e3b  push rcx
00007a44d59d8e3c  push rdx
00007a44d59d8e3d  push rdi
00007a44d59d8e3e  push rsi
00007a44d59d8e3f  push r8
00007a44d59d8e41  push r9
00007a44d59d8e43  push r10
00007a44d59d8e45  push r11
00007a44d59d8e47  sub rsp, 0xF0
00007a44d59d8e4e  vmovaps [rsp], xmm0
00007a44d59d8e53  vmovaps [rsp+0x10], xmm1
00007a44d59d8e59  vmovaps [rsp+0x20], xmm2
00007a44d59d8e5f  vmovaps [rsp+0x30], xmm3
00007a44d59d8e65  vmovaps [rsp+0x40], xmm4
00007a44d59d8e6b  vmovaps [rsp+0x50], xmm5
00007a44d59d8e71  vmovaps [rsp+0x60], xmm6
00007a44d59d8e77  vmovaps [rsp+0x70], xmm7
00007a44d59d8e7d  vmovaps [rsp+0x80], xmm9
00007a44d59d8e86  vmovaps [rsp+0x90], xmm10
00007a44d59d8e8f  vmovaps [rsp+0xA0], xmm11
00007a44d59d8e98  vmovaps [rsp+0xB0], xmm12
00007a44d59d8ea1  vmovaps [rsp+0xC0], xmm13
00007a44d59d8eaa  vmovaps [rsp+0xD0], xmm14
00007a44d59d8eb3  vmovaps [rsp+0xE0], xmm15
00007a44d59d8ebc  sub rsp, 0x40
00007a44d59d8ec0  lea rdi, [rsp]
00007a44d59d8ec4  lea rsi, [rsp+0x10]
00007a44d59d8ec9  lea rdx, [rsp+0x20]
00007a44d59d8ece  lea rcx, [rsp+0x30]
00007a44d59d8ed3  mov r8d, 0x00
00007a44d59d8ed9  lea r9, [r15+0x3A8]
00007a44d59d8ee0  movaps [rdi], xmm8
00007a44d59d8ee4  movaps [rsi], xmm7
00007a44d59d8ee7  movaps [rdx], xmm4
00007a44d59d8eea  movaps [rcx], xmm12
00007a44d59d8eee  mov rax, 0x56179A4B1A50
00007a44d59d8ef8  call rax
00007a44d59d8efa  movaps xmm8, [rsp]
00007a44d59d8eff  add rsp, 0x40
00007a44d59d8f03  vmovaps xmm0, [rsp]
00007a44d59d8f08  vmovaps xmm1, [rsp+0x10]
00007a44d59d8f0e  vmovaps xmm2, [rsp+0x20]
00007a44d59d8f14  vmovaps xmm3, [rsp+0x30]
00007a44d59d8f1a  vmovaps xmm4, [rsp+0x40]
00007a44d59d8f20  vmovaps xmm5, [rsp+0x50]
00007a44d59d8f26  vmovaps xmm6, [rsp+0x60]
00007a44d59d8f2c  vmovaps xmm7, [rsp+0x70]
00007a44d59d8f32  vmovaps xmm9, [rsp+0x80]
00007a44d59d8f3b  vmovaps xmm10, [rsp+0x90]
00007a44d59d8f44  vmovaps xmm11, [rsp+0xA0]
00007a44d59d8f4d  vmovaps xmm12, [rsp+0xB0]
00007a44d59d8f56  vmovaps xmm13, [rsp+0xC0]
00007a44d59d8f5f  vmovaps xmm14, [rsp+0xD0]
00007a44d59d8f68  vmovaps xmm15, [rsp+0xE0]
00007a44d59d8f71  add rsp, 0xF0
00007a44d59d8f78  pop r11
00007a44d59d8f7a  pop r10
00007a44d59d8f7c  pop r9
00007a44d59d8f7e  pop r8
00007a44d59d8f80  pop rsi
00007a44d59d8f81  pop rdi
00007a44d59d8f82  pop rdx
00007a44d59d8f83  pop rcx
00007a44d59d8f84  pop rax
00007a44d59d8f85  add rsp, 0x08
00007a44d59d8f89  jmp 0x00007A44D59D6B45
00007a44d59d8f8e  sub rsp, 0x08
00007a44d59d8f92  push rax
00007a44d59d8f93  push rcx
00007a44d59d8f94  push rdx
00007a44d59d8f95  push rdi
00007a44d59d8f96  push rsi
00007a44d59d8f97  push r8
00007a44d59d8f99  push r9
00007a44d59d8f9b  push r10
00007a44d59d8f9d  push r11
00007a44d59d8f9f  sub rsp, 0xF0
00007a44d59d8fa6  vmovaps [rsp], xmm0
00007a44d59d8fab  vmovaps [rsp+0x10], xmm1
00007a44d59d8fb1  vmovaps [rsp+0x20], xmm2
00007a44d59d8fb7  vmovaps [rsp+0x30], xmm3
00007a44d59d8fbd  vmovaps [rsp+0x40], xmm4
00007a44d59d8fc3  vmovaps [rsp+0x50], xmm5
00007a44d59d8fc9  vmovaps [rsp+0x60], xmm6
00007a44d59d8fcf  vmovaps [rsp+0x70], xmm8
00007a44d59d8fd5  vmovaps [rsp+0x80], xmm9
00007a44d59d8fde  vmovaps [rsp+0x90], xmm10
00007a44d59d8fe7  vmovaps [rsp+0xA0], xmm11
00007a44d59d8ff0  vmovaps [rsp+0xB0], xmm12
00007a44d59d8ff9  vmovaps [rsp+0xC0], xmm13
00007a44d59d9002  vmovaps [rsp+0xD0], xmm14
00007a44d59d900b  vmovaps [rsp+0xE0], xmm15
00007a44d59d9014  sub rsp, 0x40
00007a44d59d9018  lea rdi, [rsp]
00007a44d59d901c  lea rsi, [rsp+0x10]
00007a44d59d9021  lea rdx, [rsp+0x20]
00007a44d59d9026  lea rcx, [rsp+0x30]
00007a44d59d902b  mov r8d, 0x00
00007a44d59d9031  lea r9, [r15+0x3A8]
00007a44d59d9038  movaps [rdi], xmm7
00007a44d59d903b  movaps [rsi], xmm9
00007a44d59d903f  movaps [rdx], xmm14
00007a44d59d9043  movaps [rcx], xmm12
00007a44d59d9047  mov rax, 0x56179A4B1A50
00007a44d59d9051  call rax
00007a44d59d9053  movaps xmm7, [rsp]
00007a44d59d9057  add rsp, 0x40
00007a44d59d905b  vmovaps xmm0, [rsp]
00007a44d59d9060  vmovaps xmm1, [rsp+0x10]
00007a44d59d9066  vmovaps xmm2, [rsp+0x20]
00007a44d59d906c  vmovaps xmm3, [rsp+0x30]
00007a44d59d9072  vmovaps xmm4, [rsp+0x40]
00007a44d59d9078  vmovaps xmm5, [rsp+0x50]
00007a44d59d907e  vmovaps xmm6, [rsp+0x60]
00007a44d59d9084  vmovaps xmm8, [rsp+0x70]
00007a44d59d908a  vmovaps xmm9, [rsp+0x80]
00007a44d59d9093  vmovaps xmm10, [rsp+0x90]
00007a44d59d909c  vmovaps xmm11, [rsp+0xA0]
00007a44d59d90a5  vmovaps xmm12, [rsp+0xB0]
00007a44d59d90ae  vmovaps xmm13, [rsp+0xC0]
00007a44d59d90b7  vmovaps xmm14, [rsp+0xD0]
00007a44d59d90c0  vmovaps xmm15, [rsp+0xE0]
00007a44d59d90c9  add rsp, 0xF0
00007a44d59d90d0  pop r11
00007a44d59d90d2  pop r10
00007a44d59d90d4  pop r9
00007a44d59d90d6  pop r8
00007a44d59d90d8  pop rsi
00007a44d59d90d9  pop rdi
00007a44d59d90da  pop rdx
00007a44d59d90db  pop rcx
00007a44d59d90dc  pop rax
00007a44d59d90dd  add rsp, 0x08
00007a44d59d90e1  jmp 0x00007A44D59D6B6D
00007a44d59d90e6  sub rsp, 0x08
00007a44d59d90ea  push rax
00007a44d59d90eb  push rcx
00007a44d59d90ec  push rdx
00007a44d59d90ed  push rdi
00007a44d59d90ee  push rsi
00007a44d59d90ef  push r8
00007a44d59d90f1  push r9
00007a44d59d90f3  push r10
00007a44d59d90f5  push r11
00007a44d59d90f7  sub rsp, 0xF0
00007a44d59d90fe  vmovaps [rsp], xmm0
00007a44d59d9103  vmovaps [rsp+0x10], xmm1
00007a44d59d9109  vmovaps [rsp+0x20], xmm2
00007a44d59d910f  vmovaps [rsp+0x30], xmm3
00007a44d59d9115  vmovaps [rsp+0x40], xmm4
00007a44d59d911b  vmovaps [rsp+0x50], xmm5
00007a44d59d9121  vmovaps [rsp+0x60], xmm6
00007a44d59d9127  vmovaps [rsp+0x70], xmm7
00007a44d59d912d  vmovaps [rsp+0x80], xmm8
00007a44d59d9136  vmovaps [rsp+0x90], xmm9
00007a44d59d913f  vmovaps [rsp+0xA0], xmm10
00007a44d59d9148  vmovaps [rsp+0xB0], xmm11
00007a44d59d9151  vmovaps [rsp+0xC0], xmm13
00007a44d59d915a  vmovaps [rsp+0xD0], xmm14
00007a44d59d9163  vmovaps [rsp+0xE0], xmm15
00007a44d59d916c  sub rsp, 0x40
00007a44d59d9170  lea rdi, [rsp]
00007a44d59d9174  lea rsi, [rsp+0x10]
00007a44d59d9179  lea rdx, [rsp+0x20]
00007a44d59d917e  lea rcx, [rsp+0x30]
00007a44d59d9183  mov r8d, 0x00
00007a44d59d9189  lea r9, [r15+0x3A8]
00007a44d59d9190  movaps [rdi], xmm12
00007a44d59d9194  movaps [rsi], xmm11
00007a44d59d9198  movaps [rdx], xmm15
00007a44d59d919c  movaps [rcx], xmm14
00007a44d59d91a0  mov rax, 0x56179A4B1A50
00007a44d59d91aa  call rax
00007a44d59d91ac  movaps xmm12, [rsp]
00007a44d59d91b1  add rsp, 0x40
00007a44d59d91b5  vmovaps xmm0, [rsp]
00007a44d59d91ba  vmovaps xmm1, [rsp+0x10]
00007a44d59d91c0  vmovaps xmm2, [rsp+0x20]
00007a44d59d91c6  vmovaps xmm3, [rsp+0x30]
00007a44d59d91cc  vmovaps xmm4, [rsp+0x40]
00007a44d59d91d2  vmovaps xmm5, [rsp+0x50]
00007a44d59d91d8  vmovaps xmm6, [rsp+0x60]
00007a44d59d91de  vmovaps xmm7, [rsp+0x70]
00007a44d59d91e4  vmovaps xmm8, [rsp+0x80]
00007a44d59d91ed  vmovaps xmm9, [rsp+0x90]
00007a44d59d91f6  vmovaps xmm10, [rsp+0xA0]
00007a44d59d91ff  vmovaps xmm11, [rsp+0xB0]
00007a44d59d9208  vmovaps xmm13, [rsp+0xC0]
00007a44d59d9211  vmovaps xmm14, [rsp+0xD0]
00007a44d59d921a  vmovaps xmm15, [rsp+0xE0]
00007a44d59d9223  add rsp, 0xF0
00007a44d59d922a  pop r11
00007a44d59d922c  pop r10
00007a44d59d922e  pop r9
00007a44d59d9230  pop r8
00007a44d59d9232  pop rsi
00007a44d59d9233  pop rdi
00007a44d59d9234  pop rdx
00007a44d59d9235  pop rcx
00007a44d59d9236  pop rax
00007a44d59d9237  add rsp, 0x08
00007a44d59d923b  jmp 0x00007A44D59D6B96
00007a44d59d9240  sub rsp, 0x08
00007a44d59d9244  push rax
00007a44d59d9245  push rcx
00007a44d59d9246  push rdx
00007a44d59d9247  push rdi
00007a44d59d9248  push rsi
00007a44d59d9249  push r8
00007a44d59d924b  push r9
00007a44d59d924d  push r10
00007a44d59d924f  push r11
00007a44d59d9251  sub rsp, 0xF0
00007a44d59d9258  vmovaps [rsp], xmm0
00007a44d59d925d  vmovaps [rsp+0x10], xmm1
00007a44d59d9263  vmovaps [rsp+0x20], xmm2
00007a44d59d9269  vmovaps [rsp+0x30], xmm3
00007a44d59d926f  vmovaps [rsp+0x40], xmm4
00007a44d59d9275  vmovaps [rsp+0x50], xmm5
00007a44d59d927b  vmovaps [rsp+0x60], xmm6
00007a44d59d9281  vmovaps [rsp+0x70], xmm7
00007a44d59d9287  vmovaps [rsp+0x80], xmm8
00007a44d59d9290  vmovaps [rsp+0x90], xmm9
00007a44d59d9299  vmovaps [rsp+0xA0], xmm10
00007a44d59d92a2  vmovaps [rsp+0xB0], xmm12
00007a44d59d92ab  vmovaps [rsp+0xC0], xmm13
00007a44d59d92b4  vmovaps [rsp+0xD0], xmm14
00007a44d59d92bd  vmovaps [rsp+0xE0], xmm15
00007a44d59d92c6  sub rsp, 0x40
00007a44d59d92ca  lea rdi, [rsp]
00007a44d59d92ce  lea rsi, [rsp+0x10]
00007a44d59d92d3  lea rdx, [rsp+0x20]
00007a44d59d92d8  lea rcx, [rsp+0x30]
00007a44d59d92dd  mov r8d, 0x00
00007a44d59d92e3  lea r9, [r15+0x3A8]
00007a44d59d92ea  movaps [rdi], xmm11
00007a44d59d92ee  movaps [rsi], xmm10
00007a44d59d92f2  movaps [rdx], xmm13
00007a44d59d92f6  movaps [rcx], xmm15
00007a44d59d92fa  mov rax, 0x56179A4B1A50
00007a44d59d9304  call rax
00007a44d59d9306  movaps xmm11, [rsp]
00007a44d59d930b  add rsp, 0x40
00007a44d59d930f  vmovaps xmm0, [rsp]
00007a44d59d9314  vmovaps xmm1, [rsp+0x10]
00007a44d59d931a  vmovaps xmm2, [rsp+0x20]
00007a44d59d9320  vmovaps xmm3, [rsp+0x30]
00007a44d59d9326  vmovaps xmm4, [rsp+0x40]
00007a44d59d932c  vmovaps xmm5, [rsp+0x50]
00007a44d59d9332  vmovaps xmm6, [rsp+0x60]
00007a44d59d9338  vmovaps xmm7, [rsp+0x70]
00007a44d59d933e  vmovaps xmm8, [rsp+0x80]
00007a44d59d9347  vmovaps xmm9, [rsp+0x90]
00007a44d59d9350  vmovaps xmm10, [rsp+0xA0]
00007a44d59d9359  vmovaps xmm12, [rsp+0xB0]
00007a44d59d9362  vmovaps xmm13, [rsp+0xC0]
00007a44d59d936b  vmovaps xmm14, [rsp+0xD0]
00007a44d59d9374  vmovaps xmm15, [rsp+0xE0]
00007a44d59d937d  add rsp, 0xF0
00007a44d59d9384  pop r11
00007a44d59d9386  pop r10
00007a44d59d9388  pop r9
00007a44d59d938a  pop r8
00007a44d59d938c  pop rsi
00007a44d59d938d  pop rdi
00007a44d59d938e  pop rdx
00007a44d59d938f  pop rcx
00007a44d59d9390  pop rax
00007a44d59d9391  add rsp, 0x08
00007a44d59d9395  jmp 0x00007A44D59D6BBF
00007a44d59d939a  call 0x00007A44D58E5820
00007a44d59d939f  jmp 0x00007A44D59D6BCC
00007a44d59d93a4  call 0x00007A44D58E45A0
00007a44d59d93a9  jmp 0x00007A44D59D6BD9
00007a44d59d93ae  sub rsp, 0x08
00007a44d59d93b2  push rax
00007a44d59d93b3  push rcx
00007a44d59d93b4  push rdx
00007a44d59d93b5  push rdi
00007a44d59d93b6  push rsi
00007a44d59d93b7  push r8
00007a44d59d93b9  push r9
00007a44d59d93bb  push r10
00007a44d59d93bd  push r11
00007a44d59d93bf  sub rsp, 0xF0
00007a44d59d93c6  vmovaps [rsp], xmm0
00007a44d59d93cb  vmovaps [rsp+0x10], xmm1
00007a44d59d93d1  vmovaps [rsp+0x20], xmm2
00007a44d59d93d7  vmovaps [rsp+0x30], xmm3
00007a44d59d93dd  vmovaps [rsp+0x40], xmm4
00007a44d59d93e3  vmovaps [rsp+0x50], xmm5
00007a44d59d93e9  vmovaps [rsp+0x60], xmm6
00007a44d59d93ef  vmovaps [rsp+0x70], xmm7
00007a44d59d93f5  vmovaps [rsp+0x80], xmm8
00007a44d59d93fe  vmovaps [rsp+0x90], xmm9
00007a44d59d9407  vmovaps [rsp+0xA0], xmm11
00007a44d59d9410  vmovaps [rsp+0xB0], xmm12
00007a44d59d9419  vmovaps [rsp+0xC0], xmm13
00007a44d59d9422  vmovaps [rsp+0xD0], xmm14
00007a44d59d942b  vmovaps [rsp+0xE0], xmm15
00007a44d59d9434  sub rsp, 0x40
00007a44d59d9438  lea rdi, [rsp]
00007a44d59d943c  lea rsi, [rsp+0x10]
00007a44d59d9441  lea rdx, [rsp+0x20]
00007a44d59d9446  lea rcx, [rsp+0x30]
00007a44d59d944b  mov r8d, 0x00
00007a44d59d9451  lea r9, [r15+0x3A8]
00007a44d59d9458  movaps [rdi], xmm10
00007a44d59d945c  movaps [rsi], xmm8
00007a44d59d9460  movaps [rdx], xmm1
00007a44d59d9463  movaps [rcx], xmm13
00007a44d59d9467  mov rax, 0x56179A4B1A50
00007a44d59d9471  call rax
00007a44d59d9473  movaps xmm10, [rsp]
00007a44d59d9478  add rsp, 0x40
00007a44d59d947c  vmovaps xmm0, [rsp]
00007a44d59d9481  vmovaps xmm1, [rsp+0x10]
00007a44d59d9487  vmovaps xmm2, [rsp+0x20]
00007a44d59d948d  vmovaps xmm3, [rsp+0x30]
00007a44d59d9493  vmovaps xmm4, [rsp+0x40]
00007a44d59d9499  vmovaps xmm5, [rsp+0x50]
00007a44d59d949f  vmovaps xmm6, [rsp+0x60]
00007a44d59d94a5  vmovaps xmm7, [rsp+0x70]
00007a44d59d94ab  vmovaps xmm8, [rsp+0x80]
00007a44d59d94b4  vmovaps xmm9, [rsp+0x90]
00007a44d59d94bd  vmovaps xmm11, [rsp+0xA0]
00007a44d59d94c6  vmovaps xmm12, [rsp+0xB0]
00007a44d59d94cf  vmovaps xmm13, [rsp+0xC0]
00007a44d59d94d8  vmovaps xmm14, [rsp+0xD0]
00007a44d59d94e1  vmovaps xmm15, [rsp+0xE0]
00007a44d59d94ea  add rsp, 0xF0
00007a44d59d94f1  pop r11
00007a44d59d94f3  pop r10
00007a44d59d94f5  pop r9
00007a44d59d94f7  pop r8
00007a44d59d94f9  pop rsi
00007a44d59d94fa  pop rdi
00007a44d59d94fb  pop rdx
00007a44d59d94fc  pop rcx
00007a44d59d94fd  pop rax
00007a44d59d94fe  add rsp, 0x08
00007a44d59d9502  jmp 0x00007A44D59D6C0F
00007a44d59d9507  call 0x00007A44D58D64F0
00007a44d59d950c  jmp 0x00007A44D59D6C21
00007a44d59d9511  sub rsp, 0x08
00007a44d59d9515  push rax
00007a44d59d9516  push rcx
00007a44d59d9517  push rdx
00007a44d59d9518  push rdi
00007a44d59d9519  push rsi
00007a44d59d951a  push r8
00007a44d59d951c  push r9
00007a44d59d951e  push r10
00007a44d59d9520  push r11
00007a44d59d9522  sub rsp, 0xF0
00007a44d59d9529  vmovaps [rsp], xmm0
00007a44d59d952e  vmovaps [rsp+0x10], xmm1
00007a44d59d9534  vmovaps [rsp+0x20], xmm2
00007a44d59d953a  vmovaps [rsp+0x30], xmm3
00007a44d59d9540  vmovaps [rsp+0x40], xmm4
00007a44d59d9546  vmovaps [rsp+0x50], xmm5
00007a44d59d954c  vmovaps [rsp+0x60], xmm6
00007a44d59d9552  vmovaps [rsp+0x70], xmm7
00007a44d59d9558  vmovaps [rsp+0x80], xmm8
00007a44d59d9561  vmovaps [rsp+0x90], xmm10
00007a44d59d956a  vmovaps [rsp+0xA0], xmm11
00007a44d59d9573  vmovaps [rsp+0xB0], xmm12
00007a44d59d957c  vmovaps [rsp+0xC0], xmm13
00007a44d59d9585  vmovaps [rsp+0xD0], xmm14
00007a44d59d958e  vmovaps [rsp+0xE0], xmm15
00007a44d59d9597  sub rsp, 0x40
00007a44d59d959b  lea rdi, [rsp]
00007a44d59d959f  lea rsi, [rsp+0x10]
00007a44d59d95a4  lea rdx, [rsp+0x20]
00007a44d59d95a9  lea rcx, [rsp+0x30]
00007a44d59d95ae  mov r8d, 0x00
00007a44d59d95b4  lea r9, [r15+0x3A8]
00007a44d59d95bb  movaps [rdi], xmm9
00007a44d59d95bf  movaps [rsi], xmm7
00007a44d59d95c2  movaps [rdx], xmm14
00007a44d59d95c6  movaps [rcx], xmm13
00007a44d59d95ca  mov rax, 0x56179A4B1A50
00007a44d59d95d4  call rax
00007a44d59d95d6  movaps xmm9, [rsp]
00007a44d59d95db  add rsp, 0x40
00007a44d59d95df  vmovaps xmm0, [rsp]
00007a44d59d95e4  vmovaps xmm1, [rsp+0x10]
00007a44d59d95ea  vmovaps xmm2, [rsp+0x20]
00007a44d59d95f0  vmovaps xmm3, [rsp+0x30]
00007a44d59d95f6  vmovaps xmm4, [rsp+0x40]
00007a44d59d95fc  vmovaps xmm5, [rsp+0x50]
00007a44d59d9602  vmovaps xmm6, [rsp+0x60]
00007a44d59d9608  vmovaps xmm7, [rsp+0x70]
00007a44d59d960e  vmovaps xmm8, [rsp+0x80]
00007a44d59d9617  vmovaps xmm10, [rsp+0x90]
00007a44d59d9620  vmovaps xmm11, [rsp+0xA0]
00007a44d59d9629  vmovaps xmm12, [rsp+0xB0]
00007a44d59d9632  vmovaps xmm13, [rsp+0xC0]
00007a44d59d963b  vmovaps xmm14, [rsp+0xD0]
00007a44d59d9644  vmovaps xmm15, [rsp+0xE0]
00007a44d59d964d  add rsp, 0xF0
00007a44d59d9654  pop r11
00007a44d59d9656  pop r10
00007a44d59d9658  pop r9
00007a44d59d965a  pop r8
00007a44d59d965c  pop rsi
00007a44d59d965d  pop rdi
00007a44d59d965e  pop rdx
00007a44d59d965f  pop rcx
00007a44d59d9660  pop rax
00007a44d59d9661  add rsp, 0x08
00007a44d59d9665  jmp 0x00007A44D59D6C4F
00007a44d59d966a  sub rsp, 0x08
00007a44d59d966e  push rax
00007a44d59d966f  push rcx
00007a44d59d9670  push rdx
00007a44d59d9671  push rdi
00007a44d59d9672  push rsi
00007a44d59d9673  push r8
00007a44d59d9675  push r9
00007a44d59d9677  push r10
00007a44d59d9679  push r11
00007a44d59d967b  sub rsp, 0xF0
00007a44d59d9682  vmovaps [rsp], xmm0
00007a44d59d9687  vmovaps [rsp+0x10], xmm1
00007a44d59d968d  vmovaps [rsp+0x20], xmm2
00007a44d59d9693  vmovaps [rsp+0x30], xmm3
00007a44d59d9699  vmovaps [rsp+0x40], xmm4
00007a44d59d969f  vmovaps [rsp+0x50], xmm5
00007a44d59d96a5  vmovaps [rsp+0x60], xmm6
00007a44d59d96ab  vmovaps [rsp+0x70], xmm7
00007a44d59d96b1  vmovaps [rsp+0x80], xmm8
00007a44d59d96ba  vmovaps [rsp+0x90], xmm9
00007a44d59d96c3  vmovaps [rsp+0xA0], xmm10
00007a44d59d96cc  vmovaps [rsp+0xB0], xmm11
00007a44d59d96d5  vmovaps [rsp+0xC0], xmm12
00007a44d59d96de  vmovaps [rsp+0xD0], xmm14
00007a44d59d96e7  vmovaps [rsp+0xE0], xmm15
00007a44d59d96f0  sub rsp, 0x40
00007a44d59d96f4  lea rdi, [rsp]
00007a44d59d96f8  lea rsi, [rsp+0x10]
00007a44d59d96fd  lea rdx, [rsp+0x20]
00007a44d59d9702  lea rcx, [rsp+0x30]
00007a44d59d9707  mov r8d, 0x00
00007a44d59d970d  lea r9, [r15+0x3A8]
00007a44d59d9714  movaps [rdi], xmm13
00007a44d59d9718  movaps [rsi], xmm12
00007a44d59d971c  movaps [rdx], xmm15
00007a44d59d9720  movaps [rcx], xmm14
00007a44d59d9724  mov rax, 0x56179A4B1A50
00007a44d59d972e  call rax
00007a44d59d9730  movaps xmm13, [rsp]
00007a44d59d9735  add rsp, 0x40
00007a44d59d9739  vmovaps xmm0, [rsp]
00007a44d59d973e  vmovaps xmm1, [rsp+0x10]
00007a44d59d9744  vmovaps xmm2, [rsp+0x20]
00007a44d59d974a  vmovaps xmm3, [rsp+0x30]
00007a44d59d9750  vmovaps xmm4, [rsp+0x40]
00007a44d59d9756  vmovaps xmm5, [rsp+0x50]
00007a44d59d975c  vmovaps xmm6, [rsp+0x60]
00007a44d59d9762  vmovaps xmm7, [rsp+0x70]
00007a44d59d9768  vmovaps xmm8, [rsp+0x80]
00007a44d59d9771  vmovaps xmm9, [rsp+0x90]
00007a44d59d977a  vmovaps xmm10, [rsp+0xA0]
00007a44d59d9783  vmovaps xmm11, [rsp+0xB0]
00007a44d59d978c  vmovaps xmm12, [rsp+0xC0]
00007a44d59d9795  vmovaps xmm14, [rsp+0xD0]
00007a44d59d979e  vmovaps xmm15, [rsp+0xE0]
00007a44d59d97a7  add rsp, 0xF0
00007a44d59d97ae  pop r11
00007a44d59d97b0  pop r10
00007a44d59d97b2  pop r9
00007a44d59d97b4  pop r8
00007a44d59d97b6  pop rsi
00007a44d59d97b7  pop rdi
00007a44d59d97b8  pop rdx
00007a44d59d97b9  pop rcx
00007a44d59d97ba  pop rax
00007a44d59d97bb  add rsp, 0x08
00007a44d59d97bf  jmp 0x00007A44D59D6C7D
00007a44d59d97c4  sub rsp, 0x08
00007a44d59d97c8  push rax
00007a44d59d97c9  push rcx
00007a44d59d97ca  push rdx
00007a44d59d97cb  push rdi
00007a44d59d97cc  push rsi
00007a44d59d97cd  push r8
00007a44d59d97cf  push r9
00007a44d59d97d1  push r10
00007a44d59d97d3  push r11
00007a44d59d97d5  sub rsp, 0xF0
00007a44d59d97dc  vmovaps [rsp], xmm0
00007a44d59d97e1  vmovaps [rsp+0x10], xmm1
00007a44d59d97e7  vmovaps [rsp+0x20], xmm2
00007a44d59d97ed  vmovaps [rsp+0x30], xmm3
00007a44d59d97f3  vmovaps [rsp+0x40], xmm4
00007a44d59d97f9  vmovaps [rsp+0x50], xmm5
00007a44d59d97ff  vmovaps [rsp+0x60], xmm6
00007a44d59d9805  vmovaps [rsp+0x70], xmm7
00007a44d59d980b  vmovaps [rsp+0x80], xmm8
00007a44d59d9814  vmovaps [rsp+0x90], xmm9
00007a44d59d981d  vmovaps [rsp+0xA0], xmm10
00007a44d59d9826  vmovaps [rsp+0xB0], xmm11
00007a44d59d982f  vmovaps [rsp+0xC0], xmm12
00007a44d59d9838  vmovaps [rsp+0xD0], xmm13
00007a44d59d9841  vmovaps [rsp+0xE0], xmm15
00007a44d59d984a  sub rsp, 0x40
00007a44d59d984e  lea rdi, [rsp]
00007a44d59d9852  lea rsi, [rsp+0x10]
00007a44d59d9857  lea rdx, [rsp+0x20]
00007a44d59d985c  lea rcx, [rsp+0x30]
00007a44d59d9861  mov r8d, 0x00
00007a44d59d9867  lea r9, [r15+0x3A8]
00007a44d59d986e  movaps [rdi], xmm14
00007a44d59d9872  movaps [rsi], xmm11
00007a44d59d9876  movaps [rdx], xmm1
00007a44d59d9879  movaps [rcx], xmm15
00007a44d59d987d  mov rax, 0x56179A4B1A50
00007a44d59d9887  call rax
00007a44d59d9889  movaps xmm14, [rsp]
00007a44d59d988e  add rsp, 0x40
00007a44d59d9892  vmovaps xmm0, [rsp]
00007a44d59d9897  vmovaps xmm1, [rsp+0x10]
00007a44d59d989d  vmovaps xmm2, [rsp+0x20]
00007a44d59d98a3  vmovaps xmm3, [rsp+0x30]
00007a44d59d98a9  vmovaps xmm4, [rsp+0x40]
00007a44d59d98af  vmovaps xmm5, [rsp+0x50]
00007a44d59d98b5  vmovaps xmm6, [rsp+0x60]
00007a44d59d98bb  vmovaps xmm7, [rsp+0x70]
00007a44d59d98c1  vmovaps xmm8, [rsp+0x80]
00007a44d59d98ca  vmovaps xmm9, [rsp+0x90]
00007a44d59d98d3  vmovaps xmm10, [rsp+0xA0]
00007a44d59d98dc  vmovaps xmm11, [rsp+0xB0]
00007a44d59d98e5  vmovaps xmm12, [rsp+0xC0]
00007a44d59d98ee  vmovaps xmm13, [rsp+0xD0]
00007a44d59d98f7  vmovaps xmm15, [rsp+0xE0]
00007a44d59d9900  add rsp, 0xF0
00007a44d59d9907  pop r11
00007a44d59d9909  pop r10
00007a44d59d990b  pop r9
00007a44d59d990d  pop r8
00007a44d59d990f  pop rsi
00007a44d59d9910  pop rdi
00007a44d59d9911  pop rdx
00007a44d59d9912  pop rcx
00007a44d59d9913  pop rax
00007a44d59d9914  add rsp, 0x08
00007a44d59d9918  jmp 0x00007A44D59D6CAB
00007a44d59d991d  call 0x00007A44D58ACF70
00007a44d59d9922  jmp 0x00007A44D59D6CB9
00007a44d59d9927  call 0x00007A44D580C380
00007a44d59d992c  jmp 0x00007A44D59D6CC3
00007a44d59d9931  call 0x00007A44D5808C20
00007a44d59d9936  jmp 0x00007A44D59D6CCD
00007a44d59d993b  call 0x00007A44D580D600
00007a44d59d9940  jmp 0x00007A44D59D6CD7
00007a44d59d9945  int3
00007a44d59d9946  nop [rax+rax*1], ax
00007a44d59d994f  nop
00007a44d59d9950  mov eax, [r15+0x48]
00007a44d59d9954  lea r14d, [eax+0x01]
00007a44d59d9959  mov [rsp+0x10], r14d
00007a44d59d995e  mov r14d, r14d
00007a44d59d9961  mov [r15+0x48], r14
00007a44d59d9965  xor eax, eax
00007a44d59d9967  mov r14d, [rsp+0x10]
00007a44d59d996c  cmp r14d, 0x1F4
00007a44d59d9973  cmc
00007a44d59d9974  lahf
00007a44d59d9975  seto al
00007a44d59d9978  mov [r15+0x108], eax
00007a44d59d997f  mov eax, [r15+0x108]
00007a44d59d9986  sahf
00007a44d59d9987  jnz 0x00007A44D59D99B9
00007a44d59d9989  cmp dword ptr [r15+0x318], 0x00
00007a44d59d9991  jz 0x00007A44D59DD2E0
00007a44d59d9997  nop [rax+rax*1], ax
00007a44d59d99a0  nop [rax+rax*1], eax
00007a44d59d99a8  mov eax, 0x410670
00007a44d59d99ad  mov [r15+0x100], rax
00007a44d59d99b4  jmp 0x00007A44D57FE110
00007a44d59d99b9  cmp dword ptr [r15+0x318], 0x00
00007a44d59d99c1  jz 0x00007A44D59D99F0
00007a44d59d99c7  nop [rax+rax*1], ax
00007a44d59d99d0  nop [rax+rax*1], eax
00007a44d59d99d8  mov eax, 0x4104EC
00007a44d59d99dd  mov [r15+0x100], rax
00007a44d59d99e4  jmp 0x00007A44D57FE110
00007a44d59d99e9  int3
00007a44d59d99ea  int3
00007a44d59d99eb  nop [rax+rax*1], eax
00007a44d59d99f0  mov rax, [r15+0x40]
00007a44d59d99f4  vxorps xmm1, xmm1, xmm1
00007a44d59d99f8  vpbroadcastq xmm1, xmm1
00007a44d59d99fd  vxorps xmm15, xmm15, xmm15
00007a44d59d9a02  vpbroadcastq xmm15, xmm15
00007a44d59d9a07  lea r14, [rax+0x30]
00007a44d59d9a0b  mov r12, [r13+r14*1]
00007a44d59d9a10  lea r14, [rax+0x38]
00007a44d59d9a14  mov r11, [r13+r14*1]
00007a44d59d9a19  movq xmm14, r12
00007a44d59d9a1e  movq xmm13, r11
00007a44d59d9a23  movq xmm14, xmm14
00007a44d59d9a28  movq xmm13, xmm13
00007a44d59d9a2d  vmovaps [rsp+0x10], xmm13
00007a44d59d9a33  movq xmm13, xmm13
00007a44d59d9a38  movaps [r15+0x270], xmm13
00007a44d59d9a40  movaps xmm13, [r15+0x160]
00007a44d59d9a48  vmovaps [rsp+0x20], xmm13
00007a44d59d9a4e  vmovaps xmm12, [rsp+0x20]
00007a44d59d9a54  por xmm13, xmm12
00007a44d59d9a59  lea r14, [rax+0x20]
00007a44d59d9a5d  mov r12, [r13+r14*1]
00007a44d59d9a62  lea r14, [rax+0x28]
00007a44d59d9a66  mov r11, [r13+r14*1]
00007a44d59d9a6b  movq xmm12, r12
00007a44d59d9a70  movq xmm11, r11
00007a44d59d9a75  movq xmm12, xmm12
00007a44d59d9a7a  movq xmm11, xmm11
00007a44d59d9a7f  movaps xmm10, [r15+0x2D0]
00007a44d59d9a87  vmovaps [rsp+0x20], xmm10
00007a44d59d9a8d  vmovaps xmm9, [rsp+0x20]
00007a44d59d9a93  por xmm10, xmm9
00007a44d59d9a98  movaps xmm9, [r15+0x300]
00007a44d59d9aa0  vmovaps [rsp+0x20], xmm9
00007a44d59d9aa6  vmovaps xmm8, [rsp+0x20]
00007a44d59d9aac  por xmm9, xmm8
00007a44d59d9ab1  movaps xmm8, [r15+0x2B0]
00007a44d59d9ab9  vmovaps [rsp+0x20], xmm8
00007a44d59d9abf  vmovaps xmm7, [rsp+0x20]
00007a44d59d9ac5  por xmm8, xmm7
00007a44d59d9aca  movaps xmm7, [r15+0x180]
00007a44d59d9ad2  vmovaps [rsp+0x20], xmm7
00007a44d59d9ad8  vmovaps xmm6, [rsp+0x20]
00007a44d59d9ade  por xmm7, xmm6
00007a44d59d9ae2  lea r14, [rax+0x10]
00007a44d59d9ae6  mov r12, [r13+r14*1]
00007a44d59d9aeb  lea r14, [rax+0x18]
00007a44d59d9aef  mov r11, [r13+r14*1]
00007a44d59d9af4  movq xmm6, r12
00007a44d59d9af9  movq xmm5, r11
00007a44d59d9afe  movq xmm6, xmm6
00007a44d59d9b02  movq xmm5, xmm5
00007a44d59d9b06  movaps xmm4, [r15+0x200]
00007a44d59d9b0e  vmovaps [rsp+0x20], xmm4
00007a44d59d9b14  vmovaps xmm3, [rsp+0x20]
00007a44d59d9b1a  por xmm4, xmm3
00007a44d59d9b1e  movaps xmm3, [r15+0x1F0]
00007a44d59d9b26  vmovaps [rsp+0x20], xmm3
00007a44d59d9b2c  vmovaps xmm2, [rsp+0x20]
00007a44d59d9b32  por xmm3, xmm2
00007a44d59d9b36  movaps xmm2, [r15+0x2E0]
00007a44d59d9b3e  vmovaps [rsp+0x20], xmm2
00007a44d59d9b44  vmovaps [rsp+0x30], xmm1
00007a44d59d9b4a  vmovaps xmm1, [rsp+0x20]
00007a44d59d9b50  por xmm2, xmm1
00007a44d59d9b54  movaps xmm1, [r15+0x2A0]
00007a44d59d9b5c  vmovaps [rsp+0x20], xmm1
00007a44d59d9b62  vmovaps [rsp+0x40], xmm15
00007a44d59d9b68  vmovaps xmm15, [rsp+0x20]
00007a44d59d9b6e  por xmm1, xmm15
00007a44d59d9b73  movaps xmm15, [r15+0x280]
00007a44d59d9b7b  vmovaps [rsp+0x20], xmm15
00007a44d59d9b81  vmovaps [rsp+0x50], xmm1
00007a44d59d9b87  vmovaps xmm1, [rsp+0x20]
00007a44d59d9b8d  por xmm15, xmm1
00007a44d59d9b92  movaps xmm1, [r15+0x1C0]
00007a44d59d9b9a  vmovaps [rsp+0x20], xmm1
00007a44d59d9ba0  vmovaps [rsp+0x60], xmm15
00007a44d59d9ba6  vmovaps xmm15, [rsp+0x20]
00007a44d59d9bac  por xmm1, xmm15
00007a44d59d9bb1  movaps xmm15, [r15+0x210]
00007a44d59d9bb9  vmovaps [rsp+0x20], xmm15
00007a44d59d9bbf  vmovaps [rsp+0x70], xmm1
00007a44d59d9bc5  vmovaps xmm1, [rsp+0x20]
00007a44d59d9bcb  por xmm15, xmm1
00007a44d59d9bd0  mov r14, [r13+rax*1]
00007a44d59d9bd5  vmovq xmm1, r14
00007a44d59d9bda  vpbroadcastq xmm1, xmm1
00007a44d59d9bdf  vmovaps [rsp+0x20], xmm1
00007a44d59d9be5  vxorps xmm1, xmm1, xmm1
00007a44d59d9be9  vpbroadcastq xmm1, xmm1
00007a44d59d9bee  mov r14, [r15+0xF8]
00007a44d59d9bf5  vmovaps [rsp+0x80], xmm1
00007a44d59d9bfe  movups xmm1, [r13+r14*1]
00007a44d59d9c04  vmovaps [rsp+0x90], xmm1
00007a44d59d9c0d  vxorps xmm1, xmm1, xmm1
00007a44d59d9c11  vpbroadcastq xmm1, xmm1
00007a44d59d9c16  lea r12, [rax+0x08]
00007a44d59d9c1a  mov rax, [r13+r12*1]
00007a44d59d9c1f  vmovaps [rsp+0xA0], xmm1
00007a44d59d9c28  movq xmm1, rax
00007a44d59d9c2d  movaps [r15+0x240], xmm1
00007a44d59d9c35  mov rax, [r15+0x50]
00007a44d59d9c39  mov [r15+0x60], rax
00007a44d59d9c3d  mov qword ptr [r15+0x58], 0x40
00007a44d59d9c45  vmovaps xmm1, [rsp+0x30]
00007a44d59d9c4b  vmovaps [rsp+0x30], xmm15
00007a44d59d9c51  vmovaps xmm15, [rsp+0x90]
00007a44d59d9c5a  vmovaps [rsp+0x90], xmm14
00007a44d59d9c63  vmovaps xmm14, [rsp+0x20]
00007a44d59d9c69  vmovaps [rsp+0x20], xmm13
00007a44d59d9c6f  vmovaps [rsp+0xB0], xmm12
00007a44d59d9c78  movaps xmm13, xmm1
00007a44d59d9c7c  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d9c87  vptest xmm12, xmm12
00007a44d59d9c8c  jnz 0x00007A44D59DA72F
00007a44d59d9c92  movaps xmm1, [r15+0x250]
00007a44d59d9c9a  vmovaps xmm15, [rsp+0x40]
00007a44d59d9ca0  vmovaps [rsp+0x40], xmm13
00007a44d59d9ca6  movaps xmm12, xmm15
00007a44d59d9caa  vfmadd231pd xmm12, xmm1, xmm14
00007a44d59d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
00007a44d59d9cb5  vptest xmm13, xmm13
00007a44d59d9cba  jnz 0x00007A44D59DA888
00007a44d59d9cc0  movaps xmm15, [r15+0x1E0]
00007a44d59d9cc8  vmovaps [rsp+0xC0], xmm15
00007a44d59d9cd1  vmovaps xmm13, [rsp+0xC0]
00007a44d59d9cda  por xmm15, xmm13
00007a44d59d9cdf  movaps xmm13, [r15+0x1D0]
00007a44d59d9ce7  vmovaps [rsp+0xC0], xmm13
00007a44d59d9cf0  vmovaps [rsp+0xD0], xmm1
00007a44d59d9cf9  vmovaps xmm1, [rsp+0xC0]
00007a44d59d9d02  por xmm13, xmm1
00007a44d59d9d07  movaps xmm1, [r15+0x2C0]
00007a44d59d9d0f  vmovaps [rsp+0xC0], xmm1
00007a44d59d9d18  vmovaps [rsp+0xE0], xmm15
00007a44d59d9d21  vmovaps xmm15, [rsp+0xC0]
00007a44d59d9d2a  por xmm1, xmm15
00007a44d59d9d2f  movaps xmm15, [r15+0x290]
00007a44d59d9d37  vmovaps [rsp+0xC0], xmm15
00007a44d59d9d40  vmovaps [rsp+0xF0], xmm1
00007a44d59d9d49  vmovaps xmm1, [rsp+0xC0]
00007a44d59d9d52  por xmm15, xmm1
00007a44d59d9d57  movaps xmm1, [r15+0x260]
00007a44d59d9d5f  vmovaps [rsp+0xC0], xmm1
00007a44d59d9d68  vmovaps [rsp+0x100], xmm15
00007a44d59d9d71  vmovaps xmm15, [rsp+0xC0]
00007a44d59d9d7a  por xmm1, xmm15
00007a44d59d9d7f  vmovaps xmm15, [rsp+0xD0]
00007a44d59d9d88  vmovaps [rsp+0xC0], xmm1
00007a44d59d9d91  vmovaps xmm1, [rsp+0xD0]
00007a44d59d9d9a  por xmm15, xmm1
00007a44d59d9d9f  lea r12, [r14+0xC0]
00007a44d59d9da6  movups xmm1, [r13+r12*1]
00007a44d59d9dac  mov [rsp+0xD0], rax
00007a44d59d9db4  xor eax, eax
00007a44d59d9db6  mov r12d, 0x40
00007a44d59d9dbc  mov r11d, 0x200
00007a44d59d9dc2  cmp r12, r11
00007a44d59d9dc5  cmc
00007a44d59d9dc6  lahf
00007a44d59d9dc7  seto al
00007a44d59d9dca  mov [r15+0x108], eax
00007a44d59d9dd1  vmovaps [rsp+0x110], xmm1
00007a44d59d9dda  vmovaps xmm1, [rsp+0x80]
00007a44d59d9de3  vmovaps [rsp+0x80], xmm15
00007a44d59d9dec  vmovaps xmm15, [rsp+0x110]
00007a44d59d9df5  vmovaps [rsp+0x110], xmm13
00007a44d59d9dfe  vmovaps [rsp+0x120], xmm12
00007a44d59d9e07  movaps xmm13, xmm1
00007a44d59d9e0b  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d9e16  vptest xmm12, xmm12
00007a44d59d9e1b  jnz 0x00007A44D59DA9EB
00007a44d59d9e21  lea rax, [r14+0xB0]
00007a44d59d9e28  movups xmm1, [r13+rax*1]
00007a44d59d9e2e  vmovaps xmm15, [rsp+0xA0]
00007a44d59d9e37  vmovaps [rsp+0xA0], xmm13
00007a44d59d9e40  movaps xmm12, xmm15
00007a44d59d9e44  vfmadd231pd xmm12, xmm1, xmm14
00007a44d59d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
00007a44d59d9e4f  vptest xmm13, xmm13
00007a44d59d9e54  jnz 0x00007A44D59DAB4E
00007a44d59d9e5a  vmovaps xmm1, [rsp+0x30]
00007a44d59d9e60  vmovaps xmm15, [rsp+0x30]
00007a44d59d9e66  por xmm1, xmm15
00007a44d59d9e6b  movaps [r15+0x210], xmm1
00007a44d59d9e73  vmovaps xmm15, [rsp+0x70]
00007a44d59d9e79  vmovaps xmm14, [rsp+0x70]
00007a44d59d9e7f  por xmm15, xmm14
00007a44d59d9e84  movaps [r15+0x1C0], xmm15
00007a44d59d9e8c  vmovaps xmm14, [rsp+0x60]
00007a44d59d9e92  vmovaps xmm13, [rsp+0x60]
00007a44d59d9e98  por xmm14, xmm13
00007a44d59d9e9d  movaps [r15+0x280], xmm14
00007a44d59d9ea5  vmovaps xmm13, [rsp+0x50]
00007a44d59d9eab  vmovaps [rsp+0x30], xmm1
00007a44d59d9eb1  vmovaps xmm1, [rsp+0x50]
00007a44d59d9eb7  por xmm13, xmm1
00007a44d59d9ebc  movaps [r15+0x2A0], xmm13
00007a44d59d9ec4  vmovaps [rsp+0x50], xmm2
00007a44d59d9eca  vmovaps xmm1, [rsp+0x50]
00007a44d59d9ed0  por xmm2, xmm1
00007a44d59d9ed4  movaps [r15+0x2E0], xmm2
00007a44d59d9edc  vmovaps [rsp+0x50], xmm3
00007a44d59d9ee2  vmovaps xmm1, [rsp+0x50]
00007a44d59d9ee8  por xmm3, xmm1
00007a44d59d9eec  movaps [r15+0x1F0], xmm3
00007a44d59d9ef4  vmovaps xmm1, [rsp+0x80]
00007a44d59d9efd  vmovaps [rsp+0x50], xmm15
00007a44d59d9f03  vmovaps xmm15, [rsp+0x80]
00007a44d59d9f0c  por xmm1, xmm15
00007a44d59d9f11  movaps [r15+0x250], xmm1
00007a44d59d9f19  vmovaps xmm1, [rsp+0xC0]
00007a44d59d9f22  vmovaps xmm15, [rsp+0xC0]
00007a44d59d9f2b  por xmm1, xmm15
00007a44d59d9f30  movaps [r15+0x260], xmm1
00007a44d59d9f38  vmovaps xmm15, [rsp+0x100]
00007a44d59d9f41  vmovaps [rsp+0x60], xmm1
00007a44d59d9f47  vmovaps xmm1, [rsp+0x100]
00007a44d59d9f50  por xmm15, xmm1
00007a44d59d9f55  movaps [r15+0x290], xmm15
00007a44d59d9f5d  vmovaps xmm1, [rsp+0xF0]
00007a44d59d9f66  vmovaps [rsp+0x70], xmm15
00007a44d59d9f6c  vmovaps xmm15, [rsp+0xF0]
00007a44d59d9f75  por xmm1, xmm15
00007a44d59d9f7a  movaps [r15+0x2C0], xmm1
00007a44d59d9f82  movq xmm15, qword ptr [r15+0x240]
00007a44d59d9f8b  vmovaps [rsp+0x80], xmm15
00007a44d59d9f94  vpermilpd xmm15, xmm15, 0x00
00007a44d59d9f9a  vmovaps [rsp+0xC0], xmm1
00007a44d59d9fa3  vmovaps xmm1, [rsp+0x40]
00007a44d59d9fa9  vmovaps [rsp+0x40], xmm15
00007a44d59d9faf  vmovaps xmm15, [rsp+0x30]
00007a44d59d9fb5  vmovaps [rsp+0x30], xmm14
00007a44d59d9fbb  vmovaps xmm14, [rsp+0x40]
00007a44d59d9fc1  vmovaps [rsp+0x40], xmm13
00007a44d59d9fc7  vmovaps [rsp+0xF0], xmm12
00007a44d59d9fd0  movaps xmm13, xmm1
00007a44d59d9fd4  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
00007a44d59d9fdf  vptest xmm12, xmm12
00007a44d59d9fe4  jnz 0x00007A44D59DACA7
00007a44d59d9fea  vmovaps xmm1, [rsp+0x80]
00007a44d59d9ff3  vpermilpd xmm1, xmm1, 0x00
00007a44d59d9ff9  vmovaps xmm15, [rsp+0xA0]
00007a44d59da002  movaps xmm14, xmm15
00007a44d59da006  vfmadd231pd xmm14, xmm2, xmm1
00007a44d59da00b  vcmppd xmm12, xmm14, xmm14, 0x03
00007a44d59da011  vptest xmm12, xmm12
00007a44d59da016  jnz 0x00007A44D59DAE00
00007a44d59da01c  vmovaps xmm1, [rsp+0x80]
00007a44d59da025  vpermilpd xmm1, xmm1, 0x00
00007a44d59da02b  vmovaps xmm15, [rsp+0x120]
00007a44d59da034  vmovaps xmm12, [rsp+0x50]
00007a44d59da03a  vmovaps [rsp+0x50], xmm14
00007a44d59da040  movaps xmm2, xmm15
00007a44d59da044  vfmadd231pd xmm2, xmm12, xmm1
00007a44d59da049  vcmppd xmm14, xmm2, xmm2, 0x03
00007a44d59da04e  vptest xmm14, xmm14
00007a44d59da053  jnz 0x00007A44D59DAF58
00007a44d59da059  vmovaps xmm1, [rsp+0x110]
00007a44d59da062  vmovaps xmm15, [rsp+0x110]
00007a44d59da06b  por xmm1, xmm15
00007a44d59da070  movaps [r15+0x1D0], xmm1
00007a44d59da078  vmovaps xmm15, [rsp+0x80]
00007a44d59da081  vpermilpd xmm15, xmm15, 0x00
00007a44d59da087  vmovaps xmm14, [rsp+0xF0]
00007a44d59da090  vmovaps [rsp+0x80], xmm1
00007a44d59da099  movaps xmm12, xmm14
00007a44d59da09d  vfmadd231pd xmm12, xmm3, xmm15
00007a44d59da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
00007a44d59da0a8  vptest xmm1, xmm1
00007a44d59da0ad  jnz 0x00007A44D59DB0AF
00007a44d59da0b3  vmovaps [rsp+0xA0], xmm4
00007a44d59da0bc  vmovaps xmm1, [rsp+0xA0]
00007a44d59da0c5  por xmm4, xmm1
00007a44d59da0c9  movaps [r15+0x200], xmm4
00007a44d59da0d1  vmovaps xmm1, [rsp+0xE0]
00007a44d59da0da  vmovaps xmm15, [rsp+0xE0]
00007a44d59da0e3  por xmm1, xmm15
00007a44d59da0e8  movaps [r15+0x1E0], xmm1
00007a44d59da0f0  vmovaps [rsp+0xA0], xmm8
00007a44d59da0f9  vmovaps xmm1, [rsp+0xA0]
00007a44d59da102  por xmm8, xmm1
00007a44d59da107  movaps [r15+0x2B0], xmm8
00007a44d59da10f  vmovaps [rsp+0xA0], xmm9
00007a44d59da118  vmovaps xmm1, [rsp+0xA0]
00007a44d59da121  por xmm9, xmm1
00007a44d59da126  movaps [r15+0x300], xmm9
00007a44d59da12e  vmovaps [rsp+0xA0], xmm6
00007a44d59da137  vpermilpd xmm6, xmm6, 0x00
00007a44d59da13d  vmovaps xmm14, [rsp+0x60]
00007a44d59da143  movaps xmm9, xmm13
00007a44d59da147  vfmadd231pd xmm9, xmm14, xmm6
00007a44d59da14c  vcmppd xmm3, xmm9, xmm9, 0x03
00007a44d59da152  vptest xmm3, xmm3
00007a44d59da157  jnz 0x00007A44D59DB208
00007a44d59da15d  vmovaps xmm14, [rsp+0xA0]
00007a44d59da166  vpermilpd xmm14, xmm14, 0x00
00007a44d59da16c  vmovaps xmm13, [rsp+0x50]
00007a44d59da172  vmovaps xmm6, [rsp+0xC0]
00007a44d59da17b  vmovaps [rsp+0x50], xmm1
00007a44d59da181  movaps xmm3, xmm13
00007a44d59da185  vfmadd231pd xmm3, xmm6, xmm14
00007a44d59da18a  vcmppd xmm1, xmm3, xmm3, 0x03
00007a44d59da18f  vptest xmm1, xmm1
00007a44d59da194  jnz 0x00007A44D59DB361
00007a44d59da19a  vmovaps xmm1, [rsp+0xA0]
00007a44d59da1a3  vpermilpd xmm1, xmm1, 0x00
00007a44d59da1a9  vmovaps xmm14, [rsp+0x30]
00007a44d59da1af  movaps xmm6, xmm2
00007a44d59da1b2  vfmadd231pd xmm6, xmm14, xmm1
00007a44d59da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
00007a44d59da1bc  vptest xmm13, xmm13
00007a44d59da1c1  jnz 0x00007A44D59DB4B8
00007a44d59da1c7  vmovaps xmm1, [rsp+0xA0]
00007a44d59da1d0  vpermilpd xmm1, xmm1, 0x00
00007a44d59da1d6  vmovaps xmm14, [rsp+0x80]
00007a44d59da1df  movaps xmm13, xmm12
00007a44d59da1e3  vfmadd231pd xmm13, xmm14, xmm1
00007a44d59da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
00007a44d59da1ee  vptest xmm2, xmm2
00007a44d59da1f3  jnz 0x00007A44D59DB60E
00007a44d59da1f9  vmovaps [rsp+0x30], xmm7
00007a44d59da1ff  vmovaps xmm1, [rsp+0x30]
00007a44d59da205  por xmm7, xmm1
00007a44d59da209  movaps [r15+0x180], xmm7
00007a44d59da211  vmovaps [rsp+0x30], xmm10
00007a44d59da217  vmovaps xmm1, [rsp+0x30]
00007a44d59da21d  por xmm10, xmm1
00007a44d59da222  movaps [r15+0x2D0], xmm10
00007a44d59da22a  vmovaps [rsp+0x30], xmm5
00007a44d59da230  vpermilpd xmm5, xmm5, 0x00
00007a44d59da236  vmovaps xmm14, [rsp+0x50]
00007a44d59da23c  movaps xmm12, xmm3
00007a44d59da240  vfmadd231pd xmm12, xmm14, xmm5
00007a44d59da245  vcmppd xmm10, xmm12, xmm12, 0x03
00007a44d59da24b  vptest xmm10, xmm10
00007a44d59da250  jnz 0x00007A44D59DB767
00007a44d59da256  vmovaps xmm14, [rsp+0x30]
00007a44d59da25c  vpermilpd xmm14, xmm14, 0x00
00007a44d59da262  movaps xmm10, xmm9
00007a44d59da266  vfmadd231pd xmm10, xmm7, xmm14
00007a44d59da26b  vcmppd xmm5, xmm10, xmm10, 0x03
00007a44d59da271  vptest xmm5, xmm5
00007a44d59da276  jnz 0x00007A44D59DB8BF
00007a44d59da27c  lea rax, [r14+0x80]
00007a44d59da283  movups xmm14, [r13+rax*1]
00007a44d59da289  movaps [r15+0x2F0], xmm14
00007a44d59da291  vmovaps xmm9, [rsp+0x30]
00007a44d59da297  vpermilpd xmm9, xmm9, 0x00
00007a44d59da29d  vmovaps xmm7, [rsp+0x70]
00007a44d59da2a3  movaps xmm5, xmm6
00007a44d59da2a6  vfmadd231pd xmm5, xmm7, xmm9
00007a44d59da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
00007a44d59da2b0  vptest xmm3, xmm3
00007a44d59da2b5  jnz 0x00007A44D59DBA22
00007a44d59da2bb  vmovaps xmm9, [rsp+0x30]
00007a44d59da2c1  vpermilpd xmm9, xmm9, 0x00
00007a44d59da2c7  movaps xmm7, xmm13
00007a44d59da2cb  vfmadd231pd xmm7, xmm1, xmm9
00007a44d59da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
00007a44d59da2d5  vptest xmm6, xmm6
00007a44d59da2da  jnz 0x00007A44D59DBB78
00007a44d59da2e0  vmovaps xmm1, [rsp+0x20]
00007a44d59da2e6  vmovaps xmm13, [rsp+0x20]
00007a44d59da2ec  por xmm1, xmm13
00007a44d59da2f1  movaps [r15+0x160], xmm1
00007a44d59da2f9  lea rax, [r14+0x40]
00007a44d59da2fd  movups xmm13, [r13+rax*1]
00007a44d59da303  lea rax, [r14+0x50]
00007a44d59da307  movups xmm9, [r13+rax*1]
00007a44d59da30d  movaps [r15+0x1B0], xmm13
00007a44d59da315  movaps [r15+0x1A0], xmm9
00007a44d59da31d  movaps xmm6, [r15+0x190]
00007a44d59da325  vmovaps xmm3, [rsp+0xB0]
00007a44d59da32e  vpermilpd xmm3, xmm3, 0x00
00007a44d59da334  vmovaps [rsp+0x20], xmm1
00007a44d59da33a  movaps xmm2, xmm12
00007a44d59da33e  vfmadd231pd xmm2, xmm6, xmm3
00007a44d59da343  vcmppd xmm1, xmm2, xmm2, 0x03
00007a44d59da348  vptest xmm1, xmm1
00007a44d59da34d  jnz 0x00007A44D59DBCE3
00007a44d59da353  vmovaps xmm1, [rsp+0xB0]
00007a44d59da35c  vpermilpd xmm1, xmm1, 0x00
00007a44d59da362  vmovaps xmm12, [rsp+0x20]
00007a44d59da368  movaps xmm6, xmm10
00007a44d59da36c  vfmadd231pd xmm6, xmm12, xmm1
00007a44d59da371  vcmppd xmm3, xmm6, xmm6, 0x03
00007a44d59da376  vptest xmm3, xmm3
00007a44d59da37b  jnz 0x00007A44D59DBE39
00007a44d59da381  vmovaps xmm1, [rsp+0xB0]
00007a44d59da38a  vpermilpd xmm1, xmm1, 0x00
00007a44d59da390  vmovaps xmm12, [rsp+0x40]
00007a44d59da396  movaps xmm10, xmm5
00007a44d59da39a  vfmadd231pd xmm10, xmm12, xmm1
00007a44d59da39f  vcmppd xmm3, xmm10, xmm10, 0x03
00007a44d59da3a5  vptest xmm3, xmm3
00007a44d59da3aa  jnz 0x00007A44D59DBF90
00007a44d59da3b0  vmovaps xmm1, [rsp+0xB0]
00007a44d59da3b9  vpermilpd xmm1, xmm1, 0x00
00007a44d59da3bf  movaps xmm12, xmm7
00007a44d59da3c3  vfmadd231pd xmm12, xmm15, xmm1
00007a44d59da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
00007a44d59da3ce  vptest xmm5, xmm5
00007a44d59da3d3  jnz 0x00007A44D59DC0E8
00007a44d59da3d9  lea rax, [r14+0x60]
00007a44d59da3dd  movups xmm1, [r13+rax*1]
00007a44d59da3e3  lea rax, [r14+0x70]
00007a44d59da3e7  movups xmm15, [r13+rax*1]
00007a44d59da3ed  movaps [r15+0x150], xmm1
00007a44d59da3f5  movaps [r15+0x120], xmm15
00007a44d59da3fd  vmovaps [rsp+0x20], xmm11
00007a44d59da403  vpermilpd xmm11, xmm11, 0x00
00007a44d59da409  movaps xmm7, xmm2
00007a44d59da40c  vfmadd231pd xmm7, xmm9, xmm11
00007a44d59da411  vcmppd xmm5, xmm7, xmm7, 0x03
00007a44d59da416  vptest xmm5, xmm5
00007a44d59da41b  jnz 0x00007A44D59DC254
00007a44d59da421  vmovaps xmm11, [rsp+0x20]
00007a44d59da427  vpermilpd xmm11, xmm11, 0x00
00007a44d59da42d  movaps xmm9, xmm6
00007a44d59da431  vfmadd231pd xmm9, xmm1, xmm11
00007a44d59da436  vcmppd xmm5, xmm9, xmm9, 0x03
00007a44d59da43c  vptest xmm5, xmm5
00007a44d59da441  jnz 0x00007A44D59DC3AB
00007a44d59da447  vmovaps xmm1, [rsp+0x20]
00007a44d59da44d  vpermilpd xmm1, xmm1, 0x00
00007a44d59da453  movaps xmm11, xmm10
00007a44d59da457  vfmadd231pd xmm11, xmm8, xmm1
00007a44d59da45c  vcmppd xmm6, xmm11, xmm11, 0x03
00007a44d59da462  vptest xmm6, xmm6
00007a44d59da467  jnz 0x00007A44D59DC503
00007a44d59da46d  vmovaps xmm1, [rsp+0x20]
00007a44d59da473  vpermilpd xmm1, xmm1, 0x00
00007a44d59da479  movaps xmm10, xmm12
00007a44d59da47d  vfmadd231pd xmm10, xmm13, xmm1
00007a44d59da482  vcmppd xmm8, xmm10, xmm10, 0x03
00007a44d59da488  vptest xmm8, xmm8
00007a44d59da48d  jnz 0x00007A44D59DC65C
00007a44d59da493  lea rax, [r14+0x20]
00007a44d59da497  movups xmm1, [r13+rax*1]
00007a44d59da49d  lea rax, [r14+0x30]
00007a44d59da4a1  movups xmm13, [r13+rax*1]
00007a44d59da4a7  vmovaps xmm12, [rsp+0x90]
00007a44d59da4b0  vpermilpd xmm12, xmm12, 0x00
00007a44d59da4b6  movaps xmm8, xmm7
00007a44d59da4ba  vfmadd231pd xmm8, xmm4, xmm12
00007a44d59da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
00007a44d59da4c5  vptest xmm6, xmm6
00007a44d59da4ca  jnz 0x00007A44D59DC7C9
00007a44d59da4d0  vmovaps xmm12, [rsp+0x90]
00007a44d59da4d9  vpermilpd xmm12, xmm12, 0x00
00007a44d59da4df  movaps xmm7, xmm9
00007a44d59da4e3  vfmadd231pd xmm7, xmm14, xmm12
00007a44d59da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
00007a44d59da4ed  vptest xmm6, xmm6
00007a44d59da4f2  jnz 0x00007A44D59DC921
00007a44d59da4f8  vmovaps xmm14, [rsp+0x90]
00007a44d59da501  vpermilpd xmm14, xmm14, 0x00
00007a44d59da507  movaps xmm12, xmm11
00007a44d59da50b  vfmadd231pd xmm12, xmm15, xmm14
00007a44d59da510  vcmppd xmm9, xmm12, xmm12, 0x03
00007a44d59da516  vptest xmm9, xmm9
00007a44d59da51b  jnz 0x00007A44D59DCA79
00007a44d59da521  vmovaps xmm15, [rsp+0x90]
00007a44d59da52a  vpermilpd xmm15, xmm15, 0x00
00007a44d59da530  movaps xmm11, xmm10
00007a44d59da534  vfmadd231pd xmm11, xmm13, xmm15
00007a44d59da539  vcmppd xmm14, xmm11, xmm11, 0x03
00007a44d59da53f  vptest xmm14, xmm14
00007a44d59da544  jnz 0x00007A44D59DCBD3
00007a44d59da54a  lea rax, [r14+0x90]
00007a44d59da551  movups xmm15, [r13+rax*1]
00007a44d59da557  lea rax, [r14+0xA0]
00007a44d59da55e  movups xmm14, [r13+rax*1]
00007a44d59da564  movaps [r15+0x140], xmm15
00007a44d59da56c  movaps [r15+0x130], xmm14
00007a44d59da574  vmovaps xmm13, [rsp+0x10]
00007a44d59da57a  vpermilpd xmm13, xmm13, 0x00
00007a44d59da580  movaps xmm10, xmm8
00007a44d59da584  vfmadd231pd xmm10, xmm1, xmm13
00007a44d59da589  vcmppd xmm9, xmm10, xmm10, 0x03
00007a44d59da58f  vptest xmm9, xmm9
00007a44d59da594  jnz 0x00007A44D59DCD41
00007a44d59da59a  movaps [r15+0x220], xmm10
00007a44d59da5a2  lea rax, [r14+0x10]
00007a44d59da5a6  movups xmm1, [r13+rax*1]
00007a44d59da5ac  movaps [r15+0x240], xmm1
00007a44d59da5b4  vmovaps xmm13, [rsp+0x10]
00007a44d59da5ba  vpermilpd xmm13, xmm13, 0x00
00007a44d59da5c0  movaps xmm9, xmm7
00007a44d59da5c4  vfmadd231pd xmm9, xmm14, xmm13
00007a44d59da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
00007a44d59da5cf  vptest xmm8, xmm8
00007a44d59da5d4  jnz 0x00007A44D59DCEA4
00007a44d59da5da  movaps [r15+0x110], xmm9
00007a44d59da5e2  vmovaps xmm14, [rsp+0x10]
00007a44d59da5e8  vpermilpd xmm14, xmm14, 0x00
00007a44d59da5ee  movaps xmm13, xmm12
00007a44d59da5f2  vfmadd231pd xmm13, xmm15, xmm14
00007a44d59da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
00007a44d59da5fd  vptest xmm8, xmm8
00007a44d59da602  jnz 0x00007A44D59DCFFD
00007a44d59da608  movaps [r15+0x170], xmm13
00007a44d59da610  vmovaps xmm15, [rsp+0x10]
00007a44d59da616  vpermilpd xmm15, xmm15, 0x00
00007a44d59da61c  movaps xmm14, xmm11
00007a44d59da620  vfmadd231pd xmm14, xmm1, xmm15
00007a44d59da625  vcmppd xmm12, xmm14, xmm14, 0x03
00007a44d59da62b  vptest xmm12, xmm12
00007a44d59da630  jnz 0x00007A44D59DD157
00007a44d59da636  movaps [r15+0x230], xmm14
00007a44d59da63e  mov rax, [rsp+0xD0]
00007a44d59da646  movups [r13+rax*1], xmm9
00007a44d59da64c  lea r14, [rax+0x10]
00007a44d59da650  movups [r13+r14*1], xmm13
00007a44d59da656  lea r14, [rax+0x20]
00007a44d59da65a  movups [r13+r14*1], xmm10
00007a44d59da660  lea r14, [rax+0x30]
00007a44d59da664  movups [r13+r14*1], xmm14
00007a44d59da66a  mov eax, [r15+0x108]
00007a44d59da671  sahf
00007a44d59da672  jnz 0x00007A44D59DA6A4
00007a44d59da674  cmp dword ptr [r15+0x318], 0x00
00007a44d59da67c  jz 0x00007A44D59D9950
00007a44d59da682  nop [rax+rax*1], ax
00007a44d59da68b  nop [rax+rax*1], eax
00007a44d59da693  mov eax, 0x410664
00007a44d59da698  mov [r15+0x100], rax
00007a44d59da69f  jmp 0x00007A44D57FE110
00007a44d59da6a4  cmp dword ptr [r15+0x318], 0x00
00007a44d59da6ac  jz 0x00007A44D59D6050
00007a44d59da6b2  nop [rax+rax*1], ax
00007a44d59da6bb  nop [rax+rax*1], eax
00007a44d59da6c3  mov eax, 0x4104F0
00007a44d59da6c8  mov [r15+0x100], rax
00007a44d59da6cf  jmp 0x00007A44D57FE110
00007a44d59da6d4  int3
00007a44d59da6d5  call 0x00007A44D58E27E0
00007a44d59da6da  jmp 0x00007A44D59D9A10
00007a44d59da6df  call 0x00007A44D58E1570
00007a44d59da6e4  jmp 0x00007A44D59D9A19
00007a44d59da6e9  call 0x00007A44D58E27E0
00007a44d59da6ee  jmp 0x00007A44D59D9A62
00007a44d59da6f3  call 0x00007A44D58E1570
00007a44d59da6f8  jmp 0x00007A44D59D9A6B
00007a44d59da6fd  call 0x00007A44D58E27E0
00007a44d59da702  jmp 0x00007A44D59D9AEB
00007a44d59da707  call 0x00007A44D58E1570
00007a44d59da70c  jmp 0x00007A44D59D9AF4
00007a44d59da711  call 0x00007A44D580DC20
00007a44d59da716  jmp 0x00007A44D59D9BD5
00007a44d59da71b  call 0x00007A44D58D64F0
00007a44d59da720  jmp 0x00007A44D59D9C04
00007a44d59da725  call 0x00007A44D58B47C0
00007a44d59da72a  jmp 0x00007A44D59D9C1F
00007a44d59da72f  sub rsp, 0x08
00007a44d59da733  push rax
00007a44d59da734  push rcx
00007a44d59da735  push rdx
00007a44d59da736  push rdi
00007a44d59da737  push rsi
00007a44d59da738  push r8
00007a44d59da73a  push r9
00007a44d59da73c  push r10
00007a44d59da73e  push r11
00007a44d59da740  sub rsp, 0xF0
00007a44d59da747  vmovaps [rsp], xmm0
00007a44d59da74c  vmovaps [rsp+0x10], xmm1
00007a44d59da752  vmovaps [rsp+0x20], xmm2
00007a44d59da758  vmovaps [rsp+0x30], xmm3
00007a44d59da75e  vmovaps [rsp+0x40], xmm4
00007a44d59da764  vmovaps [rsp+0x50], xmm5
00007a44d59da76a  vmovaps [rsp+0x60], xmm6
00007a44d59da770  vmovaps [rsp+0x70], xmm7
00007a44d59da776  vmovaps [rsp+0x80], xmm8
00007a44d59da77f  vmovaps [rsp+0x90], xmm9
00007a44d59da788  vmovaps [rsp+0xA0], xmm10
00007a44d59da791  vmovaps [rsp+0xB0], xmm11
00007a44d59da79a  vmovaps [rsp+0xC0], xmm12
00007a44d59da7a3  vmovaps [rsp+0xD0], xmm14
00007a44d59da7ac  vmovaps [rsp+0xE0], xmm15
00007a44d59da7b5  sub rsp, 0x40
00007a44d59da7b9  lea rdi, [rsp]
00007a44d59da7bd  lea rsi, [rsp+0x10]
00007a44d59da7c2  lea rdx, [rsp+0x20]
00007a44d59da7c7  lea rcx, [rsp+0x30]
00007a44d59da7cc  mov r8d, 0x00
00007a44d59da7d2  lea r9, [r15+0x3A8]
00007a44d59da7d9  movaps [rdi], xmm13
00007a44d59da7dd  movaps [rsi], xmm1
00007a44d59da7e0  movaps [rdx], xmm15
00007a44d59da7e4  movaps [rcx], xmm14
00007a44d59da7e8  mov rax, 0x56179A4B1A50
00007a44d59da7f2  call rax
00007a44d59da7f4  movaps xmm13, [rsp]
00007a44d59da7f9  add rsp, 0x40
00007a44d59da7fd  vmovaps xmm0, [rsp]
00007a44d59da802  vmovaps xmm1, [rsp+0x10]
00007a44d59da808  vmovaps xmm2, [rsp+0x20]
00007a44d59da80e  vmovaps xmm3, [rsp+0x30]
00007a44d59da814  vmovaps xmm4, [rsp+0x40]
00007a44d59da81a  vmovaps xmm5, [rsp+0x50]
00007a44d59da820  vmovaps xmm6, [rsp+0x60]
00007a44d59da826  vmovaps xmm7, [rsp+0x70]
00007a44d59da82c  vmovaps xmm8, [rsp+0x80]
00007a44d59da835  vmovaps xmm9, [rsp+0x90]
00007a44d59da83e  vmovaps xmm10, [rsp+0xA0]
00007a44d59da847  vmovaps xmm11, [rsp+0xB0]
00007a44d59da850  vmovaps xmm12, [rsp+0xC0]
00007a44d59da859  vmovaps xmm14, [rsp+0xD0]
00007a44d59da862  vmovaps xmm15, [rsp+0xE0]
00007a44d59da86b  add rsp, 0xF0
00007a44d59da872  pop r11
00007a44d59da874  pop r10
00007a44d59da876  pop r9
00007a44d59da878  pop r8
00007a44d59da87a  pop rsi
00007a44d59da87b  pop rdi
00007a44d59da87c  pop rdx
00007a44d59da87d  pop rcx
00007a44d59da87e  pop rax
00007a44d59da87f  add rsp, 0x08
00007a44d59da883  jmp 0x00007A44D59D9C92
00007a44d59da888  sub rsp, 0x08
00007a44d59da88c  push rax
00007a44d59da88d  push rcx
00007a44d59da88e  push rdx
00007a44d59da88f  push rdi
00007a44d59da890  push rsi
00007a44d59da891  push r8
00007a44d59da893  push r9
00007a44d59da895  push r10
00007a44d59da897  push r11
00007a44d59da899  sub rsp, 0xF0
00007a44d59da8a0  vmovaps [rsp], xmm0
00007a44d59da8a5  vmovaps [rsp+0x10], xmm1
00007a44d59da8ab  vmovaps [rsp+0x20], xmm2
00007a44d59da8b1  vmovaps [rsp+0x30], xmm3
00007a44d59da8b7  vmovaps [rsp+0x40], xmm4
00007a44d59da8bd  vmovaps [rsp+0x50], xmm5
00007a44d59da8c3  vmovaps [rsp+0x60], xmm6
00007a44d59da8c9  vmovaps [rsp+0x70], xmm7
00007a44d59da8cf  vmovaps [rsp+0x80], xmm8
00007a44d59da8d8  vmovaps [rsp+0x90], xmm9
00007a44d59da8e1  vmovaps [rsp+0xA0], xmm10
00007a44d59da8ea  vmovaps [rsp+0xB0], xmm11
00007a44d59da8f3  vmovaps [rsp+0xC0], xmm13
00007a44d59da8fc  vmovaps [rsp+0xD0], xmm14
00007a44d59da905  vmovaps [rsp+0xE0], xmm15
00007a44d59da90e  sub rsp, 0x40
00007a44d59da912  lea rdi, [rsp]
00007a44d59da916  lea rsi, [rsp+0x10]
00007a44d59da91b  lea rdx, [rsp+0x20]
00007a44d59da920  lea rcx, [rsp+0x30]
00007a44d59da925  mov r8d, 0x00
00007a44d59da92b  lea r9, [r15+0x3A8]
00007a44d59da932  movaps [rdi], xmm12
00007a44d59da936  movaps [rsi], xmm15
00007a44d59da93a  movaps [rdx], xmm1
00007a44d59da93d  movaps [rcx], xmm14
00007a44d59da941  mov rax, 0x56179A4B1A50
00007a44d59da94b  call rax
00007a44d59da94d  movaps xmm12, [rsp]
00007a44d59da952  add rsp, 0x40
00007a44d59da956  vmovaps xmm0, [rsp]
00007a44d59da95b  vmovaps xmm1, [rsp+0x10]
00007a44d59da961  vmovaps xmm2, [rsp+0x20]
00007a44d59da967  vmovaps xmm3, [rsp+0x30]
00007a44d59da96d  vmovaps xmm4, [rsp+0x40]
00007a44d59da973  vmovaps xmm5, [rsp+0x50]
00007a44d59da979  vmovaps xmm6, [rsp+0x60]
00007a44d59da97f  vmovaps xmm7, [rsp+0x70]
00007a44d59da985  vmovaps xmm8, [rsp+0x80]
00007a44d59da98e  vmovaps xmm9, [rsp+0x90]
00007a44d59da997  vmovaps xmm10, [rsp+0xA0]
00007a44d59da9a0  vmovaps xmm11, [rsp+0xB0]
00007a44d59da9a9  vmovaps xmm13, [rsp+0xC0]
00007a44d59da9b2  vmovaps xmm14, [rsp+0xD0]
00007a44d59da9bb  vmovaps xmm15, [rsp+0xE0]
00007a44d59da9c4  add rsp, 0xF0
00007a44d59da9cb  pop r11
00007a44d59da9cd  pop r10
00007a44d59da9cf  pop r9
00007a44d59da9d1  pop r8
00007a44d59da9d3  pop rsi
00007a44d59da9d4  pop rdi
00007a44d59da9d5  pop rdx
00007a44d59da9d6  pop rcx
00007a44d59da9d7  pop rax
00007a44d59da9d8  add rsp, 0x08
00007a44d59da9dc  jmp 0x00007A44D59D9CC0
00007a44d59da9e1  call 0x00007A44D58B52F0
00007a44d59da9e6  jmp 0x00007A44D59D9DAC
00007a44d59da9eb  sub rsp, 0x08
00007a44d59da9ef  push rax
00007a44d59da9f0  push rcx
00007a44d59da9f1  push rdx
00007a44d59da9f2  push rdi
00007a44d59da9f3  push rsi
00007a44d59da9f4  push r8
00007a44d59da9f6  push r9
00007a44d59da9f8  push r10
00007a44d59da9fa  push r11
00007a44d59da9fc  sub rsp, 0xF0
00007a44d59daa03  vmovaps [rsp], xmm0
00007a44d59daa08  vmovaps [rsp+0x10], xmm1
00007a44d59daa0e  vmovaps [rsp+0x20], xmm2
00007a44d59daa14  vmovaps [rsp+0x30], xmm3
00007a44d59daa1a  vmovaps [rsp+0x40], xmm4
00007a44d59daa20  vmovaps [rsp+0x50], xmm5
00007a44d59daa26  vmovaps [rsp+0x60], xmm6
00007a44d59daa2c  vmovaps [rsp+0x70], xmm7
00007a44d59daa32  vmovaps [rsp+0x80], xmm8
00007a44d59daa3b  vmovaps [rsp+0x90], xmm9
00007a44d59daa44  vmovaps [rsp+0xA0], xmm10
00007a44d59daa4d  vmovaps [rsp+0xB0], xmm11
00007a44d59daa56  vmovaps [rsp+0xC0], xmm12
00007a44d59daa5f  vmovaps [rsp+0xD0], xmm14
00007a44d59daa68  vmovaps [rsp+0xE0], xmm15
00007a44d59daa71  sub rsp, 0x40
00007a44d59daa75  lea rdi, [rsp]
00007a44d59daa79  lea rsi, [rsp+0x10]
00007a44d59daa7e  lea rdx, [rsp+0x20]
00007a44d59daa83  lea rcx, [rsp+0x30]
00007a44d59daa88  mov r8d, 0x00
00007a44d59daa8e  lea r9, [r15+0x3A8]
00007a44d59daa95  movaps [rdi], xmm13
00007a44d59daa99  movaps [rsi], xmm1
00007a44d59daa9c  movaps [rdx], xmm15
00007a44d59daaa0  movaps [rcx], xmm14
00007a44d59daaa4  mov rax, 0x56179A4B1A50
00007a44d59daaae  call rax
00007a44d59daab0  movaps xmm13, [rsp]
00007a44d59daab5  add rsp, 0x40
00007a44d59daab9  vmovaps xmm0, [rsp]
00007a44d59daabe  vmovaps xmm1, [rsp+0x10]
00007a44d59daac4  vmovaps xmm2, [rsp+0x20]
00007a44d59daaca  vmovaps xmm3, [rsp+0x30]
00007a44d59daad0  vmovaps xmm4, [rsp+0x40]
00007a44d59daad6  vmovaps xmm5, [rsp+0x50]
00007a44d59daadc  vmovaps xmm6, [rsp+0x60]
00007a44d59daae2  vmovaps xmm7, [rsp+0x70]
00007a44d59daae8  vmovaps xmm8, [rsp+0x80]
00007a44d59daaf1  vmovaps xmm9, [rsp+0x90]
00007a44d59daafa  vmovaps xmm10, [rsp+0xA0]
00007a44d59dab03  vmovaps xmm11, [rsp+0xB0]
00007a44d59dab0c  vmovaps xmm12, [rsp+0xC0]
00007a44d59dab15  vmovaps xmm14, [rsp+0xD0]
00007a44d59dab1e  vmovaps xmm15, [rsp+0xE0]
00007a44d59dab27  add rsp, 0xF0
00007a44d59dab2e  pop r11
00007a44d59dab30  pop r10
00007a44d59dab32  pop r9
00007a44d59dab34  pop r8
00007a44d59dab36  pop rsi
00007a44d59dab37  pop rdi
00007a44d59dab38  pop rdx
00007a44d59dab39  pop rcx
00007a44d59dab3a  pop rax
00007a44d59dab3b  add rsp, 0x08
00007a44d59dab3f  jmp 0x00007A44D59D9E21
00007a44d59dab44  call 0x00007A44D57FF430
00007a44d59dab49  jmp 0x00007A44D59D9E2E
00007a44d59dab4e  sub rsp, 0x08
00007a44d59dab52  push rax
00007a44d59dab53  push rcx
00007a44d59dab54  push rdx
00007a44d59dab55  push rdi
00007a44d59dab56  push rsi
00007a44d59dab57  push r8
00007a44d59dab59  push r9
00007a44d59dab5b  push r10
00007a44d59dab5d  push r11
00007a44d59dab5f  sub rsp, 0xF0
00007a44d59dab66  vmovaps [rsp], xmm0
00007a44d59dab6b  vmovaps [rsp+0x10], xmm1
00007a44d59dab71  vmovaps [rsp+0x20], xmm2
00007a44d59dab77  vmovaps [rsp+0x30], xmm3
00007a44d59dab7d  vmovaps [rsp+0x40], xmm4
00007a44d59dab83  vmovaps [rsp+0x50], xmm5
00007a44d59dab89  vmovaps [rsp+0x60], xmm6
00007a44d59dab8f  vmovaps [rsp+0x70], xmm7
00007a44d59dab95  vmovaps [rsp+0x80], xmm8
00007a44d59dab9e  vmovaps [rsp+0x90], xmm9
00007a44d59daba7  vmovaps [rsp+0xA0], xmm10
00007a44d59dabb0  vmovaps [rsp+0xB0], xmm11
00007a44d59dabb9  vmovaps [rsp+0xC0], xmm13
00007a44d59dabc2  vmovaps [rsp+0xD0], xmm14
00007a44d59dabcb  vmovaps [rsp+0xE0], xmm15
00007a44d59dabd4  sub rsp, 0x40
00007a44d59dabd8  lea rdi, [rsp]
00007a44d59dabdc  lea rsi, [rsp+0x10]
00007a44d59dabe1  lea rdx, [rsp+0x20]
00007a44d59dabe6  lea rcx, [rsp+0x30]
00007a44d59dabeb  mov r8d, 0x00
00007a44d59dabf1  lea r9, [r15+0x3A8]
00007a44d59dabf8  movaps [rdi], xmm12
00007a44d59dabfc  movaps [rsi], xmm15
00007a44d59dac00  movaps [rdx], xmm1
00007a44d59dac03  movaps [rcx], xmm14
00007a44d59dac07  mov rax, 0x56179A4B1A50
00007a44d59dac11  call rax
00007a44d59dac13  movaps xmm12, [rsp]
00007a44d59dac18  add rsp, 0x40
00007a44d59dac1c  vmovaps xmm0, [rsp]
00007a44d59dac21  vmovaps xmm1, [rsp+0x10]
00007a44d59dac27  vmovaps xmm2, [rsp+0x20]
00007a44d59dac2d  vmovaps xmm3, [rsp+0x30]
00007a44d59dac33  vmovaps xmm4, [rsp+0x40]
00007a44d59dac39  vmovaps xmm5, [rsp+0x50]
00007a44d59dac3f  vmovaps xmm6, [rsp+0x60]
00007a44d59dac45  vmovaps xmm7, [rsp+0x70]
00007a44d59dac4b  vmovaps xmm8, [rsp+0x80]
00007a44d59dac54  vmovaps xmm9, [rsp+0x90]
00007a44d59dac5d  vmovaps xmm10, [rsp+0xA0]
00007a44d59dac66  vmovaps xmm11, [rsp+0xB0]
00007a44d59dac6f  vmovaps xmm13, [rsp+0xC0]
00007a44d59dac78  vmovaps xmm14, [rsp+0xD0]
00007a44d59dac81  vmovaps xmm15, [rsp+0xE0]
00007a44d59dac8a  add rsp, 0xF0
00007a44d59dac91  pop r11
00007a44d59dac93  pop r10
00007a44d59dac95  pop r9
00007a44d59dac97  pop r8
00007a44d59dac99  pop rsi
00007a44d59dac9a  pop rdi
00007a44d59dac9b  pop rdx
00007a44d59dac9c  pop rcx
00007a44d59dac9d  pop rax
00007a44d59dac9e  add rsp, 0x08
00007a44d59daca2  jmp 0x00007A44D59D9E5A
00007a44d59daca7  sub rsp, 0x08
00007a44d59dacab  push rax
00007a44d59dacac  push rcx
00007a44d59dacad  push rdx
00007a44d59dacae  push rdi
00007a44d59dacaf  push rsi
00007a44d59dacb0  push r8
00007a44d59dacb2  push r9
00007a44d59dacb4  push r10
00007a44d59dacb6  push r11
00007a44d59dacb8  sub rsp, 0xF0
00007a44d59dacbf  vmovaps [rsp], xmm0
00007a44d59dacc4  vmovaps [rsp+0x10], xmm1
00007a44d59dacca  vmovaps [rsp+0x20], xmm2
00007a44d59dacd0  vmovaps [rsp+0x30], xmm3
00007a44d59dacd6  vmovaps [rsp+0x40], xmm4
00007a44d59dacdc  vmovaps [rsp+0x50], xmm5
00007a44d59dace2  vmovaps [rsp+0x60], xmm6
00007a44d59dace8  vmovaps [rsp+0x70], xmm7
00007a44d59dacee  vmovaps [rsp+0x80], xmm8
00007a44d59dacf7  vmovaps [rsp+0x90], xmm9
00007a44d59dad00  vmovaps [rsp+0xA0], xmm10
00007a44d59dad09  vmovaps [rsp+0xB0], xmm11
00007a44d59dad12  vmovaps [rsp+0xC0], xmm12
00007a44d59dad1b  vmovaps [rsp+0xD0], xmm14
00007a44d59dad24  vmovaps [rsp+0xE0], xmm15
00007a44d59dad2d  sub rsp, 0x40
00007a44d59dad31  lea rdi, [rsp]
00007a44d59dad35  lea rsi, [rsp+0x10]
00007a44d59dad3a  lea rdx, [rsp+0x20]
00007a44d59dad3f  lea rcx, [rsp+0x30]
00007a44d59dad44  mov r8d, 0x00
00007a44d59dad4a  lea r9, [r15+0x3A8]
00007a44d59dad51  movaps [rdi], xmm13
00007a44d59dad55  movaps [rsi], xmm1
00007a44d59dad58  movaps [rdx], xmm15
00007a44d59dad5c  movaps [rcx], xmm14
00007a44d59dad60  mov rax, 0x56179A4B1A50
00007a44d59dad6a  call rax
00007a44d59dad6c  movaps xmm13, [rsp]
00007a44d59dad71  add rsp, 0x40
00007a44d59dad75  vmovaps xmm0, [rsp]
00007a44d59dad7a  vmovaps xmm1, [rsp+0x10]
00007a44d59dad80  vmovaps xmm2, [rsp+0x20]
00007a44d59dad86  vmovaps xmm3, [rsp+0x30]
00007a44d59dad8c  vmovaps xmm4, [rsp+0x40]
00007a44d59dad92  vmovaps xmm5, [rsp+0x50]
00007a44d59dad98  vmovaps xmm6, [rsp+0x60]
00007a44d59dad9e  vmovaps xmm7, [rsp+0x70]
00007a44d59dada4  vmovaps xmm8, [rsp+0x80]
00007a44d59dadad  vmovaps xmm9, [rsp+0x90]
00007a44d59dadb6  vmovaps xmm10, [rsp+0xA0]
00007a44d59dadbf  vmovaps xmm11, [rsp+0xB0]
00007a44d59dadc8  vmovaps xmm12, [rsp+0xC0]
00007a44d59dadd1  vmovaps xmm14, [rsp+0xD0]
00007a44d59dadda  vmovaps xmm15, [rsp+0xE0]
00007a44d59dade3  add rsp, 0xF0
00007a44d59dadea  pop r11
00007a44d59dadec  pop r10
00007a44d59dadee  pop r9
00007a44d59dadf0  pop r8
00007a44d59dadf2  pop rsi
00007a44d59dadf3  pop rdi
00007a44d59dadf4  pop rdx
00007a44d59dadf5  pop rcx
00007a44d59dadf6  pop rax
00007a44d59dadf7  add rsp, 0x08
00007a44d59dadfb  jmp 0x00007A44D59D9FEA
00007a44d59dae00  sub rsp, 0x08
00007a44d59dae04  push rax
00007a44d59dae05  push rcx
00007a44d59dae06  push rdx
00007a44d59dae07  push rdi
00007a44d59dae08  push rsi
00007a44d59dae09  push r8
00007a44d59dae0b  push r9
00007a44d59dae0d  push r10
00007a44d59dae0f  push r11
00007a44d59dae11  sub rsp, 0xF0
00007a44d59dae18  vmovaps [rsp], xmm0
00007a44d59dae1d  vmovaps [rsp+0x10], xmm1
00007a44d59dae23  vmovaps [rsp+0x20], xmm2
00007a44d59dae29  vmovaps [rsp+0x30], xmm3
00007a44d59dae2f  vmovaps [rsp+0x40], xmm4
00007a44d59dae35  vmovaps [rsp+0x50], xmm5
00007a44d59dae3b  vmovaps [rsp+0x60], xmm6
00007a44d59dae41  vmovaps [rsp+0x70], xmm7
00007a44d59dae47  vmovaps [rsp+0x80], xmm8
00007a44d59dae50  vmovaps [rsp+0x90], xmm9
00007a44d59dae59  vmovaps [rsp+0xA0], xmm10
00007a44d59dae62  vmovaps [rsp+0xB0], xmm11
00007a44d59dae6b  vmovaps [rsp+0xC0], xmm12
00007a44d59dae74  vmovaps [rsp+0xD0], xmm13
00007a44d59dae7d  vmovaps [rsp+0xE0], xmm15
00007a44d59dae86  sub rsp, 0x40
00007a44d59dae8a  lea rdi, [rsp]
00007a44d59dae8e  lea rsi, [rsp+0x10]
00007a44d59dae93  lea rdx, [rsp+0x20]
00007a44d59dae98  lea rcx, [rsp+0x30]
00007a44d59dae9d  mov r8d, 0x00
00007a44d59daea3  lea r9, [r15+0x3A8]
00007a44d59daeaa  movaps [rdi], xmm14
00007a44d59daeae  movaps [rsi], xmm15
00007a44d59daeb2  movaps [rdx], xmm2
00007a44d59daeb5  movaps [rcx], xmm1
00007a44d59daeb8  mov rax, 0x56179A4B1A50
00007a44d59daec2  call rax
00007a44d59daec4  movaps xmm14, [rsp]
00007a44d59daec9  add rsp, 0x40
00007a44d59daecd  vmovaps xmm0, [rsp]
00007a44d59daed2  vmovaps xmm1, [rsp+0x10]
00007a44d59daed8  vmovaps xmm2, [rsp+0x20]
00007a44d59daede  vmovaps xmm3, [rsp+0x30]
00007a44d59daee4  vmovaps xmm4, [rsp+0x40]
00007a44d59daeea  vmovaps xmm5, [rsp+0x50]
00007a44d59daef0  vmovaps xmm6, [rsp+0x60]
00007a44d59daef6  vmovaps xmm7, [rsp+0x70]
00007a44d59daefc  vmovaps xmm8, [rsp+0x80]
00007a44d59daf05  vmovaps xmm9, [rsp+0x90]
00007a44d59daf0e  vmovaps xmm10, [rsp+0xA0]
00007a44d59daf17  vmovaps xmm11, [rsp+0xB0]
00007a44d59daf20  vmovaps xmm12, [rsp+0xC0]
00007a44d59daf29  vmovaps xmm13, [rsp+0xD0]
00007a44d59daf32  vmovaps xmm15, [rsp+0xE0]
00007a44d59daf3b  add rsp, 0xF0
00007a44d59daf42  pop r11
00007a44d59daf44  pop r10
00007a44d59daf46  pop r9
00007a44d59daf48  pop r8
00007a44d59daf4a  pop rsi
00007a44d59daf4b  pop rdi
00007a44d59daf4c  pop rdx
00007a44d59daf4d  pop rcx
00007a44d59daf4e  pop rax
00007a44d59daf4f  add rsp, 0x08
00007a44d59daf53  jmp 0x00007A44D59DA01C
00007a44d59daf58  sub rsp, 0x08
00007a44d59daf5c  push rax
00007a44d59daf5d  push rcx
00007a44d59daf5e  push rdx
00007a44d59daf5f  push rdi
00007a44d59daf60  push rsi
00007a44d59daf61  push r8
00007a44d59daf63  push r9
00007a44d59daf65  push r10
00007a44d59daf67  push r11
00007a44d59daf69  sub rsp, 0xF0
00007a44d59daf70  vmovaps [rsp], xmm0
00007a44d59daf75  vmovaps [rsp+0x10], xmm1
00007a44d59daf7b  vmovaps [rsp+0x20], xmm3
00007a44d59daf81  vmovaps [rsp+0x30], xmm4
00007a44d59daf87  vmovaps [rsp+0x40], xmm5
00007a44d59daf8d  vmovaps [rsp+0x50], xmm6
00007a44d59daf93  vmovaps [rsp+0x60], xmm7
00007a44d59daf99  vmovaps [rsp+0x70], xmm8
00007a44d59daf9f  vmovaps [rsp+0x80], xmm9
00007a44d59dafa8  vmovaps [rsp+0x90], xmm10
00007a44d59dafb1  vmovaps [rsp+0xA0], xmm11
00007a44d59dafba  vmovaps [rsp+0xB0], xmm12
00007a44d59dafc3  vmovaps [rsp+0xC0], xmm13
00007a44d59dafcc  vmovaps [rsp+0xD0], xmm14
00007a44d59dafd5  vmovaps [rsp+0xE0], xmm15
00007a44d59dafde  sub rsp, 0x40
00007a44d59dafe2  lea rdi, [rsp]
00007a44d59dafe6  lea rsi, [rsp+0x10]
00007a44d59dafeb  lea rdx, [rsp+0x20]
00007a44d59daff0  lea rcx, [rsp+0x30]
00007a44d59daff5  mov r8d, 0x00
00007a44d59daffb  lea r9, [r15+0x3A8]
00007a44d59db002  movaps [rdi], xmm2
00007a44d59db005  movaps [rsi], xmm15
00007a44d59db009  movaps [rdx], xmm12
00007a44d59db00d  movaps [rcx], xmm1
00007a44d59db010  mov rax, 0x56179A4B1A50
00007a44d59db01a  call rax
00007a44d59db01c  movaps xmm2, [rsp]
00007a44d59db020  add rsp, 0x40
00007a44d59db024  vmovaps xmm0, [rsp]
00007a44d59db029  vmovaps xmm1, [rsp+0x10]
00007a44d59db02f  vmovaps xmm3, [rsp+0x20]
00007a44d59db035  vmovaps xmm4, [rsp+0x30]
00007a44d59db03b  vmovaps xmm5, [rsp+0x40]
00007a44d59db041  vmovaps xmm6, [rsp+0x50]
00007a44d59db047  vmovaps xmm7, [rsp+0x60]
00007a44d59db04d  vmovaps xmm8, [rsp+0x70]
00007a44d59db053  vmovaps xmm9, [rsp+0x80]
00007a44d59db05c  vmovaps xmm10, [rsp+0x90]
00007a44d59db065  vmovaps xmm11, [rsp+0xA0]
00007a44d59db06e  vmovaps xmm12, [rsp+0xB0]
00007a44d59db077  vmovaps xmm13, [rsp+0xC0]
00007a44d59db080  vmovaps xmm14, [rsp+0xD0]
00007a44d59db089  vmovaps xmm15, [rsp+0xE0]
00007a44d59db092  add rsp, 0xF0
00007a44d59db099  pop r11
00007a44d59db09b  pop r10
00007a44d59db09d  pop r9
00007a44d59db09f  pop r8
00007a44d59db0a1  pop rsi
00007a44d59db0a2  pop rdi
00007a44d59db0a3  pop rdx
00007a44d59db0a4  pop rcx
00007a44d59db0a5  pop rax
00007a44d59db0a6  add rsp, 0x08
00007a44d59db0aa  jmp 0x00007A44D59DA059
00007a44d59db0af  sub rsp, 0x08
00007a44d59db0b3  push rax
00007a44d59db0b4  push rcx
00007a44d59db0b5  push rdx
00007a44d59db0b6  push rdi
00007a44d59db0b7  push rsi
00007a44d59db0b8  push r8
00007a44d59db0ba  push r9
00007a44d59db0bc  push r10
00007a44d59db0be  push r11
00007a44d59db0c0  sub rsp, 0xF0
00007a44d59db0c7  vmovaps [rsp], xmm0
00007a44d59db0cc  vmovaps [rsp+0x10], xmm1
00007a44d59db0d2  vmovaps [rsp+0x20], xmm2
00007a44d59db0d8  vmovaps [rsp+0x30], xmm3
00007a44d59db0de  vmovaps [rsp+0x40], xmm4
00007a44d59db0e4  vmovaps [rsp+0x50], xmm5
00007a44d59db0ea  vmovaps [rsp+0x60], xmm6
00007a44d59db0f0  vmovaps [rsp+0x70], xmm7
00007a44d59db0f6  vmovaps [rsp+0x80], xmm8
00007a44d59db0ff  vmovaps [rsp+0x90], xmm9
00007a44d59db108  vmovaps [rsp+0xA0], xmm10
00007a44d59db111  vmovaps [rsp+0xB0], xmm11
00007a44d59db11a  vmovaps [rsp+0xC0], xmm13
00007a44d59db123  vmovaps [rsp+0xD0], xmm14
00007a44d59db12c  vmovaps [rsp+0xE0], xmm15
00007a44d59db135  sub rsp, 0x40
00007a44d59db139  lea rdi, [rsp]
00007a44d59db13d  lea rsi, [rsp+0x10]
00007a44d59db142  lea rdx, [rsp+0x20]
00007a44d59db147  lea rcx, [rsp+0x30]
00007a44d59db14c  mov r8d, 0x00
00007a44d59db152  lea r9, [r15+0x3A8]
00007a44d59db159  movaps [rdi], xmm12
00007a44d59db15d  movaps [rsi], xmm14
00007a44d59db161  movaps [rdx], xmm3
00007a44d59db164  movaps [rcx], xmm15
00007a44d59db168  mov rax, 0x56179A4B1A50
00007a44d59db172  call rax
00007a44d59db174  movaps xmm12, [rsp]
00007a44d59db179  add rsp, 0x40
00007a44d59db17d  vmovaps xmm0, [rsp]
00007a44d59db182  vmovaps xmm1, [rsp+0x10]
00007a44d59db188  vmovaps xmm2, [rsp+0x20]
00007a44d59db18e  vmovaps xmm3, [rsp+0x30]
00007a44d59db194  vmovaps xmm4, [rsp+0x40]
00007a44d59db19a  vmovaps xmm5, [rsp+0x50]
00007a44d59db1a0  vmovaps xmm6, [rsp+0x60]
00007a44d59db1a6  vmovaps xmm7, [rsp+0x70]
00007a44d59db1ac  vmovaps xmm8, [rsp+0x80]
00007a44d59db1b5  vmovaps xmm9, [rsp+0x90]
00007a44d59db1be  vmovaps xmm10, [rsp+0xA0]
00007a44d59db1c7  vmovaps xmm11, [rsp+0xB0]
00007a44d59db1d0  vmovaps xmm13, [rsp+0xC0]
00007a44d59db1d9  vmovaps xmm14, [rsp+0xD0]
00007a44d59db1e2  vmovaps xmm15, [rsp+0xE0]
00007a44d59db1eb  add rsp, 0xF0
00007a44d59db1f2  pop r11
00007a44d59db1f4  pop r10
00007a44d59db1f6  pop r9
00007a44d59db1f8  pop r8
00007a44d59db1fa  pop rsi
00007a44d59db1fb  pop rdi
00007a44d59db1fc  pop rdx
00007a44d59db1fd  pop rcx
00007a44d59db1fe  pop rax
00007a44d59db1ff  add rsp, 0x08
00007a44d59db203  jmp 0x00007A44D59DA0B3
00007a44d59db208  sub rsp, 0x08
00007a44d59db20c  push rax
00007a44d59db20d  push rcx
00007a44d59db20e  push rdx
00007a44d59db20f  push rdi
00007a44d59db210  push rsi
00007a44d59db211  push r8
00007a44d59db213  push r9
00007a44d59db215  push r10
00007a44d59db217  push r11
00007a44d59db219  sub rsp, 0xF0
00007a44d59db220  vmovaps [rsp], xmm0
00007a44d59db225  vmovaps [rsp+0x10], xmm1
00007a44d59db22b  vmovaps [rsp+0x20], xmm2
00007a44d59db231  vmovaps [rsp+0x30], xmm3
00007a44d59db237  vmovaps [rsp+0x40], xmm4
00007a44d59db23d  vmovaps [rsp+0x50], xmm5
00007a44d59db243  vmovaps [rsp+0x60], xmm6
00007a44d59db249  vmovaps [rsp+0x70], xmm7
00007a44d59db24f  vmovaps [rsp+0x80], xmm8
00007a44d59db258  vmovaps [rsp+0x90], xmm10
00007a44d59db261  vmovaps [rsp+0xA0], xmm11
00007a44d59db26a  vmovaps [rsp+0xB0], xmm12
00007a44d59db273  vmovaps [rsp+0xC0], xmm13
00007a44d59db27c  vmovaps [rsp+0xD0], xmm14
00007a44d59db285  vmovaps [rsp+0xE0], xmm15
00007a44d59db28e  sub rsp, 0x40
00007a44d59db292  lea rdi, [rsp]
00007a44d59db296  lea rsi, [rsp+0x10]
00007a44d59db29b  lea rdx, [rsp+0x20]
00007a44d59db2a0  lea rcx, [rsp+0x30]
00007a44d59db2a5  mov r8d, 0x00
00007a44d59db2ab  lea r9, [r15+0x3A8]
00007a44d59db2b2  movaps [rdi], xmm9
00007a44d59db2b6  movaps [rsi], xmm13
00007a44d59db2ba  movaps [rdx], xmm14
00007a44d59db2be  movaps [rcx], xmm6
00007a44d59db2c1  mov rax, 0x56179A4B1A50
00007a44d59db2cb  call rax
00007a44d59db2cd  movaps xmm9, [rsp]
00007a44d59db2d2  add rsp, 0x40
00007a44d59db2d6  vmovaps xmm0, [rsp]
00007a44d59db2db  vmovaps xmm1, [rsp+0x10]
00007a44d59db2e1  vmovaps xmm2, [rsp+0x20]
00007a44d59db2e7  vmovaps xmm3, [rsp+0x30]
00007a44d59db2ed  vmovaps xmm4, [rsp+0x40]
00007a44d59db2f3  vmovaps xmm5, [rsp+0x50]
00007a44d59db2f9  vmovaps xmm6, [rsp+0x60]
00007a44d59db2ff  vmovaps xmm7, [rsp+0x70]
00007a44d59db305  vmovaps xmm8, [rsp+0x80]
00007a44d59db30e  vmovaps xmm10, [rsp+0x90]
00007a44d59db317  vmovaps xmm11, [rsp+0xA0]
00007a44d59db320  vmovaps xmm12, [rsp+0xB0]
00007a44d59db329  vmovaps xmm13, [rsp+0xC0]
00007a44d59db332  vmovaps xmm14, [rsp+0xD0]
00007a44d59db33b  vmovaps xmm15, [rsp+0xE0]
00007a44d59db344  add rsp, 0xF0
00007a44d59db34b  pop r11
00007a44d59db34d  pop r10
00007a44d59db34f  pop r9
00007a44d59db351  pop r8
00007a44d59db353  pop rsi
00007a44d59db354  pop rdi
00007a44d59db355  pop rdx
00007a44d59db356  pop rcx
00007a44d59db357  pop rax
00007a44d59db358  add rsp, 0x08
00007a44d59db35c  jmp 0x00007A44D59DA15D
00007a44d59db361  sub rsp, 0x08
00007a44d59db365  push rax
00007a44d59db366  push rcx
00007a44d59db367  push rdx
00007a44d59db368  push rdi
00007a44d59db369  push rsi
00007a44d59db36a  push r8
00007a44d59db36c  push r9
00007a44d59db36e  push r10
00007a44d59db370  push r11
00007a44d59db372  sub rsp, 0xF0
00007a44d59db379  vmovaps [rsp], xmm0
00007a44d59db37e  vmovaps [rsp+0x10], xmm1
00007a44d59db384  vmovaps [rsp+0x20], xmm2
00007a44d59db38a  vmovaps [rsp+0x30], xmm4
00007a44d59db390  vmovaps [rsp+0x40], xmm5
00007a44d59db396  vmovaps [rsp+0x50], xmm6
00007a44d59db39c  vmovaps [rsp+0x60], xmm7
00007a44d59db3a2  vmovaps [rsp+0x70], xmm8
00007a44d59db3a8  vmovaps [rsp+0x80], xmm9
00007a44d59db3b1  vmovaps [rsp+0x90], xmm10
00007a44d59db3ba  vmovaps [rsp+0xA0], xmm11
00007a44d59db3c3  vmovaps [rsp+0xB0], xmm12
00007a44d59db3cc  vmovaps [rsp+0xC0], xmm13
00007a44d59db3d5  vmovaps [rsp+0xD0], xmm14
00007a44d59db3de  vmovaps [rsp+0xE0], xmm15
00007a44d59db3e7  sub rsp, 0x40
00007a44d59db3eb  lea rdi, [rsp]
00007a44d59db3ef  lea rsi, [rsp+0x10]
00007a44d59db3f4  lea rdx, [rsp+0x20]
00007a44d59db3f9  lea rcx, [rsp+0x30]
00007a44d59db3fe  mov r8d, 0x00
00007a44d59db404  lea r9, [r15+0x3A8]
00007a44d59db40b  movaps [rdi], xmm3
00007a44d59db40e  movaps [rsi], xmm13
00007a44d59db412  movaps [rdx], xmm6
00007a44d59db415  movaps [rcx], xmm14
00007a44d59db419  mov rax, 0x56179A4B1A50
00007a44d59db423  call rax
00007a44d59db425  movaps xmm3, [rsp]
00007a44d59db429  add rsp, 0x40
00007a44d59db42d  vmovaps xmm0, [rsp]
00007a44d59db432  vmovaps xmm1, [rsp+0x10]
00007a44d59db438  vmovaps xmm2, [rsp+0x20]
00007a44d59db43e  vmovaps xmm4, [rsp+0x30]
00007a44d59db444  vmovaps xmm5, [rsp+0x40]
00007a44d59db44a  vmovaps xmm6, [rsp+0x50]
00007a44d59db450  vmovaps xmm7, [rsp+0x60]
00007a44d59db456  vmovaps xmm8, [rsp+0x70]
00007a44d59db45c  vmovaps xmm9, [rsp+0x80]
00007a44d59db465  vmovaps xmm10, [rsp+0x90]
00007a44d59db46e  vmovaps xmm11, [rsp+0xA0]
00007a44d59db477  vmovaps xmm12, [rsp+0xB0]
00007a44d59db480  vmovaps xmm13, [rsp+0xC0]
00007a44d59db489  vmovaps xmm14, [rsp+0xD0]
00007a44d59db492  vmovaps xmm15, [rsp+0xE0]
00007a44d59db49b  add rsp, 0xF0
00007a44d59db4a2  pop r11
00007a44d59db4a4  pop r10
00007a44d59db4a6  pop r9
00007a44d59db4a8  pop r8
00007a44d59db4aa  pop rsi
00007a44d59db4ab  pop rdi
00007a44d59db4ac  pop rdx
00007a44d59db4ad  pop rcx
00007a44d59db4ae  pop rax
00007a44d59db4af  add rsp, 0x08
00007a44d59db4b3  jmp 0x00007A44D59DA19A
00007a44d59db4b8  sub rsp, 0x08
00007a44d59db4bc  push rax
00007a44d59db4bd  push rcx
00007a44d59db4be  push rdx
00007a44d59db4bf  push rdi
00007a44d59db4c0  push rsi
00007a44d59db4c1  push r8
00007a44d59db4c3  push r9
00007a44d59db4c5  push r10
00007a44d59db4c7  push r11
00007a44d59db4c9  sub rsp, 0xF0
00007a44d59db4d0  vmovaps [rsp], xmm0
00007a44d59db4d5  vmovaps [rsp+0x10], xmm1
00007a44d59db4db  vmovaps [rsp+0x20], xmm2
00007a44d59db4e1  vmovaps [rsp+0x30], xmm3
00007a44d59db4e7  vmovaps [rsp+0x40], xmm4
00007a44d59db4ed  vmovaps [rsp+0x50], xmm5
00007a44d59db4f3  vmovaps [rsp+0x60], xmm7
00007a44d59db4f9  vmovaps [rsp+0x70], xmm8
00007a44d59db4ff  vmovaps [rsp+0x80], xmm9
00007a44d59db508  vmovaps [rsp+0x90], xmm10
00007a44d59db511  vmovaps [rsp+0xA0], xmm11
00007a44d59db51a  vmovaps [rsp+0xB0], xmm12
00007a44d59db523  vmovaps [rsp+0xC0], xmm13
00007a44d59db52c  vmovaps [rsp+0xD0], xmm14
00007a44d59db535  vmovaps [rsp+0xE0], xmm15
00007a44d59db53e  sub rsp, 0x40
00007a44d59db542  lea rdi, [rsp]
00007a44d59db546  lea rsi, [rsp+0x10]
00007a44d59db54b  lea rdx, [rsp+0x20]
00007a44d59db550  lea rcx, [rsp+0x30]
00007a44d59db555  mov r8d, 0x00
00007a44d59db55b  lea r9, [r15+0x3A8]
00007a44d59db562  movaps [rdi], xmm6
00007a44d59db565  movaps [rsi], xmm2
00007a44d59db568  movaps [rdx], xmm14
00007a44d59db56c  movaps [rcx], xmm1
00007a44d59db56f  mov rax, 0x56179A4B1A50
00007a44d59db579  call rax
00007a44d59db57b  movaps xmm6, [rsp]
00007a44d59db57f  add rsp, 0x40
00007a44d59db583  vmovaps xmm0, [rsp]
00007a44d59db588  vmovaps xmm1, [rsp+0x10]
00007a44d59db58e  vmovaps xmm2, [rsp+0x20]
00007a44d59db594  vmovaps xmm3, [rsp+0x30]
00007a44d59db59a  vmovaps xmm4, [rsp+0x40]
00007a44d59db5a0  vmovaps xmm5, [rsp+0x50]
00007a44d59db5a6  vmovaps xmm7, [rsp+0x60]
00007a44d59db5ac  vmovaps xmm8, [rsp+0x70]
00007a44d59db5b2  vmovaps xmm9, [rsp+0x80]
00007a44d59db5bb  vmovaps xmm10, [rsp+0x90]
00007a44d59db5c4  vmovaps xmm11, [rsp+0xA0]
00007a44d59db5cd  vmovaps xmm12, [rsp+0xB0]
00007a44d59db5d6  vmovaps xmm13, [rsp+0xC0]
00007a44d59db5df  vmovaps xmm14, [rsp+0xD0]
00007a44d59db5e8  vmovaps xmm15, [rsp+0xE0]
00007a44d59db5f1  add rsp, 0xF0
00007a44d59db5f8  pop r11
00007a44d59db5fa  pop r10
00007a44d59db5fc  pop r9
00007a44d59db5fe  pop r8
00007a44d59db600  pop rsi
00007a44d59db601  pop rdi
00007a44d59db602  pop rdx
00007a44d59db603  pop rcx
00007a44d59db604  pop rax
00007a44d59db605  add rsp, 0x08
00007a44d59db609  jmp 0x00007A44D59DA1C7
00007a44d59db60e  sub rsp, 0x08
00007a44d59db612  push rax
00007a44d59db613  push rcx
00007a44d59db614  push rdx
00007a44d59db615  push rdi
00007a44d59db616  push rsi
00007a44d59db617  push r8
00007a44d59db619  push r9
00007a44d59db61b  push r10
00007a44d59db61d  push r11
00007a44d59db61f  sub rsp, 0xF0
00007a44d59db626  vmovaps [rsp], xmm0
00007a44d59db62b  vmovaps [rsp+0x10], xmm1
00007a44d59db631  vmovaps [rsp+0x20], xmm2
00007a44d59db637  vmovaps [rsp+0x30], xmm3
00007a44d59db63d  vmovaps [rsp+0x40], xmm4
00007a44d59db643  vmovaps [rsp+0x50], xmm5
00007a44d59db649  vmovaps [rsp+0x60], xmm6
00007a44d59db64f  vmovaps [rsp+0x70], xmm7
00007a44d59db655  vmovaps [rsp+0x80], xmm8
00007a44d59db65e  vmovaps [rsp+0x90], xmm9
00007a44d59db667  vmovaps [rsp+0xA0], xmm10
00007a44d59db670  vmovaps [rsp+0xB0], xmm11
00007a44d59db679  vmovaps [rsp+0xC0], xmm12
00007a44d59db682  vmovaps [rsp+0xD0], xmm14
00007a44d59db68b  vmovaps [rsp+0xE0], xmm15
00007a44d59db694  sub rsp, 0x40
00007a44d59db698  lea rdi, [rsp]
00007a44d59db69c  lea rsi, [rsp+0x10]
00007a44d59db6a1  lea rdx, [rsp+0x20]
00007a44d59db6a6  lea rcx, [rsp+0x30]
00007a44d59db6ab  mov r8d, 0x00
00007a44d59db6b1  lea r9, [r15+0x3A8]
00007a44d59db6b8  movaps [rdi], xmm13
00007a44d59db6bc  movaps [rsi], xmm12
00007a44d59db6c0  movaps [rdx], xmm14
00007a44d59db6c4  movaps [rcx], xmm1
00007a44d59db6c7  mov rax, 0x56179A4B1A50
00007a44d59db6d1  call rax
00007a44d59db6d3  movaps xmm13, [rsp]
00007a44d59db6d8  add rsp, 0x40
00007a44d59db6dc  vmovaps xmm0, [rsp]
00007a44d59db6e1  vmovaps xmm1, [rsp+0x10]
00007a44d59db6e7  vmovaps xmm2, [rsp+0x20]
00007a44d59db6ed  vmovaps xmm3, [rsp+0x30]
00007a44d59db6f3  vmovaps xmm4, [rsp+0x40]
00007a44d59db6f9  vmovaps xmm5, [rsp+0x50]
00007a44d59db6ff  vmovaps xmm6, [rsp+0x60]
00007a44d59db705  vmovaps xmm7, [rsp+0x70]
00007a44d59db70b  vmovaps xmm8, [rsp+0x80]
00007a44d59db714  vmovaps xmm9, [rsp+0x90]
00007a44d59db71d  vmovaps xmm10, [rsp+0xA0]
00007a44d59db726  vmovaps xmm11, [rsp+0xB0]
00007a44d59db72f  vmovaps xmm12, [rsp+0xC0]
00007a44d59db738  vmovaps xmm14, [rsp+0xD0]
00007a44d59db741  vmovaps xmm15, [rsp+0xE0]
00007a44d59db74a  add rsp, 0xF0
00007a44d59db751  pop r11
00007a44d59db753  pop r10
00007a44d59db755  pop r9
00007a44d59db757  pop r8
00007a44d59db759  pop rsi
00007a44d59db75a  pop rdi
00007a44d59db75b  pop rdx
00007a44d59db75c  pop rcx
00007a44d59db75d  pop rax
00007a44d59db75e  add rsp, 0x08
00007a44d59db762  jmp 0x00007A44D59DA1F9
00007a44d59db767  sub rsp, 0x08
00007a44d59db76b  push rax
00007a44d59db76c  push rcx
00007a44d59db76d  push rdx
00007a44d59db76e  push rdi
00007a44d59db76f  push rsi
00007a44d59db770  push r8
00007a44d59db772  push r9
00007a44d59db774  push r10
00007a44d59db776  push r11
00007a44d59db778  sub rsp, 0xF0
00007a44d59db77f  vmovaps [rsp], xmm0
00007a44d59db784  vmovaps [rsp+0x10], xmm1
00007a44d59db78a  vmovaps [rsp+0x20], xmm2
00007a44d59db790  vmovaps [rsp+0x30], xmm3
00007a44d59db796  vmovaps [rsp+0x40], xmm4
00007a44d59db79c  vmovaps [rsp+0x50], xmm5
00007a44d59db7a2  vmovaps [rsp+0x60], xmm6
00007a44d59db7a8  vmovaps [rsp+0x70], xmm7
00007a44d59db7ae  vmovaps [rsp+0x80], xmm8
00007a44d59db7b7  vmovaps [rsp+0x90], xmm9
00007a44d59db7c0  vmovaps [rsp+0xA0], xmm10
00007a44d59db7c9  vmovaps [rsp+0xB0], xmm11
00007a44d59db7d2  vmovaps [rsp+0xC0], xmm13
00007a44d59db7db  vmovaps [rsp+0xD0], xmm14
00007a44d59db7e4  vmovaps [rsp+0xE0], xmm15
00007a44d59db7ed  sub rsp, 0x40
00007a44d59db7f1  lea rdi, [rsp]
00007a44d59db7f5  lea rsi, [rsp+0x10]
00007a44d59db7fa  lea rdx, [rsp+0x20]
00007a44d59db7ff  lea rcx, [rsp+0x30]
00007a44d59db804  mov r8d, 0x00
00007a44d59db80a  lea r9, [r15+0x3A8]
00007a44d59db811  movaps [rdi], xmm12
00007a44d59db815  movaps [rsi], xmm3
00007a44d59db818  movaps [rdx], xmm14
00007a44d59db81c  movaps [rcx], xmm5
00007a44d59db81f  mov rax, 0x56179A4B1A50
00007a44d59db829  call rax
00007a44d59db82b  movaps xmm12, [rsp]
00007a44d59db830  add rsp, 0x40
00007a44d59db834  vmovaps xmm0, [rsp]
00007a44d59db839  vmovaps xmm1, [rsp+0x10]
00007a44d59db83f  vmovaps xmm2, [rsp+0x20]
00007a44d59db845  vmovaps xmm3, [rsp+0x30]
00007a44d59db84b  vmovaps xmm4, [rsp+0x40]
00007a44d59db851  vmovaps xmm5, [rsp+0x50]
00007a44d59db857  vmovaps xmm6, [rsp+0x60]
00007a44d59db85d  vmovaps xmm7, [rsp+0x70]
00007a44d59db863  vmovaps xmm8, [rsp+0x80]
00007a44d59db86c  vmovaps xmm9, [rsp+0x90]
00007a44d59db875  vmovaps xmm10, [rsp+0xA0]
00007a44d59db87e  vmovaps xmm11, [rsp+0xB0]
00007a44d59db887  vmovaps xmm13, [rsp+0xC0]
00007a44d59db890  vmovaps xmm14, [rsp+0xD0]
00007a44d59db899  vmovaps xmm15, [rsp+0xE0]
00007a44d59db8a2  add rsp, 0xF0
00007a44d59db8a9  pop r11
00007a44d59db8ab  pop r10
00007a44d59db8ad  pop r9
00007a44d59db8af  pop r8
00007a44d59db8b1  pop rsi
00007a44d59db8b2  pop rdi
00007a44d59db8b3  pop rdx
00007a44d59db8b4  pop rcx
00007a44d59db8b5  pop rax
00007a44d59db8b6  add rsp, 0x08
00007a44d59db8ba  jmp 0x00007A44D59DA256
00007a44d59db8bf  sub rsp, 0x08
00007a44d59db8c3  push rax
00007a44d59db8c4  push rcx
00007a44d59db8c5  push rdx
00007a44d59db8c6  push rdi
00007a44d59db8c7  push rsi
00007a44d59db8c8  push r8
00007a44d59db8ca  push r9
00007a44d59db8cc  push r10
00007a44d59db8ce  push r11
00007a44d59db8d0  sub rsp, 0xF0
00007a44d59db8d7  vmovaps [rsp], xmm0
00007a44d59db8dc  vmovaps [rsp+0x10], xmm1
00007a44d59db8e2  vmovaps [rsp+0x20], xmm2
00007a44d59db8e8  vmovaps [rsp+0x30], xmm3
00007a44d59db8ee  vmovaps [rsp+0x40], xmm4
00007a44d59db8f4  vmovaps [rsp+0x50], xmm5
00007a44d59db8fa  vmovaps [rsp+0x60], xmm6
00007a44d59db900  vmovaps [rsp+0x70], xmm7
00007a44d59db906  vmovaps [rsp+0x80], xmm8
00007a44d59db90f  vmovaps [rsp+0x90], xmm9
00007a44d59db918  vmovaps [rsp+0xA0], xmm11
00007a44d59db921  vmovaps [rsp+0xB0], xmm12
00007a44d59db92a  vmovaps [rsp+0xC0], xmm13
00007a44d59db933  vmovaps [rsp+0xD0], xmm14
00007a44d59db93c  vmovaps [rsp+0xE0], xmm15
00007a44d59db945  sub rsp, 0x40
00007a44d59db949  lea rdi, [rsp]
00007a44d59db94d  lea rsi, [rsp+0x10]
00007a44d59db952  lea rdx, [rsp+0x20]
00007a44d59db957  lea rcx, [rsp+0x30]
00007a44d59db95c  mov r8d, 0x00
00007a44d59db962  lea r9, [r15+0x3A8]
00007a44d59db969  movaps [rdi], xmm10
00007a44d59db96d  movaps [rsi], xmm9
00007a44d59db971  movaps [rdx], xmm7
00007a44d59db974  movaps [rcx], xmm14
00007a44d59db978  mov rax, 0x56179A4B1A50
00007a44d59db982  call rax
00007a44d59db984  movaps xmm10, [rsp]
00007a44d59db989  add rsp, 0x40
00007a44d59db98d  vmovaps xmm0, [rsp]
00007a44d59db992  vmovaps xmm1, [rsp+0x10]
00007a44d59db998  vmovaps xmm2, [rsp+0x20]
00007a44d59db99e  vmovaps xmm3, [rsp+0x30]
00007a44d59db9a4  vmovaps xmm4, [rsp+0x40]
00007a44d59db9aa  vmovaps xmm5, [rsp+0x50]
00007a44d59db9b0  vmovaps xmm6, [rsp+0x60]
00007a44d59db9b6  vmovaps xmm7, [rsp+0x70]
00007a44d59db9bc  vmovaps xmm8, [rsp+0x80]
00007a44d59db9c5  vmovaps xmm9, [rsp+0x90]
00007a44d59db9ce  vmovaps xmm11, [rsp+0xA0]
00007a44d59db9d7  vmovaps xmm12, [rsp+0xB0]
00007a44d59db9e0  vmovaps xmm13, [rsp+0xC0]
00007a44d59db9e9  vmovaps xmm14, [rsp+0xD0]
00007a44d59db9f2  vmovaps xmm15, [rsp+0xE0]
00007a44d59db9fb  add rsp, 0xF0
00007a44d59dba02  pop r11
00007a44d59dba04  pop r10
00007a44d59dba06  pop r9
00007a44d59dba08  pop r8
00007a44d59dba0a  pop rsi
00007a44d59dba0b  pop rdi
00007a44d59dba0c  pop rdx
00007a44d59dba0d  pop rcx
00007a44d59dba0e  pop rax
00007a44d59dba0f  add rsp, 0x08
00007a44d59dba13  jmp 0x00007A44D59DA27C
00007a44d59dba18  call 0x00007A44D580D4E0
00007a44d59dba1d  jmp 0x00007A44D59DA289
00007a44d59dba22  sub rsp, 0x08
00007a44d59dba26  push rax
00007a44d59dba27  push rcx
00007a44d59dba28  push rdx
00007a44d59dba29  push rdi
00007a44d59dba2a  push rsi
00007a44d59dba2b  push r8
00007a44d59dba2d  push r9
00007a44d59dba2f  push r10
00007a44d59dba31  push r11
00007a44d59dba33  sub rsp, 0xF0
00007a44d59dba3a  vmovaps [rsp], xmm0
00007a44d59dba3f  vmovaps [rsp+0x10], xmm1
00007a44d59dba45  vmovaps [rsp+0x20], xmm2
00007a44d59dba4b  vmovaps [rsp+0x30], xmm3
00007a44d59dba51  vmovaps [rsp+0x40], xmm4
00007a44d59dba57  vmovaps [rsp+0x50], xmm6
00007a44d59dba5d  vmovaps [rsp+0x60], xmm7
00007a44d59dba63  vmovaps [rsp+0x70], xmm8
00007a44d59dba69  vmovaps [rsp+0x80], xmm9
00007a44d59dba72  vmovaps [rsp+0x90], xmm10
00007a44d59dba7b  vmovaps [rsp+0xA0], xmm11
00007a44d59dba84  vmovaps [rsp+0xB0], xmm12
00007a44d59dba8d  vmovaps [rsp+0xC0], xmm13
00007a44d59dba96  vmovaps [rsp+0xD0], xmm14
00007a44d59dba9f  vmovaps [rsp+0xE0], xmm15
00007a44d59dbaa8  sub rsp, 0x40
00007a44d59dbaac  lea rdi, [rsp]
00007a44d59dbab0  lea rsi, [rsp+0x10]
00007a44d59dbab5  lea rdx, [rsp+0x20]
00007a44d59dbaba  lea rcx, [rsp+0x30]
00007a44d59dbabf  mov r8d, 0x00
00007a44d59dbac5  lea r9, [r15+0x3A8]
00007a44d59dbacc  movaps [rdi], xmm5
00007a44d59dbacf  movaps [rsi], xmm6
00007a44d59dbad2  movaps [rdx], xmm7
00007a44d59dbad5  movaps [rcx], xmm9
00007a44d59dbad9  mov rax, 0x56179A4B1A50
00007a44d59dbae3  call rax
00007a44d59dbae5  movaps xmm5, [rsp]
00007a44d59dbae9  add rsp, 0x40
00007a44d59dbaed  vmovaps xmm0, [rsp]
00007a44d59dbaf2  vmovaps xmm1, [rsp+0x10]
00007a44d59dbaf8  vmovaps xmm2, [rsp+0x20]
00007a44d59dbafe  vmovaps xmm3, [rsp+0x30]
00007a44d59dbb04  vmovaps xmm4, [rsp+0x40]
00007a44d59dbb0a  vmovaps xmm6, [rsp+0x50]
00007a44d59dbb10  vmovaps xmm7, [rsp+0x60]
00007a44d59dbb16  vmovaps xmm8, [rsp+0x70]
00007a44d59dbb1c  vmovaps xmm9, [rsp+0x80]
00007a44d59dbb25  vmovaps xmm10, [rsp+0x90]
00007a44d59dbb2e  vmovaps xmm11, [rsp+0xA0]
00007a44d59dbb37  vmovaps xmm12, [rsp+0xB0]
00007a44d59dbb40  vmovaps xmm13, [rsp+0xC0]
00007a44d59dbb49  vmovaps xmm14, [rsp+0xD0]
00007a44d59dbb52  vmovaps xmm15, [rsp+0xE0]
00007a44d59dbb5b  add rsp, 0xF0
00007a44d59dbb62  pop r11
00007a44d59dbb64  pop r10
00007a44d59dbb66  pop r9
00007a44d59dbb68  pop r8
00007a44d59dbb6a  pop rsi
00007a44d59dbb6b  pop rdi
00007a44d59dbb6c  pop rdx
00007a44d59dbb6d  pop rcx
00007a44d59dbb6e  pop rax
00007a44d59dbb6f  add rsp, 0x08
00007a44d59dbb73  jmp 0x00007A44D59DA2BB
00007a44d59dbb78  sub rsp, 0x08
00007a44d59dbb7c  push rax
00007a44d59dbb7d  push rcx
00007a44d59dbb7e  push rdx
00007a44d59dbb7f  push rdi
00007a44d59dbb80  push rsi
00007a44d59dbb81  push r8
00007a44d59dbb83  push r9
00007a44d59dbb85  push r10
00007a44d59dbb87  push r11
00007a44d59dbb89  sub rsp, 0xF0
00007a44d59dbb90  vmovaps [rsp], xmm0
00007a44d59dbb95  vmovaps [rsp+0x10], xmm1
00007a44d59dbb9b  vmovaps [rsp+0x20], xmm2
00007a44d59dbba1  vmovaps [rsp+0x30], xmm3
00007a44d59dbba7  vmovaps [rsp+0x40], xmm4
00007a44d59dbbad  vmovaps [rsp+0x50], xmm5
00007a44d59dbbb3  vmovaps [rsp+0x60], xmm6
00007a44d59dbbb9  vmovaps [rsp+0x70], xmm8
00007a44d59dbbbf  vmovaps [rsp+0x80], xmm9
00007a44d59dbbc8  vmovaps [rsp+0x90], xmm10
00007a44d59dbbd1  vmovaps [rsp+0xA0], xmm11
00007a44d59dbbda  vmovaps [rsp+0xB0], xmm12
00007a44d59dbbe3  vmovaps [rsp+0xC0], xmm13
00007a44d59dbbec  vmovaps [rsp+0xD0], xmm14
00007a44d59dbbf5  vmovaps [rsp+0xE0], xmm15
00007a44d59dbbfe  sub rsp, 0x40
00007a44d59dbc02  lea rdi, [rsp]
00007a44d59dbc06  lea rsi, [rsp+0x10]
00007a44d59dbc0b  lea rdx, [rsp+0x20]
00007a44d59dbc10  lea rcx, [rsp+0x30]
00007a44d59dbc15  mov r8d, 0x00
00007a44d59dbc1b  lea r9, [r15+0x3A8]
00007a44d59dbc22  movaps [rdi], xmm7
00007a44d59dbc25  movaps [rsi], xmm13
00007a44d59dbc29  movaps [rdx], xmm1
00007a44d59dbc2c  movaps [rcx], xmm9
00007a44d59dbc30  mov rax, 0x56179A4B1A50
00007a44d59dbc3a  call rax
00007a44d59dbc3c  movaps xmm7, [rsp]
00007a44d59dbc40  add rsp, 0x40
00007a44d59dbc44  vmovaps xmm0, [rsp]
00007a44d59dbc49  vmovaps xmm1, [rsp+0x10]
00007a44d59dbc4f  vmovaps xmm2, [rsp+0x20]
00007a44d59dbc55  vmovaps xmm3, [rsp+0x30]
00007a44d59dbc5b  vmovaps xmm4, [rsp+0x40]
00007a44d59dbc61  vmovaps xmm5, [rsp+0x50]
00007a44d59dbc67  vmovaps xmm6, [rsp+0x60]
00007a44d59dbc6d  vmovaps xmm8, [rsp+0x70]
00007a44d59dbc73  vmovaps xmm9, [rsp+0x80]
00007a44d59dbc7c  vmovaps xmm10, [rsp+0x90]
00007a44d59dbc85  vmovaps xmm11, [rsp+0xA0]
00007a44d59dbc8e  vmovaps xmm12, [rsp+0xB0]
00007a44d59dbc97  vmovaps xmm13, [rsp+0xC0]
00007a44d59dbca0  vmovaps xmm14, [rsp+0xD0]
00007a44d59dbca9  vmovaps xmm15, [rsp+0xE0]
00007a44d59dbcb2  add rsp, 0xF0
00007a44d59dbcb9  pop r11
00007a44d59dbcbb  pop r10
00007a44d59dbcbd  pop r9
00007a44d59dbcbf  pop r8
00007a44d59dbcc1  pop rsi
00007a44d59dbcc2  pop rdi
00007a44d59dbcc3  pop rdx
00007a44d59dbcc4  pop rcx
00007a44d59dbcc5  pop rax
00007a44d59dbcc6  add rsp, 0x08
00007a44d59dbcca  jmp 0x00007A44D59DA2E0
00007a44d59dbccf  call 0x00007A44D580C260
00007a44d59dbcd4  jmp 0x00007A44D59DA303
00007a44d59dbcd9  call 0x00007A44D5807890
00007a44d59dbcde  jmp 0x00007A44D59DA30D
00007a44d59dbce3  sub rsp, 0x08
00007a44d59dbce7  push rax
00007a44d59dbce8  push rcx
00007a44d59dbce9  push rdx
00007a44d59dbcea  push rdi
00007a44d59dbceb  push rsi
00007a44d59dbcec  push r8
00007a44d59dbcee  push r9
00007a44d59dbcf0  push r10
00007a44d59dbcf2  push r11
00007a44d59dbcf4  sub rsp, 0xF0
00007a44d59dbcfb  vmovaps [rsp], xmm0
00007a44d59dbd00  vmovaps [rsp+0x10], xmm1
00007a44d59dbd06  vmovaps [rsp+0x20], xmm3
00007a44d59dbd0c  vmovaps [rsp+0x30], xmm4
00007a44d59dbd12  vmovaps [rsp+0x40], xmm5
00007a44d59dbd18  vmovaps [rsp+0x50], xmm6
00007a44d59dbd1e  vmovaps [rsp+0x60], xmm7
00007a44d59dbd24  vmovaps [rsp+0x70], xmm8
00007a44d59dbd2a  vmovaps [rsp+0x80], xmm9
00007a44d59dbd33  vmovaps [rsp+0x90], xmm10
00007a44d59dbd3c  vmovaps [rsp+0xA0], xmm11
00007a44d59dbd45  vmovaps [rsp+0xB0], xmm12
00007a44d59dbd4e  vmovaps [rsp+0xC0], xmm13
00007a44d59dbd57  vmovaps [rsp+0xD0], xmm14
00007a44d59dbd60  vmovaps [rsp+0xE0], xmm15
00007a44d59dbd69  sub rsp, 0x40
00007a44d59dbd6d  lea rdi, [rsp]
00007a44d59dbd71  lea rsi, [rsp+0x10]
00007a44d59dbd76  lea rdx, [rsp+0x20]
00007a44d59dbd7b  lea rcx, [rsp+0x30]
00007a44d59dbd80  mov r8d, 0x00
00007a44d59dbd86  lea r9, [r15+0x3A8]
00007a44d59dbd8d  movaps [rdi], xmm2
00007a44d59dbd90  movaps [rsi], xmm12
00007a44d59dbd94  movaps [rdx], xmm6
00007a44d59dbd97  movaps [rcx], xmm3
00007a44d59dbd9a  mov rax, 0x56179A4B1A50
00007a44d59dbda4  call rax
00007a44d59dbda6  movaps xmm2, [rsp]
00007a44d59dbdaa  add rsp, 0x40
00007a44d59dbdae  vmovaps xmm0, [rsp]
00007a44d59dbdb3  vmovaps xmm1, [rsp+0x10]
00007a44d59dbdb9  vmovaps xmm3, [rsp+0x20]
00007a44d59dbdbf  vmovaps xmm4, [rsp+0x30]
00007a44d59dbdc5  vmovaps xmm5, [rsp+0x40]
00007a44d59dbdcb  vmovaps xmm6, [rsp+0x50]
00007a44d59dbdd1  vmovaps xmm7, [rsp+0x60]
00007a44d59dbdd7  vmovaps xmm8, [rsp+0x70]
00007a44d59dbddd  vmovaps xmm9, [rsp+0x80]
00007a44d59dbde6  vmovaps xmm10, [rsp+0x90]
00007a44d59dbdef  vmovaps xmm11, [rsp+0xA0]
00007a44d59dbdf8  vmovaps xmm12, [rsp+0xB0]
00007a44d59dbe01  vmovaps xmm13, [rsp+0xC0]
00007a44d59dbe0a  vmovaps xmm14, [rsp+0xD0]
00007a44d59dbe13  vmovaps xmm15, [rsp+0xE0]
00007a44d59dbe1c  add rsp, 0xF0
00007a44d59dbe23  pop r11
00007a44d59dbe25  pop r10
00007a44d59dbe27  pop r9
00007a44d59dbe29  pop r8
00007a44d59dbe2b  pop rsi
00007a44d59dbe2c  pop rdi
00007a44d59dbe2d  pop rdx
00007a44d59dbe2e  pop rcx
00007a44d59dbe2f  pop rax
00007a44d59dbe30  add rsp, 0x08
00007a44d59dbe34  jmp 0x00007A44D59DA353
00007a44d59dbe39  sub rsp, 0x08
00007a44d59dbe3d  push rax
00007a44d59dbe3e  push rcx
00007a44d59dbe3f  push rdx
00007a44d59dbe40  push rdi
00007a44d59dbe41  push rsi
00007a44d59dbe42  push r8
00007a44d59dbe44  push r9
00007a44d59dbe46  push r10
00007a44d59dbe48  push r11
00007a44d59dbe4a  sub rsp, 0xF0
00007a44d59dbe51  vmovaps [rsp], xmm0
00007a44d59dbe56  vmovaps [rsp+0x10], xmm1
00007a44d59dbe5c  vmovaps [rsp+0x20], xmm2
00007a44d59dbe62  vmovaps [rsp+0x30], xmm3
00007a44d59dbe68  vmovaps [rsp+0x40], xmm4
00007a44d59dbe6e  vmovaps [rsp+0x50], xmm5
00007a44d59dbe74  vmovaps [rsp+0x60], xmm7
00007a44d59dbe7a  vmovaps [rsp+0x70], xmm8
00007a44d59dbe80  vmovaps [rsp+0x80], xmm9
00007a44d59dbe89  vmovaps [rsp+0x90], xmm10
00007a44d59dbe92  vmovaps [rsp+0xA0], xmm11
00007a44d59dbe9b  vmovaps [rsp+0xB0], xmm12
00007a44d59dbea4  vmovaps [rsp+0xC0], xmm13
00007a44d59dbead  vmovaps [rsp+0xD0], xmm14
00007a44d59dbeb6  vmovaps [rsp+0xE0], xmm15
00007a44d59dbebf  sub rsp, 0x40
00007a44d59dbec3  lea rdi, [rsp]
00007a44d59dbec7  lea rsi, [rsp+0x10]
00007a44d59dbecc  lea rdx, [rsp+0x20]
00007a44d59dbed1  lea rcx, [rsp+0x30]
00007a44d59dbed6  mov r8d, 0x00
00007a44d59dbedc  lea r9, [r15+0x3A8]
00007a44d59dbee3  movaps [rdi], xmm6
00007a44d59dbee6  movaps [rsi], xmm10
00007a44d59dbeea  movaps [rdx], xmm12
00007a44d59dbeee  movaps [rcx], xmm1
00007a44d59dbef1  mov rax, 0x56179A4B1A50
00007a44d59dbefb  call rax
00007a44d59dbefd  movaps xmm6, [rsp]
00007a44d59dbf01  add rsp, 0x40
00007a44d59dbf05  vmovaps xmm0, [rsp]
00007a44d59dbf0a  vmovaps xmm1, [rsp+0x10]
00007a44d59dbf10  vmovaps xmm2, [rsp+0x20]
00007a44d59dbf16  vmovaps xmm3, [rsp+0x30]
00007a44d59dbf1c  vmovaps xmm4, [rsp+0x40]
00007a44d59dbf22  vmovaps xmm5, [rsp+0x50]
00007a44d59dbf28  vmovaps xmm7, [rsp+0x60]
00007a44d59dbf2e  vmovaps xmm8, [rsp+0x70]
00007a44d59dbf34  vmovaps xmm9, [rsp+0x80]
00007a44d59dbf3d  vmovaps xmm10, [rsp+0x90]
00007a44d59dbf46  vmovaps xmm11, [rsp+0xA0]
00007a44d59dbf4f  vmovaps xmm12, [rsp+0xB0]
00007a44d59dbf58  vmovaps xmm13, [rsp+0xC0]
00007a44d59dbf61  vmovaps xmm14, [rsp+0xD0]
00007a44d59dbf6a  vmovaps xmm15, [rsp+0xE0]
00007a44d59dbf73  add rsp, 0xF0
00007a44d59dbf7a  pop r11
00007a44d59dbf7c  pop r10
00007a44d59dbf7e  pop r9
00007a44d59dbf80  pop r8
00007a44d59dbf82  pop rsi
00007a44d59dbf83  pop rdi
00007a44d59dbf84  pop rdx
00007a44d59dbf85  pop rcx
00007a44d59dbf86  pop rax
00007a44d59dbf87  add rsp, 0x08
00007a44d59dbf8b  jmp 0x00007A44D59DA381
00007a44d59dbf90  sub rsp, 0x08
00007a44d59dbf94  push rax
00007a44d59dbf95  push rcx
00007a44d59dbf96  push rdx
00007a44d59dbf97  push rdi
00007a44d59dbf98  push rsi
00007a44d59dbf99  push r8
00007a44d59dbf9b  push r9
00007a44d59dbf9d  push r10
00007a44d59dbf9f  push r11
00007a44d59dbfa1  sub rsp, 0xF0
00007a44d59dbfa8  vmovaps [rsp], xmm0
00007a44d59dbfad  vmovaps [rsp+0x10], xmm1
00007a44d59dbfb3  vmovaps [rsp+0x20], xmm2
00007a44d59dbfb9  vmovaps [rsp+0x30], xmm3
00007a44d59dbfbf  vmovaps [rsp+0x40], xmm4
00007a44d59dbfc5  vmovaps [rsp+0x50], xmm5
00007a44d59dbfcb  vmovaps [rsp+0x60], xmm6
00007a44d59dbfd1  vmovaps [rsp+0x70], xmm7
00007a44d59dbfd7  vmovaps [rsp+0x80], xmm8
00007a44d59dbfe0  vmovaps [rsp+0x90], xmm9
00007a44d59dbfe9  vmovaps [rsp+0xA0], xmm11
00007a44d59dbff2  vmovaps [rsp+0xB0], xmm12
00007a44d59dbffb  vmovaps [rsp+0xC0], xmm13
00007a44d59dc004  vmovaps [rsp+0xD0], xmm14
00007a44d59dc00d  vmovaps [rsp+0xE0], xmm15
00007a44d59dc016  sub rsp, 0x40
00007a44d59dc01a  lea rdi, [rsp]
00007a44d59dc01e  lea rsi, [rsp+0x10]
00007a44d59dc023  lea rdx, [rsp+0x20]
00007a44d59dc028  lea rcx, [rsp+0x30]
00007a44d59dc02d  mov r8d, 0x00
00007a44d59dc033  lea r9, [r15+0x3A8]
00007a44d59dc03a  movaps [rdi], xmm10
00007a44d59dc03e  movaps [rsi], xmm5
00007a44d59dc041  movaps [rdx], xmm12
00007a44d59dc045  movaps [rcx], xmm1
00007a44d59dc048  mov rax, 0x56179A4B1A50
00007a44d59dc052  call rax
00007a44d59dc054  movaps xmm10, [rsp]
00007a44d59dc059  add rsp, 0x40
00007a44d59dc05d  vmovaps xmm0, [rsp]
00007a44d59dc062  vmovaps xmm1, [rsp+0x10]
00007a44d59dc068  vmovaps xmm2, [rsp+0x20]
00007a44d59dc06e  vmovaps xmm3, [rsp+0x30]
00007a44d59dc074  vmovaps xmm4, [rsp+0x40]
00007a44d59dc07a  vmovaps xmm5, [rsp+0x50]
00007a44d59dc080  vmovaps xmm6, [rsp+0x60]
00007a44d59dc086  vmovaps xmm7, [rsp+0x70]
00007a44d59dc08c  vmovaps xmm8, [rsp+0x80]
00007a44d59dc095  vmovaps xmm9, [rsp+0x90]
00007a44d59dc09e  vmovaps xmm11, [rsp+0xA0]
00007a44d59dc0a7  vmovaps xmm12, [rsp+0xB0]
00007a44d59dc0b0  vmovaps xmm13, [rsp+0xC0]
00007a44d59dc0b9  vmovaps xmm14, [rsp+0xD0]
00007a44d59dc0c2  vmovaps xmm15, [rsp+0xE0]
00007a44d59dc0cb  add rsp, 0xF0
00007a44d59dc0d2  pop r11
00007a44d59dc0d4  pop r10
00007a44d59dc0d6  pop r9
00007a44d59dc0d8  pop r8
00007a44d59dc0da  pop rsi
00007a44d59dc0db  pop rdi
00007a44d59dc0dc  pop rdx
00007a44d59dc0dd  pop rcx
00007a44d59dc0de  pop rax
00007a44d59dc0df  add rsp, 0x08
00007a44d59dc0e3  jmp 0x00007A44D59DA3B0
00007a44d59dc0e8  sub rsp, 0x08
00007a44d59dc0ec  push rax
00007a44d59dc0ed  push rcx
00007a44d59dc0ee  push rdx
00007a44d59dc0ef  push rdi
00007a44d59dc0f0  push rsi
00007a44d59dc0f1  push r8
00007a44d59dc0f3  push r9
00007a44d59dc0f5  push r10
00007a44d59dc0f7  push r11
00007a44d59dc0f9  sub rsp, 0xF0
00007a44d59dc100  vmovaps [rsp], xmm0
00007a44d59dc105  vmovaps [rsp+0x10], xmm1
00007a44d59dc10b  vmovaps [rsp+0x20], xmm2
00007a44d59dc111  vmovaps [rsp+0x30], xmm3
00007a44d59dc117  vmovaps [rsp+0x40], xmm4
00007a44d59dc11d  vmovaps [rsp+0x50], xmm5
00007a44d59dc123  vmovaps [rsp+0x60], xmm6
00007a44d59dc129  vmovaps [rsp+0x70], xmm7
00007a44d59dc12f  vmovaps [rsp+0x80], xmm8
00007a44d59dc138  vmovaps [rsp+0x90], xmm9
00007a44d59dc141  vmovaps [rsp+0xA0], xmm10
00007a44d59dc14a  vmovaps [rsp+0xB0], xmm11
00007a44d59dc153  vmovaps [rsp+0xC0], xmm13
00007a44d59dc15c  vmovaps [rsp+0xD0], xmm14
00007a44d59dc165  vmovaps [rsp+0xE0], xmm15
00007a44d59dc16e  sub rsp, 0x40
00007a44d59dc172  lea rdi, [rsp]
00007a44d59dc176  lea rsi, [rsp+0x10]
00007a44d59dc17b  lea rdx, [rsp+0x20]
00007a44d59dc180  lea rcx, [rsp+0x30]
00007a44d59dc185  mov r8d, 0x00
00007a44d59dc18b  lea r9, [r15+0x3A8]
00007a44d59dc192  movaps [rdi], xmm12
00007a44d59dc196  movaps [rsi], xmm7
00007a44d59dc199  movaps [rdx], xmm15
00007a44d59dc19d  movaps [rcx], xmm1
00007a44d59dc1a0  mov rax, 0x56179A4B1A50
00007a44d59dc1aa  call rax
00007a44d59dc1ac  movaps xmm12, [rsp]
00007a44d59dc1b1  add rsp, 0x40
00007a44d59dc1b5  vmovaps xmm0, [rsp]
00007a44d59dc1ba  vmovaps xmm1, [rsp+0x10]
00007a44d59dc1c0  vmovaps xmm2, [rsp+0x20]
00007a44d59dc1c6  vmovaps xmm3, [rsp+0x30]
00007a44d59dc1cc  vmovaps xmm4, [rsp+0x40]
00007a44d59dc1d2  vmovaps xmm5, [rsp+0x50]
00007a44d59dc1d8  vmovaps xmm6, [rsp+0x60]
00007a44d59dc1de  vmovaps xmm7, [rsp+0x70]
00007a44d59dc1e4  vmovaps xmm8, [rsp+0x80]
00007a44d59dc1ed  vmovaps xmm9, [rsp+0x90]
00007a44d59dc1f6  vmovaps xmm10, [rsp+0xA0]
00007a44d59dc1ff  vmovaps xmm11, [rsp+0xB0]
00007a44d59dc208  vmovaps xmm13, [rsp+0xC0]
00007a44d59dc211  vmovaps xmm14, [rsp+0xD0]
00007a44d59dc21a  vmovaps xmm15, [rsp+0xE0]
00007a44d59dc223  add rsp, 0xF0
00007a44d59dc22a  pop r11
00007a44d59dc22c  pop r10
00007a44d59dc22e  pop r9
00007a44d59dc230  pop r8
00007a44d59dc232  pop rsi
00007a44d59dc233  pop rdi
00007a44d59dc234  pop rdx
00007a44d59dc235  pop rcx
00007a44d59dc236  pop rax
00007a44d59dc237  add rsp, 0x08
00007a44d59dc23b  jmp 0x00007A44D59DA3D9
00007a44d59dc240  call 0x00007A44D57FF430
00007a44d59dc245  jmp 0x00007A44D59DA3E3
00007a44d59dc24a  call 0x00007A44D580E760
00007a44d59dc24f  jmp 0x00007A44D59DA3ED
00007a44d59dc254  sub rsp, 0x08
00007a44d59dc258  push rax
00007a44d59dc259  push rcx
00007a44d59dc25a  push rdx
00007a44d59dc25b  push rdi
00007a44d59dc25c  push rsi
00007a44d59dc25d  push r8
00007a44d59dc25f  push r9
00007a44d59dc261  push r10
00007a44d59dc263  push r11
00007a44d59dc265  sub rsp, 0xF0
00007a44d59dc26c  vmovaps [rsp], xmm0
00007a44d59dc271  vmovaps [rsp+0x10], xmm1
00007a44d59dc277  vmovaps [rsp+0x20], xmm2
00007a44d59dc27d  vmovaps [rsp+0x30], xmm3
00007a44d59dc283  vmovaps [rsp+0x40], xmm4
00007a44d59dc289  vmovaps [rsp+0x50], xmm5
00007a44d59dc28f  vmovaps [rsp+0x60], xmm6
00007a44d59dc295  vmovaps [rsp+0x70], xmm8
00007a44d59dc29b  vmovaps [rsp+0x80], xmm9
00007a44d59dc2a4  vmovaps [rsp+0x90], xmm10
00007a44d59dc2ad  vmovaps [rsp+0xA0], xmm11
00007a44d59dc2b6  vmovaps [rsp+0xB0], xmm12
00007a44d59dc2bf  vmovaps [rsp+0xC0], xmm13
00007a44d59dc2c8  vmovaps [rsp+0xD0], xmm14
00007a44d59dc2d1  vmovaps [rsp+0xE0], xmm15
00007a44d59dc2da  sub rsp, 0x40
00007a44d59dc2de  lea rdi, [rsp]
00007a44d59dc2e2  lea rsi, [rsp+0x10]
00007a44d59dc2e7  lea rdx, [rsp+0x20]
00007a44d59dc2ec  lea rcx, [rsp+0x30]
00007a44d59dc2f1  mov r8d, 0x00
00007a44d59dc2f7  lea r9, [r15+0x3A8]
00007a44d59dc2fe  movaps [rdi], xmm7
00007a44d59dc301  movaps [rsi], xmm2
00007a44d59dc304  movaps [rdx], xmm9
00007a44d59dc308  movaps [rcx], xmm11
00007a44d59dc30c  mov rax, 0x56179A4B1A50
00007a44d59dc316  call rax
00007a44d59dc318  movaps xmm7, [rsp]
00007a44d59dc31c  add rsp, 0x40
00007a44d59dc320  vmovaps xmm0, [rsp]
00007a44d59dc325  vmovaps xmm1, [rsp+0x10]
00007a44d59dc32b  vmovaps xmm2, [rsp+0x20]
00007a44d59dc331  vmovaps xmm3, [rsp+0x30]
00007a44d59dc337  vmovaps xmm4, [rsp+0x40]
00007a44d59dc33d  vmovaps xmm5, [rsp+0x50]
00007a44d59dc343  vmovaps xmm6, [rsp+0x60]
00007a44d59dc349  vmovaps xmm8, [rsp+0x70]
00007a44d59dc34f  vmovaps xmm9, [rsp+0x80]
00007a44d59dc358  vmovaps xmm10, [rsp+0x90]
00007a44d59dc361  vmovaps xmm11, [rsp+0xA0]
00007a44d59dc36a  vmovaps xmm12, [rsp+0xB0]
00007a44d59dc373  vmovaps xmm13, [rsp+0xC0]
00007a44d59dc37c  vmovaps xmm14, [rsp+0xD0]
00007a44d59dc385  vmovaps xmm15, [rsp+0xE0]
00007a44d59dc38e  add rsp, 0xF0
00007a44d59dc395  pop r11
00007a44d59dc397  pop r10
00007a44d59dc399  pop r9
00007a44d59dc39b  pop r8
00007a44d59dc39d  pop rsi
00007a44d59dc39e  pop rdi
00007a44d59dc39f  pop rdx
00007a44d59dc3a0  pop rcx
00007a44d59dc3a1  pop rax
00007a44d59dc3a2  add rsp, 0x08
00007a44d59dc3a6  jmp 0x00007A44D59DA421
00007a44d59dc3ab  sub rsp, 0x08
00007a44d59dc3af  push rax
00007a44d59dc3b0  push rcx
00007a44d59dc3b1  push rdx
00007a44d59dc3b2  push rdi
00007a44d59dc3b3  push rsi
00007a44d59dc3b4  push r8
00007a44d59dc3b6  push r9
00007a44d59dc3b8  push r10
00007a44d59dc3ba  push r11
00007a44d59dc3bc  sub rsp, 0xF0
00007a44d59dc3c3  vmovaps [rsp], xmm0
00007a44d59dc3c8  vmovaps [rsp+0x10], xmm1
00007a44d59dc3ce  vmovaps [rsp+0x20], xmm2
00007a44d59dc3d4  vmovaps [rsp+0x30], xmm3
00007a44d59dc3da  vmovaps [rsp+0x40], xmm4
00007a44d59dc3e0  vmovaps [rsp+0x50], xmm5
00007a44d59dc3e6  vmovaps [rsp+0x60], xmm6
00007a44d59dc3ec  vmovaps [rsp+0x70], xmm7
00007a44d59dc3f2  vmovaps [rsp+0x80], xmm8
00007a44d59dc3fb  vmovaps [rsp+0x90], xmm10
00007a44d59dc404  vmovaps [rsp+0xA0], xmm11
00007a44d59dc40d  vmovaps [rsp+0xB0], xmm12
00007a44d59dc416  vmovaps [rsp+0xC0], xmm13
00007a44d59dc41f  vmovaps [rsp+0xD0], xmm14
00007a44d59dc428  vmovaps [rsp+0xE0], xmm15
00007a44d59dc431  sub rsp, 0x40
00007a44d59dc435  lea rdi, [rsp]
00007a44d59dc439  lea rsi, [rsp+0x10]
00007a44d59dc43e  lea rdx, [rsp+0x20]
00007a44d59dc443  lea rcx, [rsp+0x30]
00007a44d59dc448  mov r8d, 0x00
00007a44d59dc44e  lea r9, [r15+0x3A8]
00007a44d59dc455  movaps [rdi], xmm9
00007a44d59dc459  movaps [rsi], xmm6
00007a44d59dc45c  movaps [rdx], xmm1
00007a44d59dc45f  movaps [rcx], xmm11
00007a44d59dc463  mov rax, 0x56179A4B1A50
00007a44d59dc46d  call rax
00007a44d59dc46f  movaps xmm9, [rsp]
00007a44d59dc474  add rsp, 0x40
00007a44d59dc478  vmovaps xmm0, [rsp]
00007a44d59dc47d  vmovaps xmm1, [rsp+0x10]
00007a44d59dc483  vmovaps xmm2, [rsp+0x20]
00007a44d59dc489  vmovaps xmm3, [rsp+0x30]
00007a44d59dc48f  vmovaps xmm4, [rsp+0x40]
00007a44d59dc495  vmovaps xmm5, [rsp+0x50]
00007a44d59dc49b  vmovaps xmm6, [rsp+0x60]
00007a44d59dc4a1  vmovaps xmm7, [rsp+0x70]
00007a44d59dc4a7  vmovaps xmm8, [rsp+0x80]
00007a44d59dc4b0  vmovaps xmm10, [rsp+0x90]
00007a44d59dc4b9  vmovaps xmm11, [rsp+0xA0]
00007a44d59dc4c2  vmovaps xmm12, [rsp+0xB0]
00007a44d59dc4cb  vmovaps xmm13, [rsp+0xC0]
00007a44d59dc4d4  vmovaps xmm14, [rsp+0xD0]
00007a44d59dc4dd  vmovaps xmm15, [rsp+0xE0]
00007a44d59dc4e6  add rsp, 0xF0
00007a44d59dc4ed  pop r11
00007a44d59dc4ef  pop r10
00007a44d59dc4f1  pop r9
00007a44d59dc4f3  pop r8
00007a44d59dc4f5  pop rsi
00007a44d59dc4f6  pop rdi
00007a44d59dc4f7  pop rdx
00007a44d59dc4f8  pop rcx
00007a44d59dc4f9  pop rax
00007a44d59dc4fa  add rsp, 0x08
00007a44d59dc4fe  jmp 0x00007A44D59DA447
00007a44d59dc503  sub rsp, 0x08
00007a44d59dc507  push rax
00007a44d59dc508  push rcx
00007a44d59dc509  push rdx
00007a44d59dc50a  push rdi
00007a44d59dc50b  push rsi
00007a44d59dc50c  push r8
00007a44d59dc50e  push r9
00007a44d59dc510  push r10
00007a44d59dc512  push r11
00007a44d59dc514  sub rsp, 0xF0
00007a44d59dc51b  vmovaps [rsp], xmm0
00007a44d59dc520  vmovaps [rsp+0x10], xmm1
00007a44d59dc526  vmovaps [rsp+0x20], xmm2
00007a44d59dc52c  vmovaps [rsp+0x30], xmm3
00007a44d59dc532  vmovaps [rsp+0x40], xmm4
00007a44d59dc538  vmovaps [rsp+0x50], xmm5
00007a44d59dc53e  vmovaps [rsp+0x60], xmm6
00007a44d59dc544  vmovaps [rsp+0x70], xmm7
00007a44d59dc54a  vmovaps [rsp+0x80], xmm8
00007a44d59dc553  vmovaps [rsp+0x90], xmm9
00007a44d59dc55c  vmovaps [rsp+0xA0], xmm10
00007a44d59dc565  vmovaps [rsp+0xB0], xmm12
00007a44d59dc56e  vmovaps [rsp+0xC0], xmm13
00007a44d59dc577  vmovaps [rsp+0xD0], xmm14
00007a44d59dc580  vmovaps [rsp+0xE0], xmm15
00007a44d59dc589  sub rsp, 0x40
00007a44d59dc58d  lea rdi, [rsp]
00007a44d59dc591  lea rsi, [rsp+0x10]
00007a44d59dc596  lea rdx, [rsp+0x20]
00007a44d59dc59b  lea rcx, [rsp+0x30]
00007a44d59dc5a0  mov r8d, 0x00
00007a44d59dc5a6  lea r9, [r15+0x3A8]
00007a44d59dc5ad  movaps [rdi], xmm11
00007a44d59dc5b1  movaps [rsi], xmm10
00007a44d59dc5b5  movaps [rdx], xmm8
00007a44d59dc5b9  movaps [rcx], xmm1
00007a44d59dc5bc  mov rax, 0x56179A4B1A50
00007a44d59dc5c6  call rax
00007a44d59dc5c8  movaps xmm11, [rsp]
00007a44d59dc5cd  add rsp, 0x40
00007a44d59dc5d1  vmovaps xmm0, [rsp]
00007a44d59dc5d6  vmovaps xmm1, [rsp+0x10]
00007a44d59dc5dc  vmovaps xmm2, [rsp+0x20]
00007a44d59dc5e2  vmovaps xmm3, [rsp+0x30]
00007a44d59dc5e8  vmovaps xmm4, [rsp+0x40]
00007a44d59dc5ee  vmovaps xmm5, [rsp+0x50]
00007a44d59dc5f4  vmovaps xmm6, [rsp+0x60]
00007a44d59dc5fa  vmovaps xmm7, [rsp+0x70]
00007a44d59dc600  vmovaps xmm8, [rsp+0x80]
00007a44d59dc609  vmovaps xmm9, [rsp+0x90]
00007a44d59dc612  vmovaps xmm10, [rsp+0xA0]
00007a44d59dc61b  vmovaps xmm12, [rsp+0xB0]
00007a44d59dc624  vmovaps xmm13, [rsp+0xC0]
00007a44d59dc62d  vmovaps xmm14, [rsp+0xD0]
00007a44d59dc636  vmovaps xmm15, [rsp+0xE0]
00007a44d59dc63f  add rsp, 0xF0
00007a44d59dc646  pop r11
00007a44d59dc648  pop r10
00007a44d59dc64a  pop r9
00007a44d59dc64c  pop r8
00007a44d59dc64e  pop rsi
00007a44d59dc64f  pop rdi
00007a44d59dc650  pop rdx
00007a44d59dc651  pop rcx
00007a44d59dc652  pop rax
00007a44d59dc653  add rsp, 0x08
00007a44d59dc657  jmp 0x00007A44D59DA46D
00007a44d59dc65c  sub rsp, 0x08
00007a44d59dc660  push rax
00007a44d59dc661  push rcx
00007a44d59dc662  push rdx
00007a44d59dc663  push rdi
00007a44d59dc664  push rsi
00007a44d59dc665  push r8
00007a44d59dc667  push r9
00007a44d59dc669  push r10
00007a44d59dc66b  push r11
00007a44d59dc66d  sub rsp, 0xF0
00007a44d59dc674  vmovaps [rsp], xmm0
00007a44d59dc679  vmovaps [rsp+0x10], xmm1
00007a44d59dc67f  vmovaps [rsp+0x20], xmm2
00007a44d59dc685  vmovaps [rsp+0x30], xmm3
00007a44d59dc68b  vmovaps [rsp+0x40], xmm4
00007a44d59dc691  vmovaps [rsp+0x50], xmm5
00007a44d59dc697  vmovaps [rsp+0x60], xmm6
00007a44d59dc69d  vmovaps [rsp+0x70], xmm7
00007a44d59dc6a3  vmovaps [rsp+0x80], xmm8
00007a44d59dc6ac  vmovaps [rsp+0x90], xmm9
00007a44d59dc6b5  vmovaps [rsp+0xA0], xmm11
00007a44d59dc6be  vmovaps [rsp+0xB0], xmm12
00007a44d59dc6c7  vmovaps [rsp+0xC0], xmm13
00007a44d59dc6d0  vmovaps [rsp+0xD0], xmm14
00007a44d59dc6d9  vmovaps [rsp+0xE0], xmm15
00007a44d59dc6e2  sub rsp, 0x40
00007a44d59dc6e6  lea rdi, [rsp]
00007a44d59dc6ea  lea rsi, [rsp+0x10]
00007a44d59dc6ef  lea rdx, [rsp+0x20]
00007a44d59dc6f4  lea rcx, [rsp+0x30]
00007a44d59dc6f9  mov r8d, 0x00
00007a44d59dc6ff  lea r9, [r15+0x3A8]
00007a44d59dc706  movaps [rdi], xmm10
00007a44d59dc70a  movaps [rsi], xmm12
00007a44d59dc70e  movaps [rdx], xmm13
00007a44d59dc712  movaps [rcx], xmm1
00007a44d59dc715  mov rax, 0x56179A4B1A50
00007a44d59dc71f  call rax
00007a44d59dc721  movaps xmm10, [rsp]
00007a44d59dc726  add rsp, 0x40
00007a44d59dc72a  vmovaps xmm0, [rsp]
00007a44d59dc72f  vmovaps xmm1, [rsp+0x10]
00007a44d59dc735  vmovaps xmm2, [rsp+0x20]
00007a44d59dc73b  vmovaps xmm3, [rsp+0x30]
00007a44d59dc741  vmovaps xmm4, [rsp+0x40]
00007a44d59dc747  vmovaps xmm5, [rsp+0x50]
00007a44d59dc74d  vmovaps xmm6, [rsp+0x60]
00007a44d59dc753  vmovaps xmm7, [rsp+0x70]
00007a44d59dc759  vmovaps xmm8, [rsp+0x80]
00007a44d59dc762  vmovaps xmm9, [rsp+0x90]
00007a44d59dc76b  vmovaps xmm11, [rsp+0xA0]
00007a44d59dc774  vmovaps xmm12, [rsp+0xB0]
00007a44d59dc77d  vmovaps xmm13, [rsp+0xC0]
00007a44d59dc786  vmovaps xmm14, [rsp+0xD0]
00007a44d59dc78f  vmovaps xmm15, [rsp+0xE0]
00007a44d59dc798  add rsp, 0xF0
00007a44d59dc79f  pop r11
00007a44d59dc7a1  pop r10
00007a44d59dc7a3  pop r9
00007a44d59dc7a5  pop r8
00007a44d59dc7a7  pop rsi
00007a44d59dc7a8  pop rdi
00007a44d59dc7a9  pop rdx
00007a44d59dc7aa  pop rcx
00007a44d59dc7ab  pop rax
00007a44d59dc7ac  add rsp, 0x08
00007a44d59dc7b0  jmp 0x00007A44D59DA493
00007a44d59dc7b5  call 0x00007A44D57FF430
00007a44d59dc7ba  jmp 0x00007A44D59DA49D
00007a44d59dc7bf  call 0x00007A44D580C260
00007a44d59dc7c4  jmp 0x00007A44D59DA4A7
00007a44d59dc7c9  sub rsp, 0x08
00007a44d59dc7cd  push rax
00007a44d59dc7ce  push rcx
00007a44d59dc7cf  push rdx
00007a44d59dc7d0  push rdi
00007a44d59dc7d1  push rsi
00007a44d59dc7d2  push r8
00007a44d59dc7d4  push r9
00007a44d59dc7d6  push r10
00007a44d59dc7d8  push r11
00007a44d59dc7da  sub rsp, 0xF0
00007a44d59dc7e1  vmovaps [rsp], xmm0
00007a44d59dc7e6  vmovaps [rsp+0x10], xmm1
00007a44d59dc7ec  vmovaps [rsp+0x20], xmm2
00007a44d59dc7f2  vmovaps [rsp+0x30], xmm3
00007a44d59dc7f8  vmovaps [rsp+0x40], xmm4
00007a44d59dc7fe  vmovaps [rsp+0x50], xmm5
00007a44d59dc804  vmovaps [rsp+0x60], xmm6
00007a44d59dc80a  vmovaps [rsp+0x70], xmm7
00007a44d59dc810  vmovaps [rsp+0x80], xmm9
00007a44d59dc819  vmovaps [rsp+0x90], xmm10
00007a44d59dc822  vmovaps [rsp+0xA0], xmm11
00007a44d59dc82b  vmovaps [rsp+0xB0], xmm12
00007a44d59dc834  vmovaps [rsp+0xC0], xmm13
00007a44d59dc83d  vmovaps [rsp+0xD0], xmm14
00007a44d59dc846  vmovaps [rsp+0xE0], xmm15
00007a44d59dc84f  sub rsp, 0x40
00007a44d59dc853  lea rdi, [rsp]
00007a44d59dc857  lea rsi, [rsp+0x10]
00007a44d59dc85c  lea rdx, [rsp+0x20]
00007a44d59dc861  lea rcx, [rsp+0x30]
00007a44d59dc866  mov r8d, 0x00
00007a44d59dc86c  lea r9, [r15+0x3A8]
00007a44d59dc873  movaps [rdi], xmm8
00007a44d59dc877  movaps [rsi], xmm7
00007a44d59dc87a  movaps [rdx], xmm4
00007a44d59dc87d  movaps [rcx], xmm12
00007a44d59dc881  mov rax, 0x56179A4B1A50
00007a44d59dc88b  call rax
00007a44d59dc88d  movaps xmm8, [rsp]
00007a44d59dc892  add rsp, 0x40
00007a44d59dc896  vmovaps xmm0, [rsp]
00007a44d59dc89b  vmovaps xmm1, [rsp+0x10]
00007a44d59dc8a1  vmovaps xmm2, [rsp+0x20]
00007a44d59dc8a7  vmovaps xmm3, [rsp+0x30]
00007a44d59dc8ad  vmovaps xmm4, [rsp+0x40]
00007a44d59dc8b3  vmovaps xmm5, [rsp+0x50]
00007a44d59dc8b9  vmovaps xmm6, [rsp+0x60]
00007a44d59dc8bf  vmovaps xmm7, [rsp+0x70]
00007a44d59dc8c5  vmovaps xmm9, [rsp+0x80]
00007a44d59dc8ce  vmovaps xmm10, [rsp+0x90]
00007a44d59dc8d7  vmovaps xmm11, [rsp+0xA0]
00007a44d59dc8e0  vmovaps xmm12, [rsp+0xB0]
00007a44d59dc8e9  vmovaps xmm13, [rsp+0xC0]
00007a44d59dc8f2  vmovaps xmm14, [rsp+0xD0]
00007a44d59dc8fb  vmovaps xmm15, [rsp+0xE0]
00007a44d59dc904  add rsp, 0xF0
00007a44d59dc90b  pop r11
00007a44d59dc90d  pop r10
00007a44d59dc90f  pop r9
00007a44d59dc911  pop r8
00007a44d59dc913  pop rsi
00007a44d59dc914  pop rdi
00007a44d59dc915  pop rdx
00007a44d59dc916  pop rcx
00007a44d59dc917  pop rax
00007a44d59dc918  add rsp, 0x08
00007a44d59dc91c  jmp 0x00007A44D59DA4D0
00007a44d59dc921  sub rsp, 0x08
00007a44d59dc925  push rax
00007a44d59dc926  push rcx
00007a44d59dc927  push rdx
00007a44d59dc928  push rdi
00007a44d59dc929  push rsi
00007a44d59dc92a  push r8
00007a44d59dc92c  push r9
00007a44d59dc92e  push r10
00007a44d59dc930  push r11
00007a44d59dc932  sub rsp, 0xF0
00007a44d59dc939  vmovaps [rsp], xmm0
00007a44d59dc93e  vmovaps [rsp+0x10], xmm1
00007a44d59dc944  vmovaps [rsp+0x20], xmm2
00007a44d59dc94a  vmovaps [rsp+0x30], xmm3
00007a44d59dc950  vmovaps [rsp+0x40], xmm4
00007a44d59dc956  vmovaps [rsp+0x50], xmm5
00007a44d59dc95c  vmovaps [rsp+0x60], xmm6
00007a44d59dc962  vmovaps [rsp+0x70], xmm8
00007a44d59dc968  vmovaps [rsp+0x80], xmm9
00007a44d59dc971  vmovaps [rsp+0x90], xmm10
00007a44d59dc97a  vmovaps [rsp+0xA0], xmm11
00007a44d59dc983  vmovaps [rsp+0xB0], xmm12
00007a44d59dc98c  vmovaps [rsp+0xC0], xmm13
00007a44d59dc995  vmovaps [rsp+0xD0], xmm14
00007a44d59dc99e  vmovaps [rsp+0xE0], xmm15
00007a44d59dc9a7  sub rsp, 0x40
00007a44d59dc9ab  lea rdi, [rsp]
00007a44d59dc9af  lea rsi, [rsp+0x10]
00007a44d59dc9b4  lea rdx, [rsp+0x20]
00007a44d59dc9b9  lea rcx, [rsp+0x30]
00007a44d59dc9be  mov r8d, 0x00
00007a44d59dc9c4  lea r9, [r15+0x3A8]
00007a44d59dc9cb  movaps [rdi], xmm7
00007a44d59dc9ce  movaps [rsi], xmm9
00007a44d59dc9d2  movaps [rdx], xmm14
00007a44d59dc9d6  movaps [rcx], xmm12
00007a44d59dc9da  mov rax, 0x56179A4B1A50
00007a44d59dc9e4  call rax
00007a44d59dc9e6  movaps xmm7, [rsp]
00007a44d59dc9ea  add rsp, 0x40
00007a44d59dc9ee  vmovaps xmm0, [rsp]
00007a44d59dc9f3  vmovaps xmm1, [rsp+0x10]
00007a44d59dc9f9  vmovaps xmm2, [rsp+0x20]
00007a44d59dc9ff  vmovaps xmm3, [rsp+0x30]
00007a44d59dca05  vmovaps xmm4, [rsp+0x40]
00007a44d59dca0b  vmovaps xmm5, [rsp+0x50]
00007a44d59dca11  vmovaps xmm6, [rsp+0x60]
00007a44d59dca17  vmovaps xmm8, [rsp+0x70]
00007a44d59dca1d  vmovaps xmm9, [rsp+0x80]
00007a44d59dca26  vmovaps xmm10, [rsp+0x90]
00007a44d59dca2f  vmovaps xmm11, [rsp+0xA0]
00007a44d59dca38  vmovaps xmm12, [rsp+0xB0]
00007a44d59dca41  vmovaps xmm13, [rsp+0xC0]
00007a44d59dca4a  vmovaps xmm14, [rsp+0xD0]
00007a44d59dca53  vmovaps xmm15, [rsp+0xE0]
00007a44d59dca5c  add rsp, 0xF0
00007a44d59dca63  pop r11
00007a44d59dca65  pop r10
00007a44d59dca67  pop r9
00007a44d59dca69  pop r8
00007a44d59dca6b  pop rsi
00007a44d59dca6c  pop rdi
00007a44d59dca6d  pop rdx
00007a44d59dca6e  pop rcx
00007a44d59dca6f  pop rax
00007a44d59dca70  add rsp, 0x08
00007a44d59dca74  jmp 0x00007A44D59DA4F8
00007a44d59dca79  sub rsp, 0x08
00007a44d59dca7d  push rax
00007a44d59dca7e  push rcx
00007a44d59dca7f  push rdx
00007a44d59dca80  push rdi
00007a44d59dca81  push rsi
00007a44d59dca82  push r8
00007a44d59dca84  push r9
00007a44d59dca86  push r10
00007a44d59dca88  push r11
00007a44d59dca8a  sub rsp, 0xF0
00007a44d59dca91  vmovaps [rsp], xmm0
00007a44d59dca96  vmovaps [rsp+0x10], xmm1
00007a44d59dca9c  vmovaps [rsp+0x20], xmm2
00007a44d59dcaa2  vmovaps [rsp+0x30], xmm3
00007a44d59dcaa8  vmovaps [rsp+0x40], xmm4
00007a44d59dcaae  vmovaps [rsp+0x50], xmm5
00007a44d59dcab4  vmovaps [rsp+0x60], xmm6
00007a44d59dcaba  vmovaps [rsp+0x70], xmm7
00007a44d59dcac0  vmovaps [rsp+0x80], xmm8
00007a44d59dcac9  vmovaps [rsp+0x90], xmm9
00007a44d59dcad2  vmovaps [rsp+0xA0], xmm10
00007a44d59dcadb  vmovaps [rsp+0xB0], xmm11
00007a44d59dcae4  vmovaps [rsp+0xC0], xmm13
00007a44d59dcaed  vmovaps [rsp+0xD0], xmm14
00007a44d59dcaf6  vmovaps [rsp+0xE0], xmm15
00007a44d59dcaff  sub rsp, 0x40
00007a44d59dcb03  lea rdi, [rsp]
00007a44d59dcb07  lea rsi, [rsp+0x10]
00007a44d59dcb0c  lea rdx, [rsp+0x20]
00007a44d59dcb11  lea rcx, [rsp+0x30]
00007a44d59dcb16  mov r8d, 0x00
00007a44d59dcb1c  lea r9, [r15+0x3A8]
00007a44d59dcb23  movaps [rdi], xmm12
00007a44d59dcb27  movaps [rsi], xmm11
00007a44d59dcb2b  movaps [rdx], xmm15
00007a44d59dcb2f  movaps [rcx], xmm14
00007a44d59dcb33  mov rax, 0x56179A4B1A50
00007a44d59dcb3d  call rax
00007a44d59dcb3f  movaps xmm12, [rsp]
00007a44d59dcb44  add rsp, 0x40
00007a44d59dcb48  vmovaps xmm0, [rsp]
00007a44d59dcb4d  vmovaps xmm1, [rsp+0x10]
00007a44d59dcb53  vmovaps xmm2, [rsp+0x20]
00007a44d59dcb59  vmovaps xmm3, [rsp+0x30]
00007a44d59dcb5f  vmovaps xmm4, [rsp+0x40]
00007a44d59dcb65  vmovaps xmm5, [rsp+0x50]
00007a44d59dcb6b  vmovaps xmm6, [rsp+0x60]
00007a44d59dcb71  vmovaps xmm7, [rsp+0x70]
00007a44d59dcb77  vmovaps xmm8, [rsp+0x80]
00007a44d59dcb80  vmovaps xmm9, [rsp+0x90]
00007a44d59dcb89  vmovaps xmm10, [rsp+0xA0]
00007a44d59dcb92  vmovaps xmm11, [rsp+0xB0]
00007a44d59dcb9b  vmovaps xmm13, [rsp+0xC0]
00007a44d59dcba4  vmovaps xmm14, [rsp+0xD0]
00007a44d59dcbad  vmovaps xmm15, [rsp+0xE0]
00007a44d59dcbb6  add rsp, 0xF0
00007a44d59dcbbd  pop r11
00007a44d59dcbbf  pop r10
00007a44d59dcbc1  pop r9
00007a44d59dcbc3  pop r8
00007a44d59dcbc5  pop rsi
00007a44d59dcbc6  pop rdi
00007a44d59dcbc7  pop rdx
00007a44d59dcbc8  pop rcx
00007a44d59dcbc9  pop rax
00007a44d59dcbca  add rsp, 0x08
00007a44d59dcbce  jmp 0x00007A44D59DA521
00007a44d59dcbd3  sub rsp, 0x08
00007a44d59dcbd7  push rax
00007a44d59dcbd8  push rcx
00007a44d59dcbd9  push rdx
00007a44d59dcbda  push rdi
00007a44d59dcbdb  push rsi
00007a44d59dcbdc  push r8
00007a44d59dcbde  push r9
00007a44d59dcbe0  push r10
00007a44d59dcbe2  push r11
00007a44d59dcbe4  sub rsp, 0xF0
00007a44d59dcbeb  vmovaps [rsp], xmm0
00007a44d59dcbf0  vmovaps [rsp+0x10], xmm1
00007a44d59dcbf6  vmovaps [rsp+0x20], xmm2
00007a44d59dcbfc  vmovaps [rsp+0x30], xmm3
00007a44d59dcc02  vmovaps [rsp+0x40], xmm4
00007a44d59dcc08  vmovaps [rsp+0x50], xmm5
00007a44d59dcc0e  vmovaps [rsp+0x60], xmm6
00007a44d59dcc14  vmovaps [rsp+0x70], xmm7
00007a44d59dcc1a  vmovaps [rsp+0x80], xmm8
00007a44d59dcc23  vmovaps [rsp+0x90], xmm9
00007a44d59dcc2c  vmovaps [rsp+0xA0], xmm10
00007a44d59dcc35  vmovaps [rsp+0xB0], xmm12
00007a44d59dcc3e  vmovaps [rsp+0xC0], xmm13
00007a44d59dcc47  vmovaps [rsp+0xD0], xmm14
00007a44d59dcc50  vmovaps [rsp+0xE0], xmm15
00007a44d59dcc59  sub rsp, 0x40
00007a44d59dcc5d  lea rdi, [rsp]
00007a44d59dcc61  lea rsi, [rsp+0x10]
00007a44d59dcc66  lea rdx, [rsp+0x20]
00007a44d59dcc6b  lea rcx, [rsp+0x30]
00007a44d59dcc70  mov r8d, 0x00
00007a44d59dcc76  lea r9, [r15+0x3A8]
00007a44d59dcc7d  movaps [rdi], xmm11
00007a44d59dcc81  movaps [rsi], xmm10
00007a44d59dcc85  movaps [rdx], xmm13
00007a44d59dcc89  movaps [rcx], xmm15
00007a44d59dcc8d  mov rax, 0x56179A4B1A50
00007a44d59dcc97  call rax
00007a44d59dcc99  movaps xmm11, [rsp]
00007a44d59dcc9e  add rsp, 0x40
00007a44d59dcca2  vmovaps xmm0, [rsp]
00007a44d59dcca7  vmovaps xmm1, [rsp+0x10]
00007a44d59dccad  vmovaps xmm2, [rsp+0x20]
00007a44d59dccb3  vmovaps xmm3, [rsp+0x30]
00007a44d59dccb9  vmovaps xmm4, [rsp+0x40]
00007a44d59dccbf  vmovaps xmm5, [rsp+0x50]
00007a44d59dccc5  vmovaps xmm6, [rsp+0x60]
00007a44d59dcccb  vmovaps xmm7, [rsp+0x70]
00007a44d59dccd1  vmovaps xmm8, [rsp+0x80]
00007a44d59dccda  vmovaps xmm9, [rsp+0x90]
00007a44d59dcce3  vmovaps xmm10, [rsp+0xA0]
00007a44d59dccec  vmovaps xmm12, [rsp+0xB0]
00007a44d59dccf5  vmovaps xmm13, [rsp+0xC0]
00007a44d59dccfe  vmovaps xmm14, [rsp+0xD0]
00007a44d59dcd07  vmovaps xmm15, [rsp+0xE0]
00007a44d59dcd10  add rsp, 0xF0
00007a44d59dcd17  pop r11
00007a44d59dcd19  pop r10
00007a44d59dcd1b  pop r9
00007a44d59dcd1d  pop r8
00007a44d59dcd1f  pop rsi
00007a44d59dcd20  pop rdi
00007a44d59dcd21  pop rdx
00007a44d59dcd22  pop rcx
00007a44d59dcd23  pop rax
00007a44d59dcd24  add rsp, 0x08
00007a44d59dcd28  jmp 0x00007A44D59DA54A
00007a44d59dcd2d  call 0x00007A44D580E760
00007a44d59dcd32  jmp 0x00007A44D59DA557
00007a44d59dcd37  call 0x00007A44D580D4E0
00007a44d59dcd3c  jmp 0x00007A44D59DA564
00007a44d59dcd41  sub rsp, 0x08
00007a44d59dcd45  push rax
00007a44d59dcd46  push rcx
00007a44d59dcd47  push rdx
00007a44d59dcd48  push rdi
00007a44d59dcd49  push rsi
00007a44d59dcd4a  push r8
00007a44d59dcd4c  push r9
00007a44d59dcd4e  push r10
00007a44d59dcd50  push r11
00007a44d59dcd52  sub rsp, 0xF0
00007a44d59dcd59  vmovaps [rsp], xmm0
00007a44d59dcd5e  vmovaps [rsp+0x10], xmm1
00007a44d59dcd64  vmovaps [rsp+0x20], xmm2
00007a44d59dcd6a  vmovaps [rsp+0x30], xmm3
00007a44d59dcd70  vmovaps [rsp+0x40], xmm4
00007a44d59dcd76  vmovaps [rsp+0x50], xmm5
00007a44d59dcd7c  vmovaps [rsp+0x60], xmm6
00007a44d59dcd82  vmovaps [rsp+0x70], xmm7
00007a44d59dcd88  vmovaps [rsp+0x80], xmm8
00007a44d59dcd91  vmovaps [rsp+0x90], xmm9
00007a44d59dcd9a  vmovaps [rsp+0xA0], xmm11
00007a44d59dcda3  vmovaps [rsp+0xB0], xmm12
00007a44d59dcdac  vmovaps [rsp+0xC0], xmm13
00007a44d59dcdb5  vmovaps [rsp+0xD0], xmm14
00007a44d59dcdbe  vmovaps [rsp+0xE0], xmm15
00007a44d59dcdc7  sub rsp, 0x40
00007a44d59dcdcb  lea rdi, [rsp]
00007a44d59dcdcf  lea rsi, [rsp+0x10]
00007a44d59dcdd4  lea rdx, [rsp+0x20]
00007a44d59dcdd9  lea rcx, [rsp+0x30]
00007a44d59dcdde  mov r8d, 0x00
00007a44d59dcde4  lea r9, [r15+0x3A8]
00007a44d59dcdeb  movaps [rdi], xmm10
00007a44d59dcdef  movaps [rsi], xmm8
00007a44d59dcdf3  movaps [rdx], xmm1
00007a44d59dcdf6  movaps [rcx], xmm13
00007a44d59dcdfa  mov rax, 0x56179A4B1A50
00007a44d59dce04  call rax
00007a44d59dce06  movaps xmm10, [rsp]
00007a44d59dce0b  add rsp, 0x40
00007a44d59dce0f  vmovaps xmm0, [rsp]
00007a44d59dce14  vmovaps xmm1, [rsp+0x10]
00007a44d59dce1a  vmovaps xmm2, [rsp+0x20]
00007a44d59dce20  vmovaps xmm3, [rsp+0x30]
00007a44d59dce26  vmovaps xmm4, [rsp+0x40]
00007a44d59dce2c  vmovaps xmm5, [rsp+0x50]
00007a44d59dce32  vmovaps xmm6, [rsp+0x60]
00007a44d59dce38  vmovaps xmm7, [rsp+0x70]
00007a44d59dce3e  vmovaps xmm8, [rsp+0x80]
00007a44d59dce47  vmovaps xmm9, [rsp+0x90]
00007a44d59dce50  vmovaps xmm11, [rsp+0xA0]
00007a44d59dce59  vmovaps xmm12, [rsp+0xB0]
00007a44d59dce62  vmovaps xmm13, [rsp+0xC0]
00007a44d59dce6b  vmovaps xmm14, [rsp+0xD0]
00007a44d59dce74  vmovaps xmm15, [rsp+0xE0]
00007a44d59dce7d  add rsp, 0xF0
00007a44d59dce84  pop r11
00007a44d59dce86  pop r10
00007a44d59dce88  pop r9
00007a44d59dce8a  pop r8
00007a44d59dce8c  pop rsi
00007a44d59dce8d  pop rdi
00007a44d59dce8e  pop rdx
00007a44d59dce8f  pop rcx
00007a44d59dce90  pop rax
00007a44d59dce91  add rsp, 0x08
00007a44d59dce95  jmp 0x00007A44D59DA59A
00007a44d59dce9a  call 0x00007A44D57FF430
00007a44d59dce9f  jmp 0x00007A44D59DA5AC
00007a44d59dcea4  sub rsp, 0x08
00007a44d59dcea8  push rax
00007a44d59dcea9  push rcx
00007a44d59dceaa  push rdx
00007a44d59dceab  push rdi
00007a44d59dceac  push rsi
00007a44d59dcead  push r8
00007a44d59dceaf  push r9
00007a44d59dceb1  push r10
00007a44d59dceb3  push r11
00007a44d59dceb5  sub rsp, 0xF0
00007a44d59dcebc  vmovaps [rsp], xmm0
00007a44d59dcec1  vmovaps [rsp+0x10], xmm1
00007a44d59dcec7  vmovaps [rsp+0x20], xmm2
00007a44d59dcecd  vmovaps [rsp+0x30], xmm3
00007a44d59dced3  vmovaps [rsp+0x40], xmm4
00007a44d59dced9  vmovaps [rsp+0x50], xmm5
00007a44d59dcedf  vmovaps [rsp+0x60], xmm6
00007a44d59dcee5  vmovaps [rsp+0x70], xmm7
00007a44d59dceeb  vmovaps [rsp+0x80], xmm8
00007a44d59dcef4  vmovaps [rsp+0x90], xmm10
00007a44d59dcefd  vmovaps [rsp+0xA0], xmm11
00007a44d59dcf06  vmovaps [rsp+0xB0], xmm12
00007a44d59dcf0f  vmovaps [rsp+0xC0], xmm13
00007a44d59dcf18  vmovaps [rsp+0xD0], xmm14
00007a44d59dcf21  vmovaps [rsp+0xE0], xmm15
00007a44d59dcf2a  sub rsp, 0x40
00007a44d59dcf2e  lea rdi, [rsp]
00007a44d59dcf32  lea rsi, [rsp+0x10]
00007a44d59dcf37  lea rdx, [rsp+0x20]
00007a44d59dcf3c  lea rcx, [rsp+0x30]
00007a44d59dcf41  mov r8d, 0x00
00007a44d59dcf47  lea r9, [r15+0x3A8]
00007a44d59dcf4e  movaps [rdi], xmm9
00007a44d59dcf52  movaps [rsi], xmm7
00007a44d59dcf55  movaps [rdx], xmm14
00007a44d59dcf59  movaps [rcx], xmm13
00007a44d59dcf5d  mov rax, 0x56179A4B1A50
00007a44d59dcf67  call rax
00007a44d59dcf69  movaps xmm9, [rsp]
00007a44d59dcf6e  add rsp, 0x40
00007a44d59dcf72  vmovaps xmm0, [rsp]
00007a44d59dcf77  vmovaps xmm1, [rsp+0x10]
00007a44d59dcf7d  vmovaps xmm2, [rsp+0x20]
00007a44d59dcf83  vmovaps xmm3, [rsp+0x30]
00007a44d59dcf89  vmovaps xmm4, [rsp+0x40]
00007a44d59dcf8f  vmovaps xmm5, [rsp+0x50]
00007a44d59dcf95  vmovaps xmm6, [rsp+0x60]
00007a44d59dcf9b  vmovaps xmm7, [rsp+0x70]
00007a44d59dcfa1  vmovaps xmm8, [rsp+0x80]
00007a44d59dcfaa  vmovaps xmm10, [rsp+0x90]
00007a44d59dcfb3  vmovaps xmm11, [rsp+0xA0]
00007a44d59dcfbc  vmovaps xmm12, [rsp+0xB0]
00007a44d59dcfc5  vmovaps xmm13, [rsp+0xC0]
00007a44d59dcfce  vmovaps xmm14, [rsp+0xD0]
00007a44d59dcfd7  vmovaps xmm15, [rsp+0xE0]
00007a44d59dcfe0  add rsp, 0xF0
00007a44d59dcfe7  pop r11
00007a44d59dcfe9  pop r10
00007a44d59dcfeb  pop r9
00007a44d59dcfed  pop r8
00007a44d59dcfef  pop rsi
00007a44d59dcff0  pop rdi
00007a44d59dcff1  pop rdx
00007a44d59dcff2  pop rcx
00007a44d59dcff3  pop rax
00007a44d59dcff4  add rsp, 0x08
00007a44d59dcff8  jmp 0x00007A44D59DA5DA
00007a44d59dcffd  sub rsp, 0x08
00007a44d59dd001  push rax
00007a44d59dd002  push rcx
00007a44d59dd003  push rdx
00007a44d59dd004  push rdi
00007a44d59dd005  push rsi
00007a44d59dd006  push r8
00007a44d59dd008  push r9
00007a44d59dd00a  push r10
00007a44d59dd00c  push r11
00007a44d59dd00e  sub rsp, 0xF0
00007a44d59dd015  vmovaps [rsp], xmm0
00007a44d59dd01a  vmovaps [rsp+0x10], xmm1
00007a44d59dd020  vmovaps [rsp+0x20], xmm2
00007a44d59dd026  vmovaps [rsp+0x30], xmm3
00007a44d59dd02c  vmovaps [rsp+0x40], xmm4
00007a44d59dd032  vmovaps [rsp+0x50], xmm5
00007a44d59dd038  vmovaps [rsp+0x60], xmm6
00007a44d59dd03e  vmovaps [rsp+0x70], xmm7
00007a44d59dd044  vmovaps [rsp+0x80], xmm8
00007a44d59dd04d  vmovaps [rsp+0x90], xmm9
00007a44d59dd056  vmovaps [rsp+0xA0], xmm10
00007a44d59dd05f  vmovaps [rsp+0xB0], xmm11
00007a44d59dd068  vmovaps [rsp+0xC0], xmm12
00007a44d59dd071  vmovaps [rsp+0xD0], xmm14
00007a44d59dd07a  vmovaps [rsp+0xE0], xmm15
00007a44d59dd083  sub rsp, 0x40
00007a44d59dd087  lea rdi, [rsp]
00007a44d59dd08b  lea rsi, [rsp+0x10]
00007a44d59dd090  lea rdx, [rsp+0x20]
00007a44d59dd095  lea rcx, [rsp+0x30]
00007a44d59dd09a  mov r8d, 0x00
00007a44d59dd0a0  lea r9, [r15+0x3A8]
00007a44d59dd0a7  movaps [rdi], xmm13
00007a44d59dd0ab  movaps [rsi], xmm12
00007a44d59dd0af  movaps [rdx], xmm15
00007a44d59dd0b3  movaps [rcx], xmm14
00007a44d59dd0b7  mov rax, 0x56179A4B1A50
00007a44d59dd0c1  call rax
00007a44d59dd0c3  movaps xmm13, [rsp]
00007a44d59dd0c8  add rsp, 0x40
00007a44d59dd0cc  vmovaps xmm0, [rsp]
00007a44d59dd0d1  vmovaps xmm1, [rsp+0x10]
00007a44d59dd0d7  vmovaps xmm2, [rsp+0x20]
00007a44d59dd0dd  vmovaps xmm3, [rsp+0x30]
00007a44d59dd0e3  vmovaps xmm4, [rsp+0x40]
00007a44d59dd0e9  vmovaps xmm5, [rsp+0x50]
00007a44d59dd0ef  vmovaps xmm6, [rsp+0x60]
00007a44d59dd0f5  vmovaps xmm7, [rsp+0x70]
00007a44d59dd0fb  vmovaps xmm8, [rsp+0x80]
00007a44d59dd104  vmovaps xmm9, [rsp+0x90]
00007a44d59dd10d  vmovaps xmm10, [rsp+0xA0]
00007a44d59dd116  vmovaps xmm11, [rsp+0xB0]
00007a44d59dd11f  vmovaps xmm12, [rsp+0xC0]
00007a44d59dd128  vmovaps xmm14, [rsp+0xD0]
00007a44d59dd131  vmovaps xmm15, [rsp+0xE0]
00007a44d59dd13a  add rsp, 0xF0
00007a44d59dd141  pop r11
00007a44d59dd143  pop r10
00007a44d59dd145  pop r9
00007a44d59dd147  pop r8
00007a44d59dd149  pop rsi
00007a44d59dd14a  pop rdi
00007a44d59dd14b  pop rdx
00007a44d59dd14c  pop rcx
00007a44d59dd14d  pop rax
00007a44d59dd14e  add rsp, 0x08
00007a44d59dd152  jmp 0x00007A44D59DA608
00007a44d59dd157  sub rsp, 0x08
00007a44d59dd15b  push rax
00007a44d59dd15c  push rcx
00007a44d59dd15d  push rdx
00007a44d59dd15e  push rdi
00007a44d59dd15f  push rsi
00007a44d59dd160  push r8
00007a44d59dd162  push r9
00007a44d59dd164  push r10
00007a44d59dd166  push r11
00007a44d59dd168  sub rsp, 0xF0
00007a44d59dd16f  vmovaps [rsp], xmm0
00007a44d59dd174  vmovaps [rsp+0x10], xmm1
00007a44d59dd17a  vmovaps [rsp+0x20], xmm2
00007a44d59dd180  vmovaps [rsp+0x30], xmm3
00007a44d59dd186  vmovaps [rsp+0x40], xmm4
00007a44d59dd18c  vmovaps [rsp+0x50], xmm5
00007a44d59dd192  vmovaps [rsp+0x60], xmm6
00007a44d59dd198  vmovaps [rsp+0x70], xmm7
00007a44d59dd19e  vmovaps [rsp+0x80], xmm8
00007a44d59dd1a7  vmovaps [rsp+0x90], xmm9
00007a44d59dd1b0  vmovaps [rsp+0xA0], xmm10
00007a44d59dd1b9  vmovaps [rsp+0xB0], xmm11
00007a44d59dd1c2  vmovaps [rsp+0xC0], xmm12
00007a44d59dd1cb  vmovaps [rsp+0xD0], xmm13
00007a44d59dd1d4  vmovaps [rsp+0xE0], xmm15
00007a44d59dd1dd  sub rsp, 0x40
00007a44d59dd1e1  lea rdi, [rsp]
00007a44d59dd1e5  lea rsi, [rsp+0x10]
00007a44d59dd1ea  lea rdx, [rsp+0x20]
00007a44d59dd1ef  lea rcx, [rsp+0x30]
00007a44d59dd1f4  mov r8d, 0x00
00007a44d59dd1fa  lea r9, [r15+0x3A8]
00007a44d59dd201  movaps [rdi], xmm14
00007a44d59dd205  movaps [rsi], xmm11
00007a44d59dd209  movaps [rdx], xmm1
00007a44d59dd20c  movaps [rcx], xmm15
00007a44d59dd210  mov rax, 0x56179A4B1A50
00007a44d59dd21a  call rax
00007a44d59dd21c  movaps xmm14, [rsp]
00007a44d59dd221  add rsp, 0x40
00007a44d59dd225  vmovaps xmm0, [rsp]
00007a44d59dd22a  vmovaps xmm1, [rsp+0x10]
00007a44d59dd230  vmovaps xmm2, [rsp+0x20]
00007a44d59dd236  vmovaps xmm3, [rsp+0x30]
00007a44d59dd23c  vmovaps xmm4, [rsp+0x40]
00007a44d59dd242  vmovaps xmm5, [rsp+0x50]
00007a44d59dd248  vmovaps xmm6, [rsp+0x60]
00007a44d59dd24e  vmovaps xmm7, [rsp+0x70]
00007a44d59dd254  vmovaps xmm8, [rsp+0x80]
00007a44d59dd25d  vmovaps xmm9, [rsp+0x90]
00007a44d59dd266  vmovaps xmm10, [rsp+0xA0]
00007a44d59dd26f  vmovaps xmm11, [rsp+0xB0]
00007a44d59dd278  vmovaps xmm12, [rsp+0xC0]
00007a44d59dd281  vmovaps xmm13, [rsp+0xD0]
00007a44d59dd28a  vmovaps xmm15, [rsp+0xE0]
00007a44d59dd293  add rsp, 0xF0
00007a44d59dd29a  pop r11
00007a44d59dd29c  pop r10
00007a44d59dd29e  pop r9
00007a44d59dd2a0  pop r8
00007a44d59dd2a2  pop rsi
00007a44d59dd2a3  pop rdi
00007a44d59dd2a4  pop rdx
00007a44d59dd2a5  pop rcx
00007a44d59dd2a6  pop rax
00007a44d59dd2a7  add rsp, 0x08
00007a44d59dd2ab  jmp 0x00007A44D59DA636
00007a44d59dd2b0  call 0x00007A44D58079B0
00007a44d59dd2b5  jmp 0x00007A44D59DA64C
00007a44d59dd2ba  call 0x00007A44D58E3440
00007a44d59dd2bf  jmp 0x00007A44D59DA656
00007a44d59dd2c4  call 0x00007A44D58DFCE0
00007a44d59dd2c9  jmp 0x00007A44D59DA660
00007a44d59dd2ce  call 0x00007A44D58E46C0
00007a44d59dd2d3  jmp 0x00007A44D59DA66A
00007a44d59dd2d8  int3
00007a44d59dd2d9  nop [rax], eax
00007a44d59dd2e0  mov qword ptr [r15+0x40], 0x430000
00007a44d59dd2e8  mov eax, 0x430C50
00007a44d59dd2ed  mov r14, [r13+rax*1]
00007a44d59dd2f2  movq xmm1, r14
00007a44d59dd2f7  mov rax, [r15+0x50]
00007a44d59dd2fb  movups xmm15, [r13+rax*1]
00007a44d59dd301  movaps [r15+0x120], xmm15
00007a44d59dd309  mov qword ptr [r15+0x48], 0x10
00007a44d59dd311  xor eax, eax
00007a44d59dd313  mov r14d, 0x10
00007a44d59dd319  mov r12d, 0x200
00007a44d59dd31f  cmp r14, r12
00007a44d59dd322  cmc
00007a44d59dd323  lahf
00007a44d59dd324  seto al
00007a44d59dd327  mov [r15+0x108], eax
00007a44d59dd32e  pextrq rax, xmm15, 0x01
00007a44d59dd335  movq xmm14, rax
00007a44d59dd33a  movaps [r15+0x130], xmm14
00007a44d59dd342  movq rax, xmm1
00007a44d59dd347  movq r14, xmm15
00007a44d59dd34c  vmovq xmm1, rax
00007a44d59dd351  vmovq xmm15, r14
00007a44d59dd356  movaps xmm13, xmm1
00007a44d59dd35a  addsd xmm13, xmm15
00007a44d59dd35f  ucomisd xmm13, xmm13
00007a44d59dd364  jp 0x00007A44D59DD423
00007a44d59dd36a  movq xmm13, xmm13
00007a44d59dd36f  movq rax, xmm13
00007a44d59dd374  movq r14, xmm14
00007a44d59dd379  vmovq xmm1, rax
00007a44d59dd37e  vmovq xmm15, r14
00007a44d59dd383  movaps xmm14, xmm1
00007a44d59dd387  addsd xmm14, xmm15
00007a44d59dd38c  ucomisd xmm14, xmm14
00007a44d59dd391  jp 0x00007A44D59DD46B
00007a44d59dd397  movq xmm14, xmm14
00007a44d59dd39c  movaps [r15+0x110], xmm14
00007a44d59dd3a4  mov eax, [r15+0x108]
00007a44d59dd3ab  sahf
00007a44d59dd3ac  jnz 0x00007A44D59DD3DE
00007a44d59dd3ae  cmp dword ptr [r15+0x318], 0x00
00007a44d59dd3b6  jz 0x00007A44D59DD680
00007a44d59dd3bc  nop [rax+rax*1], ax
00007a44d59dd3c5  nop [rax+rax*1], eax
00007a44d59dd3cd  mov eax, 0x410698
00007a44d59dd3d2  mov [r15+0x100], rax
00007a44d59dd3d9  jmp 0x00007A44D57FE110
00007a44d59dd3de  cmp dword ptr [r15+0x318], 0x00
00007a44d59dd3e6  jz 0x00007A44D59DD4C0
00007a44d59dd3ec  nop [rax+rax*1], ax
00007a44d59dd3f5  nop [rax+rax*1], eax
00007a44d59dd3fd  mov eax, 0x41067C
00007a44d59dd402  mov [r15+0x100], rax
00007a44d59dd409  jmp 0x00007A44D57FE110
00007a44d59dd40e  int3
00007a44d59dd40f  call 0x00007A44D580DC20
00007a44d59dd414  jmp 0x00007A44D59DD2F2
00007a44d59dd419  call 0x00007A44D580E760
00007a44d59dd41e  jmp 0x00007A44D59DD301
00007a44d59dd423  ucomisd xmm1, xmm15
00007a44d59dd428  jp 0x00007A44D59DD437
00007a44d59dd42a  movaps xmm13, [0x00007A44D55FE060]
00007a44d59dd432  jmp 0x00007A44D59DD36A
00007a44d59dd437  vxorps xmm0, xmm1, xmm15
00007a44d59dd43c  pextrw eax, xmm0, 0x03
00007a44d59dd441  and eax, 0x7FF8
00007a44d59dd446  cmp eax, 0x08
00007a44d59dd449  jnz 0x00007A44D59DD36A
00007a44d59dd44f  movq rax, xmm15
00007a44d59dd454  shl rax, 0x0D
00007a44d59dd458  jbe 0x00007A44D59DD36A
00007a44d59dd45e  vorps xmm13, xmm15, [0x00007A44D55FE070]
00007a44d59dd466  jmp 0x00007A44D59DD36A
00007a44d59dd46b  ucomisd xmm1, xmm15
00007a44d59dd470  jp 0x00007A44D59DD47F
00007a44d59dd472  movaps xmm14, [0x00007A44D55FE060]
00007a44d59dd47a  jmp 0x00007A44D59DD397
00007a44d59dd47f  vxorps xmm0, xmm1, xmm15
00007a44d59dd484  pextrw eax, xmm0, 0x03
00007a44d59dd489  and eax, 0x7FF8
00007a44d59dd48e  cmp eax, 0x08
00007a44d59dd491  jnz 0x00007A44D59DD397
00007a44d59dd497  movq rax, xmm15
00007a44d59dd49c  shl rax, 0x0D
00007a44d59dd4a0  jbe 0x00007A44D59DD397
00007a44d59dd4a6  vorps xmm14, xmm15, [0x00007A44D55FE070]
00007a44d59dd4ae  jmp 0x00007A44D59DD397
00007a44d59dd4b3  int3
00007a44d59dd4b4  nop [rax+rax*1], ax
00007a44d59dd4bd  nop [rax], eax
00007a44d59dd4c0  mov rax, [r15+0x48]
00007a44d59dd4c4  mov r14, [r15+0x50]
00007a44d59dd4c8  lea r12, [r14+rax*1]
00007a44d59dd4cc  movups xmm1, [r13+r12*1]
00007a44d59dd4d2  movaps [r15+0x120], xmm1
00007a44d59dd4da  lea r14, [rax+0x10]
00007a44d59dd4de  mov [r15+0x48], r14
00007a44d59dd4e2  xor eax, eax
00007a44d59dd4e4  mov r12d, 0x200
00007a44d59dd4ea  cmp r14, r12
00007a44d59dd4ed  cmc
00007a44d59dd4ee  lahf
00007a44d59dd4ef  seto al
00007a44d59dd4f2  mov [r15+0x108], eax
00007a44d59dd4f9  pextrq rax, xmm1, 0x01
00007a44d59dd500  movq xmm15, rax
00007a44d59dd505  movaps [r15+0x130], xmm15
00007a44d59dd50d  movaps xmm14, [r15+0x110]
00007a44d59dd515  movq rax, xmm14
00007a44d59dd51a  movq r14, xmm1
00007a44d59dd51f  vmovq xmm1, rax
00007a44d59dd524  vmovq xmm14, r14
00007a44d59dd529  movaps xmm13, xmm1
00007a44d59dd52d  addsd xmm13, xmm14
00007a44d59dd532  ucomisd xmm13, xmm13
00007a44d59dd537  jp 0x00007A44D59DD5EC
00007a44d59dd53d  movq xmm13, xmm13
00007a44d59dd542  movq rax, xmm13
00007a44d59dd547  movq r14, xmm15
00007a44d59dd54c  vmovq xmm1, rax
00007a44d59dd551  vmovq xmm15, r14
00007a44d59dd556  movaps xmm14, xmm1
00007a44d59dd55a  addsd xmm14, xmm15
00007a44d59dd55f  ucomisd xmm14, xmm14
00007a44d59dd564  jp 0x00007A44D59DD634
00007a44d59dd56a  movq xmm14, xmm14
00007a44d59dd56f  movaps [r15+0x110], xmm14
00007a44d59dd577  mov eax, [r15+0x108]
00007a44d59dd57e  sahf
00007a44d59dd57f  jnz 0x00007A44D59DD5B1
00007a44d59dd581  cmp dword ptr [r15+0x318], 0x00
00007a44d59dd589  jz 0x00007A44D59DD680
00007a44d59dd58f  nop [rax+rax*1], ax
00007a44d59dd598  nop [rax+rax*1], eax
00007a44d59dd5a0  mov eax, 0x410698
00007a44d59dd5a5  mov [r15+0x100], rax
00007a44d59dd5ac  jmp 0x00007A44D57FE110
00007a44d59dd5b1  cmp dword ptr [r15+0x318], 0x00
00007a44d59dd5b9  jz 0x00007A44D59DD4C0
00007a44d59dd5bf  nop [rax+rax*1], ax
00007a44d59dd5c8  nop [rax+rax*1], eax
00007a44d59dd5d0  mov eax, 0x41067C
00007a44d59dd5d5  mov [r15+0x100], rax
00007a44d59dd5dc  jmp 0x00007A44D57FE110
00007a44d59dd5e1  int3
00007a44d59dd5e2  call 0x00007A44D58B52F0
00007a44d59dd5e7  jmp 0x00007A44D59DD4D2
00007a44d59dd5ec  ucomisd xmm1, xmm14
00007a44d59dd5f1  jp 0x00007A44D59DD600
00007a44d59dd5f3  movaps xmm13, [0x00007A44D55FE060]
00007a44d59dd5fb  jmp 0x00007A44D59DD53D
00007a44d59dd600  vxorps xmm0, xmm1, xmm14
00007a44d59dd605  pextrw eax, xmm0, 0x03
00007a44d59dd60a  and eax, 0x7FF8
00007a44d59dd60f  cmp eax, 0x08
00007a44d59dd612  jnz 0x00007A44D59DD53D
00007a44d59dd618  movq rax, xmm14
00007a44d59dd61d  shl rax, 0x0D
00007a44d59dd621  jbe 0x00007A44D59DD53D
00007a44d59dd627  vorps xmm13, xmm14, [0x00007A44D55FE070]
00007a44d59dd62f  jmp 0x00007A44D59DD53D
00007a44d59dd634  ucomisd xmm1, xmm15
00007a44d59dd639  jp 0x00007A44D59DD648
00007a44d59dd63b  movaps xmm14, [0x00007A44D55FE060]
00007a44d59dd643  jmp 0x00007A44D59DD56A
00007a44d59dd648  vxorps xmm0, xmm1, xmm15
00007a44d59dd64d  pextrw eax, xmm0, 0x03
00007a44d59dd652  and eax, 0x7FF8
00007a44d59dd657  cmp eax, 0x08
00007a44d59dd65a  jnz 0x00007A44D59DD56A
00007a44d59dd660  movq rax, xmm15
00007a44d59dd665  shl rax, 0x0D
00007a44d59dd669  jbe 0x00007A44D59DD56A
00007a44d59dd66f  vorps xmm14, xmm15, [0x00007A44D55FE070]
00007a44d59dd677  jmp 0x00007A44D59DD56A
00007a44d59dd67c  int3
00007a44d59dd67d  nop [rax], eax
00007a44d59dd680  mov rax, [r15+0xF8]
00007a44d59dd687  lea r14, [rax+0x1A0]
00007a44d59dd68e  mov r12, [r13+r14*1]
00007a44d59dd693  lea r14, [rax+0x1A8]
00007a44d59dd69a  mov r11, [r13+r14*1]
00007a44d59dd69f  mov [r15+0xA0], r12
00007a44d59dd6a6  mov [r15+0x98], r11
00007a44d59dd6ad  mov r14, [r15+0x40]
00007a44d59dd6b1  lea r12, [r14+0xC50]
00007a44d59dd6b8  movaps xmm1, [r15+0x110]
00007a44d59dd6c0  movq r14, xmm1
00007a44d59dd6c5  mov [r13+r12*1], r14
00007a44d59dd6ca  lea r14, [rax+0x190]
00007a44d59dd6d1  mov r12, [r13+r14*1]
00007a44d59dd6d6  lea r14, [rax+0x198]
00007a44d59dd6dd  mov r11, [r13+r14*1]
00007a44d59dd6e2  mov [r15+0xE8], r12
00007a44d59dd6e9  mov [r15+0xF0], r11
00007a44d59dd6f0  lea r14, [rax+0x180]
00007a44d59dd6f7  mov r12, [r13+r14*1]
00007a44d59dd6fc  lea r14, [rax+0x188]
00007a44d59dd703  mov r10, [r13+r14*1]
00007a44d59dd708  movq xmm1, r12
00007a44d59dd70d  movq xmm15, r10
00007a44d59dd712  movq xmm1, xmm1
00007a44d59dd716  movq xmm1, xmm1
00007a44d59dd71a  movaps [r15+0x1A0], xmm1
00007a44d59dd722  movq xmm15, xmm15
00007a44d59dd727  movq xmm15, xmm15
00007a44d59dd72c  movaps [r15+0x190], xmm15
00007a44d59dd734  lea r14, [rax+0x170]
00007a44d59dd73b  mov r12, [r13+r14*1]
00007a44d59dd740  lea r14, [rax+0x178]
00007a44d59dd747  mov r10, [r13+r14*1]
00007a44d59dd74c  movq xmm1, r12
00007a44d59dd751  movq xmm15, r10
00007a44d59dd756  movq xmm1, xmm1
00007a44d59dd75a  movq xmm1, xmm1
00007a44d59dd75e  movaps [r15+0x1C0], xmm1
00007a44d59dd766  movq xmm15, xmm15
00007a44d59dd76b  movq xmm15, xmm15
00007a44d59dd770  movaps [r15+0x1B0], xmm15
00007a44d59dd778  lea r14, [rax+0x160]
00007a44d59dd77f  mov r12, [r13+r14*1]
00007a44d59dd784  lea r14, [rax+0x168]
00007a44d59dd78b  mov r10, [r13+r14*1]
00007a44d59dd790  movq xmm1, r12
00007a44d59dd795  movq xmm15, r10
00007a44d59dd79a  movq xmm1, xmm1
00007a44d59dd79e  movq xmm1, xmm1
00007a44d59dd7a2  movaps [r15+0x1E0], xmm1
00007a44d59dd7aa  movq xmm15, xmm15
00007a44d59dd7af  movq xmm15, xmm15
00007a44d59dd7b4  movaps [r15+0x1D0], xmm15
00007a44d59dd7bc  lea r14, [rax+0x150]
00007a44d59dd7c3  mov r12, [r13+r14*1]
00007a44d59dd7c8  lea r14, [rax+0x158]
00007a44d59dd7cf  mov r10, [r13+r14*1]
00007a44d59dd7d4  movq xmm1, r12
00007a44d59dd7d9  movq xmm15, r10
00007a44d59dd7de  movq xmm1, xmm1
00007a44d59dd7e2  movq xmm1, xmm1
00007a44d59dd7e6  movaps [r15+0x200], xmm1
00007a44d59dd7ee  movq xmm15, xmm15
00007a44d59dd7f3  movq xmm15, xmm15
00007a44d59dd7f8  movaps [r15+0x1F0], xmm15
00007a44d59dd800  lea r14, [rax+0x1B0]
00007a44d59dd807  mov [r15+0xF8], r14
00007a44d59dd80e  mov [r15+0x100], r11
00007a44d59dd815  jmp 0x00007A44D59CE5C0
00007a44d59dd81a  int3
00007a44d59dd81b  call 0x00007A44D58E27E0
00007a44d59dd820  jmp 0x00007A44D59DD693
00007a44d59dd825  call 0x00007A44D58E1570
00007a44d59dd82a  jmp 0x00007A44D59DD69F
00007a44d59dd82f  call 0x00007A44D58C3FE0
00007a44d59dd834  jmp 0x00007A44D59DD6CA
00007a44d59dd839  call 0x00007A44D58E27E0
00007a44d59dd83e  jmp 0x00007A44D59DD6D6
00007a44d59dd843  call 0x00007A44D58E1570
00007a44d59dd848  jmp 0x00007A44D59DD6E2
00007a44d59dd84d  call 0x00007A44D58E27E0
00007a44d59dd852  jmp 0x00007A44D59DD6FC
00007a44d59dd857  call 0x00007A44D58E0300
00007a44d59dd85c  jmp 0x00007A44D59DD708
00007a44d59dd861  call 0x00007A44D58E27E0
00007a44d59dd866  jmp 0x00007A44D59DD740
00007a44d59dd86b  call 0x00007A44D58E0300
00007a44d59dd870  jmp 0x00007A44D59DD74C
00007a44d59dd875  call 0x00007A44D58E27E0
00007a44d59dd87a  jmp 0x00007A44D59DD784
00007a44d59dd87f  call 0x00007A44D58E0300
00007a44d59dd884  jmp 0x00007A44D59DD790
00007a44d59dd889  call 0x00007A44D58E27E0
00007a44d59dd88e  jmp 0x00007A44D59DD7C8
00007a44d59dd893  call 0x00007A44D58E0300
00007a44d59dd898  jmp 0x00007A44D59DD7D4
00007a44d59dd89d  int3
00007a44d59dd89e  nop
00007a44d59dd8a0  mov qword ptr [r15+0x100], 0x04
00007a44d59dd8ab  mov esi, 0x00
00007a44d59dd8b0  mov edx, 0x09
00007a44d59dd8b5  mov rdi, 0x7FFC1AA1DE50
00007a44d59dd8bf  mov rax, 0x56179A344970
00007a44d59dd8c9  call rax
00007a44d59dd8cb  cmp dword ptr [r15+0x318], 0x00
00007a44d59dd8d3  jnz 0x00007A44D57FE110
00007a44d59dd8d9  jmp 0x00007A44D57FE0A0
00007a44d59dd8de  int3
00007a44d59dd8df  int3
