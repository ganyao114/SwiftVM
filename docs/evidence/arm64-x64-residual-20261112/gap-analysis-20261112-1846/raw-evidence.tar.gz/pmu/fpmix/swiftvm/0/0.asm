
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/pmu/fpmix/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x150
   7:	mov    r11,QWORD PTR [r12+0x398]
   f:	mov    QWORD PTR [rsp],r11
  13:	cmp    DWORD PTR [r12+0x310],0x0
  1c:	je     0xa7
  22:	push   rdx
  23:	push   rsi
  24:	push   r10
  26:	push   r11
  28:	mov    rdx,QWORD PTR [rsp+0x20]
  2d:	mov    r10d,edx
  30:	and    r10d,0xc000
  37:	shl    r10d,0x10
  3b:	mov    r11d,edx
  3e:	and    r11d,0x100
  45:	shl    r11d,0x15
  49:	or     r10d,r11d
  4c:	and    edx,0x1
  4f:	shl    edx,0x1c
  52:	or     r10d,edx
  55:	btc    r10,0x1d
  5a:	mov    r11d,0xf0000000
  60:	and    r11,r10
  63:	movabs rsi,0xffffffff0fffffff
  6d:	and    rbx,rsi
  70:	or     rbx,r11
  73:	pop    r11
  75:	pop    r10
  77:	pop    rsi
  78:	pop    rdx
  79:	mov    QWORD PTR [r12+0x108],rbx
  81:	mov    eax,0x410028
  86:	mov    QWORD PTR [r12+0x100],rax
  8e:	add    rsp,0x150
  95:	mov    eax,0x3
  9a:	movabs r11,0x603b7346aca0
  a4:	jmp    r11
  a7:	mov    r13d,0x4240
  ad:	mov    r14d,0xf
  b3:	and    r14d,0xffff
  ba:	mov    rax,r13
  bd:	movabs rcx,0xffffffff0000ffff
  c7:	and    rax,rcx
  ca:	mov    rdx,r14
  cd:	shl    rdx,0x10
  d1:	mov    ecx,0xffff0000
  d6:	and    rdx,rcx
  d9:	or     rax,rdx
  dc:	mov    r15,rax
  df:	mov    QWORD PTR [r12+0x8],r15
  e4:	mov    r13d,0x420080
  ea:	mov    QWORD PTR [r12+0x20],r13
  ef:	mov    r13d,0x0
  f5:	mov    QWORD PTR [r12],r13
  f9:	mov    r13d,0x0
  ff:	movabs r14,0x3ff8000000000000
 109:	mov    QWORD PTR [r12+0x120],r14
 111:	mov    QWORD PTR [r12+0x128],r13
 119:	mov    r13d,0x0
 11f:	movabs r14,0x4000000000000000
 129:	mov    QWORD PTR [r12+0x130],r14
 131:	mov    QWORD PTR [r12+0x138],r13
 139:	mov    r13d,0x0
 13f:	movabs r14,0x3fe0000000000000
 149:	mov    QWORD PTR [r12+0x140],r14
 151:	mov    QWORD PTR [r12+0x148],r13
 159:	mov    r11,rax
 15c:	movzx  eax,WORD PTR [rsp]
 160:	add    al,0x7f
 162:	sahf
 163:	mov    rax,r11
 166:	jmp    0x16b
 16b:	lea    r13,[r12]
 16f:	mov    r14d,0x1e631844
 175:	mov    r15d,0x410048
 17b:	mov    r11,rax
 17e:	lahf
 17f:	seto   al
 182:	mov    WORD PTR [rsp],ax
 186:	mov    rax,r11
 189:	mov    rdx,QWORD PTR [rsp]
 18d:	mov    r10d,edx
 190:	and    r10d,0xc000
 197:	shl    r10d,0x10
 19b:	mov    r11d,edx
 19e:	and    r11d,0x100
 1a5:	shl    r11d,0x15
 1a9:	or     r10d,r11d
 1ac:	and    edx,0x1
 1af:	shl    edx,0x1c
 1b2:	or     r10d,edx
 1b5:	btc    r10,0x1d
 1ba:	mov    r11d,0xf0000000
 1c0:	and    r11,r10
 1c3:	movabs rsi,0xffffffff0fffffff
 1cd:	and    rbx,rsi
 1d0:	or     rbx,r11
 1d3:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 1dd:	movq   xmm0,xmm0
 1e1:	movdqu xmm1,XMMWORD PTR [r12+0x140]
 1eb:	movq   xmm1,xmm1
 1ef:	divsd  xmm0,xmm1
 1f3:	movq   xmm0,xmm0
 1f7:	movdqa xmm14,xmm0
 1fc:	movdqu xmm15,XMMWORD PTR [rip+0xbcb]        # 0xdd0
 205:	pand   xmm14,xmm15
 20a:	movdqu xmm15,XMMWORD PTR [rip+0xbcd]        # 0xde0
 213:	pcmpeqq xmm14,xmm15
 219:	movdqa xmm15,xmm0
 21e:	cmpunordpd xmm15,xmm0
 224:	por    xmm14,xmm15
 229:	pmovmskb ecx,xmm14
 22e:	jrcxz  0x235
 230:	jmp    0x73d
 235:	movdqu XMMWORD PTR [r12+0x150],xmm0
 23f:	mov    eax,0x0
 244:	mov    DWORD PTR [r12+0x324],0x0
 250:	mov    rbp,rax
 253:	lea    r13,[r12]
 257:	mov    r14d,0x9e620005
 25d:	mov    r15d,0x41004c
 263:	mov    rax,QWORD PTR [r12]
 267:	pxor   xmm0,xmm0
 26b:	cvtsi2sd xmm0,rax
 270:	movdqu XMMWORD PTR [r12+0x160],xmm0
 27a:	mov    eax,0x0
 27f:	mov    DWORD PTR [r12+0x324],0x0
 28b:	mov    rbp,rax
 28e:	movdqu xmm2,XMMWORD PTR [r12+0x160]
 298:	movdqu xmm3,XMMWORD PTR [r12+0x120]
 2a2:	movdqa xmm0,xmm2
 2a6:	movdqa xmm1,xmm3
 2aa:	movq   xmm0,xmm0
 2ae:	movq   xmm1,xmm1
 2b2:	addsd  xmm0,xmm1
 2b6:	movdqa xmm14,xmm0
 2bb:	movdqu xmm15,XMMWORD PTR [rip+0xb0c]        # 0xdd0
 2c4:	pand   xmm14,xmm15
 2c9:	movdqu xmm15,XMMWORD PTR [rip+0xb0e]        # 0xde0
 2d2:	pcmpeqq xmm14,xmm15
 2d8:	movdqa xmm15,xmm0
 2dd:	cmpunordpd xmm15,xmm0
 2e3:	por    xmm14,xmm15
 2e8:	pmovmskb ecx,xmm14
 2ed:	jrcxz  0x2f4
 2ef:	jmp    0x64a
 2f4:	movdqa xmm4,xmm0
 2f8:	movdqu XMMWORD PTR [r12+0x160],xmm4
 302:	lea    r13,[r12]
 306:	mov    r14d,0x9e7800a0
 30c:	mov    r15d,0x410054
 312:	movdqu xmm0,XMMWORD PTR [r12+0x160]
 31c:	movq   xmm0,xmm0
 320:	movq   rax,xmm0
 325:	movabs rdx,0x7fffffffffffffff
 32f:	and    rax,rdx
 332:	movabs rdx,0x43e0000000000000
 33c:	cmp    rax,rdx
 33f:	jae    0x849
 345:	cvttsd2si rax,xmm0
 34a:	mov    QWORD PTR [r12],rax
 34e:	mov    eax,0x0
 353:	mov    DWORD PTR [r12+0x324],0x0
 35f:	mov    rbp,rax
 362:	mov    r13,QWORD PTR [r12+0x150]
 36a:	movabs rcx,0x7fffffffffffffff
 374:	mov    r14,r13
 377:	and    r14,rcx
 37a:	movabs rcx,0x7ff0000000000000
 384:	mov    r15,r13
 387:	and    r15,rcx
 38a:	movabs rcx,0x7ff0000000000000
 394:	xor    r15,rcx
 397:	mov    rax,r15
 39a:	test   rax,rax
 39d:	sete   al
 3a0:	movzx  eax,al
 3a3:	and    eax,0x1
 3a6:	mov    rbp,rax
 3a9:	movabs rcx,0xfffffffffffff
 3b3:	mov    r15,r13
 3b6:	and    r15,rcx
 3b9:	mov    rax,r15
 3bc:	test   rax,rax
 3bf:	setne  al
 3c2:	movzx  eax,al
 3c5:	and    eax,0x1
 3c8:	mov    r8,rax
 3cb:	mov    rcx,r8
 3ce:	and    ecx,0xff
 3d4:	mov    r15,rbp
 3d7:	and    r15d,0xff
 3de:	and    r15,rcx
 3e1:	and    r15d,0xff
 3e8:	mov    ebp,DWORD PTR [r12+0x310]
 3f0:	mov    eax,ebp
 3f2:	shr    rax,1
 3f5:	and    eax,0x1
 3f8:	and    eax,0x1
 3fb:	mov    r8,rax
 3fe:	mov    rcx,r15
 401:	and    ecx,0xff
 407:	mov    rbp,r8
 40a:	and    ebp,0xff
 410:	and    rbp,rcx
 413:	and    ebp,0xff
 419:	mov    rax,rbp
 41c:	and    eax,0xff
 421:	test   rax,rax
 424:	je     0x432
 42a:	mov    rax,r13
 42d:	jmp    0x435
 432:	mov    rax,r14
 435:	mov    r15,rax
 438:	mov    r13d,0x0
 43e:	mov    QWORD PTR [r12+0x150],r15
 446:	mov    QWORD PTR [r12+0x158],r13
 44e:	lea    r13,[r12]
 452:	mov    r14d,0x1f431026
 458:	mov    r15d,0x41005c
 45e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 468:	movq   xmm0,xmm0
 46c:	movdqu xmm1,XMMWORD PTR [r12+0x140]
 476:	movq   xmm1,xmm1
 47a:	movdqu xmm14,XMMWORD PTR [r12+0x150]
 484:	movq   xmm14,xmm14
 489:	vfmadd213sd xmm0,xmm1,xmm14
 48e:	movq   xmm0,xmm0
 492:	movdqa xmm14,xmm0
 497:	movdqu xmm15,XMMWORD PTR [rip+0x930]        # 0xdd0
 4a0:	pand   xmm14,xmm15
 4a5:	movdqu xmm15,XMMWORD PTR [rip+0x932]        # 0xde0
 4ae:	pcmpeqq xmm14,xmm15
 4b4:	movdqa xmm15,xmm0
 4b9:	cmpunordpd xmm15,xmm0
 4bf:	por    xmm14,xmm15
 4c4:	pmovmskb ecx,xmm14
 4c9:	jrcxz  0x4d0
 4cb:	jmp    0x8cf
 4d0:	movdqu XMMWORD PTR [r12+0x170],xmm0
 4da:	mov    eax,0x0
 4df:	mov    DWORD PTR [r12+0x324],0x0
 4eb:	mov    rbp,rax
 4ee:	lea    r13,[r12]
 4f2:	mov    r14d,0x1e6220c0
 4f8:	mov    r15d,0x410060
 4fe:	movdqu xmm0,XMMWORD PTR [r12+0x170]
 508:	movq   xmm0,xmm0
 50c:	movdqu xmm1,XMMWORD PTR [r12+0x130]
 516:	movq   xmm1,xmm1
 51a:	ucomisd xmm0,xmm1
 51e:	mov    eax,0x2
 523:	mov    edx,0x8
 528:	cmovb  eax,edx
 52b:	mov    edx,0x6
 530:	cmove  eax,edx
 533:	mov    edx,0x3
 538:	cmovp  eax,edx
 53b:	mov    DWORD PTR [r12+0x324],0x0
 547:	mov    rbp,rax
 54a:	shl    rbp,0x1c
 54e:	mov    rax,rbp
 551:	mov    r11d,0xd0000000
 557:	and    r11,rax
 55a:	movabs rsi,0xffffffff2fffffff
 564:	and    rbx,rsi
 567:	or     rbx,r11
 56a:	mov    rax,rbx
 56d:	shr    rax,0x1f
 571:	and    eax,0x1
 574:	mov    r10,rbx
 577:	shr    r10,0x1c
 57b:	and    r10d,0x1
 57f:	xor    rax,r10
 582:	mov    r10,rbx
 585:	shr    r10,0x1e
 589:	and    r10d,0x1
 58d:	or     rax,r10
 590:	xor    eax,0x1
 593:	test   rax,rax
 596:	jne    0x5b2
 59c:	jmp    0x5a1
 5a1:	mov    r13,QWORD PTR [r12]
 5a5:	add    r13,0x7
 5a9:	mov    QWORD PTR [r12],r13
 5ad:	jmp    0x5b2
 5b2:	mov    r13,QWORD PTR [r12+0x8]
 5b7:	sub    r13,0x1
 5bb:	mov    QWORD PTR [r12+0x8],r13
 5c0:	mov    rcx,QWORD PTR [r12+0x380]
 5c8:	jrcxz  0x5cf
 5ca:	jmp    0x9db
 5cf:	jne    0x16b
 5d5:	mov    r11,rax
 5d8:	lahf
 5d9:	seto   al
 5dc:	mov    WORD PTR [rsp],ax
 5e0:	mov    rax,r11
 5e3:	jmp    0x5e8
 5e8:	mov    r13,QWORD PTR [r12+0x20]
 5ed:	mov    r14,QWORD PTR [r12]
 5f1:	mov    QWORD PTR [r13+0x0],r14
 5f5:	mov    r13d,0x0
 5fb:	mov    DWORD PTR [r12+0x32c],r13d
 603:	mov    rcx,QWORD PTR [r12+0x380]
 60b:	jrcxz  0x612
 60d:	jmp    0xa6f
 612:	mov    r13,QWORD PTR [r12+0xf0]
 61a:	mov    QWORD PTR [r12+0x100],r13
 622:	mov    r11,QWORD PTR [rsp]
 626:	mov    QWORD PTR [r12+0x398],r11
 62e:	mov    rdi,QWORD PTR [r12+0x100]
 636:	add    rsp,0x150
 63d:	movabs r11,0x603b7346a940
 647:	jmp    r11
 64a:	movdqa xmm0,xmm2
 64e:	movdqa xmm1,xmm3
 652:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 65b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 664:	call   0x670
 669:	jmp    0x2f4
 66e:	xchg   ax,ax
 670:	sub    rsp,0x8
 674:	mov    QWORD PTR [r12+0x378],0x3
 680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
 686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
 68c:	mov    QWORD PTR [r12+0x108],rbx
 694:	stmxcsr DWORD PTR [r12-0x28]
 69a:	mov    r10d,DWORD PTR [r12-0x28]
 69f:	test   r10d,0x3f
 6a6:	je     0x6cb
 6ac:	mov    r11d,r10d
 6af:	shr    r10d,1
 6b2:	and    r10d,0x1e
 6b6:	and    r11d,0x1
 6ba:	or     r10d,r11d
 6bd:	or     DWORD PTR [r12+0x314],r10d
 6c5:	and    DWORD PTR [r12-0x28],0xffffffc0
 6cb:	ldmxcsr DWORD PTR [r12-0x38]
 6d1:	lea    rdi,[rsp+0x110]
 6d9:	lea    rsi,[rsp+0xf0]
 6e1:	lea    rdx,[rsp+0x100]
 6e9:	mov    ecx,0xc
 6ee:	mov    r8d,0x0
 6f4:	lea    r9,[r12+0x314]
 6fc:	movabs r11,0x603b732d1650
 706:	call   r11
 709:	ldmxcsr DWORD PTR [r12-0x28]
 70f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
 715:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
 71b:	mov    rbx,QWORD PTR [r12+0x108]
 723:	mov    QWORD PTR [r12+0x378],0x2
 72f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
 738:	add    rsp,0x8
 73c:	ret
 73d:	mov    QWORD PTR [r12+0x378],0x3
 749:	mov    QWORD PTR [r12+0x108],rbx
 751:	stmxcsr DWORD PTR [r12-0x28]
 757:	mov    r10d,DWORD PTR [r12-0x28]
 75c:	test   r10d,0x3f
 763:	je     0x788
 769:	mov    r11d,r10d
 76c:	shr    r10d,1
 76f:	and    r10d,0x1e
 773:	and    r11d,0x1
 777:	or     r10d,r11d
 77a:	or     DWORD PTR [r12+0x314],r10d
 782:	and    DWORD PTR [r12-0x28],0xffffffc0
 788:	ldmxcsr DWORD PTR [r12-0x38]
 78e:	movabs r11,0x603b732cc5e0
 798:	mov    rdi,r13
 79b:	mov    rsi,r14
 79e:	mov    rdx,r15
 7a1:	call   r11
 7a4:	ldmxcsr DWORD PTR [r12-0x28]
 7aa:	mov    rbx,QWORD PTR [r12+0x108]
 7b2:	mov    QWORD PTR [r12+0x378],0x2
 7be:	jmp    0x250
 7c3:	mov    QWORD PTR [r12+0x378],0x3
 7cf:	mov    QWORD PTR [r12+0x108],rbx
 7d7:	stmxcsr DWORD PTR [r12-0x28]
 7dd:	mov    r10d,DWORD PTR [r12-0x28]
 7e2:	test   r10d,0x3f
 7e9:	je     0x80e
 7ef:	mov    r11d,r10d
 7f2:	shr    r10d,1
 7f5:	and    r10d,0x1e
 7f9:	and    r11d,0x1
 7fd:	or     r10d,r11d
 800:	or     DWORD PTR [r12+0x314],r10d
 808:	and    DWORD PTR [r12-0x28],0xffffffc0
 80e:	ldmxcsr DWORD PTR [r12-0x38]
 814:	movabs r11,0x603b732cc5e0
 81e:	mov    rdi,r13
 821:	mov    rsi,r14
 824:	mov    rdx,r15
 827:	call   r11
 82a:	ldmxcsr DWORD PTR [r12-0x28]
 830:	mov    rbx,QWORD PTR [r12+0x108]
 838:	mov    QWORD PTR [r12+0x378],0x2
 844:	jmp    0x28b
 849:	mov    QWORD PTR [r12+0x378],0x3
 855:	mov    QWORD PTR [r12+0x108],rbx
 85d:	stmxcsr DWORD PTR [r12-0x28]
 863:	mov    r10d,DWORD PTR [r12-0x28]
 868:	test   r10d,0x3f
 86f:	je     0x894
 875:	mov    r11d,r10d
 878:	shr    r10d,1
 87b:	and    r10d,0x1e
 87f:	and    r11d,0x1
 883:	or     r10d,r11d
 886:	or     DWORD PTR [r12+0x314],r10d
 88e:	and    DWORD PTR [r12-0x28],0xffffffc0
 894:	ldmxcsr DWORD PTR [r12-0x38]
 89a:	movabs r11,0x603b732cc5e0
 8a4:	mov    rdi,r13
 8a7:	mov    rsi,r14
 8aa:	mov    rdx,r15
 8ad:	call   r11
 8b0:	ldmxcsr DWORD PTR [r12-0x28]
 8b6:	mov    rbx,QWORD PTR [r12+0x108]
 8be:	mov    QWORD PTR [r12+0x378],0x2
 8ca:	jmp    0x35f
 8cf:	mov    QWORD PTR [r12+0x378],0x3
 8db:	mov    QWORD PTR [r12+0x108],rbx
 8e3:	stmxcsr DWORD PTR [r12-0x28]
 8e9:	mov    r10d,DWORD PTR [r12-0x28]
 8ee:	test   r10d,0x3f
 8f5:	je     0x91a
 8fb:	mov    r11d,r10d
 8fe:	shr    r10d,1
 901:	and    r10d,0x1e
 905:	and    r11d,0x1
 909:	or     r10d,r11d
 90c:	or     DWORD PTR [r12+0x314],r10d
 914:	and    DWORD PTR [r12-0x28],0xffffffc0
 91a:	ldmxcsr DWORD PTR [r12-0x38]
 920:	movabs r11,0x603b732cc5e0
 92a:	mov    rdi,r13
 92d:	mov    rsi,r14
 930:	mov    rdx,r15
 933:	call   r11
 936:	ldmxcsr DWORD PTR [r12-0x28]
 93c:	mov    rbx,QWORD PTR [r12+0x108]
 944:	mov    QWORD PTR [r12+0x378],0x2
 950:	jmp    0x4eb
 955:	mov    QWORD PTR [r12+0x378],0x3
 961:	mov    QWORD PTR [r12+0x108],rbx
 969:	stmxcsr DWORD PTR [r12-0x28]
 96f:	mov    r10d,DWORD PTR [r12-0x28]
 974:	test   r10d,0x3f
 97b:	je     0x9a0
 981:	mov    r11d,r10d
 984:	shr    r10d,1
 987:	and    r10d,0x1e
 98b:	and    r11d,0x1
 98f:	or     r10d,r11d
 992:	or     DWORD PTR [r12+0x314],r10d
 99a:	and    DWORD PTR [r12-0x28],0xffffffc0
 9a0:	ldmxcsr DWORD PTR [r12-0x38]
 9a6:	movabs r11,0x603b732cc5e0
 9b0:	mov    rdi,r13
 9b3:	mov    rsi,r14
 9b6:	mov    rdx,r15
 9b9:	call   r11
 9bc:	ldmxcsr DWORD PTR [r12-0x28]
 9c2:	mov    rbx,QWORD PTR [r12+0x108]
 9ca:	mov    QWORD PTR [r12+0x378],0x2
 9d6:	jmp    0x547
 9db:	mov    eax,0x410070
 9e0:	mov    QWORD PTR [r12+0x100],rax
 9e8:	push   rdx
 9e9:	push   rsi
 9ea:	push   r10
 9ec:	push   r11
 9ee:	mov    r11,rax
 9f1:	lahf
 9f2:	seto   al
 9f5:	mov    WORD PTR [rsp+0x20],ax
 9fa:	mov    rax,r11
 9fd:	mov    rdx,QWORD PTR [rsp+0x20]
 a02:	mov    r10d,edx
 a05:	and    r10d,0xc000
 a0c:	shl    r10d,0x10
 a10:	mov    r11d,edx
 a13:	and    r11d,0x100
 a1a:	shl    r11d,0x15
 a1e:	or     r10d,r11d
 a21:	and    edx,0x1
 a24:	shl    edx,0x1c
 a27:	or     r10d,edx
 a2a:	btc    r10,0x1d
 a2f:	mov    r11d,0xf0000000
 a35:	and    r11,r10
 a38:	movabs rsi,0xffffffff0fffffff
 a42:	and    rbx,rsi
 a45:	or     rbx,r11
 a48:	pop    r11
 a4a:	pop    r10
 a4c:	pop    rsi
 a4d:	pop    rdx
 a4e:	mov    QWORD PTR [r12+0x108],rbx
 a56:	add    rsp,0x150
 a5d:	mov    eax,0xc
 a62:	movabs r11,0x603b7346aca0
 a6c:	jmp    r11
 a6f:	mov    eax,0x410078
 a74:	mov    QWORD PTR [r12+0x100],rax
 a7c:	push   rdx
 a7d:	push   rsi
 a7e:	push   r10
 a80:	push   r11
 a82:	mov    rdx,QWORD PTR [rsp+0x20]
 a87:	mov    r10d,edx
 a8a:	and    r10d,0xc000
 a91:	shl    r10d,0x10
 a95:	mov    r11d,edx
 a98:	and    r11d,0x100
 a9f:	shl    r11d,0x15
 aa3:	or     r10d,r11d
 aa6:	and    edx,0x1
 aa9:	shl    edx,0x1c
 aac:	or     r10d,edx
 aaf:	btc    r10,0x1d
 ab4:	mov    r11d,0xf0000000
 aba:	and    r11,r10
 abd:	movabs rsi,0xffffffff0fffffff
 ac7:	and    rbx,rsi
 aca:	or     rbx,r11
 acd:	pop    r11
 acf:	pop    r10
 ad1:	pop    rsi
 ad2:	pop    rdx
 ad3:	mov    QWORD PTR [r12+0x108],rbx
 adb:	add    rsp,0x150
 ae2:	mov    eax,0xc
 ae7:	movabs r11,0x603b7346aca0
 af1:	jmp    r11
 af4:	data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 b00:	sub    rsp,0x150
 b07:	mov    r11,QWORD PTR [r12+0x398]
 b0f:	mov    QWORD PTR [rsp],r11
 b13:	cmp    DWORD PTR [r12+0x310],0x0
 b1c:	je     0xba7
 b22:	push   rdx
 b23:	push   rsi
 b24:	push   r10
 b26:	push   r11
 b28:	mov    rdx,QWORD PTR [rsp+0x20]
 b2d:	mov    r10d,edx
 b30:	and    r10d,0xc000
 b37:	shl    r10d,0x10
 b3b:	mov    r11d,edx
 b3e:	and    r11d,0x100
 b45:	shl    r11d,0x15
 b49:	or     r10d,r11d
 b4c:	and    edx,0x1
 b4f:	shl    edx,0x1c
 b52:	or     r10d,edx
 b55:	btc    r10,0x1d
 b5a:	mov    r11d,0xf0000000
 b60:	and    r11,r10
 b63:	movabs rsi,0xffffffff0fffffff
 b6d:	and    rbx,rsi
 b70:	or     rbx,r11
 b73:	pop    r11
 b75:	pop    r10
 b77:	pop    rsi
 b78:	pop    rdx
 b79:	mov    QWORD PTR [r12+0x108],rbx
 b81:	mov    eax,0x410048
 b86:	mov    QWORD PTR [r12+0x100],rax
 b8e:	add    rsp,0x150
 b95:	mov    eax,0x3
 b9a:	movabs r11,0x603b7346aca0
 ba4:	jmp    r11
 ba7:	mov    r11,rax
 baa:	movzx  eax,WORD PTR [rsp]
 bae:	add    al,0x7f
 bb0:	sahf
 bb1:	mov    rax,r11
 bb4:	jmp    0x16b
 bb9:	nop    DWORD PTR [rax+0x0]
 bc0:	sub    rsp,0x150
 bc7:	mov    r11,QWORD PTR [r12+0x398]
 bcf:	mov    QWORD PTR [rsp],r11
 bd3:	cmp    DWORD PTR [r12+0x310],0x0
 bdc:	je     0xc67
 be2:	push   rdx
 be3:	push   rsi
 be4:	push   r10
 be6:	push   r11
 be8:	mov    rdx,QWORD PTR [rsp+0x20]
 bed:	mov    r10d,edx
 bf0:	and    r10d,0xc000
 bf7:	shl    r10d,0x10
 bfb:	mov    r11d,edx
 bfe:	and    r11d,0x100
 c05:	shl    r11d,0x15
 c09:	or     r10d,r11d
 c0c:	and    edx,0x1
 c0f:	shl    edx,0x1c
 c12:	or     r10d,edx
 c15:	btc    r10,0x1d
 c1a:	mov    r11d,0xf0000000
 c20:	and    r11,r10
 c23:	movabs rsi,0xffffffff0fffffff
 c2d:	and    rbx,rsi
 c30:	or     rbx,r11
 c33:	pop    r11
 c35:	pop    r10
 c37:	pop    rsi
 c38:	pop    rdx
 c39:	mov    QWORD PTR [r12+0x108],rbx
 c41:	mov    eax,0x410068
 c46:	mov    QWORD PTR [r12+0x100],rax
 c4e:	add    rsp,0x150
 c55:	mov    eax,0x3
 c5a:	movabs r11,0x603b7346aca0
 c64:	jmp    r11
 c67:	jmp    0x5a1
 c6c:	nop    DWORD PTR [rax+0x0]
 c70:	sub    rsp,0x150
 c77:	mov    r11,QWORD PTR [r12+0x398]
 c7f:	mov    QWORD PTR [rsp],r11
 c83:	cmp    DWORD PTR [r12+0x310],0x0
 c8c:	je     0xd17
 c92:	push   rdx
 c93:	push   rsi
 c94:	push   r10
 c96:	push   r11
 c98:	mov    rdx,QWORD PTR [rsp+0x20]
 c9d:	mov    r10d,edx
 ca0:	and    r10d,0xc000
 ca7:	shl    r10d,0x10
 cab:	mov    r11d,edx
 cae:	and    r11d,0x100
 cb5:	shl    r11d,0x15
 cb9:	or     r10d,r11d
 cbc:	and    edx,0x1
 cbf:	shl    edx,0x1c
 cc2:	or     r10d,edx
 cc5:	btc    r10,0x1d
 cca:	mov    r11d,0xf0000000
 cd0:	and    r11,r10
 cd3:	movabs rsi,0xffffffff0fffffff
 cdd:	and    rbx,rsi
 ce0:	or     rbx,r11
 ce3:	pop    r11
 ce5:	pop    r10
 ce7:	pop    rsi
 ce8:	pop    rdx
 ce9:	mov    QWORD PTR [r12+0x108],rbx
 cf1:	mov    eax,0x41006c
 cf6:	mov    QWORD PTR [r12+0x100],rax
 cfe:	add    rsp,0x150
 d05:	mov    eax,0x3
 d0a:	movabs r11,0x603b7346aca0
 d14:	jmp    r11
 d17:	jmp    0x5b2
 d1c:	nop    DWORD PTR [rax+0x0]
 d20:	sub    rsp,0x150
 d27:	mov    r11,QWORD PTR [r12+0x398]
 d2f:	mov    QWORD PTR [rsp],r11
 d33:	cmp    DWORD PTR [r12+0x310],0x0
 d3c:	je     0xdc7
 d42:	push   rdx
 d43:	push   rsi
 d44:	push   r10
 d46:	push   r11
 d48:	mov    rdx,QWORD PTR [rsp+0x20]
 d4d:	mov    r10d,edx
 d50:	and    r10d,0xc000
 d57:	shl    r10d,0x10
 d5b:	mov    r11d,edx
 d5e:	and    r11d,0x100
 d65:	shl    r11d,0x15
 d69:	or     r10d,r11d
 d6c:	and    edx,0x1
 d6f:	shl    edx,0x1c
 d72:	or     r10d,edx
 d75:	btc    r10,0x1d
 d7a:	mov    r11d,0xf0000000
 d80:	and    r11,r10
 d83:	movabs rsi,0xffffffff0fffffff
 d8d:	and    rbx,rsi
 d90:	or     rbx,r11
 d93:	pop    r11
 d95:	pop    r10
 d97:	pop    rsi
 d98:	pop    rdx
 d99:	mov    QWORD PTR [r12+0x108],rbx
 da1:	mov    eax,0x410074
 da6:	mov    QWORD PTR [r12+0x100],rax
 dae:	add    rsp,0x150
 db5:	mov    eax,0x3
 dba:	movabs r11,0x603b7346aca0
 dc4:	jmp    r11
 dc7:	jmp    0x5e8
 dcc:	nop    DWORD PTR [rax+0x0]
 dd0:	(bad)
 dd1:	(bad)
 dd2:	(bad)
 dd3:	(bad)
 dd4:	(bad)
 dd5:	(bad)
 dd6:	(bad)
 dd7:	jg     0xdd8
 dd9:	(bad)
 dda:	(bad)
 ddb:	(bad)
 ddc:	(bad)
 ddd:	(bad)
 dde:	(bad)
 ddf:	jg     0xde1
 de1:	add    BYTE PTR [rax],al
 de3:	add    BYTE PTR [rax],al
 de5:	add    BYTE PTR [rax],dl
 de7:	add    BYTE PTR [rax],al
 de9:	add    BYTE PTR [rax],al
 deb:	add    BYTE PTR [rax],al
 ded:	add    BYTE PTR [rax],dl
	...
