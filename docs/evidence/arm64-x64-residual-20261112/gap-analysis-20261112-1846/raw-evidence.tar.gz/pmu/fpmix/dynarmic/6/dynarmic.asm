00007480dd5ce69b  nop [rax+rax*1], eax
00007480dd5ce6a0  mov qword ptr [r15+0x08], 0xF4240
00007480dd5ce6a8  mov qword ptr [r15+0x20], 0x420080
00007480dd5ce6b0  vmovaps xmm1, [0x00007480DD1FE010]
00007480dd5ce6b8  movq xmm1, xmm1
00007480dd5ce6bc  movaps [r15+0x120], xmm1
00007480dd5ce6c4  vmovaps xmm15, [0x00007480DD1FE020]
00007480dd5ce6cc  movq xmm15, xmm15
00007480dd5ce6d1  movaps [r15+0x130], xmm15
00007480dd5ce6d9  vmovaps xmm14, [0x00007480DD1FE030]
00007480dd5ce6e1  movq xmm14, xmm14
00007480dd5ce6e6  movaps [r15+0x140], xmm14
00007480dd5ce6ee  movq rax, xmm15
00007480dd5ce6f3  movq r14, xmm14
00007480dd5ce6f8  vmovq xmm13, rax
00007480dd5ce6fd  vmovq xmm12, r14
00007480dd5ce702  movaps xmm11, xmm13
00007480dd5ce706  divsd xmm11, xmm12
00007480dd5ce70b  ucomisd xmm11, xmm11
00007480dd5ce710  jp 0x00007480DD5CE88B
00007480dd5ce716  movq xmm11, xmm11
00007480dd5ce71b  xor eax, eax
00007480dd5ce71d  cvtsi2sd xmm13, rax
00007480dd5ce722  movq xmm13, xmm13
00007480dd5ce727  movq rax, xmm13
00007480dd5ce72c  movq r14, xmm1
00007480dd5ce731  vmovq xmm13, rax
00007480dd5ce736  vmovq xmm12, r14
00007480dd5ce73b  movaps xmm10, xmm13
00007480dd5ce73f  addsd xmm10, xmm12
00007480dd5ce744  ucomisd xmm10, xmm10
00007480dd5ce749  jp 0x00007480DD5CE8D3
00007480dd5ce74f  movq xmm10, xmm10
00007480dd5ce754  movaps [r15+0x160], xmm10
00007480dd5ce75c  movq rax, xmm10
00007480dd5ce761  vmovq xmm13, rax
00007480dd5ce766  vfixupimmsd xmm13, xmm13, [0x00007480DD1FE040], 0x00
00007480dd5ce771  movsd xmm12, qword ptr [0x00007480DD1FE050]
00007480dd5ce77a  comisd xmm12, xmm13
00007480dd5ce77f  jbe 0x00007480DD5CE91B
00007480dd5ce785  cvttsd2si r14, xmm13
00007480dd5ce78a  mov [r15], r14
00007480dd5ce78d  movq rax, xmm11
00007480dd5ce792  vmovq xmm13, rax
00007480dd5ce797  andps xmm13, [0x00007480DD1FE060]
00007480dd5ce79f  movq xmm13, xmm13
00007480dd5ce7a4  movaps [r15+0x150], xmm13
00007480dd5ce7ac  movq rax, xmm13
00007480dd5ce7b1  movq r14, xmm1
00007480dd5ce7b6  movq r12, xmm14
00007480dd5ce7bb  vmovq xmm1, rax
00007480dd5ce7c0  vmovq xmm14, r14
00007480dd5ce7c5  vmovq xmm13, r12
00007480dd5ce7ca  movaps xmm12, xmm1
00007480dd5ce7ce  vfmadd231sd xmm12, xmm14, xmm13
00007480dd5ce7d3  ucomisd xmm12, xmm12
00007480dd5ce7d8  jp 0x00007480DD5CE92A
00007480dd5ce7de  movq xmm12, xmm12
00007480dd5ce7e3  movaps [r15+0x170], xmm12
00007480dd5ce7eb  movq rax, xmm12
00007480dd5ce7f0  movq r14, xmm15
00007480dd5ce7f5  vmovq xmm1, rax
00007480dd5ce7fa  vmovq xmm15, r14
00007480dd5ce7ff  ucomisd xmm1, xmm15
00007480dd5ce804  mov rax, 0x101410080000100
00007480dd5ce80e  setz cl
00007480dd5ce811  rcl cl, 0x05
00007480dd5ce814  shr rax, cl
00007480dd5ce817  mov [r15+0x108], eax
00007480dd5ce81e  mov eax, [r15+0x108]
00007480dd5ce825  cmp al, 0x81
00007480dd5ce827  sahf
00007480dd5ce828  jnle 0x00007480DD5CE85A
00007480dd5ce82a  cmp dword ptr [r15+0x318], 0x00
00007480dd5ce832  mov eax, 0x410068
00007480dd5ce837  mov [r15+0x100], rax
00007480dd5ce83e  jz 0x00007480DD3FE0A0
00007480dd5ce844  nop [rax+rax*1], eax
00007480dd5ce849  mov eax, 0x410068
00007480dd5ce84e  mov [r15+0x100], rax
00007480dd5ce855  jmp 0x00007480DD3FE110
00007480dd5ce85a  cmp dword ptr [r15+0x318], 0x00
00007480dd5ce862  jz 0x00007480DD5CE9C0
00007480dd5ce868  nop [rax+rax*1], ax
00007480dd5ce871  nop [rax+rax*1], eax
00007480dd5ce879  mov eax, 0x41006C
00007480dd5ce87e  mov [r15+0x100], rax
00007480dd5ce885  jmp 0x00007480DD3FE110
00007480dd5ce88a  int3
00007480dd5ce88b  ucomisd xmm13, xmm12
00007480dd5ce890  jp 0x00007480DD5CE89F
00007480dd5ce892  movaps xmm11, [0x00007480DD1FE070]
00007480dd5ce89a  jmp 0x00007480DD5CE716
00007480dd5ce89f  vxorps xmm0, xmm13, xmm12
00007480dd5ce8a4  pextrw eax, xmm0, 0x03
00007480dd5ce8a9  and eax, 0x7FF8
00007480dd5ce8ae  cmp eax, 0x08
00007480dd5ce8b1  jnz 0x00007480DD5CE716
00007480dd5ce8b7  movq rax, xmm12
00007480dd5ce8bc  shl rax, 0x0D
00007480dd5ce8c0  jbe 0x00007480DD5CE716
00007480dd5ce8c6  vorps xmm11, xmm12, [0x00007480DD1FE080]
00007480dd5ce8ce  jmp 0x00007480DD5CE716
00007480dd5ce8d3  ucomisd xmm13, xmm12
00007480dd5ce8d8  jp 0x00007480DD5CE8E7
00007480dd5ce8da  movaps xmm10, [0x00007480DD1FE070]
00007480dd5ce8e2  jmp 0x00007480DD5CE74F
00007480dd5ce8e7  vxorps xmm0, xmm13, xmm12
00007480dd5ce8ec  pextrw eax, xmm0, 0x03
00007480dd5ce8f1  and eax, 0x7FF8
00007480dd5ce8f6  cmp eax, 0x08
00007480dd5ce8f9  jnz 0x00007480DD5CE74F
00007480dd5ce8ff  movq rax, xmm12
00007480dd5ce904  shl rax, 0x0D
00007480dd5ce908  jbe 0x00007480DD5CE74F
00007480dd5ce90e  vorps xmm10, xmm12, [0x00007480DD1FE080]
00007480dd5ce916  jmp 0x00007480DD5CE74F
00007480dd5ce91b  mov r14, 0x7FFFFFFFFFFFFFFF
00007480dd5ce925  jmp 0x00007480DD5CE78A
00007480dd5ce92a  vmovaps xmm0, [0x00007480DD1FE080]
00007480dd5ce932  ucomisd xmm14, xmm13
00007480dd5ce937  jp 0x00007480DD5CE962
00007480dd5ce939  ucomisd xmm1, xmm1
00007480dd5ce93d  jnp 0x00007480DD5CE955
00007480dd5ce93f  ptest xmm1, xmm0
00007480dd5ce944  jz 0x00007480DD5CE973
00007480dd5ce946  vmulsd xmm0, xmm14, xmm13
00007480dd5ce94b  ucomisd xmm0, xmm0
00007480dd5ce94f  jnp 0x00007480DD5CE7DE
00007480dd5ce955  vmovaps xmm12, [0x00007480DD1FE070]
00007480dd5ce95d  jmp 0x00007480DD5CE7DE
00007480dd5ce962  ucomisd xmm1, xmm1
00007480dd5ce966  jnp 0x00007480DD5CE97C
00007480dd5ce968  movaps xmm12, xmm1
00007480dd5ce96c  ptest xmm1, xmm0
00007480dd5ce971  jnz 0x00007480DD5CE97C
00007480dd5ce973  vorps xmm12, xmm1, xmm0
00007480dd5ce977  jmp 0x00007480DD5CE7DE
00007480dd5ce97c  ucomisd xmm14, xmm14
00007480dd5ce981  jnp 0x00007480DD5CE994
00007480dd5ce983  ptest xmm14, xmm0
00007480dd5ce989  jnz 0x00007480DD5CE994
00007480dd5ce98b  vorps xmm12, xmm14, xmm0
00007480dd5ce98f  jmp 0x00007480DD5CE7DE
00007480dd5ce994  ucomisd xmm13, xmm13
00007480dd5ce999  jnp 0x00007480DD5CE9AC
00007480dd5ce99b  ptest xmm13, xmm0
00007480dd5ce9a1  jnz 0x00007480DD5CE9AC
00007480dd5ce9a3  vorps xmm12, xmm13, xmm0
00007480dd5ce9a7  jmp 0x00007480DD5CE7DE
00007480dd5ce9ac  jmp 0x00007480DD5CE7DE
00007480dd5ce9b1  int3
00007480dd5ce9b2  nop [rax+rax*1], ax
00007480dd5ce9bb  nop [rax+rax*1], eax
00007480dd5ce9c0  mov rax, [r15+0x08]
00007480dd5ce9c4  mov [rsp+0x10], rax
00007480dd5ce9c9  xor eax, eax
00007480dd5ce9cb  mov r14, [rsp+0x10]
00007480dd5ce9d0  mov r12d, 0x01
00007480dd5ce9d6  sub r14, r12
00007480dd5ce9d9  cmc
00007480dd5ce9da  lahf
00007480dd5ce9db  seto al
00007480dd5ce9de  mov [r15+0x108], eax
00007480dd5ce9e5  mov [r15+0x08], r14
00007480dd5ce9e9  mov eax, [r15+0x108]
00007480dd5ce9f0  sahf
00007480dd5ce9f1  jnz 0x00007480DD5CEA23
00007480dd5ce9f3  cmp dword ptr [r15+0x318], 0x00
00007480dd5ce9fb  jz 0x00007480DD5CED50
00007480dd5cea01  nop [rax+rax*1], ax
00007480dd5cea0a  nop [rax+rax*1], eax
00007480dd5cea12  mov eax, 0x410074
00007480dd5cea17  mov [r15+0x100], rax
00007480dd5cea1e  jmp 0x00007480DD3FE110
00007480dd5cea23  cmp dword ptr [r15+0x318], 0x00
00007480dd5cea2b  jz 0x00007480DD5CEA60
00007480dd5cea31  nop [rax+rax*1], ax
00007480dd5cea3a  nop [rax+rax*1], eax
00007480dd5cea42  mov eax, 0x410048
00007480dd5cea47  mov [r15+0x100], rax
00007480dd5cea4e  jmp 0x00007480DD3FE110
00007480dd5cea53  int3
00007480dd5cea54  int3
00007480dd5cea55  nop [rax+rax*1], ax
00007480dd5cea5e  nop
00007480dd5cea60  movaps xmm1, [r15+0x130]
00007480dd5cea68  movq rax, xmm1
00007480dd5cea6d  movaps xmm15, [r15+0x140]
00007480dd5cea75  movq r14, xmm15
00007480dd5cea7a  vmovq xmm14, rax
00007480dd5cea7f  vmovq xmm13, r14
00007480dd5cea84  movaps xmm12, xmm14
00007480dd5cea88  divsd xmm12, xmm13
00007480dd5cea8d  ucomisd xmm12, xmm12
00007480dd5cea92  jp 0x00007480DD5CEC16
00007480dd5cea98  movq xmm12, xmm12
00007480dd5cea9d  mov rax, [r15]
00007480dd5ceaa0  cvtsi2sd xmm14, rax
00007480dd5ceaa5  movq xmm14, xmm14
00007480dd5ceaaa  movq rax, xmm14
00007480dd5ceaaf  movaps xmm14, [r15+0x120]
00007480dd5ceab7  movq r14, xmm14
00007480dd5ceabc  vmovq xmm13, rax
00007480dd5ceac1  vmovq xmm11, r14
00007480dd5ceac6  movaps xmm10, xmm13
00007480dd5ceaca  addsd xmm10, xmm11
00007480dd5ceacf  ucomisd xmm10, xmm10
00007480dd5cead4  jp 0x00007480DD5CEC5E
00007480dd5ceada  movq xmm10, xmm10
00007480dd5ceadf  movaps [r15+0x160], xmm10
00007480dd5ceae7  movq rax, xmm10
00007480dd5ceaec  vmovq xmm13, rax
00007480dd5ceaf1  vfixupimmsd xmm13, xmm13, [0x00007480DD1FE040], 0x00
00007480dd5ceafc  movsd xmm11, qword ptr [0x00007480DD1FE050]
00007480dd5ceb05  comisd xmm11, xmm13
00007480dd5ceb0a  jbe 0x00007480DD5CECA6
00007480dd5ceb10  cvttsd2si r14, xmm13
00007480dd5ceb15  mov [r15], r14
00007480dd5ceb18  movq rax, xmm12
00007480dd5ceb1d  vmovq xmm13, rax
00007480dd5ceb22  andps xmm13, [0x00007480DD1FE060]
00007480dd5ceb2a  movq xmm13, xmm13
00007480dd5ceb2f  movaps [r15+0x150], xmm13
00007480dd5ceb37  movq rax, xmm13
00007480dd5ceb3c  movq r14, xmm14
00007480dd5ceb41  movq r12, xmm15
00007480dd5ceb46  vmovq xmm15, rax
00007480dd5ceb4b  vmovq xmm14, r14
00007480dd5ceb50  vmovq xmm13, r12
00007480dd5ceb55  movaps xmm12, xmm15
00007480dd5ceb59  vfmadd231sd xmm12, xmm14, xmm13
00007480dd5ceb5e  ucomisd xmm12, xmm12
00007480dd5ceb63  jp 0x00007480DD5CECB5
00007480dd5ceb69  movq xmm12, xmm12
00007480dd5ceb6e  movaps [r15+0x170], xmm12
00007480dd5ceb76  movq rax, xmm12
00007480dd5ceb7b  movq r14, xmm1
00007480dd5ceb80  vmovq xmm1, rax
00007480dd5ceb85  vmovq xmm15, r14
00007480dd5ceb8a  ucomisd xmm1, xmm15
00007480dd5ceb8f  mov rax, 0x101410080000100
00007480dd5ceb99  setz cl
00007480dd5ceb9c  rcl cl, 0x05
00007480dd5ceb9f  shr rax, cl
00007480dd5ceba2  mov [r15+0x108], eax
00007480dd5ceba9  mov eax, [r15+0x108]
00007480dd5cebb0  cmp al, 0x81
00007480dd5cebb2  sahf
00007480dd5cebb3  jnle 0x00007480DD5CEBE5
00007480dd5cebb5  cmp dword ptr [r15+0x318], 0x00
00007480dd5cebbd  mov eax, 0x410068
00007480dd5cebc2  mov [r15+0x100], rax
00007480dd5cebc9  jz 0x00007480DD3FE0A0
00007480dd5cebcf  nop [rax+rax*1], eax
00007480dd5cebd4  mov eax, 0x410068
00007480dd5cebd9  mov [r15+0x100], rax
00007480dd5cebe0  jmp 0x00007480DD3FE110
00007480dd5cebe5  cmp dword ptr [r15+0x318], 0x00
00007480dd5cebed  jz 0x00007480DD5CE9C0
00007480dd5cebf3  nop [rax+rax*1], ax
00007480dd5cebfc  nop [rax+rax*1], eax
00007480dd5cec04  mov eax, 0x41006C
00007480dd5cec09  mov [r15+0x100], rax
00007480dd5cec10  jmp 0x00007480DD3FE110
00007480dd5cec15  int3
00007480dd5cec16  ucomisd xmm14, xmm13
00007480dd5cec1b  jp 0x00007480DD5CEC2A
00007480dd5cec1d  movaps xmm12, [0x00007480DD1FE070]
00007480dd5cec25  jmp 0x00007480DD5CEA98
00007480dd5cec2a  vxorps xmm0, xmm14, xmm13
00007480dd5cec2f  pextrw eax, xmm0, 0x03
00007480dd5cec34  and eax, 0x7FF8
00007480dd5cec39  cmp eax, 0x08
00007480dd5cec3c  jnz 0x00007480DD5CEA98
00007480dd5cec42  movq rax, xmm13
00007480dd5cec47  shl rax, 0x0D
00007480dd5cec4b  jbe 0x00007480DD5CEA98
00007480dd5cec51  vorps xmm12, xmm13, [0x00007480DD1FE080]
00007480dd5cec59  jmp 0x00007480DD5CEA98
00007480dd5cec5e  ucomisd xmm13, xmm11
00007480dd5cec63  jp 0x00007480DD5CEC72
00007480dd5cec65  movaps xmm10, [0x00007480DD1FE070]
00007480dd5cec6d  jmp 0x00007480DD5CEADA
00007480dd5cec72  vxorps xmm0, xmm13, xmm11
00007480dd5cec77  pextrw eax, xmm0, 0x03
00007480dd5cec7c  and eax, 0x7FF8
00007480dd5cec81  cmp eax, 0x08
00007480dd5cec84  jnz 0x00007480DD5CEADA
00007480dd5cec8a  movq rax, xmm11
00007480dd5cec8f  shl rax, 0x0D
00007480dd5cec93  jbe 0x00007480DD5CEADA
00007480dd5cec99  vorps xmm10, xmm11, [0x00007480DD1FE080]
00007480dd5ceca1  jmp 0x00007480DD5CEADA
00007480dd5ceca6  mov r14, 0x7FFFFFFFFFFFFFFF
00007480dd5cecb0  jmp 0x00007480DD5CEB15
00007480dd5cecb5  vmovaps xmm0, [0x00007480DD1FE080]
00007480dd5cecbd  ucomisd xmm14, xmm13
00007480dd5cecc2  jp 0x00007480DD5CECEF
00007480dd5cecc4  ucomisd xmm15, xmm15
00007480dd5cecc9  jnp 0x00007480DD5CECE2
00007480dd5ceccb  ptest xmm15, xmm0
00007480dd5cecd1  jz 0x00007480DD5CED02
00007480dd5cecd3  vmulsd xmm0, xmm14, xmm13
00007480dd5cecd8  ucomisd xmm0, xmm0
00007480dd5cecdc  jnp 0x00007480DD5CEB69
00007480dd5cece2  vmovaps xmm12, [0x00007480DD1FE070]
00007480dd5cecea  jmp 0x00007480DD5CEB69
00007480dd5cecef  ucomisd xmm15, xmm15
00007480dd5cecf4  jnp 0x00007480DD5CED0B
00007480dd5cecf6  movaps xmm12, xmm15
00007480dd5cecfa  ptest xmm15, xmm0
00007480dd5ced00  jnz 0x00007480DD5CED0B
00007480dd5ced02  vorps xmm12, xmm15, xmm0
00007480dd5ced06  jmp 0x00007480DD5CEB69
00007480dd5ced0b  ucomisd xmm14, xmm14
00007480dd5ced10  jnp 0x00007480DD5CED23
00007480dd5ced12  ptest xmm14, xmm0
00007480dd5ced18  jnz 0x00007480DD5CED23
00007480dd5ced1a  vorps xmm12, xmm14, xmm0
00007480dd5ced1e  jmp 0x00007480DD5CEB69
00007480dd5ced23  ucomisd xmm13, xmm13
00007480dd5ced28  jnp 0x00007480DD5CED3B
00007480dd5ced2a  ptest xmm13, xmm0
00007480dd5ced30  jnz 0x00007480DD5CED3B
00007480dd5ced32  vorps xmm12, xmm13, xmm0
00007480dd5ced36  jmp 0x00007480DD5CEB69
00007480dd5ced3b  jmp 0x00007480DD5CEB69
00007480dd5ced40  int3
00007480dd5ced41  nop [rax+rax*1], ax
00007480dd5ced4a  nop [rax+rax*1], ax
00007480dd5ced50  mov rax, [r15+0x20]
00007480dd5ced54  mov r14, [r15]
00007480dd5ced57  mov [r13+rax*1], r14
00007480dd5ced5c  mov rax, [r15+0xF0]
00007480dd5ced63  mov [r15+0x100], rax
00007480dd5ced6a  jmp 0x00007480DD5CE5C0
00007480dd5ced6f  int3
00007480dd5ced70  call 0x00007480DD40E120
00007480dd5ced75  jmp 0x00007480DD5CED5C
00007480dd5ced7a  int3
00007480dd5ced7b  nop [rax+rax*1], eax
00007480dd5ced80  mov qword ptr [r15+0x100], 0x04
00007480dd5ced8b  mov esi, 0x00
00007480dd5ced90  mov edx, 0x09
00007480dd5ced95  mov rdi, 0x7FFDA3D5C9C0
00007480dd5ced9f  mov rax, 0x5A0316A72970
00007480dd5ceda9  call rax
00007480dd5cedab  cmp dword ptr [r15+0x318], 0x00
00007480dd5cedb3  jnz 0x00007480DD3FE110
00007480dd5cedb9  jmp 0x00007480DD3FE0A0
00007480dd5cedbe  int3
00007480dd5cedbf  int3
