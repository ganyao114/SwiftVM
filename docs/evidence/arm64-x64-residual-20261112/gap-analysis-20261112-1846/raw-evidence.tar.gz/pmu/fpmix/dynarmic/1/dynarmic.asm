000070a53a9ce69b  nop [rax+rax*1], eax
000070a53a9ce6a0  mov qword ptr [r15+0x08], 0xF4240
000070a53a9ce6a8  mov qword ptr [r15+0x20], 0x420080
000070a53a9ce6b0  vmovaps xmm1, [0x000070A53A5FE010]
000070a53a9ce6b8  movq xmm1, xmm1
000070a53a9ce6bc  movaps [r15+0x120], xmm1
000070a53a9ce6c4  vmovaps xmm15, [0x000070A53A5FE020]
000070a53a9ce6cc  movq xmm15, xmm15
000070a53a9ce6d1  movaps [r15+0x130], xmm15
000070a53a9ce6d9  vmovaps xmm14, [0x000070A53A5FE030]
000070a53a9ce6e1  movq xmm14, xmm14
000070a53a9ce6e6  movaps [r15+0x140], xmm14
000070a53a9ce6ee  movq rax, xmm15
000070a53a9ce6f3  movq r14, xmm14
000070a53a9ce6f8  vmovq xmm13, rax
000070a53a9ce6fd  vmovq xmm12, r14
000070a53a9ce702  movaps xmm11, xmm13
000070a53a9ce706  divsd xmm11, xmm12
000070a53a9ce70b  ucomisd xmm11, xmm11
000070a53a9ce710  jp 0x000070A53A9CE88B
000070a53a9ce716  movq xmm11, xmm11
000070a53a9ce71b  xor eax, eax
000070a53a9ce71d  cvtsi2sd xmm13, rax
000070a53a9ce722  movq xmm13, xmm13
000070a53a9ce727  movq rax, xmm13
000070a53a9ce72c  movq r14, xmm1
000070a53a9ce731  vmovq xmm13, rax
000070a53a9ce736  vmovq xmm12, r14
000070a53a9ce73b  movaps xmm10, xmm13
000070a53a9ce73f  addsd xmm10, xmm12
000070a53a9ce744  ucomisd xmm10, xmm10
000070a53a9ce749  jp 0x000070A53A9CE8D3
000070a53a9ce74f  movq xmm10, xmm10
000070a53a9ce754  movaps [r15+0x160], xmm10
000070a53a9ce75c  movq rax, xmm10
000070a53a9ce761  vmovq xmm13, rax
000070a53a9ce766  vfixupimmsd xmm13, xmm13, [0x000070A53A5FE040], 0x00
000070a53a9ce771  movsd xmm12, qword ptr [0x000070A53A5FE050]
000070a53a9ce77a  comisd xmm12, xmm13
000070a53a9ce77f  jbe 0x000070A53A9CE91B
000070a53a9ce785  cvttsd2si r14, xmm13
000070a53a9ce78a  mov [r15], r14
000070a53a9ce78d  movq rax, xmm11
000070a53a9ce792  vmovq xmm13, rax
000070a53a9ce797  andps xmm13, [0x000070A53A5FE060]
000070a53a9ce79f  movq xmm13, xmm13
000070a53a9ce7a4  movaps [r15+0x150], xmm13
000070a53a9ce7ac  movq rax, xmm13
000070a53a9ce7b1  movq r14, xmm1
000070a53a9ce7b6  movq r12, xmm14
000070a53a9ce7bb  vmovq xmm1, rax
000070a53a9ce7c0  vmovq xmm14, r14
000070a53a9ce7c5  vmovq xmm13, r12
000070a53a9ce7ca  movaps xmm12, xmm1
000070a53a9ce7ce  vfmadd231sd xmm12, xmm14, xmm13
000070a53a9ce7d3  ucomisd xmm12, xmm12
000070a53a9ce7d8  jp 0x000070A53A9CE92A
000070a53a9ce7de  movq xmm12, xmm12
000070a53a9ce7e3  movaps [r15+0x170], xmm12
000070a53a9ce7eb  movq rax, xmm12
000070a53a9ce7f0  movq r14, xmm15
000070a53a9ce7f5  vmovq xmm1, rax
000070a53a9ce7fa  vmovq xmm15, r14
000070a53a9ce7ff  ucomisd xmm1, xmm15
000070a53a9ce804  mov rax, 0x101410080000100
000070a53a9ce80e  setz cl
000070a53a9ce811  rcl cl, 0x05
000070a53a9ce814  shr rax, cl
000070a53a9ce817  mov [r15+0x108], eax
000070a53a9ce81e  mov eax, [r15+0x108]
000070a53a9ce825  cmp al, 0x81
000070a53a9ce827  sahf
000070a53a9ce828  jnle 0x000070A53A9CE85A
000070a53a9ce82a  cmp dword ptr [r15+0x318], 0x00
000070a53a9ce832  mov eax, 0x410068
000070a53a9ce837  mov [r15+0x100], rax
000070a53a9ce83e  jz 0x000070A53A7FE0A0
000070a53a9ce844  nop [rax+rax*1], eax
000070a53a9ce849  mov eax, 0x410068
000070a53a9ce84e  mov [r15+0x100], rax
000070a53a9ce855  jmp 0x000070A53A7FE110
000070a53a9ce85a  cmp dword ptr [r15+0x318], 0x00
000070a53a9ce862  jz 0x000070A53A9CE9C0
000070a53a9ce868  nop [rax+rax*1], ax
000070a53a9ce871  nop [rax+rax*1], eax
000070a53a9ce879  mov eax, 0x41006C
000070a53a9ce87e  mov [r15+0x100], rax
000070a53a9ce885  jmp 0x000070A53A7FE110
000070a53a9ce88a  int3
000070a53a9ce88b  ucomisd xmm13, xmm12
000070a53a9ce890  jp 0x000070A53A9CE89F
000070a53a9ce892  movaps xmm11, [0x000070A53A5FE070]
000070a53a9ce89a  jmp 0x000070A53A9CE716
000070a53a9ce89f  vxorps xmm0, xmm13, xmm12
000070a53a9ce8a4  pextrw eax, xmm0, 0x03
000070a53a9ce8a9  and eax, 0x7FF8
000070a53a9ce8ae  cmp eax, 0x08
000070a53a9ce8b1  jnz 0x000070A53A9CE716
000070a53a9ce8b7  movq rax, xmm12
000070a53a9ce8bc  shl rax, 0x0D
000070a53a9ce8c0  jbe 0x000070A53A9CE716
000070a53a9ce8c6  vorps xmm11, xmm12, [0x000070A53A5FE080]
000070a53a9ce8ce  jmp 0x000070A53A9CE716
000070a53a9ce8d3  ucomisd xmm13, xmm12
000070a53a9ce8d8  jp 0x000070A53A9CE8E7
000070a53a9ce8da  movaps xmm10, [0x000070A53A5FE070]
000070a53a9ce8e2  jmp 0x000070A53A9CE74F
000070a53a9ce8e7  vxorps xmm0, xmm13, xmm12
000070a53a9ce8ec  pextrw eax, xmm0, 0x03
000070a53a9ce8f1  and eax, 0x7FF8
000070a53a9ce8f6  cmp eax, 0x08
000070a53a9ce8f9  jnz 0x000070A53A9CE74F
000070a53a9ce8ff  movq rax, xmm12
000070a53a9ce904  shl rax, 0x0D
000070a53a9ce908  jbe 0x000070A53A9CE74F
000070a53a9ce90e  vorps xmm10, xmm12, [0x000070A53A5FE080]
000070a53a9ce916  jmp 0x000070A53A9CE74F
000070a53a9ce91b  mov r14, 0x7FFFFFFFFFFFFFFF
000070a53a9ce925  jmp 0x000070A53A9CE78A
000070a53a9ce92a  vmovaps xmm0, [0x000070A53A5FE080]
000070a53a9ce932  ucomisd xmm14, xmm13
000070a53a9ce937  jp 0x000070A53A9CE962
000070a53a9ce939  ucomisd xmm1, xmm1
000070a53a9ce93d  jnp 0x000070A53A9CE955
000070a53a9ce93f  ptest xmm1, xmm0
000070a53a9ce944  jz 0x000070A53A9CE973
000070a53a9ce946  vmulsd xmm0, xmm14, xmm13
000070a53a9ce94b  ucomisd xmm0, xmm0
000070a53a9ce94f  jnp 0x000070A53A9CE7DE
000070a53a9ce955  vmovaps xmm12, [0x000070A53A5FE070]
000070a53a9ce95d  jmp 0x000070A53A9CE7DE
000070a53a9ce962  ucomisd xmm1, xmm1
000070a53a9ce966  jnp 0x000070A53A9CE97C
000070a53a9ce968  movaps xmm12, xmm1
000070a53a9ce96c  ptest xmm1, xmm0
000070a53a9ce971  jnz 0x000070A53A9CE97C
000070a53a9ce973  vorps xmm12, xmm1, xmm0
000070a53a9ce977  jmp 0x000070A53A9CE7DE
000070a53a9ce97c  ucomisd xmm14, xmm14
000070a53a9ce981  jnp 0x000070A53A9CE994
000070a53a9ce983  ptest xmm14, xmm0
000070a53a9ce989  jnz 0x000070A53A9CE994
000070a53a9ce98b  vorps xmm12, xmm14, xmm0
000070a53a9ce98f  jmp 0x000070A53A9CE7DE
000070a53a9ce994  ucomisd xmm13, xmm13
000070a53a9ce999  jnp 0x000070A53A9CE9AC
000070a53a9ce99b  ptest xmm13, xmm0
000070a53a9ce9a1  jnz 0x000070A53A9CE9AC
000070a53a9ce9a3  vorps xmm12, xmm13, xmm0
000070a53a9ce9a7  jmp 0x000070A53A9CE7DE
000070a53a9ce9ac  jmp 0x000070A53A9CE7DE
000070a53a9ce9b1  int3
000070a53a9ce9b2  nop [rax+rax*1], ax
000070a53a9ce9bb  nop [rax+rax*1], eax
000070a53a9ce9c0  mov rax, [r15+0x08]
000070a53a9ce9c4  mov [rsp+0x10], rax
000070a53a9ce9c9  xor eax, eax
000070a53a9ce9cb  mov r14, [rsp+0x10]
000070a53a9ce9d0  mov r12d, 0x01
000070a53a9ce9d6  sub r14, r12
000070a53a9ce9d9  cmc
000070a53a9ce9da  lahf
000070a53a9ce9db  seto al
000070a53a9ce9de  mov [r15+0x108], eax
000070a53a9ce9e5  mov [r15+0x08], r14
000070a53a9ce9e9  mov eax, [r15+0x108]
000070a53a9ce9f0  sahf
000070a53a9ce9f1  jnz 0x000070A53A9CEA23
000070a53a9ce9f3  cmp dword ptr [r15+0x318], 0x00
000070a53a9ce9fb  jz 0x000070A53A9CED50
000070a53a9cea01  nop [rax+rax*1], ax
000070a53a9cea0a  nop [rax+rax*1], eax
000070a53a9cea12  mov eax, 0x410074
000070a53a9cea17  mov [r15+0x100], rax
000070a53a9cea1e  jmp 0x000070A53A7FE110
000070a53a9cea23  cmp dword ptr [r15+0x318], 0x00
000070a53a9cea2b  jz 0x000070A53A9CEA60
000070a53a9cea31  nop [rax+rax*1], ax
000070a53a9cea3a  nop [rax+rax*1], eax
000070a53a9cea42  mov eax, 0x410048
000070a53a9cea47  mov [r15+0x100], rax
000070a53a9cea4e  jmp 0x000070A53A7FE110
000070a53a9cea53  int3
000070a53a9cea54  int3
000070a53a9cea55  nop [rax+rax*1], ax
000070a53a9cea5e  nop
000070a53a9cea60  movaps xmm1, [r15+0x130]
000070a53a9cea68  movq rax, xmm1
000070a53a9cea6d  movaps xmm15, [r15+0x140]
000070a53a9cea75  movq r14, xmm15
000070a53a9cea7a  vmovq xmm14, rax
000070a53a9cea7f  vmovq xmm13, r14
000070a53a9cea84  movaps xmm12, xmm14
000070a53a9cea88  divsd xmm12, xmm13
000070a53a9cea8d  ucomisd xmm12, xmm12
000070a53a9cea92  jp 0x000070A53A9CEC16
000070a53a9cea98  movq xmm12, xmm12
000070a53a9cea9d  mov rax, [r15]
000070a53a9ceaa0  cvtsi2sd xmm14, rax
000070a53a9ceaa5  movq xmm14, xmm14
000070a53a9ceaaa  movq rax, xmm14
000070a53a9ceaaf  movaps xmm14, [r15+0x120]
000070a53a9ceab7  movq r14, xmm14
000070a53a9ceabc  vmovq xmm13, rax
000070a53a9ceac1  vmovq xmm11, r14
000070a53a9ceac6  movaps xmm10, xmm13
000070a53a9ceaca  addsd xmm10, xmm11
000070a53a9ceacf  ucomisd xmm10, xmm10
000070a53a9cead4  jp 0x000070A53A9CEC5E
000070a53a9ceada  movq xmm10, xmm10
000070a53a9ceadf  movaps [r15+0x160], xmm10
000070a53a9ceae7  movq rax, xmm10
000070a53a9ceaec  vmovq xmm13, rax
000070a53a9ceaf1  vfixupimmsd xmm13, xmm13, [0x000070A53A5FE040], 0x00
000070a53a9ceafc  movsd xmm11, qword ptr [0x000070A53A5FE050]
000070a53a9ceb05  comisd xmm11, xmm13
000070a53a9ceb0a  jbe 0x000070A53A9CECA6
000070a53a9ceb10  cvttsd2si r14, xmm13
000070a53a9ceb15  mov [r15], r14
000070a53a9ceb18  movq rax, xmm12
000070a53a9ceb1d  vmovq xmm13, rax
000070a53a9ceb22  andps xmm13, [0x000070A53A5FE060]
000070a53a9ceb2a  movq xmm13, xmm13
000070a53a9ceb2f  movaps [r15+0x150], xmm13
000070a53a9ceb37  movq rax, xmm13
000070a53a9ceb3c  movq r14, xmm14
000070a53a9ceb41  movq r12, xmm15
000070a53a9ceb46  vmovq xmm15, rax
000070a53a9ceb4b  vmovq xmm14, r14
000070a53a9ceb50  vmovq xmm13, r12
000070a53a9ceb55  movaps xmm12, xmm15
000070a53a9ceb59  vfmadd231sd xmm12, xmm14, xmm13
000070a53a9ceb5e  ucomisd xmm12, xmm12
000070a53a9ceb63  jp 0x000070A53A9CECB5
000070a53a9ceb69  movq xmm12, xmm12
000070a53a9ceb6e  movaps [r15+0x170], xmm12
000070a53a9ceb76  movq rax, xmm12
000070a53a9ceb7b  movq r14, xmm1
000070a53a9ceb80  vmovq xmm1, rax
000070a53a9ceb85  vmovq xmm15, r14
000070a53a9ceb8a  ucomisd xmm1, xmm15
000070a53a9ceb8f  mov rax, 0x101410080000100
000070a53a9ceb99  setz cl
000070a53a9ceb9c  rcl cl, 0x05
000070a53a9ceb9f  shr rax, cl
000070a53a9ceba2  mov [r15+0x108], eax
000070a53a9ceba9  mov eax, [r15+0x108]
000070a53a9cebb0  cmp al, 0x81
000070a53a9cebb2  sahf
000070a53a9cebb3  jnle 0x000070A53A9CEBE5
000070a53a9cebb5  cmp dword ptr [r15+0x318], 0x00
000070a53a9cebbd  mov eax, 0x410068
000070a53a9cebc2  mov [r15+0x100], rax
000070a53a9cebc9  jz 0x000070A53A7FE0A0
000070a53a9cebcf  nop [rax+rax*1], eax
000070a53a9cebd4  mov eax, 0x410068
000070a53a9cebd9  mov [r15+0x100], rax
000070a53a9cebe0  jmp 0x000070A53A7FE110
000070a53a9cebe5  cmp dword ptr [r15+0x318], 0x00
000070a53a9cebed  jz 0x000070A53A9CE9C0
000070a53a9cebf3  nop [rax+rax*1], ax
000070a53a9cebfc  nop [rax+rax*1], eax
000070a53a9cec04  mov eax, 0x41006C
000070a53a9cec09  mov [r15+0x100], rax
000070a53a9cec10  jmp 0x000070A53A7FE110
000070a53a9cec15  int3
000070a53a9cec16  ucomisd xmm14, xmm13
000070a53a9cec1b  jp 0x000070A53A9CEC2A
000070a53a9cec1d  movaps xmm12, [0x000070A53A5FE070]
000070a53a9cec25  jmp 0x000070A53A9CEA98
000070a53a9cec2a  vxorps xmm0, xmm14, xmm13
000070a53a9cec2f  pextrw eax, xmm0, 0x03
000070a53a9cec34  and eax, 0x7FF8
000070a53a9cec39  cmp eax, 0x08
000070a53a9cec3c  jnz 0x000070A53A9CEA98
000070a53a9cec42  movq rax, xmm13
000070a53a9cec47  shl rax, 0x0D
000070a53a9cec4b  jbe 0x000070A53A9CEA98
000070a53a9cec51  vorps xmm12, xmm13, [0x000070A53A5FE080]
000070a53a9cec59  jmp 0x000070A53A9CEA98
000070a53a9cec5e  ucomisd xmm13, xmm11
000070a53a9cec63  jp 0x000070A53A9CEC72
000070a53a9cec65  movaps xmm10, [0x000070A53A5FE070]
000070a53a9cec6d  jmp 0x000070A53A9CEADA
000070a53a9cec72  vxorps xmm0, xmm13, xmm11
000070a53a9cec77  pextrw eax, xmm0, 0x03
000070a53a9cec7c  and eax, 0x7FF8
000070a53a9cec81  cmp eax, 0x08
000070a53a9cec84  jnz 0x000070A53A9CEADA
000070a53a9cec8a  movq rax, xmm11
000070a53a9cec8f  shl rax, 0x0D
000070a53a9cec93  jbe 0x000070A53A9CEADA
000070a53a9cec99  vorps xmm10, xmm11, [0x000070A53A5FE080]
000070a53a9ceca1  jmp 0x000070A53A9CEADA
000070a53a9ceca6  mov r14, 0x7FFFFFFFFFFFFFFF
000070a53a9cecb0  jmp 0x000070A53A9CEB15
000070a53a9cecb5  vmovaps xmm0, [0x000070A53A5FE080]
000070a53a9cecbd  ucomisd xmm14, xmm13
000070a53a9cecc2  jp 0x000070A53A9CECEF
000070a53a9cecc4  ucomisd xmm15, xmm15
000070a53a9cecc9  jnp 0x000070A53A9CECE2
000070a53a9ceccb  ptest xmm15, xmm0
000070a53a9cecd1  jz 0x000070A53A9CED02
000070a53a9cecd3  vmulsd xmm0, xmm14, xmm13
000070a53a9cecd8  ucomisd xmm0, xmm0
000070a53a9cecdc  jnp 0x000070A53A9CEB69
000070a53a9cece2  vmovaps xmm12, [0x000070A53A5FE070]
000070a53a9cecea  jmp 0x000070A53A9CEB69
000070a53a9cecef  ucomisd xmm15, xmm15
000070a53a9cecf4  jnp 0x000070A53A9CED0B
000070a53a9cecf6  movaps xmm12, xmm15
000070a53a9cecfa  ptest xmm15, xmm0
000070a53a9ced00  jnz 0x000070A53A9CED0B
000070a53a9ced02  vorps xmm12, xmm15, xmm0
000070a53a9ced06  jmp 0x000070A53A9CEB69
000070a53a9ced0b  ucomisd xmm14, xmm14
000070a53a9ced10  jnp 0x000070A53A9CED23
000070a53a9ced12  ptest xmm14, xmm0
000070a53a9ced18  jnz 0x000070A53A9CED23
000070a53a9ced1a  vorps xmm12, xmm14, xmm0
000070a53a9ced1e  jmp 0x000070A53A9CEB69
000070a53a9ced23  ucomisd xmm13, xmm13
000070a53a9ced28  jnp 0x000070A53A9CED3B
000070a53a9ced2a  ptest xmm13, xmm0
000070a53a9ced30  jnz 0x000070A53A9CED3B
000070a53a9ced32  vorps xmm12, xmm13, xmm0
000070a53a9ced36  jmp 0x000070A53A9CEB69
000070a53a9ced3b  jmp 0x000070A53A9CEB69
000070a53a9ced40  int3
000070a53a9ced41  nop [rax+rax*1], ax
000070a53a9ced4a  nop [rax+rax*1], ax
000070a53a9ced50  mov rax, [r15+0x20]
000070a53a9ced54  mov r14, [r15]
000070a53a9ced57  mov [r13+rax*1], r14
000070a53a9ced5c  mov rax, [r15+0xF0]
000070a53a9ced63  mov [r15+0x100], rax
000070a53a9ced6a  jmp 0x000070A53A9CE5C0
000070a53a9ced6f  int3
000070a53a9ced70  call 0x000070A53A80E120
000070a53a9ced75  jmp 0x000070A53A9CED5C
000070a53a9ced7a  int3
000070a53a9ced7b  nop [rax+rax*1], eax
000070a53a9ced80  mov qword ptr [r15+0x100], 0x04
000070a53a9ced8b  mov esi, 0x00
000070a53a9ced90  mov edx, 0x09
000070a53a9ced95  mov rdi, 0x7FFD56ABD230
000070a53a9ced9f  mov rax, 0x6090C3741970
000070a53a9ceda9  call rax
000070a53a9cedab  cmp dword ptr [r15+0x318], 0x00
000070a53a9cedb3  jnz 0x000070A53A7FE110
000070a53a9cedb9  jmp 0x000070A53A7FE0A0
000070a53a9cedbe  int3
000070a53a9cedbf  int3
