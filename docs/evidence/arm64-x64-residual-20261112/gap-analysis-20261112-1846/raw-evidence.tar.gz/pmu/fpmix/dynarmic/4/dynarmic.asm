000079d9bafce69b  nop [rax+rax*1], eax
000079d9bafce6a0  mov qword ptr [r15+0x08], 0xF4240
000079d9bafce6a8  mov qword ptr [r15+0x20], 0x420080
000079d9bafce6b0  vmovaps xmm1, [0x000079D9BABFE010]
000079d9bafce6b8  movq xmm1, xmm1
000079d9bafce6bc  movaps [r15+0x120], xmm1
000079d9bafce6c4  vmovaps xmm15, [0x000079D9BABFE020]
000079d9bafce6cc  movq xmm15, xmm15
000079d9bafce6d1  movaps [r15+0x130], xmm15
000079d9bafce6d9  vmovaps xmm14, [0x000079D9BABFE030]
000079d9bafce6e1  movq xmm14, xmm14
000079d9bafce6e6  movaps [r15+0x140], xmm14
000079d9bafce6ee  movq rax, xmm15
000079d9bafce6f3  movq r14, xmm14
000079d9bafce6f8  vmovq xmm13, rax
000079d9bafce6fd  vmovq xmm12, r14
000079d9bafce702  movaps xmm11, xmm13
000079d9bafce706  divsd xmm11, xmm12
000079d9bafce70b  ucomisd xmm11, xmm11
000079d9bafce710  jp 0x000079D9BAFCE88B
000079d9bafce716  movq xmm11, xmm11
000079d9bafce71b  xor eax, eax
000079d9bafce71d  cvtsi2sd xmm13, rax
000079d9bafce722  movq xmm13, xmm13
000079d9bafce727  movq rax, xmm13
000079d9bafce72c  movq r14, xmm1
000079d9bafce731  vmovq xmm13, rax
000079d9bafce736  vmovq xmm12, r14
000079d9bafce73b  movaps xmm10, xmm13
000079d9bafce73f  addsd xmm10, xmm12
000079d9bafce744  ucomisd xmm10, xmm10
000079d9bafce749  jp 0x000079D9BAFCE8D3
000079d9bafce74f  movq xmm10, xmm10
000079d9bafce754  movaps [r15+0x160], xmm10
000079d9bafce75c  movq rax, xmm10
000079d9bafce761  vmovq xmm13, rax
000079d9bafce766  vfixupimmsd xmm13, xmm13, [0x000079D9BABFE040], 0x00
000079d9bafce771  movsd xmm12, qword ptr [0x000079D9BABFE050]
000079d9bafce77a  comisd xmm12, xmm13
000079d9bafce77f  jbe 0x000079D9BAFCE91B
000079d9bafce785  cvttsd2si r14, xmm13
000079d9bafce78a  mov [r15], r14
000079d9bafce78d  movq rax, xmm11
000079d9bafce792  vmovq xmm13, rax
000079d9bafce797  andps xmm13, [0x000079D9BABFE060]
000079d9bafce79f  movq xmm13, xmm13
000079d9bafce7a4  movaps [r15+0x150], xmm13
000079d9bafce7ac  movq rax, xmm13
000079d9bafce7b1  movq r14, xmm1
000079d9bafce7b6  movq r12, xmm14
000079d9bafce7bb  vmovq xmm1, rax
000079d9bafce7c0  vmovq xmm14, r14
000079d9bafce7c5  vmovq xmm13, r12
000079d9bafce7ca  movaps xmm12, xmm1
000079d9bafce7ce  vfmadd231sd xmm12, xmm14, xmm13
000079d9bafce7d3  ucomisd xmm12, xmm12
000079d9bafce7d8  jp 0x000079D9BAFCE92A
000079d9bafce7de  movq xmm12, xmm12
000079d9bafce7e3  movaps [r15+0x170], xmm12
000079d9bafce7eb  movq rax, xmm12
000079d9bafce7f0  movq r14, xmm15
000079d9bafce7f5  vmovq xmm1, rax
000079d9bafce7fa  vmovq xmm15, r14
000079d9bafce7ff  ucomisd xmm1, xmm15
000079d9bafce804  mov rax, 0x101410080000100
000079d9bafce80e  setz cl
000079d9bafce811  rcl cl, 0x05
000079d9bafce814  shr rax, cl
000079d9bafce817  mov [r15+0x108], eax
000079d9bafce81e  mov eax, [r15+0x108]
000079d9bafce825  cmp al, 0x81
000079d9bafce827  sahf
000079d9bafce828  jnle 0x000079D9BAFCE85A
000079d9bafce82a  cmp dword ptr [r15+0x318], 0x00
000079d9bafce832  mov eax, 0x410068
000079d9bafce837  mov [r15+0x100], rax
000079d9bafce83e  jz 0x000079D9BADFE0A0
000079d9bafce844  nop [rax+rax*1], eax
000079d9bafce849  mov eax, 0x410068
000079d9bafce84e  mov [r15+0x100], rax
000079d9bafce855  jmp 0x000079D9BADFE110
000079d9bafce85a  cmp dword ptr [r15+0x318], 0x00
000079d9bafce862  jz 0x000079D9BAFCE9C0
000079d9bafce868  nop [rax+rax*1], ax
000079d9bafce871  nop [rax+rax*1], eax
000079d9bafce879  mov eax, 0x41006C
000079d9bafce87e  mov [r15+0x100], rax
000079d9bafce885  jmp 0x000079D9BADFE110
000079d9bafce88a  int3
000079d9bafce88b  ucomisd xmm13, xmm12
000079d9bafce890  jp 0x000079D9BAFCE89F
000079d9bafce892  movaps xmm11, [0x000079D9BABFE070]
000079d9bafce89a  jmp 0x000079D9BAFCE716
000079d9bafce89f  vxorps xmm0, xmm13, xmm12
000079d9bafce8a4  pextrw eax, xmm0, 0x03
000079d9bafce8a9  and eax, 0x7FF8
000079d9bafce8ae  cmp eax, 0x08
000079d9bafce8b1  jnz 0x000079D9BAFCE716
000079d9bafce8b7  movq rax, xmm12
000079d9bafce8bc  shl rax, 0x0D
000079d9bafce8c0  jbe 0x000079D9BAFCE716
000079d9bafce8c6  vorps xmm11, xmm12, [0x000079D9BABFE080]
000079d9bafce8ce  jmp 0x000079D9BAFCE716
000079d9bafce8d3  ucomisd xmm13, xmm12
000079d9bafce8d8  jp 0x000079D9BAFCE8E7
000079d9bafce8da  movaps xmm10, [0x000079D9BABFE070]
000079d9bafce8e2  jmp 0x000079D9BAFCE74F
000079d9bafce8e7  vxorps xmm0, xmm13, xmm12
000079d9bafce8ec  pextrw eax, xmm0, 0x03
000079d9bafce8f1  and eax, 0x7FF8
000079d9bafce8f6  cmp eax, 0x08
000079d9bafce8f9  jnz 0x000079D9BAFCE74F
000079d9bafce8ff  movq rax, xmm12
000079d9bafce904  shl rax, 0x0D
000079d9bafce908  jbe 0x000079D9BAFCE74F
000079d9bafce90e  vorps xmm10, xmm12, [0x000079D9BABFE080]
000079d9bafce916  jmp 0x000079D9BAFCE74F
000079d9bafce91b  mov r14, 0x7FFFFFFFFFFFFFFF
000079d9bafce925  jmp 0x000079D9BAFCE78A
000079d9bafce92a  vmovaps xmm0, [0x000079D9BABFE080]
000079d9bafce932  ucomisd xmm14, xmm13
000079d9bafce937  jp 0x000079D9BAFCE962
000079d9bafce939  ucomisd xmm1, xmm1
000079d9bafce93d  jnp 0x000079D9BAFCE955
000079d9bafce93f  ptest xmm1, xmm0
000079d9bafce944  jz 0x000079D9BAFCE973
000079d9bafce946  vmulsd xmm0, xmm14, xmm13
000079d9bafce94b  ucomisd xmm0, xmm0
000079d9bafce94f  jnp 0x000079D9BAFCE7DE
000079d9bafce955  vmovaps xmm12, [0x000079D9BABFE070]
000079d9bafce95d  jmp 0x000079D9BAFCE7DE
000079d9bafce962  ucomisd xmm1, xmm1
000079d9bafce966  jnp 0x000079D9BAFCE97C
000079d9bafce968  movaps xmm12, xmm1
000079d9bafce96c  ptest xmm1, xmm0
000079d9bafce971  jnz 0x000079D9BAFCE97C
000079d9bafce973  vorps xmm12, xmm1, xmm0
000079d9bafce977  jmp 0x000079D9BAFCE7DE
000079d9bafce97c  ucomisd xmm14, xmm14
000079d9bafce981  jnp 0x000079D9BAFCE994
000079d9bafce983  ptest xmm14, xmm0
000079d9bafce989  jnz 0x000079D9BAFCE994
000079d9bafce98b  vorps xmm12, xmm14, xmm0
000079d9bafce98f  jmp 0x000079D9BAFCE7DE
000079d9bafce994  ucomisd xmm13, xmm13
000079d9bafce999  jnp 0x000079D9BAFCE9AC
000079d9bafce99b  ptest xmm13, xmm0
000079d9bafce9a1  jnz 0x000079D9BAFCE9AC
000079d9bafce9a3  vorps xmm12, xmm13, xmm0
000079d9bafce9a7  jmp 0x000079D9BAFCE7DE
000079d9bafce9ac  jmp 0x000079D9BAFCE7DE
000079d9bafce9b1  int3
000079d9bafce9b2  nop [rax+rax*1], ax
000079d9bafce9bb  nop [rax+rax*1], eax
000079d9bafce9c0  mov rax, [r15+0x08]
000079d9bafce9c4  mov [rsp+0x10], rax
000079d9bafce9c9  xor eax, eax
000079d9bafce9cb  mov r14, [rsp+0x10]
000079d9bafce9d0  mov r12d, 0x01
000079d9bafce9d6  sub r14, r12
000079d9bafce9d9  cmc
000079d9bafce9da  lahf
000079d9bafce9db  seto al
000079d9bafce9de  mov [r15+0x108], eax
000079d9bafce9e5  mov [r15+0x08], r14
000079d9bafce9e9  mov eax, [r15+0x108]
000079d9bafce9f0  sahf
000079d9bafce9f1  jnz 0x000079D9BAFCEA23
000079d9bafce9f3  cmp dword ptr [r15+0x318], 0x00
000079d9bafce9fb  jz 0x000079D9BAFCED50
000079d9bafcea01  nop [rax+rax*1], ax
000079d9bafcea0a  nop [rax+rax*1], eax
000079d9bafcea12  mov eax, 0x410074
000079d9bafcea17  mov [r15+0x100], rax
000079d9bafcea1e  jmp 0x000079D9BADFE110
000079d9bafcea23  cmp dword ptr [r15+0x318], 0x00
000079d9bafcea2b  jz 0x000079D9BAFCEA60
000079d9bafcea31  nop [rax+rax*1], ax
000079d9bafcea3a  nop [rax+rax*1], eax
000079d9bafcea42  mov eax, 0x410048
000079d9bafcea47  mov [r15+0x100], rax
000079d9bafcea4e  jmp 0x000079D9BADFE110
000079d9bafcea53  int3
000079d9bafcea54  int3
000079d9bafcea55  nop [rax+rax*1], ax
000079d9bafcea5e  nop
000079d9bafcea60  movaps xmm1, [r15+0x130]
000079d9bafcea68  movq rax, xmm1
000079d9bafcea6d  movaps xmm15, [r15+0x140]
000079d9bafcea75  movq r14, xmm15
000079d9bafcea7a  vmovq xmm14, rax
000079d9bafcea7f  vmovq xmm13, r14
000079d9bafcea84  movaps xmm12, xmm14
000079d9bafcea88  divsd xmm12, xmm13
000079d9bafcea8d  ucomisd xmm12, xmm12
000079d9bafcea92  jp 0x000079D9BAFCEC16
000079d9bafcea98  movq xmm12, xmm12
000079d9bafcea9d  mov rax, [r15]
000079d9bafceaa0  cvtsi2sd xmm14, rax
000079d9bafceaa5  movq xmm14, xmm14
000079d9bafceaaa  movq rax, xmm14
000079d9bafceaaf  movaps xmm14, [r15+0x120]
000079d9bafceab7  movq r14, xmm14
000079d9bafceabc  vmovq xmm13, rax
000079d9bafceac1  vmovq xmm11, r14
000079d9bafceac6  movaps xmm10, xmm13
000079d9bafceaca  addsd xmm10, xmm11
000079d9bafceacf  ucomisd xmm10, xmm10
000079d9bafcead4  jp 0x000079D9BAFCEC5E
000079d9bafceada  movq xmm10, xmm10
000079d9bafceadf  movaps [r15+0x160], xmm10
000079d9bafceae7  movq rax, xmm10
000079d9bafceaec  vmovq xmm13, rax
000079d9bafceaf1  vfixupimmsd xmm13, xmm13, [0x000079D9BABFE040], 0x00
000079d9bafceafc  movsd xmm11, qword ptr [0x000079D9BABFE050]
000079d9bafceb05  comisd xmm11, xmm13
000079d9bafceb0a  jbe 0x000079D9BAFCECA6
000079d9bafceb10  cvttsd2si r14, xmm13
000079d9bafceb15  mov [r15], r14
000079d9bafceb18  movq rax, xmm12
000079d9bafceb1d  vmovq xmm13, rax
000079d9bafceb22  andps xmm13, [0x000079D9BABFE060]
000079d9bafceb2a  movq xmm13, xmm13
000079d9bafceb2f  movaps [r15+0x150], xmm13
000079d9bafceb37  movq rax, xmm13
000079d9bafceb3c  movq r14, xmm14
000079d9bafceb41  movq r12, xmm15
000079d9bafceb46  vmovq xmm15, rax
000079d9bafceb4b  vmovq xmm14, r14
000079d9bafceb50  vmovq xmm13, r12
000079d9bafceb55  movaps xmm12, xmm15
000079d9bafceb59  vfmadd231sd xmm12, xmm14, xmm13
000079d9bafceb5e  ucomisd xmm12, xmm12
000079d9bafceb63  jp 0x000079D9BAFCECB5
000079d9bafceb69  movq xmm12, xmm12
000079d9bafceb6e  movaps [r15+0x170], xmm12
000079d9bafceb76  movq rax, xmm12
000079d9bafceb7b  movq r14, xmm1
000079d9bafceb80  vmovq xmm1, rax
000079d9bafceb85  vmovq xmm15, r14
000079d9bafceb8a  ucomisd xmm1, xmm15
000079d9bafceb8f  mov rax, 0x101410080000100
000079d9bafceb99  setz cl
000079d9bafceb9c  rcl cl, 0x05
000079d9bafceb9f  shr rax, cl
000079d9bafceba2  mov [r15+0x108], eax
000079d9bafceba9  mov eax, [r15+0x108]
000079d9bafcebb0  cmp al, 0x81
000079d9bafcebb2  sahf
000079d9bafcebb3  jnle 0x000079D9BAFCEBE5
000079d9bafcebb5  cmp dword ptr [r15+0x318], 0x00
000079d9bafcebbd  mov eax, 0x410068
000079d9bafcebc2  mov [r15+0x100], rax
000079d9bafcebc9  jz 0x000079D9BADFE0A0
000079d9bafcebcf  nop [rax+rax*1], eax
000079d9bafcebd4  mov eax, 0x410068
000079d9bafcebd9  mov [r15+0x100], rax
000079d9bafcebe0  jmp 0x000079D9BADFE110
000079d9bafcebe5  cmp dword ptr [r15+0x318], 0x00
000079d9bafcebed  jz 0x000079D9BAFCE9C0
000079d9bafcebf3  nop [rax+rax*1], ax
000079d9bafcebfc  nop [rax+rax*1], eax
000079d9bafcec04  mov eax, 0x41006C
000079d9bafcec09  mov [r15+0x100], rax
000079d9bafcec10  jmp 0x000079D9BADFE110
000079d9bafcec15  int3
000079d9bafcec16  ucomisd xmm14, xmm13
000079d9bafcec1b  jp 0x000079D9BAFCEC2A
000079d9bafcec1d  movaps xmm12, [0x000079D9BABFE070]
000079d9bafcec25  jmp 0x000079D9BAFCEA98
000079d9bafcec2a  vxorps xmm0, xmm14, xmm13
000079d9bafcec2f  pextrw eax, xmm0, 0x03
000079d9bafcec34  and eax, 0x7FF8
000079d9bafcec39  cmp eax, 0x08
000079d9bafcec3c  jnz 0x000079D9BAFCEA98
000079d9bafcec42  movq rax, xmm13
000079d9bafcec47  shl rax, 0x0D
000079d9bafcec4b  jbe 0x000079D9BAFCEA98
000079d9bafcec51  vorps xmm12, xmm13, [0x000079D9BABFE080]
000079d9bafcec59  jmp 0x000079D9BAFCEA98
000079d9bafcec5e  ucomisd xmm13, xmm11
000079d9bafcec63  jp 0x000079D9BAFCEC72
000079d9bafcec65  movaps xmm10, [0x000079D9BABFE070]
000079d9bafcec6d  jmp 0x000079D9BAFCEADA
000079d9bafcec72  vxorps xmm0, xmm13, xmm11
000079d9bafcec77  pextrw eax, xmm0, 0x03
000079d9bafcec7c  and eax, 0x7FF8
000079d9bafcec81  cmp eax, 0x08
000079d9bafcec84  jnz 0x000079D9BAFCEADA
000079d9bafcec8a  movq rax, xmm11
000079d9bafcec8f  shl rax, 0x0D
000079d9bafcec93  jbe 0x000079D9BAFCEADA
000079d9bafcec99  vorps xmm10, xmm11, [0x000079D9BABFE080]
000079d9bafceca1  jmp 0x000079D9BAFCEADA
000079d9bafceca6  mov r14, 0x7FFFFFFFFFFFFFFF
000079d9bafcecb0  jmp 0x000079D9BAFCEB15
000079d9bafcecb5  vmovaps xmm0, [0x000079D9BABFE080]
000079d9bafcecbd  ucomisd xmm14, xmm13
000079d9bafcecc2  jp 0x000079D9BAFCECEF
000079d9bafcecc4  ucomisd xmm15, xmm15
000079d9bafcecc9  jnp 0x000079D9BAFCECE2
000079d9bafceccb  ptest xmm15, xmm0
000079d9bafcecd1  jz 0x000079D9BAFCED02
000079d9bafcecd3  vmulsd xmm0, xmm14, xmm13
000079d9bafcecd8  ucomisd xmm0, xmm0
000079d9bafcecdc  jnp 0x000079D9BAFCEB69
000079d9bafcece2  vmovaps xmm12, [0x000079D9BABFE070]
000079d9bafcecea  jmp 0x000079D9BAFCEB69
000079d9bafcecef  ucomisd xmm15, xmm15
000079d9bafcecf4  jnp 0x000079D9BAFCED0B
000079d9bafcecf6  movaps xmm12, xmm15
000079d9bafcecfa  ptest xmm15, xmm0
000079d9bafced00  jnz 0x000079D9BAFCED0B
000079d9bafced02  vorps xmm12, xmm15, xmm0
000079d9bafced06  jmp 0x000079D9BAFCEB69
000079d9bafced0b  ucomisd xmm14, xmm14
000079d9bafced10  jnp 0x000079D9BAFCED23
000079d9bafced12  ptest xmm14, xmm0
000079d9bafced18  jnz 0x000079D9BAFCED23
000079d9bafced1a  vorps xmm12, xmm14, xmm0
000079d9bafced1e  jmp 0x000079D9BAFCEB69
000079d9bafced23  ucomisd xmm13, xmm13
000079d9bafced28  jnp 0x000079D9BAFCED3B
000079d9bafced2a  ptest xmm13, xmm0
000079d9bafced30  jnz 0x000079D9BAFCED3B
000079d9bafced32  vorps xmm12, xmm13, xmm0
000079d9bafced36  jmp 0x000079D9BAFCEB69
000079d9bafced3b  jmp 0x000079D9BAFCEB69
000079d9bafced40  int3
000079d9bafced41  nop [rax+rax*1], ax
000079d9bafced4a  nop [rax+rax*1], ax
000079d9bafced50  mov rax, [r15+0x20]
000079d9bafced54  mov r14, [r15]
000079d9bafced57  mov [r13+rax*1], r14
000079d9bafced5c  mov rax, [r15+0xF0]
000079d9bafced63  mov [r15+0x100], rax
000079d9bafced6a  jmp 0x000079D9BAFCE5C0
000079d9bafced6f  int3
000079d9bafced70  call 0x000079D9BAE0E120
000079d9bafced75  jmp 0x000079D9BAFCED5C
000079d9bafced7a  int3
000079d9bafced7b  nop [rax+rax*1], eax
000079d9bafced80  mov qword ptr [r15+0x100], 0x04
000079d9bafced8b  mov esi, 0x00
000079d9bafced90  mov edx, 0x09
000079d9bafced95  mov rdi, 0x7FFE6E884A30
000079d9bafced9f  mov rax, 0x610AEB8AF970
000079d9bafceda9  call rax
000079d9bafcedab  cmp dword ptr [r15+0x318], 0x00
000079d9bafcedb3  jnz 0x000079D9BADFE110
000079d9bafcedb9  jmp 0x000079D9BADFE0A0
000079d9bafcedbe  int3
000079d9bafcedbf  int3
