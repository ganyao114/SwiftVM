00007942783ce69b  nop [rax+rax*1], eax
00007942783ce6a0  vmovaps xmm1, [0x0000794277FFE010]
00007942783ce6a8  movq xmm1, xmm1
00007942783ce6ac  movaps [r15+0x110], xmm1
00007942783ce6b4  vmovaps xmm1, [0x0000794277FFE020]
00007942783ce6bc  movq xmm1, xmm1
00007942783ce6c0  movaps [r15+0x120], xmm1
00007942783ce6c8  mov eax, 0x4204C0
00007942783ce6cd  mov r14, [r13+rax*1]
00007942783ce6d2  movq xmm1, r14
00007942783ce6d7  movaps [r15+0x130], xmm1
00007942783ce6df  vmovaps xmm1, [0x0000794277FFE030]
00007942783ce6e7  vpbroadcastq xmm1, xmm1
00007942783ce6ec  movaps [r15+0x140], xmm1
00007942783ce6f4  mov qword ptr [r15+0x40], 0x02
00007942783ce6fc  vmovaps xmm15, [0x0000794277FFE040]
00007942783ce704  movq xmm15, xmm15
00007942783ce709  movaps [r15+0x150], xmm15
00007942783ce711  mov qword ptr [r15+0x58], 0x420000
00007942783ce719  vmovaps xmm15, [0x0000794277FFE050]
00007942783ce721  vpbroadcastq xmm15, xmm15
00007942783ce726  movaps [r15+0x160], xmm15
00007942783ce72e  mov rax, [r15+0x40]
00007942783ce732  vmovq xmm14, rax
00007942783ce737  vpbroadcastq xmm14, xmm14
00007942783ce73c  movaps [r15+0x170], xmm14
00007942783ce744  mov eax, 0x4204D0
00007942783ce749  movups xmm13, [r13+rax*1]
00007942783ce74f  mov qword ptr [r15+0x40], 0x430518
00007942783ce757  mov qword ptr [r15+0x50], 0x430720
00007942783ce75f  vpmovqd xmm12, xmm13
00007942783ce765  pxor xmm11, xmm11
00007942783ce76a  punpcklqdq xmm12, xmm11
00007942783ce76f  movaps [r15+0x210], xmm12
00007942783ce777  movq xmm12, qword ptr [r15+0x120]
00007942783ce780  movq xmm11, qword ptr [r15+0x130]
00007942783ce789  psubd xmm12, xmm11
00007942783ce78e  movq xmm12, xmm12
00007942783ce793  paddq xmm13, xmm14
00007942783ce798  movaps [r15+0x180], xmm13
00007942783ce7a0  movq xmm14, qword ptr [r15+0x150]
00007942783ce7a9  paddd xmm11, xmm14
00007942783ce7ae  movq xmm11, xmm11
00007942783ce7b3  movq xmm11, xmm11
00007942783ce7b8  movaps [r15+0x130], xmm11
00007942783ce7c0  pmovzxdq xmm12, xmm12
00007942783ce7c6  psllq xmm12, 0x00
00007942783ce7cc  movq xmm14, qword ptr [r15+0x210]
00007942783ce7d5  movq xmm13, qword ptr [r15+0x110]
00007942783ce7de  paddd xmm14, xmm13
00007942783ce7e3  movq xmm14, xmm14
00007942783ce7e8  vcvtuqq2pd xmm12, xmm12
00007942783ce7ee  pmovzxdq xmm14, xmm14
00007942783ce7f4  psllq xmm14, 0x00
00007942783ce7fa  vcvtuqq2pd xmm14, xmm14
00007942783ce800  movaps xmm13, xmm12
00007942783ce804  mulpd xmm13, xmm1
00007942783ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007942783ce80f  ptest xmm11, xmm11
00007942783ce815  jnz 0x00007942783CE8FF
00007942783ce81b  movaps [r15+0x220], xmm13
00007942783ce823  mov eax, 0x430720
00007942783ce828  movups [r13+rax*1], xmm13
00007942783ce82e  movaps xmm1, xmm14
00007942783ce832  mulpd xmm1, xmm15
00007942783ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007942783ce83c  ptest xmm13, xmm13
00007942783ce842  jnz 0x00007942783CEA4C
00007942783ce848  movaps [r15+0x210], xmm1
00007942783ce850  mov eax, 0x430518
00007942783ce855  movups [r13+rax*1], xmm1
00007942783ce85b  mov qword ptr [r15+0x48], 0x10
00007942783ce863  xor eax, eax
00007942783ce865  mov r14d, 0x10
00007942783ce86b  mov r12d, 0x200
00007942783ce871  cmp r14, r12
00007942783ce874  cmc
00007942783ce875  lahf
00007942783ce876  seto al
00007942783ce879  mov [r15+0x108], eax
00007942783ce880  mov eax, [r15+0x108]
00007942783ce887  sahf
00007942783ce888  jnz 0x00007942783CE8BA
00007942783ce88a  cmp dword ptr [r15+0x318], 0x00
00007942783ce892  jz 0x00007942783CEFF0
00007942783ce898  nop [rax+rax*1], ax
00007942783ce8a1  nop [rax+rax*1], eax
00007942783ce8a9  mov eax, 0x4101EC
00007942783ce8ae  mov [r15+0x100], rax
00007942783ce8b5  jmp 0x00007942781FE110
00007942783ce8ba  cmp dword ptr [r15+0x318], 0x00
00007942783ce8c2  jz 0x00007942783CEBA0
00007942783ce8c8  nop [rax+rax*1], ax
00007942783ce8d1  nop [rax+rax*1], eax
00007942783ce8d9  mov eax, 0x4101AC
00007942783ce8de  mov [r15+0x100], rax
00007942783ce8e5  jmp 0x00007942781FE110
00007942783ce8ea  int3
00007942783ce8eb  call 0x000079427820DC20
00007942783ce8f0  jmp 0x00007942783CE6D2
00007942783ce8f5  call 0x000079427820C260
00007942783ce8fa  jmp 0x00007942783CE74F
00007942783ce8ff  sub rsp, 0x08
00007942783ce903  push rax
00007942783ce904  push rcx
00007942783ce905  push rdx
00007942783ce906  push rdi
00007942783ce907  push rsi
00007942783ce908  push r8
00007942783ce90a  push r9
00007942783ce90c  push r10
00007942783ce90e  push r11
00007942783ce910  sub rsp, 0xF0
00007942783ce917  vmovaps [rsp], xmm0
00007942783ce91c  vmovaps [rsp+0x10], xmm1
00007942783ce922  vmovaps [rsp+0x20], xmm2
00007942783ce928  vmovaps [rsp+0x30], xmm3
00007942783ce92e  vmovaps [rsp+0x40], xmm4
00007942783ce934  vmovaps [rsp+0x50], xmm5
00007942783ce93a  vmovaps [rsp+0x60], xmm6
00007942783ce940  vmovaps [rsp+0x70], xmm7
00007942783ce946  vmovaps [rsp+0x80], xmm8
00007942783ce94f  vmovaps [rsp+0x90], xmm9
00007942783ce958  vmovaps [rsp+0xA0], xmm10
00007942783ce961  vmovaps [rsp+0xB0], xmm11
00007942783ce96a  vmovaps [rsp+0xC0], xmm12
00007942783ce973  vmovaps [rsp+0xD0], xmm14
00007942783ce97c  vmovaps [rsp+0xE0], xmm15
00007942783ce985  sub rsp, 0x30
00007942783ce989  movaps [rsp], xmm13
00007942783ce98e  movaps [rsp+0x10], xmm12
00007942783ce994  movaps [rsp+0x20], xmm1
00007942783ce999  lea rdi, [rsp]
00007942783ce99d  mov esi, 0x00
00007942783ce9a2  mov rax, 0x59DDDCBA3530
00007942783ce9ac  call rax
00007942783ce9ae  movaps xmm13, [rsp]
00007942783ce9b3  add rsp, 0x30
00007942783ce9b7  vmovaps xmm0, [rsp]
00007942783ce9bc  vmovaps xmm1, [rsp+0x10]
00007942783ce9c2  vmovaps xmm2, [rsp+0x20]
00007942783ce9c8  vmovaps xmm3, [rsp+0x30]
00007942783ce9ce  vmovaps xmm4, [rsp+0x40]
00007942783ce9d4  vmovaps xmm5, [rsp+0x50]
00007942783ce9da  vmovaps xmm6, [rsp+0x60]
00007942783ce9e0  vmovaps xmm7, [rsp+0x70]
00007942783ce9e6  vmovaps xmm8, [rsp+0x80]
00007942783ce9ef  vmovaps xmm9, [rsp+0x90]
00007942783ce9f8  vmovaps xmm10, [rsp+0xA0]
00007942783cea01  vmovaps xmm11, [rsp+0xB0]
00007942783cea0a  vmovaps xmm12, [rsp+0xC0]
00007942783cea13  vmovaps xmm14, [rsp+0xD0]
00007942783cea1c  vmovaps xmm15, [rsp+0xE0]
00007942783cea25  add rsp, 0xF0
00007942783cea2c  pop r11
00007942783cea2e  pop r10
00007942783cea30  pop r9
00007942783cea32  pop r8
00007942783cea34  pop rsi
00007942783cea35  pop rdi
00007942783cea36  pop rdx
00007942783cea37  pop rcx
00007942783cea38  pop rax
00007942783cea39  add rsp, 0x08
00007942783cea3d  jmp 0x00007942783CE81B
00007942783cea42  call 0x000079427820C380
00007942783cea47  jmp 0x00007942783CE82E
00007942783cea4c  sub rsp, 0x08
00007942783cea50  push rax
00007942783cea51  push rcx
00007942783cea52  push rdx
00007942783cea53  push rdi
00007942783cea54  push rsi
00007942783cea55  push r8
00007942783cea57  push r9
00007942783cea59  push r10
00007942783cea5b  push r11
00007942783cea5d  sub rsp, 0xF0
00007942783cea64  vmovaps [rsp], xmm0
00007942783cea69  vmovaps [rsp+0x10], xmm2
00007942783cea6f  vmovaps [rsp+0x20], xmm3
00007942783cea75  vmovaps [rsp+0x30], xmm4
00007942783cea7b  vmovaps [rsp+0x40], xmm5
00007942783cea81  vmovaps [rsp+0x50], xmm6
00007942783cea87  vmovaps [rsp+0x60], xmm7
00007942783cea8d  vmovaps [rsp+0x70], xmm8
00007942783cea93  vmovaps [rsp+0x80], xmm9
00007942783cea9c  vmovaps [rsp+0x90], xmm10
00007942783ceaa5  vmovaps [rsp+0xA0], xmm11
00007942783ceaae  vmovaps [rsp+0xB0], xmm12
00007942783ceab7  vmovaps [rsp+0xC0], xmm13
00007942783ceac0  vmovaps [rsp+0xD0], xmm14
00007942783ceac9  vmovaps [rsp+0xE0], xmm15
00007942783cead2  sub rsp, 0x30
00007942783cead6  movaps [rsp], xmm1
00007942783ceada  movaps [rsp+0x10], xmm14
00007942783ceae0  movaps [rsp+0x20], xmm15
00007942783ceae6  lea rdi, [rsp]
00007942783ceaea  mov esi, 0x00
00007942783ceaef  mov rax, 0x59DDDCBA3530
00007942783ceaf9  call rax
00007942783ceafb  movaps xmm1, [rsp]
00007942783ceaff  add rsp, 0x30
00007942783ceb03  vmovaps xmm0, [rsp]
00007942783ceb08  vmovaps xmm2, [rsp+0x10]
00007942783ceb0e  vmovaps xmm3, [rsp+0x20]
00007942783ceb14  vmovaps xmm4, [rsp+0x30]
00007942783ceb1a  vmovaps xmm5, [rsp+0x40]
00007942783ceb20  vmovaps xmm6, [rsp+0x50]
00007942783ceb26  vmovaps xmm7, [rsp+0x60]
00007942783ceb2c  vmovaps xmm8, [rsp+0x70]
00007942783ceb32  vmovaps xmm9, [rsp+0x80]
00007942783ceb3b  vmovaps xmm10, [rsp+0x90]
00007942783ceb44  vmovaps xmm11, [rsp+0xA0]
00007942783ceb4d  vmovaps xmm12, [rsp+0xB0]
00007942783ceb56  vmovaps xmm13, [rsp+0xC0]
00007942783ceb5f  vmovaps xmm14, [rsp+0xD0]
00007942783ceb68  vmovaps xmm15, [rsp+0xE0]
00007942783ceb71  add rsp, 0xF0
00007942783ceb78  pop r11
00007942783ceb7a  pop r10
00007942783ceb7c  pop r9
00007942783ceb7e  pop r8
00007942783ceb80  pop rsi
00007942783ceb81  pop rdi
00007942783ceb82  pop rdx
00007942783ceb83  pop rcx
00007942783ceb84  pop rax
00007942783ceb85  add rsp, 0x08
00007942783ceb89  jmp 0x00007942783CE848
00007942783ceb8e  call 0x00007942781FF540
00007942783ceb93  jmp 0x00007942783CE85B
00007942783ceb98  int3
00007942783ceb99  nop [rax], eax
00007942783ceba0  movaps xmm1, [r15+0x180]
00007942783ceba8  vpmovqd xmm15, xmm1
00007942783cebae  pxor xmm14, xmm14
00007942783cebb3  punpcklqdq xmm15, xmm14
00007942783cebb8  movaps [r15+0x210], xmm15
00007942783cebc0  movq xmm15, qword ptr [r15+0x120]
00007942783cebc9  movq xmm14, qword ptr [r15+0x130]
00007942783cebd2  psubd xmm15, xmm14
00007942783cebd7  movq xmm15, xmm15
00007942783cebdc  movaps xmm13, [r15+0x170]
00007942783cebe4  paddq xmm1, xmm13
00007942783cebe9  movaps [r15+0x180], xmm1
00007942783cebf1  movq xmm1, qword ptr [r15+0x150]
00007942783cebfa  paddd xmm14, xmm1
00007942783cebff  movq xmm14, xmm14
00007942783cec04  movq xmm14, xmm14
00007942783cec09  movaps [r15+0x130], xmm14
00007942783cec11  pmovzxdq xmm15, xmm15
00007942783cec17  psllq xmm15, 0x00
00007942783cec1d  movq xmm1, qword ptr [r15+0x210]
00007942783cec26  movq xmm14, qword ptr [r15+0x110]
00007942783cec2f  paddd xmm1, xmm14
00007942783cec34  movq xmm1, xmm1
00007942783cec38  vcvtuqq2pd xmm15, xmm15
00007942783cec3e  pmovzxdq xmm1, xmm1
00007942783cec43  psllq xmm1, 0x00
00007942783cec48  vcvtuqq2pd xmm1, xmm1
00007942783cec4e  movaps xmm14, [r15+0x140]
00007942783cec56  movaps xmm13, xmm15
00007942783cec5a  mulpd xmm13, xmm14
00007942783cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007942783cec65  ptest xmm12, xmm12
00007942783cec6b  jnz 0x00007942783CED4E
00007942783cec71  movaps [r15+0x220], xmm13
00007942783cec79  mov rax, [r15+0x48]
00007942783cec7d  mov r14, [r15+0x50]
00007942783cec81  lea r12, [r14+rax*1]
00007942783cec85  movups [r13+r12*1], xmm13
00007942783cec8b  movaps xmm15, [r15+0x160]
00007942783cec93  movaps xmm14, xmm1
00007942783cec97  mulpd xmm14, xmm15
00007942783cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007942783ceca2  ptest xmm13, xmm13
00007942783ceca8  jnz 0x00007942783CEE9C
00007942783cecae  movaps [r15+0x210], xmm14
00007942783cecb6  mov r14, [r15+0x40]
00007942783cecba  lea r12, [r14+rax*1]
00007942783cecbe  movups [r13+r12*1], xmm14
00007942783cecc4  lea r14, [rax+0x10]
00007942783cecc8  mov [r15+0x48], r14
00007942783ceccc  xor eax, eax
00007942783cecce  mov r12d, 0x200
00007942783cecd4  cmp r14, r12
00007942783cecd7  cmc
00007942783cecd8  lahf
00007942783cecd9  seto al
00007942783cecdc  mov [r15+0x108], eax
00007942783cece3  mov eax, [r15+0x108]
00007942783cecea  sahf
00007942783ceceb  jnz 0x00007942783CED1D
00007942783ceced  cmp dword ptr [r15+0x318], 0x00
00007942783cecf5  jz 0x00007942783CEFF0
00007942783cecfb  nop [rax+rax*1], ax
00007942783ced04  nop [rax+rax*1], eax
00007942783ced0c  mov eax, 0x4101EC
00007942783ced11  mov [r15+0x100], rax
00007942783ced18  jmp 0x00007942781FE110
00007942783ced1d  cmp dword ptr [r15+0x318], 0x00
00007942783ced25  jz 0x00007942783CEBA0
00007942783ced2b  nop [rax+rax*1], ax
00007942783ced34  nop [rax+rax*1], eax
00007942783ced3c  mov eax, 0x4101AC
00007942783ced41  mov [r15+0x100], rax
00007942783ced48  jmp 0x00007942781FE110
00007942783ced4d  int3
00007942783ced4e  sub rsp, 0x08
00007942783ced52  push rax
00007942783ced53  push rcx
00007942783ced54  push rdx
00007942783ced55  push rdi
00007942783ced56  push rsi
00007942783ced57  push r8
00007942783ced59  push r9
00007942783ced5b  push r10
00007942783ced5d  push r11
00007942783ced5f  sub rsp, 0xF0
00007942783ced66  vmovaps [rsp], xmm0
00007942783ced6b  vmovaps [rsp+0x10], xmm1
00007942783ced71  vmovaps [rsp+0x20], xmm2
00007942783ced77  vmovaps [rsp+0x30], xmm3
00007942783ced7d  vmovaps [rsp+0x40], xmm4
00007942783ced83  vmovaps [rsp+0x50], xmm5
00007942783ced89  vmovaps [rsp+0x60], xmm6
00007942783ced8f  vmovaps [rsp+0x70], xmm7
00007942783ced95  vmovaps [rsp+0x80], xmm8
00007942783ced9e  vmovaps [rsp+0x90], xmm9
00007942783ceda7  vmovaps [rsp+0xA0], xmm10
00007942783cedb0  vmovaps [rsp+0xB0], xmm11
00007942783cedb9  vmovaps [rsp+0xC0], xmm12
00007942783cedc2  vmovaps [rsp+0xD0], xmm14
00007942783cedcb  vmovaps [rsp+0xE0], xmm15
00007942783cedd4  sub rsp, 0x30
00007942783cedd8  movaps [rsp], xmm13
00007942783ceddd  movaps [rsp+0x10], xmm15
00007942783cede3  movaps [rsp+0x20], xmm14
00007942783cede9  lea rdi, [rsp]
00007942783ceded  mov esi, 0x00
00007942783cedf2  mov rax, 0x59DDDCBA3530
00007942783cedfc  call rax
00007942783cedfe  movaps xmm13, [rsp]
00007942783cee03  add rsp, 0x30
00007942783cee07  vmovaps xmm0, [rsp]
00007942783cee0c  vmovaps xmm1, [rsp+0x10]
00007942783cee12  vmovaps xmm2, [rsp+0x20]
00007942783cee18  vmovaps xmm3, [rsp+0x30]
00007942783cee1e  vmovaps xmm4, [rsp+0x40]
00007942783cee24  vmovaps xmm5, [rsp+0x50]
00007942783cee2a  vmovaps xmm6, [rsp+0x60]
00007942783cee30  vmovaps xmm7, [rsp+0x70]
00007942783cee36  vmovaps xmm8, [rsp+0x80]
00007942783cee3f  vmovaps xmm9, [rsp+0x90]
00007942783cee48  vmovaps xmm10, [rsp+0xA0]
00007942783cee51  vmovaps xmm11, [rsp+0xB0]
00007942783cee5a  vmovaps xmm12, [rsp+0xC0]
00007942783cee63  vmovaps xmm14, [rsp+0xD0]
00007942783cee6c  vmovaps xmm15, [rsp+0xE0]
00007942783cee75  add rsp, 0xF0
00007942783cee7c  pop r11
00007942783cee7e  pop r10
00007942783cee80  pop r9
00007942783cee82  pop r8
00007942783cee84  pop rsi
00007942783cee85  pop rdi
00007942783cee86  pop rdx
00007942783cee87  pop rcx
00007942783cee88  pop rax
00007942783cee89  add rsp, 0x08
00007942783cee8d  jmp 0x00007942783CEC71
00007942783cee92  call 0x00007942782C2240
00007942783cee97  jmp 0x00007942783CEC8B
00007942783cee9c  sub rsp, 0x08
00007942783ceea0  push rax
00007942783ceea1  push rcx
00007942783ceea2  push rdx
00007942783ceea3  push rdi
00007942783ceea4  push rsi
00007942783ceea5  push r8
00007942783ceea7  push r9
00007942783ceea9  push r10
00007942783ceeab  push r11
00007942783ceead  sub rsp, 0xF0
00007942783ceeb4  vmovaps [rsp], xmm0
00007942783ceeb9  vmovaps [rsp+0x10], xmm1
00007942783ceebf  vmovaps [rsp+0x20], xmm2
00007942783ceec5  vmovaps [rsp+0x30], xmm3
00007942783ceecb  vmovaps [rsp+0x40], xmm4
00007942783ceed1  vmovaps [rsp+0x50], xmm5
00007942783ceed7  vmovaps [rsp+0x60], xmm6
00007942783ceedd  vmovaps [rsp+0x70], xmm7
00007942783ceee3  vmovaps [rsp+0x80], xmm8
00007942783ceeec  vmovaps [rsp+0x90], xmm9
00007942783ceef5  vmovaps [rsp+0xA0], xmm10
00007942783ceefe  vmovaps [rsp+0xB0], xmm11
00007942783cef07  vmovaps [rsp+0xC0], xmm12
00007942783cef10  vmovaps [rsp+0xD0], xmm13
00007942783cef19  vmovaps [rsp+0xE0], xmm15
00007942783cef22  sub rsp, 0x30
00007942783cef26  movaps [rsp], xmm14
00007942783cef2b  movaps [rsp+0x10], xmm1
00007942783cef30  movaps [rsp+0x20], xmm15
00007942783cef36  lea rdi, [rsp]
00007942783cef3a  mov esi, 0x00
00007942783cef3f  mov rax, 0x59DDDCBA3530
00007942783cef49  call rax
00007942783cef4b  movaps xmm14, [rsp]
00007942783cef50  add rsp, 0x30
00007942783cef54  vmovaps xmm0, [rsp]
00007942783cef59  vmovaps xmm1, [rsp+0x10]
00007942783cef5f  vmovaps xmm2, [rsp+0x20]
00007942783cef65  vmovaps xmm3, [rsp+0x30]
00007942783cef6b  vmovaps xmm4, [rsp+0x40]
00007942783cef71  vmovaps xmm5, [rsp+0x50]
00007942783cef77  vmovaps xmm6, [rsp+0x60]
00007942783cef7d  vmovaps xmm7, [rsp+0x70]
00007942783cef83  vmovaps xmm8, [rsp+0x80]
00007942783cef8c  vmovaps xmm9, [rsp+0x90]
00007942783cef95  vmovaps xmm10, [rsp+0xA0]
00007942783cef9e  vmovaps xmm11, [rsp+0xB0]
00007942783cefa7  vmovaps xmm12, [rsp+0xC0]
00007942783cefb0  vmovaps xmm13, [rsp+0xD0]
00007942783cefb9  vmovaps xmm15, [rsp+0xE0]
00007942783cefc2  add rsp, 0xF0
00007942783cefc9  pop r11
00007942783cefcb  pop r10
00007942783cefcd  pop r9
00007942783cefcf  pop r8
00007942783cefd1  pop rsi
00007942783cefd2  pop rdi
00007942783cefd3  pop rdx
00007942783cefd4  pop rcx
00007942783cefd5  pop rax
00007942783cefd6  add rsp, 0x08
00007942783cefda  jmp 0x00007942783CECAE
00007942783cefdf  call 0x00007942782C34C0
00007942783cefe4  jmp 0x00007942783CECC4
00007942783cefe9  int3
00007942783cefea  nop [rax+rax*1], ax
00007942783ceff0  mov rax, [r15+0xF8]
00007942783ceff7  lea r14, [rax-0x150]
00007942783ceffe  mov [r15+0xF8], r14
00007942783cf005  mov rax, [r15+0x50]
00007942783cf009  lea r12, [rax+0x80]
00007942783cf010  movups xmm1, [r13+r12*1]
00007942783cf016  lea r12, [rax+0x90]
00007942783cf01d  movups xmm15, [r13+r12*1]
00007942783cf023  mov qword ptr [r15+0x48], 0x00
00007942783cf02b  lea r12, [rax+0x40]
00007942783cf02f  movups xmm14, [r13+r12*1]
00007942783cf035  lea r12, [rax+0x50]
00007942783cf039  movups xmm13, [r13+r12*1]
00007942783cf03f  lea r12, [r14+0x120]
00007942783cf046  movq xmm12, qword ptr [r15+0x1C0]
00007942783cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007942783cf058  movq r11, xmm12
00007942783cf05d  movq r10, xmm11
00007942783cf062  mov [r13+r12*1], r11
00007942783cf067  lea r12, [r14+0x128]
00007942783cf06e  mov [r13+r12*1], r10
00007942783cf073  vxorps xmm12, xmm12, xmm12
00007942783cf078  vpbroadcastq xmm12, xmm12
00007942783cf07d  lea r12, [r14+0x100]
00007942783cf084  movq xmm11, qword ptr [r15+0x200]
00007942783cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007942783cf096  movq r11, xmm11
00007942783cf09b  movq r10, xmm10
00007942783cf0a0  mov [r13+r12*1], r11
00007942783cf0a5  lea r12, [r14+0x108]
00007942783cf0ac  mov [r13+r12*1], r10
00007942783cf0b1  lea r12, [r14+0xE0]
00007942783cf0b8  movups [r13+r12*1], xmm15
00007942783cf0be  lea r12, [r14+0xF0]
00007942783cf0c5  movups [r13+r12*1], xmm1
00007942783cf0cb  lea r12, [rax+0xC0]
00007942783cf0d2  movups xmm1, [r13+r12*1]
00007942783cf0d8  lea r12, [rax+0xD0]
00007942783cf0df  movups xmm15, [r13+r12*1]
00007942783cf0e5  lea r12, [r14+0x110]
00007942783cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007942783cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007942783cf0fe  movq r11, xmm11
00007942783cf103  movq r10, xmm10
00007942783cf108  mov [r13+r12*1], r11
00007942783cf10d  lea r12, [r14+0x118]
00007942783cf114  mov [r13+r12*1], r10
00007942783cf119  movups xmm11, [r13+rax*1]
00007942783cf11f  lea r12, [rax+0x10]
00007942783cf123  movups xmm10, [r13+r12*1]
00007942783cf129  lea r12, [r14+0x130]
00007942783cf130  movq xmm9, qword ptr [r15+0x1A0]
00007942783cf139  movq xmm8, qword ptr [r15+0x190]
00007942783cf142  movq r11, xmm9
00007942783cf147  movq r10, xmm8
00007942783cf14c  mov [r13+r12*1], r11
00007942783cf151  lea r12, [r14+0x138]
00007942783cf158  mov [r13+r12*1], r10
00007942783cf15d  lea r12, [rax+0x140]
00007942783cf164  movups xmm9, [r13+r12*1]
00007942783cf16a  lea r12, [rax+0x150]
00007942783cf171  movups xmm8, [r13+r12*1]
00007942783cf177  lea r12, [r14+0xC0]
00007942783cf17e  movups [r13+r12*1], xmm15
00007942783cf184  lea r12, [r14+0xD0]
00007942783cf18b  movups [r13+r12*1], xmm1
00007942783cf191  lea r12, [rax+0x100]
00007942783cf198  movups xmm1, [r13+r12*1]
00007942783cf19e  lea r12, [rax+0x110]
00007942783cf1a5  movups xmm15, [r13+r12*1]
00007942783cf1ab  lea r12, [r14+0x140]
00007942783cf1b2  mov r11, [r15+0xE8]
00007942783cf1b9  mov [r13+r12*1], r11
00007942783cf1be  lea r12, [rax+0x180]
00007942783cf1c5  movups xmm7, [r13+r12*1]
00007942783cf1cb  lea r12, [rax+0x190]
00007942783cf1d2  movups xmm6, [r13+r12*1]
00007942783cf1d8  lea r12, [rax+0x1C0]
00007942783cf1df  movups xmm5, [r13+r12*1]
00007942783cf1e5  lea r12, [rax+0x1D0]
00007942783cf1ec  movups xmm4, [r13+r12*1]
00007942783cf1f2  lea r12, [r14+0x20]
00007942783cf1f6  movups [r13+r12*1], xmm1
00007942783cf1fc  lea r12, [r14+0x30]
00007942783cf200  movups [r13+r12*1], xmm13
00007942783cf206  lea r12, [rax+0x60]
00007942783cf20a  movups xmm1, [r13+r12*1]
00007942783cf210  lea r12, [rax+0x70]
00007942783cf214  movups xmm13, [r13+r12*1]
00007942783cf21a  lea r12, [rax+0x20]
00007942783cf21e  movups xmm3, [r13+r12*1]
00007942783cf224  lea r12, [rax+0x30]
00007942783cf228  movups xmm2, [r13+r12*1]
00007942783cf22e  movaps [r15+0x1F0], xmm2
00007942783cf236  lea r12, [r14+0x60]
00007942783cf23a  movups [r13+r12*1], xmm11
00007942783cf240  lea r12, [r14+0x70]
00007942783cf244  movups [r13+r12*1], xmm5
00007942783cf24a  lea r12, [rax+0xE0]
00007942783cf251  movups xmm11, [r13+r12*1]
00007942783cf257  lea r12, [rax+0xF0]
00007942783cf25e  movups xmm5, [r13+r12*1]
00007942783cf264  lea r12, [r14+0xA0]
00007942783cf26b  movups [r13+r12*1], xmm13
00007942783cf271  lea r12, [r14+0xB0]
00007942783cf278  movups [r13+r12*1], xmm1
00007942783cf27e  lea r12, [rax+0xA0]
00007942783cf285  movups xmm1, [r13+r12*1]
00007942783cf28b  lea r12, [rax+0xB0]
00007942783cf292  movups xmm13, [r13+r12*1]
00007942783cf298  lea r12, [rax+0x120]
00007942783cf29f  vmovaps [rsp+0x10], xmm1
00007942783cf2a5  movups xmm1, [r13+r12*1]
00007942783cf2ab  lea r12, [rax+0x130]
00007942783cf2b2  vmovaps [rsp+0x20], xmm1
00007942783cf2b8  movups xmm1, [r13+r12*1]
00007942783cf2be  lea r12, [rax+0x160]
00007942783cf2c5  vmovaps [rsp+0x30], xmm1
00007942783cf2cb  movups xmm1, [r13+r12*1]
00007942783cf2d1  lea r12, [rax+0x170]
00007942783cf2d8  vmovaps [rsp+0x40], xmm1
00007942783cf2de  movups xmm1, [r13+r12*1]
00007942783cf2e4  movaps [r15+0x2B0], xmm1
00007942783cf2ec  lea r12, [r14+0x80]
00007942783cf2f3  movups [r13+r12*1], xmm13
00007942783cf2f9  lea r12, [r14+0x90]
00007942783cf300  vmovaps xmm13, [rsp+0x10]
00007942783cf306  movups [r13+r12*1], xmm13
00007942783cf30c  lea r12, [rax+0x1A0]
00007942783cf313  movups xmm13, [r13+r12*1]
00007942783cf319  lea r12, [rax+0x1B0]
00007942783cf320  vmovaps [rsp+0x10], xmm1
00007942783cf326  movups xmm1, [r13+r12*1]
00007942783cf32c  movaps [r15+0x290], xmm13
00007942783cf334  movaps [r15+0x1E0], xmm1
00007942783cf33c  lea r12, [rax+0x1E0]
00007942783cf343  vmovaps [rsp+0x50], xmm1
00007942783cf349  movups xmm1, [r13+r12*1]
00007942783cf34f  lea r12, [rax+0x1F0]
00007942783cf356  vmovaps [rsp+0x60], xmm1
00007942783cf35c  movups xmm1, [r13+r12*1]
00007942783cf362  mov qword ptr [r15+0x50], 0x430920
00007942783cf36a  lea rax, [r14+0x40]
00007942783cf36e  vmovaps [rsp+0x70], xmm1
00007942783cf374  vmovaps xmm1, [rsp+0x40]
00007942783cf37a  movups [r13+rax*1], xmm1
00007942783cf380  lea rax, [r14+0x50]
00007942783cf384  movups [r13+rax*1], xmm10
00007942783cf38a  vmovaps xmm1, [rsp+0x70]
00007942783cf390  movups [r13+r14*1], xmm1
00007942783cf396  lea rax, [r14+0x10]
00007942783cf39a  vmovaps xmm1, [rsp+0x60]
00007942783cf3a0  movups [r13+rax*1], xmm1
00007942783cf3a6  mov rax, [r15+0x40]
00007942783cf3aa  vmovaps [rsp+0x40], xmm3
00007942783cf3b0  vmovaps xmm1, [rsp+0x40]
00007942783cf3b6  por xmm3, xmm1
00007942783cf3ba  vmovaps [rsp+0x40], xmm6
00007942783cf3c0  vmovaps xmm10, [rsp+0x40]
00007942783cf3c6  por xmm6, xmm10
00007942783cf3cb  lea r12, [rax+0x30]
00007942783cf3cf  mov r11, [r13+r12*1]
00007942783cf3d4  lea r12, [rax+0x38]
00007942783cf3d8  mov r10, [r13+r12*1]
00007942783cf3dd  movq xmm10, r11
00007942783cf3e2  vmovaps [rsp+0x40], xmm1
00007942783cf3e8  movq xmm1, r10
00007942783cf3ed  movq xmm10, xmm10
00007942783cf3f2  vmovaps [rsp+0x60], xmm10
00007942783cf3f8  movq xmm10, xmm10
00007942783cf3fd  movaps [r15+0x130], xmm10
00007942783cf405  movq xmm1, xmm1
00007942783cf409  vmovaps [rsp+0x70], xmm1
00007942783cf40f  movq xmm1, xmm1
00007942783cf413  movaps [r15+0x280], xmm1
00007942783cf41b  vmovaps [rsp+0x80], xmm9
00007942783cf424  vmovaps xmm1, [rsp+0x80]
00007942783cf42d  por xmm9, xmm1
00007942783cf432  lea r12, [rax+0x20]
00007942783cf436  mov r11, [r13+r12*1]
00007942783cf43b  lea r12, [rax+0x28]
00007942783cf43f  mov r10, [r13+r12*1]
00007942783cf444  movq xmm1, r11
00007942783cf449  movq xmm10, r10
00007942783cf44e  movq xmm1, xmm1
00007942783cf452  vmovaps [rsp+0x80], xmm1
00007942783cf45b  movq xmm1, xmm1
00007942783cf45f  movaps [r15+0x150], xmm1
00007942783cf467  movq xmm10, xmm10
00007942783cf46c  vmovaps [rsp+0x90], xmm10
00007942783cf475  movq xmm10, xmm10
00007942783cf47a  movaps [r15+0x140], xmm10
00007942783cf482  lea r12, [rax+0x10]
00007942783cf486  mov r11, [r13+r12*1]
00007942783cf48b  lea r12, [rax+0x18]
00007942783cf48f  mov r10, [r13+r12*1]
00007942783cf494  movq xmm1, r11
00007942783cf499  movq xmm10, r10
00007942783cf49e  movq xmm1, xmm1
00007942783cf4a2  vmovaps [rsp+0xA0], xmm1
00007942783cf4ab  movq xmm1, xmm1
00007942783cf4af  movaps [r15+0x170], xmm1
00007942783cf4b7  movq xmm10, xmm10
00007942783cf4bc  vmovaps [rsp+0xB0], xmm10
00007942783cf4c5  movq xmm10, xmm10
00007942783cf4ca  movaps [r15+0x160], xmm10
00007942783cf4d2  mov r12, [r13+rax*1]
00007942783cf4d7  vmovq xmm1, r12
00007942783cf4dc  vpbroadcastq xmm1, xmm1
00007942783cf4e1  lea r12, [rax+0x08]
00007942783cf4e5  mov rax, [r13+r12*1]
00007942783cf4ea  movq xmm10, rax
00007942783cf4ef  movaps [r15+0x230], xmm10
00007942783cf4f7  lea rax, [r14+0x50]
00007942783cf4fb  movups xmm10, [r13+rax*1]
00007942783cf501  lea rax, [r14+0x60]
00007942783cf505  vmovaps [rsp+0xC0], xmm1
00007942783cf50e  movups xmm1, [r13+rax*1]
00007942783cf514  lea rax, [r14+0x30]
00007942783cf518  vmovaps [rsp+0xD0], xmm1
00007942783cf521  movups xmm1, [r13+rax*1]
00007942783cf527  mov qword ptr [r15+0x60], 0x430920
00007942783cf52f  mov qword ptr [r15+0x58], 0x40
00007942783cf537  vmovaps [rsp+0xE0], xmm1
00007942783cf540  vmovaps [rsp+0xF0], xmm15
00007942783cf549  vmovaps xmm15, [rsp+0xC0]
00007942783cf552  vmovaps [rsp+0xC0], xmm14
00007942783cf55b  vmovaps xmm14, [rsp+0x40]
00007942783cf561  vmovaps [rsp+0x40], xmm13
00007942783cf567  movaps xmm1, xmm15
00007942783cf56b  mulpd xmm1, xmm14
00007942783cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007942783cf575  ptest xmm13, xmm13
00007942783cf57b  jnz 0x00007942783D0682
00007942783cf581  movq xmm14, qword ptr [r15+0x230]
00007942783cf58a  vmovaps [rsp+0x100], xmm14
00007942783cf593  vpermilpd xmm14, xmm14, 0x00
00007942783cf599  vmovaps [rsp+0x110], xmm1
00007942783cf5a2  vmovaps xmm1, [rsp+0xE0]
00007942783cf5ab  vmovaps [rsp+0xE0], xmm15
00007942783cf5b4  movaps xmm13, xmm1
00007942783cf5b8  mulpd xmm13, xmm14
00007942783cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007942783cf5c3  ptest xmm15, xmm15
00007942783cf5c9  jnz 0x00007942783D07C4
00007942783cf5cf  vxorps xmm1, xmm1, xmm1
00007942783cf5d3  vpbroadcastq xmm1, xmm1
00007942783cf5d8  vmovaps xmm14, [rsp+0xE0]
00007942783cf5e1  vmovaps [rsp+0xE0], xmm1
00007942783cf5ea  vmovaps xmm1, [rsp+0xD0]
00007942783cf5f3  vmovaps [rsp+0xD0], xmm13
00007942783cf5fc  movaps xmm15, xmm14
00007942783cf600  mulpd xmm15, xmm1
00007942783cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007942783cf60b  ptest xmm13, xmm13
00007942783cf611  jnz 0x00007942783D0907
00007942783cf617  movaps xmm1, xmm14
00007942783cf61b  mulpd xmm1, xmm10
00007942783cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007942783cf625  ptest xmm13, xmm13
00007942783cf62b  jnz 0x00007942783D0A4A
00007942783cf631  movaps xmm13, xmm14
00007942783cf635  mulpd xmm13, xmm2
00007942783cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007942783cf640  ptest xmm10, xmm10
00007942783cf646  jnz 0x00007942783D0B8C
00007942783cf64c  vmovaps [rsp+0x120], xmm7
00007942783cf655  vmovaps xmm14, [rsp+0x120]
00007942783cf65e  por xmm7, xmm14
00007942783cf663  vmovaps xmm14, [rsp+0xC0]
00007942783cf66c  vmovaps xmm10, [rsp+0xC0]
00007942783cf675  por xmm14, xmm10
00007942783cf67a  vmovaps xmm2, [rsp+0x100]
00007942783cf683  vpermilpd xmm2, xmm2, 0x00
00007942783cf689  vmovaps [rsp+0xC0], xmm1
00007942783cf692  vmovaps [rsp+0x120], xmm15
00007942783cf69b  movaps xmm1, xmm10
00007942783cf69f  mulpd xmm1, xmm2
00007942783cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007942783cf6a8  ptest xmm15, xmm15
00007942783cf6ae  jnz 0x00007942783D0CCF
00007942783cf6b4  xor eax, eax
00007942783cf6b6  mov r12d, 0x40
00007942783cf6bc  mov r11d, 0x200
00007942783cf6c2  cmp r12, r11
00007942783cf6c5  cmc
00007942783cf6c6  lahf
00007942783cf6c7  seto al
00007942783cf6ca  mov [r15+0x108], eax
00007942783cf6d1  vmovaps xmm10, [rsp+0x110]
00007942783cf6da  vmovaps xmm2, [rsp+0xE0]
00007942783cf6e3  vmovaps [rsp+0xE0], xmm1
00007942783cf6ec  movaps xmm15, xmm10
00007942783cf6f0  addpd xmm15, xmm2
00007942783cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007942783cf6fb  ptest xmm1, xmm1
00007942783cf700  jnz 0x00007942783D0E10
00007942783cf706  vmovaps xmm10, [rsp+0x120]
00007942783cf70f  vmovaps [rsp+0x110], xmm15
00007942783cf718  movaps xmm1, xmm10
00007942783cf71c  addpd xmm1, xmm12
00007942783cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007942783cf726  ptest xmm15, xmm15
00007942783cf72c  jnz 0x00007942783D0F53
00007942783cf732  vmovaps xmm10, [rsp+0xC0]
00007942783cf73b  vmovaps [rsp+0xC0], xmm1
00007942783cf744  movaps xmm15, xmm10
00007942783cf748  addpd xmm15, xmm12
00007942783cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007942783cf753  ptest xmm1, xmm1
00007942783cf758  jnz 0x00007942783D1095
00007942783cf75e  vmovaps xmm1, [rsp+0x30]
00007942783cf764  vmovaps xmm12, [rsp+0x30]
00007942783cf76a  por xmm1, xmm12
00007942783cf76f  vmovaps xmm12, [rsp+0x20]
00007942783cf775  vmovaps xmm10, [rsp+0x20]
00007942783cf77b  por xmm12, xmm10
00007942783cf780  vmovaps [rsp+0x20], xmm5
00007942783cf786  vmovaps xmm10, [rsp+0x20]
00007942783cf78c  por xmm5, xmm10
00007942783cf791  vmovaps [rsp+0x20], xmm11
00007942783cf797  vmovaps xmm10, [rsp+0x20]
00007942783cf79d  por xmm11, xmm10
00007942783cf7a2  vmovaps [rsp+0x20], xmm4
00007942783cf7a8  vmovaps xmm10, [rsp+0x20]
00007942783cf7ae  por xmm4, xmm10
00007942783cf7b3  vmovaps [rsp+0x20], xmm8
00007942783cf7b9  vmovaps xmm10, [rsp+0x20]
00007942783cf7bf  por xmm8, xmm10
00007942783cf7c4  vmovaps xmm10, [rsp+0xF0]
00007942783cf7cd  vmovaps [rsp+0x20], xmm1
00007942783cf7d3  vmovaps xmm1, [rsp+0xF0]
00007942783cf7dc  por xmm10, xmm1
00007942783cf7e1  lea rax, [r14+0xA0]
00007942783cf7e8  movups xmm1, [r13+rax*1]
00007942783cf7ee  lea rax, [r14+0xB0]
00007942783cf7f5  vmovaps [rsp+0x30], xmm1
00007942783cf7fb  movups xmm1, [r13+rax*1]
00007942783cf801  vmovaps [rsp+0xF0], xmm1
00007942783cf80a  vmovaps [rsp+0x120], xmm15
00007942783cf813  movaps xmm1, xmm13
00007942783cf817  addpd xmm1, xmm2
00007942783cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007942783cf820  ptest xmm15, xmm15
00007942783cf826  jnz 0x00007942783D11ED
00007942783cf82c  lea rax, [r14+0xF0]
00007942783cf833  movups xmm15, [r13+rax*1]
00007942783cf839  vmovaps xmm2, [rsp+0xC0]
00007942783cf842  vmovaps [rsp+0xC0], xmm1
00007942783cf84b  vmovaps xmm1, [rsp+0xE0]
00007942783cf854  vmovaps [rsp+0xE0], xmm15
00007942783cf85d  movaps xmm13, xmm2
00007942783cf861  addpd xmm13, xmm1
00007942783cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007942783cf86c  ptest xmm15, xmm15
00007942783cf872  jnz 0x00007942783D1338
00007942783cf878  vmovaps xmm15, [rsp+0x120]
00007942783cf881  vmovaps xmm2, [rsp+0xD0]
00007942783cf88a  vmovaps [rsp+0xD0], xmm14
00007942783cf893  movaps xmm1, xmm15
00007942783cf897  addpd xmm1, xmm2
00007942783cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007942783cf8a0  ptest xmm14, xmm14
00007942783cf8a6  jnz 0x00007942783D147A
00007942783cf8ac  vmovaps xmm15, [rsp+0x100]
00007942783cf8b5  vpermilpd xmm15, xmm15, 0x00
00007942783cf8bb  vmovaps xmm2, [rsp+0xF0]
00007942783cf8c4  vmovaps [rsp+0xF0], xmm1
00007942783cf8cd  movaps xmm14, xmm2
00007942783cf8d1  mulpd xmm14, xmm15
00007942783cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007942783cf8dc  ptest xmm1, xmm1
00007942783cf8e1  jnz 0x00007942783D15BB
00007942783cf8e7  vmovaps xmm1, [rsp+0xA0]
00007942783cf8f0  vpermilpd xmm1, xmm1, 0x00
00007942783cf8f6  vmovaps xmm2, [rsp+0xE0]
00007942783cf8ff  vmovaps [rsp+0xE0], xmm14
00007942783cf908  movaps xmm15, xmm2
00007942783cf90c  mulpd xmm15, xmm1
00007942783cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007942783cf917  ptest xmm14, xmm14
00007942783cf91d  jnz 0x00007942783D16FE
00007942783cf923  lea rax, [r14+0xE0]
00007942783cf92a  movups xmm1, [r13+rax*1]
00007942783cf930  vmovaps xmm14, [rsp+0x100]
00007942783cf939  vpermilpd xmm14, xmm14, 0x00
00007942783cf93f  vmovaps [rsp+0x100], xmm1
00007942783cf948  vmovaps xmm1, [rsp+0x30]
00007942783cf94e  vmovaps [rsp+0x30], xmm15
00007942783cf954  movaps xmm2, xmm1
00007942783cf957  mulpd xmm2, xmm14
00007942783cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007942783cf961  ptest xmm15, xmm15
00007942783cf967  jnz 0x00007942783D184A
00007942783cf96d  vmovaps [rsp+0x120], xmm10
00007942783cf976  vmovaps xmm1, [rsp+0x120]
00007942783cf97f  por xmm10, xmm1
00007942783cf984  movaps [r15+0x300], xmm10
00007942783cf98c  vmovaps [rsp+0x120], xmm8
00007942783cf995  vmovaps xmm1, [rsp+0x120]
00007942783cf99e  por xmm8, xmm1
00007942783cf9a3  movaps [r15+0x190], xmm8
00007942783cf9ab  vmovaps xmm1, [rsp+0xA0]
00007942783cf9b4  vpermilpd xmm1, xmm1, 0x00
00007942783cf9ba  vmovaps xmm14, [rsp+0x100]
00007942783cf9c3  vmovaps [rsp+0x100], xmm13
00007942783cf9cc  movaps xmm15, xmm14
00007942783cf9d0  mulpd xmm15, xmm1
00007942783cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007942783cf9db  ptest xmm13, xmm13
00007942783cf9e1  jnz 0x00007942783D198B
00007942783cf9e7  lea rax, [r14+0x90]
00007942783cf9ee  movups xmm1, [r13+rax*1]
00007942783cf9f4  vmovaps [rsp+0x120], xmm4
00007942783cf9fd  vmovaps xmm14, [rsp+0x120]
00007942783cfa06  por xmm4, xmm14
00007942783cfa0b  movaps [r15+0x1C0], xmm4
00007942783cfa13  vmovaps [rsp+0x120], xmm11
00007942783cfa1c  vmovaps xmm14, [rsp+0x120]
00007942783cfa25  por xmm11, xmm14
00007942783cfa2a  movaps [r15+0x200], xmm11
00007942783cfa32  vmovaps [rsp+0x120], xmm5
00007942783cfa3b  vmovaps xmm14, [rsp+0x120]
00007942783cfa44  por xmm5, xmm14
00007942783cfa49  movaps [r15+0x2D0], xmm5
00007942783cfa51  vmovaps [rsp+0x120], xmm12
00007942783cfa5a  vmovaps xmm14, [rsp+0x120]
00007942783cfa63  por xmm12, xmm14
00007942783cfa68  movaps [r15+0x2E0], xmm12
00007942783cfa70  vmovaps xmm13, [rsp+0x110]
00007942783cfa79  vmovaps [rsp+0x110], xmm1
00007942783cfa82  vmovaps xmm1, [rsp+0xE0]
00007942783cfa8b  vmovaps [rsp+0xE0], xmm15
00007942783cfa94  movaps xmm14, xmm13
00007942783cfa98  addpd xmm14, xmm1
00007942783cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007942783cfaa3  ptest xmm15, xmm15
00007942783cfaa9  jnz 0x00007942783D1AD8
00007942783cfaaf  vmovaps xmm1, [rsp+0xA0]
00007942783cfab8  vpermilpd xmm1, xmm1, 0x00
00007942783cfabe  vmovaps xmm13, [rsp+0x110]
00007942783cfac7  vmovaps [rsp+0x110], xmm14
00007942783cfad0  movaps xmm15, xmm13
00007942783cfad4  mulpd xmm15, xmm1
00007942783cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007942783cfadf  ptest xmm14, xmm14
00007942783cfae5  jnz 0x00007942783D1C1B
00007942783cfaeb  lea rax, [r14+0x80]
00007942783cfaf2  movups xmm1, [r13+rax*1]
00007942783cfaf8  vmovaps xmm13, [rsp+0xC0]
00007942783cfb01  vmovaps [rsp+0xC0], xmm1
00007942783cfb0a  movaps xmm14, xmm13
00007942783cfb0e  addpd xmm14, xmm2
00007942783cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007942783cfb19  ptest xmm1, xmm1
00007942783cfb1e  jnz 0x00007942783D1D68
00007942783cfb24  vmovaps xmm13, [rsp+0x100]
00007942783cfb2d  vmovaps xmm2, [rsp+0x30]
00007942783cfb33  vmovaps [rsp+0x30], xmm15
00007942783cfb39  movaps xmm1, xmm13
00007942783cfb3d  addpd xmm1, xmm2
00007942783cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007942783cfb46  ptest xmm15, xmm15
00007942783cfb4c  jnz 0x00007942783D1EAB
00007942783cfb52  vmovaps xmm15, [rsp+0x20]
00007942783cfb58  vmovaps xmm13, [rsp+0x20]
00007942783cfb5e  por xmm15, xmm13
00007942783cfb63  movaps [r15+0x2F0], xmm15
00007942783cfb6b  vmovaps xmm13, [rsp+0xA0]
00007942783cfb74  vpermilpd xmm13, xmm13, 0x00
00007942783cfb7a  vmovaps [rsp+0x20], xmm1
00007942783cfb80  vmovaps xmm1, [rsp+0xC0]
00007942783cfb89  vmovaps [rsp+0xA0], xmm15
00007942783cfb92  movaps xmm2, xmm1
00007942783cfb95  mulpd xmm2, xmm13
00007942783cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007942783cfb9f  ptest xmm15, xmm15
00007942783cfba5  jnz 0x00007942783D1FEC
00007942783cfbab  lea rax, [r14+0xD0]
00007942783cfbb2  movups xmm1, [r13+rax*1]
00007942783cfbb8  vmovaps xmm13, [rsp+0xF0]
00007942783cfbc1  vmovaps [rsp+0xC0], xmm1
00007942783cfbca  vmovaps xmm1, [rsp+0xE0]
00007942783cfbd3  vmovaps [rsp+0xE0], xmm14
00007942783cfbdc  movaps xmm15, xmm13
00007942783cfbe0  addpd xmm15, xmm1
00007942783cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007942783cfbeb  ptest xmm14, xmm14
00007942783cfbf1  jnz 0x00007942783D2137
00007942783cfbf7  vmovaps xmm1, [rsp+0xB0]
00007942783cfc00  vpermilpd xmm1, xmm1, 0x00
00007942783cfc06  movaps xmm14, xmm11
00007942783cfc0a  mulpd xmm14, xmm1
00007942783cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007942783cfc15  ptest xmm13, xmm13
00007942783cfc1b  jnz 0x00007942783D227A
00007942783cfc21  movaps [r15+0x260], xmm14
00007942783cfc29  vxorps xmm1, xmm1, xmm1
00007942783cfc2d  vpbroadcastq xmm1, xmm1
00007942783cfc32  movaps [r15+0x1B0], xmm1
00007942783cfc3a  vmovaps xmm1, [rsp+0xB0]
00007942783cfc43  vpermilpd xmm1, xmm1, 0x00
00007942783cfc49  vmovaps xmm11, [rsp+0xC0]
00007942783cfc52  vmovaps [rsp+0xC0], xmm15
00007942783cfc5b  movaps xmm13, xmm11
00007942783cfc5f  mulpd xmm13, xmm1
00007942783cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007942783cfc6a  ptest xmm15, xmm15
00007942783cfc70  jnz 0x00007942783D23BD
00007942783cfc76  lea rax, [r14+0xC0]
00007942783cfc7d  movups xmm1, [r13+rax*1]
00007942783cfc83  vmovaps xmm11, [rsp+0x110]
00007942783cfc8c  vmovaps [rsp+0xF0], xmm1
00007942783cfc95  vmovaps xmm1, [rsp+0x30]
00007942783cfc9b  vmovaps [rsp+0x30], xmm14
00007942783cfca1  movaps xmm15, xmm11
00007942783cfca5  addpd xmm15, xmm1
00007942783cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007942783cfcb0  ptest xmm14, xmm14
00007942783cfcb6  jnz 0x00007942783D250A
00007942783cfcbc  vmovaps [rsp+0x100], xmm9
00007942783cfcc5  vmovaps xmm1, [rsp+0x100]
00007942783cfcce  por xmm9, xmm1
00007942783cfcd3  movaps [r15+0x270], xmm9
00007942783cfcdb  vmovaps [rsp+0x100], xmm6
00007942783cfce4  vmovaps xmm1, [rsp+0x100]
00007942783cfced  por xmm6, xmm1
00007942783cfcf1  movaps [r15+0x1A0], xmm6
00007942783cfcf9  vmovaps xmm14, [rsp+0xB0]
00007942783cfd02  vpermilpd xmm14, xmm14, 0x00
00007942783cfd08  vmovaps xmm6, [rsp+0xF0]
00007942783cfd11  vmovaps [rsp+0xF0], xmm1
00007942783cfd1a  movaps xmm11, xmm6
00007942783cfd1e  mulpd xmm11, xmm14
00007942783cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007942783cfd29  ptest xmm1, xmm1
00007942783cfd2e  jnz 0x00007942783D264D
00007942783cfd34  lea rax, [r14+0x20]
00007942783cfd38  movups xmm1, [r13+rax*1]
00007942783cfd3e  movaps [r15+0x110], xmm1
00007942783cfd46  vmovaps xmm6, [rsp+0xE0]
00007942783cfd4f  vmovaps [rsp+0xE0], xmm1
00007942783cfd58  movaps xmm14, xmm6
00007942783cfd5c  addpd xmm14, xmm2
00007942783cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007942783cfd67  ptest xmm1, xmm1
00007942783cfd6c  jnz 0x00007942783D279A
00007942783cfd72  vmovaps xmm1, [rsp+0xB0]
00007942783cfd7b  vpermilpd xmm1, xmm1, 0x00
00007942783cfd81  movaps xmm6, xmm5
00007942783cfd84  mulpd xmm6, xmm1
00007942783cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007942783cfd8d  ptest xmm2, xmm2
00007942783cfd92  jnz 0x00007942783D28DC
00007942783cfd98  vmovaps xmm5, [rsp+0x20]
00007942783cfd9e  movaps xmm1, xmm5
00007942783cfda1  addpd xmm1, xmm13
00007942783cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007942783cfdab  ptest xmm2, xmm2
00007942783cfdb0  jnz 0x00007942783D2A1C
00007942783cfdb6  vmovaps xmm13, [rsp+0x80]
00007942783cfdbf  vpermilpd xmm13, xmm13, 0x00
00007942783cfdc5  vmovaps xmm2, [rsp+0xE0]
00007942783cfdce  vmovaps [rsp+0x20], xmm1
00007942783cfdd4  movaps xmm5, xmm2
00007942783cfdd7  mulpd xmm5, xmm13
00007942783cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007942783cfde1  ptest xmm1, xmm1
00007942783cfde6  jnz 0x00007942783D2B5D
00007942783cfdec  vmovaps xmm1, [rsp+0x80]
00007942783cfdf5  vpermilpd xmm1, xmm1, 0x00
00007942783cfdfb  movaps xmm13, xmm10
00007942783cfdff  mulpd xmm13, xmm1
00007942783cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007942783cfe0a  ptest xmm2, xmm2
00007942783cfe0f  jnz 0x00007942783D2C9E
00007942783cfe15  vmovaps xmm10, [rsp+0x30]
00007942783cfe1b  movaps xmm1, xmm15
00007942783cfe1f  addpd xmm1, xmm10
00007942783cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007942783cfe29  ptest xmm2, xmm2
00007942783cfe2e  jnz 0x00007942783D2DE1
00007942783cfe34  vmovaps xmm10, [rsp+0xC0]
00007942783cfe3d  movaps xmm15, xmm10
00007942783cfe41  addpd xmm15, xmm11
00007942783cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007942783cfe4c  ptest xmm2, xmm2
00007942783cfe51  jnz 0x00007942783D2F23
00007942783cfe57  vmovaps xmm11, [rsp+0x80]
00007942783cfe60  vpermilpd xmm11, xmm11, 0x00
00007942783cfe66  movaps xmm10, xmm12
00007942783cfe6a  mulpd xmm10, xmm11
00007942783cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007942783cfe75  ptest xmm2, xmm2
00007942783cfe7a  jnz 0x00007942783D3067
00007942783cfe80  vmovaps xmm12, [rsp+0x80]
00007942783cfe89  vpermilpd xmm12, xmm12, 0x00
00007942783cfe8f  vmovaps xmm2, [rsp+0xA0]
00007942783cfe98  vmovaps [rsp+0x30], xmm1
00007942783cfe9e  movaps xmm11, xmm2
00007942783cfea2  mulpd xmm11, xmm12
00007942783cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007942783cfead  ptest xmm1, xmm1
00007942783cfeb2  jnz 0x00007942783D31AB
00007942783cfeb8  movaps xmm1, xmm14
00007942783cfebc  addpd xmm1, xmm6
00007942783cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007942783cfec5  ptest xmm12, xmm12
00007942783cfecb  jnz 0x00007942783D32EE
00007942783cfed1  vmovaps xmm12, [rsp+0x20]
00007942783cfed7  movaps xmm14, xmm12
00007942783cfedb  addpd xmm14, xmm5
00007942783cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007942783cfee6  ptest xmm6, xmm6
00007942783cfeeb  jnz 0x00007942783D342F
00007942783cfef1  vmovaps xmm12, [rsp+0x90]
00007942783cfefa  vpermilpd xmm12, xmm12, 0x00
00007942783cff00  movaps xmm6, xmm9
00007942783cff04  mulpd xmm6, xmm12
00007942783cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007942783cff0e  ptest xmm5, xmm5
00007942783cff13  jnz 0x00007942783D3572
00007942783cff19  movaps xmm12, xmm15
00007942783cff1d  addpd xmm12, xmm13
00007942783cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007942783cff28  ptest xmm9, xmm9
00007942783cff2e  jnz 0x00007942783D36B4
00007942783cff34  vmovaps xmm13, [rsp+0x30]
00007942783cff3a  movaps xmm15, xmm13
00007942783cff3e  addpd xmm15, xmm10
00007942783cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007942783cff49  ptest xmm9, xmm9
00007942783cff4f  jnz 0x00007942783D37F8
00007942783cff55  vmovaps xmm13, [rsp+0xD0]
00007942783cff5e  vmovaps xmm10, [rsp+0xD0]
00007942783cff67  por xmm13, xmm10
00007942783cff6c  movaps [r15+0x250], xmm13
00007942783cff74  vmovaps [rsp+0x20], xmm7
00007942783cff7a  vmovaps xmm13, [rsp+0x20]
00007942783cff80  por xmm7, xmm13
00007942783cff85  movaps [r15+0x2A0], xmm7
00007942783cff8d  vmovaps [rsp+0x20], xmm3
00007942783cff93  vmovaps xmm13, [rsp+0x20]
00007942783cff99  por xmm3, xmm13
00007942783cff9e  movaps [r15+0x1D0], xmm3
00007942783cffa6  lea rax, [r14+0x40]
00007942783cffaa  movups xmm13, [r13+rax*1]
00007942783cffb0  movaps [r15+0x2C0], xmm13
00007942783cffb8  vmovaps xmm10, [rsp+0x90]
00007942783cffc1  vpermilpd xmm10, xmm10, 0x00
00007942783cffc7  movaps xmm9, xmm8
00007942783cffcb  mulpd xmm9, xmm10
00007942783cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007942783cffd6  ptest xmm5, xmm5
00007942783cffdb  jnz 0x00007942783D3946
00007942783cffe1  movaps xmm10, xmm1
00007942783cffe5  addpd xmm10, xmm11
00007942783cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007942783cfff0  ptest xmm8, xmm8
00007942783cfff6  jnz 0x00007942783D3A8A
00007942783cfffc  movaps xmm1, xmm14
00007942783d0000  addpd xmm1, xmm6
00007942783d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007942783d0009  ptest xmm11, xmm11
00007942783d000f  jnz 0x00007942783D3BCD
00007942783d0015  vmovaps xmm14, [rsp+0x90]
00007942783d001e  vpermilpd xmm14, xmm14, 0x00
00007942783d0024  movaps xmm11, xmm13
00007942783d0028  mulpd xmm11, xmm14
00007942783d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007942783d0033  ptest xmm8, xmm8
00007942783d0039  jnz 0x00007942783D3D0E
00007942783d003f  vmovaps xmm14, [rsp+0x90]
00007942783d0048  vpermilpd xmm14, xmm14, 0x00
00007942783d004e  vmovaps xmm8, [rsp+0x10]
00007942783d0054  movaps xmm13, xmm8
00007942783d0058  mulpd xmm13, xmm14
00007942783d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007942783d0063  ptest xmm6, xmm6
00007942783d0068  jnz 0x00007942783D3E52
00007942783d006e  vmovaps xmm14, [rsp+0x60]
00007942783d0074  vpermilpd xmm14, xmm14, 0x00
00007942783d007a  movaps xmm8, xmm7
00007942783d007e  mulpd xmm8, xmm14
00007942783d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007942783d0089  ptest xmm6, xmm6
00007942783d008e  jnz 0x00007942783D3F96
00007942783d0094  movaps xmm14, xmm12
00007942783d0098  addpd xmm14, xmm9
00007942783d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007942783d00a3  ptest xmm7, xmm7
00007942783d00a8  jnz 0x00007942783D40D9
00007942783d00ae  vmovaps xmm12, [rsp+0x60]
00007942783d00b4  vpermilpd xmm12, xmm12, 0x00
00007942783d00ba  vmovaps xmm7, [rsp+0xF0]
00007942783d00c3  movaps xmm9, xmm7
00007942783d00c7  mulpd xmm9, xmm12
00007942783d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007942783d00d2  ptest xmm6, xmm6
00007942783d00d7  jnz 0x00007942783D421D
00007942783d00dd  movaps xmm12, xmm15
00007942783d00e1  addpd xmm12, xmm11
00007942783d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007942783d00ec  ptest xmm7, xmm7
00007942783d00f1  jnz 0x00007942783D4360
00007942783d00f7  vmovaps xmm15, [rsp+0x60]
00007942783d00fd  vpermilpd xmm15, xmm15, 0x00
00007942783d0103  vmovaps xmm7, [rsp+0x40]
00007942783d0109  movaps xmm11, xmm7
00007942783d010d  mulpd xmm11, xmm15
00007942783d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007942783d0118  ptest xmm6, xmm6
00007942783d011d  jnz 0x00007942783D44A4
00007942783d0123  movaps xmm15, xmm10
00007942783d0127  addpd xmm15, xmm13
00007942783d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007942783d0132  ptest xmm7, xmm7
00007942783d0137  jnz 0x00007942783D45E7
00007942783d013d  vmovaps xmm13, [rsp+0x60]
00007942783d0143  vpermilpd xmm13, xmm13, 0x00
00007942783d0149  vmovaps xmm7, [rsp+0x50]
00007942783d014f  movaps xmm10, xmm7
00007942783d0153  mulpd xmm10, xmm13
00007942783d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007942783d015e  ptest xmm6, xmm6
00007942783d0163  jnz 0x00007942783D472B
00007942783d0169  movaps xmm13, xmm1
00007942783d016d  addpd xmm13, xmm8
00007942783d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007942783d0178  ptest xmm7, xmm7
00007942783d017d  jnz 0x00007942783D486E
00007942783d0183  lea rax, [r14+0x70]
00007942783d0187  movups xmm1, [r13+rax*1]
00007942783d018d  movaps [r15+0x240], xmm1
00007942783d0195  movaps xmm8, xmm14
00007942783d0199  addpd xmm8, xmm9
00007942783d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007942783d01a4  ptest xmm7, xmm7
00007942783d01a9  jnz 0x00007942783D49BB
00007942783d01af  movaps [r15+0x170], xmm8
00007942783d01b7  vmovaps xmm14, [rsp+0x70]
00007942783d01bd  vpermilpd xmm14, xmm14, 0x00
00007942783d01c3  movaps xmm9, xmm1
00007942783d01c7  mulpd xmm9, xmm14
00007942783d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007942783d01d2  ptest xmm7, xmm7
00007942783d01d7  jnz 0x00007942783D4AFF
00007942783d01dd  vmovaps xmm1, [rsp+0x70]
00007942783d01e3  vpermilpd xmm1, xmm1, 0x00
00007942783d01e9  movaps xmm14, xmm4
00007942783d01ed  mulpd xmm14, xmm1
00007942783d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007942783d01f8  ptest xmm7, xmm7
00007942783d01fd  jnz 0x00007942783D4C42
00007942783d0203  movaps [r15+0x180], xmm14
00007942783d020b  movaps xmm1, xmm12
00007942783d020f  addpd xmm1, xmm11
00007942783d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007942783d0219  ptest xmm7, xmm7
00007942783d021e  jnz 0x00007942783D4D84
00007942783d0224  movaps [r15+0x210], xmm1
00007942783d022c  movups xmm12, [r13+r14*1]
00007942783d0232  lea rax, [r14+0x10]
00007942783d0236  movups xmm11, [r13+rax*1]
00007942783d023c  movaps [r15+0x230], xmm11
00007942783d0244  movaps xmm7, xmm15
00007942783d0248  addpd xmm7, xmm10
00007942783d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007942783d0252  ptest xmm6, xmm6
00007942783d0257  jnz 0x00007942783D4EDA
00007942783d025d  movaps [r15+0x130], xmm7
00007942783d0265  vmovaps xmm15, [rsp+0x70]
00007942783d026b  vpermilpd xmm15, xmm15, 0x00
00007942783d0271  movaps xmm10, xmm11
00007942783d0275  mulpd xmm10, xmm15
00007942783d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007942783d0280  ptest xmm6, xmm6
00007942783d0285  jnz 0x00007942783D501C
00007942783d028b  movaps [r15+0x220], xmm10
00007942783d0293  vmovaps xmm15, [rsp+0x70]
00007942783d0299  vpermilpd xmm15, xmm15, 0x00
00007942783d029f  movaps xmm11, xmm12
00007942783d02a3  mulpd xmm11, xmm15
00007942783d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007942783d02ae  ptest xmm6, xmm6
00007942783d02b3  jnz 0x00007942783D5160
00007942783d02b9  movaps xmm15, xmm13
00007942783d02bd  addpd xmm15, xmm9
00007942783d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007942783d02c8  ptest xmm12, xmm12
00007942783d02ce  jnz 0x00007942783D52A4
00007942783d02d4  movaps [r15+0x140], xmm15
00007942783d02dc  movaps xmm13, xmm8
00007942783d02e0  addpd xmm13, xmm14
00007942783d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007942783d02eb  ptest xmm12, xmm12
00007942783d02f1  jnz 0x00007942783D53E8
00007942783d02f7  movaps [r15+0x150], xmm13
00007942783d02ff  movaps xmm14, xmm1
00007942783d0303  addpd xmm14, xmm10
00007942783d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007942783d030e  ptest xmm12, xmm12
00007942783d0314  jnz 0x00007942783D552C
00007942783d031a  movaps [r15+0x160], xmm14
00007942783d0322  movaps xmm1, xmm7
00007942783d0325  addpd xmm1, xmm11
00007942783d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007942783d032f  ptest xmm12, xmm12
00007942783d0335  jnz 0x00007942783D566F
00007942783d033b  movaps [r15+0x120], xmm1
00007942783d0343  mov eax, 0x430920
00007942783d0348  movups [r13+rax*1], xmm15
00007942783d034e  mov eax, 0x430930
00007942783d0353  movups [r13+rax*1], xmm13
00007942783d0359  mov eax, 0x430940
00007942783d035e  movups [r13+rax*1], xmm14
00007942783d0364  mov eax, 0x430950
00007942783d0369  movups [r13+rax*1], xmm1
00007942783d036f  mov eax, [r15+0x108]
00007942783d0376  sahf
00007942783d0377  jnz 0x00007942783D03A9
00007942783d0379  cmp dword ptr [r15+0x318], 0x00
00007942783d0381  jz 0x00007942783DB900
00007942783d0387  nop [rax+rax*1], ax
00007942783d0390  nop [rax+rax*1], eax
00007942783d0398  mov eax, 0x410444
00007942783d039d  mov [r15+0x100], rax
00007942783d03a4  jmp 0x00007942781FE110
00007942783d03a9  cmp dword ptr [r15+0x318], 0x00
00007942783d03b1  jz 0x00007942783D57E0
00007942783d03b7  nop [rax+rax*1], ax
00007942783d03c0  nop [rax+rax*1], eax
00007942783d03c8  mov eax, 0x410278
00007942783d03cd  mov [r15+0x100], rax
00007942783d03d4  jmp 0x00007942781FE110
00007942783d03d9  int3
00007942783d03da  call 0x00007942782B52F0
00007942783d03df  jmp 0x00007942783CF016
00007942783d03e4  call 0x00007942782C4620
00007942783d03e9  jmp 0x00007942783CF023
00007942783d03ee  call 0x00007942782C33A0
00007942783d03f3  jmp 0x00007942783CF035
00007942783d03f8  call 0x00007942782C2120
00007942783d03fd  jmp 0x00007942783CF03F
00007942783d0402  call 0x00007942782C0860
00007942783d0407  jmp 0x00007942783CF067
00007942783d040c  call 0x00007942782BF5F0
00007942783d0411  jmp 0x00007942783CF073
00007942783d0416  call 0x00007942782C0860
00007942783d041b  jmp 0x00007942783CF0A5
00007942783d0420  call 0x00007942782BF5F0
00007942783d0425  jmp 0x00007942783CF0B1
00007942783d042a  call 0x00007942782C4740
00007942783d042f  jmp 0x00007942783CF0BE
00007942783d0434  call 0x00007942782B5400
00007942783d0439  jmp 0x00007942783CF0CB
00007942783d043e  call 0x00007942782B52F0
00007942783d0443  jmp 0x00007942783CF0D8
00007942783d0448  call 0x00007942782C4620
00007942783d044d  jmp 0x00007942783CF0E5
00007942783d0452  call 0x00007942782C0860
00007942783d0457  jmp 0x00007942783CF10D
00007942783d045c  call 0x00007942782BF5F0
00007942783d0461  jmp 0x00007942783CF119
00007942783d0466  call 0x0000794278209D70
00007942783d046b  jmp 0x00007942783CF11F
00007942783d0470  call 0x00007942782BE9C0
00007942783d0475  jmp 0x00007942783CF129
00007942783d047a  call 0x00007942782C0860
00007942783d047f  jmp 0x00007942783CF151
00007942783d0484  call 0x00007942782BF5F0
00007942783d0489  jmp 0x00007942783CF15D
00007942783d048e  call 0x00007942782BD750
00007942783d0493  jmp 0x00007942783CF16A
00007942783d0498  call 0x00007942782BC4E0
00007942783d049d  jmp 0x00007942783CF177
00007942783d04a2  call 0x00007942782C4740
00007942783d04a7  jmp 0x00007942783CF184
00007942783d04ac  call 0x00007942782B5400
00007942783d04b1  jmp 0x00007942783CF191
00007942783d04b6  call 0x00007942782B52F0
00007942783d04bb  jmp 0x00007942783CF19E
00007942783d04c0  call 0x00007942782C4620
00007942783d04c5  jmp 0x00007942783CF1AB
00007942783d04ca  call 0x00007942782C0860
00007942783d04cf  jmp 0x00007942783CF1BE
00007942783d04d4  call 0x00007942782BB270
00007942783d04d9  jmp 0x00007942783CF1CB
00007942783d04de  call 0x00007942782BA000
00007942783d04e3  jmp 0x00007942783CF1D8
00007942783d04e8  call 0x00007942782B8D90
00007942783d04ed  jmp 0x00007942783CF1E5
00007942783d04f2  call 0x00007942782B8A20
00007942783d04f7  jmp 0x00007942783CF1F2
00007942783d04fc  call 0x00007942782B5400
00007942783d0501  jmp 0x00007942783CF1FC
00007942783d0506  call 0x00007942782C2240
00007942783d050b  jmp 0x00007942783CF206
00007942783d0510  call 0x00007942782B52F0
00007942783d0515  jmp 0x00007942783CF210
00007942783d051a  call 0x00007942782C2120
00007942783d051f  jmp 0x00007942783CF21A
00007942783d0524  call 0x00007942782B77B0
00007942783d0529  jmp 0x00007942783CF224
00007942783d052e  call 0x00007942782B6550
00007942783d0533  jmp 0x00007942783CF22E
00007942783d0538  call 0x00007942782BFD50
00007942783d053d  jmp 0x00007942783CF240
00007942783d0542  call 0x00007942782B8EA0
00007942783d0547  jmp 0x00007942783CF24A
00007942783d054c  call 0x00007942782BFC30
00007942783d0551  jmp 0x00007942783CF257
00007942783d0556  call 0x00007942782B8D90
00007942783d055b  jmp 0x00007942783CF264
00007942783d0560  call 0x00007942782C2240
00007942783d0565  jmp 0x00007942783CF271
00007942783d056a  call 0x00007942782B5400
00007942783d056f  jmp 0x00007942783CF27E
00007942783d0574  call 0x00007942782B52F0
00007942783d0579  jmp 0x00007942783CF28B
00007942783d057e  call 0x00007942782C2120
00007942783d0583  jmp 0x00007942783CF298
00007942783d0588  call 0x00007942782B52F0
00007942783d058d  jmp 0x00007942783CF2AB
00007942783d0592  call 0x00007942782B52F0
00007942783d0597  jmp 0x00007942783CF2BE
00007942783d059c  call 0x00007942782B52F0
00007942783d05a1  jmp 0x00007942783CF2D1
00007942783d05a6  call 0x00007942782B52F0
00007942783d05ab  jmp 0x00007942783CF2E4
00007942783d05b0  call 0x00007942782C2240
00007942783d05b5  jmp 0x00007942783CF2F9
00007942783d05ba  call 0x00007942782C2240
00007942783d05bf  jmp 0x00007942783CF30C
00007942783d05c4  call 0x00007942782C2120
00007942783d05c9  jmp 0x00007942783CF319
00007942783d05ce  call 0x00007942782B52F0
00007942783d05d3  jmp 0x00007942783CF32C
00007942783d05d8  call 0x00007942782B52F0
00007942783d05dd  jmp 0x00007942783CF34F
00007942783d05e2  call 0x00007942782B52F0
00007942783d05e7  jmp 0x00007942783CF362
00007942783d05ec  call 0x00007942781FF540
00007942783d05f1  jmp 0x00007942783CF380
00007942783d05f6  call 0x0000794278208C20
00007942783d05fb  jmp 0x00007942783CF38A
00007942783d0600  call 0x00007942782D6600
00007942783d0605  jmp 0x00007942783CF396
00007942783d060a  call 0x00007942781FF540
00007942783d060f  jmp 0x00007942783CF3A6
00007942783d0614  call 0x00007942782C0370
00007942783d0619  jmp 0x00007942783CF3D4
00007942783d061e  call 0x00007942782BF100
00007942783d0623  jmp 0x00007942783CF3DD
00007942783d0628  call 0x00007942782C0370
00007942783d062d  jmp 0x00007942783CF43B
00007942783d0632  call 0x00007942782BF100
00007942783d0637  jmp 0x00007942783CF444
00007942783d063c  call 0x00007942782C0370
00007942783d0641  jmp 0x00007942783CF48B
00007942783d0646  call 0x00007942782BF100
00007942783d064b  jmp 0x00007942783CF494
00007942783d0650  call 0x000079427820B720
00007942783d0655  jmp 0x00007942783CF4D7
00007942783d065a  call 0x00007942782B47C0
00007942783d065f  jmp 0x00007942783CF4EA
00007942783d0664  call 0x0000794278208B00
00007942783d0669  jmp 0x00007942783CF501
00007942783d066e  call 0x00007942781FF430
00007942783d0673  jmp 0x00007942783CF514
00007942783d0678  call 0x00007942781FF430
00007942783d067d  jmp 0x00007942783CF527
00007942783d0682  sub rsp, 0x08
00007942783d0686  push rax
00007942783d0687  push rcx
00007942783d0688  push rdx
00007942783d0689  push rdi
00007942783d068a  push rsi
00007942783d068b  push r8
00007942783d068d  push r9
00007942783d068f  push r10
00007942783d0691  push r11
00007942783d0693  sub rsp, 0xF0
00007942783d069a  vmovaps [rsp], xmm0
00007942783d069f  vmovaps [rsp+0x10], xmm2
00007942783d06a5  vmovaps [rsp+0x20], xmm3
00007942783d06ab  vmovaps [rsp+0x30], xmm4
00007942783d06b1  vmovaps [rsp+0x40], xmm5
00007942783d06b7  vmovaps [rsp+0x50], xmm6
00007942783d06bd  vmovaps [rsp+0x60], xmm7
00007942783d06c3  vmovaps [rsp+0x70], xmm8
00007942783d06c9  vmovaps [rsp+0x80], xmm9
00007942783d06d2  vmovaps [rsp+0x90], xmm10
00007942783d06db  vmovaps [rsp+0xA0], xmm11
00007942783d06e4  vmovaps [rsp+0xB0], xmm12
00007942783d06ed  vmovaps [rsp+0xC0], xmm13
00007942783d06f6  vmovaps [rsp+0xD0], xmm14
00007942783d06ff  vmovaps [rsp+0xE0], xmm15
00007942783d0708  sub rsp, 0x30
00007942783d070c  movaps [rsp], xmm1
00007942783d0710  movaps [rsp+0x10], xmm15
00007942783d0716  movaps [rsp+0x20], xmm14
00007942783d071c  lea rdi, [rsp]
00007942783d0720  mov esi, 0x00
00007942783d0725  mov rax, 0x59DDDCBA3530
00007942783d072f  call rax
00007942783d0731  movaps xmm1, [rsp]
00007942783d0735  add rsp, 0x30
00007942783d0739  vmovaps xmm0, [rsp]
00007942783d073e  vmovaps xmm2, [rsp+0x10]
00007942783d0744  vmovaps xmm3, [rsp+0x20]
00007942783d074a  vmovaps xmm4, [rsp+0x30]
00007942783d0750  vmovaps xmm5, [rsp+0x40]
00007942783d0756  vmovaps xmm6, [rsp+0x50]
00007942783d075c  vmovaps xmm7, [rsp+0x60]
00007942783d0762  vmovaps xmm8, [rsp+0x70]
00007942783d0768  vmovaps xmm9, [rsp+0x80]
00007942783d0771  vmovaps xmm10, [rsp+0x90]
00007942783d077a  vmovaps xmm11, [rsp+0xA0]
00007942783d0783  vmovaps xmm12, [rsp+0xB0]
00007942783d078c  vmovaps xmm13, [rsp+0xC0]
00007942783d0795  vmovaps xmm14, [rsp+0xD0]
00007942783d079e  vmovaps xmm15, [rsp+0xE0]
00007942783d07a7  add rsp, 0xF0
00007942783d07ae  pop r11
00007942783d07b0  pop r10
00007942783d07b2  pop r9
00007942783d07b4  pop r8
00007942783d07b6  pop rsi
00007942783d07b7  pop rdi
00007942783d07b8  pop rdx
00007942783d07b9  pop rcx
00007942783d07ba  pop rax
00007942783d07bb  add rsp, 0x08
00007942783d07bf  jmp 0x00007942783CF581
00007942783d07c4  sub rsp, 0x08
00007942783d07c8  push rax
00007942783d07c9  push rcx
00007942783d07ca  push rdx
00007942783d07cb  push rdi
00007942783d07cc  push rsi
00007942783d07cd  push r8
00007942783d07cf  push r9
00007942783d07d1  push r10
00007942783d07d3  push r11
00007942783d07d5  sub rsp, 0xF0
00007942783d07dc  vmovaps [rsp], xmm0
00007942783d07e1  vmovaps [rsp+0x10], xmm1
00007942783d07e7  vmovaps [rsp+0x20], xmm2
00007942783d07ed  vmovaps [rsp+0x30], xmm3
00007942783d07f3  vmovaps [rsp+0x40], xmm4
00007942783d07f9  vmovaps [rsp+0x50], xmm5
00007942783d07ff  vmovaps [rsp+0x60], xmm6
00007942783d0805  vmovaps [rsp+0x70], xmm7
00007942783d080b  vmovaps [rsp+0x80], xmm8
00007942783d0814  vmovaps [rsp+0x90], xmm9
00007942783d081d  vmovaps [rsp+0xA0], xmm10
00007942783d0826  vmovaps [rsp+0xB0], xmm11
00007942783d082f  vmovaps [rsp+0xC0], xmm12
00007942783d0838  vmovaps [rsp+0xD0], xmm14
00007942783d0841  vmovaps [rsp+0xE0], xmm15
00007942783d084a  sub rsp, 0x30
00007942783d084e  movaps [rsp], xmm13
00007942783d0853  movaps [rsp+0x10], xmm1
00007942783d0858  movaps [rsp+0x20], xmm14
00007942783d085e  lea rdi, [rsp]
00007942783d0862  mov esi, 0x00
00007942783d0867  mov rax, 0x59DDDCBA3530
00007942783d0871  call rax
00007942783d0873  movaps xmm13, [rsp]
00007942783d0878  add rsp, 0x30
00007942783d087c  vmovaps xmm0, [rsp]
00007942783d0881  vmovaps xmm1, [rsp+0x10]
00007942783d0887  vmovaps xmm2, [rsp+0x20]
00007942783d088d  vmovaps xmm3, [rsp+0x30]
00007942783d0893  vmovaps xmm4, [rsp+0x40]
00007942783d0899  vmovaps xmm5, [rsp+0x50]
00007942783d089f  vmovaps xmm6, [rsp+0x60]
00007942783d08a5  vmovaps xmm7, [rsp+0x70]
00007942783d08ab  vmovaps xmm8, [rsp+0x80]
00007942783d08b4  vmovaps xmm9, [rsp+0x90]
00007942783d08bd  vmovaps xmm10, [rsp+0xA0]
00007942783d08c6  vmovaps xmm11, [rsp+0xB0]
00007942783d08cf  vmovaps xmm12, [rsp+0xC0]
00007942783d08d8  vmovaps xmm14, [rsp+0xD0]
00007942783d08e1  vmovaps xmm15, [rsp+0xE0]
00007942783d08ea  add rsp, 0xF0
00007942783d08f1  pop r11
00007942783d08f3  pop r10
00007942783d08f5  pop r9
00007942783d08f7  pop r8
00007942783d08f9  pop rsi
00007942783d08fa  pop rdi
00007942783d08fb  pop rdx
00007942783d08fc  pop rcx
00007942783d08fd  pop rax
00007942783d08fe  add rsp, 0x08
00007942783d0902  jmp 0x00007942783CF5CF
00007942783d0907  sub rsp, 0x08
00007942783d090b  push rax
00007942783d090c  push rcx
00007942783d090d  push rdx
00007942783d090e  push rdi
00007942783d090f  push rsi
00007942783d0910  push r8
00007942783d0912  push r9
00007942783d0914  push r10
00007942783d0916  push r11
00007942783d0918  sub rsp, 0xF0
00007942783d091f  vmovaps [rsp], xmm0
00007942783d0924  vmovaps [rsp+0x10], xmm1
00007942783d092a  vmovaps [rsp+0x20], xmm2
00007942783d0930  vmovaps [rsp+0x30], xmm3
00007942783d0936  vmovaps [rsp+0x40], xmm4
00007942783d093c  vmovaps [rsp+0x50], xmm5
00007942783d0942  vmovaps [rsp+0x60], xmm6
00007942783d0948  vmovaps [rsp+0x70], xmm7
00007942783d094e  vmovaps [rsp+0x80], xmm8
00007942783d0957  vmovaps [rsp+0x90], xmm9
00007942783d0960  vmovaps [rsp+0xA0], xmm10
00007942783d0969  vmovaps [rsp+0xB0], xmm11
00007942783d0972  vmovaps [rsp+0xC0], xmm12
00007942783d097b  vmovaps [rsp+0xD0], xmm13
00007942783d0984  vmovaps [rsp+0xE0], xmm14
00007942783d098d  sub rsp, 0x30
00007942783d0991  movaps [rsp], xmm15
00007942783d0996  movaps [rsp+0x10], xmm14
00007942783d099c  movaps [rsp+0x20], xmm1
00007942783d09a1  lea rdi, [rsp]
00007942783d09a5  mov esi, 0x00
00007942783d09aa  mov rax, 0x59DDDCBA3530
00007942783d09b4  call rax
00007942783d09b6  movaps xmm15, [rsp]
00007942783d09bb  add rsp, 0x30
00007942783d09bf  vmovaps xmm0, [rsp]
00007942783d09c4  vmovaps xmm1, [rsp+0x10]
00007942783d09ca  vmovaps xmm2, [rsp+0x20]
00007942783d09d0  vmovaps xmm3, [rsp+0x30]
00007942783d09d6  vmovaps xmm4, [rsp+0x40]
00007942783d09dc  vmovaps xmm5, [rsp+0x50]
00007942783d09e2  vmovaps xmm6, [rsp+0x60]
00007942783d09e8  vmovaps xmm7, [rsp+0x70]
00007942783d09ee  vmovaps xmm8, [rsp+0x80]
00007942783d09f7  vmovaps xmm9, [rsp+0x90]
00007942783d0a00  vmovaps xmm10, [rsp+0xA0]
00007942783d0a09  vmovaps xmm11, [rsp+0xB0]
00007942783d0a12  vmovaps xmm12, [rsp+0xC0]
00007942783d0a1b  vmovaps xmm13, [rsp+0xD0]
00007942783d0a24  vmovaps xmm14, [rsp+0xE0]
00007942783d0a2d  add rsp, 0xF0
00007942783d0a34  pop r11
00007942783d0a36  pop r10
00007942783d0a38  pop r9
00007942783d0a3a  pop r8
00007942783d0a3c  pop rsi
00007942783d0a3d  pop rdi
00007942783d0a3e  pop rdx
00007942783d0a3f  pop rcx
00007942783d0a40  pop rax
00007942783d0a41  add rsp, 0x08
00007942783d0a45  jmp 0x00007942783CF617
00007942783d0a4a  sub rsp, 0x08
00007942783d0a4e  push rax
00007942783d0a4f  push rcx
00007942783d0a50  push rdx
00007942783d0a51  push rdi
00007942783d0a52  push rsi
00007942783d0a53  push r8
00007942783d0a55  push r9
00007942783d0a57  push r10
00007942783d0a59  push r11
00007942783d0a5b  sub rsp, 0xF0
00007942783d0a62  vmovaps [rsp], xmm0
00007942783d0a67  vmovaps [rsp+0x10], xmm2
00007942783d0a6d  vmovaps [rsp+0x20], xmm3
00007942783d0a73  vmovaps [rsp+0x30], xmm4
00007942783d0a79  vmovaps [rsp+0x40], xmm5
00007942783d0a7f  vmovaps [rsp+0x50], xmm6
00007942783d0a85  vmovaps [rsp+0x60], xmm7
00007942783d0a8b  vmovaps [rsp+0x70], xmm8
00007942783d0a91  vmovaps [rsp+0x80], xmm9
00007942783d0a9a  vmovaps [rsp+0x90], xmm10
00007942783d0aa3  vmovaps [rsp+0xA0], xmm11
00007942783d0aac  vmovaps [rsp+0xB0], xmm12
00007942783d0ab5  vmovaps [rsp+0xC0], xmm13
00007942783d0abe  vmovaps [rsp+0xD0], xmm14
00007942783d0ac7  vmovaps [rsp+0xE0], xmm15
00007942783d0ad0  sub rsp, 0x30
00007942783d0ad4  movaps [rsp], xmm1
00007942783d0ad8  movaps [rsp+0x10], xmm14
00007942783d0ade  movaps [rsp+0x20], xmm10
00007942783d0ae4  lea rdi, [rsp]
00007942783d0ae8  mov esi, 0x00
00007942783d0aed  mov rax, 0x59DDDCBA3530
00007942783d0af7  call rax
00007942783d0af9  movaps xmm1, [rsp]
00007942783d0afd  add rsp, 0x30
00007942783d0b01  vmovaps xmm0, [rsp]
00007942783d0b06  vmovaps xmm2, [rsp+0x10]
00007942783d0b0c  vmovaps xmm3, [rsp+0x20]
00007942783d0b12  vmovaps xmm4, [rsp+0x30]
00007942783d0b18  vmovaps xmm5, [rsp+0x40]
00007942783d0b1e  vmovaps xmm6, [rsp+0x50]
00007942783d0b24  vmovaps xmm7, [rsp+0x60]
00007942783d0b2a  vmovaps xmm8, [rsp+0x70]
00007942783d0b30  vmovaps xmm9, [rsp+0x80]
00007942783d0b39  vmovaps xmm10, [rsp+0x90]
00007942783d0b42  vmovaps xmm11, [rsp+0xA0]
00007942783d0b4b  vmovaps xmm12, [rsp+0xB0]
00007942783d0b54  vmovaps xmm13, [rsp+0xC0]
00007942783d0b5d  vmovaps xmm14, [rsp+0xD0]
00007942783d0b66  vmovaps xmm15, [rsp+0xE0]
00007942783d0b6f  add rsp, 0xF0
00007942783d0b76  pop r11
00007942783d0b78  pop r10
00007942783d0b7a  pop r9
00007942783d0b7c  pop r8
00007942783d0b7e  pop rsi
00007942783d0b7f  pop rdi
00007942783d0b80  pop rdx
00007942783d0b81  pop rcx
00007942783d0b82  pop rax
00007942783d0b83  add rsp, 0x08
00007942783d0b87  jmp 0x00007942783CF631
00007942783d0b8c  sub rsp, 0x08
00007942783d0b90  push rax
00007942783d0b91  push rcx
00007942783d0b92  push rdx
00007942783d0b93  push rdi
00007942783d0b94  push rsi
00007942783d0b95  push r8
00007942783d0b97  push r9
00007942783d0b99  push r10
00007942783d0b9b  push r11
00007942783d0b9d  sub rsp, 0xF0
00007942783d0ba4  vmovaps [rsp], xmm0
00007942783d0ba9  vmovaps [rsp+0x10], xmm1
00007942783d0baf  vmovaps [rsp+0x20], xmm2
00007942783d0bb5  vmovaps [rsp+0x30], xmm3
00007942783d0bbb  vmovaps [rsp+0x40], xmm4
00007942783d0bc1  vmovaps [rsp+0x50], xmm5
00007942783d0bc7  vmovaps [rsp+0x60], xmm6
00007942783d0bcd  vmovaps [rsp+0x70], xmm7
00007942783d0bd3  vmovaps [rsp+0x80], xmm8
00007942783d0bdc  vmovaps [rsp+0x90], xmm9
00007942783d0be5  vmovaps [rsp+0xA0], xmm10
00007942783d0bee  vmovaps [rsp+0xB0], xmm11
00007942783d0bf7  vmovaps [rsp+0xC0], xmm12
00007942783d0c00  vmovaps [rsp+0xD0], xmm14
00007942783d0c09  vmovaps [rsp+0xE0], xmm15
00007942783d0c12  sub rsp, 0x30
00007942783d0c16  movaps [rsp], xmm13
00007942783d0c1b  movaps [rsp+0x10], xmm14
00007942783d0c21  movaps [rsp+0x20], xmm2
00007942783d0c26  lea rdi, [rsp]
00007942783d0c2a  mov esi, 0x00
00007942783d0c2f  mov rax, 0x59DDDCBA3530
00007942783d0c39  call rax
00007942783d0c3b  movaps xmm13, [rsp]
00007942783d0c40  add rsp, 0x30
00007942783d0c44  vmovaps xmm0, [rsp]
00007942783d0c49  vmovaps xmm1, [rsp+0x10]
00007942783d0c4f  vmovaps xmm2, [rsp+0x20]
00007942783d0c55  vmovaps xmm3, [rsp+0x30]
00007942783d0c5b  vmovaps xmm4, [rsp+0x40]
00007942783d0c61  vmovaps xmm5, [rsp+0x50]
00007942783d0c67  vmovaps xmm6, [rsp+0x60]
00007942783d0c6d  vmovaps xmm7, [rsp+0x70]
00007942783d0c73  vmovaps xmm8, [rsp+0x80]
00007942783d0c7c  vmovaps xmm9, [rsp+0x90]
00007942783d0c85  vmovaps xmm10, [rsp+0xA0]
00007942783d0c8e  vmovaps xmm11, [rsp+0xB0]
00007942783d0c97  vmovaps xmm12, [rsp+0xC0]
00007942783d0ca0  vmovaps xmm14, [rsp+0xD0]
00007942783d0ca9  vmovaps xmm15, [rsp+0xE0]
00007942783d0cb2  add rsp, 0xF0
00007942783d0cb9  pop r11
00007942783d0cbb  pop r10
00007942783d0cbd  pop r9
00007942783d0cbf  pop r8
00007942783d0cc1  pop rsi
00007942783d0cc2  pop rdi
00007942783d0cc3  pop rdx
00007942783d0cc4  pop rcx
00007942783d0cc5  pop rax
00007942783d0cc6  add rsp, 0x08
00007942783d0cca  jmp 0x00007942783CF64C
00007942783d0ccf  sub rsp, 0x08
00007942783d0cd3  push rax
00007942783d0cd4  push rcx
00007942783d0cd5  push rdx
00007942783d0cd6  push rdi
00007942783d0cd7  push rsi
00007942783d0cd8  push r8
00007942783d0cda  push r9
00007942783d0cdc  push r10
00007942783d0cde  push r11
00007942783d0ce0  sub rsp, 0xF0
00007942783d0ce7  vmovaps [rsp], xmm0
00007942783d0cec  vmovaps [rsp+0x10], xmm2
00007942783d0cf2  vmovaps [rsp+0x20], xmm3
00007942783d0cf8  vmovaps [rsp+0x30], xmm4
00007942783d0cfe  vmovaps [rsp+0x40], xmm5
00007942783d0d04  vmovaps [rsp+0x50], xmm6
00007942783d0d0a  vmovaps [rsp+0x60], xmm7
00007942783d0d10  vmovaps [rsp+0x70], xmm8
00007942783d0d16  vmovaps [rsp+0x80], xmm9
00007942783d0d1f  vmovaps [rsp+0x90], xmm10
00007942783d0d28  vmovaps [rsp+0xA0], xmm11
00007942783d0d31  vmovaps [rsp+0xB0], xmm12
00007942783d0d3a  vmovaps [rsp+0xC0], xmm13
00007942783d0d43  vmovaps [rsp+0xD0], xmm14
00007942783d0d4c  vmovaps [rsp+0xE0], xmm15
00007942783d0d55  sub rsp, 0x30
00007942783d0d59  movaps [rsp], xmm1
00007942783d0d5d  movaps [rsp+0x10], xmm10
00007942783d0d63  movaps [rsp+0x20], xmm2
00007942783d0d68  lea rdi, [rsp]
00007942783d0d6c  mov esi, 0x00
00007942783d0d71  mov rax, 0x59DDDCBA3530
00007942783d0d7b  call rax
00007942783d0d7d  movaps xmm1, [rsp]
00007942783d0d81  add rsp, 0x30
00007942783d0d85  vmovaps xmm0, [rsp]
00007942783d0d8a  vmovaps xmm2, [rsp+0x10]
00007942783d0d90  vmovaps xmm3, [rsp+0x20]
00007942783d0d96  vmovaps xmm4, [rsp+0x30]
00007942783d0d9c  vmovaps xmm5, [rsp+0x40]
00007942783d0da2  vmovaps xmm6, [rsp+0x50]
00007942783d0da8  vmovaps xmm7, [rsp+0x60]
00007942783d0dae  vmovaps xmm8, [rsp+0x70]
00007942783d0db4  vmovaps xmm9, [rsp+0x80]
00007942783d0dbd  vmovaps xmm10, [rsp+0x90]
00007942783d0dc6  vmovaps xmm11, [rsp+0xA0]
00007942783d0dcf  vmovaps xmm12, [rsp+0xB0]
00007942783d0dd8  vmovaps xmm13, [rsp+0xC0]
00007942783d0de1  vmovaps xmm14, [rsp+0xD0]
00007942783d0dea  vmovaps xmm15, [rsp+0xE0]
00007942783d0df3  add rsp, 0xF0
00007942783d0dfa  pop r11
00007942783d0dfc  pop r10
00007942783d0dfe  pop r9
00007942783d0e00  pop r8
00007942783d0e02  pop rsi
00007942783d0e03  pop rdi
00007942783d0e04  pop rdx
00007942783d0e05  pop rcx
00007942783d0e06  pop rax
00007942783d0e07  add rsp, 0x08
00007942783d0e0b  jmp 0x00007942783CF6B4
00007942783d0e10  sub rsp, 0x08
00007942783d0e14  push rax
00007942783d0e15  push rcx
00007942783d0e16  push rdx
00007942783d0e17  push rdi
00007942783d0e18  push rsi
00007942783d0e19  push r8
00007942783d0e1b  push r9
00007942783d0e1d  push r10
00007942783d0e1f  push r11
00007942783d0e21  sub rsp, 0xF0
00007942783d0e28  vmovaps [rsp], xmm0
00007942783d0e2d  vmovaps [rsp+0x10], xmm1
00007942783d0e33  vmovaps [rsp+0x20], xmm2
00007942783d0e39  vmovaps [rsp+0x30], xmm3
00007942783d0e3f  vmovaps [rsp+0x40], xmm4
00007942783d0e45  vmovaps [rsp+0x50], xmm5
00007942783d0e4b  vmovaps [rsp+0x60], xmm6
00007942783d0e51  vmovaps [rsp+0x70], xmm7
00007942783d0e57  vmovaps [rsp+0x80], xmm8
00007942783d0e60  vmovaps [rsp+0x90], xmm9
00007942783d0e69  vmovaps [rsp+0xA0], xmm10
00007942783d0e72  vmovaps [rsp+0xB0], xmm11
00007942783d0e7b  vmovaps [rsp+0xC0], xmm12
00007942783d0e84  vmovaps [rsp+0xD0], xmm13
00007942783d0e8d  vmovaps [rsp+0xE0], xmm14
00007942783d0e96  sub rsp, 0x30
00007942783d0e9a  movaps [rsp], xmm15
00007942783d0e9f  movaps [rsp+0x10], xmm10
00007942783d0ea5  movaps [rsp+0x20], xmm2
00007942783d0eaa  lea rdi, [rsp]
00007942783d0eae  mov esi, 0x00
00007942783d0eb3  mov rax, 0x59DDDCBA3530
00007942783d0ebd  call rax
00007942783d0ebf  movaps xmm15, [rsp]
00007942783d0ec4  add rsp, 0x30
00007942783d0ec8  vmovaps xmm0, [rsp]
00007942783d0ecd  vmovaps xmm1, [rsp+0x10]
00007942783d0ed3  vmovaps xmm2, [rsp+0x20]
00007942783d0ed9  vmovaps xmm3, [rsp+0x30]
00007942783d0edf  vmovaps xmm4, [rsp+0x40]
00007942783d0ee5  vmovaps xmm5, [rsp+0x50]
00007942783d0eeb  vmovaps xmm6, [rsp+0x60]
00007942783d0ef1  vmovaps xmm7, [rsp+0x70]
00007942783d0ef7  vmovaps xmm8, [rsp+0x80]
00007942783d0f00  vmovaps xmm9, [rsp+0x90]
00007942783d0f09  vmovaps xmm10, [rsp+0xA0]
00007942783d0f12  vmovaps xmm11, [rsp+0xB0]
00007942783d0f1b  vmovaps xmm12, [rsp+0xC0]
00007942783d0f24  vmovaps xmm13, [rsp+0xD0]
00007942783d0f2d  vmovaps xmm14, [rsp+0xE0]
00007942783d0f36  add rsp, 0xF0
00007942783d0f3d  pop r11
00007942783d0f3f  pop r10
00007942783d0f41  pop r9
00007942783d0f43  pop r8
00007942783d0f45  pop rsi
00007942783d0f46  pop rdi
00007942783d0f47  pop rdx
00007942783d0f48  pop rcx
00007942783d0f49  pop rax
00007942783d0f4a  add rsp, 0x08
00007942783d0f4e  jmp 0x00007942783CF706
00007942783d0f53  sub rsp, 0x08
00007942783d0f57  push rax
00007942783d0f58  push rcx
00007942783d0f59  push rdx
00007942783d0f5a  push rdi
00007942783d0f5b  push rsi
00007942783d0f5c  push r8
00007942783d0f5e  push r9
00007942783d0f60  push r10
00007942783d0f62  push r11
00007942783d0f64  sub rsp, 0xF0
00007942783d0f6b  vmovaps [rsp], xmm0
00007942783d0f70  vmovaps [rsp+0x10], xmm2
00007942783d0f76  vmovaps [rsp+0x20], xmm3
00007942783d0f7c  vmovaps [rsp+0x30], xmm4
00007942783d0f82  vmovaps [rsp+0x40], xmm5
00007942783d0f88  vmovaps [rsp+0x50], xmm6
00007942783d0f8e  vmovaps [rsp+0x60], xmm7
00007942783d0f94  vmovaps [rsp+0x70], xmm8
00007942783d0f9a  vmovaps [rsp+0x80], xmm9
00007942783d0fa3  vmovaps [rsp+0x90], xmm10
00007942783d0fac  vmovaps [rsp+0xA0], xmm11
00007942783d0fb5  vmovaps [rsp+0xB0], xmm12
00007942783d0fbe  vmovaps [rsp+0xC0], xmm13
00007942783d0fc7  vmovaps [rsp+0xD0], xmm14
00007942783d0fd0  vmovaps [rsp+0xE0], xmm15
00007942783d0fd9  sub rsp, 0x30
00007942783d0fdd  movaps [rsp], xmm1
00007942783d0fe1  movaps [rsp+0x10], xmm10
00007942783d0fe7  movaps [rsp+0x20], xmm12
00007942783d0fed  lea rdi, [rsp]
00007942783d0ff1  mov esi, 0x00
00007942783d0ff6  mov rax, 0x59DDDCBA3530
00007942783d1000  call rax
00007942783d1002  movaps xmm1, [rsp]
00007942783d1006  add rsp, 0x30
00007942783d100a  vmovaps xmm0, [rsp]
00007942783d100f  vmovaps xmm2, [rsp+0x10]
00007942783d1015  vmovaps xmm3, [rsp+0x20]
00007942783d101b  vmovaps xmm4, [rsp+0x30]
00007942783d1021  vmovaps xmm5, [rsp+0x40]
00007942783d1027  vmovaps xmm6, [rsp+0x50]
00007942783d102d  vmovaps xmm7, [rsp+0x60]
00007942783d1033  vmovaps xmm8, [rsp+0x70]
00007942783d1039  vmovaps xmm9, [rsp+0x80]
00007942783d1042  vmovaps xmm10, [rsp+0x90]
00007942783d104b  vmovaps xmm11, [rsp+0xA0]
00007942783d1054  vmovaps xmm12, [rsp+0xB0]
00007942783d105d  vmovaps xmm13, [rsp+0xC0]
00007942783d1066  vmovaps xmm14, [rsp+0xD0]
00007942783d106f  vmovaps xmm15, [rsp+0xE0]
00007942783d1078  add rsp, 0xF0
00007942783d107f  pop r11
00007942783d1081  pop r10
00007942783d1083  pop r9
00007942783d1085  pop r8
00007942783d1087  pop rsi
00007942783d1088  pop rdi
00007942783d1089  pop rdx
00007942783d108a  pop rcx
00007942783d108b  pop rax
00007942783d108c  add rsp, 0x08
00007942783d1090  jmp 0x00007942783CF732
00007942783d1095  sub rsp, 0x08
00007942783d1099  push rax
00007942783d109a  push rcx
00007942783d109b  push rdx
00007942783d109c  push rdi
00007942783d109d  push rsi
00007942783d109e  push r8
00007942783d10a0  push r9
00007942783d10a2  push r10
00007942783d10a4  push r11
00007942783d10a6  sub rsp, 0xF0
00007942783d10ad  vmovaps [rsp], xmm0
00007942783d10b2  vmovaps [rsp+0x10], xmm1
00007942783d10b8  vmovaps [rsp+0x20], xmm2
00007942783d10be  vmovaps [rsp+0x30], xmm3
00007942783d10c4  vmovaps [rsp+0x40], xmm4
00007942783d10ca  vmovaps [rsp+0x50], xmm5
00007942783d10d0  vmovaps [rsp+0x60], xmm6
00007942783d10d6  vmovaps [rsp+0x70], xmm7
00007942783d10dc  vmovaps [rsp+0x80], xmm8
00007942783d10e5  vmovaps [rsp+0x90], xmm9
00007942783d10ee  vmovaps [rsp+0xA0], xmm10
00007942783d10f7  vmovaps [rsp+0xB0], xmm11
00007942783d1100  vmovaps [rsp+0xC0], xmm12
00007942783d1109  vmovaps [rsp+0xD0], xmm13
00007942783d1112  vmovaps [rsp+0xE0], xmm14
00007942783d111b  sub rsp, 0x30
00007942783d111f  movaps [rsp], xmm15
00007942783d1124  movaps [rsp+0x10], xmm10
00007942783d112a  movaps [rsp+0x20], xmm12
00007942783d1130  lea rdi, [rsp]
00007942783d1134  mov esi, 0x00
00007942783d1139  mov rax, 0x59DDDCBA3530
00007942783d1143  call rax
00007942783d1145  movaps xmm15, [rsp]
00007942783d114a  add rsp, 0x30
00007942783d114e  vmovaps xmm0, [rsp]
00007942783d1153  vmovaps xmm1, [rsp+0x10]
00007942783d1159  vmovaps xmm2, [rsp+0x20]
00007942783d115f  vmovaps xmm3, [rsp+0x30]
00007942783d1165  vmovaps xmm4, [rsp+0x40]
00007942783d116b  vmovaps xmm5, [rsp+0x50]
00007942783d1171  vmovaps xmm6, [rsp+0x60]
00007942783d1177  vmovaps xmm7, [rsp+0x70]
00007942783d117d  vmovaps xmm8, [rsp+0x80]
00007942783d1186  vmovaps xmm9, [rsp+0x90]
00007942783d118f  vmovaps xmm10, [rsp+0xA0]
00007942783d1198  vmovaps xmm11, [rsp+0xB0]
00007942783d11a1  vmovaps xmm12, [rsp+0xC0]
00007942783d11aa  vmovaps xmm13, [rsp+0xD0]
00007942783d11b3  vmovaps xmm14, [rsp+0xE0]
00007942783d11bc  add rsp, 0xF0
00007942783d11c3  pop r11
00007942783d11c5  pop r10
00007942783d11c7  pop r9
00007942783d11c9  pop r8
00007942783d11cb  pop rsi
00007942783d11cc  pop rdi
00007942783d11cd  pop rdx
00007942783d11ce  pop rcx
00007942783d11cf  pop rax
00007942783d11d0  add rsp, 0x08
00007942783d11d4  jmp 0x00007942783CF75E
00007942783d11d9  call 0x00007942781FF430
00007942783d11de  jmp 0x00007942783CF7EE
00007942783d11e3  call 0x00007942781FF430
00007942783d11e8  jmp 0x00007942783CF801
00007942783d11ed  sub rsp, 0x08
00007942783d11f1  push rax
00007942783d11f2  push rcx
00007942783d11f3  push rdx
00007942783d11f4  push rdi
00007942783d11f5  push rsi
00007942783d11f6  push r8
00007942783d11f8  push r9
00007942783d11fa  push r10
00007942783d11fc  push r11
00007942783d11fe  sub rsp, 0xF0
00007942783d1205  vmovaps [rsp], xmm0
00007942783d120a  vmovaps [rsp+0x10], xmm2
00007942783d1210  vmovaps [rsp+0x20], xmm3
00007942783d1216  vmovaps [rsp+0x30], xmm4
00007942783d121c  vmovaps [rsp+0x40], xmm5
00007942783d1222  vmovaps [rsp+0x50], xmm6
00007942783d1228  vmovaps [rsp+0x60], xmm7
00007942783d122e  vmovaps [rsp+0x70], xmm8
00007942783d1234  vmovaps [rsp+0x80], xmm9
00007942783d123d  vmovaps [rsp+0x90], xmm10
00007942783d1246  vmovaps [rsp+0xA0], xmm11
00007942783d124f  vmovaps [rsp+0xB0], xmm12
00007942783d1258  vmovaps [rsp+0xC0], xmm13
00007942783d1261  vmovaps [rsp+0xD0], xmm14
00007942783d126a  vmovaps [rsp+0xE0], xmm15
00007942783d1273  sub rsp, 0x30
00007942783d1277  movaps [rsp], xmm1
00007942783d127b  movaps [rsp+0x10], xmm13
00007942783d1281  movaps [rsp+0x20], xmm2
00007942783d1286  lea rdi, [rsp]
00007942783d128a  mov esi, 0x00
00007942783d128f  mov rax, 0x59DDDCBA3530
00007942783d1299  call rax
00007942783d129b  movaps xmm1, [rsp]
00007942783d129f  add rsp, 0x30
00007942783d12a3  vmovaps xmm0, [rsp]
00007942783d12a8  vmovaps xmm2, [rsp+0x10]
00007942783d12ae  vmovaps xmm3, [rsp+0x20]
00007942783d12b4  vmovaps xmm4, [rsp+0x30]
00007942783d12ba  vmovaps xmm5, [rsp+0x40]
00007942783d12c0  vmovaps xmm6, [rsp+0x50]
00007942783d12c6  vmovaps xmm7, [rsp+0x60]
00007942783d12cc  vmovaps xmm8, [rsp+0x70]
00007942783d12d2  vmovaps xmm9, [rsp+0x80]
00007942783d12db  vmovaps xmm10, [rsp+0x90]
00007942783d12e4  vmovaps xmm11, [rsp+0xA0]
00007942783d12ed  vmovaps xmm12, [rsp+0xB0]
00007942783d12f6  vmovaps xmm13, [rsp+0xC0]
00007942783d12ff  vmovaps xmm14, [rsp+0xD0]
00007942783d1308  vmovaps xmm15, [rsp+0xE0]
00007942783d1311  add rsp, 0xF0
00007942783d1318  pop r11
00007942783d131a  pop r10
00007942783d131c  pop r9
00007942783d131e  pop r8
00007942783d1320  pop rsi
00007942783d1321  pop rdi
00007942783d1322  pop rdx
00007942783d1323  pop rcx
00007942783d1324  pop rax
00007942783d1325  add rsp, 0x08
00007942783d1329  jmp 0x00007942783CF82C
00007942783d132e  call 0x000079427820E760
00007942783d1333  jmp 0x00007942783CF839
00007942783d1338  sub rsp, 0x08
00007942783d133c  push rax
00007942783d133d  push rcx
00007942783d133e  push rdx
00007942783d133f  push rdi
00007942783d1340  push rsi
00007942783d1341  push r8
00007942783d1343  push r9
00007942783d1345  push r10
00007942783d1347  push r11
00007942783d1349  sub rsp, 0xF0
00007942783d1350  vmovaps [rsp], xmm0
00007942783d1355  vmovaps [rsp+0x10], xmm1
00007942783d135b  vmovaps [rsp+0x20], xmm2
00007942783d1361  vmovaps [rsp+0x30], xmm3
00007942783d1367  vmovaps [rsp+0x40], xmm4
00007942783d136d  vmovaps [rsp+0x50], xmm5
00007942783d1373  vmovaps [rsp+0x60], xmm6
00007942783d1379  vmovaps [rsp+0x70], xmm7
00007942783d137f  vmovaps [rsp+0x80], xmm8
00007942783d1388  vmovaps [rsp+0x90], xmm9
00007942783d1391  vmovaps [rsp+0xA0], xmm10
00007942783d139a  vmovaps [rsp+0xB0], xmm11
00007942783d13a3  vmovaps [rsp+0xC0], xmm12
00007942783d13ac  vmovaps [rsp+0xD0], xmm14
00007942783d13b5  vmovaps [rsp+0xE0], xmm15
00007942783d13be  sub rsp, 0x30
00007942783d13c2  movaps [rsp], xmm13
00007942783d13c7  movaps [rsp+0x10], xmm2
00007942783d13cc  movaps [rsp+0x20], xmm1
00007942783d13d1  lea rdi, [rsp]
00007942783d13d5  mov esi, 0x00
00007942783d13da  mov rax, 0x59DDDCBA3530
00007942783d13e4  call rax
00007942783d13e6  movaps xmm13, [rsp]
00007942783d13eb  add rsp, 0x30
00007942783d13ef  vmovaps xmm0, [rsp]
00007942783d13f4  vmovaps xmm1, [rsp+0x10]
00007942783d13fa  vmovaps xmm2, [rsp+0x20]
00007942783d1400  vmovaps xmm3, [rsp+0x30]
00007942783d1406  vmovaps xmm4, [rsp+0x40]
00007942783d140c  vmovaps xmm5, [rsp+0x50]
00007942783d1412  vmovaps xmm6, [rsp+0x60]
00007942783d1418  vmovaps xmm7, [rsp+0x70]
00007942783d141e  vmovaps xmm8, [rsp+0x80]
00007942783d1427  vmovaps xmm9, [rsp+0x90]
00007942783d1430  vmovaps xmm10, [rsp+0xA0]
00007942783d1439  vmovaps xmm11, [rsp+0xB0]
00007942783d1442  vmovaps xmm12, [rsp+0xC0]
00007942783d144b  vmovaps xmm14, [rsp+0xD0]
00007942783d1454  vmovaps xmm15, [rsp+0xE0]
00007942783d145d  add rsp, 0xF0
00007942783d1464  pop r11
00007942783d1466  pop r10
00007942783d1468  pop r9
00007942783d146a  pop r8
00007942783d146c  pop rsi
00007942783d146d  pop rdi
00007942783d146e  pop rdx
00007942783d146f  pop rcx
00007942783d1470  pop rax
00007942783d1471  add rsp, 0x08
00007942783d1475  jmp 0x00007942783CF878
00007942783d147a  sub rsp, 0x08
00007942783d147e  push rax
00007942783d147f  push rcx
00007942783d1480  push rdx
00007942783d1481  push rdi
00007942783d1482  push rsi
00007942783d1483  push r8
00007942783d1485  push r9
00007942783d1487  push r10
00007942783d1489  push r11
00007942783d148b  sub rsp, 0xF0
00007942783d1492  vmovaps [rsp], xmm0
00007942783d1497  vmovaps [rsp+0x10], xmm2
00007942783d149d  vmovaps [rsp+0x20], xmm3
00007942783d14a3  vmovaps [rsp+0x30], xmm4
00007942783d14a9  vmovaps [rsp+0x40], xmm5
00007942783d14af  vmovaps [rsp+0x50], xmm6
00007942783d14b5  vmovaps [rsp+0x60], xmm7
00007942783d14bb  vmovaps [rsp+0x70], xmm8
00007942783d14c1  vmovaps [rsp+0x80], xmm9
00007942783d14ca  vmovaps [rsp+0x90], xmm10
00007942783d14d3  vmovaps [rsp+0xA0], xmm11
00007942783d14dc  vmovaps [rsp+0xB0], xmm12
00007942783d14e5  vmovaps [rsp+0xC0], xmm13
00007942783d14ee  vmovaps [rsp+0xD0], xmm14
00007942783d14f7  vmovaps [rsp+0xE0], xmm15
00007942783d1500  sub rsp, 0x30
00007942783d1504  movaps [rsp], xmm1
00007942783d1508  movaps [rsp+0x10], xmm15
00007942783d150e  movaps [rsp+0x20], xmm2
00007942783d1513  lea rdi, [rsp]
00007942783d1517  mov esi, 0x00
00007942783d151c  mov rax, 0x59DDDCBA3530
00007942783d1526  call rax
00007942783d1528  movaps xmm1, [rsp]
00007942783d152c  add rsp, 0x30
00007942783d1530  vmovaps xmm0, [rsp]
00007942783d1535  vmovaps xmm2, [rsp+0x10]
00007942783d153b  vmovaps xmm3, [rsp+0x20]
00007942783d1541  vmovaps xmm4, [rsp+0x30]
00007942783d1547  vmovaps xmm5, [rsp+0x40]
00007942783d154d  vmovaps xmm6, [rsp+0x50]
00007942783d1553  vmovaps xmm7, [rsp+0x60]
00007942783d1559  vmovaps xmm8, [rsp+0x70]
00007942783d155f  vmovaps xmm9, [rsp+0x80]
00007942783d1568  vmovaps xmm10, [rsp+0x90]
00007942783d1571  vmovaps xmm11, [rsp+0xA0]
00007942783d157a  vmovaps xmm12, [rsp+0xB0]
00007942783d1583  vmovaps xmm13, [rsp+0xC0]
00007942783d158c  vmovaps xmm14, [rsp+0xD0]
00007942783d1595  vmovaps xmm15, [rsp+0xE0]
00007942783d159e  add rsp, 0xF0
00007942783d15a5  pop r11
00007942783d15a7  pop r10
00007942783d15a9  pop r9
00007942783d15ab  pop r8
00007942783d15ad  pop rsi
00007942783d15ae  pop rdi
00007942783d15af  pop rdx
00007942783d15b0  pop rcx
00007942783d15b1  pop rax
00007942783d15b2  add rsp, 0x08
00007942783d15b6  jmp 0x00007942783CF8AC
00007942783d15bb  sub rsp, 0x08
00007942783d15bf  push rax
00007942783d15c0  push rcx
00007942783d15c1  push rdx
00007942783d15c2  push rdi
00007942783d15c3  push rsi
00007942783d15c4  push r8
00007942783d15c6  push r9
00007942783d15c8  push r10
00007942783d15ca  push r11
00007942783d15cc  sub rsp, 0xF0
00007942783d15d3  vmovaps [rsp], xmm0
00007942783d15d8  vmovaps [rsp+0x10], xmm1
00007942783d15de  vmovaps [rsp+0x20], xmm2
00007942783d15e4  vmovaps [rsp+0x30], xmm3
00007942783d15ea  vmovaps [rsp+0x40], xmm4
00007942783d15f0  vmovaps [rsp+0x50], xmm5
00007942783d15f6  vmovaps [rsp+0x60], xmm6
00007942783d15fc  vmovaps [rsp+0x70], xmm7
00007942783d1602  vmovaps [rsp+0x80], xmm8
00007942783d160b  vmovaps [rsp+0x90], xmm9
00007942783d1614  vmovaps [rsp+0xA0], xmm10
00007942783d161d  vmovaps [rsp+0xB0], xmm11
00007942783d1626  vmovaps [rsp+0xC0], xmm12
00007942783d162f  vmovaps [rsp+0xD0], xmm13
00007942783d1638  vmovaps [rsp+0xE0], xmm15
00007942783d1641  sub rsp, 0x30
00007942783d1645  movaps [rsp], xmm14
00007942783d164a  movaps [rsp+0x10], xmm2
00007942783d164f  movaps [rsp+0x20], xmm15
00007942783d1655  lea rdi, [rsp]
00007942783d1659  mov esi, 0x00
00007942783d165e  mov rax, 0x59DDDCBA3530
00007942783d1668  call rax
00007942783d166a  movaps xmm14, [rsp]
00007942783d166f  add rsp, 0x30
00007942783d1673  vmovaps xmm0, [rsp]
00007942783d1678  vmovaps xmm1, [rsp+0x10]
00007942783d167e  vmovaps xmm2, [rsp+0x20]
00007942783d1684  vmovaps xmm3, [rsp+0x30]
00007942783d168a  vmovaps xmm4, [rsp+0x40]
00007942783d1690  vmovaps xmm5, [rsp+0x50]
00007942783d1696  vmovaps xmm6, [rsp+0x60]
00007942783d169c  vmovaps xmm7, [rsp+0x70]
00007942783d16a2  vmovaps xmm8, [rsp+0x80]
00007942783d16ab  vmovaps xmm9, [rsp+0x90]
00007942783d16b4  vmovaps xmm10, [rsp+0xA0]
00007942783d16bd  vmovaps xmm11, [rsp+0xB0]
00007942783d16c6  vmovaps xmm12, [rsp+0xC0]
00007942783d16cf  vmovaps xmm13, [rsp+0xD0]
00007942783d16d8  vmovaps xmm15, [rsp+0xE0]
00007942783d16e1  add rsp, 0xF0
00007942783d16e8  pop r11
00007942783d16ea  pop r10
00007942783d16ec  pop r9
00007942783d16ee  pop r8
00007942783d16f0  pop rsi
00007942783d16f1  pop rdi
00007942783d16f2  pop rdx
00007942783d16f3  pop rcx
00007942783d16f4  pop rax
00007942783d16f5  add rsp, 0x08
00007942783d16f9  jmp 0x00007942783CF8E7
00007942783d16fe  sub rsp, 0x08
00007942783d1702  push rax
00007942783d1703  push rcx
00007942783d1704  push rdx
00007942783d1705  push rdi
00007942783d1706  push rsi
00007942783d1707  push r8
00007942783d1709  push r9
00007942783d170b  push r10
00007942783d170d  push r11
00007942783d170f  sub rsp, 0xF0
00007942783d1716  vmovaps [rsp], xmm0
00007942783d171b  vmovaps [rsp+0x10], xmm1
00007942783d1721  vmovaps [rsp+0x20], xmm2
00007942783d1727  vmovaps [rsp+0x30], xmm3
00007942783d172d  vmovaps [rsp+0x40], xmm4
00007942783d1733  vmovaps [rsp+0x50], xmm5
00007942783d1739  vmovaps [rsp+0x60], xmm6
00007942783d173f  vmovaps [rsp+0x70], xmm7
00007942783d1745  vmovaps [rsp+0x80], xmm8
00007942783d174e  vmovaps [rsp+0x90], xmm9
00007942783d1757  vmovaps [rsp+0xA0], xmm10
00007942783d1760  vmovaps [rsp+0xB0], xmm11
00007942783d1769  vmovaps [rsp+0xC0], xmm12
00007942783d1772  vmovaps [rsp+0xD0], xmm13
00007942783d177b  vmovaps [rsp+0xE0], xmm14
00007942783d1784  sub rsp, 0x30
00007942783d1788  movaps [rsp], xmm15
00007942783d178d  movaps [rsp+0x10], xmm2
00007942783d1792  movaps [rsp+0x20], xmm1
00007942783d1797  lea rdi, [rsp]
00007942783d179b  mov esi, 0x00
00007942783d17a0  mov rax, 0x59DDDCBA3530
00007942783d17aa  call rax
00007942783d17ac  movaps xmm15, [rsp]
00007942783d17b1  add rsp, 0x30
00007942783d17b5  vmovaps xmm0, [rsp]
00007942783d17ba  vmovaps xmm1, [rsp+0x10]
00007942783d17c0  vmovaps xmm2, [rsp+0x20]
00007942783d17c6  vmovaps xmm3, [rsp+0x30]
00007942783d17cc  vmovaps xmm4, [rsp+0x40]
00007942783d17d2  vmovaps xmm5, [rsp+0x50]
00007942783d17d8  vmovaps xmm6, [rsp+0x60]
00007942783d17de  vmovaps xmm7, [rsp+0x70]
00007942783d17e4  vmovaps xmm8, [rsp+0x80]
00007942783d17ed  vmovaps xmm9, [rsp+0x90]
00007942783d17f6  vmovaps xmm10, [rsp+0xA0]
00007942783d17ff  vmovaps xmm11, [rsp+0xB0]
00007942783d1808  vmovaps xmm12, [rsp+0xC0]
00007942783d1811  vmovaps xmm13, [rsp+0xD0]
00007942783d181a  vmovaps xmm14, [rsp+0xE0]
00007942783d1823  add rsp, 0xF0
00007942783d182a  pop r11
00007942783d182c  pop r10
00007942783d182e  pop r9
00007942783d1830  pop r8
00007942783d1832  pop rsi
00007942783d1833  pop rdi
00007942783d1834  pop rdx
00007942783d1835  pop rcx
00007942783d1836  pop rax
00007942783d1837  add rsp, 0x08
00007942783d183b  jmp 0x00007942783CF923
00007942783d1840  call 0x00007942781FF430
00007942783d1845  jmp 0x00007942783CF930
00007942783d184a  sub rsp, 0x08
00007942783d184e  push rax
00007942783d184f  push rcx
00007942783d1850  push rdx
00007942783d1851  push rdi
00007942783d1852  push rsi
00007942783d1853  push r8
00007942783d1855  push r9
00007942783d1857  push r10
00007942783d1859  push r11
00007942783d185b  sub rsp, 0xF0
00007942783d1862  vmovaps [rsp], xmm0
00007942783d1867  vmovaps [rsp+0x10], xmm1
00007942783d186d  vmovaps [rsp+0x20], xmm3
00007942783d1873  vmovaps [rsp+0x30], xmm4
00007942783d1879  vmovaps [rsp+0x40], xmm5
00007942783d187f  vmovaps [rsp+0x50], xmm6
00007942783d1885  vmovaps [rsp+0x60], xmm7
00007942783d188b  vmovaps [rsp+0x70], xmm8
00007942783d1891  vmovaps [rsp+0x80], xmm9
00007942783d189a  vmovaps [rsp+0x90], xmm10
00007942783d18a3  vmovaps [rsp+0xA0], xmm11
00007942783d18ac  vmovaps [rsp+0xB0], xmm12
00007942783d18b5  vmovaps [rsp+0xC0], xmm13
00007942783d18be  vmovaps [rsp+0xD0], xmm14
00007942783d18c7  vmovaps [rsp+0xE0], xmm15
00007942783d18d0  sub rsp, 0x30
00007942783d18d4  movaps [rsp], xmm2
00007942783d18d8  movaps [rsp+0x10], xmm1
00007942783d18dd  movaps [rsp+0x20], xmm14
00007942783d18e3  lea rdi, [rsp]
00007942783d18e7  mov esi, 0x00
00007942783d18ec  mov rax, 0x59DDDCBA3530
00007942783d18f6  call rax
00007942783d18f8  movaps xmm2, [rsp]
00007942783d18fc  add rsp, 0x30
00007942783d1900  vmovaps xmm0, [rsp]
00007942783d1905  vmovaps xmm1, [rsp+0x10]
00007942783d190b  vmovaps xmm3, [rsp+0x20]
00007942783d1911  vmovaps xmm4, [rsp+0x30]
00007942783d1917  vmovaps xmm5, [rsp+0x40]
00007942783d191d  vmovaps xmm6, [rsp+0x50]
00007942783d1923  vmovaps xmm7, [rsp+0x60]
00007942783d1929  vmovaps xmm8, [rsp+0x70]
00007942783d192f  vmovaps xmm9, [rsp+0x80]
00007942783d1938  vmovaps xmm10, [rsp+0x90]
00007942783d1941  vmovaps xmm11, [rsp+0xA0]
00007942783d194a  vmovaps xmm12, [rsp+0xB0]
00007942783d1953  vmovaps xmm13, [rsp+0xC0]
00007942783d195c  vmovaps xmm14, [rsp+0xD0]
00007942783d1965  vmovaps xmm15, [rsp+0xE0]
00007942783d196e  add rsp, 0xF0
00007942783d1975  pop r11
00007942783d1977  pop r10
00007942783d1979  pop r9
00007942783d197b  pop r8
00007942783d197d  pop rsi
00007942783d197e  pop rdi
00007942783d197f  pop rdx
00007942783d1980  pop rcx
00007942783d1981  pop rax
00007942783d1982  add rsp, 0x08
00007942783d1986  jmp 0x00007942783CF96D
00007942783d198b  sub rsp, 0x08
00007942783d198f  push rax
00007942783d1990  push rcx
00007942783d1991  push rdx
00007942783d1992  push rdi
00007942783d1993  push rsi
00007942783d1994  push r8
00007942783d1996  push r9
00007942783d1998  push r10
00007942783d199a  push r11
00007942783d199c  sub rsp, 0xF0
00007942783d19a3  vmovaps [rsp], xmm0
00007942783d19a8  vmovaps [rsp+0x10], xmm1
00007942783d19ae  vmovaps [rsp+0x20], xmm2
00007942783d19b4  vmovaps [rsp+0x30], xmm3
00007942783d19ba  vmovaps [rsp+0x40], xmm4
00007942783d19c0  vmovaps [rsp+0x50], xmm5
00007942783d19c6  vmovaps [rsp+0x60], xmm6
00007942783d19cc  vmovaps [rsp+0x70], xmm7
00007942783d19d2  vmovaps [rsp+0x80], xmm8
00007942783d19db  vmovaps [rsp+0x90], xmm9
00007942783d19e4  vmovaps [rsp+0xA0], xmm10
00007942783d19ed  vmovaps [rsp+0xB0], xmm11
00007942783d19f6  vmovaps [rsp+0xC0], xmm12
00007942783d19ff  vmovaps [rsp+0xD0], xmm13
00007942783d1a08  vmovaps [rsp+0xE0], xmm14
00007942783d1a11  sub rsp, 0x30
00007942783d1a15  movaps [rsp], xmm15
00007942783d1a1a  movaps [rsp+0x10], xmm14
00007942783d1a20  movaps [rsp+0x20], xmm1
00007942783d1a25  lea rdi, [rsp]
00007942783d1a29  mov esi, 0x00
00007942783d1a2e  mov rax, 0x59DDDCBA3530
00007942783d1a38  call rax
00007942783d1a3a  movaps xmm15, [rsp]
00007942783d1a3f  add rsp, 0x30
00007942783d1a43  vmovaps xmm0, [rsp]
00007942783d1a48  vmovaps xmm1, [rsp+0x10]
00007942783d1a4e  vmovaps xmm2, [rsp+0x20]
00007942783d1a54  vmovaps xmm3, [rsp+0x30]
00007942783d1a5a  vmovaps xmm4, [rsp+0x40]
00007942783d1a60  vmovaps xmm5, [rsp+0x50]
00007942783d1a66  vmovaps xmm6, [rsp+0x60]
00007942783d1a6c  vmovaps xmm7, [rsp+0x70]
00007942783d1a72  vmovaps xmm8, [rsp+0x80]
00007942783d1a7b  vmovaps xmm9, [rsp+0x90]
00007942783d1a84  vmovaps xmm10, [rsp+0xA0]
00007942783d1a8d  vmovaps xmm11, [rsp+0xB0]
00007942783d1a96  vmovaps xmm12, [rsp+0xC0]
00007942783d1a9f  vmovaps xmm13, [rsp+0xD0]
00007942783d1aa8  vmovaps xmm14, [rsp+0xE0]
00007942783d1ab1  add rsp, 0xF0
00007942783d1ab8  pop r11
00007942783d1aba  pop r10
00007942783d1abc  pop r9
00007942783d1abe  pop r8
00007942783d1ac0  pop rsi
00007942783d1ac1  pop rdi
00007942783d1ac2  pop rdx
00007942783d1ac3  pop rcx
00007942783d1ac4  pop rax
00007942783d1ac5  add rsp, 0x08
00007942783d1ac9  jmp 0x00007942783CF9E7
00007942783d1ace  call 0x00007942781FF430
00007942783d1ad3  jmp 0x00007942783CF9F4
00007942783d1ad8  sub rsp, 0x08
00007942783d1adc  push rax
00007942783d1add  push rcx
00007942783d1ade  push rdx
00007942783d1adf  push rdi
00007942783d1ae0  push rsi
00007942783d1ae1  push r8
00007942783d1ae3  push r9
00007942783d1ae5  push r10
00007942783d1ae7  push r11
00007942783d1ae9  sub rsp, 0xF0
00007942783d1af0  vmovaps [rsp], xmm0
00007942783d1af5  vmovaps [rsp+0x10], xmm1
00007942783d1afb  vmovaps [rsp+0x20], xmm2
00007942783d1b01  vmovaps [rsp+0x30], xmm3
00007942783d1b07  vmovaps [rsp+0x40], xmm4
00007942783d1b0d  vmovaps [rsp+0x50], xmm5
00007942783d1b13  vmovaps [rsp+0x60], xmm6
00007942783d1b19  vmovaps [rsp+0x70], xmm7
00007942783d1b1f  vmovaps [rsp+0x80], xmm8
00007942783d1b28  vmovaps [rsp+0x90], xmm9
00007942783d1b31  vmovaps [rsp+0xA0], xmm10
00007942783d1b3a  vmovaps [rsp+0xB0], xmm11
00007942783d1b43  vmovaps [rsp+0xC0], xmm12
00007942783d1b4c  vmovaps [rsp+0xD0], xmm13
00007942783d1b55  vmovaps [rsp+0xE0], xmm15
00007942783d1b5e  sub rsp, 0x30
00007942783d1b62  movaps [rsp], xmm14
00007942783d1b67  movaps [rsp+0x10], xmm13
00007942783d1b6d  movaps [rsp+0x20], xmm1
00007942783d1b72  lea rdi, [rsp]
00007942783d1b76  mov esi, 0x00
00007942783d1b7b  mov rax, 0x59DDDCBA3530
00007942783d1b85  call rax
00007942783d1b87  movaps xmm14, [rsp]
00007942783d1b8c  add rsp, 0x30
00007942783d1b90  vmovaps xmm0, [rsp]
00007942783d1b95  vmovaps xmm1, [rsp+0x10]
00007942783d1b9b  vmovaps xmm2, [rsp+0x20]
00007942783d1ba1  vmovaps xmm3, [rsp+0x30]
00007942783d1ba7  vmovaps xmm4, [rsp+0x40]
00007942783d1bad  vmovaps xmm5, [rsp+0x50]
00007942783d1bb3  vmovaps xmm6, [rsp+0x60]
00007942783d1bb9  vmovaps xmm7, [rsp+0x70]
00007942783d1bbf  vmovaps xmm8, [rsp+0x80]
00007942783d1bc8  vmovaps xmm9, [rsp+0x90]
00007942783d1bd1  vmovaps xmm10, [rsp+0xA0]
00007942783d1bda  vmovaps xmm11, [rsp+0xB0]
00007942783d1be3  vmovaps xmm12, [rsp+0xC0]
00007942783d1bec  vmovaps xmm13, [rsp+0xD0]
00007942783d1bf5  vmovaps xmm15, [rsp+0xE0]
00007942783d1bfe  add rsp, 0xF0
00007942783d1c05  pop r11
00007942783d1c07  pop r10
00007942783d1c09  pop r9
00007942783d1c0b  pop r8
00007942783d1c0d  pop rsi
00007942783d1c0e  pop rdi
00007942783d1c0f  pop rdx
00007942783d1c10  pop rcx
00007942783d1c11  pop rax
00007942783d1c12  add rsp, 0x08
00007942783d1c16  jmp 0x00007942783CFAAF
00007942783d1c1b  sub rsp, 0x08
00007942783d1c1f  push rax
00007942783d1c20  push rcx
00007942783d1c21  push rdx
00007942783d1c22  push rdi
00007942783d1c23  push rsi
00007942783d1c24  push r8
00007942783d1c26  push r9
00007942783d1c28  push r10
00007942783d1c2a  push r11
00007942783d1c2c  sub rsp, 0xF0
00007942783d1c33  vmovaps [rsp], xmm0
00007942783d1c38  vmovaps [rsp+0x10], xmm1
00007942783d1c3e  vmovaps [rsp+0x20], xmm2
00007942783d1c44  vmovaps [rsp+0x30], xmm3
00007942783d1c4a  vmovaps [rsp+0x40], xmm4
00007942783d1c50  vmovaps [rsp+0x50], xmm5
00007942783d1c56  vmovaps [rsp+0x60], xmm6
00007942783d1c5c  vmovaps [rsp+0x70], xmm7
00007942783d1c62  vmovaps [rsp+0x80], xmm8
00007942783d1c6b  vmovaps [rsp+0x90], xmm9
00007942783d1c74  vmovaps [rsp+0xA0], xmm10
00007942783d1c7d  vmovaps [rsp+0xB0], xmm11
00007942783d1c86  vmovaps [rsp+0xC0], xmm12
00007942783d1c8f  vmovaps [rsp+0xD0], xmm13
00007942783d1c98  vmovaps [rsp+0xE0], xmm14
00007942783d1ca1  sub rsp, 0x30
00007942783d1ca5  movaps [rsp], xmm15
00007942783d1caa  movaps [rsp+0x10], xmm13
00007942783d1cb0  movaps [rsp+0x20], xmm1
00007942783d1cb5  lea rdi, [rsp]
00007942783d1cb9  mov esi, 0x00
00007942783d1cbe  mov rax, 0x59DDDCBA3530
00007942783d1cc8  call rax
00007942783d1cca  movaps xmm15, [rsp]
00007942783d1ccf  add rsp, 0x30
00007942783d1cd3  vmovaps xmm0, [rsp]
00007942783d1cd8  vmovaps xmm1, [rsp+0x10]
00007942783d1cde  vmovaps xmm2, [rsp+0x20]
00007942783d1ce4  vmovaps xmm3, [rsp+0x30]
00007942783d1cea  vmovaps xmm4, [rsp+0x40]
00007942783d1cf0  vmovaps xmm5, [rsp+0x50]
00007942783d1cf6  vmovaps xmm6, [rsp+0x60]
00007942783d1cfc  vmovaps xmm7, [rsp+0x70]
00007942783d1d02  vmovaps xmm8, [rsp+0x80]
00007942783d1d0b  vmovaps xmm9, [rsp+0x90]
00007942783d1d14  vmovaps xmm10, [rsp+0xA0]
00007942783d1d1d  vmovaps xmm11, [rsp+0xB0]
00007942783d1d26  vmovaps xmm12, [rsp+0xC0]
00007942783d1d2f  vmovaps xmm13, [rsp+0xD0]
00007942783d1d38  vmovaps xmm14, [rsp+0xE0]
00007942783d1d41  add rsp, 0xF0
00007942783d1d48  pop r11
00007942783d1d4a  pop r10
00007942783d1d4c  pop r9
00007942783d1d4e  pop r8
00007942783d1d50  pop rsi
00007942783d1d51  pop rdi
00007942783d1d52  pop rdx
00007942783d1d53  pop rcx
00007942783d1d54  pop rax
00007942783d1d55  add rsp, 0x08
00007942783d1d59  jmp 0x00007942783CFAEB
00007942783d1d5e  call 0x00007942781FF430
00007942783d1d63  jmp 0x00007942783CFAF8
00007942783d1d68  sub rsp, 0x08
00007942783d1d6c  push rax
00007942783d1d6d  push rcx
00007942783d1d6e  push rdx
00007942783d1d6f  push rdi
00007942783d1d70  push rsi
00007942783d1d71  push r8
00007942783d1d73  push r9
00007942783d1d75  push r10
00007942783d1d77  push r11
00007942783d1d79  sub rsp, 0xF0
00007942783d1d80  vmovaps [rsp], xmm0
00007942783d1d85  vmovaps [rsp+0x10], xmm1
00007942783d1d8b  vmovaps [rsp+0x20], xmm2
00007942783d1d91  vmovaps [rsp+0x30], xmm3
00007942783d1d97  vmovaps [rsp+0x40], xmm4
00007942783d1d9d  vmovaps [rsp+0x50], xmm5
00007942783d1da3  vmovaps [rsp+0x60], xmm6
00007942783d1da9  vmovaps [rsp+0x70], xmm7
00007942783d1daf  vmovaps [rsp+0x80], xmm8
00007942783d1db8  vmovaps [rsp+0x90], xmm9
00007942783d1dc1  vmovaps [rsp+0xA0], xmm10
00007942783d1dca  vmovaps [rsp+0xB0], xmm11
00007942783d1dd3  vmovaps [rsp+0xC0], xmm12
00007942783d1ddc  vmovaps [rsp+0xD0], xmm13
00007942783d1de5  vmovaps [rsp+0xE0], xmm15
00007942783d1dee  sub rsp, 0x30
00007942783d1df2  movaps [rsp], xmm14
00007942783d1df7  movaps [rsp+0x10], xmm13
00007942783d1dfd  movaps [rsp+0x20], xmm2
00007942783d1e02  lea rdi, [rsp]
00007942783d1e06  mov esi, 0x00
00007942783d1e0b  mov rax, 0x59DDDCBA3530
00007942783d1e15  call rax
00007942783d1e17  movaps xmm14, [rsp]
00007942783d1e1c  add rsp, 0x30
00007942783d1e20  vmovaps xmm0, [rsp]
00007942783d1e25  vmovaps xmm1, [rsp+0x10]
00007942783d1e2b  vmovaps xmm2, [rsp+0x20]
00007942783d1e31  vmovaps xmm3, [rsp+0x30]
00007942783d1e37  vmovaps xmm4, [rsp+0x40]
00007942783d1e3d  vmovaps xmm5, [rsp+0x50]
00007942783d1e43  vmovaps xmm6, [rsp+0x60]
00007942783d1e49  vmovaps xmm7, [rsp+0x70]
00007942783d1e4f  vmovaps xmm8, [rsp+0x80]
00007942783d1e58  vmovaps xmm9, [rsp+0x90]
00007942783d1e61  vmovaps xmm10, [rsp+0xA0]
00007942783d1e6a  vmovaps xmm11, [rsp+0xB0]
00007942783d1e73  vmovaps xmm12, [rsp+0xC0]
00007942783d1e7c  vmovaps xmm13, [rsp+0xD0]
00007942783d1e85  vmovaps xmm15, [rsp+0xE0]
00007942783d1e8e  add rsp, 0xF0
00007942783d1e95  pop r11
00007942783d1e97  pop r10
00007942783d1e99  pop r9
00007942783d1e9b  pop r8
00007942783d1e9d  pop rsi
00007942783d1e9e  pop rdi
00007942783d1e9f  pop rdx
00007942783d1ea0  pop rcx
00007942783d1ea1  pop rax
00007942783d1ea2  add rsp, 0x08
00007942783d1ea6  jmp 0x00007942783CFB24
00007942783d1eab  sub rsp, 0x08
00007942783d1eaf  push rax
00007942783d1eb0  push rcx
00007942783d1eb1  push rdx
00007942783d1eb2  push rdi
00007942783d1eb3  push rsi
00007942783d1eb4  push r8
00007942783d1eb6  push r9
00007942783d1eb8  push r10
00007942783d1eba  push r11
00007942783d1ebc  sub rsp, 0xF0
00007942783d1ec3  vmovaps [rsp], xmm0
00007942783d1ec8  vmovaps [rsp+0x10], xmm2
00007942783d1ece  vmovaps [rsp+0x20], xmm3
00007942783d1ed4  vmovaps [rsp+0x30], xmm4
00007942783d1eda  vmovaps [rsp+0x40], xmm5
00007942783d1ee0  vmovaps [rsp+0x50], xmm6
00007942783d1ee6  vmovaps [rsp+0x60], xmm7
00007942783d1eec  vmovaps [rsp+0x70], xmm8
00007942783d1ef2  vmovaps [rsp+0x80], xmm9
00007942783d1efb  vmovaps [rsp+0x90], xmm10
00007942783d1f04  vmovaps [rsp+0xA0], xmm11
00007942783d1f0d  vmovaps [rsp+0xB0], xmm12
00007942783d1f16  vmovaps [rsp+0xC0], xmm13
00007942783d1f1f  vmovaps [rsp+0xD0], xmm14
00007942783d1f28  vmovaps [rsp+0xE0], xmm15
00007942783d1f31  sub rsp, 0x30
00007942783d1f35  movaps [rsp], xmm1
00007942783d1f39  movaps [rsp+0x10], xmm13
00007942783d1f3f  movaps [rsp+0x20], xmm2
00007942783d1f44  lea rdi, [rsp]
00007942783d1f48  mov esi, 0x00
00007942783d1f4d  mov rax, 0x59DDDCBA3530
00007942783d1f57  call rax
00007942783d1f59  movaps xmm1, [rsp]
00007942783d1f5d  add rsp, 0x30
00007942783d1f61  vmovaps xmm0, [rsp]
00007942783d1f66  vmovaps xmm2, [rsp+0x10]
00007942783d1f6c  vmovaps xmm3, [rsp+0x20]
00007942783d1f72  vmovaps xmm4, [rsp+0x30]
00007942783d1f78  vmovaps xmm5, [rsp+0x40]
00007942783d1f7e  vmovaps xmm6, [rsp+0x50]
00007942783d1f84  vmovaps xmm7, [rsp+0x60]
00007942783d1f8a  vmovaps xmm8, [rsp+0x70]
00007942783d1f90  vmovaps xmm9, [rsp+0x80]
00007942783d1f99  vmovaps xmm10, [rsp+0x90]
00007942783d1fa2  vmovaps xmm11, [rsp+0xA0]
00007942783d1fab  vmovaps xmm12, [rsp+0xB0]
00007942783d1fb4  vmovaps xmm13, [rsp+0xC0]
00007942783d1fbd  vmovaps xmm14, [rsp+0xD0]
00007942783d1fc6  vmovaps xmm15, [rsp+0xE0]
00007942783d1fcf  add rsp, 0xF0
00007942783d1fd6  pop r11
00007942783d1fd8  pop r10
00007942783d1fda  pop r9
00007942783d1fdc  pop r8
00007942783d1fde  pop rsi
00007942783d1fdf  pop rdi
00007942783d1fe0  pop rdx
00007942783d1fe1  pop rcx
00007942783d1fe2  pop rax
00007942783d1fe3  add rsp, 0x08
00007942783d1fe7  jmp 0x00007942783CFB52
00007942783d1fec  sub rsp, 0x08
00007942783d1ff0  push rax
00007942783d1ff1  push rcx
00007942783d1ff2  push rdx
00007942783d1ff3  push rdi
00007942783d1ff4  push rsi
00007942783d1ff5  push r8
00007942783d1ff7  push r9
00007942783d1ff9  push r10
00007942783d1ffb  push r11
00007942783d1ffd  sub rsp, 0xF0
00007942783d2004  vmovaps [rsp], xmm0
00007942783d2009  vmovaps [rsp+0x10], xmm1
00007942783d200f  vmovaps [rsp+0x20], xmm3
00007942783d2015  vmovaps [rsp+0x30], xmm4
00007942783d201b  vmovaps [rsp+0x40], xmm5
00007942783d2021  vmovaps [rsp+0x50], xmm6
00007942783d2027  vmovaps [rsp+0x60], xmm7
00007942783d202d  vmovaps [rsp+0x70], xmm8
00007942783d2033  vmovaps [rsp+0x80], xmm9
00007942783d203c  vmovaps [rsp+0x90], xmm10
00007942783d2045  vmovaps [rsp+0xA0], xmm11
00007942783d204e  vmovaps [rsp+0xB0], xmm12
00007942783d2057  vmovaps [rsp+0xC0], xmm13
00007942783d2060  vmovaps [rsp+0xD0], xmm14
00007942783d2069  vmovaps [rsp+0xE0], xmm15
00007942783d2072  sub rsp, 0x30
00007942783d2076  movaps [rsp], xmm2
00007942783d207a  movaps [rsp+0x10], xmm1
00007942783d207f  movaps [rsp+0x20], xmm13
00007942783d2085  lea rdi, [rsp]
00007942783d2089  mov esi, 0x00
00007942783d208e  mov rax, 0x59DDDCBA3530
00007942783d2098  call rax
00007942783d209a  movaps xmm2, [rsp]
00007942783d209e  add rsp, 0x30
00007942783d20a2  vmovaps xmm0, [rsp]
00007942783d20a7  vmovaps xmm1, [rsp+0x10]
00007942783d20ad  vmovaps xmm3, [rsp+0x20]
00007942783d20b3  vmovaps xmm4, [rsp+0x30]
00007942783d20b9  vmovaps xmm5, [rsp+0x40]
00007942783d20bf  vmovaps xmm6, [rsp+0x50]
00007942783d20c5  vmovaps xmm7, [rsp+0x60]
00007942783d20cb  vmovaps xmm8, [rsp+0x70]
00007942783d20d1  vmovaps xmm9, [rsp+0x80]
00007942783d20da  vmovaps xmm10, [rsp+0x90]
00007942783d20e3  vmovaps xmm11, [rsp+0xA0]
00007942783d20ec  vmovaps xmm12, [rsp+0xB0]
00007942783d20f5  vmovaps xmm13, [rsp+0xC0]
00007942783d20fe  vmovaps xmm14, [rsp+0xD0]
00007942783d2107  vmovaps xmm15, [rsp+0xE0]
00007942783d2110  add rsp, 0xF0
00007942783d2117  pop r11
00007942783d2119  pop r10
00007942783d211b  pop r9
00007942783d211d  pop r8
00007942783d211f  pop rsi
00007942783d2120  pop rdi
00007942783d2121  pop rdx
00007942783d2122  pop rcx
00007942783d2123  pop rax
00007942783d2124  add rsp, 0x08
00007942783d2128  jmp 0x00007942783CFBAB
00007942783d212d  call 0x00007942781FF430
00007942783d2132  jmp 0x00007942783CFBB8
00007942783d2137  sub rsp, 0x08
00007942783d213b  push rax
00007942783d213c  push rcx
00007942783d213d  push rdx
00007942783d213e  push rdi
00007942783d213f  push rsi
00007942783d2140  push r8
00007942783d2142  push r9
00007942783d2144  push r10
00007942783d2146  push r11
00007942783d2148  sub rsp, 0xF0
00007942783d214f  vmovaps [rsp], xmm0
00007942783d2154  vmovaps [rsp+0x10], xmm1
00007942783d215a  vmovaps [rsp+0x20], xmm2
00007942783d2160  vmovaps [rsp+0x30], xmm3
00007942783d2166  vmovaps [rsp+0x40], xmm4
00007942783d216c  vmovaps [rsp+0x50], xmm5
00007942783d2172  vmovaps [rsp+0x60], xmm6
00007942783d2178  vmovaps [rsp+0x70], xmm7
00007942783d217e  vmovaps [rsp+0x80], xmm8
00007942783d2187  vmovaps [rsp+0x90], xmm9
00007942783d2190  vmovaps [rsp+0xA0], xmm10
00007942783d2199  vmovaps [rsp+0xB0], xmm11
00007942783d21a2  vmovaps [rsp+0xC0], xmm12
00007942783d21ab  vmovaps [rsp+0xD0], xmm13
00007942783d21b4  vmovaps [rsp+0xE0], xmm14
00007942783d21bd  sub rsp, 0x30
00007942783d21c1  movaps [rsp], xmm15
00007942783d21c6  movaps [rsp+0x10], xmm13
00007942783d21cc  movaps [rsp+0x20], xmm1
00007942783d21d1  lea rdi, [rsp]
00007942783d21d5  mov esi, 0x00
00007942783d21da  mov rax, 0x59DDDCBA3530
00007942783d21e4  call rax
00007942783d21e6  movaps xmm15, [rsp]
00007942783d21eb  add rsp, 0x30
00007942783d21ef  vmovaps xmm0, [rsp]
00007942783d21f4  vmovaps xmm1, [rsp+0x10]
00007942783d21fa  vmovaps xmm2, [rsp+0x20]
00007942783d2200  vmovaps xmm3, [rsp+0x30]
00007942783d2206  vmovaps xmm4, [rsp+0x40]
00007942783d220c  vmovaps xmm5, [rsp+0x50]
00007942783d2212  vmovaps xmm6, [rsp+0x60]
00007942783d2218  vmovaps xmm7, [rsp+0x70]
00007942783d221e  vmovaps xmm8, [rsp+0x80]
00007942783d2227  vmovaps xmm9, [rsp+0x90]
00007942783d2230  vmovaps xmm10, [rsp+0xA0]
00007942783d2239  vmovaps xmm11, [rsp+0xB0]
00007942783d2242  vmovaps xmm12, [rsp+0xC0]
00007942783d224b  vmovaps xmm13, [rsp+0xD0]
00007942783d2254  vmovaps xmm14, [rsp+0xE0]
00007942783d225d  add rsp, 0xF0
00007942783d2264  pop r11
00007942783d2266  pop r10
00007942783d2268  pop r9
00007942783d226a  pop r8
00007942783d226c  pop rsi
00007942783d226d  pop rdi
00007942783d226e  pop rdx
00007942783d226f  pop rcx
00007942783d2270  pop rax
00007942783d2271  add rsp, 0x08
00007942783d2275  jmp 0x00007942783CFBF7
00007942783d227a  sub rsp, 0x08
00007942783d227e  push rax
00007942783d227f  push rcx
00007942783d2280  push rdx
00007942783d2281  push rdi
00007942783d2282  push rsi
00007942783d2283  push r8
00007942783d2285  push r9
00007942783d2287  push r10
00007942783d2289  push r11
00007942783d228b  sub rsp, 0xF0
00007942783d2292  vmovaps [rsp], xmm0
00007942783d2297  vmovaps [rsp+0x10], xmm1
00007942783d229d  vmovaps [rsp+0x20], xmm2
00007942783d22a3  vmovaps [rsp+0x30], xmm3
00007942783d22a9  vmovaps [rsp+0x40], xmm4
00007942783d22af  vmovaps [rsp+0x50], xmm5
00007942783d22b5  vmovaps [rsp+0x60], xmm6
00007942783d22bb  vmovaps [rsp+0x70], xmm7
00007942783d22c1  vmovaps [rsp+0x80], xmm8
00007942783d22ca  vmovaps [rsp+0x90], xmm9
00007942783d22d3  vmovaps [rsp+0xA0], xmm10
00007942783d22dc  vmovaps [rsp+0xB0], xmm11
00007942783d22e5  vmovaps [rsp+0xC0], xmm12
00007942783d22ee  vmovaps [rsp+0xD0], xmm13
00007942783d22f7  vmovaps [rsp+0xE0], xmm15
00007942783d2300  sub rsp, 0x30
00007942783d2304  movaps [rsp], xmm14
00007942783d2309  movaps [rsp+0x10], xmm11
00007942783d230f  movaps [rsp+0x20], xmm1
00007942783d2314  lea rdi, [rsp]
00007942783d2318  mov esi, 0x00
00007942783d231d  mov rax, 0x59DDDCBA3530
00007942783d2327  call rax
00007942783d2329  movaps xmm14, [rsp]
00007942783d232e  add rsp, 0x30
00007942783d2332  vmovaps xmm0, [rsp]
00007942783d2337  vmovaps xmm1, [rsp+0x10]
00007942783d233d  vmovaps xmm2, [rsp+0x20]
00007942783d2343  vmovaps xmm3, [rsp+0x30]
00007942783d2349  vmovaps xmm4, [rsp+0x40]
00007942783d234f  vmovaps xmm5, [rsp+0x50]
00007942783d2355  vmovaps xmm6, [rsp+0x60]
00007942783d235b  vmovaps xmm7, [rsp+0x70]
00007942783d2361  vmovaps xmm8, [rsp+0x80]
00007942783d236a  vmovaps xmm9, [rsp+0x90]
00007942783d2373  vmovaps xmm10, [rsp+0xA0]
00007942783d237c  vmovaps xmm11, [rsp+0xB0]
00007942783d2385  vmovaps xmm12, [rsp+0xC0]
00007942783d238e  vmovaps xmm13, [rsp+0xD0]
00007942783d2397  vmovaps xmm15, [rsp+0xE0]
00007942783d23a0  add rsp, 0xF0
00007942783d23a7  pop r11
00007942783d23a9  pop r10
00007942783d23ab  pop r9
00007942783d23ad  pop r8
00007942783d23af  pop rsi
00007942783d23b0  pop rdi
00007942783d23b1  pop rdx
00007942783d23b2  pop rcx
00007942783d23b3  pop rax
00007942783d23b4  add rsp, 0x08
00007942783d23b8  jmp 0x00007942783CFC21
00007942783d23bd  sub rsp, 0x08
00007942783d23c1  push rax
00007942783d23c2  push rcx
00007942783d23c3  push rdx
00007942783d23c4  push rdi
00007942783d23c5  push rsi
00007942783d23c6  push r8
00007942783d23c8  push r9
00007942783d23ca  push r10
00007942783d23cc  push r11
00007942783d23ce  sub rsp, 0xF0
00007942783d23d5  vmovaps [rsp], xmm0
00007942783d23da  vmovaps [rsp+0x10], xmm1
00007942783d23e0  vmovaps [rsp+0x20], xmm2
00007942783d23e6  vmovaps [rsp+0x30], xmm3
00007942783d23ec  vmovaps [rsp+0x40], xmm4
00007942783d23f2  vmovaps [rsp+0x50], xmm5
00007942783d23f8  vmovaps [rsp+0x60], xmm6
00007942783d23fe  vmovaps [rsp+0x70], xmm7
00007942783d2404  vmovaps [rsp+0x80], xmm8
00007942783d240d  vmovaps [rsp+0x90], xmm9
00007942783d2416  vmovaps [rsp+0xA0], xmm10
00007942783d241f  vmovaps [rsp+0xB0], xmm11
00007942783d2428  vmovaps [rsp+0xC0], xmm12
00007942783d2431  vmovaps [rsp+0xD0], xmm14
00007942783d243a  vmovaps [rsp+0xE0], xmm15
00007942783d2443  sub rsp, 0x30
00007942783d2447  movaps [rsp], xmm13
00007942783d244c  movaps [rsp+0x10], xmm11
00007942783d2452  movaps [rsp+0x20], xmm1
00007942783d2457  lea rdi, [rsp]
00007942783d245b  mov esi, 0x00
00007942783d2460  mov rax, 0x59DDDCBA3530
00007942783d246a  call rax
00007942783d246c  movaps xmm13, [rsp]
00007942783d2471  add rsp, 0x30
00007942783d2475  vmovaps xmm0, [rsp]
00007942783d247a  vmovaps xmm1, [rsp+0x10]
00007942783d2480  vmovaps xmm2, [rsp+0x20]
00007942783d2486  vmovaps xmm3, [rsp+0x30]
00007942783d248c  vmovaps xmm4, [rsp+0x40]
00007942783d2492  vmovaps xmm5, [rsp+0x50]
00007942783d2498  vmovaps xmm6, [rsp+0x60]
00007942783d249e  vmovaps xmm7, [rsp+0x70]
00007942783d24a4  vmovaps xmm8, [rsp+0x80]
00007942783d24ad  vmovaps xmm9, [rsp+0x90]
00007942783d24b6  vmovaps xmm10, [rsp+0xA0]
00007942783d24bf  vmovaps xmm11, [rsp+0xB0]
00007942783d24c8  vmovaps xmm12, [rsp+0xC0]
00007942783d24d1  vmovaps xmm14, [rsp+0xD0]
00007942783d24da  vmovaps xmm15, [rsp+0xE0]
00007942783d24e3  add rsp, 0xF0
00007942783d24ea  pop r11
00007942783d24ec  pop r10
00007942783d24ee  pop r9
00007942783d24f0  pop r8
00007942783d24f2  pop rsi
00007942783d24f3  pop rdi
00007942783d24f4  pop rdx
00007942783d24f5  pop rcx
00007942783d24f6  pop rax
00007942783d24f7  add rsp, 0x08
00007942783d24fb  jmp 0x00007942783CFC76
00007942783d2500  call 0x00007942781FF430
00007942783d2505  jmp 0x00007942783CFC83
00007942783d250a  sub rsp, 0x08
00007942783d250e  push rax
00007942783d250f  push rcx
00007942783d2510  push rdx
00007942783d2511  push rdi
00007942783d2512  push rsi
00007942783d2513  push r8
00007942783d2515  push r9
00007942783d2517  push r10
00007942783d2519  push r11
00007942783d251b  sub rsp, 0xF0
00007942783d2522  vmovaps [rsp], xmm0
00007942783d2527  vmovaps [rsp+0x10], xmm1
00007942783d252d  vmovaps [rsp+0x20], xmm2
00007942783d2533  vmovaps [rsp+0x30], xmm3
00007942783d2539  vmovaps [rsp+0x40], xmm4
00007942783d253f  vmovaps [rsp+0x50], xmm5
00007942783d2545  vmovaps [rsp+0x60], xmm6
00007942783d254b  vmovaps [rsp+0x70], xmm7
00007942783d2551  vmovaps [rsp+0x80], xmm8
00007942783d255a  vmovaps [rsp+0x90], xmm9
00007942783d2563  vmovaps [rsp+0xA0], xmm10
00007942783d256c  vmovaps [rsp+0xB0], xmm11
00007942783d2575  vmovaps [rsp+0xC0], xmm12
00007942783d257e  vmovaps [rsp+0xD0], xmm13
00007942783d2587  vmovaps [rsp+0xE0], xmm14
00007942783d2590  sub rsp, 0x30
00007942783d2594  movaps [rsp], xmm15
00007942783d2599  movaps [rsp+0x10], xmm11
00007942783d259f  movaps [rsp+0x20], xmm1
00007942783d25a4  lea rdi, [rsp]
00007942783d25a8  mov esi, 0x00
00007942783d25ad  mov rax, 0x59DDDCBA3530
00007942783d25b7  call rax
00007942783d25b9  movaps xmm15, [rsp]
00007942783d25be  add rsp, 0x30
00007942783d25c2  vmovaps xmm0, [rsp]
00007942783d25c7  vmovaps xmm1, [rsp+0x10]
00007942783d25cd  vmovaps xmm2, [rsp+0x20]
00007942783d25d3  vmovaps xmm3, [rsp+0x30]
00007942783d25d9  vmovaps xmm4, [rsp+0x40]
00007942783d25df  vmovaps xmm5, [rsp+0x50]
00007942783d25e5  vmovaps xmm6, [rsp+0x60]
00007942783d25eb  vmovaps xmm7, [rsp+0x70]
00007942783d25f1  vmovaps xmm8, [rsp+0x80]
00007942783d25fa  vmovaps xmm9, [rsp+0x90]
00007942783d2603  vmovaps xmm10, [rsp+0xA0]
00007942783d260c  vmovaps xmm11, [rsp+0xB0]
00007942783d2615  vmovaps xmm12, [rsp+0xC0]
00007942783d261e  vmovaps xmm13, [rsp+0xD0]
00007942783d2627  vmovaps xmm14, [rsp+0xE0]
00007942783d2630  add rsp, 0xF0
00007942783d2637  pop r11
00007942783d2639  pop r10
00007942783d263b  pop r9
00007942783d263d  pop r8
00007942783d263f  pop rsi
00007942783d2640  pop rdi
00007942783d2641  pop rdx
00007942783d2642  pop rcx
00007942783d2643  pop rax
00007942783d2644  add rsp, 0x08
00007942783d2648  jmp 0x00007942783CFCBC
00007942783d264d  sub rsp, 0x08
00007942783d2651  push rax
00007942783d2652  push rcx
00007942783d2653  push rdx
00007942783d2654  push rdi
00007942783d2655  push rsi
00007942783d2656  push r8
00007942783d2658  push r9
00007942783d265a  push r10
00007942783d265c  push r11
00007942783d265e  sub rsp, 0xF0
00007942783d2665  vmovaps [rsp], xmm0
00007942783d266a  vmovaps [rsp+0x10], xmm1
00007942783d2670  vmovaps [rsp+0x20], xmm2
00007942783d2676  vmovaps [rsp+0x30], xmm3
00007942783d267c  vmovaps [rsp+0x40], xmm4
00007942783d2682  vmovaps [rsp+0x50], xmm5
00007942783d2688  vmovaps [rsp+0x60], xmm6
00007942783d268e  vmovaps [rsp+0x70], xmm7
00007942783d2694  vmovaps [rsp+0x80], xmm8
00007942783d269d  vmovaps [rsp+0x90], xmm9
00007942783d26a6  vmovaps [rsp+0xA0], xmm10
00007942783d26af  vmovaps [rsp+0xB0], xmm12
00007942783d26b8  vmovaps [rsp+0xC0], xmm13
00007942783d26c1  vmovaps [rsp+0xD0], xmm14
00007942783d26ca  vmovaps [rsp+0xE0], xmm15
00007942783d26d3  sub rsp, 0x30
00007942783d26d7  movaps [rsp], xmm11
00007942783d26dc  movaps [rsp+0x10], xmm6
00007942783d26e1  movaps [rsp+0x20], xmm14
00007942783d26e7  lea rdi, [rsp]
00007942783d26eb  mov esi, 0x00
00007942783d26f0  mov rax, 0x59DDDCBA3530
00007942783d26fa  call rax
00007942783d26fc  movaps xmm11, [rsp]
00007942783d2701  add rsp, 0x30
00007942783d2705  vmovaps xmm0, [rsp]
00007942783d270a  vmovaps xmm1, [rsp+0x10]
00007942783d2710  vmovaps xmm2, [rsp+0x20]
00007942783d2716  vmovaps xmm3, [rsp+0x30]
00007942783d271c  vmovaps xmm4, [rsp+0x40]
00007942783d2722  vmovaps xmm5, [rsp+0x50]
00007942783d2728  vmovaps xmm6, [rsp+0x60]
00007942783d272e  vmovaps xmm7, [rsp+0x70]
00007942783d2734  vmovaps xmm8, [rsp+0x80]
00007942783d273d  vmovaps xmm9, [rsp+0x90]
00007942783d2746  vmovaps xmm10, [rsp+0xA0]
00007942783d274f  vmovaps xmm12, [rsp+0xB0]
00007942783d2758  vmovaps xmm13, [rsp+0xC0]
00007942783d2761  vmovaps xmm14, [rsp+0xD0]
00007942783d276a  vmovaps xmm15, [rsp+0xE0]
00007942783d2773  add rsp, 0xF0
00007942783d277a  pop r11
00007942783d277c  pop r10
00007942783d277e  pop r9
00007942783d2780  pop r8
00007942783d2782  pop rsi
00007942783d2783  pop rdi
00007942783d2784  pop rdx
00007942783d2785  pop rcx
00007942783d2786  pop rax
00007942783d2787  add rsp, 0x08
00007942783d278b  jmp 0x00007942783CFD34
00007942783d2790  call 0x00007942781FF430
00007942783d2795  jmp 0x00007942783CFD3E
00007942783d279a  sub rsp, 0x08
00007942783d279e  push rax
00007942783d279f  push rcx
00007942783d27a0  push rdx
00007942783d27a1  push rdi
00007942783d27a2  push rsi
00007942783d27a3  push r8
00007942783d27a5  push r9
00007942783d27a7  push r10
00007942783d27a9  push r11
00007942783d27ab  sub rsp, 0xF0
00007942783d27b2  vmovaps [rsp], xmm0
00007942783d27b7  vmovaps [rsp+0x10], xmm1
00007942783d27bd  vmovaps [rsp+0x20], xmm2
00007942783d27c3  vmovaps [rsp+0x30], xmm3
00007942783d27c9  vmovaps [rsp+0x40], xmm4
00007942783d27cf  vmovaps [rsp+0x50], xmm5
00007942783d27d5  vmovaps [rsp+0x60], xmm6
00007942783d27db  vmovaps [rsp+0x70], xmm7
00007942783d27e1  vmovaps [rsp+0x80], xmm8
00007942783d27ea  vmovaps [rsp+0x90], xmm9
00007942783d27f3  vmovaps [rsp+0xA0], xmm10
00007942783d27fc  vmovaps [rsp+0xB0], xmm11
00007942783d2805  vmovaps [rsp+0xC0], xmm12
00007942783d280e  vmovaps [rsp+0xD0], xmm13
00007942783d2817  vmovaps [rsp+0xE0], xmm15
00007942783d2820  sub rsp, 0x30
00007942783d2824  movaps [rsp], xmm14
00007942783d2829  movaps [rsp+0x10], xmm6
00007942783d282e  movaps [rsp+0x20], xmm2
00007942783d2833  lea rdi, [rsp]
00007942783d2837  mov esi, 0x00
00007942783d283c  mov rax, 0x59DDDCBA3530
00007942783d2846  call rax
00007942783d2848  movaps xmm14, [rsp]
00007942783d284d  add rsp, 0x30
00007942783d2851  vmovaps xmm0, [rsp]
00007942783d2856  vmovaps xmm1, [rsp+0x10]
00007942783d285c  vmovaps xmm2, [rsp+0x20]
00007942783d2862  vmovaps xmm3, [rsp+0x30]
00007942783d2868  vmovaps xmm4, [rsp+0x40]
00007942783d286e  vmovaps xmm5, [rsp+0x50]
00007942783d2874  vmovaps xmm6, [rsp+0x60]
00007942783d287a  vmovaps xmm7, [rsp+0x70]
00007942783d2880  vmovaps xmm8, [rsp+0x80]
00007942783d2889  vmovaps xmm9, [rsp+0x90]
00007942783d2892  vmovaps xmm10, [rsp+0xA0]
00007942783d289b  vmovaps xmm11, [rsp+0xB0]
00007942783d28a4  vmovaps xmm12, [rsp+0xC0]
00007942783d28ad  vmovaps xmm13, [rsp+0xD0]
00007942783d28b6  vmovaps xmm15, [rsp+0xE0]
00007942783d28bf  add rsp, 0xF0
00007942783d28c6  pop r11
00007942783d28c8  pop r10
00007942783d28ca  pop r9
00007942783d28cc  pop r8
00007942783d28ce  pop rsi
00007942783d28cf  pop rdi
00007942783d28d0  pop rdx
00007942783d28d1  pop rcx
00007942783d28d2  pop rax
00007942783d28d3  add rsp, 0x08
00007942783d28d7  jmp 0x00007942783CFD72
00007942783d28dc  sub rsp, 0x08
00007942783d28e0  push rax
00007942783d28e1  push rcx
00007942783d28e2  push rdx
00007942783d28e3  push rdi
00007942783d28e4  push rsi
00007942783d28e5  push r8
00007942783d28e7  push r9
00007942783d28e9  push r10
00007942783d28eb  push r11
00007942783d28ed  sub rsp, 0xF0
00007942783d28f4  vmovaps [rsp], xmm0
00007942783d28f9  vmovaps [rsp+0x10], xmm1
00007942783d28ff  vmovaps [rsp+0x20], xmm2
00007942783d2905  vmovaps [rsp+0x30], xmm3
00007942783d290b  vmovaps [rsp+0x40], xmm4
00007942783d2911  vmovaps [rsp+0x50], xmm5
00007942783d2917  vmovaps [rsp+0x60], xmm7
00007942783d291d  vmovaps [rsp+0x70], xmm8
00007942783d2923  vmovaps [rsp+0x80], xmm9
00007942783d292c  vmovaps [rsp+0x90], xmm10
00007942783d2935  vmovaps [rsp+0xA0], xmm11
00007942783d293e  vmovaps [rsp+0xB0], xmm12
00007942783d2947  vmovaps [rsp+0xC0], xmm13
00007942783d2950  vmovaps [rsp+0xD0], xmm14
00007942783d2959  vmovaps [rsp+0xE0], xmm15
00007942783d2962  sub rsp, 0x30
00007942783d2966  movaps [rsp], xmm6
00007942783d296a  movaps [rsp+0x10], xmm5
00007942783d296f  movaps [rsp+0x20], xmm1
00007942783d2974  lea rdi, [rsp]
00007942783d2978  mov esi, 0x00
00007942783d297d  mov rax, 0x59DDDCBA3530
00007942783d2987  call rax
00007942783d2989  movaps xmm6, [rsp]
00007942783d298d  add rsp, 0x30
00007942783d2991  vmovaps xmm0, [rsp]
00007942783d2996  vmovaps xmm1, [rsp+0x10]
00007942783d299c  vmovaps xmm2, [rsp+0x20]
00007942783d29a2  vmovaps xmm3, [rsp+0x30]
00007942783d29a8  vmovaps xmm4, [rsp+0x40]
00007942783d29ae  vmovaps xmm5, [rsp+0x50]
00007942783d29b4  vmovaps xmm7, [rsp+0x60]
00007942783d29ba  vmovaps xmm8, [rsp+0x70]
00007942783d29c0  vmovaps xmm9, [rsp+0x80]
00007942783d29c9  vmovaps xmm10, [rsp+0x90]
00007942783d29d2  vmovaps xmm11, [rsp+0xA0]
00007942783d29db  vmovaps xmm12, [rsp+0xB0]
00007942783d29e4  vmovaps xmm13, [rsp+0xC0]
00007942783d29ed  vmovaps xmm14, [rsp+0xD0]
00007942783d29f6  vmovaps xmm15, [rsp+0xE0]
00007942783d29ff  add rsp, 0xF0
00007942783d2a06  pop r11
00007942783d2a08  pop r10
00007942783d2a0a  pop r9
00007942783d2a0c  pop r8
00007942783d2a0e  pop rsi
00007942783d2a0f  pop rdi
00007942783d2a10  pop rdx
00007942783d2a11  pop rcx
00007942783d2a12  pop rax
00007942783d2a13  add rsp, 0x08
00007942783d2a17  jmp 0x00007942783CFD98
00007942783d2a1c  sub rsp, 0x08
00007942783d2a20  push rax
00007942783d2a21  push rcx
00007942783d2a22  push rdx
00007942783d2a23  push rdi
00007942783d2a24  push rsi
00007942783d2a25  push r8
00007942783d2a27  push r9
00007942783d2a29  push r10
00007942783d2a2b  push r11
00007942783d2a2d  sub rsp, 0xF0
00007942783d2a34  vmovaps [rsp], xmm0
00007942783d2a39  vmovaps [rsp+0x10], xmm2
00007942783d2a3f  vmovaps [rsp+0x20], xmm3
00007942783d2a45  vmovaps [rsp+0x30], xmm4
00007942783d2a4b  vmovaps [rsp+0x40], xmm5
00007942783d2a51  vmovaps [rsp+0x50], xmm6
00007942783d2a57  vmovaps [rsp+0x60], xmm7
00007942783d2a5d  vmovaps [rsp+0x70], xmm8
00007942783d2a63  vmovaps [rsp+0x80], xmm9
00007942783d2a6c  vmovaps [rsp+0x90], xmm10
00007942783d2a75  vmovaps [rsp+0xA0], xmm11
00007942783d2a7e  vmovaps [rsp+0xB0], xmm12
00007942783d2a87  vmovaps [rsp+0xC0], xmm13
00007942783d2a90  vmovaps [rsp+0xD0], xmm14
00007942783d2a99  vmovaps [rsp+0xE0], xmm15
00007942783d2aa2  sub rsp, 0x30
00007942783d2aa6  movaps [rsp], xmm1
00007942783d2aaa  movaps [rsp+0x10], xmm5
00007942783d2aaf  movaps [rsp+0x20], xmm13
00007942783d2ab5  lea rdi, [rsp]
00007942783d2ab9  mov esi, 0x00
00007942783d2abe  mov rax, 0x59DDDCBA3530
00007942783d2ac8  call rax
00007942783d2aca  movaps xmm1, [rsp]
00007942783d2ace  add rsp, 0x30
00007942783d2ad2  vmovaps xmm0, [rsp]
00007942783d2ad7  vmovaps xmm2, [rsp+0x10]
00007942783d2add  vmovaps xmm3, [rsp+0x20]
00007942783d2ae3  vmovaps xmm4, [rsp+0x30]
00007942783d2ae9  vmovaps xmm5, [rsp+0x40]
00007942783d2aef  vmovaps xmm6, [rsp+0x50]
00007942783d2af5  vmovaps xmm7, [rsp+0x60]
00007942783d2afb  vmovaps xmm8, [rsp+0x70]
00007942783d2b01  vmovaps xmm9, [rsp+0x80]
00007942783d2b0a  vmovaps xmm10, [rsp+0x90]
00007942783d2b13  vmovaps xmm11, [rsp+0xA0]
00007942783d2b1c  vmovaps xmm12, [rsp+0xB0]
00007942783d2b25  vmovaps xmm13, [rsp+0xC0]
00007942783d2b2e  vmovaps xmm14, [rsp+0xD0]
00007942783d2b37  vmovaps xmm15, [rsp+0xE0]
00007942783d2b40  add rsp, 0xF0
00007942783d2b47  pop r11
00007942783d2b49  pop r10
00007942783d2b4b  pop r9
00007942783d2b4d  pop r8
00007942783d2b4f  pop rsi
00007942783d2b50  pop rdi
00007942783d2b51  pop rdx
00007942783d2b52  pop rcx
00007942783d2b53  pop rax
00007942783d2b54  add rsp, 0x08
00007942783d2b58  jmp 0x00007942783CFDB6
00007942783d2b5d  sub rsp, 0x08
00007942783d2b61  push rax
00007942783d2b62  push rcx
00007942783d2b63  push rdx
00007942783d2b64  push rdi
00007942783d2b65  push rsi
00007942783d2b66  push r8
00007942783d2b68  push r9
00007942783d2b6a  push r10
00007942783d2b6c  push r11
00007942783d2b6e  sub rsp, 0xF0
00007942783d2b75  vmovaps [rsp], xmm0
00007942783d2b7a  vmovaps [rsp+0x10], xmm1
00007942783d2b80  vmovaps [rsp+0x20], xmm2
00007942783d2b86  vmovaps [rsp+0x30], xmm3
00007942783d2b8c  vmovaps [rsp+0x40], xmm4
00007942783d2b92  vmovaps [rsp+0x50], xmm6
00007942783d2b98  vmovaps [rsp+0x60], xmm7
00007942783d2b9e  vmovaps [rsp+0x70], xmm8
00007942783d2ba4  vmovaps [rsp+0x80], xmm9
00007942783d2bad  vmovaps [rsp+0x90], xmm10
00007942783d2bb6  vmovaps [rsp+0xA0], xmm11
00007942783d2bbf  vmovaps [rsp+0xB0], xmm12
00007942783d2bc8  vmovaps [rsp+0xC0], xmm13
00007942783d2bd1  vmovaps [rsp+0xD0], xmm14
00007942783d2bda  vmovaps [rsp+0xE0], xmm15
00007942783d2be3  sub rsp, 0x30
00007942783d2be7  movaps [rsp], xmm5
00007942783d2beb  movaps [rsp+0x10], xmm2
00007942783d2bf0  movaps [rsp+0x20], xmm13
00007942783d2bf6  lea rdi, [rsp]
00007942783d2bfa  mov esi, 0x00
00007942783d2bff  mov rax, 0x59DDDCBA3530
00007942783d2c09  call rax
00007942783d2c0b  movaps xmm5, [rsp]
00007942783d2c0f  add rsp, 0x30
00007942783d2c13  vmovaps xmm0, [rsp]
00007942783d2c18  vmovaps xmm1, [rsp+0x10]
00007942783d2c1e  vmovaps xmm2, [rsp+0x20]
00007942783d2c24  vmovaps xmm3, [rsp+0x30]
00007942783d2c2a  vmovaps xmm4, [rsp+0x40]
00007942783d2c30  vmovaps xmm6, [rsp+0x50]
00007942783d2c36  vmovaps xmm7, [rsp+0x60]
00007942783d2c3c  vmovaps xmm8, [rsp+0x70]
00007942783d2c42  vmovaps xmm9, [rsp+0x80]
00007942783d2c4b  vmovaps xmm10, [rsp+0x90]
00007942783d2c54  vmovaps xmm11, [rsp+0xA0]
00007942783d2c5d  vmovaps xmm12, [rsp+0xB0]
00007942783d2c66  vmovaps xmm13, [rsp+0xC0]
00007942783d2c6f  vmovaps xmm14, [rsp+0xD0]
00007942783d2c78  vmovaps xmm15, [rsp+0xE0]
00007942783d2c81  add rsp, 0xF0
00007942783d2c88  pop r11
00007942783d2c8a  pop r10
00007942783d2c8c  pop r9
00007942783d2c8e  pop r8
00007942783d2c90  pop rsi
00007942783d2c91  pop rdi
00007942783d2c92  pop rdx
00007942783d2c93  pop rcx
00007942783d2c94  pop rax
00007942783d2c95  add rsp, 0x08
00007942783d2c99  jmp 0x00007942783CFDEC
00007942783d2c9e  sub rsp, 0x08
00007942783d2ca2  push rax
00007942783d2ca3  push rcx
00007942783d2ca4  push rdx
00007942783d2ca5  push rdi
00007942783d2ca6  push rsi
00007942783d2ca7  push r8
00007942783d2ca9  push r9
00007942783d2cab  push r10
00007942783d2cad  push r11
00007942783d2caf  sub rsp, 0xF0
00007942783d2cb6  vmovaps [rsp], xmm0
00007942783d2cbb  vmovaps [rsp+0x10], xmm1
00007942783d2cc1  vmovaps [rsp+0x20], xmm2
00007942783d2cc7  vmovaps [rsp+0x30], xmm3
00007942783d2ccd  vmovaps [rsp+0x40], xmm4
00007942783d2cd3  vmovaps [rsp+0x50], xmm5
00007942783d2cd9  vmovaps [rsp+0x60], xmm6
00007942783d2cdf  vmovaps [rsp+0x70], xmm7
00007942783d2ce5  vmovaps [rsp+0x80], xmm8
00007942783d2cee  vmovaps [rsp+0x90], xmm9
00007942783d2cf7  vmovaps [rsp+0xA0], xmm10
00007942783d2d00  vmovaps [rsp+0xB0], xmm11
00007942783d2d09  vmovaps [rsp+0xC0], xmm12
00007942783d2d12  vmovaps [rsp+0xD0], xmm14
00007942783d2d1b  vmovaps [rsp+0xE0], xmm15
00007942783d2d24  sub rsp, 0x30
00007942783d2d28  movaps [rsp], xmm13
00007942783d2d2d  movaps [rsp+0x10], xmm10
00007942783d2d33  movaps [rsp+0x20], xmm1
00007942783d2d38  lea rdi, [rsp]
00007942783d2d3c  mov esi, 0x00
00007942783d2d41  mov rax, 0x59DDDCBA3530
00007942783d2d4b  call rax
00007942783d2d4d  movaps xmm13, [rsp]
00007942783d2d52  add rsp, 0x30
00007942783d2d56  vmovaps xmm0, [rsp]
00007942783d2d5b  vmovaps xmm1, [rsp+0x10]
00007942783d2d61  vmovaps xmm2, [rsp+0x20]
00007942783d2d67  vmovaps xmm3, [rsp+0x30]
00007942783d2d6d  vmovaps xmm4, [rsp+0x40]
00007942783d2d73  vmovaps xmm5, [rsp+0x50]
00007942783d2d79  vmovaps xmm6, [rsp+0x60]
00007942783d2d7f  vmovaps xmm7, [rsp+0x70]
00007942783d2d85  vmovaps xmm8, [rsp+0x80]
00007942783d2d8e  vmovaps xmm9, [rsp+0x90]
00007942783d2d97  vmovaps xmm10, [rsp+0xA0]
00007942783d2da0  vmovaps xmm11, [rsp+0xB0]
00007942783d2da9  vmovaps xmm12, [rsp+0xC0]
00007942783d2db2  vmovaps xmm14, [rsp+0xD0]
00007942783d2dbb  vmovaps xmm15, [rsp+0xE0]
00007942783d2dc4  add rsp, 0xF0
00007942783d2dcb  pop r11
00007942783d2dcd  pop r10
00007942783d2dcf  pop r9
00007942783d2dd1  pop r8
00007942783d2dd3  pop rsi
00007942783d2dd4  pop rdi
00007942783d2dd5  pop rdx
00007942783d2dd6  pop rcx
00007942783d2dd7  pop rax
00007942783d2dd8  add rsp, 0x08
00007942783d2ddc  jmp 0x00007942783CFE15
00007942783d2de1  sub rsp, 0x08
00007942783d2de5  push rax
00007942783d2de6  push rcx
00007942783d2de7  push rdx
00007942783d2de8  push rdi
00007942783d2de9  push rsi
00007942783d2dea  push r8
00007942783d2dec  push r9
00007942783d2dee  push r10
00007942783d2df0  push r11
00007942783d2df2  sub rsp, 0xF0
00007942783d2df9  vmovaps [rsp], xmm0
00007942783d2dfe  vmovaps [rsp+0x10], xmm2
00007942783d2e04  vmovaps [rsp+0x20], xmm3
00007942783d2e0a  vmovaps [rsp+0x30], xmm4
00007942783d2e10  vmovaps [rsp+0x40], xmm5
00007942783d2e16  vmovaps [rsp+0x50], xmm6
00007942783d2e1c  vmovaps [rsp+0x60], xmm7
00007942783d2e22  vmovaps [rsp+0x70], xmm8
00007942783d2e28  vmovaps [rsp+0x80], xmm9
00007942783d2e31  vmovaps [rsp+0x90], xmm10
00007942783d2e3a  vmovaps [rsp+0xA0], xmm11
00007942783d2e43  vmovaps [rsp+0xB0], xmm12
00007942783d2e4c  vmovaps [rsp+0xC0], xmm13
00007942783d2e55  vmovaps [rsp+0xD0], xmm14
00007942783d2e5e  vmovaps [rsp+0xE0], xmm15
00007942783d2e67  sub rsp, 0x30
00007942783d2e6b  movaps [rsp], xmm1
00007942783d2e6f  movaps [rsp+0x10], xmm15
00007942783d2e75  movaps [rsp+0x20], xmm10
00007942783d2e7b  lea rdi, [rsp]
00007942783d2e7f  mov esi, 0x00
00007942783d2e84  mov rax, 0x59DDDCBA3530
00007942783d2e8e  call rax
00007942783d2e90  movaps xmm1, [rsp]
00007942783d2e94  add rsp, 0x30
00007942783d2e98  vmovaps xmm0, [rsp]
00007942783d2e9d  vmovaps xmm2, [rsp+0x10]
00007942783d2ea3  vmovaps xmm3, [rsp+0x20]
00007942783d2ea9  vmovaps xmm4, [rsp+0x30]
00007942783d2eaf  vmovaps xmm5, [rsp+0x40]
00007942783d2eb5  vmovaps xmm6, [rsp+0x50]
00007942783d2ebb  vmovaps xmm7, [rsp+0x60]
00007942783d2ec1  vmovaps xmm8, [rsp+0x70]
00007942783d2ec7  vmovaps xmm9, [rsp+0x80]
00007942783d2ed0  vmovaps xmm10, [rsp+0x90]
00007942783d2ed9  vmovaps xmm11, [rsp+0xA0]
00007942783d2ee2  vmovaps xmm12, [rsp+0xB0]
00007942783d2eeb  vmovaps xmm13, [rsp+0xC0]
00007942783d2ef4  vmovaps xmm14, [rsp+0xD0]
00007942783d2efd  vmovaps xmm15, [rsp+0xE0]
00007942783d2f06  add rsp, 0xF0
00007942783d2f0d  pop r11
00007942783d2f0f  pop r10
00007942783d2f11  pop r9
00007942783d2f13  pop r8
00007942783d2f15  pop rsi
00007942783d2f16  pop rdi
00007942783d2f17  pop rdx
00007942783d2f18  pop rcx
00007942783d2f19  pop rax
00007942783d2f1a  add rsp, 0x08
00007942783d2f1e  jmp 0x00007942783CFE34
00007942783d2f23  sub rsp, 0x08
00007942783d2f27  push rax
00007942783d2f28  push rcx
00007942783d2f29  push rdx
00007942783d2f2a  push rdi
00007942783d2f2b  push rsi
00007942783d2f2c  push r8
00007942783d2f2e  push r9
00007942783d2f30  push r10
00007942783d2f32  push r11
00007942783d2f34  sub rsp, 0xF0
00007942783d2f3b  vmovaps [rsp], xmm0
00007942783d2f40  vmovaps [rsp+0x10], xmm1
00007942783d2f46  vmovaps [rsp+0x20], xmm2
00007942783d2f4c  vmovaps [rsp+0x30], xmm3
00007942783d2f52  vmovaps [rsp+0x40], xmm4
00007942783d2f58  vmovaps [rsp+0x50], xmm5
00007942783d2f5e  vmovaps [rsp+0x60], xmm6
00007942783d2f64  vmovaps [rsp+0x70], xmm7
00007942783d2f6a  vmovaps [rsp+0x80], xmm8
00007942783d2f73  vmovaps [rsp+0x90], xmm9
00007942783d2f7c  vmovaps [rsp+0xA0], xmm10
00007942783d2f85  vmovaps [rsp+0xB0], xmm11
00007942783d2f8e  vmovaps [rsp+0xC0], xmm12
00007942783d2f97  vmovaps [rsp+0xD0], xmm13
00007942783d2fa0  vmovaps [rsp+0xE0], xmm14
00007942783d2fa9  sub rsp, 0x30
00007942783d2fad  movaps [rsp], xmm15
00007942783d2fb2  movaps [rsp+0x10], xmm10
00007942783d2fb8  movaps [rsp+0x20], xmm11
00007942783d2fbe  lea rdi, [rsp]
00007942783d2fc2  mov esi, 0x00
00007942783d2fc7  mov rax, 0x59DDDCBA3530
00007942783d2fd1  call rax
00007942783d2fd3  movaps xmm15, [rsp]
00007942783d2fd8  add rsp, 0x30
00007942783d2fdc  vmovaps xmm0, [rsp]
00007942783d2fe1  vmovaps xmm1, [rsp+0x10]
00007942783d2fe7  vmovaps xmm2, [rsp+0x20]
00007942783d2fed  vmovaps xmm3, [rsp+0x30]
00007942783d2ff3  vmovaps xmm4, [rsp+0x40]
00007942783d2ff9  vmovaps xmm5, [rsp+0x50]
00007942783d2fff  vmovaps xmm6, [rsp+0x60]
00007942783d3005  vmovaps xmm7, [rsp+0x70]
00007942783d300b  vmovaps xmm8, [rsp+0x80]
00007942783d3014  vmovaps xmm9, [rsp+0x90]
00007942783d301d  vmovaps xmm10, [rsp+0xA0]
00007942783d3026  vmovaps xmm11, [rsp+0xB0]
00007942783d302f  vmovaps xmm12, [rsp+0xC0]
00007942783d3038  vmovaps xmm13, [rsp+0xD0]
00007942783d3041  vmovaps xmm14, [rsp+0xE0]
00007942783d304a  add rsp, 0xF0
00007942783d3051  pop r11
00007942783d3053  pop r10
00007942783d3055  pop r9
00007942783d3057  pop r8
00007942783d3059  pop rsi
00007942783d305a  pop rdi
00007942783d305b  pop rdx
00007942783d305c  pop rcx
00007942783d305d  pop rax
00007942783d305e  add rsp, 0x08
00007942783d3062  jmp 0x00007942783CFE57
00007942783d3067  sub rsp, 0x08
00007942783d306b  push rax
00007942783d306c  push rcx
00007942783d306d  push rdx
00007942783d306e  push rdi
00007942783d306f  push rsi
00007942783d3070  push r8
00007942783d3072  push r9
00007942783d3074  push r10
00007942783d3076  push r11
00007942783d3078  sub rsp, 0xF0
00007942783d307f  vmovaps [rsp], xmm0
00007942783d3084  vmovaps [rsp+0x10], xmm1
00007942783d308a  vmovaps [rsp+0x20], xmm2
00007942783d3090  vmovaps [rsp+0x30], xmm3
00007942783d3096  vmovaps [rsp+0x40], xmm4
00007942783d309c  vmovaps [rsp+0x50], xmm5
00007942783d30a2  vmovaps [rsp+0x60], xmm6
00007942783d30a8  vmovaps [rsp+0x70], xmm7
00007942783d30ae  vmovaps [rsp+0x80], xmm8
00007942783d30b7  vmovaps [rsp+0x90], xmm9
00007942783d30c0  vmovaps [rsp+0xA0], xmm11
00007942783d30c9  vmovaps [rsp+0xB0], xmm12
00007942783d30d2  vmovaps [rsp+0xC0], xmm13
00007942783d30db  vmovaps [rsp+0xD0], xmm14
00007942783d30e4  vmovaps [rsp+0xE0], xmm15
00007942783d30ed  sub rsp, 0x30
00007942783d30f1  movaps [rsp], xmm10
00007942783d30f6  movaps [rsp+0x10], xmm12
00007942783d30fc  movaps [rsp+0x20], xmm11
00007942783d3102  lea rdi, [rsp]
00007942783d3106  mov esi, 0x00
00007942783d310b  mov rax, 0x59DDDCBA3530
00007942783d3115  call rax
00007942783d3117  movaps xmm10, [rsp]
00007942783d311c  add rsp, 0x30
00007942783d3120  vmovaps xmm0, [rsp]
00007942783d3125  vmovaps xmm1, [rsp+0x10]
00007942783d312b  vmovaps xmm2, [rsp+0x20]
00007942783d3131  vmovaps xmm3, [rsp+0x30]
00007942783d3137  vmovaps xmm4, [rsp+0x40]
00007942783d313d  vmovaps xmm5, [rsp+0x50]
00007942783d3143  vmovaps xmm6, [rsp+0x60]
00007942783d3149  vmovaps xmm7, [rsp+0x70]
00007942783d314f  vmovaps xmm8, [rsp+0x80]
00007942783d3158  vmovaps xmm9, [rsp+0x90]
00007942783d3161  vmovaps xmm11, [rsp+0xA0]
00007942783d316a  vmovaps xmm12, [rsp+0xB0]
00007942783d3173  vmovaps xmm13, [rsp+0xC0]
00007942783d317c  vmovaps xmm14, [rsp+0xD0]
00007942783d3185  vmovaps xmm15, [rsp+0xE0]
00007942783d318e  add rsp, 0xF0
00007942783d3195  pop r11
00007942783d3197  pop r10
00007942783d3199  pop r9
00007942783d319b  pop r8
00007942783d319d  pop rsi
00007942783d319e  pop rdi
00007942783d319f  pop rdx
00007942783d31a0  pop rcx
00007942783d31a1  pop rax
00007942783d31a2  add rsp, 0x08
00007942783d31a6  jmp 0x00007942783CFE80
00007942783d31ab  sub rsp, 0x08
00007942783d31af  push rax
00007942783d31b0  push rcx
00007942783d31b1  push rdx
00007942783d31b2  push rdi
00007942783d31b3  push rsi
00007942783d31b4  push r8
00007942783d31b6  push r9
00007942783d31b8  push r10
00007942783d31ba  push r11
00007942783d31bc  sub rsp, 0xF0
00007942783d31c3  vmovaps [rsp], xmm0
00007942783d31c8  vmovaps [rsp+0x10], xmm1
00007942783d31ce  vmovaps [rsp+0x20], xmm2
00007942783d31d4  vmovaps [rsp+0x30], xmm3
00007942783d31da  vmovaps [rsp+0x40], xmm4
00007942783d31e0  vmovaps [rsp+0x50], xmm5
00007942783d31e6  vmovaps [rsp+0x60], xmm6
00007942783d31ec  vmovaps [rsp+0x70], xmm7
00007942783d31f2  vmovaps [rsp+0x80], xmm8
00007942783d31fb  vmovaps [rsp+0x90], xmm9
00007942783d3204  vmovaps [rsp+0xA0], xmm10
00007942783d320d  vmovaps [rsp+0xB0], xmm12
00007942783d3216  vmovaps [rsp+0xC0], xmm13
00007942783d321f  vmovaps [rsp+0xD0], xmm14
00007942783d3228  vmovaps [rsp+0xE0], xmm15
00007942783d3231  sub rsp, 0x30
00007942783d3235  movaps [rsp], xmm11
00007942783d323a  movaps [rsp+0x10], xmm2
00007942783d323f  movaps [rsp+0x20], xmm12
00007942783d3245  lea rdi, [rsp]
00007942783d3249  mov esi, 0x00
00007942783d324e  mov rax, 0x59DDDCBA3530
00007942783d3258  call rax
00007942783d325a  movaps xmm11, [rsp]
00007942783d325f  add rsp, 0x30
00007942783d3263  vmovaps xmm0, [rsp]
00007942783d3268  vmovaps xmm1, [rsp+0x10]
00007942783d326e  vmovaps xmm2, [rsp+0x20]
00007942783d3274  vmovaps xmm3, [rsp+0x30]
00007942783d327a  vmovaps xmm4, [rsp+0x40]
00007942783d3280  vmovaps xmm5, [rsp+0x50]
00007942783d3286  vmovaps xmm6, [rsp+0x60]
00007942783d328c  vmovaps xmm7, [rsp+0x70]
00007942783d3292  vmovaps xmm8, [rsp+0x80]
00007942783d329b  vmovaps xmm9, [rsp+0x90]
00007942783d32a4  vmovaps xmm10, [rsp+0xA0]
00007942783d32ad  vmovaps xmm12, [rsp+0xB0]
00007942783d32b6  vmovaps xmm13, [rsp+0xC0]
00007942783d32bf  vmovaps xmm14, [rsp+0xD0]
00007942783d32c8  vmovaps xmm15, [rsp+0xE0]
00007942783d32d1  add rsp, 0xF0
00007942783d32d8  pop r11
00007942783d32da  pop r10
00007942783d32dc  pop r9
00007942783d32de  pop r8
00007942783d32e0  pop rsi
00007942783d32e1  pop rdi
00007942783d32e2  pop rdx
00007942783d32e3  pop rcx
00007942783d32e4  pop rax
00007942783d32e5  add rsp, 0x08
00007942783d32e9  jmp 0x00007942783CFEB8
00007942783d32ee  sub rsp, 0x08
00007942783d32f2  push rax
00007942783d32f3  push rcx
00007942783d32f4  push rdx
00007942783d32f5  push rdi
00007942783d32f6  push rsi
00007942783d32f7  push r8
00007942783d32f9  push r9
00007942783d32fb  push r10
00007942783d32fd  push r11
00007942783d32ff  sub rsp, 0xF0
00007942783d3306  vmovaps [rsp], xmm0
00007942783d330b  vmovaps [rsp+0x10], xmm2
00007942783d3311  vmovaps [rsp+0x20], xmm3
00007942783d3317  vmovaps [rsp+0x30], xmm4
00007942783d331d  vmovaps [rsp+0x40], xmm5
00007942783d3323  vmovaps [rsp+0x50], xmm6
00007942783d3329  vmovaps [rsp+0x60], xmm7
00007942783d332f  vmovaps [rsp+0x70], xmm8
00007942783d3335  vmovaps [rsp+0x80], xmm9
00007942783d333e  vmovaps [rsp+0x90], xmm10
00007942783d3347  vmovaps [rsp+0xA0], xmm11
00007942783d3350  vmovaps [rsp+0xB0], xmm12
00007942783d3359  vmovaps [rsp+0xC0], xmm13
00007942783d3362  vmovaps [rsp+0xD0], xmm14
00007942783d336b  vmovaps [rsp+0xE0], xmm15
00007942783d3374  sub rsp, 0x30
00007942783d3378  movaps [rsp], xmm1
00007942783d337c  movaps [rsp+0x10], xmm14
00007942783d3382  movaps [rsp+0x20], xmm6
00007942783d3387  lea rdi, [rsp]
00007942783d338b  mov esi, 0x00
00007942783d3390  mov rax, 0x59DDDCBA3530
00007942783d339a  call rax
00007942783d339c  movaps xmm1, [rsp]
00007942783d33a0  add rsp, 0x30
00007942783d33a4  vmovaps xmm0, [rsp]
00007942783d33a9  vmovaps xmm2, [rsp+0x10]
00007942783d33af  vmovaps xmm3, [rsp+0x20]
00007942783d33b5  vmovaps xmm4, [rsp+0x30]
00007942783d33bb  vmovaps xmm5, [rsp+0x40]
00007942783d33c1  vmovaps xmm6, [rsp+0x50]
00007942783d33c7  vmovaps xmm7, [rsp+0x60]
00007942783d33cd  vmovaps xmm8, [rsp+0x70]
00007942783d33d3  vmovaps xmm9, [rsp+0x80]
00007942783d33dc  vmovaps xmm10, [rsp+0x90]
00007942783d33e5  vmovaps xmm11, [rsp+0xA0]
00007942783d33ee  vmovaps xmm12, [rsp+0xB0]
00007942783d33f7  vmovaps xmm13, [rsp+0xC0]
00007942783d3400  vmovaps xmm14, [rsp+0xD0]
00007942783d3409  vmovaps xmm15, [rsp+0xE0]
00007942783d3412  add rsp, 0xF0
00007942783d3419  pop r11
00007942783d341b  pop r10
00007942783d341d  pop r9
00007942783d341f  pop r8
00007942783d3421  pop rsi
00007942783d3422  pop rdi
00007942783d3423  pop rdx
00007942783d3424  pop rcx
00007942783d3425  pop rax
00007942783d3426  add rsp, 0x08
00007942783d342a  jmp 0x00007942783CFED1
00007942783d342f  sub rsp, 0x08
00007942783d3433  push rax
00007942783d3434  push rcx
00007942783d3435  push rdx
00007942783d3436  push rdi
00007942783d3437  push rsi
00007942783d3438  push r8
00007942783d343a  push r9
00007942783d343c  push r10
00007942783d343e  push r11
00007942783d3440  sub rsp, 0xF0
00007942783d3447  vmovaps [rsp], xmm0
00007942783d344c  vmovaps [rsp+0x10], xmm1
00007942783d3452  vmovaps [rsp+0x20], xmm2
00007942783d3458  vmovaps [rsp+0x30], xmm3
00007942783d345e  vmovaps [rsp+0x40], xmm4
00007942783d3464  vmovaps [rsp+0x50], xmm5
00007942783d346a  vmovaps [rsp+0x60], xmm6
00007942783d3470  vmovaps [rsp+0x70], xmm7
00007942783d3476  vmovaps [rsp+0x80], xmm8
00007942783d347f  vmovaps [rsp+0x90], xmm9
00007942783d3488  vmovaps [rsp+0xA0], xmm10
00007942783d3491  vmovaps [rsp+0xB0], xmm11
00007942783d349a  vmovaps [rsp+0xC0], xmm12
00007942783d34a3  vmovaps [rsp+0xD0], xmm13
00007942783d34ac  vmovaps [rsp+0xE0], xmm15
00007942783d34b5  sub rsp, 0x30
00007942783d34b9  movaps [rsp], xmm14
00007942783d34be  movaps [rsp+0x10], xmm12
00007942783d34c4  movaps [rsp+0x20], xmm5
00007942783d34c9  lea rdi, [rsp]
00007942783d34cd  mov esi, 0x00
00007942783d34d2  mov rax, 0x59DDDCBA3530
00007942783d34dc  call rax
00007942783d34de  movaps xmm14, [rsp]
00007942783d34e3  add rsp, 0x30
00007942783d34e7  vmovaps xmm0, [rsp]
00007942783d34ec  vmovaps xmm1, [rsp+0x10]
00007942783d34f2  vmovaps xmm2, [rsp+0x20]
00007942783d34f8  vmovaps xmm3, [rsp+0x30]
00007942783d34fe  vmovaps xmm4, [rsp+0x40]
00007942783d3504  vmovaps xmm5, [rsp+0x50]
00007942783d350a  vmovaps xmm6, [rsp+0x60]
00007942783d3510  vmovaps xmm7, [rsp+0x70]
00007942783d3516  vmovaps xmm8, [rsp+0x80]
00007942783d351f  vmovaps xmm9, [rsp+0x90]
00007942783d3528  vmovaps xmm10, [rsp+0xA0]
00007942783d3531  vmovaps xmm11, [rsp+0xB0]
00007942783d353a  vmovaps xmm12, [rsp+0xC0]
00007942783d3543  vmovaps xmm13, [rsp+0xD0]
00007942783d354c  vmovaps xmm15, [rsp+0xE0]
00007942783d3555  add rsp, 0xF0
00007942783d355c  pop r11
00007942783d355e  pop r10
00007942783d3560  pop r9
00007942783d3562  pop r8
00007942783d3564  pop rsi
00007942783d3565  pop rdi
00007942783d3566  pop rdx
00007942783d3567  pop rcx
00007942783d3568  pop rax
00007942783d3569  add rsp, 0x08
00007942783d356d  jmp 0x00007942783CFEF1
00007942783d3572  sub rsp, 0x08
00007942783d3576  push rax
00007942783d3577  push rcx
00007942783d3578  push rdx
00007942783d3579  push rdi
00007942783d357a  push rsi
00007942783d357b  push r8
00007942783d357d  push r9
00007942783d357f  push r10
00007942783d3581  push r11
00007942783d3583  sub rsp, 0xF0
00007942783d358a  vmovaps [rsp], xmm0
00007942783d358f  vmovaps [rsp+0x10], xmm1
00007942783d3595  vmovaps [rsp+0x20], xmm2
00007942783d359b  vmovaps [rsp+0x30], xmm3
00007942783d35a1  vmovaps [rsp+0x40], xmm4
00007942783d35a7  vmovaps [rsp+0x50], xmm5
00007942783d35ad  vmovaps [rsp+0x60], xmm7
00007942783d35b3  vmovaps [rsp+0x70], xmm8
00007942783d35b9  vmovaps [rsp+0x80], xmm9
00007942783d35c2  vmovaps [rsp+0x90], xmm10
00007942783d35cb  vmovaps [rsp+0xA0], xmm11
00007942783d35d4  vmovaps [rsp+0xB0], xmm12
00007942783d35dd  vmovaps [rsp+0xC0], xmm13
00007942783d35e6  vmovaps [rsp+0xD0], xmm14
00007942783d35ef  vmovaps [rsp+0xE0], xmm15
00007942783d35f8  sub rsp, 0x30
00007942783d35fc  movaps [rsp], xmm6
00007942783d3600  movaps [rsp+0x10], xmm9
00007942783d3606  movaps [rsp+0x20], xmm12
00007942783d360c  lea rdi, [rsp]
00007942783d3610  mov esi, 0x00
00007942783d3615  mov rax, 0x59DDDCBA3530
00007942783d361f  call rax
00007942783d3621  movaps xmm6, [rsp]
00007942783d3625  add rsp, 0x30
00007942783d3629  vmovaps xmm0, [rsp]
00007942783d362e  vmovaps xmm1, [rsp+0x10]
00007942783d3634  vmovaps xmm2, [rsp+0x20]
00007942783d363a  vmovaps xmm3, [rsp+0x30]
00007942783d3640  vmovaps xmm4, [rsp+0x40]
00007942783d3646  vmovaps xmm5, [rsp+0x50]
00007942783d364c  vmovaps xmm7, [rsp+0x60]
00007942783d3652  vmovaps xmm8, [rsp+0x70]
00007942783d3658  vmovaps xmm9, [rsp+0x80]
00007942783d3661  vmovaps xmm10, [rsp+0x90]
00007942783d366a  vmovaps xmm11, [rsp+0xA0]
00007942783d3673  vmovaps xmm12, [rsp+0xB0]
00007942783d367c  vmovaps xmm13, [rsp+0xC0]
00007942783d3685  vmovaps xmm14, [rsp+0xD0]
00007942783d368e  vmovaps xmm15, [rsp+0xE0]
00007942783d3697  add rsp, 0xF0
00007942783d369e  pop r11
00007942783d36a0  pop r10
00007942783d36a2  pop r9
00007942783d36a4  pop r8
00007942783d36a6  pop rsi
00007942783d36a7  pop rdi
00007942783d36a8  pop rdx
00007942783d36a9  pop rcx
00007942783d36aa  pop rax
00007942783d36ab  add rsp, 0x08
00007942783d36af  jmp 0x00007942783CFF19
00007942783d36b4  sub rsp, 0x08
00007942783d36b8  push rax
00007942783d36b9  push rcx
00007942783d36ba  push rdx
00007942783d36bb  push rdi
00007942783d36bc  push rsi
00007942783d36bd  push r8
00007942783d36bf  push r9
00007942783d36c1  push r10
00007942783d36c3  push r11
00007942783d36c5  sub rsp, 0xF0
00007942783d36cc  vmovaps [rsp], xmm0
00007942783d36d1  vmovaps [rsp+0x10], xmm1
00007942783d36d7  vmovaps [rsp+0x20], xmm2
00007942783d36dd  vmovaps [rsp+0x30], xmm3
00007942783d36e3  vmovaps [rsp+0x40], xmm4
00007942783d36e9  vmovaps [rsp+0x50], xmm5
00007942783d36ef  vmovaps [rsp+0x60], xmm6
00007942783d36f5  vmovaps [rsp+0x70], xmm7
00007942783d36fb  vmovaps [rsp+0x80], xmm8
00007942783d3704  vmovaps [rsp+0x90], xmm9
00007942783d370d  vmovaps [rsp+0xA0], xmm10
00007942783d3716  vmovaps [rsp+0xB0], xmm11
00007942783d371f  vmovaps [rsp+0xC0], xmm13
00007942783d3728  vmovaps [rsp+0xD0], xmm14
00007942783d3731  vmovaps [rsp+0xE0], xmm15
00007942783d373a  sub rsp, 0x30
00007942783d373e  movaps [rsp], xmm12
00007942783d3743  movaps [rsp+0x10], xmm15
00007942783d3749  movaps [rsp+0x20], xmm13
00007942783d374f  lea rdi, [rsp]
00007942783d3753  mov esi, 0x00
00007942783d3758  mov rax, 0x59DDDCBA3530
00007942783d3762  call rax
00007942783d3764  movaps xmm12, [rsp]
00007942783d3769  add rsp, 0x30
00007942783d376d  vmovaps xmm0, [rsp]
00007942783d3772  vmovaps xmm1, [rsp+0x10]
00007942783d3778  vmovaps xmm2, [rsp+0x20]
00007942783d377e  vmovaps xmm3, [rsp+0x30]
00007942783d3784  vmovaps xmm4, [rsp+0x40]
00007942783d378a  vmovaps xmm5, [rsp+0x50]
00007942783d3790  vmovaps xmm6, [rsp+0x60]
00007942783d3796  vmovaps xmm7, [rsp+0x70]
00007942783d379c  vmovaps xmm8, [rsp+0x80]
00007942783d37a5  vmovaps xmm9, [rsp+0x90]
00007942783d37ae  vmovaps xmm10, [rsp+0xA0]
00007942783d37b7  vmovaps xmm11, [rsp+0xB0]
00007942783d37c0  vmovaps xmm13, [rsp+0xC0]
00007942783d37c9  vmovaps xmm14, [rsp+0xD0]
00007942783d37d2  vmovaps xmm15, [rsp+0xE0]
00007942783d37db  add rsp, 0xF0
00007942783d37e2  pop r11
00007942783d37e4  pop r10
00007942783d37e6  pop r9
00007942783d37e8  pop r8
00007942783d37ea  pop rsi
00007942783d37eb  pop rdi
00007942783d37ec  pop rdx
00007942783d37ed  pop rcx
00007942783d37ee  pop rax
00007942783d37ef  add rsp, 0x08
00007942783d37f3  jmp 0x00007942783CFF34
00007942783d37f8  sub rsp, 0x08
00007942783d37fc  push rax
00007942783d37fd  push rcx
00007942783d37fe  push rdx
00007942783d37ff  push rdi
00007942783d3800  push rsi
00007942783d3801  push r8
00007942783d3803  push r9
00007942783d3805  push r10
00007942783d3807  push r11
00007942783d3809  sub rsp, 0xF0
00007942783d3810  vmovaps [rsp], xmm0
00007942783d3815  vmovaps [rsp+0x10], xmm1
00007942783d381b  vmovaps [rsp+0x20], xmm2
00007942783d3821  vmovaps [rsp+0x30], xmm3
00007942783d3827  vmovaps [rsp+0x40], xmm4
00007942783d382d  vmovaps [rsp+0x50], xmm5
00007942783d3833  vmovaps [rsp+0x60], xmm6
00007942783d3839  vmovaps [rsp+0x70], xmm7
00007942783d383f  vmovaps [rsp+0x80], xmm8
00007942783d3848  vmovaps [rsp+0x90], xmm9
00007942783d3851  vmovaps [rsp+0xA0], xmm10
00007942783d385a  vmovaps [rsp+0xB0], xmm11
00007942783d3863  vmovaps [rsp+0xC0], xmm12
00007942783d386c  vmovaps [rsp+0xD0], xmm13
00007942783d3875  vmovaps [rsp+0xE0], xmm14
00007942783d387e  sub rsp, 0x30
00007942783d3882  movaps [rsp], xmm15
00007942783d3887  movaps [rsp+0x10], xmm13
00007942783d388d  movaps [rsp+0x20], xmm10
00007942783d3893  lea rdi, [rsp]
00007942783d3897  mov esi, 0x00
00007942783d389c  mov rax, 0x59DDDCBA3530
00007942783d38a6  call rax
00007942783d38a8  movaps xmm15, [rsp]
00007942783d38ad  add rsp, 0x30
00007942783d38b1  vmovaps xmm0, [rsp]
00007942783d38b6  vmovaps xmm1, [rsp+0x10]
00007942783d38bc  vmovaps xmm2, [rsp+0x20]
00007942783d38c2  vmovaps xmm3, [rsp+0x30]
00007942783d38c8  vmovaps xmm4, [rsp+0x40]
00007942783d38ce  vmovaps xmm5, [rsp+0x50]
00007942783d38d4  vmovaps xmm6, [rsp+0x60]
00007942783d38da  vmovaps xmm7, [rsp+0x70]
00007942783d38e0  vmovaps xmm8, [rsp+0x80]
00007942783d38e9  vmovaps xmm9, [rsp+0x90]
00007942783d38f2  vmovaps xmm10, [rsp+0xA0]
00007942783d38fb  vmovaps xmm11, [rsp+0xB0]
00007942783d3904  vmovaps xmm12, [rsp+0xC0]
00007942783d390d  vmovaps xmm13, [rsp+0xD0]
00007942783d3916  vmovaps xmm14, [rsp+0xE0]
00007942783d391f  add rsp, 0xF0
00007942783d3926  pop r11
00007942783d3928  pop r10
00007942783d392a  pop r9
00007942783d392c  pop r8
00007942783d392e  pop rsi
00007942783d392f  pop rdi
00007942783d3930  pop rdx
00007942783d3931  pop rcx
00007942783d3932  pop rax
00007942783d3933  add rsp, 0x08
00007942783d3937  jmp 0x00007942783CFF55
00007942783d393c  call 0x000079427820C260
00007942783d3941  jmp 0x00007942783CFFB0
00007942783d3946  sub rsp, 0x08
00007942783d394a  push rax
00007942783d394b  push rcx
00007942783d394c  push rdx
00007942783d394d  push rdi
00007942783d394e  push rsi
00007942783d394f  push r8
00007942783d3951  push r9
00007942783d3953  push r10
00007942783d3955  push r11
00007942783d3957  sub rsp, 0xF0
00007942783d395e  vmovaps [rsp], xmm0
00007942783d3963  vmovaps [rsp+0x10], xmm1
00007942783d3969  vmovaps [rsp+0x20], xmm2
00007942783d396f  vmovaps [rsp+0x30], xmm3
00007942783d3975  vmovaps [rsp+0x40], xmm4
00007942783d397b  vmovaps [rsp+0x50], xmm5
00007942783d3981  vmovaps [rsp+0x60], xmm6
00007942783d3987  vmovaps [rsp+0x70], xmm7
00007942783d398d  vmovaps [rsp+0x80], xmm8
00007942783d3996  vmovaps [rsp+0x90], xmm10
00007942783d399f  vmovaps [rsp+0xA0], xmm11
00007942783d39a8  vmovaps [rsp+0xB0], xmm12
00007942783d39b1  vmovaps [rsp+0xC0], xmm13
00007942783d39ba  vmovaps [rsp+0xD0], xmm14
00007942783d39c3  vmovaps [rsp+0xE0], xmm15
00007942783d39cc  sub rsp, 0x30
00007942783d39d0  movaps [rsp], xmm9
00007942783d39d5  movaps [rsp+0x10], xmm8
00007942783d39db  movaps [rsp+0x20], xmm10
00007942783d39e1  lea rdi, [rsp]
00007942783d39e5  mov esi, 0x00
00007942783d39ea  mov rax, 0x59DDDCBA3530
00007942783d39f4  call rax
00007942783d39f6  movaps xmm9, [rsp]
00007942783d39fb  add rsp, 0x30
00007942783d39ff  vmovaps xmm0, [rsp]
00007942783d3a04  vmovaps xmm1, [rsp+0x10]
00007942783d3a0a  vmovaps xmm2, [rsp+0x20]
00007942783d3a10  vmovaps xmm3, [rsp+0x30]
00007942783d3a16  vmovaps xmm4, [rsp+0x40]
00007942783d3a1c  vmovaps xmm5, [rsp+0x50]
00007942783d3a22  vmovaps xmm6, [rsp+0x60]
00007942783d3a28  vmovaps xmm7, [rsp+0x70]
00007942783d3a2e  vmovaps xmm8, [rsp+0x80]
00007942783d3a37  vmovaps xmm10, [rsp+0x90]
00007942783d3a40  vmovaps xmm11, [rsp+0xA0]
00007942783d3a49  vmovaps xmm12, [rsp+0xB0]
00007942783d3a52  vmovaps xmm13, [rsp+0xC0]
00007942783d3a5b  vmovaps xmm14, [rsp+0xD0]
00007942783d3a64  vmovaps xmm15, [rsp+0xE0]
00007942783d3a6d  add rsp, 0xF0
00007942783d3a74  pop r11
00007942783d3a76  pop r10
00007942783d3a78  pop r9
00007942783d3a7a  pop r8
00007942783d3a7c  pop rsi
00007942783d3a7d  pop rdi
00007942783d3a7e  pop rdx
00007942783d3a7f  pop rcx
00007942783d3a80  pop rax
00007942783d3a81  add rsp, 0x08
00007942783d3a85  jmp 0x00007942783CFFE1
00007942783d3a8a  sub rsp, 0x08
00007942783d3a8e  push rax
00007942783d3a8f  push rcx
00007942783d3a90  push rdx
00007942783d3a91  push rdi
00007942783d3a92  push rsi
00007942783d3a93  push r8
00007942783d3a95  push r9
00007942783d3a97  push r10
00007942783d3a99  push r11
00007942783d3a9b  sub rsp, 0xF0
00007942783d3aa2  vmovaps [rsp], xmm0
00007942783d3aa7  vmovaps [rsp+0x10], xmm1
00007942783d3aad  vmovaps [rsp+0x20], xmm2
00007942783d3ab3  vmovaps [rsp+0x30], xmm3
00007942783d3ab9  vmovaps [rsp+0x40], xmm4
00007942783d3abf  vmovaps [rsp+0x50], xmm5
00007942783d3ac5  vmovaps [rsp+0x60], xmm6
00007942783d3acb  vmovaps [rsp+0x70], xmm7
00007942783d3ad1  vmovaps [rsp+0x80], xmm8
00007942783d3ada  vmovaps [rsp+0x90], xmm9
00007942783d3ae3  vmovaps [rsp+0xA0], xmm11
00007942783d3aec  vmovaps [rsp+0xB0], xmm12
00007942783d3af5  vmovaps [rsp+0xC0], xmm13
00007942783d3afe  vmovaps [rsp+0xD0], xmm14
00007942783d3b07  vmovaps [rsp+0xE0], xmm15
00007942783d3b10  sub rsp, 0x30
00007942783d3b14  movaps [rsp], xmm10
00007942783d3b19  movaps [rsp+0x10], xmm1
00007942783d3b1e  movaps [rsp+0x20], xmm11
00007942783d3b24  lea rdi, [rsp]
00007942783d3b28  mov esi, 0x00
00007942783d3b2d  mov rax, 0x59DDDCBA3530
00007942783d3b37  call rax
00007942783d3b39  movaps xmm10, [rsp]
00007942783d3b3e  add rsp, 0x30
00007942783d3b42  vmovaps xmm0, [rsp]
00007942783d3b47  vmovaps xmm1, [rsp+0x10]
00007942783d3b4d  vmovaps xmm2, [rsp+0x20]
00007942783d3b53  vmovaps xmm3, [rsp+0x30]
00007942783d3b59  vmovaps xmm4, [rsp+0x40]
00007942783d3b5f  vmovaps xmm5, [rsp+0x50]
00007942783d3b65  vmovaps xmm6, [rsp+0x60]
00007942783d3b6b  vmovaps xmm7, [rsp+0x70]
00007942783d3b71  vmovaps xmm8, [rsp+0x80]
00007942783d3b7a  vmovaps xmm9, [rsp+0x90]
00007942783d3b83  vmovaps xmm11, [rsp+0xA0]
00007942783d3b8c  vmovaps xmm12, [rsp+0xB0]
00007942783d3b95  vmovaps xmm13, [rsp+0xC0]
00007942783d3b9e  vmovaps xmm14, [rsp+0xD0]
00007942783d3ba7  vmovaps xmm15, [rsp+0xE0]
00007942783d3bb0  add rsp, 0xF0
00007942783d3bb7  pop r11
00007942783d3bb9  pop r10
00007942783d3bbb  pop r9
00007942783d3bbd  pop r8
00007942783d3bbf  pop rsi
00007942783d3bc0  pop rdi
00007942783d3bc1  pop rdx
00007942783d3bc2  pop rcx
00007942783d3bc3  pop rax
00007942783d3bc4  add rsp, 0x08
00007942783d3bc8  jmp 0x00007942783CFFFC
00007942783d3bcd  sub rsp, 0x08
00007942783d3bd1  push rax
00007942783d3bd2  push rcx
00007942783d3bd3  push rdx
00007942783d3bd4  push rdi
00007942783d3bd5  push rsi
00007942783d3bd6  push r8
00007942783d3bd8  push r9
00007942783d3bda  push r10
00007942783d3bdc  push r11
00007942783d3bde  sub rsp, 0xF0
00007942783d3be5  vmovaps [rsp], xmm0
00007942783d3bea  vmovaps [rsp+0x10], xmm2
00007942783d3bf0  vmovaps [rsp+0x20], xmm3
00007942783d3bf6  vmovaps [rsp+0x30], xmm4
00007942783d3bfc  vmovaps [rsp+0x40], xmm5
00007942783d3c02  vmovaps [rsp+0x50], xmm6
00007942783d3c08  vmovaps [rsp+0x60], xmm7
00007942783d3c0e  vmovaps [rsp+0x70], xmm8
00007942783d3c14  vmovaps [rsp+0x80], xmm9
00007942783d3c1d  vmovaps [rsp+0x90], xmm10
00007942783d3c26  vmovaps [rsp+0xA0], xmm11
00007942783d3c2f  vmovaps [rsp+0xB0], xmm12
00007942783d3c38  vmovaps [rsp+0xC0], xmm13
00007942783d3c41  vmovaps [rsp+0xD0], xmm14
00007942783d3c4a  vmovaps [rsp+0xE0], xmm15
00007942783d3c53  sub rsp, 0x30
00007942783d3c57  movaps [rsp], xmm1
00007942783d3c5b  movaps [rsp+0x10], xmm14
00007942783d3c61  movaps [rsp+0x20], xmm6
00007942783d3c66  lea rdi, [rsp]
00007942783d3c6a  mov esi, 0x00
00007942783d3c6f  mov rax, 0x59DDDCBA3530
00007942783d3c79  call rax
00007942783d3c7b  movaps xmm1, [rsp]
00007942783d3c7f  add rsp, 0x30
00007942783d3c83  vmovaps xmm0, [rsp]
00007942783d3c88  vmovaps xmm2, [rsp+0x10]
00007942783d3c8e  vmovaps xmm3, [rsp+0x20]
00007942783d3c94  vmovaps xmm4, [rsp+0x30]
00007942783d3c9a  vmovaps xmm5, [rsp+0x40]
00007942783d3ca0  vmovaps xmm6, [rsp+0x50]
00007942783d3ca6  vmovaps xmm7, [rsp+0x60]
00007942783d3cac  vmovaps xmm8, [rsp+0x70]
00007942783d3cb2  vmovaps xmm9, [rsp+0x80]
00007942783d3cbb  vmovaps xmm10, [rsp+0x90]
00007942783d3cc4  vmovaps xmm11, [rsp+0xA0]
00007942783d3ccd  vmovaps xmm12, [rsp+0xB0]
00007942783d3cd6  vmovaps xmm13, [rsp+0xC0]
00007942783d3cdf  vmovaps xmm14, [rsp+0xD0]
00007942783d3ce8  vmovaps xmm15, [rsp+0xE0]
00007942783d3cf1  add rsp, 0xF0
00007942783d3cf8  pop r11
00007942783d3cfa  pop r10
00007942783d3cfc  pop r9
00007942783d3cfe  pop r8
00007942783d3d00  pop rsi
00007942783d3d01  pop rdi
00007942783d3d02  pop rdx
00007942783d3d03  pop rcx
00007942783d3d04  pop rax
00007942783d3d05  add rsp, 0x08
00007942783d3d09  jmp 0x00007942783D0015
00007942783d3d0e  sub rsp, 0x08
00007942783d3d12  push rax
00007942783d3d13  push rcx
00007942783d3d14  push rdx
00007942783d3d15  push rdi
00007942783d3d16  push rsi
00007942783d3d17  push r8
00007942783d3d19  push r9
00007942783d3d1b  push r10
00007942783d3d1d  push r11
00007942783d3d1f  sub rsp, 0xF0
00007942783d3d26  vmovaps [rsp], xmm0
00007942783d3d2b  vmovaps [rsp+0x10], xmm1
00007942783d3d31  vmovaps [rsp+0x20], xmm2
00007942783d3d37  vmovaps [rsp+0x30], xmm3
00007942783d3d3d  vmovaps [rsp+0x40], xmm4
00007942783d3d43  vmovaps [rsp+0x50], xmm5
00007942783d3d49  vmovaps [rsp+0x60], xmm6
00007942783d3d4f  vmovaps [rsp+0x70], xmm7
00007942783d3d55  vmovaps [rsp+0x80], xmm8
00007942783d3d5e  vmovaps [rsp+0x90], xmm9
00007942783d3d67  vmovaps [rsp+0xA0], xmm10
00007942783d3d70  vmovaps [rsp+0xB0], xmm12
00007942783d3d79  vmovaps [rsp+0xC0], xmm13
00007942783d3d82  vmovaps [rsp+0xD0], xmm14
00007942783d3d8b  vmovaps [rsp+0xE0], xmm15
00007942783d3d94  sub rsp, 0x30
00007942783d3d98  movaps [rsp], xmm11
00007942783d3d9d  movaps [rsp+0x10], xmm13
00007942783d3da3  movaps [rsp+0x20], xmm14
00007942783d3da9  lea rdi, [rsp]
00007942783d3dad  mov esi, 0x00
00007942783d3db2  mov rax, 0x59DDDCBA3530
00007942783d3dbc  call rax
00007942783d3dbe  movaps xmm11, [rsp]
00007942783d3dc3  add rsp, 0x30
00007942783d3dc7  vmovaps xmm0, [rsp]
00007942783d3dcc  vmovaps xmm1, [rsp+0x10]
00007942783d3dd2  vmovaps xmm2, [rsp+0x20]
00007942783d3dd8  vmovaps xmm3, [rsp+0x30]
00007942783d3dde  vmovaps xmm4, [rsp+0x40]
00007942783d3de4  vmovaps xmm5, [rsp+0x50]
00007942783d3dea  vmovaps xmm6, [rsp+0x60]
00007942783d3df0  vmovaps xmm7, [rsp+0x70]
00007942783d3df6  vmovaps xmm8, [rsp+0x80]
00007942783d3dff  vmovaps xmm9, [rsp+0x90]
00007942783d3e08  vmovaps xmm10, [rsp+0xA0]
00007942783d3e11  vmovaps xmm12, [rsp+0xB0]
00007942783d3e1a  vmovaps xmm13, [rsp+0xC0]
00007942783d3e23  vmovaps xmm14, [rsp+0xD0]
00007942783d3e2c  vmovaps xmm15, [rsp+0xE0]
00007942783d3e35  add rsp, 0xF0
00007942783d3e3c  pop r11
00007942783d3e3e  pop r10
00007942783d3e40  pop r9
00007942783d3e42  pop r8
00007942783d3e44  pop rsi
00007942783d3e45  pop rdi
00007942783d3e46  pop rdx
00007942783d3e47  pop rcx
00007942783d3e48  pop rax
00007942783d3e49  add rsp, 0x08
00007942783d3e4d  jmp 0x00007942783D003F
00007942783d3e52  sub rsp, 0x08
00007942783d3e56  push rax
00007942783d3e57  push rcx
00007942783d3e58  push rdx
00007942783d3e59  push rdi
00007942783d3e5a  push rsi
00007942783d3e5b  push r8
00007942783d3e5d  push r9
00007942783d3e5f  push r10
00007942783d3e61  push r11
00007942783d3e63  sub rsp, 0xF0
00007942783d3e6a  vmovaps [rsp], xmm0
00007942783d3e6f  vmovaps [rsp+0x10], xmm1
00007942783d3e75  vmovaps [rsp+0x20], xmm2
00007942783d3e7b  vmovaps [rsp+0x30], xmm3
00007942783d3e81  vmovaps [rsp+0x40], xmm4
00007942783d3e87  vmovaps [rsp+0x50], xmm5
00007942783d3e8d  vmovaps [rsp+0x60], xmm6
00007942783d3e93  vmovaps [rsp+0x70], xmm7
00007942783d3e99  vmovaps [rsp+0x80], xmm8
00007942783d3ea2  vmovaps [rsp+0x90], xmm9
00007942783d3eab  vmovaps [rsp+0xA0], xmm10
00007942783d3eb4  vmovaps [rsp+0xB0], xmm11
00007942783d3ebd  vmovaps [rsp+0xC0], xmm12
00007942783d3ec6  vmovaps [rsp+0xD0], xmm14
00007942783d3ecf  vmovaps [rsp+0xE0], xmm15
00007942783d3ed8  sub rsp, 0x30
00007942783d3edc  movaps [rsp], xmm13
00007942783d3ee1  movaps [rsp+0x10], xmm8
00007942783d3ee7  movaps [rsp+0x20], xmm14
00007942783d3eed  lea rdi, [rsp]
00007942783d3ef1  mov esi, 0x00
00007942783d3ef6  mov rax, 0x59DDDCBA3530
00007942783d3f00  call rax
00007942783d3f02  movaps xmm13, [rsp]
00007942783d3f07  add rsp, 0x30
00007942783d3f0b  vmovaps xmm0, [rsp]
00007942783d3f10  vmovaps xmm1, [rsp+0x10]
00007942783d3f16  vmovaps xmm2, [rsp+0x20]
00007942783d3f1c  vmovaps xmm3, [rsp+0x30]
00007942783d3f22  vmovaps xmm4, [rsp+0x40]
00007942783d3f28  vmovaps xmm5, [rsp+0x50]
00007942783d3f2e  vmovaps xmm6, [rsp+0x60]
00007942783d3f34  vmovaps xmm7, [rsp+0x70]
00007942783d3f3a  vmovaps xmm8, [rsp+0x80]
00007942783d3f43  vmovaps xmm9, [rsp+0x90]
00007942783d3f4c  vmovaps xmm10, [rsp+0xA0]
00007942783d3f55  vmovaps xmm11, [rsp+0xB0]
00007942783d3f5e  vmovaps xmm12, [rsp+0xC0]
00007942783d3f67  vmovaps xmm14, [rsp+0xD0]
00007942783d3f70  vmovaps xmm15, [rsp+0xE0]
00007942783d3f79  add rsp, 0xF0
00007942783d3f80  pop r11
00007942783d3f82  pop r10
00007942783d3f84  pop r9
00007942783d3f86  pop r8
00007942783d3f88  pop rsi
00007942783d3f89  pop rdi
00007942783d3f8a  pop rdx
00007942783d3f8b  pop rcx
00007942783d3f8c  pop rax
00007942783d3f8d  add rsp, 0x08
00007942783d3f91  jmp 0x00007942783D006E
00007942783d3f96  sub rsp, 0x08
00007942783d3f9a  push rax
00007942783d3f9b  push rcx
00007942783d3f9c  push rdx
00007942783d3f9d  push rdi
00007942783d3f9e  push rsi
00007942783d3f9f  push r8
00007942783d3fa1  push r9
00007942783d3fa3  push r10
00007942783d3fa5  push r11
00007942783d3fa7  sub rsp, 0xF0
00007942783d3fae  vmovaps [rsp], xmm0
00007942783d3fb3  vmovaps [rsp+0x10], xmm1
00007942783d3fb9  vmovaps [rsp+0x20], xmm2
00007942783d3fbf  vmovaps [rsp+0x30], xmm3
00007942783d3fc5  vmovaps [rsp+0x40], xmm4
00007942783d3fcb  vmovaps [rsp+0x50], xmm5
00007942783d3fd1  vmovaps [rsp+0x60], xmm6
00007942783d3fd7  vmovaps [rsp+0x70], xmm7
00007942783d3fdd  vmovaps [rsp+0x80], xmm9
00007942783d3fe6  vmovaps [rsp+0x90], xmm10
00007942783d3fef  vmovaps [rsp+0xA0], xmm11
00007942783d3ff8  vmovaps [rsp+0xB0], xmm12
00007942783d4001  vmovaps [rsp+0xC0], xmm13
00007942783d400a  vmovaps [rsp+0xD0], xmm14
00007942783d4013  vmovaps [rsp+0xE0], xmm15
00007942783d401c  sub rsp, 0x30
00007942783d4020  movaps [rsp], xmm8
00007942783d4025  movaps [rsp+0x10], xmm7
00007942783d402a  movaps [rsp+0x20], xmm14
00007942783d4030  lea rdi, [rsp]
00007942783d4034  mov esi, 0x00
00007942783d4039  mov rax, 0x59DDDCBA3530
00007942783d4043  call rax
00007942783d4045  movaps xmm8, [rsp]
00007942783d404a  add rsp, 0x30
00007942783d404e  vmovaps xmm0, [rsp]
00007942783d4053  vmovaps xmm1, [rsp+0x10]
00007942783d4059  vmovaps xmm2, [rsp+0x20]
00007942783d405f  vmovaps xmm3, [rsp+0x30]
00007942783d4065  vmovaps xmm4, [rsp+0x40]
00007942783d406b  vmovaps xmm5, [rsp+0x50]
00007942783d4071  vmovaps xmm6, [rsp+0x60]
00007942783d4077  vmovaps xmm7, [rsp+0x70]
00007942783d407d  vmovaps xmm9, [rsp+0x80]
00007942783d4086  vmovaps xmm10, [rsp+0x90]
00007942783d408f  vmovaps xmm11, [rsp+0xA0]
00007942783d4098  vmovaps xmm12, [rsp+0xB0]
00007942783d40a1  vmovaps xmm13, [rsp+0xC0]
00007942783d40aa  vmovaps xmm14, [rsp+0xD0]
00007942783d40b3  vmovaps xmm15, [rsp+0xE0]
00007942783d40bc  add rsp, 0xF0
00007942783d40c3  pop r11
00007942783d40c5  pop r10
00007942783d40c7  pop r9
00007942783d40c9  pop r8
00007942783d40cb  pop rsi
00007942783d40cc  pop rdi
00007942783d40cd  pop rdx
00007942783d40ce  pop rcx
00007942783d40cf  pop rax
00007942783d40d0  add rsp, 0x08
00007942783d40d4  jmp 0x00007942783D0094
00007942783d40d9  sub rsp, 0x08
00007942783d40dd  push rax
00007942783d40de  push rcx
00007942783d40df  push rdx
00007942783d40e0  push rdi
00007942783d40e1  push rsi
00007942783d40e2  push r8
00007942783d40e4  push r9
00007942783d40e6  push r10
00007942783d40e8  push r11
00007942783d40ea  sub rsp, 0xF0
00007942783d40f1  vmovaps [rsp], xmm0
00007942783d40f6  vmovaps [rsp+0x10], xmm1
00007942783d40fc  vmovaps [rsp+0x20], xmm2
00007942783d4102  vmovaps [rsp+0x30], xmm3
00007942783d4108  vmovaps [rsp+0x40], xmm4
00007942783d410e  vmovaps [rsp+0x50], xmm5
00007942783d4114  vmovaps [rsp+0x60], xmm6
00007942783d411a  vmovaps [rsp+0x70], xmm7
00007942783d4120  vmovaps [rsp+0x80], xmm8
00007942783d4129  vmovaps [rsp+0x90], xmm9
00007942783d4132  vmovaps [rsp+0xA0], xmm10
00007942783d413b  vmovaps [rsp+0xB0], xmm11
00007942783d4144  vmovaps [rsp+0xC0], xmm12
00007942783d414d  vmovaps [rsp+0xD0], xmm13
00007942783d4156  vmovaps [rsp+0xE0], xmm15
00007942783d415f  sub rsp, 0x30
00007942783d4163  movaps [rsp], xmm14
00007942783d4168  movaps [rsp+0x10], xmm12
00007942783d416e  movaps [rsp+0x20], xmm9
00007942783d4174  lea rdi, [rsp]
00007942783d4178  mov esi, 0x00
00007942783d417d  mov rax, 0x59DDDCBA3530
00007942783d4187  call rax
00007942783d4189  movaps xmm14, [rsp]
00007942783d418e  add rsp, 0x30
00007942783d4192  vmovaps xmm0, [rsp]
00007942783d4197  vmovaps xmm1, [rsp+0x10]
00007942783d419d  vmovaps xmm2, [rsp+0x20]
00007942783d41a3  vmovaps xmm3, [rsp+0x30]
00007942783d41a9  vmovaps xmm4, [rsp+0x40]
00007942783d41af  vmovaps xmm5, [rsp+0x50]
00007942783d41b5  vmovaps xmm6, [rsp+0x60]
00007942783d41bb  vmovaps xmm7, [rsp+0x70]
00007942783d41c1  vmovaps xmm8, [rsp+0x80]
00007942783d41ca  vmovaps xmm9, [rsp+0x90]
00007942783d41d3  vmovaps xmm10, [rsp+0xA0]
00007942783d41dc  vmovaps xmm11, [rsp+0xB0]
00007942783d41e5  vmovaps xmm12, [rsp+0xC0]
00007942783d41ee  vmovaps xmm13, [rsp+0xD0]
00007942783d41f7  vmovaps xmm15, [rsp+0xE0]
00007942783d4200  add rsp, 0xF0
00007942783d4207  pop r11
00007942783d4209  pop r10
00007942783d420b  pop r9
00007942783d420d  pop r8
00007942783d420f  pop rsi
00007942783d4210  pop rdi
00007942783d4211  pop rdx
00007942783d4212  pop rcx
00007942783d4213  pop rax
00007942783d4214  add rsp, 0x08
00007942783d4218  jmp 0x00007942783D00AE
00007942783d421d  sub rsp, 0x08
00007942783d4221  push rax
00007942783d4222  push rcx
00007942783d4223  push rdx
00007942783d4224  push rdi
00007942783d4225  push rsi
00007942783d4226  push r8
00007942783d4228  push r9
00007942783d422a  push r10
00007942783d422c  push r11
00007942783d422e  sub rsp, 0xF0
00007942783d4235  vmovaps [rsp], xmm0
00007942783d423a  vmovaps [rsp+0x10], xmm1
00007942783d4240  vmovaps [rsp+0x20], xmm2
00007942783d4246  vmovaps [rsp+0x30], xmm3
00007942783d424c  vmovaps [rsp+0x40], xmm4
00007942783d4252  vmovaps [rsp+0x50], xmm5
00007942783d4258  vmovaps [rsp+0x60], xmm6
00007942783d425e  vmovaps [rsp+0x70], xmm7
00007942783d4264  vmovaps [rsp+0x80], xmm8
00007942783d426d  vmovaps [rsp+0x90], xmm10
00007942783d4276  vmovaps [rsp+0xA0], xmm11
00007942783d427f  vmovaps [rsp+0xB0], xmm12
00007942783d4288  vmovaps [rsp+0xC0], xmm13
00007942783d4291  vmovaps [rsp+0xD0], xmm14
00007942783d429a  vmovaps [rsp+0xE0], xmm15
00007942783d42a3  sub rsp, 0x30
00007942783d42a7  movaps [rsp], xmm9
00007942783d42ac  movaps [rsp+0x10], xmm7
00007942783d42b1  movaps [rsp+0x20], xmm12
00007942783d42b7  lea rdi, [rsp]
00007942783d42bb  mov esi, 0x00
00007942783d42c0  mov rax, 0x59DDDCBA3530
00007942783d42ca  call rax
00007942783d42cc  movaps xmm9, [rsp]
00007942783d42d1  add rsp, 0x30
00007942783d42d5  vmovaps xmm0, [rsp]
00007942783d42da  vmovaps xmm1, [rsp+0x10]
00007942783d42e0  vmovaps xmm2, [rsp+0x20]
00007942783d42e6  vmovaps xmm3, [rsp+0x30]
00007942783d42ec  vmovaps xmm4, [rsp+0x40]
00007942783d42f2  vmovaps xmm5, [rsp+0x50]
00007942783d42f8  vmovaps xmm6, [rsp+0x60]
00007942783d42fe  vmovaps xmm7, [rsp+0x70]
00007942783d4304  vmovaps xmm8, [rsp+0x80]
00007942783d430d  vmovaps xmm10, [rsp+0x90]
00007942783d4316  vmovaps xmm11, [rsp+0xA0]
00007942783d431f  vmovaps xmm12, [rsp+0xB0]
00007942783d4328  vmovaps xmm13, [rsp+0xC0]
00007942783d4331  vmovaps xmm14, [rsp+0xD0]
00007942783d433a  vmovaps xmm15, [rsp+0xE0]
00007942783d4343  add rsp, 0xF0
00007942783d434a  pop r11
00007942783d434c  pop r10
00007942783d434e  pop r9
00007942783d4350  pop r8
00007942783d4352  pop rsi
00007942783d4353  pop rdi
00007942783d4354  pop rdx
00007942783d4355  pop rcx
00007942783d4356  pop rax
00007942783d4357  add rsp, 0x08
00007942783d435b  jmp 0x00007942783D00DD
00007942783d4360  sub rsp, 0x08
00007942783d4364  push rax
00007942783d4365  push rcx
00007942783d4366  push rdx
00007942783d4367  push rdi
00007942783d4368  push rsi
00007942783d4369  push r8
00007942783d436b  push r9
00007942783d436d  push r10
00007942783d436f  push r11
00007942783d4371  sub rsp, 0xF0
00007942783d4378  vmovaps [rsp], xmm0
00007942783d437d  vmovaps [rsp+0x10], xmm1
00007942783d4383  vmovaps [rsp+0x20], xmm2
00007942783d4389  vmovaps [rsp+0x30], xmm3
00007942783d438f  vmovaps [rsp+0x40], xmm4
00007942783d4395  vmovaps [rsp+0x50], xmm5
00007942783d439b  vmovaps [rsp+0x60], xmm6
00007942783d43a1  vmovaps [rsp+0x70], xmm7
00007942783d43a7  vmovaps [rsp+0x80], xmm8
00007942783d43b0  vmovaps [rsp+0x90], xmm9
00007942783d43b9  vmovaps [rsp+0xA0], xmm10
00007942783d43c2  vmovaps [rsp+0xB0], xmm11
00007942783d43cb  vmovaps [rsp+0xC0], xmm13
00007942783d43d4  vmovaps [rsp+0xD0], xmm14
00007942783d43dd  vmovaps [rsp+0xE0], xmm15
00007942783d43e6  sub rsp, 0x30
00007942783d43ea  movaps [rsp], xmm12
00007942783d43ef  movaps [rsp+0x10], xmm15
00007942783d43f5  movaps [rsp+0x20], xmm11
00007942783d43fb  lea rdi, [rsp]
00007942783d43ff  mov esi, 0x00
00007942783d4404  mov rax, 0x59DDDCBA3530
00007942783d440e  call rax
00007942783d4410  movaps xmm12, [rsp]
00007942783d4415  add rsp, 0x30
00007942783d4419  vmovaps xmm0, [rsp]
00007942783d441e  vmovaps xmm1, [rsp+0x10]
00007942783d4424  vmovaps xmm2, [rsp+0x20]
00007942783d442a  vmovaps xmm3, [rsp+0x30]
00007942783d4430  vmovaps xmm4, [rsp+0x40]
00007942783d4436  vmovaps xmm5, [rsp+0x50]
00007942783d443c  vmovaps xmm6, [rsp+0x60]
00007942783d4442  vmovaps xmm7, [rsp+0x70]
00007942783d4448  vmovaps xmm8, [rsp+0x80]
00007942783d4451  vmovaps xmm9, [rsp+0x90]
00007942783d445a  vmovaps xmm10, [rsp+0xA0]
00007942783d4463  vmovaps xmm11, [rsp+0xB0]
00007942783d446c  vmovaps xmm13, [rsp+0xC0]
00007942783d4475  vmovaps xmm14, [rsp+0xD0]
00007942783d447e  vmovaps xmm15, [rsp+0xE0]
00007942783d4487  add rsp, 0xF0
00007942783d448e  pop r11
00007942783d4490  pop r10
00007942783d4492  pop r9
00007942783d4494  pop r8
00007942783d4496  pop rsi
00007942783d4497  pop rdi
00007942783d4498  pop rdx
00007942783d4499  pop rcx
00007942783d449a  pop rax
00007942783d449b  add rsp, 0x08
00007942783d449f  jmp 0x00007942783D00F7
00007942783d44a4  sub rsp, 0x08
00007942783d44a8  push rax
00007942783d44a9  push rcx
00007942783d44aa  push rdx
00007942783d44ab  push rdi
00007942783d44ac  push rsi
00007942783d44ad  push r8
00007942783d44af  push r9
00007942783d44b1  push r10
00007942783d44b3  push r11
00007942783d44b5  sub rsp, 0xF0
00007942783d44bc  vmovaps [rsp], xmm0
00007942783d44c1  vmovaps [rsp+0x10], xmm1
00007942783d44c7  vmovaps [rsp+0x20], xmm2
00007942783d44cd  vmovaps [rsp+0x30], xmm3
00007942783d44d3  vmovaps [rsp+0x40], xmm4
00007942783d44d9  vmovaps [rsp+0x50], xmm5
00007942783d44df  vmovaps [rsp+0x60], xmm6
00007942783d44e5  vmovaps [rsp+0x70], xmm7
00007942783d44eb  vmovaps [rsp+0x80], xmm8
00007942783d44f4  vmovaps [rsp+0x90], xmm9
00007942783d44fd  vmovaps [rsp+0xA0], xmm10
00007942783d4506  vmovaps [rsp+0xB0], xmm12
00007942783d450f  vmovaps [rsp+0xC0], xmm13
00007942783d4518  vmovaps [rsp+0xD0], xmm14
00007942783d4521  vmovaps [rsp+0xE0], xmm15
00007942783d452a  sub rsp, 0x30
00007942783d452e  movaps [rsp], xmm11
00007942783d4533  movaps [rsp+0x10], xmm7
00007942783d4538  movaps [rsp+0x20], xmm15
00007942783d453e  lea rdi, [rsp]
00007942783d4542  mov esi, 0x00
00007942783d4547  mov rax, 0x59DDDCBA3530
00007942783d4551  call rax
00007942783d4553  movaps xmm11, [rsp]
00007942783d4558  add rsp, 0x30
00007942783d455c  vmovaps xmm0, [rsp]
00007942783d4561  vmovaps xmm1, [rsp+0x10]
00007942783d4567  vmovaps xmm2, [rsp+0x20]
00007942783d456d  vmovaps xmm3, [rsp+0x30]
00007942783d4573  vmovaps xmm4, [rsp+0x40]
00007942783d4579  vmovaps xmm5, [rsp+0x50]
00007942783d457f  vmovaps xmm6, [rsp+0x60]
00007942783d4585  vmovaps xmm7, [rsp+0x70]
00007942783d458b  vmovaps xmm8, [rsp+0x80]
00007942783d4594  vmovaps xmm9, [rsp+0x90]
00007942783d459d  vmovaps xmm10, [rsp+0xA0]
00007942783d45a6  vmovaps xmm12, [rsp+0xB0]
00007942783d45af  vmovaps xmm13, [rsp+0xC0]
00007942783d45b8  vmovaps xmm14, [rsp+0xD0]
00007942783d45c1  vmovaps xmm15, [rsp+0xE0]
00007942783d45ca  add rsp, 0xF0
00007942783d45d1  pop r11
00007942783d45d3  pop r10
00007942783d45d5  pop r9
00007942783d45d7  pop r8
00007942783d45d9  pop rsi
00007942783d45da  pop rdi
00007942783d45db  pop rdx
00007942783d45dc  pop rcx
00007942783d45dd  pop rax
00007942783d45de  add rsp, 0x08
00007942783d45e2  jmp 0x00007942783D0123
00007942783d45e7  sub rsp, 0x08
00007942783d45eb  push rax
00007942783d45ec  push rcx
00007942783d45ed  push rdx
00007942783d45ee  push rdi
00007942783d45ef  push rsi
00007942783d45f0  push r8
00007942783d45f2  push r9
00007942783d45f4  push r10
00007942783d45f6  push r11
00007942783d45f8  sub rsp, 0xF0
00007942783d45ff  vmovaps [rsp], xmm0
00007942783d4604  vmovaps [rsp+0x10], xmm1
00007942783d460a  vmovaps [rsp+0x20], xmm2
00007942783d4610  vmovaps [rsp+0x30], xmm3
00007942783d4616  vmovaps [rsp+0x40], xmm4
00007942783d461c  vmovaps [rsp+0x50], xmm5
00007942783d4622  vmovaps [rsp+0x60], xmm6
00007942783d4628  vmovaps [rsp+0x70], xmm7
00007942783d462e  vmovaps [rsp+0x80], xmm8
00007942783d4637  vmovaps [rsp+0x90], xmm9
00007942783d4640  vmovaps [rsp+0xA0], xmm10
00007942783d4649  vmovaps [rsp+0xB0], xmm11
00007942783d4652  vmovaps [rsp+0xC0], xmm12
00007942783d465b  vmovaps [rsp+0xD0], xmm13
00007942783d4664  vmovaps [rsp+0xE0], xmm14
00007942783d466d  sub rsp, 0x30
00007942783d4671  movaps [rsp], xmm15
00007942783d4676  movaps [rsp+0x10], xmm10
00007942783d467c  movaps [rsp+0x20], xmm13
00007942783d4682  lea rdi, [rsp]
00007942783d4686  mov esi, 0x00
00007942783d468b  mov rax, 0x59DDDCBA3530
00007942783d4695  call rax
00007942783d4697  movaps xmm15, [rsp]
00007942783d469c  add rsp, 0x30
00007942783d46a0  vmovaps xmm0, [rsp]
00007942783d46a5  vmovaps xmm1, [rsp+0x10]
00007942783d46ab  vmovaps xmm2, [rsp+0x20]
00007942783d46b1  vmovaps xmm3, [rsp+0x30]
00007942783d46b7  vmovaps xmm4, [rsp+0x40]
00007942783d46bd  vmovaps xmm5, [rsp+0x50]
00007942783d46c3  vmovaps xmm6, [rsp+0x60]
00007942783d46c9  vmovaps xmm7, [rsp+0x70]
00007942783d46cf  vmovaps xmm8, [rsp+0x80]
00007942783d46d8  vmovaps xmm9, [rsp+0x90]
00007942783d46e1  vmovaps xmm10, [rsp+0xA0]
00007942783d46ea  vmovaps xmm11, [rsp+0xB0]
00007942783d46f3  vmovaps xmm12, [rsp+0xC0]
00007942783d46fc  vmovaps xmm13, [rsp+0xD0]
00007942783d4705  vmovaps xmm14, [rsp+0xE0]
00007942783d470e  add rsp, 0xF0
00007942783d4715  pop r11
00007942783d4717  pop r10
00007942783d4719  pop r9
00007942783d471b  pop r8
00007942783d471d  pop rsi
00007942783d471e  pop rdi
00007942783d471f  pop rdx
00007942783d4720  pop rcx
00007942783d4721  pop rax
00007942783d4722  add rsp, 0x08
00007942783d4726  jmp 0x00007942783D013D
00007942783d472b  sub rsp, 0x08
00007942783d472f  push rax
00007942783d4730  push rcx
00007942783d4731  push rdx
00007942783d4732  push rdi
00007942783d4733  push rsi
00007942783d4734  push r8
00007942783d4736  push r9
00007942783d4738  push r10
00007942783d473a  push r11
00007942783d473c  sub rsp, 0xF0
00007942783d4743  vmovaps [rsp], xmm0
00007942783d4748  vmovaps [rsp+0x10], xmm1
00007942783d474e  vmovaps [rsp+0x20], xmm2
00007942783d4754  vmovaps [rsp+0x30], xmm3
00007942783d475a  vmovaps [rsp+0x40], xmm4
00007942783d4760  vmovaps [rsp+0x50], xmm5
00007942783d4766  vmovaps [rsp+0x60], xmm6
00007942783d476c  vmovaps [rsp+0x70], xmm7
00007942783d4772  vmovaps [rsp+0x80], xmm8
00007942783d477b  vmovaps [rsp+0x90], xmm9
00007942783d4784  vmovaps [rsp+0xA0], xmm11
00007942783d478d  vmovaps [rsp+0xB0], xmm12
00007942783d4796  vmovaps [rsp+0xC0], xmm13
00007942783d479f  vmovaps [rsp+0xD0], xmm14
00007942783d47a8  vmovaps [rsp+0xE0], xmm15
00007942783d47b1  sub rsp, 0x30
00007942783d47b5  movaps [rsp], xmm10
00007942783d47ba  movaps [rsp+0x10], xmm7
00007942783d47bf  movaps [rsp+0x20], xmm13
00007942783d47c5  lea rdi, [rsp]
00007942783d47c9  mov esi, 0x00
00007942783d47ce  mov rax, 0x59DDDCBA3530
00007942783d47d8  call rax
00007942783d47da  movaps xmm10, [rsp]
00007942783d47df  add rsp, 0x30
00007942783d47e3  vmovaps xmm0, [rsp]
00007942783d47e8  vmovaps xmm1, [rsp+0x10]
00007942783d47ee  vmovaps xmm2, [rsp+0x20]
00007942783d47f4  vmovaps xmm3, [rsp+0x30]
00007942783d47fa  vmovaps xmm4, [rsp+0x40]
00007942783d4800  vmovaps xmm5, [rsp+0x50]
00007942783d4806  vmovaps xmm6, [rsp+0x60]
00007942783d480c  vmovaps xmm7, [rsp+0x70]
00007942783d4812  vmovaps xmm8, [rsp+0x80]
00007942783d481b  vmovaps xmm9, [rsp+0x90]
00007942783d4824  vmovaps xmm11, [rsp+0xA0]
00007942783d482d  vmovaps xmm12, [rsp+0xB0]
00007942783d4836  vmovaps xmm13, [rsp+0xC0]
00007942783d483f  vmovaps xmm14, [rsp+0xD0]
00007942783d4848  vmovaps xmm15, [rsp+0xE0]
00007942783d4851  add rsp, 0xF0
00007942783d4858  pop r11
00007942783d485a  pop r10
00007942783d485c  pop r9
00007942783d485e  pop r8
00007942783d4860  pop rsi
00007942783d4861  pop rdi
00007942783d4862  pop rdx
00007942783d4863  pop rcx
00007942783d4864  pop rax
00007942783d4865  add rsp, 0x08
00007942783d4869  jmp 0x00007942783D0169
00007942783d486e  sub rsp, 0x08
00007942783d4872  push rax
00007942783d4873  push rcx
00007942783d4874  push rdx
00007942783d4875  push rdi
00007942783d4876  push rsi
00007942783d4877  push r8
00007942783d4879  push r9
00007942783d487b  push r10
00007942783d487d  push r11
00007942783d487f  sub rsp, 0xF0
00007942783d4886  vmovaps [rsp], xmm0
00007942783d488b  vmovaps [rsp+0x10], xmm1
00007942783d4891  vmovaps [rsp+0x20], xmm2
00007942783d4897  vmovaps [rsp+0x30], xmm3
00007942783d489d  vmovaps [rsp+0x40], xmm4
00007942783d48a3  vmovaps [rsp+0x50], xmm5
00007942783d48a9  vmovaps [rsp+0x60], xmm6
00007942783d48af  vmovaps [rsp+0x70], xmm7
00007942783d48b5  vmovaps [rsp+0x80], xmm8
00007942783d48be  vmovaps [rsp+0x90], xmm9
00007942783d48c7  vmovaps [rsp+0xA0], xmm10
00007942783d48d0  vmovaps [rsp+0xB0], xmm11
00007942783d48d9  vmovaps [rsp+0xC0], xmm12
00007942783d48e2  vmovaps [rsp+0xD0], xmm14
00007942783d48eb  vmovaps [rsp+0xE0], xmm15
00007942783d48f4  sub rsp, 0x30
00007942783d48f8  movaps [rsp], xmm13
00007942783d48fd  movaps [rsp+0x10], xmm1
00007942783d4902  movaps [rsp+0x20], xmm8
00007942783d4908  lea rdi, [rsp]
00007942783d490c  mov esi, 0x00
00007942783d4911  mov rax, 0x59DDDCBA3530
00007942783d491b  call rax
00007942783d491d  movaps xmm13, [rsp]
00007942783d4922  add rsp, 0x30
00007942783d4926  vmovaps xmm0, [rsp]
00007942783d492b  vmovaps xmm1, [rsp+0x10]
00007942783d4931  vmovaps xmm2, [rsp+0x20]
00007942783d4937  vmovaps xmm3, [rsp+0x30]
00007942783d493d  vmovaps xmm4, [rsp+0x40]
00007942783d4943  vmovaps xmm5, [rsp+0x50]
00007942783d4949  vmovaps xmm6, [rsp+0x60]
00007942783d494f  vmovaps xmm7, [rsp+0x70]
00007942783d4955  vmovaps xmm8, [rsp+0x80]
00007942783d495e  vmovaps xmm9, [rsp+0x90]
00007942783d4967  vmovaps xmm10, [rsp+0xA0]
00007942783d4970  vmovaps xmm11, [rsp+0xB0]
00007942783d4979  vmovaps xmm12, [rsp+0xC0]
00007942783d4982  vmovaps xmm14, [rsp+0xD0]
00007942783d498b  vmovaps xmm15, [rsp+0xE0]
00007942783d4994  add rsp, 0xF0
00007942783d499b  pop r11
00007942783d499d  pop r10
00007942783d499f  pop r9
00007942783d49a1  pop r8
00007942783d49a3  pop rsi
00007942783d49a4  pop rdi
00007942783d49a5  pop rdx
00007942783d49a6  pop rcx
00007942783d49a7  pop rax
00007942783d49a8  add rsp, 0x08
00007942783d49ac  jmp 0x00007942783D0183
00007942783d49b1  call 0x00007942781FF430
00007942783d49b6  jmp 0x00007942783D018D
00007942783d49bb  sub rsp, 0x08
00007942783d49bf  push rax
00007942783d49c0  push rcx
00007942783d49c1  push rdx
00007942783d49c2  push rdi
00007942783d49c3  push rsi
00007942783d49c4  push r8
00007942783d49c6  push r9
00007942783d49c8  push r10
00007942783d49ca  push r11
00007942783d49cc  sub rsp, 0xF0
00007942783d49d3  vmovaps [rsp], xmm0
00007942783d49d8  vmovaps [rsp+0x10], xmm1
00007942783d49de  vmovaps [rsp+0x20], xmm2
00007942783d49e4  vmovaps [rsp+0x30], xmm3
00007942783d49ea  vmovaps [rsp+0x40], xmm4
00007942783d49f0  vmovaps [rsp+0x50], xmm5
00007942783d49f6  vmovaps [rsp+0x60], xmm6
00007942783d49fc  vmovaps [rsp+0x70], xmm7
00007942783d4a02  vmovaps [rsp+0x80], xmm9
00007942783d4a0b  vmovaps [rsp+0x90], xmm10
00007942783d4a14  vmovaps [rsp+0xA0], xmm11
00007942783d4a1d  vmovaps [rsp+0xB0], xmm12
00007942783d4a26  vmovaps [rsp+0xC0], xmm13
00007942783d4a2f  vmovaps [rsp+0xD0], xmm14
00007942783d4a38  vmovaps [rsp+0xE0], xmm15
00007942783d4a41  sub rsp, 0x30
00007942783d4a45  movaps [rsp], xmm8
00007942783d4a4a  movaps [rsp+0x10], xmm14
00007942783d4a50  movaps [rsp+0x20], xmm9
00007942783d4a56  lea rdi, [rsp]
00007942783d4a5a  mov esi, 0x00
00007942783d4a5f  mov rax, 0x59DDDCBA3530
00007942783d4a69  call rax
00007942783d4a6b  movaps xmm8, [rsp]
00007942783d4a70  add rsp, 0x30
00007942783d4a74  vmovaps xmm0, [rsp]
00007942783d4a79  vmovaps xmm1, [rsp+0x10]
00007942783d4a7f  vmovaps xmm2, [rsp+0x20]
00007942783d4a85  vmovaps xmm3, [rsp+0x30]
00007942783d4a8b  vmovaps xmm4, [rsp+0x40]
00007942783d4a91  vmovaps xmm5, [rsp+0x50]
00007942783d4a97  vmovaps xmm6, [rsp+0x60]
00007942783d4a9d  vmovaps xmm7, [rsp+0x70]
00007942783d4aa3  vmovaps xmm9, [rsp+0x80]
00007942783d4aac  vmovaps xmm10, [rsp+0x90]
00007942783d4ab5  vmovaps xmm11, [rsp+0xA0]
00007942783d4abe  vmovaps xmm12, [rsp+0xB0]
00007942783d4ac7  vmovaps xmm13, [rsp+0xC0]
00007942783d4ad0  vmovaps xmm14, [rsp+0xD0]
00007942783d4ad9  vmovaps xmm15, [rsp+0xE0]
00007942783d4ae2  add rsp, 0xF0
00007942783d4ae9  pop r11
00007942783d4aeb  pop r10
00007942783d4aed  pop r9
00007942783d4aef  pop r8
00007942783d4af1  pop rsi
00007942783d4af2  pop rdi
00007942783d4af3  pop rdx
00007942783d4af4  pop rcx
00007942783d4af5  pop rax
00007942783d4af6  add rsp, 0x08
00007942783d4afa  jmp 0x00007942783D01AF
00007942783d4aff  sub rsp, 0x08
00007942783d4b03  push rax
00007942783d4b04  push rcx
00007942783d4b05  push rdx
00007942783d4b06  push rdi
00007942783d4b07  push rsi
00007942783d4b08  push r8
00007942783d4b0a  push r9
00007942783d4b0c  push r10
00007942783d4b0e  push r11
00007942783d4b10  sub rsp, 0xF0
00007942783d4b17  vmovaps [rsp], xmm0
00007942783d4b1c  vmovaps [rsp+0x10], xmm1
00007942783d4b22  vmovaps [rsp+0x20], xmm2
00007942783d4b28  vmovaps [rsp+0x30], xmm3
00007942783d4b2e  vmovaps [rsp+0x40], xmm4
00007942783d4b34  vmovaps [rsp+0x50], xmm5
00007942783d4b3a  vmovaps [rsp+0x60], xmm6
00007942783d4b40  vmovaps [rsp+0x70], xmm7
00007942783d4b46  vmovaps [rsp+0x80], xmm8
00007942783d4b4f  vmovaps [rsp+0x90], xmm10
00007942783d4b58  vmovaps [rsp+0xA0], xmm11
00007942783d4b61  vmovaps [rsp+0xB0], xmm12
00007942783d4b6a  vmovaps [rsp+0xC0], xmm13
00007942783d4b73  vmovaps [rsp+0xD0], xmm14
00007942783d4b7c  vmovaps [rsp+0xE0], xmm15
00007942783d4b85  sub rsp, 0x30
00007942783d4b89  movaps [rsp], xmm9
00007942783d4b8e  movaps [rsp+0x10], xmm1
00007942783d4b93  movaps [rsp+0x20], xmm14
00007942783d4b99  lea rdi, [rsp]
00007942783d4b9d  mov esi, 0x00
00007942783d4ba2  mov rax, 0x59DDDCBA3530
00007942783d4bac  call rax
00007942783d4bae  movaps xmm9, [rsp]
00007942783d4bb3  add rsp, 0x30
00007942783d4bb7  vmovaps xmm0, [rsp]
00007942783d4bbc  vmovaps xmm1, [rsp+0x10]
00007942783d4bc2  vmovaps xmm2, [rsp+0x20]
00007942783d4bc8  vmovaps xmm3, [rsp+0x30]
00007942783d4bce  vmovaps xmm4, [rsp+0x40]
00007942783d4bd4  vmovaps xmm5, [rsp+0x50]
00007942783d4bda  vmovaps xmm6, [rsp+0x60]
00007942783d4be0  vmovaps xmm7, [rsp+0x70]
00007942783d4be6  vmovaps xmm8, [rsp+0x80]
00007942783d4bef  vmovaps xmm10, [rsp+0x90]
00007942783d4bf8  vmovaps xmm11, [rsp+0xA0]
00007942783d4c01  vmovaps xmm12, [rsp+0xB0]
00007942783d4c0a  vmovaps xmm13, [rsp+0xC0]
00007942783d4c13  vmovaps xmm14, [rsp+0xD0]
00007942783d4c1c  vmovaps xmm15, [rsp+0xE0]
00007942783d4c25  add rsp, 0xF0
00007942783d4c2c  pop r11
00007942783d4c2e  pop r10
00007942783d4c30  pop r9
00007942783d4c32  pop r8
00007942783d4c34  pop rsi
00007942783d4c35  pop rdi
00007942783d4c36  pop rdx
00007942783d4c37  pop rcx
00007942783d4c38  pop rax
00007942783d4c39  add rsp, 0x08
00007942783d4c3d  jmp 0x00007942783D01DD
00007942783d4c42  sub rsp, 0x08
00007942783d4c46  push rax
00007942783d4c47  push rcx
00007942783d4c48  push rdx
00007942783d4c49  push rdi
00007942783d4c4a  push rsi
00007942783d4c4b  push r8
00007942783d4c4d  push r9
00007942783d4c4f  push r10
00007942783d4c51  push r11
00007942783d4c53  sub rsp, 0xF0
00007942783d4c5a  vmovaps [rsp], xmm0
00007942783d4c5f  vmovaps [rsp+0x10], xmm1
00007942783d4c65  vmovaps [rsp+0x20], xmm2
00007942783d4c6b  vmovaps [rsp+0x30], xmm3
00007942783d4c71  vmovaps [rsp+0x40], xmm4
00007942783d4c77  vmovaps [rsp+0x50], xmm5
00007942783d4c7d  vmovaps [rsp+0x60], xmm6
00007942783d4c83  vmovaps [rsp+0x70], xmm7
00007942783d4c89  vmovaps [rsp+0x80], xmm8
00007942783d4c92  vmovaps [rsp+0x90], xmm9
00007942783d4c9b  vmovaps [rsp+0xA0], xmm10
00007942783d4ca4  vmovaps [rsp+0xB0], xmm11
00007942783d4cad  vmovaps [rsp+0xC0], xmm12
00007942783d4cb6  vmovaps [rsp+0xD0], xmm13
00007942783d4cbf  vmovaps [rsp+0xE0], xmm15
00007942783d4cc8  sub rsp, 0x30
00007942783d4ccc  movaps [rsp], xmm14
00007942783d4cd1  movaps [rsp+0x10], xmm4
00007942783d4cd6  movaps [rsp+0x20], xmm1
00007942783d4cdb  lea rdi, [rsp]
00007942783d4cdf  mov esi, 0x00
00007942783d4ce4  mov rax, 0x59DDDCBA3530
00007942783d4cee  call rax
00007942783d4cf0  movaps xmm14, [rsp]
00007942783d4cf5  add rsp, 0x30
00007942783d4cf9  vmovaps xmm0, [rsp]
00007942783d4cfe  vmovaps xmm1, [rsp+0x10]
00007942783d4d04  vmovaps xmm2, [rsp+0x20]
00007942783d4d0a  vmovaps xmm3, [rsp+0x30]
00007942783d4d10  vmovaps xmm4, [rsp+0x40]
00007942783d4d16  vmovaps xmm5, [rsp+0x50]
00007942783d4d1c  vmovaps xmm6, [rsp+0x60]
00007942783d4d22  vmovaps xmm7, [rsp+0x70]
00007942783d4d28  vmovaps xmm8, [rsp+0x80]
00007942783d4d31  vmovaps xmm9, [rsp+0x90]
00007942783d4d3a  vmovaps xmm10, [rsp+0xA0]
00007942783d4d43  vmovaps xmm11, [rsp+0xB0]
00007942783d4d4c  vmovaps xmm12, [rsp+0xC0]
00007942783d4d55  vmovaps xmm13, [rsp+0xD0]
00007942783d4d5e  vmovaps xmm15, [rsp+0xE0]
00007942783d4d67  add rsp, 0xF0
00007942783d4d6e  pop r11
00007942783d4d70  pop r10
00007942783d4d72  pop r9
00007942783d4d74  pop r8
00007942783d4d76  pop rsi
00007942783d4d77  pop rdi
00007942783d4d78  pop rdx
00007942783d4d79  pop rcx
00007942783d4d7a  pop rax
00007942783d4d7b  add rsp, 0x08
00007942783d4d7f  jmp 0x00007942783D0203
00007942783d4d84  sub rsp, 0x08
00007942783d4d88  push rax
00007942783d4d89  push rcx
00007942783d4d8a  push rdx
00007942783d4d8b  push rdi
00007942783d4d8c  push rsi
00007942783d4d8d  push r8
00007942783d4d8f  push r9
00007942783d4d91  push r10
00007942783d4d93  push r11
00007942783d4d95  sub rsp, 0xF0
00007942783d4d9c  vmovaps [rsp], xmm0
00007942783d4da1  vmovaps [rsp+0x10], xmm2
00007942783d4da7  vmovaps [rsp+0x20], xmm3
00007942783d4dad  vmovaps [rsp+0x30], xmm4
00007942783d4db3  vmovaps [rsp+0x40], xmm5
00007942783d4db9  vmovaps [rsp+0x50], xmm6
00007942783d4dbf  vmovaps [rsp+0x60], xmm7
00007942783d4dc5  vmovaps [rsp+0x70], xmm8
00007942783d4dcb  vmovaps [rsp+0x80], xmm9
00007942783d4dd4  vmovaps [rsp+0x90], xmm10
00007942783d4ddd  vmovaps [rsp+0xA0], xmm11
00007942783d4de6  vmovaps [rsp+0xB0], xmm12
00007942783d4def  vmovaps [rsp+0xC0], xmm13
00007942783d4df8  vmovaps [rsp+0xD0], xmm14
00007942783d4e01  vmovaps [rsp+0xE0], xmm15
00007942783d4e0a  sub rsp, 0x30
00007942783d4e0e  movaps [rsp], xmm1
00007942783d4e12  movaps [rsp+0x10], xmm12
00007942783d4e18  movaps [rsp+0x20], xmm11
00007942783d4e1e  lea rdi, [rsp]
00007942783d4e22  mov esi, 0x00
00007942783d4e27  mov rax, 0x59DDDCBA3530
00007942783d4e31  call rax
00007942783d4e33  movaps xmm1, [rsp]
00007942783d4e37  add rsp, 0x30
00007942783d4e3b  vmovaps xmm0, [rsp]
00007942783d4e40  vmovaps xmm2, [rsp+0x10]
00007942783d4e46  vmovaps xmm3, [rsp+0x20]
00007942783d4e4c  vmovaps xmm4, [rsp+0x30]
00007942783d4e52  vmovaps xmm5, [rsp+0x40]
00007942783d4e58  vmovaps xmm6, [rsp+0x50]
00007942783d4e5e  vmovaps xmm7, [rsp+0x60]
00007942783d4e64  vmovaps xmm8, [rsp+0x70]
00007942783d4e6a  vmovaps xmm9, [rsp+0x80]
00007942783d4e73  vmovaps xmm10, [rsp+0x90]
00007942783d4e7c  vmovaps xmm11, [rsp+0xA0]
00007942783d4e85  vmovaps xmm12, [rsp+0xB0]
00007942783d4e8e  vmovaps xmm13, [rsp+0xC0]
00007942783d4e97  vmovaps xmm14, [rsp+0xD0]
00007942783d4ea0  vmovaps xmm15, [rsp+0xE0]
00007942783d4ea9  add rsp, 0xF0
00007942783d4eb0  pop r11
00007942783d4eb2  pop r10
00007942783d4eb4  pop r9
00007942783d4eb6  pop r8
00007942783d4eb8  pop rsi
00007942783d4eb9  pop rdi
00007942783d4eba  pop rdx
00007942783d4ebb  pop rcx
00007942783d4ebc  pop rax
00007942783d4ebd  add rsp, 0x08
00007942783d4ec1  jmp 0x00007942783D0224
00007942783d4ec6  call 0x00007942782E20A0
00007942783d4ecb  jmp 0x00007942783D0232
00007942783d4ed0  call 0x0000794278209D70
00007942783d4ed5  jmp 0x00007942783D023C
00007942783d4eda  sub rsp, 0x08
00007942783d4ede  push rax
00007942783d4edf  push rcx
00007942783d4ee0  push rdx
00007942783d4ee1  push rdi
00007942783d4ee2  push rsi
00007942783d4ee3  push r8
00007942783d4ee5  push r9
00007942783d4ee7  push r10
00007942783d4ee9  push r11
00007942783d4eeb  sub rsp, 0xF0
00007942783d4ef2  vmovaps [rsp], xmm0
00007942783d4ef7  vmovaps [rsp+0x10], xmm1
00007942783d4efd  vmovaps [rsp+0x20], xmm2
00007942783d4f03  vmovaps [rsp+0x30], xmm3
00007942783d4f09  vmovaps [rsp+0x40], xmm4
00007942783d4f0f  vmovaps [rsp+0x50], xmm5
00007942783d4f15  vmovaps [rsp+0x60], xmm6
00007942783d4f1b  vmovaps [rsp+0x70], xmm8
00007942783d4f21  vmovaps [rsp+0x80], xmm9
00007942783d4f2a  vmovaps [rsp+0x90], xmm10
00007942783d4f33  vmovaps [rsp+0xA0], xmm11
00007942783d4f3c  vmovaps [rsp+0xB0], xmm12
00007942783d4f45  vmovaps [rsp+0xC0], xmm13
00007942783d4f4e  vmovaps [rsp+0xD0], xmm14
00007942783d4f57  vmovaps [rsp+0xE0], xmm15
00007942783d4f60  sub rsp, 0x30
00007942783d4f64  movaps [rsp], xmm7
00007942783d4f68  movaps [rsp+0x10], xmm15
00007942783d4f6e  movaps [rsp+0x20], xmm10
00007942783d4f74  lea rdi, [rsp]
00007942783d4f78  mov esi, 0x00
00007942783d4f7d  mov rax, 0x59DDDCBA3530
00007942783d4f87  call rax
00007942783d4f89  movaps xmm7, [rsp]
00007942783d4f8d  add rsp, 0x30
00007942783d4f91  vmovaps xmm0, [rsp]
00007942783d4f96  vmovaps xmm1, [rsp+0x10]
00007942783d4f9c  vmovaps xmm2, [rsp+0x20]
00007942783d4fa2  vmovaps xmm3, [rsp+0x30]
00007942783d4fa8  vmovaps xmm4, [rsp+0x40]
00007942783d4fae  vmovaps xmm5, [rsp+0x50]
00007942783d4fb4  vmovaps xmm6, [rsp+0x60]
00007942783d4fba  vmovaps xmm8, [rsp+0x70]
00007942783d4fc0  vmovaps xmm9, [rsp+0x80]
00007942783d4fc9  vmovaps xmm10, [rsp+0x90]
00007942783d4fd2  vmovaps xmm11, [rsp+0xA0]
00007942783d4fdb  vmovaps xmm12, [rsp+0xB0]
00007942783d4fe4  vmovaps xmm13, [rsp+0xC0]
00007942783d4fed  vmovaps xmm14, [rsp+0xD0]
00007942783d4ff6  vmovaps xmm15, [rsp+0xE0]
00007942783d4fff  add rsp, 0xF0
00007942783d5006  pop r11
00007942783d5008  pop r10
00007942783d500a  pop r9
00007942783d500c  pop r8
00007942783d500e  pop rsi
00007942783d500f  pop rdi
00007942783d5010  pop rdx
00007942783d5011  pop rcx
00007942783d5012  pop rax
00007942783d5013  add rsp, 0x08
00007942783d5017  jmp 0x00007942783D025D
00007942783d501c  sub rsp, 0x08
00007942783d5020  push rax
00007942783d5021  push rcx
00007942783d5022  push rdx
00007942783d5023  push rdi
00007942783d5024  push rsi
00007942783d5025  push r8
00007942783d5027  push r9
00007942783d5029  push r10
00007942783d502b  push r11
00007942783d502d  sub rsp, 0xF0
00007942783d5034  vmovaps [rsp], xmm0
00007942783d5039  vmovaps [rsp+0x10], xmm1
00007942783d503f  vmovaps [rsp+0x20], xmm2
00007942783d5045  vmovaps [rsp+0x30], xmm3
00007942783d504b  vmovaps [rsp+0x40], xmm4
00007942783d5051  vmovaps [rsp+0x50], xmm5
00007942783d5057  vmovaps [rsp+0x60], xmm6
00007942783d505d  vmovaps [rsp+0x70], xmm7
00007942783d5063  vmovaps [rsp+0x80], xmm8
00007942783d506c  vmovaps [rsp+0x90], xmm9
00007942783d5075  vmovaps [rsp+0xA0], xmm11
00007942783d507e  vmovaps [rsp+0xB0], xmm12
00007942783d5087  vmovaps [rsp+0xC0], xmm13
00007942783d5090  vmovaps [rsp+0xD0], xmm14
00007942783d5099  vmovaps [rsp+0xE0], xmm15
00007942783d50a2  sub rsp, 0x30
00007942783d50a6  movaps [rsp], xmm10
00007942783d50ab  movaps [rsp+0x10], xmm11
00007942783d50b1  movaps [rsp+0x20], xmm15
00007942783d50b7  lea rdi, [rsp]
00007942783d50bb  mov esi, 0x00
00007942783d50c0  mov rax, 0x59DDDCBA3530
00007942783d50ca  call rax
00007942783d50cc  movaps xmm10, [rsp]
00007942783d50d1  add rsp, 0x30
00007942783d50d5  vmovaps xmm0, [rsp]
00007942783d50da  vmovaps xmm1, [rsp+0x10]
00007942783d50e0  vmovaps xmm2, [rsp+0x20]
00007942783d50e6  vmovaps xmm3, [rsp+0x30]
00007942783d50ec  vmovaps xmm4, [rsp+0x40]
00007942783d50f2  vmovaps xmm5, [rsp+0x50]
00007942783d50f8  vmovaps xmm6, [rsp+0x60]
00007942783d50fe  vmovaps xmm7, [rsp+0x70]
00007942783d5104  vmovaps xmm8, [rsp+0x80]
00007942783d510d  vmovaps xmm9, [rsp+0x90]
00007942783d5116  vmovaps xmm11, [rsp+0xA0]
00007942783d511f  vmovaps xmm12, [rsp+0xB0]
00007942783d5128  vmovaps xmm13, [rsp+0xC0]
00007942783d5131  vmovaps xmm14, [rsp+0xD0]
00007942783d513a  vmovaps xmm15, [rsp+0xE0]
00007942783d5143  add rsp, 0xF0
00007942783d514a  pop r11
00007942783d514c  pop r10
00007942783d514e  pop r9
00007942783d5150  pop r8
00007942783d5152  pop rsi
00007942783d5153  pop rdi
00007942783d5154  pop rdx
00007942783d5155  pop rcx
00007942783d5156  pop rax
00007942783d5157  add rsp, 0x08
00007942783d515b  jmp 0x00007942783D028B
00007942783d5160  sub rsp, 0x08
00007942783d5164  push rax
00007942783d5165  push rcx
00007942783d5166  push rdx
00007942783d5167  push rdi
00007942783d5168  push rsi
00007942783d5169  push r8
00007942783d516b  push r9
00007942783d516d  push r10
00007942783d516f  push r11
00007942783d5171  sub rsp, 0xF0
00007942783d5178  vmovaps [rsp], xmm0
00007942783d517d  vmovaps [rsp+0x10], xmm1
00007942783d5183  vmovaps [rsp+0x20], xmm2
00007942783d5189  vmovaps [rsp+0x30], xmm3
00007942783d518f  vmovaps [rsp+0x40], xmm4
00007942783d5195  vmovaps [rsp+0x50], xmm5
00007942783d519b  vmovaps [rsp+0x60], xmm6
00007942783d51a1  vmovaps [rsp+0x70], xmm7
00007942783d51a7  vmovaps [rsp+0x80], xmm8
00007942783d51b0  vmovaps [rsp+0x90], xmm9
00007942783d51b9  vmovaps [rsp+0xA0], xmm10
00007942783d51c2  vmovaps [rsp+0xB0], xmm12
00007942783d51cb  vmovaps [rsp+0xC0], xmm13
00007942783d51d4  vmovaps [rsp+0xD0], xmm14
00007942783d51dd  vmovaps [rsp+0xE0], xmm15
00007942783d51e6  sub rsp, 0x30
00007942783d51ea  movaps [rsp], xmm11
00007942783d51ef  movaps [rsp+0x10], xmm12
00007942783d51f5  movaps [rsp+0x20], xmm15
00007942783d51fb  lea rdi, [rsp]
00007942783d51ff  mov esi, 0x00
00007942783d5204  mov rax, 0x59DDDCBA3530
00007942783d520e  call rax
00007942783d5210  movaps xmm11, [rsp]
00007942783d5215  add rsp, 0x30
00007942783d5219  vmovaps xmm0, [rsp]
00007942783d521e  vmovaps xmm1, [rsp+0x10]
00007942783d5224  vmovaps xmm2, [rsp+0x20]
00007942783d522a  vmovaps xmm3, [rsp+0x30]
00007942783d5230  vmovaps xmm4, [rsp+0x40]
00007942783d5236  vmovaps xmm5, [rsp+0x50]
00007942783d523c  vmovaps xmm6, [rsp+0x60]
00007942783d5242  vmovaps xmm7, [rsp+0x70]
00007942783d5248  vmovaps xmm8, [rsp+0x80]
00007942783d5251  vmovaps xmm9, [rsp+0x90]
00007942783d525a  vmovaps xmm10, [rsp+0xA0]
00007942783d5263  vmovaps xmm12, [rsp+0xB0]
00007942783d526c  vmovaps xmm13, [rsp+0xC0]
00007942783d5275  vmovaps xmm14, [rsp+0xD0]
00007942783d527e  vmovaps xmm15, [rsp+0xE0]
00007942783d5287  add rsp, 0xF0
00007942783d528e  pop r11
00007942783d5290  pop r10
00007942783d5292  pop r9
00007942783d5294  pop r8
00007942783d5296  pop rsi
00007942783d5297  pop rdi
00007942783d5298  pop rdx
00007942783d5299  pop rcx
00007942783d529a  pop rax
00007942783d529b  add rsp, 0x08
00007942783d529f  jmp 0x00007942783D02B9
00007942783d52a4  sub rsp, 0x08
00007942783d52a8  push rax
00007942783d52a9  push rcx
00007942783d52aa  push rdx
00007942783d52ab  push rdi
00007942783d52ac  push rsi
00007942783d52ad  push r8
00007942783d52af  push r9
00007942783d52b1  push r10
00007942783d52b3  push r11
00007942783d52b5  sub rsp, 0xF0
00007942783d52bc  vmovaps [rsp], xmm0
00007942783d52c1  vmovaps [rsp+0x10], xmm1
00007942783d52c7  vmovaps [rsp+0x20], xmm2
00007942783d52cd  vmovaps [rsp+0x30], xmm3
00007942783d52d3  vmovaps [rsp+0x40], xmm4
00007942783d52d9  vmovaps [rsp+0x50], xmm5
00007942783d52df  vmovaps [rsp+0x60], xmm6
00007942783d52e5  vmovaps [rsp+0x70], xmm7
00007942783d52eb  vmovaps [rsp+0x80], xmm8
00007942783d52f4  vmovaps [rsp+0x90], xmm9
00007942783d52fd  vmovaps [rsp+0xA0], xmm10
00007942783d5306  vmovaps [rsp+0xB0], xmm11
00007942783d530f  vmovaps [rsp+0xC0], xmm12
00007942783d5318  vmovaps [rsp+0xD0], xmm13
00007942783d5321  vmovaps [rsp+0xE0], xmm14
00007942783d532a  sub rsp, 0x30
00007942783d532e  movaps [rsp], xmm15
00007942783d5333  movaps [rsp+0x10], xmm13
00007942783d5339  movaps [rsp+0x20], xmm9
00007942783d533f  lea rdi, [rsp]
00007942783d5343  mov esi, 0x00
00007942783d5348  mov rax, 0x59DDDCBA3530
00007942783d5352  call rax
00007942783d5354  movaps xmm15, [rsp]
00007942783d5359  add rsp, 0x30
00007942783d535d  vmovaps xmm0, [rsp]
00007942783d5362  vmovaps xmm1, [rsp+0x10]
00007942783d5368  vmovaps xmm2, [rsp+0x20]
00007942783d536e  vmovaps xmm3, [rsp+0x30]
00007942783d5374  vmovaps xmm4, [rsp+0x40]
00007942783d537a  vmovaps xmm5, [rsp+0x50]
00007942783d5380  vmovaps xmm6, [rsp+0x60]
00007942783d5386  vmovaps xmm7, [rsp+0x70]
00007942783d538c  vmovaps xmm8, [rsp+0x80]
00007942783d5395  vmovaps xmm9, [rsp+0x90]
00007942783d539e  vmovaps xmm10, [rsp+0xA0]
00007942783d53a7  vmovaps xmm11, [rsp+0xB0]
00007942783d53b0  vmovaps xmm12, [rsp+0xC0]
00007942783d53b9  vmovaps xmm13, [rsp+0xD0]
00007942783d53c2  vmovaps xmm14, [rsp+0xE0]
00007942783d53cb  add rsp, 0xF0
00007942783d53d2  pop r11
00007942783d53d4  pop r10
00007942783d53d6  pop r9
00007942783d53d8  pop r8
00007942783d53da  pop rsi
00007942783d53db  pop rdi
00007942783d53dc  pop rdx
00007942783d53dd  pop rcx
00007942783d53de  pop rax
00007942783d53df  add rsp, 0x08
00007942783d53e3  jmp 0x00007942783D02D4
00007942783d53e8  sub rsp, 0x08
00007942783d53ec  push rax
00007942783d53ed  push rcx
00007942783d53ee  push rdx
00007942783d53ef  push rdi
00007942783d53f0  push rsi
00007942783d53f1  push r8
00007942783d53f3  push r9
00007942783d53f5  push r10
00007942783d53f7  push r11
00007942783d53f9  sub rsp, 0xF0
00007942783d5400  vmovaps [rsp], xmm0
00007942783d5405  vmovaps [rsp+0x10], xmm1
00007942783d540b  vmovaps [rsp+0x20], xmm2
00007942783d5411  vmovaps [rsp+0x30], xmm3
00007942783d5417  vmovaps [rsp+0x40], xmm4
00007942783d541d  vmovaps [rsp+0x50], xmm5
00007942783d5423  vmovaps [rsp+0x60], xmm6
00007942783d5429  vmovaps [rsp+0x70], xmm7
00007942783d542f  vmovaps [rsp+0x80], xmm8
00007942783d5438  vmovaps [rsp+0x90], xmm9
00007942783d5441  vmovaps [rsp+0xA0], xmm10
00007942783d544a  vmovaps [rsp+0xB0], xmm11
00007942783d5453  vmovaps [rsp+0xC0], xmm12
00007942783d545c  vmovaps [rsp+0xD0], xmm14
00007942783d5465  vmovaps [rsp+0xE0], xmm15
00007942783d546e  sub rsp, 0x30
00007942783d5472  movaps [rsp], xmm13
00007942783d5477  movaps [rsp+0x10], xmm8
00007942783d547d  movaps [rsp+0x20], xmm14
00007942783d5483  lea rdi, [rsp]
00007942783d5487  mov esi, 0x00
00007942783d548c  mov rax, 0x59DDDCBA3530
00007942783d5496  call rax
00007942783d5498  movaps xmm13, [rsp]
00007942783d549d  add rsp, 0x30
00007942783d54a1  vmovaps xmm0, [rsp]
00007942783d54a6  vmovaps xmm1, [rsp+0x10]
00007942783d54ac  vmovaps xmm2, [rsp+0x20]
00007942783d54b2  vmovaps xmm3, [rsp+0x30]
00007942783d54b8  vmovaps xmm4, [rsp+0x40]
00007942783d54be  vmovaps xmm5, [rsp+0x50]
00007942783d54c4  vmovaps xmm6, [rsp+0x60]
00007942783d54ca  vmovaps xmm7, [rsp+0x70]
00007942783d54d0  vmovaps xmm8, [rsp+0x80]
00007942783d54d9  vmovaps xmm9, [rsp+0x90]
00007942783d54e2  vmovaps xmm10, [rsp+0xA0]
00007942783d54eb  vmovaps xmm11, [rsp+0xB0]
00007942783d54f4  vmovaps xmm12, [rsp+0xC0]
00007942783d54fd  vmovaps xmm14, [rsp+0xD0]
00007942783d5506  vmovaps xmm15, [rsp+0xE0]
00007942783d550f  add rsp, 0xF0
00007942783d5516  pop r11
00007942783d5518  pop r10
00007942783d551a  pop r9
00007942783d551c  pop r8
00007942783d551e  pop rsi
00007942783d551f  pop rdi
00007942783d5520  pop rdx
00007942783d5521  pop rcx
00007942783d5522  pop rax
00007942783d5523  add rsp, 0x08
00007942783d5527  jmp 0x00007942783D02F7
00007942783d552c  sub rsp, 0x08
00007942783d5530  push rax
00007942783d5531  push rcx
00007942783d5532  push rdx
00007942783d5533  push rdi
00007942783d5534  push rsi
00007942783d5535  push r8
00007942783d5537  push r9
00007942783d5539  push r10
00007942783d553b  push r11
00007942783d553d  sub rsp, 0xF0
00007942783d5544  vmovaps [rsp], xmm0
00007942783d5549  vmovaps [rsp+0x10], xmm1
00007942783d554f  vmovaps [rsp+0x20], xmm2
00007942783d5555  vmovaps [rsp+0x30], xmm3
00007942783d555b  vmovaps [rsp+0x40], xmm4
00007942783d5561  vmovaps [rsp+0x50], xmm5
00007942783d5567  vmovaps [rsp+0x60], xmm6
00007942783d556d  vmovaps [rsp+0x70], xmm7
00007942783d5573  vmovaps [rsp+0x80], xmm8
00007942783d557c  vmovaps [rsp+0x90], xmm9
00007942783d5585  vmovaps [rsp+0xA0], xmm10
00007942783d558e  vmovaps [rsp+0xB0], xmm11
00007942783d5597  vmovaps [rsp+0xC0], xmm12
00007942783d55a0  vmovaps [rsp+0xD0], xmm13
00007942783d55a9  vmovaps [rsp+0xE0], xmm15
00007942783d55b2  sub rsp, 0x30
00007942783d55b6  movaps [rsp], xmm14
00007942783d55bb  movaps [rsp+0x10], xmm1
00007942783d55c0  movaps [rsp+0x20], xmm10
00007942783d55c6  lea rdi, [rsp]
00007942783d55ca  mov esi, 0x00
00007942783d55cf  mov rax, 0x59DDDCBA3530
00007942783d55d9  call rax
00007942783d55db  movaps xmm14, [rsp]
00007942783d55e0  add rsp, 0x30
00007942783d55e4  vmovaps xmm0, [rsp]
00007942783d55e9  vmovaps xmm1, [rsp+0x10]
00007942783d55ef  vmovaps xmm2, [rsp+0x20]
00007942783d55f5  vmovaps xmm3, [rsp+0x30]
00007942783d55fb  vmovaps xmm4, [rsp+0x40]
00007942783d5601  vmovaps xmm5, [rsp+0x50]
00007942783d5607  vmovaps xmm6, [rsp+0x60]
00007942783d560d  vmovaps xmm7, [rsp+0x70]
00007942783d5613  vmovaps xmm8, [rsp+0x80]
00007942783d561c  vmovaps xmm9, [rsp+0x90]
00007942783d5625  vmovaps xmm10, [rsp+0xA0]
00007942783d562e  vmovaps xmm11, [rsp+0xB0]
00007942783d5637  vmovaps xmm12, [rsp+0xC0]
00007942783d5640  vmovaps xmm13, [rsp+0xD0]
00007942783d5649  vmovaps xmm15, [rsp+0xE0]
00007942783d5652  add rsp, 0xF0
00007942783d5659  pop r11
00007942783d565b  pop r10
00007942783d565d  pop r9
00007942783d565f  pop r8
00007942783d5661  pop rsi
00007942783d5662  pop rdi
00007942783d5663  pop rdx
00007942783d5664  pop rcx
00007942783d5665  pop rax
00007942783d5666  add rsp, 0x08
00007942783d566a  jmp 0x00007942783D031A
00007942783d566f  sub rsp, 0x08
00007942783d5673  push rax
00007942783d5674  push rcx
00007942783d5675  push rdx
00007942783d5676  push rdi
00007942783d5677  push rsi
00007942783d5678  push r8
00007942783d567a  push r9
00007942783d567c  push r10
00007942783d567e  push r11
00007942783d5680  sub rsp, 0xF0
00007942783d5687  vmovaps [rsp], xmm0
00007942783d568c  vmovaps [rsp+0x10], xmm2
00007942783d5692  vmovaps [rsp+0x20], xmm3
00007942783d5698  vmovaps [rsp+0x30], xmm4
00007942783d569e  vmovaps [rsp+0x40], xmm5
00007942783d56a4  vmovaps [rsp+0x50], xmm6
00007942783d56aa  vmovaps [rsp+0x60], xmm7
00007942783d56b0  vmovaps [rsp+0x70], xmm8
00007942783d56b6  vmovaps [rsp+0x80], xmm9
00007942783d56bf  vmovaps [rsp+0x90], xmm10
00007942783d56c8  vmovaps [rsp+0xA0], xmm11
00007942783d56d1  vmovaps [rsp+0xB0], xmm12
00007942783d56da  vmovaps [rsp+0xC0], xmm13
00007942783d56e3  vmovaps [rsp+0xD0], xmm14
00007942783d56ec  vmovaps [rsp+0xE0], xmm15
00007942783d56f5  sub rsp, 0x30
00007942783d56f9  movaps [rsp], xmm1
00007942783d56fd  movaps [rsp+0x10], xmm7
00007942783d5702  movaps [rsp+0x20], xmm11
00007942783d5708  lea rdi, [rsp]
00007942783d570c  mov esi, 0x00
00007942783d5711  mov rax, 0x59DDDCBA3530
00007942783d571b  call rax
00007942783d571d  movaps xmm1, [rsp]
00007942783d5721  add rsp, 0x30
00007942783d5725  vmovaps xmm0, [rsp]
00007942783d572a  vmovaps xmm2, [rsp+0x10]
00007942783d5730  vmovaps xmm3, [rsp+0x20]
00007942783d5736  vmovaps xmm4, [rsp+0x30]
00007942783d573c  vmovaps xmm5, [rsp+0x40]
00007942783d5742  vmovaps xmm6, [rsp+0x50]
00007942783d5748  vmovaps xmm7, [rsp+0x60]
00007942783d574e  vmovaps xmm8, [rsp+0x70]
00007942783d5754  vmovaps xmm9, [rsp+0x80]
00007942783d575d  vmovaps xmm10, [rsp+0x90]
00007942783d5766  vmovaps xmm11, [rsp+0xA0]
00007942783d576f  vmovaps xmm12, [rsp+0xB0]
00007942783d5778  vmovaps xmm13, [rsp+0xC0]
00007942783d5781  vmovaps xmm14, [rsp+0xD0]
00007942783d578a  vmovaps xmm15, [rsp+0xE0]
00007942783d5793  add rsp, 0xF0
00007942783d579a  pop r11
00007942783d579c  pop r10
00007942783d579e  pop r9
00007942783d57a0  pop r8
00007942783d57a2  pop rsi
00007942783d57a3  pop rdi
00007942783d57a4  pop rdx
00007942783d57a5  pop rcx
00007942783d57a6  pop rax
00007942783d57a7  add rsp, 0x08
00007942783d57ab  jmp 0x00007942783D033B
00007942783d57b0  call 0x000079427820E880
00007942783d57b5  jmp 0x00007942783D034E
00007942783d57ba  call 0x000079427820C380
00007942783d57bf  jmp 0x00007942783D0359
00007942783d57c4  call 0x000079427820D600
00007942783d57c9  jmp 0x00007942783D0364
00007942783d57ce  call 0x00007942781FF540
00007942783d57d3  jmp 0x00007942783D036F
00007942783d57d8  int3
00007942783d57d9  nop [rax], eax
00007942783d57e0  mov rax, [r15+0x40]
00007942783d57e4  mov r14, [r15+0x58]
00007942783d57e8  lea r12, [rax+r14*1]
00007942783d57ec  movaps xmm1, [r15+0x1D0]
00007942783d57f4  vmovaps [rsp+0x10], xmm1
00007942783d57fa  vmovaps xmm15, [rsp+0x10]
00007942783d5800  por xmm1, xmm15
00007942783d5805  movaps xmm14, [r15+0x1A0]
00007942783d580d  vmovaps [rsp+0x10], xmm14
00007942783d5813  vmovaps xmm13, [rsp+0x10]
00007942783d5819  por xmm14, xmm13
00007942783d581e  lea rax, [r12+0x30]
00007942783d5823  mov r11, [r13+rax*1]
00007942783d5828  lea rax, [r12+0x38]
00007942783d582d  mov r10, [r13+rax*1]
00007942783d5832  movq xmm13, r11
00007942783d5837  movq xmm12, r10
00007942783d583c  movq xmm13, xmm13
00007942783d5841  vmovaps [rsp+0x10], xmm13
00007942783d5847  movq xmm13, xmm13
00007942783d584c  movaps [r15+0x130], xmm13
00007942783d5854  movq xmm12, xmm12
00007942783d5859  vmovaps [rsp+0x20], xmm12
00007942783d585f  movq xmm12, xmm12
00007942783d5864  movaps [r15+0x280], xmm12
00007942783d586c  movaps xmm13, [r15+0x270]
00007942783d5874  vmovaps [rsp+0x30], xmm13
00007942783d587a  vmovaps xmm12, [rsp+0x30]
00007942783d5880  por xmm13, xmm12
00007942783d5885  lea rax, [r12+0x20]
00007942783d588a  mov r11, [r13+rax*1]
00007942783d588f  lea rax, [r12+0x28]
00007942783d5894  mov r10, [r13+rax*1]
00007942783d5899  movq xmm12, r11
00007942783d589e  movq xmm11, r10
00007942783d58a3  movq xmm12, xmm12
00007942783d58a8  vmovaps [rsp+0x30], xmm12
00007942783d58ae  movq xmm12, xmm12
00007942783d58b3  movaps [r15+0x150], xmm12
00007942783d58bb  movq xmm11, xmm11
00007942783d58c0  vmovaps [rsp+0x40], xmm11
00007942783d58c6  movq xmm11, xmm11
00007942783d58cb  movaps [r15+0x140], xmm11
00007942783d58d3  lea rax, [r12+0x10]
00007942783d58d8  mov r11, [r13+rax*1]
00007942783d58dd  lea rax, [r12+0x18]
00007942783d58e2  mov r10, [r13+rax*1]
00007942783d58e7  movq xmm12, r11
00007942783d58ec  movq xmm11, r10
00007942783d58f1  movq xmm12, xmm12
00007942783d58f6  vmovaps [rsp+0x50], xmm12
00007942783d58fc  movq xmm12, xmm12
00007942783d5901  movaps [r15+0x170], xmm12
00007942783d5909  movq xmm11, xmm11
00007942783d590e  vmovaps [rsp+0x60], xmm11
00007942783d5914  movq xmm11, xmm11
00007942783d5919  movaps [r15+0x160], xmm11
00007942783d5921  mov rax, [r13+r12*1]
00007942783d5926  vmovq xmm12, rax
00007942783d592b  vpbroadcastq xmm12, xmm12
00007942783d5930  lea rax, [r12+0x08]
00007942783d5935  mov r12, [r13+rax*1]
00007942783d593a  movq xmm11, r12
00007942783d593f  movaps [r15+0x230], xmm11
00007942783d5947  mov rax, [r15+0xF8]
00007942783d594e  lea r12, [rax+0x50]
00007942783d5952  movups xmm11, [r13+r12*1]
00007942783d5958  lea r12, [rax+0x60]
00007942783d595c  movups xmm10, [r13+r12*1]
00007942783d5962  lea r12, [rax+0x30]
00007942783d5966  movups xmm9, [r13+r12*1]
00007942783d596c  mov r12, [r15+0x50]
00007942783d5970  lea r11, [r12+r14*1]
00007942783d5974  mov [r15+0x60], r11
00007942783d5978  lea r12, [r14+0x40]
00007942783d597c  mov [r15+0x58], r12
00007942783d5980  movaps xmm8, xmm12
00007942783d5984  mulpd xmm8, xmm15
00007942783d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007942783d598f  ptest xmm7, xmm7
00007942783d5994  jnz 0x00007942783D67B7
00007942783d599a  movq xmm15, qword ptr [r15+0x230]
00007942783d59a3  vmovaps [rsp+0x70], xmm15
00007942783d59a9  vpermilpd xmm15, xmm15, 0x00
00007942783d59af  movaps xmm7, xmm9
00007942783d59b3  mulpd xmm7, xmm15
00007942783d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007942783d59bd  ptest xmm6, xmm6
00007942783d59c2  jnz 0x00007942783D68FB
00007942783d59c8  vxorps xmm15, xmm15, xmm15
00007942783d59cd  vpbroadcastq xmm15, xmm15
00007942783d59d2  movaps xmm9, xmm12
00007942783d59d6  mulpd xmm9, xmm10
00007942783d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007942783d59e1  ptest xmm6, xmm6
00007942783d59e6  jnz 0x00007942783D6A3D
00007942783d59ec  movaps xmm10, xmm12
00007942783d59f0  mulpd xmm10, xmm11
00007942783d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007942783d59fb  ptest xmm6, xmm6
00007942783d5a00  jnz 0x00007942783D6B81
00007942783d5a06  movaps xmm11, [r15+0x1F0]
00007942783d5a0e  movaps xmm6, xmm12
00007942783d5a12  mulpd xmm6, xmm11
00007942783d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007942783d5a1c  ptest xmm5, xmm5
00007942783d5a21  jnz 0x00007942783D6CC5
00007942783d5a27  movaps xmm12, [r15+0x2A0]
00007942783d5a2f  vmovaps [rsp+0x80], xmm12
00007942783d5a38  vmovaps xmm11, [rsp+0x80]
00007942783d5a41  por xmm12, xmm11
00007942783d5a46  movaps xmm11, [r15+0x250]
00007942783d5a4e  vmovaps [rsp+0x80], xmm11
00007942783d5a57  vmovaps xmm5, [rsp+0x80]
00007942783d5a60  por xmm11, xmm5
00007942783d5a65  vmovaps xmm4, [rsp+0x70]
00007942783d5a6b  vpermilpd xmm4, xmm4, 0x00
00007942783d5a71  movaps xmm3, xmm5
00007942783d5a74  mulpd xmm3, xmm4
00007942783d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007942783d5a7d  ptest xmm2, xmm2
00007942783d5a82  jnz 0x00007942783D6E07
00007942783d5a88  mov [rsp+0x80], rax
00007942783d5a90  xor eax, eax
00007942783d5a92  mov r14d, 0x200
00007942783d5a98  cmp r12, r14
00007942783d5a9b  cmc
00007942783d5a9c  lahf
00007942783d5a9d  seto al
00007942783d5aa0  mov [r15+0x108], eax
00007942783d5aa7  movaps xmm5, xmm8
00007942783d5aab  addpd xmm5, xmm15
00007942783d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007942783d5ab5  ptest xmm4, xmm4
00007942783d5aba  jnz 0x00007942783D6F47
00007942783d5ac0  movaps xmm8, [r15+0x1B0]
00007942783d5ac8  movaps xmm4, xmm9
00007942783d5acc  addpd xmm4, xmm8
00007942783d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007942783d5ad6  ptest xmm2, xmm2
00007942783d5adb  jnz 0x00007942783D7089
00007942783d5ae1  movaps xmm9, xmm10
00007942783d5ae5  addpd xmm9, xmm8
00007942783d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007942783d5af0  ptest xmm2, xmm2
00007942783d5af5  jnz 0x00007942783D71CB
00007942783d5afb  movaps xmm10, [r15+0x2F0]
00007942783d5b03  vmovaps [rsp+0x90], xmm10
00007942783d5b0c  vmovaps xmm8, [rsp+0x90]
00007942783d5b15  por xmm10, xmm8
00007942783d5b1a  movaps xmm8, [r15+0x2E0]
00007942783d5b22  vmovaps [rsp+0x90], xmm8
00007942783d5b2b  vmovaps xmm2, [rsp+0x90]
00007942783d5b34  por xmm8, xmm2
00007942783d5b39  movaps xmm2, [r15+0x2D0]
00007942783d5b41  vmovaps [rsp+0x90], xmm2
00007942783d5b4a  vmovaps [rsp+0xA0], xmm1
00007942783d5b53  vmovaps xmm1, [rsp+0x90]
00007942783d5b5c  por xmm2, xmm1
00007942783d5b60  movaps xmm1, [r15+0x200]
00007942783d5b68  vmovaps [rsp+0x90], xmm1
00007942783d5b71  vmovaps [rsp+0xB0], xmm15
00007942783d5b7a  vmovaps xmm15, [rsp+0x90]
00007942783d5b83  por xmm1, xmm15
00007942783d5b88  movaps xmm15, [r15+0x1C0]
00007942783d5b90  vmovaps [rsp+0x90], xmm15
00007942783d5b99  vmovaps [rsp+0xC0], xmm1
00007942783d5ba2  vmovaps xmm1, [rsp+0x90]
00007942783d5bab  por xmm15, xmm1
00007942783d5bb0  movaps xmm1, [r15+0x190]
00007942783d5bb8  vmovaps [rsp+0x90], xmm1
00007942783d5bc1  vmovaps [rsp+0xD0], xmm15
00007942783d5bca  vmovaps xmm15, [rsp+0x90]
00007942783d5bd3  por xmm1, xmm15
00007942783d5bd8  movaps xmm15, [r15+0x300]
00007942783d5be0  vmovaps [rsp+0x90], xmm15
00007942783d5be9  vmovaps [rsp+0xE0], xmm1
00007942783d5bf2  vmovaps xmm1, [rsp+0x90]
00007942783d5bfb  por xmm15, xmm1
00007942783d5c00  mov rax, [rsp+0x80]
00007942783d5c08  lea r14, [rax+0xA0]
00007942783d5c0f  movups xmm1, [r13+r14*1]
00007942783d5c15  lea r14, [rax+0xB0]
00007942783d5c1c  vmovaps [rsp+0x80], xmm1
00007942783d5c25  movups xmm1, [r13+r14*1]
00007942783d5c2b  vmovaps [rsp+0x90], xmm1
00007942783d5c34  vmovaps [rsp+0xF0], xmm15
00007942783d5c3d  vmovaps xmm15, [rsp+0xB0]
00007942783d5c46  vmovaps [rsp+0xB0], xmm14
00007942783d5c4f  movaps xmm1, xmm6
00007942783d5c52  addpd xmm1, xmm15
00007942783d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007942783d5c5c  ptest xmm14, xmm14
00007942783d5c62  jnz 0x00007942783D7323
00007942783d5c68  lea r14, [rax+0xF0]
00007942783d5c6f  movups xmm15, [r13+r14*1]
00007942783d5c75  movaps xmm14, xmm4
00007942783d5c79  addpd xmm14, xmm3
00007942783d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007942783d5c84  ptest xmm6, xmm6
00007942783d5c89  jnz 0x00007942783D746E
00007942783d5c8f  movaps xmm6, xmm9
00007942783d5c93  addpd xmm6, xmm7
00007942783d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007942783d5c9c  ptest xmm4, xmm4
00007942783d5ca1  jnz 0x00007942783D75B0
00007942783d5ca7  vmovaps xmm9, [rsp+0x70]
00007942783d5cad  vpermilpd xmm9, xmm9, 0x00
00007942783d5cb3  vmovaps xmm4, [rsp+0x90]
00007942783d5cbc  movaps xmm7, xmm4
00007942783d5cbf  mulpd xmm7, xmm9
00007942783d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007942783d5cc9  ptest xmm3, xmm3
00007942783d5cce  jnz 0x00007942783D76F1
00007942783d5cd4  vmovaps xmm9, [rsp+0x50]
00007942783d5cda  vpermilpd xmm9, xmm9, 0x00
00007942783d5ce0  movaps xmm4, xmm15
00007942783d5ce4  mulpd xmm4, xmm9
00007942783d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007942783d5cee  ptest xmm3, xmm3
00007942783d5cf3  jnz 0x00007942783D7832
00007942783d5cf9  lea r14, [rax+0xE0]
00007942783d5d00  movups xmm15, [r13+r14*1]
00007942783d5d06  vmovaps xmm9, [rsp+0x70]
00007942783d5d0c  vpermilpd xmm9, xmm9, 0x00
00007942783d5d12  vmovaps [rsp+0x70], xmm1
00007942783d5d18  vmovaps xmm1, [rsp+0x80]
00007942783d5d21  vmovaps [rsp+0x80], xmm15
00007942783d5d2a  movaps xmm3, xmm1
00007942783d5d2d  mulpd xmm3, xmm9
00007942783d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007942783d5d37  ptest xmm15, xmm15
00007942783d5d3d  jnz 0x00007942783D797E
00007942783d5d43  vmovaps xmm1, [rsp+0xF0]
00007942783d5d4c  vmovaps xmm15, [rsp+0xF0]
00007942783d5d55  por xmm1, xmm15
00007942783d5d5a  movaps [r15+0x300], xmm1
00007942783d5d62  vmovaps xmm15, [rsp+0xE0]
00007942783d5d6b  vmovaps xmm9, [rsp+0xE0]
00007942783d5d74  por xmm15, xmm9
00007942783d5d79  movaps [r15+0x190], xmm15
00007942783d5d81  vmovaps xmm9, [rsp+0x50]
00007942783d5d87  vpermilpd xmm9, xmm9, 0x00
00007942783d5d8d  vmovaps [rsp+0x90], xmm1
00007942783d5d96  vmovaps [rsp+0xE0], xmm15
00007942783d5d9f  vmovaps xmm15, [rsp+0x80]
00007942783d5da8  vmovaps [rsp+0x80], xmm14
00007942783d5db1  movaps xmm1, xmm15
00007942783d5db5  mulpd xmm1, xmm9
00007942783d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007942783d5dbf  ptest xmm14, xmm14
00007942783d5dc5  jnz 0x00007942783D7ABF
00007942783d5dcb  lea r14, [rax+0x90]
00007942783d5dd2  movups xmm15, [r13+r14*1]
00007942783d5dd8  vmovaps xmm14, [rsp+0xD0]
00007942783d5de1  vmovaps xmm9, [rsp+0xD0]
00007942783d5dea  por xmm14, xmm9
00007942783d5def  movaps [r15+0x1C0], xmm14
00007942783d5df7  vmovaps xmm9, [rsp+0xC0]
00007942783d5e00  vmovaps [rsp+0xD0], xmm1
00007942783d5e09  vmovaps xmm1, [rsp+0xC0]
00007942783d5e12  por xmm9, xmm1
00007942783d5e17  movaps [r15+0x200], xmm9
00007942783d5e1f  vmovaps [rsp+0xC0], xmm2
00007942783d5e28  vmovaps xmm1, [rsp+0xC0]
00007942783d5e31  por xmm2, xmm1
00007942783d5e35  movaps [r15+0x2D0], xmm2
00007942783d5e3d  vmovaps [rsp+0xC0], xmm8
00007942783d5e46  vmovaps xmm1, [rsp+0xC0]
00007942783d5e4f  por xmm8, xmm1
00007942783d5e54  movaps [r15+0x2E0], xmm8
00007942783d5e5c  vmovaps [rsp+0xC0], xmm15
00007942783d5e65  movaps xmm1, xmm5
00007942783d5e68  addpd xmm1, xmm7
00007942783d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007942783d5e71  ptest xmm15, xmm15
00007942783d5e77  jnz 0x00007942783D7C0B
00007942783d5e7d  vmovaps xmm15, [rsp+0x50]
00007942783d5e83  vpermilpd xmm15, xmm15, 0x00
00007942783d5e89  vmovaps xmm5, [rsp+0xC0]
00007942783d5e92  vmovaps [rsp+0xC0], xmm1
00007942783d5e9b  movaps xmm7, xmm5
00007942783d5e9e  mulpd xmm7, xmm15
00007942783d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007942783d5ea8  ptest xmm1, xmm1
00007942783d5ead  jnz 0x00007942783D7D4B
00007942783d5eb3  lea r14, [rax+0x80]
00007942783d5eba  movups xmm1, [r13+r14*1]
00007942783d5ec0  vmovaps xmm5, [rsp+0x70]
00007942783d5ec6  vmovaps [rsp+0x70], xmm1
00007942783d5ecc  movaps xmm15, xmm5
00007942783d5ed0  addpd xmm15, xmm3
00007942783d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007942783d5edb  ptest xmm1, xmm1
00007942783d5ee0  jnz 0x00007942783D7E96
00007942783d5ee6  vmovaps xmm5, [rsp+0x80]
00007942783d5eef  movaps xmm1, xmm5
00007942783d5ef2  addpd xmm1, xmm4
00007942783d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007942783d5efb  ptest xmm3, xmm3
00007942783d5f00  jnz 0x00007942783D7FD8
00007942783d5f06  vmovaps [rsp+0x80], xmm10
00007942783d5f0f  vmovaps xmm5, [rsp+0x80]
00007942783d5f18  por xmm10, xmm5
00007942783d5f1d  movaps [r15+0x2F0], xmm10
00007942783d5f25  vmovaps xmm5, [rsp+0x50]
00007942783d5f2b  vpermilpd xmm5, xmm5, 0x00
00007942783d5f31  vmovaps xmm3, [rsp+0x70]
00007942783d5f37  vmovaps [rsp+0x50], xmm1
00007942783d5f3d  movaps xmm4, xmm3
00007942783d5f40  mulpd xmm4, xmm5
00007942783d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007942783d5f49  ptest xmm1, xmm1
00007942783d5f4e  jnz 0x00007942783D8118
00007942783d5f54  lea r14, [rax+0xD0]
00007942783d5f5b  movups xmm1, [r13+r14*1]
00007942783d5f61  vmovaps xmm3, [rsp+0xD0]
00007942783d5f6a  vmovaps [rsp+0x70], xmm1
00007942783d5f70  movaps xmm5, xmm6
00007942783d5f73  addpd xmm5, xmm3
00007942783d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007942783d5f7c  ptest xmm1, xmm1
00007942783d5f81  jnz 0x00007942783D8262
00007942783d5f87  vmovaps xmm1, [rsp+0x60]
00007942783d5f8d  vpermilpd xmm1, xmm1, 0x00
00007942783d5f93  movaps xmm6, xmm9
00007942783d5f97  mulpd xmm6, xmm1
00007942783d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007942783d5fa0  ptest xmm3, xmm3
00007942783d5fa5  jnz 0x00007942783D83A2
00007942783d5fab  movaps [r15+0x260], xmm6
00007942783d5fb3  vxorps xmm1, xmm1, xmm1
00007942783d5fb7  vpbroadcastq xmm1, xmm1
00007942783d5fbc  movaps [r15+0x1B0], xmm1
00007942783d5fc4  vmovaps xmm1, [rsp+0x60]
00007942783d5fca  vpermilpd xmm1, xmm1, 0x00
00007942783d5fd0  vmovaps xmm3, [rsp+0x70]
00007942783d5fd6  vmovaps [rsp+0x70], xmm15
00007942783d5fdc  movaps xmm9, xmm3
00007942783d5fe0  mulpd xmm9, xmm1
00007942783d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007942783d5feb  ptest xmm15, xmm15
00007942783d5ff1  jnz 0x00007942783D84E3
00007942783d5ff7  lea r14, [rax+0xC0]
00007942783d5ffe  movups xmm1, [r13+r14*1]
00007942783d6004  vmovaps xmm3, [rsp+0xC0]
00007942783d600d  vmovaps [rsp+0x80], xmm1
00007942783d6016  movaps xmm15, xmm3
00007942783d601a  addpd xmm15, xmm7
00007942783d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007942783d6025  ptest xmm1, xmm1
00007942783d602a  jnz 0x00007942783D862F
00007942783d6030  vmovaps [rsp+0xC0], xmm13
00007942783d6039  vmovaps xmm1, [rsp+0xC0]
00007942783d6042  por xmm13, xmm1
00007942783d6047  movaps [r15+0x270], xmm13
00007942783d604f  vmovaps xmm1, [rsp+0xB0]
00007942783d6058  vmovaps xmm7, [rsp+0xB0]
00007942783d6061  por xmm1, xmm7
00007942783d6065  movaps [r15+0x1A0], xmm1
00007942783d606d  vmovaps xmm1, [rsp+0x60]
00007942783d6073  vpermilpd xmm1, xmm1, 0x00
00007942783d6079  vmovaps [rsp+0xB0], xmm1
00007942783d6082  vmovaps xmm1, [rsp+0x80]
00007942783d608b  vmovaps [rsp+0x80], xmm15
00007942783d6094  vmovaps xmm15, [rsp+0xB0]
00007942783d609d  vmovaps [rsp+0xB0], xmm14
00007942783d60a6  movaps xmm3, xmm1
00007942783d60a9  mulpd xmm3, xmm15
00007942783d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007942783d60b3  ptest xmm14, xmm14
00007942783d60b9  jnz 0x00007942783D8771
00007942783d60bf  lea r14, [rax+0x20]
00007942783d60c3  movups xmm1, [r13+r14*1]
00007942783d60c9  movaps [r15+0x110], xmm1
00007942783d60d1  vmovaps xmm14, [rsp+0x70]
00007942783d60d7  vmovaps [rsp+0x70], xmm1
00007942783d60dd  movaps xmm15, xmm14
00007942783d60e1  addpd xmm15, xmm4
00007942783d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007942783d60ec  ptest xmm1, xmm1
00007942783d60f1  jnz 0x00007942783D88BC
00007942783d60f7  vmovaps xmm1, [rsp+0x60]
00007942783d60fd  vpermilpd xmm1, xmm1, 0x00
00007942783d6103  movaps xmm14, xmm2
00007942783d6107  mulpd xmm14, xmm1
00007942783d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007942783d6112  ptest xmm4, xmm4
00007942783d6117  jnz 0x00007942783D89FF
00007942783d611d  vmovaps xmm4, [rsp+0x50]
00007942783d6123  movaps xmm1, xmm4
00007942783d6126  addpd xmm1, xmm9
00007942783d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007942783d6130  ptest xmm2, xmm2
00007942783d6135  jnz 0x00007942783D8B41
00007942783d613b  vmovaps xmm9, [rsp+0x30]
00007942783d6141  vpermilpd xmm9, xmm9, 0x00
00007942783d6147  vmovaps xmm2, [rsp+0x70]
00007942783d614d  vmovaps [rsp+0x50], xmm1
00007942783d6153  movaps xmm4, xmm2
00007942783d6156  mulpd xmm4, xmm9
00007942783d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007942783d6160  ptest xmm1, xmm1
00007942783d6165  jnz 0x00007942783D8C82
00007942783d616b  vmovaps xmm1, [rsp+0x30]
00007942783d6171  vpermilpd xmm1, xmm1, 0x00
00007942783d6177  vmovaps xmm2, [rsp+0x90]
00007942783d6180  vmovaps [rsp+0x60], xmm15
00007942783d6186  movaps xmm9, xmm2
00007942783d618a  mulpd xmm9, xmm1
00007942783d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007942783d6195  ptest xmm15, xmm15
00007942783d619b  jnz 0x00007942783D8DC3
00007942783d61a1  vmovaps xmm15, [rsp+0x80]
00007942783d61aa  movaps xmm1, xmm15
00007942783d61ae  addpd xmm1, xmm6
00007942783d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007942783d61b7  ptest xmm2, xmm2
00007942783d61bc  jnz 0x00007942783D8F05
00007942783d61c2  movaps xmm15, xmm5
00007942783d61c6  addpd xmm15, xmm3
00007942783d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007942783d61d1  ptest xmm6, xmm6
00007942783d61d6  jnz 0x00007942783D9046
00007942783d61dc  vmovaps xmm6, [rsp+0x30]
00007942783d61e2  vpermilpd xmm6, xmm6, 0x00
00007942783d61e8  movaps xmm5, xmm8
00007942783d61ec  mulpd xmm5, xmm6
00007942783d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007942783d61f5  ptest xmm3, xmm3
00007942783d61fa  jnz 0x00007942783D9188
00007942783d6200  vmovaps xmm8, [rsp+0x30]
00007942783d6206  vpermilpd xmm8, xmm8, 0x00
00007942783d620c  movaps xmm6, xmm10
00007942783d6210  mulpd xmm6, xmm8
00007942783d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007942783d621a  ptest xmm3, xmm3
00007942783d621f  jnz 0x00007942783D92C9
00007942783d6225  vmovaps xmm8, [rsp+0x60]
00007942783d622b  movaps xmm10, xmm8
00007942783d622f  addpd xmm10, xmm14
00007942783d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007942783d623a  ptest xmm3, xmm3
00007942783d623f  jnz 0x00007942783D940B
00007942783d6245  vmovaps xmm8, [rsp+0x50]
00007942783d624b  movaps xmm14, xmm8
00007942783d624f  addpd xmm14, xmm4
00007942783d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007942783d625a  ptest xmm3, xmm3
00007942783d625f  jnz 0x00007942783D954F
00007942783d6265  vmovaps xmm8, [rsp+0x40]
00007942783d626b  vpermilpd xmm8, xmm8, 0x00
00007942783d6271  movaps xmm4, xmm13
00007942783d6275  mulpd xmm4, xmm8
00007942783d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007942783d627f  ptest xmm3, xmm3
00007942783d6284  jnz 0x00007942783D9692
00007942783d628a  movaps xmm13, xmm15
00007942783d628e  addpd xmm13, xmm9
00007942783d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007942783d6299  ptest xmm8, xmm8
00007942783d629f  jnz 0x00007942783D97D4
00007942783d62a5  movaps xmm15, xmm1
00007942783d62a9  addpd xmm15, xmm5
00007942783d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007942783d62b4  ptest xmm9, xmm9
00007942783d62ba  jnz 0x00007942783D9918
00007942783d62c0  vmovaps [rsp+0x30], xmm11
00007942783d62c6  vmovaps xmm1, [rsp+0x30]
00007942783d62cc  por xmm11, xmm1
00007942783d62d1  movaps [r15+0x250], xmm11
00007942783d62d9  vmovaps [rsp+0x30], xmm12
00007942783d62df  vmovaps xmm1, [rsp+0x30]
00007942783d62e5  por xmm12, xmm1
00007942783d62ea  movaps [r15+0x2A0], xmm12
00007942783d62f2  vmovaps xmm1, [rsp+0xA0]
00007942783d62fb  vmovaps xmm11, [rsp+0xA0]
00007942783d6304  por xmm1, xmm11
00007942783d6309  movaps [r15+0x1D0], xmm1
00007942783d6311  lea r14, [rax+0x40]
00007942783d6315  movups xmm1, [r13+r14*1]
00007942783d631b  movaps [r15+0x2C0], xmm1
00007942783d6323  vmovaps xmm11, [rsp+0x40]
00007942783d6329  vpermilpd xmm11, xmm11, 0x00
00007942783d632f  vmovaps xmm8, [rsp+0xE0]
00007942783d6338  movaps xmm9, xmm8
00007942783d633c  mulpd xmm9, xmm11
00007942783d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007942783d6347  ptest xmm5, xmm5
00007942783d634c  jnz 0x00007942783D9A64
00007942783d6352  movaps xmm11, xmm10
00007942783d6356  addpd xmm11, xmm6
00007942783d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007942783d6361  ptest xmm8, xmm8
00007942783d6367  jnz 0x00007942783D9BA8
00007942783d636d  movaps xmm10, xmm14
00007942783d6371  addpd xmm10, xmm4
00007942783d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007942783d637c  ptest xmm8, xmm8
00007942783d6382  jnz 0x00007942783D9CEB
00007942783d6388  vmovaps xmm14, [rsp+0x40]
00007942783d638e  vpermilpd xmm14, xmm14, 0x00
00007942783d6394  movaps xmm8, xmm1
00007942783d6398  mulpd xmm8, xmm14
00007942783d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007942783d63a3  ptest xmm6, xmm6
00007942783d63a8  jnz 0x00007942783D9E2E
00007942783d63ae  movaps xmm1, [r15+0x2B0]
00007942783d63b6  vmovaps xmm14, [rsp+0x40]
00007942783d63bc  vpermilpd xmm14, xmm14, 0x00
00007942783d63c2  movaps xmm6, xmm1
00007942783d63c5  mulpd xmm6, xmm14
00007942783d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007942783d63cf  ptest xmm5, xmm5
00007942783d63d4  jnz 0x00007942783D9F71
00007942783d63da  vmovaps xmm1, [rsp+0x10]
00007942783d63e0  vpermilpd xmm1, xmm1, 0x00
00007942783d63e6  movaps xmm14, xmm12
00007942783d63ea  mulpd xmm14, xmm1
00007942783d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007942783d63f5  ptest xmm5, xmm5
00007942783d63fa  jnz 0x00007942783DA0B2
00007942783d6400  movaps xmm1, xmm13
00007942783d6404  addpd xmm1, xmm9
00007942783d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007942783d640e  ptest xmm12, xmm12
00007942783d6414  jnz 0x00007942783DA1F5
00007942783d641a  vmovaps xmm13, [rsp+0x10]
00007942783d6420  vpermilpd xmm13, xmm13, 0x00
00007942783d6426  movaps xmm12, xmm7
00007942783d642a  mulpd xmm12, xmm13
00007942783d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007942783d6435  ptest xmm9, xmm9
00007942783d643b  jnz 0x00007942783DA337
00007942783d6441  movaps xmm13, xmm15
00007942783d6445  addpd xmm13, xmm8
00007942783d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007942783d6450  ptest xmm9, xmm9
00007942783d6456  jnz 0x00007942783DA47A
00007942783d645c  movaps xmm15, [r15+0x290]
00007942783d6464  vmovaps xmm9, [rsp+0x10]
00007942783d646a  vpermilpd xmm9, xmm9, 0x00
00007942783d6470  movaps xmm8, xmm15
00007942783d6474  mulpd xmm8, xmm9
00007942783d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007942783d647f  ptest xmm7, xmm7
00007942783d6484  jnz 0x00007942783DA5BE
00007942783d648a  movaps xmm15, xmm11
00007942783d648e  addpd xmm15, xmm6
00007942783d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007942783d6499  ptest xmm9, xmm9
00007942783d649f  jnz 0x00007942783DA702
00007942783d64a5  movaps xmm11, [r15+0x1E0]
00007942783d64ad  vmovaps xmm9, [rsp+0x10]
00007942783d64b3  vpermilpd xmm9, xmm9, 0x00
00007942783d64b9  movaps xmm7, xmm11
00007942783d64bd  mulpd xmm7, xmm9
00007942783d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007942783d64c7  ptest xmm6, xmm6
00007942783d64cc  jnz 0x00007942783DA845
00007942783d64d2  movaps xmm11, xmm10
00007942783d64d6  addpd xmm11, xmm14
00007942783d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007942783d64e1  ptest xmm9, xmm9
00007942783d64e7  jnz 0x00007942783DA987
00007942783d64ed  lea r14, [rax+0x70]
00007942783d64f1  movups xmm14, [r13+r14*1]
00007942783d64f7  movaps [r15+0x240], xmm14
00007942783d64ff  movaps xmm10, xmm1
00007942783d6503  addpd xmm10, xmm12
00007942783d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007942783d650e  ptest xmm9, xmm9
00007942783d6514  jnz 0x00007942783DAAD5
00007942783d651a  movaps [r15+0x170], xmm10
00007942783d6522  vmovaps xmm1, [rsp+0x20]
00007942783d6528  vpermilpd xmm1, xmm1, 0x00
00007942783d652e  movaps xmm12, xmm14
00007942783d6532  mulpd xmm12, xmm1
00007942783d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007942783d653d  ptest xmm9, xmm9
00007942783d6543  jnz 0x00007942783DAC18
00007942783d6549  vmovaps xmm1, [rsp+0x20]
00007942783d654f  vpermilpd xmm1, xmm1, 0x00
00007942783d6555  vmovaps xmm9, [rsp+0xB0]
00007942783d655e  movaps xmm14, xmm9
00007942783d6562  mulpd xmm14, xmm1
00007942783d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007942783d656d  ptest xmm6, xmm6
00007942783d6572  jnz 0x00007942783DAD5B
00007942783d6578  movaps [r15+0x180], xmm14
00007942783d6580  movaps xmm1, xmm13
00007942783d6584  addpd xmm1, xmm8
00007942783d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007942783d658e  ptest xmm9, xmm9
00007942783d6594  jnz 0x00007942783DAE9E
00007942783d659a  movaps [r15+0x210], xmm1
00007942783d65a2  movups xmm13, [r13+rax*1]
00007942783d65a8  lea r14, [rax+0x10]
00007942783d65ac  movups xmm9, [r13+r14*1]
00007942783d65b2  movaps [r15+0x230], xmm9
00007942783d65ba  movaps xmm8, xmm15
00007942783d65be  addpd xmm8, xmm7
00007942783d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007942783d65c9  ptest xmm6, xmm6
00007942783d65ce  jnz 0x00007942783DAFF4
00007942783d65d4  movaps [r15+0x130], xmm8
00007942783d65dc  vmovaps xmm15, [rsp+0x20]
00007942783d65e2  vpermilpd xmm15, xmm15, 0x00
00007942783d65e8  movaps xmm7, xmm9
00007942783d65ec  mulpd xmm7, xmm15
00007942783d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007942783d65f6  ptest xmm6, xmm6
00007942783d65fb  jnz 0x00007942783DB137
00007942783d6601  movaps [r15+0x220], xmm7
00007942783d6609  vmovaps xmm15, [rsp+0x20]
00007942783d660f  vpermilpd xmm15, xmm15, 0x00
00007942783d6615  movaps xmm9, xmm13
00007942783d6619  mulpd xmm9, xmm15
00007942783d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007942783d6624  ptest xmm6, xmm6
00007942783d6629  jnz 0x00007942783DB279
00007942783d662f  movaps xmm15, xmm11
00007942783d6633  addpd xmm15, xmm12
00007942783d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007942783d663e  ptest xmm13, xmm13
00007942783d6644  jnz 0x00007942783DB3BD
00007942783d664a  movaps [r15+0x140], xmm15
00007942783d6652  movaps xmm13, xmm10
00007942783d6656  addpd xmm13, xmm14
00007942783d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007942783d6661  ptest xmm12, xmm12
00007942783d6667  jnz 0x00007942783DB501
00007942783d666d  movaps [r15+0x150], xmm13
00007942783d6675  movaps xmm14, xmm1
00007942783d6679  addpd xmm14, xmm7
00007942783d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007942783d6684  ptest xmm12, xmm12
00007942783d668a  jnz 0x00007942783DB645
00007942783d6690  movaps [r15+0x160], xmm14
00007942783d6698  movaps xmm1, xmm8
00007942783d669c  addpd xmm1, xmm9
00007942783d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007942783d66a6  ptest xmm12, xmm12
00007942783d66ac  jnz 0x00007942783DB787
00007942783d66b2  movaps [r15+0x120], xmm1
00007942783d66ba  movups [r13+r11*1], xmm15
00007942783d66c0  lea rax, [r11+0x10]
00007942783d66c4  movups [r13+rax*1], xmm13
00007942783d66ca  lea rax, [r11+0x20]
00007942783d66ce  movups [r13+rax*1], xmm14
00007942783d66d4  lea rax, [r11+0x30]
00007942783d66d8  movups [r13+rax*1], xmm1
00007942783d66de  mov eax, [r15+0x108]
00007942783d66e5  sahf
00007942783d66e6  jnz 0x00007942783D6718
00007942783d66e8  cmp dword ptr [r15+0x318], 0x00
00007942783d66f0  jz 0x00007942783DB900
00007942783d66f6  nop [rax+rax*1], ax
00007942783d66ff  nop [rax+rax*1], eax
00007942783d6707  mov eax, 0x410444
00007942783d670c  mov [r15+0x100], rax
00007942783d6713  jmp 0x00007942781FE110
00007942783d6718  cmp dword ptr [r15+0x318], 0x00
00007942783d6720  jz 0x00007942783D57E0
00007942783d6726  nop [rax+rax*1], ax
00007942783d672f  nop [rax+rax*1], eax
00007942783d6737  mov eax, 0x410278
00007942783d673c  mov [r15+0x100], rax
00007942783d6743  jmp 0x00007942781FE110
00007942783d6748  int3
00007942783d6749  call 0x000079427820A4B0
00007942783d674e  jmp 0x00007942783D5828
00007942783d6753  call 0x0000794278209240
00007942783d6758  jmp 0x00007942783D5832
00007942783d675d  call 0x000079427820A4B0
00007942783d6762  jmp 0x00007942783D588F
00007942783d6767  call 0x0000794278209240
00007942783d676c  jmp 0x00007942783D5899
00007942783d6771  call 0x000079427820A4B0
00007942783d6776  jmp 0x00007942783D58DD
00007942783d677b  call 0x0000794278209240
00007942783d6780  jmp 0x00007942783D58E7
00007942783d6785  call 0x00007942782B47C0
00007942783d678a  jmp 0x00007942783D5926
00007942783d678f  call 0x000079427820B720
00007942783d6794  jmp 0x00007942783D593A
00007942783d6799  call 0x00007942782BFC30
00007942783d679e  jmp 0x00007942783D5958
00007942783d67a3  call 0x00007942782BE9C0
00007942783d67a8  jmp 0x00007942783D5962
00007942783d67ad  call 0x00007942782BD750
00007942783d67b2  jmp 0x00007942783D596C
00007942783d67b7  sub rsp, 0x08
00007942783d67bb  push rax
00007942783d67bc  push rcx
00007942783d67bd  push rdx
00007942783d67be  push rdi
00007942783d67bf  push rsi
00007942783d67c0  push r8
00007942783d67c2  push r9
00007942783d67c4  push r10
00007942783d67c6  push r11
00007942783d67c8  sub rsp, 0xF0
00007942783d67cf  vmovaps [rsp], xmm0
00007942783d67d4  vmovaps [rsp+0x10], xmm1
00007942783d67da  vmovaps [rsp+0x20], xmm2
00007942783d67e0  vmovaps [rsp+0x30], xmm3
00007942783d67e6  vmovaps [rsp+0x40], xmm4
00007942783d67ec  vmovaps [rsp+0x50], xmm5
00007942783d67f2  vmovaps [rsp+0x60], xmm6
00007942783d67f8  vmovaps [rsp+0x70], xmm7
00007942783d67fe  vmovaps [rsp+0x80], xmm9
00007942783d6807  vmovaps [rsp+0x90], xmm10
00007942783d6810  vmovaps [rsp+0xA0], xmm11
00007942783d6819  vmovaps [rsp+0xB0], xmm12
00007942783d6822  vmovaps [rsp+0xC0], xmm13
00007942783d682b  vmovaps [rsp+0xD0], xmm14
00007942783d6834  vmovaps [rsp+0xE0], xmm15
00007942783d683d  sub rsp, 0x30
00007942783d6841  movaps [rsp], xmm8
00007942783d6846  movaps [rsp+0x10], xmm12
00007942783d684c  movaps [rsp+0x20], xmm15
00007942783d6852  lea rdi, [rsp]
00007942783d6856  mov esi, 0x00
00007942783d685b  mov rax, 0x59DDDCBA3530
00007942783d6865  call rax
00007942783d6867  movaps xmm8, [rsp]
00007942783d686c  add rsp, 0x30
00007942783d6870  vmovaps xmm0, [rsp]
00007942783d6875  vmovaps xmm1, [rsp+0x10]
00007942783d687b  vmovaps xmm2, [rsp+0x20]
00007942783d6881  vmovaps xmm3, [rsp+0x30]
00007942783d6887  vmovaps xmm4, [rsp+0x40]
00007942783d688d  vmovaps xmm5, [rsp+0x50]
00007942783d6893  vmovaps xmm6, [rsp+0x60]
00007942783d6899  vmovaps xmm7, [rsp+0x70]
00007942783d689f  vmovaps xmm9, [rsp+0x80]
00007942783d68a8  vmovaps xmm10, [rsp+0x90]
00007942783d68b1  vmovaps xmm11, [rsp+0xA0]
00007942783d68ba  vmovaps xmm12, [rsp+0xB0]
00007942783d68c3  vmovaps xmm13, [rsp+0xC0]
00007942783d68cc  vmovaps xmm14, [rsp+0xD0]
00007942783d68d5  vmovaps xmm15, [rsp+0xE0]
00007942783d68de  add rsp, 0xF0
00007942783d68e5  pop r11
00007942783d68e7  pop r10
00007942783d68e9  pop r9
00007942783d68eb  pop r8
00007942783d68ed  pop rsi
00007942783d68ee  pop rdi
00007942783d68ef  pop rdx
00007942783d68f0  pop rcx
00007942783d68f1  pop rax
00007942783d68f2  add rsp, 0x08
00007942783d68f6  jmp 0x00007942783D599A
00007942783d68fb  sub rsp, 0x08
00007942783d68ff  push rax
00007942783d6900  push rcx
00007942783d6901  push rdx
00007942783d6902  push rdi
00007942783d6903  push rsi
00007942783d6904  push r8
00007942783d6906  push r9
00007942783d6908  push r10
00007942783d690a  push r11
00007942783d690c  sub rsp, 0xF0
00007942783d6913  vmovaps [rsp], xmm0
00007942783d6918  vmovaps [rsp+0x10], xmm1
00007942783d691e  vmovaps [rsp+0x20], xmm2
00007942783d6924  vmovaps [rsp+0x30], xmm3
00007942783d692a  vmovaps [rsp+0x40], xmm4
00007942783d6930  vmovaps [rsp+0x50], xmm5
00007942783d6936  vmovaps [rsp+0x60], xmm6
00007942783d693c  vmovaps [rsp+0x70], xmm8
00007942783d6942  vmovaps [rsp+0x80], xmm9
00007942783d694b  vmovaps [rsp+0x90], xmm10
00007942783d6954  vmovaps [rsp+0xA0], xmm11
00007942783d695d  vmovaps [rsp+0xB0], xmm12
00007942783d6966  vmovaps [rsp+0xC0], xmm13
00007942783d696f  vmovaps [rsp+0xD0], xmm14
00007942783d6978  vmovaps [rsp+0xE0], xmm15
00007942783d6981  sub rsp, 0x30
00007942783d6985  movaps [rsp], xmm7
00007942783d6989  movaps [rsp+0x10], xmm9
00007942783d698f  movaps [rsp+0x20], xmm15
00007942783d6995  lea rdi, [rsp]
00007942783d6999  mov esi, 0x00
00007942783d699e  mov rax, 0x59DDDCBA3530
00007942783d69a8  call rax
00007942783d69aa  movaps xmm7, [rsp]
00007942783d69ae  add rsp, 0x30
00007942783d69b2  vmovaps xmm0, [rsp]
00007942783d69b7  vmovaps xmm1, [rsp+0x10]
00007942783d69bd  vmovaps xmm2, [rsp+0x20]
00007942783d69c3  vmovaps xmm3, [rsp+0x30]
00007942783d69c9  vmovaps xmm4, [rsp+0x40]
00007942783d69cf  vmovaps xmm5, [rsp+0x50]
00007942783d69d5  vmovaps xmm6, [rsp+0x60]
00007942783d69db  vmovaps xmm8, [rsp+0x70]
00007942783d69e1  vmovaps xmm9, [rsp+0x80]
00007942783d69ea  vmovaps xmm10, [rsp+0x90]
00007942783d69f3  vmovaps xmm11, [rsp+0xA0]
00007942783d69fc  vmovaps xmm12, [rsp+0xB0]
00007942783d6a05  vmovaps xmm13, [rsp+0xC0]
00007942783d6a0e  vmovaps xmm14, [rsp+0xD0]
00007942783d6a17  vmovaps xmm15, [rsp+0xE0]
00007942783d6a20  add rsp, 0xF0
00007942783d6a27  pop r11
00007942783d6a29  pop r10
00007942783d6a2b  pop r9
00007942783d6a2d  pop r8
00007942783d6a2f  pop rsi
00007942783d6a30  pop rdi
00007942783d6a31  pop rdx
00007942783d6a32  pop rcx
00007942783d6a33  pop rax
00007942783d6a34  add rsp, 0x08
00007942783d6a38  jmp 0x00007942783D59C8
00007942783d6a3d  sub rsp, 0x08
00007942783d6a41  push rax
00007942783d6a42  push rcx
00007942783d6a43  push rdx
00007942783d6a44  push rdi
00007942783d6a45  push rsi
00007942783d6a46  push r8
00007942783d6a48  push r9
00007942783d6a4a  push r10
00007942783d6a4c  push r11
00007942783d6a4e  sub rsp, 0xF0
00007942783d6a55  vmovaps [rsp], xmm0
00007942783d6a5a  vmovaps [rsp+0x10], xmm1
00007942783d6a60  vmovaps [rsp+0x20], xmm2
00007942783d6a66  vmovaps [rsp+0x30], xmm3
00007942783d6a6c  vmovaps [rsp+0x40], xmm4
00007942783d6a72  vmovaps [rsp+0x50], xmm5
00007942783d6a78  vmovaps [rsp+0x60], xmm6
00007942783d6a7e  vmovaps [rsp+0x70], xmm7
00007942783d6a84  vmovaps [rsp+0x80], xmm8
00007942783d6a8d  vmovaps [rsp+0x90], xmm10
00007942783d6a96  vmovaps [rsp+0xA0], xmm11
00007942783d6a9f  vmovaps [rsp+0xB0], xmm12
00007942783d6aa8  vmovaps [rsp+0xC0], xmm13
00007942783d6ab1  vmovaps [rsp+0xD0], xmm14
00007942783d6aba  vmovaps [rsp+0xE0], xmm15
00007942783d6ac3  sub rsp, 0x30
00007942783d6ac7  movaps [rsp], xmm9
00007942783d6acc  movaps [rsp+0x10], xmm12
00007942783d6ad2  movaps [rsp+0x20], xmm10
00007942783d6ad8  lea rdi, [rsp]
00007942783d6adc  mov esi, 0x00
00007942783d6ae1  mov rax, 0x59DDDCBA3530
00007942783d6aeb  call rax
00007942783d6aed  movaps xmm9, [rsp]
00007942783d6af2  add rsp, 0x30
00007942783d6af6  vmovaps xmm0, [rsp]
00007942783d6afb  vmovaps xmm1, [rsp+0x10]
00007942783d6b01  vmovaps xmm2, [rsp+0x20]
00007942783d6b07  vmovaps xmm3, [rsp+0x30]
00007942783d6b0d  vmovaps xmm4, [rsp+0x40]
00007942783d6b13  vmovaps xmm5, [rsp+0x50]
00007942783d6b19  vmovaps xmm6, [rsp+0x60]
00007942783d6b1f  vmovaps xmm7, [rsp+0x70]
00007942783d6b25  vmovaps xmm8, [rsp+0x80]
00007942783d6b2e  vmovaps xmm10, [rsp+0x90]
00007942783d6b37  vmovaps xmm11, [rsp+0xA0]
00007942783d6b40  vmovaps xmm12, [rsp+0xB0]
00007942783d6b49  vmovaps xmm13, [rsp+0xC0]
00007942783d6b52  vmovaps xmm14, [rsp+0xD0]
00007942783d6b5b  vmovaps xmm15, [rsp+0xE0]
00007942783d6b64  add rsp, 0xF0
00007942783d6b6b  pop r11
00007942783d6b6d  pop r10
00007942783d6b6f  pop r9
00007942783d6b71  pop r8
00007942783d6b73  pop rsi
00007942783d6b74  pop rdi
00007942783d6b75  pop rdx
00007942783d6b76  pop rcx
00007942783d6b77  pop rax
00007942783d6b78  add rsp, 0x08
00007942783d6b7c  jmp 0x00007942783D59EC
00007942783d6b81  sub rsp, 0x08
00007942783d6b85  push rax
00007942783d6b86  push rcx
00007942783d6b87  push rdx
00007942783d6b88  push rdi
00007942783d6b89  push rsi
00007942783d6b8a  push r8
00007942783d6b8c  push r9
00007942783d6b8e  push r10
00007942783d6b90  push r11
00007942783d6b92  sub rsp, 0xF0
00007942783d6b99  vmovaps [rsp], xmm0
00007942783d6b9e  vmovaps [rsp+0x10], xmm1
00007942783d6ba4  vmovaps [rsp+0x20], xmm2
00007942783d6baa  vmovaps [rsp+0x30], xmm3
00007942783d6bb0  vmovaps [rsp+0x40], xmm4
00007942783d6bb6  vmovaps [rsp+0x50], xmm5
00007942783d6bbc  vmovaps [rsp+0x60], xmm6
00007942783d6bc2  vmovaps [rsp+0x70], xmm7
00007942783d6bc8  vmovaps [rsp+0x80], xmm8
00007942783d6bd1  vmovaps [rsp+0x90], xmm9
00007942783d6bda  vmovaps [rsp+0xA0], xmm11
00007942783d6be3  vmovaps [rsp+0xB0], xmm12
00007942783d6bec  vmovaps [rsp+0xC0], xmm13
00007942783d6bf5  vmovaps [rsp+0xD0], xmm14
00007942783d6bfe  vmovaps [rsp+0xE0], xmm15
00007942783d6c07  sub rsp, 0x30
00007942783d6c0b  movaps [rsp], xmm10
00007942783d6c10  movaps [rsp+0x10], xmm12
00007942783d6c16  movaps [rsp+0x20], xmm11
00007942783d6c1c  lea rdi, [rsp]
00007942783d6c20  mov esi, 0x00
00007942783d6c25  mov rax, 0x59DDDCBA3530
00007942783d6c2f  call rax
00007942783d6c31  movaps xmm10, [rsp]
00007942783d6c36  add rsp, 0x30
00007942783d6c3a  vmovaps xmm0, [rsp]
00007942783d6c3f  vmovaps xmm1, [rsp+0x10]
00007942783d6c45  vmovaps xmm2, [rsp+0x20]
00007942783d6c4b  vmovaps xmm3, [rsp+0x30]
00007942783d6c51  vmovaps xmm4, [rsp+0x40]
00007942783d6c57  vmovaps xmm5, [rsp+0x50]
00007942783d6c5d  vmovaps xmm6, [rsp+0x60]
00007942783d6c63  vmovaps xmm7, [rsp+0x70]
00007942783d6c69  vmovaps xmm8, [rsp+0x80]
00007942783d6c72  vmovaps xmm9, [rsp+0x90]
00007942783d6c7b  vmovaps xmm11, [rsp+0xA0]
00007942783d6c84  vmovaps xmm12, [rsp+0xB0]
00007942783d6c8d  vmovaps xmm13, [rsp+0xC0]
00007942783d6c96  vmovaps xmm14, [rsp+0xD0]
00007942783d6c9f  vmovaps xmm15, [rsp+0xE0]
00007942783d6ca8  add rsp, 0xF0
00007942783d6caf  pop r11
00007942783d6cb1  pop r10
00007942783d6cb3  pop r9
00007942783d6cb5  pop r8
00007942783d6cb7  pop rsi
00007942783d6cb8  pop rdi
00007942783d6cb9  pop rdx
00007942783d6cba  pop rcx
00007942783d6cbb  pop rax
00007942783d6cbc  add rsp, 0x08
00007942783d6cc0  jmp 0x00007942783D5A06
00007942783d6cc5  sub rsp, 0x08
00007942783d6cc9  push rax
00007942783d6cca  push rcx
00007942783d6ccb  push rdx
00007942783d6ccc  push rdi
00007942783d6ccd  push rsi
00007942783d6cce  push r8
00007942783d6cd0  push r9
00007942783d6cd2  push r10
00007942783d6cd4  push r11
00007942783d6cd6  sub rsp, 0xF0
00007942783d6cdd  vmovaps [rsp], xmm0
00007942783d6ce2  vmovaps [rsp+0x10], xmm1
00007942783d6ce8  vmovaps [rsp+0x20], xmm2
00007942783d6cee  vmovaps [rsp+0x30], xmm3
00007942783d6cf4  vmovaps [rsp+0x40], xmm4
00007942783d6cfa  vmovaps [rsp+0x50], xmm5
00007942783d6d00  vmovaps [rsp+0x60], xmm7
00007942783d6d06  vmovaps [rsp+0x70], xmm8
00007942783d6d0c  vmovaps [rsp+0x80], xmm9
00007942783d6d15  vmovaps [rsp+0x90], xmm10
00007942783d6d1e  vmovaps [rsp+0xA0], xmm11
00007942783d6d27  vmovaps [rsp+0xB0], xmm12
00007942783d6d30  vmovaps [rsp+0xC0], xmm13
00007942783d6d39  vmovaps [rsp+0xD0], xmm14
00007942783d6d42  vmovaps [rsp+0xE0], xmm15
00007942783d6d4b  sub rsp, 0x30
00007942783d6d4f  movaps [rsp], xmm6
00007942783d6d53  movaps [rsp+0x10], xmm12
00007942783d6d59  movaps [rsp+0x20], xmm11
00007942783d6d5f  lea rdi, [rsp]
00007942783d6d63  mov esi, 0x00
00007942783d6d68  mov rax, 0x59DDDCBA3530
00007942783d6d72  call rax
00007942783d6d74  movaps xmm6, [rsp]
00007942783d6d78  add rsp, 0x30
00007942783d6d7c  vmovaps xmm0, [rsp]
00007942783d6d81  vmovaps xmm1, [rsp+0x10]
00007942783d6d87  vmovaps xmm2, [rsp+0x20]
00007942783d6d8d  vmovaps xmm3, [rsp+0x30]
00007942783d6d93  vmovaps xmm4, [rsp+0x40]
00007942783d6d99  vmovaps xmm5, [rsp+0x50]
00007942783d6d9f  vmovaps xmm7, [rsp+0x60]
00007942783d6da5  vmovaps xmm8, [rsp+0x70]
00007942783d6dab  vmovaps xmm9, [rsp+0x80]
00007942783d6db4  vmovaps xmm10, [rsp+0x90]
00007942783d6dbd  vmovaps xmm11, [rsp+0xA0]
00007942783d6dc6  vmovaps xmm12, [rsp+0xB0]
00007942783d6dcf  vmovaps xmm13, [rsp+0xC0]
00007942783d6dd8  vmovaps xmm14, [rsp+0xD0]
00007942783d6de1  vmovaps xmm15, [rsp+0xE0]
00007942783d6dea  add rsp, 0xF0
00007942783d6df1  pop r11
00007942783d6df3  pop r10
00007942783d6df5  pop r9
00007942783d6df7  pop r8
00007942783d6df9  pop rsi
00007942783d6dfa  pop rdi
00007942783d6dfb  pop rdx
00007942783d6dfc  pop rcx
00007942783d6dfd  pop rax
00007942783d6dfe  add rsp, 0x08
00007942783d6e02  jmp 0x00007942783D5A27
00007942783d6e07  sub rsp, 0x08
00007942783d6e0b  push rax
00007942783d6e0c  push rcx
00007942783d6e0d  push rdx
00007942783d6e0e  push rdi
00007942783d6e0f  push rsi
00007942783d6e10  push r8
00007942783d6e12  push r9
00007942783d6e14  push r10
00007942783d6e16  push r11
00007942783d6e18  sub rsp, 0xF0
00007942783d6e1f  vmovaps [rsp], xmm0
00007942783d6e24  vmovaps [rsp+0x10], xmm1
00007942783d6e2a  vmovaps [rsp+0x20], xmm2
00007942783d6e30  vmovaps [rsp+0x30], xmm4
00007942783d6e36  vmovaps [rsp+0x40], xmm5
00007942783d6e3c  vmovaps [rsp+0x50], xmm6
00007942783d6e42  vmovaps [rsp+0x60], xmm7
00007942783d6e48  vmovaps [rsp+0x70], xmm8
00007942783d6e4e  vmovaps [rsp+0x80], xmm9
00007942783d6e57  vmovaps [rsp+0x90], xmm10
00007942783d6e60  vmovaps [rsp+0xA0], xmm11
00007942783d6e69  vmovaps [rsp+0xB0], xmm12
00007942783d6e72  vmovaps [rsp+0xC0], xmm13
00007942783d6e7b  vmovaps [rsp+0xD0], xmm14
00007942783d6e84  vmovaps [rsp+0xE0], xmm15
00007942783d6e8d  sub rsp, 0x30
00007942783d6e91  movaps [rsp], xmm3
00007942783d6e95  movaps [rsp+0x10], xmm5
00007942783d6e9a  movaps [rsp+0x20], xmm4
00007942783d6e9f  lea rdi, [rsp]
00007942783d6ea3  mov esi, 0x00
00007942783d6ea8  mov rax, 0x59DDDCBA3530
00007942783d6eb2  call rax
00007942783d6eb4  movaps xmm3, [rsp]
00007942783d6eb8  add rsp, 0x30
00007942783d6ebc  vmovaps xmm0, [rsp]
00007942783d6ec1  vmovaps xmm1, [rsp+0x10]
00007942783d6ec7  vmovaps xmm2, [rsp+0x20]
00007942783d6ecd  vmovaps xmm4, [rsp+0x30]
00007942783d6ed3  vmovaps xmm5, [rsp+0x40]
00007942783d6ed9  vmovaps xmm6, [rsp+0x50]
00007942783d6edf  vmovaps xmm7, [rsp+0x60]
00007942783d6ee5  vmovaps xmm8, [rsp+0x70]
00007942783d6eeb  vmovaps xmm9, [rsp+0x80]
00007942783d6ef4  vmovaps xmm10, [rsp+0x90]
00007942783d6efd  vmovaps xmm11, [rsp+0xA0]
00007942783d6f06  vmovaps xmm12, [rsp+0xB0]
00007942783d6f0f  vmovaps xmm13, [rsp+0xC0]
00007942783d6f18  vmovaps xmm14, [rsp+0xD0]
00007942783d6f21  vmovaps xmm15, [rsp+0xE0]
00007942783d6f2a  add rsp, 0xF0
00007942783d6f31  pop r11
00007942783d6f33  pop r10
00007942783d6f35  pop r9
00007942783d6f37  pop r8
00007942783d6f39  pop rsi
00007942783d6f3a  pop rdi
00007942783d6f3b  pop rdx
00007942783d6f3c  pop rcx
00007942783d6f3d  pop rax
00007942783d6f3e  add rsp, 0x08
00007942783d6f42  jmp 0x00007942783D5A88
00007942783d6f47  sub rsp, 0x08
00007942783d6f4b  push rax
00007942783d6f4c  push rcx
00007942783d6f4d  push rdx
00007942783d6f4e  push rdi
00007942783d6f4f  push rsi
00007942783d6f50  push r8
00007942783d6f52  push r9
00007942783d6f54  push r10
00007942783d6f56  push r11
00007942783d6f58  sub rsp, 0xF0
00007942783d6f5f  vmovaps [rsp], xmm0
00007942783d6f64  vmovaps [rsp+0x10], xmm1
00007942783d6f6a  vmovaps [rsp+0x20], xmm2
00007942783d6f70  vmovaps [rsp+0x30], xmm3
00007942783d6f76  vmovaps [rsp+0x40], xmm4
00007942783d6f7c  vmovaps [rsp+0x50], xmm6
00007942783d6f82  vmovaps [rsp+0x60], xmm7
00007942783d6f88  vmovaps [rsp+0x70], xmm8
00007942783d6f8e  vmovaps [rsp+0x80], xmm9
00007942783d6f97  vmovaps [rsp+0x90], xmm10
00007942783d6fa0  vmovaps [rsp+0xA0], xmm11
00007942783d6fa9  vmovaps [rsp+0xB0], xmm12
00007942783d6fb2  vmovaps [rsp+0xC0], xmm13
00007942783d6fbb  vmovaps [rsp+0xD0], xmm14
00007942783d6fc4  vmovaps [rsp+0xE0], xmm15
00007942783d6fcd  sub rsp, 0x30
00007942783d6fd1  movaps [rsp], xmm5
00007942783d6fd5  movaps [rsp+0x10], xmm8
00007942783d6fdb  movaps [rsp+0x20], xmm15
00007942783d6fe1  lea rdi, [rsp]
00007942783d6fe5  mov esi, 0x00
00007942783d6fea  mov rax, 0x59DDDCBA3530
00007942783d6ff4  call rax
00007942783d6ff6  movaps xmm5, [rsp]
00007942783d6ffa  add rsp, 0x30
00007942783d6ffe  vmovaps xmm0, [rsp]
00007942783d7003  vmovaps xmm1, [rsp+0x10]
00007942783d7009  vmovaps xmm2, [rsp+0x20]
00007942783d700f  vmovaps xmm3, [rsp+0x30]
00007942783d7015  vmovaps xmm4, [rsp+0x40]
00007942783d701b  vmovaps xmm6, [rsp+0x50]
00007942783d7021  vmovaps xmm7, [rsp+0x60]
00007942783d7027  vmovaps xmm8, [rsp+0x70]
00007942783d702d  vmovaps xmm9, [rsp+0x80]
00007942783d7036  vmovaps xmm10, [rsp+0x90]
00007942783d703f  vmovaps xmm11, [rsp+0xA0]
00007942783d7048  vmovaps xmm12, [rsp+0xB0]
00007942783d7051  vmovaps xmm13, [rsp+0xC0]
00007942783d705a  vmovaps xmm14, [rsp+0xD0]
00007942783d7063  vmovaps xmm15, [rsp+0xE0]
00007942783d706c  add rsp, 0xF0
00007942783d7073  pop r11
00007942783d7075  pop r10
00007942783d7077  pop r9
00007942783d7079  pop r8
00007942783d707b  pop rsi
00007942783d707c  pop rdi
00007942783d707d  pop rdx
00007942783d707e  pop rcx
00007942783d707f  pop rax
00007942783d7080  add rsp, 0x08
00007942783d7084  jmp 0x00007942783D5AC0
00007942783d7089  sub rsp, 0x08
00007942783d708d  push rax
00007942783d708e  push rcx
00007942783d708f  push rdx
00007942783d7090  push rdi
00007942783d7091  push rsi
00007942783d7092  push r8
00007942783d7094  push r9
00007942783d7096  push r10
00007942783d7098  push r11
00007942783d709a  sub rsp, 0xF0
00007942783d70a1  vmovaps [rsp], xmm0
00007942783d70a6  vmovaps [rsp+0x10], xmm1
00007942783d70ac  vmovaps [rsp+0x20], xmm2
00007942783d70b2  vmovaps [rsp+0x30], xmm3
00007942783d70b8  vmovaps [rsp+0x40], xmm5
00007942783d70be  vmovaps [rsp+0x50], xmm6
00007942783d70c4  vmovaps [rsp+0x60], xmm7
00007942783d70ca  vmovaps [rsp+0x70], xmm8
00007942783d70d0  vmovaps [rsp+0x80], xmm9
00007942783d70d9  vmovaps [rsp+0x90], xmm10
00007942783d70e2  vmovaps [rsp+0xA0], xmm11
00007942783d70eb  vmovaps [rsp+0xB0], xmm12
00007942783d70f4  vmovaps [rsp+0xC0], xmm13
00007942783d70fd  vmovaps [rsp+0xD0], xmm14
00007942783d7106  vmovaps [rsp+0xE0], xmm15
00007942783d710f  sub rsp, 0x30
00007942783d7113  movaps [rsp], xmm4
00007942783d7117  movaps [rsp+0x10], xmm9
00007942783d711d  movaps [rsp+0x20], xmm8
00007942783d7123  lea rdi, [rsp]
00007942783d7127  mov esi, 0x00
00007942783d712c  mov rax, 0x59DDDCBA3530
00007942783d7136  call rax
00007942783d7138  movaps xmm4, [rsp]
00007942783d713c  add rsp, 0x30
00007942783d7140  vmovaps xmm0, [rsp]
00007942783d7145  vmovaps xmm1, [rsp+0x10]
00007942783d714b  vmovaps xmm2, [rsp+0x20]
00007942783d7151  vmovaps xmm3, [rsp+0x30]
00007942783d7157  vmovaps xmm5, [rsp+0x40]
00007942783d715d  vmovaps xmm6, [rsp+0x50]
00007942783d7163  vmovaps xmm7, [rsp+0x60]
00007942783d7169  vmovaps xmm8, [rsp+0x70]
00007942783d716f  vmovaps xmm9, [rsp+0x80]
00007942783d7178  vmovaps xmm10, [rsp+0x90]
00007942783d7181  vmovaps xmm11, [rsp+0xA0]
00007942783d718a  vmovaps xmm12, [rsp+0xB0]
00007942783d7193  vmovaps xmm13, [rsp+0xC0]
00007942783d719c  vmovaps xmm14, [rsp+0xD0]
00007942783d71a5  vmovaps xmm15, [rsp+0xE0]
00007942783d71ae  add rsp, 0xF0
00007942783d71b5  pop r11
00007942783d71b7  pop r10
00007942783d71b9  pop r9
00007942783d71bb  pop r8
00007942783d71bd  pop rsi
00007942783d71be  pop rdi
00007942783d71bf  pop rdx
00007942783d71c0  pop rcx
00007942783d71c1  pop rax
00007942783d71c2  add rsp, 0x08
00007942783d71c6  jmp 0x00007942783D5AE1
00007942783d71cb  sub rsp, 0x08
00007942783d71cf  push rax
00007942783d71d0  push rcx
00007942783d71d1  push rdx
00007942783d71d2  push rdi
00007942783d71d3  push rsi
00007942783d71d4  push r8
00007942783d71d6  push r9
00007942783d71d8  push r10
00007942783d71da  push r11
00007942783d71dc  sub rsp, 0xF0
00007942783d71e3  vmovaps [rsp], xmm0
00007942783d71e8  vmovaps [rsp+0x10], xmm1
00007942783d71ee  vmovaps [rsp+0x20], xmm2
00007942783d71f4  vmovaps [rsp+0x30], xmm3
00007942783d71fa  vmovaps [rsp+0x40], xmm4
00007942783d7200  vmovaps [rsp+0x50], xmm5
00007942783d7206  vmovaps [rsp+0x60], xmm6
00007942783d720c  vmovaps [rsp+0x70], xmm7
00007942783d7212  vmovaps [rsp+0x80], xmm8
00007942783d721b  vmovaps [rsp+0x90], xmm10
00007942783d7224  vmovaps [rsp+0xA0], xmm11
00007942783d722d  vmovaps [rsp+0xB0], xmm12
00007942783d7236  vmovaps [rsp+0xC0], xmm13
00007942783d723f  vmovaps [rsp+0xD0], xmm14
00007942783d7248  vmovaps [rsp+0xE0], xmm15
00007942783d7251  sub rsp, 0x30
00007942783d7255  movaps [rsp], xmm9
00007942783d725a  movaps [rsp+0x10], xmm10
00007942783d7260  movaps [rsp+0x20], xmm8
00007942783d7266  lea rdi, [rsp]
00007942783d726a  mov esi, 0x00
00007942783d726f  mov rax, 0x59DDDCBA3530
00007942783d7279  call rax
00007942783d727b  movaps xmm9, [rsp]
00007942783d7280  add rsp, 0x30
00007942783d7284  vmovaps xmm0, [rsp]
00007942783d7289  vmovaps xmm1, [rsp+0x10]
00007942783d728f  vmovaps xmm2, [rsp+0x20]
00007942783d7295  vmovaps xmm3, [rsp+0x30]
00007942783d729b  vmovaps xmm4, [rsp+0x40]
00007942783d72a1  vmovaps xmm5, [rsp+0x50]
00007942783d72a7  vmovaps xmm6, [rsp+0x60]
00007942783d72ad  vmovaps xmm7, [rsp+0x70]
00007942783d72b3  vmovaps xmm8, [rsp+0x80]
00007942783d72bc  vmovaps xmm10, [rsp+0x90]
00007942783d72c5  vmovaps xmm11, [rsp+0xA0]
00007942783d72ce  vmovaps xmm12, [rsp+0xB0]
00007942783d72d7  vmovaps xmm13, [rsp+0xC0]
00007942783d72e0  vmovaps xmm14, [rsp+0xD0]
00007942783d72e9  vmovaps xmm15, [rsp+0xE0]
00007942783d72f2  add rsp, 0xF0
00007942783d72f9  pop r11
00007942783d72fb  pop r10
00007942783d72fd  pop r9
00007942783d72ff  pop r8
00007942783d7301  pop rsi
00007942783d7302  pop rdi
00007942783d7303  pop rdx
00007942783d7304  pop rcx
00007942783d7305  pop rax
00007942783d7306  add rsp, 0x08
00007942783d730a  jmp 0x00007942783D5AFB
00007942783d730f  call 0x00007942782D64F0
00007942783d7314  jmp 0x00007942783D5C15
00007942783d7319  call 0x00007942782D64F0
00007942783d731e  jmp 0x00007942783D5C2B
00007942783d7323  sub rsp, 0x08
00007942783d7327  push rax
00007942783d7328  push rcx
00007942783d7329  push rdx
00007942783d732a  push rdi
00007942783d732b  push rsi
00007942783d732c  push r8
00007942783d732e  push r9
00007942783d7330  push r10
00007942783d7332  push r11
00007942783d7334  sub rsp, 0xF0
00007942783d733b  vmovaps [rsp], xmm0
00007942783d7340  vmovaps [rsp+0x10], xmm2
00007942783d7346  vmovaps [rsp+0x20], xmm3
00007942783d734c  vmovaps [rsp+0x30], xmm4
00007942783d7352  vmovaps [rsp+0x40], xmm5
00007942783d7358  vmovaps [rsp+0x50], xmm6
00007942783d735e  vmovaps [rsp+0x60], xmm7
00007942783d7364  vmovaps [rsp+0x70], xmm8
00007942783d736a  vmovaps [rsp+0x80], xmm9
00007942783d7373  vmovaps [rsp+0x90], xmm10
00007942783d737c  vmovaps [rsp+0xA0], xmm11
00007942783d7385  vmovaps [rsp+0xB0], xmm12
00007942783d738e  vmovaps [rsp+0xC0], xmm13
00007942783d7397  vmovaps [rsp+0xD0], xmm14
00007942783d73a0  vmovaps [rsp+0xE0], xmm15
00007942783d73a9  sub rsp, 0x30
00007942783d73ad  movaps [rsp], xmm1
00007942783d73b1  movaps [rsp+0x10], xmm6
00007942783d73b6  movaps [rsp+0x20], xmm15
00007942783d73bc  lea rdi, [rsp]
00007942783d73c0  mov esi, 0x00
00007942783d73c5  mov rax, 0x59DDDCBA3530
00007942783d73cf  call rax
00007942783d73d1  movaps xmm1, [rsp]
00007942783d73d5  add rsp, 0x30
00007942783d73d9  vmovaps xmm0, [rsp]
00007942783d73de  vmovaps xmm2, [rsp+0x10]
00007942783d73e4  vmovaps xmm3, [rsp+0x20]
00007942783d73ea  vmovaps xmm4, [rsp+0x30]
00007942783d73f0  vmovaps xmm5, [rsp+0x40]
00007942783d73f6  vmovaps xmm6, [rsp+0x50]
00007942783d73fc  vmovaps xmm7, [rsp+0x60]
00007942783d7402  vmovaps xmm8, [rsp+0x70]
00007942783d7408  vmovaps xmm9, [rsp+0x80]
00007942783d7411  vmovaps xmm10, [rsp+0x90]
00007942783d741a  vmovaps xmm11, [rsp+0xA0]
00007942783d7423  vmovaps xmm12, [rsp+0xB0]
00007942783d742c  vmovaps xmm13, [rsp+0xC0]
00007942783d7435  vmovaps xmm14, [rsp+0xD0]
00007942783d743e  vmovaps xmm15, [rsp+0xE0]
00007942783d7447  add rsp, 0xF0
00007942783d744e  pop r11
00007942783d7450  pop r10
00007942783d7452  pop r9
00007942783d7454  pop r8
00007942783d7456  pop rsi
00007942783d7457  pop rdi
00007942783d7458  pop rdx
00007942783d7459  pop rcx
00007942783d745a  pop rax
00007942783d745b  add rsp, 0x08
00007942783d745f  jmp 0x00007942783D5C68
00007942783d7464  call 0x00007942782E5820
00007942783d7469  jmp 0x00007942783D5C75
00007942783d746e  sub rsp, 0x08
00007942783d7472  push rax
00007942783d7473  push rcx
00007942783d7474  push rdx
00007942783d7475  push rdi
00007942783d7476  push rsi
00007942783d7477  push r8
00007942783d7479  push r9
00007942783d747b  push r10
00007942783d747d  push r11
00007942783d747f  sub rsp, 0xF0
00007942783d7486  vmovaps [rsp], xmm0
00007942783d748b  vmovaps [rsp+0x10], xmm1
00007942783d7491  vmovaps [rsp+0x20], xmm2
00007942783d7497  vmovaps [rsp+0x30], xmm3
00007942783d749d  vmovaps [rsp+0x40], xmm4
00007942783d74a3  vmovaps [rsp+0x50], xmm5
00007942783d74a9  vmovaps [rsp+0x60], xmm6
00007942783d74af  vmovaps [rsp+0x70], xmm7
00007942783d74b5  vmovaps [rsp+0x80], xmm8
00007942783d74be  vmovaps [rsp+0x90], xmm9
00007942783d74c7  vmovaps [rsp+0xA0], xmm10
00007942783d74d0  vmovaps [rsp+0xB0], xmm11
00007942783d74d9  vmovaps [rsp+0xC0], xmm12
00007942783d74e2  vmovaps [rsp+0xD0], xmm13
00007942783d74eb  vmovaps [rsp+0xE0], xmm15
00007942783d74f4  sub rsp, 0x30
00007942783d74f8  movaps [rsp], xmm14
00007942783d74fd  movaps [rsp+0x10], xmm4
00007942783d7502  movaps [rsp+0x20], xmm3
00007942783d7507  lea rdi, [rsp]
00007942783d750b  mov esi, 0x00
00007942783d7510  mov rax, 0x59DDDCBA3530
00007942783d751a  call rax
00007942783d751c  movaps xmm14, [rsp]
00007942783d7521  add rsp, 0x30
00007942783d7525  vmovaps xmm0, [rsp]
00007942783d752a  vmovaps xmm1, [rsp+0x10]
00007942783d7530  vmovaps xmm2, [rsp+0x20]
00007942783d7536  vmovaps xmm3, [rsp+0x30]
00007942783d753c  vmovaps xmm4, [rsp+0x40]
00007942783d7542  vmovaps xmm5, [rsp+0x50]
00007942783d7548  vmovaps xmm6, [rsp+0x60]
00007942783d754e  vmovaps xmm7, [rsp+0x70]
00007942783d7554  vmovaps xmm8, [rsp+0x80]
00007942783d755d  vmovaps xmm9, [rsp+0x90]
00007942783d7566  vmovaps xmm10, [rsp+0xA0]
00007942783d756f  vmovaps xmm11, [rsp+0xB0]
00007942783d7578  vmovaps xmm12, [rsp+0xC0]
00007942783d7581  vmovaps xmm13, [rsp+0xD0]
00007942783d758a  vmovaps xmm15, [rsp+0xE0]
00007942783d7593  add rsp, 0xF0
00007942783d759a  pop r11
00007942783d759c  pop r10
00007942783d759e  pop r9
00007942783d75a0  pop r8
00007942783d75a2  pop rsi
00007942783d75a3  pop rdi
00007942783d75a4  pop rdx
00007942783d75a5  pop rcx
00007942783d75a6  pop rax
00007942783d75a7  add rsp, 0x08
00007942783d75ab  jmp 0x00007942783D5C8F
00007942783d75b0  sub rsp, 0x08
00007942783d75b4  push rax
00007942783d75b5  push rcx
00007942783d75b6  push rdx
00007942783d75b7  push rdi
00007942783d75b8  push rsi
00007942783d75b9  push r8
00007942783d75bb  push r9
00007942783d75bd  push r10
00007942783d75bf  push r11
00007942783d75c1  sub rsp, 0xF0
00007942783d75c8  vmovaps [rsp], xmm0
00007942783d75cd  vmovaps [rsp+0x10], xmm1
00007942783d75d3  vmovaps [rsp+0x20], xmm2
00007942783d75d9  vmovaps [rsp+0x30], xmm3
00007942783d75df  vmovaps [rsp+0x40], xmm4
00007942783d75e5  vmovaps [rsp+0x50], xmm5
00007942783d75eb  vmovaps [rsp+0x60], xmm7
00007942783d75f1  vmovaps [rsp+0x70], xmm8
00007942783d75f7  vmovaps [rsp+0x80], xmm9
00007942783d7600  vmovaps [rsp+0x90], xmm10
00007942783d7609  vmovaps [rsp+0xA0], xmm11
00007942783d7612  vmovaps [rsp+0xB0], xmm12
00007942783d761b  vmovaps [rsp+0xC0], xmm13
00007942783d7624  vmovaps [rsp+0xD0], xmm14
00007942783d762d  vmovaps [rsp+0xE0], xmm15
00007942783d7636  sub rsp, 0x30
00007942783d763a  movaps [rsp], xmm6
00007942783d763e  movaps [rsp+0x10], xmm9
00007942783d7644  movaps [rsp+0x20], xmm7
00007942783d7649  lea rdi, [rsp]
00007942783d764d  mov esi, 0x00
00007942783d7652  mov rax, 0x59DDDCBA3530
00007942783d765c  call rax
00007942783d765e  movaps xmm6, [rsp]
00007942783d7662  add rsp, 0x30
00007942783d7666  vmovaps xmm0, [rsp]
00007942783d766b  vmovaps xmm1, [rsp+0x10]
00007942783d7671  vmovaps xmm2, [rsp+0x20]
00007942783d7677  vmovaps xmm3, [rsp+0x30]
00007942783d767d  vmovaps xmm4, [rsp+0x40]
00007942783d7683  vmovaps xmm5, [rsp+0x50]
00007942783d7689  vmovaps xmm7, [rsp+0x60]
00007942783d768f  vmovaps xmm8, [rsp+0x70]
00007942783d7695  vmovaps xmm9, [rsp+0x80]
00007942783d769e  vmovaps xmm10, [rsp+0x90]
00007942783d76a7  vmovaps xmm11, [rsp+0xA0]
00007942783d76b0  vmovaps xmm12, [rsp+0xB0]
00007942783d76b9  vmovaps xmm13, [rsp+0xC0]
00007942783d76c2  vmovaps xmm14, [rsp+0xD0]
00007942783d76cb  vmovaps xmm15, [rsp+0xE0]
00007942783d76d4  add rsp, 0xF0
00007942783d76db  pop r11
00007942783d76dd  pop r10
00007942783d76df  pop r9
00007942783d76e1  pop r8
00007942783d76e3  pop rsi
00007942783d76e4  pop rdi
00007942783d76e5  pop rdx
00007942783d76e6  pop rcx
00007942783d76e7  pop rax
00007942783d76e8  add rsp, 0x08
00007942783d76ec  jmp 0x00007942783D5CA7
00007942783d76f1  sub rsp, 0x08
00007942783d76f5  push rax
00007942783d76f6  push rcx
00007942783d76f7  push rdx
00007942783d76f8  push rdi
00007942783d76f9  push rsi
00007942783d76fa  push r8
00007942783d76fc  push r9
00007942783d76fe  push r10
00007942783d7700  push r11
00007942783d7702  sub rsp, 0xF0
00007942783d7709  vmovaps [rsp], xmm0
00007942783d770e  vmovaps [rsp+0x10], xmm1
00007942783d7714  vmovaps [rsp+0x20], xmm2
00007942783d771a  vmovaps [rsp+0x30], xmm3
00007942783d7720  vmovaps [rsp+0x40], xmm4
00007942783d7726  vmovaps [rsp+0x50], xmm5
00007942783d772c  vmovaps [rsp+0x60], xmm6
00007942783d7732  vmovaps [rsp+0x70], xmm8
00007942783d7738  vmovaps [rsp+0x80], xmm9
00007942783d7741  vmovaps [rsp+0x90], xmm10
00007942783d774a  vmovaps [rsp+0xA0], xmm11
00007942783d7753  vmovaps [rsp+0xB0], xmm12
00007942783d775c  vmovaps [rsp+0xC0], xmm13
00007942783d7765  vmovaps [rsp+0xD0], xmm14
00007942783d776e  vmovaps [rsp+0xE0], xmm15
00007942783d7777  sub rsp, 0x30
00007942783d777b  movaps [rsp], xmm7
00007942783d777f  movaps [rsp+0x10], xmm4
00007942783d7784  movaps [rsp+0x20], xmm9
00007942783d778a  lea rdi, [rsp]
00007942783d778e  mov esi, 0x00
00007942783d7793  mov rax, 0x59DDDCBA3530
00007942783d779d  call rax
00007942783d779f  movaps xmm7, [rsp]
00007942783d77a3  add rsp, 0x30
00007942783d77a7  vmovaps xmm0, [rsp]
00007942783d77ac  vmovaps xmm1, [rsp+0x10]
00007942783d77b2  vmovaps xmm2, [rsp+0x20]
00007942783d77b8  vmovaps xmm3, [rsp+0x30]
00007942783d77be  vmovaps xmm4, [rsp+0x40]
00007942783d77c4  vmovaps xmm5, [rsp+0x50]
00007942783d77ca  vmovaps xmm6, [rsp+0x60]
00007942783d77d0  vmovaps xmm8, [rsp+0x70]
00007942783d77d6  vmovaps xmm9, [rsp+0x80]
00007942783d77df  vmovaps xmm10, [rsp+0x90]
00007942783d77e8  vmovaps xmm11, [rsp+0xA0]
00007942783d77f1  vmovaps xmm12, [rsp+0xB0]
00007942783d77fa  vmovaps xmm13, [rsp+0xC0]
00007942783d7803  vmovaps xmm14, [rsp+0xD0]
00007942783d780c  vmovaps xmm15, [rsp+0xE0]
00007942783d7815  add rsp, 0xF0
00007942783d781c  pop r11
00007942783d781e  pop r10
00007942783d7820  pop r9
00007942783d7822  pop r8
00007942783d7824  pop rsi
00007942783d7825  pop rdi
00007942783d7826  pop rdx
00007942783d7827  pop rcx
00007942783d7828  pop rax
00007942783d7829  add rsp, 0x08
00007942783d782d  jmp 0x00007942783D5CD4
00007942783d7832  sub rsp, 0x08
00007942783d7836  push rax
00007942783d7837  push rcx
00007942783d7838  push rdx
00007942783d7839  push rdi
00007942783d783a  push rsi
00007942783d783b  push r8
00007942783d783d  push r9
00007942783d783f  push r10
00007942783d7841  push r11
00007942783d7843  sub rsp, 0xF0
00007942783d784a  vmovaps [rsp], xmm0
00007942783d784f  vmovaps [rsp+0x10], xmm1
00007942783d7855  vmovaps [rsp+0x20], xmm2
00007942783d785b  vmovaps [rsp+0x30], xmm3
00007942783d7861  vmovaps [rsp+0x40], xmm5
00007942783d7867  vmovaps [rsp+0x50], xmm6
00007942783d786d  vmovaps [rsp+0x60], xmm7
00007942783d7873  vmovaps [rsp+0x70], xmm8
00007942783d7879  vmovaps [rsp+0x80], xmm9
00007942783d7882  vmovaps [rsp+0x90], xmm10
00007942783d788b  vmovaps [rsp+0xA0], xmm11
00007942783d7894  vmovaps [rsp+0xB0], xmm12
00007942783d789d  vmovaps [rsp+0xC0], xmm13
00007942783d78a6  vmovaps [rsp+0xD0], xmm14
00007942783d78af  vmovaps [rsp+0xE0], xmm15
00007942783d78b8  sub rsp, 0x30
00007942783d78bc  movaps [rsp], xmm4
00007942783d78c0  movaps [rsp+0x10], xmm15
00007942783d78c6  movaps [rsp+0x20], xmm9
00007942783d78cc  lea rdi, [rsp]
00007942783d78d0  mov esi, 0x00
00007942783d78d5  mov rax, 0x59DDDCBA3530
00007942783d78df  call rax
00007942783d78e1  movaps xmm4, [rsp]
00007942783d78e5  add rsp, 0x30
00007942783d78e9  vmovaps xmm0, [rsp]
00007942783d78ee  vmovaps xmm1, [rsp+0x10]
00007942783d78f4  vmovaps xmm2, [rsp+0x20]
00007942783d78fa  vmovaps xmm3, [rsp+0x30]
00007942783d7900  vmovaps xmm5, [rsp+0x40]
00007942783d7906  vmovaps xmm6, [rsp+0x50]
00007942783d790c  vmovaps xmm7, [rsp+0x60]
00007942783d7912  vmovaps xmm8, [rsp+0x70]
00007942783d7918  vmovaps xmm9, [rsp+0x80]
00007942783d7921  vmovaps xmm10, [rsp+0x90]
00007942783d792a  vmovaps xmm11, [rsp+0xA0]
00007942783d7933  vmovaps xmm12, [rsp+0xB0]
00007942783d793c  vmovaps xmm13, [rsp+0xC0]
00007942783d7945  vmovaps xmm14, [rsp+0xD0]
00007942783d794e  vmovaps xmm15, [rsp+0xE0]
00007942783d7957  add rsp, 0xF0
00007942783d795e  pop r11
00007942783d7960  pop r10
00007942783d7962  pop r9
00007942783d7964  pop r8
00007942783d7966  pop rsi
00007942783d7967  pop rdi
00007942783d7968  pop rdx
00007942783d7969  pop rcx
00007942783d796a  pop rax
00007942783d796b  add rsp, 0x08
00007942783d796f  jmp 0x00007942783D5CF9
00007942783d7974  call 0x00007942782E5820
00007942783d7979  jmp 0x00007942783D5D06
00007942783d797e  sub rsp, 0x08
00007942783d7982  push rax
00007942783d7983  push rcx
00007942783d7984  push rdx
00007942783d7985  push rdi
00007942783d7986  push rsi
00007942783d7987  push r8
00007942783d7989  push r9
00007942783d798b  push r10
00007942783d798d  push r11
00007942783d798f  sub rsp, 0xF0
00007942783d7996  vmovaps [rsp], xmm0
00007942783d799b  vmovaps [rsp+0x10], xmm1
00007942783d79a1  vmovaps [rsp+0x20], xmm2
00007942783d79a7  vmovaps [rsp+0x30], xmm4
00007942783d79ad  vmovaps [rsp+0x40], xmm5
00007942783d79b3  vmovaps [rsp+0x50], xmm6
00007942783d79b9  vmovaps [rsp+0x60], xmm7
00007942783d79bf  vmovaps [rsp+0x70], xmm8
00007942783d79c5  vmovaps [rsp+0x80], xmm9
00007942783d79ce  vmovaps [rsp+0x90], xmm10
00007942783d79d7  vmovaps [rsp+0xA0], xmm11
00007942783d79e0  vmovaps [rsp+0xB0], xmm12
00007942783d79e9  vmovaps [rsp+0xC0], xmm13
00007942783d79f2  vmovaps [rsp+0xD0], xmm14
00007942783d79fb  vmovaps [rsp+0xE0], xmm15
00007942783d7a04  sub rsp, 0x30
00007942783d7a08  movaps [rsp], xmm3
00007942783d7a0c  movaps [rsp+0x10], xmm1
00007942783d7a11  movaps [rsp+0x20], xmm9
00007942783d7a17  lea rdi, [rsp]
00007942783d7a1b  mov esi, 0x00
00007942783d7a20  mov rax, 0x59DDDCBA3530
00007942783d7a2a  call rax
00007942783d7a2c  movaps xmm3, [rsp]
00007942783d7a30  add rsp, 0x30
00007942783d7a34  vmovaps xmm0, [rsp]
00007942783d7a39  vmovaps xmm1, [rsp+0x10]
00007942783d7a3f  vmovaps xmm2, [rsp+0x20]
00007942783d7a45  vmovaps xmm4, [rsp+0x30]
00007942783d7a4b  vmovaps xmm5, [rsp+0x40]
00007942783d7a51  vmovaps xmm6, [rsp+0x50]
00007942783d7a57  vmovaps xmm7, [rsp+0x60]
00007942783d7a5d  vmovaps xmm8, [rsp+0x70]
00007942783d7a63  vmovaps xmm9, [rsp+0x80]
00007942783d7a6c  vmovaps xmm10, [rsp+0x90]
00007942783d7a75  vmovaps xmm11, [rsp+0xA0]
00007942783d7a7e  vmovaps xmm12, [rsp+0xB0]
00007942783d7a87  vmovaps xmm13, [rsp+0xC0]
00007942783d7a90  vmovaps xmm14, [rsp+0xD0]
00007942783d7a99  vmovaps xmm15, [rsp+0xE0]
00007942783d7aa2  add rsp, 0xF0
00007942783d7aa9  pop r11
00007942783d7aab  pop r10
00007942783d7aad  pop r9
00007942783d7aaf  pop r8
00007942783d7ab1  pop rsi
00007942783d7ab2  pop rdi
00007942783d7ab3  pop rdx
00007942783d7ab4  pop rcx
00007942783d7ab5  pop rax
00007942783d7ab6  add rsp, 0x08
00007942783d7aba  jmp 0x00007942783D5D43
00007942783d7abf  sub rsp, 0x08
00007942783d7ac3  push rax
00007942783d7ac4  push rcx
00007942783d7ac5  push rdx
00007942783d7ac6  push rdi
00007942783d7ac7  push rsi
00007942783d7ac8  push r8
00007942783d7aca  push r9
00007942783d7acc  push r10
00007942783d7ace  push r11
00007942783d7ad0  sub rsp, 0xF0
00007942783d7ad7  vmovaps [rsp], xmm0
00007942783d7adc  vmovaps [rsp+0x10], xmm2
00007942783d7ae2  vmovaps [rsp+0x20], xmm3
00007942783d7ae8  vmovaps [rsp+0x30], xmm4
00007942783d7aee  vmovaps [rsp+0x40], xmm5
00007942783d7af4  vmovaps [rsp+0x50], xmm6
00007942783d7afa  vmovaps [rsp+0x60], xmm7
00007942783d7b00  vmovaps [rsp+0x70], xmm8
00007942783d7b06  vmovaps [rsp+0x80], xmm9
00007942783d7b0f  vmovaps [rsp+0x90], xmm10
00007942783d7b18  vmovaps [rsp+0xA0], xmm11
00007942783d7b21  vmovaps [rsp+0xB0], xmm12
00007942783d7b2a  vmovaps [rsp+0xC0], xmm13
00007942783d7b33  vmovaps [rsp+0xD0], xmm14
00007942783d7b3c  vmovaps [rsp+0xE0], xmm15
00007942783d7b45  sub rsp, 0x30
00007942783d7b49  movaps [rsp], xmm1
00007942783d7b4d  movaps [rsp+0x10], xmm15
00007942783d7b53  movaps [rsp+0x20], xmm9
00007942783d7b59  lea rdi, [rsp]
00007942783d7b5d  mov esi, 0x00
00007942783d7b62  mov rax, 0x59DDDCBA3530
00007942783d7b6c  call rax
00007942783d7b6e  movaps xmm1, [rsp]
00007942783d7b72  add rsp, 0x30
00007942783d7b76  vmovaps xmm0, [rsp]
00007942783d7b7b  vmovaps xmm2, [rsp+0x10]
00007942783d7b81  vmovaps xmm3, [rsp+0x20]
00007942783d7b87  vmovaps xmm4, [rsp+0x30]
00007942783d7b8d  vmovaps xmm5, [rsp+0x40]
00007942783d7b93  vmovaps xmm6, [rsp+0x50]
00007942783d7b99  vmovaps xmm7, [rsp+0x60]
00007942783d7b9f  vmovaps xmm8, [rsp+0x70]
00007942783d7ba5  vmovaps xmm9, [rsp+0x80]
00007942783d7bae  vmovaps xmm10, [rsp+0x90]
00007942783d7bb7  vmovaps xmm11, [rsp+0xA0]
00007942783d7bc0  vmovaps xmm12, [rsp+0xB0]
00007942783d7bc9  vmovaps xmm13, [rsp+0xC0]
00007942783d7bd2  vmovaps xmm14, [rsp+0xD0]
00007942783d7bdb  vmovaps xmm15, [rsp+0xE0]
00007942783d7be4  add rsp, 0xF0
00007942783d7beb  pop r11
00007942783d7bed  pop r10
00007942783d7bef  pop r9
00007942783d7bf1  pop r8
00007942783d7bf3  pop rsi
00007942783d7bf4  pop rdi
00007942783d7bf5  pop rdx
00007942783d7bf6  pop rcx
00007942783d7bf7  pop rax
00007942783d7bf8  add rsp, 0x08
00007942783d7bfc  jmp 0x00007942783D5DCB
00007942783d7c01  call 0x00007942782E5820
00007942783d7c06  jmp 0x00007942783D5DD8
00007942783d7c0b  sub rsp, 0x08
00007942783d7c0f  push rax
00007942783d7c10  push rcx
00007942783d7c11  push rdx
00007942783d7c12  push rdi
00007942783d7c13  push rsi
00007942783d7c14  push r8
00007942783d7c16  push r9
00007942783d7c18  push r10
00007942783d7c1a  push r11
00007942783d7c1c  sub rsp, 0xF0
00007942783d7c23  vmovaps [rsp], xmm0
00007942783d7c28  vmovaps [rsp+0x10], xmm2
00007942783d7c2e  vmovaps [rsp+0x20], xmm3
00007942783d7c34  vmovaps [rsp+0x30], xmm4
00007942783d7c3a  vmovaps [rsp+0x40], xmm5
00007942783d7c40  vmovaps [rsp+0x50], xmm6
00007942783d7c46  vmovaps [rsp+0x60], xmm7
00007942783d7c4c  vmovaps [rsp+0x70], xmm8
00007942783d7c52  vmovaps [rsp+0x80], xmm9
00007942783d7c5b  vmovaps [rsp+0x90], xmm10
00007942783d7c64  vmovaps [rsp+0xA0], xmm11
00007942783d7c6d  vmovaps [rsp+0xB0], xmm12
00007942783d7c76  vmovaps [rsp+0xC0], xmm13
00007942783d7c7f  vmovaps [rsp+0xD0], xmm14
00007942783d7c88  vmovaps [rsp+0xE0], xmm15
00007942783d7c91  sub rsp, 0x30
00007942783d7c95  movaps [rsp], xmm1
00007942783d7c99  movaps [rsp+0x10], xmm5
00007942783d7c9e  movaps [rsp+0x20], xmm7
00007942783d7ca3  lea rdi, [rsp]
00007942783d7ca7  mov esi, 0x00
00007942783d7cac  mov rax, 0x59DDDCBA3530
00007942783d7cb6  call rax
00007942783d7cb8  movaps xmm1, [rsp]
00007942783d7cbc  add rsp, 0x30
00007942783d7cc0  vmovaps xmm0, [rsp]
00007942783d7cc5  vmovaps xmm2, [rsp+0x10]
00007942783d7ccb  vmovaps xmm3, [rsp+0x20]
00007942783d7cd1  vmovaps xmm4, [rsp+0x30]
00007942783d7cd7  vmovaps xmm5, [rsp+0x40]
00007942783d7cdd  vmovaps xmm6, [rsp+0x50]
00007942783d7ce3  vmovaps xmm7, [rsp+0x60]
00007942783d7ce9  vmovaps xmm8, [rsp+0x70]
00007942783d7cef  vmovaps xmm9, [rsp+0x80]
00007942783d7cf8  vmovaps xmm10, [rsp+0x90]
00007942783d7d01  vmovaps xmm11, [rsp+0xA0]
00007942783d7d0a  vmovaps xmm12, [rsp+0xB0]
00007942783d7d13  vmovaps xmm13, [rsp+0xC0]
00007942783d7d1c  vmovaps xmm14, [rsp+0xD0]
00007942783d7d25  vmovaps xmm15, [rsp+0xE0]
00007942783d7d2e  add rsp, 0xF0
00007942783d7d35  pop r11
00007942783d7d37  pop r10
00007942783d7d39  pop r9
00007942783d7d3b  pop r8
00007942783d7d3d  pop rsi
00007942783d7d3e  pop rdi
00007942783d7d3f  pop rdx
00007942783d7d40  pop rcx
00007942783d7d41  pop rax
00007942783d7d42  add rsp, 0x08
00007942783d7d46  jmp 0x00007942783D5E7D
00007942783d7d4b  sub rsp, 0x08
00007942783d7d4f  push rax
00007942783d7d50  push rcx
00007942783d7d51  push rdx
00007942783d7d52  push rdi
00007942783d7d53  push rsi
00007942783d7d54  push r8
00007942783d7d56  push r9
00007942783d7d58  push r10
00007942783d7d5a  push r11
00007942783d7d5c  sub rsp, 0xF0
00007942783d7d63  vmovaps [rsp], xmm0
00007942783d7d68  vmovaps [rsp+0x10], xmm1
00007942783d7d6e  vmovaps [rsp+0x20], xmm2
00007942783d7d74  vmovaps [rsp+0x30], xmm3
00007942783d7d7a  vmovaps [rsp+0x40], xmm4
00007942783d7d80  vmovaps [rsp+0x50], xmm5
00007942783d7d86  vmovaps [rsp+0x60], xmm6
00007942783d7d8c  vmovaps [rsp+0x70], xmm8
00007942783d7d92  vmovaps [rsp+0x80], xmm9
00007942783d7d9b  vmovaps [rsp+0x90], xmm10
00007942783d7da4  vmovaps [rsp+0xA0], xmm11
00007942783d7dad  vmovaps [rsp+0xB0], xmm12
00007942783d7db6  vmovaps [rsp+0xC0], xmm13
00007942783d7dbf  vmovaps [rsp+0xD0], xmm14
00007942783d7dc8  vmovaps [rsp+0xE0], xmm15
00007942783d7dd1  sub rsp, 0x30
00007942783d7dd5  movaps [rsp], xmm7
00007942783d7dd9  movaps [rsp+0x10], xmm5
00007942783d7dde  movaps [rsp+0x20], xmm15
00007942783d7de4  lea rdi, [rsp]
00007942783d7de8  mov esi, 0x00
00007942783d7ded  mov rax, 0x59DDDCBA3530
00007942783d7df7  call rax
00007942783d7df9  movaps xmm7, [rsp]
00007942783d7dfd  add rsp, 0x30
00007942783d7e01  vmovaps xmm0, [rsp]
00007942783d7e06  vmovaps xmm1, [rsp+0x10]
00007942783d7e0c  vmovaps xmm2, [rsp+0x20]
00007942783d7e12  vmovaps xmm3, [rsp+0x30]
00007942783d7e18  vmovaps xmm4, [rsp+0x40]
00007942783d7e1e  vmovaps xmm5, [rsp+0x50]
00007942783d7e24  vmovaps xmm6, [rsp+0x60]
00007942783d7e2a  vmovaps xmm8, [rsp+0x70]
00007942783d7e30  vmovaps xmm9, [rsp+0x80]
00007942783d7e39  vmovaps xmm10, [rsp+0x90]
00007942783d7e42  vmovaps xmm11, [rsp+0xA0]
00007942783d7e4b  vmovaps xmm12, [rsp+0xB0]
00007942783d7e54  vmovaps xmm13, [rsp+0xC0]
00007942783d7e5d  vmovaps xmm14, [rsp+0xD0]
00007942783d7e66  vmovaps xmm15, [rsp+0xE0]
00007942783d7e6f  add rsp, 0xF0
00007942783d7e76  pop r11
00007942783d7e78  pop r10
00007942783d7e7a  pop r9
00007942783d7e7c  pop r8
00007942783d7e7e  pop rsi
00007942783d7e7f  pop rdi
00007942783d7e80  pop rdx
00007942783d7e81  pop rcx
00007942783d7e82  pop rax
00007942783d7e83  add rsp, 0x08
00007942783d7e87  jmp 0x00007942783D5EB3
00007942783d7e8c  call 0x00007942782D64F0
00007942783d7e91  jmp 0x00007942783D5EC0
00007942783d7e96  sub rsp, 0x08
00007942783d7e9a  push rax
00007942783d7e9b  push rcx
00007942783d7e9c  push rdx
00007942783d7e9d  push rdi
00007942783d7e9e  push rsi
00007942783d7e9f  push r8
00007942783d7ea1  push r9
00007942783d7ea3  push r10
00007942783d7ea5  push r11
00007942783d7ea7  sub rsp, 0xF0
00007942783d7eae  vmovaps [rsp], xmm0
00007942783d7eb3  vmovaps [rsp+0x10], xmm1
00007942783d7eb9  vmovaps [rsp+0x20], xmm2
00007942783d7ebf  vmovaps [rsp+0x30], xmm3
00007942783d7ec5  vmovaps [rsp+0x40], xmm4
00007942783d7ecb  vmovaps [rsp+0x50], xmm5
00007942783d7ed1  vmovaps [rsp+0x60], xmm6
00007942783d7ed7  vmovaps [rsp+0x70], xmm7
00007942783d7edd  vmovaps [rsp+0x80], xmm8
00007942783d7ee6  vmovaps [rsp+0x90], xmm9
00007942783d7eef  vmovaps [rsp+0xA0], xmm10
00007942783d7ef8  vmovaps [rsp+0xB0], xmm11
00007942783d7f01  vmovaps [rsp+0xC0], xmm12
00007942783d7f0a  vmovaps [rsp+0xD0], xmm13
00007942783d7f13  vmovaps [rsp+0xE0], xmm14
00007942783d7f1c  sub rsp, 0x30
00007942783d7f20  movaps [rsp], xmm15
00007942783d7f25  movaps [rsp+0x10], xmm5
00007942783d7f2a  movaps [rsp+0x20], xmm3
00007942783d7f2f  lea rdi, [rsp]
00007942783d7f33  mov esi, 0x00
00007942783d7f38  mov rax, 0x59DDDCBA3530
00007942783d7f42  call rax
00007942783d7f44  movaps xmm15, [rsp]
00007942783d7f49  add rsp, 0x30
00007942783d7f4d  vmovaps xmm0, [rsp]
00007942783d7f52  vmovaps xmm1, [rsp+0x10]
00007942783d7f58  vmovaps xmm2, [rsp+0x20]
00007942783d7f5e  vmovaps xmm3, [rsp+0x30]
00007942783d7f64  vmovaps xmm4, [rsp+0x40]
00007942783d7f6a  vmovaps xmm5, [rsp+0x50]
00007942783d7f70  vmovaps xmm6, [rsp+0x60]
00007942783d7f76  vmovaps xmm7, [rsp+0x70]
00007942783d7f7c  vmovaps xmm8, [rsp+0x80]
00007942783d7f85  vmovaps xmm9, [rsp+0x90]
00007942783d7f8e  vmovaps xmm10, [rsp+0xA0]
00007942783d7f97  vmovaps xmm11, [rsp+0xB0]
00007942783d7fa0  vmovaps xmm12, [rsp+0xC0]
00007942783d7fa9  vmovaps xmm13, [rsp+0xD0]
00007942783d7fb2  vmovaps xmm14, [rsp+0xE0]
00007942783d7fbb  add rsp, 0xF0
00007942783d7fc2  pop r11
00007942783d7fc4  pop r10
00007942783d7fc6  pop r9
00007942783d7fc8  pop r8
00007942783d7fca  pop rsi
00007942783d7fcb  pop rdi
00007942783d7fcc  pop rdx
00007942783d7fcd  pop rcx
00007942783d7fce  pop rax
00007942783d7fcf  add rsp, 0x08
00007942783d7fd3  jmp 0x00007942783D5EE6
00007942783d7fd8  sub rsp, 0x08
00007942783d7fdc  push rax
00007942783d7fdd  push rcx
00007942783d7fde  push rdx
00007942783d7fdf  push rdi
00007942783d7fe0  push rsi
00007942783d7fe1  push r8
00007942783d7fe3  push r9
00007942783d7fe5  push r10
00007942783d7fe7  push r11
00007942783d7fe9  sub rsp, 0xF0
00007942783d7ff0  vmovaps [rsp], xmm0
00007942783d7ff5  vmovaps [rsp+0x10], xmm2
00007942783d7ffb  vmovaps [rsp+0x20], xmm3
00007942783d8001  vmovaps [rsp+0x30], xmm4
00007942783d8007  vmovaps [rsp+0x40], xmm5
00007942783d800d  vmovaps [rsp+0x50], xmm6
00007942783d8013  vmovaps [rsp+0x60], xmm7
00007942783d8019  vmovaps [rsp+0x70], xmm8
00007942783d801f  vmovaps [rsp+0x80], xmm9
00007942783d8028  vmovaps [rsp+0x90], xmm10
00007942783d8031  vmovaps [rsp+0xA0], xmm11
00007942783d803a  vmovaps [rsp+0xB0], xmm12
00007942783d8043  vmovaps [rsp+0xC0], xmm13
00007942783d804c  vmovaps [rsp+0xD0], xmm14
00007942783d8055  vmovaps [rsp+0xE0], xmm15
00007942783d805e  sub rsp, 0x30
00007942783d8062  movaps [rsp], xmm1
00007942783d8066  movaps [rsp+0x10], xmm5
00007942783d806b  movaps [rsp+0x20], xmm4
00007942783d8070  lea rdi, [rsp]
00007942783d8074  mov esi, 0x00
00007942783d8079  mov rax, 0x59DDDCBA3530
00007942783d8083  call rax
00007942783d8085  movaps xmm1, [rsp]
00007942783d8089  add rsp, 0x30
00007942783d808d  vmovaps xmm0, [rsp]
00007942783d8092  vmovaps xmm2, [rsp+0x10]
00007942783d8098  vmovaps xmm3, [rsp+0x20]
00007942783d809e  vmovaps xmm4, [rsp+0x30]
00007942783d80a4  vmovaps xmm5, [rsp+0x40]
00007942783d80aa  vmovaps xmm6, [rsp+0x50]
00007942783d80b0  vmovaps xmm7, [rsp+0x60]
00007942783d80b6  vmovaps xmm8, [rsp+0x70]
00007942783d80bc  vmovaps xmm9, [rsp+0x80]
00007942783d80c5  vmovaps xmm10, [rsp+0x90]
00007942783d80ce  vmovaps xmm11, [rsp+0xA0]
00007942783d80d7  vmovaps xmm12, [rsp+0xB0]
00007942783d80e0  vmovaps xmm13, [rsp+0xC0]
00007942783d80e9  vmovaps xmm14, [rsp+0xD0]
00007942783d80f2  vmovaps xmm15, [rsp+0xE0]
00007942783d80fb  add rsp, 0xF0
00007942783d8102  pop r11
00007942783d8104  pop r10
00007942783d8106  pop r9
00007942783d8108  pop r8
00007942783d810a  pop rsi
00007942783d810b  pop rdi
00007942783d810c  pop rdx
00007942783d810d  pop rcx
00007942783d810e  pop rax
00007942783d810f  add rsp, 0x08
00007942783d8113  jmp 0x00007942783D5F06
00007942783d8118  sub rsp, 0x08
00007942783d811c  push rax
00007942783d811d  push rcx
00007942783d811e  push rdx
00007942783d811f  push rdi
00007942783d8120  push rsi
00007942783d8121  push r8
00007942783d8123  push r9
00007942783d8125  push r10
00007942783d8127  push r11
00007942783d8129  sub rsp, 0xF0
00007942783d8130  vmovaps [rsp], xmm0
00007942783d8135  vmovaps [rsp+0x10], xmm1
00007942783d813b  vmovaps [rsp+0x20], xmm2
00007942783d8141  vmovaps [rsp+0x30], xmm3
00007942783d8147  vmovaps [rsp+0x40], xmm5
00007942783d814d  vmovaps [rsp+0x50], xmm6
00007942783d8153  vmovaps [rsp+0x60], xmm7
00007942783d8159  vmovaps [rsp+0x70], xmm8
00007942783d815f  vmovaps [rsp+0x80], xmm9
00007942783d8168  vmovaps [rsp+0x90], xmm10
00007942783d8171  vmovaps [rsp+0xA0], xmm11
00007942783d817a  vmovaps [rsp+0xB0], xmm12
00007942783d8183  vmovaps [rsp+0xC0], xmm13
00007942783d818c  vmovaps [rsp+0xD0], xmm14
00007942783d8195  vmovaps [rsp+0xE0], xmm15
00007942783d819e  sub rsp, 0x30
00007942783d81a2  movaps [rsp], xmm4
00007942783d81a6  movaps [rsp+0x10], xmm3
00007942783d81ab  movaps [rsp+0x20], xmm5
00007942783d81b0  lea rdi, [rsp]
00007942783d81b4  mov esi, 0x00
00007942783d81b9  mov rax, 0x59DDDCBA3530
00007942783d81c3  call rax
00007942783d81c5  movaps xmm4, [rsp]
00007942783d81c9  add rsp, 0x30
00007942783d81cd  vmovaps xmm0, [rsp]
00007942783d81d2  vmovaps xmm1, [rsp+0x10]
00007942783d81d8  vmovaps xmm2, [rsp+0x20]
00007942783d81de  vmovaps xmm3, [rsp+0x30]
00007942783d81e4  vmovaps xmm5, [rsp+0x40]
00007942783d81ea  vmovaps xmm6, [rsp+0x50]
00007942783d81f0  vmovaps xmm7, [rsp+0x60]
00007942783d81f6  vmovaps xmm8, [rsp+0x70]
00007942783d81fc  vmovaps xmm9, [rsp+0x80]
00007942783d8205  vmovaps xmm10, [rsp+0x90]
00007942783d820e  vmovaps xmm11, [rsp+0xA0]
00007942783d8217  vmovaps xmm12, [rsp+0xB0]
00007942783d8220  vmovaps xmm13, [rsp+0xC0]
00007942783d8229  vmovaps xmm14, [rsp+0xD0]
00007942783d8232  vmovaps xmm15, [rsp+0xE0]
00007942783d823b  add rsp, 0xF0
00007942783d8242  pop r11
00007942783d8244  pop r10
00007942783d8246  pop r9
00007942783d8248  pop r8
00007942783d824a  pop rsi
00007942783d824b  pop rdi
00007942783d824c  pop rdx
00007942783d824d  pop rcx
00007942783d824e  pop rax
00007942783d824f  add rsp, 0x08
00007942783d8253  jmp 0x00007942783D5F54
00007942783d8258  call 0x00007942782D64F0
00007942783d825d  jmp 0x00007942783D5F61
00007942783d8262  sub rsp, 0x08
00007942783d8266  push rax
00007942783d8267  push rcx
00007942783d8268  push rdx
00007942783d8269  push rdi
00007942783d826a  push rsi
00007942783d826b  push r8
00007942783d826d  push r9
00007942783d826f  push r10
00007942783d8271  push r11
00007942783d8273  sub rsp, 0xF0
00007942783d827a  vmovaps [rsp], xmm0
00007942783d827f  vmovaps [rsp+0x10], xmm1
00007942783d8285  vmovaps [rsp+0x20], xmm2
00007942783d828b  vmovaps [rsp+0x30], xmm3
00007942783d8291  vmovaps [rsp+0x40], xmm4
00007942783d8297  vmovaps [rsp+0x50], xmm6
00007942783d829d  vmovaps [rsp+0x60], xmm7
00007942783d82a3  vmovaps [rsp+0x70], xmm8
00007942783d82a9  vmovaps [rsp+0x80], xmm9
00007942783d82b2  vmovaps [rsp+0x90], xmm10
00007942783d82bb  vmovaps [rsp+0xA0], xmm11
00007942783d82c4  vmovaps [rsp+0xB0], xmm12
00007942783d82cd  vmovaps [rsp+0xC0], xmm13
00007942783d82d6  vmovaps [rsp+0xD0], xmm14
00007942783d82df  vmovaps [rsp+0xE0], xmm15
00007942783d82e8  sub rsp, 0x30
00007942783d82ec  movaps [rsp], xmm5
00007942783d82f0  movaps [rsp+0x10], xmm6
00007942783d82f5  movaps [rsp+0x20], xmm3
00007942783d82fa  lea rdi, [rsp]
00007942783d82fe  mov esi, 0x00
00007942783d8303  mov rax, 0x59DDDCBA3530
00007942783d830d  call rax
00007942783d830f  movaps xmm5, [rsp]
00007942783d8313  add rsp, 0x30
00007942783d8317  vmovaps xmm0, [rsp]
00007942783d831c  vmovaps xmm1, [rsp+0x10]
00007942783d8322  vmovaps xmm2, [rsp+0x20]
00007942783d8328  vmovaps xmm3, [rsp+0x30]
00007942783d832e  vmovaps xmm4, [rsp+0x40]
00007942783d8334  vmovaps xmm6, [rsp+0x50]
00007942783d833a  vmovaps xmm7, [rsp+0x60]
00007942783d8340  vmovaps xmm8, [rsp+0x70]
00007942783d8346  vmovaps xmm9, [rsp+0x80]
00007942783d834f  vmovaps xmm10, [rsp+0x90]
00007942783d8358  vmovaps xmm11, [rsp+0xA0]
00007942783d8361  vmovaps xmm12, [rsp+0xB0]
00007942783d836a  vmovaps xmm13, [rsp+0xC0]
00007942783d8373  vmovaps xmm14, [rsp+0xD0]
00007942783d837c  vmovaps xmm15, [rsp+0xE0]
00007942783d8385  add rsp, 0xF0
00007942783d838c  pop r11
00007942783d838e  pop r10
00007942783d8390  pop r9
00007942783d8392  pop r8
00007942783d8394  pop rsi
00007942783d8395  pop rdi
00007942783d8396  pop rdx
00007942783d8397  pop rcx
00007942783d8398  pop rax
00007942783d8399  add rsp, 0x08
00007942783d839d  jmp 0x00007942783D5F87
00007942783d83a2  sub rsp, 0x08
00007942783d83a6  push rax
00007942783d83a7  push rcx
00007942783d83a8  push rdx
00007942783d83a9  push rdi
00007942783d83aa  push rsi
00007942783d83ab  push r8
00007942783d83ad  push r9
00007942783d83af  push r10
00007942783d83b1  push r11
00007942783d83b3  sub rsp, 0xF0
00007942783d83ba  vmovaps [rsp], xmm0
00007942783d83bf  vmovaps [rsp+0x10], xmm1
00007942783d83c5  vmovaps [rsp+0x20], xmm2
00007942783d83cb  vmovaps [rsp+0x30], xmm3
00007942783d83d1  vmovaps [rsp+0x40], xmm4
00007942783d83d7  vmovaps [rsp+0x50], xmm5
00007942783d83dd  vmovaps [rsp+0x60], xmm7
00007942783d83e3  vmovaps [rsp+0x70], xmm8
00007942783d83e9  vmovaps [rsp+0x80], xmm9
00007942783d83f2  vmovaps [rsp+0x90], xmm10
00007942783d83fb  vmovaps [rsp+0xA0], xmm11
00007942783d8404  vmovaps [rsp+0xB0], xmm12
00007942783d840d  vmovaps [rsp+0xC0], xmm13
00007942783d8416  vmovaps [rsp+0xD0], xmm14
00007942783d841f  vmovaps [rsp+0xE0], xmm15
00007942783d8428  sub rsp, 0x30
00007942783d842c  movaps [rsp], xmm6
00007942783d8430  movaps [rsp+0x10], xmm9
00007942783d8436  movaps [rsp+0x20], xmm1
00007942783d843b  lea rdi, [rsp]
00007942783d843f  mov esi, 0x00
00007942783d8444  mov rax, 0x59DDDCBA3530
00007942783d844e  call rax
00007942783d8450  movaps xmm6, [rsp]
00007942783d8454  add rsp, 0x30
00007942783d8458  vmovaps xmm0, [rsp]
00007942783d845d  vmovaps xmm1, [rsp+0x10]
00007942783d8463  vmovaps xmm2, [rsp+0x20]
00007942783d8469  vmovaps xmm3, [rsp+0x30]
00007942783d846f  vmovaps xmm4, [rsp+0x40]
00007942783d8475  vmovaps xmm5, [rsp+0x50]
00007942783d847b  vmovaps xmm7, [rsp+0x60]
00007942783d8481  vmovaps xmm8, [rsp+0x70]
00007942783d8487  vmovaps xmm9, [rsp+0x80]
00007942783d8490  vmovaps xmm10, [rsp+0x90]
00007942783d8499  vmovaps xmm11, [rsp+0xA0]
00007942783d84a2  vmovaps xmm12, [rsp+0xB0]
00007942783d84ab  vmovaps xmm13, [rsp+0xC0]
00007942783d84b4  vmovaps xmm14, [rsp+0xD0]
00007942783d84bd  vmovaps xmm15, [rsp+0xE0]
00007942783d84c6  add rsp, 0xF0
00007942783d84cd  pop r11
00007942783d84cf  pop r10
00007942783d84d1  pop r9
00007942783d84d3  pop r8
00007942783d84d5  pop rsi
00007942783d84d6  pop rdi
00007942783d84d7  pop rdx
00007942783d84d8  pop rcx
00007942783d84d9  pop rax
00007942783d84da  add rsp, 0x08
00007942783d84de  jmp 0x00007942783D5FAB
00007942783d84e3  sub rsp, 0x08
00007942783d84e7  push rax
00007942783d84e8  push rcx
00007942783d84e9  push rdx
00007942783d84ea  push rdi
00007942783d84eb  push rsi
00007942783d84ec  push r8
00007942783d84ee  push r9
00007942783d84f0  push r10
00007942783d84f2  push r11
00007942783d84f4  sub rsp, 0xF0
00007942783d84fb  vmovaps [rsp], xmm0
00007942783d8500  vmovaps [rsp+0x10], xmm1
00007942783d8506  vmovaps [rsp+0x20], xmm2
00007942783d850c  vmovaps [rsp+0x30], xmm3
00007942783d8512  vmovaps [rsp+0x40], xmm4
00007942783d8518  vmovaps [rsp+0x50], xmm5
00007942783d851e  vmovaps [rsp+0x60], xmm6
00007942783d8524  vmovaps [rsp+0x70], xmm7
00007942783d852a  vmovaps [rsp+0x80], xmm8
00007942783d8533  vmovaps [rsp+0x90], xmm10
00007942783d853c  vmovaps [rsp+0xA0], xmm11
00007942783d8545  vmovaps [rsp+0xB0], xmm12
00007942783d854e  vmovaps [rsp+0xC0], xmm13
00007942783d8557  vmovaps [rsp+0xD0], xmm14
00007942783d8560  vmovaps [rsp+0xE0], xmm15
00007942783d8569  sub rsp, 0x30
00007942783d856d  movaps [rsp], xmm9
00007942783d8572  movaps [rsp+0x10], xmm3
00007942783d8577  movaps [rsp+0x20], xmm1
00007942783d857c  lea rdi, [rsp]
00007942783d8580  mov esi, 0x00
00007942783d8585  mov rax, 0x59DDDCBA3530
00007942783d858f  call rax
00007942783d8591  movaps xmm9, [rsp]
00007942783d8596  add rsp, 0x30
00007942783d859a  vmovaps xmm0, [rsp]
00007942783d859f  vmovaps xmm1, [rsp+0x10]
00007942783d85a5  vmovaps xmm2, [rsp+0x20]
00007942783d85ab  vmovaps xmm3, [rsp+0x30]
00007942783d85b1  vmovaps xmm4, [rsp+0x40]
00007942783d85b7  vmovaps xmm5, [rsp+0x50]
00007942783d85bd  vmovaps xmm6, [rsp+0x60]
00007942783d85c3  vmovaps xmm7, [rsp+0x70]
00007942783d85c9  vmovaps xmm8, [rsp+0x80]
00007942783d85d2  vmovaps xmm10, [rsp+0x90]
00007942783d85db  vmovaps xmm11, [rsp+0xA0]
00007942783d85e4  vmovaps xmm12, [rsp+0xB0]
00007942783d85ed  vmovaps xmm13, [rsp+0xC0]
00007942783d85f6  vmovaps xmm14, [rsp+0xD0]
00007942783d85ff  vmovaps xmm15, [rsp+0xE0]
00007942783d8608  add rsp, 0xF0
00007942783d860f  pop r11
00007942783d8611  pop r10
00007942783d8613  pop r9
00007942783d8615  pop r8
00007942783d8617  pop rsi
00007942783d8618  pop rdi
00007942783d8619  pop rdx
00007942783d861a  pop rcx
00007942783d861b  pop rax
00007942783d861c  add rsp, 0x08
00007942783d8620  jmp 0x00007942783D5FF7
00007942783d8625  call 0x00007942782D64F0
00007942783d862a  jmp 0x00007942783D6004
00007942783d862f  sub rsp, 0x08
00007942783d8633  push rax
00007942783d8634  push rcx
00007942783d8635  push rdx
00007942783d8636  push rdi
00007942783d8637  push rsi
00007942783d8638  push r8
00007942783d863a  push r9
00007942783d863c  push r10
00007942783d863e  push r11
00007942783d8640  sub rsp, 0xF0
00007942783d8647  vmovaps [rsp], xmm0
00007942783d864c  vmovaps [rsp+0x10], xmm1
00007942783d8652  vmovaps [rsp+0x20], xmm2
00007942783d8658  vmovaps [rsp+0x30], xmm3
00007942783d865e  vmovaps [rsp+0x40], xmm4
00007942783d8664  vmovaps [rsp+0x50], xmm5
00007942783d866a  vmovaps [rsp+0x60], xmm6
00007942783d8670  vmovaps [rsp+0x70], xmm7
00007942783d8676  vmovaps [rsp+0x80], xmm8
00007942783d867f  vmovaps [rsp+0x90], xmm9
00007942783d8688  vmovaps [rsp+0xA0], xmm10
00007942783d8691  vmovaps [rsp+0xB0], xmm11
00007942783d869a  vmovaps [rsp+0xC0], xmm12
00007942783d86a3  vmovaps [rsp+0xD0], xmm13
00007942783d86ac  vmovaps [rsp+0xE0], xmm14
00007942783d86b5  sub rsp, 0x30
00007942783d86b9  movaps [rsp], xmm15
00007942783d86be  movaps [rsp+0x10], xmm3
00007942783d86c3  movaps [rsp+0x20], xmm7
00007942783d86c8  lea rdi, [rsp]
00007942783d86cc  mov esi, 0x00
00007942783d86d1  mov rax, 0x59DDDCBA3530
00007942783d86db  call rax
00007942783d86dd  movaps xmm15, [rsp]
00007942783d86e2  add rsp, 0x30
00007942783d86e6  vmovaps xmm0, [rsp]
00007942783d86eb  vmovaps xmm1, [rsp+0x10]
00007942783d86f1  vmovaps xmm2, [rsp+0x20]
00007942783d86f7  vmovaps xmm3, [rsp+0x30]
00007942783d86fd  vmovaps xmm4, [rsp+0x40]
00007942783d8703  vmovaps xmm5, [rsp+0x50]
00007942783d8709  vmovaps xmm6, [rsp+0x60]
00007942783d870f  vmovaps xmm7, [rsp+0x70]
00007942783d8715  vmovaps xmm8, [rsp+0x80]
00007942783d871e  vmovaps xmm9, [rsp+0x90]
00007942783d8727  vmovaps xmm10, [rsp+0xA0]
00007942783d8730  vmovaps xmm11, [rsp+0xB0]
00007942783d8739  vmovaps xmm12, [rsp+0xC0]
00007942783d8742  vmovaps xmm13, [rsp+0xD0]
00007942783d874b  vmovaps xmm14, [rsp+0xE0]
00007942783d8754  add rsp, 0xF0
00007942783d875b  pop r11
00007942783d875d  pop r10
00007942783d875f  pop r9
00007942783d8761  pop r8
00007942783d8763  pop rsi
00007942783d8764  pop rdi
00007942783d8765  pop rdx
00007942783d8766  pop rcx
00007942783d8767  pop rax
00007942783d8768  add rsp, 0x08
00007942783d876c  jmp 0x00007942783D6030
00007942783d8771  sub rsp, 0x08
00007942783d8775  push rax
00007942783d8776  push rcx
00007942783d8777  push rdx
00007942783d8778  push rdi
00007942783d8779  push rsi
00007942783d877a  push r8
00007942783d877c  push r9
00007942783d877e  push r10
00007942783d8780  push r11
00007942783d8782  sub rsp, 0xF0
00007942783d8789  vmovaps [rsp], xmm0
00007942783d878e  vmovaps [rsp+0x10], xmm1
00007942783d8794  vmovaps [rsp+0x20], xmm2
00007942783d879a  vmovaps [rsp+0x30], xmm4
00007942783d87a0  vmovaps [rsp+0x40], xmm5
00007942783d87a6  vmovaps [rsp+0x50], xmm6
00007942783d87ac  vmovaps [rsp+0x60], xmm7
00007942783d87b2  vmovaps [rsp+0x70], xmm8
00007942783d87b8  vmovaps [rsp+0x80], xmm9
00007942783d87c1  vmovaps [rsp+0x90], xmm10
00007942783d87ca  vmovaps [rsp+0xA0], xmm11
00007942783d87d3  vmovaps [rsp+0xB0], xmm12
00007942783d87dc  vmovaps [rsp+0xC0], xmm13
00007942783d87e5  vmovaps [rsp+0xD0], xmm14
00007942783d87ee  vmovaps [rsp+0xE0], xmm15
00007942783d87f7  sub rsp, 0x30
00007942783d87fb  movaps [rsp], xmm3
00007942783d87ff  movaps [rsp+0x10], xmm1
00007942783d8804  movaps [rsp+0x20], xmm15
00007942783d880a  lea rdi, [rsp]
00007942783d880e  mov esi, 0x00
00007942783d8813  mov rax, 0x59DDDCBA3530
00007942783d881d  call rax
00007942783d881f  movaps xmm3, [rsp]
00007942783d8823  add rsp, 0x30
00007942783d8827  vmovaps xmm0, [rsp]
00007942783d882c  vmovaps xmm1, [rsp+0x10]
00007942783d8832  vmovaps xmm2, [rsp+0x20]
00007942783d8838  vmovaps xmm4, [rsp+0x30]
00007942783d883e  vmovaps xmm5, [rsp+0x40]
00007942783d8844  vmovaps xmm6, [rsp+0x50]
00007942783d884a  vmovaps xmm7, [rsp+0x60]
00007942783d8850  vmovaps xmm8, [rsp+0x70]
00007942783d8856  vmovaps xmm9, [rsp+0x80]
00007942783d885f  vmovaps xmm10, [rsp+0x90]
00007942783d8868  vmovaps xmm11, [rsp+0xA0]
00007942783d8871  vmovaps xmm12, [rsp+0xB0]
00007942783d887a  vmovaps xmm13, [rsp+0xC0]
00007942783d8883  vmovaps xmm14, [rsp+0xD0]
00007942783d888c  vmovaps xmm15, [rsp+0xE0]
00007942783d8895  add rsp, 0xF0
00007942783d889c  pop r11
00007942783d889e  pop r10
00007942783d88a0  pop r9
00007942783d88a2  pop r8
00007942783d88a4  pop rsi
00007942783d88a5  pop rdi
00007942783d88a6  pop rdx
00007942783d88a7  pop rcx
00007942783d88a8  pop rax
00007942783d88a9  add rsp, 0x08
00007942783d88ad  jmp 0x00007942783D60BF
00007942783d88b2  call 0x00007942782D64F0
00007942783d88b7  jmp 0x00007942783D60C9
00007942783d88bc  sub rsp, 0x08
00007942783d88c0  push rax
00007942783d88c1  push rcx
00007942783d88c2  push rdx
00007942783d88c3  push rdi
00007942783d88c4  push rsi
00007942783d88c5  push r8
00007942783d88c7  push r9
00007942783d88c9  push r10
00007942783d88cb  push r11
00007942783d88cd  sub rsp, 0xF0
00007942783d88d4  vmovaps [rsp], xmm0
00007942783d88d9  vmovaps [rsp+0x10], xmm1
00007942783d88df  vmovaps [rsp+0x20], xmm2
00007942783d88e5  vmovaps [rsp+0x30], xmm3
00007942783d88eb  vmovaps [rsp+0x40], xmm4
00007942783d88f1  vmovaps [rsp+0x50], xmm5
00007942783d88f7  vmovaps [rsp+0x60], xmm6
00007942783d88fd  vmovaps [rsp+0x70], xmm7
00007942783d8903  vmovaps [rsp+0x80], xmm8
00007942783d890c  vmovaps [rsp+0x90], xmm9
00007942783d8915  vmovaps [rsp+0xA0], xmm10
00007942783d891e  vmovaps [rsp+0xB0], xmm11
00007942783d8927  vmovaps [rsp+0xC0], xmm12
00007942783d8930  vmovaps [rsp+0xD0], xmm13
00007942783d8939  vmovaps [rsp+0xE0], xmm14
00007942783d8942  sub rsp, 0x30
00007942783d8946  movaps [rsp], xmm15
00007942783d894b  movaps [rsp+0x10], xmm14
00007942783d8951  movaps [rsp+0x20], xmm4
00007942783d8956  lea rdi, [rsp]
00007942783d895a  mov esi, 0x00
00007942783d895f  mov rax, 0x59DDDCBA3530
00007942783d8969  call rax
00007942783d896b  movaps xmm15, [rsp]
00007942783d8970  add rsp, 0x30
00007942783d8974  vmovaps xmm0, [rsp]
00007942783d8979  vmovaps xmm1, [rsp+0x10]
00007942783d897f  vmovaps xmm2, [rsp+0x20]
00007942783d8985  vmovaps xmm3, [rsp+0x30]
00007942783d898b  vmovaps xmm4, [rsp+0x40]
00007942783d8991  vmovaps xmm5, [rsp+0x50]
00007942783d8997  vmovaps xmm6, [rsp+0x60]
00007942783d899d  vmovaps xmm7, [rsp+0x70]
00007942783d89a3  vmovaps xmm8, [rsp+0x80]
00007942783d89ac  vmovaps xmm9, [rsp+0x90]
00007942783d89b5  vmovaps xmm10, [rsp+0xA0]
00007942783d89be  vmovaps xmm11, [rsp+0xB0]
00007942783d89c7  vmovaps xmm12, [rsp+0xC0]
00007942783d89d0  vmovaps xmm13, [rsp+0xD0]
00007942783d89d9  vmovaps xmm14, [rsp+0xE0]
00007942783d89e2  add rsp, 0xF0
00007942783d89e9  pop r11
00007942783d89eb  pop r10
00007942783d89ed  pop r9
00007942783d89ef  pop r8
00007942783d89f1  pop rsi
00007942783d89f2  pop rdi
00007942783d89f3  pop rdx
00007942783d89f4  pop rcx
00007942783d89f5  pop rax
00007942783d89f6  add rsp, 0x08
00007942783d89fa  jmp 0x00007942783D60F7
00007942783d89ff  sub rsp, 0x08
00007942783d8a03  push rax
00007942783d8a04  push rcx
00007942783d8a05  push rdx
00007942783d8a06  push rdi
00007942783d8a07  push rsi
00007942783d8a08  push r8
00007942783d8a0a  push r9
00007942783d8a0c  push r10
00007942783d8a0e  push r11
00007942783d8a10  sub rsp, 0xF0
00007942783d8a17  vmovaps [rsp], xmm0
00007942783d8a1c  vmovaps [rsp+0x10], xmm1
00007942783d8a22  vmovaps [rsp+0x20], xmm2
00007942783d8a28  vmovaps [rsp+0x30], xmm3
00007942783d8a2e  vmovaps [rsp+0x40], xmm4
00007942783d8a34  vmovaps [rsp+0x50], xmm5
00007942783d8a3a  vmovaps [rsp+0x60], xmm6
00007942783d8a40  vmovaps [rsp+0x70], xmm7
00007942783d8a46  vmovaps [rsp+0x80], xmm8
00007942783d8a4f  vmovaps [rsp+0x90], xmm9
00007942783d8a58  vmovaps [rsp+0xA0], xmm10
00007942783d8a61  vmovaps [rsp+0xB0], xmm11
00007942783d8a6a  vmovaps [rsp+0xC0], xmm12
00007942783d8a73  vmovaps [rsp+0xD0], xmm13
00007942783d8a7c  vmovaps [rsp+0xE0], xmm15
00007942783d8a85  sub rsp, 0x30
00007942783d8a89  movaps [rsp], xmm14
00007942783d8a8e  movaps [rsp+0x10], xmm2
00007942783d8a93  movaps [rsp+0x20], xmm1
00007942783d8a98  lea rdi, [rsp]
00007942783d8a9c  mov esi, 0x00
00007942783d8aa1  mov rax, 0x59DDDCBA3530
00007942783d8aab  call rax
00007942783d8aad  movaps xmm14, [rsp]
00007942783d8ab2  add rsp, 0x30
00007942783d8ab6  vmovaps xmm0, [rsp]
00007942783d8abb  vmovaps xmm1, [rsp+0x10]
00007942783d8ac1  vmovaps xmm2, [rsp+0x20]
00007942783d8ac7  vmovaps xmm3, [rsp+0x30]
00007942783d8acd  vmovaps xmm4, [rsp+0x40]
00007942783d8ad3  vmovaps xmm5, [rsp+0x50]
00007942783d8ad9  vmovaps xmm6, [rsp+0x60]
00007942783d8adf  vmovaps xmm7, [rsp+0x70]
00007942783d8ae5  vmovaps xmm8, [rsp+0x80]
00007942783d8aee  vmovaps xmm9, [rsp+0x90]
00007942783d8af7  vmovaps xmm10, [rsp+0xA0]
00007942783d8b00  vmovaps xmm11, [rsp+0xB0]
00007942783d8b09  vmovaps xmm12, [rsp+0xC0]
00007942783d8b12  vmovaps xmm13, [rsp+0xD0]
00007942783d8b1b  vmovaps xmm15, [rsp+0xE0]
00007942783d8b24  add rsp, 0xF0
00007942783d8b2b  pop r11
00007942783d8b2d  pop r10
00007942783d8b2f  pop r9
00007942783d8b31  pop r8
00007942783d8b33  pop rsi
00007942783d8b34  pop rdi
00007942783d8b35  pop rdx
00007942783d8b36  pop rcx
00007942783d8b37  pop rax
00007942783d8b38  add rsp, 0x08
00007942783d8b3c  jmp 0x00007942783D611D
00007942783d8b41  sub rsp, 0x08
00007942783d8b45  push rax
00007942783d8b46  push rcx
00007942783d8b47  push rdx
00007942783d8b48  push rdi
00007942783d8b49  push rsi
00007942783d8b4a  push r8
00007942783d8b4c  push r9
00007942783d8b4e  push r10
00007942783d8b50  push r11
00007942783d8b52  sub rsp, 0xF0
00007942783d8b59  vmovaps [rsp], xmm0
00007942783d8b5e  vmovaps [rsp+0x10], xmm2
00007942783d8b64  vmovaps [rsp+0x20], xmm3
00007942783d8b6a  vmovaps [rsp+0x30], xmm4
00007942783d8b70  vmovaps [rsp+0x40], xmm5
00007942783d8b76  vmovaps [rsp+0x50], xmm6
00007942783d8b7c  vmovaps [rsp+0x60], xmm7
00007942783d8b82  vmovaps [rsp+0x70], xmm8
00007942783d8b88  vmovaps [rsp+0x80], xmm9
00007942783d8b91  vmovaps [rsp+0x90], xmm10
00007942783d8b9a  vmovaps [rsp+0xA0], xmm11
00007942783d8ba3  vmovaps [rsp+0xB0], xmm12
00007942783d8bac  vmovaps [rsp+0xC0], xmm13
00007942783d8bb5  vmovaps [rsp+0xD0], xmm14
00007942783d8bbe  vmovaps [rsp+0xE0], xmm15
00007942783d8bc7  sub rsp, 0x30
00007942783d8bcb  movaps [rsp], xmm1
00007942783d8bcf  movaps [rsp+0x10], xmm4
00007942783d8bd4  movaps [rsp+0x20], xmm9
00007942783d8bda  lea rdi, [rsp]
00007942783d8bde  mov esi, 0x00
00007942783d8be3  mov rax, 0x59DDDCBA3530
00007942783d8bed  call rax
00007942783d8bef  movaps xmm1, [rsp]
00007942783d8bf3  add rsp, 0x30
00007942783d8bf7  vmovaps xmm0, [rsp]
00007942783d8bfc  vmovaps xmm2, [rsp+0x10]
00007942783d8c02  vmovaps xmm3, [rsp+0x20]
00007942783d8c08  vmovaps xmm4, [rsp+0x30]
00007942783d8c0e  vmovaps xmm5, [rsp+0x40]
00007942783d8c14  vmovaps xmm6, [rsp+0x50]
00007942783d8c1a  vmovaps xmm7, [rsp+0x60]
00007942783d8c20  vmovaps xmm8, [rsp+0x70]
00007942783d8c26  vmovaps xmm9, [rsp+0x80]
00007942783d8c2f  vmovaps xmm10, [rsp+0x90]
00007942783d8c38  vmovaps xmm11, [rsp+0xA0]
00007942783d8c41  vmovaps xmm12, [rsp+0xB0]
00007942783d8c4a  vmovaps xmm13, [rsp+0xC0]
00007942783d8c53  vmovaps xmm14, [rsp+0xD0]
00007942783d8c5c  vmovaps xmm15, [rsp+0xE0]
00007942783d8c65  add rsp, 0xF0
00007942783d8c6c  pop r11
00007942783d8c6e  pop r10
00007942783d8c70  pop r9
00007942783d8c72  pop r8
00007942783d8c74  pop rsi
00007942783d8c75  pop rdi
00007942783d8c76  pop rdx
00007942783d8c77  pop rcx
00007942783d8c78  pop rax
00007942783d8c79  add rsp, 0x08
00007942783d8c7d  jmp 0x00007942783D613B
00007942783d8c82  sub rsp, 0x08
00007942783d8c86  push rax
00007942783d8c87  push rcx
00007942783d8c88  push rdx
00007942783d8c89  push rdi
00007942783d8c8a  push rsi
00007942783d8c8b  push r8
00007942783d8c8d  push r9
00007942783d8c8f  push r10
00007942783d8c91  push r11
00007942783d8c93  sub rsp, 0xF0
00007942783d8c9a  vmovaps [rsp], xmm0
00007942783d8c9f  vmovaps [rsp+0x10], xmm1
00007942783d8ca5  vmovaps [rsp+0x20], xmm2
00007942783d8cab  vmovaps [rsp+0x30], xmm3
00007942783d8cb1  vmovaps [rsp+0x40], xmm5
00007942783d8cb7  vmovaps [rsp+0x50], xmm6
00007942783d8cbd  vmovaps [rsp+0x60], xmm7
00007942783d8cc3  vmovaps [rsp+0x70], xmm8
00007942783d8cc9  vmovaps [rsp+0x80], xmm9
00007942783d8cd2  vmovaps [rsp+0x90], xmm10
00007942783d8cdb  vmovaps [rsp+0xA0], xmm11
00007942783d8ce4  vmovaps [rsp+0xB0], xmm12
00007942783d8ced  vmovaps [rsp+0xC0], xmm13
00007942783d8cf6  vmovaps [rsp+0xD0], xmm14
00007942783d8cff  vmovaps [rsp+0xE0], xmm15
00007942783d8d08  sub rsp, 0x30
00007942783d8d0c  movaps [rsp], xmm4
00007942783d8d10  movaps [rsp+0x10], xmm2
00007942783d8d15  movaps [rsp+0x20], xmm9
00007942783d8d1b  lea rdi, [rsp]
00007942783d8d1f  mov esi, 0x00
00007942783d8d24  mov rax, 0x59DDDCBA3530
00007942783d8d2e  call rax
00007942783d8d30  movaps xmm4, [rsp]
00007942783d8d34  add rsp, 0x30
00007942783d8d38  vmovaps xmm0, [rsp]
00007942783d8d3d  vmovaps xmm1, [rsp+0x10]
00007942783d8d43  vmovaps xmm2, [rsp+0x20]
00007942783d8d49  vmovaps xmm3, [rsp+0x30]
00007942783d8d4f  vmovaps xmm5, [rsp+0x40]
00007942783d8d55  vmovaps xmm6, [rsp+0x50]
00007942783d8d5b  vmovaps xmm7, [rsp+0x60]
00007942783d8d61  vmovaps xmm8, [rsp+0x70]
00007942783d8d67  vmovaps xmm9, [rsp+0x80]
00007942783d8d70  vmovaps xmm10, [rsp+0x90]
00007942783d8d79  vmovaps xmm11, [rsp+0xA0]
00007942783d8d82  vmovaps xmm12, [rsp+0xB0]
00007942783d8d8b  vmovaps xmm13, [rsp+0xC0]
00007942783d8d94  vmovaps xmm14, [rsp+0xD0]
00007942783d8d9d  vmovaps xmm15, [rsp+0xE0]
00007942783d8da6  add rsp, 0xF0
00007942783d8dad  pop r11
00007942783d8daf  pop r10
00007942783d8db1  pop r9
00007942783d8db3  pop r8
00007942783d8db5  pop rsi
00007942783d8db6  pop rdi
00007942783d8db7  pop rdx
00007942783d8db8  pop rcx
00007942783d8db9  pop rax
00007942783d8dba  add rsp, 0x08
00007942783d8dbe  jmp 0x00007942783D616B
00007942783d8dc3  sub rsp, 0x08
00007942783d8dc7  push rax
00007942783d8dc8  push rcx
00007942783d8dc9  push rdx
00007942783d8dca  push rdi
00007942783d8dcb  push rsi
00007942783d8dcc  push r8
00007942783d8dce  push r9
00007942783d8dd0  push r10
00007942783d8dd2  push r11
00007942783d8dd4  sub rsp, 0xF0
00007942783d8ddb  vmovaps [rsp], xmm0
00007942783d8de0  vmovaps [rsp+0x10], xmm1
00007942783d8de6  vmovaps [rsp+0x20], xmm2
00007942783d8dec  vmovaps [rsp+0x30], xmm3
00007942783d8df2  vmovaps [rsp+0x40], xmm4
00007942783d8df8  vmovaps [rsp+0x50], xmm5
00007942783d8dfe  vmovaps [rsp+0x60], xmm6
00007942783d8e04  vmovaps [rsp+0x70], xmm7
00007942783d8e0a  vmovaps [rsp+0x80], xmm8
00007942783d8e13  vmovaps [rsp+0x90], xmm10
00007942783d8e1c  vmovaps [rsp+0xA0], xmm11
00007942783d8e25  vmovaps [rsp+0xB0], xmm12
00007942783d8e2e  vmovaps [rsp+0xC0], xmm13
00007942783d8e37  vmovaps [rsp+0xD0], xmm14
00007942783d8e40  vmovaps [rsp+0xE0], xmm15
00007942783d8e49  sub rsp, 0x30
00007942783d8e4d  movaps [rsp], xmm9
00007942783d8e52  movaps [rsp+0x10], xmm2
00007942783d8e57  movaps [rsp+0x20], xmm1
00007942783d8e5c  lea rdi, [rsp]
00007942783d8e60  mov esi, 0x00
00007942783d8e65  mov rax, 0x59DDDCBA3530
00007942783d8e6f  call rax
00007942783d8e71  movaps xmm9, [rsp]
00007942783d8e76  add rsp, 0x30
00007942783d8e7a  vmovaps xmm0, [rsp]
00007942783d8e7f  vmovaps xmm1, [rsp+0x10]
00007942783d8e85  vmovaps xmm2, [rsp+0x20]
00007942783d8e8b  vmovaps xmm3, [rsp+0x30]
00007942783d8e91  vmovaps xmm4, [rsp+0x40]
00007942783d8e97  vmovaps xmm5, [rsp+0x50]
00007942783d8e9d  vmovaps xmm6, [rsp+0x60]
00007942783d8ea3  vmovaps xmm7, [rsp+0x70]
00007942783d8ea9  vmovaps xmm8, [rsp+0x80]
00007942783d8eb2  vmovaps xmm10, [rsp+0x90]
00007942783d8ebb  vmovaps xmm11, [rsp+0xA0]
00007942783d8ec4  vmovaps xmm12, [rsp+0xB0]
00007942783d8ecd  vmovaps xmm13, [rsp+0xC0]
00007942783d8ed6  vmovaps xmm14, [rsp+0xD0]
00007942783d8edf  vmovaps xmm15, [rsp+0xE0]
00007942783d8ee8  add rsp, 0xF0
00007942783d8eef  pop r11
00007942783d8ef1  pop r10
00007942783d8ef3  pop r9
00007942783d8ef5  pop r8
00007942783d8ef7  pop rsi
00007942783d8ef8  pop rdi
00007942783d8ef9  pop rdx
00007942783d8efa  pop rcx
00007942783d8efb  pop rax
00007942783d8efc  add rsp, 0x08
00007942783d8f00  jmp 0x00007942783D61A1
00007942783d8f05  sub rsp, 0x08
00007942783d8f09  push rax
00007942783d8f0a  push rcx
00007942783d8f0b  push rdx
00007942783d8f0c  push rdi
00007942783d8f0d  push rsi
00007942783d8f0e  push r8
00007942783d8f10  push r9
00007942783d8f12  push r10
00007942783d8f14  push r11
00007942783d8f16  sub rsp, 0xF0
00007942783d8f1d  vmovaps [rsp], xmm0
00007942783d8f22  vmovaps [rsp+0x10], xmm2
00007942783d8f28  vmovaps [rsp+0x20], xmm3
00007942783d8f2e  vmovaps [rsp+0x30], xmm4
00007942783d8f34  vmovaps [rsp+0x40], xmm5
00007942783d8f3a  vmovaps [rsp+0x50], xmm6
00007942783d8f40  vmovaps [rsp+0x60], xmm7
00007942783d8f46  vmovaps [rsp+0x70], xmm8
00007942783d8f4c  vmovaps [rsp+0x80], xmm9
00007942783d8f55  vmovaps [rsp+0x90], xmm10
00007942783d8f5e  vmovaps [rsp+0xA0], xmm11
00007942783d8f67  vmovaps [rsp+0xB0], xmm12
00007942783d8f70  vmovaps [rsp+0xC0], xmm13
00007942783d8f79  vmovaps [rsp+0xD0], xmm14
00007942783d8f82  vmovaps [rsp+0xE0], xmm15
00007942783d8f8b  sub rsp, 0x30
00007942783d8f8f  movaps [rsp], xmm1
00007942783d8f93  movaps [rsp+0x10], xmm15
00007942783d8f99  movaps [rsp+0x20], xmm6
00007942783d8f9e  lea rdi, [rsp]
00007942783d8fa2  mov esi, 0x00
00007942783d8fa7  mov rax, 0x59DDDCBA3530
00007942783d8fb1  call rax
00007942783d8fb3  movaps xmm1, [rsp]
00007942783d8fb7  add rsp, 0x30
00007942783d8fbb  vmovaps xmm0, [rsp]
00007942783d8fc0  vmovaps xmm2, [rsp+0x10]
00007942783d8fc6  vmovaps xmm3, [rsp+0x20]
00007942783d8fcc  vmovaps xmm4, [rsp+0x30]
00007942783d8fd2  vmovaps xmm5, [rsp+0x40]
00007942783d8fd8  vmovaps xmm6, [rsp+0x50]
00007942783d8fde  vmovaps xmm7, [rsp+0x60]
00007942783d8fe4  vmovaps xmm8, [rsp+0x70]
00007942783d8fea  vmovaps xmm9, [rsp+0x80]
00007942783d8ff3  vmovaps xmm10, [rsp+0x90]
00007942783d8ffc  vmovaps xmm11, [rsp+0xA0]
00007942783d9005  vmovaps xmm12, [rsp+0xB0]
00007942783d900e  vmovaps xmm13, [rsp+0xC0]
00007942783d9017  vmovaps xmm14, [rsp+0xD0]
00007942783d9020  vmovaps xmm15, [rsp+0xE0]
00007942783d9029  add rsp, 0xF0
00007942783d9030  pop r11
00007942783d9032  pop r10
00007942783d9034  pop r9
00007942783d9036  pop r8
00007942783d9038  pop rsi
00007942783d9039  pop rdi
00007942783d903a  pop rdx
00007942783d903b  pop rcx
00007942783d903c  pop rax
00007942783d903d  add rsp, 0x08
00007942783d9041  jmp 0x00007942783D61C2
00007942783d9046  sub rsp, 0x08
00007942783d904a  push rax
00007942783d904b  push rcx
00007942783d904c  push rdx
00007942783d904d  push rdi
00007942783d904e  push rsi
00007942783d904f  push r8
00007942783d9051  push r9
00007942783d9053  push r10
00007942783d9055  push r11
00007942783d9057  sub rsp, 0xF0
00007942783d905e  vmovaps [rsp], xmm0
00007942783d9063  vmovaps [rsp+0x10], xmm1
00007942783d9069  vmovaps [rsp+0x20], xmm2
00007942783d906f  vmovaps [rsp+0x30], xmm3
00007942783d9075  vmovaps [rsp+0x40], xmm4
00007942783d907b  vmovaps [rsp+0x50], xmm5
00007942783d9081  vmovaps [rsp+0x60], xmm6
00007942783d9087  vmovaps [rsp+0x70], xmm7
00007942783d908d  vmovaps [rsp+0x80], xmm8
00007942783d9096  vmovaps [rsp+0x90], xmm9
00007942783d909f  vmovaps [rsp+0xA0], xmm10
00007942783d90a8  vmovaps [rsp+0xB0], xmm11
00007942783d90b1  vmovaps [rsp+0xC0], xmm12
00007942783d90ba  vmovaps [rsp+0xD0], xmm13
00007942783d90c3  vmovaps [rsp+0xE0], xmm14
00007942783d90cc  sub rsp, 0x30
00007942783d90d0  movaps [rsp], xmm15
00007942783d90d5  movaps [rsp+0x10], xmm5
00007942783d90da  movaps [rsp+0x20], xmm3
00007942783d90df  lea rdi, [rsp]
00007942783d90e3  mov esi, 0x00
00007942783d90e8  mov rax, 0x59DDDCBA3530
00007942783d90f2  call rax
00007942783d90f4  movaps xmm15, [rsp]
00007942783d90f9  add rsp, 0x30
00007942783d90fd  vmovaps xmm0, [rsp]
00007942783d9102  vmovaps xmm1, [rsp+0x10]
00007942783d9108  vmovaps xmm2, [rsp+0x20]
00007942783d910e  vmovaps xmm3, [rsp+0x30]
00007942783d9114  vmovaps xmm4, [rsp+0x40]
00007942783d911a  vmovaps xmm5, [rsp+0x50]
00007942783d9120  vmovaps xmm6, [rsp+0x60]
00007942783d9126  vmovaps xmm7, [rsp+0x70]
00007942783d912c  vmovaps xmm8, [rsp+0x80]
00007942783d9135  vmovaps xmm9, [rsp+0x90]
00007942783d913e  vmovaps xmm10, [rsp+0xA0]
00007942783d9147  vmovaps xmm11, [rsp+0xB0]
00007942783d9150  vmovaps xmm12, [rsp+0xC0]
00007942783d9159  vmovaps xmm13, [rsp+0xD0]
00007942783d9162  vmovaps xmm14, [rsp+0xE0]
00007942783d916b  add rsp, 0xF0
00007942783d9172  pop r11
00007942783d9174  pop r10
00007942783d9176  pop r9
00007942783d9178  pop r8
00007942783d917a  pop rsi
00007942783d917b  pop rdi
00007942783d917c  pop rdx
00007942783d917d  pop rcx
00007942783d917e  pop rax
00007942783d917f  add rsp, 0x08
00007942783d9183  jmp 0x00007942783D61DC
00007942783d9188  sub rsp, 0x08
00007942783d918c  push rax
00007942783d918d  push rcx
00007942783d918e  push rdx
00007942783d918f  push rdi
00007942783d9190  push rsi
00007942783d9191  push r8
00007942783d9193  push r9
00007942783d9195  push r10
00007942783d9197  push r11
00007942783d9199  sub rsp, 0xF0
00007942783d91a0  vmovaps [rsp], xmm0
00007942783d91a5  vmovaps [rsp+0x10], xmm1
00007942783d91ab  vmovaps [rsp+0x20], xmm2
00007942783d91b1  vmovaps [rsp+0x30], xmm3
00007942783d91b7  vmovaps [rsp+0x40], xmm4
00007942783d91bd  vmovaps [rsp+0x50], xmm6
00007942783d91c3  vmovaps [rsp+0x60], xmm7
00007942783d91c9  vmovaps [rsp+0x70], xmm8
00007942783d91cf  vmovaps [rsp+0x80], xmm9
00007942783d91d8  vmovaps [rsp+0x90], xmm10
00007942783d91e1  vmovaps [rsp+0xA0], xmm11
00007942783d91ea  vmovaps [rsp+0xB0], xmm12
00007942783d91f3  vmovaps [rsp+0xC0], xmm13
00007942783d91fc  vmovaps [rsp+0xD0], xmm14
00007942783d9205  vmovaps [rsp+0xE0], xmm15
00007942783d920e  sub rsp, 0x30
00007942783d9212  movaps [rsp], xmm5
00007942783d9216  movaps [rsp+0x10], xmm8
00007942783d921c  movaps [rsp+0x20], xmm6
00007942783d9221  lea rdi, [rsp]
00007942783d9225  mov esi, 0x00
00007942783d922a  mov rax, 0x59DDDCBA3530
00007942783d9234  call rax
00007942783d9236  movaps xmm5, [rsp]
00007942783d923a  add rsp, 0x30
00007942783d923e  vmovaps xmm0, [rsp]
00007942783d9243  vmovaps xmm1, [rsp+0x10]
00007942783d9249  vmovaps xmm2, [rsp+0x20]
00007942783d924f  vmovaps xmm3, [rsp+0x30]
00007942783d9255  vmovaps xmm4, [rsp+0x40]
00007942783d925b  vmovaps xmm6, [rsp+0x50]
00007942783d9261  vmovaps xmm7, [rsp+0x60]
00007942783d9267  vmovaps xmm8, [rsp+0x70]
00007942783d926d  vmovaps xmm9, [rsp+0x80]
00007942783d9276  vmovaps xmm10, [rsp+0x90]
00007942783d927f  vmovaps xmm11, [rsp+0xA0]
00007942783d9288  vmovaps xmm12, [rsp+0xB0]
00007942783d9291  vmovaps xmm13, [rsp+0xC0]
00007942783d929a  vmovaps xmm14, [rsp+0xD0]
00007942783d92a3  vmovaps xmm15, [rsp+0xE0]
00007942783d92ac  add rsp, 0xF0
00007942783d92b3  pop r11
00007942783d92b5  pop r10
00007942783d92b7  pop r9
00007942783d92b9  pop r8
00007942783d92bb  pop rsi
00007942783d92bc  pop rdi
00007942783d92bd  pop rdx
00007942783d92be  pop rcx
00007942783d92bf  pop rax
00007942783d92c0  add rsp, 0x08
00007942783d92c4  jmp 0x00007942783D6200
00007942783d92c9  sub rsp, 0x08
00007942783d92cd  push rax
00007942783d92ce  push rcx
00007942783d92cf  push rdx
00007942783d92d0  push rdi
00007942783d92d1  push rsi
00007942783d92d2  push r8
00007942783d92d4  push r9
00007942783d92d6  push r10
00007942783d92d8  push r11
00007942783d92da  sub rsp, 0xF0
00007942783d92e1  vmovaps [rsp], xmm0
00007942783d92e6  vmovaps [rsp+0x10], xmm1
00007942783d92ec  vmovaps [rsp+0x20], xmm2
00007942783d92f2  vmovaps [rsp+0x30], xmm3
00007942783d92f8  vmovaps [rsp+0x40], xmm4
00007942783d92fe  vmovaps [rsp+0x50], xmm5
00007942783d9304  vmovaps [rsp+0x60], xmm7
00007942783d930a  vmovaps [rsp+0x70], xmm8
00007942783d9310  vmovaps [rsp+0x80], xmm9
00007942783d9319  vmovaps [rsp+0x90], xmm10
00007942783d9322  vmovaps [rsp+0xA0], xmm11
00007942783d932b  vmovaps [rsp+0xB0], xmm12
00007942783d9334  vmovaps [rsp+0xC0], xmm13
00007942783d933d  vmovaps [rsp+0xD0], xmm14
00007942783d9346  vmovaps [rsp+0xE0], xmm15
00007942783d934f  sub rsp, 0x30
00007942783d9353  movaps [rsp], xmm6
00007942783d9357  movaps [rsp+0x10], xmm10
00007942783d935d  movaps [rsp+0x20], xmm8
00007942783d9363  lea rdi, [rsp]
00007942783d9367  mov esi, 0x00
00007942783d936c  mov rax, 0x59DDDCBA3530
00007942783d9376  call rax
00007942783d9378  movaps xmm6, [rsp]
00007942783d937c  add rsp, 0x30
00007942783d9380  vmovaps xmm0, [rsp]
00007942783d9385  vmovaps xmm1, [rsp+0x10]
00007942783d938b  vmovaps xmm2, [rsp+0x20]
00007942783d9391  vmovaps xmm3, [rsp+0x30]
00007942783d9397  vmovaps xmm4, [rsp+0x40]
00007942783d939d  vmovaps xmm5, [rsp+0x50]
00007942783d93a3  vmovaps xmm7, [rsp+0x60]
00007942783d93a9  vmovaps xmm8, [rsp+0x70]
00007942783d93af  vmovaps xmm9, [rsp+0x80]
00007942783d93b8  vmovaps xmm10, [rsp+0x90]
00007942783d93c1  vmovaps xmm11, [rsp+0xA0]
00007942783d93ca  vmovaps xmm12, [rsp+0xB0]
00007942783d93d3  vmovaps xmm13, [rsp+0xC0]
00007942783d93dc  vmovaps xmm14, [rsp+0xD0]
00007942783d93e5  vmovaps xmm15, [rsp+0xE0]
00007942783d93ee  add rsp, 0xF0
00007942783d93f5  pop r11
00007942783d93f7  pop r10
00007942783d93f9  pop r9
00007942783d93fb  pop r8
00007942783d93fd  pop rsi
00007942783d93fe  pop rdi
00007942783d93ff  pop rdx
00007942783d9400  pop rcx
00007942783d9401  pop rax
00007942783d9402  add rsp, 0x08
00007942783d9406  jmp 0x00007942783D6225
00007942783d940b  sub rsp, 0x08
00007942783d940f  push rax
00007942783d9410  push rcx
00007942783d9411  push rdx
00007942783d9412  push rdi
00007942783d9413  push rsi
00007942783d9414  push r8
00007942783d9416  push r9
00007942783d9418  push r10
00007942783d941a  push r11
00007942783d941c  sub rsp, 0xF0
00007942783d9423  vmovaps [rsp], xmm0
00007942783d9428  vmovaps [rsp+0x10], xmm1
00007942783d942e  vmovaps [rsp+0x20], xmm2
00007942783d9434  vmovaps [rsp+0x30], xmm3
00007942783d943a  vmovaps [rsp+0x40], xmm4
00007942783d9440  vmovaps [rsp+0x50], xmm5
00007942783d9446  vmovaps [rsp+0x60], xmm6
00007942783d944c  vmovaps [rsp+0x70], xmm7
00007942783d9452  vmovaps [rsp+0x80], xmm8
00007942783d945b  vmovaps [rsp+0x90], xmm9
00007942783d9464  vmovaps [rsp+0xA0], xmm11
00007942783d946d  vmovaps [rsp+0xB0], xmm12
00007942783d9476  vmovaps [rsp+0xC0], xmm13
00007942783d947f  vmovaps [rsp+0xD0], xmm14
00007942783d9488  vmovaps [rsp+0xE0], xmm15
00007942783d9491  sub rsp, 0x30
00007942783d9495  movaps [rsp], xmm10
00007942783d949a  movaps [rsp+0x10], xmm8
00007942783d94a0  movaps [rsp+0x20], xmm14
00007942783d94a6  lea rdi, [rsp]
00007942783d94aa  mov esi, 0x00
00007942783d94af  mov rax, 0x59DDDCBA3530
00007942783d94b9  call rax
00007942783d94bb  movaps xmm10, [rsp]
00007942783d94c0  add rsp, 0x30
00007942783d94c4  vmovaps xmm0, [rsp]
00007942783d94c9  vmovaps xmm1, [rsp+0x10]
00007942783d94cf  vmovaps xmm2, [rsp+0x20]
00007942783d94d5  vmovaps xmm3, [rsp+0x30]
00007942783d94db  vmovaps xmm4, [rsp+0x40]
00007942783d94e1  vmovaps xmm5, [rsp+0x50]
00007942783d94e7  vmovaps xmm6, [rsp+0x60]
00007942783d94ed  vmovaps xmm7, [rsp+0x70]
00007942783d94f3  vmovaps xmm8, [rsp+0x80]
00007942783d94fc  vmovaps xmm9, [rsp+0x90]
00007942783d9505  vmovaps xmm11, [rsp+0xA0]
00007942783d950e  vmovaps xmm12, [rsp+0xB0]
00007942783d9517  vmovaps xmm13, [rsp+0xC0]
00007942783d9520  vmovaps xmm14, [rsp+0xD0]
00007942783d9529  vmovaps xmm15, [rsp+0xE0]
00007942783d9532  add rsp, 0xF0
00007942783d9539  pop r11
00007942783d953b  pop r10
00007942783d953d  pop r9
00007942783d953f  pop r8
00007942783d9541  pop rsi
00007942783d9542  pop rdi
00007942783d9543  pop rdx
00007942783d9544  pop rcx
00007942783d9545  pop rax
00007942783d9546  add rsp, 0x08
00007942783d954a  jmp 0x00007942783D6245
00007942783d954f  sub rsp, 0x08
00007942783d9553  push rax
00007942783d9554  push rcx
00007942783d9555  push rdx
00007942783d9556  push rdi
00007942783d9557  push rsi
00007942783d9558  push r8
00007942783d955a  push r9
00007942783d955c  push r10
00007942783d955e  push r11
00007942783d9560  sub rsp, 0xF0
00007942783d9567  vmovaps [rsp], xmm0
00007942783d956c  vmovaps [rsp+0x10], xmm1
00007942783d9572  vmovaps [rsp+0x20], xmm2
00007942783d9578  vmovaps [rsp+0x30], xmm3
00007942783d957e  vmovaps [rsp+0x40], xmm4
00007942783d9584  vmovaps [rsp+0x50], xmm5
00007942783d958a  vmovaps [rsp+0x60], xmm6
00007942783d9590  vmovaps [rsp+0x70], xmm7
00007942783d9596  vmovaps [rsp+0x80], xmm8
00007942783d959f  vmovaps [rsp+0x90], xmm9
00007942783d95a8  vmovaps [rsp+0xA0], xmm10
00007942783d95b1  vmovaps [rsp+0xB0], xmm11
00007942783d95ba  vmovaps [rsp+0xC0], xmm12
00007942783d95c3  vmovaps [rsp+0xD0], xmm13
00007942783d95cc  vmovaps [rsp+0xE0], xmm15
00007942783d95d5  sub rsp, 0x30
00007942783d95d9  movaps [rsp], xmm14
00007942783d95de  movaps [rsp+0x10], xmm8
00007942783d95e4  movaps [rsp+0x20], xmm4
00007942783d95e9  lea rdi, [rsp]
00007942783d95ed  mov esi, 0x00
00007942783d95f2  mov rax, 0x59DDDCBA3530
00007942783d95fc  call rax
00007942783d95fe  movaps xmm14, [rsp]
00007942783d9603  add rsp, 0x30
00007942783d9607  vmovaps xmm0, [rsp]
00007942783d960c  vmovaps xmm1, [rsp+0x10]
00007942783d9612  vmovaps xmm2, [rsp+0x20]
00007942783d9618  vmovaps xmm3, [rsp+0x30]
00007942783d961e  vmovaps xmm4, [rsp+0x40]
00007942783d9624  vmovaps xmm5, [rsp+0x50]
00007942783d962a  vmovaps xmm6, [rsp+0x60]
00007942783d9630  vmovaps xmm7, [rsp+0x70]
00007942783d9636  vmovaps xmm8, [rsp+0x80]
00007942783d963f  vmovaps xmm9, [rsp+0x90]
00007942783d9648  vmovaps xmm10, [rsp+0xA0]
00007942783d9651  vmovaps xmm11, [rsp+0xB0]
00007942783d965a  vmovaps xmm12, [rsp+0xC0]
00007942783d9663  vmovaps xmm13, [rsp+0xD0]
00007942783d966c  vmovaps xmm15, [rsp+0xE0]
00007942783d9675  add rsp, 0xF0
00007942783d967c  pop r11
00007942783d967e  pop r10
00007942783d9680  pop r9
00007942783d9682  pop r8
00007942783d9684  pop rsi
00007942783d9685  pop rdi
00007942783d9686  pop rdx
00007942783d9687  pop rcx
00007942783d9688  pop rax
00007942783d9689  add rsp, 0x08
00007942783d968d  jmp 0x00007942783D6265
00007942783d9692  sub rsp, 0x08
00007942783d9696  push rax
00007942783d9697  push rcx
00007942783d9698  push rdx
00007942783d9699  push rdi
00007942783d969a  push rsi
00007942783d969b  push r8
00007942783d969d  push r9
00007942783d969f  push r10
00007942783d96a1  push r11
00007942783d96a3  sub rsp, 0xF0
00007942783d96aa  vmovaps [rsp], xmm0
00007942783d96af  vmovaps [rsp+0x10], xmm1
00007942783d96b5  vmovaps [rsp+0x20], xmm2
00007942783d96bb  vmovaps [rsp+0x30], xmm3
00007942783d96c1  vmovaps [rsp+0x40], xmm5
00007942783d96c7  vmovaps [rsp+0x50], xmm6
00007942783d96cd  vmovaps [rsp+0x60], xmm7
00007942783d96d3  vmovaps [rsp+0x70], xmm8
00007942783d96d9  vmovaps [rsp+0x80], xmm9
00007942783d96e2  vmovaps [rsp+0x90], xmm10
00007942783d96eb  vmovaps [rsp+0xA0], xmm11
00007942783d96f4  vmovaps [rsp+0xB0], xmm12
00007942783d96fd  vmovaps [rsp+0xC0], xmm13
00007942783d9706  vmovaps [rsp+0xD0], xmm14
00007942783d970f  vmovaps [rsp+0xE0], xmm15
00007942783d9718  sub rsp, 0x30
00007942783d971c  movaps [rsp], xmm4
00007942783d9720  movaps [rsp+0x10], xmm13
00007942783d9726  movaps [rsp+0x20], xmm8
00007942783d972c  lea rdi, [rsp]
00007942783d9730  mov esi, 0x00
00007942783d9735  mov rax, 0x59DDDCBA3530
00007942783d973f  call rax
00007942783d9741  movaps xmm4, [rsp]
00007942783d9745  add rsp, 0x30
00007942783d9749  vmovaps xmm0, [rsp]
00007942783d974e  vmovaps xmm1, [rsp+0x10]
00007942783d9754  vmovaps xmm2, [rsp+0x20]
00007942783d975a  vmovaps xmm3, [rsp+0x30]
00007942783d9760  vmovaps xmm5, [rsp+0x40]
00007942783d9766  vmovaps xmm6, [rsp+0x50]
00007942783d976c  vmovaps xmm7, [rsp+0x60]
00007942783d9772  vmovaps xmm8, [rsp+0x70]
00007942783d9778  vmovaps xmm9, [rsp+0x80]
00007942783d9781  vmovaps xmm10, [rsp+0x90]
00007942783d978a  vmovaps xmm11, [rsp+0xA0]
00007942783d9793  vmovaps xmm12, [rsp+0xB0]
00007942783d979c  vmovaps xmm13, [rsp+0xC0]
00007942783d97a5  vmovaps xmm14, [rsp+0xD0]
00007942783d97ae  vmovaps xmm15, [rsp+0xE0]
00007942783d97b7  add rsp, 0xF0
00007942783d97be  pop r11
00007942783d97c0  pop r10
00007942783d97c2  pop r9
00007942783d97c4  pop r8
00007942783d97c6  pop rsi
00007942783d97c7  pop rdi
00007942783d97c8  pop rdx
00007942783d97c9  pop rcx
00007942783d97ca  pop rax
00007942783d97cb  add rsp, 0x08
00007942783d97cf  jmp 0x00007942783D628A
00007942783d97d4  sub rsp, 0x08
00007942783d97d8  push rax
00007942783d97d9  push rcx
00007942783d97da  push rdx
00007942783d97db  push rdi
00007942783d97dc  push rsi
00007942783d97dd  push r8
00007942783d97df  push r9
00007942783d97e1  push r10
00007942783d97e3  push r11
00007942783d97e5  sub rsp, 0xF0
00007942783d97ec  vmovaps [rsp], xmm0
00007942783d97f1  vmovaps [rsp+0x10], xmm1
00007942783d97f7  vmovaps [rsp+0x20], xmm2
00007942783d97fd  vmovaps [rsp+0x30], xmm3
00007942783d9803  vmovaps [rsp+0x40], xmm4
00007942783d9809  vmovaps [rsp+0x50], xmm5
00007942783d980f  vmovaps [rsp+0x60], xmm6
00007942783d9815  vmovaps [rsp+0x70], xmm7
00007942783d981b  vmovaps [rsp+0x80], xmm8
00007942783d9824  vmovaps [rsp+0x90], xmm9
00007942783d982d  vmovaps [rsp+0xA0], xmm10
00007942783d9836  vmovaps [rsp+0xB0], xmm11
00007942783d983f  vmovaps [rsp+0xC0], xmm12
00007942783d9848  vmovaps [rsp+0xD0], xmm14
00007942783d9851  vmovaps [rsp+0xE0], xmm15
00007942783d985a  sub rsp, 0x30
00007942783d985e  movaps [rsp], xmm13
00007942783d9863  movaps [rsp+0x10], xmm15
00007942783d9869  movaps [rsp+0x20], xmm9
00007942783d986f  lea rdi, [rsp]
00007942783d9873  mov esi, 0x00
00007942783d9878  mov rax, 0x59DDDCBA3530
00007942783d9882  call rax
00007942783d9884  movaps xmm13, [rsp]
00007942783d9889  add rsp, 0x30
00007942783d988d  vmovaps xmm0, [rsp]
00007942783d9892  vmovaps xmm1, [rsp+0x10]
00007942783d9898  vmovaps xmm2, [rsp+0x20]
00007942783d989e  vmovaps xmm3, [rsp+0x30]
00007942783d98a4  vmovaps xmm4, [rsp+0x40]
00007942783d98aa  vmovaps xmm5, [rsp+0x50]
00007942783d98b0  vmovaps xmm6, [rsp+0x60]
00007942783d98b6  vmovaps xmm7, [rsp+0x70]
00007942783d98bc  vmovaps xmm8, [rsp+0x80]
00007942783d98c5  vmovaps xmm9, [rsp+0x90]
00007942783d98ce  vmovaps xmm10, [rsp+0xA0]
00007942783d98d7  vmovaps xmm11, [rsp+0xB0]
00007942783d98e0  vmovaps xmm12, [rsp+0xC0]
00007942783d98e9  vmovaps xmm14, [rsp+0xD0]
00007942783d98f2  vmovaps xmm15, [rsp+0xE0]
00007942783d98fb  add rsp, 0xF0
00007942783d9902  pop r11
00007942783d9904  pop r10
00007942783d9906  pop r9
00007942783d9908  pop r8
00007942783d990a  pop rsi
00007942783d990b  pop rdi
00007942783d990c  pop rdx
00007942783d990d  pop rcx
00007942783d990e  pop rax
00007942783d990f  add rsp, 0x08
00007942783d9913  jmp 0x00007942783D62A5
00007942783d9918  sub rsp, 0x08
00007942783d991c  push rax
00007942783d991d  push rcx
00007942783d991e  push rdx
00007942783d991f  push rdi
00007942783d9920  push rsi
00007942783d9921  push r8
00007942783d9923  push r9
00007942783d9925  push r10
00007942783d9927  push r11
00007942783d9929  sub rsp, 0xF0
00007942783d9930  vmovaps [rsp], xmm0
00007942783d9935  vmovaps [rsp+0x10], xmm1
00007942783d993b  vmovaps [rsp+0x20], xmm2
00007942783d9941  vmovaps [rsp+0x30], xmm3
00007942783d9947  vmovaps [rsp+0x40], xmm4
00007942783d994d  vmovaps [rsp+0x50], xmm5
00007942783d9953  vmovaps [rsp+0x60], xmm6
00007942783d9959  vmovaps [rsp+0x70], xmm7
00007942783d995f  vmovaps [rsp+0x80], xmm8
00007942783d9968  vmovaps [rsp+0x90], xmm9
00007942783d9971  vmovaps [rsp+0xA0], xmm10
00007942783d997a  vmovaps [rsp+0xB0], xmm11
00007942783d9983  vmovaps [rsp+0xC0], xmm12
00007942783d998c  vmovaps [rsp+0xD0], xmm13
00007942783d9995  vmovaps [rsp+0xE0], xmm14
00007942783d999e  sub rsp, 0x30
00007942783d99a2  movaps [rsp], xmm15
00007942783d99a7  movaps [rsp+0x10], xmm1
00007942783d99ac  movaps [rsp+0x20], xmm5
00007942783d99b1  lea rdi, [rsp]
00007942783d99b5  mov esi, 0x00
00007942783d99ba  mov rax, 0x59DDDCBA3530
00007942783d99c4  call rax
00007942783d99c6  movaps xmm15, [rsp]
00007942783d99cb  add rsp, 0x30
00007942783d99cf  vmovaps xmm0, [rsp]
00007942783d99d4  vmovaps xmm1, [rsp+0x10]
00007942783d99da  vmovaps xmm2, [rsp+0x20]
00007942783d99e0  vmovaps xmm3, [rsp+0x30]
00007942783d99e6  vmovaps xmm4, [rsp+0x40]
00007942783d99ec  vmovaps xmm5, [rsp+0x50]
00007942783d99f2  vmovaps xmm6, [rsp+0x60]
00007942783d99f8  vmovaps xmm7, [rsp+0x70]
00007942783d99fe  vmovaps xmm8, [rsp+0x80]
00007942783d9a07  vmovaps xmm9, [rsp+0x90]
00007942783d9a10  vmovaps xmm10, [rsp+0xA0]
00007942783d9a19  vmovaps xmm11, [rsp+0xB0]
00007942783d9a22  vmovaps xmm12, [rsp+0xC0]
00007942783d9a2b  vmovaps xmm13, [rsp+0xD0]
00007942783d9a34  vmovaps xmm14, [rsp+0xE0]
00007942783d9a3d  add rsp, 0xF0
00007942783d9a44  pop r11
00007942783d9a46  pop r10
00007942783d9a48  pop r9
00007942783d9a4a  pop r8
00007942783d9a4c  pop rsi
00007942783d9a4d  pop rdi
00007942783d9a4e  pop rdx
00007942783d9a4f  pop rcx
00007942783d9a50  pop rax
00007942783d9a51  add rsp, 0x08
00007942783d9a55  jmp 0x00007942783D62C0
00007942783d9a5a  call 0x00007942782D64F0
00007942783d9a5f  jmp 0x00007942783D631B
00007942783d9a64  sub rsp, 0x08
00007942783d9a68  push rax
00007942783d9a69  push rcx
00007942783d9a6a  push rdx
00007942783d9a6b  push rdi
00007942783d9a6c  push rsi
00007942783d9a6d  push r8
00007942783d9a6f  push r9
00007942783d9a71  push r10
00007942783d9a73  push r11
00007942783d9a75  sub rsp, 0xF0
00007942783d9a7c  vmovaps [rsp], xmm0
00007942783d9a81  vmovaps [rsp+0x10], xmm1
00007942783d9a87  vmovaps [rsp+0x20], xmm2
00007942783d9a8d  vmovaps [rsp+0x30], xmm3
00007942783d9a93  vmovaps [rsp+0x40], xmm4
00007942783d9a99  vmovaps [rsp+0x50], xmm5
00007942783d9a9f  vmovaps [rsp+0x60], xmm6
00007942783d9aa5  vmovaps [rsp+0x70], xmm7
00007942783d9aab  vmovaps [rsp+0x80], xmm8
00007942783d9ab4  vmovaps [rsp+0x90], xmm10
00007942783d9abd  vmovaps [rsp+0xA0], xmm11
00007942783d9ac6  vmovaps [rsp+0xB0], xmm12
00007942783d9acf  vmovaps [rsp+0xC0], xmm13
00007942783d9ad8  vmovaps [rsp+0xD0], xmm14
00007942783d9ae1  vmovaps [rsp+0xE0], xmm15
00007942783d9aea  sub rsp, 0x30
00007942783d9aee  movaps [rsp], xmm9
00007942783d9af3  movaps [rsp+0x10], xmm8
00007942783d9af9  movaps [rsp+0x20], xmm11
00007942783d9aff  lea rdi, [rsp]
00007942783d9b03  mov esi, 0x00
00007942783d9b08  mov rax, 0x59DDDCBA3530
00007942783d9b12  call rax
00007942783d9b14  movaps xmm9, [rsp]
00007942783d9b19  add rsp, 0x30
00007942783d9b1d  vmovaps xmm0, [rsp]
00007942783d9b22  vmovaps xmm1, [rsp+0x10]
00007942783d9b28  vmovaps xmm2, [rsp+0x20]
00007942783d9b2e  vmovaps xmm3, [rsp+0x30]
00007942783d9b34  vmovaps xmm4, [rsp+0x40]
00007942783d9b3a  vmovaps xmm5, [rsp+0x50]
00007942783d9b40  vmovaps xmm6, [rsp+0x60]
00007942783d9b46  vmovaps xmm7, [rsp+0x70]
00007942783d9b4c  vmovaps xmm8, [rsp+0x80]
00007942783d9b55  vmovaps xmm10, [rsp+0x90]
00007942783d9b5e  vmovaps xmm11, [rsp+0xA0]
00007942783d9b67  vmovaps xmm12, [rsp+0xB0]
00007942783d9b70  vmovaps xmm13, [rsp+0xC0]
00007942783d9b79  vmovaps xmm14, [rsp+0xD0]
00007942783d9b82  vmovaps xmm15, [rsp+0xE0]
00007942783d9b8b  add rsp, 0xF0
00007942783d9b92  pop r11
00007942783d9b94  pop r10
00007942783d9b96  pop r9
00007942783d9b98  pop r8
00007942783d9b9a  pop rsi
00007942783d9b9b  pop rdi
00007942783d9b9c  pop rdx
00007942783d9b9d  pop rcx
00007942783d9b9e  pop rax
00007942783d9b9f  add rsp, 0x08
00007942783d9ba3  jmp 0x00007942783D6352
00007942783d9ba8  sub rsp, 0x08
00007942783d9bac  push rax
00007942783d9bad  push rcx
00007942783d9bae  push rdx
00007942783d9baf  push rdi
00007942783d9bb0  push rsi
00007942783d9bb1  push r8
00007942783d9bb3  push r9
00007942783d9bb5  push r10
00007942783d9bb7  push r11
00007942783d9bb9  sub rsp, 0xF0
00007942783d9bc0  vmovaps [rsp], xmm0
00007942783d9bc5  vmovaps [rsp+0x10], xmm1
00007942783d9bcb  vmovaps [rsp+0x20], xmm2
00007942783d9bd1  vmovaps [rsp+0x30], xmm3
00007942783d9bd7  vmovaps [rsp+0x40], xmm4
00007942783d9bdd  vmovaps [rsp+0x50], xmm5
00007942783d9be3  vmovaps [rsp+0x60], xmm6
00007942783d9be9  vmovaps [rsp+0x70], xmm7
00007942783d9bef  vmovaps [rsp+0x80], xmm8
00007942783d9bf8  vmovaps [rsp+0x90], xmm9
00007942783d9c01  vmovaps [rsp+0xA0], xmm10
00007942783d9c0a  vmovaps [rsp+0xB0], xmm12
00007942783d9c13  vmovaps [rsp+0xC0], xmm13
00007942783d9c1c  vmovaps [rsp+0xD0], xmm14
00007942783d9c25  vmovaps [rsp+0xE0], xmm15
00007942783d9c2e  sub rsp, 0x30
00007942783d9c32  movaps [rsp], xmm11
00007942783d9c37  movaps [rsp+0x10], xmm10
00007942783d9c3d  movaps [rsp+0x20], xmm6
00007942783d9c42  lea rdi, [rsp]
00007942783d9c46  mov esi, 0x00
00007942783d9c4b  mov rax, 0x59DDDCBA3530
00007942783d9c55  call rax
00007942783d9c57  movaps xmm11, [rsp]
00007942783d9c5c  add rsp, 0x30
00007942783d9c60  vmovaps xmm0, [rsp]
00007942783d9c65  vmovaps xmm1, [rsp+0x10]
00007942783d9c6b  vmovaps xmm2, [rsp+0x20]
00007942783d9c71  vmovaps xmm3, [rsp+0x30]
00007942783d9c77  vmovaps xmm4, [rsp+0x40]
00007942783d9c7d  vmovaps xmm5, [rsp+0x50]
00007942783d9c83  vmovaps xmm6, [rsp+0x60]
00007942783d9c89  vmovaps xmm7, [rsp+0x70]
00007942783d9c8f  vmovaps xmm8, [rsp+0x80]
00007942783d9c98  vmovaps xmm9, [rsp+0x90]
00007942783d9ca1  vmovaps xmm10, [rsp+0xA0]
00007942783d9caa  vmovaps xmm12, [rsp+0xB0]
00007942783d9cb3  vmovaps xmm13, [rsp+0xC0]
00007942783d9cbc  vmovaps xmm14, [rsp+0xD0]
00007942783d9cc5  vmovaps xmm15, [rsp+0xE0]
00007942783d9cce  add rsp, 0xF0
00007942783d9cd5  pop r11
00007942783d9cd7  pop r10
00007942783d9cd9  pop r9
00007942783d9cdb  pop r8
00007942783d9cdd  pop rsi
00007942783d9cde  pop rdi
00007942783d9cdf  pop rdx
00007942783d9ce0  pop rcx
00007942783d9ce1  pop rax
00007942783d9ce2  add rsp, 0x08
00007942783d9ce6  jmp 0x00007942783D636D
00007942783d9ceb  sub rsp, 0x08
00007942783d9cef  push rax
00007942783d9cf0  push rcx
00007942783d9cf1  push rdx
00007942783d9cf2  push rdi
00007942783d9cf3  push rsi
00007942783d9cf4  push r8
00007942783d9cf6  push r9
00007942783d9cf8  push r10
00007942783d9cfa  push r11
00007942783d9cfc  sub rsp, 0xF0
00007942783d9d03  vmovaps [rsp], xmm0
00007942783d9d08  vmovaps [rsp+0x10], xmm1
00007942783d9d0e  vmovaps [rsp+0x20], xmm2
00007942783d9d14  vmovaps [rsp+0x30], xmm3
00007942783d9d1a  vmovaps [rsp+0x40], xmm4
00007942783d9d20  vmovaps [rsp+0x50], xmm5
00007942783d9d26  vmovaps [rsp+0x60], xmm6
00007942783d9d2c  vmovaps [rsp+0x70], xmm7
00007942783d9d32  vmovaps [rsp+0x80], xmm8
00007942783d9d3b  vmovaps [rsp+0x90], xmm9
00007942783d9d44  vmovaps [rsp+0xA0], xmm11
00007942783d9d4d  vmovaps [rsp+0xB0], xmm12
00007942783d9d56  vmovaps [rsp+0xC0], xmm13
00007942783d9d5f  vmovaps [rsp+0xD0], xmm14
00007942783d9d68  vmovaps [rsp+0xE0], xmm15
00007942783d9d71  sub rsp, 0x30
00007942783d9d75  movaps [rsp], xmm10
00007942783d9d7a  movaps [rsp+0x10], xmm14
00007942783d9d80  movaps [rsp+0x20], xmm4
00007942783d9d85  lea rdi, [rsp]
00007942783d9d89  mov esi, 0x00
00007942783d9d8e  mov rax, 0x59DDDCBA3530
00007942783d9d98  call rax
00007942783d9d9a  movaps xmm10, [rsp]
00007942783d9d9f  add rsp, 0x30
00007942783d9da3  vmovaps xmm0, [rsp]
00007942783d9da8  vmovaps xmm1, [rsp+0x10]
00007942783d9dae  vmovaps xmm2, [rsp+0x20]
00007942783d9db4  vmovaps xmm3, [rsp+0x30]
00007942783d9dba  vmovaps xmm4, [rsp+0x40]
00007942783d9dc0  vmovaps xmm5, [rsp+0x50]
00007942783d9dc6  vmovaps xmm6, [rsp+0x60]
00007942783d9dcc  vmovaps xmm7, [rsp+0x70]
00007942783d9dd2  vmovaps xmm8, [rsp+0x80]
00007942783d9ddb  vmovaps xmm9, [rsp+0x90]
00007942783d9de4  vmovaps xmm11, [rsp+0xA0]
00007942783d9ded  vmovaps xmm12, [rsp+0xB0]
00007942783d9df6  vmovaps xmm13, [rsp+0xC0]
00007942783d9dff  vmovaps xmm14, [rsp+0xD0]
00007942783d9e08  vmovaps xmm15, [rsp+0xE0]
00007942783d9e11  add rsp, 0xF0
00007942783d9e18  pop r11
00007942783d9e1a  pop r10
00007942783d9e1c  pop r9
00007942783d9e1e  pop r8
00007942783d9e20  pop rsi
00007942783d9e21  pop rdi
00007942783d9e22  pop rdx
00007942783d9e23  pop rcx
00007942783d9e24  pop rax
00007942783d9e25  add rsp, 0x08
00007942783d9e29  jmp 0x00007942783D6388
00007942783d9e2e  sub rsp, 0x08
00007942783d9e32  push rax
00007942783d9e33  push rcx
00007942783d9e34  push rdx
00007942783d9e35  push rdi
00007942783d9e36  push rsi
00007942783d9e37  push r8
00007942783d9e39  push r9
00007942783d9e3b  push r10
00007942783d9e3d  push r11
00007942783d9e3f  sub rsp, 0xF0
00007942783d9e46  vmovaps [rsp], xmm0
00007942783d9e4b  vmovaps [rsp+0x10], xmm1
00007942783d9e51  vmovaps [rsp+0x20], xmm2
00007942783d9e57  vmovaps [rsp+0x30], xmm3
00007942783d9e5d  vmovaps [rsp+0x40], xmm4
00007942783d9e63  vmovaps [rsp+0x50], xmm5
00007942783d9e69  vmovaps [rsp+0x60], xmm6
00007942783d9e6f  vmovaps [rsp+0x70], xmm7
00007942783d9e75  vmovaps [rsp+0x80], xmm9
00007942783d9e7e  vmovaps [rsp+0x90], xmm10
00007942783d9e87  vmovaps [rsp+0xA0], xmm11
00007942783d9e90  vmovaps [rsp+0xB0], xmm12
00007942783d9e99  vmovaps [rsp+0xC0], xmm13
00007942783d9ea2  vmovaps [rsp+0xD0], xmm14
00007942783d9eab  vmovaps [rsp+0xE0], xmm15
00007942783d9eb4  sub rsp, 0x30
00007942783d9eb8  movaps [rsp], xmm8
00007942783d9ebd  movaps [rsp+0x10], xmm1
00007942783d9ec2  movaps [rsp+0x20], xmm14
00007942783d9ec8  lea rdi, [rsp]
00007942783d9ecc  mov esi, 0x00
00007942783d9ed1  mov rax, 0x59DDDCBA3530
00007942783d9edb  call rax
00007942783d9edd  movaps xmm8, [rsp]
00007942783d9ee2  add rsp, 0x30
00007942783d9ee6  vmovaps xmm0, [rsp]
00007942783d9eeb  vmovaps xmm1, [rsp+0x10]
00007942783d9ef1  vmovaps xmm2, [rsp+0x20]
00007942783d9ef7  vmovaps xmm3, [rsp+0x30]
00007942783d9efd  vmovaps xmm4, [rsp+0x40]
00007942783d9f03  vmovaps xmm5, [rsp+0x50]
00007942783d9f09  vmovaps xmm6, [rsp+0x60]
00007942783d9f0f  vmovaps xmm7, [rsp+0x70]
00007942783d9f15  vmovaps xmm9, [rsp+0x80]
00007942783d9f1e  vmovaps xmm10, [rsp+0x90]
00007942783d9f27  vmovaps xmm11, [rsp+0xA0]
00007942783d9f30  vmovaps xmm12, [rsp+0xB0]
00007942783d9f39  vmovaps xmm13, [rsp+0xC0]
00007942783d9f42  vmovaps xmm14, [rsp+0xD0]
00007942783d9f4b  vmovaps xmm15, [rsp+0xE0]
00007942783d9f54  add rsp, 0xF0
00007942783d9f5b  pop r11
00007942783d9f5d  pop r10
00007942783d9f5f  pop r9
00007942783d9f61  pop r8
00007942783d9f63  pop rsi
00007942783d9f64  pop rdi
00007942783d9f65  pop rdx
00007942783d9f66  pop rcx
00007942783d9f67  pop rax
00007942783d9f68  add rsp, 0x08
00007942783d9f6c  jmp 0x00007942783D63AE
00007942783d9f71  sub rsp, 0x08
00007942783d9f75  push rax
00007942783d9f76  push rcx
00007942783d9f77  push rdx
00007942783d9f78  push rdi
00007942783d9f79  push rsi
00007942783d9f7a  push r8
00007942783d9f7c  push r9
00007942783d9f7e  push r10
00007942783d9f80  push r11
00007942783d9f82  sub rsp, 0xF0
00007942783d9f89  vmovaps [rsp], xmm0
00007942783d9f8e  vmovaps [rsp+0x10], xmm1
00007942783d9f94  vmovaps [rsp+0x20], xmm2
00007942783d9f9a  vmovaps [rsp+0x30], xmm3
00007942783d9fa0  vmovaps [rsp+0x40], xmm4
00007942783d9fa6  vmovaps [rsp+0x50], xmm5
00007942783d9fac  vmovaps [rsp+0x60], xmm7
00007942783d9fb2  vmovaps [rsp+0x70], xmm8
00007942783d9fb8  vmovaps [rsp+0x80], xmm9
00007942783d9fc1  vmovaps [rsp+0x90], xmm10
00007942783d9fca  vmovaps [rsp+0xA0], xmm11
00007942783d9fd3  vmovaps [rsp+0xB0], xmm12
00007942783d9fdc  vmovaps [rsp+0xC0], xmm13
00007942783d9fe5  vmovaps [rsp+0xD0], xmm14
00007942783d9fee  vmovaps [rsp+0xE0], xmm15
00007942783d9ff7  sub rsp, 0x30
00007942783d9ffb  movaps [rsp], xmm6
00007942783d9fff  movaps [rsp+0x10], xmm1
00007942783da004  movaps [rsp+0x20], xmm14
00007942783da00a  lea rdi, [rsp]
00007942783da00e  mov esi, 0x00
00007942783da013  mov rax, 0x59DDDCBA3530
00007942783da01d  call rax
00007942783da01f  movaps xmm6, [rsp]
00007942783da023  add rsp, 0x30
00007942783da027  vmovaps xmm0, [rsp]
00007942783da02c  vmovaps xmm1, [rsp+0x10]
00007942783da032  vmovaps xmm2, [rsp+0x20]
00007942783da038  vmovaps xmm3, [rsp+0x30]
00007942783da03e  vmovaps xmm4, [rsp+0x40]
00007942783da044  vmovaps xmm5, [rsp+0x50]
00007942783da04a  vmovaps xmm7, [rsp+0x60]
00007942783da050  vmovaps xmm8, [rsp+0x70]
00007942783da056  vmovaps xmm9, [rsp+0x80]
00007942783da05f  vmovaps xmm10, [rsp+0x90]
00007942783da068  vmovaps xmm11, [rsp+0xA0]
00007942783da071  vmovaps xmm12, [rsp+0xB0]
00007942783da07a  vmovaps xmm13, [rsp+0xC0]
00007942783da083  vmovaps xmm14, [rsp+0xD0]
00007942783da08c  vmovaps xmm15, [rsp+0xE0]
00007942783da095  add rsp, 0xF0
00007942783da09c  pop r11
00007942783da09e  pop r10
00007942783da0a0  pop r9
00007942783da0a2  pop r8
00007942783da0a4  pop rsi
00007942783da0a5  pop rdi
00007942783da0a6  pop rdx
00007942783da0a7  pop rcx
00007942783da0a8  pop rax
00007942783da0a9  add rsp, 0x08
00007942783da0ad  jmp 0x00007942783D63DA
00007942783da0b2  sub rsp, 0x08
00007942783da0b6  push rax
00007942783da0b7  push rcx
00007942783da0b8  push rdx
00007942783da0b9  push rdi
00007942783da0ba  push rsi
00007942783da0bb  push r8
00007942783da0bd  push r9
00007942783da0bf  push r10
00007942783da0c1  push r11
00007942783da0c3  sub rsp, 0xF0
00007942783da0ca  vmovaps [rsp], xmm0
00007942783da0cf  vmovaps [rsp+0x10], xmm1
00007942783da0d5  vmovaps [rsp+0x20], xmm2
00007942783da0db  vmovaps [rsp+0x30], xmm3
00007942783da0e1  vmovaps [rsp+0x40], xmm4
00007942783da0e7  vmovaps [rsp+0x50], xmm5
00007942783da0ed  vmovaps [rsp+0x60], xmm6
00007942783da0f3  vmovaps [rsp+0x70], xmm7
00007942783da0f9  vmovaps [rsp+0x80], xmm8
00007942783da102  vmovaps [rsp+0x90], xmm9
00007942783da10b  vmovaps [rsp+0xA0], xmm10
00007942783da114  vmovaps [rsp+0xB0], xmm11
00007942783da11d  vmovaps [rsp+0xC0], xmm12
00007942783da126  vmovaps [rsp+0xD0], xmm13
00007942783da12f  vmovaps [rsp+0xE0], xmm15
00007942783da138  sub rsp, 0x30
00007942783da13c  movaps [rsp], xmm14
00007942783da141  movaps [rsp+0x10], xmm12
00007942783da147  movaps [rsp+0x20], xmm1
00007942783da14c  lea rdi, [rsp]
00007942783da150  mov esi, 0x00
00007942783da155  mov rax, 0x59DDDCBA3530
00007942783da15f  call rax
00007942783da161  movaps xmm14, [rsp]
00007942783da166  add rsp, 0x30
00007942783da16a  vmovaps xmm0, [rsp]
00007942783da16f  vmovaps xmm1, [rsp+0x10]
00007942783da175  vmovaps xmm2, [rsp+0x20]
00007942783da17b  vmovaps xmm3, [rsp+0x30]
00007942783da181  vmovaps xmm4, [rsp+0x40]
00007942783da187  vmovaps xmm5, [rsp+0x50]
00007942783da18d  vmovaps xmm6, [rsp+0x60]
00007942783da193  vmovaps xmm7, [rsp+0x70]
00007942783da199  vmovaps xmm8, [rsp+0x80]
00007942783da1a2  vmovaps xmm9, [rsp+0x90]
00007942783da1ab  vmovaps xmm10, [rsp+0xA0]
00007942783da1b4  vmovaps xmm11, [rsp+0xB0]
00007942783da1bd  vmovaps xmm12, [rsp+0xC0]
00007942783da1c6  vmovaps xmm13, [rsp+0xD0]
00007942783da1cf  vmovaps xmm15, [rsp+0xE0]
00007942783da1d8  add rsp, 0xF0
00007942783da1df  pop r11
00007942783da1e1  pop r10
00007942783da1e3  pop r9
00007942783da1e5  pop r8
00007942783da1e7  pop rsi
00007942783da1e8  pop rdi
00007942783da1e9  pop rdx
00007942783da1ea  pop rcx
00007942783da1eb  pop rax
00007942783da1ec  add rsp, 0x08
00007942783da1f0  jmp 0x00007942783D6400
00007942783da1f5  sub rsp, 0x08
00007942783da1f9  push rax
00007942783da1fa  push rcx
00007942783da1fb  push rdx
00007942783da1fc  push rdi
00007942783da1fd  push rsi
00007942783da1fe  push r8
00007942783da200  push r9
00007942783da202  push r10
00007942783da204  push r11
00007942783da206  sub rsp, 0xF0
00007942783da20d  vmovaps [rsp], xmm0
00007942783da212  vmovaps [rsp+0x10], xmm2
00007942783da218  vmovaps [rsp+0x20], xmm3
00007942783da21e  vmovaps [rsp+0x30], xmm4
00007942783da224  vmovaps [rsp+0x40], xmm5
00007942783da22a  vmovaps [rsp+0x50], xmm6
00007942783da230  vmovaps [rsp+0x60], xmm7
00007942783da236  vmovaps [rsp+0x70], xmm8
00007942783da23c  vmovaps [rsp+0x80], xmm9
00007942783da245  vmovaps [rsp+0x90], xmm10
00007942783da24e  vmovaps [rsp+0xA0], xmm11
00007942783da257  vmovaps [rsp+0xB0], xmm12
00007942783da260  vmovaps [rsp+0xC0], xmm13
00007942783da269  vmovaps [rsp+0xD0], xmm14
00007942783da272  vmovaps [rsp+0xE0], xmm15
00007942783da27b  sub rsp, 0x30
00007942783da27f  movaps [rsp], xmm1
00007942783da283  movaps [rsp+0x10], xmm13
00007942783da289  movaps [rsp+0x20], xmm9
00007942783da28f  lea rdi, [rsp]
00007942783da293  mov esi, 0x00
00007942783da298  mov rax, 0x59DDDCBA3530
00007942783da2a2  call rax
00007942783da2a4  movaps xmm1, [rsp]
00007942783da2a8  add rsp, 0x30
00007942783da2ac  vmovaps xmm0, [rsp]
00007942783da2b1  vmovaps xmm2, [rsp+0x10]
00007942783da2b7  vmovaps xmm3, [rsp+0x20]
00007942783da2bd  vmovaps xmm4, [rsp+0x30]
00007942783da2c3  vmovaps xmm5, [rsp+0x40]
00007942783da2c9  vmovaps xmm6, [rsp+0x50]
00007942783da2cf  vmovaps xmm7, [rsp+0x60]
00007942783da2d5  vmovaps xmm8, [rsp+0x70]
00007942783da2db  vmovaps xmm9, [rsp+0x80]
00007942783da2e4  vmovaps xmm10, [rsp+0x90]
00007942783da2ed  vmovaps xmm11, [rsp+0xA0]
00007942783da2f6  vmovaps xmm12, [rsp+0xB0]
00007942783da2ff  vmovaps xmm13, [rsp+0xC0]
00007942783da308  vmovaps xmm14, [rsp+0xD0]
00007942783da311  vmovaps xmm15, [rsp+0xE0]
00007942783da31a  add rsp, 0xF0
00007942783da321  pop r11
00007942783da323  pop r10
00007942783da325  pop r9
00007942783da327  pop r8
00007942783da329  pop rsi
00007942783da32a  pop rdi
00007942783da32b  pop rdx
00007942783da32c  pop rcx
00007942783da32d  pop rax
00007942783da32e  add rsp, 0x08
00007942783da332  jmp 0x00007942783D641A
00007942783da337  sub rsp, 0x08
00007942783da33b  push rax
00007942783da33c  push rcx
00007942783da33d  push rdx
00007942783da33e  push rdi
00007942783da33f  push rsi
00007942783da340  push r8
00007942783da342  push r9
00007942783da344  push r10
00007942783da346  push r11
00007942783da348  sub rsp, 0xF0
00007942783da34f  vmovaps [rsp], xmm0
00007942783da354  vmovaps [rsp+0x10], xmm1
00007942783da35a  vmovaps [rsp+0x20], xmm2
00007942783da360  vmovaps [rsp+0x30], xmm3
00007942783da366  vmovaps [rsp+0x40], xmm4
00007942783da36c  vmovaps [rsp+0x50], xmm5
00007942783da372  vmovaps [rsp+0x60], xmm6
00007942783da378  vmovaps [rsp+0x70], xmm7
00007942783da37e  vmovaps [rsp+0x80], xmm8
00007942783da387  vmovaps [rsp+0x90], xmm9
00007942783da390  vmovaps [rsp+0xA0], xmm10
00007942783da399  vmovaps [rsp+0xB0], xmm11
00007942783da3a2  vmovaps [rsp+0xC0], xmm13
00007942783da3ab  vmovaps [rsp+0xD0], xmm14
00007942783da3b4  vmovaps [rsp+0xE0], xmm15
00007942783da3bd  sub rsp, 0x30
00007942783da3c1  movaps [rsp], xmm12
00007942783da3c6  movaps [rsp+0x10], xmm7
00007942783da3cb  movaps [rsp+0x20], xmm13
00007942783da3d1  lea rdi, [rsp]
00007942783da3d5  mov esi, 0x00
00007942783da3da  mov rax, 0x59DDDCBA3530
00007942783da3e4  call rax
00007942783da3e6  movaps xmm12, [rsp]
00007942783da3eb  add rsp, 0x30
00007942783da3ef  vmovaps xmm0, [rsp]
00007942783da3f4  vmovaps xmm1, [rsp+0x10]
00007942783da3fa  vmovaps xmm2, [rsp+0x20]
00007942783da400  vmovaps xmm3, [rsp+0x30]
00007942783da406  vmovaps xmm4, [rsp+0x40]
00007942783da40c  vmovaps xmm5, [rsp+0x50]
00007942783da412  vmovaps xmm6, [rsp+0x60]
00007942783da418  vmovaps xmm7, [rsp+0x70]
00007942783da41e  vmovaps xmm8, [rsp+0x80]
00007942783da427  vmovaps xmm9, [rsp+0x90]
00007942783da430  vmovaps xmm10, [rsp+0xA0]
00007942783da439  vmovaps xmm11, [rsp+0xB0]
00007942783da442  vmovaps xmm13, [rsp+0xC0]
00007942783da44b  vmovaps xmm14, [rsp+0xD0]
00007942783da454  vmovaps xmm15, [rsp+0xE0]
00007942783da45d  add rsp, 0xF0
00007942783da464  pop r11
00007942783da466  pop r10
00007942783da468  pop r9
00007942783da46a  pop r8
00007942783da46c  pop rsi
00007942783da46d  pop rdi
00007942783da46e  pop rdx
00007942783da46f  pop rcx
00007942783da470  pop rax
00007942783da471  add rsp, 0x08
00007942783da475  jmp 0x00007942783D6441
00007942783da47a  sub rsp, 0x08
00007942783da47e  push rax
00007942783da47f  push rcx
00007942783da480  push rdx
00007942783da481  push rdi
00007942783da482  push rsi
00007942783da483  push r8
00007942783da485  push r9
00007942783da487  push r10
00007942783da489  push r11
00007942783da48b  sub rsp, 0xF0
00007942783da492  vmovaps [rsp], xmm0
00007942783da497  vmovaps [rsp+0x10], xmm1
00007942783da49d  vmovaps [rsp+0x20], xmm2
00007942783da4a3  vmovaps [rsp+0x30], xmm3
00007942783da4a9  vmovaps [rsp+0x40], xmm4
00007942783da4af  vmovaps [rsp+0x50], xmm5
00007942783da4b5  vmovaps [rsp+0x60], xmm6
00007942783da4bb  vmovaps [rsp+0x70], xmm7
00007942783da4c1  vmovaps [rsp+0x80], xmm8
00007942783da4ca  vmovaps [rsp+0x90], xmm9
00007942783da4d3  vmovaps [rsp+0xA0], xmm10
00007942783da4dc  vmovaps [rsp+0xB0], xmm11
00007942783da4e5  vmovaps [rsp+0xC0], xmm12
00007942783da4ee  vmovaps [rsp+0xD0], xmm14
00007942783da4f7  vmovaps [rsp+0xE0], xmm15
00007942783da500  sub rsp, 0x30
00007942783da504  movaps [rsp], xmm13
00007942783da509  movaps [rsp+0x10], xmm15
00007942783da50f  movaps [rsp+0x20], xmm8
00007942783da515  lea rdi, [rsp]
00007942783da519  mov esi, 0x00
00007942783da51e  mov rax, 0x59DDDCBA3530
00007942783da528  call rax
00007942783da52a  movaps xmm13, [rsp]
00007942783da52f  add rsp, 0x30
00007942783da533  vmovaps xmm0, [rsp]
00007942783da538  vmovaps xmm1, [rsp+0x10]
00007942783da53e  vmovaps xmm2, [rsp+0x20]
00007942783da544  vmovaps xmm3, [rsp+0x30]
00007942783da54a  vmovaps xmm4, [rsp+0x40]
00007942783da550  vmovaps xmm5, [rsp+0x50]
00007942783da556  vmovaps xmm6, [rsp+0x60]
00007942783da55c  vmovaps xmm7, [rsp+0x70]
00007942783da562  vmovaps xmm8, [rsp+0x80]
00007942783da56b  vmovaps xmm9, [rsp+0x90]
00007942783da574  vmovaps xmm10, [rsp+0xA0]
00007942783da57d  vmovaps xmm11, [rsp+0xB0]
00007942783da586  vmovaps xmm12, [rsp+0xC0]
00007942783da58f  vmovaps xmm14, [rsp+0xD0]
00007942783da598  vmovaps xmm15, [rsp+0xE0]
00007942783da5a1  add rsp, 0xF0
00007942783da5a8  pop r11
00007942783da5aa  pop r10
00007942783da5ac  pop r9
00007942783da5ae  pop r8
00007942783da5b0  pop rsi
00007942783da5b1  pop rdi
00007942783da5b2  pop rdx
00007942783da5b3  pop rcx
00007942783da5b4  pop rax
00007942783da5b5  add rsp, 0x08
00007942783da5b9  jmp 0x00007942783D645C
00007942783da5be  sub rsp, 0x08
00007942783da5c2  push rax
00007942783da5c3  push rcx
00007942783da5c4  push rdx
00007942783da5c5  push rdi
00007942783da5c6  push rsi
00007942783da5c7  push r8
00007942783da5c9  push r9
00007942783da5cb  push r10
00007942783da5cd  push r11
00007942783da5cf  sub rsp, 0xF0
00007942783da5d6  vmovaps [rsp], xmm0
00007942783da5db  vmovaps [rsp+0x10], xmm1
00007942783da5e1  vmovaps [rsp+0x20], xmm2
00007942783da5e7  vmovaps [rsp+0x30], xmm3
00007942783da5ed  vmovaps [rsp+0x40], xmm4
00007942783da5f3  vmovaps [rsp+0x50], xmm5
00007942783da5f9  vmovaps [rsp+0x60], xmm6
00007942783da5ff  vmovaps [rsp+0x70], xmm7
00007942783da605  vmovaps [rsp+0x80], xmm9
00007942783da60e  vmovaps [rsp+0x90], xmm10
00007942783da617  vmovaps [rsp+0xA0], xmm11
00007942783da620  vmovaps [rsp+0xB0], xmm12
00007942783da629  vmovaps [rsp+0xC0], xmm13
00007942783da632  vmovaps [rsp+0xD0], xmm14
00007942783da63b  vmovaps [rsp+0xE0], xmm15
00007942783da644  sub rsp, 0x30
00007942783da648  movaps [rsp], xmm8
00007942783da64d  movaps [rsp+0x10], xmm15
00007942783da653  movaps [rsp+0x20], xmm9
00007942783da659  lea rdi, [rsp]
00007942783da65d  mov esi, 0x00
00007942783da662  mov rax, 0x59DDDCBA3530
00007942783da66c  call rax
00007942783da66e  movaps xmm8, [rsp]
00007942783da673  add rsp, 0x30
00007942783da677  vmovaps xmm0, [rsp]
00007942783da67c  vmovaps xmm1, [rsp+0x10]
00007942783da682  vmovaps xmm2, [rsp+0x20]
00007942783da688  vmovaps xmm3, [rsp+0x30]
00007942783da68e  vmovaps xmm4, [rsp+0x40]
00007942783da694  vmovaps xmm5, [rsp+0x50]
00007942783da69a  vmovaps xmm6, [rsp+0x60]
00007942783da6a0  vmovaps xmm7, [rsp+0x70]
00007942783da6a6  vmovaps xmm9, [rsp+0x80]
00007942783da6af  vmovaps xmm10, [rsp+0x90]
00007942783da6b8  vmovaps xmm11, [rsp+0xA0]
00007942783da6c1  vmovaps xmm12, [rsp+0xB0]
00007942783da6ca  vmovaps xmm13, [rsp+0xC0]
00007942783da6d3  vmovaps xmm14, [rsp+0xD0]
00007942783da6dc  vmovaps xmm15, [rsp+0xE0]
00007942783da6e5  add rsp, 0xF0
00007942783da6ec  pop r11
00007942783da6ee  pop r10
00007942783da6f0  pop r9
00007942783da6f2  pop r8
00007942783da6f4  pop rsi
00007942783da6f5  pop rdi
00007942783da6f6  pop rdx
00007942783da6f7  pop rcx
00007942783da6f8  pop rax
00007942783da6f9  add rsp, 0x08
00007942783da6fd  jmp 0x00007942783D648A
00007942783da702  sub rsp, 0x08
00007942783da706  push rax
00007942783da707  push rcx
00007942783da708  push rdx
00007942783da709  push rdi
00007942783da70a  push rsi
00007942783da70b  push r8
00007942783da70d  push r9
00007942783da70f  push r10
00007942783da711  push r11
00007942783da713  sub rsp, 0xF0
00007942783da71a  vmovaps [rsp], xmm0
00007942783da71f  vmovaps [rsp+0x10], xmm1
00007942783da725  vmovaps [rsp+0x20], xmm2
00007942783da72b  vmovaps [rsp+0x30], xmm3
00007942783da731  vmovaps [rsp+0x40], xmm4
00007942783da737  vmovaps [rsp+0x50], xmm5
00007942783da73d  vmovaps [rsp+0x60], xmm6
00007942783da743  vmovaps [rsp+0x70], xmm7
00007942783da749  vmovaps [rsp+0x80], xmm8
00007942783da752  vmovaps [rsp+0x90], xmm9
00007942783da75b  vmovaps [rsp+0xA0], xmm10
00007942783da764  vmovaps [rsp+0xB0], xmm11
00007942783da76d  vmovaps [rsp+0xC0], xmm12
00007942783da776  vmovaps [rsp+0xD0], xmm13
00007942783da77f  vmovaps [rsp+0xE0], xmm14
00007942783da788  sub rsp, 0x30
00007942783da78c  movaps [rsp], xmm15
00007942783da791  movaps [rsp+0x10], xmm11
00007942783da797  movaps [rsp+0x20], xmm6
00007942783da79c  lea rdi, [rsp]
00007942783da7a0  mov esi, 0x00
00007942783da7a5  mov rax, 0x59DDDCBA3530
00007942783da7af  call rax
00007942783da7b1  movaps xmm15, [rsp]
00007942783da7b6  add rsp, 0x30
00007942783da7ba  vmovaps xmm0, [rsp]
00007942783da7bf  vmovaps xmm1, [rsp+0x10]
00007942783da7c5  vmovaps xmm2, [rsp+0x20]
00007942783da7cb  vmovaps xmm3, [rsp+0x30]
00007942783da7d1  vmovaps xmm4, [rsp+0x40]
00007942783da7d7  vmovaps xmm5, [rsp+0x50]
00007942783da7dd  vmovaps xmm6, [rsp+0x60]
00007942783da7e3  vmovaps xmm7, [rsp+0x70]
00007942783da7e9  vmovaps xmm8, [rsp+0x80]
00007942783da7f2  vmovaps xmm9, [rsp+0x90]
00007942783da7fb  vmovaps xmm10, [rsp+0xA0]
00007942783da804  vmovaps xmm11, [rsp+0xB0]
00007942783da80d  vmovaps xmm12, [rsp+0xC0]
00007942783da816  vmovaps xmm13, [rsp+0xD0]
00007942783da81f  vmovaps xmm14, [rsp+0xE0]
00007942783da828  add rsp, 0xF0
00007942783da82f  pop r11
00007942783da831  pop r10
00007942783da833  pop r9
00007942783da835  pop r8
00007942783da837  pop rsi
00007942783da838  pop rdi
00007942783da839  pop rdx
00007942783da83a  pop rcx
00007942783da83b  pop rax
00007942783da83c  add rsp, 0x08
00007942783da840  jmp 0x00007942783D64A5
00007942783da845  sub rsp, 0x08
00007942783da849  push rax
00007942783da84a  push rcx
00007942783da84b  push rdx
00007942783da84c  push rdi
00007942783da84d  push rsi
00007942783da84e  push r8
00007942783da850  push r9
00007942783da852  push r10
00007942783da854  push r11
00007942783da856  sub rsp, 0xF0
00007942783da85d  vmovaps [rsp], xmm0
00007942783da862  vmovaps [rsp+0x10], xmm1
00007942783da868  vmovaps [rsp+0x20], xmm2
00007942783da86e  vmovaps [rsp+0x30], xmm3
00007942783da874  vmovaps [rsp+0x40], xmm4
00007942783da87a  vmovaps [rsp+0x50], xmm5
00007942783da880  vmovaps [rsp+0x60], xmm6
00007942783da886  vmovaps [rsp+0x70], xmm8
00007942783da88c  vmovaps [rsp+0x80], xmm9
00007942783da895  vmovaps [rsp+0x90], xmm10
00007942783da89e  vmovaps [rsp+0xA0], xmm11
00007942783da8a7  vmovaps [rsp+0xB0], xmm12
00007942783da8b0  vmovaps [rsp+0xC0], xmm13
00007942783da8b9  vmovaps [rsp+0xD0], xmm14
00007942783da8c2  vmovaps [rsp+0xE0], xmm15
00007942783da8cb  sub rsp, 0x30
00007942783da8cf  movaps [rsp], xmm7
00007942783da8d3  movaps [rsp+0x10], xmm11
00007942783da8d9  movaps [rsp+0x20], xmm9
00007942783da8df  lea rdi, [rsp]
00007942783da8e3  mov esi, 0x00
00007942783da8e8  mov rax, 0x59DDDCBA3530
00007942783da8f2  call rax
00007942783da8f4  movaps xmm7, [rsp]
00007942783da8f8  add rsp, 0x30
00007942783da8fc  vmovaps xmm0, [rsp]
00007942783da901  vmovaps xmm1, [rsp+0x10]
00007942783da907  vmovaps xmm2, [rsp+0x20]
00007942783da90d  vmovaps xmm3, [rsp+0x30]
00007942783da913  vmovaps xmm4, [rsp+0x40]
00007942783da919  vmovaps xmm5, [rsp+0x50]
00007942783da91f  vmovaps xmm6, [rsp+0x60]
00007942783da925  vmovaps xmm8, [rsp+0x70]
00007942783da92b  vmovaps xmm9, [rsp+0x80]
00007942783da934  vmovaps xmm10, [rsp+0x90]
00007942783da93d  vmovaps xmm11, [rsp+0xA0]
00007942783da946  vmovaps xmm12, [rsp+0xB0]
00007942783da94f  vmovaps xmm13, [rsp+0xC0]
00007942783da958  vmovaps xmm14, [rsp+0xD0]
00007942783da961  vmovaps xmm15, [rsp+0xE0]
00007942783da96a  add rsp, 0xF0
00007942783da971  pop r11
00007942783da973  pop r10
00007942783da975  pop r9
00007942783da977  pop r8
00007942783da979  pop rsi
00007942783da97a  pop rdi
00007942783da97b  pop rdx
00007942783da97c  pop rcx
00007942783da97d  pop rax
00007942783da97e  add rsp, 0x08
00007942783da982  jmp 0x00007942783D64D2
00007942783da987  sub rsp, 0x08
00007942783da98b  push rax
00007942783da98c  push rcx
00007942783da98d  push rdx
00007942783da98e  push rdi
00007942783da98f  push rsi
00007942783da990  push r8
00007942783da992  push r9
00007942783da994  push r10
00007942783da996  push r11
00007942783da998  sub rsp, 0xF0
00007942783da99f  vmovaps [rsp], xmm0
00007942783da9a4  vmovaps [rsp+0x10], xmm1
00007942783da9aa  vmovaps [rsp+0x20], xmm2
00007942783da9b0  vmovaps [rsp+0x30], xmm3
00007942783da9b6  vmovaps [rsp+0x40], xmm4
00007942783da9bc  vmovaps [rsp+0x50], xmm5
00007942783da9c2  vmovaps [rsp+0x60], xmm6
00007942783da9c8  vmovaps [rsp+0x70], xmm7
00007942783da9ce  vmovaps [rsp+0x80], xmm8
00007942783da9d7  vmovaps [rsp+0x90], xmm9
00007942783da9e0  vmovaps [rsp+0xA0], xmm10
00007942783da9e9  vmovaps [rsp+0xB0], xmm12
00007942783da9f2  vmovaps [rsp+0xC0], xmm13
00007942783da9fb  vmovaps [rsp+0xD0], xmm14
00007942783daa04  vmovaps [rsp+0xE0], xmm15
00007942783daa0d  sub rsp, 0x30
00007942783daa11  movaps [rsp], xmm11
00007942783daa16  movaps [rsp+0x10], xmm10
00007942783daa1c  movaps [rsp+0x20], xmm14
00007942783daa22  lea rdi, [rsp]
00007942783daa26  mov esi, 0x00
00007942783daa2b  mov rax, 0x59DDDCBA3530
00007942783daa35  call rax
00007942783daa37  movaps xmm11, [rsp]
00007942783daa3c  add rsp, 0x30
00007942783daa40  vmovaps xmm0, [rsp]
00007942783daa45  vmovaps xmm1, [rsp+0x10]
00007942783daa4b  vmovaps xmm2, [rsp+0x20]
00007942783daa51  vmovaps xmm3, [rsp+0x30]
00007942783daa57  vmovaps xmm4, [rsp+0x40]
00007942783daa5d  vmovaps xmm5, [rsp+0x50]
00007942783daa63  vmovaps xmm6, [rsp+0x60]
00007942783daa69  vmovaps xmm7, [rsp+0x70]
00007942783daa6f  vmovaps xmm8, [rsp+0x80]
00007942783daa78  vmovaps xmm9, [rsp+0x90]
00007942783daa81  vmovaps xmm10, [rsp+0xA0]
00007942783daa8a  vmovaps xmm12, [rsp+0xB0]
00007942783daa93  vmovaps xmm13, [rsp+0xC0]
00007942783daa9c  vmovaps xmm14, [rsp+0xD0]
00007942783daaa5  vmovaps xmm15, [rsp+0xE0]
00007942783daaae  add rsp, 0xF0
00007942783daab5  pop r11
00007942783daab7  pop r10
00007942783daab9  pop r9
00007942783daabb  pop r8
00007942783daabd  pop rsi
00007942783daabe  pop rdi
00007942783daabf  pop rdx
00007942783daac0  pop rcx
00007942783daac1  pop rax
00007942783daac2  add rsp, 0x08
00007942783daac6  jmp 0x00007942783D64ED
00007942783daacb  call 0x00007942782E45A0
00007942783daad0  jmp 0x00007942783D64F7
00007942783daad5  sub rsp, 0x08
00007942783daad9  push rax
00007942783daada  push rcx
00007942783daadb  push rdx
00007942783daadc  push rdi
00007942783daadd  push rsi
00007942783daade  push r8
00007942783daae0  push r9
00007942783daae2  push r10
00007942783daae4  push r11
00007942783daae6  sub rsp, 0xF0
00007942783daaed  vmovaps [rsp], xmm0
00007942783daaf2  vmovaps [rsp+0x10], xmm1
00007942783daaf8  vmovaps [rsp+0x20], xmm2
00007942783daafe  vmovaps [rsp+0x30], xmm3
00007942783dab04  vmovaps [rsp+0x40], xmm4
00007942783dab0a  vmovaps [rsp+0x50], xmm5
00007942783dab10  vmovaps [rsp+0x60], xmm6
00007942783dab16  vmovaps [rsp+0x70], xmm7
00007942783dab1c  vmovaps [rsp+0x80], xmm8
00007942783dab25  vmovaps [rsp+0x90], xmm9
00007942783dab2e  vmovaps [rsp+0xA0], xmm11
00007942783dab37  vmovaps [rsp+0xB0], xmm12
00007942783dab40  vmovaps [rsp+0xC0], xmm13
00007942783dab49  vmovaps [rsp+0xD0], xmm14
00007942783dab52  vmovaps [rsp+0xE0], xmm15
00007942783dab5b  sub rsp, 0x30
00007942783dab5f  movaps [rsp], xmm10
00007942783dab64  movaps [rsp+0x10], xmm1
00007942783dab69  movaps [rsp+0x20], xmm12
00007942783dab6f  lea rdi, [rsp]
00007942783dab73  mov esi, 0x00
00007942783dab78  mov rax, 0x59DDDCBA3530
00007942783dab82  call rax
00007942783dab84  movaps xmm10, [rsp]
00007942783dab89  add rsp, 0x30
00007942783dab8d  vmovaps xmm0, [rsp]
00007942783dab92  vmovaps xmm1, [rsp+0x10]
00007942783dab98  vmovaps xmm2, [rsp+0x20]
00007942783dab9e  vmovaps xmm3, [rsp+0x30]
00007942783daba4  vmovaps xmm4, [rsp+0x40]
00007942783dabaa  vmovaps xmm5, [rsp+0x50]
00007942783dabb0  vmovaps xmm6, [rsp+0x60]
00007942783dabb6  vmovaps xmm7, [rsp+0x70]
00007942783dabbc  vmovaps xmm8, [rsp+0x80]
00007942783dabc5  vmovaps xmm9, [rsp+0x90]
00007942783dabce  vmovaps xmm11, [rsp+0xA0]
00007942783dabd7  vmovaps xmm12, [rsp+0xB0]
00007942783dabe0  vmovaps xmm13, [rsp+0xC0]
00007942783dabe9  vmovaps xmm14, [rsp+0xD0]
00007942783dabf2  vmovaps xmm15, [rsp+0xE0]
00007942783dabfb  add rsp, 0xF0
00007942783dac02  pop r11
00007942783dac04  pop r10
00007942783dac06  pop r9
00007942783dac08  pop r8
00007942783dac0a  pop rsi
00007942783dac0b  pop rdi
00007942783dac0c  pop rdx
00007942783dac0d  pop rcx
00007942783dac0e  pop rax
00007942783dac0f  add rsp, 0x08
00007942783dac13  jmp 0x00007942783D651A
00007942783dac18  sub rsp, 0x08
00007942783dac1c  push rax
00007942783dac1d  push rcx
00007942783dac1e  push rdx
00007942783dac1f  push rdi
00007942783dac20  push rsi
00007942783dac21  push r8
00007942783dac23  push r9
00007942783dac25  push r10
00007942783dac27  push r11
00007942783dac29  sub rsp, 0xF0
00007942783dac30  vmovaps [rsp], xmm0
00007942783dac35  vmovaps [rsp+0x10], xmm1
00007942783dac3b  vmovaps [rsp+0x20], xmm2
00007942783dac41  vmovaps [rsp+0x30], xmm3
00007942783dac47  vmovaps [rsp+0x40], xmm4
00007942783dac4d  vmovaps [rsp+0x50], xmm5
00007942783dac53  vmovaps [rsp+0x60], xmm6
00007942783dac59  vmovaps [rsp+0x70], xmm7
00007942783dac5f  vmovaps [rsp+0x80], xmm8
00007942783dac68  vmovaps [rsp+0x90], xmm9
00007942783dac71  vmovaps [rsp+0xA0], xmm10
00007942783dac7a  vmovaps [rsp+0xB0], xmm11
00007942783dac83  vmovaps [rsp+0xC0], xmm13
00007942783dac8c  vmovaps [rsp+0xD0], xmm14
00007942783dac95  vmovaps [rsp+0xE0], xmm15
00007942783dac9e  sub rsp, 0x30
00007942783daca2  movaps [rsp], xmm12
00007942783daca7  movaps [rsp+0x10], xmm14
00007942783dacad  movaps [rsp+0x20], xmm1
00007942783dacb2  lea rdi, [rsp]
00007942783dacb6  mov esi, 0x00
00007942783dacbb  mov rax, 0x59DDDCBA3530
00007942783dacc5  call rax
00007942783dacc7  movaps xmm12, [rsp]
00007942783daccc  add rsp, 0x30
00007942783dacd0  vmovaps xmm0, [rsp]
00007942783dacd5  vmovaps xmm1, [rsp+0x10]
00007942783dacdb  vmovaps xmm2, [rsp+0x20]
00007942783dace1  vmovaps xmm3, [rsp+0x30]
00007942783dace7  vmovaps xmm4, [rsp+0x40]
00007942783daced  vmovaps xmm5, [rsp+0x50]
00007942783dacf3  vmovaps xmm6, [rsp+0x60]
00007942783dacf9  vmovaps xmm7, [rsp+0x70]
00007942783dacff  vmovaps xmm8, [rsp+0x80]
00007942783dad08  vmovaps xmm9, [rsp+0x90]
00007942783dad11  vmovaps xmm10, [rsp+0xA0]
00007942783dad1a  vmovaps xmm11, [rsp+0xB0]
00007942783dad23  vmovaps xmm13, [rsp+0xC0]
00007942783dad2c  vmovaps xmm14, [rsp+0xD0]
00007942783dad35  vmovaps xmm15, [rsp+0xE0]
00007942783dad3e  add rsp, 0xF0
00007942783dad45  pop r11
00007942783dad47  pop r10
00007942783dad49  pop r9
00007942783dad4b  pop r8
00007942783dad4d  pop rsi
00007942783dad4e  pop rdi
00007942783dad4f  pop rdx
00007942783dad50  pop rcx
00007942783dad51  pop rax
00007942783dad52  add rsp, 0x08
00007942783dad56  jmp 0x00007942783D6549
00007942783dad5b  sub rsp, 0x08
00007942783dad5f  push rax
00007942783dad60  push rcx
00007942783dad61  push rdx
00007942783dad62  push rdi
00007942783dad63  push rsi
00007942783dad64  push r8
00007942783dad66  push r9
00007942783dad68  push r10
00007942783dad6a  push r11
00007942783dad6c  sub rsp, 0xF0
00007942783dad73  vmovaps [rsp], xmm0
00007942783dad78  vmovaps [rsp+0x10], xmm1
00007942783dad7e  vmovaps [rsp+0x20], xmm2
00007942783dad84  vmovaps [rsp+0x30], xmm3
00007942783dad8a  vmovaps [rsp+0x40], xmm4
00007942783dad90  vmovaps [rsp+0x50], xmm5
00007942783dad96  vmovaps [rsp+0x60], xmm6
00007942783dad9c  vmovaps [rsp+0x70], xmm7
00007942783dada2  vmovaps [rsp+0x80], xmm8
00007942783dadab  vmovaps [rsp+0x90], xmm9
00007942783dadb4  vmovaps [rsp+0xA0], xmm10
00007942783dadbd  vmovaps [rsp+0xB0], xmm11
00007942783dadc6  vmovaps [rsp+0xC0], xmm12
00007942783dadcf  vmovaps [rsp+0xD0], xmm13
00007942783dadd8  vmovaps [rsp+0xE0], xmm15
00007942783dade1  sub rsp, 0x30
00007942783dade5  movaps [rsp], xmm14
00007942783dadea  movaps [rsp+0x10], xmm9
00007942783dadf0  movaps [rsp+0x20], xmm1
00007942783dadf5  lea rdi, [rsp]
00007942783dadf9  mov esi, 0x00
00007942783dadfe  mov rax, 0x59DDDCBA3530
00007942783dae08  call rax
00007942783dae0a  movaps xmm14, [rsp]
00007942783dae0f  add rsp, 0x30
00007942783dae13  vmovaps xmm0, [rsp]
00007942783dae18  vmovaps xmm1, [rsp+0x10]
00007942783dae1e  vmovaps xmm2, [rsp+0x20]
00007942783dae24  vmovaps xmm3, [rsp+0x30]
00007942783dae2a  vmovaps xmm4, [rsp+0x40]
00007942783dae30  vmovaps xmm5, [rsp+0x50]
00007942783dae36  vmovaps xmm6, [rsp+0x60]
00007942783dae3c  vmovaps xmm7, [rsp+0x70]
00007942783dae42  vmovaps xmm8, [rsp+0x80]
00007942783dae4b  vmovaps xmm9, [rsp+0x90]
00007942783dae54  vmovaps xmm10, [rsp+0xA0]
00007942783dae5d  vmovaps xmm11, [rsp+0xB0]
00007942783dae66  vmovaps xmm12, [rsp+0xC0]
00007942783dae6f  vmovaps xmm13, [rsp+0xD0]
00007942783dae78  vmovaps xmm15, [rsp+0xE0]
00007942783dae81  add rsp, 0xF0
00007942783dae88  pop r11
00007942783dae8a  pop r10
00007942783dae8c  pop r9
00007942783dae8e  pop r8
00007942783dae90  pop rsi
00007942783dae91  pop rdi
00007942783dae92  pop rdx
00007942783dae93  pop rcx
00007942783dae94  pop rax
00007942783dae95  add rsp, 0x08
00007942783dae99  jmp 0x00007942783D6578
00007942783dae9e  sub rsp, 0x08
00007942783daea2  push rax
00007942783daea3  push rcx
00007942783daea4  push rdx
00007942783daea5  push rdi
00007942783daea6  push rsi
00007942783daea7  push r8
00007942783daea9  push r9
00007942783daeab  push r10
00007942783daead  push r11
00007942783daeaf  sub rsp, 0xF0
00007942783daeb6  vmovaps [rsp], xmm0
00007942783daebb  vmovaps [rsp+0x10], xmm2
00007942783daec1  vmovaps [rsp+0x20], xmm3
00007942783daec7  vmovaps [rsp+0x30], xmm4
00007942783daecd  vmovaps [rsp+0x40], xmm5
00007942783daed3  vmovaps [rsp+0x50], xmm6
00007942783daed9  vmovaps [rsp+0x60], xmm7
00007942783daedf  vmovaps [rsp+0x70], xmm8
00007942783daee5  vmovaps [rsp+0x80], xmm9
00007942783daeee  vmovaps [rsp+0x90], xmm10
00007942783daef7  vmovaps [rsp+0xA0], xmm11
00007942783daf00  vmovaps [rsp+0xB0], xmm12
00007942783daf09  vmovaps [rsp+0xC0], xmm13
00007942783daf12  vmovaps [rsp+0xD0], xmm14
00007942783daf1b  vmovaps [rsp+0xE0], xmm15
00007942783daf24  sub rsp, 0x30
00007942783daf28  movaps [rsp], xmm1
00007942783daf2c  movaps [rsp+0x10], xmm13
00007942783daf32  movaps [rsp+0x20], xmm8
00007942783daf38  lea rdi, [rsp]
00007942783daf3c  mov esi, 0x00
00007942783daf41  mov rax, 0x59DDDCBA3530
00007942783daf4b  call rax
00007942783daf4d  movaps xmm1, [rsp]
00007942783daf51  add rsp, 0x30
00007942783daf55  vmovaps xmm0, [rsp]
00007942783daf5a  vmovaps xmm2, [rsp+0x10]
00007942783daf60  vmovaps xmm3, [rsp+0x20]
00007942783daf66  vmovaps xmm4, [rsp+0x30]
00007942783daf6c  vmovaps xmm5, [rsp+0x40]
00007942783daf72  vmovaps xmm6, [rsp+0x50]
00007942783daf78  vmovaps xmm7, [rsp+0x60]
00007942783daf7e  vmovaps xmm8, [rsp+0x70]
00007942783daf84  vmovaps xmm9, [rsp+0x80]
00007942783daf8d  vmovaps xmm10, [rsp+0x90]
00007942783daf96  vmovaps xmm11, [rsp+0xA0]
00007942783daf9f  vmovaps xmm12, [rsp+0xB0]
00007942783dafa8  vmovaps xmm13, [rsp+0xC0]
00007942783dafb1  vmovaps xmm14, [rsp+0xD0]
00007942783dafba  vmovaps xmm15, [rsp+0xE0]
00007942783dafc3  add rsp, 0xF0
00007942783dafca  pop r11
00007942783dafcc  pop r10
00007942783dafce  pop r9
00007942783dafd0  pop r8
00007942783dafd2  pop rsi
00007942783dafd3  pop rdi
00007942783dafd4  pop rdx
00007942783dafd5  pop rcx
00007942783dafd6  pop rax
00007942783dafd7  add rsp, 0x08
00007942783dafdb  jmp 0x00007942783D659A
00007942783dafe0  call 0x000079427820C260
00007942783dafe5  jmp 0x00007942783D65A8
00007942783dafea  call 0x00007942782DE950
00007942783dafef  jmp 0x00007942783D65B2
00007942783daff4  sub rsp, 0x08
00007942783daff8  push rax
00007942783daff9  push rcx
00007942783daffa  push rdx
00007942783daffb  push rdi
00007942783daffc  push rsi
00007942783daffd  push r8
00007942783dafff  push r9
00007942783db001  push r10
00007942783db003  push r11
00007942783db005  sub rsp, 0xF0
00007942783db00c  vmovaps [rsp], xmm0
00007942783db011  vmovaps [rsp+0x10], xmm1
00007942783db017  vmovaps [rsp+0x20], xmm2
00007942783db01d  vmovaps [rsp+0x30], xmm3
00007942783db023  vmovaps [rsp+0x40], xmm4
00007942783db029  vmovaps [rsp+0x50], xmm5
00007942783db02f  vmovaps [rsp+0x60], xmm6
00007942783db035  vmovaps [rsp+0x70], xmm7
00007942783db03b  vmovaps [rsp+0x80], xmm9
00007942783db044  vmovaps [rsp+0x90], xmm10
00007942783db04d  vmovaps [rsp+0xA0], xmm11
00007942783db056  vmovaps [rsp+0xB0], xmm12
00007942783db05f  vmovaps [rsp+0xC0], xmm13
00007942783db068  vmovaps [rsp+0xD0], xmm14
00007942783db071  vmovaps [rsp+0xE0], xmm15
00007942783db07a  sub rsp, 0x30
00007942783db07e  movaps [rsp], xmm8
00007942783db083  movaps [rsp+0x10], xmm15
00007942783db089  movaps [rsp+0x20], xmm7
00007942783db08e  lea rdi, [rsp]
00007942783db092  mov esi, 0x00
00007942783db097  mov rax, 0x59DDDCBA3530
00007942783db0a1  call rax
00007942783db0a3  movaps xmm8, [rsp]
00007942783db0a8  add rsp, 0x30
00007942783db0ac  vmovaps xmm0, [rsp]
00007942783db0b1  vmovaps xmm1, [rsp+0x10]
00007942783db0b7  vmovaps xmm2, [rsp+0x20]
00007942783db0bd  vmovaps xmm3, [rsp+0x30]
00007942783db0c3  vmovaps xmm4, [rsp+0x40]
00007942783db0c9  vmovaps xmm5, [rsp+0x50]
00007942783db0cf  vmovaps xmm6, [rsp+0x60]
00007942783db0d5  vmovaps xmm7, [rsp+0x70]
00007942783db0db  vmovaps xmm9, [rsp+0x80]
00007942783db0e4  vmovaps xmm10, [rsp+0x90]
00007942783db0ed  vmovaps xmm11, [rsp+0xA0]
00007942783db0f6  vmovaps xmm12, [rsp+0xB0]
00007942783db0ff  vmovaps xmm13, [rsp+0xC0]
00007942783db108  vmovaps xmm14, [rsp+0xD0]
00007942783db111  vmovaps xmm15, [rsp+0xE0]
00007942783db11a  add rsp, 0xF0
00007942783db121  pop r11
00007942783db123  pop r10
00007942783db125  pop r9
00007942783db127  pop r8
00007942783db129  pop rsi
00007942783db12a  pop rdi
00007942783db12b  pop rdx
00007942783db12c  pop rcx
00007942783db12d  pop rax
00007942783db12e  add rsp, 0x08
00007942783db132  jmp 0x00007942783D65D4
00007942783db137  sub rsp, 0x08
00007942783db13b  push rax
00007942783db13c  push rcx
00007942783db13d  push rdx
00007942783db13e  push rdi
00007942783db13f  push rsi
00007942783db140  push r8
00007942783db142  push r9
00007942783db144  push r10
00007942783db146  push r11
00007942783db148  sub rsp, 0xF0
00007942783db14f  vmovaps [rsp], xmm0
00007942783db154  vmovaps [rsp+0x10], xmm1
00007942783db15a  vmovaps [rsp+0x20], xmm2
00007942783db160  vmovaps [rsp+0x30], xmm3
00007942783db166  vmovaps [rsp+0x40], xmm4
00007942783db16c  vmovaps [rsp+0x50], xmm5
00007942783db172  vmovaps [rsp+0x60], xmm6
00007942783db178  vmovaps [rsp+0x70], xmm8
00007942783db17e  vmovaps [rsp+0x80], xmm9
00007942783db187  vmovaps [rsp+0x90], xmm10
00007942783db190  vmovaps [rsp+0xA0], xmm11
00007942783db199  vmovaps [rsp+0xB0], xmm12
00007942783db1a2  vmovaps [rsp+0xC0], xmm13
00007942783db1ab  vmovaps [rsp+0xD0], xmm14
00007942783db1b4  vmovaps [rsp+0xE0], xmm15
00007942783db1bd  sub rsp, 0x30
00007942783db1c1  movaps [rsp], xmm7
00007942783db1c5  movaps [rsp+0x10], xmm9
00007942783db1cb  movaps [rsp+0x20], xmm15
00007942783db1d1  lea rdi, [rsp]
00007942783db1d5  mov esi, 0x00
00007942783db1da  mov rax, 0x59DDDCBA3530
00007942783db1e4  call rax
00007942783db1e6  movaps xmm7, [rsp]
00007942783db1ea  add rsp, 0x30
00007942783db1ee  vmovaps xmm0, [rsp]
00007942783db1f3  vmovaps xmm1, [rsp+0x10]
00007942783db1f9  vmovaps xmm2, [rsp+0x20]
00007942783db1ff  vmovaps xmm3, [rsp+0x30]
00007942783db205  vmovaps xmm4, [rsp+0x40]
00007942783db20b  vmovaps xmm5, [rsp+0x50]
00007942783db211  vmovaps xmm6, [rsp+0x60]
00007942783db217  vmovaps xmm8, [rsp+0x70]
00007942783db21d  vmovaps xmm9, [rsp+0x80]
00007942783db226  vmovaps xmm10, [rsp+0x90]
00007942783db22f  vmovaps xmm11, [rsp+0xA0]
00007942783db238  vmovaps xmm12, [rsp+0xB0]
00007942783db241  vmovaps xmm13, [rsp+0xC0]
00007942783db24a  vmovaps xmm14, [rsp+0xD0]
00007942783db253  vmovaps xmm15, [rsp+0xE0]
00007942783db25c  add rsp, 0xF0
00007942783db263  pop r11
00007942783db265  pop r10
00007942783db267  pop r9
00007942783db269  pop r8
00007942783db26b  pop rsi
00007942783db26c  pop rdi
00007942783db26d  pop rdx
00007942783db26e  pop rcx
00007942783db26f  pop rax
00007942783db270  add rsp, 0x08
00007942783db274  jmp 0x00007942783D6601
00007942783db279  sub rsp, 0x08
00007942783db27d  push rax
00007942783db27e  push rcx
00007942783db27f  push rdx
00007942783db280  push rdi
00007942783db281  push rsi
00007942783db282  push r8
00007942783db284  push r9
00007942783db286  push r10
00007942783db288  push r11
00007942783db28a  sub rsp, 0xF0
00007942783db291  vmovaps [rsp], xmm0
00007942783db296  vmovaps [rsp+0x10], xmm1
00007942783db29c  vmovaps [rsp+0x20], xmm2
00007942783db2a2  vmovaps [rsp+0x30], xmm3
00007942783db2a8  vmovaps [rsp+0x40], xmm4
00007942783db2ae  vmovaps [rsp+0x50], xmm5
00007942783db2b4  vmovaps [rsp+0x60], xmm6
00007942783db2ba  vmovaps [rsp+0x70], xmm7
00007942783db2c0  vmovaps [rsp+0x80], xmm8
00007942783db2c9  vmovaps [rsp+0x90], xmm10
00007942783db2d2  vmovaps [rsp+0xA0], xmm11
00007942783db2db  vmovaps [rsp+0xB0], xmm12
00007942783db2e4  vmovaps [rsp+0xC0], xmm13
00007942783db2ed  vmovaps [rsp+0xD0], xmm14
00007942783db2f6  vmovaps [rsp+0xE0], xmm15
00007942783db2ff  sub rsp, 0x30
00007942783db303  movaps [rsp], xmm9
00007942783db308  movaps [rsp+0x10], xmm13
00007942783db30e  movaps [rsp+0x20], xmm15
00007942783db314  lea rdi, [rsp]
00007942783db318  mov esi, 0x00
00007942783db31d  mov rax, 0x59DDDCBA3530
00007942783db327  call rax
00007942783db329  movaps xmm9, [rsp]
00007942783db32e  add rsp, 0x30
00007942783db332  vmovaps xmm0, [rsp]
00007942783db337  vmovaps xmm1, [rsp+0x10]
00007942783db33d  vmovaps xmm2, [rsp+0x20]
00007942783db343  vmovaps xmm3, [rsp+0x30]
00007942783db349  vmovaps xmm4, [rsp+0x40]
00007942783db34f  vmovaps xmm5, [rsp+0x50]
00007942783db355  vmovaps xmm6, [rsp+0x60]
00007942783db35b  vmovaps xmm7, [rsp+0x70]
00007942783db361  vmovaps xmm8, [rsp+0x80]
00007942783db36a  vmovaps xmm10, [rsp+0x90]
00007942783db373  vmovaps xmm11, [rsp+0xA0]
00007942783db37c  vmovaps xmm12, [rsp+0xB0]
00007942783db385  vmovaps xmm13, [rsp+0xC0]
00007942783db38e  vmovaps xmm14, [rsp+0xD0]
00007942783db397  vmovaps xmm15, [rsp+0xE0]
00007942783db3a0  add rsp, 0xF0
00007942783db3a7  pop r11
00007942783db3a9  pop r10
00007942783db3ab  pop r9
00007942783db3ad  pop r8
00007942783db3af  pop rsi
00007942783db3b0  pop rdi
00007942783db3b1  pop rdx
00007942783db3b2  pop rcx
00007942783db3b3  pop rax
00007942783db3b4  add rsp, 0x08
00007942783db3b8  jmp 0x00007942783D662F
00007942783db3bd  sub rsp, 0x08
00007942783db3c1  push rax
00007942783db3c2  push rcx
00007942783db3c3  push rdx
00007942783db3c4  push rdi
00007942783db3c5  push rsi
00007942783db3c6  push r8
00007942783db3c8  push r9
00007942783db3ca  push r10
00007942783db3cc  push r11
00007942783db3ce  sub rsp, 0xF0
00007942783db3d5  vmovaps [rsp], xmm0
00007942783db3da  vmovaps [rsp+0x10], xmm1
00007942783db3e0  vmovaps [rsp+0x20], xmm2
00007942783db3e6  vmovaps [rsp+0x30], xmm3
00007942783db3ec  vmovaps [rsp+0x40], xmm4
00007942783db3f2  vmovaps [rsp+0x50], xmm5
00007942783db3f8  vmovaps [rsp+0x60], xmm6
00007942783db3fe  vmovaps [rsp+0x70], xmm7
00007942783db404  vmovaps [rsp+0x80], xmm8
00007942783db40d  vmovaps [rsp+0x90], xmm9
00007942783db416  vmovaps [rsp+0xA0], xmm10
00007942783db41f  vmovaps [rsp+0xB0], xmm11
00007942783db428  vmovaps [rsp+0xC0], xmm12
00007942783db431  vmovaps [rsp+0xD0], xmm13
00007942783db43a  vmovaps [rsp+0xE0], xmm14
00007942783db443  sub rsp, 0x30
00007942783db447  movaps [rsp], xmm15
00007942783db44c  movaps [rsp+0x10], xmm11
00007942783db452  movaps [rsp+0x20], xmm12
00007942783db458  lea rdi, [rsp]
00007942783db45c  mov esi, 0x00
00007942783db461  mov rax, 0x59DDDCBA3530
00007942783db46b  call rax
00007942783db46d  movaps xmm15, [rsp]
00007942783db472  add rsp, 0x30
00007942783db476  vmovaps xmm0, [rsp]
00007942783db47b  vmovaps xmm1, [rsp+0x10]
00007942783db481  vmovaps xmm2, [rsp+0x20]
00007942783db487  vmovaps xmm3, [rsp+0x30]
00007942783db48d  vmovaps xmm4, [rsp+0x40]
00007942783db493  vmovaps xmm5, [rsp+0x50]
00007942783db499  vmovaps xmm6, [rsp+0x60]
00007942783db49f  vmovaps xmm7, [rsp+0x70]
00007942783db4a5  vmovaps xmm8, [rsp+0x80]
00007942783db4ae  vmovaps xmm9, [rsp+0x90]
00007942783db4b7  vmovaps xmm10, [rsp+0xA0]
00007942783db4c0  vmovaps xmm11, [rsp+0xB0]
00007942783db4c9  vmovaps xmm12, [rsp+0xC0]
00007942783db4d2  vmovaps xmm13, [rsp+0xD0]
00007942783db4db  vmovaps xmm14, [rsp+0xE0]
00007942783db4e4  add rsp, 0xF0
00007942783db4eb  pop r11
00007942783db4ed  pop r10
00007942783db4ef  pop r9
00007942783db4f1  pop r8
00007942783db4f3  pop rsi
00007942783db4f4  pop rdi
00007942783db4f5  pop rdx
00007942783db4f6  pop rcx
00007942783db4f7  pop rax
00007942783db4f8  add rsp, 0x08
00007942783db4fc  jmp 0x00007942783D664A
00007942783db501  sub rsp, 0x08
00007942783db505  push rax
00007942783db506  push rcx
00007942783db507  push rdx
00007942783db508  push rdi
00007942783db509  push rsi
00007942783db50a  push r8
00007942783db50c  push r9
00007942783db50e  push r10
00007942783db510  push r11
00007942783db512  sub rsp, 0xF0
00007942783db519  vmovaps [rsp], xmm0
00007942783db51e  vmovaps [rsp+0x10], xmm1
00007942783db524  vmovaps [rsp+0x20], xmm2
00007942783db52a  vmovaps [rsp+0x30], xmm3
00007942783db530  vmovaps [rsp+0x40], xmm4
00007942783db536  vmovaps [rsp+0x50], xmm5
00007942783db53c  vmovaps [rsp+0x60], xmm6
00007942783db542  vmovaps [rsp+0x70], xmm7
00007942783db548  vmovaps [rsp+0x80], xmm8
00007942783db551  vmovaps [rsp+0x90], xmm9
00007942783db55a  vmovaps [rsp+0xA0], xmm10
00007942783db563  vmovaps [rsp+0xB0], xmm11
00007942783db56c  vmovaps [rsp+0xC0], xmm12
00007942783db575  vmovaps [rsp+0xD0], xmm14
00007942783db57e  vmovaps [rsp+0xE0], xmm15
00007942783db587  sub rsp, 0x30
00007942783db58b  movaps [rsp], xmm13
00007942783db590  movaps [rsp+0x10], xmm10
00007942783db596  movaps [rsp+0x20], xmm14
00007942783db59c  lea rdi, [rsp]
00007942783db5a0  mov esi, 0x00
00007942783db5a5  mov rax, 0x59DDDCBA3530
00007942783db5af  call rax
00007942783db5b1  movaps xmm13, [rsp]
00007942783db5b6  add rsp, 0x30
00007942783db5ba  vmovaps xmm0, [rsp]
00007942783db5bf  vmovaps xmm1, [rsp+0x10]
00007942783db5c5  vmovaps xmm2, [rsp+0x20]
00007942783db5cb  vmovaps xmm3, [rsp+0x30]
00007942783db5d1  vmovaps xmm4, [rsp+0x40]
00007942783db5d7  vmovaps xmm5, [rsp+0x50]
00007942783db5dd  vmovaps xmm6, [rsp+0x60]
00007942783db5e3  vmovaps xmm7, [rsp+0x70]
00007942783db5e9  vmovaps xmm8, [rsp+0x80]
00007942783db5f2  vmovaps xmm9, [rsp+0x90]
00007942783db5fb  vmovaps xmm10, [rsp+0xA0]
00007942783db604  vmovaps xmm11, [rsp+0xB0]
00007942783db60d  vmovaps xmm12, [rsp+0xC0]
00007942783db616  vmovaps xmm14, [rsp+0xD0]
00007942783db61f  vmovaps xmm15, [rsp+0xE0]
00007942783db628  add rsp, 0xF0
00007942783db62f  pop r11
00007942783db631  pop r10
00007942783db633  pop r9
00007942783db635  pop r8
00007942783db637  pop rsi
00007942783db638  pop rdi
00007942783db639  pop rdx
00007942783db63a  pop rcx
00007942783db63b  pop rax
00007942783db63c  add rsp, 0x08
00007942783db640  jmp 0x00007942783D666D
00007942783db645  sub rsp, 0x08
00007942783db649  push rax
00007942783db64a  push rcx
00007942783db64b  push rdx
00007942783db64c  push rdi
00007942783db64d  push rsi
00007942783db64e  push r8
00007942783db650  push r9
00007942783db652  push r10
00007942783db654  push r11
00007942783db656  sub rsp, 0xF0
00007942783db65d  vmovaps [rsp], xmm0
00007942783db662  vmovaps [rsp+0x10], xmm1
00007942783db668  vmovaps [rsp+0x20], xmm2
00007942783db66e  vmovaps [rsp+0x30], xmm3
00007942783db674  vmovaps [rsp+0x40], xmm4
00007942783db67a  vmovaps [rsp+0x50], xmm5
00007942783db680  vmovaps [rsp+0x60], xmm6
00007942783db686  vmovaps [rsp+0x70], xmm7
00007942783db68c  vmovaps [rsp+0x80], xmm8
00007942783db695  vmovaps [rsp+0x90], xmm9
00007942783db69e  vmovaps [rsp+0xA0], xmm10
00007942783db6a7  vmovaps [rsp+0xB0], xmm11
00007942783db6b0  vmovaps [rsp+0xC0], xmm12
00007942783db6b9  vmovaps [rsp+0xD0], xmm13
00007942783db6c2  vmovaps [rsp+0xE0], xmm15
00007942783db6cb  sub rsp, 0x30
00007942783db6cf  movaps [rsp], xmm14
00007942783db6d4  movaps [rsp+0x10], xmm1
00007942783db6d9  movaps [rsp+0x20], xmm7
00007942783db6de  lea rdi, [rsp]
00007942783db6e2  mov esi, 0x00
00007942783db6e7  mov rax, 0x59DDDCBA3530
00007942783db6f1  call rax
00007942783db6f3  movaps xmm14, [rsp]
00007942783db6f8  add rsp, 0x30
00007942783db6fc  vmovaps xmm0, [rsp]
00007942783db701  vmovaps xmm1, [rsp+0x10]
00007942783db707  vmovaps xmm2, [rsp+0x20]
00007942783db70d  vmovaps xmm3, [rsp+0x30]
00007942783db713  vmovaps xmm4, [rsp+0x40]
00007942783db719  vmovaps xmm5, [rsp+0x50]
00007942783db71f  vmovaps xmm6, [rsp+0x60]
00007942783db725  vmovaps xmm7, [rsp+0x70]
00007942783db72b  vmovaps xmm8, [rsp+0x80]
00007942783db734  vmovaps xmm9, [rsp+0x90]
00007942783db73d  vmovaps xmm10, [rsp+0xA0]
00007942783db746  vmovaps xmm11, [rsp+0xB0]
00007942783db74f  vmovaps xmm12, [rsp+0xC0]
00007942783db758  vmovaps xmm13, [rsp+0xD0]
00007942783db761  vmovaps xmm15, [rsp+0xE0]
00007942783db76a  add rsp, 0xF0
00007942783db771  pop r11
00007942783db773  pop r10
00007942783db775  pop r9
00007942783db777  pop r8
00007942783db779  pop rsi
00007942783db77a  pop rdi
00007942783db77b  pop rdx
00007942783db77c  pop rcx
00007942783db77d  pop rax
00007942783db77e  add rsp, 0x08
00007942783db782  jmp 0x00007942783D6690
00007942783db787  sub rsp, 0x08
00007942783db78b  push rax
00007942783db78c  push rcx
00007942783db78d  push rdx
00007942783db78e  push rdi
00007942783db78f  push rsi
00007942783db790  push r8
00007942783db792  push r9
00007942783db794  push r10
00007942783db796  push r11
00007942783db798  sub rsp, 0xF0
00007942783db79f  vmovaps [rsp], xmm0
00007942783db7a4  vmovaps [rsp+0x10], xmm2
00007942783db7aa  vmovaps [rsp+0x20], xmm3
00007942783db7b0  vmovaps [rsp+0x30], xmm4
00007942783db7b6  vmovaps [rsp+0x40], xmm5
00007942783db7bc  vmovaps [rsp+0x50], xmm6
00007942783db7c2  vmovaps [rsp+0x60], xmm7
00007942783db7c8  vmovaps [rsp+0x70], xmm8
00007942783db7ce  vmovaps [rsp+0x80], xmm9
00007942783db7d7  vmovaps [rsp+0x90], xmm10
00007942783db7e0  vmovaps [rsp+0xA0], xmm11
00007942783db7e9  vmovaps [rsp+0xB0], xmm12
00007942783db7f2  vmovaps [rsp+0xC0], xmm13
00007942783db7fb  vmovaps [rsp+0xD0], xmm14
00007942783db804  vmovaps [rsp+0xE0], xmm15
00007942783db80d  sub rsp, 0x30
00007942783db811  movaps [rsp], xmm1
00007942783db815  movaps [rsp+0x10], xmm8
00007942783db81b  movaps [rsp+0x20], xmm9
00007942783db821  lea rdi, [rsp]
00007942783db825  mov esi, 0x00
00007942783db82a  mov rax, 0x59DDDCBA3530
00007942783db834  call rax
00007942783db836  movaps xmm1, [rsp]
00007942783db83a  add rsp, 0x30
00007942783db83e  vmovaps xmm0, [rsp]
00007942783db843  vmovaps xmm2, [rsp+0x10]
00007942783db849  vmovaps xmm3, [rsp+0x20]
00007942783db84f  vmovaps xmm4, [rsp+0x30]
00007942783db855  vmovaps xmm5, [rsp+0x40]
00007942783db85b  vmovaps xmm6, [rsp+0x50]
00007942783db861  vmovaps xmm7, [rsp+0x60]
00007942783db867  vmovaps xmm8, [rsp+0x70]
00007942783db86d  vmovaps xmm9, [rsp+0x80]
00007942783db876  vmovaps xmm10, [rsp+0x90]
00007942783db87f  vmovaps xmm11, [rsp+0xA0]
00007942783db888  vmovaps xmm12, [rsp+0xB0]
00007942783db891  vmovaps xmm13, [rsp+0xC0]
00007942783db89a  vmovaps xmm14, [rsp+0xD0]
00007942783db8a3  vmovaps xmm15, [rsp+0xE0]
00007942783db8ac  add rsp, 0xF0
00007942783db8b3  pop r11
00007942783db8b5  pop r10
00007942783db8b7  pop r9
00007942783db8b9  pop r8
00007942783db8bb  pop rsi
00007942783db8bc  pop rdi
00007942783db8bd  pop rdx
00007942783db8be  pop rcx
00007942783db8bf  pop rax
00007942783db8c0  add rsp, 0x08
00007942783db8c4  jmp 0x00007942783D66B2
00007942783db8c9  call 0x00007942782B3E40
00007942783db8ce  jmp 0x00007942783D66C0
00007942783db8d3  call 0x000079427820C380
00007942783db8d8  jmp 0x00007942783D66CA
00007942783db8dd  call 0x000079427820D600
00007942783db8e2  jmp 0x00007942783D66D4
00007942783db8e7  call 0x00007942781FF540
00007942783db8ec  jmp 0x00007942783D66DE
00007942783db8f1  int3
00007942783db8f2  nop [rax+rax*1], ax
00007942783db8fb  nop [rax+rax*1], eax
00007942783db900  mov eax, [r15+0x48]
00007942783db904  lea r14d, [eax+0x01]
00007942783db909  mov [rsp+0x10], r14d
00007942783db90e  mov r14d, r14d
00007942783db911  mov [r15+0x48], r14
00007942783db915  xor eax, eax
00007942783db917  mov r14d, [rsp+0x10]
00007942783db91c  cmp r14d, 0x1F4
00007942783db923  cmc
00007942783db924  lahf
00007942783db925  seto al
00007942783db928  mov [r15+0x108], eax
00007942783db92f  mov eax, [r15+0x108]
00007942783db936  sahf
00007942783db937  jnz 0x00007942783DB969
00007942783db939  cmp dword ptr [r15+0x318], 0x00
00007942783db941  jz 0x00007942783E1AB0
00007942783db947  nop [rax+rax*1], ax
00007942783db950  nop [rax+rax*1], eax
00007942783db958  mov eax, 0x410450
00007942783db95d  mov [r15+0x100], rax
00007942783db964  jmp 0x00007942781FE110
00007942783db969  cmp dword ptr [r15+0x318], 0x00
00007942783db971  jz 0x00007942783DB9A0
00007942783db977  nop [rax+rax*1], ax
00007942783db980  nop [rax+rax*1], eax
00007942783db988  mov eax, 0x410274
00007942783db98d  mov [r15+0x100], rax
00007942783db994  jmp 0x00007942781FE110
00007942783db999  int3
00007942783db99a  int3
00007942783db99b  nop [rax+rax*1], eax
00007942783db9a0  mov rax, [r15+0x40]
00007942783db9a4  movaps xmm1, [r15+0x1D0]
00007942783db9ac  vmovaps [rsp+0x10], xmm1
00007942783db9b2  vmovaps xmm15, [rsp+0x10]
00007942783db9b8  por xmm1, xmm15
00007942783db9bd  movaps xmm14, [r15+0x1A0]
00007942783db9c5  vmovaps [rsp+0x10], xmm14
00007942783db9cb  vmovaps xmm13, [rsp+0x10]
00007942783db9d1  por xmm14, xmm13
00007942783db9d6  lea r14, [rax+0x30]
00007942783db9da  mov r12, [r13+r14*1]
00007942783db9df  lea r14, [rax+0x38]
00007942783db9e3  mov r11, [r13+r14*1]
00007942783db9e8  movq xmm13, r12
00007942783db9ed  movq xmm12, r11
00007942783db9f2  movq xmm13, xmm13
00007942783db9f7  vmovaps [rsp+0x10], xmm13
00007942783db9fd  movq xmm13, xmm13
00007942783dba02  movaps [r15+0x130], xmm13
00007942783dba0a  movq xmm12, xmm12
00007942783dba0f  vmovaps [rsp+0x20], xmm12
00007942783dba15  movq xmm12, xmm12
00007942783dba1a  movaps [r15+0x280], xmm12
00007942783dba22  movaps xmm13, [r15+0x270]
00007942783dba2a  vmovaps [rsp+0x30], xmm13
00007942783dba30  vmovaps xmm12, [rsp+0x30]
00007942783dba36  por xmm13, xmm12
00007942783dba3b  lea r14, [rax+0x20]
00007942783dba3f  mov r12, [r13+r14*1]
00007942783dba44  lea r14, [rax+0x28]
00007942783dba48  mov r11, [r13+r14*1]
00007942783dba4d  movq xmm12, r12
00007942783dba52  movq xmm11, r11
00007942783dba57  movq xmm12, xmm12
00007942783dba5c  vmovaps [rsp+0x30], xmm12
00007942783dba62  movq xmm12, xmm12
00007942783dba67  movaps [r15+0x150], xmm12
00007942783dba6f  movq xmm11, xmm11
00007942783dba74  vmovaps [rsp+0x40], xmm11
00007942783dba7a  movq xmm11, xmm11
00007942783dba7f  movaps [r15+0x140], xmm11
00007942783dba87  lea r14, [rax+0x10]
00007942783dba8b  mov r12, [r13+r14*1]
00007942783dba90  lea r14, [rax+0x18]
00007942783dba94  mov r11, [r13+r14*1]
00007942783dba99  movq xmm12, r12
00007942783dba9e  movq xmm11, r11
00007942783dbaa3  movq xmm12, xmm12
00007942783dbaa8  vmovaps [rsp+0x50], xmm12
00007942783dbaae  movq xmm12, xmm12
00007942783dbab3  movaps [r15+0x170], xmm12
00007942783dbabb  movq xmm11, xmm11
00007942783dbac0  vmovaps [rsp+0x60], xmm11
00007942783dbac6  movq xmm11, xmm11
00007942783dbacb  movaps [r15+0x160], xmm11
00007942783dbad3  mov r14, [r13+rax*1]
00007942783dbad8  vmovq xmm12, r14
00007942783dbadd  vpbroadcastq xmm12, xmm12
00007942783dbae2  lea r14, [rax+0x08]
00007942783dbae6  mov rax, [r13+r14*1]
00007942783dbaeb  movq xmm11, rax
00007942783dbaf0  movaps [r15+0x230], xmm11
00007942783dbaf8  mov rax, [r15+0xF8]
00007942783dbaff  lea r14, [rax+0x50]
00007942783dbb03  movups xmm11, [r13+r14*1]
00007942783dbb09  lea r14, [rax+0x60]
00007942783dbb0d  movups xmm10, [r13+r14*1]
00007942783dbb13  lea r14, [rax+0x30]
00007942783dbb17  movups xmm9, [r13+r14*1]
00007942783dbb1d  mov r14, [r15+0x50]
00007942783dbb21  mov [r15+0x60], r14
00007942783dbb25  mov qword ptr [r15+0x58], 0x40
00007942783dbb2d  movaps xmm8, xmm12
00007942783dbb31  mulpd xmm8, xmm15
00007942783dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007942783dbb3c  ptest xmm7, xmm7
00007942783dbb41  jnz 0x00007942783DC96A
00007942783dbb47  movq xmm15, qword ptr [r15+0x230]
00007942783dbb50  vmovaps [rsp+0x70], xmm15
00007942783dbb56  vpermilpd xmm15, xmm15, 0x00
00007942783dbb5c  movaps xmm7, xmm9
00007942783dbb60  mulpd xmm7, xmm15
00007942783dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007942783dbb6a  ptest xmm6, xmm6
00007942783dbb6f  jnz 0x00007942783DCAAE
00007942783dbb75  vxorps xmm15, xmm15, xmm15
00007942783dbb7a  vpbroadcastq xmm15, xmm15
00007942783dbb7f  movaps xmm9, xmm12
00007942783dbb83  mulpd xmm9, xmm10
00007942783dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007942783dbb8e  ptest xmm6, xmm6
00007942783dbb93  jnz 0x00007942783DCBF0
00007942783dbb99  movaps xmm10, xmm12
00007942783dbb9d  mulpd xmm10, xmm11
00007942783dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007942783dbba8  ptest xmm6, xmm6
00007942783dbbad  jnz 0x00007942783DCD34
00007942783dbbb3  movaps xmm11, [r15+0x1F0]
00007942783dbbbb  movaps xmm6, xmm12
00007942783dbbbf  mulpd xmm6, xmm11
00007942783dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007942783dbbc9  ptest xmm5, xmm5
00007942783dbbce  jnz 0x00007942783DCE78
00007942783dbbd4  movaps xmm12, [r15+0x2A0]
00007942783dbbdc  vmovaps [rsp+0x80], xmm12
00007942783dbbe5  vmovaps xmm11, [rsp+0x80]
00007942783dbbee  por xmm12, xmm11
00007942783dbbf3  movaps xmm11, [r15+0x250]
00007942783dbbfb  vmovaps [rsp+0x80], xmm11
00007942783dbc04  vmovaps xmm5, [rsp+0x80]
00007942783dbc0d  por xmm11, xmm5
00007942783dbc12  vmovaps xmm4, [rsp+0x70]
00007942783dbc18  vpermilpd xmm4, xmm4, 0x00
00007942783dbc1e  movaps xmm3, xmm5
00007942783dbc21  mulpd xmm3, xmm4
00007942783dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007942783dbc2a  ptest xmm2, xmm2
00007942783dbc2f  jnz 0x00007942783DCFBA
00007942783dbc35  mov [rsp+0x80], rax
00007942783dbc3d  xor eax, eax
00007942783dbc3f  mov r12d, 0x40
00007942783dbc45  mov r11d, 0x200
00007942783dbc4b  cmp r12, r11
00007942783dbc4e  cmc
00007942783dbc4f  lahf
00007942783dbc50  seto al
00007942783dbc53  mov [r15+0x108], eax
00007942783dbc5a  movaps xmm5, xmm8
00007942783dbc5e  addpd xmm5, xmm15
00007942783dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007942783dbc68  ptest xmm4, xmm4
00007942783dbc6d  jnz 0x00007942783DD0FA
00007942783dbc73  movaps xmm8, [r15+0x1B0]
00007942783dbc7b  movaps xmm4, xmm9
00007942783dbc7f  addpd xmm4, xmm8
00007942783dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007942783dbc89  ptest xmm2, xmm2
00007942783dbc8e  jnz 0x00007942783DD23C
00007942783dbc94  movaps xmm9, xmm10
00007942783dbc98  addpd xmm9, xmm8
00007942783dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007942783dbca3  ptest xmm2, xmm2
00007942783dbca8  jnz 0x00007942783DD37E
00007942783dbcae  movaps xmm10, [r15+0x2F0]
00007942783dbcb6  vmovaps [rsp+0x90], xmm10
00007942783dbcbf  vmovaps xmm8, [rsp+0x90]
00007942783dbcc8  por xmm10, xmm8
00007942783dbccd  movaps xmm8, [r15+0x2E0]
00007942783dbcd5  vmovaps [rsp+0x90], xmm8
00007942783dbcde  vmovaps xmm2, [rsp+0x90]
00007942783dbce7  por xmm8, xmm2
00007942783dbcec  movaps xmm2, [r15+0x2D0]
00007942783dbcf4  vmovaps [rsp+0x90], xmm2
00007942783dbcfd  vmovaps [rsp+0xA0], xmm1
00007942783dbd06  vmovaps xmm1, [rsp+0x90]
00007942783dbd0f  por xmm2, xmm1
00007942783dbd13  movaps xmm1, [r15+0x200]
00007942783dbd1b  vmovaps [rsp+0x90], xmm1
00007942783dbd24  vmovaps [rsp+0xB0], xmm15
00007942783dbd2d  vmovaps xmm15, [rsp+0x90]
00007942783dbd36  por xmm1, xmm15
00007942783dbd3b  movaps xmm15, [r15+0x1C0]
00007942783dbd43  vmovaps [rsp+0x90], xmm15
00007942783dbd4c  vmovaps [rsp+0xC0], xmm1
00007942783dbd55  vmovaps xmm1, [rsp+0x90]
00007942783dbd5e  por xmm15, xmm1
00007942783dbd63  movaps xmm1, [r15+0x190]
00007942783dbd6b  vmovaps [rsp+0x90], xmm1
00007942783dbd74  vmovaps [rsp+0xD0], xmm15
00007942783dbd7d  vmovaps xmm15, [rsp+0x90]
00007942783dbd86  por xmm1, xmm15
00007942783dbd8b  movaps xmm15, [r15+0x300]
00007942783dbd93  vmovaps [rsp+0x90], xmm15
00007942783dbd9c  vmovaps [rsp+0xE0], xmm1
00007942783dbda5  vmovaps xmm1, [rsp+0x90]
00007942783dbdae  por xmm15, xmm1
00007942783dbdb3  mov rax, [rsp+0x80]
00007942783dbdbb  lea r12, [rax+0xA0]
00007942783dbdc2  movups xmm1, [r13+r12*1]
00007942783dbdc8  lea r12, [rax+0xB0]
00007942783dbdcf  vmovaps [rsp+0x80], xmm1
00007942783dbdd8  movups xmm1, [r13+r12*1]
00007942783dbdde  vmovaps [rsp+0x90], xmm1
00007942783dbde7  vmovaps [rsp+0xF0], xmm15
00007942783dbdf0  vmovaps xmm15, [rsp+0xB0]
00007942783dbdf9  vmovaps [rsp+0xB0], xmm14
00007942783dbe02  movaps xmm1, xmm6
00007942783dbe05  addpd xmm1, xmm15
00007942783dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007942783dbe0f  ptest xmm14, xmm14
00007942783dbe15  jnz 0x00007942783DD4D6
00007942783dbe1b  lea r12, [rax+0xF0]
00007942783dbe22  movups xmm15, [r13+r12*1]
00007942783dbe28  movaps xmm14, xmm4
00007942783dbe2c  addpd xmm14, xmm3
00007942783dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007942783dbe37  ptest xmm6, xmm6
00007942783dbe3c  jnz 0x00007942783DD621
00007942783dbe42  movaps xmm6, xmm9
00007942783dbe46  addpd xmm6, xmm7
00007942783dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007942783dbe4f  ptest xmm4, xmm4
00007942783dbe54  jnz 0x00007942783DD763
00007942783dbe5a  vmovaps xmm9, [rsp+0x70]
00007942783dbe60  vpermilpd xmm9, xmm9, 0x00
00007942783dbe66  vmovaps xmm4, [rsp+0x90]
00007942783dbe6f  movaps xmm7, xmm4
00007942783dbe72  mulpd xmm7, xmm9
00007942783dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007942783dbe7c  ptest xmm3, xmm3
00007942783dbe81  jnz 0x00007942783DD8A4
00007942783dbe87  vmovaps xmm9, [rsp+0x50]
00007942783dbe8d  vpermilpd xmm9, xmm9, 0x00
00007942783dbe93  movaps xmm4, xmm15
00007942783dbe97  mulpd xmm4, xmm9
00007942783dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007942783dbea1  ptest xmm3, xmm3
00007942783dbea6  jnz 0x00007942783DD9E5
00007942783dbeac  lea r12, [rax+0xE0]
00007942783dbeb3  movups xmm15, [r13+r12*1]
00007942783dbeb9  vmovaps xmm9, [rsp+0x70]
00007942783dbebf  vpermilpd xmm9, xmm9, 0x00
00007942783dbec5  vmovaps [rsp+0x70], xmm1
00007942783dbecb  vmovaps xmm1, [rsp+0x80]
00007942783dbed4  vmovaps [rsp+0x80], xmm15
00007942783dbedd  movaps xmm3, xmm1
00007942783dbee0  mulpd xmm3, xmm9
00007942783dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007942783dbeea  ptest xmm15, xmm15
00007942783dbef0  jnz 0x00007942783DDB31
00007942783dbef6  vmovaps xmm1, [rsp+0xF0]
00007942783dbeff  vmovaps xmm15, [rsp+0xF0]
00007942783dbf08  por xmm1, xmm15
00007942783dbf0d  movaps [r15+0x300], xmm1
00007942783dbf15  vmovaps xmm15, [rsp+0xE0]
00007942783dbf1e  vmovaps xmm9, [rsp+0xE0]
00007942783dbf27  por xmm15, xmm9
00007942783dbf2c  movaps [r15+0x190], xmm15
00007942783dbf34  vmovaps xmm9, [rsp+0x50]
00007942783dbf3a  vpermilpd xmm9, xmm9, 0x00
00007942783dbf40  vmovaps [rsp+0x90], xmm1
00007942783dbf49  vmovaps [rsp+0xE0], xmm15
00007942783dbf52  vmovaps xmm15, [rsp+0x80]
00007942783dbf5b  vmovaps [rsp+0x80], xmm14
00007942783dbf64  movaps xmm1, xmm15
00007942783dbf68  mulpd xmm1, xmm9
00007942783dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007942783dbf72  ptest xmm14, xmm14
00007942783dbf78  jnz 0x00007942783DDC72
00007942783dbf7e  lea r12, [rax+0x90]
00007942783dbf85  movups xmm15, [r13+r12*1]
00007942783dbf8b  vmovaps xmm14, [rsp+0xD0]
00007942783dbf94  vmovaps xmm9, [rsp+0xD0]
00007942783dbf9d  por xmm14, xmm9
00007942783dbfa2  movaps [r15+0x1C0], xmm14
00007942783dbfaa  vmovaps xmm9, [rsp+0xC0]
00007942783dbfb3  vmovaps [rsp+0xD0], xmm1
00007942783dbfbc  vmovaps xmm1, [rsp+0xC0]
00007942783dbfc5  por xmm9, xmm1
00007942783dbfca  movaps [r15+0x200], xmm9
00007942783dbfd2  vmovaps [rsp+0xC0], xmm2
00007942783dbfdb  vmovaps xmm1, [rsp+0xC0]
00007942783dbfe4  por xmm2, xmm1
00007942783dbfe8  movaps [r15+0x2D0], xmm2
00007942783dbff0  vmovaps [rsp+0xC0], xmm8
00007942783dbff9  vmovaps xmm1, [rsp+0xC0]
00007942783dc002  por xmm8, xmm1
00007942783dc007  movaps [r15+0x2E0], xmm8
00007942783dc00f  vmovaps [rsp+0xC0], xmm15
00007942783dc018  movaps xmm1, xmm5
00007942783dc01b  addpd xmm1, xmm7
00007942783dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007942783dc024  ptest xmm15, xmm15
00007942783dc02a  jnz 0x00007942783DDDBE
00007942783dc030  vmovaps xmm15, [rsp+0x50]
00007942783dc036  vpermilpd xmm15, xmm15, 0x00
00007942783dc03c  vmovaps xmm5, [rsp+0xC0]
00007942783dc045  vmovaps [rsp+0xC0], xmm1
00007942783dc04e  movaps xmm7, xmm5
00007942783dc051  mulpd xmm7, xmm15
00007942783dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007942783dc05b  ptest xmm1, xmm1
00007942783dc060  jnz 0x00007942783DDEFE
00007942783dc066  lea r12, [rax+0x80]
00007942783dc06d  movups xmm1, [r13+r12*1]
00007942783dc073  vmovaps xmm5, [rsp+0x70]
00007942783dc079  vmovaps [rsp+0x70], xmm1
00007942783dc07f  movaps xmm15, xmm5
00007942783dc083  addpd xmm15, xmm3
00007942783dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007942783dc08e  ptest xmm1, xmm1
00007942783dc093  jnz 0x00007942783DE049
00007942783dc099  vmovaps xmm5, [rsp+0x80]
00007942783dc0a2  movaps xmm1, xmm5
00007942783dc0a5  addpd xmm1, xmm4
00007942783dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007942783dc0ae  ptest xmm3, xmm3
00007942783dc0b3  jnz 0x00007942783DE18B
00007942783dc0b9  vmovaps [rsp+0x80], xmm10
00007942783dc0c2  vmovaps xmm5, [rsp+0x80]
00007942783dc0cb  por xmm10, xmm5
00007942783dc0d0  movaps [r15+0x2F0], xmm10
00007942783dc0d8  vmovaps xmm5, [rsp+0x50]
00007942783dc0de  vpermilpd xmm5, xmm5, 0x00
00007942783dc0e4  vmovaps xmm3, [rsp+0x70]
00007942783dc0ea  vmovaps [rsp+0x50], xmm1
00007942783dc0f0  movaps xmm4, xmm3
00007942783dc0f3  mulpd xmm4, xmm5
00007942783dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007942783dc0fc  ptest xmm1, xmm1
00007942783dc101  jnz 0x00007942783DE2CB
00007942783dc107  lea r12, [rax+0xD0]
00007942783dc10e  movups xmm1, [r13+r12*1]
00007942783dc114  vmovaps xmm3, [rsp+0xD0]
00007942783dc11d  vmovaps [rsp+0x70], xmm1
00007942783dc123  movaps xmm5, xmm6
00007942783dc126  addpd xmm5, xmm3
00007942783dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007942783dc12f  ptest xmm1, xmm1
00007942783dc134  jnz 0x00007942783DE415
00007942783dc13a  vmovaps xmm1, [rsp+0x60]
00007942783dc140  vpermilpd xmm1, xmm1, 0x00
00007942783dc146  movaps xmm6, xmm9
00007942783dc14a  mulpd xmm6, xmm1
00007942783dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007942783dc153  ptest xmm3, xmm3
00007942783dc158  jnz 0x00007942783DE555
00007942783dc15e  movaps [r15+0x260], xmm6
00007942783dc166  vxorps xmm1, xmm1, xmm1
00007942783dc16a  vpbroadcastq xmm1, xmm1
00007942783dc16f  movaps [r15+0x1B0], xmm1
00007942783dc177  vmovaps xmm1, [rsp+0x60]
00007942783dc17d  vpermilpd xmm1, xmm1, 0x00
00007942783dc183  vmovaps xmm3, [rsp+0x70]
00007942783dc189  vmovaps [rsp+0x70], xmm15
00007942783dc18f  movaps xmm9, xmm3
00007942783dc193  mulpd xmm9, xmm1
00007942783dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007942783dc19e  ptest xmm15, xmm15
00007942783dc1a4  jnz 0x00007942783DE696
00007942783dc1aa  lea r12, [rax+0xC0]
00007942783dc1b1  movups xmm1, [r13+r12*1]
00007942783dc1b7  vmovaps xmm3, [rsp+0xC0]
00007942783dc1c0  vmovaps [rsp+0x80], xmm1
00007942783dc1c9  movaps xmm15, xmm3
00007942783dc1cd  addpd xmm15, xmm7
00007942783dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007942783dc1d8  ptest xmm1, xmm1
00007942783dc1dd  jnz 0x00007942783DE7E2
00007942783dc1e3  vmovaps [rsp+0xC0], xmm13
00007942783dc1ec  vmovaps xmm1, [rsp+0xC0]
00007942783dc1f5  por xmm13, xmm1
00007942783dc1fa  movaps [r15+0x270], xmm13
00007942783dc202  vmovaps xmm1, [rsp+0xB0]
00007942783dc20b  vmovaps xmm7, [rsp+0xB0]
00007942783dc214  por xmm1, xmm7
00007942783dc218  movaps [r15+0x1A0], xmm1
00007942783dc220  vmovaps xmm1, [rsp+0x60]
00007942783dc226  vpermilpd xmm1, xmm1, 0x00
00007942783dc22c  vmovaps [rsp+0xB0], xmm1
00007942783dc235  vmovaps xmm1, [rsp+0x80]
00007942783dc23e  vmovaps [rsp+0x80], xmm15
00007942783dc247  vmovaps xmm15, [rsp+0xB0]
00007942783dc250  vmovaps [rsp+0xB0], xmm14
00007942783dc259  movaps xmm3, xmm1
00007942783dc25c  mulpd xmm3, xmm15
00007942783dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007942783dc266  ptest xmm14, xmm14
00007942783dc26c  jnz 0x00007942783DE924
00007942783dc272  lea r12, [rax+0x20]
00007942783dc276  movups xmm1, [r13+r12*1]
00007942783dc27c  movaps [r15+0x110], xmm1
00007942783dc284  vmovaps xmm14, [rsp+0x70]
00007942783dc28a  vmovaps [rsp+0x70], xmm1
00007942783dc290  movaps xmm15, xmm14
00007942783dc294  addpd xmm15, xmm4
00007942783dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007942783dc29f  ptest xmm1, xmm1
00007942783dc2a4  jnz 0x00007942783DEA6F
00007942783dc2aa  vmovaps xmm1, [rsp+0x60]
00007942783dc2b0  vpermilpd xmm1, xmm1, 0x00
00007942783dc2b6  movaps xmm14, xmm2
00007942783dc2ba  mulpd xmm14, xmm1
00007942783dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007942783dc2c5  ptest xmm4, xmm4
00007942783dc2ca  jnz 0x00007942783DEBB2
00007942783dc2d0  vmovaps xmm4, [rsp+0x50]
00007942783dc2d6  movaps xmm1, xmm4
00007942783dc2d9  addpd xmm1, xmm9
00007942783dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007942783dc2e3  ptest xmm2, xmm2
00007942783dc2e8  jnz 0x00007942783DECF4
00007942783dc2ee  vmovaps xmm9, [rsp+0x30]
00007942783dc2f4  vpermilpd xmm9, xmm9, 0x00
00007942783dc2fa  vmovaps xmm2, [rsp+0x70]
00007942783dc300  vmovaps [rsp+0x50], xmm1
00007942783dc306  movaps xmm4, xmm2
00007942783dc309  mulpd xmm4, xmm9
00007942783dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007942783dc313  ptest xmm1, xmm1
00007942783dc318  jnz 0x00007942783DEE35
00007942783dc31e  vmovaps xmm1, [rsp+0x30]
00007942783dc324  vpermilpd xmm1, xmm1, 0x00
00007942783dc32a  vmovaps xmm2, [rsp+0x90]
00007942783dc333  vmovaps [rsp+0x60], xmm15
00007942783dc339  movaps xmm9, xmm2
00007942783dc33d  mulpd xmm9, xmm1
00007942783dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007942783dc348  ptest xmm15, xmm15
00007942783dc34e  jnz 0x00007942783DEF76
00007942783dc354  vmovaps xmm15, [rsp+0x80]
00007942783dc35d  movaps xmm1, xmm15
00007942783dc361  addpd xmm1, xmm6
00007942783dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007942783dc36a  ptest xmm2, xmm2
00007942783dc36f  jnz 0x00007942783DF0B8
00007942783dc375  movaps xmm15, xmm5
00007942783dc379  addpd xmm15, xmm3
00007942783dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007942783dc384  ptest xmm6, xmm6
00007942783dc389  jnz 0x00007942783DF1F9
00007942783dc38f  vmovaps xmm6, [rsp+0x30]
00007942783dc395  vpermilpd xmm6, xmm6, 0x00
00007942783dc39b  movaps xmm5, xmm8
00007942783dc39f  mulpd xmm5, xmm6
00007942783dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007942783dc3a8  ptest xmm3, xmm3
00007942783dc3ad  jnz 0x00007942783DF33B
00007942783dc3b3  vmovaps xmm8, [rsp+0x30]
00007942783dc3b9  vpermilpd xmm8, xmm8, 0x00
00007942783dc3bf  movaps xmm6, xmm10
00007942783dc3c3  mulpd xmm6, xmm8
00007942783dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007942783dc3cd  ptest xmm3, xmm3
00007942783dc3d2  jnz 0x00007942783DF47C
00007942783dc3d8  vmovaps xmm8, [rsp+0x60]
00007942783dc3de  movaps xmm10, xmm8
00007942783dc3e2  addpd xmm10, xmm14
00007942783dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007942783dc3ed  ptest xmm3, xmm3
00007942783dc3f2  jnz 0x00007942783DF5BE
00007942783dc3f8  vmovaps xmm8, [rsp+0x50]
00007942783dc3fe  movaps xmm14, xmm8
00007942783dc402  addpd xmm14, xmm4
00007942783dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007942783dc40d  ptest xmm3, xmm3
00007942783dc412  jnz 0x00007942783DF702
00007942783dc418  vmovaps xmm8, [rsp+0x40]
00007942783dc41e  vpermilpd xmm8, xmm8, 0x00
00007942783dc424  movaps xmm4, xmm13
00007942783dc428  mulpd xmm4, xmm8
00007942783dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007942783dc432  ptest xmm3, xmm3
00007942783dc437  jnz 0x00007942783DF845
00007942783dc43d  movaps xmm13, xmm15
00007942783dc441  addpd xmm13, xmm9
00007942783dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007942783dc44c  ptest xmm8, xmm8
00007942783dc452  jnz 0x00007942783DF987
00007942783dc458  movaps xmm15, xmm1
00007942783dc45c  addpd xmm15, xmm5
00007942783dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007942783dc467  ptest xmm9, xmm9
00007942783dc46d  jnz 0x00007942783DFACB
00007942783dc473  vmovaps [rsp+0x30], xmm11
00007942783dc479  vmovaps xmm1, [rsp+0x30]
00007942783dc47f  por xmm11, xmm1
00007942783dc484  movaps [r15+0x250], xmm11
00007942783dc48c  vmovaps [rsp+0x30], xmm12
00007942783dc492  vmovaps xmm1, [rsp+0x30]
00007942783dc498  por xmm12, xmm1
00007942783dc49d  movaps [r15+0x2A0], xmm12
00007942783dc4a5  vmovaps xmm1, [rsp+0xA0]
00007942783dc4ae  vmovaps xmm11, [rsp+0xA0]
00007942783dc4b7  por xmm1, xmm11
00007942783dc4bc  movaps [r15+0x1D0], xmm1
00007942783dc4c4  lea r12, [rax+0x40]
00007942783dc4c8  movups xmm1, [r13+r12*1]
00007942783dc4ce  movaps [r15+0x2C0], xmm1
00007942783dc4d6  vmovaps xmm11, [rsp+0x40]
00007942783dc4dc  vpermilpd xmm11, xmm11, 0x00
00007942783dc4e2  vmovaps xmm8, [rsp+0xE0]
00007942783dc4eb  movaps xmm9, xmm8
00007942783dc4ef  mulpd xmm9, xmm11
00007942783dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007942783dc4fa  ptest xmm5, xmm5
00007942783dc4ff  jnz 0x00007942783DFC17
00007942783dc505  movaps xmm11, xmm10
00007942783dc509  addpd xmm11, xmm6
00007942783dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007942783dc514  ptest xmm8, xmm8
00007942783dc51a  jnz 0x00007942783DFD5B
00007942783dc520  movaps xmm10, xmm14
00007942783dc524  addpd xmm10, xmm4
00007942783dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007942783dc52f  ptest xmm8, xmm8
00007942783dc535  jnz 0x00007942783DFE9E
00007942783dc53b  vmovaps xmm14, [rsp+0x40]
00007942783dc541  vpermilpd xmm14, xmm14, 0x00
00007942783dc547  movaps xmm8, xmm1
00007942783dc54b  mulpd xmm8, xmm14
00007942783dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007942783dc556  ptest xmm6, xmm6
00007942783dc55b  jnz 0x00007942783DFFE1
00007942783dc561  movaps xmm1, [r15+0x2B0]
00007942783dc569  vmovaps xmm14, [rsp+0x40]
00007942783dc56f  vpermilpd xmm14, xmm14, 0x00
00007942783dc575  movaps xmm6, xmm1
00007942783dc578  mulpd xmm6, xmm14
00007942783dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007942783dc582  ptest xmm5, xmm5
00007942783dc587  jnz 0x00007942783E0124
00007942783dc58d  vmovaps xmm1, [rsp+0x10]
00007942783dc593  vpermilpd xmm1, xmm1, 0x00
00007942783dc599  movaps xmm14, xmm12
00007942783dc59d  mulpd xmm14, xmm1
00007942783dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007942783dc5a8  ptest xmm5, xmm5
00007942783dc5ad  jnz 0x00007942783E0265
00007942783dc5b3  movaps xmm1, xmm13
00007942783dc5b7  addpd xmm1, xmm9
00007942783dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007942783dc5c1  ptest xmm12, xmm12
00007942783dc5c7  jnz 0x00007942783E03A8
00007942783dc5cd  vmovaps xmm13, [rsp+0x10]
00007942783dc5d3  vpermilpd xmm13, xmm13, 0x00
00007942783dc5d9  movaps xmm12, xmm7
00007942783dc5dd  mulpd xmm12, xmm13
00007942783dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007942783dc5e8  ptest xmm9, xmm9
00007942783dc5ee  jnz 0x00007942783E04EA
00007942783dc5f4  movaps xmm13, xmm15
00007942783dc5f8  addpd xmm13, xmm8
00007942783dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007942783dc603  ptest xmm9, xmm9
00007942783dc609  jnz 0x00007942783E062D
00007942783dc60f  movaps xmm15, [r15+0x290]
00007942783dc617  vmovaps xmm9, [rsp+0x10]
00007942783dc61d  vpermilpd xmm9, xmm9, 0x00
00007942783dc623  movaps xmm8, xmm15
00007942783dc627  mulpd xmm8, xmm9
00007942783dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007942783dc632  ptest xmm7, xmm7
00007942783dc637  jnz 0x00007942783E0771
00007942783dc63d  movaps xmm15, xmm11
00007942783dc641  addpd xmm15, xmm6
00007942783dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007942783dc64c  ptest xmm9, xmm9
00007942783dc652  jnz 0x00007942783E08B5
00007942783dc658  movaps xmm11, [r15+0x1E0]
00007942783dc660  vmovaps xmm9, [rsp+0x10]
00007942783dc666  vpermilpd xmm9, xmm9, 0x00
00007942783dc66c  movaps xmm7, xmm11
00007942783dc670  mulpd xmm7, xmm9
00007942783dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007942783dc67a  ptest xmm6, xmm6
00007942783dc67f  jnz 0x00007942783E09F8
00007942783dc685  movaps xmm11, xmm10
00007942783dc689  addpd xmm11, xmm14
00007942783dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007942783dc694  ptest xmm9, xmm9
00007942783dc69a  jnz 0x00007942783E0B3A
00007942783dc6a0  lea r12, [rax+0x70]
00007942783dc6a4  movups xmm14, [r13+r12*1]
00007942783dc6aa  movaps [r15+0x240], xmm14
00007942783dc6b2  movaps xmm10, xmm1
00007942783dc6b6  addpd xmm10, xmm12
00007942783dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007942783dc6c1  ptest xmm9, xmm9
00007942783dc6c7  jnz 0x00007942783E0C88
00007942783dc6cd  movaps [r15+0x170], xmm10
00007942783dc6d5  vmovaps xmm1, [rsp+0x20]
00007942783dc6db  vpermilpd xmm1, xmm1, 0x00
00007942783dc6e1  movaps xmm12, xmm14
00007942783dc6e5  mulpd xmm12, xmm1
00007942783dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007942783dc6f0  ptest xmm9, xmm9
00007942783dc6f6  jnz 0x00007942783E0DCB
00007942783dc6fc  vmovaps xmm1, [rsp+0x20]
00007942783dc702  vpermilpd xmm1, xmm1, 0x00
00007942783dc708  vmovaps xmm9, [rsp+0xB0]
00007942783dc711  movaps xmm14, xmm9
00007942783dc715  mulpd xmm14, xmm1
00007942783dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007942783dc720  ptest xmm6, xmm6
00007942783dc725  jnz 0x00007942783E0F0E
00007942783dc72b  movaps [r15+0x180], xmm14
00007942783dc733  movaps xmm1, xmm13
00007942783dc737  addpd xmm1, xmm8
00007942783dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007942783dc741  ptest xmm9, xmm9
00007942783dc747  jnz 0x00007942783E1051
00007942783dc74d  movaps [r15+0x210], xmm1
00007942783dc755  movups xmm13, [r13+rax*1]
00007942783dc75b  lea r12, [rax+0x10]
00007942783dc75f  movups xmm9, [r13+r12*1]
00007942783dc765  movaps [r15+0x230], xmm9
00007942783dc76d  movaps xmm8, xmm15
00007942783dc771  addpd xmm8, xmm7
00007942783dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007942783dc77c  ptest xmm6, xmm6
00007942783dc781  jnz 0x00007942783E11A7
00007942783dc787  movaps [r15+0x130], xmm8
00007942783dc78f  vmovaps xmm15, [rsp+0x20]
00007942783dc795  vpermilpd xmm15, xmm15, 0x00
00007942783dc79b  movaps xmm7, xmm9
00007942783dc79f  mulpd xmm7, xmm15
00007942783dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007942783dc7a9  ptest xmm6, xmm6
00007942783dc7ae  jnz 0x00007942783E12EA
00007942783dc7b4  movaps [r15+0x220], xmm7
00007942783dc7bc  vmovaps xmm15, [rsp+0x20]
00007942783dc7c2  vpermilpd xmm15, xmm15, 0x00
00007942783dc7c8  movaps xmm9, xmm13
00007942783dc7cc  mulpd xmm9, xmm15
00007942783dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007942783dc7d7  ptest xmm6, xmm6
00007942783dc7dc  jnz 0x00007942783E142C
00007942783dc7e2  movaps xmm15, xmm11
00007942783dc7e6  addpd xmm15, xmm12
00007942783dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007942783dc7f1  ptest xmm13, xmm13
00007942783dc7f7  jnz 0x00007942783E1570
00007942783dc7fd  movaps [r15+0x140], xmm15
00007942783dc805  movaps xmm13, xmm10
00007942783dc809  addpd xmm13, xmm14
00007942783dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007942783dc814  ptest xmm12, xmm12
00007942783dc81a  jnz 0x00007942783E16B4
00007942783dc820  movaps [r15+0x150], xmm13
00007942783dc828  movaps xmm14, xmm1
00007942783dc82c  addpd xmm14, xmm7
00007942783dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007942783dc837  ptest xmm12, xmm12
00007942783dc83d  jnz 0x00007942783E17F8
00007942783dc843  movaps [r15+0x160], xmm14
00007942783dc84b  movaps xmm1, xmm8
00007942783dc84f  addpd xmm1, xmm9
00007942783dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007942783dc859  ptest xmm12, xmm12
00007942783dc85f  jnz 0x00007942783E193A
00007942783dc865  movaps [r15+0x120], xmm1
00007942783dc86d  movups [r13+r14*1], xmm15
00007942783dc873  lea rax, [r14+0x10]
00007942783dc877  movups [r13+rax*1], xmm13
00007942783dc87d  lea rax, [r14+0x20]
00007942783dc881  movups [r13+rax*1], xmm14
00007942783dc887  lea rax, [r14+0x30]
00007942783dc88b  movups [r13+rax*1], xmm1
00007942783dc891  mov eax, [r15+0x108]
00007942783dc898  sahf
00007942783dc899  jnz 0x00007942783DC8CB
00007942783dc89b  cmp dword ptr [r15+0x318], 0x00
00007942783dc8a3  jz 0x00007942783DB900
00007942783dc8a9  nop [rax+rax*1], ax
00007942783dc8b2  nop [rax+rax*1], eax
00007942783dc8ba  mov eax, 0x410444
00007942783dc8bf  mov [r15+0x100], rax
00007942783dc8c6  jmp 0x00007942781FE110
00007942783dc8cb  cmp dword ptr [r15+0x318], 0x00
00007942783dc8d3  jz 0x00007942783D57E0
00007942783dc8d9  nop [rax+rax*1], ax
00007942783dc8e2  nop [rax+rax*1], eax
00007942783dc8ea  mov eax, 0x410278
00007942783dc8ef  mov [r15+0x100], rax
00007942783dc8f6  jmp 0x00007942781FE110
00007942783dc8fb  int3
00007942783dc8fc  call 0x00007942782E27E0
00007942783dc901  jmp 0x00007942783DB9DF
00007942783dc906  call 0x00007942782E1570
00007942783dc90b  jmp 0x00007942783DB9E8
00007942783dc910  call 0x00007942782E27E0
00007942783dc915  jmp 0x00007942783DBA44
00007942783dc91a  call 0x00007942782E1570
00007942783dc91f  jmp 0x00007942783DBA4D
00007942783dc924  call 0x00007942782E27E0
00007942783dc929  jmp 0x00007942783DBA90
00007942783dc92e  call 0x00007942782E1570
00007942783dc933  jmp 0x00007942783DBA99
00007942783dc938  call 0x000079427820DC20
00007942783dc93d  jmp 0x00007942783DBAD8
00007942783dc942  call 0x00007942782D59C0
00007942783dc947  jmp 0x00007942783DBAEB
00007942783dc94c  call 0x00007942782E0E30
00007942783dc951  jmp 0x00007942783DBB09
00007942783dc956  call 0x00007942782DFBC0
00007942783dc95b  jmp 0x00007942783DBB13
00007942783dc960  call 0x00007942782DE950
00007942783dc965  jmp 0x00007942783DBB1D
00007942783dc96a  sub rsp, 0x08
00007942783dc96e  push rax
00007942783dc96f  push rcx
00007942783dc970  push rdx
00007942783dc971  push rdi
00007942783dc972  push rsi
00007942783dc973  push r8
00007942783dc975  push r9
00007942783dc977  push r10
00007942783dc979  push r11
00007942783dc97b  sub rsp, 0xF0
00007942783dc982  vmovaps [rsp], xmm0
00007942783dc987  vmovaps [rsp+0x10], xmm1
00007942783dc98d  vmovaps [rsp+0x20], xmm2
00007942783dc993  vmovaps [rsp+0x30], xmm3
00007942783dc999  vmovaps [rsp+0x40], xmm4
00007942783dc99f  vmovaps [rsp+0x50], xmm5
00007942783dc9a5  vmovaps [rsp+0x60], xmm6
00007942783dc9ab  vmovaps [rsp+0x70], xmm7
00007942783dc9b1  vmovaps [rsp+0x80], xmm9
00007942783dc9ba  vmovaps [rsp+0x90], xmm10
00007942783dc9c3  vmovaps [rsp+0xA0], xmm11
00007942783dc9cc  vmovaps [rsp+0xB0], xmm12
00007942783dc9d5  vmovaps [rsp+0xC0], xmm13
00007942783dc9de  vmovaps [rsp+0xD0], xmm14
00007942783dc9e7  vmovaps [rsp+0xE0], xmm15
00007942783dc9f0  sub rsp, 0x30
00007942783dc9f4  movaps [rsp], xmm8
00007942783dc9f9  movaps [rsp+0x10], xmm12
00007942783dc9ff  movaps [rsp+0x20], xmm15
00007942783dca05  lea rdi, [rsp]
00007942783dca09  mov esi, 0x00
00007942783dca0e  mov rax, 0x59DDDCBA3530
00007942783dca18  call rax
00007942783dca1a  movaps xmm8, [rsp]
00007942783dca1f  add rsp, 0x30
00007942783dca23  vmovaps xmm0, [rsp]
00007942783dca28  vmovaps xmm1, [rsp+0x10]
00007942783dca2e  vmovaps xmm2, [rsp+0x20]
00007942783dca34  vmovaps xmm3, [rsp+0x30]
00007942783dca3a  vmovaps xmm4, [rsp+0x40]
00007942783dca40  vmovaps xmm5, [rsp+0x50]
00007942783dca46  vmovaps xmm6, [rsp+0x60]
00007942783dca4c  vmovaps xmm7, [rsp+0x70]
00007942783dca52  vmovaps xmm9, [rsp+0x80]
00007942783dca5b  vmovaps xmm10, [rsp+0x90]
00007942783dca64  vmovaps xmm11, [rsp+0xA0]
00007942783dca6d  vmovaps xmm12, [rsp+0xB0]
00007942783dca76  vmovaps xmm13, [rsp+0xC0]
00007942783dca7f  vmovaps xmm14, [rsp+0xD0]
00007942783dca88  vmovaps xmm15, [rsp+0xE0]
00007942783dca91  add rsp, 0xF0
00007942783dca98  pop r11
00007942783dca9a  pop r10
00007942783dca9c  pop r9
00007942783dca9e  pop r8
00007942783dcaa0  pop rsi
00007942783dcaa1  pop rdi
00007942783dcaa2  pop rdx
00007942783dcaa3  pop rcx
00007942783dcaa4  pop rax
00007942783dcaa5  add rsp, 0x08
00007942783dcaa9  jmp 0x00007942783DBB47
00007942783dcaae  sub rsp, 0x08
00007942783dcab2  push rax
00007942783dcab3  push rcx
00007942783dcab4  push rdx
00007942783dcab5  push rdi
00007942783dcab6  push rsi
00007942783dcab7  push r8
00007942783dcab9  push r9
00007942783dcabb  push r10
00007942783dcabd  push r11
00007942783dcabf  sub rsp, 0xF0
00007942783dcac6  vmovaps [rsp], xmm0
00007942783dcacb  vmovaps [rsp+0x10], xmm1
00007942783dcad1  vmovaps [rsp+0x20], xmm2
00007942783dcad7  vmovaps [rsp+0x30], xmm3
00007942783dcadd  vmovaps [rsp+0x40], xmm4
00007942783dcae3  vmovaps [rsp+0x50], xmm5
00007942783dcae9  vmovaps [rsp+0x60], xmm6
00007942783dcaef  vmovaps [rsp+0x70], xmm8
00007942783dcaf5  vmovaps [rsp+0x80], xmm9
00007942783dcafe  vmovaps [rsp+0x90], xmm10
00007942783dcb07  vmovaps [rsp+0xA0], xmm11
00007942783dcb10  vmovaps [rsp+0xB0], xmm12
00007942783dcb19  vmovaps [rsp+0xC0], xmm13
00007942783dcb22  vmovaps [rsp+0xD0], xmm14
00007942783dcb2b  vmovaps [rsp+0xE0], xmm15
00007942783dcb34  sub rsp, 0x30
00007942783dcb38  movaps [rsp], xmm7
00007942783dcb3c  movaps [rsp+0x10], xmm9
00007942783dcb42  movaps [rsp+0x20], xmm15
00007942783dcb48  lea rdi, [rsp]
00007942783dcb4c  mov esi, 0x00
00007942783dcb51  mov rax, 0x59DDDCBA3530
00007942783dcb5b  call rax
00007942783dcb5d  movaps xmm7, [rsp]
00007942783dcb61  add rsp, 0x30
00007942783dcb65  vmovaps xmm0, [rsp]
00007942783dcb6a  vmovaps xmm1, [rsp+0x10]
00007942783dcb70  vmovaps xmm2, [rsp+0x20]
00007942783dcb76  vmovaps xmm3, [rsp+0x30]
00007942783dcb7c  vmovaps xmm4, [rsp+0x40]
00007942783dcb82  vmovaps xmm5, [rsp+0x50]
00007942783dcb88  vmovaps xmm6, [rsp+0x60]
00007942783dcb8e  vmovaps xmm8, [rsp+0x70]
00007942783dcb94  vmovaps xmm9, [rsp+0x80]
00007942783dcb9d  vmovaps xmm10, [rsp+0x90]
00007942783dcba6  vmovaps xmm11, [rsp+0xA0]
00007942783dcbaf  vmovaps xmm12, [rsp+0xB0]
00007942783dcbb8  vmovaps xmm13, [rsp+0xC0]
00007942783dcbc1  vmovaps xmm14, [rsp+0xD0]
00007942783dcbca  vmovaps xmm15, [rsp+0xE0]
00007942783dcbd3  add rsp, 0xF0
00007942783dcbda  pop r11
00007942783dcbdc  pop r10
00007942783dcbde  pop r9
00007942783dcbe0  pop r8
00007942783dcbe2  pop rsi
00007942783dcbe3  pop rdi
00007942783dcbe4  pop rdx
00007942783dcbe5  pop rcx
00007942783dcbe6  pop rax
00007942783dcbe7  add rsp, 0x08
00007942783dcbeb  jmp 0x00007942783DBB75
00007942783dcbf0  sub rsp, 0x08
00007942783dcbf4  push rax
00007942783dcbf5  push rcx
00007942783dcbf6  push rdx
00007942783dcbf7  push rdi
00007942783dcbf8  push rsi
00007942783dcbf9  push r8
00007942783dcbfb  push r9
00007942783dcbfd  push r10
00007942783dcbff  push r11
00007942783dcc01  sub rsp, 0xF0
00007942783dcc08  vmovaps [rsp], xmm0
00007942783dcc0d  vmovaps [rsp+0x10], xmm1
00007942783dcc13  vmovaps [rsp+0x20], xmm2
00007942783dcc19  vmovaps [rsp+0x30], xmm3
00007942783dcc1f  vmovaps [rsp+0x40], xmm4
00007942783dcc25  vmovaps [rsp+0x50], xmm5
00007942783dcc2b  vmovaps [rsp+0x60], xmm6
00007942783dcc31  vmovaps [rsp+0x70], xmm7
00007942783dcc37  vmovaps [rsp+0x80], xmm8
00007942783dcc40  vmovaps [rsp+0x90], xmm10
00007942783dcc49  vmovaps [rsp+0xA0], xmm11
00007942783dcc52  vmovaps [rsp+0xB0], xmm12
00007942783dcc5b  vmovaps [rsp+0xC0], xmm13
00007942783dcc64  vmovaps [rsp+0xD0], xmm14
00007942783dcc6d  vmovaps [rsp+0xE0], xmm15
00007942783dcc76  sub rsp, 0x30
00007942783dcc7a  movaps [rsp], xmm9
00007942783dcc7f  movaps [rsp+0x10], xmm12
00007942783dcc85  movaps [rsp+0x20], xmm10
00007942783dcc8b  lea rdi, [rsp]
00007942783dcc8f  mov esi, 0x00
00007942783dcc94  mov rax, 0x59DDDCBA3530
00007942783dcc9e  call rax
00007942783dcca0  movaps xmm9, [rsp]
00007942783dcca5  add rsp, 0x30
00007942783dcca9  vmovaps xmm0, [rsp]
00007942783dccae  vmovaps xmm1, [rsp+0x10]
00007942783dccb4  vmovaps xmm2, [rsp+0x20]
00007942783dccba  vmovaps xmm3, [rsp+0x30]
00007942783dccc0  vmovaps xmm4, [rsp+0x40]
00007942783dccc6  vmovaps xmm5, [rsp+0x50]
00007942783dcccc  vmovaps xmm6, [rsp+0x60]
00007942783dccd2  vmovaps xmm7, [rsp+0x70]
00007942783dccd8  vmovaps xmm8, [rsp+0x80]
00007942783dcce1  vmovaps xmm10, [rsp+0x90]
00007942783dccea  vmovaps xmm11, [rsp+0xA0]
00007942783dccf3  vmovaps xmm12, [rsp+0xB0]
00007942783dccfc  vmovaps xmm13, [rsp+0xC0]
00007942783dcd05  vmovaps xmm14, [rsp+0xD0]
00007942783dcd0e  vmovaps xmm15, [rsp+0xE0]
00007942783dcd17  add rsp, 0xF0
00007942783dcd1e  pop r11
00007942783dcd20  pop r10
00007942783dcd22  pop r9
00007942783dcd24  pop r8
00007942783dcd26  pop rsi
00007942783dcd27  pop rdi
00007942783dcd28  pop rdx
00007942783dcd29  pop rcx
00007942783dcd2a  pop rax
00007942783dcd2b  add rsp, 0x08
00007942783dcd2f  jmp 0x00007942783DBB99
00007942783dcd34  sub rsp, 0x08
00007942783dcd38  push rax
00007942783dcd39  push rcx
00007942783dcd3a  push rdx
00007942783dcd3b  push rdi
00007942783dcd3c  push rsi
00007942783dcd3d  push r8
00007942783dcd3f  push r9
00007942783dcd41  push r10
00007942783dcd43  push r11
00007942783dcd45  sub rsp, 0xF0
00007942783dcd4c  vmovaps [rsp], xmm0
00007942783dcd51  vmovaps [rsp+0x10], xmm1
00007942783dcd57  vmovaps [rsp+0x20], xmm2
00007942783dcd5d  vmovaps [rsp+0x30], xmm3
00007942783dcd63  vmovaps [rsp+0x40], xmm4
00007942783dcd69  vmovaps [rsp+0x50], xmm5
00007942783dcd6f  vmovaps [rsp+0x60], xmm6
00007942783dcd75  vmovaps [rsp+0x70], xmm7
00007942783dcd7b  vmovaps [rsp+0x80], xmm8
00007942783dcd84  vmovaps [rsp+0x90], xmm9
00007942783dcd8d  vmovaps [rsp+0xA0], xmm11
00007942783dcd96  vmovaps [rsp+0xB0], xmm12
00007942783dcd9f  vmovaps [rsp+0xC0], xmm13
00007942783dcda8  vmovaps [rsp+0xD0], xmm14
00007942783dcdb1  vmovaps [rsp+0xE0], xmm15
00007942783dcdba  sub rsp, 0x30
00007942783dcdbe  movaps [rsp], xmm10
00007942783dcdc3  movaps [rsp+0x10], xmm12
00007942783dcdc9  movaps [rsp+0x20], xmm11
00007942783dcdcf  lea rdi, [rsp]
00007942783dcdd3  mov esi, 0x00
00007942783dcdd8  mov rax, 0x59DDDCBA3530
00007942783dcde2  call rax
00007942783dcde4  movaps xmm10, [rsp]
00007942783dcde9  add rsp, 0x30
00007942783dcded  vmovaps xmm0, [rsp]
00007942783dcdf2  vmovaps xmm1, [rsp+0x10]
00007942783dcdf8  vmovaps xmm2, [rsp+0x20]
00007942783dcdfe  vmovaps xmm3, [rsp+0x30]
00007942783dce04  vmovaps xmm4, [rsp+0x40]
00007942783dce0a  vmovaps xmm5, [rsp+0x50]
00007942783dce10  vmovaps xmm6, [rsp+0x60]
00007942783dce16  vmovaps xmm7, [rsp+0x70]
00007942783dce1c  vmovaps xmm8, [rsp+0x80]
00007942783dce25  vmovaps xmm9, [rsp+0x90]
00007942783dce2e  vmovaps xmm11, [rsp+0xA0]
00007942783dce37  vmovaps xmm12, [rsp+0xB0]
00007942783dce40  vmovaps xmm13, [rsp+0xC0]
00007942783dce49  vmovaps xmm14, [rsp+0xD0]
00007942783dce52  vmovaps xmm15, [rsp+0xE0]
00007942783dce5b  add rsp, 0xF0
00007942783dce62  pop r11
00007942783dce64  pop r10
00007942783dce66  pop r9
00007942783dce68  pop r8
00007942783dce6a  pop rsi
00007942783dce6b  pop rdi
00007942783dce6c  pop rdx
00007942783dce6d  pop rcx
00007942783dce6e  pop rax
00007942783dce6f  add rsp, 0x08
00007942783dce73  jmp 0x00007942783DBBB3
00007942783dce78  sub rsp, 0x08
00007942783dce7c  push rax
00007942783dce7d  push rcx
00007942783dce7e  push rdx
00007942783dce7f  push rdi
00007942783dce80  push rsi
00007942783dce81  push r8
00007942783dce83  push r9
00007942783dce85  push r10
00007942783dce87  push r11
00007942783dce89  sub rsp, 0xF0
00007942783dce90  vmovaps [rsp], xmm0
00007942783dce95  vmovaps [rsp+0x10], xmm1
00007942783dce9b  vmovaps [rsp+0x20], xmm2
00007942783dcea1  vmovaps [rsp+0x30], xmm3
00007942783dcea7  vmovaps [rsp+0x40], xmm4
00007942783dcead  vmovaps [rsp+0x50], xmm5
00007942783dceb3  vmovaps [rsp+0x60], xmm7
00007942783dceb9  vmovaps [rsp+0x70], xmm8
00007942783dcebf  vmovaps [rsp+0x80], xmm9
00007942783dcec8  vmovaps [rsp+0x90], xmm10
00007942783dced1  vmovaps [rsp+0xA0], xmm11
00007942783dceda  vmovaps [rsp+0xB0], xmm12
00007942783dcee3  vmovaps [rsp+0xC0], xmm13
00007942783dceec  vmovaps [rsp+0xD0], xmm14
00007942783dcef5  vmovaps [rsp+0xE0], xmm15
00007942783dcefe  sub rsp, 0x30
00007942783dcf02  movaps [rsp], xmm6
00007942783dcf06  movaps [rsp+0x10], xmm12
00007942783dcf0c  movaps [rsp+0x20], xmm11
00007942783dcf12  lea rdi, [rsp]
00007942783dcf16  mov esi, 0x00
00007942783dcf1b  mov rax, 0x59DDDCBA3530
00007942783dcf25  call rax
00007942783dcf27  movaps xmm6, [rsp]
00007942783dcf2b  add rsp, 0x30
00007942783dcf2f  vmovaps xmm0, [rsp]
00007942783dcf34  vmovaps xmm1, [rsp+0x10]
00007942783dcf3a  vmovaps xmm2, [rsp+0x20]
00007942783dcf40  vmovaps xmm3, [rsp+0x30]
00007942783dcf46  vmovaps xmm4, [rsp+0x40]
00007942783dcf4c  vmovaps xmm5, [rsp+0x50]
00007942783dcf52  vmovaps xmm7, [rsp+0x60]
00007942783dcf58  vmovaps xmm8, [rsp+0x70]
00007942783dcf5e  vmovaps xmm9, [rsp+0x80]
00007942783dcf67  vmovaps xmm10, [rsp+0x90]
00007942783dcf70  vmovaps xmm11, [rsp+0xA0]
00007942783dcf79  vmovaps xmm12, [rsp+0xB0]
00007942783dcf82  vmovaps xmm13, [rsp+0xC0]
00007942783dcf8b  vmovaps xmm14, [rsp+0xD0]
00007942783dcf94  vmovaps xmm15, [rsp+0xE0]
00007942783dcf9d  add rsp, 0xF0
00007942783dcfa4  pop r11
00007942783dcfa6  pop r10
00007942783dcfa8  pop r9
00007942783dcfaa  pop r8
00007942783dcfac  pop rsi
00007942783dcfad  pop rdi
00007942783dcfae  pop rdx
00007942783dcfaf  pop rcx
00007942783dcfb0  pop rax
00007942783dcfb1  add rsp, 0x08
00007942783dcfb5  jmp 0x00007942783DBBD4
00007942783dcfba  sub rsp, 0x08
00007942783dcfbe  push rax
00007942783dcfbf  push rcx
00007942783dcfc0  push rdx
00007942783dcfc1  push rdi
00007942783dcfc2  push rsi
00007942783dcfc3  push r8
00007942783dcfc5  push r9
00007942783dcfc7  push r10
00007942783dcfc9  push r11
00007942783dcfcb  sub rsp, 0xF0
00007942783dcfd2  vmovaps [rsp], xmm0
00007942783dcfd7  vmovaps [rsp+0x10], xmm1
00007942783dcfdd  vmovaps [rsp+0x20], xmm2
00007942783dcfe3  vmovaps [rsp+0x30], xmm4
00007942783dcfe9  vmovaps [rsp+0x40], xmm5
00007942783dcfef  vmovaps [rsp+0x50], xmm6
00007942783dcff5  vmovaps [rsp+0x60], xmm7
00007942783dcffb  vmovaps [rsp+0x70], xmm8
00007942783dd001  vmovaps [rsp+0x80], xmm9
00007942783dd00a  vmovaps [rsp+0x90], xmm10
00007942783dd013  vmovaps [rsp+0xA0], xmm11
00007942783dd01c  vmovaps [rsp+0xB0], xmm12
00007942783dd025  vmovaps [rsp+0xC0], xmm13
00007942783dd02e  vmovaps [rsp+0xD0], xmm14
00007942783dd037  vmovaps [rsp+0xE0], xmm15
00007942783dd040  sub rsp, 0x30
00007942783dd044  movaps [rsp], xmm3
00007942783dd048  movaps [rsp+0x10], xmm5
00007942783dd04d  movaps [rsp+0x20], xmm4
00007942783dd052  lea rdi, [rsp]
00007942783dd056  mov esi, 0x00
00007942783dd05b  mov rax, 0x59DDDCBA3530
00007942783dd065  call rax
00007942783dd067  movaps xmm3, [rsp]
00007942783dd06b  add rsp, 0x30
00007942783dd06f  vmovaps xmm0, [rsp]
00007942783dd074  vmovaps xmm1, [rsp+0x10]
00007942783dd07a  vmovaps xmm2, [rsp+0x20]
00007942783dd080  vmovaps xmm4, [rsp+0x30]
00007942783dd086  vmovaps xmm5, [rsp+0x40]
00007942783dd08c  vmovaps xmm6, [rsp+0x50]
00007942783dd092  vmovaps xmm7, [rsp+0x60]
00007942783dd098  vmovaps xmm8, [rsp+0x70]
00007942783dd09e  vmovaps xmm9, [rsp+0x80]
00007942783dd0a7  vmovaps xmm10, [rsp+0x90]
00007942783dd0b0  vmovaps xmm11, [rsp+0xA0]
00007942783dd0b9  vmovaps xmm12, [rsp+0xB0]
00007942783dd0c2  vmovaps xmm13, [rsp+0xC0]
00007942783dd0cb  vmovaps xmm14, [rsp+0xD0]
00007942783dd0d4  vmovaps xmm15, [rsp+0xE0]
00007942783dd0dd  add rsp, 0xF0
00007942783dd0e4  pop r11
00007942783dd0e6  pop r10
00007942783dd0e8  pop r9
00007942783dd0ea  pop r8
00007942783dd0ec  pop rsi
00007942783dd0ed  pop rdi
00007942783dd0ee  pop rdx
00007942783dd0ef  pop rcx
00007942783dd0f0  pop rax
00007942783dd0f1  add rsp, 0x08
00007942783dd0f5  jmp 0x00007942783DBC35
00007942783dd0fa  sub rsp, 0x08
00007942783dd0fe  push rax
00007942783dd0ff  push rcx
00007942783dd100  push rdx
00007942783dd101  push rdi
00007942783dd102  push rsi
00007942783dd103  push r8
00007942783dd105  push r9
00007942783dd107  push r10
00007942783dd109  push r11
00007942783dd10b  sub rsp, 0xF0
00007942783dd112  vmovaps [rsp], xmm0
00007942783dd117  vmovaps [rsp+0x10], xmm1
00007942783dd11d  vmovaps [rsp+0x20], xmm2
00007942783dd123  vmovaps [rsp+0x30], xmm3
00007942783dd129  vmovaps [rsp+0x40], xmm4
00007942783dd12f  vmovaps [rsp+0x50], xmm6
00007942783dd135  vmovaps [rsp+0x60], xmm7
00007942783dd13b  vmovaps [rsp+0x70], xmm8
00007942783dd141  vmovaps [rsp+0x80], xmm9
00007942783dd14a  vmovaps [rsp+0x90], xmm10
00007942783dd153  vmovaps [rsp+0xA0], xmm11
00007942783dd15c  vmovaps [rsp+0xB0], xmm12
00007942783dd165  vmovaps [rsp+0xC0], xmm13
00007942783dd16e  vmovaps [rsp+0xD0], xmm14
00007942783dd177  vmovaps [rsp+0xE0], xmm15
00007942783dd180  sub rsp, 0x30
00007942783dd184  movaps [rsp], xmm5
00007942783dd188  movaps [rsp+0x10], xmm8
00007942783dd18e  movaps [rsp+0x20], xmm15
00007942783dd194  lea rdi, [rsp]
00007942783dd198  mov esi, 0x00
00007942783dd19d  mov rax, 0x59DDDCBA3530
00007942783dd1a7  call rax
00007942783dd1a9  movaps xmm5, [rsp]
00007942783dd1ad  add rsp, 0x30
00007942783dd1b1  vmovaps xmm0, [rsp]
00007942783dd1b6  vmovaps xmm1, [rsp+0x10]
00007942783dd1bc  vmovaps xmm2, [rsp+0x20]
00007942783dd1c2  vmovaps xmm3, [rsp+0x30]
00007942783dd1c8  vmovaps xmm4, [rsp+0x40]
00007942783dd1ce  vmovaps xmm6, [rsp+0x50]
00007942783dd1d4  vmovaps xmm7, [rsp+0x60]
00007942783dd1da  vmovaps xmm8, [rsp+0x70]
00007942783dd1e0  vmovaps xmm9, [rsp+0x80]
00007942783dd1e9  vmovaps xmm10, [rsp+0x90]
00007942783dd1f2  vmovaps xmm11, [rsp+0xA0]
00007942783dd1fb  vmovaps xmm12, [rsp+0xB0]
00007942783dd204  vmovaps xmm13, [rsp+0xC0]
00007942783dd20d  vmovaps xmm14, [rsp+0xD0]
00007942783dd216  vmovaps xmm15, [rsp+0xE0]
00007942783dd21f  add rsp, 0xF0
00007942783dd226  pop r11
00007942783dd228  pop r10
00007942783dd22a  pop r9
00007942783dd22c  pop r8
00007942783dd22e  pop rsi
00007942783dd22f  pop rdi
00007942783dd230  pop rdx
00007942783dd231  pop rcx
00007942783dd232  pop rax
00007942783dd233  add rsp, 0x08
00007942783dd237  jmp 0x00007942783DBC73
00007942783dd23c  sub rsp, 0x08
00007942783dd240  push rax
00007942783dd241  push rcx
00007942783dd242  push rdx
00007942783dd243  push rdi
00007942783dd244  push rsi
00007942783dd245  push r8
00007942783dd247  push r9
00007942783dd249  push r10
00007942783dd24b  push r11
00007942783dd24d  sub rsp, 0xF0
00007942783dd254  vmovaps [rsp], xmm0
00007942783dd259  vmovaps [rsp+0x10], xmm1
00007942783dd25f  vmovaps [rsp+0x20], xmm2
00007942783dd265  vmovaps [rsp+0x30], xmm3
00007942783dd26b  vmovaps [rsp+0x40], xmm5
00007942783dd271  vmovaps [rsp+0x50], xmm6
00007942783dd277  vmovaps [rsp+0x60], xmm7
00007942783dd27d  vmovaps [rsp+0x70], xmm8
00007942783dd283  vmovaps [rsp+0x80], xmm9
00007942783dd28c  vmovaps [rsp+0x90], xmm10
00007942783dd295  vmovaps [rsp+0xA0], xmm11
00007942783dd29e  vmovaps [rsp+0xB0], xmm12
00007942783dd2a7  vmovaps [rsp+0xC0], xmm13
00007942783dd2b0  vmovaps [rsp+0xD0], xmm14
00007942783dd2b9  vmovaps [rsp+0xE0], xmm15
00007942783dd2c2  sub rsp, 0x30
00007942783dd2c6  movaps [rsp], xmm4
00007942783dd2ca  movaps [rsp+0x10], xmm9
00007942783dd2d0  movaps [rsp+0x20], xmm8
00007942783dd2d6  lea rdi, [rsp]
00007942783dd2da  mov esi, 0x00
00007942783dd2df  mov rax, 0x59DDDCBA3530
00007942783dd2e9  call rax
00007942783dd2eb  movaps xmm4, [rsp]
00007942783dd2ef  add rsp, 0x30
00007942783dd2f3  vmovaps xmm0, [rsp]
00007942783dd2f8  vmovaps xmm1, [rsp+0x10]
00007942783dd2fe  vmovaps xmm2, [rsp+0x20]
00007942783dd304  vmovaps xmm3, [rsp+0x30]
00007942783dd30a  vmovaps xmm5, [rsp+0x40]
00007942783dd310  vmovaps xmm6, [rsp+0x50]
00007942783dd316  vmovaps xmm7, [rsp+0x60]
00007942783dd31c  vmovaps xmm8, [rsp+0x70]
00007942783dd322  vmovaps xmm9, [rsp+0x80]
00007942783dd32b  vmovaps xmm10, [rsp+0x90]
00007942783dd334  vmovaps xmm11, [rsp+0xA0]
00007942783dd33d  vmovaps xmm12, [rsp+0xB0]
00007942783dd346  vmovaps xmm13, [rsp+0xC0]
00007942783dd34f  vmovaps xmm14, [rsp+0xD0]
00007942783dd358  vmovaps xmm15, [rsp+0xE0]
00007942783dd361  add rsp, 0xF0
00007942783dd368  pop r11
00007942783dd36a  pop r10
00007942783dd36c  pop r9
00007942783dd36e  pop r8
00007942783dd370  pop rsi
00007942783dd371  pop rdi
00007942783dd372  pop rdx
00007942783dd373  pop rcx
00007942783dd374  pop rax
00007942783dd375  add rsp, 0x08
00007942783dd379  jmp 0x00007942783DBC94
00007942783dd37e  sub rsp, 0x08
00007942783dd382  push rax
00007942783dd383  push rcx
00007942783dd384  push rdx
00007942783dd385  push rdi
00007942783dd386  push rsi
00007942783dd387  push r8
00007942783dd389  push r9
00007942783dd38b  push r10
00007942783dd38d  push r11
00007942783dd38f  sub rsp, 0xF0
00007942783dd396  vmovaps [rsp], xmm0
00007942783dd39b  vmovaps [rsp+0x10], xmm1
00007942783dd3a1  vmovaps [rsp+0x20], xmm2
00007942783dd3a7  vmovaps [rsp+0x30], xmm3
00007942783dd3ad  vmovaps [rsp+0x40], xmm4
00007942783dd3b3  vmovaps [rsp+0x50], xmm5
00007942783dd3b9  vmovaps [rsp+0x60], xmm6
00007942783dd3bf  vmovaps [rsp+0x70], xmm7
00007942783dd3c5  vmovaps [rsp+0x80], xmm8
00007942783dd3ce  vmovaps [rsp+0x90], xmm10
00007942783dd3d7  vmovaps [rsp+0xA0], xmm11
00007942783dd3e0  vmovaps [rsp+0xB0], xmm12
00007942783dd3e9  vmovaps [rsp+0xC0], xmm13
00007942783dd3f2  vmovaps [rsp+0xD0], xmm14
00007942783dd3fb  vmovaps [rsp+0xE0], xmm15
00007942783dd404  sub rsp, 0x30
00007942783dd408  movaps [rsp], xmm9
00007942783dd40d  movaps [rsp+0x10], xmm10
00007942783dd413  movaps [rsp+0x20], xmm8
00007942783dd419  lea rdi, [rsp]
00007942783dd41d  mov esi, 0x00
00007942783dd422  mov rax, 0x59DDDCBA3530
00007942783dd42c  call rax
00007942783dd42e  movaps xmm9, [rsp]
00007942783dd433  add rsp, 0x30
00007942783dd437  vmovaps xmm0, [rsp]
00007942783dd43c  vmovaps xmm1, [rsp+0x10]
00007942783dd442  vmovaps xmm2, [rsp+0x20]
00007942783dd448  vmovaps xmm3, [rsp+0x30]
00007942783dd44e  vmovaps xmm4, [rsp+0x40]
00007942783dd454  vmovaps xmm5, [rsp+0x50]
00007942783dd45a  vmovaps xmm6, [rsp+0x60]
00007942783dd460  vmovaps xmm7, [rsp+0x70]
00007942783dd466  vmovaps xmm8, [rsp+0x80]
00007942783dd46f  vmovaps xmm10, [rsp+0x90]
00007942783dd478  vmovaps xmm11, [rsp+0xA0]
00007942783dd481  vmovaps xmm12, [rsp+0xB0]
00007942783dd48a  vmovaps xmm13, [rsp+0xC0]
00007942783dd493  vmovaps xmm14, [rsp+0xD0]
00007942783dd49c  vmovaps xmm15, [rsp+0xE0]
00007942783dd4a5  add rsp, 0xF0
00007942783dd4ac  pop r11
00007942783dd4ae  pop r10
00007942783dd4b0  pop r9
00007942783dd4b2  pop r8
00007942783dd4b4  pop rsi
00007942783dd4b5  pop rdi
00007942783dd4b6  pop rdx
00007942783dd4b7  pop rcx
00007942783dd4b8  pop rax
00007942783dd4b9  add rsp, 0x08
00007942783dd4bd  jmp 0x00007942783DBCAE
00007942783dd4c2  call 0x00007942782B52F0
00007942783dd4c7  jmp 0x00007942783DBDC8
00007942783dd4cc  call 0x00007942782B52F0
00007942783dd4d1  jmp 0x00007942783DBDDE
00007942783dd4d6  sub rsp, 0x08
00007942783dd4da  push rax
00007942783dd4db  push rcx
00007942783dd4dc  push rdx
00007942783dd4dd  push rdi
00007942783dd4de  push rsi
00007942783dd4df  push r8
00007942783dd4e1  push r9
00007942783dd4e3  push r10
00007942783dd4e5  push r11
00007942783dd4e7  sub rsp, 0xF0
00007942783dd4ee  vmovaps [rsp], xmm0
00007942783dd4f3  vmovaps [rsp+0x10], xmm2
00007942783dd4f9  vmovaps [rsp+0x20], xmm3
00007942783dd4ff  vmovaps [rsp+0x30], xmm4
00007942783dd505  vmovaps [rsp+0x40], xmm5
00007942783dd50b  vmovaps [rsp+0x50], xmm6
00007942783dd511  vmovaps [rsp+0x60], xmm7
00007942783dd517  vmovaps [rsp+0x70], xmm8
00007942783dd51d  vmovaps [rsp+0x80], xmm9
00007942783dd526  vmovaps [rsp+0x90], xmm10
00007942783dd52f  vmovaps [rsp+0xA0], xmm11
00007942783dd538  vmovaps [rsp+0xB0], xmm12
00007942783dd541  vmovaps [rsp+0xC0], xmm13
00007942783dd54a  vmovaps [rsp+0xD0], xmm14
00007942783dd553  vmovaps [rsp+0xE0], xmm15
00007942783dd55c  sub rsp, 0x30
00007942783dd560  movaps [rsp], xmm1
00007942783dd564  movaps [rsp+0x10], xmm6
00007942783dd569  movaps [rsp+0x20], xmm15
00007942783dd56f  lea rdi, [rsp]
00007942783dd573  mov esi, 0x00
00007942783dd578  mov rax, 0x59DDDCBA3530
00007942783dd582  call rax
00007942783dd584  movaps xmm1, [rsp]
00007942783dd588  add rsp, 0x30
00007942783dd58c  vmovaps xmm0, [rsp]
00007942783dd591  vmovaps xmm2, [rsp+0x10]
00007942783dd597  vmovaps xmm3, [rsp+0x20]
00007942783dd59d  vmovaps xmm4, [rsp+0x30]
00007942783dd5a3  vmovaps xmm5, [rsp+0x40]
00007942783dd5a9  vmovaps xmm6, [rsp+0x50]
00007942783dd5af  vmovaps xmm7, [rsp+0x60]
00007942783dd5b5  vmovaps xmm8, [rsp+0x70]
00007942783dd5bb  vmovaps xmm9, [rsp+0x80]
00007942783dd5c4  vmovaps xmm10, [rsp+0x90]
00007942783dd5cd  vmovaps xmm11, [rsp+0xA0]
00007942783dd5d6  vmovaps xmm12, [rsp+0xB0]
00007942783dd5df  vmovaps xmm13, [rsp+0xC0]
00007942783dd5e8  vmovaps xmm14, [rsp+0xD0]
00007942783dd5f1  vmovaps xmm15, [rsp+0xE0]
00007942783dd5fa  add rsp, 0xF0
00007942783dd601  pop r11
00007942783dd603  pop r10
00007942783dd605  pop r9
00007942783dd607  pop r8
00007942783dd609  pop rsi
00007942783dd60a  pop rdi
00007942783dd60b  pop rdx
00007942783dd60c  pop rcx
00007942783dd60d  pop rax
00007942783dd60e  add rsp, 0x08
00007942783dd612  jmp 0x00007942783DBE1B
00007942783dd617  call 0x00007942782C4620
00007942783dd61c  jmp 0x00007942783DBE28
00007942783dd621  sub rsp, 0x08
00007942783dd625  push rax
00007942783dd626  push rcx
00007942783dd627  push rdx
00007942783dd628  push rdi
00007942783dd629  push rsi
00007942783dd62a  push r8
00007942783dd62c  push r9
00007942783dd62e  push r10
00007942783dd630  push r11
00007942783dd632  sub rsp, 0xF0
00007942783dd639  vmovaps [rsp], xmm0
00007942783dd63e  vmovaps [rsp+0x10], xmm1
00007942783dd644  vmovaps [rsp+0x20], xmm2
00007942783dd64a  vmovaps [rsp+0x30], xmm3
00007942783dd650  vmovaps [rsp+0x40], xmm4
00007942783dd656  vmovaps [rsp+0x50], xmm5
00007942783dd65c  vmovaps [rsp+0x60], xmm6
00007942783dd662  vmovaps [rsp+0x70], xmm7
00007942783dd668  vmovaps [rsp+0x80], xmm8
00007942783dd671  vmovaps [rsp+0x90], xmm9
00007942783dd67a  vmovaps [rsp+0xA0], xmm10
00007942783dd683  vmovaps [rsp+0xB0], xmm11
00007942783dd68c  vmovaps [rsp+0xC0], xmm12
00007942783dd695  vmovaps [rsp+0xD0], xmm13
00007942783dd69e  vmovaps [rsp+0xE0], xmm15
00007942783dd6a7  sub rsp, 0x30
00007942783dd6ab  movaps [rsp], xmm14
00007942783dd6b0  movaps [rsp+0x10], xmm4
00007942783dd6b5  movaps [rsp+0x20], xmm3
00007942783dd6ba  lea rdi, [rsp]
00007942783dd6be  mov esi, 0x00
00007942783dd6c3  mov rax, 0x59DDDCBA3530
00007942783dd6cd  call rax
00007942783dd6cf  movaps xmm14, [rsp]
00007942783dd6d4  add rsp, 0x30
00007942783dd6d8  vmovaps xmm0, [rsp]
00007942783dd6dd  vmovaps xmm1, [rsp+0x10]
00007942783dd6e3  vmovaps xmm2, [rsp+0x20]
00007942783dd6e9  vmovaps xmm3, [rsp+0x30]
00007942783dd6ef  vmovaps xmm4, [rsp+0x40]
00007942783dd6f5  vmovaps xmm5, [rsp+0x50]
00007942783dd6fb  vmovaps xmm6, [rsp+0x60]
00007942783dd701  vmovaps xmm7, [rsp+0x70]
00007942783dd707  vmovaps xmm8, [rsp+0x80]
00007942783dd710  vmovaps xmm9, [rsp+0x90]
00007942783dd719  vmovaps xmm10, [rsp+0xA0]
00007942783dd722  vmovaps xmm11, [rsp+0xB0]
00007942783dd72b  vmovaps xmm12, [rsp+0xC0]
00007942783dd734  vmovaps xmm13, [rsp+0xD0]
00007942783dd73d  vmovaps xmm15, [rsp+0xE0]
00007942783dd746  add rsp, 0xF0
00007942783dd74d  pop r11
00007942783dd74f  pop r10
00007942783dd751  pop r9
00007942783dd753  pop r8
00007942783dd755  pop rsi
00007942783dd756  pop rdi
00007942783dd757  pop rdx
00007942783dd758  pop rcx
00007942783dd759  pop rax
00007942783dd75a  add rsp, 0x08
00007942783dd75e  jmp 0x00007942783DBE42
00007942783dd763  sub rsp, 0x08
00007942783dd767  push rax
00007942783dd768  push rcx
00007942783dd769  push rdx
00007942783dd76a  push rdi
00007942783dd76b  push rsi
00007942783dd76c  push r8
00007942783dd76e  push r9
00007942783dd770  push r10
00007942783dd772  push r11
00007942783dd774  sub rsp, 0xF0
00007942783dd77b  vmovaps [rsp], xmm0
00007942783dd780  vmovaps [rsp+0x10], xmm1
00007942783dd786  vmovaps [rsp+0x20], xmm2
00007942783dd78c  vmovaps [rsp+0x30], xmm3
00007942783dd792  vmovaps [rsp+0x40], xmm4
00007942783dd798  vmovaps [rsp+0x50], xmm5
00007942783dd79e  vmovaps [rsp+0x60], xmm7
00007942783dd7a4  vmovaps [rsp+0x70], xmm8
00007942783dd7aa  vmovaps [rsp+0x80], xmm9
00007942783dd7b3  vmovaps [rsp+0x90], xmm10
00007942783dd7bc  vmovaps [rsp+0xA0], xmm11
00007942783dd7c5  vmovaps [rsp+0xB0], xmm12
00007942783dd7ce  vmovaps [rsp+0xC0], xmm13
00007942783dd7d7  vmovaps [rsp+0xD0], xmm14
00007942783dd7e0  vmovaps [rsp+0xE0], xmm15
00007942783dd7e9  sub rsp, 0x30
00007942783dd7ed  movaps [rsp], xmm6
00007942783dd7f1  movaps [rsp+0x10], xmm9
00007942783dd7f7  movaps [rsp+0x20], xmm7
00007942783dd7fc  lea rdi, [rsp]
00007942783dd800  mov esi, 0x00
00007942783dd805  mov rax, 0x59DDDCBA3530
00007942783dd80f  call rax
00007942783dd811  movaps xmm6, [rsp]
00007942783dd815  add rsp, 0x30
00007942783dd819  vmovaps xmm0, [rsp]
00007942783dd81e  vmovaps xmm1, [rsp+0x10]
00007942783dd824  vmovaps xmm2, [rsp+0x20]
00007942783dd82a  vmovaps xmm3, [rsp+0x30]
00007942783dd830  vmovaps xmm4, [rsp+0x40]
00007942783dd836  vmovaps xmm5, [rsp+0x50]
00007942783dd83c  vmovaps xmm7, [rsp+0x60]
00007942783dd842  vmovaps xmm8, [rsp+0x70]
00007942783dd848  vmovaps xmm9, [rsp+0x80]
00007942783dd851  vmovaps xmm10, [rsp+0x90]
00007942783dd85a  vmovaps xmm11, [rsp+0xA0]
00007942783dd863  vmovaps xmm12, [rsp+0xB0]
00007942783dd86c  vmovaps xmm13, [rsp+0xC0]
00007942783dd875  vmovaps xmm14, [rsp+0xD0]
00007942783dd87e  vmovaps xmm15, [rsp+0xE0]
00007942783dd887  add rsp, 0xF0
00007942783dd88e  pop r11
00007942783dd890  pop r10
00007942783dd892  pop r9
00007942783dd894  pop r8
00007942783dd896  pop rsi
00007942783dd897  pop rdi
00007942783dd898  pop rdx
00007942783dd899  pop rcx
00007942783dd89a  pop rax
00007942783dd89b  add rsp, 0x08
00007942783dd89f  jmp 0x00007942783DBE5A
00007942783dd8a4  sub rsp, 0x08
00007942783dd8a8  push rax
00007942783dd8a9  push rcx
00007942783dd8aa  push rdx
00007942783dd8ab  push rdi
00007942783dd8ac  push rsi
00007942783dd8ad  push r8
00007942783dd8af  push r9
00007942783dd8b1  push r10
00007942783dd8b3  push r11
00007942783dd8b5  sub rsp, 0xF0
00007942783dd8bc  vmovaps [rsp], xmm0
00007942783dd8c1  vmovaps [rsp+0x10], xmm1
00007942783dd8c7  vmovaps [rsp+0x20], xmm2
00007942783dd8cd  vmovaps [rsp+0x30], xmm3
00007942783dd8d3  vmovaps [rsp+0x40], xmm4
00007942783dd8d9  vmovaps [rsp+0x50], xmm5
00007942783dd8df  vmovaps [rsp+0x60], xmm6
00007942783dd8e5  vmovaps [rsp+0x70], xmm8
00007942783dd8eb  vmovaps [rsp+0x80], xmm9
00007942783dd8f4  vmovaps [rsp+0x90], xmm10
00007942783dd8fd  vmovaps [rsp+0xA0], xmm11
00007942783dd906  vmovaps [rsp+0xB0], xmm12
00007942783dd90f  vmovaps [rsp+0xC0], xmm13
00007942783dd918  vmovaps [rsp+0xD0], xmm14
00007942783dd921  vmovaps [rsp+0xE0], xmm15
00007942783dd92a  sub rsp, 0x30
00007942783dd92e  movaps [rsp], xmm7
00007942783dd932  movaps [rsp+0x10], xmm4
00007942783dd937  movaps [rsp+0x20], xmm9
00007942783dd93d  lea rdi, [rsp]
00007942783dd941  mov esi, 0x00
00007942783dd946  mov rax, 0x59DDDCBA3530
00007942783dd950  call rax
00007942783dd952  movaps xmm7, [rsp]
00007942783dd956  add rsp, 0x30
00007942783dd95a  vmovaps xmm0, [rsp]
00007942783dd95f  vmovaps xmm1, [rsp+0x10]
00007942783dd965  vmovaps xmm2, [rsp+0x20]
00007942783dd96b  vmovaps xmm3, [rsp+0x30]
00007942783dd971  vmovaps xmm4, [rsp+0x40]
00007942783dd977  vmovaps xmm5, [rsp+0x50]
00007942783dd97d  vmovaps xmm6, [rsp+0x60]
00007942783dd983  vmovaps xmm8, [rsp+0x70]
00007942783dd989  vmovaps xmm9, [rsp+0x80]
00007942783dd992  vmovaps xmm10, [rsp+0x90]
00007942783dd99b  vmovaps xmm11, [rsp+0xA0]
00007942783dd9a4  vmovaps xmm12, [rsp+0xB0]
00007942783dd9ad  vmovaps xmm13, [rsp+0xC0]
00007942783dd9b6  vmovaps xmm14, [rsp+0xD0]
00007942783dd9bf  vmovaps xmm15, [rsp+0xE0]
00007942783dd9c8  add rsp, 0xF0
00007942783dd9cf  pop r11
00007942783dd9d1  pop r10
00007942783dd9d3  pop r9
00007942783dd9d5  pop r8
00007942783dd9d7  pop rsi
00007942783dd9d8  pop rdi
00007942783dd9d9  pop rdx
00007942783dd9da  pop rcx
00007942783dd9db  pop rax
00007942783dd9dc  add rsp, 0x08
00007942783dd9e0  jmp 0x00007942783DBE87
00007942783dd9e5  sub rsp, 0x08
00007942783dd9e9  push rax
00007942783dd9ea  push rcx
00007942783dd9eb  push rdx
00007942783dd9ec  push rdi
00007942783dd9ed  push rsi
00007942783dd9ee  push r8
00007942783dd9f0  push r9
00007942783dd9f2  push r10
00007942783dd9f4  push r11
00007942783dd9f6  sub rsp, 0xF0
00007942783dd9fd  vmovaps [rsp], xmm0
00007942783dda02  vmovaps [rsp+0x10], xmm1
00007942783dda08  vmovaps [rsp+0x20], xmm2
00007942783dda0e  vmovaps [rsp+0x30], xmm3
00007942783dda14  vmovaps [rsp+0x40], xmm5
00007942783dda1a  vmovaps [rsp+0x50], xmm6
00007942783dda20  vmovaps [rsp+0x60], xmm7
00007942783dda26  vmovaps [rsp+0x70], xmm8
00007942783dda2c  vmovaps [rsp+0x80], xmm9
00007942783dda35  vmovaps [rsp+0x90], xmm10
00007942783dda3e  vmovaps [rsp+0xA0], xmm11
00007942783dda47  vmovaps [rsp+0xB0], xmm12
00007942783dda50  vmovaps [rsp+0xC0], xmm13
00007942783dda59  vmovaps [rsp+0xD0], xmm14
00007942783dda62  vmovaps [rsp+0xE0], xmm15
00007942783dda6b  sub rsp, 0x30
00007942783dda6f  movaps [rsp], xmm4
00007942783dda73  movaps [rsp+0x10], xmm15
00007942783dda79  movaps [rsp+0x20], xmm9
00007942783dda7f  lea rdi, [rsp]
00007942783dda83  mov esi, 0x00
00007942783dda88  mov rax, 0x59DDDCBA3530
00007942783dda92  call rax
00007942783dda94  movaps xmm4, [rsp]
00007942783dda98  add rsp, 0x30
00007942783dda9c  vmovaps xmm0, [rsp]
00007942783ddaa1  vmovaps xmm1, [rsp+0x10]
00007942783ddaa7  vmovaps xmm2, [rsp+0x20]
00007942783ddaad  vmovaps xmm3, [rsp+0x30]
00007942783ddab3  vmovaps xmm5, [rsp+0x40]
00007942783ddab9  vmovaps xmm6, [rsp+0x50]
00007942783ddabf  vmovaps xmm7, [rsp+0x60]
00007942783ddac5  vmovaps xmm8, [rsp+0x70]
00007942783ddacb  vmovaps xmm9, [rsp+0x80]
00007942783ddad4  vmovaps xmm10, [rsp+0x90]
00007942783ddadd  vmovaps xmm11, [rsp+0xA0]
00007942783ddae6  vmovaps xmm12, [rsp+0xB0]
00007942783ddaef  vmovaps xmm13, [rsp+0xC0]
00007942783ddaf8  vmovaps xmm14, [rsp+0xD0]
00007942783ddb01  vmovaps xmm15, [rsp+0xE0]
00007942783ddb0a  add rsp, 0xF0
00007942783ddb11  pop r11
00007942783ddb13  pop r10
00007942783ddb15  pop r9
00007942783ddb17  pop r8
00007942783ddb19  pop rsi
00007942783ddb1a  pop rdi
00007942783ddb1b  pop rdx
00007942783ddb1c  pop rcx
00007942783ddb1d  pop rax
00007942783ddb1e  add rsp, 0x08
00007942783ddb22  jmp 0x00007942783DBEAC
00007942783ddb27  call 0x00007942782C4620
00007942783ddb2c  jmp 0x00007942783DBEB9
00007942783ddb31  sub rsp, 0x08
00007942783ddb35  push rax
00007942783ddb36  push rcx
00007942783ddb37  push rdx
00007942783ddb38  push rdi
00007942783ddb39  push rsi
00007942783ddb3a  push r8
00007942783ddb3c  push r9
00007942783ddb3e  push r10
00007942783ddb40  push r11
00007942783ddb42  sub rsp, 0xF0
00007942783ddb49  vmovaps [rsp], xmm0
00007942783ddb4e  vmovaps [rsp+0x10], xmm1
00007942783ddb54  vmovaps [rsp+0x20], xmm2
00007942783ddb5a  vmovaps [rsp+0x30], xmm4
00007942783ddb60  vmovaps [rsp+0x40], xmm5
00007942783ddb66  vmovaps [rsp+0x50], xmm6
00007942783ddb6c  vmovaps [rsp+0x60], xmm7
00007942783ddb72  vmovaps [rsp+0x70], xmm8
00007942783ddb78  vmovaps [rsp+0x80], xmm9
00007942783ddb81  vmovaps [rsp+0x90], xmm10
00007942783ddb8a  vmovaps [rsp+0xA0], xmm11
00007942783ddb93  vmovaps [rsp+0xB0], xmm12
00007942783ddb9c  vmovaps [rsp+0xC0], xmm13
00007942783ddba5  vmovaps [rsp+0xD0], xmm14
00007942783ddbae  vmovaps [rsp+0xE0], xmm15
00007942783ddbb7  sub rsp, 0x30
00007942783ddbbb  movaps [rsp], xmm3
00007942783ddbbf  movaps [rsp+0x10], xmm1
00007942783ddbc4  movaps [rsp+0x20], xmm9
00007942783ddbca  lea rdi, [rsp]
00007942783ddbce  mov esi, 0x00
00007942783ddbd3  mov rax, 0x59DDDCBA3530
00007942783ddbdd  call rax
00007942783ddbdf  movaps xmm3, [rsp]
00007942783ddbe3  add rsp, 0x30
00007942783ddbe7  vmovaps xmm0, [rsp]
00007942783ddbec  vmovaps xmm1, [rsp+0x10]
00007942783ddbf2  vmovaps xmm2, [rsp+0x20]
00007942783ddbf8  vmovaps xmm4, [rsp+0x30]
00007942783ddbfe  vmovaps xmm5, [rsp+0x40]
00007942783ddc04  vmovaps xmm6, [rsp+0x50]
00007942783ddc0a  vmovaps xmm7, [rsp+0x60]
00007942783ddc10  vmovaps xmm8, [rsp+0x70]
00007942783ddc16  vmovaps xmm9, [rsp+0x80]
00007942783ddc1f  vmovaps xmm10, [rsp+0x90]
00007942783ddc28  vmovaps xmm11, [rsp+0xA0]
00007942783ddc31  vmovaps xmm12, [rsp+0xB0]
00007942783ddc3a  vmovaps xmm13, [rsp+0xC0]
00007942783ddc43  vmovaps xmm14, [rsp+0xD0]
00007942783ddc4c  vmovaps xmm15, [rsp+0xE0]
00007942783ddc55  add rsp, 0xF0
00007942783ddc5c  pop r11
00007942783ddc5e  pop r10
00007942783ddc60  pop r9
00007942783ddc62  pop r8
00007942783ddc64  pop rsi
00007942783ddc65  pop rdi
00007942783ddc66  pop rdx
00007942783ddc67  pop rcx
00007942783ddc68  pop rax
00007942783ddc69  add rsp, 0x08
00007942783ddc6d  jmp 0x00007942783DBEF6
00007942783ddc72  sub rsp, 0x08
00007942783ddc76  push rax
00007942783ddc77  push rcx
00007942783ddc78  push rdx
00007942783ddc79  push rdi
00007942783ddc7a  push rsi
00007942783ddc7b  push r8
00007942783ddc7d  push r9
00007942783ddc7f  push r10
00007942783ddc81  push r11
00007942783ddc83  sub rsp, 0xF0
00007942783ddc8a  vmovaps [rsp], xmm0
00007942783ddc8f  vmovaps [rsp+0x10], xmm2
00007942783ddc95  vmovaps [rsp+0x20], xmm3
00007942783ddc9b  vmovaps [rsp+0x30], xmm4
00007942783ddca1  vmovaps [rsp+0x40], xmm5
00007942783ddca7  vmovaps [rsp+0x50], xmm6
00007942783ddcad  vmovaps [rsp+0x60], xmm7
00007942783ddcb3  vmovaps [rsp+0x70], xmm8
00007942783ddcb9  vmovaps [rsp+0x80], xmm9
00007942783ddcc2  vmovaps [rsp+0x90], xmm10
00007942783ddccb  vmovaps [rsp+0xA0], xmm11
00007942783ddcd4  vmovaps [rsp+0xB0], xmm12
00007942783ddcdd  vmovaps [rsp+0xC0], xmm13
00007942783ddce6  vmovaps [rsp+0xD0], xmm14
00007942783ddcef  vmovaps [rsp+0xE0], xmm15
00007942783ddcf8  sub rsp, 0x30
00007942783ddcfc  movaps [rsp], xmm1
00007942783ddd00  movaps [rsp+0x10], xmm15
00007942783ddd06  movaps [rsp+0x20], xmm9
00007942783ddd0c  lea rdi, [rsp]
00007942783ddd10  mov esi, 0x00
00007942783ddd15  mov rax, 0x59DDDCBA3530
00007942783ddd1f  call rax
00007942783ddd21  movaps xmm1, [rsp]
00007942783ddd25  add rsp, 0x30
00007942783ddd29  vmovaps xmm0, [rsp]
00007942783ddd2e  vmovaps xmm2, [rsp+0x10]
00007942783ddd34  vmovaps xmm3, [rsp+0x20]
00007942783ddd3a  vmovaps xmm4, [rsp+0x30]
00007942783ddd40  vmovaps xmm5, [rsp+0x40]
00007942783ddd46  vmovaps xmm6, [rsp+0x50]
00007942783ddd4c  vmovaps xmm7, [rsp+0x60]
00007942783ddd52  vmovaps xmm8, [rsp+0x70]
00007942783ddd58  vmovaps xmm9, [rsp+0x80]
00007942783ddd61  vmovaps xmm10, [rsp+0x90]
00007942783ddd6a  vmovaps xmm11, [rsp+0xA0]
00007942783ddd73  vmovaps xmm12, [rsp+0xB0]
00007942783ddd7c  vmovaps xmm13, [rsp+0xC0]
00007942783ddd85  vmovaps xmm14, [rsp+0xD0]
00007942783ddd8e  vmovaps xmm15, [rsp+0xE0]
00007942783ddd97  add rsp, 0xF0
00007942783ddd9e  pop r11
00007942783ddda0  pop r10
00007942783ddda2  pop r9
00007942783ddda4  pop r8
00007942783ddda6  pop rsi
00007942783ddda7  pop rdi
00007942783ddda8  pop rdx
00007942783ddda9  pop rcx
00007942783dddaa  pop rax
00007942783dddab  add rsp, 0x08
00007942783dddaf  jmp 0x00007942783DBF7E
00007942783dddb4  call 0x00007942782C4620
00007942783dddb9  jmp 0x00007942783DBF8B
00007942783dddbe  sub rsp, 0x08
00007942783dddc2  push rax
00007942783dddc3  push rcx
00007942783dddc4  push rdx
00007942783dddc5  push rdi
00007942783dddc6  push rsi
00007942783dddc7  push r8
00007942783dddc9  push r9
00007942783dddcb  push r10
00007942783dddcd  push r11
00007942783dddcf  sub rsp, 0xF0
00007942783dddd6  vmovaps [rsp], xmm0
00007942783ddddb  vmovaps [rsp+0x10], xmm2
00007942783ddde1  vmovaps [rsp+0x20], xmm3
00007942783ddde7  vmovaps [rsp+0x30], xmm4
00007942783ddded  vmovaps [rsp+0x40], xmm5
00007942783dddf3  vmovaps [rsp+0x50], xmm6
00007942783dddf9  vmovaps [rsp+0x60], xmm7
00007942783dddff  vmovaps [rsp+0x70], xmm8
00007942783dde05  vmovaps [rsp+0x80], xmm9
00007942783dde0e  vmovaps [rsp+0x90], xmm10
00007942783dde17  vmovaps [rsp+0xA0], xmm11
00007942783dde20  vmovaps [rsp+0xB0], xmm12
00007942783dde29  vmovaps [rsp+0xC0], xmm13
00007942783dde32  vmovaps [rsp+0xD0], xmm14
00007942783dde3b  vmovaps [rsp+0xE0], xmm15
00007942783dde44  sub rsp, 0x30
00007942783dde48  movaps [rsp], xmm1
00007942783dde4c  movaps [rsp+0x10], xmm5
00007942783dde51  movaps [rsp+0x20], xmm7
00007942783dde56  lea rdi, [rsp]
00007942783dde5a  mov esi, 0x00
00007942783dde5f  mov rax, 0x59DDDCBA3530
00007942783dde69  call rax
00007942783dde6b  movaps xmm1, [rsp]
00007942783dde6f  add rsp, 0x30
00007942783dde73  vmovaps xmm0, [rsp]
00007942783dde78  vmovaps xmm2, [rsp+0x10]
00007942783dde7e  vmovaps xmm3, [rsp+0x20]
00007942783dde84  vmovaps xmm4, [rsp+0x30]
00007942783dde8a  vmovaps xmm5, [rsp+0x40]
00007942783dde90  vmovaps xmm6, [rsp+0x50]
00007942783dde96  vmovaps xmm7, [rsp+0x60]
00007942783dde9c  vmovaps xmm8, [rsp+0x70]
00007942783ddea2  vmovaps xmm9, [rsp+0x80]
00007942783ddeab  vmovaps xmm10, [rsp+0x90]
00007942783ddeb4  vmovaps xmm11, [rsp+0xA0]
00007942783ddebd  vmovaps xmm12, [rsp+0xB0]
00007942783ddec6  vmovaps xmm13, [rsp+0xC0]
00007942783ddecf  vmovaps xmm14, [rsp+0xD0]
00007942783dded8  vmovaps xmm15, [rsp+0xE0]
00007942783ddee1  add rsp, 0xF0
00007942783ddee8  pop r11
00007942783ddeea  pop r10
00007942783ddeec  pop r9
00007942783ddeee  pop r8
00007942783ddef0  pop rsi
00007942783ddef1  pop rdi
00007942783ddef2  pop rdx
00007942783ddef3  pop rcx
00007942783ddef4  pop rax
00007942783ddef5  add rsp, 0x08
00007942783ddef9  jmp 0x00007942783DC030
00007942783ddefe  sub rsp, 0x08
00007942783ddf02  push rax
00007942783ddf03  push rcx
00007942783ddf04  push rdx
00007942783ddf05  push rdi
00007942783ddf06  push rsi
00007942783ddf07  push r8
00007942783ddf09  push r9
00007942783ddf0b  push r10
00007942783ddf0d  push r11
00007942783ddf0f  sub rsp, 0xF0
00007942783ddf16  vmovaps [rsp], xmm0
00007942783ddf1b  vmovaps [rsp+0x10], xmm1
00007942783ddf21  vmovaps [rsp+0x20], xmm2
00007942783ddf27  vmovaps [rsp+0x30], xmm3
00007942783ddf2d  vmovaps [rsp+0x40], xmm4
00007942783ddf33  vmovaps [rsp+0x50], xmm5
00007942783ddf39  vmovaps [rsp+0x60], xmm6
00007942783ddf3f  vmovaps [rsp+0x70], xmm8
00007942783ddf45  vmovaps [rsp+0x80], xmm9
00007942783ddf4e  vmovaps [rsp+0x90], xmm10
00007942783ddf57  vmovaps [rsp+0xA0], xmm11
00007942783ddf60  vmovaps [rsp+0xB0], xmm12
00007942783ddf69  vmovaps [rsp+0xC0], xmm13
00007942783ddf72  vmovaps [rsp+0xD0], xmm14
00007942783ddf7b  vmovaps [rsp+0xE0], xmm15
00007942783ddf84  sub rsp, 0x30
00007942783ddf88  movaps [rsp], xmm7
00007942783ddf8c  movaps [rsp+0x10], xmm5
00007942783ddf91  movaps [rsp+0x20], xmm15
00007942783ddf97  lea rdi, [rsp]
00007942783ddf9b  mov esi, 0x00
00007942783ddfa0  mov rax, 0x59DDDCBA3530
00007942783ddfaa  call rax
00007942783ddfac  movaps xmm7, [rsp]
00007942783ddfb0  add rsp, 0x30
00007942783ddfb4  vmovaps xmm0, [rsp]
00007942783ddfb9  vmovaps xmm1, [rsp+0x10]
00007942783ddfbf  vmovaps xmm2, [rsp+0x20]
00007942783ddfc5  vmovaps xmm3, [rsp+0x30]
00007942783ddfcb  vmovaps xmm4, [rsp+0x40]
00007942783ddfd1  vmovaps xmm5, [rsp+0x50]
00007942783ddfd7  vmovaps xmm6, [rsp+0x60]
00007942783ddfdd  vmovaps xmm8, [rsp+0x70]
00007942783ddfe3  vmovaps xmm9, [rsp+0x80]
00007942783ddfec  vmovaps xmm10, [rsp+0x90]
00007942783ddff5  vmovaps xmm11, [rsp+0xA0]
00007942783ddffe  vmovaps xmm12, [rsp+0xB0]
00007942783de007  vmovaps xmm13, [rsp+0xC0]
00007942783de010  vmovaps xmm14, [rsp+0xD0]
00007942783de019  vmovaps xmm15, [rsp+0xE0]
00007942783de022  add rsp, 0xF0
00007942783de029  pop r11
00007942783de02b  pop r10
00007942783de02d  pop r9
00007942783de02f  pop r8
00007942783de031  pop rsi
00007942783de032  pop rdi
00007942783de033  pop rdx
00007942783de034  pop rcx
00007942783de035  pop rax
00007942783de036  add rsp, 0x08
00007942783de03a  jmp 0x00007942783DC066
00007942783de03f  call 0x00007942782B52F0
00007942783de044  jmp 0x00007942783DC073
00007942783de049  sub rsp, 0x08
00007942783de04d  push rax
00007942783de04e  push rcx
00007942783de04f  push rdx
00007942783de050  push rdi
00007942783de051  push rsi
00007942783de052  push r8
00007942783de054  push r9
00007942783de056  push r10
00007942783de058  push r11
00007942783de05a  sub rsp, 0xF0
00007942783de061  vmovaps [rsp], xmm0
00007942783de066  vmovaps [rsp+0x10], xmm1
00007942783de06c  vmovaps [rsp+0x20], xmm2
00007942783de072  vmovaps [rsp+0x30], xmm3
00007942783de078  vmovaps [rsp+0x40], xmm4
00007942783de07e  vmovaps [rsp+0x50], xmm5
00007942783de084  vmovaps [rsp+0x60], xmm6
00007942783de08a  vmovaps [rsp+0x70], xmm7
00007942783de090  vmovaps [rsp+0x80], xmm8
00007942783de099  vmovaps [rsp+0x90], xmm9
00007942783de0a2  vmovaps [rsp+0xA0], xmm10
00007942783de0ab  vmovaps [rsp+0xB0], xmm11
00007942783de0b4  vmovaps [rsp+0xC0], xmm12
00007942783de0bd  vmovaps [rsp+0xD0], xmm13
00007942783de0c6  vmovaps [rsp+0xE0], xmm14
00007942783de0cf  sub rsp, 0x30
00007942783de0d3  movaps [rsp], xmm15
00007942783de0d8  movaps [rsp+0x10], xmm5
00007942783de0dd  movaps [rsp+0x20], xmm3
00007942783de0e2  lea rdi, [rsp]
00007942783de0e6  mov esi, 0x00
00007942783de0eb  mov rax, 0x59DDDCBA3530
00007942783de0f5  call rax
00007942783de0f7  movaps xmm15, [rsp]
00007942783de0fc  add rsp, 0x30
00007942783de100  vmovaps xmm0, [rsp]
00007942783de105  vmovaps xmm1, [rsp+0x10]
00007942783de10b  vmovaps xmm2, [rsp+0x20]
00007942783de111  vmovaps xmm3, [rsp+0x30]
00007942783de117  vmovaps xmm4, [rsp+0x40]
00007942783de11d  vmovaps xmm5, [rsp+0x50]
00007942783de123  vmovaps xmm6, [rsp+0x60]
00007942783de129  vmovaps xmm7, [rsp+0x70]
00007942783de12f  vmovaps xmm8, [rsp+0x80]
00007942783de138  vmovaps xmm9, [rsp+0x90]
00007942783de141  vmovaps xmm10, [rsp+0xA0]
00007942783de14a  vmovaps xmm11, [rsp+0xB0]
00007942783de153  vmovaps xmm12, [rsp+0xC0]
00007942783de15c  vmovaps xmm13, [rsp+0xD0]
00007942783de165  vmovaps xmm14, [rsp+0xE0]
00007942783de16e  add rsp, 0xF0
00007942783de175  pop r11
00007942783de177  pop r10
00007942783de179  pop r9
00007942783de17b  pop r8
00007942783de17d  pop rsi
00007942783de17e  pop rdi
00007942783de17f  pop rdx
00007942783de180  pop rcx
00007942783de181  pop rax
00007942783de182  add rsp, 0x08
00007942783de186  jmp 0x00007942783DC099
00007942783de18b  sub rsp, 0x08
00007942783de18f  push rax
00007942783de190  push rcx
00007942783de191  push rdx
00007942783de192  push rdi
00007942783de193  push rsi
00007942783de194  push r8
00007942783de196  push r9
00007942783de198  push r10
00007942783de19a  push r11
00007942783de19c  sub rsp, 0xF0
00007942783de1a3  vmovaps [rsp], xmm0
00007942783de1a8  vmovaps [rsp+0x10], xmm2
00007942783de1ae  vmovaps [rsp+0x20], xmm3
00007942783de1b4  vmovaps [rsp+0x30], xmm4
00007942783de1ba  vmovaps [rsp+0x40], xmm5
00007942783de1c0  vmovaps [rsp+0x50], xmm6
00007942783de1c6  vmovaps [rsp+0x60], xmm7
00007942783de1cc  vmovaps [rsp+0x70], xmm8
00007942783de1d2  vmovaps [rsp+0x80], xmm9
00007942783de1db  vmovaps [rsp+0x90], xmm10
00007942783de1e4  vmovaps [rsp+0xA0], xmm11
00007942783de1ed  vmovaps [rsp+0xB0], xmm12
00007942783de1f6  vmovaps [rsp+0xC0], xmm13
00007942783de1ff  vmovaps [rsp+0xD0], xmm14
00007942783de208  vmovaps [rsp+0xE0], xmm15
00007942783de211  sub rsp, 0x30
00007942783de215  movaps [rsp], xmm1
00007942783de219  movaps [rsp+0x10], xmm5
00007942783de21e  movaps [rsp+0x20], xmm4
00007942783de223  lea rdi, [rsp]
00007942783de227  mov esi, 0x00
00007942783de22c  mov rax, 0x59DDDCBA3530
00007942783de236  call rax
00007942783de238  movaps xmm1, [rsp]
00007942783de23c  add rsp, 0x30
00007942783de240  vmovaps xmm0, [rsp]
00007942783de245  vmovaps xmm2, [rsp+0x10]
00007942783de24b  vmovaps xmm3, [rsp+0x20]
00007942783de251  vmovaps xmm4, [rsp+0x30]
00007942783de257  vmovaps xmm5, [rsp+0x40]
00007942783de25d  vmovaps xmm6, [rsp+0x50]
00007942783de263  vmovaps xmm7, [rsp+0x60]
00007942783de269  vmovaps xmm8, [rsp+0x70]
00007942783de26f  vmovaps xmm9, [rsp+0x80]
00007942783de278  vmovaps xmm10, [rsp+0x90]
00007942783de281  vmovaps xmm11, [rsp+0xA0]
00007942783de28a  vmovaps xmm12, [rsp+0xB0]
00007942783de293  vmovaps xmm13, [rsp+0xC0]
00007942783de29c  vmovaps xmm14, [rsp+0xD0]
00007942783de2a5  vmovaps xmm15, [rsp+0xE0]
00007942783de2ae  add rsp, 0xF0
00007942783de2b5  pop r11
00007942783de2b7  pop r10
00007942783de2b9  pop r9
00007942783de2bb  pop r8
00007942783de2bd  pop rsi
00007942783de2be  pop rdi
00007942783de2bf  pop rdx
00007942783de2c0  pop rcx
00007942783de2c1  pop rax
00007942783de2c2  add rsp, 0x08
00007942783de2c6  jmp 0x00007942783DC0B9
00007942783de2cb  sub rsp, 0x08
00007942783de2cf  push rax
00007942783de2d0  push rcx
00007942783de2d1  push rdx
00007942783de2d2  push rdi
00007942783de2d3  push rsi
00007942783de2d4  push r8
00007942783de2d6  push r9
00007942783de2d8  push r10
00007942783de2da  push r11
00007942783de2dc  sub rsp, 0xF0
00007942783de2e3  vmovaps [rsp], xmm0
00007942783de2e8  vmovaps [rsp+0x10], xmm1
00007942783de2ee  vmovaps [rsp+0x20], xmm2
00007942783de2f4  vmovaps [rsp+0x30], xmm3
00007942783de2fa  vmovaps [rsp+0x40], xmm5
00007942783de300  vmovaps [rsp+0x50], xmm6
00007942783de306  vmovaps [rsp+0x60], xmm7
00007942783de30c  vmovaps [rsp+0x70], xmm8
00007942783de312  vmovaps [rsp+0x80], xmm9
00007942783de31b  vmovaps [rsp+0x90], xmm10
00007942783de324  vmovaps [rsp+0xA0], xmm11
00007942783de32d  vmovaps [rsp+0xB0], xmm12
00007942783de336  vmovaps [rsp+0xC0], xmm13
00007942783de33f  vmovaps [rsp+0xD0], xmm14
00007942783de348  vmovaps [rsp+0xE0], xmm15
00007942783de351  sub rsp, 0x30
00007942783de355  movaps [rsp], xmm4
00007942783de359  movaps [rsp+0x10], xmm3
00007942783de35e  movaps [rsp+0x20], xmm5
00007942783de363  lea rdi, [rsp]
00007942783de367  mov esi, 0x00
00007942783de36c  mov rax, 0x59DDDCBA3530
00007942783de376  call rax
00007942783de378  movaps xmm4, [rsp]
00007942783de37c  add rsp, 0x30
00007942783de380  vmovaps xmm0, [rsp]
00007942783de385  vmovaps xmm1, [rsp+0x10]
00007942783de38b  vmovaps xmm2, [rsp+0x20]
00007942783de391  vmovaps xmm3, [rsp+0x30]
00007942783de397  vmovaps xmm5, [rsp+0x40]
00007942783de39d  vmovaps xmm6, [rsp+0x50]
00007942783de3a3  vmovaps xmm7, [rsp+0x60]
00007942783de3a9  vmovaps xmm8, [rsp+0x70]
00007942783de3af  vmovaps xmm9, [rsp+0x80]
00007942783de3b8  vmovaps xmm10, [rsp+0x90]
00007942783de3c1  vmovaps xmm11, [rsp+0xA0]
00007942783de3ca  vmovaps xmm12, [rsp+0xB0]
00007942783de3d3  vmovaps xmm13, [rsp+0xC0]
00007942783de3dc  vmovaps xmm14, [rsp+0xD0]
00007942783de3e5  vmovaps xmm15, [rsp+0xE0]
00007942783de3ee  add rsp, 0xF0
00007942783de3f5  pop r11
00007942783de3f7  pop r10
00007942783de3f9  pop r9
00007942783de3fb  pop r8
00007942783de3fd  pop rsi
00007942783de3fe  pop rdi
00007942783de3ff  pop rdx
00007942783de400  pop rcx
00007942783de401  pop rax
00007942783de402  add rsp, 0x08
00007942783de406  jmp 0x00007942783DC107
00007942783de40b  call 0x00007942782B52F0
00007942783de410  jmp 0x00007942783DC114
00007942783de415  sub rsp, 0x08
00007942783de419  push rax
00007942783de41a  push rcx
00007942783de41b  push rdx
00007942783de41c  push rdi
00007942783de41d  push rsi
00007942783de41e  push r8
00007942783de420  push r9
00007942783de422  push r10
00007942783de424  push r11
00007942783de426  sub rsp, 0xF0
00007942783de42d  vmovaps [rsp], xmm0
00007942783de432  vmovaps [rsp+0x10], xmm1
00007942783de438  vmovaps [rsp+0x20], xmm2
00007942783de43e  vmovaps [rsp+0x30], xmm3
00007942783de444  vmovaps [rsp+0x40], xmm4
00007942783de44a  vmovaps [rsp+0x50], xmm6
00007942783de450  vmovaps [rsp+0x60], xmm7
00007942783de456  vmovaps [rsp+0x70], xmm8
00007942783de45c  vmovaps [rsp+0x80], xmm9
00007942783de465  vmovaps [rsp+0x90], xmm10
00007942783de46e  vmovaps [rsp+0xA0], xmm11
00007942783de477  vmovaps [rsp+0xB0], xmm12
00007942783de480  vmovaps [rsp+0xC0], xmm13
00007942783de489  vmovaps [rsp+0xD0], xmm14
00007942783de492  vmovaps [rsp+0xE0], xmm15
00007942783de49b  sub rsp, 0x30
00007942783de49f  movaps [rsp], xmm5
00007942783de4a3  movaps [rsp+0x10], xmm6
00007942783de4a8  movaps [rsp+0x20], xmm3
00007942783de4ad  lea rdi, [rsp]
00007942783de4b1  mov esi, 0x00
00007942783de4b6  mov rax, 0x59DDDCBA3530
00007942783de4c0  call rax
00007942783de4c2  movaps xmm5, [rsp]
00007942783de4c6  add rsp, 0x30
00007942783de4ca  vmovaps xmm0, [rsp]
00007942783de4cf  vmovaps xmm1, [rsp+0x10]
00007942783de4d5  vmovaps xmm2, [rsp+0x20]
00007942783de4db  vmovaps xmm3, [rsp+0x30]
00007942783de4e1  vmovaps xmm4, [rsp+0x40]
00007942783de4e7  vmovaps xmm6, [rsp+0x50]
00007942783de4ed  vmovaps xmm7, [rsp+0x60]
00007942783de4f3  vmovaps xmm8, [rsp+0x70]
00007942783de4f9  vmovaps xmm9, [rsp+0x80]
00007942783de502  vmovaps xmm10, [rsp+0x90]
00007942783de50b  vmovaps xmm11, [rsp+0xA0]
00007942783de514  vmovaps xmm12, [rsp+0xB0]
00007942783de51d  vmovaps xmm13, [rsp+0xC0]
00007942783de526  vmovaps xmm14, [rsp+0xD0]
00007942783de52f  vmovaps xmm15, [rsp+0xE0]
00007942783de538  add rsp, 0xF0
00007942783de53f  pop r11
00007942783de541  pop r10
00007942783de543  pop r9
00007942783de545  pop r8
00007942783de547  pop rsi
00007942783de548  pop rdi
00007942783de549  pop rdx
00007942783de54a  pop rcx
00007942783de54b  pop rax
00007942783de54c  add rsp, 0x08
00007942783de550  jmp 0x00007942783DC13A
00007942783de555  sub rsp, 0x08
00007942783de559  push rax
00007942783de55a  push rcx
00007942783de55b  push rdx
00007942783de55c  push rdi
00007942783de55d  push rsi
00007942783de55e  push r8
00007942783de560  push r9
00007942783de562  push r10
00007942783de564  push r11
00007942783de566  sub rsp, 0xF0
00007942783de56d  vmovaps [rsp], xmm0
00007942783de572  vmovaps [rsp+0x10], xmm1
00007942783de578  vmovaps [rsp+0x20], xmm2
00007942783de57e  vmovaps [rsp+0x30], xmm3
00007942783de584  vmovaps [rsp+0x40], xmm4
00007942783de58a  vmovaps [rsp+0x50], xmm5
00007942783de590  vmovaps [rsp+0x60], xmm7
00007942783de596  vmovaps [rsp+0x70], xmm8
00007942783de59c  vmovaps [rsp+0x80], xmm9
00007942783de5a5  vmovaps [rsp+0x90], xmm10
00007942783de5ae  vmovaps [rsp+0xA0], xmm11
00007942783de5b7  vmovaps [rsp+0xB0], xmm12
00007942783de5c0  vmovaps [rsp+0xC0], xmm13
00007942783de5c9  vmovaps [rsp+0xD0], xmm14
00007942783de5d2  vmovaps [rsp+0xE0], xmm15
00007942783de5db  sub rsp, 0x30
00007942783de5df  movaps [rsp], xmm6
00007942783de5e3  movaps [rsp+0x10], xmm9
00007942783de5e9  movaps [rsp+0x20], xmm1
00007942783de5ee  lea rdi, [rsp]
00007942783de5f2  mov esi, 0x00
00007942783de5f7  mov rax, 0x59DDDCBA3530
00007942783de601  call rax
00007942783de603  movaps xmm6, [rsp]
00007942783de607  add rsp, 0x30
00007942783de60b  vmovaps xmm0, [rsp]
00007942783de610  vmovaps xmm1, [rsp+0x10]
00007942783de616  vmovaps xmm2, [rsp+0x20]
00007942783de61c  vmovaps xmm3, [rsp+0x30]
00007942783de622  vmovaps xmm4, [rsp+0x40]
00007942783de628  vmovaps xmm5, [rsp+0x50]
00007942783de62e  vmovaps xmm7, [rsp+0x60]
00007942783de634  vmovaps xmm8, [rsp+0x70]
00007942783de63a  vmovaps xmm9, [rsp+0x80]
00007942783de643  vmovaps xmm10, [rsp+0x90]
00007942783de64c  vmovaps xmm11, [rsp+0xA0]
00007942783de655  vmovaps xmm12, [rsp+0xB0]
00007942783de65e  vmovaps xmm13, [rsp+0xC0]
00007942783de667  vmovaps xmm14, [rsp+0xD0]
00007942783de670  vmovaps xmm15, [rsp+0xE0]
00007942783de679  add rsp, 0xF0
00007942783de680  pop r11
00007942783de682  pop r10
00007942783de684  pop r9
00007942783de686  pop r8
00007942783de688  pop rsi
00007942783de689  pop rdi
00007942783de68a  pop rdx
00007942783de68b  pop rcx
00007942783de68c  pop rax
00007942783de68d  add rsp, 0x08
00007942783de691  jmp 0x00007942783DC15E
00007942783de696  sub rsp, 0x08
00007942783de69a  push rax
00007942783de69b  push rcx
00007942783de69c  push rdx
00007942783de69d  push rdi
00007942783de69e  push rsi
00007942783de69f  push r8
00007942783de6a1  push r9
00007942783de6a3  push r10
00007942783de6a5  push r11
00007942783de6a7  sub rsp, 0xF0
00007942783de6ae  vmovaps [rsp], xmm0
00007942783de6b3  vmovaps [rsp+0x10], xmm1
00007942783de6b9  vmovaps [rsp+0x20], xmm2
00007942783de6bf  vmovaps [rsp+0x30], xmm3
00007942783de6c5  vmovaps [rsp+0x40], xmm4
00007942783de6cb  vmovaps [rsp+0x50], xmm5
00007942783de6d1  vmovaps [rsp+0x60], xmm6
00007942783de6d7  vmovaps [rsp+0x70], xmm7
00007942783de6dd  vmovaps [rsp+0x80], xmm8
00007942783de6e6  vmovaps [rsp+0x90], xmm10
00007942783de6ef  vmovaps [rsp+0xA0], xmm11
00007942783de6f8  vmovaps [rsp+0xB0], xmm12
00007942783de701  vmovaps [rsp+0xC0], xmm13
00007942783de70a  vmovaps [rsp+0xD0], xmm14
00007942783de713  vmovaps [rsp+0xE0], xmm15
00007942783de71c  sub rsp, 0x30
00007942783de720  movaps [rsp], xmm9
00007942783de725  movaps [rsp+0x10], xmm3
00007942783de72a  movaps [rsp+0x20], xmm1
00007942783de72f  lea rdi, [rsp]
00007942783de733  mov esi, 0x00
00007942783de738  mov rax, 0x59DDDCBA3530
00007942783de742  call rax
00007942783de744  movaps xmm9, [rsp]
00007942783de749  add rsp, 0x30
00007942783de74d  vmovaps xmm0, [rsp]
00007942783de752  vmovaps xmm1, [rsp+0x10]
00007942783de758  vmovaps xmm2, [rsp+0x20]
00007942783de75e  vmovaps xmm3, [rsp+0x30]
00007942783de764  vmovaps xmm4, [rsp+0x40]
00007942783de76a  vmovaps xmm5, [rsp+0x50]
00007942783de770  vmovaps xmm6, [rsp+0x60]
00007942783de776  vmovaps xmm7, [rsp+0x70]
00007942783de77c  vmovaps xmm8, [rsp+0x80]
00007942783de785  vmovaps xmm10, [rsp+0x90]
00007942783de78e  vmovaps xmm11, [rsp+0xA0]
00007942783de797  vmovaps xmm12, [rsp+0xB0]
00007942783de7a0  vmovaps xmm13, [rsp+0xC0]
00007942783de7a9  vmovaps xmm14, [rsp+0xD0]
00007942783de7b2  vmovaps xmm15, [rsp+0xE0]
00007942783de7bb  add rsp, 0xF0
00007942783de7c2  pop r11
00007942783de7c4  pop r10
00007942783de7c6  pop r9
00007942783de7c8  pop r8
00007942783de7ca  pop rsi
00007942783de7cb  pop rdi
00007942783de7cc  pop rdx
00007942783de7cd  pop rcx
00007942783de7ce  pop rax
00007942783de7cf  add rsp, 0x08
00007942783de7d3  jmp 0x00007942783DC1AA
00007942783de7d8  call 0x00007942782B52F0
00007942783de7dd  jmp 0x00007942783DC1B7
00007942783de7e2  sub rsp, 0x08
00007942783de7e6  push rax
00007942783de7e7  push rcx
00007942783de7e8  push rdx
00007942783de7e9  push rdi
00007942783de7ea  push rsi
00007942783de7eb  push r8
00007942783de7ed  push r9
00007942783de7ef  push r10
00007942783de7f1  push r11
00007942783de7f3  sub rsp, 0xF0
00007942783de7fa  vmovaps [rsp], xmm0
00007942783de7ff  vmovaps [rsp+0x10], xmm1
00007942783de805  vmovaps [rsp+0x20], xmm2
00007942783de80b  vmovaps [rsp+0x30], xmm3
00007942783de811  vmovaps [rsp+0x40], xmm4
00007942783de817  vmovaps [rsp+0x50], xmm5
00007942783de81d  vmovaps [rsp+0x60], xmm6
00007942783de823  vmovaps [rsp+0x70], xmm7
00007942783de829  vmovaps [rsp+0x80], xmm8
00007942783de832  vmovaps [rsp+0x90], xmm9
00007942783de83b  vmovaps [rsp+0xA0], xmm10
00007942783de844  vmovaps [rsp+0xB0], xmm11
00007942783de84d  vmovaps [rsp+0xC0], xmm12
00007942783de856  vmovaps [rsp+0xD0], xmm13
00007942783de85f  vmovaps [rsp+0xE0], xmm14
00007942783de868  sub rsp, 0x30
00007942783de86c  movaps [rsp], xmm15
00007942783de871  movaps [rsp+0x10], xmm3
00007942783de876  movaps [rsp+0x20], xmm7
00007942783de87b  lea rdi, [rsp]
00007942783de87f  mov esi, 0x00
00007942783de884  mov rax, 0x59DDDCBA3530
00007942783de88e  call rax
00007942783de890  movaps xmm15, [rsp]
00007942783de895  add rsp, 0x30
00007942783de899  vmovaps xmm0, [rsp]
00007942783de89e  vmovaps xmm1, [rsp+0x10]
00007942783de8a4  vmovaps xmm2, [rsp+0x20]
00007942783de8aa  vmovaps xmm3, [rsp+0x30]
00007942783de8b0  vmovaps xmm4, [rsp+0x40]
00007942783de8b6  vmovaps xmm5, [rsp+0x50]
00007942783de8bc  vmovaps xmm6, [rsp+0x60]
00007942783de8c2  vmovaps xmm7, [rsp+0x70]
00007942783de8c8  vmovaps xmm8, [rsp+0x80]
00007942783de8d1  vmovaps xmm9, [rsp+0x90]
00007942783de8da  vmovaps xmm10, [rsp+0xA0]
00007942783de8e3  vmovaps xmm11, [rsp+0xB0]
00007942783de8ec  vmovaps xmm12, [rsp+0xC0]
00007942783de8f5  vmovaps xmm13, [rsp+0xD0]
00007942783de8fe  vmovaps xmm14, [rsp+0xE0]
00007942783de907  add rsp, 0xF0
00007942783de90e  pop r11
00007942783de910  pop r10
00007942783de912  pop r9
00007942783de914  pop r8
00007942783de916  pop rsi
00007942783de917  pop rdi
00007942783de918  pop rdx
00007942783de919  pop rcx
00007942783de91a  pop rax
00007942783de91b  add rsp, 0x08
00007942783de91f  jmp 0x00007942783DC1E3
00007942783de924  sub rsp, 0x08
00007942783de928  push rax
00007942783de929  push rcx
00007942783de92a  push rdx
00007942783de92b  push rdi
00007942783de92c  push rsi
00007942783de92d  push r8
00007942783de92f  push r9
00007942783de931  push r10
00007942783de933  push r11
00007942783de935  sub rsp, 0xF0
00007942783de93c  vmovaps [rsp], xmm0
00007942783de941  vmovaps [rsp+0x10], xmm1
00007942783de947  vmovaps [rsp+0x20], xmm2
00007942783de94d  vmovaps [rsp+0x30], xmm4
00007942783de953  vmovaps [rsp+0x40], xmm5
00007942783de959  vmovaps [rsp+0x50], xmm6
00007942783de95f  vmovaps [rsp+0x60], xmm7
00007942783de965  vmovaps [rsp+0x70], xmm8
00007942783de96b  vmovaps [rsp+0x80], xmm9
00007942783de974  vmovaps [rsp+0x90], xmm10
00007942783de97d  vmovaps [rsp+0xA0], xmm11
00007942783de986  vmovaps [rsp+0xB0], xmm12
00007942783de98f  vmovaps [rsp+0xC0], xmm13
00007942783de998  vmovaps [rsp+0xD0], xmm14
00007942783de9a1  vmovaps [rsp+0xE0], xmm15
00007942783de9aa  sub rsp, 0x30
00007942783de9ae  movaps [rsp], xmm3
00007942783de9b2  movaps [rsp+0x10], xmm1
00007942783de9b7  movaps [rsp+0x20], xmm15
00007942783de9bd  lea rdi, [rsp]
00007942783de9c1  mov esi, 0x00
00007942783de9c6  mov rax, 0x59DDDCBA3530
00007942783de9d0  call rax
00007942783de9d2  movaps xmm3, [rsp]
00007942783de9d6  add rsp, 0x30
00007942783de9da  vmovaps xmm0, [rsp]
00007942783de9df  vmovaps xmm1, [rsp+0x10]
00007942783de9e5  vmovaps xmm2, [rsp+0x20]
00007942783de9eb  vmovaps xmm4, [rsp+0x30]
00007942783de9f1  vmovaps xmm5, [rsp+0x40]
00007942783de9f7  vmovaps xmm6, [rsp+0x50]
00007942783de9fd  vmovaps xmm7, [rsp+0x60]
00007942783dea03  vmovaps xmm8, [rsp+0x70]
00007942783dea09  vmovaps xmm9, [rsp+0x80]
00007942783dea12  vmovaps xmm10, [rsp+0x90]
00007942783dea1b  vmovaps xmm11, [rsp+0xA0]
00007942783dea24  vmovaps xmm12, [rsp+0xB0]
00007942783dea2d  vmovaps xmm13, [rsp+0xC0]
00007942783dea36  vmovaps xmm14, [rsp+0xD0]
00007942783dea3f  vmovaps xmm15, [rsp+0xE0]
00007942783dea48  add rsp, 0xF0
00007942783dea4f  pop r11
00007942783dea51  pop r10
00007942783dea53  pop r9
00007942783dea55  pop r8
00007942783dea57  pop rsi
00007942783dea58  pop rdi
00007942783dea59  pop rdx
00007942783dea5a  pop rcx
00007942783dea5b  pop rax
00007942783dea5c  add rsp, 0x08
00007942783dea60  jmp 0x00007942783DC272
00007942783dea65  call 0x00007942782B52F0
00007942783dea6a  jmp 0x00007942783DC27C
00007942783dea6f  sub rsp, 0x08
00007942783dea73  push rax
00007942783dea74  push rcx
00007942783dea75  push rdx
00007942783dea76  push rdi
00007942783dea77  push rsi
00007942783dea78  push r8
00007942783dea7a  push r9
00007942783dea7c  push r10
00007942783dea7e  push r11
00007942783dea80  sub rsp, 0xF0
00007942783dea87  vmovaps [rsp], xmm0
00007942783dea8c  vmovaps [rsp+0x10], xmm1
00007942783dea92  vmovaps [rsp+0x20], xmm2
00007942783dea98  vmovaps [rsp+0x30], xmm3
00007942783dea9e  vmovaps [rsp+0x40], xmm4
00007942783deaa4  vmovaps [rsp+0x50], xmm5
00007942783deaaa  vmovaps [rsp+0x60], xmm6
00007942783deab0  vmovaps [rsp+0x70], xmm7
00007942783deab6  vmovaps [rsp+0x80], xmm8
00007942783deabf  vmovaps [rsp+0x90], xmm9
00007942783deac8  vmovaps [rsp+0xA0], xmm10
00007942783dead1  vmovaps [rsp+0xB0], xmm11
00007942783deada  vmovaps [rsp+0xC0], xmm12
00007942783deae3  vmovaps [rsp+0xD0], xmm13
00007942783deaec  vmovaps [rsp+0xE0], xmm14
00007942783deaf5  sub rsp, 0x30
00007942783deaf9  movaps [rsp], xmm15
00007942783deafe  movaps [rsp+0x10], xmm14
00007942783deb04  movaps [rsp+0x20], xmm4
00007942783deb09  lea rdi, [rsp]
00007942783deb0d  mov esi, 0x00
00007942783deb12  mov rax, 0x59DDDCBA3530
00007942783deb1c  call rax
00007942783deb1e  movaps xmm15, [rsp]
00007942783deb23  add rsp, 0x30
00007942783deb27  vmovaps xmm0, [rsp]
00007942783deb2c  vmovaps xmm1, [rsp+0x10]
00007942783deb32  vmovaps xmm2, [rsp+0x20]
00007942783deb38  vmovaps xmm3, [rsp+0x30]
00007942783deb3e  vmovaps xmm4, [rsp+0x40]
00007942783deb44  vmovaps xmm5, [rsp+0x50]
00007942783deb4a  vmovaps xmm6, [rsp+0x60]
00007942783deb50  vmovaps xmm7, [rsp+0x70]
00007942783deb56  vmovaps xmm8, [rsp+0x80]
00007942783deb5f  vmovaps xmm9, [rsp+0x90]
00007942783deb68  vmovaps xmm10, [rsp+0xA0]
00007942783deb71  vmovaps xmm11, [rsp+0xB0]
00007942783deb7a  vmovaps xmm12, [rsp+0xC0]
00007942783deb83  vmovaps xmm13, [rsp+0xD0]
00007942783deb8c  vmovaps xmm14, [rsp+0xE0]
00007942783deb95  add rsp, 0xF0
00007942783deb9c  pop r11
00007942783deb9e  pop r10
00007942783deba0  pop r9
00007942783deba2  pop r8
00007942783deba4  pop rsi
00007942783deba5  pop rdi
00007942783deba6  pop rdx
00007942783deba7  pop rcx
00007942783deba8  pop rax
00007942783deba9  add rsp, 0x08
00007942783debad  jmp 0x00007942783DC2AA
00007942783debb2  sub rsp, 0x08
00007942783debb6  push rax
00007942783debb7  push rcx
00007942783debb8  push rdx
00007942783debb9  push rdi
00007942783debba  push rsi
00007942783debbb  push r8
00007942783debbd  push r9
00007942783debbf  push r10
00007942783debc1  push r11
00007942783debc3  sub rsp, 0xF0
00007942783debca  vmovaps [rsp], xmm0
00007942783debcf  vmovaps [rsp+0x10], xmm1
00007942783debd5  vmovaps [rsp+0x20], xmm2
00007942783debdb  vmovaps [rsp+0x30], xmm3
00007942783debe1  vmovaps [rsp+0x40], xmm4
00007942783debe7  vmovaps [rsp+0x50], xmm5
00007942783debed  vmovaps [rsp+0x60], xmm6
00007942783debf3  vmovaps [rsp+0x70], xmm7
00007942783debf9  vmovaps [rsp+0x80], xmm8
00007942783dec02  vmovaps [rsp+0x90], xmm9
00007942783dec0b  vmovaps [rsp+0xA0], xmm10
00007942783dec14  vmovaps [rsp+0xB0], xmm11
00007942783dec1d  vmovaps [rsp+0xC0], xmm12
00007942783dec26  vmovaps [rsp+0xD0], xmm13
00007942783dec2f  vmovaps [rsp+0xE0], xmm15
00007942783dec38  sub rsp, 0x30
00007942783dec3c  movaps [rsp], xmm14
00007942783dec41  movaps [rsp+0x10], xmm2
00007942783dec46  movaps [rsp+0x20], xmm1
00007942783dec4b  lea rdi, [rsp]
00007942783dec4f  mov esi, 0x00
00007942783dec54  mov rax, 0x59DDDCBA3530
00007942783dec5e  call rax
00007942783dec60  movaps xmm14, [rsp]
00007942783dec65  add rsp, 0x30
00007942783dec69  vmovaps xmm0, [rsp]
00007942783dec6e  vmovaps xmm1, [rsp+0x10]
00007942783dec74  vmovaps xmm2, [rsp+0x20]
00007942783dec7a  vmovaps xmm3, [rsp+0x30]
00007942783dec80  vmovaps xmm4, [rsp+0x40]
00007942783dec86  vmovaps xmm5, [rsp+0x50]
00007942783dec8c  vmovaps xmm6, [rsp+0x60]
00007942783dec92  vmovaps xmm7, [rsp+0x70]
00007942783dec98  vmovaps xmm8, [rsp+0x80]
00007942783deca1  vmovaps xmm9, [rsp+0x90]
00007942783decaa  vmovaps xmm10, [rsp+0xA0]
00007942783decb3  vmovaps xmm11, [rsp+0xB0]
00007942783decbc  vmovaps xmm12, [rsp+0xC0]
00007942783decc5  vmovaps xmm13, [rsp+0xD0]
00007942783decce  vmovaps xmm15, [rsp+0xE0]
00007942783decd7  add rsp, 0xF0
00007942783decde  pop r11
00007942783dece0  pop r10
00007942783dece2  pop r9
00007942783dece4  pop r8
00007942783dece6  pop rsi
00007942783dece7  pop rdi
00007942783dece8  pop rdx
00007942783dece9  pop rcx
00007942783decea  pop rax
00007942783deceb  add rsp, 0x08
00007942783decef  jmp 0x00007942783DC2D0
00007942783decf4  sub rsp, 0x08
00007942783decf8  push rax
00007942783decf9  push rcx
00007942783decfa  push rdx
00007942783decfb  push rdi
00007942783decfc  push rsi
00007942783decfd  push r8
00007942783decff  push r9
00007942783ded01  push r10
00007942783ded03  push r11
00007942783ded05  sub rsp, 0xF0
00007942783ded0c  vmovaps [rsp], xmm0
00007942783ded11  vmovaps [rsp+0x10], xmm2
00007942783ded17  vmovaps [rsp+0x20], xmm3
00007942783ded1d  vmovaps [rsp+0x30], xmm4
00007942783ded23  vmovaps [rsp+0x40], xmm5
00007942783ded29  vmovaps [rsp+0x50], xmm6
00007942783ded2f  vmovaps [rsp+0x60], xmm7
00007942783ded35  vmovaps [rsp+0x70], xmm8
00007942783ded3b  vmovaps [rsp+0x80], xmm9
00007942783ded44  vmovaps [rsp+0x90], xmm10
00007942783ded4d  vmovaps [rsp+0xA0], xmm11
00007942783ded56  vmovaps [rsp+0xB0], xmm12
00007942783ded5f  vmovaps [rsp+0xC0], xmm13
00007942783ded68  vmovaps [rsp+0xD0], xmm14
00007942783ded71  vmovaps [rsp+0xE0], xmm15
00007942783ded7a  sub rsp, 0x30
00007942783ded7e  movaps [rsp], xmm1
00007942783ded82  movaps [rsp+0x10], xmm4
00007942783ded87  movaps [rsp+0x20], xmm9
00007942783ded8d  lea rdi, [rsp]
00007942783ded91  mov esi, 0x00
00007942783ded96  mov rax, 0x59DDDCBA3530
00007942783deda0  call rax
00007942783deda2  movaps xmm1, [rsp]
00007942783deda6  add rsp, 0x30
00007942783dedaa  vmovaps xmm0, [rsp]
00007942783dedaf  vmovaps xmm2, [rsp+0x10]
00007942783dedb5  vmovaps xmm3, [rsp+0x20]
00007942783dedbb  vmovaps xmm4, [rsp+0x30]
00007942783dedc1  vmovaps xmm5, [rsp+0x40]
00007942783dedc7  vmovaps xmm6, [rsp+0x50]
00007942783dedcd  vmovaps xmm7, [rsp+0x60]
00007942783dedd3  vmovaps xmm8, [rsp+0x70]
00007942783dedd9  vmovaps xmm9, [rsp+0x80]
00007942783dede2  vmovaps xmm10, [rsp+0x90]
00007942783dedeb  vmovaps xmm11, [rsp+0xA0]
00007942783dedf4  vmovaps xmm12, [rsp+0xB0]
00007942783dedfd  vmovaps xmm13, [rsp+0xC0]
00007942783dee06  vmovaps xmm14, [rsp+0xD0]
00007942783dee0f  vmovaps xmm15, [rsp+0xE0]
00007942783dee18  add rsp, 0xF0
00007942783dee1f  pop r11
00007942783dee21  pop r10
00007942783dee23  pop r9
00007942783dee25  pop r8
00007942783dee27  pop rsi
00007942783dee28  pop rdi
00007942783dee29  pop rdx
00007942783dee2a  pop rcx
00007942783dee2b  pop rax
00007942783dee2c  add rsp, 0x08
00007942783dee30  jmp 0x00007942783DC2EE
00007942783dee35  sub rsp, 0x08
00007942783dee39  push rax
00007942783dee3a  push rcx
00007942783dee3b  push rdx
00007942783dee3c  push rdi
00007942783dee3d  push rsi
00007942783dee3e  push r8
00007942783dee40  push r9
00007942783dee42  push r10
00007942783dee44  push r11
00007942783dee46  sub rsp, 0xF0
00007942783dee4d  vmovaps [rsp], xmm0
00007942783dee52  vmovaps [rsp+0x10], xmm1
00007942783dee58  vmovaps [rsp+0x20], xmm2
00007942783dee5e  vmovaps [rsp+0x30], xmm3
00007942783dee64  vmovaps [rsp+0x40], xmm5
00007942783dee6a  vmovaps [rsp+0x50], xmm6
00007942783dee70  vmovaps [rsp+0x60], xmm7
00007942783dee76  vmovaps [rsp+0x70], xmm8
00007942783dee7c  vmovaps [rsp+0x80], xmm9
00007942783dee85  vmovaps [rsp+0x90], xmm10
00007942783dee8e  vmovaps [rsp+0xA0], xmm11
00007942783dee97  vmovaps [rsp+0xB0], xmm12
00007942783deea0  vmovaps [rsp+0xC0], xmm13
00007942783deea9  vmovaps [rsp+0xD0], xmm14
00007942783deeb2  vmovaps [rsp+0xE0], xmm15
00007942783deebb  sub rsp, 0x30
00007942783deebf  movaps [rsp], xmm4
00007942783deec3  movaps [rsp+0x10], xmm2
00007942783deec8  movaps [rsp+0x20], xmm9
00007942783deece  lea rdi, [rsp]
00007942783deed2  mov esi, 0x00
00007942783deed7  mov rax, 0x59DDDCBA3530
00007942783deee1  call rax
00007942783deee3  movaps xmm4, [rsp]
00007942783deee7  add rsp, 0x30
00007942783deeeb  vmovaps xmm0, [rsp]
00007942783deef0  vmovaps xmm1, [rsp+0x10]
00007942783deef6  vmovaps xmm2, [rsp+0x20]
00007942783deefc  vmovaps xmm3, [rsp+0x30]
00007942783def02  vmovaps xmm5, [rsp+0x40]
00007942783def08  vmovaps xmm6, [rsp+0x50]
00007942783def0e  vmovaps xmm7, [rsp+0x60]
00007942783def14  vmovaps xmm8, [rsp+0x70]
00007942783def1a  vmovaps xmm9, [rsp+0x80]
00007942783def23  vmovaps xmm10, [rsp+0x90]
00007942783def2c  vmovaps xmm11, [rsp+0xA0]
00007942783def35  vmovaps xmm12, [rsp+0xB0]
00007942783def3e  vmovaps xmm13, [rsp+0xC0]
00007942783def47  vmovaps xmm14, [rsp+0xD0]
00007942783def50  vmovaps xmm15, [rsp+0xE0]
00007942783def59  add rsp, 0xF0
00007942783def60  pop r11
00007942783def62  pop r10
00007942783def64  pop r9
00007942783def66  pop r8
00007942783def68  pop rsi
00007942783def69  pop rdi
00007942783def6a  pop rdx
00007942783def6b  pop rcx
00007942783def6c  pop rax
00007942783def6d  add rsp, 0x08
00007942783def71  jmp 0x00007942783DC31E
00007942783def76  sub rsp, 0x08
00007942783def7a  push rax
00007942783def7b  push rcx
00007942783def7c  push rdx
00007942783def7d  push rdi
00007942783def7e  push rsi
00007942783def7f  push r8
00007942783def81  push r9
00007942783def83  push r10
00007942783def85  push r11
00007942783def87  sub rsp, 0xF0
00007942783def8e  vmovaps [rsp], xmm0
00007942783def93  vmovaps [rsp+0x10], xmm1
00007942783def99  vmovaps [rsp+0x20], xmm2
00007942783def9f  vmovaps [rsp+0x30], xmm3
00007942783defa5  vmovaps [rsp+0x40], xmm4
00007942783defab  vmovaps [rsp+0x50], xmm5
00007942783defb1  vmovaps [rsp+0x60], xmm6
00007942783defb7  vmovaps [rsp+0x70], xmm7
00007942783defbd  vmovaps [rsp+0x80], xmm8
00007942783defc6  vmovaps [rsp+0x90], xmm10
00007942783defcf  vmovaps [rsp+0xA0], xmm11
00007942783defd8  vmovaps [rsp+0xB0], xmm12
00007942783defe1  vmovaps [rsp+0xC0], xmm13
00007942783defea  vmovaps [rsp+0xD0], xmm14
00007942783deff3  vmovaps [rsp+0xE0], xmm15
00007942783deffc  sub rsp, 0x30
00007942783df000  movaps [rsp], xmm9
00007942783df005  movaps [rsp+0x10], xmm2
00007942783df00a  movaps [rsp+0x20], xmm1
00007942783df00f  lea rdi, [rsp]
00007942783df013  mov esi, 0x00
00007942783df018  mov rax, 0x59DDDCBA3530
00007942783df022  call rax
00007942783df024  movaps xmm9, [rsp]
00007942783df029  add rsp, 0x30
00007942783df02d  vmovaps xmm0, [rsp]
00007942783df032  vmovaps xmm1, [rsp+0x10]
00007942783df038  vmovaps xmm2, [rsp+0x20]
00007942783df03e  vmovaps xmm3, [rsp+0x30]
00007942783df044  vmovaps xmm4, [rsp+0x40]
00007942783df04a  vmovaps xmm5, [rsp+0x50]
00007942783df050  vmovaps xmm6, [rsp+0x60]
00007942783df056  vmovaps xmm7, [rsp+0x70]
00007942783df05c  vmovaps xmm8, [rsp+0x80]
00007942783df065  vmovaps xmm10, [rsp+0x90]
00007942783df06e  vmovaps xmm11, [rsp+0xA0]
00007942783df077  vmovaps xmm12, [rsp+0xB0]
00007942783df080  vmovaps xmm13, [rsp+0xC0]
00007942783df089  vmovaps xmm14, [rsp+0xD0]
00007942783df092  vmovaps xmm15, [rsp+0xE0]
00007942783df09b  add rsp, 0xF0
00007942783df0a2  pop r11
00007942783df0a4  pop r10
00007942783df0a6  pop r9
00007942783df0a8  pop r8
00007942783df0aa  pop rsi
00007942783df0ab  pop rdi
00007942783df0ac  pop rdx
00007942783df0ad  pop rcx
00007942783df0ae  pop rax
00007942783df0af  add rsp, 0x08
00007942783df0b3  jmp 0x00007942783DC354
00007942783df0b8  sub rsp, 0x08
00007942783df0bc  push rax
00007942783df0bd  push rcx
00007942783df0be  push rdx
00007942783df0bf  push rdi
00007942783df0c0  push rsi
00007942783df0c1  push r8
00007942783df0c3  push r9
00007942783df0c5  push r10
00007942783df0c7  push r11
00007942783df0c9  sub rsp, 0xF0
00007942783df0d0  vmovaps [rsp], xmm0
00007942783df0d5  vmovaps [rsp+0x10], xmm2
00007942783df0db  vmovaps [rsp+0x20], xmm3
00007942783df0e1  vmovaps [rsp+0x30], xmm4
00007942783df0e7  vmovaps [rsp+0x40], xmm5
00007942783df0ed  vmovaps [rsp+0x50], xmm6
00007942783df0f3  vmovaps [rsp+0x60], xmm7
00007942783df0f9  vmovaps [rsp+0x70], xmm8
00007942783df0ff  vmovaps [rsp+0x80], xmm9
00007942783df108  vmovaps [rsp+0x90], xmm10
00007942783df111  vmovaps [rsp+0xA0], xmm11
00007942783df11a  vmovaps [rsp+0xB0], xmm12
00007942783df123  vmovaps [rsp+0xC0], xmm13
00007942783df12c  vmovaps [rsp+0xD0], xmm14
00007942783df135  vmovaps [rsp+0xE0], xmm15
00007942783df13e  sub rsp, 0x30
00007942783df142  movaps [rsp], xmm1
00007942783df146  movaps [rsp+0x10], xmm15
00007942783df14c  movaps [rsp+0x20], xmm6
00007942783df151  lea rdi, [rsp]
00007942783df155  mov esi, 0x00
00007942783df15a  mov rax, 0x59DDDCBA3530
00007942783df164  call rax
00007942783df166  movaps xmm1, [rsp]
00007942783df16a  add rsp, 0x30
00007942783df16e  vmovaps xmm0, [rsp]
00007942783df173  vmovaps xmm2, [rsp+0x10]
00007942783df179  vmovaps xmm3, [rsp+0x20]
00007942783df17f  vmovaps xmm4, [rsp+0x30]
00007942783df185  vmovaps xmm5, [rsp+0x40]
00007942783df18b  vmovaps xmm6, [rsp+0x50]
00007942783df191  vmovaps xmm7, [rsp+0x60]
00007942783df197  vmovaps xmm8, [rsp+0x70]
00007942783df19d  vmovaps xmm9, [rsp+0x80]
00007942783df1a6  vmovaps xmm10, [rsp+0x90]
00007942783df1af  vmovaps xmm11, [rsp+0xA0]
00007942783df1b8  vmovaps xmm12, [rsp+0xB0]
00007942783df1c1  vmovaps xmm13, [rsp+0xC0]
00007942783df1ca  vmovaps xmm14, [rsp+0xD0]
00007942783df1d3  vmovaps xmm15, [rsp+0xE0]
00007942783df1dc  add rsp, 0xF0
00007942783df1e3  pop r11
00007942783df1e5  pop r10
00007942783df1e7  pop r9
00007942783df1e9  pop r8
00007942783df1eb  pop rsi
00007942783df1ec  pop rdi
00007942783df1ed  pop rdx
00007942783df1ee  pop rcx
00007942783df1ef  pop rax
00007942783df1f0  add rsp, 0x08
00007942783df1f4  jmp 0x00007942783DC375
00007942783df1f9  sub rsp, 0x08
00007942783df1fd  push rax
00007942783df1fe  push rcx
00007942783df1ff  push rdx
00007942783df200  push rdi
00007942783df201  push rsi
00007942783df202  push r8
00007942783df204  push r9
00007942783df206  push r10
00007942783df208  push r11
00007942783df20a  sub rsp, 0xF0
00007942783df211  vmovaps [rsp], xmm0
00007942783df216  vmovaps [rsp+0x10], xmm1
00007942783df21c  vmovaps [rsp+0x20], xmm2
00007942783df222  vmovaps [rsp+0x30], xmm3
00007942783df228  vmovaps [rsp+0x40], xmm4
00007942783df22e  vmovaps [rsp+0x50], xmm5
00007942783df234  vmovaps [rsp+0x60], xmm6
00007942783df23a  vmovaps [rsp+0x70], xmm7
00007942783df240  vmovaps [rsp+0x80], xmm8
00007942783df249  vmovaps [rsp+0x90], xmm9
00007942783df252  vmovaps [rsp+0xA0], xmm10
00007942783df25b  vmovaps [rsp+0xB0], xmm11
00007942783df264  vmovaps [rsp+0xC0], xmm12
00007942783df26d  vmovaps [rsp+0xD0], xmm13
00007942783df276  vmovaps [rsp+0xE0], xmm14
00007942783df27f  sub rsp, 0x30
00007942783df283  movaps [rsp], xmm15
00007942783df288  movaps [rsp+0x10], xmm5
00007942783df28d  movaps [rsp+0x20], xmm3
00007942783df292  lea rdi, [rsp]
00007942783df296  mov esi, 0x00
00007942783df29b  mov rax, 0x59DDDCBA3530
00007942783df2a5  call rax
00007942783df2a7  movaps xmm15, [rsp]
00007942783df2ac  add rsp, 0x30
00007942783df2b0  vmovaps xmm0, [rsp]
00007942783df2b5  vmovaps xmm1, [rsp+0x10]
00007942783df2bb  vmovaps xmm2, [rsp+0x20]
00007942783df2c1  vmovaps xmm3, [rsp+0x30]
00007942783df2c7  vmovaps xmm4, [rsp+0x40]
00007942783df2cd  vmovaps xmm5, [rsp+0x50]
00007942783df2d3  vmovaps xmm6, [rsp+0x60]
00007942783df2d9  vmovaps xmm7, [rsp+0x70]
00007942783df2df  vmovaps xmm8, [rsp+0x80]
00007942783df2e8  vmovaps xmm9, [rsp+0x90]
00007942783df2f1  vmovaps xmm10, [rsp+0xA0]
00007942783df2fa  vmovaps xmm11, [rsp+0xB0]
00007942783df303  vmovaps xmm12, [rsp+0xC0]
00007942783df30c  vmovaps xmm13, [rsp+0xD0]
00007942783df315  vmovaps xmm14, [rsp+0xE0]
00007942783df31e  add rsp, 0xF0
00007942783df325  pop r11
00007942783df327  pop r10
00007942783df329  pop r9
00007942783df32b  pop r8
00007942783df32d  pop rsi
00007942783df32e  pop rdi
00007942783df32f  pop rdx
00007942783df330  pop rcx
00007942783df331  pop rax
00007942783df332  add rsp, 0x08
00007942783df336  jmp 0x00007942783DC38F
00007942783df33b  sub rsp, 0x08
00007942783df33f  push rax
00007942783df340  push rcx
00007942783df341  push rdx
00007942783df342  push rdi
00007942783df343  push rsi
00007942783df344  push r8
00007942783df346  push r9
00007942783df348  push r10
00007942783df34a  push r11
00007942783df34c  sub rsp, 0xF0
00007942783df353  vmovaps [rsp], xmm0
00007942783df358  vmovaps [rsp+0x10], xmm1
00007942783df35e  vmovaps [rsp+0x20], xmm2
00007942783df364  vmovaps [rsp+0x30], xmm3
00007942783df36a  vmovaps [rsp+0x40], xmm4
00007942783df370  vmovaps [rsp+0x50], xmm6
00007942783df376  vmovaps [rsp+0x60], xmm7
00007942783df37c  vmovaps [rsp+0x70], xmm8
00007942783df382  vmovaps [rsp+0x80], xmm9
00007942783df38b  vmovaps [rsp+0x90], xmm10
00007942783df394  vmovaps [rsp+0xA0], xmm11
00007942783df39d  vmovaps [rsp+0xB0], xmm12
00007942783df3a6  vmovaps [rsp+0xC0], xmm13
00007942783df3af  vmovaps [rsp+0xD0], xmm14
00007942783df3b8  vmovaps [rsp+0xE0], xmm15
00007942783df3c1  sub rsp, 0x30
00007942783df3c5  movaps [rsp], xmm5
00007942783df3c9  movaps [rsp+0x10], xmm8
00007942783df3cf  movaps [rsp+0x20], xmm6
00007942783df3d4  lea rdi, [rsp]
00007942783df3d8  mov esi, 0x00
00007942783df3dd  mov rax, 0x59DDDCBA3530
00007942783df3e7  call rax
00007942783df3e9  movaps xmm5, [rsp]
00007942783df3ed  add rsp, 0x30
00007942783df3f1  vmovaps xmm0, [rsp]
00007942783df3f6  vmovaps xmm1, [rsp+0x10]
00007942783df3fc  vmovaps xmm2, [rsp+0x20]
00007942783df402  vmovaps xmm3, [rsp+0x30]
00007942783df408  vmovaps xmm4, [rsp+0x40]
00007942783df40e  vmovaps xmm6, [rsp+0x50]
00007942783df414  vmovaps xmm7, [rsp+0x60]
00007942783df41a  vmovaps xmm8, [rsp+0x70]
00007942783df420  vmovaps xmm9, [rsp+0x80]
00007942783df429  vmovaps xmm10, [rsp+0x90]
00007942783df432  vmovaps xmm11, [rsp+0xA0]
00007942783df43b  vmovaps xmm12, [rsp+0xB0]
00007942783df444  vmovaps xmm13, [rsp+0xC0]
00007942783df44d  vmovaps xmm14, [rsp+0xD0]
00007942783df456  vmovaps xmm15, [rsp+0xE0]
00007942783df45f  add rsp, 0xF0
00007942783df466  pop r11
00007942783df468  pop r10
00007942783df46a  pop r9
00007942783df46c  pop r8
00007942783df46e  pop rsi
00007942783df46f  pop rdi
00007942783df470  pop rdx
00007942783df471  pop rcx
00007942783df472  pop rax
00007942783df473  add rsp, 0x08
00007942783df477  jmp 0x00007942783DC3B3
00007942783df47c  sub rsp, 0x08
00007942783df480  push rax
00007942783df481  push rcx
00007942783df482  push rdx
00007942783df483  push rdi
00007942783df484  push rsi
00007942783df485  push r8
00007942783df487  push r9
00007942783df489  push r10
00007942783df48b  push r11
00007942783df48d  sub rsp, 0xF0
00007942783df494  vmovaps [rsp], xmm0
00007942783df499  vmovaps [rsp+0x10], xmm1
00007942783df49f  vmovaps [rsp+0x20], xmm2
00007942783df4a5  vmovaps [rsp+0x30], xmm3
00007942783df4ab  vmovaps [rsp+0x40], xmm4
00007942783df4b1  vmovaps [rsp+0x50], xmm5
00007942783df4b7  vmovaps [rsp+0x60], xmm7
00007942783df4bd  vmovaps [rsp+0x70], xmm8
00007942783df4c3  vmovaps [rsp+0x80], xmm9
00007942783df4cc  vmovaps [rsp+0x90], xmm10
00007942783df4d5  vmovaps [rsp+0xA0], xmm11
00007942783df4de  vmovaps [rsp+0xB0], xmm12
00007942783df4e7  vmovaps [rsp+0xC0], xmm13
00007942783df4f0  vmovaps [rsp+0xD0], xmm14
00007942783df4f9  vmovaps [rsp+0xE0], xmm15
00007942783df502  sub rsp, 0x30
00007942783df506  movaps [rsp], xmm6
00007942783df50a  movaps [rsp+0x10], xmm10
00007942783df510  movaps [rsp+0x20], xmm8
00007942783df516  lea rdi, [rsp]
00007942783df51a  mov esi, 0x00
00007942783df51f  mov rax, 0x59DDDCBA3530
00007942783df529  call rax
00007942783df52b  movaps xmm6, [rsp]
00007942783df52f  add rsp, 0x30
00007942783df533  vmovaps xmm0, [rsp]
00007942783df538  vmovaps xmm1, [rsp+0x10]
00007942783df53e  vmovaps xmm2, [rsp+0x20]
00007942783df544  vmovaps xmm3, [rsp+0x30]
00007942783df54a  vmovaps xmm4, [rsp+0x40]
00007942783df550  vmovaps xmm5, [rsp+0x50]
00007942783df556  vmovaps xmm7, [rsp+0x60]
00007942783df55c  vmovaps xmm8, [rsp+0x70]
00007942783df562  vmovaps xmm9, [rsp+0x80]
00007942783df56b  vmovaps xmm10, [rsp+0x90]
00007942783df574  vmovaps xmm11, [rsp+0xA0]
00007942783df57d  vmovaps xmm12, [rsp+0xB0]
00007942783df586  vmovaps xmm13, [rsp+0xC0]
00007942783df58f  vmovaps xmm14, [rsp+0xD0]
00007942783df598  vmovaps xmm15, [rsp+0xE0]
00007942783df5a1  add rsp, 0xF0
00007942783df5a8  pop r11
00007942783df5aa  pop r10
00007942783df5ac  pop r9
00007942783df5ae  pop r8
00007942783df5b0  pop rsi
00007942783df5b1  pop rdi
00007942783df5b2  pop rdx
00007942783df5b3  pop rcx
00007942783df5b4  pop rax
00007942783df5b5  add rsp, 0x08
00007942783df5b9  jmp 0x00007942783DC3D8
00007942783df5be  sub rsp, 0x08
00007942783df5c2  push rax
00007942783df5c3  push rcx
00007942783df5c4  push rdx
00007942783df5c5  push rdi
00007942783df5c6  push rsi
00007942783df5c7  push r8
00007942783df5c9  push r9
00007942783df5cb  push r10
00007942783df5cd  push r11
00007942783df5cf  sub rsp, 0xF0
00007942783df5d6  vmovaps [rsp], xmm0
00007942783df5db  vmovaps [rsp+0x10], xmm1
00007942783df5e1  vmovaps [rsp+0x20], xmm2
00007942783df5e7  vmovaps [rsp+0x30], xmm3
00007942783df5ed  vmovaps [rsp+0x40], xmm4
00007942783df5f3  vmovaps [rsp+0x50], xmm5
00007942783df5f9  vmovaps [rsp+0x60], xmm6
00007942783df5ff  vmovaps [rsp+0x70], xmm7
00007942783df605  vmovaps [rsp+0x80], xmm8
00007942783df60e  vmovaps [rsp+0x90], xmm9
00007942783df617  vmovaps [rsp+0xA0], xmm11
00007942783df620  vmovaps [rsp+0xB0], xmm12
00007942783df629  vmovaps [rsp+0xC0], xmm13
00007942783df632  vmovaps [rsp+0xD0], xmm14
00007942783df63b  vmovaps [rsp+0xE0], xmm15
00007942783df644  sub rsp, 0x30
00007942783df648  movaps [rsp], xmm10
00007942783df64d  movaps [rsp+0x10], xmm8
00007942783df653  movaps [rsp+0x20], xmm14
00007942783df659  lea rdi, [rsp]
00007942783df65d  mov esi, 0x00
00007942783df662  mov rax, 0x59DDDCBA3530
00007942783df66c  call rax
00007942783df66e  movaps xmm10, [rsp]
00007942783df673  add rsp, 0x30
00007942783df677  vmovaps xmm0, [rsp]
00007942783df67c  vmovaps xmm1, [rsp+0x10]
00007942783df682  vmovaps xmm2, [rsp+0x20]
00007942783df688  vmovaps xmm3, [rsp+0x30]
00007942783df68e  vmovaps xmm4, [rsp+0x40]
00007942783df694  vmovaps xmm5, [rsp+0x50]
00007942783df69a  vmovaps xmm6, [rsp+0x60]
00007942783df6a0  vmovaps xmm7, [rsp+0x70]
00007942783df6a6  vmovaps xmm8, [rsp+0x80]
00007942783df6af  vmovaps xmm9, [rsp+0x90]
00007942783df6b8  vmovaps xmm11, [rsp+0xA0]
00007942783df6c1  vmovaps xmm12, [rsp+0xB0]
00007942783df6ca  vmovaps xmm13, [rsp+0xC0]
00007942783df6d3  vmovaps xmm14, [rsp+0xD0]
00007942783df6dc  vmovaps xmm15, [rsp+0xE0]
00007942783df6e5  add rsp, 0xF0
00007942783df6ec  pop r11
00007942783df6ee  pop r10
00007942783df6f0  pop r9
00007942783df6f2  pop r8
00007942783df6f4  pop rsi
00007942783df6f5  pop rdi
00007942783df6f6  pop rdx
00007942783df6f7  pop rcx
00007942783df6f8  pop rax
00007942783df6f9  add rsp, 0x08
00007942783df6fd  jmp 0x00007942783DC3F8
00007942783df702  sub rsp, 0x08
00007942783df706  push rax
00007942783df707  push rcx
00007942783df708  push rdx
00007942783df709  push rdi
00007942783df70a  push rsi
00007942783df70b  push r8
00007942783df70d  push r9
00007942783df70f  push r10
00007942783df711  push r11
00007942783df713  sub rsp, 0xF0
00007942783df71a  vmovaps [rsp], xmm0
00007942783df71f  vmovaps [rsp+0x10], xmm1
00007942783df725  vmovaps [rsp+0x20], xmm2
00007942783df72b  vmovaps [rsp+0x30], xmm3
00007942783df731  vmovaps [rsp+0x40], xmm4
00007942783df737  vmovaps [rsp+0x50], xmm5
00007942783df73d  vmovaps [rsp+0x60], xmm6
00007942783df743  vmovaps [rsp+0x70], xmm7
00007942783df749  vmovaps [rsp+0x80], xmm8
00007942783df752  vmovaps [rsp+0x90], xmm9
00007942783df75b  vmovaps [rsp+0xA0], xmm10
00007942783df764  vmovaps [rsp+0xB0], xmm11
00007942783df76d  vmovaps [rsp+0xC0], xmm12
00007942783df776  vmovaps [rsp+0xD0], xmm13
00007942783df77f  vmovaps [rsp+0xE0], xmm15
00007942783df788  sub rsp, 0x30
00007942783df78c  movaps [rsp], xmm14
00007942783df791  movaps [rsp+0x10], xmm8
00007942783df797  movaps [rsp+0x20], xmm4
00007942783df79c  lea rdi, [rsp]
00007942783df7a0  mov esi, 0x00
00007942783df7a5  mov rax, 0x59DDDCBA3530
00007942783df7af  call rax
00007942783df7b1  movaps xmm14, [rsp]
00007942783df7b6  add rsp, 0x30
00007942783df7ba  vmovaps xmm0, [rsp]
00007942783df7bf  vmovaps xmm1, [rsp+0x10]
00007942783df7c5  vmovaps xmm2, [rsp+0x20]
00007942783df7cb  vmovaps xmm3, [rsp+0x30]
00007942783df7d1  vmovaps xmm4, [rsp+0x40]
00007942783df7d7  vmovaps xmm5, [rsp+0x50]
00007942783df7dd  vmovaps xmm6, [rsp+0x60]
00007942783df7e3  vmovaps xmm7, [rsp+0x70]
00007942783df7e9  vmovaps xmm8, [rsp+0x80]
00007942783df7f2  vmovaps xmm9, [rsp+0x90]
00007942783df7fb  vmovaps xmm10, [rsp+0xA0]
00007942783df804  vmovaps xmm11, [rsp+0xB0]
00007942783df80d  vmovaps xmm12, [rsp+0xC0]
00007942783df816  vmovaps xmm13, [rsp+0xD0]
00007942783df81f  vmovaps xmm15, [rsp+0xE0]
00007942783df828  add rsp, 0xF0
00007942783df82f  pop r11
00007942783df831  pop r10
00007942783df833  pop r9
00007942783df835  pop r8
00007942783df837  pop rsi
00007942783df838  pop rdi
00007942783df839  pop rdx
00007942783df83a  pop rcx
00007942783df83b  pop rax
00007942783df83c  add rsp, 0x08
00007942783df840  jmp 0x00007942783DC418
00007942783df845  sub rsp, 0x08
00007942783df849  push rax
00007942783df84a  push rcx
00007942783df84b  push rdx
00007942783df84c  push rdi
00007942783df84d  push rsi
00007942783df84e  push r8
00007942783df850  push r9
00007942783df852  push r10
00007942783df854  push r11
00007942783df856  sub rsp, 0xF0
00007942783df85d  vmovaps [rsp], xmm0
00007942783df862  vmovaps [rsp+0x10], xmm1
00007942783df868  vmovaps [rsp+0x20], xmm2
00007942783df86e  vmovaps [rsp+0x30], xmm3
00007942783df874  vmovaps [rsp+0x40], xmm5
00007942783df87a  vmovaps [rsp+0x50], xmm6
00007942783df880  vmovaps [rsp+0x60], xmm7
00007942783df886  vmovaps [rsp+0x70], xmm8
00007942783df88c  vmovaps [rsp+0x80], xmm9
00007942783df895  vmovaps [rsp+0x90], xmm10
00007942783df89e  vmovaps [rsp+0xA0], xmm11
00007942783df8a7  vmovaps [rsp+0xB0], xmm12
00007942783df8b0  vmovaps [rsp+0xC0], xmm13
00007942783df8b9  vmovaps [rsp+0xD0], xmm14
00007942783df8c2  vmovaps [rsp+0xE0], xmm15
00007942783df8cb  sub rsp, 0x30
00007942783df8cf  movaps [rsp], xmm4
00007942783df8d3  movaps [rsp+0x10], xmm13
00007942783df8d9  movaps [rsp+0x20], xmm8
00007942783df8df  lea rdi, [rsp]
00007942783df8e3  mov esi, 0x00
00007942783df8e8  mov rax, 0x59DDDCBA3530
00007942783df8f2  call rax
00007942783df8f4  movaps xmm4, [rsp]
00007942783df8f8  add rsp, 0x30
00007942783df8fc  vmovaps xmm0, [rsp]
00007942783df901  vmovaps xmm1, [rsp+0x10]
00007942783df907  vmovaps xmm2, [rsp+0x20]
00007942783df90d  vmovaps xmm3, [rsp+0x30]
00007942783df913  vmovaps xmm5, [rsp+0x40]
00007942783df919  vmovaps xmm6, [rsp+0x50]
00007942783df91f  vmovaps xmm7, [rsp+0x60]
00007942783df925  vmovaps xmm8, [rsp+0x70]
00007942783df92b  vmovaps xmm9, [rsp+0x80]
00007942783df934  vmovaps xmm10, [rsp+0x90]
00007942783df93d  vmovaps xmm11, [rsp+0xA0]
00007942783df946  vmovaps xmm12, [rsp+0xB0]
00007942783df94f  vmovaps xmm13, [rsp+0xC0]
00007942783df958  vmovaps xmm14, [rsp+0xD0]
00007942783df961  vmovaps xmm15, [rsp+0xE0]
00007942783df96a  add rsp, 0xF0
00007942783df971  pop r11
00007942783df973  pop r10
00007942783df975  pop r9
00007942783df977  pop r8
00007942783df979  pop rsi
00007942783df97a  pop rdi
00007942783df97b  pop rdx
00007942783df97c  pop rcx
00007942783df97d  pop rax
00007942783df97e  add rsp, 0x08
00007942783df982  jmp 0x00007942783DC43D
00007942783df987  sub rsp, 0x08
00007942783df98b  push rax
00007942783df98c  push rcx
00007942783df98d  push rdx
00007942783df98e  push rdi
00007942783df98f  push rsi
00007942783df990  push r8
00007942783df992  push r9
00007942783df994  push r10
00007942783df996  push r11
00007942783df998  sub rsp, 0xF0
00007942783df99f  vmovaps [rsp], xmm0
00007942783df9a4  vmovaps [rsp+0x10], xmm1
00007942783df9aa  vmovaps [rsp+0x20], xmm2
00007942783df9b0  vmovaps [rsp+0x30], xmm3
00007942783df9b6  vmovaps [rsp+0x40], xmm4
00007942783df9bc  vmovaps [rsp+0x50], xmm5
00007942783df9c2  vmovaps [rsp+0x60], xmm6
00007942783df9c8  vmovaps [rsp+0x70], xmm7
00007942783df9ce  vmovaps [rsp+0x80], xmm8
00007942783df9d7  vmovaps [rsp+0x90], xmm9
00007942783df9e0  vmovaps [rsp+0xA0], xmm10
00007942783df9e9  vmovaps [rsp+0xB0], xmm11
00007942783df9f2  vmovaps [rsp+0xC0], xmm12
00007942783df9fb  vmovaps [rsp+0xD0], xmm14
00007942783dfa04  vmovaps [rsp+0xE0], xmm15
00007942783dfa0d  sub rsp, 0x30
00007942783dfa11  movaps [rsp], xmm13
00007942783dfa16  movaps [rsp+0x10], xmm15
00007942783dfa1c  movaps [rsp+0x20], xmm9
00007942783dfa22  lea rdi, [rsp]
00007942783dfa26  mov esi, 0x00
00007942783dfa2b  mov rax, 0x59DDDCBA3530
00007942783dfa35  call rax
00007942783dfa37  movaps xmm13, [rsp]
00007942783dfa3c  add rsp, 0x30
00007942783dfa40  vmovaps xmm0, [rsp]
00007942783dfa45  vmovaps xmm1, [rsp+0x10]
00007942783dfa4b  vmovaps xmm2, [rsp+0x20]
00007942783dfa51  vmovaps xmm3, [rsp+0x30]
00007942783dfa57  vmovaps xmm4, [rsp+0x40]
00007942783dfa5d  vmovaps xmm5, [rsp+0x50]
00007942783dfa63  vmovaps xmm6, [rsp+0x60]
00007942783dfa69  vmovaps xmm7, [rsp+0x70]
00007942783dfa6f  vmovaps xmm8, [rsp+0x80]
00007942783dfa78  vmovaps xmm9, [rsp+0x90]
00007942783dfa81  vmovaps xmm10, [rsp+0xA0]
00007942783dfa8a  vmovaps xmm11, [rsp+0xB0]
00007942783dfa93  vmovaps xmm12, [rsp+0xC0]
00007942783dfa9c  vmovaps xmm14, [rsp+0xD0]
00007942783dfaa5  vmovaps xmm15, [rsp+0xE0]
00007942783dfaae  add rsp, 0xF0
00007942783dfab5  pop r11
00007942783dfab7  pop r10
00007942783dfab9  pop r9
00007942783dfabb  pop r8
00007942783dfabd  pop rsi
00007942783dfabe  pop rdi
00007942783dfabf  pop rdx
00007942783dfac0  pop rcx
00007942783dfac1  pop rax
00007942783dfac2  add rsp, 0x08
00007942783dfac6  jmp 0x00007942783DC458
00007942783dfacb  sub rsp, 0x08
00007942783dfacf  push rax
00007942783dfad0  push rcx
00007942783dfad1  push rdx
00007942783dfad2  push rdi
00007942783dfad3  push rsi
00007942783dfad4  push r8
00007942783dfad6  push r9
00007942783dfad8  push r10
00007942783dfada  push r11
00007942783dfadc  sub rsp, 0xF0
00007942783dfae3  vmovaps [rsp], xmm0
00007942783dfae8  vmovaps [rsp+0x10], xmm1
00007942783dfaee  vmovaps [rsp+0x20], xmm2
00007942783dfaf4  vmovaps [rsp+0x30], xmm3
00007942783dfafa  vmovaps [rsp+0x40], xmm4
00007942783dfb00  vmovaps [rsp+0x50], xmm5
00007942783dfb06  vmovaps [rsp+0x60], xmm6
00007942783dfb0c  vmovaps [rsp+0x70], xmm7
00007942783dfb12  vmovaps [rsp+0x80], xmm8
00007942783dfb1b  vmovaps [rsp+0x90], xmm9
00007942783dfb24  vmovaps [rsp+0xA0], xmm10
00007942783dfb2d  vmovaps [rsp+0xB0], xmm11
00007942783dfb36  vmovaps [rsp+0xC0], xmm12
00007942783dfb3f  vmovaps [rsp+0xD0], xmm13
00007942783dfb48  vmovaps [rsp+0xE0], xmm14
00007942783dfb51  sub rsp, 0x30
00007942783dfb55  movaps [rsp], xmm15
00007942783dfb5a  movaps [rsp+0x10], xmm1
00007942783dfb5f  movaps [rsp+0x20], xmm5
00007942783dfb64  lea rdi, [rsp]
00007942783dfb68  mov esi, 0x00
00007942783dfb6d  mov rax, 0x59DDDCBA3530
00007942783dfb77  call rax
00007942783dfb79  movaps xmm15, [rsp]
00007942783dfb7e  add rsp, 0x30
00007942783dfb82  vmovaps xmm0, [rsp]
00007942783dfb87  vmovaps xmm1, [rsp+0x10]
00007942783dfb8d  vmovaps xmm2, [rsp+0x20]
00007942783dfb93  vmovaps xmm3, [rsp+0x30]
00007942783dfb99  vmovaps xmm4, [rsp+0x40]
00007942783dfb9f  vmovaps xmm5, [rsp+0x50]
00007942783dfba5  vmovaps xmm6, [rsp+0x60]
00007942783dfbab  vmovaps xmm7, [rsp+0x70]
00007942783dfbb1  vmovaps xmm8, [rsp+0x80]
00007942783dfbba  vmovaps xmm9, [rsp+0x90]
00007942783dfbc3  vmovaps xmm10, [rsp+0xA0]
00007942783dfbcc  vmovaps xmm11, [rsp+0xB0]
00007942783dfbd5  vmovaps xmm12, [rsp+0xC0]
00007942783dfbde  vmovaps xmm13, [rsp+0xD0]
00007942783dfbe7  vmovaps xmm14, [rsp+0xE0]
00007942783dfbf0  add rsp, 0xF0
00007942783dfbf7  pop r11
00007942783dfbf9  pop r10
00007942783dfbfb  pop r9
00007942783dfbfd  pop r8
00007942783dfbff  pop rsi
00007942783dfc00  pop rdi
00007942783dfc01  pop rdx
00007942783dfc02  pop rcx
00007942783dfc03  pop rax
00007942783dfc04  add rsp, 0x08
00007942783dfc08  jmp 0x00007942783DC473
00007942783dfc0d  call 0x00007942782B52F0
00007942783dfc12  jmp 0x00007942783DC4CE
00007942783dfc17  sub rsp, 0x08
00007942783dfc1b  push rax
00007942783dfc1c  push rcx
00007942783dfc1d  push rdx
00007942783dfc1e  push rdi
00007942783dfc1f  push rsi
00007942783dfc20  push r8
00007942783dfc22  push r9
00007942783dfc24  push r10
00007942783dfc26  push r11
00007942783dfc28  sub rsp, 0xF0
00007942783dfc2f  vmovaps [rsp], xmm0
00007942783dfc34  vmovaps [rsp+0x10], xmm1
00007942783dfc3a  vmovaps [rsp+0x20], xmm2
00007942783dfc40  vmovaps [rsp+0x30], xmm3
00007942783dfc46  vmovaps [rsp+0x40], xmm4
00007942783dfc4c  vmovaps [rsp+0x50], xmm5
00007942783dfc52  vmovaps [rsp+0x60], xmm6
00007942783dfc58  vmovaps [rsp+0x70], xmm7
00007942783dfc5e  vmovaps [rsp+0x80], xmm8
00007942783dfc67  vmovaps [rsp+0x90], xmm10
00007942783dfc70  vmovaps [rsp+0xA0], xmm11
00007942783dfc79  vmovaps [rsp+0xB0], xmm12
00007942783dfc82  vmovaps [rsp+0xC0], xmm13
00007942783dfc8b  vmovaps [rsp+0xD0], xmm14
00007942783dfc94  vmovaps [rsp+0xE0], xmm15
00007942783dfc9d  sub rsp, 0x30
00007942783dfca1  movaps [rsp], xmm9
00007942783dfca6  movaps [rsp+0x10], xmm8
00007942783dfcac  movaps [rsp+0x20], xmm11
00007942783dfcb2  lea rdi, [rsp]
00007942783dfcb6  mov esi, 0x00
00007942783dfcbb  mov rax, 0x59DDDCBA3530
00007942783dfcc5  call rax
00007942783dfcc7  movaps xmm9, [rsp]
00007942783dfccc  add rsp, 0x30
00007942783dfcd0  vmovaps xmm0, [rsp]
00007942783dfcd5  vmovaps xmm1, [rsp+0x10]
00007942783dfcdb  vmovaps xmm2, [rsp+0x20]
00007942783dfce1  vmovaps xmm3, [rsp+0x30]
00007942783dfce7  vmovaps xmm4, [rsp+0x40]
00007942783dfced  vmovaps xmm5, [rsp+0x50]
00007942783dfcf3  vmovaps xmm6, [rsp+0x60]
00007942783dfcf9  vmovaps xmm7, [rsp+0x70]
00007942783dfcff  vmovaps xmm8, [rsp+0x80]
00007942783dfd08  vmovaps xmm10, [rsp+0x90]
00007942783dfd11  vmovaps xmm11, [rsp+0xA0]
00007942783dfd1a  vmovaps xmm12, [rsp+0xB0]
00007942783dfd23  vmovaps xmm13, [rsp+0xC0]
00007942783dfd2c  vmovaps xmm14, [rsp+0xD0]
00007942783dfd35  vmovaps xmm15, [rsp+0xE0]
00007942783dfd3e  add rsp, 0xF0
00007942783dfd45  pop r11
00007942783dfd47  pop r10
00007942783dfd49  pop r9
00007942783dfd4b  pop r8
00007942783dfd4d  pop rsi
00007942783dfd4e  pop rdi
00007942783dfd4f  pop rdx
00007942783dfd50  pop rcx
00007942783dfd51  pop rax
00007942783dfd52  add rsp, 0x08
00007942783dfd56  jmp 0x00007942783DC505
00007942783dfd5b  sub rsp, 0x08
00007942783dfd5f  push rax
00007942783dfd60  push rcx
00007942783dfd61  push rdx
00007942783dfd62  push rdi
00007942783dfd63  push rsi
00007942783dfd64  push r8
00007942783dfd66  push r9
00007942783dfd68  push r10
00007942783dfd6a  push r11
00007942783dfd6c  sub rsp, 0xF0
00007942783dfd73  vmovaps [rsp], xmm0
00007942783dfd78  vmovaps [rsp+0x10], xmm1
00007942783dfd7e  vmovaps [rsp+0x20], xmm2
00007942783dfd84  vmovaps [rsp+0x30], xmm3
00007942783dfd8a  vmovaps [rsp+0x40], xmm4
00007942783dfd90  vmovaps [rsp+0x50], xmm5
00007942783dfd96  vmovaps [rsp+0x60], xmm6
00007942783dfd9c  vmovaps [rsp+0x70], xmm7
00007942783dfda2  vmovaps [rsp+0x80], xmm8
00007942783dfdab  vmovaps [rsp+0x90], xmm9
00007942783dfdb4  vmovaps [rsp+0xA0], xmm10
00007942783dfdbd  vmovaps [rsp+0xB0], xmm12
00007942783dfdc6  vmovaps [rsp+0xC0], xmm13
00007942783dfdcf  vmovaps [rsp+0xD0], xmm14
00007942783dfdd8  vmovaps [rsp+0xE0], xmm15
00007942783dfde1  sub rsp, 0x30
00007942783dfde5  movaps [rsp], xmm11
00007942783dfdea  movaps [rsp+0x10], xmm10
00007942783dfdf0  movaps [rsp+0x20], xmm6
00007942783dfdf5  lea rdi, [rsp]
00007942783dfdf9  mov esi, 0x00
00007942783dfdfe  mov rax, 0x59DDDCBA3530
00007942783dfe08  call rax
00007942783dfe0a  movaps xmm11, [rsp]
00007942783dfe0f  add rsp, 0x30
00007942783dfe13  vmovaps xmm0, [rsp]
00007942783dfe18  vmovaps xmm1, [rsp+0x10]
00007942783dfe1e  vmovaps xmm2, [rsp+0x20]
00007942783dfe24  vmovaps xmm3, [rsp+0x30]
00007942783dfe2a  vmovaps xmm4, [rsp+0x40]
00007942783dfe30  vmovaps xmm5, [rsp+0x50]
00007942783dfe36  vmovaps xmm6, [rsp+0x60]
00007942783dfe3c  vmovaps xmm7, [rsp+0x70]
00007942783dfe42  vmovaps xmm8, [rsp+0x80]
00007942783dfe4b  vmovaps xmm9, [rsp+0x90]
00007942783dfe54  vmovaps xmm10, [rsp+0xA0]
00007942783dfe5d  vmovaps xmm12, [rsp+0xB0]
00007942783dfe66  vmovaps xmm13, [rsp+0xC0]
00007942783dfe6f  vmovaps xmm14, [rsp+0xD0]
00007942783dfe78  vmovaps xmm15, [rsp+0xE0]
00007942783dfe81  add rsp, 0xF0
00007942783dfe88  pop r11
00007942783dfe8a  pop r10
00007942783dfe8c  pop r9
00007942783dfe8e  pop r8
00007942783dfe90  pop rsi
00007942783dfe91  pop rdi
00007942783dfe92  pop rdx
00007942783dfe93  pop rcx
00007942783dfe94  pop rax
00007942783dfe95  add rsp, 0x08
00007942783dfe99  jmp 0x00007942783DC520
00007942783dfe9e  sub rsp, 0x08
00007942783dfea2  push rax
00007942783dfea3  push rcx
00007942783dfea4  push rdx
00007942783dfea5  push rdi
00007942783dfea6  push rsi
00007942783dfea7  push r8
00007942783dfea9  push r9
00007942783dfeab  push r10
00007942783dfead  push r11
00007942783dfeaf  sub rsp, 0xF0
00007942783dfeb6  vmovaps [rsp], xmm0
00007942783dfebb  vmovaps [rsp+0x10], xmm1
00007942783dfec1  vmovaps [rsp+0x20], xmm2
00007942783dfec7  vmovaps [rsp+0x30], xmm3
00007942783dfecd  vmovaps [rsp+0x40], xmm4
00007942783dfed3  vmovaps [rsp+0x50], xmm5
00007942783dfed9  vmovaps [rsp+0x60], xmm6
00007942783dfedf  vmovaps [rsp+0x70], xmm7
00007942783dfee5  vmovaps [rsp+0x80], xmm8
00007942783dfeee  vmovaps [rsp+0x90], xmm9
00007942783dfef7  vmovaps [rsp+0xA0], xmm11
00007942783dff00  vmovaps [rsp+0xB0], xmm12
00007942783dff09  vmovaps [rsp+0xC0], xmm13
00007942783dff12  vmovaps [rsp+0xD0], xmm14
00007942783dff1b  vmovaps [rsp+0xE0], xmm15
00007942783dff24  sub rsp, 0x30
00007942783dff28  movaps [rsp], xmm10
00007942783dff2d  movaps [rsp+0x10], xmm14
00007942783dff33  movaps [rsp+0x20], xmm4
00007942783dff38  lea rdi, [rsp]
00007942783dff3c  mov esi, 0x00
00007942783dff41  mov rax, 0x59DDDCBA3530
00007942783dff4b  call rax
00007942783dff4d  movaps xmm10, [rsp]
00007942783dff52  add rsp, 0x30
00007942783dff56  vmovaps xmm0, [rsp]
00007942783dff5b  vmovaps xmm1, [rsp+0x10]
00007942783dff61  vmovaps xmm2, [rsp+0x20]
00007942783dff67  vmovaps xmm3, [rsp+0x30]
00007942783dff6d  vmovaps xmm4, [rsp+0x40]
00007942783dff73  vmovaps xmm5, [rsp+0x50]
00007942783dff79  vmovaps xmm6, [rsp+0x60]
00007942783dff7f  vmovaps xmm7, [rsp+0x70]
00007942783dff85  vmovaps xmm8, [rsp+0x80]
00007942783dff8e  vmovaps xmm9, [rsp+0x90]
00007942783dff97  vmovaps xmm11, [rsp+0xA0]
00007942783dffa0  vmovaps xmm12, [rsp+0xB0]
00007942783dffa9  vmovaps xmm13, [rsp+0xC0]
00007942783dffb2  vmovaps xmm14, [rsp+0xD0]
00007942783dffbb  vmovaps xmm15, [rsp+0xE0]
00007942783dffc4  add rsp, 0xF0
00007942783dffcb  pop r11
00007942783dffcd  pop r10
00007942783dffcf  pop r9
00007942783dffd1  pop r8
00007942783dffd3  pop rsi
00007942783dffd4  pop rdi
00007942783dffd5  pop rdx
00007942783dffd6  pop rcx
00007942783dffd7  pop rax
00007942783dffd8  add rsp, 0x08
00007942783dffdc  jmp 0x00007942783DC53B
00007942783dffe1  sub rsp, 0x08
00007942783dffe5  push rax
00007942783dffe6  push rcx
00007942783dffe7  push rdx
00007942783dffe8  push rdi
00007942783dffe9  push rsi
00007942783dffea  push r8
00007942783dffec  push r9
00007942783dffee  push r10
00007942783dfff0  push r11
00007942783dfff2  sub rsp, 0xF0
00007942783dfff9  vmovaps [rsp], xmm0
00007942783dfffe  vmovaps [rsp+0x10], xmm1
00007942783e0004  vmovaps [rsp+0x20], xmm2
00007942783e000a  vmovaps [rsp+0x30], xmm3
00007942783e0010  vmovaps [rsp+0x40], xmm4
00007942783e0016  vmovaps [rsp+0x50], xmm5
00007942783e001c  vmovaps [rsp+0x60], xmm6
00007942783e0022  vmovaps [rsp+0x70], xmm7
00007942783e0028  vmovaps [rsp+0x80], xmm9
00007942783e0031  vmovaps [rsp+0x90], xmm10
00007942783e003a  vmovaps [rsp+0xA0], xmm11
00007942783e0043  vmovaps [rsp+0xB0], xmm12
00007942783e004c  vmovaps [rsp+0xC0], xmm13
00007942783e0055  vmovaps [rsp+0xD0], xmm14
00007942783e005e  vmovaps [rsp+0xE0], xmm15
00007942783e0067  sub rsp, 0x30
00007942783e006b  movaps [rsp], xmm8
00007942783e0070  movaps [rsp+0x10], xmm1
00007942783e0075  movaps [rsp+0x20], xmm14
00007942783e007b  lea rdi, [rsp]
00007942783e007f  mov esi, 0x00
00007942783e0084  mov rax, 0x59DDDCBA3530
00007942783e008e  call rax
00007942783e0090  movaps xmm8, [rsp]
00007942783e0095  add rsp, 0x30
00007942783e0099  vmovaps xmm0, [rsp]
00007942783e009e  vmovaps xmm1, [rsp+0x10]
00007942783e00a4  vmovaps xmm2, [rsp+0x20]
00007942783e00aa  vmovaps xmm3, [rsp+0x30]
00007942783e00b0  vmovaps xmm4, [rsp+0x40]
00007942783e00b6  vmovaps xmm5, [rsp+0x50]
00007942783e00bc  vmovaps xmm6, [rsp+0x60]
00007942783e00c2  vmovaps xmm7, [rsp+0x70]
00007942783e00c8  vmovaps xmm9, [rsp+0x80]
00007942783e00d1  vmovaps xmm10, [rsp+0x90]
00007942783e00da  vmovaps xmm11, [rsp+0xA0]
00007942783e00e3  vmovaps xmm12, [rsp+0xB0]
00007942783e00ec  vmovaps xmm13, [rsp+0xC0]
00007942783e00f5  vmovaps xmm14, [rsp+0xD0]
00007942783e00fe  vmovaps xmm15, [rsp+0xE0]
00007942783e0107  add rsp, 0xF0
00007942783e010e  pop r11
00007942783e0110  pop r10
00007942783e0112  pop r9
00007942783e0114  pop r8
00007942783e0116  pop rsi
00007942783e0117  pop rdi
00007942783e0118  pop rdx
00007942783e0119  pop rcx
00007942783e011a  pop rax
00007942783e011b  add rsp, 0x08
00007942783e011f  jmp 0x00007942783DC561
00007942783e0124  sub rsp, 0x08
00007942783e0128  push rax
00007942783e0129  push rcx
00007942783e012a  push rdx
00007942783e012b  push rdi
00007942783e012c  push rsi
00007942783e012d  push r8
00007942783e012f  push r9
00007942783e0131  push r10
00007942783e0133  push r11
00007942783e0135  sub rsp, 0xF0
00007942783e013c  vmovaps [rsp], xmm0
00007942783e0141  vmovaps [rsp+0x10], xmm1
00007942783e0147  vmovaps [rsp+0x20], xmm2
00007942783e014d  vmovaps [rsp+0x30], xmm3
00007942783e0153  vmovaps [rsp+0x40], xmm4
00007942783e0159  vmovaps [rsp+0x50], xmm5
00007942783e015f  vmovaps [rsp+0x60], xmm7
00007942783e0165  vmovaps [rsp+0x70], xmm8
00007942783e016b  vmovaps [rsp+0x80], xmm9
00007942783e0174  vmovaps [rsp+0x90], xmm10
00007942783e017d  vmovaps [rsp+0xA0], xmm11
00007942783e0186  vmovaps [rsp+0xB0], xmm12
00007942783e018f  vmovaps [rsp+0xC0], xmm13
00007942783e0198  vmovaps [rsp+0xD0], xmm14
00007942783e01a1  vmovaps [rsp+0xE0], xmm15
00007942783e01aa  sub rsp, 0x30
00007942783e01ae  movaps [rsp], xmm6
00007942783e01b2  movaps [rsp+0x10], xmm1
00007942783e01b7  movaps [rsp+0x20], xmm14
00007942783e01bd  lea rdi, [rsp]
00007942783e01c1  mov esi, 0x00
00007942783e01c6  mov rax, 0x59DDDCBA3530
00007942783e01d0  call rax
00007942783e01d2  movaps xmm6, [rsp]
00007942783e01d6  add rsp, 0x30
00007942783e01da  vmovaps xmm0, [rsp]
00007942783e01df  vmovaps xmm1, [rsp+0x10]
00007942783e01e5  vmovaps xmm2, [rsp+0x20]
00007942783e01eb  vmovaps xmm3, [rsp+0x30]
00007942783e01f1  vmovaps xmm4, [rsp+0x40]
00007942783e01f7  vmovaps xmm5, [rsp+0x50]
00007942783e01fd  vmovaps xmm7, [rsp+0x60]
00007942783e0203  vmovaps xmm8, [rsp+0x70]
00007942783e0209  vmovaps xmm9, [rsp+0x80]
00007942783e0212  vmovaps xmm10, [rsp+0x90]
00007942783e021b  vmovaps xmm11, [rsp+0xA0]
00007942783e0224  vmovaps xmm12, [rsp+0xB0]
00007942783e022d  vmovaps xmm13, [rsp+0xC0]
00007942783e0236  vmovaps xmm14, [rsp+0xD0]
00007942783e023f  vmovaps xmm15, [rsp+0xE0]
00007942783e0248  add rsp, 0xF0
00007942783e024f  pop r11
00007942783e0251  pop r10
00007942783e0253  pop r9
00007942783e0255  pop r8
00007942783e0257  pop rsi
00007942783e0258  pop rdi
00007942783e0259  pop rdx
00007942783e025a  pop rcx
00007942783e025b  pop rax
00007942783e025c  add rsp, 0x08
00007942783e0260  jmp 0x00007942783DC58D
00007942783e0265  sub rsp, 0x08
00007942783e0269  push rax
00007942783e026a  push rcx
00007942783e026b  push rdx
00007942783e026c  push rdi
00007942783e026d  push rsi
00007942783e026e  push r8
00007942783e0270  push r9
00007942783e0272  push r10
00007942783e0274  push r11
00007942783e0276  sub rsp, 0xF0
00007942783e027d  vmovaps [rsp], xmm0
00007942783e0282  vmovaps [rsp+0x10], xmm1
00007942783e0288  vmovaps [rsp+0x20], xmm2
00007942783e028e  vmovaps [rsp+0x30], xmm3
00007942783e0294  vmovaps [rsp+0x40], xmm4
00007942783e029a  vmovaps [rsp+0x50], xmm5
00007942783e02a0  vmovaps [rsp+0x60], xmm6
00007942783e02a6  vmovaps [rsp+0x70], xmm7
00007942783e02ac  vmovaps [rsp+0x80], xmm8
00007942783e02b5  vmovaps [rsp+0x90], xmm9
00007942783e02be  vmovaps [rsp+0xA0], xmm10
00007942783e02c7  vmovaps [rsp+0xB0], xmm11
00007942783e02d0  vmovaps [rsp+0xC0], xmm12
00007942783e02d9  vmovaps [rsp+0xD0], xmm13
00007942783e02e2  vmovaps [rsp+0xE0], xmm15
00007942783e02eb  sub rsp, 0x30
00007942783e02ef  movaps [rsp], xmm14
00007942783e02f4  movaps [rsp+0x10], xmm12
00007942783e02fa  movaps [rsp+0x20], xmm1
00007942783e02ff  lea rdi, [rsp]
00007942783e0303  mov esi, 0x00
00007942783e0308  mov rax, 0x59DDDCBA3530
00007942783e0312  call rax
00007942783e0314  movaps xmm14, [rsp]
00007942783e0319  add rsp, 0x30
00007942783e031d  vmovaps xmm0, [rsp]
00007942783e0322  vmovaps xmm1, [rsp+0x10]
00007942783e0328  vmovaps xmm2, [rsp+0x20]
00007942783e032e  vmovaps xmm3, [rsp+0x30]
00007942783e0334  vmovaps xmm4, [rsp+0x40]
00007942783e033a  vmovaps xmm5, [rsp+0x50]
00007942783e0340  vmovaps xmm6, [rsp+0x60]
00007942783e0346  vmovaps xmm7, [rsp+0x70]
00007942783e034c  vmovaps xmm8, [rsp+0x80]
00007942783e0355  vmovaps xmm9, [rsp+0x90]
00007942783e035e  vmovaps xmm10, [rsp+0xA0]
00007942783e0367  vmovaps xmm11, [rsp+0xB0]
00007942783e0370  vmovaps xmm12, [rsp+0xC0]
00007942783e0379  vmovaps xmm13, [rsp+0xD0]
00007942783e0382  vmovaps xmm15, [rsp+0xE0]
00007942783e038b  add rsp, 0xF0
00007942783e0392  pop r11
00007942783e0394  pop r10
00007942783e0396  pop r9
00007942783e0398  pop r8
00007942783e039a  pop rsi
00007942783e039b  pop rdi
00007942783e039c  pop rdx
00007942783e039d  pop rcx
00007942783e039e  pop rax
00007942783e039f  add rsp, 0x08
00007942783e03a3  jmp 0x00007942783DC5B3
00007942783e03a8  sub rsp, 0x08
00007942783e03ac  push rax
00007942783e03ad  push rcx
00007942783e03ae  push rdx
00007942783e03af  push rdi
00007942783e03b0  push rsi
00007942783e03b1  push r8
00007942783e03b3  push r9
00007942783e03b5  push r10
00007942783e03b7  push r11
00007942783e03b9  sub rsp, 0xF0
00007942783e03c0  vmovaps [rsp], xmm0
00007942783e03c5  vmovaps [rsp+0x10], xmm2
00007942783e03cb  vmovaps [rsp+0x20], xmm3
00007942783e03d1  vmovaps [rsp+0x30], xmm4
00007942783e03d7  vmovaps [rsp+0x40], xmm5
00007942783e03dd  vmovaps [rsp+0x50], xmm6
00007942783e03e3  vmovaps [rsp+0x60], xmm7
00007942783e03e9  vmovaps [rsp+0x70], xmm8
00007942783e03ef  vmovaps [rsp+0x80], xmm9
00007942783e03f8  vmovaps [rsp+0x90], xmm10
00007942783e0401  vmovaps [rsp+0xA0], xmm11
00007942783e040a  vmovaps [rsp+0xB0], xmm12
00007942783e0413  vmovaps [rsp+0xC0], xmm13
00007942783e041c  vmovaps [rsp+0xD0], xmm14
00007942783e0425  vmovaps [rsp+0xE0], xmm15
00007942783e042e  sub rsp, 0x30
00007942783e0432  movaps [rsp], xmm1
00007942783e0436  movaps [rsp+0x10], xmm13
00007942783e043c  movaps [rsp+0x20], xmm9
00007942783e0442  lea rdi, [rsp]
00007942783e0446  mov esi, 0x00
00007942783e044b  mov rax, 0x59DDDCBA3530
00007942783e0455  call rax
00007942783e0457  movaps xmm1, [rsp]
00007942783e045b  add rsp, 0x30
00007942783e045f  vmovaps xmm0, [rsp]
00007942783e0464  vmovaps xmm2, [rsp+0x10]
00007942783e046a  vmovaps xmm3, [rsp+0x20]
00007942783e0470  vmovaps xmm4, [rsp+0x30]
00007942783e0476  vmovaps xmm5, [rsp+0x40]
00007942783e047c  vmovaps xmm6, [rsp+0x50]
00007942783e0482  vmovaps xmm7, [rsp+0x60]
00007942783e0488  vmovaps xmm8, [rsp+0x70]
00007942783e048e  vmovaps xmm9, [rsp+0x80]
00007942783e0497  vmovaps xmm10, [rsp+0x90]
00007942783e04a0  vmovaps xmm11, [rsp+0xA0]
00007942783e04a9  vmovaps xmm12, [rsp+0xB0]
00007942783e04b2  vmovaps xmm13, [rsp+0xC0]
00007942783e04bb  vmovaps xmm14, [rsp+0xD0]
00007942783e04c4  vmovaps xmm15, [rsp+0xE0]
00007942783e04cd  add rsp, 0xF0
00007942783e04d4  pop r11
00007942783e04d6  pop r10
00007942783e04d8  pop r9
00007942783e04da  pop r8
00007942783e04dc  pop rsi
00007942783e04dd  pop rdi
00007942783e04de  pop rdx
00007942783e04df  pop rcx
00007942783e04e0  pop rax
00007942783e04e1  add rsp, 0x08
00007942783e04e5  jmp 0x00007942783DC5CD
00007942783e04ea  sub rsp, 0x08
00007942783e04ee  push rax
00007942783e04ef  push rcx
00007942783e04f0  push rdx
00007942783e04f1  push rdi
00007942783e04f2  push rsi
00007942783e04f3  push r8
00007942783e04f5  push r9
00007942783e04f7  push r10
00007942783e04f9  push r11
00007942783e04fb  sub rsp, 0xF0
00007942783e0502  vmovaps [rsp], xmm0
00007942783e0507  vmovaps [rsp+0x10], xmm1
00007942783e050d  vmovaps [rsp+0x20], xmm2
00007942783e0513  vmovaps [rsp+0x30], xmm3
00007942783e0519  vmovaps [rsp+0x40], xmm4
00007942783e051f  vmovaps [rsp+0x50], xmm5
00007942783e0525  vmovaps [rsp+0x60], xmm6
00007942783e052b  vmovaps [rsp+0x70], xmm7
00007942783e0531  vmovaps [rsp+0x80], xmm8
00007942783e053a  vmovaps [rsp+0x90], xmm9
00007942783e0543  vmovaps [rsp+0xA0], xmm10
00007942783e054c  vmovaps [rsp+0xB0], xmm11
00007942783e0555  vmovaps [rsp+0xC0], xmm13
00007942783e055e  vmovaps [rsp+0xD0], xmm14
00007942783e0567  vmovaps [rsp+0xE0], xmm15
00007942783e0570  sub rsp, 0x30
00007942783e0574  movaps [rsp], xmm12
00007942783e0579  movaps [rsp+0x10], xmm7
00007942783e057e  movaps [rsp+0x20], xmm13
00007942783e0584  lea rdi, [rsp]
00007942783e0588  mov esi, 0x00
00007942783e058d  mov rax, 0x59DDDCBA3530
00007942783e0597  call rax
00007942783e0599  movaps xmm12, [rsp]
00007942783e059e  add rsp, 0x30
00007942783e05a2  vmovaps xmm0, [rsp]
00007942783e05a7  vmovaps xmm1, [rsp+0x10]
00007942783e05ad  vmovaps xmm2, [rsp+0x20]
00007942783e05b3  vmovaps xmm3, [rsp+0x30]
00007942783e05b9  vmovaps xmm4, [rsp+0x40]
00007942783e05bf  vmovaps xmm5, [rsp+0x50]
00007942783e05c5  vmovaps xmm6, [rsp+0x60]
00007942783e05cb  vmovaps xmm7, [rsp+0x70]
00007942783e05d1  vmovaps xmm8, [rsp+0x80]
00007942783e05da  vmovaps xmm9, [rsp+0x90]
00007942783e05e3  vmovaps xmm10, [rsp+0xA0]
00007942783e05ec  vmovaps xmm11, [rsp+0xB0]
00007942783e05f5  vmovaps xmm13, [rsp+0xC0]
00007942783e05fe  vmovaps xmm14, [rsp+0xD0]
00007942783e0607  vmovaps xmm15, [rsp+0xE0]
00007942783e0610  add rsp, 0xF0
00007942783e0617  pop r11
00007942783e0619  pop r10
00007942783e061b  pop r9
00007942783e061d  pop r8
00007942783e061f  pop rsi
00007942783e0620  pop rdi
00007942783e0621  pop rdx
00007942783e0622  pop rcx
00007942783e0623  pop rax
00007942783e0624  add rsp, 0x08
00007942783e0628  jmp 0x00007942783DC5F4
00007942783e062d  sub rsp, 0x08
00007942783e0631  push rax
00007942783e0632  push rcx
00007942783e0633  push rdx
00007942783e0634  push rdi
00007942783e0635  push rsi
00007942783e0636  push r8
00007942783e0638  push r9
00007942783e063a  push r10
00007942783e063c  push r11
00007942783e063e  sub rsp, 0xF0
00007942783e0645  vmovaps [rsp], xmm0
00007942783e064a  vmovaps [rsp+0x10], xmm1
00007942783e0650  vmovaps [rsp+0x20], xmm2
00007942783e0656  vmovaps [rsp+0x30], xmm3
00007942783e065c  vmovaps [rsp+0x40], xmm4
00007942783e0662  vmovaps [rsp+0x50], xmm5
00007942783e0668  vmovaps [rsp+0x60], xmm6
00007942783e066e  vmovaps [rsp+0x70], xmm7
00007942783e0674  vmovaps [rsp+0x80], xmm8
00007942783e067d  vmovaps [rsp+0x90], xmm9
00007942783e0686  vmovaps [rsp+0xA0], xmm10
00007942783e068f  vmovaps [rsp+0xB0], xmm11
00007942783e0698  vmovaps [rsp+0xC0], xmm12
00007942783e06a1  vmovaps [rsp+0xD0], xmm14
00007942783e06aa  vmovaps [rsp+0xE0], xmm15
00007942783e06b3  sub rsp, 0x30
00007942783e06b7  movaps [rsp], xmm13
00007942783e06bc  movaps [rsp+0x10], xmm15
00007942783e06c2  movaps [rsp+0x20], xmm8
00007942783e06c8  lea rdi, [rsp]
00007942783e06cc  mov esi, 0x00
00007942783e06d1  mov rax, 0x59DDDCBA3530
00007942783e06db  call rax
00007942783e06dd  movaps xmm13, [rsp]
00007942783e06e2  add rsp, 0x30
00007942783e06e6  vmovaps xmm0, [rsp]
00007942783e06eb  vmovaps xmm1, [rsp+0x10]
00007942783e06f1  vmovaps xmm2, [rsp+0x20]
00007942783e06f7  vmovaps xmm3, [rsp+0x30]
00007942783e06fd  vmovaps xmm4, [rsp+0x40]
00007942783e0703  vmovaps xmm5, [rsp+0x50]
00007942783e0709  vmovaps xmm6, [rsp+0x60]
00007942783e070f  vmovaps xmm7, [rsp+0x70]
00007942783e0715  vmovaps xmm8, [rsp+0x80]
00007942783e071e  vmovaps xmm9, [rsp+0x90]
00007942783e0727  vmovaps xmm10, [rsp+0xA0]
00007942783e0730  vmovaps xmm11, [rsp+0xB0]
00007942783e0739  vmovaps xmm12, [rsp+0xC0]
00007942783e0742  vmovaps xmm14, [rsp+0xD0]
00007942783e074b  vmovaps xmm15, [rsp+0xE0]
00007942783e0754  add rsp, 0xF0
00007942783e075b  pop r11
00007942783e075d  pop r10
00007942783e075f  pop r9
00007942783e0761  pop r8
00007942783e0763  pop rsi
00007942783e0764  pop rdi
00007942783e0765  pop rdx
00007942783e0766  pop rcx
00007942783e0767  pop rax
00007942783e0768  add rsp, 0x08
00007942783e076c  jmp 0x00007942783DC60F
00007942783e0771  sub rsp, 0x08
00007942783e0775  push rax
00007942783e0776  push rcx
00007942783e0777  push rdx
00007942783e0778  push rdi
00007942783e0779  push rsi
00007942783e077a  push r8
00007942783e077c  push r9
00007942783e077e  push r10
00007942783e0780  push r11
00007942783e0782  sub rsp, 0xF0
00007942783e0789  vmovaps [rsp], xmm0
00007942783e078e  vmovaps [rsp+0x10], xmm1
00007942783e0794  vmovaps [rsp+0x20], xmm2
00007942783e079a  vmovaps [rsp+0x30], xmm3
00007942783e07a0  vmovaps [rsp+0x40], xmm4
00007942783e07a6  vmovaps [rsp+0x50], xmm5
00007942783e07ac  vmovaps [rsp+0x60], xmm6
00007942783e07b2  vmovaps [rsp+0x70], xmm7
00007942783e07b8  vmovaps [rsp+0x80], xmm9
00007942783e07c1  vmovaps [rsp+0x90], xmm10
00007942783e07ca  vmovaps [rsp+0xA0], xmm11
00007942783e07d3  vmovaps [rsp+0xB0], xmm12
00007942783e07dc  vmovaps [rsp+0xC0], xmm13
00007942783e07e5  vmovaps [rsp+0xD0], xmm14
00007942783e07ee  vmovaps [rsp+0xE0], xmm15
00007942783e07f7  sub rsp, 0x30
00007942783e07fb  movaps [rsp], xmm8
00007942783e0800  movaps [rsp+0x10], xmm15
00007942783e0806  movaps [rsp+0x20], xmm9
00007942783e080c  lea rdi, [rsp]
00007942783e0810  mov esi, 0x00
00007942783e0815  mov rax, 0x59DDDCBA3530
00007942783e081f  call rax
00007942783e0821  movaps xmm8, [rsp]
00007942783e0826  add rsp, 0x30
00007942783e082a  vmovaps xmm0, [rsp]
00007942783e082f  vmovaps xmm1, [rsp+0x10]
00007942783e0835  vmovaps xmm2, [rsp+0x20]
00007942783e083b  vmovaps xmm3, [rsp+0x30]
00007942783e0841  vmovaps xmm4, [rsp+0x40]
00007942783e0847  vmovaps xmm5, [rsp+0x50]
00007942783e084d  vmovaps xmm6, [rsp+0x60]
00007942783e0853  vmovaps xmm7, [rsp+0x70]
00007942783e0859  vmovaps xmm9, [rsp+0x80]
00007942783e0862  vmovaps xmm10, [rsp+0x90]
00007942783e086b  vmovaps xmm11, [rsp+0xA0]
00007942783e0874  vmovaps xmm12, [rsp+0xB0]
00007942783e087d  vmovaps xmm13, [rsp+0xC0]
00007942783e0886  vmovaps xmm14, [rsp+0xD0]
00007942783e088f  vmovaps xmm15, [rsp+0xE0]
00007942783e0898  add rsp, 0xF0
00007942783e089f  pop r11
00007942783e08a1  pop r10
00007942783e08a3  pop r9
00007942783e08a5  pop r8
00007942783e08a7  pop rsi
00007942783e08a8  pop rdi
00007942783e08a9  pop rdx
00007942783e08aa  pop rcx
00007942783e08ab  pop rax
00007942783e08ac  add rsp, 0x08
00007942783e08b0  jmp 0x00007942783DC63D
00007942783e08b5  sub rsp, 0x08
00007942783e08b9  push rax
00007942783e08ba  push rcx
00007942783e08bb  push rdx
00007942783e08bc  push rdi
00007942783e08bd  push rsi
00007942783e08be  push r8
00007942783e08c0  push r9
00007942783e08c2  push r10
00007942783e08c4  push r11
00007942783e08c6  sub rsp, 0xF0
00007942783e08cd  vmovaps [rsp], xmm0
00007942783e08d2  vmovaps [rsp+0x10], xmm1
00007942783e08d8  vmovaps [rsp+0x20], xmm2
00007942783e08de  vmovaps [rsp+0x30], xmm3
00007942783e08e4  vmovaps [rsp+0x40], xmm4
00007942783e08ea  vmovaps [rsp+0x50], xmm5
00007942783e08f0  vmovaps [rsp+0x60], xmm6
00007942783e08f6  vmovaps [rsp+0x70], xmm7
00007942783e08fc  vmovaps [rsp+0x80], xmm8
00007942783e0905  vmovaps [rsp+0x90], xmm9
00007942783e090e  vmovaps [rsp+0xA0], xmm10
00007942783e0917  vmovaps [rsp+0xB0], xmm11
00007942783e0920  vmovaps [rsp+0xC0], xmm12
00007942783e0929  vmovaps [rsp+0xD0], xmm13
00007942783e0932  vmovaps [rsp+0xE0], xmm14
00007942783e093b  sub rsp, 0x30
00007942783e093f  movaps [rsp], xmm15
00007942783e0944  movaps [rsp+0x10], xmm11
00007942783e094a  movaps [rsp+0x20], xmm6
00007942783e094f  lea rdi, [rsp]
00007942783e0953  mov esi, 0x00
00007942783e0958  mov rax, 0x59DDDCBA3530
00007942783e0962  call rax
00007942783e0964  movaps xmm15, [rsp]
00007942783e0969  add rsp, 0x30
00007942783e096d  vmovaps xmm0, [rsp]
00007942783e0972  vmovaps xmm1, [rsp+0x10]
00007942783e0978  vmovaps xmm2, [rsp+0x20]
00007942783e097e  vmovaps xmm3, [rsp+0x30]
00007942783e0984  vmovaps xmm4, [rsp+0x40]
00007942783e098a  vmovaps xmm5, [rsp+0x50]
00007942783e0990  vmovaps xmm6, [rsp+0x60]
00007942783e0996  vmovaps xmm7, [rsp+0x70]
00007942783e099c  vmovaps xmm8, [rsp+0x80]
00007942783e09a5  vmovaps xmm9, [rsp+0x90]
00007942783e09ae  vmovaps xmm10, [rsp+0xA0]
00007942783e09b7  vmovaps xmm11, [rsp+0xB0]
00007942783e09c0  vmovaps xmm12, [rsp+0xC0]
00007942783e09c9  vmovaps xmm13, [rsp+0xD0]
00007942783e09d2  vmovaps xmm14, [rsp+0xE0]
00007942783e09db  add rsp, 0xF0
00007942783e09e2  pop r11
00007942783e09e4  pop r10
00007942783e09e6  pop r9
00007942783e09e8  pop r8
00007942783e09ea  pop rsi
00007942783e09eb  pop rdi
00007942783e09ec  pop rdx
00007942783e09ed  pop rcx
00007942783e09ee  pop rax
00007942783e09ef  add rsp, 0x08
00007942783e09f3  jmp 0x00007942783DC658
00007942783e09f8  sub rsp, 0x08
00007942783e09fc  push rax
00007942783e09fd  push rcx
00007942783e09fe  push rdx
00007942783e09ff  push rdi
00007942783e0a00  push rsi
00007942783e0a01  push r8
00007942783e0a03  push r9
00007942783e0a05  push r10
00007942783e0a07  push r11
00007942783e0a09  sub rsp, 0xF0
00007942783e0a10  vmovaps [rsp], xmm0
00007942783e0a15  vmovaps [rsp+0x10], xmm1
00007942783e0a1b  vmovaps [rsp+0x20], xmm2
00007942783e0a21  vmovaps [rsp+0x30], xmm3
00007942783e0a27  vmovaps [rsp+0x40], xmm4
00007942783e0a2d  vmovaps [rsp+0x50], xmm5
00007942783e0a33  vmovaps [rsp+0x60], xmm6
00007942783e0a39  vmovaps [rsp+0x70], xmm8
00007942783e0a3f  vmovaps [rsp+0x80], xmm9
00007942783e0a48  vmovaps [rsp+0x90], xmm10
00007942783e0a51  vmovaps [rsp+0xA0], xmm11
00007942783e0a5a  vmovaps [rsp+0xB0], xmm12
00007942783e0a63  vmovaps [rsp+0xC0], xmm13
00007942783e0a6c  vmovaps [rsp+0xD0], xmm14
00007942783e0a75  vmovaps [rsp+0xE0], xmm15
00007942783e0a7e  sub rsp, 0x30
00007942783e0a82  movaps [rsp], xmm7
00007942783e0a86  movaps [rsp+0x10], xmm11
00007942783e0a8c  movaps [rsp+0x20], xmm9
00007942783e0a92  lea rdi, [rsp]
00007942783e0a96  mov esi, 0x00
00007942783e0a9b  mov rax, 0x59DDDCBA3530
00007942783e0aa5  call rax
00007942783e0aa7  movaps xmm7, [rsp]
00007942783e0aab  add rsp, 0x30
00007942783e0aaf  vmovaps xmm0, [rsp]
00007942783e0ab4  vmovaps xmm1, [rsp+0x10]
00007942783e0aba  vmovaps xmm2, [rsp+0x20]
00007942783e0ac0  vmovaps xmm3, [rsp+0x30]
00007942783e0ac6  vmovaps xmm4, [rsp+0x40]
00007942783e0acc  vmovaps xmm5, [rsp+0x50]
00007942783e0ad2  vmovaps xmm6, [rsp+0x60]
00007942783e0ad8  vmovaps xmm8, [rsp+0x70]
00007942783e0ade  vmovaps xmm9, [rsp+0x80]
00007942783e0ae7  vmovaps xmm10, [rsp+0x90]
00007942783e0af0  vmovaps xmm11, [rsp+0xA0]
00007942783e0af9  vmovaps xmm12, [rsp+0xB0]
00007942783e0b02  vmovaps xmm13, [rsp+0xC0]
00007942783e0b0b  vmovaps xmm14, [rsp+0xD0]
00007942783e0b14  vmovaps xmm15, [rsp+0xE0]
00007942783e0b1d  add rsp, 0xF0
00007942783e0b24  pop r11
00007942783e0b26  pop r10
00007942783e0b28  pop r9
00007942783e0b2a  pop r8
00007942783e0b2c  pop rsi
00007942783e0b2d  pop rdi
00007942783e0b2e  pop rdx
00007942783e0b2f  pop rcx
00007942783e0b30  pop rax
00007942783e0b31  add rsp, 0x08
00007942783e0b35  jmp 0x00007942783DC685
00007942783e0b3a  sub rsp, 0x08
00007942783e0b3e  push rax
00007942783e0b3f  push rcx
00007942783e0b40  push rdx
00007942783e0b41  push rdi
00007942783e0b42  push rsi
00007942783e0b43  push r8
00007942783e0b45  push r9
00007942783e0b47  push r10
00007942783e0b49  push r11
00007942783e0b4b  sub rsp, 0xF0
00007942783e0b52  vmovaps [rsp], xmm0
00007942783e0b57  vmovaps [rsp+0x10], xmm1
00007942783e0b5d  vmovaps [rsp+0x20], xmm2
00007942783e0b63  vmovaps [rsp+0x30], xmm3
00007942783e0b69  vmovaps [rsp+0x40], xmm4
00007942783e0b6f  vmovaps [rsp+0x50], xmm5
00007942783e0b75  vmovaps [rsp+0x60], xmm6
00007942783e0b7b  vmovaps [rsp+0x70], xmm7
00007942783e0b81  vmovaps [rsp+0x80], xmm8
00007942783e0b8a  vmovaps [rsp+0x90], xmm9
00007942783e0b93  vmovaps [rsp+0xA0], xmm10
00007942783e0b9c  vmovaps [rsp+0xB0], xmm12
00007942783e0ba5  vmovaps [rsp+0xC0], xmm13
00007942783e0bae  vmovaps [rsp+0xD0], xmm14
00007942783e0bb7  vmovaps [rsp+0xE0], xmm15
00007942783e0bc0  sub rsp, 0x30
00007942783e0bc4  movaps [rsp], xmm11
00007942783e0bc9  movaps [rsp+0x10], xmm10
00007942783e0bcf  movaps [rsp+0x20], xmm14
00007942783e0bd5  lea rdi, [rsp]
00007942783e0bd9  mov esi, 0x00
00007942783e0bde  mov rax, 0x59DDDCBA3530
00007942783e0be8  call rax
00007942783e0bea  movaps xmm11, [rsp]
00007942783e0bef  add rsp, 0x30
00007942783e0bf3  vmovaps xmm0, [rsp]
00007942783e0bf8  vmovaps xmm1, [rsp+0x10]
00007942783e0bfe  vmovaps xmm2, [rsp+0x20]
00007942783e0c04  vmovaps xmm3, [rsp+0x30]
00007942783e0c0a  vmovaps xmm4, [rsp+0x40]
00007942783e0c10  vmovaps xmm5, [rsp+0x50]
00007942783e0c16  vmovaps xmm6, [rsp+0x60]
00007942783e0c1c  vmovaps xmm7, [rsp+0x70]
00007942783e0c22  vmovaps xmm8, [rsp+0x80]
00007942783e0c2b  vmovaps xmm9, [rsp+0x90]
00007942783e0c34  vmovaps xmm10, [rsp+0xA0]
00007942783e0c3d  vmovaps xmm12, [rsp+0xB0]
00007942783e0c46  vmovaps xmm13, [rsp+0xC0]
00007942783e0c4f  vmovaps xmm14, [rsp+0xD0]
00007942783e0c58  vmovaps xmm15, [rsp+0xE0]
00007942783e0c61  add rsp, 0xF0
00007942783e0c68  pop r11
00007942783e0c6a  pop r10
00007942783e0c6c  pop r9
00007942783e0c6e  pop r8
00007942783e0c70  pop rsi
00007942783e0c71  pop rdi
00007942783e0c72  pop rdx
00007942783e0c73  pop rcx
00007942783e0c74  pop rax
00007942783e0c75  add rsp, 0x08
00007942783e0c79  jmp 0x00007942783DC6A0
00007942783e0c7e  call 0x00007942782C33A0
00007942783e0c83  jmp 0x00007942783DC6AA
00007942783e0c88  sub rsp, 0x08
00007942783e0c8c  push rax
00007942783e0c8d  push rcx
00007942783e0c8e  push rdx
00007942783e0c8f  push rdi
00007942783e0c90  push rsi
00007942783e0c91  push r8
00007942783e0c93  push r9
00007942783e0c95  push r10
00007942783e0c97  push r11
00007942783e0c99  sub rsp, 0xF0
00007942783e0ca0  vmovaps [rsp], xmm0
00007942783e0ca5  vmovaps [rsp+0x10], xmm1
00007942783e0cab  vmovaps [rsp+0x20], xmm2
00007942783e0cb1  vmovaps [rsp+0x30], xmm3
00007942783e0cb7  vmovaps [rsp+0x40], xmm4
00007942783e0cbd  vmovaps [rsp+0x50], xmm5
00007942783e0cc3  vmovaps [rsp+0x60], xmm6
00007942783e0cc9  vmovaps [rsp+0x70], xmm7
00007942783e0ccf  vmovaps [rsp+0x80], xmm8
00007942783e0cd8  vmovaps [rsp+0x90], xmm9
00007942783e0ce1  vmovaps [rsp+0xA0], xmm11
00007942783e0cea  vmovaps [rsp+0xB0], xmm12
00007942783e0cf3  vmovaps [rsp+0xC0], xmm13
00007942783e0cfc  vmovaps [rsp+0xD0], xmm14
00007942783e0d05  vmovaps [rsp+0xE0], xmm15
00007942783e0d0e  sub rsp, 0x30
00007942783e0d12  movaps [rsp], xmm10
00007942783e0d17  movaps [rsp+0x10], xmm1
00007942783e0d1c  movaps [rsp+0x20], xmm12
00007942783e0d22  lea rdi, [rsp]
00007942783e0d26  mov esi, 0x00
00007942783e0d2b  mov rax, 0x59DDDCBA3530
00007942783e0d35  call rax
00007942783e0d37  movaps xmm10, [rsp]
00007942783e0d3c  add rsp, 0x30
00007942783e0d40  vmovaps xmm0, [rsp]
00007942783e0d45  vmovaps xmm1, [rsp+0x10]
00007942783e0d4b  vmovaps xmm2, [rsp+0x20]
00007942783e0d51  vmovaps xmm3, [rsp+0x30]
00007942783e0d57  vmovaps xmm4, [rsp+0x40]
00007942783e0d5d  vmovaps xmm5, [rsp+0x50]
00007942783e0d63  vmovaps xmm6, [rsp+0x60]
00007942783e0d69  vmovaps xmm7, [rsp+0x70]
00007942783e0d6f  vmovaps xmm8, [rsp+0x80]
00007942783e0d78  vmovaps xmm9, [rsp+0x90]
00007942783e0d81  vmovaps xmm11, [rsp+0xA0]
00007942783e0d8a  vmovaps xmm12, [rsp+0xB0]
00007942783e0d93  vmovaps xmm13, [rsp+0xC0]
00007942783e0d9c  vmovaps xmm14, [rsp+0xD0]
00007942783e0da5  vmovaps xmm15, [rsp+0xE0]
00007942783e0dae  add rsp, 0xF0
00007942783e0db5  pop r11
00007942783e0db7  pop r10
00007942783e0db9  pop r9
00007942783e0dbb  pop r8
00007942783e0dbd  pop rsi
00007942783e0dbe  pop rdi
00007942783e0dbf  pop rdx
00007942783e0dc0  pop rcx
00007942783e0dc1  pop rax
00007942783e0dc2  add rsp, 0x08
00007942783e0dc6  jmp 0x00007942783DC6CD
00007942783e0dcb  sub rsp, 0x08
00007942783e0dcf  push rax
00007942783e0dd0  push rcx
00007942783e0dd1  push rdx
00007942783e0dd2  push rdi
00007942783e0dd3  push rsi
00007942783e0dd4  push r8
00007942783e0dd6  push r9
00007942783e0dd8  push r10
00007942783e0dda  push r11
00007942783e0ddc  sub rsp, 0xF0
00007942783e0de3  vmovaps [rsp], xmm0
00007942783e0de8  vmovaps [rsp+0x10], xmm1
00007942783e0dee  vmovaps [rsp+0x20], xmm2
00007942783e0df4  vmovaps [rsp+0x30], xmm3
00007942783e0dfa  vmovaps [rsp+0x40], xmm4
00007942783e0e00  vmovaps [rsp+0x50], xmm5
00007942783e0e06  vmovaps [rsp+0x60], xmm6
00007942783e0e0c  vmovaps [rsp+0x70], xmm7
00007942783e0e12  vmovaps [rsp+0x80], xmm8
00007942783e0e1b  vmovaps [rsp+0x90], xmm9
00007942783e0e24  vmovaps [rsp+0xA0], xmm10
00007942783e0e2d  vmovaps [rsp+0xB0], xmm11
00007942783e0e36  vmovaps [rsp+0xC0], xmm13
00007942783e0e3f  vmovaps [rsp+0xD0], xmm14
00007942783e0e48  vmovaps [rsp+0xE0], xmm15
00007942783e0e51  sub rsp, 0x30
00007942783e0e55  movaps [rsp], xmm12
00007942783e0e5a  movaps [rsp+0x10], xmm14
00007942783e0e60  movaps [rsp+0x20], xmm1
00007942783e0e65  lea rdi, [rsp]
00007942783e0e69  mov esi, 0x00
00007942783e0e6e  mov rax, 0x59DDDCBA3530
00007942783e0e78  call rax
00007942783e0e7a  movaps xmm12, [rsp]
00007942783e0e7f  add rsp, 0x30
00007942783e0e83  vmovaps xmm0, [rsp]
00007942783e0e88  vmovaps xmm1, [rsp+0x10]
00007942783e0e8e  vmovaps xmm2, [rsp+0x20]
00007942783e0e94  vmovaps xmm3, [rsp+0x30]
00007942783e0e9a  vmovaps xmm4, [rsp+0x40]
00007942783e0ea0  vmovaps xmm5, [rsp+0x50]
00007942783e0ea6  vmovaps xmm6, [rsp+0x60]
00007942783e0eac  vmovaps xmm7, [rsp+0x70]
00007942783e0eb2  vmovaps xmm8, [rsp+0x80]
00007942783e0ebb  vmovaps xmm9, [rsp+0x90]
00007942783e0ec4  vmovaps xmm10, [rsp+0xA0]
00007942783e0ecd  vmovaps xmm11, [rsp+0xB0]
00007942783e0ed6  vmovaps xmm13, [rsp+0xC0]
00007942783e0edf  vmovaps xmm14, [rsp+0xD0]
00007942783e0ee8  vmovaps xmm15, [rsp+0xE0]
00007942783e0ef1  add rsp, 0xF0
00007942783e0ef8  pop r11
00007942783e0efa  pop r10
00007942783e0efc  pop r9
00007942783e0efe  pop r8
00007942783e0f00  pop rsi
00007942783e0f01  pop rdi
00007942783e0f02  pop rdx
00007942783e0f03  pop rcx
00007942783e0f04  pop rax
00007942783e0f05  add rsp, 0x08
00007942783e0f09  jmp 0x00007942783DC6FC
00007942783e0f0e  sub rsp, 0x08
00007942783e0f12  push rax
00007942783e0f13  push rcx
00007942783e0f14  push rdx
00007942783e0f15  push rdi
00007942783e0f16  push rsi
00007942783e0f17  push r8
00007942783e0f19  push r9
00007942783e0f1b  push r10
00007942783e0f1d  push r11
00007942783e0f1f  sub rsp, 0xF0
00007942783e0f26  vmovaps [rsp], xmm0
00007942783e0f2b  vmovaps [rsp+0x10], xmm1
00007942783e0f31  vmovaps [rsp+0x20], xmm2
00007942783e0f37  vmovaps [rsp+0x30], xmm3
00007942783e0f3d  vmovaps [rsp+0x40], xmm4
00007942783e0f43  vmovaps [rsp+0x50], xmm5
00007942783e0f49  vmovaps [rsp+0x60], xmm6
00007942783e0f4f  vmovaps [rsp+0x70], xmm7
00007942783e0f55  vmovaps [rsp+0x80], xmm8
00007942783e0f5e  vmovaps [rsp+0x90], xmm9
00007942783e0f67  vmovaps [rsp+0xA0], xmm10
00007942783e0f70  vmovaps [rsp+0xB0], xmm11
00007942783e0f79  vmovaps [rsp+0xC0], xmm12
00007942783e0f82  vmovaps [rsp+0xD0], xmm13
00007942783e0f8b  vmovaps [rsp+0xE0], xmm15
00007942783e0f94  sub rsp, 0x30
00007942783e0f98  movaps [rsp], xmm14
00007942783e0f9d  movaps [rsp+0x10], xmm9
00007942783e0fa3  movaps [rsp+0x20], xmm1
00007942783e0fa8  lea rdi, [rsp]
00007942783e0fac  mov esi, 0x00
00007942783e0fb1  mov rax, 0x59DDDCBA3530
00007942783e0fbb  call rax
00007942783e0fbd  movaps xmm14, [rsp]
00007942783e0fc2  add rsp, 0x30
00007942783e0fc6  vmovaps xmm0, [rsp]
00007942783e0fcb  vmovaps xmm1, [rsp+0x10]
00007942783e0fd1  vmovaps xmm2, [rsp+0x20]
00007942783e0fd7  vmovaps xmm3, [rsp+0x30]
00007942783e0fdd  vmovaps xmm4, [rsp+0x40]
00007942783e0fe3  vmovaps xmm5, [rsp+0x50]
00007942783e0fe9  vmovaps xmm6, [rsp+0x60]
00007942783e0fef  vmovaps xmm7, [rsp+0x70]
00007942783e0ff5  vmovaps xmm8, [rsp+0x80]
00007942783e0ffe  vmovaps xmm9, [rsp+0x90]
00007942783e1007  vmovaps xmm10, [rsp+0xA0]
00007942783e1010  vmovaps xmm11, [rsp+0xB0]
00007942783e1019  vmovaps xmm12, [rsp+0xC0]
00007942783e1022  vmovaps xmm13, [rsp+0xD0]
00007942783e102b  vmovaps xmm15, [rsp+0xE0]
00007942783e1034  add rsp, 0xF0
00007942783e103b  pop r11
00007942783e103d  pop r10
00007942783e103f  pop r9
00007942783e1041  pop r8
00007942783e1043  pop rsi
00007942783e1044  pop rdi
00007942783e1045  pop rdx
00007942783e1046  pop rcx
00007942783e1047  pop rax
00007942783e1048  add rsp, 0x08
00007942783e104c  jmp 0x00007942783DC72B
00007942783e1051  sub rsp, 0x08
00007942783e1055  push rax
00007942783e1056  push rcx
00007942783e1057  push rdx
00007942783e1058  push rdi
00007942783e1059  push rsi
00007942783e105a  push r8
00007942783e105c  push r9
00007942783e105e  push r10
00007942783e1060  push r11
00007942783e1062  sub rsp, 0xF0
00007942783e1069  vmovaps [rsp], xmm0
00007942783e106e  vmovaps [rsp+0x10], xmm2
00007942783e1074  vmovaps [rsp+0x20], xmm3
00007942783e107a  vmovaps [rsp+0x30], xmm4
00007942783e1080  vmovaps [rsp+0x40], xmm5
00007942783e1086  vmovaps [rsp+0x50], xmm6
00007942783e108c  vmovaps [rsp+0x60], xmm7
00007942783e1092  vmovaps [rsp+0x70], xmm8
00007942783e1098  vmovaps [rsp+0x80], xmm9
00007942783e10a1  vmovaps [rsp+0x90], xmm10
00007942783e10aa  vmovaps [rsp+0xA0], xmm11
00007942783e10b3  vmovaps [rsp+0xB0], xmm12
00007942783e10bc  vmovaps [rsp+0xC0], xmm13
00007942783e10c5  vmovaps [rsp+0xD0], xmm14
00007942783e10ce  vmovaps [rsp+0xE0], xmm15
00007942783e10d7  sub rsp, 0x30
00007942783e10db  movaps [rsp], xmm1
00007942783e10df  movaps [rsp+0x10], xmm13
00007942783e10e5  movaps [rsp+0x20], xmm8
00007942783e10eb  lea rdi, [rsp]
00007942783e10ef  mov esi, 0x00
00007942783e10f4  mov rax, 0x59DDDCBA3530
00007942783e10fe  call rax
00007942783e1100  movaps xmm1, [rsp]
00007942783e1104  add rsp, 0x30
00007942783e1108  vmovaps xmm0, [rsp]
00007942783e110d  vmovaps xmm2, [rsp+0x10]
00007942783e1113  vmovaps xmm3, [rsp+0x20]
00007942783e1119  vmovaps xmm4, [rsp+0x30]
00007942783e111f  vmovaps xmm5, [rsp+0x40]
00007942783e1125  vmovaps xmm6, [rsp+0x50]
00007942783e112b  vmovaps xmm7, [rsp+0x60]
00007942783e1131  vmovaps xmm8, [rsp+0x70]
00007942783e1137  vmovaps xmm9, [rsp+0x80]
00007942783e1140  vmovaps xmm10, [rsp+0x90]
00007942783e1149  vmovaps xmm11, [rsp+0xA0]
00007942783e1152  vmovaps xmm12, [rsp+0xB0]
00007942783e115b  vmovaps xmm13, [rsp+0xC0]
00007942783e1164  vmovaps xmm14, [rsp+0xD0]
00007942783e116d  vmovaps xmm15, [rsp+0xE0]
00007942783e1176  add rsp, 0xF0
00007942783e117d  pop r11
00007942783e117f  pop r10
00007942783e1181  pop r9
00007942783e1183  pop r8
00007942783e1185  pop rsi
00007942783e1186  pop rdi
00007942783e1187  pop rdx
00007942783e1188  pop rcx
00007942783e1189  pop rax
00007942783e118a  add rsp, 0x08
00007942783e118e  jmp 0x00007942783DC74D
00007942783e1193  call 0x000079427820C260
00007942783e1198  jmp 0x00007942783DC75B
00007942783e119d  call 0x00007942782BD750
00007942783e11a2  jmp 0x00007942783DC765
00007942783e11a7  sub rsp, 0x08
00007942783e11ab  push rax
00007942783e11ac  push rcx
00007942783e11ad  push rdx
00007942783e11ae  push rdi
00007942783e11af  push rsi
00007942783e11b0  push r8
00007942783e11b2  push r9
00007942783e11b4  push r10
00007942783e11b6  push r11
00007942783e11b8  sub rsp, 0xF0
00007942783e11bf  vmovaps [rsp], xmm0
00007942783e11c4  vmovaps [rsp+0x10], xmm1
00007942783e11ca  vmovaps [rsp+0x20], xmm2
00007942783e11d0  vmovaps [rsp+0x30], xmm3
00007942783e11d6  vmovaps [rsp+0x40], xmm4
00007942783e11dc  vmovaps [rsp+0x50], xmm5
00007942783e11e2  vmovaps [rsp+0x60], xmm6
00007942783e11e8  vmovaps [rsp+0x70], xmm7
00007942783e11ee  vmovaps [rsp+0x80], xmm9
00007942783e11f7  vmovaps [rsp+0x90], xmm10
00007942783e1200  vmovaps [rsp+0xA0], xmm11
00007942783e1209  vmovaps [rsp+0xB0], xmm12
00007942783e1212  vmovaps [rsp+0xC0], xmm13
00007942783e121b  vmovaps [rsp+0xD0], xmm14
00007942783e1224  vmovaps [rsp+0xE0], xmm15
00007942783e122d  sub rsp, 0x30
00007942783e1231  movaps [rsp], xmm8
00007942783e1236  movaps [rsp+0x10], xmm15
00007942783e123c  movaps [rsp+0x20], xmm7
00007942783e1241  lea rdi, [rsp]
00007942783e1245  mov esi, 0x00
00007942783e124a  mov rax, 0x59DDDCBA3530
00007942783e1254  call rax
00007942783e1256  movaps xmm8, [rsp]
00007942783e125b  add rsp, 0x30
00007942783e125f  vmovaps xmm0, [rsp]
00007942783e1264  vmovaps xmm1, [rsp+0x10]
00007942783e126a  vmovaps xmm2, [rsp+0x20]
00007942783e1270  vmovaps xmm3, [rsp+0x30]
00007942783e1276  vmovaps xmm4, [rsp+0x40]
00007942783e127c  vmovaps xmm5, [rsp+0x50]
00007942783e1282  vmovaps xmm6, [rsp+0x60]
00007942783e1288  vmovaps xmm7, [rsp+0x70]
00007942783e128e  vmovaps xmm9, [rsp+0x80]
00007942783e1297  vmovaps xmm10, [rsp+0x90]
00007942783e12a0  vmovaps xmm11, [rsp+0xA0]
00007942783e12a9  vmovaps xmm12, [rsp+0xB0]
00007942783e12b2  vmovaps xmm13, [rsp+0xC0]
00007942783e12bb  vmovaps xmm14, [rsp+0xD0]
00007942783e12c4  vmovaps xmm15, [rsp+0xE0]
00007942783e12cd  add rsp, 0xF0
00007942783e12d4  pop r11
00007942783e12d6  pop r10
00007942783e12d8  pop r9
00007942783e12da  pop r8
00007942783e12dc  pop rsi
00007942783e12dd  pop rdi
00007942783e12de  pop rdx
00007942783e12df  pop rcx
00007942783e12e0  pop rax
00007942783e12e1  add rsp, 0x08
00007942783e12e5  jmp 0x00007942783DC787
00007942783e12ea  sub rsp, 0x08
00007942783e12ee  push rax
00007942783e12ef  push rcx
00007942783e12f0  push rdx
00007942783e12f1  push rdi
00007942783e12f2  push rsi
00007942783e12f3  push r8
00007942783e12f5  push r9
00007942783e12f7  push r10
00007942783e12f9  push r11
00007942783e12fb  sub rsp, 0xF0
00007942783e1302  vmovaps [rsp], xmm0
00007942783e1307  vmovaps [rsp+0x10], xmm1
00007942783e130d  vmovaps [rsp+0x20], xmm2
00007942783e1313  vmovaps [rsp+0x30], xmm3
00007942783e1319  vmovaps [rsp+0x40], xmm4
00007942783e131f  vmovaps [rsp+0x50], xmm5
00007942783e1325  vmovaps [rsp+0x60], xmm6
00007942783e132b  vmovaps [rsp+0x70], xmm8
00007942783e1331  vmovaps [rsp+0x80], xmm9
00007942783e133a  vmovaps [rsp+0x90], xmm10
00007942783e1343  vmovaps [rsp+0xA0], xmm11
00007942783e134c  vmovaps [rsp+0xB0], xmm12
00007942783e1355  vmovaps [rsp+0xC0], xmm13
00007942783e135e  vmovaps [rsp+0xD0], xmm14
00007942783e1367  vmovaps [rsp+0xE0], xmm15
00007942783e1370  sub rsp, 0x30
00007942783e1374  movaps [rsp], xmm7
00007942783e1378  movaps [rsp+0x10], xmm9
00007942783e137e  movaps [rsp+0x20], xmm15
00007942783e1384  lea rdi, [rsp]
00007942783e1388  mov esi, 0x00
00007942783e138d  mov rax, 0x59DDDCBA3530
00007942783e1397  call rax
00007942783e1399  movaps xmm7, [rsp]
00007942783e139d  add rsp, 0x30
00007942783e13a1  vmovaps xmm0, [rsp]
00007942783e13a6  vmovaps xmm1, [rsp+0x10]
00007942783e13ac  vmovaps xmm2, [rsp+0x20]
00007942783e13b2  vmovaps xmm3, [rsp+0x30]
00007942783e13b8  vmovaps xmm4, [rsp+0x40]
00007942783e13be  vmovaps xmm5, [rsp+0x50]
00007942783e13c4  vmovaps xmm6, [rsp+0x60]
00007942783e13ca  vmovaps xmm8, [rsp+0x70]
00007942783e13d0  vmovaps xmm9, [rsp+0x80]
00007942783e13d9  vmovaps xmm10, [rsp+0x90]
00007942783e13e2  vmovaps xmm11, [rsp+0xA0]
00007942783e13eb  vmovaps xmm12, [rsp+0xB0]
00007942783e13f4  vmovaps xmm13, [rsp+0xC0]
00007942783e13fd  vmovaps xmm14, [rsp+0xD0]
00007942783e1406  vmovaps xmm15, [rsp+0xE0]
00007942783e140f  add rsp, 0xF0
00007942783e1416  pop r11
00007942783e1418  pop r10
00007942783e141a  pop r9
00007942783e141c  pop r8
00007942783e141e  pop rsi
00007942783e141f  pop rdi
00007942783e1420  pop rdx
00007942783e1421  pop rcx
00007942783e1422  pop rax
00007942783e1423  add rsp, 0x08
00007942783e1427  jmp 0x00007942783DC7B4
00007942783e142c  sub rsp, 0x08
00007942783e1430  push rax
00007942783e1431  push rcx
00007942783e1432  push rdx
00007942783e1433  push rdi
00007942783e1434  push rsi
00007942783e1435  push r8
00007942783e1437  push r9
00007942783e1439  push r10
00007942783e143b  push r11
00007942783e143d  sub rsp, 0xF0
00007942783e1444  vmovaps [rsp], xmm0
00007942783e1449  vmovaps [rsp+0x10], xmm1
00007942783e144f  vmovaps [rsp+0x20], xmm2
00007942783e1455  vmovaps [rsp+0x30], xmm3
00007942783e145b  vmovaps [rsp+0x40], xmm4
00007942783e1461  vmovaps [rsp+0x50], xmm5
00007942783e1467  vmovaps [rsp+0x60], xmm6
00007942783e146d  vmovaps [rsp+0x70], xmm7
00007942783e1473  vmovaps [rsp+0x80], xmm8
00007942783e147c  vmovaps [rsp+0x90], xmm10
00007942783e1485  vmovaps [rsp+0xA0], xmm11
00007942783e148e  vmovaps [rsp+0xB0], xmm12
00007942783e1497  vmovaps [rsp+0xC0], xmm13
00007942783e14a0  vmovaps [rsp+0xD0], xmm14
00007942783e14a9  vmovaps [rsp+0xE0], xmm15
00007942783e14b2  sub rsp, 0x30
00007942783e14b6  movaps [rsp], xmm9
00007942783e14bb  movaps [rsp+0x10], xmm13
00007942783e14c1  movaps [rsp+0x20], xmm15
00007942783e14c7  lea rdi, [rsp]
00007942783e14cb  mov esi, 0x00
00007942783e14d0  mov rax, 0x59DDDCBA3530
00007942783e14da  call rax
00007942783e14dc  movaps xmm9, [rsp]
00007942783e14e1  add rsp, 0x30
00007942783e14e5  vmovaps xmm0, [rsp]
00007942783e14ea  vmovaps xmm1, [rsp+0x10]
00007942783e14f0  vmovaps xmm2, [rsp+0x20]
00007942783e14f6  vmovaps xmm3, [rsp+0x30]
00007942783e14fc  vmovaps xmm4, [rsp+0x40]
00007942783e1502  vmovaps xmm5, [rsp+0x50]
00007942783e1508  vmovaps xmm6, [rsp+0x60]
00007942783e150e  vmovaps xmm7, [rsp+0x70]
00007942783e1514  vmovaps xmm8, [rsp+0x80]
00007942783e151d  vmovaps xmm10, [rsp+0x90]
00007942783e1526  vmovaps xmm11, [rsp+0xA0]
00007942783e152f  vmovaps xmm12, [rsp+0xB0]
00007942783e1538  vmovaps xmm13, [rsp+0xC0]
00007942783e1541  vmovaps xmm14, [rsp+0xD0]
00007942783e154a  vmovaps xmm15, [rsp+0xE0]
00007942783e1553  add rsp, 0xF0
00007942783e155a  pop r11
00007942783e155c  pop r10
00007942783e155e  pop r9
00007942783e1560  pop r8
00007942783e1562  pop rsi
00007942783e1563  pop rdi
00007942783e1564  pop rdx
00007942783e1565  pop rcx
00007942783e1566  pop rax
00007942783e1567  add rsp, 0x08
00007942783e156b  jmp 0x00007942783DC7E2
00007942783e1570  sub rsp, 0x08
00007942783e1574  push rax
00007942783e1575  push rcx
00007942783e1576  push rdx
00007942783e1577  push rdi
00007942783e1578  push rsi
00007942783e1579  push r8
00007942783e157b  push r9
00007942783e157d  push r10
00007942783e157f  push r11
00007942783e1581  sub rsp, 0xF0
00007942783e1588  vmovaps [rsp], xmm0
00007942783e158d  vmovaps [rsp+0x10], xmm1
00007942783e1593  vmovaps [rsp+0x20], xmm2
00007942783e1599  vmovaps [rsp+0x30], xmm3
00007942783e159f  vmovaps [rsp+0x40], xmm4
00007942783e15a5  vmovaps [rsp+0x50], xmm5
00007942783e15ab  vmovaps [rsp+0x60], xmm6
00007942783e15b1  vmovaps [rsp+0x70], xmm7
00007942783e15b7  vmovaps [rsp+0x80], xmm8
00007942783e15c0  vmovaps [rsp+0x90], xmm9
00007942783e15c9  vmovaps [rsp+0xA0], xmm10
00007942783e15d2  vmovaps [rsp+0xB0], xmm11
00007942783e15db  vmovaps [rsp+0xC0], xmm12
00007942783e15e4  vmovaps [rsp+0xD0], xmm13
00007942783e15ed  vmovaps [rsp+0xE0], xmm14
00007942783e15f6  sub rsp, 0x30
00007942783e15fa  movaps [rsp], xmm15
00007942783e15ff  movaps [rsp+0x10], xmm11
00007942783e1605  movaps [rsp+0x20], xmm12
00007942783e160b  lea rdi, [rsp]
00007942783e160f  mov esi, 0x00
00007942783e1614  mov rax, 0x59DDDCBA3530
00007942783e161e  call rax
00007942783e1620  movaps xmm15, [rsp]
00007942783e1625  add rsp, 0x30
00007942783e1629  vmovaps xmm0, [rsp]
00007942783e162e  vmovaps xmm1, [rsp+0x10]
00007942783e1634  vmovaps xmm2, [rsp+0x20]
00007942783e163a  vmovaps xmm3, [rsp+0x30]
00007942783e1640  vmovaps xmm4, [rsp+0x40]
00007942783e1646  vmovaps xmm5, [rsp+0x50]
00007942783e164c  vmovaps xmm6, [rsp+0x60]
00007942783e1652  vmovaps xmm7, [rsp+0x70]
00007942783e1658  vmovaps xmm8, [rsp+0x80]
00007942783e1661  vmovaps xmm9, [rsp+0x90]
00007942783e166a  vmovaps xmm10, [rsp+0xA0]
00007942783e1673  vmovaps xmm11, [rsp+0xB0]
00007942783e167c  vmovaps xmm12, [rsp+0xC0]
00007942783e1685  vmovaps xmm13, [rsp+0xD0]
00007942783e168e  vmovaps xmm14, [rsp+0xE0]
00007942783e1697  add rsp, 0xF0
00007942783e169e  pop r11
00007942783e16a0  pop r10
00007942783e16a2  pop r9
00007942783e16a4  pop r8
00007942783e16a6  pop rsi
00007942783e16a7  pop rdi
00007942783e16a8  pop rdx
00007942783e16a9  pop rcx
00007942783e16aa  pop rax
00007942783e16ab  add rsp, 0x08
00007942783e16af  jmp 0x00007942783DC7FD
00007942783e16b4  sub rsp, 0x08
00007942783e16b8  push rax
00007942783e16b9  push rcx
00007942783e16ba  push rdx
00007942783e16bb  push rdi
00007942783e16bc  push rsi
00007942783e16bd  push r8
00007942783e16bf  push r9
00007942783e16c1  push r10
00007942783e16c3  push r11
00007942783e16c5  sub rsp, 0xF0
00007942783e16cc  vmovaps [rsp], xmm0
00007942783e16d1  vmovaps [rsp+0x10], xmm1
00007942783e16d7  vmovaps [rsp+0x20], xmm2
00007942783e16dd  vmovaps [rsp+0x30], xmm3
00007942783e16e3  vmovaps [rsp+0x40], xmm4
00007942783e16e9  vmovaps [rsp+0x50], xmm5
00007942783e16ef  vmovaps [rsp+0x60], xmm6
00007942783e16f5  vmovaps [rsp+0x70], xmm7
00007942783e16fb  vmovaps [rsp+0x80], xmm8
00007942783e1704  vmovaps [rsp+0x90], xmm9
00007942783e170d  vmovaps [rsp+0xA0], xmm10
00007942783e1716  vmovaps [rsp+0xB0], xmm11
00007942783e171f  vmovaps [rsp+0xC0], xmm12
00007942783e1728  vmovaps [rsp+0xD0], xmm14
00007942783e1731  vmovaps [rsp+0xE0], xmm15
00007942783e173a  sub rsp, 0x30
00007942783e173e  movaps [rsp], xmm13
00007942783e1743  movaps [rsp+0x10], xmm10
00007942783e1749  movaps [rsp+0x20], xmm14
00007942783e174f  lea rdi, [rsp]
00007942783e1753  mov esi, 0x00
00007942783e1758  mov rax, 0x59DDDCBA3530
00007942783e1762  call rax
00007942783e1764  movaps xmm13, [rsp]
00007942783e1769  add rsp, 0x30
00007942783e176d  vmovaps xmm0, [rsp]
00007942783e1772  vmovaps xmm1, [rsp+0x10]
00007942783e1778  vmovaps xmm2, [rsp+0x20]
00007942783e177e  vmovaps xmm3, [rsp+0x30]
00007942783e1784  vmovaps xmm4, [rsp+0x40]
00007942783e178a  vmovaps xmm5, [rsp+0x50]
00007942783e1790  vmovaps xmm6, [rsp+0x60]
00007942783e1796  vmovaps xmm7, [rsp+0x70]
00007942783e179c  vmovaps xmm8, [rsp+0x80]
00007942783e17a5  vmovaps xmm9, [rsp+0x90]
00007942783e17ae  vmovaps xmm10, [rsp+0xA0]
00007942783e17b7  vmovaps xmm11, [rsp+0xB0]
00007942783e17c0  vmovaps xmm12, [rsp+0xC0]
00007942783e17c9  vmovaps xmm14, [rsp+0xD0]
00007942783e17d2  vmovaps xmm15, [rsp+0xE0]
00007942783e17db  add rsp, 0xF0
00007942783e17e2  pop r11
00007942783e17e4  pop r10
00007942783e17e6  pop r9
00007942783e17e8  pop r8
00007942783e17ea  pop rsi
00007942783e17eb  pop rdi
00007942783e17ec  pop rdx
00007942783e17ed  pop rcx
00007942783e17ee  pop rax
00007942783e17ef  add rsp, 0x08
00007942783e17f3  jmp 0x00007942783DC820
00007942783e17f8  sub rsp, 0x08
00007942783e17fc  push rax
00007942783e17fd  push rcx
00007942783e17fe  push rdx
00007942783e17ff  push rdi
00007942783e1800  push rsi
00007942783e1801  push r8
00007942783e1803  push r9
00007942783e1805  push r10
00007942783e1807  push r11
00007942783e1809  sub rsp, 0xF0
00007942783e1810  vmovaps [rsp], xmm0
00007942783e1815  vmovaps [rsp+0x10], xmm1
00007942783e181b  vmovaps [rsp+0x20], xmm2
00007942783e1821  vmovaps [rsp+0x30], xmm3
00007942783e1827  vmovaps [rsp+0x40], xmm4
00007942783e182d  vmovaps [rsp+0x50], xmm5
00007942783e1833  vmovaps [rsp+0x60], xmm6
00007942783e1839  vmovaps [rsp+0x70], xmm7
00007942783e183f  vmovaps [rsp+0x80], xmm8
00007942783e1848  vmovaps [rsp+0x90], xmm9
00007942783e1851  vmovaps [rsp+0xA0], xmm10
00007942783e185a  vmovaps [rsp+0xB0], xmm11
00007942783e1863  vmovaps [rsp+0xC0], xmm12
00007942783e186c  vmovaps [rsp+0xD0], xmm13
00007942783e1875  vmovaps [rsp+0xE0], xmm15
00007942783e187e  sub rsp, 0x30
00007942783e1882  movaps [rsp], xmm14
00007942783e1887  movaps [rsp+0x10], xmm1
00007942783e188c  movaps [rsp+0x20], xmm7
00007942783e1891  lea rdi, [rsp]
00007942783e1895  mov esi, 0x00
00007942783e189a  mov rax, 0x59DDDCBA3530
00007942783e18a4  call rax
00007942783e18a6  movaps xmm14, [rsp]
00007942783e18ab  add rsp, 0x30
00007942783e18af  vmovaps xmm0, [rsp]
00007942783e18b4  vmovaps xmm1, [rsp+0x10]
00007942783e18ba  vmovaps xmm2, [rsp+0x20]
00007942783e18c0  vmovaps xmm3, [rsp+0x30]
00007942783e18c6  vmovaps xmm4, [rsp+0x40]
00007942783e18cc  vmovaps xmm5, [rsp+0x50]
00007942783e18d2  vmovaps xmm6, [rsp+0x60]
00007942783e18d8  vmovaps xmm7, [rsp+0x70]
00007942783e18de  vmovaps xmm8, [rsp+0x80]
00007942783e18e7  vmovaps xmm9, [rsp+0x90]
00007942783e18f0  vmovaps xmm10, [rsp+0xA0]
00007942783e18f9  vmovaps xmm11, [rsp+0xB0]
00007942783e1902  vmovaps xmm12, [rsp+0xC0]
00007942783e190b  vmovaps xmm13, [rsp+0xD0]
00007942783e1914  vmovaps xmm15, [rsp+0xE0]
00007942783e191d  add rsp, 0xF0
00007942783e1924  pop r11
00007942783e1926  pop r10
00007942783e1928  pop r9
00007942783e192a  pop r8
00007942783e192c  pop rsi
00007942783e192d  pop rdi
00007942783e192e  pop rdx
00007942783e192f  pop rcx
00007942783e1930  pop rax
00007942783e1931  add rsp, 0x08
00007942783e1935  jmp 0x00007942783DC843
00007942783e193a  sub rsp, 0x08
00007942783e193e  push rax
00007942783e193f  push rcx
00007942783e1940  push rdx
00007942783e1941  push rdi
00007942783e1942  push rsi
00007942783e1943  push r8
00007942783e1945  push r9
00007942783e1947  push r10
00007942783e1949  push r11
00007942783e194b  sub rsp, 0xF0
00007942783e1952  vmovaps [rsp], xmm0
00007942783e1957  vmovaps [rsp+0x10], xmm2
00007942783e195d  vmovaps [rsp+0x20], xmm3
00007942783e1963  vmovaps [rsp+0x30], xmm4
00007942783e1969  vmovaps [rsp+0x40], xmm5
00007942783e196f  vmovaps [rsp+0x50], xmm6
00007942783e1975  vmovaps [rsp+0x60], xmm7
00007942783e197b  vmovaps [rsp+0x70], xmm8
00007942783e1981  vmovaps [rsp+0x80], xmm9
00007942783e198a  vmovaps [rsp+0x90], xmm10
00007942783e1993  vmovaps [rsp+0xA0], xmm11
00007942783e199c  vmovaps [rsp+0xB0], xmm12
00007942783e19a5  vmovaps [rsp+0xC0], xmm13
00007942783e19ae  vmovaps [rsp+0xD0], xmm14
00007942783e19b7  vmovaps [rsp+0xE0], xmm15
00007942783e19c0  sub rsp, 0x30
00007942783e19c4  movaps [rsp], xmm1
00007942783e19c8  movaps [rsp+0x10], xmm8
00007942783e19ce  movaps [rsp+0x20], xmm9
00007942783e19d4  lea rdi, [rsp]
00007942783e19d8  mov esi, 0x00
00007942783e19dd  mov rax, 0x59DDDCBA3530
00007942783e19e7  call rax
00007942783e19e9  movaps xmm1, [rsp]
00007942783e19ed  add rsp, 0x30
00007942783e19f1  vmovaps xmm0, [rsp]
00007942783e19f6  vmovaps xmm2, [rsp+0x10]
00007942783e19fc  vmovaps xmm3, [rsp+0x20]
00007942783e1a02  vmovaps xmm4, [rsp+0x30]
00007942783e1a08  vmovaps xmm5, [rsp+0x40]
00007942783e1a0e  vmovaps xmm6, [rsp+0x50]
00007942783e1a14  vmovaps xmm7, [rsp+0x60]
00007942783e1a1a  vmovaps xmm8, [rsp+0x70]
00007942783e1a20  vmovaps xmm9, [rsp+0x80]
00007942783e1a29  vmovaps xmm10, [rsp+0x90]
00007942783e1a32  vmovaps xmm11, [rsp+0xA0]
00007942783e1a3b  vmovaps xmm12, [rsp+0xB0]
00007942783e1a44  vmovaps xmm13, [rsp+0xC0]
00007942783e1a4d  vmovaps xmm14, [rsp+0xD0]
00007942783e1a56  vmovaps xmm15, [rsp+0xE0]
00007942783e1a5f  add rsp, 0xF0
00007942783e1a66  pop r11
00007942783e1a68  pop r10
00007942783e1a6a  pop r9
00007942783e1a6c  pop r8
00007942783e1a6e  pop rsi
00007942783e1a6f  pop rdi
00007942783e1a70  pop rdx
00007942783e1a71  pop rcx
00007942783e1a72  pop rax
00007942783e1a73  add rsp, 0x08
00007942783e1a77  jmp 0x00007942783DC865
00007942783e1a7c  call 0x00007942782E5940
00007942783e1a81  jmp 0x00007942783DC873
00007942783e1a86  call 0x000079427820C380
00007942783e1a8b  jmp 0x00007942783DC87D
00007942783e1a90  call 0x000079427820D600
00007942783e1a95  jmp 0x00007942783DC887
00007942783e1a9a  call 0x00007942781FF540
00007942783e1a9f  jmp 0x00007942783DC891
00007942783e1aa4  int3
00007942783e1aa5  nop [rax+rax*1], ax
00007942783e1aae  nop
00007942783e1ab0  mov rax, [r15+0xF8]
00007942783e1ab7  lea r14, [rax+0x140]
00007942783e1abe  mov r12, [r13+r14*1]
00007942783e1ac3  mov [r15+0xE8], r12
00007942783e1aca  lea r14, [rax+0x130]
00007942783e1ad1  mov r12, [r13+r14*1]
00007942783e1ad6  lea r14, [rax+0x138]
00007942783e1add  mov r11, [r13+r14*1]
00007942783e1ae2  movq xmm1, r12
00007942783e1ae7  movq xmm15, r11
00007942783e1aec  movq xmm1, xmm1
00007942783e1af0  movq xmm1, xmm1
00007942783e1af4  movaps [r15+0x1A0], xmm1
00007942783e1afc  movq xmm15, xmm15
00007942783e1b01  movq xmm15, xmm15
00007942783e1b06  movaps [r15+0x190], xmm15
00007942783e1b0e  lea r14, [rax+0x120]
00007942783e1b15  mov r12, [r13+r14*1]
00007942783e1b1a  lea r14, [rax+0x128]
00007942783e1b21  mov r11, [r13+r14*1]
00007942783e1b26  movq xmm1, r12
00007942783e1b2b  movq xmm15, r11
00007942783e1b30  movq xmm1, xmm1
00007942783e1b34  movq xmm1, xmm1
00007942783e1b38  movaps [r15+0x1C0], xmm1
00007942783e1b40  movq xmm15, xmm15
00007942783e1b45  movq xmm15, xmm15
00007942783e1b4a  movaps [r15+0x1B0], xmm15
00007942783e1b52  lea r14, [rax+0x110]
00007942783e1b59  mov r12, [r13+r14*1]
00007942783e1b5e  lea r14, [rax+0x118]
00007942783e1b65  mov r11, [r13+r14*1]
00007942783e1b6a  movq xmm1, r12
00007942783e1b6f  movq xmm15, r11
00007942783e1b74  movq xmm1, xmm1
00007942783e1b78  movq xmm1, xmm1
00007942783e1b7c  movaps [r15+0x1E0], xmm1
00007942783e1b84  movq xmm15, xmm15
00007942783e1b89  movq xmm15, xmm15
00007942783e1b8e  movaps [r15+0x1D0], xmm15
00007942783e1b96  lea r14, [rax+0x100]
00007942783e1b9d  mov r12, [r13+r14*1]
00007942783e1ba2  lea r14, [rax+0x108]
00007942783e1ba9  mov r11, [r13+r14*1]
00007942783e1bae  movq xmm1, r12
00007942783e1bb3  movq xmm15, r11
00007942783e1bb8  movq xmm1, xmm1
00007942783e1bbc  movq xmm1, xmm1
00007942783e1bc0  movaps [r15+0x200], xmm1
00007942783e1bc8  movq xmm15, xmm15
00007942783e1bcd  movq xmm15, xmm15
00007942783e1bd2  movaps [r15+0x1F0], xmm15
00007942783e1bda  mov qword ptr [r15+0x40], 0x430000
00007942783e1be2  mov r14d, 0x430510
00007942783e1be8  mov r12, [r13+r14*1]
00007942783e1bed  movq xmm1, r12
00007942783e1bf2  lea r14, [rax+0x150]
00007942783e1bf9  mov [r15+0xF8], r14
00007942783e1c00  mov rax, [r15+0x50]
00007942783e1c04  movups xmm15, [r13+rax*1]
00007942783e1c0a  movaps [r15+0x120], xmm15
00007942783e1c12  mov qword ptr [r15+0x48], 0x10
00007942783e1c1a  xor eax, eax
00007942783e1c1c  mov r14d, 0x10
00007942783e1c22  mov r12d, 0x200
00007942783e1c28  cmp r14, r12
00007942783e1c2b  cmc
00007942783e1c2c  lahf
00007942783e1c2d  seto al
00007942783e1c30  mov [r15+0x108], eax
00007942783e1c37  pextrq rax, xmm15, 0x01
00007942783e1c3e  movq xmm14, rax
00007942783e1c43  movaps [r15+0x130], xmm14
00007942783e1c4b  movq rax, xmm1
00007942783e1c50  movq r14, xmm15
00007942783e1c55  vmovq xmm1, rax
00007942783e1c5a  vmovq xmm15, r14
00007942783e1c5f  movaps xmm13, xmm1
00007942783e1c63  addsd xmm13, xmm15
00007942783e1c68  ucomisd xmm13, xmm13
00007942783e1c6d  jp 0x00007942783E1D86
00007942783e1c73  movq xmm13, xmm13
00007942783e1c78  movq rax, xmm13
00007942783e1c7d  movq r14, xmm14
00007942783e1c82  vmovq xmm1, rax
00007942783e1c87  vmovq xmm15, r14
00007942783e1c8c  movaps xmm14, xmm1
00007942783e1c90  addsd xmm14, xmm15
00007942783e1c95  ucomisd xmm14, xmm14
00007942783e1c9a  jp 0x00007942783E1DCE
00007942783e1ca0  movq xmm14, xmm14
00007942783e1ca5  movaps [r15+0x110], xmm14
00007942783e1cad  mov eax, [r15+0x108]
00007942783e1cb4  sahf
00007942783e1cb5  jnz 0x00007942783E1CE7
00007942783e1cb7  cmp dword ptr [r15+0x318], 0x00
00007942783e1cbf  jz 0x00007942783E1FE0
00007942783e1cc5  nop [rax+rax*1], ax
00007942783e1cce  nop [rax+rax*1], eax
00007942783e1cd6  mov eax, 0x410490
00007942783e1cdb  mov [r15+0x100], rax
00007942783e1ce2  jmp 0x00007942781FE110
00007942783e1ce7  cmp dword ptr [r15+0x318], 0x00
00007942783e1cef  jz 0x00007942783E1E20
00007942783e1cf5  nop [rax+rax*1], ax
00007942783e1cfe  nop [rax+rax*1], eax
00007942783e1d06  mov eax, 0x410474
00007942783e1d0b  mov [r15+0x100], rax
00007942783e1d12  jmp 0x00007942781FE110
00007942783e1d17  int3
00007942783e1d18  call 0x00007942782E27E0
00007942783e1d1d  jmp 0x00007942783E1AC3
00007942783e1d22  call 0x00007942782E27E0
00007942783e1d27  jmp 0x00007942783E1AD6
00007942783e1d2c  call 0x00007942782E1570
00007942783e1d31  jmp 0x00007942783E1AE2
00007942783e1d36  call 0x00007942782E27E0
00007942783e1d3b  jmp 0x00007942783E1B1A
00007942783e1d40  call 0x00007942782E1570
00007942783e1d45  jmp 0x00007942783E1B26
00007942783e1d4a  call 0x00007942782E27E0
00007942783e1d4f  jmp 0x00007942783E1B5E
00007942783e1d54  call 0x00007942782E1570
00007942783e1d59  jmp 0x00007942783E1B6A
00007942783e1d5e  call 0x00007942782E27E0
00007942783e1d63  jmp 0x00007942783E1BA2
00007942783e1d68  call 0x00007942782E1570
00007942783e1d6d  jmp 0x00007942783E1BAE
00007942783e1d72  call 0x00007942782E27E0
00007942783e1d77  jmp 0x00007942783E1BED
00007942783e1d7c  call 0x000079427820E760
00007942783e1d81  jmp 0x00007942783E1C0A
00007942783e1d86  ucomisd xmm1, xmm15
00007942783e1d8b  jp 0x00007942783E1D9A
00007942783e1d8d  movaps xmm13, [0x0000794277FFE060]
00007942783e1d95  jmp 0x00007942783E1C73
00007942783e1d9a  vxorps xmm0, xmm1, xmm15
00007942783e1d9f  pextrw eax, xmm0, 0x03
00007942783e1da4  and eax, 0x7FF8
00007942783e1da9  cmp eax, 0x08
00007942783e1dac  jnz 0x00007942783E1C73
00007942783e1db2  movq rax, xmm15
00007942783e1db7  shl rax, 0x0D
00007942783e1dbb  jbe 0x00007942783E1C73
00007942783e1dc1  vorps xmm13, xmm15, [0x0000794277FFE070]
00007942783e1dc9  jmp 0x00007942783E1C73
00007942783e1dce  ucomisd xmm1, xmm15
00007942783e1dd3  jp 0x00007942783E1DE2
00007942783e1dd5  movaps xmm14, [0x0000794277FFE060]
00007942783e1ddd  jmp 0x00007942783E1CA0
00007942783e1de2  vxorps xmm0, xmm1, xmm15
00007942783e1de7  pextrw eax, xmm0, 0x03
00007942783e1dec  and eax, 0x7FF8
00007942783e1df1  cmp eax, 0x08
00007942783e1df4  jnz 0x00007942783E1CA0
00007942783e1dfa  movq rax, xmm15
00007942783e1dff  shl rax, 0x0D
00007942783e1e03  jbe 0x00007942783E1CA0
00007942783e1e09  vorps xmm14, xmm15, [0x0000794277FFE070]
00007942783e1e11  jmp 0x00007942783E1CA0
00007942783e1e16  int3
00007942783e1e17  nop [rax+rax*1], ax
00007942783e1e20  mov rax, [r15+0x48]
00007942783e1e24  mov r14, [r15+0x50]
00007942783e1e28  lea r12, [r14+rax*1]
00007942783e1e2c  movups xmm1, [r13+r12*1]
00007942783e1e32  movaps [r15+0x120], xmm1
00007942783e1e3a  lea r14, [rax+0x10]
00007942783e1e3e  mov [r15+0x48], r14
00007942783e1e42  xor eax, eax
00007942783e1e44  mov r12d, 0x200
00007942783e1e4a  cmp r14, r12
00007942783e1e4d  cmc
00007942783e1e4e  lahf
00007942783e1e4f  seto al
00007942783e1e52  mov [r15+0x108], eax
00007942783e1e59  pextrq rax, xmm1, 0x01
00007942783e1e60  movq xmm15, rax
00007942783e1e65  movaps [r15+0x130], xmm15
00007942783e1e6d  movaps xmm14, [r15+0x110]
00007942783e1e75  movq rax, xmm14
00007942783e1e7a  movq r14, xmm1
00007942783e1e7f  vmovq xmm1, rax
00007942783e1e84  vmovq xmm14, r14
00007942783e1e89  movaps xmm13, xmm1
00007942783e1e8d  addsd xmm13, xmm14
00007942783e1e92  ucomisd xmm13, xmm13
00007942783e1e97  jp 0x00007942783E1F4C
00007942783e1e9d  movq xmm13, xmm13
00007942783e1ea2  movq rax, xmm13
00007942783e1ea7  movq r14, xmm15
00007942783e1eac  vmovq xmm1, rax
00007942783e1eb1  vmovq xmm15, r14
00007942783e1eb6  movaps xmm14, xmm1
00007942783e1eba  addsd xmm14, xmm15
00007942783e1ebf  ucomisd xmm14, xmm14
00007942783e1ec4  jp 0x00007942783E1F94
00007942783e1eca  movq xmm14, xmm14
00007942783e1ecf  movaps [r15+0x110], xmm14
00007942783e1ed7  mov eax, [r15+0x108]
00007942783e1ede  sahf
00007942783e1edf  jnz 0x00007942783E1F11
00007942783e1ee1  cmp dword ptr [r15+0x318], 0x00
00007942783e1ee9  jz 0x00007942783E1FE0
00007942783e1eef  nop [rax+rax*1], ax
00007942783e1ef8  nop [rax+rax*1], eax
00007942783e1f00  mov eax, 0x410490
00007942783e1f05  mov [r15+0x100], rax
00007942783e1f0c  jmp 0x00007942781FE110
00007942783e1f11  cmp dword ptr [r15+0x318], 0x00
00007942783e1f19  jz 0x00007942783E1E20
00007942783e1f1f  nop [rax+rax*1], ax
00007942783e1f28  nop [rax+rax*1], eax
00007942783e1f30  mov eax, 0x410474
00007942783e1f35  mov [r15+0x100], rax
00007942783e1f3c  jmp 0x00007942781FE110
00007942783e1f41  int3
00007942783e1f42  call 0x00007942782B52F0
00007942783e1f47  jmp 0x00007942783E1E32
00007942783e1f4c  ucomisd xmm1, xmm14
00007942783e1f51  jp 0x00007942783E1F60
00007942783e1f53  movaps xmm13, [0x0000794277FFE060]
00007942783e1f5b  jmp 0x00007942783E1E9D
00007942783e1f60  vxorps xmm0, xmm1, xmm14
00007942783e1f65  pextrw eax, xmm0, 0x03
00007942783e1f6a  and eax, 0x7FF8
00007942783e1f6f  cmp eax, 0x08
00007942783e1f72  jnz 0x00007942783E1E9D
00007942783e1f78  movq rax, xmm14
00007942783e1f7d  shl rax, 0x0D
00007942783e1f81  jbe 0x00007942783E1E9D
00007942783e1f87  vorps xmm13, xmm14, [0x0000794277FFE070]
00007942783e1f8f  jmp 0x00007942783E1E9D
00007942783e1f94  ucomisd xmm1, xmm15
00007942783e1f99  jp 0x00007942783E1FA8
00007942783e1f9b  movaps xmm14, [0x0000794277FFE060]
00007942783e1fa3  jmp 0x00007942783E1ECA
00007942783e1fa8  vxorps xmm0, xmm1, xmm15
00007942783e1fad  pextrw eax, xmm0, 0x03
00007942783e1fb2  and eax, 0x7FF8
00007942783e1fb7  cmp eax, 0x08
00007942783e1fba  jnz 0x00007942783E1ECA
00007942783e1fc0  movq rax, xmm15
00007942783e1fc5  shl rax, 0x0D
00007942783e1fc9  jbe 0x00007942783E1ECA
00007942783e1fcf  vorps xmm14, xmm15, [0x0000794277FFE070]
00007942783e1fd7  jmp 0x00007942783E1ECA
00007942783e1fdc  int3
00007942783e1fdd  nop [rax], eax
00007942783e1fe0  mov rax, [r15+0x40]
00007942783e1fe4  lea r14, [rax+0x510]
00007942783e1feb  movaps xmm1, [r15+0x110]
00007942783e1ff3  movq rax, xmm1
00007942783e1ff8  mov [r13+r14*1], rax
00007942783e1ffd  mov rax, [r15+0xF0]
00007942783e2004  mov [r15+0x100], rax
00007942783e200b  jmp 0x00007942783CE5C0
00007942783e2010  int3
00007942783e2011  call 0x00007942782D5EB0
00007942783e2016  jmp 0x00007942783E1FFD
00007942783e201b  int3
00007942783e201c  nop [rax], eax
00007942783e2020  mov qword ptr [r15+0x100], 0x04
00007942783e202b  mov esi, 0x00
00007942783e2030  mov edx, 0x09
00007942783e2035  mov rdi, 0x7FFFA1BF6DA0
00007942783e203f  mov rax, 0x59DDDCA36970
00007942783e2049  call rax
00007942783e204b  cmp dword ptr [r15+0x318], 0x00
00007942783e2053  jnz 0x00007942781FE110
00007942783e2059  jmp 0x00007942781FE0A0
00007942783e205e  int3
00007942783e205f  int3
