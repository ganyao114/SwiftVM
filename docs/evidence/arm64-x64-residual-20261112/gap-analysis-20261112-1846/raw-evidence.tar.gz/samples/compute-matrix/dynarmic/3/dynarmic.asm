000074703edce69b  nop [rax+rax*1], eax
000074703edce6a0  vmovaps xmm1, [0x000074703E9FE010]
000074703edce6a8  movq xmm1, xmm1
000074703edce6ac  movaps [r15+0x110], xmm1
000074703edce6b4  vmovaps xmm1, [0x000074703E9FE020]
000074703edce6bc  movq xmm1, xmm1
000074703edce6c0  movaps [r15+0x120], xmm1
000074703edce6c8  mov eax, 0x4204C0
000074703edce6cd  mov r14, [r13+rax*1]
000074703edce6d2  movq xmm1, r14
000074703edce6d7  movaps [r15+0x130], xmm1
000074703edce6df  vmovaps xmm1, [0x000074703E9FE030]
000074703edce6e7  vpbroadcastq xmm1, xmm1
000074703edce6ec  movaps [r15+0x140], xmm1
000074703edce6f4  mov qword ptr [r15+0x40], 0x02
000074703edce6fc  vmovaps xmm15, [0x000074703E9FE040]
000074703edce704  movq xmm15, xmm15
000074703edce709  movaps [r15+0x150], xmm15
000074703edce711  mov qword ptr [r15+0x58], 0x420000
000074703edce719  vmovaps xmm15, [0x000074703E9FE050]
000074703edce721  vpbroadcastq xmm15, xmm15
000074703edce726  movaps [r15+0x160], xmm15
000074703edce72e  mov rax, [r15+0x40]
000074703edce732  vmovq xmm14, rax
000074703edce737  vpbroadcastq xmm14, xmm14
000074703edce73c  movaps [r15+0x170], xmm14
000074703edce744  mov eax, 0x4204D0
000074703edce749  movups xmm13, [r13+rax*1]
000074703edce74f  mov qword ptr [r15+0x40], 0x430518
000074703edce757  mov qword ptr [r15+0x50], 0x430720
000074703edce75f  vpmovqd xmm12, xmm13
000074703edce765  pxor xmm11, xmm11
000074703edce76a  punpcklqdq xmm12, xmm11
000074703edce76f  movaps [r15+0x210], xmm12
000074703edce777  movq xmm12, qword ptr [r15+0x120]
000074703edce780  movq xmm11, qword ptr [r15+0x130]
000074703edce789  psubd xmm12, xmm11
000074703edce78e  movq xmm12, xmm12
000074703edce793  paddq xmm13, xmm14
000074703edce798  movaps [r15+0x180], xmm13
000074703edce7a0  movq xmm14, qword ptr [r15+0x150]
000074703edce7a9  paddd xmm11, xmm14
000074703edce7ae  movq xmm11, xmm11
000074703edce7b3  movq xmm11, xmm11
000074703edce7b8  movaps [r15+0x130], xmm11
000074703edce7c0  pmovzxdq xmm12, xmm12
000074703edce7c6  psllq xmm12, 0x00
000074703edce7cc  movq xmm14, qword ptr [r15+0x210]
000074703edce7d5  movq xmm13, qword ptr [r15+0x110]
000074703edce7de  paddd xmm14, xmm13
000074703edce7e3  movq xmm14, xmm14
000074703edce7e8  vcvtuqq2pd xmm12, xmm12
000074703edce7ee  pmovzxdq xmm14, xmm14
000074703edce7f4  psllq xmm14, 0x00
000074703edce7fa  vcvtuqq2pd xmm14, xmm14
000074703edce800  movaps xmm13, xmm12
000074703edce804  mulpd xmm13, xmm1
000074703edce809  vcmppd xmm11, xmm13, xmm13, 0x03
000074703edce80f  ptest xmm11, xmm11
000074703edce815  jnz 0x000074703EDCE8FF
000074703edce81b  movaps [r15+0x220], xmm13
000074703edce823  mov eax, 0x430720
000074703edce828  movups [r13+rax*1], xmm13
000074703edce82e  movaps xmm1, xmm14
000074703edce832  mulpd xmm1, xmm15
000074703edce837  vcmppd xmm13, xmm1, xmm1, 0x03
000074703edce83c  ptest xmm13, xmm13
000074703edce842  jnz 0x000074703EDCEA4C
000074703edce848  movaps [r15+0x210], xmm1
000074703edce850  mov eax, 0x430518
000074703edce855  movups [r13+rax*1], xmm1
000074703edce85b  mov qword ptr [r15+0x48], 0x10
000074703edce863  xor eax, eax
000074703edce865  mov r14d, 0x10
000074703edce86b  mov r12d, 0x200
000074703edce871  cmp r14, r12
000074703edce874  cmc
000074703edce875  lahf
000074703edce876  seto al
000074703edce879  mov [r15+0x108], eax
000074703edce880  mov eax, [r15+0x108]
000074703edce887  sahf
000074703edce888  jnz 0x000074703EDCE8BA
000074703edce88a  cmp dword ptr [r15+0x318], 0x00
000074703edce892  jz 0x000074703EDCEFF0
000074703edce898  nop [rax+rax*1], ax
000074703edce8a1  nop [rax+rax*1], eax
000074703edce8a9  mov eax, 0x4101EC
000074703edce8ae  mov [r15+0x100], rax
000074703edce8b5  jmp 0x000074703EBFE110
000074703edce8ba  cmp dword ptr [r15+0x318], 0x00
000074703edce8c2  jz 0x000074703EDCEBA0
000074703edce8c8  nop [rax+rax*1], ax
000074703edce8d1  nop [rax+rax*1], eax
000074703edce8d9  mov eax, 0x4101AC
000074703edce8de  mov [r15+0x100], rax
000074703edce8e5  jmp 0x000074703EBFE110
000074703edce8ea  int3
000074703edce8eb  call 0x000074703EC0DC20
000074703edce8f0  jmp 0x000074703EDCE6D2
000074703edce8f5  call 0x000074703EC0C260
000074703edce8fa  jmp 0x000074703EDCE74F
000074703edce8ff  sub rsp, 0x08
000074703edce903  push rax
000074703edce904  push rcx
000074703edce905  push rdx
000074703edce906  push rdi
000074703edce907  push rsi
000074703edce908  push r8
000074703edce90a  push r9
000074703edce90c  push r10
000074703edce90e  push r11
000074703edce910  sub rsp, 0xF0
000074703edce917  vmovaps [rsp], xmm0
000074703edce91c  vmovaps [rsp+0x10], xmm1
000074703edce922  vmovaps [rsp+0x20], xmm2
000074703edce928  vmovaps [rsp+0x30], xmm3
000074703edce92e  vmovaps [rsp+0x40], xmm4
000074703edce934  vmovaps [rsp+0x50], xmm5
000074703edce93a  vmovaps [rsp+0x60], xmm6
000074703edce940  vmovaps [rsp+0x70], xmm7
000074703edce946  vmovaps [rsp+0x80], xmm8
000074703edce94f  vmovaps [rsp+0x90], xmm9
000074703edce958  vmovaps [rsp+0xA0], xmm10
000074703edce961  vmovaps [rsp+0xB0], xmm11
000074703edce96a  vmovaps [rsp+0xC0], xmm12
000074703edce973  vmovaps [rsp+0xD0], xmm14
000074703edce97c  vmovaps [rsp+0xE0], xmm15
000074703edce985  sub rsp, 0x30
000074703edce989  movaps [rsp], xmm13
000074703edce98e  movaps [rsp+0x10], xmm12
000074703edce994  movaps [rsp+0x20], xmm1
000074703edce999  lea rdi, [rsp]
000074703edce99d  mov esi, 0x00
000074703edce9a2  mov rax, 0x5D9974CCC530
000074703edce9ac  call rax
000074703edce9ae  movaps xmm13, [rsp]
000074703edce9b3  add rsp, 0x30
000074703edce9b7  vmovaps xmm0, [rsp]
000074703edce9bc  vmovaps xmm1, [rsp+0x10]
000074703edce9c2  vmovaps xmm2, [rsp+0x20]
000074703edce9c8  vmovaps xmm3, [rsp+0x30]
000074703edce9ce  vmovaps xmm4, [rsp+0x40]
000074703edce9d4  vmovaps xmm5, [rsp+0x50]
000074703edce9da  vmovaps xmm6, [rsp+0x60]
000074703edce9e0  vmovaps xmm7, [rsp+0x70]
000074703edce9e6  vmovaps xmm8, [rsp+0x80]
000074703edce9ef  vmovaps xmm9, [rsp+0x90]
000074703edce9f8  vmovaps xmm10, [rsp+0xA0]
000074703edcea01  vmovaps xmm11, [rsp+0xB0]
000074703edcea0a  vmovaps xmm12, [rsp+0xC0]
000074703edcea13  vmovaps xmm14, [rsp+0xD0]
000074703edcea1c  vmovaps xmm15, [rsp+0xE0]
000074703edcea25  add rsp, 0xF0
000074703edcea2c  pop r11
000074703edcea2e  pop r10
000074703edcea30  pop r9
000074703edcea32  pop r8
000074703edcea34  pop rsi
000074703edcea35  pop rdi
000074703edcea36  pop rdx
000074703edcea37  pop rcx
000074703edcea38  pop rax
000074703edcea39  add rsp, 0x08
000074703edcea3d  jmp 0x000074703EDCE81B
000074703edcea42  call 0x000074703EC0C380
000074703edcea47  jmp 0x000074703EDCE82E
000074703edcea4c  sub rsp, 0x08
000074703edcea50  push rax
000074703edcea51  push rcx
000074703edcea52  push rdx
000074703edcea53  push rdi
000074703edcea54  push rsi
000074703edcea55  push r8
000074703edcea57  push r9
000074703edcea59  push r10
000074703edcea5b  push r11
000074703edcea5d  sub rsp, 0xF0
000074703edcea64  vmovaps [rsp], xmm0
000074703edcea69  vmovaps [rsp+0x10], xmm2
000074703edcea6f  vmovaps [rsp+0x20], xmm3
000074703edcea75  vmovaps [rsp+0x30], xmm4
000074703edcea7b  vmovaps [rsp+0x40], xmm5
000074703edcea81  vmovaps [rsp+0x50], xmm6
000074703edcea87  vmovaps [rsp+0x60], xmm7
000074703edcea8d  vmovaps [rsp+0x70], xmm8
000074703edcea93  vmovaps [rsp+0x80], xmm9
000074703edcea9c  vmovaps [rsp+0x90], xmm10
000074703edceaa5  vmovaps [rsp+0xA0], xmm11
000074703edceaae  vmovaps [rsp+0xB0], xmm12
000074703edceab7  vmovaps [rsp+0xC0], xmm13
000074703edceac0  vmovaps [rsp+0xD0], xmm14
000074703edceac9  vmovaps [rsp+0xE0], xmm15
000074703edcead2  sub rsp, 0x30
000074703edcead6  movaps [rsp], xmm1
000074703edceada  movaps [rsp+0x10], xmm14
000074703edceae0  movaps [rsp+0x20], xmm15
000074703edceae6  lea rdi, [rsp]
000074703edceaea  mov esi, 0x00
000074703edceaef  mov rax, 0x5D9974CCC530
000074703edceaf9  call rax
000074703edceafb  movaps xmm1, [rsp]
000074703edceaff  add rsp, 0x30
000074703edceb03  vmovaps xmm0, [rsp]
000074703edceb08  vmovaps xmm2, [rsp+0x10]
000074703edceb0e  vmovaps xmm3, [rsp+0x20]
000074703edceb14  vmovaps xmm4, [rsp+0x30]
000074703edceb1a  vmovaps xmm5, [rsp+0x40]
000074703edceb20  vmovaps xmm6, [rsp+0x50]
000074703edceb26  vmovaps xmm7, [rsp+0x60]
000074703edceb2c  vmovaps xmm8, [rsp+0x70]
000074703edceb32  vmovaps xmm9, [rsp+0x80]
000074703edceb3b  vmovaps xmm10, [rsp+0x90]
000074703edceb44  vmovaps xmm11, [rsp+0xA0]
000074703edceb4d  vmovaps xmm12, [rsp+0xB0]
000074703edceb56  vmovaps xmm13, [rsp+0xC0]
000074703edceb5f  vmovaps xmm14, [rsp+0xD0]
000074703edceb68  vmovaps xmm15, [rsp+0xE0]
000074703edceb71  add rsp, 0xF0
000074703edceb78  pop r11
000074703edceb7a  pop r10
000074703edceb7c  pop r9
000074703edceb7e  pop r8
000074703edceb80  pop rsi
000074703edceb81  pop rdi
000074703edceb82  pop rdx
000074703edceb83  pop rcx
000074703edceb84  pop rax
000074703edceb85  add rsp, 0x08
000074703edceb89  jmp 0x000074703EDCE848
000074703edceb8e  call 0x000074703EBFF540
000074703edceb93  jmp 0x000074703EDCE85B
000074703edceb98  int3
000074703edceb99  nop [rax], eax
000074703edceba0  movaps xmm1, [r15+0x180]
000074703edceba8  vpmovqd xmm15, xmm1
000074703edcebae  pxor xmm14, xmm14
000074703edcebb3  punpcklqdq xmm15, xmm14
000074703edcebb8  movaps [r15+0x210], xmm15
000074703edcebc0  movq xmm15, qword ptr [r15+0x120]
000074703edcebc9  movq xmm14, qword ptr [r15+0x130]
000074703edcebd2  psubd xmm15, xmm14
000074703edcebd7  movq xmm15, xmm15
000074703edcebdc  movaps xmm13, [r15+0x170]
000074703edcebe4  paddq xmm1, xmm13
000074703edcebe9  movaps [r15+0x180], xmm1
000074703edcebf1  movq xmm1, qword ptr [r15+0x150]
000074703edcebfa  paddd xmm14, xmm1
000074703edcebff  movq xmm14, xmm14
000074703edcec04  movq xmm14, xmm14
000074703edcec09  movaps [r15+0x130], xmm14
000074703edcec11  pmovzxdq xmm15, xmm15
000074703edcec17  psllq xmm15, 0x00
000074703edcec1d  movq xmm1, qword ptr [r15+0x210]
000074703edcec26  movq xmm14, qword ptr [r15+0x110]
000074703edcec2f  paddd xmm1, xmm14
000074703edcec34  movq xmm1, xmm1
000074703edcec38  vcvtuqq2pd xmm15, xmm15
000074703edcec3e  pmovzxdq xmm1, xmm1
000074703edcec43  psllq xmm1, 0x00
000074703edcec48  vcvtuqq2pd xmm1, xmm1
000074703edcec4e  movaps xmm14, [r15+0x140]
000074703edcec56  movaps xmm13, xmm15
000074703edcec5a  mulpd xmm13, xmm14
000074703edcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000074703edcec65  ptest xmm12, xmm12
000074703edcec6b  jnz 0x000074703EDCED4E
000074703edcec71  movaps [r15+0x220], xmm13
000074703edcec79  mov rax, [r15+0x48]
000074703edcec7d  mov r14, [r15+0x50]
000074703edcec81  lea r12, [r14+rax*1]
000074703edcec85  movups [r13+r12*1], xmm13
000074703edcec8b  movaps xmm15, [r15+0x160]
000074703edcec93  movaps xmm14, xmm1
000074703edcec97  mulpd xmm14, xmm15
000074703edcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000074703edceca2  ptest xmm13, xmm13
000074703edceca8  jnz 0x000074703EDCEE9C
000074703edcecae  movaps [r15+0x210], xmm14
000074703edcecb6  mov r14, [r15+0x40]
000074703edcecba  lea r12, [r14+rax*1]
000074703edcecbe  movups [r13+r12*1], xmm14
000074703edcecc4  lea r14, [rax+0x10]
000074703edcecc8  mov [r15+0x48], r14
000074703edceccc  xor eax, eax
000074703edcecce  mov r12d, 0x200
000074703edcecd4  cmp r14, r12
000074703edcecd7  cmc
000074703edcecd8  lahf
000074703edcecd9  seto al
000074703edcecdc  mov [r15+0x108], eax
000074703edcece3  mov eax, [r15+0x108]
000074703edcecea  sahf
000074703edceceb  jnz 0x000074703EDCED1D
000074703edceced  cmp dword ptr [r15+0x318], 0x00
000074703edcecf5  jz 0x000074703EDCEFF0
000074703edcecfb  nop [rax+rax*1], ax
000074703edced04  nop [rax+rax*1], eax
000074703edced0c  mov eax, 0x4101EC
000074703edced11  mov [r15+0x100], rax
000074703edced18  jmp 0x000074703EBFE110
000074703edced1d  cmp dword ptr [r15+0x318], 0x00
000074703edced25  jz 0x000074703EDCEBA0
000074703edced2b  nop [rax+rax*1], ax
000074703edced34  nop [rax+rax*1], eax
000074703edced3c  mov eax, 0x4101AC
000074703edced41  mov [r15+0x100], rax
000074703edced48  jmp 0x000074703EBFE110
000074703edced4d  int3
000074703edced4e  sub rsp, 0x08
000074703edced52  push rax
000074703edced53  push rcx
000074703edced54  push rdx
000074703edced55  push rdi
000074703edced56  push rsi
000074703edced57  push r8
000074703edced59  push r9
000074703edced5b  push r10
000074703edced5d  push r11
000074703edced5f  sub rsp, 0xF0
000074703edced66  vmovaps [rsp], xmm0
000074703edced6b  vmovaps [rsp+0x10], xmm1
000074703edced71  vmovaps [rsp+0x20], xmm2
000074703edced77  vmovaps [rsp+0x30], xmm3
000074703edced7d  vmovaps [rsp+0x40], xmm4
000074703edced83  vmovaps [rsp+0x50], xmm5
000074703edced89  vmovaps [rsp+0x60], xmm6
000074703edced8f  vmovaps [rsp+0x70], xmm7
000074703edced95  vmovaps [rsp+0x80], xmm8
000074703edced9e  vmovaps [rsp+0x90], xmm9
000074703edceda7  vmovaps [rsp+0xA0], xmm10
000074703edcedb0  vmovaps [rsp+0xB0], xmm11
000074703edcedb9  vmovaps [rsp+0xC0], xmm12
000074703edcedc2  vmovaps [rsp+0xD0], xmm14
000074703edcedcb  vmovaps [rsp+0xE0], xmm15
000074703edcedd4  sub rsp, 0x30
000074703edcedd8  movaps [rsp], xmm13
000074703edceddd  movaps [rsp+0x10], xmm15
000074703edcede3  movaps [rsp+0x20], xmm14
000074703edcede9  lea rdi, [rsp]
000074703edceded  mov esi, 0x00
000074703edcedf2  mov rax, 0x5D9974CCC530
000074703edcedfc  call rax
000074703edcedfe  movaps xmm13, [rsp]
000074703edcee03  add rsp, 0x30
000074703edcee07  vmovaps xmm0, [rsp]
000074703edcee0c  vmovaps xmm1, [rsp+0x10]
000074703edcee12  vmovaps xmm2, [rsp+0x20]
000074703edcee18  vmovaps xmm3, [rsp+0x30]
000074703edcee1e  vmovaps xmm4, [rsp+0x40]
000074703edcee24  vmovaps xmm5, [rsp+0x50]
000074703edcee2a  vmovaps xmm6, [rsp+0x60]
000074703edcee30  vmovaps xmm7, [rsp+0x70]
000074703edcee36  vmovaps xmm8, [rsp+0x80]
000074703edcee3f  vmovaps xmm9, [rsp+0x90]
000074703edcee48  vmovaps xmm10, [rsp+0xA0]
000074703edcee51  vmovaps xmm11, [rsp+0xB0]
000074703edcee5a  vmovaps xmm12, [rsp+0xC0]
000074703edcee63  vmovaps xmm14, [rsp+0xD0]
000074703edcee6c  vmovaps xmm15, [rsp+0xE0]
000074703edcee75  add rsp, 0xF0
000074703edcee7c  pop r11
000074703edcee7e  pop r10
000074703edcee80  pop r9
000074703edcee82  pop r8
000074703edcee84  pop rsi
000074703edcee85  pop rdi
000074703edcee86  pop rdx
000074703edcee87  pop rcx
000074703edcee88  pop rax
000074703edcee89  add rsp, 0x08
000074703edcee8d  jmp 0x000074703EDCEC71
000074703edcee92  call 0x000074703ECC2240
000074703edcee97  jmp 0x000074703EDCEC8B
000074703edcee9c  sub rsp, 0x08
000074703edceea0  push rax
000074703edceea1  push rcx
000074703edceea2  push rdx
000074703edceea3  push rdi
000074703edceea4  push rsi
000074703edceea5  push r8
000074703edceea7  push r9
000074703edceea9  push r10
000074703edceeab  push r11
000074703edceead  sub rsp, 0xF0
000074703edceeb4  vmovaps [rsp], xmm0
000074703edceeb9  vmovaps [rsp+0x10], xmm1
000074703edceebf  vmovaps [rsp+0x20], xmm2
000074703edceec5  vmovaps [rsp+0x30], xmm3
000074703edceecb  vmovaps [rsp+0x40], xmm4
000074703edceed1  vmovaps [rsp+0x50], xmm5
000074703edceed7  vmovaps [rsp+0x60], xmm6
000074703edceedd  vmovaps [rsp+0x70], xmm7
000074703edceee3  vmovaps [rsp+0x80], xmm8
000074703edceeec  vmovaps [rsp+0x90], xmm9
000074703edceef5  vmovaps [rsp+0xA0], xmm10
000074703edceefe  vmovaps [rsp+0xB0], xmm11
000074703edcef07  vmovaps [rsp+0xC0], xmm12
000074703edcef10  vmovaps [rsp+0xD0], xmm13
000074703edcef19  vmovaps [rsp+0xE0], xmm15
000074703edcef22  sub rsp, 0x30
000074703edcef26  movaps [rsp], xmm14
000074703edcef2b  movaps [rsp+0x10], xmm1
000074703edcef30  movaps [rsp+0x20], xmm15
000074703edcef36  lea rdi, [rsp]
000074703edcef3a  mov esi, 0x00
000074703edcef3f  mov rax, 0x5D9974CCC530
000074703edcef49  call rax
000074703edcef4b  movaps xmm14, [rsp]
000074703edcef50  add rsp, 0x30
000074703edcef54  vmovaps xmm0, [rsp]
000074703edcef59  vmovaps xmm1, [rsp+0x10]
000074703edcef5f  vmovaps xmm2, [rsp+0x20]
000074703edcef65  vmovaps xmm3, [rsp+0x30]
000074703edcef6b  vmovaps xmm4, [rsp+0x40]
000074703edcef71  vmovaps xmm5, [rsp+0x50]
000074703edcef77  vmovaps xmm6, [rsp+0x60]
000074703edcef7d  vmovaps xmm7, [rsp+0x70]
000074703edcef83  vmovaps xmm8, [rsp+0x80]
000074703edcef8c  vmovaps xmm9, [rsp+0x90]
000074703edcef95  vmovaps xmm10, [rsp+0xA0]
000074703edcef9e  vmovaps xmm11, [rsp+0xB0]
000074703edcefa7  vmovaps xmm12, [rsp+0xC0]
000074703edcefb0  vmovaps xmm13, [rsp+0xD0]
000074703edcefb9  vmovaps xmm15, [rsp+0xE0]
000074703edcefc2  add rsp, 0xF0
000074703edcefc9  pop r11
000074703edcefcb  pop r10
000074703edcefcd  pop r9
000074703edcefcf  pop r8
000074703edcefd1  pop rsi
000074703edcefd2  pop rdi
000074703edcefd3  pop rdx
000074703edcefd4  pop rcx
000074703edcefd5  pop rax
000074703edcefd6  add rsp, 0x08
000074703edcefda  jmp 0x000074703EDCECAE
000074703edcefdf  call 0x000074703ECC34C0
000074703edcefe4  jmp 0x000074703EDCECC4
000074703edcefe9  int3
000074703edcefea  nop [rax+rax*1], ax
000074703edceff0  mov rax, [r15+0xF8]
000074703edceff7  lea r14, [rax-0x150]
000074703edceffe  mov [r15+0xF8], r14
000074703edcf005  mov rax, [r15+0x50]
000074703edcf009  lea r12, [rax+0x80]
000074703edcf010  movups xmm1, [r13+r12*1]
000074703edcf016  lea r12, [rax+0x90]
000074703edcf01d  movups xmm15, [r13+r12*1]
000074703edcf023  mov qword ptr [r15+0x48], 0x00
000074703edcf02b  lea r12, [rax+0x40]
000074703edcf02f  movups xmm14, [r13+r12*1]
000074703edcf035  lea r12, [rax+0x50]
000074703edcf039  movups xmm13, [r13+r12*1]
000074703edcf03f  lea r12, [r14+0x120]
000074703edcf046  movq xmm12, qword ptr [r15+0x1C0]
000074703edcf04f  movq xmm11, qword ptr [r15+0x1B0]
000074703edcf058  movq r11, xmm12
000074703edcf05d  movq r10, xmm11
000074703edcf062  mov [r13+r12*1], r11
000074703edcf067  lea r12, [r14+0x128]
000074703edcf06e  mov [r13+r12*1], r10
000074703edcf073  vxorps xmm12, xmm12, xmm12
000074703edcf078  vpbroadcastq xmm12, xmm12
000074703edcf07d  lea r12, [r14+0x100]
000074703edcf084  movq xmm11, qword ptr [r15+0x200]
000074703edcf08d  movq xmm10, qword ptr [r15+0x1F0]
000074703edcf096  movq r11, xmm11
000074703edcf09b  movq r10, xmm10
000074703edcf0a0  mov [r13+r12*1], r11
000074703edcf0a5  lea r12, [r14+0x108]
000074703edcf0ac  mov [r13+r12*1], r10
000074703edcf0b1  lea r12, [r14+0xE0]
000074703edcf0b8  movups [r13+r12*1], xmm15
000074703edcf0be  lea r12, [r14+0xF0]
000074703edcf0c5  movups [r13+r12*1], xmm1
000074703edcf0cb  lea r12, [rax+0xC0]
000074703edcf0d2  movups xmm1, [r13+r12*1]
000074703edcf0d8  lea r12, [rax+0xD0]
000074703edcf0df  movups xmm15, [r13+r12*1]
000074703edcf0e5  lea r12, [r14+0x110]
000074703edcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000074703edcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000074703edcf0fe  movq r11, xmm11
000074703edcf103  movq r10, xmm10
000074703edcf108  mov [r13+r12*1], r11
000074703edcf10d  lea r12, [r14+0x118]
000074703edcf114  mov [r13+r12*1], r10
000074703edcf119  movups xmm11, [r13+rax*1]
000074703edcf11f  lea r12, [rax+0x10]
000074703edcf123  movups xmm10, [r13+r12*1]
000074703edcf129  lea r12, [r14+0x130]
000074703edcf130  movq xmm9, qword ptr [r15+0x1A0]
000074703edcf139  movq xmm8, qword ptr [r15+0x190]
000074703edcf142  movq r11, xmm9
000074703edcf147  movq r10, xmm8
000074703edcf14c  mov [r13+r12*1], r11
000074703edcf151  lea r12, [r14+0x138]
000074703edcf158  mov [r13+r12*1], r10
000074703edcf15d  lea r12, [rax+0x140]
000074703edcf164  movups xmm9, [r13+r12*1]
000074703edcf16a  lea r12, [rax+0x150]
000074703edcf171  movups xmm8, [r13+r12*1]
000074703edcf177  lea r12, [r14+0xC0]
000074703edcf17e  movups [r13+r12*1], xmm15
000074703edcf184  lea r12, [r14+0xD0]
000074703edcf18b  movups [r13+r12*1], xmm1
000074703edcf191  lea r12, [rax+0x100]
000074703edcf198  movups xmm1, [r13+r12*1]
000074703edcf19e  lea r12, [rax+0x110]
000074703edcf1a5  movups xmm15, [r13+r12*1]
000074703edcf1ab  lea r12, [r14+0x140]
000074703edcf1b2  mov r11, [r15+0xE8]
000074703edcf1b9  mov [r13+r12*1], r11
000074703edcf1be  lea r12, [rax+0x180]
000074703edcf1c5  movups xmm7, [r13+r12*1]
000074703edcf1cb  lea r12, [rax+0x190]
000074703edcf1d2  movups xmm6, [r13+r12*1]
000074703edcf1d8  lea r12, [rax+0x1C0]
000074703edcf1df  movups xmm5, [r13+r12*1]
000074703edcf1e5  lea r12, [rax+0x1D0]
000074703edcf1ec  movups xmm4, [r13+r12*1]
000074703edcf1f2  lea r12, [r14+0x20]
000074703edcf1f6  movups [r13+r12*1], xmm1
000074703edcf1fc  lea r12, [r14+0x30]
000074703edcf200  movups [r13+r12*1], xmm13
000074703edcf206  lea r12, [rax+0x60]
000074703edcf20a  movups xmm1, [r13+r12*1]
000074703edcf210  lea r12, [rax+0x70]
000074703edcf214  movups xmm13, [r13+r12*1]
000074703edcf21a  lea r12, [rax+0x20]
000074703edcf21e  movups xmm3, [r13+r12*1]
000074703edcf224  lea r12, [rax+0x30]
000074703edcf228  movups xmm2, [r13+r12*1]
000074703edcf22e  movaps [r15+0x1F0], xmm2
000074703edcf236  lea r12, [r14+0x60]
000074703edcf23a  movups [r13+r12*1], xmm11
000074703edcf240  lea r12, [r14+0x70]
000074703edcf244  movups [r13+r12*1], xmm5
000074703edcf24a  lea r12, [rax+0xE0]
000074703edcf251  movups xmm11, [r13+r12*1]
000074703edcf257  lea r12, [rax+0xF0]
000074703edcf25e  movups xmm5, [r13+r12*1]
000074703edcf264  lea r12, [r14+0xA0]
000074703edcf26b  movups [r13+r12*1], xmm13
000074703edcf271  lea r12, [r14+0xB0]
000074703edcf278  movups [r13+r12*1], xmm1
000074703edcf27e  lea r12, [rax+0xA0]
000074703edcf285  movups xmm1, [r13+r12*1]
000074703edcf28b  lea r12, [rax+0xB0]
000074703edcf292  movups xmm13, [r13+r12*1]
000074703edcf298  lea r12, [rax+0x120]
000074703edcf29f  vmovaps [rsp+0x10], xmm1
000074703edcf2a5  movups xmm1, [r13+r12*1]
000074703edcf2ab  lea r12, [rax+0x130]
000074703edcf2b2  vmovaps [rsp+0x20], xmm1
000074703edcf2b8  movups xmm1, [r13+r12*1]
000074703edcf2be  lea r12, [rax+0x160]
000074703edcf2c5  vmovaps [rsp+0x30], xmm1
000074703edcf2cb  movups xmm1, [r13+r12*1]
000074703edcf2d1  lea r12, [rax+0x170]
000074703edcf2d8  vmovaps [rsp+0x40], xmm1
000074703edcf2de  movups xmm1, [r13+r12*1]
000074703edcf2e4  movaps [r15+0x2B0], xmm1
000074703edcf2ec  lea r12, [r14+0x80]
000074703edcf2f3  movups [r13+r12*1], xmm13
000074703edcf2f9  lea r12, [r14+0x90]
000074703edcf300  vmovaps xmm13, [rsp+0x10]
000074703edcf306  movups [r13+r12*1], xmm13
000074703edcf30c  lea r12, [rax+0x1A0]
000074703edcf313  movups xmm13, [r13+r12*1]
000074703edcf319  lea r12, [rax+0x1B0]
000074703edcf320  vmovaps [rsp+0x10], xmm1
000074703edcf326  movups xmm1, [r13+r12*1]
000074703edcf32c  movaps [r15+0x290], xmm13
000074703edcf334  movaps [r15+0x1E0], xmm1
000074703edcf33c  lea r12, [rax+0x1E0]
000074703edcf343  vmovaps [rsp+0x50], xmm1
000074703edcf349  movups xmm1, [r13+r12*1]
000074703edcf34f  lea r12, [rax+0x1F0]
000074703edcf356  vmovaps [rsp+0x60], xmm1
000074703edcf35c  movups xmm1, [r13+r12*1]
000074703edcf362  mov qword ptr [r15+0x50], 0x430920
000074703edcf36a  lea rax, [r14+0x40]
000074703edcf36e  vmovaps [rsp+0x70], xmm1
000074703edcf374  vmovaps xmm1, [rsp+0x40]
000074703edcf37a  movups [r13+rax*1], xmm1
000074703edcf380  lea rax, [r14+0x50]
000074703edcf384  movups [r13+rax*1], xmm10
000074703edcf38a  vmovaps xmm1, [rsp+0x70]
000074703edcf390  movups [r13+r14*1], xmm1
000074703edcf396  lea rax, [r14+0x10]
000074703edcf39a  vmovaps xmm1, [rsp+0x60]
000074703edcf3a0  movups [r13+rax*1], xmm1
000074703edcf3a6  mov rax, [r15+0x40]
000074703edcf3aa  vmovaps [rsp+0x40], xmm3
000074703edcf3b0  vmovaps xmm1, [rsp+0x40]
000074703edcf3b6  por xmm3, xmm1
000074703edcf3ba  vmovaps [rsp+0x40], xmm6
000074703edcf3c0  vmovaps xmm10, [rsp+0x40]
000074703edcf3c6  por xmm6, xmm10
000074703edcf3cb  lea r12, [rax+0x30]
000074703edcf3cf  mov r11, [r13+r12*1]
000074703edcf3d4  lea r12, [rax+0x38]
000074703edcf3d8  mov r10, [r13+r12*1]
000074703edcf3dd  movq xmm10, r11
000074703edcf3e2  vmovaps [rsp+0x40], xmm1
000074703edcf3e8  movq xmm1, r10
000074703edcf3ed  movq xmm10, xmm10
000074703edcf3f2  vmovaps [rsp+0x60], xmm10
000074703edcf3f8  movq xmm10, xmm10
000074703edcf3fd  movaps [r15+0x130], xmm10
000074703edcf405  movq xmm1, xmm1
000074703edcf409  vmovaps [rsp+0x70], xmm1
000074703edcf40f  movq xmm1, xmm1
000074703edcf413  movaps [r15+0x280], xmm1
000074703edcf41b  vmovaps [rsp+0x80], xmm9
000074703edcf424  vmovaps xmm1, [rsp+0x80]
000074703edcf42d  por xmm9, xmm1
000074703edcf432  lea r12, [rax+0x20]
000074703edcf436  mov r11, [r13+r12*1]
000074703edcf43b  lea r12, [rax+0x28]
000074703edcf43f  mov r10, [r13+r12*1]
000074703edcf444  movq xmm1, r11
000074703edcf449  movq xmm10, r10
000074703edcf44e  movq xmm1, xmm1
000074703edcf452  vmovaps [rsp+0x80], xmm1
000074703edcf45b  movq xmm1, xmm1
000074703edcf45f  movaps [r15+0x150], xmm1
000074703edcf467  movq xmm10, xmm10
000074703edcf46c  vmovaps [rsp+0x90], xmm10
000074703edcf475  movq xmm10, xmm10
000074703edcf47a  movaps [r15+0x140], xmm10
000074703edcf482  lea r12, [rax+0x10]
000074703edcf486  mov r11, [r13+r12*1]
000074703edcf48b  lea r12, [rax+0x18]
000074703edcf48f  mov r10, [r13+r12*1]
000074703edcf494  movq xmm1, r11
000074703edcf499  movq xmm10, r10
000074703edcf49e  movq xmm1, xmm1
000074703edcf4a2  vmovaps [rsp+0xA0], xmm1
000074703edcf4ab  movq xmm1, xmm1
000074703edcf4af  movaps [r15+0x170], xmm1
000074703edcf4b7  movq xmm10, xmm10
000074703edcf4bc  vmovaps [rsp+0xB0], xmm10
000074703edcf4c5  movq xmm10, xmm10
000074703edcf4ca  movaps [r15+0x160], xmm10
000074703edcf4d2  mov r12, [r13+rax*1]
000074703edcf4d7  vmovq xmm1, r12
000074703edcf4dc  vpbroadcastq xmm1, xmm1
000074703edcf4e1  lea r12, [rax+0x08]
000074703edcf4e5  mov rax, [r13+r12*1]
000074703edcf4ea  movq xmm10, rax
000074703edcf4ef  movaps [r15+0x230], xmm10
000074703edcf4f7  lea rax, [r14+0x50]
000074703edcf4fb  movups xmm10, [r13+rax*1]
000074703edcf501  lea rax, [r14+0x60]
000074703edcf505  vmovaps [rsp+0xC0], xmm1
000074703edcf50e  movups xmm1, [r13+rax*1]
000074703edcf514  lea rax, [r14+0x30]
000074703edcf518  vmovaps [rsp+0xD0], xmm1
000074703edcf521  movups xmm1, [r13+rax*1]
000074703edcf527  mov qword ptr [r15+0x60], 0x430920
000074703edcf52f  mov qword ptr [r15+0x58], 0x40
000074703edcf537  vmovaps [rsp+0xE0], xmm1
000074703edcf540  vmovaps [rsp+0xF0], xmm15
000074703edcf549  vmovaps xmm15, [rsp+0xC0]
000074703edcf552  vmovaps [rsp+0xC0], xmm14
000074703edcf55b  vmovaps xmm14, [rsp+0x40]
000074703edcf561  vmovaps [rsp+0x40], xmm13
000074703edcf567  movaps xmm1, xmm15
000074703edcf56b  mulpd xmm1, xmm14
000074703edcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000074703edcf575  ptest xmm13, xmm13
000074703edcf57b  jnz 0x000074703EDD0682
000074703edcf581  movq xmm14, qword ptr [r15+0x230]
000074703edcf58a  vmovaps [rsp+0x100], xmm14
000074703edcf593  vpermilpd xmm14, xmm14, 0x00
000074703edcf599  vmovaps [rsp+0x110], xmm1
000074703edcf5a2  vmovaps xmm1, [rsp+0xE0]
000074703edcf5ab  vmovaps [rsp+0xE0], xmm15
000074703edcf5b4  movaps xmm13, xmm1
000074703edcf5b8  mulpd xmm13, xmm14
000074703edcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000074703edcf5c3  ptest xmm15, xmm15
000074703edcf5c9  jnz 0x000074703EDD07C4
000074703edcf5cf  vxorps xmm1, xmm1, xmm1
000074703edcf5d3  vpbroadcastq xmm1, xmm1
000074703edcf5d8  vmovaps xmm14, [rsp+0xE0]
000074703edcf5e1  vmovaps [rsp+0xE0], xmm1
000074703edcf5ea  vmovaps xmm1, [rsp+0xD0]
000074703edcf5f3  vmovaps [rsp+0xD0], xmm13
000074703edcf5fc  movaps xmm15, xmm14
000074703edcf600  mulpd xmm15, xmm1
000074703edcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000074703edcf60b  ptest xmm13, xmm13
000074703edcf611  jnz 0x000074703EDD0907
000074703edcf617  movaps xmm1, xmm14
000074703edcf61b  mulpd xmm1, xmm10
000074703edcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000074703edcf625  ptest xmm13, xmm13
000074703edcf62b  jnz 0x000074703EDD0A4A
000074703edcf631  movaps xmm13, xmm14
000074703edcf635  mulpd xmm13, xmm2
000074703edcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000074703edcf640  ptest xmm10, xmm10
000074703edcf646  jnz 0x000074703EDD0B8C
000074703edcf64c  vmovaps [rsp+0x120], xmm7
000074703edcf655  vmovaps xmm14, [rsp+0x120]
000074703edcf65e  por xmm7, xmm14
000074703edcf663  vmovaps xmm14, [rsp+0xC0]
000074703edcf66c  vmovaps xmm10, [rsp+0xC0]
000074703edcf675  por xmm14, xmm10
000074703edcf67a  vmovaps xmm2, [rsp+0x100]
000074703edcf683  vpermilpd xmm2, xmm2, 0x00
000074703edcf689  vmovaps [rsp+0xC0], xmm1
000074703edcf692  vmovaps [rsp+0x120], xmm15
000074703edcf69b  movaps xmm1, xmm10
000074703edcf69f  mulpd xmm1, xmm2
000074703edcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000074703edcf6a8  ptest xmm15, xmm15
000074703edcf6ae  jnz 0x000074703EDD0CCF
000074703edcf6b4  xor eax, eax
000074703edcf6b6  mov r12d, 0x40
000074703edcf6bc  mov r11d, 0x200
000074703edcf6c2  cmp r12, r11
000074703edcf6c5  cmc
000074703edcf6c6  lahf
000074703edcf6c7  seto al
000074703edcf6ca  mov [r15+0x108], eax
000074703edcf6d1  vmovaps xmm10, [rsp+0x110]
000074703edcf6da  vmovaps xmm2, [rsp+0xE0]
000074703edcf6e3  vmovaps [rsp+0xE0], xmm1
000074703edcf6ec  movaps xmm15, xmm10
000074703edcf6f0  addpd xmm15, xmm2
000074703edcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000074703edcf6fb  ptest xmm1, xmm1
000074703edcf700  jnz 0x000074703EDD0E10
000074703edcf706  vmovaps xmm10, [rsp+0x120]
000074703edcf70f  vmovaps [rsp+0x110], xmm15
000074703edcf718  movaps xmm1, xmm10
000074703edcf71c  addpd xmm1, xmm12
000074703edcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000074703edcf726  ptest xmm15, xmm15
000074703edcf72c  jnz 0x000074703EDD0F53
000074703edcf732  vmovaps xmm10, [rsp+0xC0]
000074703edcf73b  vmovaps [rsp+0xC0], xmm1
000074703edcf744  movaps xmm15, xmm10
000074703edcf748  addpd xmm15, xmm12
000074703edcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000074703edcf753  ptest xmm1, xmm1
000074703edcf758  jnz 0x000074703EDD1095
000074703edcf75e  vmovaps xmm1, [rsp+0x30]
000074703edcf764  vmovaps xmm12, [rsp+0x30]
000074703edcf76a  por xmm1, xmm12
000074703edcf76f  vmovaps xmm12, [rsp+0x20]
000074703edcf775  vmovaps xmm10, [rsp+0x20]
000074703edcf77b  por xmm12, xmm10
000074703edcf780  vmovaps [rsp+0x20], xmm5
000074703edcf786  vmovaps xmm10, [rsp+0x20]
000074703edcf78c  por xmm5, xmm10
000074703edcf791  vmovaps [rsp+0x20], xmm11
000074703edcf797  vmovaps xmm10, [rsp+0x20]
000074703edcf79d  por xmm11, xmm10
000074703edcf7a2  vmovaps [rsp+0x20], xmm4
000074703edcf7a8  vmovaps xmm10, [rsp+0x20]
000074703edcf7ae  por xmm4, xmm10
000074703edcf7b3  vmovaps [rsp+0x20], xmm8
000074703edcf7b9  vmovaps xmm10, [rsp+0x20]
000074703edcf7bf  por xmm8, xmm10
000074703edcf7c4  vmovaps xmm10, [rsp+0xF0]
000074703edcf7cd  vmovaps [rsp+0x20], xmm1
000074703edcf7d3  vmovaps xmm1, [rsp+0xF0]
000074703edcf7dc  por xmm10, xmm1
000074703edcf7e1  lea rax, [r14+0xA0]
000074703edcf7e8  movups xmm1, [r13+rax*1]
000074703edcf7ee  lea rax, [r14+0xB0]
000074703edcf7f5  vmovaps [rsp+0x30], xmm1
000074703edcf7fb  movups xmm1, [r13+rax*1]
000074703edcf801  vmovaps [rsp+0xF0], xmm1
000074703edcf80a  vmovaps [rsp+0x120], xmm15
000074703edcf813  movaps xmm1, xmm13
000074703edcf817  addpd xmm1, xmm2
000074703edcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000074703edcf820  ptest xmm15, xmm15
000074703edcf826  jnz 0x000074703EDD11ED
000074703edcf82c  lea rax, [r14+0xF0]
000074703edcf833  movups xmm15, [r13+rax*1]
000074703edcf839  vmovaps xmm2, [rsp+0xC0]
000074703edcf842  vmovaps [rsp+0xC0], xmm1
000074703edcf84b  vmovaps xmm1, [rsp+0xE0]
000074703edcf854  vmovaps [rsp+0xE0], xmm15
000074703edcf85d  movaps xmm13, xmm2
000074703edcf861  addpd xmm13, xmm1
000074703edcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000074703edcf86c  ptest xmm15, xmm15
000074703edcf872  jnz 0x000074703EDD1338
000074703edcf878  vmovaps xmm15, [rsp+0x120]
000074703edcf881  vmovaps xmm2, [rsp+0xD0]
000074703edcf88a  vmovaps [rsp+0xD0], xmm14
000074703edcf893  movaps xmm1, xmm15
000074703edcf897  addpd xmm1, xmm2
000074703edcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000074703edcf8a0  ptest xmm14, xmm14
000074703edcf8a6  jnz 0x000074703EDD147A
000074703edcf8ac  vmovaps xmm15, [rsp+0x100]
000074703edcf8b5  vpermilpd xmm15, xmm15, 0x00
000074703edcf8bb  vmovaps xmm2, [rsp+0xF0]
000074703edcf8c4  vmovaps [rsp+0xF0], xmm1
000074703edcf8cd  movaps xmm14, xmm2
000074703edcf8d1  mulpd xmm14, xmm15
000074703edcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000074703edcf8dc  ptest xmm1, xmm1
000074703edcf8e1  jnz 0x000074703EDD15BB
000074703edcf8e7  vmovaps xmm1, [rsp+0xA0]
000074703edcf8f0  vpermilpd xmm1, xmm1, 0x00
000074703edcf8f6  vmovaps xmm2, [rsp+0xE0]
000074703edcf8ff  vmovaps [rsp+0xE0], xmm14
000074703edcf908  movaps xmm15, xmm2
000074703edcf90c  mulpd xmm15, xmm1
000074703edcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000074703edcf917  ptest xmm14, xmm14
000074703edcf91d  jnz 0x000074703EDD16FE
000074703edcf923  lea rax, [r14+0xE0]
000074703edcf92a  movups xmm1, [r13+rax*1]
000074703edcf930  vmovaps xmm14, [rsp+0x100]
000074703edcf939  vpermilpd xmm14, xmm14, 0x00
000074703edcf93f  vmovaps [rsp+0x100], xmm1
000074703edcf948  vmovaps xmm1, [rsp+0x30]
000074703edcf94e  vmovaps [rsp+0x30], xmm15
000074703edcf954  movaps xmm2, xmm1
000074703edcf957  mulpd xmm2, xmm14
000074703edcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000074703edcf961  ptest xmm15, xmm15
000074703edcf967  jnz 0x000074703EDD184A
000074703edcf96d  vmovaps [rsp+0x120], xmm10
000074703edcf976  vmovaps xmm1, [rsp+0x120]
000074703edcf97f  por xmm10, xmm1
000074703edcf984  movaps [r15+0x300], xmm10
000074703edcf98c  vmovaps [rsp+0x120], xmm8
000074703edcf995  vmovaps xmm1, [rsp+0x120]
000074703edcf99e  por xmm8, xmm1
000074703edcf9a3  movaps [r15+0x190], xmm8
000074703edcf9ab  vmovaps xmm1, [rsp+0xA0]
000074703edcf9b4  vpermilpd xmm1, xmm1, 0x00
000074703edcf9ba  vmovaps xmm14, [rsp+0x100]
000074703edcf9c3  vmovaps [rsp+0x100], xmm13
000074703edcf9cc  movaps xmm15, xmm14
000074703edcf9d0  mulpd xmm15, xmm1
000074703edcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000074703edcf9db  ptest xmm13, xmm13
000074703edcf9e1  jnz 0x000074703EDD198B
000074703edcf9e7  lea rax, [r14+0x90]
000074703edcf9ee  movups xmm1, [r13+rax*1]
000074703edcf9f4  vmovaps [rsp+0x120], xmm4
000074703edcf9fd  vmovaps xmm14, [rsp+0x120]
000074703edcfa06  por xmm4, xmm14
000074703edcfa0b  movaps [r15+0x1C0], xmm4
000074703edcfa13  vmovaps [rsp+0x120], xmm11
000074703edcfa1c  vmovaps xmm14, [rsp+0x120]
000074703edcfa25  por xmm11, xmm14
000074703edcfa2a  movaps [r15+0x200], xmm11
000074703edcfa32  vmovaps [rsp+0x120], xmm5
000074703edcfa3b  vmovaps xmm14, [rsp+0x120]
000074703edcfa44  por xmm5, xmm14
000074703edcfa49  movaps [r15+0x2D0], xmm5
000074703edcfa51  vmovaps [rsp+0x120], xmm12
000074703edcfa5a  vmovaps xmm14, [rsp+0x120]
000074703edcfa63  por xmm12, xmm14
000074703edcfa68  movaps [r15+0x2E0], xmm12
000074703edcfa70  vmovaps xmm13, [rsp+0x110]
000074703edcfa79  vmovaps [rsp+0x110], xmm1
000074703edcfa82  vmovaps xmm1, [rsp+0xE0]
000074703edcfa8b  vmovaps [rsp+0xE0], xmm15
000074703edcfa94  movaps xmm14, xmm13
000074703edcfa98  addpd xmm14, xmm1
000074703edcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000074703edcfaa3  ptest xmm15, xmm15
000074703edcfaa9  jnz 0x000074703EDD1AD8
000074703edcfaaf  vmovaps xmm1, [rsp+0xA0]
000074703edcfab8  vpermilpd xmm1, xmm1, 0x00
000074703edcfabe  vmovaps xmm13, [rsp+0x110]
000074703edcfac7  vmovaps [rsp+0x110], xmm14
000074703edcfad0  movaps xmm15, xmm13
000074703edcfad4  mulpd xmm15, xmm1
000074703edcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000074703edcfadf  ptest xmm14, xmm14
000074703edcfae5  jnz 0x000074703EDD1C1B
000074703edcfaeb  lea rax, [r14+0x80]
000074703edcfaf2  movups xmm1, [r13+rax*1]
000074703edcfaf8  vmovaps xmm13, [rsp+0xC0]
000074703edcfb01  vmovaps [rsp+0xC0], xmm1
000074703edcfb0a  movaps xmm14, xmm13
000074703edcfb0e  addpd xmm14, xmm2
000074703edcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000074703edcfb19  ptest xmm1, xmm1
000074703edcfb1e  jnz 0x000074703EDD1D68
000074703edcfb24  vmovaps xmm13, [rsp+0x100]
000074703edcfb2d  vmovaps xmm2, [rsp+0x30]
000074703edcfb33  vmovaps [rsp+0x30], xmm15
000074703edcfb39  movaps xmm1, xmm13
000074703edcfb3d  addpd xmm1, xmm2
000074703edcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000074703edcfb46  ptest xmm15, xmm15
000074703edcfb4c  jnz 0x000074703EDD1EAB
000074703edcfb52  vmovaps xmm15, [rsp+0x20]
000074703edcfb58  vmovaps xmm13, [rsp+0x20]
000074703edcfb5e  por xmm15, xmm13
000074703edcfb63  movaps [r15+0x2F0], xmm15
000074703edcfb6b  vmovaps xmm13, [rsp+0xA0]
000074703edcfb74  vpermilpd xmm13, xmm13, 0x00
000074703edcfb7a  vmovaps [rsp+0x20], xmm1
000074703edcfb80  vmovaps xmm1, [rsp+0xC0]
000074703edcfb89  vmovaps [rsp+0xA0], xmm15
000074703edcfb92  movaps xmm2, xmm1
000074703edcfb95  mulpd xmm2, xmm13
000074703edcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000074703edcfb9f  ptest xmm15, xmm15
000074703edcfba5  jnz 0x000074703EDD1FEC
000074703edcfbab  lea rax, [r14+0xD0]
000074703edcfbb2  movups xmm1, [r13+rax*1]
000074703edcfbb8  vmovaps xmm13, [rsp+0xF0]
000074703edcfbc1  vmovaps [rsp+0xC0], xmm1
000074703edcfbca  vmovaps xmm1, [rsp+0xE0]
000074703edcfbd3  vmovaps [rsp+0xE0], xmm14
000074703edcfbdc  movaps xmm15, xmm13
000074703edcfbe0  addpd xmm15, xmm1
000074703edcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000074703edcfbeb  ptest xmm14, xmm14
000074703edcfbf1  jnz 0x000074703EDD2137
000074703edcfbf7  vmovaps xmm1, [rsp+0xB0]
000074703edcfc00  vpermilpd xmm1, xmm1, 0x00
000074703edcfc06  movaps xmm14, xmm11
000074703edcfc0a  mulpd xmm14, xmm1
000074703edcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000074703edcfc15  ptest xmm13, xmm13
000074703edcfc1b  jnz 0x000074703EDD227A
000074703edcfc21  movaps [r15+0x260], xmm14
000074703edcfc29  vxorps xmm1, xmm1, xmm1
000074703edcfc2d  vpbroadcastq xmm1, xmm1
000074703edcfc32  movaps [r15+0x1B0], xmm1
000074703edcfc3a  vmovaps xmm1, [rsp+0xB0]
000074703edcfc43  vpermilpd xmm1, xmm1, 0x00
000074703edcfc49  vmovaps xmm11, [rsp+0xC0]
000074703edcfc52  vmovaps [rsp+0xC0], xmm15
000074703edcfc5b  movaps xmm13, xmm11
000074703edcfc5f  mulpd xmm13, xmm1
000074703edcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000074703edcfc6a  ptest xmm15, xmm15
000074703edcfc70  jnz 0x000074703EDD23BD
000074703edcfc76  lea rax, [r14+0xC0]
000074703edcfc7d  movups xmm1, [r13+rax*1]
000074703edcfc83  vmovaps xmm11, [rsp+0x110]
000074703edcfc8c  vmovaps [rsp+0xF0], xmm1
000074703edcfc95  vmovaps xmm1, [rsp+0x30]
000074703edcfc9b  vmovaps [rsp+0x30], xmm14
000074703edcfca1  movaps xmm15, xmm11
000074703edcfca5  addpd xmm15, xmm1
000074703edcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000074703edcfcb0  ptest xmm14, xmm14
000074703edcfcb6  jnz 0x000074703EDD250A
000074703edcfcbc  vmovaps [rsp+0x100], xmm9
000074703edcfcc5  vmovaps xmm1, [rsp+0x100]
000074703edcfcce  por xmm9, xmm1
000074703edcfcd3  movaps [r15+0x270], xmm9
000074703edcfcdb  vmovaps [rsp+0x100], xmm6
000074703edcfce4  vmovaps xmm1, [rsp+0x100]
000074703edcfced  por xmm6, xmm1
000074703edcfcf1  movaps [r15+0x1A0], xmm6
000074703edcfcf9  vmovaps xmm14, [rsp+0xB0]
000074703edcfd02  vpermilpd xmm14, xmm14, 0x00
000074703edcfd08  vmovaps xmm6, [rsp+0xF0]
000074703edcfd11  vmovaps [rsp+0xF0], xmm1
000074703edcfd1a  movaps xmm11, xmm6
000074703edcfd1e  mulpd xmm11, xmm14
000074703edcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000074703edcfd29  ptest xmm1, xmm1
000074703edcfd2e  jnz 0x000074703EDD264D
000074703edcfd34  lea rax, [r14+0x20]
000074703edcfd38  movups xmm1, [r13+rax*1]
000074703edcfd3e  movaps [r15+0x110], xmm1
000074703edcfd46  vmovaps xmm6, [rsp+0xE0]
000074703edcfd4f  vmovaps [rsp+0xE0], xmm1
000074703edcfd58  movaps xmm14, xmm6
000074703edcfd5c  addpd xmm14, xmm2
000074703edcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000074703edcfd67  ptest xmm1, xmm1
000074703edcfd6c  jnz 0x000074703EDD279A
000074703edcfd72  vmovaps xmm1, [rsp+0xB0]
000074703edcfd7b  vpermilpd xmm1, xmm1, 0x00
000074703edcfd81  movaps xmm6, xmm5
000074703edcfd84  mulpd xmm6, xmm1
000074703edcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000074703edcfd8d  ptest xmm2, xmm2
000074703edcfd92  jnz 0x000074703EDD28DC
000074703edcfd98  vmovaps xmm5, [rsp+0x20]
000074703edcfd9e  movaps xmm1, xmm5
000074703edcfda1  addpd xmm1, xmm13
000074703edcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000074703edcfdab  ptest xmm2, xmm2
000074703edcfdb0  jnz 0x000074703EDD2A1C
000074703edcfdb6  vmovaps xmm13, [rsp+0x80]
000074703edcfdbf  vpermilpd xmm13, xmm13, 0x00
000074703edcfdc5  vmovaps xmm2, [rsp+0xE0]
000074703edcfdce  vmovaps [rsp+0x20], xmm1
000074703edcfdd4  movaps xmm5, xmm2
000074703edcfdd7  mulpd xmm5, xmm13
000074703edcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000074703edcfde1  ptest xmm1, xmm1
000074703edcfde6  jnz 0x000074703EDD2B5D
000074703edcfdec  vmovaps xmm1, [rsp+0x80]
000074703edcfdf5  vpermilpd xmm1, xmm1, 0x00
000074703edcfdfb  movaps xmm13, xmm10
000074703edcfdff  mulpd xmm13, xmm1
000074703edcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000074703edcfe0a  ptest xmm2, xmm2
000074703edcfe0f  jnz 0x000074703EDD2C9E
000074703edcfe15  vmovaps xmm10, [rsp+0x30]
000074703edcfe1b  movaps xmm1, xmm15
000074703edcfe1f  addpd xmm1, xmm10
000074703edcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000074703edcfe29  ptest xmm2, xmm2
000074703edcfe2e  jnz 0x000074703EDD2DE1
000074703edcfe34  vmovaps xmm10, [rsp+0xC0]
000074703edcfe3d  movaps xmm15, xmm10
000074703edcfe41  addpd xmm15, xmm11
000074703edcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000074703edcfe4c  ptest xmm2, xmm2
000074703edcfe51  jnz 0x000074703EDD2F23
000074703edcfe57  vmovaps xmm11, [rsp+0x80]
000074703edcfe60  vpermilpd xmm11, xmm11, 0x00
000074703edcfe66  movaps xmm10, xmm12
000074703edcfe6a  mulpd xmm10, xmm11
000074703edcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000074703edcfe75  ptest xmm2, xmm2
000074703edcfe7a  jnz 0x000074703EDD3067
000074703edcfe80  vmovaps xmm12, [rsp+0x80]
000074703edcfe89  vpermilpd xmm12, xmm12, 0x00
000074703edcfe8f  vmovaps xmm2, [rsp+0xA0]
000074703edcfe98  vmovaps [rsp+0x30], xmm1
000074703edcfe9e  movaps xmm11, xmm2
000074703edcfea2  mulpd xmm11, xmm12
000074703edcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000074703edcfead  ptest xmm1, xmm1
000074703edcfeb2  jnz 0x000074703EDD31AB
000074703edcfeb8  movaps xmm1, xmm14
000074703edcfebc  addpd xmm1, xmm6
000074703edcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000074703edcfec5  ptest xmm12, xmm12
000074703edcfecb  jnz 0x000074703EDD32EE
000074703edcfed1  vmovaps xmm12, [rsp+0x20]
000074703edcfed7  movaps xmm14, xmm12
000074703edcfedb  addpd xmm14, xmm5
000074703edcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000074703edcfee6  ptest xmm6, xmm6
000074703edcfeeb  jnz 0x000074703EDD342F
000074703edcfef1  vmovaps xmm12, [rsp+0x90]
000074703edcfefa  vpermilpd xmm12, xmm12, 0x00
000074703edcff00  movaps xmm6, xmm9
000074703edcff04  mulpd xmm6, xmm12
000074703edcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000074703edcff0e  ptest xmm5, xmm5
000074703edcff13  jnz 0x000074703EDD3572
000074703edcff19  movaps xmm12, xmm15
000074703edcff1d  addpd xmm12, xmm13
000074703edcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000074703edcff28  ptest xmm9, xmm9
000074703edcff2e  jnz 0x000074703EDD36B4
000074703edcff34  vmovaps xmm13, [rsp+0x30]
000074703edcff3a  movaps xmm15, xmm13
000074703edcff3e  addpd xmm15, xmm10
000074703edcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000074703edcff49  ptest xmm9, xmm9
000074703edcff4f  jnz 0x000074703EDD37F8
000074703edcff55  vmovaps xmm13, [rsp+0xD0]
000074703edcff5e  vmovaps xmm10, [rsp+0xD0]
000074703edcff67  por xmm13, xmm10
000074703edcff6c  movaps [r15+0x250], xmm13
000074703edcff74  vmovaps [rsp+0x20], xmm7
000074703edcff7a  vmovaps xmm13, [rsp+0x20]
000074703edcff80  por xmm7, xmm13
000074703edcff85  movaps [r15+0x2A0], xmm7
000074703edcff8d  vmovaps [rsp+0x20], xmm3
000074703edcff93  vmovaps xmm13, [rsp+0x20]
000074703edcff99  por xmm3, xmm13
000074703edcff9e  movaps [r15+0x1D0], xmm3
000074703edcffa6  lea rax, [r14+0x40]
000074703edcffaa  movups xmm13, [r13+rax*1]
000074703edcffb0  movaps [r15+0x2C0], xmm13
000074703edcffb8  vmovaps xmm10, [rsp+0x90]
000074703edcffc1  vpermilpd xmm10, xmm10, 0x00
000074703edcffc7  movaps xmm9, xmm8
000074703edcffcb  mulpd xmm9, xmm10
000074703edcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000074703edcffd6  ptest xmm5, xmm5
000074703edcffdb  jnz 0x000074703EDD3946
000074703edcffe1  movaps xmm10, xmm1
000074703edcffe5  addpd xmm10, xmm11
000074703edcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000074703edcfff0  ptest xmm8, xmm8
000074703edcfff6  jnz 0x000074703EDD3A8A
000074703edcfffc  movaps xmm1, xmm14
000074703edd0000  addpd xmm1, xmm6
000074703edd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000074703edd0009  ptest xmm11, xmm11
000074703edd000f  jnz 0x000074703EDD3BCD
000074703edd0015  vmovaps xmm14, [rsp+0x90]
000074703edd001e  vpermilpd xmm14, xmm14, 0x00
000074703edd0024  movaps xmm11, xmm13
000074703edd0028  mulpd xmm11, xmm14
000074703edd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000074703edd0033  ptest xmm8, xmm8
000074703edd0039  jnz 0x000074703EDD3D0E
000074703edd003f  vmovaps xmm14, [rsp+0x90]
000074703edd0048  vpermilpd xmm14, xmm14, 0x00
000074703edd004e  vmovaps xmm8, [rsp+0x10]
000074703edd0054  movaps xmm13, xmm8
000074703edd0058  mulpd xmm13, xmm14
000074703edd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000074703edd0063  ptest xmm6, xmm6
000074703edd0068  jnz 0x000074703EDD3E52
000074703edd006e  vmovaps xmm14, [rsp+0x60]
000074703edd0074  vpermilpd xmm14, xmm14, 0x00
000074703edd007a  movaps xmm8, xmm7
000074703edd007e  mulpd xmm8, xmm14
000074703edd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000074703edd0089  ptest xmm6, xmm6
000074703edd008e  jnz 0x000074703EDD3F96
000074703edd0094  movaps xmm14, xmm12
000074703edd0098  addpd xmm14, xmm9
000074703edd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000074703edd00a3  ptest xmm7, xmm7
000074703edd00a8  jnz 0x000074703EDD40D9
000074703edd00ae  vmovaps xmm12, [rsp+0x60]
000074703edd00b4  vpermilpd xmm12, xmm12, 0x00
000074703edd00ba  vmovaps xmm7, [rsp+0xF0]
000074703edd00c3  movaps xmm9, xmm7
000074703edd00c7  mulpd xmm9, xmm12
000074703edd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000074703edd00d2  ptest xmm6, xmm6
000074703edd00d7  jnz 0x000074703EDD421D
000074703edd00dd  movaps xmm12, xmm15
000074703edd00e1  addpd xmm12, xmm11
000074703edd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000074703edd00ec  ptest xmm7, xmm7
000074703edd00f1  jnz 0x000074703EDD4360
000074703edd00f7  vmovaps xmm15, [rsp+0x60]
000074703edd00fd  vpermilpd xmm15, xmm15, 0x00
000074703edd0103  vmovaps xmm7, [rsp+0x40]
000074703edd0109  movaps xmm11, xmm7
000074703edd010d  mulpd xmm11, xmm15
000074703edd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000074703edd0118  ptest xmm6, xmm6
000074703edd011d  jnz 0x000074703EDD44A4
000074703edd0123  movaps xmm15, xmm10
000074703edd0127  addpd xmm15, xmm13
000074703edd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000074703edd0132  ptest xmm7, xmm7
000074703edd0137  jnz 0x000074703EDD45E7
000074703edd013d  vmovaps xmm13, [rsp+0x60]
000074703edd0143  vpermilpd xmm13, xmm13, 0x00
000074703edd0149  vmovaps xmm7, [rsp+0x50]
000074703edd014f  movaps xmm10, xmm7
000074703edd0153  mulpd xmm10, xmm13
000074703edd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000074703edd015e  ptest xmm6, xmm6
000074703edd0163  jnz 0x000074703EDD472B
000074703edd0169  movaps xmm13, xmm1
000074703edd016d  addpd xmm13, xmm8
000074703edd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000074703edd0178  ptest xmm7, xmm7
000074703edd017d  jnz 0x000074703EDD486E
000074703edd0183  lea rax, [r14+0x70]
000074703edd0187  movups xmm1, [r13+rax*1]
000074703edd018d  movaps [r15+0x240], xmm1
000074703edd0195  movaps xmm8, xmm14
000074703edd0199  addpd xmm8, xmm9
000074703edd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000074703edd01a4  ptest xmm7, xmm7
000074703edd01a9  jnz 0x000074703EDD49BB
000074703edd01af  movaps [r15+0x170], xmm8
000074703edd01b7  vmovaps xmm14, [rsp+0x70]
000074703edd01bd  vpermilpd xmm14, xmm14, 0x00
000074703edd01c3  movaps xmm9, xmm1
000074703edd01c7  mulpd xmm9, xmm14
000074703edd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000074703edd01d2  ptest xmm7, xmm7
000074703edd01d7  jnz 0x000074703EDD4AFF
000074703edd01dd  vmovaps xmm1, [rsp+0x70]
000074703edd01e3  vpermilpd xmm1, xmm1, 0x00
000074703edd01e9  movaps xmm14, xmm4
000074703edd01ed  mulpd xmm14, xmm1
000074703edd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000074703edd01f8  ptest xmm7, xmm7
000074703edd01fd  jnz 0x000074703EDD4C42
000074703edd0203  movaps [r15+0x180], xmm14
000074703edd020b  movaps xmm1, xmm12
000074703edd020f  addpd xmm1, xmm11
000074703edd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000074703edd0219  ptest xmm7, xmm7
000074703edd021e  jnz 0x000074703EDD4D84
000074703edd0224  movaps [r15+0x210], xmm1
000074703edd022c  movups xmm12, [r13+r14*1]
000074703edd0232  lea rax, [r14+0x10]
000074703edd0236  movups xmm11, [r13+rax*1]
000074703edd023c  movaps [r15+0x230], xmm11
000074703edd0244  movaps xmm7, xmm15
000074703edd0248  addpd xmm7, xmm10
000074703edd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000074703edd0252  ptest xmm6, xmm6
000074703edd0257  jnz 0x000074703EDD4EDA
000074703edd025d  movaps [r15+0x130], xmm7
000074703edd0265  vmovaps xmm15, [rsp+0x70]
000074703edd026b  vpermilpd xmm15, xmm15, 0x00
000074703edd0271  movaps xmm10, xmm11
000074703edd0275  mulpd xmm10, xmm15
000074703edd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000074703edd0280  ptest xmm6, xmm6
000074703edd0285  jnz 0x000074703EDD501C
000074703edd028b  movaps [r15+0x220], xmm10
000074703edd0293  vmovaps xmm15, [rsp+0x70]
000074703edd0299  vpermilpd xmm15, xmm15, 0x00
000074703edd029f  movaps xmm11, xmm12
000074703edd02a3  mulpd xmm11, xmm15
000074703edd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000074703edd02ae  ptest xmm6, xmm6
000074703edd02b3  jnz 0x000074703EDD5160
000074703edd02b9  movaps xmm15, xmm13
000074703edd02bd  addpd xmm15, xmm9
000074703edd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000074703edd02c8  ptest xmm12, xmm12
000074703edd02ce  jnz 0x000074703EDD52A4
000074703edd02d4  movaps [r15+0x140], xmm15
000074703edd02dc  movaps xmm13, xmm8
000074703edd02e0  addpd xmm13, xmm14
000074703edd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000074703edd02eb  ptest xmm12, xmm12
000074703edd02f1  jnz 0x000074703EDD53E8
000074703edd02f7  movaps [r15+0x150], xmm13
000074703edd02ff  movaps xmm14, xmm1
000074703edd0303  addpd xmm14, xmm10
000074703edd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000074703edd030e  ptest xmm12, xmm12
000074703edd0314  jnz 0x000074703EDD552C
000074703edd031a  movaps [r15+0x160], xmm14
000074703edd0322  movaps xmm1, xmm7
000074703edd0325  addpd xmm1, xmm11
000074703edd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000074703edd032f  ptest xmm12, xmm12
000074703edd0335  jnz 0x000074703EDD566F
000074703edd033b  movaps [r15+0x120], xmm1
000074703edd0343  mov eax, 0x430920
000074703edd0348  movups [r13+rax*1], xmm15
000074703edd034e  mov eax, 0x430930
000074703edd0353  movups [r13+rax*1], xmm13
000074703edd0359  mov eax, 0x430940
000074703edd035e  movups [r13+rax*1], xmm14
000074703edd0364  mov eax, 0x430950
000074703edd0369  movups [r13+rax*1], xmm1
000074703edd036f  mov eax, [r15+0x108]
000074703edd0376  sahf
000074703edd0377  jnz 0x000074703EDD03A9
000074703edd0379  cmp dword ptr [r15+0x318], 0x00
000074703edd0381  jz 0x000074703EDDB900
000074703edd0387  nop [rax+rax*1], ax
000074703edd0390  nop [rax+rax*1], eax
000074703edd0398  mov eax, 0x410444
000074703edd039d  mov [r15+0x100], rax
000074703edd03a4  jmp 0x000074703EBFE110
000074703edd03a9  cmp dword ptr [r15+0x318], 0x00
000074703edd03b1  jz 0x000074703EDD57E0
000074703edd03b7  nop [rax+rax*1], ax
000074703edd03c0  nop [rax+rax*1], eax
000074703edd03c8  mov eax, 0x410278
000074703edd03cd  mov [r15+0x100], rax
000074703edd03d4  jmp 0x000074703EBFE110
000074703edd03d9  int3
000074703edd03da  call 0x000074703ECB52F0
000074703edd03df  jmp 0x000074703EDCF016
000074703edd03e4  call 0x000074703ECC4620
000074703edd03e9  jmp 0x000074703EDCF023
000074703edd03ee  call 0x000074703ECC33A0
000074703edd03f3  jmp 0x000074703EDCF035
000074703edd03f8  call 0x000074703ECC2120
000074703edd03fd  jmp 0x000074703EDCF03F
000074703edd0402  call 0x000074703ECC0860
000074703edd0407  jmp 0x000074703EDCF067
000074703edd040c  call 0x000074703ECBF5F0
000074703edd0411  jmp 0x000074703EDCF073
000074703edd0416  call 0x000074703ECC0860
000074703edd041b  jmp 0x000074703EDCF0A5
000074703edd0420  call 0x000074703ECBF5F0
000074703edd0425  jmp 0x000074703EDCF0B1
000074703edd042a  call 0x000074703ECC4740
000074703edd042f  jmp 0x000074703EDCF0BE
000074703edd0434  call 0x000074703ECB5400
000074703edd0439  jmp 0x000074703EDCF0CB
000074703edd043e  call 0x000074703ECB52F0
000074703edd0443  jmp 0x000074703EDCF0D8
000074703edd0448  call 0x000074703ECC4620
000074703edd044d  jmp 0x000074703EDCF0E5
000074703edd0452  call 0x000074703ECC0860
000074703edd0457  jmp 0x000074703EDCF10D
000074703edd045c  call 0x000074703ECBF5F0
000074703edd0461  jmp 0x000074703EDCF119
000074703edd0466  call 0x000074703EC09D70
000074703edd046b  jmp 0x000074703EDCF11F
000074703edd0470  call 0x000074703ECBE9C0
000074703edd0475  jmp 0x000074703EDCF129
000074703edd047a  call 0x000074703ECC0860
000074703edd047f  jmp 0x000074703EDCF151
000074703edd0484  call 0x000074703ECBF5F0
000074703edd0489  jmp 0x000074703EDCF15D
000074703edd048e  call 0x000074703ECBD750
000074703edd0493  jmp 0x000074703EDCF16A
000074703edd0498  call 0x000074703ECBC4E0
000074703edd049d  jmp 0x000074703EDCF177
000074703edd04a2  call 0x000074703ECC4740
000074703edd04a7  jmp 0x000074703EDCF184
000074703edd04ac  call 0x000074703ECB5400
000074703edd04b1  jmp 0x000074703EDCF191
000074703edd04b6  call 0x000074703ECB52F0
000074703edd04bb  jmp 0x000074703EDCF19E
000074703edd04c0  call 0x000074703ECC4620
000074703edd04c5  jmp 0x000074703EDCF1AB
000074703edd04ca  call 0x000074703ECC0860
000074703edd04cf  jmp 0x000074703EDCF1BE
000074703edd04d4  call 0x000074703ECBB270
000074703edd04d9  jmp 0x000074703EDCF1CB
000074703edd04de  call 0x000074703ECBA000
000074703edd04e3  jmp 0x000074703EDCF1D8
000074703edd04e8  call 0x000074703ECB8D90
000074703edd04ed  jmp 0x000074703EDCF1E5
000074703edd04f2  call 0x000074703ECB8A20
000074703edd04f7  jmp 0x000074703EDCF1F2
000074703edd04fc  call 0x000074703ECB5400
000074703edd0501  jmp 0x000074703EDCF1FC
000074703edd0506  call 0x000074703ECC2240
000074703edd050b  jmp 0x000074703EDCF206
000074703edd0510  call 0x000074703ECB52F0
000074703edd0515  jmp 0x000074703EDCF210
000074703edd051a  call 0x000074703ECC2120
000074703edd051f  jmp 0x000074703EDCF21A
000074703edd0524  call 0x000074703ECB77B0
000074703edd0529  jmp 0x000074703EDCF224
000074703edd052e  call 0x000074703ECB6550
000074703edd0533  jmp 0x000074703EDCF22E
000074703edd0538  call 0x000074703ECBFD50
000074703edd053d  jmp 0x000074703EDCF240
000074703edd0542  call 0x000074703ECB8EA0
000074703edd0547  jmp 0x000074703EDCF24A
000074703edd054c  call 0x000074703ECBFC30
000074703edd0551  jmp 0x000074703EDCF257
000074703edd0556  call 0x000074703ECB8D90
000074703edd055b  jmp 0x000074703EDCF264
000074703edd0560  call 0x000074703ECC2240
000074703edd0565  jmp 0x000074703EDCF271
000074703edd056a  call 0x000074703ECB5400
000074703edd056f  jmp 0x000074703EDCF27E
000074703edd0574  call 0x000074703ECB52F0
000074703edd0579  jmp 0x000074703EDCF28B
000074703edd057e  call 0x000074703ECC2120
000074703edd0583  jmp 0x000074703EDCF298
000074703edd0588  call 0x000074703ECB52F0
000074703edd058d  jmp 0x000074703EDCF2AB
000074703edd0592  call 0x000074703ECB52F0
000074703edd0597  jmp 0x000074703EDCF2BE
000074703edd059c  call 0x000074703ECB52F0
000074703edd05a1  jmp 0x000074703EDCF2D1
000074703edd05a6  call 0x000074703ECB52F0
000074703edd05ab  jmp 0x000074703EDCF2E4
000074703edd05b0  call 0x000074703ECC2240
000074703edd05b5  jmp 0x000074703EDCF2F9
000074703edd05ba  call 0x000074703ECC2240
000074703edd05bf  jmp 0x000074703EDCF30C
000074703edd05c4  call 0x000074703ECC2120
000074703edd05c9  jmp 0x000074703EDCF319
000074703edd05ce  call 0x000074703ECB52F0
000074703edd05d3  jmp 0x000074703EDCF32C
000074703edd05d8  call 0x000074703ECB52F0
000074703edd05dd  jmp 0x000074703EDCF34F
000074703edd05e2  call 0x000074703ECB52F0
000074703edd05e7  jmp 0x000074703EDCF362
000074703edd05ec  call 0x000074703EBFF540
000074703edd05f1  jmp 0x000074703EDCF380
000074703edd05f6  call 0x000074703EC08C20
000074703edd05fb  jmp 0x000074703EDCF38A
000074703edd0600  call 0x000074703ECD6600
000074703edd0605  jmp 0x000074703EDCF396
000074703edd060a  call 0x000074703EBFF540
000074703edd060f  jmp 0x000074703EDCF3A6
000074703edd0614  call 0x000074703ECC0370
000074703edd0619  jmp 0x000074703EDCF3D4
000074703edd061e  call 0x000074703ECBF100
000074703edd0623  jmp 0x000074703EDCF3DD
000074703edd0628  call 0x000074703ECC0370
000074703edd062d  jmp 0x000074703EDCF43B
000074703edd0632  call 0x000074703ECBF100
000074703edd0637  jmp 0x000074703EDCF444
000074703edd063c  call 0x000074703ECC0370
000074703edd0641  jmp 0x000074703EDCF48B
000074703edd0646  call 0x000074703ECBF100
000074703edd064b  jmp 0x000074703EDCF494
000074703edd0650  call 0x000074703EC0B720
000074703edd0655  jmp 0x000074703EDCF4D7
000074703edd065a  call 0x000074703ECB47C0
000074703edd065f  jmp 0x000074703EDCF4EA
000074703edd0664  call 0x000074703EC08B00
000074703edd0669  jmp 0x000074703EDCF501
000074703edd066e  call 0x000074703EBFF430
000074703edd0673  jmp 0x000074703EDCF514
000074703edd0678  call 0x000074703EBFF430
000074703edd067d  jmp 0x000074703EDCF527
000074703edd0682  sub rsp, 0x08
000074703edd0686  push rax
000074703edd0687  push rcx
000074703edd0688  push rdx
000074703edd0689  push rdi
000074703edd068a  push rsi
000074703edd068b  push r8
000074703edd068d  push r9
000074703edd068f  push r10
000074703edd0691  push r11
000074703edd0693  sub rsp, 0xF0
000074703edd069a  vmovaps [rsp], xmm0
000074703edd069f  vmovaps [rsp+0x10], xmm2
000074703edd06a5  vmovaps [rsp+0x20], xmm3
000074703edd06ab  vmovaps [rsp+0x30], xmm4
000074703edd06b1  vmovaps [rsp+0x40], xmm5
000074703edd06b7  vmovaps [rsp+0x50], xmm6
000074703edd06bd  vmovaps [rsp+0x60], xmm7
000074703edd06c3  vmovaps [rsp+0x70], xmm8
000074703edd06c9  vmovaps [rsp+0x80], xmm9
000074703edd06d2  vmovaps [rsp+0x90], xmm10
000074703edd06db  vmovaps [rsp+0xA0], xmm11
000074703edd06e4  vmovaps [rsp+0xB0], xmm12
000074703edd06ed  vmovaps [rsp+0xC0], xmm13
000074703edd06f6  vmovaps [rsp+0xD0], xmm14
000074703edd06ff  vmovaps [rsp+0xE0], xmm15
000074703edd0708  sub rsp, 0x30
000074703edd070c  movaps [rsp], xmm1
000074703edd0710  movaps [rsp+0x10], xmm15
000074703edd0716  movaps [rsp+0x20], xmm14
000074703edd071c  lea rdi, [rsp]
000074703edd0720  mov esi, 0x00
000074703edd0725  mov rax, 0x5D9974CCC530
000074703edd072f  call rax
000074703edd0731  movaps xmm1, [rsp]
000074703edd0735  add rsp, 0x30
000074703edd0739  vmovaps xmm0, [rsp]
000074703edd073e  vmovaps xmm2, [rsp+0x10]
000074703edd0744  vmovaps xmm3, [rsp+0x20]
000074703edd074a  vmovaps xmm4, [rsp+0x30]
000074703edd0750  vmovaps xmm5, [rsp+0x40]
000074703edd0756  vmovaps xmm6, [rsp+0x50]
000074703edd075c  vmovaps xmm7, [rsp+0x60]
000074703edd0762  vmovaps xmm8, [rsp+0x70]
000074703edd0768  vmovaps xmm9, [rsp+0x80]
000074703edd0771  vmovaps xmm10, [rsp+0x90]
000074703edd077a  vmovaps xmm11, [rsp+0xA0]
000074703edd0783  vmovaps xmm12, [rsp+0xB0]
000074703edd078c  vmovaps xmm13, [rsp+0xC0]
000074703edd0795  vmovaps xmm14, [rsp+0xD0]
000074703edd079e  vmovaps xmm15, [rsp+0xE0]
000074703edd07a7  add rsp, 0xF0
000074703edd07ae  pop r11
000074703edd07b0  pop r10
000074703edd07b2  pop r9
000074703edd07b4  pop r8
000074703edd07b6  pop rsi
000074703edd07b7  pop rdi
000074703edd07b8  pop rdx
000074703edd07b9  pop rcx
000074703edd07ba  pop rax
000074703edd07bb  add rsp, 0x08
000074703edd07bf  jmp 0x000074703EDCF581
000074703edd07c4  sub rsp, 0x08
000074703edd07c8  push rax
000074703edd07c9  push rcx
000074703edd07ca  push rdx
000074703edd07cb  push rdi
000074703edd07cc  push rsi
000074703edd07cd  push r8
000074703edd07cf  push r9
000074703edd07d1  push r10
000074703edd07d3  push r11
000074703edd07d5  sub rsp, 0xF0
000074703edd07dc  vmovaps [rsp], xmm0
000074703edd07e1  vmovaps [rsp+0x10], xmm1
000074703edd07e7  vmovaps [rsp+0x20], xmm2
000074703edd07ed  vmovaps [rsp+0x30], xmm3
000074703edd07f3  vmovaps [rsp+0x40], xmm4
000074703edd07f9  vmovaps [rsp+0x50], xmm5
000074703edd07ff  vmovaps [rsp+0x60], xmm6
000074703edd0805  vmovaps [rsp+0x70], xmm7
000074703edd080b  vmovaps [rsp+0x80], xmm8
000074703edd0814  vmovaps [rsp+0x90], xmm9
000074703edd081d  vmovaps [rsp+0xA0], xmm10
000074703edd0826  vmovaps [rsp+0xB0], xmm11
000074703edd082f  vmovaps [rsp+0xC0], xmm12
000074703edd0838  vmovaps [rsp+0xD0], xmm14
000074703edd0841  vmovaps [rsp+0xE0], xmm15
000074703edd084a  sub rsp, 0x30
000074703edd084e  movaps [rsp], xmm13
000074703edd0853  movaps [rsp+0x10], xmm1
000074703edd0858  movaps [rsp+0x20], xmm14
000074703edd085e  lea rdi, [rsp]
000074703edd0862  mov esi, 0x00
000074703edd0867  mov rax, 0x5D9974CCC530
000074703edd0871  call rax
000074703edd0873  movaps xmm13, [rsp]
000074703edd0878  add rsp, 0x30
000074703edd087c  vmovaps xmm0, [rsp]
000074703edd0881  vmovaps xmm1, [rsp+0x10]
000074703edd0887  vmovaps xmm2, [rsp+0x20]
000074703edd088d  vmovaps xmm3, [rsp+0x30]
000074703edd0893  vmovaps xmm4, [rsp+0x40]
000074703edd0899  vmovaps xmm5, [rsp+0x50]
000074703edd089f  vmovaps xmm6, [rsp+0x60]
000074703edd08a5  vmovaps xmm7, [rsp+0x70]
000074703edd08ab  vmovaps xmm8, [rsp+0x80]
000074703edd08b4  vmovaps xmm9, [rsp+0x90]
000074703edd08bd  vmovaps xmm10, [rsp+0xA0]
000074703edd08c6  vmovaps xmm11, [rsp+0xB0]
000074703edd08cf  vmovaps xmm12, [rsp+0xC0]
000074703edd08d8  vmovaps xmm14, [rsp+0xD0]
000074703edd08e1  vmovaps xmm15, [rsp+0xE0]
000074703edd08ea  add rsp, 0xF0
000074703edd08f1  pop r11
000074703edd08f3  pop r10
000074703edd08f5  pop r9
000074703edd08f7  pop r8
000074703edd08f9  pop rsi
000074703edd08fa  pop rdi
000074703edd08fb  pop rdx
000074703edd08fc  pop rcx
000074703edd08fd  pop rax
000074703edd08fe  add rsp, 0x08
000074703edd0902  jmp 0x000074703EDCF5CF
000074703edd0907  sub rsp, 0x08
000074703edd090b  push rax
000074703edd090c  push rcx
000074703edd090d  push rdx
000074703edd090e  push rdi
000074703edd090f  push rsi
000074703edd0910  push r8
000074703edd0912  push r9
000074703edd0914  push r10
000074703edd0916  push r11
000074703edd0918  sub rsp, 0xF0
000074703edd091f  vmovaps [rsp], xmm0
000074703edd0924  vmovaps [rsp+0x10], xmm1
000074703edd092a  vmovaps [rsp+0x20], xmm2
000074703edd0930  vmovaps [rsp+0x30], xmm3
000074703edd0936  vmovaps [rsp+0x40], xmm4
000074703edd093c  vmovaps [rsp+0x50], xmm5
000074703edd0942  vmovaps [rsp+0x60], xmm6
000074703edd0948  vmovaps [rsp+0x70], xmm7
000074703edd094e  vmovaps [rsp+0x80], xmm8
000074703edd0957  vmovaps [rsp+0x90], xmm9
000074703edd0960  vmovaps [rsp+0xA0], xmm10
000074703edd0969  vmovaps [rsp+0xB0], xmm11
000074703edd0972  vmovaps [rsp+0xC0], xmm12
000074703edd097b  vmovaps [rsp+0xD0], xmm13
000074703edd0984  vmovaps [rsp+0xE0], xmm14
000074703edd098d  sub rsp, 0x30
000074703edd0991  movaps [rsp], xmm15
000074703edd0996  movaps [rsp+0x10], xmm14
000074703edd099c  movaps [rsp+0x20], xmm1
000074703edd09a1  lea rdi, [rsp]
000074703edd09a5  mov esi, 0x00
000074703edd09aa  mov rax, 0x5D9974CCC530
000074703edd09b4  call rax
000074703edd09b6  movaps xmm15, [rsp]
000074703edd09bb  add rsp, 0x30
000074703edd09bf  vmovaps xmm0, [rsp]
000074703edd09c4  vmovaps xmm1, [rsp+0x10]
000074703edd09ca  vmovaps xmm2, [rsp+0x20]
000074703edd09d0  vmovaps xmm3, [rsp+0x30]
000074703edd09d6  vmovaps xmm4, [rsp+0x40]
000074703edd09dc  vmovaps xmm5, [rsp+0x50]
000074703edd09e2  vmovaps xmm6, [rsp+0x60]
000074703edd09e8  vmovaps xmm7, [rsp+0x70]
000074703edd09ee  vmovaps xmm8, [rsp+0x80]
000074703edd09f7  vmovaps xmm9, [rsp+0x90]
000074703edd0a00  vmovaps xmm10, [rsp+0xA0]
000074703edd0a09  vmovaps xmm11, [rsp+0xB0]
000074703edd0a12  vmovaps xmm12, [rsp+0xC0]
000074703edd0a1b  vmovaps xmm13, [rsp+0xD0]
000074703edd0a24  vmovaps xmm14, [rsp+0xE0]
000074703edd0a2d  add rsp, 0xF0
000074703edd0a34  pop r11
000074703edd0a36  pop r10
000074703edd0a38  pop r9
000074703edd0a3a  pop r8
000074703edd0a3c  pop rsi
000074703edd0a3d  pop rdi
000074703edd0a3e  pop rdx
000074703edd0a3f  pop rcx
000074703edd0a40  pop rax
000074703edd0a41  add rsp, 0x08
000074703edd0a45  jmp 0x000074703EDCF617
000074703edd0a4a  sub rsp, 0x08
000074703edd0a4e  push rax
000074703edd0a4f  push rcx
000074703edd0a50  push rdx
000074703edd0a51  push rdi
000074703edd0a52  push rsi
000074703edd0a53  push r8
000074703edd0a55  push r9
000074703edd0a57  push r10
000074703edd0a59  push r11
000074703edd0a5b  sub rsp, 0xF0
000074703edd0a62  vmovaps [rsp], xmm0
000074703edd0a67  vmovaps [rsp+0x10], xmm2
000074703edd0a6d  vmovaps [rsp+0x20], xmm3
000074703edd0a73  vmovaps [rsp+0x30], xmm4
000074703edd0a79  vmovaps [rsp+0x40], xmm5
000074703edd0a7f  vmovaps [rsp+0x50], xmm6
000074703edd0a85  vmovaps [rsp+0x60], xmm7
000074703edd0a8b  vmovaps [rsp+0x70], xmm8
000074703edd0a91  vmovaps [rsp+0x80], xmm9
000074703edd0a9a  vmovaps [rsp+0x90], xmm10
000074703edd0aa3  vmovaps [rsp+0xA0], xmm11
000074703edd0aac  vmovaps [rsp+0xB0], xmm12
000074703edd0ab5  vmovaps [rsp+0xC0], xmm13
000074703edd0abe  vmovaps [rsp+0xD0], xmm14
000074703edd0ac7  vmovaps [rsp+0xE0], xmm15
000074703edd0ad0  sub rsp, 0x30
000074703edd0ad4  movaps [rsp], xmm1
000074703edd0ad8  movaps [rsp+0x10], xmm14
000074703edd0ade  movaps [rsp+0x20], xmm10
000074703edd0ae4  lea rdi, [rsp]
000074703edd0ae8  mov esi, 0x00
000074703edd0aed  mov rax, 0x5D9974CCC530
000074703edd0af7  call rax
000074703edd0af9  movaps xmm1, [rsp]
000074703edd0afd  add rsp, 0x30
000074703edd0b01  vmovaps xmm0, [rsp]
000074703edd0b06  vmovaps xmm2, [rsp+0x10]
000074703edd0b0c  vmovaps xmm3, [rsp+0x20]
000074703edd0b12  vmovaps xmm4, [rsp+0x30]
000074703edd0b18  vmovaps xmm5, [rsp+0x40]
000074703edd0b1e  vmovaps xmm6, [rsp+0x50]
000074703edd0b24  vmovaps xmm7, [rsp+0x60]
000074703edd0b2a  vmovaps xmm8, [rsp+0x70]
000074703edd0b30  vmovaps xmm9, [rsp+0x80]
000074703edd0b39  vmovaps xmm10, [rsp+0x90]
000074703edd0b42  vmovaps xmm11, [rsp+0xA0]
000074703edd0b4b  vmovaps xmm12, [rsp+0xB0]
000074703edd0b54  vmovaps xmm13, [rsp+0xC0]
000074703edd0b5d  vmovaps xmm14, [rsp+0xD0]
000074703edd0b66  vmovaps xmm15, [rsp+0xE0]
000074703edd0b6f  add rsp, 0xF0
000074703edd0b76  pop r11
000074703edd0b78  pop r10
000074703edd0b7a  pop r9
000074703edd0b7c  pop r8
000074703edd0b7e  pop rsi
000074703edd0b7f  pop rdi
000074703edd0b80  pop rdx
000074703edd0b81  pop rcx
000074703edd0b82  pop rax
000074703edd0b83  add rsp, 0x08
000074703edd0b87  jmp 0x000074703EDCF631
000074703edd0b8c  sub rsp, 0x08
000074703edd0b90  push rax
000074703edd0b91  push rcx
000074703edd0b92  push rdx
000074703edd0b93  push rdi
000074703edd0b94  push rsi
000074703edd0b95  push r8
000074703edd0b97  push r9
000074703edd0b99  push r10
000074703edd0b9b  push r11
000074703edd0b9d  sub rsp, 0xF0
000074703edd0ba4  vmovaps [rsp], xmm0
000074703edd0ba9  vmovaps [rsp+0x10], xmm1
000074703edd0baf  vmovaps [rsp+0x20], xmm2
000074703edd0bb5  vmovaps [rsp+0x30], xmm3
000074703edd0bbb  vmovaps [rsp+0x40], xmm4
000074703edd0bc1  vmovaps [rsp+0x50], xmm5
000074703edd0bc7  vmovaps [rsp+0x60], xmm6
000074703edd0bcd  vmovaps [rsp+0x70], xmm7
000074703edd0bd3  vmovaps [rsp+0x80], xmm8
000074703edd0bdc  vmovaps [rsp+0x90], xmm9
000074703edd0be5  vmovaps [rsp+0xA0], xmm10
000074703edd0bee  vmovaps [rsp+0xB0], xmm11
000074703edd0bf7  vmovaps [rsp+0xC0], xmm12
000074703edd0c00  vmovaps [rsp+0xD0], xmm14
000074703edd0c09  vmovaps [rsp+0xE0], xmm15
000074703edd0c12  sub rsp, 0x30
000074703edd0c16  movaps [rsp], xmm13
000074703edd0c1b  movaps [rsp+0x10], xmm14
000074703edd0c21  movaps [rsp+0x20], xmm2
000074703edd0c26  lea rdi, [rsp]
000074703edd0c2a  mov esi, 0x00
000074703edd0c2f  mov rax, 0x5D9974CCC530
000074703edd0c39  call rax
000074703edd0c3b  movaps xmm13, [rsp]
000074703edd0c40  add rsp, 0x30
000074703edd0c44  vmovaps xmm0, [rsp]
000074703edd0c49  vmovaps xmm1, [rsp+0x10]
000074703edd0c4f  vmovaps xmm2, [rsp+0x20]
000074703edd0c55  vmovaps xmm3, [rsp+0x30]
000074703edd0c5b  vmovaps xmm4, [rsp+0x40]
000074703edd0c61  vmovaps xmm5, [rsp+0x50]
000074703edd0c67  vmovaps xmm6, [rsp+0x60]
000074703edd0c6d  vmovaps xmm7, [rsp+0x70]
000074703edd0c73  vmovaps xmm8, [rsp+0x80]
000074703edd0c7c  vmovaps xmm9, [rsp+0x90]
000074703edd0c85  vmovaps xmm10, [rsp+0xA0]
000074703edd0c8e  vmovaps xmm11, [rsp+0xB0]
000074703edd0c97  vmovaps xmm12, [rsp+0xC0]
000074703edd0ca0  vmovaps xmm14, [rsp+0xD0]
000074703edd0ca9  vmovaps xmm15, [rsp+0xE0]
000074703edd0cb2  add rsp, 0xF0
000074703edd0cb9  pop r11
000074703edd0cbb  pop r10
000074703edd0cbd  pop r9
000074703edd0cbf  pop r8
000074703edd0cc1  pop rsi
000074703edd0cc2  pop rdi
000074703edd0cc3  pop rdx
000074703edd0cc4  pop rcx
000074703edd0cc5  pop rax
000074703edd0cc6  add rsp, 0x08
000074703edd0cca  jmp 0x000074703EDCF64C
000074703edd0ccf  sub rsp, 0x08
000074703edd0cd3  push rax
000074703edd0cd4  push rcx
000074703edd0cd5  push rdx
000074703edd0cd6  push rdi
000074703edd0cd7  push rsi
000074703edd0cd8  push r8
000074703edd0cda  push r9
000074703edd0cdc  push r10
000074703edd0cde  push r11
000074703edd0ce0  sub rsp, 0xF0
000074703edd0ce7  vmovaps [rsp], xmm0
000074703edd0cec  vmovaps [rsp+0x10], xmm2
000074703edd0cf2  vmovaps [rsp+0x20], xmm3
000074703edd0cf8  vmovaps [rsp+0x30], xmm4
000074703edd0cfe  vmovaps [rsp+0x40], xmm5
000074703edd0d04  vmovaps [rsp+0x50], xmm6
000074703edd0d0a  vmovaps [rsp+0x60], xmm7
000074703edd0d10  vmovaps [rsp+0x70], xmm8
000074703edd0d16  vmovaps [rsp+0x80], xmm9
000074703edd0d1f  vmovaps [rsp+0x90], xmm10
000074703edd0d28  vmovaps [rsp+0xA0], xmm11
000074703edd0d31  vmovaps [rsp+0xB0], xmm12
000074703edd0d3a  vmovaps [rsp+0xC0], xmm13
000074703edd0d43  vmovaps [rsp+0xD0], xmm14
000074703edd0d4c  vmovaps [rsp+0xE0], xmm15
000074703edd0d55  sub rsp, 0x30
000074703edd0d59  movaps [rsp], xmm1
000074703edd0d5d  movaps [rsp+0x10], xmm10
000074703edd0d63  movaps [rsp+0x20], xmm2
000074703edd0d68  lea rdi, [rsp]
000074703edd0d6c  mov esi, 0x00
000074703edd0d71  mov rax, 0x5D9974CCC530
000074703edd0d7b  call rax
000074703edd0d7d  movaps xmm1, [rsp]
000074703edd0d81  add rsp, 0x30
000074703edd0d85  vmovaps xmm0, [rsp]
000074703edd0d8a  vmovaps xmm2, [rsp+0x10]
000074703edd0d90  vmovaps xmm3, [rsp+0x20]
000074703edd0d96  vmovaps xmm4, [rsp+0x30]
000074703edd0d9c  vmovaps xmm5, [rsp+0x40]
000074703edd0da2  vmovaps xmm6, [rsp+0x50]
000074703edd0da8  vmovaps xmm7, [rsp+0x60]
000074703edd0dae  vmovaps xmm8, [rsp+0x70]
000074703edd0db4  vmovaps xmm9, [rsp+0x80]
000074703edd0dbd  vmovaps xmm10, [rsp+0x90]
000074703edd0dc6  vmovaps xmm11, [rsp+0xA0]
000074703edd0dcf  vmovaps xmm12, [rsp+0xB0]
000074703edd0dd8  vmovaps xmm13, [rsp+0xC0]
000074703edd0de1  vmovaps xmm14, [rsp+0xD0]
000074703edd0dea  vmovaps xmm15, [rsp+0xE0]
000074703edd0df3  add rsp, 0xF0
000074703edd0dfa  pop r11
000074703edd0dfc  pop r10
000074703edd0dfe  pop r9
000074703edd0e00  pop r8
000074703edd0e02  pop rsi
000074703edd0e03  pop rdi
000074703edd0e04  pop rdx
000074703edd0e05  pop rcx
000074703edd0e06  pop rax
000074703edd0e07  add rsp, 0x08
000074703edd0e0b  jmp 0x000074703EDCF6B4
000074703edd0e10  sub rsp, 0x08
000074703edd0e14  push rax
000074703edd0e15  push rcx
000074703edd0e16  push rdx
000074703edd0e17  push rdi
000074703edd0e18  push rsi
000074703edd0e19  push r8
000074703edd0e1b  push r9
000074703edd0e1d  push r10
000074703edd0e1f  push r11
000074703edd0e21  sub rsp, 0xF0
000074703edd0e28  vmovaps [rsp], xmm0
000074703edd0e2d  vmovaps [rsp+0x10], xmm1
000074703edd0e33  vmovaps [rsp+0x20], xmm2
000074703edd0e39  vmovaps [rsp+0x30], xmm3
000074703edd0e3f  vmovaps [rsp+0x40], xmm4
000074703edd0e45  vmovaps [rsp+0x50], xmm5
000074703edd0e4b  vmovaps [rsp+0x60], xmm6
000074703edd0e51  vmovaps [rsp+0x70], xmm7
000074703edd0e57  vmovaps [rsp+0x80], xmm8
000074703edd0e60  vmovaps [rsp+0x90], xmm9
000074703edd0e69  vmovaps [rsp+0xA0], xmm10
000074703edd0e72  vmovaps [rsp+0xB0], xmm11
000074703edd0e7b  vmovaps [rsp+0xC0], xmm12
000074703edd0e84  vmovaps [rsp+0xD0], xmm13
000074703edd0e8d  vmovaps [rsp+0xE0], xmm14
000074703edd0e96  sub rsp, 0x30
000074703edd0e9a  movaps [rsp], xmm15
000074703edd0e9f  movaps [rsp+0x10], xmm10
000074703edd0ea5  movaps [rsp+0x20], xmm2
000074703edd0eaa  lea rdi, [rsp]
000074703edd0eae  mov esi, 0x00
000074703edd0eb3  mov rax, 0x5D9974CCC530
000074703edd0ebd  call rax
000074703edd0ebf  movaps xmm15, [rsp]
000074703edd0ec4  add rsp, 0x30
000074703edd0ec8  vmovaps xmm0, [rsp]
000074703edd0ecd  vmovaps xmm1, [rsp+0x10]
000074703edd0ed3  vmovaps xmm2, [rsp+0x20]
000074703edd0ed9  vmovaps xmm3, [rsp+0x30]
000074703edd0edf  vmovaps xmm4, [rsp+0x40]
000074703edd0ee5  vmovaps xmm5, [rsp+0x50]
000074703edd0eeb  vmovaps xmm6, [rsp+0x60]
000074703edd0ef1  vmovaps xmm7, [rsp+0x70]
000074703edd0ef7  vmovaps xmm8, [rsp+0x80]
000074703edd0f00  vmovaps xmm9, [rsp+0x90]
000074703edd0f09  vmovaps xmm10, [rsp+0xA0]
000074703edd0f12  vmovaps xmm11, [rsp+0xB0]
000074703edd0f1b  vmovaps xmm12, [rsp+0xC0]
000074703edd0f24  vmovaps xmm13, [rsp+0xD0]
000074703edd0f2d  vmovaps xmm14, [rsp+0xE0]
000074703edd0f36  add rsp, 0xF0
000074703edd0f3d  pop r11
000074703edd0f3f  pop r10
000074703edd0f41  pop r9
000074703edd0f43  pop r8
000074703edd0f45  pop rsi
000074703edd0f46  pop rdi
000074703edd0f47  pop rdx
000074703edd0f48  pop rcx
000074703edd0f49  pop rax
000074703edd0f4a  add rsp, 0x08
000074703edd0f4e  jmp 0x000074703EDCF706
000074703edd0f53  sub rsp, 0x08
000074703edd0f57  push rax
000074703edd0f58  push rcx
000074703edd0f59  push rdx
000074703edd0f5a  push rdi
000074703edd0f5b  push rsi
000074703edd0f5c  push r8
000074703edd0f5e  push r9
000074703edd0f60  push r10
000074703edd0f62  push r11
000074703edd0f64  sub rsp, 0xF0
000074703edd0f6b  vmovaps [rsp], xmm0
000074703edd0f70  vmovaps [rsp+0x10], xmm2
000074703edd0f76  vmovaps [rsp+0x20], xmm3
000074703edd0f7c  vmovaps [rsp+0x30], xmm4
000074703edd0f82  vmovaps [rsp+0x40], xmm5
000074703edd0f88  vmovaps [rsp+0x50], xmm6
000074703edd0f8e  vmovaps [rsp+0x60], xmm7
000074703edd0f94  vmovaps [rsp+0x70], xmm8
000074703edd0f9a  vmovaps [rsp+0x80], xmm9
000074703edd0fa3  vmovaps [rsp+0x90], xmm10
000074703edd0fac  vmovaps [rsp+0xA0], xmm11
000074703edd0fb5  vmovaps [rsp+0xB0], xmm12
000074703edd0fbe  vmovaps [rsp+0xC0], xmm13
000074703edd0fc7  vmovaps [rsp+0xD0], xmm14
000074703edd0fd0  vmovaps [rsp+0xE0], xmm15
000074703edd0fd9  sub rsp, 0x30
000074703edd0fdd  movaps [rsp], xmm1
000074703edd0fe1  movaps [rsp+0x10], xmm10
000074703edd0fe7  movaps [rsp+0x20], xmm12
000074703edd0fed  lea rdi, [rsp]
000074703edd0ff1  mov esi, 0x00
000074703edd0ff6  mov rax, 0x5D9974CCC530
000074703edd1000  call rax
000074703edd1002  movaps xmm1, [rsp]
000074703edd1006  add rsp, 0x30
000074703edd100a  vmovaps xmm0, [rsp]
000074703edd100f  vmovaps xmm2, [rsp+0x10]
000074703edd1015  vmovaps xmm3, [rsp+0x20]
000074703edd101b  vmovaps xmm4, [rsp+0x30]
000074703edd1021  vmovaps xmm5, [rsp+0x40]
000074703edd1027  vmovaps xmm6, [rsp+0x50]
000074703edd102d  vmovaps xmm7, [rsp+0x60]
000074703edd1033  vmovaps xmm8, [rsp+0x70]
000074703edd1039  vmovaps xmm9, [rsp+0x80]
000074703edd1042  vmovaps xmm10, [rsp+0x90]
000074703edd104b  vmovaps xmm11, [rsp+0xA0]
000074703edd1054  vmovaps xmm12, [rsp+0xB0]
000074703edd105d  vmovaps xmm13, [rsp+0xC0]
000074703edd1066  vmovaps xmm14, [rsp+0xD0]
000074703edd106f  vmovaps xmm15, [rsp+0xE0]
000074703edd1078  add rsp, 0xF0
000074703edd107f  pop r11
000074703edd1081  pop r10
000074703edd1083  pop r9
000074703edd1085  pop r8
000074703edd1087  pop rsi
000074703edd1088  pop rdi
000074703edd1089  pop rdx
000074703edd108a  pop rcx
000074703edd108b  pop rax
000074703edd108c  add rsp, 0x08
000074703edd1090  jmp 0x000074703EDCF732
000074703edd1095  sub rsp, 0x08
000074703edd1099  push rax
000074703edd109a  push rcx
000074703edd109b  push rdx
000074703edd109c  push rdi
000074703edd109d  push rsi
000074703edd109e  push r8
000074703edd10a0  push r9
000074703edd10a2  push r10
000074703edd10a4  push r11
000074703edd10a6  sub rsp, 0xF0
000074703edd10ad  vmovaps [rsp], xmm0
000074703edd10b2  vmovaps [rsp+0x10], xmm1
000074703edd10b8  vmovaps [rsp+0x20], xmm2
000074703edd10be  vmovaps [rsp+0x30], xmm3
000074703edd10c4  vmovaps [rsp+0x40], xmm4
000074703edd10ca  vmovaps [rsp+0x50], xmm5
000074703edd10d0  vmovaps [rsp+0x60], xmm6
000074703edd10d6  vmovaps [rsp+0x70], xmm7
000074703edd10dc  vmovaps [rsp+0x80], xmm8
000074703edd10e5  vmovaps [rsp+0x90], xmm9
000074703edd10ee  vmovaps [rsp+0xA0], xmm10
000074703edd10f7  vmovaps [rsp+0xB0], xmm11
000074703edd1100  vmovaps [rsp+0xC0], xmm12
000074703edd1109  vmovaps [rsp+0xD0], xmm13
000074703edd1112  vmovaps [rsp+0xE0], xmm14
000074703edd111b  sub rsp, 0x30
000074703edd111f  movaps [rsp], xmm15
000074703edd1124  movaps [rsp+0x10], xmm10
000074703edd112a  movaps [rsp+0x20], xmm12
000074703edd1130  lea rdi, [rsp]
000074703edd1134  mov esi, 0x00
000074703edd1139  mov rax, 0x5D9974CCC530
000074703edd1143  call rax
000074703edd1145  movaps xmm15, [rsp]
000074703edd114a  add rsp, 0x30
000074703edd114e  vmovaps xmm0, [rsp]
000074703edd1153  vmovaps xmm1, [rsp+0x10]
000074703edd1159  vmovaps xmm2, [rsp+0x20]
000074703edd115f  vmovaps xmm3, [rsp+0x30]
000074703edd1165  vmovaps xmm4, [rsp+0x40]
000074703edd116b  vmovaps xmm5, [rsp+0x50]
000074703edd1171  vmovaps xmm6, [rsp+0x60]
000074703edd1177  vmovaps xmm7, [rsp+0x70]
000074703edd117d  vmovaps xmm8, [rsp+0x80]
000074703edd1186  vmovaps xmm9, [rsp+0x90]
000074703edd118f  vmovaps xmm10, [rsp+0xA0]
000074703edd1198  vmovaps xmm11, [rsp+0xB0]
000074703edd11a1  vmovaps xmm12, [rsp+0xC0]
000074703edd11aa  vmovaps xmm13, [rsp+0xD0]
000074703edd11b3  vmovaps xmm14, [rsp+0xE0]
000074703edd11bc  add rsp, 0xF0
000074703edd11c3  pop r11
000074703edd11c5  pop r10
000074703edd11c7  pop r9
000074703edd11c9  pop r8
000074703edd11cb  pop rsi
000074703edd11cc  pop rdi
000074703edd11cd  pop rdx
000074703edd11ce  pop rcx
000074703edd11cf  pop rax
000074703edd11d0  add rsp, 0x08
000074703edd11d4  jmp 0x000074703EDCF75E
000074703edd11d9  call 0x000074703EBFF430
000074703edd11de  jmp 0x000074703EDCF7EE
000074703edd11e3  call 0x000074703EBFF430
000074703edd11e8  jmp 0x000074703EDCF801
000074703edd11ed  sub rsp, 0x08
000074703edd11f1  push rax
000074703edd11f2  push rcx
000074703edd11f3  push rdx
000074703edd11f4  push rdi
000074703edd11f5  push rsi
000074703edd11f6  push r8
000074703edd11f8  push r9
000074703edd11fa  push r10
000074703edd11fc  push r11
000074703edd11fe  sub rsp, 0xF0
000074703edd1205  vmovaps [rsp], xmm0
000074703edd120a  vmovaps [rsp+0x10], xmm2
000074703edd1210  vmovaps [rsp+0x20], xmm3
000074703edd1216  vmovaps [rsp+0x30], xmm4
000074703edd121c  vmovaps [rsp+0x40], xmm5
000074703edd1222  vmovaps [rsp+0x50], xmm6
000074703edd1228  vmovaps [rsp+0x60], xmm7
000074703edd122e  vmovaps [rsp+0x70], xmm8
000074703edd1234  vmovaps [rsp+0x80], xmm9
000074703edd123d  vmovaps [rsp+0x90], xmm10
000074703edd1246  vmovaps [rsp+0xA0], xmm11
000074703edd124f  vmovaps [rsp+0xB0], xmm12
000074703edd1258  vmovaps [rsp+0xC0], xmm13
000074703edd1261  vmovaps [rsp+0xD0], xmm14
000074703edd126a  vmovaps [rsp+0xE0], xmm15
000074703edd1273  sub rsp, 0x30
000074703edd1277  movaps [rsp], xmm1
000074703edd127b  movaps [rsp+0x10], xmm13
000074703edd1281  movaps [rsp+0x20], xmm2
000074703edd1286  lea rdi, [rsp]
000074703edd128a  mov esi, 0x00
000074703edd128f  mov rax, 0x5D9974CCC530
000074703edd1299  call rax
000074703edd129b  movaps xmm1, [rsp]
000074703edd129f  add rsp, 0x30
000074703edd12a3  vmovaps xmm0, [rsp]
000074703edd12a8  vmovaps xmm2, [rsp+0x10]
000074703edd12ae  vmovaps xmm3, [rsp+0x20]
000074703edd12b4  vmovaps xmm4, [rsp+0x30]
000074703edd12ba  vmovaps xmm5, [rsp+0x40]
000074703edd12c0  vmovaps xmm6, [rsp+0x50]
000074703edd12c6  vmovaps xmm7, [rsp+0x60]
000074703edd12cc  vmovaps xmm8, [rsp+0x70]
000074703edd12d2  vmovaps xmm9, [rsp+0x80]
000074703edd12db  vmovaps xmm10, [rsp+0x90]
000074703edd12e4  vmovaps xmm11, [rsp+0xA0]
000074703edd12ed  vmovaps xmm12, [rsp+0xB0]
000074703edd12f6  vmovaps xmm13, [rsp+0xC0]
000074703edd12ff  vmovaps xmm14, [rsp+0xD0]
000074703edd1308  vmovaps xmm15, [rsp+0xE0]
000074703edd1311  add rsp, 0xF0
000074703edd1318  pop r11
000074703edd131a  pop r10
000074703edd131c  pop r9
000074703edd131e  pop r8
000074703edd1320  pop rsi
000074703edd1321  pop rdi
000074703edd1322  pop rdx
000074703edd1323  pop rcx
000074703edd1324  pop rax
000074703edd1325  add rsp, 0x08
000074703edd1329  jmp 0x000074703EDCF82C
000074703edd132e  call 0x000074703EC0E760
000074703edd1333  jmp 0x000074703EDCF839
000074703edd1338  sub rsp, 0x08
000074703edd133c  push rax
000074703edd133d  push rcx
000074703edd133e  push rdx
000074703edd133f  push rdi
000074703edd1340  push rsi
000074703edd1341  push r8
000074703edd1343  push r9
000074703edd1345  push r10
000074703edd1347  push r11
000074703edd1349  sub rsp, 0xF0
000074703edd1350  vmovaps [rsp], xmm0
000074703edd1355  vmovaps [rsp+0x10], xmm1
000074703edd135b  vmovaps [rsp+0x20], xmm2
000074703edd1361  vmovaps [rsp+0x30], xmm3
000074703edd1367  vmovaps [rsp+0x40], xmm4
000074703edd136d  vmovaps [rsp+0x50], xmm5
000074703edd1373  vmovaps [rsp+0x60], xmm6
000074703edd1379  vmovaps [rsp+0x70], xmm7
000074703edd137f  vmovaps [rsp+0x80], xmm8
000074703edd1388  vmovaps [rsp+0x90], xmm9
000074703edd1391  vmovaps [rsp+0xA0], xmm10
000074703edd139a  vmovaps [rsp+0xB0], xmm11
000074703edd13a3  vmovaps [rsp+0xC0], xmm12
000074703edd13ac  vmovaps [rsp+0xD0], xmm14
000074703edd13b5  vmovaps [rsp+0xE0], xmm15
000074703edd13be  sub rsp, 0x30
000074703edd13c2  movaps [rsp], xmm13
000074703edd13c7  movaps [rsp+0x10], xmm2
000074703edd13cc  movaps [rsp+0x20], xmm1
000074703edd13d1  lea rdi, [rsp]
000074703edd13d5  mov esi, 0x00
000074703edd13da  mov rax, 0x5D9974CCC530
000074703edd13e4  call rax
000074703edd13e6  movaps xmm13, [rsp]
000074703edd13eb  add rsp, 0x30
000074703edd13ef  vmovaps xmm0, [rsp]
000074703edd13f4  vmovaps xmm1, [rsp+0x10]
000074703edd13fa  vmovaps xmm2, [rsp+0x20]
000074703edd1400  vmovaps xmm3, [rsp+0x30]
000074703edd1406  vmovaps xmm4, [rsp+0x40]
000074703edd140c  vmovaps xmm5, [rsp+0x50]
000074703edd1412  vmovaps xmm6, [rsp+0x60]
000074703edd1418  vmovaps xmm7, [rsp+0x70]
000074703edd141e  vmovaps xmm8, [rsp+0x80]
000074703edd1427  vmovaps xmm9, [rsp+0x90]
000074703edd1430  vmovaps xmm10, [rsp+0xA0]
000074703edd1439  vmovaps xmm11, [rsp+0xB0]
000074703edd1442  vmovaps xmm12, [rsp+0xC0]
000074703edd144b  vmovaps xmm14, [rsp+0xD0]
000074703edd1454  vmovaps xmm15, [rsp+0xE0]
000074703edd145d  add rsp, 0xF0
000074703edd1464  pop r11
000074703edd1466  pop r10
000074703edd1468  pop r9
000074703edd146a  pop r8
000074703edd146c  pop rsi
000074703edd146d  pop rdi
000074703edd146e  pop rdx
000074703edd146f  pop rcx
000074703edd1470  pop rax
000074703edd1471  add rsp, 0x08
000074703edd1475  jmp 0x000074703EDCF878
000074703edd147a  sub rsp, 0x08
000074703edd147e  push rax
000074703edd147f  push rcx
000074703edd1480  push rdx
000074703edd1481  push rdi
000074703edd1482  push rsi
000074703edd1483  push r8
000074703edd1485  push r9
000074703edd1487  push r10
000074703edd1489  push r11
000074703edd148b  sub rsp, 0xF0
000074703edd1492  vmovaps [rsp], xmm0
000074703edd1497  vmovaps [rsp+0x10], xmm2
000074703edd149d  vmovaps [rsp+0x20], xmm3
000074703edd14a3  vmovaps [rsp+0x30], xmm4
000074703edd14a9  vmovaps [rsp+0x40], xmm5
000074703edd14af  vmovaps [rsp+0x50], xmm6
000074703edd14b5  vmovaps [rsp+0x60], xmm7
000074703edd14bb  vmovaps [rsp+0x70], xmm8
000074703edd14c1  vmovaps [rsp+0x80], xmm9
000074703edd14ca  vmovaps [rsp+0x90], xmm10
000074703edd14d3  vmovaps [rsp+0xA0], xmm11
000074703edd14dc  vmovaps [rsp+0xB0], xmm12
000074703edd14e5  vmovaps [rsp+0xC0], xmm13
000074703edd14ee  vmovaps [rsp+0xD0], xmm14
000074703edd14f7  vmovaps [rsp+0xE0], xmm15
000074703edd1500  sub rsp, 0x30
000074703edd1504  movaps [rsp], xmm1
000074703edd1508  movaps [rsp+0x10], xmm15
000074703edd150e  movaps [rsp+0x20], xmm2
000074703edd1513  lea rdi, [rsp]
000074703edd1517  mov esi, 0x00
000074703edd151c  mov rax, 0x5D9974CCC530
000074703edd1526  call rax
000074703edd1528  movaps xmm1, [rsp]
000074703edd152c  add rsp, 0x30
000074703edd1530  vmovaps xmm0, [rsp]
000074703edd1535  vmovaps xmm2, [rsp+0x10]
000074703edd153b  vmovaps xmm3, [rsp+0x20]
000074703edd1541  vmovaps xmm4, [rsp+0x30]
000074703edd1547  vmovaps xmm5, [rsp+0x40]
000074703edd154d  vmovaps xmm6, [rsp+0x50]
000074703edd1553  vmovaps xmm7, [rsp+0x60]
000074703edd1559  vmovaps xmm8, [rsp+0x70]
000074703edd155f  vmovaps xmm9, [rsp+0x80]
000074703edd1568  vmovaps xmm10, [rsp+0x90]
000074703edd1571  vmovaps xmm11, [rsp+0xA0]
000074703edd157a  vmovaps xmm12, [rsp+0xB0]
000074703edd1583  vmovaps xmm13, [rsp+0xC0]
000074703edd158c  vmovaps xmm14, [rsp+0xD0]
000074703edd1595  vmovaps xmm15, [rsp+0xE0]
000074703edd159e  add rsp, 0xF0
000074703edd15a5  pop r11
000074703edd15a7  pop r10
000074703edd15a9  pop r9
000074703edd15ab  pop r8
000074703edd15ad  pop rsi
000074703edd15ae  pop rdi
000074703edd15af  pop rdx
000074703edd15b0  pop rcx
000074703edd15b1  pop rax
000074703edd15b2  add rsp, 0x08
000074703edd15b6  jmp 0x000074703EDCF8AC
000074703edd15bb  sub rsp, 0x08
000074703edd15bf  push rax
000074703edd15c0  push rcx
000074703edd15c1  push rdx
000074703edd15c2  push rdi
000074703edd15c3  push rsi
000074703edd15c4  push r8
000074703edd15c6  push r9
000074703edd15c8  push r10
000074703edd15ca  push r11
000074703edd15cc  sub rsp, 0xF0
000074703edd15d3  vmovaps [rsp], xmm0
000074703edd15d8  vmovaps [rsp+0x10], xmm1
000074703edd15de  vmovaps [rsp+0x20], xmm2
000074703edd15e4  vmovaps [rsp+0x30], xmm3
000074703edd15ea  vmovaps [rsp+0x40], xmm4
000074703edd15f0  vmovaps [rsp+0x50], xmm5
000074703edd15f6  vmovaps [rsp+0x60], xmm6
000074703edd15fc  vmovaps [rsp+0x70], xmm7
000074703edd1602  vmovaps [rsp+0x80], xmm8
000074703edd160b  vmovaps [rsp+0x90], xmm9
000074703edd1614  vmovaps [rsp+0xA0], xmm10
000074703edd161d  vmovaps [rsp+0xB0], xmm11
000074703edd1626  vmovaps [rsp+0xC0], xmm12
000074703edd162f  vmovaps [rsp+0xD0], xmm13
000074703edd1638  vmovaps [rsp+0xE0], xmm15
000074703edd1641  sub rsp, 0x30
000074703edd1645  movaps [rsp], xmm14
000074703edd164a  movaps [rsp+0x10], xmm2
000074703edd164f  movaps [rsp+0x20], xmm15
000074703edd1655  lea rdi, [rsp]
000074703edd1659  mov esi, 0x00
000074703edd165e  mov rax, 0x5D9974CCC530
000074703edd1668  call rax
000074703edd166a  movaps xmm14, [rsp]
000074703edd166f  add rsp, 0x30
000074703edd1673  vmovaps xmm0, [rsp]
000074703edd1678  vmovaps xmm1, [rsp+0x10]
000074703edd167e  vmovaps xmm2, [rsp+0x20]
000074703edd1684  vmovaps xmm3, [rsp+0x30]
000074703edd168a  vmovaps xmm4, [rsp+0x40]
000074703edd1690  vmovaps xmm5, [rsp+0x50]
000074703edd1696  vmovaps xmm6, [rsp+0x60]
000074703edd169c  vmovaps xmm7, [rsp+0x70]
000074703edd16a2  vmovaps xmm8, [rsp+0x80]
000074703edd16ab  vmovaps xmm9, [rsp+0x90]
000074703edd16b4  vmovaps xmm10, [rsp+0xA0]
000074703edd16bd  vmovaps xmm11, [rsp+0xB0]
000074703edd16c6  vmovaps xmm12, [rsp+0xC0]
000074703edd16cf  vmovaps xmm13, [rsp+0xD0]
000074703edd16d8  vmovaps xmm15, [rsp+0xE0]
000074703edd16e1  add rsp, 0xF0
000074703edd16e8  pop r11
000074703edd16ea  pop r10
000074703edd16ec  pop r9
000074703edd16ee  pop r8
000074703edd16f0  pop rsi
000074703edd16f1  pop rdi
000074703edd16f2  pop rdx
000074703edd16f3  pop rcx
000074703edd16f4  pop rax
000074703edd16f5  add rsp, 0x08
000074703edd16f9  jmp 0x000074703EDCF8E7
000074703edd16fe  sub rsp, 0x08
000074703edd1702  push rax
000074703edd1703  push rcx
000074703edd1704  push rdx
000074703edd1705  push rdi
000074703edd1706  push rsi
000074703edd1707  push r8
000074703edd1709  push r9
000074703edd170b  push r10
000074703edd170d  push r11
000074703edd170f  sub rsp, 0xF0
000074703edd1716  vmovaps [rsp], xmm0
000074703edd171b  vmovaps [rsp+0x10], xmm1
000074703edd1721  vmovaps [rsp+0x20], xmm2
000074703edd1727  vmovaps [rsp+0x30], xmm3
000074703edd172d  vmovaps [rsp+0x40], xmm4
000074703edd1733  vmovaps [rsp+0x50], xmm5
000074703edd1739  vmovaps [rsp+0x60], xmm6
000074703edd173f  vmovaps [rsp+0x70], xmm7
000074703edd1745  vmovaps [rsp+0x80], xmm8
000074703edd174e  vmovaps [rsp+0x90], xmm9
000074703edd1757  vmovaps [rsp+0xA0], xmm10
000074703edd1760  vmovaps [rsp+0xB0], xmm11
000074703edd1769  vmovaps [rsp+0xC0], xmm12
000074703edd1772  vmovaps [rsp+0xD0], xmm13
000074703edd177b  vmovaps [rsp+0xE0], xmm14
000074703edd1784  sub rsp, 0x30
000074703edd1788  movaps [rsp], xmm15
000074703edd178d  movaps [rsp+0x10], xmm2
000074703edd1792  movaps [rsp+0x20], xmm1
000074703edd1797  lea rdi, [rsp]
000074703edd179b  mov esi, 0x00
000074703edd17a0  mov rax, 0x5D9974CCC530
000074703edd17aa  call rax
000074703edd17ac  movaps xmm15, [rsp]
000074703edd17b1  add rsp, 0x30
000074703edd17b5  vmovaps xmm0, [rsp]
000074703edd17ba  vmovaps xmm1, [rsp+0x10]
000074703edd17c0  vmovaps xmm2, [rsp+0x20]
000074703edd17c6  vmovaps xmm3, [rsp+0x30]
000074703edd17cc  vmovaps xmm4, [rsp+0x40]
000074703edd17d2  vmovaps xmm5, [rsp+0x50]
000074703edd17d8  vmovaps xmm6, [rsp+0x60]
000074703edd17de  vmovaps xmm7, [rsp+0x70]
000074703edd17e4  vmovaps xmm8, [rsp+0x80]
000074703edd17ed  vmovaps xmm9, [rsp+0x90]
000074703edd17f6  vmovaps xmm10, [rsp+0xA0]
000074703edd17ff  vmovaps xmm11, [rsp+0xB0]
000074703edd1808  vmovaps xmm12, [rsp+0xC0]
000074703edd1811  vmovaps xmm13, [rsp+0xD0]
000074703edd181a  vmovaps xmm14, [rsp+0xE0]
000074703edd1823  add rsp, 0xF0
000074703edd182a  pop r11
000074703edd182c  pop r10
000074703edd182e  pop r9
000074703edd1830  pop r8
000074703edd1832  pop rsi
000074703edd1833  pop rdi
000074703edd1834  pop rdx
000074703edd1835  pop rcx
000074703edd1836  pop rax
000074703edd1837  add rsp, 0x08
000074703edd183b  jmp 0x000074703EDCF923
000074703edd1840  call 0x000074703EBFF430
000074703edd1845  jmp 0x000074703EDCF930
000074703edd184a  sub rsp, 0x08
000074703edd184e  push rax
000074703edd184f  push rcx
000074703edd1850  push rdx
000074703edd1851  push rdi
000074703edd1852  push rsi
000074703edd1853  push r8
000074703edd1855  push r9
000074703edd1857  push r10
000074703edd1859  push r11
000074703edd185b  sub rsp, 0xF0
000074703edd1862  vmovaps [rsp], xmm0
000074703edd1867  vmovaps [rsp+0x10], xmm1
000074703edd186d  vmovaps [rsp+0x20], xmm3
000074703edd1873  vmovaps [rsp+0x30], xmm4
000074703edd1879  vmovaps [rsp+0x40], xmm5
000074703edd187f  vmovaps [rsp+0x50], xmm6
000074703edd1885  vmovaps [rsp+0x60], xmm7
000074703edd188b  vmovaps [rsp+0x70], xmm8
000074703edd1891  vmovaps [rsp+0x80], xmm9
000074703edd189a  vmovaps [rsp+0x90], xmm10
000074703edd18a3  vmovaps [rsp+0xA0], xmm11
000074703edd18ac  vmovaps [rsp+0xB0], xmm12
000074703edd18b5  vmovaps [rsp+0xC0], xmm13
000074703edd18be  vmovaps [rsp+0xD0], xmm14
000074703edd18c7  vmovaps [rsp+0xE0], xmm15
000074703edd18d0  sub rsp, 0x30
000074703edd18d4  movaps [rsp], xmm2
000074703edd18d8  movaps [rsp+0x10], xmm1
000074703edd18dd  movaps [rsp+0x20], xmm14
000074703edd18e3  lea rdi, [rsp]
000074703edd18e7  mov esi, 0x00
000074703edd18ec  mov rax, 0x5D9974CCC530
000074703edd18f6  call rax
000074703edd18f8  movaps xmm2, [rsp]
000074703edd18fc  add rsp, 0x30
000074703edd1900  vmovaps xmm0, [rsp]
000074703edd1905  vmovaps xmm1, [rsp+0x10]
000074703edd190b  vmovaps xmm3, [rsp+0x20]
000074703edd1911  vmovaps xmm4, [rsp+0x30]
000074703edd1917  vmovaps xmm5, [rsp+0x40]
000074703edd191d  vmovaps xmm6, [rsp+0x50]
000074703edd1923  vmovaps xmm7, [rsp+0x60]
000074703edd1929  vmovaps xmm8, [rsp+0x70]
000074703edd192f  vmovaps xmm9, [rsp+0x80]
000074703edd1938  vmovaps xmm10, [rsp+0x90]
000074703edd1941  vmovaps xmm11, [rsp+0xA0]
000074703edd194a  vmovaps xmm12, [rsp+0xB0]
000074703edd1953  vmovaps xmm13, [rsp+0xC0]
000074703edd195c  vmovaps xmm14, [rsp+0xD0]
000074703edd1965  vmovaps xmm15, [rsp+0xE0]
000074703edd196e  add rsp, 0xF0
000074703edd1975  pop r11
000074703edd1977  pop r10
000074703edd1979  pop r9
000074703edd197b  pop r8
000074703edd197d  pop rsi
000074703edd197e  pop rdi
000074703edd197f  pop rdx
000074703edd1980  pop rcx
000074703edd1981  pop rax
000074703edd1982  add rsp, 0x08
000074703edd1986  jmp 0x000074703EDCF96D
000074703edd198b  sub rsp, 0x08
000074703edd198f  push rax
000074703edd1990  push rcx
000074703edd1991  push rdx
000074703edd1992  push rdi
000074703edd1993  push rsi
000074703edd1994  push r8
000074703edd1996  push r9
000074703edd1998  push r10
000074703edd199a  push r11
000074703edd199c  sub rsp, 0xF0
000074703edd19a3  vmovaps [rsp], xmm0
000074703edd19a8  vmovaps [rsp+0x10], xmm1
000074703edd19ae  vmovaps [rsp+0x20], xmm2
000074703edd19b4  vmovaps [rsp+0x30], xmm3
000074703edd19ba  vmovaps [rsp+0x40], xmm4
000074703edd19c0  vmovaps [rsp+0x50], xmm5
000074703edd19c6  vmovaps [rsp+0x60], xmm6
000074703edd19cc  vmovaps [rsp+0x70], xmm7
000074703edd19d2  vmovaps [rsp+0x80], xmm8
000074703edd19db  vmovaps [rsp+0x90], xmm9
000074703edd19e4  vmovaps [rsp+0xA0], xmm10
000074703edd19ed  vmovaps [rsp+0xB0], xmm11
000074703edd19f6  vmovaps [rsp+0xC0], xmm12
000074703edd19ff  vmovaps [rsp+0xD0], xmm13
000074703edd1a08  vmovaps [rsp+0xE0], xmm14
000074703edd1a11  sub rsp, 0x30
000074703edd1a15  movaps [rsp], xmm15
000074703edd1a1a  movaps [rsp+0x10], xmm14
000074703edd1a20  movaps [rsp+0x20], xmm1
000074703edd1a25  lea rdi, [rsp]
000074703edd1a29  mov esi, 0x00
000074703edd1a2e  mov rax, 0x5D9974CCC530
000074703edd1a38  call rax
000074703edd1a3a  movaps xmm15, [rsp]
000074703edd1a3f  add rsp, 0x30
000074703edd1a43  vmovaps xmm0, [rsp]
000074703edd1a48  vmovaps xmm1, [rsp+0x10]
000074703edd1a4e  vmovaps xmm2, [rsp+0x20]
000074703edd1a54  vmovaps xmm3, [rsp+0x30]
000074703edd1a5a  vmovaps xmm4, [rsp+0x40]
000074703edd1a60  vmovaps xmm5, [rsp+0x50]
000074703edd1a66  vmovaps xmm6, [rsp+0x60]
000074703edd1a6c  vmovaps xmm7, [rsp+0x70]
000074703edd1a72  vmovaps xmm8, [rsp+0x80]
000074703edd1a7b  vmovaps xmm9, [rsp+0x90]
000074703edd1a84  vmovaps xmm10, [rsp+0xA0]
000074703edd1a8d  vmovaps xmm11, [rsp+0xB0]
000074703edd1a96  vmovaps xmm12, [rsp+0xC0]
000074703edd1a9f  vmovaps xmm13, [rsp+0xD0]
000074703edd1aa8  vmovaps xmm14, [rsp+0xE0]
000074703edd1ab1  add rsp, 0xF0
000074703edd1ab8  pop r11
000074703edd1aba  pop r10
000074703edd1abc  pop r9
000074703edd1abe  pop r8
000074703edd1ac0  pop rsi
000074703edd1ac1  pop rdi
000074703edd1ac2  pop rdx
000074703edd1ac3  pop rcx
000074703edd1ac4  pop rax
000074703edd1ac5  add rsp, 0x08
000074703edd1ac9  jmp 0x000074703EDCF9E7
000074703edd1ace  call 0x000074703EBFF430
000074703edd1ad3  jmp 0x000074703EDCF9F4
000074703edd1ad8  sub rsp, 0x08
000074703edd1adc  push rax
000074703edd1add  push rcx
000074703edd1ade  push rdx
000074703edd1adf  push rdi
000074703edd1ae0  push rsi
000074703edd1ae1  push r8
000074703edd1ae3  push r9
000074703edd1ae5  push r10
000074703edd1ae7  push r11
000074703edd1ae9  sub rsp, 0xF0
000074703edd1af0  vmovaps [rsp], xmm0
000074703edd1af5  vmovaps [rsp+0x10], xmm1
000074703edd1afb  vmovaps [rsp+0x20], xmm2
000074703edd1b01  vmovaps [rsp+0x30], xmm3
000074703edd1b07  vmovaps [rsp+0x40], xmm4
000074703edd1b0d  vmovaps [rsp+0x50], xmm5
000074703edd1b13  vmovaps [rsp+0x60], xmm6
000074703edd1b19  vmovaps [rsp+0x70], xmm7
000074703edd1b1f  vmovaps [rsp+0x80], xmm8
000074703edd1b28  vmovaps [rsp+0x90], xmm9
000074703edd1b31  vmovaps [rsp+0xA0], xmm10
000074703edd1b3a  vmovaps [rsp+0xB0], xmm11
000074703edd1b43  vmovaps [rsp+0xC0], xmm12
000074703edd1b4c  vmovaps [rsp+0xD0], xmm13
000074703edd1b55  vmovaps [rsp+0xE0], xmm15
000074703edd1b5e  sub rsp, 0x30
000074703edd1b62  movaps [rsp], xmm14
000074703edd1b67  movaps [rsp+0x10], xmm13
000074703edd1b6d  movaps [rsp+0x20], xmm1
000074703edd1b72  lea rdi, [rsp]
000074703edd1b76  mov esi, 0x00
000074703edd1b7b  mov rax, 0x5D9974CCC530
000074703edd1b85  call rax
000074703edd1b87  movaps xmm14, [rsp]
000074703edd1b8c  add rsp, 0x30
000074703edd1b90  vmovaps xmm0, [rsp]
000074703edd1b95  vmovaps xmm1, [rsp+0x10]
000074703edd1b9b  vmovaps xmm2, [rsp+0x20]
000074703edd1ba1  vmovaps xmm3, [rsp+0x30]
000074703edd1ba7  vmovaps xmm4, [rsp+0x40]
000074703edd1bad  vmovaps xmm5, [rsp+0x50]
000074703edd1bb3  vmovaps xmm6, [rsp+0x60]
000074703edd1bb9  vmovaps xmm7, [rsp+0x70]
000074703edd1bbf  vmovaps xmm8, [rsp+0x80]
000074703edd1bc8  vmovaps xmm9, [rsp+0x90]
000074703edd1bd1  vmovaps xmm10, [rsp+0xA0]
000074703edd1bda  vmovaps xmm11, [rsp+0xB0]
000074703edd1be3  vmovaps xmm12, [rsp+0xC0]
000074703edd1bec  vmovaps xmm13, [rsp+0xD0]
000074703edd1bf5  vmovaps xmm15, [rsp+0xE0]
000074703edd1bfe  add rsp, 0xF0
000074703edd1c05  pop r11
000074703edd1c07  pop r10
000074703edd1c09  pop r9
000074703edd1c0b  pop r8
000074703edd1c0d  pop rsi
000074703edd1c0e  pop rdi
000074703edd1c0f  pop rdx
000074703edd1c10  pop rcx
000074703edd1c11  pop rax
000074703edd1c12  add rsp, 0x08
000074703edd1c16  jmp 0x000074703EDCFAAF
000074703edd1c1b  sub rsp, 0x08
000074703edd1c1f  push rax
000074703edd1c20  push rcx
000074703edd1c21  push rdx
000074703edd1c22  push rdi
000074703edd1c23  push rsi
000074703edd1c24  push r8
000074703edd1c26  push r9
000074703edd1c28  push r10
000074703edd1c2a  push r11
000074703edd1c2c  sub rsp, 0xF0
000074703edd1c33  vmovaps [rsp], xmm0
000074703edd1c38  vmovaps [rsp+0x10], xmm1
000074703edd1c3e  vmovaps [rsp+0x20], xmm2
000074703edd1c44  vmovaps [rsp+0x30], xmm3
000074703edd1c4a  vmovaps [rsp+0x40], xmm4
000074703edd1c50  vmovaps [rsp+0x50], xmm5
000074703edd1c56  vmovaps [rsp+0x60], xmm6
000074703edd1c5c  vmovaps [rsp+0x70], xmm7
000074703edd1c62  vmovaps [rsp+0x80], xmm8
000074703edd1c6b  vmovaps [rsp+0x90], xmm9
000074703edd1c74  vmovaps [rsp+0xA0], xmm10
000074703edd1c7d  vmovaps [rsp+0xB0], xmm11
000074703edd1c86  vmovaps [rsp+0xC0], xmm12
000074703edd1c8f  vmovaps [rsp+0xD0], xmm13
000074703edd1c98  vmovaps [rsp+0xE0], xmm14
000074703edd1ca1  sub rsp, 0x30
000074703edd1ca5  movaps [rsp], xmm15
000074703edd1caa  movaps [rsp+0x10], xmm13
000074703edd1cb0  movaps [rsp+0x20], xmm1
000074703edd1cb5  lea rdi, [rsp]
000074703edd1cb9  mov esi, 0x00
000074703edd1cbe  mov rax, 0x5D9974CCC530
000074703edd1cc8  call rax
000074703edd1cca  movaps xmm15, [rsp]
000074703edd1ccf  add rsp, 0x30
000074703edd1cd3  vmovaps xmm0, [rsp]
000074703edd1cd8  vmovaps xmm1, [rsp+0x10]
000074703edd1cde  vmovaps xmm2, [rsp+0x20]
000074703edd1ce4  vmovaps xmm3, [rsp+0x30]
000074703edd1cea  vmovaps xmm4, [rsp+0x40]
000074703edd1cf0  vmovaps xmm5, [rsp+0x50]
000074703edd1cf6  vmovaps xmm6, [rsp+0x60]
000074703edd1cfc  vmovaps xmm7, [rsp+0x70]
000074703edd1d02  vmovaps xmm8, [rsp+0x80]
000074703edd1d0b  vmovaps xmm9, [rsp+0x90]
000074703edd1d14  vmovaps xmm10, [rsp+0xA0]
000074703edd1d1d  vmovaps xmm11, [rsp+0xB0]
000074703edd1d26  vmovaps xmm12, [rsp+0xC0]
000074703edd1d2f  vmovaps xmm13, [rsp+0xD0]
000074703edd1d38  vmovaps xmm14, [rsp+0xE0]
000074703edd1d41  add rsp, 0xF0
000074703edd1d48  pop r11
000074703edd1d4a  pop r10
000074703edd1d4c  pop r9
000074703edd1d4e  pop r8
000074703edd1d50  pop rsi
000074703edd1d51  pop rdi
000074703edd1d52  pop rdx
000074703edd1d53  pop rcx
000074703edd1d54  pop rax
000074703edd1d55  add rsp, 0x08
000074703edd1d59  jmp 0x000074703EDCFAEB
000074703edd1d5e  call 0x000074703EBFF430
000074703edd1d63  jmp 0x000074703EDCFAF8
000074703edd1d68  sub rsp, 0x08
000074703edd1d6c  push rax
000074703edd1d6d  push rcx
000074703edd1d6e  push rdx
000074703edd1d6f  push rdi
000074703edd1d70  push rsi
000074703edd1d71  push r8
000074703edd1d73  push r9
000074703edd1d75  push r10
000074703edd1d77  push r11
000074703edd1d79  sub rsp, 0xF0
000074703edd1d80  vmovaps [rsp], xmm0
000074703edd1d85  vmovaps [rsp+0x10], xmm1
000074703edd1d8b  vmovaps [rsp+0x20], xmm2
000074703edd1d91  vmovaps [rsp+0x30], xmm3
000074703edd1d97  vmovaps [rsp+0x40], xmm4
000074703edd1d9d  vmovaps [rsp+0x50], xmm5
000074703edd1da3  vmovaps [rsp+0x60], xmm6
000074703edd1da9  vmovaps [rsp+0x70], xmm7
000074703edd1daf  vmovaps [rsp+0x80], xmm8
000074703edd1db8  vmovaps [rsp+0x90], xmm9
000074703edd1dc1  vmovaps [rsp+0xA0], xmm10
000074703edd1dca  vmovaps [rsp+0xB0], xmm11
000074703edd1dd3  vmovaps [rsp+0xC0], xmm12
000074703edd1ddc  vmovaps [rsp+0xD0], xmm13
000074703edd1de5  vmovaps [rsp+0xE0], xmm15
000074703edd1dee  sub rsp, 0x30
000074703edd1df2  movaps [rsp], xmm14
000074703edd1df7  movaps [rsp+0x10], xmm13
000074703edd1dfd  movaps [rsp+0x20], xmm2
000074703edd1e02  lea rdi, [rsp]
000074703edd1e06  mov esi, 0x00
000074703edd1e0b  mov rax, 0x5D9974CCC530
000074703edd1e15  call rax
000074703edd1e17  movaps xmm14, [rsp]
000074703edd1e1c  add rsp, 0x30
000074703edd1e20  vmovaps xmm0, [rsp]
000074703edd1e25  vmovaps xmm1, [rsp+0x10]
000074703edd1e2b  vmovaps xmm2, [rsp+0x20]
000074703edd1e31  vmovaps xmm3, [rsp+0x30]
000074703edd1e37  vmovaps xmm4, [rsp+0x40]
000074703edd1e3d  vmovaps xmm5, [rsp+0x50]
000074703edd1e43  vmovaps xmm6, [rsp+0x60]
000074703edd1e49  vmovaps xmm7, [rsp+0x70]
000074703edd1e4f  vmovaps xmm8, [rsp+0x80]
000074703edd1e58  vmovaps xmm9, [rsp+0x90]
000074703edd1e61  vmovaps xmm10, [rsp+0xA0]
000074703edd1e6a  vmovaps xmm11, [rsp+0xB0]
000074703edd1e73  vmovaps xmm12, [rsp+0xC0]
000074703edd1e7c  vmovaps xmm13, [rsp+0xD0]
000074703edd1e85  vmovaps xmm15, [rsp+0xE0]
000074703edd1e8e  add rsp, 0xF0
000074703edd1e95  pop r11
000074703edd1e97  pop r10
000074703edd1e99  pop r9
000074703edd1e9b  pop r8
000074703edd1e9d  pop rsi
000074703edd1e9e  pop rdi
000074703edd1e9f  pop rdx
000074703edd1ea0  pop rcx
000074703edd1ea1  pop rax
000074703edd1ea2  add rsp, 0x08
000074703edd1ea6  jmp 0x000074703EDCFB24
000074703edd1eab  sub rsp, 0x08
000074703edd1eaf  push rax
000074703edd1eb0  push rcx
000074703edd1eb1  push rdx
000074703edd1eb2  push rdi
000074703edd1eb3  push rsi
000074703edd1eb4  push r8
000074703edd1eb6  push r9
000074703edd1eb8  push r10
000074703edd1eba  push r11
000074703edd1ebc  sub rsp, 0xF0
000074703edd1ec3  vmovaps [rsp], xmm0
000074703edd1ec8  vmovaps [rsp+0x10], xmm2
000074703edd1ece  vmovaps [rsp+0x20], xmm3
000074703edd1ed4  vmovaps [rsp+0x30], xmm4
000074703edd1eda  vmovaps [rsp+0x40], xmm5
000074703edd1ee0  vmovaps [rsp+0x50], xmm6
000074703edd1ee6  vmovaps [rsp+0x60], xmm7
000074703edd1eec  vmovaps [rsp+0x70], xmm8
000074703edd1ef2  vmovaps [rsp+0x80], xmm9
000074703edd1efb  vmovaps [rsp+0x90], xmm10
000074703edd1f04  vmovaps [rsp+0xA0], xmm11
000074703edd1f0d  vmovaps [rsp+0xB0], xmm12
000074703edd1f16  vmovaps [rsp+0xC0], xmm13
000074703edd1f1f  vmovaps [rsp+0xD0], xmm14
000074703edd1f28  vmovaps [rsp+0xE0], xmm15
000074703edd1f31  sub rsp, 0x30
000074703edd1f35  movaps [rsp], xmm1
000074703edd1f39  movaps [rsp+0x10], xmm13
000074703edd1f3f  movaps [rsp+0x20], xmm2
000074703edd1f44  lea rdi, [rsp]
000074703edd1f48  mov esi, 0x00
000074703edd1f4d  mov rax, 0x5D9974CCC530
000074703edd1f57  call rax
000074703edd1f59  movaps xmm1, [rsp]
000074703edd1f5d  add rsp, 0x30
000074703edd1f61  vmovaps xmm0, [rsp]
000074703edd1f66  vmovaps xmm2, [rsp+0x10]
000074703edd1f6c  vmovaps xmm3, [rsp+0x20]
000074703edd1f72  vmovaps xmm4, [rsp+0x30]
000074703edd1f78  vmovaps xmm5, [rsp+0x40]
000074703edd1f7e  vmovaps xmm6, [rsp+0x50]
000074703edd1f84  vmovaps xmm7, [rsp+0x60]
000074703edd1f8a  vmovaps xmm8, [rsp+0x70]
000074703edd1f90  vmovaps xmm9, [rsp+0x80]
000074703edd1f99  vmovaps xmm10, [rsp+0x90]
000074703edd1fa2  vmovaps xmm11, [rsp+0xA0]
000074703edd1fab  vmovaps xmm12, [rsp+0xB0]
000074703edd1fb4  vmovaps xmm13, [rsp+0xC0]
000074703edd1fbd  vmovaps xmm14, [rsp+0xD0]
000074703edd1fc6  vmovaps xmm15, [rsp+0xE0]
000074703edd1fcf  add rsp, 0xF0
000074703edd1fd6  pop r11
000074703edd1fd8  pop r10
000074703edd1fda  pop r9
000074703edd1fdc  pop r8
000074703edd1fde  pop rsi
000074703edd1fdf  pop rdi
000074703edd1fe0  pop rdx
000074703edd1fe1  pop rcx
000074703edd1fe2  pop rax
000074703edd1fe3  add rsp, 0x08
000074703edd1fe7  jmp 0x000074703EDCFB52
000074703edd1fec  sub rsp, 0x08
000074703edd1ff0  push rax
000074703edd1ff1  push rcx
000074703edd1ff2  push rdx
000074703edd1ff3  push rdi
000074703edd1ff4  push rsi
000074703edd1ff5  push r8
000074703edd1ff7  push r9
000074703edd1ff9  push r10
000074703edd1ffb  push r11
000074703edd1ffd  sub rsp, 0xF0
000074703edd2004  vmovaps [rsp], xmm0
000074703edd2009  vmovaps [rsp+0x10], xmm1
000074703edd200f  vmovaps [rsp+0x20], xmm3
000074703edd2015  vmovaps [rsp+0x30], xmm4
000074703edd201b  vmovaps [rsp+0x40], xmm5
000074703edd2021  vmovaps [rsp+0x50], xmm6
000074703edd2027  vmovaps [rsp+0x60], xmm7
000074703edd202d  vmovaps [rsp+0x70], xmm8
000074703edd2033  vmovaps [rsp+0x80], xmm9
000074703edd203c  vmovaps [rsp+0x90], xmm10
000074703edd2045  vmovaps [rsp+0xA0], xmm11
000074703edd204e  vmovaps [rsp+0xB0], xmm12
000074703edd2057  vmovaps [rsp+0xC0], xmm13
000074703edd2060  vmovaps [rsp+0xD0], xmm14
000074703edd2069  vmovaps [rsp+0xE0], xmm15
000074703edd2072  sub rsp, 0x30
000074703edd2076  movaps [rsp], xmm2
000074703edd207a  movaps [rsp+0x10], xmm1
000074703edd207f  movaps [rsp+0x20], xmm13
000074703edd2085  lea rdi, [rsp]
000074703edd2089  mov esi, 0x00
000074703edd208e  mov rax, 0x5D9974CCC530
000074703edd2098  call rax
000074703edd209a  movaps xmm2, [rsp]
000074703edd209e  add rsp, 0x30
000074703edd20a2  vmovaps xmm0, [rsp]
000074703edd20a7  vmovaps xmm1, [rsp+0x10]
000074703edd20ad  vmovaps xmm3, [rsp+0x20]
000074703edd20b3  vmovaps xmm4, [rsp+0x30]
000074703edd20b9  vmovaps xmm5, [rsp+0x40]
000074703edd20bf  vmovaps xmm6, [rsp+0x50]
000074703edd20c5  vmovaps xmm7, [rsp+0x60]
000074703edd20cb  vmovaps xmm8, [rsp+0x70]
000074703edd20d1  vmovaps xmm9, [rsp+0x80]
000074703edd20da  vmovaps xmm10, [rsp+0x90]
000074703edd20e3  vmovaps xmm11, [rsp+0xA0]
000074703edd20ec  vmovaps xmm12, [rsp+0xB0]
000074703edd20f5  vmovaps xmm13, [rsp+0xC0]
000074703edd20fe  vmovaps xmm14, [rsp+0xD0]
000074703edd2107  vmovaps xmm15, [rsp+0xE0]
000074703edd2110  add rsp, 0xF0
000074703edd2117  pop r11
000074703edd2119  pop r10
000074703edd211b  pop r9
000074703edd211d  pop r8
000074703edd211f  pop rsi
000074703edd2120  pop rdi
000074703edd2121  pop rdx
000074703edd2122  pop rcx
000074703edd2123  pop rax
000074703edd2124  add rsp, 0x08
000074703edd2128  jmp 0x000074703EDCFBAB
000074703edd212d  call 0x000074703EBFF430
000074703edd2132  jmp 0x000074703EDCFBB8
000074703edd2137  sub rsp, 0x08
000074703edd213b  push rax
000074703edd213c  push rcx
000074703edd213d  push rdx
000074703edd213e  push rdi
000074703edd213f  push rsi
000074703edd2140  push r8
000074703edd2142  push r9
000074703edd2144  push r10
000074703edd2146  push r11
000074703edd2148  sub rsp, 0xF0
000074703edd214f  vmovaps [rsp], xmm0
000074703edd2154  vmovaps [rsp+0x10], xmm1
000074703edd215a  vmovaps [rsp+0x20], xmm2
000074703edd2160  vmovaps [rsp+0x30], xmm3
000074703edd2166  vmovaps [rsp+0x40], xmm4
000074703edd216c  vmovaps [rsp+0x50], xmm5
000074703edd2172  vmovaps [rsp+0x60], xmm6
000074703edd2178  vmovaps [rsp+0x70], xmm7
000074703edd217e  vmovaps [rsp+0x80], xmm8
000074703edd2187  vmovaps [rsp+0x90], xmm9
000074703edd2190  vmovaps [rsp+0xA0], xmm10
000074703edd2199  vmovaps [rsp+0xB0], xmm11
000074703edd21a2  vmovaps [rsp+0xC0], xmm12
000074703edd21ab  vmovaps [rsp+0xD0], xmm13
000074703edd21b4  vmovaps [rsp+0xE0], xmm14
000074703edd21bd  sub rsp, 0x30
000074703edd21c1  movaps [rsp], xmm15
000074703edd21c6  movaps [rsp+0x10], xmm13
000074703edd21cc  movaps [rsp+0x20], xmm1
000074703edd21d1  lea rdi, [rsp]
000074703edd21d5  mov esi, 0x00
000074703edd21da  mov rax, 0x5D9974CCC530
000074703edd21e4  call rax
000074703edd21e6  movaps xmm15, [rsp]
000074703edd21eb  add rsp, 0x30
000074703edd21ef  vmovaps xmm0, [rsp]
000074703edd21f4  vmovaps xmm1, [rsp+0x10]
000074703edd21fa  vmovaps xmm2, [rsp+0x20]
000074703edd2200  vmovaps xmm3, [rsp+0x30]
000074703edd2206  vmovaps xmm4, [rsp+0x40]
000074703edd220c  vmovaps xmm5, [rsp+0x50]
000074703edd2212  vmovaps xmm6, [rsp+0x60]
000074703edd2218  vmovaps xmm7, [rsp+0x70]
000074703edd221e  vmovaps xmm8, [rsp+0x80]
000074703edd2227  vmovaps xmm9, [rsp+0x90]
000074703edd2230  vmovaps xmm10, [rsp+0xA0]
000074703edd2239  vmovaps xmm11, [rsp+0xB0]
000074703edd2242  vmovaps xmm12, [rsp+0xC0]
000074703edd224b  vmovaps xmm13, [rsp+0xD0]
000074703edd2254  vmovaps xmm14, [rsp+0xE0]
000074703edd225d  add rsp, 0xF0
000074703edd2264  pop r11
000074703edd2266  pop r10
000074703edd2268  pop r9
000074703edd226a  pop r8
000074703edd226c  pop rsi
000074703edd226d  pop rdi
000074703edd226e  pop rdx
000074703edd226f  pop rcx
000074703edd2270  pop rax
000074703edd2271  add rsp, 0x08
000074703edd2275  jmp 0x000074703EDCFBF7
000074703edd227a  sub rsp, 0x08
000074703edd227e  push rax
000074703edd227f  push rcx
000074703edd2280  push rdx
000074703edd2281  push rdi
000074703edd2282  push rsi
000074703edd2283  push r8
000074703edd2285  push r9
000074703edd2287  push r10
000074703edd2289  push r11
000074703edd228b  sub rsp, 0xF0
000074703edd2292  vmovaps [rsp], xmm0
000074703edd2297  vmovaps [rsp+0x10], xmm1
000074703edd229d  vmovaps [rsp+0x20], xmm2
000074703edd22a3  vmovaps [rsp+0x30], xmm3
000074703edd22a9  vmovaps [rsp+0x40], xmm4
000074703edd22af  vmovaps [rsp+0x50], xmm5
000074703edd22b5  vmovaps [rsp+0x60], xmm6
000074703edd22bb  vmovaps [rsp+0x70], xmm7
000074703edd22c1  vmovaps [rsp+0x80], xmm8
000074703edd22ca  vmovaps [rsp+0x90], xmm9
000074703edd22d3  vmovaps [rsp+0xA0], xmm10
000074703edd22dc  vmovaps [rsp+0xB0], xmm11
000074703edd22e5  vmovaps [rsp+0xC0], xmm12
000074703edd22ee  vmovaps [rsp+0xD0], xmm13
000074703edd22f7  vmovaps [rsp+0xE0], xmm15
000074703edd2300  sub rsp, 0x30
000074703edd2304  movaps [rsp], xmm14
000074703edd2309  movaps [rsp+0x10], xmm11
000074703edd230f  movaps [rsp+0x20], xmm1
000074703edd2314  lea rdi, [rsp]
000074703edd2318  mov esi, 0x00
000074703edd231d  mov rax, 0x5D9974CCC530
000074703edd2327  call rax
000074703edd2329  movaps xmm14, [rsp]
000074703edd232e  add rsp, 0x30
000074703edd2332  vmovaps xmm0, [rsp]
000074703edd2337  vmovaps xmm1, [rsp+0x10]
000074703edd233d  vmovaps xmm2, [rsp+0x20]
000074703edd2343  vmovaps xmm3, [rsp+0x30]
000074703edd2349  vmovaps xmm4, [rsp+0x40]
000074703edd234f  vmovaps xmm5, [rsp+0x50]
000074703edd2355  vmovaps xmm6, [rsp+0x60]
000074703edd235b  vmovaps xmm7, [rsp+0x70]
000074703edd2361  vmovaps xmm8, [rsp+0x80]
000074703edd236a  vmovaps xmm9, [rsp+0x90]
000074703edd2373  vmovaps xmm10, [rsp+0xA0]
000074703edd237c  vmovaps xmm11, [rsp+0xB0]
000074703edd2385  vmovaps xmm12, [rsp+0xC0]
000074703edd238e  vmovaps xmm13, [rsp+0xD0]
000074703edd2397  vmovaps xmm15, [rsp+0xE0]
000074703edd23a0  add rsp, 0xF0
000074703edd23a7  pop r11
000074703edd23a9  pop r10
000074703edd23ab  pop r9
000074703edd23ad  pop r8
000074703edd23af  pop rsi
000074703edd23b0  pop rdi
000074703edd23b1  pop rdx
000074703edd23b2  pop rcx
000074703edd23b3  pop rax
000074703edd23b4  add rsp, 0x08
000074703edd23b8  jmp 0x000074703EDCFC21
000074703edd23bd  sub rsp, 0x08
000074703edd23c1  push rax
000074703edd23c2  push rcx
000074703edd23c3  push rdx
000074703edd23c4  push rdi
000074703edd23c5  push rsi
000074703edd23c6  push r8
000074703edd23c8  push r9
000074703edd23ca  push r10
000074703edd23cc  push r11
000074703edd23ce  sub rsp, 0xF0
000074703edd23d5  vmovaps [rsp], xmm0
000074703edd23da  vmovaps [rsp+0x10], xmm1
000074703edd23e0  vmovaps [rsp+0x20], xmm2
000074703edd23e6  vmovaps [rsp+0x30], xmm3
000074703edd23ec  vmovaps [rsp+0x40], xmm4
000074703edd23f2  vmovaps [rsp+0x50], xmm5
000074703edd23f8  vmovaps [rsp+0x60], xmm6
000074703edd23fe  vmovaps [rsp+0x70], xmm7
000074703edd2404  vmovaps [rsp+0x80], xmm8
000074703edd240d  vmovaps [rsp+0x90], xmm9
000074703edd2416  vmovaps [rsp+0xA0], xmm10
000074703edd241f  vmovaps [rsp+0xB0], xmm11
000074703edd2428  vmovaps [rsp+0xC0], xmm12
000074703edd2431  vmovaps [rsp+0xD0], xmm14
000074703edd243a  vmovaps [rsp+0xE0], xmm15
000074703edd2443  sub rsp, 0x30
000074703edd2447  movaps [rsp], xmm13
000074703edd244c  movaps [rsp+0x10], xmm11
000074703edd2452  movaps [rsp+0x20], xmm1
000074703edd2457  lea rdi, [rsp]
000074703edd245b  mov esi, 0x00
000074703edd2460  mov rax, 0x5D9974CCC530
000074703edd246a  call rax
000074703edd246c  movaps xmm13, [rsp]
000074703edd2471  add rsp, 0x30
000074703edd2475  vmovaps xmm0, [rsp]
000074703edd247a  vmovaps xmm1, [rsp+0x10]
000074703edd2480  vmovaps xmm2, [rsp+0x20]
000074703edd2486  vmovaps xmm3, [rsp+0x30]
000074703edd248c  vmovaps xmm4, [rsp+0x40]
000074703edd2492  vmovaps xmm5, [rsp+0x50]
000074703edd2498  vmovaps xmm6, [rsp+0x60]
000074703edd249e  vmovaps xmm7, [rsp+0x70]
000074703edd24a4  vmovaps xmm8, [rsp+0x80]
000074703edd24ad  vmovaps xmm9, [rsp+0x90]
000074703edd24b6  vmovaps xmm10, [rsp+0xA0]
000074703edd24bf  vmovaps xmm11, [rsp+0xB0]
000074703edd24c8  vmovaps xmm12, [rsp+0xC0]
000074703edd24d1  vmovaps xmm14, [rsp+0xD0]
000074703edd24da  vmovaps xmm15, [rsp+0xE0]
000074703edd24e3  add rsp, 0xF0
000074703edd24ea  pop r11
000074703edd24ec  pop r10
000074703edd24ee  pop r9
000074703edd24f0  pop r8
000074703edd24f2  pop rsi
000074703edd24f3  pop rdi
000074703edd24f4  pop rdx
000074703edd24f5  pop rcx
000074703edd24f6  pop rax
000074703edd24f7  add rsp, 0x08
000074703edd24fb  jmp 0x000074703EDCFC76
000074703edd2500  call 0x000074703EBFF430
000074703edd2505  jmp 0x000074703EDCFC83
000074703edd250a  sub rsp, 0x08
000074703edd250e  push rax
000074703edd250f  push rcx
000074703edd2510  push rdx
000074703edd2511  push rdi
000074703edd2512  push rsi
000074703edd2513  push r8
000074703edd2515  push r9
000074703edd2517  push r10
000074703edd2519  push r11
000074703edd251b  sub rsp, 0xF0
000074703edd2522  vmovaps [rsp], xmm0
000074703edd2527  vmovaps [rsp+0x10], xmm1
000074703edd252d  vmovaps [rsp+0x20], xmm2
000074703edd2533  vmovaps [rsp+0x30], xmm3
000074703edd2539  vmovaps [rsp+0x40], xmm4
000074703edd253f  vmovaps [rsp+0x50], xmm5
000074703edd2545  vmovaps [rsp+0x60], xmm6
000074703edd254b  vmovaps [rsp+0x70], xmm7
000074703edd2551  vmovaps [rsp+0x80], xmm8
000074703edd255a  vmovaps [rsp+0x90], xmm9
000074703edd2563  vmovaps [rsp+0xA0], xmm10
000074703edd256c  vmovaps [rsp+0xB0], xmm11
000074703edd2575  vmovaps [rsp+0xC0], xmm12
000074703edd257e  vmovaps [rsp+0xD0], xmm13
000074703edd2587  vmovaps [rsp+0xE0], xmm14
000074703edd2590  sub rsp, 0x30
000074703edd2594  movaps [rsp], xmm15
000074703edd2599  movaps [rsp+0x10], xmm11
000074703edd259f  movaps [rsp+0x20], xmm1
000074703edd25a4  lea rdi, [rsp]
000074703edd25a8  mov esi, 0x00
000074703edd25ad  mov rax, 0x5D9974CCC530
000074703edd25b7  call rax
000074703edd25b9  movaps xmm15, [rsp]
000074703edd25be  add rsp, 0x30
000074703edd25c2  vmovaps xmm0, [rsp]
000074703edd25c7  vmovaps xmm1, [rsp+0x10]
000074703edd25cd  vmovaps xmm2, [rsp+0x20]
000074703edd25d3  vmovaps xmm3, [rsp+0x30]
000074703edd25d9  vmovaps xmm4, [rsp+0x40]
000074703edd25df  vmovaps xmm5, [rsp+0x50]
000074703edd25e5  vmovaps xmm6, [rsp+0x60]
000074703edd25eb  vmovaps xmm7, [rsp+0x70]
000074703edd25f1  vmovaps xmm8, [rsp+0x80]
000074703edd25fa  vmovaps xmm9, [rsp+0x90]
000074703edd2603  vmovaps xmm10, [rsp+0xA0]
000074703edd260c  vmovaps xmm11, [rsp+0xB0]
000074703edd2615  vmovaps xmm12, [rsp+0xC0]
000074703edd261e  vmovaps xmm13, [rsp+0xD0]
000074703edd2627  vmovaps xmm14, [rsp+0xE0]
000074703edd2630  add rsp, 0xF0
000074703edd2637  pop r11
000074703edd2639  pop r10
000074703edd263b  pop r9
000074703edd263d  pop r8
000074703edd263f  pop rsi
000074703edd2640  pop rdi
000074703edd2641  pop rdx
000074703edd2642  pop rcx
000074703edd2643  pop rax
000074703edd2644  add rsp, 0x08
000074703edd2648  jmp 0x000074703EDCFCBC
000074703edd264d  sub rsp, 0x08
000074703edd2651  push rax
000074703edd2652  push rcx
000074703edd2653  push rdx
000074703edd2654  push rdi
000074703edd2655  push rsi
000074703edd2656  push r8
000074703edd2658  push r9
000074703edd265a  push r10
000074703edd265c  push r11
000074703edd265e  sub rsp, 0xF0
000074703edd2665  vmovaps [rsp], xmm0
000074703edd266a  vmovaps [rsp+0x10], xmm1
000074703edd2670  vmovaps [rsp+0x20], xmm2
000074703edd2676  vmovaps [rsp+0x30], xmm3
000074703edd267c  vmovaps [rsp+0x40], xmm4
000074703edd2682  vmovaps [rsp+0x50], xmm5
000074703edd2688  vmovaps [rsp+0x60], xmm6
000074703edd268e  vmovaps [rsp+0x70], xmm7
000074703edd2694  vmovaps [rsp+0x80], xmm8
000074703edd269d  vmovaps [rsp+0x90], xmm9
000074703edd26a6  vmovaps [rsp+0xA0], xmm10
000074703edd26af  vmovaps [rsp+0xB0], xmm12
000074703edd26b8  vmovaps [rsp+0xC0], xmm13
000074703edd26c1  vmovaps [rsp+0xD0], xmm14
000074703edd26ca  vmovaps [rsp+0xE0], xmm15
000074703edd26d3  sub rsp, 0x30
000074703edd26d7  movaps [rsp], xmm11
000074703edd26dc  movaps [rsp+0x10], xmm6
000074703edd26e1  movaps [rsp+0x20], xmm14
000074703edd26e7  lea rdi, [rsp]
000074703edd26eb  mov esi, 0x00
000074703edd26f0  mov rax, 0x5D9974CCC530
000074703edd26fa  call rax
000074703edd26fc  movaps xmm11, [rsp]
000074703edd2701  add rsp, 0x30
000074703edd2705  vmovaps xmm0, [rsp]
000074703edd270a  vmovaps xmm1, [rsp+0x10]
000074703edd2710  vmovaps xmm2, [rsp+0x20]
000074703edd2716  vmovaps xmm3, [rsp+0x30]
000074703edd271c  vmovaps xmm4, [rsp+0x40]
000074703edd2722  vmovaps xmm5, [rsp+0x50]
000074703edd2728  vmovaps xmm6, [rsp+0x60]
000074703edd272e  vmovaps xmm7, [rsp+0x70]
000074703edd2734  vmovaps xmm8, [rsp+0x80]
000074703edd273d  vmovaps xmm9, [rsp+0x90]
000074703edd2746  vmovaps xmm10, [rsp+0xA0]
000074703edd274f  vmovaps xmm12, [rsp+0xB0]
000074703edd2758  vmovaps xmm13, [rsp+0xC0]
000074703edd2761  vmovaps xmm14, [rsp+0xD0]
000074703edd276a  vmovaps xmm15, [rsp+0xE0]
000074703edd2773  add rsp, 0xF0
000074703edd277a  pop r11
000074703edd277c  pop r10
000074703edd277e  pop r9
000074703edd2780  pop r8
000074703edd2782  pop rsi
000074703edd2783  pop rdi
000074703edd2784  pop rdx
000074703edd2785  pop rcx
000074703edd2786  pop rax
000074703edd2787  add rsp, 0x08
000074703edd278b  jmp 0x000074703EDCFD34
000074703edd2790  call 0x000074703EBFF430
000074703edd2795  jmp 0x000074703EDCFD3E
000074703edd279a  sub rsp, 0x08
000074703edd279e  push rax
000074703edd279f  push rcx
000074703edd27a0  push rdx
000074703edd27a1  push rdi
000074703edd27a2  push rsi
000074703edd27a3  push r8
000074703edd27a5  push r9
000074703edd27a7  push r10
000074703edd27a9  push r11
000074703edd27ab  sub rsp, 0xF0
000074703edd27b2  vmovaps [rsp], xmm0
000074703edd27b7  vmovaps [rsp+0x10], xmm1
000074703edd27bd  vmovaps [rsp+0x20], xmm2
000074703edd27c3  vmovaps [rsp+0x30], xmm3
000074703edd27c9  vmovaps [rsp+0x40], xmm4
000074703edd27cf  vmovaps [rsp+0x50], xmm5
000074703edd27d5  vmovaps [rsp+0x60], xmm6
000074703edd27db  vmovaps [rsp+0x70], xmm7
000074703edd27e1  vmovaps [rsp+0x80], xmm8
000074703edd27ea  vmovaps [rsp+0x90], xmm9
000074703edd27f3  vmovaps [rsp+0xA0], xmm10
000074703edd27fc  vmovaps [rsp+0xB0], xmm11
000074703edd2805  vmovaps [rsp+0xC0], xmm12
000074703edd280e  vmovaps [rsp+0xD0], xmm13
000074703edd2817  vmovaps [rsp+0xE0], xmm15
000074703edd2820  sub rsp, 0x30
000074703edd2824  movaps [rsp], xmm14
000074703edd2829  movaps [rsp+0x10], xmm6
000074703edd282e  movaps [rsp+0x20], xmm2
000074703edd2833  lea rdi, [rsp]
000074703edd2837  mov esi, 0x00
000074703edd283c  mov rax, 0x5D9974CCC530
000074703edd2846  call rax
000074703edd2848  movaps xmm14, [rsp]
000074703edd284d  add rsp, 0x30
000074703edd2851  vmovaps xmm0, [rsp]
000074703edd2856  vmovaps xmm1, [rsp+0x10]
000074703edd285c  vmovaps xmm2, [rsp+0x20]
000074703edd2862  vmovaps xmm3, [rsp+0x30]
000074703edd2868  vmovaps xmm4, [rsp+0x40]
000074703edd286e  vmovaps xmm5, [rsp+0x50]
000074703edd2874  vmovaps xmm6, [rsp+0x60]
000074703edd287a  vmovaps xmm7, [rsp+0x70]
000074703edd2880  vmovaps xmm8, [rsp+0x80]
000074703edd2889  vmovaps xmm9, [rsp+0x90]
000074703edd2892  vmovaps xmm10, [rsp+0xA0]
000074703edd289b  vmovaps xmm11, [rsp+0xB0]
000074703edd28a4  vmovaps xmm12, [rsp+0xC0]
000074703edd28ad  vmovaps xmm13, [rsp+0xD0]
000074703edd28b6  vmovaps xmm15, [rsp+0xE0]
000074703edd28bf  add rsp, 0xF0
000074703edd28c6  pop r11
000074703edd28c8  pop r10
000074703edd28ca  pop r9
000074703edd28cc  pop r8
000074703edd28ce  pop rsi
000074703edd28cf  pop rdi
000074703edd28d0  pop rdx
000074703edd28d1  pop rcx
000074703edd28d2  pop rax
000074703edd28d3  add rsp, 0x08
000074703edd28d7  jmp 0x000074703EDCFD72
000074703edd28dc  sub rsp, 0x08
000074703edd28e0  push rax
000074703edd28e1  push rcx
000074703edd28e2  push rdx
000074703edd28e3  push rdi
000074703edd28e4  push rsi
000074703edd28e5  push r8
000074703edd28e7  push r9
000074703edd28e9  push r10
000074703edd28eb  push r11
000074703edd28ed  sub rsp, 0xF0
000074703edd28f4  vmovaps [rsp], xmm0
000074703edd28f9  vmovaps [rsp+0x10], xmm1
000074703edd28ff  vmovaps [rsp+0x20], xmm2
000074703edd2905  vmovaps [rsp+0x30], xmm3
000074703edd290b  vmovaps [rsp+0x40], xmm4
000074703edd2911  vmovaps [rsp+0x50], xmm5
000074703edd2917  vmovaps [rsp+0x60], xmm7
000074703edd291d  vmovaps [rsp+0x70], xmm8
000074703edd2923  vmovaps [rsp+0x80], xmm9
000074703edd292c  vmovaps [rsp+0x90], xmm10
000074703edd2935  vmovaps [rsp+0xA0], xmm11
000074703edd293e  vmovaps [rsp+0xB0], xmm12
000074703edd2947  vmovaps [rsp+0xC0], xmm13
000074703edd2950  vmovaps [rsp+0xD0], xmm14
000074703edd2959  vmovaps [rsp+0xE0], xmm15
000074703edd2962  sub rsp, 0x30
000074703edd2966  movaps [rsp], xmm6
000074703edd296a  movaps [rsp+0x10], xmm5
000074703edd296f  movaps [rsp+0x20], xmm1
000074703edd2974  lea rdi, [rsp]
000074703edd2978  mov esi, 0x00
000074703edd297d  mov rax, 0x5D9974CCC530
000074703edd2987  call rax
000074703edd2989  movaps xmm6, [rsp]
000074703edd298d  add rsp, 0x30
000074703edd2991  vmovaps xmm0, [rsp]
000074703edd2996  vmovaps xmm1, [rsp+0x10]
000074703edd299c  vmovaps xmm2, [rsp+0x20]
000074703edd29a2  vmovaps xmm3, [rsp+0x30]
000074703edd29a8  vmovaps xmm4, [rsp+0x40]
000074703edd29ae  vmovaps xmm5, [rsp+0x50]
000074703edd29b4  vmovaps xmm7, [rsp+0x60]
000074703edd29ba  vmovaps xmm8, [rsp+0x70]
000074703edd29c0  vmovaps xmm9, [rsp+0x80]
000074703edd29c9  vmovaps xmm10, [rsp+0x90]
000074703edd29d2  vmovaps xmm11, [rsp+0xA0]
000074703edd29db  vmovaps xmm12, [rsp+0xB0]
000074703edd29e4  vmovaps xmm13, [rsp+0xC0]
000074703edd29ed  vmovaps xmm14, [rsp+0xD0]
000074703edd29f6  vmovaps xmm15, [rsp+0xE0]
000074703edd29ff  add rsp, 0xF0
000074703edd2a06  pop r11
000074703edd2a08  pop r10
000074703edd2a0a  pop r9
000074703edd2a0c  pop r8
000074703edd2a0e  pop rsi
000074703edd2a0f  pop rdi
000074703edd2a10  pop rdx
000074703edd2a11  pop rcx
000074703edd2a12  pop rax
000074703edd2a13  add rsp, 0x08
000074703edd2a17  jmp 0x000074703EDCFD98
000074703edd2a1c  sub rsp, 0x08
000074703edd2a20  push rax
000074703edd2a21  push rcx
000074703edd2a22  push rdx
000074703edd2a23  push rdi
000074703edd2a24  push rsi
000074703edd2a25  push r8
000074703edd2a27  push r9
000074703edd2a29  push r10
000074703edd2a2b  push r11
000074703edd2a2d  sub rsp, 0xF0
000074703edd2a34  vmovaps [rsp], xmm0
000074703edd2a39  vmovaps [rsp+0x10], xmm2
000074703edd2a3f  vmovaps [rsp+0x20], xmm3
000074703edd2a45  vmovaps [rsp+0x30], xmm4
000074703edd2a4b  vmovaps [rsp+0x40], xmm5
000074703edd2a51  vmovaps [rsp+0x50], xmm6
000074703edd2a57  vmovaps [rsp+0x60], xmm7
000074703edd2a5d  vmovaps [rsp+0x70], xmm8
000074703edd2a63  vmovaps [rsp+0x80], xmm9
000074703edd2a6c  vmovaps [rsp+0x90], xmm10
000074703edd2a75  vmovaps [rsp+0xA0], xmm11
000074703edd2a7e  vmovaps [rsp+0xB0], xmm12
000074703edd2a87  vmovaps [rsp+0xC0], xmm13
000074703edd2a90  vmovaps [rsp+0xD0], xmm14
000074703edd2a99  vmovaps [rsp+0xE0], xmm15
000074703edd2aa2  sub rsp, 0x30
000074703edd2aa6  movaps [rsp], xmm1
000074703edd2aaa  movaps [rsp+0x10], xmm5
000074703edd2aaf  movaps [rsp+0x20], xmm13
000074703edd2ab5  lea rdi, [rsp]
000074703edd2ab9  mov esi, 0x00
000074703edd2abe  mov rax, 0x5D9974CCC530
000074703edd2ac8  call rax
000074703edd2aca  movaps xmm1, [rsp]
000074703edd2ace  add rsp, 0x30
000074703edd2ad2  vmovaps xmm0, [rsp]
000074703edd2ad7  vmovaps xmm2, [rsp+0x10]
000074703edd2add  vmovaps xmm3, [rsp+0x20]
000074703edd2ae3  vmovaps xmm4, [rsp+0x30]
000074703edd2ae9  vmovaps xmm5, [rsp+0x40]
000074703edd2aef  vmovaps xmm6, [rsp+0x50]
000074703edd2af5  vmovaps xmm7, [rsp+0x60]
000074703edd2afb  vmovaps xmm8, [rsp+0x70]
000074703edd2b01  vmovaps xmm9, [rsp+0x80]
000074703edd2b0a  vmovaps xmm10, [rsp+0x90]
000074703edd2b13  vmovaps xmm11, [rsp+0xA0]
000074703edd2b1c  vmovaps xmm12, [rsp+0xB0]
000074703edd2b25  vmovaps xmm13, [rsp+0xC0]
000074703edd2b2e  vmovaps xmm14, [rsp+0xD0]
000074703edd2b37  vmovaps xmm15, [rsp+0xE0]
000074703edd2b40  add rsp, 0xF0
000074703edd2b47  pop r11
000074703edd2b49  pop r10
000074703edd2b4b  pop r9
000074703edd2b4d  pop r8
000074703edd2b4f  pop rsi
000074703edd2b50  pop rdi
000074703edd2b51  pop rdx
000074703edd2b52  pop rcx
000074703edd2b53  pop rax
000074703edd2b54  add rsp, 0x08
000074703edd2b58  jmp 0x000074703EDCFDB6
000074703edd2b5d  sub rsp, 0x08
000074703edd2b61  push rax
000074703edd2b62  push rcx
000074703edd2b63  push rdx
000074703edd2b64  push rdi
000074703edd2b65  push rsi
000074703edd2b66  push r8
000074703edd2b68  push r9
000074703edd2b6a  push r10
000074703edd2b6c  push r11
000074703edd2b6e  sub rsp, 0xF0
000074703edd2b75  vmovaps [rsp], xmm0
000074703edd2b7a  vmovaps [rsp+0x10], xmm1
000074703edd2b80  vmovaps [rsp+0x20], xmm2
000074703edd2b86  vmovaps [rsp+0x30], xmm3
000074703edd2b8c  vmovaps [rsp+0x40], xmm4
000074703edd2b92  vmovaps [rsp+0x50], xmm6
000074703edd2b98  vmovaps [rsp+0x60], xmm7
000074703edd2b9e  vmovaps [rsp+0x70], xmm8
000074703edd2ba4  vmovaps [rsp+0x80], xmm9
000074703edd2bad  vmovaps [rsp+0x90], xmm10
000074703edd2bb6  vmovaps [rsp+0xA0], xmm11
000074703edd2bbf  vmovaps [rsp+0xB0], xmm12
000074703edd2bc8  vmovaps [rsp+0xC0], xmm13
000074703edd2bd1  vmovaps [rsp+0xD0], xmm14
000074703edd2bda  vmovaps [rsp+0xE0], xmm15
000074703edd2be3  sub rsp, 0x30
000074703edd2be7  movaps [rsp], xmm5
000074703edd2beb  movaps [rsp+0x10], xmm2
000074703edd2bf0  movaps [rsp+0x20], xmm13
000074703edd2bf6  lea rdi, [rsp]
000074703edd2bfa  mov esi, 0x00
000074703edd2bff  mov rax, 0x5D9974CCC530
000074703edd2c09  call rax
000074703edd2c0b  movaps xmm5, [rsp]
000074703edd2c0f  add rsp, 0x30
000074703edd2c13  vmovaps xmm0, [rsp]
000074703edd2c18  vmovaps xmm1, [rsp+0x10]
000074703edd2c1e  vmovaps xmm2, [rsp+0x20]
000074703edd2c24  vmovaps xmm3, [rsp+0x30]
000074703edd2c2a  vmovaps xmm4, [rsp+0x40]
000074703edd2c30  vmovaps xmm6, [rsp+0x50]
000074703edd2c36  vmovaps xmm7, [rsp+0x60]
000074703edd2c3c  vmovaps xmm8, [rsp+0x70]
000074703edd2c42  vmovaps xmm9, [rsp+0x80]
000074703edd2c4b  vmovaps xmm10, [rsp+0x90]
000074703edd2c54  vmovaps xmm11, [rsp+0xA0]
000074703edd2c5d  vmovaps xmm12, [rsp+0xB0]
000074703edd2c66  vmovaps xmm13, [rsp+0xC0]
000074703edd2c6f  vmovaps xmm14, [rsp+0xD0]
000074703edd2c78  vmovaps xmm15, [rsp+0xE0]
000074703edd2c81  add rsp, 0xF0
000074703edd2c88  pop r11
000074703edd2c8a  pop r10
000074703edd2c8c  pop r9
000074703edd2c8e  pop r8
000074703edd2c90  pop rsi
000074703edd2c91  pop rdi
000074703edd2c92  pop rdx
000074703edd2c93  pop rcx
000074703edd2c94  pop rax
000074703edd2c95  add rsp, 0x08
000074703edd2c99  jmp 0x000074703EDCFDEC
000074703edd2c9e  sub rsp, 0x08
000074703edd2ca2  push rax
000074703edd2ca3  push rcx
000074703edd2ca4  push rdx
000074703edd2ca5  push rdi
000074703edd2ca6  push rsi
000074703edd2ca7  push r8
000074703edd2ca9  push r9
000074703edd2cab  push r10
000074703edd2cad  push r11
000074703edd2caf  sub rsp, 0xF0
000074703edd2cb6  vmovaps [rsp], xmm0
000074703edd2cbb  vmovaps [rsp+0x10], xmm1
000074703edd2cc1  vmovaps [rsp+0x20], xmm2
000074703edd2cc7  vmovaps [rsp+0x30], xmm3
000074703edd2ccd  vmovaps [rsp+0x40], xmm4
000074703edd2cd3  vmovaps [rsp+0x50], xmm5
000074703edd2cd9  vmovaps [rsp+0x60], xmm6
000074703edd2cdf  vmovaps [rsp+0x70], xmm7
000074703edd2ce5  vmovaps [rsp+0x80], xmm8
000074703edd2cee  vmovaps [rsp+0x90], xmm9
000074703edd2cf7  vmovaps [rsp+0xA0], xmm10
000074703edd2d00  vmovaps [rsp+0xB0], xmm11
000074703edd2d09  vmovaps [rsp+0xC0], xmm12
000074703edd2d12  vmovaps [rsp+0xD0], xmm14
000074703edd2d1b  vmovaps [rsp+0xE0], xmm15
000074703edd2d24  sub rsp, 0x30
000074703edd2d28  movaps [rsp], xmm13
000074703edd2d2d  movaps [rsp+0x10], xmm10
000074703edd2d33  movaps [rsp+0x20], xmm1
000074703edd2d38  lea rdi, [rsp]
000074703edd2d3c  mov esi, 0x00
000074703edd2d41  mov rax, 0x5D9974CCC530
000074703edd2d4b  call rax
000074703edd2d4d  movaps xmm13, [rsp]
000074703edd2d52  add rsp, 0x30
000074703edd2d56  vmovaps xmm0, [rsp]
000074703edd2d5b  vmovaps xmm1, [rsp+0x10]
000074703edd2d61  vmovaps xmm2, [rsp+0x20]
000074703edd2d67  vmovaps xmm3, [rsp+0x30]
000074703edd2d6d  vmovaps xmm4, [rsp+0x40]
000074703edd2d73  vmovaps xmm5, [rsp+0x50]
000074703edd2d79  vmovaps xmm6, [rsp+0x60]
000074703edd2d7f  vmovaps xmm7, [rsp+0x70]
000074703edd2d85  vmovaps xmm8, [rsp+0x80]
000074703edd2d8e  vmovaps xmm9, [rsp+0x90]
000074703edd2d97  vmovaps xmm10, [rsp+0xA0]
000074703edd2da0  vmovaps xmm11, [rsp+0xB0]
000074703edd2da9  vmovaps xmm12, [rsp+0xC0]
000074703edd2db2  vmovaps xmm14, [rsp+0xD0]
000074703edd2dbb  vmovaps xmm15, [rsp+0xE0]
000074703edd2dc4  add rsp, 0xF0
000074703edd2dcb  pop r11
000074703edd2dcd  pop r10
000074703edd2dcf  pop r9
000074703edd2dd1  pop r8
000074703edd2dd3  pop rsi
000074703edd2dd4  pop rdi
000074703edd2dd5  pop rdx
000074703edd2dd6  pop rcx
000074703edd2dd7  pop rax
000074703edd2dd8  add rsp, 0x08
000074703edd2ddc  jmp 0x000074703EDCFE15
000074703edd2de1  sub rsp, 0x08
000074703edd2de5  push rax
000074703edd2de6  push rcx
000074703edd2de7  push rdx
000074703edd2de8  push rdi
000074703edd2de9  push rsi
000074703edd2dea  push r8
000074703edd2dec  push r9
000074703edd2dee  push r10
000074703edd2df0  push r11
000074703edd2df2  sub rsp, 0xF0
000074703edd2df9  vmovaps [rsp], xmm0
000074703edd2dfe  vmovaps [rsp+0x10], xmm2
000074703edd2e04  vmovaps [rsp+0x20], xmm3
000074703edd2e0a  vmovaps [rsp+0x30], xmm4
000074703edd2e10  vmovaps [rsp+0x40], xmm5
000074703edd2e16  vmovaps [rsp+0x50], xmm6
000074703edd2e1c  vmovaps [rsp+0x60], xmm7
000074703edd2e22  vmovaps [rsp+0x70], xmm8
000074703edd2e28  vmovaps [rsp+0x80], xmm9
000074703edd2e31  vmovaps [rsp+0x90], xmm10
000074703edd2e3a  vmovaps [rsp+0xA0], xmm11
000074703edd2e43  vmovaps [rsp+0xB0], xmm12
000074703edd2e4c  vmovaps [rsp+0xC0], xmm13
000074703edd2e55  vmovaps [rsp+0xD0], xmm14
000074703edd2e5e  vmovaps [rsp+0xE0], xmm15
000074703edd2e67  sub rsp, 0x30
000074703edd2e6b  movaps [rsp], xmm1
000074703edd2e6f  movaps [rsp+0x10], xmm15
000074703edd2e75  movaps [rsp+0x20], xmm10
000074703edd2e7b  lea rdi, [rsp]
000074703edd2e7f  mov esi, 0x00
000074703edd2e84  mov rax, 0x5D9974CCC530
000074703edd2e8e  call rax
000074703edd2e90  movaps xmm1, [rsp]
000074703edd2e94  add rsp, 0x30
000074703edd2e98  vmovaps xmm0, [rsp]
000074703edd2e9d  vmovaps xmm2, [rsp+0x10]
000074703edd2ea3  vmovaps xmm3, [rsp+0x20]
000074703edd2ea9  vmovaps xmm4, [rsp+0x30]
000074703edd2eaf  vmovaps xmm5, [rsp+0x40]
000074703edd2eb5  vmovaps xmm6, [rsp+0x50]
000074703edd2ebb  vmovaps xmm7, [rsp+0x60]
000074703edd2ec1  vmovaps xmm8, [rsp+0x70]
000074703edd2ec7  vmovaps xmm9, [rsp+0x80]
000074703edd2ed0  vmovaps xmm10, [rsp+0x90]
000074703edd2ed9  vmovaps xmm11, [rsp+0xA0]
000074703edd2ee2  vmovaps xmm12, [rsp+0xB0]
000074703edd2eeb  vmovaps xmm13, [rsp+0xC0]
000074703edd2ef4  vmovaps xmm14, [rsp+0xD0]
000074703edd2efd  vmovaps xmm15, [rsp+0xE0]
000074703edd2f06  add rsp, 0xF0
000074703edd2f0d  pop r11
000074703edd2f0f  pop r10
000074703edd2f11  pop r9
000074703edd2f13  pop r8
000074703edd2f15  pop rsi
000074703edd2f16  pop rdi
000074703edd2f17  pop rdx
000074703edd2f18  pop rcx
000074703edd2f19  pop rax
000074703edd2f1a  add rsp, 0x08
000074703edd2f1e  jmp 0x000074703EDCFE34
000074703edd2f23  sub rsp, 0x08
000074703edd2f27  push rax
000074703edd2f28  push rcx
000074703edd2f29  push rdx
000074703edd2f2a  push rdi
000074703edd2f2b  push rsi
000074703edd2f2c  push r8
000074703edd2f2e  push r9
000074703edd2f30  push r10
000074703edd2f32  push r11
000074703edd2f34  sub rsp, 0xF0
000074703edd2f3b  vmovaps [rsp], xmm0
000074703edd2f40  vmovaps [rsp+0x10], xmm1
000074703edd2f46  vmovaps [rsp+0x20], xmm2
000074703edd2f4c  vmovaps [rsp+0x30], xmm3
000074703edd2f52  vmovaps [rsp+0x40], xmm4
000074703edd2f58  vmovaps [rsp+0x50], xmm5
000074703edd2f5e  vmovaps [rsp+0x60], xmm6
000074703edd2f64  vmovaps [rsp+0x70], xmm7
000074703edd2f6a  vmovaps [rsp+0x80], xmm8
000074703edd2f73  vmovaps [rsp+0x90], xmm9
000074703edd2f7c  vmovaps [rsp+0xA0], xmm10
000074703edd2f85  vmovaps [rsp+0xB0], xmm11
000074703edd2f8e  vmovaps [rsp+0xC0], xmm12
000074703edd2f97  vmovaps [rsp+0xD0], xmm13
000074703edd2fa0  vmovaps [rsp+0xE0], xmm14
000074703edd2fa9  sub rsp, 0x30
000074703edd2fad  movaps [rsp], xmm15
000074703edd2fb2  movaps [rsp+0x10], xmm10
000074703edd2fb8  movaps [rsp+0x20], xmm11
000074703edd2fbe  lea rdi, [rsp]
000074703edd2fc2  mov esi, 0x00
000074703edd2fc7  mov rax, 0x5D9974CCC530
000074703edd2fd1  call rax
000074703edd2fd3  movaps xmm15, [rsp]
000074703edd2fd8  add rsp, 0x30
000074703edd2fdc  vmovaps xmm0, [rsp]
000074703edd2fe1  vmovaps xmm1, [rsp+0x10]
000074703edd2fe7  vmovaps xmm2, [rsp+0x20]
000074703edd2fed  vmovaps xmm3, [rsp+0x30]
000074703edd2ff3  vmovaps xmm4, [rsp+0x40]
000074703edd2ff9  vmovaps xmm5, [rsp+0x50]
000074703edd2fff  vmovaps xmm6, [rsp+0x60]
000074703edd3005  vmovaps xmm7, [rsp+0x70]
000074703edd300b  vmovaps xmm8, [rsp+0x80]
000074703edd3014  vmovaps xmm9, [rsp+0x90]
000074703edd301d  vmovaps xmm10, [rsp+0xA0]
000074703edd3026  vmovaps xmm11, [rsp+0xB0]
000074703edd302f  vmovaps xmm12, [rsp+0xC0]
000074703edd3038  vmovaps xmm13, [rsp+0xD0]
000074703edd3041  vmovaps xmm14, [rsp+0xE0]
000074703edd304a  add rsp, 0xF0
000074703edd3051  pop r11
000074703edd3053  pop r10
000074703edd3055  pop r9
000074703edd3057  pop r8
000074703edd3059  pop rsi
000074703edd305a  pop rdi
000074703edd305b  pop rdx
000074703edd305c  pop rcx
000074703edd305d  pop rax
000074703edd305e  add rsp, 0x08
000074703edd3062  jmp 0x000074703EDCFE57
000074703edd3067  sub rsp, 0x08
000074703edd306b  push rax
000074703edd306c  push rcx
000074703edd306d  push rdx
000074703edd306e  push rdi
000074703edd306f  push rsi
000074703edd3070  push r8
000074703edd3072  push r9
000074703edd3074  push r10
000074703edd3076  push r11
000074703edd3078  sub rsp, 0xF0
000074703edd307f  vmovaps [rsp], xmm0
000074703edd3084  vmovaps [rsp+0x10], xmm1
000074703edd308a  vmovaps [rsp+0x20], xmm2
000074703edd3090  vmovaps [rsp+0x30], xmm3
000074703edd3096  vmovaps [rsp+0x40], xmm4
000074703edd309c  vmovaps [rsp+0x50], xmm5
000074703edd30a2  vmovaps [rsp+0x60], xmm6
000074703edd30a8  vmovaps [rsp+0x70], xmm7
000074703edd30ae  vmovaps [rsp+0x80], xmm8
000074703edd30b7  vmovaps [rsp+0x90], xmm9
000074703edd30c0  vmovaps [rsp+0xA0], xmm11
000074703edd30c9  vmovaps [rsp+0xB0], xmm12
000074703edd30d2  vmovaps [rsp+0xC0], xmm13
000074703edd30db  vmovaps [rsp+0xD0], xmm14
000074703edd30e4  vmovaps [rsp+0xE0], xmm15
000074703edd30ed  sub rsp, 0x30
000074703edd30f1  movaps [rsp], xmm10
000074703edd30f6  movaps [rsp+0x10], xmm12
000074703edd30fc  movaps [rsp+0x20], xmm11
000074703edd3102  lea rdi, [rsp]
000074703edd3106  mov esi, 0x00
000074703edd310b  mov rax, 0x5D9974CCC530
000074703edd3115  call rax
000074703edd3117  movaps xmm10, [rsp]
000074703edd311c  add rsp, 0x30
000074703edd3120  vmovaps xmm0, [rsp]
000074703edd3125  vmovaps xmm1, [rsp+0x10]
000074703edd312b  vmovaps xmm2, [rsp+0x20]
000074703edd3131  vmovaps xmm3, [rsp+0x30]
000074703edd3137  vmovaps xmm4, [rsp+0x40]
000074703edd313d  vmovaps xmm5, [rsp+0x50]
000074703edd3143  vmovaps xmm6, [rsp+0x60]
000074703edd3149  vmovaps xmm7, [rsp+0x70]
000074703edd314f  vmovaps xmm8, [rsp+0x80]
000074703edd3158  vmovaps xmm9, [rsp+0x90]
000074703edd3161  vmovaps xmm11, [rsp+0xA0]
000074703edd316a  vmovaps xmm12, [rsp+0xB0]
000074703edd3173  vmovaps xmm13, [rsp+0xC0]
000074703edd317c  vmovaps xmm14, [rsp+0xD0]
000074703edd3185  vmovaps xmm15, [rsp+0xE0]
000074703edd318e  add rsp, 0xF0
000074703edd3195  pop r11
000074703edd3197  pop r10
000074703edd3199  pop r9
000074703edd319b  pop r8
000074703edd319d  pop rsi
000074703edd319e  pop rdi
000074703edd319f  pop rdx
000074703edd31a0  pop rcx
000074703edd31a1  pop rax
000074703edd31a2  add rsp, 0x08
000074703edd31a6  jmp 0x000074703EDCFE80
000074703edd31ab  sub rsp, 0x08
000074703edd31af  push rax
000074703edd31b0  push rcx
000074703edd31b1  push rdx
000074703edd31b2  push rdi
000074703edd31b3  push rsi
000074703edd31b4  push r8
000074703edd31b6  push r9
000074703edd31b8  push r10
000074703edd31ba  push r11
000074703edd31bc  sub rsp, 0xF0
000074703edd31c3  vmovaps [rsp], xmm0
000074703edd31c8  vmovaps [rsp+0x10], xmm1
000074703edd31ce  vmovaps [rsp+0x20], xmm2
000074703edd31d4  vmovaps [rsp+0x30], xmm3
000074703edd31da  vmovaps [rsp+0x40], xmm4
000074703edd31e0  vmovaps [rsp+0x50], xmm5
000074703edd31e6  vmovaps [rsp+0x60], xmm6
000074703edd31ec  vmovaps [rsp+0x70], xmm7
000074703edd31f2  vmovaps [rsp+0x80], xmm8
000074703edd31fb  vmovaps [rsp+0x90], xmm9
000074703edd3204  vmovaps [rsp+0xA0], xmm10
000074703edd320d  vmovaps [rsp+0xB0], xmm12
000074703edd3216  vmovaps [rsp+0xC0], xmm13
000074703edd321f  vmovaps [rsp+0xD0], xmm14
000074703edd3228  vmovaps [rsp+0xE0], xmm15
000074703edd3231  sub rsp, 0x30
000074703edd3235  movaps [rsp], xmm11
000074703edd323a  movaps [rsp+0x10], xmm2
000074703edd323f  movaps [rsp+0x20], xmm12
000074703edd3245  lea rdi, [rsp]
000074703edd3249  mov esi, 0x00
000074703edd324e  mov rax, 0x5D9974CCC530
000074703edd3258  call rax
000074703edd325a  movaps xmm11, [rsp]
000074703edd325f  add rsp, 0x30
000074703edd3263  vmovaps xmm0, [rsp]
000074703edd3268  vmovaps xmm1, [rsp+0x10]
000074703edd326e  vmovaps xmm2, [rsp+0x20]
000074703edd3274  vmovaps xmm3, [rsp+0x30]
000074703edd327a  vmovaps xmm4, [rsp+0x40]
000074703edd3280  vmovaps xmm5, [rsp+0x50]
000074703edd3286  vmovaps xmm6, [rsp+0x60]
000074703edd328c  vmovaps xmm7, [rsp+0x70]
000074703edd3292  vmovaps xmm8, [rsp+0x80]
000074703edd329b  vmovaps xmm9, [rsp+0x90]
000074703edd32a4  vmovaps xmm10, [rsp+0xA0]
000074703edd32ad  vmovaps xmm12, [rsp+0xB0]
000074703edd32b6  vmovaps xmm13, [rsp+0xC0]
000074703edd32bf  vmovaps xmm14, [rsp+0xD0]
000074703edd32c8  vmovaps xmm15, [rsp+0xE0]
000074703edd32d1  add rsp, 0xF0
000074703edd32d8  pop r11
000074703edd32da  pop r10
000074703edd32dc  pop r9
000074703edd32de  pop r8
000074703edd32e0  pop rsi
000074703edd32e1  pop rdi
000074703edd32e2  pop rdx
000074703edd32e3  pop rcx
000074703edd32e4  pop rax
000074703edd32e5  add rsp, 0x08
000074703edd32e9  jmp 0x000074703EDCFEB8
000074703edd32ee  sub rsp, 0x08
000074703edd32f2  push rax
000074703edd32f3  push rcx
000074703edd32f4  push rdx
000074703edd32f5  push rdi
000074703edd32f6  push rsi
000074703edd32f7  push r8
000074703edd32f9  push r9
000074703edd32fb  push r10
000074703edd32fd  push r11
000074703edd32ff  sub rsp, 0xF0
000074703edd3306  vmovaps [rsp], xmm0
000074703edd330b  vmovaps [rsp+0x10], xmm2
000074703edd3311  vmovaps [rsp+0x20], xmm3
000074703edd3317  vmovaps [rsp+0x30], xmm4
000074703edd331d  vmovaps [rsp+0x40], xmm5
000074703edd3323  vmovaps [rsp+0x50], xmm6
000074703edd3329  vmovaps [rsp+0x60], xmm7
000074703edd332f  vmovaps [rsp+0x70], xmm8
000074703edd3335  vmovaps [rsp+0x80], xmm9
000074703edd333e  vmovaps [rsp+0x90], xmm10
000074703edd3347  vmovaps [rsp+0xA0], xmm11
000074703edd3350  vmovaps [rsp+0xB0], xmm12
000074703edd3359  vmovaps [rsp+0xC0], xmm13
000074703edd3362  vmovaps [rsp+0xD0], xmm14
000074703edd336b  vmovaps [rsp+0xE0], xmm15
000074703edd3374  sub rsp, 0x30
000074703edd3378  movaps [rsp], xmm1
000074703edd337c  movaps [rsp+0x10], xmm14
000074703edd3382  movaps [rsp+0x20], xmm6
000074703edd3387  lea rdi, [rsp]
000074703edd338b  mov esi, 0x00
000074703edd3390  mov rax, 0x5D9974CCC530
000074703edd339a  call rax
000074703edd339c  movaps xmm1, [rsp]
000074703edd33a0  add rsp, 0x30
000074703edd33a4  vmovaps xmm0, [rsp]
000074703edd33a9  vmovaps xmm2, [rsp+0x10]
000074703edd33af  vmovaps xmm3, [rsp+0x20]
000074703edd33b5  vmovaps xmm4, [rsp+0x30]
000074703edd33bb  vmovaps xmm5, [rsp+0x40]
000074703edd33c1  vmovaps xmm6, [rsp+0x50]
000074703edd33c7  vmovaps xmm7, [rsp+0x60]
000074703edd33cd  vmovaps xmm8, [rsp+0x70]
000074703edd33d3  vmovaps xmm9, [rsp+0x80]
000074703edd33dc  vmovaps xmm10, [rsp+0x90]
000074703edd33e5  vmovaps xmm11, [rsp+0xA0]
000074703edd33ee  vmovaps xmm12, [rsp+0xB0]
000074703edd33f7  vmovaps xmm13, [rsp+0xC0]
000074703edd3400  vmovaps xmm14, [rsp+0xD0]
000074703edd3409  vmovaps xmm15, [rsp+0xE0]
000074703edd3412  add rsp, 0xF0
000074703edd3419  pop r11
000074703edd341b  pop r10
000074703edd341d  pop r9
000074703edd341f  pop r8
000074703edd3421  pop rsi
000074703edd3422  pop rdi
000074703edd3423  pop rdx
000074703edd3424  pop rcx
000074703edd3425  pop rax
000074703edd3426  add rsp, 0x08
000074703edd342a  jmp 0x000074703EDCFED1
000074703edd342f  sub rsp, 0x08
000074703edd3433  push rax
000074703edd3434  push rcx
000074703edd3435  push rdx
000074703edd3436  push rdi
000074703edd3437  push rsi
000074703edd3438  push r8
000074703edd343a  push r9
000074703edd343c  push r10
000074703edd343e  push r11
000074703edd3440  sub rsp, 0xF0
000074703edd3447  vmovaps [rsp], xmm0
000074703edd344c  vmovaps [rsp+0x10], xmm1
000074703edd3452  vmovaps [rsp+0x20], xmm2
000074703edd3458  vmovaps [rsp+0x30], xmm3
000074703edd345e  vmovaps [rsp+0x40], xmm4
000074703edd3464  vmovaps [rsp+0x50], xmm5
000074703edd346a  vmovaps [rsp+0x60], xmm6
000074703edd3470  vmovaps [rsp+0x70], xmm7
000074703edd3476  vmovaps [rsp+0x80], xmm8
000074703edd347f  vmovaps [rsp+0x90], xmm9
000074703edd3488  vmovaps [rsp+0xA0], xmm10
000074703edd3491  vmovaps [rsp+0xB0], xmm11
000074703edd349a  vmovaps [rsp+0xC0], xmm12
000074703edd34a3  vmovaps [rsp+0xD0], xmm13
000074703edd34ac  vmovaps [rsp+0xE0], xmm15
000074703edd34b5  sub rsp, 0x30
000074703edd34b9  movaps [rsp], xmm14
000074703edd34be  movaps [rsp+0x10], xmm12
000074703edd34c4  movaps [rsp+0x20], xmm5
000074703edd34c9  lea rdi, [rsp]
000074703edd34cd  mov esi, 0x00
000074703edd34d2  mov rax, 0x5D9974CCC530
000074703edd34dc  call rax
000074703edd34de  movaps xmm14, [rsp]
000074703edd34e3  add rsp, 0x30
000074703edd34e7  vmovaps xmm0, [rsp]
000074703edd34ec  vmovaps xmm1, [rsp+0x10]
000074703edd34f2  vmovaps xmm2, [rsp+0x20]
000074703edd34f8  vmovaps xmm3, [rsp+0x30]
000074703edd34fe  vmovaps xmm4, [rsp+0x40]
000074703edd3504  vmovaps xmm5, [rsp+0x50]
000074703edd350a  vmovaps xmm6, [rsp+0x60]
000074703edd3510  vmovaps xmm7, [rsp+0x70]
000074703edd3516  vmovaps xmm8, [rsp+0x80]
000074703edd351f  vmovaps xmm9, [rsp+0x90]
000074703edd3528  vmovaps xmm10, [rsp+0xA0]
000074703edd3531  vmovaps xmm11, [rsp+0xB0]
000074703edd353a  vmovaps xmm12, [rsp+0xC0]
000074703edd3543  vmovaps xmm13, [rsp+0xD0]
000074703edd354c  vmovaps xmm15, [rsp+0xE0]
000074703edd3555  add rsp, 0xF0
000074703edd355c  pop r11
000074703edd355e  pop r10
000074703edd3560  pop r9
000074703edd3562  pop r8
000074703edd3564  pop rsi
000074703edd3565  pop rdi
000074703edd3566  pop rdx
000074703edd3567  pop rcx
000074703edd3568  pop rax
000074703edd3569  add rsp, 0x08
000074703edd356d  jmp 0x000074703EDCFEF1
000074703edd3572  sub rsp, 0x08
000074703edd3576  push rax
000074703edd3577  push rcx
000074703edd3578  push rdx
000074703edd3579  push rdi
000074703edd357a  push rsi
000074703edd357b  push r8
000074703edd357d  push r9
000074703edd357f  push r10
000074703edd3581  push r11
000074703edd3583  sub rsp, 0xF0
000074703edd358a  vmovaps [rsp], xmm0
000074703edd358f  vmovaps [rsp+0x10], xmm1
000074703edd3595  vmovaps [rsp+0x20], xmm2
000074703edd359b  vmovaps [rsp+0x30], xmm3
000074703edd35a1  vmovaps [rsp+0x40], xmm4
000074703edd35a7  vmovaps [rsp+0x50], xmm5
000074703edd35ad  vmovaps [rsp+0x60], xmm7
000074703edd35b3  vmovaps [rsp+0x70], xmm8
000074703edd35b9  vmovaps [rsp+0x80], xmm9
000074703edd35c2  vmovaps [rsp+0x90], xmm10
000074703edd35cb  vmovaps [rsp+0xA0], xmm11
000074703edd35d4  vmovaps [rsp+0xB0], xmm12
000074703edd35dd  vmovaps [rsp+0xC0], xmm13
000074703edd35e6  vmovaps [rsp+0xD0], xmm14
000074703edd35ef  vmovaps [rsp+0xE0], xmm15
000074703edd35f8  sub rsp, 0x30
000074703edd35fc  movaps [rsp], xmm6
000074703edd3600  movaps [rsp+0x10], xmm9
000074703edd3606  movaps [rsp+0x20], xmm12
000074703edd360c  lea rdi, [rsp]
000074703edd3610  mov esi, 0x00
000074703edd3615  mov rax, 0x5D9974CCC530
000074703edd361f  call rax
000074703edd3621  movaps xmm6, [rsp]
000074703edd3625  add rsp, 0x30
000074703edd3629  vmovaps xmm0, [rsp]
000074703edd362e  vmovaps xmm1, [rsp+0x10]
000074703edd3634  vmovaps xmm2, [rsp+0x20]
000074703edd363a  vmovaps xmm3, [rsp+0x30]
000074703edd3640  vmovaps xmm4, [rsp+0x40]
000074703edd3646  vmovaps xmm5, [rsp+0x50]
000074703edd364c  vmovaps xmm7, [rsp+0x60]
000074703edd3652  vmovaps xmm8, [rsp+0x70]
000074703edd3658  vmovaps xmm9, [rsp+0x80]
000074703edd3661  vmovaps xmm10, [rsp+0x90]
000074703edd366a  vmovaps xmm11, [rsp+0xA0]
000074703edd3673  vmovaps xmm12, [rsp+0xB0]
000074703edd367c  vmovaps xmm13, [rsp+0xC0]
000074703edd3685  vmovaps xmm14, [rsp+0xD0]
000074703edd368e  vmovaps xmm15, [rsp+0xE0]
000074703edd3697  add rsp, 0xF0
000074703edd369e  pop r11
000074703edd36a0  pop r10
000074703edd36a2  pop r9
000074703edd36a4  pop r8
000074703edd36a6  pop rsi
000074703edd36a7  pop rdi
000074703edd36a8  pop rdx
000074703edd36a9  pop rcx
000074703edd36aa  pop rax
000074703edd36ab  add rsp, 0x08
000074703edd36af  jmp 0x000074703EDCFF19
000074703edd36b4  sub rsp, 0x08
000074703edd36b8  push rax
000074703edd36b9  push rcx
000074703edd36ba  push rdx
000074703edd36bb  push rdi
000074703edd36bc  push rsi
000074703edd36bd  push r8
000074703edd36bf  push r9
000074703edd36c1  push r10
000074703edd36c3  push r11
000074703edd36c5  sub rsp, 0xF0
000074703edd36cc  vmovaps [rsp], xmm0
000074703edd36d1  vmovaps [rsp+0x10], xmm1
000074703edd36d7  vmovaps [rsp+0x20], xmm2
000074703edd36dd  vmovaps [rsp+0x30], xmm3
000074703edd36e3  vmovaps [rsp+0x40], xmm4
000074703edd36e9  vmovaps [rsp+0x50], xmm5
000074703edd36ef  vmovaps [rsp+0x60], xmm6
000074703edd36f5  vmovaps [rsp+0x70], xmm7
000074703edd36fb  vmovaps [rsp+0x80], xmm8
000074703edd3704  vmovaps [rsp+0x90], xmm9
000074703edd370d  vmovaps [rsp+0xA0], xmm10
000074703edd3716  vmovaps [rsp+0xB0], xmm11
000074703edd371f  vmovaps [rsp+0xC0], xmm13
000074703edd3728  vmovaps [rsp+0xD0], xmm14
000074703edd3731  vmovaps [rsp+0xE0], xmm15
000074703edd373a  sub rsp, 0x30
000074703edd373e  movaps [rsp], xmm12
000074703edd3743  movaps [rsp+0x10], xmm15
000074703edd3749  movaps [rsp+0x20], xmm13
000074703edd374f  lea rdi, [rsp]
000074703edd3753  mov esi, 0x00
000074703edd3758  mov rax, 0x5D9974CCC530
000074703edd3762  call rax
000074703edd3764  movaps xmm12, [rsp]
000074703edd3769  add rsp, 0x30
000074703edd376d  vmovaps xmm0, [rsp]
000074703edd3772  vmovaps xmm1, [rsp+0x10]
000074703edd3778  vmovaps xmm2, [rsp+0x20]
000074703edd377e  vmovaps xmm3, [rsp+0x30]
000074703edd3784  vmovaps xmm4, [rsp+0x40]
000074703edd378a  vmovaps xmm5, [rsp+0x50]
000074703edd3790  vmovaps xmm6, [rsp+0x60]
000074703edd3796  vmovaps xmm7, [rsp+0x70]
000074703edd379c  vmovaps xmm8, [rsp+0x80]
000074703edd37a5  vmovaps xmm9, [rsp+0x90]
000074703edd37ae  vmovaps xmm10, [rsp+0xA0]
000074703edd37b7  vmovaps xmm11, [rsp+0xB0]
000074703edd37c0  vmovaps xmm13, [rsp+0xC0]
000074703edd37c9  vmovaps xmm14, [rsp+0xD0]
000074703edd37d2  vmovaps xmm15, [rsp+0xE0]
000074703edd37db  add rsp, 0xF0
000074703edd37e2  pop r11
000074703edd37e4  pop r10
000074703edd37e6  pop r9
000074703edd37e8  pop r8
000074703edd37ea  pop rsi
000074703edd37eb  pop rdi
000074703edd37ec  pop rdx
000074703edd37ed  pop rcx
000074703edd37ee  pop rax
000074703edd37ef  add rsp, 0x08
000074703edd37f3  jmp 0x000074703EDCFF34
000074703edd37f8  sub rsp, 0x08
000074703edd37fc  push rax
000074703edd37fd  push rcx
000074703edd37fe  push rdx
000074703edd37ff  push rdi
000074703edd3800  push rsi
000074703edd3801  push r8
000074703edd3803  push r9
000074703edd3805  push r10
000074703edd3807  push r11
000074703edd3809  sub rsp, 0xF0
000074703edd3810  vmovaps [rsp], xmm0
000074703edd3815  vmovaps [rsp+0x10], xmm1
000074703edd381b  vmovaps [rsp+0x20], xmm2
000074703edd3821  vmovaps [rsp+0x30], xmm3
000074703edd3827  vmovaps [rsp+0x40], xmm4
000074703edd382d  vmovaps [rsp+0x50], xmm5
000074703edd3833  vmovaps [rsp+0x60], xmm6
000074703edd3839  vmovaps [rsp+0x70], xmm7
000074703edd383f  vmovaps [rsp+0x80], xmm8
000074703edd3848  vmovaps [rsp+0x90], xmm9
000074703edd3851  vmovaps [rsp+0xA0], xmm10
000074703edd385a  vmovaps [rsp+0xB0], xmm11
000074703edd3863  vmovaps [rsp+0xC0], xmm12
000074703edd386c  vmovaps [rsp+0xD0], xmm13
000074703edd3875  vmovaps [rsp+0xE0], xmm14
000074703edd387e  sub rsp, 0x30
000074703edd3882  movaps [rsp], xmm15
000074703edd3887  movaps [rsp+0x10], xmm13
000074703edd388d  movaps [rsp+0x20], xmm10
000074703edd3893  lea rdi, [rsp]
000074703edd3897  mov esi, 0x00
000074703edd389c  mov rax, 0x5D9974CCC530
000074703edd38a6  call rax
000074703edd38a8  movaps xmm15, [rsp]
000074703edd38ad  add rsp, 0x30
000074703edd38b1  vmovaps xmm0, [rsp]
000074703edd38b6  vmovaps xmm1, [rsp+0x10]
000074703edd38bc  vmovaps xmm2, [rsp+0x20]
000074703edd38c2  vmovaps xmm3, [rsp+0x30]
000074703edd38c8  vmovaps xmm4, [rsp+0x40]
000074703edd38ce  vmovaps xmm5, [rsp+0x50]
000074703edd38d4  vmovaps xmm6, [rsp+0x60]
000074703edd38da  vmovaps xmm7, [rsp+0x70]
000074703edd38e0  vmovaps xmm8, [rsp+0x80]
000074703edd38e9  vmovaps xmm9, [rsp+0x90]
000074703edd38f2  vmovaps xmm10, [rsp+0xA0]
000074703edd38fb  vmovaps xmm11, [rsp+0xB0]
000074703edd3904  vmovaps xmm12, [rsp+0xC0]
000074703edd390d  vmovaps xmm13, [rsp+0xD0]
000074703edd3916  vmovaps xmm14, [rsp+0xE0]
000074703edd391f  add rsp, 0xF0
000074703edd3926  pop r11
000074703edd3928  pop r10
000074703edd392a  pop r9
000074703edd392c  pop r8
000074703edd392e  pop rsi
000074703edd392f  pop rdi
000074703edd3930  pop rdx
000074703edd3931  pop rcx
000074703edd3932  pop rax
000074703edd3933  add rsp, 0x08
000074703edd3937  jmp 0x000074703EDCFF55
000074703edd393c  call 0x000074703EC0C260
000074703edd3941  jmp 0x000074703EDCFFB0
000074703edd3946  sub rsp, 0x08
000074703edd394a  push rax
000074703edd394b  push rcx
000074703edd394c  push rdx
000074703edd394d  push rdi
000074703edd394e  push rsi
000074703edd394f  push r8
000074703edd3951  push r9
000074703edd3953  push r10
000074703edd3955  push r11
000074703edd3957  sub rsp, 0xF0
000074703edd395e  vmovaps [rsp], xmm0
000074703edd3963  vmovaps [rsp+0x10], xmm1
000074703edd3969  vmovaps [rsp+0x20], xmm2
000074703edd396f  vmovaps [rsp+0x30], xmm3
000074703edd3975  vmovaps [rsp+0x40], xmm4
000074703edd397b  vmovaps [rsp+0x50], xmm5
000074703edd3981  vmovaps [rsp+0x60], xmm6
000074703edd3987  vmovaps [rsp+0x70], xmm7
000074703edd398d  vmovaps [rsp+0x80], xmm8
000074703edd3996  vmovaps [rsp+0x90], xmm10
000074703edd399f  vmovaps [rsp+0xA0], xmm11
000074703edd39a8  vmovaps [rsp+0xB0], xmm12
000074703edd39b1  vmovaps [rsp+0xC0], xmm13
000074703edd39ba  vmovaps [rsp+0xD0], xmm14
000074703edd39c3  vmovaps [rsp+0xE0], xmm15
000074703edd39cc  sub rsp, 0x30
000074703edd39d0  movaps [rsp], xmm9
000074703edd39d5  movaps [rsp+0x10], xmm8
000074703edd39db  movaps [rsp+0x20], xmm10
000074703edd39e1  lea rdi, [rsp]
000074703edd39e5  mov esi, 0x00
000074703edd39ea  mov rax, 0x5D9974CCC530
000074703edd39f4  call rax
000074703edd39f6  movaps xmm9, [rsp]
000074703edd39fb  add rsp, 0x30
000074703edd39ff  vmovaps xmm0, [rsp]
000074703edd3a04  vmovaps xmm1, [rsp+0x10]
000074703edd3a0a  vmovaps xmm2, [rsp+0x20]
000074703edd3a10  vmovaps xmm3, [rsp+0x30]
000074703edd3a16  vmovaps xmm4, [rsp+0x40]
000074703edd3a1c  vmovaps xmm5, [rsp+0x50]
000074703edd3a22  vmovaps xmm6, [rsp+0x60]
000074703edd3a28  vmovaps xmm7, [rsp+0x70]
000074703edd3a2e  vmovaps xmm8, [rsp+0x80]
000074703edd3a37  vmovaps xmm10, [rsp+0x90]
000074703edd3a40  vmovaps xmm11, [rsp+0xA0]
000074703edd3a49  vmovaps xmm12, [rsp+0xB0]
000074703edd3a52  vmovaps xmm13, [rsp+0xC0]
000074703edd3a5b  vmovaps xmm14, [rsp+0xD0]
000074703edd3a64  vmovaps xmm15, [rsp+0xE0]
000074703edd3a6d  add rsp, 0xF0
000074703edd3a74  pop r11
000074703edd3a76  pop r10
000074703edd3a78  pop r9
000074703edd3a7a  pop r8
000074703edd3a7c  pop rsi
000074703edd3a7d  pop rdi
000074703edd3a7e  pop rdx
000074703edd3a7f  pop rcx
000074703edd3a80  pop rax
000074703edd3a81  add rsp, 0x08
000074703edd3a85  jmp 0x000074703EDCFFE1
000074703edd3a8a  sub rsp, 0x08
000074703edd3a8e  push rax
000074703edd3a8f  push rcx
000074703edd3a90  push rdx
000074703edd3a91  push rdi
000074703edd3a92  push rsi
000074703edd3a93  push r8
000074703edd3a95  push r9
000074703edd3a97  push r10
000074703edd3a99  push r11
000074703edd3a9b  sub rsp, 0xF0
000074703edd3aa2  vmovaps [rsp], xmm0
000074703edd3aa7  vmovaps [rsp+0x10], xmm1
000074703edd3aad  vmovaps [rsp+0x20], xmm2
000074703edd3ab3  vmovaps [rsp+0x30], xmm3
000074703edd3ab9  vmovaps [rsp+0x40], xmm4
000074703edd3abf  vmovaps [rsp+0x50], xmm5
000074703edd3ac5  vmovaps [rsp+0x60], xmm6
000074703edd3acb  vmovaps [rsp+0x70], xmm7
000074703edd3ad1  vmovaps [rsp+0x80], xmm8
000074703edd3ada  vmovaps [rsp+0x90], xmm9
000074703edd3ae3  vmovaps [rsp+0xA0], xmm11
000074703edd3aec  vmovaps [rsp+0xB0], xmm12
000074703edd3af5  vmovaps [rsp+0xC0], xmm13
000074703edd3afe  vmovaps [rsp+0xD0], xmm14
000074703edd3b07  vmovaps [rsp+0xE0], xmm15
000074703edd3b10  sub rsp, 0x30
000074703edd3b14  movaps [rsp], xmm10
000074703edd3b19  movaps [rsp+0x10], xmm1
000074703edd3b1e  movaps [rsp+0x20], xmm11
000074703edd3b24  lea rdi, [rsp]
000074703edd3b28  mov esi, 0x00
000074703edd3b2d  mov rax, 0x5D9974CCC530
000074703edd3b37  call rax
000074703edd3b39  movaps xmm10, [rsp]
000074703edd3b3e  add rsp, 0x30
000074703edd3b42  vmovaps xmm0, [rsp]
000074703edd3b47  vmovaps xmm1, [rsp+0x10]
000074703edd3b4d  vmovaps xmm2, [rsp+0x20]
000074703edd3b53  vmovaps xmm3, [rsp+0x30]
000074703edd3b59  vmovaps xmm4, [rsp+0x40]
000074703edd3b5f  vmovaps xmm5, [rsp+0x50]
000074703edd3b65  vmovaps xmm6, [rsp+0x60]
000074703edd3b6b  vmovaps xmm7, [rsp+0x70]
000074703edd3b71  vmovaps xmm8, [rsp+0x80]
000074703edd3b7a  vmovaps xmm9, [rsp+0x90]
000074703edd3b83  vmovaps xmm11, [rsp+0xA0]
000074703edd3b8c  vmovaps xmm12, [rsp+0xB0]
000074703edd3b95  vmovaps xmm13, [rsp+0xC0]
000074703edd3b9e  vmovaps xmm14, [rsp+0xD0]
000074703edd3ba7  vmovaps xmm15, [rsp+0xE0]
000074703edd3bb0  add rsp, 0xF0
000074703edd3bb7  pop r11
000074703edd3bb9  pop r10
000074703edd3bbb  pop r9
000074703edd3bbd  pop r8
000074703edd3bbf  pop rsi
000074703edd3bc0  pop rdi
000074703edd3bc1  pop rdx
000074703edd3bc2  pop rcx
000074703edd3bc3  pop rax
000074703edd3bc4  add rsp, 0x08
000074703edd3bc8  jmp 0x000074703EDCFFFC
000074703edd3bcd  sub rsp, 0x08
000074703edd3bd1  push rax
000074703edd3bd2  push rcx
000074703edd3bd3  push rdx
000074703edd3bd4  push rdi
000074703edd3bd5  push rsi
000074703edd3bd6  push r8
000074703edd3bd8  push r9
000074703edd3bda  push r10
000074703edd3bdc  push r11
000074703edd3bde  sub rsp, 0xF0
000074703edd3be5  vmovaps [rsp], xmm0
000074703edd3bea  vmovaps [rsp+0x10], xmm2
000074703edd3bf0  vmovaps [rsp+0x20], xmm3
000074703edd3bf6  vmovaps [rsp+0x30], xmm4
000074703edd3bfc  vmovaps [rsp+0x40], xmm5
000074703edd3c02  vmovaps [rsp+0x50], xmm6
000074703edd3c08  vmovaps [rsp+0x60], xmm7
000074703edd3c0e  vmovaps [rsp+0x70], xmm8
000074703edd3c14  vmovaps [rsp+0x80], xmm9
000074703edd3c1d  vmovaps [rsp+0x90], xmm10
000074703edd3c26  vmovaps [rsp+0xA0], xmm11
000074703edd3c2f  vmovaps [rsp+0xB0], xmm12
000074703edd3c38  vmovaps [rsp+0xC0], xmm13
000074703edd3c41  vmovaps [rsp+0xD0], xmm14
000074703edd3c4a  vmovaps [rsp+0xE0], xmm15
000074703edd3c53  sub rsp, 0x30
000074703edd3c57  movaps [rsp], xmm1
000074703edd3c5b  movaps [rsp+0x10], xmm14
000074703edd3c61  movaps [rsp+0x20], xmm6
000074703edd3c66  lea rdi, [rsp]
000074703edd3c6a  mov esi, 0x00
000074703edd3c6f  mov rax, 0x5D9974CCC530
000074703edd3c79  call rax
000074703edd3c7b  movaps xmm1, [rsp]
000074703edd3c7f  add rsp, 0x30
000074703edd3c83  vmovaps xmm0, [rsp]
000074703edd3c88  vmovaps xmm2, [rsp+0x10]
000074703edd3c8e  vmovaps xmm3, [rsp+0x20]
000074703edd3c94  vmovaps xmm4, [rsp+0x30]
000074703edd3c9a  vmovaps xmm5, [rsp+0x40]
000074703edd3ca0  vmovaps xmm6, [rsp+0x50]
000074703edd3ca6  vmovaps xmm7, [rsp+0x60]
000074703edd3cac  vmovaps xmm8, [rsp+0x70]
000074703edd3cb2  vmovaps xmm9, [rsp+0x80]
000074703edd3cbb  vmovaps xmm10, [rsp+0x90]
000074703edd3cc4  vmovaps xmm11, [rsp+0xA0]
000074703edd3ccd  vmovaps xmm12, [rsp+0xB0]
000074703edd3cd6  vmovaps xmm13, [rsp+0xC0]
000074703edd3cdf  vmovaps xmm14, [rsp+0xD0]
000074703edd3ce8  vmovaps xmm15, [rsp+0xE0]
000074703edd3cf1  add rsp, 0xF0
000074703edd3cf8  pop r11
000074703edd3cfa  pop r10
000074703edd3cfc  pop r9
000074703edd3cfe  pop r8
000074703edd3d00  pop rsi
000074703edd3d01  pop rdi
000074703edd3d02  pop rdx
000074703edd3d03  pop rcx
000074703edd3d04  pop rax
000074703edd3d05  add rsp, 0x08
000074703edd3d09  jmp 0x000074703EDD0015
000074703edd3d0e  sub rsp, 0x08
000074703edd3d12  push rax
000074703edd3d13  push rcx
000074703edd3d14  push rdx
000074703edd3d15  push rdi
000074703edd3d16  push rsi
000074703edd3d17  push r8
000074703edd3d19  push r9
000074703edd3d1b  push r10
000074703edd3d1d  push r11
000074703edd3d1f  sub rsp, 0xF0
000074703edd3d26  vmovaps [rsp], xmm0
000074703edd3d2b  vmovaps [rsp+0x10], xmm1
000074703edd3d31  vmovaps [rsp+0x20], xmm2
000074703edd3d37  vmovaps [rsp+0x30], xmm3
000074703edd3d3d  vmovaps [rsp+0x40], xmm4
000074703edd3d43  vmovaps [rsp+0x50], xmm5
000074703edd3d49  vmovaps [rsp+0x60], xmm6
000074703edd3d4f  vmovaps [rsp+0x70], xmm7
000074703edd3d55  vmovaps [rsp+0x80], xmm8
000074703edd3d5e  vmovaps [rsp+0x90], xmm9
000074703edd3d67  vmovaps [rsp+0xA0], xmm10
000074703edd3d70  vmovaps [rsp+0xB0], xmm12
000074703edd3d79  vmovaps [rsp+0xC0], xmm13
000074703edd3d82  vmovaps [rsp+0xD0], xmm14
000074703edd3d8b  vmovaps [rsp+0xE0], xmm15
000074703edd3d94  sub rsp, 0x30
000074703edd3d98  movaps [rsp], xmm11
000074703edd3d9d  movaps [rsp+0x10], xmm13
000074703edd3da3  movaps [rsp+0x20], xmm14
000074703edd3da9  lea rdi, [rsp]
000074703edd3dad  mov esi, 0x00
000074703edd3db2  mov rax, 0x5D9974CCC530
000074703edd3dbc  call rax
000074703edd3dbe  movaps xmm11, [rsp]
000074703edd3dc3  add rsp, 0x30
000074703edd3dc7  vmovaps xmm0, [rsp]
000074703edd3dcc  vmovaps xmm1, [rsp+0x10]
000074703edd3dd2  vmovaps xmm2, [rsp+0x20]
000074703edd3dd8  vmovaps xmm3, [rsp+0x30]
000074703edd3dde  vmovaps xmm4, [rsp+0x40]
000074703edd3de4  vmovaps xmm5, [rsp+0x50]
000074703edd3dea  vmovaps xmm6, [rsp+0x60]
000074703edd3df0  vmovaps xmm7, [rsp+0x70]
000074703edd3df6  vmovaps xmm8, [rsp+0x80]
000074703edd3dff  vmovaps xmm9, [rsp+0x90]
000074703edd3e08  vmovaps xmm10, [rsp+0xA0]
000074703edd3e11  vmovaps xmm12, [rsp+0xB0]
000074703edd3e1a  vmovaps xmm13, [rsp+0xC0]
000074703edd3e23  vmovaps xmm14, [rsp+0xD0]
000074703edd3e2c  vmovaps xmm15, [rsp+0xE0]
000074703edd3e35  add rsp, 0xF0
000074703edd3e3c  pop r11
000074703edd3e3e  pop r10
000074703edd3e40  pop r9
000074703edd3e42  pop r8
000074703edd3e44  pop rsi
000074703edd3e45  pop rdi
000074703edd3e46  pop rdx
000074703edd3e47  pop rcx
000074703edd3e48  pop rax
000074703edd3e49  add rsp, 0x08
000074703edd3e4d  jmp 0x000074703EDD003F
000074703edd3e52  sub rsp, 0x08
000074703edd3e56  push rax
000074703edd3e57  push rcx
000074703edd3e58  push rdx
000074703edd3e59  push rdi
000074703edd3e5a  push rsi
000074703edd3e5b  push r8
000074703edd3e5d  push r9
000074703edd3e5f  push r10
000074703edd3e61  push r11
000074703edd3e63  sub rsp, 0xF0
000074703edd3e6a  vmovaps [rsp], xmm0
000074703edd3e6f  vmovaps [rsp+0x10], xmm1
000074703edd3e75  vmovaps [rsp+0x20], xmm2
000074703edd3e7b  vmovaps [rsp+0x30], xmm3
000074703edd3e81  vmovaps [rsp+0x40], xmm4
000074703edd3e87  vmovaps [rsp+0x50], xmm5
000074703edd3e8d  vmovaps [rsp+0x60], xmm6
000074703edd3e93  vmovaps [rsp+0x70], xmm7
000074703edd3e99  vmovaps [rsp+0x80], xmm8
000074703edd3ea2  vmovaps [rsp+0x90], xmm9
000074703edd3eab  vmovaps [rsp+0xA0], xmm10
000074703edd3eb4  vmovaps [rsp+0xB0], xmm11
000074703edd3ebd  vmovaps [rsp+0xC0], xmm12
000074703edd3ec6  vmovaps [rsp+0xD0], xmm14
000074703edd3ecf  vmovaps [rsp+0xE0], xmm15
000074703edd3ed8  sub rsp, 0x30
000074703edd3edc  movaps [rsp], xmm13
000074703edd3ee1  movaps [rsp+0x10], xmm8
000074703edd3ee7  movaps [rsp+0x20], xmm14
000074703edd3eed  lea rdi, [rsp]
000074703edd3ef1  mov esi, 0x00
000074703edd3ef6  mov rax, 0x5D9974CCC530
000074703edd3f00  call rax
000074703edd3f02  movaps xmm13, [rsp]
000074703edd3f07  add rsp, 0x30
000074703edd3f0b  vmovaps xmm0, [rsp]
000074703edd3f10  vmovaps xmm1, [rsp+0x10]
000074703edd3f16  vmovaps xmm2, [rsp+0x20]
000074703edd3f1c  vmovaps xmm3, [rsp+0x30]
000074703edd3f22  vmovaps xmm4, [rsp+0x40]
000074703edd3f28  vmovaps xmm5, [rsp+0x50]
000074703edd3f2e  vmovaps xmm6, [rsp+0x60]
000074703edd3f34  vmovaps xmm7, [rsp+0x70]
000074703edd3f3a  vmovaps xmm8, [rsp+0x80]
000074703edd3f43  vmovaps xmm9, [rsp+0x90]
000074703edd3f4c  vmovaps xmm10, [rsp+0xA0]
000074703edd3f55  vmovaps xmm11, [rsp+0xB0]
000074703edd3f5e  vmovaps xmm12, [rsp+0xC0]
000074703edd3f67  vmovaps xmm14, [rsp+0xD0]
000074703edd3f70  vmovaps xmm15, [rsp+0xE0]
000074703edd3f79  add rsp, 0xF0
000074703edd3f80  pop r11
000074703edd3f82  pop r10
000074703edd3f84  pop r9
000074703edd3f86  pop r8
000074703edd3f88  pop rsi
000074703edd3f89  pop rdi
000074703edd3f8a  pop rdx
000074703edd3f8b  pop rcx
000074703edd3f8c  pop rax
000074703edd3f8d  add rsp, 0x08
000074703edd3f91  jmp 0x000074703EDD006E
000074703edd3f96  sub rsp, 0x08
000074703edd3f9a  push rax
000074703edd3f9b  push rcx
000074703edd3f9c  push rdx
000074703edd3f9d  push rdi
000074703edd3f9e  push rsi
000074703edd3f9f  push r8
000074703edd3fa1  push r9
000074703edd3fa3  push r10
000074703edd3fa5  push r11
000074703edd3fa7  sub rsp, 0xF0
000074703edd3fae  vmovaps [rsp], xmm0
000074703edd3fb3  vmovaps [rsp+0x10], xmm1
000074703edd3fb9  vmovaps [rsp+0x20], xmm2
000074703edd3fbf  vmovaps [rsp+0x30], xmm3
000074703edd3fc5  vmovaps [rsp+0x40], xmm4
000074703edd3fcb  vmovaps [rsp+0x50], xmm5
000074703edd3fd1  vmovaps [rsp+0x60], xmm6
000074703edd3fd7  vmovaps [rsp+0x70], xmm7
000074703edd3fdd  vmovaps [rsp+0x80], xmm9
000074703edd3fe6  vmovaps [rsp+0x90], xmm10
000074703edd3fef  vmovaps [rsp+0xA0], xmm11
000074703edd3ff8  vmovaps [rsp+0xB0], xmm12
000074703edd4001  vmovaps [rsp+0xC0], xmm13
000074703edd400a  vmovaps [rsp+0xD0], xmm14
000074703edd4013  vmovaps [rsp+0xE0], xmm15
000074703edd401c  sub rsp, 0x30
000074703edd4020  movaps [rsp], xmm8
000074703edd4025  movaps [rsp+0x10], xmm7
000074703edd402a  movaps [rsp+0x20], xmm14
000074703edd4030  lea rdi, [rsp]
000074703edd4034  mov esi, 0x00
000074703edd4039  mov rax, 0x5D9974CCC530
000074703edd4043  call rax
000074703edd4045  movaps xmm8, [rsp]
000074703edd404a  add rsp, 0x30
000074703edd404e  vmovaps xmm0, [rsp]
000074703edd4053  vmovaps xmm1, [rsp+0x10]
000074703edd4059  vmovaps xmm2, [rsp+0x20]
000074703edd405f  vmovaps xmm3, [rsp+0x30]
000074703edd4065  vmovaps xmm4, [rsp+0x40]
000074703edd406b  vmovaps xmm5, [rsp+0x50]
000074703edd4071  vmovaps xmm6, [rsp+0x60]
000074703edd4077  vmovaps xmm7, [rsp+0x70]
000074703edd407d  vmovaps xmm9, [rsp+0x80]
000074703edd4086  vmovaps xmm10, [rsp+0x90]
000074703edd408f  vmovaps xmm11, [rsp+0xA0]
000074703edd4098  vmovaps xmm12, [rsp+0xB0]
000074703edd40a1  vmovaps xmm13, [rsp+0xC0]
000074703edd40aa  vmovaps xmm14, [rsp+0xD0]
000074703edd40b3  vmovaps xmm15, [rsp+0xE0]
000074703edd40bc  add rsp, 0xF0
000074703edd40c3  pop r11
000074703edd40c5  pop r10
000074703edd40c7  pop r9
000074703edd40c9  pop r8
000074703edd40cb  pop rsi
000074703edd40cc  pop rdi
000074703edd40cd  pop rdx
000074703edd40ce  pop rcx
000074703edd40cf  pop rax
000074703edd40d0  add rsp, 0x08
000074703edd40d4  jmp 0x000074703EDD0094
000074703edd40d9  sub rsp, 0x08
000074703edd40dd  push rax
000074703edd40de  push rcx
000074703edd40df  push rdx
000074703edd40e0  push rdi
000074703edd40e1  push rsi
000074703edd40e2  push r8
000074703edd40e4  push r9
000074703edd40e6  push r10
000074703edd40e8  push r11
000074703edd40ea  sub rsp, 0xF0
000074703edd40f1  vmovaps [rsp], xmm0
000074703edd40f6  vmovaps [rsp+0x10], xmm1
000074703edd40fc  vmovaps [rsp+0x20], xmm2
000074703edd4102  vmovaps [rsp+0x30], xmm3
000074703edd4108  vmovaps [rsp+0x40], xmm4
000074703edd410e  vmovaps [rsp+0x50], xmm5
000074703edd4114  vmovaps [rsp+0x60], xmm6
000074703edd411a  vmovaps [rsp+0x70], xmm7
000074703edd4120  vmovaps [rsp+0x80], xmm8
000074703edd4129  vmovaps [rsp+0x90], xmm9
000074703edd4132  vmovaps [rsp+0xA0], xmm10
000074703edd413b  vmovaps [rsp+0xB0], xmm11
000074703edd4144  vmovaps [rsp+0xC0], xmm12
000074703edd414d  vmovaps [rsp+0xD0], xmm13
000074703edd4156  vmovaps [rsp+0xE0], xmm15
000074703edd415f  sub rsp, 0x30
000074703edd4163  movaps [rsp], xmm14
000074703edd4168  movaps [rsp+0x10], xmm12
000074703edd416e  movaps [rsp+0x20], xmm9
000074703edd4174  lea rdi, [rsp]
000074703edd4178  mov esi, 0x00
000074703edd417d  mov rax, 0x5D9974CCC530
000074703edd4187  call rax
000074703edd4189  movaps xmm14, [rsp]
000074703edd418e  add rsp, 0x30
000074703edd4192  vmovaps xmm0, [rsp]
000074703edd4197  vmovaps xmm1, [rsp+0x10]
000074703edd419d  vmovaps xmm2, [rsp+0x20]
000074703edd41a3  vmovaps xmm3, [rsp+0x30]
000074703edd41a9  vmovaps xmm4, [rsp+0x40]
000074703edd41af  vmovaps xmm5, [rsp+0x50]
000074703edd41b5  vmovaps xmm6, [rsp+0x60]
000074703edd41bb  vmovaps xmm7, [rsp+0x70]
000074703edd41c1  vmovaps xmm8, [rsp+0x80]
000074703edd41ca  vmovaps xmm9, [rsp+0x90]
000074703edd41d3  vmovaps xmm10, [rsp+0xA0]
000074703edd41dc  vmovaps xmm11, [rsp+0xB0]
000074703edd41e5  vmovaps xmm12, [rsp+0xC0]
000074703edd41ee  vmovaps xmm13, [rsp+0xD0]
000074703edd41f7  vmovaps xmm15, [rsp+0xE0]
000074703edd4200  add rsp, 0xF0
000074703edd4207  pop r11
000074703edd4209  pop r10
000074703edd420b  pop r9
000074703edd420d  pop r8
000074703edd420f  pop rsi
000074703edd4210  pop rdi
000074703edd4211  pop rdx
000074703edd4212  pop rcx
000074703edd4213  pop rax
000074703edd4214  add rsp, 0x08
000074703edd4218  jmp 0x000074703EDD00AE
000074703edd421d  sub rsp, 0x08
000074703edd4221  push rax
000074703edd4222  push rcx
000074703edd4223  push rdx
000074703edd4224  push rdi
000074703edd4225  push rsi
000074703edd4226  push r8
000074703edd4228  push r9
000074703edd422a  push r10
000074703edd422c  push r11
000074703edd422e  sub rsp, 0xF0
000074703edd4235  vmovaps [rsp], xmm0
000074703edd423a  vmovaps [rsp+0x10], xmm1
000074703edd4240  vmovaps [rsp+0x20], xmm2
000074703edd4246  vmovaps [rsp+0x30], xmm3
000074703edd424c  vmovaps [rsp+0x40], xmm4
000074703edd4252  vmovaps [rsp+0x50], xmm5
000074703edd4258  vmovaps [rsp+0x60], xmm6
000074703edd425e  vmovaps [rsp+0x70], xmm7
000074703edd4264  vmovaps [rsp+0x80], xmm8
000074703edd426d  vmovaps [rsp+0x90], xmm10
000074703edd4276  vmovaps [rsp+0xA0], xmm11
000074703edd427f  vmovaps [rsp+0xB0], xmm12
000074703edd4288  vmovaps [rsp+0xC0], xmm13
000074703edd4291  vmovaps [rsp+0xD0], xmm14
000074703edd429a  vmovaps [rsp+0xE0], xmm15
000074703edd42a3  sub rsp, 0x30
000074703edd42a7  movaps [rsp], xmm9
000074703edd42ac  movaps [rsp+0x10], xmm7
000074703edd42b1  movaps [rsp+0x20], xmm12
000074703edd42b7  lea rdi, [rsp]
000074703edd42bb  mov esi, 0x00
000074703edd42c0  mov rax, 0x5D9974CCC530
000074703edd42ca  call rax
000074703edd42cc  movaps xmm9, [rsp]
000074703edd42d1  add rsp, 0x30
000074703edd42d5  vmovaps xmm0, [rsp]
000074703edd42da  vmovaps xmm1, [rsp+0x10]
000074703edd42e0  vmovaps xmm2, [rsp+0x20]
000074703edd42e6  vmovaps xmm3, [rsp+0x30]
000074703edd42ec  vmovaps xmm4, [rsp+0x40]
000074703edd42f2  vmovaps xmm5, [rsp+0x50]
000074703edd42f8  vmovaps xmm6, [rsp+0x60]
000074703edd42fe  vmovaps xmm7, [rsp+0x70]
000074703edd4304  vmovaps xmm8, [rsp+0x80]
000074703edd430d  vmovaps xmm10, [rsp+0x90]
000074703edd4316  vmovaps xmm11, [rsp+0xA0]
000074703edd431f  vmovaps xmm12, [rsp+0xB0]
000074703edd4328  vmovaps xmm13, [rsp+0xC0]
000074703edd4331  vmovaps xmm14, [rsp+0xD0]
000074703edd433a  vmovaps xmm15, [rsp+0xE0]
000074703edd4343  add rsp, 0xF0
000074703edd434a  pop r11
000074703edd434c  pop r10
000074703edd434e  pop r9
000074703edd4350  pop r8
000074703edd4352  pop rsi
000074703edd4353  pop rdi
000074703edd4354  pop rdx
000074703edd4355  pop rcx
000074703edd4356  pop rax
000074703edd4357  add rsp, 0x08
000074703edd435b  jmp 0x000074703EDD00DD
000074703edd4360  sub rsp, 0x08
000074703edd4364  push rax
000074703edd4365  push rcx
000074703edd4366  push rdx
000074703edd4367  push rdi
000074703edd4368  push rsi
000074703edd4369  push r8
000074703edd436b  push r9
000074703edd436d  push r10
000074703edd436f  push r11
000074703edd4371  sub rsp, 0xF0
000074703edd4378  vmovaps [rsp], xmm0
000074703edd437d  vmovaps [rsp+0x10], xmm1
000074703edd4383  vmovaps [rsp+0x20], xmm2
000074703edd4389  vmovaps [rsp+0x30], xmm3
000074703edd438f  vmovaps [rsp+0x40], xmm4
000074703edd4395  vmovaps [rsp+0x50], xmm5
000074703edd439b  vmovaps [rsp+0x60], xmm6
000074703edd43a1  vmovaps [rsp+0x70], xmm7
000074703edd43a7  vmovaps [rsp+0x80], xmm8
000074703edd43b0  vmovaps [rsp+0x90], xmm9
000074703edd43b9  vmovaps [rsp+0xA0], xmm10
000074703edd43c2  vmovaps [rsp+0xB0], xmm11
000074703edd43cb  vmovaps [rsp+0xC0], xmm13
000074703edd43d4  vmovaps [rsp+0xD0], xmm14
000074703edd43dd  vmovaps [rsp+0xE0], xmm15
000074703edd43e6  sub rsp, 0x30
000074703edd43ea  movaps [rsp], xmm12
000074703edd43ef  movaps [rsp+0x10], xmm15
000074703edd43f5  movaps [rsp+0x20], xmm11
000074703edd43fb  lea rdi, [rsp]
000074703edd43ff  mov esi, 0x00
000074703edd4404  mov rax, 0x5D9974CCC530
000074703edd440e  call rax
000074703edd4410  movaps xmm12, [rsp]
000074703edd4415  add rsp, 0x30
000074703edd4419  vmovaps xmm0, [rsp]
000074703edd441e  vmovaps xmm1, [rsp+0x10]
000074703edd4424  vmovaps xmm2, [rsp+0x20]
000074703edd442a  vmovaps xmm3, [rsp+0x30]
000074703edd4430  vmovaps xmm4, [rsp+0x40]
000074703edd4436  vmovaps xmm5, [rsp+0x50]
000074703edd443c  vmovaps xmm6, [rsp+0x60]
000074703edd4442  vmovaps xmm7, [rsp+0x70]
000074703edd4448  vmovaps xmm8, [rsp+0x80]
000074703edd4451  vmovaps xmm9, [rsp+0x90]
000074703edd445a  vmovaps xmm10, [rsp+0xA0]
000074703edd4463  vmovaps xmm11, [rsp+0xB0]
000074703edd446c  vmovaps xmm13, [rsp+0xC0]
000074703edd4475  vmovaps xmm14, [rsp+0xD0]
000074703edd447e  vmovaps xmm15, [rsp+0xE0]
000074703edd4487  add rsp, 0xF0
000074703edd448e  pop r11
000074703edd4490  pop r10
000074703edd4492  pop r9
000074703edd4494  pop r8
000074703edd4496  pop rsi
000074703edd4497  pop rdi
000074703edd4498  pop rdx
000074703edd4499  pop rcx
000074703edd449a  pop rax
000074703edd449b  add rsp, 0x08
000074703edd449f  jmp 0x000074703EDD00F7
000074703edd44a4  sub rsp, 0x08
000074703edd44a8  push rax
000074703edd44a9  push rcx
000074703edd44aa  push rdx
000074703edd44ab  push rdi
000074703edd44ac  push rsi
000074703edd44ad  push r8
000074703edd44af  push r9
000074703edd44b1  push r10
000074703edd44b3  push r11
000074703edd44b5  sub rsp, 0xF0
000074703edd44bc  vmovaps [rsp], xmm0
000074703edd44c1  vmovaps [rsp+0x10], xmm1
000074703edd44c7  vmovaps [rsp+0x20], xmm2
000074703edd44cd  vmovaps [rsp+0x30], xmm3
000074703edd44d3  vmovaps [rsp+0x40], xmm4
000074703edd44d9  vmovaps [rsp+0x50], xmm5
000074703edd44df  vmovaps [rsp+0x60], xmm6
000074703edd44e5  vmovaps [rsp+0x70], xmm7
000074703edd44eb  vmovaps [rsp+0x80], xmm8
000074703edd44f4  vmovaps [rsp+0x90], xmm9
000074703edd44fd  vmovaps [rsp+0xA0], xmm10
000074703edd4506  vmovaps [rsp+0xB0], xmm12
000074703edd450f  vmovaps [rsp+0xC0], xmm13
000074703edd4518  vmovaps [rsp+0xD0], xmm14
000074703edd4521  vmovaps [rsp+0xE0], xmm15
000074703edd452a  sub rsp, 0x30
000074703edd452e  movaps [rsp], xmm11
000074703edd4533  movaps [rsp+0x10], xmm7
000074703edd4538  movaps [rsp+0x20], xmm15
000074703edd453e  lea rdi, [rsp]
000074703edd4542  mov esi, 0x00
000074703edd4547  mov rax, 0x5D9974CCC530
000074703edd4551  call rax
000074703edd4553  movaps xmm11, [rsp]
000074703edd4558  add rsp, 0x30
000074703edd455c  vmovaps xmm0, [rsp]
000074703edd4561  vmovaps xmm1, [rsp+0x10]
000074703edd4567  vmovaps xmm2, [rsp+0x20]
000074703edd456d  vmovaps xmm3, [rsp+0x30]
000074703edd4573  vmovaps xmm4, [rsp+0x40]
000074703edd4579  vmovaps xmm5, [rsp+0x50]
000074703edd457f  vmovaps xmm6, [rsp+0x60]
000074703edd4585  vmovaps xmm7, [rsp+0x70]
000074703edd458b  vmovaps xmm8, [rsp+0x80]
000074703edd4594  vmovaps xmm9, [rsp+0x90]
000074703edd459d  vmovaps xmm10, [rsp+0xA0]
000074703edd45a6  vmovaps xmm12, [rsp+0xB0]
000074703edd45af  vmovaps xmm13, [rsp+0xC0]
000074703edd45b8  vmovaps xmm14, [rsp+0xD0]
000074703edd45c1  vmovaps xmm15, [rsp+0xE0]
000074703edd45ca  add rsp, 0xF0
000074703edd45d1  pop r11
000074703edd45d3  pop r10
000074703edd45d5  pop r9
000074703edd45d7  pop r8
000074703edd45d9  pop rsi
000074703edd45da  pop rdi
000074703edd45db  pop rdx
000074703edd45dc  pop rcx
000074703edd45dd  pop rax
000074703edd45de  add rsp, 0x08
000074703edd45e2  jmp 0x000074703EDD0123
000074703edd45e7  sub rsp, 0x08
000074703edd45eb  push rax
000074703edd45ec  push rcx
000074703edd45ed  push rdx
000074703edd45ee  push rdi
000074703edd45ef  push rsi
000074703edd45f0  push r8
000074703edd45f2  push r9
000074703edd45f4  push r10
000074703edd45f6  push r11
000074703edd45f8  sub rsp, 0xF0
000074703edd45ff  vmovaps [rsp], xmm0
000074703edd4604  vmovaps [rsp+0x10], xmm1
000074703edd460a  vmovaps [rsp+0x20], xmm2
000074703edd4610  vmovaps [rsp+0x30], xmm3
000074703edd4616  vmovaps [rsp+0x40], xmm4
000074703edd461c  vmovaps [rsp+0x50], xmm5
000074703edd4622  vmovaps [rsp+0x60], xmm6
000074703edd4628  vmovaps [rsp+0x70], xmm7
000074703edd462e  vmovaps [rsp+0x80], xmm8
000074703edd4637  vmovaps [rsp+0x90], xmm9
000074703edd4640  vmovaps [rsp+0xA0], xmm10
000074703edd4649  vmovaps [rsp+0xB0], xmm11
000074703edd4652  vmovaps [rsp+0xC0], xmm12
000074703edd465b  vmovaps [rsp+0xD0], xmm13
000074703edd4664  vmovaps [rsp+0xE0], xmm14
000074703edd466d  sub rsp, 0x30
000074703edd4671  movaps [rsp], xmm15
000074703edd4676  movaps [rsp+0x10], xmm10
000074703edd467c  movaps [rsp+0x20], xmm13
000074703edd4682  lea rdi, [rsp]
000074703edd4686  mov esi, 0x00
000074703edd468b  mov rax, 0x5D9974CCC530
000074703edd4695  call rax
000074703edd4697  movaps xmm15, [rsp]
000074703edd469c  add rsp, 0x30
000074703edd46a0  vmovaps xmm0, [rsp]
000074703edd46a5  vmovaps xmm1, [rsp+0x10]
000074703edd46ab  vmovaps xmm2, [rsp+0x20]
000074703edd46b1  vmovaps xmm3, [rsp+0x30]
000074703edd46b7  vmovaps xmm4, [rsp+0x40]
000074703edd46bd  vmovaps xmm5, [rsp+0x50]
000074703edd46c3  vmovaps xmm6, [rsp+0x60]
000074703edd46c9  vmovaps xmm7, [rsp+0x70]
000074703edd46cf  vmovaps xmm8, [rsp+0x80]
000074703edd46d8  vmovaps xmm9, [rsp+0x90]
000074703edd46e1  vmovaps xmm10, [rsp+0xA0]
000074703edd46ea  vmovaps xmm11, [rsp+0xB0]
000074703edd46f3  vmovaps xmm12, [rsp+0xC0]
000074703edd46fc  vmovaps xmm13, [rsp+0xD0]
000074703edd4705  vmovaps xmm14, [rsp+0xE0]
000074703edd470e  add rsp, 0xF0
000074703edd4715  pop r11
000074703edd4717  pop r10
000074703edd4719  pop r9
000074703edd471b  pop r8
000074703edd471d  pop rsi
000074703edd471e  pop rdi
000074703edd471f  pop rdx
000074703edd4720  pop rcx
000074703edd4721  pop rax
000074703edd4722  add rsp, 0x08
000074703edd4726  jmp 0x000074703EDD013D
000074703edd472b  sub rsp, 0x08
000074703edd472f  push rax
000074703edd4730  push rcx
000074703edd4731  push rdx
000074703edd4732  push rdi
000074703edd4733  push rsi
000074703edd4734  push r8
000074703edd4736  push r9
000074703edd4738  push r10
000074703edd473a  push r11
000074703edd473c  sub rsp, 0xF0
000074703edd4743  vmovaps [rsp], xmm0
000074703edd4748  vmovaps [rsp+0x10], xmm1
000074703edd474e  vmovaps [rsp+0x20], xmm2
000074703edd4754  vmovaps [rsp+0x30], xmm3
000074703edd475a  vmovaps [rsp+0x40], xmm4
000074703edd4760  vmovaps [rsp+0x50], xmm5
000074703edd4766  vmovaps [rsp+0x60], xmm6
000074703edd476c  vmovaps [rsp+0x70], xmm7
000074703edd4772  vmovaps [rsp+0x80], xmm8
000074703edd477b  vmovaps [rsp+0x90], xmm9
000074703edd4784  vmovaps [rsp+0xA0], xmm11
000074703edd478d  vmovaps [rsp+0xB0], xmm12
000074703edd4796  vmovaps [rsp+0xC0], xmm13
000074703edd479f  vmovaps [rsp+0xD0], xmm14
000074703edd47a8  vmovaps [rsp+0xE0], xmm15
000074703edd47b1  sub rsp, 0x30
000074703edd47b5  movaps [rsp], xmm10
000074703edd47ba  movaps [rsp+0x10], xmm7
000074703edd47bf  movaps [rsp+0x20], xmm13
000074703edd47c5  lea rdi, [rsp]
000074703edd47c9  mov esi, 0x00
000074703edd47ce  mov rax, 0x5D9974CCC530
000074703edd47d8  call rax
000074703edd47da  movaps xmm10, [rsp]
000074703edd47df  add rsp, 0x30
000074703edd47e3  vmovaps xmm0, [rsp]
000074703edd47e8  vmovaps xmm1, [rsp+0x10]
000074703edd47ee  vmovaps xmm2, [rsp+0x20]
000074703edd47f4  vmovaps xmm3, [rsp+0x30]
000074703edd47fa  vmovaps xmm4, [rsp+0x40]
000074703edd4800  vmovaps xmm5, [rsp+0x50]
000074703edd4806  vmovaps xmm6, [rsp+0x60]
000074703edd480c  vmovaps xmm7, [rsp+0x70]
000074703edd4812  vmovaps xmm8, [rsp+0x80]
000074703edd481b  vmovaps xmm9, [rsp+0x90]
000074703edd4824  vmovaps xmm11, [rsp+0xA0]
000074703edd482d  vmovaps xmm12, [rsp+0xB0]
000074703edd4836  vmovaps xmm13, [rsp+0xC0]
000074703edd483f  vmovaps xmm14, [rsp+0xD0]
000074703edd4848  vmovaps xmm15, [rsp+0xE0]
000074703edd4851  add rsp, 0xF0
000074703edd4858  pop r11
000074703edd485a  pop r10
000074703edd485c  pop r9
000074703edd485e  pop r8
000074703edd4860  pop rsi
000074703edd4861  pop rdi
000074703edd4862  pop rdx
000074703edd4863  pop rcx
000074703edd4864  pop rax
000074703edd4865  add rsp, 0x08
000074703edd4869  jmp 0x000074703EDD0169
000074703edd486e  sub rsp, 0x08
000074703edd4872  push rax
000074703edd4873  push rcx
000074703edd4874  push rdx
000074703edd4875  push rdi
000074703edd4876  push rsi
000074703edd4877  push r8
000074703edd4879  push r9
000074703edd487b  push r10
000074703edd487d  push r11
000074703edd487f  sub rsp, 0xF0
000074703edd4886  vmovaps [rsp], xmm0
000074703edd488b  vmovaps [rsp+0x10], xmm1
000074703edd4891  vmovaps [rsp+0x20], xmm2
000074703edd4897  vmovaps [rsp+0x30], xmm3
000074703edd489d  vmovaps [rsp+0x40], xmm4
000074703edd48a3  vmovaps [rsp+0x50], xmm5
000074703edd48a9  vmovaps [rsp+0x60], xmm6
000074703edd48af  vmovaps [rsp+0x70], xmm7
000074703edd48b5  vmovaps [rsp+0x80], xmm8
000074703edd48be  vmovaps [rsp+0x90], xmm9
000074703edd48c7  vmovaps [rsp+0xA0], xmm10
000074703edd48d0  vmovaps [rsp+0xB0], xmm11
000074703edd48d9  vmovaps [rsp+0xC0], xmm12
000074703edd48e2  vmovaps [rsp+0xD0], xmm14
000074703edd48eb  vmovaps [rsp+0xE0], xmm15
000074703edd48f4  sub rsp, 0x30
000074703edd48f8  movaps [rsp], xmm13
000074703edd48fd  movaps [rsp+0x10], xmm1
000074703edd4902  movaps [rsp+0x20], xmm8
000074703edd4908  lea rdi, [rsp]
000074703edd490c  mov esi, 0x00
000074703edd4911  mov rax, 0x5D9974CCC530
000074703edd491b  call rax
000074703edd491d  movaps xmm13, [rsp]
000074703edd4922  add rsp, 0x30
000074703edd4926  vmovaps xmm0, [rsp]
000074703edd492b  vmovaps xmm1, [rsp+0x10]
000074703edd4931  vmovaps xmm2, [rsp+0x20]
000074703edd4937  vmovaps xmm3, [rsp+0x30]
000074703edd493d  vmovaps xmm4, [rsp+0x40]
000074703edd4943  vmovaps xmm5, [rsp+0x50]
000074703edd4949  vmovaps xmm6, [rsp+0x60]
000074703edd494f  vmovaps xmm7, [rsp+0x70]
000074703edd4955  vmovaps xmm8, [rsp+0x80]
000074703edd495e  vmovaps xmm9, [rsp+0x90]
000074703edd4967  vmovaps xmm10, [rsp+0xA0]
000074703edd4970  vmovaps xmm11, [rsp+0xB0]
000074703edd4979  vmovaps xmm12, [rsp+0xC0]
000074703edd4982  vmovaps xmm14, [rsp+0xD0]
000074703edd498b  vmovaps xmm15, [rsp+0xE0]
000074703edd4994  add rsp, 0xF0
000074703edd499b  pop r11
000074703edd499d  pop r10
000074703edd499f  pop r9
000074703edd49a1  pop r8
000074703edd49a3  pop rsi
000074703edd49a4  pop rdi
000074703edd49a5  pop rdx
000074703edd49a6  pop rcx
000074703edd49a7  pop rax
000074703edd49a8  add rsp, 0x08
000074703edd49ac  jmp 0x000074703EDD0183
000074703edd49b1  call 0x000074703EBFF430
000074703edd49b6  jmp 0x000074703EDD018D
000074703edd49bb  sub rsp, 0x08
000074703edd49bf  push rax
000074703edd49c0  push rcx
000074703edd49c1  push rdx
000074703edd49c2  push rdi
000074703edd49c3  push rsi
000074703edd49c4  push r8
000074703edd49c6  push r9
000074703edd49c8  push r10
000074703edd49ca  push r11
000074703edd49cc  sub rsp, 0xF0
000074703edd49d3  vmovaps [rsp], xmm0
000074703edd49d8  vmovaps [rsp+0x10], xmm1
000074703edd49de  vmovaps [rsp+0x20], xmm2
000074703edd49e4  vmovaps [rsp+0x30], xmm3
000074703edd49ea  vmovaps [rsp+0x40], xmm4
000074703edd49f0  vmovaps [rsp+0x50], xmm5
000074703edd49f6  vmovaps [rsp+0x60], xmm6
000074703edd49fc  vmovaps [rsp+0x70], xmm7
000074703edd4a02  vmovaps [rsp+0x80], xmm9
000074703edd4a0b  vmovaps [rsp+0x90], xmm10
000074703edd4a14  vmovaps [rsp+0xA0], xmm11
000074703edd4a1d  vmovaps [rsp+0xB0], xmm12
000074703edd4a26  vmovaps [rsp+0xC0], xmm13
000074703edd4a2f  vmovaps [rsp+0xD0], xmm14
000074703edd4a38  vmovaps [rsp+0xE0], xmm15
000074703edd4a41  sub rsp, 0x30
000074703edd4a45  movaps [rsp], xmm8
000074703edd4a4a  movaps [rsp+0x10], xmm14
000074703edd4a50  movaps [rsp+0x20], xmm9
000074703edd4a56  lea rdi, [rsp]
000074703edd4a5a  mov esi, 0x00
000074703edd4a5f  mov rax, 0x5D9974CCC530
000074703edd4a69  call rax
000074703edd4a6b  movaps xmm8, [rsp]
000074703edd4a70  add rsp, 0x30
000074703edd4a74  vmovaps xmm0, [rsp]
000074703edd4a79  vmovaps xmm1, [rsp+0x10]
000074703edd4a7f  vmovaps xmm2, [rsp+0x20]
000074703edd4a85  vmovaps xmm3, [rsp+0x30]
000074703edd4a8b  vmovaps xmm4, [rsp+0x40]
000074703edd4a91  vmovaps xmm5, [rsp+0x50]
000074703edd4a97  vmovaps xmm6, [rsp+0x60]
000074703edd4a9d  vmovaps xmm7, [rsp+0x70]
000074703edd4aa3  vmovaps xmm9, [rsp+0x80]
000074703edd4aac  vmovaps xmm10, [rsp+0x90]
000074703edd4ab5  vmovaps xmm11, [rsp+0xA0]
000074703edd4abe  vmovaps xmm12, [rsp+0xB0]
000074703edd4ac7  vmovaps xmm13, [rsp+0xC0]
000074703edd4ad0  vmovaps xmm14, [rsp+0xD0]
000074703edd4ad9  vmovaps xmm15, [rsp+0xE0]
000074703edd4ae2  add rsp, 0xF0
000074703edd4ae9  pop r11
000074703edd4aeb  pop r10
000074703edd4aed  pop r9
000074703edd4aef  pop r8
000074703edd4af1  pop rsi
000074703edd4af2  pop rdi
000074703edd4af3  pop rdx
000074703edd4af4  pop rcx
000074703edd4af5  pop rax
000074703edd4af6  add rsp, 0x08
000074703edd4afa  jmp 0x000074703EDD01AF
000074703edd4aff  sub rsp, 0x08
000074703edd4b03  push rax
000074703edd4b04  push rcx
000074703edd4b05  push rdx
000074703edd4b06  push rdi
000074703edd4b07  push rsi
000074703edd4b08  push r8
000074703edd4b0a  push r9
000074703edd4b0c  push r10
000074703edd4b0e  push r11
000074703edd4b10  sub rsp, 0xF0
000074703edd4b17  vmovaps [rsp], xmm0
000074703edd4b1c  vmovaps [rsp+0x10], xmm1
000074703edd4b22  vmovaps [rsp+0x20], xmm2
000074703edd4b28  vmovaps [rsp+0x30], xmm3
000074703edd4b2e  vmovaps [rsp+0x40], xmm4
000074703edd4b34  vmovaps [rsp+0x50], xmm5
000074703edd4b3a  vmovaps [rsp+0x60], xmm6
000074703edd4b40  vmovaps [rsp+0x70], xmm7
000074703edd4b46  vmovaps [rsp+0x80], xmm8
000074703edd4b4f  vmovaps [rsp+0x90], xmm10
000074703edd4b58  vmovaps [rsp+0xA0], xmm11
000074703edd4b61  vmovaps [rsp+0xB0], xmm12
000074703edd4b6a  vmovaps [rsp+0xC0], xmm13
000074703edd4b73  vmovaps [rsp+0xD0], xmm14
000074703edd4b7c  vmovaps [rsp+0xE0], xmm15
000074703edd4b85  sub rsp, 0x30
000074703edd4b89  movaps [rsp], xmm9
000074703edd4b8e  movaps [rsp+0x10], xmm1
000074703edd4b93  movaps [rsp+0x20], xmm14
000074703edd4b99  lea rdi, [rsp]
000074703edd4b9d  mov esi, 0x00
000074703edd4ba2  mov rax, 0x5D9974CCC530
000074703edd4bac  call rax
000074703edd4bae  movaps xmm9, [rsp]
000074703edd4bb3  add rsp, 0x30
000074703edd4bb7  vmovaps xmm0, [rsp]
000074703edd4bbc  vmovaps xmm1, [rsp+0x10]
000074703edd4bc2  vmovaps xmm2, [rsp+0x20]
000074703edd4bc8  vmovaps xmm3, [rsp+0x30]
000074703edd4bce  vmovaps xmm4, [rsp+0x40]
000074703edd4bd4  vmovaps xmm5, [rsp+0x50]
000074703edd4bda  vmovaps xmm6, [rsp+0x60]
000074703edd4be0  vmovaps xmm7, [rsp+0x70]
000074703edd4be6  vmovaps xmm8, [rsp+0x80]
000074703edd4bef  vmovaps xmm10, [rsp+0x90]
000074703edd4bf8  vmovaps xmm11, [rsp+0xA0]
000074703edd4c01  vmovaps xmm12, [rsp+0xB0]
000074703edd4c0a  vmovaps xmm13, [rsp+0xC0]
000074703edd4c13  vmovaps xmm14, [rsp+0xD0]
000074703edd4c1c  vmovaps xmm15, [rsp+0xE0]
000074703edd4c25  add rsp, 0xF0
000074703edd4c2c  pop r11
000074703edd4c2e  pop r10
000074703edd4c30  pop r9
000074703edd4c32  pop r8
000074703edd4c34  pop rsi
000074703edd4c35  pop rdi
000074703edd4c36  pop rdx
000074703edd4c37  pop rcx
000074703edd4c38  pop rax
000074703edd4c39  add rsp, 0x08
000074703edd4c3d  jmp 0x000074703EDD01DD
000074703edd4c42  sub rsp, 0x08
000074703edd4c46  push rax
000074703edd4c47  push rcx
000074703edd4c48  push rdx
000074703edd4c49  push rdi
000074703edd4c4a  push rsi
000074703edd4c4b  push r8
000074703edd4c4d  push r9
000074703edd4c4f  push r10
000074703edd4c51  push r11
000074703edd4c53  sub rsp, 0xF0
000074703edd4c5a  vmovaps [rsp], xmm0
000074703edd4c5f  vmovaps [rsp+0x10], xmm1
000074703edd4c65  vmovaps [rsp+0x20], xmm2
000074703edd4c6b  vmovaps [rsp+0x30], xmm3
000074703edd4c71  vmovaps [rsp+0x40], xmm4
000074703edd4c77  vmovaps [rsp+0x50], xmm5
000074703edd4c7d  vmovaps [rsp+0x60], xmm6
000074703edd4c83  vmovaps [rsp+0x70], xmm7
000074703edd4c89  vmovaps [rsp+0x80], xmm8
000074703edd4c92  vmovaps [rsp+0x90], xmm9
000074703edd4c9b  vmovaps [rsp+0xA0], xmm10
000074703edd4ca4  vmovaps [rsp+0xB0], xmm11
000074703edd4cad  vmovaps [rsp+0xC0], xmm12
000074703edd4cb6  vmovaps [rsp+0xD0], xmm13
000074703edd4cbf  vmovaps [rsp+0xE0], xmm15
000074703edd4cc8  sub rsp, 0x30
000074703edd4ccc  movaps [rsp], xmm14
000074703edd4cd1  movaps [rsp+0x10], xmm4
000074703edd4cd6  movaps [rsp+0x20], xmm1
000074703edd4cdb  lea rdi, [rsp]
000074703edd4cdf  mov esi, 0x00
000074703edd4ce4  mov rax, 0x5D9974CCC530
000074703edd4cee  call rax
000074703edd4cf0  movaps xmm14, [rsp]
000074703edd4cf5  add rsp, 0x30
000074703edd4cf9  vmovaps xmm0, [rsp]
000074703edd4cfe  vmovaps xmm1, [rsp+0x10]
000074703edd4d04  vmovaps xmm2, [rsp+0x20]
000074703edd4d0a  vmovaps xmm3, [rsp+0x30]
000074703edd4d10  vmovaps xmm4, [rsp+0x40]
000074703edd4d16  vmovaps xmm5, [rsp+0x50]
000074703edd4d1c  vmovaps xmm6, [rsp+0x60]
000074703edd4d22  vmovaps xmm7, [rsp+0x70]
000074703edd4d28  vmovaps xmm8, [rsp+0x80]
000074703edd4d31  vmovaps xmm9, [rsp+0x90]
000074703edd4d3a  vmovaps xmm10, [rsp+0xA0]
000074703edd4d43  vmovaps xmm11, [rsp+0xB0]
000074703edd4d4c  vmovaps xmm12, [rsp+0xC0]
000074703edd4d55  vmovaps xmm13, [rsp+0xD0]
000074703edd4d5e  vmovaps xmm15, [rsp+0xE0]
000074703edd4d67  add rsp, 0xF0
000074703edd4d6e  pop r11
000074703edd4d70  pop r10
000074703edd4d72  pop r9
000074703edd4d74  pop r8
000074703edd4d76  pop rsi
000074703edd4d77  pop rdi
000074703edd4d78  pop rdx
000074703edd4d79  pop rcx
000074703edd4d7a  pop rax
000074703edd4d7b  add rsp, 0x08
000074703edd4d7f  jmp 0x000074703EDD0203
000074703edd4d84  sub rsp, 0x08
000074703edd4d88  push rax
000074703edd4d89  push rcx
000074703edd4d8a  push rdx
000074703edd4d8b  push rdi
000074703edd4d8c  push rsi
000074703edd4d8d  push r8
000074703edd4d8f  push r9
000074703edd4d91  push r10
000074703edd4d93  push r11
000074703edd4d95  sub rsp, 0xF0
000074703edd4d9c  vmovaps [rsp], xmm0
000074703edd4da1  vmovaps [rsp+0x10], xmm2
000074703edd4da7  vmovaps [rsp+0x20], xmm3
000074703edd4dad  vmovaps [rsp+0x30], xmm4
000074703edd4db3  vmovaps [rsp+0x40], xmm5
000074703edd4db9  vmovaps [rsp+0x50], xmm6
000074703edd4dbf  vmovaps [rsp+0x60], xmm7
000074703edd4dc5  vmovaps [rsp+0x70], xmm8
000074703edd4dcb  vmovaps [rsp+0x80], xmm9
000074703edd4dd4  vmovaps [rsp+0x90], xmm10
000074703edd4ddd  vmovaps [rsp+0xA0], xmm11
000074703edd4de6  vmovaps [rsp+0xB0], xmm12
000074703edd4def  vmovaps [rsp+0xC0], xmm13
000074703edd4df8  vmovaps [rsp+0xD0], xmm14
000074703edd4e01  vmovaps [rsp+0xE0], xmm15
000074703edd4e0a  sub rsp, 0x30
000074703edd4e0e  movaps [rsp], xmm1
000074703edd4e12  movaps [rsp+0x10], xmm12
000074703edd4e18  movaps [rsp+0x20], xmm11
000074703edd4e1e  lea rdi, [rsp]
000074703edd4e22  mov esi, 0x00
000074703edd4e27  mov rax, 0x5D9974CCC530
000074703edd4e31  call rax
000074703edd4e33  movaps xmm1, [rsp]
000074703edd4e37  add rsp, 0x30
000074703edd4e3b  vmovaps xmm0, [rsp]
000074703edd4e40  vmovaps xmm2, [rsp+0x10]
000074703edd4e46  vmovaps xmm3, [rsp+0x20]
000074703edd4e4c  vmovaps xmm4, [rsp+0x30]
000074703edd4e52  vmovaps xmm5, [rsp+0x40]
000074703edd4e58  vmovaps xmm6, [rsp+0x50]
000074703edd4e5e  vmovaps xmm7, [rsp+0x60]
000074703edd4e64  vmovaps xmm8, [rsp+0x70]
000074703edd4e6a  vmovaps xmm9, [rsp+0x80]
000074703edd4e73  vmovaps xmm10, [rsp+0x90]
000074703edd4e7c  vmovaps xmm11, [rsp+0xA0]
000074703edd4e85  vmovaps xmm12, [rsp+0xB0]
000074703edd4e8e  vmovaps xmm13, [rsp+0xC0]
000074703edd4e97  vmovaps xmm14, [rsp+0xD0]
000074703edd4ea0  vmovaps xmm15, [rsp+0xE0]
000074703edd4ea9  add rsp, 0xF0
000074703edd4eb0  pop r11
000074703edd4eb2  pop r10
000074703edd4eb4  pop r9
000074703edd4eb6  pop r8
000074703edd4eb8  pop rsi
000074703edd4eb9  pop rdi
000074703edd4eba  pop rdx
000074703edd4ebb  pop rcx
000074703edd4ebc  pop rax
000074703edd4ebd  add rsp, 0x08
000074703edd4ec1  jmp 0x000074703EDD0224
000074703edd4ec6  call 0x000074703ECE20A0
000074703edd4ecb  jmp 0x000074703EDD0232
000074703edd4ed0  call 0x000074703EC09D70
000074703edd4ed5  jmp 0x000074703EDD023C
000074703edd4eda  sub rsp, 0x08
000074703edd4ede  push rax
000074703edd4edf  push rcx
000074703edd4ee0  push rdx
000074703edd4ee1  push rdi
000074703edd4ee2  push rsi
000074703edd4ee3  push r8
000074703edd4ee5  push r9
000074703edd4ee7  push r10
000074703edd4ee9  push r11
000074703edd4eeb  sub rsp, 0xF0
000074703edd4ef2  vmovaps [rsp], xmm0
000074703edd4ef7  vmovaps [rsp+0x10], xmm1
000074703edd4efd  vmovaps [rsp+0x20], xmm2
000074703edd4f03  vmovaps [rsp+0x30], xmm3
000074703edd4f09  vmovaps [rsp+0x40], xmm4
000074703edd4f0f  vmovaps [rsp+0x50], xmm5
000074703edd4f15  vmovaps [rsp+0x60], xmm6
000074703edd4f1b  vmovaps [rsp+0x70], xmm8
000074703edd4f21  vmovaps [rsp+0x80], xmm9
000074703edd4f2a  vmovaps [rsp+0x90], xmm10
000074703edd4f33  vmovaps [rsp+0xA0], xmm11
000074703edd4f3c  vmovaps [rsp+0xB0], xmm12
000074703edd4f45  vmovaps [rsp+0xC0], xmm13
000074703edd4f4e  vmovaps [rsp+0xD0], xmm14
000074703edd4f57  vmovaps [rsp+0xE0], xmm15
000074703edd4f60  sub rsp, 0x30
000074703edd4f64  movaps [rsp], xmm7
000074703edd4f68  movaps [rsp+0x10], xmm15
000074703edd4f6e  movaps [rsp+0x20], xmm10
000074703edd4f74  lea rdi, [rsp]
000074703edd4f78  mov esi, 0x00
000074703edd4f7d  mov rax, 0x5D9974CCC530
000074703edd4f87  call rax
000074703edd4f89  movaps xmm7, [rsp]
000074703edd4f8d  add rsp, 0x30
000074703edd4f91  vmovaps xmm0, [rsp]
000074703edd4f96  vmovaps xmm1, [rsp+0x10]
000074703edd4f9c  vmovaps xmm2, [rsp+0x20]
000074703edd4fa2  vmovaps xmm3, [rsp+0x30]
000074703edd4fa8  vmovaps xmm4, [rsp+0x40]
000074703edd4fae  vmovaps xmm5, [rsp+0x50]
000074703edd4fb4  vmovaps xmm6, [rsp+0x60]
000074703edd4fba  vmovaps xmm8, [rsp+0x70]
000074703edd4fc0  vmovaps xmm9, [rsp+0x80]
000074703edd4fc9  vmovaps xmm10, [rsp+0x90]
000074703edd4fd2  vmovaps xmm11, [rsp+0xA0]
000074703edd4fdb  vmovaps xmm12, [rsp+0xB0]
000074703edd4fe4  vmovaps xmm13, [rsp+0xC0]
000074703edd4fed  vmovaps xmm14, [rsp+0xD0]
000074703edd4ff6  vmovaps xmm15, [rsp+0xE0]
000074703edd4fff  add rsp, 0xF0
000074703edd5006  pop r11
000074703edd5008  pop r10
000074703edd500a  pop r9
000074703edd500c  pop r8
000074703edd500e  pop rsi
000074703edd500f  pop rdi
000074703edd5010  pop rdx
000074703edd5011  pop rcx
000074703edd5012  pop rax
000074703edd5013  add rsp, 0x08
000074703edd5017  jmp 0x000074703EDD025D
000074703edd501c  sub rsp, 0x08
000074703edd5020  push rax
000074703edd5021  push rcx
000074703edd5022  push rdx
000074703edd5023  push rdi
000074703edd5024  push rsi
000074703edd5025  push r8
000074703edd5027  push r9
000074703edd5029  push r10
000074703edd502b  push r11
000074703edd502d  sub rsp, 0xF0
000074703edd5034  vmovaps [rsp], xmm0
000074703edd5039  vmovaps [rsp+0x10], xmm1
000074703edd503f  vmovaps [rsp+0x20], xmm2
000074703edd5045  vmovaps [rsp+0x30], xmm3
000074703edd504b  vmovaps [rsp+0x40], xmm4
000074703edd5051  vmovaps [rsp+0x50], xmm5
000074703edd5057  vmovaps [rsp+0x60], xmm6
000074703edd505d  vmovaps [rsp+0x70], xmm7
000074703edd5063  vmovaps [rsp+0x80], xmm8
000074703edd506c  vmovaps [rsp+0x90], xmm9
000074703edd5075  vmovaps [rsp+0xA0], xmm11
000074703edd507e  vmovaps [rsp+0xB0], xmm12
000074703edd5087  vmovaps [rsp+0xC0], xmm13
000074703edd5090  vmovaps [rsp+0xD0], xmm14
000074703edd5099  vmovaps [rsp+0xE0], xmm15
000074703edd50a2  sub rsp, 0x30
000074703edd50a6  movaps [rsp], xmm10
000074703edd50ab  movaps [rsp+0x10], xmm11
000074703edd50b1  movaps [rsp+0x20], xmm15
000074703edd50b7  lea rdi, [rsp]
000074703edd50bb  mov esi, 0x00
000074703edd50c0  mov rax, 0x5D9974CCC530
000074703edd50ca  call rax
000074703edd50cc  movaps xmm10, [rsp]
000074703edd50d1  add rsp, 0x30
000074703edd50d5  vmovaps xmm0, [rsp]
000074703edd50da  vmovaps xmm1, [rsp+0x10]
000074703edd50e0  vmovaps xmm2, [rsp+0x20]
000074703edd50e6  vmovaps xmm3, [rsp+0x30]
000074703edd50ec  vmovaps xmm4, [rsp+0x40]
000074703edd50f2  vmovaps xmm5, [rsp+0x50]
000074703edd50f8  vmovaps xmm6, [rsp+0x60]
000074703edd50fe  vmovaps xmm7, [rsp+0x70]
000074703edd5104  vmovaps xmm8, [rsp+0x80]
000074703edd510d  vmovaps xmm9, [rsp+0x90]
000074703edd5116  vmovaps xmm11, [rsp+0xA0]
000074703edd511f  vmovaps xmm12, [rsp+0xB0]
000074703edd5128  vmovaps xmm13, [rsp+0xC0]
000074703edd5131  vmovaps xmm14, [rsp+0xD0]
000074703edd513a  vmovaps xmm15, [rsp+0xE0]
000074703edd5143  add rsp, 0xF0
000074703edd514a  pop r11
000074703edd514c  pop r10
000074703edd514e  pop r9
000074703edd5150  pop r8
000074703edd5152  pop rsi
000074703edd5153  pop rdi
000074703edd5154  pop rdx
000074703edd5155  pop rcx
000074703edd5156  pop rax
000074703edd5157  add rsp, 0x08
000074703edd515b  jmp 0x000074703EDD028B
000074703edd5160  sub rsp, 0x08
000074703edd5164  push rax
000074703edd5165  push rcx
000074703edd5166  push rdx
000074703edd5167  push rdi
000074703edd5168  push rsi
000074703edd5169  push r8
000074703edd516b  push r9
000074703edd516d  push r10
000074703edd516f  push r11
000074703edd5171  sub rsp, 0xF0
000074703edd5178  vmovaps [rsp], xmm0
000074703edd517d  vmovaps [rsp+0x10], xmm1
000074703edd5183  vmovaps [rsp+0x20], xmm2
000074703edd5189  vmovaps [rsp+0x30], xmm3
000074703edd518f  vmovaps [rsp+0x40], xmm4
000074703edd5195  vmovaps [rsp+0x50], xmm5
000074703edd519b  vmovaps [rsp+0x60], xmm6
000074703edd51a1  vmovaps [rsp+0x70], xmm7
000074703edd51a7  vmovaps [rsp+0x80], xmm8
000074703edd51b0  vmovaps [rsp+0x90], xmm9
000074703edd51b9  vmovaps [rsp+0xA0], xmm10
000074703edd51c2  vmovaps [rsp+0xB0], xmm12
000074703edd51cb  vmovaps [rsp+0xC0], xmm13
000074703edd51d4  vmovaps [rsp+0xD0], xmm14
000074703edd51dd  vmovaps [rsp+0xE0], xmm15
000074703edd51e6  sub rsp, 0x30
000074703edd51ea  movaps [rsp], xmm11
000074703edd51ef  movaps [rsp+0x10], xmm12
000074703edd51f5  movaps [rsp+0x20], xmm15
000074703edd51fb  lea rdi, [rsp]
000074703edd51ff  mov esi, 0x00
000074703edd5204  mov rax, 0x5D9974CCC530
000074703edd520e  call rax
000074703edd5210  movaps xmm11, [rsp]
000074703edd5215  add rsp, 0x30
000074703edd5219  vmovaps xmm0, [rsp]
000074703edd521e  vmovaps xmm1, [rsp+0x10]
000074703edd5224  vmovaps xmm2, [rsp+0x20]
000074703edd522a  vmovaps xmm3, [rsp+0x30]
000074703edd5230  vmovaps xmm4, [rsp+0x40]
000074703edd5236  vmovaps xmm5, [rsp+0x50]
000074703edd523c  vmovaps xmm6, [rsp+0x60]
000074703edd5242  vmovaps xmm7, [rsp+0x70]
000074703edd5248  vmovaps xmm8, [rsp+0x80]
000074703edd5251  vmovaps xmm9, [rsp+0x90]
000074703edd525a  vmovaps xmm10, [rsp+0xA0]
000074703edd5263  vmovaps xmm12, [rsp+0xB0]
000074703edd526c  vmovaps xmm13, [rsp+0xC0]
000074703edd5275  vmovaps xmm14, [rsp+0xD0]
000074703edd527e  vmovaps xmm15, [rsp+0xE0]
000074703edd5287  add rsp, 0xF0
000074703edd528e  pop r11
000074703edd5290  pop r10
000074703edd5292  pop r9
000074703edd5294  pop r8
000074703edd5296  pop rsi
000074703edd5297  pop rdi
000074703edd5298  pop rdx
000074703edd5299  pop rcx
000074703edd529a  pop rax
000074703edd529b  add rsp, 0x08
000074703edd529f  jmp 0x000074703EDD02B9
000074703edd52a4  sub rsp, 0x08
000074703edd52a8  push rax
000074703edd52a9  push rcx
000074703edd52aa  push rdx
000074703edd52ab  push rdi
000074703edd52ac  push rsi
000074703edd52ad  push r8
000074703edd52af  push r9
000074703edd52b1  push r10
000074703edd52b3  push r11
000074703edd52b5  sub rsp, 0xF0
000074703edd52bc  vmovaps [rsp], xmm0
000074703edd52c1  vmovaps [rsp+0x10], xmm1
000074703edd52c7  vmovaps [rsp+0x20], xmm2
000074703edd52cd  vmovaps [rsp+0x30], xmm3
000074703edd52d3  vmovaps [rsp+0x40], xmm4
000074703edd52d9  vmovaps [rsp+0x50], xmm5
000074703edd52df  vmovaps [rsp+0x60], xmm6
000074703edd52e5  vmovaps [rsp+0x70], xmm7
000074703edd52eb  vmovaps [rsp+0x80], xmm8
000074703edd52f4  vmovaps [rsp+0x90], xmm9
000074703edd52fd  vmovaps [rsp+0xA0], xmm10
000074703edd5306  vmovaps [rsp+0xB0], xmm11
000074703edd530f  vmovaps [rsp+0xC0], xmm12
000074703edd5318  vmovaps [rsp+0xD0], xmm13
000074703edd5321  vmovaps [rsp+0xE0], xmm14
000074703edd532a  sub rsp, 0x30
000074703edd532e  movaps [rsp], xmm15
000074703edd5333  movaps [rsp+0x10], xmm13
000074703edd5339  movaps [rsp+0x20], xmm9
000074703edd533f  lea rdi, [rsp]
000074703edd5343  mov esi, 0x00
000074703edd5348  mov rax, 0x5D9974CCC530
000074703edd5352  call rax
000074703edd5354  movaps xmm15, [rsp]
000074703edd5359  add rsp, 0x30
000074703edd535d  vmovaps xmm0, [rsp]
000074703edd5362  vmovaps xmm1, [rsp+0x10]
000074703edd5368  vmovaps xmm2, [rsp+0x20]
000074703edd536e  vmovaps xmm3, [rsp+0x30]
000074703edd5374  vmovaps xmm4, [rsp+0x40]
000074703edd537a  vmovaps xmm5, [rsp+0x50]
000074703edd5380  vmovaps xmm6, [rsp+0x60]
000074703edd5386  vmovaps xmm7, [rsp+0x70]
000074703edd538c  vmovaps xmm8, [rsp+0x80]
000074703edd5395  vmovaps xmm9, [rsp+0x90]
000074703edd539e  vmovaps xmm10, [rsp+0xA0]
000074703edd53a7  vmovaps xmm11, [rsp+0xB0]
000074703edd53b0  vmovaps xmm12, [rsp+0xC0]
000074703edd53b9  vmovaps xmm13, [rsp+0xD0]
000074703edd53c2  vmovaps xmm14, [rsp+0xE0]
000074703edd53cb  add rsp, 0xF0
000074703edd53d2  pop r11
000074703edd53d4  pop r10
000074703edd53d6  pop r9
000074703edd53d8  pop r8
000074703edd53da  pop rsi
000074703edd53db  pop rdi
000074703edd53dc  pop rdx
000074703edd53dd  pop rcx
000074703edd53de  pop rax
000074703edd53df  add rsp, 0x08
000074703edd53e3  jmp 0x000074703EDD02D4
000074703edd53e8  sub rsp, 0x08
000074703edd53ec  push rax
000074703edd53ed  push rcx
000074703edd53ee  push rdx
000074703edd53ef  push rdi
000074703edd53f0  push rsi
000074703edd53f1  push r8
000074703edd53f3  push r9
000074703edd53f5  push r10
000074703edd53f7  push r11
000074703edd53f9  sub rsp, 0xF0
000074703edd5400  vmovaps [rsp], xmm0
000074703edd5405  vmovaps [rsp+0x10], xmm1
000074703edd540b  vmovaps [rsp+0x20], xmm2
000074703edd5411  vmovaps [rsp+0x30], xmm3
000074703edd5417  vmovaps [rsp+0x40], xmm4
000074703edd541d  vmovaps [rsp+0x50], xmm5
000074703edd5423  vmovaps [rsp+0x60], xmm6
000074703edd5429  vmovaps [rsp+0x70], xmm7
000074703edd542f  vmovaps [rsp+0x80], xmm8
000074703edd5438  vmovaps [rsp+0x90], xmm9
000074703edd5441  vmovaps [rsp+0xA0], xmm10
000074703edd544a  vmovaps [rsp+0xB0], xmm11
000074703edd5453  vmovaps [rsp+0xC0], xmm12
000074703edd545c  vmovaps [rsp+0xD0], xmm14
000074703edd5465  vmovaps [rsp+0xE0], xmm15
000074703edd546e  sub rsp, 0x30
000074703edd5472  movaps [rsp], xmm13
000074703edd5477  movaps [rsp+0x10], xmm8
000074703edd547d  movaps [rsp+0x20], xmm14
000074703edd5483  lea rdi, [rsp]
000074703edd5487  mov esi, 0x00
000074703edd548c  mov rax, 0x5D9974CCC530
000074703edd5496  call rax
000074703edd5498  movaps xmm13, [rsp]
000074703edd549d  add rsp, 0x30
000074703edd54a1  vmovaps xmm0, [rsp]
000074703edd54a6  vmovaps xmm1, [rsp+0x10]
000074703edd54ac  vmovaps xmm2, [rsp+0x20]
000074703edd54b2  vmovaps xmm3, [rsp+0x30]
000074703edd54b8  vmovaps xmm4, [rsp+0x40]
000074703edd54be  vmovaps xmm5, [rsp+0x50]
000074703edd54c4  vmovaps xmm6, [rsp+0x60]
000074703edd54ca  vmovaps xmm7, [rsp+0x70]
000074703edd54d0  vmovaps xmm8, [rsp+0x80]
000074703edd54d9  vmovaps xmm9, [rsp+0x90]
000074703edd54e2  vmovaps xmm10, [rsp+0xA0]
000074703edd54eb  vmovaps xmm11, [rsp+0xB0]
000074703edd54f4  vmovaps xmm12, [rsp+0xC0]
000074703edd54fd  vmovaps xmm14, [rsp+0xD0]
000074703edd5506  vmovaps xmm15, [rsp+0xE0]
000074703edd550f  add rsp, 0xF0
000074703edd5516  pop r11
000074703edd5518  pop r10
000074703edd551a  pop r9
000074703edd551c  pop r8
000074703edd551e  pop rsi
000074703edd551f  pop rdi
000074703edd5520  pop rdx
000074703edd5521  pop rcx
000074703edd5522  pop rax
000074703edd5523  add rsp, 0x08
000074703edd5527  jmp 0x000074703EDD02F7
000074703edd552c  sub rsp, 0x08
000074703edd5530  push rax
000074703edd5531  push rcx
000074703edd5532  push rdx
000074703edd5533  push rdi
000074703edd5534  push rsi
000074703edd5535  push r8
000074703edd5537  push r9
000074703edd5539  push r10
000074703edd553b  push r11
000074703edd553d  sub rsp, 0xF0
000074703edd5544  vmovaps [rsp], xmm0
000074703edd5549  vmovaps [rsp+0x10], xmm1
000074703edd554f  vmovaps [rsp+0x20], xmm2
000074703edd5555  vmovaps [rsp+0x30], xmm3
000074703edd555b  vmovaps [rsp+0x40], xmm4
000074703edd5561  vmovaps [rsp+0x50], xmm5
000074703edd5567  vmovaps [rsp+0x60], xmm6
000074703edd556d  vmovaps [rsp+0x70], xmm7
000074703edd5573  vmovaps [rsp+0x80], xmm8
000074703edd557c  vmovaps [rsp+0x90], xmm9
000074703edd5585  vmovaps [rsp+0xA0], xmm10
000074703edd558e  vmovaps [rsp+0xB0], xmm11
000074703edd5597  vmovaps [rsp+0xC0], xmm12
000074703edd55a0  vmovaps [rsp+0xD0], xmm13
000074703edd55a9  vmovaps [rsp+0xE0], xmm15
000074703edd55b2  sub rsp, 0x30
000074703edd55b6  movaps [rsp], xmm14
000074703edd55bb  movaps [rsp+0x10], xmm1
000074703edd55c0  movaps [rsp+0x20], xmm10
000074703edd55c6  lea rdi, [rsp]
000074703edd55ca  mov esi, 0x00
000074703edd55cf  mov rax, 0x5D9974CCC530
000074703edd55d9  call rax
000074703edd55db  movaps xmm14, [rsp]
000074703edd55e0  add rsp, 0x30
000074703edd55e4  vmovaps xmm0, [rsp]
000074703edd55e9  vmovaps xmm1, [rsp+0x10]
000074703edd55ef  vmovaps xmm2, [rsp+0x20]
000074703edd55f5  vmovaps xmm3, [rsp+0x30]
000074703edd55fb  vmovaps xmm4, [rsp+0x40]
000074703edd5601  vmovaps xmm5, [rsp+0x50]
000074703edd5607  vmovaps xmm6, [rsp+0x60]
000074703edd560d  vmovaps xmm7, [rsp+0x70]
000074703edd5613  vmovaps xmm8, [rsp+0x80]
000074703edd561c  vmovaps xmm9, [rsp+0x90]
000074703edd5625  vmovaps xmm10, [rsp+0xA0]
000074703edd562e  vmovaps xmm11, [rsp+0xB0]
000074703edd5637  vmovaps xmm12, [rsp+0xC0]
000074703edd5640  vmovaps xmm13, [rsp+0xD0]
000074703edd5649  vmovaps xmm15, [rsp+0xE0]
000074703edd5652  add rsp, 0xF0
000074703edd5659  pop r11
000074703edd565b  pop r10
000074703edd565d  pop r9
000074703edd565f  pop r8
000074703edd5661  pop rsi
000074703edd5662  pop rdi
000074703edd5663  pop rdx
000074703edd5664  pop rcx
000074703edd5665  pop rax
000074703edd5666  add rsp, 0x08
000074703edd566a  jmp 0x000074703EDD031A
000074703edd566f  sub rsp, 0x08
000074703edd5673  push rax
000074703edd5674  push rcx
000074703edd5675  push rdx
000074703edd5676  push rdi
000074703edd5677  push rsi
000074703edd5678  push r8
000074703edd567a  push r9
000074703edd567c  push r10
000074703edd567e  push r11
000074703edd5680  sub rsp, 0xF0
000074703edd5687  vmovaps [rsp], xmm0
000074703edd568c  vmovaps [rsp+0x10], xmm2
000074703edd5692  vmovaps [rsp+0x20], xmm3
000074703edd5698  vmovaps [rsp+0x30], xmm4
000074703edd569e  vmovaps [rsp+0x40], xmm5
000074703edd56a4  vmovaps [rsp+0x50], xmm6
000074703edd56aa  vmovaps [rsp+0x60], xmm7
000074703edd56b0  vmovaps [rsp+0x70], xmm8
000074703edd56b6  vmovaps [rsp+0x80], xmm9
000074703edd56bf  vmovaps [rsp+0x90], xmm10
000074703edd56c8  vmovaps [rsp+0xA0], xmm11
000074703edd56d1  vmovaps [rsp+0xB0], xmm12
000074703edd56da  vmovaps [rsp+0xC0], xmm13
000074703edd56e3  vmovaps [rsp+0xD0], xmm14
000074703edd56ec  vmovaps [rsp+0xE0], xmm15
000074703edd56f5  sub rsp, 0x30
000074703edd56f9  movaps [rsp], xmm1
000074703edd56fd  movaps [rsp+0x10], xmm7
000074703edd5702  movaps [rsp+0x20], xmm11
000074703edd5708  lea rdi, [rsp]
000074703edd570c  mov esi, 0x00
000074703edd5711  mov rax, 0x5D9974CCC530
000074703edd571b  call rax
000074703edd571d  movaps xmm1, [rsp]
000074703edd5721  add rsp, 0x30
000074703edd5725  vmovaps xmm0, [rsp]
000074703edd572a  vmovaps xmm2, [rsp+0x10]
000074703edd5730  vmovaps xmm3, [rsp+0x20]
000074703edd5736  vmovaps xmm4, [rsp+0x30]
000074703edd573c  vmovaps xmm5, [rsp+0x40]
000074703edd5742  vmovaps xmm6, [rsp+0x50]
000074703edd5748  vmovaps xmm7, [rsp+0x60]
000074703edd574e  vmovaps xmm8, [rsp+0x70]
000074703edd5754  vmovaps xmm9, [rsp+0x80]
000074703edd575d  vmovaps xmm10, [rsp+0x90]
000074703edd5766  vmovaps xmm11, [rsp+0xA0]
000074703edd576f  vmovaps xmm12, [rsp+0xB0]
000074703edd5778  vmovaps xmm13, [rsp+0xC0]
000074703edd5781  vmovaps xmm14, [rsp+0xD0]
000074703edd578a  vmovaps xmm15, [rsp+0xE0]
000074703edd5793  add rsp, 0xF0
000074703edd579a  pop r11
000074703edd579c  pop r10
000074703edd579e  pop r9
000074703edd57a0  pop r8
000074703edd57a2  pop rsi
000074703edd57a3  pop rdi
000074703edd57a4  pop rdx
000074703edd57a5  pop rcx
000074703edd57a6  pop rax
000074703edd57a7  add rsp, 0x08
000074703edd57ab  jmp 0x000074703EDD033B
000074703edd57b0  call 0x000074703EC0E880
000074703edd57b5  jmp 0x000074703EDD034E
000074703edd57ba  call 0x000074703EC0C380
000074703edd57bf  jmp 0x000074703EDD0359
000074703edd57c4  call 0x000074703EC0D600
000074703edd57c9  jmp 0x000074703EDD0364
000074703edd57ce  call 0x000074703EBFF540
000074703edd57d3  jmp 0x000074703EDD036F
000074703edd57d8  int3
000074703edd57d9  nop [rax], eax
000074703edd57e0  mov rax, [r15+0x40]
000074703edd57e4  mov r14, [r15+0x58]
000074703edd57e8  lea r12, [rax+r14*1]
000074703edd57ec  movaps xmm1, [r15+0x1D0]
000074703edd57f4  vmovaps [rsp+0x10], xmm1
000074703edd57fa  vmovaps xmm15, [rsp+0x10]
000074703edd5800  por xmm1, xmm15
000074703edd5805  movaps xmm14, [r15+0x1A0]
000074703edd580d  vmovaps [rsp+0x10], xmm14
000074703edd5813  vmovaps xmm13, [rsp+0x10]
000074703edd5819  por xmm14, xmm13
000074703edd581e  lea rax, [r12+0x30]
000074703edd5823  mov r11, [r13+rax*1]
000074703edd5828  lea rax, [r12+0x38]
000074703edd582d  mov r10, [r13+rax*1]
000074703edd5832  movq xmm13, r11
000074703edd5837  movq xmm12, r10
000074703edd583c  movq xmm13, xmm13
000074703edd5841  vmovaps [rsp+0x10], xmm13
000074703edd5847  movq xmm13, xmm13
000074703edd584c  movaps [r15+0x130], xmm13
000074703edd5854  movq xmm12, xmm12
000074703edd5859  vmovaps [rsp+0x20], xmm12
000074703edd585f  movq xmm12, xmm12
000074703edd5864  movaps [r15+0x280], xmm12
000074703edd586c  movaps xmm13, [r15+0x270]
000074703edd5874  vmovaps [rsp+0x30], xmm13
000074703edd587a  vmovaps xmm12, [rsp+0x30]
000074703edd5880  por xmm13, xmm12
000074703edd5885  lea rax, [r12+0x20]
000074703edd588a  mov r11, [r13+rax*1]
000074703edd588f  lea rax, [r12+0x28]
000074703edd5894  mov r10, [r13+rax*1]
000074703edd5899  movq xmm12, r11
000074703edd589e  movq xmm11, r10
000074703edd58a3  movq xmm12, xmm12
000074703edd58a8  vmovaps [rsp+0x30], xmm12
000074703edd58ae  movq xmm12, xmm12
000074703edd58b3  movaps [r15+0x150], xmm12
000074703edd58bb  movq xmm11, xmm11
000074703edd58c0  vmovaps [rsp+0x40], xmm11
000074703edd58c6  movq xmm11, xmm11
000074703edd58cb  movaps [r15+0x140], xmm11
000074703edd58d3  lea rax, [r12+0x10]
000074703edd58d8  mov r11, [r13+rax*1]
000074703edd58dd  lea rax, [r12+0x18]
000074703edd58e2  mov r10, [r13+rax*1]
000074703edd58e7  movq xmm12, r11
000074703edd58ec  movq xmm11, r10
000074703edd58f1  movq xmm12, xmm12
000074703edd58f6  vmovaps [rsp+0x50], xmm12
000074703edd58fc  movq xmm12, xmm12
000074703edd5901  movaps [r15+0x170], xmm12
000074703edd5909  movq xmm11, xmm11
000074703edd590e  vmovaps [rsp+0x60], xmm11
000074703edd5914  movq xmm11, xmm11
000074703edd5919  movaps [r15+0x160], xmm11
000074703edd5921  mov rax, [r13+r12*1]
000074703edd5926  vmovq xmm12, rax
000074703edd592b  vpbroadcastq xmm12, xmm12
000074703edd5930  lea rax, [r12+0x08]
000074703edd5935  mov r12, [r13+rax*1]
000074703edd593a  movq xmm11, r12
000074703edd593f  movaps [r15+0x230], xmm11
000074703edd5947  mov rax, [r15+0xF8]
000074703edd594e  lea r12, [rax+0x50]
000074703edd5952  movups xmm11, [r13+r12*1]
000074703edd5958  lea r12, [rax+0x60]
000074703edd595c  movups xmm10, [r13+r12*1]
000074703edd5962  lea r12, [rax+0x30]
000074703edd5966  movups xmm9, [r13+r12*1]
000074703edd596c  mov r12, [r15+0x50]
000074703edd5970  lea r11, [r12+r14*1]
000074703edd5974  mov [r15+0x60], r11
000074703edd5978  lea r12, [r14+0x40]
000074703edd597c  mov [r15+0x58], r12
000074703edd5980  movaps xmm8, xmm12
000074703edd5984  mulpd xmm8, xmm15
000074703edd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000074703edd598f  ptest xmm7, xmm7
000074703edd5994  jnz 0x000074703EDD67B7
000074703edd599a  movq xmm15, qword ptr [r15+0x230]
000074703edd59a3  vmovaps [rsp+0x70], xmm15
000074703edd59a9  vpermilpd xmm15, xmm15, 0x00
000074703edd59af  movaps xmm7, xmm9
000074703edd59b3  mulpd xmm7, xmm15
000074703edd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000074703edd59bd  ptest xmm6, xmm6
000074703edd59c2  jnz 0x000074703EDD68FB
000074703edd59c8  vxorps xmm15, xmm15, xmm15
000074703edd59cd  vpbroadcastq xmm15, xmm15
000074703edd59d2  movaps xmm9, xmm12
000074703edd59d6  mulpd xmm9, xmm10
000074703edd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000074703edd59e1  ptest xmm6, xmm6
000074703edd59e6  jnz 0x000074703EDD6A3D
000074703edd59ec  movaps xmm10, xmm12
000074703edd59f0  mulpd xmm10, xmm11
000074703edd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000074703edd59fb  ptest xmm6, xmm6
000074703edd5a00  jnz 0x000074703EDD6B81
000074703edd5a06  movaps xmm11, [r15+0x1F0]
000074703edd5a0e  movaps xmm6, xmm12
000074703edd5a12  mulpd xmm6, xmm11
000074703edd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000074703edd5a1c  ptest xmm5, xmm5
000074703edd5a21  jnz 0x000074703EDD6CC5
000074703edd5a27  movaps xmm12, [r15+0x2A0]
000074703edd5a2f  vmovaps [rsp+0x80], xmm12
000074703edd5a38  vmovaps xmm11, [rsp+0x80]
000074703edd5a41  por xmm12, xmm11
000074703edd5a46  movaps xmm11, [r15+0x250]
000074703edd5a4e  vmovaps [rsp+0x80], xmm11
000074703edd5a57  vmovaps xmm5, [rsp+0x80]
000074703edd5a60  por xmm11, xmm5
000074703edd5a65  vmovaps xmm4, [rsp+0x70]
000074703edd5a6b  vpermilpd xmm4, xmm4, 0x00
000074703edd5a71  movaps xmm3, xmm5
000074703edd5a74  mulpd xmm3, xmm4
000074703edd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000074703edd5a7d  ptest xmm2, xmm2
000074703edd5a82  jnz 0x000074703EDD6E07
000074703edd5a88  mov [rsp+0x80], rax
000074703edd5a90  xor eax, eax
000074703edd5a92  mov r14d, 0x200
000074703edd5a98  cmp r12, r14
000074703edd5a9b  cmc
000074703edd5a9c  lahf
000074703edd5a9d  seto al
000074703edd5aa0  mov [r15+0x108], eax
000074703edd5aa7  movaps xmm5, xmm8
000074703edd5aab  addpd xmm5, xmm15
000074703edd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000074703edd5ab5  ptest xmm4, xmm4
000074703edd5aba  jnz 0x000074703EDD6F47
000074703edd5ac0  movaps xmm8, [r15+0x1B0]
000074703edd5ac8  movaps xmm4, xmm9
000074703edd5acc  addpd xmm4, xmm8
000074703edd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000074703edd5ad6  ptest xmm2, xmm2
000074703edd5adb  jnz 0x000074703EDD7089
000074703edd5ae1  movaps xmm9, xmm10
000074703edd5ae5  addpd xmm9, xmm8
000074703edd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000074703edd5af0  ptest xmm2, xmm2
000074703edd5af5  jnz 0x000074703EDD71CB
000074703edd5afb  movaps xmm10, [r15+0x2F0]
000074703edd5b03  vmovaps [rsp+0x90], xmm10
000074703edd5b0c  vmovaps xmm8, [rsp+0x90]
000074703edd5b15  por xmm10, xmm8
000074703edd5b1a  movaps xmm8, [r15+0x2E0]
000074703edd5b22  vmovaps [rsp+0x90], xmm8
000074703edd5b2b  vmovaps xmm2, [rsp+0x90]
000074703edd5b34  por xmm8, xmm2
000074703edd5b39  movaps xmm2, [r15+0x2D0]
000074703edd5b41  vmovaps [rsp+0x90], xmm2
000074703edd5b4a  vmovaps [rsp+0xA0], xmm1
000074703edd5b53  vmovaps xmm1, [rsp+0x90]
000074703edd5b5c  por xmm2, xmm1
000074703edd5b60  movaps xmm1, [r15+0x200]
000074703edd5b68  vmovaps [rsp+0x90], xmm1
000074703edd5b71  vmovaps [rsp+0xB0], xmm15
000074703edd5b7a  vmovaps xmm15, [rsp+0x90]
000074703edd5b83  por xmm1, xmm15
000074703edd5b88  movaps xmm15, [r15+0x1C0]
000074703edd5b90  vmovaps [rsp+0x90], xmm15
000074703edd5b99  vmovaps [rsp+0xC0], xmm1
000074703edd5ba2  vmovaps xmm1, [rsp+0x90]
000074703edd5bab  por xmm15, xmm1
000074703edd5bb0  movaps xmm1, [r15+0x190]
000074703edd5bb8  vmovaps [rsp+0x90], xmm1
000074703edd5bc1  vmovaps [rsp+0xD0], xmm15
000074703edd5bca  vmovaps xmm15, [rsp+0x90]
000074703edd5bd3  por xmm1, xmm15
000074703edd5bd8  movaps xmm15, [r15+0x300]
000074703edd5be0  vmovaps [rsp+0x90], xmm15
000074703edd5be9  vmovaps [rsp+0xE0], xmm1
000074703edd5bf2  vmovaps xmm1, [rsp+0x90]
000074703edd5bfb  por xmm15, xmm1
000074703edd5c00  mov rax, [rsp+0x80]
000074703edd5c08  lea r14, [rax+0xA0]
000074703edd5c0f  movups xmm1, [r13+r14*1]
000074703edd5c15  lea r14, [rax+0xB0]
000074703edd5c1c  vmovaps [rsp+0x80], xmm1
000074703edd5c25  movups xmm1, [r13+r14*1]
000074703edd5c2b  vmovaps [rsp+0x90], xmm1
000074703edd5c34  vmovaps [rsp+0xF0], xmm15
000074703edd5c3d  vmovaps xmm15, [rsp+0xB0]
000074703edd5c46  vmovaps [rsp+0xB0], xmm14
000074703edd5c4f  movaps xmm1, xmm6
000074703edd5c52  addpd xmm1, xmm15
000074703edd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000074703edd5c5c  ptest xmm14, xmm14
000074703edd5c62  jnz 0x000074703EDD7323
000074703edd5c68  lea r14, [rax+0xF0]
000074703edd5c6f  movups xmm15, [r13+r14*1]
000074703edd5c75  movaps xmm14, xmm4
000074703edd5c79  addpd xmm14, xmm3
000074703edd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000074703edd5c84  ptest xmm6, xmm6
000074703edd5c89  jnz 0x000074703EDD746E
000074703edd5c8f  movaps xmm6, xmm9
000074703edd5c93  addpd xmm6, xmm7
000074703edd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000074703edd5c9c  ptest xmm4, xmm4
000074703edd5ca1  jnz 0x000074703EDD75B0
000074703edd5ca7  vmovaps xmm9, [rsp+0x70]
000074703edd5cad  vpermilpd xmm9, xmm9, 0x00
000074703edd5cb3  vmovaps xmm4, [rsp+0x90]
000074703edd5cbc  movaps xmm7, xmm4
000074703edd5cbf  mulpd xmm7, xmm9
000074703edd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000074703edd5cc9  ptest xmm3, xmm3
000074703edd5cce  jnz 0x000074703EDD76F1
000074703edd5cd4  vmovaps xmm9, [rsp+0x50]
000074703edd5cda  vpermilpd xmm9, xmm9, 0x00
000074703edd5ce0  movaps xmm4, xmm15
000074703edd5ce4  mulpd xmm4, xmm9
000074703edd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000074703edd5cee  ptest xmm3, xmm3
000074703edd5cf3  jnz 0x000074703EDD7832
000074703edd5cf9  lea r14, [rax+0xE0]
000074703edd5d00  movups xmm15, [r13+r14*1]
000074703edd5d06  vmovaps xmm9, [rsp+0x70]
000074703edd5d0c  vpermilpd xmm9, xmm9, 0x00
000074703edd5d12  vmovaps [rsp+0x70], xmm1
000074703edd5d18  vmovaps xmm1, [rsp+0x80]
000074703edd5d21  vmovaps [rsp+0x80], xmm15
000074703edd5d2a  movaps xmm3, xmm1
000074703edd5d2d  mulpd xmm3, xmm9
000074703edd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000074703edd5d37  ptest xmm15, xmm15
000074703edd5d3d  jnz 0x000074703EDD797E
000074703edd5d43  vmovaps xmm1, [rsp+0xF0]
000074703edd5d4c  vmovaps xmm15, [rsp+0xF0]
000074703edd5d55  por xmm1, xmm15
000074703edd5d5a  movaps [r15+0x300], xmm1
000074703edd5d62  vmovaps xmm15, [rsp+0xE0]
000074703edd5d6b  vmovaps xmm9, [rsp+0xE0]
000074703edd5d74  por xmm15, xmm9
000074703edd5d79  movaps [r15+0x190], xmm15
000074703edd5d81  vmovaps xmm9, [rsp+0x50]
000074703edd5d87  vpermilpd xmm9, xmm9, 0x00
000074703edd5d8d  vmovaps [rsp+0x90], xmm1
000074703edd5d96  vmovaps [rsp+0xE0], xmm15
000074703edd5d9f  vmovaps xmm15, [rsp+0x80]
000074703edd5da8  vmovaps [rsp+0x80], xmm14
000074703edd5db1  movaps xmm1, xmm15
000074703edd5db5  mulpd xmm1, xmm9
000074703edd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000074703edd5dbf  ptest xmm14, xmm14
000074703edd5dc5  jnz 0x000074703EDD7ABF
000074703edd5dcb  lea r14, [rax+0x90]
000074703edd5dd2  movups xmm15, [r13+r14*1]
000074703edd5dd8  vmovaps xmm14, [rsp+0xD0]
000074703edd5de1  vmovaps xmm9, [rsp+0xD0]
000074703edd5dea  por xmm14, xmm9
000074703edd5def  movaps [r15+0x1C0], xmm14
000074703edd5df7  vmovaps xmm9, [rsp+0xC0]
000074703edd5e00  vmovaps [rsp+0xD0], xmm1
000074703edd5e09  vmovaps xmm1, [rsp+0xC0]
000074703edd5e12  por xmm9, xmm1
000074703edd5e17  movaps [r15+0x200], xmm9
000074703edd5e1f  vmovaps [rsp+0xC0], xmm2
000074703edd5e28  vmovaps xmm1, [rsp+0xC0]
000074703edd5e31  por xmm2, xmm1
000074703edd5e35  movaps [r15+0x2D0], xmm2
000074703edd5e3d  vmovaps [rsp+0xC0], xmm8
000074703edd5e46  vmovaps xmm1, [rsp+0xC0]
000074703edd5e4f  por xmm8, xmm1
000074703edd5e54  movaps [r15+0x2E0], xmm8
000074703edd5e5c  vmovaps [rsp+0xC0], xmm15
000074703edd5e65  movaps xmm1, xmm5
000074703edd5e68  addpd xmm1, xmm7
000074703edd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000074703edd5e71  ptest xmm15, xmm15
000074703edd5e77  jnz 0x000074703EDD7C0B
000074703edd5e7d  vmovaps xmm15, [rsp+0x50]
000074703edd5e83  vpermilpd xmm15, xmm15, 0x00
000074703edd5e89  vmovaps xmm5, [rsp+0xC0]
000074703edd5e92  vmovaps [rsp+0xC0], xmm1
000074703edd5e9b  movaps xmm7, xmm5
000074703edd5e9e  mulpd xmm7, xmm15
000074703edd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000074703edd5ea8  ptest xmm1, xmm1
000074703edd5ead  jnz 0x000074703EDD7D4B
000074703edd5eb3  lea r14, [rax+0x80]
000074703edd5eba  movups xmm1, [r13+r14*1]
000074703edd5ec0  vmovaps xmm5, [rsp+0x70]
000074703edd5ec6  vmovaps [rsp+0x70], xmm1
000074703edd5ecc  movaps xmm15, xmm5
000074703edd5ed0  addpd xmm15, xmm3
000074703edd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000074703edd5edb  ptest xmm1, xmm1
000074703edd5ee0  jnz 0x000074703EDD7E96
000074703edd5ee6  vmovaps xmm5, [rsp+0x80]
000074703edd5eef  movaps xmm1, xmm5
000074703edd5ef2  addpd xmm1, xmm4
000074703edd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000074703edd5efb  ptest xmm3, xmm3
000074703edd5f00  jnz 0x000074703EDD7FD8
000074703edd5f06  vmovaps [rsp+0x80], xmm10
000074703edd5f0f  vmovaps xmm5, [rsp+0x80]
000074703edd5f18  por xmm10, xmm5
000074703edd5f1d  movaps [r15+0x2F0], xmm10
000074703edd5f25  vmovaps xmm5, [rsp+0x50]
000074703edd5f2b  vpermilpd xmm5, xmm5, 0x00
000074703edd5f31  vmovaps xmm3, [rsp+0x70]
000074703edd5f37  vmovaps [rsp+0x50], xmm1
000074703edd5f3d  movaps xmm4, xmm3
000074703edd5f40  mulpd xmm4, xmm5
000074703edd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000074703edd5f49  ptest xmm1, xmm1
000074703edd5f4e  jnz 0x000074703EDD8118
000074703edd5f54  lea r14, [rax+0xD0]
000074703edd5f5b  movups xmm1, [r13+r14*1]
000074703edd5f61  vmovaps xmm3, [rsp+0xD0]
000074703edd5f6a  vmovaps [rsp+0x70], xmm1
000074703edd5f70  movaps xmm5, xmm6
000074703edd5f73  addpd xmm5, xmm3
000074703edd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000074703edd5f7c  ptest xmm1, xmm1
000074703edd5f81  jnz 0x000074703EDD8262
000074703edd5f87  vmovaps xmm1, [rsp+0x60]
000074703edd5f8d  vpermilpd xmm1, xmm1, 0x00
000074703edd5f93  movaps xmm6, xmm9
000074703edd5f97  mulpd xmm6, xmm1
000074703edd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000074703edd5fa0  ptest xmm3, xmm3
000074703edd5fa5  jnz 0x000074703EDD83A2
000074703edd5fab  movaps [r15+0x260], xmm6
000074703edd5fb3  vxorps xmm1, xmm1, xmm1
000074703edd5fb7  vpbroadcastq xmm1, xmm1
000074703edd5fbc  movaps [r15+0x1B0], xmm1
000074703edd5fc4  vmovaps xmm1, [rsp+0x60]
000074703edd5fca  vpermilpd xmm1, xmm1, 0x00
000074703edd5fd0  vmovaps xmm3, [rsp+0x70]
000074703edd5fd6  vmovaps [rsp+0x70], xmm15
000074703edd5fdc  movaps xmm9, xmm3
000074703edd5fe0  mulpd xmm9, xmm1
000074703edd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000074703edd5feb  ptest xmm15, xmm15
000074703edd5ff1  jnz 0x000074703EDD84E3
000074703edd5ff7  lea r14, [rax+0xC0]
000074703edd5ffe  movups xmm1, [r13+r14*1]
000074703edd6004  vmovaps xmm3, [rsp+0xC0]
000074703edd600d  vmovaps [rsp+0x80], xmm1
000074703edd6016  movaps xmm15, xmm3
000074703edd601a  addpd xmm15, xmm7
000074703edd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000074703edd6025  ptest xmm1, xmm1
000074703edd602a  jnz 0x000074703EDD862F
000074703edd6030  vmovaps [rsp+0xC0], xmm13
000074703edd6039  vmovaps xmm1, [rsp+0xC0]
000074703edd6042  por xmm13, xmm1
000074703edd6047  movaps [r15+0x270], xmm13
000074703edd604f  vmovaps xmm1, [rsp+0xB0]
000074703edd6058  vmovaps xmm7, [rsp+0xB0]
000074703edd6061  por xmm1, xmm7
000074703edd6065  movaps [r15+0x1A0], xmm1
000074703edd606d  vmovaps xmm1, [rsp+0x60]
000074703edd6073  vpermilpd xmm1, xmm1, 0x00
000074703edd6079  vmovaps [rsp+0xB0], xmm1
000074703edd6082  vmovaps xmm1, [rsp+0x80]
000074703edd608b  vmovaps [rsp+0x80], xmm15
000074703edd6094  vmovaps xmm15, [rsp+0xB0]
000074703edd609d  vmovaps [rsp+0xB0], xmm14
000074703edd60a6  movaps xmm3, xmm1
000074703edd60a9  mulpd xmm3, xmm15
000074703edd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000074703edd60b3  ptest xmm14, xmm14
000074703edd60b9  jnz 0x000074703EDD8771
000074703edd60bf  lea r14, [rax+0x20]
000074703edd60c3  movups xmm1, [r13+r14*1]
000074703edd60c9  movaps [r15+0x110], xmm1
000074703edd60d1  vmovaps xmm14, [rsp+0x70]
000074703edd60d7  vmovaps [rsp+0x70], xmm1
000074703edd60dd  movaps xmm15, xmm14
000074703edd60e1  addpd xmm15, xmm4
000074703edd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000074703edd60ec  ptest xmm1, xmm1
000074703edd60f1  jnz 0x000074703EDD88BC
000074703edd60f7  vmovaps xmm1, [rsp+0x60]
000074703edd60fd  vpermilpd xmm1, xmm1, 0x00
000074703edd6103  movaps xmm14, xmm2
000074703edd6107  mulpd xmm14, xmm1
000074703edd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000074703edd6112  ptest xmm4, xmm4
000074703edd6117  jnz 0x000074703EDD89FF
000074703edd611d  vmovaps xmm4, [rsp+0x50]
000074703edd6123  movaps xmm1, xmm4
000074703edd6126  addpd xmm1, xmm9
000074703edd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000074703edd6130  ptest xmm2, xmm2
000074703edd6135  jnz 0x000074703EDD8B41
000074703edd613b  vmovaps xmm9, [rsp+0x30]
000074703edd6141  vpermilpd xmm9, xmm9, 0x00
000074703edd6147  vmovaps xmm2, [rsp+0x70]
000074703edd614d  vmovaps [rsp+0x50], xmm1
000074703edd6153  movaps xmm4, xmm2
000074703edd6156  mulpd xmm4, xmm9
000074703edd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000074703edd6160  ptest xmm1, xmm1
000074703edd6165  jnz 0x000074703EDD8C82
000074703edd616b  vmovaps xmm1, [rsp+0x30]
000074703edd6171  vpermilpd xmm1, xmm1, 0x00
000074703edd6177  vmovaps xmm2, [rsp+0x90]
000074703edd6180  vmovaps [rsp+0x60], xmm15
000074703edd6186  movaps xmm9, xmm2
000074703edd618a  mulpd xmm9, xmm1
000074703edd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000074703edd6195  ptest xmm15, xmm15
000074703edd619b  jnz 0x000074703EDD8DC3
000074703edd61a1  vmovaps xmm15, [rsp+0x80]
000074703edd61aa  movaps xmm1, xmm15
000074703edd61ae  addpd xmm1, xmm6
000074703edd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000074703edd61b7  ptest xmm2, xmm2
000074703edd61bc  jnz 0x000074703EDD8F05
000074703edd61c2  movaps xmm15, xmm5
000074703edd61c6  addpd xmm15, xmm3
000074703edd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000074703edd61d1  ptest xmm6, xmm6
000074703edd61d6  jnz 0x000074703EDD9046
000074703edd61dc  vmovaps xmm6, [rsp+0x30]
000074703edd61e2  vpermilpd xmm6, xmm6, 0x00
000074703edd61e8  movaps xmm5, xmm8
000074703edd61ec  mulpd xmm5, xmm6
000074703edd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000074703edd61f5  ptest xmm3, xmm3
000074703edd61fa  jnz 0x000074703EDD9188
000074703edd6200  vmovaps xmm8, [rsp+0x30]
000074703edd6206  vpermilpd xmm8, xmm8, 0x00
000074703edd620c  movaps xmm6, xmm10
000074703edd6210  mulpd xmm6, xmm8
000074703edd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000074703edd621a  ptest xmm3, xmm3
000074703edd621f  jnz 0x000074703EDD92C9
000074703edd6225  vmovaps xmm8, [rsp+0x60]
000074703edd622b  movaps xmm10, xmm8
000074703edd622f  addpd xmm10, xmm14
000074703edd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000074703edd623a  ptest xmm3, xmm3
000074703edd623f  jnz 0x000074703EDD940B
000074703edd6245  vmovaps xmm8, [rsp+0x50]
000074703edd624b  movaps xmm14, xmm8
000074703edd624f  addpd xmm14, xmm4
000074703edd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000074703edd625a  ptest xmm3, xmm3
000074703edd625f  jnz 0x000074703EDD954F
000074703edd6265  vmovaps xmm8, [rsp+0x40]
000074703edd626b  vpermilpd xmm8, xmm8, 0x00
000074703edd6271  movaps xmm4, xmm13
000074703edd6275  mulpd xmm4, xmm8
000074703edd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000074703edd627f  ptest xmm3, xmm3
000074703edd6284  jnz 0x000074703EDD9692
000074703edd628a  movaps xmm13, xmm15
000074703edd628e  addpd xmm13, xmm9
000074703edd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000074703edd6299  ptest xmm8, xmm8
000074703edd629f  jnz 0x000074703EDD97D4
000074703edd62a5  movaps xmm15, xmm1
000074703edd62a9  addpd xmm15, xmm5
000074703edd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000074703edd62b4  ptest xmm9, xmm9
000074703edd62ba  jnz 0x000074703EDD9918
000074703edd62c0  vmovaps [rsp+0x30], xmm11
000074703edd62c6  vmovaps xmm1, [rsp+0x30]
000074703edd62cc  por xmm11, xmm1
000074703edd62d1  movaps [r15+0x250], xmm11
000074703edd62d9  vmovaps [rsp+0x30], xmm12
000074703edd62df  vmovaps xmm1, [rsp+0x30]
000074703edd62e5  por xmm12, xmm1
000074703edd62ea  movaps [r15+0x2A0], xmm12
000074703edd62f2  vmovaps xmm1, [rsp+0xA0]
000074703edd62fb  vmovaps xmm11, [rsp+0xA0]
000074703edd6304  por xmm1, xmm11
000074703edd6309  movaps [r15+0x1D0], xmm1
000074703edd6311  lea r14, [rax+0x40]
000074703edd6315  movups xmm1, [r13+r14*1]
000074703edd631b  movaps [r15+0x2C0], xmm1
000074703edd6323  vmovaps xmm11, [rsp+0x40]
000074703edd6329  vpermilpd xmm11, xmm11, 0x00
000074703edd632f  vmovaps xmm8, [rsp+0xE0]
000074703edd6338  movaps xmm9, xmm8
000074703edd633c  mulpd xmm9, xmm11
000074703edd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000074703edd6347  ptest xmm5, xmm5
000074703edd634c  jnz 0x000074703EDD9A64
000074703edd6352  movaps xmm11, xmm10
000074703edd6356  addpd xmm11, xmm6
000074703edd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000074703edd6361  ptest xmm8, xmm8
000074703edd6367  jnz 0x000074703EDD9BA8
000074703edd636d  movaps xmm10, xmm14
000074703edd6371  addpd xmm10, xmm4
000074703edd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000074703edd637c  ptest xmm8, xmm8
000074703edd6382  jnz 0x000074703EDD9CEB
000074703edd6388  vmovaps xmm14, [rsp+0x40]
000074703edd638e  vpermilpd xmm14, xmm14, 0x00
000074703edd6394  movaps xmm8, xmm1
000074703edd6398  mulpd xmm8, xmm14
000074703edd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000074703edd63a3  ptest xmm6, xmm6
000074703edd63a8  jnz 0x000074703EDD9E2E
000074703edd63ae  movaps xmm1, [r15+0x2B0]
000074703edd63b6  vmovaps xmm14, [rsp+0x40]
000074703edd63bc  vpermilpd xmm14, xmm14, 0x00
000074703edd63c2  movaps xmm6, xmm1
000074703edd63c5  mulpd xmm6, xmm14
000074703edd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000074703edd63cf  ptest xmm5, xmm5
000074703edd63d4  jnz 0x000074703EDD9F71
000074703edd63da  vmovaps xmm1, [rsp+0x10]
000074703edd63e0  vpermilpd xmm1, xmm1, 0x00
000074703edd63e6  movaps xmm14, xmm12
000074703edd63ea  mulpd xmm14, xmm1
000074703edd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000074703edd63f5  ptest xmm5, xmm5
000074703edd63fa  jnz 0x000074703EDDA0B2
000074703edd6400  movaps xmm1, xmm13
000074703edd6404  addpd xmm1, xmm9
000074703edd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000074703edd640e  ptest xmm12, xmm12
000074703edd6414  jnz 0x000074703EDDA1F5
000074703edd641a  vmovaps xmm13, [rsp+0x10]
000074703edd6420  vpermilpd xmm13, xmm13, 0x00
000074703edd6426  movaps xmm12, xmm7
000074703edd642a  mulpd xmm12, xmm13
000074703edd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000074703edd6435  ptest xmm9, xmm9
000074703edd643b  jnz 0x000074703EDDA337
000074703edd6441  movaps xmm13, xmm15
000074703edd6445  addpd xmm13, xmm8
000074703edd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000074703edd6450  ptest xmm9, xmm9
000074703edd6456  jnz 0x000074703EDDA47A
000074703edd645c  movaps xmm15, [r15+0x290]
000074703edd6464  vmovaps xmm9, [rsp+0x10]
000074703edd646a  vpermilpd xmm9, xmm9, 0x00
000074703edd6470  movaps xmm8, xmm15
000074703edd6474  mulpd xmm8, xmm9
000074703edd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000074703edd647f  ptest xmm7, xmm7
000074703edd6484  jnz 0x000074703EDDA5BE
000074703edd648a  movaps xmm15, xmm11
000074703edd648e  addpd xmm15, xmm6
000074703edd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000074703edd6499  ptest xmm9, xmm9
000074703edd649f  jnz 0x000074703EDDA702
000074703edd64a5  movaps xmm11, [r15+0x1E0]
000074703edd64ad  vmovaps xmm9, [rsp+0x10]
000074703edd64b3  vpermilpd xmm9, xmm9, 0x00
000074703edd64b9  movaps xmm7, xmm11
000074703edd64bd  mulpd xmm7, xmm9
000074703edd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000074703edd64c7  ptest xmm6, xmm6
000074703edd64cc  jnz 0x000074703EDDA845
000074703edd64d2  movaps xmm11, xmm10
000074703edd64d6  addpd xmm11, xmm14
000074703edd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000074703edd64e1  ptest xmm9, xmm9
000074703edd64e7  jnz 0x000074703EDDA987
000074703edd64ed  lea r14, [rax+0x70]
000074703edd64f1  movups xmm14, [r13+r14*1]
000074703edd64f7  movaps [r15+0x240], xmm14
000074703edd64ff  movaps xmm10, xmm1
000074703edd6503  addpd xmm10, xmm12
000074703edd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000074703edd650e  ptest xmm9, xmm9
000074703edd6514  jnz 0x000074703EDDAAD5
000074703edd651a  movaps [r15+0x170], xmm10
000074703edd6522  vmovaps xmm1, [rsp+0x20]
000074703edd6528  vpermilpd xmm1, xmm1, 0x00
000074703edd652e  movaps xmm12, xmm14
000074703edd6532  mulpd xmm12, xmm1
000074703edd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000074703edd653d  ptest xmm9, xmm9
000074703edd6543  jnz 0x000074703EDDAC18
000074703edd6549  vmovaps xmm1, [rsp+0x20]
000074703edd654f  vpermilpd xmm1, xmm1, 0x00
000074703edd6555  vmovaps xmm9, [rsp+0xB0]
000074703edd655e  movaps xmm14, xmm9
000074703edd6562  mulpd xmm14, xmm1
000074703edd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000074703edd656d  ptest xmm6, xmm6
000074703edd6572  jnz 0x000074703EDDAD5B
000074703edd6578  movaps [r15+0x180], xmm14
000074703edd6580  movaps xmm1, xmm13
000074703edd6584  addpd xmm1, xmm8
000074703edd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000074703edd658e  ptest xmm9, xmm9
000074703edd6594  jnz 0x000074703EDDAE9E
000074703edd659a  movaps [r15+0x210], xmm1
000074703edd65a2  movups xmm13, [r13+rax*1]
000074703edd65a8  lea r14, [rax+0x10]
000074703edd65ac  movups xmm9, [r13+r14*1]
000074703edd65b2  movaps [r15+0x230], xmm9
000074703edd65ba  movaps xmm8, xmm15
000074703edd65be  addpd xmm8, xmm7
000074703edd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000074703edd65c9  ptest xmm6, xmm6
000074703edd65ce  jnz 0x000074703EDDAFF4
000074703edd65d4  movaps [r15+0x130], xmm8
000074703edd65dc  vmovaps xmm15, [rsp+0x20]
000074703edd65e2  vpermilpd xmm15, xmm15, 0x00
000074703edd65e8  movaps xmm7, xmm9
000074703edd65ec  mulpd xmm7, xmm15
000074703edd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000074703edd65f6  ptest xmm6, xmm6
000074703edd65fb  jnz 0x000074703EDDB137
000074703edd6601  movaps [r15+0x220], xmm7
000074703edd6609  vmovaps xmm15, [rsp+0x20]
000074703edd660f  vpermilpd xmm15, xmm15, 0x00
000074703edd6615  movaps xmm9, xmm13
000074703edd6619  mulpd xmm9, xmm15
000074703edd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000074703edd6624  ptest xmm6, xmm6
000074703edd6629  jnz 0x000074703EDDB279
000074703edd662f  movaps xmm15, xmm11
000074703edd6633  addpd xmm15, xmm12
000074703edd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000074703edd663e  ptest xmm13, xmm13
000074703edd6644  jnz 0x000074703EDDB3BD
000074703edd664a  movaps [r15+0x140], xmm15
000074703edd6652  movaps xmm13, xmm10
000074703edd6656  addpd xmm13, xmm14
000074703edd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000074703edd6661  ptest xmm12, xmm12
000074703edd6667  jnz 0x000074703EDDB501
000074703edd666d  movaps [r15+0x150], xmm13
000074703edd6675  movaps xmm14, xmm1
000074703edd6679  addpd xmm14, xmm7
000074703edd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000074703edd6684  ptest xmm12, xmm12
000074703edd668a  jnz 0x000074703EDDB645
000074703edd6690  movaps [r15+0x160], xmm14
000074703edd6698  movaps xmm1, xmm8
000074703edd669c  addpd xmm1, xmm9
000074703edd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000074703edd66a6  ptest xmm12, xmm12
000074703edd66ac  jnz 0x000074703EDDB787
000074703edd66b2  movaps [r15+0x120], xmm1
000074703edd66ba  movups [r13+r11*1], xmm15
000074703edd66c0  lea rax, [r11+0x10]
000074703edd66c4  movups [r13+rax*1], xmm13
000074703edd66ca  lea rax, [r11+0x20]
000074703edd66ce  movups [r13+rax*1], xmm14
000074703edd66d4  lea rax, [r11+0x30]
000074703edd66d8  movups [r13+rax*1], xmm1
000074703edd66de  mov eax, [r15+0x108]
000074703edd66e5  sahf
000074703edd66e6  jnz 0x000074703EDD6718
000074703edd66e8  cmp dword ptr [r15+0x318], 0x00
000074703edd66f0  jz 0x000074703EDDB900
000074703edd66f6  nop [rax+rax*1], ax
000074703edd66ff  nop [rax+rax*1], eax
000074703edd6707  mov eax, 0x410444
000074703edd670c  mov [r15+0x100], rax
000074703edd6713  jmp 0x000074703EBFE110
000074703edd6718  cmp dword ptr [r15+0x318], 0x00
000074703edd6720  jz 0x000074703EDD57E0
000074703edd6726  nop [rax+rax*1], ax
000074703edd672f  nop [rax+rax*1], eax
000074703edd6737  mov eax, 0x410278
000074703edd673c  mov [r15+0x100], rax
000074703edd6743  jmp 0x000074703EBFE110
000074703edd6748  int3
000074703edd6749  call 0x000074703EC0A4B0
000074703edd674e  jmp 0x000074703EDD5828
000074703edd6753  call 0x000074703EC09240
000074703edd6758  jmp 0x000074703EDD5832
000074703edd675d  call 0x000074703EC0A4B0
000074703edd6762  jmp 0x000074703EDD588F
000074703edd6767  call 0x000074703EC09240
000074703edd676c  jmp 0x000074703EDD5899
000074703edd6771  call 0x000074703EC0A4B0
000074703edd6776  jmp 0x000074703EDD58DD
000074703edd677b  call 0x000074703EC09240
000074703edd6780  jmp 0x000074703EDD58E7
000074703edd6785  call 0x000074703ECB47C0
000074703edd678a  jmp 0x000074703EDD5926
000074703edd678f  call 0x000074703EC0B720
000074703edd6794  jmp 0x000074703EDD593A
000074703edd6799  call 0x000074703ECBFC30
000074703edd679e  jmp 0x000074703EDD5958
000074703edd67a3  call 0x000074703ECBE9C0
000074703edd67a8  jmp 0x000074703EDD5962
000074703edd67ad  call 0x000074703ECBD750
000074703edd67b2  jmp 0x000074703EDD596C
000074703edd67b7  sub rsp, 0x08
000074703edd67bb  push rax
000074703edd67bc  push rcx
000074703edd67bd  push rdx
000074703edd67be  push rdi
000074703edd67bf  push rsi
000074703edd67c0  push r8
000074703edd67c2  push r9
000074703edd67c4  push r10
000074703edd67c6  push r11
000074703edd67c8  sub rsp, 0xF0
000074703edd67cf  vmovaps [rsp], xmm0
000074703edd67d4  vmovaps [rsp+0x10], xmm1
000074703edd67da  vmovaps [rsp+0x20], xmm2
000074703edd67e0  vmovaps [rsp+0x30], xmm3
000074703edd67e6  vmovaps [rsp+0x40], xmm4
000074703edd67ec  vmovaps [rsp+0x50], xmm5
000074703edd67f2  vmovaps [rsp+0x60], xmm6
000074703edd67f8  vmovaps [rsp+0x70], xmm7
000074703edd67fe  vmovaps [rsp+0x80], xmm9
000074703edd6807  vmovaps [rsp+0x90], xmm10
000074703edd6810  vmovaps [rsp+0xA0], xmm11
000074703edd6819  vmovaps [rsp+0xB0], xmm12
000074703edd6822  vmovaps [rsp+0xC0], xmm13
000074703edd682b  vmovaps [rsp+0xD0], xmm14
000074703edd6834  vmovaps [rsp+0xE0], xmm15
000074703edd683d  sub rsp, 0x30
000074703edd6841  movaps [rsp], xmm8
000074703edd6846  movaps [rsp+0x10], xmm12
000074703edd684c  movaps [rsp+0x20], xmm15
000074703edd6852  lea rdi, [rsp]
000074703edd6856  mov esi, 0x00
000074703edd685b  mov rax, 0x5D9974CCC530
000074703edd6865  call rax
000074703edd6867  movaps xmm8, [rsp]
000074703edd686c  add rsp, 0x30
000074703edd6870  vmovaps xmm0, [rsp]
000074703edd6875  vmovaps xmm1, [rsp+0x10]
000074703edd687b  vmovaps xmm2, [rsp+0x20]
000074703edd6881  vmovaps xmm3, [rsp+0x30]
000074703edd6887  vmovaps xmm4, [rsp+0x40]
000074703edd688d  vmovaps xmm5, [rsp+0x50]
000074703edd6893  vmovaps xmm6, [rsp+0x60]
000074703edd6899  vmovaps xmm7, [rsp+0x70]
000074703edd689f  vmovaps xmm9, [rsp+0x80]
000074703edd68a8  vmovaps xmm10, [rsp+0x90]
000074703edd68b1  vmovaps xmm11, [rsp+0xA0]
000074703edd68ba  vmovaps xmm12, [rsp+0xB0]
000074703edd68c3  vmovaps xmm13, [rsp+0xC0]
000074703edd68cc  vmovaps xmm14, [rsp+0xD0]
000074703edd68d5  vmovaps xmm15, [rsp+0xE0]
000074703edd68de  add rsp, 0xF0
000074703edd68e5  pop r11
000074703edd68e7  pop r10
000074703edd68e9  pop r9
000074703edd68eb  pop r8
000074703edd68ed  pop rsi
000074703edd68ee  pop rdi
000074703edd68ef  pop rdx
000074703edd68f0  pop rcx
000074703edd68f1  pop rax
000074703edd68f2  add rsp, 0x08
000074703edd68f6  jmp 0x000074703EDD599A
000074703edd68fb  sub rsp, 0x08
000074703edd68ff  push rax
000074703edd6900  push rcx
000074703edd6901  push rdx
000074703edd6902  push rdi
000074703edd6903  push rsi
000074703edd6904  push r8
000074703edd6906  push r9
000074703edd6908  push r10
000074703edd690a  push r11
000074703edd690c  sub rsp, 0xF0
000074703edd6913  vmovaps [rsp], xmm0
000074703edd6918  vmovaps [rsp+0x10], xmm1
000074703edd691e  vmovaps [rsp+0x20], xmm2
000074703edd6924  vmovaps [rsp+0x30], xmm3
000074703edd692a  vmovaps [rsp+0x40], xmm4
000074703edd6930  vmovaps [rsp+0x50], xmm5
000074703edd6936  vmovaps [rsp+0x60], xmm6
000074703edd693c  vmovaps [rsp+0x70], xmm8
000074703edd6942  vmovaps [rsp+0x80], xmm9
000074703edd694b  vmovaps [rsp+0x90], xmm10
000074703edd6954  vmovaps [rsp+0xA0], xmm11
000074703edd695d  vmovaps [rsp+0xB0], xmm12
000074703edd6966  vmovaps [rsp+0xC0], xmm13
000074703edd696f  vmovaps [rsp+0xD0], xmm14
000074703edd6978  vmovaps [rsp+0xE0], xmm15
000074703edd6981  sub rsp, 0x30
000074703edd6985  movaps [rsp], xmm7
000074703edd6989  movaps [rsp+0x10], xmm9
000074703edd698f  movaps [rsp+0x20], xmm15
000074703edd6995  lea rdi, [rsp]
000074703edd6999  mov esi, 0x00
000074703edd699e  mov rax, 0x5D9974CCC530
000074703edd69a8  call rax
000074703edd69aa  movaps xmm7, [rsp]
000074703edd69ae  add rsp, 0x30
000074703edd69b2  vmovaps xmm0, [rsp]
000074703edd69b7  vmovaps xmm1, [rsp+0x10]
000074703edd69bd  vmovaps xmm2, [rsp+0x20]
000074703edd69c3  vmovaps xmm3, [rsp+0x30]
000074703edd69c9  vmovaps xmm4, [rsp+0x40]
000074703edd69cf  vmovaps xmm5, [rsp+0x50]
000074703edd69d5  vmovaps xmm6, [rsp+0x60]
000074703edd69db  vmovaps xmm8, [rsp+0x70]
000074703edd69e1  vmovaps xmm9, [rsp+0x80]
000074703edd69ea  vmovaps xmm10, [rsp+0x90]
000074703edd69f3  vmovaps xmm11, [rsp+0xA0]
000074703edd69fc  vmovaps xmm12, [rsp+0xB0]
000074703edd6a05  vmovaps xmm13, [rsp+0xC0]
000074703edd6a0e  vmovaps xmm14, [rsp+0xD0]
000074703edd6a17  vmovaps xmm15, [rsp+0xE0]
000074703edd6a20  add rsp, 0xF0
000074703edd6a27  pop r11
000074703edd6a29  pop r10
000074703edd6a2b  pop r9
000074703edd6a2d  pop r8
000074703edd6a2f  pop rsi
000074703edd6a30  pop rdi
000074703edd6a31  pop rdx
000074703edd6a32  pop rcx
000074703edd6a33  pop rax
000074703edd6a34  add rsp, 0x08
000074703edd6a38  jmp 0x000074703EDD59C8
000074703edd6a3d  sub rsp, 0x08
000074703edd6a41  push rax
000074703edd6a42  push rcx
000074703edd6a43  push rdx
000074703edd6a44  push rdi
000074703edd6a45  push rsi
000074703edd6a46  push r8
000074703edd6a48  push r9
000074703edd6a4a  push r10
000074703edd6a4c  push r11
000074703edd6a4e  sub rsp, 0xF0
000074703edd6a55  vmovaps [rsp], xmm0
000074703edd6a5a  vmovaps [rsp+0x10], xmm1
000074703edd6a60  vmovaps [rsp+0x20], xmm2
000074703edd6a66  vmovaps [rsp+0x30], xmm3
000074703edd6a6c  vmovaps [rsp+0x40], xmm4
000074703edd6a72  vmovaps [rsp+0x50], xmm5
000074703edd6a78  vmovaps [rsp+0x60], xmm6
000074703edd6a7e  vmovaps [rsp+0x70], xmm7
000074703edd6a84  vmovaps [rsp+0x80], xmm8
000074703edd6a8d  vmovaps [rsp+0x90], xmm10
000074703edd6a96  vmovaps [rsp+0xA0], xmm11
000074703edd6a9f  vmovaps [rsp+0xB0], xmm12
000074703edd6aa8  vmovaps [rsp+0xC0], xmm13
000074703edd6ab1  vmovaps [rsp+0xD0], xmm14
000074703edd6aba  vmovaps [rsp+0xE0], xmm15
000074703edd6ac3  sub rsp, 0x30
000074703edd6ac7  movaps [rsp], xmm9
000074703edd6acc  movaps [rsp+0x10], xmm12
000074703edd6ad2  movaps [rsp+0x20], xmm10
000074703edd6ad8  lea rdi, [rsp]
000074703edd6adc  mov esi, 0x00
000074703edd6ae1  mov rax, 0x5D9974CCC530
000074703edd6aeb  call rax
000074703edd6aed  movaps xmm9, [rsp]
000074703edd6af2  add rsp, 0x30
000074703edd6af6  vmovaps xmm0, [rsp]
000074703edd6afb  vmovaps xmm1, [rsp+0x10]
000074703edd6b01  vmovaps xmm2, [rsp+0x20]
000074703edd6b07  vmovaps xmm3, [rsp+0x30]
000074703edd6b0d  vmovaps xmm4, [rsp+0x40]
000074703edd6b13  vmovaps xmm5, [rsp+0x50]
000074703edd6b19  vmovaps xmm6, [rsp+0x60]
000074703edd6b1f  vmovaps xmm7, [rsp+0x70]
000074703edd6b25  vmovaps xmm8, [rsp+0x80]
000074703edd6b2e  vmovaps xmm10, [rsp+0x90]
000074703edd6b37  vmovaps xmm11, [rsp+0xA0]
000074703edd6b40  vmovaps xmm12, [rsp+0xB0]
000074703edd6b49  vmovaps xmm13, [rsp+0xC0]
000074703edd6b52  vmovaps xmm14, [rsp+0xD0]
000074703edd6b5b  vmovaps xmm15, [rsp+0xE0]
000074703edd6b64  add rsp, 0xF0
000074703edd6b6b  pop r11
000074703edd6b6d  pop r10
000074703edd6b6f  pop r9
000074703edd6b71  pop r8
000074703edd6b73  pop rsi
000074703edd6b74  pop rdi
000074703edd6b75  pop rdx
000074703edd6b76  pop rcx
000074703edd6b77  pop rax
000074703edd6b78  add rsp, 0x08
000074703edd6b7c  jmp 0x000074703EDD59EC
000074703edd6b81  sub rsp, 0x08
000074703edd6b85  push rax
000074703edd6b86  push rcx
000074703edd6b87  push rdx
000074703edd6b88  push rdi
000074703edd6b89  push rsi
000074703edd6b8a  push r8
000074703edd6b8c  push r9
000074703edd6b8e  push r10
000074703edd6b90  push r11
000074703edd6b92  sub rsp, 0xF0
000074703edd6b99  vmovaps [rsp], xmm0
000074703edd6b9e  vmovaps [rsp+0x10], xmm1
000074703edd6ba4  vmovaps [rsp+0x20], xmm2
000074703edd6baa  vmovaps [rsp+0x30], xmm3
000074703edd6bb0  vmovaps [rsp+0x40], xmm4
000074703edd6bb6  vmovaps [rsp+0x50], xmm5
000074703edd6bbc  vmovaps [rsp+0x60], xmm6
000074703edd6bc2  vmovaps [rsp+0x70], xmm7
000074703edd6bc8  vmovaps [rsp+0x80], xmm8
000074703edd6bd1  vmovaps [rsp+0x90], xmm9
000074703edd6bda  vmovaps [rsp+0xA0], xmm11
000074703edd6be3  vmovaps [rsp+0xB0], xmm12
000074703edd6bec  vmovaps [rsp+0xC0], xmm13
000074703edd6bf5  vmovaps [rsp+0xD0], xmm14
000074703edd6bfe  vmovaps [rsp+0xE0], xmm15
000074703edd6c07  sub rsp, 0x30
000074703edd6c0b  movaps [rsp], xmm10
000074703edd6c10  movaps [rsp+0x10], xmm12
000074703edd6c16  movaps [rsp+0x20], xmm11
000074703edd6c1c  lea rdi, [rsp]
000074703edd6c20  mov esi, 0x00
000074703edd6c25  mov rax, 0x5D9974CCC530
000074703edd6c2f  call rax
000074703edd6c31  movaps xmm10, [rsp]
000074703edd6c36  add rsp, 0x30
000074703edd6c3a  vmovaps xmm0, [rsp]
000074703edd6c3f  vmovaps xmm1, [rsp+0x10]
000074703edd6c45  vmovaps xmm2, [rsp+0x20]
000074703edd6c4b  vmovaps xmm3, [rsp+0x30]
000074703edd6c51  vmovaps xmm4, [rsp+0x40]
000074703edd6c57  vmovaps xmm5, [rsp+0x50]
000074703edd6c5d  vmovaps xmm6, [rsp+0x60]
000074703edd6c63  vmovaps xmm7, [rsp+0x70]
000074703edd6c69  vmovaps xmm8, [rsp+0x80]
000074703edd6c72  vmovaps xmm9, [rsp+0x90]
000074703edd6c7b  vmovaps xmm11, [rsp+0xA0]
000074703edd6c84  vmovaps xmm12, [rsp+0xB0]
000074703edd6c8d  vmovaps xmm13, [rsp+0xC0]
000074703edd6c96  vmovaps xmm14, [rsp+0xD0]
000074703edd6c9f  vmovaps xmm15, [rsp+0xE0]
000074703edd6ca8  add rsp, 0xF0
000074703edd6caf  pop r11
000074703edd6cb1  pop r10
000074703edd6cb3  pop r9
000074703edd6cb5  pop r8
000074703edd6cb7  pop rsi
000074703edd6cb8  pop rdi
000074703edd6cb9  pop rdx
000074703edd6cba  pop rcx
000074703edd6cbb  pop rax
000074703edd6cbc  add rsp, 0x08
000074703edd6cc0  jmp 0x000074703EDD5A06
000074703edd6cc5  sub rsp, 0x08
000074703edd6cc9  push rax
000074703edd6cca  push rcx
000074703edd6ccb  push rdx
000074703edd6ccc  push rdi
000074703edd6ccd  push rsi
000074703edd6cce  push r8
000074703edd6cd0  push r9
000074703edd6cd2  push r10
000074703edd6cd4  push r11
000074703edd6cd6  sub rsp, 0xF0
000074703edd6cdd  vmovaps [rsp], xmm0
000074703edd6ce2  vmovaps [rsp+0x10], xmm1
000074703edd6ce8  vmovaps [rsp+0x20], xmm2
000074703edd6cee  vmovaps [rsp+0x30], xmm3
000074703edd6cf4  vmovaps [rsp+0x40], xmm4
000074703edd6cfa  vmovaps [rsp+0x50], xmm5
000074703edd6d00  vmovaps [rsp+0x60], xmm7
000074703edd6d06  vmovaps [rsp+0x70], xmm8
000074703edd6d0c  vmovaps [rsp+0x80], xmm9
000074703edd6d15  vmovaps [rsp+0x90], xmm10
000074703edd6d1e  vmovaps [rsp+0xA0], xmm11
000074703edd6d27  vmovaps [rsp+0xB0], xmm12
000074703edd6d30  vmovaps [rsp+0xC0], xmm13
000074703edd6d39  vmovaps [rsp+0xD0], xmm14
000074703edd6d42  vmovaps [rsp+0xE0], xmm15
000074703edd6d4b  sub rsp, 0x30
000074703edd6d4f  movaps [rsp], xmm6
000074703edd6d53  movaps [rsp+0x10], xmm12
000074703edd6d59  movaps [rsp+0x20], xmm11
000074703edd6d5f  lea rdi, [rsp]
000074703edd6d63  mov esi, 0x00
000074703edd6d68  mov rax, 0x5D9974CCC530
000074703edd6d72  call rax
000074703edd6d74  movaps xmm6, [rsp]
000074703edd6d78  add rsp, 0x30
000074703edd6d7c  vmovaps xmm0, [rsp]
000074703edd6d81  vmovaps xmm1, [rsp+0x10]
000074703edd6d87  vmovaps xmm2, [rsp+0x20]
000074703edd6d8d  vmovaps xmm3, [rsp+0x30]
000074703edd6d93  vmovaps xmm4, [rsp+0x40]
000074703edd6d99  vmovaps xmm5, [rsp+0x50]
000074703edd6d9f  vmovaps xmm7, [rsp+0x60]
000074703edd6da5  vmovaps xmm8, [rsp+0x70]
000074703edd6dab  vmovaps xmm9, [rsp+0x80]
000074703edd6db4  vmovaps xmm10, [rsp+0x90]
000074703edd6dbd  vmovaps xmm11, [rsp+0xA0]
000074703edd6dc6  vmovaps xmm12, [rsp+0xB0]
000074703edd6dcf  vmovaps xmm13, [rsp+0xC0]
000074703edd6dd8  vmovaps xmm14, [rsp+0xD0]
000074703edd6de1  vmovaps xmm15, [rsp+0xE0]
000074703edd6dea  add rsp, 0xF0
000074703edd6df1  pop r11
000074703edd6df3  pop r10
000074703edd6df5  pop r9
000074703edd6df7  pop r8
000074703edd6df9  pop rsi
000074703edd6dfa  pop rdi
000074703edd6dfb  pop rdx
000074703edd6dfc  pop rcx
000074703edd6dfd  pop rax
000074703edd6dfe  add rsp, 0x08
000074703edd6e02  jmp 0x000074703EDD5A27
000074703edd6e07  sub rsp, 0x08
000074703edd6e0b  push rax
000074703edd6e0c  push rcx
000074703edd6e0d  push rdx
000074703edd6e0e  push rdi
000074703edd6e0f  push rsi
000074703edd6e10  push r8
000074703edd6e12  push r9
000074703edd6e14  push r10
000074703edd6e16  push r11
000074703edd6e18  sub rsp, 0xF0
000074703edd6e1f  vmovaps [rsp], xmm0
000074703edd6e24  vmovaps [rsp+0x10], xmm1
000074703edd6e2a  vmovaps [rsp+0x20], xmm2
000074703edd6e30  vmovaps [rsp+0x30], xmm4
000074703edd6e36  vmovaps [rsp+0x40], xmm5
000074703edd6e3c  vmovaps [rsp+0x50], xmm6
000074703edd6e42  vmovaps [rsp+0x60], xmm7
000074703edd6e48  vmovaps [rsp+0x70], xmm8
000074703edd6e4e  vmovaps [rsp+0x80], xmm9
000074703edd6e57  vmovaps [rsp+0x90], xmm10
000074703edd6e60  vmovaps [rsp+0xA0], xmm11
000074703edd6e69  vmovaps [rsp+0xB0], xmm12
000074703edd6e72  vmovaps [rsp+0xC0], xmm13
000074703edd6e7b  vmovaps [rsp+0xD0], xmm14
000074703edd6e84  vmovaps [rsp+0xE0], xmm15
000074703edd6e8d  sub rsp, 0x30
000074703edd6e91  movaps [rsp], xmm3
000074703edd6e95  movaps [rsp+0x10], xmm5
000074703edd6e9a  movaps [rsp+0x20], xmm4
000074703edd6e9f  lea rdi, [rsp]
000074703edd6ea3  mov esi, 0x00
000074703edd6ea8  mov rax, 0x5D9974CCC530
000074703edd6eb2  call rax
000074703edd6eb4  movaps xmm3, [rsp]
000074703edd6eb8  add rsp, 0x30
000074703edd6ebc  vmovaps xmm0, [rsp]
000074703edd6ec1  vmovaps xmm1, [rsp+0x10]
000074703edd6ec7  vmovaps xmm2, [rsp+0x20]
000074703edd6ecd  vmovaps xmm4, [rsp+0x30]
000074703edd6ed3  vmovaps xmm5, [rsp+0x40]
000074703edd6ed9  vmovaps xmm6, [rsp+0x50]
000074703edd6edf  vmovaps xmm7, [rsp+0x60]
000074703edd6ee5  vmovaps xmm8, [rsp+0x70]
000074703edd6eeb  vmovaps xmm9, [rsp+0x80]
000074703edd6ef4  vmovaps xmm10, [rsp+0x90]
000074703edd6efd  vmovaps xmm11, [rsp+0xA0]
000074703edd6f06  vmovaps xmm12, [rsp+0xB0]
000074703edd6f0f  vmovaps xmm13, [rsp+0xC0]
000074703edd6f18  vmovaps xmm14, [rsp+0xD0]
000074703edd6f21  vmovaps xmm15, [rsp+0xE0]
000074703edd6f2a  add rsp, 0xF0
000074703edd6f31  pop r11
000074703edd6f33  pop r10
000074703edd6f35  pop r9
000074703edd6f37  pop r8
000074703edd6f39  pop rsi
000074703edd6f3a  pop rdi
000074703edd6f3b  pop rdx
000074703edd6f3c  pop rcx
000074703edd6f3d  pop rax
000074703edd6f3e  add rsp, 0x08
000074703edd6f42  jmp 0x000074703EDD5A88
000074703edd6f47  sub rsp, 0x08
000074703edd6f4b  push rax
000074703edd6f4c  push rcx
000074703edd6f4d  push rdx
000074703edd6f4e  push rdi
000074703edd6f4f  push rsi
000074703edd6f50  push r8
000074703edd6f52  push r9
000074703edd6f54  push r10
000074703edd6f56  push r11
000074703edd6f58  sub rsp, 0xF0
000074703edd6f5f  vmovaps [rsp], xmm0
000074703edd6f64  vmovaps [rsp+0x10], xmm1
000074703edd6f6a  vmovaps [rsp+0x20], xmm2
000074703edd6f70  vmovaps [rsp+0x30], xmm3
000074703edd6f76  vmovaps [rsp+0x40], xmm4
000074703edd6f7c  vmovaps [rsp+0x50], xmm6
000074703edd6f82  vmovaps [rsp+0x60], xmm7
000074703edd6f88  vmovaps [rsp+0x70], xmm8
000074703edd6f8e  vmovaps [rsp+0x80], xmm9
000074703edd6f97  vmovaps [rsp+0x90], xmm10
000074703edd6fa0  vmovaps [rsp+0xA0], xmm11
000074703edd6fa9  vmovaps [rsp+0xB0], xmm12
000074703edd6fb2  vmovaps [rsp+0xC0], xmm13
000074703edd6fbb  vmovaps [rsp+0xD0], xmm14
000074703edd6fc4  vmovaps [rsp+0xE0], xmm15
000074703edd6fcd  sub rsp, 0x30
000074703edd6fd1  movaps [rsp], xmm5
000074703edd6fd5  movaps [rsp+0x10], xmm8
000074703edd6fdb  movaps [rsp+0x20], xmm15
000074703edd6fe1  lea rdi, [rsp]
000074703edd6fe5  mov esi, 0x00
000074703edd6fea  mov rax, 0x5D9974CCC530
000074703edd6ff4  call rax
000074703edd6ff6  movaps xmm5, [rsp]
000074703edd6ffa  add rsp, 0x30
000074703edd6ffe  vmovaps xmm0, [rsp]
000074703edd7003  vmovaps xmm1, [rsp+0x10]
000074703edd7009  vmovaps xmm2, [rsp+0x20]
000074703edd700f  vmovaps xmm3, [rsp+0x30]
000074703edd7015  vmovaps xmm4, [rsp+0x40]
000074703edd701b  vmovaps xmm6, [rsp+0x50]
000074703edd7021  vmovaps xmm7, [rsp+0x60]
000074703edd7027  vmovaps xmm8, [rsp+0x70]
000074703edd702d  vmovaps xmm9, [rsp+0x80]
000074703edd7036  vmovaps xmm10, [rsp+0x90]
000074703edd703f  vmovaps xmm11, [rsp+0xA0]
000074703edd7048  vmovaps xmm12, [rsp+0xB0]
000074703edd7051  vmovaps xmm13, [rsp+0xC0]
000074703edd705a  vmovaps xmm14, [rsp+0xD0]
000074703edd7063  vmovaps xmm15, [rsp+0xE0]
000074703edd706c  add rsp, 0xF0
000074703edd7073  pop r11
000074703edd7075  pop r10
000074703edd7077  pop r9
000074703edd7079  pop r8
000074703edd707b  pop rsi
000074703edd707c  pop rdi
000074703edd707d  pop rdx
000074703edd707e  pop rcx
000074703edd707f  pop rax
000074703edd7080  add rsp, 0x08
000074703edd7084  jmp 0x000074703EDD5AC0
000074703edd7089  sub rsp, 0x08
000074703edd708d  push rax
000074703edd708e  push rcx
000074703edd708f  push rdx
000074703edd7090  push rdi
000074703edd7091  push rsi
000074703edd7092  push r8
000074703edd7094  push r9
000074703edd7096  push r10
000074703edd7098  push r11
000074703edd709a  sub rsp, 0xF0
000074703edd70a1  vmovaps [rsp], xmm0
000074703edd70a6  vmovaps [rsp+0x10], xmm1
000074703edd70ac  vmovaps [rsp+0x20], xmm2
000074703edd70b2  vmovaps [rsp+0x30], xmm3
000074703edd70b8  vmovaps [rsp+0x40], xmm5
000074703edd70be  vmovaps [rsp+0x50], xmm6
000074703edd70c4  vmovaps [rsp+0x60], xmm7
000074703edd70ca  vmovaps [rsp+0x70], xmm8
000074703edd70d0  vmovaps [rsp+0x80], xmm9
000074703edd70d9  vmovaps [rsp+0x90], xmm10
000074703edd70e2  vmovaps [rsp+0xA0], xmm11
000074703edd70eb  vmovaps [rsp+0xB0], xmm12
000074703edd70f4  vmovaps [rsp+0xC0], xmm13
000074703edd70fd  vmovaps [rsp+0xD0], xmm14
000074703edd7106  vmovaps [rsp+0xE0], xmm15
000074703edd710f  sub rsp, 0x30
000074703edd7113  movaps [rsp], xmm4
000074703edd7117  movaps [rsp+0x10], xmm9
000074703edd711d  movaps [rsp+0x20], xmm8
000074703edd7123  lea rdi, [rsp]
000074703edd7127  mov esi, 0x00
000074703edd712c  mov rax, 0x5D9974CCC530
000074703edd7136  call rax
000074703edd7138  movaps xmm4, [rsp]
000074703edd713c  add rsp, 0x30
000074703edd7140  vmovaps xmm0, [rsp]
000074703edd7145  vmovaps xmm1, [rsp+0x10]
000074703edd714b  vmovaps xmm2, [rsp+0x20]
000074703edd7151  vmovaps xmm3, [rsp+0x30]
000074703edd7157  vmovaps xmm5, [rsp+0x40]
000074703edd715d  vmovaps xmm6, [rsp+0x50]
000074703edd7163  vmovaps xmm7, [rsp+0x60]
000074703edd7169  vmovaps xmm8, [rsp+0x70]
000074703edd716f  vmovaps xmm9, [rsp+0x80]
000074703edd7178  vmovaps xmm10, [rsp+0x90]
000074703edd7181  vmovaps xmm11, [rsp+0xA0]
000074703edd718a  vmovaps xmm12, [rsp+0xB0]
000074703edd7193  vmovaps xmm13, [rsp+0xC0]
000074703edd719c  vmovaps xmm14, [rsp+0xD0]
000074703edd71a5  vmovaps xmm15, [rsp+0xE0]
000074703edd71ae  add rsp, 0xF0
000074703edd71b5  pop r11
000074703edd71b7  pop r10
000074703edd71b9  pop r9
000074703edd71bb  pop r8
000074703edd71bd  pop rsi
000074703edd71be  pop rdi
000074703edd71bf  pop rdx
000074703edd71c0  pop rcx
000074703edd71c1  pop rax
000074703edd71c2  add rsp, 0x08
000074703edd71c6  jmp 0x000074703EDD5AE1
000074703edd71cb  sub rsp, 0x08
000074703edd71cf  push rax
000074703edd71d0  push rcx
000074703edd71d1  push rdx
000074703edd71d2  push rdi
000074703edd71d3  push rsi
000074703edd71d4  push r8
000074703edd71d6  push r9
000074703edd71d8  push r10
000074703edd71da  push r11
000074703edd71dc  sub rsp, 0xF0
000074703edd71e3  vmovaps [rsp], xmm0
000074703edd71e8  vmovaps [rsp+0x10], xmm1
000074703edd71ee  vmovaps [rsp+0x20], xmm2
000074703edd71f4  vmovaps [rsp+0x30], xmm3
000074703edd71fa  vmovaps [rsp+0x40], xmm4
000074703edd7200  vmovaps [rsp+0x50], xmm5
000074703edd7206  vmovaps [rsp+0x60], xmm6
000074703edd720c  vmovaps [rsp+0x70], xmm7
000074703edd7212  vmovaps [rsp+0x80], xmm8
000074703edd721b  vmovaps [rsp+0x90], xmm10
000074703edd7224  vmovaps [rsp+0xA0], xmm11
000074703edd722d  vmovaps [rsp+0xB0], xmm12
000074703edd7236  vmovaps [rsp+0xC0], xmm13
000074703edd723f  vmovaps [rsp+0xD0], xmm14
000074703edd7248  vmovaps [rsp+0xE0], xmm15
000074703edd7251  sub rsp, 0x30
000074703edd7255  movaps [rsp], xmm9
000074703edd725a  movaps [rsp+0x10], xmm10
000074703edd7260  movaps [rsp+0x20], xmm8
000074703edd7266  lea rdi, [rsp]
000074703edd726a  mov esi, 0x00
000074703edd726f  mov rax, 0x5D9974CCC530
000074703edd7279  call rax
000074703edd727b  movaps xmm9, [rsp]
000074703edd7280  add rsp, 0x30
000074703edd7284  vmovaps xmm0, [rsp]
000074703edd7289  vmovaps xmm1, [rsp+0x10]
000074703edd728f  vmovaps xmm2, [rsp+0x20]
000074703edd7295  vmovaps xmm3, [rsp+0x30]
000074703edd729b  vmovaps xmm4, [rsp+0x40]
000074703edd72a1  vmovaps xmm5, [rsp+0x50]
000074703edd72a7  vmovaps xmm6, [rsp+0x60]
000074703edd72ad  vmovaps xmm7, [rsp+0x70]
000074703edd72b3  vmovaps xmm8, [rsp+0x80]
000074703edd72bc  vmovaps xmm10, [rsp+0x90]
000074703edd72c5  vmovaps xmm11, [rsp+0xA0]
000074703edd72ce  vmovaps xmm12, [rsp+0xB0]
000074703edd72d7  vmovaps xmm13, [rsp+0xC0]
000074703edd72e0  vmovaps xmm14, [rsp+0xD0]
000074703edd72e9  vmovaps xmm15, [rsp+0xE0]
000074703edd72f2  add rsp, 0xF0
000074703edd72f9  pop r11
000074703edd72fb  pop r10
000074703edd72fd  pop r9
000074703edd72ff  pop r8
000074703edd7301  pop rsi
000074703edd7302  pop rdi
000074703edd7303  pop rdx
000074703edd7304  pop rcx
000074703edd7305  pop rax
000074703edd7306  add rsp, 0x08
000074703edd730a  jmp 0x000074703EDD5AFB
000074703edd730f  call 0x000074703ECD64F0
000074703edd7314  jmp 0x000074703EDD5C15
000074703edd7319  call 0x000074703ECD64F0
000074703edd731e  jmp 0x000074703EDD5C2B
000074703edd7323  sub rsp, 0x08
000074703edd7327  push rax
000074703edd7328  push rcx
000074703edd7329  push rdx
000074703edd732a  push rdi
000074703edd732b  push rsi
000074703edd732c  push r8
000074703edd732e  push r9
000074703edd7330  push r10
000074703edd7332  push r11
000074703edd7334  sub rsp, 0xF0
000074703edd733b  vmovaps [rsp], xmm0
000074703edd7340  vmovaps [rsp+0x10], xmm2
000074703edd7346  vmovaps [rsp+0x20], xmm3
000074703edd734c  vmovaps [rsp+0x30], xmm4
000074703edd7352  vmovaps [rsp+0x40], xmm5
000074703edd7358  vmovaps [rsp+0x50], xmm6
000074703edd735e  vmovaps [rsp+0x60], xmm7
000074703edd7364  vmovaps [rsp+0x70], xmm8
000074703edd736a  vmovaps [rsp+0x80], xmm9
000074703edd7373  vmovaps [rsp+0x90], xmm10
000074703edd737c  vmovaps [rsp+0xA0], xmm11
000074703edd7385  vmovaps [rsp+0xB0], xmm12
000074703edd738e  vmovaps [rsp+0xC0], xmm13
000074703edd7397  vmovaps [rsp+0xD0], xmm14
000074703edd73a0  vmovaps [rsp+0xE0], xmm15
000074703edd73a9  sub rsp, 0x30
000074703edd73ad  movaps [rsp], xmm1
000074703edd73b1  movaps [rsp+0x10], xmm6
000074703edd73b6  movaps [rsp+0x20], xmm15
000074703edd73bc  lea rdi, [rsp]
000074703edd73c0  mov esi, 0x00
000074703edd73c5  mov rax, 0x5D9974CCC530
000074703edd73cf  call rax
000074703edd73d1  movaps xmm1, [rsp]
000074703edd73d5  add rsp, 0x30
000074703edd73d9  vmovaps xmm0, [rsp]
000074703edd73de  vmovaps xmm2, [rsp+0x10]
000074703edd73e4  vmovaps xmm3, [rsp+0x20]
000074703edd73ea  vmovaps xmm4, [rsp+0x30]
000074703edd73f0  vmovaps xmm5, [rsp+0x40]
000074703edd73f6  vmovaps xmm6, [rsp+0x50]
000074703edd73fc  vmovaps xmm7, [rsp+0x60]
000074703edd7402  vmovaps xmm8, [rsp+0x70]
000074703edd7408  vmovaps xmm9, [rsp+0x80]
000074703edd7411  vmovaps xmm10, [rsp+0x90]
000074703edd741a  vmovaps xmm11, [rsp+0xA0]
000074703edd7423  vmovaps xmm12, [rsp+0xB0]
000074703edd742c  vmovaps xmm13, [rsp+0xC0]
000074703edd7435  vmovaps xmm14, [rsp+0xD0]
000074703edd743e  vmovaps xmm15, [rsp+0xE0]
000074703edd7447  add rsp, 0xF0
000074703edd744e  pop r11
000074703edd7450  pop r10
000074703edd7452  pop r9
000074703edd7454  pop r8
000074703edd7456  pop rsi
000074703edd7457  pop rdi
000074703edd7458  pop rdx
000074703edd7459  pop rcx
000074703edd745a  pop rax
000074703edd745b  add rsp, 0x08
000074703edd745f  jmp 0x000074703EDD5C68
000074703edd7464  call 0x000074703ECE5820
000074703edd7469  jmp 0x000074703EDD5C75
000074703edd746e  sub rsp, 0x08
000074703edd7472  push rax
000074703edd7473  push rcx
000074703edd7474  push rdx
000074703edd7475  push rdi
000074703edd7476  push rsi
000074703edd7477  push r8
000074703edd7479  push r9
000074703edd747b  push r10
000074703edd747d  push r11
000074703edd747f  sub rsp, 0xF0
000074703edd7486  vmovaps [rsp], xmm0
000074703edd748b  vmovaps [rsp+0x10], xmm1
000074703edd7491  vmovaps [rsp+0x20], xmm2
000074703edd7497  vmovaps [rsp+0x30], xmm3
000074703edd749d  vmovaps [rsp+0x40], xmm4
000074703edd74a3  vmovaps [rsp+0x50], xmm5
000074703edd74a9  vmovaps [rsp+0x60], xmm6
000074703edd74af  vmovaps [rsp+0x70], xmm7
000074703edd74b5  vmovaps [rsp+0x80], xmm8
000074703edd74be  vmovaps [rsp+0x90], xmm9
000074703edd74c7  vmovaps [rsp+0xA0], xmm10
000074703edd74d0  vmovaps [rsp+0xB0], xmm11
000074703edd74d9  vmovaps [rsp+0xC0], xmm12
000074703edd74e2  vmovaps [rsp+0xD0], xmm13
000074703edd74eb  vmovaps [rsp+0xE0], xmm15
000074703edd74f4  sub rsp, 0x30
000074703edd74f8  movaps [rsp], xmm14
000074703edd74fd  movaps [rsp+0x10], xmm4
000074703edd7502  movaps [rsp+0x20], xmm3
000074703edd7507  lea rdi, [rsp]
000074703edd750b  mov esi, 0x00
000074703edd7510  mov rax, 0x5D9974CCC530
000074703edd751a  call rax
000074703edd751c  movaps xmm14, [rsp]
000074703edd7521  add rsp, 0x30
000074703edd7525  vmovaps xmm0, [rsp]
000074703edd752a  vmovaps xmm1, [rsp+0x10]
000074703edd7530  vmovaps xmm2, [rsp+0x20]
000074703edd7536  vmovaps xmm3, [rsp+0x30]
000074703edd753c  vmovaps xmm4, [rsp+0x40]
000074703edd7542  vmovaps xmm5, [rsp+0x50]
000074703edd7548  vmovaps xmm6, [rsp+0x60]
000074703edd754e  vmovaps xmm7, [rsp+0x70]
000074703edd7554  vmovaps xmm8, [rsp+0x80]
000074703edd755d  vmovaps xmm9, [rsp+0x90]
000074703edd7566  vmovaps xmm10, [rsp+0xA0]
000074703edd756f  vmovaps xmm11, [rsp+0xB0]
000074703edd7578  vmovaps xmm12, [rsp+0xC0]
000074703edd7581  vmovaps xmm13, [rsp+0xD0]
000074703edd758a  vmovaps xmm15, [rsp+0xE0]
000074703edd7593  add rsp, 0xF0
000074703edd759a  pop r11
000074703edd759c  pop r10
000074703edd759e  pop r9
000074703edd75a0  pop r8
000074703edd75a2  pop rsi
000074703edd75a3  pop rdi
000074703edd75a4  pop rdx
000074703edd75a5  pop rcx
000074703edd75a6  pop rax
000074703edd75a7  add rsp, 0x08
000074703edd75ab  jmp 0x000074703EDD5C8F
000074703edd75b0  sub rsp, 0x08
000074703edd75b4  push rax
000074703edd75b5  push rcx
000074703edd75b6  push rdx
000074703edd75b7  push rdi
000074703edd75b8  push rsi
000074703edd75b9  push r8
000074703edd75bb  push r9
000074703edd75bd  push r10
000074703edd75bf  push r11
000074703edd75c1  sub rsp, 0xF0
000074703edd75c8  vmovaps [rsp], xmm0
000074703edd75cd  vmovaps [rsp+0x10], xmm1
000074703edd75d3  vmovaps [rsp+0x20], xmm2
000074703edd75d9  vmovaps [rsp+0x30], xmm3
000074703edd75df  vmovaps [rsp+0x40], xmm4
000074703edd75e5  vmovaps [rsp+0x50], xmm5
000074703edd75eb  vmovaps [rsp+0x60], xmm7
000074703edd75f1  vmovaps [rsp+0x70], xmm8
000074703edd75f7  vmovaps [rsp+0x80], xmm9
000074703edd7600  vmovaps [rsp+0x90], xmm10
000074703edd7609  vmovaps [rsp+0xA0], xmm11
000074703edd7612  vmovaps [rsp+0xB0], xmm12
000074703edd761b  vmovaps [rsp+0xC0], xmm13
000074703edd7624  vmovaps [rsp+0xD0], xmm14
000074703edd762d  vmovaps [rsp+0xE0], xmm15
000074703edd7636  sub rsp, 0x30
000074703edd763a  movaps [rsp], xmm6
000074703edd763e  movaps [rsp+0x10], xmm9
000074703edd7644  movaps [rsp+0x20], xmm7
000074703edd7649  lea rdi, [rsp]
000074703edd764d  mov esi, 0x00
000074703edd7652  mov rax, 0x5D9974CCC530
000074703edd765c  call rax
000074703edd765e  movaps xmm6, [rsp]
000074703edd7662  add rsp, 0x30
000074703edd7666  vmovaps xmm0, [rsp]
000074703edd766b  vmovaps xmm1, [rsp+0x10]
000074703edd7671  vmovaps xmm2, [rsp+0x20]
000074703edd7677  vmovaps xmm3, [rsp+0x30]
000074703edd767d  vmovaps xmm4, [rsp+0x40]
000074703edd7683  vmovaps xmm5, [rsp+0x50]
000074703edd7689  vmovaps xmm7, [rsp+0x60]
000074703edd768f  vmovaps xmm8, [rsp+0x70]
000074703edd7695  vmovaps xmm9, [rsp+0x80]
000074703edd769e  vmovaps xmm10, [rsp+0x90]
000074703edd76a7  vmovaps xmm11, [rsp+0xA0]
000074703edd76b0  vmovaps xmm12, [rsp+0xB0]
000074703edd76b9  vmovaps xmm13, [rsp+0xC0]
000074703edd76c2  vmovaps xmm14, [rsp+0xD0]
000074703edd76cb  vmovaps xmm15, [rsp+0xE0]
000074703edd76d4  add rsp, 0xF0
000074703edd76db  pop r11
000074703edd76dd  pop r10
000074703edd76df  pop r9
000074703edd76e1  pop r8
000074703edd76e3  pop rsi
000074703edd76e4  pop rdi
000074703edd76e5  pop rdx
000074703edd76e6  pop rcx
000074703edd76e7  pop rax
000074703edd76e8  add rsp, 0x08
000074703edd76ec  jmp 0x000074703EDD5CA7
000074703edd76f1  sub rsp, 0x08
000074703edd76f5  push rax
000074703edd76f6  push rcx
000074703edd76f7  push rdx
000074703edd76f8  push rdi
000074703edd76f9  push rsi
000074703edd76fa  push r8
000074703edd76fc  push r9
000074703edd76fe  push r10
000074703edd7700  push r11
000074703edd7702  sub rsp, 0xF0
000074703edd7709  vmovaps [rsp], xmm0
000074703edd770e  vmovaps [rsp+0x10], xmm1
000074703edd7714  vmovaps [rsp+0x20], xmm2
000074703edd771a  vmovaps [rsp+0x30], xmm3
000074703edd7720  vmovaps [rsp+0x40], xmm4
000074703edd7726  vmovaps [rsp+0x50], xmm5
000074703edd772c  vmovaps [rsp+0x60], xmm6
000074703edd7732  vmovaps [rsp+0x70], xmm8
000074703edd7738  vmovaps [rsp+0x80], xmm9
000074703edd7741  vmovaps [rsp+0x90], xmm10
000074703edd774a  vmovaps [rsp+0xA0], xmm11
000074703edd7753  vmovaps [rsp+0xB0], xmm12
000074703edd775c  vmovaps [rsp+0xC0], xmm13
000074703edd7765  vmovaps [rsp+0xD0], xmm14
000074703edd776e  vmovaps [rsp+0xE0], xmm15
000074703edd7777  sub rsp, 0x30
000074703edd777b  movaps [rsp], xmm7
000074703edd777f  movaps [rsp+0x10], xmm4
000074703edd7784  movaps [rsp+0x20], xmm9
000074703edd778a  lea rdi, [rsp]
000074703edd778e  mov esi, 0x00
000074703edd7793  mov rax, 0x5D9974CCC530
000074703edd779d  call rax
000074703edd779f  movaps xmm7, [rsp]
000074703edd77a3  add rsp, 0x30
000074703edd77a7  vmovaps xmm0, [rsp]
000074703edd77ac  vmovaps xmm1, [rsp+0x10]
000074703edd77b2  vmovaps xmm2, [rsp+0x20]
000074703edd77b8  vmovaps xmm3, [rsp+0x30]
000074703edd77be  vmovaps xmm4, [rsp+0x40]
000074703edd77c4  vmovaps xmm5, [rsp+0x50]
000074703edd77ca  vmovaps xmm6, [rsp+0x60]
000074703edd77d0  vmovaps xmm8, [rsp+0x70]
000074703edd77d6  vmovaps xmm9, [rsp+0x80]
000074703edd77df  vmovaps xmm10, [rsp+0x90]
000074703edd77e8  vmovaps xmm11, [rsp+0xA0]
000074703edd77f1  vmovaps xmm12, [rsp+0xB0]
000074703edd77fa  vmovaps xmm13, [rsp+0xC0]
000074703edd7803  vmovaps xmm14, [rsp+0xD0]
000074703edd780c  vmovaps xmm15, [rsp+0xE0]
000074703edd7815  add rsp, 0xF0
000074703edd781c  pop r11
000074703edd781e  pop r10
000074703edd7820  pop r9
000074703edd7822  pop r8
000074703edd7824  pop rsi
000074703edd7825  pop rdi
000074703edd7826  pop rdx
000074703edd7827  pop rcx
000074703edd7828  pop rax
000074703edd7829  add rsp, 0x08
000074703edd782d  jmp 0x000074703EDD5CD4
000074703edd7832  sub rsp, 0x08
000074703edd7836  push rax
000074703edd7837  push rcx
000074703edd7838  push rdx
000074703edd7839  push rdi
000074703edd783a  push rsi
000074703edd783b  push r8
000074703edd783d  push r9
000074703edd783f  push r10
000074703edd7841  push r11
000074703edd7843  sub rsp, 0xF0
000074703edd784a  vmovaps [rsp], xmm0
000074703edd784f  vmovaps [rsp+0x10], xmm1
000074703edd7855  vmovaps [rsp+0x20], xmm2
000074703edd785b  vmovaps [rsp+0x30], xmm3
000074703edd7861  vmovaps [rsp+0x40], xmm5
000074703edd7867  vmovaps [rsp+0x50], xmm6
000074703edd786d  vmovaps [rsp+0x60], xmm7
000074703edd7873  vmovaps [rsp+0x70], xmm8
000074703edd7879  vmovaps [rsp+0x80], xmm9
000074703edd7882  vmovaps [rsp+0x90], xmm10
000074703edd788b  vmovaps [rsp+0xA0], xmm11
000074703edd7894  vmovaps [rsp+0xB0], xmm12
000074703edd789d  vmovaps [rsp+0xC0], xmm13
000074703edd78a6  vmovaps [rsp+0xD0], xmm14
000074703edd78af  vmovaps [rsp+0xE0], xmm15
000074703edd78b8  sub rsp, 0x30
000074703edd78bc  movaps [rsp], xmm4
000074703edd78c0  movaps [rsp+0x10], xmm15
000074703edd78c6  movaps [rsp+0x20], xmm9
000074703edd78cc  lea rdi, [rsp]
000074703edd78d0  mov esi, 0x00
000074703edd78d5  mov rax, 0x5D9974CCC530
000074703edd78df  call rax
000074703edd78e1  movaps xmm4, [rsp]
000074703edd78e5  add rsp, 0x30
000074703edd78e9  vmovaps xmm0, [rsp]
000074703edd78ee  vmovaps xmm1, [rsp+0x10]
000074703edd78f4  vmovaps xmm2, [rsp+0x20]
000074703edd78fa  vmovaps xmm3, [rsp+0x30]
000074703edd7900  vmovaps xmm5, [rsp+0x40]
000074703edd7906  vmovaps xmm6, [rsp+0x50]
000074703edd790c  vmovaps xmm7, [rsp+0x60]
000074703edd7912  vmovaps xmm8, [rsp+0x70]
000074703edd7918  vmovaps xmm9, [rsp+0x80]
000074703edd7921  vmovaps xmm10, [rsp+0x90]
000074703edd792a  vmovaps xmm11, [rsp+0xA0]
000074703edd7933  vmovaps xmm12, [rsp+0xB0]
000074703edd793c  vmovaps xmm13, [rsp+0xC0]
000074703edd7945  vmovaps xmm14, [rsp+0xD0]
000074703edd794e  vmovaps xmm15, [rsp+0xE0]
000074703edd7957  add rsp, 0xF0
000074703edd795e  pop r11
000074703edd7960  pop r10
000074703edd7962  pop r9
000074703edd7964  pop r8
000074703edd7966  pop rsi
000074703edd7967  pop rdi
000074703edd7968  pop rdx
000074703edd7969  pop rcx
000074703edd796a  pop rax
000074703edd796b  add rsp, 0x08
000074703edd796f  jmp 0x000074703EDD5CF9
000074703edd7974  call 0x000074703ECE5820
000074703edd7979  jmp 0x000074703EDD5D06
000074703edd797e  sub rsp, 0x08
000074703edd7982  push rax
000074703edd7983  push rcx
000074703edd7984  push rdx
000074703edd7985  push rdi
000074703edd7986  push rsi
000074703edd7987  push r8
000074703edd7989  push r9
000074703edd798b  push r10
000074703edd798d  push r11
000074703edd798f  sub rsp, 0xF0
000074703edd7996  vmovaps [rsp], xmm0
000074703edd799b  vmovaps [rsp+0x10], xmm1
000074703edd79a1  vmovaps [rsp+0x20], xmm2
000074703edd79a7  vmovaps [rsp+0x30], xmm4
000074703edd79ad  vmovaps [rsp+0x40], xmm5
000074703edd79b3  vmovaps [rsp+0x50], xmm6
000074703edd79b9  vmovaps [rsp+0x60], xmm7
000074703edd79bf  vmovaps [rsp+0x70], xmm8
000074703edd79c5  vmovaps [rsp+0x80], xmm9
000074703edd79ce  vmovaps [rsp+0x90], xmm10
000074703edd79d7  vmovaps [rsp+0xA0], xmm11
000074703edd79e0  vmovaps [rsp+0xB0], xmm12
000074703edd79e9  vmovaps [rsp+0xC0], xmm13
000074703edd79f2  vmovaps [rsp+0xD0], xmm14
000074703edd79fb  vmovaps [rsp+0xE0], xmm15
000074703edd7a04  sub rsp, 0x30
000074703edd7a08  movaps [rsp], xmm3
000074703edd7a0c  movaps [rsp+0x10], xmm1
000074703edd7a11  movaps [rsp+0x20], xmm9
000074703edd7a17  lea rdi, [rsp]
000074703edd7a1b  mov esi, 0x00
000074703edd7a20  mov rax, 0x5D9974CCC530
000074703edd7a2a  call rax
000074703edd7a2c  movaps xmm3, [rsp]
000074703edd7a30  add rsp, 0x30
000074703edd7a34  vmovaps xmm0, [rsp]
000074703edd7a39  vmovaps xmm1, [rsp+0x10]
000074703edd7a3f  vmovaps xmm2, [rsp+0x20]
000074703edd7a45  vmovaps xmm4, [rsp+0x30]
000074703edd7a4b  vmovaps xmm5, [rsp+0x40]
000074703edd7a51  vmovaps xmm6, [rsp+0x50]
000074703edd7a57  vmovaps xmm7, [rsp+0x60]
000074703edd7a5d  vmovaps xmm8, [rsp+0x70]
000074703edd7a63  vmovaps xmm9, [rsp+0x80]
000074703edd7a6c  vmovaps xmm10, [rsp+0x90]
000074703edd7a75  vmovaps xmm11, [rsp+0xA0]
000074703edd7a7e  vmovaps xmm12, [rsp+0xB0]
000074703edd7a87  vmovaps xmm13, [rsp+0xC0]
000074703edd7a90  vmovaps xmm14, [rsp+0xD0]
000074703edd7a99  vmovaps xmm15, [rsp+0xE0]
000074703edd7aa2  add rsp, 0xF0
000074703edd7aa9  pop r11
000074703edd7aab  pop r10
000074703edd7aad  pop r9
000074703edd7aaf  pop r8
000074703edd7ab1  pop rsi
000074703edd7ab2  pop rdi
000074703edd7ab3  pop rdx
000074703edd7ab4  pop rcx
000074703edd7ab5  pop rax
000074703edd7ab6  add rsp, 0x08
000074703edd7aba  jmp 0x000074703EDD5D43
000074703edd7abf  sub rsp, 0x08
000074703edd7ac3  push rax
000074703edd7ac4  push rcx
000074703edd7ac5  push rdx
000074703edd7ac6  push rdi
000074703edd7ac7  push rsi
000074703edd7ac8  push r8
000074703edd7aca  push r9
000074703edd7acc  push r10
000074703edd7ace  push r11
000074703edd7ad0  sub rsp, 0xF0
000074703edd7ad7  vmovaps [rsp], xmm0
000074703edd7adc  vmovaps [rsp+0x10], xmm2
000074703edd7ae2  vmovaps [rsp+0x20], xmm3
000074703edd7ae8  vmovaps [rsp+0x30], xmm4
000074703edd7aee  vmovaps [rsp+0x40], xmm5
000074703edd7af4  vmovaps [rsp+0x50], xmm6
000074703edd7afa  vmovaps [rsp+0x60], xmm7
000074703edd7b00  vmovaps [rsp+0x70], xmm8
000074703edd7b06  vmovaps [rsp+0x80], xmm9
000074703edd7b0f  vmovaps [rsp+0x90], xmm10
000074703edd7b18  vmovaps [rsp+0xA0], xmm11
000074703edd7b21  vmovaps [rsp+0xB0], xmm12
000074703edd7b2a  vmovaps [rsp+0xC0], xmm13
000074703edd7b33  vmovaps [rsp+0xD0], xmm14
000074703edd7b3c  vmovaps [rsp+0xE0], xmm15
000074703edd7b45  sub rsp, 0x30
000074703edd7b49  movaps [rsp], xmm1
000074703edd7b4d  movaps [rsp+0x10], xmm15
000074703edd7b53  movaps [rsp+0x20], xmm9
000074703edd7b59  lea rdi, [rsp]
000074703edd7b5d  mov esi, 0x00
000074703edd7b62  mov rax, 0x5D9974CCC530
000074703edd7b6c  call rax
000074703edd7b6e  movaps xmm1, [rsp]
000074703edd7b72  add rsp, 0x30
000074703edd7b76  vmovaps xmm0, [rsp]
000074703edd7b7b  vmovaps xmm2, [rsp+0x10]
000074703edd7b81  vmovaps xmm3, [rsp+0x20]
000074703edd7b87  vmovaps xmm4, [rsp+0x30]
000074703edd7b8d  vmovaps xmm5, [rsp+0x40]
000074703edd7b93  vmovaps xmm6, [rsp+0x50]
000074703edd7b99  vmovaps xmm7, [rsp+0x60]
000074703edd7b9f  vmovaps xmm8, [rsp+0x70]
000074703edd7ba5  vmovaps xmm9, [rsp+0x80]
000074703edd7bae  vmovaps xmm10, [rsp+0x90]
000074703edd7bb7  vmovaps xmm11, [rsp+0xA0]
000074703edd7bc0  vmovaps xmm12, [rsp+0xB0]
000074703edd7bc9  vmovaps xmm13, [rsp+0xC0]
000074703edd7bd2  vmovaps xmm14, [rsp+0xD0]
000074703edd7bdb  vmovaps xmm15, [rsp+0xE0]
000074703edd7be4  add rsp, 0xF0
000074703edd7beb  pop r11
000074703edd7bed  pop r10
000074703edd7bef  pop r9
000074703edd7bf1  pop r8
000074703edd7bf3  pop rsi
000074703edd7bf4  pop rdi
000074703edd7bf5  pop rdx
000074703edd7bf6  pop rcx
000074703edd7bf7  pop rax
000074703edd7bf8  add rsp, 0x08
000074703edd7bfc  jmp 0x000074703EDD5DCB
000074703edd7c01  call 0x000074703ECE5820
000074703edd7c06  jmp 0x000074703EDD5DD8
000074703edd7c0b  sub rsp, 0x08
000074703edd7c0f  push rax
000074703edd7c10  push rcx
000074703edd7c11  push rdx
000074703edd7c12  push rdi
000074703edd7c13  push rsi
000074703edd7c14  push r8
000074703edd7c16  push r9
000074703edd7c18  push r10
000074703edd7c1a  push r11
000074703edd7c1c  sub rsp, 0xF0
000074703edd7c23  vmovaps [rsp], xmm0
000074703edd7c28  vmovaps [rsp+0x10], xmm2
000074703edd7c2e  vmovaps [rsp+0x20], xmm3
000074703edd7c34  vmovaps [rsp+0x30], xmm4
000074703edd7c3a  vmovaps [rsp+0x40], xmm5
000074703edd7c40  vmovaps [rsp+0x50], xmm6
000074703edd7c46  vmovaps [rsp+0x60], xmm7
000074703edd7c4c  vmovaps [rsp+0x70], xmm8
000074703edd7c52  vmovaps [rsp+0x80], xmm9
000074703edd7c5b  vmovaps [rsp+0x90], xmm10
000074703edd7c64  vmovaps [rsp+0xA0], xmm11
000074703edd7c6d  vmovaps [rsp+0xB0], xmm12
000074703edd7c76  vmovaps [rsp+0xC0], xmm13
000074703edd7c7f  vmovaps [rsp+0xD0], xmm14
000074703edd7c88  vmovaps [rsp+0xE0], xmm15
000074703edd7c91  sub rsp, 0x30
000074703edd7c95  movaps [rsp], xmm1
000074703edd7c99  movaps [rsp+0x10], xmm5
000074703edd7c9e  movaps [rsp+0x20], xmm7
000074703edd7ca3  lea rdi, [rsp]
000074703edd7ca7  mov esi, 0x00
000074703edd7cac  mov rax, 0x5D9974CCC530
000074703edd7cb6  call rax
000074703edd7cb8  movaps xmm1, [rsp]
000074703edd7cbc  add rsp, 0x30
000074703edd7cc0  vmovaps xmm0, [rsp]
000074703edd7cc5  vmovaps xmm2, [rsp+0x10]
000074703edd7ccb  vmovaps xmm3, [rsp+0x20]
000074703edd7cd1  vmovaps xmm4, [rsp+0x30]
000074703edd7cd7  vmovaps xmm5, [rsp+0x40]
000074703edd7cdd  vmovaps xmm6, [rsp+0x50]
000074703edd7ce3  vmovaps xmm7, [rsp+0x60]
000074703edd7ce9  vmovaps xmm8, [rsp+0x70]
000074703edd7cef  vmovaps xmm9, [rsp+0x80]
000074703edd7cf8  vmovaps xmm10, [rsp+0x90]
000074703edd7d01  vmovaps xmm11, [rsp+0xA0]
000074703edd7d0a  vmovaps xmm12, [rsp+0xB0]
000074703edd7d13  vmovaps xmm13, [rsp+0xC0]
000074703edd7d1c  vmovaps xmm14, [rsp+0xD0]
000074703edd7d25  vmovaps xmm15, [rsp+0xE0]
000074703edd7d2e  add rsp, 0xF0
000074703edd7d35  pop r11
000074703edd7d37  pop r10
000074703edd7d39  pop r9
000074703edd7d3b  pop r8
000074703edd7d3d  pop rsi
000074703edd7d3e  pop rdi
000074703edd7d3f  pop rdx
000074703edd7d40  pop rcx
000074703edd7d41  pop rax
000074703edd7d42  add rsp, 0x08
000074703edd7d46  jmp 0x000074703EDD5E7D
000074703edd7d4b  sub rsp, 0x08
000074703edd7d4f  push rax
000074703edd7d50  push rcx
000074703edd7d51  push rdx
000074703edd7d52  push rdi
000074703edd7d53  push rsi
000074703edd7d54  push r8
000074703edd7d56  push r9
000074703edd7d58  push r10
000074703edd7d5a  push r11
000074703edd7d5c  sub rsp, 0xF0
000074703edd7d63  vmovaps [rsp], xmm0
000074703edd7d68  vmovaps [rsp+0x10], xmm1
000074703edd7d6e  vmovaps [rsp+0x20], xmm2
000074703edd7d74  vmovaps [rsp+0x30], xmm3
000074703edd7d7a  vmovaps [rsp+0x40], xmm4
000074703edd7d80  vmovaps [rsp+0x50], xmm5
000074703edd7d86  vmovaps [rsp+0x60], xmm6
000074703edd7d8c  vmovaps [rsp+0x70], xmm8
000074703edd7d92  vmovaps [rsp+0x80], xmm9
000074703edd7d9b  vmovaps [rsp+0x90], xmm10
000074703edd7da4  vmovaps [rsp+0xA0], xmm11
000074703edd7dad  vmovaps [rsp+0xB0], xmm12
000074703edd7db6  vmovaps [rsp+0xC0], xmm13
000074703edd7dbf  vmovaps [rsp+0xD0], xmm14
000074703edd7dc8  vmovaps [rsp+0xE0], xmm15
000074703edd7dd1  sub rsp, 0x30
000074703edd7dd5  movaps [rsp], xmm7
000074703edd7dd9  movaps [rsp+0x10], xmm5
000074703edd7dde  movaps [rsp+0x20], xmm15
000074703edd7de4  lea rdi, [rsp]
000074703edd7de8  mov esi, 0x00
000074703edd7ded  mov rax, 0x5D9974CCC530
000074703edd7df7  call rax
000074703edd7df9  movaps xmm7, [rsp]
000074703edd7dfd  add rsp, 0x30
000074703edd7e01  vmovaps xmm0, [rsp]
000074703edd7e06  vmovaps xmm1, [rsp+0x10]
000074703edd7e0c  vmovaps xmm2, [rsp+0x20]
000074703edd7e12  vmovaps xmm3, [rsp+0x30]
000074703edd7e18  vmovaps xmm4, [rsp+0x40]
000074703edd7e1e  vmovaps xmm5, [rsp+0x50]
000074703edd7e24  vmovaps xmm6, [rsp+0x60]
000074703edd7e2a  vmovaps xmm8, [rsp+0x70]
000074703edd7e30  vmovaps xmm9, [rsp+0x80]
000074703edd7e39  vmovaps xmm10, [rsp+0x90]
000074703edd7e42  vmovaps xmm11, [rsp+0xA0]
000074703edd7e4b  vmovaps xmm12, [rsp+0xB0]
000074703edd7e54  vmovaps xmm13, [rsp+0xC0]
000074703edd7e5d  vmovaps xmm14, [rsp+0xD0]
000074703edd7e66  vmovaps xmm15, [rsp+0xE0]
000074703edd7e6f  add rsp, 0xF0
000074703edd7e76  pop r11
000074703edd7e78  pop r10
000074703edd7e7a  pop r9
000074703edd7e7c  pop r8
000074703edd7e7e  pop rsi
000074703edd7e7f  pop rdi
000074703edd7e80  pop rdx
000074703edd7e81  pop rcx
000074703edd7e82  pop rax
000074703edd7e83  add rsp, 0x08
000074703edd7e87  jmp 0x000074703EDD5EB3
000074703edd7e8c  call 0x000074703ECD64F0
000074703edd7e91  jmp 0x000074703EDD5EC0
000074703edd7e96  sub rsp, 0x08
000074703edd7e9a  push rax
000074703edd7e9b  push rcx
000074703edd7e9c  push rdx
000074703edd7e9d  push rdi
000074703edd7e9e  push rsi
000074703edd7e9f  push r8
000074703edd7ea1  push r9
000074703edd7ea3  push r10
000074703edd7ea5  push r11
000074703edd7ea7  sub rsp, 0xF0
000074703edd7eae  vmovaps [rsp], xmm0
000074703edd7eb3  vmovaps [rsp+0x10], xmm1
000074703edd7eb9  vmovaps [rsp+0x20], xmm2
000074703edd7ebf  vmovaps [rsp+0x30], xmm3
000074703edd7ec5  vmovaps [rsp+0x40], xmm4
000074703edd7ecb  vmovaps [rsp+0x50], xmm5
000074703edd7ed1  vmovaps [rsp+0x60], xmm6
000074703edd7ed7  vmovaps [rsp+0x70], xmm7
000074703edd7edd  vmovaps [rsp+0x80], xmm8
000074703edd7ee6  vmovaps [rsp+0x90], xmm9
000074703edd7eef  vmovaps [rsp+0xA0], xmm10
000074703edd7ef8  vmovaps [rsp+0xB0], xmm11
000074703edd7f01  vmovaps [rsp+0xC0], xmm12
000074703edd7f0a  vmovaps [rsp+0xD0], xmm13
000074703edd7f13  vmovaps [rsp+0xE0], xmm14
000074703edd7f1c  sub rsp, 0x30
000074703edd7f20  movaps [rsp], xmm15
000074703edd7f25  movaps [rsp+0x10], xmm5
000074703edd7f2a  movaps [rsp+0x20], xmm3
000074703edd7f2f  lea rdi, [rsp]
000074703edd7f33  mov esi, 0x00
000074703edd7f38  mov rax, 0x5D9974CCC530
000074703edd7f42  call rax
000074703edd7f44  movaps xmm15, [rsp]
000074703edd7f49  add rsp, 0x30
000074703edd7f4d  vmovaps xmm0, [rsp]
000074703edd7f52  vmovaps xmm1, [rsp+0x10]
000074703edd7f58  vmovaps xmm2, [rsp+0x20]
000074703edd7f5e  vmovaps xmm3, [rsp+0x30]
000074703edd7f64  vmovaps xmm4, [rsp+0x40]
000074703edd7f6a  vmovaps xmm5, [rsp+0x50]
000074703edd7f70  vmovaps xmm6, [rsp+0x60]
000074703edd7f76  vmovaps xmm7, [rsp+0x70]
000074703edd7f7c  vmovaps xmm8, [rsp+0x80]
000074703edd7f85  vmovaps xmm9, [rsp+0x90]
000074703edd7f8e  vmovaps xmm10, [rsp+0xA0]
000074703edd7f97  vmovaps xmm11, [rsp+0xB0]
000074703edd7fa0  vmovaps xmm12, [rsp+0xC0]
000074703edd7fa9  vmovaps xmm13, [rsp+0xD0]
000074703edd7fb2  vmovaps xmm14, [rsp+0xE0]
000074703edd7fbb  add rsp, 0xF0
000074703edd7fc2  pop r11
000074703edd7fc4  pop r10
000074703edd7fc6  pop r9
000074703edd7fc8  pop r8
000074703edd7fca  pop rsi
000074703edd7fcb  pop rdi
000074703edd7fcc  pop rdx
000074703edd7fcd  pop rcx
000074703edd7fce  pop rax
000074703edd7fcf  add rsp, 0x08
000074703edd7fd3  jmp 0x000074703EDD5EE6
000074703edd7fd8  sub rsp, 0x08
000074703edd7fdc  push rax
000074703edd7fdd  push rcx
000074703edd7fde  push rdx
000074703edd7fdf  push rdi
000074703edd7fe0  push rsi
000074703edd7fe1  push r8
000074703edd7fe3  push r9
000074703edd7fe5  push r10
000074703edd7fe7  push r11
000074703edd7fe9  sub rsp, 0xF0
000074703edd7ff0  vmovaps [rsp], xmm0
000074703edd7ff5  vmovaps [rsp+0x10], xmm2
000074703edd7ffb  vmovaps [rsp+0x20], xmm3
000074703edd8001  vmovaps [rsp+0x30], xmm4
000074703edd8007  vmovaps [rsp+0x40], xmm5
000074703edd800d  vmovaps [rsp+0x50], xmm6
000074703edd8013  vmovaps [rsp+0x60], xmm7
000074703edd8019  vmovaps [rsp+0x70], xmm8
000074703edd801f  vmovaps [rsp+0x80], xmm9
000074703edd8028  vmovaps [rsp+0x90], xmm10
000074703edd8031  vmovaps [rsp+0xA0], xmm11
000074703edd803a  vmovaps [rsp+0xB0], xmm12
000074703edd8043  vmovaps [rsp+0xC0], xmm13
000074703edd804c  vmovaps [rsp+0xD0], xmm14
000074703edd8055  vmovaps [rsp+0xE0], xmm15
000074703edd805e  sub rsp, 0x30
000074703edd8062  movaps [rsp], xmm1
000074703edd8066  movaps [rsp+0x10], xmm5
000074703edd806b  movaps [rsp+0x20], xmm4
000074703edd8070  lea rdi, [rsp]
000074703edd8074  mov esi, 0x00
000074703edd8079  mov rax, 0x5D9974CCC530
000074703edd8083  call rax
000074703edd8085  movaps xmm1, [rsp]
000074703edd8089  add rsp, 0x30
000074703edd808d  vmovaps xmm0, [rsp]
000074703edd8092  vmovaps xmm2, [rsp+0x10]
000074703edd8098  vmovaps xmm3, [rsp+0x20]
000074703edd809e  vmovaps xmm4, [rsp+0x30]
000074703edd80a4  vmovaps xmm5, [rsp+0x40]
000074703edd80aa  vmovaps xmm6, [rsp+0x50]
000074703edd80b0  vmovaps xmm7, [rsp+0x60]
000074703edd80b6  vmovaps xmm8, [rsp+0x70]
000074703edd80bc  vmovaps xmm9, [rsp+0x80]
000074703edd80c5  vmovaps xmm10, [rsp+0x90]
000074703edd80ce  vmovaps xmm11, [rsp+0xA0]
000074703edd80d7  vmovaps xmm12, [rsp+0xB0]
000074703edd80e0  vmovaps xmm13, [rsp+0xC0]
000074703edd80e9  vmovaps xmm14, [rsp+0xD0]
000074703edd80f2  vmovaps xmm15, [rsp+0xE0]
000074703edd80fb  add rsp, 0xF0
000074703edd8102  pop r11
000074703edd8104  pop r10
000074703edd8106  pop r9
000074703edd8108  pop r8
000074703edd810a  pop rsi
000074703edd810b  pop rdi
000074703edd810c  pop rdx
000074703edd810d  pop rcx
000074703edd810e  pop rax
000074703edd810f  add rsp, 0x08
000074703edd8113  jmp 0x000074703EDD5F06
000074703edd8118  sub rsp, 0x08
000074703edd811c  push rax
000074703edd811d  push rcx
000074703edd811e  push rdx
000074703edd811f  push rdi
000074703edd8120  push rsi
000074703edd8121  push r8
000074703edd8123  push r9
000074703edd8125  push r10
000074703edd8127  push r11
000074703edd8129  sub rsp, 0xF0
000074703edd8130  vmovaps [rsp], xmm0
000074703edd8135  vmovaps [rsp+0x10], xmm1
000074703edd813b  vmovaps [rsp+0x20], xmm2
000074703edd8141  vmovaps [rsp+0x30], xmm3
000074703edd8147  vmovaps [rsp+0x40], xmm5
000074703edd814d  vmovaps [rsp+0x50], xmm6
000074703edd8153  vmovaps [rsp+0x60], xmm7
000074703edd8159  vmovaps [rsp+0x70], xmm8
000074703edd815f  vmovaps [rsp+0x80], xmm9
000074703edd8168  vmovaps [rsp+0x90], xmm10
000074703edd8171  vmovaps [rsp+0xA0], xmm11
000074703edd817a  vmovaps [rsp+0xB0], xmm12
000074703edd8183  vmovaps [rsp+0xC0], xmm13
000074703edd818c  vmovaps [rsp+0xD0], xmm14
000074703edd8195  vmovaps [rsp+0xE0], xmm15
000074703edd819e  sub rsp, 0x30
000074703edd81a2  movaps [rsp], xmm4
000074703edd81a6  movaps [rsp+0x10], xmm3
000074703edd81ab  movaps [rsp+0x20], xmm5
000074703edd81b0  lea rdi, [rsp]
000074703edd81b4  mov esi, 0x00
000074703edd81b9  mov rax, 0x5D9974CCC530
000074703edd81c3  call rax
000074703edd81c5  movaps xmm4, [rsp]
000074703edd81c9  add rsp, 0x30
000074703edd81cd  vmovaps xmm0, [rsp]
000074703edd81d2  vmovaps xmm1, [rsp+0x10]
000074703edd81d8  vmovaps xmm2, [rsp+0x20]
000074703edd81de  vmovaps xmm3, [rsp+0x30]
000074703edd81e4  vmovaps xmm5, [rsp+0x40]
000074703edd81ea  vmovaps xmm6, [rsp+0x50]
000074703edd81f0  vmovaps xmm7, [rsp+0x60]
000074703edd81f6  vmovaps xmm8, [rsp+0x70]
000074703edd81fc  vmovaps xmm9, [rsp+0x80]
000074703edd8205  vmovaps xmm10, [rsp+0x90]
000074703edd820e  vmovaps xmm11, [rsp+0xA0]
000074703edd8217  vmovaps xmm12, [rsp+0xB0]
000074703edd8220  vmovaps xmm13, [rsp+0xC0]
000074703edd8229  vmovaps xmm14, [rsp+0xD0]
000074703edd8232  vmovaps xmm15, [rsp+0xE0]
000074703edd823b  add rsp, 0xF0
000074703edd8242  pop r11
000074703edd8244  pop r10
000074703edd8246  pop r9
000074703edd8248  pop r8
000074703edd824a  pop rsi
000074703edd824b  pop rdi
000074703edd824c  pop rdx
000074703edd824d  pop rcx
000074703edd824e  pop rax
000074703edd824f  add rsp, 0x08
000074703edd8253  jmp 0x000074703EDD5F54
000074703edd8258  call 0x000074703ECD64F0
000074703edd825d  jmp 0x000074703EDD5F61
000074703edd8262  sub rsp, 0x08
000074703edd8266  push rax
000074703edd8267  push rcx
000074703edd8268  push rdx
000074703edd8269  push rdi
000074703edd826a  push rsi
000074703edd826b  push r8
000074703edd826d  push r9
000074703edd826f  push r10
000074703edd8271  push r11
000074703edd8273  sub rsp, 0xF0
000074703edd827a  vmovaps [rsp], xmm0
000074703edd827f  vmovaps [rsp+0x10], xmm1
000074703edd8285  vmovaps [rsp+0x20], xmm2
000074703edd828b  vmovaps [rsp+0x30], xmm3
000074703edd8291  vmovaps [rsp+0x40], xmm4
000074703edd8297  vmovaps [rsp+0x50], xmm6
000074703edd829d  vmovaps [rsp+0x60], xmm7
000074703edd82a3  vmovaps [rsp+0x70], xmm8
000074703edd82a9  vmovaps [rsp+0x80], xmm9
000074703edd82b2  vmovaps [rsp+0x90], xmm10
000074703edd82bb  vmovaps [rsp+0xA0], xmm11
000074703edd82c4  vmovaps [rsp+0xB0], xmm12
000074703edd82cd  vmovaps [rsp+0xC0], xmm13
000074703edd82d6  vmovaps [rsp+0xD0], xmm14
000074703edd82df  vmovaps [rsp+0xE0], xmm15
000074703edd82e8  sub rsp, 0x30
000074703edd82ec  movaps [rsp], xmm5
000074703edd82f0  movaps [rsp+0x10], xmm6
000074703edd82f5  movaps [rsp+0x20], xmm3
000074703edd82fa  lea rdi, [rsp]
000074703edd82fe  mov esi, 0x00
000074703edd8303  mov rax, 0x5D9974CCC530
000074703edd830d  call rax
000074703edd830f  movaps xmm5, [rsp]
000074703edd8313  add rsp, 0x30
000074703edd8317  vmovaps xmm0, [rsp]
000074703edd831c  vmovaps xmm1, [rsp+0x10]
000074703edd8322  vmovaps xmm2, [rsp+0x20]
000074703edd8328  vmovaps xmm3, [rsp+0x30]
000074703edd832e  vmovaps xmm4, [rsp+0x40]
000074703edd8334  vmovaps xmm6, [rsp+0x50]
000074703edd833a  vmovaps xmm7, [rsp+0x60]
000074703edd8340  vmovaps xmm8, [rsp+0x70]
000074703edd8346  vmovaps xmm9, [rsp+0x80]
000074703edd834f  vmovaps xmm10, [rsp+0x90]
000074703edd8358  vmovaps xmm11, [rsp+0xA0]
000074703edd8361  vmovaps xmm12, [rsp+0xB0]
000074703edd836a  vmovaps xmm13, [rsp+0xC0]
000074703edd8373  vmovaps xmm14, [rsp+0xD0]
000074703edd837c  vmovaps xmm15, [rsp+0xE0]
000074703edd8385  add rsp, 0xF0
000074703edd838c  pop r11
000074703edd838e  pop r10
000074703edd8390  pop r9
000074703edd8392  pop r8
000074703edd8394  pop rsi
000074703edd8395  pop rdi
000074703edd8396  pop rdx
000074703edd8397  pop rcx
000074703edd8398  pop rax
000074703edd8399  add rsp, 0x08
000074703edd839d  jmp 0x000074703EDD5F87
000074703edd83a2  sub rsp, 0x08
000074703edd83a6  push rax
000074703edd83a7  push rcx
000074703edd83a8  push rdx
000074703edd83a9  push rdi
000074703edd83aa  push rsi
000074703edd83ab  push r8
000074703edd83ad  push r9
000074703edd83af  push r10
000074703edd83b1  push r11
000074703edd83b3  sub rsp, 0xF0
000074703edd83ba  vmovaps [rsp], xmm0
000074703edd83bf  vmovaps [rsp+0x10], xmm1
000074703edd83c5  vmovaps [rsp+0x20], xmm2
000074703edd83cb  vmovaps [rsp+0x30], xmm3
000074703edd83d1  vmovaps [rsp+0x40], xmm4
000074703edd83d7  vmovaps [rsp+0x50], xmm5
000074703edd83dd  vmovaps [rsp+0x60], xmm7
000074703edd83e3  vmovaps [rsp+0x70], xmm8
000074703edd83e9  vmovaps [rsp+0x80], xmm9
000074703edd83f2  vmovaps [rsp+0x90], xmm10
000074703edd83fb  vmovaps [rsp+0xA0], xmm11
000074703edd8404  vmovaps [rsp+0xB0], xmm12
000074703edd840d  vmovaps [rsp+0xC0], xmm13
000074703edd8416  vmovaps [rsp+0xD0], xmm14
000074703edd841f  vmovaps [rsp+0xE0], xmm15
000074703edd8428  sub rsp, 0x30
000074703edd842c  movaps [rsp], xmm6
000074703edd8430  movaps [rsp+0x10], xmm9
000074703edd8436  movaps [rsp+0x20], xmm1
000074703edd843b  lea rdi, [rsp]
000074703edd843f  mov esi, 0x00
000074703edd8444  mov rax, 0x5D9974CCC530
000074703edd844e  call rax
000074703edd8450  movaps xmm6, [rsp]
000074703edd8454  add rsp, 0x30
000074703edd8458  vmovaps xmm0, [rsp]
000074703edd845d  vmovaps xmm1, [rsp+0x10]
000074703edd8463  vmovaps xmm2, [rsp+0x20]
000074703edd8469  vmovaps xmm3, [rsp+0x30]
000074703edd846f  vmovaps xmm4, [rsp+0x40]
000074703edd8475  vmovaps xmm5, [rsp+0x50]
000074703edd847b  vmovaps xmm7, [rsp+0x60]
000074703edd8481  vmovaps xmm8, [rsp+0x70]
000074703edd8487  vmovaps xmm9, [rsp+0x80]
000074703edd8490  vmovaps xmm10, [rsp+0x90]
000074703edd8499  vmovaps xmm11, [rsp+0xA0]
000074703edd84a2  vmovaps xmm12, [rsp+0xB0]
000074703edd84ab  vmovaps xmm13, [rsp+0xC0]
000074703edd84b4  vmovaps xmm14, [rsp+0xD0]
000074703edd84bd  vmovaps xmm15, [rsp+0xE0]
000074703edd84c6  add rsp, 0xF0
000074703edd84cd  pop r11
000074703edd84cf  pop r10
000074703edd84d1  pop r9
000074703edd84d3  pop r8
000074703edd84d5  pop rsi
000074703edd84d6  pop rdi
000074703edd84d7  pop rdx
000074703edd84d8  pop rcx
000074703edd84d9  pop rax
000074703edd84da  add rsp, 0x08
000074703edd84de  jmp 0x000074703EDD5FAB
000074703edd84e3  sub rsp, 0x08
000074703edd84e7  push rax
000074703edd84e8  push rcx
000074703edd84e9  push rdx
000074703edd84ea  push rdi
000074703edd84eb  push rsi
000074703edd84ec  push r8
000074703edd84ee  push r9
000074703edd84f0  push r10
000074703edd84f2  push r11
000074703edd84f4  sub rsp, 0xF0
000074703edd84fb  vmovaps [rsp], xmm0
000074703edd8500  vmovaps [rsp+0x10], xmm1
000074703edd8506  vmovaps [rsp+0x20], xmm2
000074703edd850c  vmovaps [rsp+0x30], xmm3
000074703edd8512  vmovaps [rsp+0x40], xmm4
000074703edd8518  vmovaps [rsp+0x50], xmm5
000074703edd851e  vmovaps [rsp+0x60], xmm6
000074703edd8524  vmovaps [rsp+0x70], xmm7
000074703edd852a  vmovaps [rsp+0x80], xmm8
000074703edd8533  vmovaps [rsp+0x90], xmm10
000074703edd853c  vmovaps [rsp+0xA0], xmm11
000074703edd8545  vmovaps [rsp+0xB0], xmm12
000074703edd854e  vmovaps [rsp+0xC0], xmm13
000074703edd8557  vmovaps [rsp+0xD0], xmm14
000074703edd8560  vmovaps [rsp+0xE0], xmm15
000074703edd8569  sub rsp, 0x30
000074703edd856d  movaps [rsp], xmm9
000074703edd8572  movaps [rsp+0x10], xmm3
000074703edd8577  movaps [rsp+0x20], xmm1
000074703edd857c  lea rdi, [rsp]
000074703edd8580  mov esi, 0x00
000074703edd8585  mov rax, 0x5D9974CCC530
000074703edd858f  call rax
000074703edd8591  movaps xmm9, [rsp]
000074703edd8596  add rsp, 0x30
000074703edd859a  vmovaps xmm0, [rsp]
000074703edd859f  vmovaps xmm1, [rsp+0x10]
000074703edd85a5  vmovaps xmm2, [rsp+0x20]
000074703edd85ab  vmovaps xmm3, [rsp+0x30]
000074703edd85b1  vmovaps xmm4, [rsp+0x40]
000074703edd85b7  vmovaps xmm5, [rsp+0x50]
000074703edd85bd  vmovaps xmm6, [rsp+0x60]
000074703edd85c3  vmovaps xmm7, [rsp+0x70]
000074703edd85c9  vmovaps xmm8, [rsp+0x80]
000074703edd85d2  vmovaps xmm10, [rsp+0x90]
000074703edd85db  vmovaps xmm11, [rsp+0xA0]
000074703edd85e4  vmovaps xmm12, [rsp+0xB0]
000074703edd85ed  vmovaps xmm13, [rsp+0xC0]
000074703edd85f6  vmovaps xmm14, [rsp+0xD0]
000074703edd85ff  vmovaps xmm15, [rsp+0xE0]
000074703edd8608  add rsp, 0xF0
000074703edd860f  pop r11
000074703edd8611  pop r10
000074703edd8613  pop r9
000074703edd8615  pop r8
000074703edd8617  pop rsi
000074703edd8618  pop rdi
000074703edd8619  pop rdx
000074703edd861a  pop rcx
000074703edd861b  pop rax
000074703edd861c  add rsp, 0x08
000074703edd8620  jmp 0x000074703EDD5FF7
000074703edd8625  call 0x000074703ECD64F0
000074703edd862a  jmp 0x000074703EDD6004
000074703edd862f  sub rsp, 0x08
000074703edd8633  push rax
000074703edd8634  push rcx
000074703edd8635  push rdx
000074703edd8636  push rdi
000074703edd8637  push rsi
000074703edd8638  push r8
000074703edd863a  push r9
000074703edd863c  push r10
000074703edd863e  push r11
000074703edd8640  sub rsp, 0xF0
000074703edd8647  vmovaps [rsp], xmm0
000074703edd864c  vmovaps [rsp+0x10], xmm1
000074703edd8652  vmovaps [rsp+0x20], xmm2
000074703edd8658  vmovaps [rsp+0x30], xmm3
000074703edd865e  vmovaps [rsp+0x40], xmm4
000074703edd8664  vmovaps [rsp+0x50], xmm5
000074703edd866a  vmovaps [rsp+0x60], xmm6
000074703edd8670  vmovaps [rsp+0x70], xmm7
000074703edd8676  vmovaps [rsp+0x80], xmm8
000074703edd867f  vmovaps [rsp+0x90], xmm9
000074703edd8688  vmovaps [rsp+0xA0], xmm10
000074703edd8691  vmovaps [rsp+0xB0], xmm11
000074703edd869a  vmovaps [rsp+0xC0], xmm12
000074703edd86a3  vmovaps [rsp+0xD0], xmm13
000074703edd86ac  vmovaps [rsp+0xE0], xmm14
000074703edd86b5  sub rsp, 0x30
000074703edd86b9  movaps [rsp], xmm15
000074703edd86be  movaps [rsp+0x10], xmm3
000074703edd86c3  movaps [rsp+0x20], xmm7
000074703edd86c8  lea rdi, [rsp]
000074703edd86cc  mov esi, 0x00
000074703edd86d1  mov rax, 0x5D9974CCC530
000074703edd86db  call rax
000074703edd86dd  movaps xmm15, [rsp]
000074703edd86e2  add rsp, 0x30
000074703edd86e6  vmovaps xmm0, [rsp]
000074703edd86eb  vmovaps xmm1, [rsp+0x10]
000074703edd86f1  vmovaps xmm2, [rsp+0x20]
000074703edd86f7  vmovaps xmm3, [rsp+0x30]
000074703edd86fd  vmovaps xmm4, [rsp+0x40]
000074703edd8703  vmovaps xmm5, [rsp+0x50]
000074703edd8709  vmovaps xmm6, [rsp+0x60]
000074703edd870f  vmovaps xmm7, [rsp+0x70]
000074703edd8715  vmovaps xmm8, [rsp+0x80]
000074703edd871e  vmovaps xmm9, [rsp+0x90]
000074703edd8727  vmovaps xmm10, [rsp+0xA0]
000074703edd8730  vmovaps xmm11, [rsp+0xB0]
000074703edd8739  vmovaps xmm12, [rsp+0xC0]
000074703edd8742  vmovaps xmm13, [rsp+0xD0]
000074703edd874b  vmovaps xmm14, [rsp+0xE0]
000074703edd8754  add rsp, 0xF0
000074703edd875b  pop r11
000074703edd875d  pop r10
000074703edd875f  pop r9
000074703edd8761  pop r8
000074703edd8763  pop rsi
000074703edd8764  pop rdi
000074703edd8765  pop rdx
000074703edd8766  pop rcx
000074703edd8767  pop rax
000074703edd8768  add rsp, 0x08
000074703edd876c  jmp 0x000074703EDD6030
000074703edd8771  sub rsp, 0x08
000074703edd8775  push rax
000074703edd8776  push rcx
000074703edd8777  push rdx
000074703edd8778  push rdi
000074703edd8779  push rsi
000074703edd877a  push r8
000074703edd877c  push r9
000074703edd877e  push r10
000074703edd8780  push r11
000074703edd8782  sub rsp, 0xF0
000074703edd8789  vmovaps [rsp], xmm0
000074703edd878e  vmovaps [rsp+0x10], xmm1
000074703edd8794  vmovaps [rsp+0x20], xmm2
000074703edd879a  vmovaps [rsp+0x30], xmm4
000074703edd87a0  vmovaps [rsp+0x40], xmm5
000074703edd87a6  vmovaps [rsp+0x50], xmm6
000074703edd87ac  vmovaps [rsp+0x60], xmm7
000074703edd87b2  vmovaps [rsp+0x70], xmm8
000074703edd87b8  vmovaps [rsp+0x80], xmm9
000074703edd87c1  vmovaps [rsp+0x90], xmm10
000074703edd87ca  vmovaps [rsp+0xA0], xmm11
000074703edd87d3  vmovaps [rsp+0xB0], xmm12
000074703edd87dc  vmovaps [rsp+0xC0], xmm13
000074703edd87e5  vmovaps [rsp+0xD0], xmm14
000074703edd87ee  vmovaps [rsp+0xE0], xmm15
000074703edd87f7  sub rsp, 0x30
000074703edd87fb  movaps [rsp], xmm3
000074703edd87ff  movaps [rsp+0x10], xmm1
000074703edd8804  movaps [rsp+0x20], xmm15
000074703edd880a  lea rdi, [rsp]
000074703edd880e  mov esi, 0x00
000074703edd8813  mov rax, 0x5D9974CCC530
000074703edd881d  call rax
000074703edd881f  movaps xmm3, [rsp]
000074703edd8823  add rsp, 0x30
000074703edd8827  vmovaps xmm0, [rsp]
000074703edd882c  vmovaps xmm1, [rsp+0x10]
000074703edd8832  vmovaps xmm2, [rsp+0x20]
000074703edd8838  vmovaps xmm4, [rsp+0x30]
000074703edd883e  vmovaps xmm5, [rsp+0x40]
000074703edd8844  vmovaps xmm6, [rsp+0x50]
000074703edd884a  vmovaps xmm7, [rsp+0x60]
000074703edd8850  vmovaps xmm8, [rsp+0x70]
000074703edd8856  vmovaps xmm9, [rsp+0x80]
000074703edd885f  vmovaps xmm10, [rsp+0x90]
000074703edd8868  vmovaps xmm11, [rsp+0xA0]
000074703edd8871  vmovaps xmm12, [rsp+0xB0]
000074703edd887a  vmovaps xmm13, [rsp+0xC0]
000074703edd8883  vmovaps xmm14, [rsp+0xD0]
000074703edd888c  vmovaps xmm15, [rsp+0xE0]
000074703edd8895  add rsp, 0xF0
000074703edd889c  pop r11
000074703edd889e  pop r10
000074703edd88a0  pop r9
000074703edd88a2  pop r8
000074703edd88a4  pop rsi
000074703edd88a5  pop rdi
000074703edd88a6  pop rdx
000074703edd88a7  pop rcx
000074703edd88a8  pop rax
000074703edd88a9  add rsp, 0x08
000074703edd88ad  jmp 0x000074703EDD60BF
000074703edd88b2  call 0x000074703ECD64F0
000074703edd88b7  jmp 0x000074703EDD60C9
000074703edd88bc  sub rsp, 0x08
000074703edd88c0  push rax
000074703edd88c1  push rcx
000074703edd88c2  push rdx
000074703edd88c3  push rdi
000074703edd88c4  push rsi
000074703edd88c5  push r8
000074703edd88c7  push r9
000074703edd88c9  push r10
000074703edd88cb  push r11
000074703edd88cd  sub rsp, 0xF0
000074703edd88d4  vmovaps [rsp], xmm0
000074703edd88d9  vmovaps [rsp+0x10], xmm1
000074703edd88df  vmovaps [rsp+0x20], xmm2
000074703edd88e5  vmovaps [rsp+0x30], xmm3
000074703edd88eb  vmovaps [rsp+0x40], xmm4
000074703edd88f1  vmovaps [rsp+0x50], xmm5
000074703edd88f7  vmovaps [rsp+0x60], xmm6
000074703edd88fd  vmovaps [rsp+0x70], xmm7
000074703edd8903  vmovaps [rsp+0x80], xmm8
000074703edd890c  vmovaps [rsp+0x90], xmm9
000074703edd8915  vmovaps [rsp+0xA0], xmm10
000074703edd891e  vmovaps [rsp+0xB0], xmm11
000074703edd8927  vmovaps [rsp+0xC0], xmm12
000074703edd8930  vmovaps [rsp+0xD0], xmm13
000074703edd8939  vmovaps [rsp+0xE0], xmm14
000074703edd8942  sub rsp, 0x30
000074703edd8946  movaps [rsp], xmm15
000074703edd894b  movaps [rsp+0x10], xmm14
000074703edd8951  movaps [rsp+0x20], xmm4
000074703edd8956  lea rdi, [rsp]
000074703edd895a  mov esi, 0x00
000074703edd895f  mov rax, 0x5D9974CCC530
000074703edd8969  call rax
000074703edd896b  movaps xmm15, [rsp]
000074703edd8970  add rsp, 0x30
000074703edd8974  vmovaps xmm0, [rsp]
000074703edd8979  vmovaps xmm1, [rsp+0x10]
000074703edd897f  vmovaps xmm2, [rsp+0x20]
000074703edd8985  vmovaps xmm3, [rsp+0x30]
000074703edd898b  vmovaps xmm4, [rsp+0x40]
000074703edd8991  vmovaps xmm5, [rsp+0x50]
000074703edd8997  vmovaps xmm6, [rsp+0x60]
000074703edd899d  vmovaps xmm7, [rsp+0x70]
000074703edd89a3  vmovaps xmm8, [rsp+0x80]
000074703edd89ac  vmovaps xmm9, [rsp+0x90]
000074703edd89b5  vmovaps xmm10, [rsp+0xA0]
000074703edd89be  vmovaps xmm11, [rsp+0xB0]
000074703edd89c7  vmovaps xmm12, [rsp+0xC0]
000074703edd89d0  vmovaps xmm13, [rsp+0xD0]
000074703edd89d9  vmovaps xmm14, [rsp+0xE0]
000074703edd89e2  add rsp, 0xF0
000074703edd89e9  pop r11
000074703edd89eb  pop r10
000074703edd89ed  pop r9
000074703edd89ef  pop r8
000074703edd89f1  pop rsi
000074703edd89f2  pop rdi
000074703edd89f3  pop rdx
000074703edd89f4  pop rcx
000074703edd89f5  pop rax
000074703edd89f6  add rsp, 0x08
000074703edd89fa  jmp 0x000074703EDD60F7
000074703edd89ff  sub rsp, 0x08
000074703edd8a03  push rax
000074703edd8a04  push rcx
000074703edd8a05  push rdx
000074703edd8a06  push rdi
000074703edd8a07  push rsi
000074703edd8a08  push r8
000074703edd8a0a  push r9
000074703edd8a0c  push r10
000074703edd8a0e  push r11
000074703edd8a10  sub rsp, 0xF0
000074703edd8a17  vmovaps [rsp], xmm0
000074703edd8a1c  vmovaps [rsp+0x10], xmm1
000074703edd8a22  vmovaps [rsp+0x20], xmm2
000074703edd8a28  vmovaps [rsp+0x30], xmm3
000074703edd8a2e  vmovaps [rsp+0x40], xmm4
000074703edd8a34  vmovaps [rsp+0x50], xmm5
000074703edd8a3a  vmovaps [rsp+0x60], xmm6
000074703edd8a40  vmovaps [rsp+0x70], xmm7
000074703edd8a46  vmovaps [rsp+0x80], xmm8
000074703edd8a4f  vmovaps [rsp+0x90], xmm9
000074703edd8a58  vmovaps [rsp+0xA0], xmm10
000074703edd8a61  vmovaps [rsp+0xB0], xmm11
000074703edd8a6a  vmovaps [rsp+0xC0], xmm12
000074703edd8a73  vmovaps [rsp+0xD0], xmm13
000074703edd8a7c  vmovaps [rsp+0xE0], xmm15
000074703edd8a85  sub rsp, 0x30
000074703edd8a89  movaps [rsp], xmm14
000074703edd8a8e  movaps [rsp+0x10], xmm2
000074703edd8a93  movaps [rsp+0x20], xmm1
000074703edd8a98  lea rdi, [rsp]
000074703edd8a9c  mov esi, 0x00
000074703edd8aa1  mov rax, 0x5D9974CCC530
000074703edd8aab  call rax
000074703edd8aad  movaps xmm14, [rsp]
000074703edd8ab2  add rsp, 0x30
000074703edd8ab6  vmovaps xmm0, [rsp]
000074703edd8abb  vmovaps xmm1, [rsp+0x10]
000074703edd8ac1  vmovaps xmm2, [rsp+0x20]
000074703edd8ac7  vmovaps xmm3, [rsp+0x30]
000074703edd8acd  vmovaps xmm4, [rsp+0x40]
000074703edd8ad3  vmovaps xmm5, [rsp+0x50]
000074703edd8ad9  vmovaps xmm6, [rsp+0x60]
000074703edd8adf  vmovaps xmm7, [rsp+0x70]
000074703edd8ae5  vmovaps xmm8, [rsp+0x80]
000074703edd8aee  vmovaps xmm9, [rsp+0x90]
000074703edd8af7  vmovaps xmm10, [rsp+0xA0]
000074703edd8b00  vmovaps xmm11, [rsp+0xB0]
000074703edd8b09  vmovaps xmm12, [rsp+0xC0]
000074703edd8b12  vmovaps xmm13, [rsp+0xD0]
000074703edd8b1b  vmovaps xmm15, [rsp+0xE0]
000074703edd8b24  add rsp, 0xF0
000074703edd8b2b  pop r11
000074703edd8b2d  pop r10
000074703edd8b2f  pop r9
000074703edd8b31  pop r8
000074703edd8b33  pop rsi
000074703edd8b34  pop rdi
000074703edd8b35  pop rdx
000074703edd8b36  pop rcx
000074703edd8b37  pop rax
000074703edd8b38  add rsp, 0x08
000074703edd8b3c  jmp 0x000074703EDD611D
000074703edd8b41  sub rsp, 0x08
000074703edd8b45  push rax
000074703edd8b46  push rcx
000074703edd8b47  push rdx
000074703edd8b48  push rdi
000074703edd8b49  push rsi
000074703edd8b4a  push r8
000074703edd8b4c  push r9
000074703edd8b4e  push r10
000074703edd8b50  push r11
000074703edd8b52  sub rsp, 0xF0
000074703edd8b59  vmovaps [rsp], xmm0
000074703edd8b5e  vmovaps [rsp+0x10], xmm2
000074703edd8b64  vmovaps [rsp+0x20], xmm3
000074703edd8b6a  vmovaps [rsp+0x30], xmm4
000074703edd8b70  vmovaps [rsp+0x40], xmm5
000074703edd8b76  vmovaps [rsp+0x50], xmm6
000074703edd8b7c  vmovaps [rsp+0x60], xmm7
000074703edd8b82  vmovaps [rsp+0x70], xmm8
000074703edd8b88  vmovaps [rsp+0x80], xmm9
000074703edd8b91  vmovaps [rsp+0x90], xmm10
000074703edd8b9a  vmovaps [rsp+0xA0], xmm11
000074703edd8ba3  vmovaps [rsp+0xB0], xmm12
000074703edd8bac  vmovaps [rsp+0xC0], xmm13
000074703edd8bb5  vmovaps [rsp+0xD0], xmm14
000074703edd8bbe  vmovaps [rsp+0xE0], xmm15
000074703edd8bc7  sub rsp, 0x30
000074703edd8bcb  movaps [rsp], xmm1
000074703edd8bcf  movaps [rsp+0x10], xmm4
000074703edd8bd4  movaps [rsp+0x20], xmm9
000074703edd8bda  lea rdi, [rsp]
000074703edd8bde  mov esi, 0x00
000074703edd8be3  mov rax, 0x5D9974CCC530
000074703edd8bed  call rax
000074703edd8bef  movaps xmm1, [rsp]
000074703edd8bf3  add rsp, 0x30
000074703edd8bf7  vmovaps xmm0, [rsp]
000074703edd8bfc  vmovaps xmm2, [rsp+0x10]
000074703edd8c02  vmovaps xmm3, [rsp+0x20]
000074703edd8c08  vmovaps xmm4, [rsp+0x30]
000074703edd8c0e  vmovaps xmm5, [rsp+0x40]
000074703edd8c14  vmovaps xmm6, [rsp+0x50]
000074703edd8c1a  vmovaps xmm7, [rsp+0x60]
000074703edd8c20  vmovaps xmm8, [rsp+0x70]
000074703edd8c26  vmovaps xmm9, [rsp+0x80]
000074703edd8c2f  vmovaps xmm10, [rsp+0x90]
000074703edd8c38  vmovaps xmm11, [rsp+0xA0]
000074703edd8c41  vmovaps xmm12, [rsp+0xB0]
000074703edd8c4a  vmovaps xmm13, [rsp+0xC0]
000074703edd8c53  vmovaps xmm14, [rsp+0xD0]
000074703edd8c5c  vmovaps xmm15, [rsp+0xE0]
000074703edd8c65  add rsp, 0xF0
000074703edd8c6c  pop r11
000074703edd8c6e  pop r10
000074703edd8c70  pop r9
000074703edd8c72  pop r8
000074703edd8c74  pop rsi
000074703edd8c75  pop rdi
000074703edd8c76  pop rdx
000074703edd8c77  pop rcx
000074703edd8c78  pop rax
000074703edd8c79  add rsp, 0x08
000074703edd8c7d  jmp 0x000074703EDD613B
000074703edd8c82  sub rsp, 0x08
000074703edd8c86  push rax
000074703edd8c87  push rcx
000074703edd8c88  push rdx
000074703edd8c89  push rdi
000074703edd8c8a  push rsi
000074703edd8c8b  push r8
000074703edd8c8d  push r9
000074703edd8c8f  push r10
000074703edd8c91  push r11
000074703edd8c93  sub rsp, 0xF0
000074703edd8c9a  vmovaps [rsp], xmm0
000074703edd8c9f  vmovaps [rsp+0x10], xmm1
000074703edd8ca5  vmovaps [rsp+0x20], xmm2
000074703edd8cab  vmovaps [rsp+0x30], xmm3
000074703edd8cb1  vmovaps [rsp+0x40], xmm5
000074703edd8cb7  vmovaps [rsp+0x50], xmm6
000074703edd8cbd  vmovaps [rsp+0x60], xmm7
000074703edd8cc3  vmovaps [rsp+0x70], xmm8
000074703edd8cc9  vmovaps [rsp+0x80], xmm9
000074703edd8cd2  vmovaps [rsp+0x90], xmm10
000074703edd8cdb  vmovaps [rsp+0xA0], xmm11
000074703edd8ce4  vmovaps [rsp+0xB0], xmm12
000074703edd8ced  vmovaps [rsp+0xC0], xmm13
000074703edd8cf6  vmovaps [rsp+0xD0], xmm14
000074703edd8cff  vmovaps [rsp+0xE0], xmm15
000074703edd8d08  sub rsp, 0x30
000074703edd8d0c  movaps [rsp], xmm4
000074703edd8d10  movaps [rsp+0x10], xmm2
000074703edd8d15  movaps [rsp+0x20], xmm9
000074703edd8d1b  lea rdi, [rsp]
000074703edd8d1f  mov esi, 0x00
000074703edd8d24  mov rax, 0x5D9974CCC530
000074703edd8d2e  call rax
000074703edd8d30  movaps xmm4, [rsp]
000074703edd8d34  add rsp, 0x30
000074703edd8d38  vmovaps xmm0, [rsp]
000074703edd8d3d  vmovaps xmm1, [rsp+0x10]
000074703edd8d43  vmovaps xmm2, [rsp+0x20]
000074703edd8d49  vmovaps xmm3, [rsp+0x30]
000074703edd8d4f  vmovaps xmm5, [rsp+0x40]
000074703edd8d55  vmovaps xmm6, [rsp+0x50]
000074703edd8d5b  vmovaps xmm7, [rsp+0x60]
000074703edd8d61  vmovaps xmm8, [rsp+0x70]
000074703edd8d67  vmovaps xmm9, [rsp+0x80]
000074703edd8d70  vmovaps xmm10, [rsp+0x90]
000074703edd8d79  vmovaps xmm11, [rsp+0xA0]
000074703edd8d82  vmovaps xmm12, [rsp+0xB0]
000074703edd8d8b  vmovaps xmm13, [rsp+0xC0]
000074703edd8d94  vmovaps xmm14, [rsp+0xD0]
000074703edd8d9d  vmovaps xmm15, [rsp+0xE0]
000074703edd8da6  add rsp, 0xF0
000074703edd8dad  pop r11
000074703edd8daf  pop r10
000074703edd8db1  pop r9
000074703edd8db3  pop r8
000074703edd8db5  pop rsi
000074703edd8db6  pop rdi
000074703edd8db7  pop rdx
000074703edd8db8  pop rcx
000074703edd8db9  pop rax
000074703edd8dba  add rsp, 0x08
000074703edd8dbe  jmp 0x000074703EDD616B
000074703edd8dc3  sub rsp, 0x08
000074703edd8dc7  push rax
000074703edd8dc8  push rcx
000074703edd8dc9  push rdx
000074703edd8dca  push rdi
000074703edd8dcb  push rsi
000074703edd8dcc  push r8
000074703edd8dce  push r9
000074703edd8dd0  push r10
000074703edd8dd2  push r11
000074703edd8dd4  sub rsp, 0xF0
000074703edd8ddb  vmovaps [rsp], xmm0
000074703edd8de0  vmovaps [rsp+0x10], xmm1
000074703edd8de6  vmovaps [rsp+0x20], xmm2
000074703edd8dec  vmovaps [rsp+0x30], xmm3
000074703edd8df2  vmovaps [rsp+0x40], xmm4
000074703edd8df8  vmovaps [rsp+0x50], xmm5
000074703edd8dfe  vmovaps [rsp+0x60], xmm6
000074703edd8e04  vmovaps [rsp+0x70], xmm7
000074703edd8e0a  vmovaps [rsp+0x80], xmm8
000074703edd8e13  vmovaps [rsp+0x90], xmm10
000074703edd8e1c  vmovaps [rsp+0xA0], xmm11
000074703edd8e25  vmovaps [rsp+0xB0], xmm12
000074703edd8e2e  vmovaps [rsp+0xC0], xmm13
000074703edd8e37  vmovaps [rsp+0xD0], xmm14
000074703edd8e40  vmovaps [rsp+0xE0], xmm15
000074703edd8e49  sub rsp, 0x30
000074703edd8e4d  movaps [rsp], xmm9
000074703edd8e52  movaps [rsp+0x10], xmm2
000074703edd8e57  movaps [rsp+0x20], xmm1
000074703edd8e5c  lea rdi, [rsp]
000074703edd8e60  mov esi, 0x00
000074703edd8e65  mov rax, 0x5D9974CCC530
000074703edd8e6f  call rax
000074703edd8e71  movaps xmm9, [rsp]
000074703edd8e76  add rsp, 0x30
000074703edd8e7a  vmovaps xmm0, [rsp]
000074703edd8e7f  vmovaps xmm1, [rsp+0x10]
000074703edd8e85  vmovaps xmm2, [rsp+0x20]
000074703edd8e8b  vmovaps xmm3, [rsp+0x30]
000074703edd8e91  vmovaps xmm4, [rsp+0x40]
000074703edd8e97  vmovaps xmm5, [rsp+0x50]
000074703edd8e9d  vmovaps xmm6, [rsp+0x60]
000074703edd8ea3  vmovaps xmm7, [rsp+0x70]
000074703edd8ea9  vmovaps xmm8, [rsp+0x80]
000074703edd8eb2  vmovaps xmm10, [rsp+0x90]
000074703edd8ebb  vmovaps xmm11, [rsp+0xA0]
000074703edd8ec4  vmovaps xmm12, [rsp+0xB0]
000074703edd8ecd  vmovaps xmm13, [rsp+0xC0]
000074703edd8ed6  vmovaps xmm14, [rsp+0xD0]
000074703edd8edf  vmovaps xmm15, [rsp+0xE0]
000074703edd8ee8  add rsp, 0xF0
000074703edd8eef  pop r11
000074703edd8ef1  pop r10
000074703edd8ef3  pop r9
000074703edd8ef5  pop r8
000074703edd8ef7  pop rsi
000074703edd8ef8  pop rdi
000074703edd8ef9  pop rdx
000074703edd8efa  pop rcx
000074703edd8efb  pop rax
000074703edd8efc  add rsp, 0x08
000074703edd8f00  jmp 0x000074703EDD61A1
000074703edd8f05  sub rsp, 0x08
000074703edd8f09  push rax
000074703edd8f0a  push rcx
000074703edd8f0b  push rdx
000074703edd8f0c  push rdi
000074703edd8f0d  push rsi
000074703edd8f0e  push r8
000074703edd8f10  push r9
000074703edd8f12  push r10
000074703edd8f14  push r11
000074703edd8f16  sub rsp, 0xF0
000074703edd8f1d  vmovaps [rsp], xmm0
000074703edd8f22  vmovaps [rsp+0x10], xmm2
000074703edd8f28  vmovaps [rsp+0x20], xmm3
000074703edd8f2e  vmovaps [rsp+0x30], xmm4
000074703edd8f34  vmovaps [rsp+0x40], xmm5
000074703edd8f3a  vmovaps [rsp+0x50], xmm6
000074703edd8f40  vmovaps [rsp+0x60], xmm7
000074703edd8f46  vmovaps [rsp+0x70], xmm8
000074703edd8f4c  vmovaps [rsp+0x80], xmm9
000074703edd8f55  vmovaps [rsp+0x90], xmm10
000074703edd8f5e  vmovaps [rsp+0xA0], xmm11
000074703edd8f67  vmovaps [rsp+0xB0], xmm12
000074703edd8f70  vmovaps [rsp+0xC0], xmm13
000074703edd8f79  vmovaps [rsp+0xD0], xmm14
000074703edd8f82  vmovaps [rsp+0xE0], xmm15
000074703edd8f8b  sub rsp, 0x30
000074703edd8f8f  movaps [rsp], xmm1
000074703edd8f93  movaps [rsp+0x10], xmm15
000074703edd8f99  movaps [rsp+0x20], xmm6
000074703edd8f9e  lea rdi, [rsp]
000074703edd8fa2  mov esi, 0x00
000074703edd8fa7  mov rax, 0x5D9974CCC530
000074703edd8fb1  call rax
000074703edd8fb3  movaps xmm1, [rsp]
000074703edd8fb7  add rsp, 0x30
000074703edd8fbb  vmovaps xmm0, [rsp]
000074703edd8fc0  vmovaps xmm2, [rsp+0x10]
000074703edd8fc6  vmovaps xmm3, [rsp+0x20]
000074703edd8fcc  vmovaps xmm4, [rsp+0x30]
000074703edd8fd2  vmovaps xmm5, [rsp+0x40]
000074703edd8fd8  vmovaps xmm6, [rsp+0x50]
000074703edd8fde  vmovaps xmm7, [rsp+0x60]
000074703edd8fe4  vmovaps xmm8, [rsp+0x70]
000074703edd8fea  vmovaps xmm9, [rsp+0x80]
000074703edd8ff3  vmovaps xmm10, [rsp+0x90]
000074703edd8ffc  vmovaps xmm11, [rsp+0xA0]
000074703edd9005  vmovaps xmm12, [rsp+0xB0]
000074703edd900e  vmovaps xmm13, [rsp+0xC0]
000074703edd9017  vmovaps xmm14, [rsp+0xD0]
000074703edd9020  vmovaps xmm15, [rsp+0xE0]
000074703edd9029  add rsp, 0xF0
000074703edd9030  pop r11
000074703edd9032  pop r10
000074703edd9034  pop r9
000074703edd9036  pop r8
000074703edd9038  pop rsi
000074703edd9039  pop rdi
000074703edd903a  pop rdx
000074703edd903b  pop rcx
000074703edd903c  pop rax
000074703edd903d  add rsp, 0x08
000074703edd9041  jmp 0x000074703EDD61C2
000074703edd9046  sub rsp, 0x08
000074703edd904a  push rax
000074703edd904b  push rcx
000074703edd904c  push rdx
000074703edd904d  push rdi
000074703edd904e  push rsi
000074703edd904f  push r8
000074703edd9051  push r9
000074703edd9053  push r10
000074703edd9055  push r11
000074703edd9057  sub rsp, 0xF0
000074703edd905e  vmovaps [rsp], xmm0
000074703edd9063  vmovaps [rsp+0x10], xmm1
000074703edd9069  vmovaps [rsp+0x20], xmm2
000074703edd906f  vmovaps [rsp+0x30], xmm3
000074703edd9075  vmovaps [rsp+0x40], xmm4
000074703edd907b  vmovaps [rsp+0x50], xmm5
000074703edd9081  vmovaps [rsp+0x60], xmm6
000074703edd9087  vmovaps [rsp+0x70], xmm7
000074703edd908d  vmovaps [rsp+0x80], xmm8
000074703edd9096  vmovaps [rsp+0x90], xmm9
000074703edd909f  vmovaps [rsp+0xA0], xmm10
000074703edd90a8  vmovaps [rsp+0xB0], xmm11
000074703edd90b1  vmovaps [rsp+0xC0], xmm12
000074703edd90ba  vmovaps [rsp+0xD0], xmm13
000074703edd90c3  vmovaps [rsp+0xE0], xmm14
000074703edd90cc  sub rsp, 0x30
000074703edd90d0  movaps [rsp], xmm15
000074703edd90d5  movaps [rsp+0x10], xmm5
000074703edd90da  movaps [rsp+0x20], xmm3
000074703edd90df  lea rdi, [rsp]
000074703edd90e3  mov esi, 0x00
000074703edd90e8  mov rax, 0x5D9974CCC530
000074703edd90f2  call rax
000074703edd90f4  movaps xmm15, [rsp]
000074703edd90f9  add rsp, 0x30
000074703edd90fd  vmovaps xmm0, [rsp]
000074703edd9102  vmovaps xmm1, [rsp+0x10]
000074703edd9108  vmovaps xmm2, [rsp+0x20]
000074703edd910e  vmovaps xmm3, [rsp+0x30]
000074703edd9114  vmovaps xmm4, [rsp+0x40]
000074703edd911a  vmovaps xmm5, [rsp+0x50]
000074703edd9120  vmovaps xmm6, [rsp+0x60]
000074703edd9126  vmovaps xmm7, [rsp+0x70]
000074703edd912c  vmovaps xmm8, [rsp+0x80]
000074703edd9135  vmovaps xmm9, [rsp+0x90]
000074703edd913e  vmovaps xmm10, [rsp+0xA0]
000074703edd9147  vmovaps xmm11, [rsp+0xB0]
000074703edd9150  vmovaps xmm12, [rsp+0xC0]
000074703edd9159  vmovaps xmm13, [rsp+0xD0]
000074703edd9162  vmovaps xmm14, [rsp+0xE0]
000074703edd916b  add rsp, 0xF0
000074703edd9172  pop r11
000074703edd9174  pop r10
000074703edd9176  pop r9
000074703edd9178  pop r8
000074703edd917a  pop rsi
000074703edd917b  pop rdi
000074703edd917c  pop rdx
000074703edd917d  pop rcx
000074703edd917e  pop rax
000074703edd917f  add rsp, 0x08
000074703edd9183  jmp 0x000074703EDD61DC
000074703edd9188  sub rsp, 0x08
000074703edd918c  push rax
000074703edd918d  push rcx
000074703edd918e  push rdx
000074703edd918f  push rdi
000074703edd9190  push rsi
000074703edd9191  push r8
000074703edd9193  push r9
000074703edd9195  push r10
000074703edd9197  push r11
000074703edd9199  sub rsp, 0xF0
000074703edd91a0  vmovaps [rsp], xmm0
000074703edd91a5  vmovaps [rsp+0x10], xmm1
000074703edd91ab  vmovaps [rsp+0x20], xmm2
000074703edd91b1  vmovaps [rsp+0x30], xmm3
000074703edd91b7  vmovaps [rsp+0x40], xmm4
000074703edd91bd  vmovaps [rsp+0x50], xmm6
000074703edd91c3  vmovaps [rsp+0x60], xmm7
000074703edd91c9  vmovaps [rsp+0x70], xmm8
000074703edd91cf  vmovaps [rsp+0x80], xmm9
000074703edd91d8  vmovaps [rsp+0x90], xmm10
000074703edd91e1  vmovaps [rsp+0xA0], xmm11
000074703edd91ea  vmovaps [rsp+0xB0], xmm12
000074703edd91f3  vmovaps [rsp+0xC0], xmm13
000074703edd91fc  vmovaps [rsp+0xD0], xmm14
000074703edd9205  vmovaps [rsp+0xE0], xmm15
000074703edd920e  sub rsp, 0x30
000074703edd9212  movaps [rsp], xmm5
000074703edd9216  movaps [rsp+0x10], xmm8
000074703edd921c  movaps [rsp+0x20], xmm6
000074703edd9221  lea rdi, [rsp]
000074703edd9225  mov esi, 0x00
000074703edd922a  mov rax, 0x5D9974CCC530
000074703edd9234  call rax
000074703edd9236  movaps xmm5, [rsp]
000074703edd923a  add rsp, 0x30
000074703edd923e  vmovaps xmm0, [rsp]
000074703edd9243  vmovaps xmm1, [rsp+0x10]
000074703edd9249  vmovaps xmm2, [rsp+0x20]
000074703edd924f  vmovaps xmm3, [rsp+0x30]
000074703edd9255  vmovaps xmm4, [rsp+0x40]
000074703edd925b  vmovaps xmm6, [rsp+0x50]
000074703edd9261  vmovaps xmm7, [rsp+0x60]
000074703edd9267  vmovaps xmm8, [rsp+0x70]
000074703edd926d  vmovaps xmm9, [rsp+0x80]
000074703edd9276  vmovaps xmm10, [rsp+0x90]
000074703edd927f  vmovaps xmm11, [rsp+0xA0]
000074703edd9288  vmovaps xmm12, [rsp+0xB0]
000074703edd9291  vmovaps xmm13, [rsp+0xC0]
000074703edd929a  vmovaps xmm14, [rsp+0xD0]
000074703edd92a3  vmovaps xmm15, [rsp+0xE0]
000074703edd92ac  add rsp, 0xF0
000074703edd92b3  pop r11
000074703edd92b5  pop r10
000074703edd92b7  pop r9
000074703edd92b9  pop r8
000074703edd92bb  pop rsi
000074703edd92bc  pop rdi
000074703edd92bd  pop rdx
000074703edd92be  pop rcx
000074703edd92bf  pop rax
000074703edd92c0  add rsp, 0x08
000074703edd92c4  jmp 0x000074703EDD6200
000074703edd92c9  sub rsp, 0x08
000074703edd92cd  push rax
000074703edd92ce  push rcx
000074703edd92cf  push rdx
000074703edd92d0  push rdi
000074703edd92d1  push rsi
000074703edd92d2  push r8
000074703edd92d4  push r9
000074703edd92d6  push r10
000074703edd92d8  push r11
000074703edd92da  sub rsp, 0xF0
000074703edd92e1  vmovaps [rsp], xmm0
000074703edd92e6  vmovaps [rsp+0x10], xmm1
000074703edd92ec  vmovaps [rsp+0x20], xmm2
000074703edd92f2  vmovaps [rsp+0x30], xmm3
000074703edd92f8  vmovaps [rsp+0x40], xmm4
000074703edd92fe  vmovaps [rsp+0x50], xmm5
000074703edd9304  vmovaps [rsp+0x60], xmm7
000074703edd930a  vmovaps [rsp+0x70], xmm8
000074703edd9310  vmovaps [rsp+0x80], xmm9
000074703edd9319  vmovaps [rsp+0x90], xmm10
000074703edd9322  vmovaps [rsp+0xA0], xmm11
000074703edd932b  vmovaps [rsp+0xB0], xmm12
000074703edd9334  vmovaps [rsp+0xC0], xmm13
000074703edd933d  vmovaps [rsp+0xD0], xmm14
000074703edd9346  vmovaps [rsp+0xE0], xmm15
000074703edd934f  sub rsp, 0x30
000074703edd9353  movaps [rsp], xmm6
000074703edd9357  movaps [rsp+0x10], xmm10
000074703edd935d  movaps [rsp+0x20], xmm8
000074703edd9363  lea rdi, [rsp]
000074703edd9367  mov esi, 0x00
000074703edd936c  mov rax, 0x5D9974CCC530
000074703edd9376  call rax
000074703edd9378  movaps xmm6, [rsp]
000074703edd937c  add rsp, 0x30
000074703edd9380  vmovaps xmm0, [rsp]
000074703edd9385  vmovaps xmm1, [rsp+0x10]
000074703edd938b  vmovaps xmm2, [rsp+0x20]
000074703edd9391  vmovaps xmm3, [rsp+0x30]
000074703edd9397  vmovaps xmm4, [rsp+0x40]
000074703edd939d  vmovaps xmm5, [rsp+0x50]
000074703edd93a3  vmovaps xmm7, [rsp+0x60]
000074703edd93a9  vmovaps xmm8, [rsp+0x70]
000074703edd93af  vmovaps xmm9, [rsp+0x80]
000074703edd93b8  vmovaps xmm10, [rsp+0x90]
000074703edd93c1  vmovaps xmm11, [rsp+0xA0]
000074703edd93ca  vmovaps xmm12, [rsp+0xB0]
000074703edd93d3  vmovaps xmm13, [rsp+0xC0]
000074703edd93dc  vmovaps xmm14, [rsp+0xD0]
000074703edd93e5  vmovaps xmm15, [rsp+0xE0]
000074703edd93ee  add rsp, 0xF0
000074703edd93f5  pop r11
000074703edd93f7  pop r10
000074703edd93f9  pop r9
000074703edd93fb  pop r8
000074703edd93fd  pop rsi
000074703edd93fe  pop rdi
000074703edd93ff  pop rdx
000074703edd9400  pop rcx
000074703edd9401  pop rax
000074703edd9402  add rsp, 0x08
000074703edd9406  jmp 0x000074703EDD6225
000074703edd940b  sub rsp, 0x08
000074703edd940f  push rax
000074703edd9410  push rcx
000074703edd9411  push rdx
000074703edd9412  push rdi
000074703edd9413  push rsi
000074703edd9414  push r8
000074703edd9416  push r9
000074703edd9418  push r10
000074703edd941a  push r11
000074703edd941c  sub rsp, 0xF0
000074703edd9423  vmovaps [rsp], xmm0
000074703edd9428  vmovaps [rsp+0x10], xmm1
000074703edd942e  vmovaps [rsp+0x20], xmm2
000074703edd9434  vmovaps [rsp+0x30], xmm3
000074703edd943a  vmovaps [rsp+0x40], xmm4
000074703edd9440  vmovaps [rsp+0x50], xmm5
000074703edd9446  vmovaps [rsp+0x60], xmm6
000074703edd944c  vmovaps [rsp+0x70], xmm7
000074703edd9452  vmovaps [rsp+0x80], xmm8
000074703edd945b  vmovaps [rsp+0x90], xmm9
000074703edd9464  vmovaps [rsp+0xA0], xmm11
000074703edd946d  vmovaps [rsp+0xB0], xmm12
000074703edd9476  vmovaps [rsp+0xC0], xmm13
000074703edd947f  vmovaps [rsp+0xD0], xmm14
000074703edd9488  vmovaps [rsp+0xE0], xmm15
000074703edd9491  sub rsp, 0x30
000074703edd9495  movaps [rsp], xmm10
000074703edd949a  movaps [rsp+0x10], xmm8
000074703edd94a0  movaps [rsp+0x20], xmm14
000074703edd94a6  lea rdi, [rsp]
000074703edd94aa  mov esi, 0x00
000074703edd94af  mov rax, 0x5D9974CCC530
000074703edd94b9  call rax
000074703edd94bb  movaps xmm10, [rsp]
000074703edd94c0  add rsp, 0x30
000074703edd94c4  vmovaps xmm0, [rsp]
000074703edd94c9  vmovaps xmm1, [rsp+0x10]
000074703edd94cf  vmovaps xmm2, [rsp+0x20]
000074703edd94d5  vmovaps xmm3, [rsp+0x30]
000074703edd94db  vmovaps xmm4, [rsp+0x40]
000074703edd94e1  vmovaps xmm5, [rsp+0x50]
000074703edd94e7  vmovaps xmm6, [rsp+0x60]
000074703edd94ed  vmovaps xmm7, [rsp+0x70]
000074703edd94f3  vmovaps xmm8, [rsp+0x80]
000074703edd94fc  vmovaps xmm9, [rsp+0x90]
000074703edd9505  vmovaps xmm11, [rsp+0xA0]
000074703edd950e  vmovaps xmm12, [rsp+0xB0]
000074703edd9517  vmovaps xmm13, [rsp+0xC0]
000074703edd9520  vmovaps xmm14, [rsp+0xD0]
000074703edd9529  vmovaps xmm15, [rsp+0xE0]
000074703edd9532  add rsp, 0xF0
000074703edd9539  pop r11
000074703edd953b  pop r10
000074703edd953d  pop r9
000074703edd953f  pop r8
000074703edd9541  pop rsi
000074703edd9542  pop rdi
000074703edd9543  pop rdx
000074703edd9544  pop rcx
000074703edd9545  pop rax
000074703edd9546  add rsp, 0x08
000074703edd954a  jmp 0x000074703EDD6245
000074703edd954f  sub rsp, 0x08
000074703edd9553  push rax
000074703edd9554  push rcx
000074703edd9555  push rdx
000074703edd9556  push rdi
000074703edd9557  push rsi
000074703edd9558  push r8
000074703edd955a  push r9
000074703edd955c  push r10
000074703edd955e  push r11
000074703edd9560  sub rsp, 0xF0
000074703edd9567  vmovaps [rsp], xmm0
000074703edd956c  vmovaps [rsp+0x10], xmm1
000074703edd9572  vmovaps [rsp+0x20], xmm2
000074703edd9578  vmovaps [rsp+0x30], xmm3
000074703edd957e  vmovaps [rsp+0x40], xmm4
000074703edd9584  vmovaps [rsp+0x50], xmm5
000074703edd958a  vmovaps [rsp+0x60], xmm6
000074703edd9590  vmovaps [rsp+0x70], xmm7
000074703edd9596  vmovaps [rsp+0x80], xmm8
000074703edd959f  vmovaps [rsp+0x90], xmm9
000074703edd95a8  vmovaps [rsp+0xA0], xmm10
000074703edd95b1  vmovaps [rsp+0xB0], xmm11
000074703edd95ba  vmovaps [rsp+0xC0], xmm12
000074703edd95c3  vmovaps [rsp+0xD0], xmm13
000074703edd95cc  vmovaps [rsp+0xE0], xmm15
000074703edd95d5  sub rsp, 0x30
000074703edd95d9  movaps [rsp], xmm14
000074703edd95de  movaps [rsp+0x10], xmm8
000074703edd95e4  movaps [rsp+0x20], xmm4
000074703edd95e9  lea rdi, [rsp]
000074703edd95ed  mov esi, 0x00
000074703edd95f2  mov rax, 0x5D9974CCC530
000074703edd95fc  call rax
000074703edd95fe  movaps xmm14, [rsp]
000074703edd9603  add rsp, 0x30
000074703edd9607  vmovaps xmm0, [rsp]
000074703edd960c  vmovaps xmm1, [rsp+0x10]
000074703edd9612  vmovaps xmm2, [rsp+0x20]
000074703edd9618  vmovaps xmm3, [rsp+0x30]
000074703edd961e  vmovaps xmm4, [rsp+0x40]
000074703edd9624  vmovaps xmm5, [rsp+0x50]
000074703edd962a  vmovaps xmm6, [rsp+0x60]
000074703edd9630  vmovaps xmm7, [rsp+0x70]
000074703edd9636  vmovaps xmm8, [rsp+0x80]
000074703edd963f  vmovaps xmm9, [rsp+0x90]
000074703edd9648  vmovaps xmm10, [rsp+0xA0]
000074703edd9651  vmovaps xmm11, [rsp+0xB0]
000074703edd965a  vmovaps xmm12, [rsp+0xC0]
000074703edd9663  vmovaps xmm13, [rsp+0xD0]
000074703edd966c  vmovaps xmm15, [rsp+0xE0]
000074703edd9675  add rsp, 0xF0
000074703edd967c  pop r11
000074703edd967e  pop r10
000074703edd9680  pop r9
000074703edd9682  pop r8
000074703edd9684  pop rsi
000074703edd9685  pop rdi
000074703edd9686  pop rdx
000074703edd9687  pop rcx
000074703edd9688  pop rax
000074703edd9689  add rsp, 0x08
000074703edd968d  jmp 0x000074703EDD6265
000074703edd9692  sub rsp, 0x08
000074703edd9696  push rax
000074703edd9697  push rcx
000074703edd9698  push rdx
000074703edd9699  push rdi
000074703edd969a  push rsi
000074703edd969b  push r8
000074703edd969d  push r9
000074703edd969f  push r10
000074703edd96a1  push r11
000074703edd96a3  sub rsp, 0xF0
000074703edd96aa  vmovaps [rsp], xmm0
000074703edd96af  vmovaps [rsp+0x10], xmm1
000074703edd96b5  vmovaps [rsp+0x20], xmm2
000074703edd96bb  vmovaps [rsp+0x30], xmm3
000074703edd96c1  vmovaps [rsp+0x40], xmm5
000074703edd96c7  vmovaps [rsp+0x50], xmm6
000074703edd96cd  vmovaps [rsp+0x60], xmm7
000074703edd96d3  vmovaps [rsp+0x70], xmm8
000074703edd96d9  vmovaps [rsp+0x80], xmm9
000074703edd96e2  vmovaps [rsp+0x90], xmm10
000074703edd96eb  vmovaps [rsp+0xA0], xmm11
000074703edd96f4  vmovaps [rsp+0xB0], xmm12
000074703edd96fd  vmovaps [rsp+0xC0], xmm13
000074703edd9706  vmovaps [rsp+0xD0], xmm14
000074703edd970f  vmovaps [rsp+0xE0], xmm15
000074703edd9718  sub rsp, 0x30
000074703edd971c  movaps [rsp], xmm4
000074703edd9720  movaps [rsp+0x10], xmm13
000074703edd9726  movaps [rsp+0x20], xmm8
000074703edd972c  lea rdi, [rsp]
000074703edd9730  mov esi, 0x00
000074703edd9735  mov rax, 0x5D9974CCC530
000074703edd973f  call rax
000074703edd9741  movaps xmm4, [rsp]
000074703edd9745  add rsp, 0x30
000074703edd9749  vmovaps xmm0, [rsp]
000074703edd974e  vmovaps xmm1, [rsp+0x10]
000074703edd9754  vmovaps xmm2, [rsp+0x20]
000074703edd975a  vmovaps xmm3, [rsp+0x30]
000074703edd9760  vmovaps xmm5, [rsp+0x40]
000074703edd9766  vmovaps xmm6, [rsp+0x50]
000074703edd976c  vmovaps xmm7, [rsp+0x60]
000074703edd9772  vmovaps xmm8, [rsp+0x70]
000074703edd9778  vmovaps xmm9, [rsp+0x80]
000074703edd9781  vmovaps xmm10, [rsp+0x90]
000074703edd978a  vmovaps xmm11, [rsp+0xA0]
000074703edd9793  vmovaps xmm12, [rsp+0xB0]
000074703edd979c  vmovaps xmm13, [rsp+0xC0]
000074703edd97a5  vmovaps xmm14, [rsp+0xD0]
000074703edd97ae  vmovaps xmm15, [rsp+0xE0]
000074703edd97b7  add rsp, 0xF0
000074703edd97be  pop r11
000074703edd97c0  pop r10
000074703edd97c2  pop r9
000074703edd97c4  pop r8
000074703edd97c6  pop rsi
000074703edd97c7  pop rdi
000074703edd97c8  pop rdx
000074703edd97c9  pop rcx
000074703edd97ca  pop rax
000074703edd97cb  add rsp, 0x08
000074703edd97cf  jmp 0x000074703EDD628A
000074703edd97d4  sub rsp, 0x08
000074703edd97d8  push rax
000074703edd97d9  push rcx
000074703edd97da  push rdx
000074703edd97db  push rdi
000074703edd97dc  push rsi
000074703edd97dd  push r8
000074703edd97df  push r9
000074703edd97e1  push r10
000074703edd97e3  push r11
000074703edd97e5  sub rsp, 0xF0
000074703edd97ec  vmovaps [rsp], xmm0
000074703edd97f1  vmovaps [rsp+0x10], xmm1
000074703edd97f7  vmovaps [rsp+0x20], xmm2
000074703edd97fd  vmovaps [rsp+0x30], xmm3
000074703edd9803  vmovaps [rsp+0x40], xmm4
000074703edd9809  vmovaps [rsp+0x50], xmm5
000074703edd980f  vmovaps [rsp+0x60], xmm6
000074703edd9815  vmovaps [rsp+0x70], xmm7
000074703edd981b  vmovaps [rsp+0x80], xmm8
000074703edd9824  vmovaps [rsp+0x90], xmm9
000074703edd982d  vmovaps [rsp+0xA0], xmm10
000074703edd9836  vmovaps [rsp+0xB0], xmm11
000074703edd983f  vmovaps [rsp+0xC0], xmm12
000074703edd9848  vmovaps [rsp+0xD0], xmm14
000074703edd9851  vmovaps [rsp+0xE0], xmm15
000074703edd985a  sub rsp, 0x30
000074703edd985e  movaps [rsp], xmm13
000074703edd9863  movaps [rsp+0x10], xmm15
000074703edd9869  movaps [rsp+0x20], xmm9
000074703edd986f  lea rdi, [rsp]
000074703edd9873  mov esi, 0x00
000074703edd9878  mov rax, 0x5D9974CCC530
000074703edd9882  call rax
000074703edd9884  movaps xmm13, [rsp]
000074703edd9889  add rsp, 0x30
000074703edd988d  vmovaps xmm0, [rsp]
000074703edd9892  vmovaps xmm1, [rsp+0x10]
000074703edd9898  vmovaps xmm2, [rsp+0x20]
000074703edd989e  vmovaps xmm3, [rsp+0x30]
000074703edd98a4  vmovaps xmm4, [rsp+0x40]
000074703edd98aa  vmovaps xmm5, [rsp+0x50]
000074703edd98b0  vmovaps xmm6, [rsp+0x60]
000074703edd98b6  vmovaps xmm7, [rsp+0x70]
000074703edd98bc  vmovaps xmm8, [rsp+0x80]
000074703edd98c5  vmovaps xmm9, [rsp+0x90]
000074703edd98ce  vmovaps xmm10, [rsp+0xA0]
000074703edd98d7  vmovaps xmm11, [rsp+0xB0]
000074703edd98e0  vmovaps xmm12, [rsp+0xC0]
000074703edd98e9  vmovaps xmm14, [rsp+0xD0]
000074703edd98f2  vmovaps xmm15, [rsp+0xE0]
000074703edd98fb  add rsp, 0xF0
000074703edd9902  pop r11
000074703edd9904  pop r10
000074703edd9906  pop r9
000074703edd9908  pop r8
000074703edd990a  pop rsi
000074703edd990b  pop rdi
000074703edd990c  pop rdx
000074703edd990d  pop rcx
000074703edd990e  pop rax
000074703edd990f  add rsp, 0x08
000074703edd9913  jmp 0x000074703EDD62A5
000074703edd9918  sub rsp, 0x08
000074703edd991c  push rax
000074703edd991d  push rcx
000074703edd991e  push rdx
000074703edd991f  push rdi
000074703edd9920  push rsi
000074703edd9921  push r8
000074703edd9923  push r9
000074703edd9925  push r10
000074703edd9927  push r11
000074703edd9929  sub rsp, 0xF0
000074703edd9930  vmovaps [rsp], xmm0
000074703edd9935  vmovaps [rsp+0x10], xmm1
000074703edd993b  vmovaps [rsp+0x20], xmm2
000074703edd9941  vmovaps [rsp+0x30], xmm3
000074703edd9947  vmovaps [rsp+0x40], xmm4
000074703edd994d  vmovaps [rsp+0x50], xmm5
000074703edd9953  vmovaps [rsp+0x60], xmm6
000074703edd9959  vmovaps [rsp+0x70], xmm7
000074703edd995f  vmovaps [rsp+0x80], xmm8
000074703edd9968  vmovaps [rsp+0x90], xmm9
000074703edd9971  vmovaps [rsp+0xA0], xmm10
000074703edd997a  vmovaps [rsp+0xB0], xmm11
000074703edd9983  vmovaps [rsp+0xC0], xmm12
000074703edd998c  vmovaps [rsp+0xD0], xmm13
000074703edd9995  vmovaps [rsp+0xE0], xmm14
000074703edd999e  sub rsp, 0x30
000074703edd99a2  movaps [rsp], xmm15
000074703edd99a7  movaps [rsp+0x10], xmm1
000074703edd99ac  movaps [rsp+0x20], xmm5
000074703edd99b1  lea rdi, [rsp]
000074703edd99b5  mov esi, 0x00
000074703edd99ba  mov rax, 0x5D9974CCC530
000074703edd99c4  call rax
000074703edd99c6  movaps xmm15, [rsp]
000074703edd99cb  add rsp, 0x30
000074703edd99cf  vmovaps xmm0, [rsp]
000074703edd99d4  vmovaps xmm1, [rsp+0x10]
000074703edd99da  vmovaps xmm2, [rsp+0x20]
000074703edd99e0  vmovaps xmm3, [rsp+0x30]
000074703edd99e6  vmovaps xmm4, [rsp+0x40]
000074703edd99ec  vmovaps xmm5, [rsp+0x50]
000074703edd99f2  vmovaps xmm6, [rsp+0x60]
000074703edd99f8  vmovaps xmm7, [rsp+0x70]
000074703edd99fe  vmovaps xmm8, [rsp+0x80]
000074703edd9a07  vmovaps xmm9, [rsp+0x90]
000074703edd9a10  vmovaps xmm10, [rsp+0xA0]
000074703edd9a19  vmovaps xmm11, [rsp+0xB0]
000074703edd9a22  vmovaps xmm12, [rsp+0xC0]
000074703edd9a2b  vmovaps xmm13, [rsp+0xD0]
000074703edd9a34  vmovaps xmm14, [rsp+0xE0]
000074703edd9a3d  add rsp, 0xF0
000074703edd9a44  pop r11
000074703edd9a46  pop r10
000074703edd9a48  pop r9
000074703edd9a4a  pop r8
000074703edd9a4c  pop rsi
000074703edd9a4d  pop rdi
000074703edd9a4e  pop rdx
000074703edd9a4f  pop rcx
000074703edd9a50  pop rax
000074703edd9a51  add rsp, 0x08
000074703edd9a55  jmp 0x000074703EDD62C0
000074703edd9a5a  call 0x000074703ECD64F0
000074703edd9a5f  jmp 0x000074703EDD631B
000074703edd9a64  sub rsp, 0x08
000074703edd9a68  push rax
000074703edd9a69  push rcx
000074703edd9a6a  push rdx
000074703edd9a6b  push rdi
000074703edd9a6c  push rsi
000074703edd9a6d  push r8
000074703edd9a6f  push r9
000074703edd9a71  push r10
000074703edd9a73  push r11
000074703edd9a75  sub rsp, 0xF0
000074703edd9a7c  vmovaps [rsp], xmm0
000074703edd9a81  vmovaps [rsp+0x10], xmm1
000074703edd9a87  vmovaps [rsp+0x20], xmm2
000074703edd9a8d  vmovaps [rsp+0x30], xmm3
000074703edd9a93  vmovaps [rsp+0x40], xmm4
000074703edd9a99  vmovaps [rsp+0x50], xmm5
000074703edd9a9f  vmovaps [rsp+0x60], xmm6
000074703edd9aa5  vmovaps [rsp+0x70], xmm7
000074703edd9aab  vmovaps [rsp+0x80], xmm8
000074703edd9ab4  vmovaps [rsp+0x90], xmm10
000074703edd9abd  vmovaps [rsp+0xA0], xmm11
000074703edd9ac6  vmovaps [rsp+0xB0], xmm12
000074703edd9acf  vmovaps [rsp+0xC0], xmm13
000074703edd9ad8  vmovaps [rsp+0xD0], xmm14
000074703edd9ae1  vmovaps [rsp+0xE0], xmm15
000074703edd9aea  sub rsp, 0x30
000074703edd9aee  movaps [rsp], xmm9
000074703edd9af3  movaps [rsp+0x10], xmm8
000074703edd9af9  movaps [rsp+0x20], xmm11
000074703edd9aff  lea rdi, [rsp]
000074703edd9b03  mov esi, 0x00
000074703edd9b08  mov rax, 0x5D9974CCC530
000074703edd9b12  call rax
000074703edd9b14  movaps xmm9, [rsp]
000074703edd9b19  add rsp, 0x30
000074703edd9b1d  vmovaps xmm0, [rsp]
000074703edd9b22  vmovaps xmm1, [rsp+0x10]
000074703edd9b28  vmovaps xmm2, [rsp+0x20]
000074703edd9b2e  vmovaps xmm3, [rsp+0x30]
000074703edd9b34  vmovaps xmm4, [rsp+0x40]
000074703edd9b3a  vmovaps xmm5, [rsp+0x50]
000074703edd9b40  vmovaps xmm6, [rsp+0x60]
000074703edd9b46  vmovaps xmm7, [rsp+0x70]
000074703edd9b4c  vmovaps xmm8, [rsp+0x80]
000074703edd9b55  vmovaps xmm10, [rsp+0x90]
000074703edd9b5e  vmovaps xmm11, [rsp+0xA0]
000074703edd9b67  vmovaps xmm12, [rsp+0xB0]
000074703edd9b70  vmovaps xmm13, [rsp+0xC0]
000074703edd9b79  vmovaps xmm14, [rsp+0xD0]
000074703edd9b82  vmovaps xmm15, [rsp+0xE0]
000074703edd9b8b  add rsp, 0xF0
000074703edd9b92  pop r11
000074703edd9b94  pop r10
000074703edd9b96  pop r9
000074703edd9b98  pop r8
000074703edd9b9a  pop rsi
000074703edd9b9b  pop rdi
000074703edd9b9c  pop rdx
000074703edd9b9d  pop rcx
000074703edd9b9e  pop rax
000074703edd9b9f  add rsp, 0x08
000074703edd9ba3  jmp 0x000074703EDD6352
000074703edd9ba8  sub rsp, 0x08
000074703edd9bac  push rax
000074703edd9bad  push rcx
000074703edd9bae  push rdx
000074703edd9baf  push rdi
000074703edd9bb0  push rsi
000074703edd9bb1  push r8
000074703edd9bb3  push r9
000074703edd9bb5  push r10
000074703edd9bb7  push r11
000074703edd9bb9  sub rsp, 0xF0
000074703edd9bc0  vmovaps [rsp], xmm0
000074703edd9bc5  vmovaps [rsp+0x10], xmm1
000074703edd9bcb  vmovaps [rsp+0x20], xmm2
000074703edd9bd1  vmovaps [rsp+0x30], xmm3
000074703edd9bd7  vmovaps [rsp+0x40], xmm4
000074703edd9bdd  vmovaps [rsp+0x50], xmm5
000074703edd9be3  vmovaps [rsp+0x60], xmm6
000074703edd9be9  vmovaps [rsp+0x70], xmm7
000074703edd9bef  vmovaps [rsp+0x80], xmm8
000074703edd9bf8  vmovaps [rsp+0x90], xmm9
000074703edd9c01  vmovaps [rsp+0xA0], xmm10
000074703edd9c0a  vmovaps [rsp+0xB0], xmm12
000074703edd9c13  vmovaps [rsp+0xC0], xmm13
000074703edd9c1c  vmovaps [rsp+0xD0], xmm14
000074703edd9c25  vmovaps [rsp+0xE0], xmm15
000074703edd9c2e  sub rsp, 0x30
000074703edd9c32  movaps [rsp], xmm11
000074703edd9c37  movaps [rsp+0x10], xmm10
000074703edd9c3d  movaps [rsp+0x20], xmm6
000074703edd9c42  lea rdi, [rsp]
000074703edd9c46  mov esi, 0x00
000074703edd9c4b  mov rax, 0x5D9974CCC530
000074703edd9c55  call rax
000074703edd9c57  movaps xmm11, [rsp]
000074703edd9c5c  add rsp, 0x30
000074703edd9c60  vmovaps xmm0, [rsp]
000074703edd9c65  vmovaps xmm1, [rsp+0x10]
000074703edd9c6b  vmovaps xmm2, [rsp+0x20]
000074703edd9c71  vmovaps xmm3, [rsp+0x30]
000074703edd9c77  vmovaps xmm4, [rsp+0x40]
000074703edd9c7d  vmovaps xmm5, [rsp+0x50]
000074703edd9c83  vmovaps xmm6, [rsp+0x60]
000074703edd9c89  vmovaps xmm7, [rsp+0x70]
000074703edd9c8f  vmovaps xmm8, [rsp+0x80]
000074703edd9c98  vmovaps xmm9, [rsp+0x90]
000074703edd9ca1  vmovaps xmm10, [rsp+0xA0]
000074703edd9caa  vmovaps xmm12, [rsp+0xB0]
000074703edd9cb3  vmovaps xmm13, [rsp+0xC0]
000074703edd9cbc  vmovaps xmm14, [rsp+0xD0]
000074703edd9cc5  vmovaps xmm15, [rsp+0xE0]
000074703edd9cce  add rsp, 0xF0
000074703edd9cd5  pop r11
000074703edd9cd7  pop r10
000074703edd9cd9  pop r9
000074703edd9cdb  pop r8
000074703edd9cdd  pop rsi
000074703edd9cde  pop rdi
000074703edd9cdf  pop rdx
000074703edd9ce0  pop rcx
000074703edd9ce1  pop rax
000074703edd9ce2  add rsp, 0x08
000074703edd9ce6  jmp 0x000074703EDD636D
000074703edd9ceb  sub rsp, 0x08
000074703edd9cef  push rax
000074703edd9cf0  push rcx
000074703edd9cf1  push rdx
000074703edd9cf2  push rdi
000074703edd9cf3  push rsi
000074703edd9cf4  push r8
000074703edd9cf6  push r9
000074703edd9cf8  push r10
000074703edd9cfa  push r11
000074703edd9cfc  sub rsp, 0xF0
000074703edd9d03  vmovaps [rsp], xmm0
000074703edd9d08  vmovaps [rsp+0x10], xmm1
000074703edd9d0e  vmovaps [rsp+0x20], xmm2
000074703edd9d14  vmovaps [rsp+0x30], xmm3
000074703edd9d1a  vmovaps [rsp+0x40], xmm4
000074703edd9d20  vmovaps [rsp+0x50], xmm5
000074703edd9d26  vmovaps [rsp+0x60], xmm6
000074703edd9d2c  vmovaps [rsp+0x70], xmm7
000074703edd9d32  vmovaps [rsp+0x80], xmm8
000074703edd9d3b  vmovaps [rsp+0x90], xmm9
000074703edd9d44  vmovaps [rsp+0xA0], xmm11
000074703edd9d4d  vmovaps [rsp+0xB0], xmm12
000074703edd9d56  vmovaps [rsp+0xC0], xmm13
000074703edd9d5f  vmovaps [rsp+0xD0], xmm14
000074703edd9d68  vmovaps [rsp+0xE0], xmm15
000074703edd9d71  sub rsp, 0x30
000074703edd9d75  movaps [rsp], xmm10
000074703edd9d7a  movaps [rsp+0x10], xmm14
000074703edd9d80  movaps [rsp+0x20], xmm4
000074703edd9d85  lea rdi, [rsp]
000074703edd9d89  mov esi, 0x00
000074703edd9d8e  mov rax, 0x5D9974CCC530
000074703edd9d98  call rax
000074703edd9d9a  movaps xmm10, [rsp]
000074703edd9d9f  add rsp, 0x30
000074703edd9da3  vmovaps xmm0, [rsp]
000074703edd9da8  vmovaps xmm1, [rsp+0x10]
000074703edd9dae  vmovaps xmm2, [rsp+0x20]
000074703edd9db4  vmovaps xmm3, [rsp+0x30]
000074703edd9dba  vmovaps xmm4, [rsp+0x40]
000074703edd9dc0  vmovaps xmm5, [rsp+0x50]
000074703edd9dc6  vmovaps xmm6, [rsp+0x60]
000074703edd9dcc  vmovaps xmm7, [rsp+0x70]
000074703edd9dd2  vmovaps xmm8, [rsp+0x80]
000074703edd9ddb  vmovaps xmm9, [rsp+0x90]
000074703edd9de4  vmovaps xmm11, [rsp+0xA0]
000074703edd9ded  vmovaps xmm12, [rsp+0xB0]
000074703edd9df6  vmovaps xmm13, [rsp+0xC0]
000074703edd9dff  vmovaps xmm14, [rsp+0xD0]
000074703edd9e08  vmovaps xmm15, [rsp+0xE0]
000074703edd9e11  add rsp, 0xF0
000074703edd9e18  pop r11
000074703edd9e1a  pop r10
000074703edd9e1c  pop r9
000074703edd9e1e  pop r8
000074703edd9e20  pop rsi
000074703edd9e21  pop rdi
000074703edd9e22  pop rdx
000074703edd9e23  pop rcx
000074703edd9e24  pop rax
000074703edd9e25  add rsp, 0x08
000074703edd9e29  jmp 0x000074703EDD6388
000074703edd9e2e  sub rsp, 0x08
000074703edd9e32  push rax
000074703edd9e33  push rcx
000074703edd9e34  push rdx
000074703edd9e35  push rdi
000074703edd9e36  push rsi
000074703edd9e37  push r8
000074703edd9e39  push r9
000074703edd9e3b  push r10
000074703edd9e3d  push r11
000074703edd9e3f  sub rsp, 0xF0
000074703edd9e46  vmovaps [rsp], xmm0
000074703edd9e4b  vmovaps [rsp+0x10], xmm1
000074703edd9e51  vmovaps [rsp+0x20], xmm2
000074703edd9e57  vmovaps [rsp+0x30], xmm3
000074703edd9e5d  vmovaps [rsp+0x40], xmm4
000074703edd9e63  vmovaps [rsp+0x50], xmm5
000074703edd9e69  vmovaps [rsp+0x60], xmm6
000074703edd9e6f  vmovaps [rsp+0x70], xmm7
000074703edd9e75  vmovaps [rsp+0x80], xmm9
000074703edd9e7e  vmovaps [rsp+0x90], xmm10
000074703edd9e87  vmovaps [rsp+0xA0], xmm11
000074703edd9e90  vmovaps [rsp+0xB0], xmm12
000074703edd9e99  vmovaps [rsp+0xC0], xmm13
000074703edd9ea2  vmovaps [rsp+0xD0], xmm14
000074703edd9eab  vmovaps [rsp+0xE0], xmm15
000074703edd9eb4  sub rsp, 0x30
000074703edd9eb8  movaps [rsp], xmm8
000074703edd9ebd  movaps [rsp+0x10], xmm1
000074703edd9ec2  movaps [rsp+0x20], xmm14
000074703edd9ec8  lea rdi, [rsp]
000074703edd9ecc  mov esi, 0x00
000074703edd9ed1  mov rax, 0x5D9974CCC530
000074703edd9edb  call rax
000074703edd9edd  movaps xmm8, [rsp]
000074703edd9ee2  add rsp, 0x30
000074703edd9ee6  vmovaps xmm0, [rsp]
000074703edd9eeb  vmovaps xmm1, [rsp+0x10]
000074703edd9ef1  vmovaps xmm2, [rsp+0x20]
000074703edd9ef7  vmovaps xmm3, [rsp+0x30]
000074703edd9efd  vmovaps xmm4, [rsp+0x40]
000074703edd9f03  vmovaps xmm5, [rsp+0x50]
000074703edd9f09  vmovaps xmm6, [rsp+0x60]
000074703edd9f0f  vmovaps xmm7, [rsp+0x70]
000074703edd9f15  vmovaps xmm9, [rsp+0x80]
000074703edd9f1e  vmovaps xmm10, [rsp+0x90]
000074703edd9f27  vmovaps xmm11, [rsp+0xA0]
000074703edd9f30  vmovaps xmm12, [rsp+0xB0]
000074703edd9f39  vmovaps xmm13, [rsp+0xC0]
000074703edd9f42  vmovaps xmm14, [rsp+0xD0]
000074703edd9f4b  vmovaps xmm15, [rsp+0xE0]
000074703edd9f54  add rsp, 0xF0
000074703edd9f5b  pop r11
000074703edd9f5d  pop r10
000074703edd9f5f  pop r9
000074703edd9f61  pop r8
000074703edd9f63  pop rsi
000074703edd9f64  pop rdi
000074703edd9f65  pop rdx
000074703edd9f66  pop rcx
000074703edd9f67  pop rax
000074703edd9f68  add rsp, 0x08
000074703edd9f6c  jmp 0x000074703EDD63AE
000074703edd9f71  sub rsp, 0x08
000074703edd9f75  push rax
000074703edd9f76  push rcx
000074703edd9f77  push rdx
000074703edd9f78  push rdi
000074703edd9f79  push rsi
000074703edd9f7a  push r8
000074703edd9f7c  push r9
000074703edd9f7e  push r10
000074703edd9f80  push r11
000074703edd9f82  sub rsp, 0xF0
000074703edd9f89  vmovaps [rsp], xmm0
000074703edd9f8e  vmovaps [rsp+0x10], xmm1
000074703edd9f94  vmovaps [rsp+0x20], xmm2
000074703edd9f9a  vmovaps [rsp+0x30], xmm3
000074703edd9fa0  vmovaps [rsp+0x40], xmm4
000074703edd9fa6  vmovaps [rsp+0x50], xmm5
000074703edd9fac  vmovaps [rsp+0x60], xmm7
000074703edd9fb2  vmovaps [rsp+0x70], xmm8
000074703edd9fb8  vmovaps [rsp+0x80], xmm9
000074703edd9fc1  vmovaps [rsp+0x90], xmm10
000074703edd9fca  vmovaps [rsp+0xA0], xmm11
000074703edd9fd3  vmovaps [rsp+0xB0], xmm12
000074703edd9fdc  vmovaps [rsp+0xC0], xmm13
000074703edd9fe5  vmovaps [rsp+0xD0], xmm14
000074703edd9fee  vmovaps [rsp+0xE0], xmm15
000074703edd9ff7  sub rsp, 0x30
000074703edd9ffb  movaps [rsp], xmm6
000074703edd9fff  movaps [rsp+0x10], xmm1
000074703edda004  movaps [rsp+0x20], xmm14
000074703edda00a  lea rdi, [rsp]
000074703edda00e  mov esi, 0x00
000074703edda013  mov rax, 0x5D9974CCC530
000074703edda01d  call rax
000074703edda01f  movaps xmm6, [rsp]
000074703edda023  add rsp, 0x30
000074703edda027  vmovaps xmm0, [rsp]
000074703edda02c  vmovaps xmm1, [rsp+0x10]
000074703edda032  vmovaps xmm2, [rsp+0x20]
000074703edda038  vmovaps xmm3, [rsp+0x30]
000074703edda03e  vmovaps xmm4, [rsp+0x40]
000074703edda044  vmovaps xmm5, [rsp+0x50]
000074703edda04a  vmovaps xmm7, [rsp+0x60]
000074703edda050  vmovaps xmm8, [rsp+0x70]
000074703edda056  vmovaps xmm9, [rsp+0x80]
000074703edda05f  vmovaps xmm10, [rsp+0x90]
000074703edda068  vmovaps xmm11, [rsp+0xA0]
000074703edda071  vmovaps xmm12, [rsp+0xB0]
000074703edda07a  vmovaps xmm13, [rsp+0xC0]
000074703edda083  vmovaps xmm14, [rsp+0xD0]
000074703edda08c  vmovaps xmm15, [rsp+0xE0]
000074703edda095  add rsp, 0xF0
000074703edda09c  pop r11
000074703edda09e  pop r10
000074703edda0a0  pop r9
000074703edda0a2  pop r8
000074703edda0a4  pop rsi
000074703edda0a5  pop rdi
000074703edda0a6  pop rdx
000074703edda0a7  pop rcx
000074703edda0a8  pop rax
000074703edda0a9  add rsp, 0x08
000074703edda0ad  jmp 0x000074703EDD63DA
000074703edda0b2  sub rsp, 0x08
000074703edda0b6  push rax
000074703edda0b7  push rcx
000074703edda0b8  push rdx
000074703edda0b9  push rdi
000074703edda0ba  push rsi
000074703edda0bb  push r8
000074703edda0bd  push r9
000074703edda0bf  push r10
000074703edda0c1  push r11
000074703edda0c3  sub rsp, 0xF0
000074703edda0ca  vmovaps [rsp], xmm0
000074703edda0cf  vmovaps [rsp+0x10], xmm1
000074703edda0d5  vmovaps [rsp+0x20], xmm2
000074703edda0db  vmovaps [rsp+0x30], xmm3
000074703edda0e1  vmovaps [rsp+0x40], xmm4
000074703edda0e7  vmovaps [rsp+0x50], xmm5
000074703edda0ed  vmovaps [rsp+0x60], xmm6
000074703edda0f3  vmovaps [rsp+0x70], xmm7
000074703edda0f9  vmovaps [rsp+0x80], xmm8
000074703edda102  vmovaps [rsp+0x90], xmm9
000074703edda10b  vmovaps [rsp+0xA0], xmm10
000074703edda114  vmovaps [rsp+0xB0], xmm11
000074703edda11d  vmovaps [rsp+0xC0], xmm12
000074703edda126  vmovaps [rsp+0xD0], xmm13
000074703edda12f  vmovaps [rsp+0xE0], xmm15
000074703edda138  sub rsp, 0x30
000074703edda13c  movaps [rsp], xmm14
000074703edda141  movaps [rsp+0x10], xmm12
000074703edda147  movaps [rsp+0x20], xmm1
000074703edda14c  lea rdi, [rsp]
000074703edda150  mov esi, 0x00
000074703edda155  mov rax, 0x5D9974CCC530
000074703edda15f  call rax
000074703edda161  movaps xmm14, [rsp]
000074703edda166  add rsp, 0x30
000074703edda16a  vmovaps xmm0, [rsp]
000074703edda16f  vmovaps xmm1, [rsp+0x10]
000074703edda175  vmovaps xmm2, [rsp+0x20]
000074703edda17b  vmovaps xmm3, [rsp+0x30]
000074703edda181  vmovaps xmm4, [rsp+0x40]
000074703edda187  vmovaps xmm5, [rsp+0x50]
000074703edda18d  vmovaps xmm6, [rsp+0x60]
000074703edda193  vmovaps xmm7, [rsp+0x70]
000074703edda199  vmovaps xmm8, [rsp+0x80]
000074703edda1a2  vmovaps xmm9, [rsp+0x90]
000074703edda1ab  vmovaps xmm10, [rsp+0xA0]
000074703edda1b4  vmovaps xmm11, [rsp+0xB0]
000074703edda1bd  vmovaps xmm12, [rsp+0xC0]
000074703edda1c6  vmovaps xmm13, [rsp+0xD0]
000074703edda1cf  vmovaps xmm15, [rsp+0xE0]
000074703edda1d8  add rsp, 0xF0
000074703edda1df  pop r11
000074703edda1e1  pop r10
000074703edda1e3  pop r9
000074703edda1e5  pop r8
000074703edda1e7  pop rsi
000074703edda1e8  pop rdi
000074703edda1e9  pop rdx
000074703edda1ea  pop rcx
000074703edda1eb  pop rax
000074703edda1ec  add rsp, 0x08
000074703edda1f0  jmp 0x000074703EDD6400
000074703edda1f5  sub rsp, 0x08
000074703edda1f9  push rax
000074703edda1fa  push rcx
000074703edda1fb  push rdx
000074703edda1fc  push rdi
000074703edda1fd  push rsi
000074703edda1fe  push r8
000074703edda200  push r9
000074703edda202  push r10
000074703edda204  push r11
000074703edda206  sub rsp, 0xF0
000074703edda20d  vmovaps [rsp], xmm0
000074703edda212  vmovaps [rsp+0x10], xmm2
000074703edda218  vmovaps [rsp+0x20], xmm3
000074703edda21e  vmovaps [rsp+0x30], xmm4
000074703edda224  vmovaps [rsp+0x40], xmm5
000074703edda22a  vmovaps [rsp+0x50], xmm6
000074703edda230  vmovaps [rsp+0x60], xmm7
000074703edda236  vmovaps [rsp+0x70], xmm8
000074703edda23c  vmovaps [rsp+0x80], xmm9
000074703edda245  vmovaps [rsp+0x90], xmm10
000074703edda24e  vmovaps [rsp+0xA0], xmm11
000074703edda257  vmovaps [rsp+0xB0], xmm12
000074703edda260  vmovaps [rsp+0xC0], xmm13
000074703edda269  vmovaps [rsp+0xD0], xmm14
000074703edda272  vmovaps [rsp+0xE0], xmm15
000074703edda27b  sub rsp, 0x30
000074703edda27f  movaps [rsp], xmm1
000074703edda283  movaps [rsp+0x10], xmm13
000074703edda289  movaps [rsp+0x20], xmm9
000074703edda28f  lea rdi, [rsp]
000074703edda293  mov esi, 0x00
000074703edda298  mov rax, 0x5D9974CCC530
000074703edda2a2  call rax
000074703edda2a4  movaps xmm1, [rsp]
000074703edda2a8  add rsp, 0x30
000074703edda2ac  vmovaps xmm0, [rsp]
000074703edda2b1  vmovaps xmm2, [rsp+0x10]
000074703edda2b7  vmovaps xmm3, [rsp+0x20]
000074703edda2bd  vmovaps xmm4, [rsp+0x30]
000074703edda2c3  vmovaps xmm5, [rsp+0x40]
000074703edda2c9  vmovaps xmm6, [rsp+0x50]
000074703edda2cf  vmovaps xmm7, [rsp+0x60]
000074703edda2d5  vmovaps xmm8, [rsp+0x70]
000074703edda2db  vmovaps xmm9, [rsp+0x80]
000074703edda2e4  vmovaps xmm10, [rsp+0x90]
000074703edda2ed  vmovaps xmm11, [rsp+0xA0]
000074703edda2f6  vmovaps xmm12, [rsp+0xB0]
000074703edda2ff  vmovaps xmm13, [rsp+0xC0]
000074703edda308  vmovaps xmm14, [rsp+0xD0]
000074703edda311  vmovaps xmm15, [rsp+0xE0]
000074703edda31a  add rsp, 0xF0
000074703edda321  pop r11
000074703edda323  pop r10
000074703edda325  pop r9
000074703edda327  pop r8
000074703edda329  pop rsi
000074703edda32a  pop rdi
000074703edda32b  pop rdx
000074703edda32c  pop rcx
000074703edda32d  pop rax
000074703edda32e  add rsp, 0x08
000074703edda332  jmp 0x000074703EDD641A
000074703edda337  sub rsp, 0x08
000074703edda33b  push rax
000074703edda33c  push rcx
000074703edda33d  push rdx
000074703edda33e  push rdi
000074703edda33f  push rsi
000074703edda340  push r8
000074703edda342  push r9
000074703edda344  push r10
000074703edda346  push r11
000074703edda348  sub rsp, 0xF0
000074703edda34f  vmovaps [rsp], xmm0
000074703edda354  vmovaps [rsp+0x10], xmm1
000074703edda35a  vmovaps [rsp+0x20], xmm2
000074703edda360  vmovaps [rsp+0x30], xmm3
000074703edda366  vmovaps [rsp+0x40], xmm4
000074703edda36c  vmovaps [rsp+0x50], xmm5
000074703edda372  vmovaps [rsp+0x60], xmm6
000074703edda378  vmovaps [rsp+0x70], xmm7
000074703edda37e  vmovaps [rsp+0x80], xmm8
000074703edda387  vmovaps [rsp+0x90], xmm9
000074703edda390  vmovaps [rsp+0xA0], xmm10
000074703edda399  vmovaps [rsp+0xB0], xmm11
000074703edda3a2  vmovaps [rsp+0xC0], xmm13
000074703edda3ab  vmovaps [rsp+0xD0], xmm14
000074703edda3b4  vmovaps [rsp+0xE0], xmm15
000074703edda3bd  sub rsp, 0x30
000074703edda3c1  movaps [rsp], xmm12
000074703edda3c6  movaps [rsp+0x10], xmm7
000074703edda3cb  movaps [rsp+0x20], xmm13
000074703edda3d1  lea rdi, [rsp]
000074703edda3d5  mov esi, 0x00
000074703edda3da  mov rax, 0x5D9974CCC530
000074703edda3e4  call rax
000074703edda3e6  movaps xmm12, [rsp]
000074703edda3eb  add rsp, 0x30
000074703edda3ef  vmovaps xmm0, [rsp]
000074703edda3f4  vmovaps xmm1, [rsp+0x10]
000074703edda3fa  vmovaps xmm2, [rsp+0x20]
000074703edda400  vmovaps xmm3, [rsp+0x30]
000074703edda406  vmovaps xmm4, [rsp+0x40]
000074703edda40c  vmovaps xmm5, [rsp+0x50]
000074703edda412  vmovaps xmm6, [rsp+0x60]
000074703edda418  vmovaps xmm7, [rsp+0x70]
000074703edda41e  vmovaps xmm8, [rsp+0x80]
000074703edda427  vmovaps xmm9, [rsp+0x90]
000074703edda430  vmovaps xmm10, [rsp+0xA0]
000074703edda439  vmovaps xmm11, [rsp+0xB0]
000074703edda442  vmovaps xmm13, [rsp+0xC0]
000074703edda44b  vmovaps xmm14, [rsp+0xD0]
000074703edda454  vmovaps xmm15, [rsp+0xE0]
000074703edda45d  add rsp, 0xF0
000074703edda464  pop r11
000074703edda466  pop r10
000074703edda468  pop r9
000074703edda46a  pop r8
000074703edda46c  pop rsi
000074703edda46d  pop rdi
000074703edda46e  pop rdx
000074703edda46f  pop rcx
000074703edda470  pop rax
000074703edda471  add rsp, 0x08
000074703edda475  jmp 0x000074703EDD6441
000074703edda47a  sub rsp, 0x08
000074703edda47e  push rax
000074703edda47f  push rcx
000074703edda480  push rdx
000074703edda481  push rdi
000074703edda482  push rsi
000074703edda483  push r8
000074703edda485  push r9
000074703edda487  push r10
000074703edda489  push r11
000074703edda48b  sub rsp, 0xF0
000074703edda492  vmovaps [rsp], xmm0
000074703edda497  vmovaps [rsp+0x10], xmm1
000074703edda49d  vmovaps [rsp+0x20], xmm2
000074703edda4a3  vmovaps [rsp+0x30], xmm3
000074703edda4a9  vmovaps [rsp+0x40], xmm4
000074703edda4af  vmovaps [rsp+0x50], xmm5
000074703edda4b5  vmovaps [rsp+0x60], xmm6
000074703edda4bb  vmovaps [rsp+0x70], xmm7
000074703edda4c1  vmovaps [rsp+0x80], xmm8
000074703edda4ca  vmovaps [rsp+0x90], xmm9
000074703edda4d3  vmovaps [rsp+0xA0], xmm10
000074703edda4dc  vmovaps [rsp+0xB0], xmm11
000074703edda4e5  vmovaps [rsp+0xC0], xmm12
000074703edda4ee  vmovaps [rsp+0xD0], xmm14
000074703edda4f7  vmovaps [rsp+0xE0], xmm15
000074703edda500  sub rsp, 0x30
000074703edda504  movaps [rsp], xmm13
000074703edda509  movaps [rsp+0x10], xmm15
000074703edda50f  movaps [rsp+0x20], xmm8
000074703edda515  lea rdi, [rsp]
000074703edda519  mov esi, 0x00
000074703edda51e  mov rax, 0x5D9974CCC530
000074703edda528  call rax
000074703edda52a  movaps xmm13, [rsp]
000074703edda52f  add rsp, 0x30
000074703edda533  vmovaps xmm0, [rsp]
000074703edda538  vmovaps xmm1, [rsp+0x10]
000074703edda53e  vmovaps xmm2, [rsp+0x20]
000074703edda544  vmovaps xmm3, [rsp+0x30]
000074703edda54a  vmovaps xmm4, [rsp+0x40]
000074703edda550  vmovaps xmm5, [rsp+0x50]
000074703edda556  vmovaps xmm6, [rsp+0x60]
000074703edda55c  vmovaps xmm7, [rsp+0x70]
000074703edda562  vmovaps xmm8, [rsp+0x80]
000074703edda56b  vmovaps xmm9, [rsp+0x90]
000074703edda574  vmovaps xmm10, [rsp+0xA0]
000074703edda57d  vmovaps xmm11, [rsp+0xB0]
000074703edda586  vmovaps xmm12, [rsp+0xC0]
000074703edda58f  vmovaps xmm14, [rsp+0xD0]
000074703edda598  vmovaps xmm15, [rsp+0xE0]
000074703edda5a1  add rsp, 0xF0
000074703edda5a8  pop r11
000074703edda5aa  pop r10
000074703edda5ac  pop r9
000074703edda5ae  pop r8
000074703edda5b0  pop rsi
000074703edda5b1  pop rdi
000074703edda5b2  pop rdx
000074703edda5b3  pop rcx
000074703edda5b4  pop rax
000074703edda5b5  add rsp, 0x08
000074703edda5b9  jmp 0x000074703EDD645C
000074703edda5be  sub rsp, 0x08
000074703edda5c2  push rax
000074703edda5c3  push rcx
000074703edda5c4  push rdx
000074703edda5c5  push rdi
000074703edda5c6  push rsi
000074703edda5c7  push r8
000074703edda5c9  push r9
000074703edda5cb  push r10
000074703edda5cd  push r11
000074703edda5cf  sub rsp, 0xF0
000074703edda5d6  vmovaps [rsp], xmm0
000074703edda5db  vmovaps [rsp+0x10], xmm1
000074703edda5e1  vmovaps [rsp+0x20], xmm2
000074703edda5e7  vmovaps [rsp+0x30], xmm3
000074703edda5ed  vmovaps [rsp+0x40], xmm4
000074703edda5f3  vmovaps [rsp+0x50], xmm5
000074703edda5f9  vmovaps [rsp+0x60], xmm6
000074703edda5ff  vmovaps [rsp+0x70], xmm7
000074703edda605  vmovaps [rsp+0x80], xmm9
000074703edda60e  vmovaps [rsp+0x90], xmm10
000074703edda617  vmovaps [rsp+0xA0], xmm11
000074703edda620  vmovaps [rsp+0xB0], xmm12
000074703edda629  vmovaps [rsp+0xC0], xmm13
000074703edda632  vmovaps [rsp+0xD0], xmm14
000074703edda63b  vmovaps [rsp+0xE0], xmm15
000074703edda644  sub rsp, 0x30
000074703edda648  movaps [rsp], xmm8
000074703edda64d  movaps [rsp+0x10], xmm15
000074703edda653  movaps [rsp+0x20], xmm9
000074703edda659  lea rdi, [rsp]
000074703edda65d  mov esi, 0x00
000074703edda662  mov rax, 0x5D9974CCC530
000074703edda66c  call rax
000074703edda66e  movaps xmm8, [rsp]
000074703edda673  add rsp, 0x30
000074703edda677  vmovaps xmm0, [rsp]
000074703edda67c  vmovaps xmm1, [rsp+0x10]
000074703edda682  vmovaps xmm2, [rsp+0x20]
000074703edda688  vmovaps xmm3, [rsp+0x30]
000074703edda68e  vmovaps xmm4, [rsp+0x40]
000074703edda694  vmovaps xmm5, [rsp+0x50]
000074703edda69a  vmovaps xmm6, [rsp+0x60]
000074703edda6a0  vmovaps xmm7, [rsp+0x70]
000074703edda6a6  vmovaps xmm9, [rsp+0x80]
000074703edda6af  vmovaps xmm10, [rsp+0x90]
000074703edda6b8  vmovaps xmm11, [rsp+0xA0]
000074703edda6c1  vmovaps xmm12, [rsp+0xB0]
000074703edda6ca  vmovaps xmm13, [rsp+0xC0]
000074703edda6d3  vmovaps xmm14, [rsp+0xD0]
000074703edda6dc  vmovaps xmm15, [rsp+0xE0]
000074703edda6e5  add rsp, 0xF0
000074703edda6ec  pop r11
000074703edda6ee  pop r10
000074703edda6f0  pop r9
000074703edda6f2  pop r8
000074703edda6f4  pop rsi
000074703edda6f5  pop rdi
000074703edda6f6  pop rdx
000074703edda6f7  pop rcx
000074703edda6f8  pop rax
000074703edda6f9  add rsp, 0x08
000074703edda6fd  jmp 0x000074703EDD648A
000074703edda702  sub rsp, 0x08
000074703edda706  push rax
000074703edda707  push rcx
000074703edda708  push rdx
000074703edda709  push rdi
000074703edda70a  push rsi
000074703edda70b  push r8
000074703edda70d  push r9
000074703edda70f  push r10
000074703edda711  push r11
000074703edda713  sub rsp, 0xF0
000074703edda71a  vmovaps [rsp], xmm0
000074703edda71f  vmovaps [rsp+0x10], xmm1
000074703edda725  vmovaps [rsp+0x20], xmm2
000074703edda72b  vmovaps [rsp+0x30], xmm3
000074703edda731  vmovaps [rsp+0x40], xmm4
000074703edda737  vmovaps [rsp+0x50], xmm5
000074703edda73d  vmovaps [rsp+0x60], xmm6
000074703edda743  vmovaps [rsp+0x70], xmm7
000074703edda749  vmovaps [rsp+0x80], xmm8
000074703edda752  vmovaps [rsp+0x90], xmm9
000074703edda75b  vmovaps [rsp+0xA0], xmm10
000074703edda764  vmovaps [rsp+0xB0], xmm11
000074703edda76d  vmovaps [rsp+0xC0], xmm12
000074703edda776  vmovaps [rsp+0xD0], xmm13
000074703edda77f  vmovaps [rsp+0xE0], xmm14
000074703edda788  sub rsp, 0x30
000074703edda78c  movaps [rsp], xmm15
000074703edda791  movaps [rsp+0x10], xmm11
000074703edda797  movaps [rsp+0x20], xmm6
000074703edda79c  lea rdi, [rsp]
000074703edda7a0  mov esi, 0x00
000074703edda7a5  mov rax, 0x5D9974CCC530
000074703edda7af  call rax
000074703edda7b1  movaps xmm15, [rsp]
000074703edda7b6  add rsp, 0x30
000074703edda7ba  vmovaps xmm0, [rsp]
000074703edda7bf  vmovaps xmm1, [rsp+0x10]
000074703edda7c5  vmovaps xmm2, [rsp+0x20]
000074703edda7cb  vmovaps xmm3, [rsp+0x30]
000074703edda7d1  vmovaps xmm4, [rsp+0x40]
000074703edda7d7  vmovaps xmm5, [rsp+0x50]
000074703edda7dd  vmovaps xmm6, [rsp+0x60]
000074703edda7e3  vmovaps xmm7, [rsp+0x70]
000074703edda7e9  vmovaps xmm8, [rsp+0x80]
000074703edda7f2  vmovaps xmm9, [rsp+0x90]
000074703edda7fb  vmovaps xmm10, [rsp+0xA0]
000074703edda804  vmovaps xmm11, [rsp+0xB0]
000074703edda80d  vmovaps xmm12, [rsp+0xC0]
000074703edda816  vmovaps xmm13, [rsp+0xD0]
000074703edda81f  vmovaps xmm14, [rsp+0xE0]
000074703edda828  add rsp, 0xF0
000074703edda82f  pop r11
000074703edda831  pop r10
000074703edda833  pop r9
000074703edda835  pop r8
000074703edda837  pop rsi
000074703edda838  pop rdi
000074703edda839  pop rdx
000074703edda83a  pop rcx
000074703edda83b  pop rax
000074703edda83c  add rsp, 0x08
000074703edda840  jmp 0x000074703EDD64A5
000074703edda845  sub rsp, 0x08
000074703edda849  push rax
000074703edda84a  push rcx
000074703edda84b  push rdx
000074703edda84c  push rdi
000074703edda84d  push rsi
000074703edda84e  push r8
000074703edda850  push r9
000074703edda852  push r10
000074703edda854  push r11
000074703edda856  sub rsp, 0xF0
000074703edda85d  vmovaps [rsp], xmm0
000074703edda862  vmovaps [rsp+0x10], xmm1
000074703edda868  vmovaps [rsp+0x20], xmm2
000074703edda86e  vmovaps [rsp+0x30], xmm3
000074703edda874  vmovaps [rsp+0x40], xmm4
000074703edda87a  vmovaps [rsp+0x50], xmm5
000074703edda880  vmovaps [rsp+0x60], xmm6
000074703edda886  vmovaps [rsp+0x70], xmm8
000074703edda88c  vmovaps [rsp+0x80], xmm9
000074703edda895  vmovaps [rsp+0x90], xmm10
000074703edda89e  vmovaps [rsp+0xA0], xmm11
000074703edda8a7  vmovaps [rsp+0xB0], xmm12
000074703edda8b0  vmovaps [rsp+0xC0], xmm13
000074703edda8b9  vmovaps [rsp+0xD0], xmm14
000074703edda8c2  vmovaps [rsp+0xE0], xmm15
000074703edda8cb  sub rsp, 0x30
000074703edda8cf  movaps [rsp], xmm7
000074703edda8d3  movaps [rsp+0x10], xmm11
000074703edda8d9  movaps [rsp+0x20], xmm9
000074703edda8df  lea rdi, [rsp]
000074703edda8e3  mov esi, 0x00
000074703edda8e8  mov rax, 0x5D9974CCC530
000074703edda8f2  call rax
000074703edda8f4  movaps xmm7, [rsp]
000074703edda8f8  add rsp, 0x30
000074703edda8fc  vmovaps xmm0, [rsp]
000074703edda901  vmovaps xmm1, [rsp+0x10]
000074703edda907  vmovaps xmm2, [rsp+0x20]
000074703edda90d  vmovaps xmm3, [rsp+0x30]
000074703edda913  vmovaps xmm4, [rsp+0x40]
000074703edda919  vmovaps xmm5, [rsp+0x50]
000074703edda91f  vmovaps xmm6, [rsp+0x60]
000074703edda925  vmovaps xmm8, [rsp+0x70]
000074703edda92b  vmovaps xmm9, [rsp+0x80]
000074703edda934  vmovaps xmm10, [rsp+0x90]
000074703edda93d  vmovaps xmm11, [rsp+0xA0]
000074703edda946  vmovaps xmm12, [rsp+0xB0]
000074703edda94f  vmovaps xmm13, [rsp+0xC0]
000074703edda958  vmovaps xmm14, [rsp+0xD0]
000074703edda961  vmovaps xmm15, [rsp+0xE0]
000074703edda96a  add rsp, 0xF0
000074703edda971  pop r11
000074703edda973  pop r10
000074703edda975  pop r9
000074703edda977  pop r8
000074703edda979  pop rsi
000074703edda97a  pop rdi
000074703edda97b  pop rdx
000074703edda97c  pop rcx
000074703edda97d  pop rax
000074703edda97e  add rsp, 0x08
000074703edda982  jmp 0x000074703EDD64D2
000074703edda987  sub rsp, 0x08
000074703edda98b  push rax
000074703edda98c  push rcx
000074703edda98d  push rdx
000074703edda98e  push rdi
000074703edda98f  push rsi
000074703edda990  push r8
000074703edda992  push r9
000074703edda994  push r10
000074703edda996  push r11
000074703edda998  sub rsp, 0xF0
000074703edda99f  vmovaps [rsp], xmm0
000074703edda9a4  vmovaps [rsp+0x10], xmm1
000074703edda9aa  vmovaps [rsp+0x20], xmm2
000074703edda9b0  vmovaps [rsp+0x30], xmm3
000074703edda9b6  vmovaps [rsp+0x40], xmm4
000074703edda9bc  vmovaps [rsp+0x50], xmm5
000074703edda9c2  vmovaps [rsp+0x60], xmm6
000074703edda9c8  vmovaps [rsp+0x70], xmm7
000074703edda9ce  vmovaps [rsp+0x80], xmm8
000074703edda9d7  vmovaps [rsp+0x90], xmm9
000074703edda9e0  vmovaps [rsp+0xA0], xmm10
000074703edda9e9  vmovaps [rsp+0xB0], xmm12
000074703edda9f2  vmovaps [rsp+0xC0], xmm13
000074703edda9fb  vmovaps [rsp+0xD0], xmm14
000074703eddaa04  vmovaps [rsp+0xE0], xmm15
000074703eddaa0d  sub rsp, 0x30
000074703eddaa11  movaps [rsp], xmm11
000074703eddaa16  movaps [rsp+0x10], xmm10
000074703eddaa1c  movaps [rsp+0x20], xmm14
000074703eddaa22  lea rdi, [rsp]
000074703eddaa26  mov esi, 0x00
000074703eddaa2b  mov rax, 0x5D9974CCC530
000074703eddaa35  call rax
000074703eddaa37  movaps xmm11, [rsp]
000074703eddaa3c  add rsp, 0x30
000074703eddaa40  vmovaps xmm0, [rsp]
000074703eddaa45  vmovaps xmm1, [rsp+0x10]
000074703eddaa4b  vmovaps xmm2, [rsp+0x20]
000074703eddaa51  vmovaps xmm3, [rsp+0x30]
000074703eddaa57  vmovaps xmm4, [rsp+0x40]
000074703eddaa5d  vmovaps xmm5, [rsp+0x50]
000074703eddaa63  vmovaps xmm6, [rsp+0x60]
000074703eddaa69  vmovaps xmm7, [rsp+0x70]
000074703eddaa6f  vmovaps xmm8, [rsp+0x80]
000074703eddaa78  vmovaps xmm9, [rsp+0x90]
000074703eddaa81  vmovaps xmm10, [rsp+0xA0]
000074703eddaa8a  vmovaps xmm12, [rsp+0xB0]
000074703eddaa93  vmovaps xmm13, [rsp+0xC0]
000074703eddaa9c  vmovaps xmm14, [rsp+0xD0]
000074703eddaaa5  vmovaps xmm15, [rsp+0xE0]
000074703eddaaae  add rsp, 0xF0
000074703eddaab5  pop r11
000074703eddaab7  pop r10
000074703eddaab9  pop r9
000074703eddaabb  pop r8
000074703eddaabd  pop rsi
000074703eddaabe  pop rdi
000074703eddaabf  pop rdx
000074703eddaac0  pop rcx
000074703eddaac1  pop rax
000074703eddaac2  add rsp, 0x08
000074703eddaac6  jmp 0x000074703EDD64ED
000074703eddaacb  call 0x000074703ECE45A0
000074703eddaad0  jmp 0x000074703EDD64F7
000074703eddaad5  sub rsp, 0x08
000074703eddaad9  push rax
000074703eddaada  push rcx
000074703eddaadb  push rdx
000074703eddaadc  push rdi
000074703eddaadd  push rsi
000074703eddaade  push r8
000074703eddaae0  push r9
000074703eddaae2  push r10
000074703eddaae4  push r11
000074703eddaae6  sub rsp, 0xF0
000074703eddaaed  vmovaps [rsp], xmm0
000074703eddaaf2  vmovaps [rsp+0x10], xmm1
000074703eddaaf8  vmovaps [rsp+0x20], xmm2
000074703eddaafe  vmovaps [rsp+0x30], xmm3
000074703eddab04  vmovaps [rsp+0x40], xmm4
000074703eddab0a  vmovaps [rsp+0x50], xmm5
000074703eddab10  vmovaps [rsp+0x60], xmm6
000074703eddab16  vmovaps [rsp+0x70], xmm7
000074703eddab1c  vmovaps [rsp+0x80], xmm8
000074703eddab25  vmovaps [rsp+0x90], xmm9
000074703eddab2e  vmovaps [rsp+0xA0], xmm11
000074703eddab37  vmovaps [rsp+0xB0], xmm12
000074703eddab40  vmovaps [rsp+0xC0], xmm13
000074703eddab49  vmovaps [rsp+0xD0], xmm14
000074703eddab52  vmovaps [rsp+0xE0], xmm15
000074703eddab5b  sub rsp, 0x30
000074703eddab5f  movaps [rsp], xmm10
000074703eddab64  movaps [rsp+0x10], xmm1
000074703eddab69  movaps [rsp+0x20], xmm12
000074703eddab6f  lea rdi, [rsp]
000074703eddab73  mov esi, 0x00
000074703eddab78  mov rax, 0x5D9974CCC530
000074703eddab82  call rax
000074703eddab84  movaps xmm10, [rsp]
000074703eddab89  add rsp, 0x30
000074703eddab8d  vmovaps xmm0, [rsp]
000074703eddab92  vmovaps xmm1, [rsp+0x10]
000074703eddab98  vmovaps xmm2, [rsp+0x20]
000074703eddab9e  vmovaps xmm3, [rsp+0x30]
000074703eddaba4  vmovaps xmm4, [rsp+0x40]
000074703eddabaa  vmovaps xmm5, [rsp+0x50]
000074703eddabb0  vmovaps xmm6, [rsp+0x60]
000074703eddabb6  vmovaps xmm7, [rsp+0x70]
000074703eddabbc  vmovaps xmm8, [rsp+0x80]
000074703eddabc5  vmovaps xmm9, [rsp+0x90]
000074703eddabce  vmovaps xmm11, [rsp+0xA0]
000074703eddabd7  vmovaps xmm12, [rsp+0xB0]
000074703eddabe0  vmovaps xmm13, [rsp+0xC0]
000074703eddabe9  vmovaps xmm14, [rsp+0xD0]
000074703eddabf2  vmovaps xmm15, [rsp+0xE0]
000074703eddabfb  add rsp, 0xF0
000074703eddac02  pop r11
000074703eddac04  pop r10
000074703eddac06  pop r9
000074703eddac08  pop r8
000074703eddac0a  pop rsi
000074703eddac0b  pop rdi
000074703eddac0c  pop rdx
000074703eddac0d  pop rcx
000074703eddac0e  pop rax
000074703eddac0f  add rsp, 0x08
000074703eddac13  jmp 0x000074703EDD651A
000074703eddac18  sub rsp, 0x08
000074703eddac1c  push rax
000074703eddac1d  push rcx
000074703eddac1e  push rdx
000074703eddac1f  push rdi
000074703eddac20  push rsi
000074703eddac21  push r8
000074703eddac23  push r9
000074703eddac25  push r10
000074703eddac27  push r11
000074703eddac29  sub rsp, 0xF0
000074703eddac30  vmovaps [rsp], xmm0
000074703eddac35  vmovaps [rsp+0x10], xmm1
000074703eddac3b  vmovaps [rsp+0x20], xmm2
000074703eddac41  vmovaps [rsp+0x30], xmm3
000074703eddac47  vmovaps [rsp+0x40], xmm4
000074703eddac4d  vmovaps [rsp+0x50], xmm5
000074703eddac53  vmovaps [rsp+0x60], xmm6
000074703eddac59  vmovaps [rsp+0x70], xmm7
000074703eddac5f  vmovaps [rsp+0x80], xmm8
000074703eddac68  vmovaps [rsp+0x90], xmm9
000074703eddac71  vmovaps [rsp+0xA0], xmm10
000074703eddac7a  vmovaps [rsp+0xB0], xmm11
000074703eddac83  vmovaps [rsp+0xC0], xmm13
000074703eddac8c  vmovaps [rsp+0xD0], xmm14
000074703eddac95  vmovaps [rsp+0xE0], xmm15
000074703eddac9e  sub rsp, 0x30
000074703eddaca2  movaps [rsp], xmm12
000074703eddaca7  movaps [rsp+0x10], xmm14
000074703eddacad  movaps [rsp+0x20], xmm1
000074703eddacb2  lea rdi, [rsp]
000074703eddacb6  mov esi, 0x00
000074703eddacbb  mov rax, 0x5D9974CCC530
000074703eddacc5  call rax
000074703eddacc7  movaps xmm12, [rsp]
000074703eddaccc  add rsp, 0x30
000074703eddacd0  vmovaps xmm0, [rsp]
000074703eddacd5  vmovaps xmm1, [rsp+0x10]
000074703eddacdb  vmovaps xmm2, [rsp+0x20]
000074703eddace1  vmovaps xmm3, [rsp+0x30]
000074703eddace7  vmovaps xmm4, [rsp+0x40]
000074703eddaced  vmovaps xmm5, [rsp+0x50]
000074703eddacf3  vmovaps xmm6, [rsp+0x60]
000074703eddacf9  vmovaps xmm7, [rsp+0x70]
000074703eddacff  vmovaps xmm8, [rsp+0x80]
000074703eddad08  vmovaps xmm9, [rsp+0x90]
000074703eddad11  vmovaps xmm10, [rsp+0xA0]
000074703eddad1a  vmovaps xmm11, [rsp+0xB0]
000074703eddad23  vmovaps xmm13, [rsp+0xC0]
000074703eddad2c  vmovaps xmm14, [rsp+0xD0]
000074703eddad35  vmovaps xmm15, [rsp+0xE0]
000074703eddad3e  add rsp, 0xF0
000074703eddad45  pop r11
000074703eddad47  pop r10
000074703eddad49  pop r9
000074703eddad4b  pop r8
000074703eddad4d  pop rsi
000074703eddad4e  pop rdi
000074703eddad4f  pop rdx
000074703eddad50  pop rcx
000074703eddad51  pop rax
000074703eddad52  add rsp, 0x08
000074703eddad56  jmp 0x000074703EDD6549
000074703eddad5b  sub rsp, 0x08
000074703eddad5f  push rax
000074703eddad60  push rcx
000074703eddad61  push rdx
000074703eddad62  push rdi
000074703eddad63  push rsi
000074703eddad64  push r8
000074703eddad66  push r9
000074703eddad68  push r10
000074703eddad6a  push r11
000074703eddad6c  sub rsp, 0xF0
000074703eddad73  vmovaps [rsp], xmm0
000074703eddad78  vmovaps [rsp+0x10], xmm1
000074703eddad7e  vmovaps [rsp+0x20], xmm2
000074703eddad84  vmovaps [rsp+0x30], xmm3
000074703eddad8a  vmovaps [rsp+0x40], xmm4
000074703eddad90  vmovaps [rsp+0x50], xmm5
000074703eddad96  vmovaps [rsp+0x60], xmm6
000074703eddad9c  vmovaps [rsp+0x70], xmm7
000074703eddada2  vmovaps [rsp+0x80], xmm8
000074703eddadab  vmovaps [rsp+0x90], xmm9
000074703eddadb4  vmovaps [rsp+0xA0], xmm10
000074703eddadbd  vmovaps [rsp+0xB0], xmm11
000074703eddadc6  vmovaps [rsp+0xC0], xmm12
000074703eddadcf  vmovaps [rsp+0xD0], xmm13
000074703eddadd8  vmovaps [rsp+0xE0], xmm15
000074703eddade1  sub rsp, 0x30
000074703eddade5  movaps [rsp], xmm14
000074703eddadea  movaps [rsp+0x10], xmm9
000074703eddadf0  movaps [rsp+0x20], xmm1
000074703eddadf5  lea rdi, [rsp]
000074703eddadf9  mov esi, 0x00
000074703eddadfe  mov rax, 0x5D9974CCC530
000074703eddae08  call rax
000074703eddae0a  movaps xmm14, [rsp]
000074703eddae0f  add rsp, 0x30
000074703eddae13  vmovaps xmm0, [rsp]
000074703eddae18  vmovaps xmm1, [rsp+0x10]
000074703eddae1e  vmovaps xmm2, [rsp+0x20]
000074703eddae24  vmovaps xmm3, [rsp+0x30]
000074703eddae2a  vmovaps xmm4, [rsp+0x40]
000074703eddae30  vmovaps xmm5, [rsp+0x50]
000074703eddae36  vmovaps xmm6, [rsp+0x60]
000074703eddae3c  vmovaps xmm7, [rsp+0x70]
000074703eddae42  vmovaps xmm8, [rsp+0x80]
000074703eddae4b  vmovaps xmm9, [rsp+0x90]
000074703eddae54  vmovaps xmm10, [rsp+0xA0]
000074703eddae5d  vmovaps xmm11, [rsp+0xB0]
000074703eddae66  vmovaps xmm12, [rsp+0xC0]
000074703eddae6f  vmovaps xmm13, [rsp+0xD0]
000074703eddae78  vmovaps xmm15, [rsp+0xE0]
000074703eddae81  add rsp, 0xF0
000074703eddae88  pop r11
000074703eddae8a  pop r10
000074703eddae8c  pop r9
000074703eddae8e  pop r8
000074703eddae90  pop rsi
000074703eddae91  pop rdi
000074703eddae92  pop rdx
000074703eddae93  pop rcx
000074703eddae94  pop rax
000074703eddae95  add rsp, 0x08
000074703eddae99  jmp 0x000074703EDD6578
000074703eddae9e  sub rsp, 0x08
000074703eddaea2  push rax
000074703eddaea3  push rcx
000074703eddaea4  push rdx
000074703eddaea5  push rdi
000074703eddaea6  push rsi
000074703eddaea7  push r8
000074703eddaea9  push r9
000074703eddaeab  push r10
000074703eddaead  push r11
000074703eddaeaf  sub rsp, 0xF0
000074703eddaeb6  vmovaps [rsp], xmm0
000074703eddaebb  vmovaps [rsp+0x10], xmm2
000074703eddaec1  vmovaps [rsp+0x20], xmm3
000074703eddaec7  vmovaps [rsp+0x30], xmm4
000074703eddaecd  vmovaps [rsp+0x40], xmm5
000074703eddaed3  vmovaps [rsp+0x50], xmm6
000074703eddaed9  vmovaps [rsp+0x60], xmm7
000074703eddaedf  vmovaps [rsp+0x70], xmm8
000074703eddaee5  vmovaps [rsp+0x80], xmm9
000074703eddaeee  vmovaps [rsp+0x90], xmm10
000074703eddaef7  vmovaps [rsp+0xA0], xmm11
000074703eddaf00  vmovaps [rsp+0xB0], xmm12
000074703eddaf09  vmovaps [rsp+0xC0], xmm13
000074703eddaf12  vmovaps [rsp+0xD0], xmm14
000074703eddaf1b  vmovaps [rsp+0xE0], xmm15
000074703eddaf24  sub rsp, 0x30
000074703eddaf28  movaps [rsp], xmm1
000074703eddaf2c  movaps [rsp+0x10], xmm13
000074703eddaf32  movaps [rsp+0x20], xmm8
000074703eddaf38  lea rdi, [rsp]
000074703eddaf3c  mov esi, 0x00
000074703eddaf41  mov rax, 0x5D9974CCC530
000074703eddaf4b  call rax
000074703eddaf4d  movaps xmm1, [rsp]
000074703eddaf51  add rsp, 0x30
000074703eddaf55  vmovaps xmm0, [rsp]
000074703eddaf5a  vmovaps xmm2, [rsp+0x10]
000074703eddaf60  vmovaps xmm3, [rsp+0x20]
000074703eddaf66  vmovaps xmm4, [rsp+0x30]
000074703eddaf6c  vmovaps xmm5, [rsp+0x40]
000074703eddaf72  vmovaps xmm6, [rsp+0x50]
000074703eddaf78  vmovaps xmm7, [rsp+0x60]
000074703eddaf7e  vmovaps xmm8, [rsp+0x70]
000074703eddaf84  vmovaps xmm9, [rsp+0x80]
000074703eddaf8d  vmovaps xmm10, [rsp+0x90]
000074703eddaf96  vmovaps xmm11, [rsp+0xA0]
000074703eddaf9f  vmovaps xmm12, [rsp+0xB0]
000074703eddafa8  vmovaps xmm13, [rsp+0xC0]
000074703eddafb1  vmovaps xmm14, [rsp+0xD0]
000074703eddafba  vmovaps xmm15, [rsp+0xE0]
000074703eddafc3  add rsp, 0xF0
000074703eddafca  pop r11
000074703eddafcc  pop r10
000074703eddafce  pop r9
000074703eddafd0  pop r8
000074703eddafd2  pop rsi
000074703eddafd3  pop rdi
000074703eddafd4  pop rdx
000074703eddafd5  pop rcx
000074703eddafd6  pop rax
000074703eddafd7  add rsp, 0x08
000074703eddafdb  jmp 0x000074703EDD659A
000074703eddafe0  call 0x000074703EC0C260
000074703eddafe5  jmp 0x000074703EDD65A8
000074703eddafea  call 0x000074703ECDE950
000074703eddafef  jmp 0x000074703EDD65B2
000074703eddaff4  sub rsp, 0x08
000074703eddaff8  push rax
000074703eddaff9  push rcx
000074703eddaffa  push rdx
000074703eddaffb  push rdi
000074703eddaffc  push rsi
000074703eddaffd  push r8
000074703eddafff  push r9
000074703eddb001  push r10
000074703eddb003  push r11
000074703eddb005  sub rsp, 0xF0
000074703eddb00c  vmovaps [rsp], xmm0
000074703eddb011  vmovaps [rsp+0x10], xmm1
000074703eddb017  vmovaps [rsp+0x20], xmm2
000074703eddb01d  vmovaps [rsp+0x30], xmm3
000074703eddb023  vmovaps [rsp+0x40], xmm4
000074703eddb029  vmovaps [rsp+0x50], xmm5
000074703eddb02f  vmovaps [rsp+0x60], xmm6
000074703eddb035  vmovaps [rsp+0x70], xmm7
000074703eddb03b  vmovaps [rsp+0x80], xmm9
000074703eddb044  vmovaps [rsp+0x90], xmm10
000074703eddb04d  vmovaps [rsp+0xA0], xmm11
000074703eddb056  vmovaps [rsp+0xB0], xmm12
000074703eddb05f  vmovaps [rsp+0xC0], xmm13
000074703eddb068  vmovaps [rsp+0xD0], xmm14
000074703eddb071  vmovaps [rsp+0xE0], xmm15
000074703eddb07a  sub rsp, 0x30
000074703eddb07e  movaps [rsp], xmm8
000074703eddb083  movaps [rsp+0x10], xmm15
000074703eddb089  movaps [rsp+0x20], xmm7
000074703eddb08e  lea rdi, [rsp]
000074703eddb092  mov esi, 0x00
000074703eddb097  mov rax, 0x5D9974CCC530
000074703eddb0a1  call rax
000074703eddb0a3  movaps xmm8, [rsp]
000074703eddb0a8  add rsp, 0x30
000074703eddb0ac  vmovaps xmm0, [rsp]
000074703eddb0b1  vmovaps xmm1, [rsp+0x10]
000074703eddb0b7  vmovaps xmm2, [rsp+0x20]
000074703eddb0bd  vmovaps xmm3, [rsp+0x30]
000074703eddb0c3  vmovaps xmm4, [rsp+0x40]
000074703eddb0c9  vmovaps xmm5, [rsp+0x50]
000074703eddb0cf  vmovaps xmm6, [rsp+0x60]
000074703eddb0d5  vmovaps xmm7, [rsp+0x70]
000074703eddb0db  vmovaps xmm9, [rsp+0x80]
000074703eddb0e4  vmovaps xmm10, [rsp+0x90]
000074703eddb0ed  vmovaps xmm11, [rsp+0xA0]
000074703eddb0f6  vmovaps xmm12, [rsp+0xB0]
000074703eddb0ff  vmovaps xmm13, [rsp+0xC0]
000074703eddb108  vmovaps xmm14, [rsp+0xD0]
000074703eddb111  vmovaps xmm15, [rsp+0xE0]
000074703eddb11a  add rsp, 0xF0
000074703eddb121  pop r11
000074703eddb123  pop r10
000074703eddb125  pop r9
000074703eddb127  pop r8
000074703eddb129  pop rsi
000074703eddb12a  pop rdi
000074703eddb12b  pop rdx
000074703eddb12c  pop rcx
000074703eddb12d  pop rax
000074703eddb12e  add rsp, 0x08
000074703eddb132  jmp 0x000074703EDD65D4
000074703eddb137  sub rsp, 0x08
000074703eddb13b  push rax
000074703eddb13c  push rcx
000074703eddb13d  push rdx
000074703eddb13e  push rdi
000074703eddb13f  push rsi
000074703eddb140  push r8
000074703eddb142  push r9
000074703eddb144  push r10
000074703eddb146  push r11
000074703eddb148  sub rsp, 0xF0
000074703eddb14f  vmovaps [rsp], xmm0
000074703eddb154  vmovaps [rsp+0x10], xmm1
000074703eddb15a  vmovaps [rsp+0x20], xmm2
000074703eddb160  vmovaps [rsp+0x30], xmm3
000074703eddb166  vmovaps [rsp+0x40], xmm4
000074703eddb16c  vmovaps [rsp+0x50], xmm5
000074703eddb172  vmovaps [rsp+0x60], xmm6
000074703eddb178  vmovaps [rsp+0x70], xmm8
000074703eddb17e  vmovaps [rsp+0x80], xmm9
000074703eddb187  vmovaps [rsp+0x90], xmm10
000074703eddb190  vmovaps [rsp+0xA0], xmm11
000074703eddb199  vmovaps [rsp+0xB0], xmm12
000074703eddb1a2  vmovaps [rsp+0xC0], xmm13
000074703eddb1ab  vmovaps [rsp+0xD0], xmm14
000074703eddb1b4  vmovaps [rsp+0xE0], xmm15
000074703eddb1bd  sub rsp, 0x30
000074703eddb1c1  movaps [rsp], xmm7
000074703eddb1c5  movaps [rsp+0x10], xmm9
000074703eddb1cb  movaps [rsp+0x20], xmm15
000074703eddb1d1  lea rdi, [rsp]
000074703eddb1d5  mov esi, 0x00
000074703eddb1da  mov rax, 0x5D9974CCC530
000074703eddb1e4  call rax
000074703eddb1e6  movaps xmm7, [rsp]
000074703eddb1ea  add rsp, 0x30
000074703eddb1ee  vmovaps xmm0, [rsp]
000074703eddb1f3  vmovaps xmm1, [rsp+0x10]
000074703eddb1f9  vmovaps xmm2, [rsp+0x20]
000074703eddb1ff  vmovaps xmm3, [rsp+0x30]
000074703eddb205  vmovaps xmm4, [rsp+0x40]
000074703eddb20b  vmovaps xmm5, [rsp+0x50]
000074703eddb211  vmovaps xmm6, [rsp+0x60]
000074703eddb217  vmovaps xmm8, [rsp+0x70]
000074703eddb21d  vmovaps xmm9, [rsp+0x80]
000074703eddb226  vmovaps xmm10, [rsp+0x90]
000074703eddb22f  vmovaps xmm11, [rsp+0xA0]
000074703eddb238  vmovaps xmm12, [rsp+0xB0]
000074703eddb241  vmovaps xmm13, [rsp+0xC0]
000074703eddb24a  vmovaps xmm14, [rsp+0xD0]
000074703eddb253  vmovaps xmm15, [rsp+0xE0]
000074703eddb25c  add rsp, 0xF0
000074703eddb263  pop r11
000074703eddb265  pop r10
000074703eddb267  pop r9
000074703eddb269  pop r8
000074703eddb26b  pop rsi
000074703eddb26c  pop rdi
000074703eddb26d  pop rdx
000074703eddb26e  pop rcx
000074703eddb26f  pop rax
000074703eddb270  add rsp, 0x08
000074703eddb274  jmp 0x000074703EDD6601
000074703eddb279  sub rsp, 0x08
000074703eddb27d  push rax
000074703eddb27e  push rcx
000074703eddb27f  push rdx
000074703eddb280  push rdi
000074703eddb281  push rsi
000074703eddb282  push r8
000074703eddb284  push r9
000074703eddb286  push r10
000074703eddb288  push r11
000074703eddb28a  sub rsp, 0xF0
000074703eddb291  vmovaps [rsp], xmm0
000074703eddb296  vmovaps [rsp+0x10], xmm1
000074703eddb29c  vmovaps [rsp+0x20], xmm2
000074703eddb2a2  vmovaps [rsp+0x30], xmm3
000074703eddb2a8  vmovaps [rsp+0x40], xmm4
000074703eddb2ae  vmovaps [rsp+0x50], xmm5
000074703eddb2b4  vmovaps [rsp+0x60], xmm6
000074703eddb2ba  vmovaps [rsp+0x70], xmm7
000074703eddb2c0  vmovaps [rsp+0x80], xmm8
000074703eddb2c9  vmovaps [rsp+0x90], xmm10
000074703eddb2d2  vmovaps [rsp+0xA0], xmm11
000074703eddb2db  vmovaps [rsp+0xB0], xmm12
000074703eddb2e4  vmovaps [rsp+0xC0], xmm13
000074703eddb2ed  vmovaps [rsp+0xD0], xmm14
000074703eddb2f6  vmovaps [rsp+0xE0], xmm15
000074703eddb2ff  sub rsp, 0x30
000074703eddb303  movaps [rsp], xmm9
000074703eddb308  movaps [rsp+0x10], xmm13
000074703eddb30e  movaps [rsp+0x20], xmm15
000074703eddb314  lea rdi, [rsp]
000074703eddb318  mov esi, 0x00
000074703eddb31d  mov rax, 0x5D9974CCC530
000074703eddb327  call rax
000074703eddb329  movaps xmm9, [rsp]
000074703eddb32e  add rsp, 0x30
000074703eddb332  vmovaps xmm0, [rsp]
000074703eddb337  vmovaps xmm1, [rsp+0x10]
000074703eddb33d  vmovaps xmm2, [rsp+0x20]
000074703eddb343  vmovaps xmm3, [rsp+0x30]
000074703eddb349  vmovaps xmm4, [rsp+0x40]
000074703eddb34f  vmovaps xmm5, [rsp+0x50]
000074703eddb355  vmovaps xmm6, [rsp+0x60]
000074703eddb35b  vmovaps xmm7, [rsp+0x70]
000074703eddb361  vmovaps xmm8, [rsp+0x80]
000074703eddb36a  vmovaps xmm10, [rsp+0x90]
000074703eddb373  vmovaps xmm11, [rsp+0xA0]
000074703eddb37c  vmovaps xmm12, [rsp+0xB0]
000074703eddb385  vmovaps xmm13, [rsp+0xC0]
000074703eddb38e  vmovaps xmm14, [rsp+0xD0]
000074703eddb397  vmovaps xmm15, [rsp+0xE0]
000074703eddb3a0  add rsp, 0xF0
000074703eddb3a7  pop r11
000074703eddb3a9  pop r10
000074703eddb3ab  pop r9
000074703eddb3ad  pop r8
000074703eddb3af  pop rsi
000074703eddb3b0  pop rdi
000074703eddb3b1  pop rdx
000074703eddb3b2  pop rcx
000074703eddb3b3  pop rax
000074703eddb3b4  add rsp, 0x08
000074703eddb3b8  jmp 0x000074703EDD662F
000074703eddb3bd  sub rsp, 0x08
000074703eddb3c1  push rax
000074703eddb3c2  push rcx
000074703eddb3c3  push rdx
000074703eddb3c4  push rdi
000074703eddb3c5  push rsi
000074703eddb3c6  push r8
000074703eddb3c8  push r9
000074703eddb3ca  push r10
000074703eddb3cc  push r11
000074703eddb3ce  sub rsp, 0xF0
000074703eddb3d5  vmovaps [rsp], xmm0
000074703eddb3da  vmovaps [rsp+0x10], xmm1
000074703eddb3e0  vmovaps [rsp+0x20], xmm2
000074703eddb3e6  vmovaps [rsp+0x30], xmm3
000074703eddb3ec  vmovaps [rsp+0x40], xmm4
000074703eddb3f2  vmovaps [rsp+0x50], xmm5
000074703eddb3f8  vmovaps [rsp+0x60], xmm6
000074703eddb3fe  vmovaps [rsp+0x70], xmm7
000074703eddb404  vmovaps [rsp+0x80], xmm8
000074703eddb40d  vmovaps [rsp+0x90], xmm9
000074703eddb416  vmovaps [rsp+0xA0], xmm10
000074703eddb41f  vmovaps [rsp+0xB0], xmm11
000074703eddb428  vmovaps [rsp+0xC0], xmm12
000074703eddb431  vmovaps [rsp+0xD0], xmm13
000074703eddb43a  vmovaps [rsp+0xE0], xmm14
000074703eddb443  sub rsp, 0x30
000074703eddb447  movaps [rsp], xmm15
000074703eddb44c  movaps [rsp+0x10], xmm11
000074703eddb452  movaps [rsp+0x20], xmm12
000074703eddb458  lea rdi, [rsp]
000074703eddb45c  mov esi, 0x00
000074703eddb461  mov rax, 0x5D9974CCC530
000074703eddb46b  call rax
000074703eddb46d  movaps xmm15, [rsp]
000074703eddb472  add rsp, 0x30
000074703eddb476  vmovaps xmm0, [rsp]
000074703eddb47b  vmovaps xmm1, [rsp+0x10]
000074703eddb481  vmovaps xmm2, [rsp+0x20]
000074703eddb487  vmovaps xmm3, [rsp+0x30]
000074703eddb48d  vmovaps xmm4, [rsp+0x40]
000074703eddb493  vmovaps xmm5, [rsp+0x50]
000074703eddb499  vmovaps xmm6, [rsp+0x60]
000074703eddb49f  vmovaps xmm7, [rsp+0x70]
000074703eddb4a5  vmovaps xmm8, [rsp+0x80]
000074703eddb4ae  vmovaps xmm9, [rsp+0x90]
000074703eddb4b7  vmovaps xmm10, [rsp+0xA0]
000074703eddb4c0  vmovaps xmm11, [rsp+0xB0]
000074703eddb4c9  vmovaps xmm12, [rsp+0xC0]
000074703eddb4d2  vmovaps xmm13, [rsp+0xD0]
000074703eddb4db  vmovaps xmm14, [rsp+0xE0]
000074703eddb4e4  add rsp, 0xF0
000074703eddb4eb  pop r11
000074703eddb4ed  pop r10
000074703eddb4ef  pop r9
000074703eddb4f1  pop r8
000074703eddb4f3  pop rsi
000074703eddb4f4  pop rdi
000074703eddb4f5  pop rdx
000074703eddb4f6  pop rcx
000074703eddb4f7  pop rax
000074703eddb4f8  add rsp, 0x08
000074703eddb4fc  jmp 0x000074703EDD664A
000074703eddb501  sub rsp, 0x08
000074703eddb505  push rax
000074703eddb506  push rcx
000074703eddb507  push rdx
000074703eddb508  push rdi
000074703eddb509  push rsi
000074703eddb50a  push r8
000074703eddb50c  push r9
000074703eddb50e  push r10
000074703eddb510  push r11
000074703eddb512  sub rsp, 0xF0
000074703eddb519  vmovaps [rsp], xmm0
000074703eddb51e  vmovaps [rsp+0x10], xmm1
000074703eddb524  vmovaps [rsp+0x20], xmm2
000074703eddb52a  vmovaps [rsp+0x30], xmm3
000074703eddb530  vmovaps [rsp+0x40], xmm4
000074703eddb536  vmovaps [rsp+0x50], xmm5
000074703eddb53c  vmovaps [rsp+0x60], xmm6
000074703eddb542  vmovaps [rsp+0x70], xmm7
000074703eddb548  vmovaps [rsp+0x80], xmm8
000074703eddb551  vmovaps [rsp+0x90], xmm9
000074703eddb55a  vmovaps [rsp+0xA0], xmm10
000074703eddb563  vmovaps [rsp+0xB0], xmm11
000074703eddb56c  vmovaps [rsp+0xC0], xmm12
000074703eddb575  vmovaps [rsp+0xD0], xmm14
000074703eddb57e  vmovaps [rsp+0xE0], xmm15
000074703eddb587  sub rsp, 0x30
000074703eddb58b  movaps [rsp], xmm13
000074703eddb590  movaps [rsp+0x10], xmm10
000074703eddb596  movaps [rsp+0x20], xmm14
000074703eddb59c  lea rdi, [rsp]
000074703eddb5a0  mov esi, 0x00
000074703eddb5a5  mov rax, 0x5D9974CCC530
000074703eddb5af  call rax
000074703eddb5b1  movaps xmm13, [rsp]
000074703eddb5b6  add rsp, 0x30
000074703eddb5ba  vmovaps xmm0, [rsp]
000074703eddb5bf  vmovaps xmm1, [rsp+0x10]
000074703eddb5c5  vmovaps xmm2, [rsp+0x20]
000074703eddb5cb  vmovaps xmm3, [rsp+0x30]
000074703eddb5d1  vmovaps xmm4, [rsp+0x40]
000074703eddb5d7  vmovaps xmm5, [rsp+0x50]
000074703eddb5dd  vmovaps xmm6, [rsp+0x60]
000074703eddb5e3  vmovaps xmm7, [rsp+0x70]
000074703eddb5e9  vmovaps xmm8, [rsp+0x80]
000074703eddb5f2  vmovaps xmm9, [rsp+0x90]
000074703eddb5fb  vmovaps xmm10, [rsp+0xA0]
000074703eddb604  vmovaps xmm11, [rsp+0xB0]
000074703eddb60d  vmovaps xmm12, [rsp+0xC0]
000074703eddb616  vmovaps xmm14, [rsp+0xD0]
000074703eddb61f  vmovaps xmm15, [rsp+0xE0]
000074703eddb628  add rsp, 0xF0
000074703eddb62f  pop r11
000074703eddb631  pop r10
000074703eddb633  pop r9
000074703eddb635  pop r8
000074703eddb637  pop rsi
000074703eddb638  pop rdi
000074703eddb639  pop rdx
000074703eddb63a  pop rcx
000074703eddb63b  pop rax
000074703eddb63c  add rsp, 0x08
000074703eddb640  jmp 0x000074703EDD666D
000074703eddb645  sub rsp, 0x08
000074703eddb649  push rax
000074703eddb64a  push rcx
000074703eddb64b  push rdx
000074703eddb64c  push rdi
000074703eddb64d  push rsi
000074703eddb64e  push r8
000074703eddb650  push r9
000074703eddb652  push r10
000074703eddb654  push r11
000074703eddb656  sub rsp, 0xF0
000074703eddb65d  vmovaps [rsp], xmm0
000074703eddb662  vmovaps [rsp+0x10], xmm1
000074703eddb668  vmovaps [rsp+0x20], xmm2
000074703eddb66e  vmovaps [rsp+0x30], xmm3
000074703eddb674  vmovaps [rsp+0x40], xmm4
000074703eddb67a  vmovaps [rsp+0x50], xmm5
000074703eddb680  vmovaps [rsp+0x60], xmm6
000074703eddb686  vmovaps [rsp+0x70], xmm7
000074703eddb68c  vmovaps [rsp+0x80], xmm8
000074703eddb695  vmovaps [rsp+0x90], xmm9
000074703eddb69e  vmovaps [rsp+0xA0], xmm10
000074703eddb6a7  vmovaps [rsp+0xB0], xmm11
000074703eddb6b0  vmovaps [rsp+0xC0], xmm12
000074703eddb6b9  vmovaps [rsp+0xD0], xmm13
000074703eddb6c2  vmovaps [rsp+0xE0], xmm15
000074703eddb6cb  sub rsp, 0x30
000074703eddb6cf  movaps [rsp], xmm14
000074703eddb6d4  movaps [rsp+0x10], xmm1
000074703eddb6d9  movaps [rsp+0x20], xmm7
000074703eddb6de  lea rdi, [rsp]
000074703eddb6e2  mov esi, 0x00
000074703eddb6e7  mov rax, 0x5D9974CCC530
000074703eddb6f1  call rax
000074703eddb6f3  movaps xmm14, [rsp]
000074703eddb6f8  add rsp, 0x30
000074703eddb6fc  vmovaps xmm0, [rsp]
000074703eddb701  vmovaps xmm1, [rsp+0x10]
000074703eddb707  vmovaps xmm2, [rsp+0x20]
000074703eddb70d  vmovaps xmm3, [rsp+0x30]
000074703eddb713  vmovaps xmm4, [rsp+0x40]
000074703eddb719  vmovaps xmm5, [rsp+0x50]
000074703eddb71f  vmovaps xmm6, [rsp+0x60]
000074703eddb725  vmovaps xmm7, [rsp+0x70]
000074703eddb72b  vmovaps xmm8, [rsp+0x80]
000074703eddb734  vmovaps xmm9, [rsp+0x90]
000074703eddb73d  vmovaps xmm10, [rsp+0xA0]
000074703eddb746  vmovaps xmm11, [rsp+0xB0]
000074703eddb74f  vmovaps xmm12, [rsp+0xC0]
000074703eddb758  vmovaps xmm13, [rsp+0xD0]
000074703eddb761  vmovaps xmm15, [rsp+0xE0]
000074703eddb76a  add rsp, 0xF0
000074703eddb771  pop r11
000074703eddb773  pop r10
000074703eddb775  pop r9
000074703eddb777  pop r8
000074703eddb779  pop rsi
000074703eddb77a  pop rdi
000074703eddb77b  pop rdx
000074703eddb77c  pop rcx
000074703eddb77d  pop rax
000074703eddb77e  add rsp, 0x08
000074703eddb782  jmp 0x000074703EDD6690
000074703eddb787  sub rsp, 0x08
000074703eddb78b  push rax
000074703eddb78c  push rcx
000074703eddb78d  push rdx
000074703eddb78e  push rdi
000074703eddb78f  push rsi
000074703eddb790  push r8
000074703eddb792  push r9
000074703eddb794  push r10
000074703eddb796  push r11
000074703eddb798  sub rsp, 0xF0
000074703eddb79f  vmovaps [rsp], xmm0
000074703eddb7a4  vmovaps [rsp+0x10], xmm2
000074703eddb7aa  vmovaps [rsp+0x20], xmm3
000074703eddb7b0  vmovaps [rsp+0x30], xmm4
000074703eddb7b6  vmovaps [rsp+0x40], xmm5
000074703eddb7bc  vmovaps [rsp+0x50], xmm6
000074703eddb7c2  vmovaps [rsp+0x60], xmm7
000074703eddb7c8  vmovaps [rsp+0x70], xmm8
000074703eddb7ce  vmovaps [rsp+0x80], xmm9
000074703eddb7d7  vmovaps [rsp+0x90], xmm10
000074703eddb7e0  vmovaps [rsp+0xA0], xmm11
000074703eddb7e9  vmovaps [rsp+0xB0], xmm12
000074703eddb7f2  vmovaps [rsp+0xC0], xmm13
000074703eddb7fb  vmovaps [rsp+0xD0], xmm14
000074703eddb804  vmovaps [rsp+0xE0], xmm15
000074703eddb80d  sub rsp, 0x30
000074703eddb811  movaps [rsp], xmm1
000074703eddb815  movaps [rsp+0x10], xmm8
000074703eddb81b  movaps [rsp+0x20], xmm9
000074703eddb821  lea rdi, [rsp]
000074703eddb825  mov esi, 0x00
000074703eddb82a  mov rax, 0x5D9974CCC530
000074703eddb834  call rax
000074703eddb836  movaps xmm1, [rsp]
000074703eddb83a  add rsp, 0x30
000074703eddb83e  vmovaps xmm0, [rsp]
000074703eddb843  vmovaps xmm2, [rsp+0x10]
000074703eddb849  vmovaps xmm3, [rsp+0x20]
000074703eddb84f  vmovaps xmm4, [rsp+0x30]
000074703eddb855  vmovaps xmm5, [rsp+0x40]
000074703eddb85b  vmovaps xmm6, [rsp+0x50]
000074703eddb861  vmovaps xmm7, [rsp+0x60]
000074703eddb867  vmovaps xmm8, [rsp+0x70]
000074703eddb86d  vmovaps xmm9, [rsp+0x80]
000074703eddb876  vmovaps xmm10, [rsp+0x90]
000074703eddb87f  vmovaps xmm11, [rsp+0xA0]
000074703eddb888  vmovaps xmm12, [rsp+0xB0]
000074703eddb891  vmovaps xmm13, [rsp+0xC0]
000074703eddb89a  vmovaps xmm14, [rsp+0xD0]
000074703eddb8a3  vmovaps xmm15, [rsp+0xE0]
000074703eddb8ac  add rsp, 0xF0
000074703eddb8b3  pop r11
000074703eddb8b5  pop r10
000074703eddb8b7  pop r9
000074703eddb8b9  pop r8
000074703eddb8bb  pop rsi
000074703eddb8bc  pop rdi
000074703eddb8bd  pop rdx
000074703eddb8be  pop rcx
000074703eddb8bf  pop rax
000074703eddb8c0  add rsp, 0x08
000074703eddb8c4  jmp 0x000074703EDD66B2
000074703eddb8c9  call 0x000074703ECB3E40
000074703eddb8ce  jmp 0x000074703EDD66C0
000074703eddb8d3  call 0x000074703EC0C380
000074703eddb8d8  jmp 0x000074703EDD66CA
000074703eddb8dd  call 0x000074703EC0D600
000074703eddb8e2  jmp 0x000074703EDD66D4
000074703eddb8e7  call 0x000074703EBFF540
000074703eddb8ec  jmp 0x000074703EDD66DE
000074703eddb8f1  int3
000074703eddb8f2  nop [rax+rax*1], ax
000074703eddb8fb  nop [rax+rax*1], eax
000074703eddb900  mov eax, [r15+0x48]
000074703eddb904  lea r14d, [eax+0x01]
000074703eddb909  mov [rsp+0x10], r14d
000074703eddb90e  mov r14d, r14d
000074703eddb911  mov [r15+0x48], r14
000074703eddb915  xor eax, eax
000074703eddb917  mov r14d, [rsp+0x10]
000074703eddb91c  cmp r14d, 0x1F4
000074703eddb923  cmc
000074703eddb924  lahf
000074703eddb925  seto al
000074703eddb928  mov [r15+0x108], eax
000074703eddb92f  mov eax, [r15+0x108]
000074703eddb936  sahf
000074703eddb937  jnz 0x000074703EDDB969
000074703eddb939  cmp dword ptr [r15+0x318], 0x00
000074703eddb941  jz 0x000074703EDE1AB0
000074703eddb947  nop [rax+rax*1], ax
000074703eddb950  nop [rax+rax*1], eax
000074703eddb958  mov eax, 0x410450
000074703eddb95d  mov [r15+0x100], rax
000074703eddb964  jmp 0x000074703EBFE110
000074703eddb969  cmp dword ptr [r15+0x318], 0x00
000074703eddb971  jz 0x000074703EDDB9A0
000074703eddb977  nop [rax+rax*1], ax
000074703eddb980  nop [rax+rax*1], eax
000074703eddb988  mov eax, 0x410274
000074703eddb98d  mov [r15+0x100], rax
000074703eddb994  jmp 0x000074703EBFE110
000074703eddb999  int3
000074703eddb99a  int3
000074703eddb99b  nop [rax+rax*1], eax
000074703eddb9a0  mov rax, [r15+0x40]
000074703eddb9a4  movaps xmm1, [r15+0x1D0]
000074703eddb9ac  vmovaps [rsp+0x10], xmm1
000074703eddb9b2  vmovaps xmm15, [rsp+0x10]
000074703eddb9b8  por xmm1, xmm15
000074703eddb9bd  movaps xmm14, [r15+0x1A0]
000074703eddb9c5  vmovaps [rsp+0x10], xmm14
000074703eddb9cb  vmovaps xmm13, [rsp+0x10]
000074703eddb9d1  por xmm14, xmm13
000074703eddb9d6  lea r14, [rax+0x30]
000074703eddb9da  mov r12, [r13+r14*1]
000074703eddb9df  lea r14, [rax+0x38]
000074703eddb9e3  mov r11, [r13+r14*1]
000074703eddb9e8  movq xmm13, r12
000074703eddb9ed  movq xmm12, r11
000074703eddb9f2  movq xmm13, xmm13
000074703eddb9f7  vmovaps [rsp+0x10], xmm13
000074703eddb9fd  movq xmm13, xmm13
000074703eddba02  movaps [r15+0x130], xmm13
000074703eddba0a  movq xmm12, xmm12
000074703eddba0f  vmovaps [rsp+0x20], xmm12
000074703eddba15  movq xmm12, xmm12
000074703eddba1a  movaps [r15+0x280], xmm12
000074703eddba22  movaps xmm13, [r15+0x270]
000074703eddba2a  vmovaps [rsp+0x30], xmm13
000074703eddba30  vmovaps xmm12, [rsp+0x30]
000074703eddba36  por xmm13, xmm12
000074703eddba3b  lea r14, [rax+0x20]
000074703eddba3f  mov r12, [r13+r14*1]
000074703eddba44  lea r14, [rax+0x28]
000074703eddba48  mov r11, [r13+r14*1]
000074703eddba4d  movq xmm12, r12
000074703eddba52  movq xmm11, r11
000074703eddba57  movq xmm12, xmm12
000074703eddba5c  vmovaps [rsp+0x30], xmm12
000074703eddba62  movq xmm12, xmm12
000074703eddba67  movaps [r15+0x150], xmm12
000074703eddba6f  movq xmm11, xmm11
000074703eddba74  vmovaps [rsp+0x40], xmm11
000074703eddba7a  movq xmm11, xmm11
000074703eddba7f  movaps [r15+0x140], xmm11
000074703eddba87  lea r14, [rax+0x10]
000074703eddba8b  mov r12, [r13+r14*1]
000074703eddba90  lea r14, [rax+0x18]
000074703eddba94  mov r11, [r13+r14*1]
000074703eddba99  movq xmm12, r12
000074703eddba9e  movq xmm11, r11
000074703eddbaa3  movq xmm12, xmm12
000074703eddbaa8  vmovaps [rsp+0x50], xmm12
000074703eddbaae  movq xmm12, xmm12
000074703eddbab3  movaps [r15+0x170], xmm12
000074703eddbabb  movq xmm11, xmm11
000074703eddbac0  vmovaps [rsp+0x60], xmm11
000074703eddbac6  movq xmm11, xmm11
000074703eddbacb  movaps [r15+0x160], xmm11
000074703eddbad3  mov r14, [r13+rax*1]
000074703eddbad8  vmovq xmm12, r14
000074703eddbadd  vpbroadcastq xmm12, xmm12
000074703eddbae2  lea r14, [rax+0x08]
000074703eddbae6  mov rax, [r13+r14*1]
000074703eddbaeb  movq xmm11, rax
000074703eddbaf0  movaps [r15+0x230], xmm11
000074703eddbaf8  mov rax, [r15+0xF8]
000074703eddbaff  lea r14, [rax+0x50]
000074703eddbb03  movups xmm11, [r13+r14*1]
000074703eddbb09  lea r14, [rax+0x60]
000074703eddbb0d  movups xmm10, [r13+r14*1]
000074703eddbb13  lea r14, [rax+0x30]
000074703eddbb17  movups xmm9, [r13+r14*1]
000074703eddbb1d  mov r14, [r15+0x50]
000074703eddbb21  mov [r15+0x60], r14
000074703eddbb25  mov qword ptr [r15+0x58], 0x40
000074703eddbb2d  movaps xmm8, xmm12
000074703eddbb31  mulpd xmm8, xmm15
000074703eddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000074703eddbb3c  ptest xmm7, xmm7
000074703eddbb41  jnz 0x000074703EDDC96A
000074703eddbb47  movq xmm15, qword ptr [r15+0x230]
000074703eddbb50  vmovaps [rsp+0x70], xmm15
000074703eddbb56  vpermilpd xmm15, xmm15, 0x00
000074703eddbb5c  movaps xmm7, xmm9
000074703eddbb60  mulpd xmm7, xmm15
000074703eddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000074703eddbb6a  ptest xmm6, xmm6
000074703eddbb6f  jnz 0x000074703EDDCAAE
000074703eddbb75  vxorps xmm15, xmm15, xmm15
000074703eddbb7a  vpbroadcastq xmm15, xmm15
000074703eddbb7f  movaps xmm9, xmm12
000074703eddbb83  mulpd xmm9, xmm10
000074703eddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000074703eddbb8e  ptest xmm6, xmm6
000074703eddbb93  jnz 0x000074703EDDCBF0
000074703eddbb99  movaps xmm10, xmm12
000074703eddbb9d  mulpd xmm10, xmm11
000074703eddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000074703eddbba8  ptest xmm6, xmm6
000074703eddbbad  jnz 0x000074703EDDCD34
000074703eddbbb3  movaps xmm11, [r15+0x1F0]
000074703eddbbbb  movaps xmm6, xmm12
000074703eddbbbf  mulpd xmm6, xmm11
000074703eddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000074703eddbbc9  ptest xmm5, xmm5
000074703eddbbce  jnz 0x000074703EDDCE78
000074703eddbbd4  movaps xmm12, [r15+0x2A0]
000074703eddbbdc  vmovaps [rsp+0x80], xmm12
000074703eddbbe5  vmovaps xmm11, [rsp+0x80]
000074703eddbbee  por xmm12, xmm11
000074703eddbbf3  movaps xmm11, [r15+0x250]
000074703eddbbfb  vmovaps [rsp+0x80], xmm11
000074703eddbc04  vmovaps xmm5, [rsp+0x80]
000074703eddbc0d  por xmm11, xmm5
000074703eddbc12  vmovaps xmm4, [rsp+0x70]
000074703eddbc18  vpermilpd xmm4, xmm4, 0x00
000074703eddbc1e  movaps xmm3, xmm5
000074703eddbc21  mulpd xmm3, xmm4
000074703eddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000074703eddbc2a  ptest xmm2, xmm2
000074703eddbc2f  jnz 0x000074703EDDCFBA
000074703eddbc35  mov [rsp+0x80], rax
000074703eddbc3d  xor eax, eax
000074703eddbc3f  mov r12d, 0x40
000074703eddbc45  mov r11d, 0x200
000074703eddbc4b  cmp r12, r11
000074703eddbc4e  cmc
000074703eddbc4f  lahf
000074703eddbc50  seto al
000074703eddbc53  mov [r15+0x108], eax
000074703eddbc5a  movaps xmm5, xmm8
000074703eddbc5e  addpd xmm5, xmm15
000074703eddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000074703eddbc68  ptest xmm4, xmm4
000074703eddbc6d  jnz 0x000074703EDDD0FA
000074703eddbc73  movaps xmm8, [r15+0x1B0]
000074703eddbc7b  movaps xmm4, xmm9
000074703eddbc7f  addpd xmm4, xmm8
000074703eddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000074703eddbc89  ptest xmm2, xmm2
000074703eddbc8e  jnz 0x000074703EDDD23C
000074703eddbc94  movaps xmm9, xmm10
000074703eddbc98  addpd xmm9, xmm8
000074703eddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000074703eddbca3  ptest xmm2, xmm2
000074703eddbca8  jnz 0x000074703EDDD37E
000074703eddbcae  movaps xmm10, [r15+0x2F0]
000074703eddbcb6  vmovaps [rsp+0x90], xmm10
000074703eddbcbf  vmovaps xmm8, [rsp+0x90]
000074703eddbcc8  por xmm10, xmm8
000074703eddbccd  movaps xmm8, [r15+0x2E0]
000074703eddbcd5  vmovaps [rsp+0x90], xmm8
000074703eddbcde  vmovaps xmm2, [rsp+0x90]
000074703eddbce7  por xmm8, xmm2
000074703eddbcec  movaps xmm2, [r15+0x2D0]
000074703eddbcf4  vmovaps [rsp+0x90], xmm2
000074703eddbcfd  vmovaps [rsp+0xA0], xmm1
000074703eddbd06  vmovaps xmm1, [rsp+0x90]
000074703eddbd0f  por xmm2, xmm1
000074703eddbd13  movaps xmm1, [r15+0x200]
000074703eddbd1b  vmovaps [rsp+0x90], xmm1
000074703eddbd24  vmovaps [rsp+0xB0], xmm15
000074703eddbd2d  vmovaps xmm15, [rsp+0x90]
000074703eddbd36  por xmm1, xmm15
000074703eddbd3b  movaps xmm15, [r15+0x1C0]
000074703eddbd43  vmovaps [rsp+0x90], xmm15
000074703eddbd4c  vmovaps [rsp+0xC0], xmm1
000074703eddbd55  vmovaps xmm1, [rsp+0x90]
000074703eddbd5e  por xmm15, xmm1
000074703eddbd63  movaps xmm1, [r15+0x190]
000074703eddbd6b  vmovaps [rsp+0x90], xmm1
000074703eddbd74  vmovaps [rsp+0xD0], xmm15
000074703eddbd7d  vmovaps xmm15, [rsp+0x90]
000074703eddbd86  por xmm1, xmm15
000074703eddbd8b  movaps xmm15, [r15+0x300]
000074703eddbd93  vmovaps [rsp+0x90], xmm15
000074703eddbd9c  vmovaps [rsp+0xE0], xmm1
000074703eddbda5  vmovaps xmm1, [rsp+0x90]
000074703eddbdae  por xmm15, xmm1
000074703eddbdb3  mov rax, [rsp+0x80]
000074703eddbdbb  lea r12, [rax+0xA0]
000074703eddbdc2  movups xmm1, [r13+r12*1]
000074703eddbdc8  lea r12, [rax+0xB0]
000074703eddbdcf  vmovaps [rsp+0x80], xmm1
000074703eddbdd8  movups xmm1, [r13+r12*1]
000074703eddbdde  vmovaps [rsp+0x90], xmm1
000074703eddbde7  vmovaps [rsp+0xF0], xmm15
000074703eddbdf0  vmovaps xmm15, [rsp+0xB0]
000074703eddbdf9  vmovaps [rsp+0xB0], xmm14
000074703eddbe02  movaps xmm1, xmm6
000074703eddbe05  addpd xmm1, xmm15
000074703eddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000074703eddbe0f  ptest xmm14, xmm14
000074703eddbe15  jnz 0x000074703EDDD4D6
000074703eddbe1b  lea r12, [rax+0xF0]
000074703eddbe22  movups xmm15, [r13+r12*1]
000074703eddbe28  movaps xmm14, xmm4
000074703eddbe2c  addpd xmm14, xmm3
000074703eddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000074703eddbe37  ptest xmm6, xmm6
000074703eddbe3c  jnz 0x000074703EDDD621
000074703eddbe42  movaps xmm6, xmm9
000074703eddbe46  addpd xmm6, xmm7
000074703eddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000074703eddbe4f  ptest xmm4, xmm4
000074703eddbe54  jnz 0x000074703EDDD763
000074703eddbe5a  vmovaps xmm9, [rsp+0x70]
000074703eddbe60  vpermilpd xmm9, xmm9, 0x00
000074703eddbe66  vmovaps xmm4, [rsp+0x90]
000074703eddbe6f  movaps xmm7, xmm4
000074703eddbe72  mulpd xmm7, xmm9
000074703eddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000074703eddbe7c  ptest xmm3, xmm3
000074703eddbe81  jnz 0x000074703EDDD8A4
000074703eddbe87  vmovaps xmm9, [rsp+0x50]
000074703eddbe8d  vpermilpd xmm9, xmm9, 0x00
000074703eddbe93  movaps xmm4, xmm15
000074703eddbe97  mulpd xmm4, xmm9
000074703eddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000074703eddbea1  ptest xmm3, xmm3
000074703eddbea6  jnz 0x000074703EDDD9E5
000074703eddbeac  lea r12, [rax+0xE0]
000074703eddbeb3  movups xmm15, [r13+r12*1]
000074703eddbeb9  vmovaps xmm9, [rsp+0x70]
000074703eddbebf  vpermilpd xmm9, xmm9, 0x00
000074703eddbec5  vmovaps [rsp+0x70], xmm1
000074703eddbecb  vmovaps xmm1, [rsp+0x80]
000074703eddbed4  vmovaps [rsp+0x80], xmm15
000074703eddbedd  movaps xmm3, xmm1
000074703eddbee0  mulpd xmm3, xmm9
000074703eddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000074703eddbeea  ptest xmm15, xmm15
000074703eddbef0  jnz 0x000074703EDDDB31
000074703eddbef6  vmovaps xmm1, [rsp+0xF0]
000074703eddbeff  vmovaps xmm15, [rsp+0xF0]
000074703eddbf08  por xmm1, xmm15
000074703eddbf0d  movaps [r15+0x300], xmm1
000074703eddbf15  vmovaps xmm15, [rsp+0xE0]
000074703eddbf1e  vmovaps xmm9, [rsp+0xE0]
000074703eddbf27  por xmm15, xmm9
000074703eddbf2c  movaps [r15+0x190], xmm15
000074703eddbf34  vmovaps xmm9, [rsp+0x50]
000074703eddbf3a  vpermilpd xmm9, xmm9, 0x00
000074703eddbf40  vmovaps [rsp+0x90], xmm1
000074703eddbf49  vmovaps [rsp+0xE0], xmm15
000074703eddbf52  vmovaps xmm15, [rsp+0x80]
000074703eddbf5b  vmovaps [rsp+0x80], xmm14
000074703eddbf64  movaps xmm1, xmm15
000074703eddbf68  mulpd xmm1, xmm9
000074703eddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000074703eddbf72  ptest xmm14, xmm14
000074703eddbf78  jnz 0x000074703EDDDC72
000074703eddbf7e  lea r12, [rax+0x90]
000074703eddbf85  movups xmm15, [r13+r12*1]
000074703eddbf8b  vmovaps xmm14, [rsp+0xD0]
000074703eddbf94  vmovaps xmm9, [rsp+0xD0]
000074703eddbf9d  por xmm14, xmm9
000074703eddbfa2  movaps [r15+0x1C0], xmm14
000074703eddbfaa  vmovaps xmm9, [rsp+0xC0]
000074703eddbfb3  vmovaps [rsp+0xD0], xmm1
000074703eddbfbc  vmovaps xmm1, [rsp+0xC0]
000074703eddbfc5  por xmm9, xmm1
000074703eddbfca  movaps [r15+0x200], xmm9
000074703eddbfd2  vmovaps [rsp+0xC0], xmm2
000074703eddbfdb  vmovaps xmm1, [rsp+0xC0]
000074703eddbfe4  por xmm2, xmm1
000074703eddbfe8  movaps [r15+0x2D0], xmm2
000074703eddbff0  vmovaps [rsp+0xC0], xmm8
000074703eddbff9  vmovaps xmm1, [rsp+0xC0]
000074703eddc002  por xmm8, xmm1
000074703eddc007  movaps [r15+0x2E0], xmm8
000074703eddc00f  vmovaps [rsp+0xC0], xmm15
000074703eddc018  movaps xmm1, xmm5
000074703eddc01b  addpd xmm1, xmm7
000074703eddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000074703eddc024  ptest xmm15, xmm15
000074703eddc02a  jnz 0x000074703EDDDDBE
000074703eddc030  vmovaps xmm15, [rsp+0x50]
000074703eddc036  vpermilpd xmm15, xmm15, 0x00
000074703eddc03c  vmovaps xmm5, [rsp+0xC0]
000074703eddc045  vmovaps [rsp+0xC0], xmm1
000074703eddc04e  movaps xmm7, xmm5
000074703eddc051  mulpd xmm7, xmm15
000074703eddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000074703eddc05b  ptest xmm1, xmm1
000074703eddc060  jnz 0x000074703EDDDEFE
000074703eddc066  lea r12, [rax+0x80]
000074703eddc06d  movups xmm1, [r13+r12*1]
000074703eddc073  vmovaps xmm5, [rsp+0x70]
000074703eddc079  vmovaps [rsp+0x70], xmm1
000074703eddc07f  movaps xmm15, xmm5
000074703eddc083  addpd xmm15, xmm3
000074703eddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000074703eddc08e  ptest xmm1, xmm1
000074703eddc093  jnz 0x000074703EDDE049
000074703eddc099  vmovaps xmm5, [rsp+0x80]
000074703eddc0a2  movaps xmm1, xmm5
000074703eddc0a5  addpd xmm1, xmm4
000074703eddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000074703eddc0ae  ptest xmm3, xmm3
000074703eddc0b3  jnz 0x000074703EDDE18B
000074703eddc0b9  vmovaps [rsp+0x80], xmm10
000074703eddc0c2  vmovaps xmm5, [rsp+0x80]
000074703eddc0cb  por xmm10, xmm5
000074703eddc0d0  movaps [r15+0x2F0], xmm10
000074703eddc0d8  vmovaps xmm5, [rsp+0x50]
000074703eddc0de  vpermilpd xmm5, xmm5, 0x00
000074703eddc0e4  vmovaps xmm3, [rsp+0x70]
000074703eddc0ea  vmovaps [rsp+0x50], xmm1
000074703eddc0f0  movaps xmm4, xmm3
000074703eddc0f3  mulpd xmm4, xmm5
000074703eddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000074703eddc0fc  ptest xmm1, xmm1
000074703eddc101  jnz 0x000074703EDDE2CB
000074703eddc107  lea r12, [rax+0xD0]
000074703eddc10e  movups xmm1, [r13+r12*1]
000074703eddc114  vmovaps xmm3, [rsp+0xD0]
000074703eddc11d  vmovaps [rsp+0x70], xmm1
000074703eddc123  movaps xmm5, xmm6
000074703eddc126  addpd xmm5, xmm3
000074703eddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000074703eddc12f  ptest xmm1, xmm1
000074703eddc134  jnz 0x000074703EDDE415
000074703eddc13a  vmovaps xmm1, [rsp+0x60]
000074703eddc140  vpermilpd xmm1, xmm1, 0x00
000074703eddc146  movaps xmm6, xmm9
000074703eddc14a  mulpd xmm6, xmm1
000074703eddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000074703eddc153  ptest xmm3, xmm3
000074703eddc158  jnz 0x000074703EDDE555
000074703eddc15e  movaps [r15+0x260], xmm6
000074703eddc166  vxorps xmm1, xmm1, xmm1
000074703eddc16a  vpbroadcastq xmm1, xmm1
000074703eddc16f  movaps [r15+0x1B0], xmm1
000074703eddc177  vmovaps xmm1, [rsp+0x60]
000074703eddc17d  vpermilpd xmm1, xmm1, 0x00
000074703eddc183  vmovaps xmm3, [rsp+0x70]
000074703eddc189  vmovaps [rsp+0x70], xmm15
000074703eddc18f  movaps xmm9, xmm3
000074703eddc193  mulpd xmm9, xmm1
000074703eddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000074703eddc19e  ptest xmm15, xmm15
000074703eddc1a4  jnz 0x000074703EDDE696
000074703eddc1aa  lea r12, [rax+0xC0]
000074703eddc1b1  movups xmm1, [r13+r12*1]
000074703eddc1b7  vmovaps xmm3, [rsp+0xC0]
000074703eddc1c0  vmovaps [rsp+0x80], xmm1
000074703eddc1c9  movaps xmm15, xmm3
000074703eddc1cd  addpd xmm15, xmm7
000074703eddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000074703eddc1d8  ptest xmm1, xmm1
000074703eddc1dd  jnz 0x000074703EDDE7E2
000074703eddc1e3  vmovaps [rsp+0xC0], xmm13
000074703eddc1ec  vmovaps xmm1, [rsp+0xC0]
000074703eddc1f5  por xmm13, xmm1
000074703eddc1fa  movaps [r15+0x270], xmm13
000074703eddc202  vmovaps xmm1, [rsp+0xB0]
000074703eddc20b  vmovaps xmm7, [rsp+0xB0]
000074703eddc214  por xmm1, xmm7
000074703eddc218  movaps [r15+0x1A0], xmm1
000074703eddc220  vmovaps xmm1, [rsp+0x60]
000074703eddc226  vpermilpd xmm1, xmm1, 0x00
000074703eddc22c  vmovaps [rsp+0xB0], xmm1
000074703eddc235  vmovaps xmm1, [rsp+0x80]
000074703eddc23e  vmovaps [rsp+0x80], xmm15
000074703eddc247  vmovaps xmm15, [rsp+0xB0]
000074703eddc250  vmovaps [rsp+0xB0], xmm14
000074703eddc259  movaps xmm3, xmm1
000074703eddc25c  mulpd xmm3, xmm15
000074703eddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000074703eddc266  ptest xmm14, xmm14
000074703eddc26c  jnz 0x000074703EDDE924
000074703eddc272  lea r12, [rax+0x20]
000074703eddc276  movups xmm1, [r13+r12*1]
000074703eddc27c  movaps [r15+0x110], xmm1
000074703eddc284  vmovaps xmm14, [rsp+0x70]
000074703eddc28a  vmovaps [rsp+0x70], xmm1
000074703eddc290  movaps xmm15, xmm14
000074703eddc294  addpd xmm15, xmm4
000074703eddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000074703eddc29f  ptest xmm1, xmm1
000074703eddc2a4  jnz 0x000074703EDDEA6F
000074703eddc2aa  vmovaps xmm1, [rsp+0x60]
000074703eddc2b0  vpermilpd xmm1, xmm1, 0x00
000074703eddc2b6  movaps xmm14, xmm2
000074703eddc2ba  mulpd xmm14, xmm1
000074703eddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000074703eddc2c5  ptest xmm4, xmm4
000074703eddc2ca  jnz 0x000074703EDDEBB2
000074703eddc2d0  vmovaps xmm4, [rsp+0x50]
000074703eddc2d6  movaps xmm1, xmm4
000074703eddc2d9  addpd xmm1, xmm9
000074703eddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000074703eddc2e3  ptest xmm2, xmm2
000074703eddc2e8  jnz 0x000074703EDDECF4
000074703eddc2ee  vmovaps xmm9, [rsp+0x30]
000074703eddc2f4  vpermilpd xmm9, xmm9, 0x00
000074703eddc2fa  vmovaps xmm2, [rsp+0x70]
000074703eddc300  vmovaps [rsp+0x50], xmm1
000074703eddc306  movaps xmm4, xmm2
000074703eddc309  mulpd xmm4, xmm9
000074703eddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000074703eddc313  ptest xmm1, xmm1
000074703eddc318  jnz 0x000074703EDDEE35
000074703eddc31e  vmovaps xmm1, [rsp+0x30]
000074703eddc324  vpermilpd xmm1, xmm1, 0x00
000074703eddc32a  vmovaps xmm2, [rsp+0x90]
000074703eddc333  vmovaps [rsp+0x60], xmm15
000074703eddc339  movaps xmm9, xmm2
000074703eddc33d  mulpd xmm9, xmm1
000074703eddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000074703eddc348  ptest xmm15, xmm15
000074703eddc34e  jnz 0x000074703EDDEF76
000074703eddc354  vmovaps xmm15, [rsp+0x80]
000074703eddc35d  movaps xmm1, xmm15
000074703eddc361  addpd xmm1, xmm6
000074703eddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000074703eddc36a  ptest xmm2, xmm2
000074703eddc36f  jnz 0x000074703EDDF0B8
000074703eddc375  movaps xmm15, xmm5
000074703eddc379  addpd xmm15, xmm3
000074703eddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000074703eddc384  ptest xmm6, xmm6
000074703eddc389  jnz 0x000074703EDDF1F9
000074703eddc38f  vmovaps xmm6, [rsp+0x30]
000074703eddc395  vpermilpd xmm6, xmm6, 0x00
000074703eddc39b  movaps xmm5, xmm8
000074703eddc39f  mulpd xmm5, xmm6
000074703eddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000074703eddc3a8  ptest xmm3, xmm3
000074703eddc3ad  jnz 0x000074703EDDF33B
000074703eddc3b3  vmovaps xmm8, [rsp+0x30]
000074703eddc3b9  vpermilpd xmm8, xmm8, 0x00
000074703eddc3bf  movaps xmm6, xmm10
000074703eddc3c3  mulpd xmm6, xmm8
000074703eddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000074703eddc3cd  ptest xmm3, xmm3
000074703eddc3d2  jnz 0x000074703EDDF47C
000074703eddc3d8  vmovaps xmm8, [rsp+0x60]
000074703eddc3de  movaps xmm10, xmm8
000074703eddc3e2  addpd xmm10, xmm14
000074703eddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000074703eddc3ed  ptest xmm3, xmm3
000074703eddc3f2  jnz 0x000074703EDDF5BE
000074703eddc3f8  vmovaps xmm8, [rsp+0x50]
000074703eddc3fe  movaps xmm14, xmm8
000074703eddc402  addpd xmm14, xmm4
000074703eddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000074703eddc40d  ptest xmm3, xmm3
000074703eddc412  jnz 0x000074703EDDF702
000074703eddc418  vmovaps xmm8, [rsp+0x40]
000074703eddc41e  vpermilpd xmm8, xmm8, 0x00
000074703eddc424  movaps xmm4, xmm13
000074703eddc428  mulpd xmm4, xmm8
000074703eddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000074703eddc432  ptest xmm3, xmm3
000074703eddc437  jnz 0x000074703EDDF845
000074703eddc43d  movaps xmm13, xmm15
000074703eddc441  addpd xmm13, xmm9
000074703eddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000074703eddc44c  ptest xmm8, xmm8
000074703eddc452  jnz 0x000074703EDDF987
000074703eddc458  movaps xmm15, xmm1
000074703eddc45c  addpd xmm15, xmm5
000074703eddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000074703eddc467  ptest xmm9, xmm9
000074703eddc46d  jnz 0x000074703EDDFACB
000074703eddc473  vmovaps [rsp+0x30], xmm11
000074703eddc479  vmovaps xmm1, [rsp+0x30]
000074703eddc47f  por xmm11, xmm1
000074703eddc484  movaps [r15+0x250], xmm11
000074703eddc48c  vmovaps [rsp+0x30], xmm12
000074703eddc492  vmovaps xmm1, [rsp+0x30]
000074703eddc498  por xmm12, xmm1
000074703eddc49d  movaps [r15+0x2A0], xmm12
000074703eddc4a5  vmovaps xmm1, [rsp+0xA0]
000074703eddc4ae  vmovaps xmm11, [rsp+0xA0]
000074703eddc4b7  por xmm1, xmm11
000074703eddc4bc  movaps [r15+0x1D0], xmm1
000074703eddc4c4  lea r12, [rax+0x40]
000074703eddc4c8  movups xmm1, [r13+r12*1]
000074703eddc4ce  movaps [r15+0x2C0], xmm1
000074703eddc4d6  vmovaps xmm11, [rsp+0x40]
000074703eddc4dc  vpermilpd xmm11, xmm11, 0x00
000074703eddc4e2  vmovaps xmm8, [rsp+0xE0]
000074703eddc4eb  movaps xmm9, xmm8
000074703eddc4ef  mulpd xmm9, xmm11
000074703eddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000074703eddc4fa  ptest xmm5, xmm5
000074703eddc4ff  jnz 0x000074703EDDFC17
000074703eddc505  movaps xmm11, xmm10
000074703eddc509  addpd xmm11, xmm6
000074703eddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000074703eddc514  ptest xmm8, xmm8
000074703eddc51a  jnz 0x000074703EDDFD5B
000074703eddc520  movaps xmm10, xmm14
000074703eddc524  addpd xmm10, xmm4
000074703eddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000074703eddc52f  ptest xmm8, xmm8
000074703eddc535  jnz 0x000074703EDDFE9E
000074703eddc53b  vmovaps xmm14, [rsp+0x40]
000074703eddc541  vpermilpd xmm14, xmm14, 0x00
000074703eddc547  movaps xmm8, xmm1
000074703eddc54b  mulpd xmm8, xmm14
000074703eddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000074703eddc556  ptest xmm6, xmm6
000074703eddc55b  jnz 0x000074703EDDFFE1
000074703eddc561  movaps xmm1, [r15+0x2B0]
000074703eddc569  vmovaps xmm14, [rsp+0x40]
000074703eddc56f  vpermilpd xmm14, xmm14, 0x00
000074703eddc575  movaps xmm6, xmm1
000074703eddc578  mulpd xmm6, xmm14
000074703eddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000074703eddc582  ptest xmm5, xmm5
000074703eddc587  jnz 0x000074703EDE0124
000074703eddc58d  vmovaps xmm1, [rsp+0x10]
000074703eddc593  vpermilpd xmm1, xmm1, 0x00
000074703eddc599  movaps xmm14, xmm12
000074703eddc59d  mulpd xmm14, xmm1
000074703eddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000074703eddc5a8  ptest xmm5, xmm5
000074703eddc5ad  jnz 0x000074703EDE0265
000074703eddc5b3  movaps xmm1, xmm13
000074703eddc5b7  addpd xmm1, xmm9
000074703eddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000074703eddc5c1  ptest xmm12, xmm12
000074703eddc5c7  jnz 0x000074703EDE03A8
000074703eddc5cd  vmovaps xmm13, [rsp+0x10]
000074703eddc5d3  vpermilpd xmm13, xmm13, 0x00
000074703eddc5d9  movaps xmm12, xmm7
000074703eddc5dd  mulpd xmm12, xmm13
000074703eddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000074703eddc5e8  ptest xmm9, xmm9
000074703eddc5ee  jnz 0x000074703EDE04EA
000074703eddc5f4  movaps xmm13, xmm15
000074703eddc5f8  addpd xmm13, xmm8
000074703eddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000074703eddc603  ptest xmm9, xmm9
000074703eddc609  jnz 0x000074703EDE062D
000074703eddc60f  movaps xmm15, [r15+0x290]
000074703eddc617  vmovaps xmm9, [rsp+0x10]
000074703eddc61d  vpermilpd xmm9, xmm9, 0x00
000074703eddc623  movaps xmm8, xmm15
000074703eddc627  mulpd xmm8, xmm9
000074703eddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000074703eddc632  ptest xmm7, xmm7
000074703eddc637  jnz 0x000074703EDE0771
000074703eddc63d  movaps xmm15, xmm11
000074703eddc641  addpd xmm15, xmm6
000074703eddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000074703eddc64c  ptest xmm9, xmm9
000074703eddc652  jnz 0x000074703EDE08B5
000074703eddc658  movaps xmm11, [r15+0x1E0]
000074703eddc660  vmovaps xmm9, [rsp+0x10]
000074703eddc666  vpermilpd xmm9, xmm9, 0x00
000074703eddc66c  movaps xmm7, xmm11
000074703eddc670  mulpd xmm7, xmm9
000074703eddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000074703eddc67a  ptest xmm6, xmm6
000074703eddc67f  jnz 0x000074703EDE09F8
000074703eddc685  movaps xmm11, xmm10
000074703eddc689  addpd xmm11, xmm14
000074703eddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000074703eddc694  ptest xmm9, xmm9
000074703eddc69a  jnz 0x000074703EDE0B3A
000074703eddc6a0  lea r12, [rax+0x70]
000074703eddc6a4  movups xmm14, [r13+r12*1]
000074703eddc6aa  movaps [r15+0x240], xmm14
000074703eddc6b2  movaps xmm10, xmm1
000074703eddc6b6  addpd xmm10, xmm12
000074703eddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000074703eddc6c1  ptest xmm9, xmm9
000074703eddc6c7  jnz 0x000074703EDE0C88
000074703eddc6cd  movaps [r15+0x170], xmm10
000074703eddc6d5  vmovaps xmm1, [rsp+0x20]
000074703eddc6db  vpermilpd xmm1, xmm1, 0x00
000074703eddc6e1  movaps xmm12, xmm14
000074703eddc6e5  mulpd xmm12, xmm1
000074703eddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000074703eddc6f0  ptest xmm9, xmm9
000074703eddc6f6  jnz 0x000074703EDE0DCB
000074703eddc6fc  vmovaps xmm1, [rsp+0x20]
000074703eddc702  vpermilpd xmm1, xmm1, 0x00
000074703eddc708  vmovaps xmm9, [rsp+0xB0]
000074703eddc711  movaps xmm14, xmm9
000074703eddc715  mulpd xmm14, xmm1
000074703eddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000074703eddc720  ptest xmm6, xmm6
000074703eddc725  jnz 0x000074703EDE0F0E
000074703eddc72b  movaps [r15+0x180], xmm14
000074703eddc733  movaps xmm1, xmm13
000074703eddc737  addpd xmm1, xmm8
000074703eddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000074703eddc741  ptest xmm9, xmm9
000074703eddc747  jnz 0x000074703EDE1051
000074703eddc74d  movaps [r15+0x210], xmm1
000074703eddc755  movups xmm13, [r13+rax*1]
000074703eddc75b  lea r12, [rax+0x10]
000074703eddc75f  movups xmm9, [r13+r12*1]
000074703eddc765  movaps [r15+0x230], xmm9
000074703eddc76d  movaps xmm8, xmm15
000074703eddc771  addpd xmm8, xmm7
000074703eddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000074703eddc77c  ptest xmm6, xmm6
000074703eddc781  jnz 0x000074703EDE11A7
000074703eddc787  movaps [r15+0x130], xmm8
000074703eddc78f  vmovaps xmm15, [rsp+0x20]
000074703eddc795  vpermilpd xmm15, xmm15, 0x00
000074703eddc79b  movaps xmm7, xmm9
000074703eddc79f  mulpd xmm7, xmm15
000074703eddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000074703eddc7a9  ptest xmm6, xmm6
000074703eddc7ae  jnz 0x000074703EDE12EA
000074703eddc7b4  movaps [r15+0x220], xmm7
000074703eddc7bc  vmovaps xmm15, [rsp+0x20]
000074703eddc7c2  vpermilpd xmm15, xmm15, 0x00
000074703eddc7c8  movaps xmm9, xmm13
000074703eddc7cc  mulpd xmm9, xmm15
000074703eddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000074703eddc7d7  ptest xmm6, xmm6
000074703eddc7dc  jnz 0x000074703EDE142C
000074703eddc7e2  movaps xmm15, xmm11
000074703eddc7e6  addpd xmm15, xmm12
000074703eddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000074703eddc7f1  ptest xmm13, xmm13
000074703eddc7f7  jnz 0x000074703EDE1570
000074703eddc7fd  movaps [r15+0x140], xmm15
000074703eddc805  movaps xmm13, xmm10
000074703eddc809  addpd xmm13, xmm14
000074703eddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000074703eddc814  ptest xmm12, xmm12
000074703eddc81a  jnz 0x000074703EDE16B4
000074703eddc820  movaps [r15+0x150], xmm13
000074703eddc828  movaps xmm14, xmm1
000074703eddc82c  addpd xmm14, xmm7
000074703eddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000074703eddc837  ptest xmm12, xmm12
000074703eddc83d  jnz 0x000074703EDE17F8
000074703eddc843  movaps [r15+0x160], xmm14
000074703eddc84b  movaps xmm1, xmm8
000074703eddc84f  addpd xmm1, xmm9
000074703eddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000074703eddc859  ptest xmm12, xmm12
000074703eddc85f  jnz 0x000074703EDE193A
000074703eddc865  movaps [r15+0x120], xmm1
000074703eddc86d  movups [r13+r14*1], xmm15
000074703eddc873  lea rax, [r14+0x10]
000074703eddc877  movups [r13+rax*1], xmm13
000074703eddc87d  lea rax, [r14+0x20]
000074703eddc881  movups [r13+rax*1], xmm14
000074703eddc887  lea rax, [r14+0x30]
000074703eddc88b  movups [r13+rax*1], xmm1
000074703eddc891  mov eax, [r15+0x108]
000074703eddc898  sahf
000074703eddc899  jnz 0x000074703EDDC8CB
000074703eddc89b  cmp dword ptr [r15+0x318], 0x00
000074703eddc8a3  jz 0x000074703EDDB900
000074703eddc8a9  nop [rax+rax*1], ax
000074703eddc8b2  nop [rax+rax*1], eax
000074703eddc8ba  mov eax, 0x410444
000074703eddc8bf  mov [r15+0x100], rax
000074703eddc8c6  jmp 0x000074703EBFE110
000074703eddc8cb  cmp dword ptr [r15+0x318], 0x00
000074703eddc8d3  jz 0x000074703EDD57E0
000074703eddc8d9  nop [rax+rax*1], ax
000074703eddc8e2  nop [rax+rax*1], eax
000074703eddc8ea  mov eax, 0x410278
000074703eddc8ef  mov [r15+0x100], rax
000074703eddc8f6  jmp 0x000074703EBFE110
000074703eddc8fb  int3
000074703eddc8fc  call 0x000074703ECE27E0
000074703eddc901  jmp 0x000074703EDDB9DF
000074703eddc906  call 0x000074703ECE1570
000074703eddc90b  jmp 0x000074703EDDB9E8
000074703eddc910  call 0x000074703ECE27E0
000074703eddc915  jmp 0x000074703EDDBA44
000074703eddc91a  call 0x000074703ECE1570
000074703eddc91f  jmp 0x000074703EDDBA4D
000074703eddc924  call 0x000074703ECE27E0
000074703eddc929  jmp 0x000074703EDDBA90
000074703eddc92e  call 0x000074703ECE1570
000074703eddc933  jmp 0x000074703EDDBA99
000074703eddc938  call 0x000074703EC0DC20
000074703eddc93d  jmp 0x000074703EDDBAD8
000074703eddc942  call 0x000074703ECD59C0
000074703eddc947  jmp 0x000074703EDDBAEB
000074703eddc94c  call 0x000074703ECE0E30
000074703eddc951  jmp 0x000074703EDDBB09
000074703eddc956  call 0x000074703ECDFBC0
000074703eddc95b  jmp 0x000074703EDDBB13
000074703eddc960  call 0x000074703ECDE950
000074703eddc965  jmp 0x000074703EDDBB1D
000074703eddc96a  sub rsp, 0x08
000074703eddc96e  push rax
000074703eddc96f  push rcx
000074703eddc970  push rdx
000074703eddc971  push rdi
000074703eddc972  push rsi
000074703eddc973  push r8
000074703eddc975  push r9
000074703eddc977  push r10
000074703eddc979  push r11
000074703eddc97b  sub rsp, 0xF0
000074703eddc982  vmovaps [rsp], xmm0
000074703eddc987  vmovaps [rsp+0x10], xmm1
000074703eddc98d  vmovaps [rsp+0x20], xmm2
000074703eddc993  vmovaps [rsp+0x30], xmm3
000074703eddc999  vmovaps [rsp+0x40], xmm4
000074703eddc99f  vmovaps [rsp+0x50], xmm5
000074703eddc9a5  vmovaps [rsp+0x60], xmm6
000074703eddc9ab  vmovaps [rsp+0x70], xmm7
000074703eddc9b1  vmovaps [rsp+0x80], xmm9
000074703eddc9ba  vmovaps [rsp+0x90], xmm10
000074703eddc9c3  vmovaps [rsp+0xA0], xmm11
000074703eddc9cc  vmovaps [rsp+0xB0], xmm12
000074703eddc9d5  vmovaps [rsp+0xC0], xmm13
000074703eddc9de  vmovaps [rsp+0xD0], xmm14
000074703eddc9e7  vmovaps [rsp+0xE0], xmm15
000074703eddc9f0  sub rsp, 0x30
000074703eddc9f4  movaps [rsp], xmm8
000074703eddc9f9  movaps [rsp+0x10], xmm12
000074703eddc9ff  movaps [rsp+0x20], xmm15
000074703eddca05  lea rdi, [rsp]
000074703eddca09  mov esi, 0x00
000074703eddca0e  mov rax, 0x5D9974CCC530
000074703eddca18  call rax
000074703eddca1a  movaps xmm8, [rsp]
000074703eddca1f  add rsp, 0x30
000074703eddca23  vmovaps xmm0, [rsp]
000074703eddca28  vmovaps xmm1, [rsp+0x10]
000074703eddca2e  vmovaps xmm2, [rsp+0x20]
000074703eddca34  vmovaps xmm3, [rsp+0x30]
000074703eddca3a  vmovaps xmm4, [rsp+0x40]
000074703eddca40  vmovaps xmm5, [rsp+0x50]
000074703eddca46  vmovaps xmm6, [rsp+0x60]
000074703eddca4c  vmovaps xmm7, [rsp+0x70]
000074703eddca52  vmovaps xmm9, [rsp+0x80]
000074703eddca5b  vmovaps xmm10, [rsp+0x90]
000074703eddca64  vmovaps xmm11, [rsp+0xA0]
000074703eddca6d  vmovaps xmm12, [rsp+0xB0]
000074703eddca76  vmovaps xmm13, [rsp+0xC0]
000074703eddca7f  vmovaps xmm14, [rsp+0xD0]
000074703eddca88  vmovaps xmm15, [rsp+0xE0]
000074703eddca91  add rsp, 0xF0
000074703eddca98  pop r11
000074703eddca9a  pop r10
000074703eddca9c  pop r9
000074703eddca9e  pop r8
000074703eddcaa0  pop rsi
000074703eddcaa1  pop rdi
000074703eddcaa2  pop rdx
000074703eddcaa3  pop rcx
000074703eddcaa4  pop rax
000074703eddcaa5  add rsp, 0x08
000074703eddcaa9  jmp 0x000074703EDDBB47
000074703eddcaae  sub rsp, 0x08
000074703eddcab2  push rax
000074703eddcab3  push rcx
000074703eddcab4  push rdx
000074703eddcab5  push rdi
000074703eddcab6  push rsi
000074703eddcab7  push r8
000074703eddcab9  push r9
000074703eddcabb  push r10
000074703eddcabd  push r11
000074703eddcabf  sub rsp, 0xF0
000074703eddcac6  vmovaps [rsp], xmm0
000074703eddcacb  vmovaps [rsp+0x10], xmm1
000074703eddcad1  vmovaps [rsp+0x20], xmm2
000074703eddcad7  vmovaps [rsp+0x30], xmm3
000074703eddcadd  vmovaps [rsp+0x40], xmm4
000074703eddcae3  vmovaps [rsp+0x50], xmm5
000074703eddcae9  vmovaps [rsp+0x60], xmm6
000074703eddcaef  vmovaps [rsp+0x70], xmm8
000074703eddcaf5  vmovaps [rsp+0x80], xmm9
000074703eddcafe  vmovaps [rsp+0x90], xmm10
000074703eddcb07  vmovaps [rsp+0xA0], xmm11
000074703eddcb10  vmovaps [rsp+0xB0], xmm12
000074703eddcb19  vmovaps [rsp+0xC0], xmm13
000074703eddcb22  vmovaps [rsp+0xD0], xmm14
000074703eddcb2b  vmovaps [rsp+0xE0], xmm15
000074703eddcb34  sub rsp, 0x30
000074703eddcb38  movaps [rsp], xmm7
000074703eddcb3c  movaps [rsp+0x10], xmm9
000074703eddcb42  movaps [rsp+0x20], xmm15
000074703eddcb48  lea rdi, [rsp]
000074703eddcb4c  mov esi, 0x00
000074703eddcb51  mov rax, 0x5D9974CCC530
000074703eddcb5b  call rax
000074703eddcb5d  movaps xmm7, [rsp]
000074703eddcb61  add rsp, 0x30
000074703eddcb65  vmovaps xmm0, [rsp]
000074703eddcb6a  vmovaps xmm1, [rsp+0x10]
000074703eddcb70  vmovaps xmm2, [rsp+0x20]
000074703eddcb76  vmovaps xmm3, [rsp+0x30]
000074703eddcb7c  vmovaps xmm4, [rsp+0x40]
000074703eddcb82  vmovaps xmm5, [rsp+0x50]
000074703eddcb88  vmovaps xmm6, [rsp+0x60]
000074703eddcb8e  vmovaps xmm8, [rsp+0x70]
000074703eddcb94  vmovaps xmm9, [rsp+0x80]
000074703eddcb9d  vmovaps xmm10, [rsp+0x90]
000074703eddcba6  vmovaps xmm11, [rsp+0xA0]
000074703eddcbaf  vmovaps xmm12, [rsp+0xB0]
000074703eddcbb8  vmovaps xmm13, [rsp+0xC0]
000074703eddcbc1  vmovaps xmm14, [rsp+0xD0]
000074703eddcbca  vmovaps xmm15, [rsp+0xE0]
000074703eddcbd3  add rsp, 0xF0
000074703eddcbda  pop r11
000074703eddcbdc  pop r10
000074703eddcbde  pop r9
000074703eddcbe0  pop r8
000074703eddcbe2  pop rsi
000074703eddcbe3  pop rdi
000074703eddcbe4  pop rdx
000074703eddcbe5  pop rcx
000074703eddcbe6  pop rax
000074703eddcbe7  add rsp, 0x08
000074703eddcbeb  jmp 0x000074703EDDBB75
000074703eddcbf0  sub rsp, 0x08
000074703eddcbf4  push rax
000074703eddcbf5  push rcx
000074703eddcbf6  push rdx
000074703eddcbf7  push rdi
000074703eddcbf8  push rsi
000074703eddcbf9  push r8
000074703eddcbfb  push r9
000074703eddcbfd  push r10
000074703eddcbff  push r11
000074703eddcc01  sub rsp, 0xF0
000074703eddcc08  vmovaps [rsp], xmm0
000074703eddcc0d  vmovaps [rsp+0x10], xmm1
000074703eddcc13  vmovaps [rsp+0x20], xmm2
000074703eddcc19  vmovaps [rsp+0x30], xmm3
000074703eddcc1f  vmovaps [rsp+0x40], xmm4
000074703eddcc25  vmovaps [rsp+0x50], xmm5
000074703eddcc2b  vmovaps [rsp+0x60], xmm6
000074703eddcc31  vmovaps [rsp+0x70], xmm7
000074703eddcc37  vmovaps [rsp+0x80], xmm8
000074703eddcc40  vmovaps [rsp+0x90], xmm10
000074703eddcc49  vmovaps [rsp+0xA0], xmm11
000074703eddcc52  vmovaps [rsp+0xB0], xmm12
000074703eddcc5b  vmovaps [rsp+0xC0], xmm13
000074703eddcc64  vmovaps [rsp+0xD0], xmm14
000074703eddcc6d  vmovaps [rsp+0xE0], xmm15
000074703eddcc76  sub rsp, 0x30
000074703eddcc7a  movaps [rsp], xmm9
000074703eddcc7f  movaps [rsp+0x10], xmm12
000074703eddcc85  movaps [rsp+0x20], xmm10
000074703eddcc8b  lea rdi, [rsp]
000074703eddcc8f  mov esi, 0x00
000074703eddcc94  mov rax, 0x5D9974CCC530
000074703eddcc9e  call rax
000074703eddcca0  movaps xmm9, [rsp]
000074703eddcca5  add rsp, 0x30
000074703eddcca9  vmovaps xmm0, [rsp]
000074703eddccae  vmovaps xmm1, [rsp+0x10]
000074703eddccb4  vmovaps xmm2, [rsp+0x20]
000074703eddccba  vmovaps xmm3, [rsp+0x30]
000074703eddccc0  vmovaps xmm4, [rsp+0x40]
000074703eddccc6  vmovaps xmm5, [rsp+0x50]
000074703eddcccc  vmovaps xmm6, [rsp+0x60]
000074703eddccd2  vmovaps xmm7, [rsp+0x70]
000074703eddccd8  vmovaps xmm8, [rsp+0x80]
000074703eddcce1  vmovaps xmm10, [rsp+0x90]
000074703eddccea  vmovaps xmm11, [rsp+0xA0]
000074703eddccf3  vmovaps xmm12, [rsp+0xB0]
000074703eddccfc  vmovaps xmm13, [rsp+0xC0]
000074703eddcd05  vmovaps xmm14, [rsp+0xD0]
000074703eddcd0e  vmovaps xmm15, [rsp+0xE0]
000074703eddcd17  add rsp, 0xF0
000074703eddcd1e  pop r11
000074703eddcd20  pop r10
000074703eddcd22  pop r9
000074703eddcd24  pop r8
000074703eddcd26  pop rsi
000074703eddcd27  pop rdi
000074703eddcd28  pop rdx
000074703eddcd29  pop rcx
000074703eddcd2a  pop rax
000074703eddcd2b  add rsp, 0x08
000074703eddcd2f  jmp 0x000074703EDDBB99
000074703eddcd34  sub rsp, 0x08
000074703eddcd38  push rax
000074703eddcd39  push rcx
000074703eddcd3a  push rdx
000074703eddcd3b  push rdi
000074703eddcd3c  push rsi
000074703eddcd3d  push r8
000074703eddcd3f  push r9
000074703eddcd41  push r10
000074703eddcd43  push r11
000074703eddcd45  sub rsp, 0xF0
000074703eddcd4c  vmovaps [rsp], xmm0
000074703eddcd51  vmovaps [rsp+0x10], xmm1
000074703eddcd57  vmovaps [rsp+0x20], xmm2
000074703eddcd5d  vmovaps [rsp+0x30], xmm3
000074703eddcd63  vmovaps [rsp+0x40], xmm4
000074703eddcd69  vmovaps [rsp+0x50], xmm5
000074703eddcd6f  vmovaps [rsp+0x60], xmm6
000074703eddcd75  vmovaps [rsp+0x70], xmm7
000074703eddcd7b  vmovaps [rsp+0x80], xmm8
000074703eddcd84  vmovaps [rsp+0x90], xmm9
000074703eddcd8d  vmovaps [rsp+0xA0], xmm11
000074703eddcd96  vmovaps [rsp+0xB0], xmm12
000074703eddcd9f  vmovaps [rsp+0xC0], xmm13
000074703eddcda8  vmovaps [rsp+0xD0], xmm14
000074703eddcdb1  vmovaps [rsp+0xE0], xmm15
000074703eddcdba  sub rsp, 0x30
000074703eddcdbe  movaps [rsp], xmm10
000074703eddcdc3  movaps [rsp+0x10], xmm12
000074703eddcdc9  movaps [rsp+0x20], xmm11
000074703eddcdcf  lea rdi, [rsp]
000074703eddcdd3  mov esi, 0x00
000074703eddcdd8  mov rax, 0x5D9974CCC530
000074703eddcde2  call rax
000074703eddcde4  movaps xmm10, [rsp]
000074703eddcde9  add rsp, 0x30
000074703eddcded  vmovaps xmm0, [rsp]
000074703eddcdf2  vmovaps xmm1, [rsp+0x10]
000074703eddcdf8  vmovaps xmm2, [rsp+0x20]
000074703eddcdfe  vmovaps xmm3, [rsp+0x30]
000074703eddce04  vmovaps xmm4, [rsp+0x40]
000074703eddce0a  vmovaps xmm5, [rsp+0x50]
000074703eddce10  vmovaps xmm6, [rsp+0x60]
000074703eddce16  vmovaps xmm7, [rsp+0x70]
000074703eddce1c  vmovaps xmm8, [rsp+0x80]
000074703eddce25  vmovaps xmm9, [rsp+0x90]
000074703eddce2e  vmovaps xmm11, [rsp+0xA0]
000074703eddce37  vmovaps xmm12, [rsp+0xB0]
000074703eddce40  vmovaps xmm13, [rsp+0xC0]
000074703eddce49  vmovaps xmm14, [rsp+0xD0]
000074703eddce52  vmovaps xmm15, [rsp+0xE0]
000074703eddce5b  add rsp, 0xF0
000074703eddce62  pop r11
000074703eddce64  pop r10
000074703eddce66  pop r9
000074703eddce68  pop r8
000074703eddce6a  pop rsi
000074703eddce6b  pop rdi
000074703eddce6c  pop rdx
000074703eddce6d  pop rcx
000074703eddce6e  pop rax
000074703eddce6f  add rsp, 0x08
000074703eddce73  jmp 0x000074703EDDBBB3
000074703eddce78  sub rsp, 0x08
000074703eddce7c  push rax
000074703eddce7d  push rcx
000074703eddce7e  push rdx
000074703eddce7f  push rdi
000074703eddce80  push rsi
000074703eddce81  push r8
000074703eddce83  push r9
000074703eddce85  push r10
000074703eddce87  push r11
000074703eddce89  sub rsp, 0xF0
000074703eddce90  vmovaps [rsp], xmm0
000074703eddce95  vmovaps [rsp+0x10], xmm1
000074703eddce9b  vmovaps [rsp+0x20], xmm2
000074703eddcea1  vmovaps [rsp+0x30], xmm3
000074703eddcea7  vmovaps [rsp+0x40], xmm4
000074703eddcead  vmovaps [rsp+0x50], xmm5
000074703eddceb3  vmovaps [rsp+0x60], xmm7
000074703eddceb9  vmovaps [rsp+0x70], xmm8
000074703eddcebf  vmovaps [rsp+0x80], xmm9
000074703eddcec8  vmovaps [rsp+0x90], xmm10
000074703eddced1  vmovaps [rsp+0xA0], xmm11
000074703eddceda  vmovaps [rsp+0xB0], xmm12
000074703eddcee3  vmovaps [rsp+0xC0], xmm13
000074703eddceec  vmovaps [rsp+0xD0], xmm14
000074703eddcef5  vmovaps [rsp+0xE0], xmm15
000074703eddcefe  sub rsp, 0x30
000074703eddcf02  movaps [rsp], xmm6
000074703eddcf06  movaps [rsp+0x10], xmm12
000074703eddcf0c  movaps [rsp+0x20], xmm11
000074703eddcf12  lea rdi, [rsp]
000074703eddcf16  mov esi, 0x00
000074703eddcf1b  mov rax, 0x5D9974CCC530
000074703eddcf25  call rax
000074703eddcf27  movaps xmm6, [rsp]
000074703eddcf2b  add rsp, 0x30
000074703eddcf2f  vmovaps xmm0, [rsp]
000074703eddcf34  vmovaps xmm1, [rsp+0x10]
000074703eddcf3a  vmovaps xmm2, [rsp+0x20]
000074703eddcf40  vmovaps xmm3, [rsp+0x30]
000074703eddcf46  vmovaps xmm4, [rsp+0x40]
000074703eddcf4c  vmovaps xmm5, [rsp+0x50]
000074703eddcf52  vmovaps xmm7, [rsp+0x60]
000074703eddcf58  vmovaps xmm8, [rsp+0x70]
000074703eddcf5e  vmovaps xmm9, [rsp+0x80]
000074703eddcf67  vmovaps xmm10, [rsp+0x90]
000074703eddcf70  vmovaps xmm11, [rsp+0xA0]
000074703eddcf79  vmovaps xmm12, [rsp+0xB0]
000074703eddcf82  vmovaps xmm13, [rsp+0xC0]
000074703eddcf8b  vmovaps xmm14, [rsp+0xD0]
000074703eddcf94  vmovaps xmm15, [rsp+0xE0]
000074703eddcf9d  add rsp, 0xF0
000074703eddcfa4  pop r11
000074703eddcfa6  pop r10
000074703eddcfa8  pop r9
000074703eddcfaa  pop r8
000074703eddcfac  pop rsi
000074703eddcfad  pop rdi
000074703eddcfae  pop rdx
000074703eddcfaf  pop rcx
000074703eddcfb0  pop rax
000074703eddcfb1  add rsp, 0x08
000074703eddcfb5  jmp 0x000074703EDDBBD4
000074703eddcfba  sub rsp, 0x08
000074703eddcfbe  push rax
000074703eddcfbf  push rcx
000074703eddcfc0  push rdx
000074703eddcfc1  push rdi
000074703eddcfc2  push rsi
000074703eddcfc3  push r8
000074703eddcfc5  push r9
000074703eddcfc7  push r10
000074703eddcfc9  push r11
000074703eddcfcb  sub rsp, 0xF0
000074703eddcfd2  vmovaps [rsp], xmm0
000074703eddcfd7  vmovaps [rsp+0x10], xmm1
000074703eddcfdd  vmovaps [rsp+0x20], xmm2
000074703eddcfe3  vmovaps [rsp+0x30], xmm4
000074703eddcfe9  vmovaps [rsp+0x40], xmm5
000074703eddcfef  vmovaps [rsp+0x50], xmm6
000074703eddcff5  vmovaps [rsp+0x60], xmm7
000074703eddcffb  vmovaps [rsp+0x70], xmm8
000074703eddd001  vmovaps [rsp+0x80], xmm9
000074703eddd00a  vmovaps [rsp+0x90], xmm10
000074703eddd013  vmovaps [rsp+0xA0], xmm11
000074703eddd01c  vmovaps [rsp+0xB0], xmm12
000074703eddd025  vmovaps [rsp+0xC0], xmm13
000074703eddd02e  vmovaps [rsp+0xD0], xmm14
000074703eddd037  vmovaps [rsp+0xE0], xmm15
000074703eddd040  sub rsp, 0x30
000074703eddd044  movaps [rsp], xmm3
000074703eddd048  movaps [rsp+0x10], xmm5
000074703eddd04d  movaps [rsp+0x20], xmm4
000074703eddd052  lea rdi, [rsp]
000074703eddd056  mov esi, 0x00
000074703eddd05b  mov rax, 0x5D9974CCC530
000074703eddd065  call rax
000074703eddd067  movaps xmm3, [rsp]
000074703eddd06b  add rsp, 0x30
000074703eddd06f  vmovaps xmm0, [rsp]
000074703eddd074  vmovaps xmm1, [rsp+0x10]
000074703eddd07a  vmovaps xmm2, [rsp+0x20]
000074703eddd080  vmovaps xmm4, [rsp+0x30]
000074703eddd086  vmovaps xmm5, [rsp+0x40]
000074703eddd08c  vmovaps xmm6, [rsp+0x50]
000074703eddd092  vmovaps xmm7, [rsp+0x60]
000074703eddd098  vmovaps xmm8, [rsp+0x70]
000074703eddd09e  vmovaps xmm9, [rsp+0x80]
000074703eddd0a7  vmovaps xmm10, [rsp+0x90]
000074703eddd0b0  vmovaps xmm11, [rsp+0xA0]
000074703eddd0b9  vmovaps xmm12, [rsp+0xB0]
000074703eddd0c2  vmovaps xmm13, [rsp+0xC0]
000074703eddd0cb  vmovaps xmm14, [rsp+0xD0]
000074703eddd0d4  vmovaps xmm15, [rsp+0xE0]
000074703eddd0dd  add rsp, 0xF0
000074703eddd0e4  pop r11
000074703eddd0e6  pop r10
000074703eddd0e8  pop r9
000074703eddd0ea  pop r8
000074703eddd0ec  pop rsi
000074703eddd0ed  pop rdi
000074703eddd0ee  pop rdx
000074703eddd0ef  pop rcx
000074703eddd0f0  pop rax
000074703eddd0f1  add rsp, 0x08
000074703eddd0f5  jmp 0x000074703EDDBC35
000074703eddd0fa  sub rsp, 0x08
000074703eddd0fe  push rax
000074703eddd0ff  push rcx
000074703eddd100  push rdx
000074703eddd101  push rdi
000074703eddd102  push rsi
000074703eddd103  push r8
000074703eddd105  push r9
000074703eddd107  push r10
000074703eddd109  push r11
000074703eddd10b  sub rsp, 0xF0
000074703eddd112  vmovaps [rsp], xmm0
000074703eddd117  vmovaps [rsp+0x10], xmm1
000074703eddd11d  vmovaps [rsp+0x20], xmm2
000074703eddd123  vmovaps [rsp+0x30], xmm3
000074703eddd129  vmovaps [rsp+0x40], xmm4
000074703eddd12f  vmovaps [rsp+0x50], xmm6
000074703eddd135  vmovaps [rsp+0x60], xmm7
000074703eddd13b  vmovaps [rsp+0x70], xmm8
000074703eddd141  vmovaps [rsp+0x80], xmm9
000074703eddd14a  vmovaps [rsp+0x90], xmm10
000074703eddd153  vmovaps [rsp+0xA0], xmm11
000074703eddd15c  vmovaps [rsp+0xB0], xmm12
000074703eddd165  vmovaps [rsp+0xC0], xmm13
000074703eddd16e  vmovaps [rsp+0xD0], xmm14
000074703eddd177  vmovaps [rsp+0xE0], xmm15
000074703eddd180  sub rsp, 0x30
000074703eddd184  movaps [rsp], xmm5
000074703eddd188  movaps [rsp+0x10], xmm8
000074703eddd18e  movaps [rsp+0x20], xmm15
000074703eddd194  lea rdi, [rsp]
000074703eddd198  mov esi, 0x00
000074703eddd19d  mov rax, 0x5D9974CCC530
000074703eddd1a7  call rax
000074703eddd1a9  movaps xmm5, [rsp]
000074703eddd1ad  add rsp, 0x30
000074703eddd1b1  vmovaps xmm0, [rsp]
000074703eddd1b6  vmovaps xmm1, [rsp+0x10]
000074703eddd1bc  vmovaps xmm2, [rsp+0x20]
000074703eddd1c2  vmovaps xmm3, [rsp+0x30]
000074703eddd1c8  vmovaps xmm4, [rsp+0x40]
000074703eddd1ce  vmovaps xmm6, [rsp+0x50]
000074703eddd1d4  vmovaps xmm7, [rsp+0x60]
000074703eddd1da  vmovaps xmm8, [rsp+0x70]
000074703eddd1e0  vmovaps xmm9, [rsp+0x80]
000074703eddd1e9  vmovaps xmm10, [rsp+0x90]
000074703eddd1f2  vmovaps xmm11, [rsp+0xA0]
000074703eddd1fb  vmovaps xmm12, [rsp+0xB0]
000074703eddd204  vmovaps xmm13, [rsp+0xC0]
000074703eddd20d  vmovaps xmm14, [rsp+0xD0]
000074703eddd216  vmovaps xmm15, [rsp+0xE0]
000074703eddd21f  add rsp, 0xF0
000074703eddd226  pop r11
000074703eddd228  pop r10
000074703eddd22a  pop r9
000074703eddd22c  pop r8
000074703eddd22e  pop rsi
000074703eddd22f  pop rdi
000074703eddd230  pop rdx
000074703eddd231  pop rcx
000074703eddd232  pop rax
000074703eddd233  add rsp, 0x08
000074703eddd237  jmp 0x000074703EDDBC73
000074703eddd23c  sub rsp, 0x08
000074703eddd240  push rax
000074703eddd241  push rcx
000074703eddd242  push rdx
000074703eddd243  push rdi
000074703eddd244  push rsi
000074703eddd245  push r8
000074703eddd247  push r9
000074703eddd249  push r10
000074703eddd24b  push r11
000074703eddd24d  sub rsp, 0xF0
000074703eddd254  vmovaps [rsp], xmm0
000074703eddd259  vmovaps [rsp+0x10], xmm1
000074703eddd25f  vmovaps [rsp+0x20], xmm2
000074703eddd265  vmovaps [rsp+0x30], xmm3
000074703eddd26b  vmovaps [rsp+0x40], xmm5
000074703eddd271  vmovaps [rsp+0x50], xmm6
000074703eddd277  vmovaps [rsp+0x60], xmm7
000074703eddd27d  vmovaps [rsp+0x70], xmm8
000074703eddd283  vmovaps [rsp+0x80], xmm9
000074703eddd28c  vmovaps [rsp+0x90], xmm10
000074703eddd295  vmovaps [rsp+0xA0], xmm11
000074703eddd29e  vmovaps [rsp+0xB0], xmm12
000074703eddd2a7  vmovaps [rsp+0xC0], xmm13
000074703eddd2b0  vmovaps [rsp+0xD0], xmm14
000074703eddd2b9  vmovaps [rsp+0xE0], xmm15
000074703eddd2c2  sub rsp, 0x30
000074703eddd2c6  movaps [rsp], xmm4
000074703eddd2ca  movaps [rsp+0x10], xmm9
000074703eddd2d0  movaps [rsp+0x20], xmm8
000074703eddd2d6  lea rdi, [rsp]
000074703eddd2da  mov esi, 0x00
000074703eddd2df  mov rax, 0x5D9974CCC530
000074703eddd2e9  call rax
000074703eddd2eb  movaps xmm4, [rsp]
000074703eddd2ef  add rsp, 0x30
000074703eddd2f3  vmovaps xmm0, [rsp]
000074703eddd2f8  vmovaps xmm1, [rsp+0x10]
000074703eddd2fe  vmovaps xmm2, [rsp+0x20]
000074703eddd304  vmovaps xmm3, [rsp+0x30]
000074703eddd30a  vmovaps xmm5, [rsp+0x40]
000074703eddd310  vmovaps xmm6, [rsp+0x50]
000074703eddd316  vmovaps xmm7, [rsp+0x60]
000074703eddd31c  vmovaps xmm8, [rsp+0x70]
000074703eddd322  vmovaps xmm9, [rsp+0x80]
000074703eddd32b  vmovaps xmm10, [rsp+0x90]
000074703eddd334  vmovaps xmm11, [rsp+0xA0]
000074703eddd33d  vmovaps xmm12, [rsp+0xB0]
000074703eddd346  vmovaps xmm13, [rsp+0xC0]
000074703eddd34f  vmovaps xmm14, [rsp+0xD0]
000074703eddd358  vmovaps xmm15, [rsp+0xE0]
000074703eddd361  add rsp, 0xF0
000074703eddd368  pop r11
000074703eddd36a  pop r10
000074703eddd36c  pop r9
000074703eddd36e  pop r8
000074703eddd370  pop rsi
000074703eddd371  pop rdi
000074703eddd372  pop rdx
000074703eddd373  pop rcx
000074703eddd374  pop rax
000074703eddd375  add rsp, 0x08
000074703eddd379  jmp 0x000074703EDDBC94
000074703eddd37e  sub rsp, 0x08
000074703eddd382  push rax
000074703eddd383  push rcx
000074703eddd384  push rdx
000074703eddd385  push rdi
000074703eddd386  push rsi
000074703eddd387  push r8
000074703eddd389  push r9
000074703eddd38b  push r10
000074703eddd38d  push r11
000074703eddd38f  sub rsp, 0xF0
000074703eddd396  vmovaps [rsp], xmm0
000074703eddd39b  vmovaps [rsp+0x10], xmm1
000074703eddd3a1  vmovaps [rsp+0x20], xmm2
000074703eddd3a7  vmovaps [rsp+0x30], xmm3
000074703eddd3ad  vmovaps [rsp+0x40], xmm4
000074703eddd3b3  vmovaps [rsp+0x50], xmm5
000074703eddd3b9  vmovaps [rsp+0x60], xmm6
000074703eddd3bf  vmovaps [rsp+0x70], xmm7
000074703eddd3c5  vmovaps [rsp+0x80], xmm8
000074703eddd3ce  vmovaps [rsp+0x90], xmm10
000074703eddd3d7  vmovaps [rsp+0xA0], xmm11
000074703eddd3e0  vmovaps [rsp+0xB0], xmm12
000074703eddd3e9  vmovaps [rsp+0xC0], xmm13
000074703eddd3f2  vmovaps [rsp+0xD0], xmm14
000074703eddd3fb  vmovaps [rsp+0xE0], xmm15
000074703eddd404  sub rsp, 0x30
000074703eddd408  movaps [rsp], xmm9
000074703eddd40d  movaps [rsp+0x10], xmm10
000074703eddd413  movaps [rsp+0x20], xmm8
000074703eddd419  lea rdi, [rsp]
000074703eddd41d  mov esi, 0x00
000074703eddd422  mov rax, 0x5D9974CCC530
000074703eddd42c  call rax
000074703eddd42e  movaps xmm9, [rsp]
000074703eddd433  add rsp, 0x30
000074703eddd437  vmovaps xmm0, [rsp]
000074703eddd43c  vmovaps xmm1, [rsp+0x10]
000074703eddd442  vmovaps xmm2, [rsp+0x20]
000074703eddd448  vmovaps xmm3, [rsp+0x30]
000074703eddd44e  vmovaps xmm4, [rsp+0x40]
000074703eddd454  vmovaps xmm5, [rsp+0x50]
000074703eddd45a  vmovaps xmm6, [rsp+0x60]
000074703eddd460  vmovaps xmm7, [rsp+0x70]
000074703eddd466  vmovaps xmm8, [rsp+0x80]
000074703eddd46f  vmovaps xmm10, [rsp+0x90]
000074703eddd478  vmovaps xmm11, [rsp+0xA0]
000074703eddd481  vmovaps xmm12, [rsp+0xB0]
000074703eddd48a  vmovaps xmm13, [rsp+0xC0]
000074703eddd493  vmovaps xmm14, [rsp+0xD0]
000074703eddd49c  vmovaps xmm15, [rsp+0xE0]
000074703eddd4a5  add rsp, 0xF0
000074703eddd4ac  pop r11
000074703eddd4ae  pop r10
000074703eddd4b0  pop r9
000074703eddd4b2  pop r8
000074703eddd4b4  pop rsi
000074703eddd4b5  pop rdi
000074703eddd4b6  pop rdx
000074703eddd4b7  pop rcx
000074703eddd4b8  pop rax
000074703eddd4b9  add rsp, 0x08
000074703eddd4bd  jmp 0x000074703EDDBCAE
000074703eddd4c2  call 0x000074703ECB52F0
000074703eddd4c7  jmp 0x000074703EDDBDC8
000074703eddd4cc  call 0x000074703ECB52F0
000074703eddd4d1  jmp 0x000074703EDDBDDE
000074703eddd4d6  sub rsp, 0x08
000074703eddd4da  push rax
000074703eddd4db  push rcx
000074703eddd4dc  push rdx
000074703eddd4dd  push rdi
000074703eddd4de  push rsi
000074703eddd4df  push r8
000074703eddd4e1  push r9
000074703eddd4e3  push r10
000074703eddd4e5  push r11
000074703eddd4e7  sub rsp, 0xF0
000074703eddd4ee  vmovaps [rsp], xmm0
000074703eddd4f3  vmovaps [rsp+0x10], xmm2
000074703eddd4f9  vmovaps [rsp+0x20], xmm3
000074703eddd4ff  vmovaps [rsp+0x30], xmm4
000074703eddd505  vmovaps [rsp+0x40], xmm5
000074703eddd50b  vmovaps [rsp+0x50], xmm6
000074703eddd511  vmovaps [rsp+0x60], xmm7
000074703eddd517  vmovaps [rsp+0x70], xmm8
000074703eddd51d  vmovaps [rsp+0x80], xmm9
000074703eddd526  vmovaps [rsp+0x90], xmm10
000074703eddd52f  vmovaps [rsp+0xA0], xmm11
000074703eddd538  vmovaps [rsp+0xB0], xmm12
000074703eddd541  vmovaps [rsp+0xC0], xmm13
000074703eddd54a  vmovaps [rsp+0xD0], xmm14
000074703eddd553  vmovaps [rsp+0xE0], xmm15
000074703eddd55c  sub rsp, 0x30
000074703eddd560  movaps [rsp], xmm1
000074703eddd564  movaps [rsp+0x10], xmm6
000074703eddd569  movaps [rsp+0x20], xmm15
000074703eddd56f  lea rdi, [rsp]
000074703eddd573  mov esi, 0x00
000074703eddd578  mov rax, 0x5D9974CCC530
000074703eddd582  call rax
000074703eddd584  movaps xmm1, [rsp]
000074703eddd588  add rsp, 0x30
000074703eddd58c  vmovaps xmm0, [rsp]
000074703eddd591  vmovaps xmm2, [rsp+0x10]
000074703eddd597  vmovaps xmm3, [rsp+0x20]
000074703eddd59d  vmovaps xmm4, [rsp+0x30]
000074703eddd5a3  vmovaps xmm5, [rsp+0x40]
000074703eddd5a9  vmovaps xmm6, [rsp+0x50]
000074703eddd5af  vmovaps xmm7, [rsp+0x60]
000074703eddd5b5  vmovaps xmm8, [rsp+0x70]
000074703eddd5bb  vmovaps xmm9, [rsp+0x80]
000074703eddd5c4  vmovaps xmm10, [rsp+0x90]
000074703eddd5cd  vmovaps xmm11, [rsp+0xA0]
000074703eddd5d6  vmovaps xmm12, [rsp+0xB0]
000074703eddd5df  vmovaps xmm13, [rsp+0xC0]
000074703eddd5e8  vmovaps xmm14, [rsp+0xD0]
000074703eddd5f1  vmovaps xmm15, [rsp+0xE0]
000074703eddd5fa  add rsp, 0xF0
000074703eddd601  pop r11
000074703eddd603  pop r10
000074703eddd605  pop r9
000074703eddd607  pop r8
000074703eddd609  pop rsi
000074703eddd60a  pop rdi
000074703eddd60b  pop rdx
000074703eddd60c  pop rcx
000074703eddd60d  pop rax
000074703eddd60e  add rsp, 0x08
000074703eddd612  jmp 0x000074703EDDBE1B
000074703eddd617  call 0x000074703ECC4620
000074703eddd61c  jmp 0x000074703EDDBE28
000074703eddd621  sub rsp, 0x08
000074703eddd625  push rax
000074703eddd626  push rcx
000074703eddd627  push rdx
000074703eddd628  push rdi
000074703eddd629  push rsi
000074703eddd62a  push r8
000074703eddd62c  push r9
000074703eddd62e  push r10
000074703eddd630  push r11
000074703eddd632  sub rsp, 0xF0
000074703eddd639  vmovaps [rsp], xmm0
000074703eddd63e  vmovaps [rsp+0x10], xmm1
000074703eddd644  vmovaps [rsp+0x20], xmm2
000074703eddd64a  vmovaps [rsp+0x30], xmm3
000074703eddd650  vmovaps [rsp+0x40], xmm4
000074703eddd656  vmovaps [rsp+0x50], xmm5
000074703eddd65c  vmovaps [rsp+0x60], xmm6
000074703eddd662  vmovaps [rsp+0x70], xmm7
000074703eddd668  vmovaps [rsp+0x80], xmm8
000074703eddd671  vmovaps [rsp+0x90], xmm9
000074703eddd67a  vmovaps [rsp+0xA0], xmm10
000074703eddd683  vmovaps [rsp+0xB0], xmm11
000074703eddd68c  vmovaps [rsp+0xC0], xmm12
000074703eddd695  vmovaps [rsp+0xD0], xmm13
000074703eddd69e  vmovaps [rsp+0xE0], xmm15
000074703eddd6a7  sub rsp, 0x30
000074703eddd6ab  movaps [rsp], xmm14
000074703eddd6b0  movaps [rsp+0x10], xmm4
000074703eddd6b5  movaps [rsp+0x20], xmm3
000074703eddd6ba  lea rdi, [rsp]
000074703eddd6be  mov esi, 0x00
000074703eddd6c3  mov rax, 0x5D9974CCC530
000074703eddd6cd  call rax
000074703eddd6cf  movaps xmm14, [rsp]
000074703eddd6d4  add rsp, 0x30
000074703eddd6d8  vmovaps xmm0, [rsp]
000074703eddd6dd  vmovaps xmm1, [rsp+0x10]
000074703eddd6e3  vmovaps xmm2, [rsp+0x20]
000074703eddd6e9  vmovaps xmm3, [rsp+0x30]
000074703eddd6ef  vmovaps xmm4, [rsp+0x40]
000074703eddd6f5  vmovaps xmm5, [rsp+0x50]
000074703eddd6fb  vmovaps xmm6, [rsp+0x60]
000074703eddd701  vmovaps xmm7, [rsp+0x70]
000074703eddd707  vmovaps xmm8, [rsp+0x80]
000074703eddd710  vmovaps xmm9, [rsp+0x90]
000074703eddd719  vmovaps xmm10, [rsp+0xA0]
000074703eddd722  vmovaps xmm11, [rsp+0xB0]
000074703eddd72b  vmovaps xmm12, [rsp+0xC0]
000074703eddd734  vmovaps xmm13, [rsp+0xD0]
000074703eddd73d  vmovaps xmm15, [rsp+0xE0]
000074703eddd746  add rsp, 0xF0
000074703eddd74d  pop r11
000074703eddd74f  pop r10
000074703eddd751  pop r9
000074703eddd753  pop r8
000074703eddd755  pop rsi
000074703eddd756  pop rdi
000074703eddd757  pop rdx
000074703eddd758  pop rcx
000074703eddd759  pop rax
000074703eddd75a  add rsp, 0x08
000074703eddd75e  jmp 0x000074703EDDBE42
000074703eddd763  sub rsp, 0x08
000074703eddd767  push rax
000074703eddd768  push rcx
000074703eddd769  push rdx
000074703eddd76a  push rdi
000074703eddd76b  push rsi
000074703eddd76c  push r8
000074703eddd76e  push r9
000074703eddd770  push r10
000074703eddd772  push r11
000074703eddd774  sub rsp, 0xF0
000074703eddd77b  vmovaps [rsp], xmm0
000074703eddd780  vmovaps [rsp+0x10], xmm1
000074703eddd786  vmovaps [rsp+0x20], xmm2
000074703eddd78c  vmovaps [rsp+0x30], xmm3
000074703eddd792  vmovaps [rsp+0x40], xmm4
000074703eddd798  vmovaps [rsp+0x50], xmm5
000074703eddd79e  vmovaps [rsp+0x60], xmm7
000074703eddd7a4  vmovaps [rsp+0x70], xmm8
000074703eddd7aa  vmovaps [rsp+0x80], xmm9
000074703eddd7b3  vmovaps [rsp+0x90], xmm10
000074703eddd7bc  vmovaps [rsp+0xA0], xmm11
000074703eddd7c5  vmovaps [rsp+0xB0], xmm12
000074703eddd7ce  vmovaps [rsp+0xC0], xmm13
000074703eddd7d7  vmovaps [rsp+0xD0], xmm14
000074703eddd7e0  vmovaps [rsp+0xE0], xmm15
000074703eddd7e9  sub rsp, 0x30
000074703eddd7ed  movaps [rsp], xmm6
000074703eddd7f1  movaps [rsp+0x10], xmm9
000074703eddd7f7  movaps [rsp+0x20], xmm7
000074703eddd7fc  lea rdi, [rsp]
000074703eddd800  mov esi, 0x00
000074703eddd805  mov rax, 0x5D9974CCC530
000074703eddd80f  call rax
000074703eddd811  movaps xmm6, [rsp]
000074703eddd815  add rsp, 0x30
000074703eddd819  vmovaps xmm0, [rsp]
000074703eddd81e  vmovaps xmm1, [rsp+0x10]
000074703eddd824  vmovaps xmm2, [rsp+0x20]
000074703eddd82a  vmovaps xmm3, [rsp+0x30]
000074703eddd830  vmovaps xmm4, [rsp+0x40]
000074703eddd836  vmovaps xmm5, [rsp+0x50]
000074703eddd83c  vmovaps xmm7, [rsp+0x60]
000074703eddd842  vmovaps xmm8, [rsp+0x70]
000074703eddd848  vmovaps xmm9, [rsp+0x80]
000074703eddd851  vmovaps xmm10, [rsp+0x90]
000074703eddd85a  vmovaps xmm11, [rsp+0xA0]
000074703eddd863  vmovaps xmm12, [rsp+0xB0]
000074703eddd86c  vmovaps xmm13, [rsp+0xC0]
000074703eddd875  vmovaps xmm14, [rsp+0xD0]
000074703eddd87e  vmovaps xmm15, [rsp+0xE0]
000074703eddd887  add rsp, 0xF0
000074703eddd88e  pop r11
000074703eddd890  pop r10
000074703eddd892  pop r9
000074703eddd894  pop r8
000074703eddd896  pop rsi
000074703eddd897  pop rdi
000074703eddd898  pop rdx
000074703eddd899  pop rcx
000074703eddd89a  pop rax
000074703eddd89b  add rsp, 0x08
000074703eddd89f  jmp 0x000074703EDDBE5A
000074703eddd8a4  sub rsp, 0x08
000074703eddd8a8  push rax
000074703eddd8a9  push rcx
000074703eddd8aa  push rdx
000074703eddd8ab  push rdi
000074703eddd8ac  push rsi
000074703eddd8ad  push r8
000074703eddd8af  push r9
000074703eddd8b1  push r10
000074703eddd8b3  push r11
000074703eddd8b5  sub rsp, 0xF0
000074703eddd8bc  vmovaps [rsp], xmm0
000074703eddd8c1  vmovaps [rsp+0x10], xmm1
000074703eddd8c7  vmovaps [rsp+0x20], xmm2
000074703eddd8cd  vmovaps [rsp+0x30], xmm3
000074703eddd8d3  vmovaps [rsp+0x40], xmm4
000074703eddd8d9  vmovaps [rsp+0x50], xmm5
000074703eddd8df  vmovaps [rsp+0x60], xmm6
000074703eddd8e5  vmovaps [rsp+0x70], xmm8
000074703eddd8eb  vmovaps [rsp+0x80], xmm9
000074703eddd8f4  vmovaps [rsp+0x90], xmm10
000074703eddd8fd  vmovaps [rsp+0xA0], xmm11
000074703eddd906  vmovaps [rsp+0xB0], xmm12
000074703eddd90f  vmovaps [rsp+0xC0], xmm13
000074703eddd918  vmovaps [rsp+0xD0], xmm14
000074703eddd921  vmovaps [rsp+0xE0], xmm15
000074703eddd92a  sub rsp, 0x30
000074703eddd92e  movaps [rsp], xmm7
000074703eddd932  movaps [rsp+0x10], xmm4
000074703eddd937  movaps [rsp+0x20], xmm9
000074703eddd93d  lea rdi, [rsp]
000074703eddd941  mov esi, 0x00
000074703eddd946  mov rax, 0x5D9974CCC530
000074703eddd950  call rax
000074703eddd952  movaps xmm7, [rsp]
000074703eddd956  add rsp, 0x30
000074703eddd95a  vmovaps xmm0, [rsp]
000074703eddd95f  vmovaps xmm1, [rsp+0x10]
000074703eddd965  vmovaps xmm2, [rsp+0x20]
000074703eddd96b  vmovaps xmm3, [rsp+0x30]
000074703eddd971  vmovaps xmm4, [rsp+0x40]
000074703eddd977  vmovaps xmm5, [rsp+0x50]
000074703eddd97d  vmovaps xmm6, [rsp+0x60]
000074703eddd983  vmovaps xmm8, [rsp+0x70]
000074703eddd989  vmovaps xmm9, [rsp+0x80]
000074703eddd992  vmovaps xmm10, [rsp+0x90]
000074703eddd99b  vmovaps xmm11, [rsp+0xA0]
000074703eddd9a4  vmovaps xmm12, [rsp+0xB0]
000074703eddd9ad  vmovaps xmm13, [rsp+0xC0]
000074703eddd9b6  vmovaps xmm14, [rsp+0xD0]
000074703eddd9bf  vmovaps xmm15, [rsp+0xE0]
000074703eddd9c8  add rsp, 0xF0
000074703eddd9cf  pop r11
000074703eddd9d1  pop r10
000074703eddd9d3  pop r9
000074703eddd9d5  pop r8
000074703eddd9d7  pop rsi
000074703eddd9d8  pop rdi
000074703eddd9d9  pop rdx
000074703eddd9da  pop rcx
000074703eddd9db  pop rax
000074703eddd9dc  add rsp, 0x08
000074703eddd9e0  jmp 0x000074703EDDBE87
000074703eddd9e5  sub rsp, 0x08
000074703eddd9e9  push rax
000074703eddd9ea  push rcx
000074703eddd9eb  push rdx
000074703eddd9ec  push rdi
000074703eddd9ed  push rsi
000074703eddd9ee  push r8
000074703eddd9f0  push r9
000074703eddd9f2  push r10
000074703eddd9f4  push r11
000074703eddd9f6  sub rsp, 0xF0
000074703eddd9fd  vmovaps [rsp], xmm0
000074703eddda02  vmovaps [rsp+0x10], xmm1
000074703eddda08  vmovaps [rsp+0x20], xmm2
000074703eddda0e  vmovaps [rsp+0x30], xmm3
000074703eddda14  vmovaps [rsp+0x40], xmm5
000074703eddda1a  vmovaps [rsp+0x50], xmm6
000074703eddda20  vmovaps [rsp+0x60], xmm7
000074703eddda26  vmovaps [rsp+0x70], xmm8
000074703eddda2c  vmovaps [rsp+0x80], xmm9
000074703eddda35  vmovaps [rsp+0x90], xmm10
000074703eddda3e  vmovaps [rsp+0xA0], xmm11
000074703eddda47  vmovaps [rsp+0xB0], xmm12
000074703eddda50  vmovaps [rsp+0xC0], xmm13
000074703eddda59  vmovaps [rsp+0xD0], xmm14
000074703eddda62  vmovaps [rsp+0xE0], xmm15
000074703eddda6b  sub rsp, 0x30
000074703eddda6f  movaps [rsp], xmm4
000074703eddda73  movaps [rsp+0x10], xmm15
000074703eddda79  movaps [rsp+0x20], xmm9
000074703eddda7f  lea rdi, [rsp]
000074703eddda83  mov esi, 0x00
000074703eddda88  mov rax, 0x5D9974CCC530
000074703eddda92  call rax
000074703eddda94  movaps xmm4, [rsp]
000074703eddda98  add rsp, 0x30
000074703eddda9c  vmovaps xmm0, [rsp]
000074703edddaa1  vmovaps xmm1, [rsp+0x10]
000074703edddaa7  vmovaps xmm2, [rsp+0x20]
000074703edddaad  vmovaps xmm3, [rsp+0x30]
000074703edddab3  vmovaps xmm5, [rsp+0x40]
000074703edddab9  vmovaps xmm6, [rsp+0x50]
000074703edddabf  vmovaps xmm7, [rsp+0x60]
000074703edddac5  vmovaps xmm8, [rsp+0x70]
000074703edddacb  vmovaps xmm9, [rsp+0x80]
000074703edddad4  vmovaps xmm10, [rsp+0x90]
000074703edddadd  vmovaps xmm11, [rsp+0xA0]
000074703edddae6  vmovaps xmm12, [rsp+0xB0]
000074703edddaef  vmovaps xmm13, [rsp+0xC0]
000074703edddaf8  vmovaps xmm14, [rsp+0xD0]
000074703edddb01  vmovaps xmm15, [rsp+0xE0]
000074703edddb0a  add rsp, 0xF0
000074703edddb11  pop r11
000074703edddb13  pop r10
000074703edddb15  pop r9
000074703edddb17  pop r8
000074703edddb19  pop rsi
000074703edddb1a  pop rdi
000074703edddb1b  pop rdx
000074703edddb1c  pop rcx
000074703edddb1d  pop rax
000074703edddb1e  add rsp, 0x08
000074703edddb22  jmp 0x000074703EDDBEAC
000074703edddb27  call 0x000074703ECC4620
000074703edddb2c  jmp 0x000074703EDDBEB9
000074703edddb31  sub rsp, 0x08
000074703edddb35  push rax
000074703edddb36  push rcx
000074703edddb37  push rdx
000074703edddb38  push rdi
000074703edddb39  push rsi
000074703edddb3a  push r8
000074703edddb3c  push r9
000074703edddb3e  push r10
000074703edddb40  push r11
000074703edddb42  sub rsp, 0xF0
000074703edddb49  vmovaps [rsp], xmm0
000074703edddb4e  vmovaps [rsp+0x10], xmm1
000074703edddb54  vmovaps [rsp+0x20], xmm2
000074703edddb5a  vmovaps [rsp+0x30], xmm4
000074703edddb60  vmovaps [rsp+0x40], xmm5
000074703edddb66  vmovaps [rsp+0x50], xmm6
000074703edddb6c  vmovaps [rsp+0x60], xmm7
000074703edddb72  vmovaps [rsp+0x70], xmm8
000074703edddb78  vmovaps [rsp+0x80], xmm9
000074703edddb81  vmovaps [rsp+0x90], xmm10
000074703edddb8a  vmovaps [rsp+0xA0], xmm11
000074703edddb93  vmovaps [rsp+0xB0], xmm12
000074703edddb9c  vmovaps [rsp+0xC0], xmm13
000074703edddba5  vmovaps [rsp+0xD0], xmm14
000074703edddbae  vmovaps [rsp+0xE0], xmm15
000074703edddbb7  sub rsp, 0x30
000074703edddbbb  movaps [rsp], xmm3
000074703edddbbf  movaps [rsp+0x10], xmm1
000074703edddbc4  movaps [rsp+0x20], xmm9
000074703edddbca  lea rdi, [rsp]
000074703edddbce  mov esi, 0x00
000074703edddbd3  mov rax, 0x5D9974CCC530
000074703edddbdd  call rax
000074703edddbdf  movaps xmm3, [rsp]
000074703edddbe3  add rsp, 0x30
000074703edddbe7  vmovaps xmm0, [rsp]
000074703edddbec  vmovaps xmm1, [rsp+0x10]
000074703edddbf2  vmovaps xmm2, [rsp+0x20]
000074703edddbf8  vmovaps xmm4, [rsp+0x30]
000074703edddbfe  vmovaps xmm5, [rsp+0x40]
000074703edddc04  vmovaps xmm6, [rsp+0x50]
000074703edddc0a  vmovaps xmm7, [rsp+0x60]
000074703edddc10  vmovaps xmm8, [rsp+0x70]
000074703edddc16  vmovaps xmm9, [rsp+0x80]
000074703edddc1f  vmovaps xmm10, [rsp+0x90]
000074703edddc28  vmovaps xmm11, [rsp+0xA0]
000074703edddc31  vmovaps xmm12, [rsp+0xB0]
000074703edddc3a  vmovaps xmm13, [rsp+0xC0]
000074703edddc43  vmovaps xmm14, [rsp+0xD0]
000074703edddc4c  vmovaps xmm15, [rsp+0xE0]
000074703edddc55  add rsp, 0xF0
000074703edddc5c  pop r11
000074703edddc5e  pop r10
000074703edddc60  pop r9
000074703edddc62  pop r8
000074703edddc64  pop rsi
000074703edddc65  pop rdi
000074703edddc66  pop rdx
000074703edddc67  pop rcx
000074703edddc68  pop rax
000074703edddc69  add rsp, 0x08
000074703edddc6d  jmp 0x000074703EDDBEF6
000074703edddc72  sub rsp, 0x08
000074703edddc76  push rax
000074703edddc77  push rcx
000074703edddc78  push rdx
000074703edddc79  push rdi
000074703edddc7a  push rsi
000074703edddc7b  push r8
000074703edddc7d  push r9
000074703edddc7f  push r10
000074703edddc81  push r11
000074703edddc83  sub rsp, 0xF0
000074703edddc8a  vmovaps [rsp], xmm0
000074703edddc8f  vmovaps [rsp+0x10], xmm2
000074703edddc95  vmovaps [rsp+0x20], xmm3
000074703edddc9b  vmovaps [rsp+0x30], xmm4
000074703edddca1  vmovaps [rsp+0x40], xmm5
000074703edddca7  vmovaps [rsp+0x50], xmm6
000074703edddcad  vmovaps [rsp+0x60], xmm7
000074703edddcb3  vmovaps [rsp+0x70], xmm8
000074703edddcb9  vmovaps [rsp+0x80], xmm9
000074703edddcc2  vmovaps [rsp+0x90], xmm10
000074703edddccb  vmovaps [rsp+0xA0], xmm11
000074703edddcd4  vmovaps [rsp+0xB0], xmm12
000074703edddcdd  vmovaps [rsp+0xC0], xmm13
000074703edddce6  vmovaps [rsp+0xD0], xmm14
000074703edddcef  vmovaps [rsp+0xE0], xmm15
000074703edddcf8  sub rsp, 0x30
000074703edddcfc  movaps [rsp], xmm1
000074703edddd00  movaps [rsp+0x10], xmm15
000074703edddd06  movaps [rsp+0x20], xmm9
000074703edddd0c  lea rdi, [rsp]
000074703edddd10  mov esi, 0x00
000074703edddd15  mov rax, 0x5D9974CCC530
000074703edddd1f  call rax
000074703edddd21  movaps xmm1, [rsp]
000074703edddd25  add rsp, 0x30
000074703edddd29  vmovaps xmm0, [rsp]
000074703edddd2e  vmovaps xmm2, [rsp+0x10]
000074703edddd34  vmovaps xmm3, [rsp+0x20]
000074703edddd3a  vmovaps xmm4, [rsp+0x30]
000074703edddd40  vmovaps xmm5, [rsp+0x40]
000074703edddd46  vmovaps xmm6, [rsp+0x50]
000074703edddd4c  vmovaps xmm7, [rsp+0x60]
000074703edddd52  vmovaps xmm8, [rsp+0x70]
000074703edddd58  vmovaps xmm9, [rsp+0x80]
000074703edddd61  vmovaps xmm10, [rsp+0x90]
000074703edddd6a  vmovaps xmm11, [rsp+0xA0]
000074703edddd73  vmovaps xmm12, [rsp+0xB0]
000074703edddd7c  vmovaps xmm13, [rsp+0xC0]
000074703edddd85  vmovaps xmm14, [rsp+0xD0]
000074703edddd8e  vmovaps xmm15, [rsp+0xE0]
000074703edddd97  add rsp, 0xF0
000074703edddd9e  pop r11
000074703edddda0  pop r10
000074703edddda2  pop r9
000074703edddda4  pop r8
000074703edddda6  pop rsi
000074703edddda7  pop rdi
000074703edddda8  pop rdx
000074703edddda9  pop rcx
000074703eddddaa  pop rax
000074703eddddab  add rsp, 0x08
000074703eddddaf  jmp 0x000074703EDDBF7E
000074703eddddb4  call 0x000074703ECC4620
000074703eddddb9  jmp 0x000074703EDDBF8B
000074703eddddbe  sub rsp, 0x08
000074703eddddc2  push rax
000074703eddddc3  push rcx
000074703eddddc4  push rdx
000074703eddddc5  push rdi
000074703eddddc6  push rsi
000074703eddddc7  push r8
000074703eddddc9  push r9
000074703eddddcb  push r10
000074703eddddcd  push r11
000074703eddddcf  sub rsp, 0xF0
000074703eddddd6  vmovaps [rsp], xmm0
000074703edddddb  vmovaps [rsp+0x10], xmm2
000074703edddde1  vmovaps [rsp+0x20], xmm3
000074703edddde7  vmovaps [rsp+0x30], xmm4
000074703edddded  vmovaps [rsp+0x40], xmm5
000074703eddddf3  vmovaps [rsp+0x50], xmm6
000074703eddddf9  vmovaps [rsp+0x60], xmm7
000074703eddddff  vmovaps [rsp+0x70], xmm8
000074703eddde05  vmovaps [rsp+0x80], xmm9
000074703eddde0e  vmovaps [rsp+0x90], xmm10
000074703eddde17  vmovaps [rsp+0xA0], xmm11
000074703eddde20  vmovaps [rsp+0xB0], xmm12
000074703eddde29  vmovaps [rsp+0xC0], xmm13
000074703eddde32  vmovaps [rsp+0xD0], xmm14
000074703eddde3b  vmovaps [rsp+0xE0], xmm15
000074703eddde44  sub rsp, 0x30
000074703eddde48  movaps [rsp], xmm1
000074703eddde4c  movaps [rsp+0x10], xmm5
000074703eddde51  movaps [rsp+0x20], xmm7
000074703eddde56  lea rdi, [rsp]
000074703eddde5a  mov esi, 0x00
000074703eddde5f  mov rax, 0x5D9974CCC530
000074703eddde69  call rax
000074703eddde6b  movaps xmm1, [rsp]
000074703eddde6f  add rsp, 0x30
000074703eddde73  vmovaps xmm0, [rsp]
000074703eddde78  vmovaps xmm2, [rsp+0x10]
000074703eddde7e  vmovaps xmm3, [rsp+0x20]
000074703eddde84  vmovaps xmm4, [rsp+0x30]
000074703eddde8a  vmovaps xmm5, [rsp+0x40]
000074703eddde90  vmovaps xmm6, [rsp+0x50]
000074703eddde96  vmovaps xmm7, [rsp+0x60]
000074703eddde9c  vmovaps xmm8, [rsp+0x70]
000074703edddea2  vmovaps xmm9, [rsp+0x80]
000074703edddeab  vmovaps xmm10, [rsp+0x90]
000074703edddeb4  vmovaps xmm11, [rsp+0xA0]
000074703edddebd  vmovaps xmm12, [rsp+0xB0]
000074703edddec6  vmovaps xmm13, [rsp+0xC0]
000074703edddecf  vmovaps xmm14, [rsp+0xD0]
000074703eddded8  vmovaps xmm15, [rsp+0xE0]
000074703edddee1  add rsp, 0xF0
000074703edddee8  pop r11
000074703edddeea  pop r10
000074703edddeec  pop r9
000074703edddeee  pop r8
000074703edddef0  pop rsi
000074703edddef1  pop rdi
000074703edddef2  pop rdx
000074703edddef3  pop rcx
000074703edddef4  pop rax
000074703edddef5  add rsp, 0x08
000074703edddef9  jmp 0x000074703EDDC030
000074703edddefe  sub rsp, 0x08
000074703edddf02  push rax
000074703edddf03  push rcx
000074703edddf04  push rdx
000074703edddf05  push rdi
000074703edddf06  push rsi
000074703edddf07  push r8
000074703edddf09  push r9
000074703edddf0b  push r10
000074703edddf0d  push r11
000074703edddf0f  sub rsp, 0xF0
000074703edddf16  vmovaps [rsp], xmm0
000074703edddf1b  vmovaps [rsp+0x10], xmm1
000074703edddf21  vmovaps [rsp+0x20], xmm2
000074703edddf27  vmovaps [rsp+0x30], xmm3
000074703edddf2d  vmovaps [rsp+0x40], xmm4
000074703edddf33  vmovaps [rsp+0x50], xmm5
000074703edddf39  vmovaps [rsp+0x60], xmm6
000074703edddf3f  vmovaps [rsp+0x70], xmm8
000074703edddf45  vmovaps [rsp+0x80], xmm9
000074703edddf4e  vmovaps [rsp+0x90], xmm10
000074703edddf57  vmovaps [rsp+0xA0], xmm11
000074703edddf60  vmovaps [rsp+0xB0], xmm12
000074703edddf69  vmovaps [rsp+0xC0], xmm13
000074703edddf72  vmovaps [rsp+0xD0], xmm14
000074703edddf7b  vmovaps [rsp+0xE0], xmm15
000074703edddf84  sub rsp, 0x30
000074703edddf88  movaps [rsp], xmm7
000074703edddf8c  movaps [rsp+0x10], xmm5
000074703edddf91  movaps [rsp+0x20], xmm15
000074703edddf97  lea rdi, [rsp]
000074703edddf9b  mov esi, 0x00
000074703edddfa0  mov rax, 0x5D9974CCC530
000074703edddfaa  call rax
000074703edddfac  movaps xmm7, [rsp]
000074703edddfb0  add rsp, 0x30
000074703edddfb4  vmovaps xmm0, [rsp]
000074703edddfb9  vmovaps xmm1, [rsp+0x10]
000074703edddfbf  vmovaps xmm2, [rsp+0x20]
000074703edddfc5  vmovaps xmm3, [rsp+0x30]
000074703edddfcb  vmovaps xmm4, [rsp+0x40]
000074703edddfd1  vmovaps xmm5, [rsp+0x50]
000074703edddfd7  vmovaps xmm6, [rsp+0x60]
000074703edddfdd  vmovaps xmm8, [rsp+0x70]
000074703edddfe3  vmovaps xmm9, [rsp+0x80]
000074703edddfec  vmovaps xmm10, [rsp+0x90]
000074703edddff5  vmovaps xmm11, [rsp+0xA0]
000074703edddffe  vmovaps xmm12, [rsp+0xB0]
000074703edde007  vmovaps xmm13, [rsp+0xC0]
000074703edde010  vmovaps xmm14, [rsp+0xD0]
000074703edde019  vmovaps xmm15, [rsp+0xE0]
000074703edde022  add rsp, 0xF0
000074703edde029  pop r11
000074703edde02b  pop r10
000074703edde02d  pop r9
000074703edde02f  pop r8
000074703edde031  pop rsi
000074703edde032  pop rdi
000074703edde033  pop rdx
000074703edde034  pop rcx
000074703edde035  pop rax
000074703edde036  add rsp, 0x08
000074703edde03a  jmp 0x000074703EDDC066
000074703edde03f  call 0x000074703ECB52F0
000074703edde044  jmp 0x000074703EDDC073
000074703edde049  sub rsp, 0x08
000074703edde04d  push rax
000074703edde04e  push rcx
000074703edde04f  push rdx
000074703edde050  push rdi
000074703edde051  push rsi
000074703edde052  push r8
000074703edde054  push r9
000074703edde056  push r10
000074703edde058  push r11
000074703edde05a  sub rsp, 0xF0
000074703edde061  vmovaps [rsp], xmm0
000074703edde066  vmovaps [rsp+0x10], xmm1
000074703edde06c  vmovaps [rsp+0x20], xmm2
000074703edde072  vmovaps [rsp+0x30], xmm3
000074703edde078  vmovaps [rsp+0x40], xmm4
000074703edde07e  vmovaps [rsp+0x50], xmm5
000074703edde084  vmovaps [rsp+0x60], xmm6
000074703edde08a  vmovaps [rsp+0x70], xmm7
000074703edde090  vmovaps [rsp+0x80], xmm8
000074703edde099  vmovaps [rsp+0x90], xmm9
000074703edde0a2  vmovaps [rsp+0xA0], xmm10
000074703edde0ab  vmovaps [rsp+0xB0], xmm11
000074703edde0b4  vmovaps [rsp+0xC0], xmm12
000074703edde0bd  vmovaps [rsp+0xD0], xmm13
000074703edde0c6  vmovaps [rsp+0xE0], xmm14
000074703edde0cf  sub rsp, 0x30
000074703edde0d3  movaps [rsp], xmm15
000074703edde0d8  movaps [rsp+0x10], xmm5
000074703edde0dd  movaps [rsp+0x20], xmm3
000074703edde0e2  lea rdi, [rsp]
000074703edde0e6  mov esi, 0x00
000074703edde0eb  mov rax, 0x5D9974CCC530
000074703edde0f5  call rax
000074703edde0f7  movaps xmm15, [rsp]
000074703edde0fc  add rsp, 0x30
000074703edde100  vmovaps xmm0, [rsp]
000074703edde105  vmovaps xmm1, [rsp+0x10]
000074703edde10b  vmovaps xmm2, [rsp+0x20]
000074703edde111  vmovaps xmm3, [rsp+0x30]
000074703edde117  vmovaps xmm4, [rsp+0x40]
000074703edde11d  vmovaps xmm5, [rsp+0x50]
000074703edde123  vmovaps xmm6, [rsp+0x60]
000074703edde129  vmovaps xmm7, [rsp+0x70]
000074703edde12f  vmovaps xmm8, [rsp+0x80]
000074703edde138  vmovaps xmm9, [rsp+0x90]
000074703edde141  vmovaps xmm10, [rsp+0xA0]
000074703edde14a  vmovaps xmm11, [rsp+0xB0]
000074703edde153  vmovaps xmm12, [rsp+0xC0]
000074703edde15c  vmovaps xmm13, [rsp+0xD0]
000074703edde165  vmovaps xmm14, [rsp+0xE0]
000074703edde16e  add rsp, 0xF0
000074703edde175  pop r11
000074703edde177  pop r10
000074703edde179  pop r9
000074703edde17b  pop r8
000074703edde17d  pop rsi
000074703edde17e  pop rdi
000074703edde17f  pop rdx
000074703edde180  pop rcx
000074703edde181  pop rax
000074703edde182  add rsp, 0x08
000074703edde186  jmp 0x000074703EDDC099
000074703edde18b  sub rsp, 0x08
000074703edde18f  push rax
000074703edde190  push rcx
000074703edde191  push rdx
000074703edde192  push rdi
000074703edde193  push rsi
000074703edde194  push r8
000074703edde196  push r9
000074703edde198  push r10
000074703edde19a  push r11
000074703edde19c  sub rsp, 0xF0
000074703edde1a3  vmovaps [rsp], xmm0
000074703edde1a8  vmovaps [rsp+0x10], xmm2
000074703edde1ae  vmovaps [rsp+0x20], xmm3
000074703edde1b4  vmovaps [rsp+0x30], xmm4
000074703edde1ba  vmovaps [rsp+0x40], xmm5
000074703edde1c0  vmovaps [rsp+0x50], xmm6
000074703edde1c6  vmovaps [rsp+0x60], xmm7
000074703edde1cc  vmovaps [rsp+0x70], xmm8
000074703edde1d2  vmovaps [rsp+0x80], xmm9
000074703edde1db  vmovaps [rsp+0x90], xmm10
000074703edde1e4  vmovaps [rsp+0xA0], xmm11
000074703edde1ed  vmovaps [rsp+0xB0], xmm12
000074703edde1f6  vmovaps [rsp+0xC0], xmm13
000074703edde1ff  vmovaps [rsp+0xD0], xmm14
000074703edde208  vmovaps [rsp+0xE0], xmm15
000074703edde211  sub rsp, 0x30
000074703edde215  movaps [rsp], xmm1
000074703edde219  movaps [rsp+0x10], xmm5
000074703edde21e  movaps [rsp+0x20], xmm4
000074703edde223  lea rdi, [rsp]
000074703edde227  mov esi, 0x00
000074703edde22c  mov rax, 0x5D9974CCC530
000074703edde236  call rax
000074703edde238  movaps xmm1, [rsp]
000074703edde23c  add rsp, 0x30
000074703edde240  vmovaps xmm0, [rsp]
000074703edde245  vmovaps xmm2, [rsp+0x10]
000074703edde24b  vmovaps xmm3, [rsp+0x20]
000074703edde251  vmovaps xmm4, [rsp+0x30]
000074703edde257  vmovaps xmm5, [rsp+0x40]
000074703edde25d  vmovaps xmm6, [rsp+0x50]
000074703edde263  vmovaps xmm7, [rsp+0x60]
000074703edde269  vmovaps xmm8, [rsp+0x70]
000074703edde26f  vmovaps xmm9, [rsp+0x80]
000074703edde278  vmovaps xmm10, [rsp+0x90]
000074703edde281  vmovaps xmm11, [rsp+0xA0]
000074703edde28a  vmovaps xmm12, [rsp+0xB0]
000074703edde293  vmovaps xmm13, [rsp+0xC0]
000074703edde29c  vmovaps xmm14, [rsp+0xD0]
000074703edde2a5  vmovaps xmm15, [rsp+0xE0]
000074703edde2ae  add rsp, 0xF0
000074703edde2b5  pop r11
000074703edde2b7  pop r10
000074703edde2b9  pop r9
000074703edde2bb  pop r8
000074703edde2bd  pop rsi
000074703edde2be  pop rdi
000074703edde2bf  pop rdx
000074703edde2c0  pop rcx
000074703edde2c1  pop rax
000074703edde2c2  add rsp, 0x08
000074703edde2c6  jmp 0x000074703EDDC0B9
000074703edde2cb  sub rsp, 0x08
000074703edde2cf  push rax
000074703edde2d0  push rcx
000074703edde2d1  push rdx
000074703edde2d2  push rdi
000074703edde2d3  push rsi
000074703edde2d4  push r8
000074703edde2d6  push r9
000074703edde2d8  push r10
000074703edde2da  push r11
000074703edde2dc  sub rsp, 0xF0
000074703edde2e3  vmovaps [rsp], xmm0
000074703edde2e8  vmovaps [rsp+0x10], xmm1
000074703edde2ee  vmovaps [rsp+0x20], xmm2
000074703edde2f4  vmovaps [rsp+0x30], xmm3
000074703edde2fa  vmovaps [rsp+0x40], xmm5
000074703edde300  vmovaps [rsp+0x50], xmm6
000074703edde306  vmovaps [rsp+0x60], xmm7
000074703edde30c  vmovaps [rsp+0x70], xmm8
000074703edde312  vmovaps [rsp+0x80], xmm9
000074703edde31b  vmovaps [rsp+0x90], xmm10
000074703edde324  vmovaps [rsp+0xA0], xmm11
000074703edde32d  vmovaps [rsp+0xB0], xmm12
000074703edde336  vmovaps [rsp+0xC0], xmm13
000074703edde33f  vmovaps [rsp+0xD0], xmm14
000074703edde348  vmovaps [rsp+0xE0], xmm15
000074703edde351  sub rsp, 0x30
000074703edde355  movaps [rsp], xmm4
000074703edde359  movaps [rsp+0x10], xmm3
000074703edde35e  movaps [rsp+0x20], xmm5
000074703edde363  lea rdi, [rsp]
000074703edde367  mov esi, 0x00
000074703edde36c  mov rax, 0x5D9974CCC530
000074703edde376  call rax
000074703edde378  movaps xmm4, [rsp]
000074703edde37c  add rsp, 0x30
000074703edde380  vmovaps xmm0, [rsp]
000074703edde385  vmovaps xmm1, [rsp+0x10]
000074703edde38b  vmovaps xmm2, [rsp+0x20]
000074703edde391  vmovaps xmm3, [rsp+0x30]
000074703edde397  vmovaps xmm5, [rsp+0x40]
000074703edde39d  vmovaps xmm6, [rsp+0x50]
000074703edde3a3  vmovaps xmm7, [rsp+0x60]
000074703edde3a9  vmovaps xmm8, [rsp+0x70]
000074703edde3af  vmovaps xmm9, [rsp+0x80]
000074703edde3b8  vmovaps xmm10, [rsp+0x90]
000074703edde3c1  vmovaps xmm11, [rsp+0xA0]
000074703edde3ca  vmovaps xmm12, [rsp+0xB0]
000074703edde3d3  vmovaps xmm13, [rsp+0xC0]
000074703edde3dc  vmovaps xmm14, [rsp+0xD0]
000074703edde3e5  vmovaps xmm15, [rsp+0xE0]
000074703edde3ee  add rsp, 0xF0
000074703edde3f5  pop r11
000074703edde3f7  pop r10
000074703edde3f9  pop r9
000074703edde3fb  pop r8
000074703edde3fd  pop rsi
000074703edde3fe  pop rdi
000074703edde3ff  pop rdx
000074703edde400  pop rcx
000074703edde401  pop rax
000074703edde402  add rsp, 0x08
000074703edde406  jmp 0x000074703EDDC107
000074703edde40b  call 0x000074703ECB52F0
000074703edde410  jmp 0x000074703EDDC114
000074703edde415  sub rsp, 0x08
000074703edde419  push rax
000074703edde41a  push rcx
000074703edde41b  push rdx
000074703edde41c  push rdi
000074703edde41d  push rsi
000074703edde41e  push r8
000074703edde420  push r9
000074703edde422  push r10
000074703edde424  push r11
000074703edde426  sub rsp, 0xF0
000074703edde42d  vmovaps [rsp], xmm0
000074703edde432  vmovaps [rsp+0x10], xmm1
000074703edde438  vmovaps [rsp+0x20], xmm2
000074703edde43e  vmovaps [rsp+0x30], xmm3
000074703edde444  vmovaps [rsp+0x40], xmm4
000074703edde44a  vmovaps [rsp+0x50], xmm6
000074703edde450  vmovaps [rsp+0x60], xmm7
000074703edde456  vmovaps [rsp+0x70], xmm8
000074703edde45c  vmovaps [rsp+0x80], xmm9
000074703edde465  vmovaps [rsp+0x90], xmm10
000074703edde46e  vmovaps [rsp+0xA0], xmm11
000074703edde477  vmovaps [rsp+0xB0], xmm12
000074703edde480  vmovaps [rsp+0xC0], xmm13
000074703edde489  vmovaps [rsp+0xD0], xmm14
000074703edde492  vmovaps [rsp+0xE0], xmm15
000074703edde49b  sub rsp, 0x30
000074703edde49f  movaps [rsp], xmm5
000074703edde4a3  movaps [rsp+0x10], xmm6
000074703edde4a8  movaps [rsp+0x20], xmm3
000074703edde4ad  lea rdi, [rsp]
000074703edde4b1  mov esi, 0x00
000074703edde4b6  mov rax, 0x5D9974CCC530
000074703edde4c0  call rax
000074703edde4c2  movaps xmm5, [rsp]
000074703edde4c6  add rsp, 0x30
000074703edde4ca  vmovaps xmm0, [rsp]
000074703edde4cf  vmovaps xmm1, [rsp+0x10]
000074703edde4d5  vmovaps xmm2, [rsp+0x20]
000074703edde4db  vmovaps xmm3, [rsp+0x30]
000074703edde4e1  vmovaps xmm4, [rsp+0x40]
000074703edde4e7  vmovaps xmm6, [rsp+0x50]
000074703edde4ed  vmovaps xmm7, [rsp+0x60]
000074703edde4f3  vmovaps xmm8, [rsp+0x70]
000074703edde4f9  vmovaps xmm9, [rsp+0x80]
000074703edde502  vmovaps xmm10, [rsp+0x90]
000074703edde50b  vmovaps xmm11, [rsp+0xA0]
000074703edde514  vmovaps xmm12, [rsp+0xB0]
000074703edde51d  vmovaps xmm13, [rsp+0xC0]
000074703edde526  vmovaps xmm14, [rsp+0xD0]
000074703edde52f  vmovaps xmm15, [rsp+0xE0]
000074703edde538  add rsp, 0xF0
000074703edde53f  pop r11
000074703edde541  pop r10
000074703edde543  pop r9
000074703edde545  pop r8
000074703edde547  pop rsi
000074703edde548  pop rdi
000074703edde549  pop rdx
000074703edde54a  pop rcx
000074703edde54b  pop rax
000074703edde54c  add rsp, 0x08
000074703edde550  jmp 0x000074703EDDC13A
000074703edde555  sub rsp, 0x08
000074703edde559  push rax
000074703edde55a  push rcx
000074703edde55b  push rdx
000074703edde55c  push rdi
000074703edde55d  push rsi
000074703edde55e  push r8
000074703edde560  push r9
000074703edde562  push r10
000074703edde564  push r11
000074703edde566  sub rsp, 0xF0
000074703edde56d  vmovaps [rsp], xmm0
000074703edde572  vmovaps [rsp+0x10], xmm1
000074703edde578  vmovaps [rsp+0x20], xmm2
000074703edde57e  vmovaps [rsp+0x30], xmm3
000074703edde584  vmovaps [rsp+0x40], xmm4
000074703edde58a  vmovaps [rsp+0x50], xmm5
000074703edde590  vmovaps [rsp+0x60], xmm7
000074703edde596  vmovaps [rsp+0x70], xmm8
000074703edde59c  vmovaps [rsp+0x80], xmm9
000074703edde5a5  vmovaps [rsp+0x90], xmm10
000074703edde5ae  vmovaps [rsp+0xA0], xmm11
000074703edde5b7  vmovaps [rsp+0xB0], xmm12
000074703edde5c0  vmovaps [rsp+0xC0], xmm13
000074703edde5c9  vmovaps [rsp+0xD0], xmm14
000074703edde5d2  vmovaps [rsp+0xE0], xmm15
000074703edde5db  sub rsp, 0x30
000074703edde5df  movaps [rsp], xmm6
000074703edde5e3  movaps [rsp+0x10], xmm9
000074703edde5e9  movaps [rsp+0x20], xmm1
000074703edde5ee  lea rdi, [rsp]
000074703edde5f2  mov esi, 0x00
000074703edde5f7  mov rax, 0x5D9974CCC530
000074703edde601  call rax
000074703edde603  movaps xmm6, [rsp]
000074703edde607  add rsp, 0x30
000074703edde60b  vmovaps xmm0, [rsp]
000074703edde610  vmovaps xmm1, [rsp+0x10]
000074703edde616  vmovaps xmm2, [rsp+0x20]
000074703edde61c  vmovaps xmm3, [rsp+0x30]
000074703edde622  vmovaps xmm4, [rsp+0x40]
000074703edde628  vmovaps xmm5, [rsp+0x50]
000074703edde62e  vmovaps xmm7, [rsp+0x60]
000074703edde634  vmovaps xmm8, [rsp+0x70]
000074703edde63a  vmovaps xmm9, [rsp+0x80]
000074703edde643  vmovaps xmm10, [rsp+0x90]
000074703edde64c  vmovaps xmm11, [rsp+0xA0]
000074703edde655  vmovaps xmm12, [rsp+0xB0]
000074703edde65e  vmovaps xmm13, [rsp+0xC0]
000074703edde667  vmovaps xmm14, [rsp+0xD0]
000074703edde670  vmovaps xmm15, [rsp+0xE0]
000074703edde679  add rsp, 0xF0
000074703edde680  pop r11
000074703edde682  pop r10
000074703edde684  pop r9
000074703edde686  pop r8
000074703edde688  pop rsi
000074703edde689  pop rdi
000074703edde68a  pop rdx
000074703edde68b  pop rcx
000074703edde68c  pop rax
000074703edde68d  add rsp, 0x08
000074703edde691  jmp 0x000074703EDDC15E
000074703edde696  sub rsp, 0x08
000074703edde69a  push rax
000074703edde69b  push rcx
000074703edde69c  push rdx
000074703edde69d  push rdi
000074703edde69e  push rsi
000074703edde69f  push r8
000074703edde6a1  push r9
000074703edde6a3  push r10
000074703edde6a5  push r11
000074703edde6a7  sub rsp, 0xF0
000074703edde6ae  vmovaps [rsp], xmm0
000074703edde6b3  vmovaps [rsp+0x10], xmm1
000074703edde6b9  vmovaps [rsp+0x20], xmm2
000074703edde6bf  vmovaps [rsp+0x30], xmm3
000074703edde6c5  vmovaps [rsp+0x40], xmm4
000074703edde6cb  vmovaps [rsp+0x50], xmm5
000074703edde6d1  vmovaps [rsp+0x60], xmm6
000074703edde6d7  vmovaps [rsp+0x70], xmm7
000074703edde6dd  vmovaps [rsp+0x80], xmm8
000074703edde6e6  vmovaps [rsp+0x90], xmm10
000074703edde6ef  vmovaps [rsp+0xA0], xmm11
000074703edde6f8  vmovaps [rsp+0xB0], xmm12
000074703edde701  vmovaps [rsp+0xC0], xmm13
000074703edde70a  vmovaps [rsp+0xD0], xmm14
000074703edde713  vmovaps [rsp+0xE0], xmm15
000074703edde71c  sub rsp, 0x30
000074703edde720  movaps [rsp], xmm9
000074703edde725  movaps [rsp+0x10], xmm3
000074703edde72a  movaps [rsp+0x20], xmm1
000074703edde72f  lea rdi, [rsp]
000074703edde733  mov esi, 0x00
000074703edde738  mov rax, 0x5D9974CCC530
000074703edde742  call rax
000074703edde744  movaps xmm9, [rsp]
000074703edde749  add rsp, 0x30
000074703edde74d  vmovaps xmm0, [rsp]
000074703edde752  vmovaps xmm1, [rsp+0x10]
000074703edde758  vmovaps xmm2, [rsp+0x20]
000074703edde75e  vmovaps xmm3, [rsp+0x30]
000074703edde764  vmovaps xmm4, [rsp+0x40]
000074703edde76a  vmovaps xmm5, [rsp+0x50]
000074703edde770  vmovaps xmm6, [rsp+0x60]
000074703edde776  vmovaps xmm7, [rsp+0x70]
000074703edde77c  vmovaps xmm8, [rsp+0x80]
000074703edde785  vmovaps xmm10, [rsp+0x90]
000074703edde78e  vmovaps xmm11, [rsp+0xA0]
000074703edde797  vmovaps xmm12, [rsp+0xB0]
000074703edde7a0  vmovaps xmm13, [rsp+0xC0]
000074703edde7a9  vmovaps xmm14, [rsp+0xD0]
000074703edde7b2  vmovaps xmm15, [rsp+0xE0]
000074703edde7bb  add rsp, 0xF0
000074703edde7c2  pop r11
000074703edde7c4  pop r10
000074703edde7c6  pop r9
000074703edde7c8  pop r8
000074703edde7ca  pop rsi
000074703edde7cb  pop rdi
000074703edde7cc  pop rdx
000074703edde7cd  pop rcx
000074703edde7ce  pop rax
000074703edde7cf  add rsp, 0x08
000074703edde7d3  jmp 0x000074703EDDC1AA
000074703edde7d8  call 0x000074703ECB52F0
000074703edde7dd  jmp 0x000074703EDDC1B7
000074703edde7e2  sub rsp, 0x08
000074703edde7e6  push rax
000074703edde7e7  push rcx
000074703edde7e8  push rdx
000074703edde7e9  push rdi
000074703edde7ea  push rsi
000074703edde7eb  push r8
000074703edde7ed  push r9
000074703edde7ef  push r10
000074703edde7f1  push r11
000074703edde7f3  sub rsp, 0xF0
000074703edde7fa  vmovaps [rsp], xmm0
000074703edde7ff  vmovaps [rsp+0x10], xmm1
000074703edde805  vmovaps [rsp+0x20], xmm2
000074703edde80b  vmovaps [rsp+0x30], xmm3
000074703edde811  vmovaps [rsp+0x40], xmm4
000074703edde817  vmovaps [rsp+0x50], xmm5
000074703edde81d  vmovaps [rsp+0x60], xmm6
000074703edde823  vmovaps [rsp+0x70], xmm7
000074703edde829  vmovaps [rsp+0x80], xmm8
000074703edde832  vmovaps [rsp+0x90], xmm9
000074703edde83b  vmovaps [rsp+0xA0], xmm10
000074703edde844  vmovaps [rsp+0xB0], xmm11
000074703edde84d  vmovaps [rsp+0xC0], xmm12
000074703edde856  vmovaps [rsp+0xD0], xmm13
000074703edde85f  vmovaps [rsp+0xE0], xmm14
000074703edde868  sub rsp, 0x30
000074703edde86c  movaps [rsp], xmm15
000074703edde871  movaps [rsp+0x10], xmm3
000074703edde876  movaps [rsp+0x20], xmm7
000074703edde87b  lea rdi, [rsp]
000074703edde87f  mov esi, 0x00
000074703edde884  mov rax, 0x5D9974CCC530
000074703edde88e  call rax
000074703edde890  movaps xmm15, [rsp]
000074703edde895  add rsp, 0x30
000074703edde899  vmovaps xmm0, [rsp]
000074703edde89e  vmovaps xmm1, [rsp+0x10]
000074703edde8a4  vmovaps xmm2, [rsp+0x20]
000074703edde8aa  vmovaps xmm3, [rsp+0x30]
000074703edde8b0  vmovaps xmm4, [rsp+0x40]
000074703edde8b6  vmovaps xmm5, [rsp+0x50]
000074703edde8bc  vmovaps xmm6, [rsp+0x60]
000074703edde8c2  vmovaps xmm7, [rsp+0x70]
000074703edde8c8  vmovaps xmm8, [rsp+0x80]
000074703edde8d1  vmovaps xmm9, [rsp+0x90]
000074703edde8da  vmovaps xmm10, [rsp+0xA0]
000074703edde8e3  vmovaps xmm11, [rsp+0xB0]
000074703edde8ec  vmovaps xmm12, [rsp+0xC0]
000074703edde8f5  vmovaps xmm13, [rsp+0xD0]
000074703edde8fe  vmovaps xmm14, [rsp+0xE0]
000074703edde907  add rsp, 0xF0
000074703edde90e  pop r11
000074703edde910  pop r10
000074703edde912  pop r9
000074703edde914  pop r8
000074703edde916  pop rsi
000074703edde917  pop rdi
000074703edde918  pop rdx
000074703edde919  pop rcx
000074703edde91a  pop rax
000074703edde91b  add rsp, 0x08
000074703edde91f  jmp 0x000074703EDDC1E3
000074703edde924  sub rsp, 0x08
000074703edde928  push rax
000074703edde929  push rcx
000074703edde92a  push rdx
000074703edde92b  push rdi
000074703edde92c  push rsi
000074703edde92d  push r8
000074703edde92f  push r9
000074703edde931  push r10
000074703edde933  push r11
000074703edde935  sub rsp, 0xF0
000074703edde93c  vmovaps [rsp], xmm0
000074703edde941  vmovaps [rsp+0x10], xmm1
000074703edde947  vmovaps [rsp+0x20], xmm2
000074703edde94d  vmovaps [rsp+0x30], xmm4
000074703edde953  vmovaps [rsp+0x40], xmm5
000074703edde959  vmovaps [rsp+0x50], xmm6
000074703edde95f  vmovaps [rsp+0x60], xmm7
000074703edde965  vmovaps [rsp+0x70], xmm8
000074703edde96b  vmovaps [rsp+0x80], xmm9
000074703edde974  vmovaps [rsp+0x90], xmm10
000074703edde97d  vmovaps [rsp+0xA0], xmm11
000074703edde986  vmovaps [rsp+0xB0], xmm12
000074703edde98f  vmovaps [rsp+0xC0], xmm13
000074703edde998  vmovaps [rsp+0xD0], xmm14
000074703edde9a1  vmovaps [rsp+0xE0], xmm15
000074703edde9aa  sub rsp, 0x30
000074703edde9ae  movaps [rsp], xmm3
000074703edde9b2  movaps [rsp+0x10], xmm1
000074703edde9b7  movaps [rsp+0x20], xmm15
000074703edde9bd  lea rdi, [rsp]
000074703edde9c1  mov esi, 0x00
000074703edde9c6  mov rax, 0x5D9974CCC530
000074703edde9d0  call rax
000074703edde9d2  movaps xmm3, [rsp]
000074703edde9d6  add rsp, 0x30
000074703edde9da  vmovaps xmm0, [rsp]
000074703edde9df  vmovaps xmm1, [rsp+0x10]
000074703edde9e5  vmovaps xmm2, [rsp+0x20]
000074703edde9eb  vmovaps xmm4, [rsp+0x30]
000074703edde9f1  vmovaps xmm5, [rsp+0x40]
000074703edde9f7  vmovaps xmm6, [rsp+0x50]
000074703edde9fd  vmovaps xmm7, [rsp+0x60]
000074703eddea03  vmovaps xmm8, [rsp+0x70]
000074703eddea09  vmovaps xmm9, [rsp+0x80]
000074703eddea12  vmovaps xmm10, [rsp+0x90]
000074703eddea1b  vmovaps xmm11, [rsp+0xA0]
000074703eddea24  vmovaps xmm12, [rsp+0xB0]
000074703eddea2d  vmovaps xmm13, [rsp+0xC0]
000074703eddea36  vmovaps xmm14, [rsp+0xD0]
000074703eddea3f  vmovaps xmm15, [rsp+0xE0]
000074703eddea48  add rsp, 0xF0
000074703eddea4f  pop r11
000074703eddea51  pop r10
000074703eddea53  pop r9
000074703eddea55  pop r8
000074703eddea57  pop rsi
000074703eddea58  pop rdi
000074703eddea59  pop rdx
000074703eddea5a  pop rcx
000074703eddea5b  pop rax
000074703eddea5c  add rsp, 0x08
000074703eddea60  jmp 0x000074703EDDC272
000074703eddea65  call 0x000074703ECB52F0
000074703eddea6a  jmp 0x000074703EDDC27C
000074703eddea6f  sub rsp, 0x08
000074703eddea73  push rax
000074703eddea74  push rcx
000074703eddea75  push rdx
000074703eddea76  push rdi
000074703eddea77  push rsi
000074703eddea78  push r8
000074703eddea7a  push r9
000074703eddea7c  push r10
000074703eddea7e  push r11
000074703eddea80  sub rsp, 0xF0
000074703eddea87  vmovaps [rsp], xmm0
000074703eddea8c  vmovaps [rsp+0x10], xmm1
000074703eddea92  vmovaps [rsp+0x20], xmm2
000074703eddea98  vmovaps [rsp+0x30], xmm3
000074703eddea9e  vmovaps [rsp+0x40], xmm4
000074703eddeaa4  vmovaps [rsp+0x50], xmm5
000074703eddeaaa  vmovaps [rsp+0x60], xmm6
000074703eddeab0  vmovaps [rsp+0x70], xmm7
000074703eddeab6  vmovaps [rsp+0x80], xmm8
000074703eddeabf  vmovaps [rsp+0x90], xmm9
000074703eddeac8  vmovaps [rsp+0xA0], xmm10
000074703eddead1  vmovaps [rsp+0xB0], xmm11
000074703eddeada  vmovaps [rsp+0xC0], xmm12
000074703eddeae3  vmovaps [rsp+0xD0], xmm13
000074703eddeaec  vmovaps [rsp+0xE0], xmm14
000074703eddeaf5  sub rsp, 0x30
000074703eddeaf9  movaps [rsp], xmm15
000074703eddeafe  movaps [rsp+0x10], xmm14
000074703eddeb04  movaps [rsp+0x20], xmm4
000074703eddeb09  lea rdi, [rsp]
000074703eddeb0d  mov esi, 0x00
000074703eddeb12  mov rax, 0x5D9974CCC530
000074703eddeb1c  call rax
000074703eddeb1e  movaps xmm15, [rsp]
000074703eddeb23  add rsp, 0x30
000074703eddeb27  vmovaps xmm0, [rsp]
000074703eddeb2c  vmovaps xmm1, [rsp+0x10]
000074703eddeb32  vmovaps xmm2, [rsp+0x20]
000074703eddeb38  vmovaps xmm3, [rsp+0x30]
000074703eddeb3e  vmovaps xmm4, [rsp+0x40]
000074703eddeb44  vmovaps xmm5, [rsp+0x50]
000074703eddeb4a  vmovaps xmm6, [rsp+0x60]
000074703eddeb50  vmovaps xmm7, [rsp+0x70]
000074703eddeb56  vmovaps xmm8, [rsp+0x80]
000074703eddeb5f  vmovaps xmm9, [rsp+0x90]
000074703eddeb68  vmovaps xmm10, [rsp+0xA0]
000074703eddeb71  vmovaps xmm11, [rsp+0xB0]
000074703eddeb7a  vmovaps xmm12, [rsp+0xC0]
000074703eddeb83  vmovaps xmm13, [rsp+0xD0]
000074703eddeb8c  vmovaps xmm14, [rsp+0xE0]
000074703eddeb95  add rsp, 0xF0
000074703eddeb9c  pop r11
000074703eddeb9e  pop r10
000074703eddeba0  pop r9
000074703eddeba2  pop r8
000074703eddeba4  pop rsi
000074703eddeba5  pop rdi
000074703eddeba6  pop rdx
000074703eddeba7  pop rcx
000074703eddeba8  pop rax
000074703eddeba9  add rsp, 0x08
000074703eddebad  jmp 0x000074703EDDC2AA
000074703eddebb2  sub rsp, 0x08
000074703eddebb6  push rax
000074703eddebb7  push rcx
000074703eddebb8  push rdx
000074703eddebb9  push rdi
000074703eddebba  push rsi
000074703eddebbb  push r8
000074703eddebbd  push r9
000074703eddebbf  push r10
000074703eddebc1  push r11
000074703eddebc3  sub rsp, 0xF0
000074703eddebca  vmovaps [rsp], xmm0
000074703eddebcf  vmovaps [rsp+0x10], xmm1
000074703eddebd5  vmovaps [rsp+0x20], xmm2
000074703eddebdb  vmovaps [rsp+0x30], xmm3
000074703eddebe1  vmovaps [rsp+0x40], xmm4
000074703eddebe7  vmovaps [rsp+0x50], xmm5
000074703eddebed  vmovaps [rsp+0x60], xmm6
000074703eddebf3  vmovaps [rsp+0x70], xmm7
000074703eddebf9  vmovaps [rsp+0x80], xmm8
000074703eddec02  vmovaps [rsp+0x90], xmm9
000074703eddec0b  vmovaps [rsp+0xA0], xmm10
000074703eddec14  vmovaps [rsp+0xB0], xmm11
000074703eddec1d  vmovaps [rsp+0xC0], xmm12
000074703eddec26  vmovaps [rsp+0xD0], xmm13
000074703eddec2f  vmovaps [rsp+0xE0], xmm15
000074703eddec38  sub rsp, 0x30
000074703eddec3c  movaps [rsp], xmm14
000074703eddec41  movaps [rsp+0x10], xmm2
000074703eddec46  movaps [rsp+0x20], xmm1
000074703eddec4b  lea rdi, [rsp]
000074703eddec4f  mov esi, 0x00
000074703eddec54  mov rax, 0x5D9974CCC530
000074703eddec5e  call rax
000074703eddec60  movaps xmm14, [rsp]
000074703eddec65  add rsp, 0x30
000074703eddec69  vmovaps xmm0, [rsp]
000074703eddec6e  vmovaps xmm1, [rsp+0x10]
000074703eddec74  vmovaps xmm2, [rsp+0x20]
000074703eddec7a  vmovaps xmm3, [rsp+0x30]
000074703eddec80  vmovaps xmm4, [rsp+0x40]
000074703eddec86  vmovaps xmm5, [rsp+0x50]
000074703eddec8c  vmovaps xmm6, [rsp+0x60]
000074703eddec92  vmovaps xmm7, [rsp+0x70]
000074703eddec98  vmovaps xmm8, [rsp+0x80]
000074703eddeca1  vmovaps xmm9, [rsp+0x90]
000074703eddecaa  vmovaps xmm10, [rsp+0xA0]
000074703eddecb3  vmovaps xmm11, [rsp+0xB0]
000074703eddecbc  vmovaps xmm12, [rsp+0xC0]
000074703eddecc5  vmovaps xmm13, [rsp+0xD0]
000074703eddecce  vmovaps xmm15, [rsp+0xE0]
000074703eddecd7  add rsp, 0xF0
000074703eddecde  pop r11
000074703eddece0  pop r10
000074703eddece2  pop r9
000074703eddece4  pop r8
000074703eddece6  pop rsi
000074703eddece7  pop rdi
000074703eddece8  pop rdx
000074703eddece9  pop rcx
000074703eddecea  pop rax
000074703eddeceb  add rsp, 0x08
000074703eddecef  jmp 0x000074703EDDC2D0
000074703eddecf4  sub rsp, 0x08
000074703eddecf8  push rax
000074703eddecf9  push rcx
000074703eddecfa  push rdx
000074703eddecfb  push rdi
000074703eddecfc  push rsi
000074703eddecfd  push r8
000074703eddecff  push r9
000074703edded01  push r10
000074703edded03  push r11
000074703edded05  sub rsp, 0xF0
000074703edded0c  vmovaps [rsp], xmm0
000074703edded11  vmovaps [rsp+0x10], xmm2
000074703edded17  vmovaps [rsp+0x20], xmm3
000074703edded1d  vmovaps [rsp+0x30], xmm4
000074703edded23  vmovaps [rsp+0x40], xmm5
000074703edded29  vmovaps [rsp+0x50], xmm6
000074703edded2f  vmovaps [rsp+0x60], xmm7
000074703edded35  vmovaps [rsp+0x70], xmm8
000074703edded3b  vmovaps [rsp+0x80], xmm9
000074703edded44  vmovaps [rsp+0x90], xmm10
000074703edded4d  vmovaps [rsp+0xA0], xmm11
000074703edded56  vmovaps [rsp+0xB0], xmm12
000074703edded5f  vmovaps [rsp+0xC0], xmm13
000074703edded68  vmovaps [rsp+0xD0], xmm14
000074703edded71  vmovaps [rsp+0xE0], xmm15
000074703edded7a  sub rsp, 0x30
000074703edded7e  movaps [rsp], xmm1
000074703edded82  movaps [rsp+0x10], xmm4
000074703edded87  movaps [rsp+0x20], xmm9
000074703edded8d  lea rdi, [rsp]
000074703edded91  mov esi, 0x00
000074703edded96  mov rax, 0x5D9974CCC530
000074703eddeda0  call rax
000074703eddeda2  movaps xmm1, [rsp]
000074703eddeda6  add rsp, 0x30
000074703eddedaa  vmovaps xmm0, [rsp]
000074703eddedaf  vmovaps xmm2, [rsp+0x10]
000074703eddedb5  vmovaps xmm3, [rsp+0x20]
000074703eddedbb  vmovaps xmm4, [rsp+0x30]
000074703eddedc1  vmovaps xmm5, [rsp+0x40]
000074703eddedc7  vmovaps xmm6, [rsp+0x50]
000074703eddedcd  vmovaps xmm7, [rsp+0x60]
000074703eddedd3  vmovaps xmm8, [rsp+0x70]
000074703eddedd9  vmovaps xmm9, [rsp+0x80]
000074703eddede2  vmovaps xmm10, [rsp+0x90]
000074703eddedeb  vmovaps xmm11, [rsp+0xA0]
000074703eddedf4  vmovaps xmm12, [rsp+0xB0]
000074703eddedfd  vmovaps xmm13, [rsp+0xC0]
000074703eddee06  vmovaps xmm14, [rsp+0xD0]
000074703eddee0f  vmovaps xmm15, [rsp+0xE0]
000074703eddee18  add rsp, 0xF0
000074703eddee1f  pop r11
000074703eddee21  pop r10
000074703eddee23  pop r9
000074703eddee25  pop r8
000074703eddee27  pop rsi
000074703eddee28  pop rdi
000074703eddee29  pop rdx
000074703eddee2a  pop rcx
000074703eddee2b  pop rax
000074703eddee2c  add rsp, 0x08
000074703eddee30  jmp 0x000074703EDDC2EE
000074703eddee35  sub rsp, 0x08
000074703eddee39  push rax
000074703eddee3a  push rcx
000074703eddee3b  push rdx
000074703eddee3c  push rdi
000074703eddee3d  push rsi
000074703eddee3e  push r8
000074703eddee40  push r9
000074703eddee42  push r10
000074703eddee44  push r11
000074703eddee46  sub rsp, 0xF0
000074703eddee4d  vmovaps [rsp], xmm0
000074703eddee52  vmovaps [rsp+0x10], xmm1
000074703eddee58  vmovaps [rsp+0x20], xmm2
000074703eddee5e  vmovaps [rsp+0x30], xmm3
000074703eddee64  vmovaps [rsp+0x40], xmm5
000074703eddee6a  vmovaps [rsp+0x50], xmm6
000074703eddee70  vmovaps [rsp+0x60], xmm7
000074703eddee76  vmovaps [rsp+0x70], xmm8
000074703eddee7c  vmovaps [rsp+0x80], xmm9
000074703eddee85  vmovaps [rsp+0x90], xmm10
000074703eddee8e  vmovaps [rsp+0xA0], xmm11
000074703eddee97  vmovaps [rsp+0xB0], xmm12
000074703eddeea0  vmovaps [rsp+0xC0], xmm13
000074703eddeea9  vmovaps [rsp+0xD0], xmm14
000074703eddeeb2  vmovaps [rsp+0xE0], xmm15
000074703eddeebb  sub rsp, 0x30
000074703eddeebf  movaps [rsp], xmm4
000074703eddeec3  movaps [rsp+0x10], xmm2
000074703eddeec8  movaps [rsp+0x20], xmm9
000074703eddeece  lea rdi, [rsp]
000074703eddeed2  mov esi, 0x00
000074703eddeed7  mov rax, 0x5D9974CCC530
000074703eddeee1  call rax
000074703eddeee3  movaps xmm4, [rsp]
000074703eddeee7  add rsp, 0x30
000074703eddeeeb  vmovaps xmm0, [rsp]
000074703eddeef0  vmovaps xmm1, [rsp+0x10]
000074703eddeef6  vmovaps xmm2, [rsp+0x20]
000074703eddeefc  vmovaps xmm3, [rsp+0x30]
000074703eddef02  vmovaps xmm5, [rsp+0x40]
000074703eddef08  vmovaps xmm6, [rsp+0x50]
000074703eddef0e  vmovaps xmm7, [rsp+0x60]
000074703eddef14  vmovaps xmm8, [rsp+0x70]
000074703eddef1a  vmovaps xmm9, [rsp+0x80]
000074703eddef23  vmovaps xmm10, [rsp+0x90]
000074703eddef2c  vmovaps xmm11, [rsp+0xA0]
000074703eddef35  vmovaps xmm12, [rsp+0xB0]
000074703eddef3e  vmovaps xmm13, [rsp+0xC0]
000074703eddef47  vmovaps xmm14, [rsp+0xD0]
000074703eddef50  vmovaps xmm15, [rsp+0xE0]
000074703eddef59  add rsp, 0xF0
000074703eddef60  pop r11
000074703eddef62  pop r10
000074703eddef64  pop r9
000074703eddef66  pop r8
000074703eddef68  pop rsi
000074703eddef69  pop rdi
000074703eddef6a  pop rdx
000074703eddef6b  pop rcx
000074703eddef6c  pop rax
000074703eddef6d  add rsp, 0x08
000074703eddef71  jmp 0x000074703EDDC31E
000074703eddef76  sub rsp, 0x08
000074703eddef7a  push rax
000074703eddef7b  push rcx
000074703eddef7c  push rdx
000074703eddef7d  push rdi
000074703eddef7e  push rsi
000074703eddef7f  push r8
000074703eddef81  push r9
000074703eddef83  push r10
000074703eddef85  push r11
000074703eddef87  sub rsp, 0xF0
000074703eddef8e  vmovaps [rsp], xmm0
000074703eddef93  vmovaps [rsp+0x10], xmm1
000074703eddef99  vmovaps [rsp+0x20], xmm2
000074703eddef9f  vmovaps [rsp+0x30], xmm3
000074703eddefa5  vmovaps [rsp+0x40], xmm4
000074703eddefab  vmovaps [rsp+0x50], xmm5
000074703eddefb1  vmovaps [rsp+0x60], xmm6
000074703eddefb7  vmovaps [rsp+0x70], xmm7
000074703eddefbd  vmovaps [rsp+0x80], xmm8
000074703eddefc6  vmovaps [rsp+0x90], xmm10
000074703eddefcf  vmovaps [rsp+0xA0], xmm11
000074703eddefd8  vmovaps [rsp+0xB0], xmm12
000074703eddefe1  vmovaps [rsp+0xC0], xmm13
000074703eddefea  vmovaps [rsp+0xD0], xmm14
000074703eddeff3  vmovaps [rsp+0xE0], xmm15
000074703eddeffc  sub rsp, 0x30
000074703eddf000  movaps [rsp], xmm9
000074703eddf005  movaps [rsp+0x10], xmm2
000074703eddf00a  movaps [rsp+0x20], xmm1
000074703eddf00f  lea rdi, [rsp]
000074703eddf013  mov esi, 0x00
000074703eddf018  mov rax, 0x5D9974CCC530
000074703eddf022  call rax
000074703eddf024  movaps xmm9, [rsp]
000074703eddf029  add rsp, 0x30
000074703eddf02d  vmovaps xmm0, [rsp]
000074703eddf032  vmovaps xmm1, [rsp+0x10]
000074703eddf038  vmovaps xmm2, [rsp+0x20]
000074703eddf03e  vmovaps xmm3, [rsp+0x30]
000074703eddf044  vmovaps xmm4, [rsp+0x40]
000074703eddf04a  vmovaps xmm5, [rsp+0x50]
000074703eddf050  vmovaps xmm6, [rsp+0x60]
000074703eddf056  vmovaps xmm7, [rsp+0x70]
000074703eddf05c  vmovaps xmm8, [rsp+0x80]
000074703eddf065  vmovaps xmm10, [rsp+0x90]
000074703eddf06e  vmovaps xmm11, [rsp+0xA0]
000074703eddf077  vmovaps xmm12, [rsp+0xB0]
000074703eddf080  vmovaps xmm13, [rsp+0xC0]
000074703eddf089  vmovaps xmm14, [rsp+0xD0]
000074703eddf092  vmovaps xmm15, [rsp+0xE0]
000074703eddf09b  add rsp, 0xF0
000074703eddf0a2  pop r11
000074703eddf0a4  pop r10
000074703eddf0a6  pop r9
000074703eddf0a8  pop r8
000074703eddf0aa  pop rsi
000074703eddf0ab  pop rdi
000074703eddf0ac  pop rdx
000074703eddf0ad  pop rcx
000074703eddf0ae  pop rax
000074703eddf0af  add rsp, 0x08
000074703eddf0b3  jmp 0x000074703EDDC354
000074703eddf0b8  sub rsp, 0x08
000074703eddf0bc  push rax
000074703eddf0bd  push rcx
000074703eddf0be  push rdx
000074703eddf0bf  push rdi
000074703eddf0c0  push rsi
000074703eddf0c1  push r8
000074703eddf0c3  push r9
000074703eddf0c5  push r10
000074703eddf0c7  push r11
000074703eddf0c9  sub rsp, 0xF0
000074703eddf0d0  vmovaps [rsp], xmm0
000074703eddf0d5  vmovaps [rsp+0x10], xmm2
000074703eddf0db  vmovaps [rsp+0x20], xmm3
000074703eddf0e1  vmovaps [rsp+0x30], xmm4
000074703eddf0e7  vmovaps [rsp+0x40], xmm5
000074703eddf0ed  vmovaps [rsp+0x50], xmm6
000074703eddf0f3  vmovaps [rsp+0x60], xmm7
000074703eddf0f9  vmovaps [rsp+0x70], xmm8
000074703eddf0ff  vmovaps [rsp+0x80], xmm9
000074703eddf108  vmovaps [rsp+0x90], xmm10
000074703eddf111  vmovaps [rsp+0xA0], xmm11
000074703eddf11a  vmovaps [rsp+0xB0], xmm12
000074703eddf123  vmovaps [rsp+0xC0], xmm13
000074703eddf12c  vmovaps [rsp+0xD0], xmm14
000074703eddf135  vmovaps [rsp+0xE0], xmm15
000074703eddf13e  sub rsp, 0x30
000074703eddf142  movaps [rsp], xmm1
000074703eddf146  movaps [rsp+0x10], xmm15
000074703eddf14c  movaps [rsp+0x20], xmm6
000074703eddf151  lea rdi, [rsp]
000074703eddf155  mov esi, 0x00
000074703eddf15a  mov rax, 0x5D9974CCC530
000074703eddf164  call rax
000074703eddf166  movaps xmm1, [rsp]
000074703eddf16a  add rsp, 0x30
000074703eddf16e  vmovaps xmm0, [rsp]
000074703eddf173  vmovaps xmm2, [rsp+0x10]
000074703eddf179  vmovaps xmm3, [rsp+0x20]
000074703eddf17f  vmovaps xmm4, [rsp+0x30]
000074703eddf185  vmovaps xmm5, [rsp+0x40]
000074703eddf18b  vmovaps xmm6, [rsp+0x50]
000074703eddf191  vmovaps xmm7, [rsp+0x60]
000074703eddf197  vmovaps xmm8, [rsp+0x70]
000074703eddf19d  vmovaps xmm9, [rsp+0x80]
000074703eddf1a6  vmovaps xmm10, [rsp+0x90]
000074703eddf1af  vmovaps xmm11, [rsp+0xA0]
000074703eddf1b8  vmovaps xmm12, [rsp+0xB0]
000074703eddf1c1  vmovaps xmm13, [rsp+0xC0]
000074703eddf1ca  vmovaps xmm14, [rsp+0xD0]
000074703eddf1d3  vmovaps xmm15, [rsp+0xE0]
000074703eddf1dc  add rsp, 0xF0
000074703eddf1e3  pop r11
000074703eddf1e5  pop r10
000074703eddf1e7  pop r9
000074703eddf1e9  pop r8
000074703eddf1eb  pop rsi
000074703eddf1ec  pop rdi
000074703eddf1ed  pop rdx
000074703eddf1ee  pop rcx
000074703eddf1ef  pop rax
000074703eddf1f0  add rsp, 0x08
000074703eddf1f4  jmp 0x000074703EDDC375
000074703eddf1f9  sub rsp, 0x08
000074703eddf1fd  push rax
000074703eddf1fe  push rcx
000074703eddf1ff  push rdx
000074703eddf200  push rdi
000074703eddf201  push rsi
000074703eddf202  push r8
000074703eddf204  push r9
000074703eddf206  push r10
000074703eddf208  push r11
000074703eddf20a  sub rsp, 0xF0
000074703eddf211  vmovaps [rsp], xmm0
000074703eddf216  vmovaps [rsp+0x10], xmm1
000074703eddf21c  vmovaps [rsp+0x20], xmm2
000074703eddf222  vmovaps [rsp+0x30], xmm3
000074703eddf228  vmovaps [rsp+0x40], xmm4
000074703eddf22e  vmovaps [rsp+0x50], xmm5
000074703eddf234  vmovaps [rsp+0x60], xmm6
000074703eddf23a  vmovaps [rsp+0x70], xmm7
000074703eddf240  vmovaps [rsp+0x80], xmm8
000074703eddf249  vmovaps [rsp+0x90], xmm9
000074703eddf252  vmovaps [rsp+0xA0], xmm10
000074703eddf25b  vmovaps [rsp+0xB0], xmm11
000074703eddf264  vmovaps [rsp+0xC0], xmm12
000074703eddf26d  vmovaps [rsp+0xD0], xmm13
000074703eddf276  vmovaps [rsp+0xE0], xmm14
000074703eddf27f  sub rsp, 0x30
000074703eddf283  movaps [rsp], xmm15
000074703eddf288  movaps [rsp+0x10], xmm5
000074703eddf28d  movaps [rsp+0x20], xmm3
000074703eddf292  lea rdi, [rsp]
000074703eddf296  mov esi, 0x00
000074703eddf29b  mov rax, 0x5D9974CCC530
000074703eddf2a5  call rax
000074703eddf2a7  movaps xmm15, [rsp]
000074703eddf2ac  add rsp, 0x30
000074703eddf2b0  vmovaps xmm0, [rsp]
000074703eddf2b5  vmovaps xmm1, [rsp+0x10]
000074703eddf2bb  vmovaps xmm2, [rsp+0x20]
000074703eddf2c1  vmovaps xmm3, [rsp+0x30]
000074703eddf2c7  vmovaps xmm4, [rsp+0x40]
000074703eddf2cd  vmovaps xmm5, [rsp+0x50]
000074703eddf2d3  vmovaps xmm6, [rsp+0x60]
000074703eddf2d9  vmovaps xmm7, [rsp+0x70]
000074703eddf2df  vmovaps xmm8, [rsp+0x80]
000074703eddf2e8  vmovaps xmm9, [rsp+0x90]
000074703eddf2f1  vmovaps xmm10, [rsp+0xA0]
000074703eddf2fa  vmovaps xmm11, [rsp+0xB0]
000074703eddf303  vmovaps xmm12, [rsp+0xC0]
000074703eddf30c  vmovaps xmm13, [rsp+0xD0]
000074703eddf315  vmovaps xmm14, [rsp+0xE0]
000074703eddf31e  add rsp, 0xF0
000074703eddf325  pop r11
000074703eddf327  pop r10
000074703eddf329  pop r9
000074703eddf32b  pop r8
000074703eddf32d  pop rsi
000074703eddf32e  pop rdi
000074703eddf32f  pop rdx
000074703eddf330  pop rcx
000074703eddf331  pop rax
000074703eddf332  add rsp, 0x08
000074703eddf336  jmp 0x000074703EDDC38F
000074703eddf33b  sub rsp, 0x08
000074703eddf33f  push rax
000074703eddf340  push rcx
000074703eddf341  push rdx
000074703eddf342  push rdi
000074703eddf343  push rsi
000074703eddf344  push r8
000074703eddf346  push r9
000074703eddf348  push r10
000074703eddf34a  push r11
000074703eddf34c  sub rsp, 0xF0
000074703eddf353  vmovaps [rsp], xmm0
000074703eddf358  vmovaps [rsp+0x10], xmm1
000074703eddf35e  vmovaps [rsp+0x20], xmm2
000074703eddf364  vmovaps [rsp+0x30], xmm3
000074703eddf36a  vmovaps [rsp+0x40], xmm4
000074703eddf370  vmovaps [rsp+0x50], xmm6
000074703eddf376  vmovaps [rsp+0x60], xmm7
000074703eddf37c  vmovaps [rsp+0x70], xmm8
000074703eddf382  vmovaps [rsp+0x80], xmm9
000074703eddf38b  vmovaps [rsp+0x90], xmm10
000074703eddf394  vmovaps [rsp+0xA0], xmm11
000074703eddf39d  vmovaps [rsp+0xB0], xmm12
000074703eddf3a6  vmovaps [rsp+0xC0], xmm13
000074703eddf3af  vmovaps [rsp+0xD0], xmm14
000074703eddf3b8  vmovaps [rsp+0xE0], xmm15
000074703eddf3c1  sub rsp, 0x30
000074703eddf3c5  movaps [rsp], xmm5
000074703eddf3c9  movaps [rsp+0x10], xmm8
000074703eddf3cf  movaps [rsp+0x20], xmm6
000074703eddf3d4  lea rdi, [rsp]
000074703eddf3d8  mov esi, 0x00
000074703eddf3dd  mov rax, 0x5D9974CCC530
000074703eddf3e7  call rax
000074703eddf3e9  movaps xmm5, [rsp]
000074703eddf3ed  add rsp, 0x30
000074703eddf3f1  vmovaps xmm0, [rsp]
000074703eddf3f6  vmovaps xmm1, [rsp+0x10]
000074703eddf3fc  vmovaps xmm2, [rsp+0x20]
000074703eddf402  vmovaps xmm3, [rsp+0x30]
000074703eddf408  vmovaps xmm4, [rsp+0x40]
000074703eddf40e  vmovaps xmm6, [rsp+0x50]
000074703eddf414  vmovaps xmm7, [rsp+0x60]
000074703eddf41a  vmovaps xmm8, [rsp+0x70]
000074703eddf420  vmovaps xmm9, [rsp+0x80]
000074703eddf429  vmovaps xmm10, [rsp+0x90]
000074703eddf432  vmovaps xmm11, [rsp+0xA0]
000074703eddf43b  vmovaps xmm12, [rsp+0xB0]
000074703eddf444  vmovaps xmm13, [rsp+0xC0]
000074703eddf44d  vmovaps xmm14, [rsp+0xD0]
000074703eddf456  vmovaps xmm15, [rsp+0xE0]
000074703eddf45f  add rsp, 0xF0
000074703eddf466  pop r11
000074703eddf468  pop r10
000074703eddf46a  pop r9
000074703eddf46c  pop r8
000074703eddf46e  pop rsi
000074703eddf46f  pop rdi
000074703eddf470  pop rdx
000074703eddf471  pop rcx
000074703eddf472  pop rax
000074703eddf473  add rsp, 0x08
000074703eddf477  jmp 0x000074703EDDC3B3
000074703eddf47c  sub rsp, 0x08
000074703eddf480  push rax
000074703eddf481  push rcx
000074703eddf482  push rdx
000074703eddf483  push rdi
000074703eddf484  push rsi
000074703eddf485  push r8
000074703eddf487  push r9
000074703eddf489  push r10
000074703eddf48b  push r11
000074703eddf48d  sub rsp, 0xF0
000074703eddf494  vmovaps [rsp], xmm0
000074703eddf499  vmovaps [rsp+0x10], xmm1
000074703eddf49f  vmovaps [rsp+0x20], xmm2
000074703eddf4a5  vmovaps [rsp+0x30], xmm3
000074703eddf4ab  vmovaps [rsp+0x40], xmm4
000074703eddf4b1  vmovaps [rsp+0x50], xmm5
000074703eddf4b7  vmovaps [rsp+0x60], xmm7
000074703eddf4bd  vmovaps [rsp+0x70], xmm8
000074703eddf4c3  vmovaps [rsp+0x80], xmm9
000074703eddf4cc  vmovaps [rsp+0x90], xmm10
000074703eddf4d5  vmovaps [rsp+0xA0], xmm11
000074703eddf4de  vmovaps [rsp+0xB0], xmm12
000074703eddf4e7  vmovaps [rsp+0xC0], xmm13
000074703eddf4f0  vmovaps [rsp+0xD0], xmm14
000074703eddf4f9  vmovaps [rsp+0xE0], xmm15
000074703eddf502  sub rsp, 0x30
000074703eddf506  movaps [rsp], xmm6
000074703eddf50a  movaps [rsp+0x10], xmm10
000074703eddf510  movaps [rsp+0x20], xmm8
000074703eddf516  lea rdi, [rsp]
000074703eddf51a  mov esi, 0x00
000074703eddf51f  mov rax, 0x5D9974CCC530
000074703eddf529  call rax
000074703eddf52b  movaps xmm6, [rsp]
000074703eddf52f  add rsp, 0x30
000074703eddf533  vmovaps xmm0, [rsp]
000074703eddf538  vmovaps xmm1, [rsp+0x10]
000074703eddf53e  vmovaps xmm2, [rsp+0x20]
000074703eddf544  vmovaps xmm3, [rsp+0x30]
000074703eddf54a  vmovaps xmm4, [rsp+0x40]
000074703eddf550  vmovaps xmm5, [rsp+0x50]
000074703eddf556  vmovaps xmm7, [rsp+0x60]
000074703eddf55c  vmovaps xmm8, [rsp+0x70]
000074703eddf562  vmovaps xmm9, [rsp+0x80]
000074703eddf56b  vmovaps xmm10, [rsp+0x90]
000074703eddf574  vmovaps xmm11, [rsp+0xA0]
000074703eddf57d  vmovaps xmm12, [rsp+0xB0]
000074703eddf586  vmovaps xmm13, [rsp+0xC0]
000074703eddf58f  vmovaps xmm14, [rsp+0xD0]
000074703eddf598  vmovaps xmm15, [rsp+0xE0]
000074703eddf5a1  add rsp, 0xF0
000074703eddf5a8  pop r11
000074703eddf5aa  pop r10
000074703eddf5ac  pop r9
000074703eddf5ae  pop r8
000074703eddf5b0  pop rsi
000074703eddf5b1  pop rdi
000074703eddf5b2  pop rdx
000074703eddf5b3  pop rcx
000074703eddf5b4  pop rax
000074703eddf5b5  add rsp, 0x08
000074703eddf5b9  jmp 0x000074703EDDC3D8
000074703eddf5be  sub rsp, 0x08
000074703eddf5c2  push rax
000074703eddf5c3  push rcx
000074703eddf5c4  push rdx
000074703eddf5c5  push rdi
000074703eddf5c6  push rsi
000074703eddf5c7  push r8
000074703eddf5c9  push r9
000074703eddf5cb  push r10
000074703eddf5cd  push r11
000074703eddf5cf  sub rsp, 0xF0
000074703eddf5d6  vmovaps [rsp], xmm0
000074703eddf5db  vmovaps [rsp+0x10], xmm1
000074703eddf5e1  vmovaps [rsp+0x20], xmm2
000074703eddf5e7  vmovaps [rsp+0x30], xmm3
000074703eddf5ed  vmovaps [rsp+0x40], xmm4
000074703eddf5f3  vmovaps [rsp+0x50], xmm5
000074703eddf5f9  vmovaps [rsp+0x60], xmm6
000074703eddf5ff  vmovaps [rsp+0x70], xmm7
000074703eddf605  vmovaps [rsp+0x80], xmm8
000074703eddf60e  vmovaps [rsp+0x90], xmm9
000074703eddf617  vmovaps [rsp+0xA0], xmm11
000074703eddf620  vmovaps [rsp+0xB0], xmm12
000074703eddf629  vmovaps [rsp+0xC0], xmm13
000074703eddf632  vmovaps [rsp+0xD0], xmm14
000074703eddf63b  vmovaps [rsp+0xE0], xmm15
000074703eddf644  sub rsp, 0x30
000074703eddf648  movaps [rsp], xmm10
000074703eddf64d  movaps [rsp+0x10], xmm8
000074703eddf653  movaps [rsp+0x20], xmm14
000074703eddf659  lea rdi, [rsp]
000074703eddf65d  mov esi, 0x00
000074703eddf662  mov rax, 0x5D9974CCC530
000074703eddf66c  call rax
000074703eddf66e  movaps xmm10, [rsp]
000074703eddf673  add rsp, 0x30
000074703eddf677  vmovaps xmm0, [rsp]
000074703eddf67c  vmovaps xmm1, [rsp+0x10]
000074703eddf682  vmovaps xmm2, [rsp+0x20]
000074703eddf688  vmovaps xmm3, [rsp+0x30]
000074703eddf68e  vmovaps xmm4, [rsp+0x40]
000074703eddf694  vmovaps xmm5, [rsp+0x50]
000074703eddf69a  vmovaps xmm6, [rsp+0x60]
000074703eddf6a0  vmovaps xmm7, [rsp+0x70]
000074703eddf6a6  vmovaps xmm8, [rsp+0x80]
000074703eddf6af  vmovaps xmm9, [rsp+0x90]
000074703eddf6b8  vmovaps xmm11, [rsp+0xA0]
000074703eddf6c1  vmovaps xmm12, [rsp+0xB0]
000074703eddf6ca  vmovaps xmm13, [rsp+0xC0]
000074703eddf6d3  vmovaps xmm14, [rsp+0xD0]
000074703eddf6dc  vmovaps xmm15, [rsp+0xE0]
000074703eddf6e5  add rsp, 0xF0
000074703eddf6ec  pop r11
000074703eddf6ee  pop r10
000074703eddf6f0  pop r9
000074703eddf6f2  pop r8
000074703eddf6f4  pop rsi
000074703eddf6f5  pop rdi
000074703eddf6f6  pop rdx
000074703eddf6f7  pop rcx
000074703eddf6f8  pop rax
000074703eddf6f9  add rsp, 0x08
000074703eddf6fd  jmp 0x000074703EDDC3F8
000074703eddf702  sub rsp, 0x08
000074703eddf706  push rax
000074703eddf707  push rcx
000074703eddf708  push rdx
000074703eddf709  push rdi
000074703eddf70a  push rsi
000074703eddf70b  push r8
000074703eddf70d  push r9
000074703eddf70f  push r10
000074703eddf711  push r11
000074703eddf713  sub rsp, 0xF0
000074703eddf71a  vmovaps [rsp], xmm0
000074703eddf71f  vmovaps [rsp+0x10], xmm1
000074703eddf725  vmovaps [rsp+0x20], xmm2
000074703eddf72b  vmovaps [rsp+0x30], xmm3
000074703eddf731  vmovaps [rsp+0x40], xmm4
000074703eddf737  vmovaps [rsp+0x50], xmm5
000074703eddf73d  vmovaps [rsp+0x60], xmm6
000074703eddf743  vmovaps [rsp+0x70], xmm7
000074703eddf749  vmovaps [rsp+0x80], xmm8
000074703eddf752  vmovaps [rsp+0x90], xmm9
000074703eddf75b  vmovaps [rsp+0xA0], xmm10
000074703eddf764  vmovaps [rsp+0xB0], xmm11
000074703eddf76d  vmovaps [rsp+0xC0], xmm12
000074703eddf776  vmovaps [rsp+0xD0], xmm13
000074703eddf77f  vmovaps [rsp+0xE0], xmm15
000074703eddf788  sub rsp, 0x30
000074703eddf78c  movaps [rsp], xmm14
000074703eddf791  movaps [rsp+0x10], xmm8
000074703eddf797  movaps [rsp+0x20], xmm4
000074703eddf79c  lea rdi, [rsp]
000074703eddf7a0  mov esi, 0x00
000074703eddf7a5  mov rax, 0x5D9974CCC530
000074703eddf7af  call rax
000074703eddf7b1  movaps xmm14, [rsp]
000074703eddf7b6  add rsp, 0x30
000074703eddf7ba  vmovaps xmm0, [rsp]
000074703eddf7bf  vmovaps xmm1, [rsp+0x10]
000074703eddf7c5  vmovaps xmm2, [rsp+0x20]
000074703eddf7cb  vmovaps xmm3, [rsp+0x30]
000074703eddf7d1  vmovaps xmm4, [rsp+0x40]
000074703eddf7d7  vmovaps xmm5, [rsp+0x50]
000074703eddf7dd  vmovaps xmm6, [rsp+0x60]
000074703eddf7e3  vmovaps xmm7, [rsp+0x70]
000074703eddf7e9  vmovaps xmm8, [rsp+0x80]
000074703eddf7f2  vmovaps xmm9, [rsp+0x90]
000074703eddf7fb  vmovaps xmm10, [rsp+0xA0]
000074703eddf804  vmovaps xmm11, [rsp+0xB0]
000074703eddf80d  vmovaps xmm12, [rsp+0xC0]
000074703eddf816  vmovaps xmm13, [rsp+0xD0]
000074703eddf81f  vmovaps xmm15, [rsp+0xE0]
000074703eddf828  add rsp, 0xF0
000074703eddf82f  pop r11
000074703eddf831  pop r10
000074703eddf833  pop r9
000074703eddf835  pop r8
000074703eddf837  pop rsi
000074703eddf838  pop rdi
000074703eddf839  pop rdx
000074703eddf83a  pop rcx
000074703eddf83b  pop rax
000074703eddf83c  add rsp, 0x08
000074703eddf840  jmp 0x000074703EDDC418
000074703eddf845  sub rsp, 0x08
000074703eddf849  push rax
000074703eddf84a  push rcx
000074703eddf84b  push rdx
000074703eddf84c  push rdi
000074703eddf84d  push rsi
000074703eddf84e  push r8
000074703eddf850  push r9
000074703eddf852  push r10
000074703eddf854  push r11
000074703eddf856  sub rsp, 0xF0
000074703eddf85d  vmovaps [rsp], xmm0
000074703eddf862  vmovaps [rsp+0x10], xmm1
000074703eddf868  vmovaps [rsp+0x20], xmm2
000074703eddf86e  vmovaps [rsp+0x30], xmm3
000074703eddf874  vmovaps [rsp+0x40], xmm5
000074703eddf87a  vmovaps [rsp+0x50], xmm6
000074703eddf880  vmovaps [rsp+0x60], xmm7
000074703eddf886  vmovaps [rsp+0x70], xmm8
000074703eddf88c  vmovaps [rsp+0x80], xmm9
000074703eddf895  vmovaps [rsp+0x90], xmm10
000074703eddf89e  vmovaps [rsp+0xA0], xmm11
000074703eddf8a7  vmovaps [rsp+0xB0], xmm12
000074703eddf8b0  vmovaps [rsp+0xC0], xmm13
000074703eddf8b9  vmovaps [rsp+0xD0], xmm14
000074703eddf8c2  vmovaps [rsp+0xE0], xmm15
000074703eddf8cb  sub rsp, 0x30
000074703eddf8cf  movaps [rsp], xmm4
000074703eddf8d3  movaps [rsp+0x10], xmm13
000074703eddf8d9  movaps [rsp+0x20], xmm8
000074703eddf8df  lea rdi, [rsp]
000074703eddf8e3  mov esi, 0x00
000074703eddf8e8  mov rax, 0x5D9974CCC530
000074703eddf8f2  call rax
000074703eddf8f4  movaps xmm4, [rsp]
000074703eddf8f8  add rsp, 0x30
000074703eddf8fc  vmovaps xmm0, [rsp]
000074703eddf901  vmovaps xmm1, [rsp+0x10]
000074703eddf907  vmovaps xmm2, [rsp+0x20]
000074703eddf90d  vmovaps xmm3, [rsp+0x30]
000074703eddf913  vmovaps xmm5, [rsp+0x40]
000074703eddf919  vmovaps xmm6, [rsp+0x50]
000074703eddf91f  vmovaps xmm7, [rsp+0x60]
000074703eddf925  vmovaps xmm8, [rsp+0x70]
000074703eddf92b  vmovaps xmm9, [rsp+0x80]
000074703eddf934  vmovaps xmm10, [rsp+0x90]
000074703eddf93d  vmovaps xmm11, [rsp+0xA0]
000074703eddf946  vmovaps xmm12, [rsp+0xB0]
000074703eddf94f  vmovaps xmm13, [rsp+0xC0]
000074703eddf958  vmovaps xmm14, [rsp+0xD0]
000074703eddf961  vmovaps xmm15, [rsp+0xE0]
000074703eddf96a  add rsp, 0xF0
000074703eddf971  pop r11
000074703eddf973  pop r10
000074703eddf975  pop r9
000074703eddf977  pop r8
000074703eddf979  pop rsi
000074703eddf97a  pop rdi
000074703eddf97b  pop rdx
000074703eddf97c  pop rcx
000074703eddf97d  pop rax
000074703eddf97e  add rsp, 0x08
000074703eddf982  jmp 0x000074703EDDC43D
000074703eddf987  sub rsp, 0x08
000074703eddf98b  push rax
000074703eddf98c  push rcx
000074703eddf98d  push rdx
000074703eddf98e  push rdi
000074703eddf98f  push rsi
000074703eddf990  push r8
000074703eddf992  push r9
000074703eddf994  push r10
000074703eddf996  push r11
000074703eddf998  sub rsp, 0xF0
000074703eddf99f  vmovaps [rsp], xmm0
000074703eddf9a4  vmovaps [rsp+0x10], xmm1
000074703eddf9aa  vmovaps [rsp+0x20], xmm2
000074703eddf9b0  vmovaps [rsp+0x30], xmm3
000074703eddf9b6  vmovaps [rsp+0x40], xmm4
000074703eddf9bc  vmovaps [rsp+0x50], xmm5
000074703eddf9c2  vmovaps [rsp+0x60], xmm6
000074703eddf9c8  vmovaps [rsp+0x70], xmm7
000074703eddf9ce  vmovaps [rsp+0x80], xmm8
000074703eddf9d7  vmovaps [rsp+0x90], xmm9
000074703eddf9e0  vmovaps [rsp+0xA0], xmm10
000074703eddf9e9  vmovaps [rsp+0xB0], xmm11
000074703eddf9f2  vmovaps [rsp+0xC0], xmm12
000074703eddf9fb  vmovaps [rsp+0xD0], xmm14
000074703eddfa04  vmovaps [rsp+0xE0], xmm15
000074703eddfa0d  sub rsp, 0x30
000074703eddfa11  movaps [rsp], xmm13
000074703eddfa16  movaps [rsp+0x10], xmm15
000074703eddfa1c  movaps [rsp+0x20], xmm9
000074703eddfa22  lea rdi, [rsp]
000074703eddfa26  mov esi, 0x00
000074703eddfa2b  mov rax, 0x5D9974CCC530
000074703eddfa35  call rax
000074703eddfa37  movaps xmm13, [rsp]
000074703eddfa3c  add rsp, 0x30
000074703eddfa40  vmovaps xmm0, [rsp]
000074703eddfa45  vmovaps xmm1, [rsp+0x10]
000074703eddfa4b  vmovaps xmm2, [rsp+0x20]
000074703eddfa51  vmovaps xmm3, [rsp+0x30]
000074703eddfa57  vmovaps xmm4, [rsp+0x40]
000074703eddfa5d  vmovaps xmm5, [rsp+0x50]
000074703eddfa63  vmovaps xmm6, [rsp+0x60]
000074703eddfa69  vmovaps xmm7, [rsp+0x70]
000074703eddfa6f  vmovaps xmm8, [rsp+0x80]
000074703eddfa78  vmovaps xmm9, [rsp+0x90]
000074703eddfa81  vmovaps xmm10, [rsp+0xA0]
000074703eddfa8a  vmovaps xmm11, [rsp+0xB0]
000074703eddfa93  vmovaps xmm12, [rsp+0xC0]
000074703eddfa9c  vmovaps xmm14, [rsp+0xD0]
000074703eddfaa5  vmovaps xmm15, [rsp+0xE0]
000074703eddfaae  add rsp, 0xF0
000074703eddfab5  pop r11
000074703eddfab7  pop r10
000074703eddfab9  pop r9
000074703eddfabb  pop r8
000074703eddfabd  pop rsi
000074703eddfabe  pop rdi
000074703eddfabf  pop rdx
000074703eddfac0  pop rcx
000074703eddfac1  pop rax
000074703eddfac2  add rsp, 0x08
000074703eddfac6  jmp 0x000074703EDDC458
000074703eddfacb  sub rsp, 0x08
000074703eddfacf  push rax
000074703eddfad0  push rcx
000074703eddfad1  push rdx
000074703eddfad2  push rdi
000074703eddfad3  push rsi
000074703eddfad4  push r8
000074703eddfad6  push r9
000074703eddfad8  push r10
000074703eddfada  push r11
000074703eddfadc  sub rsp, 0xF0
000074703eddfae3  vmovaps [rsp], xmm0
000074703eddfae8  vmovaps [rsp+0x10], xmm1
000074703eddfaee  vmovaps [rsp+0x20], xmm2
000074703eddfaf4  vmovaps [rsp+0x30], xmm3
000074703eddfafa  vmovaps [rsp+0x40], xmm4
000074703eddfb00  vmovaps [rsp+0x50], xmm5
000074703eddfb06  vmovaps [rsp+0x60], xmm6
000074703eddfb0c  vmovaps [rsp+0x70], xmm7
000074703eddfb12  vmovaps [rsp+0x80], xmm8
000074703eddfb1b  vmovaps [rsp+0x90], xmm9
000074703eddfb24  vmovaps [rsp+0xA0], xmm10
000074703eddfb2d  vmovaps [rsp+0xB0], xmm11
000074703eddfb36  vmovaps [rsp+0xC0], xmm12
000074703eddfb3f  vmovaps [rsp+0xD0], xmm13
000074703eddfb48  vmovaps [rsp+0xE0], xmm14
000074703eddfb51  sub rsp, 0x30
000074703eddfb55  movaps [rsp], xmm15
000074703eddfb5a  movaps [rsp+0x10], xmm1
000074703eddfb5f  movaps [rsp+0x20], xmm5
000074703eddfb64  lea rdi, [rsp]
000074703eddfb68  mov esi, 0x00
000074703eddfb6d  mov rax, 0x5D9974CCC530
000074703eddfb77  call rax
000074703eddfb79  movaps xmm15, [rsp]
000074703eddfb7e  add rsp, 0x30
000074703eddfb82  vmovaps xmm0, [rsp]
000074703eddfb87  vmovaps xmm1, [rsp+0x10]
000074703eddfb8d  vmovaps xmm2, [rsp+0x20]
000074703eddfb93  vmovaps xmm3, [rsp+0x30]
000074703eddfb99  vmovaps xmm4, [rsp+0x40]
000074703eddfb9f  vmovaps xmm5, [rsp+0x50]
000074703eddfba5  vmovaps xmm6, [rsp+0x60]
000074703eddfbab  vmovaps xmm7, [rsp+0x70]
000074703eddfbb1  vmovaps xmm8, [rsp+0x80]
000074703eddfbba  vmovaps xmm9, [rsp+0x90]
000074703eddfbc3  vmovaps xmm10, [rsp+0xA0]
000074703eddfbcc  vmovaps xmm11, [rsp+0xB0]
000074703eddfbd5  vmovaps xmm12, [rsp+0xC0]
000074703eddfbde  vmovaps xmm13, [rsp+0xD0]
000074703eddfbe7  vmovaps xmm14, [rsp+0xE0]
000074703eddfbf0  add rsp, 0xF0
000074703eddfbf7  pop r11
000074703eddfbf9  pop r10
000074703eddfbfb  pop r9
000074703eddfbfd  pop r8
000074703eddfbff  pop rsi
000074703eddfc00  pop rdi
000074703eddfc01  pop rdx
000074703eddfc02  pop rcx
000074703eddfc03  pop rax
000074703eddfc04  add rsp, 0x08
000074703eddfc08  jmp 0x000074703EDDC473
000074703eddfc0d  call 0x000074703ECB52F0
000074703eddfc12  jmp 0x000074703EDDC4CE
000074703eddfc17  sub rsp, 0x08
000074703eddfc1b  push rax
000074703eddfc1c  push rcx
000074703eddfc1d  push rdx
000074703eddfc1e  push rdi
000074703eddfc1f  push rsi
000074703eddfc20  push r8
000074703eddfc22  push r9
000074703eddfc24  push r10
000074703eddfc26  push r11
000074703eddfc28  sub rsp, 0xF0
000074703eddfc2f  vmovaps [rsp], xmm0
000074703eddfc34  vmovaps [rsp+0x10], xmm1
000074703eddfc3a  vmovaps [rsp+0x20], xmm2
000074703eddfc40  vmovaps [rsp+0x30], xmm3
000074703eddfc46  vmovaps [rsp+0x40], xmm4
000074703eddfc4c  vmovaps [rsp+0x50], xmm5
000074703eddfc52  vmovaps [rsp+0x60], xmm6
000074703eddfc58  vmovaps [rsp+0x70], xmm7
000074703eddfc5e  vmovaps [rsp+0x80], xmm8
000074703eddfc67  vmovaps [rsp+0x90], xmm10
000074703eddfc70  vmovaps [rsp+0xA0], xmm11
000074703eddfc79  vmovaps [rsp+0xB0], xmm12
000074703eddfc82  vmovaps [rsp+0xC0], xmm13
000074703eddfc8b  vmovaps [rsp+0xD0], xmm14
000074703eddfc94  vmovaps [rsp+0xE0], xmm15
000074703eddfc9d  sub rsp, 0x30
000074703eddfca1  movaps [rsp], xmm9
000074703eddfca6  movaps [rsp+0x10], xmm8
000074703eddfcac  movaps [rsp+0x20], xmm11
000074703eddfcb2  lea rdi, [rsp]
000074703eddfcb6  mov esi, 0x00
000074703eddfcbb  mov rax, 0x5D9974CCC530
000074703eddfcc5  call rax
000074703eddfcc7  movaps xmm9, [rsp]
000074703eddfccc  add rsp, 0x30
000074703eddfcd0  vmovaps xmm0, [rsp]
000074703eddfcd5  vmovaps xmm1, [rsp+0x10]
000074703eddfcdb  vmovaps xmm2, [rsp+0x20]
000074703eddfce1  vmovaps xmm3, [rsp+0x30]
000074703eddfce7  vmovaps xmm4, [rsp+0x40]
000074703eddfced  vmovaps xmm5, [rsp+0x50]
000074703eddfcf3  vmovaps xmm6, [rsp+0x60]
000074703eddfcf9  vmovaps xmm7, [rsp+0x70]
000074703eddfcff  vmovaps xmm8, [rsp+0x80]
000074703eddfd08  vmovaps xmm10, [rsp+0x90]
000074703eddfd11  vmovaps xmm11, [rsp+0xA0]
000074703eddfd1a  vmovaps xmm12, [rsp+0xB0]
000074703eddfd23  vmovaps xmm13, [rsp+0xC0]
000074703eddfd2c  vmovaps xmm14, [rsp+0xD0]
000074703eddfd35  vmovaps xmm15, [rsp+0xE0]
000074703eddfd3e  add rsp, 0xF0
000074703eddfd45  pop r11
000074703eddfd47  pop r10
000074703eddfd49  pop r9
000074703eddfd4b  pop r8
000074703eddfd4d  pop rsi
000074703eddfd4e  pop rdi
000074703eddfd4f  pop rdx
000074703eddfd50  pop rcx
000074703eddfd51  pop rax
000074703eddfd52  add rsp, 0x08
000074703eddfd56  jmp 0x000074703EDDC505
000074703eddfd5b  sub rsp, 0x08
000074703eddfd5f  push rax
000074703eddfd60  push rcx
000074703eddfd61  push rdx
000074703eddfd62  push rdi
000074703eddfd63  push rsi
000074703eddfd64  push r8
000074703eddfd66  push r9
000074703eddfd68  push r10
000074703eddfd6a  push r11
000074703eddfd6c  sub rsp, 0xF0
000074703eddfd73  vmovaps [rsp], xmm0
000074703eddfd78  vmovaps [rsp+0x10], xmm1
000074703eddfd7e  vmovaps [rsp+0x20], xmm2
000074703eddfd84  vmovaps [rsp+0x30], xmm3
000074703eddfd8a  vmovaps [rsp+0x40], xmm4
000074703eddfd90  vmovaps [rsp+0x50], xmm5
000074703eddfd96  vmovaps [rsp+0x60], xmm6
000074703eddfd9c  vmovaps [rsp+0x70], xmm7
000074703eddfda2  vmovaps [rsp+0x80], xmm8
000074703eddfdab  vmovaps [rsp+0x90], xmm9
000074703eddfdb4  vmovaps [rsp+0xA0], xmm10
000074703eddfdbd  vmovaps [rsp+0xB0], xmm12
000074703eddfdc6  vmovaps [rsp+0xC0], xmm13
000074703eddfdcf  vmovaps [rsp+0xD0], xmm14
000074703eddfdd8  vmovaps [rsp+0xE0], xmm15
000074703eddfde1  sub rsp, 0x30
000074703eddfde5  movaps [rsp], xmm11
000074703eddfdea  movaps [rsp+0x10], xmm10
000074703eddfdf0  movaps [rsp+0x20], xmm6
000074703eddfdf5  lea rdi, [rsp]
000074703eddfdf9  mov esi, 0x00
000074703eddfdfe  mov rax, 0x5D9974CCC530
000074703eddfe08  call rax
000074703eddfe0a  movaps xmm11, [rsp]
000074703eddfe0f  add rsp, 0x30
000074703eddfe13  vmovaps xmm0, [rsp]
000074703eddfe18  vmovaps xmm1, [rsp+0x10]
000074703eddfe1e  vmovaps xmm2, [rsp+0x20]
000074703eddfe24  vmovaps xmm3, [rsp+0x30]
000074703eddfe2a  vmovaps xmm4, [rsp+0x40]
000074703eddfe30  vmovaps xmm5, [rsp+0x50]
000074703eddfe36  vmovaps xmm6, [rsp+0x60]
000074703eddfe3c  vmovaps xmm7, [rsp+0x70]
000074703eddfe42  vmovaps xmm8, [rsp+0x80]
000074703eddfe4b  vmovaps xmm9, [rsp+0x90]
000074703eddfe54  vmovaps xmm10, [rsp+0xA0]
000074703eddfe5d  vmovaps xmm12, [rsp+0xB0]
000074703eddfe66  vmovaps xmm13, [rsp+0xC0]
000074703eddfe6f  vmovaps xmm14, [rsp+0xD0]
000074703eddfe78  vmovaps xmm15, [rsp+0xE0]
000074703eddfe81  add rsp, 0xF0
000074703eddfe88  pop r11
000074703eddfe8a  pop r10
000074703eddfe8c  pop r9
000074703eddfe8e  pop r8
000074703eddfe90  pop rsi
000074703eddfe91  pop rdi
000074703eddfe92  pop rdx
000074703eddfe93  pop rcx
000074703eddfe94  pop rax
000074703eddfe95  add rsp, 0x08
000074703eddfe99  jmp 0x000074703EDDC520
000074703eddfe9e  sub rsp, 0x08
000074703eddfea2  push rax
000074703eddfea3  push rcx
000074703eddfea4  push rdx
000074703eddfea5  push rdi
000074703eddfea6  push rsi
000074703eddfea7  push r8
000074703eddfea9  push r9
000074703eddfeab  push r10
000074703eddfead  push r11
000074703eddfeaf  sub rsp, 0xF0
000074703eddfeb6  vmovaps [rsp], xmm0
000074703eddfebb  vmovaps [rsp+0x10], xmm1
000074703eddfec1  vmovaps [rsp+0x20], xmm2
000074703eddfec7  vmovaps [rsp+0x30], xmm3
000074703eddfecd  vmovaps [rsp+0x40], xmm4
000074703eddfed3  vmovaps [rsp+0x50], xmm5
000074703eddfed9  vmovaps [rsp+0x60], xmm6
000074703eddfedf  vmovaps [rsp+0x70], xmm7
000074703eddfee5  vmovaps [rsp+0x80], xmm8
000074703eddfeee  vmovaps [rsp+0x90], xmm9
000074703eddfef7  vmovaps [rsp+0xA0], xmm11
000074703eddff00  vmovaps [rsp+0xB0], xmm12
000074703eddff09  vmovaps [rsp+0xC0], xmm13
000074703eddff12  vmovaps [rsp+0xD0], xmm14
000074703eddff1b  vmovaps [rsp+0xE0], xmm15
000074703eddff24  sub rsp, 0x30
000074703eddff28  movaps [rsp], xmm10
000074703eddff2d  movaps [rsp+0x10], xmm14
000074703eddff33  movaps [rsp+0x20], xmm4
000074703eddff38  lea rdi, [rsp]
000074703eddff3c  mov esi, 0x00
000074703eddff41  mov rax, 0x5D9974CCC530
000074703eddff4b  call rax
000074703eddff4d  movaps xmm10, [rsp]
000074703eddff52  add rsp, 0x30
000074703eddff56  vmovaps xmm0, [rsp]
000074703eddff5b  vmovaps xmm1, [rsp+0x10]
000074703eddff61  vmovaps xmm2, [rsp+0x20]
000074703eddff67  vmovaps xmm3, [rsp+0x30]
000074703eddff6d  vmovaps xmm4, [rsp+0x40]
000074703eddff73  vmovaps xmm5, [rsp+0x50]
000074703eddff79  vmovaps xmm6, [rsp+0x60]
000074703eddff7f  vmovaps xmm7, [rsp+0x70]
000074703eddff85  vmovaps xmm8, [rsp+0x80]
000074703eddff8e  vmovaps xmm9, [rsp+0x90]
000074703eddff97  vmovaps xmm11, [rsp+0xA0]
000074703eddffa0  vmovaps xmm12, [rsp+0xB0]
000074703eddffa9  vmovaps xmm13, [rsp+0xC0]
000074703eddffb2  vmovaps xmm14, [rsp+0xD0]
000074703eddffbb  vmovaps xmm15, [rsp+0xE0]
000074703eddffc4  add rsp, 0xF0
000074703eddffcb  pop r11
000074703eddffcd  pop r10
000074703eddffcf  pop r9
000074703eddffd1  pop r8
000074703eddffd3  pop rsi
000074703eddffd4  pop rdi
000074703eddffd5  pop rdx
000074703eddffd6  pop rcx
000074703eddffd7  pop rax
000074703eddffd8  add rsp, 0x08
000074703eddffdc  jmp 0x000074703EDDC53B
000074703eddffe1  sub rsp, 0x08
000074703eddffe5  push rax
000074703eddffe6  push rcx
000074703eddffe7  push rdx
000074703eddffe8  push rdi
000074703eddffe9  push rsi
000074703eddffea  push r8
000074703eddffec  push r9
000074703eddffee  push r10
000074703eddfff0  push r11
000074703eddfff2  sub rsp, 0xF0
000074703eddfff9  vmovaps [rsp], xmm0
000074703eddfffe  vmovaps [rsp+0x10], xmm1
000074703ede0004  vmovaps [rsp+0x20], xmm2
000074703ede000a  vmovaps [rsp+0x30], xmm3
000074703ede0010  vmovaps [rsp+0x40], xmm4
000074703ede0016  vmovaps [rsp+0x50], xmm5
000074703ede001c  vmovaps [rsp+0x60], xmm6
000074703ede0022  vmovaps [rsp+0x70], xmm7
000074703ede0028  vmovaps [rsp+0x80], xmm9
000074703ede0031  vmovaps [rsp+0x90], xmm10
000074703ede003a  vmovaps [rsp+0xA0], xmm11
000074703ede0043  vmovaps [rsp+0xB0], xmm12
000074703ede004c  vmovaps [rsp+0xC0], xmm13
000074703ede0055  vmovaps [rsp+0xD0], xmm14
000074703ede005e  vmovaps [rsp+0xE0], xmm15
000074703ede0067  sub rsp, 0x30
000074703ede006b  movaps [rsp], xmm8
000074703ede0070  movaps [rsp+0x10], xmm1
000074703ede0075  movaps [rsp+0x20], xmm14
000074703ede007b  lea rdi, [rsp]
000074703ede007f  mov esi, 0x00
000074703ede0084  mov rax, 0x5D9974CCC530
000074703ede008e  call rax
000074703ede0090  movaps xmm8, [rsp]
000074703ede0095  add rsp, 0x30
000074703ede0099  vmovaps xmm0, [rsp]
000074703ede009e  vmovaps xmm1, [rsp+0x10]
000074703ede00a4  vmovaps xmm2, [rsp+0x20]
000074703ede00aa  vmovaps xmm3, [rsp+0x30]
000074703ede00b0  vmovaps xmm4, [rsp+0x40]
000074703ede00b6  vmovaps xmm5, [rsp+0x50]
000074703ede00bc  vmovaps xmm6, [rsp+0x60]
000074703ede00c2  vmovaps xmm7, [rsp+0x70]
000074703ede00c8  vmovaps xmm9, [rsp+0x80]
000074703ede00d1  vmovaps xmm10, [rsp+0x90]
000074703ede00da  vmovaps xmm11, [rsp+0xA0]
000074703ede00e3  vmovaps xmm12, [rsp+0xB0]
000074703ede00ec  vmovaps xmm13, [rsp+0xC0]
000074703ede00f5  vmovaps xmm14, [rsp+0xD0]
000074703ede00fe  vmovaps xmm15, [rsp+0xE0]
000074703ede0107  add rsp, 0xF0
000074703ede010e  pop r11
000074703ede0110  pop r10
000074703ede0112  pop r9
000074703ede0114  pop r8
000074703ede0116  pop rsi
000074703ede0117  pop rdi
000074703ede0118  pop rdx
000074703ede0119  pop rcx
000074703ede011a  pop rax
000074703ede011b  add rsp, 0x08
000074703ede011f  jmp 0x000074703EDDC561
000074703ede0124  sub rsp, 0x08
000074703ede0128  push rax
000074703ede0129  push rcx
000074703ede012a  push rdx
000074703ede012b  push rdi
000074703ede012c  push rsi
000074703ede012d  push r8
000074703ede012f  push r9
000074703ede0131  push r10
000074703ede0133  push r11
000074703ede0135  sub rsp, 0xF0
000074703ede013c  vmovaps [rsp], xmm0
000074703ede0141  vmovaps [rsp+0x10], xmm1
000074703ede0147  vmovaps [rsp+0x20], xmm2
000074703ede014d  vmovaps [rsp+0x30], xmm3
000074703ede0153  vmovaps [rsp+0x40], xmm4
000074703ede0159  vmovaps [rsp+0x50], xmm5
000074703ede015f  vmovaps [rsp+0x60], xmm7
000074703ede0165  vmovaps [rsp+0x70], xmm8
000074703ede016b  vmovaps [rsp+0x80], xmm9
000074703ede0174  vmovaps [rsp+0x90], xmm10
000074703ede017d  vmovaps [rsp+0xA0], xmm11
000074703ede0186  vmovaps [rsp+0xB0], xmm12
000074703ede018f  vmovaps [rsp+0xC0], xmm13
000074703ede0198  vmovaps [rsp+0xD0], xmm14
000074703ede01a1  vmovaps [rsp+0xE0], xmm15
000074703ede01aa  sub rsp, 0x30
000074703ede01ae  movaps [rsp], xmm6
000074703ede01b2  movaps [rsp+0x10], xmm1
000074703ede01b7  movaps [rsp+0x20], xmm14
000074703ede01bd  lea rdi, [rsp]
000074703ede01c1  mov esi, 0x00
000074703ede01c6  mov rax, 0x5D9974CCC530
000074703ede01d0  call rax
000074703ede01d2  movaps xmm6, [rsp]
000074703ede01d6  add rsp, 0x30
000074703ede01da  vmovaps xmm0, [rsp]
000074703ede01df  vmovaps xmm1, [rsp+0x10]
000074703ede01e5  vmovaps xmm2, [rsp+0x20]
000074703ede01eb  vmovaps xmm3, [rsp+0x30]
000074703ede01f1  vmovaps xmm4, [rsp+0x40]
000074703ede01f7  vmovaps xmm5, [rsp+0x50]
000074703ede01fd  vmovaps xmm7, [rsp+0x60]
000074703ede0203  vmovaps xmm8, [rsp+0x70]
000074703ede0209  vmovaps xmm9, [rsp+0x80]
000074703ede0212  vmovaps xmm10, [rsp+0x90]
000074703ede021b  vmovaps xmm11, [rsp+0xA0]
000074703ede0224  vmovaps xmm12, [rsp+0xB0]
000074703ede022d  vmovaps xmm13, [rsp+0xC0]
000074703ede0236  vmovaps xmm14, [rsp+0xD0]
000074703ede023f  vmovaps xmm15, [rsp+0xE0]
000074703ede0248  add rsp, 0xF0
000074703ede024f  pop r11
000074703ede0251  pop r10
000074703ede0253  pop r9
000074703ede0255  pop r8
000074703ede0257  pop rsi
000074703ede0258  pop rdi
000074703ede0259  pop rdx
000074703ede025a  pop rcx
000074703ede025b  pop rax
000074703ede025c  add rsp, 0x08
000074703ede0260  jmp 0x000074703EDDC58D
000074703ede0265  sub rsp, 0x08
000074703ede0269  push rax
000074703ede026a  push rcx
000074703ede026b  push rdx
000074703ede026c  push rdi
000074703ede026d  push rsi
000074703ede026e  push r8
000074703ede0270  push r9
000074703ede0272  push r10
000074703ede0274  push r11
000074703ede0276  sub rsp, 0xF0
000074703ede027d  vmovaps [rsp], xmm0
000074703ede0282  vmovaps [rsp+0x10], xmm1
000074703ede0288  vmovaps [rsp+0x20], xmm2
000074703ede028e  vmovaps [rsp+0x30], xmm3
000074703ede0294  vmovaps [rsp+0x40], xmm4
000074703ede029a  vmovaps [rsp+0x50], xmm5
000074703ede02a0  vmovaps [rsp+0x60], xmm6
000074703ede02a6  vmovaps [rsp+0x70], xmm7
000074703ede02ac  vmovaps [rsp+0x80], xmm8
000074703ede02b5  vmovaps [rsp+0x90], xmm9
000074703ede02be  vmovaps [rsp+0xA0], xmm10
000074703ede02c7  vmovaps [rsp+0xB0], xmm11
000074703ede02d0  vmovaps [rsp+0xC0], xmm12
000074703ede02d9  vmovaps [rsp+0xD0], xmm13
000074703ede02e2  vmovaps [rsp+0xE0], xmm15
000074703ede02eb  sub rsp, 0x30
000074703ede02ef  movaps [rsp], xmm14
000074703ede02f4  movaps [rsp+0x10], xmm12
000074703ede02fa  movaps [rsp+0x20], xmm1
000074703ede02ff  lea rdi, [rsp]
000074703ede0303  mov esi, 0x00
000074703ede0308  mov rax, 0x5D9974CCC530
000074703ede0312  call rax
000074703ede0314  movaps xmm14, [rsp]
000074703ede0319  add rsp, 0x30
000074703ede031d  vmovaps xmm0, [rsp]
000074703ede0322  vmovaps xmm1, [rsp+0x10]
000074703ede0328  vmovaps xmm2, [rsp+0x20]
000074703ede032e  vmovaps xmm3, [rsp+0x30]
000074703ede0334  vmovaps xmm4, [rsp+0x40]
000074703ede033a  vmovaps xmm5, [rsp+0x50]
000074703ede0340  vmovaps xmm6, [rsp+0x60]
000074703ede0346  vmovaps xmm7, [rsp+0x70]
000074703ede034c  vmovaps xmm8, [rsp+0x80]
000074703ede0355  vmovaps xmm9, [rsp+0x90]
000074703ede035e  vmovaps xmm10, [rsp+0xA0]
000074703ede0367  vmovaps xmm11, [rsp+0xB0]
000074703ede0370  vmovaps xmm12, [rsp+0xC0]
000074703ede0379  vmovaps xmm13, [rsp+0xD0]
000074703ede0382  vmovaps xmm15, [rsp+0xE0]
000074703ede038b  add rsp, 0xF0
000074703ede0392  pop r11
000074703ede0394  pop r10
000074703ede0396  pop r9
000074703ede0398  pop r8
000074703ede039a  pop rsi
000074703ede039b  pop rdi
000074703ede039c  pop rdx
000074703ede039d  pop rcx
000074703ede039e  pop rax
000074703ede039f  add rsp, 0x08
000074703ede03a3  jmp 0x000074703EDDC5B3
000074703ede03a8  sub rsp, 0x08
000074703ede03ac  push rax
000074703ede03ad  push rcx
000074703ede03ae  push rdx
000074703ede03af  push rdi
000074703ede03b0  push rsi
000074703ede03b1  push r8
000074703ede03b3  push r9
000074703ede03b5  push r10
000074703ede03b7  push r11
000074703ede03b9  sub rsp, 0xF0
000074703ede03c0  vmovaps [rsp], xmm0
000074703ede03c5  vmovaps [rsp+0x10], xmm2
000074703ede03cb  vmovaps [rsp+0x20], xmm3
000074703ede03d1  vmovaps [rsp+0x30], xmm4
000074703ede03d7  vmovaps [rsp+0x40], xmm5
000074703ede03dd  vmovaps [rsp+0x50], xmm6
000074703ede03e3  vmovaps [rsp+0x60], xmm7
000074703ede03e9  vmovaps [rsp+0x70], xmm8
000074703ede03ef  vmovaps [rsp+0x80], xmm9
000074703ede03f8  vmovaps [rsp+0x90], xmm10
000074703ede0401  vmovaps [rsp+0xA0], xmm11
000074703ede040a  vmovaps [rsp+0xB0], xmm12
000074703ede0413  vmovaps [rsp+0xC0], xmm13
000074703ede041c  vmovaps [rsp+0xD0], xmm14
000074703ede0425  vmovaps [rsp+0xE0], xmm15
000074703ede042e  sub rsp, 0x30
000074703ede0432  movaps [rsp], xmm1
000074703ede0436  movaps [rsp+0x10], xmm13
000074703ede043c  movaps [rsp+0x20], xmm9
000074703ede0442  lea rdi, [rsp]
000074703ede0446  mov esi, 0x00
000074703ede044b  mov rax, 0x5D9974CCC530
000074703ede0455  call rax
000074703ede0457  movaps xmm1, [rsp]
000074703ede045b  add rsp, 0x30
000074703ede045f  vmovaps xmm0, [rsp]
000074703ede0464  vmovaps xmm2, [rsp+0x10]
000074703ede046a  vmovaps xmm3, [rsp+0x20]
000074703ede0470  vmovaps xmm4, [rsp+0x30]
000074703ede0476  vmovaps xmm5, [rsp+0x40]
000074703ede047c  vmovaps xmm6, [rsp+0x50]
000074703ede0482  vmovaps xmm7, [rsp+0x60]
000074703ede0488  vmovaps xmm8, [rsp+0x70]
000074703ede048e  vmovaps xmm9, [rsp+0x80]
000074703ede0497  vmovaps xmm10, [rsp+0x90]
000074703ede04a0  vmovaps xmm11, [rsp+0xA0]
000074703ede04a9  vmovaps xmm12, [rsp+0xB0]
000074703ede04b2  vmovaps xmm13, [rsp+0xC0]
000074703ede04bb  vmovaps xmm14, [rsp+0xD0]
000074703ede04c4  vmovaps xmm15, [rsp+0xE0]
000074703ede04cd  add rsp, 0xF0
000074703ede04d4  pop r11
000074703ede04d6  pop r10
000074703ede04d8  pop r9
000074703ede04da  pop r8
000074703ede04dc  pop rsi
000074703ede04dd  pop rdi
000074703ede04de  pop rdx
000074703ede04df  pop rcx
000074703ede04e0  pop rax
000074703ede04e1  add rsp, 0x08
000074703ede04e5  jmp 0x000074703EDDC5CD
000074703ede04ea  sub rsp, 0x08
000074703ede04ee  push rax
000074703ede04ef  push rcx
000074703ede04f0  push rdx
000074703ede04f1  push rdi
000074703ede04f2  push rsi
000074703ede04f3  push r8
000074703ede04f5  push r9
000074703ede04f7  push r10
000074703ede04f9  push r11
000074703ede04fb  sub rsp, 0xF0
000074703ede0502  vmovaps [rsp], xmm0
000074703ede0507  vmovaps [rsp+0x10], xmm1
000074703ede050d  vmovaps [rsp+0x20], xmm2
000074703ede0513  vmovaps [rsp+0x30], xmm3
000074703ede0519  vmovaps [rsp+0x40], xmm4
000074703ede051f  vmovaps [rsp+0x50], xmm5
000074703ede0525  vmovaps [rsp+0x60], xmm6
000074703ede052b  vmovaps [rsp+0x70], xmm7
000074703ede0531  vmovaps [rsp+0x80], xmm8
000074703ede053a  vmovaps [rsp+0x90], xmm9
000074703ede0543  vmovaps [rsp+0xA0], xmm10
000074703ede054c  vmovaps [rsp+0xB0], xmm11
000074703ede0555  vmovaps [rsp+0xC0], xmm13
000074703ede055e  vmovaps [rsp+0xD0], xmm14
000074703ede0567  vmovaps [rsp+0xE0], xmm15
000074703ede0570  sub rsp, 0x30
000074703ede0574  movaps [rsp], xmm12
000074703ede0579  movaps [rsp+0x10], xmm7
000074703ede057e  movaps [rsp+0x20], xmm13
000074703ede0584  lea rdi, [rsp]
000074703ede0588  mov esi, 0x00
000074703ede058d  mov rax, 0x5D9974CCC530
000074703ede0597  call rax
000074703ede0599  movaps xmm12, [rsp]
000074703ede059e  add rsp, 0x30
000074703ede05a2  vmovaps xmm0, [rsp]
000074703ede05a7  vmovaps xmm1, [rsp+0x10]
000074703ede05ad  vmovaps xmm2, [rsp+0x20]
000074703ede05b3  vmovaps xmm3, [rsp+0x30]
000074703ede05b9  vmovaps xmm4, [rsp+0x40]
000074703ede05bf  vmovaps xmm5, [rsp+0x50]
000074703ede05c5  vmovaps xmm6, [rsp+0x60]
000074703ede05cb  vmovaps xmm7, [rsp+0x70]
000074703ede05d1  vmovaps xmm8, [rsp+0x80]
000074703ede05da  vmovaps xmm9, [rsp+0x90]
000074703ede05e3  vmovaps xmm10, [rsp+0xA0]
000074703ede05ec  vmovaps xmm11, [rsp+0xB0]
000074703ede05f5  vmovaps xmm13, [rsp+0xC0]
000074703ede05fe  vmovaps xmm14, [rsp+0xD0]
000074703ede0607  vmovaps xmm15, [rsp+0xE0]
000074703ede0610  add rsp, 0xF0
000074703ede0617  pop r11
000074703ede0619  pop r10
000074703ede061b  pop r9
000074703ede061d  pop r8
000074703ede061f  pop rsi
000074703ede0620  pop rdi
000074703ede0621  pop rdx
000074703ede0622  pop rcx
000074703ede0623  pop rax
000074703ede0624  add rsp, 0x08
000074703ede0628  jmp 0x000074703EDDC5F4
000074703ede062d  sub rsp, 0x08
000074703ede0631  push rax
000074703ede0632  push rcx
000074703ede0633  push rdx
000074703ede0634  push rdi
000074703ede0635  push rsi
000074703ede0636  push r8
000074703ede0638  push r9
000074703ede063a  push r10
000074703ede063c  push r11
000074703ede063e  sub rsp, 0xF0
000074703ede0645  vmovaps [rsp], xmm0
000074703ede064a  vmovaps [rsp+0x10], xmm1
000074703ede0650  vmovaps [rsp+0x20], xmm2
000074703ede0656  vmovaps [rsp+0x30], xmm3
000074703ede065c  vmovaps [rsp+0x40], xmm4
000074703ede0662  vmovaps [rsp+0x50], xmm5
000074703ede0668  vmovaps [rsp+0x60], xmm6
000074703ede066e  vmovaps [rsp+0x70], xmm7
000074703ede0674  vmovaps [rsp+0x80], xmm8
000074703ede067d  vmovaps [rsp+0x90], xmm9
000074703ede0686  vmovaps [rsp+0xA0], xmm10
000074703ede068f  vmovaps [rsp+0xB0], xmm11
000074703ede0698  vmovaps [rsp+0xC0], xmm12
000074703ede06a1  vmovaps [rsp+0xD0], xmm14
000074703ede06aa  vmovaps [rsp+0xE0], xmm15
000074703ede06b3  sub rsp, 0x30
000074703ede06b7  movaps [rsp], xmm13
000074703ede06bc  movaps [rsp+0x10], xmm15
000074703ede06c2  movaps [rsp+0x20], xmm8
000074703ede06c8  lea rdi, [rsp]
000074703ede06cc  mov esi, 0x00
000074703ede06d1  mov rax, 0x5D9974CCC530
000074703ede06db  call rax
000074703ede06dd  movaps xmm13, [rsp]
000074703ede06e2  add rsp, 0x30
000074703ede06e6  vmovaps xmm0, [rsp]
000074703ede06eb  vmovaps xmm1, [rsp+0x10]
000074703ede06f1  vmovaps xmm2, [rsp+0x20]
000074703ede06f7  vmovaps xmm3, [rsp+0x30]
000074703ede06fd  vmovaps xmm4, [rsp+0x40]
000074703ede0703  vmovaps xmm5, [rsp+0x50]
000074703ede0709  vmovaps xmm6, [rsp+0x60]
000074703ede070f  vmovaps xmm7, [rsp+0x70]
000074703ede0715  vmovaps xmm8, [rsp+0x80]
000074703ede071e  vmovaps xmm9, [rsp+0x90]
000074703ede0727  vmovaps xmm10, [rsp+0xA0]
000074703ede0730  vmovaps xmm11, [rsp+0xB0]
000074703ede0739  vmovaps xmm12, [rsp+0xC0]
000074703ede0742  vmovaps xmm14, [rsp+0xD0]
000074703ede074b  vmovaps xmm15, [rsp+0xE0]
000074703ede0754  add rsp, 0xF0
000074703ede075b  pop r11
000074703ede075d  pop r10
000074703ede075f  pop r9
000074703ede0761  pop r8
000074703ede0763  pop rsi
000074703ede0764  pop rdi
000074703ede0765  pop rdx
000074703ede0766  pop rcx
000074703ede0767  pop rax
000074703ede0768  add rsp, 0x08
000074703ede076c  jmp 0x000074703EDDC60F
000074703ede0771  sub rsp, 0x08
000074703ede0775  push rax
000074703ede0776  push rcx
000074703ede0777  push rdx
000074703ede0778  push rdi
000074703ede0779  push rsi
000074703ede077a  push r8
000074703ede077c  push r9
000074703ede077e  push r10
000074703ede0780  push r11
000074703ede0782  sub rsp, 0xF0
000074703ede0789  vmovaps [rsp], xmm0
000074703ede078e  vmovaps [rsp+0x10], xmm1
000074703ede0794  vmovaps [rsp+0x20], xmm2
000074703ede079a  vmovaps [rsp+0x30], xmm3
000074703ede07a0  vmovaps [rsp+0x40], xmm4
000074703ede07a6  vmovaps [rsp+0x50], xmm5
000074703ede07ac  vmovaps [rsp+0x60], xmm6
000074703ede07b2  vmovaps [rsp+0x70], xmm7
000074703ede07b8  vmovaps [rsp+0x80], xmm9
000074703ede07c1  vmovaps [rsp+0x90], xmm10
000074703ede07ca  vmovaps [rsp+0xA0], xmm11
000074703ede07d3  vmovaps [rsp+0xB0], xmm12
000074703ede07dc  vmovaps [rsp+0xC0], xmm13
000074703ede07e5  vmovaps [rsp+0xD0], xmm14
000074703ede07ee  vmovaps [rsp+0xE0], xmm15
000074703ede07f7  sub rsp, 0x30
000074703ede07fb  movaps [rsp], xmm8
000074703ede0800  movaps [rsp+0x10], xmm15
000074703ede0806  movaps [rsp+0x20], xmm9
000074703ede080c  lea rdi, [rsp]
000074703ede0810  mov esi, 0x00
000074703ede0815  mov rax, 0x5D9974CCC530
000074703ede081f  call rax
000074703ede0821  movaps xmm8, [rsp]
000074703ede0826  add rsp, 0x30
000074703ede082a  vmovaps xmm0, [rsp]
000074703ede082f  vmovaps xmm1, [rsp+0x10]
000074703ede0835  vmovaps xmm2, [rsp+0x20]
000074703ede083b  vmovaps xmm3, [rsp+0x30]
000074703ede0841  vmovaps xmm4, [rsp+0x40]
000074703ede0847  vmovaps xmm5, [rsp+0x50]
000074703ede084d  vmovaps xmm6, [rsp+0x60]
000074703ede0853  vmovaps xmm7, [rsp+0x70]
000074703ede0859  vmovaps xmm9, [rsp+0x80]
000074703ede0862  vmovaps xmm10, [rsp+0x90]
000074703ede086b  vmovaps xmm11, [rsp+0xA0]
000074703ede0874  vmovaps xmm12, [rsp+0xB0]
000074703ede087d  vmovaps xmm13, [rsp+0xC0]
000074703ede0886  vmovaps xmm14, [rsp+0xD0]
000074703ede088f  vmovaps xmm15, [rsp+0xE0]
000074703ede0898  add rsp, 0xF0
000074703ede089f  pop r11
000074703ede08a1  pop r10
000074703ede08a3  pop r9
000074703ede08a5  pop r8
000074703ede08a7  pop rsi
000074703ede08a8  pop rdi
000074703ede08a9  pop rdx
000074703ede08aa  pop rcx
000074703ede08ab  pop rax
000074703ede08ac  add rsp, 0x08
000074703ede08b0  jmp 0x000074703EDDC63D
000074703ede08b5  sub rsp, 0x08
000074703ede08b9  push rax
000074703ede08ba  push rcx
000074703ede08bb  push rdx
000074703ede08bc  push rdi
000074703ede08bd  push rsi
000074703ede08be  push r8
000074703ede08c0  push r9
000074703ede08c2  push r10
000074703ede08c4  push r11
000074703ede08c6  sub rsp, 0xF0
000074703ede08cd  vmovaps [rsp], xmm0
000074703ede08d2  vmovaps [rsp+0x10], xmm1
000074703ede08d8  vmovaps [rsp+0x20], xmm2
000074703ede08de  vmovaps [rsp+0x30], xmm3
000074703ede08e4  vmovaps [rsp+0x40], xmm4
000074703ede08ea  vmovaps [rsp+0x50], xmm5
000074703ede08f0  vmovaps [rsp+0x60], xmm6
000074703ede08f6  vmovaps [rsp+0x70], xmm7
000074703ede08fc  vmovaps [rsp+0x80], xmm8
000074703ede0905  vmovaps [rsp+0x90], xmm9
000074703ede090e  vmovaps [rsp+0xA0], xmm10
000074703ede0917  vmovaps [rsp+0xB0], xmm11
000074703ede0920  vmovaps [rsp+0xC0], xmm12
000074703ede0929  vmovaps [rsp+0xD0], xmm13
000074703ede0932  vmovaps [rsp+0xE0], xmm14
000074703ede093b  sub rsp, 0x30
000074703ede093f  movaps [rsp], xmm15
000074703ede0944  movaps [rsp+0x10], xmm11
000074703ede094a  movaps [rsp+0x20], xmm6
000074703ede094f  lea rdi, [rsp]
000074703ede0953  mov esi, 0x00
000074703ede0958  mov rax, 0x5D9974CCC530
000074703ede0962  call rax
000074703ede0964  movaps xmm15, [rsp]
000074703ede0969  add rsp, 0x30
000074703ede096d  vmovaps xmm0, [rsp]
000074703ede0972  vmovaps xmm1, [rsp+0x10]
000074703ede0978  vmovaps xmm2, [rsp+0x20]
000074703ede097e  vmovaps xmm3, [rsp+0x30]
000074703ede0984  vmovaps xmm4, [rsp+0x40]
000074703ede098a  vmovaps xmm5, [rsp+0x50]
000074703ede0990  vmovaps xmm6, [rsp+0x60]
000074703ede0996  vmovaps xmm7, [rsp+0x70]
000074703ede099c  vmovaps xmm8, [rsp+0x80]
000074703ede09a5  vmovaps xmm9, [rsp+0x90]
000074703ede09ae  vmovaps xmm10, [rsp+0xA0]
000074703ede09b7  vmovaps xmm11, [rsp+0xB0]
000074703ede09c0  vmovaps xmm12, [rsp+0xC0]
000074703ede09c9  vmovaps xmm13, [rsp+0xD0]
000074703ede09d2  vmovaps xmm14, [rsp+0xE0]
000074703ede09db  add rsp, 0xF0
000074703ede09e2  pop r11
000074703ede09e4  pop r10
000074703ede09e6  pop r9
000074703ede09e8  pop r8
000074703ede09ea  pop rsi
000074703ede09eb  pop rdi
000074703ede09ec  pop rdx
000074703ede09ed  pop rcx
000074703ede09ee  pop rax
000074703ede09ef  add rsp, 0x08
000074703ede09f3  jmp 0x000074703EDDC658
000074703ede09f8  sub rsp, 0x08
000074703ede09fc  push rax
000074703ede09fd  push rcx
000074703ede09fe  push rdx
000074703ede09ff  push rdi
000074703ede0a00  push rsi
000074703ede0a01  push r8
000074703ede0a03  push r9
000074703ede0a05  push r10
000074703ede0a07  push r11
000074703ede0a09  sub rsp, 0xF0
000074703ede0a10  vmovaps [rsp], xmm0
000074703ede0a15  vmovaps [rsp+0x10], xmm1
000074703ede0a1b  vmovaps [rsp+0x20], xmm2
000074703ede0a21  vmovaps [rsp+0x30], xmm3
000074703ede0a27  vmovaps [rsp+0x40], xmm4
000074703ede0a2d  vmovaps [rsp+0x50], xmm5
000074703ede0a33  vmovaps [rsp+0x60], xmm6
000074703ede0a39  vmovaps [rsp+0x70], xmm8
000074703ede0a3f  vmovaps [rsp+0x80], xmm9
000074703ede0a48  vmovaps [rsp+0x90], xmm10
000074703ede0a51  vmovaps [rsp+0xA0], xmm11
000074703ede0a5a  vmovaps [rsp+0xB0], xmm12
000074703ede0a63  vmovaps [rsp+0xC0], xmm13
000074703ede0a6c  vmovaps [rsp+0xD0], xmm14
000074703ede0a75  vmovaps [rsp+0xE0], xmm15
000074703ede0a7e  sub rsp, 0x30
000074703ede0a82  movaps [rsp], xmm7
000074703ede0a86  movaps [rsp+0x10], xmm11
000074703ede0a8c  movaps [rsp+0x20], xmm9
000074703ede0a92  lea rdi, [rsp]
000074703ede0a96  mov esi, 0x00
000074703ede0a9b  mov rax, 0x5D9974CCC530
000074703ede0aa5  call rax
000074703ede0aa7  movaps xmm7, [rsp]
000074703ede0aab  add rsp, 0x30
000074703ede0aaf  vmovaps xmm0, [rsp]
000074703ede0ab4  vmovaps xmm1, [rsp+0x10]
000074703ede0aba  vmovaps xmm2, [rsp+0x20]
000074703ede0ac0  vmovaps xmm3, [rsp+0x30]
000074703ede0ac6  vmovaps xmm4, [rsp+0x40]
000074703ede0acc  vmovaps xmm5, [rsp+0x50]
000074703ede0ad2  vmovaps xmm6, [rsp+0x60]
000074703ede0ad8  vmovaps xmm8, [rsp+0x70]
000074703ede0ade  vmovaps xmm9, [rsp+0x80]
000074703ede0ae7  vmovaps xmm10, [rsp+0x90]
000074703ede0af0  vmovaps xmm11, [rsp+0xA0]
000074703ede0af9  vmovaps xmm12, [rsp+0xB0]
000074703ede0b02  vmovaps xmm13, [rsp+0xC0]
000074703ede0b0b  vmovaps xmm14, [rsp+0xD0]
000074703ede0b14  vmovaps xmm15, [rsp+0xE0]
000074703ede0b1d  add rsp, 0xF0
000074703ede0b24  pop r11
000074703ede0b26  pop r10
000074703ede0b28  pop r9
000074703ede0b2a  pop r8
000074703ede0b2c  pop rsi
000074703ede0b2d  pop rdi
000074703ede0b2e  pop rdx
000074703ede0b2f  pop rcx
000074703ede0b30  pop rax
000074703ede0b31  add rsp, 0x08
000074703ede0b35  jmp 0x000074703EDDC685
000074703ede0b3a  sub rsp, 0x08
000074703ede0b3e  push rax
000074703ede0b3f  push rcx
000074703ede0b40  push rdx
000074703ede0b41  push rdi
000074703ede0b42  push rsi
000074703ede0b43  push r8
000074703ede0b45  push r9
000074703ede0b47  push r10
000074703ede0b49  push r11
000074703ede0b4b  sub rsp, 0xF0
000074703ede0b52  vmovaps [rsp], xmm0
000074703ede0b57  vmovaps [rsp+0x10], xmm1
000074703ede0b5d  vmovaps [rsp+0x20], xmm2
000074703ede0b63  vmovaps [rsp+0x30], xmm3
000074703ede0b69  vmovaps [rsp+0x40], xmm4
000074703ede0b6f  vmovaps [rsp+0x50], xmm5
000074703ede0b75  vmovaps [rsp+0x60], xmm6
000074703ede0b7b  vmovaps [rsp+0x70], xmm7
000074703ede0b81  vmovaps [rsp+0x80], xmm8
000074703ede0b8a  vmovaps [rsp+0x90], xmm9
000074703ede0b93  vmovaps [rsp+0xA0], xmm10
000074703ede0b9c  vmovaps [rsp+0xB0], xmm12
000074703ede0ba5  vmovaps [rsp+0xC0], xmm13
000074703ede0bae  vmovaps [rsp+0xD0], xmm14
000074703ede0bb7  vmovaps [rsp+0xE0], xmm15
000074703ede0bc0  sub rsp, 0x30
000074703ede0bc4  movaps [rsp], xmm11
000074703ede0bc9  movaps [rsp+0x10], xmm10
000074703ede0bcf  movaps [rsp+0x20], xmm14
000074703ede0bd5  lea rdi, [rsp]
000074703ede0bd9  mov esi, 0x00
000074703ede0bde  mov rax, 0x5D9974CCC530
000074703ede0be8  call rax
000074703ede0bea  movaps xmm11, [rsp]
000074703ede0bef  add rsp, 0x30
000074703ede0bf3  vmovaps xmm0, [rsp]
000074703ede0bf8  vmovaps xmm1, [rsp+0x10]
000074703ede0bfe  vmovaps xmm2, [rsp+0x20]
000074703ede0c04  vmovaps xmm3, [rsp+0x30]
000074703ede0c0a  vmovaps xmm4, [rsp+0x40]
000074703ede0c10  vmovaps xmm5, [rsp+0x50]
000074703ede0c16  vmovaps xmm6, [rsp+0x60]
000074703ede0c1c  vmovaps xmm7, [rsp+0x70]
000074703ede0c22  vmovaps xmm8, [rsp+0x80]
000074703ede0c2b  vmovaps xmm9, [rsp+0x90]
000074703ede0c34  vmovaps xmm10, [rsp+0xA0]
000074703ede0c3d  vmovaps xmm12, [rsp+0xB0]
000074703ede0c46  vmovaps xmm13, [rsp+0xC0]
000074703ede0c4f  vmovaps xmm14, [rsp+0xD0]
000074703ede0c58  vmovaps xmm15, [rsp+0xE0]
000074703ede0c61  add rsp, 0xF0
000074703ede0c68  pop r11
000074703ede0c6a  pop r10
000074703ede0c6c  pop r9
000074703ede0c6e  pop r8
000074703ede0c70  pop rsi
000074703ede0c71  pop rdi
000074703ede0c72  pop rdx
000074703ede0c73  pop rcx
000074703ede0c74  pop rax
000074703ede0c75  add rsp, 0x08
000074703ede0c79  jmp 0x000074703EDDC6A0
000074703ede0c7e  call 0x000074703ECC33A0
000074703ede0c83  jmp 0x000074703EDDC6AA
000074703ede0c88  sub rsp, 0x08
000074703ede0c8c  push rax
000074703ede0c8d  push rcx
000074703ede0c8e  push rdx
000074703ede0c8f  push rdi
000074703ede0c90  push rsi
000074703ede0c91  push r8
000074703ede0c93  push r9
000074703ede0c95  push r10
000074703ede0c97  push r11
000074703ede0c99  sub rsp, 0xF0
000074703ede0ca0  vmovaps [rsp], xmm0
000074703ede0ca5  vmovaps [rsp+0x10], xmm1
000074703ede0cab  vmovaps [rsp+0x20], xmm2
000074703ede0cb1  vmovaps [rsp+0x30], xmm3
000074703ede0cb7  vmovaps [rsp+0x40], xmm4
000074703ede0cbd  vmovaps [rsp+0x50], xmm5
000074703ede0cc3  vmovaps [rsp+0x60], xmm6
000074703ede0cc9  vmovaps [rsp+0x70], xmm7
000074703ede0ccf  vmovaps [rsp+0x80], xmm8
000074703ede0cd8  vmovaps [rsp+0x90], xmm9
000074703ede0ce1  vmovaps [rsp+0xA0], xmm11
000074703ede0cea  vmovaps [rsp+0xB0], xmm12
000074703ede0cf3  vmovaps [rsp+0xC0], xmm13
000074703ede0cfc  vmovaps [rsp+0xD0], xmm14
000074703ede0d05  vmovaps [rsp+0xE0], xmm15
000074703ede0d0e  sub rsp, 0x30
000074703ede0d12  movaps [rsp], xmm10
000074703ede0d17  movaps [rsp+0x10], xmm1
000074703ede0d1c  movaps [rsp+0x20], xmm12
000074703ede0d22  lea rdi, [rsp]
000074703ede0d26  mov esi, 0x00
000074703ede0d2b  mov rax, 0x5D9974CCC530
000074703ede0d35  call rax
000074703ede0d37  movaps xmm10, [rsp]
000074703ede0d3c  add rsp, 0x30
000074703ede0d40  vmovaps xmm0, [rsp]
000074703ede0d45  vmovaps xmm1, [rsp+0x10]
000074703ede0d4b  vmovaps xmm2, [rsp+0x20]
000074703ede0d51  vmovaps xmm3, [rsp+0x30]
000074703ede0d57  vmovaps xmm4, [rsp+0x40]
000074703ede0d5d  vmovaps xmm5, [rsp+0x50]
000074703ede0d63  vmovaps xmm6, [rsp+0x60]
000074703ede0d69  vmovaps xmm7, [rsp+0x70]
000074703ede0d6f  vmovaps xmm8, [rsp+0x80]
000074703ede0d78  vmovaps xmm9, [rsp+0x90]
000074703ede0d81  vmovaps xmm11, [rsp+0xA0]
000074703ede0d8a  vmovaps xmm12, [rsp+0xB0]
000074703ede0d93  vmovaps xmm13, [rsp+0xC0]
000074703ede0d9c  vmovaps xmm14, [rsp+0xD0]
000074703ede0da5  vmovaps xmm15, [rsp+0xE0]
000074703ede0dae  add rsp, 0xF0
000074703ede0db5  pop r11
000074703ede0db7  pop r10
000074703ede0db9  pop r9
000074703ede0dbb  pop r8
000074703ede0dbd  pop rsi
000074703ede0dbe  pop rdi
000074703ede0dbf  pop rdx
000074703ede0dc0  pop rcx
000074703ede0dc1  pop rax
000074703ede0dc2  add rsp, 0x08
000074703ede0dc6  jmp 0x000074703EDDC6CD
000074703ede0dcb  sub rsp, 0x08
000074703ede0dcf  push rax
000074703ede0dd0  push rcx
000074703ede0dd1  push rdx
000074703ede0dd2  push rdi
000074703ede0dd3  push rsi
000074703ede0dd4  push r8
000074703ede0dd6  push r9
000074703ede0dd8  push r10
000074703ede0dda  push r11
000074703ede0ddc  sub rsp, 0xF0
000074703ede0de3  vmovaps [rsp], xmm0
000074703ede0de8  vmovaps [rsp+0x10], xmm1
000074703ede0dee  vmovaps [rsp+0x20], xmm2
000074703ede0df4  vmovaps [rsp+0x30], xmm3
000074703ede0dfa  vmovaps [rsp+0x40], xmm4
000074703ede0e00  vmovaps [rsp+0x50], xmm5
000074703ede0e06  vmovaps [rsp+0x60], xmm6
000074703ede0e0c  vmovaps [rsp+0x70], xmm7
000074703ede0e12  vmovaps [rsp+0x80], xmm8
000074703ede0e1b  vmovaps [rsp+0x90], xmm9
000074703ede0e24  vmovaps [rsp+0xA0], xmm10
000074703ede0e2d  vmovaps [rsp+0xB0], xmm11
000074703ede0e36  vmovaps [rsp+0xC0], xmm13
000074703ede0e3f  vmovaps [rsp+0xD0], xmm14
000074703ede0e48  vmovaps [rsp+0xE0], xmm15
000074703ede0e51  sub rsp, 0x30
000074703ede0e55  movaps [rsp], xmm12
000074703ede0e5a  movaps [rsp+0x10], xmm14
000074703ede0e60  movaps [rsp+0x20], xmm1
000074703ede0e65  lea rdi, [rsp]
000074703ede0e69  mov esi, 0x00
000074703ede0e6e  mov rax, 0x5D9974CCC530
000074703ede0e78  call rax
000074703ede0e7a  movaps xmm12, [rsp]
000074703ede0e7f  add rsp, 0x30
000074703ede0e83  vmovaps xmm0, [rsp]
000074703ede0e88  vmovaps xmm1, [rsp+0x10]
000074703ede0e8e  vmovaps xmm2, [rsp+0x20]
000074703ede0e94  vmovaps xmm3, [rsp+0x30]
000074703ede0e9a  vmovaps xmm4, [rsp+0x40]
000074703ede0ea0  vmovaps xmm5, [rsp+0x50]
000074703ede0ea6  vmovaps xmm6, [rsp+0x60]
000074703ede0eac  vmovaps xmm7, [rsp+0x70]
000074703ede0eb2  vmovaps xmm8, [rsp+0x80]
000074703ede0ebb  vmovaps xmm9, [rsp+0x90]
000074703ede0ec4  vmovaps xmm10, [rsp+0xA0]
000074703ede0ecd  vmovaps xmm11, [rsp+0xB0]
000074703ede0ed6  vmovaps xmm13, [rsp+0xC0]
000074703ede0edf  vmovaps xmm14, [rsp+0xD0]
000074703ede0ee8  vmovaps xmm15, [rsp+0xE0]
000074703ede0ef1  add rsp, 0xF0
000074703ede0ef8  pop r11
000074703ede0efa  pop r10
000074703ede0efc  pop r9
000074703ede0efe  pop r8
000074703ede0f00  pop rsi
000074703ede0f01  pop rdi
000074703ede0f02  pop rdx
000074703ede0f03  pop rcx
000074703ede0f04  pop rax
000074703ede0f05  add rsp, 0x08
000074703ede0f09  jmp 0x000074703EDDC6FC
000074703ede0f0e  sub rsp, 0x08
000074703ede0f12  push rax
000074703ede0f13  push rcx
000074703ede0f14  push rdx
000074703ede0f15  push rdi
000074703ede0f16  push rsi
000074703ede0f17  push r8
000074703ede0f19  push r9
000074703ede0f1b  push r10
000074703ede0f1d  push r11
000074703ede0f1f  sub rsp, 0xF0
000074703ede0f26  vmovaps [rsp], xmm0
000074703ede0f2b  vmovaps [rsp+0x10], xmm1
000074703ede0f31  vmovaps [rsp+0x20], xmm2
000074703ede0f37  vmovaps [rsp+0x30], xmm3
000074703ede0f3d  vmovaps [rsp+0x40], xmm4
000074703ede0f43  vmovaps [rsp+0x50], xmm5
000074703ede0f49  vmovaps [rsp+0x60], xmm6
000074703ede0f4f  vmovaps [rsp+0x70], xmm7
000074703ede0f55  vmovaps [rsp+0x80], xmm8
000074703ede0f5e  vmovaps [rsp+0x90], xmm9
000074703ede0f67  vmovaps [rsp+0xA0], xmm10
000074703ede0f70  vmovaps [rsp+0xB0], xmm11
000074703ede0f79  vmovaps [rsp+0xC0], xmm12
000074703ede0f82  vmovaps [rsp+0xD0], xmm13
000074703ede0f8b  vmovaps [rsp+0xE0], xmm15
000074703ede0f94  sub rsp, 0x30
000074703ede0f98  movaps [rsp], xmm14
000074703ede0f9d  movaps [rsp+0x10], xmm9
000074703ede0fa3  movaps [rsp+0x20], xmm1
000074703ede0fa8  lea rdi, [rsp]
000074703ede0fac  mov esi, 0x00
000074703ede0fb1  mov rax, 0x5D9974CCC530
000074703ede0fbb  call rax
000074703ede0fbd  movaps xmm14, [rsp]
000074703ede0fc2  add rsp, 0x30
000074703ede0fc6  vmovaps xmm0, [rsp]
000074703ede0fcb  vmovaps xmm1, [rsp+0x10]
000074703ede0fd1  vmovaps xmm2, [rsp+0x20]
000074703ede0fd7  vmovaps xmm3, [rsp+0x30]
000074703ede0fdd  vmovaps xmm4, [rsp+0x40]
000074703ede0fe3  vmovaps xmm5, [rsp+0x50]
000074703ede0fe9  vmovaps xmm6, [rsp+0x60]
000074703ede0fef  vmovaps xmm7, [rsp+0x70]
000074703ede0ff5  vmovaps xmm8, [rsp+0x80]
000074703ede0ffe  vmovaps xmm9, [rsp+0x90]
000074703ede1007  vmovaps xmm10, [rsp+0xA0]
000074703ede1010  vmovaps xmm11, [rsp+0xB0]
000074703ede1019  vmovaps xmm12, [rsp+0xC0]
000074703ede1022  vmovaps xmm13, [rsp+0xD0]
000074703ede102b  vmovaps xmm15, [rsp+0xE0]
000074703ede1034  add rsp, 0xF0
000074703ede103b  pop r11
000074703ede103d  pop r10
000074703ede103f  pop r9
000074703ede1041  pop r8
000074703ede1043  pop rsi
000074703ede1044  pop rdi
000074703ede1045  pop rdx
000074703ede1046  pop rcx
000074703ede1047  pop rax
000074703ede1048  add rsp, 0x08
000074703ede104c  jmp 0x000074703EDDC72B
000074703ede1051  sub rsp, 0x08
000074703ede1055  push rax
000074703ede1056  push rcx
000074703ede1057  push rdx
000074703ede1058  push rdi
000074703ede1059  push rsi
000074703ede105a  push r8
000074703ede105c  push r9
000074703ede105e  push r10
000074703ede1060  push r11
000074703ede1062  sub rsp, 0xF0
000074703ede1069  vmovaps [rsp], xmm0
000074703ede106e  vmovaps [rsp+0x10], xmm2
000074703ede1074  vmovaps [rsp+0x20], xmm3
000074703ede107a  vmovaps [rsp+0x30], xmm4
000074703ede1080  vmovaps [rsp+0x40], xmm5
000074703ede1086  vmovaps [rsp+0x50], xmm6
000074703ede108c  vmovaps [rsp+0x60], xmm7
000074703ede1092  vmovaps [rsp+0x70], xmm8
000074703ede1098  vmovaps [rsp+0x80], xmm9
000074703ede10a1  vmovaps [rsp+0x90], xmm10
000074703ede10aa  vmovaps [rsp+0xA0], xmm11
000074703ede10b3  vmovaps [rsp+0xB0], xmm12
000074703ede10bc  vmovaps [rsp+0xC0], xmm13
000074703ede10c5  vmovaps [rsp+0xD0], xmm14
000074703ede10ce  vmovaps [rsp+0xE0], xmm15
000074703ede10d7  sub rsp, 0x30
000074703ede10db  movaps [rsp], xmm1
000074703ede10df  movaps [rsp+0x10], xmm13
000074703ede10e5  movaps [rsp+0x20], xmm8
000074703ede10eb  lea rdi, [rsp]
000074703ede10ef  mov esi, 0x00
000074703ede10f4  mov rax, 0x5D9974CCC530
000074703ede10fe  call rax
000074703ede1100  movaps xmm1, [rsp]
000074703ede1104  add rsp, 0x30
000074703ede1108  vmovaps xmm0, [rsp]
000074703ede110d  vmovaps xmm2, [rsp+0x10]
000074703ede1113  vmovaps xmm3, [rsp+0x20]
000074703ede1119  vmovaps xmm4, [rsp+0x30]
000074703ede111f  vmovaps xmm5, [rsp+0x40]
000074703ede1125  vmovaps xmm6, [rsp+0x50]
000074703ede112b  vmovaps xmm7, [rsp+0x60]
000074703ede1131  vmovaps xmm8, [rsp+0x70]
000074703ede1137  vmovaps xmm9, [rsp+0x80]
000074703ede1140  vmovaps xmm10, [rsp+0x90]
000074703ede1149  vmovaps xmm11, [rsp+0xA0]
000074703ede1152  vmovaps xmm12, [rsp+0xB0]
000074703ede115b  vmovaps xmm13, [rsp+0xC0]
000074703ede1164  vmovaps xmm14, [rsp+0xD0]
000074703ede116d  vmovaps xmm15, [rsp+0xE0]
000074703ede1176  add rsp, 0xF0
000074703ede117d  pop r11
000074703ede117f  pop r10
000074703ede1181  pop r9
000074703ede1183  pop r8
000074703ede1185  pop rsi
000074703ede1186  pop rdi
000074703ede1187  pop rdx
000074703ede1188  pop rcx
000074703ede1189  pop rax
000074703ede118a  add rsp, 0x08
000074703ede118e  jmp 0x000074703EDDC74D
000074703ede1193  call 0x000074703EC0C260
000074703ede1198  jmp 0x000074703EDDC75B
000074703ede119d  call 0x000074703ECBD750
000074703ede11a2  jmp 0x000074703EDDC765
000074703ede11a7  sub rsp, 0x08
000074703ede11ab  push rax
000074703ede11ac  push rcx
000074703ede11ad  push rdx
000074703ede11ae  push rdi
000074703ede11af  push rsi
000074703ede11b0  push r8
000074703ede11b2  push r9
000074703ede11b4  push r10
000074703ede11b6  push r11
000074703ede11b8  sub rsp, 0xF0
000074703ede11bf  vmovaps [rsp], xmm0
000074703ede11c4  vmovaps [rsp+0x10], xmm1
000074703ede11ca  vmovaps [rsp+0x20], xmm2
000074703ede11d0  vmovaps [rsp+0x30], xmm3
000074703ede11d6  vmovaps [rsp+0x40], xmm4
000074703ede11dc  vmovaps [rsp+0x50], xmm5
000074703ede11e2  vmovaps [rsp+0x60], xmm6
000074703ede11e8  vmovaps [rsp+0x70], xmm7
000074703ede11ee  vmovaps [rsp+0x80], xmm9
000074703ede11f7  vmovaps [rsp+0x90], xmm10
000074703ede1200  vmovaps [rsp+0xA0], xmm11
000074703ede1209  vmovaps [rsp+0xB0], xmm12
000074703ede1212  vmovaps [rsp+0xC0], xmm13
000074703ede121b  vmovaps [rsp+0xD0], xmm14
000074703ede1224  vmovaps [rsp+0xE0], xmm15
000074703ede122d  sub rsp, 0x30
000074703ede1231  movaps [rsp], xmm8
000074703ede1236  movaps [rsp+0x10], xmm15
000074703ede123c  movaps [rsp+0x20], xmm7
000074703ede1241  lea rdi, [rsp]
000074703ede1245  mov esi, 0x00
000074703ede124a  mov rax, 0x5D9974CCC530
000074703ede1254  call rax
000074703ede1256  movaps xmm8, [rsp]
000074703ede125b  add rsp, 0x30
000074703ede125f  vmovaps xmm0, [rsp]
000074703ede1264  vmovaps xmm1, [rsp+0x10]
000074703ede126a  vmovaps xmm2, [rsp+0x20]
000074703ede1270  vmovaps xmm3, [rsp+0x30]
000074703ede1276  vmovaps xmm4, [rsp+0x40]
000074703ede127c  vmovaps xmm5, [rsp+0x50]
000074703ede1282  vmovaps xmm6, [rsp+0x60]
000074703ede1288  vmovaps xmm7, [rsp+0x70]
000074703ede128e  vmovaps xmm9, [rsp+0x80]
000074703ede1297  vmovaps xmm10, [rsp+0x90]
000074703ede12a0  vmovaps xmm11, [rsp+0xA0]
000074703ede12a9  vmovaps xmm12, [rsp+0xB0]
000074703ede12b2  vmovaps xmm13, [rsp+0xC0]
000074703ede12bb  vmovaps xmm14, [rsp+0xD0]
000074703ede12c4  vmovaps xmm15, [rsp+0xE0]
000074703ede12cd  add rsp, 0xF0
000074703ede12d4  pop r11
000074703ede12d6  pop r10
000074703ede12d8  pop r9
000074703ede12da  pop r8
000074703ede12dc  pop rsi
000074703ede12dd  pop rdi
000074703ede12de  pop rdx
000074703ede12df  pop rcx
000074703ede12e0  pop rax
000074703ede12e1  add rsp, 0x08
000074703ede12e5  jmp 0x000074703EDDC787
000074703ede12ea  sub rsp, 0x08
000074703ede12ee  push rax
000074703ede12ef  push rcx
000074703ede12f0  push rdx
000074703ede12f1  push rdi
000074703ede12f2  push rsi
000074703ede12f3  push r8
000074703ede12f5  push r9
000074703ede12f7  push r10
000074703ede12f9  push r11
000074703ede12fb  sub rsp, 0xF0
000074703ede1302  vmovaps [rsp], xmm0
000074703ede1307  vmovaps [rsp+0x10], xmm1
000074703ede130d  vmovaps [rsp+0x20], xmm2
000074703ede1313  vmovaps [rsp+0x30], xmm3
000074703ede1319  vmovaps [rsp+0x40], xmm4
000074703ede131f  vmovaps [rsp+0x50], xmm5
000074703ede1325  vmovaps [rsp+0x60], xmm6
000074703ede132b  vmovaps [rsp+0x70], xmm8
000074703ede1331  vmovaps [rsp+0x80], xmm9
000074703ede133a  vmovaps [rsp+0x90], xmm10
000074703ede1343  vmovaps [rsp+0xA0], xmm11
000074703ede134c  vmovaps [rsp+0xB0], xmm12
000074703ede1355  vmovaps [rsp+0xC0], xmm13
000074703ede135e  vmovaps [rsp+0xD0], xmm14
000074703ede1367  vmovaps [rsp+0xE0], xmm15
000074703ede1370  sub rsp, 0x30
000074703ede1374  movaps [rsp], xmm7
000074703ede1378  movaps [rsp+0x10], xmm9
000074703ede137e  movaps [rsp+0x20], xmm15
000074703ede1384  lea rdi, [rsp]
000074703ede1388  mov esi, 0x00
000074703ede138d  mov rax, 0x5D9974CCC530
000074703ede1397  call rax
000074703ede1399  movaps xmm7, [rsp]
000074703ede139d  add rsp, 0x30
000074703ede13a1  vmovaps xmm0, [rsp]
000074703ede13a6  vmovaps xmm1, [rsp+0x10]
000074703ede13ac  vmovaps xmm2, [rsp+0x20]
000074703ede13b2  vmovaps xmm3, [rsp+0x30]
000074703ede13b8  vmovaps xmm4, [rsp+0x40]
000074703ede13be  vmovaps xmm5, [rsp+0x50]
000074703ede13c4  vmovaps xmm6, [rsp+0x60]
000074703ede13ca  vmovaps xmm8, [rsp+0x70]
000074703ede13d0  vmovaps xmm9, [rsp+0x80]
000074703ede13d9  vmovaps xmm10, [rsp+0x90]
000074703ede13e2  vmovaps xmm11, [rsp+0xA0]
000074703ede13eb  vmovaps xmm12, [rsp+0xB0]
000074703ede13f4  vmovaps xmm13, [rsp+0xC0]
000074703ede13fd  vmovaps xmm14, [rsp+0xD0]
000074703ede1406  vmovaps xmm15, [rsp+0xE0]
000074703ede140f  add rsp, 0xF0
000074703ede1416  pop r11
000074703ede1418  pop r10
000074703ede141a  pop r9
000074703ede141c  pop r8
000074703ede141e  pop rsi
000074703ede141f  pop rdi
000074703ede1420  pop rdx
000074703ede1421  pop rcx
000074703ede1422  pop rax
000074703ede1423  add rsp, 0x08
000074703ede1427  jmp 0x000074703EDDC7B4
000074703ede142c  sub rsp, 0x08
000074703ede1430  push rax
000074703ede1431  push rcx
000074703ede1432  push rdx
000074703ede1433  push rdi
000074703ede1434  push rsi
000074703ede1435  push r8
000074703ede1437  push r9
000074703ede1439  push r10
000074703ede143b  push r11
000074703ede143d  sub rsp, 0xF0
000074703ede1444  vmovaps [rsp], xmm0
000074703ede1449  vmovaps [rsp+0x10], xmm1
000074703ede144f  vmovaps [rsp+0x20], xmm2
000074703ede1455  vmovaps [rsp+0x30], xmm3
000074703ede145b  vmovaps [rsp+0x40], xmm4
000074703ede1461  vmovaps [rsp+0x50], xmm5
000074703ede1467  vmovaps [rsp+0x60], xmm6
000074703ede146d  vmovaps [rsp+0x70], xmm7
000074703ede1473  vmovaps [rsp+0x80], xmm8
000074703ede147c  vmovaps [rsp+0x90], xmm10
000074703ede1485  vmovaps [rsp+0xA0], xmm11
000074703ede148e  vmovaps [rsp+0xB0], xmm12
000074703ede1497  vmovaps [rsp+0xC0], xmm13
000074703ede14a0  vmovaps [rsp+0xD0], xmm14
000074703ede14a9  vmovaps [rsp+0xE0], xmm15
000074703ede14b2  sub rsp, 0x30
000074703ede14b6  movaps [rsp], xmm9
000074703ede14bb  movaps [rsp+0x10], xmm13
000074703ede14c1  movaps [rsp+0x20], xmm15
000074703ede14c7  lea rdi, [rsp]
000074703ede14cb  mov esi, 0x00
000074703ede14d0  mov rax, 0x5D9974CCC530
000074703ede14da  call rax
000074703ede14dc  movaps xmm9, [rsp]
000074703ede14e1  add rsp, 0x30
000074703ede14e5  vmovaps xmm0, [rsp]
000074703ede14ea  vmovaps xmm1, [rsp+0x10]
000074703ede14f0  vmovaps xmm2, [rsp+0x20]
000074703ede14f6  vmovaps xmm3, [rsp+0x30]
000074703ede14fc  vmovaps xmm4, [rsp+0x40]
000074703ede1502  vmovaps xmm5, [rsp+0x50]
000074703ede1508  vmovaps xmm6, [rsp+0x60]
000074703ede150e  vmovaps xmm7, [rsp+0x70]
000074703ede1514  vmovaps xmm8, [rsp+0x80]
000074703ede151d  vmovaps xmm10, [rsp+0x90]
000074703ede1526  vmovaps xmm11, [rsp+0xA0]
000074703ede152f  vmovaps xmm12, [rsp+0xB0]
000074703ede1538  vmovaps xmm13, [rsp+0xC0]
000074703ede1541  vmovaps xmm14, [rsp+0xD0]
000074703ede154a  vmovaps xmm15, [rsp+0xE0]
000074703ede1553  add rsp, 0xF0
000074703ede155a  pop r11
000074703ede155c  pop r10
000074703ede155e  pop r9
000074703ede1560  pop r8
000074703ede1562  pop rsi
000074703ede1563  pop rdi
000074703ede1564  pop rdx
000074703ede1565  pop rcx
000074703ede1566  pop rax
000074703ede1567  add rsp, 0x08
000074703ede156b  jmp 0x000074703EDDC7E2
000074703ede1570  sub rsp, 0x08
000074703ede1574  push rax
000074703ede1575  push rcx
000074703ede1576  push rdx
000074703ede1577  push rdi
000074703ede1578  push rsi
000074703ede1579  push r8
000074703ede157b  push r9
000074703ede157d  push r10
000074703ede157f  push r11
000074703ede1581  sub rsp, 0xF0
000074703ede1588  vmovaps [rsp], xmm0
000074703ede158d  vmovaps [rsp+0x10], xmm1
000074703ede1593  vmovaps [rsp+0x20], xmm2
000074703ede1599  vmovaps [rsp+0x30], xmm3
000074703ede159f  vmovaps [rsp+0x40], xmm4
000074703ede15a5  vmovaps [rsp+0x50], xmm5
000074703ede15ab  vmovaps [rsp+0x60], xmm6
000074703ede15b1  vmovaps [rsp+0x70], xmm7
000074703ede15b7  vmovaps [rsp+0x80], xmm8
000074703ede15c0  vmovaps [rsp+0x90], xmm9
000074703ede15c9  vmovaps [rsp+0xA0], xmm10
000074703ede15d2  vmovaps [rsp+0xB0], xmm11
000074703ede15db  vmovaps [rsp+0xC0], xmm12
000074703ede15e4  vmovaps [rsp+0xD0], xmm13
000074703ede15ed  vmovaps [rsp+0xE0], xmm14
000074703ede15f6  sub rsp, 0x30
000074703ede15fa  movaps [rsp], xmm15
000074703ede15ff  movaps [rsp+0x10], xmm11
000074703ede1605  movaps [rsp+0x20], xmm12
000074703ede160b  lea rdi, [rsp]
000074703ede160f  mov esi, 0x00
000074703ede1614  mov rax, 0x5D9974CCC530
000074703ede161e  call rax
000074703ede1620  movaps xmm15, [rsp]
000074703ede1625  add rsp, 0x30
000074703ede1629  vmovaps xmm0, [rsp]
000074703ede162e  vmovaps xmm1, [rsp+0x10]
000074703ede1634  vmovaps xmm2, [rsp+0x20]
000074703ede163a  vmovaps xmm3, [rsp+0x30]
000074703ede1640  vmovaps xmm4, [rsp+0x40]
000074703ede1646  vmovaps xmm5, [rsp+0x50]
000074703ede164c  vmovaps xmm6, [rsp+0x60]
000074703ede1652  vmovaps xmm7, [rsp+0x70]
000074703ede1658  vmovaps xmm8, [rsp+0x80]
000074703ede1661  vmovaps xmm9, [rsp+0x90]
000074703ede166a  vmovaps xmm10, [rsp+0xA0]
000074703ede1673  vmovaps xmm11, [rsp+0xB0]
000074703ede167c  vmovaps xmm12, [rsp+0xC0]
000074703ede1685  vmovaps xmm13, [rsp+0xD0]
000074703ede168e  vmovaps xmm14, [rsp+0xE0]
000074703ede1697  add rsp, 0xF0
000074703ede169e  pop r11
000074703ede16a0  pop r10
000074703ede16a2  pop r9
000074703ede16a4  pop r8
000074703ede16a6  pop rsi
000074703ede16a7  pop rdi
000074703ede16a8  pop rdx
000074703ede16a9  pop rcx
000074703ede16aa  pop rax
000074703ede16ab  add rsp, 0x08
000074703ede16af  jmp 0x000074703EDDC7FD
000074703ede16b4  sub rsp, 0x08
000074703ede16b8  push rax
000074703ede16b9  push rcx
000074703ede16ba  push rdx
000074703ede16bb  push rdi
000074703ede16bc  push rsi
000074703ede16bd  push r8
000074703ede16bf  push r9
000074703ede16c1  push r10
000074703ede16c3  push r11
000074703ede16c5  sub rsp, 0xF0
000074703ede16cc  vmovaps [rsp], xmm0
000074703ede16d1  vmovaps [rsp+0x10], xmm1
000074703ede16d7  vmovaps [rsp+0x20], xmm2
000074703ede16dd  vmovaps [rsp+0x30], xmm3
000074703ede16e3  vmovaps [rsp+0x40], xmm4
000074703ede16e9  vmovaps [rsp+0x50], xmm5
000074703ede16ef  vmovaps [rsp+0x60], xmm6
000074703ede16f5  vmovaps [rsp+0x70], xmm7
000074703ede16fb  vmovaps [rsp+0x80], xmm8
000074703ede1704  vmovaps [rsp+0x90], xmm9
000074703ede170d  vmovaps [rsp+0xA0], xmm10
000074703ede1716  vmovaps [rsp+0xB0], xmm11
000074703ede171f  vmovaps [rsp+0xC0], xmm12
000074703ede1728  vmovaps [rsp+0xD0], xmm14
000074703ede1731  vmovaps [rsp+0xE0], xmm15
000074703ede173a  sub rsp, 0x30
000074703ede173e  movaps [rsp], xmm13
000074703ede1743  movaps [rsp+0x10], xmm10
000074703ede1749  movaps [rsp+0x20], xmm14
000074703ede174f  lea rdi, [rsp]
000074703ede1753  mov esi, 0x00
000074703ede1758  mov rax, 0x5D9974CCC530
000074703ede1762  call rax
000074703ede1764  movaps xmm13, [rsp]
000074703ede1769  add rsp, 0x30
000074703ede176d  vmovaps xmm0, [rsp]
000074703ede1772  vmovaps xmm1, [rsp+0x10]
000074703ede1778  vmovaps xmm2, [rsp+0x20]
000074703ede177e  vmovaps xmm3, [rsp+0x30]
000074703ede1784  vmovaps xmm4, [rsp+0x40]
000074703ede178a  vmovaps xmm5, [rsp+0x50]
000074703ede1790  vmovaps xmm6, [rsp+0x60]
000074703ede1796  vmovaps xmm7, [rsp+0x70]
000074703ede179c  vmovaps xmm8, [rsp+0x80]
000074703ede17a5  vmovaps xmm9, [rsp+0x90]
000074703ede17ae  vmovaps xmm10, [rsp+0xA0]
000074703ede17b7  vmovaps xmm11, [rsp+0xB0]
000074703ede17c0  vmovaps xmm12, [rsp+0xC0]
000074703ede17c9  vmovaps xmm14, [rsp+0xD0]
000074703ede17d2  vmovaps xmm15, [rsp+0xE0]
000074703ede17db  add rsp, 0xF0
000074703ede17e2  pop r11
000074703ede17e4  pop r10
000074703ede17e6  pop r9
000074703ede17e8  pop r8
000074703ede17ea  pop rsi
000074703ede17eb  pop rdi
000074703ede17ec  pop rdx
000074703ede17ed  pop rcx
000074703ede17ee  pop rax
000074703ede17ef  add rsp, 0x08
000074703ede17f3  jmp 0x000074703EDDC820
000074703ede17f8  sub rsp, 0x08
000074703ede17fc  push rax
000074703ede17fd  push rcx
000074703ede17fe  push rdx
000074703ede17ff  push rdi
000074703ede1800  push rsi
000074703ede1801  push r8
000074703ede1803  push r9
000074703ede1805  push r10
000074703ede1807  push r11
000074703ede1809  sub rsp, 0xF0
000074703ede1810  vmovaps [rsp], xmm0
000074703ede1815  vmovaps [rsp+0x10], xmm1
000074703ede181b  vmovaps [rsp+0x20], xmm2
000074703ede1821  vmovaps [rsp+0x30], xmm3
000074703ede1827  vmovaps [rsp+0x40], xmm4
000074703ede182d  vmovaps [rsp+0x50], xmm5
000074703ede1833  vmovaps [rsp+0x60], xmm6
000074703ede1839  vmovaps [rsp+0x70], xmm7
000074703ede183f  vmovaps [rsp+0x80], xmm8
000074703ede1848  vmovaps [rsp+0x90], xmm9
000074703ede1851  vmovaps [rsp+0xA0], xmm10
000074703ede185a  vmovaps [rsp+0xB0], xmm11
000074703ede1863  vmovaps [rsp+0xC0], xmm12
000074703ede186c  vmovaps [rsp+0xD0], xmm13
000074703ede1875  vmovaps [rsp+0xE0], xmm15
000074703ede187e  sub rsp, 0x30
000074703ede1882  movaps [rsp], xmm14
000074703ede1887  movaps [rsp+0x10], xmm1
000074703ede188c  movaps [rsp+0x20], xmm7
000074703ede1891  lea rdi, [rsp]
000074703ede1895  mov esi, 0x00
000074703ede189a  mov rax, 0x5D9974CCC530
000074703ede18a4  call rax
000074703ede18a6  movaps xmm14, [rsp]
000074703ede18ab  add rsp, 0x30
000074703ede18af  vmovaps xmm0, [rsp]
000074703ede18b4  vmovaps xmm1, [rsp+0x10]
000074703ede18ba  vmovaps xmm2, [rsp+0x20]
000074703ede18c0  vmovaps xmm3, [rsp+0x30]
000074703ede18c6  vmovaps xmm4, [rsp+0x40]
000074703ede18cc  vmovaps xmm5, [rsp+0x50]
000074703ede18d2  vmovaps xmm6, [rsp+0x60]
000074703ede18d8  vmovaps xmm7, [rsp+0x70]
000074703ede18de  vmovaps xmm8, [rsp+0x80]
000074703ede18e7  vmovaps xmm9, [rsp+0x90]
000074703ede18f0  vmovaps xmm10, [rsp+0xA0]
000074703ede18f9  vmovaps xmm11, [rsp+0xB0]
000074703ede1902  vmovaps xmm12, [rsp+0xC0]
000074703ede190b  vmovaps xmm13, [rsp+0xD0]
000074703ede1914  vmovaps xmm15, [rsp+0xE0]
000074703ede191d  add rsp, 0xF0
000074703ede1924  pop r11
000074703ede1926  pop r10
000074703ede1928  pop r9
000074703ede192a  pop r8
000074703ede192c  pop rsi
000074703ede192d  pop rdi
000074703ede192e  pop rdx
000074703ede192f  pop rcx
000074703ede1930  pop rax
000074703ede1931  add rsp, 0x08
000074703ede1935  jmp 0x000074703EDDC843
000074703ede193a  sub rsp, 0x08
000074703ede193e  push rax
000074703ede193f  push rcx
000074703ede1940  push rdx
000074703ede1941  push rdi
000074703ede1942  push rsi
000074703ede1943  push r8
000074703ede1945  push r9
000074703ede1947  push r10
000074703ede1949  push r11
000074703ede194b  sub rsp, 0xF0
000074703ede1952  vmovaps [rsp], xmm0
000074703ede1957  vmovaps [rsp+0x10], xmm2
000074703ede195d  vmovaps [rsp+0x20], xmm3
000074703ede1963  vmovaps [rsp+0x30], xmm4
000074703ede1969  vmovaps [rsp+0x40], xmm5
000074703ede196f  vmovaps [rsp+0x50], xmm6
000074703ede1975  vmovaps [rsp+0x60], xmm7
000074703ede197b  vmovaps [rsp+0x70], xmm8
000074703ede1981  vmovaps [rsp+0x80], xmm9
000074703ede198a  vmovaps [rsp+0x90], xmm10
000074703ede1993  vmovaps [rsp+0xA0], xmm11
000074703ede199c  vmovaps [rsp+0xB0], xmm12
000074703ede19a5  vmovaps [rsp+0xC0], xmm13
000074703ede19ae  vmovaps [rsp+0xD0], xmm14
000074703ede19b7  vmovaps [rsp+0xE0], xmm15
000074703ede19c0  sub rsp, 0x30
000074703ede19c4  movaps [rsp], xmm1
000074703ede19c8  movaps [rsp+0x10], xmm8
000074703ede19ce  movaps [rsp+0x20], xmm9
000074703ede19d4  lea rdi, [rsp]
000074703ede19d8  mov esi, 0x00
000074703ede19dd  mov rax, 0x5D9974CCC530
000074703ede19e7  call rax
000074703ede19e9  movaps xmm1, [rsp]
000074703ede19ed  add rsp, 0x30
000074703ede19f1  vmovaps xmm0, [rsp]
000074703ede19f6  vmovaps xmm2, [rsp+0x10]
000074703ede19fc  vmovaps xmm3, [rsp+0x20]
000074703ede1a02  vmovaps xmm4, [rsp+0x30]
000074703ede1a08  vmovaps xmm5, [rsp+0x40]
000074703ede1a0e  vmovaps xmm6, [rsp+0x50]
000074703ede1a14  vmovaps xmm7, [rsp+0x60]
000074703ede1a1a  vmovaps xmm8, [rsp+0x70]
000074703ede1a20  vmovaps xmm9, [rsp+0x80]
000074703ede1a29  vmovaps xmm10, [rsp+0x90]
000074703ede1a32  vmovaps xmm11, [rsp+0xA0]
000074703ede1a3b  vmovaps xmm12, [rsp+0xB0]
000074703ede1a44  vmovaps xmm13, [rsp+0xC0]
000074703ede1a4d  vmovaps xmm14, [rsp+0xD0]
000074703ede1a56  vmovaps xmm15, [rsp+0xE0]
000074703ede1a5f  add rsp, 0xF0
000074703ede1a66  pop r11
000074703ede1a68  pop r10
000074703ede1a6a  pop r9
000074703ede1a6c  pop r8
000074703ede1a6e  pop rsi
000074703ede1a6f  pop rdi
000074703ede1a70  pop rdx
000074703ede1a71  pop rcx
000074703ede1a72  pop rax
000074703ede1a73  add rsp, 0x08
000074703ede1a77  jmp 0x000074703EDDC865
000074703ede1a7c  call 0x000074703ECE5940
000074703ede1a81  jmp 0x000074703EDDC873
000074703ede1a86  call 0x000074703EC0C380
000074703ede1a8b  jmp 0x000074703EDDC87D
000074703ede1a90  call 0x000074703EC0D600
000074703ede1a95  jmp 0x000074703EDDC887
000074703ede1a9a  call 0x000074703EBFF540
000074703ede1a9f  jmp 0x000074703EDDC891
000074703ede1aa4  int3
000074703ede1aa5  nop [rax+rax*1], ax
000074703ede1aae  nop
000074703ede1ab0  mov rax, [r15+0xF8]
000074703ede1ab7  lea r14, [rax+0x140]
000074703ede1abe  mov r12, [r13+r14*1]
000074703ede1ac3  mov [r15+0xE8], r12
000074703ede1aca  lea r14, [rax+0x130]
000074703ede1ad1  mov r12, [r13+r14*1]
000074703ede1ad6  lea r14, [rax+0x138]
000074703ede1add  mov r11, [r13+r14*1]
000074703ede1ae2  movq xmm1, r12
000074703ede1ae7  movq xmm15, r11
000074703ede1aec  movq xmm1, xmm1
000074703ede1af0  movq xmm1, xmm1
000074703ede1af4  movaps [r15+0x1A0], xmm1
000074703ede1afc  movq xmm15, xmm15
000074703ede1b01  movq xmm15, xmm15
000074703ede1b06  movaps [r15+0x190], xmm15
000074703ede1b0e  lea r14, [rax+0x120]
000074703ede1b15  mov r12, [r13+r14*1]
000074703ede1b1a  lea r14, [rax+0x128]
000074703ede1b21  mov r11, [r13+r14*1]
000074703ede1b26  movq xmm1, r12
000074703ede1b2b  movq xmm15, r11
000074703ede1b30  movq xmm1, xmm1
000074703ede1b34  movq xmm1, xmm1
000074703ede1b38  movaps [r15+0x1C0], xmm1
000074703ede1b40  movq xmm15, xmm15
000074703ede1b45  movq xmm15, xmm15
000074703ede1b4a  movaps [r15+0x1B0], xmm15
000074703ede1b52  lea r14, [rax+0x110]
000074703ede1b59  mov r12, [r13+r14*1]
000074703ede1b5e  lea r14, [rax+0x118]
000074703ede1b65  mov r11, [r13+r14*1]
000074703ede1b6a  movq xmm1, r12
000074703ede1b6f  movq xmm15, r11
000074703ede1b74  movq xmm1, xmm1
000074703ede1b78  movq xmm1, xmm1
000074703ede1b7c  movaps [r15+0x1E0], xmm1
000074703ede1b84  movq xmm15, xmm15
000074703ede1b89  movq xmm15, xmm15
000074703ede1b8e  movaps [r15+0x1D0], xmm15
000074703ede1b96  lea r14, [rax+0x100]
000074703ede1b9d  mov r12, [r13+r14*1]
000074703ede1ba2  lea r14, [rax+0x108]
000074703ede1ba9  mov r11, [r13+r14*1]
000074703ede1bae  movq xmm1, r12
000074703ede1bb3  movq xmm15, r11
000074703ede1bb8  movq xmm1, xmm1
000074703ede1bbc  movq xmm1, xmm1
000074703ede1bc0  movaps [r15+0x200], xmm1
000074703ede1bc8  movq xmm15, xmm15
000074703ede1bcd  movq xmm15, xmm15
000074703ede1bd2  movaps [r15+0x1F0], xmm15
000074703ede1bda  mov qword ptr [r15+0x40], 0x430000
000074703ede1be2  mov r14d, 0x430510
000074703ede1be8  mov r12, [r13+r14*1]
000074703ede1bed  movq xmm1, r12
000074703ede1bf2  lea r14, [rax+0x150]
000074703ede1bf9  mov [r15+0xF8], r14
000074703ede1c00  mov rax, [r15+0x50]
000074703ede1c04  movups xmm15, [r13+rax*1]
000074703ede1c0a  movaps [r15+0x120], xmm15
000074703ede1c12  mov qword ptr [r15+0x48], 0x10
000074703ede1c1a  xor eax, eax
000074703ede1c1c  mov r14d, 0x10
000074703ede1c22  mov r12d, 0x200
000074703ede1c28  cmp r14, r12
000074703ede1c2b  cmc
000074703ede1c2c  lahf
000074703ede1c2d  seto al
000074703ede1c30  mov [r15+0x108], eax
000074703ede1c37  pextrq rax, xmm15, 0x01
000074703ede1c3e  movq xmm14, rax
000074703ede1c43  movaps [r15+0x130], xmm14
000074703ede1c4b  movq rax, xmm1
000074703ede1c50  movq r14, xmm15
000074703ede1c55  vmovq xmm1, rax
000074703ede1c5a  vmovq xmm15, r14
000074703ede1c5f  movaps xmm13, xmm1
000074703ede1c63  addsd xmm13, xmm15
000074703ede1c68  ucomisd xmm13, xmm13
000074703ede1c6d  jp 0x000074703EDE1D86
000074703ede1c73  movq xmm13, xmm13
000074703ede1c78  movq rax, xmm13
000074703ede1c7d  movq r14, xmm14
000074703ede1c82  vmovq xmm1, rax
000074703ede1c87  vmovq xmm15, r14
000074703ede1c8c  movaps xmm14, xmm1
000074703ede1c90  addsd xmm14, xmm15
000074703ede1c95  ucomisd xmm14, xmm14
000074703ede1c9a  jp 0x000074703EDE1DCE
000074703ede1ca0  movq xmm14, xmm14
000074703ede1ca5  movaps [r15+0x110], xmm14
000074703ede1cad  mov eax, [r15+0x108]
000074703ede1cb4  sahf
000074703ede1cb5  jnz 0x000074703EDE1CE7
000074703ede1cb7  cmp dword ptr [r15+0x318], 0x00
000074703ede1cbf  jz 0x000074703EDE1FE0
000074703ede1cc5  nop [rax+rax*1], ax
000074703ede1cce  nop [rax+rax*1], eax
000074703ede1cd6  mov eax, 0x410490
000074703ede1cdb  mov [r15+0x100], rax
000074703ede1ce2  jmp 0x000074703EBFE110
000074703ede1ce7  cmp dword ptr [r15+0x318], 0x00
000074703ede1cef  jz 0x000074703EDE1E20
000074703ede1cf5  nop [rax+rax*1], ax
000074703ede1cfe  nop [rax+rax*1], eax
000074703ede1d06  mov eax, 0x410474
000074703ede1d0b  mov [r15+0x100], rax
000074703ede1d12  jmp 0x000074703EBFE110
000074703ede1d17  int3
000074703ede1d18  call 0x000074703ECE27E0
000074703ede1d1d  jmp 0x000074703EDE1AC3
000074703ede1d22  call 0x000074703ECE27E0
000074703ede1d27  jmp 0x000074703EDE1AD6
000074703ede1d2c  call 0x000074703ECE1570
000074703ede1d31  jmp 0x000074703EDE1AE2
000074703ede1d36  call 0x000074703ECE27E0
000074703ede1d3b  jmp 0x000074703EDE1B1A
000074703ede1d40  call 0x000074703ECE1570
000074703ede1d45  jmp 0x000074703EDE1B26
000074703ede1d4a  call 0x000074703ECE27E0
000074703ede1d4f  jmp 0x000074703EDE1B5E
000074703ede1d54  call 0x000074703ECE1570
000074703ede1d59  jmp 0x000074703EDE1B6A
000074703ede1d5e  call 0x000074703ECE27E0
000074703ede1d63  jmp 0x000074703EDE1BA2
000074703ede1d68  call 0x000074703ECE1570
000074703ede1d6d  jmp 0x000074703EDE1BAE
000074703ede1d72  call 0x000074703ECE27E0
000074703ede1d77  jmp 0x000074703EDE1BED
000074703ede1d7c  call 0x000074703EC0E760
000074703ede1d81  jmp 0x000074703EDE1C0A
000074703ede1d86  ucomisd xmm1, xmm15
000074703ede1d8b  jp 0x000074703EDE1D9A
000074703ede1d8d  movaps xmm13, [0x000074703E9FE060]
000074703ede1d95  jmp 0x000074703EDE1C73
000074703ede1d9a  vxorps xmm0, xmm1, xmm15
000074703ede1d9f  pextrw eax, xmm0, 0x03
000074703ede1da4  and eax, 0x7FF8
000074703ede1da9  cmp eax, 0x08
000074703ede1dac  jnz 0x000074703EDE1C73
000074703ede1db2  movq rax, xmm15
000074703ede1db7  shl rax, 0x0D
000074703ede1dbb  jbe 0x000074703EDE1C73
000074703ede1dc1  vorps xmm13, xmm15, [0x000074703E9FE070]
000074703ede1dc9  jmp 0x000074703EDE1C73
000074703ede1dce  ucomisd xmm1, xmm15
000074703ede1dd3  jp 0x000074703EDE1DE2
000074703ede1dd5  movaps xmm14, [0x000074703E9FE060]
000074703ede1ddd  jmp 0x000074703EDE1CA0
000074703ede1de2  vxorps xmm0, xmm1, xmm15
000074703ede1de7  pextrw eax, xmm0, 0x03
000074703ede1dec  and eax, 0x7FF8
000074703ede1df1  cmp eax, 0x08
000074703ede1df4  jnz 0x000074703EDE1CA0
000074703ede1dfa  movq rax, xmm15
000074703ede1dff  shl rax, 0x0D
000074703ede1e03  jbe 0x000074703EDE1CA0
000074703ede1e09  vorps xmm14, xmm15, [0x000074703E9FE070]
000074703ede1e11  jmp 0x000074703EDE1CA0
000074703ede1e16  int3
000074703ede1e17  nop [rax+rax*1], ax
000074703ede1e20  mov rax, [r15+0x48]
000074703ede1e24  mov r14, [r15+0x50]
000074703ede1e28  lea r12, [r14+rax*1]
000074703ede1e2c  movups xmm1, [r13+r12*1]
000074703ede1e32  movaps [r15+0x120], xmm1
000074703ede1e3a  lea r14, [rax+0x10]
000074703ede1e3e  mov [r15+0x48], r14
000074703ede1e42  xor eax, eax
000074703ede1e44  mov r12d, 0x200
000074703ede1e4a  cmp r14, r12
000074703ede1e4d  cmc
000074703ede1e4e  lahf
000074703ede1e4f  seto al
000074703ede1e52  mov [r15+0x108], eax
000074703ede1e59  pextrq rax, xmm1, 0x01
000074703ede1e60  movq xmm15, rax
000074703ede1e65  movaps [r15+0x130], xmm15
000074703ede1e6d  movaps xmm14, [r15+0x110]
000074703ede1e75  movq rax, xmm14
000074703ede1e7a  movq r14, xmm1
000074703ede1e7f  vmovq xmm1, rax
000074703ede1e84  vmovq xmm14, r14
000074703ede1e89  movaps xmm13, xmm1
000074703ede1e8d  addsd xmm13, xmm14
000074703ede1e92  ucomisd xmm13, xmm13
000074703ede1e97  jp 0x000074703EDE1F4C
000074703ede1e9d  movq xmm13, xmm13
000074703ede1ea2  movq rax, xmm13
000074703ede1ea7  movq r14, xmm15
000074703ede1eac  vmovq xmm1, rax
000074703ede1eb1  vmovq xmm15, r14
000074703ede1eb6  movaps xmm14, xmm1
000074703ede1eba  addsd xmm14, xmm15
000074703ede1ebf  ucomisd xmm14, xmm14
000074703ede1ec4  jp 0x000074703EDE1F94
000074703ede1eca  movq xmm14, xmm14
000074703ede1ecf  movaps [r15+0x110], xmm14
000074703ede1ed7  mov eax, [r15+0x108]
000074703ede1ede  sahf
000074703ede1edf  jnz 0x000074703EDE1F11
000074703ede1ee1  cmp dword ptr [r15+0x318], 0x00
000074703ede1ee9  jz 0x000074703EDE1FE0
000074703ede1eef  nop [rax+rax*1], ax
000074703ede1ef8  nop [rax+rax*1], eax
000074703ede1f00  mov eax, 0x410490
000074703ede1f05  mov [r15+0x100], rax
000074703ede1f0c  jmp 0x000074703EBFE110
000074703ede1f11  cmp dword ptr [r15+0x318], 0x00
000074703ede1f19  jz 0x000074703EDE1E20
000074703ede1f1f  nop [rax+rax*1], ax
000074703ede1f28  nop [rax+rax*1], eax
000074703ede1f30  mov eax, 0x410474
000074703ede1f35  mov [r15+0x100], rax
000074703ede1f3c  jmp 0x000074703EBFE110
000074703ede1f41  int3
000074703ede1f42  call 0x000074703ECB52F0
000074703ede1f47  jmp 0x000074703EDE1E32
000074703ede1f4c  ucomisd xmm1, xmm14
000074703ede1f51  jp 0x000074703EDE1F60
000074703ede1f53  movaps xmm13, [0x000074703E9FE060]
000074703ede1f5b  jmp 0x000074703EDE1E9D
000074703ede1f60  vxorps xmm0, xmm1, xmm14
000074703ede1f65  pextrw eax, xmm0, 0x03
000074703ede1f6a  and eax, 0x7FF8
000074703ede1f6f  cmp eax, 0x08
000074703ede1f72  jnz 0x000074703EDE1E9D
000074703ede1f78  movq rax, xmm14
000074703ede1f7d  shl rax, 0x0D
000074703ede1f81  jbe 0x000074703EDE1E9D
000074703ede1f87  vorps xmm13, xmm14, [0x000074703E9FE070]
000074703ede1f8f  jmp 0x000074703EDE1E9D
000074703ede1f94  ucomisd xmm1, xmm15
000074703ede1f99  jp 0x000074703EDE1FA8
000074703ede1f9b  movaps xmm14, [0x000074703E9FE060]
000074703ede1fa3  jmp 0x000074703EDE1ECA
000074703ede1fa8  vxorps xmm0, xmm1, xmm15
000074703ede1fad  pextrw eax, xmm0, 0x03
000074703ede1fb2  and eax, 0x7FF8
000074703ede1fb7  cmp eax, 0x08
000074703ede1fba  jnz 0x000074703EDE1ECA
000074703ede1fc0  movq rax, xmm15
000074703ede1fc5  shl rax, 0x0D
000074703ede1fc9  jbe 0x000074703EDE1ECA
000074703ede1fcf  vorps xmm14, xmm15, [0x000074703E9FE070]
000074703ede1fd7  jmp 0x000074703EDE1ECA
000074703ede1fdc  int3
000074703ede1fdd  nop [rax], eax
000074703ede1fe0  mov rax, [r15+0x40]
000074703ede1fe4  lea r14, [rax+0x510]
000074703ede1feb  movaps xmm1, [r15+0x110]
000074703ede1ff3  movq rax, xmm1
000074703ede1ff8  mov [r13+r14*1], rax
000074703ede1ffd  mov rax, [r15+0xF0]
000074703ede2004  mov [r15+0x100], rax
000074703ede200b  jmp 0x000074703EDCE5C0
000074703ede2010  int3
000074703ede2011  call 0x000074703ECD5EB0
000074703ede2016  jmp 0x000074703EDE1FFD
000074703ede201b  int3
000074703ede201c  nop [rax], eax
000074703ede2020  mov qword ptr [r15+0x100], 0x04
000074703ede202b  mov esi, 0x00
000074703ede2030  mov edx, 0x09
000074703ede2035  mov rdi, 0x7FFCCCBCE280
000074703ede203f  mov rax, 0x5D9974B5F970
000074703ede2049  call rax
000074703ede204b  cmp dword ptr [r15+0x318], 0x00
000074703ede2053  jnz 0x000074703EBFE110
000074703ede2059  jmp 0x000074703EBFE0A0
000074703ede205e  int3
000074703ede205f  int3
