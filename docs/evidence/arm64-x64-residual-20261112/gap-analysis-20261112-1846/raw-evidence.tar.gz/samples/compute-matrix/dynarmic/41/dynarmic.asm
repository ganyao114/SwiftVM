000071e7f4dce69b  nop [rax+rax*1], eax
000071e7f4dce6a0  vmovaps xmm1, [0x000071E7F49FE010]
000071e7f4dce6a8  movq xmm1, xmm1
000071e7f4dce6ac  movaps [r15+0x110], xmm1
000071e7f4dce6b4  vmovaps xmm1, [0x000071E7F49FE020]
000071e7f4dce6bc  movq xmm1, xmm1
000071e7f4dce6c0  movaps [r15+0x120], xmm1
000071e7f4dce6c8  mov eax, 0x4204C0
000071e7f4dce6cd  mov r14, [r13+rax*1]
000071e7f4dce6d2  movq xmm1, r14
000071e7f4dce6d7  movaps [r15+0x130], xmm1
000071e7f4dce6df  vmovaps xmm1, [0x000071E7F49FE030]
000071e7f4dce6e7  vpbroadcastq xmm1, xmm1
000071e7f4dce6ec  movaps [r15+0x140], xmm1
000071e7f4dce6f4  mov qword ptr [r15+0x40], 0x02
000071e7f4dce6fc  vmovaps xmm15, [0x000071E7F49FE040]
000071e7f4dce704  movq xmm15, xmm15
000071e7f4dce709  movaps [r15+0x150], xmm15
000071e7f4dce711  mov qword ptr [r15+0x58], 0x420000
000071e7f4dce719  vmovaps xmm15, [0x000071E7F49FE050]
000071e7f4dce721  vpbroadcastq xmm15, xmm15
000071e7f4dce726  movaps [r15+0x160], xmm15
000071e7f4dce72e  mov rax, [r15+0x40]
000071e7f4dce732  vmovq xmm14, rax
000071e7f4dce737  vpbroadcastq xmm14, xmm14
000071e7f4dce73c  movaps [r15+0x170], xmm14
000071e7f4dce744  mov eax, 0x4204D0
000071e7f4dce749  movups xmm13, [r13+rax*1]
000071e7f4dce74f  mov qword ptr [r15+0x40], 0x430518
000071e7f4dce757  mov qword ptr [r15+0x50], 0x430720
000071e7f4dce75f  vpmovqd xmm12, xmm13
000071e7f4dce765  pxor xmm11, xmm11
000071e7f4dce76a  punpcklqdq xmm12, xmm11
000071e7f4dce76f  movaps [r15+0x210], xmm12
000071e7f4dce777  movq xmm12, qword ptr [r15+0x120]
000071e7f4dce780  movq xmm11, qword ptr [r15+0x130]
000071e7f4dce789  psubd xmm12, xmm11
000071e7f4dce78e  movq xmm12, xmm12
000071e7f4dce793  paddq xmm13, xmm14
000071e7f4dce798  movaps [r15+0x180], xmm13
000071e7f4dce7a0  movq xmm14, qword ptr [r15+0x150]
000071e7f4dce7a9  paddd xmm11, xmm14
000071e7f4dce7ae  movq xmm11, xmm11
000071e7f4dce7b3  movq xmm11, xmm11
000071e7f4dce7b8  movaps [r15+0x130], xmm11
000071e7f4dce7c0  pmovzxdq xmm12, xmm12
000071e7f4dce7c6  psllq xmm12, 0x00
000071e7f4dce7cc  movq xmm14, qword ptr [r15+0x210]
000071e7f4dce7d5  movq xmm13, qword ptr [r15+0x110]
000071e7f4dce7de  paddd xmm14, xmm13
000071e7f4dce7e3  movq xmm14, xmm14
000071e7f4dce7e8  vcvtuqq2pd xmm12, xmm12
000071e7f4dce7ee  pmovzxdq xmm14, xmm14
000071e7f4dce7f4  psllq xmm14, 0x00
000071e7f4dce7fa  vcvtuqq2pd xmm14, xmm14
000071e7f4dce800  movaps xmm13, xmm12
000071e7f4dce804  mulpd xmm13, xmm1
000071e7f4dce809  vcmppd xmm11, xmm13, xmm13, 0x03
000071e7f4dce80f  ptest xmm11, xmm11
000071e7f4dce815  jnz 0x000071E7F4DCE8FF
000071e7f4dce81b  movaps [r15+0x220], xmm13
000071e7f4dce823  mov eax, 0x430720
000071e7f4dce828  movups [r13+rax*1], xmm13
000071e7f4dce82e  movaps xmm1, xmm14
000071e7f4dce832  mulpd xmm1, xmm15
000071e7f4dce837  vcmppd xmm13, xmm1, xmm1, 0x03
000071e7f4dce83c  ptest xmm13, xmm13
000071e7f4dce842  jnz 0x000071E7F4DCEA4C
000071e7f4dce848  movaps [r15+0x210], xmm1
000071e7f4dce850  mov eax, 0x430518
000071e7f4dce855  movups [r13+rax*1], xmm1
000071e7f4dce85b  mov qword ptr [r15+0x48], 0x10
000071e7f4dce863  xor eax, eax
000071e7f4dce865  mov r14d, 0x10
000071e7f4dce86b  mov r12d, 0x200
000071e7f4dce871  cmp r14, r12
000071e7f4dce874  cmc
000071e7f4dce875  lahf
000071e7f4dce876  seto al
000071e7f4dce879  mov [r15+0x108], eax
000071e7f4dce880  mov eax, [r15+0x108]
000071e7f4dce887  sahf
000071e7f4dce888  jnz 0x000071E7F4DCE8BA
000071e7f4dce88a  cmp dword ptr [r15+0x318], 0x00
000071e7f4dce892  jz 0x000071E7F4DCEFF0
000071e7f4dce898  nop [rax+rax*1], ax
000071e7f4dce8a1  nop [rax+rax*1], eax
000071e7f4dce8a9  mov eax, 0x4101EC
000071e7f4dce8ae  mov [r15+0x100], rax
000071e7f4dce8b5  jmp 0x000071E7F4BFE110
000071e7f4dce8ba  cmp dword ptr [r15+0x318], 0x00
000071e7f4dce8c2  jz 0x000071E7F4DCEBA0
000071e7f4dce8c8  nop [rax+rax*1], ax
000071e7f4dce8d1  nop [rax+rax*1], eax
000071e7f4dce8d9  mov eax, 0x4101AC
000071e7f4dce8de  mov [r15+0x100], rax
000071e7f4dce8e5  jmp 0x000071E7F4BFE110
000071e7f4dce8ea  int3
000071e7f4dce8eb  call 0x000071E7F4C0DC20
000071e7f4dce8f0  jmp 0x000071E7F4DCE6D2
000071e7f4dce8f5  call 0x000071E7F4C0C260
000071e7f4dce8fa  jmp 0x000071E7F4DCE74F
000071e7f4dce8ff  sub rsp, 0x08
000071e7f4dce903  push rax
000071e7f4dce904  push rcx
000071e7f4dce905  push rdx
000071e7f4dce906  push rdi
000071e7f4dce907  push rsi
000071e7f4dce908  push r8
000071e7f4dce90a  push r9
000071e7f4dce90c  push r10
000071e7f4dce90e  push r11
000071e7f4dce910  sub rsp, 0xF0
000071e7f4dce917  vmovaps [rsp], xmm0
000071e7f4dce91c  vmovaps [rsp+0x10], xmm1
000071e7f4dce922  vmovaps [rsp+0x20], xmm2
000071e7f4dce928  vmovaps [rsp+0x30], xmm3
000071e7f4dce92e  vmovaps [rsp+0x40], xmm4
000071e7f4dce934  vmovaps [rsp+0x50], xmm5
000071e7f4dce93a  vmovaps [rsp+0x60], xmm6
000071e7f4dce940  vmovaps [rsp+0x70], xmm7
000071e7f4dce946  vmovaps [rsp+0x80], xmm8
000071e7f4dce94f  vmovaps [rsp+0x90], xmm9
000071e7f4dce958  vmovaps [rsp+0xA0], xmm10
000071e7f4dce961  vmovaps [rsp+0xB0], xmm11
000071e7f4dce96a  vmovaps [rsp+0xC0], xmm12
000071e7f4dce973  vmovaps [rsp+0xD0], xmm14
000071e7f4dce97c  vmovaps [rsp+0xE0], xmm15
000071e7f4dce985  sub rsp, 0x30
000071e7f4dce989  movaps [rsp], xmm13
000071e7f4dce98e  movaps [rsp+0x10], xmm12
000071e7f4dce994  movaps [rsp+0x20], xmm1
000071e7f4dce999  lea rdi, [rsp]
000071e7f4dce99d  mov esi, 0x00
000071e7f4dce9a2  mov rax, 0x562A51E82530
000071e7f4dce9ac  call rax
000071e7f4dce9ae  movaps xmm13, [rsp]
000071e7f4dce9b3  add rsp, 0x30
000071e7f4dce9b7  vmovaps xmm0, [rsp]
000071e7f4dce9bc  vmovaps xmm1, [rsp+0x10]
000071e7f4dce9c2  vmovaps xmm2, [rsp+0x20]
000071e7f4dce9c8  vmovaps xmm3, [rsp+0x30]
000071e7f4dce9ce  vmovaps xmm4, [rsp+0x40]
000071e7f4dce9d4  vmovaps xmm5, [rsp+0x50]
000071e7f4dce9da  vmovaps xmm6, [rsp+0x60]
000071e7f4dce9e0  vmovaps xmm7, [rsp+0x70]
000071e7f4dce9e6  vmovaps xmm8, [rsp+0x80]
000071e7f4dce9ef  vmovaps xmm9, [rsp+0x90]
000071e7f4dce9f8  vmovaps xmm10, [rsp+0xA0]
000071e7f4dcea01  vmovaps xmm11, [rsp+0xB0]
000071e7f4dcea0a  vmovaps xmm12, [rsp+0xC0]
000071e7f4dcea13  vmovaps xmm14, [rsp+0xD0]
000071e7f4dcea1c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dcea25  add rsp, 0xF0
000071e7f4dcea2c  pop r11
000071e7f4dcea2e  pop r10
000071e7f4dcea30  pop r9
000071e7f4dcea32  pop r8
000071e7f4dcea34  pop rsi
000071e7f4dcea35  pop rdi
000071e7f4dcea36  pop rdx
000071e7f4dcea37  pop rcx
000071e7f4dcea38  pop rax
000071e7f4dcea39  add rsp, 0x08
000071e7f4dcea3d  jmp 0x000071E7F4DCE81B
000071e7f4dcea42  call 0x000071E7F4C0C380
000071e7f4dcea47  jmp 0x000071E7F4DCE82E
000071e7f4dcea4c  sub rsp, 0x08
000071e7f4dcea50  push rax
000071e7f4dcea51  push rcx
000071e7f4dcea52  push rdx
000071e7f4dcea53  push rdi
000071e7f4dcea54  push rsi
000071e7f4dcea55  push r8
000071e7f4dcea57  push r9
000071e7f4dcea59  push r10
000071e7f4dcea5b  push r11
000071e7f4dcea5d  sub rsp, 0xF0
000071e7f4dcea64  vmovaps [rsp], xmm0
000071e7f4dcea69  vmovaps [rsp+0x10], xmm2
000071e7f4dcea6f  vmovaps [rsp+0x20], xmm3
000071e7f4dcea75  vmovaps [rsp+0x30], xmm4
000071e7f4dcea7b  vmovaps [rsp+0x40], xmm5
000071e7f4dcea81  vmovaps [rsp+0x50], xmm6
000071e7f4dcea87  vmovaps [rsp+0x60], xmm7
000071e7f4dcea8d  vmovaps [rsp+0x70], xmm8
000071e7f4dcea93  vmovaps [rsp+0x80], xmm9
000071e7f4dcea9c  vmovaps [rsp+0x90], xmm10
000071e7f4dceaa5  vmovaps [rsp+0xA0], xmm11
000071e7f4dceaae  vmovaps [rsp+0xB0], xmm12
000071e7f4dceab7  vmovaps [rsp+0xC0], xmm13
000071e7f4dceac0  vmovaps [rsp+0xD0], xmm14
000071e7f4dceac9  vmovaps [rsp+0xE0], xmm15
000071e7f4dcead2  sub rsp, 0x30
000071e7f4dcead6  movaps [rsp], xmm1
000071e7f4dceada  movaps [rsp+0x10], xmm14
000071e7f4dceae0  movaps [rsp+0x20], xmm15
000071e7f4dceae6  lea rdi, [rsp]
000071e7f4dceaea  mov esi, 0x00
000071e7f4dceaef  mov rax, 0x562A51E82530
000071e7f4dceaf9  call rax
000071e7f4dceafb  movaps xmm1, [rsp]
000071e7f4dceaff  add rsp, 0x30
000071e7f4dceb03  vmovaps xmm0, [rsp]
000071e7f4dceb08  vmovaps xmm2, [rsp+0x10]
000071e7f4dceb0e  vmovaps xmm3, [rsp+0x20]
000071e7f4dceb14  vmovaps xmm4, [rsp+0x30]
000071e7f4dceb1a  vmovaps xmm5, [rsp+0x40]
000071e7f4dceb20  vmovaps xmm6, [rsp+0x50]
000071e7f4dceb26  vmovaps xmm7, [rsp+0x60]
000071e7f4dceb2c  vmovaps xmm8, [rsp+0x70]
000071e7f4dceb32  vmovaps xmm9, [rsp+0x80]
000071e7f4dceb3b  vmovaps xmm10, [rsp+0x90]
000071e7f4dceb44  vmovaps xmm11, [rsp+0xA0]
000071e7f4dceb4d  vmovaps xmm12, [rsp+0xB0]
000071e7f4dceb56  vmovaps xmm13, [rsp+0xC0]
000071e7f4dceb5f  vmovaps xmm14, [rsp+0xD0]
000071e7f4dceb68  vmovaps xmm15, [rsp+0xE0]
000071e7f4dceb71  add rsp, 0xF0
000071e7f4dceb78  pop r11
000071e7f4dceb7a  pop r10
000071e7f4dceb7c  pop r9
000071e7f4dceb7e  pop r8
000071e7f4dceb80  pop rsi
000071e7f4dceb81  pop rdi
000071e7f4dceb82  pop rdx
000071e7f4dceb83  pop rcx
000071e7f4dceb84  pop rax
000071e7f4dceb85  add rsp, 0x08
000071e7f4dceb89  jmp 0x000071E7F4DCE848
000071e7f4dceb8e  call 0x000071E7F4BFF540
000071e7f4dceb93  jmp 0x000071E7F4DCE85B
000071e7f4dceb98  int3
000071e7f4dceb99  nop [rax], eax
000071e7f4dceba0  movaps xmm1, [r15+0x180]
000071e7f4dceba8  vpmovqd xmm15, xmm1
000071e7f4dcebae  pxor xmm14, xmm14
000071e7f4dcebb3  punpcklqdq xmm15, xmm14
000071e7f4dcebb8  movaps [r15+0x210], xmm15
000071e7f4dcebc0  movq xmm15, qword ptr [r15+0x120]
000071e7f4dcebc9  movq xmm14, qword ptr [r15+0x130]
000071e7f4dcebd2  psubd xmm15, xmm14
000071e7f4dcebd7  movq xmm15, xmm15
000071e7f4dcebdc  movaps xmm13, [r15+0x170]
000071e7f4dcebe4  paddq xmm1, xmm13
000071e7f4dcebe9  movaps [r15+0x180], xmm1
000071e7f4dcebf1  movq xmm1, qword ptr [r15+0x150]
000071e7f4dcebfa  paddd xmm14, xmm1
000071e7f4dcebff  movq xmm14, xmm14
000071e7f4dcec04  movq xmm14, xmm14
000071e7f4dcec09  movaps [r15+0x130], xmm14
000071e7f4dcec11  pmovzxdq xmm15, xmm15
000071e7f4dcec17  psllq xmm15, 0x00
000071e7f4dcec1d  movq xmm1, qword ptr [r15+0x210]
000071e7f4dcec26  movq xmm14, qword ptr [r15+0x110]
000071e7f4dcec2f  paddd xmm1, xmm14
000071e7f4dcec34  movq xmm1, xmm1
000071e7f4dcec38  vcvtuqq2pd xmm15, xmm15
000071e7f4dcec3e  pmovzxdq xmm1, xmm1
000071e7f4dcec43  psllq xmm1, 0x00
000071e7f4dcec48  vcvtuqq2pd xmm1, xmm1
000071e7f4dcec4e  movaps xmm14, [r15+0x140]
000071e7f4dcec56  movaps xmm13, xmm15
000071e7f4dcec5a  mulpd xmm13, xmm14
000071e7f4dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000071e7f4dcec65  ptest xmm12, xmm12
000071e7f4dcec6b  jnz 0x000071E7F4DCED4E
000071e7f4dcec71  movaps [r15+0x220], xmm13
000071e7f4dcec79  mov rax, [r15+0x48]
000071e7f4dcec7d  mov r14, [r15+0x50]
000071e7f4dcec81  lea r12, [r14+rax*1]
000071e7f4dcec85  movups [r13+r12*1], xmm13
000071e7f4dcec8b  movaps xmm15, [r15+0x160]
000071e7f4dcec93  movaps xmm14, xmm1
000071e7f4dcec97  mulpd xmm14, xmm15
000071e7f4dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000071e7f4dceca2  ptest xmm13, xmm13
000071e7f4dceca8  jnz 0x000071E7F4DCEE9C
000071e7f4dcecae  movaps [r15+0x210], xmm14
000071e7f4dcecb6  mov r14, [r15+0x40]
000071e7f4dcecba  lea r12, [r14+rax*1]
000071e7f4dcecbe  movups [r13+r12*1], xmm14
000071e7f4dcecc4  lea r14, [rax+0x10]
000071e7f4dcecc8  mov [r15+0x48], r14
000071e7f4dceccc  xor eax, eax
000071e7f4dcecce  mov r12d, 0x200
000071e7f4dcecd4  cmp r14, r12
000071e7f4dcecd7  cmc
000071e7f4dcecd8  lahf
000071e7f4dcecd9  seto al
000071e7f4dcecdc  mov [r15+0x108], eax
000071e7f4dcece3  mov eax, [r15+0x108]
000071e7f4dcecea  sahf
000071e7f4dceceb  jnz 0x000071E7F4DCED1D
000071e7f4dceced  cmp dword ptr [r15+0x318], 0x00
000071e7f4dcecf5  jz 0x000071E7F4DCEFF0
000071e7f4dcecfb  nop [rax+rax*1], ax
000071e7f4dced04  nop [rax+rax*1], eax
000071e7f4dced0c  mov eax, 0x4101EC
000071e7f4dced11  mov [r15+0x100], rax
000071e7f4dced18  jmp 0x000071E7F4BFE110
000071e7f4dced1d  cmp dword ptr [r15+0x318], 0x00
000071e7f4dced25  jz 0x000071E7F4DCEBA0
000071e7f4dced2b  nop [rax+rax*1], ax
000071e7f4dced34  nop [rax+rax*1], eax
000071e7f4dced3c  mov eax, 0x4101AC
000071e7f4dced41  mov [r15+0x100], rax
000071e7f4dced48  jmp 0x000071E7F4BFE110
000071e7f4dced4d  int3
000071e7f4dced4e  sub rsp, 0x08
000071e7f4dced52  push rax
000071e7f4dced53  push rcx
000071e7f4dced54  push rdx
000071e7f4dced55  push rdi
000071e7f4dced56  push rsi
000071e7f4dced57  push r8
000071e7f4dced59  push r9
000071e7f4dced5b  push r10
000071e7f4dced5d  push r11
000071e7f4dced5f  sub rsp, 0xF0
000071e7f4dced66  vmovaps [rsp], xmm0
000071e7f4dced6b  vmovaps [rsp+0x10], xmm1
000071e7f4dced71  vmovaps [rsp+0x20], xmm2
000071e7f4dced77  vmovaps [rsp+0x30], xmm3
000071e7f4dced7d  vmovaps [rsp+0x40], xmm4
000071e7f4dced83  vmovaps [rsp+0x50], xmm5
000071e7f4dced89  vmovaps [rsp+0x60], xmm6
000071e7f4dced8f  vmovaps [rsp+0x70], xmm7
000071e7f4dced95  vmovaps [rsp+0x80], xmm8
000071e7f4dced9e  vmovaps [rsp+0x90], xmm9
000071e7f4dceda7  vmovaps [rsp+0xA0], xmm10
000071e7f4dcedb0  vmovaps [rsp+0xB0], xmm11
000071e7f4dcedb9  vmovaps [rsp+0xC0], xmm12
000071e7f4dcedc2  vmovaps [rsp+0xD0], xmm14
000071e7f4dcedcb  vmovaps [rsp+0xE0], xmm15
000071e7f4dcedd4  sub rsp, 0x30
000071e7f4dcedd8  movaps [rsp], xmm13
000071e7f4dceddd  movaps [rsp+0x10], xmm15
000071e7f4dcede3  movaps [rsp+0x20], xmm14
000071e7f4dcede9  lea rdi, [rsp]
000071e7f4dceded  mov esi, 0x00
000071e7f4dcedf2  mov rax, 0x562A51E82530
000071e7f4dcedfc  call rax
000071e7f4dcedfe  movaps xmm13, [rsp]
000071e7f4dcee03  add rsp, 0x30
000071e7f4dcee07  vmovaps xmm0, [rsp]
000071e7f4dcee0c  vmovaps xmm1, [rsp+0x10]
000071e7f4dcee12  vmovaps xmm2, [rsp+0x20]
000071e7f4dcee18  vmovaps xmm3, [rsp+0x30]
000071e7f4dcee1e  vmovaps xmm4, [rsp+0x40]
000071e7f4dcee24  vmovaps xmm5, [rsp+0x50]
000071e7f4dcee2a  vmovaps xmm6, [rsp+0x60]
000071e7f4dcee30  vmovaps xmm7, [rsp+0x70]
000071e7f4dcee36  vmovaps xmm8, [rsp+0x80]
000071e7f4dcee3f  vmovaps xmm9, [rsp+0x90]
000071e7f4dcee48  vmovaps xmm10, [rsp+0xA0]
000071e7f4dcee51  vmovaps xmm11, [rsp+0xB0]
000071e7f4dcee5a  vmovaps xmm12, [rsp+0xC0]
000071e7f4dcee63  vmovaps xmm14, [rsp+0xD0]
000071e7f4dcee6c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dcee75  add rsp, 0xF0
000071e7f4dcee7c  pop r11
000071e7f4dcee7e  pop r10
000071e7f4dcee80  pop r9
000071e7f4dcee82  pop r8
000071e7f4dcee84  pop rsi
000071e7f4dcee85  pop rdi
000071e7f4dcee86  pop rdx
000071e7f4dcee87  pop rcx
000071e7f4dcee88  pop rax
000071e7f4dcee89  add rsp, 0x08
000071e7f4dcee8d  jmp 0x000071E7F4DCEC71
000071e7f4dcee92  call 0x000071E7F4CC2240
000071e7f4dcee97  jmp 0x000071E7F4DCEC8B
000071e7f4dcee9c  sub rsp, 0x08
000071e7f4dceea0  push rax
000071e7f4dceea1  push rcx
000071e7f4dceea2  push rdx
000071e7f4dceea3  push rdi
000071e7f4dceea4  push rsi
000071e7f4dceea5  push r8
000071e7f4dceea7  push r9
000071e7f4dceea9  push r10
000071e7f4dceeab  push r11
000071e7f4dceead  sub rsp, 0xF0
000071e7f4dceeb4  vmovaps [rsp], xmm0
000071e7f4dceeb9  vmovaps [rsp+0x10], xmm1
000071e7f4dceebf  vmovaps [rsp+0x20], xmm2
000071e7f4dceec5  vmovaps [rsp+0x30], xmm3
000071e7f4dceecb  vmovaps [rsp+0x40], xmm4
000071e7f4dceed1  vmovaps [rsp+0x50], xmm5
000071e7f4dceed7  vmovaps [rsp+0x60], xmm6
000071e7f4dceedd  vmovaps [rsp+0x70], xmm7
000071e7f4dceee3  vmovaps [rsp+0x80], xmm8
000071e7f4dceeec  vmovaps [rsp+0x90], xmm9
000071e7f4dceef5  vmovaps [rsp+0xA0], xmm10
000071e7f4dceefe  vmovaps [rsp+0xB0], xmm11
000071e7f4dcef07  vmovaps [rsp+0xC0], xmm12
000071e7f4dcef10  vmovaps [rsp+0xD0], xmm13
000071e7f4dcef19  vmovaps [rsp+0xE0], xmm15
000071e7f4dcef22  sub rsp, 0x30
000071e7f4dcef26  movaps [rsp], xmm14
000071e7f4dcef2b  movaps [rsp+0x10], xmm1
000071e7f4dcef30  movaps [rsp+0x20], xmm15
000071e7f4dcef36  lea rdi, [rsp]
000071e7f4dcef3a  mov esi, 0x00
000071e7f4dcef3f  mov rax, 0x562A51E82530
000071e7f4dcef49  call rax
000071e7f4dcef4b  movaps xmm14, [rsp]
000071e7f4dcef50  add rsp, 0x30
000071e7f4dcef54  vmovaps xmm0, [rsp]
000071e7f4dcef59  vmovaps xmm1, [rsp+0x10]
000071e7f4dcef5f  vmovaps xmm2, [rsp+0x20]
000071e7f4dcef65  vmovaps xmm3, [rsp+0x30]
000071e7f4dcef6b  vmovaps xmm4, [rsp+0x40]
000071e7f4dcef71  vmovaps xmm5, [rsp+0x50]
000071e7f4dcef77  vmovaps xmm6, [rsp+0x60]
000071e7f4dcef7d  vmovaps xmm7, [rsp+0x70]
000071e7f4dcef83  vmovaps xmm8, [rsp+0x80]
000071e7f4dcef8c  vmovaps xmm9, [rsp+0x90]
000071e7f4dcef95  vmovaps xmm10, [rsp+0xA0]
000071e7f4dcef9e  vmovaps xmm11, [rsp+0xB0]
000071e7f4dcefa7  vmovaps xmm12, [rsp+0xC0]
000071e7f4dcefb0  vmovaps xmm13, [rsp+0xD0]
000071e7f4dcefb9  vmovaps xmm15, [rsp+0xE0]
000071e7f4dcefc2  add rsp, 0xF0
000071e7f4dcefc9  pop r11
000071e7f4dcefcb  pop r10
000071e7f4dcefcd  pop r9
000071e7f4dcefcf  pop r8
000071e7f4dcefd1  pop rsi
000071e7f4dcefd2  pop rdi
000071e7f4dcefd3  pop rdx
000071e7f4dcefd4  pop rcx
000071e7f4dcefd5  pop rax
000071e7f4dcefd6  add rsp, 0x08
000071e7f4dcefda  jmp 0x000071E7F4DCECAE
000071e7f4dcefdf  call 0x000071E7F4CC34C0
000071e7f4dcefe4  jmp 0x000071E7F4DCECC4
000071e7f4dcefe9  int3
000071e7f4dcefea  nop [rax+rax*1], ax
000071e7f4dceff0  mov rax, [r15+0xF8]
000071e7f4dceff7  lea r14, [rax-0x150]
000071e7f4dceffe  mov [r15+0xF8], r14
000071e7f4dcf005  mov rax, [r15+0x50]
000071e7f4dcf009  lea r12, [rax+0x80]
000071e7f4dcf010  movups xmm1, [r13+r12*1]
000071e7f4dcf016  lea r12, [rax+0x90]
000071e7f4dcf01d  movups xmm15, [r13+r12*1]
000071e7f4dcf023  mov qword ptr [r15+0x48], 0x00
000071e7f4dcf02b  lea r12, [rax+0x40]
000071e7f4dcf02f  movups xmm14, [r13+r12*1]
000071e7f4dcf035  lea r12, [rax+0x50]
000071e7f4dcf039  movups xmm13, [r13+r12*1]
000071e7f4dcf03f  lea r12, [r14+0x120]
000071e7f4dcf046  movq xmm12, qword ptr [r15+0x1C0]
000071e7f4dcf04f  movq xmm11, qword ptr [r15+0x1B0]
000071e7f4dcf058  movq r11, xmm12
000071e7f4dcf05d  movq r10, xmm11
000071e7f4dcf062  mov [r13+r12*1], r11
000071e7f4dcf067  lea r12, [r14+0x128]
000071e7f4dcf06e  mov [r13+r12*1], r10
000071e7f4dcf073  vxorps xmm12, xmm12, xmm12
000071e7f4dcf078  vpbroadcastq xmm12, xmm12
000071e7f4dcf07d  lea r12, [r14+0x100]
000071e7f4dcf084  movq xmm11, qword ptr [r15+0x200]
000071e7f4dcf08d  movq xmm10, qword ptr [r15+0x1F0]
000071e7f4dcf096  movq r11, xmm11
000071e7f4dcf09b  movq r10, xmm10
000071e7f4dcf0a0  mov [r13+r12*1], r11
000071e7f4dcf0a5  lea r12, [r14+0x108]
000071e7f4dcf0ac  mov [r13+r12*1], r10
000071e7f4dcf0b1  lea r12, [r14+0xE0]
000071e7f4dcf0b8  movups [r13+r12*1], xmm15
000071e7f4dcf0be  lea r12, [r14+0xF0]
000071e7f4dcf0c5  movups [r13+r12*1], xmm1
000071e7f4dcf0cb  lea r12, [rax+0xC0]
000071e7f4dcf0d2  movups xmm1, [r13+r12*1]
000071e7f4dcf0d8  lea r12, [rax+0xD0]
000071e7f4dcf0df  movups xmm15, [r13+r12*1]
000071e7f4dcf0e5  lea r12, [r14+0x110]
000071e7f4dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000071e7f4dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000071e7f4dcf0fe  movq r11, xmm11
000071e7f4dcf103  movq r10, xmm10
000071e7f4dcf108  mov [r13+r12*1], r11
000071e7f4dcf10d  lea r12, [r14+0x118]
000071e7f4dcf114  mov [r13+r12*1], r10
000071e7f4dcf119  movups xmm11, [r13+rax*1]
000071e7f4dcf11f  lea r12, [rax+0x10]
000071e7f4dcf123  movups xmm10, [r13+r12*1]
000071e7f4dcf129  lea r12, [r14+0x130]
000071e7f4dcf130  movq xmm9, qword ptr [r15+0x1A0]
000071e7f4dcf139  movq xmm8, qword ptr [r15+0x190]
000071e7f4dcf142  movq r11, xmm9
000071e7f4dcf147  movq r10, xmm8
000071e7f4dcf14c  mov [r13+r12*1], r11
000071e7f4dcf151  lea r12, [r14+0x138]
000071e7f4dcf158  mov [r13+r12*1], r10
000071e7f4dcf15d  lea r12, [rax+0x140]
000071e7f4dcf164  movups xmm9, [r13+r12*1]
000071e7f4dcf16a  lea r12, [rax+0x150]
000071e7f4dcf171  movups xmm8, [r13+r12*1]
000071e7f4dcf177  lea r12, [r14+0xC0]
000071e7f4dcf17e  movups [r13+r12*1], xmm15
000071e7f4dcf184  lea r12, [r14+0xD0]
000071e7f4dcf18b  movups [r13+r12*1], xmm1
000071e7f4dcf191  lea r12, [rax+0x100]
000071e7f4dcf198  movups xmm1, [r13+r12*1]
000071e7f4dcf19e  lea r12, [rax+0x110]
000071e7f4dcf1a5  movups xmm15, [r13+r12*1]
000071e7f4dcf1ab  lea r12, [r14+0x140]
000071e7f4dcf1b2  mov r11, [r15+0xE8]
000071e7f4dcf1b9  mov [r13+r12*1], r11
000071e7f4dcf1be  lea r12, [rax+0x180]
000071e7f4dcf1c5  movups xmm7, [r13+r12*1]
000071e7f4dcf1cb  lea r12, [rax+0x190]
000071e7f4dcf1d2  movups xmm6, [r13+r12*1]
000071e7f4dcf1d8  lea r12, [rax+0x1C0]
000071e7f4dcf1df  movups xmm5, [r13+r12*1]
000071e7f4dcf1e5  lea r12, [rax+0x1D0]
000071e7f4dcf1ec  movups xmm4, [r13+r12*1]
000071e7f4dcf1f2  lea r12, [r14+0x20]
000071e7f4dcf1f6  movups [r13+r12*1], xmm1
000071e7f4dcf1fc  lea r12, [r14+0x30]
000071e7f4dcf200  movups [r13+r12*1], xmm13
000071e7f4dcf206  lea r12, [rax+0x60]
000071e7f4dcf20a  movups xmm1, [r13+r12*1]
000071e7f4dcf210  lea r12, [rax+0x70]
000071e7f4dcf214  movups xmm13, [r13+r12*1]
000071e7f4dcf21a  lea r12, [rax+0x20]
000071e7f4dcf21e  movups xmm3, [r13+r12*1]
000071e7f4dcf224  lea r12, [rax+0x30]
000071e7f4dcf228  movups xmm2, [r13+r12*1]
000071e7f4dcf22e  movaps [r15+0x1F0], xmm2
000071e7f4dcf236  lea r12, [r14+0x60]
000071e7f4dcf23a  movups [r13+r12*1], xmm11
000071e7f4dcf240  lea r12, [r14+0x70]
000071e7f4dcf244  movups [r13+r12*1], xmm5
000071e7f4dcf24a  lea r12, [rax+0xE0]
000071e7f4dcf251  movups xmm11, [r13+r12*1]
000071e7f4dcf257  lea r12, [rax+0xF0]
000071e7f4dcf25e  movups xmm5, [r13+r12*1]
000071e7f4dcf264  lea r12, [r14+0xA0]
000071e7f4dcf26b  movups [r13+r12*1], xmm13
000071e7f4dcf271  lea r12, [r14+0xB0]
000071e7f4dcf278  movups [r13+r12*1], xmm1
000071e7f4dcf27e  lea r12, [rax+0xA0]
000071e7f4dcf285  movups xmm1, [r13+r12*1]
000071e7f4dcf28b  lea r12, [rax+0xB0]
000071e7f4dcf292  movups xmm13, [r13+r12*1]
000071e7f4dcf298  lea r12, [rax+0x120]
000071e7f4dcf29f  vmovaps [rsp+0x10], xmm1
000071e7f4dcf2a5  movups xmm1, [r13+r12*1]
000071e7f4dcf2ab  lea r12, [rax+0x130]
000071e7f4dcf2b2  vmovaps [rsp+0x20], xmm1
000071e7f4dcf2b8  movups xmm1, [r13+r12*1]
000071e7f4dcf2be  lea r12, [rax+0x160]
000071e7f4dcf2c5  vmovaps [rsp+0x30], xmm1
000071e7f4dcf2cb  movups xmm1, [r13+r12*1]
000071e7f4dcf2d1  lea r12, [rax+0x170]
000071e7f4dcf2d8  vmovaps [rsp+0x40], xmm1
000071e7f4dcf2de  movups xmm1, [r13+r12*1]
000071e7f4dcf2e4  movaps [r15+0x2B0], xmm1
000071e7f4dcf2ec  lea r12, [r14+0x80]
000071e7f4dcf2f3  movups [r13+r12*1], xmm13
000071e7f4dcf2f9  lea r12, [r14+0x90]
000071e7f4dcf300  vmovaps xmm13, [rsp+0x10]
000071e7f4dcf306  movups [r13+r12*1], xmm13
000071e7f4dcf30c  lea r12, [rax+0x1A0]
000071e7f4dcf313  movups xmm13, [r13+r12*1]
000071e7f4dcf319  lea r12, [rax+0x1B0]
000071e7f4dcf320  vmovaps [rsp+0x10], xmm1
000071e7f4dcf326  movups xmm1, [r13+r12*1]
000071e7f4dcf32c  movaps [r15+0x290], xmm13
000071e7f4dcf334  movaps [r15+0x1E0], xmm1
000071e7f4dcf33c  lea r12, [rax+0x1E0]
000071e7f4dcf343  vmovaps [rsp+0x50], xmm1
000071e7f4dcf349  movups xmm1, [r13+r12*1]
000071e7f4dcf34f  lea r12, [rax+0x1F0]
000071e7f4dcf356  vmovaps [rsp+0x60], xmm1
000071e7f4dcf35c  movups xmm1, [r13+r12*1]
000071e7f4dcf362  mov qword ptr [r15+0x50], 0x430920
000071e7f4dcf36a  lea rax, [r14+0x40]
000071e7f4dcf36e  vmovaps [rsp+0x70], xmm1
000071e7f4dcf374  vmovaps xmm1, [rsp+0x40]
000071e7f4dcf37a  movups [r13+rax*1], xmm1
000071e7f4dcf380  lea rax, [r14+0x50]
000071e7f4dcf384  movups [r13+rax*1], xmm10
000071e7f4dcf38a  vmovaps xmm1, [rsp+0x70]
000071e7f4dcf390  movups [r13+r14*1], xmm1
000071e7f4dcf396  lea rax, [r14+0x10]
000071e7f4dcf39a  vmovaps xmm1, [rsp+0x60]
000071e7f4dcf3a0  movups [r13+rax*1], xmm1
000071e7f4dcf3a6  mov rax, [r15+0x40]
000071e7f4dcf3aa  vmovaps [rsp+0x40], xmm3
000071e7f4dcf3b0  vmovaps xmm1, [rsp+0x40]
000071e7f4dcf3b6  por xmm3, xmm1
000071e7f4dcf3ba  vmovaps [rsp+0x40], xmm6
000071e7f4dcf3c0  vmovaps xmm10, [rsp+0x40]
000071e7f4dcf3c6  por xmm6, xmm10
000071e7f4dcf3cb  lea r12, [rax+0x30]
000071e7f4dcf3cf  mov r11, [r13+r12*1]
000071e7f4dcf3d4  lea r12, [rax+0x38]
000071e7f4dcf3d8  mov r10, [r13+r12*1]
000071e7f4dcf3dd  movq xmm10, r11
000071e7f4dcf3e2  vmovaps [rsp+0x40], xmm1
000071e7f4dcf3e8  movq xmm1, r10
000071e7f4dcf3ed  movq xmm10, xmm10
000071e7f4dcf3f2  vmovaps [rsp+0x60], xmm10
000071e7f4dcf3f8  movq xmm10, xmm10
000071e7f4dcf3fd  movaps [r15+0x130], xmm10
000071e7f4dcf405  movq xmm1, xmm1
000071e7f4dcf409  vmovaps [rsp+0x70], xmm1
000071e7f4dcf40f  movq xmm1, xmm1
000071e7f4dcf413  movaps [r15+0x280], xmm1
000071e7f4dcf41b  vmovaps [rsp+0x80], xmm9
000071e7f4dcf424  vmovaps xmm1, [rsp+0x80]
000071e7f4dcf42d  por xmm9, xmm1
000071e7f4dcf432  lea r12, [rax+0x20]
000071e7f4dcf436  mov r11, [r13+r12*1]
000071e7f4dcf43b  lea r12, [rax+0x28]
000071e7f4dcf43f  mov r10, [r13+r12*1]
000071e7f4dcf444  movq xmm1, r11
000071e7f4dcf449  movq xmm10, r10
000071e7f4dcf44e  movq xmm1, xmm1
000071e7f4dcf452  vmovaps [rsp+0x80], xmm1
000071e7f4dcf45b  movq xmm1, xmm1
000071e7f4dcf45f  movaps [r15+0x150], xmm1
000071e7f4dcf467  movq xmm10, xmm10
000071e7f4dcf46c  vmovaps [rsp+0x90], xmm10
000071e7f4dcf475  movq xmm10, xmm10
000071e7f4dcf47a  movaps [r15+0x140], xmm10
000071e7f4dcf482  lea r12, [rax+0x10]
000071e7f4dcf486  mov r11, [r13+r12*1]
000071e7f4dcf48b  lea r12, [rax+0x18]
000071e7f4dcf48f  mov r10, [r13+r12*1]
000071e7f4dcf494  movq xmm1, r11
000071e7f4dcf499  movq xmm10, r10
000071e7f4dcf49e  movq xmm1, xmm1
000071e7f4dcf4a2  vmovaps [rsp+0xA0], xmm1
000071e7f4dcf4ab  movq xmm1, xmm1
000071e7f4dcf4af  movaps [r15+0x170], xmm1
000071e7f4dcf4b7  movq xmm10, xmm10
000071e7f4dcf4bc  vmovaps [rsp+0xB0], xmm10
000071e7f4dcf4c5  movq xmm10, xmm10
000071e7f4dcf4ca  movaps [r15+0x160], xmm10
000071e7f4dcf4d2  mov r12, [r13+rax*1]
000071e7f4dcf4d7  vmovq xmm1, r12
000071e7f4dcf4dc  vpbroadcastq xmm1, xmm1
000071e7f4dcf4e1  lea r12, [rax+0x08]
000071e7f4dcf4e5  mov rax, [r13+r12*1]
000071e7f4dcf4ea  movq xmm10, rax
000071e7f4dcf4ef  movaps [r15+0x230], xmm10
000071e7f4dcf4f7  lea rax, [r14+0x50]
000071e7f4dcf4fb  movups xmm10, [r13+rax*1]
000071e7f4dcf501  lea rax, [r14+0x60]
000071e7f4dcf505  vmovaps [rsp+0xC0], xmm1
000071e7f4dcf50e  movups xmm1, [r13+rax*1]
000071e7f4dcf514  lea rax, [r14+0x30]
000071e7f4dcf518  vmovaps [rsp+0xD0], xmm1
000071e7f4dcf521  movups xmm1, [r13+rax*1]
000071e7f4dcf527  mov qword ptr [r15+0x60], 0x430920
000071e7f4dcf52f  mov qword ptr [r15+0x58], 0x40
000071e7f4dcf537  vmovaps [rsp+0xE0], xmm1
000071e7f4dcf540  vmovaps [rsp+0xF0], xmm15
000071e7f4dcf549  vmovaps xmm15, [rsp+0xC0]
000071e7f4dcf552  vmovaps [rsp+0xC0], xmm14
000071e7f4dcf55b  vmovaps xmm14, [rsp+0x40]
000071e7f4dcf561  vmovaps [rsp+0x40], xmm13
000071e7f4dcf567  movaps xmm1, xmm15
000071e7f4dcf56b  mulpd xmm1, xmm14
000071e7f4dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000071e7f4dcf575  ptest xmm13, xmm13
000071e7f4dcf57b  jnz 0x000071E7F4DD0682
000071e7f4dcf581  movq xmm14, qword ptr [r15+0x230]
000071e7f4dcf58a  vmovaps [rsp+0x100], xmm14
000071e7f4dcf593  vpermilpd xmm14, xmm14, 0x00
000071e7f4dcf599  vmovaps [rsp+0x110], xmm1
000071e7f4dcf5a2  vmovaps xmm1, [rsp+0xE0]
000071e7f4dcf5ab  vmovaps [rsp+0xE0], xmm15
000071e7f4dcf5b4  movaps xmm13, xmm1
000071e7f4dcf5b8  mulpd xmm13, xmm14
000071e7f4dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000071e7f4dcf5c3  ptest xmm15, xmm15
000071e7f4dcf5c9  jnz 0x000071E7F4DD07C4
000071e7f4dcf5cf  vxorps xmm1, xmm1, xmm1
000071e7f4dcf5d3  vpbroadcastq xmm1, xmm1
000071e7f4dcf5d8  vmovaps xmm14, [rsp+0xE0]
000071e7f4dcf5e1  vmovaps [rsp+0xE0], xmm1
000071e7f4dcf5ea  vmovaps xmm1, [rsp+0xD0]
000071e7f4dcf5f3  vmovaps [rsp+0xD0], xmm13
000071e7f4dcf5fc  movaps xmm15, xmm14
000071e7f4dcf600  mulpd xmm15, xmm1
000071e7f4dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000071e7f4dcf60b  ptest xmm13, xmm13
000071e7f4dcf611  jnz 0x000071E7F4DD0907
000071e7f4dcf617  movaps xmm1, xmm14
000071e7f4dcf61b  mulpd xmm1, xmm10
000071e7f4dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000071e7f4dcf625  ptest xmm13, xmm13
000071e7f4dcf62b  jnz 0x000071E7F4DD0A4A
000071e7f4dcf631  movaps xmm13, xmm14
000071e7f4dcf635  mulpd xmm13, xmm2
000071e7f4dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000071e7f4dcf640  ptest xmm10, xmm10
000071e7f4dcf646  jnz 0x000071E7F4DD0B8C
000071e7f4dcf64c  vmovaps [rsp+0x120], xmm7
000071e7f4dcf655  vmovaps xmm14, [rsp+0x120]
000071e7f4dcf65e  por xmm7, xmm14
000071e7f4dcf663  vmovaps xmm14, [rsp+0xC0]
000071e7f4dcf66c  vmovaps xmm10, [rsp+0xC0]
000071e7f4dcf675  por xmm14, xmm10
000071e7f4dcf67a  vmovaps xmm2, [rsp+0x100]
000071e7f4dcf683  vpermilpd xmm2, xmm2, 0x00
000071e7f4dcf689  vmovaps [rsp+0xC0], xmm1
000071e7f4dcf692  vmovaps [rsp+0x120], xmm15
000071e7f4dcf69b  movaps xmm1, xmm10
000071e7f4dcf69f  mulpd xmm1, xmm2
000071e7f4dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000071e7f4dcf6a8  ptest xmm15, xmm15
000071e7f4dcf6ae  jnz 0x000071E7F4DD0CCF
000071e7f4dcf6b4  xor eax, eax
000071e7f4dcf6b6  mov r12d, 0x40
000071e7f4dcf6bc  mov r11d, 0x200
000071e7f4dcf6c2  cmp r12, r11
000071e7f4dcf6c5  cmc
000071e7f4dcf6c6  lahf
000071e7f4dcf6c7  seto al
000071e7f4dcf6ca  mov [r15+0x108], eax
000071e7f4dcf6d1  vmovaps xmm10, [rsp+0x110]
000071e7f4dcf6da  vmovaps xmm2, [rsp+0xE0]
000071e7f4dcf6e3  vmovaps [rsp+0xE0], xmm1
000071e7f4dcf6ec  movaps xmm15, xmm10
000071e7f4dcf6f0  addpd xmm15, xmm2
000071e7f4dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000071e7f4dcf6fb  ptest xmm1, xmm1
000071e7f4dcf700  jnz 0x000071E7F4DD0E10
000071e7f4dcf706  vmovaps xmm10, [rsp+0x120]
000071e7f4dcf70f  vmovaps [rsp+0x110], xmm15
000071e7f4dcf718  movaps xmm1, xmm10
000071e7f4dcf71c  addpd xmm1, xmm12
000071e7f4dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000071e7f4dcf726  ptest xmm15, xmm15
000071e7f4dcf72c  jnz 0x000071E7F4DD0F53
000071e7f4dcf732  vmovaps xmm10, [rsp+0xC0]
000071e7f4dcf73b  vmovaps [rsp+0xC0], xmm1
000071e7f4dcf744  movaps xmm15, xmm10
000071e7f4dcf748  addpd xmm15, xmm12
000071e7f4dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000071e7f4dcf753  ptest xmm1, xmm1
000071e7f4dcf758  jnz 0x000071E7F4DD1095
000071e7f4dcf75e  vmovaps xmm1, [rsp+0x30]
000071e7f4dcf764  vmovaps xmm12, [rsp+0x30]
000071e7f4dcf76a  por xmm1, xmm12
000071e7f4dcf76f  vmovaps xmm12, [rsp+0x20]
000071e7f4dcf775  vmovaps xmm10, [rsp+0x20]
000071e7f4dcf77b  por xmm12, xmm10
000071e7f4dcf780  vmovaps [rsp+0x20], xmm5
000071e7f4dcf786  vmovaps xmm10, [rsp+0x20]
000071e7f4dcf78c  por xmm5, xmm10
000071e7f4dcf791  vmovaps [rsp+0x20], xmm11
000071e7f4dcf797  vmovaps xmm10, [rsp+0x20]
000071e7f4dcf79d  por xmm11, xmm10
000071e7f4dcf7a2  vmovaps [rsp+0x20], xmm4
000071e7f4dcf7a8  vmovaps xmm10, [rsp+0x20]
000071e7f4dcf7ae  por xmm4, xmm10
000071e7f4dcf7b3  vmovaps [rsp+0x20], xmm8
000071e7f4dcf7b9  vmovaps xmm10, [rsp+0x20]
000071e7f4dcf7bf  por xmm8, xmm10
000071e7f4dcf7c4  vmovaps xmm10, [rsp+0xF0]
000071e7f4dcf7cd  vmovaps [rsp+0x20], xmm1
000071e7f4dcf7d3  vmovaps xmm1, [rsp+0xF0]
000071e7f4dcf7dc  por xmm10, xmm1
000071e7f4dcf7e1  lea rax, [r14+0xA0]
000071e7f4dcf7e8  movups xmm1, [r13+rax*1]
000071e7f4dcf7ee  lea rax, [r14+0xB0]
000071e7f4dcf7f5  vmovaps [rsp+0x30], xmm1
000071e7f4dcf7fb  movups xmm1, [r13+rax*1]
000071e7f4dcf801  vmovaps [rsp+0xF0], xmm1
000071e7f4dcf80a  vmovaps [rsp+0x120], xmm15
000071e7f4dcf813  movaps xmm1, xmm13
000071e7f4dcf817  addpd xmm1, xmm2
000071e7f4dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000071e7f4dcf820  ptest xmm15, xmm15
000071e7f4dcf826  jnz 0x000071E7F4DD11ED
000071e7f4dcf82c  lea rax, [r14+0xF0]
000071e7f4dcf833  movups xmm15, [r13+rax*1]
000071e7f4dcf839  vmovaps xmm2, [rsp+0xC0]
000071e7f4dcf842  vmovaps [rsp+0xC0], xmm1
000071e7f4dcf84b  vmovaps xmm1, [rsp+0xE0]
000071e7f4dcf854  vmovaps [rsp+0xE0], xmm15
000071e7f4dcf85d  movaps xmm13, xmm2
000071e7f4dcf861  addpd xmm13, xmm1
000071e7f4dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000071e7f4dcf86c  ptest xmm15, xmm15
000071e7f4dcf872  jnz 0x000071E7F4DD1338
000071e7f4dcf878  vmovaps xmm15, [rsp+0x120]
000071e7f4dcf881  vmovaps xmm2, [rsp+0xD0]
000071e7f4dcf88a  vmovaps [rsp+0xD0], xmm14
000071e7f4dcf893  movaps xmm1, xmm15
000071e7f4dcf897  addpd xmm1, xmm2
000071e7f4dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000071e7f4dcf8a0  ptest xmm14, xmm14
000071e7f4dcf8a6  jnz 0x000071E7F4DD147A
000071e7f4dcf8ac  vmovaps xmm15, [rsp+0x100]
000071e7f4dcf8b5  vpermilpd xmm15, xmm15, 0x00
000071e7f4dcf8bb  vmovaps xmm2, [rsp+0xF0]
000071e7f4dcf8c4  vmovaps [rsp+0xF0], xmm1
000071e7f4dcf8cd  movaps xmm14, xmm2
000071e7f4dcf8d1  mulpd xmm14, xmm15
000071e7f4dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000071e7f4dcf8dc  ptest xmm1, xmm1
000071e7f4dcf8e1  jnz 0x000071E7F4DD15BB
000071e7f4dcf8e7  vmovaps xmm1, [rsp+0xA0]
000071e7f4dcf8f0  vpermilpd xmm1, xmm1, 0x00
000071e7f4dcf8f6  vmovaps xmm2, [rsp+0xE0]
000071e7f4dcf8ff  vmovaps [rsp+0xE0], xmm14
000071e7f4dcf908  movaps xmm15, xmm2
000071e7f4dcf90c  mulpd xmm15, xmm1
000071e7f4dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000071e7f4dcf917  ptest xmm14, xmm14
000071e7f4dcf91d  jnz 0x000071E7F4DD16FE
000071e7f4dcf923  lea rax, [r14+0xE0]
000071e7f4dcf92a  movups xmm1, [r13+rax*1]
000071e7f4dcf930  vmovaps xmm14, [rsp+0x100]
000071e7f4dcf939  vpermilpd xmm14, xmm14, 0x00
000071e7f4dcf93f  vmovaps [rsp+0x100], xmm1
000071e7f4dcf948  vmovaps xmm1, [rsp+0x30]
000071e7f4dcf94e  vmovaps [rsp+0x30], xmm15
000071e7f4dcf954  movaps xmm2, xmm1
000071e7f4dcf957  mulpd xmm2, xmm14
000071e7f4dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000071e7f4dcf961  ptest xmm15, xmm15
000071e7f4dcf967  jnz 0x000071E7F4DD184A
000071e7f4dcf96d  vmovaps [rsp+0x120], xmm10
000071e7f4dcf976  vmovaps xmm1, [rsp+0x120]
000071e7f4dcf97f  por xmm10, xmm1
000071e7f4dcf984  movaps [r15+0x300], xmm10
000071e7f4dcf98c  vmovaps [rsp+0x120], xmm8
000071e7f4dcf995  vmovaps xmm1, [rsp+0x120]
000071e7f4dcf99e  por xmm8, xmm1
000071e7f4dcf9a3  movaps [r15+0x190], xmm8
000071e7f4dcf9ab  vmovaps xmm1, [rsp+0xA0]
000071e7f4dcf9b4  vpermilpd xmm1, xmm1, 0x00
000071e7f4dcf9ba  vmovaps xmm14, [rsp+0x100]
000071e7f4dcf9c3  vmovaps [rsp+0x100], xmm13
000071e7f4dcf9cc  movaps xmm15, xmm14
000071e7f4dcf9d0  mulpd xmm15, xmm1
000071e7f4dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000071e7f4dcf9db  ptest xmm13, xmm13
000071e7f4dcf9e1  jnz 0x000071E7F4DD198B
000071e7f4dcf9e7  lea rax, [r14+0x90]
000071e7f4dcf9ee  movups xmm1, [r13+rax*1]
000071e7f4dcf9f4  vmovaps [rsp+0x120], xmm4
000071e7f4dcf9fd  vmovaps xmm14, [rsp+0x120]
000071e7f4dcfa06  por xmm4, xmm14
000071e7f4dcfa0b  movaps [r15+0x1C0], xmm4
000071e7f4dcfa13  vmovaps [rsp+0x120], xmm11
000071e7f4dcfa1c  vmovaps xmm14, [rsp+0x120]
000071e7f4dcfa25  por xmm11, xmm14
000071e7f4dcfa2a  movaps [r15+0x200], xmm11
000071e7f4dcfa32  vmovaps [rsp+0x120], xmm5
000071e7f4dcfa3b  vmovaps xmm14, [rsp+0x120]
000071e7f4dcfa44  por xmm5, xmm14
000071e7f4dcfa49  movaps [r15+0x2D0], xmm5
000071e7f4dcfa51  vmovaps [rsp+0x120], xmm12
000071e7f4dcfa5a  vmovaps xmm14, [rsp+0x120]
000071e7f4dcfa63  por xmm12, xmm14
000071e7f4dcfa68  movaps [r15+0x2E0], xmm12
000071e7f4dcfa70  vmovaps xmm13, [rsp+0x110]
000071e7f4dcfa79  vmovaps [rsp+0x110], xmm1
000071e7f4dcfa82  vmovaps xmm1, [rsp+0xE0]
000071e7f4dcfa8b  vmovaps [rsp+0xE0], xmm15
000071e7f4dcfa94  movaps xmm14, xmm13
000071e7f4dcfa98  addpd xmm14, xmm1
000071e7f4dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000071e7f4dcfaa3  ptest xmm15, xmm15
000071e7f4dcfaa9  jnz 0x000071E7F4DD1AD8
000071e7f4dcfaaf  vmovaps xmm1, [rsp+0xA0]
000071e7f4dcfab8  vpermilpd xmm1, xmm1, 0x00
000071e7f4dcfabe  vmovaps xmm13, [rsp+0x110]
000071e7f4dcfac7  vmovaps [rsp+0x110], xmm14
000071e7f4dcfad0  movaps xmm15, xmm13
000071e7f4dcfad4  mulpd xmm15, xmm1
000071e7f4dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000071e7f4dcfadf  ptest xmm14, xmm14
000071e7f4dcfae5  jnz 0x000071E7F4DD1C1B
000071e7f4dcfaeb  lea rax, [r14+0x80]
000071e7f4dcfaf2  movups xmm1, [r13+rax*1]
000071e7f4dcfaf8  vmovaps xmm13, [rsp+0xC0]
000071e7f4dcfb01  vmovaps [rsp+0xC0], xmm1
000071e7f4dcfb0a  movaps xmm14, xmm13
000071e7f4dcfb0e  addpd xmm14, xmm2
000071e7f4dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000071e7f4dcfb19  ptest xmm1, xmm1
000071e7f4dcfb1e  jnz 0x000071E7F4DD1D68
000071e7f4dcfb24  vmovaps xmm13, [rsp+0x100]
000071e7f4dcfb2d  vmovaps xmm2, [rsp+0x30]
000071e7f4dcfb33  vmovaps [rsp+0x30], xmm15
000071e7f4dcfb39  movaps xmm1, xmm13
000071e7f4dcfb3d  addpd xmm1, xmm2
000071e7f4dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000071e7f4dcfb46  ptest xmm15, xmm15
000071e7f4dcfb4c  jnz 0x000071E7F4DD1EAB
000071e7f4dcfb52  vmovaps xmm15, [rsp+0x20]
000071e7f4dcfb58  vmovaps xmm13, [rsp+0x20]
000071e7f4dcfb5e  por xmm15, xmm13
000071e7f4dcfb63  movaps [r15+0x2F0], xmm15
000071e7f4dcfb6b  vmovaps xmm13, [rsp+0xA0]
000071e7f4dcfb74  vpermilpd xmm13, xmm13, 0x00
000071e7f4dcfb7a  vmovaps [rsp+0x20], xmm1
000071e7f4dcfb80  vmovaps xmm1, [rsp+0xC0]
000071e7f4dcfb89  vmovaps [rsp+0xA0], xmm15
000071e7f4dcfb92  movaps xmm2, xmm1
000071e7f4dcfb95  mulpd xmm2, xmm13
000071e7f4dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000071e7f4dcfb9f  ptest xmm15, xmm15
000071e7f4dcfba5  jnz 0x000071E7F4DD1FEC
000071e7f4dcfbab  lea rax, [r14+0xD0]
000071e7f4dcfbb2  movups xmm1, [r13+rax*1]
000071e7f4dcfbb8  vmovaps xmm13, [rsp+0xF0]
000071e7f4dcfbc1  vmovaps [rsp+0xC0], xmm1
000071e7f4dcfbca  vmovaps xmm1, [rsp+0xE0]
000071e7f4dcfbd3  vmovaps [rsp+0xE0], xmm14
000071e7f4dcfbdc  movaps xmm15, xmm13
000071e7f4dcfbe0  addpd xmm15, xmm1
000071e7f4dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000071e7f4dcfbeb  ptest xmm14, xmm14
000071e7f4dcfbf1  jnz 0x000071E7F4DD2137
000071e7f4dcfbf7  vmovaps xmm1, [rsp+0xB0]
000071e7f4dcfc00  vpermilpd xmm1, xmm1, 0x00
000071e7f4dcfc06  movaps xmm14, xmm11
000071e7f4dcfc0a  mulpd xmm14, xmm1
000071e7f4dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000071e7f4dcfc15  ptest xmm13, xmm13
000071e7f4dcfc1b  jnz 0x000071E7F4DD227A
000071e7f4dcfc21  movaps [r15+0x260], xmm14
000071e7f4dcfc29  vxorps xmm1, xmm1, xmm1
000071e7f4dcfc2d  vpbroadcastq xmm1, xmm1
000071e7f4dcfc32  movaps [r15+0x1B0], xmm1
000071e7f4dcfc3a  vmovaps xmm1, [rsp+0xB0]
000071e7f4dcfc43  vpermilpd xmm1, xmm1, 0x00
000071e7f4dcfc49  vmovaps xmm11, [rsp+0xC0]
000071e7f4dcfc52  vmovaps [rsp+0xC0], xmm15
000071e7f4dcfc5b  movaps xmm13, xmm11
000071e7f4dcfc5f  mulpd xmm13, xmm1
000071e7f4dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000071e7f4dcfc6a  ptest xmm15, xmm15
000071e7f4dcfc70  jnz 0x000071E7F4DD23BD
000071e7f4dcfc76  lea rax, [r14+0xC0]
000071e7f4dcfc7d  movups xmm1, [r13+rax*1]
000071e7f4dcfc83  vmovaps xmm11, [rsp+0x110]
000071e7f4dcfc8c  vmovaps [rsp+0xF0], xmm1
000071e7f4dcfc95  vmovaps xmm1, [rsp+0x30]
000071e7f4dcfc9b  vmovaps [rsp+0x30], xmm14
000071e7f4dcfca1  movaps xmm15, xmm11
000071e7f4dcfca5  addpd xmm15, xmm1
000071e7f4dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000071e7f4dcfcb0  ptest xmm14, xmm14
000071e7f4dcfcb6  jnz 0x000071E7F4DD250A
000071e7f4dcfcbc  vmovaps [rsp+0x100], xmm9
000071e7f4dcfcc5  vmovaps xmm1, [rsp+0x100]
000071e7f4dcfcce  por xmm9, xmm1
000071e7f4dcfcd3  movaps [r15+0x270], xmm9
000071e7f4dcfcdb  vmovaps [rsp+0x100], xmm6
000071e7f4dcfce4  vmovaps xmm1, [rsp+0x100]
000071e7f4dcfced  por xmm6, xmm1
000071e7f4dcfcf1  movaps [r15+0x1A0], xmm6
000071e7f4dcfcf9  vmovaps xmm14, [rsp+0xB0]
000071e7f4dcfd02  vpermilpd xmm14, xmm14, 0x00
000071e7f4dcfd08  vmovaps xmm6, [rsp+0xF0]
000071e7f4dcfd11  vmovaps [rsp+0xF0], xmm1
000071e7f4dcfd1a  movaps xmm11, xmm6
000071e7f4dcfd1e  mulpd xmm11, xmm14
000071e7f4dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000071e7f4dcfd29  ptest xmm1, xmm1
000071e7f4dcfd2e  jnz 0x000071E7F4DD264D
000071e7f4dcfd34  lea rax, [r14+0x20]
000071e7f4dcfd38  movups xmm1, [r13+rax*1]
000071e7f4dcfd3e  movaps [r15+0x110], xmm1
000071e7f4dcfd46  vmovaps xmm6, [rsp+0xE0]
000071e7f4dcfd4f  vmovaps [rsp+0xE0], xmm1
000071e7f4dcfd58  movaps xmm14, xmm6
000071e7f4dcfd5c  addpd xmm14, xmm2
000071e7f4dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000071e7f4dcfd67  ptest xmm1, xmm1
000071e7f4dcfd6c  jnz 0x000071E7F4DD279A
000071e7f4dcfd72  vmovaps xmm1, [rsp+0xB0]
000071e7f4dcfd7b  vpermilpd xmm1, xmm1, 0x00
000071e7f4dcfd81  movaps xmm6, xmm5
000071e7f4dcfd84  mulpd xmm6, xmm1
000071e7f4dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000071e7f4dcfd8d  ptest xmm2, xmm2
000071e7f4dcfd92  jnz 0x000071E7F4DD28DC
000071e7f4dcfd98  vmovaps xmm5, [rsp+0x20]
000071e7f4dcfd9e  movaps xmm1, xmm5
000071e7f4dcfda1  addpd xmm1, xmm13
000071e7f4dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000071e7f4dcfdab  ptest xmm2, xmm2
000071e7f4dcfdb0  jnz 0x000071E7F4DD2A1C
000071e7f4dcfdb6  vmovaps xmm13, [rsp+0x80]
000071e7f4dcfdbf  vpermilpd xmm13, xmm13, 0x00
000071e7f4dcfdc5  vmovaps xmm2, [rsp+0xE0]
000071e7f4dcfdce  vmovaps [rsp+0x20], xmm1
000071e7f4dcfdd4  movaps xmm5, xmm2
000071e7f4dcfdd7  mulpd xmm5, xmm13
000071e7f4dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000071e7f4dcfde1  ptest xmm1, xmm1
000071e7f4dcfde6  jnz 0x000071E7F4DD2B5D
000071e7f4dcfdec  vmovaps xmm1, [rsp+0x80]
000071e7f4dcfdf5  vpermilpd xmm1, xmm1, 0x00
000071e7f4dcfdfb  movaps xmm13, xmm10
000071e7f4dcfdff  mulpd xmm13, xmm1
000071e7f4dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000071e7f4dcfe0a  ptest xmm2, xmm2
000071e7f4dcfe0f  jnz 0x000071E7F4DD2C9E
000071e7f4dcfe15  vmovaps xmm10, [rsp+0x30]
000071e7f4dcfe1b  movaps xmm1, xmm15
000071e7f4dcfe1f  addpd xmm1, xmm10
000071e7f4dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000071e7f4dcfe29  ptest xmm2, xmm2
000071e7f4dcfe2e  jnz 0x000071E7F4DD2DE1
000071e7f4dcfe34  vmovaps xmm10, [rsp+0xC0]
000071e7f4dcfe3d  movaps xmm15, xmm10
000071e7f4dcfe41  addpd xmm15, xmm11
000071e7f4dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000071e7f4dcfe4c  ptest xmm2, xmm2
000071e7f4dcfe51  jnz 0x000071E7F4DD2F23
000071e7f4dcfe57  vmovaps xmm11, [rsp+0x80]
000071e7f4dcfe60  vpermilpd xmm11, xmm11, 0x00
000071e7f4dcfe66  movaps xmm10, xmm12
000071e7f4dcfe6a  mulpd xmm10, xmm11
000071e7f4dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000071e7f4dcfe75  ptest xmm2, xmm2
000071e7f4dcfe7a  jnz 0x000071E7F4DD3067
000071e7f4dcfe80  vmovaps xmm12, [rsp+0x80]
000071e7f4dcfe89  vpermilpd xmm12, xmm12, 0x00
000071e7f4dcfe8f  vmovaps xmm2, [rsp+0xA0]
000071e7f4dcfe98  vmovaps [rsp+0x30], xmm1
000071e7f4dcfe9e  movaps xmm11, xmm2
000071e7f4dcfea2  mulpd xmm11, xmm12
000071e7f4dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000071e7f4dcfead  ptest xmm1, xmm1
000071e7f4dcfeb2  jnz 0x000071E7F4DD31AB
000071e7f4dcfeb8  movaps xmm1, xmm14
000071e7f4dcfebc  addpd xmm1, xmm6
000071e7f4dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000071e7f4dcfec5  ptest xmm12, xmm12
000071e7f4dcfecb  jnz 0x000071E7F4DD32EE
000071e7f4dcfed1  vmovaps xmm12, [rsp+0x20]
000071e7f4dcfed7  movaps xmm14, xmm12
000071e7f4dcfedb  addpd xmm14, xmm5
000071e7f4dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000071e7f4dcfee6  ptest xmm6, xmm6
000071e7f4dcfeeb  jnz 0x000071E7F4DD342F
000071e7f4dcfef1  vmovaps xmm12, [rsp+0x90]
000071e7f4dcfefa  vpermilpd xmm12, xmm12, 0x00
000071e7f4dcff00  movaps xmm6, xmm9
000071e7f4dcff04  mulpd xmm6, xmm12
000071e7f4dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000071e7f4dcff0e  ptest xmm5, xmm5
000071e7f4dcff13  jnz 0x000071E7F4DD3572
000071e7f4dcff19  movaps xmm12, xmm15
000071e7f4dcff1d  addpd xmm12, xmm13
000071e7f4dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000071e7f4dcff28  ptest xmm9, xmm9
000071e7f4dcff2e  jnz 0x000071E7F4DD36B4
000071e7f4dcff34  vmovaps xmm13, [rsp+0x30]
000071e7f4dcff3a  movaps xmm15, xmm13
000071e7f4dcff3e  addpd xmm15, xmm10
000071e7f4dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000071e7f4dcff49  ptest xmm9, xmm9
000071e7f4dcff4f  jnz 0x000071E7F4DD37F8
000071e7f4dcff55  vmovaps xmm13, [rsp+0xD0]
000071e7f4dcff5e  vmovaps xmm10, [rsp+0xD0]
000071e7f4dcff67  por xmm13, xmm10
000071e7f4dcff6c  movaps [r15+0x250], xmm13
000071e7f4dcff74  vmovaps [rsp+0x20], xmm7
000071e7f4dcff7a  vmovaps xmm13, [rsp+0x20]
000071e7f4dcff80  por xmm7, xmm13
000071e7f4dcff85  movaps [r15+0x2A0], xmm7
000071e7f4dcff8d  vmovaps [rsp+0x20], xmm3
000071e7f4dcff93  vmovaps xmm13, [rsp+0x20]
000071e7f4dcff99  por xmm3, xmm13
000071e7f4dcff9e  movaps [r15+0x1D0], xmm3
000071e7f4dcffa6  lea rax, [r14+0x40]
000071e7f4dcffaa  movups xmm13, [r13+rax*1]
000071e7f4dcffb0  movaps [r15+0x2C0], xmm13
000071e7f4dcffb8  vmovaps xmm10, [rsp+0x90]
000071e7f4dcffc1  vpermilpd xmm10, xmm10, 0x00
000071e7f4dcffc7  movaps xmm9, xmm8
000071e7f4dcffcb  mulpd xmm9, xmm10
000071e7f4dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000071e7f4dcffd6  ptest xmm5, xmm5
000071e7f4dcffdb  jnz 0x000071E7F4DD3946
000071e7f4dcffe1  movaps xmm10, xmm1
000071e7f4dcffe5  addpd xmm10, xmm11
000071e7f4dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000071e7f4dcfff0  ptest xmm8, xmm8
000071e7f4dcfff6  jnz 0x000071E7F4DD3A8A
000071e7f4dcfffc  movaps xmm1, xmm14
000071e7f4dd0000  addpd xmm1, xmm6
000071e7f4dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000071e7f4dd0009  ptest xmm11, xmm11
000071e7f4dd000f  jnz 0x000071E7F4DD3BCD
000071e7f4dd0015  vmovaps xmm14, [rsp+0x90]
000071e7f4dd001e  vpermilpd xmm14, xmm14, 0x00
000071e7f4dd0024  movaps xmm11, xmm13
000071e7f4dd0028  mulpd xmm11, xmm14
000071e7f4dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000071e7f4dd0033  ptest xmm8, xmm8
000071e7f4dd0039  jnz 0x000071E7F4DD3D0E
000071e7f4dd003f  vmovaps xmm14, [rsp+0x90]
000071e7f4dd0048  vpermilpd xmm14, xmm14, 0x00
000071e7f4dd004e  vmovaps xmm8, [rsp+0x10]
000071e7f4dd0054  movaps xmm13, xmm8
000071e7f4dd0058  mulpd xmm13, xmm14
000071e7f4dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000071e7f4dd0063  ptest xmm6, xmm6
000071e7f4dd0068  jnz 0x000071E7F4DD3E52
000071e7f4dd006e  vmovaps xmm14, [rsp+0x60]
000071e7f4dd0074  vpermilpd xmm14, xmm14, 0x00
000071e7f4dd007a  movaps xmm8, xmm7
000071e7f4dd007e  mulpd xmm8, xmm14
000071e7f4dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000071e7f4dd0089  ptest xmm6, xmm6
000071e7f4dd008e  jnz 0x000071E7F4DD3F96
000071e7f4dd0094  movaps xmm14, xmm12
000071e7f4dd0098  addpd xmm14, xmm9
000071e7f4dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000071e7f4dd00a3  ptest xmm7, xmm7
000071e7f4dd00a8  jnz 0x000071E7F4DD40D9
000071e7f4dd00ae  vmovaps xmm12, [rsp+0x60]
000071e7f4dd00b4  vpermilpd xmm12, xmm12, 0x00
000071e7f4dd00ba  vmovaps xmm7, [rsp+0xF0]
000071e7f4dd00c3  movaps xmm9, xmm7
000071e7f4dd00c7  mulpd xmm9, xmm12
000071e7f4dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000071e7f4dd00d2  ptest xmm6, xmm6
000071e7f4dd00d7  jnz 0x000071E7F4DD421D
000071e7f4dd00dd  movaps xmm12, xmm15
000071e7f4dd00e1  addpd xmm12, xmm11
000071e7f4dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000071e7f4dd00ec  ptest xmm7, xmm7
000071e7f4dd00f1  jnz 0x000071E7F4DD4360
000071e7f4dd00f7  vmovaps xmm15, [rsp+0x60]
000071e7f4dd00fd  vpermilpd xmm15, xmm15, 0x00
000071e7f4dd0103  vmovaps xmm7, [rsp+0x40]
000071e7f4dd0109  movaps xmm11, xmm7
000071e7f4dd010d  mulpd xmm11, xmm15
000071e7f4dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000071e7f4dd0118  ptest xmm6, xmm6
000071e7f4dd011d  jnz 0x000071E7F4DD44A4
000071e7f4dd0123  movaps xmm15, xmm10
000071e7f4dd0127  addpd xmm15, xmm13
000071e7f4dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000071e7f4dd0132  ptest xmm7, xmm7
000071e7f4dd0137  jnz 0x000071E7F4DD45E7
000071e7f4dd013d  vmovaps xmm13, [rsp+0x60]
000071e7f4dd0143  vpermilpd xmm13, xmm13, 0x00
000071e7f4dd0149  vmovaps xmm7, [rsp+0x50]
000071e7f4dd014f  movaps xmm10, xmm7
000071e7f4dd0153  mulpd xmm10, xmm13
000071e7f4dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000071e7f4dd015e  ptest xmm6, xmm6
000071e7f4dd0163  jnz 0x000071E7F4DD472B
000071e7f4dd0169  movaps xmm13, xmm1
000071e7f4dd016d  addpd xmm13, xmm8
000071e7f4dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000071e7f4dd0178  ptest xmm7, xmm7
000071e7f4dd017d  jnz 0x000071E7F4DD486E
000071e7f4dd0183  lea rax, [r14+0x70]
000071e7f4dd0187  movups xmm1, [r13+rax*1]
000071e7f4dd018d  movaps [r15+0x240], xmm1
000071e7f4dd0195  movaps xmm8, xmm14
000071e7f4dd0199  addpd xmm8, xmm9
000071e7f4dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000071e7f4dd01a4  ptest xmm7, xmm7
000071e7f4dd01a9  jnz 0x000071E7F4DD49BB
000071e7f4dd01af  movaps [r15+0x170], xmm8
000071e7f4dd01b7  vmovaps xmm14, [rsp+0x70]
000071e7f4dd01bd  vpermilpd xmm14, xmm14, 0x00
000071e7f4dd01c3  movaps xmm9, xmm1
000071e7f4dd01c7  mulpd xmm9, xmm14
000071e7f4dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000071e7f4dd01d2  ptest xmm7, xmm7
000071e7f4dd01d7  jnz 0x000071E7F4DD4AFF
000071e7f4dd01dd  vmovaps xmm1, [rsp+0x70]
000071e7f4dd01e3  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd01e9  movaps xmm14, xmm4
000071e7f4dd01ed  mulpd xmm14, xmm1
000071e7f4dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000071e7f4dd01f8  ptest xmm7, xmm7
000071e7f4dd01fd  jnz 0x000071E7F4DD4C42
000071e7f4dd0203  movaps [r15+0x180], xmm14
000071e7f4dd020b  movaps xmm1, xmm12
000071e7f4dd020f  addpd xmm1, xmm11
000071e7f4dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000071e7f4dd0219  ptest xmm7, xmm7
000071e7f4dd021e  jnz 0x000071E7F4DD4D84
000071e7f4dd0224  movaps [r15+0x210], xmm1
000071e7f4dd022c  movups xmm12, [r13+r14*1]
000071e7f4dd0232  lea rax, [r14+0x10]
000071e7f4dd0236  movups xmm11, [r13+rax*1]
000071e7f4dd023c  movaps [r15+0x230], xmm11
000071e7f4dd0244  movaps xmm7, xmm15
000071e7f4dd0248  addpd xmm7, xmm10
000071e7f4dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000071e7f4dd0252  ptest xmm6, xmm6
000071e7f4dd0257  jnz 0x000071E7F4DD4EDA
000071e7f4dd025d  movaps [r15+0x130], xmm7
000071e7f4dd0265  vmovaps xmm15, [rsp+0x70]
000071e7f4dd026b  vpermilpd xmm15, xmm15, 0x00
000071e7f4dd0271  movaps xmm10, xmm11
000071e7f4dd0275  mulpd xmm10, xmm15
000071e7f4dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000071e7f4dd0280  ptest xmm6, xmm6
000071e7f4dd0285  jnz 0x000071E7F4DD501C
000071e7f4dd028b  movaps [r15+0x220], xmm10
000071e7f4dd0293  vmovaps xmm15, [rsp+0x70]
000071e7f4dd0299  vpermilpd xmm15, xmm15, 0x00
000071e7f4dd029f  movaps xmm11, xmm12
000071e7f4dd02a3  mulpd xmm11, xmm15
000071e7f4dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000071e7f4dd02ae  ptest xmm6, xmm6
000071e7f4dd02b3  jnz 0x000071E7F4DD5160
000071e7f4dd02b9  movaps xmm15, xmm13
000071e7f4dd02bd  addpd xmm15, xmm9
000071e7f4dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000071e7f4dd02c8  ptest xmm12, xmm12
000071e7f4dd02ce  jnz 0x000071E7F4DD52A4
000071e7f4dd02d4  movaps [r15+0x140], xmm15
000071e7f4dd02dc  movaps xmm13, xmm8
000071e7f4dd02e0  addpd xmm13, xmm14
000071e7f4dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000071e7f4dd02eb  ptest xmm12, xmm12
000071e7f4dd02f1  jnz 0x000071E7F4DD53E8
000071e7f4dd02f7  movaps [r15+0x150], xmm13
000071e7f4dd02ff  movaps xmm14, xmm1
000071e7f4dd0303  addpd xmm14, xmm10
000071e7f4dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000071e7f4dd030e  ptest xmm12, xmm12
000071e7f4dd0314  jnz 0x000071E7F4DD552C
000071e7f4dd031a  movaps [r15+0x160], xmm14
000071e7f4dd0322  movaps xmm1, xmm7
000071e7f4dd0325  addpd xmm1, xmm11
000071e7f4dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000071e7f4dd032f  ptest xmm12, xmm12
000071e7f4dd0335  jnz 0x000071E7F4DD566F
000071e7f4dd033b  movaps [r15+0x120], xmm1
000071e7f4dd0343  mov eax, 0x430920
000071e7f4dd0348  movups [r13+rax*1], xmm15
000071e7f4dd034e  mov eax, 0x430930
000071e7f4dd0353  movups [r13+rax*1], xmm13
000071e7f4dd0359  mov eax, 0x430940
000071e7f4dd035e  movups [r13+rax*1], xmm14
000071e7f4dd0364  mov eax, 0x430950
000071e7f4dd0369  movups [r13+rax*1], xmm1
000071e7f4dd036f  mov eax, [r15+0x108]
000071e7f4dd0376  sahf
000071e7f4dd0377  jnz 0x000071E7F4DD03A9
000071e7f4dd0379  cmp dword ptr [r15+0x318], 0x00
000071e7f4dd0381  jz 0x000071E7F4DDB900
000071e7f4dd0387  nop [rax+rax*1], ax
000071e7f4dd0390  nop [rax+rax*1], eax
000071e7f4dd0398  mov eax, 0x410444
000071e7f4dd039d  mov [r15+0x100], rax
000071e7f4dd03a4  jmp 0x000071E7F4BFE110
000071e7f4dd03a9  cmp dword ptr [r15+0x318], 0x00
000071e7f4dd03b1  jz 0x000071E7F4DD57E0
000071e7f4dd03b7  nop [rax+rax*1], ax
000071e7f4dd03c0  nop [rax+rax*1], eax
000071e7f4dd03c8  mov eax, 0x410278
000071e7f4dd03cd  mov [r15+0x100], rax
000071e7f4dd03d4  jmp 0x000071E7F4BFE110
000071e7f4dd03d9  int3
000071e7f4dd03da  call 0x000071E7F4CB52F0
000071e7f4dd03df  jmp 0x000071E7F4DCF016
000071e7f4dd03e4  call 0x000071E7F4CC4620
000071e7f4dd03e9  jmp 0x000071E7F4DCF023
000071e7f4dd03ee  call 0x000071E7F4CC33A0
000071e7f4dd03f3  jmp 0x000071E7F4DCF035
000071e7f4dd03f8  call 0x000071E7F4CC2120
000071e7f4dd03fd  jmp 0x000071E7F4DCF03F
000071e7f4dd0402  call 0x000071E7F4CC0860
000071e7f4dd0407  jmp 0x000071E7F4DCF067
000071e7f4dd040c  call 0x000071E7F4CBF5F0
000071e7f4dd0411  jmp 0x000071E7F4DCF073
000071e7f4dd0416  call 0x000071E7F4CC0860
000071e7f4dd041b  jmp 0x000071E7F4DCF0A5
000071e7f4dd0420  call 0x000071E7F4CBF5F0
000071e7f4dd0425  jmp 0x000071E7F4DCF0B1
000071e7f4dd042a  call 0x000071E7F4CC4740
000071e7f4dd042f  jmp 0x000071E7F4DCF0BE
000071e7f4dd0434  call 0x000071E7F4CB5400
000071e7f4dd0439  jmp 0x000071E7F4DCF0CB
000071e7f4dd043e  call 0x000071E7F4CB52F0
000071e7f4dd0443  jmp 0x000071E7F4DCF0D8
000071e7f4dd0448  call 0x000071E7F4CC4620
000071e7f4dd044d  jmp 0x000071E7F4DCF0E5
000071e7f4dd0452  call 0x000071E7F4CC0860
000071e7f4dd0457  jmp 0x000071E7F4DCF10D
000071e7f4dd045c  call 0x000071E7F4CBF5F0
000071e7f4dd0461  jmp 0x000071E7F4DCF119
000071e7f4dd0466  call 0x000071E7F4C09D70
000071e7f4dd046b  jmp 0x000071E7F4DCF11F
000071e7f4dd0470  call 0x000071E7F4CBE9C0
000071e7f4dd0475  jmp 0x000071E7F4DCF129
000071e7f4dd047a  call 0x000071E7F4CC0860
000071e7f4dd047f  jmp 0x000071E7F4DCF151
000071e7f4dd0484  call 0x000071E7F4CBF5F0
000071e7f4dd0489  jmp 0x000071E7F4DCF15D
000071e7f4dd048e  call 0x000071E7F4CBD750
000071e7f4dd0493  jmp 0x000071E7F4DCF16A
000071e7f4dd0498  call 0x000071E7F4CBC4E0
000071e7f4dd049d  jmp 0x000071E7F4DCF177
000071e7f4dd04a2  call 0x000071E7F4CC4740
000071e7f4dd04a7  jmp 0x000071E7F4DCF184
000071e7f4dd04ac  call 0x000071E7F4CB5400
000071e7f4dd04b1  jmp 0x000071E7F4DCF191
000071e7f4dd04b6  call 0x000071E7F4CB52F0
000071e7f4dd04bb  jmp 0x000071E7F4DCF19E
000071e7f4dd04c0  call 0x000071E7F4CC4620
000071e7f4dd04c5  jmp 0x000071E7F4DCF1AB
000071e7f4dd04ca  call 0x000071E7F4CC0860
000071e7f4dd04cf  jmp 0x000071E7F4DCF1BE
000071e7f4dd04d4  call 0x000071E7F4CBB270
000071e7f4dd04d9  jmp 0x000071E7F4DCF1CB
000071e7f4dd04de  call 0x000071E7F4CBA000
000071e7f4dd04e3  jmp 0x000071E7F4DCF1D8
000071e7f4dd04e8  call 0x000071E7F4CB8D90
000071e7f4dd04ed  jmp 0x000071E7F4DCF1E5
000071e7f4dd04f2  call 0x000071E7F4CB8A20
000071e7f4dd04f7  jmp 0x000071E7F4DCF1F2
000071e7f4dd04fc  call 0x000071E7F4CB5400
000071e7f4dd0501  jmp 0x000071E7F4DCF1FC
000071e7f4dd0506  call 0x000071E7F4CC2240
000071e7f4dd050b  jmp 0x000071E7F4DCF206
000071e7f4dd0510  call 0x000071E7F4CB52F0
000071e7f4dd0515  jmp 0x000071E7F4DCF210
000071e7f4dd051a  call 0x000071E7F4CC2120
000071e7f4dd051f  jmp 0x000071E7F4DCF21A
000071e7f4dd0524  call 0x000071E7F4CB77B0
000071e7f4dd0529  jmp 0x000071E7F4DCF224
000071e7f4dd052e  call 0x000071E7F4CB6550
000071e7f4dd0533  jmp 0x000071E7F4DCF22E
000071e7f4dd0538  call 0x000071E7F4CBFD50
000071e7f4dd053d  jmp 0x000071E7F4DCF240
000071e7f4dd0542  call 0x000071E7F4CB8EA0
000071e7f4dd0547  jmp 0x000071E7F4DCF24A
000071e7f4dd054c  call 0x000071E7F4CBFC30
000071e7f4dd0551  jmp 0x000071E7F4DCF257
000071e7f4dd0556  call 0x000071E7F4CB8D90
000071e7f4dd055b  jmp 0x000071E7F4DCF264
000071e7f4dd0560  call 0x000071E7F4CC2240
000071e7f4dd0565  jmp 0x000071E7F4DCF271
000071e7f4dd056a  call 0x000071E7F4CB5400
000071e7f4dd056f  jmp 0x000071E7F4DCF27E
000071e7f4dd0574  call 0x000071E7F4CB52F0
000071e7f4dd0579  jmp 0x000071E7F4DCF28B
000071e7f4dd057e  call 0x000071E7F4CC2120
000071e7f4dd0583  jmp 0x000071E7F4DCF298
000071e7f4dd0588  call 0x000071E7F4CB52F0
000071e7f4dd058d  jmp 0x000071E7F4DCF2AB
000071e7f4dd0592  call 0x000071E7F4CB52F0
000071e7f4dd0597  jmp 0x000071E7F4DCF2BE
000071e7f4dd059c  call 0x000071E7F4CB52F0
000071e7f4dd05a1  jmp 0x000071E7F4DCF2D1
000071e7f4dd05a6  call 0x000071E7F4CB52F0
000071e7f4dd05ab  jmp 0x000071E7F4DCF2E4
000071e7f4dd05b0  call 0x000071E7F4CC2240
000071e7f4dd05b5  jmp 0x000071E7F4DCF2F9
000071e7f4dd05ba  call 0x000071E7F4CC2240
000071e7f4dd05bf  jmp 0x000071E7F4DCF30C
000071e7f4dd05c4  call 0x000071E7F4CC2120
000071e7f4dd05c9  jmp 0x000071E7F4DCF319
000071e7f4dd05ce  call 0x000071E7F4CB52F0
000071e7f4dd05d3  jmp 0x000071E7F4DCF32C
000071e7f4dd05d8  call 0x000071E7F4CB52F0
000071e7f4dd05dd  jmp 0x000071E7F4DCF34F
000071e7f4dd05e2  call 0x000071E7F4CB52F0
000071e7f4dd05e7  jmp 0x000071E7F4DCF362
000071e7f4dd05ec  call 0x000071E7F4BFF540
000071e7f4dd05f1  jmp 0x000071E7F4DCF380
000071e7f4dd05f6  call 0x000071E7F4C08C20
000071e7f4dd05fb  jmp 0x000071E7F4DCF38A
000071e7f4dd0600  call 0x000071E7F4CD6600
000071e7f4dd0605  jmp 0x000071E7F4DCF396
000071e7f4dd060a  call 0x000071E7F4BFF540
000071e7f4dd060f  jmp 0x000071E7F4DCF3A6
000071e7f4dd0614  call 0x000071E7F4CC0370
000071e7f4dd0619  jmp 0x000071E7F4DCF3D4
000071e7f4dd061e  call 0x000071E7F4CBF100
000071e7f4dd0623  jmp 0x000071E7F4DCF3DD
000071e7f4dd0628  call 0x000071E7F4CC0370
000071e7f4dd062d  jmp 0x000071E7F4DCF43B
000071e7f4dd0632  call 0x000071E7F4CBF100
000071e7f4dd0637  jmp 0x000071E7F4DCF444
000071e7f4dd063c  call 0x000071E7F4CC0370
000071e7f4dd0641  jmp 0x000071E7F4DCF48B
000071e7f4dd0646  call 0x000071E7F4CBF100
000071e7f4dd064b  jmp 0x000071E7F4DCF494
000071e7f4dd0650  call 0x000071E7F4C0B720
000071e7f4dd0655  jmp 0x000071E7F4DCF4D7
000071e7f4dd065a  call 0x000071E7F4CB47C0
000071e7f4dd065f  jmp 0x000071E7F4DCF4EA
000071e7f4dd0664  call 0x000071E7F4C08B00
000071e7f4dd0669  jmp 0x000071E7F4DCF501
000071e7f4dd066e  call 0x000071E7F4BFF430
000071e7f4dd0673  jmp 0x000071E7F4DCF514
000071e7f4dd0678  call 0x000071E7F4BFF430
000071e7f4dd067d  jmp 0x000071E7F4DCF527
000071e7f4dd0682  sub rsp, 0x08
000071e7f4dd0686  push rax
000071e7f4dd0687  push rcx
000071e7f4dd0688  push rdx
000071e7f4dd0689  push rdi
000071e7f4dd068a  push rsi
000071e7f4dd068b  push r8
000071e7f4dd068d  push r9
000071e7f4dd068f  push r10
000071e7f4dd0691  push r11
000071e7f4dd0693  sub rsp, 0xF0
000071e7f4dd069a  vmovaps [rsp], xmm0
000071e7f4dd069f  vmovaps [rsp+0x10], xmm2
000071e7f4dd06a5  vmovaps [rsp+0x20], xmm3
000071e7f4dd06ab  vmovaps [rsp+0x30], xmm4
000071e7f4dd06b1  vmovaps [rsp+0x40], xmm5
000071e7f4dd06b7  vmovaps [rsp+0x50], xmm6
000071e7f4dd06bd  vmovaps [rsp+0x60], xmm7
000071e7f4dd06c3  vmovaps [rsp+0x70], xmm8
000071e7f4dd06c9  vmovaps [rsp+0x80], xmm9
000071e7f4dd06d2  vmovaps [rsp+0x90], xmm10
000071e7f4dd06db  vmovaps [rsp+0xA0], xmm11
000071e7f4dd06e4  vmovaps [rsp+0xB0], xmm12
000071e7f4dd06ed  vmovaps [rsp+0xC0], xmm13
000071e7f4dd06f6  vmovaps [rsp+0xD0], xmm14
000071e7f4dd06ff  vmovaps [rsp+0xE0], xmm15
000071e7f4dd0708  sub rsp, 0x30
000071e7f4dd070c  movaps [rsp], xmm1
000071e7f4dd0710  movaps [rsp+0x10], xmm15
000071e7f4dd0716  movaps [rsp+0x20], xmm14
000071e7f4dd071c  lea rdi, [rsp]
000071e7f4dd0720  mov esi, 0x00
000071e7f4dd0725  mov rax, 0x562A51E82530
000071e7f4dd072f  call rax
000071e7f4dd0731  movaps xmm1, [rsp]
000071e7f4dd0735  add rsp, 0x30
000071e7f4dd0739  vmovaps xmm0, [rsp]
000071e7f4dd073e  vmovaps xmm2, [rsp+0x10]
000071e7f4dd0744  vmovaps xmm3, [rsp+0x20]
000071e7f4dd074a  vmovaps xmm4, [rsp+0x30]
000071e7f4dd0750  vmovaps xmm5, [rsp+0x40]
000071e7f4dd0756  vmovaps xmm6, [rsp+0x50]
000071e7f4dd075c  vmovaps xmm7, [rsp+0x60]
000071e7f4dd0762  vmovaps xmm8, [rsp+0x70]
000071e7f4dd0768  vmovaps xmm9, [rsp+0x80]
000071e7f4dd0771  vmovaps xmm10, [rsp+0x90]
000071e7f4dd077a  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd0783  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd078c  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd0795  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd079e  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd07a7  add rsp, 0xF0
000071e7f4dd07ae  pop r11
000071e7f4dd07b0  pop r10
000071e7f4dd07b2  pop r9
000071e7f4dd07b4  pop r8
000071e7f4dd07b6  pop rsi
000071e7f4dd07b7  pop rdi
000071e7f4dd07b8  pop rdx
000071e7f4dd07b9  pop rcx
000071e7f4dd07ba  pop rax
000071e7f4dd07bb  add rsp, 0x08
000071e7f4dd07bf  jmp 0x000071E7F4DCF581
000071e7f4dd07c4  sub rsp, 0x08
000071e7f4dd07c8  push rax
000071e7f4dd07c9  push rcx
000071e7f4dd07ca  push rdx
000071e7f4dd07cb  push rdi
000071e7f4dd07cc  push rsi
000071e7f4dd07cd  push r8
000071e7f4dd07cf  push r9
000071e7f4dd07d1  push r10
000071e7f4dd07d3  push r11
000071e7f4dd07d5  sub rsp, 0xF0
000071e7f4dd07dc  vmovaps [rsp], xmm0
000071e7f4dd07e1  vmovaps [rsp+0x10], xmm1
000071e7f4dd07e7  vmovaps [rsp+0x20], xmm2
000071e7f4dd07ed  vmovaps [rsp+0x30], xmm3
000071e7f4dd07f3  vmovaps [rsp+0x40], xmm4
000071e7f4dd07f9  vmovaps [rsp+0x50], xmm5
000071e7f4dd07ff  vmovaps [rsp+0x60], xmm6
000071e7f4dd0805  vmovaps [rsp+0x70], xmm7
000071e7f4dd080b  vmovaps [rsp+0x80], xmm8
000071e7f4dd0814  vmovaps [rsp+0x90], xmm9
000071e7f4dd081d  vmovaps [rsp+0xA0], xmm10
000071e7f4dd0826  vmovaps [rsp+0xB0], xmm11
000071e7f4dd082f  vmovaps [rsp+0xC0], xmm12
000071e7f4dd0838  vmovaps [rsp+0xD0], xmm14
000071e7f4dd0841  vmovaps [rsp+0xE0], xmm15
000071e7f4dd084a  sub rsp, 0x30
000071e7f4dd084e  movaps [rsp], xmm13
000071e7f4dd0853  movaps [rsp+0x10], xmm1
000071e7f4dd0858  movaps [rsp+0x20], xmm14
000071e7f4dd085e  lea rdi, [rsp]
000071e7f4dd0862  mov esi, 0x00
000071e7f4dd0867  mov rax, 0x562A51E82530
000071e7f4dd0871  call rax
000071e7f4dd0873  movaps xmm13, [rsp]
000071e7f4dd0878  add rsp, 0x30
000071e7f4dd087c  vmovaps xmm0, [rsp]
000071e7f4dd0881  vmovaps xmm1, [rsp+0x10]
000071e7f4dd0887  vmovaps xmm2, [rsp+0x20]
000071e7f4dd088d  vmovaps xmm3, [rsp+0x30]
000071e7f4dd0893  vmovaps xmm4, [rsp+0x40]
000071e7f4dd0899  vmovaps xmm5, [rsp+0x50]
000071e7f4dd089f  vmovaps xmm6, [rsp+0x60]
000071e7f4dd08a5  vmovaps xmm7, [rsp+0x70]
000071e7f4dd08ab  vmovaps xmm8, [rsp+0x80]
000071e7f4dd08b4  vmovaps xmm9, [rsp+0x90]
000071e7f4dd08bd  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd08c6  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd08cf  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd08d8  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd08e1  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd08ea  add rsp, 0xF0
000071e7f4dd08f1  pop r11
000071e7f4dd08f3  pop r10
000071e7f4dd08f5  pop r9
000071e7f4dd08f7  pop r8
000071e7f4dd08f9  pop rsi
000071e7f4dd08fa  pop rdi
000071e7f4dd08fb  pop rdx
000071e7f4dd08fc  pop rcx
000071e7f4dd08fd  pop rax
000071e7f4dd08fe  add rsp, 0x08
000071e7f4dd0902  jmp 0x000071E7F4DCF5CF
000071e7f4dd0907  sub rsp, 0x08
000071e7f4dd090b  push rax
000071e7f4dd090c  push rcx
000071e7f4dd090d  push rdx
000071e7f4dd090e  push rdi
000071e7f4dd090f  push rsi
000071e7f4dd0910  push r8
000071e7f4dd0912  push r9
000071e7f4dd0914  push r10
000071e7f4dd0916  push r11
000071e7f4dd0918  sub rsp, 0xF0
000071e7f4dd091f  vmovaps [rsp], xmm0
000071e7f4dd0924  vmovaps [rsp+0x10], xmm1
000071e7f4dd092a  vmovaps [rsp+0x20], xmm2
000071e7f4dd0930  vmovaps [rsp+0x30], xmm3
000071e7f4dd0936  vmovaps [rsp+0x40], xmm4
000071e7f4dd093c  vmovaps [rsp+0x50], xmm5
000071e7f4dd0942  vmovaps [rsp+0x60], xmm6
000071e7f4dd0948  vmovaps [rsp+0x70], xmm7
000071e7f4dd094e  vmovaps [rsp+0x80], xmm8
000071e7f4dd0957  vmovaps [rsp+0x90], xmm9
000071e7f4dd0960  vmovaps [rsp+0xA0], xmm10
000071e7f4dd0969  vmovaps [rsp+0xB0], xmm11
000071e7f4dd0972  vmovaps [rsp+0xC0], xmm12
000071e7f4dd097b  vmovaps [rsp+0xD0], xmm13
000071e7f4dd0984  vmovaps [rsp+0xE0], xmm14
000071e7f4dd098d  sub rsp, 0x30
000071e7f4dd0991  movaps [rsp], xmm15
000071e7f4dd0996  movaps [rsp+0x10], xmm14
000071e7f4dd099c  movaps [rsp+0x20], xmm1
000071e7f4dd09a1  lea rdi, [rsp]
000071e7f4dd09a5  mov esi, 0x00
000071e7f4dd09aa  mov rax, 0x562A51E82530
000071e7f4dd09b4  call rax
000071e7f4dd09b6  movaps xmm15, [rsp]
000071e7f4dd09bb  add rsp, 0x30
000071e7f4dd09bf  vmovaps xmm0, [rsp]
000071e7f4dd09c4  vmovaps xmm1, [rsp+0x10]
000071e7f4dd09ca  vmovaps xmm2, [rsp+0x20]
000071e7f4dd09d0  vmovaps xmm3, [rsp+0x30]
000071e7f4dd09d6  vmovaps xmm4, [rsp+0x40]
000071e7f4dd09dc  vmovaps xmm5, [rsp+0x50]
000071e7f4dd09e2  vmovaps xmm6, [rsp+0x60]
000071e7f4dd09e8  vmovaps xmm7, [rsp+0x70]
000071e7f4dd09ee  vmovaps xmm8, [rsp+0x80]
000071e7f4dd09f7  vmovaps xmm9, [rsp+0x90]
000071e7f4dd0a00  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd0a09  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd0a12  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd0a1b  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd0a24  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd0a2d  add rsp, 0xF0
000071e7f4dd0a34  pop r11
000071e7f4dd0a36  pop r10
000071e7f4dd0a38  pop r9
000071e7f4dd0a3a  pop r8
000071e7f4dd0a3c  pop rsi
000071e7f4dd0a3d  pop rdi
000071e7f4dd0a3e  pop rdx
000071e7f4dd0a3f  pop rcx
000071e7f4dd0a40  pop rax
000071e7f4dd0a41  add rsp, 0x08
000071e7f4dd0a45  jmp 0x000071E7F4DCF617
000071e7f4dd0a4a  sub rsp, 0x08
000071e7f4dd0a4e  push rax
000071e7f4dd0a4f  push rcx
000071e7f4dd0a50  push rdx
000071e7f4dd0a51  push rdi
000071e7f4dd0a52  push rsi
000071e7f4dd0a53  push r8
000071e7f4dd0a55  push r9
000071e7f4dd0a57  push r10
000071e7f4dd0a59  push r11
000071e7f4dd0a5b  sub rsp, 0xF0
000071e7f4dd0a62  vmovaps [rsp], xmm0
000071e7f4dd0a67  vmovaps [rsp+0x10], xmm2
000071e7f4dd0a6d  vmovaps [rsp+0x20], xmm3
000071e7f4dd0a73  vmovaps [rsp+0x30], xmm4
000071e7f4dd0a79  vmovaps [rsp+0x40], xmm5
000071e7f4dd0a7f  vmovaps [rsp+0x50], xmm6
000071e7f4dd0a85  vmovaps [rsp+0x60], xmm7
000071e7f4dd0a8b  vmovaps [rsp+0x70], xmm8
000071e7f4dd0a91  vmovaps [rsp+0x80], xmm9
000071e7f4dd0a9a  vmovaps [rsp+0x90], xmm10
000071e7f4dd0aa3  vmovaps [rsp+0xA0], xmm11
000071e7f4dd0aac  vmovaps [rsp+0xB0], xmm12
000071e7f4dd0ab5  vmovaps [rsp+0xC0], xmm13
000071e7f4dd0abe  vmovaps [rsp+0xD0], xmm14
000071e7f4dd0ac7  vmovaps [rsp+0xE0], xmm15
000071e7f4dd0ad0  sub rsp, 0x30
000071e7f4dd0ad4  movaps [rsp], xmm1
000071e7f4dd0ad8  movaps [rsp+0x10], xmm14
000071e7f4dd0ade  movaps [rsp+0x20], xmm10
000071e7f4dd0ae4  lea rdi, [rsp]
000071e7f4dd0ae8  mov esi, 0x00
000071e7f4dd0aed  mov rax, 0x562A51E82530
000071e7f4dd0af7  call rax
000071e7f4dd0af9  movaps xmm1, [rsp]
000071e7f4dd0afd  add rsp, 0x30
000071e7f4dd0b01  vmovaps xmm0, [rsp]
000071e7f4dd0b06  vmovaps xmm2, [rsp+0x10]
000071e7f4dd0b0c  vmovaps xmm3, [rsp+0x20]
000071e7f4dd0b12  vmovaps xmm4, [rsp+0x30]
000071e7f4dd0b18  vmovaps xmm5, [rsp+0x40]
000071e7f4dd0b1e  vmovaps xmm6, [rsp+0x50]
000071e7f4dd0b24  vmovaps xmm7, [rsp+0x60]
000071e7f4dd0b2a  vmovaps xmm8, [rsp+0x70]
000071e7f4dd0b30  vmovaps xmm9, [rsp+0x80]
000071e7f4dd0b39  vmovaps xmm10, [rsp+0x90]
000071e7f4dd0b42  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd0b4b  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd0b54  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd0b5d  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd0b66  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd0b6f  add rsp, 0xF0
000071e7f4dd0b76  pop r11
000071e7f4dd0b78  pop r10
000071e7f4dd0b7a  pop r9
000071e7f4dd0b7c  pop r8
000071e7f4dd0b7e  pop rsi
000071e7f4dd0b7f  pop rdi
000071e7f4dd0b80  pop rdx
000071e7f4dd0b81  pop rcx
000071e7f4dd0b82  pop rax
000071e7f4dd0b83  add rsp, 0x08
000071e7f4dd0b87  jmp 0x000071E7F4DCF631
000071e7f4dd0b8c  sub rsp, 0x08
000071e7f4dd0b90  push rax
000071e7f4dd0b91  push rcx
000071e7f4dd0b92  push rdx
000071e7f4dd0b93  push rdi
000071e7f4dd0b94  push rsi
000071e7f4dd0b95  push r8
000071e7f4dd0b97  push r9
000071e7f4dd0b99  push r10
000071e7f4dd0b9b  push r11
000071e7f4dd0b9d  sub rsp, 0xF0
000071e7f4dd0ba4  vmovaps [rsp], xmm0
000071e7f4dd0ba9  vmovaps [rsp+0x10], xmm1
000071e7f4dd0baf  vmovaps [rsp+0x20], xmm2
000071e7f4dd0bb5  vmovaps [rsp+0x30], xmm3
000071e7f4dd0bbb  vmovaps [rsp+0x40], xmm4
000071e7f4dd0bc1  vmovaps [rsp+0x50], xmm5
000071e7f4dd0bc7  vmovaps [rsp+0x60], xmm6
000071e7f4dd0bcd  vmovaps [rsp+0x70], xmm7
000071e7f4dd0bd3  vmovaps [rsp+0x80], xmm8
000071e7f4dd0bdc  vmovaps [rsp+0x90], xmm9
000071e7f4dd0be5  vmovaps [rsp+0xA0], xmm10
000071e7f4dd0bee  vmovaps [rsp+0xB0], xmm11
000071e7f4dd0bf7  vmovaps [rsp+0xC0], xmm12
000071e7f4dd0c00  vmovaps [rsp+0xD0], xmm14
000071e7f4dd0c09  vmovaps [rsp+0xE0], xmm15
000071e7f4dd0c12  sub rsp, 0x30
000071e7f4dd0c16  movaps [rsp], xmm13
000071e7f4dd0c1b  movaps [rsp+0x10], xmm14
000071e7f4dd0c21  movaps [rsp+0x20], xmm2
000071e7f4dd0c26  lea rdi, [rsp]
000071e7f4dd0c2a  mov esi, 0x00
000071e7f4dd0c2f  mov rax, 0x562A51E82530
000071e7f4dd0c39  call rax
000071e7f4dd0c3b  movaps xmm13, [rsp]
000071e7f4dd0c40  add rsp, 0x30
000071e7f4dd0c44  vmovaps xmm0, [rsp]
000071e7f4dd0c49  vmovaps xmm1, [rsp+0x10]
000071e7f4dd0c4f  vmovaps xmm2, [rsp+0x20]
000071e7f4dd0c55  vmovaps xmm3, [rsp+0x30]
000071e7f4dd0c5b  vmovaps xmm4, [rsp+0x40]
000071e7f4dd0c61  vmovaps xmm5, [rsp+0x50]
000071e7f4dd0c67  vmovaps xmm6, [rsp+0x60]
000071e7f4dd0c6d  vmovaps xmm7, [rsp+0x70]
000071e7f4dd0c73  vmovaps xmm8, [rsp+0x80]
000071e7f4dd0c7c  vmovaps xmm9, [rsp+0x90]
000071e7f4dd0c85  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd0c8e  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd0c97  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd0ca0  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd0ca9  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd0cb2  add rsp, 0xF0
000071e7f4dd0cb9  pop r11
000071e7f4dd0cbb  pop r10
000071e7f4dd0cbd  pop r9
000071e7f4dd0cbf  pop r8
000071e7f4dd0cc1  pop rsi
000071e7f4dd0cc2  pop rdi
000071e7f4dd0cc3  pop rdx
000071e7f4dd0cc4  pop rcx
000071e7f4dd0cc5  pop rax
000071e7f4dd0cc6  add rsp, 0x08
000071e7f4dd0cca  jmp 0x000071E7F4DCF64C
000071e7f4dd0ccf  sub rsp, 0x08
000071e7f4dd0cd3  push rax
000071e7f4dd0cd4  push rcx
000071e7f4dd0cd5  push rdx
000071e7f4dd0cd6  push rdi
000071e7f4dd0cd7  push rsi
000071e7f4dd0cd8  push r8
000071e7f4dd0cda  push r9
000071e7f4dd0cdc  push r10
000071e7f4dd0cde  push r11
000071e7f4dd0ce0  sub rsp, 0xF0
000071e7f4dd0ce7  vmovaps [rsp], xmm0
000071e7f4dd0cec  vmovaps [rsp+0x10], xmm2
000071e7f4dd0cf2  vmovaps [rsp+0x20], xmm3
000071e7f4dd0cf8  vmovaps [rsp+0x30], xmm4
000071e7f4dd0cfe  vmovaps [rsp+0x40], xmm5
000071e7f4dd0d04  vmovaps [rsp+0x50], xmm6
000071e7f4dd0d0a  vmovaps [rsp+0x60], xmm7
000071e7f4dd0d10  vmovaps [rsp+0x70], xmm8
000071e7f4dd0d16  vmovaps [rsp+0x80], xmm9
000071e7f4dd0d1f  vmovaps [rsp+0x90], xmm10
000071e7f4dd0d28  vmovaps [rsp+0xA0], xmm11
000071e7f4dd0d31  vmovaps [rsp+0xB0], xmm12
000071e7f4dd0d3a  vmovaps [rsp+0xC0], xmm13
000071e7f4dd0d43  vmovaps [rsp+0xD0], xmm14
000071e7f4dd0d4c  vmovaps [rsp+0xE0], xmm15
000071e7f4dd0d55  sub rsp, 0x30
000071e7f4dd0d59  movaps [rsp], xmm1
000071e7f4dd0d5d  movaps [rsp+0x10], xmm10
000071e7f4dd0d63  movaps [rsp+0x20], xmm2
000071e7f4dd0d68  lea rdi, [rsp]
000071e7f4dd0d6c  mov esi, 0x00
000071e7f4dd0d71  mov rax, 0x562A51E82530
000071e7f4dd0d7b  call rax
000071e7f4dd0d7d  movaps xmm1, [rsp]
000071e7f4dd0d81  add rsp, 0x30
000071e7f4dd0d85  vmovaps xmm0, [rsp]
000071e7f4dd0d8a  vmovaps xmm2, [rsp+0x10]
000071e7f4dd0d90  vmovaps xmm3, [rsp+0x20]
000071e7f4dd0d96  vmovaps xmm4, [rsp+0x30]
000071e7f4dd0d9c  vmovaps xmm5, [rsp+0x40]
000071e7f4dd0da2  vmovaps xmm6, [rsp+0x50]
000071e7f4dd0da8  vmovaps xmm7, [rsp+0x60]
000071e7f4dd0dae  vmovaps xmm8, [rsp+0x70]
000071e7f4dd0db4  vmovaps xmm9, [rsp+0x80]
000071e7f4dd0dbd  vmovaps xmm10, [rsp+0x90]
000071e7f4dd0dc6  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd0dcf  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd0dd8  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd0de1  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd0dea  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd0df3  add rsp, 0xF0
000071e7f4dd0dfa  pop r11
000071e7f4dd0dfc  pop r10
000071e7f4dd0dfe  pop r9
000071e7f4dd0e00  pop r8
000071e7f4dd0e02  pop rsi
000071e7f4dd0e03  pop rdi
000071e7f4dd0e04  pop rdx
000071e7f4dd0e05  pop rcx
000071e7f4dd0e06  pop rax
000071e7f4dd0e07  add rsp, 0x08
000071e7f4dd0e0b  jmp 0x000071E7F4DCF6B4
000071e7f4dd0e10  sub rsp, 0x08
000071e7f4dd0e14  push rax
000071e7f4dd0e15  push rcx
000071e7f4dd0e16  push rdx
000071e7f4dd0e17  push rdi
000071e7f4dd0e18  push rsi
000071e7f4dd0e19  push r8
000071e7f4dd0e1b  push r9
000071e7f4dd0e1d  push r10
000071e7f4dd0e1f  push r11
000071e7f4dd0e21  sub rsp, 0xF0
000071e7f4dd0e28  vmovaps [rsp], xmm0
000071e7f4dd0e2d  vmovaps [rsp+0x10], xmm1
000071e7f4dd0e33  vmovaps [rsp+0x20], xmm2
000071e7f4dd0e39  vmovaps [rsp+0x30], xmm3
000071e7f4dd0e3f  vmovaps [rsp+0x40], xmm4
000071e7f4dd0e45  vmovaps [rsp+0x50], xmm5
000071e7f4dd0e4b  vmovaps [rsp+0x60], xmm6
000071e7f4dd0e51  vmovaps [rsp+0x70], xmm7
000071e7f4dd0e57  vmovaps [rsp+0x80], xmm8
000071e7f4dd0e60  vmovaps [rsp+0x90], xmm9
000071e7f4dd0e69  vmovaps [rsp+0xA0], xmm10
000071e7f4dd0e72  vmovaps [rsp+0xB0], xmm11
000071e7f4dd0e7b  vmovaps [rsp+0xC0], xmm12
000071e7f4dd0e84  vmovaps [rsp+0xD0], xmm13
000071e7f4dd0e8d  vmovaps [rsp+0xE0], xmm14
000071e7f4dd0e96  sub rsp, 0x30
000071e7f4dd0e9a  movaps [rsp], xmm15
000071e7f4dd0e9f  movaps [rsp+0x10], xmm10
000071e7f4dd0ea5  movaps [rsp+0x20], xmm2
000071e7f4dd0eaa  lea rdi, [rsp]
000071e7f4dd0eae  mov esi, 0x00
000071e7f4dd0eb3  mov rax, 0x562A51E82530
000071e7f4dd0ebd  call rax
000071e7f4dd0ebf  movaps xmm15, [rsp]
000071e7f4dd0ec4  add rsp, 0x30
000071e7f4dd0ec8  vmovaps xmm0, [rsp]
000071e7f4dd0ecd  vmovaps xmm1, [rsp+0x10]
000071e7f4dd0ed3  vmovaps xmm2, [rsp+0x20]
000071e7f4dd0ed9  vmovaps xmm3, [rsp+0x30]
000071e7f4dd0edf  vmovaps xmm4, [rsp+0x40]
000071e7f4dd0ee5  vmovaps xmm5, [rsp+0x50]
000071e7f4dd0eeb  vmovaps xmm6, [rsp+0x60]
000071e7f4dd0ef1  vmovaps xmm7, [rsp+0x70]
000071e7f4dd0ef7  vmovaps xmm8, [rsp+0x80]
000071e7f4dd0f00  vmovaps xmm9, [rsp+0x90]
000071e7f4dd0f09  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd0f12  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd0f1b  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd0f24  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd0f2d  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd0f36  add rsp, 0xF0
000071e7f4dd0f3d  pop r11
000071e7f4dd0f3f  pop r10
000071e7f4dd0f41  pop r9
000071e7f4dd0f43  pop r8
000071e7f4dd0f45  pop rsi
000071e7f4dd0f46  pop rdi
000071e7f4dd0f47  pop rdx
000071e7f4dd0f48  pop rcx
000071e7f4dd0f49  pop rax
000071e7f4dd0f4a  add rsp, 0x08
000071e7f4dd0f4e  jmp 0x000071E7F4DCF706
000071e7f4dd0f53  sub rsp, 0x08
000071e7f4dd0f57  push rax
000071e7f4dd0f58  push rcx
000071e7f4dd0f59  push rdx
000071e7f4dd0f5a  push rdi
000071e7f4dd0f5b  push rsi
000071e7f4dd0f5c  push r8
000071e7f4dd0f5e  push r9
000071e7f4dd0f60  push r10
000071e7f4dd0f62  push r11
000071e7f4dd0f64  sub rsp, 0xF0
000071e7f4dd0f6b  vmovaps [rsp], xmm0
000071e7f4dd0f70  vmovaps [rsp+0x10], xmm2
000071e7f4dd0f76  vmovaps [rsp+0x20], xmm3
000071e7f4dd0f7c  vmovaps [rsp+0x30], xmm4
000071e7f4dd0f82  vmovaps [rsp+0x40], xmm5
000071e7f4dd0f88  vmovaps [rsp+0x50], xmm6
000071e7f4dd0f8e  vmovaps [rsp+0x60], xmm7
000071e7f4dd0f94  vmovaps [rsp+0x70], xmm8
000071e7f4dd0f9a  vmovaps [rsp+0x80], xmm9
000071e7f4dd0fa3  vmovaps [rsp+0x90], xmm10
000071e7f4dd0fac  vmovaps [rsp+0xA0], xmm11
000071e7f4dd0fb5  vmovaps [rsp+0xB0], xmm12
000071e7f4dd0fbe  vmovaps [rsp+0xC0], xmm13
000071e7f4dd0fc7  vmovaps [rsp+0xD0], xmm14
000071e7f4dd0fd0  vmovaps [rsp+0xE0], xmm15
000071e7f4dd0fd9  sub rsp, 0x30
000071e7f4dd0fdd  movaps [rsp], xmm1
000071e7f4dd0fe1  movaps [rsp+0x10], xmm10
000071e7f4dd0fe7  movaps [rsp+0x20], xmm12
000071e7f4dd0fed  lea rdi, [rsp]
000071e7f4dd0ff1  mov esi, 0x00
000071e7f4dd0ff6  mov rax, 0x562A51E82530
000071e7f4dd1000  call rax
000071e7f4dd1002  movaps xmm1, [rsp]
000071e7f4dd1006  add rsp, 0x30
000071e7f4dd100a  vmovaps xmm0, [rsp]
000071e7f4dd100f  vmovaps xmm2, [rsp+0x10]
000071e7f4dd1015  vmovaps xmm3, [rsp+0x20]
000071e7f4dd101b  vmovaps xmm4, [rsp+0x30]
000071e7f4dd1021  vmovaps xmm5, [rsp+0x40]
000071e7f4dd1027  vmovaps xmm6, [rsp+0x50]
000071e7f4dd102d  vmovaps xmm7, [rsp+0x60]
000071e7f4dd1033  vmovaps xmm8, [rsp+0x70]
000071e7f4dd1039  vmovaps xmm9, [rsp+0x80]
000071e7f4dd1042  vmovaps xmm10, [rsp+0x90]
000071e7f4dd104b  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd1054  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd105d  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd1066  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd106f  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd1078  add rsp, 0xF0
000071e7f4dd107f  pop r11
000071e7f4dd1081  pop r10
000071e7f4dd1083  pop r9
000071e7f4dd1085  pop r8
000071e7f4dd1087  pop rsi
000071e7f4dd1088  pop rdi
000071e7f4dd1089  pop rdx
000071e7f4dd108a  pop rcx
000071e7f4dd108b  pop rax
000071e7f4dd108c  add rsp, 0x08
000071e7f4dd1090  jmp 0x000071E7F4DCF732
000071e7f4dd1095  sub rsp, 0x08
000071e7f4dd1099  push rax
000071e7f4dd109a  push rcx
000071e7f4dd109b  push rdx
000071e7f4dd109c  push rdi
000071e7f4dd109d  push rsi
000071e7f4dd109e  push r8
000071e7f4dd10a0  push r9
000071e7f4dd10a2  push r10
000071e7f4dd10a4  push r11
000071e7f4dd10a6  sub rsp, 0xF0
000071e7f4dd10ad  vmovaps [rsp], xmm0
000071e7f4dd10b2  vmovaps [rsp+0x10], xmm1
000071e7f4dd10b8  vmovaps [rsp+0x20], xmm2
000071e7f4dd10be  vmovaps [rsp+0x30], xmm3
000071e7f4dd10c4  vmovaps [rsp+0x40], xmm4
000071e7f4dd10ca  vmovaps [rsp+0x50], xmm5
000071e7f4dd10d0  vmovaps [rsp+0x60], xmm6
000071e7f4dd10d6  vmovaps [rsp+0x70], xmm7
000071e7f4dd10dc  vmovaps [rsp+0x80], xmm8
000071e7f4dd10e5  vmovaps [rsp+0x90], xmm9
000071e7f4dd10ee  vmovaps [rsp+0xA0], xmm10
000071e7f4dd10f7  vmovaps [rsp+0xB0], xmm11
000071e7f4dd1100  vmovaps [rsp+0xC0], xmm12
000071e7f4dd1109  vmovaps [rsp+0xD0], xmm13
000071e7f4dd1112  vmovaps [rsp+0xE0], xmm14
000071e7f4dd111b  sub rsp, 0x30
000071e7f4dd111f  movaps [rsp], xmm15
000071e7f4dd1124  movaps [rsp+0x10], xmm10
000071e7f4dd112a  movaps [rsp+0x20], xmm12
000071e7f4dd1130  lea rdi, [rsp]
000071e7f4dd1134  mov esi, 0x00
000071e7f4dd1139  mov rax, 0x562A51E82530
000071e7f4dd1143  call rax
000071e7f4dd1145  movaps xmm15, [rsp]
000071e7f4dd114a  add rsp, 0x30
000071e7f4dd114e  vmovaps xmm0, [rsp]
000071e7f4dd1153  vmovaps xmm1, [rsp+0x10]
000071e7f4dd1159  vmovaps xmm2, [rsp+0x20]
000071e7f4dd115f  vmovaps xmm3, [rsp+0x30]
000071e7f4dd1165  vmovaps xmm4, [rsp+0x40]
000071e7f4dd116b  vmovaps xmm5, [rsp+0x50]
000071e7f4dd1171  vmovaps xmm6, [rsp+0x60]
000071e7f4dd1177  vmovaps xmm7, [rsp+0x70]
000071e7f4dd117d  vmovaps xmm8, [rsp+0x80]
000071e7f4dd1186  vmovaps xmm9, [rsp+0x90]
000071e7f4dd118f  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd1198  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd11a1  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd11aa  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd11b3  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd11bc  add rsp, 0xF0
000071e7f4dd11c3  pop r11
000071e7f4dd11c5  pop r10
000071e7f4dd11c7  pop r9
000071e7f4dd11c9  pop r8
000071e7f4dd11cb  pop rsi
000071e7f4dd11cc  pop rdi
000071e7f4dd11cd  pop rdx
000071e7f4dd11ce  pop rcx
000071e7f4dd11cf  pop rax
000071e7f4dd11d0  add rsp, 0x08
000071e7f4dd11d4  jmp 0x000071E7F4DCF75E
000071e7f4dd11d9  call 0x000071E7F4BFF430
000071e7f4dd11de  jmp 0x000071E7F4DCF7EE
000071e7f4dd11e3  call 0x000071E7F4BFF430
000071e7f4dd11e8  jmp 0x000071E7F4DCF801
000071e7f4dd11ed  sub rsp, 0x08
000071e7f4dd11f1  push rax
000071e7f4dd11f2  push rcx
000071e7f4dd11f3  push rdx
000071e7f4dd11f4  push rdi
000071e7f4dd11f5  push rsi
000071e7f4dd11f6  push r8
000071e7f4dd11f8  push r9
000071e7f4dd11fa  push r10
000071e7f4dd11fc  push r11
000071e7f4dd11fe  sub rsp, 0xF0
000071e7f4dd1205  vmovaps [rsp], xmm0
000071e7f4dd120a  vmovaps [rsp+0x10], xmm2
000071e7f4dd1210  vmovaps [rsp+0x20], xmm3
000071e7f4dd1216  vmovaps [rsp+0x30], xmm4
000071e7f4dd121c  vmovaps [rsp+0x40], xmm5
000071e7f4dd1222  vmovaps [rsp+0x50], xmm6
000071e7f4dd1228  vmovaps [rsp+0x60], xmm7
000071e7f4dd122e  vmovaps [rsp+0x70], xmm8
000071e7f4dd1234  vmovaps [rsp+0x80], xmm9
000071e7f4dd123d  vmovaps [rsp+0x90], xmm10
000071e7f4dd1246  vmovaps [rsp+0xA0], xmm11
000071e7f4dd124f  vmovaps [rsp+0xB0], xmm12
000071e7f4dd1258  vmovaps [rsp+0xC0], xmm13
000071e7f4dd1261  vmovaps [rsp+0xD0], xmm14
000071e7f4dd126a  vmovaps [rsp+0xE0], xmm15
000071e7f4dd1273  sub rsp, 0x30
000071e7f4dd1277  movaps [rsp], xmm1
000071e7f4dd127b  movaps [rsp+0x10], xmm13
000071e7f4dd1281  movaps [rsp+0x20], xmm2
000071e7f4dd1286  lea rdi, [rsp]
000071e7f4dd128a  mov esi, 0x00
000071e7f4dd128f  mov rax, 0x562A51E82530
000071e7f4dd1299  call rax
000071e7f4dd129b  movaps xmm1, [rsp]
000071e7f4dd129f  add rsp, 0x30
000071e7f4dd12a3  vmovaps xmm0, [rsp]
000071e7f4dd12a8  vmovaps xmm2, [rsp+0x10]
000071e7f4dd12ae  vmovaps xmm3, [rsp+0x20]
000071e7f4dd12b4  vmovaps xmm4, [rsp+0x30]
000071e7f4dd12ba  vmovaps xmm5, [rsp+0x40]
000071e7f4dd12c0  vmovaps xmm6, [rsp+0x50]
000071e7f4dd12c6  vmovaps xmm7, [rsp+0x60]
000071e7f4dd12cc  vmovaps xmm8, [rsp+0x70]
000071e7f4dd12d2  vmovaps xmm9, [rsp+0x80]
000071e7f4dd12db  vmovaps xmm10, [rsp+0x90]
000071e7f4dd12e4  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd12ed  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd12f6  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd12ff  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd1308  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd1311  add rsp, 0xF0
000071e7f4dd1318  pop r11
000071e7f4dd131a  pop r10
000071e7f4dd131c  pop r9
000071e7f4dd131e  pop r8
000071e7f4dd1320  pop rsi
000071e7f4dd1321  pop rdi
000071e7f4dd1322  pop rdx
000071e7f4dd1323  pop rcx
000071e7f4dd1324  pop rax
000071e7f4dd1325  add rsp, 0x08
000071e7f4dd1329  jmp 0x000071E7F4DCF82C
000071e7f4dd132e  call 0x000071E7F4C0E760
000071e7f4dd1333  jmp 0x000071E7F4DCF839
000071e7f4dd1338  sub rsp, 0x08
000071e7f4dd133c  push rax
000071e7f4dd133d  push rcx
000071e7f4dd133e  push rdx
000071e7f4dd133f  push rdi
000071e7f4dd1340  push rsi
000071e7f4dd1341  push r8
000071e7f4dd1343  push r9
000071e7f4dd1345  push r10
000071e7f4dd1347  push r11
000071e7f4dd1349  sub rsp, 0xF0
000071e7f4dd1350  vmovaps [rsp], xmm0
000071e7f4dd1355  vmovaps [rsp+0x10], xmm1
000071e7f4dd135b  vmovaps [rsp+0x20], xmm2
000071e7f4dd1361  vmovaps [rsp+0x30], xmm3
000071e7f4dd1367  vmovaps [rsp+0x40], xmm4
000071e7f4dd136d  vmovaps [rsp+0x50], xmm5
000071e7f4dd1373  vmovaps [rsp+0x60], xmm6
000071e7f4dd1379  vmovaps [rsp+0x70], xmm7
000071e7f4dd137f  vmovaps [rsp+0x80], xmm8
000071e7f4dd1388  vmovaps [rsp+0x90], xmm9
000071e7f4dd1391  vmovaps [rsp+0xA0], xmm10
000071e7f4dd139a  vmovaps [rsp+0xB0], xmm11
000071e7f4dd13a3  vmovaps [rsp+0xC0], xmm12
000071e7f4dd13ac  vmovaps [rsp+0xD0], xmm14
000071e7f4dd13b5  vmovaps [rsp+0xE0], xmm15
000071e7f4dd13be  sub rsp, 0x30
000071e7f4dd13c2  movaps [rsp], xmm13
000071e7f4dd13c7  movaps [rsp+0x10], xmm2
000071e7f4dd13cc  movaps [rsp+0x20], xmm1
000071e7f4dd13d1  lea rdi, [rsp]
000071e7f4dd13d5  mov esi, 0x00
000071e7f4dd13da  mov rax, 0x562A51E82530
000071e7f4dd13e4  call rax
000071e7f4dd13e6  movaps xmm13, [rsp]
000071e7f4dd13eb  add rsp, 0x30
000071e7f4dd13ef  vmovaps xmm0, [rsp]
000071e7f4dd13f4  vmovaps xmm1, [rsp+0x10]
000071e7f4dd13fa  vmovaps xmm2, [rsp+0x20]
000071e7f4dd1400  vmovaps xmm3, [rsp+0x30]
000071e7f4dd1406  vmovaps xmm4, [rsp+0x40]
000071e7f4dd140c  vmovaps xmm5, [rsp+0x50]
000071e7f4dd1412  vmovaps xmm6, [rsp+0x60]
000071e7f4dd1418  vmovaps xmm7, [rsp+0x70]
000071e7f4dd141e  vmovaps xmm8, [rsp+0x80]
000071e7f4dd1427  vmovaps xmm9, [rsp+0x90]
000071e7f4dd1430  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd1439  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd1442  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd144b  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd1454  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd145d  add rsp, 0xF0
000071e7f4dd1464  pop r11
000071e7f4dd1466  pop r10
000071e7f4dd1468  pop r9
000071e7f4dd146a  pop r8
000071e7f4dd146c  pop rsi
000071e7f4dd146d  pop rdi
000071e7f4dd146e  pop rdx
000071e7f4dd146f  pop rcx
000071e7f4dd1470  pop rax
000071e7f4dd1471  add rsp, 0x08
000071e7f4dd1475  jmp 0x000071E7F4DCF878
000071e7f4dd147a  sub rsp, 0x08
000071e7f4dd147e  push rax
000071e7f4dd147f  push rcx
000071e7f4dd1480  push rdx
000071e7f4dd1481  push rdi
000071e7f4dd1482  push rsi
000071e7f4dd1483  push r8
000071e7f4dd1485  push r9
000071e7f4dd1487  push r10
000071e7f4dd1489  push r11
000071e7f4dd148b  sub rsp, 0xF0
000071e7f4dd1492  vmovaps [rsp], xmm0
000071e7f4dd1497  vmovaps [rsp+0x10], xmm2
000071e7f4dd149d  vmovaps [rsp+0x20], xmm3
000071e7f4dd14a3  vmovaps [rsp+0x30], xmm4
000071e7f4dd14a9  vmovaps [rsp+0x40], xmm5
000071e7f4dd14af  vmovaps [rsp+0x50], xmm6
000071e7f4dd14b5  vmovaps [rsp+0x60], xmm7
000071e7f4dd14bb  vmovaps [rsp+0x70], xmm8
000071e7f4dd14c1  vmovaps [rsp+0x80], xmm9
000071e7f4dd14ca  vmovaps [rsp+0x90], xmm10
000071e7f4dd14d3  vmovaps [rsp+0xA0], xmm11
000071e7f4dd14dc  vmovaps [rsp+0xB0], xmm12
000071e7f4dd14e5  vmovaps [rsp+0xC0], xmm13
000071e7f4dd14ee  vmovaps [rsp+0xD0], xmm14
000071e7f4dd14f7  vmovaps [rsp+0xE0], xmm15
000071e7f4dd1500  sub rsp, 0x30
000071e7f4dd1504  movaps [rsp], xmm1
000071e7f4dd1508  movaps [rsp+0x10], xmm15
000071e7f4dd150e  movaps [rsp+0x20], xmm2
000071e7f4dd1513  lea rdi, [rsp]
000071e7f4dd1517  mov esi, 0x00
000071e7f4dd151c  mov rax, 0x562A51E82530
000071e7f4dd1526  call rax
000071e7f4dd1528  movaps xmm1, [rsp]
000071e7f4dd152c  add rsp, 0x30
000071e7f4dd1530  vmovaps xmm0, [rsp]
000071e7f4dd1535  vmovaps xmm2, [rsp+0x10]
000071e7f4dd153b  vmovaps xmm3, [rsp+0x20]
000071e7f4dd1541  vmovaps xmm4, [rsp+0x30]
000071e7f4dd1547  vmovaps xmm5, [rsp+0x40]
000071e7f4dd154d  vmovaps xmm6, [rsp+0x50]
000071e7f4dd1553  vmovaps xmm7, [rsp+0x60]
000071e7f4dd1559  vmovaps xmm8, [rsp+0x70]
000071e7f4dd155f  vmovaps xmm9, [rsp+0x80]
000071e7f4dd1568  vmovaps xmm10, [rsp+0x90]
000071e7f4dd1571  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd157a  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd1583  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd158c  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd1595  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd159e  add rsp, 0xF0
000071e7f4dd15a5  pop r11
000071e7f4dd15a7  pop r10
000071e7f4dd15a9  pop r9
000071e7f4dd15ab  pop r8
000071e7f4dd15ad  pop rsi
000071e7f4dd15ae  pop rdi
000071e7f4dd15af  pop rdx
000071e7f4dd15b0  pop rcx
000071e7f4dd15b1  pop rax
000071e7f4dd15b2  add rsp, 0x08
000071e7f4dd15b6  jmp 0x000071E7F4DCF8AC
000071e7f4dd15bb  sub rsp, 0x08
000071e7f4dd15bf  push rax
000071e7f4dd15c0  push rcx
000071e7f4dd15c1  push rdx
000071e7f4dd15c2  push rdi
000071e7f4dd15c3  push rsi
000071e7f4dd15c4  push r8
000071e7f4dd15c6  push r9
000071e7f4dd15c8  push r10
000071e7f4dd15ca  push r11
000071e7f4dd15cc  sub rsp, 0xF0
000071e7f4dd15d3  vmovaps [rsp], xmm0
000071e7f4dd15d8  vmovaps [rsp+0x10], xmm1
000071e7f4dd15de  vmovaps [rsp+0x20], xmm2
000071e7f4dd15e4  vmovaps [rsp+0x30], xmm3
000071e7f4dd15ea  vmovaps [rsp+0x40], xmm4
000071e7f4dd15f0  vmovaps [rsp+0x50], xmm5
000071e7f4dd15f6  vmovaps [rsp+0x60], xmm6
000071e7f4dd15fc  vmovaps [rsp+0x70], xmm7
000071e7f4dd1602  vmovaps [rsp+0x80], xmm8
000071e7f4dd160b  vmovaps [rsp+0x90], xmm9
000071e7f4dd1614  vmovaps [rsp+0xA0], xmm10
000071e7f4dd161d  vmovaps [rsp+0xB0], xmm11
000071e7f4dd1626  vmovaps [rsp+0xC0], xmm12
000071e7f4dd162f  vmovaps [rsp+0xD0], xmm13
000071e7f4dd1638  vmovaps [rsp+0xE0], xmm15
000071e7f4dd1641  sub rsp, 0x30
000071e7f4dd1645  movaps [rsp], xmm14
000071e7f4dd164a  movaps [rsp+0x10], xmm2
000071e7f4dd164f  movaps [rsp+0x20], xmm15
000071e7f4dd1655  lea rdi, [rsp]
000071e7f4dd1659  mov esi, 0x00
000071e7f4dd165e  mov rax, 0x562A51E82530
000071e7f4dd1668  call rax
000071e7f4dd166a  movaps xmm14, [rsp]
000071e7f4dd166f  add rsp, 0x30
000071e7f4dd1673  vmovaps xmm0, [rsp]
000071e7f4dd1678  vmovaps xmm1, [rsp+0x10]
000071e7f4dd167e  vmovaps xmm2, [rsp+0x20]
000071e7f4dd1684  vmovaps xmm3, [rsp+0x30]
000071e7f4dd168a  vmovaps xmm4, [rsp+0x40]
000071e7f4dd1690  vmovaps xmm5, [rsp+0x50]
000071e7f4dd1696  vmovaps xmm6, [rsp+0x60]
000071e7f4dd169c  vmovaps xmm7, [rsp+0x70]
000071e7f4dd16a2  vmovaps xmm8, [rsp+0x80]
000071e7f4dd16ab  vmovaps xmm9, [rsp+0x90]
000071e7f4dd16b4  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd16bd  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd16c6  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd16cf  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd16d8  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd16e1  add rsp, 0xF0
000071e7f4dd16e8  pop r11
000071e7f4dd16ea  pop r10
000071e7f4dd16ec  pop r9
000071e7f4dd16ee  pop r8
000071e7f4dd16f0  pop rsi
000071e7f4dd16f1  pop rdi
000071e7f4dd16f2  pop rdx
000071e7f4dd16f3  pop rcx
000071e7f4dd16f4  pop rax
000071e7f4dd16f5  add rsp, 0x08
000071e7f4dd16f9  jmp 0x000071E7F4DCF8E7
000071e7f4dd16fe  sub rsp, 0x08
000071e7f4dd1702  push rax
000071e7f4dd1703  push rcx
000071e7f4dd1704  push rdx
000071e7f4dd1705  push rdi
000071e7f4dd1706  push rsi
000071e7f4dd1707  push r8
000071e7f4dd1709  push r9
000071e7f4dd170b  push r10
000071e7f4dd170d  push r11
000071e7f4dd170f  sub rsp, 0xF0
000071e7f4dd1716  vmovaps [rsp], xmm0
000071e7f4dd171b  vmovaps [rsp+0x10], xmm1
000071e7f4dd1721  vmovaps [rsp+0x20], xmm2
000071e7f4dd1727  vmovaps [rsp+0x30], xmm3
000071e7f4dd172d  vmovaps [rsp+0x40], xmm4
000071e7f4dd1733  vmovaps [rsp+0x50], xmm5
000071e7f4dd1739  vmovaps [rsp+0x60], xmm6
000071e7f4dd173f  vmovaps [rsp+0x70], xmm7
000071e7f4dd1745  vmovaps [rsp+0x80], xmm8
000071e7f4dd174e  vmovaps [rsp+0x90], xmm9
000071e7f4dd1757  vmovaps [rsp+0xA0], xmm10
000071e7f4dd1760  vmovaps [rsp+0xB0], xmm11
000071e7f4dd1769  vmovaps [rsp+0xC0], xmm12
000071e7f4dd1772  vmovaps [rsp+0xD0], xmm13
000071e7f4dd177b  vmovaps [rsp+0xE0], xmm14
000071e7f4dd1784  sub rsp, 0x30
000071e7f4dd1788  movaps [rsp], xmm15
000071e7f4dd178d  movaps [rsp+0x10], xmm2
000071e7f4dd1792  movaps [rsp+0x20], xmm1
000071e7f4dd1797  lea rdi, [rsp]
000071e7f4dd179b  mov esi, 0x00
000071e7f4dd17a0  mov rax, 0x562A51E82530
000071e7f4dd17aa  call rax
000071e7f4dd17ac  movaps xmm15, [rsp]
000071e7f4dd17b1  add rsp, 0x30
000071e7f4dd17b5  vmovaps xmm0, [rsp]
000071e7f4dd17ba  vmovaps xmm1, [rsp+0x10]
000071e7f4dd17c0  vmovaps xmm2, [rsp+0x20]
000071e7f4dd17c6  vmovaps xmm3, [rsp+0x30]
000071e7f4dd17cc  vmovaps xmm4, [rsp+0x40]
000071e7f4dd17d2  vmovaps xmm5, [rsp+0x50]
000071e7f4dd17d8  vmovaps xmm6, [rsp+0x60]
000071e7f4dd17de  vmovaps xmm7, [rsp+0x70]
000071e7f4dd17e4  vmovaps xmm8, [rsp+0x80]
000071e7f4dd17ed  vmovaps xmm9, [rsp+0x90]
000071e7f4dd17f6  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd17ff  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd1808  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd1811  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd181a  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd1823  add rsp, 0xF0
000071e7f4dd182a  pop r11
000071e7f4dd182c  pop r10
000071e7f4dd182e  pop r9
000071e7f4dd1830  pop r8
000071e7f4dd1832  pop rsi
000071e7f4dd1833  pop rdi
000071e7f4dd1834  pop rdx
000071e7f4dd1835  pop rcx
000071e7f4dd1836  pop rax
000071e7f4dd1837  add rsp, 0x08
000071e7f4dd183b  jmp 0x000071E7F4DCF923
000071e7f4dd1840  call 0x000071E7F4BFF430
000071e7f4dd1845  jmp 0x000071E7F4DCF930
000071e7f4dd184a  sub rsp, 0x08
000071e7f4dd184e  push rax
000071e7f4dd184f  push rcx
000071e7f4dd1850  push rdx
000071e7f4dd1851  push rdi
000071e7f4dd1852  push rsi
000071e7f4dd1853  push r8
000071e7f4dd1855  push r9
000071e7f4dd1857  push r10
000071e7f4dd1859  push r11
000071e7f4dd185b  sub rsp, 0xF0
000071e7f4dd1862  vmovaps [rsp], xmm0
000071e7f4dd1867  vmovaps [rsp+0x10], xmm1
000071e7f4dd186d  vmovaps [rsp+0x20], xmm3
000071e7f4dd1873  vmovaps [rsp+0x30], xmm4
000071e7f4dd1879  vmovaps [rsp+0x40], xmm5
000071e7f4dd187f  vmovaps [rsp+0x50], xmm6
000071e7f4dd1885  vmovaps [rsp+0x60], xmm7
000071e7f4dd188b  vmovaps [rsp+0x70], xmm8
000071e7f4dd1891  vmovaps [rsp+0x80], xmm9
000071e7f4dd189a  vmovaps [rsp+0x90], xmm10
000071e7f4dd18a3  vmovaps [rsp+0xA0], xmm11
000071e7f4dd18ac  vmovaps [rsp+0xB0], xmm12
000071e7f4dd18b5  vmovaps [rsp+0xC0], xmm13
000071e7f4dd18be  vmovaps [rsp+0xD0], xmm14
000071e7f4dd18c7  vmovaps [rsp+0xE0], xmm15
000071e7f4dd18d0  sub rsp, 0x30
000071e7f4dd18d4  movaps [rsp], xmm2
000071e7f4dd18d8  movaps [rsp+0x10], xmm1
000071e7f4dd18dd  movaps [rsp+0x20], xmm14
000071e7f4dd18e3  lea rdi, [rsp]
000071e7f4dd18e7  mov esi, 0x00
000071e7f4dd18ec  mov rax, 0x562A51E82530
000071e7f4dd18f6  call rax
000071e7f4dd18f8  movaps xmm2, [rsp]
000071e7f4dd18fc  add rsp, 0x30
000071e7f4dd1900  vmovaps xmm0, [rsp]
000071e7f4dd1905  vmovaps xmm1, [rsp+0x10]
000071e7f4dd190b  vmovaps xmm3, [rsp+0x20]
000071e7f4dd1911  vmovaps xmm4, [rsp+0x30]
000071e7f4dd1917  vmovaps xmm5, [rsp+0x40]
000071e7f4dd191d  vmovaps xmm6, [rsp+0x50]
000071e7f4dd1923  vmovaps xmm7, [rsp+0x60]
000071e7f4dd1929  vmovaps xmm8, [rsp+0x70]
000071e7f4dd192f  vmovaps xmm9, [rsp+0x80]
000071e7f4dd1938  vmovaps xmm10, [rsp+0x90]
000071e7f4dd1941  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd194a  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd1953  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd195c  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd1965  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd196e  add rsp, 0xF0
000071e7f4dd1975  pop r11
000071e7f4dd1977  pop r10
000071e7f4dd1979  pop r9
000071e7f4dd197b  pop r8
000071e7f4dd197d  pop rsi
000071e7f4dd197e  pop rdi
000071e7f4dd197f  pop rdx
000071e7f4dd1980  pop rcx
000071e7f4dd1981  pop rax
000071e7f4dd1982  add rsp, 0x08
000071e7f4dd1986  jmp 0x000071E7F4DCF96D
000071e7f4dd198b  sub rsp, 0x08
000071e7f4dd198f  push rax
000071e7f4dd1990  push rcx
000071e7f4dd1991  push rdx
000071e7f4dd1992  push rdi
000071e7f4dd1993  push rsi
000071e7f4dd1994  push r8
000071e7f4dd1996  push r9
000071e7f4dd1998  push r10
000071e7f4dd199a  push r11
000071e7f4dd199c  sub rsp, 0xF0
000071e7f4dd19a3  vmovaps [rsp], xmm0
000071e7f4dd19a8  vmovaps [rsp+0x10], xmm1
000071e7f4dd19ae  vmovaps [rsp+0x20], xmm2
000071e7f4dd19b4  vmovaps [rsp+0x30], xmm3
000071e7f4dd19ba  vmovaps [rsp+0x40], xmm4
000071e7f4dd19c0  vmovaps [rsp+0x50], xmm5
000071e7f4dd19c6  vmovaps [rsp+0x60], xmm6
000071e7f4dd19cc  vmovaps [rsp+0x70], xmm7
000071e7f4dd19d2  vmovaps [rsp+0x80], xmm8
000071e7f4dd19db  vmovaps [rsp+0x90], xmm9
000071e7f4dd19e4  vmovaps [rsp+0xA0], xmm10
000071e7f4dd19ed  vmovaps [rsp+0xB0], xmm11
000071e7f4dd19f6  vmovaps [rsp+0xC0], xmm12
000071e7f4dd19ff  vmovaps [rsp+0xD0], xmm13
000071e7f4dd1a08  vmovaps [rsp+0xE0], xmm14
000071e7f4dd1a11  sub rsp, 0x30
000071e7f4dd1a15  movaps [rsp], xmm15
000071e7f4dd1a1a  movaps [rsp+0x10], xmm14
000071e7f4dd1a20  movaps [rsp+0x20], xmm1
000071e7f4dd1a25  lea rdi, [rsp]
000071e7f4dd1a29  mov esi, 0x00
000071e7f4dd1a2e  mov rax, 0x562A51E82530
000071e7f4dd1a38  call rax
000071e7f4dd1a3a  movaps xmm15, [rsp]
000071e7f4dd1a3f  add rsp, 0x30
000071e7f4dd1a43  vmovaps xmm0, [rsp]
000071e7f4dd1a48  vmovaps xmm1, [rsp+0x10]
000071e7f4dd1a4e  vmovaps xmm2, [rsp+0x20]
000071e7f4dd1a54  vmovaps xmm3, [rsp+0x30]
000071e7f4dd1a5a  vmovaps xmm4, [rsp+0x40]
000071e7f4dd1a60  vmovaps xmm5, [rsp+0x50]
000071e7f4dd1a66  vmovaps xmm6, [rsp+0x60]
000071e7f4dd1a6c  vmovaps xmm7, [rsp+0x70]
000071e7f4dd1a72  vmovaps xmm8, [rsp+0x80]
000071e7f4dd1a7b  vmovaps xmm9, [rsp+0x90]
000071e7f4dd1a84  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd1a8d  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd1a96  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd1a9f  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd1aa8  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd1ab1  add rsp, 0xF0
000071e7f4dd1ab8  pop r11
000071e7f4dd1aba  pop r10
000071e7f4dd1abc  pop r9
000071e7f4dd1abe  pop r8
000071e7f4dd1ac0  pop rsi
000071e7f4dd1ac1  pop rdi
000071e7f4dd1ac2  pop rdx
000071e7f4dd1ac3  pop rcx
000071e7f4dd1ac4  pop rax
000071e7f4dd1ac5  add rsp, 0x08
000071e7f4dd1ac9  jmp 0x000071E7F4DCF9E7
000071e7f4dd1ace  call 0x000071E7F4BFF430
000071e7f4dd1ad3  jmp 0x000071E7F4DCF9F4
000071e7f4dd1ad8  sub rsp, 0x08
000071e7f4dd1adc  push rax
000071e7f4dd1add  push rcx
000071e7f4dd1ade  push rdx
000071e7f4dd1adf  push rdi
000071e7f4dd1ae0  push rsi
000071e7f4dd1ae1  push r8
000071e7f4dd1ae3  push r9
000071e7f4dd1ae5  push r10
000071e7f4dd1ae7  push r11
000071e7f4dd1ae9  sub rsp, 0xF0
000071e7f4dd1af0  vmovaps [rsp], xmm0
000071e7f4dd1af5  vmovaps [rsp+0x10], xmm1
000071e7f4dd1afb  vmovaps [rsp+0x20], xmm2
000071e7f4dd1b01  vmovaps [rsp+0x30], xmm3
000071e7f4dd1b07  vmovaps [rsp+0x40], xmm4
000071e7f4dd1b0d  vmovaps [rsp+0x50], xmm5
000071e7f4dd1b13  vmovaps [rsp+0x60], xmm6
000071e7f4dd1b19  vmovaps [rsp+0x70], xmm7
000071e7f4dd1b1f  vmovaps [rsp+0x80], xmm8
000071e7f4dd1b28  vmovaps [rsp+0x90], xmm9
000071e7f4dd1b31  vmovaps [rsp+0xA0], xmm10
000071e7f4dd1b3a  vmovaps [rsp+0xB0], xmm11
000071e7f4dd1b43  vmovaps [rsp+0xC0], xmm12
000071e7f4dd1b4c  vmovaps [rsp+0xD0], xmm13
000071e7f4dd1b55  vmovaps [rsp+0xE0], xmm15
000071e7f4dd1b5e  sub rsp, 0x30
000071e7f4dd1b62  movaps [rsp], xmm14
000071e7f4dd1b67  movaps [rsp+0x10], xmm13
000071e7f4dd1b6d  movaps [rsp+0x20], xmm1
000071e7f4dd1b72  lea rdi, [rsp]
000071e7f4dd1b76  mov esi, 0x00
000071e7f4dd1b7b  mov rax, 0x562A51E82530
000071e7f4dd1b85  call rax
000071e7f4dd1b87  movaps xmm14, [rsp]
000071e7f4dd1b8c  add rsp, 0x30
000071e7f4dd1b90  vmovaps xmm0, [rsp]
000071e7f4dd1b95  vmovaps xmm1, [rsp+0x10]
000071e7f4dd1b9b  vmovaps xmm2, [rsp+0x20]
000071e7f4dd1ba1  vmovaps xmm3, [rsp+0x30]
000071e7f4dd1ba7  vmovaps xmm4, [rsp+0x40]
000071e7f4dd1bad  vmovaps xmm5, [rsp+0x50]
000071e7f4dd1bb3  vmovaps xmm6, [rsp+0x60]
000071e7f4dd1bb9  vmovaps xmm7, [rsp+0x70]
000071e7f4dd1bbf  vmovaps xmm8, [rsp+0x80]
000071e7f4dd1bc8  vmovaps xmm9, [rsp+0x90]
000071e7f4dd1bd1  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd1bda  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd1be3  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd1bec  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd1bf5  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd1bfe  add rsp, 0xF0
000071e7f4dd1c05  pop r11
000071e7f4dd1c07  pop r10
000071e7f4dd1c09  pop r9
000071e7f4dd1c0b  pop r8
000071e7f4dd1c0d  pop rsi
000071e7f4dd1c0e  pop rdi
000071e7f4dd1c0f  pop rdx
000071e7f4dd1c10  pop rcx
000071e7f4dd1c11  pop rax
000071e7f4dd1c12  add rsp, 0x08
000071e7f4dd1c16  jmp 0x000071E7F4DCFAAF
000071e7f4dd1c1b  sub rsp, 0x08
000071e7f4dd1c1f  push rax
000071e7f4dd1c20  push rcx
000071e7f4dd1c21  push rdx
000071e7f4dd1c22  push rdi
000071e7f4dd1c23  push rsi
000071e7f4dd1c24  push r8
000071e7f4dd1c26  push r9
000071e7f4dd1c28  push r10
000071e7f4dd1c2a  push r11
000071e7f4dd1c2c  sub rsp, 0xF0
000071e7f4dd1c33  vmovaps [rsp], xmm0
000071e7f4dd1c38  vmovaps [rsp+0x10], xmm1
000071e7f4dd1c3e  vmovaps [rsp+0x20], xmm2
000071e7f4dd1c44  vmovaps [rsp+0x30], xmm3
000071e7f4dd1c4a  vmovaps [rsp+0x40], xmm4
000071e7f4dd1c50  vmovaps [rsp+0x50], xmm5
000071e7f4dd1c56  vmovaps [rsp+0x60], xmm6
000071e7f4dd1c5c  vmovaps [rsp+0x70], xmm7
000071e7f4dd1c62  vmovaps [rsp+0x80], xmm8
000071e7f4dd1c6b  vmovaps [rsp+0x90], xmm9
000071e7f4dd1c74  vmovaps [rsp+0xA0], xmm10
000071e7f4dd1c7d  vmovaps [rsp+0xB0], xmm11
000071e7f4dd1c86  vmovaps [rsp+0xC0], xmm12
000071e7f4dd1c8f  vmovaps [rsp+0xD0], xmm13
000071e7f4dd1c98  vmovaps [rsp+0xE0], xmm14
000071e7f4dd1ca1  sub rsp, 0x30
000071e7f4dd1ca5  movaps [rsp], xmm15
000071e7f4dd1caa  movaps [rsp+0x10], xmm13
000071e7f4dd1cb0  movaps [rsp+0x20], xmm1
000071e7f4dd1cb5  lea rdi, [rsp]
000071e7f4dd1cb9  mov esi, 0x00
000071e7f4dd1cbe  mov rax, 0x562A51E82530
000071e7f4dd1cc8  call rax
000071e7f4dd1cca  movaps xmm15, [rsp]
000071e7f4dd1ccf  add rsp, 0x30
000071e7f4dd1cd3  vmovaps xmm0, [rsp]
000071e7f4dd1cd8  vmovaps xmm1, [rsp+0x10]
000071e7f4dd1cde  vmovaps xmm2, [rsp+0x20]
000071e7f4dd1ce4  vmovaps xmm3, [rsp+0x30]
000071e7f4dd1cea  vmovaps xmm4, [rsp+0x40]
000071e7f4dd1cf0  vmovaps xmm5, [rsp+0x50]
000071e7f4dd1cf6  vmovaps xmm6, [rsp+0x60]
000071e7f4dd1cfc  vmovaps xmm7, [rsp+0x70]
000071e7f4dd1d02  vmovaps xmm8, [rsp+0x80]
000071e7f4dd1d0b  vmovaps xmm9, [rsp+0x90]
000071e7f4dd1d14  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd1d1d  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd1d26  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd1d2f  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd1d38  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd1d41  add rsp, 0xF0
000071e7f4dd1d48  pop r11
000071e7f4dd1d4a  pop r10
000071e7f4dd1d4c  pop r9
000071e7f4dd1d4e  pop r8
000071e7f4dd1d50  pop rsi
000071e7f4dd1d51  pop rdi
000071e7f4dd1d52  pop rdx
000071e7f4dd1d53  pop rcx
000071e7f4dd1d54  pop rax
000071e7f4dd1d55  add rsp, 0x08
000071e7f4dd1d59  jmp 0x000071E7F4DCFAEB
000071e7f4dd1d5e  call 0x000071E7F4BFF430
000071e7f4dd1d63  jmp 0x000071E7F4DCFAF8
000071e7f4dd1d68  sub rsp, 0x08
000071e7f4dd1d6c  push rax
000071e7f4dd1d6d  push rcx
000071e7f4dd1d6e  push rdx
000071e7f4dd1d6f  push rdi
000071e7f4dd1d70  push rsi
000071e7f4dd1d71  push r8
000071e7f4dd1d73  push r9
000071e7f4dd1d75  push r10
000071e7f4dd1d77  push r11
000071e7f4dd1d79  sub rsp, 0xF0
000071e7f4dd1d80  vmovaps [rsp], xmm0
000071e7f4dd1d85  vmovaps [rsp+0x10], xmm1
000071e7f4dd1d8b  vmovaps [rsp+0x20], xmm2
000071e7f4dd1d91  vmovaps [rsp+0x30], xmm3
000071e7f4dd1d97  vmovaps [rsp+0x40], xmm4
000071e7f4dd1d9d  vmovaps [rsp+0x50], xmm5
000071e7f4dd1da3  vmovaps [rsp+0x60], xmm6
000071e7f4dd1da9  vmovaps [rsp+0x70], xmm7
000071e7f4dd1daf  vmovaps [rsp+0x80], xmm8
000071e7f4dd1db8  vmovaps [rsp+0x90], xmm9
000071e7f4dd1dc1  vmovaps [rsp+0xA0], xmm10
000071e7f4dd1dca  vmovaps [rsp+0xB0], xmm11
000071e7f4dd1dd3  vmovaps [rsp+0xC0], xmm12
000071e7f4dd1ddc  vmovaps [rsp+0xD0], xmm13
000071e7f4dd1de5  vmovaps [rsp+0xE0], xmm15
000071e7f4dd1dee  sub rsp, 0x30
000071e7f4dd1df2  movaps [rsp], xmm14
000071e7f4dd1df7  movaps [rsp+0x10], xmm13
000071e7f4dd1dfd  movaps [rsp+0x20], xmm2
000071e7f4dd1e02  lea rdi, [rsp]
000071e7f4dd1e06  mov esi, 0x00
000071e7f4dd1e0b  mov rax, 0x562A51E82530
000071e7f4dd1e15  call rax
000071e7f4dd1e17  movaps xmm14, [rsp]
000071e7f4dd1e1c  add rsp, 0x30
000071e7f4dd1e20  vmovaps xmm0, [rsp]
000071e7f4dd1e25  vmovaps xmm1, [rsp+0x10]
000071e7f4dd1e2b  vmovaps xmm2, [rsp+0x20]
000071e7f4dd1e31  vmovaps xmm3, [rsp+0x30]
000071e7f4dd1e37  vmovaps xmm4, [rsp+0x40]
000071e7f4dd1e3d  vmovaps xmm5, [rsp+0x50]
000071e7f4dd1e43  vmovaps xmm6, [rsp+0x60]
000071e7f4dd1e49  vmovaps xmm7, [rsp+0x70]
000071e7f4dd1e4f  vmovaps xmm8, [rsp+0x80]
000071e7f4dd1e58  vmovaps xmm9, [rsp+0x90]
000071e7f4dd1e61  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd1e6a  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd1e73  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd1e7c  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd1e85  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd1e8e  add rsp, 0xF0
000071e7f4dd1e95  pop r11
000071e7f4dd1e97  pop r10
000071e7f4dd1e99  pop r9
000071e7f4dd1e9b  pop r8
000071e7f4dd1e9d  pop rsi
000071e7f4dd1e9e  pop rdi
000071e7f4dd1e9f  pop rdx
000071e7f4dd1ea0  pop rcx
000071e7f4dd1ea1  pop rax
000071e7f4dd1ea2  add rsp, 0x08
000071e7f4dd1ea6  jmp 0x000071E7F4DCFB24
000071e7f4dd1eab  sub rsp, 0x08
000071e7f4dd1eaf  push rax
000071e7f4dd1eb0  push rcx
000071e7f4dd1eb1  push rdx
000071e7f4dd1eb2  push rdi
000071e7f4dd1eb3  push rsi
000071e7f4dd1eb4  push r8
000071e7f4dd1eb6  push r9
000071e7f4dd1eb8  push r10
000071e7f4dd1eba  push r11
000071e7f4dd1ebc  sub rsp, 0xF0
000071e7f4dd1ec3  vmovaps [rsp], xmm0
000071e7f4dd1ec8  vmovaps [rsp+0x10], xmm2
000071e7f4dd1ece  vmovaps [rsp+0x20], xmm3
000071e7f4dd1ed4  vmovaps [rsp+0x30], xmm4
000071e7f4dd1eda  vmovaps [rsp+0x40], xmm5
000071e7f4dd1ee0  vmovaps [rsp+0x50], xmm6
000071e7f4dd1ee6  vmovaps [rsp+0x60], xmm7
000071e7f4dd1eec  vmovaps [rsp+0x70], xmm8
000071e7f4dd1ef2  vmovaps [rsp+0x80], xmm9
000071e7f4dd1efb  vmovaps [rsp+0x90], xmm10
000071e7f4dd1f04  vmovaps [rsp+0xA0], xmm11
000071e7f4dd1f0d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd1f16  vmovaps [rsp+0xC0], xmm13
000071e7f4dd1f1f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd1f28  vmovaps [rsp+0xE0], xmm15
000071e7f4dd1f31  sub rsp, 0x30
000071e7f4dd1f35  movaps [rsp], xmm1
000071e7f4dd1f39  movaps [rsp+0x10], xmm13
000071e7f4dd1f3f  movaps [rsp+0x20], xmm2
000071e7f4dd1f44  lea rdi, [rsp]
000071e7f4dd1f48  mov esi, 0x00
000071e7f4dd1f4d  mov rax, 0x562A51E82530
000071e7f4dd1f57  call rax
000071e7f4dd1f59  movaps xmm1, [rsp]
000071e7f4dd1f5d  add rsp, 0x30
000071e7f4dd1f61  vmovaps xmm0, [rsp]
000071e7f4dd1f66  vmovaps xmm2, [rsp+0x10]
000071e7f4dd1f6c  vmovaps xmm3, [rsp+0x20]
000071e7f4dd1f72  vmovaps xmm4, [rsp+0x30]
000071e7f4dd1f78  vmovaps xmm5, [rsp+0x40]
000071e7f4dd1f7e  vmovaps xmm6, [rsp+0x50]
000071e7f4dd1f84  vmovaps xmm7, [rsp+0x60]
000071e7f4dd1f8a  vmovaps xmm8, [rsp+0x70]
000071e7f4dd1f90  vmovaps xmm9, [rsp+0x80]
000071e7f4dd1f99  vmovaps xmm10, [rsp+0x90]
000071e7f4dd1fa2  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd1fab  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd1fb4  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd1fbd  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd1fc6  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd1fcf  add rsp, 0xF0
000071e7f4dd1fd6  pop r11
000071e7f4dd1fd8  pop r10
000071e7f4dd1fda  pop r9
000071e7f4dd1fdc  pop r8
000071e7f4dd1fde  pop rsi
000071e7f4dd1fdf  pop rdi
000071e7f4dd1fe0  pop rdx
000071e7f4dd1fe1  pop rcx
000071e7f4dd1fe2  pop rax
000071e7f4dd1fe3  add rsp, 0x08
000071e7f4dd1fe7  jmp 0x000071E7F4DCFB52
000071e7f4dd1fec  sub rsp, 0x08
000071e7f4dd1ff0  push rax
000071e7f4dd1ff1  push rcx
000071e7f4dd1ff2  push rdx
000071e7f4dd1ff3  push rdi
000071e7f4dd1ff4  push rsi
000071e7f4dd1ff5  push r8
000071e7f4dd1ff7  push r9
000071e7f4dd1ff9  push r10
000071e7f4dd1ffb  push r11
000071e7f4dd1ffd  sub rsp, 0xF0
000071e7f4dd2004  vmovaps [rsp], xmm0
000071e7f4dd2009  vmovaps [rsp+0x10], xmm1
000071e7f4dd200f  vmovaps [rsp+0x20], xmm3
000071e7f4dd2015  vmovaps [rsp+0x30], xmm4
000071e7f4dd201b  vmovaps [rsp+0x40], xmm5
000071e7f4dd2021  vmovaps [rsp+0x50], xmm6
000071e7f4dd2027  vmovaps [rsp+0x60], xmm7
000071e7f4dd202d  vmovaps [rsp+0x70], xmm8
000071e7f4dd2033  vmovaps [rsp+0x80], xmm9
000071e7f4dd203c  vmovaps [rsp+0x90], xmm10
000071e7f4dd2045  vmovaps [rsp+0xA0], xmm11
000071e7f4dd204e  vmovaps [rsp+0xB0], xmm12
000071e7f4dd2057  vmovaps [rsp+0xC0], xmm13
000071e7f4dd2060  vmovaps [rsp+0xD0], xmm14
000071e7f4dd2069  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2072  sub rsp, 0x30
000071e7f4dd2076  movaps [rsp], xmm2
000071e7f4dd207a  movaps [rsp+0x10], xmm1
000071e7f4dd207f  movaps [rsp+0x20], xmm13
000071e7f4dd2085  lea rdi, [rsp]
000071e7f4dd2089  mov esi, 0x00
000071e7f4dd208e  mov rax, 0x562A51E82530
000071e7f4dd2098  call rax
000071e7f4dd209a  movaps xmm2, [rsp]
000071e7f4dd209e  add rsp, 0x30
000071e7f4dd20a2  vmovaps xmm0, [rsp]
000071e7f4dd20a7  vmovaps xmm1, [rsp+0x10]
000071e7f4dd20ad  vmovaps xmm3, [rsp+0x20]
000071e7f4dd20b3  vmovaps xmm4, [rsp+0x30]
000071e7f4dd20b9  vmovaps xmm5, [rsp+0x40]
000071e7f4dd20bf  vmovaps xmm6, [rsp+0x50]
000071e7f4dd20c5  vmovaps xmm7, [rsp+0x60]
000071e7f4dd20cb  vmovaps xmm8, [rsp+0x70]
000071e7f4dd20d1  vmovaps xmm9, [rsp+0x80]
000071e7f4dd20da  vmovaps xmm10, [rsp+0x90]
000071e7f4dd20e3  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd20ec  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd20f5  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd20fe  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd2107  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd2110  add rsp, 0xF0
000071e7f4dd2117  pop r11
000071e7f4dd2119  pop r10
000071e7f4dd211b  pop r9
000071e7f4dd211d  pop r8
000071e7f4dd211f  pop rsi
000071e7f4dd2120  pop rdi
000071e7f4dd2121  pop rdx
000071e7f4dd2122  pop rcx
000071e7f4dd2123  pop rax
000071e7f4dd2124  add rsp, 0x08
000071e7f4dd2128  jmp 0x000071E7F4DCFBAB
000071e7f4dd212d  call 0x000071E7F4BFF430
000071e7f4dd2132  jmp 0x000071E7F4DCFBB8
000071e7f4dd2137  sub rsp, 0x08
000071e7f4dd213b  push rax
000071e7f4dd213c  push rcx
000071e7f4dd213d  push rdx
000071e7f4dd213e  push rdi
000071e7f4dd213f  push rsi
000071e7f4dd2140  push r8
000071e7f4dd2142  push r9
000071e7f4dd2144  push r10
000071e7f4dd2146  push r11
000071e7f4dd2148  sub rsp, 0xF0
000071e7f4dd214f  vmovaps [rsp], xmm0
000071e7f4dd2154  vmovaps [rsp+0x10], xmm1
000071e7f4dd215a  vmovaps [rsp+0x20], xmm2
000071e7f4dd2160  vmovaps [rsp+0x30], xmm3
000071e7f4dd2166  vmovaps [rsp+0x40], xmm4
000071e7f4dd216c  vmovaps [rsp+0x50], xmm5
000071e7f4dd2172  vmovaps [rsp+0x60], xmm6
000071e7f4dd2178  vmovaps [rsp+0x70], xmm7
000071e7f4dd217e  vmovaps [rsp+0x80], xmm8
000071e7f4dd2187  vmovaps [rsp+0x90], xmm9
000071e7f4dd2190  vmovaps [rsp+0xA0], xmm10
000071e7f4dd2199  vmovaps [rsp+0xB0], xmm11
000071e7f4dd21a2  vmovaps [rsp+0xC0], xmm12
000071e7f4dd21ab  vmovaps [rsp+0xD0], xmm13
000071e7f4dd21b4  vmovaps [rsp+0xE0], xmm14
000071e7f4dd21bd  sub rsp, 0x30
000071e7f4dd21c1  movaps [rsp], xmm15
000071e7f4dd21c6  movaps [rsp+0x10], xmm13
000071e7f4dd21cc  movaps [rsp+0x20], xmm1
000071e7f4dd21d1  lea rdi, [rsp]
000071e7f4dd21d5  mov esi, 0x00
000071e7f4dd21da  mov rax, 0x562A51E82530
000071e7f4dd21e4  call rax
000071e7f4dd21e6  movaps xmm15, [rsp]
000071e7f4dd21eb  add rsp, 0x30
000071e7f4dd21ef  vmovaps xmm0, [rsp]
000071e7f4dd21f4  vmovaps xmm1, [rsp+0x10]
000071e7f4dd21fa  vmovaps xmm2, [rsp+0x20]
000071e7f4dd2200  vmovaps xmm3, [rsp+0x30]
000071e7f4dd2206  vmovaps xmm4, [rsp+0x40]
000071e7f4dd220c  vmovaps xmm5, [rsp+0x50]
000071e7f4dd2212  vmovaps xmm6, [rsp+0x60]
000071e7f4dd2218  vmovaps xmm7, [rsp+0x70]
000071e7f4dd221e  vmovaps xmm8, [rsp+0x80]
000071e7f4dd2227  vmovaps xmm9, [rsp+0x90]
000071e7f4dd2230  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd2239  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd2242  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd224b  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd2254  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd225d  add rsp, 0xF0
000071e7f4dd2264  pop r11
000071e7f4dd2266  pop r10
000071e7f4dd2268  pop r9
000071e7f4dd226a  pop r8
000071e7f4dd226c  pop rsi
000071e7f4dd226d  pop rdi
000071e7f4dd226e  pop rdx
000071e7f4dd226f  pop rcx
000071e7f4dd2270  pop rax
000071e7f4dd2271  add rsp, 0x08
000071e7f4dd2275  jmp 0x000071E7F4DCFBF7
000071e7f4dd227a  sub rsp, 0x08
000071e7f4dd227e  push rax
000071e7f4dd227f  push rcx
000071e7f4dd2280  push rdx
000071e7f4dd2281  push rdi
000071e7f4dd2282  push rsi
000071e7f4dd2283  push r8
000071e7f4dd2285  push r9
000071e7f4dd2287  push r10
000071e7f4dd2289  push r11
000071e7f4dd228b  sub rsp, 0xF0
000071e7f4dd2292  vmovaps [rsp], xmm0
000071e7f4dd2297  vmovaps [rsp+0x10], xmm1
000071e7f4dd229d  vmovaps [rsp+0x20], xmm2
000071e7f4dd22a3  vmovaps [rsp+0x30], xmm3
000071e7f4dd22a9  vmovaps [rsp+0x40], xmm4
000071e7f4dd22af  vmovaps [rsp+0x50], xmm5
000071e7f4dd22b5  vmovaps [rsp+0x60], xmm6
000071e7f4dd22bb  vmovaps [rsp+0x70], xmm7
000071e7f4dd22c1  vmovaps [rsp+0x80], xmm8
000071e7f4dd22ca  vmovaps [rsp+0x90], xmm9
000071e7f4dd22d3  vmovaps [rsp+0xA0], xmm10
000071e7f4dd22dc  vmovaps [rsp+0xB0], xmm11
000071e7f4dd22e5  vmovaps [rsp+0xC0], xmm12
000071e7f4dd22ee  vmovaps [rsp+0xD0], xmm13
000071e7f4dd22f7  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2300  sub rsp, 0x30
000071e7f4dd2304  movaps [rsp], xmm14
000071e7f4dd2309  movaps [rsp+0x10], xmm11
000071e7f4dd230f  movaps [rsp+0x20], xmm1
000071e7f4dd2314  lea rdi, [rsp]
000071e7f4dd2318  mov esi, 0x00
000071e7f4dd231d  mov rax, 0x562A51E82530
000071e7f4dd2327  call rax
000071e7f4dd2329  movaps xmm14, [rsp]
000071e7f4dd232e  add rsp, 0x30
000071e7f4dd2332  vmovaps xmm0, [rsp]
000071e7f4dd2337  vmovaps xmm1, [rsp+0x10]
000071e7f4dd233d  vmovaps xmm2, [rsp+0x20]
000071e7f4dd2343  vmovaps xmm3, [rsp+0x30]
000071e7f4dd2349  vmovaps xmm4, [rsp+0x40]
000071e7f4dd234f  vmovaps xmm5, [rsp+0x50]
000071e7f4dd2355  vmovaps xmm6, [rsp+0x60]
000071e7f4dd235b  vmovaps xmm7, [rsp+0x70]
000071e7f4dd2361  vmovaps xmm8, [rsp+0x80]
000071e7f4dd236a  vmovaps xmm9, [rsp+0x90]
000071e7f4dd2373  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd237c  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd2385  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd238e  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd2397  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd23a0  add rsp, 0xF0
000071e7f4dd23a7  pop r11
000071e7f4dd23a9  pop r10
000071e7f4dd23ab  pop r9
000071e7f4dd23ad  pop r8
000071e7f4dd23af  pop rsi
000071e7f4dd23b0  pop rdi
000071e7f4dd23b1  pop rdx
000071e7f4dd23b2  pop rcx
000071e7f4dd23b3  pop rax
000071e7f4dd23b4  add rsp, 0x08
000071e7f4dd23b8  jmp 0x000071E7F4DCFC21
000071e7f4dd23bd  sub rsp, 0x08
000071e7f4dd23c1  push rax
000071e7f4dd23c2  push rcx
000071e7f4dd23c3  push rdx
000071e7f4dd23c4  push rdi
000071e7f4dd23c5  push rsi
000071e7f4dd23c6  push r8
000071e7f4dd23c8  push r9
000071e7f4dd23ca  push r10
000071e7f4dd23cc  push r11
000071e7f4dd23ce  sub rsp, 0xF0
000071e7f4dd23d5  vmovaps [rsp], xmm0
000071e7f4dd23da  vmovaps [rsp+0x10], xmm1
000071e7f4dd23e0  vmovaps [rsp+0x20], xmm2
000071e7f4dd23e6  vmovaps [rsp+0x30], xmm3
000071e7f4dd23ec  vmovaps [rsp+0x40], xmm4
000071e7f4dd23f2  vmovaps [rsp+0x50], xmm5
000071e7f4dd23f8  vmovaps [rsp+0x60], xmm6
000071e7f4dd23fe  vmovaps [rsp+0x70], xmm7
000071e7f4dd2404  vmovaps [rsp+0x80], xmm8
000071e7f4dd240d  vmovaps [rsp+0x90], xmm9
000071e7f4dd2416  vmovaps [rsp+0xA0], xmm10
000071e7f4dd241f  vmovaps [rsp+0xB0], xmm11
000071e7f4dd2428  vmovaps [rsp+0xC0], xmm12
000071e7f4dd2431  vmovaps [rsp+0xD0], xmm14
000071e7f4dd243a  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2443  sub rsp, 0x30
000071e7f4dd2447  movaps [rsp], xmm13
000071e7f4dd244c  movaps [rsp+0x10], xmm11
000071e7f4dd2452  movaps [rsp+0x20], xmm1
000071e7f4dd2457  lea rdi, [rsp]
000071e7f4dd245b  mov esi, 0x00
000071e7f4dd2460  mov rax, 0x562A51E82530
000071e7f4dd246a  call rax
000071e7f4dd246c  movaps xmm13, [rsp]
000071e7f4dd2471  add rsp, 0x30
000071e7f4dd2475  vmovaps xmm0, [rsp]
000071e7f4dd247a  vmovaps xmm1, [rsp+0x10]
000071e7f4dd2480  vmovaps xmm2, [rsp+0x20]
000071e7f4dd2486  vmovaps xmm3, [rsp+0x30]
000071e7f4dd248c  vmovaps xmm4, [rsp+0x40]
000071e7f4dd2492  vmovaps xmm5, [rsp+0x50]
000071e7f4dd2498  vmovaps xmm6, [rsp+0x60]
000071e7f4dd249e  vmovaps xmm7, [rsp+0x70]
000071e7f4dd24a4  vmovaps xmm8, [rsp+0x80]
000071e7f4dd24ad  vmovaps xmm9, [rsp+0x90]
000071e7f4dd24b6  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd24bf  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd24c8  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd24d1  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd24da  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd24e3  add rsp, 0xF0
000071e7f4dd24ea  pop r11
000071e7f4dd24ec  pop r10
000071e7f4dd24ee  pop r9
000071e7f4dd24f0  pop r8
000071e7f4dd24f2  pop rsi
000071e7f4dd24f3  pop rdi
000071e7f4dd24f4  pop rdx
000071e7f4dd24f5  pop rcx
000071e7f4dd24f6  pop rax
000071e7f4dd24f7  add rsp, 0x08
000071e7f4dd24fb  jmp 0x000071E7F4DCFC76
000071e7f4dd2500  call 0x000071E7F4BFF430
000071e7f4dd2505  jmp 0x000071E7F4DCFC83
000071e7f4dd250a  sub rsp, 0x08
000071e7f4dd250e  push rax
000071e7f4dd250f  push rcx
000071e7f4dd2510  push rdx
000071e7f4dd2511  push rdi
000071e7f4dd2512  push rsi
000071e7f4dd2513  push r8
000071e7f4dd2515  push r9
000071e7f4dd2517  push r10
000071e7f4dd2519  push r11
000071e7f4dd251b  sub rsp, 0xF0
000071e7f4dd2522  vmovaps [rsp], xmm0
000071e7f4dd2527  vmovaps [rsp+0x10], xmm1
000071e7f4dd252d  vmovaps [rsp+0x20], xmm2
000071e7f4dd2533  vmovaps [rsp+0x30], xmm3
000071e7f4dd2539  vmovaps [rsp+0x40], xmm4
000071e7f4dd253f  vmovaps [rsp+0x50], xmm5
000071e7f4dd2545  vmovaps [rsp+0x60], xmm6
000071e7f4dd254b  vmovaps [rsp+0x70], xmm7
000071e7f4dd2551  vmovaps [rsp+0x80], xmm8
000071e7f4dd255a  vmovaps [rsp+0x90], xmm9
000071e7f4dd2563  vmovaps [rsp+0xA0], xmm10
000071e7f4dd256c  vmovaps [rsp+0xB0], xmm11
000071e7f4dd2575  vmovaps [rsp+0xC0], xmm12
000071e7f4dd257e  vmovaps [rsp+0xD0], xmm13
000071e7f4dd2587  vmovaps [rsp+0xE0], xmm14
000071e7f4dd2590  sub rsp, 0x30
000071e7f4dd2594  movaps [rsp], xmm15
000071e7f4dd2599  movaps [rsp+0x10], xmm11
000071e7f4dd259f  movaps [rsp+0x20], xmm1
000071e7f4dd25a4  lea rdi, [rsp]
000071e7f4dd25a8  mov esi, 0x00
000071e7f4dd25ad  mov rax, 0x562A51E82530
000071e7f4dd25b7  call rax
000071e7f4dd25b9  movaps xmm15, [rsp]
000071e7f4dd25be  add rsp, 0x30
000071e7f4dd25c2  vmovaps xmm0, [rsp]
000071e7f4dd25c7  vmovaps xmm1, [rsp+0x10]
000071e7f4dd25cd  vmovaps xmm2, [rsp+0x20]
000071e7f4dd25d3  vmovaps xmm3, [rsp+0x30]
000071e7f4dd25d9  vmovaps xmm4, [rsp+0x40]
000071e7f4dd25df  vmovaps xmm5, [rsp+0x50]
000071e7f4dd25e5  vmovaps xmm6, [rsp+0x60]
000071e7f4dd25eb  vmovaps xmm7, [rsp+0x70]
000071e7f4dd25f1  vmovaps xmm8, [rsp+0x80]
000071e7f4dd25fa  vmovaps xmm9, [rsp+0x90]
000071e7f4dd2603  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd260c  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd2615  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd261e  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd2627  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd2630  add rsp, 0xF0
000071e7f4dd2637  pop r11
000071e7f4dd2639  pop r10
000071e7f4dd263b  pop r9
000071e7f4dd263d  pop r8
000071e7f4dd263f  pop rsi
000071e7f4dd2640  pop rdi
000071e7f4dd2641  pop rdx
000071e7f4dd2642  pop rcx
000071e7f4dd2643  pop rax
000071e7f4dd2644  add rsp, 0x08
000071e7f4dd2648  jmp 0x000071E7F4DCFCBC
000071e7f4dd264d  sub rsp, 0x08
000071e7f4dd2651  push rax
000071e7f4dd2652  push rcx
000071e7f4dd2653  push rdx
000071e7f4dd2654  push rdi
000071e7f4dd2655  push rsi
000071e7f4dd2656  push r8
000071e7f4dd2658  push r9
000071e7f4dd265a  push r10
000071e7f4dd265c  push r11
000071e7f4dd265e  sub rsp, 0xF0
000071e7f4dd2665  vmovaps [rsp], xmm0
000071e7f4dd266a  vmovaps [rsp+0x10], xmm1
000071e7f4dd2670  vmovaps [rsp+0x20], xmm2
000071e7f4dd2676  vmovaps [rsp+0x30], xmm3
000071e7f4dd267c  vmovaps [rsp+0x40], xmm4
000071e7f4dd2682  vmovaps [rsp+0x50], xmm5
000071e7f4dd2688  vmovaps [rsp+0x60], xmm6
000071e7f4dd268e  vmovaps [rsp+0x70], xmm7
000071e7f4dd2694  vmovaps [rsp+0x80], xmm8
000071e7f4dd269d  vmovaps [rsp+0x90], xmm9
000071e7f4dd26a6  vmovaps [rsp+0xA0], xmm10
000071e7f4dd26af  vmovaps [rsp+0xB0], xmm12
000071e7f4dd26b8  vmovaps [rsp+0xC0], xmm13
000071e7f4dd26c1  vmovaps [rsp+0xD0], xmm14
000071e7f4dd26ca  vmovaps [rsp+0xE0], xmm15
000071e7f4dd26d3  sub rsp, 0x30
000071e7f4dd26d7  movaps [rsp], xmm11
000071e7f4dd26dc  movaps [rsp+0x10], xmm6
000071e7f4dd26e1  movaps [rsp+0x20], xmm14
000071e7f4dd26e7  lea rdi, [rsp]
000071e7f4dd26eb  mov esi, 0x00
000071e7f4dd26f0  mov rax, 0x562A51E82530
000071e7f4dd26fa  call rax
000071e7f4dd26fc  movaps xmm11, [rsp]
000071e7f4dd2701  add rsp, 0x30
000071e7f4dd2705  vmovaps xmm0, [rsp]
000071e7f4dd270a  vmovaps xmm1, [rsp+0x10]
000071e7f4dd2710  vmovaps xmm2, [rsp+0x20]
000071e7f4dd2716  vmovaps xmm3, [rsp+0x30]
000071e7f4dd271c  vmovaps xmm4, [rsp+0x40]
000071e7f4dd2722  vmovaps xmm5, [rsp+0x50]
000071e7f4dd2728  vmovaps xmm6, [rsp+0x60]
000071e7f4dd272e  vmovaps xmm7, [rsp+0x70]
000071e7f4dd2734  vmovaps xmm8, [rsp+0x80]
000071e7f4dd273d  vmovaps xmm9, [rsp+0x90]
000071e7f4dd2746  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd274f  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd2758  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd2761  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd276a  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd2773  add rsp, 0xF0
000071e7f4dd277a  pop r11
000071e7f4dd277c  pop r10
000071e7f4dd277e  pop r9
000071e7f4dd2780  pop r8
000071e7f4dd2782  pop rsi
000071e7f4dd2783  pop rdi
000071e7f4dd2784  pop rdx
000071e7f4dd2785  pop rcx
000071e7f4dd2786  pop rax
000071e7f4dd2787  add rsp, 0x08
000071e7f4dd278b  jmp 0x000071E7F4DCFD34
000071e7f4dd2790  call 0x000071E7F4BFF430
000071e7f4dd2795  jmp 0x000071E7F4DCFD3E
000071e7f4dd279a  sub rsp, 0x08
000071e7f4dd279e  push rax
000071e7f4dd279f  push rcx
000071e7f4dd27a0  push rdx
000071e7f4dd27a1  push rdi
000071e7f4dd27a2  push rsi
000071e7f4dd27a3  push r8
000071e7f4dd27a5  push r9
000071e7f4dd27a7  push r10
000071e7f4dd27a9  push r11
000071e7f4dd27ab  sub rsp, 0xF0
000071e7f4dd27b2  vmovaps [rsp], xmm0
000071e7f4dd27b7  vmovaps [rsp+0x10], xmm1
000071e7f4dd27bd  vmovaps [rsp+0x20], xmm2
000071e7f4dd27c3  vmovaps [rsp+0x30], xmm3
000071e7f4dd27c9  vmovaps [rsp+0x40], xmm4
000071e7f4dd27cf  vmovaps [rsp+0x50], xmm5
000071e7f4dd27d5  vmovaps [rsp+0x60], xmm6
000071e7f4dd27db  vmovaps [rsp+0x70], xmm7
000071e7f4dd27e1  vmovaps [rsp+0x80], xmm8
000071e7f4dd27ea  vmovaps [rsp+0x90], xmm9
000071e7f4dd27f3  vmovaps [rsp+0xA0], xmm10
000071e7f4dd27fc  vmovaps [rsp+0xB0], xmm11
000071e7f4dd2805  vmovaps [rsp+0xC0], xmm12
000071e7f4dd280e  vmovaps [rsp+0xD0], xmm13
000071e7f4dd2817  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2820  sub rsp, 0x30
000071e7f4dd2824  movaps [rsp], xmm14
000071e7f4dd2829  movaps [rsp+0x10], xmm6
000071e7f4dd282e  movaps [rsp+0x20], xmm2
000071e7f4dd2833  lea rdi, [rsp]
000071e7f4dd2837  mov esi, 0x00
000071e7f4dd283c  mov rax, 0x562A51E82530
000071e7f4dd2846  call rax
000071e7f4dd2848  movaps xmm14, [rsp]
000071e7f4dd284d  add rsp, 0x30
000071e7f4dd2851  vmovaps xmm0, [rsp]
000071e7f4dd2856  vmovaps xmm1, [rsp+0x10]
000071e7f4dd285c  vmovaps xmm2, [rsp+0x20]
000071e7f4dd2862  vmovaps xmm3, [rsp+0x30]
000071e7f4dd2868  vmovaps xmm4, [rsp+0x40]
000071e7f4dd286e  vmovaps xmm5, [rsp+0x50]
000071e7f4dd2874  vmovaps xmm6, [rsp+0x60]
000071e7f4dd287a  vmovaps xmm7, [rsp+0x70]
000071e7f4dd2880  vmovaps xmm8, [rsp+0x80]
000071e7f4dd2889  vmovaps xmm9, [rsp+0x90]
000071e7f4dd2892  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd289b  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd28a4  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd28ad  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd28b6  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd28bf  add rsp, 0xF0
000071e7f4dd28c6  pop r11
000071e7f4dd28c8  pop r10
000071e7f4dd28ca  pop r9
000071e7f4dd28cc  pop r8
000071e7f4dd28ce  pop rsi
000071e7f4dd28cf  pop rdi
000071e7f4dd28d0  pop rdx
000071e7f4dd28d1  pop rcx
000071e7f4dd28d2  pop rax
000071e7f4dd28d3  add rsp, 0x08
000071e7f4dd28d7  jmp 0x000071E7F4DCFD72
000071e7f4dd28dc  sub rsp, 0x08
000071e7f4dd28e0  push rax
000071e7f4dd28e1  push rcx
000071e7f4dd28e2  push rdx
000071e7f4dd28e3  push rdi
000071e7f4dd28e4  push rsi
000071e7f4dd28e5  push r8
000071e7f4dd28e7  push r9
000071e7f4dd28e9  push r10
000071e7f4dd28eb  push r11
000071e7f4dd28ed  sub rsp, 0xF0
000071e7f4dd28f4  vmovaps [rsp], xmm0
000071e7f4dd28f9  vmovaps [rsp+0x10], xmm1
000071e7f4dd28ff  vmovaps [rsp+0x20], xmm2
000071e7f4dd2905  vmovaps [rsp+0x30], xmm3
000071e7f4dd290b  vmovaps [rsp+0x40], xmm4
000071e7f4dd2911  vmovaps [rsp+0x50], xmm5
000071e7f4dd2917  vmovaps [rsp+0x60], xmm7
000071e7f4dd291d  vmovaps [rsp+0x70], xmm8
000071e7f4dd2923  vmovaps [rsp+0x80], xmm9
000071e7f4dd292c  vmovaps [rsp+0x90], xmm10
000071e7f4dd2935  vmovaps [rsp+0xA0], xmm11
000071e7f4dd293e  vmovaps [rsp+0xB0], xmm12
000071e7f4dd2947  vmovaps [rsp+0xC0], xmm13
000071e7f4dd2950  vmovaps [rsp+0xD0], xmm14
000071e7f4dd2959  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2962  sub rsp, 0x30
000071e7f4dd2966  movaps [rsp], xmm6
000071e7f4dd296a  movaps [rsp+0x10], xmm5
000071e7f4dd296f  movaps [rsp+0x20], xmm1
000071e7f4dd2974  lea rdi, [rsp]
000071e7f4dd2978  mov esi, 0x00
000071e7f4dd297d  mov rax, 0x562A51E82530
000071e7f4dd2987  call rax
000071e7f4dd2989  movaps xmm6, [rsp]
000071e7f4dd298d  add rsp, 0x30
000071e7f4dd2991  vmovaps xmm0, [rsp]
000071e7f4dd2996  vmovaps xmm1, [rsp+0x10]
000071e7f4dd299c  vmovaps xmm2, [rsp+0x20]
000071e7f4dd29a2  vmovaps xmm3, [rsp+0x30]
000071e7f4dd29a8  vmovaps xmm4, [rsp+0x40]
000071e7f4dd29ae  vmovaps xmm5, [rsp+0x50]
000071e7f4dd29b4  vmovaps xmm7, [rsp+0x60]
000071e7f4dd29ba  vmovaps xmm8, [rsp+0x70]
000071e7f4dd29c0  vmovaps xmm9, [rsp+0x80]
000071e7f4dd29c9  vmovaps xmm10, [rsp+0x90]
000071e7f4dd29d2  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd29db  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd29e4  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd29ed  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd29f6  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd29ff  add rsp, 0xF0
000071e7f4dd2a06  pop r11
000071e7f4dd2a08  pop r10
000071e7f4dd2a0a  pop r9
000071e7f4dd2a0c  pop r8
000071e7f4dd2a0e  pop rsi
000071e7f4dd2a0f  pop rdi
000071e7f4dd2a10  pop rdx
000071e7f4dd2a11  pop rcx
000071e7f4dd2a12  pop rax
000071e7f4dd2a13  add rsp, 0x08
000071e7f4dd2a17  jmp 0x000071E7F4DCFD98
000071e7f4dd2a1c  sub rsp, 0x08
000071e7f4dd2a20  push rax
000071e7f4dd2a21  push rcx
000071e7f4dd2a22  push rdx
000071e7f4dd2a23  push rdi
000071e7f4dd2a24  push rsi
000071e7f4dd2a25  push r8
000071e7f4dd2a27  push r9
000071e7f4dd2a29  push r10
000071e7f4dd2a2b  push r11
000071e7f4dd2a2d  sub rsp, 0xF0
000071e7f4dd2a34  vmovaps [rsp], xmm0
000071e7f4dd2a39  vmovaps [rsp+0x10], xmm2
000071e7f4dd2a3f  vmovaps [rsp+0x20], xmm3
000071e7f4dd2a45  vmovaps [rsp+0x30], xmm4
000071e7f4dd2a4b  vmovaps [rsp+0x40], xmm5
000071e7f4dd2a51  vmovaps [rsp+0x50], xmm6
000071e7f4dd2a57  vmovaps [rsp+0x60], xmm7
000071e7f4dd2a5d  vmovaps [rsp+0x70], xmm8
000071e7f4dd2a63  vmovaps [rsp+0x80], xmm9
000071e7f4dd2a6c  vmovaps [rsp+0x90], xmm10
000071e7f4dd2a75  vmovaps [rsp+0xA0], xmm11
000071e7f4dd2a7e  vmovaps [rsp+0xB0], xmm12
000071e7f4dd2a87  vmovaps [rsp+0xC0], xmm13
000071e7f4dd2a90  vmovaps [rsp+0xD0], xmm14
000071e7f4dd2a99  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2aa2  sub rsp, 0x30
000071e7f4dd2aa6  movaps [rsp], xmm1
000071e7f4dd2aaa  movaps [rsp+0x10], xmm5
000071e7f4dd2aaf  movaps [rsp+0x20], xmm13
000071e7f4dd2ab5  lea rdi, [rsp]
000071e7f4dd2ab9  mov esi, 0x00
000071e7f4dd2abe  mov rax, 0x562A51E82530
000071e7f4dd2ac8  call rax
000071e7f4dd2aca  movaps xmm1, [rsp]
000071e7f4dd2ace  add rsp, 0x30
000071e7f4dd2ad2  vmovaps xmm0, [rsp]
000071e7f4dd2ad7  vmovaps xmm2, [rsp+0x10]
000071e7f4dd2add  vmovaps xmm3, [rsp+0x20]
000071e7f4dd2ae3  vmovaps xmm4, [rsp+0x30]
000071e7f4dd2ae9  vmovaps xmm5, [rsp+0x40]
000071e7f4dd2aef  vmovaps xmm6, [rsp+0x50]
000071e7f4dd2af5  vmovaps xmm7, [rsp+0x60]
000071e7f4dd2afb  vmovaps xmm8, [rsp+0x70]
000071e7f4dd2b01  vmovaps xmm9, [rsp+0x80]
000071e7f4dd2b0a  vmovaps xmm10, [rsp+0x90]
000071e7f4dd2b13  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd2b1c  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd2b25  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd2b2e  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd2b37  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd2b40  add rsp, 0xF0
000071e7f4dd2b47  pop r11
000071e7f4dd2b49  pop r10
000071e7f4dd2b4b  pop r9
000071e7f4dd2b4d  pop r8
000071e7f4dd2b4f  pop rsi
000071e7f4dd2b50  pop rdi
000071e7f4dd2b51  pop rdx
000071e7f4dd2b52  pop rcx
000071e7f4dd2b53  pop rax
000071e7f4dd2b54  add rsp, 0x08
000071e7f4dd2b58  jmp 0x000071E7F4DCFDB6
000071e7f4dd2b5d  sub rsp, 0x08
000071e7f4dd2b61  push rax
000071e7f4dd2b62  push rcx
000071e7f4dd2b63  push rdx
000071e7f4dd2b64  push rdi
000071e7f4dd2b65  push rsi
000071e7f4dd2b66  push r8
000071e7f4dd2b68  push r9
000071e7f4dd2b6a  push r10
000071e7f4dd2b6c  push r11
000071e7f4dd2b6e  sub rsp, 0xF0
000071e7f4dd2b75  vmovaps [rsp], xmm0
000071e7f4dd2b7a  vmovaps [rsp+0x10], xmm1
000071e7f4dd2b80  vmovaps [rsp+0x20], xmm2
000071e7f4dd2b86  vmovaps [rsp+0x30], xmm3
000071e7f4dd2b8c  vmovaps [rsp+0x40], xmm4
000071e7f4dd2b92  vmovaps [rsp+0x50], xmm6
000071e7f4dd2b98  vmovaps [rsp+0x60], xmm7
000071e7f4dd2b9e  vmovaps [rsp+0x70], xmm8
000071e7f4dd2ba4  vmovaps [rsp+0x80], xmm9
000071e7f4dd2bad  vmovaps [rsp+0x90], xmm10
000071e7f4dd2bb6  vmovaps [rsp+0xA0], xmm11
000071e7f4dd2bbf  vmovaps [rsp+0xB0], xmm12
000071e7f4dd2bc8  vmovaps [rsp+0xC0], xmm13
000071e7f4dd2bd1  vmovaps [rsp+0xD0], xmm14
000071e7f4dd2bda  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2be3  sub rsp, 0x30
000071e7f4dd2be7  movaps [rsp], xmm5
000071e7f4dd2beb  movaps [rsp+0x10], xmm2
000071e7f4dd2bf0  movaps [rsp+0x20], xmm13
000071e7f4dd2bf6  lea rdi, [rsp]
000071e7f4dd2bfa  mov esi, 0x00
000071e7f4dd2bff  mov rax, 0x562A51E82530
000071e7f4dd2c09  call rax
000071e7f4dd2c0b  movaps xmm5, [rsp]
000071e7f4dd2c0f  add rsp, 0x30
000071e7f4dd2c13  vmovaps xmm0, [rsp]
000071e7f4dd2c18  vmovaps xmm1, [rsp+0x10]
000071e7f4dd2c1e  vmovaps xmm2, [rsp+0x20]
000071e7f4dd2c24  vmovaps xmm3, [rsp+0x30]
000071e7f4dd2c2a  vmovaps xmm4, [rsp+0x40]
000071e7f4dd2c30  vmovaps xmm6, [rsp+0x50]
000071e7f4dd2c36  vmovaps xmm7, [rsp+0x60]
000071e7f4dd2c3c  vmovaps xmm8, [rsp+0x70]
000071e7f4dd2c42  vmovaps xmm9, [rsp+0x80]
000071e7f4dd2c4b  vmovaps xmm10, [rsp+0x90]
000071e7f4dd2c54  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd2c5d  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd2c66  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd2c6f  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd2c78  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd2c81  add rsp, 0xF0
000071e7f4dd2c88  pop r11
000071e7f4dd2c8a  pop r10
000071e7f4dd2c8c  pop r9
000071e7f4dd2c8e  pop r8
000071e7f4dd2c90  pop rsi
000071e7f4dd2c91  pop rdi
000071e7f4dd2c92  pop rdx
000071e7f4dd2c93  pop rcx
000071e7f4dd2c94  pop rax
000071e7f4dd2c95  add rsp, 0x08
000071e7f4dd2c99  jmp 0x000071E7F4DCFDEC
000071e7f4dd2c9e  sub rsp, 0x08
000071e7f4dd2ca2  push rax
000071e7f4dd2ca3  push rcx
000071e7f4dd2ca4  push rdx
000071e7f4dd2ca5  push rdi
000071e7f4dd2ca6  push rsi
000071e7f4dd2ca7  push r8
000071e7f4dd2ca9  push r9
000071e7f4dd2cab  push r10
000071e7f4dd2cad  push r11
000071e7f4dd2caf  sub rsp, 0xF0
000071e7f4dd2cb6  vmovaps [rsp], xmm0
000071e7f4dd2cbb  vmovaps [rsp+0x10], xmm1
000071e7f4dd2cc1  vmovaps [rsp+0x20], xmm2
000071e7f4dd2cc7  vmovaps [rsp+0x30], xmm3
000071e7f4dd2ccd  vmovaps [rsp+0x40], xmm4
000071e7f4dd2cd3  vmovaps [rsp+0x50], xmm5
000071e7f4dd2cd9  vmovaps [rsp+0x60], xmm6
000071e7f4dd2cdf  vmovaps [rsp+0x70], xmm7
000071e7f4dd2ce5  vmovaps [rsp+0x80], xmm8
000071e7f4dd2cee  vmovaps [rsp+0x90], xmm9
000071e7f4dd2cf7  vmovaps [rsp+0xA0], xmm10
000071e7f4dd2d00  vmovaps [rsp+0xB0], xmm11
000071e7f4dd2d09  vmovaps [rsp+0xC0], xmm12
000071e7f4dd2d12  vmovaps [rsp+0xD0], xmm14
000071e7f4dd2d1b  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2d24  sub rsp, 0x30
000071e7f4dd2d28  movaps [rsp], xmm13
000071e7f4dd2d2d  movaps [rsp+0x10], xmm10
000071e7f4dd2d33  movaps [rsp+0x20], xmm1
000071e7f4dd2d38  lea rdi, [rsp]
000071e7f4dd2d3c  mov esi, 0x00
000071e7f4dd2d41  mov rax, 0x562A51E82530
000071e7f4dd2d4b  call rax
000071e7f4dd2d4d  movaps xmm13, [rsp]
000071e7f4dd2d52  add rsp, 0x30
000071e7f4dd2d56  vmovaps xmm0, [rsp]
000071e7f4dd2d5b  vmovaps xmm1, [rsp+0x10]
000071e7f4dd2d61  vmovaps xmm2, [rsp+0x20]
000071e7f4dd2d67  vmovaps xmm3, [rsp+0x30]
000071e7f4dd2d6d  vmovaps xmm4, [rsp+0x40]
000071e7f4dd2d73  vmovaps xmm5, [rsp+0x50]
000071e7f4dd2d79  vmovaps xmm6, [rsp+0x60]
000071e7f4dd2d7f  vmovaps xmm7, [rsp+0x70]
000071e7f4dd2d85  vmovaps xmm8, [rsp+0x80]
000071e7f4dd2d8e  vmovaps xmm9, [rsp+0x90]
000071e7f4dd2d97  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd2da0  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd2da9  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd2db2  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd2dbb  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd2dc4  add rsp, 0xF0
000071e7f4dd2dcb  pop r11
000071e7f4dd2dcd  pop r10
000071e7f4dd2dcf  pop r9
000071e7f4dd2dd1  pop r8
000071e7f4dd2dd3  pop rsi
000071e7f4dd2dd4  pop rdi
000071e7f4dd2dd5  pop rdx
000071e7f4dd2dd6  pop rcx
000071e7f4dd2dd7  pop rax
000071e7f4dd2dd8  add rsp, 0x08
000071e7f4dd2ddc  jmp 0x000071E7F4DCFE15
000071e7f4dd2de1  sub rsp, 0x08
000071e7f4dd2de5  push rax
000071e7f4dd2de6  push rcx
000071e7f4dd2de7  push rdx
000071e7f4dd2de8  push rdi
000071e7f4dd2de9  push rsi
000071e7f4dd2dea  push r8
000071e7f4dd2dec  push r9
000071e7f4dd2dee  push r10
000071e7f4dd2df0  push r11
000071e7f4dd2df2  sub rsp, 0xF0
000071e7f4dd2df9  vmovaps [rsp], xmm0
000071e7f4dd2dfe  vmovaps [rsp+0x10], xmm2
000071e7f4dd2e04  vmovaps [rsp+0x20], xmm3
000071e7f4dd2e0a  vmovaps [rsp+0x30], xmm4
000071e7f4dd2e10  vmovaps [rsp+0x40], xmm5
000071e7f4dd2e16  vmovaps [rsp+0x50], xmm6
000071e7f4dd2e1c  vmovaps [rsp+0x60], xmm7
000071e7f4dd2e22  vmovaps [rsp+0x70], xmm8
000071e7f4dd2e28  vmovaps [rsp+0x80], xmm9
000071e7f4dd2e31  vmovaps [rsp+0x90], xmm10
000071e7f4dd2e3a  vmovaps [rsp+0xA0], xmm11
000071e7f4dd2e43  vmovaps [rsp+0xB0], xmm12
000071e7f4dd2e4c  vmovaps [rsp+0xC0], xmm13
000071e7f4dd2e55  vmovaps [rsp+0xD0], xmm14
000071e7f4dd2e5e  vmovaps [rsp+0xE0], xmm15
000071e7f4dd2e67  sub rsp, 0x30
000071e7f4dd2e6b  movaps [rsp], xmm1
000071e7f4dd2e6f  movaps [rsp+0x10], xmm15
000071e7f4dd2e75  movaps [rsp+0x20], xmm10
000071e7f4dd2e7b  lea rdi, [rsp]
000071e7f4dd2e7f  mov esi, 0x00
000071e7f4dd2e84  mov rax, 0x562A51E82530
000071e7f4dd2e8e  call rax
000071e7f4dd2e90  movaps xmm1, [rsp]
000071e7f4dd2e94  add rsp, 0x30
000071e7f4dd2e98  vmovaps xmm0, [rsp]
000071e7f4dd2e9d  vmovaps xmm2, [rsp+0x10]
000071e7f4dd2ea3  vmovaps xmm3, [rsp+0x20]
000071e7f4dd2ea9  vmovaps xmm4, [rsp+0x30]
000071e7f4dd2eaf  vmovaps xmm5, [rsp+0x40]
000071e7f4dd2eb5  vmovaps xmm6, [rsp+0x50]
000071e7f4dd2ebb  vmovaps xmm7, [rsp+0x60]
000071e7f4dd2ec1  vmovaps xmm8, [rsp+0x70]
000071e7f4dd2ec7  vmovaps xmm9, [rsp+0x80]
000071e7f4dd2ed0  vmovaps xmm10, [rsp+0x90]
000071e7f4dd2ed9  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd2ee2  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd2eeb  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd2ef4  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd2efd  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd2f06  add rsp, 0xF0
000071e7f4dd2f0d  pop r11
000071e7f4dd2f0f  pop r10
000071e7f4dd2f11  pop r9
000071e7f4dd2f13  pop r8
000071e7f4dd2f15  pop rsi
000071e7f4dd2f16  pop rdi
000071e7f4dd2f17  pop rdx
000071e7f4dd2f18  pop rcx
000071e7f4dd2f19  pop rax
000071e7f4dd2f1a  add rsp, 0x08
000071e7f4dd2f1e  jmp 0x000071E7F4DCFE34
000071e7f4dd2f23  sub rsp, 0x08
000071e7f4dd2f27  push rax
000071e7f4dd2f28  push rcx
000071e7f4dd2f29  push rdx
000071e7f4dd2f2a  push rdi
000071e7f4dd2f2b  push rsi
000071e7f4dd2f2c  push r8
000071e7f4dd2f2e  push r9
000071e7f4dd2f30  push r10
000071e7f4dd2f32  push r11
000071e7f4dd2f34  sub rsp, 0xF0
000071e7f4dd2f3b  vmovaps [rsp], xmm0
000071e7f4dd2f40  vmovaps [rsp+0x10], xmm1
000071e7f4dd2f46  vmovaps [rsp+0x20], xmm2
000071e7f4dd2f4c  vmovaps [rsp+0x30], xmm3
000071e7f4dd2f52  vmovaps [rsp+0x40], xmm4
000071e7f4dd2f58  vmovaps [rsp+0x50], xmm5
000071e7f4dd2f5e  vmovaps [rsp+0x60], xmm6
000071e7f4dd2f64  vmovaps [rsp+0x70], xmm7
000071e7f4dd2f6a  vmovaps [rsp+0x80], xmm8
000071e7f4dd2f73  vmovaps [rsp+0x90], xmm9
000071e7f4dd2f7c  vmovaps [rsp+0xA0], xmm10
000071e7f4dd2f85  vmovaps [rsp+0xB0], xmm11
000071e7f4dd2f8e  vmovaps [rsp+0xC0], xmm12
000071e7f4dd2f97  vmovaps [rsp+0xD0], xmm13
000071e7f4dd2fa0  vmovaps [rsp+0xE0], xmm14
000071e7f4dd2fa9  sub rsp, 0x30
000071e7f4dd2fad  movaps [rsp], xmm15
000071e7f4dd2fb2  movaps [rsp+0x10], xmm10
000071e7f4dd2fb8  movaps [rsp+0x20], xmm11
000071e7f4dd2fbe  lea rdi, [rsp]
000071e7f4dd2fc2  mov esi, 0x00
000071e7f4dd2fc7  mov rax, 0x562A51E82530
000071e7f4dd2fd1  call rax
000071e7f4dd2fd3  movaps xmm15, [rsp]
000071e7f4dd2fd8  add rsp, 0x30
000071e7f4dd2fdc  vmovaps xmm0, [rsp]
000071e7f4dd2fe1  vmovaps xmm1, [rsp+0x10]
000071e7f4dd2fe7  vmovaps xmm2, [rsp+0x20]
000071e7f4dd2fed  vmovaps xmm3, [rsp+0x30]
000071e7f4dd2ff3  vmovaps xmm4, [rsp+0x40]
000071e7f4dd2ff9  vmovaps xmm5, [rsp+0x50]
000071e7f4dd2fff  vmovaps xmm6, [rsp+0x60]
000071e7f4dd3005  vmovaps xmm7, [rsp+0x70]
000071e7f4dd300b  vmovaps xmm8, [rsp+0x80]
000071e7f4dd3014  vmovaps xmm9, [rsp+0x90]
000071e7f4dd301d  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd3026  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd302f  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd3038  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd3041  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd304a  add rsp, 0xF0
000071e7f4dd3051  pop r11
000071e7f4dd3053  pop r10
000071e7f4dd3055  pop r9
000071e7f4dd3057  pop r8
000071e7f4dd3059  pop rsi
000071e7f4dd305a  pop rdi
000071e7f4dd305b  pop rdx
000071e7f4dd305c  pop rcx
000071e7f4dd305d  pop rax
000071e7f4dd305e  add rsp, 0x08
000071e7f4dd3062  jmp 0x000071E7F4DCFE57
000071e7f4dd3067  sub rsp, 0x08
000071e7f4dd306b  push rax
000071e7f4dd306c  push rcx
000071e7f4dd306d  push rdx
000071e7f4dd306e  push rdi
000071e7f4dd306f  push rsi
000071e7f4dd3070  push r8
000071e7f4dd3072  push r9
000071e7f4dd3074  push r10
000071e7f4dd3076  push r11
000071e7f4dd3078  sub rsp, 0xF0
000071e7f4dd307f  vmovaps [rsp], xmm0
000071e7f4dd3084  vmovaps [rsp+0x10], xmm1
000071e7f4dd308a  vmovaps [rsp+0x20], xmm2
000071e7f4dd3090  vmovaps [rsp+0x30], xmm3
000071e7f4dd3096  vmovaps [rsp+0x40], xmm4
000071e7f4dd309c  vmovaps [rsp+0x50], xmm5
000071e7f4dd30a2  vmovaps [rsp+0x60], xmm6
000071e7f4dd30a8  vmovaps [rsp+0x70], xmm7
000071e7f4dd30ae  vmovaps [rsp+0x80], xmm8
000071e7f4dd30b7  vmovaps [rsp+0x90], xmm9
000071e7f4dd30c0  vmovaps [rsp+0xA0], xmm11
000071e7f4dd30c9  vmovaps [rsp+0xB0], xmm12
000071e7f4dd30d2  vmovaps [rsp+0xC0], xmm13
000071e7f4dd30db  vmovaps [rsp+0xD0], xmm14
000071e7f4dd30e4  vmovaps [rsp+0xE0], xmm15
000071e7f4dd30ed  sub rsp, 0x30
000071e7f4dd30f1  movaps [rsp], xmm10
000071e7f4dd30f6  movaps [rsp+0x10], xmm12
000071e7f4dd30fc  movaps [rsp+0x20], xmm11
000071e7f4dd3102  lea rdi, [rsp]
000071e7f4dd3106  mov esi, 0x00
000071e7f4dd310b  mov rax, 0x562A51E82530
000071e7f4dd3115  call rax
000071e7f4dd3117  movaps xmm10, [rsp]
000071e7f4dd311c  add rsp, 0x30
000071e7f4dd3120  vmovaps xmm0, [rsp]
000071e7f4dd3125  vmovaps xmm1, [rsp+0x10]
000071e7f4dd312b  vmovaps xmm2, [rsp+0x20]
000071e7f4dd3131  vmovaps xmm3, [rsp+0x30]
000071e7f4dd3137  vmovaps xmm4, [rsp+0x40]
000071e7f4dd313d  vmovaps xmm5, [rsp+0x50]
000071e7f4dd3143  vmovaps xmm6, [rsp+0x60]
000071e7f4dd3149  vmovaps xmm7, [rsp+0x70]
000071e7f4dd314f  vmovaps xmm8, [rsp+0x80]
000071e7f4dd3158  vmovaps xmm9, [rsp+0x90]
000071e7f4dd3161  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd316a  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd3173  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd317c  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd3185  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd318e  add rsp, 0xF0
000071e7f4dd3195  pop r11
000071e7f4dd3197  pop r10
000071e7f4dd3199  pop r9
000071e7f4dd319b  pop r8
000071e7f4dd319d  pop rsi
000071e7f4dd319e  pop rdi
000071e7f4dd319f  pop rdx
000071e7f4dd31a0  pop rcx
000071e7f4dd31a1  pop rax
000071e7f4dd31a2  add rsp, 0x08
000071e7f4dd31a6  jmp 0x000071E7F4DCFE80
000071e7f4dd31ab  sub rsp, 0x08
000071e7f4dd31af  push rax
000071e7f4dd31b0  push rcx
000071e7f4dd31b1  push rdx
000071e7f4dd31b2  push rdi
000071e7f4dd31b3  push rsi
000071e7f4dd31b4  push r8
000071e7f4dd31b6  push r9
000071e7f4dd31b8  push r10
000071e7f4dd31ba  push r11
000071e7f4dd31bc  sub rsp, 0xF0
000071e7f4dd31c3  vmovaps [rsp], xmm0
000071e7f4dd31c8  vmovaps [rsp+0x10], xmm1
000071e7f4dd31ce  vmovaps [rsp+0x20], xmm2
000071e7f4dd31d4  vmovaps [rsp+0x30], xmm3
000071e7f4dd31da  vmovaps [rsp+0x40], xmm4
000071e7f4dd31e0  vmovaps [rsp+0x50], xmm5
000071e7f4dd31e6  vmovaps [rsp+0x60], xmm6
000071e7f4dd31ec  vmovaps [rsp+0x70], xmm7
000071e7f4dd31f2  vmovaps [rsp+0x80], xmm8
000071e7f4dd31fb  vmovaps [rsp+0x90], xmm9
000071e7f4dd3204  vmovaps [rsp+0xA0], xmm10
000071e7f4dd320d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd3216  vmovaps [rsp+0xC0], xmm13
000071e7f4dd321f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd3228  vmovaps [rsp+0xE0], xmm15
000071e7f4dd3231  sub rsp, 0x30
000071e7f4dd3235  movaps [rsp], xmm11
000071e7f4dd323a  movaps [rsp+0x10], xmm2
000071e7f4dd323f  movaps [rsp+0x20], xmm12
000071e7f4dd3245  lea rdi, [rsp]
000071e7f4dd3249  mov esi, 0x00
000071e7f4dd324e  mov rax, 0x562A51E82530
000071e7f4dd3258  call rax
000071e7f4dd325a  movaps xmm11, [rsp]
000071e7f4dd325f  add rsp, 0x30
000071e7f4dd3263  vmovaps xmm0, [rsp]
000071e7f4dd3268  vmovaps xmm1, [rsp+0x10]
000071e7f4dd326e  vmovaps xmm2, [rsp+0x20]
000071e7f4dd3274  vmovaps xmm3, [rsp+0x30]
000071e7f4dd327a  vmovaps xmm4, [rsp+0x40]
000071e7f4dd3280  vmovaps xmm5, [rsp+0x50]
000071e7f4dd3286  vmovaps xmm6, [rsp+0x60]
000071e7f4dd328c  vmovaps xmm7, [rsp+0x70]
000071e7f4dd3292  vmovaps xmm8, [rsp+0x80]
000071e7f4dd329b  vmovaps xmm9, [rsp+0x90]
000071e7f4dd32a4  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd32ad  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd32b6  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd32bf  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd32c8  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd32d1  add rsp, 0xF0
000071e7f4dd32d8  pop r11
000071e7f4dd32da  pop r10
000071e7f4dd32dc  pop r9
000071e7f4dd32de  pop r8
000071e7f4dd32e0  pop rsi
000071e7f4dd32e1  pop rdi
000071e7f4dd32e2  pop rdx
000071e7f4dd32e3  pop rcx
000071e7f4dd32e4  pop rax
000071e7f4dd32e5  add rsp, 0x08
000071e7f4dd32e9  jmp 0x000071E7F4DCFEB8
000071e7f4dd32ee  sub rsp, 0x08
000071e7f4dd32f2  push rax
000071e7f4dd32f3  push rcx
000071e7f4dd32f4  push rdx
000071e7f4dd32f5  push rdi
000071e7f4dd32f6  push rsi
000071e7f4dd32f7  push r8
000071e7f4dd32f9  push r9
000071e7f4dd32fb  push r10
000071e7f4dd32fd  push r11
000071e7f4dd32ff  sub rsp, 0xF0
000071e7f4dd3306  vmovaps [rsp], xmm0
000071e7f4dd330b  vmovaps [rsp+0x10], xmm2
000071e7f4dd3311  vmovaps [rsp+0x20], xmm3
000071e7f4dd3317  vmovaps [rsp+0x30], xmm4
000071e7f4dd331d  vmovaps [rsp+0x40], xmm5
000071e7f4dd3323  vmovaps [rsp+0x50], xmm6
000071e7f4dd3329  vmovaps [rsp+0x60], xmm7
000071e7f4dd332f  vmovaps [rsp+0x70], xmm8
000071e7f4dd3335  vmovaps [rsp+0x80], xmm9
000071e7f4dd333e  vmovaps [rsp+0x90], xmm10
000071e7f4dd3347  vmovaps [rsp+0xA0], xmm11
000071e7f4dd3350  vmovaps [rsp+0xB0], xmm12
000071e7f4dd3359  vmovaps [rsp+0xC0], xmm13
000071e7f4dd3362  vmovaps [rsp+0xD0], xmm14
000071e7f4dd336b  vmovaps [rsp+0xE0], xmm15
000071e7f4dd3374  sub rsp, 0x30
000071e7f4dd3378  movaps [rsp], xmm1
000071e7f4dd337c  movaps [rsp+0x10], xmm14
000071e7f4dd3382  movaps [rsp+0x20], xmm6
000071e7f4dd3387  lea rdi, [rsp]
000071e7f4dd338b  mov esi, 0x00
000071e7f4dd3390  mov rax, 0x562A51E82530
000071e7f4dd339a  call rax
000071e7f4dd339c  movaps xmm1, [rsp]
000071e7f4dd33a0  add rsp, 0x30
000071e7f4dd33a4  vmovaps xmm0, [rsp]
000071e7f4dd33a9  vmovaps xmm2, [rsp+0x10]
000071e7f4dd33af  vmovaps xmm3, [rsp+0x20]
000071e7f4dd33b5  vmovaps xmm4, [rsp+0x30]
000071e7f4dd33bb  vmovaps xmm5, [rsp+0x40]
000071e7f4dd33c1  vmovaps xmm6, [rsp+0x50]
000071e7f4dd33c7  vmovaps xmm7, [rsp+0x60]
000071e7f4dd33cd  vmovaps xmm8, [rsp+0x70]
000071e7f4dd33d3  vmovaps xmm9, [rsp+0x80]
000071e7f4dd33dc  vmovaps xmm10, [rsp+0x90]
000071e7f4dd33e5  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd33ee  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd33f7  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd3400  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd3409  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd3412  add rsp, 0xF0
000071e7f4dd3419  pop r11
000071e7f4dd341b  pop r10
000071e7f4dd341d  pop r9
000071e7f4dd341f  pop r8
000071e7f4dd3421  pop rsi
000071e7f4dd3422  pop rdi
000071e7f4dd3423  pop rdx
000071e7f4dd3424  pop rcx
000071e7f4dd3425  pop rax
000071e7f4dd3426  add rsp, 0x08
000071e7f4dd342a  jmp 0x000071E7F4DCFED1
000071e7f4dd342f  sub rsp, 0x08
000071e7f4dd3433  push rax
000071e7f4dd3434  push rcx
000071e7f4dd3435  push rdx
000071e7f4dd3436  push rdi
000071e7f4dd3437  push rsi
000071e7f4dd3438  push r8
000071e7f4dd343a  push r9
000071e7f4dd343c  push r10
000071e7f4dd343e  push r11
000071e7f4dd3440  sub rsp, 0xF0
000071e7f4dd3447  vmovaps [rsp], xmm0
000071e7f4dd344c  vmovaps [rsp+0x10], xmm1
000071e7f4dd3452  vmovaps [rsp+0x20], xmm2
000071e7f4dd3458  vmovaps [rsp+0x30], xmm3
000071e7f4dd345e  vmovaps [rsp+0x40], xmm4
000071e7f4dd3464  vmovaps [rsp+0x50], xmm5
000071e7f4dd346a  vmovaps [rsp+0x60], xmm6
000071e7f4dd3470  vmovaps [rsp+0x70], xmm7
000071e7f4dd3476  vmovaps [rsp+0x80], xmm8
000071e7f4dd347f  vmovaps [rsp+0x90], xmm9
000071e7f4dd3488  vmovaps [rsp+0xA0], xmm10
000071e7f4dd3491  vmovaps [rsp+0xB0], xmm11
000071e7f4dd349a  vmovaps [rsp+0xC0], xmm12
000071e7f4dd34a3  vmovaps [rsp+0xD0], xmm13
000071e7f4dd34ac  vmovaps [rsp+0xE0], xmm15
000071e7f4dd34b5  sub rsp, 0x30
000071e7f4dd34b9  movaps [rsp], xmm14
000071e7f4dd34be  movaps [rsp+0x10], xmm12
000071e7f4dd34c4  movaps [rsp+0x20], xmm5
000071e7f4dd34c9  lea rdi, [rsp]
000071e7f4dd34cd  mov esi, 0x00
000071e7f4dd34d2  mov rax, 0x562A51E82530
000071e7f4dd34dc  call rax
000071e7f4dd34de  movaps xmm14, [rsp]
000071e7f4dd34e3  add rsp, 0x30
000071e7f4dd34e7  vmovaps xmm0, [rsp]
000071e7f4dd34ec  vmovaps xmm1, [rsp+0x10]
000071e7f4dd34f2  vmovaps xmm2, [rsp+0x20]
000071e7f4dd34f8  vmovaps xmm3, [rsp+0x30]
000071e7f4dd34fe  vmovaps xmm4, [rsp+0x40]
000071e7f4dd3504  vmovaps xmm5, [rsp+0x50]
000071e7f4dd350a  vmovaps xmm6, [rsp+0x60]
000071e7f4dd3510  vmovaps xmm7, [rsp+0x70]
000071e7f4dd3516  vmovaps xmm8, [rsp+0x80]
000071e7f4dd351f  vmovaps xmm9, [rsp+0x90]
000071e7f4dd3528  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd3531  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd353a  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd3543  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd354c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd3555  add rsp, 0xF0
000071e7f4dd355c  pop r11
000071e7f4dd355e  pop r10
000071e7f4dd3560  pop r9
000071e7f4dd3562  pop r8
000071e7f4dd3564  pop rsi
000071e7f4dd3565  pop rdi
000071e7f4dd3566  pop rdx
000071e7f4dd3567  pop rcx
000071e7f4dd3568  pop rax
000071e7f4dd3569  add rsp, 0x08
000071e7f4dd356d  jmp 0x000071E7F4DCFEF1
000071e7f4dd3572  sub rsp, 0x08
000071e7f4dd3576  push rax
000071e7f4dd3577  push rcx
000071e7f4dd3578  push rdx
000071e7f4dd3579  push rdi
000071e7f4dd357a  push rsi
000071e7f4dd357b  push r8
000071e7f4dd357d  push r9
000071e7f4dd357f  push r10
000071e7f4dd3581  push r11
000071e7f4dd3583  sub rsp, 0xF0
000071e7f4dd358a  vmovaps [rsp], xmm0
000071e7f4dd358f  vmovaps [rsp+0x10], xmm1
000071e7f4dd3595  vmovaps [rsp+0x20], xmm2
000071e7f4dd359b  vmovaps [rsp+0x30], xmm3
000071e7f4dd35a1  vmovaps [rsp+0x40], xmm4
000071e7f4dd35a7  vmovaps [rsp+0x50], xmm5
000071e7f4dd35ad  vmovaps [rsp+0x60], xmm7
000071e7f4dd35b3  vmovaps [rsp+0x70], xmm8
000071e7f4dd35b9  vmovaps [rsp+0x80], xmm9
000071e7f4dd35c2  vmovaps [rsp+0x90], xmm10
000071e7f4dd35cb  vmovaps [rsp+0xA0], xmm11
000071e7f4dd35d4  vmovaps [rsp+0xB0], xmm12
000071e7f4dd35dd  vmovaps [rsp+0xC0], xmm13
000071e7f4dd35e6  vmovaps [rsp+0xD0], xmm14
000071e7f4dd35ef  vmovaps [rsp+0xE0], xmm15
000071e7f4dd35f8  sub rsp, 0x30
000071e7f4dd35fc  movaps [rsp], xmm6
000071e7f4dd3600  movaps [rsp+0x10], xmm9
000071e7f4dd3606  movaps [rsp+0x20], xmm12
000071e7f4dd360c  lea rdi, [rsp]
000071e7f4dd3610  mov esi, 0x00
000071e7f4dd3615  mov rax, 0x562A51E82530
000071e7f4dd361f  call rax
000071e7f4dd3621  movaps xmm6, [rsp]
000071e7f4dd3625  add rsp, 0x30
000071e7f4dd3629  vmovaps xmm0, [rsp]
000071e7f4dd362e  vmovaps xmm1, [rsp+0x10]
000071e7f4dd3634  vmovaps xmm2, [rsp+0x20]
000071e7f4dd363a  vmovaps xmm3, [rsp+0x30]
000071e7f4dd3640  vmovaps xmm4, [rsp+0x40]
000071e7f4dd3646  vmovaps xmm5, [rsp+0x50]
000071e7f4dd364c  vmovaps xmm7, [rsp+0x60]
000071e7f4dd3652  vmovaps xmm8, [rsp+0x70]
000071e7f4dd3658  vmovaps xmm9, [rsp+0x80]
000071e7f4dd3661  vmovaps xmm10, [rsp+0x90]
000071e7f4dd366a  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd3673  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd367c  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd3685  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd368e  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd3697  add rsp, 0xF0
000071e7f4dd369e  pop r11
000071e7f4dd36a0  pop r10
000071e7f4dd36a2  pop r9
000071e7f4dd36a4  pop r8
000071e7f4dd36a6  pop rsi
000071e7f4dd36a7  pop rdi
000071e7f4dd36a8  pop rdx
000071e7f4dd36a9  pop rcx
000071e7f4dd36aa  pop rax
000071e7f4dd36ab  add rsp, 0x08
000071e7f4dd36af  jmp 0x000071E7F4DCFF19
000071e7f4dd36b4  sub rsp, 0x08
000071e7f4dd36b8  push rax
000071e7f4dd36b9  push rcx
000071e7f4dd36ba  push rdx
000071e7f4dd36bb  push rdi
000071e7f4dd36bc  push rsi
000071e7f4dd36bd  push r8
000071e7f4dd36bf  push r9
000071e7f4dd36c1  push r10
000071e7f4dd36c3  push r11
000071e7f4dd36c5  sub rsp, 0xF0
000071e7f4dd36cc  vmovaps [rsp], xmm0
000071e7f4dd36d1  vmovaps [rsp+0x10], xmm1
000071e7f4dd36d7  vmovaps [rsp+0x20], xmm2
000071e7f4dd36dd  vmovaps [rsp+0x30], xmm3
000071e7f4dd36e3  vmovaps [rsp+0x40], xmm4
000071e7f4dd36e9  vmovaps [rsp+0x50], xmm5
000071e7f4dd36ef  vmovaps [rsp+0x60], xmm6
000071e7f4dd36f5  vmovaps [rsp+0x70], xmm7
000071e7f4dd36fb  vmovaps [rsp+0x80], xmm8
000071e7f4dd3704  vmovaps [rsp+0x90], xmm9
000071e7f4dd370d  vmovaps [rsp+0xA0], xmm10
000071e7f4dd3716  vmovaps [rsp+0xB0], xmm11
000071e7f4dd371f  vmovaps [rsp+0xC0], xmm13
000071e7f4dd3728  vmovaps [rsp+0xD0], xmm14
000071e7f4dd3731  vmovaps [rsp+0xE0], xmm15
000071e7f4dd373a  sub rsp, 0x30
000071e7f4dd373e  movaps [rsp], xmm12
000071e7f4dd3743  movaps [rsp+0x10], xmm15
000071e7f4dd3749  movaps [rsp+0x20], xmm13
000071e7f4dd374f  lea rdi, [rsp]
000071e7f4dd3753  mov esi, 0x00
000071e7f4dd3758  mov rax, 0x562A51E82530
000071e7f4dd3762  call rax
000071e7f4dd3764  movaps xmm12, [rsp]
000071e7f4dd3769  add rsp, 0x30
000071e7f4dd376d  vmovaps xmm0, [rsp]
000071e7f4dd3772  vmovaps xmm1, [rsp+0x10]
000071e7f4dd3778  vmovaps xmm2, [rsp+0x20]
000071e7f4dd377e  vmovaps xmm3, [rsp+0x30]
000071e7f4dd3784  vmovaps xmm4, [rsp+0x40]
000071e7f4dd378a  vmovaps xmm5, [rsp+0x50]
000071e7f4dd3790  vmovaps xmm6, [rsp+0x60]
000071e7f4dd3796  vmovaps xmm7, [rsp+0x70]
000071e7f4dd379c  vmovaps xmm8, [rsp+0x80]
000071e7f4dd37a5  vmovaps xmm9, [rsp+0x90]
000071e7f4dd37ae  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd37b7  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd37c0  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd37c9  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd37d2  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd37db  add rsp, 0xF0
000071e7f4dd37e2  pop r11
000071e7f4dd37e4  pop r10
000071e7f4dd37e6  pop r9
000071e7f4dd37e8  pop r8
000071e7f4dd37ea  pop rsi
000071e7f4dd37eb  pop rdi
000071e7f4dd37ec  pop rdx
000071e7f4dd37ed  pop rcx
000071e7f4dd37ee  pop rax
000071e7f4dd37ef  add rsp, 0x08
000071e7f4dd37f3  jmp 0x000071E7F4DCFF34
000071e7f4dd37f8  sub rsp, 0x08
000071e7f4dd37fc  push rax
000071e7f4dd37fd  push rcx
000071e7f4dd37fe  push rdx
000071e7f4dd37ff  push rdi
000071e7f4dd3800  push rsi
000071e7f4dd3801  push r8
000071e7f4dd3803  push r9
000071e7f4dd3805  push r10
000071e7f4dd3807  push r11
000071e7f4dd3809  sub rsp, 0xF0
000071e7f4dd3810  vmovaps [rsp], xmm0
000071e7f4dd3815  vmovaps [rsp+0x10], xmm1
000071e7f4dd381b  vmovaps [rsp+0x20], xmm2
000071e7f4dd3821  vmovaps [rsp+0x30], xmm3
000071e7f4dd3827  vmovaps [rsp+0x40], xmm4
000071e7f4dd382d  vmovaps [rsp+0x50], xmm5
000071e7f4dd3833  vmovaps [rsp+0x60], xmm6
000071e7f4dd3839  vmovaps [rsp+0x70], xmm7
000071e7f4dd383f  vmovaps [rsp+0x80], xmm8
000071e7f4dd3848  vmovaps [rsp+0x90], xmm9
000071e7f4dd3851  vmovaps [rsp+0xA0], xmm10
000071e7f4dd385a  vmovaps [rsp+0xB0], xmm11
000071e7f4dd3863  vmovaps [rsp+0xC0], xmm12
000071e7f4dd386c  vmovaps [rsp+0xD0], xmm13
000071e7f4dd3875  vmovaps [rsp+0xE0], xmm14
000071e7f4dd387e  sub rsp, 0x30
000071e7f4dd3882  movaps [rsp], xmm15
000071e7f4dd3887  movaps [rsp+0x10], xmm13
000071e7f4dd388d  movaps [rsp+0x20], xmm10
000071e7f4dd3893  lea rdi, [rsp]
000071e7f4dd3897  mov esi, 0x00
000071e7f4dd389c  mov rax, 0x562A51E82530
000071e7f4dd38a6  call rax
000071e7f4dd38a8  movaps xmm15, [rsp]
000071e7f4dd38ad  add rsp, 0x30
000071e7f4dd38b1  vmovaps xmm0, [rsp]
000071e7f4dd38b6  vmovaps xmm1, [rsp+0x10]
000071e7f4dd38bc  vmovaps xmm2, [rsp+0x20]
000071e7f4dd38c2  vmovaps xmm3, [rsp+0x30]
000071e7f4dd38c8  vmovaps xmm4, [rsp+0x40]
000071e7f4dd38ce  vmovaps xmm5, [rsp+0x50]
000071e7f4dd38d4  vmovaps xmm6, [rsp+0x60]
000071e7f4dd38da  vmovaps xmm7, [rsp+0x70]
000071e7f4dd38e0  vmovaps xmm8, [rsp+0x80]
000071e7f4dd38e9  vmovaps xmm9, [rsp+0x90]
000071e7f4dd38f2  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd38fb  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd3904  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd390d  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd3916  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd391f  add rsp, 0xF0
000071e7f4dd3926  pop r11
000071e7f4dd3928  pop r10
000071e7f4dd392a  pop r9
000071e7f4dd392c  pop r8
000071e7f4dd392e  pop rsi
000071e7f4dd392f  pop rdi
000071e7f4dd3930  pop rdx
000071e7f4dd3931  pop rcx
000071e7f4dd3932  pop rax
000071e7f4dd3933  add rsp, 0x08
000071e7f4dd3937  jmp 0x000071E7F4DCFF55
000071e7f4dd393c  call 0x000071E7F4C0C260
000071e7f4dd3941  jmp 0x000071E7F4DCFFB0
000071e7f4dd3946  sub rsp, 0x08
000071e7f4dd394a  push rax
000071e7f4dd394b  push rcx
000071e7f4dd394c  push rdx
000071e7f4dd394d  push rdi
000071e7f4dd394e  push rsi
000071e7f4dd394f  push r8
000071e7f4dd3951  push r9
000071e7f4dd3953  push r10
000071e7f4dd3955  push r11
000071e7f4dd3957  sub rsp, 0xF0
000071e7f4dd395e  vmovaps [rsp], xmm0
000071e7f4dd3963  vmovaps [rsp+0x10], xmm1
000071e7f4dd3969  vmovaps [rsp+0x20], xmm2
000071e7f4dd396f  vmovaps [rsp+0x30], xmm3
000071e7f4dd3975  vmovaps [rsp+0x40], xmm4
000071e7f4dd397b  vmovaps [rsp+0x50], xmm5
000071e7f4dd3981  vmovaps [rsp+0x60], xmm6
000071e7f4dd3987  vmovaps [rsp+0x70], xmm7
000071e7f4dd398d  vmovaps [rsp+0x80], xmm8
000071e7f4dd3996  vmovaps [rsp+0x90], xmm10
000071e7f4dd399f  vmovaps [rsp+0xA0], xmm11
000071e7f4dd39a8  vmovaps [rsp+0xB0], xmm12
000071e7f4dd39b1  vmovaps [rsp+0xC0], xmm13
000071e7f4dd39ba  vmovaps [rsp+0xD0], xmm14
000071e7f4dd39c3  vmovaps [rsp+0xE0], xmm15
000071e7f4dd39cc  sub rsp, 0x30
000071e7f4dd39d0  movaps [rsp], xmm9
000071e7f4dd39d5  movaps [rsp+0x10], xmm8
000071e7f4dd39db  movaps [rsp+0x20], xmm10
000071e7f4dd39e1  lea rdi, [rsp]
000071e7f4dd39e5  mov esi, 0x00
000071e7f4dd39ea  mov rax, 0x562A51E82530
000071e7f4dd39f4  call rax
000071e7f4dd39f6  movaps xmm9, [rsp]
000071e7f4dd39fb  add rsp, 0x30
000071e7f4dd39ff  vmovaps xmm0, [rsp]
000071e7f4dd3a04  vmovaps xmm1, [rsp+0x10]
000071e7f4dd3a0a  vmovaps xmm2, [rsp+0x20]
000071e7f4dd3a10  vmovaps xmm3, [rsp+0x30]
000071e7f4dd3a16  vmovaps xmm4, [rsp+0x40]
000071e7f4dd3a1c  vmovaps xmm5, [rsp+0x50]
000071e7f4dd3a22  vmovaps xmm6, [rsp+0x60]
000071e7f4dd3a28  vmovaps xmm7, [rsp+0x70]
000071e7f4dd3a2e  vmovaps xmm8, [rsp+0x80]
000071e7f4dd3a37  vmovaps xmm10, [rsp+0x90]
000071e7f4dd3a40  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd3a49  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd3a52  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd3a5b  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd3a64  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd3a6d  add rsp, 0xF0
000071e7f4dd3a74  pop r11
000071e7f4dd3a76  pop r10
000071e7f4dd3a78  pop r9
000071e7f4dd3a7a  pop r8
000071e7f4dd3a7c  pop rsi
000071e7f4dd3a7d  pop rdi
000071e7f4dd3a7e  pop rdx
000071e7f4dd3a7f  pop rcx
000071e7f4dd3a80  pop rax
000071e7f4dd3a81  add rsp, 0x08
000071e7f4dd3a85  jmp 0x000071E7F4DCFFE1
000071e7f4dd3a8a  sub rsp, 0x08
000071e7f4dd3a8e  push rax
000071e7f4dd3a8f  push rcx
000071e7f4dd3a90  push rdx
000071e7f4dd3a91  push rdi
000071e7f4dd3a92  push rsi
000071e7f4dd3a93  push r8
000071e7f4dd3a95  push r9
000071e7f4dd3a97  push r10
000071e7f4dd3a99  push r11
000071e7f4dd3a9b  sub rsp, 0xF0
000071e7f4dd3aa2  vmovaps [rsp], xmm0
000071e7f4dd3aa7  vmovaps [rsp+0x10], xmm1
000071e7f4dd3aad  vmovaps [rsp+0x20], xmm2
000071e7f4dd3ab3  vmovaps [rsp+0x30], xmm3
000071e7f4dd3ab9  vmovaps [rsp+0x40], xmm4
000071e7f4dd3abf  vmovaps [rsp+0x50], xmm5
000071e7f4dd3ac5  vmovaps [rsp+0x60], xmm6
000071e7f4dd3acb  vmovaps [rsp+0x70], xmm7
000071e7f4dd3ad1  vmovaps [rsp+0x80], xmm8
000071e7f4dd3ada  vmovaps [rsp+0x90], xmm9
000071e7f4dd3ae3  vmovaps [rsp+0xA0], xmm11
000071e7f4dd3aec  vmovaps [rsp+0xB0], xmm12
000071e7f4dd3af5  vmovaps [rsp+0xC0], xmm13
000071e7f4dd3afe  vmovaps [rsp+0xD0], xmm14
000071e7f4dd3b07  vmovaps [rsp+0xE0], xmm15
000071e7f4dd3b10  sub rsp, 0x30
000071e7f4dd3b14  movaps [rsp], xmm10
000071e7f4dd3b19  movaps [rsp+0x10], xmm1
000071e7f4dd3b1e  movaps [rsp+0x20], xmm11
000071e7f4dd3b24  lea rdi, [rsp]
000071e7f4dd3b28  mov esi, 0x00
000071e7f4dd3b2d  mov rax, 0x562A51E82530
000071e7f4dd3b37  call rax
000071e7f4dd3b39  movaps xmm10, [rsp]
000071e7f4dd3b3e  add rsp, 0x30
000071e7f4dd3b42  vmovaps xmm0, [rsp]
000071e7f4dd3b47  vmovaps xmm1, [rsp+0x10]
000071e7f4dd3b4d  vmovaps xmm2, [rsp+0x20]
000071e7f4dd3b53  vmovaps xmm3, [rsp+0x30]
000071e7f4dd3b59  vmovaps xmm4, [rsp+0x40]
000071e7f4dd3b5f  vmovaps xmm5, [rsp+0x50]
000071e7f4dd3b65  vmovaps xmm6, [rsp+0x60]
000071e7f4dd3b6b  vmovaps xmm7, [rsp+0x70]
000071e7f4dd3b71  vmovaps xmm8, [rsp+0x80]
000071e7f4dd3b7a  vmovaps xmm9, [rsp+0x90]
000071e7f4dd3b83  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd3b8c  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd3b95  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd3b9e  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd3ba7  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd3bb0  add rsp, 0xF0
000071e7f4dd3bb7  pop r11
000071e7f4dd3bb9  pop r10
000071e7f4dd3bbb  pop r9
000071e7f4dd3bbd  pop r8
000071e7f4dd3bbf  pop rsi
000071e7f4dd3bc0  pop rdi
000071e7f4dd3bc1  pop rdx
000071e7f4dd3bc2  pop rcx
000071e7f4dd3bc3  pop rax
000071e7f4dd3bc4  add rsp, 0x08
000071e7f4dd3bc8  jmp 0x000071E7F4DCFFFC
000071e7f4dd3bcd  sub rsp, 0x08
000071e7f4dd3bd1  push rax
000071e7f4dd3bd2  push rcx
000071e7f4dd3bd3  push rdx
000071e7f4dd3bd4  push rdi
000071e7f4dd3bd5  push rsi
000071e7f4dd3bd6  push r8
000071e7f4dd3bd8  push r9
000071e7f4dd3bda  push r10
000071e7f4dd3bdc  push r11
000071e7f4dd3bde  sub rsp, 0xF0
000071e7f4dd3be5  vmovaps [rsp], xmm0
000071e7f4dd3bea  vmovaps [rsp+0x10], xmm2
000071e7f4dd3bf0  vmovaps [rsp+0x20], xmm3
000071e7f4dd3bf6  vmovaps [rsp+0x30], xmm4
000071e7f4dd3bfc  vmovaps [rsp+0x40], xmm5
000071e7f4dd3c02  vmovaps [rsp+0x50], xmm6
000071e7f4dd3c08  vmovaps [rsp+0x60], xmm7
000071e7f4dd3c0e  vmovaps [rsp+0x70], xmm8
000071e7f4dd3c14  vmovaps [rsp+0x80], xmm9
000071e7f4dd3c1d  vmovaps [rsp+0x90], xmm10
000071e7f4dd3c26  vmovaps [rsp+0xA0], xmm11
000071e7f4dd3c2f  vmovaps [rsp+0xB0], xmm12
000071e7f4dd3c38  vmovaps [rsp+0xC0], xmm13
000071e7f4dd3c41  vmovaps [rsp+0xD0], xmm14
000071e7f4dd3c4a  vmovaps [rsp+0xE0], xmm15
000071e7f4dd3c53  sub rsp, 0x30
000071e7f4dd3c57  movaps [rsp], xmm1
000071e7f4dd3c5b  movaps [rsp+0x10], xmm14
000071e7f4dd3c61  movaps [rsp+0x20], xmm6
000071e7f4dd3c66  lea rdi, [rsp]
000071e7f4dd3c6a  mov esi, 0x00
000071e7f4dd3c6f  mov rax, 0x562A51E82530
000071e7f4dd3c79  call rax
000071e7f4dd3c7b  movaps xmm1, [rsp]
000071e7f4dd3c7f  add rsp, 0x30
000071e7f4dd3c83  vmovaps xmm0, [rsp]
000071e7f4dd3c88  vmovaps xmm2, [rsp+0x10]
000071e7f4dd3c8e  vmovaps xmm3, [rsp+0x20]
000071e7f4dd3c94  vmovaps xmm4, [rsp+0x30]
000071e7f4dd3c9a  vmovaps xmm5, [rsp+0x40]
000071e7f4dd3ca0  vmovaps xmm6, [rsp+0x50]
000071e7f4dd3ca6  vmovaps xmm7, [rsp+0x60]
000071e7f4dd3cac  vmovaps xmm8, [rsp+0x70]
000071e7f4dd3cb2  vmovaps xmm9, [rsp+0x80]
000071e7f4dd3cbb  vmovaps xmm10, [rsp+0x90]
000071e7f4dd3cc4  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd3ccd  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd3cd6  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd3cdf  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd3ce8  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd3cf1  add rsp, 0xF0
000071e7f4dd3cf8  pop r11
000071e7f4dd3cfa  pop r10
000071e7f4dd3cfc  pop r9
000071e7f4dd3cfe  pop r8
000071e7f4dd3d00  pop rsi
000071e7f4dd3d01  pop rdi
000071e7f4dd3d02  pop rdx
000071e7f4dd3d03  pop rcx
000071e7f4dd3d04  pop rax
000071e7f4dd3d05  add rsp, 0x08
000071e7f4dd3d09  jmp 0x000071E7F4DD0015
000071e7f4dd3d0e  sub rsp, 0x08
000071e7f4dd3d12  push rax
000071e7f4dd3d13  push rcx
000071e7f4dd3d14  push rdx
000071e7f4dd3d15  push rdi
000071e7f4dd3d16  push rsi
000071e7f4dd3d17  push r8
000071e7f4dd3d19  push r9
000071e7f4dd3d1b  push r10
000071e7f4dd3d1d  push r11
000071e7f4dd3d1f  sub rsp, 0xF0
000071e7f4dd3d26  vmovaps [rsp], xmm0
000071e7f4dd3d2b  vmovaps [rsp+0x10], xmm1
000071e7f4dd3d31  vmovaps [rsp+0x20], xmm2
000071e7f4dd3d37  vmovaps [rsp+0x30], xmm3
000071e7f4dd3d3d  vmovaps [rsp+0x40], xmm4
000071e7f4dd3d43  vmovaps [rsp+0x50], xmm5
000071e7f4dd3d49  vmovaps [rsp+0x60], xmm6
000071e7f4dd3d4f  vmovaps [rsp+0x70], xmm7
000071e7f4dd3d55  vmovaps [rsp+0x80], xmm8
000071e7f4dd3d5e  vmovaps [rsp+0x90], xmm9
000071e7f4dd3d67  vmovaps [rsp+0xA0], xmm10
000071e7f4dd3d70  vmovaps [rsp+0xB0], xmm12
000071e7f4dd3d79  vmovaps [rsp+0xC0], xmm13
000071e7f4dd3d82  vmovaps [rsp+0xD0], xmm14
000071e7f4dd3d8b  vmovaps [rsp+0xE0], xmm15
000071e7f4dd3d94  sub rsp, 0x30
000071e7f4dd3d98  movaps [rsp], xmm11
000071e7f4dd3d9d  movaps [rsp+0x10], xmm13
000071e7f4dd3da3  movaps [rsp+0x20], xmm14
000071e7f4dd3da9  lea rdi, [rsp]
000071e7f4dd3dad  mov esi, 0x00
000071e7f4dd3db2  mov rax, 0x562A51E82530
000071e7f4dd3dbc  call rax
000071e7f4dd3dbe  movaps xmm11, [rsp]
000071e7f4dd3dc3  add rsp, 0x30
000071e7f4dd3dc7  vmovaps xmm0, [rsp]
000071e7f4dd3dcc  vmovaps xmm1, [rsp+0x10]
000071e7f4dd3dd2  vmovaps xmm2, [rsp+0x20]
000071e7f4dd3dd8  vmovaps xmm3, [rsp+0x30]
000071e7f4dd3dde  vmovaps xmm4, [rsp+0x40]
000071e7f4dd3de4  vmovaps xmm5, [rsp+0x50]
000071e7f4dd3dea  vmovaps xmm6, [rsp+0x60]
000071e7f4dd3df0  vmovaps xmm7, [rsp+0x70]
000071e7f4dd3df6  vmovaps xmm8, [rsp+0x80]
000071e7f4dd3dff  vmovaps xmm9, [rsp+0x90]
000071e7f4dd3e08  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd3e11  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd3e1a  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd3e23  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd3e2c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd3e35  add rsp, 0xF0
000071e7f4dd3e3c  pop r11
000071e7f4dd3e3e  pop r10
000071e7f4dd3e40  pop r9
000071e7f4dd3e42  pop r8
000071e7f4dd3e44  pop rsi
000071e7f4dd3e45  pop rdi
000071e7f4dd3e46  pop rdx
000071e7f4dd3e47  pop rcx
000071e7f4dd3e48  pop rax
000071e7f4dd3e49  add rsp, 0x08
000071e7f4dd3e4d  jmp 0x000071E7F4DD003F
000071e7f4dd3e52  sub rsp, 0x08
000071e7f4dd3e56  push rax
000071e7f4dd3e57  push rcx
000071e7f4dd3e58  push rdx
000071e7f4dd3e59  push rdi
000071e7f4dd3e5a  push rsi
000071e7f4dd3e5b  push r8
000071e7f4dd3e5d  push r9
000071e7f4dd3e5f  push r10
000071e7f4dd3e61  push r11
000071e7f4dd3e63  sub rsp, 0xF0
000071e7f4dd3e6a  vmovaps [rsp], xmm0
000071e7f4dd3e6f  vmovaps [rsp+0x10], xmm1
000071e7f4dd3e75  vmovaps [rsp+0x20], xmm2
000071e7f4dd3e7b  vmovaps [rsp+0x30], xmm3
000071e7f4dd3e81  vmovaps [rsp+0x40], xmm4
000071e7f4dd3e87  vmovaps [rsp+0x50], xmm5
000071e7f4dd3e8d  vmovaps [rsp+0x60], xmm6
000071e7f4dd3e93  vmovaps [rsp+0x70], xmm7
000071e7f4dd3e99  vmovaps [rsp+0x80], xmm8
000071e7f4dd3ea2  vmovaps [rsp+0x90], xmm9
000071e7f4dd3eab  vmovaps [rsp+0xA0], xmm10
000071e7f4dd3eb4  vmovaps [rsp+0xB0], xmm11
000071e7f4dd3ebd  vmovaps [rsp+0xC0], xmm12
000071e7f4dd3ec6  vmovaps [rsp+0xD0], xmm14
000071e7f4dd3ecf  vmovaps [rsp+0xE0], xmm15
000071e7f4dd3ed8  sub rsp, 0x30
000071e7f4dd3edc  movaps [rsp], xmm13
000071e7f4dd3ee1  movaps [rsp+0x10], xmm8
000071e7f4dd3ee7  movaps [rsp+0x20], xmm14
000071e7f4dd3eed  lea rdi, [rsp]
000071e7f4dd3ef1  mov esi, 0x00
000071e7f4dd3ef6  mov rax, 0x562A51E82530
000071e7f4dd3f00  call rax
000071e7f4dd3f02  movaps xmm13, [rsp]
000071e7f4dd3f07  add rsp, 0x30
000071e7f4dd3f0b  vmovaps xmm0, [rsp]
000071e7f4dd3f10  vmovaps xmm1, [rsp+0x10]
000071e7f4dd3f16  vmovaps xmm2, [rsp+0x20]
000071e7f4dd3f1c  vmovaps xmm3, [rsp+0x30]
000071e7f4dd3f22  vmovaps xmm4, [rsp+0x40]
000071e7f4dd3f28  vmovaps xmm5, [rsp+0x50]
000071e7f4dd3f2e  vmovaps xmm6, [rsp+0x60]
000071e7f4dd3f34  vmovaps xmm7, [rsp+0x70]
000071e7f4dd3f3a  vmovaps xmm8, [rsp+0x80]
000071e7f4dd3f43  vmovaps xmm9, [rsp+0x90]
000071e7f4dd3f4c  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd3f55  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd3f5e  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd3f67  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd3f70  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd3f79  add rsp, 0xF0
000071e7f4dd3f80  pop r11
000071e7f4dd3f82  pop r10
000071e7f4dd3f84  pop r9
000071e7f4dd3f86  pop r8
000071e7f4dd3f88  pop rsi
000071e7f4dd3f89  pop rdi
000071e7f4dd3f8a  pop rdx
000071e7f4dd3f8b  pop rcx
000071e7f4dd3f8c  pop rax
000071e7f4dd3f8d  add rsp, 0x08
000071e7f4dd3f91  jmp 0x000071E7F4DD006E
000071e7f4dd3f96  sub rsp, 0x08
000071e7f4dd3f9a  push rax
000071e7f4dd3f9b  push rcx
000071e7f4dd3f9c  push rdx
000071e7f4dd3f9d  push rdi
000071e7f4dd3f9e  push rsi
000071e7f4dd3f9f  push r8
000071e7f4dd3fa1  push r9
000071e7f4dd3fa3  push r10
000071e7f4dd3fa5  push r11
000071e7f4dd3fa7  sub rsp, 0xF0
000071e7f4dd3fae  vmovaps [rsp], xmm0
000071e7f4dd3fb3  vmovaps [rsp+0x10], xmm1
000071e7f4dd3fb9  vmovaps [rsp+0x20], xmm2
000071e7f4dd3fbf  vmovaps [rsp+0x30], xmm3
000071e7f4dd3fc5  vmovaps [rsp+0x40], xmm4
000071e7f4dd3fcb  vmovaps [rsp+0x50], xmm5
000071e7f4dd3fd1  vmovaps [rsp+0x60], xmm6
000071e7f4dd3fd7  vmovaps [rsp+0x70], xmm7
000071e7f4dd3fdd  vmovaps [rsp+0x80], xmm9
000071e7f4dd3fe6  vmovaps [rsp+0x90], xmm10
000071e7f4dd3fef  vmovaps [rsp+0xA0], xmm11
000071e7f4dd3ff8  vmovaps [rsp+0xB0], xmm12
000071e7f4dd4001  vmovaps [rsp+0xC0], xmm13
000071e7f4dd400a  vmovaps [rsp+0xD0], xmm14
000071e7f4dd4013  vmovaps [rsp+0xE0], xmm15
000071e7f4dd401c  sub rsp, 0x30
000071e7f4dd4020  movaps [rsp], xmm8
000071e7f4dd4025  movaps [rsp+0x10], xmm7
000071e7f4dd402a  movaps [rsp+0x20], xmm14
000071e7f4dd4030  lea rdi, [rsp]
000071e7f4dd4034  mov esi, 0x00
000071e7f4dd4039  mov rax, 0x562A51E82530
000071e7f4dd4043  call rax
000071e7f4dd4045  movaps xmm8, [rsp]
000071e7f4dd404a  add rsp, 0x30
000071e7f4dd404e  vmovaps xmm0, [rsp]
000071e7f4dd4053  vmovaps xmm1, [rsp+0x10]
000071e7f4dd4059  vmovaps xmm2, [rsp+0x20]
000071e7f4dd405f  vmovaps xmm3, [rsp+0x30]
000071e7f4dd4065  vmovaps xmm4, [rsp+0x40]
000071e7f4dd406b  vmovaps xmm5, [rsp+0x50]
000071e7f4dd4071  vmovaps xmm6, [rsp+0x60]
000071e7f4dd4077  vmovaps xmm7, [rsp+0x70]
000071e7f4dd407d  vmovaps xmm9, [rsp+0x80]
000071e7f4dd4086  vmovaps xmm10, [rsp+0x90]
000071e7f4dd408f  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd4098  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd40a1  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd40aa  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd40b3  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd40bc  add rsp, 0xF0
000071e7f4dd40c3  pop r11
000071e7f4dd40c5  pop r10
000071e7f4dd40c7  pop r9
000071e7f4dd40c9  pop r8
000071e7f4dd40cb  pop rsi
000071e7f4dd40cc  pop rdi
000071e7f4dd40cd  pop rdx
000071e7f4dd40ce  pop rcx
000071e7f4dd40cf  pop rax
000071e7f4dd40d0  add rsp, 0x08
000071e7f4dd40d4  jmp 0x000071E7F4DD0094
000071e7f4dd40d9  sub rsp, 0x08
000071e7f4dd40dd  push rax
000071e7f4dd40de  push rcx
000071e7f4dd40df  push rdx
000071e7f4dd40e0  push rdi
000071e7f4dd40e1  push rsi
000071e7f4dd40e2  push r8
000071e7f4dd40e4  push r9
000071e7f4dd40e6  push r10
000071e7f4dd40e8  push r11
000071e7f4dd40ea  sub rsp, 0xF0
000071e7f4dd40f1  vmovaps [rsp], xmm0
000071e7f4dd40f6  vmovaps [rsp+0x10], xmm1
000071e7f4dd40fc  vmovaps [rsp+0x20], xmm2
000071e7f4dd4102  vmovaps [rsp+0x30], xmm3
000071e7f4dd4108  vmovaps [rsp+0x40], xmm4
000071e7f4dd410e  vmovaps [rsp+0x50], xmm5
000071e7f4dd4114  vmovaps [rsp+0x60], xmm6
000071e7f4dd411a  vmovaps [rsp+0x70], xmm7
000071e7f4dd4120  vmovaps [rsp+0x80], xmm8
000071e7f4dd4129  vmovaps [rsp+0x90], xmm9
000071e7f4dd4132  vmovaps [rsp+0xA0], xmm10
000071e7f4dd413b  vmovaps [rsp+0xB0], xmm11
000071e7f4dd4144  vmovaps [rsp+0xC0], xmm12
000071e7f4dd414d  vmovaps [rsp+0xD0], xmm13
000071e7f4dd4156  vmovaps [rsp+0xE0], xmm15
000071e7f4dd415f  sub rsp, 0x30
000071e7f4dd4163  movaps [rsp], xmm14
000071e7f4dd4168  movaps [rsp+0x10], xmm12
000071e7f4dd416e  movaps [rsp+0x20], xmm9
000071e7f4dd4174  lea rdi, [rsp]
000071e7f4dd4178  mov esi, 0x00
000071e7f4dd417d  mov rax, 0x562A51E82530
000071e7f4dd4187  call rax
000071e7f4dd4189  movaps xmm14, [rsp]
000071e7f4dd418e  add rsp, 0x30
000071e7f4dd4192  vmovaps xmm0, [rsp]
000071e7f4dd4197  vmovaps xmm1, [rsp+0x10]
000071e7f4dd419d  vmovaps xmm2, [rsp+0x20]
000071e7f4dd41a3  vmovaps xmm3, [rsp+0x30]
000071e7f4dd41a9  vmovaps xmm4, [rsp+0x40]
000071e7f4dd41af  vmovaps xmm5, [rsp+0x50]
000071e7f4dd41b5  vmovaps xmm6, [rsp+0x60]
000071e7f4dd41bb  vmovaps xmm7, [rsp+0x70]
000071e7f4dd41c1  vmovaps xmm8, [rsp+0x80]
000071e7f4dd41ca  vmovaps xmm9, [rsp+0x90]
000071e7f4dd41d3  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd41dc  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd41e5  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd41ee  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd41f7  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4200  add rsp, 0xF0
000071e7f4dd4207  pop r11
000071e7f4dd4209  pop r10
000071e7f4dd420b  pop r9
000071e7f4dd420d  pop r8
000071e7f4dd420f  pop rsi
000071e7f4dd4210  pop rdi
000071e7f4dd4211  pop rdx
000071e7f4dd4212  pop rcx
000071e7f4dd4213  pop rax
000071e7f4dd4214  add rsp, 0x08
000071e7f4dd4218  jmp 0x000071E7F4DD00AE
000071e7f4dd421d  sub rsp, 0x08
000071e7f4dd4221  push rax
000071e7f4dd4222  push rcx
000071e7f4dd4223  push rdx
000071e7f4dd4224  push rdi
000071e7f4dd4225  push rsi
000071e7f4dd4226  push r8
000071e7f4dd4228  push r9
000071e7f4dd422a  push r10
000071e7f4dd422c  push r11
000071e7f4dd422e  sub rsp, 0xF0
000071e7f4dd4235  vmovaps [rsp], xmm0
000071e7f4dd423a  vmovaps [rsp+0x10], xmm1
000071e7f4dd4240  vmovaps [rsp+0x20], xmm2
000071e7f4dd4246  vmovaps [rsp+0x30], xmm3
000071e7f4dd424c  vmovaps [rsp+0x40], xmm4
000071e7f4dd4252  vmovaps [rsp+0x50], xmm5
000071e7f4dd4258  vmovaps [rsp+0x60], xmm6
000071e7f4dd425e  vmovaps [rsp+0x70], xmm7
000071e7f4dd4264  vmovaps [rsp+0x80], xmm8
000071e7f4dd426d  vmovaps [rsp+0x90], xmm10
000071e7f4dd4276  vmovaps [rsp+0xA0], xmm11
000071e7f4dd427f  vmovaps [rsp+0xB0], xmm12
000071e7f4dd4288  vmovaps [rsp+0xC0], xmm13
000071e7f4dd4291  vmovaps [rsp+0xD0], xmm14
000071e7f4dd429a  vmovaps [rsp+0xE0], xmm15
000071e7f4dd42a3  sub rsp, 0x30
000071e7f4dd42a7  movaps [rsp], xmm9
000071e7f4dd42ac  movaps [rsp+0x10], xmm7
000071e7f4dd42b1  movaps [rsp+0x20], xmm12
000071e7f4dd42b7  lea rdi, [rsp]
000071e7f4dd42bb  mov esi, 0x00
000071e7f4dd42c0  mov rax, 0x562A51E82530
000071e7f4dd42ca  call rax
000071e7f4dd42cc  movaps xmm9, [rsp]
000071e7f4dd42d1  add rsp, 0x30
000071e7f4dd42d5  vmovaps xmm0, [rsp]
000071e7f4dd42da  vmovaps xmm1, [rsp+0x10]
000071e7f4dd42e0  vmovaps xmm2, [rsp+0x20]
000071e7f4dd42e6  vmovaps xmm3, [rsp+0x30]
000071e7f4dd42ec  vmovaps xmm4, [rsp+0x40]
000071e7f4dd42f2  vmovaps xmm5, [rsp+0x50]
000071e7f4dd42f8  vmovaps xmm6, [rsp+0x60]
000071e7f4dd42fe  vmovaps xmm7, [rsp+0x70]
000071e7f4dd4304  vmovaps xmm8, [rsp+0x80]
000071e7f4dd430d  vmovaps xmm10, [rsp+0x90]
000071e7f4dd4316  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd431f  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd4328  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd4331  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd433a  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4343  add rsp, 0xF0
000071e7f4dd434a  pop r11
000071e7f4dd434c  pop r10
000071e7f4dd434e  pop r9
000071e7f4dd4350  pop r8
000071e7f4dd4352  pop rsi
000071e7f4dd4353  pop rdi
000071e7f4dd4354  pop rdx
000071e7f4dd4355  pop rcx
000071e7f4dd4356  pop rax
000071e7f4dd4357  add rsp, 0x08
000071e7f4dd435b  jmp 0x000071E7F4DD00DD
000071e7f4dd4360  sub rsp, 0x08
000071e7f4dd4364  push rax
000071e7f4dd4365  push rcx
000071e7f4dd4366  push rdx
000071e7f4dd4367  push rdi
000071e7f4dd4368  push rsi
000071e7f4dd4369  push r8
000071e7f4dd436b  push r9
000071e7f4dd436d  push r10
000071e7f4dd436f  push r11
000071e7f4dd4371  sub rsp, 0xF0
000071e7f4dd4378  vmovaps [rsp], xmm0
000071e7f4dd437d  vmovaps [rsp+0x10], xmm1
000071e7f4dd4383  vmovaps [rsp+0x20], xmm2
000071e7f4dd4389  vmovaps [rsp+0x30], xmm3
000071e7f4dd438f  vmovaps [rsp+0x40], xmm4
000071e7f4dd4395  vmovaps [rsp+0x50], xmm5
000071e7f4dd439b  vmovaps [rsp+0x60], xmm6
000071e7f4dd43a1  vmovaps [rsp+0x70], xmm7
000071e7f4dd43a7  vmovaps [rsp+0x80], xmm8
000071e7f4dd43b0  vmovaps [rsp+0x90], xmm9
000071e7f4dd43b9  vmovaps [rsp+0xA0], xmm10
000071e7f4dd43c2  vmovaps [rsp+0xB0], xmm11
000071e7f4dd43cb  vmovaps [rsp+0xC0], xmm13
000071e7f4dd43d4  vmovaps [rsp+0xD0], xmm14
000071e7f4dd43dd  vmovaps [rsp+0xE0], xmm15
000071e7f4dd43e6  sub rsp, 0x30
000071e7f4dd43ea  movaps [rsp], xmm12
000071e7f4dd43ef  movaps [rsp+0x10], xmm15
000071e7f4dd43f5  movaps [rsp+0x20], xmm11
000071e7f4dd43fb  lea rdi, [rsp]
000071e7f4dd43ff  mov esi, 0x00
000071e7f4dd4404  mov rax, 0x562A51E82530
000071e7f4dd440e  call rax
000071e7f4dd4410  movaps xmm12, [rsp]
000071e7f4dd4415  add rsp, 0x30
000071e7f4dd4419  vmovaps xmm0, [rsp]
000071e7f4dd441e  vmovaps xmm1, [rsp+0x10]
000071e7f4dd4424  vmovaps xmm2, [rsp+0x20]
000071e7f4dd442a  vmovaps xmm3, [rsp+0x30]
000071e7f4dd4430  vmovaps xmm4, [rsp+0x40]
000071e7f4dd4436  vmovaps xmm5, [rsp+0x50]
000071e7f4dd443c  vmovaps xmm6, [rsp+0x60]
000071e7f4dd4442  vmovaps xmm7, [rsp+0x70]
000071e7f4dd4448  vmovaps xmm8, [rsp+0x80]
000071e7f4dd4451  vmovaps xmm9, [rsp+0x90]
000071e7f4dd445a  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd4463  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd446c  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd4475  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd447e  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4487  add rsp, 0xF0
000071e7f4dd448e  pop r11
000071e7f4dd4490  pop r10
000071e7f4dd4492  pop r9
000071e7f4dd4494  pop r8
000071e7f4dd4496  pop rsi
000071e7f4dd4497  pop rdi
000071e7f4dd4498  pop rdx
000071e7f4dd4499  pop rcx
000071e7f4dd449a  pop rax
000071e7f4dd449b  add rsp, 0x08
000071e7f4dd449f  jmp 0x000071E7F4DD00F7
000071e7f4dd44a4  sub rsp, 0x08
000071e7f4dd44a8  push rax
000071e7f4dd44a9  push rcx
000071e7f4dd44aa  push rdx
000071e7f4dd44ab  push rdi
000071e7f4dd44ac  push rsi
000071e7f4dd44ad  push r8
000071e7f4dd44af  push r9
000071e7f4dd44b1  push r10
000071e7f4dd44b3  push r11
000071e7f4dd44b5  sub rsp, 0xF0
000071e7f4dd44bc  vmovaps [rsp], xmm0
000071e7f4dd44c1  vmovaps [rsp+0x10], xmm1
000071e7f4dd44c7  vmovaps [rsp+0x20], xmm2
000071e7f4dd44cd  vmovaps [rsp+0x30], xmm3
000071e7f4dd44d3  vmovaps [rsp+0x40], xmm4
000071e7f4dd44d9  vmovaps [rsp+0x50], xmm5
000071e7f4dd44df  vmovaps [rsp+0x60], xmm6
000071e7f4dd44e5  vmovaps [rsp+0x70], xmm7
000071e7f4dd44eb  vmovaps [rsp+0x80], xmm8
000071e7f4dd44f4  vmovaps [rsp+0x90], xmm9
000071e7f4dd44fd  vmovaps [rsp+0xA0], xmm10
000071e7f4dd4506  vmovaps [rsp+0xB0], xmm12
000071e7f4dd450f  vmovaps [rsp+0xC0], xmm13
000071e7f4dd4518  vmovaps [rsp+0xD0], xmm14
000071e7f4dd4521  vmovaps [rsp+0xE0], xmm15
000071e7f4dd452a  sub rsp, 0x30
000071e7f4dd452e  movaps [rsp], xmm11
000071e7f4dd4533  movaps [rsp+0x10], xmm7
000071e7f4dd4538  movaps [rsp+0x20], xmm15
000071e7f4dd453e  lea rdi, [rsp]
000071e7f4dd4542  mov esi, 0x00
000071e7f4dd4547  mov rax, 0x562A51E82530
000071e7f4dd4551  call rax
000071e7f4dd4553  movaps xmm11, [rsp]
000071e7f4dd4558  add rsp, 0x30
000071e7f4dd455c  vmovaps xmm0, [rsp]
000071e7f4dd4561  vmovaps xmm1, [rsp+0x10]
000071e7f4dd4567  vmovaps xmm2, [rsp+0x20]
000071e7f4dd456d  vmovaps xmm3, [rsp+0x30]
000071e7f4dd4573  vmovaps xmm4, [rsp+0x40]
000071e7f4dd4579  vmovaps xmm5, [rsp+0x50]
000071e7f4dd457f  vmovaps xmm6, [rsp+0x60]
000071e7f4dd4585  vmovaps xmm7, [rsp+0x70]
000071e7f4dd458b  vmovaps xmm8, [rsp+0x80]
000071e7f4dd4594  vmovaps xmm9, [rsp+0x90]
000071e7f4dd459d  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd45a6  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd45af  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd45b8  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd45c1  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd45ca  add rsp, 0xF0
000071e7f4dd45d1  pop r11
000071e7f4dd45d3  pop r10
000071e7f4dd45d5  pop r9
000071e7f4dd45d7  pop r8
000071e7f4dd45d9  pop rsi
000071e7f4dd45da  pop rdi
000071e7f4dd45db  pop rdx
000071e7f4dd45dc  pop rcx
000071e7f4dd45dd  pop rax
000071e7f4dd45de  add rsp, 0x08
000071e7f4dd45e2  jmp 0x000071E7F4DD0123
000071e7f4dd45e7  sub rsp, 0x08
000071e7f4dd45eb  push rax
000071e7f4dd45ec  push rcx
000071e7f4dd45ed  push rdx
000071e7f4dd45ee  push rdi
000071e7f4dd45ef  push rsi
000071e7f4dd45f0  push r8
000071e7f4dd45f2  push r9
000071e7f4dd45f4  push r10
000071e7f4dd45f6  push r11
000071e7f4dd45f8  sub rsp, 0xF0
000071e7f4dd45ff  vmovaps [rsp], xmm0
000071e7f4dd4604  vmovaps [rsp+0x10], xmm1
000071e7f4dd460a  vmovaps [rsp+0x20], xmm2
000071e7f4dd4610  vmovaps [rsp+0x30], xmm3
000071e7f4dd4616  vmovaps [rsp+0x40], xmm4
000071e7f4dd461c  vmovaps [rsp+0x50], xmm5
000071e7f4dd4622  vmovaps [rsp+0x60], xmm6
000071e7f4dd4628  vmovaps [rsp+0x70], xmm7
000071e7f4dd462e  vmovaps [rsp+0x80], xmm8
000071e7f4dd4637  vmovaps [rsp+0x90], xmm9
000071e7f4dd4640  vmovaps [rsp+0xA0], xmm10
000071e7f4dd4649  vmovaps [rsp+0xB0], xmm11
000071e7f4dd4652  vmovaps [rsp+0xC0], xmm12
000071e7f4dd465b  vmovaps [rsp+0xD0], xmm13
000071e7f4dd4664  vmovaps [rsp+0xE0], xmm14
000071e7f4dd466d  sub rsp, 0x30
000071e7f4dd4671  movaps [rsp], xmm15
000071e7f4dd4676  movaps [rsp+0x10], xmm10
000071e7f4dd467c  movaps [rsp+0x20], xmm13
000071e7f4dd4682  lea rdi, [rsp]
000071e7f4dd4686  mov esi, 0x00
000071e7f4dd468b  mov rax, 0x562A51E82530
000071e7f4dd4695  call rax
000071e7f4dd4697  movaps xmm15, [rsp]
000071e7f4dd469c  add rsp, 0x30
000071e7f4dd46a0  vmovaps xmm0, [rsp]
000071e7f4dd46a5  vmovaps xmm1, [rsp+0x10]
000071e7f4dd46ab  vmovaps xmm2, [rsp+0x20]
000071e7f4dd46b1  vmovaps xmm3, [rsp+0x30]
000071e7f4dd46b7  vmovaps xmm4, [rsp+0x40]
000071e7f4dd46bd  vmovaps xmm5, [rsp+0x50]
000071e7f4dd46c3  vmovaps xmm6, [rsp+0x60]
000071e7f4dd46c9  vmovaps xmm7, [rsp+0x70]
000071e7f4dd46cf  vmovaps xmm8, [rsp+0x80]
000071e7f4dd46d8  vmovaps xmm9, [rsp+0x90]
000071e7f4dd46e1  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd46ea  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd46f3  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd46fc  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd4705  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd470e  add rsp, 0xF0
000071e7f4dd4715  pop r11
000071e7f4dd4717  pop r10
000071e7f4dd4719  pop r9
000071e7f4dd471b  pop r8
000071e7f4dd471d  pop rsi
000071e7f4dd471e  pop rdi
000071e7f4dd471f  pop rdx
000071e7f4dd4720  pop rcx
000071e7f4dd4721  pop rax
000071e7f4dd4722  add rsp, 0x08
000071e7f4dd4726  jmp 0x000071E7F4DD013D
000071e7f4dd472b  sub rsp, 0x08
000071e7f4dd472f  push rax
000071e7f4dd4730  push rcx
000071e7f4dd4731  push rdx
000071e7f4dd4732  push rdi
000071e7f4dd4733  push rsi
000071e7f4dd4734  push r8
000071e7f4dd4736  push r9
000071e7f4dd4738  push r10
000071e7f4dd473a  push r11
000071e7f4dd473c  sub rsp, 0xF0
000071e7f4dd4743  vmovaps [rsp], xmm0
000071e7f4dd4748  vmovaps [rsp+0x10], xmm1
000071e7f4dd474e  vmovaps [rsp+0x20], xmm2
000071e7f4dd4754  vmovaps [rsp+0x30], xmm3
000071e7f4dd475a  vmovaps [rsp+0x40], xmm4
000071e7f4dd4760  vmovaps [rsp+0x50], xmm5
000071e7f4dd4766  vmovaps [rsp+0x60], xmm6
000071e7f4dd476c  vmovaps [rsp+0x70], xmm7
000071e7f4dd4772  vmovaps [rsp+0x80], xmm8
000071e7f4dd477b  vmovaps [rsp+0x90], xmm9
000071e7f4dd4784  vmovaps [rsp+0xA0], xmm11
000071e7f4dd478d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd4796  vmovaps [rsp+0xC0], xmm13
000071e7f4dd479f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd47a8  vmovaps [rsp+0xE0], xmm15
000071e7f4dd47b1  sub rsp, 0x30
000071e7f4dd47b5  movaps [rsp], xmm10
000071e7f4dd47ba  movaps [rsp+0x10], xmm7
000071e7f4dd47bf  movaps [rsp+0x20], xmm13
000071e7f4dd47c5  lea rdi, [rsp]
000071e7f4dd47c9  mov esi, 0x00
000071e7f4dd47ce  mov rax, 0x562A51E82530
000071e7f4dd47d8  call rax
000071e7f4dd47da  movaps xmm10, [rsp]
000071e7f4dd47df  add rsp, 0x30
000071e7f4dd47e3  vmovaps xmm0, [rsp]
000071e7f4dd47e8  vmovaps xmm1, [rsp+0x10]
000071e7f4dd47ee  vmovaps xmm2, [rsp+0x20]
000071e7f4dd47f4  vmovaps xmm3, [rsp+0x30]
000071e7f4dd47fa  vmovaps xmm4, [rsp+0x40]
000071e7f4dd4800  vmovaps xmm5, [rsp+0x50]
000071e7f4dd4806  vmovaps xmm6, [rsp+0x60]
000071e7f4dd480c  vmovaps xmm7, [rsp+0x70]
000071e7f4dd4812  vmovaps xmm8, [rsp+0x80]
000071e7f4dd481b  vmovaps xmm9, [rsp+0x90]
000071e7f4dd4824  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd482d  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd4836  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd483f  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd4848  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4851  add rsp, 0xF0
000071e7f4dd4858  pop r11
000071e7f4dd485a  pop r10
000071e7f4dd485c  pop r9
000071e7f4dd485e  pop r8
000071e7f4dd4860  pop rsi
000071e7f4dd4861  pop rdi
000071e7f4dd4862  pop rdx
000071e7f4dd4863  pop rcx
000071e7f4dd4864  pop rax
000071e7f4dd4865  add rsp, 0x08
000071e7f4dd4869  jmp 0x000071E7F4DD0169
000071e7f4dd486e  sub rsp, 0x08
000071e7f4dd4872  push rax
000071e7f4dd4873  push rcx
000071e7f4dd4874  push rdx
000071e7f4dd4875  push rdi
000071e7f4dd4876  push rsi
000071e7f4dd4877  push r8
000071e7f4dd4879  push r9
000071e7f4dd487b  push r10
000071e7f4dd487d  push r11
000071e7f4dd487f  sub rsp, 0xF0
000071e7f4dd4886  vmovaps [rsp], xmm0
000071e7f4dd488b  vmovaps [rsp+0x10], xmm1
000071e7f4dd4891  vmovaps [rsp+0x20], xmm2
000071e7f4dd4897  vmovaps [rsp+0x30], xmm3
000071e7f4dd489d  vmovaps [rsp+0x40], xmm4
000071e7f4dd48a3  vmovaps [rsp+0x50], xmm5
000071e7f4dd48a9  vmovaps [rsp+0x60], xmm6
000071e7f4dd48af  vmovaps [rsp+0x70], xmm7
000071e7f4dd48b5  vmovaps [rsp+0x80], xmm8
000071e7f4dd48be  vmovaps [rsp+0x90], xmm9
000071e7f4dd48c7  vmovaps [rsp+0xA0], xmm10
000071e7f4dd48d0  vmovaps [rsp+0xB0], xmm11
000071e7f4dd48d9  vmovaps [rsp+0xC0], xmm12
000071e7f4dd48e2  vmovaps [rsp+0xD0], xmm14
000071e7f4dd48eb  vmovaps [rsp+0xE0], xmm15
000071e7f4dd48f4  sub rsp, 0x30
000071e7f4dd48f8  movaps [rsp], xmm13
000071e7f4dd48fd  movaps [rsp+0x10], xmm1
000071e7f4dd4902  movaps [rsp+0x20], xmm8
000071e7f4dd4908  lea rdi, [rsp]
000071e7f4dd490c  mov esi, 0x00
000071e7f4dd4911  mov rax, 0x562A51E82530
000071e7f4dd491b  call rax
000071e7f4dd491d  movaps xmm13, [rsp]
000071e7f4dd4922  add rsp, 0x30
000071e7f4dd4926  vmovaps xmm0, [rsp]
000071e7f4dd492b  vmovaps xmm1, [rsp+0x10]
000071e7f4dd4931  vmovaps xmm2, [rsp+0x20]
000071e7f4dd4937  vmovaps xmm3, [rsp+0x30]
000071e7f4dd493d  vmovaps xmm4, [rsp+0x40]
000071e7f4dd4943  vmovaps xmm5, [rsp+0x50]
000071e7f4dd4949  vmovaps xmm6, [rsp+0x60]
000071e7f4dd494f  vmovaps xmm7, [rsp+0x70]
000071e7f4dd4955  vmovaps xmm8, [rsp+0x80]
000071e7f4dd495e  vmovaps xmm9, [rsp+0x90]
000071e7f4dd4967  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd4970  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd4979  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd4982  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd498b  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4994  add rsp, 0xF0
000071e7f4dd499b  pop r11
000071e7f4dd499d  pop r10
000071e7f4dd499f  pop r9
000071e7f4dd49a1  pop r8
000071e7f4dd49a3  pop rsi
000071e7f4dd49a4  pop rdi
000071e7f4dd49a5  pop rdx
000071e7f4dd49a6  pop rcx
000071e7f4dd49a7  pop rax
000071e7f4dd49a8  add rsp, 0x08
000071e7f4dd49ac  jmp 0x000071E7F4DD0183
000071e7f4dd49b1  call 0x000071E7F4BFF430
000071e7f4dd49b6  jmp 0x000071E7F4DD018D
000071e7f4dd49bb  sub rsp, 0x08
000071e7f4dd49bf  push rax
000071e7f4dd49c0  push rcx
000071e7f4dd49c1  push rdx
000071e7f4dd49c2  push rdi
000071e7f4dd49c3  push rsi
000071e7f4dd49c4  push r8
000071e7f4dd49c6  push r9
000071e7f4dd49c8  push r10
000071e7f4dd49ca  push r11
000071e7f4dd49cc  sub rsp, 0xF0
000071e7f4dd49d3  vmovaps [rsp], xmm0
000071e7f4dd49d8  vmovaps [rsp+0x10], xmm1
000071e7f4dd49de  vmovaps [rsp+0x20], xmm2
000071e7f4dd49e4  vmovaps [rsp+0x30], xmm3
000071e7f4dd49ea  vmovaps [rsp+0x40], xmm4
000071e7f4dd49f0  vmovaps [rsp+0x50], xmm5
000071e7f4dd49f6  vmovaps [rsp+0x60], xmm6
000071e7f4dd49fc  vmovaps [rsp+0x70], xmm7
000071e7f4dd4a02  vmovaps [rsp+0x80], xmm9
000071e7f4dd4a0b  vmovaps [rsp+0x90], xmm10
000071e7f4dd4a14  vmovaps [rsp+0xA0], xmm11
000071e7f4dd4a1d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd4a26  vmovaps [rsp+0xC0], xmm13
000071e7f4dd4a2f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd4a38  vmovaps [rsp+0xE0], xmm15
000071e7f4dd4a41  sub rsp, 0x30
000071e7f4dd4a45  movaps [rsp], xmm8
000071e7f4dd4a4a  movaps [rsp+0x10], xmm14
000071e7f4dd4a50  movaps [rsp+0x20], xmm9
000071e7f4dd4a56  lea rdi, [rsp]
000071e7f4dd4a5a  mov esi, 0x00
000071e7f4dd4a5f  mov rax, 0x562A51E82530
000071e7f4dd4a69  call rax
000071e7f4dd4a6b  movaps xmm8, [rsp]
000071e7f4dd4a70  add rsp, 0x30
000071e7f4dd4a74  vmovaps xmm0, [rsp]
000071e7f4dd4a79  vmovaps xmm1, [rsp+0x10]
000071e7f4dd4a7f  vmovaps xmm2, [rsp+0x20]
000071e7f4dd4a85  vmovaps xmm3, [rsp+0x30]
000071e7f4dd4a8b  vmovaps xmm4, [rsp+0x40]
000071e7f4dd4a91  vmovaps xmm5, [rsp+0x50]
000071e7f4dd4a97  vmovaps xmm6, [rsp+0x60]
000071e7f4dd4a9d  vmovaps xmm7, [rsp+0x70]
000071e7f4dd4aa3  vmovaps xmm9, [rsp+0x80]
000071e7f4dd4aac  vmovaps xmm10, [rsp+0x90]
000071e7f4dd4ab5  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd4abe  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd4ac7  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd4ad0  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd4ad9  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4ae2  add rsp, 0xF0
000071e7f4dd4ae9  pop r11
000071e7f4dd4aeb  pop r10
000071e7f4dd4aed  pop r9
000071e7f4dd4aef  pop r8
000071e7f4dd4af1  pop rsi
000071e7f4dd4af2  pop rdi
000071e7f4dd4af3  pop rdx
000071e7f4dd4af4  pop rcx
000071e7f4dd4af5  pop rax
000071e7f4dd4af6  add rsp, 0x08
000071e7f4dd4afa  jmp 0x000071E7F4DD01AF
000071e7f4dd4aff  sub rsp, 0x08
000071e7f4dd4b03  push rax
000071e7f4dd4b04  push rcx
000071e7f4dd4b05  push rdx
000071e7f4dd4b06  push rdi
000071e7f4dd4b07  push rsi
000071e7f4dd4b08  push r8
000071e7f4dd4b0a  push r9
000071e7f4dd4b0c  push r10
000071e7f4dd4b0e  push r11
000071e7f4dd4b10  sub rsp, 0xF0
000071e7f4dd4b17  vmovaps [rsp], xmm0
000071e7f4dd4b1c  vmovaps [rsp+0x10], xmm1
000071e7f4dd4b22  vmovaps [rsp+0x20], xmm2
000071e7f4dd4b28  vmovaps [rsp+0x30], xmm3
000071e7f4dd4b2e  vmovaps [rsp+0x40], xmm4
000071e7f4dd4b34  vmovaps [rsp+0x50], xmm5
000071e7f4dd4b3a  vmovaps [rsp+0x60], xmm6
000071e7f4dd4b40  vmovaps [rsp+0x70], xmm7
000071e7f4dd4b46  vmovaps [rsp+0x80], xmm8
000071e7f4dd4b4f  vmovaps [rsp+0x90], xmm10
000071e7f4dd4b58  vmovaps [rsp+0xA0], xmm11
000071e7f4dd4b61  vmovaps [rsp+0xB0], xmm12
000071e7f4dd4b6a  vmovaps [rsp+0xC0], xmm13
000071e7f4dd4b73  vmovaps [rsp+0xD0], xmm14
000071e7f4dd4b7c  vmovaps [rsp+0xE0], xmm15
000071e7f4dd4b85  sub rsp, 0x30
000071e7f4dd4b89  movaps [rsp], xmm9
000071e7f4dd4b8e  movaps [rsp+0x10], xmm1
000071e7f4dd4b93  movaps [rsp+0x20], xmm14
000071e7f4dd4b99  lea rdi, [rsp]
000071e7f4dd4b9d  mov esi, 0x00
000071e7f4dd4ba2  mov rax, 0x562A51E82530
000071e7f4dd4bac  call rax
000071e7f4dd4bae  movaps xmm9, [rsp]
000071e7f4dd4bb3  add rsp, 0x30
000071e7f4dd4bb7  vmovaps xmm0, [rsp]
000071e7f4dd4bbc  vmovaps xmm1, [rsp+0x10]
000071e7f4dd4bc2  vmovaps xmm2, [rsp+0x20]
000071e7f4dd4bc8  vmovaps xmm3, [rsp+0x30]
000071e7f4dd4bce  vmovaps xmm4, [rsp+0x40]
000071e7f4dd4bd4  vmovaps xmm5, [rsp+0x50]
000071e7f4dd4bda  vmovaps xmm6, [rsp+0x60]
000071e7f4dd4be0  vmovaps xmm7, [rsp+0x70]
000071e7f4dd4be6  vmovaps xmm8, [rsp+0x80]
000071e7f4dd4bef  vmovaps xmm10, [rsp+0x90]
000071e7f4dd4bf8  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd4c01  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd4c0a  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd4c13  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd4c1c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4c25  add rsp, 0xF0
000071e7f4dd4c2c  pop r11
000071e7f4dd4c2e  pop r10
000071e7f4dd4c30  pop r9
000071e7f4dd4c32  pop r8
000071e7f4dd4c34  pop rsi
000071e7f4dd4c35  pop rdi
000071e7f4dd4c36  pop rdx
000071e7f4dd4c37  pop rcx
000071e7f4dd4c38  pop rax
000071e7f4dd4c39  add rsp, 0x08
000071e7f4dd4c3d  jmp 0x000071E7F4DD01DD
000071e7f4dd4c42  sub rsp, 0x08
000071e7f4dd4c46  push rax
000071e7f4dd4c47  push rcx
000071e7f4dd4c48  push rdx
000071e7f4dd4c49  push rdi
000071e7f4dd4c4a  push rsi
000071e7f4dd4c4b  push r8
000071e7f4dd4c4d  push r9
000071e7f4dd4c4f  push r10
000071e7f4dd4c51  push r11
000071e7f4dd4c53  sub rsp, 0xF0
000071e7f4dd4c5a  vmovaps [rsp], xmm0
000071e7f4dd4c5f  vmovaps [rsp+0x10], xmm1
000071e7f4dd4c65  vmovaps [rsp+0x20], xmm2
000071e7f4dd4c6b  vmovaps [rsp+0x30], xmm3
000071e7f4dd4c71  vmovaps [rsp+0x40], xmm4
000071e7f4dd4c77  vmovaps [rsp+0x50], xmm5
000071e7f4dd4c7d  vmovaps [rsp+0x60], xmm6
000071e7f4dd4c83  vmovaps [rsp+0x70], xmm7
000071e7f4dd4c89  vmovaps [rsp+0x80], xmm8
000071e7f4dd4c92  vmovaps [rsp+0x90], xmm9
000071e7f4dd4c9b  vmovaps [rsp+0xA0], xmm10
000071e7f4dd4ca4  vmovaps [rsp+0xB0], xmm11
000071e7f4dd4cad  vmovaps [rsp+0xC0], xmm12
000071e7f4dd4cb6  vmovaps [rsp+0xD0], xmm13
000071e7f4dd4cbf  vmovaps [rsp+0xE0], xmm15
000071e7f4dd4cc8  sub rsp, 0x30
000071e7f4dd4ccc  movaps [rsp], xmm14
000071e7f4dd4cd1  movaps [rsp+0x10], xmm4
000071e7f4dd4cd6  movaps [rsp+0x20], xmm1
000071e7f4dd4cdb  lea rdi, [rsp]
000071e7f4dd4cdf  mov esi, 0x00
000071e7f4dd4ce4  mov rax, 0x562A51E82530
000071e7f4dd4cee  call rax
000071e7f4dd4cf0  movaps xmm14, [rsp]
000071e7f4dd4cf5  add rsp, 0x30
000071e7f4dd4cf9  vmovaps xmm0, [rsp]
000071e7f4dd4cfe  vmovaps xmm1, [rsp+0x10]
000071e7f4dd4d04  vmovaps xmm2, [rsp+0x20]
000071e7f4dd4d0a  vmovaps xmm3, [rsp+0x30]
000071e7f4dd4d10  vmovaps xmm4, [rsp+0x40]
000071e7f4dd4d16  vmovaps xmm5, [rsp+0x50]
000071e7f4dd4d1c  vmovaps xmm6, [rsp+0x60]
000071e7f4dd4d22  vmovaps xmm7, [rsp+0x70]
000071e7f4dd4d28  vmovaps xmm8, [rsp+0x80]
000071e7f4dd4d31  vmovaps xmm9, [rsp+0x90]
000071e7f4dd4d3a  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd4d43  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd4d4c  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd4d55  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd4d5e  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4d67  add rsp, 0xF0
000071e7f4dd4d6e  pop r11
000071e7f4dd4d70  pop r10
000071e7f4dd4d72  pop r9
000071e7f4dd4d74  pop r8
000071e7f4dd4d76  pop rsi
000071e7f4dd4d77  pop rdi
000071e7f4dd4d78  pop rdx
000071e7f4dd4d79  pop rcx
000071e7f4dd4d7a  pop rax
000071e7f4dd4d7b  add rsp, 0x08
000071e7f4dd4d7f  jmp 0x000071E7F4DD0203
000071e7f4dd4d84  sub rsp, 0x08
000071e7f4dd4d88  push rax
000071e7f4dd4d89  push rcx
000071e7f4dd4d8a  push rdx
000071e7f4dd4d8b  push rdi
000071e7f4dd4d8c  push rsi
000071e7f4dd4d8d  push r8
000071e7f4dd4d8f  push r9
000071e7f4dd4d91  push r10
000071e7f4dd4d93  push r11
000071e7f4dd4d95  sub rsp, 0xF0
000071e7f4dd4d9c  vmovaps [rsp], xmm0
000071e7f4dd4da1  vmovaps [rsp+0x10], xmm2
000071e7f4dd4da7  vmovaps [rsp+0x20], xmm3
000071e7f4dd4dad  vmovaps [rsp+0x30], xmm4
000071e7f4dd4db3  vmovaps [rsp+0x40], xmm5
000071e7f4dd4db9  vmovaps [rsp+0x50], xmm6
000071e7f4dd4dbf  vmovaps [rsp+0x60], xmm7
000071e7f4dd4dc5  vmovaps [rsp+0x70], xmm8
000071e7f4dd4dcb  vmovaps [rsp+0x80], xmm9
000071e7f4dd4dd4  vmovaps [rsp+0x90], xmm10
000071e7f4dd4ddd  vmovaps [rsp+0xA0], xmm11
000071e7f4dd4de6  vmovaps [rsp+0xB0], xmm12
000071e7f4dd4def  vmovaps [rsp+0xC0], xmm13
000071e7f4dd4df8  vmovaps [rsp+0xD0], xmm14
000071e7f4dd4e01  vmovaps [rsp+0xE0], xmm15
000071e7f4dd4e0a  sub rsp, 0x30
000071e7f4dd4e0e  movaps [rsp], xmm1
000071e7f4dd4e12  movaps [rsp+0x10], xmm12
000071e7f4dd4e18  movaps [rsp+0x20], xmm11
000071e7f4dd4e1e  lea rdi, [rsp]
000071e7f4dd4e22  mov esi, 0x00
000071e7f4dd4e27  mov rax, 0x562A51E82530
000071e7f4dd4e31  call rax
000071e7f4dd4e33  movaps xmm1, [rsp]
000071e7f4dd4e37  add rsp, 0x30
000071e7f4dd4e3b  vmovaps xmm0, [rsp]
000071e7f4dd4e40  vmovaps xmm2, [rsp+0x10]
000071e7f4dd4e46  vmovaps xmm3, [rsp+0x20]
000071e7f4dd4e4c  vmovaps xmm4, [rsp+0x30]
000071e7f4dd4e52  vmovaps xmm5, [rsp+0x40]
000071e7f4dd4e58  vmovaps xmm6, [rsp+0x50]
000071e7f4dd4e5e  vmovaps xmm7, [rsp+0x60]
000071e7f4dd4e64  vmovaps xmm8, [rsp+0x70]
000071e7f4dd4e6a  vmovaps xmm9, [rsp+0x80]
000071e7f4dd4e73  vmovaps xmm10, [rsp+0x90]
000071e7f4dd4e7c  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd4e85  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd4e8e  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd4e97  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd4ea0  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4ea9  add rsp, 0xF0
000071e7f4dd4eb0  pop r11
000071e7f4dd4eb2  pop r10
000071e7f4dd4eb4  pop r9
000071e7f4dd4eb6  pop r8
000071e7f4dd4eb8  pop rsi
000071e7f4dd4eb9  pop rdi
000071e7f4dd4eba  pop rdx
000071e7f4dd4ebb  pop rcx
000071e7f4dd4ebc  pop rax
000071e7f4dd4ebd  add rsp, 0x08
000071e7f4dd4ec1  jmp 0x000071E7F4DD0224
000071e7f4dd4ec6  call 0x000071E7F4CE20A0
000071e7f4dd4ecb  jmp 0x000071E7F4DD0232
000071e7f4dd4ed0  call 0x000071E7F4C09D70
000071e7f4dd4ed5  jmp 0x000071E7F4DD023C
000071e7f4dd4eda  sub rsp, 0x08
000071e7f4dd4ede  push rax
000071e7f4dd4edf  push rcx
000071e7f4dd4ee0  push rdx
000071e7f4dd4ee1  push rdi
000071e7f4dd4ee2  push rsi
000071e7f4dd4ee3  push r8
000071e7f4dd4ee5  push r9
000071e7f4dd4ee7  push r10
000071e7f4dd4ee9  push r11
000071e7f4dd4eeb  sub rsp, 0xF0
000071e7f4dd4ef2  vmovaps [rsp], xmm0
000071e7f4dd4ef7  vmovaps [rsp+0x10], xmm1
000071e7f4dd4efd  vmovaps [rsp+0x20], xmm2
000071e7f4dd4f03  vmovaps [rsp+0x30], xmm3
000071e7f4dd4f09  vmovaps [rsp+0x40], xmm4
000071e7f4dd4f0f  vmovaps [rsp+0x50], xmm5
000071e7f4dd4f15  vmovaps [rsp+0x60], xmm6
000071e7f4dd4f1b  vmovaps [rsp+0x70], xmm8
000071e7f4dd4f21  vmovaps [rsp+0x80], xmm9
000071e7f4dd4f2a  vmovaps [rsp+0x90], xmm10
000071e7f4dd4f33  vmovaps [rsp+0xA0], xmm11
000071e7f4dd4f3c  vmovaps [rsp+0xB0], xmm12
000071e7f4dd4f45  vmovaps [rsp+0xC0], xmm13
000071e7f4dd4f4e  vmovaps [rsp+0xD0], xmm14
000071e7f4dd4f57  vmovaps [rsp+0xE0], xmm15
000071e7f4dd4f60  sub rsp, 0x30
000071e7f4dd4f64  movaps [rsp], xmm7
000071e7f4dd4f68  movaps [rsp+0x10], xmm15
000071e7f4dd4f6e  movaps [rsp+0x20], xmm10
000071e7f4dd4f74  lea rdi, [rsp]
000071e7f4dd4f78  mov esi, 0x00
000071e7f4dd4f7d  mov rax, 0x562A51E82530
000071e7f4dd4f87  call rax
000071e7f4dd4f89  movaps xmm7, [rsp]
000071e7f4dd4f8d  add rsp, 0x30
000071e7f4dd4f91  vmovaps xmm0, [rsp]
000071e7f4dd4f96  vmovaps xmm1, [rsp+0x10]
000071e7f4dd4f9c  vmovaps xmm2, [rsp+0x20]
000071e7f4dd4fa2  vmovaps xmm3, [rsp+0x30]
000071e7f4dd4fa8  vmovaps xmm4, [rsp+0x40]
000071e7f4dd4fae  vmovaps xmm5, [rsp+0x50]
000071e7f4dd4fb4  vmovaps xmm6, [rsp+0x60]
000071e7f4dd4fba  vmovaps xmm8, [rsp+0x70]
000071e7f4dd4fc0  vmovaps xmm9, [rsp+0x80]
000071e7f4dd4fc9  vmovaps xmm10, [rsp+0x90]
000071e7f4dd4fd2  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd4fdb  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd4fe4  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd4fed  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd4ff6  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd4fff  add rsp, 0xF0
000071e7f4dd5006  pop r11
000071e7f4dd5008  pop r10
000071e7f4dd500a  pop r9
000071e7f4dd500c  pop r8
000071e7f4dd500e  pop rsi
000071e7f4dd500f  pop rdi
000071e7f4dd5010  pop rdx
000071e7f4dd5011  pop rcx
000071e7f4dd5012  pop rax
000071e7f4dd5013  add rsp, 0x08
000071e7f4dd5017  jmp 0x000071E7F4DD025D
000071e7f4dd501c  sub rsp, 0x08
000071e7f4dd5020  push rax
000071e7f4dd5021  push rcx
000071e7f4dd5022  push rdx
000071e7f4dd5023  push rdi
000071e7f4dd5024  push rsi
000071e7f4dd5025  push r8
000071e7f4dd5027  push r9
000071e7f4dd5029  push r10
000071e7f4dd502b  push r11
000071e7f4dd502d  sub rsp, 0xF0
000071e7f4dd5034  vmovaps [rsp], xmm0
000071e7f4dd5039  vmovaps [rsp+0x10], xmm1
000071e7f4dd503f  vmovaps [rsp+0x20], xmm2
000071e7f4dd5045  vmovaps [rsp+0x30], xmm3
000071e7f4dd504b  vmovaps [rsp+0x40], xmm4
000071e7f4dd5051  vmovaps [rsp+0x50], xmm5
000071e7f4dd5057  vmovaps [rsp+0x60], xmm6
000071e7f4dd505d  vmovaps [rsp+0x70], xmm7
000071e7f4dd5063  vmovaps [rsp+0x80], xmm8
000071e7f4dd506c  vmovaps [rsp+0x90], xmm9
000071e7f4dd5075  vmovaps [rsp+0xA0], xmm11
000071e7f4dd507e  vmovaps [rsp+0xB0], xmm12
000071e7f4dd5087  vmovaps [rsp+0xC0], xmm13
000071e7f4dd5090  vmovaps [rsp+0xD0], xmm14
000071e7f4dd5099  vmovaps [rsp+0xE0], xmm15
000071e7f4dd50a2  sub rsp, 0x30
000071e7f4dd50a6  movaps [rsp], xmm10
000071e7f4dd50ab  movaps [rsp+0x10], xmm11
000071e7f4dd50b1  movaps [rsp+0x20], xmm15
000071e7f4dd50b7  lea rdi, [rsp]
000071e7f4dd50bb  mov esi, 0x00
000071e7f4dd50c0  mov rax, 0x562A51E82530
000071e7f4dd50ca  call rax
000071e7f4dd50cc  movaps xmm10, [rsp]
000071e7f4dd50d1  add rsp, 0x30
000071e7f4dd50d5  vmovaps xmm0, [rsp]
000071e7f4dd50da  vmovaps xmm1, [rsp+0x10]
000071e7f4dd50e0  vmovaps xmm2, [rsp+0x20]
000071e7f4dd50e6  vmovaps xmm3, [rsp+0x30]
000071e7f4dd50ec  vmovaps xmm4, [rsp+0x40]
000071e7f4dd50f2  vmovaps xmm5, [rsp+0x50]
000071e7f4dd50f8  vmovaps xmm6, [rsp+0x60]
000071e7f4dd50fe  vmovaps xmm7, [rsp+0x70]
000071e7f4dd5104  vmovaps xmm8, [rsp+0x80]
000071e7f4dd510d  vmovaps xmm9, [rsp+0x90]
000071e7f4dd5116  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd511f  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd5128  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd5131  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd513a  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd5143  add rsp, 0xF0
000071e7f4dd514a  pop r11
000071e7f4dd514c  pop r10
000071e7f4dd514e  pop r9
000071e7f4dd5150  pop r8
000071e7f4dd5152  pop rsi
000071e7f4dd5153  pop rdi
000071e7f4dd5154  pop rdx
000071e7f4dd5155  pop rcx
000071e7f4dd5156  pop rax
000071e7f4dd5157  add rsp, 0x08
000071e7f4dd515b  jmp 0x000071E7F4DD028B
000071e7f4dd5160  sub rsp, 0x08
000071e7f4dd5164  push rax
000071e7f4dd5165  push rcx
000071e7f4dd5166  push rdx
000071e7f4dd5167  push rdi
000071e7f4dd5168  push rsi
000071e7f4dd5169  push r8
000071e7f4dd516b  push r9
000071e7f4dd516d  push r10
000071e7f4dd516f  push r11
000071e7f4dd5171  sub rsp, 0xF0
000071e7f4dd5178  vmovaps [rsp], xmm0
000071e7f4dd517d  vmovaps [rsp+0x10], xmm1
000071e7f4dd5183  vmovaps [rsp+0x20], xmm2
000071e7f4dd5189  vmovaps [rsp+0x30], xmm3
000071e7f4dd518f  vmovaps [rsp+0x40], xmm4
000071e7f4dd5195  vmovaps [rsp+0x50], xmm5
000071e7f4dd519b  vmovaps [rsp+0x60], xmm6
000071e7f4dd51a1  vmovaps [rsp+0x70], xmm7
000071e7f4dd51a7  vmovaps [rsp+0x80], xmm8
000071e7f4dd51b0  vmovaps [rsp+0x90], xmm9
000071e7f4dd51b9  vmovaps [rsp+0xA0], xmm10
000071e7f4dd51c2  vmovaps [rsp+0xB0], xmm12
000071e7f4dd51cb  vmovaps [rsp+0xC0], xmm13
000071e7f4dd51d4  vmovaps [rsp+0xD0], xmm14
000071e7f4dd51dd  vmovaps [rsp+0xE0], xmm15
000071e7f4dd51e6  sub rsp, 0x30
000071e7f4dd51ea  movaps [rsp], xmm11
000071e7f4dd51ef  movaps [rsp+0x10], xmm12
000071e7f4dd51f5  movaps [rsp+0x20], xmm15
000071e7f4dd51fb  lea rdi, [rsp]
000071e7f4dd51ff  mov esi, 0x00
000071e7f4dd5204  mov rax, 0x562A51E82530
000071e7f4dd520e  call rax
000071e7f4dd5210  movaps xmm11, [rsp]
000071e7f4dd5215  add rsp, 0x30
000071e7f4dd5219  vmovaps xmm0, [rsp]
000071e7f4dd521e  vmovaps xmm1, [rsp+0x10]
000071e7f4dd5224  vmovaps xmm2, [rsp+0x20]
000071e7f4dd522a  vmovaps xmm3, [rsp+0x30]
000071e7f4dd5230  vmovaps xmm4, [rsp+0x40]
000071e7f4dd5236  vmovaps xmm5, [rsp+0x50]
000071e7f4dd523c  vmovaps xmm6, [rsp+0x60]
000071e7f4dd5242  vmovaps xmm7, [rsp+0x70]
000071e7f4dd5248  vmovaps xmm8, [rsp+0x80]
000071e7f4dd5251  vmovaps xmm9, [rsp+0x90]
000071e7f4dd525a  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd5263  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd526c  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd5275  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd527e  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd5287  add rsp, 0xF0
000071e7f4dd528e  pop r11
000071e7f4dd5290  pop r10
000071e7f4dd5292  pop r9
000071e7f4dd5294  pop r8
000071e7f4dd5296  pop rsi
000071e7f4dd5297  pop rdi
000071e7f4dd5298  pop rdx
000071e7f4dd5299  pop rcx
000071e7f4dd529a  pop rax
000071e7f4dd529b  add rsp, 0x08
000071e7f4dd529f  jmp 0x000071E7F4DD02B9
000071e7f4dd52a4  sub rsp, 0x08
000071e7f4dd52a8  push rax
000071e7f4dd52a9  push rcx
000071e7f4dd52aa  push rdx
000071e7f4dd52ab  push rdi
000071e7f4dd52ac  push rsi
000071e7f4dd52ad  push r8
000071e7f4dd52af  push r9
000071e7f4dd52b1  push r10
000071e7f4dd52b3  push r11
000071e7f4dd52b5  sub rsp, 0xF0
000071e7f4dd52bc  vmovaps [rsp], xmm0
000071e7f4dd52c1  vmovaps [rsp+0x10], xmm1
000071e7f4dd52c7  vmovaps [rsp+0x20], xmm2
000071e7f4dd52cd  vmovaps [rsp+0x30], xmm3
000071e7f4dd52d3  vmovaps [rsp+0x40], xmm4
000071e7f4dd52d9  vmovaps [rsp+0x50], xmm5
000071e7f4dd52df  vmovaps [rsp+0x60], xmm6
000071e7f4dd52e5  vmovaps [rsp+0x70], xmm7
000071e7f4dd52eb  vmovaps [rsp+0x80], xmm8
000071e7f4dd52f4  vmovaps [rsp+0x90], xmm9
000071e7f4dd52fd  vmovaps [rsp+0xA0], xmm10
000071e7f4dd5306  vmovaps [rsp+0xB0], xmm11
000071e7f4dd530f  vmovaps [rsp+0xC0], xmm12
000071e7f4dd5318  vmovaps [rsp+0xD0], xmm13
000071e7f4dd5321  vmovaps [rsp+0xE0], xmm14
000071e7f4dd532a  sub rsp, 0x30
000071e7f4dd532e  movaps [rsp], xmm15
000071e7f4dd5333  movaps [rsp+0x10], xmm13
000071e7f4dd5339  movaps [rsp+0x20], xmm9
000071e7f4dd533f  lea rdi, [rsp]
000071e7f4dd5343  mov esi, 0x00
000071e7f4dd5348  mov rax, 0x562A51E82530
000071e7f4dd5352  call rax
000071e7f4dd5354  movaps xmm15, [rsp]
000071e7f4dd5359  add rsp, 0x30
000071e7f4dd535d  vmovaps xmm0, [rsp]
000071e7f4dd5362  vmovaps xmm1, [rsp+0x10]
000071e7f4dd5368  vmovaps xmm2, [rsp+0x20]
000071e7f4dd536e  vmovaps xmm3, [rsp+0x30]
000071e7f4dd5374  vmovaps xmm4, [rsp+0x40]
000071e7f4dd537a  vmovaps xmm5, [rsp+0x50]
000071e7f4dd5380  vmovaps xmm6, [rsp+0x60]
000071e7f4dd5386  vmovaps xmm7, [rsp+0x70]
000071e7f4dd538c  vmovaps xmm8, [rsp+0x80]
000071e7f4dd5395  vmovaps xmm9, [rsp+0x90]
000071e7f4dd539e  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd53a7  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd53b0  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd53b9  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd53c2  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd53cb  add rsp, 0xF0
000071e7f4dd53d2  pop r11
000071e7f4dd53d4  pop r10
000071e7f4dd53d6  pop r9
000071e7f4dd53d8  pop r8
000071e7f4dd53da  pop rsi
000071e7f4dd53db  pop rdi
000071e7f4dd53dc  pop rdx
000071e7f4dd53dd  pop rcx
000071e7f4dd53de  pop rax
000071e7f4dd53df  add rsp, 0x08
000071e7f4dd53e3  jmp 0x000071E7F4DD02D4
000071e7f4dd53e8  sub rsp, 0x08
000071e7f4dd53ec  push rax
000071e7f4dd53ed  push rcx
000071e7f4dd53ee  push rdx
000071e7f4dd53ef  push rdi
000071e7f4dd53f0  push rsi
000071e7f4dd53f1  push r8
000071e7f4dd53f3  push r9
000071e7f4dd53f5  push r10
000071e7f4dd53f7  push r11
000071e7f4dd53f9  sub rsp, 0xF0
000071e7f4dd5400  vmovaps [rsp], xmm0
000071e7f4dd5405  vmovaps [rsp+0x10], xmm1
000071e7f4dd540b  vmovaps [rsp+0x20], xmm2
000071e7f4dd5411  vmovaps [rsp+0x30], xmm3
000071e7f4dd5417  vmovaps [rsp+0x40], xmm4
000071e7f4dd541d  vmovaps [rsp+0x50], xmm5
000071e7f4dd5423  vmovaps [rsp+0x60], xmm6
000071e7f4dd5429  vmovaps [rsp+0x70], xmm7
000071e7f4dd542f  vmovaps [rsp+0x80], xmm8
000071e7f4dd5438  vmovaps [rsp+0x90], xmm9
000071e7f4dd5441  vmovaps [rsp+0xA0], xmm10
000071e7f4dd544a  vmovaps [rsp+0xB0], xmm11
000071e7f4dd5453  vmovaps [rsp+0xC0], xmm12
000071e7f4dd545c  vmovaps [rsp+0xD0], xmm14
000071e7f4dd5465  vmovaps [rsp+0xE0], xmm15
000071e7f4dd546e  sub rsp, 0x30
000071e7f4dd5472  movaps [rsp], xmm13
000071e7f4dd5477  movaps [rsp+0x10], xmm8
000071e7f4dd547d  movaps [rsp+0x20], xmm14
000071e7f4dd5483  lea rdi, [rsp]
000071e7f4dd5487  mov esi, 0x00
000071e7f4dd548c  mov rax, 0x562A51E82530
000071e7f4dd5496  call rax
000071e7f4dd5498  movaps xmm13, [rsp]
000071e7f4dd549d  add rsp, 0x30
000071e7f4dd54a1  vmovaps xmm0, [rsp]
000071e7f4dd54a6  vmovaps xmm1, [rsp+0x10]
000071e7f4dd54ac  vmovaps xmm2, [rsp+0x20]
000071e7f4dd54b2  vmovaps xmm3, [rsp+0x30]
000071e7f4dd54b8  vmovaps xmm4, [rsp+0x40]
000071e7f4dd54be  vmovaps xmm5, [rsp+0x50]
000071e7f4dd54c4  vmovaps xmm6, [rsp+0x60]
000071e7f4dd54ca  vmovaps xmm7, [rsp+0x70]
000071e7f4dd54d0  vmovaps xmm8, [rsp+0x80]
000071e7f4dd54d9  vmovaps xmm9, [rsp+0x90]
000071e7f4dd54e2  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd54eb  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd54f4  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd54fd  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd5506  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd550f  add rsp, 0xF0
000071e7f4dd5516  pop r11
000071e7f4dd5518  pop r10
000071e7f4dd551a  pop r9
000071e7f4dd551c  pop r8
000071e7f4dd551e  pop rsi
000071e7f4dd551f  pop rdi
000071e7f4dd5520  pop rdx
000071e7f4dd5521  pop rcx
000071e7f4dd5522  pop rax
000071e7f4dd5523  add rsp, 0x08
000071e7f4dd5527  jmp 0x000071E7F4DD02F7
000071e7f4dd552c  sub rsp, 0x08
000071e7f4dd5530  push rax
000071e7f4dd5531  push rcx
000071e7f4dd5532  push rdx
000071e7f4dd5533  push rdi
000071e7f4dd5534  push rsi
000071e7f4dd5535  push r8
000071e7f4dd5537  push r9
000071e7f4dd5539  push r10
000071e7f4dd553b  push r11
000071e7f4dd553d  sub rsp, 0xF0
000071e7f4dd5544  vmovaps [rsp], xmm0
000071e7f4dd5549  vmovaps [rsp+0x10], xmm1
000071e7f4dd554f  vmovaps [rsp+0x20], xmm2
000071e7f4dd5555  vmovaps [rsp+0x30], xmm3
000071e7f4dd555b  vmovaps [rsp+0x40], xmm4
000071e7f4dd5561  vmovaps [rsp+0x50], xmm5
000071e7f4dd5567  vmovaps [rsp+0x60], xmm6
000071e7f4dd556d  vmovaps [rsp+0x70], xmm7
000071e7f4dd5573  vmovaps [rsp+0x80], xmm8
000071e7f4dd557c  vmovaps [rsp+0x90], xmm9
000071e7f4dd5585  vmovaps [rsp+0xA0], xmm10
000071e7f4dd558e  vmovaps [rsp+0xB0], xmm11
000071e7f4dd5597  vmovaps [rsp+0xC0], xmm12
000071e7f4dd55a0  vmovaps [rsp+0xD0], xmm13
000071e7f4dd55a9  vmovaps [rsp+0xE0], xmm15
000071e7f4dd55b2  sub rsp, 0x30
000071e7f4dd55b6  movaps [rsp], xmm14
000071e7f4dd55bb  movaps [rsp+0x10], xmm1
000071e7f4dd55c0  movaps [rsp+0x20], xmm10
000071e7f4dd55c6  lea rdi, [rsp]
000071e7f4dd55ca  mov esi, 0x00
000071e7f4dd55cf  mov rax, 0x562A51E82530
000071e7f4dd55d9  call rax
000071e7f4dd55db  movaps xmm14, [rsp]
000071e7f4dd55e0  add rsp, 0x30
000071e7f4dd55e4  vmovaps xmm0, [rsp]
000071e7f4dd55e9  vmovaps xmm1, [rsp+0x10]
000071e7f4dd55ef  vmovaps xmm2, [rsp+0x20]
000071e7f4dd55f5  vmovaps xmm3, [rsp+0x30]
000071e7f4dd55fb  vmovaps xmm4, [rsp+0x40]
000071e7f4dd5601  vmovaps xmm5, [rsp+0x50]
000071e7f4dd5607  vmovaps xmm6, [rsp+0x60]
000071e7f4dd560d  vmovaps xmm7, [rsp+0x70]
000071e7f4dd5613  vmovaps xmm8, [rsp+0x80]
000071e7f4dd561c  vmovaps xmm9, [rsp+0x90]
000071e7f4dd5625  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd562e  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd5637  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd5640  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd5649  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd5652  add rsp, 0xF0
000071e7f4dd5659  pop r11
000071e7f4dd565b  pop r10
000071e7f4dd565d  pop r9
000071e7f4dd565f  pop r8
000071e7f4dd5661  pop rsi
000071e7f4dd5662  pop rdi
000071e7f4dd5663  pop rdx
000071e7f4dd5664  pop rcx
000071e7f4dd5665  pop rax
000071e7f4dd5666  add rsp, 0x08
000071e7f4dd566a  jmp 0x000071E7F4DD031A
000071e7f4dd566f  sub rsp, 0x08
000071e7f4dd5673  push rax
000071e7f4dd5674  push rcx
000071e7f4dd5675  push rdx
000071e7f4dd5676  push rdi
000071e7f4dd5677  push rsi
000071e7f4dd5678  push r8
000071e7f4dd567a  push r9
000071e7f4dd567c  push r10
000071e7f4dd567e  push r11
000071e7f4dd5680  sub rsp, 0xF0
000071e7f4dd5687  vmovaps [rsp], xmm0
000071e7f4dd568c  vmovaps [rsp+0x10], xmm2
000071e7f4dd5692  vmovaps [rsp+0x20], xmm3
000071e7f4dd5698  vmovaps [rsp+0x30], xmm4
000071e7f4dd569e  vmovaps [rsp+0x40], xmm5
000071e7f4dd56a4  vmovaps [rsp+0x50], xmm6
000071e7f4dd56aa  vmovaps [rsp+0x60], xmm7
000071e7f4dd56b0  vmovaps [rsp+0x70], xmm8
000071e7f4dd56b6  vmovaps [rsp+0x80], xmm9
000071e7f4dd56bf  vmovaps [rsp+0x90], xmm10
000071e7f4dd56c8  vmovaps [rsp+0xA0], xmm11
000071e7f4dd56d1  vmovaps [rsp+0xB0], xmm12
000071e7f4dd56da  vmovaps [rsp+0xC0], xmm13
000071e7f4dd56e3  vmovaps [rsp+0xD0], xmm14
000071e7f4dd56ec  vmovaps [rsp+0xE0], xmm15
000071e7f4dd56f5  sub rsp, 0x30
000071e7f4dd56f9  movaps [rsp], xmm1
000071e7f4dd56fd  movaps [rsp+0x10], xmm7
000071e7f4dd5702  movaps [rsp+0x20], xmm11
000071e7f4dd5708  lea rdi, [rsp]
000071e7f4dd570c  mov esi, 0x00
000071e7f4dd5711  mov rax, 0x562A51E82530
000071e7f4dd571b  call rax
000071e7f4dd571d  movaps xmm1, [rsp]
000071e7f4dd5721  add rsp, 0x30
000071e7f4dd5725  vmovaps xmm0, [rsp]
000071e7f4dd572a  vmovaps xmm2, [rsp+0x10]
000071e7f4dd5730  vmovaps xmm3, [rsp+0x20]
000071e7f4dd5736  vmovaps xmm4, [rsp+0x30]
000071e7f4dd573c  vmovaps xmm5, [rsp+0x40]
000071e7f4dd5742  vmovaps xmm6, [rsp+0x50]
000071e7f4dd5748  vmovaps xmm7, [rsp+0x60]
000071e7f4dd574e  vmovaps xmm8, [rsp+0x70]
000071e7f4dd5754  vmovaps xmm9, [rsp+0x80]
000071e7f4dd575d  vmovaps xmm10, [rsp+0x90]
000071e7f4dd5766  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd576f  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd5778  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd5781  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd578a  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd5793  add rsp, 0xF0
000071e7f4dd579a  pop r11
000071e7f4dd579c  pop r10
000071e7f4dd579e  pop r9
000071e7f4dd57a0  pop r8
000071e7f4dd57a2  pop rsi
000071e7f4dd57a3  pop rdi
000071e7f4dd57a4  pop rdx
000071e7f4dd57a5  pop rcx
000071e7f4dd57a6  pop rax
000071e7f4dd57a7  add rsp, 0x08
000071e7f4dd57ab  jmp 0x000071E7F4DD033B
000071e7f4dd57b0  call 0x000071E7F4C0E880
000071e7f4dd57b5  jmp 0x000071E7F4DD034E
000071e7f4dd57ba  call 0x000071E7F4C0C380
000071e7f4dd57bf  jmp 0x000071E7F4DD0359
000071e7f4dd57c4  call 0x000071E7F4C0D600
000071e7f4dd57c9  jmp 0x000071E7F4DD0364
000071e7f4dd57ce  call 0x000071E7F4BFF540
000071e7f4dd57d3  jmp 0x000071E7F4DD036F
000071e7f4dd57d8  int3
000071e7f4dd57d9  nop [rax], eax
000071e7f4dd57e0  mov rax, [r15+0x40]
000071e7f4dd57e4  mov r14, [r15+0x58]
000071e7f4dd57e8  lea r12, [rax+r14*1]
000071e7f4dd57ec  movaps xmm1, [r15+0x1D0]
000071e7f4dd57f4  vmovaps [rsp+0x10], xmm1
000071e7f4dd57fa  vmovaps xmm15, [rsp+0x10]
000071e7f4dd5800  por xmm1, xmm15
000071e7f4dd5805  movaps xmm14, [r15+0x1A0]
000071e7f4dd580d  vmovaps [rsp+0x10], xmm14
000071e7f4dd5813  vmovaps xmm13, [rsp+0x10]
000071e7f4dd5819  por xmm14, xmm13
000071e7f4dd581e  lea rax, [r12+0x30]
000071e7f4dd5823  mov r11, [r13+rax*1]
000071e7f4dd5828  lea rax, [r12+0x38]
000071e7f4dd582d  mov r10, [r13+rax*1]
000071e7f4dd5832  movq xmm13, r11
000071e7f4dd5837  movq xmm12, r10
000071e7f4dd583c  movq xmm13, xmm13
000071e7f4dd5841  vmovaps [rsp+0x10], xmm13
000071e7f4dd5847  movq xmm13, xmm13
000071e7f4dd584c  movaps [r15+0x130], xmm13
000071e7f4dd5854  movq xmm12, xmm12
000071e7f4dd5859  vmovaps [rsp+0x20], xmm12
000071e7f4dd585f  movq xmm12, xmm12
000071e7f4dd5864  movaps [r15+0x280], xmm12
000071e7f4dd586c  movaps xmm13, [r15+0x270]
000071e7f4dd5874  vmovaps [rsp+0x30], xmm13
000071e7f4dd587a  vmovaps xmm12, [rsp+0x30]
000071e7f4dd5880  por xmm13, xmm12
000071e7f4dd5885  lea rax, [r12+0x20]
000071e7f4dd588a  mov r11, [r13+rax*1]
000071e7f4dd588f  lea rax, [r12+0x28]
000071e7f4dd5894  mov r10, [r13+rax*1]
000071e7f4dd5899  movq xmm12, r11
000071e7f4dd589e  movq xmm11, r10
000071e7f4dd58a3  movq xmm12, xmm12
000071e7f4dd58a8  vmovaps [rsp+0x30], xmm12
000071e7f4dd58ae  movq xmm12, xmm12
000071e7f4dd58b3  movaps [r15+0x150], xmm12
000071e7f4dd58bb  movq xmm11, xmm11
000071e7f4dd58c0  vmovaps [rsp+0x40], xmm11
000071e7f4dd58c6  movq xmm11, xmm11
000071e7f4dd58cb  movaps [r15+0x140], xmm11
000071e7f4dd58d3  lea rax, [r12+0x10]
000071e7f4dd58d8  mov r11, [r13+rax*1]
000071e7f4dd58dd  lea rax, [r12+0x18]
000071e7f4dd58e2  mov r10, [r13+rax*1]
000071e7f4dd58e7  movq xmm12, r11
000071e7f4dd58ec  movq xmm11, r10
000071e7f4dd58f1  movq xmm12, xmm12
000071e7f4dd58f6  vmovaps [rsp+0x50], xmm12
000071e7f4dd58fc  movq xmm12, xmm12
000071e7f4dd5901  movaps [r15+0x170], xmm12
000071e7f4dd5909  movq xmm11, xmm11
000071e7f4dd590e  vmovaps [rsp+0x60], xmm11
000071e7f4dd5914  movq xmm11, xmm11
000071e7f4dd5919  movaps [r15+0x160], xmm11
000071e7f4dd5921  mov rax, [r13+r12*1]
000071e7f4dd5926  vmovq xmm12, rax
000071e7f4dd592b  vpbroadcastq xmm12, xmm12
000071e7f4dd5930  lea rax, [r12+0x08]
000071e7f4dd5935  mov r12, [r13+rax*1]
000071e7f4dd593a  movq xmm11, r12
000071e7f4dd593f  movaps [r15+0x230], xmm11
000071e7f4dd5947  mov rax, [r15+0xF8]
000071e7f4dd594e  lea r12, [rax+0x50]
000071e7f4dd5952  movups xmm11, [r13+r12*1]
000071e7f4dd5958  lea r12, [rax+0x60]
000071e7f4dd595c  movups xmm10, [r13+r12*1]
000071e7f4dd5962  lea r12, [rax+0x30]
000071e7f4dd5966  movups xmm9, [r13+r12*1]
000071e7f4dd596c  mov r12, [r15+0x50]
000071e7f4dd5970  lea r11, [r12+r14*1]
000071e7f4dd5974  mov [r15+0x60], r11
000071e7f4dd5978  lea r12, [r14+0x40]
000071e7f4dd597c  mov [r15+0x58], r12
000071e7f4dd5980  movaps xmm8, xmm12
000071e7f4dd5984  mulpd xmm8, xmm15
000071e7f4dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000071e7f4dd598f  ptest xmm7, xmm7
000071e7f4dd5994  jnz 0x000071E7F4DD67B7
000071e7f4dd599a  movq xmm15, qword ptr [r15+0x230]
000071e7f4dd59a3  vmovaps [rsp+0x70], xmm15
000071e7f4dd59a9  vpermilpd xmm15, xmm15, 0x00
000071e7f4dd59af  movaps xmm7, xmm9
000071e7f4dd59b3  mulpd xmm7, xmm15
000071e7f4dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000071e7f4dd59bd  ptest xmm6, xmm6
000071e7f4dd59c2  jnz 0x000071E7F4DD68FB
000071e7f4dd59c8  vxorps xmm15, xmm15, xmm15
000071e7f4dd59cd  vpbroadcastq xmm15, xmm15
000071e7f4dd59d2  movaps xmm9, xmm12
000071e7f4dd59d6  mulpd xmm9, xmm10
000071e7f4dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000071e7f4dd59e1  ptest xmm6, xmm6
000071e7f4dd59e6  jnz 0x000071E7F4DD6A3D
000071e7f4dd59ec  movaps xmm10, xmm12
000071e7f4dd59f0  mulpd xmm10, xmm11
000071e7f4dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000071e7f4dd59fb  ptest xmm6, xmm6
000071e7f4dd5a00  jnz 0x000071E7F4DD6B81
000071e7f4dd5a06  movaps xmm11, [r15+0x1F0]
000071e7f4dd5a0e  movaps xmm6, xmm12
000071e7f4dd5a12  mulpd xmm6, xmm11
000071e7f4dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000071e7f4dd5a1c  ptest xmm5, xmm5
000071e7f4dd5a21  jnz 0x000071E7F4DD6CC5
000071e7f4dd5a27  movaps xmm12, [r15+0x2A0]
000071e7f4dd5a2f  vmovaps [rsp+0x80], xmm12
000071e7f4dd5a38  vmovaps xmm11, [rsp+0x80]
000071e7f4dd5a41  por xmm12, xmm11
000071e7f4dd5a46  movaps xmm11, [r15+0x250]
000071e7f4dd5a4e  vmovaps [rsp+0x80], xmm11
000071e7f4dd5a57  vmovaps xmm5, [rsp+0x80]
000071e7f4dd5a60  por xmm11, xmm5
000071e7f4dd5a65  vmovaps xmm4, [rsp+0x70]
000071e7f4dd5a6b  vpermilpd xmm4, xmm4, 0x00
000071e7f4dd5a71  movaps xmm3, xmm5
000071e7f4dd5a74  mulpd xmm3, xmm4
000071e7f4dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000071e7f4dd5a7d  ptest xmm2, xmm2
000071e7f4dd5a82  jnz 0x000071E7F4DD6E07
000071e7f4dd5a88  mov [rsp+0x80], rax
000071e7f4dd5a90  xor eax, eax
000071e7f4dd5a92  mov r14d, 0x200
000071e7f4dd5a98  cmp r12, r14
000071e7f4dd5a9b  cmc
000071e7f4dd5a9c  lahf
000071e7f4dd5a9d  seto al
000071e7f4dd5aa0  mov [r15+0x108], eax
000071e7f4dd5aa7  movaps xmm5, xmm8
000071e7f4dd5aab  addpd xmm5, xmm15
000071e7f4dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000071e7f4dd5ab5  ptest xmm4, xmm4
000071e7f4dd5aba  jnz 0x000071E7F4DD6F47
000071e7f4dd5ac0  movaps xmm8, [r15+0x1B0]
000071e7f4dd5ac8  movaps xmm4, xmm9
000071e7f4dd5acc  addpd xmm4, xmm8
000071e7f4dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000071e7f4dd5ad6  ptest xmm2, xmm2
000071e7f4dd5adb  jnz 0x000071E7F4DD7089
000071e7f4dd5ae1  movaps xmm9, xmm10
000071e7f4dd5ae5  addpd xmm9, xmm8
000071e7f4dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000071e7f4dd5af0  ptest xmm2, xmm2
000071e7f4dd5af5  jnz 0x000071E7F4DD71CB
000071e7f4dd5afb  movaps xmm10, [r15+0x2F0]
000071e7f4dd5b03  vmovaps [rsp+0x90], xmm10
000071e7f4dd5b0c  vmovaps xmm8, [rsp+0x90]
000071e7f4dd5b15  por xmm10, xmm8
000071e7f4dd5b1a  movaps xmm8, [r15+0x2E0]
000071e7f4dd5b22  vmovaps [rsp+0x90], xmm8
000071e7f4dd5b2b  vmovaps xmm2, [rsp+0x90]
000071e7f4dd5b34  por xmm8, xmm2
000071e7f4dd5b39  movaps xmm2, [r15+0x2D0]
000071e7f4dd5b41  vmovaps [rsp+0x90], xmm2
000071e7f4dd5b4a  vmovaps [rsp+0xA0], xmm1
000071e7f4dd5b53  vmovaps xmm1, [rsp+0x90]
000071e7f4dd5b5c  por xmm2, xmm1
000071e7f4dd5b60  movaps xmm1, [r15+0x200]
000071e7f4dd5b68  vmovaps [rsp+0x90], xmm1
000071e7f4dd5b71  vmovaps [rsp+0xB0], xmm15
000071e7f4dd5b7a  vmovaps xmm15, [rsp+0x90]
000071e7f4dd5b83  por xmm1, xmm15
000071e7f4dd5b88  movaps xmm15, [r15+0x1C0]
000071e7f4dd5b90  vmovaps [rsp+0x90], xmm15
000071e7f4dd5b99  vmovaps [rsp+0xC0], xmm1
000071e7f4dd5ba2  vmovaps xmm1, [rsp+0x90]
000071e7f4dd5bab  por xmm15, xmm1
000071e7f4dd5bb0  movaps xmm1, [r15+0x190]
000071e7f4dd5bb8  vmovaps [rsp+0x90], xmm1
000071e7f4dd5bc1  vmovaps [rsp+0xD0], xmm15
000071e7f4dd5bca  vmovaps xmm15, [rsp+0x90]
000071e7f4dd5bd3  por xmm1, xmm15
000071e7f4dd5bd8  movaps xmm15, [r15+0x300]
000071e7f4dd5be0  vmovaps [rsp+0x90], xmm15
000071e7f4dd5be9  vmovaps [rsp+0xE0], xmm1
000071e7f4dd5bf2  vmovaps xmm1, [rsp+0x90]
000071e7f4dd5bfb  por xmm15, xmm1
000071e7f4dd5c00  mov rax, [rsp+0x80]
000071e7f4dd5c08  lea r14, [rax+0xA0]
000071e7f4dd5c0f  movups xmm1, [r13+r14*1]
000071e7f4dd5c15  lea r14, [rax+0xB0]
000071e7f4dd5c1c  vmovaps [rsp+0x80], xmm1
000071e7f4dd5c25  movups xmm1, [r13+r14*1]
000071e7f4dd5c2b  vmovaps [rsp+0x90], xmm1
000071e7f4dd5c34  vmovaps [rsp+0xF0], xmm15
000071e7f4dd5c3d  vmovaps xmm15, [rsp+0xB0]
000071e7f4dd5c46  vmovaps [rsp+0xB0], xmm14
000071e7f4dd5c4f  movaps xmm1, xmm6
000071e7f4dd5c52  addpd xmm1, xmm15
000071e7f4dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000071e7f4dd5c5c  ptest xmm14, xmm14
000071e7f4dd5c62  jnz 0x000071E7F4DD7323
000071e7f4dd5c68  lea r14, [rax+0xF0]
000071e7f4dd5c6f  movups xmm15, [r13+r14*1]
000071e7f4dd5c75  movaps xmm14, xmm4
000071e7f4dd5c79  addpd xmm14, xmm3
000071e7f4dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000071e7f4dd5c84  ptest xmm6, xmm6
000071e7f4dd5c89  jnz 0x000071E7F4DD746E
000071e7f4dd5c8f  movaps xmm6, xmm9
000071e7f4dd5c93  addpd xmm6, xmm7
000071e7f4dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000071e7f4dd5c9c  ptest xmm4, xmm4
000071e7f4dd5ca1  jnz 0x000071E7F4DD75B0
000071e7f4dd5ca7  vmovaps xmm9, [rsp+0x70]
000071e7f4dd5cad  vpermilpd xmm9, xmm9, 0x00
000071e7f4dd5cb3  vmovaps xmm4, [rsp+0x90]
000071e7f4dd5cbc  movaps xmm7, xmm4
000071e7f4dd5cbf  mulpd xmm7, xmm9
000071e7f4dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000071e7f4dd5cc9  ptest xmm3, xmm3
000071e7f4dd5cce  jnz 0x000071E7F4DD76F1
000071e7f4dd5cd4  vmovaps xmm9, [rsp+0x50]
000071e7f4dd5cda  vpermilpd xmm9, xmm9, 0x00
000071e7f4dd5ce0  movaps xmm4, xmm15
000071e7f4dd5ce4  mulpd xmm4, xmm9
000071e7f4dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000071e7f4dd5cee  ptest xmm3, xmm3
000071e7f4dd5cf3  jnz 0x000071E7F4DD7832
000071e7f4dd5cf9  lea r14, [rax+0xE0]
000071e7f4dd5d00  movups xmm15, [r13+r14*1]
000071e7f4dd5d06  vmovaps xmm9, [rsp+0x70]
000071e7f4dd5d0c  vpermilpd xmm9, xmm9, 0x00
000071e7f4dd5d12  vmovaps [rsp+0x70], xmm1
000071e7f4dd5d18  vmovaps xmm1, [rsp+0x80]
000071e7f4dd5d21  vmovaps [rsp+0x80], xmm15
000071e7f4dd5d2a  movaps xmm3, xmm1
000071e7f4dd5d2d  mulpd xmm3, xmm9
000071e7f4dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000071e7f4dd5d37  ptest xmm15, xmm15
000071e7f4dd5d3d  jnz 0x000071E7F4DD797E
000071e7f4dd5d43  vmovaps xmm1, [rsp+0xF0]
000071e7f4dd5d4c  vmovaps xmm15, [rsp+0xF0]
000071e7f4dd5d55  por xmm1, xmm15
000071e7f4dd5d5a  movaps [r15+0x300], xmm1
000071e7f4dd5d62  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd5d6b  vmovaps xmm9, [rsp+0xE0]
000071e7f4dd5d74  por xmm15, xmm9
000071e7f4dd5d79  movaps [r15+0x190], xmm15
000071e7f4dd5d81  vmovaps xmm9, [rsp+0x50]
000071e7f4dd5d87  vpermilpd xmm9, xmm9, 0x00
000071e7f4dd5d8d  vmovaps [rsp+0x90], xmm1
000071e7f4dd5d96  vmovaps [rsp+0xE0], xmm15
000071e7f4dd5d9f  vmovaps xmm15, [rsp+0x80]
000071e7f4dd5da8  vmovaps [rsp+0x80], xmm14
000071e7f4dd5db1  movaps xmm1, xmm15
000071e7f4dd5db5  mulpd xmm1, xmm9
000071e7f4dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000071e7f4dd5dbf  ptest xmm14, xmm14
000071e7f4dd5dc5  jnz 0x000071E7F4DD7ABF
000071e7f4dd5dcb  lea r14, [rax+0x90]
000071e7f4dd5dd2  movups xmm15, [r13+r14*1]
000071e7f4dd5dd8  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd5de1  vmovaps xmm9, [rsp+0xD0]
000071e7f4dd5dea  por xmm14, xmm9
000071e7f4dd5def  movaps [r15+0x1C0], xmm14
000071e7f4dd5df7  vmovaps xmm9, [rsp+0xC0]
000071e7f4dd5e00  vmovaps [rsp+0xD0], xmm1
000071e7f4dd5e09  vmovaps xmm1, [rsp+0xC0]
000071e7f4dd5e12  por xmm9, xmm1
000071e7f4dd5e17  movaps [r15+0x200], xmm9
000071e7f4dd5e1f  vmovaps [rsp+0xC0], xmm2
000071e7f4dd5e28  vmovaps xmm1, [rsp+0xC0]
000071e7f4dd5e31  por xmm2, xmm1
000071e7f4dd5e35  movaps [r15+0x2D0], xmm2
000071e7f4dd5e3d  vmovaps [rsp+0xC0], xmm8
000071e7f4dd5e46  vmovaps xmm1, [rsp+0xC0]
000071e7f4dd5e4f  por xmm8, xmm1
000071e7f4dd5e54  movaps [r15+0x2E0], xmm8
000071e7f4dd5e5c  vmovaps [rsp+0xC0], xmm15
000071e7f4dd5e65  movaps xmm1, xmm5
000071e7f4dd5e68  addpd xmm1, xmm7
000071e7f4dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000071e7f4dd5e71  ptest xmm15, xmm15
000071e7f4dd5e77  jnz 0x000071E7F4DD7C0B
000071e7f4dd5e7d  vmovaps xmm15, [rsp+0x50]
000071e7f4dd5e83  vpermilpd xmm15, xmm15, 0x00
000071e7f4dd5e89  vmovaps xmm5, [rsp+0xC0]
000071e7f4dd5e92  vmovaps [rsp+0xC0], xmm1
000071e7f4dd5e9b  movaps xmm7, xmm5
000071e7f4dd5e9e  mulpd xmm7, xmm15
000071e7f4dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000071e7f4dd5ea8  ptest xmm1, xmm1
000071e7f4dd5ead  jnz 0x000071E7F4DD7D4B
000071e7f4dd5eb3  lea r14, [rax+0x80]
000071e7f4dd5eba  movups xmm1, [r13+r14*1]
000071e7f4dd5ec0  vmovaps xmm5, [rsp+0x70]
000071e7f4dd5ec6  vmovaps [rsp+0x70], xmm1
000071e7f4dd5ecc  movaps xmm15, xmm5
000071e7f4dd5ed0  addpd xmm15, xmm3
000071e7f4dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000071e7f4dd5edb  ptest xmm1, xmm1
000071e7f4dd5ee0  jnz 0x000071E7F4DD7E96
000071e7f4dd5ee6  vmovaps xmm5, [rsp+0x80]
000071e7f4dd5eef  movaps xmm1, xmm5
000071e7f4dd5ef2  addpd xmm1, xmm4
000071e7f4dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000071e7f4dd5efb  ptest xmm3, xmm3
000071e7f4dd5f00  jnz 0x000071E7F4DD7FD8
000071e7f4dd5f06  vmovaps [rsp+0x80], xmm10
000071e7f4dd5f0f  vmovaps xmm5, [rsp+0x80]
000071e7f4dd5f18  por xmm10, xmm5
000071e7f4dd5f1d  movaps [r15+0x2F0], xmm10
000071e7f4dd5f25  vmovaps xmm5, [rsp+0x50]
000071e7f4dd5f2b  vpermilpd xmm5, xmm5, 0x00
000071e7f4dd5f31  vmovaps xmm3, [rsp+0x70]
000071e7f4dd5f37  vmovaps [rsp+0x50], xmm1
000071e7f4dd5f3d  movaps xmm4, xmm3
000071e7f4dd5f40  mulpd xmm4, xmm5
000071e7f4dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000071e7f4dd5f49  ptest xmm1, xmm1
000071e7f4dd5f4e  jnz 0x000071E7F4DD8118
000071e7f4dd5f54  lea r14, [rax+0xD0]
000071e7f4dd5f5b  movups xmm1, [r13+r14*1]
000071e7f4dd5f61  vmovaps xmm3, [rsp+0xD0]
000071e7f4dd5f6a  vmovaps [rsp+0x70], xmm1
000071e7f4dd5f70  movaps xmm5, xmm6
000071e7f4dd5f73  addpd xmm5, xmm3
000071e7f4dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000071e7f4dd5f7c  ptest xmm1, xmm1
000071e7f4dd5f81  jnz 0x000071E7F4DD8262
000071e7f4dd5f87  vmovaps xmm1, [rsp+0x60]
000071e7f4dd5f8d  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd5f93  movaps xmm6, xmm9
000071e7f4dd5f97  mulpd xmm6, xmm1
000071e7f4dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000071e7f4dd5fa0  ptest xmm3, xmm3
000071e7f4dd5fa5  jnz 0x000071E7F4DD83A2
000071e7f4dd5fab  movaps [r15+0x260], xmm6
000071e7f4dd5fb3  vxorps xmm1, xmm1, xmm1
000071e7f4dd5fb7  vpbroadcastq xmm1, xmm1
000071e7f4dd5fbc  movaps [r15+0x1B0], xmm1
000071e7f4dd5fc4  vmovaps xmm1, [rsp+0x60]
000071e7f4dd5fca  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd5fd0  vmovaps xmm3, [rsp+0x70]
000071e7f4dd5fd6  vmovaps [rsp+0x70], xmm15
000071e7f4dd5fdc  movaps xmm9, xmm3
000071e7f4dd5fe0  mulpd xmm9, xmm1
000071e7f4dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000071e7f4dd5feb  ptest xmm15, xmm15
000071e7f4dd5ff1  jnz 0x000071E7F4DD84E3
000071e7f4dd5ff7  lea r14, [rax+0xC0]
000071e7f4dd5ffe  movups xmm1, [r13+r14*1]
000071e7f4dd6004  vmovaps xmm3, [rsp+0xC0]
000071e7f4dd600d  vmovaps [rsp+0x80], xmm1
000071e7f4dd6016  movaps xmm15, xmm3
000071e7f4dd601a  addpd xmm15, xmm7
000071e7f4dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000071e7f4dd6025  ptest xmm1, xmm1
000071e7f4dd602a  jnz 0x000071E7F4DD862F
000071e7f4dd6030  vmovaps [rsp+0xC0], xmm13
000071e7f4dd6039  vmovaps xmm1, [rsp+0xC0]
000071e7f4dd6042  por xmm13, xmm1
000071e7f4dd6047  movaps [r15+0x270], xmm13
000071e7f4dd604f  vmovaps xmm1, [rsp+0xB0]
000071e7f4dd6058  vmovaps xmm7, [rsp+0xB0]
000071e7f4dd6061  por xmm1, xmm7
000071e7f4dd6065  movaps [r15+0x1A0], xmm1
000071e7f4dd606d  vmovaps xmm1, [rsp+0x60]
000071e7f4dd6073  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd6079  vmovaps [rsp+0xB0], xmm1
000071e7f4dd6082  vmovaps xmm1, [rsp+0x80]
000071e7f4dd608b  vmovaps [rsp+0x80], xmm15
000071e7f4dd6094  vmovaps xmm15, [rsp+0xB0]
000071e7f4dd609d  vmovaps [rsp+0xB0], xmm14
000071e7f4dd60a6  movaps xmm3, xmm1
000071e7f4dd60a9  mulpd xmm3, xmm15
000071e7f4dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000071e7f4dd60b3  ptest xmm14, xmm14
000071e7f4dd60b9  jnz 0x000071E7F4DD8771
000071e7f4dd60bf  lea r14, [rax+0x20]
000071e7f4dd60c3  movups xmm1, [r13+r14*1]
000071e7f4dd60c9  movaps [r15+0x110], xmm1
000071e7f4dd60d1  vmovaps xmm14, [rsp+0x70]
000071e7f4dd60d7  vmovaps [rsp+0x70], xmm1
000071e7f4dd60dd  movaps xmm15, xmm14
000071e7f4dd60e1  addpd xmm15, xmm4
000071e7f4dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000071e7f4dd60ec  ptest xmm1, xmm1
000071e7f4dd60f1  jnz 0x000071E7F4DD88BC
000071e7f4dd60f7  vmovaps xmm1, [rsp+0x60]
000071e7f4dd60fd  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd6103  movaps xmm14, xmm2
000071e7f4dd6107  mulpd xmm14, xmm1
000071e7f4dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000071e7f4dd6112  ptest xmm4, xmm4
000071e7f4dd6117  jnz 0x000071E7F4DD89FF
000071e7f4dd611d  vmovaps xmm4, [rsp+0x50]
000071e7f4dd6123  movaps xmm1, xmm4
000071e7f4dd6126  addpd xmm1, xmm9
000071e7f4dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000071e7f4dd6130  ptest xmm2, xmm2
000071e7f4dd6135  jnz 0x000071E7F4DD8B41
000071e7f4dd613b  vmovaps xmm9, [rsp+0x30]
000071e7f4dd6141  vpermilpd xmm9, xmm9, 0x00
000071e7f4dd6147  vmovaps xmm2, [rsp+0x70]
000071e7f4dd614d  vmovaps [rsp+0x50], xmm1
000071e7f4dd6153  movaps xmm4, xmm2
000071e7f4dd6156  mulpd xmm4, xmm9
000071e7f4dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000071e7f4dd6160  ptest xmm1, xmm1
000071e7f4dd6165  jnz 0x000071E7F4DD8C82
000071e7f4dd616b  vmovaps xmm1, [rsp+0x30]
000071e7f4dd6171  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd6177  vmovaps xmm2, [rsp+0x90]
000071e7f4dd6180  vmovaps [rsp+0x60], xmm15
000071e7f4dd6186  movaps xmm9, xmm2
000071e7f4dd618a  mulpd xmm9, xmm1
000071e7f4dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000071e7f4dd6195  ptest xmm15, xmm15
000071e7f4dd619b  jnz 0x000071E7F4DD8DC3
000071e7f4dd61a1  vmovaps xmm15, [rsp+0x80]
000071e7f4dd61aa  movaps xmm1, xmm15
000071e7f4dd61ae  addpd xmm1, xmm6
000071e7f4dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000071e7f4dd61b7  ptest xmm2, xmm2
000071e7f4dd61bc  jnz 0x000071E7F4DD8F05
000071e7f4dd61c2  movaps xmm15, xmm5
000071e7f4dd61c6  addpd xmm15, xmm3
000071e7f4dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000071e7f4dd61d1  ptest xmm6, xmm6
000071e7f4dd61d6  jnz 0x000071E7F4DD9046
000071e7f4dd61dc  vmovaps xmm6, [rsp+0x30]
000071e7f4dd61e2  vpermilpd xmm6, xmm6, 0x00
000071e7f4dd61e8  movaps xmm5, xmm8
000071e7f4dd61ec  mulpd xmm5, xmm6
000071e7f4dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000071e7f4dd61f5  ptest xmm3, xmm3
000071e7f4dd61fa  jnz 0x000071E7F4DD9188
000071e7f4dd6200  vmovaps xmm8, [rsp+0x30]
000071e7f4dd6206  vpermilpd xmm8, xmm8, 0x00
000071e7f4dd620c  movaps xmm6, xmm10
000071e7f4dd6210  mulpd xmm6, xmm8
000071e7f4dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000071e7f4dd621a  ptest xmm3, xmm3
000071e7f4dd621f  jnz 0x000071E7F4DD92C9
000071e7f4dd6225  vmovaps xmm8, [rsp+0x60]
000071e7f4dd622b  movaps xmm10, xmm8
000071e7f4dd622f  addpd xmm10, xmm14
000071e7f4dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000071e7f4dd623a  ptest xmm3, xmm3
000071e7f4dd623f  jnz 0x000071E7F4DD940B
000071e7f4dd6245  vmovaps xmm8, [rsp+0x50]
000071e7f4dd624b  movaps xmm14, xmm8
000071e7f4dd624f  addpd xmm14, xmm4
000071e7f4dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000071e7f4dd625a  ptest xmm3, xmm3
000071e7f4dd625f  jnz 0x000071E7F4DD954F
000071e7f4dd6265  vmovaps xmm8, [rsp+0x40]
000071e7f4dd626b  vpermilpd xmm8, xmm8, 0x00
000071e7f4dd6271  movaps xmm4, xmm13
000071e7f4dd6275  mulpd xmm4, xmm8
000071e7f4dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000071e7f4dd627f  ptest xmm3, xmm3
000071e7f4dd6284  jnz 0x000071E7F4DD9692
000071e7f4dd628a  movaps xmm13, xmm15
000071e7f4dd628e  addpd xmm13, xmm9
000071e7f4dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000071e7f4dd6299  ptest xmm8, xmm8
000071e7f4dd629f  jnz 0x000071E7F4DD97D4
000071e7f4dd62a5  movaps xmm15, xmm1
000071e7f4dd62a9  addpd xmm15, xmm5
000071e7f4dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000071e7f4dd62b4  ptest xmm9, xmm9
000071e7f4dd62ba  jnz 0x000071E7F4DD9918
000071e7f4dd62c0  vmovaps [rsp+0x30], xmm11
000071e7f4dd62c6  vmovaps xmm1, [rsp+0x30]
000071e7f4dd62cc  por xmm11, xmm1
000071e7f4dd62d1  movaps [r15+0x250], xmm11
000071e7f4dd62d9  vmovaps [rsp+0x30], xmm12
000071e7f4dd62df  vmovaps xmm1, [rsp+0x30]
000071e7f4dd62e5  por xmm12, xmm1
000071e7f4dd62ea  movaps [r15+0x2A0], xmm12
000071e7f4dd62f2  vmovaps xmm1, [rsp+0xA0]
000071e7f4dd62fb  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd6304  por xmm1, xmm11
000071e7f4dd6309  movaps [r15+0x1D0], xmm1
000071e7f4dd6311  lea r14, [rax+0x40]
000071e7f4dd6315  movups xmm1, [r13+r14*1]
000071e7f4dd631b  movaps [r15+0x2C0], xmm1
000071e7f4dd6323  vmovaps xmm11, [rsp+0x40]
000071e7f4dd6329  vpermilpd xmm11, xmm11, 0x00
000071e7f4dd632f  vmovaps xmm8, [rsp+0xE0]
000071e7f4dd6338  movaps xmm9, xmm8
000071e7f4dd633c  mulpd xmm9, xmm11
000071e7f4dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000071e7f4dd6347  ptest xmm5, xmm5
000071e7f4dd634c  jnz 0x000071E7F4DD9A64
000071e7f4dd6352  movaps xmm11, xmm10
000071e7f4dd6356  addpd xmm11, xmm6
000071e7f4dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000071e7f4dd6361  ptest xmm8, xmm8
000071e7f4dd6367  jnz 0x000071E7F4DD9BA8
000071e7f4dd636d  movaps xmm10, xmm14
000071e7f4dd6371  addpd xmm10, xmm4
000071e7f4dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000071e7f4dd637c  ptest xmm8, xmm8
000071e7f4dd6382  jnz 0x000071E7F4DD9CEB
000071e7f4dd6388  vmovaps xmm14, [rsp+0x40]
000071e7f4dd638e  vpermilpd xmm14, xmm14, 0x00
000071e7f4dd6394  movaps xmm8, xmm1
000071e7f4dd6398  mulpd xmm8, xmm14
000071e7f4dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000071e7f4dd63a3  ptest xmm6, xmm6
000071e7f4dd63a8  jnz 0x000071E7F4DD9E2E
000071e7f4dd63ae  movaps xmm1, [r15+0x2B0]
000071e7f4dd63b6  vmovaps xmm14, [rsp+0x40]
000071e7f4dd63bc  vpermilpd xmm14, xmm14, 0x00
000071e7f4dd63c2  movaps xmm6, xmm1
000071e7f4dd63c5  mulpd xmm6, xmm14
000071e7f4dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000071e7f4dd63cf  ptest xmm5, xmm5
000071e7f4dd63d4  jnz 0x000071E7F4DD9F71
000071e7f4dd63da  vmovaps xmm1, [rsp+0x10]
000071e7f4dd63e0  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd63e6  movaps xmm14, xmm12
000071e7f4dd63ea  mulpd xmm14, xmm1
000071e7f4dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000071e7f4dd63f5  ptest xmm5, xmm5
000071e7f4dd63fa  jnz 0x000071E7F4DDA0B2
000071e7f4dd6400  movaps xmm1, xmm13
000071e7f4dd6404  addpd xmm1, xmm9
000071e7f4dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000071e7f4dd640e  ptest xmm12, xmm12
000071e7f4dd6414  jnz 0x000071E7F4DDA1F5
000071e7f4dd641a  vmovaps xmm13, [rsp+0x10]
000071e7f4dd6420  vpermilpd xmm13, xmm13, 0x00
000071e7f4dd6426  movaps xmm12, xmm7
000071e7f4dd642a  mulpd xmm12, xmm13
000071e7f4dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000071e7f4dd6435  ptest xmm9, xmm9
000071e7f4dd643b  jnz 0x000071E7F4DDA337
000071e7f4dd6441  movaps xmm13, xmm15
000071e7f4dd6445  addpd xmm13, xmm8
000071e7f4dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000071e7f4dd6450  ptest xmm9, xmm9
000071e7f4dd6456  jnz 0x000071E7F4DDA47A
000071e7f4dd645c  movaps xmm15, [r15+0x290]
000071e7f4dd6464  vmovaps xmm9, [rsp+0x10]
000071e7f4dd646a  vpermilpd xmm9, xmm9, 0x00
000071e7f4dd6470  movaps xmm8, xmm15
000071e7f4dd6474  mulpd xmm8, xmm9
000071e7f4dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000071e7f4dd647f  ptest xmm7, xmm7
000071e7f4dd6484  jnz 0x000071E7F4DDA5BE
000071e7f4dd648a  movaps xmm15, xmm11
000071e7f4dd648e  addpd xmm15, xmm6
000071e7f4dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000071e7f4dd6499  ptest xmm9, xmm9
000071e7f4dd649f  jnz 0x000071E7F4DDA702
000071e7f4dd64a5  movaps xmm11, [r15+0x1E0]
000071e7f4dd64ad  vmovaps xmm9, [rsp+0x10]
000071e7f4dd64b3  vpermilpd xmm9, xmm9, 0x00
000071e7f4dd64b9  movaps xmm7, xmm11
000071e7f4dd64bd  mulpd xmm7, xmm9
000071e7f4dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000071e7f4dd64c7  ptest xmm6, xmm6
000071e7f4dd64cc  jnz 0x000071E7F4DDA845
000071e7f4dd64d2  movaps xmm11, xmm10
000071e7f4dd64d6  addpd xmm11, xmm14
000071e7f4dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000071e7f4dd64e1  ptest xmm9, xmm9
000071e7f4dd64e7  jnz 0x000071E7F4DDA987
000071e7f4dd64ed  lea r14, [rax+0x70]
000071e7f4dd64f1  movups xmm14, [r13+r14*1]
000071e7f4dd64f7  movaps [r15+0x240], xmm14
000071e7f4dd64ff  movaps xmm10, xmm1
000071e7f4dd6503  addpd xmm10, xmm12
000071e7f4dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000071e7f4dd650e  ptest xmm9, xmm9
000071e7f4dd6514  jnz 0x000071E7F4DDAAD5
000071e7f4dd651a  movaps [r15+0x170], xmm10
000071e7f4dd6522  vmovaps xmm1, [rsp+0x20]
000071e7f4dd6528  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd652e  movaps xmm12, xmm14
000071e7f4dd6532  mulpd xmm12, xmm1
000071e7f4dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000071e7f4dd653d  ptest xmm9, xmm9
000071e7f4dd6543  jnz 0x000071E7F4DDAC18
000071e7f4dd6549  vmovaps xmm1, [rsp+0x20]
000071e7f4dd654f  vpermilpd xmm1, xmm1, 0x00
000071e7f4dd6555  vmovaps xmm9, [rsp+0xB0]
000071e7f4dd655e  movaps xmm14, xmm9
000071e7f4dd6562  mulpd xmm14, xmm1
000071e7f4dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000071e7f4dd656d  ptest xmm6, xmm6
000071e7f4dd6572  jnz 0x000071E7F4DDAD5B
000071e7f4dd6578  movaps [r15+0x180], xmm14
000071e7f4dd6580  movaps xmm1, xmm13
000071e7f4dd6584  addpd xmm1, xmm8
000071e7f4dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000071e7f4dd658e  ptest xmm9, xmm9
000071e7f4dd6594  jnz 0x000071E7F4DDAE9E
000071e7f4dd659a  movaps [r15+0x210], xmm1
000071e7f4dd65a2  movups xmm13, [r13+rax*1]
000071e7f4dd65a8  lea r14, [rax+0x10]
000071e7f4dd65ac  movups xmm9, [r13+r14*1]
000071e7f4dd65b2  movaps [r15+0x230], xmm9
000071e7f4dd65ba  movaps xmm8, xmm15
000071e7f4dd65be  addpd xmm8, xmm7
000071e7f4dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000071e7f4dd65c9  ptest xmm6, xmm6
000071e7f4dd65ce  jnz 0x000071E7F4DDAFF4
000071e7f4dd65d4  movaps [r15+0x130], xmm8
000071e7f4dd65dc  vmovaps xmm15, [rsp+0x20]
000071e7f4dd65e2  vpermilpd xmm15, xmm15, 0x00
000071e7f4dd65e8  movaps xmm7, xmm9
000071e7f4dd65ec  mulpd xmm7, xmm15
000071e7f4dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000071e7f4dd65f6  ptest xmm6, xmm6
000071e7f4dd65fb  jnz 0x000071E7F4DDB137
000071e7f4dd6601  movaps [r15+0x220], xmm7
000071e7f4dd6609  vmovaps xmm15, [rsp+0x20]
000071e7f4dd660f  vpermilpd xmm15, xmm15, 0x00
000071e7f4dd6615  movaps xmm9, xmm13
000071e7f4dd6619  mulpd xmm9, xmm15
000071e7f4dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000071e7f4dd6624  ptest xmm6, xmm6
000071e7f4dd6629  jnz 0x000071E7F4DDB279
000071e7f4dd662f  movaps xmm15, xmm11
000071e7f4dd6633  addpd xmm15, xmm12
000071e7f4dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000071e7f4dd663e  ptest xmm13, xmm13
000071e7f4dd6644  jnz 0x000071E7F4DDB3BD
000071e7f4dd664a  movaps [r15+0x140], xmm15
000071e7f4dd6652  movaps xmm13, xmm10
000071e7f4dd6656  addpd xmm13, xmm14
000071e7f4dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000071e7f4dd6661  ptest xmm12, xmm12
000071e7f4dd6667  jnz 0x000071E7F4DDB501
000071e7f4dd666d  movaps [r15+0x150], xmm13
000071e7f4dd6675  movaps xmm14, xmm1
000071e7f4dd6679  addpd xmm14, xmm7
000071e7f4dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000071e7f4dd6684  ptest xmm12, xmm12
000071e7f4dd668a  jnz 0x000071E7F4DDB645
000071e7f4dd6690  movaps [r15+0x160], xmm14
000071e7f4dd6698  movaps xmm1, xmm8
000071e7f4dd669c  addpd xmm1, xmm9
000071e7f4dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000071e7f4dd66a6  ptest xmm12, xmm12
000071e7f4dd66ac  jnz 0x000071E7F4DDB787
000071e7f4dd66b2  movaps [r15+0x120], xmm1
000071e7f4dd66ba  movups [r13+r11*1], xmm15
000071e7f4dd66c0  lea rax, [r11+0x10]
000071e7f4dd66c4  movups [r13+rax*1], xmm13
000071e7f4dd66ca  lea rax, [r11+0x20]
000071e7f4dd66ce  movups [r13+rax*1], xmm14
000071e7f4dd66d4  lea rax, [r11+0x30]
000071e7f4dd66d8  movups [r13+rax*1], xmm1
000071e7f4dd66de  mov eax, [r15+0x108]
000071e7f4dd66e5  sahf
000071e7f4dd66e6  jnz 0x000071E7F4DD6718
000071e7f4dd66e8  cmp dword ptr [r15+0x318], 0x00
000071e7f4dd66f0  jz 0x000071E7F4DDB900
000071e7f4dd66f6  nop [rax+rax*1], ax
000071e7f4dd66ff  nop [rax+rax*1], eax
000071e7f4dd6707  mov eax, 0x410444
000071e7f4dd670c  mov [r15+0x100], rax
000071e7f4dd6713  jmp 0x000071E7F4BFE110
000071e7f4dd6718  cmp dword ptr [r15+0x318], 0x00
000071e7f4dd6720  jz 0x000071E7F4DD57E0
000071e7f4dd6726  nop [rax+rax*1], ax
000071e7f4dd672f  nop [rax+rax*1], eax
000071e7f4dd6737  mov eax, 0x410278
000071e7f4dd673c  mov [r15+0x100], rax
000071e7f4dd6743  jmp 0x000071E7F4BFE110
000071e7f4dd6748  int3
000071e7f4dd6749  call 0x000071E7F4C0A4B0
000071e7f4dd674e  jmp 0x000071E7F4DD5828
000071e7f4dd6753  call 0x000071E7F4C09240
000071e7f4dd6758  jmp 0x000071E7F4DD5832
000071e7f4dd675d  call 0x000071E7F4C0A4B0
000071e7f4dd6762  jmp 0x000071E7F4DD588F
000071e7f4dd6767  call 0x000071E7F4C09240
000071e7f4dd676c  jmp 0x000071E7F4DD5899
000071e7f4dd6771  call 0x000071E7F4C0A4B0
000071e7f4dd6776  jmp 0x000071E7F4DD58DD
000071e7f4dd677b  call 0x000071E7F4C09240
000071e7f4dd6780  jmp 0x000071E7F4DD58E7
000071e7f4dd6785  call 0x000071E7F4CB47C0
000071e7f4dd678a  jmp 0x000071E7F4DD5926
000071e7f4dd678f  call 0x000071E7F4C0B720
000071e7f4dd6794  jmp 0x000071E7F4DD593A
000071e7f4dd6799  call 0x000071E7F4CBFC30
000071e7f4dd679e  jmp 0x000071E7F4DD5958
000071e7f4dd67a3  call 0x000071E7F4CBE9C0
000071e7f4dd67a8  jmp 0x000071E7F4DD5962
000071e7f4dd67ad  call 0x000071E7F4CBD750
000071e7f4dd67b2  jmp 0x000071E7F4DD596C
000071e7f4dd67b7  sub rsp, 0x08
000071e7f4dd67bb  push rax
000071e7f4dd67bc  push rcx
000071e7f4dd67bd  push rdx
000071e7f4dd67be  push rdi
000071e7f4dd67bf  push rsi
000071e7f4dd67c0  push r8
000071e7f4dd67c2  push r9
000071e7f4dd67c4  push r10
000071e7f4dd67c6  push r11
000071e7f4dd67c8  sub rsp, 0xF0
000071e7f4dd67cf  vmovaps [rsp], xmm0
000071e7f4dd67d4  vmovaps [rsp+0x10], xmm1
000071e7f4dd67da  vmovaps [rsp+0x20], xmm2
000071e7f4dd67e0  vmovaps [rsp+0x30], xmm3
000071e7f4dd67e6  vmovaps [rsp+0x40], xmm4
000071e7f4dd67ec  vmovaps [rsp+0x50], xmm5
000071e7f4dd67f2  vmovaps [rsp+0x60], xmm6
000071e7f4dd67f8  vmovaps [rsp+0x70], xmm7
000071e7f4dd67fe  vmovaps [rsp+0x80], xmm9
000071e7f4dd6807  vmovaps [rsp+0x90], xmm10
000071e7f4dd6810  vmovaps [rsp+0xA0], xmm11
000071e7f4dd6819  vmovaps [rsp+0xB0], xmm12
000071e7f4dd6822  vmovaps [rsp+0xC0], xmm13
000071e7f4dd682b  vmovaps [rsp+0xD0], xmm14
000071e7f4dd6834  vmovaps [rsp+0xE0], xmm15
000071e7f4dd683d  sub rsp, 0x30
000071e7f4dd6841  movaps [rsp], xmm8
000071e7f4dd6846  movaps [rsp+0x10], xmm12
000071e7f4dd684c  movaps [rsp+0x20], xmm15
000071e7f4dd6852  lea rdi, [rsp]
000071e7f4dd6856  mov esi, 0x00
000071e7f4dd685b  mov rax, 0x562A51E82530
000071e7f4dd6865  call rax
000071e7f4dd6867  movaps xmm8, [rsp]
000071e7f4dd686c  add rsp, 0x30
000071e7f4dd6870  vmovaps xmm0, [rsp]
000071e7f4dd6875  vmovaps xmm1, [rsp+0x10]
000071e7f4dd687b  vmovaps xmm2, [rsp+0x20]
000071e7f4dd6881  vmovaps xmm3, [rsp+0x30]
000071e7f4dd6887  vmovaps xmm4, [rsp+0x40]
000071e7f4dd688d  vmovaps xmm5, [rsp+0x50]
000071e7f4dd6893  vmovaps xmm6, [rsp+0x60]
000071e7f4dd6899  vmovaps xmm7, [rsp+0x70]
000071e7f4dd689f  vmovaps xmm9, [rsp+0x80]
000071e7f4dd68a8  vmovaps xmm10, [rsp+0x90]
000071e7f4dd68b1  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd68ba  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd68c3  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd68cc  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd68d5  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd68de  add rsp, 0xF0
000071e7f4dd68e5  pop r11
000071e7f4dd68e7  pop r10
000071e7f4dd68e9  pop r9
000071e7f4dd68eb  pop r8
000071e7f4dd68ed  pop rsi
000071e7f4dd68ee  pop rdi
000071e7f4dd68ef  pop rdx
000071e7f4dd68f0  pop rcx
000071e7f4dd68f1  pop rax
000071e7f4dd68f2  add rsp, 0x08
000071e7f4dd68f6  jmp 0x000071E7F4DD599A
000071e7f4dd68fb  sub rsp, 0x08
000071e7f4dd68ff  push rax
000071e7f4dd6900  push rcx
000071e7f4dd6901  push rdx
000071e7f4dd6902  push rdi
000071e7f4dd6903  push rsi
000071e7f4dd6904  push r8
000071e7f4dd6906  push r9
000071e7f4dd6908  push r10
000071e7f4dd690a  push r11
000071e7f4dd690c  sub rsp, 0xF0
000071e7f4dd6913  vmovaps [rsp], xmm0
000071e7f4dd6918  vmovaps [rsp+0x10], xmm1
000071e7f4dd691e  vmovaps [rsp+0x20], xmm2
000071e7f4dd6924  vmovaps [rsp+0x30], xmm3
000071e7f4dd692a  vmovaps [rsp+0x40], xmm4
000071e7f4dd6930  vmovaps [rsp+0x50], xmm5
000071e7f4dd6936  vmovaps [rsp+0x60], xmm6
000071e7f4dd693c  vmovaps [rsp+0x70], xmm8
000071e7f4dd6942  vmovaps [rsp+0x80], xmm9
000071e7f4dd694b  vmovaps [rsp+0x90], xmm10
000071e7f4dd6954  vmovaps [rsp+0xA0], xmm11
000071e7f4dd695d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd6966  vmovaps [rsp+0xC0], xmm13
000071e7f4dd696f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd6978  vmovaps [rsp+0xE0], xmm15
000071e7f4dd6981  sub rsp, 0x30
000071e7f4dd6985  movaps [rsp], xmm7
000071e7f4dd6989  movaps [rsp+0x10], xmm9
000071e7f4dd698f  movaps [rsp+0x20], xmm15
000071e7f4dd6995  lea rdi, [rsp]
000071e7f4dd6999  mov esi, 0x00
000071e7f4dd699e  mov rax, 0x562A51E82530
000071e7f4dd69a8  call rax
000071e7f4dd69aa  movaps xmm7, [rsp]
000071e7f4dd69ae  add rsp, 0x30
000071e7f4dd69b2  vmovaps xmm0, [rsp]
000071e7f4dd69b7  vmovaps xmm1, [rsp+0x10]
000071e7f4dd69bd  vmovaps xmm2, [rsp+0x20]
000071e7f4dd69c3  vmovaps xmm3, [rsp+0x30]
000071e7f4dd69c9  vmovaps xmm4, [rsp+0x40]
000071e7f4dd69cf  vmovaps xmm5, [rsp+0x50]
000071e7f4dd69d5  vmovaps xmm6, [rsp+0x60]
000071e7f4dd69db  vmovaps xmm8, [rsp+0x70]
000071e7f4dd69e1  vmovaps xmm9, [rsp+0x80]
000071e7f4dd69ea  vmovaps xmm10, [rsp+0x90]
000071e7f4dd69f3  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd69fc  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd6a05  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd6a0e  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd6a17  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd6a20  add rsp, 0xF0
000071e7f4dd6a27  pop r11
000071e7f4dd6a29  pop r10
000071e7f4dd6a2b  pop r9
000071e7f4dd6a2d  pop r8
000071e7f4dd6a2f  pop rsi
000071e7f4dd6a30  pop rdi
000071e7f4dd6a31  pop rdx
000071e7f4dd6a32  pop rcx
000071e7f4dd6a33  pop rax
000071e7f4dd6a34  add rsp, 0x08
000071e7f4dd6a38  jmp 0x000071E7F4DD59C8
000071e7f4dd6a3d  sub rsp, 0x08
000071e7f4dd6a41  push rax
000071e7f4dd6a42  push rcx
000071e7f4dd6a43  push rdx
000071e7f4dd6a44  push rdi
000071e7f4dd6a45  push rsi
000071e7f4dd6a46  push r8
000071e7f4dd6a48  push r9
000071e7f4dd6a4a  push r10
000071e7f4dd6a4c  push r11
000071e7f4dd6a4e  sub rsp, 0xF0
000071e7f4dd6a55  vmovaps [rsp], xmm0
000071e7f4dd6a5a  vmovaps [rsp+0x10], xmm1
000071e7f4dd6a60  vmovaps [rsp+0x20], xmm2
000071e7f4dd6a66  vmovaps [rsp+0x30], xmm3
000071e7f4dd6a6c  vmovaps [rsp+0x40], xmm4
000071e7f4dd6a72  vmovaps [rsp+0x50], xmm5
000071e7f4dd6a78  vmovaps [rsp+0x60], xmm6
000071e7f4dd6a7e  vmovaps [rsp+0x70], xmm7
000071e7f4dd6a84  vmovaps [rsp+0x80], xmm8
000071e7f4dd6a8d  vmovaps [rsp+0x90], xmm10
000071e7f4dd6a96  vmovaps [rsp+0xA0], xmm11
000071e7f4dd6a9f  vmovaps [rsp+0xB0], xmm12
000071e7f4dd6aa8  vmovaps [rsp+0xC0], xmm13
000071e7f4dd6ab1  vmovaps [rsp+0xD0], xmm14
000071e7f4dd6aba  vmovaps [rsp+0xE0], xmm15
000071e7f4dd6ac3  sub rsp, 0x30
000071e7f4dd6ac7  movaps [rsp], xmm9
000071e7f4dd6acc  movaps [rsp+0x10], xmm12
000071e7f4dd6ad2  movaps [rsp+0x20], xmm10
000071e7f4dd6ad8  lea rdi, [rsp]
000071e7f4dd6adc  mov esi, 0x00
000071e7f4dd6ae1  mov rax, 0x562A51E82530
000071e7f4dd6aeb  call rax
000071e7f4dd6aed  movaps xmm9, [rsp]
000071e7f4dd6af2  add rsp, 0x30
000071e7f4dd6af6  vmovaps xmm0, [rsp]
000071e7f4dd6afb  vmovaps xmm1, [rsp+0x10]
000071e7f4dd6b01  vmovaps xmm2, [rsp+0x20]
000071e7f4dd6b07  vmovaps xmm3, [rsp+0x30]
000071e7f4dd6b0d  vmovaps xmm4, [rsp+0x40]
000071e7f4dd6b13  vmovaps xmm5, [rsp+0x50]
000071e7f4dd6b19  vmovaps xmm6, [rsp+0x60]
000071e7f4dd6b1f  vmovaps xmm7, [rsp+0x70]
000071e7f4dd6b25  vmovaps xmm8, [rsp+0x80]
000071e7f4dd6b2e  vmovaps xmm10, [rsp+0x90]
000071e7f4dd6b37  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd6b40  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd6b49  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd6b52  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd6b5b  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd6b64  add rsp, 0xF0
000071e7f4dd6b6b  pop r11
000071e7f4dd6b6d  pop r10
000071e7f4dd6b6f  pop r9
000071e7f4dd6b71  pop r8
000071e7f4dd6b73  pop rsi
000071e7f4dd6b74  pop rdi
000071e7f4dd6b75  pop rdx
000071e7f4dd6b76  pop rcx
000071e7f4dd6b77  pop rax
000071e7f4dd6b78  add rsp, 0x08
000071e7f4dd6b7c  jmp 0x000071E7F4DD59EC
000071e7f4dd6b81  sub rsp, 0x08
000071e7f4dd6b85  push rax
000071e7f4dd6b86  push rcx
000071e7f4dd6b87  push rdx
000071e7f4dd6b88  push rdi
000071e7f4dd6b89  push rsi
000071e7f4dd6b8a  push r8
000071e7f4dd6b8c  push r9
000071e7f4dd6b8e  push r10
000071e7f4dd6b90  push r11
000071e7f4dd6b92  sub rsp, 0xF0
000071e7f4dd6b99  vmovaps [rsp], xmm0
000071e7f4dd6b9e  vmovaps [rsp+0x10], xmm1
000071e7f4dd6ba4  vmovaps [rsp+0x20], xmm2
000071e7f4dd6baa  vmovaps [rsp+0x30], xmm3
000071e7f4dd6bb0  vmovaps [rsp+0x40], xmm4
000071e7f4dd6bb6  vmovaps [rsp+0x50], xmm5
000071e7f4dd6bbc  vmovaps [rsp+0x60], xmm6
000071e7f4dd6bc2  vmovaps [rsp+0x70], xmm7
000071e7f4dd6bc8  vmovaps [rsp+0x80], xmm8
000071e7f4dd6bd1  vmovaps [rsp+0x90], xmm9
000071e7f4dd6bda  vmovaps [rsp+0xA0], xmm11
000071e7f4dd6be3  vmovaps [rsp+0xB0], xmm12
000071e7f4dd6bec  vmovaps [rsp+0xC0], xmm13
000071e7f4dd6bf5  vmovaps [rsp+0xD0], xmm14
000071e7f4dd6bfe  vmovaps [rsp+0xE0], xmm15
000071e7f4dd6c07  sub rsp, 0x30
000071e7f4dd6c0b  movaps [rsp], xmm10
000071e7f4dd6c10  movaps [rsp+0x10], xmm12
000071e7f4dd6c16  movaps [rsp+0x20], xmm11
000071e7f4dd6c1c  lea rdi, [rsp]
000071e7f4dd6c20  mov esi, 0x00
000071e7f4dd6c25  mov rax, 0x562A51E82530
000071e7f4dd6c2f  call rax
000071e7f4dd6c31  movaps xmm10, [rsp]
000071e7f4dd6c36  add rsp, 0x30
000071e7f4dd6c3a  vmovaps xmm0, [rsp]
000071e7f4dd6c3f  vmovaps xmm1, [rsp+0x10]
000071e7f4dd6c45  vmovaps xmm2, [rsp+0x20]
000071e7f4dd6c4b  vmovaps xmm3, [rsp+0x30]
000071e7f4dd6c51  vmovaps xmm4, [rsp+0x40]
000071e7f4dd6c57  vmovaps xmm5, [rsp+0x50]
000071e7f4dd6c5d  vmovaps xmm6, [rsp+0x60]
000071e7f4dd6c63  vmovaps xmm7, [rsp+0x70]
000071e7f4dd6c69  vmovaps xmm8, [rsp+0x80]
000071e7f4dd6c72  vmovaps xmm9, [rsp+0x90]
000071e7f4dd6c7b  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd6c84  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd6c8d  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd6c96  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd6c9f  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd6ca8  add rsp, 0xF0
000071e7f4dd6caf  pop r11
000071e7f4dd6cb1  pop r10
000071e7f4dd6cb3  pop r9
000071e7f4dd6cb5  pop r8
000071e7f4dd6cb7  pop rsi
000071e7f4dd6cb8  pop rdi
000071e7f4dd6cb9  pop rdx
000071e7f4dd6cba  pop rcx
000071e7f4dd6cbb  pop rax
000071e7f4dd6cbc  add rsp, 0x08
000071e7f4dd6cc0  jmp 0x000071E7F4DD5A06
000071e7f4dd6cc5  sub rsp, 0x08
000071e7f4dd6cc9  push rax
000071e7f4dd6cca  push rcx
000071e7f4dd6ccb  push rdx
000071e7f4dd6ccc  push rdi
000071e7f4dd6ccd  push rsi
000071e7f4dd6cce  push r8
000071e7f4dd6cd0  push r9
000071e7f4dd6cd2  push r10
000071e7f4dd6cd4  push r11
000071e7f4dd6cd6  sub rsp, 0xF0
000071e7f4dd6cdd  vmovaps [rsp], xmm0
000071e7f4dd6ce2  vmovaps [rsp+0x10], xmm1
000071e7f4dd6ce8  vmovaps [rsp+0x20], xmm2
000071e7f4dd6cee  vmovaps [rsp+0x30], xmm3
000071e7f4dd6cf4  vmovaps [rsp+0x40], xmm4
000071e7f4dd6cfa  vmovaps [rsp+0x50], xmm5
000071e7f4dd6d00  vmovaps [rsp+0x60], xmm7
000071e7f4dd6d06  vmovaps [rsp+0x70], xmm8
000071e7f4dd6d0c  vmovaps [rsp+0x80], xmm9
000071e7f4dd6d15  vmovaps [rsp+0x90], xmm10
000071e7f4dd6d1e  vmovaps [rsp+0xA0], xmm11
000071e7f4dd6d27  vmovaps [rsp+0xB0], xmm12
000071e7f4dd6d30  vmovaps [rsp+0xC0], xmm13
000071e7f4dd6d39  vmovaps [rsp+0xD0], xmm14
000071e7f4dd6d42  vmovaps [rsp+0xE0], xmm15
000071e7f4dd6d4b  sub rsp, 0x30
000071e7f4dd6d4f  movaps [rsp], xmm6
000071e7f4dd6d53  movaps [rsp+0x10], xmm12
000071e7f4dd6d59  movaps [rsp+0x20], xmm11
000071e7f4dd6d5f  lea rdi, [rsp]
000071e7f4dd6d63  mov esi, 0x00
000071e7f4dd6d68  mov rax, 0x562A51E82530
000071e7f4dd6d72  call rax
000071e7f4dd6d74  movaps xmm6, [rsp]
000071e7f4dd6d78  add rsp, 0x30
000071e7f4dd6d7c  vmovaps xmm0, [rsp]
000071e7f4dd6d81  vmovaps xmm1, [rsp+0x10]
000071e7f4dd6d87  vmovaps xmm2, [rsp+0x20]
000071e7f4dd6d8d  vmovaps xmm3, [rsp+0x30]
000071e7f4dd6d93  vmovaps xmm4, [rsp+0x40]
000071e7f4dd6d99  vmovaps xmm5, [rsp+0x50]
000071e7f4dd6d9f  vmovaps xmm7, [rsp+0x60]
000071e7f4dd6da5  vmovaps xmm8, [rsp+0x70]
000071e7f4dd6dab  vmovaps xmm9, [rsp+0x80]
000071e7f4dd6db4  vmovaps xmm10, [rsp+0x90]
000071e7f4dd6dbd  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd6dc6  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd6dcf  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd6dd8  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd6de1  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd6dea  add rsp, 0xF0
000071e7f4dd6df1  pop r11
000071e7f4dd6df3  pop r10
000071e7f4dd6df5  pop r9
000071e7f4dd6df7  pop r8
000071e7f4dd6df9  pop rsi
000071e7f4dd6dfa  pop rdi
000071e7f4dd6dfb  pop rdx
000071e7f4dd6dfc  pop rcx
000071e7f4dd6dfd  pop rax
000071e7f4dd6dfe  add rsp, 0x08
000071e7f4dd6e02  jmp 0x000071E7F4DD5A27
000071e7f4dd6e07  sub rsp, 0x08
000071e7f4dd6e0b  push rax
000071e7f4dd6e0c  push rcx
000071e7f4dd6e0d  push rdx
000071e7f4dd6e0e  push rdi
000071e7f4dd6e0f  push rsi
000071e7f4dd6e10  push r8
000071e7f4dd6e12  push r9
000071e7f4dd6e14  push r10
000071e7f4dd6e16  push r11
000071e7f4dd6e18  sub rsp, 0xF0
000071e7f4dd6e1f  vmovaps [rsp], xmm0
000071e7f4dd6e24  vmovaps [rsp+0x10], xmm1
000071e7f4dd6e2a  vmovaps [rsp+0x20], xmm2
000071e7f4dd6e30  vmovaps [rsp+0x30], xmm4
000071e7f4dd6e36  vmovaps [rsp+0x40], xmm5
000071e7f4dd6e3c  vmovaps [rsp+0x50], xmm6
000071e7f4dd6e42  vmovaps [rsp+0x60], xmm7
000071e7f4dd6e48  vmovaps [rsp+0x70], xmm8
000071e7f4dd6e4e  vmovaps [rsp+0x80], xmm9
000071e7f4dd6e57  vmovaps [rsp+0x90], xmm10
000071e7f4dd6e60  vmovaps [rsp+0xA0], xmm11
000071e7f4dd6e69  vmovaps [rsp+0xB0], xmm12
000071e7f4dd6e72  vmovaps [rsp+0xC0], xmm13
000071e7f4dd6e7b  vmovaps [rsp+0xD0], xmm14
000071e7f4dd6e84  vmovaps [rsp+0xE0], xmm15
000071e7f4dd6e8d  sub rsp, 0x30
000071e7f4dd6e91  movaps [rsp], xmm3
000071e7f4dd6e95  movaps [rsp+0x10], xmm5
000071e7f4dd6e9a  movaps [rsp+0x20], xmm4
000071e7f4dd6e9f  lea rdi, [rsp]
000071e7f4dd6ea3  mov esi, 0x00
000071e7f4dd6ea8  mov rax, 0x562A51E82530
000071e7f4dd6eb2  call rax
000071e7f4dd6eb4  movaps xmm3, [rsp]
000071e7f4dd6eb8  add rsp, 0x30
000071e7f4dd6ebc  vmovaps xmm0, [rsp]
000071e7f4dd6ec1  vmovaps xmm1, [rsp+0x10]
000071e7f4dd6ec7  vmovaps xmm2, [rsp+0x20]
000071e7f4dd6ecd  vmovaps xmm4, [rsp+0x30]
000071e7f4dd6ed3  vmovaps xmm5, [rsp+0x40]
000071e7f4dd6ed9  vmovaps xmm6, [rsp+0x50]
000071e7f4dd6edf  vmovaps xmm7, [rsp+0x60]
000071e7f4dd6ee5  vmovaps xmm8, [rsp+0x70]
000071e7f4dd6eeb  vmovaps xmm9, [rsp+0x80]
000071e7f4dd6ef4  vmovaps xmm10, [rsp+0x90]
000071e7f4dd6efd  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd6f06  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd6f0f  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd6f18  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd6f21  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd6f2a  add rsp, 0xF0
000071e7f4dd6f31  pop r11
000071e7f4dd6f33  pop r10
000071e7f4dd6f35  pop r9
000071e7f4dd6f37  pop r8
000071e7f4dd6f39  pop rsi
000071e7f4dd6f3a  pop rdi
000071e7f4dd6f3b  pop rdx
000071e7f4dd6f3c  pop rcx
000071e7f4dd6f3d  pop rax
000071e7f4dd6f3e  add rsp, 0x08
000071e7f4dd6f42  jmp 0x000071E7F4DD5A88
000071e7f4dd6f47  sub rsp, 0x08
000071e7f4dd6f4b  push rax
000071e7f4dd6f4c  push rcx
000071e7f4dd6f4d  push rdx
000071e7f4dd6f4e  push rdi
000071e7f4dd6f4f  push rsi
000071e7f4dd6f50  push r8
000071e7f4dd6f52  push r9
000071e7f4dd6f54  push r10
000071e7f4dd6f56  push r11
000071e7f4dd6f58  sub rsp, 0xF0
000071e7f4dd6f5f  vmovaps [rsp], xmm0
000071e7f4dd6f64  vmovaps [rsp+0x10], xmm1
000071e7f4dd6f6a  vmovaps [rsp+0x20], xmm2
000071e7f4dd6f70  vmovaps [rsp+0x30], xmm3
000071e7f4dd6f76  vmovaps [rsp+0x40], xmm4
000071e7f4dd6f7c  vmovaps [rsp+0x50], xmm6
000071e7f4dd6f82  vmovaps [rsp+0x60], xmm7
000071e7f4dd6f88  vmovaps [rsp+0x70], xmm8
000071e7f4dd6f8e  vmovaps [rsp+0x80], xmm9
000071e7f4dd6f97  vmovaps [rsp+0x90], xmm10
000071e7f4dd6fa0  vmovaps [rsp+0xA0], xmm11
000071e7f4dd6fa9  vmovaps [rsp+0xB0], xmm12
000071e7f4dd6fb2  vmovaps [rsp+0xC0], xmm13
000071e7f4dd6fbb  vmovaps [rsp+0xD0], xmm14
000071e7f4dd6fc4  vmovaps [rsp+0xE0], xmm15
000071e7f4dd6fcd  sub rsp, 0x30
000071e7f4dd6fd1  movaps [rsp], xmm5
000071e7f4dd6fd5  movaps [rsp+0x10], xmm8
000071e7f4dd6fdb  movaps [rsp+0x20], xmm15
000071e7f4dd6fe1  lea rdi, [rsp]
000071e7f4dd6fe5  mov esi, 0x00
000071e7f4dd6fea  mov rax, 0x562A51E82530
000071e7f4dd6ff4  call rax
000071e7f4dd6ff6  movaps xmm5, [rsp]
000071e7f4dd6ffa  add rsp, 0x30
000071e7f4dd6ffe  vmovaps xmm0, [rsp]
000071e7f4dd7003  vmovaps xmm1, [rsp+0x10]
000071e7f4dd7009  vmovaps xmm2, [rsp+0x20]
000071e7f4dd700f  vmovaps xmm3, [rsp+0x30]
000071e7f4dd7015  vmovaps xmm4, [rsp+0x40]
000071e7f4dd701b  vmovaps xmm6, [rsp+0x50]
000071e7f4dd7021  vmovaps xmm7, [rsp+0x60]
000071e7f4dd7027  vmovaps xmm8, [rsp+0x70]
000071e7f4dd702d  vmovaps xmm9, [rsp+0x80]
000071e7f4dd7036  vmovaps xmm10, [rsp+0x90]
000071e7f4dd703f  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd7048  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd7051  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd705a  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd7063  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd706c  add rsp, 0xF0
000071e7f4dd7073  pop r11
000071e7f4dd7075  pop r10
000071e7f4dd7077  pop r9
000071e7f4dd7079  pop r8
000071e7f4dd707b  pop rsi
000071e7f4dd707c  pop rdi
000071e7f4dd707d  pop rdx
000071e7f4dd707e  pop rcx
000071e7f4dd707f  pop rax
000071e7f4dd7080  add rsp, 0x08
000071e7f4dd7084  jmp 0x000071E7F4DD5AC0
000071e7f4dd7089  sub rsp, 0x08
000071e7f4dd708d  push rax
000071e7f4dd708e  push rcx
000071e7f4dd708f  push rdx
000071e7f4dd7090  push rdi
000071e7f4dd7091  push rsi
000071e7f4dd7092  push r8
000071e7f4dd7094  push r9
000071e7f4dd7096  push r10
000071e7f4dd7098  push r11
000071e7f4dd709a  sub rsp, 0xF0
000071e7f4dd70a1  vmovaps [rsp], xmm0
000071e7f4dd70a6  vmovaps [rsp+0x10], xmm1
000071e7f4dd70ac  vmovaps [rsp+0x20], xmm2
000071e7f4dd70b2  vmovaps [rsp+0x30], xmm3
000071e7f4dd70b8  vmovaps [rsp+0x40], xmm5
000071e7f4dd70be  vmovaps [rsp+0x50], xmm6
000071e7f4dd70c4  vmovaps [rsp+0x60], xmm7
000071e7f4dd70ca  vmovaps [rsp+0x70], xmm8
000071e7f4dd70d0  vmovaps [rsp+0x80], xmm9
000071e7f4dd70d9  vmovaps [rsp+0x90], xmm10
000071e7f4dd70e2  vmovaps [rsp+0xA0], xmm11
000071e7f4dd70eb  vmovaps [rsp+0xB0], xmm12
000071e7f4dd70f4  vmovaps [rsp+0xC0], xmm13
000071e7f4dd70fd  vmovaps [rsp+0xD0], xmm14
000071e7f4dd7106  vmovaps [rsp+0xE0], xmm15
000071e7f4dd710f  sub rsp, 0x30
000071e7f4dd7113  movaps [rsp], xmm4
000071e7f4dd7117  movaps [rsp+0x10], xmm9
000071e7f4dd711d  movaps [rsp+0x20], xmm8
000071e7f4dd7123  lea rdi, [rsp]
000071e7f4dd7127  mov esi, 0x00
000071e7f4dd712c  mov rax, 0x562A51E82530
000071e7f4dd7136  call rax
000071e7f4dd7138  movaps xmm4, [rsp]
000071e7f4dd713c  add rsp, 0x30
000071e7f4dd7140  vmovaps xmm0, [rsp]
000071e7f4dd7145  vmovaps xmm1, [rsp+0x10]
000071e7f4dd714b  vmovaps xmm2, [rsp+0x20]
000071e7f4dd7151  vmovaps xmm3, [rsp+0x30]
000071e7f4dd7157  vmovaps xmm5, [rsp+0x40]
000071e7f4dd715d  vmovaps xmm6, [rsp+0x50]
000071e7f4dd7163  vmovaps xmm7, [rsp+0x60]
000071e7f4dd7169  vmovaps xmm8, [rsp+0x70]
000071e7f4dd716f  vmovaps xmm9, [rsp+0x80]
000071e7f4dd7178  vmovaps xmm10, [rsp+0x90]
000071e7f4dd7181  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd718a  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd7193  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd719c  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd71a5  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd71ae  add rsp, 0xF0
000071e7f4dd71b5  pop r11
000071e7f4dd71b7  pop r10
000071e7f4dd71b9  pop r9
000071e7f4dd71bb  pop r8
000071e7f4dd71bd  pop rsi
000071e7f4dd71be  pop rdi
000071e7f4dd71bf  pop rdx
000071e7f4dd71c0  pop rcx
000071e7f4dd71c1  pop rax
000071e7f4dd71c2  add rsp, 0x08
000071e7f4dd71c6  jmp 0x000071E7F4DD5AE1
000071e7f4dd71cb  sub rsp, 0x08
000071e7f4dd71cf  push rax
000071e7f4dd71d0  push rcx
000071e7f4dd71d1  push rdx
000071e7f4dd71d2  push rdi
000071e7f4dd71d3  push rsi
000071e7f4dd71d4  push r8
000071e7f4dd71d6  push r9
000071e7f4dd71d8  push r10
000071e7f4dd71da  push r11
000071e7f4dd71dc  sub rsp, 0xF0
000071e7f4dd71e3  vmovaps [rsp], xmm0
000071e7f4dd71e8  vmovaps [rsp+0x10], xmm1
000071e7f4dd71ee  vmovaps [rsp+0x20], xmm2
000071e7f4dd71f4  vmovaps [rsp+0x30], xmm3
000071e7f4dd71fa  vmovaps [rsp+0x40], xmm4
000071e7f4dd7200  vmovaps [rsp+0x50], xmm5
000071e7f4dd7206  vmovaps [rsp+0x60], xmm6
000071e7f4dd720c  vmovaps [rsp+0x70], xmm7
000071e7f4dd7212  vmovaps [rsp+0x80], xmm8
000071e7f4dd721b  vmovaps [rsp+0x90], xmm10
000071e7f4dd7224  vmovaps [rsp+0xA0], xmm11
000071e7f4dd722d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd7236  vmovaps [rsp+0xC0], xmm13
000071e7f4dd723f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd7248  vmovaps [rsp+0xE0], xmm15
000071e7f4dd7251  sub rsp, 0x30
000071e7f4dd7255  movaps [rsp], xmm9
000071e7f4dd725a  movaps [rsp+0x10], xmm10
000071e7f4dd7260  movaps [rsp+0x20], xmm8
000071e7f4dd7266  lea rdi, [rsp]
000071e7f4dd726a  mov esi, 0x00
000071e7f4dd726f  mov rax, 0x562A51E82530
000071e7f4dd7279  call rax
000071e7f4dd727b  movaps xmm9, [rsp]
000071e7f4dd7280  add rsp, 0x30
000071e7f4dd7284  vmovaps xmm0, [rsp]
000071e7f4dd7289  vmovaps xmm1, [rsp+0x10]
000071e7f4dd728f  vmovaps xmm2, [rsp+0x20]
000071e7f4dd7295  vmovaps xmm3, [rsp+0x30]
000071e7f4dd729b  vmovaps xmm4, [rsp+0x40]
000071e7f4dd72a1  vmovaps xmm5, [rsp+0x50]
000071e7f4dd72a7  vmovaps xmm6, [rsp+0x60]
000071e7f4dd72ad  vmovaps xmm7, [rsp+0x70]
000071e7f4dd72b3  vmovaps xmm8, [rsp+0x80]
000071e7f4dd72bc  vmovaps xmm10, [rsp+0x90]
000071e7f4dd72c5  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd72ce  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd72d7  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd72e0  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd72e9  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd72f2  add rsp, 0xF0
000071e7f4dd72f9  pop r11
000071e7f4dd72fb  pop r10
000071e7f4dd72fd  pop r9
000071e7f4dd72ff  pop r8
000071e7f4dd7301  pop rsi
000071e7f4dd7302  pop rdi
000071e7f4dd7303  pop rdx
000071e7f4dd7304  pop rcx
000071e7f4dd7305  pop rax
000071e7f4dd7306  add rsp, 0x08
000071e7f4dd730a  jmp 0x000071E7F4DD5AFB
000071e7f4dd730f  call 0x000071E7F4CD64F0
000071e7f4dd7314  jmp 0x000071E7F4DD5C15
000071e7f4dd7319  call 0x000071E7F4CD64F0
000071e7f4dd731e  jmp 0x000071E7F4DD5C2B
000071e7f4dd7323  sub rsp, 0x08
000071e7f4dd7327  push rax
000071e7f4dd7328  push rcx
000071e7f4dd7329  push rdx
000071e7f4dd732a  push rdi
000071e7f4dd732b  push rsi
000071e7f4dd732c  push r8
000071e7f4dd732e  push r9
000071e7f4dd7330  push r10
000071e7f4dd7332  push r11
000071e7f4dd7334  sub rsp, 0xF0
000071e7f4dd733b  vmovaps [rsp], xmm0
000071e7f4dd7340  vmovaps [rsp+0x10], xmm2
000071e7f4dd7346  vmovaps [rsp+0x20], xmm3
000071e7f4dd734c  vmovaps [rsp+0x30], xmm4
000071e7f4dd7352  vmovaps [rsp+0x40], xmm5
000071e7f4dd7358  vmovaps [rsp+0x50], xmm6
000071e7f4dd735e  vmovaps [rsp+0x60], xmm7
000071e7f4dd7364  vmovaps [rsp+0x70], xmm8
000071e7f4dd736a  vmovaps [rsp+0x80], xmm9
000071e7f4dd7373  vmovaps [rsp+0x90], xmm10
000071e7f4dd737c  vmovaps [rsp+0xA0], xmm11
000071e7f4dd7385  vmovaps [rsp+0xB0], xmm12
000071e7f4dd738e  vmovaps [rsp+0xC0], xmm13
000071e7f4dd7397  vmovaps [rsp+0xD0], xmm14
000071e7f4dd73a0  vmovaps [rsp+0xE0], xmm15
000071e7f4dd73a9  sub rsp, 0x30
000071e7f4dd73ad  movaps [rsp], xmm1
000071e7f4dd73b1  movaps [rsp+0x10], xmm6
000071e7f4dd73b6  movaps [rsp+0x20], xmm15
000071e7f4dd73bc  lea rdi, [rsp]
000071e7f4dd73c0  mov esi, 0x00
000071e7f4dd73c5  mov rax, 0x562A51E82530
000071e7f4dd73cf  call rax
000071e7f4dd73d1  movaps xmm1, [rsp]
000071e7f4dd73d5  add rsp, 0x30
000071e7f4dd73d9  vmovaps xmm0, [rsp]
000071e7f4dd73de  vmovaps xmm2, [rsp+0x10]
000071e7f4dd73e4  vmovaps xmm3, [rsp+0x20]
000071e7f4dd73ea  vmovaps xmm4, [rsp+0x30]
000071e7f4dd73f0  vmovaps xmm5, [rsp+0x40]
000071e7f4dd73f6  vmovaps xmm6, [rsp+0x50]
000071e7f4dd73fc  vmovaps xmm7, [rsp+0x60]
000071e7f4dd7402  vmovaps xmm8, [rsp+0x70]
000071e7f4dd7408  vmovaps xmm9, [rsp+0x80]
000071e7f4dd7411  vmovaps xmm10, [rsp+0x90]
000071e7f4dd741a  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd7423  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd742c  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd7435  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd743e  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd7447  add rsp, 0xF0
000071e7f4dd744e  pop r11
000071e7f4dd7450  pop r10
000071e7f4dd7452  pop r9
000071e7f4dd7454  pop r8
000071e7f4dd7456  pop rsi
000071e7f4dd7457  pop rdi
000071e7f4dd7458  pop rdx
000071e7f4dd7459  pop rcx
000071e7f4dd745a  pop rax
000071e7f4dd745b  add rsp, 0x08
000071e7f4dd745f  jmp 0x000071E7F4DD5C68
000071e7f4dd7464  call 0x000071E7F4CE5820
000071e7f4dd7469  jmp 0x000071E7F4DD5C75
000071e7f4dd746e  sub rsp, 0x08
000071e7f4dd7472  push rax
000071e7f4dd7473  push rcx
000071e7f4dd7474  push rdx
000071e7f4dd7475  push rdi
000071e7f4dd7476  push rsi
000071e7f4dd7477  push r8
000071e7f4dd7479  push r9
000071e7f4dd747b  push r10
000071e7f4dd747d  push r11
000071e7f4dd747f  sub rsp, 0xF0
000071e7f4dd7486  vmovaps [rsp], xmm0
000071e7f4dd748b  vmovaps [rsp+0x10], xmm1
000071e7f4dd7491  vmovaps [rsp+0x20], xmm2
000071e7f4dd7497  vmovaps [rsp+0x30], xmm3
000071e7f4dd749d  vmovaps [rsp+0x40], xmm4
000071e7f4dd74a3  vmovaps [rsp+0x50], xmm5
000071e7f4dd74a9  vmovaps [rsp+0x60], xmm6
000071e7f4dd74af  vmovaps [rsp+0x70], xmm7
000071e7f4dd74b5  vmovaps [rsp+0x80], xmm8
000071e7f4dd74be  vmovaps [rsp+0x90], xmm9
000071e7f4dd74c7  vmovaps [rsp+0xA0], xmm10
000071e7f4dd74d0  vmovaps [rsp+0xB0], xmm11
000071e7f4dd74d9  vmovaps [rsp+0xC0], xmm12
000071e7f4dd74e2  vmovaps [rsp+0xD0], xmm13
000071e7f4dd74eb  vmovaps [rsp+0xE0], xmm15
000071e7f4dd74f4  sub rsp, 0x30
000071e7f4dd74f8  movaps [rsp], xmm14
000071e7f4dd74fd  movaps [rsp+0x10], xmm4
000071e7f4dd7502  movaps [rsp+0x20], xmm3
000071e7f4dd7507  lea rdi, [rsp]
000071e7f4dd750b  mov esi, 0x00
000071e7f4dd7510  mov rax, 0x562A51E82530
000071e7f4dd751a  call rax
000071e7f4dd751c  movaps xmm14, [rsp]
000071e7f4dd7521  add rsp, 0x30
000071e7f4dd7525  vmovaps xmm0, [rsp]
000071e7f4dd752a  vmovaps xmm1, [rsp+0x10]
000071e7f4dd7530  vmovaps xmm2, [rsp+0x20]
000071e7f4dd7536  vmovaps xmm3, [rsp+0x30]
000071e7f4dd753c  vmovaps xmm4, [rsp+0x40]
000071e7f4dd7542  vmovaps xmm5, [rsp+0x50]
000071e7f4dd7548  vmovaps xmm6, [rsp+0x60]
000071e7f4dd754e  vmovaps xmm7, [rsp+0x70]
000071e7f4dd7554  vmovaps xmm8, [rsp+0x80]
000071e7f4dd755d  vmovaps xmm9, [rsp+0x90]
000071e7f4dd7566  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd756f  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd7578  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd7581  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd758a  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd7593  add rsp, 0xF0
000071e7f4dd759a  pop r11
000071e7f4dd759c  pop r10
000071e7f4dd759e  pop r9
000071e7f4dd75a0  pop r8
000071e7f4dd75a2  pop rsi
000071e7f4dd75a3  pop rdi
000071e7f4dd75a4  pop rdx
000071e7f4dd75a5  pop rcx
000071e7f4dd75a6  pop rax
000071e7f4dd75a7  add rsp, 0x08
000071e7f4dd75ab  jmp 0x000071E7F4DD5C8F
000071e7f4dd75b0  sub rsp, 0x08
000071e7f4dd75b4  push rax
000071e7f4dd75b5  push rcx
000071e7f4dd75b6  push rdx
000071e7f4dd75b7  push rdi
000071e7f4dd75b8  push rsi
000071e7f4dd75b9  push r8
000071e7f4dd75bb  push r9
000071e7f4dd75bd  push r10
000071e7f4dd75bf  push r11
000071e7f4dd75c1  sub rsp, 0xF0
000071e7f4dd75c8  vmovaps [rsp], xmm0
000071e7f4dd75cd  vmovaps [rsp+0x10], xmm1
000071e7f4dd75d3  vmovaps [rsp+0x20], xmm2
000071e7f4dd75d9  vmovaps [rsp+0x30], xmm3
000071e7f4dd75df  vmovaps [rsp+0x40], xmm4
000071e7f4dd75e5  vmovaps [rsp+0x50], xmm5
000071e7f4dd75eb  vmovaps [rsp+0x60], xmm7
000071e7f4dd75f1  vmovaps [rsp+0x70], xmm8
000071e7f4dd75f7  vmovaps [rsp+0x80], xmm9
000071e7f4dd7600  vmovaps [rsp+0x90], xmm10
000071e7f4dd7609  vmovaps [rsp+0xA0], xmm11
000071e7f4dd7612  vmovaps [rsp+0xB0], xmm12
000071e7f4dd761b  vmovaps [rsp+0xC0], xmm13
000071e7f4dd7624  vmovaps [rsp+0xD0], xmm14
000071e7f4dd762d  vmovaps [rsp+0xE0], xmm15
000071e7f4dd7636  sub rsp, 0x30
000071e7f4dd763a  movaps [rsp], xmm6
000071e7f4dd763e  movaps [rsp+0x10], xmm9
000071e7f4dd7644  movaps [rsp+0x20], xmm7
000071e7f4dd7649  lea rdi, [rsp]
000071e7f4dd764d  mov esi, 0x00
000071e7f4dd7652  mov rax, 0x562A51E82530
000071e7f4dd765c  call rax
000071e7f4dd765e  movaps xmm6, [rsp]
000071e7f4dd7662  add rsp, 0x30
000071e7f4dd7666  vmovaps xmm0, [rsp]
000071e7f4dd766b  vmovaps xmm1, [rsp+0x10]
000071e7f4dd7671  vmovaps xmm2, [rsp+0x20]
000071e7f4dd7677  vmovaps xmm3, [rsp+0x30]
000071e7f4dd767d  vmovaps xmm4, [rsp+0x40]
000071e7f4dd7683  vmovaps xmm5, [rsp+0x50]
000071e7f4dd7689  vmovaps xmm7, [rsp+0x60]
000071e7f4dd768f  vmovaps xmm8, [rsp+0x70]
000071e7f4dd7695  vmovaps xmm9, [rsp+0x80]
000071e7f4dd769e  vmovaps xmm10, [rsp+0x90]
000071e7f4dd76a7  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd76b0  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd76b9  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd76c2  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd76cb  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd76d4  add rsp, 0xF0
000071e7f4dd76db  pop r11
000071e7f4dd76dd  pop r10
000071e7f4dd76df  pop r9
000071e7f4dd76e1  pop r8
000071e7f4dd76e3  pop rsi
000071e7f4dd76e4  pop rdi
000071e7f4dd76e5  pop rdx
000071e7f4dd76e6  pop rcx
000071e7f4dd76e7  pop rax
000071e7f4dd76e8  add rsp, 0x08
000071e7f4dd76ec  jmp 0x000071E7F4DD5CA7
000071e7f4dd76f1  sub rsp, 0x08
000071e7f4dd76f5  push rax
000071e7f4dd76f6  push rcx
000071e7f4dd76f7  push rdx
000071e7f4dd76f8  push rdi
000071e7f4dd76f9  push rsi
000071e7f4dd76fa  push r8
000071e7f4dd76fc  push r9
000071e7f4dd76fe  push r10
000071e7f4dd7700  push r11
000071e7f4dd7702  sub rsp, 0xF0
000071e7f4dd7709  vmovaps [rsp], xmm0
000071e7f4dd770e  vmovaps [rsp+0x10], xmm1
000071e7f4dd7714  vmovaps [rsp+0x20], xmm2
000071e7f4dd771a  vmovaps [rsp+0x30], xmm3
000071e7f4dd7720  vmovaps [rsp+0x40], xmm4
000071e7f4dd7726  vmovaps [rsp+0x50], xmm5
000071e7f4dd772c  vmovaps [rsp+0x60], xmm6
000071e7f4dd7732  vmovaps [rsp+0x70], xmm8
000071e7f4dd7738  vmovaps [rsp+0x80], xmm9
000071e7f4dd7741  vmovaps [rsp+0x90], xmm10
000071e7f4dd774a  vmovaps [rsp+0xA0], xmm11
000071e7f4dd7753  vmovaps [rsp+0xB0], xmm12
000071e7f4dd775c  vmovaps [rsp+0xC0], xmm13
000071e7f4dd7765  vmovaps [rsp+0xD0], xmm14
000071e7f4dd776e  vmovaps [rsp+0xE0], xmm15
000071e7f4dd7777  sub rsp, 0x30
000071e7f4dd777b  movaps [rsp], xmm7
000071e7f4dd777f  movaps [rsp+0x10], xmm4
000071e7f4dd7784  movaps [rsp+0x20], xmm9
000071e7f4dd778a  lea rdi, [rsp]
000071e7f4dd778e  mov esi, 0x00
000071e7f4dd7793  mov rax, 0x562A51E82530
000071e7f4dd779d  call rax
000071e7f4dd779f  movaps xmm7, [rsp]
000071e7f4dd77a3  add rsp, 0x30
000071e7f4dd77a7  vmovaps xmm0, [rsp]
000071e7f4dd77ac  vmovaps xmm1, [rsp+0x10]
000071e7f4dd77b2  vmovaps xmm2, [rsp+0x20]
000071e7f4dd77b8  vmovaps xmm3, [rsp+0x30]
000071e7f4dd77be  vmovaps xmm4, [rsp+0x40]
000071e7f4dd77c4  vmovaps xmm5, [rsp+0x50]
000071e7f4dd77ca  vmovaps xmm6, [rsp+0x60]
000071e7f4dd77d0  vmovaps xmm8, [rsp+0x70]
000071e7f4dd77d6  vmovaps xmm9, [rsp+0x80]
000071e7f4dd77df  vmovaps xmm10, [rsp+0x90]
000071e7f4dd77e8  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd77f1  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd77fa  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd7803  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd780c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd7815  add rsp, 0xF0
000071e7f4dd781c  pop r11
000071e7f4dd781e  pop r10
000071e7f4dd7820  pop r9
000071e7f4dd7822  pop r8
000071e7f4dd7824  pop rsi
000071e7f4dd7825  pop rdi
000071e7f4dd7826  pop rdx
000071e7f4dd7827  pop rcx
000071e7f4dd7828  pop rax
000071e7f4dd7829  add rsp, 0x08
000071e7f4dd782d  jmp 0x000071E7F4DD5CD4
000071e7f4dd7832  sub rsp, 0x08
000071e7f4dd7836  push rax
000071e7f4dd7837  push rcx
000071e7f4dd7838  push rdx
000071e7f4dd7839  push rdi
000071e7f4dd783a  push rsi
000071e7f4dd783b  push r8
000071e7f4dd783d  push r9
000071e7f4dd783f  push r10
000071e7f4dd7841  push r11
000071e7f4dd7843  sub rsp, 0xF0
000071e7f4dd784a  vmovaps [rsp], xmm0
000071e7f4dd784f  vmovaps [rsp+0x10], xmm1
000071e7f4dd7855  vmovaps [rsp+0x20], xmm2
000071e7f4dd785b  vmovaps [rsp+0x30], xmm3
000071e7f4dd7861  vmovaps [rsp+0x40], xmm5
000071e7f4dd7867  vmovaps [rsp+0x50], xmm6
000071e7f4dd786d  vmovaps [rsp+0x60], xmm7
000071e7f4dd7873  vmovaps [rsp+0x70], xmm8
000071e7f4dd7879  vmovaps [rsp+0x80], xmm9
000071e7f4dd7882  vmovaps [rsp+0x90], xmm10
000071e7f4dd788b  vmovaps [rsp+0xA0], xmm11
000071e7f4dd7894  vmovaps [rsp+0xB0], xmm12
000071e7f4dd789d  vmovaps [rsp+0xC0], xmm13
000071e7f4dd78a6  vmovaps [rsp+0xD0], xmm14
000071e7f4dd78af  vmovaps [rsp+0xE0], xmm15
000071e7f4dd78b8  sub rsp, 0x30
000071e7f4dd78bc  movaps [rsp], xmm4
000071e7f4dd78c0  movaps [rsp+0x10], xmm15
000071e7f4dd78c6  movaps [rsp+0x20], xmm9
000071e7f4dd78cc  lea rdi, [rsp]
000071e7f4dd78d0  mov esi, 0x00
000071e7f4dd78d5  mov rax, 0x562A51E82530
000071e7f4dd78df  call rax
000071e7f4dd78e1  movaps xmm4, [rsp]
000071e7f4dd78e5  add rsp, 0x30
000071e7f4dd78e9  vmovaps xmm0, [rsp]
000071e7f4dd78ee  vmovaps xmm1, [rsp+0x10]
000071e7f4dd78f4  vmovaps xmm2, [rsp+0x20]
000071e7f4dd78fa  vmovaps xmm3, [rsp+0x30]
000071e7f4dd7900  vmovaps xmm5, [rsp+0x40]
000071e7f4dd7906  vmovaps xmm6, [rsp+0x50]
000071e7f4dd790c  vmovaps xmm7, [rsp+0x60]
000071e7f4dd7912  vmovaps xmm8, [rsp+0x70]
000071e7f4dd7918  vmovaps xmm9, [rsp+0x80]
000071e7f4dd7921  vmovaps xmm10, [rsp+0x90]
000071e7f4dd792a  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd7933  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd793c  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd7945  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd794e  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd7957  add rsp, 0xF0
000071e7f4dd795e  pop r11
000071e7f4dd7960  pop r10
000071e7f4dd7962  pop r9
000071e7f4dd7964  pop r8
000071e7f4dd7966  pop rsi
000071e7f4dd7967  pop rdi
000071e7f4dd7968  pop rdx
000071e7f4dd7969  pop rcx
000071e7f4dd796a  pop rax
000071e7f4dd796b  add rsp, 0x08
000071e7f4dd796f  jmp 0x000071E7F4DD5CF9
000071e7f4dd7974  call 0x000071E7F4CE5820
000071e7f4dd7979  jmp 0x000071E7F4DD5D06
000071e7f4dd797e  sub rsp, 0x08
000071e7f4dd7982  push rax
000071e7f4dd7983  push rcx
000071e7f4dd7984  push rdx
000071e7f4dd7985  push rdi
000071e7f4dd7986  push rsi
000071e7f4dd7987  push r8
000071e7f4dd7989  push r9
000071e7f4dd798b  push r10
000071e7f4dd798d  push r11
000071e7f4dd798f  sub rsp, 0xF0
000071e7f4dd7996  vmovaps [rsp], xmm0
000071e7f4dd799b  vmovaps [rsp+0x10], xmm1
000071e7f4dd79a1  vmovaps [rsp+0x20], xmm2
000071e7f4dd79a7  vmovaps [rsp+0x30], xmm4
000071e7f4dd79ad  vmovaps [rsp+0x40], xmm5
000071e7f4dd79b3  vmovaps [rsp+0x50], xmm6
000071e7f4dd79b9  vmovaps [rsp+0x60], xmm7
000071e7f4dd79bf  vmovaps [rsp+0x70], xmm8
000071e7f4dd79c5  vmovaps [rsp+0x80], xmm9
000071e7f4dd79ce  vmovaps [rsp+0x90], xmm10
000071e7f4dd79d7  vmovaps [rsp+0xA0], xmm11
000071e7f4dd79e0  vmovaps [rsp+0xB0], xmm12
000071e7f4dd79e9  vmovaps [rsp+0xC0], xmm13
000071e7f4dd79f2  vmovaps [rsp+0xD0], xmm14
000071e7f4dd79fb  vmovaps [rsp+0xE0], xmm15
000071e7f4dd7a04  sub rsp, 0x30
000071e7f4dd7a08  movaps [rsp], xmm3
000071e7f4dd7a0c  movaps [rsp+0x10], xmm1
000071e7f4dd7a11  movaps [rsp+0x20], xmm9
000071e7f4dd7a17  lea rdi, [rsp]
000071e7f4dd7a1b  mov esi, 0x00
000071e7f4dd7a20  mov rax, 0x562A51E82530
000071e7f4dd7a2a  call rax
000071e7f4dd7a2c  movaps xmm3, [rsp]
000071e7f4dd7a30  add rsp, 0x30
000071e7f4dd7a34  vmovaps xmm0, [rsp]
000071e7f4dd7a39  vmovaps xmm1, [rsp+0x10]
000071e7f4dd7a3f  vmovaps xmm2, [rsp+0x20]
000071e7f4dd7a45  vmovaps xmm4, [rsp+0x30]
000071e7f4dd7a4b  vmovaps xmm5, [rsp+0x40]
000071e7f4dd7a51  vmovaps xmm6, [rsp+0x50]
000071e7f4dd7a57  vmovaps xmm7, [rsp+0x60]
000071e7f4dd7a5d  vmovaps xmm8, [rsp+0x70]
000071e7f4dd7a63  vmovaps xmm9, [rsp+0x80]
000071e7f4dd7a6c  vmovaps xmm10, [rsp+0x90]
000071e7f4dd7a75  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd7a7e  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd7a87  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd7a90  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd7a99  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd7aa2  add rsp, 0xF0
000071e7f4dd7aa9  pop r11
000071e7f4dd7aab  pop r10
000071e7f4dd7aad  pop r9
000071e7f4dd7aaf  pop r8
000071e7f4dd7ab1  pop rsi
000071e7f4dd7ab2  pop rdi
000071e7f4dd7ab3  pop rdx
000071e7f4dd7ab4  pop rcx
000071e7f4dd7ab5  pop rax
000071e7f4dd7ab6  add rsp, 0x08
000071e7f4dd7aba  jmp 0x000071E7F4DD5D43
000071e7f4dd7abf  sub rsp, 0x08
000071e7f4dd7ac3  push rax
000071e7f4dd7ac4  push rcx
000071e7f4dd7ac5  push rdx
000071e7f4dd7ac6  push rdi
000071e7f4dd7ac7  push rsi
000071e7f4dd7ac8  push r8
000071e7f4dd7aca  push r9
000071e7f4dd7acc  push r10
000071e7f4dd7ace  push r11
000071e7f4dd7ad0  sub rsp, 0xF0
000071e7f4dd7ad7  vmovaps [rsp], xmm0
000071e7f4dd7adc  vmovaps [rsp+0x10], xmm2
000071e7f4dd7ae2  vmovaps [rsp+0x20], xmm3
000071e7f4dd7ae8  vmovaps [rsp+0x30], xmm4
000071e7f4dd7aee  vmovaps [rsp+0x40], xmm5
000071e7f4dd7af4  vmovaps [rsp+0x50], xmm6
000071e7f4dd7afa  vmovaps [rsp+0x60], xmm7
000071e7f4dd7b00  vmovaps [rsp+0x70], xmm8
000071e7f4dd7b06  vmovaps [rsp+0x80], xmm9
000071e7f4dd7b0f  vmovaps [rsp+0x90], xmm10
000071e7f4dd7b18  vmovaps [rsp+0xA0], xmm11
000071e7f4dd7b21  vmovaps [rsp+0xB0], xmm12
000071e7f4dd7b2a  vmovaps [rsp+0xC0], xmm13
000071e7f4dd7b33  vmovaps [rsp+0xD0], xmm14
000071e7f4dd7b3c  vmovaps [rsp+0xE0], xmm15
000071e7f4dd7b45  sub rsp, 0x30
000071e7f4dd7b49  movaps [rsp], xmm1
000071e7f4dd7b4d  movaps [rsp+0x10], xmm15
000071e7f4dd7b53  movaps [rsp+0x20], xmm9
000071e7f4dd7b59  lea rdi, [rsp]
000071e7f4dd7b5d  mov esi, 0x00
000071e7f4dd7b62  mov rax, 0x562A51E82530
000071e7f4dd7b6c  call rax
000071e7f4dd7b6e  movaps xmm1, [rsp]
000071e7f4dd7b72  add rsp, 0x30
000071e7f4dd7b76  vmovaps xmm0, [rsp]
000071e7f4dd7b7b  vmovaps xmm2, [rsp+0x10]
000071e7f4dd7b81  vmovaps xmm3, [rsp+0x20]
000071e7f4dd7b87  vmovaps xmm4, [rsp+0x30]
000071e7f4dd7b8d  vmovaps xmm5, [rsp+0x40]
000071e7f4dd7b93  vmovaps xmm6, [rsp+0x50]
000071e7f4dd7b99  vmovaps xmm7, [rsp+0x60]
000071e7f4dd7b9f  vmovaps xmm8, [rsp+0x70]
000071e7f4dd7ba5  vmovaps xmm9, [rsp+0x80]
000071e7f4dd7bae  vmovaps xmm10, [rsp+0x90]
000071e7f4dd7bb7  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd7bc0  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd7bc9  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd7bd2  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd7bdb  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd7be4  add rsp, 0xF0
000071e7f4dd7beb  pop r11
000071e7f4dd7bed  pop r10
000071e7f4dd7bef  pop r9
000071e7f4dd7bf1  pop r8
000071e7f4dd7bf3  pop rsi
000071e7f4dd7bf4  pop rdi
000071e7f4dd7bf5  pop rdx
000071e7f4dd7bf6  pop rcx
000071e7f4dd7bf7  pop rax
000071e7f4dd7bf8  add rsp, 0x08
000071e7f4dd7bfc  jmp 0x000071E7F4DD5DCB
000071e7f4dd7c01  call 0x000071E7F4CE5820
000071e7f4dd7c06  jmp 0x000071E7F4DD5DD8
000071e7f4dd7c0b  sub rsp, 0x08
000071e7f4dd7c0f  push rax
000071e7f4dd7c10  push rcx
000071e7f4dd7c11  push rdx
000071e7f4dd7c12  push rdi
000071e7f4dd7c13  push rsi
000071e7f4dd7c14  push r8
000071e7f4dd7c16  push r9
000071e7f4dd7c18  push r10
000071e7f4dd7c1a  push r11
000071e7f4dd7c1c  sub rsp, 0xF0
000071e7f4dd7c23  vmovaps [rsp], xmm0
000071e7f4dd7c28  vmovaps [rsp+0x10], xmm2
000071e7f4dd7c2e  vmovaps [rsp+0x20], xmm3
000071e7f4dd7c34  vmovaps [rsp+0x30], xmm4
000071e7f4dd7c3a  vmovaps [rsp+0x40], xmm5
000071e7f4dd7c40  vmovaps [rsp+0x50], xmm6
000071e7f4dd7c46  vmovaps [rsp+0x60], xmm7
000071e7f4dd7c4c  vmovaps [rsp+0x70], xmm8
000071e7f4dd7c52  vmovaps [rsp+0x80], xmm9
000071e7f4dd7c5b  vmovaps [rsp+0x90], xmm10
000071e7f4dd7c64  vmovaps [rsp+0xA0], xmm11
000071e7f4dd7c6d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd7c76  vmovaps [rsp+0xC0], xmm13
000071e7f4dd7c7f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd7c88  vmovaps [rsp+0xE0], xmm15
000071e7f4dd7c91  sub rsp, 0x30
000071e7f4dd7c95  movaps [rsp], xmm1
000071e7f4dd7c99  movaps [rsp+0x10], xmm5
000071e7f4dd7c9e  movaps [rsp+0x20], xmm7
000071e7f4dd7ca3  lea rdi, [rsp]
000071e7f4dd7ca7  mov esi, 0x00
000071e7f4dd7cac  mov rax, 0x562A51E82530
000071e7f4dd7cb6  call rax
000071e7f4dd7cb8  movaps xmm1, [rsp]
000071e7f4dd7cbc  add rsp, 0x30
000071e7f4dd7cc0  vmovaps xmm0, [rsp]
000071e7f4dd7cc5  vmovaps xmm2, [rsp+0x10]
000071e7f4dd7ccb  vmovaps xmm3, [rsp+0x20]
000071e7f4dd7cd1  vmovaps xmm4, [rsp+0x30]
000071e7f4dd7cd7  vmovaps xmm5, [rsp+0x40]
000071e7f4dd7cdd  vmovaps xmm6, [rsp+0x50]
000071e7f4dd7ce3  vmovaps xmm7, [rsp+0x60]
000071e7f4dd7ce9  vmovaps xmm8, [rsp+0x70]
000071e7f4dd7cef  vmovaps xmm9, [rsp+0x80]
000071e7f4dd7cf8  vmovaps xmm10, [rsp+0x90]
000071e7f4dd7d01  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd7d0a  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd7d13  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd7d1c  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd7d25  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd7d2e  add rsp, 0xF0
000071e7f4dd7d35  pop r11
000071e7f4dd7d37  pop r10
000071e7f4dd7d39  pop r9
000071e7f4dd7d3b  pop r8
000071e7f4dd7d3d  pop rsi
000071e7f4dd7d3e  pop rdi
000071e7f4dd7d3f  pop rdx
000071e7f4dd7d40  pop rcx
000071e7f4dd7d41  pop rax
000071e7f4dd7d42  add rsp, 0x08
000071e7f4dd7d46  jmp 0x000071E7F4DD5E7D
000071e7f4dd7d4b  sub rsp, 0x08
000071e7f4dd7d4f  push rax
000071e7f4dd7d50  push rcx
000071e7f4dd7d51  push rdx
000071e7f4dd7d52  push rdi
000071e7f4dd7d53  push rsi
000071e7f4dd7d54  push r8
000071e7f4dd7d56  push r9
000071e7f4dd7d58  push r10
000071e7f4dd7d5a  push r11
000071e7f4dd7d5c  sub rsp, 0xF0
000071e7f4dd7d63  vmovaps [rsp], xmm0
000071e7f4dd7d68  vmovaps [rsp+0x10], xmm1
000071e7f4dd7d6e  vmovaps [rsp+0x20], xmm2
000071e7f4dd7d74  vmovaps [rsp+0x30], xmm3
000071e7f4dd7d7a  vmovaps [rsp+0x40], xmm4
000071e7f4dd7d80  vmovaps [rsp+0x50], xmm5
000071e7f4dd7d86  vmovaps [rsp+0x60], xmm6
000071e7f4dd7d8c  vmovaps [rsp+0x70], xmm8
000071e7f4dd7d92  vmovaps [rsp+0x80], xmm9
000071e7f4dd7d9b  vmovaps [rsp+0x90], xmm10
000071e7f4dd7da4  vmovaps [rsp+0xA0], xmm11
000071e7f4dd7dad  vmovaps [rsp+0xB0], xmm12
000071e7f4dd7db6  vmovaps [rsp+0xC0], xmm13
000071e7f4dd7dbf  vmovaps [rsp+0xD0], xmm14
000071e7f4dd7dc8  vmovaps [rsp+0xE0], xmm15
000071e7f4dd7dd1  sub rsp, 0x30
000071e7f4dd7dd5  movaps [rsp], xmm7
000071e7f4dd7dd9  movaps [rsp+0x10], xmm5
000071e7f4dd7dde  movaps [rsp+0x20], xmm15
000071e7f4dd7de4  lea rdi, [rsp]
000071e7f4dd7de8  mov esi, 0x00
000071e7f4dd7ded  mov rax, 0x562A51E82530
000071e7f4dd7df7  call rax
000071e7f4dd7df9  movaps xmm7, [rsp]
000071e7f4dd7dfd  add rsp, 0x30
000071e7f4dd7e01  vmovaps xmm0, [rsp]
000071e7f4dd7e06  vmovaps xmm1, [rsp+0x10]
000071e7f4dd7e0c  vmovaps xmm2, [rsp+0x20]
000071e7f4dd7e12  vmovaps xmm3, [rsp+0x30]
000071e7f4dd7e18  vmovaps xmm4, [rsp+0x40]
000071e7f4dd7e1e  vmovaps xmm5, [rsp+0x50]
000071e7f4dd7e24  vmovaps xmm6, [rsp+0x60]
000071e7f4dd7e2a  vmovaps xmm8, [rsp+0x70]
000071e7f4dd7e30  vmovaps xmm9, [rsp+0x80]
000071e7f4dd7e39  vmovaps xmm10, [rsp+0x90]
000071e7f4dd7e42  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd7e4b  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd7e54  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd7e5d  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd7e66  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd7e6f  add rsp, 0xF0
000071e7f4dd7e76  pop r11
000071e7f4dd7e78  pop r10
000071e7f4dd7e7a  pop r9
000071e7f4dd7e7c  pop r8
000071e7f4dd7e7e  pop rsi
000071e7f4dd7e7f  pop rdi
000071e7f4dd7e80  pop rdx
000071e7f4dd7e81  pop rcx
000071e7f4dd7e82  pop rax
000071e7f4dd7e83  add rsp, 0x08
000071e7f4dd7e87  jmp 0x000071E7F4DD5EB3
000071e7f4dd7e8c  call 0x000071E7F4CD64F0
000071e7f4dd7e91  jmp 0x000071E7F4DD5EC0
000071e7f4dd7e96  sub rsp, 0x08
000071e7f4dd7e9a  push rax
000071e7f4dd7e9b  push rcx
000071e7f4dd7e9c  push rdx
000071e7f4dd7e9d  push rdi
000071e7f4dd7e9e  push rsi
000071e7f4dd7e9f  push r8
000071e7f4dd7ea1  push r9
000071e7f4dd7ea3  push r10
000071e7f4dd7ea5  push r11
000071e7f4dd7ea7  sub rsp, 0xF0
000071e7f4dd7eae  vmovaps [rsp], xmm0
000071e7f4dd7eb3  vmovaps [rsp+0x10], xmm1
000071e7f4dd7eb9  vmovaps [rsp+0x20], xmm2
000071e7f4dd7ebf  vmovaps [rsp+0x30], xmm3
000071e7f4dd7ec5  vmovaps [rsp+0x40], xmm4
000071e7f4dd7ecb  vmovaps [rsp+0x50], xmm5
000071e7f4dd7ed1  vmovaps [rsp+0x60], xmm6
000071e7f4dd7ed7  vmovaps [rsp+0x70], xmm7
000071e7f4dd7edd  vmovaps [rsp+0x80], xmm8
000071e7f4dd7ee6  vmovaps [rsp+0x90], xmm9
000071e7f4dd7eef  vmovaps [rsp+0xA0], xmm10
000071e7f4dd7ef8  vmovaps [rsp+0xB0], xmm11
000071e7f4dd7f01  vmovaps [rsp+0xC0], xmm12
000071e7f4dd7f0a  vmovaps [rsp+0xD0], xmm13
000071e7f4dd7f13  vmovaps [rsp+0xE0], xmm14
000071e7f4dd7f1c  sub rsp, 0x30
000071e7f4dd7f20  movaps [rsp], xmm15
000071e7f4dd7f25  movaps [rsp+0x10], xmm5
000071e7f4dd7f2a  movaps [rsp+0x20], xmm3
000071e7f4dd7f2f  lea rdi, [rsp]
000071e7f4dd7f33  mov esi, 0x00
000071e7f4dd7f38  mov rax, 0x562A51E82530
000071e7f4dd7f42  call rax
000071e7f4dd7f44  movaps xmm15, [rsp]
000071e7f4dd7f49  add rsp, 0x30
000071e7f4dd7f4d  vmovaps xmm0, [rsp]
000071e7f4dd7f52  vmovaps xmm1, [rsp+0x10]
000071e7f4dd7f58  vmovaps xmm2, [rsp+0x20]
000071e7f4dd7f5e  vmovaps xmm3, [rsp+0x30]
000071e7f4dd7f64  vmovaps xmm4, [rsp+0x40]
000071e7f4dd7f6a  vmovaps xmm5, [rsp+0x50]
000071e7f4dd7f70  vmovaps xmm6, [rsp+0x60]
000071e7f4dd7f76  vmovaps xmm7, [rsp+0x70]
000071e7f4dd7f7c  vmovaps xmm8, [rsp+0x80]
000071e7f4dd7f85  vmovaps xmm9, [rsp+0x90]
000071e7f4dd7f8e  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd7f97  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd7fa0  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd7fa9  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd7fb2  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd7fbb  add rsp, 0xF0
000071e7f4dd7fc2  pop r11
000071e7f4dd7fc4  pop r10
000071e7f4dd7fc6  pop r9
000071e7f4dd7fc8  pop r8
000071e7f4dd7fca  pop rsi
000071e7f4dd7fcb  pop rdi
000071e7f4dd7fcc  pop rdx
000071e7f4dd7fcd  pop rcx
000071e7f4dd7fce  pop rax
000071e7f4dd7fcf  add rsp, 0x08
000071e7f4dd7fd3  jmp 0x000071E7F4DD5EE6
000071e7f4dd7fd8  sub rsp, 0x08
000071e7f4dd7fdc  push rax
000071e7f4dd7fdd  push rcx
000071e7f4dd7fde  push rdx
000071e7f4dd7fdf  push rdi
000071e7f4dd7fe0  push rsi
000071e7f4dd7fe1  push r8
000071e7f4dd7fe3  push r9
000071e7f4dd7fe5  push r10
000071e7f4dd7fe7  push r11
000071e7f4dd7fe9  sub rsp, 0xF0
000071e7f4dd7ff0  vmovaps [rsp], xmm0
000071e7f4dd7ff5  vmovaps [rsp+0x10], xmm2
000071e7f4dd7ffb  vmovaps [rsp+0x20], xmm3
000071e7f4dd8001  vmovaps [rsp+0x30], xmm4
000071e7f4dd8007  vmovaps [rsp+0x40], xmm5
000071e7f4dd800d  vmovaps [rsp+0x50], xmm6
000071e7f4dd8013  vmovaps [rsp+0x60], xmm7
000071e7f4dd8019  vmovaps [rsp+0x70], xmm8
000071e7f4dd801f  vmovaps [rsp+0x80], xmm9
000071e7f4dd8028  vmovaps [rsp+0x90], xmm10
000071e7f4dd8031  vmovaps [rsp+0xA0], xmm11
000071e7f4dd803a  vmovaps [rsp+0xB0], xmm12
000071e7f4dd8043  vmovaps [rsp+0xC0], xmm13
000071e7f4dd804c  vmovaps [rsp+0xD0], xmm14
000071e7f4dd8055  vmovaps [rsp+0xE0], xmm15
000071e7f4dd805e  sub rsp, 0x30
000071e7f4dd8062  movaps [rsp], xmm1
000071e7f4dd8066  movaps [rsp+0x10], xmm5
000071e7f4dd806b  movaps [rsp+0x20], xmm4
000071e7f4dd8070  lea rdi, [rsp]
000071e7f4dd8074  mov esi, 0x00
000071e7f4dd8079  mov rax, 0x562A51E82530
000071e7f4dd8083  call rax
000071e7f4dd8085  movaps xmm1, [rsp]
000071e7f4dd8089  add rsp, 0x30
000071e7f4dd808d  vmovaps xmm0, [rsp]
000071e7f4dd8092  vmovaps xmm2, [rsp+0x10]
000071e7f4dd8098  vmovaps xmm3, [rsp+0x20]
000071e7f4dd809e  vmovaps xmm4, [rsp+0x30]
000071e7f4dd80a4  vmovaps xmm5, [rsp+0x40]
000071e7f4dd80aa  vmovaps xmm6, [rsp+0x50]
000071e7f4dd80b0  vmovaps xmm7, [rsp+0x60]
000071e7f4dd80b6  vmovaps xmm8, [rsp+0x70]
000071e7f4dd80bc  vmovaps xmm9, [rsp+0x80]
000071e7f4dd80c5  vmovaps xmm10, [rsp+0x90]
000071e7f4dd80ce  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd80d7  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd80e0  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd80e9  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd80f2  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd80fb  add rsp, 0xF0
000071e7f4dd8102  pop r11
000071e7f4dd8104  pop r10
000071e7f4dd8106  pop r9
000071e7f4dd8108  pop r8
000071e7f4dd810a  pop rsi
000071e7f4dd810b  pop rdi
000071e7f4dd810c  pop rdx
000071e7f4dd810d  pop rcx
000071e7f4dd810e  pop rax
000071e7f4dd810f  add rsp, 0x08
000071e7f4dd8113  jmp 0x000071E7F4DD5F06
000071e7f4dd8118  sub rsp, 0x08
000071e7f4dd811c  push rax
000071e7f4dd811d  push rcx
000071e7f4dd811e  push rdx
000071e7f4dd811f  push rdi
000071e7f4dd8120  push rsi
000071e7f4dd8121  push r8
000071e7f4dd8123  push r9
000071e7f4dd8125  push r10
000071e7f4dd8127  push r11
000071e7f4dd8129  sub rsp, 0xF0
000071e7f4dd8130  vmovaps [rsp], xmm0
000071e7f4dd8135  vmovaps [rsp+0x10], xmm1
000071e7f4dd813b  vmovaps [rsp+0x20], xmm2
000071e7f4dd8141  vmovaps [rsp+0x30], xmm3
000071e7f4dd8147  vmovaps [rsp+0x40], xmm5
000071e7f4dd814d  vmovaps [rsp+0x50], xmm6
000071e7f4dd8153  vmovaps [rsp+0x60], xmm7
000071e7f4dd8159  vmovaps [rsp+0x70], xmm8
000071e7f4dd815f  vmovaps [rsp+0x80], xmm9
000071e7f4dd8168  vmovaps [rsp+0x90], xmm10
000071e7f4dd8171  vmovaps [rsp+0xA0], xmm11
000071e7f4dd817a  vmovaps [rsp+0xB0], xmm12
000071e7f4dd8183  vmovaps [rsp+0xC0], xmm13
000071e7f4dd818c  vmovaps [rsp+0xD0], xmm14
000071e7f4dd8195  vmovaps [rsp+0xE0], xmm15
000071e7f4dd819e  sub rsp, 0x30
000071e7f4dd81a2  movaps [rsp], xmm4
000071e7f4dd81a6  movaps [rsp+0x10], xmm3
000071e7f4dd81ab  movaps [rsp+0x20], xmm5
000071e7f4dd81b0  lea rdi, [rsp]
000071e7f4dd81b4  mov esi, 0x00
000071e7f4dd81b9  mov rax, 0x562A51E82530
000071e7f4dd81c3  call rax
000071e7f4dd81c5  movaps xmm4, [rsp]
000071e7f4dd81c9  add rsp, 0x30
000071e7f4dd81cd  vmovaps xmm0, [rsp]
000071e7f4dd81d2  vmovaps xmm1, [rsp+0x10]
000071e7f4dd81d8  vmovaps xmm2, [rsp+0x20]
000071e7f4dd81de  vmovaps xmm3, [rsp+0x30]
000071e7f4dd81e4  vmovaps xmm5, [rsp+0x40]
000071e7f4dd81ea  vmovaps xmm6, [rsp+0x50]
000071e7f4dd81f0  vmovaps xmm7, [rsp+0x60]
000071e7f4dd81f6  vmovaps xmm8, [rsp+0x70]
000071e7f4dd81fc  vmovaps xmm9, [rsp+0x80]
000071e7f4dd8205  vmovaps xmm10, [rsp+0x90]
000071e7f4dd820e  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd8217  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd8220  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd8229  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd8232  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd823b  add rsp, 0xF0
000071e7f4dd8242  pop r11
000071e7f4dd8244  pop r10
000071e7f4dd8246  pop r9
000071e7f4dd8248  pop r8
000071e7f4dd824a  pop rsi
000071e7f4dd824b  pop rdi
000071e7f4dd824c  pop rdx
000071e7f4dd824d  pop rcx
000071e7f4dd824e  pop rax
000071e7f4dd824f  add rsp, 0x08
000071e7f4dd8253  jmp 0x000071E7F4DD5F54
000071e7f4dd8258  call 0x000071E7F4CD64F0
000071e7f4dd825d  jmp 0x000071E7F4DD5F61
000071e7f4dd8262  sub rsp, 0x08
000071e7f4dd8266  push rax
000071e7f4dd8267  push rcx
000071e7f4dd8268  push rdx
000071e7f4dd8269  push rdi
000071e7f4dd826a  push rsi
000071e7f4dd826b  push r8
000071e7f4dd826d  push r9
000071e7f4dd826f  push r10
000071e7f4dd8271  push r11
000071e7f4dd8273  sub rsp, 0xF0
000071e7f4dd827a  vmovaps [rsp], xmm0
000071e7f4dd827f  vmovaps [rsp+0x10], xmm1
000071e7f4dd8285  vmovaps [rsp+0x20], xmm2
000071e7f4dd828b  vmovaps [rsp+0x30], xmm3
000071e7f4dd8291  vmovaps [rsp+0x40], xmm4
000071e7f4dd8297  vmovaps [rsp+0x50], xmm6
000071e7f4dd829d  vmovaps [rsp+0x60], xmm7
000071e7f4dd82a3  vmovaps [rsp+0x70], xmm8
000071e7f4dd82a9  vmovaps [rsp+0x80], xmm9
000071e7f4dd82b2  vmovaps [rsp+0x90], xmm10
000071e7f4dd82bb  vmovaps [rsp+0xA0], xmm11
000071e7f4dd82c4  vmovaps [rsp+0xB0], xmm12
000071e7f4dd82cd  vmovaps [rsp+0xC0], xmm13
000071e7f4dd82d6  vmovaps [rsp+0xD0], xmm14
000071e7f4dd82df  vmovaps [rsp+0xE0], xmm15
000071e7f4dd82e8  sub rsp, 0x30
000071e7f4dd82ec  movaps [rsp], xmm5
000071e7f4dd82f0  movaps [rsp+0x10], xmm6
000071e7f4dd82f5  movaps [rsp+0x20], xmm3
000071e7f4dd82fa  lea rdi, [rsp]
000071e7f4dd82fe  mov esi, 0x00
000071e7f4dd8303  mov rax, 0x562A51E82530
000071e7f4dd830d  call rax
000071e7f4dd830f  movaps xmm5, [rsp]
000071e7f4dd8313  add rsp, 0x30
000071e7f4dd8317  vmovaps xmm0, [rsp]
000071e7f4dd831c  vmovaps xmm1, [rsp+0x10]
000071e7f4dd8322  vmovaps xmm2, [rsp+0x20]
000071e7f4dd8328  vmovaps xmm3, [rsp+0x30]
000071e7f4dd832e  vmovaps xmm4, [rsp+0x40]
000071e7f4dd8334  vmovaps xmm6, [rsp+0x50]
000071e7f4dd833a  vmovaps xmm7, [rsp+0x60]
000071e7f4dd8340  vmovaps xmm8, [rsp+0x70]
000071e7f4dd8346  vmovaps xmm9, [rsp+0x80]
000071e7f4dd834f  vmovaps xmm10, [rsp+0x90]
000071e7f4dd8358  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd8361  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd836a  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd8373  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd837c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd8385  add rsp, 0xF0
000071e7f4dd838c  pop r11
000071e7f4dd838e  pop r10
000071e7f4dd8390  pop r9
000071e7f4dd8392  pop r8
000071e7f4dd8394  pop rsi
000071e7f4dd8395  pop rdi
000071e7f4dd8396  pop rdx
000071e7f4dd8397  pop rcx
000071e7f4dd8398  pop rax
000071e7f4dd8399  add rsp, 0x08
000071e7f4dd839d  jmp 0x000071E7F4DD5F87
000071e7f4dd83a2  sub rsp, 0x08
000071e7f4dd83a6  push rax
000071e7f4dd83a7  push rcx
000071e7f4dd83a8  push rdx
000071e7f4dd83a9  push rdi
000071e7f4dd83aa  push rsi
000071e7f4dd83ab  push r8
000071e7f4dd83ad  push r9
000071e7f4dd83af  push r10
000071e7f4dd83b1  push r11
000071e7f4dd83b3  sub rsp, 0xF0
000071e7f4dd83ba  vmovaps [rsp], xmm0
000071e7f4dd83bf  vmovaps [rsp+0x10], xmm1
000071e7f4dd83c5  vmovaps [rsp+0x20], xmm2
000071e7f4dd83cb  vmovaps [rsp+0x30], xmm3
000071e7f4dd83d1  vmovaps [rsp+0x40], xmm4
000071e7f4dd83d7  vmovaps [rsp+0x50], xmm5
000071e7f4dd83dd  vmovaps [rsp+0x60], xmm7
000071e7f4dd83e3  vmovaps [rsp+0x70], xmm8
000071e7f4dd83e9  vmovaps [rsp+0x80], xmm9
000071e7f4dd83f2  vmovaps [rsp+0x90], xmm10
000071e7f4dd83fb  vmovaps [rsp+0xA0], xmm11
000071e7f4dd8404  vmovaps [rsp+0xB0], xmm12
000071e7f4dd840d  vmovaps [rsp+0xC0], xmm13
000071e7f4dd8416  vmovaps [rsp+0xD0], xmm14
000071e7f4dd841f  vmovaps [rsp+0xE0], xmm15
000071e7f4dd8428  sub rsp, 0x30
000071e7f4dd842c  movaps [rsp], xmm6
000071e7f4dd8430  movaps [rsp+0x10], xmm9
000071e7f4dd8436  movaps [rsp+0x20], xmm1
000071e7f4dd843b  lea rdi, [rsp]
000071e7f4dd843f  mov esi, 0x00
000071e7f4dd8444  mov rax, 0x562A51E82530
000071e7f4dd844e  call rax
000071e7f4dd8450  movaps xmm6, [rsp]
000071e7f4dd8454  add rsp, 0x30
000071e7f4dd8458  vmovaps xmm0, [rsp]
000071e7f4dd845d  vmovaps xmm1, [rsp+0x10]
000071e7f4dd8463  vmovaps xmm2, [rsp+0x20]
000071e7f4dd8469  vmovaps xmm3, [rsp+0x30]
000071e7f4dd846f  vmovaps xmm4, [rsp+0x40]
000071e7f4dd8475  vmovaps xmm5, [rsp+0x50]
000071e7f4dd847b  vmovaps xmm7, [rsp+0x60]
000071e7f4dd8481  vmovaps xmm8, [rsp+0x70]
000071e7f4dd8487  vmovaps xmm9, [rsp+0x80]
000071e7f4dd8490  vmovaps xmm10, [rsp+0x90]
000071e7f4dd8499  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd84a2  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd84ab  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd84b4  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd84bd  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd84c6  add rsp, 0xF0
000071e7f4dd84cd  pop r11
000071e7f4dd84cf  pop r10
000071e7f4dd84d1  pop r9
000071e7f4dd84d3  pop r8
000071e7f4dd84d5  pop rsi
000071e7f4dd84d6  pop rdi
000071e7f4dd84d7  pop rdx
000071e7f4dd84d8  pop rcx
000071e7f4dd84d9  pop rax
000071e7f4dd84da  add rsp, 0x08
000071e7f4dd84de  jmp 0x000071E7F4DD5FAB
000071e7f4dd84e3  sub rsp, 0x08
000071e7f4dd84e7  push rax
000071e7f4dd84e8  push rcx
000071e7f4dd84e9  push rdx
000071e7f4dd84ea  push rdi
000071e7f4dd84eb  push rsi
000071e7f4dd84ec  push r8
000071e7f4dd84ee  push r9
000071e7f4dd84f0  push r10
000071e7f4dd84f2  push r11
000071e7f4dd84f4  sub rsp, 0xF0
000071e7f4dd84fb  vmovaps [rsp], xmm0
000071e7f4dd8500  vmovaps [rsp+0x10], xmm1
000071e7f4dd8506  vmovaps [rsp+0x20], xmm2
000071e7f4dd850c  vmovaps [rsp+0x30], xmm3
000071e7f4dd8512  vmovaps [rsp+0x40], xmm4
000071e7f4dd8518  vmovaps [rsp+0x50], xmm5
000071e7f4dd851e  vmovaps [rsp+0x60], xmm6
000071e7f4dd8524  vmovaps [rsp+0x70], xmm7
000071e7f4dd852a  vmovaps [rsp+0x80], xmm8
000071e7f4dd8533  vmovaps [rsp+0x90], xmm10
000071e7f4dd853c  vmovaps [rsp+0xA0], xmm11
000071e7f4dd8545  vmovaps [rsp+0xB0], xmm12
000071e7f4dd854e  vmovaps [rsp+0xC0], xmm13
000071e7f4dd8557  vmovaps [rsp+0xD0], xmm14
000071e7f4dd8560  vmovaps [rsp+0xE0], xmm15
000071e7f4dd8569  sub rsp, 0x30
000071e7f4dd856d  movaps [rsp], xmm9
000071e7f4dd8572  movaps [rsp+0x10], xmm3
000071e7f4dd8577  movaps [rsp+0x20], xmm1
000071e7f4dd857c  lea rdi, [rsp]
000071e7f4dd8580  mov esi, 0x00
000071e7f4dd8585  mov rax, 0x562A51E82530
000071e7f4dd858f  call rax
000071e7f4dd8591  movaps xmm9, [rsp]
000071e7f4dd8596  add rsp, 0x30
000071e7f4dd859a  vmovaps xmm0, [rsp]
000071e7f4dd859f  vmovaps xmm1, [rsp+0x10]
000071e7f4dd85a5  vmovaps xmm2, [rsp+0x20]
000071e7f4dd85ab  vmovaps xmm3, [rsp+0x30]
000071e7f4dd85b1  vmovaps xmm4, [rsp+0x40]
000071e7f4dd85b7  vmovaps xmm5, [rsp+0x50]
000071e7f4dd85bd  vmovaps xmm6, [rsp+0x60]
000071e7f4dd85c3  vmovaps xmm7, [rsp+0x70]
000071e7f4dd85c9  vmovaps xmm8, [rsp+0x80]
000071e7f4dd85d2  vmovaps xmm10, [rsp+0x90]
000071e7f4dd85db  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd85e4  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd85ed  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd85f6  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd85ff  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd8608  add rsp, 0xF0
000071e7f4dd860f  pop r11
000071e7f4dd8611  pop r10
000071e7f4dd8613  pop r9
000071e7f4dd8615  pop r8
000071e7f4dd8617  pop rsi
000071e7f4dd8618  pop rdi
000071e7f4dd8619  pop rdx
000071e7f4dd861a  pop rcx
000071e7f4dd861b  pop rax
000071e7f4dd861c  add rsp, 0x08
000071e7f4dd8620  jmp 0x000071E7F4DD5FF7
000071e7f4dd8625  call 0x000071E7F4CD64F0
000071e7f4dd862a  jmp 0x000071E7F4DD6004
000071e7f4dd862f  sub rsp, 0x08
000071e7f4dd8633  push rax
000071e7f4dd8634  push rcx
000071e7f4dd8635  push rdx
000071e7f4dd8636  push rdi
000071e7f4dd8637  push rsi
000071e7f4dd8638  push r8
000071e7f4dd863a  push r9
000071e7f4dd863c  push r10
000071e7f4dd863e  push r11
000071e7f4dd8640  sub rsp, 0xF0
000071e7f4dd8647  vmovaps [rsp], xmm0
000071e7f4dd864c  vmovaps [rsp+0x10], xmm1
000071e7f4dd8652  vmovaps [rsp+0x20], xmm2
000071e7f4dd8658  vmovaps [rsp+0x30], xmm3
000071e7f4dd865e  vmovaps [rsp+0x40], xmm4
000071e7f4dd8664  vmovaps [rsp+0x50], xmm5
000071e7f4dd866a  vmovaps [rsp+0x60], xmm6
000071e7f4dd8670  vmovaps [rsp+0x70], xmm7
000071e7f4dd8676  vmovaps [rsp+0x80], xmm8
000071e7f4dd867f  vmovaps [rsp+0x90], xmm9
000071e7f4dd8688  vmovaps [rsp+0xA0], xmm10
000071e7f4dd8691  vmovaps [rsp+0xB0], xmm11
000071e7f4dd869a  vmovaps [rsp+0xC0], xmm12
000071e7f4dd86a3  vmovaps [rsp+0xD0], xmm13
000071e7f4dd86ac  vmovaps [rsp+0xE0], xmm14
000071e7f4dd86b5  sub rsp, 0x30
000071e7f4dd86b9  movaps [rsp], xmm15
000071e7f4dd86be  movaps [rsp+0x10], xmm3
000071e7f4dd86c3  movaps [rsp+0x20], xmm7
000071e7f4dd86c8  lea rdi, [rsp]
000071e7f4dd86cc  mov esi, 0x00
000071e7f4dd86d1  mov rax, 0x562A51E82530
000071e7f4dd86db  call rax
000071e7f4dd86dd  movaps xmm15, [rsp]
000071e7f4dd86e2  add rsp, 0x30
000071e7f4dd86e6  vmovaps xmm0, [rsp]
000071e7f4dd86eb  vmovaps xmm1, [rsp+0x10]
000071e7f4dd86f1  vmovaps xmm2, [rsp+0x20]
000071e7f4dd86f7  vmovaps xmm3, [rsp+0x30]
000071e7f4dd86fd  vmovaps xmm4, [rsp+0x40]
000071e7f4dd8703  vmovaps xmm5, [rsp+0x50]
000071e7f4dd8709  vmovaps xmm6, [rsp+0x60]
000071e7f4dd870f  vmovaps xmm7, [rsp+0x70]
000071e7f4dd8715  vmovaps xmm8, [rsp+0x80]
000071e7f4dd871e  vmovaps xmm9, [rsp+0x90]
000071e7f4dd8727  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd8730  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd8739  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd8742  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd874b  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd8754  add rsp, 0xF0
000071e7f4dd875b  pop r11
000071e7f4dd875d  pop r10
000071e7f4dd875f  pop r9
000071e7f4dd8761  pop r8
000071e7f4dd8763  pop rsi
000071e7f4dd8764  pop rdi
000071e7f4dd8765  pop rdx
000071e7f4dd8766  pop rcx
000071e7f4dd8767  pop rax
000071e7f4dd8768  add rsp, 0x08
000071e7f4dd876c  jmp 0x000071E7F4DD6030
000071e7f4dd8771  sub rsp, 0x08
000071e7f4dd8775  push rax
000071e7f4dd8776  push rcx
000071e7f4dd8777  push rdx
000071e7f4dd8778  push rdi
000071e7f4dd8779  push rsi
000071e7f4dd877a  push r8
000071e7f4dd877c  push r9
000071e7f4dd877e  push r10
000071e7f4dd8780  push r11
000071e7f4dd8782  sub rsp, 0xF0
000071e7f4dd8789  vmovaps [rsp], xmm0
000071e7f4dd878e  vmovaps [rsp+0x10], xmm1
000071e7f4dd8794  vmovaps [rsp+0x20], xmm2
000071e7f4dd879a  vmovaps [rsp+0x30], xmm4
000071e7f4dd87a0  vmovaps [rsp+0x40], xmm5
000071e7f4dd87a6  vmovaps [rsp+0x50], xmm6
000071e7f4dd87ac  vmovaps [rsp+0x60], xmm7
000071e7f4dd87b2  vmovaps [rsp+0x70], xmm8
000071e7f4dd87b8  vmovaps [rsp+0x80], xmm9
000071e7f4dd87c1  vmovaps [rsp+0x90], xmm10
000071e7f4dd87ca  vmovaps [rsp+0xA0], xmm11
000071e7f4dd87d3  vmovaps [rsp+0xB0], xmm12
000071e7f4dd87dc  vmovaps [rsp+0xC0], xmm13
000071e7f4dd87e5  vmovaps [rsp+0xD0], xmm14
000071e7f4dd87ee  vmovaps [rsp+0xE0], xmm15
000071e7f4dd87f7  sub rsp, 0x30
000071e7f4dd87fb  movaps [rsp], xmm3
000071e7f4dd87ff  movaps [rsp+0x10], xmm1
000071e7f4dd8804  movaps [rsp+0x20], xmm15
000071e7f4dd880a  lea rdi, [rsp]
000071e7f4dd880e  mov esi, 0x00
000071e7f4dd8813  mov rax, 0x562A51E82530
000071e7f4dd881d  call rax
000071e7f4dd881f  movaps xmm3, [rsp]
000071e7f4dd8823  add rsp, 0x30
000071e7f4dd8827  vmovaps xmm0, [rsp]
000071e7f4dd882c  vmovaps xmm1, [rsp+0x10]
000071e7f4dd8832  vmovaps xmm2, [rsp+0x20]
000071e7f4dd8838  vmovaps xmm4, [rsp+0x30]
000071e7f4dd883e  vmovaps xmm5, [rsp+0x40]
000071e7f4dd8844  vmovaps xmm6, [rsp+0x50]
000071e7f4dd884a  vmovaps xmm7, [rsp+0x60]
000071e7f4dd8850  vmovaps xmm8, [rsp+0x70]
000071e7f4dd8856  vmovaps xmm9, [rsp+0x80]
000071e7f4dd885f  vmovaps xmm10, [rsp+0x90]
000071e7f4dd8868  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd8871  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd887a  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd8883  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd888c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd8895  add rsp, 0xF0
000071e7f4dd889c  pop r11
000071e7f4dd889e  pop r10
000071e7f4dd88a0  pop r9
000071e7f4dd88a2  pop r8
000071e7f4dd88a4  pop rsi
000071e7f4dd88a5  pop rdi
000071e7f4dd88a6  pop rdx
000071e7f4dd88a7  pop rcx
000071e7f4dd88a8  pop rax
000071e7f4dd88a9  add rsp, 0x08
000071e7f4dd88ad  jmp 0x000071E7F4DD60BF
000071e7f4dd88b2  call 0x000071E7F4CD64F0
000071e7f4dd88b7  jmp 0x000071E7F4DD60C9
000071e7f4dd88bc  sub rsp, 0x08
000071e7f4dd88c0  push rax
000071e7f4dd88c1  push rcx
000071e7f4dd88c2  push rdx
000071e7f4dd88c3  push rdi
000071e7f4dd88c4  push rsi
000071e7f4dd88c5  push r8
000071e7f4dd88c7  push r9
000071e7f4dd88c9  push r10
000071e7f4dd88cb  push r11
000071e7f4dd88cd  sub rsp, 0xF0
000071e7f4dd88d4  vmovaps [rsp], xmm0
000071e7f4dd88d9  vmovaps [rsp+0x10], xmm1
000071e7f4dd88df  vmovaps [rsp+0x20], xmm2
000071e7f4dd88e5  vmovaps [rsp+0x30], xmm3
000071e7f4dd88eb  vmovaps [rsp+0x40], xmm4
000071e7f4dd88f1  vmovaps [rsp+0x50], xmm5
000071e7f4dd88f7  vmovaps [rsp+0x60], xmm6
000071e7f4dd88fd  vmovaps [rsp+0x70], xmm7
000071e7f4dd8903  vmovaps [rsp+0x80], xmm8
000071e7f4dd890c  vmovaps [rsp+0x90], xmm9
000071e7f4dd8915  vmovaps [rsp+0xA0], xmm10
000071e7f4dd891e  vmovaps [rsp+0xB0], xmm11
000071e7f4dd8927  vmovaps [rsp+0xC0], xmm12
000071e7f4dd8930  vmovaps [rsp+0xD0], xmm13
000071e7f4dd8939  vmovaps [rsp+0xE0], xmm14
000071e7f4dd8942  sub rsp, 0x30
000071e7f4dd8946  movaps [rsp], xmm15
000071e7f4dd894b  movaps [rsp+0x10], xmm14
000071e7f4dd8951  movaps [rsp+0x20], xmm4
000071e7f4dd8956  lea rdi, [rsp]
000071e7f4dd895a  mov esi, 0x00
000071e7f4dd895f  mov rax, 0x562A51E82530
000071e7f4dd8969  call rax
000071e7f4dd896b  movaps xmm15, [rsp]
000071e7f4dd8970  add rsp, 0x30
000071e7f4dd8974  vmovaps xmm0, [rsp]
000071e7f4dd8979  vmovaps xmm1, [rsp+0x10]
000071e7f4dd897f  vmovaps xmm2, [rsp+0x20]
000071e7f4dd8985  vmovaps xmm3, [rsp+0x30]
000071e7f4dd898b  vmovaps xmm4, [rsp+0x40]
000071e7f4dd8991  vmovaps xmm5, [rsp+0x50]
000071e7f4dd8997  vmovaps xmm6, [rsp+0x60]
000071e7f4dd899d  vmovaps xmm7, [rsp+0x70]
000071e7f4dd89a3  vmovaps xmm8, [rsp+0x80]
000071e7f4dd89ac  vmovaps xmm9, [rsp+0x90]
000071e7f4dd89b5  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd89be  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd89c7  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd89d0  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd89d9  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd89e2  add rsp, 0xF0
000071e7f4dd89e9  pop r11
000071e7f4dd89eb  pop r10
000071e7f4dd89ed  pop r9
000071e7f4dd89ef  pop r8
000071e7f4dd89f1  pop rsi
000071e7f4dd89f2  pop rdi
000071e7f4dd89f3  pop rdx
000071e7f4dd89f4  pop rcx
000071e7f4dd89f5  pop rax
000071e7f4dd89f6  add rsp, 0x08
000071e7f4dd89fa  jmp 0x000071E7F4DD60F7
000071e7f4dd89ff  sub rsp, 0x08
000071e7f4dd8a03  push rax
000071e7f4dd8a04  push rcx
000071e7f4dd8a05  push rdx
000071e7f4dd8a06  push rdi
000071e7f4dd8a07  push rsi
000071e7f4dd8a08  push r8
000071e7f4dd8a0a  push r9
000071e7f4dd8a0c  push r10
000071e7f4dd8a0e  push r11
000071e7f4dd8a10  sub rsp, 0xF0
000071e7f4dd8a17  vmovaps [rsp], xmm0
000071e7f4dd8a1c  vmovaps [rsp+0x10], xmm1
000071e7f4dd8a22  vmovaps [rsp+0x20], xmm2
000071e7f4dd8a28  vmovaps [rsp+0x30], xmm3
000071e7f4dd8a2e  vmovaps [rsp+0x40], xmm4
000071e7f4dd8a34  vmovaps [rsp+0x50], xmm5
000071e7f4dd8a3a  vmovaps [rsp+0x60], xmm6
000071e7f4dd8a40  vmovaps [rsp+0x70], xmm7
000071e7f4dd8a46  vmovaps [rsp+0x80], xmm8
000071e7f4dd8a4f  vmovaps [rsp+0x90], xmm9
000071e7f4dd8a58  vmovaps [rsp+0xA0], xmm10
000071e7f4dd8a61  vmovaps [rsp+0xB0], xmm11
000071e7f4dd8a6a  vmovaps [rsp+0xC0], xmm12
000071e7f4dd8a73  vmovaps [rsp+0xD0], xmm13
000071e7f4dd8a7c  vmovaps [rsp+0xE0], xmm15
000071e7f4dd8a85  sub rsp, 0x30
000071e7f4dd8a89  movaps [rsp], xmm14
000071e7f4dd8a8e  movaps [rsp+0x10], xmm2
000071e7f4dd8a93  movaps [rsp+0x20], xmm1
000071e7f4dd8a98  lea rdi, [rsp]
000071e7f4dd8a9c  mov esi, 0x00
000071e7f4dd8aa1  mov rax, 0x562A51E82530
000071e7f4dd8aab  call rax
000071e7f4dd8aad  movaps xmm14, [rsp]
000071e7f4dd8ab2  add rsp, 0x30
000071e7f4dd8ab6  vmovaps xmm0, [rsp]
000071e7f4dd8abb  vmovaps xmm1, [rsp+0x10]
000071e7f4dd8ac1  vmovaps xmm2, [rsp+0x20]
000071e7f4dd8ac7  vmovaps xmm3, [rsp+0x30]
000071e7f4dd8acd  vmovaps xmm4, [rsp+0x40]
000071e7f4dd8ad3  vmovaps xmm5, [rsp+0x50]
000071e7f4dd8ad9  vmovaps xmm6, [rsp+0x60]
000071e7f4dd8adf  vmovaps xmm7, [rsp+0x70]
000071e7f4dd8ae5  vmovaps xmm8, [rsp+0x80]
000071e7f4dd8aee  vmovaps xmm9, [rsp+0x90]
000071e7f4dd8af7  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd8b00  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd8b09  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd8b12  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd8b1b  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd8b24  add rsp, 0xF0
000071e7f4dd8b2b  pop r11
000071e7f4dd8b2d  pop r10
000071e7f4dd8b2f  pop r9
000071e7f4dd8b31  pop r8
000071e7f4dd8b33  pop rsi
000071e7f4dd8b34  pop rdi
000071e7f4dd8b35  pop rdx
000071e7f4dd8b36  pop rcx
000071e7f4dd8b37  pop rax
000071e7f4dd8b38  add rsp, 0x08
000071e7f4dd8b3c  jmp 0x000071E7F4DD611D
000071e7f4dd8b41  sub rsp, 0x08
000071e7f4dd8b45  push rax
000071e7f4dd8b46  push rcx
000071e7f4dd8b47  push rdx
000071e7f4dd8b48  push rdi
000071e7f4dd8b49  push rsi
000071e7f4dd8b4a  push r8
000071e7f4dd8b4c  push r9
000071e7f4dd8b4e  push r10
000071e7f4dd8b50  push r11
000071e7f4dd8b52  sub rsp, 0xF0
000071e7f4dd8b59  vmovaps [rsp], xmm0
000071e7f4dd8b5e  vmovaps [rsp+0x10], xmm2
000071e7f4dd8b64  vmovaps [rsp+0x20], xmm3
000071e7f4dd8b6a  vmovaps [rsp+0x30], xmm4
000071e7f4dd8b70  vmovaps [rsp+0x40], xmm5
000071e7f4dd8b76  vmovaps [rsp+0x50], xmm6
000071e7f4dd8b7c  vmovaps [rsp+0x60], xmm7
000071e7f4dd8b82  vmovaps [rsp+0x70], xmm8
000071e7f4dd8b88  vmovaps [rsp+0x80], xmm9
000071e7f4dd8b91  vmovaps [rsp+0x90], xmm10
000071e7f4dd8b9a  vmovaps [rsp+0xA0], xmm11
000071e7f4dd8ba3  vmovaps [rsp+0xB0], xmm12
000071e7f4dd8bac  vmovaps [rsp+0xC0], xmm13
000071e7f4dd8bb5  vmovaps [rsp+0xD0], xmm14
000071e7f4dd8bbe  vmovaps [rsp+0xE0], xmm15
000071e7f4dd8bc7  sub rsp, 0x30
000071e7f4dd8bcb  movaps [rsp], xmm1
000071e7f4dd8bcf  movaps [rsp+0x10], xmm4
000071e7f4dd8bd4  movaps [rsp+0x20], xmm9
000071e7f4dd8bda  lea rdi, [rsp]
000071e7f4dd8bde  mov esi, 0x00
000071e7f4dd8be3  mov rax, 0x562A51E82530
000071e7f4dd8bed  call rax
000071e7f4dd8bef  movaps xmm1, [rsp]
000071e7f4dd8bf3  add rsp, 0x30
000071e7f4dd8bf7  vmovaps xmm0, [rsp]
000071e7f4dd8bfc  vmovaps xmm2, [rsp+0x10]
000071e7f4dd8c02  vmovaps xmm3, [rsp+0x20]
000071e7f4dd8c08  vmovaps xmm4, [rsp+0x30]
000071e7f4dd8c0e  vmovaps xmm5, [rsp+0x40]
000071e7f4dd8c14  vmovaps xmm6, [rsp+0x50]
000071e7f4dd8c1a  vmovaps xmm7, [rsp+0x60]
000071e7f4dd8c20  vmovaps xmm8, [rsp+0x70]
000071e7f4dd8c26  vmovaps xmm9, [rsp+0x80]
000071e7f4dd8c2f  vmovaps xmm10, [rsp+0x90]
000071e7f4dd8c38  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd8c41  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd8c4a  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd8c53  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd8c5c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd8c65  add rsp, 0xF0
000071e7f4dd8c6c  pop r11
000071e7f4dd8c6e  pop r10
000071e7f4dd8c70  pop r9
000071e7f4dd8c72  pop r8
000071e7f4dd8c74  pop rsi
000071e7f4dd8c75  pop rdi
000071e7f4dd8c76  pop rdx
000071e7f4dd8c77  pop rcx
000071e7f4dd8c78  pop rax
000071e7f4dd8c79  add rsp, 0x08
000071e7f4dd8c7d  jmp 0x000071E7F4DD613B
000071e7f4dd8c82  sub rsp, 0x08
000071e7f4dd8c86  push rax
000071e7f4dd8c87  push rcx
000071e7f4dd8c88  push rdx
000071e7f4dd8c89  push rdi
000071e7f4dd8c8a  push rsi
000071e7f4dd8c8b  push r8
000071e7f4dd8c8d  push r9
000071e7f4dd8c8f  push r10
000071e7f4dd8c91  push r11
000071e7f4dd8c93  sub rsp, 0xF0
000071e7f4dd8c9a  vmovaps [rsp], xmm0
000071e7f4dd8c9f  vmovaps [rsp+0x10], xmm1
000071e7f4dd8ca5  vmovaps [rsp+0x20], xmm2
000071e7f4dd8cab  vmovaps [rsp+0x30], xmm3
000071e7f4dd8cb1  vmovaps [rsp+0x40], xmm5
000071e7f4dd8cb7  vmovaps [rsp+0x50], xmm6
000071e7f4dd8cbd  vmovaps [rsp+0x60], xmm7
000071e7f4dd8cc3  vmovaps [rsp+0x70], xmm8
000071e7f4dd8cc9  vmovaps [rsp+0x80], xmm9
000071e7f4dd8cd2  vmovaps [rsp+0x90], xmm10
000071e7f4dd8cdb  vmovaps [rsp+0xA0], xmm11
000071e7f4dd8ce4  vmovaps [rsp+0xB0], xmm12
000071e7f4dd8ced  vmovaps [rsp+0xC0], xmm13
000071e7f4dd8cf6  vmovaps [rsp+0xD0], xmm14
000071e7f4dd8cff  vmovaps [rsp+0xE0], xmm15
000071e7f4dd8d08  sub rsp, 0x30
000071e7f4dd8d0c  movaps [rsp], xmm4
000071e7f4dd8d10  movaps [rsp+0x10], xmm2
000071e7f4dd8d15  movaps [rsp+0x20], xmm9
000071e7f4dd8d1b  lea rdi, [rsp]
000071e7f4dd8d1f  mov esi, 0x00
000071e7f4dd8d24  mov rax, 0x562A51E82530
000071e7f4dd8d2e  call rax
000071e7f4dd8d30  movaps xmm4, [rsp]
000071e7f4dd8d34  add rsp, 0x30
000071e7f4dd8d38  vmovaps xmm0, [rsp]
000071e7f4dd8d3d  vmovaps xmm1, [rsp+0x10]
000071e7f4dd8d43  vmovaps xmm2, [rsp+0x20]
000071e7f4dd8d49  vmovaps xmm3, [rsp+0x30]
000071e7f4dd8d4f  vmovaps xmm5, [rsp+0x40]
000071e7f4dd8d55  vmovaps xmm6, [rsp+0x50]
000071e7f4dd8d5b  vmovaps xmm7, [rsp+0x60]
000071e7f4dd8d61  vmovaps xmm8, [rsp+0x70]
000071e7f4dd8d67  vmovaps xmm9, [rsp+0x80]
000071e7f4dd8d70  vmovaps xmm10, [rsp+0x90]
000071e7f4dd8d79  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd8d82  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd8d8b  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd8d94  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd8d9d  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd8da6  add rsp, 0xF0
000071e7f4dd8dad  pop r11
000071e7f4dd8daf  pop r10
000071e7f4dd8db1  pop r9
000071e7f4dd8db3  pop r8
000071e7f4dd8db5  pop rsi
000071e7f4dd8db6  pop rdi
000071e7f4dd8db7  pop rdx
000071e7f4dd8db8  pop rcx
000071e7f4dd8db9  pop rax
000071e7f4dd8dba  add rsp, 0x08
000071e7f4dd8dbe  jmp 0x000071E7F4DD616B
000071e7f4dd8dc3  sub rsp, 0x08
000071e7f4dd8dc7  push rax
000071e7f4dd8dc8  push rcx
000071e7f4dd8dc9  push rdx
000071e7f4dd8dca  push rdi
000071e7f4dd8dcb  push rsi
000071e7f4dd8dcc  push r8
000071e7f4dd8dce  push r9
000071e7f4dd8dd0  push r10
000071e7f4dd8dd2  push r11
000071e7f4dd8dd4  sub rsp, 0xF0
000071e7f4dd8ddb  vmovaps [rsp], xmm0
000071e7f4dd8de0  vmovaps [rsp+0x10], xmm1
000071e7f4dd8de6  vmovaps [rsp+0x20], xmm2
000071e7f4dd8dec  vmovaps [rsp+0x30], xmm3
000071e7f4dd8df2  vmovaps [rsp+0x40], xmm4
000071e7f4dd8df8  vmovaps [rsp+0x50], xmm5
000071e7f4dd8dfe  vmovaps [rsp+0x60], xmm6
000071e7f4dd8e04  vmovaps [rsp+0x70], xmm7
000071e7f4dd8e0a  vmovaps [rsp+0x80], xmm8
000071e7f4dd8e13  vmovaps [rsp+0x90], xmm10
000071e7f4dd8e1c  vmovaps [rsp+0xA0], xmm11
000071e7f4dd8e25  vmovaps [rsp+0xB0], xmm12
000071e7f4dd8e2e  vmovaps [rsp+0xC0], xmm13
000071e7f4dd8e37  vmovaps [rsp+0xD0], xmm14
000071e7f4dd8e40  vmovaps [rsp+0xE0], xmm15
000071e7f4dd8e49  sub rsp, 0x30
000071e7f4dd8e4d  movaps [rsp], xmm9
000071e7f4dd8e52  movaps [rsp+0x10], xmm2
000071e7f4dd8e57  movaps [rsp+0x20], xmm1
000071e7f4dd8e5c  lea rdi, [rsp]
000071e7f4dd8e60  mov esi, 0x00
000071e7f4dd8e65  mov rax, 0x562A51E82530
000071e7f4dd8e6f  call rax
000071e7f4dd8e71  movaps xmm9, [rsp]
000071e7f4dd8e76  add rsp, 0x30
000071e7f4dd8e7a  vmovaps xmm0, [rsp]
000071e7f4dd8e7f  vmovaps xmm1, [rsp+0x10]
000071e7f4dd8e85  vmovaps xmm2, [rsp+0x20]
000071e7f4dd8e8b  vmovaps xmm3, [rsp+0x30]
000071e7f4dd8e91  vmovaps xmm4, [rsp+0x40]
000071e7f4dd8e97  vmovaps xmm5, [rsp+0x50]
000071e7f4dd8e9d  vmovaps xmm6, [rsp+0x60]
000071e7f4dd8ea3  vmovaps xmm7, [rsp+0x70]
000071e7f4dd8ea9  vmovaps xmm8, [rsp+0x80]
000071e7f4dd8eb2  vmovaps xmm10, [rsp+0x90]
000071e7f4dd8ebb  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd8ec4  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd8ecd  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd8ed6  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd8edf  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd8ee8  add rsp, 0xF0
000071e7f4dd8eef  pop r11
000071e7f4dd8ef1  pop r10
000071e7f4dd8ef3  pop r9
000071e7f4dd8ef5  pop r8
000071e7f4dd8ef7  pop rsi
000071e7f4dd8ef8  pop rdi
000071e7f4dd8ef9  pop rdx
000071e7f4dd8efa  pop rcx
000071e7f4dd8efb  pop rax
000071e7f4dd8efc  add rsp, 0x08
000071e7f4dd8f00  jmp 0x000071E7F4DD61A1
000071e7f4dd8f05  sub rsp, 0x08
000071e7f4dd8f09  push rax
000071e7f4dd8f0a  push rcx
000071e7f4dd8f0b  push rdx
000071e7f4dd8f0c  push rdi
000071e7f4dd8f0d  push rsi
000071e7f4dd8f0e  push r8
000071e7f4dd8f10  push r9
000071e7f4dd8f12  push r10
000071e7f4dd8f14  push r11
000071e7f4dd8f16  sub rsp, 0xF0
000071e7f4dd8f1d  vmovaps [rsp], xmm0
000071e7f4dd8f22  vmovaps [rsp+0x10], xmm2
000071e7f4dd8f28  vmovaps [rsp+0x20], xmm3
000071e7f4dd8f2e  vmovaps [rsp+0x30], xmm4
000071e7f4dd8f34  vmovaps [rsp+0x40], xmm5
000071e7f4dd8f3a  vmovaps [rsp+0x50], xmm6
000071e7f4dd8f40  vmovaps [rsp+0x60], xmm7
000071e7f4dd8f46  vmovaps [rsp+0x70], xmm8
000071e7f4dd8f4c  vmovaps [rsp+0x80], xmm9
000071e7f4dd8f55  vmovaps [rsp+0x90], xmm10
000071e7f4dd8f5e  vmovaps [rsp+0xA0], xmm11
000071e7f4dd8f67  vmovaps [rsp+0xB0], xmm12
000071e7f4dd8f70  vmovaps [rsp+0xC0], xmm13
000071e7f4dd8f79  vmovaps [rsp+0xD0], xmm14
000071e7f4dd8f82  vmovaps [rsp+0xE0], xmm15
000071e7f4dd8f8b  sub rsp, 0x30
000071e7f4dd8f8f  movaps [rsp], xmm1
000071e7f4dd8f93  movaps [rsp+0x10], xmm15
000071e7f4dd8f99  movaps [rsp+0x20], xmm6
000071e7f4dd8f9e  lea rdi, [rsp]
000071e7f4dd8fa2  mov esi, 0x00
000071e7f4dd8fa7  mov rax, 0x562A51E82530
000071e7f4dd8fb1  call rax
000071e7f4dd8fb3  movaps xmm1, [rsp]
000071e7f4dd8fb7  add rsp, 0x30
000071e7f4dd8fbb  vmovaps xmm0, [rsp]
000071e7f4dd8fc0  vmovaps xmm2, [rsp+0x10]
000071e7f4dd8fc6  vmovaps xmm3, [rsp+0x20]
000071e7f4dd8fcc  vmovaps xmm4, [rsp+0x30]
000071e7f4dd8fd2  vmovaps xmm5, [rsp+0x40]
000071e7f4dd8fd8  vmovaps xmm6, [rsp+0x50]
000071e7f4dd8fde  vmovaps xmm7, [rsp+0x60]
000071e7f4dd8fe4  vmovaps xmm8, [rsp+0x70]
000071e7f4dd8fea  vmovaps xmm9, [rsp+0x80]
000071e7f4dd8ff3  vmovaps xmm10, [rsp+0x90]
000071e7f4dd8ffc  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd9005  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd900e  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd9017  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd9020  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd9029  add rsp, 0xF0
000071e7f4dd9030  pop r11
000071e7f4dd9032  pop r10
000071e7f4dd9034  pop r9
000071e7f4dd9036  pop r8
000071e7f4dd9038  pop rsi
000071e7f4dd9039  pop rdi
000071e7f4dd903a  pop rdx
000071e7f4dd903b  pop rcx
000071e7f4dd903c  pop rax
000071e7f4dd903d  add rsp, 0x08
000071e7f4dd9041  jmp 0x000071E7F4DD61C2
000071e7f4dd9046  sub rsp, 0x08
000071e7f4dd904a  push rax
000071e7f4dd904b  push rcx
000071e7f4dd904c  push rdx
000071e7f4dd904d  push rdi
000071e7f4dd904e  push rsi
000071e7f4dd904f  push r8
000071e7f4dd9051  push r9
000071e7f4dd9053  push r10
000071e7f4dd9055  push r11
000071e7f4dd9057  sub rsp, 0xF0
000071e7f4dd905e  vmovaps [rsp], xmm0
000071e7f4dd9063  vmovaps [rsp+0x10], xmm1
000071e7f4dd9069  vmovaps [rsp+0x20], xmm2
000071e7f4dd906f  vmovaps [rsp+0x30], xmm3
000071e7f4dd9075  vmovaps [rsp+0x40], xmm4
000071e7f4dd907b  vmovaps [rsp+0x50], xmm5
000071e7f4dd9081  vmovaps [rsp+0x60], xmm6
000071e7f4dd9087  vmovaps [rsp+0x70], xmm7
000071e7f4dd908d  vmovaps [rsp+0x80], xmm8
000071e7f4dd9096  vmovaps [rsp+0x90], xmm9
000071e7f4dd909f  vmovaps [rsp+0xA0], xmm10
000071e7f4dd90a8  vmovaps [rsp+0xB0], xmm11
000071e7f4dd90b1  vmovaps [rsp+0xC0], xmm12
000071e7f4dd90ba  vmovaps [rsp+0xD0], xmm13
000071e7f4dd90c3  vmovaps [rsp+0xE0], xmm14
000071e7f4dd90cc  sub rsp, 0x30
000071e7f4dd90d0  movaps [rsp], xmm15
000071e7f4dd90d5  movaps [rsp+0x10], xmm5
000071e7f4dd90da  movaps [rsp+0x20], xmm3
000071e7f4dd90df  lea rdi, [rsp]
000071e7f4dd90e3  mov esi, 0x00
000071e7f4dd90e8  mov rax, 0x562A51E82530
000071e7f4dd90f2  call rax
000071e7f4dd90f4  movaps xmm15, [rsp]
000071e7f4dd90f9  add rsp, 0x30
000071e7f4dd90fd  vmovaps xmm0, [rsp]
000071e7f4dd9102  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9108  vmovaps xmm2, [rsp+0x20]
000071e7f4dd910e  vmovaps xmm3, [rsp+0x30]
000071e7f4dd9114  vmovaps xmm4, [rsp+0x40]
000071e7f4dd911a  vmovaps xmm5, [rsp+0x50]
000071e7f4dd9120  vmovaps xmm6, [rsp+0x60]
000071e7f4dd9126  vmovaps xmm7, [rsp+0x70]
000071e7f4dd912c  vmovaps xmm8, [rsp+0x80]
000071e7f4dd9135  vmovaps xmm9, [rsp+0x90]
000071e7f4dd913e  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd9147  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd9150  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd9159  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd9162  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd916b  add rsp, 0xF0
000071e7f4dd9172  pop r11
000071e7f4dd9174  pop r10
000071e7f4dd9176  pop r9
000071e7f4dd9178  pop r8
000071e7f4dd917a  pop rsi
000071e7f4dd917b  pop rdi
000071e7f4dd917c  pop rdx
000071e7f4dd917d  pop rcx
000071e7f4dd917e  pop rax
000071e7f4dd917f  add rsp, 0x08
000071e7f4dd9183  jmp 0x000071E7F4DD61DC
000071e7f4dd9188  sub rsp, 0x08
000071e7f4dd918c  push rax
000071e7f4dd918d  push rcx
000071e7f4dd918e  push rdx
000071e7f4dd918f  push rdi
000071e7f4dd9190  push rsi
000071e7f4dd9191  push r8
000071e7f4dd9193  push r9
000071e7f4dd9195  push r10
000071e7f4dd9197  push r11
000071e7f4dd9199  sub rsp, 0xF0
000071e7f4dd91a0  vmovaps [rsp], xmm0
000071e7f4dd91a5  vmovaps [rsp+0x10], xmm1
000071e7f4dd91ab  vmovaps [rsp+0x20], xmm2
000071e7f4dd91b1  vmovaps [rsp+0x30], xmm3
000071e7f4dd91b7  vmovaps [rsp+0x40], xmm4
000071e7f4dd91bd  vmovaps [rsp+0x50], xmm6
000071e7f4dd91c3  vmovaps [rsp+0x60], xmm7
000071e7f4dd91c9  vmovaps [rsp+0x70], xmm8
000071e7f4dd91cf  vmovaps [rsp+0x80], xmm9
000071e7f4dd91d8  vmovaps [rsp+0x90], xmm10
000071e7f4dd91e1  vmovaps [rsp+0xA0], xmm11
000071e7f4dd91ea  vmovaps [rsp+0xB0], xmm12
000071e7f4dd91f3  vmovaps [rsp+0xC0], xmm13
000071e7f4dd91fc  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9205  vmovaps [rsp+0xE0], xmm15
000071e7f4dd920e  sub rsp, 0x30
000071e7f4dd9212  movaps [rsp], xmm5
000071e7f4dd9216  movaps [rsp+0x10], xmm8
000071e7f4dd921c  movaps [rsp+0x20], xmm6
000071e7f4dd9221  lea rdi, [rsp]
000071e7f4dd9225  mov esi, 0x00
000071e7f4dd922a  mov rax, 0x562A51E82530
000071e7f4dd9234  call rax
000071e7f4dd9236  movaps xmm5, [rsp]
000071e7f4dd923a  add rsp, 0x30
000071e7f4dd923e  vmovaps xmm0, [rsp]
000071e7f4dd9243  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9249  vmovaps xmm2, [rsp+0x20]
000071e7f4dd924f  vmovaps xmm3, [rsp+0x30]
000071e7f4dd9255  vmovaps xmm4, [rsp+0x40]
000071e7f4dd925b  vmovaps xmm6, [rsp+0x50]
000071e7f4dd9261  vmovaps xmm7, [rsp+0x60]
000071e7f4dd9267  vmovaps xmm8, [rsp+0x70]
000071e7f4dd926d  vmovaps xmm9, [rsp+0x80]
000071e7f4dd9276  vmovaps xmm10, [rsp+0x90]
000071e7f4dd927f  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd9288  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd9291  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd929a  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd92a3  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd92ac  add rsp, 0xF0
000071e7f4dd92b3  pop r11
000071e7f4dd92b5  pop r10
000071e7f4dd92b7  pop r9
000071e7f4dd92b9  pop r8
000071e7f4dd92bb  pop rsi
000071e7f4dd92bc  pop rdi
000071e7f4dd92bd  pop rdx
000071e7f4dd92be  pop rcx
000071e7f4dd92bf  pop rax
000071e7f4dd92c0  add rsp, 0x08
000071e7f4dd92c4  jmp 0x000071E7F4DD6200
000071e7f4dd92c9  sub rsp, 0x08
000071e7f4dd92cd  push rax
000071e7f4dd92ce  push rcx
000071e7f4dd92cf  push rdx
000071e7f4dd92d0  push rdi
000071e7f4dd92d1  push rsi
000071e7f4dd92d2  push r8
000071e7f4dd92d4  push r9
000071e7f4dd92d6  push r10
000071e7f4dd92d8  push r11
000071e7f4dd92da  sub rsp, 0xF0
000071e7f4dd92e1  vmovaps [rsp], xmm0
000071e7f4dd92e6  vmovaps [rsp+0x10], xmm1
000071e7f4dd92ec  vmovaps [rsp+0x20], xmm2
000071e7f4dd92f2  vmovaps [rsp+0x30], xmm3
000071e7f4dd92f8  vmovaps [rsp+0x40], xmm4
000071e7f4dd92fe  vmovaps [rsp+0x50], xmm5
000071e7f4dd9304  vmovaps [rsp+0x60], xmm7
000071e7f4dd930a  vmovaps [rsp+0x70], xmm8
000071e7f4dd9310  vmovaps [rsp+0x80], xmm9
000071e7f4dd9319  vmovaps [rsp+0x90], xmm10
000071e7f4dd9322  vmovaps [rsp+0xA0], xmm11
000071e7f4dd932b  vmovaps [rsp+0xB0], xmm12
000071e7f4dd9334  vmovaps [rsp+0xC0], xmm13
000071e7f4dd933d  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9346  vmovaps [rsp+0xE0], xmm15
000071e7f4dd934f  sub rsp, 0x30
000071e7f4dd9353  movaps [rsp], xmm6
000071e7f4dd9357  movaps [rsp+0x10], xmm10
000071e7f4dd935d  movaps [rsp+0x20], xmm8
000071e7f4dd9363  lea rdi, [rsp]
000071e7f4dd9367  mov esi, 0x00
000071e7f4dd936c  mov rax, 0x562A51E82530
000071e7f4dd9376  call rax
000071e7f4dd9378  movaps xmm6, [rsp]
000071e7f4dd937c  add rsp, 0x30
000071e7f4dd9380  vmovaps xmm0, [rsp]
000071e7f4dd9385  vmovaps xmm1, [rsp+0x10]
000071e7f4dd938b  vmovaps xmm2, [rsp+0x20]
000071e7f4dd9391  vmovaps xmm3, [rsp+0x30]
000071e7f4dd9397  vmovaps xmm4, [rsp+0x40]
000071e7f4dd939d  vmovaps xmm5, [rsp+0x50]
000071e7f4dd93a3  vmovaps xmm7, [rsp+0x60]
000071e7f4dd93a9  vmovaps xmm8, [rsp+0x70]
000071e7f4dd93af  vmovaps xmm9, [rsp+0x80]
000071e7f4dd93b8  vmovaps xmm10, [rsp+0x90]
000071e7f4dd93c1  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd93ca  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd93d3  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd93dc  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd93e5  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd93ee  add rsp, 0xF0
000071e7f4dd93f5  pop r11
000071e7f4dd93f7  pop r10
000071e7f4dd93f9  pop r9
000071e7f4dd93fb  pop r8
000071e7f4dd93fd  pop rsi
000071e7f4dd93fe  pop rdi
000071e7f4dd93ff  pop rdx
000071e7f4dd9400  pop rcx
000071e7f4dd9401  pop rax
000071e7f4dd9402  add rsp, 0x08
000071e7f4dd9406  jmp 0x000071E7F4DD6225
000071e7f4dd940b  sub rsp, 0x08
000071e7f4dd940f  push rax
000071e7f4dd9410  push rcx
000071e7f4dd9411  push rdx
000071e7f4dd9412  push rdi
000071e7f4dd9413  push rsi
000071e7f4dd9414  push r8
000071e7f4dd9416  push r9
000071e7f4dd9418  push r10
000071e7f4dd941a  push r11
000071e7f4dd941c  sub rsp, 0xF0
000071e7f4dd9423  vmovaps [rsp], xmm0
000071e7f4dd9428  vmovaps [rsp+0x10], xmm1
000071e7f4dd942e  vmovaps [rsp+0x20], xmm2
000071e7f4dd9434  vmovaps [rsp+0x30], xmm3
000071e7f4dd943a  vmovaps [rsp+0x40], xmm4
000071e7f4dd9440  vmovaps [rsp+0x50], xmm5
000071e7f4dd9446  vmovaps [rsp+0x60], xmm6
000071e7f4dd944c  vmovaps [rsp+0x70], xmm7
000071e7f4dd9452  vmovaps [rsp+0x80], xmm8
000071e7f4dd945b  vmovaps [rsp+0x90], xmm9
000071e7f4dd9464  vmovaps [rsp+0xA0], xmm11
000071e7f4dd946d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd9476  vmovaps [rsp+0xC0], xmm13
000071e7f4dd947f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9488  vmovaps [rsp+0xE0], xmm15
000071e7f4dd9491  sub rsp, 0x30
000071e7f4dd9495  movaps [rsp], xmm10
000071e7f4dd949a  movaps [rsp+0x10], xmm8
000071e7f4dd94a0  movaps [rsp+0x20], xmm14
000071e7f4dd94a6  lea rdi, [rsp]
000071e7f4dd94aa  mov esi, 0x00
000071e7f4dd94af  mov rax, 0x562A51E82530
000071e7f4dd94b9  call rax
000071e7f4dd94bb  movaps xmm10, [rsp]
000071e7f4dd94c0  add rsp, 0x30
000071e7f4dd94c4  vmovaps xmm0, [rsp]
000071e7f4dd94c9  vmovaps xmm1, [rsp+0x10]
000071e7f4dd94cf  vmovaps xmm2, [rsp+0x20]
000071e7f4dd94d5  vmovaps xmm3, [rsp+0x30]
000071e7f4dd94db  vmovaps xmm4, [rsp+0x40]
000071e7f4dd94e1  vmovaps xmm5, [rsp+0x50]
000071e7f4dd94e7  vmovaps xmm6, [rsp+0x60]
000071e7f4dd94ed  vmovaps xmm7, [rsp+0x70]
000071e7f4dd94f3  vmovaps xmm8, [rsp+0x80]
000071e7f4dd94fc  vmovaps xmm9, [rsp+0x90]
000071e7f4dd9505  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd950e  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd9517  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd9520  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd9529  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd9532  add rsp, 0xF0
000071e7f4dd9539  pop r11
000071e7f4dd953b  pop r10
000071e7f4dd953d  pop r9
000071e7f4dd953f  pop r8
000071e7f4dd9541  pop rsi
000071e7f4dd9542  pop rdi
000071e7f4dd9543  pop rdx
000071e7f4dd9544  pop rcx
000071e7f4dd9545  pop rax
000071e7f4dd9546  add rsp, 0x08
000071e7f4dd954a  jmp 0x000071E7F4DD6245
000071e7f4dd954f  sub rsp, 0x08
000071e7f4dd9553  push rax
000071e7f4dd9554  push rcx
000071e7f4dd9555  push rdx
000071e7f4dd9556  push rdi
000071e7f4dd9557  push rsi
000071e7f4dd9558  push r8
000071e7f4dd955a  push r9
000071e7f4dd955c  push r10
000071e7f4dd955e  push r11
000071e7f4dd9560  sub rsp, 0xF0
000071e7f4dd9567  vmovaps [rsp], xmm0
000071e7f4dd956c  vmovaps [rsp+0x10], xmm1
000071e7f4dd9572  vmovaps [rsp+0x20], xmm2
000071e7f4dd9578  vmovaps [rsp+0x30], xmm3
000071e7f4dd957e  vmovaps [rsp+0x40], xmm4
000071e7f4dd9584  vmovaps [rsp+0x50], xmm5
000071e7f4dd958a  vmovaps [rsp+0x60], xmm6
000071e7f4dd9590  vmovaps [rsp+0x70], xmm7
000071e7f4dd9596  vmovaps [rsp+0x80], xmm8
000071e7f4dd959f  vmovaps [rsp+0x90], xmm9
000071e7f4dd95a8  vmovaps [rsp+0xA0], xmm10
000071e7f4dd95b1  vmovaps [rsp+0xB0], xmm11
000071e7f4dd95ba  vmovaps [rsp+0xC0], xmm12
000071e7f4dd95c3  vmovaps [rsp+0xD0], xmm13
000071e7f4dd95cc  vmovaps [rsp+0xE0], xmm15
000071e7f4dd95d5  sub rsp, 0x30
000071e7f4dd95d9  movaps [rsp], xmm14
000071e7f4dd95de  movaps [rsp+0x10], xmm8
000071e7f4dd95e4  movaps [rsp+0x20], xmm4
000071e7f4dd95e9  lea rdi, [rsp]
000071e7f4dd95ed  mov esi, 0x00
000071e7f4dd95f2  mov rax, 0x562A51E82530
000071e7f4dd95fc  call rax
000071e7f4dd95fe  movaps xmm14, [rsp]
000071e7f4dd9603  add rsp, 0x30
000071e7f4dd9607  vmovaps xmm0, [rsp]
000071e7f4dd960c  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9612  vmovaps xmm2, [rsp+0x20]
000071e7f4dd9618  vmovaps xmm3, [rsp+0x30]
000071e7f4dd961e  vmovaps xmm4, [rsp+0x40]
000071e7f4dd9624  vmovaps xmm5, [rsp+0x50]
000071e7f4dd962a  vmovaps xmm6, [rsp+0x60]
000071e7f4dd9630  vmovaps xmm7, [rsp+0x70]
000071e7f4dd9636  vmovaps xmm8, [rsp+0x80]
000071e7f4dd963f  vmovaps xmm9, [rsp+0x90]
000071e7f4dd9648  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd9651  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd965a  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd9663  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd966c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd9675  add rsp, 0xF0
000071e7f4dd967c  pop r11
000071e7f4dd967e  pop r10
000071e7f4dd9680  pop r9
000071e7f4dd9682  pop r8
000071e7f4dd9684  pop rsi
000071e7f4dd9685  pop rdi
000071e7f4dd9686  pop rdx
000071e7f4dd9687  pop rcx
000071e7f4dd9688  pop rax
000071e7f4dd9689  add rsp, 0x08
000071e7f4dd968d  jmp 0x000071E7F4DD6265
000071e7f4dd9692  sub rsp, 0x08
000071e7f4dd9696  push rax
000071e7f4dd9697  push rcx
000071e7f4dd9698  push rdx
000071e7f4dd9699  push rdi
000071e7f4dd969a  push rsi
000071e7f4dd969b  push r8
000071e7f4dd969d  push r9
000071e7f4dd969f  push r10
000071e7f4dd96a1  push r11
000071e7f4dd96a3  sub rsp, 0xF0
000071e7f4dd96aa  vmovaps [rsp], xmm0
000071e7f4dd96af  vmovaps [rsp+0x10], xmm1
000071e7f4dd96b5  vmovaps [rsp+0x20], xmm2
000071e7f4dd96bb  vmovaps [rsp+0x30], xmm3
000071e7f4dd96c1  vmovaps [rsp+0x40], xmm5
000071e7f4dd96c7  vmovaps [rsp+0x50], xmm6
000071e7f4dd96cd  vmovaps [rsp+0x60], xmm7
000071e7f4dd96d3  vmovaps [rsp+0x70], xmm8
000071e7f4dd96d9  vmovaps [rsp+0x80], xmm9
000071e7f4dd96e2  vmovaps [rsp+0x90], xmm10
000071e7f4dd96eb  vmovaps [rsp+0xA0], xmm11
000071e7f4dd96f4  vmovaps [rsp+0xB0], xmm12
000071e7f4dd96fd  vmovaps [rsp+0xC0], xmm13
000071e7f4dd9706  vmovaps [rsp+0xD0], xmm14
000071e7f4dd970f  vmovaps [rsp+0xE0], xmm15
000071e7f4dd9718  sub rsp, 0x30
000071e7f4dd971c  movaps [rsp], xmm4
000071e7f4dd9720  movaps [rsp+0x10], xmm13
000071e7f4dd9726  movaps [rsp+0x20], xmm8
000071e7f4dd972c  lea rdi, [rsp]
000071e7f4dd9730  mov esi, 0x00
000071e7f4dd9735  mov rax, 0x562A51E82530
000071e7f4dd973f  call rax
000071e7f4dd9741  movaps xmm4, [rsp]
000071e7f4dd9745  add rsp, 0x30
000071e7f4dd9749  vmovaps xmm0, [rsp]
000071e7f4dd974e  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9754  vmovaps xmm2, [rsp+0x20]
000071e7f4dd975a  vmovaps xmm3, [rsp+0x30]
000071e7f4dd9760  vmovaps xmm5, [rsp+0x40]
000071e7f4dd9766  vmovaps xmm6, [rsp+0x50]
000071e7f4dd976c  vmovaps xmm7, [rsp+0x60]
000071e7f4dd9772  vmovaps xmm8, [rsp+0x70]
000071e7f4dd9778  vmovaps xmm9, [rsp+0x80]
000071e7f4dd9781  vmovaps xmm10, [rsp+0x90]
000071e7f4dd978a  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd9793  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd979c  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd97a5  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd97ae  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd97b7  add rsp, 0xF0
000071e7f4dd97be  pop r11
000071e7f4dd97c0  pop r10
000071e7f4dd97c2  pop r9
000071e7f4dd97c4  pop r8
000071e7f4dd97c6  pop rsi
000071e7f4dd97c7  pop rdi
000071e7f4dd97c8  pop rdx
000071e7f4dd97c9  pop rcx
000071e7f4dd97ca  pop rax
000071e7f4dd97cb  add rsp, 0x08
000071e7f4dd97cf  jmp 0x000071E7F4DD628A
000071e7f4dd97d4  sub rsp, 0x08
000071e7f4dd97d8  push rax
000071e7f4dd97d9  push rcx
000071e7f4dd97da  push rdx
000071e7f4dd97db  push rdi
000071e7f4dd97dc  push rsi
000071e7f4dd97dd  push r8
000071e7f4dd97df  push r9
000071e7f4dd97e1  push r10
000071e7f4dd97e3  push r11
000071e7f4dd97e5  sub rsp, 0xF0
000071e7f4dd97ec  vmovaps [rsp], xmm0
000071e7f4dd97f1  vmovaps [rsp+0x10], xmm1
000071e7f4dd97f7  vmovaps [rsp+0x20], xmm2
000071e7f4dd97fd  vmovaps [rsp+0x30], xmm3
000071e7f4dd9803  vmovaps [rsp+0x40], xmm4
000071e7f4dd9809  vmovaps [rsp+0x50], xmm5
000071e7f4dd980f  vmovaps [rsp+0x60], xmm6
000071e7f4dd9815  vmovaps [rsp+0x70], xmm7
000071e7f4dd981b  vmovaps [rsp+0x80], xmm8
000071e7f4dd9824  vmovaps [rsp+0x90], xmm9
000071e7f4dd982d  vmovaps [rsp+0xA0], xmm10
000071e7f4dd9836  vmovaps [rsp+0xB0], xmm11
000071e7f4dd983f  vmovaps [rsp+0xC0], xmm12
000071e7f4dd9848  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9851  vmovaps [rsp+0xE0], xmm15
000071e7f4dd985a  sub rsp, 0x30
000071e7f4dd985e  movaps [rsp], xmm13
000071e7f4dd9863  movaps [rsp+0x10], xmm15
000071e7f4dd9869  movaps [rsp+0x20], xmm9
000071e7f4dd986f  lea rdi, [rsp]
000071e7f4dd9873  mov esi, 0x00
000071e7f4dd9878  mov rax, 0x562A51E82530
000071e7f4dd9882  call rax
000071e7f4dd9884  movaps xmm13, [rsp]
000071e7f4dd9889  add rsp, 0x30
000071e7f4dd988d  vmovaps xmm0, [rsp]
000071e7f4dd9892  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9898  vmovaps xmm2, [rsp+0x20]
000071e7f4dd989e  vmovaps xmm3, [rsp+0x30]
000071e7f4dd98a4  vmovaps xmm4, [rsp+0x40]
000071e7f4dd98aa  vmovaps xmm5, [rsp+0x50]
000071e7f4dd98b0  vmovaps xmm6, [rsp+0x60]
000071e7f4dd98b6  vmovaps xmm7, [rsp+0x70]
000071e7f4dd98bc  vmovaps xmm8, [rsp+0x80]
000071e7f4dd98c5  vmovaps xmm9, [rsp+0x90]
000071e7f4dd98ce  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd98d7  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd98e0  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd98e9  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd98f2  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd98fb  add rsp, 0xF0
000071e7f4dd9902  pop r11
000071e7f4dd9904  pop r10
000071e7f4dd9906  pop r9
000071e7f4dd9908  pop r8
000071e7f4dd990a  pop rsi
000071e7f4dd990b  pop rdi
000071e7f4dd990c  pop rdx
000071e7f4dd990d  pop rcx
000071e7f4dd990e  pop rax
000071e7f4dd990f  add rsp, 0x08
000071e7f4dd9913  jmp 0x000071E7F4DD62A5
000071e7f4dd9918  sub rsp, 0x08
000071e7f4dd991c  push rax
000071e7f4dd991d  push rcx
000071e7f4dd991e  push rdx
000071e7f4dd991f  push rdi
000071e7f4dd9920  push rsi
000071e7f4dd9921  push r8
000071e7f4dd9923  push r9
000071e7f4dd9925  push r10
000071e7f4dd9927  push r11
000071e7f4dd9929  sub rsp, 0xF0
000071e7f4dd9930  vmovaps [rsp], xmm0
000071e7f4dd9935  vmovaps [rsp+0x10], xmm1
000071e7f4dd993b  vmovaps [rsp+0x20], xmm2
000071e7f4dd9941  vmovaps [rsp+0x30], xmm3
000071e7f4dd9947  vmovaps [rsp+0x40], xmm4
000071e7f4dd994d  vmovaps [rsp+0x50], xmm5
000071e7f4dd9953  vmovaps [rsp+0x60], xmm6
000071e7f4dd9959  vmovaps [rsp+0x70], xmm7
000071e7f4dd995f  vmovaps [rsp+0x80], xmm8
000071e7f4dd9968  vmovaps [rsp+0x90], xmm9
000071e7f4dd9971  vmovaps [rsp+0xA0], xmm10
000071e7f4dd997a  vmovaps [rsp+0xB0], xmm11
000071e7f4dd9983  vmovaps [rsp+0xC0], xmm12
000071e7f4dd998c  vmovaps [rsp+0xD0], xmm13
000071e7f4dd9995  vmovaps [rsp+0xE0], xmm14
000071e7f4dd999e  sub rsp, 0x30
000071e7f4dd99a2  movaps [rsp], xmm15
000071e7f4dd99a7  movaps [rsp+0x10], xmm1
000071e7f4dd99ac  movaps [rsp+0x20], xmm5
000071e7f4dd99b1  lea rdi, [rsp]
000071e7f4dd99b5  mov esi, 0x00
000071e7f4dd99ba  mov rax, 0x562A51E82530
000071e7f4dd99c4  call rax
000071e7f4dd99c6  movaps xmm15, [rsp]
000071e7f4dd99cb  add rsp, 0x30
000071e7f4dd99cf  vmovaps xmm0, [rsp]
000071e7f4dd99d4  vmovaps xmm1, [rsp+0x10]
000071e7f4dd99da  vmovaps xmm2, [rsp+0x20]
000071e7f4dd99e0  vmovaps xmm3, [rsp+0x30]
000071e7f4dd99e6  vmovaps xmm4, [rsp+0x40]
000071e7f4dd99ec  vmovaps xmm5, [rsp+0x50]
000071e7f4dd99f2  vmovaps xmm6, [rsp+0x60]
000071e7f4dd99f8  vmovaps xmm7, [rsp+0x70]
000071e7f4dd99fe  vmovaps xmm8, [rsp+0x80]
000071e7f4dd9a07  vmovaps xmm9, [rsp+0x90]
000071e7f4dd9a10  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd9a19  vmovaps xmm11, [rsp+0xB0]
000071e7f4dd9a22  vmovaps xmm12, [rsp+0xC0]
000071e7f4dd9a2b  vmovaps xmm13, [rsp+0xD0]
000071e7f4dd9a34  vmovaps xmm14, [rsp+0xE0]
000071e7f4dd9a3d  add rsp, 0xF0
000071e7f4dd9a44  pop r11
000071e7f4dd9a46  pop r10
000071e7f4dd9a48  pop r9
000071e7f4dd9a4a  pop r8
000071e7f4dd9a4c  pop rsi
000071e7f4dd9a4d  pop rdi
000071e7f4dd9a4e  pop rdx
000071e7f4dd9a4f  pop rcx
000071e7f4dd9a50  pop rax
000071e7f4dd9a51  add rsp, 0x08
000071e7f4dd9a55  jmp 0x000071E7F4DD62C0
000071e7f4dd9a5a  call 0x000071E7F4CD64F0
000071e7f4dd9a5f  jmp 0x000071E7F4DD631B
000071e7f4dd9a64  sub rsp, 0x08
000071e7f4dd9a68  push rax
000071e7f4dd9a69  push rcx
000071e7f4dd9a6a  push rdx
000071e7f4dd9a6b  push rdi
000071e7f4dd9a6c  push rsi
000071e7f4dd9a6d  push r8
000071e7f4dd9a6f  push r9
000071e7f4dd9a71  push r10
000071e7f4dd9a73  push r11
000071e7f4dd9a75  sub rsp, 0xF0
000071e7f4dd9a7c  vmovaps [rsp], xmm0
000071e7f4dd9a81  vmovaps [rsp+0x10], xmm1
000071e7f4dd9a87  vmovaps [rsp+0x20], xmm2
000071e7f4dd9a8d  vmovaps [rsp+0x30], xmm3
000071e7f4dd9a93  vmovaps [rsp+0x40], xmm4
000071e7f4dd9a99  vmovaps [rsp+0x50], xmm5
000071e7f4dd9a9f  vmovaps [rsp+0x60], xmm6
000071e7f4dd9aa5  vmovaps [rsp+0x70], xmm7
000071e7f4dd9aab  vmovaps [rsp+0x80], xmm8
000071e7f4dd9ab4  vmovaps [rsp+0x90], xmm10
000071e7f4dd9abd  vmovaps [rsp+0xA0], xmm11
000071e7f4dd9ac6  vmovaps [rsp+0xB0], xmm12
000071e7f4dd9acf  vmovaps [rsp+0xC0], xmm13
000071e7f4dd9ad8  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9ae1  vmovaps [rsp+0xE0], xmm15
000071e7f4dd9aea  sub rsp, 0x30
000071e7f4dd9aee  movaps [rsp], xmm9
000071e7f4dd9af3  movaps [rsp+0x10], xmm8
000071e7f4dd9af9  movaps [rsp+0x20], xmm11
000071e7f4dd9aff  lea rdi, [rsp]
000071e7f4dd9b03  mov esi, 0x00
000071e7f4dd9b08  mov rax, 0x562A51E82530
000071e7f4dd9b12  call rax
000071e7f4dd9b14  movaps xmm9, [rsp]
000071e7f4dd9b19  add rsp, 0x30
000071e7f4dd9b1d  vmovaps xmm0, [rsp]
000071e7f4dd9b22  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9b28  vmovaps xmm2, [rsp+0x20]
000071e7f4dd9b2e  vmovaps xmm3, [rsp+0x30]
000071e7f4dd9b34  vmovaps xmm4, [rsp+0x40]
000071e7f4dd9b3a  vmovaps xmm5, [rsp+0x50]
000071e7f4dd9b40  vmovaps xmm6, [rsp+0x60]
000071e7f4dd9b46  vmovaps xmm7, [rsp+0x70]
000071e7f4dd9b4c  vmovaps xmm8, [rsp+0x80]
000071e7f4dd9b55  vmovaps xmm10, [rsp+0x90]
000071e7f4dd9b5e  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd9b67  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd9b70  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd9b79  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd9b82  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd9b8b  add rsp, 0xF0
000071e7f4dd9b92  pop r11
000071e7f4dd9b94  pop r10
000071e7f4dd9b96  pop r9
000071e7f4dd9b98  pop r8
000071e7f4dd9b9a  pop rsi
000071e7f4dd9b9b  pop rdi
000071e7f4dd9b9c  pop rdx
000071e7f4dd9b9d  pop rcx
000071e7f4dd9b9e  pop rax
000071e7f4dd9b9f  add rsp, 0x08
000071e7f4dd9ba3  jmp 0x000071E7F4DD6352
000071e7f4dd9ba8  sub rsp, 0x08
000071e7f4dd9bac  push rax
000071e7f4dd9bad  push rcx
000071e7f4dd9bae  push rdx
000071e7f4dd9baf  push rdi
000071e7f4dd9bb0  push rsi
000071e7f4dd9bb1  push r8
000071e7f4dd9bb3  push r9
000071e7f4dd9bb5  push r10
000071e7f4dd9bb7  push r11
000071e7f4dd9bb9  sub rsp, 0xF0
000071e7f4dd9bc0  vmovaps [rsp], xmm0
000071e7f4dd9bc5  vmovaps [rsp+0x10], xmm1
000071e7f4dd9bcb  vmovaps [rsp+0x20], xmm2
000071e7f4dd9bd1  vmovaps [rsp+0x30], xmm3
000071e7f4dd9bd7  vmovaps [rsp+0x40], xmm4
000071e7f4dd9bdd  vmovaps [rsp+0x50], xmm5
000071e7f4dd9be3  vmovaps [rsp+0x60], xmm6
000071e7f4dd9be9  vmovaps [rsp+0x70], xmm7
000071e7f4dd9bef  vmovaps [rsp+0x80], xmm8
000071e7f4dd9bf8  vmovaps [rsp+0x90], xmm9
000071e7f4dd9c01  vmovaps [rsp+0xA0], xmm10
000071e7f4dd9c0a  vmovaps [rsp+0xB0], xmm12
000071e7f4dd9c13  vmovaps [rsp+0xC0], xmm13
000071e7f4dd9c1c  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9c25  vmovaps [rsp+0xE0], xmm15
000071e7f4dd9c2e  sub rsp, 0x30
000071e7f4dd9c32  movaps [rsp], xmm11
000071e7f4dd9c37  movaps [rsp+0x10], xmm10
000071e7f4dd9c3d  movaps [rsp+0x20], xmm6
000071e7f4dd9c42  lea rdi, [rsp]
000071e7f4dd9c46  mov esi, 0x00
000071e7f4dd9c4b  mov rax, 0x562A51E82530
000071e7f4dd9c55  call rax
000071e7f4dd9c57  movaps xmm11, [rsp]
000071e7f4dd9c5c  add rsp, 0x30
000071e7f4dd9c60  vmovaps xmm0, [rsp]
000071e7f4dd9c65  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9c6b  vmovaps xmm2, [rsp+0x20]
000071e7f4dd9c71  vmovaps xmm3, [rsp+0x30]
000071e7f4dd9c77  vmovaps xmm4, [rsp+0x40]
000071e7f4dd9c7d  vmovaps xmm5, [rsp+0x50]
000071e7f4dd9c83  vmovaps xmm6, [rsp+0x60]
000071e7f4dd9c89  vmovaps xmm7, [rsp+0x70]
000071e7f4dd9c8f  vmovaps xmm8, [rsp+0x80]
000071e7f4dd9c98  vmovaps xmm9, [rsp+0x90]
000071e7f4dd9ca1  vmovaps xmm10, [rsp+0xA0]
000071e7f4dd9caa  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd9cb3  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd9cbc  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd9cc5  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd9cce  add rsp, 0xF0
000071e7f4dd9cd5  pop r11
000071e7f4dd9cd7  pop r10
000071e7f4dd9cd9  pop r9
000071e7f4dd9cdb  pop r8
000071e7f4dd9cdd  pop rsi
000071e7f4dd9cde  pop rdi
000071e7f4dd9cdf  pop rdx
000071e7f4dd9ce0  pop rcx
000071e7f4dd9ce1  pop rax
000071e7f4dd9ce2  add rsp, 0x08
000071e7f4dd9ce6  jmp 0x000071E7F4DD636D
000071e7f4dd9ceb  sub rsp, 0x08
000071e7f4dd9cef  push rax
000071e7f4dd9cf0  push rcx
000071e7f4dd9cf1  push rdx
000071e7f4dd9cf2  push rdi
000071e7f4dd9cf3  push rsi
000071e7f4dd9cf4  push r8
000071e7f4dd9cf6  push r9
000071e7f4dd9cf8  push r10
000071e7f4dd9cfa  push r11
000071e7f4dd9cfc  sub rsp, 0xF0
000071e7f4dd9d03  vmovaps [rsp], xmm0
000071e7f4dd9d08  vmovaps [rsp+0x10], xmm1
000071e7f4dd9d0e  vmovaps [rsp+0x20], xmm2
000071e7f4dd9d14  vmovaps [rsp+0x30], xmm3
000071e7f4dd9d1a  vmovaps [rsp+0x40], xmm4
000071e7f4dd9d20  vmovaps [rsp+0x50], xmm5
000071e7f4dd9d26  vmovaps [rsp+0x60], xmm6
000071e7f4dd9d2c  vmovaps [rsp+0x70], xmm7
000071e7f4dd9d32  vmovaps [rsp+0x80], xmm8
000071e7f4dd9d3b  vmovaps [rsp+0x90], xmm9
000071e7f4dd9d44  vmovaps [rsp+0xA0], xmm11
000071e7f4dd9d4d  vmovaps [rsp+0xB0], xmm12
000071e7f4dd9d56  vmovaps [rsp+0xC0], xmm13
000071e7f4dd9d5f  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9d68  vmovaps [rsp+0xE0], xmm15
000071e7f4dd9d71  sub rsp, 0x30
000071e7f4dd9d75  movaps [rsp], xmm10
000071e7f4dd9d7a  movaps [rsp+0x10], xmm14
000071e7f4dd9d80  movaps [rsp+0x20], xmm4
000071e7f4dd9d85  lea rdi, [rsp]
000071e7f4dd9d89  mov esi, 0x00
000071e7f4dd9d8e  mov rax, 0x562A51E82530
000071e7f4dd9d98  call rax
000071e7f4dd9d9a  movaps xmm10, [rsp]
000071e7f4dd9d9f  add rsp, 0x30
000071e7f4dd9da3  vmovaps xmm0, [rsp]
000071e7f4dd9da8  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9dae  vmovaps xmm2, [rsp+0x20]
000071e7f4dd9db4  vmovaps xmm3, [rsp+0x30]
000071e7f4dd9dba  vmovaps xmm4, [rsp+0x40]
000071e7f4dd9dc0  vmovaps xmm5, [rsp+0x50]
000071e7f4dd9dc6  vmovaps xmm6, [rsp+0x60]
000071e7f4dd9dcc  vmovaps xmm7, [rsp+0x70]
000071e7f4dd9dd2  vmovaps xmm8, [rsp+0x80]
000071e7f4dd9ddb  vmovaps xmm9, [rsp+0x90]
000071e7f4dd9de4  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd9ded  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd9df6  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd9dff  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd9e08  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd9e11  add rsp, 0xF0
000071e7f4dd9e18  pop r11
000071e7f4dd9e1a  pop r10
000071e7f4dd9e1c  pop r9
000071e7f4dd9e1e  pop r8
000071e7f4dd9e20  pop rsi
000071e7f4dd9e21  pop rdi
000071e7f4dd9e22  pop rdx
000071e7f4dd9e23  pop rcx
000071e7f4dd9e24  pop rax
000071e7f4dd9e25  add rsp, 0x08
000071e7f4dd9e29  jmp 0x000071E7F4DD6388
000071e7f4dd9e2e  sub rsp, 0x08
000071e7f4dd9e32  push rax
000071e7f4dd9e33  push rcx
000071e7f4dd9e34  push rdx
000071e7f4dd9e35  push rdi
000071e7f4dd9e36  push rsi
000071e7f4dd9e37  push r8
000071e7f4dd9e39  push r9
000071e7f4dd9e3b  push r10
000071e7f4dd9e3d  push r11
000071e7f4dd9e3f  sub rsp, 0xF0
000071e7f4dd9e46  vmovaps [rsp], xmm0
000071e7f4dd9e4b  vmovaps [rsp+0x10], xmm1
000071e7f4dd9e51  vmovaps [rsp+0x20], xmm2
000071e7f4dd9e57  vmovaps [rsp+0x30], xmm3
000071e7f4dd9e5d  vmovaps [rsp+0x40], xmm4
000071e7f4dd9e63  vmovaps [rsp+0x50], xmm5
000071e7f4dd9e69  vmovaps [rsp+0x60], xmm6
000071e7f4dd9e6f  vmovaps [rsp+0x70], xmm7
000071e7f4dd9e75  vmovaps [rsp+0x80], xmm9
000071e7f4dd9e7e  vmovaps [rsp+0x90], xmm10
000071e7f4dd9e87  vmovaps [rsp+0xA0], xmm11
000071e7f4dd9e90  vmovaps [rsp+0xB0], xmm12
000071e7f4dd9e99  vmovaps [rsp+0xC0], xmm13
000071e7f4dd9ea2  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9eab  vmovaps [rsp+0xE0], xmm15
000071e7f4dd9eb4  sub rsp, 0x30
000071e7f4dd9eb8  movaps [rsp], xmm8
000071e7f4dd9ebd  movaps [rsp+0x10], xmm1
000071e7f4dd9ec2  movaps [rsp+0x20], xmm14
000071e7f4dd9ec8  lea rdi, [rsp]
000071e7f4dd9ecc  mov esi, 0x00
000071e7f4dd9ed1  mov rax, 0x562A51E82530
000071e7f4dd9edb  call rax
000071e7f4dd9edd  movaps xmm8, [rsp]
000071e7f4dd9ee2  add rsp, 0x30
000071e7f4dd9ee6  vmovaps xmm0, [rsp]
000071e7f4dd9eeb  vmovaps xmm1, [rsp+0x10]
000071e7f4dd9ef1  vmovaps xmm2, [rsp+0x20]
000071e7f4dd9ef7  vmovaps xmm3, [rsp+0x30]
000071e7f4dd9efd  vmovaps xmm4, [rsp+0x40]
000071e7f4dd9f03  vmovaps xmm5, [rsp+0x50]
000071e7f4dd9f09  vmovaps xmm6, [rsp+0x60]
000071e7f4dd9f0f  vmovaps xmm7, [rsp+0x70]
000071e7f4dd9f15  vmovaps xmm9, [rsp+0x80]
000071e7f4dd9f1e  vmovaps xmm10, [rsp+0x90]
000071e7f4dd9f27  vmovaps xmm11, [rsp+0xA0]
000071e7f4dd9f30  vmovaps xmm12, [rsp+0xB0]
000071e7f4dd9f39  vmovaps xmm13, [rsp+0xC0]
000071e7f4dd9f42  vmovaps xmm14, [rsp+0xD0]
000071e7f4dd9f4b  vmovaps xmm15, [rsp+0xE0]
000071e7f4dd9f54  add rsp, 0xF0
000071e7f4dd9f5b  pop r11
000071e7f4dd9f5d  pop r10
000071e7f4dd9f5f  pop r9
000071e7f4dd9f61  pop r8
000071e7f4dd9f63  pop rsi
000071e7f4dd9f64  pop rdi
000071e7f4dd9f65  pop rdx
000071e7f4dd9f66  pop rcx
000071e7f4dd9f67  pop rax
000071e7f4dd9f68  add rsp, 0x08
000071e7f4dd9f6c  jmp 0x000071E7F4DD63AE
000071e7f4dd9f71  sub rsp, 0x08
000071e7f4dd9f75  push rax
000071e7f4dd9f76  push rcx
000071e7f4dd9f77  push rdx
000071e7f4dd9f78  push rdi
000071e7f4dd9f79  push rsi
000071e7f4dd9f7a  push r8
000071e7f4dd9f7c  push r9
000071e7f4dd9f7e  push r10
000071e7f4dd9f80  push r11
000071e7f4dd9f82  sub rsp, 0xF0
000071e7f4dd9f89  vmovaps [rsp], xmm0
000071e7f4dd9f8e  vmovaps [rsp+0x10], xmm1
000071e7f4dd9f94  vmovaps [rsp+0x20], xmm2
000071e7f4dd9f9a  vmovaps [rsp+0x30], xmm3
000071e7f4dd9fa0  vmovaps [rsp+0x40], xmm4
000071e7f4dd9fa6  vmovaps [rsp+0x50], xmm5
000071e7f4dd9fac  vmovaps [rsp+0x60], xmm7
000071e7f4dd9fb2  vmovaps [rsp+0x70], xmm8
000071e7f4dd9fb8  vmovaps [rsp+0x80], xmm9
000071e7f4dd9fc1  vmovaps [rsp+0x90], xmm10
000071e7f4dd9fca  vmovaps [rsp+0xA0], xmm11
000071e7f4dd9fd3  vmovaps [rsp+0xB0], xmm12
000071e7f4dd9fdc  vmovaps [rsp+0xC0], xmm13
000071e7f4dd9fe5  vmovaps [rsp+0xD0], xmm14
000071e7f4dd9fee  vmovaps [rsp+0xE0], xmm15
000071e7f4dd9ff7  sub rsp, 0x30
000071e7f4dd9ffb  movaps [rsp], xmm6
000071e7f4dd9fff  movaps [rsp+0x10], xmm1
000071e7f4dda004  movaps [rsp+0x20], xmm14
000071e7f4dda00a  lea rdi, [rsp]
000071e7f4dda00e  mov esi, 0x00
000071e7f4dda013  mov rax, 0x562A51E82530
000071e7f4dda01d  call rax
000071e7f4dda01f  movaps xmm6, [rsp]
000071e7f4dda023  add rsp, 0x30
000071e7f4dda027  vmovaps xmm0, [rsp]
000071e7f4dda02c  vmovaps xmm1, [rsp+0x10]
000071e7f4dda032  vmovaps xmm2, [rsp+0x20]
000071e7f4dda038  vmovaps xmm3, [rsp+0x30]
000071e7f4dda03e  vmovaps xmm4, [rsp+0x40]
000071e7f4dda044  vmovaps xmm5, [rsp+0x50]
000071e7f4dda04a  vmovaps xmm7, [rsp+0x60]
000071e7f4dda050  vmovaps xmm8, [rsp+0x70]
000071e7f4dda056  vmovaps xmm9, [rsp+0x80]
000071e7f4dda05f  vmovaps xmm10, [rsp+0x90]
000071e7f4dda068  vmovaps xmm11, [rsp+0xA0]
000071e7f4dda071  vmovaps xmm12, [rsp+0xB0]
000071e7f4dda07a  vmovaps xmm13, [rsp+0xC0]
000071e7f4dda083  vmovaps xmm14, [rsp+0xD0]
000071e7f4dda08c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dda095  add rsp, 0xF0
000071e7f4dda09c  pop r11
000071e7f4dda09e  pop r10
000071e7f4dda0a0  pop r9
000071e7f4dda0a2  pop r8
000071e7f4dda0a4  pop rsi
000071e7f4dda0a5  pop rdi
000071e7f4dda0a6  pop rdx
000071e7f4dda0a7  pop rcx
000071e7f4dda0a8  pop rax
000071e7f4dda0a9  add rsp, 0x08
000071e7f4dda0ad  jmp 0x000071E7F4DD63DA
000071e7f4dda0b2  sub rsp, 0x08
000071e7f4dda0b6  push rax
000071e7f4dda0b7  push rcx
000071e7f4dda0b8  push rdx
000071e7f4dda0b9  push rdi
000071e7f4dda0ba  push rsi
000071e7f4dda0bb  push r8
000071e7f4dda0bd  push r9
000071e7f4dda0bf  push r10
000071e7f4dda0c1  push r11
000071e7f4dda0c3  sub rsp, 0xF0
000071e7f4dda0ca  vmovaps [rsp], xmm0
000071e7f4dda0cf  vmovaps [rsp+0x10], xmm1
000071e7f4dda0d5  vmovaps [rsp+0x20], xmm2
000071e7f4dda0db  vmovaps [rsp+0x30], xmm3
000071e7f4dda0e1  vmovaps [rsp+0x40], xmm4
000071e7f4dda0e7  vmovaps [rsp+0x50], xmm5
000071e7f4dda0ed  vmovaps [rsp+0x60], xmm6
000071e7f4dda0f3  vmovaps [rsp+0x70], xmm7
000071e7f4dda0f9  vmovaps [rsp+0x80], xmm8
000071e7f4dda102  vmovaps [rsp+0x90], xmm9
000071e7f4dda10b  vmovaps [rsp+0xA0], xmm10
000071e7f4dda114  vmovaps [rsp+0xB0], xmm11
000071e7f4dda11d  vmovaps [rsp+0xC0], xmm12
000071e7f4dda126  vmovaps [rsp+0xD0], xmm13
000071e7f4dda12f  vmovaps [rsp+0xE0], xmm15
000071e7f4dda138  sub rsp, 0x30
000071e7f4dda13c  movaps [rsp], xmm14
000071e7f4dda141  movaps [rsp+0x10], xmm12
000071e7f4dda147  movaps [rsp+0x20], xmm1
000071e7f4dda14c  lea rdi, [rsp]
000071e7f4dda150  mov esi, 0x00
000071e7f4dda155  mov rax, 0x562A51E82530
000071e7f4dda15f  call rax
000071e7f4dda161  movaps xmm14, [rsp]
000071e7f4dda166  add rsp, 0x30
000071e7f4dda16a  vmovaps xmm0, [rsp]
000071e7f4dda16f  vmovaps xmm1, [rsp+0x10]
000071e7f4dda175  vmovaps xmm2, [rsp+0x20]
000071e7f4dda17b  vmovaps xmm3, [rsp+0x30]
000071e7f4dda181  vmovaps xmm4, [rsp+0x40]
000071e7f4dda187  vmovaps xmm5, [rsp+0x50]
000071e7f4dda18d  vmovaps xmm6, [rsp+0x60]
000071e7f4dda193  vmovaps xmm7, [rsp+0x70]
000071e7f4dda199  vmovaps xmm8, [rsp+0x80]
000071e7f4dda1a2  vmovaps xmm9, [rsp+0x90]
000071e7f4dda1ab  vmovaps xmm10, [rsp+0xA0]
000071e7f4dda1b4  vmovaps xmm11, [rsp+0xB0]
000071e7f4dda1bd  vmovaps xmm12, [rsp+0xC0]
000071e7f4dda1c6  vmovaps xmm13, [rsp+0xD0]
000071e7f4dda1cf  vmovaps xmm15, [rsp+0xE0]
000071e7f4dda1d8  add rsp, 0xF0
000071e7f4dda1df  pop r11
000071e7f4dda1e1  pop r10
000071e7f4dda1e3  pop r9
000071e7f4dda1e5  pop r8
000071e7f4dda1e7  pop rsi
000071e7f4dda1e8  pop rdi
000071e7f4dda1e9  pop rdx
000071e7f4dda1ea  pop rcx
000071e7f4dda1eb  pop rax
000071e7f4dda1ec  add rsp, 0x08
000071e7f4dda1f0  jmp 0x000071E7F4DD6400
000071e7f4dda1f5  sub rsp, 0x08
000071e7f4dda1f9  push rax
000071e7f4dda1fa  push rcx
000071e7f4dda1fb  push rdx
000071e7f4dda1fc  push rdi
000071e7f4dda1fd  push rsi
000071e7f4dda1fe  push r8
000071e7f4dda200  push r9
000071e7f4dda202  push r10
000071e7f4dda204  push r11
000071e7f4dda206  sub rsp, 0xF0
000071e7f4dda20d  vmovaps [rsp], xmm0
000071e7f4dda212  vmovaps [rsp+0x10], xmm2
000071e7f4dda218  vmovaps [rsp+0x20], xmm3
000071e7f4dda21e  vmovaps [rsp+0x30], xmm4
000071e7f4dda224  vmovaps [rsp+0x40], xmm5
000071e7f4dda22a  vmovaps [rsp+0x50], xmm6
000071e7f4dda230  vmovaps [rsp+0x60], xmm7
000071e7f4dda236  vmovaps [rsp+0x70], xmm8
000071e7f4dda23c  vmovaps [rsp+0x80], xmm9
000071e7f4dda245  vmovaps [rsp+0x90], xmm10
000071e7f4dda24e  vmovaps [rsp+0xA0], xmm11
000071e7f4dda257  vmovaps [rsp+0xB0], xmm12
000071e7f4dda260  vmovaps [rsp+0xC0], xmm13
000071e7f4dda269  vmovaps [rsp+0xD0], xmm14
000071e7f4dda272  vmovaps [rsp+0xE0], xmm15
000071e7f4dda27b  sub rsp, 0x30
000071e7f4dda27f  movaps [rsp], xmm1
000071e7f4dda283  movaps [rsp+0x10], xmm13
000071e7f4dda289  movaps [rsp+0x20], xmm9
000071e7f4dda28f  lea rdi, [rsp]
000071e7f4dda293  mov esi, 0x00
000071e7f4dda298  mov rax, 0x562A51E82530
000071e7f4dda2a2  call rax
000071e7f4dda2a4  movaps xmm1, [rsp]
000071e7f4dda2a8  add rsp, 0x30
000071e7f4dda2ac  vmovaps xmm0, [rsp]
000071e7f4dda2b1  vmovaps xmm2, [rsp+0x10]
000071e7f4dda2b7  vmovaps xmm3, [rsp+0x20]
000071e7f4dda2bd  vmovaps xmm4, [rsp+0x30]
000071e7f4dda2c3  vmovaps xmm5, [rsp+0x40]
000071e7f4dda2c9  vmovaps xmm6, [rsp+0x50]
000071e7f4dda2cf  vmovaps xmm7, [rsp+0x60]
000071e7f4dda2d5  vmovaps xmm8, [rsp+0x70]
000071e7f4dda2db  vmovaps xmm9, [rsp+0x80]
000071e7f4dda2e4  vmovaps xmm10, [rsp+0x90]
000071e7f4dda2ed  vmovaps xmm11, [rsp+0xA0]
000071e7f4dda2f6  vmovaps xmm12, [rsp+0xB0]
000071e7f4dda2ff  vmovaps xmm13, [rsp+0xC0]
000071e7f4dda308  vmovaps xmm14, [rsp+0xD0]
000071e7f4dda311  vmovaps xmm15, [rsp+0xE0]
000071e7f4dda31a  add rsp, 0xF0
000071e7f4dda321  pop r11
000071e7f4dda323  pop r10
000071e7f4dda325  pop r9
000071e7f4dda327  pop r8
000071e7f4dda329  pop rsi
000071e7f4dda32a  pop rdi
000071e7f4dda32b  pop rdx
000071e7f4dda32c  pop rcx
000071e7f4dda32d  pop rax
000071e7f4dda32e  add rsp, 0x08
000071e7f4dda332  jmp 0x000071E7F4DD641A
000071e7f4dda337  sub rsp, 0x08
000071e7f4dda33b  push rax
000071e7f4dda33c  push rcx
000071e7f4dda33d  push rdx
000071e7f4dda33e  push rdi
000071e7f4dda33f  push rsi
000071e7f4dda340  push r8
000071e7f4dda342  push r9
000071e7f4dda344  push r10
000071e7f4dda346  push r11
000071e7f4dda348  sub rsp, 0xF0
000071e7f4dda34f  vmovaps [rsp], xmm0
000071e7f4dda354  vmovaps [rsp+0x10], xmm1
000071e7f4dda35a  vmovaps [rsp+0x20], xmm2
000071e7f4dda360  vmovaps [rsp+0x30], xmm3
000071e7f4dda366  vmovaps [rsp+0x40], xmm4
000071e7f4dda36c  vmovaps [rsp+0x50], xmm5
000071e7f4dda372  vmovaps [rsp+0x60], xmm6
000071e7f4dda378  vmovaps [rsp+0x70], xmm7
000071e7f4dda37e  vmovaps [rsp+0x80], xmm8
000071e7f4dda387  vmovaps [rsp+0x90], xmm9
000071e7f4dda390  vmovaps [rsp+0xA0], xmm10
000071e7f4dda399  vmovaps [rsp+0xB0], xmm11
000071e7f4dda3a2  vmovaps [rsp+0xC0], xmm13
000071e7f4dda3ab  vmovaps [rsp+0xD0], xmm14
000071e7f4dda3b4  vmovaps [rsp+0xE0], xmm15
000071e7f4dda3bd  sub rsp, 0x30
000071e7f4dda3c1  movaps [rsp], xmm12
000071e7f4dda3c6  movaps [rsp+0x10], xmm7
000071e7f4dda3cb  movaps [rsp+0x20], xmm13
000071e7f4dda3d1  lea rdi, [rsp]
000071e7f4dda3d5  mov esi, 0x00
000071e7f4dda3da  mov rax, 0x562A51E82530
000071e7f4dda3e4  call rax
000071e7f4dda3e6  movaps xmm12, [rsp]
000071e7f4dda3eb  add rsp, 0x30
000071e7f4dda3ef  vmovaps xmm0, [rsp]
000071e7f4dda3f4  vmovaps xmm1, [rsp+0x10]
000071e7f4dda3fa  vmovaps xmm2, [rsp+0x20]
000071e7f4dda400  vmovaps xmm3, [rsp+0x30]
000071e7f4dda406  vmovaps xmm4, [rsp+0x40]
000071e7f4dda40c  vmovaps xmm5, [rsp+0x50]
000071e7f4dda412  vmovaps xmm6, [rsp+0x60]
000071e7f4dda418  vmovaps xmm7, [rsp+0x70]
000071e7f4dda41e  vmovaps xmm8, [rsp+0x80]
000071e7f4dda427  vmovaps xmm9, [rsp+0x90]
000071e7f4dda430  vmovaps xmm10, [rsp+0xA0]
000071e7f4dda439  vmovaps xmm11, [rsp+0xB0]
000071e7f4dda442  vmovaps xmm13, [rsp+0xC0]
000071e7f4dda44b  vmovaps xmm14, [rsp+0xD0]
000071e7f4dda454  vmovaps xmm15, [rsp+0xE0]
000071e7f4dda45d  add rsp, 0xF0
000071e7f4dda464  pop r11
000071e7f4dda466  pop r10
000071e7f4dda468  pop r9
000071e7f4dda46a  pop r8
000071e7f4dda46c  pop rsi
000071e7f4dda46d  pop rdi
000071e7f4dda46e  pop rdx
000071e7f4dda46f  pop rcx
000071e7f4dda470  pop rax
000071e7f4dda471  add rsp, 0x08
000071e7f4dda475  jmp 0x000071E7F4DD6441
000071e7f4dda47a  sub rsp, 0x08
000071e7f4dda47e  push rax
000071e7f4dda47f  push rcx
000071e7f4dda480  push rdx
000071e7f4dda481  push rdi
000071e7f4dda482  push rsi
000071e7f4dda483  push r8
000071e7f4dda485  push r9
000071e7f4dda487  push r10
000071e7f4dda489  push r11
000071e7f4dda48b  sub rsp, 0xF0
000071e7f4dda492  vmovaps [rsp], xmm0
000071e7f4dda497  vmovaps [rsp+0x10], xmm1
000071e7f4dda49d  vmovaps [rsp+0x20], xmm2
000071e7f4dda4a3  vmovaps [rsp+0x30], xmm3
000071e7f4dda4a9  vmovaps [rsp+0x40], xmm4
000071e7f4dda4af  vmovaps [rsp+0x50], xmm5
000071e7f4dda4b5  vmovaps [rsp+0x60], xmm6
000071e7f4dda4bb  vmovaps [rsp+0x70], xmm7
000071e7f4dda4c1  vmovaps [rsp+0x80], xmm8
000071e7f4dda4ca  vmovaps [rsp+0x90], xmm9
000071e7f4dda4d3  vmovaps [rsp+0xA0], xmm10
000071e7f4dda4dc  vmovaps [rsp+0xB0], xmm11
000071e7f4dda4e5  vmovaps [rsp+0xC0], xmm12
000071e7f4dda4ee  vmovaps [rsp+0xD0], xmm14
000071e7f4dda4f7  vmovaps [rsp+0xE0], xmm15
000071e7f4dda500  sub rsp, 0x30
000071e7f4dda504  movaps [rsp], xmm13
000071e7f4dda509  movaps [rsp+0x10], xmm15
000071e7f4dda50f  movaps [rsp+0x20], xmm8
000071e7f4dda515  lea rdi, [rsp]
000071e7f4dda519  mov esi, 0x00
000071e7f4dda51e  mov rax, 0x562A51E82530
000071e7f4dda528  call rax
000071e7f4dda52a  movaps xmm13, [rsp]
000071e7f4dda52f  add rsp, 0x30
000071e7f4dda533  vmovaps xmm0, [rsp]
000071e7f4dda538  vmovaps xmm1, [rsp+0x10]
000071e7f4dda53e  vmovaps xmm2, [rsp+0x20]
000071e7f4dda544  vmovaps xmm3, [rsp+0x30]
000071e7f4dda54a  vmovaps xmm4, [rsp+0x40]
000071e7f4dda550  vmovaps xmm5, [rsp+0x50]
000071e7f4dda556  vmovaps xmm6, [rsp+0x60]
000071e7f4dda55c  vmovaps xmm7, [rsp+0x70]
000071e7f4dda562  vmovaps xmm8, [rsp+0x80]
000071e7f4dda56b  vmovaps xmm9, [rsp+0x90]
000071e7f4dda574  vmovaps xmm10, [rsp+0xA0]
000071e7f4dda57d  vmovaps xmm11, [rsp+0xB0]
000071e7f4dda586  vmovaps xmm12, [rsp+0xC0]
000071e7f4dda58f  vmovaps xmm14, [rsp+0xD0]
000071e7f4dda598  vmovaps xmm15, [rsp+0xE0]
000071e7f4dda5a1  add rsp, 0xF0
000071e7f4dda5a8  pop r11
000071e7f4dda5aa  pop r10
000071e7f4dda5ac  pop r9
000071e7f4dda5ae  pop r8
000071e7f4dda5b0  pop rsi
000071e7f4dda5b1  pop rdi
000071e7f4dda5b2  pop rdx
000071e7f4dda5b3  pop rcx
000071e7f4dda5b4  pop rax
000071e7f4dda5b5  add rsp, 0x08
000071e7f4dda5b9  jmp 0x000071E7F4DD645C
000071e7f4dda5be  sub rsp, 0x08
000071e7f4dda5c2  push rax
000071e7f4dda5c3  push rcx
000071e7f4dda5c4  push rdx
000071e7f4dda5c5  push rdi
000071e7f4dda5c6  push rsi
000071e7f4dda5c7  push r8
000071e7f4dda5c9  push r9
000071e7f4dda5cb  push r10
000071e7f4dda5cd  push r11
000071e7f4dda5cf  sub rsp, 0xF0
000071e7f4dda5d6  vmovaps [rsp], xmm0
000071e7f4dda5db  vmovaps [rsp+0x10], xmm1
000071e7f4dda5e1  vmovaps [rsp+0x20], xmm2
000071e7f4dda5e7  vmovaps [rsp+0x30], xmm3
000071e7f4dda5ed  vmovaps [rsp+0x40], xmm4
000071e7f4dda5f3  vmovaps [rsp+0x50], xmm5
000071e7f4dda5f9  vmovaps [rsp+0x60], xmm6
000071e7f4dda5ff  vmovaps [rsp+0x70], xmm7
000071e7f4dda605  vmovaps [rsp+0x80], xmm9
000071e7f4dda60e  vmovaps [rsp+0x90], xmm10
000071e7f4dda617  vmovaps [rsp+0xA0], xmm11
000071e7f4dda620  vmovaps [rsp+0xB0], xmm12
000071e7f4dda629  vmovaps [rsp+0xC0], xmm13
000071e7f4dda632  vmovaps [rsp+0xD0], xmm14
000071e7f4dda63b  vmovaps [rsp+0xE0], xmm15
000071e7f4dda644  sub rsp, 0x30
000071e7f4dda648  movaps [rsp], xmm8
000071e7f4dda64d  movaps [rsp+0x10], xmm15
000071e7f4dda653  movaps [rsp+0x20], xmm9
000071e7f4dda659  lea rdi, [rsp]
000071e7f4dda65d  mov esi, 0x00
000071e7f4dda662  mov rax, 0x562A51E82530
000071e7f4dda66c  call rax
000071e7f4dda66e  movaps xmm8, [rsp]
000071e7f4dda673  add rsp, 0x30
000071e7f4dda677  vmovaps xmm0, [rsp]
000071e7f4dda67c  vmovaps xmm1, [rsp+0x10]
000071e7f4dda682  vmovaps xmm2, [rsp+0x20]
000071e7f4dda688  vmovaps xmm3, [rsp+0x30]
000071e7f4dda68e  vmovaps xmm4, [rsp+0x40]
000071e7f4dda694  vmovaps xmm5, [rsp+0x50]
000071e7f4dda69a  vmovaps xmm6, [rsp+0x60]
000071e7f4dda6a0  vmovaps xmm7, [rsp+0x70]
000071e7f4dda6a6  vmovaps xmm9, [rsp+0x80]
000071e7f4dda6af  vmovaps xmm10, [rsp+0x90]
000071e7f4dda6b8  vmovaps xmm11, [rsp+0xA0]
000071e7f4dda6c1  vmovaps xmm12, [rsp+0xB0]
000071e7f4dda6ca  vmovaps xmm13, [rsp+0xC0]
000071e7f4dda6d3  vmovaps xmm14, [rsp+0xD0]
000071e7f4dda6dc  vmovaps xmm15, [rsp+0xE0]
000071e7f4dda6e5  add rsp, 0xF0
000071e7f4dda6ec  pop r11
000071e7f4dda6ee  pop r10
000071e7f4dda6f0  pop r9
000071e7f4dda6f2  pop r8
000071e7f4dda6f4  pop rsi
000071e7f4dda6f5  pop rdi
000071e7f4dda6f6  pop rdx
000071e7f4dda6f7  pop rcx
000071e7f4dda6f8  pop rax
000071e7f4dda6f9  add rsp, 0x08
000071e7f4dda6fd  jmp 0x000071E7F4DD648A
000071e7f4dda702  sub rsp, 0x08
000071e7f4dda706  push rax
000071e7f4dda707  push rcx
000071e7f4dda708  push rdx
000071e7f4dda709  push rdi
000071e7f4dda70a  push rsi
000071e7f4dda70b  push r8
000071e7f4dda70d  push r9
000071e7f4dda70f  push r10
000071e7f4dda711  push r11
000071e7f4dda713  sub rsp, 0xF0
000071e7f4dda71a  vmovaps [rsp], xmm0
000071e7f4dda71f  vmovaps [rsp+0x10], xmm1
000071e7f4dda725  vmovaps [rsp+0x20], xmm2
000071e7f4dda72b  vmovaps [rsp+0x30], xmm3
000071e7f4dda731  vmovaps [rsp+0x40], xmm4
000071e7f4dda737  vmovaps [rsp+0x50], xmm5
000071e7f4dda73d  vmovaps [rsp+0x60], xmm6
000071e7f4dda743  vmovaps [rsp+0x70], xmm7
000071e7f4dda749  vmovaps [rsp+0x80], xmm8
000071e7f4dda752  vmovaps [rsp+0x90], xmm9
000071e7f4dda75b  vmovaps [rsp+0xA0], xmm10
000071e7f4dda764  vmovaps [rsp+0xB0], xmm11
000071e7f4dda76d  vmovaps [rsp+0xC0], xmm12
000071e7f4dda776  vmovaps [rsp+0xD0], xmm13
000071e7f4dda77f  vmovaps [rsp+0xE0], xmm14
000071e7f4dda788  sub rsp, 0x30
000071e7f4dda78c  movaps [rsp], xmm15
000071e7f4dda791  movaps [rsp+0x10], xmm11
000071e7f4dda797  movaps [rsp+0x20], xmm6
000071e7f4dda79c  lea rdi, [rsp]
000071e7f4dda7a0  mov esi, 0x00
000071e7f4dda7a5  mov rax, 0x562A51E82530
000071e7f4dda7af  call rax
000071e7f4dda7b1  movaps xmm15, [rsp]
000071e7f4dda7b6  add rsp, 0x30
000071e7f4dda7ba  vmovaps xmm0, [rsp]
000071e7f4dda7bf  vmovaps xmm1, [rsp+0x10]
000071e7f4dda7c5  vmovaps xmm2, [rsp+0x20]
000071e7f4dda7cb  vmovaps xmm3, [rsp+0x30]
000071e7f4dda7d1  vmovaps xmm4, [rsp+0x40]
000071e7f4dda7d7  vmovaps xmm5, [rsp+0x50]
000071e7f4dda7dd  vmovaps xmm6, [rsp+0x60]
000071e7f4dda7e3  vmovaps xmm7, [rsp+0x70]
000071e7f4dda7e9  vmovaps xmm8, [rsp+0x80]
000071e7f4dda7f2  vmovaps xmm9, [rsp+0x90]
000071e7f4dda7fb  vmovaps xmm10, [rsp+0xA0]
000071e7f4dda804  vmovaps xmm11, [rsp+0xB0]
000071e7f4dda80d  vmovaps xmm12, [rsp+0xC0]
000071e7f4dda816  vmovaps xmm13, [rsp+0xD0]
000071e7f4dda81f  vmovaps xmm14, [rsp+0xE0]
000071e7f4dda828  add rsp, 0xF0
000071e7f4dda82f  pop r11
000071e7f4dda831  pop r10
000071e7f4dda833  pop r9
000071e7f4dda835  pop r8
000071e7f4dda837  pop rsi
000071e7f4dda838  pop rdi
000071e7f4dda839  pop rdx
000071e7f4dda83a  pop rcx
000071e7f4dda83b  pop rax
000071e7f4dda83c  add rsp, 0x08
000071e7f4dda840  jmp 0x000071E7F4DD64A5
000071e7f4dda845  sub rsp, 0x08
000071e7f4dda849  push rax
000071e7f4dda84a  push rcx
000071e7f4dda84b  push rdx
000071e7f4dda84c  push rdi
000071e7f4dda84d  push rsi
000071e7f4dda84e  push r8
000071e7f4dda850  push r9
000071e7f4dda852  push r10
000071e7f4dda854  push r11
000071e7f4dda856  sub rsp, 0xF0
000071e7f4dda85d  vmovaps [rsp], xmm0
000071e7f4dda862  vmovaps [rsp+0x10], xmm1
000071e7f4dda868  vmovaps [rsp+0x20], xmm2
000071e7f4dda86e  vmovaps [rsp+0x30], xmm3
000071e7f4dda874  vmovaps [rsp+0x40], xmm4
000071e7f4dda87a  vmovaps [rsp+0x50], xmm5
000071e7f4dda880  vmovaps [rsp+0x60], xmm6
000071e7f4dda886  vmovaps [rsp+0x70], xmm8
000071e7f4dda88c  vmovaps [rsp+0x80], xmm9
000071e7f4dda895  vmovaps [rsp+0x90], xmm10
000071e7f4dda89e  vmovaps [rsp+0xA0], xmm11
000071e7f4dda8a7  vmovaps [rsp+0xB0], xmm12
000071e7f4dda8b0  vmovaps [rsp+0xC0], xmm13
000071e7f4dda8b9  vmovaps [rsp+0xD0], xmm14
000071e7f4dda8c2  vmovaps [rsp+0xE0], xmm15
000071e7f4dda8cb  sub rsp, 0x30
000071e7f4dda8cf  movaps [rsp], xmm7
000071e7f4dda8d3  movaps [rsp+0x10], xmm11
000071e7f4dda8d9  movaps [rsp+0x20], xmm9
000071e7f4dda8df  lea rdi, [rsp]
000071e7f4dda8e3  mov esi, 0x00
000071e7f4dda8e8  mov rax, 0x562A51E82530
000071e7f4dda8f2  call rax
000071e7f4dda8f4  movaps xmm7, [rsp]
000071e7f4dda8f8  add rsp, 0x30
000071e7f4dda8fc  vmovaps xmm0, [rsp]
000071e7f4dda901  vmovaps xmm1, [rsp+0x10]
000071e7f4dda907  vmovaps xmm2, [rsp+0x20]
000071e7f4dda90d  vmovaps xmm3, [rsp+0x30]
000071e7f4dda913  vmovaps xmm4, [rsp+0x40]
000071e7f4dda919  vmovaps xmm5, [rsp+0x50]
000071e7f4dda91f  vmovaps xmm6, [rsp+0x60]
000071e7f4dda925  vmovaps xmm8, [rsp+0x70]
000071e7f4dda92b  vmovaps xmm9, [rsp+0x80]
000071e7f4dda934  vmovaps xmm10, [rsp+0x90]
000071e7f4dda93d  vmovaps xmm11, [rsp+0xA0]
000071e7f4dda946  vmovaps xmm12, [rsp+0xB0]
000071e7f4dda94f  vmovaps xmm13, [rsp+0xC0]
000071e7f4dda958  vmovaps xmm14, [rsp+0xD0]
000071e7f4dda961  vmovaps xmm15, [rsp+0xE0]
000071e7f4dda96a  add rsp, 0xF0
000071e7f4dda971  pop r11
000071e7f4dda973  pop r10
000071e7f4dda975  pop r9
000071e7f4dda977  pop r8
000071e7f4dda979  pop rsi
000071e7f4dda97a  pop rdi
000071e7f4dda97b  pop rdx
000071e7f4dda97c  pop rcx
000071e7f4dda97d  pop rax
000071e7f4dda97e  add rsp, 0x08
000071e7f4dda982  jmp 0x000071E7F4DD64D2
000071e7f4dda987  sub rsp, 0x08
000071e7f4dda98b  push rax
000071e7f4dda98c  push rcx
000071e7f4dda98d  push rdx
000071e7f4dda98e  push rdi
000071e7f4dda98f  push rsi
000071e7f4dda990  push r8
000071e7f4dda992  push r9
000071e7f4dda994  push r10
000071e7f4dda996  push r11
000071e7f4dda998  sub rsp, 0xF0
000071e7f4dda99f  vmovaps [rsp], xmm0
000071e7f4dda9a4  vmovaps [rsp+0x10], xmm1
000071e7f4dda9aa  vmovaps [rsp+0x20], xmm2
000071e7f4dda9b0  vmovaps [rsp+0x30], xmm3
000071e7f4dda9b6  vmovaps [rsp+0x40], xmm4
000071e7f4dda9bc  vmovaps [rsp+0x50], xmm5
000071e7f4dda9c2  vmovaps [rsp+0x60], xmm6
000071e7f4dda9c8  vmovaps [rsp+0x70], xmm7
000071e7f4dda9ce  vmovaps [rsp+0x80], xmm8
000071e7f4dda9d7  vmovaps [rsp+0x90], xmm9
000071e7f4dda9e0  vmovaps [rsp+0xA0], xmm10
000071e7f4dda9e9  vmovaps [rsp+0xB0], xmm12
000071e7f4dda9f2  vmovaps [rsp+0xC0], xmm13
000071e7f4dda9fb  vmovaps [rsp+0xD0], xmm14
000071e7f4ddaa04  vmovaps [rsp+0xE0], xmm15
000071e7f4ddaa0d  sub rsp, 0x30
000071e7f4ddaa11  movaps [rsp], xmm11
000071e7f4ddaa16  movaps [rsp+0x10], xmm10
000071e7f4ddaa1c  movaps [rsp+0x20], xmm14
000071e7f4ddaa22  lea rdi, [rsp]
000071e7f4ddaa26  mov esi, 0x00
000071e7f4ddaa2b  mov rax, 0x562A51E82530
000071e7f4ddaa35  call rax
000071e7f4ddaa37  movaps xmm11, [rsp]
000071e7f4ddaa3c  add rsp, 0x30
000071e7f4ddaa40  vmovaps xmm0, [rsp]
000071e7f4ddaa45  vmovaps xmm1, [rsp+0x10]
000071e7f4ddaa4b  vmovaps xmm2, [rsp+0x20]
000071e7f4ddaa51  vmovaps xmm3, [rsp+0x30]
000071e7f4ddaa57  vmovaps xmm4, [rsp+0x40]
000071e7f4ddaa5d  vmovaps xmm5, [rsp+0x50]
000071e7f4ddaa63  vmovaps xmm6, [rsp+0x60]
000071e7f4ddaa69  vmovaps xmm7, [rsp+0x70]
000071e7f4ddaa6f  vmovaps xmm8, [rsp+0x80]
000071e7f4ddaa78  vmovaps xmm9, [rsp+0x90]
000071e7f4ddaa81  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddaa8a  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddaa93  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddaa9c  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddaaa5  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddaaae  add rsp, 0xF0
000071e7f4ddaab5  pop r11
000071e7f4ddaab7  pop r10
000071e7f4ddaab9  pop r9
000071e7f4ddaabb  pop r8
000071e7f4ddaabd  pop rsi
000071e7f4ddaabe  pop rdi
000071e7f4ddaabf  pop rdx
000071e7f4ddaac0  pop rcx
000071e7f4ddaac1  pop rax
000071e7f4ddaac2  add rsp, 0x08
000071e7f4ddaac6  jmp 0x000071E7F4DD64ED
000071e7f4ddaacb  call 0x000071E7F4CE45A0
000071e7f4ddaad0  jmp 0x000071E7F4DD64F7
000071e7f4ddaad5  sub rsp, 0x08
000071e7f4ddaad9  push rax
000071e7f4ddaada  push rcx
000071e7f4ddaadb  push rdx
000071e7f4ddaadc  push rdi
000071e7f4ddaadd  push rsi
000071e7f4ddaade  push r8
000071e7f4ddaae0  push r9
000071e7f4ddaae2  push r10
000071e7f4ddaae4  push r11
000071e7f4ddaae6  sub rsp, 0xF0
000071e7f4ddaaed  vmovaps [rsp], xmm0
000071e7f4ddaaf2  vmovaps [rsp+0x10], xmm1
000071e7f4ddaaf8  vmovaps [rsp+0x20], xmm2
000071e7f4ddaafe  vmovaps [rsp+0x30], xmm3
000071e7f4ddab04  vmovaps [rsp+0x40], xmm4
000071e7f4ddab0a  vmovaps [rsp+0x50], xmm5
000071e7f4ddab10  vmovaps [rsp+0x60], xmm6
000071e7f4ddab16  vmovaps [rsp+0x70], xmm7
000071e7f4ddab1c  vmovaps [rsp+0x80], xmm8
000071e7f4ddab25  vmovaps [rsp+0x90], xmm9
000071e7f4ddab2e  vmovaps [rsp+0xA0], xmm11
000071e7f4ddab37  vmovaps [rsp+0xB0], xmm12
000071e7f4ddab40  vmovaps [rsp+0xC0], xmm13
000071e7f4ddab49  vmovaps [rsp+0xD0], xmm14
000071e7f4ddab52  vmovaps [rsp+0xE0], xmm15
000071e7f4ddab5b  sub rsp, 0x30
000071e7f4ddab5f  movaps [rsp], xmm10
000071e7f4ddab64  movaps [rsp+0x10], xmm1
000071e7f4ddab69  movaps [rsp+0x20], xmm12
000071e7f4ddab6f  lea rdi, [rsp]
000071e7f4ddab73  mov esi, 0x00
000071e7f4ddab78  mov rax, 0x562A51E82530
000071e7f4ddab82  call rax
000071e7f4ddab84  movaps xmm10, [rsp]
000071e7f4ddab89  add rsp, 0x30
000071e7f4ddab8d  vmovaps xmm0, [rsp]
000071e7f4ddab92  vmovaps xmm1, [rsp+0x10]
000071e7f4ddab98  vmovaps xmm2, [rsp+0x20]
000071e7f4ddab9e  vmovaps xmm3, [rsp+0x30]
000071e7f4ddaba4  vmovaps xmm4, [rsp+0x40]
000071e7f4ddabaa  vmovaps xmm5, [rsp+0x50]
000071e7f4ddabb0  vmovaps xmm6, [rsp+0x60]
000071e7f4ddabb6  vmovaps xmm7, [rsp+0x70]
000071e7f4ddabbc  vmovaps xmm8, [rsp+0x80]
000071e7f4ddabc5  vmovaps xmm9, [rsp+0x90]
000071e7f4ddabce  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddabd7  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddabe0  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddabe9  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddabf2  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddabfb  add rsp, 0xF0
000071e7f4ddac02  pop r11
000071e7f4ddac04  pop r10
000071e7f4ddac06  pop r9
000071e7f4ddac08  pop r8
000071e7f4ddac0a  pop rsi
000071e7f4ddac0b  pop rdi
000071e7f4ddac0c  pop rdx
000071e7f4ddac0d  pop rcx
000071e7f4ddac0e  pop rax
000071e7f4ddac0f  add rsp, 0x08
000071e7f4ddac13  jmp 0x000071E7F4DD651A
000071e7f4ddac18  sub rsp, 0x08
000071e7f4ddac1c  push rax
000071e7f4ddac1d  push rcx
000071e7f4ddac1e  push rdx
000071e7f4ddac1f  push rdi
000071e7f4ddac20  push rsi
000071e7f4ddac21  push r8
000071e7f4ddac23  push r9
000071e7f4ddac25  push r10
000071e7f4ddac27  push r11
000071e7f4ddac29  sub rsp, 0xF0
000071e7f4ddac30  vmovaps [rsp], xmm0
000071e7f4ddac35  vmovaps [rsp+0x10], xmm1
000071e7f4ddac3b  vmovaps [rsp+0x20], xmm2
000071e7f4ddac41  vmovaps [rsp+0x30], xmm3
000071e7f4ddac47  vmovaps [rsp+0x40], xmm4
000071e7f4ddac4d  vmovaps [rsp+0x50], xmm5
000071e7f4ddac53  vmovaps [rsp+0x60], xmm6
000071e7f4ddac59  vmovaps [rsp+0x70], xmm7
000071e7f4ddac5f  vmovaps [rsp+0x80], xmm8
000071e7f4ddac68  vmovaps [rsp+0x90], xmm9
000071e7f4ddac71  vmovaps [rsp+0xA0], xmm10
000071e7f4ddac7a  vmovaps [rsp+0xB0], xmm11
000071e7f4ddac83  vmovaps [rsp+0xC0], xmm13
000071e7f4ddac8c  vmovaps [rsp+0xD0], xmm14
000071e7f4ddac95  vmovaps [rsp+0xE0], xmm15
000071e7f4ddac9e  sub rsp, 0x30
000071e7f4ddaca2  movaps [rsp], xmm12
000071e7f4ddaca7  movaps [rsp+0x10], xmm14
000071e7f4ddacad  movaps [rsp+0x20], xmm1
000071e7f4ddacb2  lea rdi, [rsp]
000071e7f4ddacb6  mov esi, 0x00
000071e7f4ddacbb  mov rax, 0x562A51E82530
000071e7f4ddacc5  call rax
000071e7f4ddacc7  movaps xmm12, [rsp]
000071e7f4ddaccc  add rsp, 0x30
000071e7f4ddacd0  vmovaps xmm0, [rsp]
000071e7f4ddacd5  vmovaps xmm1, [rsp+0x10]
000071e7f4ddacdb  vmovaps xmm2, [rsp+0x20]
000071e7f4ddace1  vmovaps xmm3, [rsp+0x30]
000071e7f4ddace7  vmovaps xmm4, [rsp+0x40]
000071e7f4ddaced  vmovaps xmm5, [rsp+0x50]
000071e7f4ddacf3  vmovaps xmm6, [rsp+0x60]
000071e7f4ddacf9  vmovaps xmm7, [rsp+0x70]
000071e7f4ddacff  vmovaps xmm8, [rsp+0x80]
000071e7f4ddad08  vmovaps xmm9, [rsp+0x90]
000071e7f4ddad11  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddad1a  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddad23  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddad2c  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddad35  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddad3e  add rsp, 0xF0
000071e7f4ddad45  pop r11
000071e7f4ddad47  pop r10
000071e7f4ddad49  pop r9
000071e7f4ddad4b  pop r8
000071e7f4ddad4d  pop rsi
000071e7f4ddad4e  pop rdi
000071e7f4ddad4f  pop rdx
000071e7f4ddad50  pop rcx
000071e7f4ddad51  pop rax
000071e7f4ddad52  add rsp, 0x08
000071e7f4ddad56  jmp 0x000071E7F4DD6549
000071e7f4ddad5b  sub rsp, 0x08
000071e7f4ddad5f  push rax
000071e7f4ddad60  push rcx
000071e7f4ddad61  push rdx
000071e7f4ddad62  push rdi
000071e7f4ddad63  push rsi
000071e7f4ddad64  push r8
000071e7f4ddad66  push r9
000071e7f4ddad68  push r10
000071e7f4ddad6a  push r11
000071e7f4ddad6c  sub rsp, 0xF0
000071e7f4ddad73  vmovaps [rsp], xmm0
000071e7f4ddad78  vmovaps [rsp+0x10], xmm1
000071e7f4ddad7e  vmovaps [rsp+0x20], xmm2
000071e7f4ddad84  vmovaps [rsp+0x30], xmm3
000071e7f4ddad8a  vmovaps [rsp+0x40], xmm4
000071e7f4ddad90  vmovaps [rsp+0x50], xmm5
000071e7f4ddad96  vmovaps [rsp+0x60], xmm6
000071e7f4ddad9c  vmovaps [rsp+0x70], xmm7
000071e7f4ddada2  vmovaps [rsp+0x80], xmm8
000071e7f4ddadab  vmovaps [rsp+0x90], xmm9
000071e7f4ddadb4  vmovaps [rsp+0xA0], xmm10
000071e7f4ddadbd  vmovaps [rsp+0xB0], xmm11
000071e7f4ddadc6  vmovaps [rsp+0xC0], xmm12
000071e7f4ddadcf  vmovaps [rsp+0xD0], xmm13
000071e7f4ddadd8  vmovaps [rsp+0xE0], xmm15
000071e7f4ddade1  sub rsp, 0x30
000071e7f4ddade5  movaps [rsp], xmm14
000071e7f4ddadea  movaps [rsp+0x10], xmm9
000071e7f4ddadf0  movaps [rsp+0x20], xmm1
000071e7f4ddadf5  lea rdi, [rsp]
000071e7f4ddadf9  mov esi, 0x00
000071e7f4ddadfe  mov rax, 0x562A51E82530
000071e7f4ddae08  call rax
000071e7f4ddae0a  movaps xmm14, [rsp]
000071e7f4ddae0f  add rsp, 0x30
000071e7f4ddae13  vmovaps xmm0, [rsp]
000071e7f4ddae18  vmovaps xmm1, [rsp+0x10]
000071e7f4ddae1e  vmovaps xmm2, [rsp+0x20]
000071e7f4ddae24  vmovaps xmm3, [rsp+0x30]
000071e7f4ddae2a  vmovaps xmm4, [rsp+0x40]
000071e7f4ddae30  vmovaps xmm5, [rsp+0x50]
000071e7f4ddae36  vmovaps xmm6, [rsp+0x60]
000071e7f4ddae3c  vmovaps xmm7, [rsp+0x70]
000071e7f4ddae42  vmovaps xmm8, [rsp+0x80]
000071e7f4ddae4b  vmovaps xmm9, [rsp+0x90]
000071e7f4ddae54  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddae5d  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddae66  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddae6f  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddae78  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddae81  add rsp, 0xF0
000071e7f4ddae88  pop r11
000071e7f4ddae8a  pop r10
000071e7f4ddae8c  pop r9
000071e7f4ddae8e  pop r8
000071e7f4ddae90  pop rsi
000071e7f4ddae91  pop rdi
000071e7f4ddae92  pop rdx
000071e7f4ddae93  pop rcx
000071e7f4ddae94  pop rax
000071e7f4ddae95  add rsp, 0x08
000071e7f4ddae99  jmp 0x000071E7F4DD6578
000071e7f4ddae9e  sub rsp, 0x08
000071e7f4ddaea2  push rax
000071e7f4ddaea3  push rcx
000071e7f4ddaea4  push rdx
000071e7f4ddaea5  push rdi
000071e7f4ddaea6  push rsi
000071e7f4ddaea7  push r8
000071e7f4ddaea9  push r9
000071e7f4ddaeab  push r10
000071e7f4ddaead  push r11
000071e7f4ddaeaf  sub rsp, 0xF0
000071e7f4ddaeb6  vmovaps [rsp], xmm0
000071e7f4ddaebb  vmovaps [rsp+0x10], xmm2
000071e7f4ddaec1  vmovaps [rsp+0x20], xmm3
000071e7f4ddaec7  vmovaps [rsp+0x30], xmm4
000071e7f4ddaecd  vmovaps [rsp+0x40], xmm5
000071e7f4ddaed3  vmovaps [rsp+0x50], xmm6
000071e7f4ddaed9  vmovaps [rsp+0x60], xmm7
000071e7f4ddaedf  vmovaps [rsp+0x70], xmm8
000071e7f4ddaee5  vmovaps [rsp+0x80], xmm9
000071e7f4ddaeee  vmovaps [rsp+0x90], xmm10
000071e7f4ddaef7  vmovaps [rsp+0xA0], xmm11
000071e7f4ddaf00  vmovaps [rsp+0xB0], xmm12
000071e7f4ddaf09  vmovaps [rsp+0xC0], xmm13
000071e7f4ddaf12  vmovaps [rsp+0xD0], xmm14
000071e7f4ddaf1b  vmovaps [rsp+0xE0], xmm15
000071e7f4ddaf24  sub rsp, 0x30
000071e7f4ddaf28  movaps [rsp], xmm1
000071e7f4ddaf2c  movaps [rsp+0x10], xmm13
000071e7f4ddaf32  movaps [rsp+0x20], xmm8
000071e7f4ddaf38  lea rdi, [rsp]
000071e7f4ddaf3c  mov esi, 0x00
000071e7f4ddaf41  mov rax, 0x562A51E82530
000071e7f4ddaf4b  call rax
000071e7f4ddaf4d  movaps xmm1, [rsp]
000071e7f4ddaf51  add rsp, 0x30
000071e7f4ddaf55  vmovaps xmm0, [rsp]
000071e7f4ddaf5a  vmovaps xmm2, [rsp+0x10]
000071e7f4ddaf60  vmovaps xmm3, [rsp+0x20]
000071e7f4ddaf66  vmovaps xmm4, [rsp+0x30]
000071e7f4ddaf6c  vmovaps xmm5, [rsp+0x40]
000071e7f4ddaf72  vmovaps xmm6, [rsp+0x50]
000071e7f4ddaf78  vmovaps xmm7, [rsp+0x60]
000071e7f4ddaf7e  vmovaps xmm8, [rsp+0x70]
000071e7f4ddaf84  vmovaps xmm9, [rsp+0x80]
000071e7f4ddaf8d  vmovaps xmm10, [rsp+0x90]
000071e7f4ddaf96  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddaf9f  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddafa8  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddafb1  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddafba  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddafc3  add rsp, 0xF0
000071e7f4ddafca  pop r11
000071e7f4ddafcc  pop r10
000071e7f4ddafce  pop r9
000071e7f4ddafd0  pop r8
000071e7f4ddafd2  pop rsi
000071e7f4ddafd3  pop rdi
000071e7f4ddafd4  pop rdx
000071e7f4ddafd5  pop rcx
000071e7f4ddafd6  pop rax
000071e7f4ddafd7  add rsp, 0x08
000071e7f4ddafdb  jmp 0x000071E7F4DD659A
000071e7f4ddafe0  call 0x000071E7F4C0C260
000071e7f4ddafe5  jmp 0x000071E7F4DD65A8
000071e7f4ddafea  call 0x000071E7F4CDE950
000071e7f4ddafef  jmp 0x000071E7F4DD65B2
000071e7f4ddaff4  sub rsp, 0x08
000071e7f4ddaff8  push rax
000071e7f4ddaff9  push rcx
000071e7f4ddaffa  push rdx
000071e7f4ddaffb  push rdi
000071e7f4ddaffc  push rsi
000071e7f4ddaffd  push r8
000071e7f4ddafff  push r9
000071e7f4ddb001  push r10
000071e7f4ddb003  push r11
000071e7f4ddb005  sub rsp, 0xF0
000071e7f4ddb00c  vmovaps [rsp], xmm0
000071e7f4ddb011  vmovaps [rsp+0x10], xmm1
000071e7f4ddb017  vmovaps [rsp+0x20], xmm2
000071e7f4ddb01d  vmovaps [rsp+0x30], xmm3
000071e7f4ddb023  vmovaps [rsp+0x40], xmm4
000071e7f4ddb029  vmovaps [rsp+0x50], xmm5
000071e7f4ddb02f  vmovaps [rsp+0x60], xmm6
000071e7f4ddb035  vmovaps [rsp+0x70], xmm7
000071e7f4ddb03b  vmovaps [rsp+0x80], xmm9
000071e7f4ddb044  vmovaps [rsp+0x90], xmm10
000071e7f4ddb04d  vmovaps [rsp+0xA0], xmm11
000071e7f4ddb056  vmovaps [rsp+0xB0], xmm12
000071e7f4ddb05f  vmovaps [rsp+0xC0], xmm13
000071e7f4ddb068  vmovaps [rsp+0xD0], xmm14
000071e7f4ddb071  vmovaps [rsp+0xE0], xmm15
000071e7f4ddb07a  sub rsp, 0x30
000071e7f4ddb07e  movaps [rsp], xmm8
000071e7f4ddb083  movaps [rsp+0x10], xmm15
000071e7f4ddb089  movaps [rsp+0x20], xmm7
000071e7f4ddb08e  lea rdi, [rsp]
000071e7f4ddb092  mov esi, 0x00
000071e7f4ddb097  mov rax, 0x562A51E82530
000071e7f4ddb0a1  call rax
000071e7f4ddb0a3  movaps xmm8, [rsp]
000071e7f4ddb0a8  add rsp, 0x30
000071e7f4ddb0ac  vmovaps xmm0, [rsp]
000071e7f4ddb0b1  vmovaps xmm1, [rsp+0x10]
000071e7f4ddb0b7  vmovaps xmm2, [rsp+0x20]
000071e7f4ddb0bd  vmovaps xmm3, [rsp+0x30]
000071e7f4ddb0c3  vmovaps xmm4, [rsp+0x40]
000071e7f4ddb0c9  vmovaps xmm5, [rsp+0x50]
000071e7f4ddb0cf  vmovaps xmm6, [rsp+0x60]
000071e7f4ddb0d5  vmovaps xmm7, [rsp+0x70]
000071e7f4ddb0db  vmovaps xmm9, [rsp+0x80]
000071e7f4ddb0e4  vmovaps xmm10, [rsp+0x90]
000071e7f4ddb0ed  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddb0f6  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddb0ff  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddb108  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddb111  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddb11a  add rsp, 0xF0
000071e7f4ddb121  pop r11
000071e7f4ddb123  pop r10
000071e7f4ddb125  pop r9
000071e7f4ddb127  pop r8
000071e7f4ddb129  pop rsi
000071e7f4ddb12a  pop rdi
000071e7f4ddb12b  pop rdx
000071e7f4ddb12c  pop rcx
000071e7f4ddb12d  pop rax
000071e7f4ddb12e  add rsp, 0x08
000071e7f4ddb132  jmp 0x000071E7F4DD65D4
000071e7f4ddb137  sub rsp, 0x08
000071e7f4ddb13b  push rax
000071e7f4ddb13c  push rcx
000071e7f4ddb13d  push rdx
000071e7f4ddb13e  push rdi
000071e7f4ddb13f  push rsi
000071e7f4ddb140  push r8
000071e7f4ddb142  push r9
000071e7f4ddb144  push r10
000071e7f4ddb146  push r11
000071e7f4ddb148  sub rsp, 0xF0
000071e7f4ddb14f  vmovaps [rsp], xmm0
000071e7f4ddb154  vmovaps [rsp+0x10], xmm1
000071e7f4ddb15a  vmovaps [rsp+0x20], xmm2
000071e7f4ddb160  vmovaps [rsp+0x30], xmm3
000071e7f4ddb166  vmovaps [rsp+0x40], xmm4
000071e7f4ddb16c  vmovaps [rsp+0x50], xmm5
000071e7f4ddb172  vmovaps [rsp+0x60], xmm6
000071e7f4ddb178  vmovaps [rsp+0x70], xmm8
000071e7f4ddb17e  vmovaps [rsp+0x80], xmm9
000071e7f4ddb187  vmovaps [rsp+0x90], xmm10
000071e7f4ddb190  vmovaps [rsp+0xA0], xmm11
000071e7f4ddb199  vmovaps [rsp+0xB0], xmm12
000071e7f4ddb1a2  vmovaps [rsp+0xC0], xmm13
000071e7f4ddb1ab  vmovaps [rsp+0xD0], xmm14
000071e7f4ddb1b4  vmovaps [rsp+0xE0], xmm15
000071e7f4ddb1bd  sub rsp, 0x30
000071e7f4ddb1c1  movaps [rsp], xmm7
000071e7f4ddb1c5  movaps [rsp+0x10], xmm9
000071e7f4ddb1cb  movaps [rsp+0x20], xmm15
000071e7f4ddb1d1  lea rdi, [rsp]
000071e7f4ddb1d5  mov esi, 0x00
000071e7f4ddb1da  mov rax, 0x562A51E82530
000071e7f4ddb1e4  call rax
000071e7f4ddb1e6  movaps xmm7, [rsp]
000071e7f4ddb1ea  add rsp, 0x30
000071e7f4ddb1ee  vmovaps xmm0, [rsp]
000071e7f4ddb1f3  vmovaps xmm1, [rsp+0x10]
000071e7f4ddb1f9  vmovaps xmm2, [rsp+0x20]
000071e7f4ddb1ff  vmovaps xmm3, [rsp+0x30]
000071e7f4ddb205  vmovaps xmm4, [rsp+0x40]
000071e7f4ddb20b  vmovaps xmm5, [rsp+0x50]
000071e7f4ddb211  vmovaps xmm6, [rsp+0x60]
000071e7f4ddb217  vmovaps xmm8, [rsp+0x70]
000071e7f4ddb21d  vmovaps xmm9, [rsp+0x80]
000071e7f4ddb226  vmovaps xmm10, [rsp+0x90]
000071e7f4ddb22f  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddb238  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddb241  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddb24a  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddb253  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddb25c  add rsp, 0xF0
000071e7f4ddb263  pop r11
000071e7f4ddb265  pop r10
000071e7f4ddb267  pop r9
000071e7f4ddb269  pop r8
000071e7f4ddb26b  pop rsi
000071e7f4ddb26c  pop rdi
000071e7f4ddb26d  pop rdx
000071e7f4ddb26e  pop rcx
000071e7f4ddb26f  pop rax
000071e7f4ddb270  add rsp, 0x08
000071e7f4ddb274  jmp 0x000071E7F4DD6601
000071e7f4ddb279  sub rsp, 0x08
000071e7f4ddb27d  push rax
000071e7f4ddb27e  push rcx
000071e7f4ddb27f  push rdx
000071e7f4ddb280  push rdi
000071e7f4ddb281  push rsi
000071e7f4ddb282  push r8
000071e7f4ddb284  push r9
000071e7f4ddb286  push r10
000071e7f4ddb288  push r11
000071e7f4ddb28a  sub rsp, 0xF0
000071e7f4ddb291  vmovaps [rsp], xmm0
000071e7f4ddb296  vmovaps [rsp+0x10], xmm1
000071e7f4ddb29c  vmovaps [rsp+0x20], xmm2
000071e7f4ddb2a2  vmovaps [rsp+0x30], xmm3
000071e7f4ddb2a8  vmovaps [rsp+0x40], xmm4
000071e7f4ddb2ae  vmovaps [rsp+0x50], xmm5
000071e7f4ddb2b4  vmovaps [rsp+0x60], xmm6
000071e7f4ddb2ba  vmovaps [rsp+0x70], xmm7
000071e7f4ddb2c0  vmovaps [rsp+0x80], xmm8
000071e7f4ddb2c9  vmovaps [rsp+0x90], xmm10
000071e7f4ddb2d2  vmovaps [rsp+0xA0], xmm11
000071e7f4ddb2db  vmovaps [rsp+0xB0], xmm12
000071e7f4ddb2e4  vmovaps [rsp+0xC0], xmm13
000071e7f4ddb2ed  vmovaps [rsp+0xD0], xmm14
000071e7f4ddb2f6  vmovaps [rsp+0xE0], xmm15
000071e7f4ddb2ff  sub rsp, 0x30
000071e7f4ddb303  movaps [rsp], xmm9
000071e7f4ddb308  movaps [rsp+0x10], xmm13
000071e7f4ddb30e  movaps [rsp+0x20], xmm15
000071e7f4ddb314  lea rdi, [rsp]
000071e7f4ddb318  mov esi, 0x00
000071e7f4ddb31d  mov rax, 0x562A51E82530
000071e7f4ddb327  call rax
000071e7f4ddb329  movaps xmm9, [rsp]
000071e7f4ddb32e  add rsp, 0x30
000071e7f4ddb332  vmovaps xmm0, [rsp]
000071e7f4ddb337  vmovaps xmm1, [rsp+0x10]
000071e7f4ddb33d  vmovaps xmm2, [rsp+0x20]
000071e7f4ddb343  vmovaps xmm3, [rsp+0x30]
000071e7f4ddb349  vmovaps xmm4, [rsp+0x40]
000071e7f4ddb34f  vmovaps xmm5, [rsp+0x50]
000071e7f4ddb355  vmovaps xmm6, [rsp+0x60]
000071e7f4ddb35b  vmovaps xmm7, [rsp+0x70]
000071e7f4ddb361  vmovaps xmm8, [rsp+0x80]
000071e7f4ddb36a  vmovaps xmm10, [rsp+0x90]
000071e7f4ddb373  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddb37c  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddb385  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddb38e  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddb397  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddb3a0  add rsp, 0xF0
000071e7f4ddb3a7  pop r11
000071e7f4ddb3a9  pop r10
000071e7f4ddb3ab  pop r9
000071e7f4ddb3ad  pop r8
000071e7f4ddb3af  pop rsi
000071e7f4ddb3b0  pop rdi
000071e7f4ddb3b1  pop rdx
000071e7f4ddb3b2  pop rcx
000071e7f4ddb3b3  pop rax
000071e7f4ddb3b4  add rsp, 0x08
000071e7f4ddb3b8  jmp 0x000071E7F4DD662F
000071e7f4ddb3bd  sub rsp, 0x08
000071e7f4ddb3c1  push rax
000071e7f4ddb3c2  push rcx
000071e7f4ddb3c3  push rdx
000071e7f4ddb3c4  push rdi
000071e7f4ddb3c5  push rsi
000071e7f4ddb3c6  push r8
000071e7f4ddb3c8  push r9
000071e7f4ddb3ca  push r10
000071e7f4ddb3cc  push r11
000071e7f4ddb3ce  sub rsp, 0xF0
000071e7f4ddb3d5  vmovaps [rsp], xmm0
000071e7f4ddb3da  vmovaps [rsp+0x10], xmm1
000071e7f4ddb3e0  vmovaps [rsp+0x20], xmm2
000071e7f4ddb3e6  vmovaps [rsp+0x30], xmm3
000071e7f4ddb3ec  vmovaps [rsp+0x40], xmm4
000071e7f4ddb3f2  vmovaps [rsp+0x50], xmm5
000071e7f4ddb3f8  vmovaps [rsp+0x60], xmm6
000071e7f4ddb3fe  vmovaps [rsp+0x70], xmm7
000071e7f4ddb404  vmovaps [rsp+0x80], xmm8
000071e7f4ddb40d  vmovaps [rsp+0x90], xmm9
000071e7f4ddb416  vmovaps [rsp+0xA0], xmm10
000071e7f4ddb41f  vmovaps [rsp+0xB0], xmm11
000071e7f4ddb428  vmovaps [rsp+0xC0], xmm12
000071e7f4ddb431  vmovaps [rsp+0xD0], xmm13
000071e7f4ddb43a  vmovaps [rsp+0xE0], xmm14
000071e7f4ddb443  sub rsp, 0x30
000071e7f4ddb447  movaps [rsp], xmm15
000071e7f4ddb44c  movaps [rsp+0x10], xmm11
000071e7f4ddb452  movaps [rsp+0x20], xmm12
000071e7f4ddb458  lea rdi, [rsp]
000071e7f4ddb45c  mov esi, 0x00
000071e7f4ddb461  mov rax, 0x562A51E82530
000071e7f4ddb46b  call rax
000071e7f4ddb46d  movaps xmm15, [rsp]
000071e7f4ddb472  add rsp, 0x30
000071e7f4ddb476  vmovaps xmm0, [rsp]
000071e7f4ddb47b  vmovaps xmm1, [rsp+0x10]
000071e7f4ddb481  vmovaps xmm2, [rsp+0x20]
000071e7f4ddb487  vmovaps xmm3, [rsp+0x30]
000071e7f4ddb48d  vmovaps xmm4, [rsp+0x40]
000071e7f4ddb493  vmovaps xmm5, [rsp+0x50]
000071e7f4ddb499  vmovaps xmm6, [rsp+0x60]
000071e7f4ddb49f  vmovaps xmm7, [rsp+0x70]
000071e7f4ddb4a5  vmovaps xmm8, [rsp+0x80]
000071e7f4ddb4ae  vmovaps xmm9, [rsp+0x90]
000071e7f4ddb4b7  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddb4c0  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddb4c9  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddb4d2  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddb4db  vmovaps xmm14, [rsp+0xE0]
000071e7f4ddb4e4  add rsp, 0xF0
000071e7f4ddb4eb  pop r11
000071e7f4ddb4ed  pop r10
000071e7f4ddb4ef  pop r9
000071e7f4ddb4f1  pop r8
000071e7f4ddb4f3  pop rsi
000071e7f4ddb4f4  pop rdi
000071e7f4ddb4f5  pop rdx
000071e7f4ddb4f6  pop rcx
000071e7f4ddb4f7  pop rax
000071e7f4ddb4f8  add rsp, 0x08
000071e7f4ddb4fc  jmp 0x000071E7F4DD664A
000071e7f4ddb501  sub rsp, 0x08
000071e7f4ddb505  push rax
000071e7f4ddb506  push rcx
000071e7f4ddb507  push rdx
000071e7f4ddb508  push rdi
000071e7f4ddb509  push rsi
000071e7f4ddb50a  push r8
000071e7f4ddb50c  push r9
000071e7f4ddb50e  push r10
000071e7f4ddb510  push r11
000071e7f4ddb512  sub rsp, 0xF0
000071e7f4ddb519  vmovaps [rsp], xmm0
000071e7f4ddb51e  vmovaps [rsp+0x10], xmm1
000071e7f4ddb524  vmovaps [rsp+0x20], xmm2
000071e7f4ddb52a  vmovaps [rsp+0x30], xmm3
000071e7f4ddb530  vmovaps [rsp+0x40], xmm4
000071e7f4ddb536  vmovaps [rsp+0x50], xmm5
000071e7f4ddb53c  vmovaps [rsp+0x60], xmm6
000071e7f4ddb542  vmovaps [rsp+0x70], xmm7
000071e7f4ddb548  vmovaps [rsp+0x80], xmm8
000071e7f4ddb551  vmovaps [rsp+0x90], xmm9
000071e7f4ddb55a  vmovaps [rsp+0xA0], xmm10
000071e7f4ddb563  vmovaps [rsp+0xB0], xmm11
000071e7f4ddb56c  vmovaps [rsp+0xC0], xmm12
000071e7f4ddb575  vmovaps [rsp+0xD0], xmm14
000071e7f4ddb57e  vmovaps [rsp+0xE0], xmm15
000071e7f4ddb587  sub rsp, 0x30
000071e7f4ddb58b  movaps [rsp], xmm13
000071e7f4ddb590  movaps [rsp+0x10], xmm10
000071e7f4ddb596  movaps [rsp+0x20], xmm14
000071e7f4ddb59c  lea rdi, [rsp]
000071e7f4ddb5a0  mov esi, 0x00
000071e7f4ddb5a5  mov rax, 0x562A51E82530
000071e7f4ddb5af  call rax
000071e7f4ddb5b1  movaps xmm13, [rsp]
000071e7f4ddb5b6  add rsp, 0x30
000071e7f4ddb5ba  vmovaps xmm0, [rsp]
000071e7f4ddb5bf  vmovaps xmm1, [rsp+0x10]
000071e7f4ddb5c5  vmovaps xmm2, [rsp+0x20]
000071e7f4ddb5cb  vmovaps xmm3, [rsp+0x30]
000071e7f4ddb5d1  vmovaps xmm4, [rsp+0x40]
000071e7f4ddb5d7  vmovaps xmm5, [rsp+0x50]
000071e7f4ddb5dd  vmovaps xmm6, [rsp+0x60]
000071e7f4ddb5e3  vmovaps xmm7, [rsp+0x70]
000071e7f4ddb5e9  vmovaps xmm8, [rsp+0x80]
000071e7f4ddb5f2  vmovaps xmm9, [rsp+0x90]
000071e7f4ddb5fb  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddb604  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddb60d  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddb616  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddb61f  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddb628  add rsp, 0xF0
000071e7f4ddb62f  pop r11
000071e7f4ddb631  pop r10
000071e7f4ddb633  pop r9
000071e7f4ddb635  pop r8
000071e7f4ddb637  pop rsi
000071e7f4ddb638  pop rdi
000071e7f4ddb639  pop rdx
000071e7f4ddb63a  pop rcx
000071e7f4ddb63b  pop rax
000071e7f4ddb63c  add rsp, 0x08
000071e7f4ddb640  jmp 0x000071E7F4DD666D
000071e7f4ddb645  sub rsp, 0x08
000071e7f4ddb649  push rax
000071e7f4ddb64a  push rcx
000071e7f4ddb64b  push rdx
000071e7f4ddb64c  push rdi
000071e7f4ddb64d  push rsi
000071e7f4ddb64e  push r8
000071e7f4ddb650  push r9
000071e7f4ddb652  push r10
000071e7f4ddb654  push r11
000071e7f4ddb656  sub rsp, 0xF0
000071e7f4ddb65d  vmovaps [rsp], xmm0
000071e7f4ddb662  vmovaps [rsp+0x10], xmm1
000071e7f4ddb668  vmovaps [rsp+0x20], xmm2
000071e7f4ddb66e  vmovaps [rsp+0x30], xmm3
000071e7f4ddb674  vmovaps [rsp+0x40], xmm4
000071e7f4ddb67a  vmovaps [rsp+0x50], xmm5
000071e7f4ddb680  vmovaps [rsp+0x60], xmm6
000071e7f4ddb686  vmovaps [rsp+0x70], xmm7
000071e7f4ddb68c  vmovaps [rsp+0x80], xmm8
000071e7f4ddb695  vmovaps [rsp+0x90], xmm9
000071e7f4ddb69e  vmovaps [rsp+0xA0], xmm10
000071e7f4ddb6a7  vmovaps [rsp+0xB0], xmm11
000071e7f4ddb6b0  vmovaps [rsp+0xC0], xmm12
000071e7f4ddb6b9  vmovaps [rsp+0xD0], xmm13
000071e7f4ddb6c2  vmovaps [rsp+0xE0], xmm15
000071e7f4ddb6cb  sub rsp, 0x30
000071e7f4ddb6cf  movaps [rsp], xmm14
000071e7f4ddb6d4  movaps [rsp+0x10], xmm1
000071e7f4ddb6d9  movaps [rsp+0x20], xmm7
000071e7f4ddb6de  lea rdi, [rsp]
000071e7f4ddb6e2  mov esi, 0x00
000071e7f4ddb6e7  mov rax, 0x562A51E82530
000071e7f4ddb6f1  call rax
000071e7f4ddb6f3  movaps xmm14, [rsp]
000071e7f4ddb6f8  add rsp, 0x30
000071e7f4ddb6fc  vmovaps xmm0, [rsp]
000071e7f4ddb701  vmovaps xmm1, [rsp+0x10]
000071e7f4ddb707  vmovaps xmm2, [rsp+0x20]
000071e7f4ddb70d  vmovaps xmm3, [rsp+0x30]
000071e7f4ddb713  vmovaps xmm4, [rsp+0x40]
000071e7f4ddb719  vmovaps xmm5, [rsp+0x50]
000071e7f4ddb71f  vmovaps xmm6, [rsp+0x60]
000071e7f4ddb725  vmovaps xmm7, [rsp+0x70]
000071e7f4ddb72b  vmovaps xmm8, [rsp+0x80]
000071e7f4ddb734  vmovaps xmm9, [rsp+0x90]
000071e7f4ddb73d  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddb746  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddb74f  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddb758  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddb761  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddb76a  add rsp, 0xF0
000071e7f4ddb771  pop r11
000071e7f4ddb773  pop r10
000071e7f4ddb775  pop r9
000071e7f4ddb777  pop r8
000071e7f4ddb779  pop rsi
000071e7f4ddb77a  pop rdi
000071e7f4ddb77b  pop rdx
000071e7f4ddb77c  pop rcx
000071e7f4ddb77d  pop rax
000071e7f4ddb77e  add rsp, 0x08
000071e7f4ddb782  jmp 0x000071E7F4DD6690
000071e7f4ddb787  sub rsp, 0x08
000071e7f4ddb78b  push rax
000071e7f4ddb78c  push rcx
000071e7f4ddb78d  push rdx
000071e7f4ddb78e  push rdi
000071e7f4ddb78f  push rsi
000071e7f4ddb790  push r8
000071e7f4ddb792  push r9
000071e7f4ddb794  push r10
000071e7f4ddb796  push r11
000071e7f4ddb798  sub rsp, 0xF0
000071e7f4ddb79f  vmovaps [rsp], xmm0
000071e7f4ddb7a4  vmovaps [rsp+0x10], xmm2
000071e7f4ddb7aa  vmovaps [rsp+0x20], xmm3
000071e7f4ddb7b0  vmovaps [rsp+0x30], xmm4
000071e7f4ddb7b6  vmovaps [rsp+0x40], xmm5
000071e7f4ddb7bc  vmovaps [rsp+0x50], xmm6
000071e7f4ddb7c2  vmovaps [rsp+0x60], xmm7
000071e7f4ddb7c8  vmovaps [rsp+0x70], xmm8
000071e7f4ddb7ce  vmovaps [rsp+0x80], xmm9
000071e7f4ddb7d7  vmovaps [rsp+0x90], xmm10
000071e7f4ddb7e0  vmovaps [rsp+0xA0], xmm11
000071e7f4ddb7e9  vmovaps [rsp+0xB0], xmm12
000071e7f4ddb7f2  vmovaps [rsp+0xC0], xmm13
000071e7f4ddb7fb  vmovaps [rsp+0xD0], xmm14
000071e7f4ddb804  vmovaps [rsp+0xE0], xmm15
000071e7f4ddb80d  sub rsp, 0x30
000071e7f4ddb811  movaps [rsp], xmm1
000071e7f4ddb815  movaps [rsp+0x10], xmm8
000071e7f4ddb81b  movaps [rsp+0x20], xmm9
000071e7f4ddb821  lea rdi, [rsp]
000071e7f4ddb825  mov esi, 0x00
000071e7f4ddb82a  mov rax, 0x562A51E82530
000071e7f4ddb834  call rax
000071e7f4ddb836  movaps xmm1, [rsp]
000071e7f4ddb83a  add rsp, 0x30
000071e7f4ddb83e  vmovaps xmm0, [rsp]
000071e7f4ddb843  vmovaps xmm2, [rsp+0x10]
000071e7f4ddb849  vmovaps xmm3, [rsp+0x20]
000071e7f4ddb84f  vmovaps xmm4, [rsp+0x30]
000071e7f4ddb855  vmovaps xmm5, [rsp+0x40]
000071e7f4ddb85b  vmovaps xmm6, [rsp+0x50]
000071e7f4ddb861  vmovaps xmm7, [rsp+0x60]
000071e7f4ddb867  vmovaps xmm8, [rsp+0x70]
000071e7f4ddb86d  vmovaps xmm9, [rsp+0x80]
000071e7f4ddb876  vmovaps xmm10, [rsp+0x90]
000071e7f4ddb87f  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddb888  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddb891  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddb89a  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddb8a3  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddb8ac  add rsp, 0xF0
000071e7f4ddb8b3  pop r11
000071e7f4ddb8b5  pop r10
000071e7f4ddb8b7  pop r9
000071e7f4ddb8b9  pop r8
000071e7f4ddb8bb  pop rsi
000071e7f4ddb8bc  pop rdi
000071e7f4ddb8bd  pop rdx
000071e7f4ddb8be  pop rcx
000071e7f4ddb8bf  pop rax
000071e7f4ddb8c0  add rsp, 0x08
000071e7f4ddb8c4  jmp 0x000071E7F4DD66B2
000071e7f4ddb8c9  call 0x000071E7F4CB3E40
000071e7f4ddb8ce  jmp 0x000071E7F4DD66C0
000071e7f4ddb8d3  call 0x000071E7F4C0C380
000071e7f4ddb8d8  jmp 0x000071E7F4DD66CA
000071e7f4ddb8dd  call 0x000071E7F4C0D600
000071e7f4ddb8e2  jmp 0x000071E7F4DD66D4
000071e7f4ddb8e7  call 0x000071E7F4BFF540
000071e7f4ddb8ec  jmp 0x000071E7F4DD66DE
000071e7f4ddb8f1  int3
000071e7f4ddb8f2  nop [rax+rax*1], ax
000071e7f4ddb8fb  nop [rax+rax*1], eax
000071e7f4ddb900  mov eax, [r15+0x48]
000071e7f4ddb904  lea r14d, [eax+0x01]
000071e7f4ddb909  mov [rsp+0x10], r14d
000071e7f4ddb90e  mov r14d, r14d
000071e7f4ddb911  mov [r15+0x48], r14
000071e7f4ddb915  xor eax, eax
000071e7f4ddb917  mov r14d, [rsp+0x10]
000071e7f4ddb91c  cmp r14d, 0x1F4
000071e7f4ddb923  cmc
000071e7f4ddb924  lahf
000071e7f4ddb925  seto al
000071e7f4ddb928  mov [r15+0x108], eax
000071e7f4ddb92f  mov eax, [r15+0x108]
000071e7f4ddb936  sahf
000071e7f4ddb937  jnz 0x000071E7F4DDB969
000071e7f4ddb939  cmp dword ptr [r15+0x318], 0x00
000071e7f4ddb941  jz 0x000071E7F4DE1AB0
000071e7f4ddb947  nop [rax+rax*1], ax
000071e7f4ddb950  nop [rax+rax*1], eax
000071e7f4ddb958  mov eax, 0x410450
000071e7f4ddb95d  mov [r15+0x100], rax
000071e7f4ddb964  jmp 0x000071E7F4BFE110
000071e7f4ddb969  cmp dword ptr [r15+0x318], 0x00
000071e7f4ddb971  jz 0x000071E7F4DDB9A0
000071e7f4ddb977  nop [rax+rax*1], ax
000071e7f4ddb980  nop [rax+rax*1], eax
000071e7f4ddb988  mov eax, 0x410274
000071e7f4ddb98d  mov [r15+0x100], rax
000071e7f4ddb994  jmp 0x000071E7F4BFE110
000071e7f4ddb999  int3
000071e7f4ddb99a  int3
000071e7f4ddb99b  nop [rax+rax*1], eax
000071e7f4ddb9a0  mov rax, [r15+0x40]
000071e7f4ddb9a4  movaps xmm1, [r15+0x1D0]
000071e7f4ddb9ac  vmovaps [rsp+0x10], xmm1
000071e7f4ddb9b2  vmovaps xmm15, [rsp+0x10]
000071e7f4ddb9b8  por xmm1, xmm15
000071e7f4ddb9bd  movaps xmm14, [r15+0x1A0]
000071e7f4ddb9c5  vmovaps [rsp+0x10], xmm14
000071e7f4ddb9cb  vmovaps xmm13, [rsp+0x10]
000071e7f4ddb9d1  por xmm14, xmm13
000071e7f4ddb9d6  lea r14, [rax+0x30]
000071e7f4ddb9da  mov r12, [r13+r14*1]
000071e7f4ddb9df  lea r14, [rax+0x38]
000071e7f4ddb9e3  mov r11, [r13+r14*1]
000071e7f4ddb9e8  movq xmm13, r12
000071e7f4ddb9ed  movq xmm12, r11
000071e7f4ddb9f2  movq xmm13, xmm13
000071e7f4ddb9f7  vmovaps [rsp+0x10], xmm13
000071e7f4ddb9fd  movq xmm13, xmm13
000071e7f4ddba02  movaps [r15+0x130], xmm13
000071e7f4ddba0a  movq xmm12, xmm12
000071e7f4ddba0f  vmovaps [rsp+0x20], xmm12
000071e7f4ddba15  movq xmm12, xmm12
000071e7f4ddba1a  movaps [r15+0x280], xmm12
000071e7f4ddba22  movaps xmm13, [r15+0x270]
000071e7f4ddba2a  vmovaps [rsp+0x30], xmm13
000071e7f4ddba30  vmovaps xmm12, [rsp+0x30]
000071e7f4ddba36  por xmm13, xmm12
000071e7f4ddba3b  lea r14, [rax+0x20]
000071e7f4ddba3f  mov r12, [r13+r14*1]
000071e7f4ddba44  lea r14, [rax+0x28]
000071e7f4ddba48  mov r11, [r13+r14*1]
000071e7f4ddba4d  movq xmm12, r12
000071e7f4ddba52  movq xmm11, r11
000071e7f4ddba57  movq xmm12, xmm12
000071e7f4ddba5c  vmovaps [rsp+0x30], xmm12
000071e7f4ddba62  movq xmm12, xmm12
000071e7f4ddba67  movaps [r15+0x150], xmm12
000071e7f4ddba6f  movq xmm11, xmm11
000071e7f4ddba74  vmovaps [rsp+0x40], xmm11
000071e7f4ddba7a  movq xmm11, xmm11
000071e7f4ddba7f  movaps [r15+0x140], xmm11
000071e7f4ddba87  lea r14, [rax+0x10]
000071e7f4ddba8b  mov r12, [r13+r14*1]
000071e7f4ddba90  lea r14, [rax+0x18]
000071e7f4ddba94  mov r11, [r13+r14*1]
000071e7f4ddba99  movq xmm12, r12
000071e7f4ddba9e  movq xmm11, r11
000071e7f4ddbaa3  movq xmm12, xmm12
000071e7f4ddbaa8  vmovaps [rsp+0x50], xmm12
000071e7f4ddbaae  movq xmm12, xmm12
000071e7f4ddbab3  movaps [r15+0x170], xmm12
000071e7f4ddbabb  movq xmm11, xmm11
000071e7f4ddbac0  vmovaps [rsp+0x60], xmm11
000071e7f4ddbac6  movq xmm11, xmm11
000071e7f4ddbacb  movaps [r15+0x160], xmm11
000071e7f4ddbad3  mov r14, [r13+rax*1]
000071e7f4ddbad8  vmovq xmm12, r14
000071e7f4ddbadd  vpbroadcastq xmm12, xmm12
000071e7f4ddbae2  lea r14, [rax+0x08]
000071e7f4ddbae6  mov rax, [r13+r14*1]
000071e7f4ddbaeb  movq xmm11, rax
000071e7f4ddbaf0  movaps [r15+0x230], xmm11
000071e7f4ddbaf8  mov rax, [r15+0xF8]
000071e7f4ddbaff  lea r14, [rax+0x50]
000071e7f4ddbb03  movups xmm11, [r13+r14*1]
000071e7f4ddbb09  lea r14, [rax+0x60]
000071e7f4ddbb0d  movups xmm10, [r13+r14*1]
000071e7f4ddbb13  lea r14, [rax+0x30]
000071e7f4ddbb17  movups xmm9, [r13+r14*1]
000071e7f4ddbb1d  mov r14, [r15+0x50]
000071e7f4ddbb21  mov [r15+0x60], r14
000071e7f4ddbb25  mov qword ptr [r15+0x58], 0x40
000071e7f4ddbb2d  movaps xmm8, xmm12
000071e7f4ddbb31  mulpd xmm8, xmm15
000071e7f4ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000071e7f4ddbb3c  ptest xmm7, xmm7
000071e7f4ddbb41  jnz 0x000071E7F4DDC96A
000071e7f4ddbb47  movq xmm15, qword ptr [r15+0x230]
000071e7f4ddbb50  vmovaps [rsp+0x70], xmm15
000071e7f4ddbb56  vpermilpd xmm15, xmm15, 0x00
000071e7f4ddbb5c  movaps xmm7, xmm9
000071e7f4ddbb60  mulpd xmm7, xmm15
000071e7f4ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000071e7f4ddbb6a  ptest xmm6, xmm6
000071e7f4ddbb6f  jnz 0x000071E7F4DDCAAE
000071e7f4ddbb75  vxorps xmm15, xmm15, xmm15
000071e7f4ddbb7a  vpbroadcastq xmm15, xmm15
000071e7f4ddbb7f  movaps xmm9, xmm12
000071e7f4ddbb83  mulpd xmm9, xmm10
000071e7f4ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000071e7f4ddbb8e  ptest xmm6, xmm6
000071e7f4ddbb93  jnz 0x000071E7F4DDCBF0
000071e7f4ddbb99  movaps xmm10, xmm12
000071e7f4ddbb9d  mulpd xmm10, xmm11
000071e7f4ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000071e7f4ddbba8  ptest xmm6, xmm6
000071e7f4ddbbad  jnz 0x000071E7F4DDCD34
000071e7f4ddbbb3  movaps xmm11, [r15+0x1F0]
000071e7f4ddbbbb  movaps xmm6, xmm12
000071e7f4ddbbbf  mulpd xmm6, xmm11
000071e7f4ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000071e7f4ddbbc9  ptest xmm5, xmm5
000071e7f4ddbbce  jnz 0x000071E7F4DDCE78
000071e7f4ddbbd4  movaps xmm12, [r15+0x2A0]
000071e7f4ddbbdc  vmovaps [rsp+0x80], xmm12
000071e7f4ddbbe5  vmovaps xmm11, [rsp+0x80]
000071e7f4ddbbee  por xmm12, xmm11
000071e7f4ddbbf3  movaps xmm11, [r15+0x250]
000071e7f4ddbbfb  vmovaps [rsp+0x80], xmm11
000071e7f4ddbc04  vmovaps xmm5, [rsp+0x80]
000071e7f4ddbc0d  por xmm11, xmm5
000071e7f4ddbc12  vmovaps xmm4, [rsp+0x70]
000071e7f4ddbc18  vpermilpd xmm4, xmm4, 0x00
000071e7f4ddbc1e  movaps xmm3, xmm5
000071e7f4ddbc21  mulpd xmm3, xmm4
000071e7f4ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000071e7f4ddbc2a  ptest xmm2, xmm2
000071e7f4ddbc2f  jnz 0x000071E7F4DDCFBA
000071e7f4ddbc35  mov [rsp+0x80], rax
000071e7f4ddbc3d  xor eax, eax
000071e7f4ddbc3f  mov r12d, 0x40
000071e7f4ddbc45  mov r11d, 0x200
000071e7f4ddbc4b  cmp r12, r11
000071e7f4ddbc4e  cmc
000071e7f4ddbc4f  lahf
000071e7f4ddbc50  seto al
000071e7f4ddbc53  mov [r15+0x108], eax
000071e7f4ddbc5a  movaps xmm5, xmm8
000071e7f4ddbc5e  addpd xmm5, xmm15
000071e7f4ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000071e7f4ddbc68  ptest xmm4, xmm4
000071e7f4ddbc6d  jnz 0x000071E7F4DDD0FA
000071e7f4ddbc73  movaps xmm8, [r15+0x1B0]
000071e7f4ddbc7b  movaps xmm4, xmm9
000071e7f4ddbc7f  addpd xmm4, xmm8
000071e7f4ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000071e7f4ddbc89  ptest xmm2, xmm2
000071e7f4ddbc8e  jnz 0x000071E7F4DDD23C
000071e7f4ddbc94  movaps xmm9, xmm10
000071e7f4ddbc98  addpd xmm9, xmm8
000071e7f4ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000071e7f4ddbca3  ptest xmm2, xmm2
000071e7f4ddbca8  jnz 0x000071E7F4DDD37E
000071e7f4ddbcae  movaps xmm10, [r15+0x2F0]
000071e7f4ddbcb6  vmovaps [rsp+0x90], xmm10
000071e7f4ddbcbf  vmovaps xmm8, [rsp+0x90]
000071e7f4ddbcc8  por xmm10, xmm8
000071e7f4ddbccd  movaps xmm8, [r15+0x2E0]
000071e7f4ddbcd5  vmovaps [rsp+0x90], xmm8
000071e7f4ddbcde  vmovaps xmm2, [rsp+0x90]
000071e7f4ddbce7  por xmm8, xmm2
000071e7f4ddbcec  movaps xmm2, [r15+0x2D0]
000071e7f4ddbcf4  vmovaps [rsp+0x90], xmm2
000071e7f4ddbcfd  vmovaps [rsp+0xA0], xmm1
000071e7f4ddbd06  vmovaps xmm1, [rsp+0x90]
000071e7f4ddbd0f  por xmm2, xmm1
000071e7f4ddbd13  movaps xmm1, [r15+0x200]
000071e7f4ddbd1b  vmovaps [rsp+0x90], xmm1
000071e7f4ddbd24  vmovaps [rsp+0xB0], xmm15
000071e7f4ddbd2d  vmovaps xmm15, [rsp+0x90]
000071e7f4ddbd36  por xmm1, xmm15
000071e7f4ddbd3b  movaps xmm15, [r15+0x1C0]
000071e7f4ddbd43  vmovaps [rsp+0x90], xmm15
000071e7f4ddbd4c  vmovaps [rsp+0xC0], xmm1
000071e7f4ddbd55  vmovaps xmm1, [rsp+0x90]
000071e7f4ddbd5e  por xmm15, xmm1
000071e7f4ddbd63  movaps xmm1, [r15+0x190]
000071e7f4ddbd6b  vmovaps [rsp+0x90], xmm1
000071e7f4ddbd74  vmovaps [rsp+0xD0], xmm15
000071e7f4ddbd7d  vmovaps xmm15, [rsp+0x90]
000071e7f4ddbd86  por xmm1, xmm15
000071e7f4ddbd8b  movaps xmm15, [r15+0x300]
000071e7f4ddbd93  vmovaps [rsp+0x90], xmm15
000071e7f4ddbd9c  vmovaps [rsp+0xE0], xmm1
000071e7f4ddbda5  vmovaps xmm1, [rsp+0x90]
000071e7f4ddbdae  por xmm15, xmm1
000071e7f4ddbdb3  mov rax, [rsp+0x80]
000071e7f4ddbdbb  lea r12, [rax+0xA0]
000071e7f4ddbdc2  movups xmm1, [r13+r12*1]
000071e7f4ddbdc8  lea r12, [rax+0xB0]
000071e7f4ddbdcf  vmovaps [rsp+0x80], xmm1
000071e7f4ddbdd8  movups xmm1, [r13+r12*1]
000071e7f4ddbdde  vmovaps [rsp+0x90], xmm1
000071e7f4ddbde7  vmovaps [rsp+0xF0], xmm15
000071e7f4ddbdf0  vmovaps xmm15, [rsp+0xB0]
000071e7f4ddbdf9  vmovaps [rsp+0xB0], xmm14
000071e7f4ddbe02  movaps xmm1, xmm6
000071e7f4ddbe05  addpd xmm1, xmm15
000071e7f4ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000071e7f4ddbe0f  ptest xmm14, xmm14
000071e7f4ddbe15  jnz 0x000071E7F4DDD4D6
000071e7f4ddbe1b  lea r12, [rax+0xF0]
000071e7f4ddbe22  movups xmm15, [r13+r12*1]
000071e7f4ddbe28  movaps xmm14, xmm4
000071e7f4ddbe2c  addpd xmm14, xmm3
000071e7f4ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000071e7f4ddbe37  ptest xmm6, xmm6
000071e7f4ddbe3c  jnz 0x000071E7F4DDD621
000071e7f4ddbe42  movaps xmm6, xmm9
000071e7f4ddbe46  addpd xmm6, xmm7
000071e7f4ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000071e7f4ddbe4f  ptest xmm4, xmm4
000071e7f4ddbe54  jnz 0x000071E7F4DDD763
000071e7f4ddbe5a  vmovaps xmm9, [rsp+0x70]
000071e7f4ddbe60  vpermilpd xmm9, xmm9, 0x00
000071e7f4ddbe66  vmovaps xmm4, [rsp+0x90]
000071e7f4ddbe6f  movaps xmm7, xmm4
000071e7f4ddbe72  mulpd xmm7, xmm9
000071e7f4ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000071e7f4ddbe7c  ptest xmm3, xmm3
000071e7f4ddbe81  jnz 0x000071E7F4DDD8A4
000071e7f4ddbe87  vmovaps xmm9, [rsp+0x50]
000071e7f4ddbe8d  vpermilpd xmm9, xmm9, 0x00
000071e7f4ddbe93  movaps xmm4, xmm15
000071e7f4ddbe97  mulpd xmm4, xmm9
000071e7f4ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000071e7f4ddbea1  ptest xmm3, xmm3
000071e7f4ddbea6  jnz 0x000071E7F4DDD9E5
000071e7f4ddbeac  lea r12, [rax+0xE0]
000071e7f4ddbeb3  movups xmm15, [r13+r12*1]
000071e7f4ddbeb9  vmovaps xmm9, [rsp+0x70]
000071e7f4ddbebf  vpermilpd xmm9, xmm9, 0x00
000071e7f4ddbec5  vmovaps [rsp+0x70], xmm1
000071e7f4ddbecb  vmovaps xmm1, [rsp+0x80]
000071e7f4ddbed4  vmovaps [rsp+0x80], xmm15
000071e7f4ddbedd  movaps xmm3, xmm1
000071e7f4ddbee0  mulpd xmm3, xmm9
000071e7f4ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000071e7f4ddbeea  ptest xmm15, xmm15
000071e7f4ddbef0  jnz 0x000071E7F4DDDB31
000071e7f4ddbef6  vmovaps xmm1, [rsp+0xF0]
000071e7f4ddbeff  vmovaps xmm15, [rsp+0xF0]
000071e7f4ddbf08  por xmm1, xmm15
000071e7f4ddbf0d  movaps [r15+0x300], xmm1
000071e7f4ddbf15  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddbf1e  vmovaps xmm9, [rsp+0xE0]
000071e7f4ddbf27  por xmm15, xmm9
000071e7f4ddbf2c  movaps [r15+0x190], xmm15
000071e7f4ddbf34  vmovaps xmm9, [rsp+0x50]
000071e7f4ddbf3a  vpermilpd xmm9, xmm9, 0x00
000071e7f4ddbf40  vmovaps [rsp+0x90], xmm1
000071e7f4ddbf49  vmovaps [rsp+0xE0], xmm15
000071e7f4ddbf52  vmovaps xmm15, [rsp+0x80]
000071e7f4ddbf5b  vmovaps [rsp+0x80], xmm14
000071e7f4ddbf64  movaps xmm1, xmm15
000071e7f4ddbf68  mulpd xmm1, xmm9
000071e7f4ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000071e7f4ddbf72  ptest xmm14, xmm14
000071e7f4ddbf78  jnz 0x000071E7F4DDDC72
000071e7f4ddbf7e  lea r12, [rax+0x90]
000071e7f4ddbf85  movups xmm15, [r13+r12*1]
000071e7f4ddbf8b  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddbf94  vmovaps xmm9, [rsp+0xD0]
000071e7f4ddbf9d  por xmm14, xmm9
000071e7f4ddbfa2  movaps [r15+0x1C0], xmm14
000071e7f4ddbfaa  vmovaps xmm9, [rsp+0xC0]
000071e7f4ddbfb3  vmovaps [rsp+0xD0], xmm1
000071e7f4ddbfbc  vmovaps xmm1, [rsp+0xC0]
000071e7f4ddbfc5  por xmm9, xmm1
000071e7f4ddbfca  movaps [r15+0x200], xmm9
000071e7f4ddbfd2  vmovaps [rsp+0xC0], xmm2
000071e7f4ddbfdb  vmovaps xmm1, [rsp+0xC0]
000071e7f4ddbfe4  por xmm2, xmm1
000071e7f4ddbfe8  movaps [r15+0x2D0], xmm2
000071e7f4ddbff0  vmovaps [rsp+0xC0], xmm8
000071e7f4ddbff9  vmovaps xmm1, [rsp+0xC0]
000071e7f4ddc002  por xmm8, xmm1
000071e7f4ddc007  movaps [r15+0x2E0], xmm8
000071e7f4ddc00f  vmovaps [rsp+0xC0], xmm15
000071e7f4ddc018  movaps xmm1, xmm5
000071e7f4ddc01b  addpd xmm1, xmm7
000071e7f4ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000071e7f4ddc024  ptest xmm15, xmm15
000071e7f4ddc02a  jnz 0x000071E7F4DDDDBE
000071e7f4ddc030  vmovaps xmm15, [rsp+0x50]
000071e7f4ddc036  vpermilpd xmm15, xmm15, 0x00
000071e7f4ddc03c  vmovaps xmm5, [rsp+0xC0]
000071e7f4ddc045  vmovaps [rsp+0xC0], xmm1
000071e7f4ddc04e  movaps xmm7, xmm5
000071e7f4ddc051  mulpd xmm7, xmm15
000071e7f4ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000071e7f4ddc05b  ptest xmm1, xmm1
000071e7f4ddc060  jnz 0x000071E7F4DDDEFE
000071e7f4ddc066  lea r12, [rax+0x80]
000071e7f4ddc06d  movups xmm1, [r13+r12*1]
000071e7f4ddc073  vmovaps xmm5, [rsp+0x70]
000071e7f4ddc079  vmovaps [rsp+0x70], xmm1
000071e7f4ddc07f  movaps xmm15, xmm5
000071e7f4ddc083  addpd xmm15, xmm3
000071e7f4ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000071e7f4ddc08e  ptest xmm1, xmm1
000071e7f4ddc093  jnz 0x000071E7F4DDE049
000071e7f4ddc099  vmovaps xmm5, [rsp+0x80]
000071e7f4ddc0a2  movaps xmm1, xmm5
000071e7f4ddc0a5  addpd xmm1, xmm4
000071e7f4ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000071e7f4ddc0ae  ptest xmm3, xmm3
000071e7f4ddc0b3  jnz 0x000071E7F4DDE18B
000071e7f4ddc0b9  vmovaps [rsp+0x80], xmm10
000071e7f4ddc0c2  vmovaps xmm5, [rsp+0x80]
000071e7f4ddc0cb  por xmm10, xmm5
000071e7f4ddc0d0  movaps [r15+0x2F0], xmm10
000071e7f4ddc0d8  vmovaps xmm5, [rsp+0x50]
000071e7f4ddc0de  vpermilpd xmm5, xmm5, 0x00
000071e7f4ddc0e4  vmovaps xmm3, [rsp+0x70]
000071e7f4ddc0ea  vmovaps [rsp+0x50], xmm1
000071e7f4ddc0f0  movaps xmm4, xmm3
000071e7f4ddc0f3  mulpd xmm4, xmm5
000071e7f4ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000071e7f4ddc0fc  ptest xmm1, xmm1
000071e7f4ddc101  jnz 0x000071E7F4DDE2CB
000071e7f4ddc107  lea r12, [rax+0xD0]
000071e7f4ddc10e  movups xmm1, [r13+r12*1]
000071e7f4ddc114  vmovaps xmm3, [rsp+0xD0]
000071e7f4ddc11d  vmovaps [rsp+0x70], xmm1
000071e7f4ddc123  movaps xmm5, xmm6
000071e7f4ddc126  addpd xmm5, xmm3
000071e7f4ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000071e7f4ddc12f  ptest xmm1, xmm1
000071e7f4ddc134  jnz 0x000071E7F4DDE415
000071e7f4ddc13a  vmovaps xmm1, [rsp+0x60]
000071e7f4ddc140  vpermilpd xmm1, xmm1, 0x00
000071e7f4ddc146  movaps xmm6, xmm9
000071e7f4ddc14a  mulpd xmm6, xmm1
000071e7f4ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000071e7f4ddc153  ptest xmm3, xmm3
000071e7f4ddc158  jnz 0x000071E7F4DDE555
000071e7f4ddc15e  movaps [r15+0x260], xmm6
000071e7f4ddc166  vxorps xmm1, xmm1, xmm1
000071e7f4ddc16a  vpbroadcastq xmm1, xmm1
000071e7f4ddc16f  movaps [r15+0x1B0], xmm1
000071e7f4ddc177  vmovaps xmm1, [rsp+0x60]
000071e7f4ddc17d  vpermilpd xmm1, xmm1, 0x00
000071e7f4ddc183  vmovaps xmm3, [rsp+0x70]
000071e7f4ddc189  vmovaps [rsp+0x70], xmm15
000071e7f4ddc18f  movaps xmm9, xmm3
000071e7f4ddc193  mulpd xmm9, xmm1
000071e7f4ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000071e7f4ddc19e  ptest xmm15, xmm15
000071e7f4ddc1a4  jnz 0x000071E7F4DDE696
000071e7f4ddc1aa  lea r12, [rax+0xC0]
000071e7f4ddc1b1  movups xmm1, [r13+r12*1]
000071e7f4ddc1b7  vmovaps xmm3, [rsp+0xC0]
000071e7f4ddc1c0  vmovaps [rsp+0x80], xmm1
000071e7f4ddc1c9  movaps xmm15, xmm3
000071e7f4ddc1cd  addpd xmm15, xmm7
000071e7f4ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000071e7f4ddc1d8  ptest xmm1, xmm1
000071e7f4ddc1dd  jnz 0x000071E7F4DDE7E2
000071e7f4ddc1e3  vmovaps [rsp+0xC0], xmm13
000071e7f4ddc1ec  vmovaps xmm1, [rsp+0xC0]
000071e7f4ddc1f5  por xmm13, xmm1
000071e7f4ddc1fa  movaps [r15+0x270], xmm13
000071e7f4ddc202  vmovaps xmm1, [rsp+0xB0]
000071e7f4ddc20b  vmovaps xmm7, [rsp+0xB0]
000071e7f4ddc214  por xmm1, xmm7
000071e7f4ddc218  movaps [r15+0x1A0], xmm1
000071e7f4ddc220  vmovaps xmm1, [rsp+0x60]
000071e7f4ddc226  vpermilpd xmm1, xmm1, 0x00
000071e7f4ddc22c  vmovaps [rsp+0xB0], xmm1
000071e7f4ddc235  vmovaps xmm1, [rsp+0x80]
000071e7f4ddc23e  vmovaps [rsp+0x80], xmm15
000071e7f4ddc247  vmovaps xmm15, [rsp+0xB0]
000071e7f4ddc250  vmovaps [rsp+0xB0], xmm14
000071e7f4ddc259  movaps xmm3, xmm1
000071e7f4ddc25c  mulpd xmm3, xmm15
000071e7f4ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000071e7f4ddc266  ptest xmm14, xmm14
000071e7f4ddc26c  jnz 0x000071E7F4DDE924
000071e7f4ddc272  lea r12, [rax+0x20]
000071e7f4ddc276  movups xmm1, [r13+r12*1]
000071e7f4ddc27c  movaps [r15+0x110], xmm1
000071e7f4ddc284  vmovaps xmm14, [rsp+0x70]
000071e7f4ddc28a  vmovaps [rsp+0x70], xmm1
000071e7f4ddc290  movaps xmm15, xmm14
000071e7f4ddc294  addpd xmm15, xmm4
000071e7f4ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000071e7f4ddc29f  ptest xmm1, xmm1
000071e7f4ddc2a4  jnz 0x000071E7F4DDEA6F
000071e7f4ddc2aa  vmovaps xmm1, [rsp+0x60]
000071e7f4ddc2b0  vpermilpd xmm1, xmm1, 0x00
000071e7f4ddc2b6  movaps xmm14, xmm2
000071e7f4ddc2ba  mulpd xmm14, xmm1
000071e7f4ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000071e7f4ddc2c5  ptest xmm4, xmm4
000071e7f4ddc2ca  jnz 0x000071E7F4DDEBB2
000071e7f4ddc2d0  vmovaps xmm4, [rsp+0x50]
000071e7f4ddc2d6  movaps xmm1, xmm4
000071e7f4ddc2d9  addpd xmm1, xmm9
000071e7f4ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000071e7f4ddc2e3  ptest xmm2, xmm2
000071e7f4ddc2e8  jnz 0x000071E7F4DDECF4
000071e7f4ddc2ee  vmovaps xmm9, [rsp+0x30]
000071e7f4ddc2f4  vpermilpd xmm9, xmm9, 0x00
000071e7f4ddc2fa  vmovaps xmm2, [rsp+0x70]
000071e7f4ddc300  vmovaps [rsp+0x50], xmm1
000071e7f4ddc306  movaps xmm4, xmm2
000071e7f4ddc309  mulpd xmm4, xmm9
000071e7f4ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000071e7f4ddc313  ptest xmm1, xmm1
000071e7f4ddc318  jnz 0x000071E7F4DDEE35
000071e7f4ddc31e  vmovaps xmm1, [rsp+0x30]
000071e7f4ddc324  vpermilpd xmm1, xmm1, 0x00
000071e7f4ddc32a  vmovaps xmm2, [rsp+0x90]
000071e7f4ddc333  vmovaps [rsp+0x60], xmm15
000071e7f4ddc339  movaps xmm9, xmm2
000071e7f4ddc33d  mulpd xmm9, xmm1
000071e7f4ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000071e7f4ddc348  ptest xmm15, xmm15
000071e7f4ddc34e  jnz 0x000071E7F4DDEF76
000071e7f4ddc354  vmovaps xmm15, [rsp+0x80]
000071e7f4ddc35d  movaps xmm1, xmm15
000071e7f4ddc361  addpd xmm1, xmm6
000071e7f4ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000071e7f4ddc36a  ptest xmm2, xmm2
000071e7f4ddc36f  jnz 0x000071E7F4DDF0B8
000071e7f4ddc375  movaps xmm15, xmm5
000071e7f4ddc379  addpd xmm15, xmm3
000071e7f4ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000071e7f4ddc384  ptest xmm6, xmm6
000071e7f4ddc389  jnz 0x000071E7F4DDF1F9
000071e7f4ddc38f  vmovaps xmm6, [rsp+0x30]
000071e7f4ddc395  vpermilpd xmm6, xmm6, 0x00
000071e7f4ddc39b  movaps xmm5, xmm8
000071e7f4ddc39f  mulpd xmm5, xmm6
000071e7f4ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000071e7f4ddc3a8  ptest xmm3, xmm3
000071e7f4ddc3ad  jnz 0x000071E7F4DDF33B
000071e7f4ddc3b3  vmovaps xmm8, [rsp+0x30]
000071e7f4ddc3b9  vpermilpd xmm8, xmm8, 0x00
000071e7f4ddc3bf  movaps xmm6, xmm10
000071e7f4ddc3c3  mulpd xmm6, xmm8
000071e7f4ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000071e7f4ddc3cd  ptest xmm3, xmm3
000071e7f4ddc3d2  jnz 0x000071E7F4DDF47C
000071e7f4ddc3d8  vmovaps xmm8, [rsp+0x60]
000071e7f4ddc3de  movaps xmm10, xmm8
000071e7f4ddc3e2  addpd xmm10, xmm14
000071e7f4ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000071e7f4ddc3ed  ptest xmm3, xmm3
000071e7f4ddc3f2  jnz 0x000071E7F4DDF5BE
000071e7f4ddc3f8  vmovaps xmm8, [rsp+0x50]
000071e7f4ddc3fe  movaps xmm14, xmm8
000071e7f4ddc402  addpd xmm14, xmm4
000071e7f4ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000071e7f4ddc40d  ptest xmm3, xmm3
000071e7f4ddc412  jnz 0x000071E7F4DDF702
000071e7f4ddc418  vmovaps xmm8, [rsp+0x40]
000071e7f4ddc41e  vpermilpd xmm8, xmm8, 0x00
000071e7f4ddc424  movaps xmm4, xmm13
000071e7f4ddc428  mulpd xmm4, xmm8
000071e7f4ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000071e7f4ddc432  ptest xmm3, xmm3
000071e7f4ddc437  jnz 0x000071E7F4DDF845
000071e7f4ddc43d  movaps xmm13, xmm15
000071e7f4ddc441  addpd xmm13, xmm9
000071e7f4ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000071e7f4ddc44c  ptest xmm8, xmm8
000071e7f4ddc452  jnz 0x000071E7F4DDF987
000071e7f4ddc458  movaps xmm15, xmm1
000071e7f4ddc45c  addpd xmm15, xmm5
000071e7f4ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000071e7f4ddc467  ptest xmm9, xmm9
000071e7f4ddc46d  jnz 0x000071E7F4DDFACB
000071e7f4ddc473  vmovaps [rsp+0x30], xmm11
000071e7f4ddc479  vmovaps xmm1, [rsp+0x30]
000071e7f4ddc47f  por xmm11, xmm1
000071e7f4ddc484  movaps [r15+0x250], xmm11
000071e7f4ddc48c  vmovaps [rsp+0x30], xmm12
000071e7f4ddc492  vmovaps xmm1, [rsp+0x30]
000071e7f4ddc498  por xmm12, xmm1
000071e7f4ddc49d  movaps [r15+0x2A0], xmm12
000071e7f4ddc4a5  vmovaps xmm1, [rsp+0xA0]
000071e7f4ddc4ae  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddc4b7  por xmm1, xmm11
000071e7f4ddc4bc  movaps [r15+0x1D0], xmm1
000071e7f4ddc4c4  lea r12, [rax+0x40]
000071e7f4ddc4c8  movups xmm1, [r13+r12*1]
000071e7f4ddc4ce  movaps [r15+0x2C0], xmm1
000071e7f4ddc4d6  vmovaps xmm11, [rsp+0x40]
000071e7f4ddc4dc  vpermilpd xmm11, xmm11, 0x00
000071e7f4ddc4e2  vmovaps xmm8, [rsp+0xE0]
000071e7f4ddc4eb  movaps xmm9, xmm8
000071e7f4ddc4ef  mulpd xmm9, xmm11
000071e7f4ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000071e7f4ddc4fa  ptest xmm5, xmm5
000071e7f4ddc4ff  jnz 0x000071E7F4DDFC17
000071e7f4ddc505  movaps xmm11, xmm10
000071e7f4ddc509  addpd xmm11, xmm6
000071e7f4ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000071e7f4ddc514  ptest xmm8, xmm8
000071e7f4ddc51a  jnz 0x000071E7F4DDFD5B
000071e7f4ddc520  movaps xmm10, xmm14
000071e7f4ddc524  addpd xmm10, xmm4
000071e7f4ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000071e7f4ddc52f  ptest xmm8, xmm8
000071e7f4ddc535  jnz 0x000071E7F4DDFE9E
000071e7f4ddc53b  vmovaps xmm14, [rsp+0x40]
000071e7f4ddc541  vpermilpd xmm14, xmm14, 0x00
000071e7f4ddc547  movaps xmm8, xmm1
000071e7f4ddc54b  mulpd xmm8, xmm14
000071e7f4ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000071e7f4ddc556  ptest xmm6, xmm6
000071e7f4ddc55b  jnz 0x000071E7F4DDFFE1
000071e7f4ddc561  movaps xmm1, [r15+0x2B0]
000071e7f4ddc569  vmovaps xmm14, [rsp+0x40]
000071e7f4ddc56f  vpermilpd xmm14, xmm14, 0x00
000071e7f4ddc575  movaps xmm6, xmm1
000071e7f4ddc578  mulpd xmm6, xmm14
000071e7f4ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000071e7f4ddc582  ptest xmm5, xmm5
000071e7f4ddc587  jnz 0x000071E7F4DE0124
000071e7f4ddc58d  vmovaps xmm1, [rsp+0x10]
000071e7f4ddc593  vpermilpd xmm1, xmm1, 0x00
000071e7f4ddc599  movaps xmm14, xmm12
000071e7f4ddc59d  mulpd xmm14, xmm1
000071e7f4ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000071e7f4ddc5a8  ptest xmm5, xmm5
000071e7f4ddc5ad  jnz 0x000071E7F4DE0265
000071e7f4ddc5b3  movaps xmm1, xmm13
000071e7f4ddc5b7  addpd xmm1, xmm9
000071e7f4ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000071e7f4ddc5c1  ptest xmm12, xmm12
000071e7f4ddc5c7  jnz 0x000071E7F4DE03A8
000071e7f4ddc5cd  vmovaps xmm13, [rsp+0x10]
000071e7f4ddc5d3  vpermilpd xmm13, xmm13, 0x00
000071e7f4ddc5d9  movaps xmm12, xmm7
000071e7f4ddc5dd  mulpd xmm12, xmm13
000071e7f4ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000071e7f4ddc5e8  ptest xmm9, xmm9
000071e7f4ddc5ee  jnz 0x000071E7F4DE04EA
000071e7f4ddc5f4  movaps xmm13, xmm15
000071e7f4ddc5f8  addpd xmm13, xmm8
000071e7f4ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000071e7f4ddc603  ptest xmm9, xmm9
000071e7f4ddc609  jnz 0x000071E7F4DE062D
000071e7f4ddc60f  movaps xmm15, [r15+0x290]
000071e7f4ddc617  vmovaps xmm9, [rsp+0x10]
000071e7f4ddc61d  vpermilpd xmm9, xmm9, 0x00
000071e7f4ddc623  movaps xmm8, xmm15
000071e7f4ddc627  mulpd xmm8, xmm9
000071e7f4ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000071e7f4ddc632  ptest xmm7, xmm7
000071e7f4ddc637  jnz 0x000071E7F4DE0771
000071e7f4ddc63d  movaps xmm15, xmm11
000071e7f4ddc641  addpd xmm15, xmm6
000071e7f4ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000071e7f4ddc64c  ptest xmm9, xmm9
000071e7f4ddc652  jnz 0x000071E7F4DE08B5
000071e7f4ddc658  movaps xmm11, [r15+0x1E0]
000071e7f4ddc660  vmovaps xmm9, [rsp+0x10]
000071e7f4ddc666  vpermilpd xmm9, xmm9, 0x00
000071e7f4ddc66c  movaps xmm7, xmm11
000071e7f4ddc670  mulpd xmm7, xmm9
000071e7f4ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000071e7f4ddc67a  ptest xmm6, xmm6
000071e7f4ddc67f  jnz 0x000071E7F4DE09F8
000071e7f4ddc685  movaps xmm11, xmm10
000071e7f4ddc689  addpd xmm11, xmm14
000071e7f4ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000071e7f4ddc694  ptest xmm9, xmm9
000071e7f4ddc69a  jnz 0x000071E7F4DE0B3A
000071e7f4ddc6a0  lea r12, [rax+0x70]
000071e7f4ddc6a4  movups xmm14, [r13+r12*1]
000071e7f4ddc6aa  movaps [r15+0x240], xmm14
000071e7f4ddc6b2  movaps xmm10, xmm1
000071e7f4ddc6b6  addpd xmm10, xmm12
000071e7f4ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000071e7f4ddc6c1  ptest xmm9, xmm9
000071e7f4ddc6c7  jnz 0x000071E7F4DE0C88
000071e7f4ddc6cd  movaps [r15+0x170], xmm10
000071e7f4ddc6d5  vmovaps xmm1, [rsp+0x20]
000071e7f4ddc6db  vpermilpd xmm1, xmm1, 0x00
000071e7f4ddc6e1  movaps xmm12, xmm14
000071e7f4ddc6e5  mulpd xmm12, xmm1
000071e7f4ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000071e7f4ddc6f0  ptest xmm9, xmm9
000071e7f4ddc6f6  jnz 0x000071E7F4DE0DCB
000071e7f4ddc6fc  vmovaps xmm1, [rsp+0x20]
000071e7f4ddc702  vpermilpd xmm1, xmm1, 0x00
000071e7f4ddc708  vmovaps xmm9, [rsp+0xB0]
000071e7f4ddc711  movaps xmm14, xmm9
000071e7f4ddc715  mulpd xmm14, xmm1
000071e7f4ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000071e7f4ddc720  ptest xmm6, xmm6
000071e7f4ddc725  jnz 0x000071E7F4DE0F0E
000071e7f4ddc72b  movaps [r15+0x180], xmm14
000071e7f4ddc733  movaps xmm1, xmm13
000071e7f4ddc737  addpd xmm1, xmm8
000071e7f4ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000071e7f4ddc741  ptest xmm9, xmm9
000071e7f4ddc747  jnz 0x000071E7F4DE1051
000071e7f4ddc74d  movaps [r15+0x210], xmm1
000071e7f4ddc755  movups xmm13, [r13+rax*1]
000071e7f4ddc75b  lea r12, [rax+0x10]
000071e7f4ddc75f  movups xmm9, [r13+r12*1]
000071e7f4ddc765  movaps [r15+0x230], xmm9
000071e7f4ddc76d  movaps xmm8, xmm15
000071e7f4ddc771  addpd xmm8, xmm7
000071e7f4ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000071e7f4ddc77c  ptest xmm6, xmm6
000071e7f4ddc781  jnz 0x000071E7F4DE11A7
000071e7f4ddc787  movaps [r15+0x130], xmm8
000071e7f4ddc78f  vmovaps xmm15, [rsp+0x20]
000071e7f4ddc795  vpermilpd xmm15, xmm15, 0x00
000071e7f4ddc79b  movaps xmm7, xmm9
000071e7f4ddc79f  mulpd xmm7, xmm15
000071e7f4ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000071e7f4ddc7a9  ptest xmm6, xmm6
000071e7f4ddc7ae  jnz 0x000071E7F4DE12EA
000071e7f4ddc7b4  movaps [r15+0x220], xmm7
000071e7f4ddc7bc  vmovaps xmm15, [rsp+0x20]
000071e7f4ddc7c2  vpermilpd xmm15, xmm15, 0x00
000071e7f4ddc7c8  movaps xmm9, xmm13
000071e7f4ddc7cc  mulpd xmm9, xmm15
000071e7f4ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000071e7f4ddc7d7  ptest xmm6, xmm6
000071e7f4ddc7dc  jnz 0x000071E7F4DE142C
000071e7f4ddc7e2  movaps xmm15, xmm11
000071e7f4ddc7e6  addpd xmm15, xmm12
000071e7f4ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000071e7f4ddc7f1  ptest xmm13, xmm13
000071e7f4ddc7f7  jnz 0x000071E7F4DE1570
000071e7f4ddc7fd  movaps [r15+0x140], xmm15
000071e7f4ddc805  movaps xmm13, xmm10
000071e7f4ddc809  addpd xmm13, xmm14
000071e7f4ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000071e7f4ddc814  ptest xmm12, xmm12
000071e7f4ddc81a  jnz 0x000071E7F4DE16B4
000071e7f4ddc820  movaps [r15+0x150], xmm13
000071e7f4ddc828  movaps xmm14, xmm1
000071e7f4ddc82c  addpd xmm14, xmm7
000071e7f4ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000071e7f4ddc837  ptest xmm12, xmm12
000071e7f4ddc83d  jnz 0x000071E7F4DE17F8
000071e7f4ddc843  movaps [r15+0x160], xmm14
000071e7f4ddc84b  movaps xmm1, xmm8
000071e7f4ddc84f  addpd xmm1, xmm9
000071e7f4ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000071e7f4ddc859  ptest xmm12, xmm12
000071e7f4ddc85f  jnz 0x000071E7F4DE193A
000071e7f4ddc865  movaps [r15+0x120], xmm1
000071e7f4ddc86d  movups [r13+r14*1], xmm15
000071e7f4ddc873  lea rax, [r14+0x10]
000071e7f4ddc877  movups [r13+rax*1], xmm13
000071e7f4ddc87d  lea rax, [r14+0x20]
000071e7f4ddc881  movups [r13+rax*1], xmm14
000071e7f4ddc887  lea rax, [r14+0x30]
000071e7f4ddc88b  movups [r13+rax*1], xmm1
000071e7f4ddc891  mov eax, [r15+0x108]
000071e7f4ddc898  sahf
000071e7f4ddc899  jnz 0x000071E7F4DDC8CB
000071e7f4ddc89b  cmp dword ptr [r15+0x318], 0x00
000071e7f4ddc8a3  jz 0x000071E7F4DDB900
000071e7f4ddc8a9  nop [rax+rax*1], ax
000071e7f4ddc8b2  nop [rax+rax*1], eax
000071e7f4ddc8ba  mov eax, 0x410444
000071e7f4ddc8bf  mov [r15+0x100], rax
000071e7f4ddc8c6  jmp 0x000071E7F4BFE110
000071e7f4ddc8cb  cmp dword ptr [r15+0x318], 0x00
000071e7f4ddc8d3  jz 0x000071E7F4DD57E0
000071e7f4ddc8d9  nop [rax+rax*1], ax
000071e7f4ddc8e2  nop [rax+rax*1], eax
000071e7f4ddc8ea  mov eax, 0x410278
000071e7f4ddc8ef  mov [r15+0x100], rax
000071e7f4ddc8f6  jmp 0x000071E7F4BFE110
000071e7f4ddc8fb  int3
000071e7f4ddc8fc  call 0x000071E7F4CE27E0
000071e7f4ddc901  jmp 0x000071E7F4DDB9DF
000071e7f4ddc906  call 0x000071E7F4CE1570
000071e7f4ddc90b  jmp 0x000071E7F4DDB9E8
000071e7f4ddc910  call 0x000071E7F4CE27E0
000071e7f4ddc915  jmp 0x000071E7F4DDBA44
000071e7f4ddc91a  call 0x000071E7F4CE1570
000071e7f4ddc91f  jmp 0x000071E7F4DDBA4D
000071e7f4ddc924  call 0x000071E7F4CE27E0
000071e7f4ddc929  jmp 0x000071E7F4DDBA90
000071e7f4ddc92e  call 0x000071E7F4CE1570
000071e7f4ddc933  jmp 0x000071E7F4DDBA99
000071e7f4ddc938  call 0x000071E7F4C0DC20
000071e7f4ddc93d  jmp 0x000071E7F4DDBAD8
000071e7f4ddc942  call 0x000071E7F4CD59C0
000071e7f4ddc947  jmp 0x000071E7F4DDBAEB
000071e7f4ddc94c  call 0x000071E7F4CE0E30
000071e7f4ddc951  jmp 0x000071E7F4DDBB09
000071e7f4ddc956  call 0x000071E7F4CDFBC0
000071e7f4ddc95b  jmp 0x000071E7F4DDBB13
000071e7f4ddc960  call 0x000071E7F4CDE950
000071e7f4ddc965  jmp 0x000071E7F4DDBB1D
000071e7f4ddc96a  sub rsp, 0x08
000071e7f4ddc96e  push rax
000071e7f4ddc96f  push rcx
000071e7f4ddc970  push rdx
000071e7f4ddc971  push rdi
000071e7f4ddc972  push rsi
000071e7f4ddc973  push r8
000071e7f4ddc975  push r9
000071e7f4ddc977  push r10
000071e7f4ddc979  push r11
000071e7f4ddc97b  sub rsp, 0xF0
000071e7f4ddc982  vmovaps [rsp], xmm0
000071e7f4ddc987  vmovaps [rsp+0x10], xmm1
000071e7f4ddc98d  vmovaps [rsp+0x20], xmm2
000071e7f4ddc993  vmovaps [rsp+0x30], xmm3
000071e7f4ddc999  vmovaps [rsp+0x40], xmm4
000071e7f4ddc99f  vmovaps [rsp+0x50], xmm5
000071e7f4ddc9a5  vmovaps [rsp+0x60], xmm6
000071e7f4ddc9ab  vmovaps [rsp+0x70], xmm7
000071e7f4ddc9b1  vmovaps [rsp+0x80], xmm9
000071e7f4ddc9ba  vmovaps [rsp+0x90], xmm10
000071e7f4ddc9c3  vmovaps [rsp+0xA0], xmm11
000071e7f4ddc9cc  vmovaps [rsp+0xB0], xmm12
000071e7f4ddc9d5  vmovaps [rsp+0xC0], xmm13
000071e7f4ddc9de  vmovaps [rsp+0xD0], xmm14
000071e7f4ddc9e7  vmovaps [rsp+0xE0], xmm15
000071e7f4ddc9f0  sub rsp, 0x30
000071e7f4ddc9f4  movaps [rsp], xmm8
000071e7f4ddc9f9  movaps [rsp+0x10], xmm12
000071e7f4ddc9ff  movaps [rsp+0x20], xmm15
000071e7f4ddca05  lea rdi, [rsp]
000071e7f4ddca09  mov esi, 0x00
000071e7f4ddca0e  mov rax, 0x562A51E82530
000071e7f4ddca18  call rax
000071e7f4ddca1a  movaps xmm8, [rsp]
000071e7f4ddca1f  add rsp, 0x30
000071e7f4ddca23  vmovaps xmm0, [rsp]
000071e7f4ddca28  vmovaps xmm1, [rsp+0x10]
000071e7f4ddca2e  vmovaps xmm2, [rsp+0x20]
000071e7f4ddca34  vmovaps xmm3, [rsp+0x30]
000071e7f4ddca3a  vmovaps xmm4, [rsp+0x40]
000071e7f4ddca40  vmovaps xmm5, [rsp+0x50]
000071e7f4ddca46  vmovaps xmm6, [rsp+0x60]
000071e7f4ddca4c  vmovaps xmm7, [rsp+0x70]
000071e7f4ddca52  vmovaps xmm9, [rsp+0x80]
000071e7f4ddca5b  vmovaps xmm10, [rsp+0x90]
000071e7f4ddca64  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddca6d  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddca76  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddca7f  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddca88  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddca91  add rsp, 0xF0
000071e7f4ddca98  pop r11
000071e7f4ddca9a  pop r10
000071e7f4ddca9c  pop r9
000071e7f4ddca9e  pop r8
000071e7f4ddcaa0  pop rsi
000071e7f4ddcaa1  pop rdi
000071e7f4ddcaa2  pop rdx
000071e7f4ddcaa3  pop rcx
000071e7f4ddcaa4  pop rax
000071e7f4ddcaa5  add rsp, 0x08
000071e7f4ddcaa9  jmp 0x000071E7F4DDBB47
000071e7f4ddcaae  sub rsp, 0x08
000071e7f4ddcab2  push rax
000071e7f4ddcab3  push rcx
000071e7f4ddcab4  push rdx
000071e7f4ddcab5  push rdi
000071e7f4ddcab6  push rsi
000071e7f4ddcab7  push r8
000071e7f4ddcab9  push r9
000071e7f4ddcabb  push r10
000071e7f4ddcabd  push r11
000071e7f4ddcabf  sub rsp, 0xF0
000071e7f4ddcac6  vmovaps [rsp], xmm0
000071e7f4ddcacb  vmovaps [rsp+0x10], xmm1
000071e7f4ddcad1  vmovaps [rsp+0x20], xmm2
000071e7f4ddcad7  vmovaps [rsp+0x30], xmm3
000071e7f4ddcadd  vmovaps [rsp+0x40], xmm4
000071e7f4ddcae3  vmovaps [rsp+0x50], xmm5
000071e7f4ddcae9  vmovaps [rsp+0x60], xmm6
000071e7f4ddcaef  vmovaps [rsp+0x70], xmm8
000071e7f4ddcaf5  vmovaps [rsp+0x80], xmm9
000071e7f4ddcafe  vmovaps [rsp+0x90], xmm10
000071e7f4ddcb07  vmovaps [rsp+0xA0], xmm11
000071e7f4ddcb10  vmovaps [rsp+0xB0], xmm12
000071e7f4ddcb19  vmovaps [rsp+0xC0], xmm13
000071e7f4ddcb22  vmovaps [rsp+0xD0], xmm14
000071e7f4ddcb2b  vmovaps [rsp+0xE0], xmm15
000071e7f4ddcb34  sub rsp, 0x30
000071e7f4ddcb38  movaps [rsp], xmm7
000071e7f4ddcb3c  movaps [rsp+0x10], xmm9
000071e7f4ddcb42  movaps [rsp+0x20], xmm15
000071e7f4ddcb48  lea rdi, [rsp]
000071e7f4ddcb4c  mov esi, 0x00
000071e7f4ddcb51  mov rax, 0x562A51E82530
000071e7f4ddcb5b  call rax
000071e7f4ddcb5d  movaps xmm7, [rsp]
000071e7f4ddcb61  add rsp, 0x30
000071e7f4ddcb65  vmovaps xmm0, [rsp]
000071e7f4ddcb6a  vmovaps xmm1, [rsp+0x10]
000071e7f4ddcb70  vmovaps xmm2, [rsp+0x20]
000071e7f4ddcb76  vmovaps xmm3, [rsp+0x30]
000071e7f4ddcb7c  vmovaps xmm4, [rsp+0x40]
000071e7f4ddcb82  vmovaps xmm5, [rsp+0x50]
000071e7f4ddcb88  vmovaps xmm6, [rsp+0x60]
000071e7f4ddcb8e  vmovaps xmm8, [rsp+0x70]
000071e7f4ddcb94  vmovaps xmm9, [rsp+0x80]
000071e7f4ddcb9d  vmovaps xmm10, [rsp+0x90]
000071e7f4ddcba6  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddcbaf  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddcbb8  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddcbc1  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddcbca  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddcbd3  add rsp, 0xF0
000071e7f4ddcbda  pop r11
000071e7f4ddcbdc  pop r10
000071e7f4ddcbde  pop r9
000071e7f4ddcbe0  pop r8
000071e7f4ddcbe2  pop rsi
000071e7f4ddcbe3  pop rdi
000071e7f4ddcbe4  pop rdx
000071e7f4ddcbe5  pop rcx
000071e7f4ddcbe6  pop rax
000071e7f4ddcbe7  add rsp, 0x08
000071e7f4ddcbeb  jmp 0x000071E7F4DDBB75
000071e7f4ddcbf0  sub rsp, 0x08
000071e7f4ddcbf4  push rax
000071e7f4ddcbf5  push rcx
000071e7f4ddcbf6  push rdx
000071e7f4ddcbf7  push rdi
000071e7f4ddcbf8  push rsi
000071e7f4ddcbf9  push r8
000071e7f4ddcbfb  push r9
000071e7f4ddcbfd  push r10
000071e7f4ddcbff  push r11
000071e7f4ddcc01  sub rsp, 0xF0
000071e7f4ddcc08  vmovaps [rsp], xmm0
000071e7f4ddcc0d  vmovaps [rsp+0x10], xmm1
000071e7f4ddcc13  vmovaps [rsp+0x20], xmm2
000071e7f4ddcc19  vmovaps [rsp+0x30], xmm3
000071e7f4ddcc1f  vmovaps [rsp+0x40], xmm4
000071e7f4ddcc25  vmovaps [rsp+0x50], xmm5
000071e7f4ddcc2b  vmovaps [rsp+0x60], xmm6
000071e7f4ddcc31  vmovaps [rsp+0x70], xmm7
000071e7f4ddcc37  vmovaps [rsp+0x80], xmm8
000071e7f4ddcc40  vmovaps [rsp+0x90], xmm10
000071e7f4ddcc49  vmovaps [rsp+0xA0], xmm11
000071e7f4ddcc52  vmovaps [rsp+0xB0], xmm12
000071e7f4ddcc5b  vmovaps [rsp+0xC0], xmm13
000071e7f4ddcc64  vmovaps [rsp+0xD0], xmm14
000071e7f4ddcc6d  vmovaps [rsp+0xE0], xmm15
000071e7f4ddcc76  sub rsp, 0x30
000071e7f4ddcc7a  movaps [rsp], xmm9
000071e7f4ddcc7f  movaps [rsp+0x10], xmm12
000071e7f4ddcc85  movaps [rsp+0x20], xmm10
000071e7f4ddcc8b  lea rdi, [rsp]
000071e7f4ddcc8f  mov esi, 0x00
000071e7f4ddcc94  mov rax, 0x562A51E82530
000071e7f4ddcc9e  call rax
000071e7f4ddcca0  movaps xmm9, [rsp]
000071e7f4ddcca5  add rsp, 0x30
000071e7f4ddcca9  vmovaps xmm0, [rsp]
000071e7f4ddccae  vmovaps xmm1, [rsp+0x10]
000071e7f4ddccb4  vmovaps xmm2, [rsp+0x20]
000071e7f4ddccba  vmovaps xmm3, [rsp+0x30]
000071e7f4ddccc0  vmovaps xmm4, [rsp+0x40]
000071e7f4ddccc6  vmovaps xmm5, [rsp+0x50]
000071e7f4ddcccc  vmovaps xmm6, [rsp+0x60]
000071e7f4ddccd2  vmovaps xmm7, [rsp+0x70]
000071e7f4ddccd8  vmovaps xmm8, [rsp+0x80]
000071e7f4ddcce1  vmovaps xmm10, [rsp+0x90]
000071e7f4ddccea  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddccf3  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddccfc  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddcd05  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddcd0e  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddcd17  add rsp, 0xF0
000071e7f4ddcd1e  pop r11
000071e7f4ddcd20  pop r10
000071e7f4ddcd22  pop r9
000071e7f4ddcd24  pop r8
000071e7f4ddcd26  pop rsi
000071e7f4ddcd27  pop rdi
000071e7f4ddcd28  pop rdx
000071e7f4ddcd29  pop rcx
000071e7f4ddcd2a  pop rax
000071e7f4ddcd2b  add rsp, 0x08
000071e7f4ddcd2f  jmp 0x000071E7F4DDBB99
000071e7f4ddcd34  sub rsp, 0x08
000071e7f4ddcd38  push rax
000071e7f4ddcd39  push rcx
000071e7f4ddcd3a  push rdx
000071e7f4ddcd3b  push rdi
000071e7f4ddcd3c  push rsi
000071e7f4ddcd3d  push r8
000071e7f4ddcd3f  push r9
000071e7f4ddcd41  push r10
000071e7f4ddcd43  push r11
000071e7f4ddcd45  sub rsp, 0xF0
000071e7f4ddcd4c  vmovaps [rsp], xmm0
000071e7f4ddcd51  vmovaps [rsp+0x10], xmm1
000071e7f4ddcd57  vmovaps [rsp+0x20], xmm2
000071e7f4ddcd5d  vmovaps [rsp+0x30], xmm3
000071e7f4ddcd63  vmovaps [rsp+0x40], xmm4
000071e7f4ddcd69  vmovaps [rsp+0x50], xmm5
000071e7f4ddcd6f  vmovaps [rsp+0x60], xmm6
000071e7f4ddcd75  vmovaps [rsp+0x70], xmm7
000071e7f4ddcd7b  vmovaps [rsp+0x80], xmm8
000071e7f4ddcd84  vmovaps [rsp+0x90], xmm9
000071e7f4ddcd8d  vmovaps [rsp+0xA0], xmm11
000071e7f4ddcd96  vmovaps [rsp+0xB0], xmm12
000071e7f4ddcd9f  vmovaps [rsp+0xC0], xmm13
000071e7f4ddcda8  vmovaps [rsp+0xD0], xmm14
000071e7f4ddcdb1  vmovaps [rsp+0xE0], xmm15
000071e7f4ddcdba  sub rsp, 0x30
000071e7f4ddcdbe  movaps [rsp], xmm10
000071e7f4ddcdc3  movaps [rsp+0x10], xmm12
000071e7f4ddcdc9  movaps [rsp+0x20], xmm11
000071e7f4ddcdcf  lea rdi, [rsp]
000071e7f4ddcdd3  mov esi, 0x00
000071e7f4ddcdd8  mov rax, 0x562A51E82530
000071e7f4ddcde2  call rax
000071e7f4ddcde4  movaps xmm10, [rsp]
000071e7f4ddcde9  add rsp, 0x30
000071e7f4ddcded  vmovaps xmm0, [rsp]
000071e7f4ddcdf2  vmovaps xmm1, [rsp+0x10]
000071e7f4ddcdf8  vmovaps xmm2, [rsp+0x20]
000071e7f4ddcdfe  vmovaps xmm3, [rsp+0x30]
000071e7f4ddce04  vmovaps xmm4, [rsp+0x40]
000071e7f4ddce0a  vmovaps xmm5, [rsp+0x50]
000071e7f4ddce10  vmovaps xmm6, [rsp+0x60]
000071e7f4ddce16  vmovaps xmm7, [rsp+0x70]
000071e7f4ddce1c  vmovaps xmm8, [rsp+0x80]
000071e7f4ddce25  vmovaps xmm9, [rsp+0x90]
000071e7f4ddce2e  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddce37  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddce40  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddce49  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddce52  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddce5b  add rsp, 0xF0
000071e7f4ddce62  pop r11
000071e7f4ddce64  pop r10
000071e7f4ddce66  pop r9
000071e7f4ddce68  pop r8
000071e7f4ddce6a  pop rsi
000071e7f4ddce6b  pop rdi
000071e7f4ddce6c  pop rdx
000071e7f4ddce6d  pop rcx
000071e7f4ddce6e  pop rax
000071e7f4ddce6f  add rsp, 0x08
000071e7f4ddce73  jmp 0x000071E7F4DDBBB3
000071e7f4ddce78  sub rsp, 0x08
000071e7f4ddce7c  push rax
000071e7f4ddce7d  push rcx
000071e7f4ddce7e  push rdx
000071e7f4ddce7f  push rdi
000071e7f4ddce80  push rsi
000071e7f4ddce81  push r8
000071e7f4ddce83  push r9
000071e7f4ddce85  push r10
000071e7f4ddce87  push r11
000071e7f4ddce89  sub rsp, 0xF0
000071e7f4ddce90  vmovaps [rsp], xmm0
000071e7f4ddce95  vmovaps [rsp+0x10], xmm1
000071e7f4ddce9b  vmovaps [rsp+0x20], xmm2
000071e7f4ddcea1  vmovaps [rsp+0x30], xmm3
000071e7f4ddcea7  vmovaps [rsp+0x40], xmm4
000071e7f4ddcead  vmovaps [rsp+0x50], xmm5
000071e7f4ddceb3  vmovaps [rsp+0x60], xmm7
000071e7f4ddceb9  vmovaps [rsp+0x70], xmm8
000071e7f4ddcebf  vmovaps [rsp+0x80], xmm9
000071e7f4ddcec8  vmovaps [rsp+0x90], xmm10
000071e7f4ddced1  vmovaps [rsp+0xA0], xmm11
000071e7f4ddceda  vmovaps [rsp+0xB0], xmm12
000071e7f4ddcee3  vmovaps [rsp+0xC0], xmm13
000071e7f4ddceec  vmovaps [rsp+0xD0], xmm14
000071e7f4ddcef5  vmovaps [rsp+0xE0], xmm15
000071e7f4ddcefe  sub rsp, 0x30
000071e7f4ddcf02  movaps [rsp], xmm6
000071e7f4ddcf06  movaps [rsp+0x10], xmm12
000071e7f4ddcf0c  movaps [rsp+0x20], xmm11
000071e7f4ddcf12  lea rdi, [rsp]
000071e7f4ddcf16  mov esi, 0x00
000071e7f4ddcf1b  mov rax, 0x562A51E82530
000071e7f4ddcf25  call rax
000071e7f4ddcf27  movaps xmm6, [rsp]
000071e7f4ddcf2b  add rsp, 0x30
000071e7f4ddcf2f  vmovaps xmm0, [rsp]
000071e7f4ddcf34  vmovaps xmm1, [rsp+0x10]
000071e7f4ddcf3a  vmovaps xmm2, [rsp+0x20]
000071e7f4ddcf40  vmovaps xmm3, [rsp+0x30]
000071e7f4ddcf46  vmovaps xmm4, [rsp+0x40]
000071e7f4ddcf4c  vmovaps xmm5, [rsp+0x50]
000071e7f4ddcf52  vmovaps xmm7, [rsp+0x60]
000071e7f4ddcf58  vmovaps xmm8, [rsp+0x70]
000071e7f4ddcf5e  vmovaps xmm9, [rsp+0x80]
000071e7f4ddcf67  vmovaps xmm10, [rsp+0x90]
000071e7f4ddcf70  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddcf79  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddcf82  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddcf8b  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddcf94  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddcf9d  add rsp, 0xF0
000071e7f4ddcfa4  pop r11
000071e7f4ddcfa6  pop r10
000071e7f4ddcfa8  pop r9
000071e7f4ddcfaa  pop r8
000071e7f4ddcfac  pop rsi
000071e7f4ddcfad  pop rdi
000071e7f4ddcfae  pop rdx
000071e7f4ddcfaf  pop rcx
000071e7f4ddcfb0  pop rax
000071e7f4ddcfb1  add rsp, 0x08
000071e7f4ddcfb5  jmp 0x000071E7F4DDBBD4
000071e7f4ddcfba  sub rsp, 0x08
000071e7f4ddcfbe  push rax
000071e7f4ddcfbf  push rcx
000071e7f4ddcfc0  push rdx
000071e7f4ddcfc1  push rdi
000071e7f4ddcfc2  push rsi
000071e7f4ddcfc3  push r8
000071e7f4ddcfc5  push r9
000071e7f4ddcfc7  push r10
000071e7f4ddcfc9  push r11
000071e7f4ddcfcb  sub rsp, 0xF0
000071e7f4ddcfd2  vmovaps [rsp], xmm0
000071e7f4ddcfd7  vmovaps [rsp+0x10], xmm1
000071e7f4ddcfdd  vmovaps [rsp+0x20], xmm2
000071e7f4ddcfe3  vmovaps [rsp+0x30], xmm4
000071e7f4ddcfe9  vmovaps [rsp+0x40], xmm5
000071e7f4ddcfef  vmovaps [rsp+0x50], xmm6
000071e7f4ddcff5  vmovaps [rsp+0x60], xmm7
000071e7f4ddcffb  vmovaps [rsp+0x70], xmm8
000071e7f4ddd001  vmovaps [rsp+0x80], xmm9
000071e7f4ddd00a  vmovaps [rsp+0x90], xmm10
000071e7f4ddd013  vmovaps [rsp+0xA0], xmm11
000071e7f4ddd01c  vmovaps [rsp+0xB0], xmm12
000071e7f4ddd025  vmovaps [rsp+0xC0], xmm13
000071e7f4ddd02e  vmovaps [rsp+0xD0], xmm14
000071e7f4ddd037  vmovaps [rsp+0xE0], xmm15
000071e7f4ddd040  sub rsp, 0x30
000071e7f4ddd044  movaps [rsp], xmm3
000071e7f4ddd048  movaps [rsp+0x10], xmm5
000071e7f4ddd04d  movaps [rsp+0x20], xmm4
000071e7f4ddd052  lea rdi, [rsp]
000071e7f4ddd056  mov esi, 0x00
000071e7f4ddd05b  mov rax, 0x562A51E82530
000071e7f4ddd065  call rax
000071e7f4ddd067  movaps xmm3, [rsp]
000071e7f4ddd06b  add rsp, 0x30
000071e7f4ddd06f  vmovaps xmm0, [rsp]
000071e7f4ddd074  vmovaps xmm1, [rsp+0x10]
000071e7f4ddd07a  vmovaps xmm2, [rsp+0x20]
000071e7f4ddd080  vmovaps xmm4, [rsp+0x30]
000071e7f4ddd086  vmovaps xmm5, [rsp+0x40]
000071e7f4ddd08c  vmovaps xmm6, [rsp+0x50]
000071e7f4ddd092  vmovaps xmm7, [rsp+0x60]
000071e7f4ddd098  vmovaps xmm8, [rsp+0x70]
000071e7f4ddd09e  vmovaps xmm9, [rsp+0x80]
000071e7f4ddd0a7  vmovaps xmm10, [rsp+0x90]
000071e7f4ddd0b0  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddd0b9  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddd0c2  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddd0cb  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddd0d4  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddd0dd  add rsp, 0xF0
000071e7f4ddd0e4  pop r11
000071e7f4ddd0e6  pop r10
000071e7f4ddd0e8  pop r9
000071e7f4ddd0ea  pop r8
000071e7f4ddd0ec  pop rsi
000071e7f4ddd0ed  pop rdi
000071e7f4ddd0ee  pop rdx
000071e7f4ddd0ef  pop rcx
000071e7f4ddd0f0  pop rax
000071e7f4ddd0f1  add rsp, 0x08
000071e7f4ddd0f5  jmp 0x000071E7F4DDBC35
000071e7f4ddd0fa  sub rsp, 0x08
000071e7f4ddd0fe  push rax
000071e7f4ddd0ff  push rcx
000071e7f4ddd100  push rdx
000071e7f4ddd101  push rdi
000071e7f4ddd102  push rsi
000071e7f4ddd103  push r8
000071e7f4ddd105  push r9
000071e7f4ddd107  push r10
000071e7f4ddd109  push r11
000071e7f4ddd10b  sub rsp, 0xF0
000071e7f4ddd112  vmovaps [rsp], xmm0
000071e7f4ddd117  vmovaps [rsp+0x10], xmm1
000071e7f4ddd11d  vmovaps [rsp+0x20], xmm2
000071e7f4ddd123  vmovaps [rsp+0x30], xmm3
000071e7f4ddd129  vmovaps [rsp+0x40], xmm4
000071e7f4ddd12f  vmovaps [rsp+0x50], xmm6
000071e7f4ddd135  vmovaps [rsp+0x60], xmm7
000071e7f4ddd13b  vmovaps [rsp+0x70], xmm8
000071e7f4ddd141  vmovaps [rsp+0x80], xmm9
000071e7f4ddd14a  vmovaps [rsp+0x90], xmm10
000071e7f4ddd153  vmovaps [rsp+0xA0], xmm11
000071e7f4ddd15c  vmovaps [rsp+0xB0], xmm12
000071e7f4ddd165  vmovaps [rsp+0xC0], xmm13
000071e7f4ddd16e  vmovaps [rsp+0xD0], xmm14
000071e7f4ddd177  vmovaps [rsp+0xE0], xmm15
000071e7f4ddd180  sub rsp, 0x30
000071e7f4ddd184  movaps [rsp], xmm5
000071e7f4ddd188  movaps [rsp+0x10], xmm8
000071e7f4ddd18e  movaps [rsp+0x20], xmm15
000071e7f4ddd194  lea rdi, [rsp]
000071e7f4ddd198  mov esi, 0x00
000071e7f4ddd19d  mov rax, 0x562A51E82530
000071e7f4ddd1a7  call rax
000071e7f4ddd1a9  movaps xmm5, [rsp]
000071e7f4ddd1ad  add rsp, 0x30
000071e7f4ddd1b1  vmovaps xmm0, [rsp]
000071e7f4ddd1b6  vmovaps xmm1, [rsp+0x10]
000071e7f4ddd1bc  vmovaps xmm2, [rsp+0x20]
000071e7f4ddd1c2  vmovaps xmm3, [rsp+0x30]
000071e7f4ddd1c8  vmovaps xmm4, [rsp+0x40]
000071e7f4ddd1ce  vmovaps xmm6, [rsp+0x50]
000071e7f4ddd1d4  vmovaps xmm7, [rsp+0x60]
000071e7f4ddd1da  vmovaps xmm8, [rsp+0x70]
000071e7f4ddd1e0  vmovaps xmm9, [rsp+0x80]
000071e7f4ddd1e9  vmovaps xmm10, [rsp+0x90]
000071e7f4ddd1f2  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddd1fb  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddd204  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddd20d  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddd216  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddd21f  add rsp, 0xF0
000071e7f4ddd226  pop r11
000071e7f4ddd228  pop r10
000071e7f4ddd22a  pop r9
000071e7f4ddd22c  pop r8
000071e7f4ddd22e  pop rsi
000071e7f4ddd22f  pop rdi
000071e7f4ddd230  pop rdx
000071e7f4ddd231  pop rcx
000071e7f4ddd232  pop rax
000071e7f4ddd233  add rsp, 0x08
000071e7f4ddd237  jmp 0x000071E7F4DDBC73
000071e7f4ddd23c  sub rsp, 0x08
000071e7f4ddd240  push rax
000071e7f4ddd241  push rcx
000071e7f4ddd242  push rdx
000071e7f4ddd243  push rdi
000071e7f4ddd244  push rsi
000071e7f4ddd245  push r8
000071e7f4ddd247  push r9
000071e7f4ddd249  push r10
000071e7f4ddd24b  push r11
000071e7f4ddd24d  sub rsp, 0xF0
000071e7f4ddd254  vmovaps [rsp], xmm0
000071e7f4ddd259  vmovaps [rsp+0x10], xmm1
000071e7f4ddd25f  vmovaps [rsp+0x20], xmm2
000071e7f4ddd265  vmovaps [rsp+0x30], xmm3
000071e7f4ddd26b  vmovaps [rsp+0x40], xmm5
000071e7f4ddd271  vmovaps [rsp+0x50], xmm6
000071e7f4ddd277  vmovaps [rsp+0x60], xmm7
000071e7f4ddd27d  vmovaps [rsp+0x70], xmm8
000071e7f4ddd283  vmovaps [rsp+0x80], xmm9
000071e7f4ddd28c  vmovaps [rsp+0x90], xmm10
000071e7f4ddd295  vmovaps [rsp+0xA0], xmm11
000071e7f4ddd29e  vmovaps [rsp+0xB0], xmm12
000071e7f4ddd2a7  vmovaps [rsp+0xC0], xmm13
000071e7f4ddd2b0  vmovaps [rsp+0xD0], xmm14
000071e7f4ddd2b9  vmovaps [rsp+0xE0], xmm15
000071e7f4ddd2c2  sub rsp, 0x30
000071e7f4ddd2c6  movaps [rsp], xmm4
000071e7f4ddd2ca  movaps [rsp+0x10], xmm9
000071e7f4ddd2d0  movaps [rsp+0x20], xmm8
000071e7f4ddd2d6  lea rdi, [rsp]
000071e7f4ddd2da  mov esi, 0x00
000071e7f4ddd2df  mov rax, 0x562A51E82530
000071e7f4ddd2e9  call rax
000071e7f4ddd2eb  movaps xmm4, [rsp]
000071e7f4ddd2ef  add rsp, 0x30
000071e7f4ddd2f3  vmovaps xmm0, [rsp]
000071e7f4ddd2f8  vmovaps xmm1, [rsp+0x10]
000071e7f4ddd2fe  vmovaps xmm2, [rsp+0x20]
000071e7f4ddd304  vmovaps xmm3, [rsp+0x30]
000071e7f4ddd30a  vmovaps xmm5, [rsp+0x40]
000071e7f4ddd310  vmovaps xmm6, [rsp+0x50]
000071e7f4ddd316  vmovaps xmm7, [rsp+0x60]
000071e7f4ddd31c  vmovaps xmm8, [rsp+0x70]
000071e7f4ddd322  vmovaps xmm9, [rsp+0x80]
000071e7f4ddd32b  vmovaps xmm10, [rsp+0x90]
000071e7f4ddd334  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddd33d  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddd346  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddd34f  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddd358  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddd361  add rsp, 0xF0
000071e7f4ddd368  pop r11
000071e7f4ddd36a  pop r10
000071e7f4ddd36c  pop r9
000071e7f4ddd36e  pop r8
000071e7f4ddd370  pop rsi
000071e7f4ddd371  pop rdi
000071e7f4ddd372  pop rdx
000071e7f4ddd373  pop rcx
000071e7f4ddd374  pop rax
000071e7f4ddd375  add rsp, 0x08
000071e7f4ddd379  jmp 0x000071E7F4DDBC94
000071e7f4ddd37e  sub rsp, 0x08
000071e7f4ddd382  push rax
000071e7f4ddd383  push rcx
000071e7f4ddd384  push rdx
000071e7f4ddd385  push rdi
000071e7f4ddd386  push rsi
000071e7f4ddd387  push r8
000071e7f4ddd389  push r9
000071e7f4ddd38b  push r10
000071e7f4ddd38d  push r11
000071e7f4ddd38f  sub rsp, 0xF0
000071e7f4ddd396  vmovaps [rsp], xmm0
000071e7f4ddd39b  vmovaps [rsp+0x10], xmm1
000071e7f4ddd3a1  vmovaps [rsp+0x20], xmm2
000071e7f4ddd3a7  vmovaps [rsp+0x30], xmm3
000071e7f4ddd3ad  vmovaps [rsp+0x40], xmm4
000071e7f4ddd3b3  vmovaps [rsp+0x50], xmm5
000071e7f4ddd3b9  vmovaps [rsp+0x60], xmm6
000071e7f4ddd3bf  vmovaps [rsp+0x70], xmm7
000071e7f4ddd3c5  vmovaps [rsp+0x80], xmm8
000071e7f4ddd3ce  vmovaps [rsp+0x90], xmm10
000071e7f4ddd3d7  vmovaps [rsp+0xA0], xmm11
000071e7f4ddd3e0  vmovaps [rsp+0xB0], xmm12
000071e7f4ddd3e9  vmovaps [rsp+0xC0], xmm13
000071e7f4ddd3f2  vmovaps [rsp+0xD0], xmm14
000071e7f4ddd3fb  vmovaps [rsp+0xE0], xmm15
000071e7f4ddd404  sub rsp, 0x30
000071e7f4ddd408  movaps [rsp], xmm9
000071e7f4ddd40d  movaps [rsp+0x10], xmm10
000071e7f4ddd413  movaps [rsp+0x20], xmm8
000071e7f4ddd419  lea rdi, [rsp]
000071e7f4ddd41d  mov esi, 0x00
000071e7f4ddd422  mov rax, 0x562A51E82530
000071e7f4ddd42c  call rax
000071e7f4ddd42e  movaps xmm9, [rsp]
000071e7f4ddd433  add rsp, 0x30
000071e7f4ddd437  vmovaps xmm0, [rsp]
000071e7f4ddd43c  vmovaps xmm1, [rsp+0x10]
000071e7f4ddd442  vmovaps xmm2, [rsp+0x20]
000071e7f4ddd448  vmovaps xmm3, [rsp+0x30]
000071e7f4ddd44e  vmovaps xmm4, [rsp+0x40]
000071e7f4ddd454  vmovaps xmm5, [rsp+0x50]
000071e7f4ddd45a  vmovaps xmm6, [rsp+0x60]
000071e7f4ddd460  vmovaps xmm7, [rsp+0x70]
000071e7f4ddd466  vmovaps xmm8, [rsp+0x80]
000071e7f4ddd46f  vmovaps xmm10, [rsp+0x90]
000071e7f4ddd478  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddd481  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddd48a  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddd493  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddd49c  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddd4a5  add rsp, 0xF0
000071e7f4ddd4ac  pop r11
000071e7f4ddd4ae  pop r10
000071e7f4ddd4b0  pop r9
000071e7f4ddd4b2  pop r8
000071e7f4ddd4b4  pop rsi
000071e7f4ddd4b5  pop rdi
000071e7f4ddd4b6  pop rdx
000071e7f4ddd4b7  pop rcx
000071e7f4ddd4b8  pop rax
000071e7f4ddd4b9  add rsp, 0x08
000071e7f4ddd4bd  jmp 0x000071E7F4DDBCAE
000071e7f4ddd4c2  call 0x000071E7F4CB52F0
000071e7f4ddd4c7  jmp 0x000071E7F4DDBDC8
000071e7f4ddd4cc  call 0x000071E7F4CB52F0
000071e7f4ddd4d1  jmp 0x000071E7F4DDBDDE
000071e7f4ddd4d6  sub rsp, 0x08
000071e7f4ddd4da  push rax
000071e7f4ddd4db  push rcx
000071e7f4ddd4dc  push rdx
000071e7f4ddd4dd  push rdi
000071e7f4ddd4de  push rsi
000071e7f4ddd4df  push r8
000071e7f4ddd4e1  push r9
000071e7f4ddd4e3  push r10
000071e7f4ddd4e5  push r11
000071e7f4ddd4e7  sub rsp, 0xF0
000071e7f4ddd4ee  vmovaps [rsp], xmm0
000071e7f4ddd4f3  vmovaps [rsp+0x10], xmm2
000071e7f4ddd4f9  vmovaps [rsp+0x20], xmm3
000071e7f4ddd4ff  vmovaps [rsp+0x30], xmm4
000071e7f4ddd505  vmovaps [rsp+0x40], xmm5
000071e7f4ddd50b  vmovaps [rsp+0x50], xmm6
000071e7f4ddd511  vmovaps [rsp+0x60], xmm7
000071e7f4ddd517  vmovaps [rsp+0x70], xmm8
000071e7f4ddd51d  vmovaps [rsp+0x80], xmm9
000071e7f4ddd526  vmovaps [rsp+0x90], xmm10
000071e7f4ddd52f  vmovaps [rsp+0xA0], xmm11
000071e7f4ddd538  vmovaps [rsp+0xB0], xmm12
000071e7f4ddd541  vmovaps [rsp+0xC0], xmm13
000071e7f4ddd54a  vmovaps [rsp+0xD0], xmm14
000071e7f4ddd553  vmovaps [rsp+0xE0], xmm15
000071e7f4ddd55c  sub rsp, 0x30
000071e7f4ddd560  movaps [rsp], xmm1
000071e7f4ddd564  movaps [rsp+0x10], xmm6
000071e7f4ddd569  movaps [rsp+0x20], xmm15
000071e7f4ddd56f  lea rdi, [rsp]
000071e7f4ddd573  mov esi, 0x00
000071e7f4ddd578  mov rax, 0x562A51E82530
000071e7f4ddd582  call rax
000071e7f4ddd584  movaps xmm1, [rsp]
000071e7f4ddd588  add rsp, 0x30
000071e7f4ddd58c  vmovaps xmm0, [rsp]
000071e7f4ddd591  vmovaps xmm2, [rsp+0x10]
000071e7f4ddd597  vmovaps xmm3, [rsp+0x20]
000071e7f4ddd59d  vmovaps xmm4, [rsp+0x30]
000071e7f4ddd5a3  vmovaps xmm5, [rsp+0x40]
000071e7f4ddd5a9  vmovaps xmm6, [rsp+0x50]
000071e7f4ddd5af  vmovaps xmm7, [rsp+0x60]
000071e7f4ddd5b5  vmovaps xmm8, [rsp+0x70]
000071e7f4ddd5bb  vmovaps xmm9, [rsp+0x80]
000071e7f4ddd5c4  vmovaps xmm10, [rsp+0x90]
000071e7f4ddd5cd  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddd5d6  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddd5df  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddd5e8  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddd5f1  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddd5fa  add rsp, 0xF0
000071e7f4ddd601  pop r11
000071e7f4ddd603  pop r10
000071e7f4ddd605  pop r9
000071e7f4ddd607  pop r8
000071e7f4ddd609  pop rsi
000071e7f4ddd60a  pop rdi
000071e7f4ddd60b  pop rdx
000071e7f4ddd60c  pop rcx
000071e7f4ddd60d  pop rax
000071e7f4ddd60e  add rsp, 0x08
000071e7f4ddd612  jmp 0x000071E7F4DDBE1B
000071e7f4ddd617  call 0x000071E7F4CC4620
000071e7f4ddd61c  jmp 0x000071E7F4DDBE28
000071e7f4ddd621  sub rsp, 0x08
000071e7f4ddd625  push rax
000071e7f4ddd626  push rcx
000071e7f4ddd627  push rdx
000071e7f4ddd628  push rdi
000071e7f4ddd629  push rsi
000071e7f4ddd62a  push r8
000071e7f4ddd62c  push r9
000071e7f4ddd62e  push r10
000071e7f4ddd630  push r11
000071e7f4ddd632  sub rsp, 0xF0
000071e7f4ddd639  vmovaps [rsp], xmm0
000071e7f4ddd63e  vmovaps [rsp+0x10], xmm1
000071e7f4ddd644  vmovaps [rsp+0x20], xmm2
000071e7f4ddd64a  vmovaps [rsp+0x30], xmm3
000071e7f4ddd650  vmovaps [rsp+0x40], xmm4
000071e7f4ddd656  vmovaps [rsp+0x50], xmm5
000071e7f4ddd65c  vmovaps [rsp+0x60], xmm6
000071e7f4ddd662  vmovaps [rsp+0x70], xmm7
000071e7f4ddd668  vmovaps [rsp+0x80], xmm8
000071e7f4ddd671  vmovaps [rsp+0x90], xmm9
000071e7f4ddd67a  vmovaps [rsp+0xA0], xmm10
000071e7f4ddd683  vmovaps [rsp+0xB0], xmm11
000071e7f4ddd68c  vmovaps [rsp+0xC0], xmm12
000071e7f4ddd695  vmovaps [rsp+0xD0], xmm13
000071e7f4ddd69e  vmovaps [rsp+0xE0], xmm15
000071e7f4ddd6a7  sub rsp, 0x30
000071e7f4ddd6ab  movaps [rsp], xmm14
000071e7f4ddd6b0  movaps [rsp+0x10], xmm4
000071e7f4ddd6b5  movaps [rsp+0x20], xmm3
000071e7f4ddd6ba  lea rdi, [rsp]
000071e7f4ddd6be  mov esi, 0x00
000071e7f4ddd6c3  mov rax, 0x562A51E82530
000071e7f4ddd6cd  call rax
000071e7f4ddd6cf  movaps xmm14, [rsp]
000071e7f4ddd6d4  add rsp, 0x30
000071e7f4ddd6d8  vmovaps xmm0, [rsp]
000071e7f4ddd6dd  vmovaps xmm1, [rsp+0x10]
000071e7f4ddd6e3  vmovaps xmm2, [rsp+0x20]
000071e7f4ddd6e9  vmovaps xmm3, [rsp+0x30]
000071e7f4ddd6ef  vmovaps xmm4, [rsp+0x40]
000071e7f4ddd6f5  vmovaps xmm5, [rsp+0x50]
000071e7f4ddd6fb  vmovaps xmm6, [rsp+0x60]
000071e7f4ddd701  vmovaps xmm7, [rsp+0x70]
000071e7f4ddd707  vmovaps xmm8, [rsp+0x80]
000071e7f4ddd710  vmovaps xmm9, [rsp+0x90]
000071e7f4ddd719  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddd722  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddd72b  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddd734  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddd73d  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddd746  add rsp, 0xF0
000071e7f4ddd74d  pop r11
000071e7f4ddd74f  pop r10
000071e7f4ddd751  pop r9
000071e7f4ddd753  pop r8
000071e7f4ddd755  pop rsi
000071e7f4ddd756  pop rdi
000071e7f4ddd757  pop rdx
000071e7f4ddd758  pop rcx
000071e7f4ddd759  pop rax
000071e7f4ddd75a  add rsp, 0x08
000071e7f4ddd75e  jmp 0x000071E7F4DDBE42
000071e7f4ddd763  sub rsp, 0x08
000071e7f4ddd767  push rax
000071e7f4ddd768  push rcx
000071e7f4ddd769  push rdx
000071e7f4ddd76a  push rdi
000071e7f4ddd76b  push rsi
000071e7f4ddd76c  push r8
000071e7f4ddd76e  push r9
000071e7f4ddd770  push r10
000071e7f4ddd772  push r11
000071e7f4ddd774  sub rsp, 0xF0
000071e7f4ddd77b  vmovaps [rsp], xmm0
000071e7f4ddd780  vmovaps [rsp+0x10], xmm1
000071e7f4ddd786  vmovaps [rsp+0x20], xmm2
000071e7f4ddd78c  vmovaps [rsp+0x30], xmm3
000071e7f4ddd792  vmovaps [rsp+0x40], xmm4
000071e7f4ddd798  vmovaps [rsp+0x50], xmm5
000071e7f4ddd79e  vmovaps [rsp+0x60], xmm7
000071e7f4ddd7a4  vmovaps [rsp+0x70], xmm8
000071e7f4ddd7aa  vmovaps [rsp+0x80], xmm9
000071e7f4ddd7b3  vmovaps [rsp+0x90], xmm10
000071e7f4ddd7bc  vmovaps [rsp+0xA0], xmm11
000071e7f4ddd7c5  vmovaps [rsp+0xB0], xmm12
000071e7f4ddd7ce  vmovaps [rsp+0xC0], xmm13
000071e7f4ddd7d7  vmovaps [rsp+0xD0], xmm14
000071e7f4ddd7e0  vmovaps [rsp+0xE0], xmm15
000071e7f4ddd7e9  sub rsp, 0x30
000071e7f4ddd7ed  movaps [rsp], xmm6
000071e7f4ddd7f1  movaps [rsp+0x10], xmm9
000071e7f4ddd7f7  movaps [rsp+0x20], xmm7
000071e7f4ddd7fc  lea rdi, [rsp]
000071e7f4ddd800  mov esi, 0x00
000071e7f4ddd805  mov rax, 0x562A51E82530
000071e7f4ddd80f  call rax
000071e7f4ddd811  movaps xmm6, [rsp]
000071e7f4ddd815  add rsp, 0x30
000071e7f4ddd819  vmovaps xmm0, [rsp]
000071e7f4ddd81e  vmovaps xmm1, [rsp+0x10]
000071e7f4ddd824  vmovaps xmm2, [rsp+0x20]
000071e7f4ddd82a  vmovaps xmm3, [rsp+0x30]
000071e7f4ddd830  vmovaps xmm4, [rsp+0x40]
000071e7f4ddd836  vmovaps xmm5, [rsp+0x50]
000071e7f4ddd83c  vmovaps xmm7, [rsp+0x60]
000071e7f4ddd842  vmovaps xmm8, [rsp+0x70]
000071e7f4ddd848  vmovaps xmm9, [rsp+0x80]
000071e7f4ddd851  vmovaps xmm10, [rsp+0x90]
000071e7f4ddd85a  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddd863  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddd86c  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddd875  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddd87e  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddd887  add rsp, 0xF0
000071e7f4ddd88e  pop r11
000071e7f4ddd890  pop r10
000071e7f4ddd892  pop r9
000071e7f4ddd894  pop r8
000071e7f4ddd896  pop rsi
000071e7f4ddd897  pop rdi
000071e7f4ddd898  pop rdx
000071e7f4ddd899  pop rcx
000071e7f4ddd89a  pop rax
000071e7f4ddd89b  add rsp, 0x08
000071e7f4ddd89f  jmp 0x000071E7F4DDBE5A
000071e7f4ddd8a4  sub rsp, 0x08
000071e7f4ddd8a8  push rax
000071e7f4ddd8a9  push rcx
000071e7f4ddd8aa  push rdx
000071e7f4ddd8ab  push rdi
000071e7f4ddd8ac  push rsi
000071e7f4ddd8ad  push r8
000071e7f4ddd8af  push r9
000071e7f4ddd8b1  push r10
000071e7f4ddd8b3  push r11
000071e7f4ddd8b5  sub rsp, 0xF0
000071e7f4ddd8bc  vmovaps [rsp], xmm0
000071e7f4ddd8c1  vmovaps [rsp+0x10], xmm1
000071e7f4ddd8c7  vmovaps [rsp+0x20], xmm2
000071e7f4ddd8cd  vmovaps [rsp+0x30], xmm3
000071e7f4ddd8d3  vmovaps [rsp+0x40], xmm4
000071e7f4ddd8d9  vmovaps [rsp+0x50], xmm5
000071e7f4ddd8df  vmovaps [rsp+0x60], xmm6
000071e7f4ddd8e5  vmovaps [rsp+0x70], xmm8
000071e7f4ddd8eb  vmovaps [rsp+0x80], xmm9
000071e7f4ddd8f4  vmovaps [rsp+0x90], xmm10
000071e7f4ddd8fd  vmovaps [rsp+0xA0], xmm11
000071e7f4ddd906  vmovaps [rsp+0xB0], xmm12
000071e7f4ddd90f  vmovaps [rsp+0xC0], xmm13
000071e7f4ddd918  vmovaps [rsp+0xD0], xmm14
000071e7f4ddd921  vmovaps [rsp+0xE0], xmm15
000071e7f4ddd92a  sub rsp, 0x30
000071e7f4ddd92e  movaps [rsp], xmm7
000071e7f4ddd932  movaps [rsp+0x10], xmm4
000071e7f4ddd937  movaps [rsp+0x20], xmm9
000071e7f4ddd93d  lea rdi, [rsp]
000071e7f4ddd941  mov esi, 0x00
000071e7f4ddd946  mov rax, 0x562A51E82530
000071e7f4ddd950  call rax
000071e7f4ddd952  movaps xmm7, [rsp]
000071e7f4ddd956  add rsp, 0x30
000071e7f4ddd95a  vmovaps xmm0, [rsp]
000071e7f4ddd95f  vmovaps xmm1, [rsp+0x10]
000071e7f4ddd965  vmovaps xmm2, [rsp+0x20]
000071e7f4ddd96b  vmovaps xmm3, [rsp+0x30]
000071e7f4ddd971  vmovaps xmm4, [rsp+0x40]
000071e7f4ddd977  vmovaps xmm5, [rsp+0x50]
000071e7f4ddd97d  vmovaps xmm6, [rsp+0x60]
000071e7f4ddd983  vmovaps xmm8, [rsp+0x70]
000071e7f4ddd989  vmovaps xmm9, [rsp+0x80]
000071e7f4ddd992  vmovaps xmm10, [rsp+0x90]
000071e7f4ddd99b  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddd9a4  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddd9ad  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddd9b6  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddd9bf  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddd9c8  add rsp, 0xF0
000071e7f4ddd9cf  pop r11
000071e7f4ddd9d1  pop r10
000071e7f4ddd9d3  pop r9
000071e7f4ddd9d5  pop r8
000071e7f4ddd9d7  pop rsi
000071e7f4ddd9d8  pop rdi
000071e7f4ddd9d9  pop rdx
000071e7f4ddd9da  pop rcx
000071e7f4ddd9db  pop rax
000071e7f4ddd9dc  add rsp, 0x08
000071e7f4ddd9e0  jmp 0x000071E7F4DDBE87
000071e7f4ddd9e5  sub rsp, 0x08
000071e7f4ddd9e9  push rax
000071e7f4ddd9ea  push rcx
000071e7f4ddd9eb  push rdx
000071e7f4ddd9ec  push rdi
000071e7f4ddd9ed  push rsi
000071e7f4ddd9ee  push r8
000071e7f4ddd9f0  push r9
000071e7f4ddd9f2  push r10
000071e7f4ddd9f4  push r11
000071e7f4ddd9f6  sub rsp, 0xF0
000071e7f4ddd9fd  vmovaps [rsp], xmm0
000071e7f4ddda02  vmovaps [rsp+0x10], xmm1
000071e7f4ddda08  vmovaps [rsp+0x20], xmm2
000071e7f4ddda0e  vmovaps [rsp+0x30], xmm3
000071e7f4ddda14  vmovaps [rsp+0x40], xmm5
000071e7f4ddda1a  vmovaps [rsp+0x50], xmm6
000071e7f4ddda20  vmovaps [rsp+0x60], xmm7
000071e7f4ddda26  vmovaps [rsp+0x70], xmm8
000071e7f4ddda2c  vmovaps [rsp+0x80], xmm9
000071e7f4ddda35  vmovaps [rsp+0x90], xmm10
000071e7f4ddda3e  vmovaps [rsp+0xA0], xmm11
000071e7f4ddda47  vmovaps [rsp+0xB0], xmm12
000071e7f4ddda50  vmovaps [rsp+0xC0], xmm13
000071e7f4ddda59  vmovaps [rsp+0xD0], xmm14
000071e7f4ddda62  vmovaps [rsp+0xE0], xmm15
000071e7f4ddda6b  sub rsp, 0x30
000071e7f4ddda6f  movaps [rsp], xmm4
000071e7f4ddda73  movaps [rsp+0x10], xmm15
000071e7f4ddda79  movaps [rsp+0x20], xmm9
000071e7f4ddda7f  lea rdi, [rsp]
000071e7f4ddda83  mov esi, 0x00
000071e7f4ddda88  mov rax, 0x562A51E82530
000071e7f4ddda92  call rax
000071e7f4ddda94  movaps xmm4, [rsp]
000071e7f4ddda98  add rsp, 0x30
000071e7f4ddda9c  vmovaps xmm0, [rsp]
000071e7f4dddaa1  vmovaps xmm1, [rsp+0x10]
000071e7f4dddaa7  vmovaps xmm2, [rsp+0x20]
000071e7f4dddaad  vmovaps xmm3, [rsp+0x30]
000071e7f4dddab3  vmovaps xmm5, [rsp+0x40]
000071e7f4dddab9  vmovaps xmm6, [rsp+0x50]
000071e7f4dddabf  vmovaps xmm7, [rsp+0x60]
000071e7f4dddac5  vmovaps xmm8, [rsp+0x70]
000071e7f4dddacb  vmovaps xmm9, [rsp+0x80]
000071e7f4dddad4  vmovaps xmm10, [rsp+0x90]
000071e7f4dddadd  vmovaps xmm11, [rsp+0xA0]
000071e7f4dddae6  vmovaps xmm12, [rsp+0xB0]
000071e7f4dddaef  vmovaps xmm13, [rsp+0xC0]
000071e7f4dddaf8  vmovaps xmm14, [rsp+0xD0]
000071e7f4dddb01  vmovaps xmm15, [rsp+0xE0]
000071e7f4dddb0a  add rsp, 0xF0
000071e7f4dddb11  pop r11
000071e7f4dddb13  pop r10
000071e7f4dddb15  pop r9
000071e7f4dddb17  pop r8
000071e7f4dddb19  pop rsi
000071e7f4dddb1a  pop rdi
000071e7f4dddb1b  pop rdx
000071e7f4dddb1c  pop rcx
000071e7f4dddb1d  pop rax
000071e7f4dddb1e  add rsp, 0x08
000071e7f4dddb22  jmp 0x000071E7F4DDBEAC
000071e7f4dddb27  call 0x000071E7F4CC4620
000071e7f4dddb2c  jmp 0x000071E7F4DDBEB9
000071e7f4dddb31  sub rsp, 0x08
000071e7f4dddb35  push rax
000071e7f4dddb36  push rcx
000071e7f4dddb37  push rdx
000071e7f4dddb38  push rdi
000071e7f4dddb39  push rsi
000071e7f4dddb3a  push r8
000071e7f4dddb3c  push r9
000071e7f4dddb3e  push r10
000071e7f4dddb40  push r11
000071e7f4dddb42  sub rsp, 0xF0
000071e7f4dddb49  vmovaps [rsp], xmm0
000071e7f4dddb4e  vmovaps [rsp+0x10], xmm1
000071e7f4dddb54  vmovaps [rsp+0x20], xmm2
000071e7f4dddb5a  vmovaps [rsp+0x30], xmm4
000071e7f4dddb60  vmovaps [rsp+0x40], xmm5
000071e7f4dddb66  vmovaps [rsp+0x50], xmm6
000071e7f4dddb6c  vmovaps [rsp+0x60], xmm7
000071e7f4dddb72  vmovaps [rsp+0x70], xmm8
000071e7f4dddb78  vmovaps [rsp+0x80], xmm9
000071e7f4dddb81  vmovaps [rsp+0x90], xmm10
000071e7f4dddb8a  vmovaps [rsp+0xA0], xmm11
000071e7f4dddb93  vmovaps [rsp+0xB0], xmm12
000071e7f4dddb9c  vmovaps [rsp+0xC0], xmm13
000071e7f4dddba5  vmovaps [rsp+0xD0], xmm14
000071e7f4dddbae  vmovaps [rsp+0xE0], xmm15
000071e7f4dddbb7  sub rsp, 0x30
000071e7f4dddbbb  movaps [rsp], xmm3
000071e7f4dddbbf  movaps [rsp+0x10], xmm1
000071e7f4dddbc4  movaps [rsp+0x20], xmm9
000071e7f4dddbca  lea rdi, [rsp]
000071e7f4dddbce  mov esi, 0x00
000071e7f4dddbd3  mov rax, 0x562A51E82530
000071e7f4dddbdd  call rax
000071e7f4dddbdf  movaps xmm3, [rsp]
000071e7f4dddbe3  add rsp, 0x30
000071e7f4dddbe7  vmovaps xmm0, [rsp]
000071e7f4dddbec  vmovaps xmm1, [rsp+0x10]
000071e7f4dddbf2  vmovaps xmm2, [rsp+0x20]
000071e7f4dddbf8  vmovaps xmm4, [rsp+0x30]
000071e7f4dddbfe  vmovaps xmm5, [rsp+0x40]
000071e7f4dddc04  vmovaps xmm6, [rsp+0x50]
000071e7f4dddc0a  vmovaps xmm7, [rsp+0x60]
000071e7f4dddc10  vmovaps xmm8, [rsp+0x70]
000071e7f4dddc16  vmovaps xmm9, [rsp+0x80]
000071e7f4dddc1f  vmovaps xmm10, [rsp+0x90]
000071e7f4dddc28  vmovaps xmm11, [rsp+0xA0]
000071e7f4dddc31  vmovaps xmm12, [rsp+0xB0]
000071e7f4dddc3a  vmovaps xmm13, [rsp+0xC0]
000071e7f4dddc43  vmovaps xmm14, [rsp+0xD0]
000071e7f4dddc4c  vmovaps xmm15, [rsp+0xE0]
000071e7f4dddc55  add rsp, 0xF0
000071e7f4dddc5c  pop r11
000071e7f4dddc5e  pop r10
000071e7f4dddc60  pop r9
000071e7f4dddc62  pop r8
000071e7f4dddc64  pop rsi
000071e7f4dddc65  pop rdi
000071e7f4dddc66  pop rdx
000071e7f4dddc67  pop rcx
000071e7f4dddc68  pop rax
000071e7f4dddc69  add rsp, 0x08
000071e7f4dddc6d  jmp 0x000071E7F4DDBEF6
000071e7f4dddc72  sub rsp, 0x08
000071e7f4dddc76  push rax
000071e7f4dddc77  push rcx
000071e7f4dddc78  push rdx
000071e7f4dddc79  push rdi
000071e7f4dddc7a  push rsi
000071e7f4dddc7b  push r8
000071e7f4dddc7d  push r9
000071e7f4dddc7f  push r10
000071e7f4dddc81  push r11
000071e7f4dddc83  sub rsp, 0xF0
000071e7f4dddc8a  vmovaps [rsp], xmm0
000071e7f4dddc8f  vmovaps [rsp+0x10], xmm2
000071e7f4dddc95  vmovaps [rsp+0x20], xmm3
000071e7f4dddc9b  vmovaps [rsp+0x30], xmm4
000071e7f4dddca1  vmovaps [rsp+0x40], xmm5
000071e7f4dddca7  vmovaps [rsp+0x50], xmm6
000071e7f4dddcad  vmovaps [rsp+0x60], xmm7
000071e7f4dddcb3  vmovaps [rsp+0x70], xmm8
000071e7f4dddcb9  vmovaps [rsp+0x80], xmm9
000071e7f4dddcc2  vmovaps [rsp+0x90], xmm10
000071e7f4dddccb  vmovaps [rsp+0xA0], xmm11
000071e7f4dddcd4  vmovaps [rsp+0xB0], xmm12
000071e7f4dddcdd  vmovaps [rsp+0xC0], xmm13
000071e7f4dddce6  vmovaps [rsp+0xD0], xmm14
000071e7f4dddcef  vmovaps [rsp+0xE0], xmm15
000071e7f4dddcf8  sub rsp, 0x30
000071e7f4dddcfc  movaps [rsp], xmm1
000071e7f4dddd00  movaps [rsp+0x10], xmm15
000071e7f4dddd06  movaps [rsp+0x20], xmm9
000071e7f4dddd0c  lea rdi, [rsp]
000071e7f4dddd10  mov esi, 0x00
000071e7f4dddd15  mov rax, 0x562A51E82530
000071e7f4dddd1f  call rax
000071e7f4dddd21  movaps xmm1, [rsp]
000071e7f4dddd25  add rsp, 0x30
000071e7f4dddd29  vmovaps xmm0, [rsp]
000071e7f4dddd2e  vmovaps xmm2, [rsp+0x10]
000071e7f4dddd34  vmovaps xmm3, [rsp+0x20]
000071e7f4dddd3a  vmovaps xmm4, [rsp+0x30]
000071e7f4dddd40  vmovaps xmm5, [rsp+0x40]
000071e7f4dddd46  vmovaps xmm6, [rsp+0x50]
000071e7f4dddd4c  vmovaps xmm7, [rsp+0x60]
000071e7f4dddd52  vmovaps xmm8, [rsp+0x70]
000071e7f4dddd58  vmovaps xmm9, [rsp+0x80]
000071e7f4dddd61  vmovaps xmm10, [rsp+0x90]
000071e7f4dddd6a  vmovaps xmm11, [rsp+0xA0]
000071e7f4dddd73  vmovaps xmm12, [rsp+0xB0]
000071e7f4dddd7c  vmovaps xmm13, [rsp+0xC0]
000071e7f4dddd85  vmovaps xmm14, [rsp+0xD0]
000071e7f4dddd8e  vmovaps xmm15, [rsp+0xE0]
000071e7f4dddd97  add rsp, 0xF0
000071e7f4dddd9e  pop r11
000071e7f4dddda0  pop r10
000071e7f4dddda2  pop r9
000071e7f4dddda4  pop r8
000071e7f4dddda6  pop rsi
000071e7f4dddda7  pop rdi
000071e7f4dddda8  pop rdx
000071e7f4dddda9  pop rcx
000071e7f4ddddaa  pop rax
000071e7f4ddddab  add rsp, 0x08
000071e7f4ddddaf  jmp 0x000071E7F4DDBF7E
000071e7f4ddddb4  call 0x000071E7F4CC4620
000071e7f4ddddb9  jmp 0x000071E7F4DDBF8B
000071e7f4ddddbe  sub rsp, 0x08
000071e7f4ddddc2  push rax
000071e7f4ddddc3  push rcx
000071e7f4ddddc4  push rdx
000071e7f4ddddc5  push rdi
000071e7f4ddddc6  push rsi
000071e7f4ddddc7  push r8
000071e7f4ddddc9  push r9
000071e7f4ddddcb  push r10
000071e7f4ddddcd  push r11
000071e7f4ddddcf  sub rsp, 0xF0
000071e7f4ddddd6  vmovaps [rsp], xmm0
000071e7f4dddddb  vmovaps [rsp+0x10], xmm2
000071e7f4dddde1  vmovaps [rsp+0x20], xmm3
000071e7f4dddde7  vmovaps [rsp+0x30], xmm4
000071e7f4dddded  vmovaps [rsp+0x40], xmm5
000071e7f4ddddf3  vmovaps [rsp+0x50], xmm6
000071e7f4ddddf9  vmovaps [rsp+0x60], xmm7
000071e7f4ddddff  vmovaps [rsp+0x70], xmm8
000071e7f4ddde05  vmovaps [rsp+0x80], xmm9
000071e7f4ddde0e  vmovaps [rsp+0x90], xmm10
000071e7f4ddde17  vmovaps [rsp+0xA0], xmm11
000071e7f4ddde20  vmovaps [rsp+0xB0], xmm12
000071e7f4ddde29  vmovaps [rsp+0xC0], xmm13
000071e7f4ddde32  vmovaps [rsp+0xD0], xmm14
000071e7f4ddde3b  vmovaps [rsp+0xE0], xmm15
000071e7f4ddde44  sub rsp, 0x30
000071e7f4ddde48  movaps [rsp], xmm1
000071e7f4ddde4c  movaps [rsp+0x10], xmm5
000071e7f4ddde51  movaps [rsp+0x20], xmm7
000071e7f4ddde56  lea rdi, [rsp]
000071e7f4ddde5a  mov esi, 0x00
000071e7f4ddde5f  mov rax, 0x562A51E82530
000071e7f4ddde69  call rax
000071e7f4ddde6b  movaps xmm1, [rsp]
000071e7f4ddde6f  add rsp, 0x30
000071e7f4ddde73  vmovaps xmm0, [rsp]
000071e7f4ddde78  vmovaps xmm2, [rsp+0x10]
000071e7f4ddde7e  vmovaps xmm3, [rsp+0x20]
000071e7f4ddde84  vmovaps xmm4, [rsp+0x30]
000071e7f4ddde8a  vmovaps xmm5, [rsp+0x40]
000071e7f4ddde90  vmovaps xmm6, [rsp+0x50]
000071e7f4ddde96  vmovaps xmm7, [rsp+0x60]
000071e7f4ddde9c  vmovaps xmm8, [rsp+0x70]
000071e7f4dddea2  vmovaps xmm9, [rsp+0x80]
000071e7f4dddeab  vmovaps xmm10, [rsp+0x90]
000071e7f4dddeb4  vmovaps xmm11, [rsp+0xA0]
000071e7f4dddebd  vmovaps xmm12, [rsp+0xB0]
000071e7f4dddec6  vmovaps xmm13, [rsp+0xC0]
000071e7f4dddecf  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddded8  vmovaps xmm15, [rsp+0xE0]
000071e7f4dddee1  add rsp, 0xF0
000071e7f4dddee8  pop r11
000071e7f4dddeea  pop r10
000071e7f4dddeec  pop r9
000071e7f4dddeee  pop r8
000071e7f4dddef0  pop rsi
000071e7f4dddef1  pop rdi
000071e7f4dddef2  pop rdx
000071e7f4dddef3  pop rcx
000071e7f4dddef4  pop rax
000071e7f4dddef5  add rsp, 0x08
000071e7f4dddef9  jmp 0x000071E7F4DDC030
000071e7f4dddefe  sub rsp, 0x08
000071e7f4dddf02  push rax
000071e7f4dddf03  push rcx
000071e7f4dddf04  push rdx
000071e7f4dddf05  push rdi
000071e7f4dddf06  push rsi
000071e7f4dddf07  push r8
000071e7f4dddf09  push r9
000071e7f4dddf0b  push r10
000071e7f4dddf0d  push r11
000071e7f4dddf0f  sub rsp, 0xF0
000071e7f4dddf16  vmovaps [rsp], xmm0
000071e7f4dddf1b  vmovaps [rsp+0x10], xmm1
000071e7f4dddf21  vmovaps [rsp+0x20], xmm2
000071e7f4dddf27  vmovaps [rsp+0x30], xmm3
000071e7f4dddf2d  vmovaps [rsp+0x40], xmm4
000071e7f4dddf33  vmovaps [rsp+0x50], xmm5
000071e7f4dddf39  vmovaps [rsp+0x60], xmm6
000071e7f4dddf3f  vmovaps [rsp+0x70], xmm8
000071e7f4dddf45  vmovaps [rsp+0x80], xmm9
000071e7f4dddf4e  vmovaps [rsp+0x90], xmm10
000071e7f4dddf57  vmovaps [rsp+0xA0], xmm11
000071e7f4dddf60  vmovaps [rsp+0xB0], xmm12
000071e7f4dddf69  vmovaps [rsp+0xC0], xmm13
000071e7f4dddf72  vmovaps [rsp+0xD0], xmm14
000071e7f4dddf7b  vmovaps [rsp+0xE0], xmm15
000071e7f4dddf84  sub rsp, 0x30
000071e7f4dddf88  movaps [rsp], xmm7
000071e7f4dddf8c  movaps [rsp+0x10], xmm5
000071e7f4dddf91  movaps [rsp+0x20], xmm15
000071e7f4dddf97  lea rdi, [rsp]
000071e7f4dddf9b  mov esi, 0x00
000071e7f4dddfa0  mov rax, 0x562A51E82530
000071e7f4dddfaa  call rax
000071e7f4dddfac  movaps xmm7, [rsp]
000071e7f4dddfb0  add rsp, 0x30
000071e7f4dddfb4  vmovaps xmm0, [rsp]
000071e7f4dddfb9  vmovaps xmm1, [rsp+0x10]
000071e7f4dddfbf  vmovaps xmm2, [rsp+0x20]
000071e7f4dddfc5  vmovaps xmm3, [rsp+0x30]
000071e7f4dddfcb  vmovaps xmm4, [rsp+0x40]
000071e7f4dddfd1  vmovaps xmm5, [rsp+0x50]
000071e7f4dddfd7  vmovaps xmm6, [rsp+0x60]
000071e7f4dddfdd  vmovaps xmm8, [rsp+0x70]
000071e7f4dddfe3  vmovaps xmm9, [rsp+0x80]
000071e7f4dddfec  vmovaps xmm10, [rsp+0x90]
000071e7f4dddff5  vmovaps xmm11, [rsp+0xA0]
000071e7f4dddffe  vmovaps xmm12, [rsp+0xB0]
000071e7f4dde007  vmovaps xmm13, [rsp+0xC0]
000071e7f4dde010  vmovaps xmm14, [rsp+0xD0]
000071e7f4dde019  vmovaps xmm15, [rsp+0xE0]
000071e7f4dde022  add rsp, 0xF0
000071e7f4dde029  pop r11
000071e7f4dde02b  pop r10
000071e7f4dde02d  pop r9
000071e7f4dde02f  pop r8
000071e7f4dde031  pop rsi
000071e7f4dde032  pop rdi
000071e7f4dde033  pop rdx
000071e7f4dde034  pop rcx
000071e7f4dde035  pop rax
000071e7f4dde036  add rsp, 0x08
000071e7f4dde03a  jmp 0x000071E7F4DDC066
000071e7f4dde03f  call 0x000071E7F4CB52F0
000071e7f4dde044  jmp 0x000071E7F4DDC073
000071e7f4dde049  sub rsp, 0x08
000071e7f4dde04d  push rax
000071e7f4dde04e  push rcx
000071e7f4dde04f  push rdx
000071e7f4dde050  push rdi
000071e7f4dde051  push rsi
000071e7f4dde052  push r8
000071e7f4dde054  push r9
000071e7f4dde056  push r10
000071e7f4dde058  push r11
000071e7f4dde05a  sub rsp, 0xF0
000071e7f4dde061  vmovaps [rsp], xmm0
000071e7f4dde066  vmovaps [rsp+0x10], xmm1
000071e7f4dde06c  vmovaps [rsp+0x20], xmm2
000071e7f4dde072  vmovaps [rsp+0x30], xmm3
000071e7f4dde078  vmovaps [rsp+0x40], xmm4
000071e7f4dde07e  vmovaps [rsp+0x50], xmm5
000071e7f4dde084  vmovaps [rsp+0x60], xmm6
000071e7f4dde08a  vmovaps [rsp+0x70], xmm7
000071e7f4dde090  vmovaps [rsp+0x80], xmm8
000071e7f4dde099  vmovaps [rsp+0x90], xmm9
000071e7f4dde0a2  vmovaps [rsp+0xA0], xmm10
000071e7f4dde0ab  vmovaps [rsp+0xB0], xmm11
000071e7f4dde0b4  vmovaps [rsp+0xC0], xmm12
000071e7f4dde0bd  vmovaps [rsp+0xD0], xmm13
000071e7f4dde0c6  vmovaps [rsp+0xE0], xmm14
000071e7f4dde0cf  sub rsp, 0x30
000071e7f4dde0d3  movaps [rsp], xmm15
000071e7f4dde0d8  movaps [rsp+0x10], xmm5
000071e7f4dde0dd  movaps [rsp+0x20], xmm3
000071e7f4dde0e2  lea rdi, [rsp]
000071e7f4dde0e6  mov esi, 0x00
000071e7f4dde0eb  mov rax, 0x562A51E82530
000071e7f4dde0f5  call rax
000071e7f4dde0f7  movaps xmm15, [rsp]
000071e7f4dde0fc  add rsp, 0x30
000071e7f4dde100  vmovaps xmm0, [rsp]
000071e7f4dde105  vmovaps xmm1, [rsp+0x10]
000071e7f4dde10b  vmovaps xmm2, [rsp+0x20]
000071e7f4dde111  vmovaps xmm3, [rsp+0x30]
000071e7f4dde117  vmovaps xmm4, [rsp+0x40]
000071e7f4dde11d  vmovaps xmm5, [rsp+0x50]
000071e7f4dde123  vmovaps xmm6, [rsp+0x60]
000071e7f4dde129  vmovaps xmm7, [rsp+0x70]
000071e7f4dde12f  vmovaps xmm8, [rsp+0x80]
000071e7f4dde138  vmovaps xmm9, [rsp+0x90]
000071e7f4dde141  vmovaps xmm10, [rsp+0xA0]
000071e7f4dde14a  vmovaps xmm11, [rsp+0xB0]
000071e7f4dde153  vmovaps xmm12, [rsp+0xC0]
000071e7f4dde15c  vmovaps xmm13, [rsp+0xD0]
000071e7f4dde165  vmovaps xmm14, [rsp+0xE0]
000071e7f4dde16e  add rsp, 0xF0
000071e7f4dde175  pop r11
000071e7f4dde177  pop r10
000071e7f4dde179  pop r9
000071e7f4dde17b  pop r8
000071e7f4dde17d  pop rsi
000071e7f4dde17e  pop rdi
000071e7f4dde17f  pop rdx
000071e7f4dde180  pop rcx
000071e7f4dde181  pop rax
000071e7f4dde182  add rsp, 0x08
000071e7f4dde186  jmp 0x000071E7F4DDC099
000071e7f4dde18b  sub rsp, 0x08
000071e7f4dde18f  push rax
000071e7f4dde190  push rcx
000071e7f4dde191  push rdx
000071e7f4dde192  push rdi
000071e7f4dde193  push rsi
000071e7f4dde194  push r8
000071e7f4dde196  push r9
000071e7f4dde198  push r10
000071e7f4dde19a  push r11
000071e7f4dde19c  sub rsp, 0xF0
000071e7f4dde1a3  vmovaps [rsp], xmm0
000071e7f4dde1a8  vmovaps [rsp+0x10], xmm2
000071e7f4dde1ae  vmovaps [rsp+0x20], xmm3
000071e7f4dde1b4  vmovaps [rsp+0x30], xmm4
000071e7f4dde1ba  vmovaps [rsp+0x40], xmm5
000071e7f4dde1c0  vmovaps [rsp+0x50], xmm6
000071e7f4dde1c6  vmovaps [rsp+0x60], xmm7
000071e7f4dde1cc  vmovaps [rsp+0x70], xmm8
000071e7f4dde1d2  vmovaps [rsp+0x80], xmm9
000071e7f4dde1db  vmovaps [rsp+0x90], xmm10
000071e7f4dde1e4  vmovaps [rsp+0xA0], xmm11
000071e7f4dde1ed  vmovaps [rsp+0xB0], xmm12
000071e7f4dde1f6  vmovaps [rsp+0xC0], xmm13
000071e7f4dde1ff  vmovaps [rsp+0xD0], xmm14
000071e7f4dde208  vmovaps [rsp+0xE0], xmm15
000071e7f4dde211  sub rsp, 0x30
000071e7f4dde215  movaps [rsp], xmm1
000071e7f4dde219  movaps [rsp+0x10], xmm5
000071e7f4dde21e  movaps [rsp+0x20], xmm4
000071e7f4dde223  lea rdi, [rsp]
000071e7f4dde227  mov esi, 0x00
000071e7f4dde22c  mov rax, 0x562A51E82530
000071e7f4dde236  call rax
000071e7f4dde238  movaps xmm1, [rsp]
000071e7f4dde23c  add rsp, 0x30
000071e7f4dde240  vmovaps xmm0, [rsp]
000071e7f4dde245  vmovaps xmm2, [rsp+0x10]
000071e7f4dde24b  vmovaps xmm3, [rsp+0x20]
000071e7f4dde251  vmovaps xmm4, [rsp+0x30]
000071e7f4dde257  vmovaps xmm5, [rsp+0x40]
000071e7f4dde25d  vmovaps xmm6, [rsp+0x50]
000071e7f4dde263  vmovaps xmm7, [rsp+0x60]
000071e7f4dde269  vmovaps xmm8, [rsp+0x70]
000071e7f4dde26f  vmovaps xmm9, [rsp+0x80]
000071e7f4dde278  vmovaps xmm10, [rsp+0x90]
000071e7f4dde281  vmovaps xmm11, [rsp+0xA0]
000071e7f4dde28a  vmovaps xmm12, [rsp+0xB0]
000071e7f4dde293  vmovaps xmm13, [rsp+0xC0]
000071e7f4dde29c  vmovaps xmm14, [rsp+0xD0]
000071e7f4dde2a5  vmovaps xmm15, [rsp+0xE0]
000071e7f4dde2ae  add rsp, 0xF0
000071e7f4dde2b5  pop r11
000071e7f4dde2b7  pop r10
000071e7f4dde2b9  pop r9
000071e7f4dde2bb  pop r8
000071e7f4dde2bd  pop rsi
000071e7f4dde2be  pop rdi
000071e7f4dde2bf  pop rdx
000071e7f4dde2c0  pop rcx
000071e7f4dde2c1  pop rax
000071e7f4dde2c2  add rsp, 0x08
000071e7f4dde2c6  jmp 0x000071E7F4DDC0B9
000071e7f4dde2cb  sub rsp, 0x08
000071e7f4dde2cf  push rax
000071e7f4dde2d0  push rcx
000071e7f4dde2d1  push rdx
000071e7f4dde2d2  push rdi
000071e7f4dde2d3  push rsi
000071e7f4dde2d4  push r8
000071e7f4dde2d6  push r9
000071e7f4dde2d8  push r10
000071e7f4dde2da  push r11
000071e7f4dde2dc  sub rsp, 0xF0
000071e7f4dde2e3  vmovaps [rsp], xmm0
000071e7f4dde2e8  vmovaps [rsp+0x10], xmm1
000071e7f4dde2ee  vmovaps [rsp+0x20], xmm2
000071e7f4dde2f4  vmovaps [rsp+0x30], xmm3
000071e7f4dde2fa  vmovaps [rsp+0x40], xmm5
000071e7f4dde300  vmovaps [rsp+0x50], xmm6
000071e7f4dde306  vmovaps [rsp+0x60], xmm7
000071e7f4dde30c  vmovaps [rsp+0x70], xmm8
000071e7f4dde312  vmovaps [rsp+0x80], xmm9
000071e7f4dde31b  vmovaps [rsp+0x90], xmm10
000071e7f4dde324  vmovaps [rsp+0xA0], xmm11
000071e7f4dde32d  vmovaps [rsp+0xB0], xmm12
000071e7f4dde336  vmovaps [rsp+0xC0], xmm13
000071e7f4dde33f  vmovaps [rsp+0xD0], xmm14
000071e7f4dde348  vmovaps [rsp+0xE0], xmm15
000071e7f4dde351  sub rsp, 0x30
000071e7f4dde355  movaps [rsp], xmm4
000071e7f4dde359  movaps [rsp+0x10], xmm3
000071e7f4dde35e  movaps [rsp+0x20], xmm5
000071e7f4dde363  lea rdi, [rsp]
000071e7f4dde367  mov esi, 0x00
000071e7f4dde36c  mov rax, 0x562A51E82530
000071e7f4dde376  call rax
000071e7f4dde378  movaps xmm4, [rsp]
000071e7f4dde37c  add rsp, 0x30
000071e7f4dde380  vmovaps xmm0, [rsp]
000071e7f4dde385  vmovaps xmm1, [rsp+0x10]
000071e7f4dde38b  vmovaps xmm2, [rsp+0x20]
000071e7f4dde391  vmovaps xmm3, [rsp+0x30]
000071e7f4dde397  vmovaps xmm5, [rsp+0x40]
000071e7f4dde39d  vmovaps xmm6, [rsp+0x50]
000071e7f4dde3a3  vmovaps xmm7, [rsp+0x60]
000071e7f4dde3a9  vmovaps xmm8, [rsp+0x70]
000071e7f4dde3af  vmovaps xmm9, [rsp+0x80]
000071e7f4dde3b8  vmovaps xmm10, [rsp+0x90]
000071e7f4dde3c1  vmovaps xmm11, [rsp+0xA0]
000071e7f4dde3ca  vmovaps xmm12, [rsp+0xB0]
000071e7f4dde3d3  vmovaps xmm13, [rsp+0xC0]
000071e7f4dde3dc  vmovaps xmm14, [rsp+0xD0]
000071e7f4dde3e5  vmovaps xmm15, [rsp+0xE0]
000071e7f4dde3ee  add rsp, 0xF0
000071e7f4dde3f5  pop r11
000071e7f4dde3f7  pop r10
000071e7f4dde3f9  pop r9
000071e7f4dde3fb  pop r8
000071e7f4dde3fd  pop rsi
000071e7f4dde3fe  pop rdi
000071e7f4dde3ff  pop rdx
000071e7f4dde400  pop rcx
000071e7f4dde401  pop rax
000071e7f4dde402  add rsp, 0x08
000071e7f4dde406  jmp 0x000071E7F4DDC107
000071e7f4dde40b  call 0x000071E7F4CB52F0
000071e7f4dde410  jmp 0x000071E7F4DDC114
000071e7f4dde415  sub rsp, 0x08
000071e7f4dde419  push rax
000071e7f4dde41a  push rcx
000071e7f4dde41b  push rdx
000071e7f4dde41c  push rdi
000071e7f4dde41d  push rsi
000071e7f4dde41e  push r8
000071e7f4dde420  push r9
000071e7f4dde422  push r10
000071e7f4dde424  push r11
000071e7f4dde426  sub rsp, 0xF0
000071e7f4dde42d  vmovaps [rsp], xmm0
000071e7f4dde432  vmovaps [rsp+0x10], xmm1
000071e7f4dde438  vmovaps [rsp+0x20], xmm2
000071e7f4dde43e  vmovaps [rsp+0x30], xmm3
000071e7f4dde444  vmovaps [rsp+0x40], xmm4
000071e7f4dde44a  vmovaps [rsp+0x50], xmm6
000071e7f4dde450  vmovaps [rsp+0x60], xmm7
000071e7f4dde456  vmovaps [rsp+0x70], xmm8
000071e7f4dde45c  vmovaps [rsp+0x80], xmm9
000071e7f4dde465  vmovaps [rsp+0x90], xmm10
000071e7f4dde46e  vmovaps [rsp+0xA0], xmm11
000071e7f4dde477  vmovaps [rsp+0xB0], xmm12
000071e7f4dde480  vmovaps [rsp+0xC0], xmm13
000071e7f4dde489  vmovaps [rsp+0xD0], xmm14
000071e7f4dde492  vmovaps [rsp+0xE0], xmm15
000071e7f4dde49b  sub rsp, 0x30
000071e7f4dde49f  movaps [rsp], xmm5
000071e7f4dde4a3  movaps [rsp+0x10], xmm6
000071e7f4dde4a8  movaps [rsp+0x20], xmm3
000071e7f4dde4ad  lea rdi, [rsp]
000071e7f4dde4b1  mov esi, 0x00
000071e7f4dde4b6  mov rax, 0x562A51E82530
000071e7f4dde4c0  call rax
000071e7f4dde4c2  movaps xmm5, [rsp]
000071e7f4dde4c6  add rsp, 0x30
000071e7f4dde4ca  vmovaps xmm0, [rsp]
000071e7f4dde4cf  vmovaps xmm1, [rsp+0x10]
000071e7f4dde4d5  vmovaps xmm2, [rsp+0x20]
000071e7f4dde4db  vmovaps xmm3, [rsp+0x30]
000071e7f4dde4e1  vmovaps xmm4, [rsp+0x40]
000071e7f4dde4e7  vmovaps xmm6, [rsp+0x50]
000071e7f4dde4ed  vmovaps xmm7, [rsp+0x60]
000071e7f4dde4f3  vmovaps xmm8, [rsp+0x70]
000071e7f4dde4f9  vmovaps xmm9, [rsp+0x80]
000071e7f4dde502  vmovaps xmm10, [rsp+0x90]
000071e7f4dde50b  vmovaps xmm11, [rsp+0xA0]
000071e7f4dde514  vmovaps xmm12, [rsp+0xB0]
000071e7f4dde51d  vmovaps xmm13, [rsp+0xC0]
000071e7f4dde526  vmovaps xmm14, [rsp+0xD0]
000071e7f4dde52f  vmovaps xmm15, [rsp+0xE0]
000071e7f4dde538  add rsp, 0xF0
000071e7f4dde53f  pop r11
000071e7f4dde541  pop r10
000071e7f4dde543  pop r9
000071e7f4dde545  pop r8
000071e7f4dde547  pop rsi
000071e7f4dde548  pop rdi
000071e7f4dde549  pop rdx
000071e7f4dde54a  pop rcx
000071e7f4dde54b  pop rax
000071e7f4dde54c  add rsp, 0x08
000071e7f4dde550  jmp 0x000071E7F4DDC13A
000071e7f4dde555  sub rsp, 0x08
000071e7f4dde559  push rax
000071e7f4dde55a  push rcx
000071e7f4dde55b  push rdx
000071e7f4dde55c  push rdi
000071e7f4dde55d  push rsi
000071e7f4dde55e  push r8
000071e7f4dde560  push r9
000071e7f4dde562  push r10
000071e7f4dde564  push r11
000071e7f4dde566  sub rsp, 0xF0
000071e7f4dde56d  vmovaps [rsp], xmm0
000071e7f4dde572  vmovaps [rsp+0x10], xmm1
000071e7f4dde578  vmovaps [rsp+0x20], xmm2
000071e7f4dde57e  vmovaps [rsp+0x30], xmm3
000071e7f4dde584  vmovaps [rsp+0x40], xmm4
000071e7f4dde58a  vmovaps [rsp+0x50], xmm5
000071e7f4dde590  vmovaps [rsp+0x60], xmm7
000071e7f4dde596  vmovaps [rsp+0x70], xmm8
000071e7f4dde59c  vmovaps [rsp+0x80], xmm9
000071e7f4dde5a5  vmovaps [rsp+0x90], xmm10
000071e7f4dde5ae  vmovaps [rsp+0xA0], xmm11
000071e7f4dde5b7  vmovaps [rsp+0xB0], xmm12
000071e7f4dde5c0  vmovaps [rsp+0xC0], xmm13
000071e7f4dde5c9  vmovaps [rsp+0xD0], xmm14
000071e7f4dde5d2  vmovaps [rsp+0xE0], xmm15
000071e7f4dde5db  sub rsp, 0x30
000071e7f4dde5df  movaps [rsp], xmm6
000071e7f4dde5e3  movaps [rsp+0x10], xmm9
000071e7f4dde5e9  movaps [rsp+0x20], xmm1
000071e7f4dde5ee  lea rdi, [rsp]
000071e7f4dde5f2  mov esi, 0x00
000071e7f4dde5f7  mov rax, 0x562A51E82530
000071e7f4dde601  call rax
000071e7f4dde603  movaps xmm6, [rsp]
000071e7f4dde607  add rsp, 0x30
000071e7f4dde60b  vmovaps xmm0, [rsp]
000071e7f4dde610  vmovaps xmm1, [rsp+0x10]
000071e7f4dde616  vmovaps xmm2, [rsp+0x20]
000071e7f4dde61c  vmovaps xmm3, [rsp+0x30]
000071e7f4dde622  vmovaps xmm4, [rsp+0x40]
000071e7f4dde628  vmovaps xmm5, [rsp+0x50]
000071e7f4dde62e  vmovaps xmm7, [rsp+0x60]
000071e7f4dde634  vmovaps xmm8, [rsp+0x70]
000071e7f4dde63a  vmovaps xmm9, [rsp+0x80]
000071e7f4dde643  vmovaps xmm10, [rsp+0x90]
000071e7f4dde64c  vmovaps xmm11, [rsp+0xA0]
000071e7f4dde655  vmovaps xmm12, [rsp+0xB0]
000071e7f4dde65e  vmovaps xmm13, [rsp+0xC0]
000071e7f4dde667  vmovaps xmm14, [rsp+0xD0]
000071e7f4dde670  vmovaps xmm15, [rsp+0xE0]
000071e7f4dde679  add rsp, 0xF0
000071e7f4dde680  pop r11
000071e7f4dde682  pop r10
000071e7f4dde684  pop r9
000071e7f4dde686  pop r8
000071e7f4dde688  pop rsi
000071e7f4dde689  pop rdi
000071e7f4dde68a  pop rdx
000071e7f4dde68b  pop rcx
000071e7f4dde68c  pop rax
000071e7f4dde68d  add rsp, 0x08
000071e7f4dde691  jmp 0x000071E7F4DDC15E
000071e7f4dde696  sub rsp, 0x08
000071e7f4dde69a  push rax
000071e7f4dde69b  push rcx
000071e7f4dde69c  push rdx
000071e7f4dde69d  push rdi
000071e7f4dde69e  push rsi
000071e7f4dde69f  push r8
000071e7f4dde6a1  push r9
000071e7f4dde6a3  push r10
000071e7f4dde6a5  push r11
000071e7f4dde6a7  sub rsp, 0xF0
000071e7f4dde6ae  vmovaps [rsp], xmm0
000071e7f4dde6b3  vmovaps [rsp+0x10], xmm1
000071e7f4dde6b9  vmovaps [rsp+0x20], xmm2
000071e7f4dde6bf  vmovaps [rsp+0x30], xmm3
000071e7f4dde6c5  vmovaps [rsp+0x40], xmm4
000071e7f4dde6cb  vmovaps [rsp+0x50], xmm5
000071e7f4dde6d1  vmovaps [rsp+0x60], xmm6
000071e7f4dde6d7  vmovaps [rsp+0x70], xmm7
000071e7f4dde6dd  vmovaps [rsp+0x80], xmm8
000071e7f4dde6e6  vmovaps [rsp+0x90], xmm10
000071e7f4dde6ef  vmovaps [rsp+0xA0], xmm11
000071e7f4dde6f8  vmovaps [rsp+0xB0], xmm12
000071e7f4dde701  vmovaps [rsp+0xC0], xmm13
000071e7f4dde70a  vmovaps [rsp+0xD0], xmm14
000071e7f4dde713  vmovaps [rsp+0xE0], xmm15
000071e7f4dde71c  sub rsp, 0x30
000071e7f4dde720  movaps [rsp], xmm9
000071e7f4dde725  movaps [rsp+0x10], xmm3
000071e7f4dde72a  movaps [rsp+0x20], xmm1
000071e7f4dde72f  lea rdi, [rsp]
000071e7f4dde733  mov esi, 0x00
000071e7f4dde738  mov rax, 0x562A51E82530
000071e7f4dde742  call rax
000071e7f4dde744  movaps xmm9, [rsp]
000071e7f4dde749  add rsp, 0x30
000071e7f4dde74d  vmovaps xmm0, [rsp]
000071e7f4dde752  vmovaps xmm1, [rsp+0x10]
000071e7f4dde758  vmovaps xmm2, [rsp+0x20]
000071e7f4dde75e  vmovaps xmm3, [rsp+0x30]
000071e7f4dde764  vmovaps xmm4, [rsp+0x40]
000071e7f4dde76a  vmovaps xmm5, [rsp+0x50]
000071e7f4dde770  vmovaps xmm6, [rsp+0x60]
000071e7f4dde776  vmovaps xmm7, [rsp+0x70]
000071e7f4dde77c  vmovaps xmm8, [rsp+0x80]
000071e7f4dde785  vmovaps xmm10, [rsp+0x90]
000071e7f4dde78e  vmovaps xmm11, [rsp+0xA0]
000071e7f4dde797  vmovaps xmm12, [rsp+0xB0]
000071e7f4dde7a0  vmovaps xmm13, [rsp+0xC0]
000071e7f4dde7a9  vmovaps xmm14, [rsp+0xD0]
000071e7f4dde7b2  vmovaps xmm15, [rsp+0xE0]
000071e7f4dde7bb  add rsp, 0xF0
000071e7f4dde7c2  pop r11
000071e7f4dde7c4  pop r10
000071e7f4dde7c6  pop r9
000071e7f4dde7c8  pop r8
000071e7f4dde7ca  pop rsi
000071e7f4dde7cb  pop rdi
000071e7f4dde7cc  pop rdx
000071e7f4dde7cd  pop rcx
000071e7f4dde7ce  pop rax
000071e7f4dde7cf  add rsp, 0x08
000071e7f4dde7d3  jmp 0x000071E7F4DDC1AA
000071e7f4dde7d8  call 0x000071E7F4CB52F0
000071e7f4dde7dd  jmp 0x000071E7F4DDC1B7
000071e7f4dde7e2  sub rsp, 0x08
000071e7f4dde7e6  push rax
000071e7f4dde7e7  push rcx
000071e7f4dde7e8  push rdx
000071e7f4dde7e9  push rdi
000071e7f4dde7ea  push rsi
000071e7f4dde7eb  push r8
000071e7f4dde7ed  push r9
000071e7f4dde7ef  push r10
000071e7f4dde7f1  push r11
000071e7f4dde7f3  sub rsp, 0xF0
000071e7f4dde7fa  vmovaps [rsp], xmm0
000071e7f4dde7ff  vmovaps [rsp+0x10], xmm1
000071e7f4dde805  vmovaps [rsp+0x20], xmm2
000071e7f4dde80b  vmovaps [rsp+0x30], xmm3
000071e7f4dde811  vmovaps [rsp+0x40], xmm4
000071e7f4dde817  vmovaps [rsp+0x50], xmm5
000071e7f4dde81d  vmovaps [rsp+0x60], xmm6
000071e7f4dde823  vmovaps [rsp+0x70], xmm7
000071e7f4dde829  vmovaps [rsp+0x80], xmm8
000071e7f4dde832  vmovaps [rsp+0x90], xmm9
000071e7f4dde83b  vmovaps [rsp+0xA0], xmm10
000071e7f4dde844  vmovaps [rsp+0xB0], xmm11
000071e7f4dde84d  vmovaps [rsp+0xC0], xmm12
000071e7f4dde856  vmovaps [rsp+0xD0], xmm13
000071e7f4dde85f  vmovaps [rsp+0xE0], xmm14
000071e7f4dde868  sub rsp, 0x30
000071e7f4dde86c  movaps [rsp], xmm15
000071e7f4dde871  movaps [rsp+0x10], xmm3
000071e7f4dde876  movaps [rsp+0x20], xmm7
000071e7f4dde87b  lea rdi, [rsp]
000071e7f4dde87f  mov esi, 0x00
000071e7f4dde884  mov rax, 0x562A51E82530
000071e7f4dde88e  call rax
000071e7f4dde890  movaps xmm15, [rsp]
000071e7f4dde895  add rsp, 0x30
000071e7f4dde899  vmovaps xmm0, [rsp]
000071e7f4dde89e  vmovaps xmm1, [rsp+0x10]
000071e7f4dde8a4  vmovaps xmm2, [rsp+0x20]
000071e7f4dde8aa  vmovaps xmm3, [rsp+0x30]
000071e7f4dde8b0  vmovaps xmm4, [rsp+0x40]
000071e7f4dde8b6  vmovaps xmm5, [rsp+0x50]
000071e7f4dde8bc  vmovaps xmm6, [rsp+0x60]
000071e7f4dde8c2  vmovaps xmm7, [rsp+0x70]
000071e7f4dde8c8  vmovaps xmm8, [rsp+0x80]
000071e7f4dde8d1  vmovaps xmm9, [rsp+0x90]
000071e7f4dde8da  vmovaps xmm10, [rsp+0xA0]
000071e7f4dde8e3  vmovaps xmm11, [rsp+0xB0]
000071e7f4dde8ec  vmovaps xmm12, [rsp+0xC0]
000071e7f4dde8f5  vmovaps xmm13, [rsp+0xD0]
000071e7f4dde8fe  vmovaps xmm14, [rsp+0xE0]
000071e7f4dde907  add rsp, 0xF0
000071e7f4dde90e  pop r11
000071e7f4dde910  pop r10
000071e7f4dde912  pop r9
000071e7f4dde914  pop r8
000071e7f4dde916  pop rsi
000071e7f4dde917  pop rdi
000071e7f4dde918  pop rdx
000071e7f4dde919  pop rcx
000071e7f4dde91a  pop rax
000071e7f4dde91b  add rsp, 0x08
000071e7f4dde91f  jmp 0x000071E7F4DDC1E3
000071e7f4dde924  sub rsp, 0x08
000071e7f4dde928  push rax
000071e7f4dde929  push rcx
000071e7f4dde92a  push rdx
000071e7f4dde92b  push rdi
000071e7f4dde92c  push rsi
000071e7f4dde92d  push r8
000071e7f4dde92f  push r9
000071e7f4dde931  push r10
000071e7f4dde933  push r11
000071e7f4dde935  sub rsp, 0xF0
000071e7f4dde93c  vmovaps [rsp], xmm0
000071e7f4dde941  vmovaps [rsp+0x10], xmm1
000071e7f4dde947  vmovaps [rsp+0x20], xmm2
000071e7f4dde94d  vmovaps [rsp+0x30], xmm4
000071e7f4dde953  vmovaps [rsp+0x40], xmm5
000071e7f4dde959  vmovaps [rsp+0x50], xmm6
000071e7f4dde95f  vmovaps [rsp+0x60], xmm7
000071e7f4dde965  vmovaps [rsp+0x70], xmm8
000071e7f4dde96b  vmovaps [rsp+0x80], xmm9
000071e7f4dde974  vmovaps [rsp+0x90], xmm10
000071e7f4dde97d  vmovaps [rsp+0xA0], xmm11
000071e7f4dde986  vmovaps [rsp+0xB0], xmm12
000071e7f4dde98f  vmovaps [rsp+0xC0], xmm13
000071e7f4dde998  vmovaps [rsp+0xD0], xmm14
000071e7f4dde9a1  vmovaps [rsp+0xE0], xmm15
000071e7f4dde9aa  sub rsp, 0x30
000071e7f4dde9ae  movaps [rsp], xmm3
000071e7f4dde9b2  movaps [rsp+0x10], xmm1
000071e7f4dde9b7  movaps [rsp+0x20], xmm15
000071e7f4dde9bd  lea rdi, [rsp]
000071e7f4dde9c1  mov esi, 0x00
000071e7f4dde9c6  mov rax, 0x562A51E82530
000071e7f4dde9d0  call rax
000071e7f4dde9d2  movaps xmm3, [rsp]
000071e7f4dde9d6  add rsp, 0x30
000071e7f4dde9da  vmovaps xmm0, [rsp]
000071e7f4dde9df  vmovaps xmm1, [rsp+0x10]
000071e7f4dde9e5  vmovaps xmm2, [rsp+0x20]
000071e7f4dde9eb  vmovaps xmm4, [rsp+0x30]
000071e7f4dde9f1  vmovaps xmm5, [rsp+0x40]
000071e7f4dde9f7  vmovaps xmm6, [rsp+0x50]
000071e7f4dde9fd  vmovaps xmm7, [rsp+0x60]
000071e7f4ddea03  vmovaps xmm8, [rsp+0x70]
000071e7f4ddea09  vmovaps xmm9, [rsp+0x80]
000071e7f4ddea12  vmovaps xmm10, [rsp+0x90]
000071e7f4ddea1b  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddea24  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddea2d  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddea36  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddea3f  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddea48  add rsp, 0xF0
000071e7f4ddea4f  pop r11
000071e7f4ddea51  pop r10
000071e7f4ddea53  pop r9
000071e7f4ddea55  pop r8
000071e7f4ddea57  pop rsi
000071e7f4ddea58  pop rdi
000071e7f4ddea59  pop rdx
000071e7f4ddea5a  pop rcx
000071e7f4ddea5b  pop rax
000071e7f4ddea5c  add rsp, 0x08
000071e7f4ddea60  jmp 0x000071E7F4DDC272
000071e7f4ddea65  call 0x000071E7F4CB52F0
000071e7f4ddea6a  jmp 0x000071E7F4DDC27C
000071e7f4ddea6f  sub rsp, 0x08
000071e7f4ddea73  push rax
000071e7f4ddea74  push rcx
000071e7f4ddea75  push rdx
000071e7f4ddea76  push rdi
000071e7f4ddea77  push rsi
000071e7f4ddea78  push r8
000071e7f4ddea7a  push r9
000071e7f4ddea7c  push r10
000071e7f4ddea7e  push r11
000071e7f4ddea80  sub rsp, 0xF0
000071e7f4ddea87  vmovaps [rsp], xmm0
000071e7f4ddea8c  vmovaps [rsp+0x10], xmm1
000071e7f4ddea92  vmovaps [rsp+0x20], xmm2
000071e7f4ddea98  vmovaps [rsp+0x30], xmm3
000071e7f4ddea9e  vmovaps [rsp+0x40], xmm4
000071e7f4ddeaa4  vmovaps [rsp+0x50], xmm5
000071e7f4ddeaaa  vmovaps [rsp+0x60], xmm6
000071e7f4ddeab0  vmovaps [rsp+0x70], xmm7
000071e7f4ddeab6  vmovaps [rsp+0x80], xmm8
000071e7f4ddeabf  vmovaps [rsp+0x90], xmm9
000071e7f4ddeac8  vmovaps [rsp+0xA0], xmm10
000071e7f4ddead1  vmovaps [rsp+0xB0], xmm11
000071e7f4ddeada  vmovaps [rsp+0xC0], xmm12
000071e7f4ddeae3  vmovaps [rsp+0xD0], xmm13
000071e7f4ddeaec  vmovaps [rsp+0xE0], xmm14
000071e7f4ddeaf5  sub rsp, 0x30
000071e7f4ddeaf9  movaps [rsp], xmm15
000071e7f4ddeafe  movaps [rsp+0x10], xmm14
000071e7f4ddeb04  movaps [rsp+0x20], xmm4
000071e7f4ddeb09  lea rdi, [rsp]
000071e7f4ddeb0d  mov esi, 0x00
000071e7f4ddeb12  mov rax, 0x562A51E82530
000071e7f4ddeb1c  call rax
000071e7f4ddeb1e  movaps xmm15, [rsp]
000071e7f4ddeb23  add rsp, 0x30
000071e7f4ddeb27  vmovaps xmm0, [rsp]
000071e7f4ddeb2c  vmovaps xmm1, [rsp+0x10]
000071e7f4ddeb32  vmovaps xmm2, [rsp+0x20]
000071e7f4ddeb38  vmovaps xmm3, [rsp+0x30]
000071e7f4ddeb3e  vmovaps xmm4, [rsp+0x40]
000071e7f4ddeb44  vmovaps xmm5, [rsp+0x50]
000071e7f4ddeb4a  vmovaps xmm6, [rsp+0x60]
000071e7f4ddeb50  vmovaps xmm7, [rsp+0x70]
000071e7f4ddeb56  vmovaps xmm8, [rsp+0x80]
000071e7f4ddeb5f  vmovaps xmm9, [rsp+0x90]
000071e7f4ddeb68  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddeb71  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddeb7a  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddeb83  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddeb8c  vmovaps xmm14, [rsp+0xE0]
000071e7f4ddeb95  add rsp, 0xF0
000071e7f4ddeb9c  pop r11
000071e7f4ddeb9e  pop r10
000071e7f4ddeba0  pop r9
000071e7f4ddeba2  pop r8
000071e7f4ddeba4  pop rsi
000071e7f4ddeba5  pop rdi
000071e7f4ddeba6  pop rdx
000071e7f4ddeba7  pop rcx
000071e7f4ddeba8  pop rax
000071e7f4ddeba9  add rsp, 0x08
000071e7f4ddebad  jmp 0x000071E7F4DDC2AA
000071e7f4ddebb2  sub rsp, 0x08
000071e7f4ddebb6  push rax
000071e7f4ddebb7  push rcx
000071e7f4ddebb8  push rdx
000071e7f4ddebb9  push rdi
000071e7f4ddebba  push rsi
000071e7f4ddebbb  push r8
000071e7f4ddebbd  push r9
000071e7f4ddebbf  push r10
000071e7f4ddebc1  push r11
000071e7f4ddebc3  sub rsp, 0xF0
000071e7f4ddebca  vmovaps [rsp], xmm0
000071e7f4ddebcf  vmovaps [rsp+0x10], xmm1
000071e7f4ddebd5  vmovaps [rsp+0x20], xmm2
000071e7f4ddebdb  vmovaps [rsp+0x30], xmm3
000071e7f4ddebe1  vmovaps [rsp+0x40], xmm4
000071e7f4ddebe7  vmovaps [rsp+0x50], xmm5
000071e7f4ddebed  vmovaps [rsp+0x60], xmm6
000071e7f4ddebf3  vmovaps [rsp+0x70], xmm7
000071e7f4ddebf9  vmovaps [rsp+0x80], xmm8
000071e7f4ddec02  vmovaps [rsp+0x90], xmm9
000071e7f4ddec0b  vmovaps [rsp+0xA0], xmm10
000071e7f4ddec14  vmovaps [rsp+0xB0], xmm11
000071e7f4ddec1d  vmovaps [rsp+0xC0], xmm12
000071e7f4ddec26  vmovaps [rsp+0xD0], xmm13
000071e7f4ddec2f  vmovaps [rsp+0xE0], xmm15
000071e7f4ddec38  sub rsp, 0x30
000071e7f4ddec3c  movaps [rsp], xmm14
000071e7f4ddec41  movaps [rsp+0x10], xmm2
000071e7f4ddec46  movaps [rsp+0x20], xmm1
000071e7f4ddec4b  lea rdi, [rsp]
000071e7f4ddec4f  mov esi, 0x00
000071e7f4ddec54  mov rax, 0x562A51E82530
000071e7f4ddec5e  call rax
000071e7f4ddec60  movaps xmm14, [rsp]
000071e7f4ddec65  add rsp, 0x30
000071e7f4ddec69  vmovaps xmm0, [rsp]
000071e7f4ddec6e  vmovaps xmm1, [rsp+0x10]
000071e7f4ddec74  vmovaps xmm2, [rsp+0x20]
000071e7f4ddec7a  vmovaps xmm3, [rsp+0x30]
000071e7f4ddec80  vmovaps xmm4, [rsp+0x40]
000071e7f4ddec86  vmovaps xmm5, [rsp+0x50]
000071e7f4ddec8c  vmovaps xmm6, [rsp+0x60]
000071e7f4ddec92  vmovaps xmm7, [rsp+0x70]
000071e7f4ddec98  vmovaps xmm8, [rsp+0x80]
000071e7f4ddeca1  vmovaps xmm9, [rsp+0x90]
000071e7f4ddecaa  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddecb3  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddecbc  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddecc5  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddecce  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddecd7  add rsp, 0xF0
000071e7f4ddecde  pop r11
000071e7f4ddece0  pop r10
000071e7f4ddece2  pop r9
000071e7f4ddece4  pop r8
000071e7f4ddece6  pop rsi
000071e7f4ddece7  pop rdi
000071e7f4ddece8  pop rdx
000071e7f4ddece9  pop rcx
000071e7f4ddecea  pop rax
000071e7f4ddeceb  add rsp, 0x08
000071e7f4ddecef  jmp 0x000071E7F4DDC2D0
000071e7f4ddecf4  sub rsp, 0x08
000071e7f4ddecf8  push rax
000071e7f4ddecf9  push rcx
000071e7f4ddecfa  push rdx
000071e7f4ddecfb  push rdi
000071e7f4ddecfc  push rsi
000071e7f4ddecfd  push r8
000071e7f4ddecff  push r9
000071e7f4dded01  push r10
000071e7f4dded03  push r11
000071e7f4dded05  sub rsp, 0xF0
000071e7f4dded0c  vmovaps [rsp], xmm0
000071e7f4dded11  vmovaps [rsp+0x10], xmm2
000071e7f4dded17  vmovaps [rsp+0x20], xmm3
000071e7f4dded1d  vmovaps [rsp+0x30], xmm4
000071e7f4dded23  vmovaps [rsp+0x40], xmm5
000071e7f4dded29  vmovaps [rsp+0x50], xmm6
000071e7f4dded2f  vmovaps [rsp+0x60], xmm7
000071e7f4dded35  vmovaps [rsp+0x70], xmm8
000071e7f4dded3b  vmovaps [rsp+0x80], xmm9
000071e7f4dded44  vmovaps [rsp+0x90], xmm10
000071e7f4dded4d  vmovaps [rsp+0xA0], xmm11
000071e7f4dded56  vmovaps [rsp+0xB0], xmm12
000071e7f4dded5f  vmovaps [rsp+0xC0], xmm13
000071e7f4dded68  vmovaps [rsp+0xD0], xmm14
000071e7f4dded71  vmovaps [rsp+0xE0], xmm15
000071e7f4dded7a  sub rsp, 0x30
000071e7f4dded7e  movaps [rsp], xmm1
000071e7f4dded82  movaps [rsp+0x10], xmm4
000071e7f4dded87  movaps [rsp+0x20], xmm9
000071e7f4dded8d  lea rdi, [rsp]
000071e7f4dded91  mov esi, 0x00
000071e7f4dded96  mov rax, 0x562A51E82530
000071e7f4ddeda0  call rax
000071e7f4ddeda2  movaps xmm1, [rsp]
000071e7f4ddeda6  add rsp, 0x30
000071e7f4ddedaa  vmovaps xmm0, [rsp]
000071e7f4ddedaf  vmovaps xmm2, [rsp+0x10]
000071e7f4ddedb5  vmovaps xmm3, [rsp+0x20]
000071e7f4ddedbb  vmovaps xmm4, [rsp+0x30]
000071e7f4ddedc1  vmovaps xmm5, [rsp+0x40]
000071e7f4ddedc7  vmovaps xmm6, [rsp+0x50]
000071e7f4ddedcd  vmovaps xmm7, [rsp+0x60]
000071e7f4ddedd3  vmovaps xmm8, [rsp+0x70]
000071e7f4ddedd9  vmovaps xmm9, [rsp+0x80]
000071e7f4ddede2  vmovaps xmm10, [rsp+0x90]
000071e7f4ddedeb  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddedf4  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddedfd  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddee06  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddee0f  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddee18  add rsp, 0xF0
000071e7f4ddee1f  pop r11
000071e7f4ddee21  pop r10
000071e7f4ddee23  pop r9
000071e7f4ddee25  pop r8
000071e7f4ddee27  pop rsi
000071e7f4ddee28  pop rdi
000071e7f4ddee29  pop rdx
000071e7f4ddee2a  pop rcx
000071e7f4ddee2b  pop rax
000071e7f4ddee2c  add rsp, 0x08
000071e7f4ddee30  jmp 0x000071E7F4DDC2EE
000071e7f4ddee35  sub rsp, 0x08
000071e7f4ddee39  push rax
000071e7f4ddee3a  push rcx
000071e7f4ddee3b  push rdx
000071e7f4ddee3c  push rdi
000071e7f4ddee3d  push rsi
000071e7f4ddee3e  push r8
000071e7f4ddee40  push r9
000071e7f4ddee42  push r10
000071e7f4ddee44  push r11
000071e7f4ddee46  sub rsp, 0xF0
000071e7f4ddee4d  vmovaps [rsp], xmm0
000071e7f4ddee52  vmovaps [rsp+0x10], xmm1
000071e7f4ddee58  vmovaps [rsp+0x20], xmm2
000071e7f4ddee5e  vmovaps [rsp+0x30], xmm3
000071e7f4ddee64  vmovaps [rsp+0x40], xmm5
000071e7f4ddee6a  vmovaps [rsp+0x50], xmm6
000071e7f4ddee70  vmovaps [rsp+0x60], xmm7
000071e7f4ddee76  vmovaps [rsp+0x70], xmm8
000071e7f4ddee7c  vmovaps [rsp+0x80], xmm9
000071e7f4ddee85  vmovaps [rsp+0x90], xmm10
000071e7f4ddee8e  vmovaps [rsp+0xA0], xmm11
000071e7f4ddee97  vmovaps [rsp+0xB0], xmm12
000071e7f4ddeea0  vmovaps [rsp+0xC0], xmm13
000071e7f4ddeea9  vmovaps [rsp+0xD0], xmm14
000071e7f4ddeeb2  vmovaps [rsp+0xE0], xmm15
000071e7f4ddeebb  sub rsp, 0x30
000071e7f4ddeebf  movaps [rsp], xmm4
000071e7f4ddeec3  movaps [rsp+0x10], xmm2
000071e7f4ddeec8  movaps [rsp+0x20], xmm9
000071e7f4ddeece  lea rdi, [rsp]
000071e7f4ddeed2  mov esi, 0x00
000071e7f4ddeed7  mov rax, 0x562A51E82530
000071e7f4ddeee1  call rax
000071e7f4ddeee3  movaps xmm4, [rsp]
000071e7f4ddeee7  add rsp, 0x30
000071e7f4ddeeeb  vmovaps xmm0, [rsp]
000071e7f4ddeef0  vmovaps xmm1, [rsp+0x10]
000071e7f4ddeef6  vmovaps xmm2, [rsp+0x20]
000071e7f4ddeefc  vmovaps xmm3, [rsp+0x30]
000071e7f4ddef02  vmovaps xmm5, [rsp+0x40]
000071e7f4ddef08  vmovaps xmm6, [rsp+0x50]
000071e7f4ddef0e  vmovaps xmm7, [rsp+0x60]
000071e7f4ddef14  vmovaps xmm8, [rsp+0x70]
000071e7f4ddef1a  vmovaps xmm9, [rsp+0x80]
000071e7f4ddef23  vmovaps xmm10, [rsp+0x90]
000071e7f4ddef2c  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddef35  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddef3e  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddef47  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddef50  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddef59  add rsp, 0xF0
000071e7f4ddef60  pop r11
000071e7f4ddef62  pop r10
000071e7f4ddef64  pop r9
000071e7f4ddef66  pop r8
000071e7f4ddef68  pop rsi
000071e7f4ddef69  pop rdi
000071e7f4ddef6a  pop rdx
000071e7f4ddef6b  pop rcx
000071e7f4ddef6c  pop rax
000071e7f4ddef6d  add rsp, 0x08
000071e7f4ddef71  jmp 0x000071E7F4DDC31E
000071e7f4ddef76  sub rsp, 0x08
000071e7f4ddef7a  push rax
000071e7f4ddef7b  push rcx
000071e7f4ddef7c  push rdx
000071e7f4ddef7d  push rdi
000071e7f4ddef7e  push rsi
000071e7f4ddef7f  push r8
000071e7f4ddef81  push r9
000071e7f4ddef83  push r10
000071e7f4ddef85  push r11
000071e7f4ddef87  sub rsp, 0xF0
000071e7f4ddef8e  vmovaps [rsp], xmm0
000071e7f4ddef93  vmovaps [rsp+0x10], xmm1
000071e7f4ddef99  vmovaps [rsp+0x20], xmm2
000071e7f4ddef9f  vmovaps [rsp+0x30], xmm3
000071e7f4ddefa5  vmovaps [rsp+0x40], xmm4
000071e7f4ddefab  vmovaps [rsp+0x50], xmm5
000071e7f4ddefb1  vmovaps [rsp+0x60], xmm6
000071e7f4ddefb7  vmovaps [rsp+0x70], xmm7
000071e7f4ddefbd  vmovaps [rsp+0x80], xmm8
000071e7f4ddefc6  vmovaps [rsp+0x90], xmm10
000071e7f4ddefcf  vmovaps [rsp+0xA0], xmm11
000071e7f4ddefd8  vmovaps [rsp+0xB0], xmm12
000071e7f4ddefe1  vmovaps [rsp+0xC0], xmm13
000071e7f4ddefea  vmovaps [rsp+0xD0], xmm14
000071e7f4ddeff3  vmovaps [rsp+0xE0], xmm15
000071e7f4ddeffc  sub rsp, 0x30
000071e7f4ddf000  movaps [rsp], xmm9
000071e7f4ddf005  movaps [rsp+0x10], xmm2
000071e7f4ddf00a  movaps [rsp+0x20], xmm1
000071e7f4ddf00f  lea rdi, [rsp]
000071e7f4ddf013  mov esi, 0x00
000071e7f4ddf018  mov rax, 0x562A51E82530
000071e7f4ddf022  call rax
000071e7f4ddf024  movaps xmm9, [rsp]
000071e7f4ddf029  add rsp, 0x30
000071e7f4ddf02d  vmovaps xmm0, [rsp]
000071e7f4ddf032  vmovaps xmm1, [rsp+0x10]
000071e7f4ddf038  vmovaps xmm2, [rsp+0x20]
000071e7f4ddf03e  vmovaps xmm3, [rsp+0x30]
000071e7f4ddf044  vmovaps xmm4, [rsp+0x40]
000071e7f4ddf04a  vmovaps xmm5, [rsp+0x50]
000071e7f4ddf050  vmovaps xmm6, [rsp+0x60]
000071e7f4ddf056  vmovaps xmm7, [rsp+0x70]
000071e7f4ddf05c  vmovaps xmm8, [rsp+0x80]
000071e7f4ddf065  vmovaps xmm10, [rsp+0x90]
000071e7f4ddf06e  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddf077  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddf080  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddf089  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddf092  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddf09b  add rsp, 0xF0
000071e7f4ddf0a2  pop r11
000071e7f4ddf0a4  pop r10
000071e7f4ddf0a6  pop r9
000071e7f4ddf0a8  pop r8
000071e7f4ddf0aa  pop rsi
000071e7f4ddf0ab  pop rdi
000071e7f4ddf0ac  pop rdx
000071e7f4ddf0ad  pop rcx
000071e7f4ddf0ae  pop rax
000071e7f4ddf0af  add rsp, 0x08
000071e7f4ddf0b3  jmp 0x000071E7F4DDC354
000071e7f4ddf0b8  sub rsp, 0x08
000071e7f4ddf0bc  push rax
000071e7f4ddf0bd  push rcx
000071e7f4ddf0be  push rdx
000071e7f4ddf0bf  push rdi
000071e7f4ddf0c0  push rsi
000071e7f4ddf0c1  push r8
000071e7f4ddf0c3  push r9
000071e7f4ddf0c5  push r10
000071e7f4ddf0c7  push r11
000071e7f4ddf0c9  sub rsp, 0xF0
000071e7f4ddf0d0  vmovaps [rsp], xmm0
000071e7f4ddf0d5  vmovaps [rsp+0x10], xmm2
000071e7f4ddf0db  vmovaps [rsp+0x20], xmm3
000071e7f4ddf0e1  vmovaps [rsp+0x30], xmm4
000071e7f4ddf0e7  vmovaps [rsp+0x40], xmm5
000071e7f4ddf0ed  vmovaps [rsp+0x50], xmm6
000071e7f4ddf0f3  vmovaps [rsp+0x60], xmm7
000071e7f4ddf0f9  vmovaps [rsp+0x70], xmm8
000071e7f4ddf0ff  vmovaps [rsp+0x80], xmm9
000071e7f4ddf108  vmovaps [rsp+0x90], xmm10
000071e7f4ddf111  vmovaps [rsp+0xA0], xmm11
000071e7f4ddf11a  vmovaps [rsp+0xB0], xmm12
000071e7f4ddf123  vmovaps [rsp+0xC0], xmm13
000071e7f4ddf12c  vmovaps [rsp+0xD0], xmm14
000071e7f4ddf135  vmovaps [rsp+0xE0], xmm15
000071e7f4ddf13e  sub rsp, 0x30
000071e7f4ddf142  movaps [rsp], xmm1
000071e7f4ddf146  movaps [rsp+0x10], xmm15
000071e7f4ddf14c  movaps [rsp+0x20], xmm6
000071e7f4ddf151  lea rdi, [rsp]
000071e7f4ddf155  mov esi, 0x00
000071e7f4ddf15a  mov rax, 0x562A51E82530
000071e7f4ddf164  call rax
000071e7f4ddf166  movaps xmm1, [rsp]
000071e7f4ddf16a  add rsp, 0x30
000071e7f4ddf16e  vmovaps xmm0, [rsp]
000071e7f4ddf173  vmovaps xmm2, [rsp+0x10]
000071e7f4ddf179  vmovaps xmm3, [rsp+0x20]
000071e7f4ddf17f  vmovaps xmm4, [rsp+0x30]
000071e7f4ddf185  vmovaps xmm5, [rsp+0x40]
000071e7f4ddf18b  vmovaps xmm6, [rsp+0x50]
000071e7f4ddf191  vmovaps xmm7, [rsp+0x60]
000071e7f4ddf197  vmovaps xmm8, [rsp+0x70]
000071e7f4ddf19d  vmovaps xmm9, [rsp+0x80]
000071e7f4ddf1a6  vmovaps xmm10, [rsp+0x90]
000071e7f4ddf1af  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddf1b8  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddf1c1  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddf1ca  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddf1d3  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddf1dc  add rsp, 0xF0
000071e7f4ddf1e3  pop r11
000071e7f4ddf1e5  pop r10
000071e7f4ddf1e7  pop r9
000071e7f4ddf1e9  pop r8
000071e7f4ddf1eb  pop rsi
000071e7f4ddf1ec  pop rdi
000071e7f4ddf1ed  pop rdx
000071e7f4ddf1ee  pop rcx
000071e7f4ddf1ef  pop rax
000071e7f4ddf1f0  add rsp, 0x08
000071e7f4ddf1f4  jmp 0x000071E7F4DDC375
000071e7f4ddf1f9  sub rsp, 0x08
000071e7f4ddf1fd  push rax
000071e7f4ddf1fe  push rcx
000071e7f4ddf1ff  push rdx
000071e7f4ddf200  push rdi
000071e7f4ddf201  push rsi
000071e7f4ddf202  push r8
000071e7f4ddf204  push r9
000071e7f4ddf206  push r10
000071e7f4ddf208  push r11
000071e7f4ddf20a  sub rsp, 0xF0
000071e7f4ddf211  vmovaps [rsp], xmm0
000071e7f4ddf216  vmovaps [rsp+0x10], xmm1
000071e7f4ddf21c  vmovaps [rsp+0x20], xmm2
000071e7f4ddf222  vmovaps [rsp+0x30], xmm3
000071e7f4ddf228  vmovaps [rsp+0x40], xmm4
000071e7f4ddf22e  vmovaps [rsp+0x50], xmm5
000071e7f4ddf234  vmovaps [rsp+0x60], xmm6
000071e7f4ddf23a  vmovaps [rsp+0x70], xmm7
000071e7f4ddf240  vmovaps [rsp+0x80], xmm8
000071e7f4ddf249  vmovaps [rsp+0x90], xmm9
000071e7f4ddf252  vmovaps [rsp+0xA0], xmm10
000071e7f4ddf25b  vmovaps [rsp+0xB0], xmm11
000071e7f4ddf264  vmovaps [rsp+0xC0], xmm12
000071e7f4ddf26d  vmovaps [rsp+0xD0], xmm13
000071e7f4ddf276  vmovaps [rsp+0xE0], xmm14
000071e7f4ddf27f  sub rsp, 0x30
000071e7f4ddf283  movaps [rsp], xmm15
000071e7f4ddf288  movaps [rsp+0x10], xmm5
000071e7f4ddf28d  movaps [rsp+0x20], xmm3
000071e7f4ddf292  lea rdi, [rsp]
000071e7f4ddf296  mov esi, 0x00
000071e7f4ddf29b  mov rax, 0x562A51E82530
000071e7f4ddf2a5  call rax
000071e7f4ddf2a7  movaps xmm15, [rsp]
000071e7f4ddf2ac  add rsp, 0x30
000071e7f4ddf2b0  vmovaps xmm0, [rsp]
000071e7f4ddf2b5  vmovaps xmm1, [rsp+0x10]
000071e7f4ddf2bb  vmovaps xmm2, [rsp+0x20]
000071e7f4ddf2c1  vmovaps xmm3, [rsp+0x30]
000071e7f4ddf2c7  vmovaps xmm4, [rsp+0x40]
000071e7f4ddf2cd  vmovaps xmm5, [rsp+0x50]
000071e7f4ddf2d3  vmovaps xmm6, [rsp+0x60]
000071e7f4ddf2d9  vmovaps xmm7, [rsp+0x70]
000071e7f4ddf2df  vmovaps xmm8, [rsp+0x80]
000071e7f4ddf2e8  vmovaps xmm9, [rsp+0x90]
000071e7f4ddf2f1  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddf2fa  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddf303  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddf30c  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddf315  vmovaps xmm14, [rsp+0xE0]
000071e7f4ddf31e  add rsp, 0xF0
000071e7f4ddf325  pop r11
000071e7f4ddf327  pop r10
000071e7f4ddf329  pop r9
000071e7f4ddf32b  pop r8
000071e7f4ddf32d  pop rsi
000071e7f4ddf32e  pop rdi
000071e7f4ddf32f  pop rdx
000071e7f4ddf330  pop rcx
000071e7f4ddf331  pop rax
000071e7f4ddf332  add rsp, 0x08
000071e7f4ddf336  jmp 0x000071E7F4DDC38F
000071e7f4ddf33b  sub rsp, 0x08
000071e7f4ddf33f  push rax
000071e7f4ddf340  push rcx
000071e7f4ddf341  push rdx
000071e7f4ddf342  push rdi
000071e7f4ddf343  push rsi
000071e7f4ddf344  push r8
000071e7f4ddf346  push r9
000071e7f4ddf348  push r10
000071e7f4ddf34a  push r11
000071e7f4ddf34c  sub rsp, 0xF0
000071e7f4ddf353  vmovaps [rsp], xmm0
000071e7f4ddf358  vmovaps [rsp+0x10], xmm1
000071e7f4ddf35e  vmovaps [rsp+0x20], xmm2
000071e7f4ddf364  vmovaps [rsp+0x30], xmm3
000071e7f4ddf36a  vmovaps [rsp+0x40], xmm4
000071e7f4ddf370  vmovaps [rsp+0x50], xmm6
000071e7f4ddf376  vmovaps [rsp+0x60], xmm7
000071e7f4ddf37c  vmovaps [rsp+0x70], xmm8
000071e7f4ddf382  vmovaps [rsp+0x80], xmm9
000071e7f4ddf38b  vmovaps [rsp+0x90], xmm10
000071e7f4ddf394  vmovaps [rsp+0xA0], xmm11
000071e7f4ddf39d  vmovaps [rsp+0xB0], xmm12
000071e7f4ddf3a6  vmovaps [rsp+0xC0], xmm13
000071e7f4ddf3af  vmovaps [rsp+0xD0], xmm14
000071e7f4ddf3b8  vmovaps [rsp+0xE0], xmm15
000071e7f4ddf3c1  sub rsp, 0x30
000071e7f4ddf3c5  movaps [rsp], xmm5
000071e7f4ddf3c9  movaps [rsp+0x10], xmm8
000071e7f4ddf3cf  movaps [rsp+0x20], xmm6
000071e7f4ddf3d4  lea rdi, [rsp]
000071e7f4ddf3d8  mov esi, 0x00
000071e7f4ddf3dd  mov rax, 0x562A51E82530
000071e7f4ddf3e7  call rax
000071e7f4ddf3e9  movaps xmm5, [rsp]
000071e7f4ddf3ed  add rsp, 0x30
000071e7f4ddf3f1  vmovaps xmm0, [rsp]
000071e7f4ddf3f6  vmovaps xmm1, [rsp+0x10]
000071e7f4ddf3fc  vmovaps xmm2, [rsp+0x20]
000071e7f4ddf402  vmovaps xmm3, [rsp+0x30]
000071e7f4ddf408  vmovaps xmm4, [rsp+0x40]
000071e7f4ddf40e  vmovaps xmm6, [rsp+0x50]
000071e7f4ddf414  vmovaps xmm7, [rsp+0x60]
000071e7f4ddf41a  vmovaps xmm8, [rsp+0x70]
000071e7f4ddf420  vmovaps xmm9, [rsp+0x80]
000071e7f4ddf429  vmovaps xmm10, [rsp+0x90]
000071e7f4ddf432  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddf43b  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddf444  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddf44d  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddf456  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddf45f  add rsp, 0xF0
000071e7f4ddf466  pop r11
000071e7f4ddf468  pop r10
000071e7f4ddf46a  pop r9
000071e7f4ddf46c  pop r8
000071e7f4ddf46e  pop rsi
000071e7f4ddf46f  pop rdi
000071e7f4ddf470  pop rdx
000071e7f4ddf471  pop rcx
000071e7f4ddf472  pop rax
000071e7f4ddf473  add rsp, 0x08
000071e7f4ddf477  jmp 0x000071E7F4DDC3B3
000071e7f4ddf47c  sub rsp, 0x08
000071e7f4ddf480  push rax
000071e7f4ddf481  push rcx
000071e7f4ddf482  push rdx
000071e7f4ddf483  push rdi
000071e7f4ddf484  push rsi
000071e7f4ddf485  push r8
000071e7f4ddf487  push r9
000071e7f4ddf489  push r10
000071e7f4ddf48b  push r11
000071e7f4ddf48d  sub rsp, 0xF0
000071e7f4ddf494  vmovaps [rsp], xmm0
000071e7f4ddf499  vmovaps [rsp+0x10], xmm1
000071e7f4ddf49f  vmovaps [rsp+0x20], xmm2
000071e7f4ddf4a5  vmovaps [rsp+0x30], xmm3
000071e7f4ddf4ab  vmovaps [rsp+0x40], xmm4
000071e7f4ddf4b1  vmovaps [rsp+0x50], xmm5
000071e7f4ddf4b7  vmovaps [rsp+0x60], xmm7
000071e7f4ddf4bd  vmovaps [rsp+0x70], xmm8
000071e7f4ddf4c3  vmovaps [rsp+0x80], xmm9
000071e7f4ddf4cc  vmovaps [rsp+0x90], xmm10
000071e7f4ddf4d5  vmovaps [rsp+0xA0], xmm11
000071e7f4ddf4de  vmovaps [rsp+0xB0], xmm12
000071e7f4ddf4e7  vmovaps [rsp+0xC0], xmm13
000071e7f4ddf4f0  vmovaps [rsp+0xD0], xmm14
000071e7f4ddf4f9  vmovaps [rsp+0xE0], xmm15
000071e7f4ddf502  sub rsp, 0x30
000071e7f4ddf506  movaps [rsp], xmm6
000071e7f4ddf50a  movaps [rsp+0x10], xmm10
000071e7f4ddf510  movaps [rsp+0x20], xmm8
000071e7f4ddf516  lea rdi, [rsp]
000071e7f4ddf51a  mov esi, 0x00
000071e7f4ddf51f  mov rax, 0x562A51E82530
000071e7f4ddf529  call rax
000071e7f4ddf52b  movaps xmm6, [rsp]
000071e7f4ddf52f  add rsp, 0x30
000071e7f4ddf533  vmovaps xmm0, [rsp]
000071e7f4ddf538  vmovaps xmm1, [rsp+0x10]
000071e7f4ddf53e  vmovaps xmm2, [rsp+0x20]
000071e7f4ddf544  vmovaps xmm3, [rsp+0x30]
000071e7f4ddf54a  vmovaps xmm4, [rsp+0x40]
000071e7f4ddf550  vmovaps xmm5, [rsp+0x50]
000071e7f4ddf556  vmovaps xmm7, [rsp+0x60]
000071e7f4ddf55c  vmovaps xmm8, [rsp+0x70]
000071e7f4ddf562  vmovaps xmm9, [rsp+0x80]
000071e7f4ddf56b  vmovaps xmm10, [rsp+0x90]
000071e7f4ddf574  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddf57d  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddf586  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddf58f  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddf598  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddf5a1  add rsp, 0xF0
000071e7f4ddf5a8  pop r11
000071e7f4ddf5aa  pop r10
000071e7f4ddf5ac  pop r9
000071e7f4ddf5ae  pop r8
000071e7f4ddf5b0  pop rsi
000071e7f4ddf5b1  pop rdi
000071e7f4ddf5b2  pop rdx
000071e7f4ddf5b3  pop rcx
000071e7f4ddf5b4  pop rax
000071e7f4ddf5b5  add rsp, 0x08
000071e7f4ddf5b9  jmp 0x000071E7F4DDC3D8
000071e7f4ddf5be  sub rsp, 0x08
000071e7f4ddf5c2  push rax
000071e7f4ddf5c3  push rcx
000071e7f4ddf5c4  push rdx
000071e7f4ddf5c5  push rdi
000071e7f4ddf5c6  push rsi
000071e7f4ddf5c7  push r8
000071e7f4ddf5c9  push r9
000071e7f4ddf5cb  push r10
000071e7f4ddf5cd  push r11
000071e7f4ddf5cf  sub rsp, 0xF0
000071e7f4ddf5d6  vmovaps [rsp], xmm0
000071e7f4ddf5db  vmovaps [rsp+0x10], xmm1
000071e7f4ddf5e1  vmovaps [rsp+0x20], xmm2
000071e7f4ddf5e7  vmovaps [rsp+0x30], xmm3
000071e7f4ddf5ed  vmovaps [rsp+0x40], xmm4
000071e7f4ddf5f3  vmovaps [rsp+0x50], xmm5
000071e7f4ddf5f9  vmovaps [rsp+0x60], xmm6
000071e7f4ddf5ff  vmovaps [rsp+0x70], xmm7
000071e7f4ddf605  vmovaps [rsp+0x80], xmm8
000071e7f4ddf60e  vmovaps [rsp+0x90], xmm9
000071e7f4ddf617  vmovaps [rsp+0xA0], xmm11
000071e7f4ddf620  vmovaps [rsp+0xB0], xmm12
000071e7f4ddf629  vmovaps [rsp+0xC0], xmm13
000071e7f4ddf632  vmovaps [rsp+0xD0], xmm14
000071e7f4ddf63b  vmovaps [rsp+0xE0], xmm15
000071e7f4ddf644  sub rsp, 0x30
000071e7f4ddf648  movaps [rsp], xmm10
000071e7f4ddf64d  movaps [rsp+0x10], xmm8
000071e7f4ddf653  movaps [rsp+0x20], xmm14
000071e7f4ddf659  lea rdi, [rsp]
000071e7f4ddf65d  mov esi, 0x00
000071e7f4ddf662  mov rax, 0x562A51E82530
000071e7f4ddf66c  call rax
000071e7f4ddf66e  movaps xmm10, [rsp]
000071e7f4ddf673  add rsp, 0x30
000071e7f4ddf677  vmovaps xmm0, [rsp]
000071e7f4ddf67c  vmovaps xmm1, [rsp+0x10]
000071e7f4ddf682  vmovaps xmm2, [rsp+0x20]
000071e7f4ddf688  vmovaps xmm3, [rsp+0x30]
000071e7f4ddf68e  vmovaps xmm4, [rsp+0x40]
000071e7f4ddf694  vmovaps xmm5, [rsp+0x50]
000071e7f4ddf69a  vmovaps xmm6, [rsp+0x60]
000071e7f4ddf6a0  vmovaps xmm7, [rsp+0x70]
000071e7f4ddf6a6  vmovaps xmm8, [rsp+0x80]
000071e7f4ddf6af  vmovaps xmm9, [rsp+0x90]
000071e7f4ddf6b8  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddf6c1  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddf6ca  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddf6d3  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddf6dc  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddf6e5  add rsp, 0xF0
000071e7f4ddf6ec  pop r11
000071e7f4ddf6ee  pop r10
000071e7f4ddf6f0  pop r9
000071e7f4ddf6f2  pop r8
000071e7f4ddf6f4  pop rsi
000071e7f4ddf6f5  pop rdi
000071e7f4ddf6f6  pop rdx
000071e7f4ddf6f7  pop rcx
000071e7f4ddf6f8  pop rax
000071e7f4ddf6f9  add rsp, 0x08
000071e7f4ddf6fd  jmp 0x000071E7F4DDC3F8
000071e7f4ddf702  sub rsp, 0x08
000071e7f4ddf706  push rax
000071e7f4ddf707  push rcx
000071e7f4ddf708  push rdx
000071e7f4ddf709  push rdi
000071e7f4ddf70a  push rsi
000071e7f4ddf70b  push r8
000071e7f4ddf70d  push r9
000071e7f4ddf70f  push r10
000071e7f4ddf711  push r11
000071e7f4ddf713  sub rsp, 0xF0
000071e7f4ddf71a  vmovaps [rsp], xmm0
000071e7f4ddf71f  vmovaps [rsp+0x10], xmm1
000071e7f4ddf725  vmovaps [rsp+0x20], xmm2
000071e7f4ddf72b  vmovaps [rsp+0x30], xmm3
000071e7f4ddf731  vmovaps [rsp+0x40], xmm4
000071e7f4ddf737  vmovaps [rsp+0x50], xmm5
000071e7f4ddf73d  vmovaps [rsp+0x60], xmm6
000071e7f4ddf743  vmovaps [rsp+0x70], xmm7
000071e7f4ddf749  vmovaps [rsp+0x80], xmm8
000071e7f4ddf752  vmovaps [rsp+0x90], xmm9
000071e7f4ddf75b  vmovaps [rsp+0xA0], xmm10
000071e7f4ddf764  vmovaps [rsp+0xB0], xmm11
000071e7f4ddf76d  vmovaps [rsp+0xC0], xmm12
000071e7f4ddf776  vmovaps [rsp+0xD0], xmm13
000071e7f4ddf77f  vmovaps [rsp+0xE0], xmm15
000071e7f4ddf788  sub rsp, 0x30
000071e7f4ddf78c  movaps [rsp], xmm14
000071e7f4ddf791  movaps [rsp+0x10], xmm8
000071e7f4ddf797  movaps [rsp+0x20], xmm4
000071e7f4ddf79c  lea rdi, [rsp]
000071e7f4ddf7a0  mov esi, 0x00
000071e7f4ddf7a5  mov rax, 0x562A51E82530
000071e7f4ddf7af  call rax
000071e7f4ddf7b1  movaps xmm14, [rsp]
000071e7f4ddf7b6  add rsp, 0x30
000071e7f4ddf7ba  vmovaps xmm0, [rsp]
000071e7f4ddf7bf  vmovaps xmm1, [rsp+0x10]
000071e7f4ddf7c5  vmovaps xmm2, [rsp+0x20]
000071e7f4ddf7cb  vmovaps xmm3, [rsp+0x30]
000071e7f4ddf7d1  vmovaps xmm4, [rsp+0x40]
000071e7f4ddf7d7  vmovaps xmm5, [rsp+0x50]
000071e7f4ddf7dd  vmovaps xmm6, [rsp+0x60]
000071e7f4ddf7e3  vmovaps xmm7, [rsp+0x70]
000071e7f4ddf7e9  vmovaps xmm8, [rsp+0x80]
000071e7f4ddf7f2  vmovaps xmm9, [rsp+0x90]
000071e7f4ddf7fb  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddf804  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddf80d  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddf816  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddf81f  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddf828  add rsp, 0xF0
000071e7f4ddf82f  pop r11
000071e7f4ddf831  pop r10
000071e7f4ddf833  pop r9
000071e7f4ddf835  pop r8
000071e7f4ddf837  pop rsi
000071e7f4ddf838  pop rdi
000071e7f4ddf839  pop rdx
000071e7f4ddf83a  pop rcx
000071e7f4ddf83b  pop rax
000071e7f4ddf83c  add rsp, 0x08
000071e7f4ddf840  jmp 0x000071E7F4DDC418
000071e7f4ddf845  sub rsp, 0x08
000071e7f4ddf849  push rax
000071e7f4ddf84a  push rcx
000071e7f4ddf84b  push rdx
000071e7f4ddf84c  push rdi
000071e7f4ddf84d  push rsi
000071e7f4ddf84e  push r8
000071e7f4ddf850  push r9
000071e7f4ddf852  push r10
000071e7f4ddf854  push r11
000071e7f4ddf856  sub rsp, 0xF0
000071e7f4ddf85d  vmovaps [rsp], xmm0
000071e7f4ddf862  vmovaps [rsp+0x10], xmm1
000071e7f4ddf868  vmovaps [rsp+0x20], xmm2
000071e7f4ddf86e  vmovaps [rsp+0x30], xmm3
000071e7f4ddf874  vmovaps [rsp+0x40], xmm5
000071e7f4ddf87a  vmovaps [rsp+0x50], xmm6
000071e7f4ddf880  vmovaps [rsp+0x60], xmm7
000071e7f4ddf886  vmovaps [rsp+0x70], xmm8
000071e7f4ddf88c  vmovaps [rsp+0x80], xmm9
000071e7f4ddf895  vmovaps [rsp+0x90], xmm10
000071e7f4ddf89e  vmovaps [rsp+0xA0], xmm11
000071e7f4ddf8a7  vmovaps [rsp+0xB0], xmm12
000071e7f4ddf8b0  vmovaps [rsp+0xC0], xmm13
000071e7f4ddf8b9  vmovaps [rsp+0xD0], xmm14
000071e7f4ddf8c2  vmovaps [rsp+0xE0], xmm15
000071e7f4ddf8cb  sub rsp, 0x30
000071e7f4ddf8cf  movaps [rsp], xmm4
000071e7f4ddf8d3  movaps [rsp+0x10], xmm13
000071e7f4ddf8d9  movaps [rsp+0x20], xmm8
000071e7f4ddf8df  lea rdi, [rsp]
000071e7f4ddf8e3  mov esi, 0x00
000071e7f4ddf8e8  mov rax, 0x562A51E82530
000071e7f4ddf8f2  call rax
000071e7f4ddf8f4  movaps xmm4, [rsp]
000071e7f4ddf8f8  add rsp, 0x30
000071e7f4ddf8fc  vmovaps xmm0, [rsp]
000071e7f4ddf901  vmovaps xmm1, [rsp+0x10]
000071e7f4ddf907  vmovaps xmm2, [rsp+0x20]
000071e7f4ddf90d  vmovaps xmm3, [rsp+0x30]
000071e7f4ddf913  vmovaps xmm5, [rsp+0x40]
000071e7f4ddf919  vmovaps xmm6, [rsp+0x50]
000071e7f4ddf91f  vmovaps xmm7, [rsp+0x60]
000071e7f4ddf925  vmovaps xmm8, [rsp+0x70]
000071e7f4ddf92b  vmovaps xmm9, [rsp+0x80]
000071e7f4ddf934  vmovaps xmm10, [rsp+0x90]
000071e7f4ddf93d  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddf946  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddf94f  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddf958  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddf961  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddf96a  add rsp, 0xF0
000071e7f4ddf971  pop r11
000071e7f4ddf973  pop r10
000071e7f4ddf975  pop r9
000071e7f4ddf977  pop r8
000071e7f4ddf979  pop rsi
000071e7f4ddf97a  pop rdi
000071e7f4ddf97b  pop rdx
000071e7f4ddf97c  pop rcx
000071e7f4ddf97d  pop rax
000071e7f4ddf97e  add rsp, 0x08
000071e7f4ddf982  jmp 0x000071E7F4DDC43D
000071e7f4ddf987  sub rsp, 0x08
000071e7f4ddf98b  push rax
000071e7f4ddf98c  push rcx
000071e7f4ddf98d  push rdx
000071e7f4ddf98e  push rdi
000071e7f4ddf98f  push rsi
000071e7f4ddf990  push r8
000071e7f4ddf992  push r9
000071e7f4ddf994  push r10
000071e7f4ddf996  push r11
000071e7f4ddf998  sub rsp, 0xF0
000071e7f4ddf99f  vmovaps [rsp], xmm0
000071e7f4ddf9a4  vmovaps [rsp+0x10], xmm1
000071e7f4ddf9aa  vmovaps [rsp+0x20], xmm2
000071e7f4ddf9b0  vmovaps [rsp+0x30], xmm3
000071e7f4ddf9b6  vmovaps [rsp+0x40], xmm4
000071e7f4ddf9bc  vmovaps [rsp+0x50], xmm5
000071e7f4ddf9c2  vmovaps [rsp+0x60], xmm6
000071e7f4ddf9c8  vmovaps [rsp+0x70], xmm7
000071e7f4ddf9ce  vmovaps [rsp+0x80], xmm8
000071e7f4ddf9d7  vmovaps [rsp+0x90], xmm9
000071e7f4ddf9e0  vmovaps [rsp+0xA0], xmm10
000071e7f4ddf9e9  vmovaps [rsp+0xB0], xmm11
000071e7f4ddf9f2  vmovaps [rsp+0xC0], xmm12
000071e7f4ddf9fb  vmovaps [rsp+0xD0], xmm14
000071e7f4ddfa04  vmovaps [rsp+0xE0], xmm15
000071e7f4ddfa0d  sub rsp, 0x30
000071e7f4ddfa11  movaps [rsp], xmm13
000071e7f4ddfa16  movaps [rsp+0x10], xmm15
000071e7f4ddfa1c  movaps [rsp+0x20], xmm9
000071e7f4ddfa22  lea rdi, [rsp]
000071e7f4ddfa26  mov esi, 0x00
000071e7f4ddfa2b  mov rax, 0x562A51E82530
000071e7f4ddfa35  call rax
000071e7f4ddfa37  movaps xmm13, [rsp]
000071e7f4ddfa3c  add rsp, 0x30
000071e7f4ddfa40  vmovaps xmm0, [rsp]
000071e7f4ddfa45  vmovaps xmm1, [rsp+0x10]
000071e7f4ddfa4b  vmovaps xmm2, [rsp+0x20]
000071e7f4ddfa51  vmovaps xmm3, [rsp+0x30]
000071e7f4ddfa57  vmovaps xmm4, [rsp+0x40]
000071e7f4ddfa5d  vmovaps xmm5, [rsp+0x50]
000071e7f4ddfa63  vmovaps xmm6, [rsp+0x60]
000071e7f4ddfa69  vmovaps xmm7, [rsp+0x70]
000071e7f4ddfa6f  vmovaps xmm8, [rsp+0x80]
000071e7f4ddfa78  vmovaps xmm9, [rsp+0x90]
000071e7f4ddfa81  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddfa8a  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddfa93  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddfa9c  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddfaa5  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddfaae  add rsp, 0xF0
000071e7f4ddfab5  pop r11
000071e7f4ddfab7  pop r10
000071e7f4ddfab9  pop r9
000071e7f4ddfabb  pop r8
000071e7f4ddfabd  pop rsi
000071e7f4ddfabe  pop rdi
000071e7f4ddfabf  pop rdx
000071e7f4ddfac0  pop rcx
000071e7f4ddfac1  pop rax
000071e7f4ddfac2  add rsp, 0x08
000071e7f4ddfac6  jmp 0x000071E7F4DDC458
000071e7f4ddfacb  sub rsp, 0x08
000071e7f4ddfacf  push rax
000071e7f4ddfad0  push rcx
000071e7f4ddfad1  push rdx
000071e7f4ddfad2  push rdi
000071e7f4ddfad3  push rsi
000071e7f4ddfad4  push r8
000071e7f4ddfad6  push r9
000071e7f4ddfad8  push r10
000071e7f4ddfada  push r11
000071e7f4ddfadc  sub rsp, 0xF0
000071e7f4ddfae3  vmovaps [rsp], xmm0
000071e7f4ddfae8  vmovaps [rsp+0x10], xmm1
000071e7f4ddfaee  vmovaps [rsp+0x20], xmm2
000071e7f4ddfaf4  vmovaps [rsp+0x30], xmm3
000071e7f4ddfafa  vmovaps [rsp+0x40], xmm4
000071e7f4ddfb00  vmovaps [rsp+0x50], xmm5
000071e7f4ddfb06  vmovaps [rsp+0x60], xmm6
000071e7f4ddfb0c  vmovaps [rsp+0x70], xmm7
000071e7f4ddfb12  vmovaps [rsp+0x80], xmm8
000071e7f4ddfb1b  vmovaps [rsp+0x90], xmm9
000071e7f4ddfb24  vmovaps [rsp+0xA0], xmm10
000071e7f4ddfb2d  vmovaps [rsp+0xB0], xmm11
000071e7f4ddfb36  vmovaps [rsp+0xC0], xmm12
000071e7f4ddfb3f  vmovaps [rsp+0xD0], xmm13
000071e7f4ddfb48  vmovaps [rsp+0xE0], xmm14
000071e7f4ddfb51  sub rsp, 0x30
000071e7f4ddfb55  movaps [rsp], xmm15
000071e7f4ddfb5a  movaps [rsp+0x10], xmm1
000071e7f4ddfb5f  movaps [rsp+0x20], xmm5
000071e7f4ddfb64  lea rdi, [rsp]
000071e7f4ddfb68  mov esi, 0x00
000071e7f4ddfb6d  mov rax, 0x562A51E82530
000071e7f4ddfb77  call rax
000071e7f4ddfb79  movaps xmm15, [rsp]
000071e7f4ddfb7e  add rsp, 0x30
000071e7f4ddfb82  vmovaps xmm0, [rsp]
000071e7f4ddfb87  vmovaps xmm1, [rsp+0x10]
000071e7f4ddfb8d  vmovaps xmm2, [rsp+0x20]
000071e7f4ddfb93  vmovaps xmm3, [rsp+0x30]
000071e7f4ddfb99  vmovaps xmm4, [rsp+0x40]
000071e7f4ddfb9f  vmovaps xmm5, [rsp+0x50]
000071e7f4ddfba5  vmovaps xmm6, [rsp+0x60]
000071e7f4ddfbab  vmovaps xmm7, [rsp+0x70]
000071e7f4ddfbb1  vmovaps xmm8, [rsp+0x80]
000071e7f4ddfbba  vmovaps xmm9, [rsp+0x90]
000071e7f4ddfbc3  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddfbcc  vmovaps xmm11, [rsp+0xB0]
000071e7f4ddfbd5  vmovaps xmm12, [rsp+0xC0]
000071e7f4ddfbde  vmovaps xmm13, [rsp+0xD0]
000071e7f4ddfbe7  vmovaps xmm14, [rsp+0xE0]
000071e7f4ddfbf0  add rsp, 0xF0
000071e7f4ddfbf7  pop r11
000071e7f4ddfbf9  pop r10
000071e7f4ddfbfb  pop r9
000071e7f4ddfbfd  pop r8
000071e7f4ddfbff  pop rsi
000071e7f4ddfc00  pop rdi
000071e7f4ddfc01  pop rdx
000071e7f4ddfc02  pop rcx
000071e7f4ddfc03  pop rax
000071e7f4ddfc04  add rsp, 0x08
000071e7f4ddfc08  jmp 0x000071E7F4DDC473
000071e7f4ddfc0d  call 0x000071E7F4CB52F0
000071e7f4ddfc12  jmp 0x000071E7F4DDC4CE
000071e7f4ddfc17  sub rsp, 0x08
000071e7f4ddfc1b  push rax
000071e7f4ddfc1c  push rcx
000071e7f4ddfc1d  push rdx
000071e7f4ddfc1e  push rdi
000071e7f4ddfc1f  push rsi
000071e7f4ddfc20  push r8
000071e7f4ddfc22  push r9
000071e7f4ddfc24  push r10
000071e7f4ddfc26  push r11
000071e7f4ddfc28  sub rsp, 0xF0
000071e7f4ddfc2f  vmovaps [rsp], xmm0
000071e7f4ddfc34  vmovaps [rsp+0x10], xmm1
000071e7f4ddfc3a  vmovaps [rsp+0x20], xmm2
000071e7f4ddfc40  vmovaps [rsp+0x30], xmm3
000071e7f4ddfc46  vmovaps [rsp+0x40], xmm4
000071e7f4ddfc4c  vmovaps [rsp+0x50], xmm5
000071e7f4ddfc52  vmovaps [rsp+0x60], xmm6
000071e7f4ddfc58  vmovaps [rsp+0x70], xmm7
000071e7f4ddfc5e  vmovaps [rsp+0x80], xmm8
000071e7f4ddfc67  vmovaps [rsp+0x90], xmm10
000071e7f4ddfc70  vmovaps [rsp+0xA0], xmm11
000071e7f4ddfc79  vmovaps [rsp+0xB0], xmm12
000071e7f4ddfc82  vmovaps [rsp+0xC0], xmm13
000071e7f4ddfc8b  vmovaps [rsp+0xD0], xmm14
000071e7f4ddfc94  vmovaps [rsp+0xE0], xmm15
000071e7f4ddfc9d  sub rsp, 0x30
000071e7f4ddfca1  movaps [rsp], xmm9
000071e7f4ddfca6  movaps [rsp+0x10], xmm8
000071e7f4ddfcac  movaps [rsp+0x20], xmm11
000071e7f4ddfcb2  lea rdi, [rsp]
000071e7f4ddfcb6  mov esi, 0x00
000071e7f4ddfcbb  mov rax, 0x562A51E82530
000071e7f4ddfcc5  call rax
000071e7f4ddfcc7  movaps xmm9, [rsp]
000071e7f4ddfccc  add rsp, 0x30
000071e7f4ddfcd0  vmovaps xmm0, [rsp]
000071e7f4ddfcd5  vmovaps xmm1, [rsp+0x10]
000071e7f4ddfcdb  vmovaps xmm2, [rsp+0x20]
000071e7f4ddfce1  vmovaps xmm3, [rsp+0x30]
000071e7f4ddfce7  vmovaps xmm4, [rsp+0x40]
000071e7f4ddfced  vmovaps xmm5, [rsp+0x50]
000071e7f4ddfcf3  vmovaps xmm6, [rsp+0x60]
000071e7f4ddfcf9  vmovaps xmm7, [rsp+0x70]
000071e7f4ddfcff  vmovaps xmm8, [rsp+0x80]
000071e7f4ddfd08  vmovaps xmm10, [rsp+0x90]
000071e7f4ddfd11  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddfd1a  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddfd23  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddfd2c  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddfd35  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddfd3e  add rsp, 0xF0
000071e7f4ddfd45  pop r11
000071e7f4ddfd47  pop r10
000071e7f4ddfd49  pop r9
000071e7f4ddfd4b  pop r8
000071e7f4ddfd4d  pop rsi
000071e7f4ddfd4e  pop rdi
000071e7f4ddfd4f  pop rdx
000071e7f4ddfd50  pop rcx
000071e7f4ddfd51  pop rax
000071e7f4ddfd52  add rsp, 0x08
000071e7f4ddfd56  jmp 0x000071E7F4DDC505
000071e7f4ddfd5b  sub rsp, 0x08
000071e7f4ddfd5f  push rax
000071e7f4ddfd60  push rcx
000071e7f4ddfd61  push rdx
000071e7f4ddfd62  push rdi
000071e7f4ddfd63  push rsi
000071e7f4ddfd64  push r8
000071e7f4ddfd66  push r9
000071e7f4ddfd68  push r10
000071e7f4ddfd6a  push r11
000071e7f4ddfd6c  sub rsp, 0xF0
000071e7f4ddfd73  vmovaps [rsp], xmm0
000071e7f4ddfd78  vmovaps [rsp+0x10], xmm1
000071e7f4ddfd7e  vmovaps [rsp+0x20], xmm2
000071e7f4ddfd84  vmovaps [rsp+0x30], xmm3
000071e7f4ddfd8a  vmovaps [rsp+0x40], xmm4
000071e7f4ddfd90  vmovaps [rsp+0x50], xmm5
000071e7f4ddfd96  vmovaps [rsp+0x60], xmm6
000071e7f4ddfd9c  vmovaps [rsp+0x70], xmm7
000071e7f4ddfda2  vmovaps [rsp+0x80], xmm8
000071e7f4ddfdab  vmovaps [rsp+0x90], xmm9
000071e7f4ddfdb4  vmovaps [rsp+0xA0], xmm10
000071e7f4ddfdbd  vmovaps [rsp+0xB0], xmm12
000071e7f4ddfdc6  vmovaps [rsp+0xC0], xmm13
000071e7f4ddfdcf  vmovaps [rsp+0xD0], xmm14
000071e7f4ddfdd8  vmovaps [rsp+0xE0], xmm15
000071e7f4ddfde1  sub rsp, 0x30
000071e7f4ddfde5  movaps [rsp], xmm11
000071e7f4ddfdea  movaps [rsp+0x10], xmm10
000071e7f4ddfdf0  movaps [rsp+0x20], xmm6
000071e7f4ddfdf5  lea rdi, [rsp]
000071e7f4ddfdf9  mov esi, 0x00
000071e7f4ddfdfe  mov rax, 0x562A51E82530
000071e7f4ddfe08  call rax
000071e7f4ddfe0a  movaps xmm11, [rsp]
000071e7f4ddfe0f  add rsp, 0x30
000071e7f4ddfe13  vmovaps xmm0, [rsp]
000071e7f4ddfe18  vmovaps xmm1, [rsp+0x10]
000071e7f4ddfe1e  vmovaps xmm2, [rsp+0x20]
000071e7f4ddfe24  vmovaps xmm3, [rsp+0x30]
000071e7f4ddfe2a  vmovaps xmm4, [rsp+0x40]
000071e7f4ddfe30  vmovaps xmm5, [rsp+0x50]
000071e7f4ddfe36  vmovaps xmm6, [rsp+0x60]
000071e7f4ddfe3c  vmovaps xmm7, [rsp+0x70]
000071e7f4ddfe42  vmovaps xmm8, [rsp+0x80]
000071e7f4ddfe4b  vmovaps xmm9, [rsp+0x90]
000071e7f4ddfe54  vmovaps xmm10, [rsp+0xA0]
000071e7f4ddfe5d  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddfe66  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddfe6f  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddfe78  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddfe81  add rsp, 0xF0
000071e7f4ddfe88  pop r11
000071e7f4ddfe8a  pop r10
000071e7f4ddfe8c  pop r9
000071e7f4ddfe8e  pop r8
000071e7f4ddfe90  pop rsi
000071e7f4ddfe91  pop rdi
000071e7f4ddfe92  pop rdx
000071e7f4ddfe93  pop rcx
000071e7f4ddfe94  pop rax
000071e7f4ddfe95  add rsp, 0x08
000071e7f4ddfe99  jmp 0x000071E7F4DDC520
000071e7f4ddfe9e  sub rsp, 0x08
000071e7f4ddfea2  push rax
000071e7f4ddfea3  push rcx
000071e7f4ddfea4  push rdx
000071e7f4ddfea5  push rdi
000071e7f4ddfea6  push rsi
000071e7f4ddfea7  push r8
000071e7f4ddfea9  push r9
000071e7f4ddfeab  push r10
000071e7f4ddfead  push r11
000071e7f4ddfeaf  sub rsp, 0xF0
000071e7f4ddfeb6  vmovaps [rsp], xmm0
000071e7f4ddfebb  vmovaps [rsp+0x10], xmm1
000071e7f4ddfec1  vmovaps [rsp+0x20], xmm2
000071e7f4ddfec7  vmovaps [rsp+0x30], xmm3
000071e7f4ddfecd  vmovaps [rsp+0x40], xmm4
000071e7f4ddfed3  vmovaps [rsp+0x50], xmm5
000071e7f4ddfed9  vmovaps [rsp+0x60], xmm6
000071e7f4ddfedf  vmovaps [rsp+0x70], xmm7
000071e7f4ddfee5  vmovaps [rsp+0x80], xmm8
000071e7f4ddfeee  vmovaps [rsp+0x90], xmm9
000071e7f4ddfef7  vmovaps [rsp+0xA0], xmm11
000071e7f4ddff00  vmovaps [rsp+0xB0], xmm12
000071e7f4ddff09  vmovaps [rsp+0xC0], xmm13
000071e7f4ddff12  vmovaps [rsp+0xD0], xmm14
000071e7f4ddff1b  vmovaps [rsp+0xE0], xmm15
000071e7f4ddff24  sub rsp, 0x30
000071e7f4ddff28  movaps [rsp], xmm10
000071e7f4ddff2d  movaps [rsp+0x10], xmm14
000071e7f4ddff33  movaps [rsp+0x20], xmm4
000071e7f4ddff38  lea rdi, [rsp]
000071e7f4ddff3c  mov esi, 0x00
000071e7f4ddff41  mov rax, 0x562A51E82530
000071e7f4ddff4b  call rax
000071e7f4ddff4d  movaps xmm10, [rsp]
000071e7f4ddff52  add rsp, 0x30
000071e7f4ddff56  vmovaps xmm0, [rsp]
000071e7f4ddff5b  vmovaps xmm1, [rsp+0x10]
000071e7f4ddff61  vmovaps xmm2, [rsp+0x20]
000071e7f4ddff67  vmovaps xmm3, [rsp+0x30]
000071e7f4ddff6d  vmovaps xmm4, [rsp+0x40]
000071e7f4ddff73  vmovaps xmm5, [rsp+0x50]
000071e7f4ddff79  vmovaps xmm6, [rsp+0x60]
000071e7f4ddff7f  vmovaps xmm7, [rsp+0x70]
000071e7f4ddff85  vmovaps xmm8, [rsp+0x80]
000071e7f4ddff8e  vmovaps xmm9, [rsp+0x90]
000071e7f4ddff97  vmovaps xmm11, [rsp+0xA0]
000071e7f4ddffa0  vmovaps xmm12, [rsp+0xB0]
000071e7f4ddffa9  vmovaps xmm13, [rsp+0xC0]
000071e7f4ddffb2  vmovaps xmm14, [rsp+0xD0]
000071e7f4ddffbb  vmovaps xmm15, [rsp+0xE0]
000071e7f4ddffc4  add rsp, 0xF0
000071e7f4ddffcb  pop r11
000071e7f4ddffcd  pop r10
000071e7f4ddffcf  pop r9
000071e7f4ddffd1  pop r8
000071e7f4ddffd3  pop rsi
000071e7f4ddffd4  pop rdi
000071e7f4ddffd5  pop rdx
000071e7f4ddffd6  pop rcx
000071e7f4ddffd7  pop rax
000071e7f4ddffd8  add rsp, 0x08
000071e7f4ddffdc  jmp 0x000071E7F4DDC53B
000071e7f4ddffe1  sub rsp, 0x08
000071e7f4ddffe5  push rax
000071e7f4ddffe6  push rcx
000071e7f4ddffe7  push rdx
000071e7f4ddffe8  push rdi
000071e7f4ddffe9  push rsi
000071e7f4ddffea  push r8
000071e7f4ddffec  push r9
000071e7f4ddffee  push r10
000071e7f4ddfff0  push r11
000071e7f4ddfff2  sub rsp, 0xF0
000071e7f4ddfff9  vmovaps [rsp], xmm0
000071e7f4ddfffe  vmovaps [rsp+0x10], xmm1
000071e7f4de0004  vmovaps [rsp+0x20], xmm2
000071e7f4de000a  vmovaps [rsp+0x30], xmm3
000071e7f4de0010  vmovaps [rsp+0x40], xmm4
000071e7f4de0016  vmovaps [rsp+0x50], xmm5
000071e7f4de001c  vmovaps [rsp+0x60], xmm6
000071e7f4de0022  vmovaps [rsp+0x70], xmm7
000071e7f4de0028  vmovaps [rsp+0x80], xmm9
000071e7f4de0031  vmovaps [rsp+0x90], xmm10
000071e7f4de003a  vmovaps [rsp+0xA0], xmm11
000071e7f4de0043  vmovaps [rsp+0xB0], xmm12
000071e7f4de004c  vmovaps [rsp+0xC0], xmm13
000071e7f4de0055  vmovaps [rsp+0xD0], xmm14
000071e7f4de005e  vmovaps [rsp+0xE0], xmm15
000071e7f4de0067  sub rsp, 0x30
000071e7f4de006b  movaps [rsp], xmm8
000071e7f4de0070  movaps [rsp+0x10], xmm1
000071e7f4de0075  movaps [rsp+0x20], xmm14
000071e7f4de007b  lea rdi, [rsp]
000071e7f4de007f  mov esi, 0x00
000071e7f4de0084  mov rax, 0x562A51E82530
000071e7f4de008e  call rax
000071e7f4de0090  movaps xmm8, [rsp]
000071e7f4de0095  add rsp, 0x30
000071e7f4de0099  vmovaps xmm0, [rsp]
000071e7f4de009e  vmovaps xmm1, [rsp+0x10]
000071e7f4de00a4  vmovaps xmm2, [rsp+0x20]
000071e7f4de00aa  vmovaps xmm3, [rsp+0x30]
000071e7f4de00b0  vmovaps xmm4, [rsp+0x40]
000071e7f4de00b6  vmovaps xmm5, [rsp+0x50]
000071e7f4de00bc  vmovaps xmm6, [rsp+0x60]
000071e7f4de00c2  vmovaps xmm7, [rsp+0x70]
000071e7f4de00c8  vmovaps xmm9, [rsp+0x80]
000071e7f4de00d1  vmovaps xmm10, [rsp+0x90]
000071e7f4de00da  vmovaps xmm11, [rsp+0xA0]
000071e7f4de00e3  vmovaps xmm12, [rsp+0xB0]
000071e7f4de00ec  vmovaps xmm13, [rsp+0xC0]
000071e7f4de00f5  vmovaps xmm14, [rsp+0xD0]
000071e7f4de00fe  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0107  add rsp, 0xF0
000071e7f4de010e  pop r11
000071e7f4de0110  pop r10
000071e7f4de0112  pop r9
000071e7f4de0114  pop r8
000071e7f4de0116  pop rsi
000071e7f4de0117  pop rdi
000071e7f4de0118  pop rdx
000071e7f4de0119  pop rcx
000071e7f4de011a  pop rax
000071e7f4de011b  add rsp, 0x08
000071e7f4de011f  jmp 0x000071E7F4DDC561
000071e7f4de0124  sub rsp, 0x08
000071e7f4de0128  push rax
000071e7f4de0129  push rcx
000071e7f4de012a  push rdx
000071e7f4de012b  push rdi
000071e7f4de012c  push rsi
000071e7f4de012d  push r8
000071e7f4de012f  push r9
000071e7f4de0131  push r10
000071e7f4de0133  push r11
000071e7f4de0135  sub rsp, 0xF0
000071e7f4de013c  vmovaps [rsp], xmm0
000071e7f4de0141  vmovaps [rsp+0x10], xmm1
000071e7f4de0147  vmovaps [rsp+0x20], xmm2
000071e7f4de014d  vmovaps [rsp+0x30], xmm3
000071e7f4de0153  vmovaps [rsp+0x40], xmm4
000071e7f4de0159  vmovaps [rsp+0x50], xmm5
000071e7f4de015f  vmovaps [rsp+0x60], xmm7
000071e7f4de0165  vmovaps [rsp+0x70], xmm8
000071e7f4de016b  vmovaps [rsp+0x80], xmm9
000071e7f4de0174  vmovaps [rsp+0x90], xmm10
000071e7f4de017d  vmovaps [rsp+0xA0], xmm11
000071e7f4de0186  vmovaps [rsp+0xB0], xmm12
000071e7f4de018f  vmovaps [rsp+0xC0], xmm13
000071e7f4de0198  vmovaps [rsp+0xD0], xmm14
000071e7f4de01a1  vmovaps [rsp+0xE0], xmm15
000071e7f4de01aa  sub rsp, 0x30
000071e7f4de01ae  movaps [rsp], xmm6
000071e7f4de01b2  movaps [rsp+0x10], xmm1
000071e7f4de01b7  movaps [rsp+0x20], xmm14
000071e7f4de01bd  lea rdi, [rsp]
000071e7f4de01c1  mov esi, 0x00
000071e7f4de01c6  mov rax, 0x562A51E82530
000071e7f4de01d0  call rax
000071e7f4de01d2  movaps xmm6, [rsp]
000071e7f4de01d6  add rsp, 0x30
000071e7f4de01da  vmovaps xmm0, [rsp]
000071e7f4de01df  vmovaps xmm1, [rsp+0x10]
000071e7f4de01e5  vmovaps xmm2, [rsp+0x20]
000071e7f4de01eb  vmovaps xmm3, [rsp+0x30]
000071e7f4de01f1  vmovaps xmm4, [rsp+0x40]
000071e7f4de01f7  vmovaps xmm5, [rsp+0x50]
000071e7f4de01fd  vmovaps xmm7, [rsp+0x60]
000071e7f4de0203  vmovaps xmm8, [rsp+0x70]
000071e7f4de0209  vmovaps xmm9, [rsp+0x80]
000071e7f4de0212  vmovaps xmm10, [rsp+0x90]
000071e7f4de021b  vmovaps xmm11, [rsp+0xA0]
000071e7f4de0224  vmovaps xmm12, [rsp+0xB0]
000071e7f4de022d  vmovaps xmm13, [rsp+0xC0]
000071e7f4de0236  vmovaps xmm14, [rsp+0xD0]
000071e7f4de023f  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0248  add rsp, 0xF0
000071e7f4de024f  pop r11
000071e7f4de0251  pop r10
000071e7f4de0253  pop r9
000071e7f4de0255  pop r8
000071e7f4de0257  pop rsi
000071e7f4de0258  pop rdi
000071e7f4de0259  pop rdx
000071e7f4de025a  pop rcx
000071e7f4de025b  pop rax
000071e7f4de025c  add rsp, 0x08
000071e7f4de0260  jmp 0x000071E7F4DDC58D
000071e7f4de0265  sub rsp, 0x08
000071e7f4de0269  push rax
000071e7f4de026a  push rcx
000071e7f4de026b  push rdx
000071e7f4de026c  push rdi
000071e7f4de026d  push rsi
000071e7f4de026e  push r8
000071e7f4de0270  push r9
000071e7f4de0272  push r10
000071e7f4de0274  push r11
000071e7f4de0276  sub rsp, 0xF0
000071e7f4de027d  vmovaps [rsp], xmm0
000071e7f4de0282  vmovaps [rsp+0x10], xmm1
000071e7f4de0288  vmovaps [rsp+0x20], xmm2
000071e7f4de028e  vmovaps [rsp+0x30], xmm3
000071e7f4de0294  vmovaps [rsp+0x40], xmm4
000071e7f4de029a  vmovaps [rsp+0x50], xmm5
000071e7f4de02a0  vmovaps [rsp+0x60], xmm6
000071e7f4de02a6  vmovaps [rsp+0x70], xmm7
000071e7f4de02ac  vmovaps [rsp+0x80], xmm8
000071e7f4de02b5  vmovaps [rsp+0x90], xmm9
000071e7f4de02be  vmovaps [rsp+0xA0], xmm10
000071e7f4de02c7  vmovaps [rsp+0xB0], xmm11
000071e7f4de02d0  vmovaps [rsp+0xC0], xmm12
000071e7f4de02d9  vmovaps [rsp+0xD0], xmm13
000071e7f4de02e2  vmovaps [rsp+0xE0], xmm15
000071e7f4de02eb  sub rsp, 0x30
000071e7f4de02ef  movaps [rsp], xmm14
000071e7f4de02f4  movaps [rsp+0x10], xmm12
000071e7f4de02fa  movaps [rsp+0x20], xmm1
000071e7f4de02ff  lea rdi, [rsp]
000071e7f4de0303  mov esi, 0x00
000071e7f4de0308  mov rax, 0x562A51E82530
000071e7f4de0312  call rax
000071e7f4de0314  movaps xmm14, [rsp]
000071e7f4de0319  add rsp, 0x30
000071e7f4de031d  vmovaps xmm0, [rsp]
000071e7f4de0322  vmovaps xmm1, [rsp+0x10]
000071e7f4de0328  vmovaps xmm2, [rsp+0x20]
000071e7f4de032e  vmovaps xmm3, [rsp+0x30]
000071e7f4de0334  vmovaps xmm4, [rsp+0x40]
000071e7f4de033a  vmovaps xmm5, [rsp+0x50]
000071e7f4de0340  vmovaps xmm6, [rsp+0x60]
000071e7f4de0346  vmovaps xmm7, [rsp+0x70]
000071e7f4de034c  vmovaps xmm8, [rsp+0x80]
000071e7f4de0355  vmovaps xmm9, [rsp+0x90]
000071e7f4de035e  vmovaps xmm10, [rsp+0xA0]
000071e7f4de0367  vmovaps xmm11, [rsp+0xB0]
000071e7f4de0370  vmovaps xmm12, [rsp+0xC0]
000071e7f4de0379  vmovaps xmm13, [rsp+0xD0]
000071e7f4de0382  vmovaps xmm15, [rsp+0xE0]
000071e7f4de038b  add rsp, 0xF0
000071e7f4de0392  pop r11
000071e7f4de0394  pop r10
000071e7f4de0396  pop r9
000071e7f4de0398  pop r8
000071e7f4de039a  pop rsi
000071e7f4de039b  pop rdi
000071e7f4de039c  pop rdx
000071e7f4de039d  pop rcx
000071e7f4de039e  pop rax
000071e7f4de039f  add rsp, 0x08
000071e7f4de03a3  jmp 0x000071E7F4DDC5B3
000071e7f4de03a8  sub rsp, 0x08
000071e7f4de03ac  push rax
000071e7f4de03ad  push rcx
000071e7f4de03ae  push rdx
000071e7f4de03af  push rdi
000071e7f4de03b0  push rsi
000071e7f4de03b1  push r8
000071e7f4de03b3  push r9
000071e7f4de03b5  push r10
000071e7f4de03b7  push r11
000071e7f4de03b9  sub rsp, 0xF0
000071e7f4de03c0  vmovaps [rsp], xmm0
000071e7f4de03c5  vmovaps [rsp+0x10], xmm2
000071e7f4de03cb  vmovaps [rsp+0x20], xmm3
000071e7f4de03d1  vmovaps [rsp+0x30], xmm4
000071e7f4de03d7  vmovaps [rsp+0x40], xmm5
000071e7f4de03dd  vmovaps [rsp+0x50], xmm6
000071e7f4de03e3  vmovaps [rsp+0x60], xmm7
000071e7f4de03e9  vmovaps [rsp+0x70], xmm8
000071e7f4de03ef  vmovaps [rsp+0x80], xmm9
000071e7f4de03f8  vmovaps [rsp+0x90], xmm10
000071e7f4de0401  vmovaps [rsp+0xA0], xmm11
000071e7f4de040a  vmovaps [rsp+0xB0], xmm12
000071e7f4de0413  vmovaps [rsp+0xC0], xmm13
000071e7f4de041c  vmovaps [rsp+0xD0], xmm14
000071e7f4de0425  vmovaps [rsp+0xE0], xmm15
000071e7f4de042e  sub rsp, 0x30
000071e7f4de0432  movaps [rsp], xmm1
000071e7f4de0436  movaps [rsp+0x10], xmm13
000071e7f4de043c  movaps [rsp+0x20], xmm9
000071e7f4de0442  lea rdi, [rsp]
000071e7f4de0446  mov esi, 0x00
000071e7f4de044b  mov rax, 0x562A51E82530
000071e7f4de0455  call rax
000071e7f4de0457  movaps xmm1, [rsp]
000071e7f4de045b  add rsp, 0x30
000071e7f4de045f  vmovaps xmm0, [rsp]
000071e7f4de0464  vmovaps xmm2, [rsp+0x10]
000071e7f4de046a  vmovaps xmm3, [rsp+0x20]
000071e7f4de0470  vmovaps xmm4, [rsp+0x30]
000071e7f4de0476  vmovaps xmm5, [rsp+0x40]
000071e7f4de047c  vmovaps xmm6, [rsp+0x50]
000071e7f4de0482  vmovaps xmm7, [rsp+0x60]
000071e7f4de0488  vmovaps xmm8, [rsp+0x70]
000071e7f4de048e  vmovaps xmm9, [rsp+0x80]
000071e7f4de0497  vmovaps xmm10, [rsp+0x90]
000071e7f4de04a0  vmovaps xmm11, [rsp+0xA0]
000071e7f4de04a9  vmovaps xmm12, [rsp+0xB0]
000071e7f4de04b2  vmovaps xmm13, [rsp+0xC0]
000071e7f4de04bb  vmovaps xmm14, [rsp+0xD0]
000071e7f4de04c4  vmovaps xmm15, [rsp+0xE0]
000071e7f4de04cd  add rsp, 0xF0
000071e7f4de04d4  pop r11
000071e7f4de04d6  pop r10
000071e7f4de04d8  pop r9
000071e7f4de04da  pop r8
000071e7f4de04dc  pop rsi
000071e7f4de04dd  pop rdi
000071e7f4de04de  pop rdx
000071e7f4de04df  pop rcx
000071e7f4de04e0  pop rax
000071e7f4de04e1  add rsp, 0x08
000071e7f4de04e5  jmp 0x000071E7F4DDC5CD
000071e7f4de04ea  sub rsp, 0x08
000071e7f4de04ee  push rax
000071e7f4de04ef  push rcx
000071e7f4de04f0  push rdx
000071e7f4de04f1  push rdi
000071e7f4de04f2  push rsi
000071e7f4de04f3  push r8
000071e7f4de04f5  push r9
000071e7f4de04f7  push r10
000071e7f4de04f9  push r11
000071e7f4de04fb  sub rsp, 0xF0
000071e7f4de0502  vmovaps [rsp], xmm0
000071e7f4de0507  vmovaps [rsp+0x10], xmm1
000071e7f4de050d  vmovaps [rsp+0x20], xmm2
000071e7f4de0513  vmovaps [rsp+0x30], xmm3
000071e7f4de0519  vmovaps [rsp+0x40], xmm4
000071e7f4de051f  vmovaps [rsp+0x50], xmm5
000071e7f4de0525  vmovaps [rsp+0x60], xmm6
000071e7f4de052b  vmovaps [rsp+0x70], xmm7
000071e7f4de0531  vmovaps [rsp+0x80], xmm8
000071e7f4de053a  vmovaps [rsp+0x90], xmm9
000071e7f4de0543  vmovaps [rsp+0xA0], xmm10
000071e7f4de054c  vmovaps [rsp+0xB0], xmm11
000071e7f4de0555  vmovaps [rsp+0xC0], xmm13
000071e7f4de055e  vmovaps [rsp+0xD0], xmm14
000071e7f4de0567  vmovaps [rsp+0xE0], xmm15
000071e7f4de0570  sub rsp, 0x30
000071e7f4de0574  movaps [rsp], xmm12
000071e7f4de0579  movaps [rsp+0x10], xmm7
000071e7f4de057e  movaps [rsp+0x20], xmm13
000071e7f4de0584  lea rdi, [rsp]
000071e7f4de0588  mov esi, 0x00
000071e7f4de058d  mov rax, 0x562A51E82530
000071e7f4de0597  call rax
000071e7f4de0599  movaps xmm12, [rsp]
000071e7f4de059e  add rsp, 0x30
000071e7f4de05a2  vmovaps xmm0, [rsp]
000071e7f4de05a7  vmovaps xmm1, [rsp+0x10]
000071e7f4de05ad  vmovaps xmm2, [rsp+0x20]
000071e7f4de05b3  vmovaps xmm3, [rsp+0x30]
000071e7f4de05b9  vmovaps xmm4, [rsp+0x40]
000071e7f4de05bf  vmovaps xmm5, [rsp+0x50]
000071e7f4de05c5  vmovaps xmm6, [rsp+0x60]
000071e7f4de05cb  vmovaps xmm7, [rsp+0x70]
000071e7f4de05d1  vmovaps xmm8, [rsp+0x80]
000071e7f4de05da  vmovaps xmm9, [rsp+0x90]
000071e7f4de05e3  vmovaps xmm10, [rsp+0xA0]
000071e7f4de05ec  vmovaps xmm11, [rsp+0xB0]
000071e7f4de05f5  vmovaps xmm13, [rsp+0xC0]
000071e7f4de05fe  vmovaps xmm14, [rsp+0xD0]
000071e7f4de0607  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0610  add rsp, 0xF0
000071e7f4de0617  pop r11
000071e7f4de0619  pop r10
000071e7f4de061b  pop r9
000071e7f4de061d  pop r8
000071e7f4de061f  pop rsi
000071e7f4de0620  pop rdi
000071e7f4de0621  pop rdx
000071e7f4de0622  pop rcx
000071e7f4de0623  pop rax
000071e7f4de0624  add rsp, 0x08
000071e7f4de0628  jmp 0x000071E7F4DDC5F4
000071e7f4de062d  sub rsp, 0x08
000071e7f4de0631  push rax
000071e7f4de0632  push rcx
000071e7f4de0633  push rdx
000071e7f4de0634  push rdi
000071e7f4de0635  push rsi
000071e7f4de0636  push r8
000071e7f4de0638  push r9
000071e7f4de063a  push r10
000071e7f4de063c  push r11
000071e7f4de063e  sub rsp, 0xF0
000071e7f4de0645  vmovaps [rsp], xmm0
000071e7f4de064a  vmovaps [rsp+0x10], xmm1
000071e7f4de0650  vmovaps [rsp+0x20], xmm2
000071e7f4de0656  vmovaps [rsp+0x30], xmm3
000071e7f4de065c  vmovaps [rsp+0x40], xmm4
000071e7f4de0662  vmovaps [rsp+0x50], xmm5
000071e7f4de0668  vmovaps [rsp+0x60], xmm6
000071e7f4de066e  vmovaps [rsp+0x70], xmm7
000071e7f4de0674  vmovaps [rsp+0x80], xmm8
000071e7f4de067d  vmovaps [rsp+0x90], xmm9
000071e7f4de0686  vmovaps [rsp+0xA0], xmm10
000071e7f4de068f  vmovaps [rsp+0xB0], xmm11
000071e7f4de0698  vmovaps [rsp+0xC0], xmm12
000071e7f4de06a1  vmovaps [rsp+0xD0], xmm14
000071e7f4de06aa  vmovaps [rsp+0xE0], xmm15
000071e7f4de06b3  sub rsp, 0x30
000071e7f4de06b7  movaps [rsp], xmm13
000071e7f4de06bc  movaps [rsp+0x10], xmm15
000071e7f4de06c2  movaps [rsp+0x20], xmm8
000071e7f4de06c8  lea rdi, [rsp]
000071e7f4de06cc  mov esi, 0x00
000071e7f4de06d1  mov rax, 0x562A51E82530
000071e7f4de06db  call rax
000071e7f4de06dd  movaps xmm13, [rsp]
000071e7f4de06e2  add rsp, 0x30
000071e7f4de06e6  vmovaps xmm0, [rsp]
000071e7f4de06eb  vmovaps xmm1, [rsp+0x10]
000071e7f4de06f1  vmovaps xmm2, [rsp+0x20]
000071e7f4de06f7  vmovaps xmm3, [rsp+0x30]
000071e7f4de06fd  vmovaps xmm4, [rsp+0x40]
000071e7f4de0703  vmovaps xmm5, [rsp+0x50]
000071e7f4de0709  vmovaps xmm6, [rsp+0x60]
000071e7f4de070f  vmovaps xmm7, [rsp+0x70]
000071e7f4de0715  vmovaps xmm8, [rsp+0x80]
000071e7f4de071e  vmovaps xmm9, [rsp+0x90]
000071e7f4de0727  vmovaps xmm10, [rsp+0xA0]
000071e7f4de0730  vmovaps xmm11, [rsp+0xB0]
000071e7f4de0739  vmovaps xmm12, [rsp+0xC0]
000071e7f4de0742  vmovaps xmm14, [rsp+0xD0]
000071e7f4de074b  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0754  add rsp, 0xF0
000071e7f4de075b  pop r11
000071e7f4de075d  pop r10
000071e7f4de075f  pop r9
000071e7f4de0761  pop r8
000071e7f4de0763  pop rsi
000071e7f4de0764  pop rdi
000071e7f4de0765  pop rdx
000071e7f4de0766  pop rcx
000071e7f4de0767  pop rax
000071e7f4de0768  add rsp, 0x08
000071e7f4de076c  jmp 0x000071E7F4DDC60F
000071e7f4de0771  sub rsp, 0x08
000071e7f4de0775  push rax
000071e7f4de0776  push rcx
000071e7f4de0777  push rdx
000071e7f4de0778  push rdi
000071e7f4de0779  push rsi
000071e7f4de077a  push r8
000071e7f4de077c  push r9
000071e7f4de077e  push r10
000071e7f4de0780  push r11
000071e7f4de0782  sub rsp, 0xF0
000071e7f4de0789  vmovaps [rsp], xmm0
000071e7f4de078e  vmovaps [rsp+0x10], xmm1
000071e7f4de0794  vmovaps [rsp+0x20], xmm2
000071e7f4de079a  vmovaps [rsp+0x30], xmm3
000071e7f4de07a0  vmovaps [rsp+0x40], xmm4
000071e7f4de07a6  vmovaps [rsp+0x50], xmm5
000071e7f4de07ac  vmovaps [rsp+0x60], xmm6
000071e7f4de07b2  vmovaps [rsp+0x70], xmm7
000071e7f4de07b8  vmovaps [rsp+0x80], xmm9
000071e7f4de07c1  vmovaps [rsp+0x90], xmm10
000071e7f4de07ca  vmovaps [rsp+0xA0], xmm11
000071e7f4de07d3  vmovaps [rsp+0xB0], xmm12
000071e7f4de07dc  vmovaps [rsp+0xC0], xmm13
000071e7f4de07e5  vmovaps [rsp+0xD0], xmm14
000071e7f4de07ee  vmovaps [rsp+0xE0], xmm15
000071e7f4de07f7  sub rsp, 0x30
000071e7f4de07fb  movaps [rsp], xmm8
000071e7f4de0800  movaps [rsp+0x10], xmm15
000071e7f4de0806  movaps [rsp+0x20], xmm9
000071e7f4de080c  lea rdi, [rsp]
000071e7f4de0810  mov esi, 0x00
000071e7f4de0815  mov rax, 0x562A51E82530
000071e7f4de081f  call rax
000071e7f4de0821  movaps xmm8, [rsp]
000071e7f4de0826  add rsp, 0x30
000071e7f4de082a  vmovaps xmm0, [rsp]
000071e7f4de082f  vmovaps xmm1, [rsp+0x10]
000071e7f4de0835  vmovaps xmm2, [rsp+0x20]
000071e7f4de083b  vmovaps xmm3, [rsp+0x30]
000071e7f4de0841  vmovaps xmm4, [rsp+0x40]
000071e7f4de0847  vmovaps xmm5, [rsp+0x50]
000071e7f4de084d  vmovaps xmm6, [rsp+0x60]
000071e7f4de0853  vmovaps xmm7, [rsp+0x70]
000071e7f4de0859  vmovaps xmm9, [rsp+0x80]
000071e7f4de0862  vmovaps xmm10, [rsp+0x90]
000071e7f4de086b  vmovaps xmm11, [rsp+0xA0]
000071e7f4de0874  vmovaps xmm12, [rsp+0xB0]
000071e7f4de087d  vmovaps xmm13, [rsp+0xC0]
000071e7f4de0886  vmovaps xmm14, [rsp+0xD0]
000071e7f4de088f  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0898  add rsp, 0xF0
000071e7f4de089f  pop r11
000071e7f4de08a1  pop r10
000071e7f4de08a3  pop r9
000071e7f4de08a5  pop r8
000071e7f4de08a7  pop rsi
000071e7f4de08a8  pop rdi
000071e7f4de08a9  pop rdx
000071e7f4de08aa  pop rcx
000071e7f4de08ab  pop rax
000071e7f4de08ac  add rsp, 0x08
000071e7f4de08b0  jmp 0x000071E7F4DDC63D
000071e7f4de08b5  sub rsp, 0x08
000071e7f4de08b9  push rax
000071e7f4de08ba  push rcx
000071e7f4de08bb  push rdx
000071e7f4de08bc  push rdi
000071e7f4de08bd  push rsi
000071e7f4de08be  push r8
000071e7f4de08c0  push r9
000071e7f4de08c2  push r10
000071e7f4de08c4  push r11
000071e7f4de08c6  sub rsp, 0xF0
000071e7f4de08cd  vmovaps [rsp], xmm0
000071e7f4de08d2  vmovaps [rsp+0x10], xmm1
000071e7f4de08d8  vmovaps [rsp+0x20], xmm2
000071e7f4de08de  vmovaps [rsp+0x30], xmm3
000071e7f4de08e4  vmovaps [rsp+0x40], xmm4
000071e7f4de08ea  vmovaps [rsp+0x50], xmm5
000071e7f4de08f0  vmovaps [rsp+0x60], xmm6
000071e7f4de08f6  vmovaps [rsp+0x70], xmm7
000071e7f4de08fc  vmovaps [rsp+0x80], xmm8
000071e7f4de0905  vmovaps [rsp+0x90], xmm9
000071e7f4de090e  vmovaps [rsp+0xA0], xmm10
000071e7f4de0917  vmovaps [rsp+0xB0], xmm11
000071e7f4de0920  vmovaps [rsp+0xC0], xmm12
000071e7f4de0929  vmovaps [rsp+0xD0], xmm13
000071e7f4de0932  vmovaps [rsp+0xE0], xmm14
000071e7f4de093b  sub rsp, 0x30
000071e7f4de093f  movaps [rsp], xmm15
000071e7f4de0944  movaps [rsp+0x10], xmm11
000071e7f4de094a  movaps [rsp+0x20], xmm6
000071e7f4de094f  lea rdi, [rsp]
000071e7f4de0953  mov esi, 0x00
000071e7f4de0958  mov rax, 0x562A51E82530
000071e7f4de0962  call rax
000071e7f4de0964  movaps xmm15, [rsp]
000071e7f4de0969  add rsp, 0x30
000071e7f4de096d  vmovaps xmm0, [rsp]
000071e7f4de0972  vmovaps xmm1, [rsp+0x10]
000071e7f4de0978  vmovaps xmm2, [rsp+0x20]
000071e7f4de097e  vmovaps xmm3, [rsp+0x30]
000071e7f4de0984  vmovaps xmm4, [rsp+0x40]
000071e7f4de098a  vmovaps xmm5, [rsp+0x50]
000071e7f4de0990  vmovaps xmm6, [rsp+0x60]
000071e7f4de0996  vmovaps xmm7, [rsp+0x70]
000071e7f4de099c  vmovaps xmm8, [rsp+0x80]
000071e7f4de09a5  vmovaps xmm9, [rsp+0x90]
000071e7f4de09ae  vmovaps xmm10, [rsp+0xA0]
000071e7f4de09b7  vmovaps xmm11, [rsp+0xB0]
000071e7f4de09c0  vmovaps xmm12, [rsp+0xC0]
000071e7f4de09c9  vmovaps xmm13, [rsp+0xD0]
000071e7f4de09d2  vmovaps xmm14, [rsp+0xE0]
000071e7f4de09db  add rsp, 0xF0
000071e7f4de09e2  pop r11
000071e7f4de09e4  pop r10
000071e7f4de09e6  pop r9
000071e7f4de09e8  pop r8
000071e7f4de09ea  pop rsi
000071e7f4de09eb  pop rdi
000071e7f4de09ec  pop rdx
000071e7f4de09ed  pop rcx
000071e7f4de09ee  pop rax
000071e7f4de09ef  add rsp, 0x08
000071e7f4de09f3  jmp 0x000071E7F4DDC658
000071e7f4de09f8  sub rsp, 0x08
000071e7f4de09fc  push rax
000071e7f4de09fd  push rcx
000071e7f4de09fe  push rdx
000071e7f4de09ff  push rdi
000071e7f4de0a00  push rsi
000071e7f4de0a01  push r8
000071e7f4de0a03  push r9
000071e7f4de0a05  push r10
000071e7f4de0a07  push r11
000071e7f4de0a09  sub rsp, 0xF0
000071e7f4de0a10  vmovaps [rsp], xmm0
000071e7f4de0a15  vmovaps [rsp+0x10], xmm1
000071e7f4de0a1b  vmovaps [rsp+0x20], xmm2
000071e7f4de0a21  vmovaps [rsp+0x30], xmm3
000071e7f4de0a27  vmovaps [rsp+0x40], xmm4
000071e7f4de0a2d  vmovaps [rsp+0x50], xmm5
000071e7f4de0a33  vmovaps [rsp+0x60], xmm6
000071e7f4de0a39  vmovaps [rsp+0x70], xmm8
000071e7f4de0a3f  vmovaps [rsp+0x80], xmm9
000071e7f4de0a48  vmovaps [rsp+0x90], xmm10
000071e7f4de0a51  vmovaps [rsp+0xA0], xmm11
000071e7f4de0a5a  vmovaps [rsp+0xB0], xmm12
000071e7f4de0a63  vmovaps [rsp+0xC0], xmm13
000071e7f4de0a6c  vmovaps [rsp+0xD0], xmm14
000071e7f4de0a75  vmovaps [rsp+0xE0], xmm15
000071e7f4de0a7e  sub rsp, 0x30
000071e7f4de0a82  movaps [rsp], xmm7
000071e7f4de0a86  movaps [rsp+0x10], xmm11
000071e7f4de0a8c  movaps [rsp+0x20], xmm9
000071e7f4de0a92  lea rdi, [rsp]
000071e7f4de0a96  mov esi, 0x00
000071e7f4de0a9b  mov rax, 0x562A51E82530
000071e7f4de0aa5  call rax
000071e7f4de0aa7  movaps xmm7, [rsp]
000071e7f4de0aab  add rsp, 0x30
000071e7f4de0aaf  vmovaps xmm0, [rsp]
000071e7f4de0ab4  vmovaps xmm1, [rsp+0x10]
000071e7f4de0aba  vmovaps xmm2, [rsp+0x20]
000071e7f4de0ac0  vmovaps xmm3, [rsp+0x30]
000071e7f4de0ac6  vmovaps xmm4, [rsp+0x40]
000071e7f4de0acc  vmovaps xmm5, [rsp+0x50]
000071e7f4de0ad2  vmovaps xmm6, [rsp+0x60]
000071e7f4de0ad8  vmovaps xmm8, [rsp+0x70]
000071e7f4de0ade  vmovaps xmm9, [rsp+0x80]
000071e7f4de0ae7  vmovaps xmm10, [rsp+0x90]
000071e7f4de0af0  vmovaps xmm11, [rsp+0xA0]
000071e7f4de0af9  vmovaps xmm12, [rsp+0xB0]
000071e7f4de0b02  vmovaps xmm13, [rsp+0xC0]
000071e7f4de0b0b  vmovaps xmm14, [rsp+0xD0]
000071e7f4de0b14  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0b1d  add rsp, 0xF0
000071e7f4de0b24  pop r11
000071e7f4de0b26  pop r10
000071e7f4de0b28  pop r9
000071e7f4de0b2a  pop r8
000071e7f4de0b2c  pop rsi
000071e7f4de0b2d  pop rdi
000071e7f4de0b2e  pop rdx
000071e7f4de0b2f  pop rcx
000071e7f4de0b30  pop rax
000071e7f4de0b31  add rsp, 0x08
000071e7f4de0b35  jmp 0x000071E7F4DDC685
000071e7f4de0b3a  sub rsp, 0x08
000071e7f4de0b3e  push rax
000071e7f4de0b3f  push rcx
000071e7f4de0b40  push rdx
000071e7f4de0b41  push rdi
000071e7f4de0b42  push rsi
000071e7f4de0b43  push r8
000071e7f4de0b45  push r9
000071e7f4de0b47  push r10
000071e7f4de0b49  push r11
000071e7f4de0b4b  sub rsp, 0xF0
000071e7f4de0b52  vmovaps [rsp], xmm0
000071e7f4de0b57  vmovaps [rsp+0x10], xmm1
000071e7f4de0b5d  vmovaps [rsp+0x20], xmm2
000071e7f4de0b63  vmovaps [rsp+0x30], xmm3
000071e7f4de0b69  vmovaps [rsp+0x40], xmm4
000071e7f4de0b6f  vmovaps [rsp+0x50], xmm5
000071e7f4de0b75  vmovaps [rsp+0x60], xmm6
000071e7f4de0b7b  vmovaps [rsp+0x70], xmm7
000071e7f4de0b81  vmovaps [rsp+0x80], xmm8
000071e7f4de0b8a  vmovaps [rsp+0x90], xmm9
000071e7f4de0b93  vmovaps [rsp+0xA0], xmm10
000071e7f4de0b9c  vmovaps [rsp+0xB0], xmm12
000071e7f4de0ba5  vmovaps [rsp+0xC0], xmm13
000071e7f4de0bae  vmovaps [rsp+0xD0], xmm14
000071e7f4de0bb7  vmovaps [rsp+0xE0], xmm15
000071e7f4de0bc0  sub rsp, 0x30
000071e7f4de0bc4  movaps [rsp], xmm11
000071e7f4de0bc9  movaps [rsp+0x10], xmm10
000071e7f4de0bcf  movaps [rsp+0x20], xmm14
000071e7f4de0bd5  lea rdi, [rsp]
000071e7f4de0bd9  mov esi, 0x00
000071e7f4de0bde  mov rax, 0x562A51E82530
000071e7f4de0be8  call rax
000071e7f4de0bea  movaps xmm11, [rsp]
000071e7f4de0bef  add rsp, 0x30
000071e7f4de0bf3  vmovaps xmm0, [rsp]
000071e7f4de0bf8  vmovaps xmm1, [rsp+0x10]
000071e7f4de0bfe  vmovaps xmm2, [rsp+0x20]
000071e7f4de0c04  vmovaps xmm3, [rsp+0x30]
000071e7f4de0c0a  vmovaps xmm4, [rsp+0x40]
000071e7f4de0c10  vmovaps xmm5, [rsp+0x50]
000071e7f4de0c16  vmovaps xmm6, [rsp+0x60]
000071e7f4de0c1c  vmovaps xmm7, [rsp+0x70]
000071e7f4de0c22  vmovaps xmm8, [rsp+0x80]
000071e7f4de0c2b  vmovaps xmm9, [rsp+0x90]
000071e7f4de0c34  vmovaps xmm10, [rsp+0xA0]
000071e7f4de0c3d  vmovaps xmm12, [rsp+0xB0]
000071e7f4de0c46  vmovaps xmm13, [rsp+0xC0]
000071e7f4de0c4f  vmovaps xmm14, [rsp+0xD0]
000071e7f4de0c58  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0c61  add rsp, 0xF0
000071e7f4de0c68  pop r11
000071e7f4de0c6a  pop r10
000071e7f4de0c6c  pop r9
000071e7f4de0c6e  pop r8
000071e7f4de0c70  pop rsi
000071e7f4de0c71  pop rdi
000071e7f4de0c72  pop rdx
000071e7f4de0c73  pop rcx
000071e7f4de0c74  pop rax
000071e7f4de0c75  add rsp, 0x08
000071e7f4de0c79  jmp 0x000071E7F4DDC6A0
000071e7f4de0c7e  call 0x000071E7F4CC33A0
000071e7f4de0c83  jmp 0x000071E7F4DDC6AA
000071e7f4de0c88  sub rsp, 0x08
000071e7f4de0c8c  push rax
000071e7f4de0c8d  push rcx
000071e7f4de0c8e  push rdx
000071e7f4de0c8f  push rdi
000071e7f4de0c90  push rsi
000071e7f4de0c91  push r8
000071e7f4de0c93  push r9
000071e7f4de0c95  push r10
000071e7f4de0c97  push r11
000071e7f4de0c99  sub rsp, 0xF0
000071e7f4de0ca0  vmovaps [rsp], xmm0
000071e7f4de0ca5  vmovaps [rsp+0x10], xmm1
000071e7f4de0cab  vmovaps [rsp+0x20], xmm2
000071e7f4de0cb1  vmovaps [rsp+0x30], xmm3
000071e7f4de0cb7  vmovaps [rsp+0x40], xmm4
000071e7f4de0cbd  vmovaps [rsp+0x50], xmm5
000071e7f4de0cc3  vmovaps [rsp+0x60], xmm6
000071e7f4de0cc9  vmovaps [rsp+0x70], xmm7
000071e7f4de0ccf  vmovaps [rsp+0x80], xmm8
000071e7f4de0cd8  vmovaps [rsp+0x90], xmm9
000071e7f4de0ce1  vmovaps [rsp+0xA0], xmm11
000071e7f4de0cea  vmovaps [rsp+0xB0], xmm12
000071e7f4de0cf3  vmovaps [rsp+0xC0], xmm13
000071e7f4de0cfc  vmovaps [rsp+0xD0], xmm14
000071e7f4de0d05  vmovaps [rsp+0xE0], xmm15
000071e7f4de0d0e  sub rsp, 0x30
000071e7f4de0d12  movaps [rsp], xmm10
000071e7f4de0d17  movaps [rsp+0x10], xmm1
000071e7f4de0d1c  movaps [rsp+0x20], xmm12
000071e7f4de0d22  lea rdi, [rsp]
000071e7f4de0d26  mov esi, 0x00
000071e7f4de0d2b  mov rax, 0x562A51E82530
000071e7f4de0d35  call rax
000071e7f4de0d37  movaps xmm10, [rsp]
000071e7f4de0d3c  add rsp, 0x30
000071e7f4de0d40  vmovaps xmm0, [rsp]
000071e7f4de0d45  vmovaps xmm1, [rsp+0x10]
000071e7f4de0d4b  vmovaps xmm2, [rsp+0x20]
000071e7f4de0d51  vmovaps xmm3, [rsp+0x30]
000071e7f4de0d57  vmovaps xmm4, [rsp+0x40]
000071e7f4de0d5d  vmovaps xmm5, [rsp+0x50]
000071e7f4de0d63  vmovaps xmm6, [rsp+0x60]
000071e7f4de0d69  vmovaps xmm7, [rsp+0x70]
000071e7f4de0d6f  vmovaps xmm8, [rsp+0x80]
000071e7f4de0d78  vmovaps xmm9, [rsp+0x90]
000071e7f4de0d81  vmovaps xmm11, [rsp+0xA0]
000071e7f4de0d8a  vmovaps xmm12, [rsp+0xB0]
000071e7f4de0d93  vmovaps xmm13, [rsp+0xC0]
000071e7f4de0d9c  vmovaps xmm14, [rsp+0xD0]
000071e7f4de0da5  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0dae  add rsp, 0xF0
000071e7f4de0db5  pop r11
000071e7f4de0db7  pop r10
000071e7f4de0db9  pop r9
000071e7f4de0dbb  pop r8
000071e7f4de0dbd  pop rsi
000071e7f4de0dbe  pop rdi
000071e7f4de0dbf  pop rdx
000071e7f4de0dc0  pop rcx
000071e7f4de0dc1  pop rax
000071e7f4de0dc2  add rsp, 0x08
000071e7f4de0dc6  jmp 0x000071E7F4DDC6CD
000071e7f4de0dcb  sub rsp, 0x08
000071e7f4de0dcf  push rax
000071e7f4de0dd0  push rcx
000071e7f4de0dd1  push rdx
000071e7f4de0dd2  push rdi
000071e7f4de0dd3  push rsi
000071e7f4de0dd4  push r8
000071e7f4de0dd6  push r9
000071e7f4de0dd8  push r10
000071e7f4de0dda  push r11
000071e7f4de0ddc  sub rsp, 0xF0
000071e7f4de0de3  vmovaps [rsp], xmm0
000071e7f4de0de8  vmovaps [rsp+0x10], xmm1
000071e7f4de0dee  vmovaps [rsp+0x20], xmm2
000071e7f4de0df4  vmovaps [rsp+0x30], xmm3
000071e7f4de0dfa  vmovaps [rsp+0x40], xmm4
000071e7f4de0e00  vmovaps [rsp+0x50], xmm5
000071e7f4de0e06  vmovaps [rsp+0x60], xmm6
000071e7f4de0e0c  vmovaps [rsp+0x70], xmm7
000071e7f4de0e12  vmovaps [rsp+0x80], xmm8
000071e7f4de0e1b  vmovaps [rsp+0x90], xmm9
000071e7f4de0e24  vmovaps [rsp+0xA0], xmm10
000071e7f4de0e2d  vmovaps [rsp+0xB0], xmm11
000071e7f4de0e36  vmovaps [rsp+0xC0], xmm13
000071e7f4de0e3f  vmovaps [rsp+0xD0], xmm14
000071e7f4de0e48  vmovaps [rsp+0xE0], xmm15
000071e7f4de0e51  sub rsp, 0x30
000071e7f4de0e55  movaps [rsp], xmm12
000071e7f4de0e5a  movaps [rsp+0x10], xmm14
000071e7f4de0e60  movaps [rsp+0x20], xmm1
000071e7f4de0e65  lea rdi, [rsp]
000071e7f4de0e69  mov esi, 0x00
000071e7f4de0e6e  mov rax, 0x562A51E82530
000071e7f4de0e78  call rax
000071e7f4de0e7a  movaps xmm12, [rsp]
000071e7f4de0e7f  add rsp, 0x30
000071e7f4de0e83  vmovaps xmm0, [rsp]
000071e7f4de0e88  vmovaps xmm1, [rsp+0x10]
000071e7f4de0e8e  vmovaps xmm2, [rsp+0x20]
000071e7f4de0e94  vmovaps xmm3, [rsp+0x30]
000071e7f4de0e9a  vmovaps xmm4, [rsp+0x40]
000071e7f4de0ea0  vmovaps xmm5, [rsp+0x50]
000071e7f4de0ea6  vmovaps xmm6, [rsp+0x60]
000071e7f4de0eac  vmovaps xmm7, [rsp+0x70]
000071e7f4de0eb2  vmovaps xmm8, [rsp+0x80]
000071e7f4de0ebb  vmovaps xmm9, [rsp+0x90]
000071e7f4de0ec4  vmovaps xmm10, [rsp+0xA0]
000071e7f4de0ecd  vmovaps xmm11, [rsp+0xB0]
000071e7f4de0ed6  vmovaps xmm13, [rsp+0xC0]
000071e7f4de0edf  vmovaps xmm14, [rsp+0xD0]
000071e7f4de0ee8  vmovaps xmm15, [rsp+0xE0]
000071e7f4de0ef1  add rsp, 0xF0
000071e7f4de0ef8  pop r11
000071e7f4de0efa  pop r10
000071e7f4de0efc  pop r9
000071e7f4de0efe  pop r8
000071e7f4de0f00  pop rsi
000071e7f4de0f01  pop rdi
000071e7f4de0f02  pop rdx
000071e7f4de0f03  pop rcx
000071e7f4de0f04  pop rax
000071e7f4de0f05  add rsp, 0x08
000071e7f4de0f09  jmp 0x000071E7F4DDC6FC
000071e7f4de0f0e  sub rsp, 0x08
000071e7f4de0f12  push rax
000071e7f4de0f13  push rcx
000071e7f4de0f14  push rdx
000071e7f4de0f15  push rdi
000071e7f4de0f16  push rsi
000071e7f4de0f17  push r8
000071e7f4de0f19  push r9
000071e7f4de0f1b  push r10
000071e7f4de0f1d  push r11
000071e7f4de0f1f  sub rsp, 0xF0
000071e7f4de0f26  vmovaps [rsp], xmm0
000071e7f4de0f2b  vmovaps [rsp+0x10], xmm1
000071e7f4de0f31  vmovaps [rsp+0x20], xmm2
000071e7f4de0f37  vmovaps [rsp+0x30], xmm3
000071e7f4de0f3d  vmovaps [rsp+0x40], xmm4
000071e7f4de0f43  vmovaps [rsp+0x50], xmm5
000071e7f4de0f49  vmovaps [rsp+0x60], xmm6
000071e7f4de0f4f  vmovaps [rsp+0x70], xmm7
000071e7f4de0f55  vmovaps [rsp+0x80], xmm8
000071e7f4de0f5e  vmovaps [rsp+0x90], xmm9
000071e7f4de0f67  vmovaps [rsp+0xA0], xmm10
000071e7f4de0f70  vmovaps [rsp+0xB0], xmm11
000071e7f4de0f79  vmovaps [rsp+0xC0], xmm12
000071e7f4de0f82  vmovaps [rsp+0xD0], xmm13
000071e7f4de0f8b  vmovaps [rsp+0xE0], xmm15
000071e7f4de0f94  sub rsp, 0x30
000071e7f4de0f98  movaps [rsp], xmm14
000071e7f4de0f9d  movaps [rsp+0x10], xmm9
000071e7f4de0fa3  movaps [rsp+0x20], xmm1
000071e7f4de0fa8  lea rdi, [rsp]
000071e7f4de0fac  mov esi, 0x00
000071e7f4de0fb1  mov rax, 0x562A51E82530
000071e7f4de0fbb  call rax
000071e7f4de0fbd  movaps xmm14, [rsp]
000071e7f4de0fc2  add rsp, 0x30
000071e7f4de0fc6  vmovaps xmm0, [rsp]
000071e7f4de0fcb  vmovaps xmm1, [rsp+0x10]
000071e7f4de0fd1  vmovaps xmm2, [rsp+0x20]
000071e7f4de0fd7  vmovaps xmm3, [rsp+0x30]
000071e7f4de0fdd  vmovaps xmm4, [rsp+0x40]
000071e7f4de0fe3  vmovaps xmm5, [rsp+0x50]
000071e7f4de0fe9  vmovaps xmm6, [rsp+0x60]
000071e7f4de0fef  vmovaps xmm7, [rsp+0x70]
000071e7f4de0ff5  vmovaps xmm8, [rsp+0x80]
000071e7f4de0ffe  vmovaps xmm9, [rsp+0x90]
000071e7f4de1007  vmovaps xmm10, [rsp+0xA0]
000071e7f4de1010  vmovaps xmm11, [rsp+0xB0]
000071e7f4de1019  vmovaps xmm12, [rsp+0xC0]
000071e7f4de1022  vmovaps xmm13, [rsp+0xD0]
000071e7f4de102b  vmovaps xmm15, [rsp+0xE0]
000071e7f4de1034  add rsp, 0xF0
000071e7f4de103b  pop r11
000071e7f4de103d  pop r10
000071e7f4de103f  pop r9
000071e7f4de1041  pop r8
000071e7f4de1043  pop rsi
000071e7f4de1044  pop rdi
000071e7f4de1045  pop rdx
000071e7f4de1046  pop rcx
000071e7f4de1047  pop rax
000071e7f4de1048  add rsp, 0x08
000071e7f4de104c  jmp 0x000071E7F4DDC72B
000071e7f4de1051  sub rsp, 0x08
000071e7f4de1055  push rax
000071e7f4de1056  push rcx
000071e7f4de1057  push rdx
000071e7f4de1058  push rdi
000071e7f4de1059  push rsi
000071e7f4de105a  push r8
000071e7f4de105c  push r9
000071e7f4de105e  push r10
000071e7f4de1060  push r11
000071e7f4de1062  sub rsp, 0xF0
000071e7f4de1069  vmovaps [rsp], xmm0
000071e7f4de106e  vmovaps [rsp+0x10], xmm2
000071e7f4de1074  vmovaps [rsp+0x20], xmm3
000071e7f4de107a  vmovaps [rsp+0x30], xmm4
000071e7f4de1080  vmovaps [rsp+0x40], xmm5
000071e7f4de1086  vmovaps [rsp+0x50], xmm6
000071e7f4de108c  vmovaps [rsp+0x60], xmm7
000071e7f4de1092  vmovaps [rsp+0x70], xmm8
000071e7f4de1098  vmovaps [rsp+0x80], xmm9
000071e7f4de10a1  vmovaps [rsp+0x90], xmm10
000071e7f4de10aa  vmovaps [rsp+0xA0], xmm11
000071e7f4de10b3  vmovaps [rsp+0xB0], xmm12
000071e7f4de10bc  vmovaps [rsp+0xC0], xmm13
000071e7f4de10c5  vmovaps [rsp+0xD0], xmm14
000071e7f4de10ce  vmovaps [rsp+0xE0], xmm15
000071e7f4de10d7  sub rsp, 0x30
000071e7f4de10db  movaps [rsp], xmm1
000071e7f4de10df  movaps [rsp+0x10], xmm13
000071e7f4de10e5  movaps [rsp+0x20], xmm8
000071e7f4de10eb  lea rdi, [rsp]
000071e7f4de10ef  mov esi, 0x00
000071e7f4de10f4  mov rax, 0x562A51E82530
000071e7f4de10fe  call rax
000071e7f4de1100  movaps xmm1, [rsp]
000071e7f4de1104  add rsp, 0x30
000071e7f4de1108  vmovaps xmm0, [rsp]
000071e7f4de110d  vmovaps xmm2, [rsp+0x10]
000071e7f4de1113  vmovaps xmm3, [rsp+0x20]
000071e7f4de1119  vmovaps xmm4, [rsp+0x30]
000071e7f4de111f  vmovaps xmm5, [rsp+0x40]
000071e7f4de1125  vmovaps xmm6, [rsp+0x50]
000071e7f4de112b  vmovaps xmm7, [rsp+0x60]
000071e7f4de1131  vmovaps xmm8, [rsp+0x70]
000071e7f4de1137  vmovaps xmm9, [rsp+0x80]
000071e7f4de1140  vmovaps xmm10, [rsp+0x90]
000071e7f4de1149  vmovaps xmm11, [rsp+0xA0]
000071e7f4de1152  vmovaps xmm12, [rsp+0xB0]
000071e7f4de115b  vmovaps xmm13, [rsp+0xC0]
000071e7f4de1164  vmovaps xmm14, [rsp+0xD0]
000071e7f4de116d  vmovaps xmm15, [rsp+0xE0]
000071e7f4de1176  add rsp, 0xF0
000071e7f4de117d  pop r11
000071e7f4de117f  pop r10
000071e7f4de1181  pop r9
000071e7f4de1183  pop r8
000071e7f4de1185  pop rsi
000071e7f4de1186  pop rdi
000071e7f4de1187  pop rdx
000071e7f4de1188  pop rcx
000071e7f4de1189  pop rax
000071e7f4de118a  add rsp, 0x08
000071e7f4de118e  jmp 0x000071E7F4DDC74D
000071e7f4de1193  call 0x000071E7F4C0C260
000071e7f4de1198  jmp 0x000071E7F4DDC75B
000071e7f4de119d  call 0x000071E7F4CBD750
000071e7f4de11a2  jmp 0x000071E7F4DDC765
000071e7f4de11a7  sub rsp, 0x08
000071e7f4de11ab  push rax
000071e7f4de11ac  push rcx
000071e7f4de11ad  push rdx
000071e7f4de11ae  push rdi
000071e7f4de11af  push rsi
000071e7f4de11b0  push r8
000071e7f4de11b2  push r9
000071e7f4de11b4  push r10
000071e7f4de11b6  push r11
000071e7f4de11b8  sub rsp, 0xF0
000071e7f4de11bf  vmovaps [rsp], xmm0
000071e7f4de11c4  vmovaps [rsp+0x10], xmm1
000071e7f4de11ca  vmovaps [rsp+0x20], xmm2
000071e7f4de11d0  vmovaps [rsp+0x30], xmm3
000071e7f4de11d6  vmovaps [rsp+0x40], xmm4
000071e7f4de11dc  vmovaps [rsp+0x50], xmm5
000071e7f4de11e2  vmovaps [rsp+0x60], xmm6
000071e7f4de11e8  vmovaps [rsp+0x70], xmm7
000071e7f4de11ee  vmovaps [rsp+0x80], xmm9
000071e7f4de11f7  vmovaps [rsp+0x90], xmm10
000071e7f4de1200  vmovaps [rsp+0xA0], xmm11
000071e7f4de1209  vmovaps [rsp+0xB0], xmm12
000071e7f4de1212  vmovaps [rsp+0xC0], xmm13
000071e7f4de121b  vmovaps [rsp+0xD0], xmm14
000071e7f4de1224  vmovaps [rsp+0xE0], xmm15
000071e7f4de122d  sub rsp, 0x30
000071e7f4de1231  movaps [rsp], xmm8
000071e7f4de1236  movaps [rsp+0x10], xmm15
000071e7f4de123c  movaps [rsp+0x20], xmm7
000071e7f4de1241  lea rdi, [rsp]
000071e7f4de1245  mov esi, 0x00
000071e7f4de124a  mov rax, 0x562A51E82530
000071e7f4de1254  call rax
000071e7f4de1256  movaps xmm8, [rsp]
000071e7f4de125b  add rsp, 0x30
000071e7f4de125f  vmovaps xmm0, [rsp]
000071e7f4de1264  vmovaps xmm1, [rsp+0x10]
000071e7f4de126a  vmovaps xmm2, [rsp+0x20]
000071e7f4de1270  vmovaps xmm3, [rsp+0x30]
000071e7f4de1276  vmovaps xmm4, [rsp+0x40]
000071e7f4de127c  vmovaps xmm5, [rsp+0x50]
000071e7f4de1282  vmovaps xmm6, [rsp+0x60]
000071e7f4de1288  vmovaps xmm7, [rsp+0x70]
000071e7f4de128e  vmovaps xmm9, [rsp+0x80]
000071e7f4de1297  vmovaps xmm10, [rsp+0x90]
000071e7f4de12a0  vmovaps xmm11, [rsp+0xA0]
000071e7f4de12a9  vmovaps xmm12, [rsp+0xB0]
000071e7f4de12b2  vmovaps xmm13, [rsp+0xC0]
000071e7f4de12bb  vmovaps xmm14, [rsp+0xD0]
000071e7f4de12c4  vmovaps xmm15, [rsp+0xE0]
000071e7f4de12cd  add rsp, 0xF0
000071e7f4de12d4  pop r11
000071e7f4de12d6  pop r10
000071e7f4de12d8  pop r9
000071e7f4de12da  pop r8
000071e7f4de12dc  pop rsi
000071e7f4de12dd  pop rdi
000071e7f4de12de  pop rdx
000071e7f4de12df  pop rcx
000071e7f4de12e0  pop rax
000071e7f4de12e1  add rsp, 0x08
000071e7f4de12e5  jmp 0x000071E7F4DDC787
000071e7f4de12ea  sub rsp, 0x08
000071e7f4de12ee  push rax
000071e7f4de12ef  push rcx
000071e7f4de12f0  push rdx
000071e7f4de12f1  push rdi
000071e7f4de12f2  push rsi
000071e7f4de12f3  push r8
000071e7f4de12f5  push r9
000071e7f4de12f7  push r10
000071e7f4de12f9  push r11
000071e7f4de12fb  sub rsp, 0xF0
000071e7f4de1302  vmovaps [rsp], xmm0
000071e7f4de1307  vmovaps [rsp+0x10], xmm1
000071e7f4de130d  vmovaps [rsp+0x20], xmm2
000071e7f4de1313  vmovaps [rsp+0x30], xmm3
000071e7f4de1319  vmovaps [rsp+0x40], xmm4
000071e7f4de131f  vmovaps [rsp+0x50], xmm5
000071e7f4de1325  vmovaps [rsp+0x60], xmm6
000071e7f4de132b  vmovaps [rsp+0x70], xmm8
000071e7f4de1331  vmovaps [rsp+0x80], xmm9
000071e7f4de133a  vmovaps [rsp+0x90], xmm10
000071e7f4de1343  vmovaps [rsp+0xA0], xmm11
000071e7f4de134c  vmovaps [rsp+0xB0], xmm12
000071e7f4de1355  vmovaps [rsp+0xC0], xmm13
000071e7f4de135e  vmovaps [rsp+0xD0], xmm14
000071e7f4de1367  vmovaps [rsp+0xE0], xmm15
000071e7f4de1370  sub rsp, 0x30
000071e7f4de1374  movaps [rsp], xmm7
000071e7f4de1378  movaps [rsp+0x10], xmm9
000071e7f4de137e  movaps [rsp+0x20], xmm15
000071e7f4de1384  lea rdi, [rsp]
000071e7f4de1388  mov esi, 0x00
000071e7f4de138d  mov rax, 0x562A51E82530
000071e7f4de1397  call rax
000071e7f4de1399  movaps xmm7, [rsp]
000071e7f4de139d  add rsp, 0x30
000071e7f4de13a1  vmovaps xmm0, [rsp]
000071e7f4de13a6  vmovaps xmm1, [rsp+0x10]
000071e7f4de13ac  vmovaps xmm2, [rsp+0x20]
000071e7f4de13b2  vmovaps xmm3, [rsp+0x30]
000071e7f4de13b8  vmovaps xmm4, [rsp+0x40]
000071e7f4de13be  vmovaps xmm5, [rsp+0x50]
000071e7f4de13c4  vmovaps xmm6, [rsp+0x60]
000071e7f4de13ca  vmovaps xmm8, [rsp+0x70]
000071e7f4de13d0  vmovaps xmm9, [rsp+0x80]
000071e7f4de13d9  vmovaps xmm10, [rsp+0x90]
000071e7f4de13e2  vmovaps xmm11, [rsp+0xA0]
000071e7f4de13eb  vmovaps xmm12, [rsp+0xB0]
000071e7f4de13f4  vmovaps xmm13, [rsp+0xC0]
000071e7f4de13fd  vmovaps xmm14, [rsp+0xD0]
000071e7f4de1406  vmovaps xmm15, [rsp+0xE0]
000071e7f4de140f  add rsp, 0xF0
000071e7f4de1416  pop r11
000071e7f4de1418  pop r10
000071e7f4de141a  pop r9
000071e7f4de141c  pop r8
000071e7f4de141e  pop rsi
000071e7f4de141f  pop rdi
000071e7f4de1420  pop rdx
000071e7f4de1421  pop rcx
000071e7f4de1422  pop rax
000071e7f4de1423  add rsp, 0x08
000071e7f4de1427  jmp 0x000071E7F4DDC7B4
000071e7f4de142c  sub rsp, 0x08
000071e7f4de1430  push rax
000071e7f4de1431  push rcx
000071e7f4de1432  push rdx
000071e7f4de1433  push rdi
000071e7f4de1434  push rsi
000071e7f4de1435  push r8
000071e7f4de1437  push r9
000071e7f4de1439  push r10
000071e7f4de143b  push r11
000071e7f4de143d  sub rsp, 0xF0
000071e7f4de1444  vmovaps [rsp], xmm0
000071e7f4de1449  vmovaps [rsp+0x10], xmm1
000071e7f4de144f  vmovaps [rsp+0x20], xmm2
000071e7f4de1455  vmovaps [rsp+0x30], xmm3
000071e7f4de145b  vmovaps [rsp+0x40], xmm4
000071e7f4de1461  vmovaps [rsp+0x50], xmm5
000071e7f4de1467  vmovaps [rsp+0x60], xmm6
000071e7f4de146d  vmovaps [rsp+0x70], xmm7
000071e7f4de1473  vmovaps [rsp+0x80], xmm8
000071e7f4de147c  vmovaps [rsp+0x90], xmm10
000071e7f4de1485  vmovaps [rsp+0xA0], xmm11
000071e7f4de148e  vmovaps [rsp+0xB0], xmm12
000071e7f4de1497  vmovaps [rsp+0xC0], xmm13
000071e7f4de14a0  vmovaps [rsp+0xD0], xmm14
000071e7f4de14a9  vmovaps [rsp+0xE0], xmm15
000071e7f4de14b2  sub rsp, 0x30
000071e7f4de14b6  movaps [rsp], xmm9
000071e7f4de14bb  movaps [rsp+0x10], xmm13
000071e7f4de14c1  movaps [rsp+0x20], xmm15
000071e7f4de14c7  lea rdi, [rsp]
000071e7f4de14cb  mov esi, 0x00
000071e7f4de14d0  mov rax, 0x562A51E82530
000071e7f4de14da  call rax
000071e7f4de14dc  movaps xmm9, [rsp]
000071e7f4de14e1  add rsp, 0x30
000071e7f4de14e5  vmovaps xmm0, [rsp]
000071e7f4de14ea  vmovaps xmm1, [rsp+0x10]
000071e7f4de14f0  vmovaps xmm2, [rsp+0x20]
000071e7f4de14f6  vmovaps xmm3, [rsp+0x30]
000071e7f4de14fc  vmovaps xmm4, [rsp+0x40]
000071e7f4de1502  vmovaps xmm5, [rsp+0x50]
000071e7f4de1508  vmovaps xmm6, [rsp+0x60]
000071e7f4de150e  vmovaps xmm7, [rsp+0x70]
000071e7f4de1514  vmovaps xmm8, [rsp+0x80]
000071e7f4de151d  vmovaps xmm10, [rsp+0x90]
000071e7f4de1526  vmovaps xmm11, [rsp+0xA0]
000071e7f4de152f  vmovaps xmm12, [rsp+0xB0]
000071e7f4de1538  vmovaps xmm13, [rsp+0xC0]
000071e7f4de1541  vmovaps xmm14, [rsp+0xD0]
000071e7f4de154a  vmovaps xmm15, [rsp+0xE0]
000071e7f4de1553  add rsp, 0xF0
000071e7f4de155a  pop r11
000071e7f4de155c  pop r10
000071e7f4de155e  pop r9
000071e7f4de1560  pop r8
000071e7f4de1562  pop rsi
000071e7f4de1563  pop rdi
000071e7f4de1564  pop rdx
000071e7f4de1565  pop rcx
000071e7f4de1566  pop rax
000071e7f4de1567  add rsp, 0x08
000071e7f4de156b  jmp 0x000071E7F4DDC7E2
000071e7f4de1570  sub rsp, 0x08
000071e7f4de1574  push rax
000071e7f4de1575  push rcx
000071e7f4de1576  push rdx
000071e7f4de1577  push rdi
000071e7f4de1578  push rsi
000071e7f4de1579  push r8
000071e7f4de157b  push r9
000071e7f4de157d  push r10
000071e7f4de157f  push r11
000071e7f4de1581  sub rsp, 0xF0
000071e7f4de1588  vmovaps [rsp], xmm0
000071e7f4de158d  vmovaps [rsp+0x10], xmm1
000071e7f4de1593  vmovaps [rsp+0x20], xmm2
000071e7f4de1599  vmovaps [rsp+0x30], xmm3
000071e7f4de159f  vmovaps [rsp+0x40], xmm4
000071e7f4de15a5  vmovaps [rsp+0x50], xmm5
000071e7f4de15ab  vmovaps [rsp+0x60], xmm6
000071e7f4de15b1  vmovaps [rsp+0x70], xmm7
000071e7f4de15b7  vmovaps [rsp+0x80], xmm8
000071e7f4de15c0  vmovaps [rsp+0x90], xmm9
000071e7f4de15c9  vmovaps [rsp+0xA0], xmm10
000071e7f4de15d2  vmovaps [rsp+0xB0], xmm11
000071e7f4de15db  vmovaps [rsp+0xC0], xmm12
000071e7f4de15e4  vmovaps [rsp+0xD0], xmm13
000071e7f4de15ed  vmovaps [rsp+0xE0], xmm14
000071e7f4de15f6  sub rsp, 0x30
000071e7f4de15fa  movaps [rsp], xmm15
000071e7f4de15ff  movaps [rsp+0x10], xmm11
000071e7f4de1605  movaps [rsp+0x20], xmm12
000071e7f4de160b  lea rdi, [rsp]
000071e7f4de160f  mov esi, 0x00
000071e7f4de1614  mov rax, 0x562A51E82530
000071e7f4de161e  call rax
000071e7f4de1620  movaps xmm15, [rsp]
000071e7f4de1625  add rsp, 0x30
000071e7f4de1629  vmovaps xmm0, [rsp]
000071e7f4de162e  vmovaps xmm1, [rsp+0x10]
000071e7f4de1634  vmovaps xmm2, [rsp+0x20]
000071e7f4de163a  vmovaps xmm3, [rsp+0x30]
000071e7f4de1640  vmovaps xmm4, [rsp+0x40]
000071e7f4de1646  vmovaps xmm5, [rsp+0x50]
000071e7f4de164c  vmovaps xmm6, [rsp+0x60]
000071e7f4de1652  vmovaps xmm7, [rsp+0x70]
000071e7f4de1658  vmovaps xmm8, [rsp+0x80]
000071e7f4de1661  vmovaps xmm9, [rsp+0x90]
000071e7f4de166a  vmovaps xmm10, [rsp+0xA0]
000071e7f4de1673  vmovaps xmm11, [rsp+0xB0]
000071e7f4de167c  vmovaps xmm12, [rsp+0xC0]
000071e7f4de1685  vmovaps xmm13, [rsp+0xD0]
000071e7f4de168e  vmovaps xmm14, [rsp+0xE0]
000071e7f4de1697  add rsp, 0xF0
000071e7f4de169e  pop r11
000071e7f4de16a0  pop r10
000071e7f4de16a2  pop r9
000071e7f4de16a4  pop r8
000071e7f4de16a6  pop rsi
000071e7f4de16a7  pop rdi
000071e7f4de16a8  pop rdx
000071e7f4de16a9  pop rcx
000071e7f4de16aa  pop rax
000071e7f4de16ab  add rsp, 0x08
000071e7f4de16af  jmp 0x000071E7F4DDC7FD
000071e7f4de16b4  sub rsp, 0x08
000071e7f4de16b8  push rax
000071e7f4de16b9  push rcx
000071e7f4de16ba  push rdx
000071e7f4de16bb  push rdi
000071e7f4de16bc  push rsi
000071e7f4de16bd  push r8
000071e7f4de16bf  push r9
000071e7f4de16c1  push r10
000071e7f4de16c3  push r11
000071e7f4de16c5  sub rsp, 0xF0
000071e7f4de16cc  vmovaps [rsp], xmm0
000071e7f4de16d1  vmovaps [rsp+0x10], xmm1
000071e7f4de16d7  vmovaps [rsp+0x20], xmm2
000071e7f4de16dd  vmovaps [rsp+0x30], xmm3
000071e7f4de16e3  vmovaps [rsp+0x40], xmm4
000071e7f4de16e9  vmovaps [rsp+0x50], xmm5
000071e7f4de16ef  vmovaps [rsp+0x60], xmm6
000071e7f4de16f5  vmovaps [rsp+0x70], xmm7
000071e7f4de16fb  vmovaps [rsp+0x80], xmm8
000071e7f4de1704  vmovaps [rsp+0x90], xmm9
000071e7f4de170d  vmovaps [rsp+0xA0], xmm10
000071e7f4de1716  vmovaps [rsp+0xB0], xmm11
000071e7f4de171f  vmovaps [rsp+0xC0], xmm12
000071e7f4de1728  vmovaps [rsp+0xD0], xmm14
000071e7f4de1731  vmovaps [rsp+0xE0], xmm15
000071e7f4de173a  sub rsp, 0x30
000071e7f4de173e  movaps [rsp], xmm13
000071e7f4de1743  movaps [rsp+0x10], xmm10
000071e7f4de1749  movaps [rsp+0x20], xmm14
000071e7f4de174f  lea rdi, [rsp]
000071e7f4de1753  mov esi, 0x00
000071e7f4de1758  mov rax, 0x562A51E82530
000071e7f4de1762  call rax
000071e7f4de1764  movaps xmm13, [rsp]
000071e7f4de1769  add rsp, 0x30
000071e7f4de176d  vmovaps xmm0, [rsp]
000071e7f4de1772  vmovaps xmm1, [rsp+0x10]
000071e7f4de1778  vmovaps xmm2, [rsp+0x20]
000071e7f4de177e  vmovaps xmm3, [rsp+0x30]
000071e7f4de1784  vmovaps xmm4, [rsp+0x40]
000071e7f4de178a  vmovaps xmm5, [rsp+0x50]
000071e7f4de1790  vmovaps xmm6, [rsp+0x60]
000071e7f4de1796  vmovaps xmm7, [rsp+0x70]
000071e7f4de179c  vmovaps xmm8, [rsp+0x80]
000071e7f4de17a5  vmovaps xmm9, [rsp+0x90]
000071e7f4de17ae  vmovaps xmm10, [rsp+0xA0]
000071e7f4de17b7  vmovaps xmm11, [rsp+0xB0]
000071e7f4de17c0  vmovaps xmm12, [rsp+0xC0]
000071e7f4de17c9  vmovaps xmm14, [rsp+0xD0]
000071e7f4de17d2  vmovaps xmm15, [rsp+0xE0]
000071e7f4de17db  add rsp, 0xF0
000071e7f4de17e2  pop r11
000071e7f4de17e4  pop r10
000071e7f4de17e6  pop r9
000071e7f4de17e8  pop r8
000071e7f4de17ea  pop rsi
000071e7f4de17eb  pop rdi
000071e7f4de17ec  pop rdx
000071e7f4de17ed  pop rcx
000071e7f4de17ee  pop rax
000071e7f4de17ef  add rsp, 0x08
000071e7f4de17f3  jmp 0x000071E7F4DDC820
000071e7f4de17f8  sub rsp, 0x08
000071e7f4de17fc  push rax
000071e7f4de17fd  push rcx
000071e7f4de17fe  push rdx
000071e7f4de17ff  push rdi
000071e7f4de1800  push rsi
000071e7f4de1801  push r8
000071e7f4de1803  push r9
000071e7f4de1805  push r10
000071e7f4de1807  push r11
000071e7f4de1809  sub rsp, 0xF0
000071e7f4de1810  vmovaps [rsp], xmm0
000071e7f4de1815  vmovaps [rsp+0x10], xmm1
000071e7f4de181b  vmovaps [rsp+0x20], xmm2
000071e7f4de1821  vmovaps [rsp+0x30], xmm3
000071e7f4de1827  vmovaps [rsp+0x40], xmm4
000071e7f4de182d  vmovaps [rsp+0x50], xmm5
000071e7f4de1833  vmovaps [rsp+0x60], xmm6
000071e7f4de1839  vmovaps [rsp+0x70], xmm7
000071e7f4de183f  vmovaps [rsp+0x80], xmm8
000071e7f4de1848  vmovaps [rsp+0x90], xmm9
000071e7f4de1851  vmovaps [rsp+0xA0], xmm10
000071e7f4de185a  vmovaps [rsp+0xB0], xmm11
000071e7f4de1863  vmovaps [rsp+0xC0], xmm12
000071e7f4de186c  vmovaps [rsp+0xD0], xmm13
000071e7f4de1875  vmovaps [rsp+0xE0], xmm15
000071e7f4de187e  sub rsp, 0x30
000071e7f4de1882  movaps [rsp], xmm14
000071e7f4de1887  movaps [rsp+0x10], xmm1
000071e7f4de188c  movaps [rsp+0x20], xmm7
000071e7f4de1891  lea rdi, [rsp]
000071e7f4de1895  mov esi, 0x00
000071e7f4de189a  mov rax, 0x562A51E82530
000071e7f4de18a4  call rax
000071e7f4de18a6  movaps xmm14, [rsp]
000071e7f4de18ab  add rsp, 0x30
000071e7f4de18af  vmovaps xmm0, [rsp]
000071e7f4de18b4  vmovaps xmm1, [rsp+0x10]
000071e7f4de18ba  vmovaps xmm2, [rsp+0x20]
000071e7f4de18c0  vmovaps xmm3, [rsp+0x30]
000071e7f4de18c6  vmovaps xmm4, [rsp+0x40]
000071e7f4de18cc  vmovaps xmm5, [rsp+0x50]
000071e7f4de18d2  vmovaps xmm6, [rsp+0x60]
000071e7f4de18d8  vmovaps xmm7, [rsp+0x70]
000071e7f4de18de  vmovaps xmm8, [rsp+0x80]
000071e7f4de18e7  vmovaps xmm9, [rsp+0x90]
000071e7f4de18f0  vmovaps xmm10, [rsp+0xA0]
000071e7f4de18f9  vmovaps xmm11, [rsp+0xB0]
000071e7f4de1902  vmovaps xmm12, [rsp+0xC0]
000071e7f4de190b  vmovaps xmm13, [rsp+0xD0]
000071e7f4de1914  vmovaps xmm15, [rsp+0xE0]
000071e7f4de191d  add rsp, 0xF0
000071e7f4de1924  pop r11
000071e7f4de1926  pop r10
000071e7f4de1928  pop r9
000071e7f4de192a  pop r8
000071e7f4de192c  pop rsi
000071e7f4de192d  pop rdi
000071e7f4de192e  pop rdx
000071e7f4de192f  pop rcx
000071e7f4de1930  pop rax
000071e7f4de1931  add rsp, 0x08
000071e7f4de1935  jmp 0x000071E7F4DDC843
000071e7f4de193a  sub rsp, 0x08
000071e7f4de193e  push rax
000071e7f4de193f  push rcx
000071e7f4de1940  push rdx
000071e7f4de1941  push rdi
000071e7f4de1942  push rsi
000071e7f4de1943  push r8
000071e7f4de1945  push r9
000071e7f4de1947  push r10
000071e7f4de1949  push r11
000071e7f4de194b  sub rsp, 0xF0
000071e7f4de1952  vmovaps [rsp], xmm0
000071e7f4de1957  vmovaps [rsp+0x10], xmm2
000071e7f4de195d  vmovaps [rsp+0x20], xmm3
000071e7f4de1963  vmovaps [rsp+0x30], xmm4
000071e7f4de1969  vmovaps [rsp+0x40], xmm5
000071e7f4de196f  vmovaps [rsp+0x50], xmm6
000071e7f4de1975  vmovaps [rsp+0x60], xmm7
000071e7f4de197b  vmovaps [rsp+0x70], xmm8
000071e7f4de1981  vmovaps [rsp+0x80], xmm9
000071e7f4de198a  vmovaps [rsp+0x90], xmm10
000071e7f4de1993  vmovaps [rsp+0xA0], xmm11
000071e7f4de199c  vmovaps [rsp+0xB0], xmm12
000071e7f4de19a5  vmovaps [rsp+0xC0], xmm13
000071e7f4de19ae  vmovaps [rsp+0xD0], xmm14
000071e7f4de19b7  vmovaps [rsp+0xE0], xmm15
000071e7f4de19c0  sub rsp, 0x30
000071e7f4de19c4  movaps [rsp], xmm1
000071e7f4de19c8  movaps [rsp+0x10], xmm8
000071e7f4de19ce  movaps [rsp+0x20], xmm9
000071e7f4de19d4  lea rdi, [rsp]
000071e7f4de19d8  mov esi, 0x00
000071e7f4de19dd  mov rax, 0x562A51E82530
000071e7f4de19e7  call rax
000071e7f4de19e9  movaps xmm1, [rsp]
000071e7f4de19ed  add rsp, 0x30
000071e7f4de19f1  vmovaps xmm0, [rsp]
000071e7f4de19f6  vmovaps xmm2, [rsp+0x10]
000071e7f4de19fc  vmovaps xmm3, [rsp+0x20]
000071e7f4de1a02  vmovaps xmm4, [rsp+0x30]
000071e7f4de1a08  vmovaps xmm5, [rsp+0x40]
000071e7f4de1a0e  vmovaps xmm6, [rsp+0x50]
000071e7f4de1a14  vmovaps xmm7, [rsp+0x60]
000071e7f4de1a1a  vmovaps xmm8, [rsp+0x70]
000071e7f4de1a20  vmovaps xmm9, [rsp+0x80]
000071e7f4de1a29  vmovaps xmm10, [rsp+0x90]
000071e7f4de1a32  vmovaps xmm11, [rsp+0xA0]
000071e7f4de1a3b  vmovaps xmm12, [rsp+0xB0]
000071e7f4de1a44  vmovaps xmm13, [rsp+0xC0]
000071e7f4de1a4d  vmovaps xmm14, [rsp+0xD0]
000071e7f4de1a56  vmovaps xmm15, [rsp+0xE0]
000071e7f4de1a5f  add rsp, 0xF0
000071e7f4de1a66  pop r11
000071e7f4de1a68  pop r10
000071e7f4de1a6a  pop r9
000071e7f4de1a6c  pop r8
000071e7f4de1a6e  pop rsi
000071e7f4de1a6f  pop rdi
000071e7f4de1a70  pop rdx
000071e7f4de1a71  pop rcx
000071e7f4de1a72  pop rax
000071e7f4de1a73  add rsp, 0x08
000071e7f4de1a77  jmp 0x000071E7F4DDC865
000071e7f4de1a7c  call 0x000071E7F4CE5940
000071e7f4de1a81  jmp 0x000071E7F4DDC873
000071e7f4de1a86  call 0x000071E7F4C0C380
000071e7f4de1a8b  jmp 0x000071E7F4DDC87D
000071e7f4de1a90  call 0x000071E7F4C0D600
000071e7f4de1a95  jmp 0x000071E7F4DDC887
000071e7f4de1a9a  call 0x000071E7F4BFF540
000071e7f4de1a9f  jmp 0x000071E7F4DDC891
000071e7f4de1aa4  int3
000071e7f4de1aa5  nop [rax+rax*1], ax
000071e7f4de1aae  nop
000071e7f4de1ab0  mov rax, [r15+0xF8]
000071e7f4de1ab7  lea r14, [rax+0x140]
000071e7f4de1abe  mov r12, [r13+r14*1]
000071e7f4de1ac3  mov [r15+0xE8], r12
000071e7f4de1aca  lea r14, [rax+0x130]
000071e7f4de1ad1  mov r12, [r13+r14*1]
000071e7f4de1ad6  lea r14, [rax+0x138]
000071e7f4de1add  mov r11, [r13+r14*1]
000071e7f4de1ae2  movq xmm1, r12
000071e7f4de1ae7  movq xmm15, r11
000071e7f4de1aec  movq xmm1, xmm1
000071e7f4de1af0  movq xmm1, xmm1
000071e7f4de1af4  movaps [r15+0x1A0], xmm1
000071e7f4de1afc  movq xmm15, xmm15
000071e7f4de1b01  movq xmm15, xmm15
000071e7f4de1b06  movaps [r15+0x190], xmm15
000071e7f4de1b0e  lea r14, [rax+0x120]
000071e7f4de1b15  mov r12, [r13+r14*1]
000071e7f4de1b1a  lea r14, [rax+0x128]
000071e7f4de1b21  mov r11, [r13+r14*1]
000071e7f4de1b26  movq xmm1, r12
000071e7f4de1b2b  movq xmm15, r11
000071e7f4de1b30  movq xmm1, xmm1
000071e7f4de1b34  movq xmm1, xmm1
000071e7f4de1b38  movaps [r15+0x1C0], xmm1
000071e7f4de1b40  movq xmm15, xmm15
000071e7f4de1b45  movq xmm15, xmm15
000071e7f4de1b4a  movaps [r15+0x1B0], xmm15
000071e7f4de1b52  lea r14, [rax+0x110]
000071e7f4de1b59  mov r12, [r13+r14*1]
000071e7f4de1b5e  lea r14, [rax+0x118]
000071e7f4de1b65  mov r11, [r13+r14*1]
000071e7f4de1b6a  movq xmm1, r12
000071e7f4de1b6f  movq xmm15, r11
000071e7f4de1b74  movq xmm1, xmm1
000071e7f4de1b78  movq xmm1, xmm1
000071e7f4de1b7c  movaps [r15+0x1E0], xmm1
000071e7f4de1b84  movq xmm15, xmm15
000071e7f4de1b89  movq xmm15, xmm15
000071e7f4de1b8e  movaps [r15+0x1D0], xmm15
000071e7f4de1b96  lea r14, [rax+0x100]
000071e7f4de1b9d  mov r12, [r13+r14*1]
000071e7f4de1ba2  lea r14, [rax+0x108]
000071e7f4de1ba9  mov r11, [r13+r14*1]
000071e7f4de1bae  movq xmm1, r12
000071e7f4de1bb3  movq xmm15, r11
000071e7f4de1bb8  movq xmm1, xmm1
000071e7f4de1bbc  movq xmm1, xmm1
000071e7f4de1bc0  movaps [r15+0x200], xmm1
000071e7f4de1bc8  movq xmm15, xmm15
000071e7f4de1bcd  movq xmm15, xmm15
000071e7f4de1bd2  movaps [r15+0x1F0], xmm15
000071e7f4de1bda  mov qword ptr [r15+0x40], 0x430000
000071e7f4de1be2  mov r14d, 0x430510
000071e7f4de1be8  mov r12, [r13+r14*1]
000071e7f4de1bed  movq xmm1, r12
000071e7f4de1bf2  lea r14, [rax+0x150]
000071e7f4de1bf9  mov [r15+0xF8], r14
000071e7f4de1c00  mov rax, [r15+0x50]
000071e7f4de1c04  movups xmm15, [r13+rax*1]
000071e7f4de1c0a  movaps [r15+0x120], xmm15
000071e7f4de1c12  mov qword ptr [r15+0x48], 0x10
000071e7f4de1c1a  xor eax, eax
000071e7f4de1c1c  mov r14d, 0x10
000071e7f4de1c22  mov r12d, 0x200
000071e7f4de1c28  cmp r14, r12
000071e7f4de1c2b  cmc
000071e7f4de1c2c  lahf
000071e7f4de1c2d  seto al
000071e7f4de1c30  mov [r15+0x108], eax
000071e7f4de1c37  pextrq rax, xmm15, 0x01
000071e7f4de1c3e  movq xmm14, rax
000071e7f4de1c43  movaps [r15+0x130], xmm14
000071e7f4de1c4b  movq rax, xmm1
000071e7f4de1c50  movq r14, xmm15
000071e7f4de1c55  vmovq xmm1, rax
000071e7f4de1c5a  vmovq xmm15, r14
000071e7f4de1c5f  movaps xmm13, xmm1
000071e7f4de1c63  addsd xmm13, xmm15
000071e7f4de1c68  ucomisd xmm13, xmm13
000071e7f4de1c6d  jp 0x000071E7F4DE1D86
000071e7f4de1c73  movq xmm13, xmm13
000071e7f4de1c78  movq rax, xmm13
000071e7f4de1c7d  movq r14, xmm14
000071e7f4de1c82  vmovq xmm1, rax
000071e7f4de1c87  vmovq xmm15, r14
000071e7f4de1c8c  movaps xmm14, xmm1
000071e7f4de1c90  addsd xmm14, xmm15
000071e7f4de1c95  ucomisd xmm14, xmm14
000071e7f4de1c9a  jp 0x000071E7F4DE1DCE
000071e7f4de1ca0  movq xmm14, xmm14
000071e7f4de1ca5  movaps [r15+0x110], xmm14
000071e7f4de1cad  mov eax, [r15+0x108]
000071e7f4de1cb4  sahf
000071e7f4de1cb5  jnz 0x000071E7F4DE1CE7
000071e7f4de1cb7  cmp dword ptr [r15+0x318], 0x00
000071e7f4de1cbf  jz 0x000071E7F4DE1FE0
000071e7f4de1cc5  nop [rax+rax*1], ax
000071e7f4de1cce  nop [rax+rax*1], eax
000071e7f4de1cd6  mov eax, 0x410490
000071e7f4de1cdb  mov [r15+0x100], rax
000071e7f4de1ce2  jmp 0x000071E7F4BFE110
000071e7f4de1ce7  cmp dword ptr [r15+0x318], 0x00
000071e7f4de1cef  jz 0x000071E7F4DE1E20
000071e7f4de1cf5  nop [rax+rax*1], ax
000071e7f4de1cfe  nop [rax+rax*1], eax
000071e7f4de1d06  mov eax, 0x410474
000071e7f4de1d0b  mov [r15+0x100], rax
000071e7f4de1d12  jmp 0x000071E7F4BFE110
000071e7f4de1d17  int3
000071e7f4de1d18  call 0x000071E7F4CE27E0
000071e7f4de1d1d  jmp 0x000071E7F4DE1AC3
000071e7f4de1d22  call 0x000071E7F4CE27E0
000071e7f4de1d27  jmp 0x000071E7F4DE1AD6
000071e7f4de1d2c  call 0x000071E7F4CE1570
000071e7f4de1d31  jmp 0x000071E7F4DE1AE2
000071e7f4de1d36  call 0x000071E7F4CE27E0
000071e7f4de1d3b  jmp 0x000071E7F4DE1B1A
000071e7f4de1d40  call 0x000071E7F4CE1570
000071e7f4de1d45  jmp 0x000071E7F4DE1B26
000071e7f4de1d4a  call 0x000071E7F4CE27E0
000071e7f4de1d4f  jmp 0x000071E7F4DE1B5E
000071e7f4de1d54  call 0x000071E7F4CE1570
000071e7f4de1d59  jmp 0x000071E7F4DE1B6A
000071e7f4de1d5e  call 0x000071E7F4CE27E0
000071e7f4de1d63  jmp 0x000071E7F4DE1BA2
000071e7f4de1d68  call 0x000071E7F4CE1570
000071e7f4de1d6d  jmp 0x000071E7F4DE1BAE
000071e7f4de1d72  call 0x000071E7F4CE27E0
000071e7f4de1d77  jmp 0x000071E7F4DE1BED
000071e7f4de1d7c  call 0x000071E7F4C0E760
000071e7f4de1d81  jmp 0x000071E7F4DE1C0A
000071e7f4de1d86  ucomisd xmm1, xmm15
000071e7f4de1d8b  jp 0x000071E7F4DE1D9A
000071e7f4de1d8d  movaps xmm13, [0x000071E7F49FE060]
000071e7f4de1d95  jmp 0x000071E7F4DE1C73
000071e7f4de1d9a  vxorps xmm0, xmm1, xmm15
000071e7f4de1d9f  pextrw eax, xmm0, 0x03
000071e7f4de1da4  and eax, 0x7FF8
000071e7f4de1da9  cmp eax, 0x08
000071e7f4de1dac  jnz 0x000071E7F4DE1C73
000071e7f4de1db2  movq rax, xmm15
000071e7f4de1db7  shl rax, 0x0D
000071e7f4de1dbb  jbe 0x000071E7F4DE1C73
000071e7f4de1dc1  vorps xmm13, xmm15, [0x000071E7F49FE070]
000071e7f4de1dc9  jmp 0x000071E7F4DE1C73
000071e7f4de1dce  ucomisd xmm1, xmm15
000071e7f4de1dd3  jp 0x000071E7F4DE1DE2
000071e7f4de1dd5  movaps xmm14, [0x000071E7F49FE060]
000071e7f4de1ddd  jmp 0x000071E7F4DE1CA0
000071e7f4de1de2  vxorps xmm0, xmm1, xmm15
000071e7f4de1de7  pextrw eax, xmm0, 0x03
000071e7f4de1dec  and eax, 0x7FF8
000071e7f4de1df1  cmp eax, 0x08
000071e7f4de1df4  jnz 0x000071E7F4DE1CA0
000071e7f4de1dfa  movq rax, xmm15
000071e7f4de1dff  shl rax, 0x0D
000071e7f4de1e03  jbe 0x000071E7F4DE1CA0
000071e7f4de1e09  vorps xmm14, xmm15, [0x000071E7F49FE070]
000071e7f4de1e11  jmp 0x000071E7F4DE1CA0
000071e7f4de1e16  int3
000071e7f4de1e17  nop [rax+rax*1], ax
000071e7f4de1e20  mov rax, [r15+0x48]
000071e7f4de1e24  mov r14, [r15+0x50]
000071e7f4de1e28  lea r12, [r14+rax*1]
000071e7f4de1e2c  movups xmm1, [r13+r12*1]
000071e7f4de1e32  movaps [r15+0x120], xmm1
000071e7f4de1e3a  lea r14, [rax+0x10]
000071e7f4de1e3e  mov [r15+0x48], r14
000071e7f4de1e42  xor eax, eax
000071e7f4de1e44  mov r12d, 0x200
000071e7f4de1e4a  cmp r14, r12
000071e7f4de1e4d  cmc
000071e7f4de1e4e  lahf
000071e7f4de1e4f  seto al
000071e7f4de1e52  mov [r15+0x108], eax
000071e7f4de1e59  pextrq rax, xmm1, 0x01
000071e7f4de1e60  movq xmm15, rax
000071e7f4de1e65  movaps [r15+0x130], xmm15
000071e7f4de1e6d  movaps xmm14, [r15+0x110]
000071e7f4de1e75  movq rax, xmm14
000071e7f4de1e7a  movq r14, xmm1
000071e7f4de1e7f  vmovq xmm1, rax
000071e7f4de1e84  vmovq xmm14, r14
000071e7f4de1e89  movaps xmm13, xmm1
000071e7f4de1e8d  addsd xmm13, xmm14
000071e7f4de1e92  ucomisd xmm13, xmm13
000071e7f4de1e97  jp 0x000071E7F4DE1F4C
000071e7f4de1e9d  movq xmm13, xmm13
000071e7f4de1ea2  movq rax, xmm13
000071e7f4de1ea7  movq r14, xmm15
000071e7f4de1eac  vmovq xmm1, rax
000071e7f4de1eb1  vmovq xmm15, r14
000071e7f4de1eb6  movaps xmm14, xmm1
000071e7f4de1eba  addsd xmm14, xmm15
000071e7f4de1ebf  ucomisd xmm14, xmm14
000071e7f4de1ec4  jp 0x000071E7F4DE1F94
000071e7f4de1eca  movq xmm14, xmm14
000071e7f4de1ecf  movaps [r15+0x110], xmm14
000071e7f4de1ed7  mov eax, [r15+0x108]
000071e7f4de1ede  sahf
000071e7f4de1edf  jnz 0x000071E7F4DE1F11
000071e7f4de1ee1  cmp dword ptr [r15+0x318], 0x00
000071e7f4de1ee9  jz 0x000071E7F4DE1FE0
000071e7f4de1eef  nop [rax+rax*1], ax
000071e7f4de1ef8  nop [rax+rax*1], eax
000071e7f4de1f00  mov eax, 0x410490
000071e7f4de1f05  mov [r15+0x100], rax
000071e7f4de1f0c  jmp 0x000071E7F4BFE110
000071e7f4de1f11  cmp dword ptr [r15+0x318], 0x00
000071e7f4de1f19  jz 0x000071E7F4DE1E20
000071e7f4de1f1f  nop [rax+rax*1], ax
000071e7f4de1f28  nop [rax+rax*1], eax
000071e7f4de1f30  mov eax, 0x410474
000071e7f4de1f35  mov [r15+0x100], rax
000071e7f4de1f3c  jmp 0x000071E7F4BFE110
000071e7f4de1f41  int3
000071e7f4de1f42  call 0x000071E7F4CB52F0
000071e7f4de1f47  jmp 0x000071E7F4DE1E32
000071e7f4de1f4c  ucomisd xmm1, xmm14
000071e7f4de1f51  jp 0x000071E7F4DE1F60
000071e7f4de1f53  movaps xmm13, [0x000071E7F49FE060]
000071e7f4de1f5b  jmp 0x000071E7F4DE1E9D
000071e7f4de1f60  vxorps xmm0, xmm1, xmm14
000071e7f4de1f65  pextrw eax, xmm0, 0x03
000071e7f4de1f6a  and eax, 0x7FF8
000071e7f4de1f6f  cmp eax, 0x08
000071e7f4de1f72  jnz 0x000071E7F4DE1E9D
000071e7f4de1f78  movq rax, xmm14
000071e7f4de1f7d  shl rax, 0x0D
000071e7f4de1f81  jbe 0x000071E7F4DE1E9D
000071e7f4de1f87  vorps xmm13, xmm14, [0x000071E7F49FE070]
000071e7f4de1f8f  jmp 0x000071E7F4DE1E9D
000071e7f4de1f94  ucomisd xmm1, xmm15
000071e7f4de1f99  jp 0x000071E7F4DE1FA8
000071e7f4de1f9b  movaps xmm14, [0x000071E7F49FE060]
000071e7f4de1fa3  jmp 0x000071E7F4DE1ECA
000071e7f4de1fa8  vxorps xmm0, xmm1, xmm15
000071e7f4de1fad  pextrw eax, xmm0, 0x03
000071e7f4de1fb2  and eax, 0x7FF8
000071e7f4de1fb7  cmp eax, 0x08
000071e7f4de1fba  jnz 0x000071E7F4DE1ECA
000071e7f4de1fc0  movq rax, xmm15
000071e7f4de1fc5  shl rax, 0x0D
000071e7f4de1fc9  jbe 0x000071E7F4DE1ECA
000071e7f4de1fcf  vorps xmm14, xmm15, [0x000071E7F49FE070]
000071e7f4de1fd7  jmp 0x000071E7F4DE1ECA
000071e7f4de1fdc  int3
000071e7f4de1fdd  nop [rax], eax
000071e7f4de1fe0  mov rax, [r15+0x40]
000071e7f4de1fe4  lea r14, [rax+0x510]
000071e7f4de1feb  movaps xmm1, [r15+0x110]
000071e7f4de1ff3  movq rax, xmm1
000071e7f4de1ff8  mov [r13+r14*1], rax
000071e7f4de1ffd  mov rax, [r15+0xF0]
000071e7f4de2004  mov [r15+0x100], rax
000071e7f4de200b  jmp 0x000071E7F4DCE5C0
000071e7f4de2010  int3
000071e7f4de2011  call 0x000071E7F4CD5EB0
000071e7f4de2016  jmp 0x000071E7F4DE1FFD
000071e7f4de201b  int3
000071e7f4de201c  nop [rax], eax
000071e7f4de2020  mov qword ptr [r15+0x100], 0x04
000071e7f4de202b  mov esi, 0x00
000071e7f4de2030  mov edx, 0x09
000071e7f4de2035  mov rdi, 0x7FFF168D2A30
000071e7f4de203f  mov rax, 0x562A51D15970
000071e7f4de2049  call rax
000071e7f4de204b  cmp dword ptr [r15+0x318], 0x00
000071e7f4de2053  jnz 0x000071E7F4BFE110
000071e7f4de2059  jmp 0x000071E7F4BFE0A0
000071e7f4de205e  int3
000071e7f4de205f  int3
