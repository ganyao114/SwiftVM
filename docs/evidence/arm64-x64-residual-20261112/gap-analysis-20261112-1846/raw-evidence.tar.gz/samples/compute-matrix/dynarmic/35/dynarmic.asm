00007154327ce69b  nop [rax+rax*1], eax
00007154327ce6a0  vmovaps xmm1, [0x00007154323FE010]
00007154327ce6a8  movq xmm1, xmm1
00007154327ce6ac  movaps [r15+0x110], xmm1
00007154327ce6b4  vmovaps xmm1, [0x00007154323FE020]
00007154327ce6bc  movq xmm1, xmm1
00007154327ce6c0  movaps [r15+0x120], xmm1
00007154327ce6c8  mov eax, 0x4204C0
00007154327ce6cd  mov r14, [r13+rax*1]
00007154327ce6d2  movq xmm1, r14
00007154327ce6d7  movaps [r15+0x130], xmm1
00007154327ce6df  vmovaps xmm1, [0x00007154323FE030]
00007154327ce6e7  vpbroadcastq xmm1, xmm1
00007154327ce6ec  movaps [r15+0x140], xmm1
00007154327ce6f4  mov qword ptr [r15+0x40], 0x02
00007154327ce6fc  vmovaps xmm15, [0x00007154323FE040]
00007154327ce704  movq xmm15, xmm15
00007154327ce709  movaps [r15+0x150], xmm15
00007154327ce711  mov qword ptr [r15+0x58], 0x420000
00007154327ce719  vmovaps xmm15, [0x00007154323FE050]
00007154327ce721  vpbroadcastq xmm15, xmm15
00007154327ce726  movaps [r15+0x160], xmm15
00007154327ce72e  mov rax, [r15+0x40]
00007154327ce732  vmovq xmm14, rax
00007154327ce737  vpbroadcastq xmm14, xmm14
00007154327ce73c  movaps [r15+0x170], xmm14
00007154327ce744  mov eax, 0x4204D0
00007154327ce749  movups xmm13, [r13+rax*1]
00007154327ce74f  mov qword ptr [r15+0x40], 0x430518
00007154327ce757  mov qword ptr [r15+0x50], 0x430720
00007154327ce75f  vpmovqd xmm12, xmm13
00007154327ce765  pxor xmm11, xmm11
00007154327ce76a  punpcklqdq xmm12, xmm11
00007154327ce76f  movaps [r15+0x210], xmm12
00007154327ce777  movq xmm12, qword ptr [r15+0x120]
00007154327ce780  movq xmm11, qword ptr [r15+0x130]
00007154327ce789  psubd xmm12, xmm11
00007154327ce78e  movq xmm12, xmm12
00007154327ce793  paddq xmm13, xmm14
00007154327ce798  movaps [r15+0x180], xmm13
00007154327ce7a0  movq xmm14, qword ptr [r15+0x150]
00007154327ce7a9  paddd xmm11, xmm14
00007154327ce7ae  movq xmm11, xmm11
00007154327ce7b3  movq xmm11, xmm11
00007154327ce7b8  movaps [r15+0x130], xmm11
00007154327ce7c0  pmovzxdq xmm12, xmm12
00007154327ce7c6  psllq xmm12, 0x00
00007154327ce7cc  movq xmm14, qword ptr [r15+0x210]
00007154327ce7d5  movq xmm13, qword ptr [r15+0x110]
00007154327ce7de  paddd xmm14, xmm13
00007154327ce7e3  movq xmm14, xmm14
00007154327ce7e8  vcvtuqq2pd xmm12, xmm12
00007154327ce7ee  pmovzxdq xmm14, xmm14
00007154327ce7f4  psllq xmm14, 0x00
00007154327ce7fa  vcvtuqq2pd xmm14, xmm14
00007154327ce800  movaps xmm13, xmm12
00007154327ce804  mulpd xmm13, xmm1
00007154327ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007154327ce80f  ptest xmm11, xmm11
00007154327ce815  jnz 0x00007154327CE8FF
00007154327ce81b  movaps [r15+0x220], xmm13
00007154327ce823  mov eax, 0x430720
00007154327ce828  movups [r13+rax*1], xmm13
00007154327ce82e  movaps xmm1, xmm14
00007154327ce832  mulpd xmm1, xmm15
00007154327ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007154327ce83c  ptest xmm13, xmm13
00007154327ce842  jnz 0x00007154327CEA4C
00007154327ce848  movaps [r15+0x210], xmm1
00007154327ce850  mov eax, 0x430518
00007154327ce855  movups [r13+rax*1], xmm1
00007154327ce85b  mov qword ptr [r15+0x48], 0x10
00007154327ce863  xor eax, eax
00007154327ce865  mov r14d, 0x10
00007154327ce86b  mov r12d, 0x200
00007154327ce871  cmp r14, r12
00007154327ce874  cmc
00007154327ce875  lahf
00007154327ce876  seto al
00007154327ce879  mov [r15+0x108], eax
00007154327ce880  mov eax, [r15+0x108]
00007154327ce887  sahf
00007154327ce888  jnz 0x00007154327CE8BA
00007154327ce88a  cmp dword ptr [r15+0x318], 0x00
00007154327ce892  jz 0x00007154327CEFF0
00007154327ce898  nop [rax+rax*1], ax
00007154327ce8a1  nop [rax+rax*1], eax
00007154327ce8a9  mov eax, 0x4101EC
00007154327ce8ae  mov [r15+0x100], rax
00007154327ce8b5  jmp 0x00007154325FE110
00007154327ce8ba  cmp dword ptr [r15+0x318], 0x00
00007154327ce8c2  jz 0x00007154327CEBA0
00007154327ce8c8  nop [rax+rax*1], ax
00007154327ce8d1  nop [rax+rax*1], eax
00007154327ce8d9  mov eax, 0x4101AC
00007154327ce8de  mov [r15+0x100], rax
00007154327ce8e5  jmp 0x00007154325FE110
00007154327ce8ea  int3
00007154327ce8eb  call 0x000071543260DC20
00007154327ce8f0  jmp 0x00007154327CE6D2
00007154327ce8f5  call 0x000071543260C260
00007154327ce8fa  jmp 0x00007154327CE74F
00007154327ce8ff  sub rsp, 0x08
00007154327ce903  push rax
00007154327ce904  push rcx
00007154327ce905  push rdx
00007154327ce906  push rdi
00007154327ce907  push rsi
00007154327ce908  push r8
00007154327ce90a  push r9
00007154327ce90c  push r10
00007154327ce90e  push r11
00007154327ce910  sub rsp, 0xF0
00007154327ce917  vmovaps [rsp], xmm0
00007154327ce91c  vmovaps [rsp+0x10], xmm1
00007154327ce922  vmovaps [rsp+0x20], xmm2
00007154327ce928  vmovaps [rsp+0x30], xmm3
00007154327ce92e  vmovaps [rsp+0x40], xmm4
00007154327ce934  vmovaps [rsp+0x50], xmm5
00007154327ce93a  vmovaps [rsp+0x60], xmm6
00007154327ce940  vmovaps [rsp+0x70], xmm7
00007154327ce946  vmovaps [rsp+0x80], xmm8
00007154327ce94f  vmovaps [rsp+0x90], xmm9
00007154327ce958  vmovaps [rsp+0xA0], xmm10
00007154327ce961  vmovaps [rsp+0xB0], xmm11
00007154327ce96a  vmovaps [rsp+0xC0], xmm12
00007154327ce973  vmovaps [rsp+0xD0], xmm14
00007154327ce97c  vmovaps [rsp+0xE0], xmm15
00007154327ce985  sub rsp, 0x30
00007154327ce989  movaps [rsp], xmm13
00007154327ce98e  movaps [rsp+0x10], xmm12
00007154327ce994  movaps [rsp+0x20], xmm1
00007154327ce999  lea rdi, [rsp]
00007154327ce99d  mov esi, 0x00
00007154327ce9a2  mov rax, 0x5A63B06A5530
00007154327ce9ac  call rax
00007154327ce9ae  movaps xmm13, [rsp]
00007154327ce9b3  add rsp, 0x30
00007154327ce9b7  vmovaps xmm0, [rsp]
00007154327ce9bc  vmovaps xmm1, [rsp+0x10]
00007154327ce9c2  vmovaps xmm2, [rsp+0x20]
00007154327ce9c8  vmovaps xmm3, [rsp+0x30]
00007154327ce9ce  vmovaps xmm4, [rsp+0x40]
00007154327ce9d4  vmovaps xmm5, [rsp+0x50]
00007154327ce9da  vmovaps xmm6, [rsp+0x60]
00007154327ce9e0  vmovaps xmm7, [rsp+0x70]
00007154327ce9e6  vmovaps xmm8, [rsp+0x80]
00007154327ce9ef  vmovaps xmm9, [rsp+0x90]
00007154327ce9f8  vmovaps xmm10, [rsp+0xA0]
00007154327cea01  vmovaps xmm11, [rsp+0xB0]
00007154327cea0a  vmovaps xmm12, [rsp+0xC0]
00007154327cea13  vmovaps xmm14, [rsp+0xD0]
00007154327cea1c  vmovaps xmm15, [rsp+0xE0]
00007154327cea25  add rsp, 0xF0
00007154327cea2c  pop r11
00007154327cea2e  pop r10
00007154327cea30  pop r9
00007154327cea32  pop r8
00007154327cea34  pop rsi
00007154327cea35  pop rdi
00007154327cea36  pop rdx
00007154327cea37  pop rcx
00007154327cea38  pop rax
00007154327cea39  add rsp, 0x08
00007154327cea3d  jmp 0x00007154327CE81B
00007154327cea42  call 0x000071543260C380
00007154327cea47  jmp 0x00007154327CE82E
00007154327cea4c  sub rsp, 0x08
00007154327cea50  push rax
00007154327cea51  push rcx
00007154327cea52  push rdx
00007154327cea53  push rdi
00007154327cea54  push rsi
00007154327cea55  push r8
00007154327cea57  push r9
00007154327cea59  push r10
00007154327cea5b  push r11
00007154327cea5d  sub rsp, 0xF0
00007154327cea64  vmovaps [rsp], xmm0
00007154327cea69  vmovaps [rsp+0x10], xmm2
00007154327cea6f  vmovaps [rsp+0x20], xmm3
00007154327cea75  vmovaps [rsp+0x30], xmm4
00007154327cea7b  vmovaps [rsp+0x40], xmm5
00007154327cea81  vmovaps [rsp+0x50], xmm6
00007154327cea87  vmovaps [rsp+0x60], xmm7
00007154327cea8d  vmovaps [rsp+0x70], xmm8
00007154327cea93  vmovaps [rsp+0x80], xmm9
00007154327cea9c  vmovaps [rsp+0x90], xmm10
00007154327ceaa5  vmovaps [rsp+0xA0], xmm11
00007154327ceaae  vmovaps [rsp+0xB0], xmm12
00007154327ceab7  vmovaps [rsp+0xC0], xmm13
00007154327ceac0  vmovaps [rsp+0xD0], xmm14
00007154327ceac9  vmovaps [rsp+0xE0], xmm15
00007154327cead2  sub rsp, 0x30
00007154327cead6  movaps [rsp], xmm1
00007154327ceada  movaps [rsp+0x10], xmm14
00007154327ceae0  movaps [rsp+0x20], xmm15
00007154327ceae6  lea rdi, [rsp]
00007154327ceaea  mov esi, 0x00
00007154327ceaef  mov rax, 0x5A63B06A5530
00007154327ceaf9  call rax
00007154327ceafb  movaps xmm1, [rsp]
00007154327ceaff  add rsp, 0x30
00007154327ceb03  vmovaps xmm0, [rsp]
00007154327ceb08  vmovaps xmm2, [rsp+0x10]
00007154327ceb0e  vmovaps xmm3, [rsp+0x20]
00007154327ceb14  vmovaps xmm4, [rsp+0x30]
00007154327ceb1a  vmovaps xmm5, [rsp+0x40]
00007154327ceb20  vmovaps xmm6, [rsp+0x50]
00007154327ceb26  vmovaps xmm7, [rsp+0x60]
00007154327ceb2c  vmovaps xmm8, [rsp+0x70]
00007154327ceb32  vmovaps xmm9, [rsp+0x80]
00007154327ceb3b  vmovaps xmm10, [rsp+0x90]
00007154327ceb44  vmovaps xmm11, [rsp+0xA0]
00007154327ceb4d  vmovaps xmm12, [rsp+0xB0]
00007154327ceb56  vmovaps xmm13, [rsp+0xC0]
00007154327ceb5f  vmovaps xmm14, [rsp+0xD0]
00007154327ceb68  vmovaps xmm15, [rsp+0xE0]
00007154327ceb71  add rsp, 0xF0
00007154327ceb78  pop r11
00007154327ceb7a  pop r10
00007154327ceb7c  pop r9
00007154327ceb7e  pop r8
00007154327ceb80  pop rsi
00007154327ceb81  pop rdi
00007154327ceb82  pop rdx
00007154327ceb83  pop rcx
00007154327ceb84  pop rax
00007154327ceb85  add rsp, 0x08
00007154327ceb89  jmp 0x00007154327CE848
00007154327ceb8e  call 0x00007154325FF540
00007154327ceb93  jmp 0x00007154327CE85B
00007154327ceb98  int3
00007154327ceb99  nop [rax], eax
00007154327ceba0  movaps xmm1, [r15+0x180]
00007154327ceba8  vpmovqd xmm15, xmm1
00007154327cebae  pxor xmm14, xmm14
00007154327cebb3  punpcklqdq xmm15, xmm14
00007154327cebb8  movaps [r15+0x210], xmm15
00007154327cebc0  movq xmm15, qword ptr [r15+0x120]
00007154327cebc9  movq xmm14, qword ptr [r15+0x130]
00007154327cebd2  psubd xmm15, xmm14
00007154327cebd7  movq xmm15, xmm15
00007154327cebdc  movaps xmm13, [r15+0x170]
00007154327cebe4  paddq xmm1, xmm13
00007154327cebe9  movaps [r15+0x180], xmm1
00007154327cebf1  movq xmm1, qword ptr [r15+0x150]
00007154327cebfa  paddd xmm14, xmm1
00007154327cebff  movq xmm14, xmm14
00007154327cec04  movq xmm14, xmm14
00007154327cec09  movaps [r15+0x130], xmm14
00007154327cec11  pmovzxdq xmm15, xmm15
00007154327cec17  psllq xmm15, 0x00
00007154327cec1d  movq xmm1, qword ptr [r15+0x210]
00007154327cec26  movq xmm14, qword ptr [r15+0x110]
00007154327cec2f  paddd xmm1, xmm14
00007154327cec34  movq xmm1, xmm1
00007154327cec38  vcvtuqq2pd xmm15, xmm15
00007154327cec3e  pmovzxdq xmm1, xmm1
00007154327cec43  psllq xmm1, 0x00
00007154327cec48  vcvtuqq2pd xmm1, xmm1
00007154327cec4e  movaps xmm14, [r15+0x140]
00007154327cec56  movaps xmm13, xmm15
00007154327cec5a  mulpd xmm13, xmm14
00007154327cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007154327cec65  ptest xmm12, xmm12
00007154327cec6b  jnz 0x00007154327CED4E
00007154327cec71  movaps [r15+0x220], xmm13
00007154327cec79  mov rax, [r15+0x48]
00007154327cec7d  mov r14, [r15+0x50]
00007154327cec81  lea r12, [r14+rax*1]
00007154327cec85  movups [r13+r12*1], xmm13
00007154327cec8b  movaps xmm15, [r15+0x160]
00007154327cec93  movaps xmm14, xmm1
00007154327cec97  mulpd xmm14, xmm15
00007154327cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007154327ceca2  ptest xmm13, xmm13
00007154327ceca8  jnz 0x00007154327CEE9C
00007154327cecae  movaps [r15+0x210], xmm14
00007154327cecb6  mov r14, [r15+0x40]
00007154327cecba  lea r12, [r14+rax*1]
00007154327cecbe  movups [r13+r12*1], xmm14
00007154327cecc4  lea r14, [rax+0x10]
00007154327cecc8  mov [r15+0x48], r14
00007154327ceccc  xor eax, eax
00007154327cecce  mov r12d, 0x200
00007154327cecd4  cmp r14, r12
00007154327cecd7  cmc
00007154327cecd8  lahf
00007154327cecd9  seto al
00007154327cecdc  mov [r15+0x108], eax
00007154327cece3  mov eax, [r15+0x108]
00007154327cecea  sahf
00007154327ceceb  jnz 0x00007154327CED1D
00007154327ceced  cmp dword ptr [r15+0x318], 0x00
00007154327cecf5  jz 0x00007154327CEFF0
00007154327cecfb  nop [rax+rax*1], ax
00007154327ced04  nop [rax+rax*1], eax
00007154327ced0c  mov eax, 0x4101EC
00007154327ced11  mov [r15+0x100], rax
00007154327ced18  jmp 0x00007154325FE110
00007154327ced1d  cmp dword ptr [r15+0x318], 0x00
00007154327ced25  jz 0x00007154327CEBA0
00007154327ced2b  nop [rax+rax*1], ax
00007154327ced34  nop [rax+rax*1], eax
00007154327ced3c  mov eax, 0x4101AC
00007154327ced41  mov [r15+0x100], rax
00007154327ced48  jmp 0x00007154325FE110
00007154327ced4d  int3
00007154327ced4e  sub rsp, 0x08
00007154327ced52  push rax
00007154327ced53  push rcx
00007154327ced54  push rdx
00007154327ced55  push rdi
00007154327ced56  push rsi
00007154327ced57  push r8
00007154327ced59  push r9
00007154327ced5b  push r10
00007154327ced5d  push r11
00007154327ced5f  sub rsp, 0xF0
00007154327ced66  vmovaps [rsp], xmm0
00007154327ced6b  vmovaps [rsp+0x10], xmm1
00007154327ced71  vmovaps [rsp+0x20], xmm2
00007154327ced77  vmovaps [rsp+0x30], xmm3
00007154327ced7d  vmovaps [rsp+0x40], xmm4
00007154327ced83  vmovaps [rsp+0x50], xmm5
00007154327ced89  vmovaps [rsp+0x60], xmm6
00007154327ced8f  vmovaps [rsp+0x70], xmm7
00007154327ced95  vmovaps [rsp+0x80], xmm8
00007154327ced9e  vmovaps [rsp+0x90], xmm9
00007154327ceda7  vmovaps [rsp+0xA0], xmm10
00007154327cedb0  vmovaps [rsp+0xB0], xmm11
00007154327cedb9  vmovaps [rsp+0xC0], xmm12
00007154327cedc2  vmovaps [rsp+0xD0], xmm14
00007154327cedcb  vmovaps [rsp+0xE0], xmm15
00007154327cedd4  sub rsp, 0x30
00007154327cedd8  movaps [rsp], xmm13
00007154327ceddd  movaps [rsp+0x10], xmm15
00007154327cede3  movaps [rsp+0x20], xmm14
00007154327cede9  lea rdi, [rsp]
00007154327ceded  mov esi, 0x00
00007154327cedf2  mov rax, 0x5A63B06A5530
00007154327cedfc  call rax
00007154327cedfe  movaps xmm13, [rsp]
00007154327cee03  add rsp, 0x30
00007154327cee07  vmovaps xmm0, [rsp]
00007154327cee0c  vmovaps xmm1, [rsp+0x10]
00007154327cee12  vmovaps xmm2, [rsp+0x20]
00007154327cee18  vmovaps xmm3, [rsp+0x30]
00007154327cee1e  vmovaps xmm4, [rsp+0x40]
00007154327cee24  vmovaps xmm5, [rsp+0x50]
00007154327cee2a  vmovaps xmm6, [rsp+0x60]
00007154327cee30  vmovaps xmm7, [rsp+0x70]
00007154327cee36  vmovaps xmm8, [rsp+0x80]
00007154327cee3f  vmovaps xmm9, [rsp+0x90]
00007154327cee48  vmovaps xmm10, [rsp+0xA0]
00007154327cee51  vmovaps xmm11, [rsp+0xB0]
00007154327cee5a  vmovaps xmm12, [rsp+0xC0]
00007154327cee63  vmovaps xmm14, [rsp+0xD0]
00007154327cee6c  vmovaps xmm15, [rsp+0xE0]
00007154327cee75  add rsp, 0xF0
00007154327cee7c  pop r11
00007154327cee7e  pop r10
00007154327cee80  pop r9
00007154327cee82  pop r8
00007154327cee84  pop rsi
00007154327cee85  pop rdi
00007154327cee86  pop rdx
00007154327cee87  pop rcx
00007154327cee88  pop rax
00007154327cee89  add rsp, 0x08
00007154327cee8d  jmp 0x00007154327CEC71
00007154327cee92  call 0x00007154326C2240
00007154327cee97  jmp 0x00007154327CEC8B
00007154327cee9c  sub rsp, 0x08
00007154327ceea0  push rax
00007154327ceea1  push rcx
00007154327ceea2  push rdx
00007154327ceea3  push rdi
00007154327ceea4  push rsi
00007154327ceea5  push r8
00007154327ceea7  push r9
00007154327ceea9  push r10
00007154327ceeab  push r11
00007154327ceead  sub rsp, 0xF0
00007154327ceeb4  vmovaps [rsp], xmm0
00007154327ceeb9  vmovaps [rsp+0x10], xmm1
00007154327ceebf  vmovaps [rsp+0x20], xmm2
00007154327ceec5  vmovaps [rsp+0x30], xmm3
00007154327ceecb  vmovaps [rsp+0x40], xmm4
00007154327ceed1  vmovaps [rsp+0x50], xmm5
00007154327ceed7  vmovaps [rsp+0x60], xmm6
00007154327ceedd  vmovaps [rsp+0x70], xmm7
00007154327ceee3  vmovaps [rsp+0x80], xmm8
00007154327ceeec  vmovaps [rsp+0x90], xmm9
00007154327ceef5  vmovaps [rsp+0xA0], xmm10
00007154327ceefe  vmovaps [rsp+0xB0], xmm11
00007154327cef07  vmovaps [rsp+0xC0], xmm12
00007154327cef10  vmovaps [rsp+0xD0], xmm13
00007154327cef19  vmovaps [rsp+0xE0], xmm15
00007154327cef22  sub rsp, 0x30
00007154327cef26  movaps [rsp], xmm14
00007154327cef2b  movaps [rsp+0x10], xmm1
00007154327cef30  movaps [rsp+0x20], xmm15
00007154327cef36  lea rdi, [rsp]
00007154327cef3a  mov esi, 0x00
00007154327cef3f  mov rax, 0x5A63B06A5530
00007154327cef49  call rax
00007154327cef4b  movaps xmm14, [rsp]
00007154327cef50  add rsp, 0x30
00007154327cef54  vmovaps xmm0, [rsp]
00007154327cef59  vmovaps xmm1, [rsp+0x10]
00007154327cef5f  vmovaps xmm2, [rsp+0x20]
00007154327cef65  vmovaps xmm3, [rsp+0x30]
00007154327cef6b  vmovaps xmm4, [rsp+0x40]
00007154327cef71  vmovaps xmm5, [rsp+0x50]
00007154327cef77  vmovaps xmm6, [rsp+0x60]
00007154327cef7d  vmovaps xmm7, [rsp+0x70]
00007154327cef83  vmovaps xmm8, [rsp+0x80]
00007154327cef8c  vmovaps xmm9, [rsp+0x90]
00007154327cef95  vmovaps xmm10, [rsp+0xA0]
00007154327cef9e  vmovaps xmm11, [rsp+0xB0]
00007154327cefa7  vmovaps xmm12, [rsp+0xC0]
00007154327cefb0  vmovaps xmm13, [rsp+0xD0]
00007154327cefb9  vmovaps xmm15, [rsp+0xE0]
00007154327cefc2  add rsp, 0xF0
00007154327cefc9  pop r11
00007154327cefcb  pop r10
00007154327cefcd  pop r9
00007154327cefcf  pop r8
00007154327cefd1  pop rsi
00007154327cefd2  pop rdi
00007154327cefd3  pop rdx
00007154327cefd4  pop rcx
00007154327cefd5  pop rax
00007154327cefd6  add rsp, 0x08
00007154327cefda  jmp 0x00007154327CECAE
00007154327cefdf  call 0x00007154326C34C0
00007154327cefe4  jmp 0x00007154327CECC4
00007154327cefe9  int3
00007154327cefea  nop [rax+rax*1], ax
00007154327ceff0  mov rax, [r15+0xF8]
00007154327ceff7  lea r14, [rax-0x150]
00007154327ceffe  mov [r15+0xF8], r14
00007154327cf005  mov rax, [r15+0x50]
00007154327cf009  lea r12, [rax+0x80]
00007154327cf010  movups xmm1, [r13+r12*1]
00007154327cf016  lea r12, [rax+0x90]
00007154327cf01d  movups xmm15, [r13+r12*1]
00007154327cf023  mov qword ptr [r15+0x48], 0x00
00007154327cf02b  lea r12, [rax+0x40]
00007154327cf02f  movups xmm14, [r13+r12*1]
00007154327cf035  lea r12, [rax+0x50]
00007154327cf039  movups xmm13, [r13+r12*1]
00007154327cf03f  lea r12, [r14+0x120]
00007154327cf046  movq xmm12, qword ptr [r15+0x1C0]
00007154327cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007154327cf058  movq r11, xmm12
00007154327cf05d  movq r10, xmm11
00007154327cf062  mov [r13+r12*1], r11
00007154327cf067  lea r12, [r14+0x128]
00007154327cf06e  mov [r13+r12*1], r10
00007154327cf073  vxorps xmm12, xmm12, xmm12
00007154327cf078  vpbroadcastq xmm12, xmm12
00007154327cf07d  lea r12, [r14+0x100]
00007154327cf084  movq xmm11, qword ptr [r15+0x200]
00007154327cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007154327cf096  movq r11, xmm11
00007154327cf09b  movq r10, xmm10
00007154327cf0a0  mov [r13+r12*1], r11
00007154327cf0a5  lea r12, [r14+0x108]
00007154327cf0ac  mov [r13+r12*1], r10
00007154327cf0b1  lea r12, [r14+0xE0]
00007154327cf0b8  movups [r13+r12*1], xmm15
00007154327cf0be  lea r12, [r14+0xF0]
00007154327cf0c5  movups [r13+r12*1], xmm1
00007154327cf0cb  lea r12, [rax+0xC0]
00007154327cf0d2  movups xmm1, [r13+r12*1]
00007154327cf0d8  lea r12, [rax+0xD0]
00007154327cf0df  movups xmm15, [r13+r12*1]
00007154327cf0e5  lea r12, [r14+0x110]
00007154327cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007154327cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007154327cf0fe  movq r11, xmm11
00007154327cf103  movq r10, xmm10
00007154327cf108  mov [r13+r12*1], r11
00007154327cf10d  lea r12, [r14+0x118]
00007154327cf114  mov [r13+r12*1], r10
00007154327cf119  movups xmm11, [r13+rax*1]
00007154327cf11f  lea r12, [rax+0x10]
00007154327cf123  movups xmm10, [r13+r12*1]
00007154327cf129  lea r12, [r14+0x130]
00007154327cf130  movq xmm9, qword ptr [r15+0x1A0]
00007154327cf139  movq xmm8, qword ptr [r15+0x190]
00007154327cf142  movq r11, xmm9
00007154327cf147  movq r10, xmm8
00007154327cf14c  mov [r13+r12*1], r11
00007154327cf151  lea r12, [r14+0x138]
00007154327cf158  mov [r13+r12*1], r10
00007154327cf15d  lea r12, [rax+0x140]
00007154327cf164  movups xmm9, [r13+r12*1]
00007154327cf16a  lea r12, [rax+0x150]
00007154327cf171  movups xmm8, [r13+r12*1]
00007154327cf177  lea r12, [r14+0xC0]
00007154327cf17e  movups [r13+r12*1], xmm15
00007154327cf184  lea r12, [r14+0xD0]
00007154327cf18b  movups [r13+r12*1], xmm1
00007154327cf191  lea r12, [rax+0x100]
00007154327cf198  movups xmm1, [r13+r12*1]
00007154327cf19e  lea r12, [rax+0x110]
00007154327cf1a5  movups xmm15, [r13+r12*1]
00007154327cf1ab  lea r12, [r14+0x140]
00007154327cf1b2  mov r11, [r15+0xE8]
00007154327cf1b9  mov [r13+r12*1], r11
00007154327cf1be  lea r12, [rax+0x180]
00007154327cf1c5  movups xmm7, [r13+r12*1]
00007154327cf1cb  lea r12, [rax+0x190]
00007154327cf1d2  movups xmm6, [r13+r12*1]
00007154327cf1d8  lea r12, [rax+0x1C0]
00007154327cf1df  movups xmm5, [r13+r12*1]
00007154327cf1e5  lea r12, [rax+0x1D0]
00007154327cf1ec  movups xmm4, [r13+r12*1]
00007154327cf1f2  lea r12, [r14+0x20]
00007154327cf1f6  movups [r13+r12*1], xmm1
00007154327cf1fc  lea r12, [r14+0x30]
00007154327cf200  movups [r13+r12*1], xmm13
00007154327cf206  lea r12, [rax+0x60]
00007154327cf20a  movups xmm1, [r13+r12*1]
00007154327cf210  lea r12, [rax+0x70]
00007154327cf214  movups xmm13, [r13+r12*1]
00007154327cf21a  lea r12, [rax+0x20]
00007154327cf21e  movups xmm3, [r13+r12*1]
00007154327cf224  lea r12, [rax+0x30]
00007154327cf228  movups xmm2, [r13+r12*1]
00007154327cf22e  movaps [r15+0x1F0], xmm2
00007154327cf236  lea r12, [r14+0x60]
00007154327cf23a  movups [r13+r12*1], xmm11
00007154327cf240  lea r12, [r14+0x70]
00007154327cf244  movups [r13+r12*1], xmm5
00007154327cf24a  lea r12, [rax+0xE0]
00007154327cf251  movups xmm11, [r13+r12*1]
00007154327cf257  lea r12, [rax+0xF0]
00007154327cf25e  movups xmm5, [r13+r12*1]
00007154327cf264  lea r12, [r14+0xA0]
00007154327cf26b  movups [r13+r12*1], xmm13
00007154327cf271  lea r12, [r14+0xB0]
00007154327cf278  movups [r13+r12*1], xmm1
00007154327cf27e  lea r12, [rax+0xA0]
00007154327cf285  movups xmm1, [r13+r12*1]
00007154327cf28b  lea r12, [rax+0xB0]
00007154327cf292  movups xmm13, [r13+r12*1]
00007154327cf298  lea r12, [rax+0x120]
00007154327cf29f  vmovaps [rsp+0x10], xmm1
00007154327cf2a5  movups xmm1, [r13+r12*1]
00007154327cf2ab  lea r12, [rax+0x130]
00007154327cf2b2  vmovaps [rsp+0x20], xmm1
00007154327cf2b8  movups xmm1, [r13+r12*1]
00007154327cf2be  lea r12, [rax+0x160]
00007154327cf2c5  vmovaps [rsp+0x30], xmm1
00007154327cf2cb  movups xmm1, [r13+r12*1]
00007154327cf2d1  lea r12, [rax+0x170]
00007154327cf2d8  vmovaps [rsp+0x40], xmm1
00007154327cf2de  movups xmm1, [r13+r12*1]
00007154327cf2e4  movaps [r15+0x2B0], xmm1
00007154327cf2ec  lea r12, [r14+0x80]
00007154327cf2f3  movups [r13+r12*1], xmm13
00007154327cf2f9  lea r12, [r14+0x90]
00007154327cf300  vmovaps xmm13, [rsp+0x10]
00007154327cf306  movups [r13+r12*1], xmm13
00007154327cf30c  lea r12, [rax+0x1A0]
00007154327cf313  movups xmm13, [r13+r12*1]
00007154327cf319  lea r12, [rax+0x1B0]
00007154327cf320  vmovaps [rsp+0x10], xmm1
00007154327cf326  movups xmm1, [r13+r12*1]
00007154327cf32c  movaps [r15+0x290], xmm13
00007154327cf334  movaps [r15+0x1E0], xmm1
00007154327cf33c  lea r12, [rax+0x1E0]
00007154327cf343  vmovaps [rsp+0x50], xmm1
00007154327cf349  movups xmm1, [r13+r12*1]
00007154327cf34f  lea r12, [rax+0x1F0]
00007154327cf356  vmovaps [rsp+0x60], xmm1
00007154327cf35c  movups xmm1, [r13+r12*1]
00007154327cf362  mov qword ptr [r15+0x50], 0x430920
00007154327cf36a  lea rax, [r14+0x40]
00007154327cf36e  vmovaps [rsp+0x70], xmm1
00007154327cf374  vmovaps xmm1, [rsp+0x40]
00007154327cf37a  movups [r13+rax*1], xmm1
00007154327cf380  lea rax, [r14+0x50]
00007154327cf384  movups [r13+rax*1], xmm10
00007154327cf38a  vmovaps xmm1, [rsp+0x70]
00007154327cf390  movups [r13+r14*1], xmm1
00007154327cf396  lea rax, [r14+0x10]
00007154327cf39a  vmovaps xmm1, [rsp+0x60]
00007154327cf3a0  movups [r13+rax*1], xmm1
00007154327cf3a6  mov rax, [r15+0x40]
00007154327cf3aa  vmovaps [rsp+0x40], xmm3
00007154327cf3b0  vmovaps xmm1, [rsp+0x40]
00007154327cf3b6  por xmm3, xmm1
00007154327cf3ba  vmovaps [rsp+0x40], xmm6
00007154327cf3c0  vmovaps xmm10, [rsp+0x40]
00007154327cf3c6  por xmm6, xmm10
00007154327cf3cb  lea r12, [rax+0x30]
00007154327cf3cf  mov r11, [r13+r12*1]
00007154327cf3d4  lea r12, [rax+0x38]
00007154327cf3d8  mov r10, [r13+r12*1]
00007154327cf3dd  movq xmm10, r11
00007154327cf3e2  vmovaps [rsp+0x40], xmm1
00007154327cf3e8  movq xmm1, r10
00007154327cf3ed  movq xmm10, xmm10
00007154327cf3f2  vmovaps [rsp+0x60], xmm10
00007154327cf3f8  movq xmm10, xmm10
00007154327cf3fd  movaps [r15+0x130], xmm10
00007154327cf405  movq xmm1, xmm1
00007154327cf409  vmovaps [rsp+0x70], xmm1
00007154327cf40f  movq xmm1, xmm1
00007154327cf413  movaps [r15+0x280], xmm1
00007154327cf41b  vmovaps [rsp+0x80], xmm9
00007154327cf424  vmovaps xmm1, [rsp+0x80]
00007154327cf42d  por xmm9, xmm1
00007154327cf432  lea r12, [rax+0x20]
00007154327cf436  mov r11, [r13+r12*1]
00007154327cf43b  lea r12, [rax+0x28]
00007154327cf43f  mov r10, [r13+r12*1]
00007154327cf444  movq xmm1, r11
00007154327cf449  movq xmm10, r10
00007154327cf44e  movq xmm1, xmm1
00007154327cf452  vmovaps [rsp+0x80], xmm1
00007154327cf45b  movq xmm1, xmm1
00007154327cf45f  movaps [r15+0x150], xmm1
00007154327cf467  movq xmm10, xmm10
00007154327cf46c  vmovaps [rsp+0x90], xmm10
00007154327cf475  movq xmm10, xmm10
00007154327cf47a  movaps [r15+0x140], xmm10
00007154327cf482  lea r12, [rax+0x10]
00007154327cf486  mov r11, [r13+r12*1]
00007154327cf48b  lea r12, [rax+0x18]
00007154327cf48f  mov r10, [r13+r12*1]
00007154327cf494  movq xmm1, r11
00007154327cf499  movq xmm10, r10
00007154327cf49e  movq xmm1, xmm1
00007154327cf4a2  vmovaps [rsp+0xA0], xmm1
00007154327cf4ab  movq xmm1, xmm1
00007154327cf4af  movaps [r15+0x170], xmm1
00007154327cf4b7  movq xmm10, xmm10
00007154327cf4bc  vmovaps [rsp+0xB0], xmm10
00007154327cf4c5  movq xmm10, xmm10
00007154327cf4ca  movaps [r15+0x160], xmm10
00007154327cf4d2  mov r12, [r13+rax*1]
00007154327cf4d7  vmovq xmm1, r12
00007154327cf4dc  vpbroadcastq xmm1, xmm1
00007154327cf4e1  lea r12, [rax+0x08]
00007154327cf4e5  mov rax, [r13+r12*1]
00007154327cf4ea  movq xmm10, rax
00007154327cf4ef  movaps [r15+0x230], xmm10
00007154327cf4f7  lea rax, [r14+0x50]
00007154327cf4fb  movups xmm10, [r13+rax*1]
00007154327cf501  lea rax, [r14+0x60]
00007154327cf505  vmovaps [rsp+0xC0], xmm1
00007154327cf50e  movups xmm1, [r13+rax*1]
00007154327cf514  lea rax, [r14+0x30]
00007154327cf518  vmovaps [rsp+0xD0], xmm1
00007154327cf521  movups xmm1, [r13+rax*1]
00007154327cf527  mov qword ptr [r15+0x60], 0x430920
00007154327cf52f  mov qword ptr [r15+0x58], 0x40
00007154327cf537  vmovaps [rsp+0xE0], xmm1
00007154327cf540  vmovaps [rsp+0xF0], xmm15
00007154327cf549  vmovaps xmm15, [rsp+0xC0]
00007154327cf552  vmovaps [rsp+0xC0], xmm14
00007154327cf55b  vmovaps xmm14, [rsp+0x40]
00007154327cf561  vmovaps [rsp+0x40], xmm13
00007154327cf567  movaps xmm1, xmm15
00007154327cf56b  mulpd xmm1, xmm14
00007154327cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007154327cf575  ptest xmm13, xmm13
00007154327cf57b  jnz 0x00007154327D0682
00007154327cf581  movq xmm14, qword ptr [r15+0x230]
00007154327cf58a  vmovaps [rsp+0x100], xmm14
00007154327cf593  vpermilpd xmm14, xmm14, 0x00
00007154327cf599  vmovaps [rsp+0x110], xmm1
00007154327cf5a2  vmovaps xmm1, [rsp+0xE0]
00007154327cf5ab  vmovaps [rsp+0xE0], xmm15
00007154327cf5b4  movaps xmm13, xmm1
00007154327cf5b8  mulpd xmm13, xmm14
00007154327cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007154327cf5c3  ptest xmm15, xmm15
00007154327cf5c9  jnz 0x00007154327D07C4
00007154327cf5cf  vxorps xmm1, xmm1, xmm1
00007154327cf5d3  vpbroadcastq xmm1, xmm1
00007154327cf5d8  vmovaps xmm14, [rsp+0xE0]
00007154327cf5e1  vmovaps [rsp+0xE0], xmm1
00007154327cf5ea  vmovaps xmm1, [rsp+0xD0]
00007154327cf5f3  vmovaps [rsp+0xD0], xmm13
00007154327cf5fc  movaps xmm15, xmm14
00007154327cf600  mulpd xmm15, xmm1
00007154327cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007154327cf60b  ptest xmm13, xmm13
00007154327cf611  jnz 0x00007154327D0907
00007154327cf617  movaps xmm1, xmm14
00007154327cf61b  mulpd xmm1, xmm10
00007154327cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007154327cf625  ptest xmm13, xmm13
00007154327cf62b  jnz 0x00007154327D0A4A
00007154327cf631  movaps xmm13, xmm14
00007154327cf635  mulpd xmm13, xmm2
00007154327cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007154327cf640  ptest xmm10, xmm10
00007154327cf646  jnz 0x00007154327D0B8C
00007154327cf64c  vmovaps [rsp+0x120], xmm7
00007154327cf655  vmovaps xmm14, [rsp+0x120]
00007154327cf65e  por xmm7, xmm14
00007154327cf663  vmovaps xmm14, [rsp+0xC0]
00007154327cf66c  vmovaps xmm10, [rsp+0xC0]
00007154327cf675  por xmm14, xmm10
00007154327cf67a  vmovaps xmm2, [rsp+0x100]
00007154327cf683  vpermilpd xmm2, xmm2, 0x00
00007154327cf689  vmovaps [rsp+0xC0], xmm1
00007154327cf692  vmovaps [rsp+0x120], xmm15
00007154327cf69b  movaps xmm1, xmm10
00007154327cf69f  mulpd xmm1, xmm2
00007154327cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007154327cf6a8  ptest xmm15, xmm15
00007154327cf6ae  jnz 0x00007154327D0CCF
00007154327cf6b4  xor eax, eax
00007154327cf6b6  mov r12d, 0x40
00007154327cf6bc  mov r11d, 0x200
00007154327cf6c2  cmp r12, r11
00007154327cf6c5  cmc
00007154327cf6c6  lahf
00007154327cf6c7  seto al
00007154327cf6ca  mov [r15+0x108], eax
00007154327cf6d1  vmovaps xmm10, [rsp+0x110]
00007154327cf6da  vmovaps xmm2, [rsp+0xE0]
00007154327cf6e3  vmovaps [rsp+0xE0], xmm1
00007154327cf6ec  movaps xmm15, xmm10
00007154327cf6f0  addpd xmm15, xmm2
00007154327cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007154327cf6fb  ptest xmm1, xmm1
00007154327cf700  jnz 0x00007154327D0E10
00007154327cf706  vmovaps xmm10, [rsp+0x120]
00007154327cf70f  vmovaps [rsp+0x110], xmm15
00007154327cf718  movaps xmm1, xmm10
00007154327cf71c  addpd xmm1, xmm12
00007154327cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007154327cf726  ptest xmm15, xmm15
00007154327cf72c  jnz 0x00007154327D0F53
00007154327cf732  vmovaps xmm10, [rsp+0xC0]
00007154327cf73b  vmovaps [rsp+0xC0], xmm1
00007154327cf744  movaps xmm15, xmm10
00007154327cf748  addpd xmm15, xmm12
00007154327cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007154327cf753  ptest xmm1, xmm1
00007154327cf758  jnz 0x00007154327D1095
00007154327cf75e  vmovaps xmm1, [rsp+0x30]
00007154327cf764  vmovaps xmm12, [rsp+0x30]
00007154327cf76a  por xmm1, xmm12
00007154327cf76f  vmovaps xmm12, [rsp+0x20]
00007154327cf775  vmovaps xmm10, [rsp+0x20]
00007154327cf77b  por xmm12, xmm10
00007154327cf780  vmovaps [rsp+0x20], xmm5
00007154327cf786  vmovaps xmm10, [rsp+0x20]
00007154327cf78c  por xmm5, xmm10
00007154327cf791  vmovaps [rsp+0x20], xmm11
00007154327cf797  vmovaps xmm10, [rsp+0x20]
00007154327cf79d  por xmm11, xmm10
00007154327cf7a2  vmovaps [rsp+0x20], xmm4
00007154327cf7a8  vmovaps xmm10, [rsp+0x20]
00007154327cf7ae  por xmm4, xmm10
00007154327cf7b3  vmovaps [rsp+0x20], xmm8
00007154327cf7b9  vmovaps xmm10, [rsp+0x20]
00007154327cf7bf  por xmm8, xmm10
00007154327cf7c4  vmovaps xmm10, [rsp+0xF0]
00007154327cf7cd  vmovaps [rsp+0x20], xmm1
00007154327cf7d3  vmovaps xmm1, [rsp+0xF0]
00007154327cf7dc  por xmm10, xmm1
00007154327cf7e1  lea rax, [r14+0xA0]
00007154327cf7e8  movups xmm1, [r13+rax*1]
00007154327cf7ee  lea rax, [r14+0xB0]
00007154327cf7f5  vmovaps [rsp+0x30], xmm1
00007154327cf7fb  movups xmm1, [r13+rax*1]
00007154327cf801  vmovaps [rsp+0xF0], xmm1
00007154327cf80a  vmovaps [rsp+0x120], xmm15
00007154327cf813  movaps xmm1, xmm13
00007154327cf817  addpd xmm1, xmm2
00007154327cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007154327cf820  ptest xmm15, xmm15
00007154327cf826  jnz 0x00007154327D11ED
00007154327cf82c  lea rax, [r14+0xF0]
00007154327cf833  movups xmm15, [r13+rax*1]
00007154327cf839  vmovaps xmm2, [rsp+0xC0]
00007154327cf842  vmovaps [rsp+0xC0], xmm1
00007154327cf84b  vmovaps xmm1, [rsp+0xE0]
00007154327cf854  vmovaps [rsp+0xE0], xmm15
00007154327cf85d  movaps xmm13, xmm2
00007154327cf861  addpd xmm13, xmm1
00007154327cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007154327cf86c  ptest xmm15, xmm15
00007154327cf872  jnz 0x00007154327D1338
00007154327cf878  vmovaps xmm15, [rsp+0x120]
00007154327cf881  vmovaps xmm2, [rsp+0xD0]
00007154327cf88a  vmovaps [rsp+0xD0], xmm14
00007154327cf893  movaps xmm1, xmm15
00007154327cf897  addpd xmm1, xmm2
00007154327cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007154327cf8a0  ptest xmm14, xmm14
00007154327cf8a6  jnz 0x00007154327D147A
00007154327cf8ac  vmovaps xmm15, [rsp+0x100]
00007154327cf8b5  vpermilpd xmm15, xmm15, 0x00
00007154327cf8bb  vmovaps xmm2, [rsp+0xF0]
00007154327cf8c4  vmovaps [rsp+0xF0], xmm1
00007154327cf8cd  movaps xmm14, xmm2
00007154327cf8d1  mulpd xmm14, xmm15
00007154327cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007154327cf8dc  ptest xmm1, xmm1
00007154327cf8e1  jnz 0x00007154327D15BB
00007154327cf8e7  vmovaps xmm1, [rsp+0xA0]
00007154327cf8f0  vpermilpd xmm1, xmm1, 0x00
00007154327cf8f6  vmovaps xmm2, [rsp+0xE0]
00007154327cf8ff  vmovaps [rsp+0xE0], xmm14
00007154327cf908  movaps xmm15, xmm2
00007154327cf90c  mulpd xmm15, xmm1
00007154327cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007154327cf917  ptest xmm14, xmm14
00007154327cf91d  jnz 0x00007154327D16FE
00007154327cf923  lea rax, [r14+0xE0]
00007154327cf92a  movups xmm1, [r13+rax*1]
00007154327cf930  vmovaps xmm14, [rsp+0x100]
00007154327cf939  vpermilpd xmm14, xmm14, 0x00
00007154327cf93f  vmovaps [rsp+0x100], xmm1
00007154327cf948  vmovaps xmm1, [rsp+0x30]
00007154327cf94e  vmovaps [rsp+0x30], xmm15
00007154327cf954  movaps xmm2, xmm1
00007154327cf957  mulpd xmm2, xmm14
00007154327cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007154327cf961  ptest xmm15, xmm15
00007154327cf967  jnz 0x00007154327D184A
00007154327cf96d  vmovaps [rsp+0x120], xmm10
00007154327cf976  vmovaps xmm1, [rsp+0x120]
00007154327cf97f  por xmm10, xmm1
00007154327cf984  movaps [r15+0x300], xmm10
00007154327cf98c  vmovaps [rsp+0x120], xmm8
00007154327cf995  vmovaps xmm1, [rsp+0x120]
00007154327cf99e  por xmm8, xmm1
00007154327cf9a3  movaps [r15+0x190], xmm8
00007154327cf9ab  vmovaps xmm1, [rsp+0xA0]
00007154327cf9b4  vpermilpd xmm1, xmm1, 0x00
00007154327cf9ba  vmovaps xmm14, [rsp+0x100]
00007154327cf9c3  vmovaps [rsp+0x100], xmm13
00007154327cf9cc  movaps xmm15, xmm14
00007154327cf9d0  mulpd xmm15, xmm1
00007154327cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007154327cf9db  ptest xmm13, xmm13
00007154327cf9e1  jnz 0x00007154327D198B
00007154327cf9e7  lea rax, [r14+0x90]
00007154327cf9ee  movups xmm1, [r13+rax*1]
00007154327cf9f4  vmovaps [rsp+0x120], xmm4
00007154327cf9fd  vmovaps xmm14, [rsp+0x120]
00007154327cfa06  por xmm4, xmm14
00007154327cfa0b  movaps [r15+0x1C0], xmm4
00007154327cfa13  vmovaps [rsp+0x120], xmm11
00007154327cfa1c  vmovaps xmm14, [rsp+0x120]
00007154327cfa25  por xmm11, xmm14
00007154327cfa2a  movaps [r15+0x200], xmm11
00007154327cfa32  vmovaps [rsp+0x120], xmm5
00007154327cfa3b  vmovaps xmm14, [rsp+0x120]
00007154327cfa44  por xmm5, xmm14
00007154327cfa49  movaps [r15+0x2D0], xmm5
00007154327cfa51  vmovaps [rsp+0x120], xmm12
00007154327cfa5a  vmovaps xmm14, [rsp+0x120]
00007154327cfa63  por xmm12, xmm14
00007154327cfa68  movaps [r15+0x2E0], xmm12
00007154327cfa70  vmovaps xmm13, [rsp+0x110]
00007154327cfa79  vmovaps [rsp+0x110], xmm1
00007154327cfa82  vmovaps xmm1, [rsp+0xE0]
00007154327cfa8b  vmovaps [rsp+0xE0], xmm15
00007154327cfa94  movaps xmm14, xmm13
00007154327cfa98  addpd xmm14, xmm1
00007154327cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007154327cfaa3  ptest xmm15, xmm15
00007154327cfaa9  jnz 0x00007154327D1AD8
00007154327cfaaf  vmovaps xmm1, [rsp+0xA0]
00007154327cfab8  vpermilpd xmm1, xmm1, 0x00
00007154327cfabe  vmovaps xmm13, [rsp+0x110]
00007154327cfac7  vmovaps [rsp+0x110], xmm14
00007154327cfad0  movaps xmm15, xmm13
00007154327cfad4  mulpd xmm15, xmm1
00007154327cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007154327cfadf  ptest xmm14, xmm14
00007154327cfae5  jnz 0x00007154327D1C1B
00007154327cfaeb  lea rax, [r14+0x80]
00007154327cfaf2  movups xmm1, [r13+rax*1]
00007154327cfaf8  vmovaps xmm13, [rsp+0xC0]
00007154327cfb01  vmovaps [rsp+0xC0], xmm1
00007154327cfb0a  movaps xmm14, xmm13
00007154327cfb0e  addpd xmm14, xmm2
00007154327cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007154327cfb19  ptest xmm1, xmm1
00007154327cfb1e  jnz 0x00007154327D1D68
00007154327cfb24  vmovaps xmm13, [rsp+0x100]
00007154327cfb2d  vmovaps xmm2, [rsp+0x30]
00007154327cfb33  vmovaps [rsp+0x30], xmm15
00007154327cfb39  movaps xmm1, xmm13
00007154327cfb3d  addpd xmm1, xmm2
00007154327cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007154327cfb46  ptest xmm15, xmm15
00007154327cfb4c  jnz 0x00007154327D1EAB
00007154327cfb52  vmovaps xmm15, [rsp+0x20]
00007154327cfb58  vmovaps xmm13, [rsp+0x20]
00007154327cfb5e  por xmm15, xmm13
00007154327cfb63  movaps [r15+0x2F0], xmm15
00007154327cfb6b  vmovaps xmm13, [rsp+0xA0]
00007154327cfb74  vpermilpd xmm13, xmm13, 0x00
00007154327cfb7a  vmovaps [rsp+0x20], xmm1
00007154327cfb80  vmovaps xmm1, [rsp+0xC0]
00007154327cfb89  vmovaps [rsp+0xA0], xmm15
00007154327cfb92  movaps xmm2, xmm1
00007154327cfb95  mulpd xmm2, xmm13
00007154327cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007154327cfb9f  ptest xmm15, xmm15
00007154327cfba5  jnz 0x00007154327D1FEC
00007154327cfbab  lea rax, [r14+0xD0]
00007154327cfbb2  movups xmm1, [r13+rax*1]
00007154327cfbb8  vmovaps xmm13, [rsp+0xF0]
00007154327cfbc1  vmovaps [rsp+0xC0], xmm1
00007154327cfbca  vmovaps xmm1, [rsp+0xE0]
00007154327cfbd3  vmovaps [rsp+0xE0], xmm14
00007154327cfbdc  movaps xmm15, xmm13
00007154327cfbe0  addpd xmm15, xmm1
00007154327cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007154327cfbeb  ptest xmm14, xmm14
00007154327cfbf1  jnz 0x00007154327D2137
00007154327cfbf7  vmovaps xmm1, [rsp+0xB0]
00007154327cfc00  vpermilpd xmm1, xmm1, 0x00
00007154327cfc06  movaps xmm14, xmm11
00007154327cfc0a  mulpd xmm14, xmm1
00007154327cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007154327cfc15  ptest xmm13, xmm13
00007154327cfc1b  jnz 0x00007154327D227A
00007154327cfc21  movaps [r15+0x260], xmm14
00007154327cfc29  vxorps xmm1, xmm1, xmm1
00007154327cfc2d  vpbroadcastq xmm1, xmm1
00007154327cfc32  movaps [r15+0x1B0], xmm1
00007154327cfc3a  vmovaps xmm1, [rsp+0xB0]
00007154327cfc43  vpermilpd xmm1, xmm1, 0x00
00007154327cfc49  vmovaps xmm11, [rsp+0xC0]
00007154327cfc52  vmovaps [rsp+0xC0], xmm15
00007154327cfc5b  movaps xmm13, xmm11
00007154327cfc5f  mulpd xmm13, xmm1
00007154327cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007154327cfc6a  ptest xmm15, xmm15
00007154327cfc70  jnz 0x00007154327D23BD
00007154327cfc76  lea rax, [r14+0xC0]
00007154327cfc7d  movups xmm1, [r13+rax*1]
00007154327cfc83  vmovaps xmm11, [rsp+0x110]
00007154327cfc8c  vmovaps [rsp+0xF0], xmm1
00007154327cfc95  vmovaps xmm1, [rsp+0x30]
00007154327cfc9b  vmovaps [rsp+0x30], xmm14
00007154327cfca1  movaps xmm15, xmm11
00007154327cfca5  addpd xmm15, xmm1
00007154327cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007154327cfcb0  ptest xmm14, xmm14
00007154327cfcb6  jnz 0x00007154327D250A
00007154327cfcbc  vmovaps [rsp+0x100], xmm9
00007154327cfcc5  vmovaps xmm1, [rsp+0x100]
00007154327cfcce  por xmm9, xmm1
00007154327cfcd3  movaps [r15+0x270], xmm9
00007154327cfcdb  vmovaps [rsp+0x100], xmm6
00007154327cfce4  vmovaps xmm1, [rsp+0x100]
00007154327cfced  por xmm6, xmm1
00007154327cfcf1  movaps [r15+0x1A0], xmm6
00007154327cfcf9  vmovaps xmm14, [rsp+0xB0]
00007154327cfd02  vpermilpd xmm14, xmm14, 0x00
00007154327cfd08  vmovaps xmm6, [rsp+0xF0]
00007154327cfd11  vmovaps [rsp+0xF0], xmm1
00007154327cfd1a  movaps xmm11, xmm6
00007154327cfd1e  mulpd xmm11, xmm14
00007154327cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007154327cfd29  ptest xmm1, xmm1
00007154327cfd2e  jnz 0x00007154327D264D
00007154327cfd34  lea rax, [r14+0x20]
00007154327cfd38  movups xmm1, [r13+rax*1]
00007154327cfd3e  movaps [r15+0x110], xmm1
00007154327cfd46  vmovaps xmm6, [rsp+0xE0]
00007154327cfd4f  vmovaps [rsp+0xE0], xmm1
00007154327cfd58  movaps xmm14, xmm6
00007154327cfd5c  addpd xmm14, xmm2
00007154327cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007154327cfd67  ptest xmm1, xmm1
00007154327cfd6c  jnz 0x00007154327D279A
00007154327cfd72  vmovaps xmm1, [rsp+0xB0]
00007154327cfd7b  vpermilpd xmm1, xmm1, 0x00
00007154327cfd81  movaps xmm6, xmm5
00007154327cfd84  mulpd xmm6, xmm1
00007154327cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007154327cfd8d  ptest xmm2, xmm2
00007154327cfd92  jnz 0x00007154327D28DC
00007154327cfd98  vmovaps xmm5, [rsp+0x20]
00007154327cfd9e  movaps xmm1, xmm5
00007154327cfda1  addpd xmm1, xmm13
00007154327cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007154327cfdab  ptest xmm2, xmm2
00007154327cfdb0  jnz 0x00007154327D2A1C
00007154327cfdb6  vmovaps xmm13, [rsp+0x80]
00007154327cfdbf  vpermilpd xmm13, xmm13, 0x00
00007154327cfdc5  vmovaps xmm2, [rsp+0xE0]
00007154327cfdce  vmovaps [rsp+0x20], xmm1
00007154327cfdd4  movaps xmm5, xmm2
00007154327cfdd7  mulpd xmm5, xmm13
00007154327cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007154327cfde1  ptest xmm1, xmm1
00007154327cfde6  jnz 0x00007154327D2B5D
00007154327cfdec  vmovaps xmm1, [rsp+0x80]
00007154327cfdf5  vpermilpd xmm1, xmm1, 0x00
00007154327cfdfb  movaps xmm13, xmm10
00007154327cfdff  mulpd xmm13, xmm1
00007154327cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007154327cfe0a  ptest xmm2, xmm2
00007154327cfe0f  jnz 0x00007154327D2C9E
00007154327cfe15  vmovaps xmm10, [rsp+0x30]
00007154327cfe1b  movaps xmm1, xmm15
00007154327cfe1f  addpd xmm1, xmm10
00007154327cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007154327cfe29  ptest xmm2, xmm2
00007154327cfe2e  jnz 0x00007154327D2DE1
00007154327cfe34  vmovaps xmm10, [rsp+0xC0]
00007154327cfe3d  movaps xmm15, xmm10
00007154327cfe41  addpd xmm15, xmm11
00007154327cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007154327cfe4c  ptest xmm2, xmm2
00007154327cfe51  jnz 0x00007154327D2F23
00007154327cfe57  vmovaps xmm11, [rsp+0x80]
00007154327cfe60  vpermilpd xmm11, xmm11, 0x00
00007154327cfe66  movaps xmm10, xmm12
00007154327cfe6a  mulpd xmm10, xmm11
00007154327cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007154327cfe75  ptest xmm2, xmm2
00007154327cfe7a  jnz 0x00007154327D3067
00007154327cfe80  vmovaps xmm12, [rsp+0x80]
00007154327cfe89  vpermilpd xmm12, xmm12, 0x00
00007154327cfe8f  vmovaps xmm2, [rsp+0xA0]
00007154327cfe98  vmovaps [rsp+0x30], xmm1
00007154327cfe9e  movaps xmm11, xmm2
00007154327cfea2  mulpd xmm11, xmm12
00007154327cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007154327cfead  ptest xmm1, xmm1
00007154327cfeb2  jnz 0x00007154327D31AB
00007154327cfeb8  movaps xmm1, xmm14
00007154327cfebc  addpd xmm1, xmm6
00007154327cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007154327cfec5  ptest xmm12, xmm12
00007154327cfecb  jnz 0x00007154327D32EE
00007154327cfed1  vmovaps xmm12, [rsp+0x20]
00007154327cfed7  movaps xmm14, xmm12
00007154327cfedb  addpd xmm14, xmm5
00007154327cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007154327cfee6  ptest xmm6, xmm6
00007154327cfeeb  jnz 0x00007154327D342F
00007154327cfef1  vmovaps xmm12, [rsp+0x90]
00007154327cfefa  vpermilpd xmm12, xmm12, 0x00
00007154327cff00  movaps xmm6, xmm9
00007154327cff04  mulpd xmm6, xmm12
00007154327cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007154327cff0e  ptest xmm5, xmm5
00007154327cff13  jnz 0x00007154327D3572
00007154327cff19  movaps xmm12, xmm15
00007154327cff1d  addpd xmm12, xmm13
00007154327cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007154327cff28  ptest xmm9, xmm9
00007154327cff2e  jnz 0x00007154327D36B4
00007154327cff34  vmovaps xmm13, [rsp+0x30]
00007154327cff3a  movaps xmm15, xmm13
00007154327cff3e  addpd xmm15, xmm10
00007154327cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007154327cff49  ptest xmm9, xmm9
00007154327cff4f  jnz 0x00007154327D37F8
00007154327cff55  vmovaps xmm13, [rsp+0xD0]
00007154327cff5e  vmovaps xmm10, [rsp+0xD0]
00007154327cff67  por xmm13, xmm10
00007154327cff6c  movaps [r15+0x250], xmm13
00007154327cff74  vmovaps [rsp+0x20], xmm7
00007154327cff7a  vmovaps xmm13, [rsp+0x20]
00007154327cff80  por xmm7, xmm13
00007154327cff85  movaps [r15+0x2A0], xmm7
00007154327cff8d  vmovaps [rsp+0x20], xmm3
00007154327cff93  vmovaps xmm13, [rsp+0x20]
00007154327cff99  por xmm3, xmm13
00007154327cff9e  movaps [r15+0x1D0], xmm3
00007154327cffa6  lea rax, [r14+0x40]
00007154327cffaa  movups xmm13, [r13+rax*1]
00007154327cffb0  movaps [r15+0x2C0], xmm13
00007154327cffb8  vmovaps xmm10, [rsp+0x90]
00007154327cffc1  vpermilpd xmm10, xmm10, 0x00
00007154327cffc7  movaps xmm9, xmm8
00007154327cffcb  mulpd xmm9, xmm10
00007154327cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007154327cffd6  ptest xmm5, xmm5
00007154327cffdb  jnz 0x00007154327D3946
00007154327cffe1  movaps xmm10, xmm1
00007154327cffe5  addpd xmm10, xmm11
00007154327cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007154327cfff0  ptest xmm8, xmm8
00007154327cfff6  jnz 0x00007154327D3A8A
00007154327cfffc  movaps xmm1, xmm14
00007154327d0000  addpd xmm1, xmm6
00007154327d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007154327d0009  ptest xmm11, xmm11
00007154327d000f  jnz 0x00007154327D3BCD
00007154327d0015  vmovaps xmm14, [rsp+0x90]
00007154327d001e  vpermilpd xmm14, xmm14, 0x00
00007154327d0024  movaps xmm11, xmm13
00007154327d0028  mulpd xmm11, xmm14
00007154327d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007154327d0033  ptest xmm8, xmm8
00007154327d0039  jnz 0x00007154327D3D0E
00007154327d003f  vmovaps xmm14, [rsp+0x90]
00007154327d0048  vpermilpd xmm14, xmm14, 0x00
00007154327d004e  vmovaps xmm8, [rsp+0x10]
00007154327d0054  movaps xmm13, xmm8
00007154327d0058  mulpd xmm13, xmm14
00007154327d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007154327d0063  ptest xmm6, xmm6
00007154327d0068  jnz 0x00007154327D3E52
00007154327d006e  vmovaps xmm14, [rsp+0x60]
00007154327d0074  vpermilpd xmm14, xmm14, 0x00
00007154327d007a  movaps xmm8, xmm7
00007154327d007e  mulpd xmm8, xmm14
00007154327d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007154327d0089  ptest xmm6, xmm6
00007154327d008e  jnz 0x00007154327D3F96
00007154327d0094  movaps xmm14, xmm12
00007154327d0098  addpd xmm14, xmm9
00007154327d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007154327d00a3  ptest xmm7, xmm7
00007154327d00a8  jnz 0x00007154327D40D9
00007154327d00ae  vmovaps xmm12, [rsp+0x60]
00007154327d00b4  vpermilpd xmm12, xmm12, 0x00
00007154327d00ba  vmovaps xmm7, [rsp+0xF0]
00007154327d00c3  movaps xmm9, xmm7
00007154327d00c7  mulpd xmm9, xmm12
00007154327d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007154327d00d2  ptest xmm6, xmm6
00007154327d00d7  jnz 0x00007154327D421D
00007154327d00dd  movaps xmm12, xmm15
00007154327d00e1  addpd xmm12, xmm11
00007154327d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007154327d00ec  ptest xmm7, xmm7
00007154327d00f1  jnz 0x00007154327D4360
00007154327d00f7  vmovaps xmm15, [rsp+0x60]
00007154327d00fd  vpermilpd xmm15, xmm15, 0x00
00007154327d0103  vmovaps xmm7, [rsp+0x40]
00007154327d0109  movaps xmm11, xmm7
00007154327d010d  mulpd xmm11, xmm15
00007154327d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007154327d0118  ptest xmm6, xmm6
00007154327d011d  jnz 0x00007154327D44A4
00007154327d0123  movaps xmm15, xmm10
00007154327d0127  addpd xmm15, xmm13
00007154327d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007154327d0132  ptest xmm7, xmm7
00007154327d0137  jnz 0x00007154327D45E7
00007154327d013d  vmovaps xmm13, [rsp+0x60]
00007154327d0143  vpermilpd xmm13, xmm13, 0x00
00007154327d0149  vmovaps xmm7, [rsp+0x50]
00007154327d014f  movaps xmm10, xmm7
00007154327d0153  mulpd xmm10, xmm13
00007154327d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007154327d015e  ptest xmm6, xmm6
00007154327d0163  jnz 0x00007154327D472B
00007154327d0169  movaps xmm13, xmm1
00007154327d016d  addpd xmm13, xmm8
00007154327d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007154327d0178  ptest xmm7, xmm7
00007154327d017d  jnz 0x00007154327D486E
00007154327d0183  lea rax, [r14+0x70]
00007154327d0187  movups xmm1, [r13+rax*1]
00007154327d018d  movaps [r15+0x240], xmm1
00007154327d0195  movaps xmm8, xmm14
00007154327d0199  addpd xmm8, xmm9
00007154327d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007154327d01a4  ptest xmm7, xmm7
00007154327d01a9  jnz 0x00007154327D49BB
00007154327d01af  movaps [r15+0x170], xmm8
00007154327d01b7  vmovaps xmm14, [rsp+0x70]
00007154327d01bd  vpermilpd xmm14, xmm14, 0x00
00007154327d01c3  movaps xmm9, xmm1
00007154327d01c7  mulpd xmm9, xmm14
00007154327d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007154327d01d2  ptest xmm7, xmm7
00007154327d01d7  jnz 0x00007154327D4AFF
00007154327d01dd  vmovaps xmm1, [rsp+0x70]
00007154327d01e3  vpermilpd xmm1, xmm1, 0x00
00007154327d01e9  movaps xmm14, xmm4
00007154327d01ed  mulpd xmm14, xmm1
00007154327d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007154327d01f8  ptest xmm7, xmm7
00007154327d01fd  jnz 0x00007154327D4C42
00007154327d0203  movaps [r15+0x180], xmm14
00007154327d020b  movaps xmm1, xmm12
00007154327d020f  addpd xmm1, xmm11
00007154327d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007154327d0219  ptest xmm7, xmm7
00007154327d021e  jnz 0x00007154327D4D84
00007154327d0224  movaps [r15+0x210], xmm1
00007154327d022c  movups xmm12, [r13+r14*1]
00007154327d0232  lea rax, [r14+0x10]
00007154327d0236  movups xmm11, [r13+rax*1]
00007154327d023c  movaps [r15+0x230], xmm11
00007154327d0244  movaps xmm7, xmm15
00007154327d0248  addpd xmm7, xmm10
00007154327d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007154327d0252  ptest xmm6, xmm6
00007154327d0257  jnz 0x00007154327D4EDA
00007154327d025d  movaps [r15+0x130], xmm7
00007154327d0265  vmovaps xmm15, [rsp+0x70]
00007154327d026b  vpermilpd xmm15, xmm15, 0x00
00007154327d0271  movaps xmm10, xmm11
00007154327d0275  mulpd xmm10, xmm15
00007154327d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007154327d0280  ptest xmm6, xmm6
00007154327d0285  jnz 0x00007154327D501C
00007154327d028b  movaps [r15+0x220], xmm10
00007154327d0293  vmovaps xmm15, [rsp+0x70]
00007154327d0299  vpermilpd xmm15, xmm15, 0x00
00007154327d029f  movaps xmm11, xmm12
00007154327d02a3  mulpd xmm11, xmm15
00007154327d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007154327d02ae  ptest xmm6, xmm6
00007154327d02b3  jnz 0x00007154327D5160
00007154327d02b9  movaps xmm15, xmm13
00007154327d02bd  addpd xmm15, xmm9
00007154327d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007154327d02c8  ptest xmm12, xmm12
00007154327d02ce  jnz 0x00007154327D52A4
00007154327d02d4  movaps [r15+0x140], xmm15
00007154327d02dc  movaps xmm13, xmm8
00007154327d02e0  addpd xmm13, xmm14
00007154327d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007154327d02eb  ptest xmm12, xmm12
00007154327d02f1  jnz 0x00007154327D53E8
00007154327d02f7  movaps [r15+0x150], xmm13
00007154327d02ff  movaps xmm14, xmm1
00007154327d0303  addpd xmm14, xmm10
00007154327d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007154327d030e  ptest xmm12, xmm12
00007154327d0314  jnz 0x00007154327D552C
00007154327d031a  movaps [r15+0x160], xmm14
00007154327d0322  movaps xmm1, xmm7
00007154327d0325  addpd xmm1, xmm11
00007154327d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007154327d032f  ptest xmm12, xmm12
00007154327d0335  jnz 0x00007154327D566F
00007154327d033b  movaps [r15+0x120], xmm1
00007154327d0343  mov eax, 0x430920
00007154327d0348  movups [r13+rax*1], xmm15
00007154327d034e  mov eax, 0x430930
00007154327d0353  movups [r13+rax*1], xmm13
00007154327d0359  mov eax, 0x430940
00007154327d035e  movups [r13+rax*1], xmm14
00007154327d0364  mov eax, 0x430950
00007154327d0369  movups [r13+rax*1], xmm1
00007154327d036f  mov eax, [r15+0x108]
00007154327d0376  sahf
00007154327d0377  jnz 0x00007154327D03A9
00007154327d0379  cmp dword ptr [r15+0x318], 0x00
00007154327d0381  jz 0x00007154327DB900
00007154327d0387  nop [rax+rax*1], ax
00007154327d0390  nop [rax+rax*1], eax
00007154327d0398  mov eax, 0x410444
00007154327d039d  mov [r15+0x100], rax
00007154327d03a4  jmp 0x00007154325FE110
00007154327d03a9  cmp dword ptr [r15+0x318], 0x00
00007154327d03b1  jz 0x00007154327D57E0
00007154327d03b7  nop [rax+rax*1], ax
00007154327d03c0  nop [rax+rax*1], eax
00007154327d03c8  mov eax, 0x410278
00007154327d03cd  mov [r15+0x100], rax
00007154327d03d4  jmp 0x00007154325FE110
00007154327d03d9  int3
00007154327d03da  call 0x00007154326B52F0
00007154327d03df  jmp 0x00007154327CF016
00007154327d03e4  call 0x00007154326C4620
00007154327d03e9  jmp 0x00007154327CF023
00007154327d03ee  call 0x00007154326C33A0
00007154327d03f3  jmp 0x00007154327CF035
00007154327d03f8  call 0x00007154326C2120
00007154327d03fd  jmp 0x00007154327CF03F
00007154327d0402  call 0x00007154326C0860
00007154327d0407  jmp 0x00007154327CF067
00007154327d040c  call 0x00007154326BF5F0
00007154327d0411  jmp 0x00007154327CF073
00007154327d0416  call 0x00007154326C0860
00007154327d041b  jmp 0x00007154327CF0A5
00007154327d0420  call 0x00007154326BF5F0
00007154327d0425  jmp 0x00007154327CF0B1
00007154327d042a  call 0x00007154326C4740
00007154327d042f  jmp 0x00007154327CF0BE
00007154327d0434  call 0x00007154326B5400
00007154327d0439  jmp 0x00007154327CF0CB
00007154327d043e  call 0x00007154326B52F0
00007154327d0443  jmp 0x00007154327CF0D8
00007154327d0448  call 0x00007154326C4620
00007154327d044d  jmp 0x00007154327CF0E5
00007154327d0452  call 0x00007154326C0860
00007154327d0457  jmp 0x00007154327CF10D
00007154327d045c  call 0x00007154326BF5F0
00007154327d0461  jmp 0x00007154327CF119
00007154327d0466  call 0x0000715432609D70
00007154327d046b  jmp 0x00007154327CF11F
00007154327d0470  call 0x00007154326BE9C0
00007154327d0475  jmp 0x00007154327CF129
00007154327d047a  call 0x00007154326C0860
00007154327d047f  jmp 0x00007154327CF151
00007154327d0484  call 0x00007154326BF5F0
00007154327d0489  jmp 0x00007154327CF15D
00007154327d048e  call 0x00007154326BD750
00007154327d0493  jmp 0x00007154327CF16A
00007154327d0498  call 0x00007154326BC4E0
00007154327d049d  jmp 0x00007154327CF177
00007154327d04a2  call 0x00007154326C4740
00007154327d04a7  jmp 0x00007154327CF184
00007154327d04ac  call 0x00007154326B5400
00007154327d04b1  jmp 0x00007154327CF191
00007154327d04b6  call 0x00007154326B52F0
00007154327d04bb  jmp 0x00007154327CF19E
00007154327d04c0  call 0x00007154326C4620
00007154327d04c5  jmp 0x00007154327CF1AB
00007154327d04ca  call 0x00007154326C0860
00007154327d04cf  jmp 0x00007154327CF1BE
00007154327d04d4  call 0x00007154326BB270
00007154327d04d9  jmp 0x00007154327CF1CB
00007154327d04de  call 0x00007154326BA000
00007154327d04e3  jmp 0x00007154327CF1D8
00007154327d04e8  call 0x00007154326B8D90
00007154327d04ed  jmp 0x00007154327CF1E5
00007154327d04f2  call 0x00007154326B8A20
00007154327d04f7  jmp 0x00007154327CF1F2
00007154327d04fc  call 0x00007154326B5400
00007154327d0501  jmp 0x00007154327CF1FC
00007154327d0506  call 0x00007154326C2240
00007154327d050b  jmp 0x00007154327CF206
00007154327d0510  call 0x00007154326B52F0
00007154327d0515  jmp 0x00007154327CF210
00007154327d051a  call 0x00007154326C2120
00007154327d051f  jmp 0x00007154327CF21A
00007154327d0524  call 0x00007154326B77B0
00007154327d0529  jmp 0x00007154327CF224
00007154327d052e  call 0x00007154326B6550
00007154327d0533  jmp 0x00007154327CF22E
00007154327d0538  call 0x00007154326BFD50
00007154327d053d  jmp 0x00007154327CF240
00007154327d0542  call 0x00007154326B8EA0
00007154327d0547  jmp 0x00007154327CF24A
00007154327d054c  call 0x00007154326BFC30
00007154327d0551  jmp 0x00007154327CF257
00007154327d0556  call 0x00007154326B8D90
00007154327d055b  jmp 0x00007154327CF264
00007154327d0560  call 0x00007154326C2240
00007154327d0565  jmp 0x00007154327CF271
00007154327d056a  call 0x00007154326B5400
00007154327d056f  jmp 0x00007154327CF27E
00007154327d0574  call 0x00007154326B52F0
00007154327d0579  jmp 0x00007154327CF28B
00007154327d057e  call 0x00007154326C2120
00007154327d0583  jmp 0x00007154327CF298
00007154327d0588  call 0x00007154326B52F0
00007154327d058d  jmp 0x00007154327CF2AB
00007154327d0592  call 0x00007154326B52F0
00007154327d0597  jmp 0x00007154327CF2BE
00007154327d059c  call 0x00007154326B52F0
00007154327d05a1  jmp 0x00007154327CF2D1
00007154327d05a6  call 0x00007154326B52F0
00007154327d05ab  jmp 0x00007154327CF2E4
00007154327d05b0  call 0x00007154326C2240
00007154327d05b5  jmp 0x00007154327CF2F9
00007154327d05ba  call 0x00007154326C2240
00007154327d05bf  jmp 0x00007154327CF30C
00007154327d05c4  call 0x00007154326C2120
00007154327d05c9  jmp 0x00007154327CF319
00007154327d05ce  call 0x00007154326B52F0
00007154327d05d3  jmp 0x00007154327CF32C
00007154327d05d8  call 0x00007154326B52F0
00007154327d05dd  jmp 0x00007154327CF34F
00007154327d05e2  call 0x00007154326B52F0
00007154327d05e7  jmp 0x00007154327CF362
00007154327d05ec  call 0x00007154325FF540
00007154327d05f1  jmp 0x00007154327CF380
00007154327d05f6  call 0x0000715432608C20
00007154327d05fb  jmp 0x00007154327CF38A
00007154327d0600  call 0x00007154326D6600
00007154327d0605  jmp 0x00007154327CF396
00007154327d060a  call 0x00007154325FF540
00007154327d060f  jmp 0x00007154327CF3A6
00007154327d0614  call 0x00007154326C0370
00007154327d0619  jmp 0x00007154327CF3D4
00007154327d061e  call 0x00007154326BF100
00007154327d0623  jmp 0x00007154327CF3DD
00007154327d0628  call 0x00007154326C0370
00007154327d062d  jmp 0x00007154327CF43B
00007154327d0632  call 0x00007154326BF100
00007154327d0637  jmp 0x00007154327CF444
00007154327d063c  call 0x00007154326C0370
00007154327d0641  jmp 0x00007154327CF48B
00007154327d0646  call 0x00007154326BF100
00007154327d064b  jmp 0x00007154327CF494
00007154327d0650  call 0x000071543260B720
00007154327d0655  jmp 0x00007154327CF4D7
00007154327d065a  call 0x00007154326B47C0
00007154327d065f  jmp 0x00007154327CF4EA
00007154327d0664  call 0x0000715432608B00
00007154327d0669  jmp 0x00007154327CF501
00007154327d066e  call 0x00007154325FF430
00007154327d0673  jmp 0x00007154327CF514
00007154327d0678  call 0x00007154325FF430
00007154327d067d  jmp 0x00007154327CF527
00007154327d0682  sub rsp, 0x08
00007154327d0686  push rax
00007154327d0687  push rcx
00007154327d0688  push rdx
00007154327d0689  push rdi
00007154327d068a  push rsi
00007154327d068b  push r8
00007154327d068d  push r9
00007154327d068f  push r10
00007154327d0691  push r11
00007154327d0693  sub rsp, 0xF0
00007154327d069a  vmovaps [rsp], xmm0
00007154327d069f  vmovaps [rsp+0x10], xmm2
00007154327d06a5  vmovaps [rsp+0x20], xmm3
00007154327d06ab  vmovaps [rsp+0x30], xmm4
00007154327d06b1  vmovaps [rsp+0x40], xmm5
00007154327d06b7  vmovaps [rsp+0x50], xmm6
00007154327d06bd  vmovaps [rsp+0x60], xmm7
00007154327d06c3  vmovaps [rsp+0x70], xmm8
00007154327d06c9  vmovaps [rsp+0x80], xmm9
00007154327d06d2  vmovaps [rsp+0x90], xmm10
00007154327d06db  vmovaps [rsp+0xA0], xmm11
00007154327d06e4  vmovaps [rsp+0xB0], xmm12
00007154327d06ed  vmovaps [rsp+0xC0], xmm13
00007154327d06f6  vmovaps [rsp+0xD0], xmm14
00007154327d06ff  vmovaps [rsp+0xE0], xmm15
00007154327d0708  sub rsp, 0x30
00007154327d070c  movaps [rsp], xmm1
00007154327d0710  movaps [rsp+0x10], xmm15
00007154327d0716  movaps [rsp+0x20], xmm14
00007154327d071c  lea rdi, [rsp]
00007154327d0720  mov esi, 0x00
00007154327d0725  mov rax, 0x5A63B06A5530
00007154327d072f  call rax
00007154327d0731  movaps xmm1, [rsp]
00007154327d0735  add rsp, 0x30
00007154327d0739  vmovaps xmm0, [rsp]
00007154327d073e  vmovaps xmm2, [rsp+0x10]
00007154327d0744  vmovaps xmm3, [rsp+0x20]
00007154327d074a  vmovaps xmm4, [rsp+0x30]
00007154327d0750  vmovaps xmm5, [rsp+0x40]
00007154327d0756  vmovaps xmm6, [rsp+0x50]
00007154327d075c  vmovaps xmm7, [rsp+0x60]
00007154327d0762  vmovaps xmm8, [rsp+0x70]
00007154327d0768  vmovaps xmm9, [rsp+0x80]
00007154327d0771  vmovaps xmm10, [rsp+0x90]
00007154327d077a  vmovaps xmm11, [rsp+0xA0]
00007154327d0783  vmovaps xmm12, [rsp+0xB0]
00007154327d078c  vmovaps xmm13, [rsp+0xC0]
00007154327d0795  vmovaps xmm14, [rsp+0xD0]
00007154327d079e  vmovaps xmm15, [rsp+0xE0]
00007154327d07a7  add rsp, 0xF0
00007154327d07ae  pop r11
00007154327d07b0  pop r10
00007154327d07b2  pop r9
00007154327d07b4  pop r8
00007154327d07b6  pop rsi
00007154327d07b7  pop rdi
00007154327d07b8  pop rdx
00007154327d07b9  pop rcx
00007154327d07ba  pop rax
00007154327d07bb  add rsp, 0x08
00007154327d07bf  jmp 0x00007154327CF581
00007154327d07c4  sub rsp, 0x08
00007154327d07c8  push rax
00007154327d07c9  push rcx
00007154327d07ca  push rdx
00007154327d07cb  push rdi
00007154327d07cc  push rsi
00007154327d07cd  push r8
00007154327d07cf  push r9
00007154327d07d1  push r10
00007154327d07d3  push r11
00007154327d07d5  sub rsp, 0xF0
00007154327d07dc  vmovaps [rsp], xmm0
00007154327d07e1  vmovaps [rsp+0x10], xmm1
00007154327d07e7  vmovaps [rsp+0x20], xmm2
00007154327d07ed  vmovaps [rsp+0x30], xmm3
00007154327d07f3  vmovaps [rsp+0x40], xmm4
00007154327d07f9  vmovaps [rsp+0x50], xmm5
00007154327d07ff  vmovaps [rsp+0x60], xmm6
00007154327d0805  vmovaps [rsp+0x70], xmm7
00007154327d080b  vmovaps [rsp+0x80], xmm8
00007154327d0814  vmovaps [rsp+0x90], xmm9
00007154327d081d  vmovaps [rsp+0xA0], xmm10
00007154327d0826  vmovaps [rsp+0xB0], xmm11
00007154327d082f  vmovaps [rsp+0xC0], xmm12
00007154327d0838  vmovaps [rsp+0xD0], xmm14
00007154327d0841  vmovaps [rsp+0xE0], xmm15
00007154327d084a  sub rsp, 0x30
00007154327d084e  movaps [rsp], xmm13
00007154327d0853  movaps [rsp+0x10], xmm1
00007154327d0858  movaps [rsp+0x20], xmm14
00007154327d085e  lea rdi, [rsp]
00007154327d0862  mov esi, 0x00
00007154327d0867  mov rax, 0x5A63B06A5530
00007154327d0871  call rax
00007154327d0873  movaps xmm13, [rsp]
00007154327d0878  add rsp, 0x30
00007154327d087c  vmovaps xmm0, [rsp]
00007154327d0881  vmovaps xmm1, [rsp+0x10]
00007154327d0887  vmovaps xmm2, [rsp+0x20]
00007154327d088d  vmovaps xmm3, [rsp+0x30]
00007154327d0893  vmovaps xmm4, [rsp+0x40]
00007154327d0899  vmovaps xmm5, [rsp+0x50]
00007154327d089f  vmovaps xmm6, [rsp+0x60]
00007154327d08a5  vmovaps xmm7, [rsp+0x70]
00007154327d08ab  vmovaps xmm8, [rsp+0x80]
00007154327d08b4  vmovaps xmm9, [rsp+0x90]
00007154327d08bd  vmovaps xmm10, [rsp+0xA0]
00007154327d08c6  vmovaps xmm11, [rsp+0xB0]
00007154327d08cf  vmovaps xmm12, [rsp+0xC0]
00007154327d08d8  vmovaps xmm14, [rsp+0xD0]
00007154327d08e1  vmovaps xmm15, [rsp+0xE0]
00007154327d08ea  add rsp, 0xF0
00007154327d08f1  pop r11
00007154327d08f3  pop r10
00007154327d08f5  pop r9
00007154327d08f7  pop r8
00007154327d08f9  pop rsi
00007154327d08fa  pop rdi
00007154327d08fb  pop rdx
00007154327d08fc  pop rcx
00007154327d08fd  pop rax
00007154327d08fe  add rsp, 0x08
00007154327d0902  jmp 0x00007154327CF5CF
00007154327d0907  sub rsp, 0x08
00007154327d090b  push rax
00007154327d090c  push rcx
00007154327d090d  push rdx
00007154327d090e  push rdi
00007154327d090f  push rsi
00007154327d0910  push r8
00007154327d0912  push r9
00007154327d0914  push r10
00007154327d0916  push r11
00007154327d0918  sub rsp, 0xF0
00007154327d091f  vmovaps [rsp], xmm0
00007154327d0924  vmovaps [rsp+0x10], xmm1
00007154327d092a  vmovaps [rsp+0x20], xmm2
00007154327d0930  vmovaps [rsp+0x30], xmm3
00007154327d0936  vmovaps [rsp+0x40], xmm4
00007154327d093c  vmovaps [rsp+0x50], xmm5
00007154327d0942  vmovaps [rsp+0x60], xmm6
00007154327d0948  vmovaps [rsp+0x70], xmm7
00007154327d094e  vmovaps [rsp+0x80], xmm8
00007154327d0957  vmovaps [rsp+0x90], xmm9
00007154327d0960  vmovaps [rsp+0xA0], xmm10
00007154327d0969  vmovaps [rsp+0xB0], xmm11
00007154327d0972  vmovaps [rsp+0xC0], xmm12
00007154327d097b  vmovaps [rsp+0xD0], xmm13
00007154327d0984  vmovaps [rsp+0xE0], xmm14
00007154327d098d  sub rsp, 0x30
00007154327d0991  movaps [rsp], xmm15
00007154327d0996  movaps [rsp+0x10], xmm14
00007154327d099c  movaps [rsp+0x20], xmm1
00007154327d09a1  lea rdi, [rsp]
00007154327d09a5  mov esi, 0x00
00007154327d09aa  mov rax, 0x5A63B06A5530
00007154327d09b4  call rax
00007154327d09b6  movaps xmm15, [rsp]
00007154327d09bb  add rsp, 0x30
00007154327d09bf  vmovaps xmm0, [rsp]
00007154327d09c4  vmovaps xmm1, [rsp+0x10]
00007154327d09ca  vmovaps xmm2, [rsp+0x20]
00007154327d09d0  vmovaps xmm3, [rsp+0x30]
00007154327d09d6  vmovaps xmm4, [rsp+0x40]
00007154327d09dc  vmovaps xmm5, [rsp+0x50]
00007154327d09e2  vmovaps xmm6, [rsp+0x60]
00007154327d09e8  vmovaps xmm7, [rsp+0x70]
00007154327d09ee  vmovaps xmm8, [rsp+0x80]
00007154327d09f7  vmovaps xmm9, [rsp+0x90]
00007154327d0a00  vmovaps xmm10, [rsp+0xA0]
00007154327d0a09  vmovaps xmm11, [rsp+0xB0]
00007154327d0a12  vmovaps xmm12, [rsp+0xC0]
00007154327d0a1b  vmovaps xmm13, [rsp+0xD0]
00007154327d0a24  vmovaps xmm14, [rsp+0xE0]
00007154327d0a2d  add rsp, 0xF0
00007154327d0a34  pop r11
00007154327d0a36  pop r10
00007154327d0a38  pop r9
00007154327d0a3a  pop r8
00007154327d0a3c  pop rsi
00007154327d0a3d  pop rdi
00007154327d0a3e  pop rdx
00007154327d0a3f  pop rcx
00007154327d0a40  pop rax
00007154327d0a41  add rsp, 0x08
00007154327d0a45  jmp 0x00007154327CF617
00007154327d0a4a  sub rsp, 0x08
00007154327d0a4e  push rax
00007154327d0a4f  push rcx
00007154327d0a50  push rdx
00007154327d0a51  push rdi
00007154327d0a52  push rsi
00007154327d0a53  push r8
00007154327d0a55  push r9
00007154327d0a57  push r10
00007154327d0a59  push r11
00007154327d0a5b  sub rsp, 0xF0
00007154327d0a62  vmovaps [rsp], xmm0
00007154327d0a67  vmovaps [rsp+0x10], xmm2
00007154327d0a6d  vmovaps [rsp+0x20], xmm3
00007154327d0a73  vmovaps [rsp+0x30], xmm4
00007154327d0a79  vmovaps [rsp+0x40], xmm5
00007154327d0a7f  vmovaps [rsp+0x50], xmm6
00007154327d0a85  vmovaps [rsp+0x60], xmm7
00007154327d0a8b  vmovaps [rsp+0x70], xmm8
00007154327d0a91  vmovaps [rsp+0x80], xmm9
00007154327d0a9a  vmovaps [rsp+0x90], xmm10
00007154327d0aa3  vmovaps [rsp+0xA0], xmm11
00007154327d0aac  vmovaps [rsp+0xB0], xmm12
00007154327d0ab5  vmovaps [rsp+0xC0], xmm13
00007154327d0abe  vmovaps [rsp+0xD0], xmm14
00007154327d0ac7  vmovaps [rsp+0xE0], xmm15
00007154327d0ad0  sub rsp, 0x30
00007154327d0ad4  movaps [rsp], xmm1
00007154327d0ad8  movaps [rsp+0x10], xmm14
00007154327d0ade  movaps [rsp+0x20], xmm10
00007154327d0ae4  lea rdi, [rsp]
00007154327d0ae8  mov esi, 0x00
00007154327d0aed  mov rax, 0x5A63B06A5530
00007154327d0af7  call rax
00007154327d0af9  movaps xmm1, [rsp]
00007154327d0afd  add rsp, 0x30
00007154327d0b01  vmovaps xmm0, [rsp]
00007154327d0b06  vmovaps xmm2, [rsp+0x10]
00007154327d0b0c  vmovaps xmm3, [rsp+0x20]
00007154327d0b12  vmovaps xmm4, [rsp+0x30]
00007154327d0b18  vmovaps xmm5, [rsp+0x40]
00007154327d0b1e  vmovaps xmm6, [rsp+0x50]
00007154327d0b24  vmovaps xmm7, [rsp+0x60]
00007154327d0b2a  vmovaps xmm8, [rsp+0x70]
00007154327d0b30  vmovaps xmm9, [rsp+0x80]
00007154327d0b39  vmovaps xmm10, [rsp+0x90]
00007154327d0b42  vmovaps xmm11, [rsp+0xA0]
00007154327d0b4b  vmovaps xmm12, [rsp+0xB0]
00007154327d0b54  vmovaps xmm13, [rsp+0xC0]
00007154327d0b5d  vmovaps xmm14, [rsp+0xD0]
00007154327d0b66  vmovaps xmm15, [rsp+0xE0]
00007154327d0b6f  add rsp, 0xF0
00007154327d0b76  pop r11
00007154327d0b78  pop r10
00007154327d0b7a  pop r9
00007154327d0b7c  pop r8
00007154327d0b7e  pop rsi
00007154327d0b7f  pop rdi
00007154327d0b80  pop rdx
00007154327d0b81  pop rcx
00007154327d0b82  pop rax
00007154327d0b83  add rsp, 0x08
00007154327d0b87  jmp 0x00007154327CF631
00007154327d0b8c  sub rsp, 0x08
00007154327d0b90  push rax
00007154327d0b91  push rcx
00007154327d0b92  push rdx
00007154327d0b93  push rdi
00007154327d0b94  push rsi
00007154327d0b95  push r8
00007154327d0b97  push r9
00007154327d0b99  push r10
00007154327d0b9b  push r11
00007154327d0b9d  sub rsp, 0xF0
00007154327d0ba4  vmovaps [rsp], xmm0
00007154327d0ba9  vmovaps [rsp+0x10], xmm1
00007154327d0baf  vmovaps [rsp+0x20], xmm2
00007154327d0bb5  vmovaps [rsp+0x30], xmm3
00007154327d0bbb  vmovaps [rsp+0x40], xmm4
00007154327d0bc1  vmovaps [rsp+0x50], xmm5
00007154327d0bc7  vmovaps [rsp+0x60], xmm6
00007154327d0bcd  vmovaps [rsp+0x70], xmm7
00007154327d0bd3  vmovaps [rsp+0x80], xmm8
00007154327d0bdc  vmovaps [rsp+0x90], xmm9
00007154327d0be5  vmovaps [rsp+0xA0], xmm10
00007154327d0bee  vmovaps [rsp+0xB0], xmm11
00007154327d0bf7  vmovaps [rsp+0xC0], xmm12
00007154327d0c00  vmovaps [rsp+0xD0], xmm14
00007154327d0c09  vmovaps [rsp+0xE0], xmm15
00007154327d0c12  sub rsp, 0x30
00007154327d0c16  movaps [rsp], xmm13
00007154327d0c1b  movaps [rsp+0x10], xmm14
00007154327d0c21  movaps [rsp+0x20], xmm2
00007154327d0c26  lea rdi, [rsp]
00007154327d0c2a  mov esi, 0x00
00007154327d0c2f  mov rax, 0x5A63B06A5530
00007154327d0c39  call rax
00007154327d0c3b  movaps xmm13, [rsp]
00007154327d0c40  add rsp, 0x30
00007154327d0c44  vmovaps xmm0, [rsp]
00007154327d0c49  vmovaps xmm1, [rsp+0x10]
00007154327d0c4f  vmovaps xmm2, [rsp+0x20]
00007154327d0c55  vmovaps xmm3, [rsp+0x30]
00007154327d0c5b  vmovaps xmm4, [rsp+0x40]
00007154327d0c61  vmovaps xmm5, [rsp+0x50]
00007154327d0c67  vmovaps xmm6, [rsp+0x60]
00007154327d0c6d  vmovaps xmm7, [rsp+0x70]
00007154327d0c73  vmovaps xmm8, [rsp+0x80]
00007154327d0c7c  vmovaps xmm9, [rsp+0x90]
00007154327d0c85  vmovaps xmm10, [rsp+0xA0]
00007154327d0c8e  vmovaps xmm11, [rsp+0xB0]
00007154327d0c97  vmovaps xmm12, [rsp+0xC0]
00007154327d0ca0  vmovaps xmm14, [rsp+0xD0]
00007154327d0ca9  vmovaps xmm15, [rsp+0xE0]
00007154327d0cb2  add rsp, 0xF0
00007154327d0cb9  pop r11
00007154327d0cbb  pop r10
00007154327d0cbd  pop r9
00007154327d0cbf  pop r8
00007154327d0cc1  pop rsi
00007154327d0cc2  pop rdi
00007154327d0cc3  pop rdx
00007154327d0cc4  pop rcx
00007154327d0cc5  pop rax
00007154327d0cc6  add rsp, 0x08
00007154327d0cca  jmp 0x00007154327CF64C
00007154327d0ccf  sub rsp, 0x08
00007154327d0cd3  push rax
00007154327d0cd4  push rcx
00007154327d0cd5  push rdx
00007154327d0cd6  push rdi
00007154327d0cd7  push rsi
00007154327d0cd8  push r8
00007154327d0cda  push r9
00007154327d0cdc  push r10
00007154327d0cde  push r11
00007154327d0ce0  sub rsp, 0xF0
00007154327d0ce7  vmovaps [rsp], xmm0
00007154327d0cec  vmovaps [rsp+0x10], xmm2
00007154327d0cf2  vmovaps [rsp+0x20], xmm3
00007154327d0cf8  vmovaps [rsp+0x30], xmm4
00007154327d0cfe  vmovaps [rsp+0x40], xmm5
00007154327d0d04  vmovaps [rsp+0x50], xmm6
00007154327d0d0a  vmovaps [rsp+0x60], xmm7
00007154327d0d10  vmovaps [rsp+0x70], xmm8
00007154327d0d16  vmovaps [rsp+0x80], xmm9
00007154327d0d1f  vmovaps [rsp+0x90], xmm10
00007154327d0d28  vmovaps [rsp+0xA0], xmm11
00007154327d0d31  vmovaps [rsp+0xB0], xmm12
00007154327d0d3a  vmovaps [rsp+0xC0], xmm13
00007154327d0d43  vmovaps [rsp+0xD0], xmm14
00007154327d0d4c  vmovaps [rsp+0xE0], xmm15
00007154327d0d55  sub rsp, 0x30
00007154327d0d59  movaps [rsp], xmm1
00007154327d0d5d  movaps [rsp+0x10], xmm10
00007154327d0d63  movaps [rsp+0x20], xmm2
00007154327d0d68  lea rdi, [rsp]
00007154327d0d6c  mov esi, 0x00
00007154327d0d71  mov rax, 0x5A63B06A5530
00007154327d0d7b  call rax
00007154327d0d7d  movaps xmm1, [rsp]
00007154327d0d81  add rsp, 0x30
00007154327d0d85  vmovaps xmm0, [rsp]
00007154327d0d8a  vmovaps xmm2, [rsp+0x10]
00007154327d0d90  vmovaps xmm3, [rsp+0x20]
00007154327d0d96  vmovaps xmm4, [rsp+0x30]
00007154327d0d9c  vmovaps xmm5, [rsp+0x40]
00007154327d0da2  vmovaps xmm6, [rsp+0x50]
00007154327d0da8  vmovaps xmm7, [rsp+0x60]
00007154327d0dae  vmovaps xmm8, [rsp+0x70]
00007154327d0db4  vmovaps xmm9, [rsp+0x80]
00007154327d0dbd  vmovaps xmm10, [rsp+0x90]
00007154327d0dc6  vmovaps xmm11, [rsp+0xA0]
00007154327d0dcf  vmovaps xmm12, [rsp+0xB0]
00007154327d0dd8  vmovaps xmm13, [rsp+0xC0]
00007154327d0de1  vmovaps xmm14, [rsp+0xD0]
00007154327d0dea  vmovaps xmm15, [rsp+0xE0]
00007154327d0df3  add rsp, 0xF0
00007154327d0dfa  pop r11
00007154327d0dfc  pop r10
00007154327d0dfe  pop r9
00007154327d0e00  pop r8
00007154327d0e02  pop rsi
00007154327d0e03  pop rdi
00007154327d0e04  pop rdx
00007154327d0e05  pop rcx
00007154327d0e06  pop rax
00007154327d0e07  add rsp, 0x08
00007154327d0e0b  jmp 0x00007154327CF6B4
00007154327d0e10  sub rsp, 0x08
00007154327d0e14  push rax
00007154327d0e15  push rcx
00007154327d0e16  push rdx
00007154327d0e17  push rdi
00007154327d0e18  push rsi
00007154327d0e19  push r8
00007154327d0e1b  push r9
00007154327d0e1d  push r10
00007154327d0e1f  push r11
00007154327d0e21  sub rsp, 0xF0
00007154327d0e28  vmovaps [rsp], xmm0
00007154327d0e2d  vmovaps [rsp+0x10], xmm1
00007154327d0e33  vmovaps [rsp+0x20], xmm2
00007154327d0e39  vmovaps [rsp+0x30], xmm3
00007154327d0e3f  vmovaps [rsp+0x40], xmm4
00007154327d0e45  vmovaps [rsp+0x50], xmm5
00007154327d0e4b  vmovaps [rsp+0x60], xmm6
00007154327d0e51  vmovaps [rsp+0x70], xmm7
00007154327d0e57  vmovaps [rsp+0x80], xmm8
00007154327d0e60  vmovaps [rsp+0x90], xmm9
00007154327d0e69  vmovaps [rsp+0xA0], xmm10
00007154327d0e72  vmovaps [rsp+0xB0], xmm11
00007154327d0e7b  vmovaps [rsp+0xC0], xmm12
00007154327d0e84  vmovaps [rsp+0xD0], xmm13
00007154327d0e8d  vmovaps [rsp+0xE0], xmm14
00007154327d0e96  sub rsp, 0x30
00007154327d0e9a  movaps [rsp], xmm15
00007154327d0e9f  movaps [rsp+0x10], xmm10
00007154327d0ea5  movaps [rsp+0x20], xmm2
00007154327d0eaa  lea rdi, [rsp]
00007154327d0eae  mov esi, 0x00
00007154327d0eb3  mov rax, 0x5A63B06A5530
00007154327d0ebd  call rax
00007154327d0ebf  movaps xmm15, [rsp]
00007154327d0ec4  add rsp, 0x30
00007154327d0ec8  vmovaps xmm0, [rsp]
00007154327d0ecd  vmovaps xmm1, [rsp+0x10]
00007154327d0ed3  vmovaps xmm2, [rsp+0x20]
00007154327d0ed9  vmovaps xmm3, [rsp+0x30]
00007154327d0edf  vmovaps xmm4, [rsp+0x40]
00007154327d0ee5  vmovaps xmm5, [rsp+0x50]
00007154327d0eeb  vmovaps xmm6, [rsp+0x60]
00007154327d0ef1  vmovaps xmm7, [rsp+0x70]
00007154327d0ef7  vmovaps xmm8, [rsp+0x80]
00007154327d0f00  vmovaps xmm9, [rsp+0x90]
00007154327d0f09  vmovaps xmm10, [rsp+0xA0]
00007154327d0f12  vmovaps xmm11, [rsp+0xB0]
00007154327d0f1b  vmovaps xmm12, [rsp+0xC0]
00007154327d0f24  vmovaps xmm13, [rsp+0xD0]
00007154327d0f2d  vmovaps xmm14, [rsp+0xE0]
00007154327d0f36  add rsp, 0xF0
00007154327d0f3d  pop r11
00007154327d0f3f  pop r10
00007154327d0f41  pop r9
00007154327d0f43  pop r8
00007154327d0f45  pop rsi
00007154327d0f46  pop rdi
00007154327d0f47  pop rdx
00007154327d0f48  pop rcx
00007154327d0f49  pop rax
00007154327d0f4a  add rsp, 0x08
00007154327d0f4e  jmp 0x00007154327CF706
00007154327d0f53  sub rsp, 0x08
00007154327d0f57  push rax
00007154327d0f58  push rcx
00007154327d0f59  push rdx
00007154327d0f5a  push rdi
00007154327d0f5b  push rsi
00007154327d0f5c  push r8
00007154327d0f5e  push r9
00007154327d0f60  push r10
00007154327d0f62  push r11
00007154327d0f64  sub rsp, 0xF0
00007154327d0f6b  vmovaps [rsp], xmm0
00007154327d0f70  vmovaps [rsp+0x10], xmm2
00007154327d0f76  vmovaps [rsp+0x20], xmm3
00007154327d0f7c  vmovaps [rsp+0x30], xmm4
00007154327d0f82  vmovaps [rsp+0x40], xmm5
00007154327d0f88  vmovaps [rsp+0x50], xmm6
00007154327d0f8e  vmovaps [rsp+0x60], xmm7
00007154327d0f94  vmovaps [rsp+0x70], xmm8
00007154327d0f9a  vmovaps [rsp+0x80], xmm9
00007154327d0fa3  vmovaps [rsp+0x90], xmm10
00007154327d0fac  vmovaps [rsp+0xA0], xmm11
00007154327d0fb5  vmovaps [rsp+0xB0], xmm12
00007154327d0fbe  vmovaps [rsp+0xC0], xmm13
00007154327d0fc7  vmovaps [rsp+0xD0], xmm14
00007154327d0fd0  vmovaps [rsp+0xE0], xmm15
00007154327d0fd9  sub rsp, 0x30
00007154327d0fdd  movaps [rsp], xmm1
00007154327d0fe1  movaps [rsp+0x10], xmm10
00007154327d0fe7  movaps [rsp+0x20], xmm12
00007154327d0fed  lea rdi, [rsp]
00007154327d0ff1  mov esi, 0x00
00007154327d0ff6  mov rax, 0x5A63B06A5530
00007154327d1000  call rax
00007154327d1002  movaps xmm1, [rsp]
00007154327d1006  add rsp, 0x30
00007154327d100a  vmovaps xmm0, [rsp]
00007154327d100f  vmovaps xmm2, [rsp+0x10]
00007154327d1015  vmovaps xmm3, [rsp+0x20]
00007154327d101b  vmovaps xmm4, [rsp+0x30]
00007154327d1021  vmovaps xmm5, [rsp+0x40]
00007154327d1027  vmovaps xmm6, [rsp+0x50]
00007154327d102d  vmovaps xmm7, [rsp+0x60]
00007154327d1033  vmovaps xmm8, [rsp+0x70]
00007154327d1039  vmovaps xmm9, [rsp+0x80]
00007154327d1042  vmovaps xmm10, [rsp+0x90]
00007154327d104b  vmovaps xmm11, [rsp+0xA0]
00007154327d1054  vmovaps xmm12, [rsp+0xB0]
00007154327d105d  vmovaps xmm13, [rsp+0xC0]
00007154327d1066  vmovaps xmm14, [rsp+0xD0]
00007154327d106f  vmovaps xmm15, [rsp+0xE0]
00007154327d1078  add rsp, 0xF0
00007154327d107f  pop r11
00007154327d1081  pop r10
00007154327d1083  pop r9
00007154327d1085  pop r8
00007154327d1087  pop rsi
00007154327d1088  pop rdi
00007154327d1089  pop rdx
00007154327d108a  pop rcx
00007154327d108b  pop rax
00007154327d108c  add rsp, 0x08
00007154327d1090  jmp 0x00007154327CF732
00007154327d1095  sub rsp, 0x08
00007154327d1099  push rax
00007154327d109a  push rcx
00007154327d109b  push rdx
00007154327d109c  push rdi
00007154327d109d  push rsi
00007154327d109e  push r8
00007154327d10a0  push r9
00007154327d10a2  push r10
00007154327d10a4  push r11
00007154327d10a6  sub rsp, 0xF0
00007154327d10ad  vmovaps [rsp], xmm0
00007154327d10b2  vmovaps [rsp+0x10], xmm1
00007154327d10b8  vmovaps [rsp+0x20], xmm2
00007154327d10be  vmovaps [rsp+0x30], xmm3
00007154327d10c4  vmovaps [rsp+0x40], xmm4
00007154327d10ca  vmovaps [rsp+0x50], xmm5
00007154327d10d0  vmovaps [rsp+0x60], xmm6
00007154327d10d6  vmovaps [rsp+0x70], xmm7
00007154327d10dc  vmovaps [rsp+0x80], xmm8
00007154327d10e5  vmovaps [rsp+0x90], xmm9
00007154327d10ee  vmovaps [rsp+0xA0], xmm10
00007154327d10f7  vmovaps [rsp+0xB0], xmm11
00007154327d1100  vmovaps [rsp+0xC0], xmm12
00007154327d1109  vmovaps [rsp+0xD0], xmm13
00007154327d1112  vmovaps [rsp+0xE0], xmm14
00007154327d111b  sub rsp, 0x30
00007154327d111f  movaps [rsp], xmm15
00007154327d1124  movaps [rsp+0x10], xmm10
00007154327d112a  movaps [rsp+0x20], xmm12
00007154327d1130  lea rdi, [rsp]
00007154327d1134  mov esi, 0x00
00007154327d1139  mov rax, 0x5A63B06A5530
00007154327d1143  call rax
00007154327d1145  movaps xmm15, [rsp]
00007154327d114a  add rsp, 0x30
00007154327d114e  vmovaps xmm0, [rsp]
00007154327d1153  vmovaps xmm1, [rsp+0x10]
00007154327d1159  vmovaps xmm2, [rsp+0x20]
00007154327d115f  vmovaps xmm3, [rsp+0x30]
00007154327d1165  vmovaps xmm4, [rsp+0x40]
00007154327d116b  vmovaps xmm5, [rsp+0x50]
00007154327d1171  vmovaps xmm6, [rsp+0x60]
00007154327d1177  vmovaps xmm7, [rsp+0x70]
00007154327d117d  vmovaps xmm8, [rsp+0x80]
00007154327d1186  vmovaps xmm9, [rsp+0x90]
00007154327d118f  vmovaps xmm10, [rsp+0xA0]
00007154327d1198  vmovaps xmm11, [rsp+0xB0]
00007154327d11a1  vmovaps xmm12, [rsp+0xC0]
00007154327d11aa  vmovaps xmm13, [rsp+0xD0]
00007154327d11b3  vmovaps xmm14, [rsp+0xE0]
00007154327d11bc  add rsp, 0xF0
00007154327d11c3  pop r11
00007154327d11c5  pop r10
00007154327d11c7  pop r9
00007154327d11c9  pop r8
00007154327d11cb  pop rsi
00007154327d11cc  pop rdi
00007154327d11cd  pop rdx
00007154327d11ce  pop rcx
00007154327d11cf  pop rax
00007154327d11d0  add rsp, 0x08
00007154327d11d4  jmp 0x00007154327CF75E
00007154327d11d9  call 0x00007154325FF430
00007154327d11de  jmp 0x00007154327CF7EE
00007154327d11e3  call 0x00007154325FF430
00007154327d11e8  jmp 0x00007154327CF801
00007154327d11ed  sub rsp, 0x08
00007154327d11f1  push rax
00007154327d11f2  push rcx
00007154327d11f3  push rdx
00007154327d11f4  push rdi
00007154327d11f5  push rsi
00007154327d11f6  push r8
00007154327d11f8  push r9
00007154327d11fa  push r10
00007154327d11fc  push r11
00007154327d11fe  sub rsp, 0xF0
00007154327d1205  vmovaps [rsp], xmm0
00007154327d120a  vmovaps [rsp+0x10], xmm2
00007154327d1210  vmovaps [rsp+0x20], xmm3
00007154327d1216  vmovaps [rsp+0x30], xmm4
00007154327d121c  vmovaps [rsp+0x40], xmm5
00007154327d1222  vmovaps [rsp+0x50], xmm6
00007154327d1228  vmovaps [rsp+0x60], xmm7
00007154327d122e  vmovaps [rsp+0x70], xmm8
00007154327d1234  vmovaps [rsp+0x80], xmm9
00007154327d123d  vmovaps [rsp+0x90], xmm10
00007154327d1246  vmovaps [rsp+0xA0], xmm11
00007154327d124f  vmovaps [rsp+0xB0], xmm12
00007154327d1258  vmovaps [rsp+0xC0], xmm13
00007154327d1261  vmovaps [rsp+0xD0], xmm14
00007154327d126a  vmovaps [rsp+0xE0], xmm15
00007154327d1273  sub rsp, 0x30
00007154327d1277  movaps [rsp], xmm1
00007154327d127b  movaps [rsp+0x10], xmm13
00007154327d1281  movaps [rsp+0x20], xmm2
00007154327d1286  lea rdi, [rsp]
00007154327d128a  mov esi, 0x00
00007154327d128f  mov rax, 0x5A63B06A5530
00007154327d1299  call rax
00007154327d129b  movaps xmm1, [rsp]
00007154327d129f  add rsp, 0x30
00007154327d12a3  vmovaps xmm0, [rsp]
00007154327d12a8  vmovaps xmm2, [rsp+0x10]
00007154327d12ae  vmovaps xmm3, [rsp+0x20]
00007154327d12b4  vmovaps xmm4, [rsp+0x30]
00007154327d12ba  vmovaps xmm5, [rsp+0x40]
00007154327d12c0  vmovaps xmm6, [rsp+0x50]
00007154327d12c6  vmovaps xmm7, [rsp+0x60]
00007154327d12cc  vmovaps xmm8, [rsp+0x70]
00007154327d12d2  vmovaps xmm9, [rsp+0x80]
00007154327d12db  vmovaps xmm10, [rsp+0x90]
00007154327d12e4  vmovaps xmm11, [rsp+0xA0]
00007154327d12ed  vmovaps xmm12, [rsp+0xB0]
00007154327d12f6  vmovaps xmm13, [rsp+0xC0]
00007154327d12ff  vmovaps xmm14, [rsp+0xD0]
00007154327d1308  vmovaps xmm15, [rsp+0xE0]
00007154327d1311  add rsp, 0xF0
00007154327d1318  pop r11
00007154327d131a  pop r10
00007154327d131c  pop r9
00007154327d131e  pop r8
00007154327d1320  pop rsi
00007154327d1321  pop rdi
00007154327d1322  pop rdx
00007154327d1323  pop rcx
00007154327d1324  pop rax
00007154327d1325  add rsp, 0x08
00007154327d1329  jmp 0x00007154327CF82C
00007154327d132e  call 0x000071543260E760
00007154327d1333  jmp 0x00007154327CF839
00007154327d1338  sub rsp, 0x08
00007154327d133c  push rax
00007154327d133d  push rcx
00007154327d133e  push rdx
00007154327d133f  push rdi
00007154327d1340  push rsi
00007154327d1341  push r8
00007154327d1343  push r9
00007154327d1345  push r10
00007154327d1347  push r11
00007154327d1349  sub rsp, 0xF0
00007154327d1350  vmovaps [rsp], xmm0
00007154327d1355  vmovaps [rsp+0x10], xmm1
00007154327d135b  vmovaps [rsp+0x20], xmm2
00007154327d1361  vmovaps [rsp+0x30], xmm3
00007154327d1367  vmovaps [rsp+0x40], xmm4
00007154327d136d  vmovaps [rsp+0x50], xmm5
00007154327d1373  vmovaps [rsp+0x60], xmm6
00007154327d1379  vmovaps [rsp+0x70], xmm7
00007154327d137f  vmovaps [rsp+0x80], xmm8
00007154327d1388  vmovaps [rsp+0x90], xmm9
00007154327d1391  vmovaps [rsp+0xA0], xmm10
00007154327d139a  vmovaps [rsp+0xB0], xmm11
00007154327d13a3  vmovaps [rsp+0xC0], xmm12
00007154327d13ac  vmovaps [rsp+0xD0], xmm14
00007154327d13b5  vmovaps [rsp+0xE0], xmm15
00007154327d13be  sub rsp, 0x30
00007154327d13c2  movaps [rsp], xmm13
00007154327d13c7  movaps [rsp+0x10], xmm2
00007154327d13cc  movaps [rsp+0x20], xmm1
00007154327d13d1  lea rdi, [rsp]
00007154327d13d5  mov esi, 0x00
00007154327d13da  mov rax, 0x5A63B06A5530
00007154327d13e4  call rax
00007154327d13e6  movaps xmm13, [rsp]
00007154327d13eb  add rsp, 0x30
00007154327d13ef  vmovaps xmm0, [rsp]
00007154327d13f4  vmovaps xmm1, [rsp+0x10]
00007154327d13fa  vmovaps xmm2, [rsp+0x20]
00007154327d1400  vmovaps xmm3, [rsp+0x30]
00007154327d1406  vmovaps xmm4, [rsp+0x40]
00007154327d140c  vmovaps xmm5, [rsp+0x50]
00007154327d1412  vmovaps xmm6, [rsp+0x60]
00007154327d1418  vmovaps xmm7, [rsp+0x70]
00007154327d141e  vmovaps xmm8, [rsp+0x80]
00007154327d1427  vmovaps xmm9, [rsp+0x90]
00007154327d1430  vmovaps xmm10, [rsp+0xA0]
00007154327d1439  vmovaps xmm11, [rsp+0xB0]
00007154327d1442  vmovaps xmm12, [rsp+0xC0]
00007154327d144b  vmovaps xmm14, [rsp+0xD0]
00007154327d1454  vmovaps xmm15, [rsp+0xE0]
00007154327d145d  add rsp, 0xF0
00007154327d1464  pop r11
00007154327d1466  pop r10
00007154327d1468  pop r9
00007154327d146a  pop r8
00007154327d146c  pop rsi
00007154327d146d  pop rdi
00007154327d146e  pop rdx
00007154327d146f  pop rcx
00007154327d1470  pop rax
00007154327d1471  add rsp, 0x08
00007154327d1475  jmp 0x00007154327CF878
00007154327d147a  sub rsp, 0x08
00007154327d147e  push rax
00007154327d147f  push rcx
00007154327d1480  push rdx
00007154327d1481  push rdi
00007154327d1482  push rsi
00007154327d1483  push r8
00007154327d1485  push r9
00007154327d1487  push r10
00007154327d1489  push r11
00007154327d148b  sub rsp, 0xF0
00007154327d1492  vmovaps [rsp], xmm0
00007154327d1497  vmovaps [rsp+0x10], xmm2
00007154327d149d  vmovaps [rsp+0x20], xmm3
00007154327d14a3  vmovaps [rsp+0x30], xmm4
00007154327d14a9  vmovaps [rsp+0x40], xmm5
00007154327d14af  vmovaps [rsp+0x50], xmm6
00007154327d14b5  vmovaps [rsp+0x60], xmm7
00007154327d14bb  vmovaps [rsp+0x70], xmm8
00007154327d14c1  vmovaps [rsp+0x80], xmm9
00007154327d14ca  vmovaps [rsp+0x90], xmm10
00007154327d14d3  vmovaps [rsp+0xA0], xmm11
00007154327d14dc  vmovaps [rsp+0xB0], xmm12
00007154327d14e5  vmovaps [rsp+0xC0], xmm13
00007154327d14ee  vmovaps [rsp+0xD0], xmm14
00007154327d14f7  vmovaps [rsp+0xE0], xmm15
00007154327d1500  sub rsp, 0x30
00007154327d1504  movaps [rsp], xmm1
00007154327d1508  movaps [rsp+0x10], xmm15
00007154327d150e  movaps [rsp+0x20], xmm2
00007154327d1513  lea rdi, [rsp]
00007154327d1517  mov esi, 0x00
00007154327d151c  mov rax, 0x5A63B06A5530
00007154327d1526  call rax
00007154327d1528  movaps xmm1, [rsp]
00007154327d152c  add rsp, 0x30
00007154327d1530  vmovaps xmm0, [rsp]
00007154327d1535  vmovaps xmm2, [rsp+0x10]
00007154327d153b  vmovaps xmm3, [rsp+0x20]
00007154327d1541  vmovaps xmm4, [rsp+0x30]
00007154327d1547  vmovaps xmm5, [rsp+0x40]
00007154327d154d  vmovaps xmm6, [rsp+0x50]
00007154327d1553  vmovaps xmm7, [rsp+0x60]
00007154327d1559  vmovaps xmm8, [rsp+0x70]
00007154327d155f  vmovaps xmm9, [rsp+0x80]
00007154327d1568  vmovaps xmm10, [rsp+0x90]
00007154327d1571  vmovaps xmm11, [rsp+0xA0]
00007154327d157a  vmovaps xmm12, [rsp+0xB0]
00007154327d1583  vmovaps xmm13, [rsp+0xC0]
00007154327d158c  vmovaps xmm14, [rsp+0xD0]
00007154327d1595  vmovaps xmm15, [rsp+0xE0]
00007154327d159e  add rsp, 0xF0
00007154327d15a5  pop r11
00007154327d15a7  pop r10
00007154327d15a9  pop r9
00007154327d15ab  pop r8
00007154327d15ad  pop rsi
00007154327d15ae  pop rdi
00007154327d15af  pop rdx
00007154327d15b0  pop rcx
00007154327d15b1  pop rax
00007154327d15b2  add rsp, 0x08
00007154327d15b6  jmp 0x00007154327CF8AC
00007154327d15bb  sub rsp, 0x08
00007154327d15bf  push rax
00007154327d15c0  push rcx
00007154327d15c1  push rdx
00007154327d15c2  push rdi
00007154327d15c3  push rsi
00007154327d15c4  push r8
00007154327d15c6  push r9
00007154327d15c8  push r10
00007154327d15ca  push r11
00007154327d15cc  sub rsp, 0xF0
00007154327d15d3  vmovaps [rsp], xmm0
00007154327d15d8  vmovaps [rsp+0x10], xmm1
00007154327d15de  vmovaps [rsp+0x20], xmm2
00007154327d15e4  vmovaps [rsp+0x30], xmm3
00007154327d15ea  vmovaps [rsp+0x40], xmm4
00007154327d15f0  vmovaps [rsp+0x50], xmm5
00007154327d15f6  vmovaps [rsp+0x60], xmm6
00007154327d15fc  vmovaps [rsp+0x70], xmm7
00007154327d1602  vmovaps [rsp+0x80], xmm8
00007154327d160b  vmovaps [rsp+0x90], xmm9
00007154327d1614  vmovaps [rsp+0xA0], xmm10
00007154327d161d  vmovaps [rsp+0xB0], xmm11
00007154327d1626  vmovaps [rsp+0xC0], xmm12
00007154327d162f  vmovaps [rsp+0xD0], xmm13
00007154327d1638  vmovaps [rsp+0xE0], xmm15
00007154327d1641  sub rsp, 0x30
00007154327d1645  movaps [rsp], xmm14
00007154327d164a  movaps [rsp+0x10], xmm2
00007154327d164f  movaps [rsp+0x20], xmm15
00007154327d1655  lea rdi, [rsp]
00007154327d1659  mov esi, 0x00
00007154327d165e  mov rax, 0x5A63B06A5530
00007154327d1668  call rax
00007154327d166a  movaps xmm14, [rsp]
00007154327d166f  add rsp, 0x30
00007154327d1673  vmovaps xmm0, [rsp]
00007154327d1678  vmovaps xmm1, [rsp+0x10]
00007154327d167e  vmovaps xmm2, [rsp+0x20]
00007154327d1684  vmovaps xmm3, [rsp+0x30]
00007154327d168a  vmovaps xmm4, [rsp+0x40]
00007154327d1690  vmovaps xmm5, [rsp+0x50]
00007154327d1696  vmovaps xmm6, [rsp+0x60]
00007154327d169c  vmovaps xmm7, [rsp+0x70]
00007154327d16a2  vmovaps xmm8, [rsp+0x80]
00007154327d16ab  vmovaps xmm9, [rsp+0x90]
00007154327d16b4  vmovaps xmm10, [rsp+0xA0]
00007154327d16bd  vmovaps xmm11, [rsp+0xB0]
00007154327d16c6  vmovaps xmm12, [rsp+0xC0]
00007154327d16cf  vmovaps xmm13, [rsp+0xD0]
00007154327d16d8  vmovaps xmm15, [rsp+0xE0]
00007154327d16e1  add rsp, 0xF0
00007154327d16e8  pop r11
00007154327d16ea  pop r10
00007154327d16ec  pop r9
00007154327d16ee  pop r8
00007154327d16f0  pop rsi
00007154327d16f1  pop rdi
00007154327d16f2  pop rdx
00007154327d16f3  pop rcx
00007154327d16f4  pop rax
00007154327d16f5  add rsp, 0x08
00007154327d16f9  jmp 0x00007154327CF8E7
00007154327d16fe  sub rsp, 0x08
00007154327d1702  push rax
00007154327d1703  push rcx
00007154327d1704  push rdx
00007154327d1705  push rdi
00007154327d1706  push rsi
00007154327d1707  push r8
00007154327d1709  push r9
00007154327d170b  push r10
00007154327d170d  push r11
00007154327d170f  sub rsp, 0xF0
00007154327d1716  vmovaps [rsp], xmm0
00007154327d171b  vmovaps [rsp+0x10], xmm1
00007154327d1721  vmovaps [rsp+0x20], xmm2
00007154327d1727  vmovaps [rsp+0x30], xmm3
00007154327d172d  vmovaps [rsp+0x40], xmm4
00007154327d1733  vmovaps [rsp+0x50], xmm5
00007154327d1739  vmovaps [rsp+0x60], xmm6
00007154327d173f  vmovaps [rsp+0x70], xmm7
00007154327d1745  vmovaps [rsp+0x80], xmm8
00007154327d174e  vmovaps [rsp+0x90], xmm9
00007154327d1757  vmovaps [rsp+0xA0], xmm10
00007154327d1760  vmovaps [rsp+0xB0], xmm11
00007154327d1769  vmovaps [rsp+0xC0], xmm12
00007154327d1772  vmovaps [rsp+0xD0], xmm13
00007154327d177b  vmovaps [rsp+0xE0], xmm14
00007154327d1784  sub rsp, 0x30
00007154327d1788  movaps [rsp], xmm15
00007154327d178d  movaps [rsp+0x10], xmm2
00007154327d1792  movaps [rsp+0x20], xmm1
00007154327d1797  lea rdi, [rsp]
00007154327d179b  mov esi, 0x00
00007154327d17a0  mov rax, 0x5A63B06A5530
00007154327d17aa  call rax
00007154327d17ac  movaps xmm15, [rsp]
00007154327d17b1  add rsp, 0x30
00007154327d17b5  vmovaps xmm0, [rsp]
00007154327d17ba  vmovaps xmm1, [rsp+0x10]
00007154327d17c0  vmovaps xmm2, [rsp+0x20]
00007154327d17c6  vmovaps xmm3, [rsp+0x30]
00007154327d17cc  vmovaps xmm4, [rsp+0x40]
00007154327d17d2  vmovaps xmm5, [rsp+0x50]
00007154327d17d8  vmovaps xmm6, [rsp+0x60]
00007154327d17de  vmovaps xmm7, [rsp+0x70]
00007154327d17e4  vmovaps xmm8, [rsp+0x80]
00007154327d17ed  vmovaps xmm9, [rsp+0x90]
00007154327d17f6  vmovaps xmm10, [rsp+0xA0]
00007154327d17ff  vmovaps xmm11, [rsp+0xB0]
00007154327d1808  vmovaps xmm12, [rsp+0xC0]
00007154327d1811  vmovaps xmm13, [rsp+0xD0]
00007154327d181a  vmovaps xmm14, [rsp+0xE0]
00007154327d1823  add rsp, 0xF0
00007154327d182a  pop r11
00007154327d182c  pop r10
00007154327d182e  pop r9
00007154327d1830  pop r8
00007154327d1832  pop rsi
00007154327d1833  pop rdi
00007154327d1834  pop rdx
00007154327d1835  pop rcx
00007154327d1836  pop rax
00007154327d1837  add rsp, 0x08
00007154327d183b  jmp 0x00007154327CF923
00007154327d1840  call 0x00007154325FF430
00007154327d1845  jmp 0x00007154327CF930
00007154327d184a  sub rsp, 0x08
00007154327d184e  push rax
00007154327d184f  push rcx
00007154327d1850  push rdx
00007154327d1851  push rdi
00007154327d1852  push rsi
00007154327d1853  push r8
00007154327d1855  push r9
00007154327d1857  push r10
00007154327d1859  push r11
00007154327d185b  sub rsp, 0xF0
00007154327d1862  vmovaps [rsp], xmm0
00007154327d1867  vmovaps [rsp+0x10], xmm1
00007154327d186d  vmovaps [rsp+0x20], xmm3
00007154327d1873  vmovaps [rsp+0x30], xmm4
00007154327d1879  vmovaps [rsp+0x40], xmm5
00007154327d187f  vmovaps [rsp+0x50], xmm6
00007154327d1885  vmovaps [rsp+0x60], xmm7
00007154327d188b  vmovaps [rsp+0x70], xmm8
00007154327d1891  vmovaps [rsp+0x80], xmm9
00007154327d189a  vmovaps [rsp+0x90], xmm10
00007154327d18a3  vmovaps [rsp+0xA0], xmm11
00007154327d18ac  vmovaps [rsp+0xB0], xmm12
00007154327d18b5  vmovaps [rsp+0xC0], xmm13
00007154327d18be  vmovaps [rsp+0xD0], xmm14
00007154327d18c7  vmovaps [rsp+0xE0], xmm15
00007154327d18d0  sub rsp, 0x30
00007154327d18d4  movaps [rsp], xmm2
00007154327d18d8  movaps [rsp+0x10], xmm1
00007154327d18dd  movaps [rsp+0x20], xmm14
00007154327d18e3  lea rdi, [rsp]
00007154327d18e7  mov esi, 0x00
00007154327d18ec  mov rax, 0x5A63B06A5530
00007154327d18f6  call rax
00007154327d18f8  movaps xmm2, [rsp]
00007154327d18fc  add rsp, 0x30
00007154327d1900  vmovaps xmm0, [rsp]
00007154327d1905  vmovaps xmm1, [rsp+0x10]
00007154327d190b  vmovaps xmm3, [rsp+0x20]
00007154327d1911  vmovaps xmm4, [rsp+0x30]
00007154327d1917  vmovaps xmm5, [rsp+0x40]
00007154327d191d  vmovaps xmm6, [rsp+0x50]
00007154327d1923  vmovaps xmm7, [rsp+0x60]
00007154327d1929  vmovaps xmm8, [rsp+0x70]
00007154327d192f  vmovaps xmm9, [rsp+0x80]
00007154327d1938  vmovaps xmm10, [rsp+0x90]
00007154327d1941  vmovaps xmm11, [rsp+0xA0]
00007154327d194a  vmovaps xmm12, [rsp+0xB0]
00007154327d1953  vmovaps xmm13, [rsp+0xC0]
00007154327d195c  vmovaps xmm14, [rsp+0xD0]
00007154327d1965  vmovaps xmm15, [rsp+0xE0]
00007154327d196e  add rsp, 0xF0
00007154327d1975  pop r11
00007154327d1977  pop r10
00007154327d1979  pop r9
00007154327d197b  pop r8
00007154327d197d  pop rsi
00007154327d197e  pop rdi
00007154327d197f  pop rdx
00007154327d1980  pop rcx
00007154327d1981  pop rax
00007154327d1982  add rsp, 0x08
00007154327d1986  jmp 0x00007154327CF96D
00007154327d198b  sub rsp, 0x08
00007154327d198f  push rax
00007154327d1990  push rcx
00007154327d1991  push rdx
00007154327d1992  push rdi
00007154327d1993  push rsi
00007154327d1994  push r8
00007154327d1996  push r9
00007154327d1998  push r10
00007154327d199a  push r11
00007154327d199c  sub rsp, 0xF0
00007154327d19a3  vmovaps [rsp], xmm0
00007154327d19a8  vmovaps [rsp+0x10], xmm1
00007154327d19ae  vmovaps [rsp+0x20], xmm2
00007154327d19b4  vmovaps [rsp+0x30], xmm3
00007154327d19ba  vmovaps [rsp+0x40], xmm4
00007154327d19c0  vmovaps [rsp+0x50], xmm5
00007154327d19c6  vmovaps [rsp+0x60], xmm6
00007154327d19cc  vmovaps [rsp+0x70], xmm7
00007154327d19d2  vmovaps [rsp+0x80], xmm8
00007154327d19db  vmovaps [rsp+0x90], xmm9
00007154327d19e4  vmovaps [rsp+0xA0], xmm10
00007154327d19ed  vmovaps [rsp+0xB0], xmm11
00007154327d19f6  vmovaps [rsp+0xC0], xmm12
00007154327d19ff  vmovaps [rsp+0xD0], xmm13
00007154327d1a08  vmovaps [rsp+0xE0], xmm14
00007154327d1a11  sub rsp, 0x30
00007154327d1a15  movaps [rsp], xmm15
00007154327d1a1a  movaps [rsp+0x10], xmm14
00007154327d1a20  movaps [rsp+0x20], xmm1
00007154327d1a25  lea rdi, [rsp]
00007154327d1a29  mov esi, 0x00
00007154327d1a2e  mov rax, 0x5A63B06A5530
00007154327d1a38  call rax
00007154327d1a3a  movaps xmm15, [rsp]
00007154327d1a3f  add rsp, 0x30
00007154327d1a43  vmovaps xmm0, [rsp]
00007154327d1a48  vmovaps xmm1, [rsp+0x10]
00007154327d1a4e  vmovaps xmm2, [rsp+0x20]
00007154327d1a54  vmovaps xmm3, [rsp+0x30]
00007154327d1a5a  vmovaps xmm4, [rsp+0x40]
00007154327d1a60  vmovaps xmm5, [rsp+0x50]
00007154327d1a66  vmovaps xmm6, [rsp+0x60]
00007154327d1a6c  vmovaps xmm7, [rsp+0x70]
00007154327d1a72  vmovaps xmm8, [rsp+0x80]
00007154327d1a7b  vmovaps xmm9, [rsp+0x90]
00007154327d1a84  vmovaps xmm10, [rsp+0xA0]
00007154327d1a8d  vmovaps xmm11, [rsp+0xB0]
00007154327d1a96  vmovaps xmm12, [rsp+0xC0]
00007154327d1a9f  vmovaps xmm13, [rsp+0xD0]
00007154327d1aa8  vmovaps xmm14, [rsp+0xE0]
00007154327d1ab1  add rsp, 0xF0
00007154327d1ab8  pop r11
00007154327d1aba  pop r10
00007154327d1abc  pop r9
00007154327d1abe  pop r8
00007154327d1ac0  pop rsi
00007154327d1ac1  pop rdi
00007154327d1ac2  pop rdx
00007154327d1ac3  pop rcx
00007154327d1ac4  pop rax
00007154327d1ac5  add rsp, 0x08
00007154327d1ac9  jmp 0x00007154327CF9E7
00007154327d1ace  call 0x00007154325FF430
00007154327d1ad3  jmp 0x00007154327CF9F4
00007154327d1ad8  sub rsp, 0x08
00007154327d1adc  push rax
00007154327d1add  push rcx
00007154327d1ade  push rdx
00007154327d1adf  push rdi
00007154327d1ae0  push rsi
00007154327d1ae1  push r8
00007154327d1ae3  push r9
00007154327d1ae5  push r10
00007154327d1ae7  push r11
00007154327d1ae9  sub rsp, 0xF0
00007154327d1af0  vmovaps [rsp], xmm0
00007154327d1af5  vmovaps [rsp+0x10], xmm1
00007154327d1afb  vmovaps [rsp+0x20], xmm2
00007154327d1b01  vmovaps [rsp+0x30], xmm3
00007154327d1b07  vmovaps [rsp+0x40], xmm4
00007154327d1b0d  vmovaps [rsp+0x50], xmm5
00007154327d1b13  vmovaps [rsp+0x60], xmm6
00007154327d1b19  vmovaps [rsp+0x70], xmm7
00007154327d1b1f  vmovaps [rsp+0x80], xmm8
00007154327d1b28  vmovaps [rsp+0x90], xmm9
00007154327d1b31  vmovaps [rsp+0xA0], xmm10
00007154327d1b3a  vmovaps [rsp+0xB0], xmm11
00007154327d1b43  vmovaps [rsp+0xC0], xmm12
00007154327d1b4c  vmovaps [rsp+0xD0], xmm13
00007154327d1b55  vmovaps [rsp+0xE0], xmm15
00007154327d1b5e  sub rsp, 0x30
00007154327d1b62  movaps [rsp], xmm14
00007154327d1b67  movaps [rsp+0x10], xmm13
00007154327d1b6d  movaps [rsp+0x20], xmm1
00007154327d1b72  lea rdi, [rsp]
00007154327d1b76  mov esi, 0x00
00007154327d1b7b  mov rax, 0x5A63B06A5530
00007154327d1b85  call rax
00007154327d1b87  movaps xmm14, [rsp]
00007154327d1b8c  add rsp, 0x30
00007154327d1b90  vmovaps xmm0, [rsp]
00007154327d1b95  vmovaps xmm1, [rsp+0x10]
00007154327d1b9b  vmovaps xmm2, [rsp+0x20]
00007154327d1ba1  vmovaps xmm3, [rsp+0x30]
00007154327d1ba7  vmovaps xmm4, [rsp+0x40]
00007154327d1bad  vmovaps xmm5, [rsp+0x50]
00007154327d1bb3  vmovaps xmm6, [rsp+0x60]
00007154327d1bb9  vmovaps xmm7, [rsp+0x70]
00007154327d1bbf  vmovaps xmm8, [rsp+0x80]
00007154327d1bc8  vmovaps xmm9, [rsp+0x90]
00007154327d1bd1  vmovaps xmm10, [rsp+0xA0]
00007154327d1bda  vmovaps xmm11, [rsp+0xB0]
00007154327d1be3  vmovaps xmm12, [rsp+0xC0]
00007154327d1bec  vmovaps xmm13, [rsp+0xD0]
00007154327d1bf5  vmovaps xmm15, [rsp+0xE0]
00007154327d1bfe  add rsp, 0xF0
00007154327d1c05  pop r11
00007154327d1c07  pop r10
00007154327d1c09  pop r9
00007154327d1c0b  pop r8
00007154327d1c0d  pop rsi
00007154327d1c0e  pop rdi
00007154327d1c0f  pop rdx
00007154327d1c10  pop rcx
00007154327d1c11  pop rax
00007154327d1c12  add rsp, 0x08
00007154327d1c16  jmp 0x00007154327CFAAF
00007154327d1c1b  sub rsp, 0x08
00007154327d1c1f  push rax
00007154327d1c20  push rcx
00007154327d1c21  push rdx
00007154327d1c22  push rdi
00007154327d1c23  push rsi
00007154327d1c24  push r8
00007154327d1c26  push r9
00007154327d1c28  push r10
00007154327d1c2a  push r11
00007154327d1c2c  sub rsp, 0xF0
00007154327d1c33  vmovaps [rsp], xmm0
00007154327d1c38  vmovaps [rsp+0x10], xmm1
00007154327d1c3e  vmovaps [rsp+0x20], xmm2
00007154327d1c44  vmovaps [rsp+0x30], xmm3
00007154327d1c4a  vmovaps [rsp+0x40], xmm4
00007154327d1c50  vmovaps [rsp+0x50], xmm5
00007154327d1c56  vmovaps [rsp+0x60], xmm6
00007154327d1c5c  vmovaps [rsp+0x70], xmm7
00007154327d1c62  vmovaps [rsp+0x80], xmm8
00007154327d1c6b  vmovaps [rsp+0x90], xmm9
00007154327d1c74  vmovaps [rsp+0xA0], xmm10
00007154327d1c7d  vmovaps [rsp+0xB0], xmm11
00007154327d1c86  vmovaps [rsp+0xC0], xmm12
00007154327d1c8f  vmovaps [rsp+0xD0], xmm13
00007154327d1c98  vmovaps [rsp+0xE0], xmm14
00007154327d1ca1  sub rsp, 0x30
00007154327d1ca5  movaps [rsp], xmm15
00007154327d1caa  movaps [rsp+0x10], xmm13
00007154327d1cb0  movaps [rsp+0x20], xmm1
00007154327d1cb5  lea rdi, [rsp]
00007154327d1cb9  mov esi, 0x00
00007154327d1cbe  mov rax, 0x5A63B06A5530
00007154327d1cc8  call rax
00007154327d1cca  movaps xmm15, [rsp]
00007154327d1ccf  add rsp, 0x30
00007154327d1cd3  vmovaps xmm0, [rsp]
00007154327d1cd8  vmovaps xmm1, [rsp+0x10]
00007154327d1cde  vmovaps xmm2, [rsp+0x20]
00007154327d1ce4  vmovaps xmm3, [rsp+0x30]
00007154327d1cea  vmovaps xmm4, [rsp+0x40]
00007154327d1cf0  vmovaps xmm5, [rsp+0x50]
00007154327d1cf6  vmovaps xmm6, [rsp+0x60]
00007154327d1cfc  vmovaps xmm7, [rsp+0x70]
00007154327d1d02  vmovaps xmm8, [rsp+0x80]
00007154327d1d0b  vmovaps xmm9, [rsp+0x90]
00007154327d1d14  vmovaps xmm10, [rsp+0xA0]
00007154327d1d1d  vmovaps xmm11, [rsp+0xB0]
00007154327d1d26  vmovaps xmm12, [rsp+0xC0]
00007154327d1d2f  vmovaps xmm13, [rsp+0xD0]
00007154327d1d38  vmovaps xmm14, [rsp+0xE0]
00007154327d1d41  add rsp, 0xF0
00007154327d1d48  pop r11
00007154327d1d4a  pop r10
00007154327d1d4c  pop r9
00007154327d1d4e  pop r8
00007154327d1d50  pop rsi
00007154327d1d51  pop rdi
00007154327d1d52  pop rdx
00007154327d1d53  pop rcx
00007154327d1d54  pop rax
00007154327d1d55  add rsp, 0x08
00007154327d1d59  jmp 0x00007154327CFAEB
00007154327d1d5e  call 0x00007154325FF430
00007154327d1d63  jmp 0x00007154327CFAF8
00007154327d1d68  sub rsp, 0x08
00007154327d1d6c  push rax
00007154327d1d6d  push rcx
00007154327d1d6e  push rdx
00007154327d1d6f  push rdi
00007154327d1d70  push rsi
00007154327d1d71  push r8
00007154327d1d73  push r9
00007154327d1d75  push r10
00007154327d1d77  push r11
00007154327d1d79  sub rsp, 0xF0
00007154327d1d80  vmovaps [rsp], xmm0
00007154327d1d85  vmovaps [rsp+0x10], xmm1
00007154327d1d8b  vmovaps [rsp+0x20], xmm2
00007154327d1d91  vmovaps [rsp+0x30], xmm3
00007154327d1d97  vmovaps [rsp+0x40], xmm4
00007154327d1d9d  vmovaps [rsp+0x50], xmm5
00007154327d1da3  vmovaps [rsp+0x60], xmm6
00007154327d1da9  vmovaps [rsp+0x70], xmm7
00007154327d1daf  vmovaps [rsp+0x80], xmm8
00007154327d1db8  vmovaps [rsp+0x90], xmm9
00007154327d1dc1  vmovaps [rsp+0xA0], xmm10
00007154327d1dca  vmovaps [rsp+0xB0], xmm11
00007154327d1dd3  vmovaps [rsp+0xC0], xmm12
00007154327d1ddc  vmovaps [rsp+0xD0], xmm13
00007154327d1de5  vmovaps [rsp+0xE0], xmm15
00007154327d1dee  sub rsp, 0x30
00007154327d1df2  movaps [rsp], xmm14
00007154327d1df7  movaps [rsp+0x10], xmm13
00007154327d1dfd  movaps [rsp+0x20], xmm2
00007154327d1e02  lea rdi, [rsp]
00007154327d1e06  mov esi, 0x00
00007154327d1e0b  mov rax, 0x5A63B06A5530
00007154327d1e15  call rax
00007154327d1e17  movaps xmm14, [rsp]
00007154327d1e1c  add rsp, 0x30
00007154327d1e20  vmovaps xmm0, [rsp]
00007154327d1e25  vmovaps xmm1, [rsp+0x10]
00007154327d1e2b  vmovaps xmm2, [rsp+0x20]
00007154327d1e31  vmovaps xmm3, [rsp+0x30]
00007154327d1e37  vmovaps xmm4, [rsp+0x40]
00007154327d1e3d  vmovaps xmm5, [rsp+0x50]
00007154327d1e43  vmovaps xmm6, [rsp+0x60]
00007154327d1e49  vmovaps xmm7, [rsp+0x70]
00007154327d1e4f  vmovaps xmm8, [rsp+0x80]
00007154327d1e58  vmovaps xmm9, [rsp+0x90]
00007154327d1e61  vmovaps xmm10, [rsp+0xA0]
00007154327d1e6a  vmovaps xmm11, [rsp+0xB0]
00007154327d1e73  vmovaps xmm12, [rsp+0xC0]
00007154327d1e7c  vmovaps xmm13, [rsp+0xD0]
00007154327d1e85  vmovaps xmm15, [rsp+0xE0]
00007154327d1e8e  add rsp, 0xF0
00007154327d1e95  pop r11
00007154327d1e97  pop r10
00007154327d1e99  pop r9
00007154327d1e9b  pop r8
00007154327d1e9d  pop rsi
00007154327d1e9e  pop rdi
00007154327d1e9f  pop rdx
00007154327d1ea0  pop rcx
00007154327d1ea1  pop rax
00007154327d1ea2  add rsp, 0x08
00007154327d1ea6  jmp 0x00007154327CFB24
00007154327d1eab  sub rsp, 0x08
00007154327d1eaf  push rax
00007154327d1eb0  push rcx
00007154327d1eb1  push rdx
00007154327d1eb2  push rdi
00007154327d1eb3  push rsi
00007154327d1eb4  push r8
00007154327d1eb6  push r9
00007154327d1eb8  push r10
00007154327d1eba  push r11
00007154327d1ebc  sub rsp, 0xF0
00007154327d1ec3  vmovaps [rsp], xmm0
00007154327d1ec8  vmovaps [rsp+0x10], xmm2
00007154327d1ece  vmovaps [rsp+0x20], xmm3
00007154327d1ed4  vmovaps [rsp+0x30], xmm4
00007154327d1eda  vmovaps [rsp+0x40], xmm5
00007154327d1ee0  vmovaps [rsp+0x50], xmm6
00007154327d1ee6  vmovaps [rsp+0x60], xmm7
00007154327d1eec  vmovaps [rsp+0x70], xmm8
00007154327d1ef2  vmovaps [rsp+0x80], xmm9
00007154327d1efb  vmovaps [rsp+0x90], xmm10
00007154327d1f04  vmovaps [rsp+0xA0], xmm11
00007154327d1f0d  vmovaps [rsp+0xB0], xmm12
00007154327d1f16  vmovaps [rsp+0xC0], xmm13
00007154327d1f1f  vmovaps [rsp+0xD0], xmm14
00007154327d1f28  vmovaps [rsp+0xE0], xmm15
00007154327d1f31  sub rsp, 0x30
00007154327d1f35  movaps [rsp], xmm1
00007154327d1f39  movaps [rsp+0x10], xmm13
00007154327d1f3f  movaps [rsp+0x20], xmm2
00007154327d1f44  lea rdi, [rsp]
00007154327d1f48  mov esi, 0x00
00007154327d1f4d  mov rax, 0x5A63B06A5530
00007154327d1f57  call rax
00007154327d1f59  movaps xmm1, [rsp]
00007154327d1f5d  add rsp, 0x30
00007154327d1f61  vmovaps xmm0, [rsp]
00007154327d1f66  vmovaps xmm2, [rsp+0x10]
00007154327d1f6c  vmovaps xmm3, [rsp+0x20]
00007154327d1f72  vmovaps xmm4, [rsp+0x30]
00007154327d1f78  vmovaps xmm5, [rsp+0x40]
00007154327d1f7e  vmovaps xmm6, [rsp+0x50]
00007154327d1f84  vmovaps xmm7, [rsp+0x60]
00007154327d1f8a  vmovaps xmm8, [rsp+0x70]
00007154327d1f90  vmovaps xmm9, [rsp+0x80]
00007154327d1f99  vmovaps xmm10, [rsp+0x90]
00007154327d1fa2  vmovaps xmm11, [rsp+0xA0]
00007154327d1fab  vmovaps xmm12, [rsp+0xB0]
00007154327d1fb4  vmovaps xmm13, [rsp+0xC0]
00007154327d1fbd  vmovaps xmm14, [rsp+0xD0]
00007154327d1fc6  vmovaps xmm15, [rsp+0xE0]
00007154327d1fcf  add rsp, 0xF0
00007154327d1fd6  pop r11
00007154327d1fd8  pop r10
00007154327d1fda  pop r9
00007154327d1fdc  pop r8
00007154327d1fde  pop rsi
00007154327d1fdf  pop rdi
00007154327d1fe0  pop rdx
00007154327d1fe1  pop rcx
00007154327d1fe2  pop rax
00007154327d1fe3  add rsp, 0x08
00007154327d1fe7  jmp 0x00007154327CFB52
00007154327d1fec  sub rsp, 0x08
00007154327d1ff0  push rax
00007154327d1ff1  push rcx
00007154327d1ff2  push rdx
00007154327d1ff3  push rdi
00007154327d1ff4  push rsi
00007154327d1ff5  push r8
00007154327d1ff7  push r9
00007154327d1ff9  push r10
00007154327d1ffb  push r11
00007154327d1ffd  sub rsp, 0xF0
00007154327d2004  vmovaps [rsp], xmm0
00007154327d2009  vmovaps [rsp+0x10], xmm1
00007154327d200f  vmovaps [rsp+0x20], xmm3
00007154327d2015  vmovaps [rsp+0x30], xmm4
00007154327d201b  vmovaps [rsp+0x40], xmm5
00007154327d2021  vmovaps [rsp+0x50], xmm6
00007154327d2027  vmovaps [rsp+0x60], xmm7
00007154327d202d  vmovaps [rsp+0x70], xmm8
00007154327d2033  vmovaps [rsp+0x80], xmm9
00007154327d203c  vmovaps [rsp+0x90], xmm10
00007154327d2045  vmovaps [rsp+0xA0], xmm11
00007154327d204e  vmovaps [rsp+0xB0], xmm12
00007154327d2057  vmovaps [rsp+0xC0], xmm13
00007154327d2060  vmovaps [rsp+0xD0], xmm14
00007154327d2069  vmovaps [rsp+0xE0], xmm15
00007154327d2072  sub rsp, 0x30
00007154327d2076  movaps [rsp], xmm2
00007154327d207a  movaps [rsp+0x10], xmm1
00007154327d207f  movaps [rsp+0x20], xmm13
00007154327d2085  lea rdi, [rsp]
00007154327d2089  mov esi, 0x00
00007154327d208e  mov rax, 0x5A63B06A5530
00007154327d2098  call rax
00007154327d209a  movaps xmm2, [rsp]
00007154327d209e  add rsp, 0x30
00007154327d20a2  vmovaps xmm0, [rsp]
00007154327d20a7  vmovaps xmm1, [rsp+0x10]
00007154327d20ad  vmovaps xmm3, [rsp+0x20]
00007154327d20b3  vmovaps xmm4, [rsp+0x30]
00007154327d20b9  vmovaps xmm5, [rsp+0x40]
00007154327d20bf  vmovaps xmm6, [rsp+0x50]
00007154327d20c5  vmovaps xmm7, [rsp+0x60]
00007154327d20cb  vmovaps xmm8, [rsp+0x70]
00007154327d20d1  vmovaps xmm9, [rsp+0x80]
00007154327d20da  vmovaps xmm10, [rsp+0x90]
00007154327d20e3  vmovaps xmm11, [rsp+0xA0]
00007154327d20ec  vmovaps xmm12, [rsp+0xB0]
00007154327d20f5  vmovaps xmm13, [rsp+0xC0]
00007154327d20fe  vmovaps xmm14, [rsp+0xD0]
00007154327d2107  vmovaps xmm15, [rsp+0xE0]
00007154327d2110  add rsp, 0xF0
00007154327d2117  pop r11
00007154327d2119  pop r10
00007154327d211b  pop r9
00007154327d211d  pop r8
00007154327d211f  pop rsi
00007154327d2120  pop rdi
00007154327d2121  pop rdx
00007154327d2122  pop rcx
00007154327d2123  pop rax
00007154327d2124  add rsp, 0x08
00007154327d2128  jmp 0x00007154327CFBAB
00007154327d212d  call 0x00007154325FF430
00007154327d2132  jmp 0x00007154327CFBB8
00007154327d2137  sub rsp, 0x08
00007154327d213b  push rax
00007154327d213c  push rcx
00007154327d213d  push rdx
00007154327d213e  push rdi
00007154327d213f  push rsi
00007154327d2140  push r8
00007154327d2142  push r9
00007154327d2144  push r10
00007154327d2146  push r11
00007154327d2148  sub rsp, 0xF0
00007154327d214f  vmovaps [rsp], xmm0
00007154327d2154  vmovaps [rsp+0x10], xmm1
00007154327d215a  vmovaps [rsp+0x20], xmm2
00007154327d2160  vmovaps [rsp+0x30], xmm3
00007154327d2166  vmovaps [rsp+0x40], xmm4
00007154327d216c  vmovaps [rsp+0x50], xmm5
00007154327d2172  vmovaps [rsp+0x60], xmm6
00007154327d2178  vmovaps [rsp+0x70], xmm7
00007154327d217e  vmovaps [rsp+0x80], xmm8
00007154327d2187  vmovaps [rsp+0x90], xmm9
00007154327d2190  vmovaps [rsp+0xA0], xmm10
00007154327d2199  vmovaps [rsp+0xB0], xmm11
00007154327d21a2  vmovaps [rsp+0xC0], xmm12
00007154327d21ab  vmovaps [rsp+0xD0], xmm13
00007154327d21b4  vmovaps [rsp+0xE0], xmm14
00007154327d21bd  sub rsp, 0x30
00007154327d21c1  movaps [rsp], xmm15
00007154327d21c6  movaps [rsp+0x10], xmm13
00007154327d21cc  movaps [rsp+0x20], xmm1
00007154327d21d1  lea rdi, [rsp]
00007154327d21d5  mov esi, 0x00
00007154327d21da  mov rax, 0x5A63B06A5530
00007154327d21e4  call rax
00007154327d21e6  movaps xmm15, [rsp]
00007154327d21eb  add rsp, 0x30
00007154327d21ef  vmovaps xmm0, [rsp]
00007154327d21f4  vmovaps xmm1, [rsp+0x10]
00007154327d21fa  vmovaps xmm2, [rsp+0x20]
00007154327d2200  vmovaps xmm3, [rsp+0x30]
00007154327d2206  vmovaps xmm4, [rsp+0x40]
00007154327d220c  vmovaps xmm5, [rsp+0x50]
00007154327d2212  vmovaps xmm6, [rsp+0x60]
00007154327d2218  vmovaps xmm7, [rsp+0x70]
00007154327d221e  vmovaps xmm8, [rsp+0x80]
00007154327d2227  vmovaps xmm9, [rsp+0x90]
00007154327d2230  vmovaps xmm10, [rsp+0xA0]
00007154327d2239  vmovaps xmm11, [rsp+0xB0]
00007154327d2242  vmovaps xmm12, [rsp+0xC0]
00007154327d224b  vmovaps xmm13, [rsp+0xD0]
00007154327d2254  vmovaps xmm14, [rsp+0xE0]
00007154327d225d  add rsp, 0xF0
00007154327d2264  pop r11
00007154327d2266  pop r10
00007154327d2268  pop r9
00007154327d226a  pop r8
00007154327d226c  pop rsi
00007154327d226d  pop rdi
00007154327d226e  pop rdx
00007154327d226f  pop rcx
00007154327d2270  pop rax
00007154327d2271  add rsp, 0x08
00007154327d2275  jmp 0x00007154327CFBF7
00007154327d227a  sub rsp, 0x08
00007154327d227e  push rax
00007154327d227f  push rcx
00007154327d2280  push rdx
00007154327d2281  push rdi
00007154327d2282  push rsi
00007154327d2283  push r8
00007154327d2285  push r9
00007154327d2287  push r10
00007154327d2289  push r11
00007154327d228b  sub rsp, 0xF0
00007154327d2292  vmovaps [rsp], xmm0
00007154327d2297  vmovaps [rsp+0x10], xmm1
00007154327d229d  vmovaps [rsp+0x20], xmm2
00007154327d22a3  vmovaps [rsp+0x30], xmm3
00007154327d22a9  vmovaps [rsp+0x40], xmm4
00007154327d22af  vmovaps [rsp+0x50], xmm5
00007154327d22b5  vmovaps [rsp+0x60], xmm6
00007154327d22bb  vmovaps [rsp+0x70], xmm7
00007154327d22c1  vmovaps [rsp+0x80], xmm8
00007154327d22ca  vmovaps [rsp+0x90], xmm9
00007154327d22d3  vmovaps [rsp+0xA0], xmm10
00007154327d22dc  vmovaps [rsp+0xB0], xmm11
00007154327d22e5  vmovaps [rsp+0xC0], xmm12
00007154327d22ee  vmovaps [rsp+0xD0], xmm13
00007154327d22f7  vmovaps [rsp+0xE0], xmm15
00007154327d2300  sub rsp, 0x30
00007154327d2304  movaps [rsp], xmm14
00007154327d2309  movaps [rsp+0x10], xmm11
00007154327d230f  movaps [rsp+0x20], xmm1
00007154327d2314  lea rdi, [rsp]
00007154327d2318  mov esi, 0x00
00007154327d231d  mov rax, 0x5A63B06A5530
00007154327d2327  call rax
00007154327d2329  movaps xmm14, [rsp]
00007154327d232e  add rsp, 0x30
00007154327d2332  vmovaps xmm0, [rsp]
00007154327d2337  vmovaps xmm1, [rsp+0x10]
00007154327d233d  vmovaps xmm2, [rsp+0x20]
00007154327d2343  vmovaps xmm3, [rsp+0x30]
00007154327d2349  vmovaps xmm4, [rsp+0x40]
00007154327d234f  vmovaps xmm5, [rsp+0x50]
00007154327d2355  vmovaps xmm6, [rsp+0x60]
00007154327d235b  vmovaps xmm7, [rsp+0x70]
00007154327d2361  vmovaps xmm8, [rsp+0x80]
00007154327d236a  vmovaps xmm9, [rsp+0x90]
00007154327d2373  vmovaps xmm10, [rsp+0xA0]
00007154327d237c  vmovaps xmm11, [rsp+0xB0]
00007154327d2385  vmovaps xmm12, [rsp+0xC0]
00007154327d238e  vmovaps xmm13, [rsp+0xD0]
00007154327d2397  vmovaps xmm15, [rsp+0xE0]
00007154327d23a0  add rsp, 0xF0
00007154327d23a7  pop r11
00007154327d23a9  pop r10
00007154327d23ab  pop r9
00007154327d23ad  pop r8
00007154327d23af  pop rsi
00007154327d23b0  pop rdi
00007154327d23b1  pop rdx
00007154327d23b2  pop rcx
00007154327d23b3  pop rax
00007154327d23b4  add rsp, 0x08
00007154327d23b8  jmp 0x00007154327CFC21
00007154327d23bd  sub rsp, 0x08
00007154327d23c1  push rax
00007154327d23c2  push rcx
00007154327d23c3  push rdx
00007154327d23c4  push rdi
00007154327d23c5  push rsi
00007154327d23c6  push r8
00007154327d23c8  push r9
00007154327d23ca  push r10
00007154327d23cc  push r11
00007154327d23ce  sub rsp, 0xF0
00007154327d23d5  vmovaps [rsp], xmm0
00007154327d23da  vmovaps [rsp+0x10], xmm1
00007154327d23e0  vmovaps [rsp+0x20], xmm2
00007154327d23e6  vmovaps [rsp+0x30], xmm3
00007154327d23ec  vmovaps [rsp+0x40], xmm4
00007154327d23f2  vmovaps [rsp+0x50], xmm5
00007154327d23f8  vmovaps [rsp+0x60], xmm6
00007154327d23fe  vmovaps [rsp+0x70], xmm7
00007154327d2404  vmovaps [rsp+0x80], xmm8
00007154327d240d  vmovaps [rsp+0x90], xmm9
00007154327d2416  vmovaps [rsp+0xA0], xmm10
00007154327d241f  vmovaps [rsp+0xB0], xmm11
00007154327d2428  vmovaps [rsp+0xC0], xmm12
00007154327d2431  vmovaps [rsp+0xD0], xmm14
00007154327d243a  vmovaps [rsp+0xE0], xmm15
00007154327d2443  sub rsp, 0x30
00007154327d2447  movaps [rsp], xmm13
00007154327d244c  movaps [rsp+0x10], xmm11
00007154327d2452  movaps [rsp+0x20], xmm1
00007154327d2457  lea rdi, [rsp]
00007154327d245b  mov esi, 0x00
00007154327d2460  mov rax, 0x5A63B06A5530
00007154327d246a  call rax
00007154327d246c  movaps xmm13, [rsp]
00007154327d2471  add rsp, 0x30
00007154327d2475  vmovaps xmm0, [rsp]
00007154327d247a  vmovaps xmm1, [rsp+0x10]
00007154327d2480  vmovaps xmm2, [rsp+0x20]
00007154327d2486  vmovaps xmm3, [rsp+0x30]
00007154327d248c  vmovaps xmm4, [rsp+0x40]
00007154327d2492  vmovaps xmm5, [rsp+0x50]
00007154327d2498  vmovaps xmm6, [rsp+0x60]
00007154327d249e  vmovaps xmm7, [rsp+0x70]
00007154327d24a4  vmovaps xmm8, [rsp+0x80]
00007154327d24ad  vmovaps xmm9, [rsp+0x90]
00007154327d24b6  vmovaps xmm10, [rsp+0xA0]
00007154327d24bf  vmovaps xmm11, [rsp+0xB0]
00007154327d24c8  vmovaps xmm12, [rsp+0xC0]
00007154327d24d1  vmovaps xmm14, [rsp+0xD0]
00007154327d24da  vmovaps xmm15, [rsp+0xE0]
00007154327d24e3  add rsp, 0xF0
00007154327d24ea  pop r11
00007154327d24ec  pop r10
00007154327d24ee  pop r9
00007154327d24f0  pop r8
00007154327d24f2  pop rsi
00007154327d24f3  pop rdi
00007154327d24f4  pop rdx
00007154327d24f5  pop rcx
00007154327d24f6  pop rax
00007154327d24f7  add rsp, 0x08
00007154327d24fb  jmp 0x00007154327CFC76
00007154327d2500  call 0x00007154325FF430
00007154327d2505  jmp 0x00007154327CFC83
00007154327d250a  sub rsp, 0x08
00007154327d250e  push rax
00007154327d250f  push rcx
00007154327d2510  push rdx
00007154327d2511  push rdi
00007154327d2512  push rsi
00007154327d2513  push r8
00007154327d2515  push r9
00007154327d2517  push r10
00007154327d2519  push r11
00007154327d251b  sub rsp, 0xF0
00007154327d2522  vmovaps [rsp], xmm0
00007154327d2527  vmovaps [rsp+0x10], xmm1
00007154327d252d  vmovaps [rsp+0x20], xmm2
00007154327d2533  vmovaps [rsp+0x30], xmm3
00007154327d2539  vmovaps [rsp+0x40], xmm4
00007154327d253f  vmovaps [rsp+0x50], xmm5
00007154327d2545  vmovaps [rsp+0x60], xmm6
00007154327d254b  vmovaps [rsp+0x70], xmm7
00007154327d2551  vmovaps [rsp+0x80], xmm8
00007154327d255a  vmovaps [rsp+0x90], xmm9
00007154327d2563  vmovaps [rsp+0xA0], xmm10
00007154327d256c  vmovaps [rsp+0xB0], xmm11
00007154327d2575  vmovaps [rsp+0xC0], xmm12
00007154327d257e  vmovaps [rsp+0xD0], xmm13
00007154327d2587  vmovaps [rsp+0xE0], xmm14
00007154327d2590  sub rsp, 0x30
00007154327d2594  movaps [rsp], xmm15
00007154327d2599  movaps [rsp+0x10], xmm11
00007154327d259f  movaps [rsp+0x20], xmm1
00007154327d25a4  lea rdi, [rsp]
00007154327d25a8  mov esi, 0x00
00007154327d25ad  mov rax, 0x5A63B06A5530
00007154327d25b7  call rax
00007154327d25b9  movaps xmm15, [rsp]
00007154327d25be  add rsp, 0x30
00007154327d25c2  vmovaps xmm0, [rsp]
00007154327d25c7  vmovaps xmm1, [rsp+0x10]
00007154327d25cd  vmovaps xmm2, [rsp+0x20]
00007154327d25d3  vmovaps xmm3, [rsp+0x30]
00007154327d25d9  vmovaps xmm4, [rsp+0x40]
00007154327d25df  vmovaps xmm5, [rsp+0x50]
00007154327d25e5  vmovaps xmm6, [rsp+0x60]
00007154327d25eb  vmovaps xmm7, [rsp+0x70]
00007154327d25f1  vmovaps xmm8, [rsp+0x80]
00007154327d25fa  vmovaps xmm9, [rsp+0x90]
00007154327d2603  vmovaps xmm10, [rsp+0xA0]
00007154327d260c  vmovaps xmm11, [rsp+0xB0]
00007154327d2615  vmovaps xmm12, [rsp+0xC0]
00007154327d261e  vmovaps xmm13, [rsp+0xD0]
00007154327d2627  vmovaps xmm14, [rsp+0xE0]
00007154327d2630  add rsp, 0xF0
00007154327d2637  pop r11
00007154327d2639  pop r10
00007154327d263b  pop r9
00007154327d263d  pop r8
00007154327d263f  pop rsi
00007154327d2640  pop rdi
00007154327d2641  pop rdx
00007154327d2642  pop rcx
00007154327d2643  pop rax
00007154327d2644  add rsp, 0x08
00007154327d2648  jmp 0x00007154327CFCBC
00007154327d264d  sub rsp, 0x08
00007154327d2651  push rax
00007154327d2652  push rcx
00007154327d2653  push rdx
00007154327d2654  push rdi
00007154327d2655  push rsi
00007154327d2656  push r8
00007154327d2658  push r9
00007154327d265a  push r10
00007154327d265c  push r11
00007154327d265e  sub rsp, 0xF0
00007154327d2665  vmovaps [rsp], xmm0
00007154327d266a  vmovaps [rsp+0x10], xmm1
00007154327d2670  vmovaps [rsp+0x20], xmm2
00007154327d2676  vmovaps [rsp+0x30], xmm3
00007154327d267c  vmovaps [rsp+0x40], xmm4
00007154327d2682  vmovaps [rsp+0x50], xmm5
00007154327d2688  vmovaps [rsp+0x60], xmm6
00007154327d268e  vmovaps [rsp+0x70], xmm7
00007154327d2694  vmovaps [rsp+0x80], xmm8
00007154327d269d  vmovaps [rsp+0x90], xmm9
00007154327d26a6  vmovaps [rsp+0xA0], xmm10
00007154327d26af  vmovaps [rsp+0xB0], xmm12
00007154327d26b8  vmovaps [rsp+0xC0], xmm13
00007154327d26c1  vmovaps [rsp+0xD0], xmm14
00007154327d26ca  vmovaps [rsp+0xE0], xmm15
00007154327d26d3  sub rsp, 0x30
00007154327d26d7  movaps [rsp], xmm11
00007154327d26dc  movaps [rsp+0x10], xmm6
00007154327d26e1  movaps [rsp+0x20], xmm14
00007154327d26e7  lea rdi, [rsp]
00007154327d26eb  mov esi, 0x00
00007154327d26f0  mov rax, 0x5A63B06A5530
00007154327d26fa  call rax
00007154327d26fc  movaps xmm11, [rsp]
00007154327d2701  add rsp, 0x30
00007154327d2705  vmovaps xmm0, [rsp]
00007154327d270a  vmovaps xmm1, [rsp+0x10]
00007154327d2710  vmovaps xmm2, [rsp+0x20]
00007154327d2716  vmovaps xmm3, [rsp+0x30]
00007154327d271c  vmovaps xmm4, [rsp+0x40]
00007154327d2722  vmovaps xmm5, [rsp+0x50]
00007154327d2728  vmovaps xmm6, [rsp+0x60]
00007154327d272e  vmovaps xmm7, [rsp+0x70]
00007154327d2734  vmovaps xmm8, [rsp+0x80]
00007154327d273d  vmovaps xmm9, [rsp+0x90]
00007154327d2746  vmovaps xmm10, [rsp+0xA0]
00007154327d274f  vmovaps xmm12, [rsp+0xB0]
00007154327d2758  vmovaps xmm13, [rsp+0xC0]
00007154327d2761  vmovaps xmm14, [rsp+0xD0]
00007154327d276a  vmovaps xmm15, [rsp+0xE0]
00007154327d2773  add rsp, 0xF0
00007154327d277a  pop r11
00007154327d277c  pop r10
00007154327d277e  pop r9
00007154327d2780  pop r8
00007154327d2782  pop rsi
00007154327d2783  pop rdi
00007154327d2784  pop rdx
00007154327d2785  pop rcx
00007154327d2786  pop rax
00007154327d2787  add rsp, 0x08
00007154327d278b  jmp 0x00007154327CFD34
00007154327d2790  call 0x00007154325FF430
00007154327d2795  jmp 0x00007154327CFD3E
00007154327d279a  sub rsp, 0x08
00007154327d279e  push rax
00007154327d279f  push rcx
00007154327d27a0  push rdx
00007154327d27a1  push rdi
00007154327d27a2  push rsi
00007154327d27a3  push r8
00007154327d27a5  push r9
00007154327d27a7  push r10
00007154327d27a9  push r11
00007154327d27ab  sub rsp, 0xF0
00007154327d27b2  vmovaps [rsp], xmm0
00007154327d27b7  vmovaps [rsp+0x10], xmm1
00007154327d27bd  vmovaps [rsp+0x20], xmm2
00007154327d27c3  vmovaps [rsp+0x30], xmm3
00007154327d27c9  vmovaps [rsp+0x40], xmm4
00007154327d27cf  vmovaps [rsp+0x50], xmm5
00007154327d27d5  vmovaps [rsp+0x60], xmm6
00007154327d27db  vmovaps [rsp+0x70], xmm7
00007154327d27e1  vmovaps [rsp+0x80], xmm8
00007154327d27ea  vmovaps [rsp+0x90], xmm9
00007154327d27f3  vmovaps [rsp+0xA0], xmm10
00007154327d27fc  vmovaps [rsp+0xB0], xmm11
00007154327d2805  vmovaps [rsp+0xC0], xmm12
00007154327d280e  vmovaps [rsp+0xD0], xmm13
00007154327d2817  vmovaps [rsp+0xE0], xmm15
00007154327d2820  sub rsp, 0x30
00007154327d2824  movaps [rsp], xmm14
00007154327d2829  movaps [rsp+0x10], xmm6
00007154327d282e  movaps [rsp+0x20], xmm2
00007154327d2833  lea rdi, [rsp]
00007154327d2837  mov esi, 0x00
00007154327d283c  mov rax, 0x5A63B06A5530
00007154327d2846  call rax
00007154327d2848  movaps xmm14, [rsp]
00007154327d284d  add rsp, 0x30
00007154327d2851  vmovaps xmm0, [rsp]
00007154327d2856  vmovaps xmm1, [rsp+0x10]
00007154327d285c  vmovaps xmm2, [rsp+0x20]
00007154327d2862  vmovaps xmm3, [rsp+0x30]
00007154327d2868  vmovaps xmm4, [rsp+0x40]
00007154327d286e  vmovaps xmm5, [rsp+0x50]
00007154327d2874  vmovaps xmm6, [rsp+0x60]
00007154327d287a  vmovaps xmm7, [rsp+0x70]
00007154327d2880  vmovaps xmm8, [rsp+0x80]
00007154327d2889  vmovaps xmm9, [rsp+0x90]
00007154327d2892  vmovaps xmm10, [rsp+0xA0]
00007154327d289b  vmovaps xmm11, [rsp+0xB0]
00007154327d28a4  vmovaps xmm12, [rsp+0xC0]
00007154327d28ad  vmovaps xmm13, [rsp+0xD0]
00007154327d28b6  vmovaps xmm15, [rsp+0xE0]
00007154327d28bf  add rsp, 0xF0
00007154327d28c6  pop r11
00007154327d28c8  pop r10
00007154327d28ca  pop r9
00007154327d28cc  pop r8
00007154327d28ce  pop rsi
00007154327d28cf  pop rdi
00007154327d28d0  pop rdx
00007154327d28d1  pop rcx
00007154327d28d2  pop rax
00007154327d28d3  add rsp, 0x08
00007154327d28d7  jmp 0x00007154327CFD72
00007154327d28dc  sub rsp, 0x08
00007154327d28e0  push rax
00007154327d28e1  push rcx
00007154327d28e2  push rdx
00007154327d28e3  push rdi
00007154327d28e4  push rsi
00007154327d28e5  push r8
00007154327d28e7  push r9
00007154327d28e9  push r10
00007154327d28eb  push r11
00007154327d28ed  sub rsp, 0xF0
00007154327d28f4  vmovaps [rsp], xmm0
00007154327d28f9  vmovaps [rsp+0x10], xmm1
00007154327d28ff  vmovaps [rsp+0x20], xmm2
00007154327d2905  vmovaps [rsp+0x30], xmm3
00007154327d290b  vmovaps [rsp+0x40], xmm4
00007154327d2911  vmovaps [rsp+0x50], xmm5
00007154327d2917  vmovaps [rsp+0x60], xmm7
00007154327d291d  vmovaps [rsp+0x70], xmm8
00007154327d2923  vmovaps [rsp+0x80], xmm9
00007154327d292c  vmovaps [rsp+0x90], xmm10
00007154327d2935  vmovaps [rsp+0xA0], xmm11
00007154327d293e  vmovaps [rsp+0xB0], xmm12
00007154327d2947  vmovaps [rsp+0xC0], xmm13
00007154327d2950  vmovaps [rsp+0xD0], xmm14
00007154327d2959  vmovaps [rsp+0xE0], xmm15
00007154327d2962  sub rsp, 0x30
00007154327d2966  movaps [rsp], xmm6
00007154327d296a  movaps [rsp+0x10], xmm5
00007154327d296f  movaps [rsp+0x20], xmm1
00007154327d2974  lea rdi, [rsp]
00007154327d2978  mov esi, 0x00
00007154327d297d  mov rax, 0x5A63B06A5530
00007154327d2987  call rax
00007154327d2989  movaps xmm6, [rsp]
00007154327d298d  add rsp, 0x30
00007154327d2991  vmovaps xmm0, [rsp]
00007154327d2996  vmovaps xmm1, [rsp+0x10]
00007154327d299c  vmovaps xmm2, [rsp+0x20]
00007154327d29a2  vmovaps xmm3, [rsp+0x30]
00007154327d29a8  vmovaps xmm4, [rsp+0x40]
00007154327d29ae  vmovaps xmm5, [rsp+0x50]
00007154327d29b4  vmovaps xmm7, [rsp+0x60]
00007154327d29ba  vmovaps xmm8, [rsp+0x70]
00007154327d29c0  vmovaps xmm9, [rsp+0x80]
00007154327d29c9  vmovaps xmm10, [rsp+0x90]
00007154327d29d2  vmovaps xmm11, [rsp+0xA0]
00007154327d29db  vmovaps xmm12, [rsp+0xB0]
00007154327d29e4  vmovaps xmm13, [rsp+0xC0]
00007154327d29ed  vmovaps xmm14, [rsp+0xD0]
00007154327d29f6  vmovaps xmm15, [rsp+0xE0]
00007154327d29ff  add rsp, 0xF0
00007154327d2a06  pop r11
00007154327d2a08  pop r10
00007154327d2a0a  pop r9
00007154327d2a0c  pop r8
00007154327d2a0e  pop rsi
00007154327d2a0f  pop rdi
00007154327d2a10  pop rdx
00007154327d2a11  pop rcx
00007154327d2a12  pop rax
00007154327d2a13  add rsp, 0x08
00007154327d2a17  jmp 0x00007154327CFD98
00007154327d2a1c  sub rsp, 0x08
00007154327d2a20  push rax
00007154327d2a21  push rcx
00007154327d2a22  push rdx
00007154327d2a23  push rdi
00007154327d2a24  push rsi
00007154327d2a25  push r8
00007154327d2a27  push r9
00007154327d2a29  push r10
00007154327d2a2b  push r11
00007154327d2a2d  sub rsp, 0xF0
00007154327d2a34  vmovaps [rsp], xmm0
00007154327d2a39  vmovaps [rsp+0x10], xmm2
00007154327d2a3f  vmovaps [rsp+0x20], xmm3
00007154327d2a45  vmovaps [rsp+0x30], xmm4
00007154327d2a4b  vmovaps [rsp+0x40], xmm5
00007154327d2a51  vmovaps [rsp+0x50], xmm6
00007154327d2a57  vmovaps [rsp+0x60], xmm7
00007154327d2a5d  vmovaps [rsp+0x70], xmm8
00007154327d2a63  vmovaps [rsp+0x80], xmm9
00007154327d2a6c  vmovaps [rsp+0x90], xmm10
00007154327d2a75  vmovaps [rsp+0xA0], xmm11
00007154327d2a7e  vmovaps [rsp+0xB0], xmm12
00007154327d2a87  vmovaps [rsp+0xC0], xmm13
00007154327d2a90  vmovaps [rsp+0xD0], xmm14
00007154327d2a99  vmovaps [rsp+0xE0], xmm15
00007154327d2aa2  sub rsp, 0x30
00007154327d2aa6  movaps [rsp], xmm1
00007154327d2aaa  movaps [rsp+0x10], xmm5
00007154327d2aaf  movaps [rsp+0x20], xmm13
00007154327d2ab5  lea rdi, [rsp]
00007154327d2ab9  mov esi, 0x00
00007154327d2abe  mov rax, 0x5A63B06A5530
00007154327d2ac8  call rax
00007154327d2aca  movaps xmm1, [rsp]
00007154327d2ace  add rsp, 0x30
00007154327d2ad2  vmovaps xmm0, [rsp]
00007154327d2ad7  vmovaps xmm2, [rsp+0x10]
00007154327d2add  vmovaps xmm3, [rsp+0x20]
00007154327d2ae3  vmovaps xmm4, [rsp+0x30]
00007154327d2ae9  vmovaps xmm5, [rsp+0x40]
00007154327d2aef  vmovaps xmm6, [rsp+0x50]
00007154327d2af5  vmovaps xmm7, [rsp+0x60]
00007154327d2afb  vmovaps xmm8, [rsp+0x70]
00007154327d2b01  vmovaps xmm9, [rsp+0x80]
00007154327d2b0a  vmovaps xmm10, [rsp+0x90]
00007154327d2b13  vmovaps xmm11, [rsp+0xA0]
00007154327d2b1c  vmovaps xmm12, [rsp+0xB0]
00007154327d2b25  vmovaps xmm13, [rsp+0xC0]
00007154327d2b2e  vmovaps xmm14, [rsp+0xD0]
00007154327d2b37  vmovaps xmm15, [rsp+0xE0]
00007154327d2b40  add rsp, 0xF0
00007154327d2b47  pop r11
00007154327d2b49  pop r10
00007154327d2b4b  pop r9
00007154327d2b4d  pop r8
00007154327d2b4f  pop rsi
00007154327d2b50  pop rdi
00007154327d2b51  pop rdx
00007154327d2b52  pop rcx
00007154327d2b53  pop rax
00007154327d2b54  add rsp, 0x08
00007154327d2b58  jmp 0x00007154327CFDB6
00007154327d2b5d  sub rsp, 0x08
00007154327d2b61  push rax
00007154327d2b62  push rcx
00007154327d2b63  push rdx
00007154327d2b64  push rdi
00007154327d2b65  push rsi
00007154327d2b66  push r8
00007154327d2b68  push r9
00007154327d2b6a  push r10
00007154327d2b6c  push r11
00007154327d2b6e  sub rsp, 0xF0
00007154327d2b75  vmovaps [rsp], xmm0
00007154327d2b7a  vmovaps [rsp+0x10], xmm1
00007154327d2b80  vmovaps [rsp+0x20], xmm2
00007154327d2b86  vmovaps [rsp+0x30], xmm3
00007154327d2b8c  vmovaps [rsp+0x40], xmm4
00007154327d2b92  vmovaps [rsp+0x50], xmm6
00007154327d2b98  vmovaps [rsp+0x60], xmm7
00007154327d2b9e  vmovaps [rsp+0x70], xmm8
00007154327d2ba4  vmovaps [rsp+0x80], xmm9
00007154327d2bad  vmovaps [rsp+0x90], xmm10
00007154327d2bb6  vmovaps [rsp+0xA0], xmm11
00007154327d2bbf  vmovaps [rsp+0xB0], xmm12
00007154327d2bc8  vmovaps [rsp+0xC0], xmm13
00007154327d2bd1  vmovaps [rsp+0xD0], xmm14
00007154327d2bda  vmovaps [rsp+0xE0], xmm15
00007154327d2be3  sub rsp, 0x30
00007154327d2be7  movaps [rsp], xmm5
00007154327d2beb  movaps [rsp+0x10], xmm2
00007154327d2bf0  movaps [rsp+0x20], xmm13
00007154327d2bf6  lea rdi, [rsp]
00007154327d2bfa  mov esi, 0x00
00007154327d2bff  mov rax, 0x5A63B06A5530
00007154327d2c09  call rax
00007154327d2c0b  movaps xmm5, [rsp]
00007154327d2c0f  add rsp, 0x30
00007154327d2c13  vmovaps xmm0, [rsp]
00007154327d2c18  vmovaps xmm1, [rsp+0x10]
00007154327d2c1e  vmovaps xmm2, [rsp+0x20]
00007154327d2c24  vmovaps xmm3, [rsp+0x30]
00007154327d2c2a  vmovaps xmm4, [rsp+0x40]
00007154327d2c30  vmovaps xmm6, [rsp+0x50]
00007154327d2c36  vmovaps xmm7, [rsp+0x60]
00007154327d2c3c  vmovaps xmm8, [rsp+0x70]
00007154327d2c42  vmovaps xmm9, [rsp+0x80]
00007154327d2c4b  vmovaps xmm10, [rsp+0x90]
00007154327d2c54  vmovaps xmm11, [rsp+0xA0]
00007154327d2c5d  vmovaps xmm12, [rsp+0xB0]
00007154327d2c66  vmovaps xmm13, [rsp+0xC0]
00007154327d2c6f  vmovaps xmm14, [rsp+0xD0]
00007154327d2c78  vmovaps xmm15, [rsp+0xE0]
00007154327d2c81  add rsp, 0xF0
00007154327d2c88  pop r11
00007154327d2c8a  pop r10
00007154327d2c8c  pop r9
00007154327d2c8e  pop r8
00007154327d2c90  pop rsi
00007154327d2c91  pop rdi
00007154327d2c92  pop rdx
00007154327d2c93  pop rcx
00007154327d2c94  pop rax
00007154327d2c95  add rsp, 0x08
00007154327d2c99  jmp 0x00007154327CFDEC
00007154327d2c9e  sub rsp, 0x08
00007154327d2ca2  push rax
00007154327d2ca3  push rcx
00007154327d2ca4  push rdx
00007154327d2ca5  push rdi
00007154327d2ca6  push rsi
00007154327d2ca7  push r8
00007154327d2ca9  push r9
00007154327d2cab  push r10
00007154327d2cad  push r11
00007154327d2caf  sub rsp, 0xF0
00007154327d2cb6  vmovaps [rsp], xmm0
00007154327d2cbb  vmovaps [rsp+0x10], xmm1
00007154327d2cc1  vmovaps [rsp+0x20], xmm2
00007154327d2cc7  vmovaps [rsp+0x30], xmm3
00007154327d2ccd  vmovaps [rsp+0x40], xmm4
00007154327d2cd3  vmovaps [rsp+0x50], xmm5
00007154327d2cd9  vmovaps [rsp+0x60], xmm6
00007154327d2cdf  vmovaps [rsp+0x70], xmm7
00007154327d2ce5  vmovaps [rsp+0x80], xmm8
00007154327d2cee  vmovaps [rsp+0x90], xmm9
00007154327d2cf7  vmovaps [rsp+0xA0], xmm10
00007154327d2d00  vmovaps [rsp+0xB0], xmm11
00007154327d2d09  vmovaps [rsp+0xC0], xmm12
00007154327d2d12  vmovaps [rsp+0xD0], xmm14
00007154327d2d1b  vmovaps [rsp+0xE0], xmm15
00007154327d2d24  sub rsp, 0x30
00007154327d2d28  movaps [rsp], xmm13
00007154327d2d2d  movaps [rsp+0x10], xmm10
00007154327d2d33  movaps [rsp+0x20], xmm1
00007154327d2d38  lea rdi, [rsp]
00007154327d2d3c  mov esi, 0x00
00007154327d2d41  mov rax, 0x5A63B06A5530
00007154327d2d4b  call rax
00007154327d2d4d  movaps xmm13, [rsp]
00007154327d2d52  add rsp, 0x30
00007154327d2d56  vmovaps xmm0, [rsp]
00007154327d2d5b  vmovaps xmm1, [rsp+0x10]
00007154327d2d61  vmovaps xmm2, [rsp+0x20]
00007154327d2d67  vmovaps xmm3, [rsp+0x30]
00007154327d2d6d  vmovaps xmm4, [rsp+0x40]
00007154327d2d73  vmovaps xmm5, [rsp+0x50]
00007154327d2d79  vmovaps xmm6, [rsp+0x60]
00007154327d2d7f  vmovaps xmm7, [rsp+0x70]
00007154327d2d85  vmovaps xmm8, [rsp+0x80]
00007154327d2d8e  vmovaps xmm9, [rsp+0x90]
00007154327d2d97  vmovaps xmm10, [rsp+0xA0]
00007154327d2da0  vmovaps xmm11, [rsp+0xB0]
00007154327d2da9  vmovaps xmm12, [rsp+0xC0]
00007154327d2db2  vmovaps xmm14, [rsp+0xD0]
00007154327d2dbb  vmovaps xmm15, [rsp+0xE0]
00007154327d2dc4  add rsp, 0xF0
00007154327d2dcb  pop r11
00007154327d2dcd  pop r10
00007154327d2dcf  pop r9
00007154327d2dd1  pop r8
00007154327d2dd3  pop rsi
00007154327d2dd4  pop rdi
00007154327d2dd5  pop rdx
00007154327d2dd6  pop rcx
00007154327d2dd7  pop rax
00007154327d2dd8  add rsp, 0x08
00007154327d2ddc  jmp 0x00007154327CFE15
00007154327d2de1  sub rsp, 0x08
00007154327d2de5  push rax
00007154327d2de6  push rcx
00007154327d2de7  push rdx
00007154327d2de8  push rdi
00007154327d2de9  push rsi
00007154327d2dea  push r8
00007154327d2dec  push r9
00007154327d2dee  push r10
00007154327d2df0  push r11
00007154327d2df2  sub rsp, 0xF0
00007154327d2df9  vmovaps [rsp], xmm0
00007154327d2dfe  vmovaps [rsp+0x10], xmm2
00007154327d2e04  vmovaps [rsp+0x20], xmm3
00007154327d2e0a  vmovaps [rsp+0x30], xmm4
00007154327d2e10  vmovaps [rsp+0x40], xmm5
00007154327d2e16  vmovaps [rsp+0x50], xmm6
00007154327d2e1c  vmovaps [rsp+0x60], xmm7
00007154327d2e22  vmovaps [rsp+0x70], xmm8
00007154327d2e28  vmovaps [rsp+0x80], xmm9
00007154327d2e31  vmovaps [rsp+0x90], xmm10
00007154327d2e3a  vmovaps [rsp+0xA0], xmm11
00007154327d2e43  vmovaps [rsp+0xB0], xmm12
00007154327d2e4c  vmovaps [rsp+0xC0], xmm13
00007154327d2e55  vmovaps [rsp+0xD0], xmm14
00007154327d2e5e  vmovaps [rsp+0xE0], xmm15
00007154327d2e67  sub rsp, 0x30
00007154327d2e6b  movaps [rsp], xmm1
00007154327d2e6f  movaps [rsp+0x10], xmm15
00007154327d2e75  movaps [rsp+0x20], xmm10
00007154327d2e7b  lea rdi, [rsp]
00007154327d2e7f  mov esi, 0x00
00007154327d2e84  mov rax, 0x5A63B06A5530
00007154327d2e8e  call rax
00007154327d2e90  movaps xmm1, [rsp]
00007154327d2e94  add rsp, 0x30
00007154327d2e98  vmovaps xmm0, [rsp]
00007154327d2e9d  vmovaps xmm2, [rsp+0x10]
00007154327d2ea3  vmovaps xmm3, [rsp+0x20]
00007154327d2ea9  vmovaps xmm4, [rsp+0x30]
00007154327d2eaf  vmovaps xmm5, [rsp+0x40]
00007154327d2eb5  vmovaps xmm6, [rsp+0x50]
00007154327d2ebb  vmovaps xmm7, [rsp+0x60]
00007154327d2ec1  vmovaps xmm8, [rsp+0x70]
00007154327d2ec7  vmovaps xmm9, [rsp+0x80]
00007154327d2ed0  vmovaps xmm10, [rsp+0x90]
00007154327d2ed9  vmovaps xmm11, [rsp+0xA0]
00007154327d2ee2  vmovaps xmm12, [rsp+0xB0]
00007154327d2eeb  vmovaps xmm13, [rsp+0xC0]
00007154327d2ef4  vmovaps xmm14, [rsp+0xD0]
00007154327d2efd  vmovaps xmm15, [rsp+0xE0]
00007154327d2f06  add rsp, 0xF0
00007154327d2f0d  pop r11
00007154327d2f0f  pop r10
00007154327d2f11  pop r9
00007154327d2f13  pop r8
00007154327d2f15  pop rsi
00007154327d2f16  pop rdi
00007154327d2f17  pop rdx
00007154327d2f18  pop rcx
00007154327d2f19  pop rax
00007154327d2f1a  add rsp, 0x08
00007154327d2f1e  jmp 0x00007154327CFE34
00007154327d2f23  sub rsp, 0x08
00007154327d2f27  push rax
00007154327d2f28  push rcx
00007154327d2f29  push rdx
00007154327d2f2a  push rdi
00007154327d2f2b  push rsi
00007154327d2f2c  push r8
00007154327d2f2e  push r9
00007154327d2f30  push r10
00007154327d2f32  push r11
00007154327d2f34  sub rsp, 0xF0
00007154327d2f3b  vmovaps [rsp], xmm0
00007154327d2f40  vmovaps [rsp+0x10], xmm1
00007154327d2f46  vmovaps [rsp+0x20], xmm2
00007154327d2f4c  vmovaps [rsp+0x30], xmm3
00007154327d2f52  vmovaps [rsp+0x40], xmm4
00007154327d2f58  vmovaps [rsp+0x50], xmm5
00007154327d2f5e  vmovaps [rsp+0x60], xmm6
00007154327d2f64  vmovaps [rsp+0x70], xmm7
00007154327d2f6a  vmovaps [rsp+0x80], xmm8
00007154327d2f73  vmovaps [rsp+0x90], xmm9
00007154327d2f7c  vmovaps [rsp+0xA0], xmm10
00007154327d2f85  vmovaps [rsp+0xB0], xmm11
00007154327d2f8e  vmovaps [rsp+0xC0], xmm12
00007154327d2f97  vmovaps [rsp+0xD0], xmm13
00007154327d2fa0  vmovaps [rsp+0xE0], xmm14
00007154327d2fa9  sub rsp, 0x30
00007154327d2fad  movaps [rsp], xmm15
00007154327d2fb2  movaps [rsp+0x10], xmm10
00007154327d2fb8  movaps [rsp+0x20], xmm11
00007154327d2fbe  lea rdi, [rsp]
00007154327d2fc2  mov esi, 0x00
00007154327d2fc7  mov rax, 0x5A63B06A5530
00007154327d2fd1  call rax
00007154327d2fd3  movaps xmm15, [rsp]
00007154327d2fd8  add rsp, 0x30
00007154327d2fdc  vmovaps xmm0, [rsp]
00007154327d2fe1  vmovaps xmm1, [rsp+0x10]
00007154327d2fe7  vmovaps xmm2, [rsp+0x20]
00007154327d2fed  vmovaps xmm3, [rsp+0x30]
00007154327d2ff3  vmovaps xmm4, [rsp+0x40]
00007154327d2ff9  vmovaps xmm5, [rsp+0x50]
00007154327d2fff  vmovaps xmm6, [rsp+0x60]
00007154327d3005  vmovaps xmm7, [rsp+0x70]
00007154327d300b  vmovaps xmm8, [rsp+0x80]
00007154327d3014  vmovaps xmm9, [rsp+0x90]
00007154327d301d  vmovaps xmm10, [rsp+0xA0]
00007154327d3026  vmovaps xmm11, [rsp+0xB0]
00007154327d302f  vmovaps xmm12, [rsp+0xC0]
00007154327d3038  vmovaps xmm13, [rsp+0xD0]
00007154327d3041  vmovaps xmm14, [rsp+0xE0]
00007154327d304a  add rsp, 0xF0
00007154327d3051  pop r11
00007154327d3053  pop r10
00007154327d3055  pop r9
00007154327d3057  pop r8
00007154327d3059  pop rsi
00007154327d305a  pop rdi
00007154327d305b  pop rdx
00007154327d305c  pop rcx
00007154327d305d  pop rax
00007154327d305e  add rsp, 0x08
00007154327d3062  jmp 0x00007154327CFE57
00007154327d3067  sub rsp, 0x08
00007154327d306b  push rax
00007154327d306c  push rcx
00007154327d306d  push rdx
00007154327d306e  push rdi
00007154327d306f  push rsi
00007154327d3070  push r8
00007154327d3072  push r9
00007154327d3074  push r10
00007154327d3076  push r11
00007154327d3078  sub rsp, 0xF0
00007154327d307f  vmovaps [rsp], xmm0
00007154327d3084  vmovaps [rsp+0x10], xmm1
00007154327d308a  vmovaps [rsp+0x20], xmm2
00007154327d3090  vmovaps [rsp+0x30], xmm3
00007154327d3096  vmovaps [rsp+0x40], xmm4
00007154327d309c  vmovaps [rsp+0x50], xmm5
00007154327d30a2  vmovaps [rsp+0x60], xmm6
00007154327d30a8  vmovaps [rsp+0x70], xmm7
00007154327d30ae  vmovaps [rsp+0x80], xmm8
00007154327d30b7  vmovaps [rsp+0x90], xmm9
00007154327d30c0  vmovaps [rsp+0xA0], xmm11
00007154327d30c9  vmovaps [rsp+0xB0], xmm12
00007154327d30d2  vmovaps [rsp+0xC0], xmm13
00007154327d30db  vmovaps [rsp+0xD0], xmm14
00007154327d30e4  vmovaps [rsp+0xE0], xmm15
00007154327d30ed  sub rsp, 0x30
00007154327d30f1  movaps [rsp], xmm10
00007154327d30f6  movaps [rsp+0x10], xmm12
00007154327d30fc  movaps [rsp+0x20], xmm11
00007154327d3102  lea rdi, [rsp]
00007154327d3106  mov esi, 0x00
00007154327d310b  mov rax, 0x5A63B06A5530
00007154327d3115  call rax
00007154327d3117  movaps xmm10, [rsp]
00007154327d311c  add rsp, 0x30
00007154327d3120  vmovaps xmm0, [rsp]
00007154327d3125  vmovaps xmm1, [rsp+0x10]
00007154327d312b  vmovaps xmm2, [rsp+0x20]
00007154327d3131  vmovaps xmm3, [rsp+0x30]
00007154327d3137  vmovaps xmm4, [rsp+0x40]
00007154327d313d  vmovaps xmm5, [rsp+0x50]
00007154327d3143  vmovaps xmm6, [rsp+0x60]
00007154327d3149  vmovaps xmm7, [rsp+0x70]
00007154327d314f  vmovaps xmm8, [rsp+0x80]
00007154327d3158  vmovaps xmm9, [rsp+0x90]
00007154327d3161  vmovaps xmm11, [rsp+0xA0]
00007154327d316a  vmovaps xmm12, [rsp+0xB0]
00007154327d3173  vmovaps xmm13, [rsp+0xC0]
00007154327d317c  vmovaps xmm14, [rsp+0xD0]
00007154327d3185  vmovaps xmm15, [rsp+0xE0]
00007154327d318e  add rsp, 0xF0
00007154327d3195  pop r11
00007154327d3197  pop r10
00007154327d3199  pop r9
00007154327d319b  pop r8
00007154327d319d  pop rsi
00007154327d319e  pop rdi
00007154327d319f  pop rdx
00007154327d31a0  pop rcx
00007154327d31a1  pop rax
00007154327d31a2  add rsp, 0x08
00007154327d31a6  jmp 0x00007154327CFE80
00007154327d31ab  sub rsp, 0x08
00007154327d31af  push rax
00007154327d31b0  push rcx
00007154327d31b1  push rdx
00007154327d31b2  push rdi
00007154327d31b3  push rsi
00007154327d31b4  push r8
00007154327d31b6  push r9
00007154327d31b8  push r10
00007154327d31ba  push r11
00007154327d31bc  sub rsp, 0xF0
00007154327d31c3  vmovaps [rsp], xmm0
00007154327d31c8  vmovaps [rsp+0x10], xmm1
00007154327d31ce  vmovaps [rsp+0x20], xmm2
00007154327d31d4  vmovaps [rsp+0x30], xmm3
00007154327d31da  vmovaps [rsp+0x40], xmm4
00007154327d31e0  vmovaps [rsp+0x50], xmm5
00007154327d31e6  vmovaps [rsp+0x60], xmm6
00007154327d31ec  vmovaps [rsp+0x70], xmm7
00007154327d31f2  vmovaps [rsp+0x80], xmm8
00007154327d31fb  vmovaps [rsp+0x90], xmm9
00007154327d3204  vmovaps [rsp+0xA0], xmm10
00007154327d320d  vmovaps [rsp+0xB0], xmm12
00007154327d3216  vmovaps [rsp+0xC0], xmm13
00007154327d321f  vmovaps [rsp+0xD0], xmm14
00007154327d3228  vmovaps [rsp+0xE0], xmm15
00007154327d3231  sub rsp, 0x30
00007154327d3235  movaps [rsp], xmm11
00007154327d323a  movaps [rsp+0x10], xmm2
00007154327d323f  movaps [rsp+0x20], xmm12
00007154327d3245  lea rdi, [rsp]
00007154327d3249  mov esi, 0x00
00007154327d324e  mov rax, 0x5A63B06A5530
00007154327d3258  call rax
00007154327d325a  movaps xmm11, [rsp]
00007154327d325f  add rsp, 0x30
00007154327d3263  vmovaps xmm0, [rsp]
00007154327d3268  vmovaps xmm1, [rsp+0x10]
00007154327d326e  vmovaps xmm2, [rsp+0x20]
00007154327d3274  vmovaps xmm3, [rsp+0x30]
00007154327d327a  vmovaps xmm4, [rsp+0x40]
00007154327d3280  vmovaps xmm5, [rsp+0x50]
00007154327d3286  vmovaps xmm6, [rsp+0x60]
00007154327d328c  vmovaps xmm7, [rsp+0x70]
00007154327d3292  vmovaps xmm8, [rsp+0x80]
00007154327d329b  vmovaps xmm9, [rsp+0x90]
00007154327d32a4  vmovaps xmm10, [rsp+0xA0]
00007154327d32ad  vmovaps xmm12, [rsp+0xB0]
00007154327d32b6  vmovaps xmm13, [rsp+0xC0]
00007154327d32bf  vmovaps xmm14, [rsp+0xD0]
00007154327d32c8  vmovaps xmm15, [rsp+0xE0]
00007154327d32d1  add rsp, 0xF0
00007154327d32d8  pop r11
00007154327d32da  pop r10
00007154327d32dc  pop r9
00007154327d32de  pop r8
00007154327d32e0  pop rsi
00007154327d32e1  pop rdi
00007154327d32e2  pop rdx
00007154327d32e3  pop rcx
00007154327d32e4  pop rax
00007154327d32e5  add rsp, 0x08
00007154327d32e9  jmp 0x00007154327CFEB8
00007154327d32ee  sub rsp, 0x08
00007154327d32f2  push rax
00007154327d32f3  push rcx
00007154327d32f4  push rdx
00007154327d32f5  push rdi
00007154327d32f6  push rsi
00007154327d32f7  push r8
00007154327d32f9  push r9
00007154327d32fb  push r10
00007154327d32fd  push r11
00007154327d32ff  sub rsp, 0xF0
00007154327d3306  vmovaps [rsp], xmm0
00007154327d330b  vmovaps [rsp+0x10], xmm2
00007154327d3311  vmovaps [rsp+0x20], xmm3
00007154327d3317  vmovaps [rsp+0x30], xmm4
00007154327d331d  vmovaps [rsp+0x40], xmm5
00007154327d3323  vmovaps [rsp+0x50], xmm6
00007154327d3329  vmovaps [rsp+0x60], xmm7
00007154327d332f  vmovaps [rsp+0x70], xmm8
00007154327d3335  vmovaps [rsp+0x80], xmm9
00007154327d333e  vmovaps [rsp+0x90], xmm10
00007154327d3347  vmovaps [rsp+0xA0], xmm11
00007154327d3350  vmovaps [rsp+0xB0], xmm12
00007154327d3359  vmovaps [rsp+0xC0], xmm13
00007154327d3362  vmovaps [rsp+0xD0], xmm14
00007154327d336b  vmovaps [rsp+0xE0], xmm15
00007154327d3374  sub rsp, 0x30
00007154327d3378  movaps [rsp], xmm1
00007154327d337c  movaps [rsp+0x10], xmm14
00007154327d3382  movaps [rsp+0x20], xmm6
00007154327d3387  lea rdi, [rsp]
00007154327d338b  mov esi, 0x00
00007154327d3390  mov rax, 0x5A63B06A5530
00007154327d339a  call rax
00007154327d339c  movaps xmm1, [rsp]
00007154327d33a0  add rsp, 0x30
00007154327d33a4  vmovaps xmm0, [rsp]
00007154327d33a9  vmovaps xmm2, [rsp+0x10]
00007154327d33af  vmovaps xmm3, [rsp+0x20]
00007154327d33b5  vmovaps xmm4, [rsp+0x30]
00007154327d33bb  vmovaps xmm5, [rsp+0x40]
00007154327d33c1  vmovaps xmm6, [rsp+0x50]
00007154327d33c7  vmovaps xmm7, [rsp+0x60]
00007154327d33cd  vmovaps xmm8, [rsp+0x70]
00007154327d33d3  vmovaps xmm9, [rsp+0x80]
00007154327d33dc  vmovaps xmm10, [rsp+0x90]
00007154327d33e5  vmovaps xmm11, [rsp+0xA0]
00007154327d33ee  vmovaps xmm12, [rsp+0xB0]
00007154327d33f7  vmovaps xmm13, [rsp+0xC0]
00007154327d3400  vmovaps xmm14, [rsp+0xD0]
00007154327d3409  vmovaps xmm15, [rsp+0xE0]
00007154327d3412  add rsp, 0xF0
00007154327d3419  pop r11
00007154327d341b  pop r10
00007154327d341d  pop r9
00007154327d341f  pop r8
00007154327d3421  pop rsi
00007154327d3422  pop rdi
00007154327d3423  pop rdx
00007154327d3424  pop rcx
00007154327d3425  pop rax
00007154327d3426  add rsp, 0x08
00007154327d342a  jmp 0x00007154327CFED1
00007154327d342f  sub rsp, 0x08
00007154327d3433  push rax
00007154327d3434  push rcx
00007154327d3435  push rdx
00007154327d3436  push rdi
00007154327d3437  push rsi
00007154327d3438  push r8
00007154327d343a  push r9
00007154327d343c  push r10
00007154327d343e  push r11
00007154327d3440  sub rsp, 0xF0
00007154327d3447  vmovaps [rsp], xmm0
00007154327d344c  vmovaps [rsp+0x10], xmm1
00007154327d3452  vmovaps [rsp+0x20], xmm2
00007154327d3458  vmovaps [rsp+0x30], xmm3
00007154327d345e  vmovaps [rsp+0x40], xmm4
00007154327d3464  vmovaps [rsp+0x50], xmm5
00007154327d346a  vmovaps [rsp+0x60], xmm6
00007154327d3470  vmovaps [rsp+0x70], xmm7
00007154327d3476  vmovaps [rsp+0x80], xmm8
00007154327d347f  vmovaps [rsp+0x90], xmm9
00007154327d3488  vmovaps [rsp+0xA0], xmm10
00007154327d3491  vmovaps [rsp+0xB0], xmm11
00007154327d349a  vmovaps [rsp+0xC0], xmm12
00007154327d34a3  vmovaps [rsp+0xD0], xmm13
00007154327d34ac  vmovaps [rsp+0xE0], xmm15
00007154327d34b5  sub rsp, 0x30
00007154327d34b9  movaps [rsp], xmm14
00007154327d34be  movaps [rsp+0x10], xmm12
00007154327d34c4  movaps [rsp+0x20], xmm5
00007154327d34c9  lea rdi, [rsp]
00007154327d34cd  mov esi, 0x00
00007154327d34d2  mov rax, 0x5A63B06A5530
00007154327d34dc  call rax
00007154327d34de  movaps xmm14, [rsp]
00007154327d34e3  add rsp, 0x30
00007154327d34e7  vmovaps xmm0, [rsp]
00007154327d34ec  vmovaps xmm1, [rsp+0x10]
00007154327d34f2  vmovaps xmm2, [rsp+0x20]
00007154327d34f8  vmovaps xmm3, [rsp+0x30]
00007154327d34fe  vmovaps xmm4, [rsp+0x40]
00007154327d3504  vmovaps xmm5, [rsp+0x50]
00007154327d350a  vmovaps xmm6, [rsp+0x60]
00007154327d3510  vmovaps xmm7, [rsp+0x70]
00007154327d3516  vmovaps xmm8, [rsp+0x80]
00007154327d351f  vmovaps xmm9, [rsp+0x90]
00007154327d3528  vmovaps xmm10, [rsp+0xA0]
00007154327d3531  vmovaps xmm11, [rsp+0xB0]
00007154327d353a  vmovaps xmm12, [rsp+0xC0]
00007154327d3543  vmovaps xmm13, [rsp+0xD0]
00007154327d354c  vmovaps xmm15, [rsp+0xE0]
00007154327d3555  add rsp, 0xF0
00007154327d355c  pop r11
00007154327d355e  pop r10
00007154327d3560  pop r9
00007154327d3562  pop r8
00007154327d3564  pop rsi
00007154327d3565  pop rdi
00007154327d3566  pop rdx
00007154327d3567  pop rcx
00007154327d3568  pop rax
00007154327d3569  add rsp, 0x08
00007154327d356d  jmp 0x00007154327CFEF1
00007154327d3572  sub rsp, 0x08
00007154327d3576  push rax
00007154327d3577  push rcx
00007154327d3578  push rdx
00007154327d3579  push rdi
00007154327d357a  push rsi
00007154327d357b  push r8
00007154327d357d  push r9
00007154327d357f  push r10
00007154327d3581  push r11
00007154327d3583  sub rsp, 0xF0
00007154327d358a  vmovaps [rsp], xmm0
00007154327d358f  vmovaps [rsp+0x10], xmm1
00007154327d3595  vmovaps [rsp+0x20], xmm2
00007154327d359b  vmovaps [rsp+0x30], xmm3
00007154327d35a1  vmovaps [rsp+0x40], xmm4
00007154327d35a7  vmovaps [rsp+0x50], xmm5
00007154327d35ad  vmovaps [rsp+0x60], xmm7
00007154327d35b3  vmovaps [rsp+0x70], xmm8
00007154327d35b9  vmovaps [rsp+0x80], xmm9
00007154327d35c2  vmovaps [rsp+0x90], xmm10
00007154327d35cb  vmovaps [rsp+0xA0], xmm11
00007154327d35d4  vmovaps [rsp+0xB0], xmm12
00007154327d35dd  vmovaps [rsp+0xC0], xmm13
00007154327d35e6  vmovaps [rsp+0xD0], xmm14
00007154327d35ef  vmovaps [rsp+0xE0], xmm15
00007154327d35f8  sub rsp, 0x30
00007154327d35fc  movaps [rsp], xmm6
00007154327d3600  movaps [rsp+0x10], xmm9
00007154327d3606  movaps [rsp+0x20], xmm12
00007154327d360c  lea rdi, [rsp]
00007154327d3610  mov esi, 0x00
00007154327d3615  mov rax, 0x5A63B06A5530
00007154327d361f  call rax
00007154327d3621  movaps xmm6, [rsp]
00007154327d3625  add rsp, 0x30
00007154327d3629  vmovaps xmm0, [rsp]
00007154327d362e  vmovaps xmm1, [rsp+0x10]
00007154327d3634  vmovaps xmm2, [rsp+0x20]
00007154327d363a  vmovaps xmm3, [rsp+0x30]
00007154327d3640  vmovaps xmm4, [rsp+0x40]
00007154327d3646  vmovaps xmm5, [rsp+0x50]
00007154327d364c  vmovaps xmm7, [rsp+0x60]
00007154327d3652  vmovaps xmm8, [rsp+0x70]
00007154327d3658  vmovaps xmm9, [rsp+0x80]
00007154327d3661  vmovaps xmm10, [rsp+0x90]
00007154327d366a  vmovaps xmm11, [rsp+0xA0]
00007154327d3673  vmovaps xmm12, [rsp+0xB0]
00007154327d367c  vmovaps xmm13, [rsp+0xC0]
00007154327d3685  vmovaps xmm14, [rsp+0xD0]
00007154327d368e  vmovaps xmm15, [rsp+0xE0]
00007154327d3697  add rsp, 0xF0
00007154327d369e  pop r11
00007154327d36a0  pop r10
00007154327d36a2  pop r9
00007154327d36a4  pop r8
00007154327d36a6  pop rsi
00007154327d36a7  pop rdi
00007154327d36a8  pop rdx
00007154327d36a9  pop rcx
00007154327d36aa  pop rax
00007154327d36ab  add rsp, 0x08
00007154327d36af  jmp 0x00007154327CFF19
00007154327d36b4  sub rsp, 0x08
00007154327d36b8  push rax
00007154327d36b9  push rcx
00007154327d36ba  push rdx
00007154327d36bb  push rdi
00007154327d36bc  push rsi
00007154327d36bd  push r8
00007154327d36bf  push r9
00007154327d36c1  push r10
00007154327d36c3  push r11
00007154327d36c5  sub rsp, 0xF0
00007154327d36cc  vmovaps [rsp], xmm0
00007154327d36d1  vmovaps [rsp+0x10], xmm1
00007154327d36d7  vmovaps [rsp+0x20], xmm2
00007154327d36dd  vmovaps [rsp+0x30], xmm3
00007154327d36e3  vmovaps [rsp+0x40], xmm4
00007154327d36e9  vmovaps [rsp+0x50], xmm5
00007154327d36ef  vmovaps [rsp+0x60], xmm6
00007154327d36f5  vmovaps [rsp+0x70], xmm7
00007154327d36fb  vmovaps [rsp+0x80], xmm8
00007154327d3704  vmovaps [rsp+0x90], xmm9
00007154327d370d  vmovaps [rsp+0xA0], xmm10
00007154327d3716  vmovaps [rsp+0xB0], xmm11
00007154327d371f  vmovaps [rsp+0xC0], xmm13
00007154327d3728  vmovaps [rsp+0xD0], xmm14
00007154327d3731  vmovaps [rsp+0xE0], xmm15
00007154327d373a  sub rsp, 0x30
00007154327d373e  movaps [rsp], xmm12
00007154327d3743  movaps [rsp+0x10], xmm15
00007154327d3749  movaps [rsp+0x20], xmm13
00007154327d374f  lea rdi, [rsp]
00007154327d3753  mov esi, 0x00
00007154327d3758  mov rax, 0x5A63B06A5530
00007154327d3762  call rax
00007154327d3764  movaps xmm12, [rsp]
00007154327d3769  add rsp, 0x30
00007154327d376d  vmovaps xmm0, [rsp]
00007154327d3772  vmovaps xmm1, [rsp+0x10]
00007154327d3778  vmovaps xmm2, [rsp+0x20]
00007154327d377e  vmovaps xmm3, [rsp+0x30]
00007154327d3784  vmovaps xmm4, [rsp+0x40]
00007154327d378a  vmovaps xmm5, [rsp+0x50]
00007154327d3790  vmovaps xmm6, [rsp+0x60]
00007154327d3796  vmovaps xmm7, [rsp+0x70]
00007154327d379c  vmovaps xmm8, [rsp+0x80]
00007154327d37a5  vmovaps xmm9, [rsp+0x90]
00007154327d37ae  vmovaps xmm10, [rsp+0xA0]
00007154327d37b7  vmovaps xmm11, [rsp+0xB0]
00007154327d37c0  vmovaps xmm13, [rsp+0xC0]
00007154327d37c9  vmovaps xmm14, [rsp+0xD0]
00007154327d37d2  vmovaps xmm15, [rsp+0xE0]
00007154327d37db  add rsp, 0xF0
00007154327d37e2  pop r11
00007154327d37e4  pop r10
00007154327d37e6  pop r9
00007154327d37e8  pop r8
00007154327d37ea  pop rsi
00007154327d37eb  pop rdi
00007154327d37ec  pop rdx
00007154327d37ed  pop rcx
00007154327d37ee  pop rax
00007154327d37ef  add rsp, 0x08
00007154327d37f3  jmp 0x00007154327CFF34
00007154327d37f8  sub rsp, 0x08
00007154327d37fc  push rax
00007154327d37fd  push rcx
00007154327d37fe  push rdx
00007154327d37ff  push rdi
00007154327d3800  push rsi
00007154327d3801  push r8
00007154327d3803  push r9
00007154327d3805  push r10
00007154327d3807  push r11
00007154327d3809  sub rsp, 0xF0
00007154327d3810  vmovaps [rsp], xmm0
00007154327d3815  vmovaps [rsp+0x10], xmm1
00007154327d381b  vmovaps [rsp+0x20], xmm2
00007154327d3821  vmovaps [rsp+0x30], xmm3
00007154327d3827  vmovaps [rsp+0x40], xmm4
00007154327d382d  vmovaps [rsp+0x50], xmm5
00007154327d3833  vmovaps [rsp+0x60], xmm6
00007154327d3839  vmovaps [rsp+0x70], xmm7
00007154327d383f  vmovaps [rsp+0x80], xmm8
00007154327d3848  vmovaps [rsp+0x90], xmm9
00007154327d3851  vmovaps [rsp+0xA0], xmm10
00007154327d385a  vmovaps [rsp+0xB0], xmm11
00007154327d3863  vmovaps [rsp+0xC0], xmm12
00007154327d386c  vmovaps [rsp+0xD0], xmm13
00007154327d3875  vmovaps [rsp+0xE0], xmm14
00007154327d387e  sub rsp, 0x30
00007154327d3882  movaps [rsp], xmm15
00007154327d3887  movaps [rsp+0x10], xmm13
00007154327d388d  movaps [rsp+0x20], xmm10
00007154327d3893  lea rdi, [rsp]
00007154327d3897  mov esi, 0x00
00007154327d389c  mov rax, 0x5A63B06A5530
00007154327d38a6  call rax
00007154327d38a8  movaps xmm15, [rsp]
00007154327d38ad  add rsp, 0x30
00007154327d38b1  vmovaps xmm0, [rsp]
00007154327d38b6  vmovaps xmm1, [rsp+0x10]
00007154327d38bc  vmovaps xmm2, [rsp+0x20]
00007154327d38c2  vmovaps xmm3, [rsp+0x30]
00007154327d38c8  vmovaps xmm4, [rsp+0x40]
00007154327d38ce  vmovaps xmm5, [rsp+0x50]
00007154327d38d4  vmovaps xmm6, [rsp+0x60]
00007154327d38da  vmovaps xmm7, [rsp+0x70]
00007154327d38e0  vmovaps xmm8, [rsp+0x80]
00007154327d38e9  vmovaps xmm9, [rsp+0x90]
00007154327d38f2  vmovaps xmm10, [rsp+0xA0]
00007154327d38fb  vmovaps xmm11, [rsp+0xB0]
00007154327d3904  vmovaps xmm12, [rsp+0xC0]
00007154327d390d  vmovaps xmm13, [rsp+0xD0]
00007154327d3916  vmovaps xmm14, [rsp+0xE0]
00007154327d391f  add rsp, 0xF0
00007154327d3926  pop r11
00007154327d3928  pop r10
00007154327d392a  pop r9
00007154327d392c  pop r8
00007154327d392e  pop rsi
00007154327d392f  pop rdi
00007154327d3930  pop rdx
00007154327d3931  pop rcx
00007154327d3932  pop rax
00007154327d3933  add rsp, 0x08
00007154327d3937  jmp 0x00007154327CFF55
00007154327d393c  call 0x000071543260C260
00007154327d3941  jmp 0x00007154327CFFB0
00007154327d3946  sub rsp, 0x08
00007154327d394a  push rax
00007154327d394b  push rcx
00007154327d394c  push rdx
00007154327d394d  push rdi
00007154327d394e  push rsi
00007154327d394f  push r8
00007154327d3951  push r9
00007154327d3953  push r10
00007154327d3955  push r11
00007154327d3957  sub rsp, 0xF0
00007154327d395e  vmovaps [rsp], xmm0
00007154327d3963  vmovaps [rsp+0x10], xmm1
00007154327d3969  vmovaps [rsp+0x20], xmm2
00007154327d396f  vmovaps [rsp+0x30], xmm3
00007154327d3975  vmovaps [rsp+0x40], xmm4
00007154327d397b  vmovaps [rsp+0x50], xmm5
00007154327d3981  vmovaps [rsp+0x60], xmm6
00007154327d3987  vmovaps [rsp+0x70], xmm7
00007154327d398d  vmovaps [rsp+0x80], xmm8
00007154327d3996  vmovaps [rsp+0x90], xmm10
00007154327d399f  vmovaps [rsp+0xA0], xmm11
00007154327d39a8  vmovaps [rsp+0xB0], xmm12
00007154327d39b1  vmovaps [rsp+0xC0], xmm13
00007154327d39ba  vmovaps [rsp+0xD0], xmm14
00007154327d39c3  vmovaps [rsp+0xE0], xmm15
00007154327d39cc  sub rsp, 0x30
00007154327d39d0  movaps [rsp], xmm9
00007154327d39d5  movaps [rsp+0x10], xmm8
00007154327d39db  movaps [rsp+0x20], xmm10
00007154327d39e1  lea rdi, [rsp]
00007154327d39e5  mov esi, 0x00
00007154327d39ea  mov rax, 0x5A63B06A5530
00007154327d39f4  call rax
00007154327d39f6  movaps xmm9, [rsp]
00007154327d39fb  add rsp, 0x30
00007154327d39ff  vmovaps xmm0, [rsp]
00007154327d3a04  vmovaps xmm1, [rsp+0x10]
00007154327d3a0a  vmovaps xmm2, [rsp+0x20]
00007154327d3a10  vmovaps xmm3, [rsp+0x30]
00007154327d3a16  vmovaps xmm4, [rsp+0x40]
00007154327d3a1c  vmovaps xmm5, [rsp+0x50]
00007154327d3a22  vmovaps xmm6, [rsp+0x60]
00007154327d3a28  vmovaps xmm7, [rsp+0x70]
00007154327d3a2e  vmovaps xmm8, [rsp+0x80]
00007154327d3a37  vmovaps xmm10, [rsp+0x90]
00007154327d3a40  vmovaps xmm11, [rsp+0xA0]
00007154327d3a49  vmovaps xmm12, [rsp+0xB0]
00007154327d3a52  vmovaps xmm13, [rsp+0xC0]
00007154327d3a5b  vmovaps xmm14, [rsp+0xD0]
00007154327d3a64  vmovaps xmm15, [rsp+0xE0]
00007154327d3a6d  add rsp, 0xF0
00007154327d3a74  pop r11
00007154327d3a76  pop r10
00007154327d3a78  pop r9
00007154327d3a7a  pop r8
00007154327d3a7c  pop rsi
00007154327d3a7d  pop rdi
00007154327d3a7e  pop rdx
00007154327d3a7f  pop rcx
00007154327d3a80  pop rax
00007154327d3a81  add rsp, 0x08
00007154327d3a85  jmp 0x00007154327CFFE1
00007154327d3a8a  sub rsp, 0x08
00007154327d3a8e  push rax
00007154327d3a8f  push rcx
00007154327d3a90  push rdx
00007154327d3a91  push rdi
00007154327d3a92  push rsi
00007154327d3a93  push r8
00007154327d3a95  push r9
00007154327d3a97  push r10
00007154327d3a99  push r11
00007154327d3a9b  sub rsp, 0xF0
00007154327d3aa2  vmovaps [rsp], xmm0
00007154327d3aa7  vmovaps [rsp+0x10], xmm1
00007154327d3aad  vmovaps [rsp+0x20], xmm2
00007154327d3ab3  vmovaps [rsp+0x30], xmm3
00007154327d3ab9  vmovaps [rsp+0x40], xmm4
00007154327d3abf  vmovaps [rsp+0x50], xmm5
00007154327d3ac5  vmovaps [rsp+0x60], xmm6
00007154327d3acb  vmovaps [rsp+0x70], xmm7
00007154327d3ad1  vmovaps [rsp+0x80], xmm8
00007154327d3ada  vmovaps [rsp+0x90], xmm9
00007154327d3ae3  vmovaps [rsp+0xA0], xmm11
00007154327d3aec  vmovaps [rsp+0xB0], xmm12
00007154327d3af5  vmovaps [rsp+0xC0], xmm13
00007154327d3afe  vmovaps [rsp+0xD0], xmm14
00007154327d3b07  vmovaps [rsp+0xE0], xmm15
00007154327d3b10  sub rsp, 0x30
00007154327d3b14  movaps [rsp], xmm10
00007154327d3b19  movaps [rsp+0x10], xmm1
00007154327d3b1e  movaps [rsp+0x20], xmm11
00007154327d3b24  lea rdi, [rsp]
00007154327d3b28  mov esi, 0x00
00007154327d3b2d  mov rax, 0x5A63B06A5530
00007154327d3b37  call rax
00007154327d3b39  movaps xmm10, [rsp]
00007154327d3b3e  add rsp, 0x30
00007154327d3b42  vmovaps xmm0, [rsp]
00007154327d3b47  vmovaps xmm1, [rsp+0x10]
00007154327d3b4d  vmovaps xmm2, [rsp+0x20]
00007154327d3b53  vmovaps xmm3, [rsp+0x30]
00007154327d3b59  vmovaps xmm4, [rsp+0x40]
00007154327d3b5f  vmovaps xmm5, [rsp+0x50]
00007154327d3b65  vmovaps xmm6, [rsp+0x60]
00007154327d3b6b  vmovaps xmm7, [rsp+0x70]
00007154327d3b71  vmovaps xmm8, [rsp+0x80]
00007154327d3b7a  vmovaps xmm9, [rsp+0x90]
00007154327d3b83  vmovaps xmm11, [rsp+0xA0]
00007154327d3b8c  vmovaps xmm12, [rsp+0xB0]
00007154327d3b95  vmovaps xmm13, [rsp+0xC0]
00007154327d3b9e  vmovaps xmm14, [rsp+0xD0]
00007154327d3ba7  vmovaps xmm15, [rsp+0xE0]
00007154327d3bb0  add rsp, 0xF0
00007154327d3bb7  pop r11
00007154327d3bb9  pop r10
00007154327d3bbb  pop r9
00007154327d3bbd  pop r8
00007154327d3bbf  pop rsi
00007154327d3bc0  pop rdi
00007154327d3bc1  pop rdx
00007154327d3bc2  pop rcx
00007154327d3bc3  pop rax
00007154327d3bc4  add rsp, 0x08
00007154327d3bc8  jmp 0x00007154327CFFFC
00007154327d3bcd  sub rsp, 0x08
00007154327d3bd1  push rax
00007154327d3bd2  push rcx
00007154327d3bd3  push rdx
00007154327d3bd4  push rdi
00007154327d3bd5  push rsi
00007154327d3bd6  push r8
00007154327d3bd8  push r9
00007154327d3bda  push r10
00007154327d3bdc  push r11
00007154327d3bde  sub rsp, 0xF0
00007154327d3be5  vmovaps [rsp], xmm0
00007154327d3bea  vmovaps [rsp+0x10], xmm2
00007154327d3bf0  vmovaps [rsp+0x20], xmm3
00007154327d3bf6  vmovaps [rsp+0x30], xmm4
00007154327d3bfc  vmovaps [rsp+0x40], xmm5
00007154327d3c02  vmovaps [rsp+0x50], xmm6
00007154327d3c08  vmovaps [rsp+0x60], xmm7
00007154327d3c0e  vmovaps [rsp+0x70], xmm8
00007154327d3c14  vmovaps [rsp+0x80], xmm9
00007154327d3c1d  vmovaps [rsp+0x90], xmm10
00007154327d3c26  vmovaps [rsp+0xA0], xmm11
00007154327d3c2f  vmovaps [rsp+0xB0], xmm12
00007154327d3c38  vmovaps [rsp+0xC0], xmm13
00007154327d3c41  vmovaps [rsp+0xD0], xmm14
00007154327d3c4a  vmovaps [rsp+0xE0], xmm15
00007154327d3c53  sub rsp, 0x30
00007154327d3c57  movaps [rsp], xmm1
00007154327d3c5b  movaps [rsp+0x10], xmm14
00007154327d3c61  movaps [rsp+0x20], xmm6
00007154327d3c66  lea rdi, [rsp]
00007154327d3c6a  mov esi, 0x00
00007154327d3c6f  mov rax, 0x5A63B06A5530
00007154327d3c79  call rax
00007154327d3c7b  movaps xmm1, [rsp]
00007154327d3c7f  add rsp, 0x30
00007154327d3c83  vmovaps xmm0, [rsp]
00007154327d3c88  vmovaps xmm2, [rsp+0x10]
00007154327d3c8e  vmovaps xmm3, [rsp+0x20]
00007154327d3c94  vmovaps xmm4, [rsp+0x30]
00007154327d3c9a  vmovaps xmm5, [rsp+0x40]
00007154327d3ca0  vmovaps xmm6, [rsp+0x50]
00007154327d3ca6  vmovaps xmm7, [rsp+0x60]
00007154327d3cac  vmovaps xmm8, [rsp+0x70]
00007154327d3cb2  vmovaps xmm9, [rsp+0x80]
00007154327d3cbb  vmovaps xmm10, [rsp+0x90]
00007154327d3cc4  vmovaps xmm11, [rsp+0xA0]
00007154327d3ccd  vmovaps xmm12, [rsp+0xB0]
00007154327d3cd6  vmovaps xmm13, [rsp+0xC0]
00007154327d3cdf  vmovaps xmm14, [rsp+0xD0]
00007154327d3ce8  vmovaps xmm15, [rsp+0xE0]
00007154327d3cf1  add rsp, 0xF0
00007154327d3cf8  pop r11
00007154327d3cfa  pop r10
00007154327d3cfc  pop r9
00007154327d3cfe  pop r8
00007154327d3d00  pop rsi
00007154327d3d01  pop rdi
00007154327d3d02  pop rdx
00007154327d3d03  pop rcx
00007154327d3d04  pop rax
00007154327d3d05  add rsp, 0x08
00007154327d3d09  jmp 0x00007154327D0015
00007154327d3d0e  sub rsp, 0x08
00007154327d3d12  push rax
00007154327d3d13  push rcx
00007154327d3d14  push rdx
00007154327d3d15  push rdi
00007154327d3d16  push rsi
00007154327d3d17  push r8
00007154327d3d19  push r9
00007154327d3d1b  push r10
00007154327d3d1d  push r11
00007154327d3d1f  sub rsp, 0xF0
00007154327d3d26  vmovaps [rsp], xmm0
00007154327d3d2b  vmovaps [rsp+0x10], xmm1
00007154327d3d31  vmovaps [rsp+0x20], xmm2
00007154327d3d37  vmovaps [rsp+0x30], xmm3
00007154327d3d3d  vmovaps [rsp+0x40], xmm4
00007154327d3d43  vmovaps [rsp+0x50], xmm5
00007154327d3d49  vmovaps [rsp+0x60], xmm6
00007154327d3d4f  vmovaps [rsp+0x70], xmm7
00007154327d3d55  vmovaps [rsp+0x80], xmm8
00007154327d3d5e  vmovaps [rsp+0x90], xmm9
00007154327d3d67  vmovaps [rsp+0xA0], xmm10
00007154327d3d70  vmovaps [rsp+0xB0], xmm12
00007154327d3d79  vmovaps [rsp+0xC0], xmm13
00007154327d3d82  vmovaps [rsp+0xD0], xmm14
00007154327d3d8b  vmovaps [rsp+0xE0], xmm15
00007154327d3d94  sub rsp, 0x30
00007154327d3d98  movaps [rsp], xmm11
00007154327d3d9d  movaps [rsp+0x10], xmm13
00007154327d3da3  movaps [rsp+0x20], xmm14
00007154327d3da9  lea rdi, [rsp]
00007154327d3dad  mov esi, 0x00
00007154327d3db2  mov rax, 0x5A63B06A5530
00007154327d3dbc  call rax
00007154327d3dbe  movaps xmm11, [rsp]
00007154327d3dc3  add rsp, 0x30
00007154327d3dc7  vmovaps xmm0, [rsp]
00007154327d3dcc  vmovaps xmm1, [rsp+0x10]
00007154327d3dd2  vmovaps xmm2, [rsp+0x20]
00007154327d3dd8  vmovaps xmm3, [rsp+0x30]
00007154327d3dde  vmovaps xmm4, [rsp+0x40]
00007154327d3de4  vmovaps xmm5, [rsp+0x50]
00007154327d3dea  vmovaps xmm6, [rsp+0x60]
00007154327d3df0  vmovaps xmm7, [rsp+0x70]
00007154327d3df6  vmovaps xmm8, [rsp+0x80]
00007154327d3dff  vmovaps xmm9, [rsp+0x90]
00007154327d3e08  vmovaps xmm10, [rsp+0xA0]
00007154327d3e11  vmovaps xmm12, [rsp+0xB0]
00007154327d3e1a  vmovaps xmm13, [rsp+0xC0]
00007154327d3e23  vmovaps xmm14, [rsp+0xD0]
00007154327d3e2c  vmovaps xmm15, [rsp+0xE0]
00007154327d3e35  add rsp, 0xF0
00007154327d3e3c  pop r11
00007154327d3e3e  pop r10
00007154327d3e40  pop r9
00007154327d3e42  pop r8
00007154327d3e44  pop rsi
00007154327d3e45  pop rdi
00007154327d3e46  pop rdx
00007154327d3e47  pop rcx
00007154327d3e48  pop rax
00007154327d3e49  add rsp, 0x08
00007154327d3e4d  jmp 0x00007154327D003F
00007154327d3e52  sub rsp, 0x08
00007154327d3e56  push rax
00007154327d3e57  push rcx
00007154327d3e58  push rdx
00007154327d3e59  push rdi
00007154327d3e5a  push rsi
00007154327d3e5b  push r8
00007154327d3e5d  push r9
00007154327d3e5f  push r10
00007154327d3e61  push r11
00007154327d3e63  sub rsp, 0xF0
00007154327d3e6a  vmovaps [rsp], xmm0
00007154327d3e6f  vmovaps [rsp+0x10], xmm1
00007154327d3e75  vmovaps [rsp+0x20], xmm2
00007154327d3e7b  vmovaps [rsp+0x30], xmm3
00007154327d3e81  vmovaps [rsp+0x40], xmm4
00007154327d3e87  vmovaps [rsp+0x50], xmm5
00007154327d3e8d  vmovaps [rsp+0x60], xmm6
00007154327d3e93  vmovaps [rsp+0x70], xmm7
00007154327d3e99  vmovaps [rsp+0x80], xmm8
00007154327d3ea2  vmovaps [rsp+0x90], xmm9
00007154327d3eab  vmovaps [rsp+0xA0], xmm10
00007154327d3eb4  vmovaps [rsp+0xB0], xmm11
00007154327d3ebd  vmovaps [rsp+0xC0], xmm12
00007154327d3ec6  vmovaps [rsp+0xD0], xmm14
00007154327d3ecf  vmovaps [rsp+0xE0], xmm15
00007154327d3ed8  sub rsp, 0x30
00007154327d3edc  movaps [rsp], xmm13
00007154327d3ee1  movaps [rsp+0x10], xmm8
00007154327d3ee7  movaps [rsp+0x20], xmm14
00007154327d3eed  lea rdi, [rsp]
00007154327d3ef1  mov esi, 0x00
00007154327d3ef6  mov rax, 0x5A63B06A5530
00007154327d3f00  call rax
00007154327d3f02  movaps xmm13, [rsp]
00007154327d3f07  add rsp, 0x30
00007154327d3f0b  vmovaps xmm0, [rsp]
00007154327d3f10  vmovaps xmm1, [rsp+0x10]
00007154327d3f16  vmovaps xmm2, [rsp+0x20]
00007154327d3f1c  vmovaps xmm3, [rsp+0x30]
00007154327d3f22  vmovaps xmm4, [rsp+0x40]
00007154327d3f28  vmovaps xmm5, [rsp+0x50]
00007154327d3f2e  vmovaps xmm6, [rsp+0x60]
00007154327d3f34  vmovaps xmm7, [rsp+0x70]
00007154327d3f3a  vmovaps xmm8, [rsp+0x80]
00007154327d3f43  vmovaps xmm9, [rsp+0x90]
00007154327d3f4c  vmovaps xmm10, [rsp+0xA0]
00007154327d3f55  vmovaps xmm11, [rsp+0xB0]
00007154327d3f5e  vmovaps xmm12, [rsp+0xC0]
00007154327d3f67  vmovaps xmm14, [rsp+0xD0]
00007154327d3f70  vmovaps xmm15, [rsp+0xE0]
00007154327d3f79  add rsp, 0xF0
00007154327d3f80  pop r11
00007154327d3f82  pop r10
00007154327d3f84  pop r9
00007154327d3f86  pop r8
00007154327d3f88  pop rsi
00007154327d3f89  pop rdi
00007154327d3f8a  pop rdx
00007154327d3f8b  pop rcx
00007154327d3f8c  pop rax
00007154327d3f8d  add rsp, 0x08
00007154327d3f91  jmp 0x00007154327D006E
00007154327d3f96  sub rsp, 0x08
00007154327d3f9a  push rax
00007154327d3f9b  push rcx
00007154327d3f9c  push rdx
00007154327d3f9d  push rdi
00007154327d3f9e  push rsi
00007154327d3f9f  push r8
00007154327d3fa1  push r9
00007154327d3fa3  push r10
00007154327d3fa5  push r11
00007154327d3fa7  sub rsp, 0xF0
00007154327d3fae  vmovaps [rsp], xmm0
00007154327d3fb3  vmovaps [rsp+0x10], xmm1
00007154327d3fb9  vmovaps [rsp+0x20], xmm2
00007154327d3fbf  vmovaps [rsp+0x30], xmm3
00007154327d3fc5  vmovaps [rsp+0x40], xmm4
00007154327d3fcb  vmovaps [rsp+0x50], xmm5
00007154327d3fd1  vmovaps [rsp+0x60], xmm6
00007154327d3fd7  vmovaps [rsp+0x70], xmm7
00007154327d3fdd  vmovaps [rsp+0x80], xmm9
00007154327d3fe6  vmovaps [rsp+0x90], xmm10
00007154327d3fef  vmovaps [rsp+0xA0], xmm11
00007154327d3ff8  vmovaps [rsp+0xB0], xmm12
00007154327d4001  vmovaps [rsp+0xC0], xmm13
00007154327d400a  vmovaps [rsp+0xD0], xmm14
00007154327d4013  vmovaps [rsp+0xE0], xmm15
00007154327d401c  sub rsp, 0x30
00007154327d4020  movaps [rsp], xmm8
00007154327d4025  movaps [rsp+0x10], xmm7
00007154327d402a  movaps [rsp+0x20], xmm14
00007154327d4030  lea rdi, [rsp]
00007154327d4034  mov esi, 0x00
00007154327d4039  mov rax, 0x5A63B06A5530
00007154327d4043  call rax
00007154327d4045  movaps xmm8, [rsp]
00007154327d404a  add rsp, 0x30
00007154327d404e  vmovaps xmm0, [rsp]
00007154327d4053  vmovaps xmm1, [rsp+0x10]
00007154327d4059  vmovaps xmm2, [rsp+0x20]
00007154327d405f  vmovaps xmm3, [rsp+0x30]
00007154327d4065  vmovaps xmm4, [rsp+0x40]
00007154327d406b  vmovaps xmm5, [rsp+0x50]
00007154327d4071  vmovaps xmm6, [rsp+0x60]
00007154327d4077  vmovaps xmm7, [rsp+0x70]
00007154327d407d  vmovaps xmm9, [rsp+0x80]
00007154327d4086  vmovaps xmm10, [rsp+0x90]
00007154327d408f  vmovaps xmm11, [rsp+0xA0]
00007154327d4098  vmovaps xmm12, [rsp+0xB0]
00007154327d40a1  vmovaps xmm13, [rsp+0xC0]
00007154327d40aa  vmovaps xmm14, [rsp+0xD0]
00007154327d40b3  vmovaps xmm15, [rsp+0xE0]
00007154327d40bc  add rsp, 0xF0
00007154327d40c3  pop r11
00007154327d40c5  pop r10
00007154327d40c7  pop r9
00007154327d40c9  pop r8
00007154327d40cb  pop rsi
00007154327d40cc  pop rdi
00007154327d40cd  pop rdx
00007154327d40ce  pop rcx
00007154327d40cf  pop rax
00007154327d40d0  add rsp, 0x08
00007154327d40d4  jmp 0x00007154327D0094
00007154327d40d9  sub rsp, 0x08
00007154327d40dd  push rax
00007154327d40de  push rcx
00007154327d40df  push rdx
00007154327d40e0  push rdi
00007154327d40e1  push rsi
00007154327d40e2  push r8
00007154327d40e4  push r9
00007154327d40e6  push r10
00007154327d40e8  push r11
00007154327d40ea  sub rsp, 0xF0
00007154327d40f1  vmovaps [rsp], xmm0
00007154327d40f6  vmovaps [rsp+0x10], xmm1
00007154327d40fc  vmovaps [rsp+0x20], xmm2
00007154327d4102  vmovaps [rsp+0x30], xmm3
00007154327d4108  vmovaps [rsp+0x40], xmm4
00007154327d410e  vmovaps [rsp+0x50], xmm5
00007154327d4114  vmovaps [rsp+0x60], xmm6
00007154327d411a  vmovaps [rsp+0x70], xmm7
00007154327d4120  vmovaps [rsp+0x80], xmm8
00007154327d4129  vmovaps [rsp+0x90], xmm9
00007154327d4132  vmovaps [rsp+0xA0], xmm10
00007154327d413b  vmovaps [rsp+0xB0], xmm11
00007154327d4144  vmovaps [rsp+0xC0], xmm12
00007154327d414d  vmovaps [rsp+0xD0], xmm13
00007154327d4156  vmovaps [rsp+0xE0], xmm15
00007154327d415f  sub rsp, 0x30
00007154327d4163  movaps [rsp], xmm14
00007154327d4168  movaps [rsp+0x10], xmm12
00007154327d416e  movaps [rsp+0x20], xmm9
00007154327d4174  lea rdi, [rsp]
00007154327d4178  mov esi, 0x00
00007154327d417d  mov rax, 0x5A63B06A5530
00007154327d4187  call rax
00007154327d4189  movaps xmm14, [rsp]
00007154327d418e  add rsp, 0x30
00007154327d4192  vmovaps xmm0, [rsp]
00007154327d4197  vmovaps xmm1, [rsp+0x10]
00007154327d419d  vmovaps xmm2, [rsp+0x20]
00007154327d41a3  vmovaps xmm3, [rsp+0x30]
00007154327d41a9  vmovaps xmm4, [rsp+0x40]
00007154327d41af  vmovaps xmm5, [rsp+0x50]
00007154327d41b5  vmovaps xmm6, [rsp+0x60]
00007154327d41bb  vmovaps xmm7, [rsp+0x70]
00007154327d41c1  vmovaps xmm8, [rsp+0x80]
00007154327d41ca  vmovaps xmm9, [rsp+0x90]
00007154327d41d3  vmovaps xmm10, [rsp+0xA0]
00007154327d41dc  vmovaps xmm11, [rsp+0xB0]
00007154327d41e5  vmovaps xmm12, [rsp+0xC0]
00007154327d41ee  vmovaps xmm13, [rsp+0xD0]
00007154327d41f7  vmovaps xmm15, [rsp+0xE0]
00007154327d4200  add rsp, 0xF0
00007154327d4207  pop r11
00007154327d4209  pop r10
00007154327d420b  pop r9
00007154327d420d  pop r8
00007154327d420f  pop rsi
00007154327d4210  pop rdi
00007154327d4211  pop rdx
00007154327d4212  pop rcx
00007154327d4213  pop rax
00007154327d4214  add rsp, 0x08
00007154327d4218  jmp 0x00007154327D00AE
00007154327d421d  sub rsp, 0x08
00007154327d4221  push rax
00007154327d4222  push rcx
00007154327d4223  push rdx
00007154327d4224  push rdi
00007154327d4225  push rsi
00007154327d4226  push r8
00007154327d4228  push r9
00007154327d422a  push r10
00007154327d422c  push r11
00007154327d422e  sub rsp, 0xF0
00007154327d4235  vmovaps [rsp], xmm0
00007154327d423a  vmovaps [rsp+0x10], xmm1
00007154327d4240  vmovaps [rsp+0x20], xmm2
00007154327d4246  vmovaps [rsp+0x30], xmm3
00007154327d424c  vmovaps [rsp+0x40], xmm4
00007154327d4252  vmovaps [rsp+0x50], xmm5
00007154327d4258  vmovaps [rsp+0x60], xmm6
00007154327d425e  vmovaps [rsp+0x70], xmm7
00007154327d4264  vmovaps [rsp+0x80], xmm8
00007154327d426d  vmovaps [rsp+0x90], xmm10
00007154327d4276  vmovaps [rsp+0xA0], xmm11
00007154327d427f  vmovaps [rsp+0xB0], xmm12
00007154327d4288  vmovaps [rsp+0xC0], xmm13
00007154327d4291  vmovaps [rsp+0xD0], xmm14
00007154327d429a  vmovaps [rsp+0xE0], xmm15
00007154327d42a3  sub rsp, 0x30
00007154327d42a7  movaps [rsp], xmm9
00007154327d42ac  movaps [rsp+0x10], xmm7
00007154327d42b1  movaps [rsp+0x20], xmm12
00007154327d42b7  lea rdi, [rsp]
00007154327d42bb  mov esi, 0x00
00007154327d42c0  mov rax, 0x5A63B06A5530
00007154327d42ca  call rax
00007154327d42cc  movaps xmm9, [rsp]
00007154327d42d1  add rsp, 0x30
00007154327d42d5  vmovaps xmm0, [rsp]
00007154327d42da  vmovaps xmm1, [rsp+0x10]
00007154327d42e0  vmovaps xmm2, [rsp+0x20]
00007154327d42e6  vmovaps xmm3, [rsp+0x30]
00007154327d42ec  vmovaps xmm4, [rsp+0x40]
00007154327d42f2  vmovaps xmm5, [rsp+0x50]
00007154327d42f8  vmovaps xmm6, [rsp+0x60]
00007154327d42fe  vmovaps xmm7, [rsp+0x70]
00007154327d4304  vmovaps xmm8, [rsp+0x80]
00007154327d430d  vmovaps xmm10, [rsp+0x90]
00007154327d4316  vmovaps xmm11, [rsp+0xA0]
00007154327d431f  vmovaps xmm12, [rsp+0xB0]
00007154327d4328  vmovaps xmm13, [rsp+0xC0]
00007154327d4331  vmovaps xmm14, [rsp+0xD0]
00007154327d433a  vmovaps xmm15, [rsp+0xE0]
00007154327d4343  add rsp, 0xF0
00007154327d434a  pop r11
00007154327d434c  pop r10
00007154327d434e  pop r9
00007154327d4350  pop r8
00007154327d4352  pop rsi
00007154327d4353  pop rdi
00007154327d4354  pop rdx
00007154327d4355  pop rcx
00007154327d4356  pop rax
00007154327d4357  add rsp, 0x08
00007154327d435b  jmp 0x00007154327D00DD
00007154327d4360  sub rsp, 0x08
00007154327d4364  push rax
00007154327d4365  push rcx
00007154327d4366  push rdx
00007154327d4367  push rdi
00007154327d4368  push rsi
00007154327d4369  push r8
00007154327d436b  push r9
00007154327d436d  push r10
00007154327d436f  push r11
00007154327d4371  sub rsp, 0xF0
00007154327d4378  vmovaps [rsp], xmm0
00007154327d437d  vmovaps [rsp+0x10], xmm1
00007154327d4383  vmovaps [rsp+0x20], xmm2
00007154327d4389  vmovaps [rsp+0x30], xmm3
00007154327d438f  vmovaps [rsp+0x40], xmm4
00007154327d4395  vmovaps [rsp+0x50], xmm5
00007154327d439b  vmovaps [rsp+0x60], xmm6
00007154327d43a1  vmovaps [rsp+0x70], xmm7
00007154327d43a7  vmovaps [rsp+0x80], xmm8
00007154327d43b0  vmovaps [rsp+0x90], xmm9
00007154327d43b9  vmovaps [rsp+0xA0], xmm10
00007154327d43c2  vmovaps [rsp+0xB0], xmm11
00007154327d43cb  vmovaps [rsp+0xC0], xmm13
00007154327d43d4  vmovaps [rsp+0xD0], xmm14
00007154327d43dd  vmovaps [rsp+0xE0], xmm15
00007154327d43e6  sub rsp, 0x30
00007154327d43ea  movaps [rsp], xmm12
00007154327d43ef  movaps [rsp+0x10], xmm15
00007154327d43f5  movaps [rsp+0x20], xmm11
00007154327d43fb  lea rdi, [rsp]
00007154327d43ff  mov esi, 0x00
00007154327d4404  mov rax, 0x5A63B06A5530
00007154327d440e  call rax
00007154327d4410  movaps xmm12, [rsp]
00007154327d4415  add rsp, 0x30
00007154327d4419  vmovaps xmm0, [rsp]
00007154327d441e  vmovaps xmm1, [rsp+0x10]
00007154327d4424  vmovaps xmm2, [rsp+0x20]
00007154327d442a  vmovaps xmm3, [rsp+0x30]
00007154327d4430  vmovaps xmm4, [rsp+0x40]
00007154327d4436  vmovaps xmm5, [rsp+0x50]
00007154327d443c  vmovaps xmm6, [rsp+0x60]
00007154327d4442  vmovaps xmm7, [rsp+0x70]
00007154327d4448  vmovaps xmm8, [rsp+0x80]
00007154327d4451  vmovaps xmm9, [rsp+0x90]
00007154327d445a  vmovaps xmm10, [rsp+0xA0]
00007154327d4463  vmovaps xmm11, [rsp+0xB0]
00007154327d446c  vmovaps xmm13, [rsp+0xC0]
00007154327d4475  vmovaps xmm14, [rsp+0xD0]
00007154327d447e  vmovaps xmm15, [rsp+0xE0]
00007154327d4487  add rsp, 0xF0
00007154327d448e  pop r11
00007154327d4490  pop r10
00007154327d4492  pop r9
00007154327d4494  pop r8
00007154327d4496  pop rsi
00007154327d4497  pop rdi
00007154327d4498  pop rdx
00007154327d4499  pop rcx
00007154327d449a  pop rax
00007154327d449b  add rsp, 0x08
00007154327d449f  jmp 0x00007154327D00F7
00007154327d44a4  sub rsp, 0x08
00007154327d44a8  push rax
00007154327d44a9  push rcx
00007154327d44aa  push rdx
00007154327d44ab  push rdi
00007154327d44ac  push rsi
00007154327d44ad  push r8
00007154327d44af  push r9
00007154327d44b1  push r10
00007154327d44b3  push r11
00007154327d44b5  sub rsp, 0xF0
00007154327d44bc  vmovaps [rsp], xmm0
00007154327d44c1  vmovaps [rsp+0x10], xmm1
00007154327d44c7  vmovaps [rsp+0x20], xmm2
00007154327d44cd  vmovaps [rsp+0x30], xmm3
00007154327d44d3  vmovaps [rsp+0x40], xmm4
00007154327d44d9  vmovaps [rsp+0x50], xmm5
00007154327d44df  vmovaps [rsp+0x60], xmm6
00007154327d44e5  vmovaps [rsp+0x70], xmm7
00007154327d44eb  vmovaps [rsp+0x80], xmm8
00007154327d44f4  vmovaps [rsp+0x90], xmm9
00007154327d44fd  vmovaps [rsp+0xA0], xmm10
00007154327d4506  vmovaps [rsp+0xB0], xmm12
00007154327d450f  vmovaps [rsp+0xC0], xmm13
00007154327d4518  vmovaps [rsp+0xD0], xmm14
00007154327d4521  vmovaps [rsp+0xE0], xmm15
00007154327d452a  sub rsp, 0x30
00007154327d452e  movaps [rsp], xmm11
00007154327d4533  movaps [rsp+0x10], xmm7
00007154327d4538  movaps [rsp+0x20], xmm15
00007154327d453e  lea rdi, [rsp]
00007154327d4542  mov esi, 0x00
00007154327d4547  mov rax, 0x5A63B06A5530
00007154327d4551  call rax
00007154327d4553  movaps xmm11, [rsp]
00007154327d4558  add rsp, 0x30
00007154327d455c  vmovaps xmm0, [rsp]
00007154327d4561  vmovaps xmm1, [rsp+0x10]
00007154327d4567  vmovaps xmm2, [rsp+0x20]
00007154327d456d  vmovaps xmm3, [rsp+0x30]
00007154327d4573  vmovaps xmm4, [rsp+0x40]
00007154327d4579  vmovaps xmm5, [rsp+0x50]
00007154327d457f  vmovaps xmm6, [rsp+0x60]
00007154327d4585  vmovaps xmm7, [rsp+0x70]
00007154327d458b  vmovaps xmm8, [rsp+0x80]
00007154327d4594  vmovaps xmm9, [rsp+0x90]
00007154327d459d  vmovaps xmm10, [rsp+0xA0]
00007154327d45a6  vmovaps xmm12, [rsp+0xB0]
00007154327d45af  vmovaps xmm13, [rsp+0xC0]
00007154327d45b8  vmovaps xmm14, [rsp+0xD0]
00007154327d45c1  vmovaps xmm15, [rsp+0xE0]
00007154327d45ca  add rsp, 0xF0
00007154327d45d1  pop r11
00007154327d45d3  pop r10
00007154327d45d5  pop r9
00007154327d45d7  pop r8
00007154327d45d9  pop rsi
00007154327d45da  pop rdi
00007154327d45db  pop rdx
00007154327d45dc  pop rcx
00007154327d45dd  pop rax
00007154327d45de  add rsp, 0x08
00007154327d45e2  jmp 0x00007154327D0123
00007154327d45e7  sub rsp, 0x08
00007154327d45eb  push rax
00007154327d45ec  push rcx
00007154327d45ed  push rdx
00007154327d45ee  push rdi
00007154327d45ef  push rsi
00007154327d45f0  push r8
00007154327d45f2  push r9
00007154327d45f4  push r10
00007154327d45f6  push r11
00007154327d45f8  sub rsp, 0xF0
00007154327d45ff  vmovaps [rsp], xmm0
00007154327d4604  vmovaps [rsp+0x10], xmm1
00007154327d460a  vmovaps [rsp+0x20], xmm2
00007154327d4610  vmovaps [rsp+0x30], xmm3
00007154327d4616  vmovaps [rsp+0x40], xmm4
00007154327d461c  vmovaps [rsp+0x50], xmm5
00007154327d4622  vmovaps [rsp+0x60], xmm6
00007154327d4628  vmovaps [rsp+0x70], xmm7
00007154327d462e  vmovaps [rsp+0x80], xmm8
00007154327d4637  vmovaps [rsp+0x90], xmm9
00007154327d4640  vmovaps [rsp+0xA0], xmm10
00007154327d4649  vmovaps [rsp+0xB0], xmm11
00007154327d4652  vmovaps [rsp+0xC0], xmm12
00007154327d465b  vmovaps [rsp+0xD0], xmm13
00007154327d4664  vmovaps [rsp+0xE0], xmm14
00007154327d466d  sub rsp, 0x30
00007154327d4671  movaps [rsp], xmm15
00007154327d4676  movaps [rsp+0x10], xmm10
00007154327d467c  movaps [rsp+0x20], xmm13
00007154327d4682  lea rdi, [rsp]
00007154327d4686  mov esi, 0x00
00007154327d468b  mov rax, 0x5A63B06A5530
00007154327d4695  call rax
00007154327d4697  movaps xmm15, [rsp]
00007154327d469c  add rsp, 0x30
00007154327d46a0  vmovaps xmm0, [rsp]
00007154327d46a5  vmovaps xmm1, [rsp+0x10]
00007154327d46ab  vmovaps xmm2, [rsp+0x20]
00007154327d46b1  vmovaps xmm3, [rsp+0x30]
00007154327d46b7  vmovaps xmm4, [rsp+0x40]
00007154327d46bd  vmovaps xmm5, [rsp+0x50]
00007154327d46c3  vmovaps xmm6, [rsp+0x60]
00007154327d46c9  vmovaps xmm7, [rsp+0x70]
00007154327d46cf  vmovaps xmm8, [rsp+0x80]
00007154327d46d8  vmovaps xmm9, [rsp+0x90]
00007154327d46e1  vmovaps xmm10, [rsp+0xA0]
00007154327d46ea  vmovaps xmm11, [rsp+0xB0]
00007154327d46f3  vmovaps xmm12, [rsp+0xC0]
00007154327d46fc  vmovaps xmm13, [rsp+0xD0]
00007154327d4705  vmovaps xmm14, [rsp+0xE0]
00007154327d470e  add rsp, 0xF0
00007154327d4715  pop r11
00007154327d4717  pop r10
00007154327d4719  pop r9
00007154327d471b  pop r8
00007154327d471d  pop rsi
00007154327d471e  pop rdi
00007154327d471f  pop rdx
00007154327d4720  pop rcx
00007154327d4721  pop rax
00007154327d4722  add rsp, 0x08
00007154327d4726  jmp 0x00007154327D013D
00007154327d472b  sub rsp, 0x08
00007154327d472f  push rax
00007154327d4730  push rcx
00007154327d4731  push rdx
00007154327d4732  push rdi
00007154327d4733  push rsi
00007154327d4734  push r8
00007154327d4736  push r9
00007154327d4738  push r10
00007154327d473a  push r11
00007154327d473c  sub rsp, 0xF0
00007154327d4743  vmovaps [rsp], xmm0
00007154327d4748  vmovaps [rsp+0x10], xmm1
00007154327d474e  vmovaps [rsp+0x20], xmm2
00007154327d4754  vmovaps [rsp+0x30], xmm3
00007154327d475a  vmovaps [rsp+0x40], xmm4
00007154327d4760  vmovaps [rsp+0x50], xmm5
00007154327d4766  vmovaps [rsp+0x60], xmm6
00007154327d476c  vmovaps [rsp+0x70], xmm7
00007154327d4772  vmovaps [rsp+0x80], xmm8
00007154327d477b  vmovaps [rsp+0x90], xmm9
00007154327d4784  vmovaps [rsp+0xA0], xmm11
00007154327d478d  vmovaps [rsp+0xB0], xmm12
00007154327d4796  vmovaps [rsp+0xC0], xmm13
00007154327d479f  vmovaps [rsp+0xD0], xmm14
00007154327d47a8  vmovaps [rsp+0xE0], xmm15
00007154327d47b1  sub rsp, 0x30
00007154327d47b5  movaps [rsp], xmm10
00007154327d47ba  movaps [rsp+0x10], xmm7
00007154327d47bf  movaps [rsp+0x20], xmm13
00007154327d47c5  lea rdi, [rsp]
00007154327d47c9  mov esi, 0x00
00007154327d47ce  mov rax, 0x5A63B06A5530
00007154327d47d8  call rax
00007154327d47da  movaps xmm10, [rsp]
00007154327d47df  add rsp, 0x30
00007154327d47e3  vmovaps xmm0, [rsp]
00007154327d47e8  vmovaps xmm1, [rsp+0x10]
00007154327d47ee  vmovaps xmm2, [rsp+0x20]
00007154327d47f4  vmovaps xmm3, [rsp+0x30]
00007154327d47fa  vmovaps xmm4, [rsp+0x40]
00007154327d4800  vmovaps xmm5, [rsp+0x50]
00007154327d4806  vmovaps xmm6, [rsp+0x60]
00007154327d480c  vmovaps xmm7, [rsp+0x70]
00007154327d4812  vmovaps xmm8, [rsp+0x80]
00007154327d481b  vmovaps xmm9, [rsp+0x90]
00007154327d4824  vmovaps xmm11, [rsp+0xA0]
00007154327d482d  vmovaps xmm12, [rsp+0xB0]
00007154327d4836  vmovaps xmm13, [rsp+0xC0]
00007154327d483f  vmovaps xmm14, [rsp+0xD0]
00007154327d4848  vmovaps xmm15, [rsp+0xE0]
00007154327d4851  add rsp, 0xF0
00007154327d4858  pop r11
00007154327d485a  pop r10
00007154327d485c  pop r9
00007154327d485e  pop r8
00007154327d4860  pop rsi
00007154327d4861  pop rdi
00007154327d4862  pop rdx
00007154327d4863  pop rcx
00007154327d4864  pop rax
00007154327d4865  add rsp, 0x08
00007154327d4869  jmp 0x00007154327D0169
00007154327d486e  sub rsp, 0x08
00007154327d4872  push rax
00007154327d4873  push rcx
00007154327d4874  push rdx
00007154327d4875  push rdi
00007154327d4876  push rsi
00007154327d4877  push r8
00007154327d4879  push r9
00007154327d487b  push r10
00007154327d487d  push r11
00007154327d487f  sub rsp, 0xF0
00007154327d4886  vmovaps [rsp], xmm0
00007154327d488b  vmovaps [rsp+0x10], xmm1
00007154327d4891  vmovaps [rsp+0x20], xmm2
00007154327d4897  vmovaps [rsp+0x30], xmm3
00007154327d489d  vmovaps [rsp+0x40], xmm4
00007154327d48a3  vmovaps [rsp+0x50], xmm5
00007154327d48a9  vmovaps [rsp+0x60], xmm6
00007154327d48af  vmovaps [rsp+0x70], xmm7
00007154327d48b5  vmovaps [rsp+0x80], xmm8
00007154327d48be  vmovaps [rsp+0x90], xmm9
00007154327d48c7  vmovaps [rsp+0xA0], xmm10
00007154327d48d0  vmovaps [rsp+0xB0], xmm11
00007154327d48d9  vmovaps [rsp+0xC0], xmm12
00007154327d48e2  vmovaps [rsp+0xD0], xmm14
00007154327d48eb  vmovaps [rsp+0xE0], xmm15
00007154327d48f4  sub rsp, 0x30
00007154327d48f8  movaps [rsp], xmm13
00007154327d48fd  movaps [rsp+0x10], xmm1
00007154327d4902  movaps [rsp+0x20], xmm8
00007154327d4908  lea rdi, [rsp]
00007154327d490c  mov esi, 0x00
00007154327d4911  mov rax, 0x5A63B06A5530
00007154327d491b  call rax
00007154327d491d  movaps xmm13, [rsp]
00007154327d4922  add rsp, 0x30
00007154327d4926  vmovaps xmm0, [rsp]
00007154327d492b  vmovaps xmm1, [rsp+0x10]
00007154327d4931  vmovaps xmm2, [rsp+0x20]
00007154327d4937  vmovaps xmm3, [rsp+0x30]
00007154327d493d  vmovaps xmm4, [rsp+0x40]
00007154327d4943  vmovaps xmm5, [rsp+0x50]
00007154327d4949  vmovaps xmm6, [rsp+0x60]
00007154327d494f  vmovaps xmm7, [rsp+0x70]
00007154327d4955  vmovaps xmm8, [rsp+0x80]
00007154327d495e  vmovaps xmm9, [rsp+0x90]
00007154327d4967  vmovaps xmm10, [rsp+0xA0]
00007154327d4970  vmovaps xmm11, [rsp+0xB0]
00007154327d4979  vmovaps xmm12, [rsp+0xC0]
00007154327d4982  vmovaps xmm14, [rsp+0xD0]
00007154327d498b  vmovaps xmm15, [rsp+0xE0]
00007154327d4994  add rsp, 0xF0
00007154327d499b  pop r11
00007154327d499d  pop r10
00007154327d499f  pop r9
00007154327d49a1  pop r8
00007154327d49a3  pop rsi
00007154327d49a4  pop rdi
00007154327d49a5  pop rdx
00007154327d49a6  pop rcx
00007154327d49a7  pop rax
00007154327d49a8  add rsp, 0x08
00007154327d49ac  jmp 0x00007154327D0183
00007154327d49b1  call 0x00007154325FF430
00007154327d49b6  jmp 0x00007154327D018D
00007154327d49bb  sub rsp, 0x08
00007154327d49bf  push rax
00007154327d49c0  push rcx
00007154327d49c1  push rdx
00007154327d49c2  push rdi
00007154327d49c3  push rsi
00007154327d49c4  push r8
00007154327d49c6  push r9
00007154327d49c8  push r10
00007154327d49ca  push r11
00007154327d49cc  sub rsp, 0xF0
00007154327d49d3  vmovaps [rsp], xmm0
00007154327d49d8  vmovaps [rsp+0x10], xmm1
00007154327d49de  vmovaps [rsp+0x20], xmm2
00007154327d49e4  vmovaps [rsp+0x30], xmm3
00007154327d49ea  vmovaps [rsp+0x40], xmm4
00007154327d49f0  vmovaps [rsp+0x50], xmm5
00007154327d49f6  vmovaps [rsp+0x60], xmm6
00007154327d49fc  vmovaps [rsp+0x70], xmm7
00007154327d4a02  vmovaps [rsp+0x80], xmm9
00007154327d4a0b  vmovaps [rsp+0x90], xmm10
00007154327d4a14  vmovaps [rsp+0xA0], xmm11
00007154327d4a1d  vmovaps [rsp+0xB0], xmm12
00007154327d4a26  vmovaps [rsp+0xC0], xmm13
00007154327d4a2f  vmovaps [rsp+0xD0], xmm14
00007154327d4a38  vmovaps [rsp+0xE0], xmm15
00007154327d4a41  sub rsp, 0x30
00007154327d4a45  movaps [rsp], xmm8
00007154327d4a4a  movaps [rsp+0x10], xmm14
00007154327d4a50  movaps [rsp+0x20], xmm9
00007154327d4a56  lea rdi, [rsp]
00007154327d4a5a  mov esi, 0x00
00007154327d4a5f  mov rax, 0x5A63B06A5530
00007154327d4a69  call rax
00007154327d4a6b  movaps xmm8, [rsp]
00007154327d4a70  add rsp, 0x30
00007154327d4a74  vmovaps xmm0, [rsp]
00007154327d4a79  vmovaps xmm1, [rsp+0x10]
00007154327d4a7f  vmovaps xmm2, [rsp+0x20]
00007154327d4a85  vmovaps xmm3, [rsp+0x30]
00007154327d4a8b  vmovaps xmm4, [rsp+0x40]
00007154327d4a91  vmovaps xmm5, [rsp+0x50]
00007154327d4a97  vmovaps xmm6, [rsp+0x60]
00007154327d4a9d  vmovaps xmm7, [rsp+0x70]
00007154327d4aa3  vmovaps xmm9, [rsp+0x80]
00007154327d4aac  vmovaps xmm10, [rsp+0x90]
00007154327d4ab5  vmovaps xmm11, [rsp+0xA0]
00007154327d4abe  vmovaps xmm12, [rsp+0xB0]
00007154327d4ac7  vmovaps xmm13, [rsp+0xC0]
00007154327d4ad0  vmovaps xmm14, [rsp+0xD0]
00007154327d4ad9  vmovaps xmm15, [rsp+0xE0]
00007154327d4ae2  add rsp, 0xF0
00007154327d4ae9  pop r11
00007154327d4aeb  pop r10
00007154327d4aed  pop r9
00007154327d4aef  pop r8
00007154327d4af1  pop rsi
00007154327d4af2  pop rdi
00007154327d4af3  pop rdx
00007154327d4af4  pop rcx
00007154327d4af5  pop rax
00007154327d4af6  add rsp, 0x08
00007154327d4afa  jmp 0x00007154327D01AF
00007154327d4aff  sub rsp, 0x08
00007154327d4b03  push rax
00007154327d4b04  push rcx
00007154327d4b05  push rdx
00007154327d4b06  push rdi
00007154327d4b07  push rsi
00007154327d4b08  push r8
00007154327d4b0a  push r9
00007154327d4b0c  push r10
00007154327d4b0e  push r11
00007154327d4b10  sub rsp, 0xF0
00007154327d4b17  vmovaps [rsp], xmm0
00007154327d4b1c  vmovaps [rsp+0x10], xmm1
00007154327d4b22  vmovaps [rsp+0x20], xmm2
00007154327d4b28  vmovaps [rsp+0x30], xmm3
00007154327d4b2e  vmovaps [rsp+0x40], xmm4
00007154327d4b34  vmovaps [rsp+0x50], xmm5
00007154327d4b3a  vmovaps [rsp+0x60], xmm6
00007154327d4b40  vmovaps [rsp+0x70], xmm7
00007154327d4b46  vmovaps [rsp+0x80], xmm8
00007154327d4b4f  vmovaps [rsp+0x90], xmm10
00007154327d4b58  vmovaps [rsp+0xA0], xmm11
00007154327d4b61  vmovaps [rsp+0xB0], xmm12
00007154327d4b6a  vmovaps [rsp+0xC0], xmm13
00007154327d4b73  vmovaps [rsp+0xD0], xmm14
00007154327d4b7c  vmovaps [rsp+0xE0], xmm15
00007154327d4b85  sub rsp, 0x30
00007154327d4b89  movaps [rsp], xmm9
00007154327d4b8e  movaps [rsp+0x10], xmm1
00007154327d4b93  movaps [rsp+0x20], xmm14
00007154327d4b99  lea rdi, [rsp]
00007154327d4b9d  mov esi, 0x00
00007154327d4ba2  mov rax, 0x5A63B06A5530
00007154327d4bac  call rax
00007154327d4bae  movaps xmm9, [rsp]
00007154327d4bb3  add rsp, 0x30
00007154327d4bb7  vmovaps xmm0, [rsp]
00007154327d4bbc  vmovaps xmm1, [rsp+0x10]
00007154327d4bc2  vmovaps xmm2, [rsp+0x20]
00007154327d4bc8  vmovaps xmm3, [rsp+0x30]
00007154327d4bce  vmovaps xmm4, [rsp+0x40]
00007154327d4bd4  vmovaps xmm5, [rsp+0x50]
00007154327d4bda  vmovaps xmm6, [rsp+0x60]
00007154327d4be0  vmovaps xmm7, [rsp+0x70]
00007154327d4be6  vmovaps xmm8, [rsp+0x80]
00007154327d4bef  vmovaps xmm10, [rsp+0x90]
00007154327d4bf8  vmovaps xmm11, [rsp+0xA0]
00007154327d4c01  vmovaps xmm12, [rsp+0xB0]
00007154327d4c0a  vmovaps xmm13, [rsp+0xC0]
00007154327d4c13  vmovaps xmm14, [rsp+0xD0]
00007154327d4c1c  vmovaps xmm15, [rsp+0xE0]
00007154327d4c25  add rsp, 0xF0
00007154327d4c2c  pop r11
00007154327d4c2e  pop r10
00007154327d4c30  pop r9
00007154327d4c32  pop r8
00007154327d4c34  pop rsi
00007154327d4c35  pop rdi
00007154327d4c36  pop rdx
00007154327d4c37  pop rcx
00007154327d4c38  pop rax
00007154327d4c39  add rsp, 0x08
00007154327d4c3d  jmp 0x00007154327D01DD
00007154327d4c42  sub rsp, 0x08
00007154327d4c46  push rax
00007154327d4c47  push rcx
00007154327d4c48  push rdx
00007154327d4c49  push rdi
00007154327d4c4a  push rsi
00007154327d4c4b  push r8
00007154327d4c4d  push r9
00007154327d4c4f  push r10
00007154327d4c51  push r11
00007154327d4c53  sub rsp, 0xF0
00007154327d4c5a  vmovaps [rsp], xmm0
00007154327d4c5f  vmovaps [rsp+0x10], xmm1
00007154327d4c65  vmovaps [rsp+0x20], xmm2
00007154327d4c6b  vmovaps [rsp+0x30], xmm3
00007154327d4c71  vmovaps [rsp+0x40], xmm4
00007154327d4c77  vmovaps [rsp+0x50], xmm5
00007154327d4c7d  vmovaps [rsp+0x60], xmm6
00007154327d4c83  vmovaps [rsp+0x70], xmm7
00007154327d4c89  vmovaps [rsp+0x80], xmm8
00007154327d4c92  vmovaps [rsp+0x90], xmm9
00007154327d4c9b  vmovaps [rsp+0xA0], xmm10
00007154327d4ca4  vmovaps [rsp+0xB0], xmm11
00007154327d4cad  vmovaps [rsp+0xC0], xmm12
00007154327d4cb6  vmovaps [rsp+0xD0], xmm13
00007154327d4cbf  vmovaps [rsp+0xE0], xmm15
00007154327d4cc8  sub rsp, 0x30
00007154327d4ccc  movaps [rsp], xmm14
00007154327d4cd1  movaps [rsp+0x10], xmm4
00007154327d4cd6  movaps [rsp+0x20], xmm1
00007154327d4cdb  lea rdi, [rsp]
00007154327d4cdf  mov esi, 0x00
00007154327d4ce4  mov rax, 0x5A63B06A5530
00007154327d4cee  call rax
00007154327d4cf0  movaps xmm14, [rsp]
00007154327d4cf5  add rsp, 0x30
00007154327d4cf9  vmovaps xmm0, [rsp]
00007154327d4cfe  vmovaps xmm1, [rsp+0x10]
00007154327d4d04  vmovaps xmm2, [rsp+0x20]
00007154327d4d0a  vmovaps xmm3, [rsp+0x30]
00007154327d4d10  vmovaps xmm4, [rsp+0x40]
00007154327d4d16  vmovaps xmm5, [rsp+0x50]
00007154327d4d1c  vmovaps xmm6, [rsp+0x60]
00007154327d4d22  vmovaps xmm7, [rsp+0x70]
00007154327d4d28  vmovaps xmm8, [rsp+0x80]
00007154327d4d31  vmovaps xmm9, [rsp+0x90]
00007154327d4d3a  vmovaps xmm10, [rsp+0xA0]
00007154327d4d43  vmovaps xmm11, [rsp+0xB0]
00007154327d4d4c  vmovaps xmm12, [rsp+0xC0]
00007154327d4d55  vmovaps xmm13, [rsp+0xD0]
00007154327d4d5e  vmovaps xmm15, [rsp+0xE0]
00007154327d4d67  add rsp, 0xF0
00007154327d4d6e  pop r11
00007154327d4d70  pop r10
00007154327d4d72  pop r9
00007154327d4d74  pop r8
00007154327d4d76  pop rsi
00007154327d4d77  pop rdi
00007154327d4d78  pop rdx
00007154327d4d79  pop rcx
00007154327d4d7a  pop rax
00007154327d4d7b  add rsp, 0x08
00007154327d4d7f  jmp 0x00007154327D0203
00007154327d4d84  sub rsp, 0x08
00007154327d4d88  push rax
00007154327d4d89  push rcx
00007154327d4d8a  push rdx
00007154327d4d8b  push rdi
00007154327d4d8c  push rsi
00007154327d4d8d  push r8
00007154327d4d8f  push r9
00007154327d4d91  push r10
00007154327d4d93  push r11
00007154327d4d95  sub rsp, 0xF0
00007154327d4d9c  vmovaps [rsp], xmm0
00007154327d4da1  vmovaps [rsp+0x10], xmm2
00007154327d4da7  vmovaps [rsp+0x20], xmm3
00007154327d4dad  vmovaps [rsp+0x30], xmm4
00007154327d4db3  vmovaps [rsp+0x40], xmm5
00007154327d4db9  vmovaps [rsp+0x50], xmm6
00007154327d4dbf  vmovaps [rsp+0x60], xmm7
00007154327d4dc5  vmovaps [rsp+0x70], xmm8
00007154327d4dcb  vmovaps [rsp+0x80], xmm9
00007154327d4dd4  vmovaps [rsp+0x90], xmm10
00007154327d4ddd  vmovaps [rsp+0xA0], xmm11
00007154327d4de6  vmovaps [rsp+0xB0], xmm12
00007154327d4def  vmovaps [rsp+0xC0], xmm13
00007154327d4df8  vmovaps [rsp+0xD0], xmm14
00007154327d4e01  vmovaps [rsp+0xE0], xmm15
00007154327d4e0a  sub rsp, 0x30
00007154327d4e0e  movaps [rsp], xmm1
00007154327d4e12  movaps [rsp+0x10], xmm12
00007154327d4e18  movaps [rsp+0x20], xmm11
00007154327d4e1e  lea rdi, [rsp]
00007154327d4e22  mov esi, 0x00
00007154327d4e27  mov rax, 0x5A63B06A5530
00007154327d4e31  call rax
00007154327d4e33  movaps xmm1, [rsp]
00007154327d4e37  add rsp, 0x30
00007154327d4e3b  vmovaps xmm0, [rsp]
00007154327d4e40  vmovaps xmm2, [rsp+0x10]
00007154327d4e46  vmovaps xmm3, [rsp+0x20]
00007154327d4e4c  vmovaps xmm4, [rsp+0x30]
00007154327d4e52  vmovaps xmm5, [rsp+0x40]
00007154327d4e58  vmovaps xmm6, [rsp+0x50]
00007154327d4e5e  vmovaps xmm7, [rsp+0x60]
00007154327d4e64  vmovaps xmm8, [rsp+0x70]
00007154327d4e6a  vmovaps xmm9, [rsp+0x80]
00007154327d4e73  vmovaps xmm10, [rsp+0x90]
00007154327d4e7c  vmovaps xmm11, [rsp+0xA0]
00007154327d4e85  vmovaps xmm12, [rsp+0xB0]
00007154327d4e8e  vmovaps xmm13, [rsp+0xC0]
00007154327d4e97  vmovaps xmm14, [rsp+0xD0]
00007154327d4ea0  vmovaps xmm15, [rsp+0xE0]
00007154327d4ea9  add rsp, 0xF0
00007154327d4eb0  pop r11
00007154327d4eb2  pop r10
00007154327d4eb4  pop r9
00007154327d4eb6  pop r8
00007154327d4eb8  pop rsi
00007154327d4eb9  pop rdi
00007154327d4eba  pop rdx
00007154327d4ebb  pop rcx
00007154327d4ebc  pop rax
00007154327d4ebd  add rsp, 0x08
00007154327d4ec1  jmp 0x00007154327D0224
00007154327d4ec6  call 0x00007154326E20A0
00007154327d4ecb  jmp 0x00007154327D0232
00007154327d4ed0  call 0x0000715432609D70
00007154327d4ed5  jmp 0x00007154327D023C
00007154327d4eda  sub rsp, 0x08
00007154327d4ede  push rax
00007154327d4edf  push rcx
00007154327d4ee0  push rdx
00007154327d4ee1  push rdi
00007154327d4ee2  push rsi
00007154327d4ee3  push r8
00007154327d4ee5  push r9
00007154327d4ee7  push r10
00007154327d4ee9  push r11
00007154327d4eeb  sub rsp, 0xF0
00007154327d4ef2  vmovaps [rsp], xmm0
00007154327d4ef7  vmovaps [rsp+0x10], xmm1
00007154327d4efd  vmovaps [rsp+0x20], xmm2
00007154327d4f03  vmovaps [rsp+0x30], xmm3
00007154327d4f09  vmovaps [rsp+0x40], xmm4
00007154327d4f0f  vmovaps [rsp+0x50], xmm5
00007154327d4f15  vmovaps [rsp+0x60], xmm6
00007154327d4f1b  vmovaps [rsp+0x70], xmm8
00007154327d4f21  vmovaps [rsp+0x80], xmm9
00007154327d4f2a  vmovaps [rsp+0x90], xmm10
00007154327d4f33  vmovaps [rsp+0xA0], xmm11
00007154327d4f3c  vmovaps [rsp+0xB0], xmm12
00007154327d4f45  vmovaps [rsp+0xC0], xmm13
00007154327d4f4e  vmovaps [rsp+0xD0], xmm14
00007154327d4f57  vmovaps [rsp+0xE0], xmm15
00007154327d4f60  sub rsp, 0x30
00007154327d4f64  movaps [rsp], xmm7
00007154327d4f68  movaps [rsp+0x10], xmm15
00007154327d4f6e  movaps [rsp+0x20], xmm10
00007154327d4f74  lea rdi, [rsp]
00007154327d4f78  mov esi, 0x00
00007154327d4f7d  mov rax, 0x5A63B06A5530
00007154327d4f87  call rax
00007154327d4f89  movaps xmm7, [rsp]
00007154327d4f8d  add rsp, 0x30
00007154327d4f91  vmovaps xmm0, [rsp]
00007154327d4f96  vmovaps xmm1, [rsp+0x10]
00007154327d4f9c  vmovaps xmm2, [rsp+0x20]
00007154327d4fa2  vmovaps xmm3, [rsp+0x30]
00007154327d4fa8  vmovaps xmm4, [rsp+0x40]
00007154327d4fae  vmovaps xmm5, [rsp+0x50]
00007154327d4fb4  vmovaps xmm6, [rsp+0x60]
00007154327d4fba  vmovaps xmm8, [rsp+0x70]
00007154327d4fc0  vmovaps xmm9, [rsp+0x80]
00007154327d4fc9  vmovaps xmm10, [rsp+0x90]
00007154327d4fd2  vmovaps xmm11, [rsp+0xA0]
00007154327d4fdb  vmovaps xmm12, [rsp+0xB0]
00007154327d4fe4  vmovaps xmm13, [rsp+0xC0]
00007154327d4fed  vmovaps xmm14, [rsp+0xD0]
00007154327d4ff6  vmovaps xmm15, [rsp+0xE0]
00007154327d4fff  add rsp, 0xF0
00007154327d5006  pop r11
00007154327d5008  pop r10
00007154327d500a  pop r9
00007154327d500c  pop r8
00007154327d500e  pop rsi
00007154327d500f  pop rdi
00007154327d5010  pop rdx
00007154327d5011  pop rcx
00007154327d5012  pop rax
00007154327d5013  add rsp, 0x08
00007154327d5017  jmp 0x00007154327D025D
00007154327d501c  sub rsp, 0x08
00007154327d5020  push rax
00007154327d5021  push rcx
00007154327d5022  push rdx
00007154327d5023  push rdi
00007154327d5024  push rsi
00007154327d5025  push r8
00007154327d5027  push r9
00007154327d5029  push r10
00007154327d502b  push r11
00007154327d502d  sub rsp, 0xF0
00007154327d5034  vmovaps [rsp], xmm0
00007154327d5039  vmovaps [rsp+0x10], xmm1
00007154327d503f  vmovaps [rsp+0x20], xmm2
00007154327d5045  vmovaps [rsp+0x30], xmm3
00007154327d504b  vmovaps [rsp+0x40], xmm4
00007154327d5051  vmovaps [rsp+0x50], xmm5
00007154327d5057  vmovaps [rsp+0x60], xmm6
00007154327d505d  vmovaps [rsp+0x70], xmm7
00007154327d5063  vmovaps [rsp+0x80], xmm8
00007154327d506c  vmovaps [rsp+0x90], xmm9
00007154327d5075  vmovaps [rsp+0xA0], xmm11
00007154327d507e  vmovaps [rsp+0xB0], xmm12
00007154327d5087  vmovaps [rsp+0xC0], xmm13
00007154327d5090  vmovaps [rsp+0xD0], xmm14
00007154327d5099  vmovaps [rsp+0xE0], xmm15
00007154327d50a2  sub rsp, 0x30
00007154327d50a6  movaps [rsp], xmm10
00007154327d50ab  movaps [rsp+0x10], xmm11
00007154327d50b1  movaps [rsp+0x20], xmm15
00007154327d50b7  lea rdi, [rsp]
00007154327d50bb  mov esi, 0x00
00007154327d50c0  mov rax, 0x5A63B06A5530
00007154327d50ca  call rax
00007154327d50cc  movaps xmm10, [rsp]
00007154327d50d1  add rsp, 0x30
00007154327d50d5  vmovaps xmm0, [rsp]
00007154327d50da  vmovaps xmm1, [rsp+0x10]
00007154327d50e0  vmovaps xmm2, [rsp+0x20]
00007154327d50e6  vmovaps xmm3, [rsp+0x30]
00007154327d50ec  vmovaps xmm4, [rsp+0x40]
00007154327d50f2  vmovaps xmm5, [rsp+0x50]
00007154327d50f8  vmovaps xmm6, [rsp+0x60]
00007154327d50fe  vmovaps xmm7, [rsp+0x70]
00007154327d5104  vmovaps xmm8, [rsp+0x80]
00007154327d510d  vmovaps xmm9, [rsp+0x90]
00007154327d5116  vmovaps xmm11, [rsp+0xA0]
00007154327d511f  vmovaps xmm12, [rsp+0xB0]
00007154327d5128  vmovaps xmm13, [rsp+0xC0]
00007154327d5131  vmovaps xmm14, [rsp+0xD0]
00007154327d513a  vmovaps xmm15, [rsp+0xE0]
00007154327d5143  add rsp, 0xF0
00007154327d514a  pop r11
00007154327d514c  pop r10
00007154327d514e  pop r9
00007154327d5150  pop r8
00007154327d5152  pop rsi
00007154327d5153  pop rdi
00007154327d5154  pop rdx
00007154327d5155  pop rcx
00007154327d5156  pop rax
00007154327d5157  add rsp, 0x08
00007154327d515b  jmp 0x00007154327D028B
00007154327d5160  sub rsp, 0x08
00007154327d5164  push rax
00007154327d5165  push rcx
00007154327d5166  push rdx
00007154327d5167  push rdi
00007154327d5168  push rsi
00007154327d5169  push r8
00007154327d516b  push r9
00007154327d516d  push r10
00007154327d516f  push r11
00007154327d5171  sub rsp, 0xF0
00007154327d5178  vmovaps [rsp], xmm0
00007154327d517d  vmovaps [rsp+0x10], xmm1
00007154327d5183  vmovaps [rsp+0x20], xmm2
00007154327d5189  vmovaps [rsp+0x30], xmm3
00007154327d518f  vmovaps [rsp+0x40], xmm4
00007154327d5195  vmovaps [rsp+0x50], xmm5
00007154327d519b  vmovaps [rsp+0x60], xmm6
00007154327d51a1  vmovaps [rsp+0x70], xmm7
00007154327d51a7  vmovaps [rsp+0x80], xmm8
00007154327d51b0  vmovaps [rsp+0x90], xmm9
00007154327d51b9  vmovaps [rsp+0xA0], xmm10
00007154327d51c2  vmovaps [rsp+0xB0], xmm12
00007154327d51cb  vmovaps [rsp+0xC0], xmm13
00007154327d51d4  vmovaps [rsp+0xD0], xmm14
00007154327d51dd  vmovaps [rsp+0xE0], xmm15
00007154327d51e6  sub rsp, 0x30
00007154327d51ea  movaps [rsp], xmm11
00007154327d51ef  movaps [rsp+0x10], xmm12
00007154327d51f5  movaps [rsp+0x20], xmm15
00007154327d51fb  lea rdi, [rsp]
00007154327d51ff  mov esi, 0x00
00007154327d5204  mov rax, 0x5A63B06A5530
00007154327d520e  call rax
00007154327d5210  movaps xmm11, [rsp]
00007154327d5215  add rsp, 0x30
00007154327d5219  vmovaps xmm0, [rsp]
00007154327d521e  vmovaps xmm1, [rsp+0x10]
00007154327d5224  vmovaps xmm2, [rsp+0x20]
00007154327d522a  vmovaps xmm3, [rsp+0x30]
00007154327d5230  vmovaps xmm4, [rsp+0x40]
00007154327d5236  vmovaps xmm5, [rsp+0x50]
00007154327d523c  vmovaps xmm6, [rsp+0x60]
00007154327d5242  vmovaps xmm7, [rsp+0x70]
00007154327d5248  vmovaps xmm8, [rsp+0x80]
00007154327d5251  vmovaps xmm9, [rsp+0x90]
00007154327d525a  vmovaps xmm10, [rsp+0xA0]
00007154327d5263  vmovaps xmm12, [rsp+0xB0]
00007154327d526c  vmovaps xmm13, [rsp+0xC0]
00007154327d5275  vmovaps xmm14, [rsp+0xD0]
00007154327d527e  vmovaps xmm15, [rsp+0xE0]
00007154327d5287  add rsp, 0xF0
00007154327d528e  pop r11
00007154327d5290  pop r10
00007154327d5292  pop r9
00007154327d5294  pop r8
00007154327d5296  pop rsi
00007154327d5297  pop rdi
00007154327d5298  pop rdx
00007154327d5299  pop rcx
00007154327d529a  pop rax
00007154327d529b  add rsp, 0x08
00007154327d529f  jmp 0x00007154327D02B9
00007154327d52a4  sub rsp, 0x08
00007154327d52a8  push rax
00007154327d52a9  push rcx
00007154327d52aa  push rdx
00007154327d52ab  push rdi
00007154327d52ac  push rsi
00007154327d52ad  push r8
00007154327d52af  push r9
00007154327d52b1  push r10
00007154327d52b3  push r11
00007154327d52b5  sub rsp, 0xF0
00007154327d52bc  vmovaps [rsp], xmm0
00007154327d52c1  vmovaps [rsp+0x10], xmm1
00007154327d52c7  vmovaps [rsp+0x20], xmm2
00007154327d52cd  vmovaps [rsp+0x30], xmm3
00007154327d52d3  vmovaps [rsp+0x40], xmm4
00007154327d52d9  vmovaps [rsp+0x50], xmm5
00007154327d52df  vmovaps [rsp+0x60], xmm6
00007154327d52e5  vmovaps [rsp+0x70], xmm7
00007154327d52eb  vmovaps [rsp+0x80], xmm8
00007154327d52f4  vmovaps [rsp+0x90], xmm9
00007154327d52fd  vmovaps [rsp+0xA0], xmm10
00007154327d5306  vmovaps [rsp+0xB0], xmm11
00007154327d530f  vmovaps [rsp+0xC0], xmm12
00007154327d5318  vmovaps [rsp+0xD0], xmm13
00007154327d5321  vmovaps [rsp+0xE0], xmm14
00007154327d532a  sub rsp, 0x30
00007154327d532e  movaps [rsp], xmm15
00007154327d5333  movaps [rsp+0x10], xmm13
00007154327d5339  movaps [rsp+0x20], xmm9
00007154327d533f  lea rdi, [rsp]
00007154327d5343  mov esi, 0x00
00007154327d5348  mov rax, 0x5A63B06A5530
00007154327d5352  call rax
00007154327d5354  movaps xmm15, [rsp]
00007154327d5359  add rsp, 0x30
00007154327d535d  vmovaps xmm0, [rsp]
00007154327d5362  vmovaps xmm1, [rsp+0x10]
00007154327d5368  vmovaps xmm2, [rsp+0x20]
00007154327d536e  vmovaps xmm3, [rsp+0x30]
00007154327d5374  vmovaps xmm4, [rsp+0x40]
00007154327d537a  vmovaps xmm5, [rsp+0x50]
00007154327d5380  vmovaps xmm6, [rsp+0x60]
00007154327d5386  vmovaps xmm7, [rsp+0x70]
00007154327d538c  vmovaps xmm8, [rsp+0x80]
00007154327d5395  vmovaps xmm9, [rsp+0x90]
00007154327d539e  vmovaps xmm10, [rsp+0xA0]
00007154327d53a7  vmovaps xmm11, [rsp+0xB0]
00007154327d53b0  vmovaps xmm12, [rsp+0xC0]
00007154327d53b9  vmovaps xmm13, [rsp+0xD0]
00007154327d53c2  vmovaps xmm14, [rsp+0xE0]
00007154327d53cb  add rsp, 0xF0
00007154327d53d2  pop r11
00007154327d53d4  pop r10
00007154327d53d6  pop r9
00007154327d53d8  pop r8
00007154327d53da  pop rsi
00007154327d53db  pop rdi
00007154327d53dc  pop rdx
00007154327d53dd  pop rcx
00007154327d53de  pop rax
00007154327d53df  add rsp, 0x08
00007154327d53e3  jmp 0x00007154327D02D4
00007154327d53e8  sub rsp, 0x08
00007154327d53ec  push rax
00007154327d53ed  push rcx
00007154327d53ee  push rdx
00007154327d53ef  push rdi
00007154327d53f0  push rsi
00007154327d53f1  push r8
00007154327d53f3  push r9
00007154327d53f5  push r10
00007154327d53f7  push r11
00007154327d53f9  sub rsp, 0xF0
00007154327d5400  vmovaps [rsp], xmm0
00007154327d5405  vmovaps [rsp+0x10], xmm1
00007154327d540b  vmovaps [rsp+0x20], xmm2
00007154327d5411  vmovaps [rsp+0x30], xmm3
00007154327d5417  vmovaps [rsp+0x40], xmm4
00007154327d541d  vmovaps [rsp+0x50], xmm5
00007154327d5423  vmovaps [rsp+0x60], xmm6
00007154327d5429  vmovaps [rsp+0x70], xmm7
00007154327d542f  vmovaps [rsp+0x80], xmm8
00007154327d5438  vmovaps [rsp+0x90], xmm9
00007154327d5441  vmovaps [rsp+0xA0], xmm10
00007154327d544a  vmovaps [rsp+0xB0], xmm11
00007154327d5453  vmovaps [rsp+0xC0], xmm12
00007154327d545c  vmovaps [rsp+0xD0], xmm14
00007154327d5465  vmovaps [rsp+0xE0], xmm15
00007154327d546e  sub rsp, 0x30
00007154327d5472  movaps [rsp], xmm13
00007154327d5477  movaps [rsp+0x10], xmm8
00007154327d547d  movaps [rsp+0x20], xmm14
00007154327d5483  lea rdi, [rsp]
00007154327d5487  mov esi, 0x00
00007154327d548c  mov rax, 0x5A63B06A5530
00007154327d5496  call rax
00007154327d5498  movaps xmm13, [rsp]
00007154327d549d  add rsp, 0x30
00007154327d54a1  vmovaps xmm0, [rsp]
00007154327d54a6  vmovaps xmm1, [rsp+0x10]
00007154327d54ac  vmovaps xmm2, [rsp+0x20]
00007154327d54b2  vmovaps xmm3, [rsp+0x30]
00007154327d54b8  vmovaps xmm4, [rsp+0x40]
00007154327d54be  vmovaps xmm5, [rsp+0x50]
00007154327d54c4  vmovaps xmm6, [rsp+0x60]
00007154327d54ca  vmovaps xmm7, [rsp+0x70]
00007154327d54d0  vmovaps xmm8, [rsp+0x80]
00007154327d54d9  vmovaps xmm9, [rsp+0x90]
00007154327d54e2  vmovaps xmm10, [rsp+0xA0]
00007154327d54eb  vmovaps xmm11, [rsp+0xB0]
00007154327d54f4  vmovaps xmm12, [rsp+0xC0]
00007154327d54fd  vmovaps xmm14, [rsp+0xD0]
00007154327d5506  vmovaps xmm15, [rsp+0xE0]
00007154327d550f  add rsp, 0xF0
00007154327d5516  pop r11
00007154327d5518  pop r10
00007154327d551a  pop r9
00007154327d551c  pop r8
00007154327d551e  pop rsi
00007154327d551f  pop rdi
00007154327d5520  pop rdx
00007154327d5521  pop rcx
00007154327d5522  pop rax
00007154327d5523  add rsp, 0x08
00007154327d5527  jmp 0x00007154327D02F7
00007154327d552c  sub rsp, 0x08
00007154327d5530  push rax
00007154327d5531  push rcx
00007154327d5532  push rdx
00007154327d5533  push rdi
00007154327d5534  push rsi
00007154327d5535  push r8
00007154327d5537  push r9
00007154327d5539  push r10
00007154327d553b  push r11
00007154327d553d  sub rsp, 0xF0
00007154327d5544  vmovaps [rsp], xmm0
00007154327d5549  vmovaps [rsp+0x10], xmm1
00007154327d554f  vmovaps [rsp+0x20], xmm2
00007154327d5555  vmovaps [rsp+0x30], xmm3
00007154327d555b  vmovaps [rsp+0x40], xmm4
00007154327d5561  vmovaps [rsp+0x50], xmm5
00007154327d5567  vmovaps [rsp+0x60], xmm6
00007154327d556d  vmovaps [rsp+0x70], xmm7
00007154327d5573  vmovaps [rsp+0x80], xmm8
00007154327d557c  vmovaps [rsp+0x90], xmm9
00007154327d5585  vmovaps [rsp+0xA0], xmm10
00007154327d558e  vmovaps [rsp+0xB0], xmm11
00007154327d5597  vmovaps [rsp+0xC0], xmm12
00007154327d55a0  vmovaps [rsp+0xD0], xmm13
00007154327d55a9  vmovaps [rsp+0xE0], xmm15
00007154327d55b2  sub rsp, 0x30
00007154327d55b6  movaps [rsp], xmm14
00007154327d55bb  movaps [rsp+0x10], xmm1
00007154327d55c0  movaps [rsp+0x20], xmm10
00007154327d55c6  lea rdi, [rsp]
00007154327d55ca  mov esi, 0x00
00007154327d55cf  mov rax, 0x5A63B06A5530
00007154327d55d9  call rax
00007154327d55db  movaps xmm14, [rsp]
00007154327d55e0  add rsp, 0x30
00007154327d55e4  vmovaps xmm0, [rsp]
00007154327d55e9  vmovaps xmm1, [rsp+0x10]
00007154327d55ef  vmovaps xmm2, [rsp+0x20]
00007154327d55f5  vmovaps xmm3, [rsp+0x30]
00007154327d55fb  vmovaps xmm4, [rsp+0x40]
00007154327d5601  vmovaps xmm5, [rsp+0x50]
00007154327d5607  vmovaps xmm6, [rsp+0x60]
00007154327d560d  vmovaps xmm7, [rsp+0x70]
00007154327d5613  vmovaps xmm8, [rsp+0x80]
00007154327d561c  vmovaps xmm9, [rsp+0x90]
00007154327d5625  vmovaps xmm10, [rsp+0xA0]
00007154327d562e  vmovaps xmm11, [rsp+0xB0]
00007154327d5637  vmovaps xmm12, [rsp+0xC0]
00007154327d5640  vmovaps xmm13, [rsp+0xD0]
00007154327d5649  vmovaps xmm15, [rsp+0xE0]
00007154327d5652  add rsp, 0xF0
00007154327d5659  pop r11
00007154327d565b  pop r10
00007154327d565d  pop r9
00007154327d565f  pop r8
00007154327d5661  pop rsi
00007154327d5662  pop rdi
00007154327d5663  pop rdx
00007154327d5664  pop rcx
00007154327d5665  pop rax
00007154327d5666  add rsp, 0x08
00007154327d566a  jmp 0x00007154327D031A
00007154327d566f  sub rsp, 0x08
00007154327d5673  push rax
00007154327d5674  push rcx
00007154327d5675  push rdx
00007154327d5676  push rdi
00007154327d5677  push rsi
00007154327d5678  push r8
00007154327d567a  push r9
00007154327d567c  push r10
00007154327d567e  push r11
00007154327d5680  sub rsp, 0xF0
00007154327d5687  vmovaps [rsp], xmm0
00007154327d568c  vmovaps [rsp+0x10], xmm2
00007154327d5692  vmovaps [rsp+0x20], xmm3
00007154327d5698  vmovaps [rsp+0x30], xmm4
00007154327d569e  vmovaps [rsp+0x40], xmm5
00007154327d56a4  vmovaps [rsp+0x50], xmm6
00007154327d56aa  vmovaps [rsp+0x60], xmm7
00007154327d56b0  vmovaps [rsp+0x70], xmm8
00007154327d56b6  vmovaps [rsp+0x80], xmm9
00007154327d56bf  vmovaps [rsp+0x90], xmm10
00007154327d56c8  vmovaps [rsp+0xA0], xmm11
00007154327d56d1  vmovaps [rsp+0xB0], xmm12
00007154327d56da  vmovaps [rsp+0xC0], xmm13
00007154327d56e3  vmovaps [rsp+0xD0], xmm14
00007154327d56ec  vmovaps [rsp+0xE0], xmm15
00007154327d56f5  sub rsp, 0x30
00007154327d56f9  movaps [rsp], xmm1
00007154327d56fd  movaps [rsp+0x10], xmm7
00007154327d5702  movaps [rsp+0x20], xmm11
00007154327d5708  lea rdi, [rsp]
00007154327d570c  mov esi, 0x00
00007154327d5711  mov rax, 0x5A63B06A5530
00007154327d571b  call rax
00007154327d571d  movaps xmm1, [rsp]
00007154327d5721  add rsp, 0x30
00007154327d5725  vmovaps xmm0, [rsp]
00007154327d572a  vmovaps xmm2, [rsp+0x10]
00007154327d5730  vmovaps xmm3, [rsp+0x20]
00007154327d5736  vmovaps xmm4, [rsp+0x30]
00007154327d573c  vmovaps xmm5, [rsp+0x40]
00007154327d5742  vmovaps xmm6, [rsp+0x50]
00007154327d5748  vmovaps xmm7, [rsp+0x60]
00007154327d574e  vmovaps xmm8, [rsp+0x70]
00007154327d5754  vmovaps xmm9, [rsp+0x80]
00007154327d575d  vmovaps xmm10, [rsp+0x90]
00007154327d5766  vmovaps xmm11, [rsp+0xA0]
00007154327d576f  vmovaps xmm12, [rsp+0xB0]
00007154327d5778  vmovaps xmm13, [rsp+0xC0]
00007154327d5781  vmovaps xmm14, [rsp+0xD0]
00007154327d578a  vmovaps xmm15, [rsp+0xE0]
00007154327d5793  add rsp, 0xF0
00007154327d579a  pop r11
00007154327d579c  pop r10
00007154327d579e  pop r9
00007154327d57a0  pop r8
00007154327d57a2  pop rsi
00007154327d57a3  pop rdi
00007154327d57a4  pop rdx
00007154327d57a5  pop rcx
00007154327d57a6  pop rax
00007154327d57a7  add rsp, 0x08
00007154327d57ab  jmp 0x00007154327D033B
00007154327d57b0  call 0x000071543260E880
00007154327d57b5  jmp 0x00007154327D034E
00007154327d57ba  call 0x000071543260C380
00007154327d57bf  jmp 0x00007154327D0359
00007154327d57c4  call 0x000071543260D600
00007154327d57c9  jmp 0x00007154327D0364
00007154327d57ce  call 0x00007154325FF540
00007154327d57d3  jmp 0x00007154327D036F
00007154327d57d8  int3
00007154327d57d9  nop [rax], eax
00007154327d57e0  mov rax, [r15+0x40]
00007154327d57e4  mov r14, [r15+0x58]
00007154327d57e8  lea r12, [rax+r14*1]
00007154327d57ec  movaps xmm1, [r15+0x1D0]
00007154327d57f4  vmovaps [rsp+0x10], xmm1
00007154327d57fa  vmovaps xmm15, [rsp+0x10]
00007154327d5800  por xmm1, xmm15
00007154327d5805  movaps xmm14, [r15+0x1A0]
00007154327d580d  vmovaps [rsp+0x10], xmm14
00007154327d5813  vmovaps xmm13, [rsp+0x10]
00007154327d5819  por xmm14, xmm13
00007154327d581e  lea rax, [r12+0x30]
00007154327d5823  mov r11, [r13+rax*1]
00007154327d5828  lea rax, [r12+0x38]
00007154327d582d  mov r10, [r13+rax*1]
00007154327d5832  movq xmm13, r11
00007154327d5837  movq xmm12, r10
00007154327d583c  movq xmm13, xmm13
00007154327d5841  vmovaps [rsp+0x10], xmm13
00007154327d5847  movq xmm13, xmm13
00007154327d584c  movaps [r15+0x130], xmm13
00007154327d5854  movq xmm12, xmm12
00007154327d5859  vmovaps [rsp+0x20], xmm12
00007154327d585f  movq xmm12, xmm12
00007154327d5864  movaps [r15+0x280], xmm12
00007154327d586c  movaps xmm13, [r15+0x270]
00007154327d5874  vmovaps [rsp+0x30], xmm13
00007154327d587a  vmovaps xmm12, [rsp+0x30]
00007154327d5880  por xmm13, xmm12
00007154327d5885  lea rax, [r12+0x20]
00007154327d588a  mov r11, [r13+rax*1]
00007154327d588f  lea rax, [r12+0x28]
00007154327d5894  mov r10, [r13+rax*1]
00007154327d5899  movq xmm12, r11
00007154327d589e  movq xmm11, r10
00007154327d58a3  movq xmm12, xmm12
00007154327d58a8  vmovaps [rsp+0x30], xmm12
00007154327d58ae  movq xmm12, xmm12
00007154327d58b3  movaps [r15+0x150], xmm12
00007154327d58bb  movq xmm11, xmm11
00007154327d58c0  vmovaps [rsp+0x40], xmm11
00007154327d58c6  movq xmm11, xmm11
00007154327d58cb  movaps [r15+0x140], xmm11
00007154327d58d3  lea rax, [r12+0x10]
00007154327d58d8  mov r11, [r13+rax*1]
00007154327d58dd  lea rax, [r12+0x18]
00007154327d58e2  mov r10, [r13+rax*1]
00007154327d58e7  movq xmm12, r11
00007154327d58ec  movq xmm11, r10
00007154327d58f1  movq xmm12, xmm12
00007154327d58f6  vmovaps [rsp+0x50], xmm12
00007154327d58fc  movq xmm12, xmm12
00007154327d5901  movaps [r15+0x170], xmm12
00007154327d5909  movq xmm11, xmm11
00007154327d590e  vmovaps [rsp+0x60], xmm11
00007154327d5914  movq xmm11, xmm11
00007154327d5919  movaps [r15+0x160], xmm11
00007154327d5921  mov rax, [r13+r12*1]
00007154327d5926  vmovq xmm12, rax
00007154327d592b  vpbroadcastq xmm12, xmm12
00007154327d5930  lea rax, [r12+0x08]
00007154327d5935  mov r12, [r13+rax*1]
00007154327d593a  movq xmm11, r12
00007154327d593f  movaps [r15+0x230], xmm11
00007154327d5947  mov rax, [r15+0xF8]
00007154327d594e  lea r12, [rax+0x50]
00007154327d5952  movups xmm11, [r13+r12*1]
00007154327d5958  lea r12, [rax+0x60]
00007154327d595c  movups xmm10, [r13+r12*1]
00007154327d5962  lea r12, [rax+0x30]
00007154327d5966  movups xmm9, [r13+r12*1]
00007154327d596c  mov r12, [r15+0x50]
00007154327d5970  lea r11, [r12+r14*1]
00007154327d5974  mov [r15+0x60], r11
00007154327d5978  lea r12, [r14+0x40]
00007154327d597c  mov [r15+0x58], r12
00007154327d5980  movaps xmm8, xmm12
00007154327d5984  mulpd xmm8, xmm15
00007154327d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007154327d598f  ptest xmm7, xmm7
00007154327d5994  jnz 0x00007154327D67B7
00007154327d599a  movq xmm15, qword ptr [r15+0x230]
00007154327d59a3  vmovaps [rsp+0x70], xmm15
00007154327d59a9  vpermilpd xmm15, xmm15, 0x00
00007154327d59af  movaps xmm7, xmm9
00007154327d59b3  mulpd xmm7, xmm15
00007154327d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007154327d59bd  ptest xmm6, xmm6
00007154327d59c2  jnz 0x00007154327D68FB
00007154327d59c8  vxorps xmm15, xmm15, xmm15
00007154327d59cd  vpbroadcastq xmm15, xmm15
00007154327d59d2  movaps xmm9, xmm12
00007154327d59d6  mulpd xmm9, xmm10
00007154327d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007154327d59e1  ptest xmm6, xmm6
00007154327d59e6  jnz 0x00007154327D6A3D
00007154327d59ec  movaps xmm10, xmm12
00007154327d59f0  mulpd xmm10, xmm11
00007154327d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007154327d59fb  ptest xmm6, xmm6
00007154327d5a00  jnz 0x00007154327D6B81
00007154327d5a06  movaps xmm11, [r15+0x1F0]
00007154327d5a0e  movaps xmm6, xmm12
00007154327d5a12  mulpd xmm6, xmm11
00007154327d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007154327d5a1c  ptest xmm5, xmm5
00007154327d5a21  jnz 0x00007154327D6CC5
00007154327d5a27  movaps xmm12, [r15+0x2A0]
00007154327d5a2f  vmovaps [rsp+0x80], xmm12
00007154327d5a38  vmovaps xmm11, [rsp+0x80]
00007154327d5a41  por xmm12, xmm11
00007154327d5a46  movaps xmm11, [r15+0x250]
00007154327d5a4e  vmovaps [rsp+0x80], xmm11
00007154327d5a57  vmovaps xmm5, [rsp+0x80]
00007154327d5a60  por xmm11, xmm5
00007154327d5a65  vmovaps xmm4, [rsp+0x70]
00007154327d5a6b  vpermilpd xmm4, xmm4, 0x00
00007154327d5a71  movaps xmm3, xmm5
00007154327d5a74  mulpd xmm3, xmm4
00007154327d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007154327d5a7d  ptest xmm2, xmm2
00007154327d5a82  jnz 0x00007154327D6E07
00007154327d5a88  mov [rsp+0x80], rax
00007154327d5a90  xor eax, eax
00007154327d5a92  mov r14d, 0x200
00007154327d5a98  cmp r12, r14
00007154327d5a9b  cmc
00007154327d5a9c  lahf
00007154327d5a9d  seto al
00007154327d5aa0  mov [r15+0x108], eax
00007154327d5aa7  movaps xmm5, xmm8
00007154327d5aab  addpd xmm5, xmm15
00007154327d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007154327d5ab5  ptest xmm4, xmm4
00007154327d5aba  jnz 0x00007154327D6F47
00007154327d5ac0  movaps xmm8, [r15+0x1B0]
00007154327d5ac8  movaps xmm4, xmm9
00007154327d5acc  addpd xmm4, xmm8
00007154327d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007154327d5ad6  ptest xmm2, xmm2
00007154327d5adb  jnz 0x00007154327D7089
00007154327d5ae1  movaps xmm9, xmm10
00007154327d5ae5  addpd xmm9, xmm8
00007154327d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007154327d5af0  ptest xmm2, xmm2
00007154327d5af5  jnz 0x00007154327D71CB
00007154327d5afb  movaps xmm10, [r15+0x2F0]
00007154327d5b03  vmovaps [rsp+0x90], xmm10
00007154327d5b0c  vmovaps xmm8, [rsp+0x90]
00007154327d5b15  por xmm10, xmm8
00007154327d5b1a  movaps xmm8, [r15+0x2E0]
00007154327d5b22  vmovaps [rsp+0x90], xmm8
00007154327d5b2b  vmovaps xmm2, [rsp+0x90]
00007154327d5b34  por xmm8, xmm2
00007154327d5b39  movaps xmm2, [r15+0x2D0]
00007154327d5b41  vmovaps [rsp+0x90], xmm2
00007154327d5b4a  vmovaps [rsp+0xA0], xmm1
00007154327d5b53  vmovaps xmm1, [rsp+0x90]
00007154327d5b5c  por xmm2, xmm1
00007154327d5b60  movaps xmm1, [r15+0x200]
00007154327d5b68  vmovaps [rsp+0x90], xmm1
00007154327d5b71  vmovaps [rsp+0xB0], xmm15
00007154327d5b7a  vmovaps xmm15, [rsp+0x90]
00007154327d5b83  por xmm1, xmm15
00007154327d5b88  movaps xmm15, [r15+0x1C0]
00007154327d5b90  vmovaps [rsp+0x90], xmm15
00007154327d5b99  vmovaps [rsp+0xC0], xmm1
00007154327d5ba2  vmovaps xmm1, [rsp+0x90]
00007154327d5bab  por xmm15, xmm1
00007154327d5bb0  movaps xmm1, [r15+0x190]
00007154327d5bb8  vmovaps [rsp+0x90], xmm1
00007154327d5bc1  vmovaps [rsp+0xD0], xmm15
00007154327d5bca  vmovaps xmm15, [rsp+0x90]
00007154327d5bd3  por xmm1, xmm15
00007154327d5bd8  movaps xmm15, [r15+0x300]
00007154327d5be0  vmovaps [rsp+0x90], xmm15
00007154327d5be9  vmovaps [rsp+0xE0], xmm1
00007154327d5bf2  vmovaps xmm1, [rsp+0x90]
00007154327d5bfb  por xmm15, xmm1
00007154327d5c00  mov rax, [rsp+0x80]
00007154327d5c08  lea r14, [rax+0xA0]
00007154327d5c0f  movups xmm1, [r13+r14*1]
00007154327d5c15  lea r14, [rax+0xB0]
00007154327d5c1c  vmovaps [rsp+0x80], xmm1
00007154327d5c25  movups xmm1, [r13+r14*1]
00007154327d5c2b  vmovaps [rsp+0x90], xmm1
00007154327d5c34  vmovaps [rsp+0xF0], xmm15
00007154327d5c3d  vmovaps xmm15, [rsp+0xB0]
00007154327d5c46  vmovaps [rsp+0xB0], xmm14
00007154327d5c4f  movaps xmm1, xmm6
00007154327d5c52  addpd xmm1, xmm15
00007154327d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007154327d5c5c  ptest xmm14, xmm14
00007154327d5c62  jnz 0x00007154327D7323
00007154327d5c68  lea r14, [rax+0xF0]
00007154327d5c6f  movups xmm15, [r13+r14*1]
00007154327d5c75  movaps xmm14, xmm4
00007154327d5c79  addpd xmm14, xmm3
00007154327d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007154327d5c84  ptest xmm6, xmm6
00007154327d5c89  jnz 0x00007154327D746E
00007154327d5c8f  movaps xmm6, xmm9
00007154327d5c93  addpd xmm6, xmm7
00007154327d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007154327d5c9c  ptest xmm4, xmm4
00007154327d5ca1  jnz 0x00007154327D75B0
00007154327d5ca7  vmovaps xmm9, [rsp+0x70]
00007154327d5cad  vpermilpd xmm9, xmm9, 0x00
00007154327d5cb3  vmovaps xmm4, [rsp+0x90]
00007154327d5cbc  movaps xmm7, xmm4
00007154327d5cbf  mulpd xmm7, xmm9
00007154327d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007154327d5cc9  ptest xmm3, xmm3
00007154327d5cce  jnz 0x00007154327D76F1
00007154327d5cd4  vmovaps xmm9, [rsp+0x50]
00007154327d5cda  vpermilpd xmm9, xmm9, 0x00
00007154327d5ce0  movaps xmm4, xmm15
00007154327d5ce4  mulpd xmm4, xmm9
00007154327d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007154327d5cee  ptest xmm3, xmm3
00007154327d5cf3  jnz 0x00007154327D7832
00007154327d5cf9  lea r14, [rax+0xE0]
00007154327d5d00  movups xmm15, [r13+r14*1]
00007154327d5d06  vmovaps xmm9, [rsp+0x70]
00007154327d5d0c  vpermilpd xmm9, xmm9, 0x00
00007154327d5d12  vmovaps [rsp+0x70], xmm1
00007154327d5d18  vmovaps xmm1, [rsp+0x80]
00007154327d5d21  vmovaps [rsp+0x80], xmm15
00007154327d5d2a  movaps xmm3, xmm1
00007154327d5d2d  mulpd xmm3, xmm9
00007154327d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007154327d5d37  ptest xmm15, xmm15
00007154327d5d3d  jnz 0x00007154327D797E
00007154327d5d43  vmovaps xmm1, [rsp+0xF0]
00007154327d5d4c  vmovaps xmm15, [rsp+0xF0]
00007154327d5d55  por xmm1, xmm15
00007154327d5d5a  movaps [r15+0x300], xmm1
00007154327d5d62  vmovaps xmm15, [rsp+0xE0]
00007154327d5d6b  vmovaps xmm9, [rsp+0xE0]
00007154327d5d74  por xmm15, xmm9
00007154327d5d79  movaps [r15+0x190], xmm15
00007154327d5d81  vmovaps xmm9, [rsp+0x50]
00007154327d5d87  vpermilpd xmm9, xmm9, 0x00
00007154327d5d8d  vmovaps [rsp+0x90], xmm1
00007154327d5d96  vmovaps [rsp+0xE0], xmm15
00007154327d5d9f  vmovaps xmm15, [rsp+0x80]
00007154327d5da8  vmovaps [rsp+0x80], xmm14
00007154327d5db1  movaps xmm1, xmm15
00007154327d5db5  mulpd xmm1, xmm9
00007154327d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007154327d5dbf  ptest xmm14, xmm14
00007154327d5dc5  jnz 0x00007154327D7ABF
00007154327d5dcb  lea r14, [rax+0x90]
00007154327d5dd2  movups xmm15, [r13+r14*1]
00007154327d5dd8  vmovaps xmm14, [rsp+0xD0]
00007154327d5de1  vmovaps xmm9, [rsp+0xD0]
00007154327d5dea  por xmm14, xmm9
00007154327d5def  movaps [r15+0x1C0], xmm14
00007154327d5df7  vmovaps xmm9, [rsp+0xC0]
00007154327d5e00  vmovaps [rsp+0xD0], xmm1
00007154327d5e09  vmovaps xmm1, [rsp+0xC0]
00007154327d5e12  por xmm9, xmm1
00007154327d5e17  movaps [r15+0x200], xmm9
00007154327d5e1f  vmovaps [rsp+0xC0], xmm2
00007154327d5e28  vmovaps xmm1, [rsp+0xC0]
00007154327d5e31  por xmm2, xmm1
00007154327d5e35  movaps [r15+0x2D0], xmm2
00007154327d5e3d  vmovaps [rsp+0xC0], xmm8
00007154327d5e46  vmovaps xmm1, [rsp+0xC0]
00007154327d5e4f  por xmm8, xmm1
00007154327d5e54  movaps [r15+0x2E0], xmm8
00007154327d5e5c  vmovaps [rsp+0xC0], xmm15
00007154327d5e65  movaps xmm1, xmm5
00007154327d5e68  addpd xmm1, xmm7
00007154327d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007154327d5e71  ptest xmm15, xmm15
00007154327d5e77  jnz 0x00007154327D7C0B
00007154327d5e7d  vmovaps xmm15, [rsp+0x50]
00007154327d5e83  vpermilpd xmm15, xmm15, 0x00
00007154327d5e89  vmovaps xmm5, [rsp+0xC0]
00007154327d5e92  vmovaps [rsp+0xC0], xmm1
00007154327d5e9b  movaps xmm7, xmm5
00007154327d5e9e  mulpd xmm7, xmm15
00007154327d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007154327d5ea8  ptest xmm1, xmm1
00007154327d5ead  jnz 0x00007154327D7D4B
00007154327d5eb3  lea r14, [rax+0x80]
00007154327d5eba  movups xmm1, [r13+r14*1]
00007154327d5ec0  vmovaps xmm5, [rsp+0x70]
00007154327d5ec6  vmovaps [rsp+0x70], xmm1
00007154327d5ecc  movaps xmm15, xmm5
00007154327d5ed0  addpd xmm15, xmm3
00007154327d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007154327d5edb  ptest xmm1, xmm1
00007154327d5ee0  jnz 0x00007154327D7E96
00007154327d5ee6  vmovaps xmm5, [rsp+0x80]
00007154327d5eef  movaps xmm1, xmm5
00007154327d5ef2  addpd xmm1, xmm4
00007154327d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007154327d5efb  ptest xmm3, xmm3
00007154327d5f00  jnz 0x00007154327D7FD8
00007154327d5f06  vmovaps [rsp+0x80], xmm10
00007154327d5f0f  vmovaps xmm5, [rsp+0x80]
00007154327d5f18  por xmm10, xmm5
00007154327d5f1d  movaps [r15+0x2F0], xmm10
00007154327d5f25  vmovaps xmm5, [rsp+0x50]
00007154327d5f2b  vpermilpd xmm5, xmm5, 0x00
00007154327d5f31  vmovaps xmm3, [rsp+0x70]
00007154327d5f37  vmovaps [rsp+0x50], xmm1
00007154327d5f3d  movaps xmm4, xmm3
00007154327d5f40  mulpd xmm4, xmm5
00007154327d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007154327d5f49  ptest xmm1, xmm1
00007154327d5f4e  jnz 0x00007154327D8118
00007154327d5f54  lea r14, [rax+0xD0]
00007154327d5f5b  movups xmm1, [r13+r14*1]
00007154327d5f61  vmovaps xmm3, [rsp+0xD0]
00007154327d5f6a  vmovaps [rsp+0x70], xmm1
00007154327d5f70  movaps xmm5, xmm6
00007154327d5f73  addpd xmm5, xmm3
00007154327d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007154327d5f7c  ptest xmm1, xmm1
00007154327d5f81  jnz 0x00007154327D8262
00007154327d5f87  vmovaps xmm1, [rsp+0x60]
00007154327d5f8d  vpermilpd xmm1, xmm1, 0x00
00007154327d5f93  movaps xmm6, xmm9
00007154327d5f97  mulpd xmm6, xmm1
00007154327d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007154327d5fa0  ptest xmm3, xmm3
00007154327d5fa5  jnz 0x00007154327D83A2
00007154327d5fab  movaps [r15+0x260], xmm6
00007154327d5fb3  vxorps xmm1, xmm1, xmm1
00007154327d5fb7  vpbroadcastq xmm1, xmm1
00007154327d5fbc  movaps [r15+0x1B0], xmm1
00007154327d5fc4  vmovaps xmm1, [rsp+0x60]
00007154327d5fca  vpermilpd xmm1, xmm1, 0x00
00007154327d5fd0  vmovaps xmm3, [rsp+0x70]
00007154327d5fd6  vmovaps [rsp+0x70], xmm15
00007154327d5fdc  movaps xmm9, xmm3
00007154327d5fe0  mulpd xmm9, xmm1
00007154327d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007154327d5feb  ptest xmm15, xmm15
00007154327d5ff1  jnz 0x00007154327D84E3
00007154327d5ff7  lea r14, [rax+0xC0]
00007154327d5ffe  movups xmm1, [r13+r14*1]
00007154327d6004  vmovaps xmm3, [rsp+0xC0]
00007154327d600d  vmovaps [rsp+0x80], xmm1
00007154327d6016  movaps xmm15, xmm3
00007154327d601a  addpd xmm15, xmm7
00007154327d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007154327d6025  ptest xmm1, xmm1
00007154327d602a  jnz 0x00007154327D862F
00007154327d6030  vmovaps [rsp+0xC0], xmm13
00007154327d6039  vmovaps xmm1, [rsp+0xC0]
00007154327d6042  por xmm13, xmm1
00007154327d6047  movaps [r15+0x270], xmm13
00007154327d604f  vmovaps xmm1, [rsp+0xB0]
00007154327d6058  vmovaps xmm7, [rsp+0xB0]
00007154327d6061  por xmm1, xmm7
00007154327d6065  movaps [r15+0x1A0], xmm1
00007154327d606d  vmovaps xmm1, [rsp+0x60]
00007154327d6073  vpermilpd xmm1, xmm1, 0x00
00007154327d6079  vmovaps [rsp+0xB0], xmm1
00007154327d6082  vmovaps xmm1, [rsp+0x80]
00007154327d608b  vmovaps [rsp+0x80], xmm15
00007154327d6094  vmovaps xmm15, [rsp+0xB0]
00007154327d609d  vmovaps [rsp+0xB0], xmm14
00007154327d60a6  movaps xmm3, xmm1
00007154327d60a9  mulpd xmm3, xmm15
00007154327d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007154327d60b3  ptest xmm14, xmm14
00007154327d60b9  jnz 0x00007154327D8771
00007154327d60bf  lea r14, [rax+0x20]
00007154327d60c3  movups xmm1, [r13+r14*1]
00007154327d60c9  movaps [r15+0x110], xmm1
00007154327d60d1  vmovaps xmm14, [rsp+0x70]
00007154327d60d7  vmovaps [rsp+0x70], xmm1
00007154327d60dd  movaps xmm15, xmm14
00007154327d60e1  addpd xmm15, xmm4
00007154327d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007154327d60ec  ptest xmm1, xmm1
00007154327d60f1  jnz 0x00007154327D88BC
00007154327d60f7  vmovaps xmm1, [rsp+0x60]
00007154327d60fd  vpermilpd xmm1, xmm1, 0x00
00007154327d6103  movaps xmm14, xmm2
00007154327d6107  mulpd xmm14, xmm1
00007154327d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007154327d6112  ptest xmm4, xmm4
00007154327d6117  jnz 0x00007154327D89FF
00007154327d611d  vmovaps xmm4, [rsp+0x50]
00007154327d6123  movaps xmm1, xmm4
00007154327d6126  addpd xmm1, xmm9
00007154327d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007154327d6130  ptest xmm2, xmm2
00007154327d6135  jnz 0x00007154327D8B41
00007154327d613b  vmovaps xmm9, [rsp+0x30]
00007154327d6141  vpermilpd xmm9, xmm9, 0x00
00007154327d6147  vmovaps xmm2, [rsp+0x70]
00007154327d614d  vmovaps [rsp+0x50], xmm1
00007154327d6153  movaps xmm4, xmm2
00007154327d6156  mulpd xmm4, xmm9
00007154327d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007154327d6160  ptest xmm1, xmm1
00007154327d6165  jnz 0x00007154327D8C82
00007154327d616b  vmovaps xmm1, [rsp+0x30]
00007154327d6171  vpermilpd xmm1, xmm1, 0x00
00007154327d6177  vmovaps xmm2, [rsp+0x90]
00007154327d6180  vmovaps [rsp+0x60], xmm15
00007154327d6186  movaps xmm9, xmm2
00007154327d618a  mulpd xmm9, xmm1
00007154327d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007154327d6195  ptest xmm15, xmm15
00007154327d619b  jnz 0x00007154327D8DC3
00007154327d61a1  vmovaps xmm15, [rsp+0x80]
00007154327d61aa  movaps xmm1, xmm15
00007154327d61ae  addpd xmm1, xmm6
00007154327d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007154327d61b7  ptest xmm2, xmm2
00007154327d61bc  jnz 0x00007154327D8F05
00007154327d61c2  movaps xmm15, xmm5
00007154327d61c6  addpd xmm15, xmm3
00007154327d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007154327d61d1  ptest xmm6, xmm6
00007154327d61d6  jnz 0x00007154327D9046
00007154327d61dc  vmovaps xmm6, [rsp+0x30]
00007154327d61e2  vpermilpd xmm6, xmm6, 0x00
00007154327d61e8  movaps xmm5, xmm8
00007154327d61ec  mulpd xmm5, xmm6
00007154327d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007154327d61f5  ptest xmm3, xmm3
00007154327d61fa  jnz 0x00007154327D9188
00007154327d6200  vmovaps xmm8, [rsp+0x30]
00007154327d6206  vpermilpd xmm8, xmm8, 0x00
00007154327d620c  movaps xmm6, xmm10
00007154327d6210  mulpd xmm6, xmm8
00007154327d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007154327d621a  ptest xmm3, xmm3
00007154327d621f  jnz 0x00007154327D92C9
00007154327d6225  vmovaps xmm8, [rsp+0x60]
00007154327d622b  movaps xmm10, xmm8
00007154327d622f  addpd xmm10, xmm14
00007154327d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007154327d623a  ptest xmm3, xmm3
00007154327d623f  jnz 0x00007154327D940B
00007154327d6245  vmovaps xmm8, [rsp+0x50]
00007154327d624b  movaps xmm14, xmm8
00007154327d624f  addpd xmm14, xmm4
00007154327d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007154327d625a  ptest xmm3, xmm3
00007154327d625f  jnz 0x00007154327D954F
00007154327d6265  vmovaps xmm8, [rsp+0x40]
00007154327d626b  vpermilpd xmm8, xmm8, 0x00
00007154327d6271  movaps xmm4, xmm13
00007154327d6275  mulpd xmm4, xmm8
00007154327d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007154327d627f  ptest xmm3, xmm3
00007154327d6284  jnz 0x00007154327D9692
00007154327d628a  movaps xmm13, xmm15
00007154327d628e  addpd xmm13, xmm9
00007154327d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007154327d6299  ptest xmm8, xmm8
00007154327d629f  jnz 0x00007154327D97D4
00007154327d62a5  movaps xmm15, xmm1
00007154327d62a9  addpd xmm15, xmm5
00007154327d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007154327d62b4  ptest xmm9, xmm9
00007154327d62ba  jnz 0x00007154327D9918
00007154327d62c0  vmovaps [rsp+0x30], xmm11
00007154327d62c6  vmovaps xmm1, [rsp+0x30]
00007154327d62cc  por xmm11, xmm1
00007154327d62d1  movaps [r15+0x250], xmm11
00007154327d62d9  vmovaps [rsp+0x30], xmm12
00007154327d62df  vmovaps xmm1, [rsp+0x30]
00007154327d62e5  por xmm12, xmm1
00007154327d62ea  movaps [r15+0x2A0], xmm12
00007154327d62f2  vmovaps xmm1, [rsp+0xA0]
00007154327d62fb  vmovaps xmm11, [rsp+0xA0]
00007154327d6304  por xmm1, xmm11
00007154327d6309  movaps [r15+0x1D0], xmm1
00007154327d6311  lea r14, [rax+0x40]
00007154327d6315  movups xmm1, [r13+r14*1]
00007154327d631b  movaps [r15+0x2C0], xmm1
00007154327d6323  vmovaps xmm11, [rsp+0x40]
00007154327d6329  vpermilpd xmm11, xmm11, 0x00
00007154327d632f  vmovaps xmm8, [rsp+0xE0]
00007154327d6338  movaps xmm9, xmm8
00007154327d633c  mulpd xmm9, xmm11
00007154327d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007154327d6347  ptest xmm5, xmm5
00007154327d634c  jnz 0x00007154327D9A64
00007154327d6352  movaps xmm11, xmm10
00007154327d6356  addpd xmm11, xmm6
00007154327d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007154327d6361  ptest xmm8, xmm8
00007154327d6367  jnz 0x00007154327D9BA8
00007154327d636d  movaps xmm10, xmm14
00007154327d6371  addpd xmm10, xmm4
00007154327d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007154327d637c  ptest xmm8, xmm8
00007154327d6382  jnz 0x00007154327D9CEB
00007154327d6388  vmovaps xmm14, [rsp+0x40]
00007154327d638e  vpermilpd xmm14, xmm14, 0x00
00007154327d6394  movaps xmm8, xmm1
00007154327d6398  mulpd xmm8, xmm14
00007154327d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007154327d63a3  ptest xmm6, xmm6
00007154327d63a8  jnz 0x00007154327D9E2E
00007154327d63ae  movaps xmm1, [r15+0x2B0]
00007154327d63b6  vmovaps xmm14, [rsp+0x40]
00007154327d63bc  vpermilpd xmm14, xmm14, 0x00
00007154327d63c2  movaps xmm6, xmm1
00007154327d63c5  mulpd xmm6, xmm14
00007154327d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007154327d63cf  ptest xmm5, xmm5
00007154327d63d4  jnz 0x00007154327D9F71
00007154327d63da  vmovaps xmm1, [rsp+0x10]
00007154327d63e0  vpermilpd xmm1, xmm1, 0x00
00007154327d63e6  movaps xmm14, xmm12
00007154327d63ea  mulpd xmm14, xmm1
00007154327d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007154327d63f5  ptest xmm5, xmm5
00007154327d63fa  jnz 0x00007154327DA0B2
00007154327d6400  movaps xmm1, xmm13
00007154327d6404  addpd xmm1, xmm9
00007154327d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007154327d640e  ptest xmm12, xmm12
00007154327d6414  jnz 0x00007154327DA1F5
00007154327d641a  vmovaps xmm13, [rsp+0x10]
00007154327d6420  vpermilpd xmm13, xmm13, 0x00
00007154327d6426  movaps xmm12, xmm7
00007154327d642a  mulpd xmm12, xmm13
00007154327d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007154327d6435  ptest xmm9, xmm9
00007154327d643b  jnz 0x00007154327DA337
00007154327d6441  movaps xmm13, xmm15
00007154327d6445  addpd xmm13, xmm8
00007154327d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007154327d6450  ptest xmm9, xmm9
00007154327d6456  jnz 0x00007154327DA47A
00007154327d645c  movaps xmm15, [r15+0x290]
00007154327d6464  vmovaps xmm9, [rsp+0x10]
00007154327d646a  vpermilpd xmm9, xmm9, 0x00
00007154327d6470  movaps xmm8, xmm15
00007154327d6474  mulpd xmm8, xmm9
00007154327d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007154327d647f  ptest xmm7, xmm7
00007154327d6484  jnz 0x00007154327DA5BE
00007154327d648a  movaps xmm15, xmm11
00007154327d648e  addpd xmm15, xmm6
00007154327d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007154327d6499  ptest xmm9, xmm9
00007154327d649f  jnz 0x00007154327DA702
00007154327d64a5  movaps xmm11, [r15+0x1E0]
00007154327d64ad  vmovaps xmm9, [rsp+0x10]
00007154327d64b3  vpermilpd xmm9, xmm9, 0x00
00007154327d64b9  movaps xmm7, xmm11
00007154327d64bd  mulpd xmm7, xmm9
00007154327d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007154327d64c7  ptest xmm6, xmm6
00007154327d64cc  jnz 0x00007154327DA845
00007154327d64d2  movaps xmm11, xmm10
00007154327d64d6  addpd xmm11, xmm14
00007154327d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007154327d64e1  ptest xmm9, xmm9
00007154327d64e7  jnz 0x00007154327DA987
00007154327d64ed  lea r14, [rax+0x70]
00007154327d64f1  movups xmm14, [r13+r14*1]
00007154327d64f7  movaps [r15+0x240], xmm14
00007154327d64ff  movaps xmm10, xmm1
00007154327d6503  addpd xmm10, xmm12
00007154327d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007154327d650e  ptest xmm9, xmm9
00007154327d6514  jnz 0x00007154327DAAD5
00007154327d651a  movaps [r15+0x170], xmm10
00007154327d6522  vmovaps xmm1, [rsp+0x20]
00007154327d6528  vpermilpd xmm1, xmm1, 0x00
00007154327d652e  movaps xmm12, xmm14
00007154327d6532  mulpd xmm12, xmm1
00007154327d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007154327d653d  ptest xmm9, xmm9
00007154327d6543  jnz 0x00007154327DAC18
00007154327d6549  vmovaps xmm1, [rsp+0x20]
00007154327d654f  vpermilpd xmm1, xmm1, 0x00
00007154327d6555  vmovaps xmm9, [rsp+0xB0]
00007154327d655e  movaps xmm14, xmm9
00007154327d6562  mulpd xmm14, xmm1
00007154327d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007154327d656d  ptest xmm6, xmm6
00007154327d6572  jnz 0x00007154327DAD5B
00007154327d6578  movaps [r15+0x180], xmm14
00007154327d6580  movaps xmm1, xmm13
00007154327d6584  addpd xmm1, xmm8
00007154327d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007154327d658e  ptest xmm9, xmm9
00007154327d6594  jnz 0x00007154327DAE9E
00007154327d659a  movaps [r15+0x210], xmm1
00007154327d65a2  movups xmm13, [r13+rax*1]
00007154327d65a8  lea r14, [rax+0x10]
00007154327d65ac  movups xmm9, [r13+r14*1]
00007154327d65b2  movaps [r15+0x230], xmm9
00007154327d65ba  movaps xmm8, xmm15
00007154327d65be  addpd xmm8, xmm7
00007154327d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007154327d65c9  ptest xmm6, xmm6
00007154327d65ce  jnz 0x00007154327DAFF4
00007154327d65d4  movaps [r15+0x130], xmm8
00007154327d65dc  vmovaps xmm15, [rsp+0x20]
00007154327d65e2  vpermilpd xmm15, xmm15, 0x00
00007154327d65e8  movaps xmm7, xmm9
00007154327d65ec  mulpd xmm7, xmm15
00007154327d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007154327d65f6  ptest xmm6, xmm6
00007154327d65fb  jnz 0x00007154327DB137
00007154327d6601  movaps [r15+0x220], xmm7
00007154327d6609  vmovaps xmm15, [rsp+0x20]
00007154327d660f  vpermilpd xmm15, xmm15, 0x00
00007154327d6615  movaps xmm9, xmm13
00007154327d6619  mulpd xmm9, xmm15
00007154327d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007154327d6624  ptest xmm6, xmm6
00007154327d6629  jnz 0x00007154327DB279
00007154327d662f  movaps xmm15, xmm11
00007154327d6633  addpd xmm15, xmm12
00007154327d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007154327d663e  ptest xmm13, xmm13
00007154327d6644  jnz 0x00007154327DB3BD
00007154327d664a  movaps [r15+0x140], xmm15
00007154327d6652  movaps xmm13, xmm10
00007154327d6656  addpd xmm13, xmm14
00007154327d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007154327d6661  ptest xmm12, xmm12
00007154327d6667  jnz 0x00007154327DB501
00007154327d666d  movaps [r15+0x150], xmm13
00007154327d6675  movaps xmm14, xmm1
00007154327d6679  addpd xmm14, xmm7
00007154327d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007154327d6684  ptest xmm12, xmm12
00007154327d668a  jnz 0x00007154327DB645
00007154327d6690  movaps [r15+0x160], xmm14
00007154327d6698  movaps xmm1, xmm8
00007154327d669c  addpd xmm1, xmm9
00007154327d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007154327d66a6  ptest xmm12, xmm12
00007154327d66ac  jnz 0x00007154327DB787
00007154327d66b2  movaps [r15+0x120], xmm1
00007154327d66ba  movups [r13+r11*1], xmm15
00007154327d66c0  lea rax, [r11+0x10]
00007154327d66c4  movups [r13+rax*1], xmm13
00007154327d66ca  lea rax, [r11+0x20]
00007154327d66ce  movups [r13+rax*1], xmm14
00007154327d66d4  lea rax, [r11+0x30]
00007154327d66d8  movups [r13+rax*1], xmm1
00007154327d66de  mov eax, [r15+0x108]
00007154327d66e5  sahf
00007154327d66e6  jnz 0x00007154327D6718
00007154327d66e8  cmp dword ptr [r15+0x318], 0x00
00007154327d66f0  jz 0x00007154327DB900
00007154327d66f6  nop [rax+rax*1], ax
00007154327d66ff  nop [rax+rax*1], eax
00007154327d6707  mov eax, 0x410444
00007154327d670c  mov [r15+0x100], rax
00007154327d6713  jmp 0x00007154325FE110
00007154327d6718  cmp dword ptr [r15+0x318], 0x00
00007154327d6720  jz 0x00007154327D57E0
00007154327d6726  nop [rax+rax*1], ax
00007154327d672f  nop [rax+rax*1], eax
00007154327d6737  mov eax, 0x410278
00007154327d673c  mov [r15+0x100], rax
00007154327d6743  jmp 0x00007154325FE110
00007154327d6748  int3
00007154327d6749  call 0x000071543260A4B0
00007154327d674e  jmp 0x00007154327D5828
00007154327d6753  call 0x0000715432609240
00007154327d6758  jmp 0x00007154327D5832
00007154327d675d  call 0x000071543260A4B0
00007154327d6762  jmp 0x00007154327D588F
00007154327d6767  call 0x0000715432609240
00007154327d676c  jmp 0x00007154327D5899
00007154327d6771  call 0x000071543260A4B0
00007154327d6776  jmp 0x00007154327D58DD
00007154327d677b  call 0x0000715432609240
00007154327d6780  jmp 0x00007154327D58E7
00007154327d6785  call 0x00007154326B47C0
00007154327d678a  jmp 0x00007154327D5926
00007154327d678f  call 0x000071543260B720
00007154327d6794  jmp 0x00007154327D593A
00007154327d6799  call 0x00007154326BFC30
00007154327d679e  jmp 0x00007154327D5958
00007154327d67a3  call 0x00007154326BE9C0
00007154327d67a8  jmp 0x00007154327D5962
00007154327d67ad  call 0x00007154326BD750
00007154327d67b2  jmp 0x00007154327D596C
00007154327d67b7  sub rsp, 0x08
00007154327d67bb  push rax
00007154327d67bc  push rcx
00007154327d67bd  push rdx
00007154327d67be  push rdi
00007154327d67bf  push rsi
00007154327d67c0  push r8
00007154327d67c2  push r9
00007154327d67c4  push r10
00007154327d67c6  push r11
00007154327d67c8  sub rsp, 0xF0
00007154327d67cf  vmovaps [rsp], xmm0
00007154327d67d4  vmovaps [rsp+0x10], xmm1
00007154327d67da  vmovaps [rsp+0x20], xmm2
00007154327d67e0  vmovaps [rsp+0x30], xmm3
00007154327d67e6  vmovaps [rsp+0x40], xmm4
00007154327d67ec  vmovaps [rsp+0x50], xmm5
00007154327d67f2  vmovaps [rsp+0x60], xmm6
00007154327d67f8  vmovaps [rsp+0x70], xmm7
00007154327d67fe  vmovaps [rsp+0x80], xmm9
00007154327d6807  vmovaps [rsp+0x90], xmm10
00007154327d6810  vmovaps [rsp+0xA0], xmm11
00007154327d6819  vmovaps [rsp+0xB0], xmm12
00007154327d6822  vmovaps [rsp+0xC0], xmm13
00007154327d682b  vmovaps [rsp+0xD0], xmm14
00007154327d6834  vmovaps [rsp+0xE0], xmm15
00007154327d683d  sub rsp, 0x30
00007154327d6841  movaps [rsp], xmm8
00007154327d6846  movaps [rsp+0x10], xmm12
00007154327d684c  movaps [rsp+0x20], xmm15
00007154327d6852  lea rdi, [rsp]
00007154327d6856  mov esi, 0x00
00007154327d685b  mov rax, 0x5A63B06A5530
00007154327d6865  call rax
00007154327d6867  movaps xmm8, [rsp]
00007154327d686c  add rsp, 0x30
00007154327d6870  vmovaps xmm0, [rsp]
00007154327d6875  vmovaps xmm1, [rsp+0x10]
00007154327d687b  vmovaps xmm2, [rsp+0x20]
00007154327d6881  vmovaps xmm3, [rsp+0x30]
00007154327d6887  vmovaps xmm4, [rsp+0x40]
00007154327d688d  vmovaps xmm5, [rsp+0x50]
00007154327d6893  vmovaps xmm6, [rsp+0x60]
00007154327d6899  vmovaps xmm7, [rsp+0x70]
00007154327d689f  vmovaps xmm9, [rsp+0x80]
00007154327d68a8  vmovaps xmm10, [rsp+0x90]
00007154327d68b1  vmovaps xmm11, [rsp+0xA0]
00007154327d68ba  vmovaps xmm12, [rsp+0xB0]
00007154327d68c3  vmovaps xmm13, [rsp+0xC0]
00007154327d68cc  vmovaps xmm14, [rsp+0xD0]
00007154327d68d5  vmovaps xmm15, [rsp+0xE0]
00007154327d68de  add rsp, 0xF0
00007154327d68e5  pop r11
00007154327d68e7  pop r10
00007154327d68e9  pop r9
00007154327d68eb  pop r8
00007154327d68ed  pop rsi
00007154327d68ee  pop rdi
00007154327d68ef  pop rdx
00007154327d68f0  pop rcx
00007154327d68f1  pop rax
00007154327d68f2  add rsp, 0x08
00007154327d68f6  jmp 0x00007154327D599A
00007154327d68fb  sub rsp, 0x08
00007154327d68ff  push rax
00007154327d6900  push rcx
00007154327d6901  push rdx
00007154327d6902  push rdi
00007154327d6903  push rsi
00007154327d6904  push r8
00007154327d6906  push r9
00007154327d6908  push r10
00007154327d690a  push r11
00007154327d690c  sub rsp, 0xF0
00007154327d6913  vmovaps [rsp], xmm0
00007154327d6918  vmovaps [rsp+0x10], xmm1
00007154327d691e  vmovaps [rsp+0x20], xmm2
00007154327d6924  vmovaps [rsp+0x30], xmm3
00007154327d692a  vmovaps [rsp+0x40], xmm4
00007154327d6930  vmovaps [rsp+0x50], xmm5
00007154327d6936  vmovaps [rsp+0x60], xmm6
00007154327d693c  vmovaps [rsp+0x70], xmm8
00007154327d6942  vmovaps [rsp+0x80], xmm9
00007154327d694b  vmovaps [rsp+0x90], xmm10
00007154327d6954  vmovaps [rsp+0xA0], xmm11
00007154327d695d  vmovaps [rsp+0xB0], xmm12
00007154327d6966  vmovaps [rsp+0xC0], xmm13
00007154327d696f  vmovaps [rsp+0xD0], xmm14
00007154327d6978  vmovaps [rsp+0xE0], xmm15
00007154327d6981  sub rsp, 0x30
00007154327d6985  movaps [rsp], xmm7
00007154327d6989  movaps [rsp+0x10], xmm9
00007154327d698f  movaps [rsp+0x20], xmm15
00007154327d6995  lea rdi, [rsp]
00007154327d6999  mov esi, 0x00
00007154327d699e  mov rax, 0x5A63B06A5530
00007154327d69a8  call rax
00007154327d69aa  movaps xmm7, [rsp]
00007154327d69ae  add rsp, 0x30
00007154327d69b2  vmovaps xmm0, [rsp]
00007154327d69b7  vmovaps xmm1, [rsp+0x10]
00007154327d69bd  vmovaps xmm2, [rsp+0x20]
00007154327d69c3  vmovaps xmm3, [rsp+0x30]
00007154327d69c9  vmovaps xmm4, [rsp+0x40]
00007154327d69cf  vmovaps xmm5, [rsp+0x50]
00007154327d69d5  vmovaps xmm6, [rsp+0x60]
00007154327d69db  vmovaps xmm8, [rsp+0x70]
00007154327d69e1  vmovaps xmm9, [rsp+0x80]
00007154327d69ea  vmovaps xmm10, [rsp+0x90]
00007154327d69f3  vmovaps xmm11, [rsp+0xA0]
00007154327d69fc  vmovaps xmm12, [rsp+0xB0]
00007154327d6a05  vmovaps xmm13, [rsp+0xC0]
00007154327d6a0e  vmovaps xmm14, [rsp+0xD0]
00007154327d6a17  vmovaps xmm15, [rsp+0xE0]
00007154327d6a20  add rsp, 0xF0
00007154327d6a27  pop r11
00007154327d6a29  pop r10
00007154327d6a2b  pop r9
00007154327d6a2d  pop r8
00007154327d6a2f  pop rsi
00007154327d6a30  pop rdi
00007154327d6a31  pop rdx
00007154327d6a32  pop rcx
00007154327d6a33  pop rax
00007154327d6a34  add rsp, 0x08
00007154327d6a38  jmp 0x00007154327D59C8
00007154327d6a3d  sub rsp, 0x08
00007154327d6a41  push rax
00007154327d6a42  push rcx
00007154327d6a43  push rdx
00007154327d6a44  push rdi
00007154327d6a45  push rsi
00007154327d6a46  push r8
00007154327d6a48  push r9
00007154327d6a4a  push r10
00007154327d6a4c  push r11
00007154327d6a4e  sub rsp, 0xF0
00007154327d6a55  vmovaps [rsp], xmm0
00007154327d6a5a  vmovaps [rsp+0x10], xmm1
00007154327d6a60  vmovaps [rsp+0x20], xmm2
00007154327d6a66  vmovaps [rsp+0x30], xmm3
00007154327d6a6c  vmovaps [rsp+0x40], xmm4
00007154327d6a72  vmovaps [rsp+0x50], xmm5
00007154327d6a78  vmovaps [rsp+0x60], xmm6
00007154327d6a7e  vmovaps [rsp+0x70], xmm7
00007154327d6a84  vmovaps [rsp+0x80], xmm8
00007154327d6a8d  vmovaps [rsp+0x90], xmm10
00007154327d6a96  vmovaps [rsp+0xA0], xmm11
00007154327d6a9f  vmovaps [rsp+0xB0], xmm12
00007154327d6aa8  vmovaps [rsp+0xC0], xmm13
00007154327d6ab1  vmovaps [rsp+0xD0], xmm14
00007154327d6aba  vmovaps [rsp+0xE0], xmm15
00007154327d6ac3  sub rsp, 0x30
00007154327d6ac7  movaps [rsp], xmm9
00007154327d6acc  movaps [rsp+0x10], xmm12
00007154327d6ad2  movaps [rsp+0x20], xmm10
00007154327d6ad8  lea rdi, [rsp]
00007154327d6adc  mov esi, 0x00
00007154327d6ae1  mov rax, 0x5A63B06A5530
00007154327d6aeb  call rax
00007154327d6aed  movaps xmm9, [rsp]
00007154327d6af2  add rsp, 0x30
00007154327d6af6  vmovaps xmm0, [rsp]
00007154327d6afb  vmovaps xmm1, [rsp+0x10]
00007154327d6b01  vmovaps xmm2, [rsp+0x20]
00007154327d6b07  vmovaps xmm3, [rsp+0x30]
00007154327d6b0d  vmovaps xmm4, [rsp+0x40]
00007154327d6b13  vmovaps xmm5, [rsp+0x50]
00007154327d6b19  vmovaps xmm6, [rsp+0x60]
00007154327d6b1f  vmovaps xmm7, [rsp+0x70]
00007154327d6b25  vmovaps xmm8, [rsp+0x80]
00007154327d6b2e  vmovaps xmm10, [rsp+0x90]
00007154327d6b37  vmovaps xmm11, [rsp+0xA0]
00007154327d6b40  vmovaps xmm12, [rsp+0xB0]
00007154327d6b49  vmovaps xmm13, [rsp+0xC0]
00007154327d6b52  vmovaps xmm14, [rsp+0xD0]
00007154327d6b5b  vmovaps xmm15, [rsp+0xE0]
00007154327d6b64  add rsp, 0xF0
00007154327d6b6b  pop r11
00007154327d6b6d  pop r10
00007154327d6b6f  pop r9
00007154327d6b71  pop r8
00007154327d6b73  pop rsi
00007154327d6b74  pop rdi
00007154327d6b75  pop rdx
00007154327d6b76  pop rcx
00007154327d6b77  pop rax
00007154327d6b78  add rsp, 0x08
00007154327d6b7c  jmp 0x00007154327D59EC
00007154327d6b81  sub rsp, 0x08
00007154327d6b85  push rax
00007154327d6b86  push rcx
00007154327d6b87  push rdx
00007154327d6b88  push rdi
00007154327d6b89  push rsi
00007154327d6b8a  push r8
00007154327d6b8c  push r9
00007154327d6b8e  push r10
00007154327d6b90  push r11
00007154327d6b92  sub rsp, 0xF0
00007154327d6b99  vmovaps [rsp], xmm0
00007154327d6b9e  vmovaps [rsp+0x10], xmm1
00007154327d6ba4  vmovaps [rsp+0x20], xmm2
00007154327d6baa  vmovaps [rsp+0x30], xmm3
00007154327d6bb0  vmovaps [rsp+0x40], xmm4
00007154327d6bb6  vmovaps [rsp+0x50], xmm5
00007154327d6bbc  vmovaps [rsp+0x60], xmm6
00007154327d6bc2  vmovaps [rsp+0x70], xmm7
00007154327d6bc8  vmovaps [rsp+0x80], xmm8
00007154327d6bd1  vmovaps [rsp+0x90], xmm9
00007154327d6bda  vmovaps [rsp+0xA0], xmm11
00007154327d6be3  vmovaps [rsp+0xB0], xmm12
00007154327d6bec  vmovaps [rsp+0xC0], xmm13
00007154327d6bf5  vmovaps [rsp+0xD0], xmm14
00007154327d6bfe  vmovaps [rsp+0xE0], xmm15
00007154327d6c07  sub rsp, 0x30
00007154327d6c0b  movaps [rsp], xmm10
00007154327d6c10  movaps [rsp+0x10], xmm12
00007154327d6c16  movaps [rsp+0x20], xmm11
00007154327d6c1c  lea rdi, [rsp]
00007154327d6c20  mov esi, 0x00
00007154327d6c25  mov rax, 0x5A63B06A5530
00007154327d6c2f  call rax
00007154327d6c31  movaps xmm10, [rsp]
00007154327d6c36  add rsp, 0x30
00007154327d6c3a  vmovaps xmm0, [rsp]
00007154327d6c3f  vmovaps xmm1, [rsp+0x10]
00007154327d6c45  vmovaps xmm2, [rsp+0x20]
00007154327d6c4b  vmovaps xmm3, [rsp+0x30]
00007154327d6c51  vmovaps xmm4, [rsp+0x40]
00007154327d6c57  vmovaps xmm5, [rsp+0x50]
00007154327d6c5d  vmovaps xmm6, [rsp+0x60]
00007154327d6c63  vmovaps xmm7, [rsp+0x70]
00007154327d6c69  vmovaps xmm8, [rsp+0x80]
00007154327d6c72  vmovaps xmm9, [rsp+0x90]
00007154327d6c7b  vmovaps xmm11, [rsp+0xA0]
00007154327d6c84  vmovaps xmm12, [rsp+0xB0]
00007154327d6c8d  vmovaps xmm13, [rsp+0xC0]
00007154327d6c96  vmovaps xmm14, [rsp+0xD0]
00007154327d6c9f  vmovaps xmm15, [rsp+0xE0]
00007154327d6ca8  add rsp, 0xF0
00007154327d6caf  pop r11
00007154327d6cb1  pop r10
00007154327d6cb3  pop r9
00007154327d6cb5  pop r8
00007154327d6cb7  pop rsi
00007154327d6cb8  pop rdi
00007154327d6cb9  pop rdx
00007154327d6cba  pop rcx
00007154327d6cbb  pop rax
00007154327d6cbc  add rsp, 0x08
00007154327d6cc0  jmp 0x00007154327D5A06
00007154327d6cc5  sub rsp, 0x08
00007154327d6cc9  push rax
00007154327d6cca  push rcx
00007154327d6ccb  push rdx
00007154327d6ccc  push rdi
00007154327d6ccd  push rsi
00007154327d6cce  push r8
00007154327d6cd0  push r9
00007154327d6cd2  push r10
00007154327d6cd4  push r11
00007154327d6cd6  sub rsp, 0xF0
00007154327d6cdd  vmovaps [rsp], xmm0
00007154327d6ce2  vmovaps [rsp+0x10], xmm1
00007154327d6ce8  vmovaps [rsp+0x20], xmm2
00007154327d6cee  vmovaps [rsp+0x30], xmm3
00007154327d6cf4  vmovaps [rsp+0x40], xmm4
00007154327d6cfa  vmovaps [rsp+0x50], xmm5
00007154327d6d00  vmovaps [rsp+0x60], xmm7
00007154327d6d06  vmovaps [rsp+0x70], xmm8
00007154327d6d0c  vmovaps [rsp+0x80], xmm9
00007154327d6d15  vmovaps [rsp+0x90], xmm10
00007154327d6d1e  vmovaps [rsp+0xA0], xmm11
00007154327d6d27  vmovaps [rsp+0xB0], xmm12
00007154327d6d30  vmovaps [rsp+0xC0], xmm13
00007154327d6d39  vmovaps [rsp+0xD0], xmm14
00007154327d6d42  vmovaps [rsp+0xE0], xmm15
00007154327d6d4b  sub rsp, 0x30
00007154327d6d4f  movaps [rsp], xmm6
00007154327d6d53  movaps [rsp+0x10], xmm12
00007154327d6d59  movaps [rsp+0x20], xmm11
00007154327d6d5f  lea rdi, [rsp]
00007154327d6d63  mov esi, 0x00
00007154327d6d68  mov rax, 0x5A63B06A5530
00007154327d6d72  call rax
00007154327d6d74  movaps xmm6, [rsp]
00007154327d6d78  add rsp, 0x30
00007154327d6d7c  vmovaps xmm0, [rsp]
00007154327d6d81  vmovaps xmm1, [rsp+0x10]
00007154327d6d87  vmovaps xmm2, [rsp+0x20]
00007154327d6d8d  vmovaps xmm3, [rsp+0x30]
00007154327d6d93  vmovaps xmm4, [rsp+0x40]
00007154327d6d99  vmovaps xmm5, [rsp+0x50]
00007154327d6d9f  vmovaps xmm7, [rsp+0x60]
00007154327d6da5  vmovaps xmm8, [rsp+0x70]
00007154327d6dab  vmovaps xmm9, [rsp+0x80]
00007154327d6db4  vmovaps xmm10, [rsp+0x90]
00007154327d6dbd  vmovaps xmm11, [rsp+0xA0]
00007154327d6dc6  vmovaps xmm12, [rsp+0xB0]
00007154327d6dcf  vmovaps xmm13, [rsp+0xC0]
00007154327d6dd8  vmovaps xmm14, [rsp+0xD0]
00007154327d6de1  vmovaps xmm15, [rsp+0xE0]
00007154327d6dea  add rsp, 0xF0
00007154327d6df1  pop r11
00007154327d6df3  pop r10
00007154327d6df5  pop r9
00007154327d6df7  pop r8
00007154327d6df9  pop rsi
00007154327d6dfa  pop rdi
00007154327d6dfb  pop rdx
00007154327d6dfc  pop rcx
00007154327d6dfd  pop rax
00007154327d6dfe  add rsp, 0x08
00007154327d6e02  jmp 0x00007154327D5A27
00007154327d6e07  sub rsp, 0x08
00007154327d6e0b  push rax
00007154327d6e0c  push rcx
00007154327d6e0d  push rdx
00007154327d6e0e  push rdi
00007154327d6e0f  push rsi
00007154327d6e10  push r8
00007154327d6e12  push r9
00007154327d6e14  push r10
00007154327d6e16  push r11
00007154327d6e18  sub rsp, 0xF0
00007154327d6e1f  vmovaps [rsp], xmm0
00007154327d6e24  vmovaps [rsp+0x10], xmm1
00007154327d6e2a  vmovaps [rsp+0x20], xmm2
00007154327d6e30  vmovaps [rsp+0x30], xmm4
00007154327d6e36  vmovaps [rsp+0x40], xmm5
00007154327d6e3c  vmovaps [rsp+0x50], xmm6
00007154327d6e42  vmovaps [rsp+0x60], xmm7
00007154327d6e48  vmovaps [rsp+0x70], xmm8
00007154327d6e4e  vmovaps [rsp+0x80], xmm9
00007154327d6e57  vmovaps [rsp+0x90], xmm10
00007154327d6e60  vmovaps [rsp+0xA0], xmm11
00007154327d6e69  vmovaps [rsp+0xB0], xmm12
00007154327d6e72  vmovaps [rsp+0xC0], xmm13
00007154327d6e7b  vmovaps [rsp+0xD0], xmm14
00007154327d6e84  vmovaps [rsp+0xE0], xmm15
00007154327d6e8d  sub rsp, 0x30
00007154327d6e91  movaps [rsp], xmm3
00007154327d6e95  movaps [rsp+0x10], xmm5
00007154327d6e9a  movaps [rsp+0x20], xmm4
00007154327d6e9f  lea rdi, [rsp]
00007154327d6ea3  mov esi, 0x00
00007154327d6ea8  mov rax, 0x5A63B06A5530
00007154327d6eb2  call rax
00007154327d6eb4  movaps xmm3, [rsp]
00007154327d6eb8  add rsp, 0x30
00007154327d6ebc  vmovaps xmm0, [rsp]
00007154327d6ec1  vmovaps xmm1, [rsp+0x10]
00007154327d6ec7  vmovaps xmm2, [rsp+0x20]
00007154327d6ecd  vmovaps xmm4, [rsp+0x30]
00007154327d6ed3  vmovaps xmm5, [rsp+0x40]
00007154327d6ed9  vmovaps xmm6, [rsp+0x50]
00007154327d6edf  vmovaps xmm7, [rsp+0x60]
00007154327d6ee5  vmovaps xmm8, [rsp+0x70]
00007154327d6eeb  vmovaps xmm9, [rsp+0x80]
00007154327d6ef4  vmovaps xmm10, [rsp+0x90]
00007154327d6efd  vmovaps xmm11, [rsp+0xA0]
00007154327d6f06  vmovaps xmm12, [rsp+0xB0]
00007154327d6f0f  vmovaps xmm13, [rsp+0xC0]
00007154327d6f18  vmovaps xmm14, [rsp+0xD0]
00007154327d6f21  vmovaps xmm15, [rsp+0xE0]
00007154327d6f2a  add rsp, 0xF0
00007154327d6f31  pop r11
00007154327d6f33  pop r10
00007154327d6f35  pop r9
00007154327d6f37  pop r8
00007154327d6f39  pop rsi
00007154327d6f3a  pop rdi
00007154327d6f3b  pop rdx
00007154327d6f3c  pop rcx
00007154327d6f3d  pop rax
00007154327d6f3e  add rsp, 0x08
00007154327d6f42  jmp 0x00007154327D5A88
00007154327d6f47  sub rsp, 0x08
00007154327d6f4b  push rax
00007154327d6f4c  push rcx
00007154327d6f4d  push rdx
00007154327d6f4e  push rdi
00007154327d6f4f  push rsi
00007154327d6f50  push r8
00007154327d6f52  push r9
00007154327d6f54  push r10
00007154327d6f56  push r11
00007154327d6f58  sub rsp, 0xF0
00007154327d6f5f  vmovaps [rsp], xmm0
00007154327d6f64  vmovaps [rsp+0x10], xmm1
00007154327d6f6a  vmovaps [rsp+0x20], xmm2
00007154327d6f70  vmovaps [rsp+0x30], xmm3
00007154327d6f76  vmovaps [rsp+0x40], xmm4
00007154327d6f7c  vmovaps [rsp+0x50], xmm6
00007154327d6f82  vmovaps [rsp+0x60], xmm7
00007154327d6f88  vmovaps [rsp+0x70], xmm8
00007154327d6f8e  vmovaps [rsp+0x80], xmm9
00007154327d6f97  vmovaps [rsp+0x90], xmm10
00007154327d6fa0  vmovaps [rsp+0xA0], xmm11
00007154327d6fa9  vmovaps [rsp+0xB0], xmm12
00007154327d6fb2  vmovaps [rsp+0xC0], xmm13
00007154327d6fbb  vmovaps [rsp+0xD0], xmm14
00007154327d6fc4  vmovaps [rsp+0xE0], xmm15
00007154327d6fcd  sub rsp, 0x30
00007154327d6fd1  movaps [rsp], xmm5
00007154327d6fd5  movaps [rsp+0x10], xmm8
00007154327d6fdb  movaps [rsp+0x20], xmm15
00007154327d6fe1  lea rdi, [rsp]
00007154327d6fe5  mov esi, 0x00
00007154327d6fea  mov rax, 0x5A63B06A5530
00007154327d6ff4  call rax
00007154327d6ff6  movaps xmm5, [rsp]
00007154327d6ffa  add rsp, 0x30
00007154327d6ffe  vmovaps xmm0, [rsp]
00007154327d7003  vmovaps xmm1, [rsp+0x10]
00007154327d7009  vmovaps xmm2, [rsp+0x20]
00007154327d700f  vmovaps xmm3, [rsp+0x30]
00007154327d7015  vmovaps xmm4, [rsp+0x40]
00007154327d701b  vmovaps xmm6, [rsp+0x50]
00007154327d7021  vmovaps xmm7, [rsp+0x60]
00007154327d7027  vmovaps xmm8, [rsp+0x70]
00007154327d702d  vmovaps xmm9, [rsp+0x80]
00007154327d7036  vmovaps xmm10, [rsp+0x90]
00007154327d703f  vmovaps xmm11, [rsp+0xA0]
00007154327d7048  vmovaps xmm12, [rsp+0xB0]
00007154327d7051  vmovaps xmm13, [rsp+0xC0]
00007154327d705a  vmovaps xmm14, [rsp+0xD0]
00007154327d7063  vmovaps xmm15, [rsp+0xE0]
00007154327d706c  add rsp, 0xF0
00007154327d7073  pop r11
00007154327d7075  pop r10
00007154327d7077  pop r9
00007154327d7079  pop r8
00007154327d707b  pop rsi
00007154327d707c  pop rdi
00007154327d707d  pop rdx
00007154327d707e  pop rcx
00007154327d707f  pop rax
00007154327d7080  add rsp, 0x08
00007154327d7084  jmp 0x00007154327D5AC0
00007154327d7089  sub rsp, 0x08
00007154327d708d  push rax
00007154327d708e  push rcx
00007154327d708f  push rdx
00007154327d7090  push rdi
00007154327d7091  push rsi
00007154327d7092  push r8
00007154327d7094  push r9
00007154327d7096  push r10
00007154327d7098  push r11
00007154327d709a  sub rsp, 0xF0
00007154327d70a1  vmovaps [rsp], xmm0
00007154327d70a6  vmovaps [rsp+0x10], xmm1
00007154327d70ac  vmovaps [rsp+0x20], xmm2
00007154327d70b2  vmovaps [rsp+0x30], xmm3
00007154327d70b8  vmovaps [rsp+0x40], xmm5
00007154327d70be  vmovaps [rsp+0x50], xmm6
00007154327d70c4  vmovaps [rsp+0x60], xmm7
00007154327d70ca  vmovaps [rsp+0x70], xmm8
00007154327d70d0  vmovaps [rsp+0x80], xmm9
00007154327d70d9  vmovaps [rsp+0x90], xmm10
00007154327d70e2  vmovaps [rsp+0xA0], xmm11
00007154327d70eb  vmovaps [rsp+0xB0], xmm12
00007154327d70f4  vmovaps [rsp+0xC0], xmm13
00007154327d70fd  vmovaps [rsp+0xD0], xmm14
00007154327d7106  vmovaps [rsp+0xE0], xmm15
00007154327d710f  sub rsp, 0x30
00007154327d7113  movaps [rsp], xmm4
00007154327d7117  movaps [rsp+0x10], xmm9
00007154327d711d  movaps [rsp+0x20], xmm8
00007154327d7123  lea rdi, [rsp]
00007154327d7127  mov esi, 0x00
00007154327d712c  mov rax, 0x5A63B06A5530
00007154327d7136  call rax
00007154327d7138  movaps xmm4, [rsp]
00007154327d713c  add rsp, 0x30
00007154327d7140  vmovaps xmm0, [rsp]
00007154327d7145  vmovaps xmm1, [rsp+0x10]
00007154327d714b  vmovaps xmm2, [rsp+0x20]
00007154327d7151  vmovaps xmm3, [rsp+0x30]
00007154327d7157  vmovaps xmm5, [rsp+0x40]
00007154327d715d  vmovaps xmm6, [rsp+0x50]
00007154327d7163  vmovaps xmm7, [rsp+0x60]
00007154327d7169  vmovaps xmm8, [rsp+0x70]
00007154327d716f  vmovaps xmm9, [rsp+0x80]
00007154327d7178  vmovaps xmm10, [rsp+0x90]
00007154327d7181  vmovaps xmm11, [rsp+0xA0]
00007154327d718a  vmovaps xmm12, [rsp+0xB0]
00007154327d7193  vmovaps xmm13, [rsp+0xC0]
00007154327d719c  vmovaps xmm14, [rsp+0xD0]
00007154327d71a5  vmovaps xmm15, [rsp+0xE0]
00007154327d71ae  add rsp, 0xF0
00007154327d71b5  pop r11
00007154327d71b7  pop r10
00007154327d71b9  pop r9
00007154327d71bb  pop r8
00007154327d71bd  pop rsi
00007154327d71be  pop rdi
00007154327d71bf  pop rdx
00007154327d71c0  pop rcx
00007154327d71c1  pop rax
00007154327d71c2  add rsp, 0x08
00007154327d71c6  jmp 0x00007154327D5AE1
00007154327d71cb  sub rsp, 0x08
00007154327d71cf  push rax
00007154327d71d0  push rcx
00007154327d71d1  push rdx
00007154327d71d2  push rdi
00007154327d71d3  push rsi
00007154327d71d4  push r8
00007154327d71d6  push r9
00007154327d71d8  push r10
00007154327d71da  push r11
00007154327d71dc  sub rsp, 0xF0
00007154327d71e3  vmovaps [rsp], xmm0
00007154327d71e8  vmovaps [rsp+0x10], xmm1
00007154327d71ee  vmovaps [rsp+0x20], xmm2
00007154327d71f4  vmovaps [rsp+0x30], xmm3
00007154327d71fa  vmovaps [rsp+0x40], xmm4
00007154327d7200  vmovaps [rsp+0x50], xmm5
00007154327d7206  vmovaps [rsp+0x60], xmm6
00007154327d720c  vmovaps [rsp+0x70], xmm7
00007154327d7212  vmovaps [rsp+0x80], xmm8
00007154327d721b  vmovaps [rsp+0x90], xmm10
00007154327d7224  vmovaps [rsp+0xA0], xmm11
00007154327d722d  vmovaps [rsp+0xB0], xmm12
00007154327d7236  vmovaps [rsp+0xC0], xmm13
00007154327d723f  vmovaps [rsp+0xD0], xmm14
00007154327d7248  vmovaps [rsp+0xE0], xmm15
00007154327d7251  sub rsp, 0x30
00007154327d7255  movaps [rsp], xmm9
00007154327d725a  movaps [rsp+0x10], xmm10
00007154327d7260  movaps [rsp+0x20], xmm8
00007154327d7266  lea rdi, [rsp]
00007154327d726a  mov esi, 0x00
00007154327d726f  mov rax, 0x5A63B06A5530
00007154327d7279  call rax
00007154327d727b  movaps xmm9, [rsp]
00007154327d7280  add rsp, 0x30
00007154327d7284  vmovaps xmm0, [rsp]
00007154327d7289  vmovaps xmm1, [rsp+0x10]
00007154327d728f  vmovaps xmm2, [rsp+0x20]
00007154327d7295  vmovaps xmm3, [rsp+0x30]
00007154327d729b  vmovaps xmm4, [rsp+0x40]
00007154327d72a1  vmovaps xmm5, [rsp+0x50]
00007154327d72a7  vmovaps xmm6, [rsp+0x60]
00007154327d72ad  vmovaps xmm7, [rsp+0x70]
00007154327d72b3  vmovaps xmm8, [rsp+0x80]
00007154327d72bc  vmovaps xmm10, [rsp+0x90]
00007154327d72c5  vmovaps xmm11, [rsp+0xA0]
00007154327d72ce  vmovaps xmm12, [rsp+0xB0]
00007154327d72d7  vmovaps xmm13, [rsp+0xC0]
00007154327d72e0  vmovaps xmm14, [rsp+0xD0]
00007154327d72e9  vmovaps xmm15, [rsp+0xE0]
00007154327d72f2  add rsp, 0xF0
00007154327d72f9  pop r11
00007154327d72fb  pop r10
00007154327d72fd  pop r9
00007154327d72ff  pop r8
00007154327d7301  pop rsi
00007154327d7302  pop rdi
00007154327d7303  pop rdx
00007154327d7304  pop rcx
00007154327d7305  pop rax
00007154327d7306  add rsp, 0x08
00007154327d730a  jmp 0x00007154327D5AFB
00007154327d730f  call 0x00007154326D64F0
00007154327d7314  jmp 0x00007154327D5C15
00007154327d7319  call 0x00007154326D64F0
00007154327d731e  jmp 0x00007154327D5C2B
00007154327d7323  sub rsp, 0x08
00007154327d7327  push rax
00007154327d7328  push rcx
00007154327d7329  push rdx
00007154327d732a  push rdi
00007154327d732b  push rsi
00007154327d732c  push r8
00007154327d732e  push r9
00007154327d7330  push r10
00007154327d7332  push r11
00007154327d7334  sub rsp, 0xF0
00007154327d733b  vmovaps [rsp], xmm0
00007154327d7340  vmovaps [rsp+0x10], xmm2
00007154327d7346  vmovaps [rsp+0x20], xmm3
00007154327d734c  vmovaps [rsp+0x30], xmm4
00007154327d7352  vmovaps [rsp+0x40], xmm5
00007154327d7358  vmovaps [rsp+0x50], xmm6
00007154327d735e  vmovaps [rsp+0x60], xmm7
00007154327d7364  vmovaps [rsp+0x70], xmm8
00007154327d736a  vmovaps [rsp+0x80], xmm9
00007154327d7373  vmovaps [rsp+0x90], xmm10
00007154327d737c  vmovaps [rsp+0xA0], xmm11
00007154327d7385  vmovaps [rsp+0xB0], xmm12
00007154327d738e  vmovaps [rsp+0xC0], xmm13
00007154327d7397  vmovaps [rsp+0xD0], xmm14
00007154327d73a0  vmovaps [rsp+0xE0], xmm15
00007154327d73a9  sub rsp, 0x30
00007154327d73ad  movaps [rsp], xmm1
00007154327d73b1  movaps [rsp+0x10], xmm6
00007154327d73b6  movaps [rsp+0x20], xmm15
00007154327d73bc  lea rdi, [rsp]
00007154327d73c0  mov esi, 0x00
00007154327d73c5  mov rax, 0x5A63B06A5530
00007154327d73cf  call rax
00007154327d73d1  movaps xmm1, [rsp]
00007154327d73d5  add rsp, 0x30
00007154327d73d9  vmovaps xmm0, [rsp]
00007154327d73de  vmovaps xmm2, [rsp+0x10]
00007154327d73e4  vmovaps xmm3, [rsp+0x20]
00007154327d73ea  vmovaps xmm4, [rsp+0x30]
00007154327d73f0  vmovaps xmm5, [rsp+0x40]
00007154327d73f6  vmovaps xmm6, [rsp+0x50]
00007154327d73fc  vmovaps xmm7, [rsp+0x60]
00007154327d7402  vmovaps xmm8, [rsp+0x70]
00007154327d7408  vmovaps xmm9, [rsp+0x80]
00007154327d7411  vmovaps xmm10, [rsp+0x90]
00007154327d741a  vmovaps xmm11, [rsp+0xA0]
00007154327d7423  vmovaps xmm12, [rsp+0xB0]
00007154327d742c  vmovaps xmm13, [rsp+0xC0]
00007154327d7435  vmovaps xmm14, [rsp+0xD0]
00007154327d743e  vmovaps xmm15, [rsp+0xE0]
00007154327d7447  add rsp, 0xF0
00007154327d744e  pop r11
00007154327d7450  pop r10
00007154327d7452  pop r9
00007154327d7454  pop r8
00007154327d7456  pop rsi
00007154327d7457  pop rdi
00007154327d7458  pop rdx
00007154327d7459  pop rcx
00007154327d745a  pop rax
00007154327d745b  add rsp, 0x08
00007154327d745f  jmp 0x00007154327D5C68
00007154327d7464  call 0x00007154326E5820
00007154327d7469  jmp 0x00007154327D5C75
00007154327d746e  sub rsp, 0x08
00007154327d7472  push rax
00007154327d7473  push rcx
00007154327d7474  push rdx
00007154327d7475  push rdi
00007154327d7476  push rsi
00007154327d7477  push r8
00007154327d7479  push r9
00007154327d747b  push r10
00007154327d747d  push r11
00007154327d747f  sub rsp, 0xF0
00007154327d7486  vmovaps [rsp], xmm0
00007154327d748b  vmovaps [rsp+0x10], xmm1
00007154327d7491  vmovaps [rsp+0x20], xmm2
00007154327d7497  vmovaps [rsp+0x30], xmm3
00007154327d749d  vmovaps [rsp+0x40], xmm4
00007154327d74a3  vmovaps [rsp+0x50], xmm5
00007154327d74a9  vmovaps [rsp+0x60], xmm6
00007154327d74af  vmovaps [rsp+0x70], xmm7
00007154327d74b5  vmovaps [rsp+0x80], xmm8
00007154327d74be  vmovaps [rsp+0x90], xmm9
00007154327d74c7  vmovaps [rsp+0xA0], xmm10
00007154327d74d0  vmovaps [rsp+0xB0], xmm11
00007154327d74d9  vmovaps [rsp+0xC0], xmm12
00007154327d74e2  vmovaps [rsp+0xD0], xmm13
00007154327d74eb  vmovaps [rsp+0xE0], xmm15
00007154327d74f4  sub rsp, 0x30
00007154327d74f8  movaps [rsp], xmm14
00007154327d74fd  movaps [rsp+0x10], xmm4
00007154327d7502  movaps [rsp+0x20], xmm3
00007154327d7507  lea rdi, [rsp]
00007154327d750b  mov esi, 0x00
00007154327d7510  mov rax, 0x5A63B06A5530
00007154327d751a  call rax
00007154327d751c  movaps xmm14, [rsp]
00007154327d7521  add rsp, 0x30
00007154327d7525  vmovaps xmm0, [rsp]
00007154327d752a  vmovaps xmm1, [rsp+0x10]
00007154327d7530  vmovaps xmm2, [rsp+0x20]
00007154327d7536  vmovaps xmm3, [rsp+0x30]
00007154327d753c  vmovaps xmm4, [rsp+0x40]
00007154327d7542  vmovaps xmm5, [rsp+0x50]
00007154327d7548  vmovaps xmm6, [rsp+0x60]
00007154327d754e  vmovaps xmm7, [rsp+0x70]
00007154327d7554  vmovaps xmm8, [rsp+0x80]
00007154327d755d  vmovaps xmm9, [rsp+0x90]
00007154327d7566  vmovaps xmm10, [rsp+0xA0]
00007154327d756f  vmovaps xmm11, [rsp+0xB0]
00007154327d7578  vmovaps xmm12, [rsp+0xC0]
00007154327d7581  vmovaps xmm13, [rsp+0xD0]
00007154327d758a  vmovaps xmm15, [rsp+0xE0]
00007154327d7593  add rsp, 0xF0
00007154327d759a  pop r11
00007154327d759c  pop r10
00007154327d759e  pop r9
00007154327d75a0  pop r8
00007154327d75a2  pop rsi
00007154327d75a3  pop rdi
00007154327d75a4  pop rdx
00007154327d75a5  pop rcx
00007154327d75a6  pop rax
00007154327d75a7  add rsp, 0x08
00007154327d75ab  jmp 0x00007154327D5C8F
00007154327d75b0  sub rsp, 0x08
00007154327d75b4  push rax
00007154327d75b5  push rcx
00007154327d75b6  push rdx
00007154327d75b7  push rdi
00007154327d75b8  push rsi
00007154327d75b9  push r8
00007154327d75bb  push r9
00007154327d75bd  push r10
00007154327d75bf  push r11
00007154327d75c1  sub rsp, 0xF0
00007154327d75c8  vmovaps [rsp], xmm0
00007154327d75cd  vmovaps [rsp+0x10], xmm1
00007154327d75d3  vmovaps [rsp+0x20], xmm2
00007154327d75d9  vmovaps [rsp+0x30], xmm3
00007154327d75df  vmovaps [rsp+0x40], xmm4
00007154327d75e5  vmovaps [rsp+0x50], xmm5
00007154327d75eb  vmovaps [rsp+0x60], xmm7
00007154327d75f1  vmovaps [rsp+0x70], xmm8
00007154327d75f7  vmovaps [rsp+0x80], xmm9
00007154327d7600  vmovaps [rsp+0x90], xmm10
00007154327d7609  vmovaps [rsp+0xA0], xmm11
00007154327d7612  vmovaps [rsp+0xB0], xmm12
00007154327d761b  vmovaps [rsp+0xC0], xmm13
00007154327d7624  vmovaps [rsp+0xD0], xmm14
00007154327d762d  vmovaps [rsp+0xE0], xmm15
00007154327d7636  sub rsp, 0x30
00007154327d763a  movaps [rsp], xmm6
00007154327d763e  movaps [rsp+0x10], xmm9
00007154327d7644  movaps [rsp+0x20], xmm7
00007154327d7649  lea rdi, [rsp]
00007154327d764d  mov esi, 0x00
00007154327d7652  mov rax, 0x5A63B06A5530
00007154327d765c  call rax
00007154327d765e  movaps xmm6, [rsp]
00007154327d7662  add rsp, 0x30
00007154327d7666  vmovaps xmm0, [rsp]
00007154327d766b  vmovaps xmm1, [rsp+0x10]
00007154327d7671  vmovaps xmm2, [rsp+0x20]
00007154327d7677  vmovaps xmm3, [rsp+0x30]
00007154327d767d  vmovaps xmm4, [rsp+0x40]
00007154327d7683  vmovaps xmm5, [rsp+0x50]
00007154327d7689  vmovaps xmm7, [rsp+0x60]
00007154327d768f  vmovaps xmm8, [rsp+0x70]
00007154327d7695  vmovaps xmm9, [rsp+0x80]
00007154327d769e  vmovaps xmm10, [rsp+0x90]
00007154327d76a7  vmovaps xmm11, [rsp+0xA0]
00007154327d76b0  vmovaps xmm12, [rsp+0xB0]
00007154327d76b9  vmovaps xmm13, [rsp+0xC0]
00007154327d76c2  vmovaps xmm14, [rsp+0xD0]
00007154327d76cb  vmovaps xmm15, [rsp+0xE0]
00007154327d76d4  add rsp, 0xF0
00007154327d76db  pop r11
00007154327d76dd  pop r10
00007154327d76df  pop r9
00007154327d76e1  pop r8
00007154327d76e3  pop rsi
00007154327d76e4  pop rdi
00007154327d76e5  pop rdx
00007154327d76e6  pop rcx
00007154327d76e7  pop rax
00007154327d76e8  add rsp, 0x08
00007154327d76ec  jmp 0x00007154327D5CA7
00007154327d76f1  sub rsp, 0x08
00007154327d76f5  push rax
00007154327d76f6  push rcx
00007154327d76f7  push rdx
00007154327d76f8  push rdi
00007154327d76f9  push rsi
00007154327d76fa  push r8
00007154327d76fc  push r9
00007154327d76fe  push r10
00007154327d7700  push r11
00007154327d7702  sub rsp, 0xF0
00007154327d7709  vmovaps [rsp], xmm0
00007154327d770e  vmovaps [rsp+0x10], xmm1
00007154327d7714  vmovaps [rsp+0x20], xmm2
00007154327d771a  vmovaps [rsp+0x30], xmm3
00007154327d7720  vmovaps [rsp+0x40], xmm4
00007154327d7726  vmovaps [rsp+0x50], xmm5
00007154327d772c  vmovaps [rsp+0x60], xmm6
00007154327d7732  vmovaps [rsp+0x70], xmm8
00007154327d7738  vmovaps [rsp+0x80], xmm9
00007154327d7741  vmovaps [rsp+0x90], xmm10
00007154327d774a  vmovaps [rsp+0xA0], xmm11
00007154327d7753  vmovaps [rsp+0xB0], xmm12
00007154327d775c  vmovaps [rsp+0xC0], xmm13
00007154327d7765  vmovaps [rsp+0xD0], xmm14
00007154327d776e  vmovaps [rsp+0xE0], xmm15
00007154327d7777  sub rsp, 0x30
00007154327d777b  movaps [rsp], xmm7
00007154327d777f  movaps [rsp+0x10], xmm4
00007154327d7784  movaps [rsp+0x20], xmm9
00007154327d778a  lea rdi, [rsp]
00007154327d778e  mov esi, 0x00
00007154327d7793  mov rax, 0x5A63B06A5530
00007154327d779d  call rax
00007154327d779f  movaps xmm7, [rsp]
00007154327d77a3  add rsp, 0x30
00007154327d77a7  vmovaps xmm0, [rsp]
00007154327d77ac  vmovaps xmm1, [rsp+0x10]
00007154327d77b2  vmovaps xmm2, [rsp+0x20]
00007154327d77b8  vmovaps xmm3, [rsp+0x30]
00007154327d77be  vmovaps xmm4, [rsp+0x40]
00007154327d77c4  vmovaps xmm5, [rsp+0x50]
00007154327d77ca  vmovaps xmm6, [rsp+0x60]
00007154327d77d0  vmovaps xmm8, [rsp+0x70]
00007154327d77d6  vmovaps xmm9, [rsp+0x80]
00007154327d77df  vmovaps xmm10, [rsp+0x90]
00007154327d77e8  vmovaps xmm11, [rsp+0xA0]
00007154327d77f1  vmovaps xmm12, [rsp+0xB0]
00007154327d77fa  vmovaps xmm13, [rsp+0xC0]
00007154327d7803  vmovaps xmm14, [rsp+0xD0]
00007154327d780c  vmovaps xmm15, [rsp+0xE0]
00007154327d7815  add rsp, 0xF0
00007154327d781c  pop r11
00007154327d781e  pop r10
00007154327d7820  pop r9
00007154327d7822  pop r8
00007154327d7824  pop rsi
00007154327d7825  pop rdi
00007154327d7826  pop rdx
00007154327d7827  pop rcx
00007154327d7828  pop rax
00007154327d7829  add rsp, 0x08
00007154327d782d  jmp 0x00007154327D5CD4
00007154327d7832  sub rsp, 0x08
00007154327d7836  push rax
00007154327d7837  push rcx
00007154327d7838  push rdx
00007154327d7839  push rdi
00007154327d783a  push rsi
00007154327d783b  push r8
00007154327d783d  push r9
00007154327d783f  push r10
00007154327d7841  push r11
00007154327d7843  sub rsp, 0xF0
00007154327d784a  vmovaps [rsp], xmm0
00007154327d784f  vmovaps [rsp+0x10], xmm1
00007154327d7855  vmovaps [rsp+0x20], xmm2
00007154327d785b  vmovaps [rsp+0x30], xmm3
00007154327d7861  vmovaps [rsp+0x40], xmm5
00007154327d7867  vmovaps [rsp+0x50], xmm6
00007154327d786d  vmovaps [rsp+0x60], xmm7
00007154327d7873  vmovaps [rsp+0x70], xmm8
00007154327d7879  vmovaps [rsp+0x80], xmm9
00007154327d7882  vmovaps [rsp+0x90], xmm10
00007154327d788b  vmovaps [rsp+0xA0], xmm11
00007154327d7894  vmovaps [rsp+0xB0], xmm12
00007154327d789d  vmovaps [rsp+0xC0], xmm13
00007154327d78a6  vmovaps [rsp+0xD0], xmm14
00007154327d78af  vmovaps [rsp+0xE0], xmm15
00007154327d78b8  sub rsp, 0x30
00007154327d78bc  movaps [rsp], xmm4
00007154327d78c0  movaps [rsp+0x10], xmm15
00007154327d78c6  movaps [rsp+0x20], xmm9
00007154327d78cc  lea rdi, [rsp]
00007154327d78d0  mov esi, 0x00
00007154327d78d5  mov rax, 0x5A63B06A5530
00007154327d78df  call rax
00007154327d78e1  movaps xmm4, [rsp]
00007154327d78e5  add rsp, 0x30
00007154327d78e9  vmovaps xmm0, [rsp]
00007154327d78ee  vmovaps xmm1, [rsp+0x10]
00007154327d78f4  vmovaps xmm2, [rsp+0x20]
00007154327d78fa  vmovaps xmm3, [rsp+0x30]
00007154327d7900  vmovaps xmm5, [rsp+0x40]
00007154327d7906  vmovaps xmm6, [rsp+0x50]
00007154327d790c  vmovaps xmm7, [rsp+0x60]
00007154327d7912  vmovaps xmm8, [rsp+0x70]
00007154327d7918  vmovaps xmm9, [rsp+0x80]
00007154327d7921  vmovaps xmm10, [rsp+0x90]
00007154327d792a  vmovaps xmm11, [rsp+0xA0]
00007154327d7933  vmovaps xmm12, [rsp+0xB0]
00007154327d793c  vmovaps xmm13, [rsp+0xC0]
00007154327d7945  vmovaps xmm14, [rsp+0xD0]
00007154327d794e  vmovaps xmm15, [rsp+0xE0]
00007154327d7957  add rsp, 0xF0
00007154327d795e  pop r11
00007154327d7960  pop r10
00007154327d7962  pop r9
00007154327d7964  pop r8
00007154327d7966  pop rsi
00007154327d7967  pop rdi
00007154327d7968  pop rdx
00007154327d7969  pop rcx
00007154327d796a  pop rax
00007154327d796b  add rsp, 0x08
00007154327d796f  jmp 0x00007154327D5CF9
00007154327d7974  call 0x00007154326E5820
00007154327d7979  jmp 0x00007154327D5D06
00007154327d797e  sub rsp, 0x08
00007154327d7982  push rax
00007154327d7983  push rcx
00007154327d7984  push rdx
00007154327d7985  push rdi
00007154327d7986  push rsi
00007154327d7987  push r8
00007154327d7989  push r9
00007154327d798b  push r10
00007154327d798d  push r11
00007154327d798f  sub rsp, 0xF0
00007154327d7996  vmovaps [rsp], xmm0
00007154327d799b  vmovaps [rsp+0x10], xmm1
00007154327d79a1  vmovaps [rsp+0x20], xmm2
00007154327d79a7  vmovaps [rsp+0x30], xmm4
00007154327d79ad  vmovaps [rsp+0x40], xmm5
00007154327d79b3  vmovaps [rsp+0x50], xmm6
00007154327d79b9  vmovaps [rsp+0x60], xmm7
00007154327d79bf  vmovaps [rsp+0x70], xmm8
00007154327d79c5  vmovaps [rsp+0x80], xmm9
00007154327d79ce  vmovaps [rsp+0x90], xmm10
00007154327d79d7  vmovaps [rsp+0xA0], xmm11
00007154327d79e0  vmovaps [rsp+0xB0], xmm12
00007154327d79e9  vmovaps [rsp+0xC0], xmm13
00007154327d79f2  vmovaps [rsp+0xD0], xmm14
00007154327d79fb  vmovaps [rsp+0xE0], xmm15
00007154327d7a04  sub rsp, 0x30
00007154327d7a08  movaps [rsp], xmm3
00007154327d7a0c  movaps [rsp+0x10], xmm1
00007154327d7a11  movaps [rsp+0x20], xmm9
00007154327d7a17  lea rdi, [rsp]
00007154327d7a1b  mov esi, 0x00
00007154327d7a20  mov rax, 0x5A63B06A5530
00007154327d7a2a  call rax
00007154327d7a2c  movaps xmm3, [rsp]
00007154327d7a30  add rsp, 0x30
00007154327d7a34  vmovaps xmm0, [rsp]
00007154327d7a39  vmovaps xmm1, [rsp+0x10]
00007154327d7a3f  vmovaps xmm2, [rsp+0x20]
00007154327d7a45  vmovaps xmm4, [rsp+0x30]
00007154327d7a4b  vmovaps xmm5, [rsp+0x40]
00007154327d7a51  vmovaps xmm6, [rsp+0x50]
00007154327d7a57  vmovaps xmm7, [rsp+0x60]
00007154327d7a5d  vmovaps xmm8, [rsp+0x70]
00007154327d7a63  vmovaps xmm9, [rsp+0x80]
00007154327d7a6c  vmovaps xmm10, [rsp+0x90]
00007154327d7a75  vmovaps xmm11, [rsp+0xA0]
00007154327d7a7e  vmovaps xmm12, [rsp+0xB0]
00007154327d7a87  vmovaps xmm13, [rsp+0xC0]
00007154327d7a90  vmovaps xmm14, [rsp+0xD0]
00007154327d7a99  vmovaps xmm15, [rsp+0xE0]
00007154327d7aa2  add rsp, 0xF0
00007154327d7aa9  pop r11
00007154327d7aab  pop r10
00007154327d7aad  pop r9
00007154327d7aaf  pop r8
00007154327d7ab1  pop rsi
00007154327d7ab2  pop rdi
00007154327d7ab3  pop rdx
00007154327d7ab4  pop rcx
00007154327d7ab5  pop rax
00007154327d7ab6  add rsp, 0x08
00007154327d7aba  jmp 0x00007154327D5D43
00007154327d7abf  sub rsp, 0x08
00007154327d7ac3  push rax
00007154327d7ac4  push rcx
00007154327d7ac5  push rdx
00007154327d7ac6  push rdi
00007154327d7ac7  push rsi
00007154327d7ac8  push r8
00007154327d7aca  push r9
00007154327d7acc  push r10
00007154327d7ace  push r11
00007154327d7ad0  sub rsp, 0xF0
00007154327d7ad7  vmovaps [rsp], xmm0
00007154327d7adc  vmovaps [rsp+0x10], xmm2
00007154327d7ae2  vmovaps [rsp+0x20], xmm3
00007154327d7ae8  vmovaps [rsp+0x30], xmm4
00007154327d7aee  vmovaps [rsp+0x40], xmm5
00007154327d7af4  vmovaps [rsp+0x50], xmm6
00007154327d7afa  vmovaps [rsp+0x60], xmm7
00007154327d7b00  vmovaps [rsp+0x70], xmm8
00007154327d7b06  vmovaps [rsp+0x80], xmm9
00007154327d7b0f  vmovaps [rsp+0x90], xmm10
00007154327d7b18  vmovaps [rsp+0xA0], xmm11
00007154327d7b21  vmovaps [rsp+0xB0], xmm12
00007154327d7b2a  vmovaps [rsp+0xC0], xmm13
00007154327d7b33  vmovaps [rsp+0xD0], xmm14
00007154327d7b3c  vmovaps [rsp+0xE0], xmm15
00007154327d7b45  sub rsp, 0x30
00007154327d7b49  movaps [rsp], xmm1
00007154327d7b4d  movaps [rsp+0x10], xmm15
00007154327d7b53  movaps [rsp+0x20], xmm9
00007154327d7b59  lea rdi, [rsp]
00007154327d7b5d  mov esi, 0x00
00007154327d7b62  mov rax, 0x5A63B06A5530
00007154327d7b6c  call rax
00007154327d7b6e  movaps xmm1, [rsp]
00007154327d7b72  add rsp, 0x30
00007154327d7b76  vmovaps xmm0, [rsp]
00007154327d7b7b  vmovaps xmm2, [rsp+0x10]
00007154327d7b81  vmovaps xmm3, [rsp+0x20]
00007154327d7b87  vmovaps xmm4, [rsp+0x30]
00007154327d7b8d  vmovaps xmm5, [rsp+0x40]
00007154327d7b93  vmovaps xmm6, [rsp+0x50]
00007154327d7b99  vmovaps xmm7, [rsp+0x60]
00007154327d7b9f  vmovaps xmm8, [rsp+0x70]
00007154327d7ba5  vmovaps xmm9, [rsp+0x80]
00007154327d7bae  vmovaps xmm10, [rsp+0x90]
00007154327d7bb7  vmovaps xmm11, [rsp+0xA0]
00007154327d7bc0  vmovaps xmm12, [rsp+0xB0]
00007154327d7bc9  vmovaps xmm13, [rsp+0xC0]
00007154327d7bd2  vmovaps xmm14, [rsp+0xD0]
00007154327d7bdb  vmovaps xmm15, [rsp+0xE0]
00007154327d7be4  add rsp, 0xF0
00007154327d7beb  pop r11
00007154327d7bed  pop r10
00007154327d7bef  pop r9
00007154327d7bf1  pop r8
00007154327d7bf3  pop rsi
00007154327d7bf4  pop rdi
00007154327d7bf5  pop rdx
00007154327d7bf6  pop rcx
00007154327d7bf7  pop rax
00007154327d7bf8  add rsp, 0x08
00007154327d7bfc  jmp 0x00007154327D5DCB
00007154327d7c01  call 0x00007154326E5820
00007154327d7c06  jmp 0x00007154327D5DD8
00007154327d7c0b  sub rsp, 0x08
00007154327d7c0f  push rax
00007154327d7c10  push rcx
00007154327d7c11  push rdx
00007154327d7c12  push rdi
00007154327d7c13  push rsi
00007154327d7c14  push r8
00007154327d7c16  push r9
00007154327d7c18  push r10
00007154327d7c1a  push r11
00007154327d7c1c  sub rsp, 0xF0
00007154327d7c23  vmovaps [rsp], xmm0
00007154327d7c28  vmovaps [rsp+0x10], xmm2
00007154327d7c2e  vmovaps [rsp+0x20], xmm3
00007154327d7c34  vmovaps [rsp+0x30], xmm4
00007154327d7c3a  vmovaps [rsp+0x40], xmm5
00007154327d7c40  vmovaps [rsp+0x50], xmm6
00007154327d7c46  vmovaps [rsp+0x60], xmm7
00007154327d7c4c  vmovaps [rsp+0x70], xmm8
00007154327d7c52  vmovaps [rsp+0x80], xmm9
00007154327d7c5b  vmovaps [rsp+0x90], xmm10
00007154327d7c64  vmovaps [rsp+0xA0], xmm11
00007154327d7c6d  vmovaps [rsp+0xB0], xmm12
00007154327d7c76  vmovaps [rsp+0xC0], xmm13
00007154327d7c7f  vmovaps [rsp+0xD0], xmm14
00007154327d7c88  vmovaps [rsp+0xE0], xmm15
00007154327d7c91  sub rsp, 0x30
00007154327d7c95  movaps [rsp], xmm1
00007154327d7c99  movaps [rsp+0x10], xmm5
00007154327d7c9e  movaps [rsp+0x20], xmm7
00007154327d7ca3  lea rdi, [rsp]
00007154327d7ca7  mov esi, 0x00
00007154327d7cac  mov rax, 0x5A63B06A5530
00007154327d7cb6  call rax
00007154327d7cb8  movaps xmm1, [rsp]
00007154327d7cbc  add rsp, 0x30
00007154327d7cc0  vmovaps xmm0, [rsp]
00007154327d7cc5  vmovaps xmm2, [rsp+0x10]
00007154327d7ccb  vmovaps xmm3, [rsp+0x20]
00007154327d7cd1  vmovaps xmm4, [rsp+0x30]
00007154327d7cd7  vmovaps xmm5, [rsp+0x40]
00007154327d7cdd  vmovaps xmm6, [rsp+0x50]
00007154327d7ce3  vmovaps xmm7, [rsp+0x60]
00007154327d7ce9  vmovaps xmm8, [rsp+0x70]
00007154327d7cef  vmovaps xmm9, [rsp+0x80]
00007154327d7cf8  vmovaps xmm10, [rsp+0x90]
00007154327d7d01  vmovaps xmm11, [rsp+0xA0]
00007154327d7d0a  vmovaps xmm12, [rsp+0xB0]
00007154327d7d13  vmovaps xmm13, [rsp+0xC0]
00007154327d7d1c  vmovaps xmm14, [rsp+0xD0]
00007154327d7d25  vmovaps xmm15, [rsp+0xE0]
00007154327d7d2e  add rsp, 0xF0
00007154327d7d35  pop r11
00007154327d7d37  pop r10
00007154327d7d39  pop r9
00007154327d7d3b  pop r8
00007154327d7d3d  pop rsi
00007154327d7d3e  pop rdi
00007154327d7d3f  pop rdx
00007154327d7d40  pop rcx
00007154327d7d41  pop rax
00007154327d7d42  add rsp, 0x08
00007154327d7d46  jmp 0x00007154327D5E7D
00007154327d7d4b  sub rsp, 0x08
00007154327d7d4f  push rax
00007154327d7d50  push rcx
00007154327d7d51  push rdx
00007154327d7d52  push rdi
00007154327d7d53  push rsi
00007154327d7d54  push r8
00007154327d7d56  push r9
00007154327d7d58  push r10
00007154327d7d5a  push r11
00007154327d7d5c  sub rsp, 0xF0
00007154327d7d63  vmovaps [rsp], xmm0
00007154327d7d68  vmovaps [rsp+0x10], xmm1
00007154327d7d6e  vmovaps [rsp+0x20], xmm2
00007154327d7d74  vmovaps [rsp+0x30], xmm3
00007154327d7d7a  vmovaps [rsp+0x40], xmm4
00007154327d7d80  vmovaps [rsp+0x50], xmm5
00007154327d7d86  vmovaps [rsp+0x60], xmm6
00007154327d7d8c  vmovaps [rsp+0x70], xmm8
00007154327d7d92  vmovaps [rsp+0x80], xmm9
00007154327d7d9b  vmovaps [rsp+0x90], xmm10
00007154327d7da4  vmovaps [rsp+0xA0], xmm11
00007154327d7dad  vmovaps [rsp+0xB0], xmm12
00007154327d7db6  vmovaps [rsp+0xC0], xmm13
00007154327d7dbf  vmovaps [rsp+0xD0], xmm14
00007154327d7dc8  vmovaps [rsp+0xE0], xmm15
00007154327d7dd1  sub rsp, 0x30
00007154327d7dd5  movaps [rsp], xmm7
00007154327d7dd9  movaps [rsp+0x10], xmm5
00007154327d7dde  movaps [rsp+0x20], xmm15
00007154327d7de4  lea rdi, [rsp]
00007154327d7de8  mov esi, 0x00
00007154327d7ded  mov rax, 0x5A63B06A5530
00007154327d7df7  call rax
00007154327d7df9  movaps xmm7, [rsp]
00007154327d7dfd  add rsp, 0x30
00007154327d7e01  vmovaps xmm0, [rsp]
00007154327d7e06  vmovaps xmm1, [rsp+0x10]
00007154327d7e0c  vmovaps xmm2, [rsp+0x20]
00007154327d7e12  vmovaps xmm3, [rsp+0x30]
00007154327d7e18  vmovaps xmm4, [rsp+0x40]
00007154327d7e1e  vmovaps xmm5, [rsp+0x50]
00007154327d7e24  vmovaps xmm6, [rsp+0x60]
00007154327d7e2a  vmovaps xmm8, [rsp+0x70]
00007154327d7e30  vmovaps xmm9, [rsp+0x80]
00007154327d7e39  vmovaps xmm10, [rsp+0x90]
00007154327d7e42  vmovaps xmm11, [rsp+0xA0]
00007154327d7e4b  vmovaps xmm12, [rsp+0xB0]
00007154327d7e54  vmovaps xmm13, [rsp+0xC0]
00007154327d7e5d  vmovaps xmm14, [rsp+0xD0]
00007154327d7e66  vmovaps xmm15, [rsp+0xE0]
00007154327d7e6f  add rsp, 0xF0
00007154327d7e76  pop r11
00007154327d7e78  pop r10
00007154327d7e7a  pop r9
00007154327d7e7c  pop r8
00007154327d7e7e  pop rsi
00007154327d7e7f  pop rdi
00007154327d7e80  pop rdx
00007154327d7e81  pop rcx
00007154327d7e82  pop rax
00007154327d7e83  add rsp, 0x08
00007154327d7e87  jmp 0x00007154327D5EB3
00007154327d7e8c  call 0x00007154326D64F0
00007154327d7e91  jmp 0x00007154327D5EC0
00007154327d7e96  sub rsp, 0x08
00007154327d7e9a  push rax
00007154327d7e9b  push rcx
00007154327d7e9c  push rdx
00007154327d7e9d  push rdi
00007154327d7e9e  push rsi
00007154327d7e9f  push r8
00007154327d7ea1  push r9
00007154327d7ea3  push r10
00007154327d7ea5  push r11
00007154327d7ea7  sub rsp, 0xF0
00007154327d7eae  vmovaps [rsp], xmm0
00007154327d7eb3  vmovaps [rsp+0x10], xmm1
00007154327d7eb9  vmovaps [rsp+0x20], xmm2
00007154327d7ebf  vmovaps [rsp+0x30], xmm3
00007154327d7ec5  vmovaps [rsp+0x40], xmm4
00007154327d7ecb  vmovaps [rsp+0x50], xmm5
00007154327d7ed1  vmovaps [rsp+0x60], xmm6
00007154327d7ed7  vmovaps [rsp+0x70], xmm7
00007154327d7edd  vmovaps [rsp+0x80], xmm8
00007154327d7ee6  vmovaps [rsp+0x90], xmm9
00007154327d7eef  vmovaps [rsp+0xA0], xmm10
00007154327d7ef8  vmovaps [rsp+0xB0], xmm11
00007154327d7f01  vmovaps [rsp+0xC0], xmm12
00007154327d7f0a  vmovaps [rsp+0xD0], xmm13
00007154327d7f13  vmovaps [rsp+0xE0], xmm14
00007154327d7f1c  sub rsp, 0x30
00007154327d7f20  movaps [rsp], xmm15
00007154327d7f25  movaps [rsp+0x10], xmm5
00007154327d7f2a  movaps [rsp+0x20], xmm3
00007154327d7f2f  lea rdi, [rsp]
00007154327d7f33  mov esi, 0x00
00007154327d7f38  mov rax, 0x5A63B06A5530
00007154327d7f42  call rax
00007154327d7f44  movaps xmm15, [rsp]
00007154327d7f49  add rsp, 0x30
00007154327d7f4d  vmovaps xmm0, [rsp]
00007154327d7f52  vmovaps xmm1, [rsp+0x10]
00007154327d7f58  vmovaps xmm2, [rsp+0x20]
00007154327d7f5e  vmovaps xmm3, [rsp+0x30]
00007154327d7f64  vmovaps xmm4, [rsp+0x40]
00007154327d7f6a  vmovaps xmm5, [rsp+0x50]
00007154327d7f70  vmovaps xmm6, [rsp+0x60]
00007154327d7f76  vmovaps xmm7, [rsp+0x70]
00007154327d7f7c  vmovaps xmm8, [rsp+0x80]
00007154327d7f85  vmovaps xmm9, [rsp+0x90]
00007154327d7f8e  vmovaps xmm10, [rsp+0xA0]
00007154327d7f97  vmovaps xmm11, [rsp+0xB0]
00007154327d7fa0  vmovaps xmm12, [rsp+0xC0]
00007154327d7fa9  vmovaps xmm13, [rsp+0xD0]
00007154327d7fb2  vmovaps xmm14, [rsp+0xE0]
00007154327d7fbb  add rsp, 0xF0
00007154327d7fc2  pop r11
00007154327d7fc4  pop r10
00007154327d7fc6  pop r9
00007154327d7fc8  pop r8
00007154327d7fca  pop rsi
00007154327d7fcb  pop rdi
00007154327d7fcc  pop rdx
00007154327d7fcd  pop rcx
00007154327d7fce  pop rax
00007154327d7fcf  add rsp, 0x08
00007154327d7fd3  jmp 0x00007154327D5EE6
00007154327d7fd8  sub rsp, 0x08
00007154327d7fdc  push rax
00007154327d7fdd  push rcx
00007154327d7fde  push rdx
00007154327d7fdf  push rdi
00007154327d7fe0  push rsi
00007154327d7fe1  push r8
00007154327d7fe3  push r9
00007154327d7fe5  push r10
00007154327d7fe7  push r11
00007154327d7fe9  sub rsp, 0xF0
00007154327d7ff0  vmovaps [rsp], xmm0
00007154327d7ff5  vmovaps [rsp+0x10], xmm2
00007154327d7ffb  vmovaps [rsp+0x20], xmm3
00007154327d8001  vmovaps [rsp+0x30], xmm4
00007154327d8007  vmovaps [rsp+0x40], xmm5
00007154327d800d  vmovaps [rsp+0x50], xmm6
00007154327d8013  vmovaps [rsp+0x60], xmm7
00007154327d8019  vmovaps [rsp+0x70], xmm8
00007154327d801f  vmovaps [rsp+0x80], xmm9
00007154327d8028  vmovaps [rsp+0x90], xmm10
00007154327d8031  vmovaps [rsp+0xA0], xmm11
00007154327d803a  vmovaps [rsp+0xB0], xmm12
00007154327d8043  vmovaps [rsp+0xC0], xmm13
00007154327d804c  vmovaps [rsp+0xD0], xmm14
00007154327d8055  vmovaps [rsp+0xE0], xmm15
00007154327d805e  sub rsp, 0x30
00007154327d8062  movaps [rsp], xmm1
00007154327d8066  movaps [rsp+0x10], xmm5
00007154327d806b  movaps [rsp+0x20], xmm4
00007154327d8070  lea rdi, [rsp]
00007154327d8074  mov esi, 0x00
00007154327d8079  mov rax, 0x5A63B06A5530
00007154327d8083  call rax
00007154327d8085  movaps xmm1, [rsp]
00007154327d8089  add rsp, 0x30
00007154327d808d  vmovaps xmm0, [rsp]
00007154327d8092  vmovaps xmm2, [rsp+0x10]
00007154327d8098  vmovaps xmm3, [rsp+0x20]
00007154327d809e  vmovaps xmm4, [rsp+0x30]
00007154327d80a4  vmovaps xmm5, [rsp+0x40]
00007154327d80aa  vmovaps xmm6, [rsp+0x50]
00007154327d80b0  vmovaps xmm7, [rsp+0x60]
00007154327d80b6  vmovaps xmm8, [rsp+0x70]
00007154327d80bc  vmovaps xmm9, [rsp+0x80]
00007154327d80c5  vmovaps xmm10, [rsp+0x90]
00007154327d80ce  vmovaps xmm11, [rsp+0xA0]
00007154327d80d7  vmovaps xmm12, [rsp+0xB0]
00007154327d80e0  vmovaps xmm13, [rsp+0xC0]
00007154327d80e9  vmovaps xmm14, [rsp+0xD0]
00007154327d80f2  vmovaps xmm15, [rsp+0xE0]
00007154327d80fb  add rsp, 0xF0
00007154327d8102  pop r11
00007154327d8104  pop r10
00007154327d8106  pop r9
00007154327d8108  pop r8
00007154327d810a  pop rsi
00007154327d810b  pop rdi
00007154327d810c  pop rdx
00007154327d810d  pop rcx
00007154327d810e  pop rax
00007154327d810f  add rsp, 0x08
00007154327d8113  jmp 0x00007154327D5F06
00007154327d8118  sub rsp, 0x08
00007154327d811c  push rax
00007154327d811d  push rcx
00007154327d811e  push rdx
00007154327d811f  push rdi
00007154327d8120  push rsi
00007154327d8121  push r8
00007154327d8123  push r9
00007154327d8125  push r10
00007154327d8127  push r11
00007154327d8129  sub rsp, 0xF0
00007154327d8130  vmovaps [rsp], xmm0
00007154327d8135  vmovaps [rsp+0x10], xmm1
00007154327d813b  vmovaps [rsp+0x20], xmm2
00007154327d8141  vmovaps [rsp+0x30], xmm3
00007154327d8147  vmovaps [rsp+0x40], xmm5
00007154327d814d  vmovaps [rsp+0x50], xmm6
00007154327d8153  vmovaps [rsp+0x60], xmm7
00007154327d8159  vmovaps [rsp+0x70], xmm8
00007154327d815f  vmovaps [rsp+0x80], xmm9
00007154327d8168  vmovaps [rsp+0x90], xmm10
00007154327d8171  vmovaps [rsp+0xA0], xmm11
00007154327d817a  vmovaps [rsp+0xB0], xmm12
00007154327d8183  vmovaps [rsp+0xC0], xmm13
00007154327d818c  vmovaps [rsp+0xD0], xmm14
00007154327d8195  vmovaps [rsp+0xE0], xmm15
00007154327d819e  sub rsp, 0x30
00007154327d81a2  movaps [rsp], xmm4
00007154327d81a6  movaps [rsp+0x10], xmm3
00007154327d81ab  movaps [rsp+0x20], xmm5
00007154327d81b0  lea rdi, [rsp]
00007154327d81b4  mov esi, 0x00
00007154327d81b9  mov rax, 0x5A63B06A5530
00007154327d81c3  call rax
00007154327d81c5  movaps xmm4, [rsp]
00007154327d81c9  add rsp, 0x30
00007154327d81cd  vmovaps xmm0, [rsp]
00007154327d81d2  vmovaps xmm1, [rsp+0x10]
00007154327d81d8  vmovaps xmm2, [rsp+0x20]
00007154327d81de  vmovaps xmm3, [rsp+0x30]
00007154327d81e4  vmovaps xmm5, [rsp+0x40]
00007154327d81ea  vmovaps xmm6, [rsp+0x50]
00007154327d81f0  vmovaps xmm7, [rsp+0x60]
00007154327d81f6  vmovaps xmm8, [rsp+0x70]
00007154327d81fc  vmovaps xmm9, [rsp+0x80]
00007154327d8205  vmovaps xmm10, [rsp+0x90]
00007154327d820e  vmovaps xmm11, [rsp+0xA0]
00007154327d8217  vmovaps xmm12, [rsp+0xB0]
00007154327d8220  vmovaps xmm13, [rsp+0xC0]
00007154327d8229  vmovaps xmm14, [rsp+0xD0]
00007154327d8232  vmovaps xmm15, [rsp+0xE0]
00007154327d823b  add rsp, 0xF0
00007154327d8242  pop r11
00007154327d8244  pop r10
00007154327d8246  pop r9
00007154327d8248  pop r8
00007154327d824a  pop rsi
00007154327d824b  pop rdi
00007154327d824c  pop rdx
00007154327d824d  pop rcx
00007154327d824e  pop rax
00007154327d824f  add rsp, 0x08
00007154327d8253  jmp 0x00007154327D5F54
00007154327d8258  call 0x00007154326D64F0
00007154327d825d  jmp 0x00007154327D5F61
00007154327d8262  sub rsp, 0x08
00007154327d8266  push rax
00007154327d8267  push rcx
00007154327d8268  push rdx
00007154327d8269  push rdi
00007154327d826a  push rsi
00007154327d826b  push r8
00007154327d826d  push r9
00007154327d826f  push r10
00007154327d8271  push r11
00007154327d8273  sub rsp, 0xF0
00007154327d827a  vmovaps [rsp], xmm0
00007154327d827f  vmovaps [rsp+0x10], xmm1
00007154327d8285  vmovaps [rsp+0x20], xmm2
00007154327d828b  vmovaps [rsp+0x30], xmm3
00007154327d8291  vmovaps [rsp+0x40], xmm4
00007154327d8297  vmovaps [rsp+0x50], xmm6
00007154327d829d  vmovaps [rsp+0x60], xmm7
00007154327d82a3  vmovaps [rsp+0x70], xmm8
00007154327d82a9  vmovaps [rsp+0x80], xmm9
00007154327d82b2  vmovaps [rsp+0x90], xmm10
00007154327d82bb  vmovaps [rsp+0xA0], xmm11
00007154327d82c4  vmovaps [rsp+0xB0], xmm12
00007154327d82cd  vmovaps [rsp+0xC0], xmm13
00007154327d82d6  vmovaps [rsp+0xD0], xmm14
00007154327d82df  vmovaps [rsp+0xE0], xmm15
00007154327d82e8  sub rsp, 0x30
00007154327d82ec  movaps [rsp], xmm5
00007154327d82f0  movaps [rsp+0x10], xmm6
00007154327d82f5  movaps [rsp+0x20], xmm3
00007154327d82fa  lea rdi, [rsp]
00007154327d82fe  mov esi, 0x00
00007154327d8303  mov rax, 0x5A63B06A5530
00007154327d830d  call rax
00007154327d830f  movaps xmm5, [rsp]
00007154327d8313  add rsp, 0x30
00007154327d8317  vmovaps xmm0, [rsp]
00007154327d831c  vmovaps xmm1, [rsp+0x10]
00007154327d8322  vmovaps xmm2, [rsp+0x20]
00007154327d8328  vmovaps xmm3, [rsp+0x30]
00007154327d832e  vmovaps xmm4, [rsp+0x40]
00007154327d8334  vmovaps xmm6, [rsp+0x50]
00007154327d833a  vmovaps xmm7, [rsp+0x60]
00007154327d8340  vmovaps xmm8, [rsp+0x70]
00007154327d8346  vmovaps xmm9, [rsp+0x80]
00007154327d834f  vmovaps xmm10, [rsp+0x90]
00007154327d8358  vmovaps xmm11, [rsp+0xA0]
00007154327d8361  vmovaps xmm12, [rsp+0xB0]
00007154327d836a  vmovaps xmm13, [rsp+0xC0]
00007154327d8373  vmovaps xmm14, [rsp+0xD0]
00007154327d837c  vmovaps xmm15, [rsp+0xE0]
00007154327d8385  add rsp, 0xF0
00007154327d838c  pop r11
00007154327d838e  pop r10
00007154327d8390  pop r9
00007154327d8392  pop r8
00007154327d8394  pop rsi
00007154327d8395  pop rdi
00007154327d8396  pop rdx
00007154327d8397  pop rcx
00007154327d8398  pop rax
00007154327d8399  add rsp, 0x08
00007154327d839d  jmp 0x00007154327D5F87
00007154327d83a2  sub rsp, 0x08
00007154327d83a6  push rax
00007154327d83a7  push rcx
00007154327d83a8  push rdx
00007154327d83a9  push rdi
00007154327d83aa  push rsi
00007154327d83ab  push r8
00007154327d83ad  push r9
00007154327d83af  push r10
00007154327d83b1  push r11
00007154327d83b3  sub rsp, 0xF0
00007154327d83ba  vmovaps [rsp], xmm0
00007154327d83bf  vmovaps [rsp+0x10], xmm1
00007154327d83c5  vmovaps [rsp+0x20], xmm2
00007154327d83cb  vmovaps [rsp+0x30], xmm3
00007154327d83d1  vmovaps [rsp+0x40], xmm4
00007154327d83d7  vmovaps [rsp+0x50], xmm5
00007154327d83dd  vmovaps [rsp+0x60], xmm7
00007154327d83e3  vmovaps [rsp+0x70], xmm8
00007154327d83e9  vmovaps [rsp+0x80], xmm9
00007154327d83f2  vmovaps [rsp+0x90], xmm10
00007154327d83fb  vmovaps [rsp+0xA0], xmm11
00007154327d8404  vmovaps [rsp+0xB0], xmm12
00007154327d840d  vmovaps [rsp+0xC0], xmm13
00007154327d8416  vmovaps [rsp+0xD0], xmm14
00007154327d841f  vmovaps [rsp+0xE0], xmm15
00007154327d8428  sub rsp, 0x30
00007154327d842c  movaps [rsp], xmm6
00007154327d8430  movaps [rsp+0x10], xmm9
00007154327d8436  movaps [rsp+0x20], xmm1
00007154327d843b  lea rdi, [rsp]
00007154327d843f  mov esi, 0x00
00007154327d8444  mov rax, 0x5A63B06A5530
00007154327d844e  call rax
00007154327d8450  movaps xmm6, [rsp]
00007154327d8454  add rsp, 0x30
00007154327d8458  vmovaps xmm0, [rsp]
00007154327d845d  vmovaps xmm1, [rsp+0x10]
00007154327d8463  vmovaps xmm2, [rsp+0x20]
00007154327d8469  vmovaps xmm3, [rsp+0x30]
00007154327d846f  vmovaps xmm4, [rsp+0x40]
00007154327d8475  vmovaps xmm5, [rsp+0x50]
00007154327d847b  vmovaps xmm7, [rsp+0x60]
00007154327d8481  vmovaps xmm8, [rsp+0x70]
00007154327d8487  vmovaps xmm9, [rsp+0x80]
00007154327d8490  vmovaps xmm10, [rsp+0x90]
00007154327d8499  vmovaps xmm11, [rsp+0xA0]
00007154327d84a2  vmovaps xmm12, [rsp+0xB0]
00007154327d84ab  vmovaps xmm13, [rsp+0xC0]
00007154327d84b4  vmovaps xmm14, [rsp+0xD0]
00007154327d84bd  vmovaps xmm15, [rsp+0xE0]
00007154327d84c6  add rsp, 0xF0
00007154327d84cd  pop r11
00007154327d84cf  pop r10
00007154327d84d1  pop r9
00007154327d84d3  pop r8
00007154327d84d5  pop rsi
00007154327d84d6  pop rdi
00007154327d84d7  pop rdx
00007154327d84d8  pop rcx
00007154327d84d9  pop rax
00007154327d84da  add rsp, 0x08
00007154327d84de  jmp 0x00007154327D5FAB
00007154327d84e3  sub rsp, 0x08
00007154327d84e7  push rax
00007154327d84e8  push rcx
00007154327d84e9  push rdx
00007154327d84ea  push rdi
00007154327d84eb  push rsi
00007154327d84ec  push r8
00007154327d84ee  push r9
00007154327d84f0  push r10
00007154327d84f2  push r11
00007154327d84f4  sub rsp, 0xF0
00007154327d84fb  vmovaps [rsp], xmm0
00007154327d8500  vmovaps [rsp+0x10], xmm1
00007154327d8506  vmovaps [rsp+0x20], xmm2
00007154327d850c  vmovaps [rsp+0x30], xmm3
00007154327d8512  vmovaps [rsp+0x40], xmm4
00007154327d8518  vmovaps [rsp+0x50], xmm5
00007154327d851e  vmovaps [rsp+0x60], xmm6
00007154327d8524  vmovaps [rsp+0x70], xmm7
00007154327d852a  vmovaps [rsp+0x80], xmm8
00007154327d8533  vmovaps [rsp+0x90], xmm10
00007154327d853c  vmovaps [rsp+0xA0], xmm11
00007154327d8545  vmovaps [rsp+0xB0], xmm12
00007154327d854e  vmovaps [rsp+0xC0], xmm13
00007154327d8557  vmovaps [rsp+0xD0], xmm14
00007154327d8560  vmovaps [rsp+0xE0], xmm15
00007154327d8569  sub rsp, 0x30
00007154327d856d  movaps [rsp], xmm9
00007154327d8572  movaps [rsp+0x10], xmm3
00007154327d8577  movaps [rsp+0x20], xmm1
00007154327d857c  lea rdi, [rsp]
00007154327d8580  mov esi, 0x00
00007154327d8585  mov rax, 0x5A63B06A5530
00007154327d858f  call rax
00007154327d8591  movaps xmm9, [rsp]
00007154327d8596  add rsp, 0x30
00007154327d859a  vmovaps xmm0, [rsp]
00007154327d859f  vmovaps xmm1, [rsp+0x10]
00007154327d85a5  vmovaps xmm2, [rsp+0x20]
00007154327d85ab  vmovaps xmm3, [rsp+0x30]
00007154327d85b1  vmovaps xmm4, [rsp+0x40]
00007154327d85b7  vmovaps xmm5, [rsp+0x50]
00007154327d85bd  vmovaps xmm6, [rsp+0x60]
00007154327d85c3  vmovaps xmm7, [rsp+0x70]
00007154327d85c9  vmovaps xmm8, [rsp+0x80]
00007154327d85d2  vmovaps xmm10, [rsp+0x90]
00007154327d85db  vmovaps xmm11, [rsp+0xA0]
00007154327d85e4  vmovaps xmm12, [rsp+0xB0]
00007154327d85ed  vmovaps xmm13, [rsp+0xC0]
00007154327d85f6  vmovaps xmm14, [rsp+0xD0]
00007154327d85ff  vmovaps xmm15, [rsp+0xE0]
00007154327d8608  add rsp, 0xF0
00007154327d860f  pop r11
00007154327d8611  pop r10
00007154327d8613  pop r9
00007154327d8615  pop r8
00007154327d8617  pop rsi
00007154327d8618  pop rdi
00007154327d8619  pop rdx
00007154327d861a  pop rcx
00007154327d861b  pop rax
00007154327d861c  add rsp, 0x08
00007154327d8620  jmp 0x00007154327D5FF7
00007154327d8625  call 0x00007154326D64F0
00007154327d862a  jmp 0x00007154327D6004
00007154327d862f  sub rsp, 0x08
00007154327d8633  push rax
00007154327d8634  push rcx
00007154327d8635  push rdx
00007154327d8636  push rdi
00007154327d8637  push rsi
00007154327d8638  push r8
00007154327d863a  push r9
00007154327d863c  push r10
00007154327d863e  push r11
00007154327d8640  sub rsp, 0xF0
00007154327d8647  vmovaps [rsp], xmm0
00007154327d864c  vmovaps [rsp+0x10], xmm1
00007154327d8652  vmovaps [rsp+0x20], xmm2
00007154327d8658  vmovaps [rsp+0x30], xmm3
00007154327d865e  vmovaps [rsp+0x40], xmm4
00007154327d8664  vmovaps [rsp+0x50], xmm5
00007154327d866a  vmovaps [rsp+0x60], xmm6
00007154327d8670  vmovaps [rsp+0x70], xmm7
00007154327d8676  vmovaps [rsp+0x80], xmm8
00007154327d867f  vmovaps [rsp+0x90], xmm9
00007154327d8688  vmovaps [rsp+0xA0], xmm10
00007154327d8691  vmovaps [rsp+0xB0], xmm11
00007154327d869a  vmovaps [rsp+0xC0], xmm12
00007154327d86a3  vmovaps [rsp+0xD0], xmm13
00007154327d86ac  vmovaps [rsp+0xE0], xmm14
00007154327d86b5  sub rsp, 0x30
00007154327d86b9  movaps [rsp], xmm15
00007154327d86be  movaps [rsp+0x10], xmm3
00007154327d86c3  movaps [rsp+0x20], xmm7
00007154327d86c8  lea rdi, [rsp]
00007154327d86cc  mov esi, 0x00
00007154327d86d1  mov rax, 0x5A63B06A5530
00007154327d86db  call rax
00007154327d86dd  movaps xmm15, [rsp]
00007154327d86e2  add rsp, 0x30
00007154327d86e6  vmovaps xmm0, [rsp]
00007154327d86eb  vmovaps xmm1, [rsp+0x10]
00007154327d86f1  vmovaps xmm2, [rsp+0x20]
00007154327d86f7  vmovaps xmm3, [rsp+0x30]
00007154327d86fd  vmovaps xmm4, [rsp+0x40]
00007154327d8703  vmovaps xmm5, [rsp+0x50]
00007154327d8709  vmovaps xmm6, [rsp+0x60]
00007154327d870f  vmovaps xmm7, [rsp+0x70]
00007154327d8715  vmovaps xmm8, [rsp+0x80]
00007154327d871e  vmovaps xmm9, [rsp+0x90]
00007154327d8727  vmovaps xmm10, [rsp+0xA0]
00007154327d8730  vmovaps xmm11, [rsp+0xB0]
00007154327d8739  vmovaps xmm12, [rsp+0xC0]
00007154327d8742  vmovaps xmm13, [rsp+0xD0]
00007154327d874b  vmovaps xmm14, [rsp+0xE0]
00007154327d8754  add rsp, 0xF0
00007154327d875b  pop r11
00007154327d875d  pop r10
00007154327d875f  pop r9
00007154327d8761  pop r8
00007154327d8763  pop rsi
00007154327d8764  pop rdi
00007154327d8765  pop rdx
00007154327d8766  pop rcx
00007154327d8767  pop rax
00007154327d8768  add rsp, 0x08
00007154327d876c  jmp 0x00007154327D6030
00007154327d8771  sub rsp, 0x08
00007154327d8775  push rax
00007154327d8776  push rcx
00007154327d8777  push rdx
00007154327d8778  push rdi
00007154327d8779  push rsi
00007154327d877a  push r8
00007154327d877c  push r9
00007154327d877e  push r10
00007154327d8780  push r11
00007154327d8782  sub rsp, 0xF0
00007154327d8789  vmovaps [rsp], xmm0
00007154327d878e  vmovaps [rsp+0x10], xmm1
00007154327d8794  vmovaps [rsp+0x20], xmm2
00007154327d879a  vmovaps [rsp+0x30], xmm4
00007154327d87a0  vmovaps [rsp+0x40], xmm5
00007154327d87a6  vmovaps [rsp+0x50], xmm6
00007154327d87ac  vmovaps [rsp+0x60], xmm7
00007154327d87b2  vmovaps [rsp+0x70], xmm8
00007154327d87b8  vmovaps [rsp+0x80], xmm9
00007154327d87c1  vmovaps [rsp+0x90], xmm10
00007154327d87ca  vmovaps [rsp+0xA0], xmm11
00007154327d87d3  vmovaps [rsp+0xB0], xmm12
00007154327d87dc  vmovaps [rsp+0xC0], xmm13
00007154327d87e5  vmovaps [rsp+0xD0], xmm14
00007154327d87ee  vmovaps [rsp+0xE0], xmm15
00007154327d87f7  sub rsp, 0x30
00007154327d87fb  movaps [rsp], xmm3
00007154327d87ff  movaps [rsp+0x10], xmm1
00007154327d8804  movaps [rsp+0x20], xmm15
00007154327d880a  lea rdi, [rsp]
00007154327d880e  mov esi, 0x00
00007154327d8813  mov rax, 0x5A63B06A5530
00007154327d881d  call rax
00007154327d881f  movaps xmm3, [rsp]
00007154327d8823  add rsp, 0x30
00007154327d8827  vmovaps xmm0, [rsp]
00007154327d882c  vmovaps xmm1, [rsp+0x10]
00007154327d8832  vmovaps xmm2, [rsp+0x20]
00007154327d8838  vmovaps xmm4, [rsp+0x30]
00007154327d883e  vmovaps xmm5, [rsp+0x40]
00007154327d8844  vmovaps xmm6, [rsp+0x50]
00007154327d884a  vmovaps xmm7, [rsp+0x60]
00007154327d8850  vmovaps xmm8, [rsp+0x70]
00007154327d8856  vmovaps xmm9, [rsp+0x80]
00007154327d885f  vmovaps xmm10, [rsp+0x90]
00007154327d8868  vmovaps xmm11, [rsp+0xA0]
00007154327d8871  vmovaps xmm12, [rsp+0xB0]
00007154327d887a  vmovaps xmm13, [rsp+0xC0]
00007154327d8883  vmovaps xmm14, [rsp+0xD0]
00007154327d888c  vmovaps xmm15, [rsp+0xE0]
00007154327d8895  add rsp, 0xF0
00007154327d889c  pop r11
00007154327d889e  pop r10
00007154327d88a0  pop r9
00007154327d88a2  pop r8
00007154327d88a4  pop rsi
00007154327d88a5  pop rdi
00007154327d88a6  pop rdx
00007154327d88a7  pop rcx
00007154327d88a8  pop rax
00007154327d88a9  add rsp, 0x08
00007154327d88ad  jmp 0x00007154327D60BF
00007154327d88b2  call 0x00007154326D64F0
00007154327d88b7  jmp 0x00007154327D60C9
00007154327d88bc  sub rsp, 0x08
00007154327d88c0  push rax
00007154327d88c1  push rcx
00007154327d88c2  push rdx
00007154327d88c3  push rdi
00007154327d88c4  push rsi
00007154327d88c5  push r8
00007154327d88c7  push r9
00007154327d88c9  push r10
00007154327d88cb  push r11
00007154327d88cd  sub rsp, 0xF0
00007154327d88d4  vmovaps [rsp], xmm0
00007154327d88d9  vmovaps [rsp+0x10], xmm1
00007154327d88df  vmovaps [rsp+0x20], xmm2
00007154327d88e5  vmovaps [rsp+0x30], xmm3
00007154327d88eb  vmovaps [rsp+0x40], xmm4
00007154327d88f1  vmovaps [rsp+0x50], xmm5
00007154327d88f7  vmovaps [rsp+0x60], xmm6
00007154327d88fd  vmovaps [rsp+0x70], xmm7
00007154327d8903  vmovaps [rsp+0x80], xmm8
00007154327d890c  vmovaps [rsp+0x90], xmm9
00007154327d8915  vmovaps [rsp+0xA0], xmm10
00007154327d891e  vmovaps [rsp+0xB0], xmm11
00007154327d8927  vmovaps [rsp+0xC0], xmm12
00007154327d8930  vmovaps [rsp+0xD0], xmm13
00007154327d8939  vmovaps [rsp+0xE0], xmm14
00007154327d8942  sub rsp, 0x30
00007154327d8946  movaps [rsp], xmm15
00007154327d894b  movaps [rsp+0x10], xmm14
00007154327d8951  movaps [rsp+0x20], xmm4
00007154327d8956  lea rdi, [rsp]
00007154327d895a  mov esi, 0x00
00007154327d895f  mov rax, 0x5A63B06A5530
00007154327d8969  call rax
00007154327d896b  movaps xmm15, [rsp]
00007154327d8970  add rsp, 0x30
00007154327d8974  vmovaps xmm0, [rsp]
00007154327d8979  vmovaps xmm1, [rsp+0x10]
00007154327d897f  vmovaps xmm2, [rsp+0x20]
00007154327d8985  vmovaps xmm3, [rsp+0x30]
00007154327d898b  vmovaps xmm4, [rsp+0x40]
00007154327d8991  vmovaps xmm5, [rsp+0x50]
00007154327d8997  vmovaps xmm6, [rsp+0x60]
00007154327d899d  vmovaps xmm7, [rsp+0x70]
00007154327d89a3  vmovaps xmm8, [rsp+0x80]
00007154327d89ac  vmovaps xmm9, [rsp+0x90]
00007154327d89b5  vmovaps xmm10, [rsp+0xA0]
00007154327d89be  vmovaps xmm11, [rsp+0xB0]
00007154327d89c7  vmovaps xmm12, [rsp+0xC0]
00007154327d89d0  vmovaps xmm13, [rsp+0xD0]
00007154327d89d9  vmovaps xmm14, [rsp+0xE0]
00007154327d89e2  add rsp, 0xF0
00007154327d89e9  pop r11
00007154327d89eb  pop r10
00007154327d89ed  pop r9
00007154327d89ef  pop r8
00007154327d89f1  pop rsi
00007154327d89f2  pop rdi
00007154327d89f3  pop rdx
00007154327d89f4  pop rcx
00007154327d89f5  pop rax
00007154327d89f6  add rsp, 0x08
00007154327d89fa  jmp 0x00007154327D60F7
00007154327d89ff  sub rsp, 0x08
00007154327d8a03  push rax
00007154327d8a04  push rcx
00007154327d8a05  push rdx
00007154327d8a06  push rdi
00007154327d8a07  push rsi
00007154327d8a08  push r8
00007154327d8a0a  push r9
00007154327d8a0c  push r10
00007154327d8a0e  push r11
00007154327d8a10  sub rsp, 0xF0
00007154327d8a17  vmovaps [rsp], xmm0
00007154327d8a1c  vmovaps [rsp+0x10], xmm1
00007154327d8a22  vmovaps [rsp+0x20], xmm2
00007154327d8a28  vmovaps [rsp+0x30], xmm3
00007154327d8a2e  vmovaps [rsp+0x40], xmm4
00007154327d8a34  vmovaps [rsp+0x50], xmm5
00007154327d8a3a  vmovaps [rsp+0x60], xmm6
00007154327d8a40  vmovaps [rsp+0x70], xmm7
00007154327d8a46  vmovaps [rsp+0x80], xmm8
00007154327d8a4f  vmovaps [rsp+0x90], xmm9
00007154327d8a58  vmovaps [rsp+0xA0], xmm10
00007154327d8a61  vmovaps [rsp+0xB0], xmm11
00007154327d8a6a  vmovaps [rsp+0xC0], xmm12
00007154327d8a73  vmovaps [rsp+0xD0], xmm13
00007154327d8a7c  vmovaps [rsp+0xE0], xmm15
00007154327d8a85  sub rsp, 0x30
00007154327d8a89  movaps [rsp], xmm14
00007154327d8a8e  movaps [rsp+0x10], xmm2
00007154327d8a93  movaps [rsp+0x20], xmm1
00007154327d8a98  lea rdi, [rsp]
00007154327d8a9c  mov esi, 0x00
00007154327d8aa1  mov rax, 0x5A63B06A5530
00007154327d8aab  call rax
00007154327d8aad  movaps xmm14, [rsp]
00007154327d8ab2  add rsp, 0x30
00007154327d8ab6  vmovaps xmm0, [rsp]
00007154327d8abb  vmovaps xmm1, [rsp+0x10]
00007154327d8ac1  vmovaps xmm2, [rsp+0x20]
00007154327d8ac7  vmovaps xmm3, [rsp+0x30]
00007154327d8acd  vmovaps xmm4, [rsp+0x40]
00007154327d8ad3  vmovaps xmm5, [rsp+0x50]
00007154327d8ad9  vmovaps xmm6, [rsp+0x60]
00007154327d8adf  vmovaps xmm7, [rsp+0x70]
00007154327d8ae5  vmovaps xmm8, [rsp+0x80]
00007154327d8aee  vmovaps xmm9, [rsp+0x90]
00007154327d8af7  vmovaps xmm10, [rsp+0xA0]
00007154327d8b00  vmovaps xmm11, [rsp+0xB0]
00007154327d8b09  vmovaps xmm12, [rsp+0xC0]
00007154327d8b12  vmovaps xmm13, [rsp+0xD0]
00007154327d8b1b  vmovaps xmm15, [rsp+0xE0]
00007154327d8b24  add rsp, 0xF0
00007154327d8b2b  pop r11
00007154327d8b2d  pop r10
00007154327d8b2f  pop r9
00007154327d8b31  pop r8
00007154327d8b33  pop rsi
00007154327d8b34  pop rdi
00007154327d8b35  pop rdx
00007154327d8b36  pop rcx
00007154327d8b37  pop rax
00007154327d8b38  add rsp, 0x08
00007154327d8b3c  jmp 0x00007154327D611D
00007154327d8b41  sub rsp, 0x08
00007154327d8b45  push rax
00007154327d8b46  push rcx
00007154327d8b47  push rdx
00007154327d8b48  push rdi
00007154327d8b49  push rsi
00007154327d8b4a  push r8
00007154327d8b4c  push r9
00007154327d8b4e  push r10
00007154327d8b50  push r11
00007154327d8b52  sub rsp, 0xF0
00007154327d8b59  vmovaps [rsp], xmm0
00007154327d8b5e  vmovaps [rsp+0x10], xmm2
00007154327d8b64  vmovaps [rsp+0x20], xmm3
00007154327d8b6a  vmovaps [rsp+0x30], xmm4
00007154327d8b70  vmovaps [rsp+0x40], xmm5
00007154327d8b76  vmovaps [rsp+0x50], xmm6
00007154327d8b7c  vmovaps [rsp+0x60], xmm7
00007154327d8b82  vmovaps [rsp+0x70], xmm8
00007154327d8b88  vmovaps [rsp+0x80], xmm9
00007154327d8b91  vmovaps [rsp+0x90], xmm10
00007154327d8b9a  vmovaps [rsp+0xA0], xmm11
00007154327d8ba3  vmovaps [rsp+0xB0], xmm12
00007154327d8bac  vmovaps [rsp+0xC0], xmm13
00007154327d8bb5  vmovaps [rsp+0xD0], xmm14
00007154327d8bbe  vmovaps [rsp+0xE0], xmm15
00007154327d8bc7  sub rsp, 0x30
00007154327d8bcb  movaps [rsp], xmm1
00007154327d8bcf  movaps [rsp+0x10], xmm4
00007154327d8bd4  movaps [rsp+0x20], xmm9
00007154327d8bda  lea rdi, [rsp]
00007154327d8bde  mov esi, 0x00
00007154327d8be3  mov rax, 0x5A63B06A5530
00007154327d8bed  call rax
00007154327d8bef  movaps xmm1, [rsp]
00007154327d8bf3  add rsp, 0x30
00007154327d8bf7  vmovaps xmm0, [rsp]
00007154327d8bfc  vmovaps xmm2, [rsp+0x10]
00007154327d8c02  vmovaps xmm3, [rsp+0x20]
00007154327d8c08  vmovaps xmm4, [rsp+0x30]
00007154327d8c0e  vmovaps xmm5, [rsp+0x40]
00007154327d8c14  vmovaps xmm6, [rsp+0x50]
00007154327d8c1a  vmovaps xmm7, [rsp+0x60]
00007154327d8c20  vmovaps xmm8, [rsp+0x70]
00007154327d8c26  vmovaps xmm9, [rsp+0x80]
00007154327d8c2f  vmovaps xmm10, [rsp+0x90]
00007154327d8c38  vmovaps xmm11, [rsp+0xA0]
00007154327d8c41  vmovaps xmm12, [rsp+0xB0]
00007154327d8c4a  vmovaps xmm13, [rsp+0xC0]
00007154327d8c53  vmovaps xmm14, [rsp+0xD0]
00007154327d8c5c  vmovaps xmm15, [rsp+0xE0]
00007154327d8c65  add rsp, 0xF0
00007154327d8c6c  pop r11
00007154327d8c6e  pop r10
00007154327d8c70  pop r9
00007154327d8c72  pop r8
00007154327d8c74  pop rsi
00007154327d8c75  pop rdi
00007154327d8c76  pop rdx
00007154327d8c77  pop rcx
00007154327d8c78  pop rax
00007154327d8c79  add rsp, 0x08
00007154327d8c7d  jmp 0x00007154327D613B
00007154327d8c82  sub rsp, 0x08
00007154327d8c86  push rax
00007154327d8c87  push rcx
00007154327d8c88  push rdx
00007154327d8c89  push rdi
00007154327d8c8a  push rsi
00007154327d8c8b  push r8
00007154327d8c8d  push r9
00007154327d8c8f  push r10
00007154327d8c91  push r11
00007154327d8c93  sub rsp, 0xF0
00007154327d8c9a  vmovaps [rsp], xmm0
00007154327d8c9f  vmovaps [rsp+0x10], xmm1
00007154327d8ca5  vmovaps [rsp+0x20], xmm2
00007154327d8cab  vmovaps [rsp+0x30], xmm3
00007154327d8cb1  vmovaps [rsp+0x40], xmm5
00007154327d8cb7  vmovaps [rsp+0x50], xmm6
00007154327d8cbd  vmovaps [rsp+0x60], xmm7
00007154327d8cc3  vmovaps [rsp+0x70], xmm8
00007154327d8cc9  vmovaps [rsp+0x80], xmm9
00007154327d8cd2  vmovaps [rsp+0x90], xmm10
00007154327d8cdb  vmovaps [rsp+0xA0], xmm11
00007154327d8ce4  vmovaps [rsp+0xB0], xmm12
00007154327d8ced  vmovaps [rsp+0xC0], xmm13
00007154327d8cf6  vmovaps [rsp+0xD0], xmm14
00007154327d8cff  vmovaps [rsp+0xE0], xmm15
00007154327d8d08  sub rsp, 0x30
00007154327d8d0c  movaps [rsp], xmm4
00007154327d8d10  movaps [rsp+0x10], xmm2
00007154327d8d15  movaps [rsp+0x20], xmm9
00007154327d8d1b  lea rdi, [rsp]
00007154327d8d1f  mov esi, 0x00
00007154327d8d24  mov rax, 0x5A63B06A5530
00007154327d8d2e  call rax
00007154327d8d30  movaps xmm4, [rsp]
00007154327d8d34  add rsp, 0x30
00007154327d8d38  vmovaps xmm0, [rsp]
00007154327d8d3d  vmovaps xmm1, [rsp+0x10]
00007154327d8d43  vmovaps xmm2, [rsp+0x20]
00007154327d8d49  vmovaps xmm3, [rsp+0x30]
00007154327d8d4f  vmovaps xmm5, [rsp+0x40]
00007154327d8d55  vmovaps xmm6, [rsp+0x50]
00007154327d8d5b  vmovaps xmm7, [rsp+0x60]
00007154327d8d61  vmovaps xmm8, [rsp+0x70]
00007154327d8d67  vmovaps xmm9, [rsp+0x80]
00007154327d8d70  vmovaps xmm10, [rsp+0x90]
00007154327d8d79  vmovaps xmm11, [rsp+0xA0]
00007154327d8d82  vmovaps xmm12, [rsp+0xB0]
00007154327d8d8b  vmovaps xmm13, [rsp+0xC0]
00007154327d8d94  vmovaps xmm14, [rsp+0xD0]
00007154327d8d9d  vmovaps xmm15, [rsp+0xE0]
00007154327d8da6  add rsp, 0xF0
00007154327d8dad  pop r11
00007154327d8daf  pop r10
00007154327d8db1  pop r9
00007154327d8db3  pop r8
00007154327d8db5  pop rsi
00007154327d8db6  pop rdi
00007154327d8db7  pop rdx
00007154327d8db8  pop rcx
00007154327d8db9  pop rax
00007154327d8dba  add rsp, 0x08
00007154327d8dbe  jmp 0x00007154327D616B
00007154327d8dc3  sub rsp, 0x08
00007154327d8dc7  push rax
00007154327d8dc8  push rcx
00007154327d8dc9  push rdx
00007154327d8dca  push rdi
00007154327d8dcb  push rsi
00007154327d8dcc  push r8
00007154327d8dce  push r9
00007154327d8dd0  push r10
00007154327d8dd2  push r11
00007154327d8dd4  sub rsp, 0xF0
00007154327d8ddb  vmovaps [rsp], xmm0
00007154327d8de0  vmovaps [rsp+0x10], xmm1
00007154327d8de6  vmovaps [rsp+0x20], xmm2
00007154327d8dec  vmovaps [rsp+0x30], xmm3
00007154327d8df2  vmovaps [rsp+0x40], xmm4
00007154327d8df8  vmovaps [rsp+0x50], xmm5
00007154327d8dfe  vmovaps [rsp+0x60], xmm6
00007154327d8e04  vmovaps [rsp+0x70], xmm7
00007154327d8e0a  vmovaps [rsp+0x80], xmm8
00007154327d8e13  vmovaps [rsp+0x90], xmm10
00007154327d8e1c  vmovaps [rsp+0xA0], xmm11
00007154327d8e25  vmovaps [rsp+0xB0], xmm12
00007154327d8e2e  vmovaps [rsp+0xC0], xmm13
00007154327d8e37  vmovaps [rsp+0xD0], xmm14
00007154327d8e40  vmovaps [rsp+0xE0], xmm15
00007154327d8e49  sub rsp, 0x30
00007154327d8e4d  movaps [rsp], xmm9
00007154327d8e52  movaps [rsp+0x10], xmm2
00007154327d8e57  movaps [rsp+0x20], xmm1
00007154327d8e5c  lea rdi, [rsp]
00007154327d8e60  mov esi, 0x00
00007154327d8e65  mov rax, 0x5A63B06A5530
00007154327d8e6f  call rax
00007154327d8e71  movaps xmm9, [rsp]
00007154327d8e76  add rsp, 0x30
00007154327d8e7a  vmovaps xmm0, [rsp]
00007154327d8e7f  vmovaps xmm1, [rsp+0x10]
00007154327d8e85  vmovaps xmm2, [rsp+0x20]
00007154327d8e8b  vmovaps xmm3, [rsp+0x30]
00007154327d8e91  vmovaps xmm4, [rsp+0x40]
00007154327d8e97  vmovaps xmm5, [rsp+0x50]
00007154327d8e9d  vmovaps xmm6, [rsp+0x60]
00007154327d8ea3  vmovaps xmm7, [rsp+0x70]
00007154327d8ea9  vmovaps xmm8, [rsp+0x80]
00007154327d8eb2  vmovaps xmm10, [rsp+0x90]
00007154327d8ebb  vmovaps xmm11, [rsp+0xA0]
00007154327d8ec4  vmovaps xmm12, [rsp+0xB0]
00007154327d8ecd  vmovaps xmm13, [rsp+0xC0]
00007154327d8ed6  vmovaps xmm14, [rsp+0xD0]
00007154327d8edf  vmovaps xmm15, [rsp+0xE0]
00007154327d8ee8  add rsp, 0xF0
00007154327d8eef  pop r11
00007154327d8ef1  pop r10
00007154327d8ef3  pop r9
00007154327d8ef5  pop r8
00007154327d8ef7  pop rsi
00007154327d8ef8  pop rdi
00007154327d8ef9  pop rdx
00007154327d8efa  pop rcx
00007154327d8efb  pop rax
00007154327d8efc  add rsp, 0x08
00007154327d8f00  jmp 0x00007154327D61A1
00007154327d8f05  sub rsp, 0x08
00007154327d8f09  push rax
00007154327d8f0a  push rcx
00007154327d8f0b  push rdx
00007154327d8f0c  push rdi
00007154327d8f0d  push rsi
00007154327d8f0e  push r8
00007154327d8f10  push r9
00007154327d8f12  push r10
00007154327d8f14  push r11
00007154327d8f16  sub rsp, 0xF0
00007154327d8f1d  vmovaps [rsp], xmm0
00007154327d8f22  vmovaps [rsp+0x10], xmm2
00007154327d8f28  vmovaps [rsp+0x20], xmm3
00007154327d8f2e  vmovaps [rsp+0x30], xmm4
00007154327d8f34  vmovaps [rsp+0x40], xmm5
00007154327d8f3a  vmovaps [rsp+0x50], xmm6
00007154327d8f40  vmovaps [rsp+0x60], xmm7
00007154327d8f46  vmovaps [rsp+0x70], xmm8
00007154327d8f4c  vmovaps [rsp+0x80], xmm9
00007154327d8f55  vmovaps [rsp+0x90], xmm10
00007154327d8f5e  vmovaps [rsp+0xA0], xmm11
00007154327d8f67  vmovaps [rsp+0xB0], xmm12
00007154327d8f70  vmovaps [rsp+0xC0], xmm13
00007154327d8f79  vmovaps [rsp+0xD0], xmm14
00007154327d8f82  vmovaps [rsp+0xE0], xmm15
00007154327d8f8b  sub rsp, 0x30
00007154327d8f8f  movaps [rsp], xmm1
00007154327d8f93  movaps [rsp+0x10], xmm15
00007154327d8f99  movaps [rsp+0x20], xmm6
00007154327d8f9e  lea rdi, [rsp]
00007154327d8fa2  mov esi, 0x00
00007154327d8fa7  mov rax, 0x5A63B06A5530
00007154327d8fb1  call rax
00007154327d8fb3  movaps xmm1, [rsp]
00007154327d8fb7  add rsp, 0x30
00007154327d8fbb  vmovaps xmm0, [rsp]
00007154327d8fc0  vmovaps xmm2, [rsp+0x10]
00007154327d8fc6  vmovaps xmm3, [rsp+0x20]
00007154327d8fcc  vmovaps xmm4, [rsp+0x30]
00007154327d8fd2  vmovaps xmm5, [rsp+0x40]
00007154327d8fd8  vmovaps xmm6, [rsp+0x50]
00007154327d8fde  vmovaps xmm7, [rsp+0x60]
00007154327d8fe4  vmovaps xmm8, [rsp+0x70]
00007154327d8fea  vmovaps xmm9, [rsp+0x80]
00007154327d8ff3  vmovaps xmm10, [rsp+0x90]
00007154327d8ffc  vmovaps xmm11, [rsp+0xA0]
00007154327d9005  vmovaps xmm12, [rsp+0xB0]
00007154327d900e  vmovaps xmm13, [rsp+0xC0]
00007154327d9017  vmovaps xmm14, [rsp+0xD0]
00007154327d9020  vmovaps xmm15, [rsp+0xE0]
00007154327d9029  add rsp, 0xF0
00007154327d9030  pop r11
00007154327d9032  pop r10
00007154327d9034  pop r9
00007154327d9036  pop r8
00007154327d9038  pop rsi
00007154327d9039  pop rdi
00007154327d903a  pop rdx
00007154327d903b  pop rcx
00007154327d903c  pop rax
00007154327d903d  add rsp, 0x08
00007154327d9041  jmp 0x00007154327D61C2
00007154327d9046  sub rsp, 0x08
00007154327d904a  push rax
00007154327d904b  push rcx
00007154327d904c  push rdx
00007154327d904d  push rdi
00007154327d904e  push rsi
00007154327d904f  push r8
00007154327d9051  push r9
00007154327d9053  push r10
00007154327d9055  push r11
00007154327d9057  sub rsp, 0xF0
00007154327d905e  vmovaps [rsp], xmm0
00007154327d9063  vmovaps [rsp+0x10], xmm1
00007154327d9069  vmovaps [rsp+0x20], xmm2
00007154327d906f  vmovaps [rsp+0x30], xmm3
00007154327d9075  vmovaps [rsp+0x40], xmm4
00007154327d907b  vmovaps [rsp+0x50], xmm5
00007154327d9081  vmovaps [rsp+0x60], xmm6
00007154327d9087  vmovaps [rsp+0x70], xmm7
00007154327d908d  vmovaps [rsp+0x80], xmm8
00007154327d9096  vmovaps [rsp+0x90], xmm9
00007154327d909f  vmovaps [rsp+0xA0], xmm10
00007154327d90a8  vmovaps [rsp+0xB0], xmm11
00007154327d90b1  vmovaps [rsp+0xC0], xmm12
00007154327d90ba  vmovaps [rsp+0xD0], xmm13
00007154327d90c3  vmovaps [rsp+0xE0], xmm14
00007154327d90cc  sub rsp, 0x30
00007154327d90d0  movaps [rsp], xmm15
00007154327d90d5  movaps [rsp+0x10], xmm5
00007154327d90da  movaps [rsp+0x20], xmm3
00007154327d90df  lea rdi, [rsp]
00007154327d90e3  mov esi, 0x00
00007154327d90e8  mov rax, 0x5A63B06A5530
00007154327d90f2  call rax
00007154327d90f4  movaps xmm15, [rsp]
00007154327d90f9  add rsp, 0x30
00007154327d90fd  vmovaps xmm0, [rsp]
00007154327d9102  vmovaps xmm1, [rsp+0x10]
00007154327d9108  vmovaps xmm2, [rsp+0x20]
00007154327d910e  vmovaps xmm3, [rsp+0x30]
00007154327d9114  vmovaps xmm4, [rsp+0x40]
00007154327d911a  vmovaps xmm5, [rsp+0x50]
00007154327d9120  vmovaps xmm6, [rsp+0x60]
00007154327d9126  vmovaps xmm7, [rsp+0x70]
00007154327d912c  vmovaps xmm8, [rsp+0x80]
00007154327d9135  vmovaps xmm9, [rsp+0x90]
00007154327d913e  vmovaps xmm10, [rsp+0xA0]
00007154327d9147  vmovaps xmm11, [rsp+0xB0]
00007154327d9150  vmovaps xmm12, [rsp+0xC0]
00007154327d9159  vmovaps xmm13, [rsp+0xD0]
00007154327d9162  vmovaps xmm14, [rsp+0xE0]
00007154327d916b  add rsp, 0xF0
00007154327d9172  pop r11
00007154327d9174  pop r10
00007154327d9176  pop r9
00007154327d9178  pop r8
00007154327d917a  pop rsi
00007154327d917b  pop rdi
00007154327d917c  pop rdx
00007154327d917d  pop rcx
00007154327d917e  pop rax
00007154327d917f  add rsp, 0x08
00007154327d9183  jmp 0x00007154327D61DC
00007154327d9188  sub rsp, 0x08
00007154327d918c  push rax
00007154327d918d  push rcx
00007154327d918e  push rdx
00007154327d918f  push rdi
00007154327d9190  push rsi
00007154327d9191  push r8
00007154327d9193  push r9
00007154327d9195  push r10
00007154327d9197  push r11
00007154327d9199  sub rsp, 0xF0
00007154327d91a0  vmovaps [rsp], xmm0
00007154327d91a5  vmovaps [rsp+0x10], xmm1
00007154327d91ab  vmovaps [rsp+0x20], xmm2
00007154327d91b1  vmovaps [rsp+0x30], xmm3
00007154327d91b7  vmovaps [rsp+0x40], xmm4
00007154327d91bd  vmovaps [rsp+0x50], xmm6
00007154327d91c3  vmovaps [rsp+0x60], xmm7
00007154327d91c9  vmovaps [rsp+0x70], xmm8
00007154327d91cf  vmovaps [rsp+0x80], xmm9
00007154327d91d8  vmovaps [rsp+0x90], xmm10
00007154327d91e1  vmovaps [rsp+0xA0], xmm11
00007154327d91ea  vmovaps [rsp+0xB0], xmm12
00007154327d91f3  vmovaps [rsp+0xC0], xmm13
00007154327d91fc  vmovaps [rsp+0xD0], xmm14
00007154327d9205  vmovaps [rsp+0xE0], xmm15
00007154327d920e  sub rsp, 0x30
00007154327d9212  movaps [rsp], xmm5
00007154327d9216  movaps [rsp+0x10], xmm8
00007154327d921c  movaps [rsp+0x20], xmm6
00007154327d9221  lea rdi, [rsp]
00007154327d9225  mov esi, 0x00
00007154327d922a  mov rax, 0x5A63B06A5530
00007154327d9234  call rax
00007154327d9236  movaps xmm5, [rsp]
00007154327d923a  add rsp, 0x30
00007154327d923e  vmovaps xmm0, [rsp]
00007154327d9243  vmovaps xmm1, [rsp+0x10]
00007154327d9249  vmovaps xmm2, [rsp+0x20]
00007154327d924f  vmovaps xmm3, [rsp+0x30]
00007154327d9255  vmovaps xmm4, [rsp+0x40]
00007154327d925b  vmovaps xmm6, [rsp+0x50]
00007154327d9261  vmovaps xmm7, [rsp+0x60]
00007154327d9267  vmovaps xmm8, [rsp+0x70]
00007154327d926d  vmovaps xmm9, [rsp+0x80]
00007154327d9276  vmovaps xmm10, [rsp+0x90]
00007154327d927f  vmovaps xmm11, [rsp+0xA0]
00007154327d9288  vmovaps xmm12, [rsp+0xB0]
00007154327d9291  vmovaps xmm13, [rsp+0xC0]
00007154327d929a  vmovaps xmm14, [rsp+0xD0]
00007154327d92a3  vmovaps xmm15, [rsp+0xE0]
00007154327d92ac  add rsp, 0xF0
00007154327d92b3  pop r11
00007154327d92b5  pop r10
00007154327d92b7  pop r9
00007154327d92b9  pop r8
00007154327d92bb  pop rsi
00007154327d92bc  pop rdi
00007154327d92bd  pop rdx
00007154327d92be  pop rcx
00007154327d92bf  pop rax
00007154327d92c0  add rsp, 0x08
00007154327d92c4  jmp 0x00007154327D6200
00007154327d92c9  sub rsp, 0x08
00007154327d92cd  push rax
00007154327d92ce  push rcx
00007154327d92cf  push rdx
00007154327d92d0  push rdi
00007154327d92d1  push rsi
00007154327d92d2  push r8
00007154327d92d4  push r9
00007154327d92d6  push r10
00007154327d92d8  push r11
00007154327d92da  sub rsp, 0xF0
00007154327d92e1  vmovaps [rsp], xmm0
00007154327d92e6  vmovaps [rsp+0x10], xmm1
00007154327d92ec  vmovaps [rsp+0x20], xmm2
00007154327d92f2  vmovaps [rsp+0x30], xmm3
00007154327d92f8  vmovaps [rsp+0x40], xmm4
00007154327d92fe  vmovaps [rsp+0x50], xmm5
00007154327d9304  vmovaps [rsp+0x60], xmm7
00007154327d930a  vmovaps [rsp+0x70], xmm8
00007154327d9310  vmovaps [rsp+0x80], xmm9
00007154327d9319  vmovaps [rsp+0x90], xmm10
00007154327d9322  vmovaps [rsp+0xA0], xmm11
00007154327d932b  vmovaps [rsp+0xB0], xmm12
00007154327d9334  vmovaps [rsp+0xC0], xmm13
00007154327d933d  vmovaps [rsp+0xD0], xmm14
00007154327d9346  vmovaps [rsp+0xE0], xmm15
00007154327d934f  sub rsp, 0x30
00007154327d9353  movaps [rsp], xmm6
00007154327d9357  movaps [rsp+0x10], xmm10
00007154327d935d  movaps [rsp+0x20], xmm8
00007154327d9363  lea rdi, [rsp]
00007154327d9367  mov esi, 0x00
00007154327d936c  mov rax, 0x5A63B06A5530
00007154327d9376  call rax
00007154327d9378  movaps xmm6, [rsp]
00007154327d937c  add rsp, 0x30
00007154327d9380  vmovaps xmm0, [rsp]
00007154327d9385  vmovaps xmm1, [rsp+0x10]
00007154327d938b  vmovaps xmm2, [rsp+0x20]
00007154327d9391  vmovaps xmm3, [rsp+0x30]
00007154327d9397  vmovaps xmm4, [rsp+0x40]
00007154327d939d  vmovaps xmm5, [rsp+0x50]
00007154327d93a3  vmovaps xmm7, [rsp+0x60]
00007154327d93a9  vmovaps xmm8, [rsp+0x70]
00007154327d93af  vmovaps xmm9, [rsp+0x80]
00007154327d93b8  vmovaps xmm10, [rsp+0x90]
00007154327d93c1  vmovaps xmm11, [rsp+0xA0]
00007154327d93ca  vmovaps xmm12, [rsp+0xB0]
00007154327d93d3  vmovaps xmm13, [rsp+0xC0]
00007154327d93dc  vmovaps xmm14, [rsp+0xD0]
00007154327d93e5  vmovaps xmm15, [rsp+0xE0]
00007154327d93ee  add rsp, 0xF0
00007154327d93f5  pop r11
00007154327d93f7  pop r10
00007154327d93f9  pop r9
00007154327d93fb  pop r8
00007154327d93fd  pop rsi
00007154327d93fe  pop rdi
00007154327d93ff  pop rdx
00007154327d9400  pop rcx
00007154327d9401  pop rax
00007154327d9402  add rsp, 0x08
00007154327d9406  jmp 0x00007154327D6225
00007154327d940b  sub rsp, 0x08
00007154327d940f  push rax
00007154327d9410  push rcx
00007154327d9411  push rdx
00007154327d9412  push rdi
00007154327d9413  push rsi
00007154327d9414  push r8
00007154327d9416  push r9
00007154327d9418  push r10
00007154327d941a  push r11
00007154327d941c  sub rsp, 0xF0
00007154327d9423  vmovaps [rsp], xmm0
00007154327d9428  vmovaps [rsp+0x10], xmm1
00007154327d942e  vmovaps [rsp+0x20], xmm2
00007154327d9434  vmovaps [rsp+0x30], xmm3
00007154327d943a  vmovaps [rsp+0x40], xmm4
00007154327d9440  vmovaps [rsp+0x50], xmm5
00007154327d9446  vmovaps [rsp+0x60], xmm6
00007154327d944c  vmovaps [rsp+0x70], xmm7
00007154327d9452  vmovaps [rsp+0x80], xmm8
00007154327d945b  vmovaps [rsp+0x90], xmm9
00007154327d9464  vmovaps [rsp+0xA0], xmm11
00007154327d946d  vmovaps [rsp+0xB0], xmm12
00007154327d9476  vmovaps [rsp+0xC0], xmm13
00007154327d947f  vmovaps [rsp+0xD0], xmm14
00007154327d9488  vmovaps [rsp+0xE0], xmm15
00007154327d9491  sub rsp, 0x30
00007154327d9495  movaps [rsp], xmm10
00007154327d949a  movaps [rsp+0x10], xmm8
00007154327d94a0  movaps [rsp+0x20], xmm14
00007154327d94a6  lea rdi, [rsp]
00007154327d94aa  mov esi, 0x00
00007154327d94af  mov rax, 0x5A63B06A5530
00007154327d94b9  call rax
00007154327d94bb  movaps xmm10, [rsp]
00007154327d94c0  add rsp, 0x30
00007154327d94c4  vmovaps xmm0, [rsp]
00007154327d94c9  vmovaps xmm1, [rsp+0x10]
00007154327d94cf  vmovaps xmm2, [rsp+0x20]
00007154327d94d5  vmovaps xmm3, [rsp+0x30]
00007154327d94db  vmovaps xmm4, [rsp+0x40]
00007154327d94e1  vmovaps xmm5, [rsp+0x50]
00007154327d94e7  vmovaps xmm6, [rsp+0x60]
00007154327d94ed  vmovaps xmm7, [rsp+0x70]
00007154327d94f3  vmovaps xmm8, [rsp+0x80]
00007154327d94fc  vmovaps xmm9, [rsp+0x90]
00007154327d9505  vmovaps xmm11, [rsp+0xA0]
00007154327d950e  vmovaps xmm12, [rsp+0xB0]
00007154327d9517  vmovaps xmm13, [rsp+0xC0]
00007154327d9520  vmovaps xmm14, [rsp+0xD0]
00007154327d9529  vmovaps xmm15, [rsp+0xE0]
00007154327d9532  add rsp, 0xF0
00007154327d9539  pop r11
00007154327d953b  pop r10
00007154327d953d  pop r9
00007154327d953f  pop r8
00007154327d9541  pop rsi
00007154327d9542  pop rdi
00007154327d9543  pop rdx
00007154327d9544  pop rcx
00007154327d9545  pop rax
00007154327d9546  add rsp, 0x08
00007154327d954a  jmp 0x00007154327D6245
00007154327d954f  sub rsp, 0x08
00007154327d9553  push rax
00007154327d9554  push rcx
00007154327d9555  push rdx
00007154327d9556  push rdi
00007154327d9557  push rsi
00007154327d9558  push r8
00007154327d955a  push r9
00007154327d955c  push r10
00007154327d955e  push r11
00007154327d9560  sub rsp, 0xF0
00007154327d9567  vmovaps [rsp], xmm0
00007154327d956c  vmovaps [rsp+0x10], xmm1
00007154327d9572  vmovaps [rsp+0x20], xmm2
00007154327d9578  vmovaps [rsp+0x30], xmm3
00007154327d957e  vmovaps [rsp+0x40], xmm4
00007154327d9584  vmovaps [rsp+0x50], xmm5
00007154327d958a  vmovaps [rsp+0x60], xmm6
00007154327d9590  vmovaps [rsp+0x70], xmm7
00007154327d9596  vmovaps [rsp+0x80], xmm8
00007154327d959f  vmovaps [rsp+0x90], xmm9
00007154327d95a8  vmovaps [rsp+0xA0], xmm10
00007154327d95b1  vmovaps [rsp+0xB0], xmm11
00007154327d95ba  vmovaps [rsp+0xC0], xmm12
00007154327d95c3  vmovaps [rsp+0xD0], xmm13
00007154327d95cc  vmovaps [rsp+0xE0], xmm15
00007154327d95d5  sub rsp, 0x30
00007154327d95d9  movaps [rsp], xmm14
00007154327d95de  movaps [rsp+0x10], xmm8
00007154327d95e4  movaps [rsp+0x20], xmm4
00007154327d95e9  lea rdi, [rsp]
00007154327d95ed  mov esi, 0x00
00007154327d95f2  mov rax, 0x5A63B06A5530
00007154327d95fc  call rax
00007154327d95fe  movaps xmm14, [rsp]
00007154327d9603  add rsp, 0x30
00007154327d9607  vmovaps xmm0, [rsp]
00007154327d960c  vmovaps xmm1, [rsp+0x10]
00007154327d9612  vmovaps xmm2, [rsp+0x20]
00007154327d9618  vmovaps xmm3, [rsp+0x30]
00007154327d961e  vmovaps xmm4, [rsp+0x40]
00007154327d9624  vmovaps xmm5, [rsp+0x50]
00007154327d962a  vmovaps xmm6, [rsp+0x60]
00007154327d9630  vmovaps xmm7, [rsp+0x70]
00007154327d9636  vmovaps xmm8, [rsp+0x80]
00007154327d963f  vmovaps xmm9, [rsp+0x90]
00007154327d9648  vmovaps xmm10, [rsp+0xA0]
00007154327d9651  vmovaps xmm11, [rsp+0xB0]
00007154327d965a  vmovaps xmm12, [rsp+0xC0]
00007154327d9663  vmovaps xmm13, [rsp+0xD0]
00007154327d966c  vmovaps xmm15, [rsp+0xE0]
00007154327d9675  add rsp, 0xF0
00007154327d967c  pop r11
00007154327d967e  pop r10
00007154327d9680  pop r9
00007154327d9682  pop r8
00007154327d9684  pop rsi
00007154327d9685  pop rdi
00007154327d9686  pop rdx
00007154327d9687  pop rcx
00007154327d9688  pop rax
00007154327d9689  add rsp, 0x08
00007154327d968d  jmp 0x00007154327D6265
00007154327d9692  sub rsp, 0x08
00007154327d9696  push rax
00007154327d9697  push rcx
00007154327d9698  push rdx
00007154327d9699  push rdi
00007154327d969a  push rsi
00007154327d969b  push r8
00007154327d969d  push r9
00007154327d969f  push r10
00007154327d96a1  push r11
00007154327d96a3  sub rsp, 0xF0
00007154327d96aa  vmovaps [rsp], xmm0
00007154327d96af  vmovaps [rsp+0x10], xmm1
00007154327d96b5  vmovaps [rsp+0x20], xmm2
00007154327d96bb  vmovaps [rsp+0x30], xmm3
00007154327d96c1  vmovaps [rsp+0x40], xmm5
00007154327d96c7  vmovaps [rsp+0x50], xmm6
00007154327d96cd  vmovaps [rsp+0x60], xmm7
00007154327d96d3  vmovaps [rsp+0x70], xmm8
00007154327d96d9  vmovaps [rsp+0x80], xmm9
00007154327d96e2  vmovaps [rsp+0x90], xmm10
00007154327d96eb  vmovaps [rsp+0xA0], xmm11
00007154327d96f4  vmovaps [rsp+0xB0], xmm12
00007154327d96fd  vmovaps [rsp+0xC0], xmm13
00007154327d9706  vmovaps [rsp+0xD0], xmm14
00007154327d970f  vmovaps [rsp+0xE0], xmm15
00007154327d9718  sub rsp, 0x30
00007154327d971c  movaps [rsp], xmm4
00007154327d9720  movaps [rsp+0x10], xmm13
00007154327d9726  movaps [rsp+0x20], xmm8
00007154327d972c  lea rdi, [rsp]
00007154327d9730  mov esi, 0x00
00007154327d9735  mov rax, 0x5A63B06A5530
00007154327d973f  call rax
00007154327d9741  movaps xmm4, [rsp]
00007154327d9745  add rsp, 0x30
00007154327d9749  vmovaps xmm0, [rsp]
00007154327d974e  vmovaps xmm1, [rsp+0x10]
00007154327d9754  vmovaps xmm2, [rsp+0x20]
00007154327d975a  vmovaps xmm3, [rsp+0x30]
00007154327d9760  vmovaps xmm5, [rsp+0x40]
00007154327d9766  vmovaps xmm6, [rsp+0x50]
00007154327d976c  vmovaps xmm7, [rsp+0x60]
00007154327d9772  vmovaps xmm8, [rsp+0x70]
00007154327d9778  vmovaps xmm9, [rsp+0x80]
00007154327d9781  vmovaps xmm10, [rsp+0x90]
00007154327d978a  vmovaps xmm11, [rsp+0xA0]
00007154327d9793  vmovaps xmm12, [rsp+0xB0]
00007154327d979c  vmovaps xmm13, [rsp+0xC0]
00007154327d97a5  vmovaps xmm14, [rsp+0xD0]
00007154327d97ae  vmovaps xmm15, [rsp+0xE0]
00007154327d97b7  add rsp, 0xF0
00007154327d97be  pop r11
00007154327d97c0  pop r10
00007154327d97c2  pop r9
00007154327d97c4  pop r8
00007154327d97c6  pop rsi
00007154327d97c7  pop rdi
00007154327d97c8  pop rdx
00007154327d97c9  pop rcx
00007154327d97ca  pop rax
00007154327d97cb  add rsp, 0x08
00007154327d97cf  jmp 0x00007154327D628A
00007154327d97d4  sub rsp, 0x08
00007154327d97d8  push rax
00007154327d97d9  push rcx
00007154327d97da  push rdx
00007154327d97db  push rdi
00007154327d97dc  push rsi
00007154327d97dd  push r8
00007154327d97df  push r9
00007154327d97e1  push r10
00007154327d97e3  push r11
00007154327d97e5  sub rsp, 0xF0
00007154327d97ec  vmovaps [rsp], xmm0
00007154327d97f1  vmovaps [rsp+0x10], xmm1
00007154327d97f7  vmovaps [rsp+0x20], xmm2
00007154327d97fd  vmovaps [rsp+0x30], xmm3
00007154327d9803  vmovaps [rsp+0x40], xmm4
00007154327d9809  vmovaps [rsp+0x50], xmm5
00007154327d980f  vmovaps [rsp+0x60], xmm6
00007154327d9815  vmovaps [rsp+0x70], xmm7
00007154327d981b  vmovaps [rsp+0x80], xmm8
00007154327d9824  vmovaps [rsp+0x90], xmm9
00007154327d982d  vmovaps [rsp+0xA0], xmm10
00007154327d9836  vmovaps [rsp+0xB0], xmm11
00007154327d983f  vmovaps [rsp+0xC0], xmm12
00007154327d9848  vmovaps [rsp+0xD0], xmm14
00007154327d9851  vmovaps [rsp+0xE0], xmm15
00007154327d985a  sub rsp, 0x30
00007154327d985e  movaps [rsp], xmm13
00007154327d9863  movaps [rsp+0x10], xmm15
00007154327d9869  movaps [rsp+0x20], xmm9
00007154327d986f  lea rdi, [rsp]
00007154327d9873  mov esi, 0x00
00007154327d9878  mov rax, 0x5A63B06A5530
00007154327d9882  call rax
00007154327d9884  movaps xmm13, [rsp]
00007154327d9889  add rsp, 0x30
00007154327d988d  vmovaps xmm0, [rsp]
00007154327d9892  vmovaps xmm1, [rsp+0x10]
00007154327d9898  vmovaps xmm2, [rsp+0x20]
00007154327d989e  vmovaps xmm3, [rsp+0x30]
00007154327d98a4  vmovaps xmm4, [rsp+0x40]
00007154327d98aa  vmovaps xmm5, [rsp+0x50]
00007154327d98b0  vmovaps xmm6, [rsp+0x60]
00007154327d98b6  vmovaps xmm7, [rsp+0x70]
00007154327d98bc  vmovaps xmm8, [rsp+0x80]
00007154327d98c5  vmovaps xmm9, [rsp+0x90]
00007154327d98ce  vmovaps xmm10, [rsp+0xA0]
00007154327d98d7  vmovaps xmm11, [rsp+0xB0]
00007154327d98e0  vmovaps xmm12, [rsp+0xC0]
00007154327d98e9  vmovaps xmm14, [rsp+0xD0]
00007154327d98f2  vmovaps xmm15, [rsp+0xE0]
00007154327d98fb  add rsp, 0xF0
00007154327d9902  pop r11
00007154327d9904  pop r10
00007154327d9906  pop r9
00007154327d9908  pop r8
00007154327d990a  pop rsi
00007154327d990b  pop rdi
00007154327d990c  pop rdx
00007154327d990d  pop rcx
00007154327d990e  pop rax
00007154327d990f  add rsp, 0x08
00007154327d9913  jmp 0x00007154327D62A5
00007154327d9918  sub rsp, 0x08
00007154327d991c  push rax
00007154327d991d  push rcx
00007154327d991e  push rdx
00007154327d991f  push rdi
00007154327d9920  push rsi
00007154327d9921  push r8
00007154327d9923  push r9
00007154327d9925  push r10
00007154327d9927  push r11
00007154327d9929  sub rsp, 0xF0
00007154327d9930  vmovaps [rsp], xmm0
00007154327d9935  vmovaps [rsp+0x10], xmm1
00007154327d993b  vmovaps [rsp+0x20], xmm2
00007154327d9941  vmovaps [rsp+0x30], xmm3
00007154327d9947  vmovaps [rsp+0x40], xmm4
00007154327d994d  vmovaps [rsp+0x50], xmm5
00007154327d9953  vmovaps [rsp+0x60], xmm6
00007154327d9959  vmovaps [rsp+0x70], xmm7
00007154327d995f  vmovaps [rsp+0x80], xmm8
00007154327d9968  vmovaps [rsp+0x90], xmm9
00007154327d9971  vmovaps [rsp+0xA0], xmm10
00007154327d997a  vmovaps [rsp+0xB0], xmm11
00007154327d9983  vmovaps [rsp+0xC0], xmm12
00007154327d998c  vmovaps [rsp+0xD0], xmm13
00007154327d9995  vmovaps [rsp+0xE0], xmm14
00007154327d999e  sub rsp, 0x30
00007154327d99a2  movaps [rsp], xmm15
00007154327d99a7  movaps [rsp+0x10], xmm1
00007154327d99ac  movaps [rsp+0x20], xmm5
00007154327d99b1  lea rdi, [rsp]
00007154327d99b5  mov esi, 0x00
00007154327d99ba  mov rax, 0x5A63B06A5530
00007154327d99c4  call rax
00007154327d99c6  movaps xmm15, [rsp]
00007154327d99cb  add rsp, 0x30
00007154327d99cf  vmovaps xmm0, [rsp]
00007154327d99d4  vmovaps xmm1, [rsp+0x10]
00007154327d99da  vmovaps xmm2, [rsp+0x20]
00007154327d99e0  vmovaps xmm3, [rsp+0x30]
00007154327d99e6  vmovaps xmm4, [rsp+0x40]
00007154327d99ec  vmovaps xmm5, [rsp+0x50]
00007154327d99f2  vmovaps xmm6, [rsp+0x60]
00007154327d99f8  vmovaps xmm7, [rsp+0x70]
00007154327d99fe  vmovaps xmm8, [rsp+0x80]
00007154327d9a07  vmovaps xmm9, [rsp+0x90]
00007154327d9a10  vmovaps xmm10, [rsp+0xA0]
00007154327d9a19  vmovaps xmm11, [rsp+0xB0]
00007154327d9a22  vmovaps xmm12, [rsp+0xC0]
00007154327d9a2b  vmovaps xmm13, [rsp+0xD0]
00007154327d9a34  vmovaps xmm14, [rsp+0xE0]
00007154327d9a3d  add rsp, 0xF0
00007154327d9a44  pop r11
00007154327d9a46  pop r10
00007154327d9a48  pop r9
00007154327d9a4a  pop r8
00007154327d9a4c  pop rsi
00007154327d9a4d  pop rdi
00007154327d9a4e  pop rdx
00007154327d9a4f  pop rcx
00007154327d9a50  pop rax
00007154327d9a51  add rsp, 0x08
00007154327d9a55  jmp 0x00007154327D62C0
00007154327d9a5a  call 0x00007154326D64F0
00007154327d9a5f  jmp 0x00007154327D631B
00007154327d9a64  sub rsp, 0x08
00007154327d9a68  push rax
00007154327d9a69  push rcx
00007154327d9a6a  push rdx
00007154327d9a6b  push rdi
00007154327d9a6c  push rsi
00007154327d9a6d  push r8
00007154327d9a6f  push r9
00007154327d9a71  push r10
00007154327d9a73  push r11
00007154327d9a75  sub rsp, 0xF0
00007154327d9a7c  vmovaps [rsp], xmm0
00007154327d9a81  vmovaps [rsp+0x10], xmm1
00007154327d9a87  vmovaps [rsp+0x20], xmm2
00007154327d9a8d  vmovaps [rsp+0x30], xmm3
00007154327d9a93  vmovaps [rsp+0x40], xmm4
00007154327d9a99  vmovaps [rsp+0x50], xmm5
00007154327d9a9f  vmovaps [rsp+0x60], xmm6
00007154327d9aa5  vmovaps [rsp+0x70], xmm7
00007154327d9aab  vmovaps [rsp+0x80], xmm8
00007154327d9ab4  vmovaps [rsp+0x90], xmm10
00007154327d9abd  vmovaps [rsp+0xA0], xmm11
00007154327d9ac6  vmovaps [rsp+0xB0], xmm12
00007154327d9acf  vmovaps [rsp+0xC0], xmm13
00007154327d9ad8  vmovaps [rsp+0xD0], xmm14
00007154327d9ae1  vmovaps [rsp+0xE0], xmm15
00007154327d9aea  sub rsp, 0x30
00007154327d9aee  movaps [rsp], xmm9
00007154327d9af3  movaps [rsp+0x10], xmm8
00007154327d9af9  movaps [rsp+0x20], xmm11
00007154327d9aff  lea rdi, [rsp]
00007154327d9b03  mov esi, 0x00
00007154327d9b08  mov rax, 0x5A63B06A5530
00007154327d9b12  call rax
00007154327d9b14  movaps xmm9, [rsp]
00007154327d9b19  add rsp, 0x30
00007154327d9b1d  vmovaps xmm0, [rsp]
00007154327d9b22  vmovaps xmm1, [rsp+0x10]
00007154327d9b28  vmovaps xmm2, [rsp+0x20]
00007154327d9b2e  vmovaps xmm3, [rsp+0x30]
00007154327d9b34  vmovaps xmm4, [rsp+0x40]
00007154327d9b3a  vmovaps xmm5, [rsp+0x50]
00007154327d9b40  vmovaps xmm6, [rsp+0x60]
00007154327d9b46  vmovaps xmm7, [rsp+0x70]
00007154327d9b4c  vmovaps xmm8, [rsp+0x80]
00007154327d9b55  vmovaps xmm10, [rsp+0x90]
00007154327d9b5e  vmovaps xmm11, [rsp+0xA0]
00007154327d9b67  vmovaps xmm12, [rsp+0xB0]
00007154327d9b70  vmovaps xmm13, [rsp+0xC0]
00007154327d9b79  vmovaps xmm14, [rsp+0xD0]
00007154327d9b82  vmovaps xmm15, [rsp+0xE0]
00007154327d9b8b  add rsp, 0xF0
00007154327d9b92  pop r11
00007154327d9b94  pop r10
00007154327d9b96  pop r9
00007154327d9b98  pop r8
00007154327d9b9a  pop rsi
00007154327d9b9b  pop rdi
00007154327d9b9c  pop rdx
00007154327d9b9d  pop rcx
00007154327d9b9e  pop rax
00007154327d9b9f  add rsp, 0x08
00007154327d9ba3  jmp 0x00007154327D6352
00007154327d9ba8  sub rsp, 0x08
00007154327d9bac  push rax
00007154327d9bad  push rcx
00007154327d9bae  push rdx
00007154327d9baf  push rdi
00007154327d9bb0  push rsi
00007154327d9bb1  push r8
00007154327d9bb3  push r9
00007154327d9bb5  push r10
00007154327d9bb7  push r11
00007154327d9bb9  sub rsp, 0xF0
00007154327d9bc0  vmovaps [rsp], xmm0
00007154327d9bc5  vmovaps [rsp+0x10], xmm1
00007154327d9bcb  vmovaps [rsp+0x20], xmm2
00007154327d9bd1  vmovaps [rsp+0x30], xmm3
00007154327d9bd7  vmovaps [rsp+0x40], xmm4
00007154327d9bdd  vmovaps [rsp+0x50], xmm5
00007154327d9be3  vmovaps [rsp+0x60], xmm6
00007154327d9be9  vmovaps [rsp+0x70], xmm7
00007154327d9bef  vmovaps [rsp+0x80], xmm8
00007154327d9bf8  vmovaps [rsp+0x90], xmm9
00007154327d9c01  vmovaps [rsp+0xA0], xmm10
00007154327d9c0a  vmovaps [rsp+0xB0], xmm12
00007154327d9c13  vmovaps [rsp+0xC0], xmm13
00007154327d9c1c  vmovaps [rsp+0xD0], xmm14
00007154327d9c25  vmovaps [rsp+0xE0], xmm15
00007154327d9c2e  sub rsp, 0x30
00007154327d9c32  movaps [rsp], xmm11
00007154327d9c37  movaps [rsp+0x10], xmm10
00007154327d9c3d  movaps [rsp+0x20], xmm6
00007154327d9c42  lea rdi, [rsp]
00007154327d9c46  mov esi, 0x00
00007154327d9c4b  mov rax, 0x5A63B06A5530
00007154327d9c55  call rax
00007154327d9c57  movaps xmm11, [rsp]
00007154327d9c5c  add rsp, 0x30
00007154327d9c60  vmovaps xmm0, [rsp]
00007154327d9c65  vmovaps xmm1, [rsp+0x10]
00007154327d9c6b  vmovaps xmm2, [rsp+0x20]
00007154327d9c71  vmovaps xmm3, [rsp+0x30]
00007154327d9c77  vmovaps xmm4, [rsp+0x40]
00007154327d9c7d  vmovaps xmm5, [rsp+0x50]
00007154327d9c83  vmovaps xmm6, [rsp+0x60]
00007154327d9c89  vmovaps xmm7, [rsp+0x70]
00007154327d9c8f  vmovaps xmm8, [rsp+0x80]
00007154327d9c98  vmovaps xmm9, [rsp+0x90]
00007154327d9ca1  vmovaps xmm10, [rsp+0xA0]
00007154327d9caa  vmovaps xmm12, [rsp+0xB0]
00007154327d9cb3  vmovaps xmm13, [rsp+0xC0]
00007154327d9cbc  vmovaps xmm14, [rsp+0xD0]
00007154327d9cc5  vmovaps xmm15, [rsp+0xE0]
00007154327d9cce  add rsp, 0xF0
00007154327d9cd5  pop r11
00007154327d9cd7  pop r10
00007154327d9cd9  pop r9
00007154327d9cdb  pop r8
00007154327d9cdd  pop rsi
00007154327d9cde  pop rdi
00007154327d9cdf  pop rdx
00007154327d9ce0  pop rcx
00007154327d9ce1  pop rax
00007154327d9ce2  add rsp, 0x08
00007154327d9ce6  jmp 0x00007154327D636D
00007154327d9ceb  sub rsp, 0x08
00007154327d9cef  push rax
00007154327d9cf0  push rcx
00007154327d9cf1  push rdx
00007154327d9cf2  push rdi
00007154327d9cf3  push rsi
00007154327d9cf4  push r8
00007154327d9cf6  push r9
00007154327d9cf8  push r10
00007154327d9cfa  push r11
00007154327d9cfc  sub rsp, 0xF0
00007154327d9d03  vmovaps [rsp], xmm0
00007154327d9d08  vmovaps [rsp+0x10], xmm1
00007154327d9d0e  vmovaps [rsp+0x20], xmm2
00007154327d9d14  vmovaps [rsp+0x30], xmm3
00007154327d9d1a  vmovaps [rsp+0x40], xmm4
00007154327d9d20  vmovaps [rsp+0x50], xmm5
00007154327d9d26  vmovaps [rsp+0x60], xmm6
00007154327d9d2c  vmovaps [rsp+0x70], xmm7
00007154327d9d32  vmovaps [rsp+0x80], xmm8
00007154327d9d3b  vmovaps [rsp+0x90], xmm9
00007154327d9d44  vmovaps [rsp+0xA0], xmm11
00007154327d9d4d  vmovaps [rsp+0xB0], xmm12
00007154327d9d56  vmovaps [rsp+0xC0], xmm13
00007154327d9d5f  vmovaps [rsp+0xD0], xmm14
00007154327d9d68  vmovaps [rsp+0xE0], xmm15
00007154327d9d71  sub rsp, 0x30
00007154327d9d75  movaps [rsp], xmm10
00007154327d9d7a  movaps [rsp+0x10], xmm14
00007154327d9d80  movaps [rsp+0x20], xmm4
00007154327d9d85  lea rdi, [rsp]
00007154327d9d89  mov esi, 0x00
00007154327d9d8e  mov rax, 0x5A63B06A5530
00007154327d9d98  call rax
00007154327d9d9a  movaps xmm10, [rsp]
00007154327d9d9f  add rsp, 0x30
00007154327d9da3  vmovaps xmm0, [rsp]
00007154327d9da8  vmovaps xmm1, [rsp+0x10]
00007154327d9dae  vmovaps xmm2, [rsp+0x20]
00007154327d9db4  vmovaps xmm3, [rsp+0x30]
00007154327d9dba  vmovaps xmm4, [rsp+0x40]
00007154327d9dc0  vmovaps xmm5, [rsp+0x50]
00007154327d9dc6  vmovaps xmm6, [rsp+0x60]
00007154327d9dcc  vmovaps xmm7, [rsp+0x70]
00007154327d9dd2  vmovaps xmm8, [rsp+0x80]
00007154327d9ddb  vmovaps xmm9, [rsp+0x90]
00007154327d9de4  vmovaps xmm11, [rsp+0xA0]
00007154327d9ded  vmovaps xmm12, [rsp+0xB0]
00007154327d9df6  vmovaps xmm13, [rsp+0xC0]
00007154327d9dff  vmovaps xmm14, [rsp+0xD0]
00007154327d9e08  vmovaps xmm15, [rsp+0xE0]
00007154327d9e11  add rsp, 0xF0
00007154327d9e18  pop r11
00007154327d9e1a  pop r10
00007154327d9e1c  pop r9
00007154327d9e1e  pop r8
00007154327d9e20  pop rsi
00007154327d9e21  pop rdi
00007154327d9e22  pop rdx
00007154327d9e23  pop rcx
00007154327d9e24  pop rax
00007154327d9e25  add rsp, 0x08
00007154327d9e29  jmp 0x00007154327D6388
00007154327d9e2e  sub rsp, 0x08
00007154327d9e32  push rax
00007154327d9e33  push rcx
00007154327d9e34  push rdx
00007154327d9e35  push rdi
00007154327d9e36  push rsi
00007154327d9e37  push r8
00007154327d9e39  push r9
00007154327d9e3b  push r10
00007154327d9e3d  push r11
00007154327d9e3f  sub rsp, 0xF0
00007154327d9e46  vmovaps [rsp], xmm0
00007154327d9e4b  vmovaps [rsp+0x10], xmm1
00007154327d9e51  vmovaps [rsp+0x20], xmm2
00007154327d9e57  vmovaps [rsp+0x30], xmm3
00007154327d9e5d  vmovaps [rsp+0x40], xmm4
00007154327d9e63  vmovaps [rsp+0x50], xmm5
00007154327d9e69  vmovaps [rsp+0x60], xmm6
00007154327d9e6f  vmovaps [rsp+0x70], xmm7
00007154327d9e75  vmovaps [rsp+0x80], xmm9
00007154327d9e7e  vmovaps [rsp+0x90], xmm10
00007154327d9e87  vmovaps [rsp+0xA0], xmm11
00007154327d9e90  vmovaps [rsp+0xB0], xmm12
00007154327d9e99  vmovaps [rsp+0xC0], xmm13
00007154327d9ea2  vmovaps [rsp+0xD0], xmm14
00007154327d9eab  vmovaps [rsp+0xE0], xmm15
00007154327d9eb4  sub rsp, 0x30
00007154327d9eb8  movaps [rsp], xmm8
00007154327d9ebd  movaps [rsp+0x10], xmm1
00007154327d9ec2  movaps [rsp+0x20], xmm14
00007154327d9ec8  lea rdi, [rsp]
00007154327d9ecc  mov esi, 0x00
00007154327d9ed1  mov rax, 0x5A63B06A5530
00007154327d9edb  call rax
00007154327d9edd  movaps xmm8, [rsp]
00007154327d9ee2  add rsp, 0x30
00007154327d9ee6  vmovaps xmm0, [rsp]
00007154327d9eeb  vmovaps xmm1, [rsp+0x10]
00007154327d9ef1  vmovaps xmm2, [rsp+0x20]
00007154327d9ef7  vmovaps xmm3, [rsp+0x30]
00007154327d9efd  vmovaps xmm4, [rsp+0x40]
00007154327d9f03  vmovaps xmm5, [rsp+0x50]
00007154327d9f09  vmovaps xmm6, [rsp+0x60]
00007154327d9f0f  vmovaps xmm7, [rsp+0x70]
00007154327d9f15  vmovaps xmm9, [rsp+0x80]
00007154327d9f1e  vmovaps xmm10, [rsp+0x90]
00007154327d9f27  vmovaps xmm11, [rsp+0xA0]
00007154327d9f30  vmovaps xmm12, [rsp+0xB0]
00007154327d9f39  vmovaps xmm13, [rsp+0xC0]
00007154327d9f42  vmovaps xmm14, [rsp+0xD0]
00007154327d9f4b  vmovaps xmm15, [rsp+0xE0]
00007154327d9f54  add rsp, 0xF0
00007154327d9f5b  pop r11
00007154327d9f5d  pop r10
00007154327d9f5f  pop r9
00007154327d9f61  pop r8
00007154327d9f63  pop rsi
00007154327d9f64  pop rdi
00007154327d9f65  pop rdx
00007154327d9f66  pop rcx
00007154327d9f67  pop rax
00007154327d9f68  add rsp, 0x08
00007154327d9f6c  jmp 0x00007154327D63AE
00007154327d9f71  sub rsp, 0x08
00007154327d9f75  push rax
00007154327d9f76  push rcx
00007154327d9f77  push rdx
00007154327d9f78  push rdi
00007154327d9f79  push rsi
00007154327d9f7a  push r8
00007154327d9f7c  push r9
00007154327d9f7e  push r10
00007154327d9f80  push r11
00007154327d9f82  sub rsp, 0xF0
00007154327d9f89  vmovaps [rsp], xmm0
00007154327d9f8e  vmovaps [rsp+0x10], xmm1
00007154327d9f94  vmovaps [rsp+0x20], xmm2
00007154327d9f9a  vmovaps [rsp+0x30], xmm3
00007154327d9fa0  vmovaps [rsp+0x40], xmm4
00007154327d9fa6  vmovaps [rsp+0x50], xmm5
00007154327d9fac  vmovaps [rsp+0x60], xmm7
00007154327d9fb2  vmovaps [rsp+0x70], xmm8
00007154327d9fb8  vmovaps [rsp+0x80], xmm9
00007154327d9fc1  vmovaps [rsp+0x90], xmm10
00007154327d9fca  vmovaps [rsp+0xA0], xmm11
00007154327d9fd3  vmovaps [rsp+0xB0], xmm12
00007154327d9fdc  vmovaps [rsp+0xC0], xmm13
00007154327d9fe5  vmovaps [rsp+0xD0], xmm14
00007154327d9fee  vmovaps [rsp+0xE0], xmm15
00007154327d9ff7  sub rsp, 0x30
00007154327d9ffb  movaps [rsp], xmm6
00007154327d9fff  movaps [rsp+0x10], xmm1
00007154327da004  movaps [rsp+0x20], xmm14
00007154327da00a  lea rdi, [rsp]
00007154327da00e  mov esi, 0x00
00007154327da013  mov rax, 0x5A63B06A5530
00007154327da01d  call rax
00007154327da01f  movaps xmm6, [rsp]
00007154327da023  add rsp, 0x30
00007154327da027  vmovaps xmm0, [rsp]
00007154327da02c  vmovaps xmm1, [rsp+0x10]
00007154327da032  vmovaps xmm2, [rsp+0x20]
00007154327da038  vmovaps xmm3, [rsp+0x30]
00007154327da03e  vmovaps xmm4, [rsp+0x40]
00007154327da044  vmovaps xmm5, [rsp+0x50]
00007154327da04a  vmovaps xmm7, [rsp+0x60]
00007154327da050  vmovaps xmm8, [rsp+0x70]
00007154327da056  vmovaps xmm9, [rsp+0x80]
00007154327da05f  vmovaps xmm10, [rsp+0x90]
00007154327da068  vmovaps xmm11, [rsp+0xA0]
00007154327da071  vmovaps xmm12, [rsp+0xB0]
00007154327da07a  vmovaps xmm13, [rsp+0xC0]
00007154327da083  vmovaps xmm14, [rsp+0xD0]
00007154327da08c  vmovaps xmm15, [rsp+0xE0]
00007154327da095  add rsp, 0xF0
00007154327da09c  pop r11
00007154327da09e  pop r10
00007154327da0a0  pop r9
00007154327da0a2  pop r8
00007154327da0a4  pop rsi
00007154327da0a5  pop rdi
00007154327da0a6  pop rdx
00007154327da0a7  pop rcx
00007154327da0a8  pop rax
00007154327da0a9  add rsp, 0x08
00007154327da0ad  jmp 0x00007154327D63DA
00007154327da0b2  sub rsp, 0x08
00007154327da0b6  push rax
00007154327da0b7  push rcx
00007154327da0b8  push rdx
00007154327da0b9  push rdi
00007154327da0ba  push rsi
00007154327da0bb  push r8
00007154327da0bd  push r9
00007154327da0bf  push r10
00007154327da0c1  push r11
00007154327da0c3  sub rsp, 0xF0
00007154327da0ca  vmovaps [rsp], xmm0
00007154327da0cf  vmovaps [rsp+0x10], xmm1
00007154327da0d5  vmovaps [rsp+0x20], xmm2
00007154327da0db  vmovaps [rsp+0x30], xmm3
00007154327da0e1  vmovaps [rsp+0x40], xmm4
00007154327da0e7  vmovaps [rsp+0x50], xmm5
00007154327da0ed  vmovaps [rsp+0x60], xmm6
00007154327da0f3  vmovaps [rsp+0x70], xmm7
00007154327da0f9  vmovaps [rsp+0x80], xmm8
00007154327da102  vmovaps [rsp+0x90], xmm9
00007154327da10b  vmovaps [rsp+0xA0], xmm10
00007154327da114  vmovaps [rsp+0xB0], xmm11
00007154327da11d  vmovaps [rsp+0xC0], xmm12
00007154327da126  vmovaps [rsp+0xD0], xmm13
00007154327da12f  vmovaps [rsp+0xE0], xmm15
00007154327da138  sub rsp, 0x30
00007154327da13c  movaps [rsp], xmm14
00007154327da141  movaps [rsp+0x10], xmm12
00007154327da147  movaps [rsp+0x20], xmm1
00007154327da14c  lea rdi, [rsp]
00007154327da150  mov esi, 0x00
00007154327da155  mov rax, 0x5A63B06A5530
00007154327da15f  call rax
00007154327da161  movaps xmm14, [rsp]
00007154327da166  add rsp, 0x30
00007154327da16a  vmovaps xmm0, [rsp]
00007154327da16f  vmovaps xmm1, [rsp+0x10]
00007154327da175  vmovaps xmm2, [rsp+0x20]
00007154327da17b  vmovaps xmm3, [rsp+0x30]
00007154327da181  vmovaps xmm4, [rsp+0x40]
00007154327da187  vmovaps xmm5, [rsp+0x50]
00007154327da18d  vmovaps xmm6, [rsp+0x60]
00007154327da193  vmovaps xmm7, [rsp+0x70]
00007154327da199  vmovaps xmm8, [rsp+0x80]
00007154327da1a2  vmovaps xmm9, [rsp+0x90]
00007154327da1ab  vmovaps xmm10, [rsp+0xA0]
00007154327da1b4  vmovaps xmm11, [rsp+0xB0]
00007154327da1bd  vmovaps xmm12, [rsp+0xC0]
00007154327da1c6  vmovaps xmm13, [rsp+0xD0]
00007154327da1cf  vmovaps xmm15, [rsp+0xE0]
00007154327da1d8  add rsp, 0xF0
00007154327da1df  pop r11
00007154327da1e1  pop r10
00007154327da1e3  pop r9
00007154327da1e5  pop r8
00007154327da1e7  pop rsi
00007154327da1e8  pop rdi
00007154327da1e9  pop rdx
00007154327da1ea  pop rcx
00007154327da1eb  pop rax
00007154327da1ec  add rsp, 0x08
00007154327da1f0  jmp 0x00007154327D6400
00007154327da1f5  sub rsp, 0x08
00007154327da1f9  push rax
00007154327da1fa  push rcx
00007154327da1fb  push rdx
00007154327da1fc  push rdi
00007154327da1fd  push rsi
00007154327da1fe  push r8
00007154327da200  push r9
00007154327da202  push r10
00007154327da204  push r11
00007154327da206  sub rsp, 0xF0
00007154327da20d  vmovaps [rsp], xmm0
00007154327da212  vmovaps [rsp+0x10], xmm2
00007154327da218  vmovaps [rsp+0x20], xmm3
00007154327da21e  vmovaps [rsp+0x30], xmm4
00007154327da224  vmovaps [rsp+0x40], xmm5
00007154327da22a  vmovaps [rsp+0x50], xmm6
00007154327da230  vmovaps [rsp+0x60], xmm7
00007154327da236  vmovaps [rsp+0x70], xmm8
00007154327da23c  vmovaps [rsp+0x80], xmm9
00007154327da245  vmovaps [rsp+0x90], xmm10
00007154327da24e  vmovaps [rsp+0xA0], xmm11
00007154327da257  vmovaps [rsp+0xB0], xmm12
00007154327da260  vmovaps [rsp+0xC0], xmm13
00007154327da269  vmovaps [rsp+0xD0], xmm14
00007154327da272  vmovaps [rsp+0xE0], xmm15
00007154327da27b  sub rsp, 0x30
00007154327da27f  movaps [rsp], xmm1
00007154327da283  movaps [rsp+0x10], xmm13
00007154327da289  movaps [rsp+0x20], xmm9
00007154327da28f  lea rdi, [rsp]
00007154327da293  mov esi, 0x00
00007154327da298  mov rax, 0x5A63B06A5530
00007154327da2a2  call rax
00007154327da2a4  movaps xmm1, [rsp]
00007154327da2a8  add rsp, 0x30
00007154327da2ac  vmovaps xmm0, [rsp]
00007154327da2b1  vmovaps xmm2, [rsp+0x10]
00007154327da2b7  vmovaps xmm3, [rsp+0x20]
00007154327da2bd  vmovaps xmm4, [rsp+0x30]
00007154327da2c3  vmovaps xmm5, [rsp+0x40]
00007154327da2c9  vmovaps xmm6, [rsp+0x50]
00007154327da2cf  vmovaps xmm7, [rsp+0x60]
00007154327da2d5  vmovaps xmm8, [rsp+0x70]
00007154327da2db  vmovaps xmm9, [rsp+0x80]
00007154327da2e4  vmovaps xmm10, [rsp+0x90]
00007154327da2ed  vmovaps xmm11, [rsp+0xA0]
00007154327da2f6  vmovaps xmm12, [rsp+0xB0]
00007154327da2ff  vmovaps xmm13, [rsp+0xC0]
00007154327da308  vmovaps xmm14, [rsp+0xD0]
00007154327da311  vmovaps xmm15, [rsp+0xE0]
00007154327da31a  add rsp, 0xF0
00007154327da321  pop r11
00007154327da323  pop r10
00007154327da325  pop r9
00007154327da327  pop r8
00007154327da329  pop rsi
00007154327da32a  pop rdi
00007154327da32b  pop rdx
00007154327da32c  pop rcx
00007154327da32d  pop rax
00007154327da32e  add rsp, 0x08
00007154327da332  jmp 0x00007154327D641A
00007154327da337  sub rsp, 0x08
00007154327da33b  push rax
00007154327da33c  push rcx
00007154327da33d  push rdx
00007154327da33e  push rdi
00007154327da33f  push rsi
00007154327da340  push r8
00007154327da342  push r9
00007154327da344  push r10
00007154327da346  push r11
00007154327da348  sub rsp, 0xF0
00007154327da34f  vmovaps [rsp], xmm0
00007154327da354  vmovaps [rsp+0x10], xmm1
00007154327da35a  vmovaps [rsp+0x20], xmm2
00007154327da360  vmovaps [rsp+0x30], xmm3
00007154327da366  vmovaps [rsp+0x40], xmm4
00007154327da36c  vmovaps [rsp+0x50], xmm5
00007154327da372  vmovaps [rsp+0x60], xmm6
00007154327da378  vmovaps [rsp+0x70], xmm7
00007154327da37e  vmovaps [rsp+0x80], xmm8
00007154327da387  vmovaps [rsp+0x90], xmm9
00007154327da390  vmovaps [rsp+0xA0], xmm10
00007154327da399  vmovaps [rsp+0xB0], xmm11
00007154327da3a2  vmovaps [rsp+0xC0], xmm13
00007154327da3ab  vmovaps [rsp+0xD0], xmm14
00007154327da3b4  vmovaps [rsp+0xE0], xmm15
00007154327da3bd  sub rsp, 0x30
00007154327da3c1  movaps [rsp], xmm12
00007154327da3c6  movaps [rsp+0x10], xmm7
00007154327da3cb  movaps [rsp+0x20], xmm13
00007154327da3d1  lea rdi, [rsp]
00007154327da3d5  mov esi, 0x00
00007154327da3da  mov rax, 0x5A63B06A5530
00007154327da3e4  call rax
00007154327da3e6  movaps xmm12, [rsp]
00007154327da3eb  add rsp, 0x30
00007154327da3ef  vmovaps xmm0, [rsp]
00007154327da3f4  vmovaps xmm1, [rsp+0x10]
00007154327da3fa  vmovaps xmm2, [rsp+0x20]
00007154327da400  vmovaps xmm3, [rsp+0x30]
00007154327da406  vmovaps xmm4, [rsp+0x40]
00007154327da40c  vmovaps xmm5, [rsp+0x50]
00007154327da412  vmovaps xmm6, [rsp+0x60]
00007154327da418  vmovaps xmm7, [rsp+0x70]
00007154327da41e  vmovaps xmm8, [rsp+0x80]
00007154327da427  vmovaps xmm9, [rsp+0x90]
00007154327da430  vmovaps xmm10, [rsp+0xA0]
00007154327da439  vmovaps xmm11, [rsp+0xB0]
00007154327da442  vmovaps xmm13, [rsp+0xC0]
00007154327da44b  vmovaps xmm14, [rsp+0xD0]
00007154327da454  vmovaps xmm15, [rsp+0xE0]
00007154327da45d  add rsp, 0xF0
00007154327da464  pop r11
00007154327da466  pop r10
00007154327da468  pop r9
00007154327da46a  pop r8
00007154327da46c  pop rsi
00007154327da46d  pop rdi
00007154327da46e  pop rdx
00007154327da46f  pop rcx
00007154327da470  pop rax
00007154327da471  add rsp, 0x08
00007154327da475  jmp 0x00007154327D6441
00007154327da47a  sub rsp, 0x08
00007154327da47e  push rax
00007154327da47f  push rcx
00007154327da480  push rdx
00007154327da481  push rdi
00007154327da482  push rsi
00007154327da483  push r8
00007154327da485  push r9
00007154327da487  push r10
00007154327da489  push r11
00007154327da48b  sub rsp, 0xF0
00007154327da492  vmovaps [rsp], xmm0
00007154327da497  vmovaps [rsp+0x10], xmm1
00007154327da49d  vmovaps [rsp+0x20], xmm2
00007154327da4a3  vmovaps [rsp+0x30], xmm3
00007154327da4a9  vmovaps [rsp+0x40], xmm4
00007154327da4af  vmovaps [rsp+0x50], xmm5
00007154327da4b5  vmovaps [rsp+0x60], xmm6
00007154327da4bb  vmovaps [rsp+0x70], xmm7
00007154327da4c1  vmovaps [rsp+0x80], xmm8
00007154327da4ca  vmovaps [rsp+0x90], xmm9
00007154327da4d3  vmovaps [rsp+0xA0], xmm10
00007154327da4dc  vmovaps [rsp+0xB0], xmm11
00007154327da4e5  vmovaps [rsp+0xC0], xmm12
00007154327da4ee  vmovaps [rsp+0xD0], xmm14
00007154327da4f7  vmovaps [rsp+0xE0], xmm15
00007154327da500  sub rsp, 0x30
00007154327da504  movaps [rsp], xmm13
00007154327da509  movaps [rsp+0x10], xmm15
00007154327da50f  movaps [rsp+0x20], xmm8
00007154327da515  lea rdi, [rsp]
00007154327da519  mov esi, 0x00
00007154327da51e  mov rax, 0x5A63B06A5530
00007154327da528  call rax
00007154327da52a  movaps xmm13, [rsp]
00007154327da52f  add rsp, 0x30
00007154327da533  vmovaps xmm0, [rsp]
00007154327da538  vmovaps xmm1, [rsp+0x10]
00007154327da53e  vmovaps xmm2, [rsp+0x20]
00007154327da544  vmovaps xmm3, [rsp+0x30]
00007154327da54a  vmovaps xmm4, [rsp+0x40]
00007154327da550  vmovaps xmm5, [rsp+0x50]
00007154327da556  vmovaps xmm6, [rsp+0x60]
00007154327da55c  vmovaps xmm7, [rsp+0x70]
00007154327da562  vmovaps xmm8, [rsp+0x80]
00007154327da56b  vmovaps xmm9, [rsp+0x90]
00007154327da574  vmovaps xmm10, [rsp+0xA0]
00007154327da57d  vmovaps xmm11, [rsp+0xB0]
00007154327da586  vmovaps xmm12, [rsp+0xC0]
00007154327da58f  vmovaps xmm14, [rsp+0xD0]
00007154327da598  vmovaps xmm15, [rsp+0xE0]
00007154327da5a1  add rsp, 0xF0
00007154327da5a8  pop r11
00007154327da5aa  pop r10
00007154327da5ac  pop r9
00007154327da5ae  pop r8
00007154327da5b0  pop rsi
00007154327da5b1  pop rdi
00007154327da5b2  pop rdx
00007154327da5b3  pop rcx
00007154327da5b4  pop rax
00007154327da5b5  add rsp, 0x08
00007154327da5b9  jmp 0x00007154327D645C
00007154327da5be  sub rsp, 0x08
00007154327da5c2  push rax
00007154327da5c3  push rcx
00007154327da5c4  push rdx
00007154327da5c5  push rdi
00007154327da5c6  push rsi
00007154327da5c7  push r8
00007154327da5c9  push r9
00007154327da5cb  push r10
00007154327da5cd  push r11
00007154327da5cf  sub rsp, 0xF0
00007154327da5d6  vmovaps [rsp], xmm0
00007154327da5db  vmovaps [rsp+0x10], xmm1
00007154327da5e1  vmovaps [rsp+0x20], xmm2
00007154327da5e7  vmovaps [rsp+0x30], xmm3
00007154327da5ed  vmovaps [rsp+0x40], xmm4
00007154327da5f3  vmovaps [rsp+0x50], xmm5
00007154327da5f9  vmovaps [rsp+0x60], xmm6
00007154327da5ff  vmovaps [rsp+0x70], xmm7
00007154327da605  vmovaps [rsp+0x80], xmm9
00007154327da60e  vmovaps [rsp+0x90], xmm10
00007154327da617  vmovaps [rsp+0xA0], xmm11
00007154327da620  vmovaps [rsp+0xB0], xmm12
00007154327da629  vmovaps [rsp+0xC0], xmm13
00007154327da632  vmovaps [rsp+0xD0], xmm14
00007154327da63b  vmovaps [rsp+0xE0], xmm15
00007154327da644  sub rsp, 0x30
00007154327da648  movaps [rsp], xmm8
00007154327da64d  movaps [rsp+0x10], xmm15
00007154327da653  movaps [rsp+0x20], xmm9
00007154327da659  lea rdi, [rsp]
00007154327da65d  mov esi, 0x00
00007154327da662  mov rax, 0x5A63B06A5530
00007154327da66c  call rax
00007154327da66e  movaps xmm8, [rsp]
00007154327da673  add rsp, 0x30
00007154327da677  vmovaps xmm0, [rsp]
00007154327da67c  vmovaps xmm1, [rsp+0x10]
00007154327da682  vmovaps xmm2, [rsp+0x20]
00007154327da688  vmovaps xmm3, [rsp+0x30]
00007154327da68e  vmovaps xmm4, [rsp+0x40]
00007154327da694  vmovaps xmm5, [rsp+0x50]
00007154327da69a  vmovaps xmm6, [rsp+0x60]
00007154327da6a0  vmovaps xmm7, [rsp+0x70]
00007154327da6a6  vmovaps xmm9, [rsp+0x80]
00007154327da6af  vmovaps xmm10, [rsp+0x90]
00007154327da6b8  vmovaps xmm11, [rsp+0xA0]
00007154327da6c1  vmovaps xmm12, [rsp+0xB0]
00007154327da6ca  vmovaps xmm13, [rsp+0xC0]
00007154327da6d3  vmovaps xmm14, [rsp+0xD0]
00007154327da6dc  vmovaps xmm15, [rsp+0xE0]
00007154327da6e5  add rsp, 0xF0
00007154327da6ec  pop r11
00007154327da6ee  pop r10
00007154327da6f0  pop r9
00007154327da6f2  pop r8
00007154327da6f4  pop rsi
00007154327da6f5  pop rdi
00007154327da6f6  pop rdx
00007154327da6f7  pop rcx
00007154327da6f8  pop rax
00007154327da6f9  add rsp, 0x08
00007154327da6fd  jmp 0x00007154327D648A
00007154327da702  sub rsp, 0x08
00007154327da706  push rax
00007154327da707  push rcx
00007154327da708  push rdx
00007154327da709  push rdi
00007154327da70a  push rsi
00007154327da70b  push r8
00007154327da70d  push r9
00007154327da70f  push r10
00007154327da711  push r11
00007154327da713  sub rsp, 0xF0
00007154327da71a  vmovaps [rsp], xmm0
00007154327da71f  vmovaps [rsp+0x10], xmm1
00007154327da725  vmovaps [rsp+0x20], xmm2
00007154327da72b  vmovaps [rsp+0x30], xmm3
00007154327da731  vmovaps [rsp+0x40], xmm4
00007154327da737  vmovaps [rsp+0x50], xmm5
00007154327da73d  vmovaps [rsp+0x60], xmm6
00007154327da743  vmovaps [rsp+0x70], xmm7
00007154327da749  vmovaps [rsp+0x80], xmm8
00007154327da752  vmovaps [rsp+0x90], xmm9
00007154327da75b  vmovaps [rsp+0xA0], xmm10
00007154327da764  vmovaps [rsp+0xB0], xmm11
00007154327da76d  vmovaps [rsp+0xC0], xmm12
00007154327da776  vmovaps [rsp+0xD0], xmm13
00007154327da77f  vmovaps [rsp+0xE0], xmm14
00007154327da788  sub rsp, 0x30
00007154327da78c  movaps [rsp], xmm15
00007154327da791  movaps [rsp+0x10], xmm11
00007154327da797  movaps [rsp+0x20], xmm6
00007154327da79c  lea rdi, [rsp]
00007154327da7a0  mov esi, 0x00
00007154327da7a5  mov rax, 0x5A63B06A5530
00007154327da7af  call rax
00007154327da7b1  movaps xmm15, [rsp]
00007154327da7b6  add rsp, 0x30
00007154327da7ba  vmovaps xmm0, [rsp]
00007154327da7bf  vmovaps xmm1, [rsp+0x10]
00007154327da7c5  vmovaps xmm2, [rsp+0x20]
00007154327da7cb  vmovaps xmm3, [rsp+0x30]
00007154327da7d1  vmovaps xmm4, [rsp+0x40]
00007154327da7d7  vmovaps xmm5, [rsp+0x50]
00007154327da7dd  vmovaps xmm6, [rsp+0x60]
00007154327da7e3  vmovaps xmm7, [rsp+0x70]
00007154327da7e9  vmovaps xmm8, [rsp+0x80]
00007154327da7f2  vmovaps xmm9, [rsp+0x90]
00007154327da7fb  vmovaps xmm10, [rsp+0xA0]
00007154327da804  vmovaps xmm11, [rsp+0xB0]
00007154327da80d  vmovaps xmm12, [rsp+0xC0]
00007154327da816  vmovaps xmm13, [rsp+0xD0]
00007154327da81f  vmovaps xmm14, [rsp+0xE0]
00007154327da828  add rsp, 0xF0
00007154327da82f  pop r11
00007154327da831  pop r10
00007154327da833  pop r9
00007154327da835  pop r8
00007154327da837  pop rsi
00007154327da838  pop rdi
00007154327da839  pop rdx
00007154327da83a  pop rcx
00007154327da83b  pop rax
00007154327da83c  add rsp, 0x08
00007154327da840  jmp 0x00007154327D64A5
00007154327da845  sub rsp, 0x08
00007154327da849  push rax
00007154327da84a  push rcx
00007154327da84b  push rdx
00007154327da84c  push rdi
00007154327da84d  push rsi
00007154327da84e  push r8
00007154327da850  push r9
00007154327da852  push r10
00007154327da854  push r11
00007154327da856  sub rsp, 0xF0
00007154327da85d  vmovaps [rsp], xmm0
00007154327da862  vmovaps [rsp+0x10], xmm1
00007154327da868  vmovaps [rsp+0x20], xmm2
00007154327da86e  vmovaps [rsp+0x30], xmm3
00007154327da874  vmovaps [rsp+0x40], xmm4
00007154327da87a  vmovaps [rsp+0x50], xmm5
00007154327da880  vmovaps [rsp+0x60], xmm6
00007154327da886  vmovaps [rsp+0x70], xmm8
00007154327da88c  vmovaps [rsp+0x80], xmm9
00007154327da895  vmovaps [rsp+0x90], xmm10
00007154327da89e  vmovaps [rsp+0xA0], xmm11
00007154327da8a7  vmovaps [rsp+0xB0], xmm12
00007154327da8b0  vmovaps [rsp+0xC0], xmm13
00007154327da8b9  vmovaps [rsp+0xD0], xmm14
00007154327da8c2  vmovaps [rsp+0xE0], xmm15
00007154327da8cb  sub rsp, 0x30
00007154327da8cf  movaps [rsp], xmm7
00007154327da8d3  movaps [rsp+0x10], xmm11
00007154327da8d9  movaps [rsp+0x20], xmm9
00007154327da8df  lea rdi, [rsp]
00007154327da8e3  mov esi, 0x00
00007154327da8e8  mov rax, 0x5A63B06A5530
00007154327da8f2  call rax
00007154327da8f4  movaps xmm7, [rsp]
00007154327da8f8  add rsp, 0x30
00007154327da8fc  vmovaps xmm0, [rsp]
00007154327da901  vmovaps xmm1, [rsp+0x10]
00007154327da907  vmovaps xmm2, [rsp+0x20]
00007154327da90d  vmovaps xmm3, [rsp+0x30]
00007154327da913  vmovaps xmm4, [rsp+0x40]
00007154327da919  vmovaps xmm5, [rsp+0x50]
00007154327da91f  vmovaps xmm6, [rsp+0x60]
00007154327da925  vmovaps xmm8, [rsp+0x70]
00007154327da92b  vmovaps xmm9, [rsp+0x80]
00007154327da934  vmovaps xmm10, [rsp+0x90]
00007154327da93d  vmovaps xmm11, [rsp+0xA0]
00007154327da946  vmovaps xmm12, [rsp+0xB0]
00007154327da94f  vmovaps xmm13, [rsp+0xC0]
00007154327da958  vmovaps xmm14, [rsp+0xD0]
00007154327da961  vmovaps xmm15, [rsp+0xE0]
00007154327da96a  add rsp, 0xF0
00007154327da971  pop r11
00007154327da973  pop r10
00007154327da975  pop r9
00007154327da977  pop r8
00007154327da979  pop rsi
00007154327da97a  pop rdi
00007154327da97b  pop rdx
00007154327da97c  pop rcx
00007154327da97d  pop rax
00007154327da97e  add rsp, 0x08
00007154327da982  jmp 0x00007154327D64D2
00007154327da987  sub rsp, 0x08
00007154327da98b  push rax
00007154327da98c  push rcx
00007154327da98d  push rdx
00007154327da98e  push rdi
00007154327da98f  push rsi
00007154327da990  push r8
00007154327da992  push r9
00007154327da994  push r10
00007154327da996  push r11
00007154327da998  sub rsp, 0xF0
00007154327da99f  vmovaps [rsp], xmm0
00007154327da9a4  vmovaps [rsp+0x10], xmm1
00007154327da9aa  vmovaps [rsp+0x20], xmm2
00007154327da9b0  vmovaps [rsp+0x30], xmm3
00007154327da9b6  vmovaps [rsp+0x40], xmm4
00007154327da9bc  vmovaps [rsp+0x50], xmm5
00007154327da9c2  vmovaps [rsp+0x60], xmm6
00007154327da9c8  vmovaps [rsp+0x70], xmm7
00007154327da9ce  vmovaps [rsp+0x80], xmm8
00007154327da9d7  vmovaps [rsp+0x90], xmm9
00007154327da9e0  vmovaps [rsp+0xA0], xmm10
00007154327da9e9  vmovaps [rsp+0xB0], xmm12
00007154327da9f2  vmovaps [rsp+0xC0], xmm13
00007154327da9fb  vmovaps [rsp+0xD0], xmm14
00007154327daa04  vmovaps [rsp+0xE0], xmm15
00007154327daa0d  sub rsp, 0x30
00007154327daa11  movaps [rsp], xmm11
00007154327daa16  movaps [rsp+0x10], xmm10
00007154327daa1c  movaps [rsp+0x20], xmm14
00007154327daa22  lea rdi, [rsp]
00007154327daa26  mov esi, 0x00
00007154327daa2b  mov rax, 0x5A63B06A5530
00007154327daa35  call rax
00007154327daa37  movaps xmm11, [rsp]
00007154327daa3c  add rsp, 0x30
00007154327daa40  vmovaps xmm0, [rsp]
00007154327daa45  vmovaps xmm1, [rsp+0x10]
00007154327daa4b  vmovaps xmm2, [rsp+0x20]
00007154327daa51  vmovaps xmm3, [rsp+0x30]
00007154327daa57  vmovaps xmm4, [rsp+0x40]
00007154327daa5d  vmovaps xmm5, [rsp+0x50]
00007154327daa63  vmovaps xmm6, [rsp+0x60]
00007154327daa69  vmovaps xmm7, [rsp+0x70]
00007154327daa6f  vmovaps xmm8, [rsp+0x80]
00007154327daa78  vmovaps xmm9, [rsp+0x90]
00007154327daa81  vmovaps xmm10, [rsp+0xA0]
00007154327daa8a  vmovaps xmm12, [rsp+0xB0]
00007154327daa93  vmovaps xmm13, [rsp+0xC0]
00007154327daa9c  vmovaps xmm14, [rsp+0xD0]
00007154327daaa5  vmovaps xmm15, [rsp+0xE0]
00007154327daaae  add rsp, 0xF0
00007154327daab5  pop r11
00007154327daab7  pop r10
00007154327daab9  pop r9
00007154327daabb  pop r8
00007154327daabd  pop rsi
00007154327daabe  pop rdi
00007154327daabf  pop rdx
00007154327daac0  pop rcx
00007154327daac1  pop rax
00007154327daac2  add rsp, 0x08
00007154327daac6  jmp 0x00007154327D64ED
00007154327daacb  call 0x00007154326E45A0
00007154327daad0  jmp 0x00007154327D64F7
00007154327daad5  sub rsp, 0x08
00007154327daad9  push rax
00007154327daada  push rcx
00007154327daadb  push rdx
00007154327daadc  push rdi
00007154327daadd  push rsi
00007154327daade  push r8
00007154327daae0  push r9
00007154327daae2  push r10
00007154327daae4  push r11
00007154327daae6  sub rsp, 0xF0
00007154327daaed  vmovaps [rsp], xmm0
00007154327daaf2  vmovaps [rsp+0x10], xmm1
00007154327daaf8  vmovaps [rsp+0x20], xmm2
00007154327daafe  vmovaps [rsp+0x30], xmm3
00007154327dab04  vmovaps [rsp+0x40], xmm4
00007154327dab0a  vmovaps [rsp+0x50], xmm5
00007154327dab10  vmovaps [rsp+0x60], xmm6
00007154327dab16  vmovaps [rsp+0x70], xmm7
00007154327dab1c  vmovaps [rsp+0x80], xmm8
00007154327dab25  vmovaps [rsp+0x90], xmm9
00007154327dab2e  vmovaps [rsp+0xA0], xmm11
00007154327dab37  vmovaps [rsp+0xB0], xmm12
00007154327dab40  vmovaps [rsp+0xC0], xmm13
00007154327dab49  vmovaps [rsp+0xD0], xmm14
00007154327dab52  vmovaps [rsp+0xE0], xmm15
00007154327dab5b  sub rsp, 0x30
00007154327dab5f  movaps [rsp], xmm10
00007154327dab64  movaps [rsp+0x10], xmm1
00007154327dab69  movaps [rsp+0x20], xmm12
00007154327dab6f  lea rdi, [rsp]
00007154327dab73  mov esi, 0x00
00007154327dab78  mov rax, 0x5A63B06A5530
00007154327dab82  call rax
00007154327dab84  movaps xmm10, [rsp]
00007154327dab89  add rsp, 0x30
00007154327dab8d  vmovaps xmm0, [rsp]
00007154327dab92  vmovaps xmm1, [rsp+0x10]
00007154327dab98  vmovaps xmm2, [rsp+0x20]
00007154327dab9e  vmovaps xmm3, [rsp+0x30]
00007154327daba4  vmovaps xmm4, [rsp+0x40]
00007154327dabaa  vmovaps xmm5, [rsp+0x50]
00007154327dabb0  vmovaps xmm6, [rsp+0x60]
00007154327dabb6  vmovaps xmm7, [rsp+0x70]
00007154327dabbc  vmovaps xmm8, [rsp+0x80]
00007154327dabc5  vmovaps xmm9, [rsp+0x90]
00007154327dabce  vmovaps xmm11, [rsp+0xA0]
00007154327dabd7  vmovaps xmm12, [rsp+0xB0]
00007154327dabe0  vmovaps xmm13, [rsp+0xC0]
00007154327dabe9  vmovaps xmm14, [rsp+0xD0]
00007154327dabf2  vmovaps xmm15, [rsp+0xE0]
00007154327dabfb  add rsp, 0xF0
00007154327dac02  pop r11
00007154327dac04  pop r10
00007154327dac06  pop r9
00007154327dac08  pop r8
00007154327dac0a  pop rsi
00007154327dac0b  pop rdi
00007154327dac0c  pop rdx
00007154327dac0d  pop rcx
00007154327dac0e  pop rax
00007154327dac0f  add rsp, 0x08
00007154327dac13  jmp 0x00007154327D651A
00007154327dac18  sub rsp, 0x08
00007154327dac1c  push rax
00007154327dac1d  push rcx
00007154327dac1e  push rdx
00007154327dac1f  push rdi
00007154327dac20  push rsi
00007154327dac21  push r8
00007154327dac23  push r9
00007154327dac25  push r10
00007154327dac27  push r11
00007154327dac29  sub rsp, 0xF0
00007154327dac30  vmovaps [rsp], xmm0
00007154327dac35  vmovaps [rsp+0x10], xmm1
00007154327dac3b  vmovaps [rsp+0x20], xmm2
00007154327dac41  vmovaps [rsp+0x30], xmm3
00007154327dac47  vmovaps [rsp+0x40], xmm4
00007154327dac4d  vmovaps [rsp+0x50], xmm5
00007154327dac53  vmovaps [rsp+0x60], xmm6
00007154327dac59  vmovaps [rsp+0x70], xmm7
00007154327dac5f  vmovaps [rsp+0x80], xmm8
00007154327dac68  vmovaps [rsp+0x90], xmm9
00007154327dac71  vmovaps [rsp+0xA0], xmm10
00007154327dac7a  vmovaps [rsp+0xB0], xmm11
00007154327dac83  vmovaps [rsp+0xC0], xmm13
00007154327dac8c  vmovaps [rsp+0xD0], xmm14
00007154327dac95  vmovaps [rsp+0xE0], xmm15
00007154327dac9e  sub rsp, 0x30
00007154327daca2  movaps [rsp], xmm12
00007154327daca7  movaps [rsp+0x10], xmm14
00007154327dacad  movaps [rsp+0x20], xmm1
00007154327dacb2  lea rdi, [rsp]
00007154327dacb6  mov esi, 0x00
00007154327dacbb  mov rax, 0x5A63B06A5530
00007154327dacc5  call rax
00007154327dacc7  movaps xmm12, [rsp]
00007154327daccc  add rsp, 0x30
00007154327dacd0  vmovaps xmm0, [rsp]
00007154327dacd5  vmovaps xmm1, [rsp+0x10]
00007154327dacdb  vmovaps xmm2, [rsp+0x20]
00007154327dace1  vmovaps xmm3, [rsp+0x30]
00007154327dace7  vmovaps xmm4, [rsp+0x40]
00007154327daced  vmovaps xmm5, [rsp+0x50]
00007154327dacf3  vmovaps xmm6, [rsp+0x60]
00007154327dacf9  vmovaps xmm7, [rsp+0x70]
00007154327dacff  vmovaps xmm8, [rsp+0x80]
00007154327dad08  vmovaps xmm9, [rsp+0x90]
00007154327dad11  vmovaps xmm10, [rsp+0xA0]
00007154327dad1a  vmovaps xmm11, [rsp+0xB0]
00007154327dad23  vmovaps xmm13, [rsp+0xC0]
00007154327dad2c  vmovaps xmm14, [rsp+0xD0]
00007154327dad35  vmovaps xmm15, [rsp+0xE0]
00007154327dad3e  add rsp, 0xF0
00007154327dad45  pop r11
00007154327dad47  pop r10
00007154327dad49  pop r9
00007154327dad4b  pop r8
00007154327dad4d  pop rsi
00007154327dad4e  pop rdi
00007154327dad4f  pop rdx
00007154327dad50  pop rcx
00007154327dad51  pop rax
00007154327dad52  add rsp, 0x08
00007154327dad56  jmp 0x00007154327D6549
00007154327dad5b  sub rsp, 0x08
00007154327dad5f  push rax
00007154327dad60  push rcx
00007154327dad61  push rdx
00007154327dad62  push rdi
00007154327dad63  push rsi
00007154327dad64  push r8
00007154327dad66  push r9
00007154327dad68  push r10
00007154327dad6a  push r11
00007154327dad6c  sub rsp, 0xF0
00007154327dad73  vmovaps [rsp], xmm0
00007154327dad78  vmovaps [rsp+0x10], xmm1
00007154327dad7e  vmovaps [rsp+0x20], xmm2
00007154327dad84  vmovaps [rsp+0x30], xmm3
00007154327dad8a  vmovaps [rsp+0x40], xmm4
00007154327dad90  vmovaps [rsp+0x50], xmm5
00007154327dad96  vmovaps [rsp+0x60], xmm6
00007154327dad9c  vmovaps [rsp+0x70], xmm7
00007154327dada2  vmovaps [rsp+0x80], xmm8
00007154327dadab  vmovaps [rsp+0x90], xmm9
00007154327dadb4  vmovaps [rsp+0xA0], xmm10
00007154327dadbd  vmovaps [rsp+0xB0], xmm11
00007154327dadc6  vmovaps [rsp+0xC0], xmm12
00007154327dadcf  vmovaps [rsp+0xD0], xmm13
00007154327dadd8  vmovaps [rsp+0xE0], xmm15
00007154327dade1  sub rsp, 0x30
00007154327dade5  movaps [rsp], xmm14
00007154327dadea  movaps [rsp+0x10], xmm9
00007154327dadf0  movaps [rsp+0x20], xmm1
00007154327dadf5  lea rdi, [rsp]
00007154327dadf9  mov esi, 0x00
00007154327dadfe  mov rax, 0x5A63B06A5530
00007154327dae08  call rax
00007154327dae0a  movaps xmm14, [rsp]
00007154327dae0f  add rsp, 0x30
00007154327dae13  vmovaps xmm0, [rsp]
00007154327dae18  vmovaps xmm1, [rsp+0x10]
00007154327dae1e  vmovaps xmm2, [rsp+0x20]
00007154327dae24  vmovaps xmm3, [rsp+0x30]
00007154327dae2a  vmovaps xmm4, [rsp+0x40]
00007154327dae30  vmovaps xmm5, [rsp+0x50]
00007154327dae36  vmovaps xmm6, [rsp+0x60]
00007154327dae3c  vmovaps xmm7, [rsp+0x70]
00007154327dae42  vmovaps xmm8, [rsp+0x80]
00007154327dae4b  vmovaps xmm9, [rsp+0x90]
00007154327dae54  vmovaps xmm10, [rsp+0xA0]
00007154327dae5d  vmovaps xmm11, [rsp+0xB0]
00007154327dae66  vmovaps xmm12, [rsp+0xC0]
00007154327dae6f  vmovaps xmm13, [rsp+0xD0]
00007154327dae78  vmovaps xmm15, [rsp+0xE0]
00007154327dae81  add rsp, 0xF0
00007154327dae88  pop r11
00007154327dae8a  pop r10
00007154327dae8c  pop r9
00007154327dae8e  pop r8
00007154327dae90  pop rsi
00007154327dae91  pop rdi
00007154327dae92  pop rdx
00007154327dae93  pop rcx
00007154327dae94  pop rax
00007154327dae95  add rsp, 0x08
00007154327dae99  jmp 0x00007154327D6578
00007154327dae9e  sub rsp, 0x08
00007154327daea2  push rax
00007154327daea3  push rcx
00007154327daea4  push rdx
00007154327daea5  push rdi
00007154327daea6  push rsi
00007154327daea7  push r8
00007154327daea9  push r9
00007154327daeab  push r10
00007154327daead  push r11
00007154327daeaf  sub rsp, 0xF0
00007154327daeb6  vmovaps [rsp], xmm0
00007154327daebb  vmovaps [rsp+0x10], xmm2
00007154327daec1  vmovaps [rsp+0x20], xmm3
00007154327daec7  vmovaps [rsp+0x30], xmm4
00007154327daecd  vmovaps [rsp+0x40], xmm5
00007154327daed3  vmovaps [rsp+0x50], xmm6
00007154327daed9  vmovaps [rsp+0x60], xmm7
00007154327daedf  vmovaps [rsp+0x70], xmm8
00007154327daee5  vmovaps [rsp+0x80], xmm9
00007154327daeee  vmovaps [rsp+0x90], xmm10
00007154327daef7  vmovaps [rsp+0xA0], xmm11
00007154327daf00  vmovaps [rsp+0xB0], xmm12
00007154327daf09  vmovaps [rsp+0xC0], xmm13
00007154327daf12  vmovaps [rsp+0xD0], xmm14
00007154327daf1b  vmovaps [rsp+0xE0], xmm15
00007154327daf24  sub rsp, 0x30
00007154327daf28  movaps [rsp], xmm1
00007154327daf2c  movaps [rsp+0x10], xmm13
00007154327daf32  movaps [rsp+0x20], xmm8
00007154327daf38  lea rdi, [rsp]
00007154327daf3c  mov esi, 0x00
00007154327daf41  mov rax, 0x5A63B06A5530
00007154327daf4b  call rax
00007154327daf4d  movaps xmm1, [rsp]
00007154327daf51  add rsp, 0x30
00007154327daf55  vmovaps xmm0, [rsp]
00007154327daf5a  vmovaps xmm2, [rsp+0x10]
00007154327daf60  vmovaps xmm3, [rsp+0x20]
00007154327daf66  vmovaps xmm4, [rsp+0x30]
00007154327daf6c  vmovaps xmm5, [rsp+0x40]
00007154327daf72  vmovaps xmm6, [rsp+0x50]
00007154327daf78  vmovaps xmm7, [rsp+0x60]
00007154327daf7e  vmovaps xmm8, [rsp+0x70]
00007154327daf84  vmovaps xmm9, [rsp+0x80]
00007154327daf8d  vmovaps xmm10, [rsp+0x90]
00007154327daf96  vmovaps xmm11, [rsp+0xA0]
00007154327daf9f  vmovaps xmm12, [rsp+0xB0]
00007154327dafa8  vmovaps xmm13, [rsp+0xC0]
00007154327dafb1  vmovaps xmm14, [rsp+0xD0]
00007154327dafba  vmovaps xmm15, [rsp+0xE0]
00007154327dafc3  add rsp, 0xF0
00007154327dafca  pop r11
00007154327dafcc  pop r10
00007154327dafce  pop r9
00007154327dafd0  pop r8
00007154327dafd2  pop rsi
00007154327dafd3  pop rdi
00007154327dafd4  pop rdx
00007154327dafd5  pop rcx
00007154327dafd6  pop rax
00007154327dafd7  add rsp, 0x08
00007154327dafdb  jmp 0x00007154327D659A
00007154327dafe0  call 0x000071543260C260
00007154327dafe5  jmp 0x00007154327D65A8
00007154327dafea  call 0x00007154326DE950
00007154327dafef  jmp 0x00007154327D65B2
00007154327daff4  sub rsp, 0x08
00007154327daff8  push rax
00007154327daff9  push rcx
00007154327daffa  push rdx
00007154327daffb  push rdi
00007154327daffc  push rsi
00007154327daffd  push r8
00007154327dafff  push r9
00007154327db001  push r10
00007154327db003  push r11
00007154327db005  sub rsp, 0xF0
00007154327db00c  vmovaps [rsp], xmm0
00007154327db011  vmovaps [rsp+0x10], xmm1
00007154327db017  vmovaps [rsp+0x20], xmm2
00007154327db01d  vmovaps [rsp+0x30], xmm3
00007154327db023  vmovaps [rsp+0x40], xmm4
00007154327db029  vmovaps [rsp+0x50], xmm5
00007154327db02f  vmovaps [rsp+0x60], xmm6
00007154327db035  vmovaps [rsp+0x70], xmm7
00007154327db03b  vmovaps [rsp+0x80], xmm9
00007154327db044  vmovaps [rsp+0x90], xmm10
00007154327db04d  vmovaps [rsp+0xA0], xmm11
00007154327db056  vmovaps [rsp+0xB0], xmm12
00007154327db05f  vmovaps [rsp+0xC0], xmm13
00007154327db068  vmovaps [rsp+0xD0], xmm14
00007154327db071  vmovaps [rsp+0xE0], xmm15
00007154327db07a  sub rsp, 0x30
00007154327db07e  movaps [rsp], xmm8
00007154327db083  movaps [rsp+0x10], xmm15
00007154327db089  movaps [rsp+0x20], xmm7
00007154327db08e  lea rdi, [rsp]
00007154327db092  mov esi, 0x00
00007154327db097  mov rax, 0x5A63B06A5530
00007154327db0a1  call rax
00007154327db0a3  movaps xmm8, [rsp]
00007154327db0a8  add rsp, 0x30
00007154327db0ac  vmovaps xmm0, [rsp]
00007154327db0b1  vmovaps xmm1, [rsp+0x10]
00007154327db0b7  vmovaps xmm2, [rsp+0x20]
00007154327db0bd  vmovaps xmm3, [rsp+0x30]
00007154327db0c3  vmovaps xmm4, [rsp+0x40]
00007154327db0c9  vmovaps xmm5, [rsp+0x50]
00007154327db0cf  vmovaps xmm6, [rsp+0x60]
00007154327db0d5  vmovaps xmm7, [rsp+0x70]
00007154327db0db  vmovaps xmm9, [rsp+0x80]
00007154327db0e4  vmovaps xmm10, [rsp+0x90]
00007154327db0ed  vmovaps xmm11, [rsp+0xA0]
00007154327db0f6  vmovaps xmm12, [rsp+0xB0]
00007154327db0ff  vmovaps xmm13, [rsp+0xC0]
00007154327db108  vmovaps xmm14, [rsp+0xD0]
00007154327db111  vmovaps xmm15, [rsp+0xE0]
00007154327db11a  add rsp, 0xF0
00007154327db121  pop r11
00007154327db123  pop r10
00007154327db125  pop r9
00007154327db127  pop r8
00007154327db129  pop rsi
00007154327db12a  pop rdi
00007154327db12b  pop rdx
00007154327db12c  pop rcx
00007154327db12d  pop rax
00007154327db12e  add rsp, 0x08
00007154327db132  jmp 0x00007154327D65D4
00007154327db137  sub rsp, 0x08
00007154327db13b  push rax
00007154327db13c  push rcx
00007154327db13d  push rdx
00007154327db13e  push rdi
00007154327db13f  push rsi
00007154327db140  push r8
00007154327db142  push r9
00007154327db144  push r10
00007154327db146  push r11
00007154327db148  sub rsp, 0xF0
00007154327db14f  vmovaps [rsp], xmm0
00007154327db154  vmovaps [rsp+0x10], xmm1
00007154327db15a  vmovaps [rsp+0x20], xmm2
00007154327db160  vmovaps [rsp+0x30], xmm3
00007154327db166  vmovaps [rsp+0x40], xmm4
00007154327db16c  vmovaps [rsp+0x50], xmm5
00007154327db172  vmovaps [rsp+0x60], xmm6
00007154327db178  vmovaps [rsp+0x70], xmm8
00007154327db17e  vmovaps [rsp+0x80], xmm9
00007154327db187  vmovaps [rsp+0x90], xmm10
00007154327db190  vmovaps [rsp+0xA0], xmm11
00007154327db199  vmovaps [rsp+0xB0], xmm12
00007154327db1a2  vmovaps [rsp+0xC0], xmm13
00007154327db1ab  vmovaps [rsp+0xD0], xmm14
00007154327db1b4  vmovaps [rsp+0xE0], xmm15
00007154327db1bd  sub rsp, 0x30
00007154327db1c1  movaps [rsp], xmm7
00007154327db1c5  movaps [rsp+0x10], xmm9
00007154327db1cb  movaps [rsp+0x20], xmm15
00007154327db1d1  lea rdi, [rsp]
00007154327db1d5  mov esi, 0x00
00007154327db1da  mov rax, 0x5A63B06A5530
00007154327db1e4  call rax
00007154327db1e6  movaps xmm7, [rsp]
00007154327db1ea  add rsp, 0x30
00007154327db1ee  vmovaps xmm0, [rsp]
00007154327db1f3  vmovaps xmm1, [rsp+0x10]
00007154327db1f9  vmovaps xmm2, [rsp+0x20]
00007154327db1ff  vmovaps xmm3, [rsp+0x30]
00007154327db205  vmovaps xmm4, [rsp+0x40]
00007154327db20b  vmovaps xmm5, [rsp+0x50]
00007154327db211  vmovaps xmm6, [rsp+0x60]
00007154327db217  vmovaps xmm8, [rsp+0x70]
00007154327db21d  vmovaps xmm9, [rsp+0x80]
00007154327db226  vmovaps xmm10, [rsp+0x90]
00007154327db22f  vmovaps xmm11, [rsp+0xA0]
00007154327db238  vmovaps xmm12, [rsp+0xB0]
00007154327db241  vmovaps xmm13, [rsp+0xC0]
00007154327db24a  vmovaps xmm14, [rsp+0xD0]
00007154327db253  vmovaps xmm15, [rsp+0xE0]
00007154327db25c  add rsp, 0xF0
00007154327db263  pop r11
00007154327db265  pop r10
00007154327db267  pop r9
00007154327db269  pop r8
00007154327db26b  pop rsi
00007154327db26c  pop rdi
00007154327db26d  pop rdx
00007154327db26e  pop rcx
00007154327db26f  pop rax
00007154327db270  add rsp, 0x08
00007154327db274  jmp 0x00007154327D6601
00007154327db279  sub rsp, 0x08
00007154327db27d  push rax
00007154327db27e  push rcx
00007154327db27f  push rdx
00007154327db280  push rdi
00007154327db281  push rsi
00007154327db282  push r8
00007154327db284  push r9
00007154327db286  push r10
00007154327db288  push r11
00007154327db28a  sub rsp, 0xF0
00007154327db291  vmovaps [rsp], xmm0
00007154327db296  vmovaps [rsp+0x10], xmm1
00007154327db29c  vmovaps [rsp+0x20], xmm2
00007154327db2a2  vmovaps [rsp+0x30], xmm3
00007154327db2a8  vmovaps [rsp+0x40], xmm4
00007154327db2ae  vmovaps [rsp+0x50], xmm5
00007154327db2b4  vmovaps [rsp+0x60], xmm6
00007154327db2ba  vmovaps [rsp+0x70], xmm7
00007154327db2c0  vmovaps [rsp+0x80], xmm8
00007154327db2c9  vmovaps [rsp+0x90], xmm10
00007154327db2d2  vmovaps [rsp+0xA0], xmm11
00007154327db2db  vmovaps [rsp+0xB0], xmm12
00007154327db2e4  vmovaps [rsp+0xC0], xmm13
00007154327db2ed  vmovaps [rsp+0xD0], xmm14
00007154327db2f6  vmovaps [rsp+0xE0], xmm15
00007154327db2ff  sub rsp, 0x30
00007154327db303  movaps [rsp], xmm9
00007154327db308  movaps [rsp+0x10], xmm13
00007154327db30e  movaps [rsp+0x20], xmm15
00007154327db314  lea rdi, [rsp]
00007154327db318  mov esi, 0x00
00007154327db31d  mov rax, 0x5A63B06A5530
00007154327db327  call rax
00007154327db329  movaps xmm9, [rsp]
00007154327db32e  add rsp, 0x30
00007154327db332  vmovaps xmm0, [rsp]
00007154327db337  vmovaps xmm1, [rsp+0x10]
00007154327db33d  vmovaps xmm2, [rsp+0x20]
00007154327db343  vmovaps xmm3, [rsp+0x30]
00007154327db349  vmovaps xmm4, [rsp+0x40]
00007154327db34f  vmovaps xmm5, [rsp+0x50]
00007154327db355  vmovaps xmm6, [rsp+0x60]
00007154327db35b  vmovaps xmm7, [rsp+0x70]
00007154327db361  vmovaps xmm8, [rsp+0x80]
00007154327db36a  vmovaps xmm10, [rsp+0x90]
00007154327db373  vmovaps xmm11, [rsp+0xA0]
00007154327db37c  vmovaps xmm12, [rsp+0xB0]
00007154327db385  vmovaps xmm13, [rsp+0xC0]
00007154327db38e  vmovaps xmm14, [rsp+0xD0]
00007154327db397  vmovaps xmm15, [rsp+0xE0]
00007154327db3a0  add rsp, 0xF0
00007154327db3a7  pop r11
00007154327db3a9  pop r10
00007154327db3ab  pop r9
00007154327db3ad  pop r8
00007154327db3af  pop rsi
00007154327db3b0  pop rdi
00007154327db3b1  pop rdx
00007154327db3b2  pop rcx
00007154327db3b3  pop rax
00007154327db3b4  add rsp, 0x08
00007154327db3b8  jmp 0x00007154327D662F
00007154327db3bd  sub rsp, 0x08
00007154327db3c1  push rax
00007154327db3c2  push rcx
00007154327db3c3  push rdx
00007154327db3c4  push rdi
00007154327db3c5  push rsi
00007154327db3c6  push r8
00007154327db3c8  push r9
00007154327db3ca  push r10
00007154327db3cc  push r11
00007154327db3ce  sub rsp, 0xF0
00007154327db3d5  vmovaps [rsp], xmm0
00007154327db3da  vmovaps [rsp+0x10], xmm1
00007154327db3e0  vmovaps [rsp+0x20], xmm2
00007154327db3e6  vmovaps [rsp+0x30], xmm3
00007154327db3ec  vmovaps [rsp+0x40], xmm4
00007154327db3f2  vmovaps [rsp+0x50], xmm5
00007154327db3f8  vmovaps [rsp+0x60], xmm6
00007154327db3fe  vmovaps [rsp+0x70], xmm7
00007154327db404  vmovaps [rsp+0x80], xmm8
00007154327db40d  vmovaps [rsp+0x90], xmm9
00007154327db416  vmovaps [rsp+0xA0], xmm10
00007154327db41f  vmovaps [rsp+0xB0], xmm11
00007154327db428  vmovaps [rsp+0xC0], xmm12
00007154327db431  vmovaps [rsp+0xD0], xmm13
00007154327db43a  vmovaps [rsp+0xE0], xmm14
00007154327db443  sub rsp, 0x30
00007154327db447  movaps [rsp], xmm15
00007154327db44c  movaps [rsp+0x10], xmm11
00007154327db452  movaps [rsp+0x20], xmm12
00007154327db458  lea rdi, [rsp]
00007154327db45c  mov esi, 0x00
00007154327db461  mov rax, 0x5A63B06A5530
00007154327db46b  call rax
00007154327db46d  movaps xmm15, [rsp]
00007154327db472  add rsp, 0x30
00007154327db476  vmovaps xmm0, [rsp]
00007154327db47b  vmovaps xmm1, [rsp+0x10]
00007154327db481  vmovaps xmm2, [rsp+0x20]
00007154327db487  vmovaps xmm3, [rsp+0x30]
00007154327db48d  vmovaps xmm4, [rsp+0x40]
00007154327db493  vmovaps xmm5, [rsp+0x50]
00007154327db499  vmovaps xmm6, [rsp+0x60]
00007154327db49f  vmovaps xmm7, [rsp+0x70]
00007154327db4a5  vmovaps xmm8, [rsp+0x80]
00007154327db4ae  vmovaps xmm9, [rsp+0x90]
00007154327db4b7  vmovaps xmm10, [rsp+0xA0]
00007154327db4c0  vmovaps xmm11, [rsp+0xB0]
00007154327db4c9  vmovaps xmm12, [rsp+0xC0]
00007154327db4d2  vmovaps xmm13, [rsp+0xD0]
00007154327db4db  vmovaps xmm14, [rsp+0xE0]
00007154327db4e4  add rsp, 0xF0
00007154327db4eb  pop r11
00007154327db4ed  pop r10
00007154327db4ef  pop r9
00007154327db4f1  pop r8
00007154327db4f3  pop rsi
00007154327db4f4  pop rdi
00007154327db4f5  pop rdx
00007154327db4f6  pop rcx
00007154327db4f7  pop rax
00007154327db4f8  add rsp, 0x08
00007154327db4fc  jmp 0x00007154327D664A
00007154327db501  sub rsp, 0x08
00007154327db505  push rax
00007154327db506  push rcx
00007154327db507  push rdx
00007154327db508  push rdi
00007154327db509  push rsi
00007154327db50a  push r8
00007154327db50c  push r9
00007154327db50e  push r10
00007154327db510  push r11
00007154327db512  sub rsp, 0xF0
00007154327db519  vmovaps [rsp], xmm0
00007154327db51e  vmovaps [rsp+0x10], xmm1
00007154327db524  vmovaps [rsp+0x20], xmm2
00007154327db52a  vmovaps [rsp+0x30], xmm3
00007154327db530  vmovaps [rsp+0x40], xmm4
00007154327db536  vmovaps [rsp+0x50], xmm5
00007154327db53c  vmovaps [rsp+0x60], xmm6
00007154327db542  vmovaps [rsp+0x70], xmm7
00007154327db548  vmovaps [rsp+0x80], xmm8
00007154327db551  vmovaps [rsp+0x90], xmm9
00007154327db55a  vmovaps [rsp+0xA0], xmm10
00007154327db563  vmovaps [rsp+0xB0], xmm11
00007154327db56c  vmovaps [rsp+0xC0], xmm12
00007154327db575  vmovaps [rsp+0xD0], xmm14
00007154327db57e  vmovaps [rsp+0xE0], xmm15
00007154327db587  sub rsp, 0x30
00007154327db58b  movaps [rsp], xmm13
00007154327db590  movaps [rsp+0x10], xmm10
00007154327db596  movaps [rsp+0x20], xmm14
00007154327db59c  lea rdi, [rsp]
00007154327db5a0  mov esi, 0x00
00007154327db5a5  mov rax, 0x5A63B06A5530
00007154327db5af  call rax
00007154327db5b1  movaps xmm13, [rsp]
00007154327db5b6  add rsp, 0x30
00007154327db5ba  vmovaps xmm0, [rsp]
00007154327db5bf  vmovaps xmm1, [rsp+0x10]
00007154327db5c5  vmovaps xmm2, [rsp+0x20]
00007154327db5cb  vmovaps xmm3, [rsp+0x30]
00007154327db5d1  vmovaps xmm4, [rsp+0x40]
00007154327db5d7  vmovaps xmm5, [rsp+0x50]
00007154327db5dd  vmovaps xmm6, [rsp+0x60]
00007154327db5e3  vmovaps xmm7, [rsp+0x70]
00007154327db5e9  vmovaps xmm8, [rsp+0x80]
00007154327db5f2  vmovaps xmm9, [rsp+0x90]
00007154327db5fb  vmovaps xmm10, [rsp+0xA0]
00007154327db604  vmovaps xmm11, [rsp+0xB0]
00007154327db60d  vmovaps xmm12, [rsp+0xC0]
00007154327db616  vmovaps xmm14, [rsp+0xD0]
00007154327db61f  vmovaps xmm15, [rsp+0xE0]
00007154327db628  add rsp, 0xF0
00007154327db62f  pop r11
00007154327db631  pop r10
00007154327db633  pop r9
00007154327db635  pop r8
00007154327db637  pop rsi
00007154327db638  pop rdi
00007154327db639  pop rdx
00007154327db63a  pop rcx
00007154327db63b  pop rax
00007154327db63c  add rsp, 0x08
00007154327db640  jmp 0x00007154327D666D
00007154327db645  sub rsp, 0x08
00007154327db649  push rax
00007154327db64a  push rcx
00007154327db64b  push rdx
00007154327db64c  push rdi
00007154327db64d  push rsi
00007154327db64e  push r8
00007154327db650  push r9
00007154327db652  push r10
00007154327db654  push r11
00007154327db656  sub rsp, 0xF0
00007154327db65d  vmovaps [rsp], xmm0
00007154327db662  vmovaps [rsp+0x10], xmm1
00007154327db668  vmovaps [rsp+0x20], xmm2
00007154327db66e  vmovaps [rsp+0x30], xmm3
00007154327db674  vmovaps [rsp+0x40], xmm4
00007154327db67a  vmovaps [rsp+0x50], xmm5
00007154327db680  vmovaps [rsp+0x60], xmm6
00007154327db686  vmovaps [rsp+0x70], xmm7
00007154327db68c  vmovaps [rsp+0x80], xmm8
00007154327db695  vmovaps [rsp+0x90], xmm9
00007154327db69e  vmovaps [rsp+0xA0], xmm10
00007154327db6a7  vmovaps [rsp+0xB0], xmm11
00007154327db6b0  vmovaps [rsp+0xC0], xmm12
00007154327db6b9  vmovaps [rsp+0xD0], xmm13
00007154327db6c2  vmovaps [rsp+0xE0], xmm15
00007154327db6cb  sub rsp, 0x30
00007154327db6cf  movaps [rsp], xmm14
00007154327db6d4  movaps [rsp+0x10], xmm1
00007154327db6d9  movaps [rsp+0x20], xmm7
00007154327db6de  lea rdi, [rsp]
00007154327db6e2  mov esi, 0x00
00007154327db6e7  mov rax, 0x5A63B06A5530
00007154327db6f1  call rax
00007154327db6f3  movaps xmm14, [rsp]
00007154327db6f8  add rsp, 0x30
00007154327db6fc  vmovaps xmm0, [rsp]
00007154327db701  vmovaps xmm1, [rsp+0x10]
00007154327db707  vmovaps xmm2, [rsp+0x20]
00007154327db70d  vmovaps xmm3, [rsp+0x30]
00007154327db713  vmovaps xmm4, [rsp+0x40]
00007154327db719  vmovaps xmm5, [rsp+0x50]
00007154327db71f  vmovaps xmm6, [rsp+0x60]
00007154327db725  vmovaps xmm7, [rsp+0x70]
00007154327db72b  vmovaps xmm8, [rsp+0x80]
00007154327db734  vmovaps xmm9, [rsp+0x90]
00007154327db73d  vmovaps xmm10, [rsp+0xA0]
00007154327db746  vmovaps xmm11, [rsp+0xB0]
00007154327db74f  vmovaps xmm12, [rsp+0xC0]
00007154327db758  vmovaps xmm13, [rsp+0xD0]
00007154327db761  vmovaps xmm15, [rsp+0xE0]
00007154327db76a  add rsp, 0xF0
00007154327db771  pop r11
00007154327db773  pop r10
00007154327db775  pop r9
00007154327db777  pop r8
00007154327db779  pop rsi
00007154327db77a  pop rdi
00007154327db77b  pop rdx
00007154327db77c  pop rcx
00007154327db77d  pop rax
00007154327db77e  add rsp, 0x08
00007154327db782  jmp 0x00007154327D6690
00007154327db787  sub rsp, 0x08
00007154327db78b  push rax
00007154327db78c  push rcx
00007154327db78d  push rdx
00007154327db78e  push rdi
00007154327db78f  push rsi
00007154327db790  push r8
00007154327db792  push r9
00007154327db794  push r10
00007154327db796  push r11
00007154327db798  sub rsp, 0xF0
00007154327db79f  vmovaps [rsp], xmm0
00007154327db7a4  vmovaps [rsp+0x10], xmm2
00007154327db7aa  vmovaps [rsp+0x20], xmm3
00007154327db7b0  vmovaps [rsp+0x30], xmm4
00007154327db7b6  vmovaps [rsp+0x40], xmm5
00007154327db7bc  vmovaps [rsp+0x50], xmm6
00007154327db7c2  vmovaps [rsp+0x60], xmm7
00007154327db7c8  vmovaps [rsp+0x70], xmm8
00007154327db7ce  vmovaps [rsp+0x80], xmm9
00007154327db7d7  vmovaps [rsp+0x90], xmm10
00007154327db7e0  vmovaps [rsp+0xA0], xmm11
00007154327db7e9  vmovaps [rsp+0xB0], xmm12
00007154327db7f2  vmovaps [rsp+0xC0], xmm13
00007154327db7fb  vmovaps [rsp+0xD0], xmm14
00007154327db804  vmovaps [rsp+0xE0], xmm15
00007154327db80d  sub rsp, 0x30
00007154327db811  movaps [rsp], xmm1
00007154327db815  movaps [rsp+0x10], xmm8
00007154327db81b  movaps [rsp+0x20], xmm9
00007154327db821  lea rdi, [rsp]
00007154327db825  mov esi, 0x00
00007154327db82a  mov rax, 0x5A63B06A5530
00007154327db834  call rax
00007154327db836  movaps xmm1, [rsp]
00007154327db83a  add rsp, 0x30
00007154327db83e  vmovaps xmm0, [rsp]
00007154327db843  vmovaps xmm2, [rsp+0x10]
00007154327db849  vmovaps xmm3, [rsp+0x20]
00007154327db84f  vmovaps xmm4, [rsp+0x30]
00007154327db855  vmovaps xmm5, [rsp+0x40]
00007154327db85b  vmovaps xmm6, [rsp+0x50]
00007154327db861  vmovaps xmm7, [rsp+0x60]
00007154327db867  vmovaps xmm8, [rsp+0x70]
00007154327db86d  vmovaps xmm9, [rsp+0x80]
00007154327db876  vmovaps xmm10, [rsp+0x90]
00007154327db87f  vmovaps xmm11, [rsp+0xA0]
00007154327db888  vmovaps xmm12, [rsp+0xB0]
00007154327db891  vmovaps xmm13, [rsp+0xC0]
00007154327db89a  vmovaps xmm14, [rsp+0xD0]
00007154327db8a3  vmovaps xmm15, [rsp+0xE0]
00007154327db8ac  add rsp, 0xF0
00007154327db8b3  pop r11
00007154327db8b5  pop r10
00007154327db8b7  pop r9
00007154327db8b9  pop r8
00007154327db8bb  pop rsi
00007154327db8bc  pop rdi
00007154327db8bd  pop rdx
00007154327db8be  pop rcx
00007154327db8bf  pop rax
00007154327db8c0  add rsp, 0x08
00007154327db8c4  jmp 0x00007154327D66B2
00007154327db8c9  call 0x00007154326B3E40
00007154327db8ce  jmp 0x00007154327D66C0
00007154327db8d3  call 0x000071543260C380
00007154327db8d8  jmp 0x00007154327D66CA
00007154327db8dd  call 0x000071543260D600
00007154327db8e2  jmp 0x00007154327D66D4
00007154327db8e7  call 0x00007154325FF540
00007154327db8ec  jmp 0x00007154327D66DE
00007154327db8f1  int3
00007154327db8f2  nop [rax+rax*1], ax
00007154327db8fb  nop [rax+rax*1], eax
00007154327db900  mov eax, [r15+0x48]
00007154327db904  lea r14d, [eax+0x01]
00007154327db909  mov [rsp+0x10], r14d
00007154327db90e  mov r14d, r14d
00007154327db911  mov [r15+0x48], r14
00007154327db915  xor eax, eax
00007154327db917  mov r14d, [rsp+0x10]
00007154327db91c  cmp r14d, 0x1F4
00007154327db923  cmc
00007154327db924  lahf
00007154327db925  seto al
00007154327db928  mov [r15+0x108], eax
00007154327db92f  mov eax, [r15+0x108]
00007154327db936  sahf
00007154327db937  jnz 0x00007154327DB969
00007154327db939  cmp dword ptr [r15+0x318], 0x00
00007154327db941  jz 0x00007154327E1AB0
00007154327db947  nop [rax+rax*1], ax
00007154327db950  nop [rax+rax*1], eax
00007154327db958  mov eax, 0x410450
00007154327db95d  mov [r15+0x100], rax
00007154327db964  jmp 0x00007154325FE110
00007154327db969  cmp dword ptr [r15+0x318], 0x00
00007154327db971  jz 0x00007154327DB9A0
00007154327db977  nop [rax+rax*1], ax
00007154327db980  nop [rax+rax*1], eax
00007154327db988  mov eax, 0x410274
00007154327db98d  mov [r15+0x100], rax
00007154327db994  jmp 0x00007154325FE110
00007154327db999  int3
00007154327db99a  int3
00007154327db99b  nop [rax+rax*1], eax
00007154327db9a0  mov rax, [r15+0x40]
00007154327db9a4  movaps xmm1, [r15+0x1D0]
00007154327db9ac  vmovaps [rsp+0x10], xmm1
00007154327db9b2  vmovaps xmm15, [rsp+0x10]
00007154327db9b8  por xmm1, xmm15
00007154327db9bd  movaps xmm14, [r15+0x1A0]
00007154327db9c5  vmovaps [rsp+0x10], xmm14
00007154327db9cb  vmovaps xmm13, [rsp+0x10]
00007154327db9d1  por xmm14, xmm13
00007154327db9d6  lea r14, [rax+0x30]
00007154327db9da  mov r12, [r13+r14*1]
00007154327db9df  lea r14, [rax+0x38]
00007154327db9e3  mov r11, [r13+r14*1]
00007154327db9e8  movq xmm13, r12
00007154327db9ed  movq xmm12, r11
00007154327db9f2  movq xmm13, xmm13
00007154327db9f7  vmovaps [rsp+0x10], xmm13
00007154327db9fd  movq xmm13, xmm13
00007154327dba02  movaps [r15+0x130], xmm13
00007154327dba0a  movq xmm12, xmm12
00007154327dba0f  vmovaps [rsp+0x20], xmm12
00007154327dba15  movq xmm12, xmm12
00007154327dba1a  movaps [r15+0x280], xmm12
00007154327dba22  movaps xmm13, [r15+0x270]
00007154327dba2a  vmovaps [rsp+0x30], xmm13
00007154327dba30  vmovaps xmm12, [rsp+0x30]
00007154327dba36  por xmm13, xmm12
00007154327dba3b  lea r14, [rax+0x20]
00007154327dba3f  mov r12, [r13+r14*1]
00007154327dba44  lea r14, [rax+0x28]
00007154327dba48  mov r11, [r13+r14*1]
00007154327dba4d  movq xmm12, r12
00007154327dba52  movq xmm11, r11
00007154327dba57  movq xmm12, xmm12
00007154327dba5c  vmovaps [rsp+0x30], xmm12
00007154327dba62  movq xmm12, xmm12
00007154327dba67  movaps [r15+0x150], xmm12
00007154327dba6f  movq xmm11, xmm11
00007154327dba74  vmovaps [rsp+0x40], xmm11
00007154327dba7a  movq xmm11, xmm11
00007154327dba7f  movaps [r15+0x140], xmm11
00007154327dba87  lea r14, [rax+0x10]
00007154327dba8b  mov r12, [r13+r14*1]
00007154327dba90  lea r14, [rax+0x18]
00007154327dba94  mov r11, [r13+r14*1]
00007154327dba99  movq xmm12, r12
00007154327dba9e  movq xmm11, r11
00007154327dbaa3  movq xmm12, xmm12
00007154327dbaa8  vmovaps [rsp+0x50], xmm12
00007154327dbaae  movq xmm12, xmm12
00007154327dbab3  movaps [r15+0x170], xmm12
00007154327dbabb  movq xmm11, xmm11
00007154327dbac0  vmovaps [rsp+0x60], xmm11
00007154327dbac6  movq xmm11, xmm11
00007154327dbacb  movaps [r15+0x160], xmm11
00007154327dbad3  mov r14, [r13+rax*1]
00007154327dbad8  vmovq xmm12, r14
00007154327dbadd  vpbroadcastq xmm12, xmm12
00007154327dbae2  lea r14, [rax+0x08]
00007154327dbae6  mov rax, [r13+r14*1]
00007154327dbaeb  movq xmm11, rax
00007154327dbaf0  movaps [r15+0x230], xmm11
00007154327dbaf8  mov rax, [r15+0xF8]
00007154327dbaff  lea r14, [rax+0x50]
00007154327dbb03  movups xmm11, [r13+r14*1]
00007154327dbb09  lea r14, [rax+0x60]
00007154327dbb0d  movups xmm10, [r13+r14*1]
00007154327dbb13  lea r14, [rax+0x30]
00007154327dbb17  movups xmm9, [r13+r14*1]
00007154327dbb1d  mov r14, [r15+0x50]
00007154327dbb21  mov [r15+0x60], r14
00007154327dbb25  mov qword ptr [r15+0x58], 0x40
00007154327dbb2d  movaps xmm8, xmm12
00007154327dbb31  mulpd xmm8, xmm15
00007154327dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007154327dbb3c  ptest xmm7, xmm7
00007154327dbb41  jnz 0x00007154327DC96A
00007154327dbb47  movq xmm15, qword ptr [r15+0x230]
00007154327dbb50  vmovaps [rsp+0x70], xmm15
00007154327dbb56  vpermilpd xmm15, xmm15, 0x00
00007154327dbb5c  movaps xmm7, xmm9
00007154327dbb60  mulpd xmm7, xmm15
00007154327dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007154327dbb6a  ptest xmm6, xmm6
00007154327dbb6f  jnz 0x00007154327DCAAE
00007154327dbb75  vxorps xmm15, xmm15, xmm15
00007154327dbb7a  vpbroadcastq xmm15, xmm15
00007154327dbb7f  movaps xmm9, xmm12
00007154327dbb83  mulpd xmm9, xmm10
00007154327dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007154327dbb8e  ptest xmm6, xmm6
00007154327dbb93  jnz 0x00007154327DCBF0
00007154327dbb99  movaps xmm10, xmm12
00007154327dbb9d  mulpd xmm10, xmm11
00007154327dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007154327dbba8  ptest xmm6, xmm6
00007154327dbbad  jnz 0x00007154327DCD34
00007154327dbbb3  movaps xmm11, [r15+0x1F0]
00007154327dbbbb  movaps xmm6, xmm12
00007154327dbbbf  mulpd xmm6, xmm11
00007154327dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007154327dbbc9  ptest xmm5, xmm5
00007154327dbbce  jnz 0x00007154327DCE78
00007154327dbbd4  movaps xmm12, [r15+0x2A0]
00007154327dbbdc  vmovaps [rsp+0x80], xmm12
00007154327dbbe5  vmovaps xmm11, [rsp+0x80]
00007154327dbbee  por xmm12, xmm11
00007154327dbbf3  movaps xmm11, [r15+0x250]
00007154327dbbfb  vmovaps [rsp+0x80], xmm11
00007154327dbc04  vmovaps xmm5, [rsp+0x80]
00007154327dbc0d  por xmm11, xmm5
00007154327dbc12  vmovaps xmm4, [rsp+0x70]
00007154327dbc18  vpermilpd xmm4, xmm4, 0x00
00007154327dbc1e  movaps xmm3, xmm5
00007154327dbc21  mulpd xmm3, xmm4
00007154327dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007154327dbc2a  ptest xmm2, xmm2
00007154327dbc2f  jnz 0x00007154327DCFBA
00007154327dbc35  mov [rsp+0x80], rax
00007154327dbc3d  xor eax, eax
00007154327dbc3f  mov r12d, 0x40
00007154327dbc45  mov r11d, 0x200
00007154327dbc4b  cmp r12, r11
00007154327dbc4e  cmc
00007154327dbc4f  lahf
00007154327dbc50  seto al
00007154327dbc53  mov [r15+0x108], eax
00007154327dbc5a  movaps xmm5, xmm8
00007154327dbc5e  addpd xmm5, xmm15
00007154327dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007154327dbc68  ptest xmm4, xmm4
00007154327dbc6d  jnz 0x00007154327DD0FA
00007154327dbc73  movaps xmm8, [r15+0x1B0]
00007154327dbc7b  movaps xmm4, xmm9
00007154327dbc7f  addpd xmm4, xmm8
00007154327dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007154327dbc89  ptest xmm2, xmm2
00007154327dbc8e  jnz 0x00007154327DD23C
00007154327dbc94  movaps xmm9, xmm10
00007154327dbc98  addpd xmm9, xmm8
00007154327dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007154327dbca3  ptest xmm2, xmm2
00007154327dbca8  jnz 0x00007154327DD37E
00007154327dbcae  movaps xmm10, [r15+0x2F0]
00007154327dbcb6  vmovaps [rsp+0x90], xmm10
00007154327dbcbf  vmovaps xmm8, [rsp+0x90]
00007154327dbcc8  por xmm10, xmm8
00007154327dbccd  movaps xmm8, [r15+0x2E0]
00007154327dbcd5  vmovaps [rsp+0x90], xmm8
00007154327dbcde  vmovaps xmm2, [rsp+0x90]
00007154327dbce7  por xmm8, xmm2
00007154327dbcec  movaps xmm2, [r15+0x2D0]
00007154327dbcf4  vmovaps [rsp+0x90], xmm2
00007154327dbcfd  vmovaps [rsp+0xA0], xmm1
00007154327dbd06  vmovaps xmm1, [rsp+0x90]
00007154327dbd0f  por xmm2, xmm1
00007154327dbd13  movaps xmm1, [r15+0x200]
00007154327dbd1b  vmovaps [rsp+0x90], xmm1
00007154327dbd24  vmovaps [rsp+0xB0], xmm15
00007154327dbd2d  vmovaps xmm15, [rsp+0x90]
00007154327dbd36  por xmm1, xmm15
00007154327dbd3b  movaps xmm15, [r15+0x1C0]
00007154327dbd43  vmovaps [rsp+0x90], xmm15
00007154327dbd4c  vmovaps [rsp+0xC0], xmm1
00007154327dbd55  vmovaps xmm1, [rsp+0x90]
00007154327dbd5e  por xmm15, xmm1
00007154327dbd63  movaps xmm1, [r15+0x190]
00007154327dbd6b  vmovaps [rsp+0x90], xmm1
00007154327dbd74  vmovaps [rsp+0xD0], xmm15
00007154327dbd7d  vmovaps xmm15, [rsp+0x90]
00007154327dbd86  por xmm1, xmm15
00007154327dbd8b  movaps xmm15, [r15+0x300]
00007154327dbd93  vmovaps [rsp+0x90], xmm15
00007154327dbd9c  vmovaps [rsp+0xE0], xmm1
00007154327dbda5  vmovaps xmm1, [rsp+0x90]
00007154327dbdae  por xmm15, xmm1
00007154327dbdb3  mov rax, [rsp+0x80]
00007154327dbdbb  lea r12, [rax+0xA0]
00007154327dbdc2  movups xmm1, [r13+r12*1]
00007154327dbdc8  lea r12, [rax+0xB0]
00007154327dbdcf  vmovaps [rsp+0x80], xmm1
00007154327dbdd8  movups xmm1, [r13+r12*1]
00007154327dbdde  vmovaps [rsp+0x90], xmm1
00007154327dbde7  vmovaps [rsp+0xF0], xmm15
00007154327dbdf0  vmovaps xmm15, [rsp+0xB0]
00007154327dbdf9  vmovaps [rsp+0xB0], xmm14
00007154327dbe02  movaps xmm1, xmm6
00007154327dbe05  addpd xmm1, xmm15
00007154327dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007154327dbe0f  ptest xmm14, xmm14
00007154327dbe15  jnz 0x00007154327DD4D6
00007154327dbe1b  lea r12, [rax+0xF0]
00007154327dbe22  movups xmm15, [r13+r12*1]
00007154327dbe28  movaps xmm14, xmm4
00007154327dbe2c  addpd xmm14, xmm3
00007154327dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007154327dbe37  ptest xmm6, xmm6
00007154327dbe3c  jnz 0x00007154327DD621
00007154327dbe42  movaps xmm6, xmm9
00007154327dbe46  addpd xmm6, xmm7
00007154327dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007154327dbe4f  ptest xmm4, xmm4
00007154327dbe54  jnz 0x00007154327DD763
00007154327dbe5a  vmovaps xmm9, [rsp+0x70]
00007154327dbe60  vpermilpd xmm9, xmm9, 0x00
00007154327dbe66  vmovaps xmm4, [rsp+0x90]
00007154327dbe6f  movaps xmm7, xmm4
00007154327dbe72  mulpd xmm7, xmm9
00007154327dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007154327dbe7c  ptest xmm3, xmm3
00007154327dbe81  jnz 0x00007154327DD8A4
00007154327dbe87  vmovaps xmm9, [rsp+0x50]
00007154327dbe8d  vpermilpd xmm9, xmm9, 0x00
00007154327dbe93  movaps xmm4, xmm15
00007154327dbe97  mulpd xmm4, xmm9
00007154327dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007154327dbea1  ptest xmm3, xmm3
00007154327dbea6  jnz 0x00007154327DD9E5
00007154327dbeac  lea r12, [rax+0xE0]
00007154327dbeb3  movups xmm15, [r13+r12*1]
00007154327dbeb9  vmovaps xmm9, [rsp+0x70]
00007154327dbebf  vpermilpd xmm9, xmm9, 0x00
00007154327dbec5  vmovaps [rsp+0x70], xmm1
00007154327dbecb  vmovaps xmm1, [rsp+0x80]
00007154327dbed4  vmovaps [rsp+0x80], xmm15
00007154327dbedd  movaps xmm3, xmm1
00007154327dbee0  mulpd xmm3, xmm9
00007154327dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007154327dbeea  ptest xmm15, xmm15
00007154327dbef0  jnz 0x00007154327DDB31
00007154327dbef6  vmovaps xmm1, [rsp+0xF0]
00007154327dbeff  vmovaps xmm15, [rsp+0xF0]
00007154327dbf08  por xmm1, xmm15
00007154327dbf0d  movaps [r15+0x300], xmm1
00007154327dbf15  vmovaps xmm15, [rsp+0xE0]
00007154327dbf1e  vmovaps xmm9, [rsp+0xE0]
00007154327dbf27  por xmm15, xmm9
00007154327dbf2c  movaps [r15+0x190], xmm15
00007154327dbf34  vmovaps xmm9, [rsp+0x50]
00007154327dbf3a  vpermilpd xmm9, xmm9, 0x00
00007154327dbf40  vmovaps [rsp+0x90], xmm1
00007154327dbf49  vmovaps [rsp+0xE0], xmm15
00007154327dbf52  vmovaps xmm15, [rsp+0x80]
00007154327dbf5b  vmovaps [rsp+0x80], xmm14
00007154327dbf64  movaps xmm1, xmm15
00007154327dbf68  mulpd xmm1, xmm9
00007154327dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007154327dbf72  ptest xmm14, xmm14
00007154327dbf78  jnz 0x00007154327DDC72
00007154327dbf7e  lea r12, [rax+0x90]
00007154327dbf85  movups xmm15, [r13+r12*1]
00007154327dbf8b  vmovaps xmm14, [rsp+0xD0]
00007154327dbf94  vmovaps xmm9, [rsp+0xD0]
00007154327dbf9d  por xmm14, xmm9
00007154327dbfa2  movaps [r15+0x1C0], xmm14
00007154327dbfaa  vmovaps xmm9, [rsp+0xC0]
00007154327dbfb3  vmovaps [rsp+0xD0], xmm1
00007154327dbfbc  vmovaps xmm1, [rsp+0xC0]
00007154327dbfc5  por xmm9, xmm1
00007154327dbfca  movaps [r15+0x200], xmm9
00007154327dbfd2  vmovaps [rsp+0xC0], xmm2
00007154327dbfdb  vmovaps xmm1, [rsp+0xC0]
00007154327dbfe4  por xmm2, xmm1
00007154327dbfe8  movaps [r15+0x2D0], xmm2
00007154327dbff0  vmovaps [rsp+0xC0], xmm8
00007154327dbff9  vmovaps xmm1, [rsp+0xC0]
00007154327dc002  por xmm8, xmm1
00007154327dc007  movaps [r15+0x2E0], xmm8
00007154327dc00f  vmovaps [rsp+0xC0], xmm15
00007154327dc018  movaps xmm1, xmm5
00007154327dc01b  addpd xmm1, xmm7
00007154327dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007154327dc024  ptest xmm15, xmm15
00007154327dc02a  jnz 0x00007154327DDDBE
00007154327dc030  vmovaps xmm15, [rsp+0x50]
00007154327dc036  vpermilpd xmm15, xmm15, 0x00
00007154327dc03c  vmovaps xmm5, [rsp+0xC0]
00007154327dc045  vmovaps [rsp+0xC0], xmm1
00007154327dc04e  movaps xmm7, xmm5
00007154327dc051  mulpd xmm7, xmm15
00007154327dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007154327dc05b  ptest xmm1, xmm1
00007154327dc060  jnz 0x00007154327DDEFE
00007154327dc066  lea r12, [rax+0x80]
00007154327dc06d  movups xmm1, [r13+r12*1]
00007154327dc073  vmovaps xmm5, [rsp+0x70]
00007154327dc079  vmovaps [rsp+0x70], xmm1
00007154327dc07f  movaps xmm15, xmm5
00007154327dc083  addpd xmm15, xmm3
00007154327dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007154327dc08e  ptest xmm1, xmm1
00007154327dc093  jnz 0x00007154327DE049
00007154327dc099  vmovaps xmm5, [rsp+0x80]
00007154327dc0a2  movaps xmm1, xmm5
00007154327dc0a5  addpd xmm1, xmm4
00007154327dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007154327dc0ae  ptest xmm3, xmm3
00007154327dc0b3  jnz 0x00007154327DE18B
00007154327dc0b9  vmovaps [rsp+0x80], xmm10
00007154327dc0c2  vmovaps xmm5, [rsp+0x80]
00007154327dc0cb  por xmm10, xmm5
00007154327dc0d0  movaps [r15+0x2F0], xmm10
00007154327dc0d8  vmovaps xmm5, [rsp+0x50]
00007154327dc0de  vpermilpd xmm5, xmm5, 0x00
00007154327dc0e4  vmovaps xmm3, [rsp+0x70]
00007154327dc0ea  vmovaps [rsp+0x50], xmm1
00007154327dc0f0  movaps xmm4, xmm3
00007154327dc0f3  mulpd xmm4, xmm5
00007154327dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007154327dc0fc  ptest xmm1, xmm1
00007154327dc101  jnz 0x00007154327DE2CB
00007154327dc107  lea r12, [rax+0xD0]
00007154327dc10e  movups xmm1, [r13+r12*1]
00007154327dc114  vmovaps xmm3, [rsp+0xD0]
00007154327dc11d  vmovaps [rsp+0x70], xmm1
00007154327dc123  movaps xmm5, xmm6
00007154327dc126  addpd xmm5, xmm3
00007154327dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007154327dc12f  ptest xmm1, xmm1
00007154327dc134  jnz 0x00007154327DE415
00007154327dc13a  vmovaps xmm1, [rsp+0x60]
00007154327dc140  vpermilpd xmm1, xmm1, 0x00
00007154327dc146  movaps xmm6, xmm9
00007154327dc14a  mulpd xmm6, xmm1
00007154327dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007154327dc153  ptest xmm3, xmm3
00007154327dc158  jnz 0x00007154327DE555
00007154327dc15e  movaps [r15+0x260], xmm6
00007154327dc166  vxorps xmm1, xmm1, xmm1
00007154327dc16a  vpbroadcastq xmm1, xmm1
00007154327dc16f  movaps [r15+0x1B0], xmm1
00007154327dc177  vmovaps xmm1, [rsp+0x60]
00007154327dc17d  vpermilpd xmm1, xmm1, 0x00
00007154327dc183  vmovaps xmm3, [rsp+0x70]
00007154327dc189  vmovaps [rsp+0x70], xmm15
00007154327dc18f  movaps xmm9, xmm3
00007154327dc193  mulpd xmm9, xmm1
00007154327dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007154327dc19e  ptest xmm15, xmm15
00007154327dc1a4  jnz 0x00007154327DE696
00007154327dc1aa  lea r12, [rax+0xC0]
00007154327dc1b1  movups xmm1, [r13+r12*1]
00007154327dc1b7  vmovaps xmm3, [rsp+0xC0]
00007154327dc1c0  vmovaps [rsp+0x80], xmm1
00007154327dc1c9  movaps xmm15, xmm3
00007154327dc1cd  addpd xmm15, xmm7
00007154327dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007154327dc1d8  ptest xmm1, xmm1
00007154327dc1dd  jnz 0x00007154327DE7E2
00007154327dc1e3  vmovaps [rsp+0xC0], xmm13
00007154327dc1ec  vmovaps xmm1, [rsp+0xC0]
00007154327dc1f5  por xmm13, xmm1
00007154327dc1fa  movaps [r15+0x270], xmm13
00007154327dc202  vmovaps xmm1, [rsp+0xB0]
00007154327dc20b  vmovaps xmm7, [rsp+0xB0]
00007154327dc214  por xmm1, xmm7
00007154327dc218  movaps [r15+0x1A0], xmm1
00007154327dc220  vmovaps xmm1, [rsp+0x60]
00007154327dc226  vpermilpd xmm1, xmm1, 0x00
00007154327dc22c  vmovaps [rsp+0xB0], xmm1
00007154327dc235  vmovaps xmm1, [rsp+0x80]
00007154327dc23e  vmovaps [rsp+0x80], xmm15
00007154327dc247  vmovaps xmm15, [rsp+0xB0]
00007154327dc250  vmovaps [rsp+0xB0], xmm14
00007154327dc259  movaps xmm3, xmm1
00007154327dc25c  mulpd xmm3, xmm15
00007154327dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007154327dc266  ptest xmm14, xmm14
00007154327dc26c  jnz 0x00007154327DE924
00007154327dc272  lea r12, [rax+0x20]
00007154327dc276  movups xmm1, [r13+r12*1]
00007154327dc27c  movaps [r15+0x110], xmm1
00007154327dc284  vmovaps xmm14, [rsp+0x70]
00007154327dc28a  vmovaps [rsp+0x70], xmm1
00007154327dc290  movaps xmm15, xmm14
00007154327dc294  addpd xmm15, xmm4
00007154327dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007154327dc29f  ptest xmm1, xmm1
00007154327dc2a4  jnz 0x00007154327DEA6F
00007154327dc2aa  vmovaps xmm1, [rsp+0x60]
00007154327dc2b0  vpermilpd xmm1, xmm1, 0x00
00007154327dc2b6  movaps xmm14, xmm2
00007154327dc2ba  mulpd xmm14, xmm1
00007154327dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007154327dc2c5  ptest xmm4, xmm4
00007154327dc2ca  jnz 0x00007154327DEBB2
00007154327dc2d0  vmovaps xmm4, [rsp+0x50]
00007154327dc2d6  movaps xmm1, xmm4
00007154327dc2d9  addpd xmm1, xmm9
00007154327dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007154327dc2e3  ptest xmm2, xmm2
00007154327dc2e8  jnz 0x00007154327DECF4
00007154327dc2ee  vmovaps xmm9, [rsp+0x30]
00007154327dc2f4  vpermilpd xmm9, xmm9, 0x00
00007154327dc2fa  vmovaps xmm2, [rsp+0x70]
00007154327dc300  vmovaps [rsp+0x50], xmm1
00007154327dc306  movaps xmm4, xmm2
00007154327dc309  mulpd xmm4, xmm9
00007154327dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007154327dc313  ptest xmm1, xmm1
00007154327dc318  jnz 0x00007154327DEE35
00007154327dc31e  vmovaps xmm1, [rsp+0x30]
00007154327dc324  vpermilpd xmm1, xmm1, 0x00
00007154327dc32a  vmovaps xmm2, [rsp+0x90]
00007154327dc333  vmovaps [rsp+0x60], xmm15
00007154327dc339  movaps xmm9, xmm2
00007154327dc33d  mulpd xmm9, xmm1
00007154327dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007154327dc348  ptest xmm15, xmm15
00007154327dc34e  jnz 0x00007154327DEF76
00007154327dc354  vmovaps xmm15, [rsp+0x80]
00007154327dc35d  movaps xmm1, xmm15
00007154327dc361  addpd xmm1, xmm6
00007154327dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007154327dc36a  ptest xmm2, xmm2
00007154327dc36f  jnz 0x00007154327DF0B8
00007154327dc375  movaps xmm15, xmm5
00007154327dc379  addpd xmm15, xmm3
00007154327dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007154327dc384  ptest xmm6, xmm6
00007154327dc389  jnz 0x00007154327DF1F9
00007154327dc38f  vmovaps xmm6, [rsp+0x30]
00007154327dc395  vpermilpd xmm6, xmm6, 0x00
00007154327dc39b  movaps xmm5, xmm8
00007154327dc39f  mulpd xmm5, xmm6
00007154327dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007154327dc3a8  ptest xmm3, xmm3
00007154327dc3ad  jnz 0x00007154327DF33B
00007154327dc3b3  vmovaps xmm8, [rsp+0x30]
00007154327dc3b9  vpermilpd xmm8, xmm8, 0x00
00007154327dc3bf  movaps xmm6, xmm10
00007154327dc3c3  mulpd xmm6, xmm8
00007154327dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007154327dc3cd  ptest xmm3, xmm3
00007154327dc3d2  jnz 0x00007154327DF47C
00007154327dc3d8  vmovaps xmm8, [rsp+0x60]
00007154327dc3de  movaps xmm10, xmm8
00007154327dc3e2  addpd xmm10, xmm14
00007154327dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007154327dc3ed  ptest xmm3, xmm3
00007154327dc3f2  jnz 0x00007154327DF5BE
00007154327dc3f8  vmovaps xmm8, [rsp+0x50]
00007154327dc3fe  movaps xmm14, xmm8
00007154327dc402  addpd xmm14, xmm4
00007154327dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007154327dc40d  ptest xmm3, xmm3
00007154327dc412  jnz 0x00007154327DF702
00007154327dc418  vmovaps xmm8, [rsp+0x40]
00007154327dc41e  vpermilpd xmm8, xmm8, 0x00
00007154327dc424  movaps xmm4, xmm13
00007154327dc428  mulpd xmm4, xmm8
00007154327dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007154327dc432  ptest xmm3, xmm3
00007154327dc437  jnz 0x00007154327DF845
00007154327dc43d  movaps xmm13, xmm15
00007154327dc441  addpd xmm13, xmm9
00007154327dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007154327dc44c  ptest xmm8, xmm8
00007154327dc452  jnz 0x00007154327DF987
00007154327dc458  movaps xmm15, xmm1
00007154327dc45c  addpd xmm15, xmm5
00007154327dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007154327dc467  ptest xmm9, xmm9
00007154327dc46d  jnz 0x00007154327DFACB
00007154327dc473  vmovaps [rsp+0x30], xmm11
00007154327dc479  vmovaps xmm1, [rsp+0x30]
00007154327dc47f  por xmm11, xmm1
00007154327dc484  movaps [r15+0x250], xmm11
00007154327dc48c  vmovaps [rsp+0x30], xmm12
00007154327dc492  vmovaps xmm1, [rsp+0x30]
00007154327dc498  por xmm12, xmm1
00007154327dc49d  movaps [r15+0x2A0], xmm12
00007154327dc4a5  vmovaps xmm1, [rsp+0xA0]
00007154327dc4ae  vmovaps xmm11, [rsp+0xA0]
00007154327dc4b7  por xmm1, xmm11
00007154327dc4bc  movaps [r15+0x1D0], xmm1
00007154327dc4c4  lea r12, [rax+0x40]
00007154327dc4c8  movups xmm1, [r13+r12*1]
00007154327dc4ce  movaps [r15+0x2C0], xmm1
00007154327dc4d6  vmovaps xmm11, [rsp+0x40]
00007154327dc4dc  vpermilpd xmm11, xmm11, 0x00
00007154327dc4e2  vmovaps xmm8, [rsp+0xE0]
00007154327dc4eb  movaps xmm9, xmm8
00007154327dc4ef  mulpd xmm9, xmm11
00007154327dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007154327dc4fa  ptest xmm5, xmm5
00007154327dc4ff  jnz 0x00007154327DFC17
00007154327dc505  movaps xmm11, xmm10
00007154327dc509  addpd xmm11, xmm6
00007154327dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007154327dc514  ptest xmm8, xmm8
00007154327dc51a  jnz 0x00007154327DFD5B
00007154327dc520  movaps xmm10, xmm14
00007154327dc524  addpd xmm10, xmm4
00007154327dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007154327dc52f  ptest xmm8, xmm8
00007154327dc535  jnz 0x00007154327DFE9E
00007154327dc53b  vmovaps xmm14, [rsp+0x40]
00007154327dc541  vpermilpd xmm14, xmm14, 0x00
00007154327dc547  movaps xmm8, xmm1
00007154327dc54b  mulpd xmm8, xmm14
00007154327dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007154327dc556  ptest xmm6, xmm6
00007154327dc55b  jnz 0x00007154327DFFE1
00007154327dc561  movaps xmm1, [r15+0x2B0]
00007154327dc569  vmovaps xmm14, [rsp+0x40]
00007154327dc56f  vpermilpd xmm14, xmm14, 0x00
00007154327dc575  movaps xmm6, xmm1
00007154327dc578  mulpd xmm6, xmm14
00007154327dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007154327dc582  ptest xmm5, xmm5
00007154327dc587  jnz 0x00007154327E0124
00007154327dc58d  vmovaps xmm1, [rsp+0x10]
00007154327dc593  vpermilpd xmm1, xmm1, 0x00
00007154327dc599  movaps xmm14, xmm12
00007154327dc59d  mulpd xmm14, xmm1
00007154327dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007154327dc5a8  ptest xmm5, xmm5
00007154327dc5ad  jnz 0x00007154327E0265
00007154327dc5b3  movaps xmm1, xmm13
00007154327dc5b7  addpd xmm1, xmm9
00007154327dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007154327dc5c1  ptest xmm12, xmm12
00007154327dc5c7  jnz 0x00007154327E03A8
00007154327dc5cd  vmovaps xmm13, [rsp+0x10]
00007154327dc5d3  vpermilpd xmm13, xmm13, 0x00
00007154327dc5d9  movaps xmm12, xmm7
00007154327dc5dd  mulpd xmm12, xmm13
00007154327dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007154327dc5e8  ptest xmm9, xmm9
00007154327dc5ee  jnz 0x00007154327E04EA
00007154327dc5f4  movaps xmm13, xmm15
00007154327dc5f8  addpd xmm13, xmm8
00007154327dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007154327dc603  ptest xmm9, xmm9
00007154327dc609  jnz 0x00007154327E062D
00007154327dc60f  movaps xmm15, [r15+0x290]
00007154327dc617  vmovaps xmm9, [rsp+0x10]
00007154327dc61d  vpermilpd xmm9, xmm9, 0x00
00007154327dc623  movaps xmm8, xmm15
00007154327dc627  mulpd xmm8, xmm9
00007154327dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007154327dc632  ptest xmm7, xmm7
00007154327dc637  jnz 0x00007154327E0771
00007154327dc63d  movaps xmm15, xmm11
00007154327dc641  addpd xmm15, xmm6
00007154327dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007154327dc64c  ptest xmm9, xmm9
00007154327dc652  jnz 0x00007154327E08B5
00007154327dc658  movaps xmm11, [r15+0x1E0]
00007154327dc660  vmovaps xmm9, [rsp+0x10]
00007154327dc666  vpermilpd xmm9, xmm9, 0x00
00007154327dc66c  movaps xmm7, xmm11
00007154327dc670  mulpd xmm7, xmm9
00007154327dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007154327dc67a  ptest xmm6, xmm6
00007154327dc67f  jnz 0x00007154327E09F8
00007154327dc685  movaps xmm11, xmm10
00007154327dc689  addpd xmm11, xmm14
00007154327dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007154327dc694  ptest xmm9, xmm9
00007154327dc69a  jnz 0x00007154327E0B3A
00007154327dc6a0  lea r12, [rax+0x70]
00007154327dc6a4  movups xmm14, [r13+r12*1]
00007154327dc6aa  movaps [r15+0x240], xmm14
00007154327dc6b2  movaps xmm10, xmm1
00007154327dc6b6  addpd xmm10, xmm12
00007154327dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007154327dc6c1  ptest xmm9, xmm9
00007154327dc6c7  jnz 0x00007154327E0C88
00007154327dc6cd  movaps [r15+0x170], xmm10
00007154327dc6d5  vmovaps xmm1, [rsp+0x20]
00007154327dc6db  vpermilpd xmm1, xmm1, 0x00
00007154327dc6e1  movaps xmm12, xmm14
00007154327dc6e5  mulpd xmm12, xmm1
00007154327dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007154327dc6f0  ptest xmm9, xmm9
00007154327dc6f6  jnz 0x00007154327E0DCB
00007154327dc6fc  vmovaps xmm1, [rsp+0x20]
00007154327dc702  vpermilpd xmm1, xmm1, 0x00
00007154327dc708  vmovaps xmm9, [rsp+0xB0]
00007154327dc711  movaps xmm14, xmm9
00007154327dc715  mulpd xmm14, xmm1
00007154327dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007154327dc720  ptest xmm6, xmm6
00007154327dc725  jnz 0x00007154327E0F0E
00007154327dc72b  movaps [r15+0x180], xmm14
00007154327dc733  movaps xmm1, xmm13
00007154327dc737  addpd xmm1, xmm8
00007154327dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007154327dc741  ptest xmm9, xmm9
00007154327dc747  jnz 0x00007154327E1051
00007154327dc74d  movaps [r15+0x210], xmm1
00007154327dc755  movups xmm13, [r13+rax*1]
00007154327dc75b  lea r12, [rax+0x10]
00007154327dc75f  movups xmm9, [r13+r12*1]
00007154327dc765  movaps [r15+0x230], xmm9
00007154327dc76d  movaps xmm8, xmm15
00007154327dc771  addpd xmm8, xmm7
00007154327dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007154327dc77c  ptest xmm6, xmm6
00007154327dc781  jnz 0x00007154327E11A7
00007154327dc787  movaps [r15+0x130], xmm8
00007154327dc78f  vmovaps xmm15, [rsp+0x20]
00007154327dc795  vpermilpd xmm15, xmm15, 0x00
00007154327dc79b  movaps xmm7, xmm9
00007154327dc79f  mulpd xmm7, xmm15
00007154327dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007154327dc7a9  ptest xmm6, xmm6
00007154327dc7ae  jnz 0x00007154327E12EA
00007154327dc7b4  movaps [r15+0x220], xmm7
00007154327dc7bc  vmovaps xmm15, [rsp+0x20]
00007154327dc7c2  vpermilpd xmm15, xmm15, 0x00
00007154327dc7c8  movaps xmm9, xmm13
00007154327dc7cc  mulpd xmm9, xmm15
00007154327dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007154327dc7d7  ptest xmm6, xmm6
00007154327dc7dc  jnz 0x00007154327E142C
00007154327dc7e2  movaps xmm15, xmm11
00007154327dc7e6  addpd xmm15, xmm12
00007154327dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007154327dc7f1  ptest xmm13, xmm13
00007154327dc7f7  jnz 0x00007154327E1570
00007154327dc7fd  movaps [r15+0x140], xmm15
00007154327dc805  movaps xmm13, xmm10
00007154327dc809  addpd xmm13, xmm14
00007154327dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007154327dc814  ptest xmm12, xmm12
00007154327dc81a  jnz 0x00007154327E16B4
00007154327dc820  movaps [r15+0x150], xmm13
00007154327dc828  movaps xmm14, xmm1
00007154327dc82c  addpd xmm14, xmm7
00007154327dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007154327dc837  ptest xmm12, xmm12
00007154327dc83d  jnz 0x00007154327E17F8
00007154327dc843  movaps [r15+0x160], xmm14
00007154327dc84b  movaps xmm1, xmm8
00007154327dc84f  addpd xmm1, xmm9
00007154327dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007154327dc859  ptest xmm12, xmm12
00007154327dc85f  jnz 0x00007154327E193A
00007154327dc865  movaps [r15+0x120], xmm1
00007154327dc86d  movups [r13+r14*1], xmm15
00007154327dc873  lea rax, [r14+0x10]
00007154327dc877  movups [r13+rax*1], xmm13
00007154327dc87d  lea rax, [r14+0x20]
00007154327dc881  movups [r13+rax*1], xmm14
00007154327dc887  lea rax, [r14+0x30]
00007154327dc88b  movups [r13+rax*1], xmm1
00007154327dc891  mov eax, [r15+0x108]
00007154327dc898  sahf
00007154327dc899  jnz 0x00007154327DC8CB
00007154327dc89b  cmp dword ptr [r15+0x318], 0x00
00007154327dc8a3  jz 0x00007154327DB900
00007154327dc8a9  nop [rax+rax*1], ax
00007154327dc8b2  nop [rax+rax*1], eax
00007154327dc8ba  mov eax, 0x410444
00007154327dc8bf  mov [r15+0x100], rax
00007154327dc8c6  jmp 0x00007154325FE110
00007154327dc8cb  cmp dword ptr [r15+0x318], 0x00
00007154327dc8d3  jz 0x00007154327D57E0
00007154327dc8d9  nop [rax+rax*1], ax
00007154327dc8e2  nop [rax+rax*1], eax
00007154327dc8ea  mov eax, 0x410278
00007154327dc8ef  mov [r15+0x100], rax
00007154327dc8f6  jmp 0x00007154325FE110
00007154327dc8fb  int3
00007154327dc8fc  call 0x00007154326E27E0
00007154327dc901  jmp 0x00007154327DB9DF
00007154327dc906  call 0x00007154326E1570
00007154327dc90b  jmp 0x00007154327DB9E8
00007154327dc910  call 0x00007154326E27E0
00007154327dc915  jmp 0x00007154327DBA44
00007154327dc91a  call 0x00007154326E1570
00007154327dc91f  jmp 0x00007154327DBA4D
00007154327dc924  call 0x00007154326E27E0
00007154327dc929  jmp 0x00007154327DBA90
00007154327dc92e  call 0x00007154326E1570
00007154327dc933  jmp 0x00007154327DBA99
00007154327dc938  call 0x000071543260DC20
00007154327dc93d  jmp 0x00007154327DBAD8
00007154327dc942  call 0x00007154326D59C0
00007154327dc947  jmp 0x00007154327DBAEB
00007154327dc94c  call 0x00007154326E0E30
00007154327dc951  jmp 0x00007154327DBB09
00007154327dc956  call 0x00007154326DFBC0
00007154327dc95b  jmp 0x00007154327DBB13
00007154327dc960  call 0x00007154326DE950
00007154327dc965  jmp 0x00007154327DBB1D
00007154327dc96a  sub rsp, 0x08
00007154327dc96e  push rax
00007154327dc96f  push rcx
00007154327dc970  push rdx
00007154327dc971  push rdi
00007154327dc972  push rsi
00007154327dc973  push r8
00007154327dc975  push r9
00007154327dc977  push r10
00007154327dc979  push r11
00007154327dc97b  sub rsp, 0xF0
00007154327dc982  vmovaps [rsp], xmm0
00007154327dc987  vmovaps [rsp+0x10], xmm1
00007154327dc98d  vmovaps [rsp+0x20], xmm2
00007154327dc993  vmovaps [rsp+0x30], xmm3
00007154327dc999  vmovaps [rsp+0x40], xmm4
00007154327dc99f  vmovaps [rsp+0x50], xmm5
00007154327dc9a5  vmovaps [rsp+0x60], xmm6
00007154327dc9ab  vmovaps [rsp+0x70], xmm7
00007154327dc9b1  vmovaps [rsp+0x80], xmm9
00007154327dc9ba  vmovaps [rsp+0x90], xmm10
00007154327dc9c3  vmovaps [rsp+0xA0], xmm11
00007154327dc9cc  vmovaps [rsp+0xB0], xmm12
00007154327dc9d5  vmovaps [rsp+0xC0], xmm13
00007154327dc9de  vmovaps [rsp+0xD0], xmm14
00007154327dc9e7  vmovaps [rsp+0xE0], xmm15
00007154327dc9f0  sub rsp, 0x30
00007154327dc9f4  movaps [rsp], xmm8
00007154327dc9f9  movaps [rsp+0x10], xmm12
00007154327dc9ff  movaps [rsp+0x20], xmm15
00007154327dca05  lea rdi, [rsp]
00007154327dca09  mov esi, 0x00
00007154327dca0e  mov rax, 0x5A63B06A5530
00007154327dca18  call rax
00007154327dca1a  movaps xmm8, [rsp]
00007154327dca1f  add rsp, 0x30
00007154327dca23  vmovaps xmm0, [rsp]
00007154327dca28  vmovaps xmm1, [rsp+0x10]
00007154327dca2e  vmovaps xmm2, [rsp+0x20]
00007154327dca34  vmovaps xmm3, [rsp+0x30]
00007154327dca3a  vmovaps xmm4, [rsp+0x40]
00007154327dca40  vmovaps xmm5, [rsp+0x50]
00007154327dca46  vmovaps xmm6, [rsp+0x60]
00007154327dca4c  vmovaps xmm7, [rsp+0x70]
00007154327dca52  vmovaps xmm9, [rsp+0x80]
00007154327dca5b  vmovaps xmm10, [rsp+0x90]
00007154327dca64  vmovaps xmm11, [rsp+0xA0]
00007154327dca6d  vmovaps xmm12, [rsp+0xB0]
00007154327dca76  vmovaps xmm13, [rsp+0xC0]
00007154327dca7f  vmovaps xmm14, [rsp+0xD0]
00007154327dca88  vmovaps xmm15, [rsp+0xE0]
00007154327dca91  add rsp, 0xF0
00007154327dca98  pop r11
00007154327dca9a  pop r10
00007154327dca9c  pop r9
00007154327dca9e  pop r8
00007154327dcaa0  pop rsi
00007154327dcaa1  pop rdi
00007154327dcaa2  pop rdx
00007154327dcaa3  pop rcx
00007154327dcaa4  pop rax
00007154327dcaa5  add rsp, 0x08
00007154327dcaa9  jmp 0x00007154327DBB47
00007154327dcaae  sub rsp, 0x08
00007154327dcab2  push rax
00007154327dcab3  push rcx
00007154327dcab4  push rdx
00007154327dcab5  push rdi
00007154327dcab6  push rsi
00007154327dcab7  push r8
00007154327dcab9  push r9
00007154327dcabb  push r10
00007154327dcabd  push r11
00007154327dcabf  sub rsp, 0xF0
00007154327dcac6  vmovaps [rsp], xmm0
00007154327dcacb  vmovaps [rsp+0x10], xmm1
00007154327dcad1  vmovaps [rsp+0x20], xmm2
00007154327dcad7  vmovaps [rsp+0x30], xmm3
00007154327dcadd  vmovaps [rsp+0x40], xmm4
00007154327dcae3  vmovaps [rsp+0x50], xmm5
00007154327dcae9  vmovaps [rsp+0x60], xmm6
00007154327dcaef  vmovaps [rsp+0x70], xmm8
00007154327dcaf5  vmovaps [rsp+0x80], xmm9
00007154327dcafe  vmovaps [rsp+0x90], xmm10
00007154327dcb07  vmovaps [rsp+0xA0], xmm11
00007154327dcb10  vmovaps [rsp+0xB0], xmm12
00007154327dcb19  vmovaps [rsp+0xC0], xmm13
00007154327dcb22  vmovaps [rsp+0xD0], xmm14
00007154327dcb2b  vmovaps [rsp+0xE0], xmm15
00007154327dcb34  sub rsp, 0x30
00007154327dcb38  movaps [rsp], xmm7
00007154327dcb3c  movaps [rsp+0x10], xmm9
00007154327dcb42  movaps [rsp+0x20], xmm15
00007154327dcb48  lea rdi, [rsp]
00007154327dcb4c  mov esi, 0x00
00007154327dcb51  mov rax, 0x5A63B06A5530
00007154327dcb5b  call rax
00007154327dcb5d  movaps xmm7, [rsp]
00007154327dcb61  add rsp, 0x30
00007154327dcb65  vmovaps xmm0, [rsp]
00007154327dcb6a  vmovaps xmm1, [rsp+0x10]
00007154327dcb70  vmovaps xmm2, [rsp+0x20]
00007154327dcb76  vmovaps xmm3, [rsp+0x30]
00007154327dcb7c  vmovaps xmm4, [rsp+0x40]
00007154327dcb82  vmovaps xmm5, [rsp+0x50]
00007154327dcb88  vmovaps xmm6, [rsp+0x60]
00007154327dcb8e  vmovaps xmm8, [rsp+0x70]
00007154327dcb94  vmovaps xmm9, [rsp+0x80]
00007154327dcb9d  vmovaps xmm10, [rsp+0x90]
00007154327dcba6  vmovaps xmm11, [rsp+0xA0]
00007154327dcbaf  vmovaps xmm12, [rsp+0xB0]
00007154327dcbb8  vmovaps xmm13, [rsp+0xC0]
00007154327dcbc1  vmovaps xmm14, [rsp+0xD0]
00007154327dcbca  vmovaps xmm15, [rsp+0xE0]
00007154327dcbd3  add rsp, 0xF0
00007154327dcbda  pop r11
00007154327dcbdc  pop r10
00007154327dcbde  pop r9
00007154327dcbe0  pop r8
00007154327dcbe2  pop rsi
00007154327dcbe3  pop rdi
00007154327dcbe4  pop rdx
00007154327dcbe5  pop rcx
00007154327dcbe6  pop rax
00007154327dcbe7  add rsp, 0x08
00007154327dcbeb  jmp 0x00007154327DBB75
00007154327dcbf0  sub rsp, 0x08
00007154327dcbf4  push rax
00007154327dcbf5  push rcx
00007154327dcbf6  push rdx
00007154327dcbf7  push rdi
00007154327dcbf8  push rsi
00007154327dcbf9  push r8
00007154327dcbfb  push r9
00007154327dcbfd  push r10
00007154327dcbff  push r11
00007154327dcc01  sub rsp, 0xF0
00007154327dcc08  vmovaps [rsp], xmm0
00007154327dcc0d  vmovaps [rsp+0x10], xmm1
00007154327dcc13  vmovaps [rsp+0x20], xmm2
00007154327dcc19  vmovaps [rsp+0x30], xmm3
00007154327dcc1f  vmovaps [rsp+0x40], xmm4
00007154327dcc25  vmovaps [rsp+0x50], xmm5
00007154327dcc2b  vmovaps [rsp+0x60], xmm6
00007154327dcc31  vmovaps [rsp+0x70], xmm7
00007154327dcc37  vmovaps [rsp+0x80], xmm8
00007154327dcc40  vmovaps [rsp+0x90], xmm10
00007154327dcc49  vmovaps [rsp+0xA0], xmm11
00007154327dcc52  vmovaps [rsp+0xB0], xmm12
00007154327dcc5b  vmovaps [rsp+0xC0], xmm13
00007154327dcc64  vmovaps [rsp+0xD0], xmm14
00007154327dcc6d  vmovaps [rsp+0xE0], xmm15
00007154327dcc76  sub rsp, 0x30
00007154327dcc7a  movaps [rsp], xmm9
00007154327dcc7f  movaps [rsp+0x10], xmm12
00007154327dcc85  movaps [rsp+0x20], xmm10
00007154327dcc8b  lea rdi, [rsp]
00007154327dcc8f  mov esi, 0x00
00007154327dcc94  mov rax, 0x5A63B06A5530
00007154327dcc9e  call rax
00007154327dcca0  movaps xmm9, [rsp]
00007154327dcca5  add rsp, 0x30
00007154327dcca9  vmovaps xmm0, [rsp]
00007154327dccae  vmovaps xmm1, [rsp+0x10]
00007154327dccb4  vmovaps xmm2, [rsp+0x20]
00007154327dccba  vmovaps xmm3, [rsp+0x30]
00007154327dccc0  vmovaps xmm4, [rsp+0x40]
00007154327dccc6  vmovaps xmm5, [rsp+0x50]
00007154327dcccc  vmovaps xmm6, [rsp+0x60]
00007154327dccd2  vmovaps xmm7, [rsp+0x70]
00007154327dccd8  vmovaps xmm8, [rsp+0x80]
00007154327dcce1  vmovaps xmm10, [rsp+0x90]
00007154327dccea  vmovaps xmm11, [rsp+0xA0]
00007154327dccf3  vmovaps xmm12, [rsp+0xB0]
00007154327dccfc  vmovaps xmm13, [rsp+0xC0]
00007154327dcd05  vmovaps xmm14, [rsp+0xD0]
00007154327dcd0e  vmovaps xmm15, [rsp+0xE0]
00007154327dcd17  add rsp, 0xF0
00007154327dcd1e  pop r11
00007154327dcd20  pop r10
00007154327dcd22  pop r9
00007154327dcd24  pop r8
00007154327dcd26  pop rsi
00007154327dcd27  pop rdi
00007154327dcd28  pop rdx
00007154327dcd29  pop rcx
00007154327dcd2a  pop rax
00007154327dcd2b  add rsp, 0x08
00007154327dcd2f  jmp 0x00007154327DBB99
00007154327dcd34  sub rsp, 0x08
00007154327dcd38  push rax
00007154327dcd39  push rcx
00007154327dcd3a  push rdx
00007154327dcd3b  push rdi
00007154327dcd3c  push rsi
00007154327dcd3d  push r8
00007154327dcd3f  push r9
00007154327dcd41  push r10
00007154327dcd43  push r11
00007154327dcd45  sub rsp, 0xF0
00007154327dcd4c  vmovaps [rsp], xmm0
00007154327dcd51  vmovaps [rsp+0x10], xmm1
00007154327dcd57  vmovaps [rsp+0x20], xmm2
00007154327dcd5d  vmovaps [rsp+0x30], xmm3
00007154327dcd63  vmovaps [rsp+0x40], xmm4
00007154327dcd69  vmovaps [rsp+0x50], xmm5
00007154327dcd6f  vmovaps [rsp+0x60], xmm6
00007154327dcd75  vmovaps [rsp+0x70], xmm7
00007154327dcd7b  vmovaps [rsp+0x80], xmm8
00007154327dcd84  vmovaps [rsp+0x90], xmm9
00007154327dcd8d  vmovaps [rsp+0xA0], xmm11
00007154327dcd96  vmovaps [rsp+0xB0], xmm12
00007154327dcd9f  vmovaps [rsp+0xC0], xmm13
00007154327dcda8  vmovaps [rsp+0xD0], xmm14
00007154327dcdb1  vmovaps [rsp+0xE0], xmm15
00007154327dcdba  sub rsp, 0x30
00007154327dcdbe  movaps [rsp], xmm10
00007154327dcdc3  movaps [rsp+0x10], xmm12
00007154327dcdc9  movaps [rsp+0x20], xmm11
00007154327dcdcf  lea rdi, [rsp]
00007154327dcdd3  mov esi, 0x00
00007154327dcdd8  mov rax, 0x5A63B06A5530
00007154327dcde2  call rax
00007154327dcde4  movaps xmm10, [rsp]
00007154327dcde9  add rsp, 0x30
00007154327dcded  vmovaps xmm0, [rsp]
00007154327dcdf2  vmovaps xmm1, [rsp+0x10]
00007154327dcdf8  vmovaps xmm2, [rsp+0x20]
00007154327dcdfe  vmovaps xmm3, [rsp+0x30]
00007154327dce04  vmovaps xmm4, [rsp+0x40]
00007154327dce0a  vmovaps xmm5, [rsp+0x50]
00007154327dce10  vmovaps xmm6, [rsp+0x60]
00007154327dce16  vmovaps xmm7, [rsp+0x70]
00007154327dce1c  vmovaps xmm8, [rsp+0x80]
00007154327dce25  vmovaps xmm9, [rsp+0x90]
00007154327dce2e  vmovaps xmm11, [rsp+0xA0]
00007154327dce37  vmovaps xmm12, [rsp+0xB0]
00007154327dce40  vmovaps xmm13, [rsp+0xC0]
00007154327dce49  vmovaps xmm14, [rsp+0xD0]
00007154327dce52  vmovaps xmm15, [rsp+0xE0]
00007154327dce5b  add rsp, 0xF0
00007154327dce62  pop r11
00007154327dce64  pop r10
00007154327dce66  pop r9
00007154327dce68  pop r8
00007154327dce6a  pop rsi
00007154327dce6b  pop rdi
00007154327dce6c  pop rdx
00007154327dce6d  pop rcx
00007154327dce6e  pop rax
00007154327dce6f  add rsp, 0x08
00007154327dce73  jmp 0x00007154327DBBB3
00007154327dce78  sub rsp, 0x08
00007154327dce7c  push rax
00007154327dce7d  push rcx
00007154327dce7e  push rdx
00007154327dce7f  push rdi
00007154327dce80  push rsi
00007154327dce81  push r8
00007154327dce83  push r9
00007154327dce85  push r10
00007154327dce87  push r11
00007154327dce89  sub rsp, 0xF0
00007154327dce90  vmovaps [rsp], xmm0
00007154327dce95  vmovaps [rsp+0x10], xmm1
00007154327dce9b  vmovaps [rsp+0x20], xmm2
00007154327dcea1  vmovaps [rsp+0x30], xmm3
00007154327dcea7  vmovaps [rsp+0x40], xmm4
00007154327dcead  vmovaps [rsp+0x50], xmm5
00007154327dceb3  vmovaps [rsp+0x60], xmm7
00007154327dceb9  vmovaps [rsp+0x70], xmm8
00007154327dcebf  vmovaps [rsp+0x80], xmm9
00007154327dcec8  vmovaps [rsp+0x90], xmm10
00007154327dced1  vmovaps [rsp+0xA0], xmm11
00007154327dceda  vmovaps [rsp+0xB0], xmm12
00007154327dcee3  vmovaps [rsp+0xC0], xmm13
00007154327dceec  vmovaps [rsp+0xD0], xmm14
00007154327dcef5  vmovaps [rsp+0xE0], xmm15
00007154327dcefe  sub rsp, 0x30
00007154327dcf02  movaps [rsp], xmm6
00007154327dcf06  movaps [rsp+0x10], xmm12
00007154327dcf0c  movaps [rsp+0x20], xmm11
00007154327dcf12  lea rdi, [rsp]
00007154327dcf16  mov esi, 0x00
00007154327dcf1b  mov rax, 0x5A63B06A5530
00007154327dcf25  call rax
00007154327dcf27  movaps xmm6, [rsp]
00007154327dcf2b  add rsp, 0x30
00007154327dcf2f  vmovaps xmm0, [rsp]
00007154327dcf34  vmovaps xmm1, [rsp+0x10]
00007154327dcf3a  vmovaps xmm2, [rsp+0x20]
00007154327dcf40  vmovaps xmm3, [rsp+0x30]
00007154327dcf46  vmovaps xmm4, [rsp+0x40]
00007154327dcf4c  vmovaps xmm5, [rsp+0x50]
00007154327dcf52  vmovaps xmm7, [rsp+0x60]
00007154327dcf58  vmovaps xmm8, [rsp+0x70]
00007154327dcf5e  vmovaps xmm9, [rsp+0x80]
00007154327dcf67  vmovaps xmm10, [rsp+0x90]
00007154327dcf70  vmovaps xmm11, [rsp+0xA0]
00007154327dcf79  vmovaps xmm12, [rsp+0xB0]
00007154327dcf82  vmovaps xmm13, [rsp+0xC0]
00007154327dcf8b  vmovaps xmm14, [rsp+0xD0]
00007154327dcf94  vmovaps xmm15, [rsp+0xE0]
00007154327dcf9d  add rsp, 0xF0
00007154327dcfa4  pop r11
00007154327dcfa6  pop r10
00007154327dcfa8  pop r9
00007154327dcfaa  pop r8
00007154327dcfac  pop rsi
00007154327dcfad  pop rdi
00007154327dcfae  pop rdx
00007154327dcfaf  pop rcx
00007154327dcfb0  pop rax
00007154327dcfb1  add rsp, 0x08
00007154327dcfb5  jmp 0x00007154327DBBD4
00007154327dcfba  sub rsp, 0x08
00007154327dcfbe  push rax
00007154327dcfbf  push rcx
00007154327dcfc0  push rdx
00007154327dcfc1  push rdi
00007154327dcfc2  push rsi
00007154327dcfc3  push r8
00007154327dcfc5  push r9
00007154327dcfc7  push r10
00007154327dcfc9  push r11
00007154327dcfcb  sub rsp, 0xF0
00007154327dcfd2  vmovaps [rsp], xmm0
00007154327dcfd7  vmovaps [rsp+0x10], xmm1
00007154327dcfdd  vmovaps [rsp+0x20], xmm2
00007154327dcfe3  vmovaps [rsp+0x30], xmm4
00007154327dcfe9  vmovaps [rsp+0x40], xmm5
00007154327dcfef  vmovaps [rsp+0x50], xmm6
00007154327dcff5  vmovaps [rsp+0x60], xmm7
00007154327dcffb  vmovaps [rsp+0x70], xmm8
00007154327dd001  vmovaps [rsp+0x80], xmm9
00007154327dd00a  vmovaps [rsp+0x90], xmm10
00007154327dd013  vmovaps [rsp+0xA0], xmm11
00007154327dd01c  vmovaps [rsp+0xB0], xmm12
00007154327dd025  vmovaps [rsp+0xC0], xmm13
00007154327dd02e  vmovaps [rsp+0xD0], xmm14
00007154327dd037  vmovaps [rsp+0xE0], xmm15
00007154327dd040  sub rsp, 0x30
00007154327dd044  movaps [rsp], xmm3
00007154327dd048  movaps [rsp+0x10], xmm5
00007154327dd04d  movaps [rsp+0x20], xmm4
00007154327dd052  lea rdi, [rsp]
00007154327dd056  mov esi, 0x00
00007154327dd05b  mov rax, 0x5A63B06A5530
00007154327dd065  call rax
00007154327dd067  movaps xmm3, [rsp]
00007154327dd06b  add rsp, 0x30
00007154327dd06f  vmovaps xmm0, [rsp]
00007154327dd074  vmovaps xmm1, [rsp+0x10]
00007154327dd07a  vmovaps xmm2, [rsp+0x20]
00007154327dd080  vmovaps xmm4, [rsp+0x30]
00007154327dd086  vmovaps xmm5, [rsp+0x40]
00007154327dd08c  vmovaps xmm6, [rsp+0x50]
00007154327dd092  vmovaps xmm7, [rsp+0x60]
00007154327dd098  vmovaps xmm8, [rsp+0x70]
00007154327dd09e  vmovaps xmm9, [rsp+0x80]
00007154327dd0a7  vmovaps xmm10, [rsp+0x90]
00007154327dd0b0  vmovaps xmm11, [rsp+0xA0]
00007154327dd0b9  vmovaps xmm12, [rsp+0xB0]
00007154327dd0c2  vmovaps xmm13, [rsp+0xC0]
00007154327dd0cb  vmovaps xmm14, [rsp+0xD0]
00007154327dd0d4  vmovaps xmm15, [rsp+0xE0]
00007154327dd0dd  add rsp, 0xF0
00007154327dd0e4  pop r11
00007154327dd0e6  pop r10
00007154327dd0e8  pop r9
00007154327dd0ea  pop r8
00007154327dd0ec  pop rsi
00007154327dd0ed  pop rdi
00007154327dd0ee  pop rdx
00007154327dd0ef  pop rcx
00007154327dd0f0  pop rax
00007154327dd0f1  add rsp, 0x08
00007154327dd0f5  jmp 0x00007154327DBC35
00007154327dd0fa  sub rsp, 0x08
00007154327dd0fe  push rax
00007154327dd0ff  push rcx
00007154327dd100  push rdx
00007154327dd101  push rdi
00007154327dd102  push rsi
00007154327dd103  push r8
00007154327dd105  push r9
00007154327dd107  push r10
00007154327dd109  push r11
00007154327dd10b  sub rsp, 0xF0
00007154327dd112  vmovaps [rsp], xmm0
00007154327dd117  vmovaps [rsp+0x10], xmm1
00007154327dd11d  vmovaps [rsp+0x20], xmm2
00007154327dd123  vmovaps [rsp+0x30], xmm3
00007154327dd129  vmovaps [rsp+0x40], xmm4
00007154327dd12f  vmovaps [rsp+0x50], xmm6
00007154327dd135  vmovaps [rsp+0x60], xmm7
00007154327dd13b  vmovaps [rsp+0x70], xmm8
00007154327dd141  vmovaps [rsp+0x80], xmm9
00007154327dd14a  vmovaps [rsp+0x90], xmm10
00007154327dd153  vmovaps [rsp+0xA0], xmm11
00007154327dd15c  vmovaps [rsp+0xB0], xmm12
00007154327dd165  vmovaps [rsp+0xC0], xmm13
00007154327dd16e  vmovaps [rsp+0xD0], xmm14
00007154327dd177  vmovaps [rsp+0xE0], xmm15
00007154327dd180  sub rsp, 0x30
00007154327dd184  movaps [rsp], xmm5
00007154327dd188  movaps [rsp+0x10], xmm8
00007154327dd18e  movaps [rsp+0x20], xmm15
00007154327dd194  lea rdi, [rsp]
00007154327dd198  mov esi, 0x00
00007154327dd19d  mov rax, 0x5A63B06A5530
00007154327dd1a7  call rax
00007154327dd1a9  movaps xmm5, [rsp]
00007154327dd1ad  add rsp, 0x30
00007154327dd1b1  vmovaps xmm0, [rsp]
00007154327dd1b6  vmovaps xmm1, [rsp+0x10]
00007154327dd1bc  vmovaps xmm2, [rsp+0x20]
00007154327dd1c2  vmovaps xmm3, [rsp+0x30]
00007154327dd1c8  vmovaps xmm4, [rsp+0x40]
00007154327dd1ce  vmovaps xmm6, [rsp+0x50]
00007154327dd1d4  vmovaps xmm7, [rsp+0x60]
00007154327dd1da  vmovaps xmm8, [rsp+0x70]
00007154327dd1e0  vmovaps xmm9, [rsp+0x80]
00007154327dd1e9  vmovaps xmm10, [rsp+0x90]
00007154327dd1f2  vmovaps xmm11, [rsp+0xA0]
00007154327dd1fb  vmovaps xmm12, [rsp+0xB0]
00007154327dd204  vmovaps xmm13, [rsp+0xC0]
00007154327dd20d  vmovaps xmm14, [rsp+0xD0]
00007154327dd216  vmovaps xmm15, [rsp+0xE0]
00007154327dd21f  add rsp, 0xF0
00007154327dd226  pop r11
00007154327dd228  pop r10
00007154327dd22a  pop r9
00007154327dd22c  pop r8
00007154327dd22e  pop rsi
00007154327dd22f  pop rdi
00007154327dd230  pop rdx
00007154327dd231  pop rcx
00007154327dd232  pop rax
00007154327dd233  add rsp, 0x08
00007154327dd237  jmp 0x00007154327DBC73
00007154327dd23c  sub rsp, 0x08
00007154327dd240  push rax
00007154327dd241  push rcx
00007154327dd242  push rdx
00007154327dd243  push rdi
00007154327dd244  push rsi
00007154327dd245  push r8
00007154327dd247  push r9
00007154327dd249  push r10
00007154327dd24b  push r11
00007154327dd24d  sub rsp, 0xF0
00007154327dd254  vmovaps [rsp], xmm0
00007154327dd259  vmovaps [rsp+0x10], xmm1
00007154327dd25f  vmovaps [rsp+0x20], xmm2
00007154327dd265  vmovaps [rsp+0x30], xmm3
00007154327dd26b  vmovaps [rsp+0x40], xmm5
00007154327dd271  vmovaps [rsp+0x50], xmm6
00007154327dd277  vmovaps [rsp+0x60], xmm7
00007154327dd27d  vmovaps [rsp+0x70], xmm8
00007154327dd283  vmovaps [rsp+0x80], xmm9
00007154327dd28c  vmovaps [rsp+0x90], xmm10
00007154327dd295  vmovaps [rsp+0xA0], xmm11
00007154327dd29e  vmovaps [rsp+0xB0], xmm12
00007154327dd2a7  vmovaps [rsp+0xC0], xmm13
00007154327dd2b0  vmovaps [rsp+0xD0], xmm14
00007154327dd2b9  vmovaps [rsp+0xE0], xmm15
00007154327dd2c2  sub rsp, 0x30
00007154327dd2c6  movaps [rsp], xmm4
00007154327dd2ca  movaps [rsp+0x10], xmm9
00007154327dd2d0  movaps [rsp+0x20], xmm8
00007154327dd2d6  lea rdi, [rsp]
00007154327dd2da  mov esi, 0x00
00007154327dd2df  mov rax, 0x5A63B06A5530
00007154327dd2e9  call rax
00007154327dd2eb  movaps xmm4, [rsp]
00007154327dd2ef  add rsp, 0x30
00007154327dd2f3  vmovaps xmm0, [rsp]
00007154327dd2f8  vmovaps xmm1, [rsp+0x10]
00007154327dd2fe  vmovaps xmm2, [rsp+0x20]
00007154327dd304  vmovaps xmm3, [rsp+0x30]
00007154327dd30a  vmovaps xmm5, [rsp+0x40]
00007154327dd310  vmovaps xmm6, [rsp+0x50]
00007154327dd316  vmovaps xmm7, [rsp+0x60]
00007154327dd31c  vmovaps xmm8, [rsp+0x70]
00007154327dd322  vmovaps xmm9, [rsp+0x80]
00007154327dd32b  vmovaps xmm10, [rsp+0x90]
00007154327dd334  vmovaps xmm11, [rsp+0xA0]
00007154327dd33d  vmovaps xmm12, [rsp+0xB0]
00007154327dd346  vmovaps xmm13, [rsp+0xC0]
00007154327dd34f  vmovaps xmm14, [rsp+0xD0]
00007154327dd358  vmovaps xmm15, [rsp+0xE0]
00007154327dd361  add rsp, 0xF0
00007154327dd368  pop r11
00007154327dd36a  pop r10
00007154327dd36c  pop r9
00007154327dd36e  pop r8
00007154327dd370  pop rsi
00007154327dd371  pop rdi
00007154327dd372  pop rdx
00007154327dd373  pop rcx
00007154327dd374  pop rax
00007154327dd375  add rsp, 0x08
00007154327dd379  jmp 0x00007154327DBC94
00007154327dd37e  sub rsp, 0x08
00007154327dd382  push rax
00007154327dd383  push rcx
00007154327dd384  push rdx
00007154327dd385  push rdi
00007154327dd386  push rsi
00007154327dd387  push r8
00007154327dd389  push r9
00007154327dd38b  push r10
00007154327dd38d  push r11
00007154327dd38f  sub rsp, 0xF0
00007154327dd396  vmovaps [rsp], xmm0
00007154327dd39b  vmovaps [rsp+0x10], xmm1
00007154327dd3a1  vmovaps [rsp+0x20], xmm2
00007154327dd3a7  vmovaps [rsp+0x30], xmm3
00007154327dd3ad  vmovaps [rsp+0x40], xmm4
00007154327dd3b3  vmovaps [rsp+0x50], xmm5
00007154327dd3b9  vmovaps [rsp+0x60], xmm6
00007154327dd3bf  vmovaps [rsp+0x70], xmm7
00007154327dd3c5  vmovaps [rsp+0x80], xmm8
00007154327dd3ce  vmovaps [rsp+0x90], xmm10
00007154327dd3d7  vmovaps [rsp+0xA0], xmm11
00007154327dd3e0  vmovaps [rsp+0xB0], xmm12
00007154327dd3e9  vmovaps [rsp+0xC0], xmm13
00007154327dd3f2  vmovaps [rsp+0xD0], xmm14
00007154327dd3fb  vmovaps [rsp+0xE0], xmm15
00007154327dd404  sub rsp, 0x30
00007154327dd408  movaps [rsp], xmm9
00007154327dd40d  movaps [rsp+0x10], xmm10
00007154327dd413  movaps [rsp+0x20], xmm8
00007154327dd419  lea rdi, [rsp]
00007154327dd41d  mov esi, 0x00
00007154327dd422  mov rax, 0x5A63B06A5530
00007154327dd42c  call rax
00007154327dd42e  movaps xmm9, [rsp]
00007154327dd433  add rsp, 0x30
00007154327dd437  vmovaps xmm0, [rsp]
00007154327dd43c  vmovaps xmm1, [rsp+0x10]
00007154327dd442  vmovaps xmm2, [rsp+0x20]
00007154327dd448  vmovaps xmm3, [rsp+0x30]
00007154327dd44e  vmovaps xmm4, [rsp+0x40]
00007154327dd454  vmovaps xmm5, [rsp+0x50]
00007154327dd45a  vmovaps xmm6, [rsp+0x60]
00007154327dd460  vmovaps xmm7, [rsp+0x70]
00007154327dd466  vmovaps xmm8, [rsp+0x80]
00007154327dd46f  vmovaps xmm10, [rsp+0x90]
00007154327dd478  vmovaps xmm11, [rsp+0xA0]
00007154327dd481  vmovaps xmm12, [rsp+0xB0]
00007154327dd48a  vmovaps xmm13, [rsp+0xC0]
00007154327dd493  vmovaps xmm14, [rsp+0xD0]
00007154327dd49c  vmovaps xmm15, [rsp+0xE0]
00007154327dd4a5  add rsp, 0xF0
00007154327dd4ac  pop r11
00007154327dd4ae  pop r10
00007154327dd4b0  pop r9
00007154327dd4b2  pop r8
00007154327dd4b4  pop rsi
00007154327dd4b5  pop rdi
00007154327dd4b6  pop rdx
00007154327dd4b7  pop rcx
00007154327dd4b8  pop rax
00007154327dd4b9  add rsp, 0x08
00007154327dd4bd  jmp 0x00007154327DBCAE
00007154327dd4c2  call 0x00007154326B52F0
00007154327dd4c7  jmp 0x00007154327DBDC8
00007154327dd4cc  call 0x00007154326B52F0
00007154327dd4d1  jmp 0x00007154327DBDDE
00007154327dd4d6  sub rsp, 0x08
00007154327dd4da  push rax
00007154327dd4db  push rcx
00007154327dd4dc  push rdx
00007154327dd4dd  push rdi
00007154327dd4de  push rsi
00007154327dd4df  push r8
00007154327dd4e1  push r9
00007154327dd4e3  push r10
00007154327dd4e5  push r11
00007154327dd4e7  sub rsp, 0xF0
00007154327dd4ee  vmovaps [rsp], xmm0
00007154327dd4f3  vmovaps [rsp+0x10], xmm2
00007154327dd4f9  vmovaps [rsp+0x20], xmm3
00007154327dd4ff  vmovaps [rsp+0x30], xmm4
00007154327dd505  vmovaps [rsp+0x40], xmm5
00007154327dd50b  vmovaps [rsp+0x50], xmm6
00007154327dd511  vmovaps [rsp+0x60], xmm7
00007154327dd517  vmovaps [rsp+0x70], xmm8
00007154327dd51d  vmovaps [rsp+0x80], xmm9
00007154327dd526  vmovaps [rsp+0x90], xmm10
00007154327dd52f  vmovaps [rsp+0xA0], xmm11
00007154327dd538  vmovaps [rsp+0xB0], xmm12
00007154327dd541  vmovaps [rsp+0xC0], xmm13
00007154327dd54a  vmovaps [rsp+0xD0], xmm14
00007154327dd553  vmovaps [rsp+0xE0], xmm15
00007154327dd55c  sub rsp, 0x30
00007154327dd560  movaps [rsp], xmm1
00007154327dd564  movaps [rsp+0x10], xmm6
00007154327dd569  movaps [rsp+0x20], xmm15
00007154327dd56f  lea rdi, [rsp]
00007154327dd573  mov esi, 0x00
00007154327dd578  mov rax, 0x5A63B06A5530
00007154327dd582  call rax
00007154327dd584  movaps xmm1, [rsp]
00007154327dd588  add rsp, 0x30
00007154327dd58c  vmovaps xmm0, [rsp]
00007154327dd591  vmovaps xmm2, [rsp+0x10]
00007154327dd597  vmovaps xmm3, [rsp+0x20]
00007154327dd59d  vmovaps xmm4, [rsp+0x30]
00007154327dd5a3  vmovaps xmm5, [rsp+0x40]
00007154327dd5a9  vmovaps xmm6, [rsp+0x50]
00007154327dd5af  vmovaps xmm7, [rsp+0x60]
00007154327dd5b5  vmovaps xmm8, [rsp+0x70]
00007154327dd5bb  vmovaps xmm9, [rsp+0x80]
00007154327dd5c4  vmovaps xmm10, [rsp+0x90]
00007154327dd5cd  vmovaps xmm11, [rsp+0xA0]
00007154327dd5d6  vmovaps xmm12, [rsp+0xB0]
00007154327dd5df  vmovaps xmm13, [rsp+0xC0]
00007154327dd5e8  vmovaps xmm14, [rsp+0xD0]
00007154327dd5f1  vmovaps xmm15, [rsp+0xE0]
00007154327dd5fa  add rsp, 0xF0
00007154327dd601  pop r11
00007154327dd603  pop r10
00007154327dd605  pop r9
00007154327dd607  pop r8
00007154327dd609  pop rsi
00007154327dd60a  pop rdi
00007154327dd60b  pop rdx
00007154327dd60c  pop rcx
00007154327dd60d  pop rax
00007154327dd60e  add rsp, 0x08
00007154327dd612  jmp 0x00007154327DBE1B
00007154327dd617  call 0x00007154326C4620
00007154327dd61c  jmp 0x00007154327DBE28
00007154327dd621  sub rsp, 0x08
00007154327dd625  push rax
00007154327dd626  push rcx
00007154327dd627  push rdx
00007154327dd628  push rdi
00007154327dd629  push rsi
00007154327dd62a  push r8
00007154327dd62c  push r9
00007154327dd62e  push r10
00007154327dd630  push r11
00007154327dd632  sub rsp, 0xF0
00007154327dd639  vmovaps [rsp], xmm0
00007154327dd63e  vmovaps [rsp+0x10], xmm1
00007154327dd644  vmovaps [rsp+0x20], xmm2
00007154327dd64a  vmovaps [rsp+0x30], xmm3
00007154327dd650  vmovaps [rsp+0x40], xmm4
00007154327dd656  vmovaps [rsp+0x50], xmm5
00007154327dd65c  vmovaps [rsp+0x60], xmm6
00007154327dd662  vmovaps [rsp+0x70], xmm7
00007154327dd668  vmovaps [rsp+0x80], xmm8
00007154327dd671  vmovaps [rsp+0x90], xmm9
00007154327dd67a  vmovaps [rsp+0xA0], xmm10
00007154327dd683  vmovaps [rsp+0xB0], xmm11
00007154327dd68c  vmovaps [rsp+0xC0], xmm12
00007154327dd695  vmovaps [rsp+0xD0], xmm13
00007154327dd69e  vmovaps [rsp+0xE0], xmm15
00007154327dd6a7  sub rsp, 0x30
00007154327dd6ab  movaps [rsp], xmm14
00007154327dd6b0  movaps [rsp+0x10], xmm4
00007154327dd6b5  movaps [rsp+0x20], xmm3
00007154327dd6ba  lea rdi, [rsp]
00007154327dd6be  mov esi, 0x00
00007154327dd6c3  mov rax, 0x5A63B06A5530
00007154327dd6cd  call rax
00007154327dd6cf  movaps xmm14, [rsp]
00007154327dd6d4  add rsp, 0x30
00007154327dd6d8  vmovaps xmm0, [rsp]
00007154327dd6dd  vmovaps xmm1, [rsp+0x10]
00007154327dd6e3  vmovaps xmm2, [rsp+0x20]
00007154327dd6e9  vmovaps xmm3, [rsp+0x30]
00007154327dd6ef  vmovaps xmm4, [rsp+0x40]
00007154327dd6f5  vmovaps xmm5, [rsp+0x50]
00007154327dd6fb  vmovaps xmm6, [rsp+0x60]
00007154327dd701  vmovaps xmm7, [rsp+0x70]
00007154327dd707  vmovaps xmm8, [rsp+0x80]
00007154327dd710  vmovaps xmm9, [rsp+0x90]
00007154327dd719  vmovaps xmm10, [rsp+0xA0]
00007154327dd722  vmovaps xmm11, [rsp+0xB0]
00007154327dd72b  vmovaps xmm12, [rsp+0xC0]
00007154327dd734  vmovaps xmm13, [rsp+0xD0]
00007154327dd73d  vmovaps xmm15, [rsp+0xE0]
00007154327dd746  add rsp, 0xF0
00007154327dd74d  pop r11
00007154327dd74f  pop r10
00007154327dd751  pop r9
00007154327dd753  pop r8
00007154327dd755  pop rsi
00007154327dd756  pop rdi
00007154327dd757  pop rdx
00007154327dd758  pop rcx
00007154327dd759  pop rax
00007154327dd75a  add rsp, 0x08
00007154327dd75e  jmp 0x00007154327DBE42
00007154327dd763  sub rsp, 0x08
00007154327dd767  push rax
00007154327dd768  push rcx
00007154327dd769  push rdx
00007154327dd76a  push rdi
00007154327dd76b  push rsi
00007154327dd76c  push r8
00007154327dd76e  push r9
00007154327dd770  push r10
00007154327dd772  push r11
00007154327dd774  sub rsp, 0xF0
00007154327dd77b  vmovaps [rsp], xmm0
00007154327dd780  vmovaps [rsp+0x10], xmm1
00007154327dd786  vmovaps [rsp+0x20], xmm2
00007154327dd78c  vmovaps [rsp+0x30], xmm3
00007154327dd792  vmovaps [rsp+0x40], xmm4
00007154327dd798  vmovaps [rsp+0x50], xmm5
00007154327dd79e  vmovaps [rsp+0x60], xmm7
00007154327dd7a4  vmovaps [rsp+0x70], xmm8
00007154327dd7aa  vmovaps [rsp+0x80], xmm9
00007154327dd7b3  vmovaps [rsp+0x90], xmm10
00007154327dd7bc  vmovaps [rsp+0xA0], xmm11
00007154327dd7c5  vmovaps [rsp+0xB0], xmm12
00007154327dd7ce  vmovaps [rsp+0xC0], xmm13
00007154327dd7d7  vmovaps [rsp+0xD0], xmm14
00007154327dd7e0  vmovaps [rsp+0xE0], xmm15
00007154327dd7e9  sub rsp, 0x30
00007154327dd7ed  movaps [rsp], xmm6
00007154327dd7f1  movaps [rsp+0x10], xmm9
00007154327dd7f7  movaps [rsp+0x20], xmm7
00007154327dd7fc  lea rdi, [rsp]
00007154327dd800  mov esi, 0x00
00007154327dd805  mov rax, 0x5A63B06A5530
00007154327dd80f  call rax
00007154327dd811  movaps xmm6, [rsp]
00007154327dd815  add rsp, 0x30
00007154327dd819  vmovaps xmm0, [rsp]
00007154327dd81e  vmovaps xmm1, [rsp+0x10]
00007154327dd824  vmovaps xmm2, [rsp+0x20]
00007154327dd82a  vmovaps xmm3, [rsp+0x30]
00007154327dd830  vmovaps xmm4, [rsp+0x40]
00007154327dd836  vmovaps xmm5, [rsp+0x50]
00007154327dd83c  vmovaps xmm7, [rsp+0x60]
00007154327dd842  vmovaps xmm8, [rsp+0x70]
00007154327dd848  vmovaps xmm9, [rsp+0x80]
00007154327dd851  vmovaps xmm10, [rsp+0x90]
00007154327dd85a  vmovaps xmm11, [rsp+0xA0]
00007154327dd863  vmovaps xmm12, [rsp+0xB0]
00007154327dd86c  vmovaps xmm13, [rsp+0xC0]
00007154327dd875  vmovaps xmm14, [rsp+0xD0]
00007154327dd87e  vmovaps xmm15, [rsp+0xE0]
00007154327dd887  add rsp, 0xF0
00007154327dd88e  pop r11
00007154327dd890  pop r10
00007154327dd892  pop r9
00007154327dd894  pop r8
00007154327dd896  pop rsi
00007154327dd897  pop rdi
00007154327dd898  pop rdx
00007154327dd899  pop rcx
00007154327dd89a  pop rax
00007154327dd89b  add rsp, 0x08
00007154327dd89f  jmp 0x00007154327DBE5A
00007154327dd8a4  sub rsp, 0x08
00007154327dd8a8  push rax
00007154327dd8a9  push rcx
00007154327dd8aa  push rdx
00007154327dd8ab  push rdi
00007154327dd8ac  push rsi
00007154327dd8ad  push r8
00007154327dd8af  push r9
00007154327dd8b1  push r10
00007154327dd8b3  push r11
00007154327dd8b5  sub rsp, 0xF0
00007154327dd8bc  vmovaps [rsp], xmm0
00007154327dd8c1  vmovaps [rsp+0x10], xmm1
00007154327dd8c7  vmovaps [rsp+0x20], xmm2
00007154327dd8cd  vmovaps [rsp+0x30], xmm3
00007154327dd8d3  vmovaps [rsp+0x40], xmm4
00007154327dd8d9  vmovaps [rsp+0x50], xmm5
00007154327dd8df  vmovaps [rsp+0x60], xmm6
00007154327dd8e5  vmovaps [rsp+0x70], xmm8
00007154327dd8eb  vmovaps [rsp+0x80], xmm9
00007154327dd8f4  vmovaps [rsp+0x90], xmm10
00007154327dd8fd  vmovaps [rsp+0xA0], xmm11
00007154327dd906  vmovaps [rsp+0xB0], xmm12
00007154327dd90f  vmovaps [rsp+0xC0], xmm13
00007154327dd918  vmovaps [rsp+0xD0], xmm14
00007154327dd921  vmovaps [rsp+0xE0], xmm15
00007154327dd92a  sub rsp, 0x30
00007154327dd92e  movaps [rsp], xmm7
00007154327dd932  movaps [rsp+0x10], xmm4
00007154327dd937  movaps [rsp+0x20], xmm9
00007154327dd93d  lea rdi, [rsp]
00007154327dd941  mov esi, 0x00
00007154327dd946  mov rax, 0x5A63B06A5530
00007154327dd950  call rax
00007154327dd952  movaps xmm7, [rsp]
00007154327dd956  add rsp, 0x30
00007154327dd95a  vmovaps xmm0, [rsp]
00007154327dd95f  vmovaps xmm1, [rsp+0x10]
00007154327dd965  vmovaps xmm2, [rsp+0x20]
00007154327dd96b  vmovaps xmm3, [rsp+0x30]
00007154327dd971  vmovaps xmm4, [rsp+0x40]
00007154327dd977  vmovaps xmm5, [rsp+0x50]
00007154327dd97d  vmovaps xmm6, [rsp+0x60]
00007154327dd983  vmovaps xmm8, [rsp+0x70]
00007154327dd989  vmovaps xmm9, [rsp+0x80]
00007154327dd992  vmovaps xmm10, [rsp+0x90]
00007154327dd99b  vmovaps xmm11, [rsp+0xA0]
00007154327dd9a4  vmovaps xmm12, [rsp+0xB0]
00007154327dd9ad  vmovaps xmm13, [rsp+0xC0]
00007154327dd9b6  vmovaps xmm14, [rsp+0xD0]
00007154327dd9bf  vmovaps xmm15, [rsp+0xE0]
00007154327dd9c8  add rsp, 0xF0
00007154327dd9cf  pop r11
00007154327dd9d1  pop r10
00007154327dd9d3  pop r9
00007154327dd9d5  pop r8
00007154327dd9d7  pop rsi
00007154327dd9d8  pop rdi
00007154327dd9d9  pop rdx
00007154327dd9da  pop rcx
00007154327dd9db  pop rax
00007154327dd9dc  add rsp, 0x08
00007154327dd9e0  jmp 0x00007154327DBE87
00007154327dd9e5  sub rsp, 0x08
00007154327dd9e9  push rax
00007154327dd9ea  push rcx
00007154327dd9eb  push rdx
00007154327dd9ec  push rdi
00007154327dd9ed  push rsi
00007154327dd9ee  push r8
00007154327dd9f0  push r9
00007154327dd9f2  push r10
00007154327dd9f4  push r11
00007154327dd9f6  sub rsp, 0xF0
00007154327dd9fd  vmovaps [rsp], xmm0
00007154327dda02  vmovaps [rsp+0x10], xmm1
00007154327dda08  vmovaps [rsp+0x20], xmm2
00007154327dda0e  vmovaps [rsp+0x30], xmm3
00007154327dda14  vmovaps [rsp+0x40], xmm5
00007154327dda1a  vmovaps [rsp+0x50], xmm6
00007154327dda20  vmovaps [rsp+0x60], xmm7
00007154327dda26  vmovaps [rsp+0x70], xmm8
00007154327dda2c  vmovaps [rsp+0x80], xmm9
00007154327dda35  vmovaps [rsp+0x90], xmm10
00007154327dda3e  vmovaps [rsp+0xA0], xmm11
00007154327dda47  vmovaps [rsp+0xB0], xmm12
00007154327dda50  vmovaps [rsp+0xC0], xmm13
00007154327dda59  vmovaps [rsp+0xD0], xmm14
00007154327dda62  vmovaps [rsp+0xE0], xmm15
00007154327dda6b  sub rsp, 0x30
00007154327dda6f  movaps [rsp], xmm4
00007154327dda73  movaps [rsp+0x10], xmm15
00007154327dda79  movaps [rsp+0x20], xmm9
00007154327dda7f  lea rdi, [rsp]
00007154327dda83  mov esi, 0x00
00007154327dda88  mov rax, 0x5A63B06A5530
00007154327dda92  call rax
00007154327dda94  movaps xmm4, [rsp]
00007154327dda98  add rsp, 0x30
00007154327dda9c  vmovaps xmm0, [rsp]
00007154327ddaa1  vmovaps xmm1, [rsp+0x10]
00007154327ddaa7  vmovaps xmm2, [rsp+0x20]
00007154327ddaad  vmovaps xmm3, [rsp+0x30]
00007154327ddab3  vmovaps xmm5, [rsp+0x40]
00007154327ddab9  vmovaps xmm6, [rsp+0x50]
00007154327ddabf  vmovaps xmm7, [rsp+0x60]
00007154327ddac5  vmovaps xmm8, [rsp+0x70]
00007154327ddacb  vmovaps xmm9, [rsp+0x80]
00007154327ddad4  vmovaps xmm10, [rsp+0x90]
00007154327ddadd  vmovaps xmm11, [rsp+0xA0]
00007154327ddae6  vmovaps xmm12, [rsp+0xB0]
00007154327ddaef  vmovaps xmm13, [rsp+0xC0]
00007154327ddaf8  vmovaps xmm14, [rsp+0xD0]
00007154327ddb01  vmovaps xmm15, [rsp+0xE0]
00007154327ddb0a  add rsp, 0xF0
00007154327ddb11  pop r11
00007154327ddb13  pop r10
00007154327ddb15  pop r9
00007154327ddb17  pop r8
00007154327ddb19  pop rsi
00007154327ddb1a  pop rdi
00007154327ddb1b  pop rdx
00007154327ddb1c  pop rcx
00007154327ddb1d  pop rax
00007154327ddb1e  add rsp, 0x08
00007154327ddb22  jmp 0x00007154327DBEAC
00007154327ddb27  call 0x00007154326C4620
00007154327ddb2c  jmp 0x00007154327DBEB9
00007154327ddb31  sub rsp, 0x08
00007154327ddb35  push rax
00007154327ddb36  push rcx
00007154327ddb37  push rdx
00007154327ddb38  push rdi
00007154327ddb39  push rsi
00007154327ddb3a  push r8
00007154327ddb3c  push r9
00007154327ddb3e  push r10
00007154327ddb40  push r11
00007154327ddb42  sub rsp, 0xF0
00007154327ddb49  vmovaps [rsp], xmm0
00007154327ddb4e  vmovaps [rsp+0x10], xmm1
00007154327ddb54  vmovaps [rsp+0x20], xmm2
00007154327ddb5a  vmovaps [rsp+0x30], xmm4
00007154327ddb60  vmovaps [rsp+0x40], xmm5
00007154327ddb66  vmovaps [rsp+0x50], xmm6
00007154327ddb6c  vmovaps [rsp+0x60], xmm7
00007154327ddb72  vmovaps [rsp+0x70], xmm8
00007154327ddb78  vmovaps [rsp+0x80], xmm9
00007154327ddb81  vmovaps [rsp+0x90], xmm10
00007154327ddb8a  vmovaps [rsp+0xA0], xmm11
00007154327ddb93  vmovaps [rsp+0xB0], xmm12
00007154327ddb9c  vmovaps [rsp+0xC0], xmm13
00007154327ddba5  vmovaps [rsp+0xD0], xmm14
00007154327ddbae  vmovaps [rsp+0xE0], xmm15
00007154327ddbb7  sub rsp, 0x30
00007154327ddbbb  movaps [rsp], xmm3
00007154327ddbbf  movaps [rsp+0x10], xmm1
00007154327ddbc4  movaps [rsp+0x20], xmm9
00007154327ddbca  lea rdi, [rsp]
00007154327ddbce  mov esi, 0x00
00007154327ddbd3  mov rax, 0x5A63B06A5530
00007154327ddbdd  call rax
00007154327ddbdf  movaps xmm3, [rsp]
00007154327ddbe3  add rsp, 0x30
00007154327ddbe7  vmovaps xmm0, [rsp]
00007154327ddbec  vmovaps xmm1, [rsp+0x10]
00007154327ddbf2  vmovaps xmm2, [rsp+0x20]
00007154327ddbf8  vmovaps xmm4, [rsp+0x30]
00007154327ddbfe  vmovaps xmm5, [rsp+0x40]
00007154327ddc04  vmovaps xmm6, [rsp+0x50]
00007154327ddc0a  vmovaps xmm7, [rsp+0x60]
00007154327ddc10  vmovaps xmm8, [rsp+0x70]
00007154327ddc16  vmovaps xmm9, [rsp+0x80]
00007154327ddc1f  vmovaps xmm10, [rsp+0x90]
00007154327ddc28  vmovaps xmm11, [rsp+0xA0]
00007154327ddc31  vmovaps xmm12, [rsp+0xB0]
00007154327ddc3a  vmovaps xmm13, [rsp+0xC0]
00007154327ddc43  vmovaps xmm14, [rsp+0xD0]
00007154327ddc4c  vmovaps xmm15, [rsp+0xE0]
00007154327ddc55  add rsp, 0xF0
00007154327ddc5c  pop r11
00007154327ddc5e  pop r10
00007154327ddc60  pop r9
00007154327ddc62  pop r8
00007154327ddc64  pop rsi
00007154327ddc65  pop rdi
00007154327ddc66  pop rdx
00007154327ddc67  pop rcx
00007154327ddc68  pop rax
00007154327ddc69  add rsp, 0x08
00007154327ddc6d  jmp 0x00007154327DBEF6
00007154327ddc72  sub rsp, 0x08
00007154327ddc76  push rax
00007154327ddc77  push rcx
00007154327ddc78  push rdx
00007154327ddc79  push rdi
00007154327ddc7a  push rsi
00007154327ddc7b  push r8
00007154327ddc7d  push r9
00007154327ddc7f  push r10
00007154327ddc81  push r11
00007154327ddc83  sub rsp, 0xF0
00007154327ddc8a  vmovaps [rsp], xmm0
00007154327ddc8f  vmovaps [rsp+0x10], xmm2
00007154327ddc95  vmovaps [rsp+0x20], xmm3
00007154327ddc9b  vmovaps [rsp+0x30], xmm4
00007154327ddca1  vmovaps [rsp+0x40], xmm5
00007154327ddca7  vmovaps [rsp+0x50], xmm6
00007154327ddcad  vmovaps [rsp+0x60], xmm7
00007154327ddcb3  vmovaps [rsp+0x70], xmm8
00007154327ddcb9  vmovaps [rsp+0x80], xmm9
00007154327ddcc2  vmovaps [rsp+0x90], xmm10
00007154327ddccb  vmovaps [rsp+0xA0], xmm11
00007154327ddcd4  vmovaps [rsp+0xB0], xmm12
00007154327ddcdd  vmovaps [rsp+0xC0], xmm13
00007154327ddce6  vmovaps [rsp+0xD0], xmm14
00007154327ddcef  vmovaps [rsp+0xE0], xmm15
00007154327ddcf8  sub rsp, 0x30
00007154327ddcfc  movaps [rsp], xmm1
00007154327ddd00  movaps [rsp+0x10], xmm15
00007154327ddd06  movaps [rsp+0x20], xmm9
00007154327ddd0c  lea rdi, [rsp]
00007154327ddd10  mov esi, 0x00
00007154327ddd15  mov rax, 0x5A63B06A5530
00007154327ddd1f  call rax
00007154327ddd21  movaps xmm1, [rsp]
00007154327ddd25  add rsp, 0x30
00007154327ddd29  vmovaps xmm0, [rsp]
00007154327ddd2e  vmovaps xmm2, [rsp+0x10]
00007154327ddd34  vmovaps xmm3, [rsp+0x20]
00007154327ddd3a  vmovaps xmm4, [rsp+0x30]
00007154327ddd40  vmovaps xmm5, [rsp+0x40]
00007154327ddd46  vmovaps xmm6, [rsp+0x50]
00007154327ddd4c  vmovaps xmm7, [rsp+0x60]
00007154327ddd52  vmovaps xmm8, [rsp+0x70]
00007154327ddd58  vmovaps xmm9, [rsp+0x80]
00007154327ddd61  vmovaps xmm10, [rsp+0x90]
00007154327ddd6a  vmovaps xmm11, [rsp+0xA0]
00007154327ddd73  vmovaps xmm12, [rsp+0xB0]
00007154327ddd7c  vmovaps xmm13, [rsp+0xC0]
00007154327ddd85  vmovaps xmm14, [rsp+0xD0]
00007154327ddd8e  vmovaps xmm15, [rsp+0xE0]
00007154327ddd97  add rsp, 0xF0
00007154327ddd9e  pop r11
00007154327ddda0  pop r10
00007154327ddda2  pop r9
00007154327ddda4  pop r8
00007154327ddda6  pop rsi
00007154327ddda7  pop rdi
00007154327ddda8  pop rdx
00007154327ddda9  pop rcx
00007154327dddaa  pop rax
00007154327dddab  add rsp, 0x08
00007154327dddaf  jmp 0x00007154327DBF7E
00007154327dddb4  call 0x00007154326C4620
00007154327dddb9  jmp 0x00007154327DBF8B
00007154327dddbe  sub rsp, 0x08
00007154327dddc2  push rax
00007154327dddc3  push rcx
00007154327dddc4  push rdx
00007154327dddc5  push rdi
00007154327dddc6  push rsi
00007154327dddc7  push r8
00007154327dddc9  push r9
00007154327dddcb  push r10
00007154327dddcd  push r11
00007154327dddcf  sub rsp, 0xF0
00007154327dddd6  vmovaps [rsp], xmm0
00007154327ddddb  vmovaps [rsp+0x10], xmm2
00007154327ddde1  vmovaps [rsp+0x20], xmm3
00007154327ddde7  vmovaps [rsp+0x30], xmm4
00007154327ddded  vmovaps [rsp+0x40], xmm5
00007154327dddf3  vmovaps [rsp+0x50], xmm6
00007154327dddf9  vmovaps [rsp+0x60], xmm7
00007154327dddff  vmovaps [rsp+0x70], xmm8
00007154327dde05  vmovaps [rsp+0x80], xmm9
00007154327dde0e  vmovaps [rsp+0x90], xmm10
00007154327dde17  vmovaps [rsp+0xA0], xmm11
00007154327dde20  vmovaps [rsp+0xB0], xmm12
00007154327dde29  vmovaps [rsp+0xC0], xmm13
00007154327dde32  vmovaps [rsp+0xD0], xmm14
00007154327dde3b  vmovaps [rsp+0xE0], xmm15
00007154327dde44  sub rsp, 0x30
00007154327dde48  movaps [rsp], xmm1
00007154327dde4c  movaps [rsp+0x10], xmm5
00007154327dde51  movaps [rsp+0x20], xmm7
00007154327dde56  lea rdi, [rsp]
00007154327dde5a  mov esi, 0x00
00007154327dde5f  mov rax, 0x5A63B06A5530
00007154327dde69  call rax
00007154327dde6b  movaps xmm1, [rsp]
00007154327dde6f  add rsp, 0x30
00007154327dde73  vmovaps xmm0, [rsp]
00007154327dde78  vmovaps xmm2, [rsp+0x10]
00007154327dde7e  vmovaps xmm3, [rsp+0x20]
00007154327dde84  vmovaps xmm4, [rsp+0x30]
00007154327dde8a  vmovaps xmm5, [rsp+0x40]
00007154327dde90  vmovaps xmm6, [rsp+0x50]
00007154327dde96  vmovaps xmm7, [rsp+0x60]
00007154327dde9c  vmovaps xmm8, [rsp+0x70]
00007154327ddea2  vmovaps xmm9, [rsp+0x80]
00007154327ddeab  vmovaps xmm10, [rsp+0x90]
00007154327ddeb4  vmovaps xmm11, [rsp+0xA0]
00007154327ddebd  vmovaps xmm12, [rsp+0xB0]
00007154327ddec6  vmovaps xmm13, [rsp+0xC0]
00007154327ddecf  vmovaps xmm14, [rsp+0xD0]
00007154327dded8  vmovaps xmm15, [rsp+0xE0]
00007154327ddee1  add rsp, 0xF0
00007154327ddee8  pop r11
00007154327ddeea  pop r10
00007154327ddeec  pop r9
00007154327ddeee  pop r8
00007154327ddef0  pop rsi
00007154327ddef1  pop rdi
00007154327ddef2  pop rdx
00007154327ddef3  pop rcx
00007154327ddef4  pop rax
00007154327ddef5  add rsp, 0x08
00007154327ddef9  jmp 0x00007154327DC030
00007154327ddefe  sub rsp, 0x08
00007154327ddf02  push rax
00007154327ddf03  push rcx
00007154327ddf04  push rdx
00007154327ddf05  push rdi
00007154327ddf06  push rsi
00007154327ddf07  push r8
00007154327ddf09  push r9
00007154327ddf0b  push r10
00007154327ddf0d  push r11
00007154327ddf0f  sub rsp, 0xF0
00007154327ddf16  vmovaps [rsp], xmm0
00007154327ddf1b  vmovaps [rsp+0x10], xmm1
00007154327ddf21  vmovaps [rsp+0x20], xmm2
00007154327ddf27  vmovaps [rsp+0x30], xmm3
00007154327ddf2d  vmovaps [rsp+0x40], xmm4
00007154327ddf33  vmovaps [rsp+0x50], xmm5
00007154327ddf39  vmovaps [rsp+0x60], xmm6
00007154327ddf3f  vmovaps [rsp+0x70], xmm8
00007154327ddf45  vmovaps [rsp+0x80], xmm9
00007154327ddf4e  vmovaps [rsp+0x90], xmm10
00007154327ddf57  vmovaps [rsp+0xA0], xmm11
00007154327ddf60  vmovaps [rsp+0xB0], xmm12
00007154327ddf69  vmovaps [rsp+0xC0], xmm13
00007154327ddf72  vmovaps [rsp+0xD0], xmm14
00007154327ddf7b  vmovaps [rsp+0xE0], xmm15
00007154327ddf84  sub rsp, 0x30
00007154327ddf88  movaps [rsp], xmm7
00007154327ddf8c  movaps [rsp+0x10], xmm5
00007154327ddf91  movaps [rsp+0x20], xmm15
00007154327ddf97  lea rdi, [rsp]
00007154327ddf9b  mov esi, 0x00
00007154327ddfa0  mov rax, 0x5A63B06A5530
00007154327ddfaa  call rax
00007154327ddfac  movaps xmm7, [rsp]
00007154327ddfb0  add rsp, 0x30
00007154327ddfb4  vmovaps xmm0, [rsp]
00007154327ddfb9  vmovaps xmm1, [rsp+0x10]
00007154327ddfbf  vmovaps xmm2, [rsp+0x20]
00007154327ddfc5  vmovaps xmm3, [rsp+0x30]
00007154327ddfcb  vmovaps xmm4, [rsp+0x40]
00007154327ddfd1  vmovaps xmm5, [rsp+0x50]
00007154327ddfd7  vmovaps xmm6, [rsp+0x60]
00007154327ddfdd  vmovaps xmm8, [rsp+0x70]
00007154327ddfe3  vmovaps xmm9, [rsp+0x80]
00007154327ddfec  vmovaps xmm10, [rsp+0x90]
00007154327ddff5  vmovaps xmm11, [rsp+0xA0]
00007154327ddffe  vmovaps xmm12, [rsp+0xB0]
00007154327de007  vmovaps xmm13, [rsp+0xC0]
00007154327de010  vmovaps xmm14, [rsp+0xD0]
00007154327de019  vmovaps xmm15, [rsp+0xE0]
00007154327de022  add rsp, 0xF0
00007154327de029  pop r11
00007154327de02b  pop r10
00007154327de02d  pop r9
00007154327de02f  pop r8
00007154327de031  pop rsi
00007154327de032  pop rdi
00007154327de033  pop rdx
00007154327de034  pop rcx
00007154327de035  pop rax
00007154327de036  add rsp, 0x08
00007154327de03a  jmp 0x00007154327DC066
00007154327de03f  call 0x00007154326B52F0
00007154327de044  jmp 0x00007154327DC073
00007154327de049  sub rsp, 0x08
00007154327de04d  push rax
00007154327de04e  push rcx
00007154327de04f  push rdx
00007154327de050  push rdi
00007154327de051  push rsi
00007154327de052  push r8
00007154327de054  push r9
00007154327de056  push r10
00007154327de058  push r11
00007154327de05a  sub rsp, 0xF0
00007154327de061  vmovaps [rsp], xmm0
00007154327de066  vmovaps [rsp+0x10], xmm1
00007154327de06c  vmovaps [rsp+0x20], xmm2
00007154327de072  vmovaps [rsp+0x30], xmm3
00007154327de078  vmovaps [rsp+0x40], xmm4
00007154327de07e  vmovaps [rsp+0x50], xmm5
00007154327de084  vmovaps [rsp+0x60], xmm6
00007154327de08a  vmovaps [rsp+0x70], xmm7
00007154327de090  vmovaps [rsp+0x80], xmm8
00007154327de099  vmovaps [rsp+0x90], xmm9
00007154327de0a2  vmovaps [rsp+0xA0], xmm10
00007154327de0ab  vmovaps [rsp+0xB0], xmm11
00007154327de0b4  vmovaps [rsp+0xC0], xmm12
00007154327de0bd  vmovaps [rsp+0xD0], xmm13
00007154327de0c6  vmovaps [rsp+0xE0], xmm14
00007154327de0cf  sub rsp, 0x30
00007154327de0d3  movaps [rsp], xmm15
00007154327de0d8  movaps [rsp+0x10], xmm5
00007154327de0dd  movaps [rsp+0x20], xmm3
00007154327de0e2  lea rdi, [rsp]
00007154327de0e6  mov esi, 0x00
00007154327de0eb  mov rax, 0x5A63B06A5530
00007154327de0f5  call rax
00007154327de0f7  movaps xmm15, [rsp]
00007154327de0fc  add rsp, 0x30
00007154327de100  vmovaps xmm0, [rsp]
00007154327de105  vmovaps xmm1, [rsp+0x10]
00007154327de10b  vmovaps xmm2, [rsp+0x20]
00007154327de111  vmovaps xmm3, [rsp+0x30]
00007154327de117  vmovaps xmm4, [rsp+0x40]
00007154327de11d  vmovaps xmm5, [rsp+0x50]
00007154327de123  vmovaps xmm6, [rsp+0x60]
00007154327de129  vmovaps xmm7, [rsp+0x70]
00007154327de12f  vmovaps xmm8, [rsp+0x80]
00007154327de138  vmovaps xmm9, [rsp+0x90]
00007154327de141  vmovaps xmm10, [rsp+0xA0]
00007154327de14a  vmovaps xmm11, [rsp+0xB0]
00007154327de153  vmovaps xmm12, [rsp+0xC0]
00007154327de15c  vmovaps xmm13, [rsp+0xD0]
00007154327de165  vmovaps xmm14, [rsp+0xE0]
00007154327de16e  add rsp, 0xF0
00007154327de175  pop r11
00007154327de177  pop r10
00007154327de179  pop r9
00007154327de17b  pop r8
00007154327de17d  pop rsi
00007154327de17e  pop rdi
00007154327de17f  pop rdx
00007154327de180  pop rcx
00007154327de181  pop rax
00007154327de182  add rsp, 0x08
00007154327de186  jmp 0x00007154327DC099
00007154327de18b  sub rsp, 0x08
00007154327de18f  push rax
00007154327de190  push rcx
00007154327de191  push rdx
00007154327de192  push rdi
00007154327de193  push rsi
00007154327de194  push r8
00007154327de196  push r9
00007154327de198  push r10
00007154327de19a  push r11
00007154327de19c  sub rsp, 0xF0
00007154327de1a3  vmovaps [rsp], xmm0
00007154327de1a8  vmovaps [rsp+0x10], xmm2
00007154327de1ae  vmovaps [rsp+0x20], xmm3
00007154327de1b4  vmovaps [rsp+0x30], xmm4
00007154327de1ba  vmovaps [rsp+0x40], xmm5
00007154327de1c0  vmovaps [rsp+0x50], xmm6
00007154327de1c6  vmovaps [rsp+0x60], xmm7
00007154327de1cc  vmovaps [rsp+0x70], xmm8
00007154327de1d2  vmovaps [rsp+0x80], xmm9
00007154327de1db  vmovaps [rsp+0x90], xmm10
00007154327de1e4  vmovaps [rsp+0xA0], xmm11
00007154327de1ed  vmovaps [rsp+0xB0], xmm12
00007154327de1f6  vmovaps [rsp+0xC0], xmm13
00007154327de1ff  vmovaps [rsp+0xD0], xmm14
00007154327de208  vmovaps [rsp+0xE0], xmm15
00007154327de211  sub rsp, 0x30
00007154327de215  movaps [rsp], xmm1
00007154327de219  movaps [rsp+0x10], xmm5
00007154327de21e  movaps [rsp+0x20], xmm4
00007154327de223  lea rdi, [rsp]
00007154327de227  mov esi, 0x00
00007154327de22c  mov rax, 0x5A63B06A5530
00007154327de236  call rax
00007154327de238  movaps xmm1, [rsp]
00007154327de23c  add rsp, 0x30
00007154327de240  vmovaps xmm0, [rsp]
00007154327de245  vmovaps xmm2, [rsp+0x10]
00007154327de24b  vmovaps xmm3, [rsp+0x20]
00007154327de251  vmovaps xmm4, [rsp+0x30]
00007154327de257  vmovaps xmm5, [rsp+0x40]
00007154327de25d  vmovaps xmm6, [rsp+0x50]
00007154327de263  vmovaps xmm7, [rsp+0x60]
00007154327de269  vmovaps xmm8, [rsp+0x70]
00007154327de26f  vmovaps xmm9, [rsp+0x80]
00007154327de278  vmovaps xmm10, [rsp+0x90]
00007154327de281  vmovaps xmm11, [rsp+0xA0]
00007154327de28a  vmovaps xmm12, [rsp+0xB0]
00007154327de293  vmovaps xmm13, [rsp+0xC0]
00007154327de29c  vmovaps xmm14, [rsp+0xD0]
00007154327de2a5  vmovaps xmm15, [rsp+0xE0]
00007154327de2ae  add rsp, 0xF0
00007154327de2b5  pop r11
00007154327de2b7  pop r10
00007154327de2b9  pop r9
00007154327de2bb  pop r8
00007154327de2bd  pop rsi
00007154327de2be  pop rdi
00007154327de2bf  pop rdx
00007154327de2c0  pop rcx
00007154327de2c1  pop rax
00007154327de2c2  add rsp, 0x08
00007154327de2c6  jmp 0x00007154327DC0B9
00007154327de2cb  sub rsp, 0x08
00007154327de2cf  push rax
00007154327de2d0  push rcx
00007154327de2d1  push rdx
00007154327de2d2  push rdi
00007154327de2d3  push rsi
00007154327de2d4  push r8
00007154327de2d6  push r9
00007154327de2d8  push r10
00007154327de2da  push r11
00007154327de2dc  sub rsp, 0xF0
00007154327de2e3  vmovaps [rsp], xmm0
00007154327de2e8  vmovaps [rsp+0x10], xmm1
00007154327de2ee  vmovaps [rsp+0x20], xmm2
00007154327de2f4  vmovaps [rsp+0x30], xmm3
00007154327de2fa  vmovaps [rsp+0x40], xmm5
00007154327de300  vmovaps [rsp+0x50], xmm6
00007154327de306  vmovaps [rsp+0x60], xmm7
00007154327de30c  vmovaps [rsp+0x70], xmm8
00007154327de312  vmovaps [rsp+0x80], xmm9
00007154327de31b  vmovaps [rsp+0x90], xmm10
00007154327de324  vmovaps [rsp+0xA0], xmm11
00007154327de32d  vmovaps [rsp+0xB0], xmm12
00007154327de336  vmovaps [rsp+0xC0], xmm13
00007154327de33f  vmovaps [rsp+0xD0], xmm14
00007154327de348  vmovaps [rsp+0xE0], xmm15
00007154327de351  sub rsp, 0x30
00007154327de355  movaps [rsp], xmm4
00007154327de359  movaps [rsp+0x10], xmm3
00007154327de35e  movaps [rsp+0x20], xmm5
00007154327de363  lea rdi, [rsp]
00007154327de367  mov esi, 0x00
00007154327de36c  mov rax, 0x5A63B06A5530
00007154327de376  call rax
00007154327de378  movaps xmm4, [rsp]
00007154327de37c  add rsp, 0x30
00007154327de380  vmovaps xmm0, [rsp]
00007154327de385  vmovaps xmm1, [rsp+0x10]
00007154327de38b  vmovaps xmm2, [rsp+0x20]
00007154327de391  vmovaps xmm3, [rsp+0x30]
00007154327de397  vmovaps xmm5, [rsp+0x40]
00007154327de39d  vmovaps xmm6, [rsp+0x50]
00007154327de3a3  vmovaps xmm7, [rsp+0x60]
00007154327de3a9  vmovaps xmm8, [rsp+0x70]
00007154327de3af  vmovaps xmm9, [rsp+0x80]
00007154327de3b8  vmovaps xmm10, [rsp+0x90]
00007154327de3c1  vmovaps xmm11, [rsp+0xA0]
00007154327de3ca  vmovaps xmm12, [rsp+0xB0]
00007154327de3d3  vmovaps xmm13, [rsp+0xC0]
00007154327de3dc  vmovaps xmm14, [rsp+0xD0]
00007154327de3e5  vmovaps xmm15, [rsp+0xE0]
00007154327de3ee  add rsp, 0xF0
00007154327de3f5  pop r11
00007154327de3f7  pop r10
00007154327de3f9  pop r9
00007154327de3fb  pop r8
00007154327de3fd  pop rsi
00007154327de3fe  pop rdi
00007154327de3ff  pop rdx
00007154327de400  pop rcx
00007154327de401  pop rax
00007154327de402  add rsp, 0x08
00007154327de406  jmp 0x00007154327DC107
00007154327de40b  call 0x00007154326B52F0
00007154327de410  jmp 0x00007154327DC114
00007154327de415  sub rsp, 0x08
00007154327de419  push rax
00007154327de41a  push rcx
00007154327de41b  push rdx
00007154327de41c  push rdi
00007154327de41d  push rsi
00007154327de41e  push r8
00007154327de420  push r9
00007154327de422  push r10
00007154327de424  push r11
00007154327de426  sub rsp, 0xF0
00007154327de42d  vmovaps [rsp], xmm0
00007154327de432  vmovaps [rsp+0x10], xmm1
00007154327de438  vmovaps [rsp+0x20], xmm2
00007154327de43e  vmovaps [rsp+0x30], xmm3
00007154327de444  vmovaps [rsp+0x40], xmm4
00007154327de44a  vmovaps [rsp+0x50], xmm6
00007154327de450  vmovaps [rsp+0x60], xmm7
00007154327de456  vmovaps [rsp+0x70], xmm8
00007154327de45c  vmovaps [rsp+0x80], xmm9
00007154327de465  vmovaps [rsp+0x90], xmm10
00007154327de46e  vmovaps [rsp+0xA0], xmm11
00007154327de477  vmovaps [rsp+0xB0], xmm12
00007154327de480  vmovaps [rsp+0xC0], xmm13
00007154327de489  vmovaps [rsp+0xD0], xmm14
00007154327de492  vmovaps [rsp+0xE0], xmm15
00007154327de49b  sub rsp, 0x30
00007154327de49f  movaps [rsp], xmm5
00007154327de4a3  movaps [rsp+0x10], xmm6
00007154327de4a8  movaps [rsp+0x20], xmm3
00007154327de4ad  lea rdi, [rsp]
00007154327de4b1  mov esi, 0x00
00007154327de4b6  mov rax, 0x5A63B06A5530
00007154327de4c0  call rax
00007154327de4c2  movaps xmm5, [rsp]
00007154327de4c6  add rsp, 0x30
00007154327de4ca  vmovaps xmm0, [rsp]
00007154327de4cf  vmovaps xmm1, [rsp+0x10]
00007154327de4d5  vmovaps xmm2, [rsp+0x20]
00007154327de4db  vmovaps xmm3, [rsp+0x30]
00007154327de4e1  vmovaps xmm4, [rsp+0x40]
00007154327de4e7  vmovaps xmm6, [rsp+0x50]
00007154327de4ed  vmovaps xmm7, [rsp+0x60]
00007154327de4f3  vmovaps xmm8, [rsp+0x70]
00007154327de4f9  vmovaps xmm9, [rsp+0x80]
00007154327de502  vmovaps xmm10, [rsp+0x90]
00007154327de50b  vmovaps xmm11, [rsp+0xA0]
00007154327de514  vmovaps xmm12, [rsp+0xB0]
00007154327de51d  vmovaps xmm13, [rsp+0xC0]
00007154327de526  vmovaps xmm14, [rsp+0xD0]
00007154327de52f  vmovaps xmm15, [rsp+0xE0]
00007154327de538  add rsp, 0xF0
00007154327de53f  pop r11
00007154327de541  pop r10
00007154327de543  pop r9
00007154327de545  pop r8
00007154327de547  pop rsi
00007154327de548  pop rdi
00007154327de549  pop rdx
00007154327de54a  pop rcx
00007154327de54b  pop rax
00007154327de54c  add rsp, 0x08
00007154327de550  jmp 0x00007154327DC13A
00007154327de555  sub rsp, 0x08
00007154327de559  push rax
00007154327de55a  push rcx
00007154327de55b  push rdx
00007154327de55c  push rdi
00007154327de55d  push rsi
00007154327de55e  push r8
00007154327de560  push r9
00007154327de562  push r10
00007154327de564  push r11
00007154327de566  sub rsp, 0xF0
00007154327de56d  vmovaps [rsp], xmm0
00007154327de572  vmovaps [rsp+0x10], xmm1
00007154327de578  vmovaps [rsp+0x20], xmm2
00007154327de57e  vmovaps [rsp+0x30], xmm3
00007154327de584  vmovaps [rsp+0x40], xmm4
00007154327de58a  vmovaps [rsp+0x50], xmm5
00007154327de590  vmovaps [rsp+0x60], xmm7
00007154327de596  vmovaps [rsp+0x70], xmm8
00007154327de59c  vmovaps [rsp+0x80], xmm9
00007154327de5a5  vmovaps [rsp+0x90], xmm10
00007154327de5ae  vmovaps [rsp+0xA0], xmm11
00007154327de5b7  vmovaps [rsp+0xB0], xmm12
00007154327de5c0  vmovaps [rsp+0xC0], xmm13
00007154327de5c9  vmovaps [rsp+0xD0], xmm14
00007154327de5d2  vmovaps [rsp+0xE0], xmm15
00007154327de5db  sub rsp, 0x30
00007154327de5df  movaps [rsp], xmm6
00007154327de5e3  movaps [rsp+0x10], xmm9
00007154327de5e9  movaps [rsp+0x20], xmm1
00007154327de5ee  lea rdi, [rsp]
00007154327de5f2  mov esi, 0x00
00007154327de5f7  mov rax, 0x5A63B06A5530
00007154327de601  call rax
00007154327de603  movaps xmm6, [rsp]
00007154327de607  add rsp, 0x30
00007154327de60b  vmovaps xmm0, [rsp]
00007154327de610  vmovaps xmm1, [rsp+0x10]
00007154327de616  vmovaps xmm2, [rsp+0x20]
00007154327de61c  vmovaps xmm3, [rsp+0x30]
00007154327de622  vmovaps xmm4, [rsp+0x40]
00007154327de628  vmovaps xmm5, [rsp+0x50]
00007154327de62e  vmovaps xmm7, [rsp+0x60]
00007154327de634  vmovaps xmm8, [rsp+0x70]
00007154327de63a  vmovaps xmm9, [rsp+0x80]
00007154327de643  vmovaps xmm10, [rsp+0x90]
00007154327de64c  vmovaps xmm11, [rsp+0xA0]
00007154327de655  vmovaps xmm12, [rsp+0xB0]
00007154327de65e  vmovaps xmm13, [rsp+0xC0]
00007154327de667  vmovaps xmm14, [rsp+0xD0]
00007154327de670  vmovaps xmm15, [rsp+0xE0]
00007154327de679  add rsp, 0xF0
00007154327de680  pop r11
00007154327de682  pop r10
00007154327de684  pop r9
00007154327de686  pop r8
00007154327de688  pop rsi
00007154327de689  pop rdi
00007154327de68a  pop rdx
00007154327de68b  pop rcx
00007154327de68c  pop rax
00007154327de68d  add rsp, 0x08
00007154327de691  jmp 0x00007154327DC15E
00007154327de696  sub rsp, 0x08
00007154327de69a  push rax
00007154327de69b  push rcx
00007154327de69c  push rdx
00007154327de69d  push rdi
00007154327de69e  push rsi
00007154327de69f  push r8
00007154327de6a1  push r9
00007154327de6a3  push r10
00007154327de6a5  push r11
00007154327de6a7  sub rsp, 0xF0
00007154327de6ae  vmovaps [rsp], xmm0
00007154327de6b3  vmovaps [rsp+0x10], xmm1
00007154327de6b9  vmovaps [rsp+0x20], xmm2
00007154327de6bf  vmovaps [rsp+0x30], xmm3
00007154327de6c5  vmovaps [rsp+0x40], xmm4
00007154327de6cb  vmovaps [rsp+0x50], xmm5
00007154327de6d1  vmovaps [rsp+0x60], xmm6
00007154327de6d7  vmovaps [rsp+0x70], xmm7
00007154327de6dd  vmovaps [rsp+0x80], xmm8
00007154327de6e6  vmovaps [rsp+0x90], xmm10
00007154327de6ef  vmovaps [rsp+0xA0], xmm11
00007154327de6f8  vmovaps [rsp+0xB0], xmm12
00007154327de701  vmovaps [rsp+0xC0], xmm13
00007154327de70a  vmovaps [rsp+0xD0], xmm14
00007154327de713  vmovaps [rsp+0xE0], xmm15
00007154327de71c  sub rsp, 0x30
00007154327de720  movaps [rsp], xmm9
00007154327de725  movaps [rsp+0x10], xmm3
00007154327de72a  movaps [rsp+0x20], xmm1
00007154327de72f  lea rdi, [rsp]
00007154327de733  mov esi, 0x00
00007154327de738  mov rax, 0x5A63B06A5530
00007154327de742  call rax
00007154327de744  movaps xmm9, [rsp]
00007154327de749  add rsp, 0x30
00007154327de74d  vmovaps xmm0, [rsp]
00007154327de752  vmovaps xmm1, [rsp+0x10]
00007154327de758  vmovaps xmm2, [rsp+0x20]
00007154327de75e  vmovaps xmm3, [rsp+0x30]
00007154327de764  vmovaps xmm4, [rsp+0x40]
00007154327de76a  vmovaps xmm5, [rsp+0x50]
00007154327de770  vmovaps xmm6, [rsp+0x60]
00007154327de776  vmovaps xmm7, [rsp+0x70]
00007154327de77c  vmovaps xmm8, [rsp+0x80]
00007154327de785  vmovaps xmm10, [rsp+0x90]
00007154327de78e  vmovaps xmm11, [rsp+0xA0]
00007154327de797  vmovaps xmm12, [rsp+0xB0]
00007154327de7a0  vmovaps xmm13, [rsp+0xC0]
00007154327de7a9  vmovaps xmm14, [rsp+0xD0]
00007154327de7b2  vmovaps xmm15, [rsp+0xE0]
00007154327de7bb  add rsp, 0xF0
00007154327de7c2  pop r11
00007154327de7c4  pop r10
00007154327de7c6  pop r9
00007154327de7c8  pop r8
00007154327de7ca  pop rsi
00007154327de7cb  pop rdi
00007154327de7cc  pop rdx
00007154327de7cd  pop rcx
00007154327de7ce  pop rax
00007154327de7cf  add rsp, 0x08
00007154327de7d3  jmp 0x00007154327DC1AA
00007154327de7d8  call 0x00007154326B52F0
00007154327de7dd  jmp 0x00007154327DC1B7
00007154327de7e2  sub rsp, 0x08
00007154327de7e6  push rax
00007154327de7e7  push rcx
00007154327de7e8  push rdx
00007154327de7e9  push rdi
00007154327de7ea  push rsi
00007154327de7eb  push r8
00007154327de7ed  push r9
00007154327de7ef  push r10
00007154327de7f1  push r11
00007154327de7f3  sub rsp, 0xF0
00007154327de7fa  vmovaps [rsp], xmm0
00007154327de7ff  vmovaps [rsp+0x10], xmm1
00007154327de805  vmovaps [rsp+0x20], xmm2
00007154327de80b  vmovaps [rsp+0x30], xmm3
00007154327de811  vmovaps [rsp+0x40], xmm4
00007154327de817  vmovaps [rsp+0x50], xmm5
00007154327de81d  vmovaps [rsp+0x60], xmm6
00007154327de823  vmovaps [rsp+0x70], xmm7
00007154327de829  vmovaps [rsp+0x80], xmm8
00007154327de832  vmovaps [rsp+0x90], xmm9
00007154327de83b  vmovaps [rsp+0xA0], xmm10
00007154327de844  vmovaps [rsp+0xB0], xmm11
00007154327de84d  vmovaps [rsp+0xC0], xmm12
00007154327de856  vmovaps [rsp+0xD0], xmm13
00007154327de85f  vmovaps [rsp+0xE0], xmm14
00007154327de868  sub rsp, 0x30
00007154327de86c  movaps [rsp], xmm15
00007154327de871  movaps [rsp+0x10], xmm3
00007154327de876  movaps [rsp+0x20], xmm7
00007154327de87b  lea rdi, [rsp]
00007154327de87f  mov esi, 0x00
00007154327de884  mov rax, 0x5A63B06A5530
00007154327de88e  call rax
00007154327de890  movaps xmm15, [rsp]
00007154327de895  add rsp, 0x30
00007154327de899  vmovaps xmm0, [rsp]
00007154327de89e  vmovaps xmm1, [rsp+0x10]
00007154327de8a4  vmovaps xmm2, [rsp+0x20]
00007154327de8aa  vmovaps xmm3, [rsp+0x30]
00007154327de8b0  vmovaps xmm4, [rsp+0x40]
00007154327de8b6  vmovaps xmm5, [rsp+0x50]
00007154327de8bc  vmovaps xmm6, [rsp+0x60]
00007154327de8c2  vmovaps xmm7, [rsp+0x70]
00007154327de8c8  vmovaps xmm8, [rsp+0x80]
00007154327de8d1  vmovaps xmm9, [rsp+0x90]
00007154327de8da  vmovaps xmm10, [rsp+0xA0]
00007154327de8e3  vmovaps xmm11, [rsp+0xB0]
00007154327de8ec  vmovaps xmm12, [rsp+0xC0]
00007154327de8f5  vmovaps xmm13, [rsp+0xD0]
00007154327de8fe  vmovaps xmm14, [rsp+0xE0]
00007154327de907  add rsp, 0xF0
00007154327de90e  pop r11
00007154327de910  pop r10
00007154327de912  pop r9
00007154327de914  pop r8
00007154327de916  pop rsi
00007154327de917  pop rdi
00007154327de918  pop rdx
00007154327de919  pop rcx
00007154327de91a  pop rax
00007154327de91b  add rsp, 0x08
00007154327de91f  jmp 0x00007154327DC1E3
00007154327de924  sub rsp, 0x08
00007154327de928  push rax
00007154327de929  push rcx
00007154327de92a  push rdx
00007154327de92b  push rdi
00007154327de92c  push rsi
00007154327de92d  push r8
00007154327de92f  push r9
00007154327de931  push r10
00007154327de933  push r11
00007154327de935  sub rsp, 0xF0
00007154327de93c  vmovaps [rsp], xmm0
00007154327de941  vmovaps [rsp+0x10], xmm1
00007154327de947  vmovaps [rsp+0x20], xmm2
00007154327de94d  vmovaps [rsp+0x30], xmm4
00007154327de953  vmovaps [rsp+0x40], xmm5
00007154327de959  vmovaps [rsp+0x50], xmm6
00007154327de95f  vmovaps [rsp+0x60], xmm7
00007154327de965  vmovaps [rsp+0x70], xmm8
00007154327de96b  vmovaps [rsp+0x80], xmm9
00007154327de974  vmovaps [rsp+0x90], xmm10
00007154327de97d  vmovaps [rsp+0xA0], xmm11
00007154327de986  vmovaps [rsp+0xB0], xmm12
00007154327de98f  vmovaps [rsp+0xC0], xmm13
00007154327de998  vmovaps [rsp+0xD0], xmm14
00007154327de9a1  vmovaps [rsp+0xE0], xmm15
00007154327de9aa  sub rsp, 0x30
00007154327de9ae  movaps [rsp], xmm3
00007154327de9b2  movaps [rsp+0x10], xmm1
00007154327de9b7  movaps [rsp+0x20], xmm15
00007154327de9bd  lea rdi, [rsp]
00007154327de9c1  mov esi, 0x00
00007154327de9c6  mov rax, 0x5A63B06A5530
00007154327de9d0  call rax
00007154327de9d2  movaps xmm3, [rsp]
00007154327de9d6  add rsp, 0x30
00007154327de9da  vmovaps xmm0, [rsp]
00007154327de9df  vmovaps xmm1, [rsp+0x10]
00007154327de9e5  vmovaps xmm2, [rsp+0x20]
00007154327de9eb  vmovaps xmm4, [rsp+0x30]
00007154327de9f1  vmovaps xmm5, [rsp+0x40]
00007154327de9f7  vmovaps xmm6, [rsp+0x50]
00007154327de9fd  vmovaps xmm7, [rsp+0x60]
00007154327dea03  vmovaps xmm8, [rsp+0x70]
00007154327dea09  vmovaps xmm9, [rsp+0x80]
00007154327dea12  vmovaps xmm10, [rsp+0x90]
00007154327dea1b  vmovaps xmm11, [rsp+0xA0]
00007154327dea24  vmovaps xmm12, [rsp+0xB0]
00007154327dea2d  vmovaps xmm13, [rsp+0xC0]
00007154327dea36  vmovaps xmm14, [rsp+0xD0]
00007154327dea3f  vmovaps xmm15, [rsp+0xE0]
00007154327dea48  add rsp, 0xF0
00007154327dea4f  pop r11
00007154327dea51  pop r10
00007154327dea53  pop r9
00007154327dea55  pop r8
00007154327dea57  pop rsi
00007154327dea58  pop rdi
00007154327dea59  pop rdx
00007154327dea5a  pop rcx
00007154327dea5b  pop rax
00007154327dea5c  add rsp, 0x08
00007154327dea60  jmp 0x00007154327DC272
00007154327dea65  call 0x00007154326B52F0
00007154327dea6a  jmp 0x00007154327DC27C
00007154327dea6f  sub rsp, 0x08
00007154327dea73  push rax
00007154327dea74  push rcx
00007154327dea75  push rdx
00007154327dea76  push rdi
00007154327dea77  push rsi
00007154327dea78  push r8
00007154327dea7a  push r9
00007154327dea7c  push r10
00007154327dea7e  push r11
00007154327dea80  sub rsp, 0xF0
00007154327dea87  vmovaps [rsp], xmm0
00007154327dea8c  vmovaps [rsp+0x10], xmm1
00007154327dea92  vmovaps [rsp+0x20], xmm2
00007154327dea98  vmovaps [rsp+0x30], xmm3
00007154327dea9e  vmovaps [rsp+0x40], xmm4
00007154327deaa4  vmovaps [rsp+0x50], xmm5
00007154327deaaa  vmovaps [rsp+0x60], xmm6
00007154327deab0  vmovaps [rsp+0x70], xmm7
00007154327deab6  vmovaps [rsp+0x80], xmm8
00007154327deabf  vmovaps [rsp+0x90], xmm9
00007154327deac8  vmovaps [rsp+0xA0], xmm10
00007154327dead1  vmovaps [rsp+0xB0], xmm11
00007154327deada  vmovaps [rsp+0xC0], xmm12
00007154327deae3  vmovaps [rsp+0xD0], xmm13
00007154327deaec  vmovaps [rsp+0xE0], xmm14
00007154327deaf5  sub rsp, 0x30
00007154327deaf9  movaps [rsp], xmm15
00007154327deafe  movaps [rsp+0x10], xmm14
00007154327deb04  movaps [rsp+0x20], xmm4
00007154327deb09  lea rdi, [rsp]
00007154327deb0d  mov esi, 0x00
00007154327deb12  mov rax, 0x5A63B06A5530
00007154327deb1c  call rax
00007154327deb1e  movaps xmm15, [rsp]
00007154327deb23  add rsp, 0x30
00007154327deb27  vmovaps xmm0, [rsp]
00007154327deb2c  vmovaps xmm1, [rsp+0x10]
00007154327deb32  vmovaps xmm2, [rsp+0x20]
00007154327deb38  vmovaps xmm3, [rsp+0x30]
00007154327deb3e  vmovaps xmm4, [rsp+0x40]
00007154327deb44  vmovaps xmm5, [rsp+0x50]
00007154327deb4a  vmovaps xmm6, [rsp+0x60]
00007154327deb50  vmovaps xmm7, [rsp+0x70]
00007154327deb56  vmovaps xmm8, [rsp+0x80]
00007154327deb5f  vmovaps xmm9, [rsp+0x90]
00007154327deb68  vmovaps xmm10, [rsp+0xA0]
00007154327deb71  vmovaps xmm11, [rsp+0xB0]
00007154327deb7a  vmovaps xmm12, [rsp+0xC0]
00007154327deb83  vmovaps xmm13, [rsp+0xD0]
00007154327deb8c  vmovaps xmm14, [rsp+0xE0]
00007154327deb95  add rsp, 0xF0
00007154327deb9c  pop r11
00007154327deb9e  pop r10
00007154327deba0  pop r9
00007154327deba2  pop r8
00007154327deba4  pop rsi
00007154327deba5  pop rdi
00007154327deba6  pop rdx
00007154327deba7  pop rcx
00007154327deba8  pop rax
00007154327deba9  add rsp, 0x08
00007154327debad  jmp 0x00007154327DC2AA
00007154327debb2  sub rsp, 0x08
00007154327debb6  push rax
00007154327debb7  push rcx
00007154327debb8  push rdx
00007154327debb9  push rdi
00007154327debba  push rsi
00007154327debbb  push r8
00007154327debbd  push r9
00007154327debbf  push r10
00007154327debc1  push r11
00007154327debc3  sub rsp, 0xF0
00007154327debca  vmovaps [rsp], xmm0
00007154327debcf  vmovaps [rsp+0x10], xmm1
00007154327debd5  vmovaps [rsp+0x20], xmm2
00007154327debdb  vmovaps [rsp+0x30], xmm3
00007154327debe1  vmovaps [rsp+0x40], xmm4
00007154327debe7  vmovaps [rsp+0x50], xmm5
00007154327debed  vmovaps [rsp+0x60], xmm6
00007154327debf3  vmovaps [rsp+0x70], xmm7
00007154327debf9  vmovaps [rsp+0x80], xmm8
00007154327dec02  vmovaps [rsp+0x90], xmm9
00007154327dec0b  vmovaps [rsp+0xA0], xmm10
00007154327dec14  vmovaps [rsp+0xB0], xmm11
00007154327dec1d  vmovaps [rsp+0xC0], xmm12
00007154327dec26  vmovaps [rsp+0xD0], xmm13
00007154327dec2f  vmovaps [rsp+0xE0], xmm15
00007154327dec38  sub rsp, 0x30
00007154327dec3c  movaps [rsp], xmm14
00007154327dec41  movaps [rsp+0x10], xmm2
00007154327dec46  movaps [rsp+0x20], xmm1
00007154327dec4b  lea rdi, [rsp]
00007154327dec4f  mov esi, 0x00
00007154327dec54  mov rax, 0x5A63B06A5530
00007154327dec5e  call rax
00007154327dec60  movaps xmm14, [rsp]
00007154327dec65  add rsp, 0x30
00007154327dec69  vmovaps xmm0, [rsp]
00007154327dec6e  vmovaps xmm1, [rsp+0x10]
00007154327dec74  vmovaps xmm2, [rsp+0x20]
00007154327dec7a  vmovaps xmm3, [rsp+0x30]
00007154327dec80  vmovaps xmm4, [rsp+0x40]
00007154327dec86  vmovaps xmm5, [rsp+0x50]
00007154327dec8c  vmovaps xmm6, [rsp+0x60]
00007154327dec92  vmovaps xmm7, [rsp+0x70]
00007154327dec98  vmovaps xmm8, [rsp+0x80]
00007154327deca1  vmovaps xmm9, [rsp+0x90]
00007154327decaa  vmovaps xmm10, [rsp+0xA0]
00007154327decb3  vmovaps xmm11, [rsp+0xB0]
00007154327decbc  vmovaps xmm12, [rsp+0xC0]
00007154327decc5  vmovaps xmm13, [rsp+0xD0]
00007154327decce  vmovaps xmm15, [rsp+0xE0]
00007154327decd7  add rsp, 0xF0
00007154327decde  pop r11
00007154327dece0  pop r10
00007154327dece2  pop r9
00007154327dece4  pop r8
00007154327dece6  pop rsi
00007154327dece7  pop rdi
00007154327dece8  pop rdx
00007154327dece9  pop rcx
00007154327decea  pop rax
00007154327deceb  add rsp, 0x08
00007154327decef  jmp 0x00007154327DC2D0
00007154327decf4  sub rsp, 0x08
00007154327decf8  push rax
00007154327decf9  push rcx
00007154327decfa  push rdx
00007154327decfb  push rdi
00007154327decfc  push rsi
00007154327decfd  push r8
00007154327decff  push r9
00007154327ded01  push r10
00007154327ded03  push r11
00007154327ded05  sub rsp, 0xF0
00007154327ded0c  vmovaps [rsp], xmm0
00007154327ded11  vmovaps [rsp+0x10], xmm2
00007154327ded17  vmovaps [rsp+0x20], xmm3
00007154327ded1d  vmovaps [rsp+0x30], xmm4
00007154327ded23  vmovaps [rsp+0x40], xmm5
00007154327ded29  vmovaps [rsp+0x50], xmm6
00007154327ded2f  vmovaps [rsp+0x60], xmm7
00007154327ded35  vmovaps [rsp+0x70], xmm8
00007154327ded3b  vmovaps [rsp+0x80], xmm9
00007154327ded44  vmovaps [rsp+0x90], xmm10
00007154327ded4d  vmovaps [rsp+0xA0], xmm11
00007154327ded56  vmovaps [rsp+0xB0], xmm12
00007154327ded5f  vmovaps [rsp+0xC0], xmm13
00007154327ded68  vmovaps [rsp+0xD0], xmm14
00007154327ded71  vmovaps [rsp+0xE0], xmm15
00007154327ded7a  sub rsp, 0x30
00007154327ded7e  movaps [rsp], xmm1
00007154327ded82  movaps [rsp+0x10], xmm4
00007154327ded87  movaps [rsp+0x20], xmm9
00007154327ded8d  lea rdi, [rsp]
00007154327ded91  mov esi, 0x00
00007154327ded96  mov rax, 0x5A63B06A5530
00007154327deda0  call rax
00007154327deda2  movaps xmm1, [rsp]
00007154327deda6  add rsp, 0x30
00007154327dedaa  vmovaps xmm0, [rsp]
00007154327dedaf  vmovaps xmm2, [rsp+0x10]
00007154327dedb5  vmovaps xmm3, [rsp+0x20]
00007154327dedbb  vmovaps xmm4, [rsp+0x30]
00007154327dedc1  vmovaps xmm5, [rsp+0x40]
00007154327dedc7  vmovaps xmm6, [rsp+0x50]
00007154327dedcd  vmovaps xmm7, [rsp+0x60]
00007154327dedd3  vmovaps xmm8, [rsp+0x70]
00007154327dedd9  vmovaps xmm9, [rsp+0x80]
00007154327dede2  vmovaps xmm10, [rsp+0x90]
00007154327dedeb  vmovaps xmm11, [rsp+0xA0]
00007154327dedf4  vmovaps xmm12, [rsp+0xB0]
00007154327dedfd  vmovaps xmm13, [rsp+0xC0]
00007154327dee06  vmovaps xmm14, [rsp+0xD0]
00007154327dee0f  vmovaps xmm15, [rsp+0xE0]
00007154327dee18  add rsp, 0xF0
00007154327dee1f  pop r11
00007154327dee21  pop r10
00007154327dee23  pop r9
00007154327dee25  pop r8
00007154327dee27  pop rsi
00007154327dee28  pop rdi
00007154327dee29  pop rdx
00007154327dee2a  pop rcx
00007154327dee2b  pop rax
00007154327dee2c  add rsp, 0x08
00007154327dee30  jmp 0x00007154327DC2EE
00007154327dee35  sub rsp, 0x08
00007154327dee39  push rax
00007154327dee3a  push rcx
00007154327dee3b  push rdx
00007154327dee3c  push rdi
00007154327dee3d  push rsi
00007154327dee3e  push r8
00007154327dee40  push r9
00007154327dee42  push r10
00007154327dee44  push r11
00007154327dee46  sub rsp, 0xF0
00007154327dee4d  vmovaps [rsp], xmm0
00007154327dee52  vmovaps [rsp+0x10], xmm1
00007154327dee58  vmovaps [rsp+0x20], xmm2
00007154327dee5e  vmovaps [rsp+0x30], xmm3
00007154327dee64  vmovaps [rsp+0x40], xmm5
00007154327dee6a  vmovaps [rsp+0x50], xmm6
00007154327dee70  vmovaps [rsp+0x60], xmm7
00007154327dee76  vmovaps [rsp+0x70], xmm8
00007154327dee7c  vmovaps [rsp+0x80], xmm9
00007154327dee85  vmovaps [rsp+0x90], xmm10
00007154327dee8e  vmovaps [rsp+0xA0], xmm11
00007154327dee97  vmovaps [rsp+0xB0], xmm12
00007154327deea0  vmovaps [rsp+0xC0], xmm13
00007154327deea9  vmovaps [rsp+0xD0], xmm14
00007154327deeb2  vmovaps [rsp+0xE0], xmm15
00007154327deebb  sub rsp, 0x30
00007154327deebf  movaps [rsp], xmm4
00007154327deec3  movaps [rsp+0x10], xmm2
00007154327deec8  movaps [rsp+0x20], xmm9
00007154327deece  lea rdi, [rsp]
00007154327deed2  mov esi, 0x00
00007154327deed7  mov rax, 0x5A63B06A5530
00007154327deee1  call rax
00007154327deee3  movaps xmm4, [rsp]
00007154327deee7  add rsp, 0x30
00007154327deeeb  vmovaps xmm0, [rsp]
00007154327deef0  vmovaps xmm1, [rsp+0x10]
00007154327deef6  vmovaps xmm2, [rsp+0x20]
00007154327deefc  vmovaps xmm3, [rsp+0x30]
00007154327def02  vmovaps xmm5, [rsp+0x40]
00007154327def08  vmovaps xmm6, [rsp+0x50]
00007154327def0e  vmovaps xmm7, [rsp+0x60]
00007154327def14  vmovaps xmm8, [rsp+0x70]
00007154327def1a  vmovaps xmm9, [rsp+0x80]
00007154327def23  vmovaps xmm10, [rsp+0x90]
00007154327def2c  vmovaps xmm11, [rsp+0xA0]
00007154327def35  vmovaps xmm12, [rsp+0xB0]
00007154327def3e  vmovaps xmm13, [rsp+0xC0]
00007154327def47  vmovaps xmm14, [rsp+0xD0]
00007154327def50  vmovaps xmm15, [rsp+0xE0]
00007154327def59  add rsp, 0xF0
00007154327def60  pop r11
00007154327def62  pop r10
00007154327def64  pop r9
00007154327def66  pop r8
00007154327def68  pop rsi
00007154327def69  pop rdi
00007154327def6a  pop rdx
00007154327def6b  pop rcx
00007154327def6c  pop rax
00007154327def6d  add rsp, 0x08
00007154327def71  jmp 0x00007154327DC31E
00007154327def76  sub rsp, 0x08
00007154327def7a  push rax
00007154327def7b  push rcx
00007154327def7c  push rdx
00007154327def7d  push rdi
00007154327def7e  push rsi
00007154327def7f  push r8
00007154327def81  push r9
00007154327def83  push r10
00007154327def85  push r11
00007154327def87  sub rsp, 0xF0
00007154327def8e  vmovaps [rsp], xmm0
00007154327def93  vmovaps [rsp+0x10], xmm1
00007154327def99  vmovaps [rsp+0x20], xmm2
00007154327def9f  vmovaps [rsp+0x30], xmm3
00007154327defa5  vmovaps [rsp+0x40], xmm4
00007154327defab  vmovaps [rsp+0x50], xmm5
00007154327defb1  vmovaps [rsp+0x60], xmm6
00007154327defb7  vmovaps [rsp+0x70], xmm7
00007154327defbd  vmovaps [rsp+0x80], xmm8
00007154327defc6  vmovaps [rsp+0x90], xmm10
00007154327defcf  vmovaps [rsp+0xA0], xmm11
00007154327defd8  vmovaps [rsp+0xB0], xmm12
00007154327defe1  vmovaps [rsp+0xC0], xmm13
00007154327defea  vmovaps [rsp+0xD0], xmm14
00007154327deff3  vmovaps [rsp+0xE0], xmm15
00007154327deffc  sub rsp, 0x30
00007154327df000  movaps [rsp], xmm9
00007154327df005  movaps [rsp+0x10], xmm2
00007154327df00a  movaps [rsp+0x20], xmm1
00007154327df00f  lea rdi, [rsp]
00007154327df013  mov esi, 0x00
00007154327df018  mov rax, 0x5A63B06A5530
00007154327df022  call rax
00007154327df024  movaps xmm9, [rsp]
00007154327df029  add rsp, 0x30
00007154327df02d  vmovaps xmm0, [rsp]
00007154327df032  vmovaps xmm1, [rsp+0x10]
00007154327df038  vmovaps xmm2, [rsp+0x20]
00007154327df03e  vmovaps xmm3, [rsp+0x30]
00007154327df044  vmovaps xmm4, [rsp+0x40]
00007154327df04a  vmovaps xmm5, [rsp+0x50]
00007154327df050  vmovaps xmm6, [rsp+0x60]
00007154327df056  vmovaps xmm7, [rsp+0x70]
00007154327df05c  vmovaps xmm8, [rsp+0x80]
00007154327df065  vmovaps xmm10, [rsp+0x90]
00007154327df06e  vmovaps xmm11, [rsp+0xA0]
00007154327df077  vmovaps xmm12, [rsp+0xB0]
00007154327df080  vmovaps xmm13, [rsp+0xC0]
00007154327df089  vmovaps xmm14, [rsp+0xD0]
00007154327df092  vmovaps xmm15, [rsp+0xE0]
00007154327df09b  add rsp, 0xF0
00007154327df0a2  pop r11
00007154327df0a4  pop r10
00007154327df0a6  pop r9
00007154327df0a8  pop r8
00007154327df0aa  pop rsi
00007154327df0ab  pop rdi
00007154327df0ac  pop rdx
00007154327df0ad  pop rcx
00007154327df0ae  pop rax
00007154327df0af  add rsp, 0x08
00007154327df0b3  jmp 0x00007154327DC354
00007154327df0b8  sub rsp, 0x08
00007154327df0bc  push rax
00007154327df0bd  push rcx
00007154327df0be  push rdx
00007154327df0bf  push rdi
00007154327df0c0  push rsi
00007154327df0c1  push r8
00007154327df0c3  push r9
00007154327df0c5  push r10
00007154327df0c7  push r11
00007154327df0c9  sub rsp, 0xF0
00007154327df0d0  vmovaps [rsp], xmm0
00007154327df0d5  vmovaps [rsp+0x10], xmm2
00007154327df0db  vmovaps [rsp+0x20], xmm3
00007154327df0e1  vmovaps [rsp+0x30], xmm4
00007154327df0e7  vmovaps [rsp+0x40], xmm5
00007154327df0ed  vmovaps [rsp+0x50], xmm6
00007154327df0f3  vmovaps [rsp+0x60], xmm7
00007154327df0f9  vmovaps [rsp+0x70], xmm8
00007154327df0ff  vmovaps [rsp+0x80], xmm9
00007154327df108  vmovaps [rsp+0x90], xmm10
00007154327df111  vmovaps [rsp+0xA0], xmm11
00007154327df11a  vmovaps [rsp+0xB0], xmm12
00007154327df123  vmovaps [rsp+0xC0], xmm13
00007154327df12c  vmovaps [rsp+0xD0], xmm14
00007154327df135  vmovaps [rsp+0xE0], xmm15
00007154327df13e  sub rsp, 0x30
00007154327df142  movaps [rsp], xmm1
00007154327df146  movaps [rsp+0x10], xmm15
00007154327df14c  movaps [rsp+0x20], xmm6
00007154327df151  lea rdi, [rsp]
00007154327df155  mov esi, 0x00
00007154327df15a  mov rax, 0x5A63B06A5530
00007154327df164  call rax
00007154327df166  movaps xmm1, [rsp]
00007154327df16a  add rsp, 0x30
00007154327df16e  vmovaps xmm0, [rsp]
00007154327df173  vmovaps xmm2, [rsp+0x10]
00007154327df179  vmovaps xmm3, [rsp+0x20]
00007154327df17f  vmovaps xmm4, [rsp+0x30]
00007154327df185  vmovaps xmm5, [rsp+0x40]
00007154327df18b  vmovaps xmm6, [rsp+0x50]
00007154327df191  vmovaps xmm7, [rsp+0x60]
00007154327df197  vmovaps xmm8, [rsp+0x70]
00007154327df19d  vmovaps xmm9, [rsp+0x80]
00007154327df1a6  vmovaps xmm10, [rsp+0x90]
00007154327df1af  vmovaps xmm11, [rsp+0xA0]
00007154327df1b8  vmovaps xmm12, [rsp+0xB0]
00007154327df1c1  vmovaps xmm13, [rsp+0xC0]
00007154327df1ca  vmovaps xmm14, [rsp+0xD0]
00007154327df1d3  vmovaps xmm15, [rsp+0xE0]
00007154327df1dc  add rsp, 0xF0
00007154327df1e3  pop r11
00007154327df1e5  pop r10
00007154327df1e7  pop r9
00007154327df1e9  pop r8
00007154327df1eb  pop rsi
00007154327df1ec  pop rdi
00007154327df1ed  pop rdx
00007154327df1ee  pop rcx
00007154327df1ef  pop rax
00007154327df1f0  add rsp, 0x08
00007154327df1f4  jmp 0x00007154327DC375
00007154327df1f9  sub rsp, 0x08
00007154327df1fd  push rax
00007154327df1fe  push rcx
00007154327df1ff  push rdx
00007154327df200  push rdi
00007154327df201  push rsi
00007154327df202  push r8
00007154327df204  push r9
00007154327df206  push r10
00007154327df208  push r11
00007154327df20a  sub rsp, 0xF0
00007154327df211  vmovaps [rsp], xmm0
00007154327df216  vmovaps [rsp+0x10], xmm1
00007154327df21c  vmovaps [rsp+0x20], xmm2
00007154327df222  vmovaps [rsp+0x30], xmm3
00007154327df228  vmovaps [rsp+0x40], xmm4
00007154327df22e  vmovaps [rsp+0x50], xmm5
00007154327df234  vmovaps [rsp+0x60], xmm6
00007154327df23a  vmovaps [rsp+0x70], xmm7
00007154327df240  vmovaps [rsp+0x80], xmm8
00007154327df249  vmovaps [rsp+0x90], xmm9
00007154327df252  vmovaps [rsp+0xA0], xmm10
00007154327df25b  vmovaps [rsp+0xB0], xmm11
00007154327df264  vmovaps [rsp+0xC0], xmm12
00007154327df26d  vmovaps [rsp+0xD0], xmm13
00007154327df276  vmovaps [rsp+0xE0], xmm14
00007154327df27f  sub rsp, 0x30
00007154327df283  movaps [rsp], xmm15
00007154327df288  movaps [rsp+0x10], xmm5
00007154327df28d  movaps [rsp+0x20], xmm3
00007154327df292  lea rdi, [rsp]
00007154327df296  mov esi, 0x00
00007154327df29b  mov rax, 0x5A63B06A5530
00007154327df2a5  call rax
00007154327df2a7  movaps xmm15, [rsp]
00007154327df2ac  add rsp, 0x30
00007154327df2b0  vmovaps xmm0, [rsp]
00007154327df2b5  vmovaps xmm1, [rsp+0x10]
00007154327df2bb  vmovaps xmm2, [rsp+0x20]
00007154327df2c1  vmovaps xmm3, [rsp+0x30]
00007154327df2c7  vmovaps xmm4, [rsp+0x40]
00007154327df2cd  vmovaps xmm5, [rsp+0x50]
00007154327df2d3  vmovaps xmm6, [rsp+0x60]
00007154327df2d9  vmovaps xmm7, [rsp+0x70]
00007154327df2df  vmovaps xmm8, [rsp+0x80]
00007154327df2e8  vmovaps xmm9, [rsp+0x90]
00007154327df2f1  vmovaps xmm10, [rsp+0xA0]
00007154327df2fa  vmovaps xmm11, [rsp+0xB0]
00007154327df303  vmovaps xmm12, [rsp+0xC0]
00007154327df30c  vmovaps xmm13, [rsp+0xD0]
00007154327df315  vmovaps xmm14, [rsp+0xE0]
00007154327df31e  add rsp, 0xF0
00007154327df325  pop r11
00007154327df327  pop r10
00007154327df329  pop r9
00007154327df32b  pop r8
00007154327df32d  pop rsi
00007154327df32e  pop rdi
00007154327df32f  pop rdx
00007154327df330  pop rcx
00007154327df331  pop rax
00007154327df332  add rsp, 0x08
00007154327df336  jmp 0x00007154327DC38F
00007154327df33b  sub rsp, 0x08
00007154327df33f  push rax
00007154327df340  push rcx
00007154327df341  push rdx
00007154327df342  push rdi
00007154327df343  push rsi
00007154327df344  push r8
00007154327df346  push r9
00007154327df348  push r10
00007154327df34a  push r11
00007154327df34c  sub rsp, 0xF0
00007154327df353  vmovaps [rsp], xmm0
00007154327df358  vmovaps [rsp+0x10], xmm1
00007154327df35e  vmovaps [rsp+0x20], xmm2
00007154327df364  vmovaps [rsp+0x30], xmm3
00007154327df36a  vmovaps [rsp+0x40], xmm4
00007154327df370  vmovaps [rsp+0x50], xmm6
00007154327df376  vmovaps [rsp+0x60], xmm7
00007154327df37c  vmovaps [rsp+0x70], xmm8
00007154327df382  vmovaps [rsp+0x80], xmm9
00007154327df38b  vmovaps [rsp+0x90], xmm10
00007154327df394  vmovaps [rsp+0xA0], xmm11
00007154327df39d  vmovaps [rsp+0xB0], xmm12
00007154327df3a6  vmovaps [rsp+0xC0], xmm13
00007154327df3af  vmovaps [rsp+0xD0], xmm14
00007154327df3b8  vmovaps [rsp+0xE0], xmm15
00007154327df3c1  sub rsp, 0x30
00007154327df3c5  movaps [rsp], xmm5
00007154327df3c9  movaps [rsp+0x10], xmm8
00007154327df3cf  movaps [rsp+0x20], xmm6
00007154327df3d4  lea rdi, [rsp]
00007154327df3d8  mov esi, 0x00
00007154327df3dd  mov rax, 0x5A63B06A5530
00007154327df3e7  call rax
00007154327df3e9  movaps xmm5, [rsp]
00007154327df3ed  add rsp, 0x30
00007154327df3f1  vmovaps xmm0, [rsp]
00007154327df3f6  vmovaps xmm1, [rsp+0x10]
00007154327df3fc  vmovaps xmm2, [rsp+0x20]
00007154327df402  vmovaps xmm3, [rsp+0x30]
00007154327df408  vmovaps xmm4, [rsp+0x40]
00007154327df40e  vmovaps xmm6, [rsp+0x50]
00007154327df414  vmovaps xmm7, [rsp+0x60]
00007154327df41a  vmovaps xmm8, [rsp+0x70]
00007154327df420  vmovaps xmm9, [rsp+0x80]
00007154327df429  vmovaps xmm10, [rsp+0x90]
00007154327df432  vmovaps xmm11, [rsp+0xA0]
00007154327df43b  vmovaps xmm12, [rsp+0xB0]
00007154327df444  vmovaps xmm13, [rsp+0xC0]
00007154327df44d  vmovaps xmm14, [rsp+0xD0]
00007154327df456  vmovaps xmm15, [rsp+0xE0]
00007154327df45f  add rsp, 0xF0
00007154327df466  pop r11
00007154327df468  pop r10
00007154327df46a  pop r9
00007154327df46c  pop r8
00007154327df46e  pop rsi
00007154327df46f  pop rdi
00007154327df470  pop rdx
00007154327df471  pop rcx
00007154327df472  pop rax
00007154327df473  add rsp, 0x08
00007154327df477  jmp 0x00007154327DC3B3
00007154327df47c  sub rsp, 0x08
00007154327df480  push rax
00007154327df481  push rcx
00007154327df482  push rdx
00007154327df483  push rdi
00007154327df484  push rsi
00007154327df485  push r8
00007154327df487  push r9
00007154327df489  push r10
00007154327df48b  push r11
00007154327df48d  sub rsp, 0xF0
00007154327df494  vmovaps [rsp], xmm0
00007154327df499  vmovaps [rsp+0x10], xmm1
00007154327df49f  vmovaps [rsp+0x20], xmm2
00007154327df4a5  vmovaps [rsp+0x30], xmm3
00007154327df4ab  vmovaps [rsp+0x40], xmm4
00007154327df4b1  vmovaps [rsp+0x50], xmm5
00007154327df4b7  vmovaps [rsp+0x60], xmm7
00007154327df4bd  vmovaps [rsp+0x70], xmm8
00007154327df4c3  vmovaps [rsp+0x80], xmm9
00007154327df4cc  vmovaps [rsp+0x90], xmm10
00007154327df4d5  vmovaps [rsp+0xA0], xmm11
00007154327df4de  vmovaps [rsp+0xB0], xmm12
00007154327df4e7  vmovaps [rsp+0xC0], xmm13
00007154327df4f0  vmovaps [rsp+0xD0], xmm14
00007154327df4f9  vmovaps [rsp+0xE0], xmm15
00007154327df502  sub rsp, 0x30
00007154327df506  movaps [rsp], xmm6
00007154327df50a  movaps [rsp+0x10], xmm10
00007154327df510  movaps [rsp+0x20], xmm8
00007154327df516  lea rdi, [rsp]
00007154327df51a  mov esi, 0x00
00007154327df51f  mov rax, 0x5A63B06A5530
00007154327df529  call rax
00007154327df52b  movaps xmm6, [rsp]
00007154327df52f  add rsp, 0x30
00007154327df533  vmovaps xmm0, [rsp]
00007154327df538  vmovaps xmm1, [rsp+0x10]
00007154327df53e  vmovaps xmm2, [rsp+0x20]
00007154327df544  vmovaps xmm3, [rsp+0x30]
00007154327df54a  vmovaps xmm4, [rsp+0x40]
00007154327df550  vmovaps xmm5, [rsp+0x50]
00007154327df556  vmovaps xmm7, [rsp+0x60]
00007154327df55c  vmovaps xmm8, [rsp+0x70]
00007154327df562  vmovaps xmm9, [rsp+0x80]
00007154327df56b  vmovaps xmm10, [rsp+0x90]
00007154327df574  vmovaps xmm11, [rsp+0xA0]
00007154327df57d  vmovaps xmm12, [rsp+0xB0]
00007154327df586  vmovaps xmm13, [rsp+0xC0]
00007154327df58f  vmovaps xmm14, [rsp+0xD0]
00007154327df598  vmovaps xmm15, [rsp+0xE0]
00007154327df5a1  add rsp, 0xF0
00007154327df5a8  pop r11
00007154327df5aa  pop r10
00007154327df5ac  pop r9
00007154327df5ae  pop r8
00007154327df5b0  pop rsi
00007154327df5b1  pop rdi
00007154327df5b2  pop rdx
00007154327df5b3  pop rcx
00007154327df5b4  pop rax
00007154327df5b5  add rsp, 0x08
00007154327df5b9  jmp 0x00007154327DC3D8
00007154327df5be  sub rsp, 0x08
00007154327df5c2  push rax
00007154327df5c3  push rcx
00007154327df5c4  push rdx
00007154327df5c5  push rdi
00007154327df5c6  push rsi
00007154327df5c7  push r8
00007154327df5c9  push r9
00007154327df5cb  push r10
00007154327df5cd  push r11
00007154327df5cf  sub rsp, 0xF0
00007154327df5d6  vmovaps [rsp], xmm0
00007154327df5db  vmovaps [rsp+0x10], xmm1
00007154327df5e1  vmovaps [rsp+0x20], xmm2
00007154327df5e7  vmovaps [rsp+0x30], xmm3
00007154327df5ed  vmovaps [rsp+0x40], xmm4
00007154327df5f3  vmovaps [rsp+0x50], xmm5
00007154327df5f9  vmovaps [rsp+0x60], xmm6
00007154327df5ff  vmovaps [rsp+0x70], xmm7
00007154327df605  vmovaps [rsp+0x80], xmm8
00007154327df60e  vmovaps [rsp+0x90], xmm9
00007154327df617  vmovaps [rsp+0xA0], xmm11
00007154327df620  vmovaps [rsp+0xB0], xmm12
00007154327df629  vmovaps [rsp+0xC0], xmm13
00007154327df632  vmovaps [rsp+0xD0], xmm14
00007154327df63b  vmovaps [rsp+0xE0], xmm15
00007154327df644  sub rsp, 0x30
00007154327df648  movaps [rsp], xmm10
00007154327df64d  movaps [rsp+0x10], xmm8
00007154327df653  movaps [rsp+0x20], xmm14
00007154327df659  lea rdi, [rsp]
00007154327df65d  mov esi, 0x00
00007154327df662  mov rax, 0x5A63B06A5530
00007154327df66c  call rax
00007154327df66e  movaps xmm10, [rsp]
00007154327df673  add rsp, 0x30
00007154327df677  vmovaps xmm0, [rsp]
00007154327df67c  vmovaps xmm1, [rsp+0x10]
00007154327df682  vmovaps xmm2, [rsp+0x20]
00007154327df688  vmovaps xmm3, [rsp+0x30]
00007154327df68e  vmovaps xmm4, [rsp+0x40]
00007154327df694  vmovaps xmm5, [rsp+0x50]
00007154327df69a  vmovaps xmm6, [rsp+0x60]
00007154327df6a0  vmovaps xmm7, [rsp+0x70]
00007154327df6a6  vmovaps xmm8, [rsp+0x80]
00007154327df6af  vmovaps xmm9, [rsp+0x90]
00007154327df6b8  vmovaps xmm11, [rsp+0xA0]
00007154327df6c1  vmovaps xmm12, [rsp+0xB0]
00007154327df6ca  vmovaps xmm13, [rsp+0xC0]
00007154327df6d3  vmovaps xmm14, [rsp+0xD0]
00007154327df6dc  vmovaps xmm15, [rsp+0xE0]
00007154327df6e5  add rsp, 0xF0
00007154327df6ec  pop r11
00007154327df6ee  pop r10
00007154327df6f0  pop r9
00007154327df6f2  pop r8
00007154327df6f4  pop rsi
00007154327df6f5  pop rdi
00007154327df6f6  pop rdx
00007154327df6f7  pop rcx
00007154327df6f8  pop rax
00007154327df6f9  add rsp, 0x08
00007154327df6fd  jmp 0x00007154327DC3F8
00007154327df702  sub rsp, 0x08
00007154327df706  push rax
00007154327df707  push rcx
00007154327df708  push rdx
00007154327df709  push rdi
00007154327df70a  push rsi
00007154327df70b  push r8
00007154327df70d  push r9
00007154327df70f  push r10
00007154327df711  push r11
00007154327df713  sub rsp, 0xF0
00007154327df71a  vmovaps [rsp], xmm0
00007154327df71f  vmovaps [rsp+0x10], xmm1
00007154327df725  vmovaps [rsp+0x20], xmm2
00007154327df72b  vmovaps [rsp+0x30], xmm3
00007154327df731  vmovaps [rsp+0x40], xmm4
00007154327df737  vmovaps [rsp+0x50], xmm5
00007154327df73d  vmovaps [rsp+0x60], xmm6
00007154327df743  vmovaps [rsp+0x70], xmm7
00007154327df749  vmovaps [rsp+0x80], xmm8
00007154327df752  vmovaps [rsp+0x90], xmm9
00007154327df75b  vmovaps [rsp+0xA0], xmm10
00007154327df764  vmovaps [rsp+0xB0], xmm11
00007154327df76d  vmovaps [rsp+0xC0], xmm12
00007154327df776  vmovaps [rsp+0xD0], xmm13
00007154327df77f  vmovaps [rsp+0xE0], xmm15
00007154327df788  sub rsp, 0x30
00007154327df78c  movaps [rsp], xmm14
00007154327df791  movaps [rsp+0x10], xmm8
00007154327df797  movaps [rsp+0x20], xmm4
00007154327df79c  lea rdi, [rsp]
00007154327df7a0  mov esi, 0x00
00007154327df7a5  mov rax, 0x5A63B06A5530
00007154327df7af  call rax
00007154327df7b1  movaps xmm14, [rsp]
00007154327df7b6  add rsp, 0x30
00007154327df7ba  vmovaps xmm0, [rsp]
00007154327df7bf  vmovaps xmm1, [rsp+0x10]
00007154327df7c5  vmovaps xmm2, [rsp+0x20]
00007154327df7cb  vmovaps xmm3, [rsp+0x30]
00007154327df7d1  vmovaps xmm4, [rsp+0x40]
00007154327df7d7  vmovaps xmm5, [rsp+0x50]
00007154327df7dd  vmovaps xmm6, [rsp+0x60]
00007154327df7e3  vmovaps xmm7, [rsp+0x70]
00007154327df7e9  vmovaps xmm8, [rsp+0x80]
00007154327df7f2  vmovaps xmm9, [rsp+0x90]
00007154327df7fb  vmovaps xmm10, [rsp+0xA0]
00007154327df804  vmovaps xmm11, [rsp+0xB0]
00007154327df80d  vmovaps xmm12, [rsp+0xC0]
00007154327df816  vmovaps xmm13, [rsp+0xD0]
00007154327df81f  vmovaps xmm15, [rsp+0xE0]
00007154327df828  add rsp, 0xF0
00007154327df82f  pop r11
00007154327df831  pop r10
00007154327df833  pop r9
00007154327df835  pop r8
00007154327df837  pop rsi
00007154327df838  pop rdi
00007154327df839  pop rdx
00007154327df83a  pop rcx
00007154327df83b  pop rax
00007154327df83c  add rsp, 0x08
00007154327df840  jmp 0x00007154327DC418
00007154327df845  sub rsp, 0x08
00007154327df849  push rax
00007154327df84a  push rcx
00007154327df84b  push rdx
00007154327df84c  push rdi
00007154327df84d  push rsi
00007154327df84e  push r8
00007154327df850  push r9
00007154327df852  push r10
00007154327df854  push r11
00007154327df856  sub rsp, 0xF0
00007154327df85d  vmovaps [rsp], xmm0
00007154327df862  vmovaps [rsp+0x10], xmm1
00007154327df868  vmovaps [rsp+0x20], xmm2
00007154327df86e  vmovaps [rsp+0x30], xmm3
00007154327df874  vmovaps [rsp+0x40], xmm5
00007154327df87a  vmovaps [rsp+0x50], xmm6
00007154327df880  vmovaps [rsp+0x60], xmm7
00007154327df886  vmovaps [rsp+0x70], xmm8
00007154327df88c  vmovaps [rsp+0x80], xmm9
00007154327df895  vmovaps [rsp+0x90], xmm10
00007154327df89e  vmovaps [rsp+0xA0], xmm11
00007154327df8a7  vmovaps [rsp+0xB0], xmm12
00007154327df8b0  vmovaps [rsp+0xC0], xmm13
00007154327df8b9  vmovaps [rsp+0xD0], xmm14
00007154327df8c2  vmovaps [rsp+0xE0], xmm15
00007154327df8cb  sub rsp, 0x30
00007154327df8cf  movaps [rsp], xmm4
00007154327df8d3  movaps [rsp+0x10], xmm13
00007154327df8d9  movaps [rsp+0x20], xmm8
00007154327df8df  lea rdi, [rsp]
00007154327df8e3  mov esi, 0x00
00007154327df8e8  mov rax, 0x5A63B06A5530
00007154327df8f2  call rax
00007154327df8f4  movaps xmm4, [rsp]
00007154327df8f8  add rsp, 0x30
00007154327df8fc  vmovaps xmm0, [rsp]
00007154327df901  vmovaps xmm1, [rsp+0x10]
00007154327df907  vmovaps xmm2, [rsp+0x20]
00007154327df90d  vmovaps xmm3, [rsp+0x30]
00007154327df913  vmovaps xmm5, [rsp+0x40]
00007154327df919  vmovaps xmm6, [rsp+0x50]
00007154327df91f  vmovaps xmm7, [rsp+0x60]
00007154327df925  vmovaps xmm8, [rsp+0x70]
00007154327df92b  vmovaps xmm9, [rsp+0x80]
00007154327df934  vmovaps xmm10, [rsp+0x90]
00007154327df93d  vmovaps xmm11, [rsp+0xA0]
00007154327df946  vmovaps xmm12, [rsp+0xB0]
00007154327df94f  vmovaps xmm13, [rsp+0xC0]
00007154327df958  vmovaps xmm14, [rsp+0xD0]
00007154327df961  vmovaps xmm15, [rsp+0xE0]
00007154327df96a  add rsp, 0xF0
00007154327df971  pop r11
00007154327df973  pop r10
00007154327df975  pop r9
00007154327df977  pop r8
00007154327df979  pop rsi
00007154327df97a  pop rdi
00007154327df97b  pop rdx
00007154327df97c  pop rcx
00007154327df97d  pop rax
00007154327df97e  add rsp, 0x08
00007154327df982  jmp 0x00007154327DC43D
00007154327df987  sub rsp, 0x08
00007154327df98b  push rax
00007154327df98c  push rcx
00007154327df98d  push rdx
00007154327df98e  push rdi
00007154327df98f  push rsi
00007154327df990  push r8
00007154327df992  push r9
00007154327df994  push r10
00007154327df996  push r11
00007154327df998  sub rsp, 0xF0
00007154327df99f  vmovaps [rsp], xmm0
00007154327df9a4  vmovaps [rsp+0x10], xmm1
00007154327df9aa  vmovaps [rsp+0x20], xmm2
00007154327df9b0  vmovaps [rsp+0x30], xmm3
00007154327df9b6  vmovaps [rsp+0x40], xmm4
00007154327df9bc  vmovaps [rsp+0x50], xmm5
00007154327df9c2  vmovaps [rsp+0x60], xmm6
00007154327df9c8  vmovaps [rsp+0x70], xmm7
00007154327df9ce  vmovaps [rsp+0x80], xmm8
00007154327df9d7  vmovaps [rsp+0x90], xmm9
00007154327df9e0  vmovaps [rsp+0xA0], xmm10
00007154327df9e9  vmovaps [rsp+0xB0], xmm11
00007154327df9f2  vmovaps [rsp+0xC0], xmm12
00007154327df9fb  vmovaps [rsp+0xD0], xmm14
00007154327dfa04  vmovaps [rsp+0xE0], xmm15
00007154327dfa0d  sub rsp, 0x30
00007154327dfa11  movaps [rsp], xmm13
00007154327dfa16  movaps [rsp+0x10], xmm15
00007154327dfa1c  movaps [rsp+0x20], xmm9
00007154327dfa22  lea rdi, [rsp]
00007154327dfa26  mov esi, 0x00
00007154327dfa2b  mov rax, 0x5A63B06A5530
00007154327dfa35  call rax
00007154327dfa37  movaps xmm13, [rsp]
00007154327dfa3c  add rsp, 0x30
00007154327dfa40  vmovaps xmm0, [rsp]
00007154327dfa45  vmovaps xmm1, [rsp+0x10]
00007154327dfa4b  vmovaps xmm2, [rsp+0x20]
00007154327dfa51  vmovaps xmm3, [rsp+0x30]
00007154327dfa57  vmovaps xmm4, [rsp+0x40]
00007154327dfa5d  vmovaps xmm5, [rsp+0x50]
00007154327dfa63  vmovaps xmm6, [rsp+0x60]
00007154327dfa69  vmovaps xmm7, [rsp+0x70]
00007154327dfa6f  vmovaps xmm8, [rsp+0x80]
00007154327dfa78  vmovaps xmm9, [rsp+0x90]
00007154327dfa81  vmovaps xmm10, [rsp+0xA0]
00007154327dfa8a  vmovaps xmm11, [rsp+0xB0]
00007154327dfa93  vmovaps xmm12, [rsp+0xC0]
00007154327dfa9c  vmovaps xmm14, [rsp+0xD0]
00007154327dfaa5  vmovaps xmm15, [rsp+0xE0]
00007154327dfaae  add rsp, 0xF0
00007154327dfab5  pop r11
00007154327dfab7  pop r10
00007154327dfab9  pop r9
00007154327dfabb  pop r8
00007154327dfabd  pop rsi
00007154327dfabe  pop rdi
00007154327dfabf  pop rdx
00007154327dfac0  pop rcx
00007154327dfac1  pop rax
00007154327dfac2  add rsp, 0x08
00007154327dfac6  jmp 0x00007154327DC458
00007154327dfacb  sub rsp, 0x08
00007154327dfacf  push rax
00007154327dfad0  push rcx
00007154327dfad1  push rdx
00007154327dfad2  push rdi
00007154327dfad3  push rsi
00007154327dfad4  push r8
00007154327dfad6  push r9
00007154327dfad8  push r10
00007154327dfada  push r11
00007154327dfadc  sub rsp, 0xF0
00007154327dfae3  vmovaps [rsp], xmm0
00007154327dfae8  vmovaps [rsp+0x10], xmm1
00007154327dfaee  vmovaps [rsp+0x20], xmm2
00007154327dfaf4  vmovaps [rsp+0x30], xmm3
00007154327dfafa  vmovaps [rsp+0x40], xmm4
00007154327dfb00  vmovaps [rsp+0x50], xmm5
00007154327dfb06  vmovaps [rsp+0x60], xmm6
00007154327dfb0c  vmovaps [rsp+0x70], xmm7
00007154327dfb12  vmovaps [rsp+0x80], xmm8
00007154327dfb1b  vmovaps [rsp+0x90], xmm9
00007154327dfb24  vmovaps [rsp+0xA0], xmm10
00007154327dfb2d  vmovaps [rsp+0xB0], xmm11
00007154327dfb36  vmovaps [rsp+0xC0], xmm12
00007154327dfb3f  vmovaps [rsp+0xD0], xmm13
00007154327dfb48  vmovaps [rsp+0xE0], xmm14
00007154327dfb51  sub rsp, 0x30
00007154327dfb55  movaps [rsp], xmm15
00007154327dfb5a  movaps [rsp+0x10], xmm1
00007154327dfb5f  movaps [rsp+0x20], xmm5
00007154327dfb64  lea rdi, [rsp]
00007154327dfb68  mov esi, 0x00
00007154327dfb6d  mov rax, 0x5A63B06A5530
00007154327dfb77  call rax
00007154327dfb79  movaps xmm15, [rsp]
00007154327dfb7e  add rsp, 0x30
00007154327dfb82  vmovaps xmm0, [rsp]
00007154327dfb87  vmovaps xmm1, [rsp+0x10]
00007154327dfb8d  vmovaps xmm2, [rsp+0x20]
00007154327dfb93  vmovaps xmm3, [rsp+0x30]
00007154327dfb99  vmovaps xmm4, [rsp+0x40]
00007154327dfb9f  vmovaps xmm5, [rsp+0x50]
00007154327dfba5  vmovaps xmm6, [rsp+0x60]
00007154327dfbab  vmovaps xmm7, [rsp+0x70]
00007154327dfbb1  vmovaps xmm8, [rsp+0x80]
00007154327dfbba  vmovaps xmm9, [rsp+0x90]
00007154327dfbc3  vmovaps xmm10, [rsp+0xA0]
00007154327dfbcc  vmovaps xmm11, [rsp+0xB0]
00007154327dfbd5  vmovaps xmm12, [rsp+0xC0]
00007154327dfbde  vmovaps xmm13, [rsp+0xD0]
00007154327dfbe7  vmovaps xmm14, [rsp+0xE0]
00007154327dfbf0  add rsp, 0xF0
00007154327dfbf7  pop r11
00007154327dfbf9  pop r10
00007154327dfbfb  pop r9
00007154327dfbfd  pop r8
00007154327dfbff  pop rsi
00007154327dfc00  pop rdi
00007154327dfc01  pop rdx
00007154327dfc02  pop rcx
00007154327dfc03  pop rax
00007154327dfc04  add rsp, 0x08
00007154327dfc08  jmp 0x00007154327DC473
00007154327dfc0d  call 0x00007154326B52F0
00007154327dfc12  jmp 0x00007154327DC4CE
00007154327dfc17  sub rsp, 0x08
00007154327dfc1b  push rax
00007154327dfc1c  push rcx
00007154327dfc1d  push rdx
00007154327dfc1e  push rdi
00007154327dfc1f  push rsi
00007154327dfc20  push r8
00007154327dfc22  push r9
00007154327dfc24  push r10
00007154327dfc26  push r11
00007154327dfc28  sub rsp, 0xF0
00007154327dfc2f  vmovaps [rsp], xmm0
00007154327dfc34  vmovaps [rsp+0x10], xmm1
00007154327dfc3a  vmovaps [rsp+0x20], xmm2
00007154327dfc40  vmovaps [rsp+0x30], xmm3
00007154327dfc46  vmovaps [rsp+0x40], xmm4
00007154327dfc4c  vmovaps [rsp+0x50], xmm5
00007154327dfc52  vmovaps [rsp+0x60], xmm6
00007154327dfc58  vmovaps [rsp+0x70], xmm7
00007154327dfc5e  vmovaps [rsp+0x80], xmm8
00007154327dfc67  vmovaps [rsp+0x90], xmm10
00007154327dfc70  vmovaps [rsp+0xA0], xmm11
00007154327dfc79  vmovaps [rsp+0xB0], xmm12
00007154327dfc82  vmovaps [rsp+0xC0], xmm13
00007154327dfc8b  vmovaps [rsp+0xD0], xmm14
00007154327dfc94  vmovaps [rsp+0xE0], xmm15
00007154327dfc9d  sub rsp, 0x30
00007154327dfca1  movaps [rsp], xmm9
00007154327dfca6  movaps [rsp+0x10], xmm8
00007154327dfcac  movaps [rsp+0x20], xmm11
00007154327dfcb2  lea rdi, [rsp]
00007154327dfcb6  mov esi, 0x00
00007154327dfcbb  mov rax, 0x5A63B06A5530
00007154327dfcc5  call rax
00007154327dfcc7  movaps xmm9, [rsp]
00007154327dfccc  add rsp, 0x30
00007154327dfcd0  vmovaps xmm0, [rsp]
00007154327dfcd5  vmovaps xmm1, [rsp+0x10]
00007154327dfcdb  vmovaps xmm2, [rsp+0x20]
00007154327dfce1  vmovaps xmm3, [rsp+0x30]
00007154327dfce7  vmovaps xmm4, [rsp+0x40]
00007154327dfced  vmovaps xmm5, [rsp+0x50]
00007154327dfcf3  vmovaps xmm6, [rsp+0x60]
00007154327dfcf9  vmovaps xmm7, [rsp+0x70]
00007154327dfcff  vmovaps xmm8, [rsp+0x80]
00007154327dfd08  vmovaps xmm10, [rsp+0x90]
00007154327dfd11  vmovaps xmm11, [rsp+0xA0]
00007154327dfd1a  vmovaps xmm12, [rsp+0xB0]
00007154327dfd23  vmovaps xmm13, [rsp+0xC0]
00007154327dfd2c  vmovaps xmm14, [rsp+0xD0]
00007154327dfd35  vmovaps xmm15, [rsp+0xE0]
00007154327dfd3e  add rsp, 0xF0
00007154327dfd45  pop r11
00007154327dfd47  pop r10
00007154327dfd49  pop r9
00007154327dfd4b  pop r8
00007154327dfd4d  pop rsi
00007154327dfd4e  pop rdi
00007154327dfd4f  pop rdx
00007154327dfd50  pop rcx
00007154327dfd51  pop rax
00007154327dfd52  add rsp, 0x08
00007154327dfd56  jmp 0x00007154327DC505
00007154327dfd5b  sub rsp, 0x08
00007154327dfd5f  push rax
00007154327dfd60  push rcx
00007154327dfd61  push rdx
00007154327dfd62  push rdi
00007154327dfd63  push rsi
00007154327dfd64  push r8
00007154327dfd66  push r9
00007154327dfd68  push r10
00007154327dfd6a  push r11
00007154327dfd6c  sub rsp, 0xF0
00007154327dfd73  vmovaps [rsp], xmm0
00007154327dfd78  vmovaps [rsp+0x10], xmm1
00007154327dfd7e  vmovaps [rsp+0x20], xmm2
00007154327dfd84  vmovaps [rsp+0x30], xmm3
00007154327dfd8a  vmovaps [rsp+0x40], xmm4
00007154327dfd90  vmovaps [rsp+0x50], xmm5
00007154327dfd96  vmovaps [rsp+0x60], xmm6
00007154327dfd9c  vmovaps [rsp+0x70], xmm7
00007154327dfda2  vmovaps [rsp+0x80], xmm8
00007154327dfdab  vmovaps [rsp+0x90], xmm9
00007154327dfdb4  vmovaps [rsp+0xA0], xmm10
00007154327dfdbd  vmovaps [rsp+0xB0], xmm12
00007154327dfdc6  vmovaps [rsp+0xC0], xmm13
00007154327dfdcf  vmovaps [rsp+0xD0], xmm14
00007154327dfdd8  vmovaps [rsp+0xE0], xmm15
00007154327dfde1  sub rsp, 0x30
00007154327dfde5  movaps [rsp], xmm11
00007154327dfdea  movaps [rsp+0x10], xmm10
00007154327dfdf0  movaps [rsp+0x20], xmm6
00007154327dfdf5  lea rdi, [rsp]
00007154327dfdf9  mov esi, 0x00
00007154327dfdfe  mov rax, 0x5A63B06A5530
00007154327dfe08  call rax
00007154327dfe0a  movaps xmm11, [rsp]
00007154327dfe0f  add rsp, 0x30
00007154327dfe13  vmovaps xmm0, [rsp]
00007154327dfe18  vmovaps xmm1, [rsp+0x10]
00007154327dfe1e  vmovaps xmm2, [rsp+0x20]
00007154327dfe24  vmovaps xmm3, [rsp+0x30]
00007154327dfe2a  vmovaps xmm4, [rsp+0x40]
00007154327dfe30  vmovaps xmm5, [rsp+0x50]
00007154327dfe36  vmovaps xmm6, [rsp+0x60]
00007154327dfe3c  vmovaps xmm7, [rsp+0x70]
00007154327dfe42  vmovaps xmm8, [rsp+0x80]
00007154327dfe4b  vmovaps xmm9, [rsp+0x90]
00007154327dfe54  vmovaps xmm10, [rsp+0xA0]
00007154327dfe5d  vmovaps xmm12, [rsp+0xB0]
00007154327dfe66  vmovaps xmm13, [rsp+0xC0]
00007154327dfe6f  vmovaps xmm14, [rsp+0xD0]
00007154327dfe78  vmovaps xmm15, [rsp+0xE0]
00007154327dfe81  add rsp, 0xF0
00007154327dfe88  pop r11
00007154327dfe8a  pop r10
00007154327dfe8c  pop r9
00007154327dfe8e  pop r8
00007154327dfe90  pop rsi
00007154327dfe91  pop rdi
00007154327dfe92  pop rdx
00007154327dfe93  pop rcx
00007154327dfe94  pop rax
00007154327dfe95  add rsp, 0x08
00007154327dfe99  jmp 0x00007154327DC520
00007154327dfe9e  sub rsp, 0x08
00007154327dfea2  push rax
00007154327dfea3  push rcx
00007154327dfea4  push rdx
00007154327dfea5  push rdi
00007154327dfea6  push rsi
00007154327dfea7  push r8
00007154327dfea9  push r9
00007154327dfeab  push r10
00007154327dfead  push r11
00007154327dfeaf  sub rsp, 0xF0
00007154327dfeb6  vmovaps [rsp], xmm0
00007154327dfebb  vmovaps [rsp+0x10], xmm1
00007154327dfec1  vmovaps [rsp+0x20], xmm2
00007154327dfec7  vmovaps [rsp+0x30], xmm3
00007154327dfecd  vmovaps [rsp+0x40], xmm4
00007154327dfed3  vmovaps [rsp+0x50], xmm5
00007154327dfed9  vmovaps [rsp+0x60], xmm6
00007154327dfedf  vmovaps [rsp+0x70], xmm7
00007154327dfee5  vmovaps [rsp+0x80], xmm8
00007154327dfeee  vmovaps [rsp+0x90], xmm9
00007154327dfef7  vmovaps [rsp+0xA0], xmm11
00007154327dff00  vmovaps [rsp+0xB0], xmm12
00007154327dff09  vmovaps [rsp+0xC0], xmm13
00007154327dff12  vmovaps [rsp+0xD0], xmm14
00007154327dff1b  vmovaps [rsp+0xE0], xmm15
00007154327dff24  sub rsp, 0x30
00007154327dff28  movaps [rsp], xmm10
00007154327dff2d  movaps [rsp+0x10], xmm14
00007154327dff33  movaps [rsp+0x20], xmm4
00007154327dff38  lea rdi, [rsp]
00007154327dff3c  mov esi, 0x00
00007154327dff41  mov rax, 0x5A63B06A5530
00007154327dff4b  call rax
00007154327dff4d  movaps xmm10, [rsp]
00007154327dff52  add rsp, 0x30
00007154327dff56  vmovaps xmm0, [rsp]
00007154327dff5b  vmovaps xmm1, [rsp+0x10]
00007154327dff61  vmovaps xmm2, [rsp+0x20]
00007154327dff67  vmovaps xmm3, [rsp+0x30]
00007154327dff6d  vmovaps xmm4, [rsp+0x40]
00007154327dff73  vmovaps xmm5, [rsp+0x50]
00007154327dff79  vmovaps xmm6, [rsp+0x60]
00007154327dff7f  vmovaps xmm7, [rsp+0x70]
00007154327dff85  vmovaps xmm8, [rsp+0x80]
00007154327dff8e  vmovaps xmm9, [rsp+0x90]
00007154327dff97  vmovaps xmm11, [rsp+0xA0]
00007154327dffa0  vmovaps xmm12, [rsp+0xB0]
00007154327dffa9  vmovaps xmm13, [rsp+0xC0]
00007154327dffb2  vmovaps xmm14, [rsp+0xD0]
00007154327dffbb  vmovaps xmm15, [rsp+0xE0]
00007154327dffc4  add rsp, 0xF0
00007154327dffcb  pop r11
00007154327dffcd  pop r10
00007154327dffcf  pop r9
00007154327dffd1  pop r8
00007154327dffd3  pop rsi
00007154327dffd4  pop rdi
00007154327dffd5  pop rdx
00007154327dffd6  pop rcx
00007154327dffd7  pop rax
00007154327dffd8  add rsp, 0x08
00007154327dffdc  jmp 0x00007154327DC53B
00007154327dffe1  sub rsp, 0x08
00007154327dffe5  push rax
00007154327dffe6  push rcx
00007154327dffe7  push rdx
00007154327dffe8  push rdi
00007154327dffe9  push rsi
00007154327dffea  push r8
00007154327dffec  push r9
00007154327dffee  push r10
00007154327dfff0  push r11
00007154327dfff2  sub rsp, 0xF0
00007154327dfff9  vmovaps [rsp], xmm0
00007154327dfffe  vmovaps [rsp+0x10], xmm1
00007154327e0004  vmovaps [rsp+0x20], xmm2
00007154327e000a  vmovaps [rsp+0x30], xmm3
00007154327e0010  vmovaps [rsp+0x40], xmm4
00007154327e0016  vmovaps [rsp+0x50], xmm5
00007154327e001c  vmovaps [rsp+0x60], xmm6
00007154327e0022  vmovaps [rsp+0x70], xmm7
00007154327e0028  vmovaps [rsp+0x80], xmm9
00007154327e0031  vmovaps [rsp+0x90], xmm10
00007154327e003a  vmovaps [rsp+0xA0], xmm11
00007154327e0043  vmovaps [rsp+0xB0], xmm12
00007154327e004c  vmovaps [rsp+0xC0], xmm13
00007154327e0055  vmovaps [rsp+0xD0], xmm14
00007154327e005e  vmovaps [rsp+0xE0], xmm15
00007154327e0067  sub rsp, 0x30
00007154327e006b  movaps [rsp], xmm8
00007154327e0070  movaps [rsp+0x10], xmm1
00007154327e0075  movaps [rsp+0x20], xmm14
00007154327e007b  lea rdi, [rsp]
00007154327e007f  mov esi, 0x00
00007154327e0084  mov rax, 0x5A63B06A5530
00007154327e008e  call rax
00007154327e0090  movaps xmm8, [rsp]
00007154327e0095  add rsp, 0x30
00007154327e0099  vmovaps xmm0, [rsp]
00007154327e009e  vmovaps xmm1, [rsp+0x10]
00007154327e00a4  vmovaps xmm2, [rsp+0x20]
00007154327e00aa  vmovaps xmm3, [rsp+0x30]
00007154327e00b0  vmovaps xmm4, [rsp+0x40]
00007154327e00b6  vmovaps xmm5, [rsp+0x50]
00007154327e00bc  vmovaps xmm6, [rsp+0x60]
00007154327e00c2  vmovaps xmm7, [rsp+0x70]
00007154327e00c8  vmovaps xmm9, [rsp+0x80]
00007154327e00d1  vmovaps xmm10, [rsp+0x90]
00007154327e00da  vmovaps xmm11, [rsp+0xA0]
00007154327e00e3  vmovaps xmm12, [rsp+0xB0]
00007154327e00ec  vmovaps xmm13, [rsp+0xC0]
00007154327e00f5  vmovaps xmm14, [rsp+0xD0]
00007154327e00fe  vmovaps xmm15, [rsp+0xE0]
00007154327e0107  add rsp, 0xF0
00007154327e010e  pop r11
00007154327e0110  pop r10
00007154327e0112  pop r9
00007154327e0114  pop r8
00007154327e0116  pop rsi
00007154327e0117  pop rdi
00007154327e0118  pop rdx
00007154327e0119  pop rcx
00007154327e011a  pop rax
00007154327e011b  add rsp, 0x08
00007154327e011f  jmp 0x00007154327DC561
00007154327e0124  sub rsp, 0x08
00007154327e0128  push rax
00007154327e0129  push rcx
00007154327e012a  push rdx
00007154327e012b  push rdi
00007154327e012c  push rsi
00007154327e012d  push r8
00007154327e012f  push r9
00007154327e0131  push r10
00007154327e0133  push r11
00007154327e0135  sub rsp, 0xF0
00007154327e013c  vmovaps [rsp], xmm0
00007154327e0141  vmovaps [rsp+0x10], xmm1
00007154327e0147  vmovaps [rsp+0x20], xmm2
00007154327e014d  vmovaps [rsp+0x30], xmm3
00007154327e0153  vmovaps [rsp+0x40], xmm4
00007154327e0159  vmovaps [rsp+0x50], xmm5
00007154327e015f  vmovaps [rsp+0x60], xmm7
00007154327e0165  vmovaps [rsp+0x70], xmm8
00007154327e016b  vmovaps [rsp+0x80], xmm9
00007154327e0174  vmovaps [rsp+0x90], xmm10
00007154327e017d  vmovaps [rsp+0xA0], xmm11
00007154327e0186  vmovaps [rsp+0xB0], xmm12
00007154327e018f  vmovaps [rsp+0xC0], xmm13
00007154327e0198  vmovaps [rsp+0xD0], xmm14
00007154327e01a1  vmovaps [rsp+0xE0], xmm15
00007154327e01aa  sub rsp, 0x30
00007154327e01ae  movaps [rsp], xmm6
00007154327e01b2  movaps [rsp+0x10], xmm1
00007154327e01b7  movaps [rsp+0x20], xmm14
00007154327e01bd  lea rdi, [rsp]
00007154327e01c1  mov esi, 0x00
00007154327e01c6  mov rax, 0x5A63B06A5530
00007154327e01d0  call rax
00007154327e01d2  movaps xmm6, [rsp]
00007154327e01d6  add rsp, 0x30
00007154327e01da  vmovaps xmm0, [rsp]
00007154327e01df  vmovaps xmm1, [rsp+0x10]
00007154327e01e5  vmovaps xmm2, [rsp+0x20]
00007154327e01eb  vmovaps xmm3, [rsp+0x30]
00007154327e01f1  vmovaps xmm4, [rsp+0x40]
00007154327e01f7  vmovaps xmm5, [rsp+0x50]
00007154327e01fd  vmovaps xmm7, [rsp+0x60]
00007154327e0203  vmovaps xmm8, [rsp+0x70]
00007154327e0209  vmovaps xmm9, [rsp+0x80]
00007154327e0212  vmovaps xmm10, [rsp+0x90]
00007154327e021b  vmovaps xmm11, [rsp+0xA0]
00007154327e0224  vmovaps xmm12, [rsp+0xB0]
00007154327e022d  vmovaps xmm13, [rsp+0xC0]
00007154327e0236  vmovaps xmm14, [rsp+0xD0]
00007154327e023f  vmovaps xmm15, [rsp+0xE0]
00007154327e0248  add rsp, 0xF0
00007154327e024f  pop r11
00007154327e0251  pop r10
00007154327e0253  pop r9
00007154327e0255  pop r8
00007154327e0257  pop rsi
00007154327e0258  pop rdi
00007154327e0259  pop rdx
00007154327e025a  pop rcx
00007154327e025b  pop rax
00007154327e025c  add rsp, 0x08
00007154327e0260  jmp 0x00007154327DC58D
00007154327e0265  sub rsp, 0x08
00007154327e0269  push rax
00007154327e026a  push rcx
00007154327e026b  push rdx
00007154327e026c  push rdi
00007154327e026d  push rsi
00007154327e026e  push r8
00007154327e0270  push r9
00007154327e0272  push r10
00007154327e0274  push r11
00007154327e0276  sub rsp, 0xF0
00007154327e027d  vmovaps [rsp], xmm0
00007154327e0282  vmovaps [rsp+0x10], xmm1
00007154327e0288  vmovaps [rsp+0x20], xmm2
00007154327e028e  vmovaps [rsp+0x30], xmm3
00007154327e0294  vmovaps [rsp+0x40], xmm4
00007154327e029a  vmovaps [rsp+0x50], xmm5
00007154327e02a0  vmovaps [rsp+0x60], xmm6
00007154327e02a6  vmovaps [rsp+0x70], xmm7
00007154327e02ac  vmovaps [rsp+0x80], xmm8
00007154327e02b5  vmovaps [rsp+0x90], xmm9
00007154327e02be  vmovaps [rsp+0xA0], xmm10
00007154327e02c7  vmovaps [rsp+0xB0], xmm11
00007154327e02d0  vmovaps [rsp+0xC0], xmm12
00007154327e02d9  vmovaps [rsp+0xD0], xmm13
00007154327e02e2  vmovaps [rsp+0xE0], xmm15
00007154327e02eb  sub rsp, 0x30
00007154327e02ef  movaps [rsp], xmm14
00007154327e02f4  movaps [rsp+0x10], xmm12
00007154327e02fa  movaps [rsp+0x20], xmm1
00007154327e02ff  lea rdi, [rsp]
00007154327e0303  mov esi, 0x00
00007154327e0308  mov rax, 0x5A63B06A5530
00007154327e0312  call rax
00007154327e0314  movaps xmm14, [rsp]
00007154327e0319  add rsp, 0x30
00007154327e031d  vmovaps xmm0, [rsp]
00007154327e0322  vmovaps xmm1, [rsp+0x10]
00007154327e0328  vmovaps xmm2, [rsp+0x20]
00007154327e032e  vmovaps xmm3, [rsp+0x30]
00007154327e0334  vmovaps xmm4, [rsp+0x40]
00007154327e033a  vmovaps xmm5, [rsp+0x50]
00007154327e0340  vmovaps xmm6, [rsp+0x60]
00007154327e0346  vmovaps xmm7, [rsp+0x70]
00007154327e034c  vmovaps xmm8, [rsp+0x80]
00007154327e0355  vmovaps xmm9, [rsp+0x90]
00007154327e035e  vmovaps xmm10, [rsp+0xA0]
00007154327e0367  vmovaps xmm11, [rsp+0xB0]
00007154327e0370  vmovaps xmm12, [rsp+0xC0]
00007154327e0379  vmovaps xmm13, [rsp+0xD0]
00007154327e0382  vmovaps xmm15, [rsp+0xE0]
00007154327e038b  add rsp, 0xF0
00007154327e0392  pop r11
00007154327e0394  pop r10
00007154327e0396  pop r9
00007154327e0398  pop r8
00007154327e039a  pop rsi
00007154327e039b  pop rdi
00007154327e039c  pop rdx
00007154327e039d  pop rcx
00007154327e039e  pop rax
00007154327e039f  add rsp, 0x08
00007154327e03a3  jmp 0x00007154327DC5B3
00007154327e03a8  sub rsp, 0x08
00007154327e03ac  push rax
00007154327e03ad  push rcx
00007154327e03ae  push rdx
00007154327e03af  push rdi
00007154327e03b0  push rsi
00007154327e03b1  push r8
00007154327e03b3  push r9
00007154327e03b5  push r10
00007154327e03b7  push r11
00007154327e03b9  sub rsp, 0xF0
00007154327e03c0  vmovaps [rsp], xmm0
00007154327e03c5  vmovaps [rsp+0x10], xmm2
00007154327e03cb  vmovaps [rsp+0x20], xmm3
00007154327e03d1  vmovaps [rsp+0x30], xmm4
00007154327e03d7  vmovaps [rsp+0x40], xmm5
00007154327e03dd  vmovaps [rsp+0x50], xmm6
00007154327e03e3  vmovaps [rsp+0x60], xmm7
00007154327e03e9  vmovaps [rsp+0x70], xmm8
00007154327e03ef  vmovaps [rsp+0x80], xmm9
00007154327e03f8  vmovaps [rsp+0x90], xmm10
00007154327e0401  vmovaps [rsp+0xA0], xmm11
00007154327e040a  vmovaps [rsp+0xB0], xmm12
00007154327e0413  vmovaps [rsp+0xC0], xmm13
00007154327e041c  vmovaps [rsp+0xD0], xmm14
00007154327e0425  vmovaps [rsp+0xE0], xmm15
00007154327e042e  sub rsp, 0x30
00007154327e0432  movaps [rsp], xmm1
00007154327e0436  movaps [rsp+0x10], xmm13
00007154327e043c  movaps [rsp+0x20], xmm9
00007154327e0442  lea rdi, [rsp]
00007154327e0446  mov esi, 0x00
00007154327e044b  mov rax, 0x5A63B06A5530
00007154327e0455  call rax
00007154327e0457  movaps xmm1, [rsp]
00007154327e045b  add rsp, 0x30
00007154327e045f  vmovaps xmm0, [rsp]
00007154327e0464  vmovaps xmm2, [rsp+0x10]
00007154327e046a  vmovaps xmm3, [rsp+0x20]
00007154327e0470  vmovaps xmm4, [rsp+0x30]
00007154327e0476  vmovaps xmm5, [rsp+0x40]
00007154327e047c  vmovaps xmm6, [rsp+0x50]
00007154327e0482  vmovaps xmm7, [rsp+0x60]
00007154327e0488  vmovaps xmm8, [rsp+0x70]
00007154327e048e  vmovaps xmm9, [rsp+0x80]
00007154327e0497  vmovaps xmm10, [rsp+0x90]
00007154327e04a0  vmovaps xmm11, [rsp+0xA0]
00007154327e04a9  vmovaps xmm12, [rsp+0xB0]
00007154327e04b2  vmovaps xmm13, [rsp+0xC0]
00007154327e04bb  vmovaps xmm14, [rsp+0xD0]
00007154327e04c4  vmovaps xmm15, [rsp+0xE0]
00007154327e04cd  add rsp, 0xF0
00007154327e04d4  pop r11
00007154327e04d6  pop r10
00007154327e04d8  pop r9
00007154327e04da  pop r8
00007154327e04dc  pop rsi
00007154327e04dd  pop rdi
00007154327e04de  pop rdx
00007154327e04df  pop rcx
00007154327e04e0  pop rax
00007154327e04e1  add rsp, 0x08
00007154327e04e5  jmp 0x00007154327DC5CD
00007154327e04ea  sub rsp, 0x08
00007154327e04ee  push rax
00007154327e04ef  push rcx
00007154327e04f0  push rdx
00007154327e04f1  push rdi
00007154327e04f2  push rsi
00007154327e04f3  push r8
00007154327e04f5  push r9
00007154327e04f7  push r10
00007154327e04f9  push r11
00007154327e04fb  sub rsp, 0xF0
00007154327e0502  vmovaps [rsp], xmm0
00007154327e0507  vmovaps [rsp+0x10], xmm1
00007154327e050d  vmovaps [rsp+0x20], xmm2
00007154327e0513  vmovaps [rsp+0x30], xmm3
00007154327e0519  vmovaps [rsp+0x40], xmm4
00007154327e051f  vmovaps [rsp+0x50], xmm5
00007154327e0525  vmovaps [rsp+0x60], xmm6
00007154327e052b  vmovaps [rsp+0x70], xmm7
00007154327e0531  vmovaps [rsp+0x80], xmm8
00007154327e053a  vmovaps [rsp+0x90], xmm9
00007154327e0543  vmovaps [rsp+0xA0], xmm10
00007154327e054c  vmovaps [rsp+0xB0], xmm11
00007154327e0555  vmovaps [rsp+0xC0], xmm13
00007154327e055e  vmovaps [rsp+0xD0], xmm14
00007154327e0567  vmovaps [rsp+0xE0], xmm15
00007154327e0570  sub rsp, 0x30
00007154327e0574  movaps [rsp], xmm12
00007154327e0579  movaps [rsp+0x10], xmm7
00007154327e057e  movaps [rsp+0x20], xmm13
00007154327e0584  lea rdi, [rsp]
00007154327e0588  mov esi, 0x00
00007154327e058d  mov rax, 0x5A63B06A5530
00007154327e0597  call rax
00007154327e0599  movaps xmm12, [rsp]
00007154327e059e  add rsp, 0x30
00007154327e05a2  vmovaps xmm0, [rsp]
00007154327e05a7  vmovaps xmm1, [rsp+0x10]
00007154327e05ad  vmovaps xmm2, [rsp+0x20]
00007154327e05b3  vmovaps xmm3, [rsp+0x30]
00007154327e05b9  vmovaps xmm4, [rsp+0x40]
00007154327e05bf  vmovaps xmm5, [rsp+0x50]
00007154327e05c5  vmovaps xmm6, [rsp+0x60]
00007154327e05cb  vmovaps xmm7, [rsp+0x70]
00007154327e05d1  vmovaps xmm8, [rsp+0x80]
00007154327e05da  vmovaps xmm9, [rsp+0x90]
00007154327e05e3  vmovaps xmm10, [rsp+0xA0]
00007154327e05ec  vmovaps xmm11, [rsp+0xB0]
00007154327e05f5  vmovaps xmm13, [rsp+0xC0]
00007154327e05fe  vmovaps xmm14, [rsp+0xD0]
00007154327e0607  vmovaps xmm15, [rsp+0xE0]
00007154327e0610  add rsp, 0xF0
00007154327e0617  pop r11
00007154327e0619  pop r10
00007154327e061b  pop r9
00007154327e061d  pop r8
00007154327e061f  pop rsi
00007154327e0620  pop rdi
00007154327e0621  pop rdx
00007154327e0622  pop rcx
00007154327e0623  pop rax
00007154327e0624  add rsp, 0x08
00007154327e0628  jmp 0x00007154327DC5F4
00007154327e062d  sub rsp, 0x08
00007154327e0631  push rax
00007154327e0632  push rcx
00007154327e0633  push rdx
00007154327e0634  push rdi
00007154327e0635  push rsi
00007154327e0636  push r8
00007154327e0638  push r9
00007154327e063a  push r10
00007154327e063c  push r11
00007154327e063e  sub rsp, 0xF0
00007154327e0645  vmovaps [rsp], xmm0
00007154327e064a  vmovaps [rsp+0x10], xmm1
00007154327e0650  vmovaps [rsp+0x20], xmm2
00007154327e0656  vmovaps [rsp+0x30], xmm3
00007154327e065c  vmovaps [rsp+0x40], xmm4
00007154327e0662  vmovaps [rsp+0x50], xmm5
00007154327e0668  vmovaps [rsp+0x60], xmm6
00007154327e066e  vmovaps [rsp+0x70], xmm7
00007154327e0674  vmovaps [rsp+0x80], xmm8
00007154327e067d  vmovaps [rsp+0x90], xmm9
00007154327e0686  vmovaps [rsp+0xA0], xmm10
00007154327e068f  vmovaps [rsp+0xB0], xmm11
00007154327e0698  vmovaps [rsp+0xC0], xmm12
00007154327e06a1  vmovaps [rsp+0xD0], xmm14
00007154327e06aa  vmovaps [rsp+0xE0], xmm15
00007154327e06b3  sub rsp, 0x30
00007154327e06b7  movaps [rsp], xmm13
00007154327e06bc  movaps [rsp+0x10], xmm15
00007154327e06c2  movaps [rsp+0x20], xmm8
00007154327e06c8  lea rdi, [rsp]
00007154327e06cc  mov esi, 0x00
00007154327e06d1  mov rax, 0x5A63B06A5530
00007154327e06db  call rax
00007154327e06dd  movaps xmm13, [rsp]
00007154327e06e2  add rsp, 0x30
00007154327e06e6  vmovaps xmm0, [rsp]
00007154327e06eb  vmovaps xmm1, [rsp+0x10]
00007154327e06f1  vmovaps xmm2, [rsp+0x20]
00007154327e06f7  vmovaps xmm3, [rsp+0x30]
00007154327e06fd  vmovaps xmm4, [rsp+0x40]
00007154327e0703  vmovaps xmm5, [rsp+0x50]
00007154327e0709  vmovaps xmm6, [rsp+0x60]
00007154327e070f  vmovaps xmm7, [rsp+0x70]
00007154327e0715  vmovaps xmm8, [rsp+0x80]
00007154327e071e  vmovaps xmm9, [rsp+0x90]
00007154327e0727  vmovaps xmm10, [rsp+0xA0]
00007154327e0730  vmovaps xmm11, [rsp+0xB0]
00007154327e0739  vmovaps xmm12, [rsp+0xC0]
00007154327e0742  vmovaps xmm14, [rsp+0xD0]
00007154327e074b  vmovaps xmm15, [rsp+0xE0]
00007154327e0754  add rsp, 0xF0
00007154327e075b  pop r11
00007154327e075d  pop r10
00007154327e075f  pop r9
00007154327e0761  pop r8
00007154327e0763  pop rsi
00007154327e0764  pop rdi
00007154327e0765  pop rdx
00007154327e0766  pop rcx
00007154327e0767  pop rax
00007154327e0768  add rsp, 0x08
00007154327e076c  jmp 0x00007154327DC60F
00007154327e0771  sub rsp, 0x08
00007154327e0775  push rax
00007154327e0776  push rcx
00007154327e0777  push rdx
00007154327e0778  push rdi
00007154327e0779  push rsi
00007154327e077a  push r8
00007154327e077c  push r9
00007154327e077e  push r10
00007154327e0780  push r11
00007154327e0782  sub rsp, 0xF0
00007154327e0789  vmovaps [rsp], xmm0
00007154327e078e  vmovaps [rsp+0x10], xmm1
00007154327e0794  vmovaps [rsp+0x20], xmm2
00007154327e079a  vmovaps [rsp+0x30], xmm3
00007154327e07a0  vmovaps [rsp+0x40], xmm4
00007154327e07a6  vmovaps [rsp+0x50], xmm5
00007154327e07ac  vmovaps [rsp+0x60], xmm6
00007154327e07b2  vmovaps [rsp+0x70], xmm7
00007154327e07b8  vmovaps [rsp+0x80], xmm9
00007154327e07c1  vmovaps [rsp+0x90], xmm10
00007154327e07ca  vmovaps [rsp+0xA0], xmm11
00007154327e07d3  vmovaps [rsp+0xB0], xmm12
00007154327e07dc  vmovaps [rsp+0xC0], xmm13
00007154327e07e5  vmovaps [rsp+0xD0], xmm14
00007154327e07ee  vmovaps [rsp+0xE0], xmm15
00007154327e07f7  sub rsp, 0x30
00007154327e07fb  movaps [rsp], xmm8
00007154327e0800  movaps [rsp+0x10], xmm15
00007154327e0806  movaps [rsp+0x20], xmm9
00007154327e080c  lea rdi, [rsp]
00007154327e0810  mov esi, 0x00
00007154327e0815  mov rax, 0x5A63B06A5530
00007154327e081f  call rax
00007154327e0821  movaps xmm8, [rsp]
00007154327e0826  add rsp, 0x30
00007154327e082a  vmovaps xmm0, [rsp]
00007154327e082f  vmovaps xmm1, [rsp+0x10]
00007154327e0835  vmovaps xmm2, [rsp+0x20]
00007154327e083b  vmovaps xmm3, [rsp+0x30]
00007154327e0841  vmovaps xmm4, [rsp+0x40]
00007154327e0847  vmovaps xmm5, [rsp+0x50]
00007154327e084d  vmovaps xmm6, [rsp+0x60]
00007154327e0853  vmovaps xmm7, [rsp+0x70]
00007154327e0859  vmovaps xmm9, [rsp+0x80]
00007154327e0862  vmovaps xmm10, [rsp+0x90]
00007154327e086b  vmovaps xmm11, [rsp+0xA0]
00007154327e0874  vmovaps xmm12, [rsp+0xB0]
00007154327e087d  vmovaps xmm13, [rsp+0xC0]
00007154327e0886  vmovaps xmm14, [rsp+0xD0]
00007154327e088f  vmovaps xmm15, [rsp+0xE0]
00007154327e0898  add rsp, 0xF0
00007154327e089f  pop r11
00007154327e08a1  pop r10
00007154327e08a3  pop r9
00007154327e08a5  pop r8
00007154327e08a7  pop rsi
00007154327e08a8  pop rdi
00007154327e08a9  pop rdx
00007154327e08aa  pop rcx
00007154327e08ab  pop rax
00007154327e08ac  add rsp, 0x08
00007154327e08b0  jmp 0x00007154327DC63D
00007154327e08b5  sub rsp, 0x08
00007154327e08b9  push rax
00007154327e08ba  push rcx
00007154327e08bb  push rdx
00007154327e08bc  push rdi
00007154327e08bd  push rsi
00007154327e08be  push r8
00007154327e08c0  push r9
00007154327e08c2  push r10
00007154327e08c4  push r11
00007154327e08c6  sub rsp, 0xF0
00007154327e08cd  vmovaps [rsp], xmm0
00007154327e08d2  vmovaps [rsp+0x10], xmm1
00007154327e08d8  vmovaps [rsp+0x20], xmm2
00007154327e08de  vmovaps [rsp+0x30], xmm3
00007154327e08e4  vmovaps [rsp+0x40], xmm4
00007154327e08ea  vmovaps [rsp+0x50], xmm5
00007154327e08f0  vmovaps [rsp+0x60], xmm6
00007154327e08f6  vmovaps [rsp+0x70], xmm7
00007154327e08fc  vmovaps [rsp+0x80], xmm8
00007154327e0905  vmovaps [rsp+0x90], xmm9
00007154327e090e  vmovaps [rsp+0xA0], xmm10
00007154327e0917  vmovaps [rsp+0xB0], xmm11
00007154327e0920  vmovaps [rsp+0xC0], xmm12
00007154327e0929  vmovaps [rsp+0xD0], xmm13
00007154327e0932  vmovaps [rsp+0xE0], xmm14
00007154327e093b  sub rsp, 0x30
00007154327e093f  movaps [rsp], xmm15
00007154327e0944  movaps [rsp+0x10], xmm11
00007154327e094a  movaps [rsp+0x20], xmm6
00007154327e094f  lea rdi, [rsp]
00007154327e0953  mov esi, 0x00
00007154327e0958  mov rax, 0x5A63B06A5530
00007154327e0962  call rax
00007154327e0964  movaps xmm15, [rsp]
00007154327e0969  add rsp, 0x30
00007154327e096d  vmovaps xmm0, [rsp]
00007154327e0972  vmovaps xmm1, [rsp+0x10]
00007154327e0978  vmovaps xmm2, [rsp+0x20]
00007154327e097e  vmovaps xmm3, [rsp+0x30]
00007154327e0984  vmovaps xmm4, [rsp+0x40]
00007154327e098a  vmovaps xmm5, [rsp+0x50]
00007154327e0990  vmovaps xmm6, [rsp+0x60]
00007154327e0996  vmovaps xmm7, [rsp+0x70]
00007154327e099c  vmovaps xmm8, [rsp+0x80]
00007154327e09a5  vmovaps xmm9, [rsp+0x90]
00007154327e09ae  vmovaps xmm10, [rsp+0xA0]
00007154327e09b7  vmovaps xmm11, [rsp+0xB0]
00007154327e09c0  vmovaps xmm12, [rsp+0xC0]
00007154327e09c9  vmovaps xmm13, [rsp+0xD0]
00007154327e09d2  vmovaps xmm14, [rsp+0xE0]
00007154327e09db  add rsp, 0xF0
00007154327e09e2  pop r11
00007154327e09e4  pop r10
00007154327e09e6  pop r9
00007154327e09e8  pop r8
00007154327e09ea  pop rsi
00007154327e09eb  pop rdi
00007154327e09ec  pop rdx
00007154327e09ed  pop rcx
00007154327e09ee  pop rax
00007154327e09ef  add rsp, 0x08
00007154327e09f3  jmp 0x00007154327DC658
00007154327e09f8  sub rsp, 0x08
00007154327e09fc  push rax
00007154327e09fd  push rcx
00007154327e09fe  push rdx
00007154327e09ff  push rdi
00007154327e0a00  push rsi
00007154327e0a01  push r8
00007154327e0a03  push r9
00007154327e0a05  push r10
00007154327e0a07  push r11
00007154327e0a09  sub rsp, 0xF0
00007154327e0a10  vmovaps [rsp], xmm0
00007154327e0a15  vmovaps [rsp+0x10], xmm1
00007154327e0a1b  vmovaps [rsp+0x20], xmm2
00007154327e0a21  vmovaps [rsp+0x30], xmm3
00007154327e0a27  vmovaps [rsp+0x40], xmm4
00007154327e0a2d  vmovaps [rsp+0x50], xmm5
00007154327e0a33  vmovaps [rsp+0x60], xmm6
00007154327e0a39  vmovaps [rsp+0x70], xmm8
00007154327e0a3f  vmovaps [rsp+0x80], xmm9
00007154327e0a48  vmovaps [rsp+0x90], xmm10
00007154327e0a51  vmovaps [rsp+0xA0], xmm11
00007154327e0a5a  vmovaps [rsp+0xB0], xmm12
00007154327e0a63  vmovaps [rsp+0xC0], xmm13
00007154327e0a6c  vmovaps [rsp+0xD0], xmm14
00007154327e0a75  vmovaps [rsp+0xE0], xmm15
00007154327e0a7e  sub rsp, 0x30
00007154327e0a82  movaps [rsp], xmm7
00007154327e0a86  movaps [rsp+0x10], xmm11
00007154327e0a8c  movaps [rsp+0x20], xmm9
00007154327e0a92  lea rdi, [rsp]
00007154327e0a96  mov esi, 0x00
00007154327e0a9b  mov rax, 0x5A63B06A5530
00007154327e0aa5  call rax
00007154327e0aa7  movaps xmm7, [rsp]
00007154327e0aab  add rsp, 0x30
00007154327e0aaf  vmovaps xmm0, [rsp]
00007154327e0ab4  vmovaps xmm1, [rsp+0x10]
00007154327e0aba  vmovaps xmm2, [rsp+0x20]
00007154327e0ac0  vmovaps xmm3, [rsp+0x30]
00007154327e0ac6  vmovaps xmm4, [rsp+0x40]
00007154327e0acc  vmovaps xmm5, [rsp+0x50]
00007154327e0ad2  vmovaps xmm6, [rsp+0x60]
00007154327e0ad8  vmovaps xmm8, [rsp+0x70]
00007154327e0ade  vmovaps xmm9, [rsp+0x80]
00007154327e0ae7  vmovaps xmm10, [rsp+0x90]
00007154327e0af0  vmovaps xmm11, [rsp+0xA0]
00007154327e0af9  vmovaps xmm12, [rsp+0xB0]
00007154327e0b02  vmovaps xmm13, [rsp+0xC0]
00007154327e0b0b  vmovaps xmm14, [rsp+0xD0]
00007154327e0b14  vmovaps xmm15, [rsp+0xE0]
00007154327e0b1d  add rsp, 0xF0
00007154327e0b24  pop r11
00007154327e0b26  pop r10
00007154327e0b28  pop r9
00007154327e0b2a  pop r8
00007154327e0b2c  pop rsi
00007154327e0b2d  pop rdi
00007154327e0b2e  pop rdx
00007154327e0b2f  pop rcx
00007154327e0b30  pop rax
00007154327e0b31  add rsp, 0x08
00007154327e0b35  jmp 0x00007154327DC685
00007154327e0b3a  sub rsp, 0x08
00007154327e0b3e  push rax
00007154327e0b3f  push rcx
00007154327e0b40  push rdx
00007154327e0b41  push rdi
00007154327e0b42  push rsi
00007154327e0b43  push r8
00007154327e0b45  push r9
00007154327e0b47  push r10
00007154327e0b49  push r11
00007154327e0b4b  sub rsp, 0xF0
00007154327e0b52  vmovaps [rsp], xmm0
00007154327e0b57  vmovaps [rsp+0x10], xmm1
00007154327e0b5d  vmovaps [rsp+0x20], xmm2
00007154327e0b63  vmovaps [rsp+0x30], xmm3
00007154327e0b69  vmovaps [rsp+0x40], xmm4
00007154327e0b6f  vmovaps [rsp+0x50], xmm5
00007154327e0b75  vmovaps [rsp+0x60], xmm6
00007154327e0b7b  vmovaps [rsp+0x70], xmm7
00007154327e0b81  vmovaps [rsp+0x80], xmm8
00007154327e0b8a  vmovaps [rsp+0x90], xmm9
00007154327e0b93  vmovaps [rsp+0xA0], xmm10
00007154327e0b9c  vmovaps [rsp+0xB0], xmm12
00007154327e0ba5  vmovaps [rsp+0xC0], xmm13
00007154327e0bae  vmovaps [rsp+0xD0], xmm14
00007154327e0bb7  vmovaps [rsp+0xE0], xmm15
00007154327e0bc0  sub rsp, 0x30
00007154327e0bc4  movaps [rsp], xmm11
00007154327e0bc9  movaps [rsp+0x10], xmm10
00007154327e0bcf  movaps [rsp+0x20], xmm14
00007154327e0bd5  lea rdi, [rsp]
00007154327e0bd9  mov esi, 0x00
00007154327e0bde  mov rax, 0x5A63B06A5530
00007154327e0be8  call rax
00007154327e0bea  movaps xmm11, [rsp]
00007154327e0bef  add rsp, 0x30
00007154327e0bf3  vmovaps xmm0, [rsp]
00007154327e0bf8  vmovaps xmm1, [rsp+0x10]
00007154327e0bfe  vmovaps xmm2, [rsp+0x20]
00007154327e0c04  vmovaps xmm3, [rsp+0x30]
00007154327e0c0a  vmovaps xmm4, [rsp+0x40]
00007154327e0c10  vmovaps xmm5, [rsp+0x50]
00007154327e0c16  vmovaps xmm6, [rsp+0x60]
00007154327e0c1c  vmovaps xmm7, [rsp+0x70]
00007154327e0c22  vmovaps xmm8, [rsp+0x80]
00007154327e0c2b  vmovaps xmm9, [rsp+0x90]
00007154327e0c34  vmovaps xmm10, [rsp+0xA0]
00007154327e0c3d  vmovaps xmm12, [rsp+0xB0]
00007154327e0c46  vmovaps xmm13, [rsp+0xC0]
00007154327e0c4f  vmovaps xmm14, [rsp+0xD0]
00007154327e0c58  vmovaps xmm15, [rsp+0xE0]
00007154327e0c61  add rsp, 0xF0
00007154327e0c68  pop r11
00007154327e0c6a  pop r10
00007154327e0c6c  pop r9
00007154327e0c6e  pop r8
00007154327e0c70  pop rsi
00007154327e0c71  pop rdi
00007154327e0c72  pop rdx
00007154327e0c73  pop rcx
00007154327e0c74  pop rax
00007154327e0c75  add rsp, 0x08
00007154327e0c79  jmp 0x00007154327DC6A0
00007154327e0c7e  call 0x00007154326C33A0
00007154327e0c83  jmp 0x00007154327DC6AA
00007154327e0c88  sub rsp, 0x08
00007154327e0c8c  push rax
00007154327e0c8d  push rcx
00007154327e0c8e  push rdx
00007154327e0c8f  push rdi
00007154327e0c90  push rsi
00007154327e0c91  push r8
00007154327e0c93  push r9
00007154327e0c95  push r10
00007154327e0c97  push r11
00007154327e0c99  sub rsp, 0xF0
00007154327e0ca0  vmovaps [rsp], xmm0
00007154327e0ca5  vmovaps [rsp+0x10], xmm1
00007154327e0cab  vmovaps [rsp+0x20], xmm2
00007154327e0cb1  vmovaps [rsp+0x30], xmm3
00007154327e0cb7  vmovaps [rsp+0x40], xmm4
00007154327e0cbd  vmovaps [rsp+0x50], xmm5
00007154327e0cc3  vmovaps [rsp+0x60], xmm6
00007154327e0cc9  vmovaps [rsp+0x70], xmm7
00007154327e0ccf  vmovaps [rsp+0x80], xmm8
00007154327e0cd8  vmovaps [rsp+0x90], xmm9
00007154327e0ce1  vmovaps [rsp+0xA0], xmm11
00007154327e0cea  vmovaps [rsp+0xB0], xmm12
00007154327e0cf3  vmovaps [rsp+0xC0], xmm13
00007154327e0cfc  vmovaps [rsp+0xD0], xmm14
00007154327e0d05  vmovaps [rsp+0xE0], xmm15
00007154327e0d0e  sub rsp, 0x30
00007154327e0d12  movaps [rsp], xmm10
00007154327e0d17  movaps [rsp+0x10], xmm1
00007154327e0d1c  movaps [rsp+0x20], xmm12
00007154327e0d22  lea rdi, [rsp]
00007154327e0d26  mov esi, 0x00
00007154327e0d2b  mov rax, 0x5A63B06A5530
00007154327e0d35  call rax
00007154327e0d37  movaps xmm10, [rsp]
00007154327e0d3c  add rsp, 0x30
00007154327e0d40  vmovaps xmm0, [rsp]
00007154327e0d45  vmovaps xmm1, [rsp+0x10]
00007154327e0d4b  vmovaps xmm2, [rsp+0x20]
00007154327e0d51  vmovaps xmm3, [rsp+0x30]
00007154327e0d57  vmovaps xmm4, [rsp+0x40]
00007154327e0d5d  vmovaps xmm5, [rsp+0x50]
00007154327e0d63  vmovaps xmm6, [rsp+0x60]
00007154327e0d69  vmovaps xmm7, [rsp+0x70]
00007154327e0d6f  vmovaps xmm8, [rsp+0x80]
00007154327e0d78  vmovaps xmm9, [rsp+0x90]
00007154327e0d81  vmovaps xmm11, [rsp+0xA0]
00007154327e0d8a  vmovaps xmm12, [rsp+0xB0]
00007154327e0d93  vmovaps xmm13, [rsp+0xC0]
00007154327e0d9c  vmovaps xmm14, [rsp+0xD0]
00007154327e0da5  vmovaps xmm15, [rsp+0xE0]
00007154327e0dae  add rsp, 0xF0
00007154327e0db5  pop r11
00007154327e0db7  pop r10
00007154327e0db9  pop r9
00007154327e0dbb  pop r8
00007154327e0dbd  pop rsi
00007154327e0dbe  pop rdi
00007154327e0dbf  pop rdx
00007154327e0dc0  pop rcx
00007154327e0dc1  pop rax
00007154327e0dc2  add rsp, 0x08
00007154327e0dc6  jmp 0x00007154327DC6CD
00007154327e0dcb  sub rsp, 0x08
00007154327e0dcf  push rax
00007154327e0dd0  push rcx
00007154327e0dd1  push rdx
00007154327e0dd2  push rdi
00007154327e0dd3  push rsi
00007154327e0dd4  push r8
00007154327e0dd6  push r9
00007154327e0dd8  push r10
00007154327e0dda  push r11
00007154327e0ddc  sub rsp, 0xF0
00007154327e0de3  vmovaps [rsp], xmm0
00007154327e0de8  vmovaps [rsp+0x10], xmm1
00007154327e0dee  vmovaps [rsp+0x20], xmm2
00007154327e0df4  vmovaps [rsp+0x30], xmm3
00007154327e0dfa  vmovaps [rsp+0x40], xmm4
00007154327e0e00  vmovaps [rsp+0x50], xmm5
00007154327e0e06  vmovaps [rsp+0x60], xmm6
00007154327e0e0c  vmovaps [rsp+0x70], xmm7
00007154327e0e12  vmovaps [rsp+0x80], xmm8
00007154327e0e1b  vmovaps [rsp+0x90], xmm9
00007154327e0e24  vmovaps [rsp+0xA0], xmm10
00007154327e0e2d  vmovaps [rsp+0xB0], xmm11
00007154327e0e36  vmovaps [rsp+0xC0], xmm13
00007154327e0e3f  vmovaps [rsp+0xD0], xmm14
00007154327e0e48  vmovaps [rsp+0xE0], xmm15
00007154327e0e51  sub rsp, 0x30
00007154327e0e55  movaps [rsp], xmm12
00007154327e0e5a  movaps [rsp+0x10], xmm14
00007154327e0e60  movaps [rsp+0x20], xmm1
00007154327e0e65  lea rdi, [rsp]
00007154327e0e69  mov esi, 0x00
00007154327e0e6e  mov rax, 0x5A63B06A5530
00007154327e0e78  call rax
00007154327e0e7a  movaps xmm12, [rsp]
00007154327e0e7f  add rsp, 0x30
00007154327e0e83  vmovaps xmm0, [rsp]
00007154327e0e88  vmovaps xmm1, [rsp+0x10]
00007154327e0e8e  vmovaps xmm2, [rsp+0x20]
00007154327e0e94  vmovaps xmm3, [rsp+0x30]
00007154327e0e9a  vmovaps xmm4, [rsp+0x40]
00007154327e0ea0  vmovaps xmm5, [rsp+0x50]
00007154327e0ea6  vmovaps xmm6, [rsp+0x60]
00007154327e0eac  vmovaps xmm7, [rsp+0x70]
00007154327e0eb2  vmovaps xmm8, [rsp+0x80]
00007154327e0ebb  vmovaps xmm9, [rsp+0x90]
00007154327e0ec4  vmovaps xmm10, [rsp+0xA0]
00007154327e0ecd  vmovaps xmm11, [rsp+0xB0]
00007154327e0ed6  vmovaps xmm13, [rsp+0xC0]
00007154327e0edf  vmovaps xmm14, [rsp+0xD0]
00007154327e0ee8  vmovaps xmm15, [rsp+0xE0]
00007154327e0ef1  add rsp, 0xF0
00007154327e0ef8  pop r11
00007154327e0efa  pop r10
00007154327e0efc  pop r9
00007154327e0efe  pop r8
00007154327e0f00  pop rsi
00007154327e0f01  pop rdi
00007154327e0f02  pop rdx
00007154327e0f03  pop rcx
00007154327e0f04  pop rax
00007154327e0f05  add rsp, 0x08
00007154327e0f09  jmp 0x00007154327DC6FC
00007154327e0f0e  sub rsp, 0x08
00007154327e0f12  push rax
00007154327e0f13  push rcx
00007154327e0f14  push rdx
00007154327e0f15  push rdi
00007154327e0f16  push rsi
00007154327e0f17  push r8
00007154327e0f19  push r9
00007154327e0f1b  push r10
00007154327e0f1d  push r11
00007154327e0f1f  sub rsp, 0xF0
00007154327e0f26  vmovaps [rsp], xmm0
00007154327e0f2b  vmovaps [rsp+0x10], xmm1
00007154327e0f31  vmovaps [rsp+0x20], xmm2
00007154327e0f37  vmovaps [rsp+0x30], xmm3
00007154327e0f3d  vmovaps [rsp+0x40], xmm4
00007154327e0f43  vmovaps [rsp+0x50], xmm5
00007154327e0f49  vmovaps [rsp+0x60], xmm6
00007154327e0f4f  vmovaps [rsp+0x70], xmm7
00007154327e0f55  vmovaps [rsp+0x80], xmm8
00007154327e0f5e  vmovaps [rsp+0x90], xmm9
00007154327e0f67  vmovaps [rsp+0xA0], xmm10
00007154327e0f70  vmovaps [rsp+0xB0], xmm11
00007154327e0f79  vmovaps [rsp+0xC0], xmm12
00007154327e0f82  vmovaps [rsp+0xD0], xmm13
00007154327e0f8b  vmovaps [rsp+0xE0], xmm15
00007154327e0f94  sub rsp, 0x30
00007154327e0f98  movaps [rsp], xmm14
00007154327e0f9d  movaps [rsp+0x10], xmm9
00007154327e0fa3  movaps [rsp+0x20], xmm1
00007154327e0fa8  lea rdi, [rsp]
00007154327e0fac  mov esi, 0x00
00007154327e0fb1  mov rax, 0x5A63B06A5530
00007154327e0fbb  call rax
00007154327e0fbd  movaps xmm14, [rsp]
00007154327e0fc2  add rsp, 0x30
00007154327e0fc6  vmovaps xmm0, [rsp]
00007154327e0fcb  vmovaps xmm1, [rsp+0x10]
00007154327e0fd1  vmovaps xmm2, [rsp+0x20]
00007154327e0fd7  vmovaps xmm3, [rsp+0x30]
00007154327e0fdd  vmovaps xmm4, [rsp+0x40]
00007154327e0fe3  vmovaps xmm5, [rsp+0x50]
00007154327e0fe9  vmovaps xmm6, [rsp+0x60]
00007154327e0fef  vmovaps xmm7, [rsp+0x70]
00007154327e0ff5  vmovaps xmm8, [rsp+0x80]
00007154327e0ffe  vmovaps xmm9, [rsp+0x90]
00007154327e1007  vmovaps xmm10, [rsp+0xA0]
00007154327e1010  vmovaps xmm11, [rsp+0xB0]
00007154327e1019  vmovaps xmm12, [rsp+0xC0]
00007154327e1022  vmovaps xmm13, [rsp+0xD0]
00007154327e102b  vmovaps xmm15, [rsp+0xE0]
00007154327e1034  add rsp, 0xF0
00007154327e103b  pop r11
00007154327e103d  pop r10
00007154327e103f  pop r9
00007154327e1041  pop r8
00007154327e1043  pop rsi
00007154327e1044  pop rdi
00007154327e1045  pop rdx
00007154327e1046  pop rcx
00007154327e1047  pop rax
00007154327e1048  add rsp, 0x08
00007154327e104c  jmp 0x00007154327DC72B
00007154327e1051  sub rsp, 0x08
00007154327e1055  push rax
00007154327e1056  push rcx
00007154327e1057  push rdx
00007154327e1058  push rdi
00007154327e1059  push rsi
00007154327e105a  push r8
00007154327e105c  push r9
00007154327e105e  push r10
00007154327e1060  push r11
00007154327e1062  sub rsp, 0xF0
00007154327e1069  vmovaps [rsp], xmm0
00007154327e106e  vmovaps [rsp+0x10], xmm2
00007154327e1074  vmovaps [rsp+0x20], xmm3
00007154327e107a  vmovaps [rsp+0x30], xmm4
00007154327e1080  vmovaps [rsp+0x40], xmm5
00007154327e1086  vmovaps [rsp+0x50], xmm6
00007154327e108c  vmovaps [rsp+0x60], xmm7
00007154327e1092  vmovaps [rsp+0x70], xmm8
00007154327e1098  vmovaps [rsp+0x80], xmm9
00007154327e10a1  vmovaps [rsp+0x90], xmm10
00007154327e10aa  vmovaps [rsp+0xA0], xmm11
00007154327e10b3  vmovaps [rsp+0xB0], xmm12
00007154327e10bc  vmovaps [rsp+0xC0], xmm13
00007154327e10c5  vmovaps [rsp+0xD0], xmm14
00007154327e10ce  vmovaps [rsp+0xE0], xmm15
00007154327e10d7  sub rsp, 0x30
00007154327e10db  movaps [rsp], xmm1
00007154327e10df  movaps [rsp+0x10], xmm13
00007154327e10e5  movaps [rsp+0x20], xmm8
00007154327e10eb  lea rdi, [rsp]
00007154327e10ef  mov esi, 0x00
00007154327e10f4  mov rax, 0x5A63B06A5530
00007154327e10fe  call rax
00007154327e1100  movaps xmm1, [rsp]
00007154327e1104  add rsp, 0x30
00007154327e1108  vmovaps xmm0, [rsp]
00007154327e110d  vmovaps xmm2, [rsp+0x10]
00007154327e1113  vmovaps xmm3, [rsp+0x20]
00007154327e1119  vmovaps xmm4, [rsp+0x30]
00007154327e111f  vmovaps xmm5, [rsp+0x40]
00007154327e1125  vmovaps xmm6, [rsp+0x50]
00007154327e112b  vmovaps xmm7, [rsp+0x60]
00007154327e1131  vmovaps xmm8, [rsp+0x70]
00007154327e1137  vmovaps xmm9, [rsp+0x80]
00007154327e1140  vmovaps xmm10, [rsp+0x90]
00007154327e1149  vmovaps xmm11, [rsp+0xA0]
00007154327e1152  vmovaps xmm12, [rsp+0xB0]
00007154327e115b  vmovaps xmm13, [rsp+0xC0]
00007154327e1164  vmovaps xmm14, [rsp+0xD0]
00007154327e116d  vmovaps xmm15, [rsp+0xE0]
00007154327e1176  add rsp, 0xF0
00007154327e117d  pop r11
00007154327e117f  pop r10
00007154327e1181  pop r9
00007154327e1183  pop r8
00007154327e1185  pop rsi
00007154327e1186  pop rdi
00007154327e1187  pop rdx
00007154327e1188  pop rcx
00007154327e1189  pop rax
00007154327e118a  add rsp, 0x08
00007154327e118e  jmp 0x00007154327DC74D
00007154327e1193  call 0x000071543260C260
00007154327e1198  jmp 0x00007154327DC75B
00007154327e119d  call 0x00007154326BD750
00007154327e11a2  jmp 0x00007154327DC765
00007154327e11a7  sub rsp, 0x08
00007154327e11ab  push rax
00007154327e11ac  push rcx
00007154327e11ad  push rdx
00007154327e11ae  push rdi
00007154327e11af  push rsi
00007154327e11b0  push r8
00007154327e11b2  push r9
00007154327e11b4  push r10
00007154327e11b6  push r11
00007154327e11b8  sub rsp, 0xF0
00007154327e11bf  vmovaps [rsp], xmm0
00007154327e11c4  vmovaps [rsp+0x10], xmm1
00007154327e11ca  vmovaps [rsp+0x20], xmm2
00007154327e11d0  vmovaps [rsp+0x30], xmm3
00007154327e11d6  vmovaps [rsp+0x40], xmm4
00007154327e11dc  vmovaps [rsp+0x50], xmm5
00007154327e11e2  vmovaps [rsp+0x60], xmm6
00007154327e11e8  vmovaps [rsp+0x70], xmm7
00007154327e11ee  vmovaps [rsp+0x80], xmm9
00007154327e11f7  vmovaps [rsp+0x90], xmm10
00007154327e1200  vmovaps [rsp+0xA0], xmm11
00007154327e1209  vmovaps [rsp+0xB0], xmm12
00007154327e1212  vmovaps [rsp+0xC0], xmm13
00007154327e121b  vmovaps [rsp+0xD0], xmm14
00007154327e1224  vmovaps [rsp+0xE0], xmm15
00007154327e122d  sub rsp, 0x30
00007154327e1231  movaps [rsp], xmm8
00007154327e1236  movaps [rsp+0x10], xmm15
00007154327e123c  movaps [rsp+0x20], xmm7
00007154327e1241  lea rdi, [rsp]
00007154327e1245  mov esi, 0x00
00007154327e124a  mov rax, 0x5A63B06A5530
00007154327e1254  call rax
00007154327e1256  movaps xmm8, [rsp]
00007154327e125b  add rsp, 0x30
00007154327e125f  vmovaps xmm0, [rsp]
00007154327e1264  vmovaps xmm1, [rsp+0x10]
00007154327e126a  vmovaps xmm2, [rsp+0x20]
00007154327e1270  vmovaps xmm3, [rsp+0x30]
00007154327e1276  vmovaps xmm4, [rsp+0x40]
00007154327e127c  vmovaps xmm5, [rsp+0x50]
00007154327e1282  vmovaps xmm6, [rsp+0x60]
00007154327e1288  vmovaps xmm7, [rsp+0x70]
00007154327e128e  vmovaps xmm9, [rsp+0x80]
00007154327e1297  vmovaps xmm10, [rsp+0x90]
00007154327e12a0  vmovaps xmm11, [rsp+0xA0]
00007154327e12a9  vmovaps xmm12, [rsp+0xB0]
00007154327e12b2  vmovaps xmm13, [rsp+0xC0]
00007154327e12bb  vmovaps xmm14, [rsp+0xD0]
00007154327e12c4  vmovaps xmm15, [rsp+0xE0]
00007154327e12cd  add rsp, 0xF0
00007154327e12d4  pop r11
00007154327e12d6  pop r10
00007154327e12d8  pop r9
00007154327e12da  pop r8
00007154327e12dc  pop rsi
00007154327e12dd  pop rdi
00007154327e12de  pop rdx
00007154327e12df  pop rcx
00007154327e12e0  pop rax
00007154327e12e1  add rsp, 0x08
00007154327e12e5  jmp 0x00007154327DC787
00007154327e12ea  sub rsp, 0x08
00007154327e12ee  push rax
00007154327e12ef  push rcx
00007154327e12f0  push rdx
00007154327e12f1  push rdi
00007154327e12f2  push rsi
00007154327e12f3  push r8
00007154327e12f5  push r9
00007154327e12f7  push r10
00007154327e12f9  push r11
00007154327e12fb  sub rsp, 0xF0
00007154327e1302  vmovaps [rsp], xmm0
00007154327e1307  vmovaps [rsp+0x10], xmm1
00007154327e130d  vmovaps [rsp+0x20], xmm2
00007154327e1313  vmovaps [rsp+0x30], xmm3
00007154327e1319  vmovaps [rsp+0x40], xmm4
00007154327e131f  vmovaps [rsp+0x50], xmm5
00007154327e1325  vmovaps [rsp+0x60], xmm6
00007154327e132b  vmovaps [rsp+0x70], xmm8
00007154327e1331  vmovaps [rsp+0x80], xmm9
00007154327e133a  vmovaps [rsp+0x90], xmm10
00007154327e1343  vmovaps [rsp+0xA0], xmm11
00007154327e134c  vmovaps [rsp+0xB0], xmm12
00007154327e1355  vmovaps [rsp+0xC0], xmm13
00007154327e135e  vmovaps [rsp+0xD0], xmm14
00007154327e1367  vmovaps [rsp+0xE0], xmm15
00007154327e1370  sub rsp, 0x30
00007154327e1374  movaps [rsp], xmm7
00007154327e1378  movaps [rsp+0x10], xmm9
00007154327e137e  movaps [rsp+0x20], xmm15
00007154327e1384  lea rdi, [rsp]
00007154327e1388  mov esi, 0x00
00007154327e138d  mov rax, 0x5A63B06A5530
00007154327e1397  call rax
00007154327e1399  movaps xmm7, [rsp]
00007154327e139d  add rsp, 0x30
00007154327e13a1  vmovaps xmm0, [rsp]
00007154327e13a6  vmovaps xmm1, [rsp+0x10]
00007154327e13ac  vmovaps xmm2, [rsp+0x20]
00007154327e13b2  vmovaps xmm3, [rsp+0x30]
00007154327e13b8  vmovaps xmm4, [rsp+0x40]
00007154327e13be  vmovaps xmm5, [rsp+0x50]
00007154327e13c4  vmovaps xmm6, [rsp+0x60]
00007154327e13ca  vmovaps xmm8, [rsp+0x70]
00007154327e13d0  vmovaps xmm9, [rsp+0x80]
00007154327e13d9  vmovaps xmm10, [rsp+0x90]
00007154327e13e2  vmovaps xmm11, [rsp+0xA0]
00007154327e13eb  vmovaps xmm12, [rsp+0xB0]
00007154327e13f4  vmovaps xmm13, [rsp+0xC0]
00007154327e13fd  vmovaps xmm14, [rsp+0xD0]
00007154327e1406  vmovaps xmm15, [rsp+0xE0]
00007154327e140f  add rsp, 0xF0
00007154327e1416  pop r11
00007154327e1418  pop r10
00007154327e141a  pop r9
00007154327e141c  pop r8
00007154327e141e  pop rsi
00007154327e141f  pop rdi
00007154327e1420  pop rdx
00007154327e1421  pop rcx
00007154327e1422  pop rax
00007154327e1423  add rsp, 0x08
00007154327e1427  jmp 0x00007154327DC7B4
00007154327e142c  sub rsp, 0x08
00007154327e1430  push rax
00007154327e1431  push rcx
00007154327e1432  push rdx
00007154327e1433  push rdi
00007154327e1434  push rsi
00007154327e1435  push r8
00007154327e1437  push r9
00007154327e1439  push r10
00007154327e143b  push r11
00007154327e143d  sub rsp, 0xF0
00007154327e1444  vmovaps [rsp], xmm0
00007154327e1449  vmovaps [rsp+0x10], xmm1
00007154327e144f  vmovaps [rsp+0x20], xmm2
00007154327e1455  vmovaps [rsp+0x30], xmm3
00007154327e145b  vmovaps [rsp+0x40], xmm4
00007154327e1461  vmovaps [rsp+0x50], xmm5
00007154327e1467  vmovaps [rsp+0x60], xmm6
00007154327e146d  vmovaps [rsp+0x70], xmm7
00007154327e1473  vmovaps [rsp+0x80], xmm8
00007154327e147c  vmovaps [rsp+0x90], xmm10
00007154327e1485  vmovaps [rsp+0xA0], xmm11
00007154327e148e  vmovaps [rsp+0xB0], xmm12
00007154327e1497  vmovaps [rsp+0xC0], xmm13
00007154327e14a0  vmovaps [rsp+0xD0], xmm14
00007154327e14a9  vmovaps [rsp+0xE0], xmm15
00007154327e14b2  sub rsp, 0x30
00007154327e14b6  movaps [rsp], xmm9
00007154327e14bb  movaps [rsp+0x10], xmm13
00007154327e14c1  movaps [rsp+0x20], xmm15
00007154327e14c7  lea rdi, [rsp]
00007154327e14cb  mov esi, 0x00
00007154327e14d0  mov rax, 0x5A63B06A5530
00007154327e14da  call rax
00007154327e14dc  movaps xmm9, [rsp]
00007154327e14e1  add rsp, 0x30
00007154327e14e5  vmovaps xmm0, [rsp]
00007154327e14ea  vmovaps xmm1, [rsp+0x10]
00007154327e14f0  vmovaps xmm2, [rsp+0x20]
00007154327e14f6  vmovaps xmm3, [rsp+0x30]
00007154327e14fc  vmovaps xmm4, [rsp+0x40]
00007154327e1502  vmovaps xmm5, [rsp+0x50]
00007154327e1508  vmovaps xmm6, [rsp+0x60]
00007154327e150e  vmovaps xmm7, [rsp+0x70]
00007154327e1514  vmovaps xmm8, [rsp+0x80]
00007154327e151d  vmovaps xmm10, [rsp+0x90]
00007154327e1526  vmovaps xmm11, [rsp+0xA0]
00007154327e152f  vmovaps xmm12, [rsp+0xB0]
00007154327e1538  vmovaps xmm13, [rsp+0xC0]
00007154327e1541  vmovaps xmm14, [rsp+0xD0]
00007154327e154a  vmovaps xmm15, [rsp+0xE0]
00007154327e1553  add rsp, 0xF0
00007154327e155a  pop r11
00007154327e155c  pop r10
00007154327e155e  pop r9
00007154327e1560  pop r8
00007154327e1562  pop rsi
00007154327e1563  pop rdi
00007154327e1564  pop rdx
00007154327e1565  pop rcx
00007154327e1566  pop rax
00007154327e1567  add rsp, 0x08
00007154327e156b  jmp 0x00007154327DC7E2
00007154327e1570  sub rsp, 0x08
00007154327e1574  push rax
00007154327e1575  push rcx
00007154327e1576  push rdx
00007154327e1577  push rdi
00007154327e1578  push rsi
00007154327e1579  push r8
00007154327e157b  push r9
00007154327e157d  push r10
00007154327e157f  push r11
00007154327e1581  sub rsp, 0xF0
00007154327e1588  vmovaps [rsp], xmm0
00007154327e158d  vmovaps [rsp+0x10], xmm1
00007154327e1593  vmovaps [rsp+0x20], xmm2
00007154327e1599  vmovaps [rsp+0x30], xmm3
00007154327e159f  vmovaps [rsp+0x40], xmm4
00007154327e15a5  vmovaps [rsp+0x50], xmm5
00007154327e15ab  vmovaps [rsp+0x60], xmm6
00007154327e15b1  vmovaps [rsp+0x70], xmm7
00007154327e15b7  vmovaps [rsp+0x80], xmm8
00007154327e15c0  vmovaps [rsp+0x90], xmm9
00007154327e15c9  vmovaps [rsp+0xA0], xmm10
00007154327e15d2  vmovaps [rsp+0xB0], xmm11
00007154327e15db  vmovaps [rsp+0xC0], xmm12
00007154327e15e4  vmovaps [rsp+0xD0], xmm13
00007154327e15ed  vmovaps [rsp+0xE0], xmm14
00007154327e15f6  sub rsp, 0x30
00007154327e15fa  movaps [rsp], xmm15
00007154327e15ff  movaps [rsp+0x10], xmm11
00007154327e1605  movaps [rsp+0x20], xmm12
00007154327e160b  lea rdi, [rsp]
00007154327e160f  mov esi, 0x00
00007154327e1614  mov rax, 0x5A63B06A5530
00007154327e161e  call rax
00007154327e1620  movaps xmm15, [rsp]
00007154327e1625  add rsp, 0x30
00007154327e1629  vmovaps xmm0, [rsp]
00007154327e162e  vmovaps xmm1, [rsp+0x10]
00007154327e1634  vmovaps xmm2, [rsp+0x20]
00007154327e163a  vmovaps xmm3, [rsp+0x30]
00007154327e1640  vmovaps xmm4, [rsp+0x40]
00007154327e1646  vmovaps xmm5, [rsp+0x50]
00007154327e164c  vmovaps xmm6, [rsp+0x60]
00007154327e1652  vmovaps xmm7, [rsp+0x70]
00007154327e1658  vmovaps xmm8, [rsp+0x80]
00007154327e1661  vmovaps xmm9, [rsp+0x90]
00007154327e166a  vmovaps xmm10, [rsp+0xA0]
00007154327e1673  vmovaps xmm11, [rsp+0xB0]
00007154327e167c  vmovaps xmm12, [rsp+0xC0]
00007154327e1685  vmovaps xmm13, [rsp+0xD0]
00007154327e168e  vmovaps xmm14, [rsp+0xE0]
00007154327e1697  add rsp, 0xF0
00007154327e169e  pop r11
00007154327e16a0  pop r10
00007154327e16a2  pop r9
00007154327e16a4  pop r8
00007154327e16a6  pop rsi
00007154327e16a7  pop rdi
00007154327e16a8  pop rdx
00007154327e16a9  pop rcx
00007154327e16aa  pop rax
00007154327e16ab  add rsp, 0x08
00007154327e16af  jmp 0x00007154327DC7FD
00007154327e16b4  sub rsp, 0x08
00007154327e16b8  push rax
00007154327e16b9  push rcx
00007154327e16ba  push rdx
00007154327e16bb  push rdi
00007154327e16bc  push rsi
00007154327e16bd  push r8
00007154327e16bf  push r9
00007154327e16c1  push r10
00007154327e16c3  push r11
00007154327e16c5  sub rsp, 0xF0
00007154327e16cc  vmovaps [rsp], xmm0
00007154327e16d1  vmovaps [rsp+0x10], xmm1
00007154327e16d7  vmovaps [rsp+0x20], xmm2
00007154327e16dd  vmovaps [rsp+0x30], xmm3
00007154327e16e3  vmovaps [rsp+0x40], xmm4
00007154327e16e9  vmovaps [rsp+0x50], xmm5
00007154327e16ef  vmovaps [rsp+0x60], xmm6
00007154327e16f5  vmovaps [rsp+0x70], xmm7
00007154327e16fb  vmovaps [rsp+0x80], xmm8
00007154327e1704  vmovaps [rsp+0x90], xmm9
00007154327e170d  vmovaps [rsp+0xA0], xmm10
00007154327e1716  vmovaps [rsp+0xB0], xmm11
00007154327e171f  vmovaps [rsp+0xC0], xmm12
00007154327e1728  vmovaps [rsp+0xD0], xmm14
00007154327e1731  vmovaps [rsp+0xE0], xmm15
00007154327e173a  sub rsp, 0x30
00007154327e173e  movaps [rsp], xmm13
00007154327e1743  movaps [rsp+0x10], xmm10
00007154327e1749  movaps [rsp+0x20], xmm14
00007154327e174f  lea rdi, [rsp]
00007154327e1753  mov esi, 0x00
00007154327e1758  mov rax, 0x5A63B06A5530
00007154327e1762  call rax
00007154327e1764  movaps xmm13, [rsp]
00007154327e1769  add rsp, 0x30
00007154327e176d  vmovaps xmm0, [rsp]
00007154327e1772  vmovaps xmm1, [rsp+0x10]
00007154327e1778  vmovaps xmm2, [rsp+0x20]
00007154327e177e  vmovaps xmm3, [rsp+0x30]
00007154327e1784  vmovaps xmm4, [rsp+0x40]
00007154327e178a  vmovaps xmm5, [rsp+0x50]
00007154327e1790  vmovaps xmm6, [rsp+0x60]
00007154327e1796  vmovaps xmm7, [rsp+0x70]
00007154327e179c  vmovaps xmm8, [rsp+0x80]
00007154327e17a5  vmovaps xmm9, [rsp+0x90]
00007154327e17ae  vmovaps xmm10, [rsp+0xA0]
00007154327e17b7  vmovaps xmm11, [rsp+0xB0]
00007154327e17c0  vmovaps xmm12, [rsp+0xC0]
00007154327e17c9  vmovaps xmm14, [rsp+0xD0]
00007154327e17d2  vmovaps xmm15, [rsp+0xE0]
00007154327e17db  add rsp, 0xF0
00007154327e17e2  pop r11
00007154327e17e4  pop r10
00007154327e17e6  pop r9
00007154327e17e8  pop r8
00007154327e17ea  pop rsi
00007154327e17eb  pop rdi
00007154327e17ec  pop rdx
00007154327e17ed  pop rcx
00007154327e17ee  pop rax
00007154327e17ef  add rsp, 0x08
00007154327e17f3  jmp 0x00007154327DC820
00007154327e17f8  sub rsp, 0x08
00007154327e17fc  push rax
00007154327e17fd  push rcx
00007154327e17fe  push rdx
00007154327e17ff  push rdi
00007154327e1800  push rsi
00007154327e1801  push r8
00007154327e1803  push r9
00007154327e1805  push r10
00007154327e1807  push r11
00007154327e1809  sub rsp, 0xF0
00007154327e1810  vmovaps [rsp], xmm0
00007154327e1815  vmovaps [rsp+0x10], xmm1
00007154327e181b  vmovaps [rsp+0x20], xmm2
00007154327e1821  vmovaps [rsp+0x30], xmm3
00007154327e1827  vmovaps [rsp+0x40], xmm4
00007154327e182d  vmovaps [rsp+0x50], xmm5
00007154327e1833  vmovaps [rsp+0x60], xmm6
00007154327e1839  vmovaps [rsp+0x70], xmm7
00007154327e183f  vmovaps [rsp+0x80], xmm8
00007154327e1848  vmovaps [rsp+0x90], xmm9
00007154327e1851  vmovaps [rsp+0xA0], xmm10
00007154327e185a  vmovaps [rsp+0xB0], xmm11
00007154327e1863  vmovaps [rsp+0xC0], xmm12
00007154327e186c  vmovaps [rsp+0xD0], xmm13
00007154327e1875  vmovaps [rsp+0xE0], xmm15
00007154327e187e  sub rsp, 0x30
00007154327e1882  movaps [rsp], xmm14
00007154327e1887  movaps [rsp+0x10], xmm1
00007154327e188c  movaps [rsp+0x20], xmm7
00007154327e1891  lea rdi, [rsp]
00007154327e1895  mov esi, 0x00
00007154327e189a  mov rax, 0x5A63B06A5530
00007154327e18a4  call rax
00007154327e18a6  movaps xmm14, [rsp]
00007154327e18ab  add rsp, 0x30
00007154327e18af  vmovaps xmm0, [rsp]
00007154327e18b4  vmovaps xmm1, [rsp+0x10]
00007154327e18ba  vmovaps xmm2, [rsp+0x20]
00007154327e18c0  vmovaps xmm3, [rsp+0x30]
00007154327e18c6  vmovaps xmm4, [rsp+0x40]
00007154327e18cc  vmovaps xmm5, [rsp+0x50]
00007154327e18d2  vmovaps xmm6, [rsp+0x60]
00007154327e18d8  vmovaps xmm7, [rsp+0x70]
00007154327e18de  vmovaps xmm8, [rsp+0x80]
00007154327e18e7  vmovaps xmm9, [rsp+0x90]
00007154327e18f0  vmovaps xmm10, [rsp+0xA0]
00007154327e18f9  vmovaps xmm11, [rsp+0xB0]
00007154327e1902  vmovaps xmm12, [rsp+0xC0]
00007154327e190b  vmovaps xmm13, [rsp+0xD0]
00007154327e1914  vmovaps xmm15, [rsp+0xE0]
00007154327e191d  add rsp, 0xF0
00007154327e1924  pop r11
00007154327e1926  pop r10
00007154327e1928  pop r9
00007154327e192a  pop r8
00007154327e192c  pop rsi
00007154327e192d  pop rdi
00007154327e192e  pop rdx
00007154327e192f  pop rcx
00007154327e1930  pop rax
00007154327e1931  add rsp, 0x08
00007154327e1935  jmp 0x00007154327DC843
00007154327e193a  sub rsp, 0x08
00007154327e193e  push rax
00007154327e193f  push rcx
00007154327e1940  push rdx
00007154327e1941  push rdi
00007154327e1942  push rsi
00007154327e1943  push r8
00007154327e1945  push r9
00007154327e1947  push r10
00007154327e1949  push r11
00007154327e194b  sub rsp, 0xF0
00007154327e1952  vmovaps [rsp], xmm0
00007154327e1957  vmovaps [rsp+0x10], xmm2
00007154327e195d  vmovaps [rsp+0x20], xmm3
00007154327e1963  vmovaps [rsp+0x30], xmm4
00007154327e1969  vmovaps [rsp+0x40], xmm5
00007154327e196f  vmovaps [rsp+0x50], xmm6
00007154327e1975  vmovaps [rsp+0x60], xmm7
00007154327e197b  vmovaps [rsp+0x70], xmm8
00007154327e1981  vmovaps [rsp+0x80], xmm9
00007154327e198a  vmovaps [rsp+0x90], xmm10
00007154327e1993  vmovaps [rsp+0xA0], xmm11
00007154327e199c  vmovaps [rsp+0xB0], xmm12
00007154327e19a5  vmovaps [rsp+0xC0], xmm13
00007154327e19ae  vmovaps [rsp+0xD0], xmm14
00007154327e19b7  vmovaps [rsp+0xE0], xmm15
00007154327e19c0  sub rsp, 0x30
00007154327e19c4  movaps [rsp], xmm1
00007154327e19c8  movaps [rsp+0x10], xmm8
00007154327e19ce  movaps [rsp+0x20], xmm9
00007154327e19d4  lea rdi, [rsp]
00007154327e19d8  mov esi, 0x00
00007154327e19dd  mov rax, 0x5A63B06A5530
00007154327e19e7  call rax
00007154327e19e9  movaps xmm1, [rsp]
00007154327e19ed  add rsp, 0x30
00007154327e19f1  vmovaps xmm0, [rsp]
00007154327e19f6  vmovaps xmm2, [rsp+0x10]
00007154327e19fc  vmovaps xmm3, [rsp+0x20]
00007154327e1a02  vmovaps xmm4, [rsp+0x30]
00007154327e1a08  vmovaps xmm5, [rsp+0x40]
00007154327e1a0e  vmovaps xmm6, [rsp+0x50]
00007154327e1a14  vmovaps xmm7, [rsp+0x60]
00007154327e1a1a  vmovaps xmm8, [rsp+0x70]
00007154327e1a20  vmovaps xmm9, [rsp+0x80]
00007154327e1a29  vmovaps xmm10, [rsp+0x90]
00007154327e1a32  vmovaps xmm11, [rsp+0xA0]
00007154327e1a3b  vmovaps xmm12, [rsp+0xB0]
00007154327e1a44  vmovaps xmm13, [rsp+0xC0]
00007154327e1a4d  vmovaps xmm14, [rsp+0xD0]
00007154327e1a56  vmovaps xmm15, [rsp+0xE0]
00007154327e1a5f  add rsp, 0xF0
00007154327e1a66  pop r11
00007154327e1a68  pop r10
00007154327e1a6a  pop r9
00007154327e1a6c  pop r8
00007154327e1a6e  pop rsi
00007154327e1a6f  pop rdi
00007154327e1a70  pop rdx
00007154327e1a71  pop rcx
00007154327e1a72  pop rax
00007154327e1a73  add rsp, 0x08
00007154327e1a77  jmp 0x00007154327DC865
00007154327e1a7c  call 0x00007154326E5940
00007154327e1a81  jmp 0x00007154327DC873
00007154327e1a86  call 0x000071543260C380
00007154327e1a8b  jmp 0x00007154327DC87D
00007154327e1a90  call 0x000071543260D600
00007154327e1a95  jmp 0x00007154327DC887
00007154327e1a9a  call 0x00007154325FF540
00007154327e1a9f  jmp 0x00007154327DC891
00007154327e1aa4  int3
00007154327e1aa5  nop [rax+rax*1], ax
00007154327e1aae  nop
00007154327e1ab0  mov rax, [r15+0xF8]
00007154327e1ab7  lea r14, [rax+0x140]
00007154327e1abe  mov r12, [r13+r14*1]
00007154327e1ac3  mov [r15+0xE8], r12
00007154327e1aca  lea r14, [rax+0x130]
00007154327e1ad1  mov r12, [r13+r14*1]
00007154327e1ad6  lea r14, [rax+0x138]
00007154327e1add  mov r11, [r13+r14*1]
00007154327e1ae2  movq xmm1, r12
00007154327e1ae7  movq xmm15, r11
00007154327e1aec  movq xmm1, xmm1
00007154327e1af0  movq xmm1, xmm1
00007154327e1af4  movaps [r15+0x1A0], xmm1
00007154327e1afc  movq xmm15, xmm15
00007154327e1b01  movq xmm15, xmm15
00007154327e1b06  movaps [r15+0x190], xmm15
00007154327e1b0e  lea r14, [rax+0x120]
00007154327e1b15  mov r12, [r13+r14*1]
00007154327e1b1a  lea r14, [rax+0x128]
00007154327e1b21  mov r11, [r13+r14*1]
00007154327e1b26  movq xmm1, r12
00007154327e1b2b  movq xmm15, r11
00007154327e1b30  movq xmm1, xmm1
00007154327e1b34  movq xmm1, xmm1
00007154327e1b38  movaps [r15+0x1C0], xmm1
00007154327e1b40  movq xmm15, xmm15
00007154327e1b45  movq xmm15, xmm15
00007154327e1b4a  movaps [r15+0x1B0], xmm15
00007154327e1b52  lea r14, [rax+0x110]
00007154327e1b59  mov r12, [r13+r14*1]
00007154327e1b5e  lea r14, [rax+0x118]
00007154327e1b65  mov r11, [r13+r14*1]
00007154327e1b6a  movq xmm1, r12
00007154327e1b6f  movq xmm15, r11
00007154327e1b74  movq xmm1, xmm1
00007154327e1b78  movq xmm1, xmm1
00007154327e1b7c  movaps [r15+0x1E0], xmm1
00007154327e1b84  movq xmm15, xmm15
00007154327e1b89  movq xmm15, xmm15
00007154327e1b8e  movaps [r15+0x1D0], xmm15
00007154327e1b96  lea r14, [rax+0x100]
00007154327e1b9d  mov r12, [r13+r14*1]
00007154327e1ba2  lea r14, [rax+0x108]
00007154327e1ba9  mov r11, [r13+r14*1]
00007154327e1bae  movq xmm1, r12
00007154327e1bb3  movq xmm15, r11
00007154327e1bb8  movq xmm1, xmm1
00007154327e1bbc  movq xmm1, xmm1
00007154327e1bc0  movaps [r15+0x200], xmm1
00007154327e1bc8  movq xmm15, xmm15
00007154327e1bcd  movq xmm15, xmm15
00007154327e1bd2  movaps [r15+0x1F0], xmm15
00007154327e1bda  mov qword ptr [r15+0x40], 0x430000
00007154327e1be2  mov r14d, 0x430510
00007154327e1be8  mov r12, [r13+r14*1]
00007154327e1bed  movq xmm1, r12
00007154327e1bf2  lea r14, [rax+0x150]
00007154327e1bf9  mov [r15+0xF8], r14
00007154327e1c00  mov rax, [r15+0x50]
00007154327e1c04  movups xmm15, [r13+rax*1]
00007154327e1c0a  movaps [r15+0x120], xmm15
00007154327e1c12  mov qword ptr [r15+0x48], 0x10
00007154327e1c1a  xor eax, eax
00007154327e1c1c  mov r14d, 0x10
00007154327e1c22  mov r12d, 0x200
00007154327e1c28  cmp r14, r12
00007154327e1c2b  cmc
00007154327e1c2c  lahf
00007154327e1c2d  seto al
00007154327e1c30  mov [r15+0x108], eax
00007154327e1c37  pextrq rax, xmm15, 0x01
00007154327e1c3e  movq xmm14, rax
00007154327e1c43  movaps [r15+0x130], xmm14
00007154327e1c4b  movq rax, xmm1
00007154327e1c50  movq r14, xmm15
00007154327e1c55  vmovq xmm1, rax
00007154327e1c5a  vmovq xmm15, r14
00007154327e1c5f  movaps xmm13, xmm1
00007154327e1c63  addsd xmm13, xmm15
00007154327e1c68  ucomisd xmm13, xmm13
00007154327e1c6d  jp 0x00007154327E1D86
00007154327e1c73  movq xmm13, xmm13
00007154327e1c78  movq rax, xmm13
00007154327e1c7d  movq r14, xmm14
00007154327e1c82  vmovq xmm1, rax
00007154327e1c87  vmovq xmm15, r14
00007154327e1c8c  movaps xmm14, xmm1
00007154327e1c90  addsd xmm14, xmm15
00007154327e1c95  ucomisd xmm14, xmm14
00007154327e1c9a  jp 0x00007154327E1DCE
00007154327e1ca0  movq xmm14, xmm14
00007154327e1ca5  movaps [r15+0x110], xmm14
00007154327e1cad  mov eax, [r15+0x108]
00007154327e1cb4  sahf
00007154327e1cb5  jnz 0x00007154327E1CE7
00007154327e1cb7  cmp dword ptr [r15+0x318], 0x00
00007154327e1cbf  jz 0x00007154327E1FE0
00007154327e1cc5  nop [rax+rax*1], ax
00007154327e1cce  nop [rax+rax*1], eax
00007154327e1cd6  mov eax, 0x410490
00007154327e1cdb  mov [r15+0x100], rax
00007154327e1ce2  jmp 0x00007154325FE110
00007154327e1ce7  cmp dword ptr [r15+0x318], 0x00
00007154327e1cef  jz 0x00007154327E1E20
00007154327e1cf5  nop [rax+rax*1], ax
00007154327e1cfe  nop [rax+rax*1], eax
00007154327e1d06  mov eax, 0x410474
00007154327e1d0b  mov [r15+0x100], rax
00007154327e1d12  jmp 0x00007154325FE110
00007154327e1d17  int3
00007154327e1d18  call 0x00007154326E27E0
00007154327e1d1d  jmp 0x00007154327E1AC3
00007154327e1d22  call 0x00007154326E27E0
00007154327e1d27  jmp 0x00007154327E1AD6
00007154327e1d2c  call 0x00007154326E1570
00007154327e1d31  jmp 0x00007154327E1AE2
00007154327e1d36  call 0x00007154326E27E0
00007154327e1d3b  jmp 0x00007154327E1B1A
00007154327e1d40  call 0x00007154326E1570
00007154327e1d45  jmp 0x00007154327E1B26
00007154327e1d4a  call 0x00007154326E27E0
00007154327e1d4f  jmp 0x00007154327E1B5E
00007154327e1d54  call 0x00007154326E1570
00007154327e1d59  jmp 0x00007154327E1B6A
00007154327e1d5e  call 0x00007154326E27E0
00007154327e1d63  jmp 0x00007154327E1BA2
00007154327e1d68  call 0x00007154326E1570
00007154327e1d6d  jmp 0x00007154327E1BAE
00007154327e1d72  call 0x00007154326E27E0
00007154327e1d77  jmp 0x00007154327E1BED
00007154327e1d7c  call 0x000071543260E760
00007154327e1d81  jmp 0x00007154327E1C0A
00007154327e1d86  ucomisd xmm1, xmm15
00007154327e1d8b  jp 0x00007154327E1D9A
00007154327e1d8d  movaps xmm13, [0x00007154323FE060]
00007154327e1d95  jmp 0x00007154327E1C73
00007154327e1d9a  vxorps xmm0, xmm1, xmm15
00007154327e1d9f  pextrw eax, xmm0, 0x03
00007154327e1da4  and eax, 0x7FF8
00007154327e1da9  cmp eax, 0x08
00007154327e1dac  jnz 0x00007154327E1C73
00007154327e1db2  movq rax, xmm15
00007154327e1db7  shl rax, 0x0D
00007154327e1dbb  jbe 0x00007154327E1C73
00007154327e1dc1  vorps xmm13, xmm15, [0x00007154323FE070]
00007154327e1dc9  jmp 0x00007154327E1C73
00007154327e1dce  ucomisd xmm1, xmm15
00007154327e1dd3  jp 0x00007154327E1DE2
00007154327e1dd5  movaps xmm14, [0x00007154323FE060]
00007154327e1ddd  jmp 0x00007154327E1CA0
00007154327e1de2  vxorps xmm0, xmm1, xmm15
00007154327e1de7  pextrw eax, xmm0, 0x03
00007154327e1dec  and eax, 0x7FF8
00007154327e1df1  cmp eax, 0x08
00007154327e1df4  jnz 0x00007154327E1CA0
00007154327e1dfa  movq rax, xmm15
00007154327e1dff  shl rax, 0x0D
00007154327e1e03  jbe 0x00007154327E1CA0
00007154327e1e09  vorps xmm14, xmm15, [0x00007154323FE070]
00007154327e1e11  jmp 0x00007154327E1CA0
00007154327e1e16  int3
00007154327e1e17  nop [rax+rax*1], ax
00007154327e1e20  mov rax, [r15+0x48]
00007154327e1e24  mov r14, [r15+0x50]
00007154327e1e28  lea r12, [r14+rax*1]
00007154327e1e2c  movups xmm1, [r13+r12*1]
00007154327e1e32  movaps [r15+0x120], xmm1
00007154327e1e3a  lea r14, [rax+0x10]
00007154327e1e3e  mov [r15+0x48], r14
00007154327e1e42  xor eax, eax
00007154327e1e44  mov r12d, 0x200
00007154327e1e4a  cmp r14, r12
00007154327e1e4d  cmc
00007154327e1e4e  lahf
00007154327e1e4f  seto al
00007154327e1e52  mov [r15+0x108], eax
00007154327e1e59  pextrq rax, xmm1, 0x01
00007154327e1e60  movq xmm15, rax
00007154327e1e65  movaps [r15+0x130], xmm15
00007154327e1e6d  movaps xmm14, [r15+0x110]
00007154327e1e75  movq rax, xmm14
00007154327e1e7a  movq r14, xmm1
00007154327e1e7f  vmovq xmm1, rax
00007154327e1e84  vmovq xmm14, r14
00007154327e1e89  movaps xmm13, xmm1
00007154327e1e8d  addsd xmm13, xmm14
00007154327e1e92  ucomisd xmm13, xmm13
00007154327e1e97  jp 0x00007154327E1F4C
00007154327e1e9d  movq xmm13, xmm13
00007154327e1ea2  movq rax, xmm13
00007154327e1ea7  movq r14, xmm15
00007154327e1eac  vmovq xmm1, rax
00007154327e1eb1  vmovq xmm15, r14
00007154327e1eb6  movaps xmm14, xmm1
00007154327e1eba  addsd xmm14, xmm15
00007154327e1ebf  ucomisd xmm14, xmm14
00007154327e1ec4  jp 0x00007154327E1F94
00007154327e1eca  movq xmm14, xmm14
00007154327e1ecf  movaps [r15+0x110], xmm14
00007154327e1ed7  mov eax, [r15+0x108]
00007154327e1ede  sahf
00007154327e1edf  jnz 0x00007154327E1F11
00007154327e1ee1  cmp dword ptr [r15+0x318], 0x00
00007154327e1ee9  jz 0x00007154327E1FE0
00007154327e1eef  nop [rax+rax*1], ax
00007154327e1ef8  nop [rax+rax*1], eax
00007154327e1f00  mov eax, 0x410490
00007154327e1f05  mov [r15+0x100], rax
00007154327e1f0c  jmp 0x00007154325FE110
00007154327e1f11  cmp dword ptr [r15+0x318], 0x00
00007154327e1f19  jz 0x00007154327E1E20
00007154327e1f1f  nop [rax+rax*1], ax
00007154327e1f28  nop [rax+rax*1], eax
00007154327e1f30  mov eax, 0x410474
00007154327e1f35  mov [r15+0x100], rax
00007154327e1f3c  jmp 0x00007154325FE110
00007154327e1f41  int3
00007154327e1f42  call 0x00007154326B52F0
00007154327e1f47  jmp 0x00007154327E1E32
00007154327e1f4c  ucomisd xmm1, xmm14
00007154327e1f51  jp 0x00007154327E1F60
00007154327e1f53  movaps xmm13, [0x00007154323FE060]
00007154327e1f5b  jmp 0x00007154327E1E9D
00007154327e1f60  vxorps xmm0, xmm1, xmm14
00007154327e1f65  pextrw eax, xmm0, 0x03
00007154327e1f6a  and eax, 0x7FF8
00007154327e1f6f  cmp eax, 0x08
00007154327e1f72  jnz 0x00007154327E1E9D
00007154327e1f78  movq rax, xmm14
00007154327e1f7d  shl rax, 0x0D
00007154327e1f81  jbe 0x00007154327E1E9D
00007154327e1f87  vorps xmm13, xmm14, [0x00007154323FE070]
00007154327e1f8f  jmp 0x00007154327E1E9D
00007154327e1f94  ucomisd xmm1, xmm15
00007154327e1f99  jp 0x00007154327E1FA8
00007154327e1f9b  movaps xmm14, [0x00007154323FE060]
00007154327e1fa3  jmp 0x00007154327E1ECA
00007154327e1fa8  vxorps xmm0, xmm1, xmm15
00007154327e1fad  pextrw eax, xmm0, 0x03
00007154327e1fb2  and eax, 0x7FF8
00007154327e1fb7  cmp eax, 0x08
00007154327e1fba  jnz 0x00007154327E1ECA
00007154327e1fc0  movq rax, xmm15
00007154327e1fc5  shl rax, 0x0D
00007154327e1fc9  jbe 0x00007154327E1ECA
00007154327e1fcf  vorps xmm14, xmm15, [0x00007154323FE070]
00007154327e1fd7  jmp 0x00007154327E1ECA
00007154327e1fdc  int3
00007154327e1fdd  nop [rax], eax
00007154327e1fe0  mov rax, [r15+0x40]
00007154327e1fe4  lea r14, [rax+0x510]
00007154327e1feb  movaps xmm1, [r15+0x110]
00007154327e1ff3  movq rax, xmm1
00007154327e1ff8  mov [r13+r14*1], rax
00007154327e1ffd  mov rax, [r15+0xF0]
00007154327e2004  mov [r15+0x100], rax
00007154327e200b  jmp 0x00007154327CE5C0
00007154327e2010  int3
00007154327e2011  call 0x00007154326D5EB0
00007154327e2016  jmp 0x00007154327E1FFD
00007154327e201b  int3
00007154327e201c  nop [rax], eax
00007154327e2020  mov qword ptr [r15+0x100], 0x04
00007154327e202b  mov esi, 0x00
00007154327e2030  mov edx, 0x09
00007154327e2035  mov rdi, 0x7FFD9BEF3750
00007154327e203f  mov rax, 0x5A63B0538970
00007154327e2049  call rax
00007154327e204b  cmp dword ptr [r15+0x318], 0x00
00007154327e2053  jnz 0x00007154325FE110
00007154327e2059  jmp 0x00007154325FE0A0
00007154327e205e  int3
00007154327e205f  int3
