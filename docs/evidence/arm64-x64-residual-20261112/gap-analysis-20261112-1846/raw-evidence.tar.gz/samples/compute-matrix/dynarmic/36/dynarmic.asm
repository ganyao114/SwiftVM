0000707b885ce69b  nop [rax+rax*1], eax
0000707b885ce6a0  vmovaps xmm1, [0x0000707B881FE010]
0000707b885ce6a8  movq xmm1, xmm1
0000707b885ce6ac  movaps [r15+0x110], xmm1
0000707b885ce6b4  vmovaps xmm1, [0x0000707B881FE020]
0000707b885ce6bc  movq xmm1, xmm1
0000707b885ce6c0  movaps [r15+0x120], xmm1
0000707b885ce6c8  mov eax, 0x4204C0
0000707b885ce6cd  mov r14, [r13+rax*1]
0000707b885ce6d2  movq xmm1, r14
0000707b885ce6d7  movaps [r15+0x130], xmm1
0000707b885ce6df  vmovaps xmm1, [0x0000707B881FE030]
0000707b885ce6e7  vpbroadcastq xmm1, xmm1
0000707b885ce6ec  movaps [r15+0x140], xmm1
0000707b885ce6f4  mov qword ptr [r15+0x40], 0x02
0000707b885ce6fc  vmovaps xmm15, [0x0000707B881FE040]
0000707b885ce704  movq xmm15, xmm15
0000707b885ce709  movaps [r15+0x150], xmm15
0000707b885ce711  mov qword ptr [r15+0x58], 0x420000
0000707b885ce719  vmovaps xmm15, [0x0000707B881FE050]
0000707b885ce721  vpbroadcastq xmm15, xmm15
0000707b885ce726  movaps [r15+0x160], xmm15
0000707b885ce72e  mov rax, [r15+0x40]
0000707b885ce732  vmovq xmm14, rax
0000707b885ce737  vpbroadcastq xmm14, xmm14
0000707b885ce73c  movaps [r15+0x170], xmm14
0000707b885ce744  mov eax, 0x4204D0
0000707b885ce749  movups xmm13, [r13+rax*1]
0000707b885ce74f  mov qword ptr [r15+0x40], 0x430518
0000707b885ce757  mov qword ptr [r15+0x50], 0x430720
0000707b885ce75f  vpmovqd xmm12, xmm13
0000707b885ce765  pxor xmm11, xmm11
0000707b885ce76a  punpcklqdq xmm12, xmm11
0000707b885ce76f  movaps [r15+0x210], xmm12
0000707b885ce777  movq xmm12, qword ptr [r15+0x120]
0000707b885ce780  movq xmm11, qword ptr [r15+0x130]
0000707b885ce789  psubd xmm12, xmm11
0000707b885ce78e  movq xmm12, xmm12
0000707b885ce793  paddq xmm13, xmm14
0000707b885ce798  movaps [r15+0x180], xmm13
0000707b885ce7a0  movq xmm14, qword ptr [r15+0x150]
0000707b885ce7a9  paddd xmm11, xmm14
0000707b885ce7ae  movq xmm11, xmm11
0000707b885ce7b3  movq xmm11, xmm11
0000707b885ce7b8  movaps [r15+0x130], xmm11
0000707b885ce7c0  pmovzxdq xmm12, xmm12
0000707b885ce7c6  psllq xmm12, 0x00
0000707b885ce7cc  movq xmm14, qword ptr [r15+0x210]
0000707b885ce7d5  movq xmm13, qword ptr [r15+0x110]
0000707b885ce7de  paddd xmm14, xmm13
0000707b885ce7e3  movq xmm14, xmm14
0000707b885ce7e8  vcvtuqq2pd xmm12, xmm12
0000707b885ce7ee  pmovzxdq xmm14, xmm14
0000707b885ce7f4  psllq xmm14, 0x00
0000707b885ce7fa  vcvtuqq2pd xmm14, xmm14
0000707b885ce800  movaps xmm13, xmm12
0000707b885ce804  mulpd xmm13, xmm1
0000707b885ce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000707b885ce80f  ptest xmm11, xmm11
0000707b885ce815  jnz 0x0000707B885CE8FF
0000707b885ce81b  movaps [r15+0x220], xmm13
0000707b885ce823  mov eax, 0x430720
0000707b885ce828  movups [r13+rax*1], xmm13
0000707b885ce82e  movaps xmm1, xmm14
0000707b885ce832  mulpd xmm1, xmm15
0000707b885ce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000707b885ce83c  ptest xmm13, xmm13
0000707b885ce842  jnz 0x0000707B885CEA4C
0000707b885ce848  movaps [r15+0x210], xmm1
0000707b885ce850  mov eax, 0x430518
0000707b885ce855  movups [r13+rax*1], xmm1
0000707b885ce85b  mov qword ptr [r15+0x48], 0x10
0000707b885ce863  xor eax, eax
0000707b885ce865  mov r14d, 0x10
0000707b885ce86b  mov r12d, 0x200
0000707b885ce871  cmp r14, r12
0000707b885ce874  cmc
0000707b885ce875  lahf
0000707b885ce876  seto al
0000707b885ce879  mov [r15+0x108], eax
0000707b885ce880  mov eax, [r15+0x108]
0000707b885ce887  sahf
0000707b885ce888  jnz 0x0000707B885CE8BA
0000707b885ce88a  cmp dword ptr [r15+0x318], 0x00
0000707b885ce892  jz 0x0000707B885CEFF0
0000707b885ce898  nop [rax+rax*1], ax
0000707b885ce8a1  nop [rax+rax*1], eax
0000707b885ce8a9  mov eax, 0x4101EC
0000707b885ce8ae  mov [r15+0x100], rax
0000707b885ce8b5  jmp 0x0000707B883FE110
0000707b885ce8ba  cmp dword ptr [r15+0x318], 0x00
0000707b885ce8c2  jz 0x0000707B885CEBA0
0000707b885ce8c8  nop [rax+rax*1], ax
0000707b885ce8d1  nop [rax+rax*1], eax
0000707b885ce8d9  mov eax, 0x4101AC
0000707b885ce8de  mov [r15+0x100], rax
0000707b885ce8e5  jmp 0x0000707B883FE110
0000707b885ce8ea  int3
0000707b885ce8eb  call 0x0000707B8840DC20
0000707b885ce8f0  jmp 0x0000707B885CE6D2
0000707b885ce8f5  call 0x0000707B8840C260
0000707b885ce8fa  jmp 0x0000707B885CE74F
0000707b885ce8ff  sub rsp, 0x08
0000707b885ce903  push rax
0000707b885ce904  push rcx
0000707b885ce905  push rdx
0000707b885ce906  push rdi
0000707b885ce907  push rsi
0000707b885ce908  push r8
0000707b885ce90a  push r9
0000707b885ce90c  push r10
0000707b885ce90e  push r11
0000707b885ce910  sub rsp, 0xF0
0000707b885ce917  vmovaps [rsp], xmm0
0000707b885ce91c  vmovaps [rsp+0x10], xmm1
0000707b885ce922  vmovaps [rsp+0x20], xmm2
0000707b885ce928  vmovaps [rsp+0x30], xmm3
0000707b885ce92e  vmovaps [rsp+0x40], xmm4
0000707b885ce934  vmovaps [rsp+0x50], xmm5
0000707b885ce93a  vmovaps [rsp+0x60], xmm6
0000707b885ce940  vmovaps [rsp+0x70], xmm7
0000707b885ce946  vmovaps [rsp+0x80], xmm8
0000707b885ce94f  vmovaps [rsp+0x90], xmm9
0000707b885ce958  vmovaps [rsp+0xA0], xmm10
0000707b885ce961  vmovaps [rsp+0xB0], xmm11
0000707b885ce96a  vmovaps [rsp+0xC0], xmm12
0000707b885ce973  vmovaps [rsp+0xD0], xmm14
0000707b885ce97c  vmovaps [rsp+0xE0], xmm15
0000707b885ce985  sub rsp, 0x30
0000707b885ce989  movaps [rsp], xmm13
0000707b885ce98e  movaps [rsp+0x10], xmm12
0000707b885ce994  movaps [rsp+0x20], xmm1
0000707b885ce999  lea rdi, [rsp]
0000707b885ce99d  mov esi, 0x00
0000707b885ce9a2  mov rax, 0x6471B35AC530
0000707b885ce9ac  call rax
0000707b885ce9ae  movaps xmm13, [rsp]
0000707b885ce9b3  add rsp, 0x30
0000707b885ce9b7  vmovaps xmm0, [rsp]
0000707b885ce9bc  vmovaps xmm1, [rsp+0x10]
0000707b885ce9c2  vmovaps xmm2, [rsp+0x20]
0000707b885ce9c8  vmovaps xmm3, [rsp+0x30]
0000707b885ce9ce  vmovaps xmm4, [rsp+0x40]
0000707b885ce9d4  vmovaps xmm5, [rsp+0x50]
0000707b885ce9da  vmovaps xmm6, [rsp+0x60]
0000707b885ce9e0  vmovaps xmm7, [rsp+0x70]
0000707b885ce9e6  vmovaps xmm8, [rsp+0x80]
0000707b885ce9ef  vmovaps xmm9, [rsp+0x90]
0000707b885ce9f8  vmovaps xmm10, [rsp+0xA0]
0000707b885cea01  vmovaps xmm11, [rsp+0xB0]
0000707b885cea0a  vmovaps xmm12, [rsp+0xC0]
0000707b885cea13  vmovaps xmm14, [rsp+0xD0]
0000707b885cea1c  vmovaps xmm15, [rsp+0xE0]
0000707b885cea25  add rsp, 0xF0
0000707b885cea2c  pop r11
0000707b885cea2e  pop r10
0000707b885cea30  pop r9
0000707b885cea32  pop r8
0000707b885cea34  pop rsi
0000707b885cea35  pop rdi
0000707b885cea36  pop rdx
0000707b885cea37  pop rcx
0000707b885cea38  pop rax
0000707b885cea39  add rsp, 0x08
0000707b885cea3d  jmp 0x0000707B885CE81B
0000707b885cea42  call 0x0000707B8840C380
0000707b885cea47  jmp 0x0000707B885CE82E
0000707b885cea4c  sub rsp, 0x08
0000707b885cea50  push rax
0000707b885cea51  push rcx
0000707b885cea52  push rdx
0000707b885cea53  push rdi
0000707b885cea54  push rsi
0000707b885cea55  push r8
0000707b885cea57  push r9
0000707b885cea59  push r10
0000707b885cea5b  push r11
0000707b885cea5d  sub rsp, 0xF0
0000707b885cea64  vmovaps [rsp], xmm0
0000707b885cea69  vmovaps [rsp+0x10], xmm2
0000707b885cea6f  vmovaps [rsp+0x20], xmm3
0000707b885cea75  vmovaps [rsp+0x30], xmm4
0000707b885cea7b  vmovaps [rsp+0x40], xmm5
0000707b885cea81  vmovaps [rsp+0x50], xmm6
0000707b885cea87  vmovaps [rsp+0x60], xmm7
0000707b885cea8d  vmovaps [rsp+0x70], xmm8
0000707b885cea93  vmovaps [rsp+0x80], xmm9
0000707b885cea9c  vmovaps [rsp+0x90], xmm10
0000707b885ceaa5  vmovaps [rsp+0xA0], xmm11
0000707b885ceaae  vmovaps [rsp+0xB0], xmm12
0000707b885ceab7  vmovaps [rsp+0xC0], xmm13
0000707b885ceac0  vmovaps [rsp+0xD0], xmm14
0000707b885ceac9  vmovaps [rsp+0xE0], xmm15
0000707b885cead2  sub rsp, 0x30
0000707b885cead6  movaps [rsp], xmm1
0000707b885ceada  movaps [rsp+0x10], xmm14
0000707b885ceae0  movaps [rsp+0x20], xmm15
0000707b885ceae6  lea rdi, [rsp]
0000707b885ceaea  mov esi, 0x00
0000707b885ceaef  mov rax, 0x6471B35AC530
0000707b885ceaf9  call rax
0000707b885ceafb  movaps xmm1, [rsp]
0000707b885ceaff  add rsp, 0x30
0000707b885ceb03  vmovaps xmm0, [rsp]
0000707b885ceb08  vmovaps xmm2, [rsp+0x10]
0000707b885ceb0e  vmovaps xmm3, [rsp+0x20]
0000707b885ceb14  vmovaps xmm4, [rsp+0x30]
0000707b885ceb1a  vmovaps xmm5, [rsp+0x40]
0000707b885ceb20  vmovaps xmm6, [rsp+0x50]
0000707b885ceb26  vmovaps xmm7, [rsp+0x60]
0000707b885ceb2c  vmovaps xmm8, [rsp+0x70]
0000707b885ceb32  vmovaps xmm9, [rsp+0x80]
0000707b885ceb3b  vmovaps xmm10, [rsp+0x90]
0000707b885ceb44  vmovaps xmm11, [rsp+0xA0]
0000707b885ceb4d  vmovaps xmm12, [rsp+0xB0]
0000707b885ceb56  vmovaps xmm13, [rsp+0xC0]
0000707b885ceb5f  vmovaps xmm14, [rsp+0xD0]
0000707b885ceb68  vmovaps xmm15, [rsp+0xE0]
0000707b885ceb71  add rsp, 0xF0
0000707b885ceb78  pop r11
0000707b885ceb7a  pop r10
0000707b885ceb7c  pop r9
0000707b885ceb7e  pop r8
0000707b885ceb80  pop rsi
0000707b885ceb81  pop rdi
0000707b885ceb82  pop rdx
0000707b885ceb83  pop rcx
0000707b885ceb84  pop rax
0000707b885ceb85  add rsp, 0x08
0000707b885ceb89  jmp 0x0000707B885CE848
0000707b885ceb8e  call 0x0000707B883FF540
0000707b885ceb93  jmp 0x0000707B885CE85B
0000707b885ceb98  int3
0000707b885ceb99  nop [rax], eax
0000707b885ceba0  movaps xmm1, [r15+0x180]
0000707b885ceba8  vpmovqd xmm15, xmm1
0000707b885cebae  pxor xmm14, xmm14
0000707b885cebb3  punpcklqdq xmm15, xmm14
0000707b885cebb8  movaps [r15+0x210], xmm15
0000707b885cebc0  movq xmm15, qword ptr [r15+0x120]
0000707b885cebc9  movq xmm14, qword ptr [r15+0x130]
0000707b885cebd2  psubd xmm15, xmm14
0000707b885cebd7  movq xmm15, xmm15
0000707b885cebdc  movaps xmm13, [r15+0x170]
0000707b885cebe4  paddq xmm1, xmm13
0000707b885cebe9  movaps [r15+0x180], xmm1
0000707b885cebf1  movq xmm1, qword ptr [r15+0x150]
0000707b885cebfa  paddd xmm14, xmm1
0000707b885cebff  movq xmm14, xmm14
0000707b885cec04  movq xmm14, xmm14
0000707b885cec09  movaps [r15+0x130], xmm14
0000707b885cec11  pmovzxdq xmm15, xmm15
0000707b885cec17  psllq xmm15, 0x00
0000707b885cec1d  movq xmm1, qword ptr [r15+0x210]
0000707b885cec26  movq xmm14, qword ptr [r15+0x110]
0000707b885cec2f  paddd xmm1, xmm14
0000707b885cec34  movq xmm1, xmm1
0000707b885cec38  vcvtuqq2pd xmm15, xmm15
0000707b885cec3e  pmovzxdq xmm1, xmm1
0000707b885cec43  psllq xmm1, 0x00
0000707b885cec48  vcvtuqq2pd xmm1, xmm1
0000707b885cec4e  movaps xmm14, [r15+0x140]
0000707b885cec56  movaps xmm13, xmm15
0000707b885cec5a  mulpd xmm13, xmm14
0000707b885cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000707b885cec65  ptest xmm12, xmm12
0000707b885cec6b  jnz 0x0000707B885CED4E
0000707b885cec71  movaps [r15+0x220], xmm13
0000707b885cec79  mov rax, [r15+0x48]
0000707b885cec7d  mov r14, [r15+0x50]
0000707b885cec81  lea r12, [r14+rax*1]
0000707b885cec85  movups [r13+r12*1], xmm13
0000707b885cec8b  movaps xmm15, [r15+0x160]
0000707b885cec93  movaps xmm14, xmm1
0000707b885cec97  mulpd xmm14, xmm15
0000707b885cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000707b885ceca2  ptest xmm13, xmm13
0000707b885ceca8  jnz 0x0000707B885CEE9C
0000707b885cecae  movaps [r15+0x210], xmm14
0000707b885cecb6  mov r14, [r15+0x40]
0000707b885cecba  lea r12, [r14+rax*1]
0000707b885cecbe  movups [r13+r12*1], xmm14
0000707b885cecc4  lea r14, [rax+0x10]
0000707b885cecc8  mov [r15+0x48], r14
0000707b885ceccc  xor eax, eax
0000707b885cecce  mov r12d, 0x200
0000707b885cecd4  cmp r14, r12
0000707b885cecd7  cmc
0000707b885cecd8  lahf
0000707b885cecd9  seto al
0000707b885cecdc  mov [r15+0x108], eax
0000707b885cece3  mov eax, [r15+0x108]
0000707b885cecea  sahf
0000707b885ceceb  jnz 0x0000707B885CED1D
0000707b885ceced  cmp dword ptr [r15+0x318], 0x00
0000707b885cecf5  jz 0x0000707B885CEFF0
0000707b885cecfb  nop [rax+rax*1], ax
0000707b885ced04  nop [rax+rax*1], eax
0000707b885ced0c  mov eax, 0x4101EC
0000707b885ced11  mov [r15+0x100], rax
0000707b885ced18  jmp 0x0000707B883FE110
0000707b885ced1d  cmp dword ptr [r15+0x318], 0x00
0000707b885ced25  jz 0x0000707B885CEBA0
0000707b885ced2b  nop [rax+rax*1], ax
0000707b885ced34  nop [rax+rax*1], eax
0000707b885ced3c  mov eax, 0x4101AC
0000707b885ced41  mov [r15+0x100], rax
0000707b885ced48  jmp 0x0000707B883FE110
0000707b885ced4d  int3
0000707b885ced4e  sub rsp, 0x08
0000707b885ced52  push rax
0000707b885ced53  push rcx
0000707b885ced54  push rdx
0000707b885ced55  push rdi
0000707b885ced56  push rsi
0000707b885ced57  push r8
0000707b885ced59  push r9
0000707b885ced5b  push r10
0000707b885ced5d  push r11
0000707b885ced5f  sub rsp, 0xF0
0000707b885ced66  vmovaps [rsp], xmm0
0000707b885ced6b  vmovaps [rsp+0x10], xmm1
0000707b885ced71  vmovaps [rsp+0x20], xmm2
0000707b885ced77  vmovaps [rsp+0x30], xmm3
0000707b885ced7d  vmovaps [rsp+0x40], xmm4
0000707b885ced83  vmovaps [rsp+0x50], xmm5
0000707b885ced89  vmovaps [rsp+0x60], xmm6
0000707b885ced8f  vmovaps [rsp+0x70], xmm7
0000707b885ced95  vmovaps [rsp+0x80], xmm8
0000707b885ced9e  vmovaps [rsp+0x90], xmm9
0000707b885ceda7  vmovaps [rsp+0xA0], xmm10
0000707b885cedb0  vmovaps [rsp+0xB0], xmm11
0000707b885cedb9  vmovaps [rsp+0xC0], xmm12
0000707b885cedc2  vmovaps [rsp+0xD0], xmm14
0000707b885cedcb  vmovaps [rsp+0xE0], xmm15
0000707b885cedd4  sub rsp, 0x30
0000707b885cedd8  movaps [rsp], xmm13
0000707b885ceddd  movaps [rsp+0x10], xmm15
0000707b885cede3  movaps [rsp+0x20], xmm14
0000707b885cede9  lea rdi, [rsp]
0000707b885ceded  mov esi, 0x00
0000707b885cedf2  mov rax, 0x6471B35AC530
0000707b885cedfc  call rax
0000707b885cedfe  movaps xmm13, [rsp]
0000707b885cee03  add rsp, 0x30
0000707b885cee07  vmovaps xmm0, [rsp]
0000707b885cee0c  vmovaps xmm1, [rsp+0x10]
0000707b885cee12  vmovaps xmm2, [rsp+0x20]
0000707b885cee18  vmovaps xmm3, [rsp+0x30]
0000707b885cee1e  vmovaps xmm4, [rsp+0x40]
0000707b885cee24  vmovaps xmm5, [rsp+0x50]
0000707b885cee2a  vmovaps xmm6, [rsp+0x60]
0000707b885cee30  vmovaps xmm7, [rsp+0x70]
0000707b885cee36  vmovaps xmm8, [rsp+0x80]
0000707b885cee3f  vmovaps xmm9, [rsp+0x90]
0000707b885cee48  vmovaps xmm10, [rsp+0xA0]
0000707b885cee51  vmovaps xmm11, [rsp+0xB0]
0000707b885cee5a  vmovaps xmm12, [rsp+0xC0]
0000707b885cee63  vmovaps xmm14, [rsp+0xD0]
0000707b885cee6c  vmovaps xmm15, [rsp+0xE0]
0000707b885cee75  add rsp, 0xF0
0000707b885cee7c  pop r11
0000707b885cee7e  pop r10
0000707b885cee80  pop r9
0000707b885cee82  pop r8
0000707b885cee84  pop rsi
0000707b885cee85  pop rdi
0000707b885cee86  pop rdx
0000707b885cee87  pop rcx
0000707b885cee88  pop rax
0000707b885cee89  add rsp, 0x08
0000707b885cee8d  jmp 0x0000707B885CEC71
0000707b885cee92  call 0x0000707B884C2240
0000707b885cee97  jmp 0x0000707B885CEC8B
0000707b885cee9c  sub rsp, 0x08
0000707b885ceea0  push rax
0000707b885ceea1  push rcx
0000707b885ceea2  push rdx
0000707b885ceea3  push rdi
0000707b885ceea4  push rsi
0000707b885ceea5  push r8
0000707b885ceea7  push r9
0000707b885ceea9  push r10
0000707b885ceeab  push r11
0000707b885ceead  sub rsp, 0xF0
0000707b885ceeb4  vmovaps [rsp], xmm0
0000707b885ceeb9  vmovaps [rsp+0x10], xmm1
0000707b885ceebf  vmovaps [rsp+0x20], xmm2
0000707b885ceec5  vmovaps [rsp+0x30], xmm3
0000707b885ceecb  vmovaps [rsp+0x40], xmm4
0000707b885ceed1  vmovaps [rsp+0x50], xmm5
0000707b885ceed7  vmovaps [rsp+0x60], xmm6
0000707b885ceedd  vmovaps [rsp+0x70], xmm7
0000707b885ceee3  vmovaps [rsp+0x80], xmm8
0000707b885ceeec  vmovaps [rsp+0x90], xmm9
0000707b885ceef5  vmovaps [rsp+0xA0], xmm10
0000707b885ceefe  vmovaps [rsp+0xB0], xmm11
0000707b885cef07  vmovaps [rsp+0xC0], xmm12
0000707b885cef10  vmovaps [rsp+0xD0], xmm13
0000707b885cef19  vmovaps [rsp+0xE0], xmm15
0000707b885cef22  sub rsp, 0x30
0000707b885cef26  movaps [rsp], xmm14
0000707b885cef2b  movaps [rsp+0x10], xmm1
0000707b885cef30  movaps [rsp+0x20], xmm15
0000707b885cef36  lea rdi, [rsp]
0000707b885cef3a  mov esi, 0x00
0000707b885cef3f  mov rax, 0x6471B35AC530
0000707b885cef49  call rax
0000707b885cef4b  movaps xmm14, [rsp]
0000707b885cef50  add rsp, 0x30
0000707b885cef54  vmovaps xmm0, [rsp]
0000707b885cef59  vmovaps xmm1, [rsp+0x10]
0000707b885cef5f  vmovaps xmm2, [rsp+0x20]
0000707b885cef65  vmovaps xmm3, [rsp+0x30]
0000707b885cef6b  vmovaps xmm4, [rsp+0x40]
0000707b885cef71  vmovaps xmm5, [rsp+0x50]
0000707b885cef77  vmovaps xmm6, [rsp+0x60]
0000707b885cef7d  vmovaps xmm7, [rsp+0x70]
0000707b885cef83  vmovaps xmm8, [rsp+0x80]
0000707b885cef8c  vmovaps xmm9, [rsp+0x90]
0000707b885cef95  vmovaps xmm10, [rsp+0xA0]
0000707b885cef9e  vmovaps xmm11, [rsp+0xB0]
0000707b885cefa7  vmovaps xmm12, [rsp+0xC0]
0000707b885cefb0  vmovaps xmm13, [rsp+0xD0]
0000707b885cefb9  vmovaps xmm15, [rsp+0xE0]
0000707b885cefc2  add rsp, 0xF0
0000707b885cefc9  pop r11
0000707b885cefcb  pop r10
0000707b885cefcd  pop r9
0000707b885cefcf  pop r8
0000707b885cefd1  pop rsi
0000707b885cefd2  pop rdi
0000707b885cefd3  pop rdx
0000707b885cefd4  pop rcx
0000707b885cefd5  pop rax
0000707b885cefd6  add rsp, 0x08
0000707b885cefda  jmp 0x0000707B885CECAE
0000707b885cefdf  call 0x0000707B884C34C0
0000707b885cefe4  jmp 0x0000707B885CECC4
0000707b885cefe9  int3
0000707b885cefea  nop [rax+rax*1], ax
0000707b885ceff0  mov rax, [r15+0xF8]
0000707b885ceff7  lea r14, [rax-0x150]
0000707b885ceffe  mov [r15+0xF8], r14
0000707b885cf005  mov rax, [r15+0x50]
0000707b885cf009  lea r12, [rax+0x80]
0000707b885cf010  movups xmm1, [r13+r12*1]
0000707b885cf016  lea r12, [rax+0x90]
0000707b885cf01d  movups xmm15, [r13+r12*1]
0000707b885cf023  mov qword ptr [r15+0x48], 0x00
0000707b885cf02b  lea r12, [rax+0x40]
0000707b885cf02f  movups xmm14, [r13+r12*1]
0000707b885cf035  lea r12, [rax+0x50]
0000707b885cf039  movups xmm13, [r13+r12*1]
0000707b885cf03f  lea r12, [r14+0x120]
0000707b885cf046  movq xmm12, qword ptr [r15+0x1C0]
0000707b885cf04f  movq xmm11, qword ptr [r15+0x1B0]
0000707b885cf058  movq r11, xmm12
0000707b885cf05d  movq r10, xmm11
0000707b885cf062  mov [r13+r12*1], r11
0000707b885cf067  lea r12, [r14+0x128]
0000707b885cf06e  mov [r13+r12*1], r10
0000707b885cf073  vxorps xmm12, xmm12, xmm12
0000707b885cf078  vpbroadcastq xmm12, xmm12
0000707b885cf07d  lea r12, [r14+0x100]
0000707b885cf084  movq xmm11, qword ptr [r15+0x200]
0000707b885cf08d  movq xmm10, qword ptr [r15+0x1F0]
0000707b885cf096  movq r11, xmm11
0000707b885cf09b  movq r10, xmm10
0000707b885cf0a0  mov [r13+r12*1], r11
0000707b885cf0a5  lea r12, [r14+0x108]
0000707b885cf0ac  mov [r13+r12*1], r10
0000707b885cf0b1  lea r12, [r14+0xE0]
0000707b885cf0b8  movups [r13+r12*1], xmm15
0000707b885cf0be  lea r12, [r14+0xF0]
0000707b885cf0c5  movups [r13+r12*1], xmm1
0000707b885cf0cb  lea r12, [rax+0xC0]
0000707b885cf0d2  movups xmm1, [r13+r12*1]
0000707b885cf0d8  lea r12, [rax+0xD0]
0000707b885cf0df  movups xmm15, [r13+r12*1]
0000707b885cf0e5  lea r12, [r14+0x110]
0000707b885cf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000707b885cf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000707b885cf0fe  movq r11, xmm11
0000707b885cf103  movq r10, xmm10
0000707b885cf108  mov [r13+r12*1], r11
0000707b885cf10d  lea r12, [r14+0x118]
0000707b885cf114  mov [r13+r12*1], r10
0000707b885cf119  movups xmm11, [r13+rax*1]
0000707b885cf11f  lea r12, [rax+0x10]
0000707b885cf123  movups xmm10, [r13+r12*1]
0000707b885cf129  lea r12, [r14+0x130]
0000707b885cf130  movq xmm9, qword ptr [r15+0x1A0]
0000707b885cf139  movq xmm8, qword ptr [r15+0x190]
0000707b885cf142  movq r11, xmm9
0000707b885cf147  movq r10, xmm8
0000707b885cf14c  mov [r13+r12*1], r11
0000707b885cf151  lea r12, [r14+0x138]
0000707b885cf158  mov [r13+r12*1], r10
0000707b885cf15d  lea r12, [rax+0x140]
0000707b885cf164  movups xmm9, [r13+r12*1]
0000707b885cf16a  lea r12, [rax+0x150]
0000707b885cf171  movups xmm8, [r13+r12*1]
0000707b885cf177  lea r12, [r14+0xC0]
0000707b885cf17e  movups [r13+r12*1], xmm15
0000707b885cf184  lea r12, [r14+0xD0]
0000707b885cf18b  movups [r13+r12*1], xmm1
0000707b885cf191  lea r12, [rax+0x100]
0000707b885cf198  movups xmm1, [r13+r12*1]
0000707b885cf19e  lea r12, [rax+0x110]
0000707b885cf1a5  movups xmm15, [r13+r12*1]
0000707b885cf1ab  lea r12, [r14+0x140]
0000707b885cf1b2  mov r11, [r15+0xE8]
0000707b885cf1b9  mov [r13+r12*1], r11
0000707b885cf1be  lea r12, [rax+0x180]
0000707b885cf1c5  movups xmm7, [r13+r12*1]
0000707b885cf1cb  lea r12, [rax+0x190]
0000707b885cf1d2  movups xmm6, [r13+r12*1]
0000707b885cf1d8  lea r12, [rax+0x1C0]
0000707b885cf1df  movups xmm5, [r13+r12*1]
0000707b885cf1e5  lea r12, [rax+0x1D0]
0000707b885cf1ec  movups xmm4, [r13+r12*1]
0000707b885cf1f2  lea r12, [r14+0x20]
0000707b885cf1f6  movups [r13+r12*1], xmm1
0000707b885cf1fc  lea r12, [r14+0x30]
0000707b885cf200  movups [r13+r12*1], xmm13
0000707b885cf206  lea r12, [rax+0x60]
0000707b885cf20a  movups xmm1, [r13+r12*1]
0000707b885cf210  lea r12, [rax+0x70]
0000707b885cf214  movups xmm13, [r13+r12*1]
0000707b885cf21a  lea r12, [rax+0x20]
0000707b885cf21e  movups xmm3, [r13+r12*1]
0000707b885cf224  lea r12, [rax+0x30]
0000707b885cf228  movups xmm2, [r13+r12*1]
0000707b885cf22e  movaps [r15+0x1F0], xmm2
0000707b885cf236  lea r12, [r14+0x60]
0000707b885cf23a  movups [r13+r12*1], xmm11
0000707b885cf240  lea r12, [r14+0x70]
0000707b885cf244  movups [r13+r12*1], xmm5
0000707b885cf24a  lea r12, [rax+0xE0]
0000707b885cf251  movups xmm11, [r13+r12*1]
0000707b885cf257  lea r12, [rax+0xF0]
0000707b885cf25e  movups xmm5, [r13+r12*1]
0000707b885cf264  lea r12, [r14+0xA0]
0000707b885cf26b  movups [r13+r12*1], xmm13
0000707b885cf271  lea r12, [r14+0xB0]
0000707b885cf278  movups [r13+r12*1], xmm1
0000707b885cf27e  lea r12, [rax+0xA0]
0000707b885cf285  movups xmm1, [r13+r12*1]
0000707b885cf28b  lea r12, [rax+0xB0]
0000707b885cf292  movups xmm13, [r13+r12*1]
0000707b885cf298  lea r12, [rax+0x120]
0000707b885cf29f  vmovaps [rsp+0x10], xmm1
0000707b885cf2a5  movups xmm1, [r13+r12*1]
0000707b885cf2ab  lea r12, [rax+0x130]
0000707b885cf2b2  vmovaps [rsp+0x20], xmm1
0000707b885cf2b8  movups xmm1, [r13+r12*1]
0000707b885cf2be  lea r12, [rax+0x160]
0000707b885cf2c5  vmovaps [rsp+0x30], xmm1
0000707b885cf2cb  movups xmm1, [r13+r12*1]
0000707b885cf2d1  lea r12, [rax+0x170]
0000707b885cf2d8  vmovaps [rsp+0x40], xmm1
0000707b885cf2de  movups xmm1, [r13+r12*1]
0000707b885cf2e4  movaps [r15+0x2B0], xmm1
0000707b885cf2ec  lea r12, [r14+0x80]
0000707b885cf2f3  movups [r13+r12*1], xmm13
0000707b885cf2f9  lea r12, [r14+0x90]
0000707b885cf300  vmovaps xmm13, [rsp+0x10]
0000707b885cf306  movups [r13+r12*1], xmm13
0000707b885cf30c  lea r12, [rax+0x1A0]
0000707b885cf313  movups xmm13, [r13+r12*1]
0000707b885cf319  lea r12, [rax+0x1B0]
0000707b885cf320  vmovaps [rsp+0x10], xmm1
0000707b885cf326  movups xmm1, [r13+r12*1]
0000707b885cf32c  movaps [r15+0x290], xmm13
0000707b885cf334  movaps [r15+0x1E0], xmm1
0000707b885cf33c  lea r12, [rax+0x1E0]
0000707b885cf343  vmovaps [rsp+0x50], xmm1
0000707b885cf349  movups xmm1, [r13+r12*1]
0000707b885cf34f  lea r12, [rax+0x1F0]
0000707b885cf356  vmovaps [rsp+0x60], xmm1
0000707b885cf35c  movups xmm1, [r13+r12*1]
0000707b885cf362  mov qword ptr [r15+0x50], 0x430920
0000707b885cf36a  lea rax, [r14+0x40]
0000707b885cf36e  vmovaps [rsp+0x70], xmm1
0000707b885cf374  vmovaps xmm1, [rsp+0x40]
0000707b885cf37a  movups [r13+rax*1], xmm1
0000707b885cf380  lea rax, [r14+0x50]
0000707b885cf384  movups [r13+rax*1], xmm10
0000707b885cf38a  vmovaps xmm1, [rsp+0x70]
0000707b885cf390  movups [r13+r14*1], xmm1
0000707b885cf396  lea rax, [r14+0x10]
0000707b885cf39a  vmovaps xmm1, [rsp+0x60]
0000707b885cf3a0  movups [r13+rax*1], xmm1
0000707b885cf3a6  mov rax, [r15+0x40]
0000707b885cf3aa  vmovaps [rsp+0x40], xmm3
0000707b885cf3b0  vmovaps xmm1, [rsp+0x40]
0000707b885cf3b6  por xmm3, xmm1
0000707b885cf3ba  vmovaps [rsp+0x40], xmm6
0000707b885cf3c0  vmovaps xmm10, [rsp+0x40]
0000707b885cf3c6  por xmm6, xmm10
0000707b885cf3cb  lea r12, [rax+0x30]
0000707b885cf3cf  mov r11, [r13+r12*1]
0000707b885cf3d4  lea r12, [rax+0x38]
0000707b885cf3d8  mov r10, [r13+r12*1]
0000707b885cf3dd  movq xmm10, r11
0000707b885cf3e2  vmovaps [rsp+0x40], xmm1
0000707b885cf3e8  movq xmm1, r10
0000707b885cf3ed  movq xmm10, xmm10
0000707b885cf3f2  vmovaps [rsp+0x60], xmm10
0000707b885cf3f8  movq xmm10, xmm10
0000707b885cf3fd  movaps [r15+0x130], xmm10
0000707b885cf405  movq xmm1, xmm1
0000707b885cf409  vmovaps [rsp+0x70], xmm1
0000707b885cf40f  movq xmm1, xmm1
0000707b885cf413  movaps [r15+0x280], xmm1
0000707b885cf41b  vmovaps [rsp+0x80], xmm9
0000707b885cf424  vmovaps xmm1, [rsp+0x80]
0000707b885cf42d  por xmm9, xmm1
0000707b885cf432  lea r12, [rax+0x20]
0000707b885cf436  mov r11, [r13+r12*1]
0000707b885cf43b  lea r12, [rax+0x28]
0000707b885cf43f  mov r10, [r13+r12*1]
0000707b885cf444  movq xmm1, r11
0000707b885cf449  movq xmm10, r10
0000707b885cf44e  movq xmm1, xmm1
0000707b885cf452  vmovaps [rsp+0x80], xmm1
0000707b885cf45b  movq xmm1, xmm1
0000707b885cf45f  movaps [r15+0x150], xmm1
0000707b885cf467  movq xmm10, xmm10
0000707b885cf46c  vmovaps [rsp+0x90], xmm10
0000707b885cf475  movq xmm10, xmm10
0000707b885cf47a  movaps [r15+0x140], xmm10
0000707b885cf482  lea r12, [rax+0x10]
0000707b885cf486  mov r11, [r13+r12*1]
0000707b885cf48b  lea r12, [rax+0x18]
0000707b885cf48f  mov r10, [r13+r12*1]
0000707b885cf494  movq xmm1, r11
0000707b885cf499  movq xmm10, r10
0000707b885cf49e  movq xmm1, xmm1
0000707b885cf4a2  vmovaps [rsp+0xA0], xmm1
0000707b885cf4ab  movq xmm1, xmm1
0000707b885cf4af  movaps [r15+0x170], xmm1
0000707b885cf4b7  movq xmm10, xmm10
0000707b885cf4bc  vmovaps [rsp+0xB0], xmm10
0000707b885cf4c5  movq xmm10, xmm10
0000707b885cf4ca  movaps [r15+0x160], xmm10
0000707b885cf4d2  mov r12, [r13+rax*1]
0000707b885cf4d7  vmovq xmm1, r12
0000707b885cf4dc  vpbroadcastq xmm1, xmm1
0000707b885cf4e1  lea r12, [rax+0x08]
0000707b885cf4e5  mov rax, [r13+r12*1]
0000707b885cf4ea  movq xmm10, rax
0000707b885cf4ef  movaps [r15+0x230], xmm10
0000707b885cf4f7  lea rax, [r14+0x50]
0000707b885cf4fb  movups xmm10, [r13+rax*1]
0000707b885cf501  lea rax, [r14+0x60]
0000707b885cf505  vmovaps [rsp+0xC0], xmm1
0000707b885cf50e  movups xmm1, [r13+rax*1]
0000707b885cf514  lea rax, [r14+0x30]
0000707b885cf518  vmovaps [rsp+0xD0], xmm1
0000707b885cf521  movups xmm1, [r13+rax*1]
0000707b885cf527  mov qword ptr [r15+0x60], 0x430920
0000707b885cf52f  mov qword ptr [r15+0x58], 0x40
0000707b885cf537  vmovaps [rsp+0xE0], xmm1
0000707b885cf540  vmovaps [rsp+0xF0], xmm15
0000707b885cf549  vmovaps xmm15, [rsp+0xC0]
0000707b885cf552  vmovaps [rsp+0xC0], xmm14
0000707b885cf55b  vmovaps xmm14, [rsp+0x40]
0000707b885cf561  vmovaps [rsp+0x40], xmm13
0000707b885cf567  movaps xmm1, xmm15
0000707b885cf56b  mulpd xmm1, xmm14
0000707b885cf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000707b885cf575  ptest xmm13, xmm13
0000707b885cf57b  jnz 0x0000707B885D0682
0000707b885cf581  movq xmm14, qword ptr [r15+0x230]
0000707b885cf58a  vmovaps [rsp+0x100], xmm14
0000707b885cf593  vpermilpd xmm14, xmm14, 0x00
0000707b885cf599  vmovaps [rsp+0x110], xmm1
0000707b885cf5a2  vmovaps xmm1, [rsp+0xE0]
0000707b885cf5ab  vmovaps [rsp+0xE0], xmm15
0000707b885cf5b4  movaps xmm13, xmm1
0000707b885cf5b8  mulpd xmm13, xmm14
0000707b885cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000707b885cf5c3  ptest xmm15, xmm15
0000707b885cf5c9  jnz 0x0000707B885D07C4
0000707b885cf5cf  vxorps xmm1, xmm1, xmm1
0000707b885cf5d3  vpbroadcastq xmm1, xmm1
0000707b885cf5d8  vmovaps xmm14, [rsp+0xE0]
0000707b885cf5e1  vmovaps [rsp+0xE0], xmm1
0000707b885cf5ea  vmovaps xmm1, [rsp+0xD0]
0000707b885cf5f3  vmovaps [rsp+0xD0], xmm13
0000707b885cf5fc  movaps xmm15, xmm14
0000707b885cf600  mulpd xmm15, xmm1
0000707b885cf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000707b885cf60b  ptest xmm13, xmm13
0000707b885cf611  jnz 0x0000707B885D0907
0000707b885cf617  movaps xmm1, xmm14
0000707b885cf61b  mulpd xmm1, xmm10
0000707b885cf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000707b885cf625  ptest xmm13, xmm13
0000707b885cf62b  jnz 0x0000707B885D0A4A
0000707b885cf631  movaps xmm13, xmm14
0000707b885cf635  mulpd xmm13, xmm2
0000707b885cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000707b885cf640  ptest xmm10, xmm10
0000707b885cf646  jnz 0x0000707B885D0B8C
0000707b885cf64c  vmovaps [rsp+0x120], xmm7
0000707b885cf655  vmovaps xmm14, [rsp+0x120]
0000707b885cf65e  por xmm7, xmm14
0000707b885cf663  vmovaps xmm14, [rsp+0xC0]
0000707b885cf66c  vmovaps xmm10, [rsp+0xC0]
0000707b885cf675  por xmm14, xmm10
0000707b885cf67a  vmovaps xmm2, [rsp+0x100]
0000707b885cf683  vpermilpd xmm2, xmm2, 0x00
0000707b885cf689  vmovaps [rsp+0xC0], xmm1
0000707b885cf692  vmovaps [rsp+0x120], xmm15
0000707b885cf69b  movaps xmm1, xmm10
0000707b885cf69f  mulpd xmm1, xmm2
0000707b885cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000707b885cf6a8  ptest xmm15, xmm15
0000707b885cf6ae  jnz 0x0000707B885D0CCF
0000707b885cf6b4  xor eax, eax
0000707b885cf6b6  mov r12d, 0x40
0000707b885cf6bc  mov r11d, 0x200
0000707b885cf6c2  cmp r12, r11
0000707b885cf6c5  cmc
0000707b885cf6c6  lahf
0000707b885cf6c7  seto al
0000707b885cf6ca  mov [r15+0x108], eax
0000707b885cf6d1  vmovaps xmm10, [rsp+0x110]
0000707b885cf6da  vmovaps xmm2, [rsp+0xE0]
0000707b885cf6e3  vmovaps [rsp+0xE0], xmm1
0000707b885cf6ec  movaps xmm15, xmm10
0000707b885cf6f0  addpd xmm15, xmm2
0000707b885cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000707b885cf6fb  ptest xmm1, xmm1
0000707b885cf700  jnz 0x0000707B885D0E10
0000707b885cf706  vmovaps xmm10, [rsp+0x120]
0000707b885cf70f  vmovaps [rsp+0x110], xmm15
0000707b885cf718  movaps xmm1, xmm10
0000707b885cf71c  addpd xmm1, xmm12
0000707b885cf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000707b885cf726  ptest xmm15, xmm15
0000707b885cf72c  jnz 0x0000707B885D0F53
0000707b885cf732  vmovaps xmm10, [rsp+0xC0]
0000707b885cf73b  vmovaps [rsp+0xC0], xmm1
0000707b885cf744  movaps xmm15, xmm10
0000707b885cf748  addpd xmm15, xmm12
0000707b885cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000707b885cf753  ptest xmm1, xmm1
0000707b885cf758  jnz 0x0000707B885D1095
0000707b885cf75e  vmovaps xmm1, [rsp+0x30]
0000707b885cf764  vmovaps xmm12, [rsp+0x30]
0000707b885cf76a  por xmm1, xmm12
0000707b885cf76f  vmovaps xmm12, [rsp+0x20]
0000707b885cf775  vmovaps xmm10, [rsp+0x20]
0000707b885cf77b  por xmm12, xmm10
0000707b885cf780  vmovaps [rsp+0x20], xmm5
0000707b885cf786  vmovaps xmm10, [rsp+0x20]
0000707b885cf78c  por xmm5, xmm10
0000707b885cf791  vmovaps [rsp+0x20], xmm11
0000707b885cf797  vmovaps xmm10, [rsp+0x20]
0000707b885cf79d  por xmm11, xmm10
0000707b885cf7a2  vmovaps [rsp+0x20], xmm4
0000707b885cf7a8  vmovaps xmm10, [rsp+0x20]
0000707b885cf7ae  por xmm4, xmm10
0000707b885cf7b3  vmovaps [rsp+0x20], xmm8
0000707b885cf7b9  vmovaps xmm10, [rsp+0x20]
0000707b885cf7bf  por xmm8, xmm10
0000707b885cf7c4  vmovaps xmm10, [rsp+0xF0]
0000707b885cf7cd  vmovaps [rsp+0x20], xmm1
0000707b885cf7d3  vmovaps xmm1, [rsp+0xF0]
0000707b885cf7dc  por xmm10, xmm1
0000707b885cf7e1  lea rax, [r14+0xA0]
0000707b885cf7e8  movups xmm1, [r13+rax*1]
0000707b885cf7ee  lea rax, [r14+0xB0]
0000707b885cf7f5  vmovaps [rsp+0x30], xmm1
0000707b885cf7fb  movups xmm1, [r13+rax*1]
0000707b885cf801  vmovaps [rsp+0xF0], xmm1
0000707b885cf80a  vmovaps [rsp+0x120], xmm15
0000707b885cf813  movaps xmm1, xmm13
0000707b885cf817  addpd xmm1, xmm2
0000707b885cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000707b885cf820  ptest xmm15, xmm15
0000707b885cf826  jnz 0x0000707B885D11ED
0000707b885cf82c  lea rax, [r14+0xF0]
0000707b885cf833  movups xmm15, [r13+rax*1]
0000707b885cf839  vmovaps xmm2, [rsp+0xC0]
0000707b885cf842  vmovaps [rsp+0xC0], xmm1
0000707b885cf84b  vmovaps xmm1, [rsp+0xE0]
0000707b885cf854  vmovaps [rsp+0xE0], xmm15
0000707b885cf85d  movaps xmm13, xmm2
0000707b885cf861  addpd xmm13, xmm1
0000707b885cf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000707b885cf86c  ptest xmm15, xmm15
0000707b885cf872  jnz 0x0000707B885D1338
0000707b885cf878  vmovaps xmm15, [rsp+0x120]
0000707b885cf881  vmovaps xmm2, [rsp+0xD0]
0000707b885cf88a  vmovaps [rsp+0xD0], xmm14
0000707b885cf893  movaps xmm1, xmm15
0000707b885cf897  addpd xmm1, xmm2
0000707b885cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000707b885cf8a0  ptest xmm14, xmm14
0000707b885cf8a6  jnz 0x0000707B885D147A
0000707b885cf8ac  vmovaps xmm15, [rsp+0x100]
0000707b885cf8b5  vpermilpd xmm15, xmm15, 0x00
0000707b885cf8bb  vmovaps xmm2, [rsp+0xF0]
0000707b885cf8c4  vmovaps [rsp+0xF0], xmm1
0000707b885cf8cd  movaps xmm14, xmm2
0000707b885cf8d1  mulpd xmm14, xmm15
0000707b885cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000707b885cf8dc  ptest xmm1, xmm1
0000707b885cf8e1  jnz 0x0000707B885D15BB
0000707b885cf8e7  vmovaps xmm1, [rsp+0xA0]
0000707b885cf8f0  vpermilpd xmm1, xmm1, 0x00
0000707b885cf8f6  vmovaps xmm2, [rsp+0xE0]
0000707b885cf8ff  vmovaps [rsp+0xE0], xmm14
0000707b885cf908  movaps xmm15, xmm2
0000707b885cf90c  mulpd xmm15, xmm1
0000707b885cf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000707b885cf917  ptest xmm14, xmm14
0000707b885cf91d  jnz 0x0000707B885D16FE
0000707b885cf923  lea rax, [r14+0xE0]
0000707b885cf92a  movups xmm1, [r13+rax*1]
0000707b885cf930  vmovaps xmm14, [rsp+0x100]
0000707b885cf939  vpermilpd xmm14, xmm14, 0x00
0000707b885cf93f  vmovaps [rsp+0x100], xmm1
0000707b885cf948  vmovaps xmm1, [rsp+0x30]
0000707b885cf94e  vmovaps [rsp+0x30], xmm15
0000707b885cf954  movaps xmm2, xmm1
0000707b885cf957  mulpd xmm2, xmm14
0000707b885cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000707b885cf961  ptest xmm15, xmm15
0000707b885cf967  jnz 0x0000707B885D184A
0000707b885cf96d  vmovaps [rsp+0x120], xmm10
0000707b885cf976  vmovaps xmm1, [rsp+0x120]
0000707b885cf97f  por xmm10, xmm1
0000707b885cf984  movaps [r15+0x300], xmm10
0000707b885cf98c  vmovaps [rsp+0x120], xmm8
0000707b885cf995  vmovaps xmm1, [rsp+0x120]
0000707b885cf99e  por xmm8, xmm1
0000707b885cf9a3  movaps [r15+0x190], xmm8
0000707b885cf9ab  vmovaps xmm1, [rsp+0xA0]
0000707b885cf9b4  vpermilpd xmm1, xmm1, 0x00
0000707b885cf9ba  vmovaps xmm14, [rsp+0x100]
0000707b885cf9c3  vmovaps [rsp+0x100], xmm13
0000707b885cf9cc  movaps xmm15, xmm14
0000707b885cf9d0  mulpd xmm15, xmm1
0000707b885cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000707b885cf9db  ptest xmm13, xmm13
0000707b885cf9e1  jnz 0x0000707B885D198B
0000707b885cf9e7  lea rax, [r14+0x90]
0000707b885cf9ee  movups xmm1, [r13+rax*1]
0000707b885cf9f4  vmovaps [rsp+0x120], xmm4
0000707b885cf9fd  vmovaps xmm14, [rsp+0x120]
0000707b885cfa06  por xmm4, xmm14
0000707b885cfa0b  movaps [r15+0x1C0], xmm4
0000707b885cfa13  vmovaps [rsp+0x120], xmm11
0000707b885cfa1c  vmovaps xmm14, [rsp+0x120]
0000707b885cfa25  por xmm11, xmm14
0000707b885cfa2a  movaps [r15+0x200], xmm11
0000707b885cfa32  vmovaps [rsp+0x120], xmm5
0000707b885cfa3b  vmovaps xmm14, [rsp+0x120]
0000707b885cfa44  por xmm5, xmm14
0000707b885cfa49  movaps [r15+0x2D0], xmm5
0000707b885cfa51  vmovaps [rsp+0x120], xmm12
0000707b885cfa5a  vmovaps xmm14, [rsp+0x120]
0000707b885cfa63  por xmm12, xmm14
0000707b885cfa68  movaps [r15+0x2E0], xmm12
0000707b885cfa70  vmovaps xmm13, [rsp+0x110]
0000707b885cfa79  vmovaps [rsp+0x110], xmm1
0000707b885cfa82  vmovaps xmm1, [rsp+0xE0]
0000707b885cfa8b  vmovaps [rsp+0xE0], xmm15
0000707b885cfa94  movaps xmm14, xmm13
0000707b885cfa98  addpd xmm14, xmm1
0000707b885cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000707b885cfaa3  ptest xmm15, xmm15
0000707b885cfaa9  jnz 0x0000707B885D1AD8
0000707b885cfaaf  vmovaps xmm1, [rsp+0xA0]
0000707b885cfab8  vpermilpd xmm1, xmm1, 0x00
0000707b885cfabe  vmovaps xmm13, [rsp+0x110]
0000707b885cfac7  vmovaps [rsp+0x110], xmm14
0000707b885cfad0  movaps xmm15, xmm13
0000707b885cfad4  mulpd xmm15, xmm1
0000707b885cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000707b885cfadf  ptest xmm14, xmm14
0000707b885cfae5  jnz 0x0000707B885D1C1B
0000707b885cfaeb  lea rax, [r14+0x80]
0000707b885cfaf2  movups xmm1, [r13+rax*1]
0000707b885cfaf8  vmovaps xmm13, [rsp+0xC0]
0000707b885cfb01  vmovaps [rsp+0xC0], xmm1
0000707b885cfb0a  movaps xmm14, xmm13
0000707b885cfb0e  addpd xmm14, xmm2
0000707b885cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000707b885cfb19  ptest xmm1, xmm1
0000707b885cfb1e  jnz 0x0000707B885D1D68
0000707b885cfb24  vmovaps xmm13, [rsp+0x100]
0000707b885cfb2d  vmovaps xmm2, [rsp+0x30]
0000707b885cfb33  vmovaps [rsp+0x30], xmm15
0000707b885cfb39  movaps xmm1, xmm13
0000707b885cfb3d  addpd xmm1, xmm2
0000707b885cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000707b885cfb46  ptest xmm15, xmm15
0000707b885cfb4c  jnz 0x0000707B885D1EAB
0000707b885cfb52  vmovaps xmm15, [rsp+0x20]
0000707b885cfb58  vmovaps xmm13, [rsp+0x20]
0000707b885cfb5e  por xmm15, xmm13
0000707b885cfb63  movaps [r15+0x2F0], xmm15
0000707b885cfb6b  vmovaps xmm13, [rsp+0xA0]
0000707b885cfb74  vpermilpd xmm13, xmm13, 0x00
0000707b885cfb7a  vmovaps [rsp+0x20], xmm1
0000707b885cfb80  vmovaps xmm1, [rsp+0xC0]
0000707b885cfb89  vmovaps [rsp+0xA0], xmm15
0000707b885cfb92  movaps xmm2, xmm1
0000707b885cfb95  mulpd xmm2, xmm13
0000707b885cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000707b885cfb9f  ptest xmm15, xmm15
0000707b885cfba5  jnz 0x0000707B885D1FEC
0000707b885cfbab  lea rax, [r14+0xD0]
0000707b885cfbb2  movups xmm1, [r13+rax*1]
0000707b885cfbb8  vmovaps xmm13, [rsp+0xF0]
0000707b885cfbc1  vmovaps [rsp+0xC0], xmm1
0000707b885cfbca  vmovaps xmm1, [rsp+0xE0]
0000707b885cfbd3  vmovaps [rsp+0xE0], xmm14
0000707b885cfbdc  movaps xmm15, xmm13
0000707b885cfbe0  addpd xmm15, xmm1
0000707b885cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000707b885cfbeb  ptest xmm14, xmm14
0000707b885cfbf1  jnz 0x0000707B885D2137
0000707b885cfbf7  vmovaps xmm1, [rsp+0xB0]
0000707b885cfc00  vpermilpd xmm1, xmm1, 0x00
0000707b885cfc06  movaps xmm14, xmm11
0000707b885cfc0a  mulpd xmm14, xmm1
0000707b885cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000707b885cfc15  ptest xmm13, xmm13
0000707b885cfc1b  jnz 0x0000707B885D227A
0000707b885cfc21  movaps [r15+0x260], xmm14
0000707b885cfc29  vxorps xmm1, xmm1, xmm1
0000707b885cfc2d  vpbroadcastq xmm1, xmm1
0000707b885cfc32  movaps [r15+0x1B0], xmm1
0000707b885cfc3a  vmovaps xmm1, [rsp+0xB0]
0000707b885cfc43  vpermilpd xmm1, xmm1, 0x00
0000707b885cfc49  vmovaps xmm11, [rsp+0xC0]
0000707b885cfc52  vmovaps [rsp+0xC0], xmm15
0000707b885cfc5b  movaps xmm13, xmm11
0000707b885cfc5f  mulpd xmm13, xmm1
0000707b885cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000707b885cfc6a  ptest xmm15, xmm15
0000707b885cfc70  jnz 0x0000707B885D23BD
0000707b885cfc76  lea rax, [r14+0xC0]
0000707b885cfc7d  movups xmm1, [r13+rax*1]
0000707b885cfc83  vmovaps xmm11, [rsp+0x110]
0000707b885cfc8c  vmovaps [rsp+0xF0], xmm1
0000707b885cfc95  vmovaps xmm1, [rsp+0x30]
0000707b885cfc9b  vmovaps [rsp+0x30], xmm14
0000707b885cfca1  movaps xmm15, xmm11
0000707b885cfca5  addpd xmm15, xmm1
0000707b885cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000707b885cfcb0  ptest xmm14, xmm14
0000707b885cfcb6  jnz 0x0000707B885D250A
0000707b885cfcbc  vmovaps [rsp+0x100], xmm9
0000707b885cfcc5  vmovaps xmm1, [rsp+0x100]
0000707b885cfcce  por xmm9, xmm1
0000707b885cfcd3  movaps [r15+0x270], xmm9
0000707b885cfcdb  vmovaps [rsp+0x100], xmm6
0000707b885cfce4  vmovaps xmm1, [rsp+0x100]
0000707b885cfced  por xmm6, xmm1
0000707b885cfcf1  movaps [r15+0x1A0], xmm6
0000707b885cfcf9  vmovaps xmm14, [rsp+0xB0]
0000707b885cfd02  vpermilpd xmm14, xmm14, 0x00
0000707b885cfd08  vmovaps xmm6, [rsp+0xF0]
0000707b885cfd11  vmovaps [rsp+0xF0], xmm1
0000707b885cfd1a  movaps xmm11, xmm6
0000707b885cfd1e  mulpd xmm11, xmm14
0000707b885cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000707b885cfd29  ptest xmm1, xmm1
0000707b885cfd2e  jnz 0x0000707B885D264D
0000707b885cfd34  lea rax, [r14+0x20]
0000707b885cfd38  movups xmm1, [r13+rax*1]
0000707b885cfd3e  movaps [r15+0x110], xmm1
0000707b885cfd46  vmovaps xmm6, [rsp+0xE0]
0000707b885cfd4f  vmovaps [rsp+0xE0], xmm1
0000707b885cfd58  movaps xmm14, xmm6
0000707b885cfd5c  addpd xmm14, xmm2
0000707b885cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000707b885cfd67  ptest xmm1, xmm1
0000707b885cfd6c  jnz 0x0000707B885D279A
0000707b885cfd72  vmovaps xmm1, [rsp+0xB0]
0000707b885cfd7b  vpermilpd xmm1, xmm1, 0x00
0000707b885cfd81  movaps xmm6, xmm5
0000707b885cfd84  mulpd xmm6, xmm1
0000707b885cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000707b885cfd8d  ptest xmm2, xmm2
0000707b885cfd92  jnz 0x0000707B885D28DC
0000707b885cfd98  vmovaps xmm5, [rsp+0x20]
0000707b885cfd9e  movaps xmm1, xmm5
0000707b885cfda1  addpd xmm1, xmm13
0000707b885cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000707b885cfdab  ptest xmm2, xmm2
0000707b885cfdb0  jnz 0x0000707B885D2A1C
0000707b885cfdb6  vmovaps xmm13, [rsp+0x80]
0000707b885cfdbf  vpermilpd xmm13, xmm13, 0x00
0000707b885cfdc5  vmovaps xmm2, [rsp+0xE0]
0000707b885cfdce  vmovaps [rsp+0x20], xmm1
0000707b885cfdd4  movaps xmm5, xmm2
0000707b885cfdd7  mulpd xmm5, xmm13
0000707b885cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000707b885cfde1  ptest xmm1, xmm1
0000707b885cfde6  jnz 0x0000707B885D2B5D
0000707b885cfdec  vmovaps xmm1, [rsp+0x80]
0000707b885cfdf5  vpermilpd xmm1, xmm1, 0x00
0000707b885cfdfb  movaps xmm13, xmm10
0000707b885cfdff  mulpd xmm13, xmm1
0000707b885cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000707b885cfe0a  ptest xmm2, xmm2
0000707b885cfe0f  jnz 0x0000707B885D2C9E
0000707b885cfe15  vmovaps xmm10, [rsp+0x30]
0000707b885cfe1b  movaps xmm1, xmm15
0000707b885cfe1f  addpd xmm1, xmm10
0000707b885cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000707b885cfe29  ptest xmm2, xmm2
0000707b885cfe2e  jnz 0x0000707B885D2DE1
0000707b885cfe34  vmovaps xmm10, [rsp+0xC0]
0000707b885cfe3d  movaps xmm15, xmm10
0000707b885cfe41  addpd xmm15, xmm11
0000707b885cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000707b885cfe4c  ptest xmm2, xmm2
0000707b885cfe51  jnz 0x0000707B885D2F23
0000707b885cfe57  vmovaps xmm11, [rsp+0x80]
0000707b885cfe60  vpermilpd xmm11, xmm11, 0x00
0000707b885cfe66  movaps xmm10, xmm12
0000707b885cfe6a  mulpd xmm10, xmm11
0000707b885cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000707b885cfe75  ptest xmm2, xmm2
0000707b885cfe7a  jnz 0x0000707B885D3067
0000707b885cfe80  vmovaps xmm12, [rsp+0x80]
0000707b885cfe89  vpermilpd xmm12, xmm12, 0x00
0000707b885cfe8f  vmovaps xmm2, [rsp+0xA0]
0000707b885cfe98  vmovaps [rsp+0x30], xmm1
0000707b885cfe9e  movaps xmm11, xmm2
0000707b885cfea2  mulpd xmm11, xmm12
0000707b885cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000707b885cfead  ptest xmm1, xmm1
0000707b885cfeb2  jnz 0x0000707B885D31AB
0000707b885cfeb8  movaps xmm1, xmm14
0000707b885cfebc  addpd xmm1, xmm6
0000707b885cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000707b885cfec5  ptest xmm12, xmm12
0000707b885cfecb  jnz 0x0000707B885D32EE
0000707b885cfed1  vmovaps xmm12, [rsp+0x20]
0000707b885cfed7  movaps xmm14, xmm12
0000707b885cfedb  addpd xmm14, xmm5
0000707b885cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000707b885cfee6  ptest xmm6, xmm6
0000707b885cfeeb  jnz 0x0000707B885D342F
0000707b885cfef1  vmovaps xmm12, [rsp+0x90]
0000707b885cfefa  vpermilpd xmm12, xmm12, 0x00
0000707b885cff00  movaps xmm6, xmm9
0000707b885cff04  mulpd xmm6, xmm12
0000707b885cff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000707b885cff0e  ptest xmm5, xmm5
0000707b885cff13  jnz 0x0000707B885D3572
0000707b885cff19  movaps xmm12, xmm15
0000707b885cff1d  addpd xmm12, xmm13
0000707b885cff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000707b885cff28  ptest xmm9, xmm9
0000707b885cff2e  jnz 0x0000707B885D36B4
0000707b885cff34  vmovaps xmm13, [rsp+0x30]
0000707b885cff3a  movaps xmm15, xmm13
0000707b885cff3e  addpd xmm15, xmm10
0000707b885cff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000707b885cff49  ptest xmm9, xmm9
0000707b885cff4f  jnz 0x0000707B885D37F8
0000707b885cff55  vmovaps xmm13, [rsp+0xD0]
0000707b885cff5e  vmovaps xmm10, [rsp+0xD0]
0000707b885cff67  por xmm13, xmm10
0000707b885cff6c  movaps [r15+0x250], xmm13
0000707b885cff74  vmovaps [rsp+0x20], xmm7
0000707b885cff7a  vmovaps xmm13, [rsp+0x20]
0000707b885cff80  por xmm7, xmm13
0000707b885cff85  movaps [r15+0x2A0], xmm7
0000707b885cff8d  vmovaps [rsp+0x20], xmm3
0000707b885cff93  vmovaps xmm13, [rsp+0x20]
0000707b885cff99  por xmm3, xmm13
0000707b885cff9e  movaps [r15+0x1D0], xmm3
0000707b885cffa6  lea rax, [r14+0x40]
0000707b885cffaa  movups xmm13, [r13+rax*1]
0000707b885cffb0  movaps [r15+0x2C0], xmm13
0000707b885cffb8  vmovaps xmm10, [rsp+0x90]
0000707b885cffc1  vpermilpd xmm10, xmm10, 0x00
0000707b885cffc7  movaps xmm9, xmm8
0000707b885cffcb  mulpd xmm9, xmm10
0000707b885cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000707b885cffd6  ptest xmm5, xmm5
0000707b885cffdb  jnz 0x0000707B885D3946
0000707b885cffe1  movaps xmm10, xmm1
0000707b885cffe5  addpd xmm10, xmm11
0000707b885cffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000707b885cfff0  ptest xmm8, xmm8
0000707b885cfff6  jnz 0x0000707B885D3A8A
0000707b885cfffc  movaps xmm1, xmm14
0000707b885d0000  addpd xmm1, xmm6
0000707b885d0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000707b885d0009  ptest xmm11, xmm11
0000707b885d000f  jnz 0x0000707B885D3BCD
0000707b885d0015  vmovaps xmm14, [rsp+0x90]
0000707b885d001e  vpermilpd xmm14, xmm14, 0x00
0000707b885d0024  movaps xmm11, xmm13
0000707b885d0028  mulpd xmm11, xmm14
0000707b885d002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000707b885d0033  ptest xmm8, xmm8
0000707b885d0039  jnz 0x0000707B885D3D0E
0000707b885d003f  vmovaps xmm14, [rsp+0x90]
0000707b885d0048  vpermilpd xmm14, xmm14, 0x00
0000707b885d004e  vmovaps xmm8, [rsp+0x10]
0000707b885d0054  movaps xmm13, xmm8
0000707b885d0058  mulpd xmm13, xmm14
0000707b885d005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000707b885d0063  ptest xmm6, xmm6
0000707b885d0068  jnz 0x0000707B885D3E52
0000707b885d006e  vmovaps xmm14, [rsp+0x60]
0000707b885d0074  vpermilpd xmm14, xmm14, 0x00
0000707b885d007a  movaps xmm8, xmm7
0000707b885d007e  mulpd xmm8, xmm14
0000707b885d0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000707b885d0089  ptest xmm6, xmm6
0000707b885d008e  jnz 0x0000707B885D3F96
0000707b885d0094  movaps xmm14, xmm12
0000707b885d0098  addpd xmm14, xmm9
0000707b885d009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000707b885d00a3  ptest xmm7, xmm7
0000707b885d00a8  jnz 0x0000707B885D40D9
0000707b885d00ae  vmovaps xmm12, [rsp+0x60]
0000707b885d00b4  vpermilpd xmm12, xmm12, 0x00
0000707b885d00ba  vmovaps xmm7, [rsp+0xF0]
0000707b885d00c3  movaps xmm9, xmm7
0000707b885d00c7  mulpd xmm9, xmm12
0000707b885d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000707b885d00d2  ptest xmm6, xmm6
0000707b885d00d7  jnz 0x0000707B885D421D
0000707b885d00dd  movaps xmm12, xmm15
0000707b885d00e1  addpd xmm12, xmm11
0000707b885d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000707b885d00ec  ptest xmm7, xmm7
0000707b885d00f1  jnz 0x0000707B885D4360
0000707b885d00f7  vmovaps xmm15, [rsp+0x60]
0000707b885d00fd  vpermilpd xmm15, xmm15, 0x00
0000707b885d0103  vmovaps xmm7, [rsp+0x40]
0000707b885d0109  movaps xmm11, xmm7
0000707b885d010d  mulpd xmm11, xmm15
0000707b885d0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000707b885d0118  ptest xmm6, xmm6
0000707b885d011d  jnz 0x0000707B885D44A4
0000707b885d0123  movaps xmm15, xmm10
0000707b885d0127  addpd xmm15, xmm13
0000707b885d012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000707b885d0132  ptest xmm7, xmm7
0000707b885d0137  jnz 0x0000707B885D45E7
0000707b885d013d  vmovaps xmm13, [rsp+0x60]
0000707b885d0143  vpermilpd xmm13, xmm13, 0x00
0000707b885d0149  vmovaps xmm7, [rsp+0x50]
0000707b885d014f  movaps xmm10, xmm7
0000707b885d0153  mulpd xmm10, xmm13
0000707b885d0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000707b885d015e  ptest xmm6, xmm6
0000707b885d0163  jnz 0x0000707B885D472B
0000707b885d0169  movaps xmm13, xmm1
0000707b885d016d  addpd xmm13, xmm8
0000707b885d0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000707b885d0178  ptest xmm7, xmm7
0000707b885d017d  jnz 0x0000707B885D486E
0000707b885d0183  lea rax, [r14+0x70]
0000707b885d0187  movups xmm1, [r13+rax*1]
0000707b885d018d  movaps [r15+0x240], xmm1
0000707b885d0195  movaps xmm8, xmm14
0000707b885d0199  addpd xmm8, xmm9
0000707b885d019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000707b885d01a4  ptest xmm7, xmm7
0000707b885d01a9  jnz 0x0000707B885D49BB
0000707b885d01af  movaps [r15+0x170], xmm8
0000707b885d01b7  vmovaps xmm14, [rsp+0x70]
0000707b885d01bd  vpermilpd xmm14, xmm14, 0x00
0000707b885d01c3  movaps xmm9, xmm1
0000707b885d01c7  mulpd xmm9, xmm14
0000707b885d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000707b885d01d2  ptest xmm7, xmm7
0000707b885d01d7  jnz 0x0000707B885D4AFF
0000707b885d01dd  vmovaps xmm1, [rsp+0x70]
0000707b885d01e3  vpermilpd xmm1, xmm1, 0x00
0000707b885d01e9  movaps xmm14, xmm4
0000707b885d01ed  mulpd xmm14, xmm1
0000707b885d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000707b885d01f8  ptest xmm7, xmm7
0000707b885d01fd  jnz 0x0000707B885D4C42
0000707b885d0203  movaps [r15+0x180], xmm14
0000707b885d020b  movaps xmm1, xmm12
0000707b885d020f  addpd xmm1, xmm11
0000707b885d0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000707b885d0219  ptest xmm7, xmm7
0000707b885d021e  jnz 0x0000707B885D4D84
0000707b885d0224  movaps [r15+0x210], xmm1
0000707b885d022c  movups xmm12, [r13+r14*1]
0000707b885d0232  lea rax, [r14+0x10]
0000707b885d0236  movups xmm11, [r13+rax*1]
0000707b885d023c  movaps [r15+0x230], xmm11
0000707b885d0244  movaps xmm7, xmm15
0000707b885d0248  addpd xmm7, xmm10
0000707b885d024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000707b885d0252  ptest xmm6, xmm6
0000707b885d0257  jnz 0x0000707B885D4EDA
0000707b885d025d  movaps [r15+0x130], xmm7
0000707b885d0265  vmovaps xmm15, [rsp+0x70]
0000707b885d026b  vpermilpd xmm15, xmm15, 0x00
0000707b885d0271  movaps xmm10, xmm11
0000707b885d0275  mulpd xmm10, xmm15
0000707b885d027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000707b885d0280  ptest xmm6, xmm6
0000707b885d0285  jnz 0x0000707B885D501C
0000707b885d028b  movaps [r15+0x220], xmm10
0000707b885d0293  vmovaps xmm15, [rsp+0x70]
0000707b885d0299  vpermilpd xmm15, xmm15, 0x00
0000707b885d029f  movaps xmm11, xmm12
0000707b885d02a3  mulpd xmm11, xmm15
0000707b885d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000707b885d02ae  ptest xmm6, xmm6
0000707b885d02b3  jnz 0x0000707B885D5160
0000707b885d02b9  movaps xmm15, xmm13
0000707b885d02bd  addpd xmm15, xmm9
0000707b885d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000707b885d02c8  ptest xmm12, xmm12
0000707b885d02ce  jnz 0x0000707B885D52A4
0000707b885d02d4  movaps [r15+0x140], xmm15
0000707b885d02dc  movaps xmm13, xmm8
0000707b885d02e0  addpd xmm13, xmm14
0000707b885d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000707b885d02eb  ptest xmm12, xmm12
0000707b885d02f1  jnz 0x0000707B885D53E8
0000707b885d02f7  movaps [r15+0x150], xmm13
0000707b885d02ff  movaps xmm14, xmm1
0000707b885d0303  addpd xmm14, xmm10
0000707b885d0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000707b885d030e  ptest xmm12, xmm12
0000707b885d0314  jnz 0x0000707B885D552C
0000707b885d031a  movaps [r15+0x160], xmm14
0000707b885d0322  movaps xmm1, xmm7
0000707b885d0325  addpd xmm1, xmm11
0000707b885d032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000707b885d032f  ptest xmm12, xmm12
0000707b885d0335  jnz 0x0000707B885D566F
0000707b885d033b  movaps [r15+0x120], xmm1
0000707b885d0343  mov eax, 0x430920
0000707b885d0348  movups [r13+rax*1], xmm15
0000707b885d034e  mov eax, 0x430930
0000707b885d0353  movups [r13+rax*1], xmm13
0000707b885d0359  mov eax, 0x430940
0000707b885d035e  movups [r13+rax*1], xmm14
0000707b885d0364  mov eax, 0x430950
0000707b885d0369  movups [r13+rax*1], xmm1
0000707b885d036f  mov eax, [r15+0x108]
0000707b885d0376  sahf
0000707b885d0377  jnz 0x0000707B885D03A9
0000707b885d0379  cmp dword ptr [r15+0x318], 0x00
0000707b885d0381  jz 0x0000707B885DB900
0000707b885d0387  nop [rax+rax*1], ax
0000707b885d0390  nop [rax+rax*1], eax
0000707b885d0398  mov eax, 0x410444
0000707b885d039d  mov [r15+0x100], rax
0000707b885d03a4  jmp 0x0000707B883FE110
0000707b885d03a9  cmp dword ptr [r15+0x318], 0x00
0000707b885d03b1  jz 0x0000707B885D57E0
0000707b885d03b7  nop [rax+rax*1], ax
0000707b885d03c0  nop [rax+rax*1], eax
0000707b885d03c8  mov eax, 0x410278
0000707b885d03cd  mov [r15+0x100], rax
0000707b885d03d4  jmp 0x0000707B883FE110
0000707b885d03d9  int3
0000707b885d03da  call 0x0000707B884B52F0
0000707b885d03df  jmp 0x0000707B885CF016
0000707b885d03e4  call 0x0000707B884C4620
0000707b885d03e9  jmp 0x0000707B885CF023
0000707b885d03ee  call 0x0000707B884C33A0
0000707b885d03f3  jmp 0x0000707B885CF035
0000707b885d03f8  call 0x0000707B884C2120
0000707b885d03fd  jmp 0x0000707B885CF03F
0000707b885d0402  call 0x0000707B884C0860
0000707b885d0407  jmp 0x0000707B885CF067
0000707b885d040c  call 0x0000707B884BF5F0
0000707b885d0411  jmp 0x0000707B885CF073
0000707b885d0416  call 0x0000707B884C0860
0000707b885d041b  jmp 0x0000707B885CF0A5
0000707b885d0420  call 0x0000707B884BF5F0
0000707b885d0425  jmp 0x0000707B885CF0B1
0000707b885d042a  call 0x0000707B884C4740
0000707b885d042f  jmp 0x0000707B885CF0BE
0000707b885d0434  call 0x0000707B884B5400
0000707b885d0439  jmp 0x0000707B885CF0CB
0000707b885d043e  call 0x0000707B884B52F0
0000707b885d0443  jmp 0x0000707B885CF0D8
0000707b885d0448  call 0x0000707B884C4620
0000707b885d044d  jmp 0x0000707B885CF0E5
0000707b885d0452  call 0x0000707B884C0860
0000707b885d0457  jmp 0x0000707B885CF10D
0000707b885d045c  call 0x0000707B884BF5F0
0000707b885d0461  jmp 0x0000707B885CF119
0000707b885d0466  call 0x0000707B88409D70
0000707b885d046b  jmp 0x0000707B885CF11F
0000707b885d0470  call 0x0000707B884BE9C0
0000707b885d0475  jmp 0x0000707B885CF129
0000707b885d047a  call 0x0000707B884C0860
0000707b885d047f  jmp 0x0000707B885CF151
0000707b885d0484  call 0x0000707B884BF5F0
0000707b885d0489  jmp 0x0000707B885CF15D
0000707b885d048e  call 0x0000707B884BD750
0000707b885d0493  jmp 0x0000707B885CF16A
0000707b885d0498  call 0x0000707B884BC4E0
0000707b885d049d  jmp 0x0000707B885CF177
0000707b885d04a2  call 0x0000707B884C4740
0000707b885d04a7  jmp 0x0000707B885CF184
0000707b885d04ac  call 0x0000707B884B5400
0000707b885d04b1  jmp 0x0000707B885CF191
0000707b885d04b6  call 0x0000707B884B52F0
0000707b885d04bb  jmp 0x0000707B885CF19E
0000707b885d04c0  call 0x0000707B884C4620
0000707b885d04c5  jmp 0x0000707B885CF1AB
0000707b885d04ca  call 0x0000707B884C0860
0000707b885d04cf  jmp 0x0000707B885CF1BE
0000707b885d04d4  call 0x0000707B884BB270
0000707b885d04d9  jmp 0x0000707B885CF1CB
0000707b885d04de  call 0x0000707B884BA000
0000707b885d04e3  jmp 0x0000707B885CF1D8
0000707b885d04e8  call 0x0000707B884B8D90
0000707b885d04ed  jmp 0x0000707B885CF1E5
0000707b885d04f2  call 0x0000707B884B8A20
0000707b885d04f7  jmp 0x0000707B885CF1F2
0000707b885d04fc  call 0x0000707B884B5400
0000707b885d0501  jmp 0x0000707B885CF1FC
0000707b885d0506  call 0x0000707B884C2240
0000707b885d050b  jmp 0x0000707B885CF206
0000707b885d0510  call 0x0000707B884B52F0
0000707b885d0515  jmp 0x0000707B885CF210
0000707b885d051a  call 0x0000707B884C2120
0000707b885d051f  jmp 0x0000707B885CF21A
0000707b885d0524  call 0x0000707B884B77B0
0000707b885d0529  jmp 0x0000707B885CF224
0000707b885d052e  call 0x0000707B884B6550
0000707b885d0533  jmp 0x0000707B885CF22E
0000707b885d0538  call 0x0000707B884BFD50
0000707b885d053d  jmp 0x0000707B885CF240
0000707b885d0542  call 0x0000707B884B8EA0
0000707b885d0547  jmp 0x0000707B885CF24A
0000707b885d054c  call 0x0000707B884BFC30
0000707b885d0551  jmp 0x0000707B885CF257
0000707b885d0556  call 0x0000707B884B8D90
0000707b885d055b  jmp 0x0000707B885CF264
0000707b885d0560  call 0x0000707B884C2240
0000707b885d0565  jmp 0x0000707B885CF271
0000707b885d056a  call 0x0000707B884B5400
0000707b885d056f  jmp 0x0000707B885CF27E
0000707b885d0574  call 0x0000707B884B52F0
0000707b885d0579  jmp 0x0000707B885CF28B
0000707b885d057e  call 0x0000707B884C2120
0000707b885d0583  jmp 0x0000707B885CF298
0000707b885d0588  call 0x0000707B884B52F0
0000707b885d058d  jmp 0x0000707B885CF2AB
0000707b885d0592  call 0x0000707B884B52F0
0000707b885d0597  jmp 0x0000707B885CF2BE
0000707b885d059c  call 0x0000707B884B52F0
0000707b885d05a1  jmp 0x0000707B885CF2D1
0000707b885d05a6  call 0x0000707B884B52F0
0000707b885d05ab  jmp 0x0000707B885CF2E4
0000707b885d05b0  call 0x0000707B884C2240
0000707b885d05b5  jmp 0x0000707B885CF2F9
0000707b885d05ba  call 0x0000707B884C2240
0000707b885d05bf  jmp 0x0000707B885CF30C
0000707b885d05c4  call 0x0000707B884C2120
0000707b885d05c9  jmp 0x0000707B885CF319
0000707b885d05ce  call 0x0000707B884B52F0
0000707b885d05d3  jmp 0x0000707B885CF32C
0000707b885d05d8  call 0x0000707B884B52F0
0000707b885d05dd  jmp 0x0000707B885CF34F
0000707b885d05e2  call 0x0000707B884B52F0
0000707b885d05e7  jmp 0x0000707B885CF362
0000707b885d05ec  call 0x0000707B883FF540
0000707b885d05f1  jmp 0x0000707B885CF380
0000707b885d05f6  call 0x0000707B88408C20
0000707b885d05fb  jmp 0x0000707B885CF38A
0000707b885d0600  call 0x0000707B884D6600
0000707b885d0605  jmp 0x0000707B885CF396
0000707b885d060a  call 0x0000707B883FF540
0000707b885d060f  jmp 0x0000707B885CF3A6
0000707b885d0614  call 0x0000707B884C0370
0000707b885d0619  jmp 0x0000707B885CF3D4
0000707b885d061e  call 0x0000707B884BF100
0000707b885d0623  jmp 0x0000707B885CF3DD
0000707b885d0628  call 0x0000707B884C0370
0000707b885d062d  jmp 0x0000707B885CF43B
0000707b885d0632  call 0x0000707B884BF100
0000707b885d0637  jmp 0x0000707B885CF444
0000707b885d063c  call 0x0000707B884C0370
0000707b885d0641  jmp 0x0000707B885CF48B
0000707b885d0646  call 0x0000707B884BF100
0000707b885d064b  jmp 0x0000707B885CF494
0000707b885d0650  call 0x0000707B8840B720
0000707b885d0655  jmp 0x0000707B885CF4D7
0000707b885d065a  call 0x0000707B884B47C0
0000707b885d065f  jmp 0x0000707B885CF4EA
0000707b885d0664  call 0x0000707B88408B00
0000707b885d0669  jmp 0x0000707B885CF501
0000707b885d066e  call 0x0000707B883FF430
0000707b885d0673  jmp 0x0000707B885CF514
0000707b885d0678  call 0x0000707B883FF430
0000707b885d067d  jmp 0x0000707B885CF527
0000707b885d0682  sub rsp, 0x08
0000707b885d0686  push rax
0000707b885d0687  push rcx
0000707b885d0688  push rdx
0000707b885d0689  push rdi
0000707b885d068a  push rsi
0000707b885d068b  push r8
0000707b885d068d  push r9
0000707b885d068f  push r10
0000707b885d0691  push r11
0000707b885d0693  sub rsp, 0xF0
0000707b885d069a  vmovaps [rsp], xmm0
0000707b885d069f  vmovaps [rsp+0x10], xmm2
0000707b885d06a5  vmovaps [rsp+0x20], xmm3
0000707b885d06ab  vmovaps [rsp+0x30], xmm4
0000707b885d06b1  vmovaps [rsp+0x40], xmm5
0000707b885d06b7  vmovaps [rsp+0x50], xmm6
0000707b885d06bd  vmovaps [rsp+0x60], xmm7
0000707b885d06c3  vmovaps [rsp+0x70], xmm8
0000707b885d06c9  vmovaps [rsp+0x80], xmm9
0000707b885d06d2  vmovaps [rsp+0x90], xmm10
0000707b885d06db  vmovaps [rsp+0xA0], xmm11
0000707b885d06e4  vmovaps [rsp+0xB0], xmm12
0000707b885d06ed  vmovaps [rsp+0xC0], xmm13
0000707b885d06f6  vmovaps [rsp+0xD0], xmm14
0000707b885d06ff  vmovaps [rsp+0xE0], xmm15
0000707b885d0708  sub rsp, 0x30
0000707b885d070c  movaps [rsp], xmm1
0000707b885d0710  movaps [rsp+0x10], xmm15
0000707b885d0716  movaps [rsp+0x20], xmm14
0000707b885d071c  lea rdi, [rsp]
0000707b885d0720  mov esi, 0x00
0000707b885d0725  mov rax, 0x6471B35AC530
0000707b885d072f  call rax
0000707b885d0731  movaps xmm1, [rsp]
0000707b885d0735  add rsp, 0x30
0000707b885d0739  vmovaps xmm0, [rsp]
0000707b885d073e  vmovaps xmm2, [rsp+0x10]
0000707b885d0744  vmovaps xmm3, [rsp+0x20]
0000707b885d074a  vmovaps xmm4, [rsp+0x30]
0000707b885d0750  vmovaps xmm5, [rsp+0x40]
0000707b885d0756  vmovaps xmm6, [rsp+0x50]
0000707b885d075c  vmovaps xmm7, [rsp+0x60]
0000707b885d0762  vmovaps xmm8, [rsp+0x70]
0000707b885d0768  vmovaps xmm9, [rsp+0x80]
0000707b885d0771  vmovaps xmm10, [rsp+0x90]
0000707b885d077a  vmovaps xmm11, [rsp+0xA0]
0000707b885d0783  vmovaps xmm12, [rsp+0xB0]
0000707b885d078c  vmovaps xmm13, [rsp+0xC0]
0000707b885d0795  vmovaps xmm14, [rsp+0xD0]
0000707b885d079e  vmovaps xmm15, [rsp+0xE0]
0000707b885d07a7  add rsp, 0xF0
0000707b885d07ae  pop r11
0000707b885d07b0  pop r10
0000707b885d07b2  pop r9
0000707b885d07b4  pop r8
0000707b885d07b6  pop rsi
0000707b885d07b7  pop rdi
0000707b885d07b8  pop rdx
0000707b885d07b9  pop rcx
0000707b885d07ba  pop rax
0000707b885d07bb  add rsp, 0x08
0000707b885d07bf  jmp 0x0000707B885CF581
0000707b885d07c4  sub rsp, 0x08
0000707b885d07c8  push rax
0000707b885d07c9  push rcx
0000707b885d07ca  push rdx
0000707b885d07cb  push rdi
0000707b885d07cc  push rsi
0000707b885d07cd  push r8
0000707b885d07cf  push r9
0000707b885d07d1  push r10
0000707b885d07d3  push r11
0000707b885d07d5  sub rsp, 0xF0
0000707b885d07dc  vmovaps [rsp], xmm0
0000707b885d07e1  vmovaps [rsp+0x10], xmm1
0000707b885d07e7  vmovaps [rsp+0x20], xmm2
0000707b885d07ed  vmovaps [rsp+0x30], xmm3
0000707b885d07f3  vmovaps [rsp+0x40], xmm4
0000707b885d07f9  vmovaps [rsp+0x50], xmm5
0000707b885d07ff  vmovaps [rsp+0x60], xmm6
0000707b885d0805  vmovaps [rsp+0x70], xmm7
0000707b885d080b  vmovaps [rsp+0x80], xmm8
0000707b885d0814  vmovaps [rsp+0x90], xmm9
0000707b885d081d  vmovaps [rsp+0xA0], xmm10
0000707b885d0826  vmovaps [rsp+0xB0], xmm11
0000707b885d082f  vmovaps [rsp+0xC0], xmm12
0000707b885d0838  vmovaps [rsp+0xD0], xmm14
0000707b885d0841  vmovaps [rsp+0xE0], xmm15
0000707b885d084a  sub rsp, 0x30
0000707b885d084e  movaps [rsp], xmm13
0000707b885d0853  movaps [rsp+0x10], xmm1
0000707b885d0858  movaps [rsp+0x20], xmm14
0000707b885d085e  lea rdi, [rsp]
0000707b885d0862  mov esi, 0x00
0000707b885d0867  mov rax, 0x6471B35AC530
0000707b885d0871  call rax
0000707b885d0873  movaps xmm13, [rsp]
0000707b885d0878  add rsp, 0x30
0000707b885d087c  vmovaps xmm0, [rsp]
0000707b885d0881  vmovaps xmm1, [rsp+0x10]
0000707b885d0887  vmovaps xmm2, [rsp+0x20]
0000707b885d088d  vmovaps xmm3, [rsp+0x30]
0000707b885d0893  vmovaps xmm4, [rsp+0x40]
0000707b885d0899  vmovaps xmm5, [rsp+0x50]
0000707b885d089f  vmovaps xmm6, [rsp+0x60]
0000707b885d08a5  vmovaps xmm7, [rsp+0x70]
0000707b885d08ab  vmovaps xmm8, [rsp+0x80]
0000707b885d08b4  vmovaps xmm9, [rsp+0x90]
0000707b885d08bd  vmovaps xmm10, [rsp+0xA0]
0000707b885d08c6  vmovaps xmm11, [rsp+0xB0]
0000707b885d08cf  vmovaps xmm12, [rsp+0xC0]
0000707b885d08d8  vmovaps xmm14, [rsp+0xD0]
0000707b885d08e1  vmovaps xmm15, [rsp+0xE0]
0000707b885d08ea  add rsp, 0xF0
0000707b885d08f1  pop r11
0000707b885d08f3  pop r10
0000707b885d08f5  pop r9
0000707b885d08f7  pop r8
0000707b885d08f9  pop rsi
0000707b885d08fa  pop rdi
0000707b885d08fb  pop rdx
0000707b885d08fc  pop rcx
0000707b885d08fd  pop rax
0000707b885d08fe  add rsp, 0x08
0000707b885d0902  jmp 0x0000707B885CF5CF
0000707b885d0907  sub rsp, 0x08
0000707b885d090b  push rax
0000707b885d090c  push rcx
0000707b885d090d  push rdx
0000707b885d090e  push rdi
0000707b885d090f  push rsi
0000707b885d0910  push r8
0000707b885d0912  push r9
0000707b885d0914  push r10
0000707b885d0916  push r11
0000707b885d0918  sub rsp, 0xF0
0000707b885d091f  vmovaps [rsp], xmm0
0000707b885d0924  vmovaps [rsp+0x10], xmm1
0000707b885d092a  vmovaps [rsp+0x20], xmm2
0000707b885d0930  vmovaps [rsp+0x30], xmm3
0000707b885d0936  vmovaps [rsp+0x40], xmm4
0000707b885d093c  vmovaps [rsp+0x50], xmm5
0000707b885d0942  vmovaps [rsp+0x60], xmm6
0000707b885d0948  vmovaps [rsp+0x70], xmm7
0000707b885d094e  vmovaps [rsp+0x80], xmm8
0000707b885d0957  vmovaps [rsp+0x90], xmm9
0000707b885d0960  vmovaps [rsp+0xA0], xmm10
0000707b885d0969  vmovaps [rsp+0xB0], xmm11
0000707b885d0972  vmovaps [rsp+0xC0], xmm12
0000707b885d097b  vmovaps [rsp+0xD0], xmm13
0000707b885d0984  vmovaps [rsp+0xE0], xmm14
0000707b885d098d  sub rsp, 0x30
0000707b885d0991  movaps [rsp], xmm15
0000707b885d0996  movaps [rsp+0x10], xmm14
0000707b885d099c  movaps [rsp+0x20], xmm1
0000707b885d09a1  lea rdi, [rsp]
0000707b885d09a5  mov esi, 0x00
0000707b885d09aa  mov rax, 0x6471B35AC530
0000707b885d09b4  call rax
0000707b885d09b6  movaps xmm15, [rsp]
0000707b885d09bb  add rsp, 0x30
0000707b885d09bf  vmovaps xmm0, [rsp]
0000707b885d09c4  vmovaps xmm1, [rsp+0x10]
0000707b885d09ca  vmovaps xmm2, [rsp+0x20]
0000707b885d09d0  vmovaps xmm3, [rsp+0x30]
0000707b885d09d6  vmovaps xmm4, [rsp+0x40]
0000707b885d09dc  vmovaps xmm5, [rsp+0x50]
0000707b885d09e2  vmovaps xmm6, [rsp+0x60]
0000707b885d09e8  vmovaps xmm7, [rsp+0x70]
0000707b885d09ee  vmovaps xmm8, [rsp+0x80]
0000707b885d09f7  vmovaps xmm9, [rsp+0x90]
0000707b885d0a00  vmovaps xmm10, [rsp+0xA0]
0000707b885d0a09  vmovaps xmm11, [rsp+0xB0]
0000707b885d0a12  vmovaps xmm12, [rsp+0xC0]
0000707b885d0a1b  vmovaps xmm13, [rsp+0xD0]
0000707b885d0a24  vmovaps xmm14, [rsp+0xE0]
0000707b885d0a2d  add rsp, 0xF0
0000707b885d0a34  pop r11
0000707b885d0a36  pop r10
0000707b885d0a38  pop r9
0000707b885d0a3a  pop r8
0000707b885d0a3c  pop rsi
0000707b885d0a3d  pop rdi
0000707b885d0a3e  pop rdx
0000707b885d0a3f  pop rcx
0000707b885d0a40  pop rax
0000707b885d0a41  add rsp, 0x08
0000707b885d0a45  jmp 0x0000707B885CF617
0000707b885d0a4a  sub rsp, 0x08
0000707b885d0a4e  push rax
0000707b885d0a4f  push rcx
0000707b885d0a50  push rdx
0000707b885d0a51  push rdi
0000707b885d0a52  push rsi
0000707b885d0a53  push r8
0000707b885d0a55  push r9
0000707b885d0a57  push r10
0000707b885d0a59  push r11
0000707b885d0a5b  sub rsp, 0xF0
0000707b885d0a62  vmovaps [rsp], xmm0
0000707b885d0a67  vmovaps [rsp+0x10], xmm2
0000707b885d0a6d  vmovaps [rsp+0x20], xmm3
0000707b885d0a73  vmovaps [rsp+0x30], xmm4
0000707b885d0a79  vmovaps [rsp+0x40], xmm5
0000707b885d0a7f  vmovaps [rsp+0x50], xmm6
0000707b885d0a85  vmovaps [rsp+0x60], xmm7
0000707b885d0a8b  vmovaps [rsp+0x70], xmm8
0000707b885d0a91  vmovaps [rsp+0x80], xmm9
0000707b885d0a9a  vmovaps [rsp+0x90], xmm10
0000707b885d0aa3  vmovaps [rsp+0xA0], xmm11
0000707b885d0aac  vmovaps [rsp+0xB0], xmm12
0000707b885d0ab5  vmovaps [rsp+0xC0], xmm13
0000707b885d0abe  vmovaps [rsp+0xD0], xmm14
0000707b885d0ac7  vmovaps [rsp+0xE0], xmm15
0000707b885d0ad0  sub rsp, 0x30
0000707b885d0ad4  movaps [rsp], xmm1
0000707b885d0ad8  movaps [rsp+0x10], xmm14
0000707b885d0ade  movaps [rsp+0x20], xmm10
0000707b885d0ae4  lea rdi, [rsp]
0000707b885d0ae8  mov esi, 0x00
0000707b885d0aed  mov rax, 0x6471B35AC530
0000707b885d0af7  call rax
0000707b885d0af9  movaps xmm1, [rsp]
0000707b885d0afd  add rsp, 0x30
0000707b885d0b01  vmovaps xmm0, [rsp]
0000707b885d0b06  vmovaps xmm2, [rsp+0x10]
0000707b885d0b0c  vmovaps xmm3, [rsp+0x20]
0000707b885d0b12  vmovaps xmm4, [rsp+0x30]
0000707b885d0b18  vmovaps xmm5, [rsp+0x40]
0000707b885d0b1e  vmovaps xmm6, [rsp+0x50]
0000707b885d0b24  vmovaps xmm7, [rsp+0x60]
0000707b885d0b2a  vmovaps xmm8, [rsp+0x70]
0000707b885d0b30  vmovaps xmm9, [rsp+0x80]
0000707b885d0b39  vmovaps xmm10, [rsp+0x90]
0000707b885d0b42  vmovaps xmm11, [rsp+0xA0]
0000707b885d0b4b  vmovaps xmm12, [rsp+0xB0]
0000707b885d0b54  vmovaps xmm13, [rsp+0xC0]
0000707b885d0b5d  vmovaps xmm14, [rsp+0xD0]
0000707b885d0b66  vmovaps xmm15, [rsp+0xE0]
0000707b885d0b6f  add rsp, 0xF0
0000707b885d0b76  pop r11
0000707b885d0b78  pop r10
0000707b885d0b7a  pop r9
0000707b885d0b7c  pop r8
0000707b885d0b7e  pop rsi
0000707b885d0b7f  pop rdi
0000707b885d0b80  pop rdx
0000707b885d0b81  pop rcx
0000707b885d0b82  pop rax
0000707b885d0b83  add rsp, 0x08
0000707b885d0b87  jmp 0x0000707B885CF631
0000707b885d0b8c  sub rsp, 0x08
0000707b885d0b90  push rax
0000707b885d0b91  push rcx
0000707b885d0b92  push rdx
0000707b885d0b93  push rdi
0000707b885d0b94  push rsi
0000707b885d0b95  push r8
0000707b885d0b97  push r9
0000707b885d0b99  push r10
0000707b885d0b9b  push r11
0000707b885d0b9d  sub rsp, 0xF0
0000707b885d0ba4  vmovaps [rsp], xmm0
0000707b885d0ba9  vmovaps [rsp+0x10], xmm1
0000707b885d0baf  vmovaps [rsp+0x20], xmm2
0000707b885d0bb5  vmovaps [rsp+0x30], xmm3
0000707b885d0bbb  vmovaps [rsp+0x40], xmm4
0000707b885d0bc1  vmovaps [rsp+0x50], xmm5
0000707b885d0bc7  vmovaps [rsp+0x60], xmm6
0000707b885d0bcd  vmovaps [rsp+0x70], xmm7
0000707b885d0bd3  vmovaps [rsp+0x80], xmm8
0000707b885d0bdc  vmovaps [rsp+0x90], xmm9
0000707b885d0be5  vmovaps [rsp+0xA0], xmm10
0000707b885d0bee  vmovaps [rsp+0xB0], xmm11
0000707b885d0bf7  vmovaps [rsp+0xC0], xmm12
0000707b885d0c00  vmovaps [rsp+0xD0], xmm14
0000707b885d0c09  vmovaps [rsp+0xE0], xmm15
0000707b885d0c12  sub rsp, 0x30
0000707b885d0c16  movaps [rsp], xmm13
0000707b885d0c1b  movaps [rsp+0x10], xmm14
0000707b885d0c21  movaps [rsp+0x20], xmm2
0000707b885d0c26  lea rdi, [rsp]
0000707b885d0c2a  mov esi, 0x00
0000707b885d0c2f  mov rax, 0x6471B35AC530
0000707b885d0c39  call rax
0000707b885d0c3b  movaps xmm13, [rsp]
0000707b885d0c40  add rsp, 0x30
0000707b885d0c44  vmovaps xmm0, [rsp]
0000707b885d0c49  vmovaps xmm1, [rsp+0x10]
0000707b885d0c4f  vmovaps xmm2, [rsp+0x20]
0000707b885d0c55  vmovaps xmm3, [rsp+0x30]
0000707b885d0c5b  vmovaps xmm4, [rsp+0x40]
0000707b885d0c61  vmovaps xmm5, [rsp+0x50]
0000707b885d0c67  vmovaps xmm6, [rsp+0x60]
0000707b885d0c6d  vmovaps xmm7, [rsp+0x70]
0000707b885d0c73  vmovaps xmm8, [rsp+0x80]
0000707b885d0c7c  vmovaps xmm9, [rsp+0x90]
0000707b885d0c85  vmovaps xmm10, [rsp+0xA0]
0000707b885d0c8e  vmovaps xmm11, [rsp+0xB0]
0000707b885d0c97  vmovaps xmm12, [rsp+0xC0]
0000707b885d0ca0  vmovaps xmm14, [rsp+0xD0]
0000707b885d0ca9  vmovaps xmm15, [rsp+0xE0]
0000707b885d0cb2  add rsp, 0xF0
0000707b885d0cb9  pop r11
0000707b885d0cbb  pop r10
0000707b885d0cbd  pop r9
0000707b885d0cbf  pop r8
0000707b885d0cc1  pop rsi
0000707b885d0cc2  pop rdi
0000707b885d0cc3  pop rdx
0000707b885d0cc4  pop rcx
0000707b885d0cc5  pop rax
0000707b885d0cc6  add rsp, 0x08
0000707b885d0cca  jmp 0x0000707B885CF64C
0000707b885d0ccf  sub rsp, 0x08
0000707b885d0cd3  push rax
0000707b885d0cd4  push rcx
0000707b885d0cd5  push rdx
0000707b885d0cd6  push rdi
0000707b885d0cd7  push rsi
0000707b885d0cd8  push r8
0000707b885d0cda  push r9
0000707b885d0cdc  push r10
0000707b885d0cde  push r11
0000707b885d0ce0  sub rsp, 0xF0
0000707b885d0ce7  vmovaps [rsp], xmm0
0000707b885d0cec  vmovaps [rsp+0x10], xmm2
0000707b885d0cf2  vmovaps [rsp+0x20], xmm3
0000707b885d0cf8  vmovaps [rsp+0x30], xmm4
0000707b885d0cfe  vmovaps [rsp+0x40], xmm5
0000707b885d0d04  vmovaps [rsp+0x50], xmm6
0000707b885d0d0a  vmovaps [rsp+0x60], xmm7
0000707b885d0d10  vmovaps [rsp+0x70], xmm8
0000707b885d0d16  vmovaps [rsp+0x80], xmm9
0000707b885d0d1f  vmovaps [rsp+0x90], xmm10
0000707b885d0d28  vmovaps [rsp+0xA0], xmm11
0000707b885d0d31  vmovaps [rsp+0xB0], xmm12
0000707b885d0d3a  vmovaps [rsp+0xC0], xmm13
0000707b885d0d43  vmovaps [rsp+0xD0], xmm14
0000707b885d0d4c  vmovaps [rsp+0xE0], xmm15
0000707b885d0d55  sub rsp, 0x30
0000707b885d0d59  movaps [rsp], xmm1
0000707b885d0d5d  movaps [rsp+0x10], xmm10
0000707b885d0d63  movaps [rsp+0x20], xmm2
0000707b885d0d68  lea rdi, [rsp]
0000707b885d0d6c  mov esi, 0x00
0000707b885d0d71  mov rax, 0x6471B35AC530
0000707b885d0d7b  call rax
0000707b885d0d7d  movaps xmm1, [rsp]
0000707b885d0d81  add rsp, 0x30
0000707b885d0d85  vmovaps xmm0, [rsp]
0000707b885d0d8a  vmovaps xmm2, [rsp+0x10]
0000707b885d0d90  vmovaps xmm3, [rsp+0x20]
0000707b885d0d96  vmovaps xmm4, [rsp+0x30]
0000707b885d0d9c  vmovaps xmm5, [rsp+0x40]
0000707b885d0da2  vmovaps xmm6, [rsp+0x50]
0000707b885d0da8  vmovaps xmm7, [rsp+0x60]
0000707b885d0dae  vmovaps xmm8, [rsp+0x70]
0000707b885d0db4  vmovaps xmm9, [rsp+0x80]
0000707b885d0dbd  vmovaps xmm10, [rsp+0x90]
0000707b885d0dc6  vmovaps xmm11, [rsp+0xA0]
0000707b885d0dcf  vmovaps xmm12, [rsp+0xB0]
0000707b885d0dd8  vmovaps xmm13, [rsp+0xC0]
0000707b885d0de1  vmovaps xmm14, [rsp+0xD0]
0000707b885d0dea  vmovaps xmm15, [rsp+0xE0]
0000707b885d0df3  add rsp, 0xF0
0000707b885d0dfa  pop r11
0000707b885d0dfc  pop r10
0000707b885d0dfe  pop r9
0000707b885d0e00  pop r8
0000707b885d0e02  pop rsi
0000707b885d0e03  pop rdi
0000707b885d0e04  pop rdx
0000707b885d0e05  pop rcx
0000707b885d0e06  pop rax
0000707b885d0e07  add rsp, 0x08
0000707b885d0e0b  jmp 0x0000707B885CF6B4
0000707b885d0e10  sub rsp, 0x08
0000707b885d0e14  push rax
0000707b885d0e15  push rcx
0000707b885d0e16  push rdx
0000707b885d0e17  push rdi
0000707b885d0e18  push rsi
0000707b885d0e19  push r8
0000707b885d0e1b  push r9
0000707b885d0e1d  push r10
0000707b885d0e1f  push r11
0000707b885d0e21  sub rsp, 0xF0
0000707b885d0e28  vmovaps [rsp], xmm0
0000707b885d0e2d  vmovaps [rsp+0x10], xmm1
0000707b885d0e33  vmovaps [rsp+0x20], xmm2
0000707b885d0e39  vmovaps [rsp+0x30], xmm3
0000707b885d0e3f  vmovaps [rsp+0x40], xmm4
0000707b885d0e45  vmovaps [rsp+0x50], xmm5
0000707b885d0e4b  vmovaps [rsp+0x60], xmm6
0000707b885d0e51  vmovaps [rsp+0x70], xmm7
0000707b885d0e57  vmovaps [rsp+0x80], xmm8
0000707b885d0e60  vmovaps [rsp+0x90], xmm9
0000707b885d0e69  vmovaps [rsp+0xA0], xmm10
0000707b885d0e72  vmovaps [rsp+0xB0], xmm11
0000707b885d0e7b  vmovaps [rsp+0xC0], xmm12
0000707b885d0e84  vmovaps [rsp+0xD0], xmm13
0000707b885d0e8d  vmovaps [rsp+0xE0], xmm14
0000707b885d0e96  sub rsp, 0x30
0000707b885d0e9a  movaps [rsp], xmm15
0000707b885d0e9f  movaps [rsp+0x10], xmm10
0000707b885d0ea5  movaps [rsp+0x20], xmm2
0000707b885d0eaa  lea rdi, [rsp]
0000707b885d0eae  mov esi, 0x00
0000707b885d0eb3  mov rax, 0x6471B35AC530
0000707b885d0ebd  call rax
0000707b885d0ebf  movaps xmm15, [rsp]
0000707b885d0ec4  add rsp, 0x30
0000707b885d0ec8  vmovaps xmm0, [rsp]
0000707b885d0ecd  vmovaps xmm1, [rsp+0x10]
0000707b885d0ed3  vmovaps xmm2, [rsp+0x20]
0000707b885d0ed9  vmovaps xmm3, [rsp+0x30]
0000707b885d0edf  vmovaps xmm4, [rsp+0x40]
0000707b885d0ee5  vmovaps xmm5, [rsp+0x50]
0000707b885d0eeb  vmovaps xmm6, [rsp+0x60]
0000707b885d0ef1  vmovaps xmm7, [rsp+0x70]
0000707b885d0ef7  vmovaps xmm8, [rsp+0x80]
0000707b885d0f00  vmovaps xmm9, [rsp+0x90]
0000707b885d0f09  vmovaps xmm10, [rsp+0xA0]
0000707b885d0f12  vmovaps xmm11, [rsp+0xB0]
0000707b885d0f1b  vmovaps xmm12, [rsp+0xC0]
0000707b885d0f24  vmovaps xmm13, [rsp+0xD0]
0000707b885d0f2d  vmovaps xmm14, [rsp+0xE0]
0000707b885d0f36  add rsp, 0xF0
0000707b885d0f3d  pop r11
0000707b885d0f3f  pop r10
0000707b885d0f41  pop r9
0000707b885d0f43  pop r8
0000707b885d0f45  pop rsi
0000707b885d0f46  pop rdi
0000707b885d0f47  pop rdx
0000707b885d0f48  pop rcx
0000707b885d0f49  pop rax
0000707b885d0f4a  add rsp, 0x08
0000707b885d0f4e  jmp 0x0000707B885CF706
0000707b885d0f53  sub rsp, 0x08
0000707b885d0f57  push rax
0000707b885d0f58  push rcx
0000707b885d0f59  push rdx
0000707b885d0f5a  push rdi
0000707b885d0f5b  push rsi
0000707b885d0f5c  push r8
0000707b885d0f5e  push r9
0000707b885d0f60  push r10
0000707b885d0f62  push r11
0000707b885d0f64  sub rsp, 0xF0
0000707b885d0f6b  vmovaps [rsp], xmm0
0000707b885d0f70  vmovaps [rsp+0x10], xmm2
0000707b885d0f76  vmovaps [rsp+0x20], xmm3
0000707b885d0f7c  vmovaps [rsp+0x30], xmm4
0000707b885d0f82  vmovaps [rsp+0x40], xmm5
0000707b885d0f88  vmovaps [rsp+0x50], xmm6
0000707b885d0f8e  vmovaps [rsp+0x60], xmm7
0000707b885d0f94  vmovaps [rsp+0x70], xmm8
0000707b885d0f9a  vmovaps [rsp+0x80], xmm9
0000707b885d0fa3  vmovaps [rsp+0x90], xmm10
0000707b885d0fac  vmovaps [rsp+0xA0], xmm11
0000707b885d0fb5  vmovaps [rsp+0xB0], xmm12
0000707b885d0fbe  vmovaps [rsp+0xC0], xmm13
0000707b885d0fc7  vmovaps [rsp+0xD0], xmm14
0000707b885d0fd0  vmovaps [rsp+0xE0], xmm15
0000707b885d0fd9  sub rsp, 0x30
0000707b885d0fdd  movaps [rsp], xmm1
0000707b885d0fe1  movaps [rsp+0x10], xmm10
0000707b885d0fe7  movaps [rsp+0x20], xmm12
0000707b885d0fed  lea rdi, [rsp]
0000707b885d0ff1  mov esi, 0x00
0000707b885d0ff6  mov rax, 0x6471B35AC530
0000707b885d1000  call rax
0000707b885d1002  movaps xmm1, [rsp]
0000707b885d1006  add rsp, 0x30
0000707b885d100a  vmovaps xmm0, [rsp]
0000707b885d100f  vmovaps xmm2, [rsp+0x10]
0000707b885d1015  vmovaps xmm3, [rsp+0x20]
0000707b885d101b  vmovaps xmm4, [rsp+0x30]
0000707b885d1021  vmovaps xmm5, [rsp+0x40]
0000707b885d1027  vmovaps xmm6, [rsp+0x50]
0000707b885d102d  vmovaps xmm7, [rsp+0x60]
0000707b885d1033  vmovaps xmm8, [rsp+0x70]
0000707b885d1039  vmovaps xmm9, [rsp+0x80]
0000707b885d1042  vmovaps xmm10, [rsp+0x90]
0000707b885d104b  vmovaps xmm11, [rsp+0xA0]
0000707b885d1054  vmovaps xmm12, [rsp+0xB0]
0000707b885d105d  vmovaps xmm13, [rsp+0xC0]
0000707b885d1066  vmovaps xmm14, [rsp+0xD0]
0000707b885d106f  vmovaps xmm15, [rsp+0xE0]
0000707b885d1078  add rsp, 0xF0
0000707b885d107f  pop r11
0000707b885d1081  pop r10
0000707b885d1083  pop r9
0000707b885d1085  pop r8
0000707b885d1087  pop rsi
0000707b885d1088  pop rdi
0000707b885d1089  pop rdx
0000707b885d108a  pop rcx
0000707b885d108b  pop rax
0000707b885d108c  add rsp, 0x08
0000707b885d1090  jmp 0x0000707B885CF732
0000707b885d1095  sub rsp, 0x08
0000707b885d1099  push rax
0000707b885d109a  push rcx
0000707b885d109b  push rdx
0000707b885d109c  push rdi
0000707b885d109d  push rsi
0000707b885d109e  push r8
0000707b885d10a0  push r9
0000707b885d10a2  push r10
0000707b885d10a4  push r11
0000707b885d10a6  sub rsp, 0xF0
0000707b885d10ad  vmovaps [rsp], xmm0
0000707b885d10b2  vmovaps [rsp+0x10], xmm1
0000707b885d10b8  vmovaps [rsp+0x20], xmm2
0000707b885d10be  vmovaps [rsp+0x30], xmm3
0000707b885d10c4  vmovaps [rsp+0x40], xmm4
0000707b885d10ca  vmovaps [rsp+0x50], xmm5
0000707b885d10d0  vmovaps [rsp+0x60], xmm6
0000707b885d10d6  vmovaps [rsp+0x70], xmm7
0000707b885d10dc  vmovaps [rsp+0x80], xmm8
0000707b885d10e5  vmovaps [rsp+0x90], xmm9
0000707b885d10ee  vmovaps [rsp+0xA0], xmm10
0000707b885d10f7  vmovaps [rsp+0xB0], xmm11
0000707b885d1100  vmovaps [rsp+0xC0], xmm12
0000707b885d1109  vmovaps [rsp+0xD0], xmm13
0000707b885d1112  vmovaps [rsp+0xE0], xmm14
0000707b885d111b  sub rsp, 0x30
0000707b885d111f  movaps [rsp], xmm15
0000707b885d1124  movaps [rsp+0x10], xmm10
0000707b885d112a  movaps [rsp+0x20], xmm12
0000707b885d1130  lea rdi, [rsp]
0000707b885d1134  mov esi, 0x00
0000707b885d1139  mov rax, 0x6471B35AC530
0000707b885d1143  call rax
0000707b885d1145  movaps xmm15, [rsp]
0000707b885d114a  add rsp, 0x30
0000707b885d114e  vmovaps xmm0, [rsp]
0000707b885d1153  vmovaps xmm1, [rsp+0x10]
0000707b885d1159  vmovaps xmm2, [rsp+0x20]
0000707b885d115f  vmovaps xmm3, [rsp+0x30]
0000707b885d1165  vmovaps xmm4, [rsp+0x40]
0000707b885d116b  vmovaps xmm5, [rsp+0x50]
0000707b885d1171  vmovaps xmm6, [rsp+0x60]
0000707b885d1177  vmovaps xmm7, [rsp+0x70]
0000707b885d117d  vmovaps xmm8, [rsp+0x80]
0000707b885d1186  vmovaps xmm9, [rsp+0x90]
0000707b885d118f  vmovaps xmm10, [rsp+0xA0]
0000707b885d1198  vmovaps xmm11, [rsp+0xB0]
0000707b885d11a1  vmovaps xmm12, [rsp+0xC0]
0000707b885d11aa  vmovaps xmm13, [rsp+0xD0]
0000707b885d11b3  vmovaps xmm14, [rsp+0xE0]
0000707b885d11bc  add rsp, 0xF0
0000707b885d11c3  pop r11
0000707b885d11c5  pop r10
0000707b885d11c7  pop r9
0000707b885d11c9  pop r8
0000707b885d11cb  pop rsi
0000707b885d11cc  pop rdi
0000707b885d11cd  pop rdx
0000707b885d11ce  pop rcx
0000707b885d11cf  pop rax
0000707b885d11d0  add rsp, 0x08
0000707b885d11d4  jmp 0x0000707B885CF75E
0000707b885d11d9  call 0x0000707B883FF430
0000707b885d11de  jmp 0x0000707B885CF7EE
0000707b885d11e3  call 0x0000707B883FF430
0000707b885d11e8  jmp 0x0000707B885CF801
0000707b885d11ed  sub rsp, 0x08
0000707b885d11f1  push rax
0000707b885d11f2  push rcx
0000707b885d11f3  push rdx
0000707b885d11f4  push rdi
0000707b885d11f5  push rsi
0000707b885d11f6  push r8
0000707b885d11f8  push r9
0000707b885d11fa  push r10
0000707b885d11fc  push r11
0000707b885d11fe  sub rsp, 0xF0
0000707b885d1205  vmovaps [rsp], xmm0
0000707b885d120a  vmovaps [rsp+0x10], xmm2
0000707b885d1210  vmovaps [rsp+0x20], xmm3
0000707b885d1216  vmovaps [rsp+0x30], xmm4
0000707b885d121c  vmovaps [rsp+0x40], xmm5
0000707b885d1222  vmovaps [rsp+0x50], xmm6
0000707b885d1228  vmovaps [rsp+0x60], xmm7
0000707b885d122e  vmovaps [rsp+0x70], xmm8
0000707b885d1234  vmovaps [rsp+0x80], xmm9
0000707b885d123d  vmovaps [rsp+0x90], xmm10
0000707b885d1246  vmovaps [rsp+0xA0], xmm11
0000707b885d124f  vmovaps [rsp+0xB0], xmm12
0000707b885d1258  vmovaps [rsp+0xC0], xmm13
0000707b885d1261  vmovaps [rsp+0xD0], xmm14
0000707b885d126a  vmovaps [rsp+0xE0], xmm15
0000707b885d1273  sub rsp, 0x30
0000707b885d1277  movaps [rsp], xmm1
0000707b885d127b  movaps [rsp+0x10], xmm13
0000707b885d1281  movaps [rsp+0x20], xmm2
0000707b885d1286  lea rdi, [rsp]
0000707b885d128a  mov esi, 0x00
0000707b885d128f  mov rax, 0x6471B35AC530
0000707b885d1299  call rax
0000707b885d129b  movaps xmm1, [rsp]
0000707b885d129f  add rsp, 0x30
0000707b885d12a3  vmovaps xmm0, [rsp]
0000707b885d12a8  vmovaps xmm2, [rsp+0x10]
0000707b885d12ae  vmovaps xmm3, [rsp+0x20]
0000707b885d12b4  vmovaps xmm4, [rsp+0x30]
0000707b885d12ba  vmovaps xmm5, [rsp+0x40]
0000707b885d12c0  vmovaps xmm6, [rsp+0x50]
0000707b885d12c6  vmovaps xmm7, [rsp+0x60]
0000707b885d12cc  vmovaps xmm8, [rsp+0x70]
0000707b885d12d2  vmovaps xmm9, [rsp+0x80]
0000707b885d12db  vmovaps xmm10, [rsp+0x90]
0000707b885d12e4  vmovaps xmm11, [rsp+0xA0]
0000707b885d12ed  vmovaps xmm12, [rsp+0xB0]
0000707b885d12f6  vmovaps xmm13, [rsp+0xC0]
0000707b885d12ff  vmovaps xmm14, [rsp+0xD0]
0000707b885d1308  vmovaps xmm15, [rsp+0xE0]
0000707b885d1311  add rsp, 0xF0
0000707b885d1318  pop r11
0000707b885d131a  pop r10
0000707b885d131c  pop r9
0000707b885d131e  pop r8
0000707b885d1320  pop rsi
0000707b885d1321  pop rdi
0000707b885d1322  pop rdx
0000707b885d1323  pop rcx
0000707b885d1324  pop rax
0000707b885d1325  add rsp, 0x08
0000707b885d1329  jmp 0x0000707B885CF82C
0000707b885d132e  call 0x0000707B8840E760
0000707b885d1333  jmp 0x0000707B885CF839
0000707b885d1338  sub rsp, 0x08
0000707b885d133c  push rax
0000707b885d133d  push rcx
0000707b885d133e  push rdx
0000707b885d133f  push rdi
0000707b885d1340  push rsi
0000707b885d1341  push r8
0000707b885d1343  push r9
0000707b885d1345  push r10
0000707b885d1347  push r11
0000707b885d1349  sub rsp, 0xF0
0000707b885d1350  vmovaps [rsp], xmm0
0000707b885d1355  vmovaps [rsp+0x10], xmm1
0000707b885d135b  vmovaps [rsp+0x20], xmm2
0000707b885d1361  vmovaps [rsp+0x30], xmm3
0000707b885d1367  vmovaps [rsp+0x40], xmm4
0000707b885d136d  vmovaps [rsp+0x50], xmm5
0000707b885d1373  vmovaps [rsp+0x60], xmm6
0000707b885d1379  vmovaps [rsp+0x70], xmm7
0000707b885d137f  vmovaps [rsp+0x80], xmm8
0000707b885d1388  vmovaps [rsp+0x90], xmm9
0000707b885d1391  vmovaps [rsp+0xA0], xmm10
0000707b885d139a  vmovaps [rsp+0xB0], xmm11
0000707b885d13a3  vmovaps [rsp+0xC0], xmm12
0000707b885d13ac  vmovaps [rsp+0xD0], xmm14
0000707b885d13b5  vmovaps [rsp+0xE0], xmm15
0000707b885d13be  sub rsp, 0x30
0000707b885d13c2  movaps [rsp], xmm13
0000707b885d13c7  movaps [rsp+0x10], xmm2
0000707b885d13cc  movaps [rsp+0x20], xmm1
0000707b885d13d1  lea rdi, [rsp]
0000707b885d13d5  mov esi, 0x00
0000707b885d13da  mov rax, 0x6471B35AC530
0000707b885d13e4  call rax
0000707b885d13e6  movaps xmm13, [rsp]
0000707b885d13eb  add rsp, 0x30
0000707b885d13ef  vmovaps xmm0, [rsp]
0000707b885d13f4  vmovaps xmm1, [rsp+0x10]
0000707b885d13fa  vmovaps xmm2, [rsp+0x20]
0000707b885d1400  vmovaps xmm3, [rsp+0x30]
0000707b885d1406  vmovaps xmm4, [rsp+0x40]
0000707b885d140c  vmovaps xmm5, [rsp+0x50]
0000707b885d1412  vmovaps xmm6, [rsp+0x60]
0000707b885d1418  vmovaps xmm7, [rsp+0x70]
0000707b885d141e  vmovaps xmm8, [rsp+0x80]
0000707b885d1427  vmovaps xmm9, [rsp+0x90]
0000707b885d1430  vmovaps xmm10, [rsp+0xA0]
0000707b885d1439  vmovaps xmm11, [rsp+0xB0]
0000707b885d1442  vmovaps xmm12, [rsp+0xC0]
0000707b885d144b  vmovaps xmm14, [rsp+0xD0]
0000707b885d1454  vmovaps xmm15, [rsp+0xE0]
0000707b885d145d  add rsp, 0xF0
0000707b885d1464  pop r11
0000707b885d1466  pop r10
0000707b885d1468  pop r9
0000707b885d146a  pop r8
0000707b885d146c  pop rsi
0000707b885d146d  pop rdi
0000707b885d146e  pop rdx
0000707b885d146f  pop rcx
0000707b885d1470  pop rax
0000707b885d1471  add rsp, 0x08
0000707b885d1475  jmp 0x0000707B885CF878
0000707b885d147a  sub rsp, 0x08
0000707b885d147e  push rax
0000707b885d147f  push rcx
0000707b885d1480  push rdx
0000707b885d1481  push rdi
0000707b885d1482  push rsi
0000707b885d1483  push r8
0000707b885d1485  push r9
0000707b885d1487  push r10
0000707b885d1489  push r11
0000707b885d148b  sub rsp, 0xF0
0000707b885d1492  vmovaps [rsp], xmm0
0000707b885d1497  vmovaps [rsp+0x10], xmm2
0000707b885d149d  vmovaps [rsp+0x20], xmm3
0000707b885d14a3  vmovaps [rsp+0x30], xmm4
0000707b885d14a9  vmovaps [rsp+0x40], xmm5
0000707b885d14af  vmovaps [rsp+0x50], xmm6
0000707b885d14b5  vmovaps [rsp+0x60], xmm7
0000707b885d14bb  vmovaps [rsp+0x70], xmm8
0000707b885d14c1  vmovaps [rsp+0x80], xmm9
0000707b885d14ca  vmovaps [rsp+0x90], xmm10
0000707b885d14d3  vmovaps [rsp+0xA0], xmm11
0000707b885d14dc  vmovaps [rsp+0xB0], xmm12
0000707b885d14e5  vmovaps [rsp+0xC0], xmm13
0000707b885d14ee  vmovaps [rsp+0xD0], xmm14
0000707b885d14f7  vmovaps [rsp+0xE0], xmm15
0000707b885d1500  sub rsp, 0x30
0000707b885d1504  movaps [rsp], xmm1
0000707b885d1508  movaps [rsp+0x10], xmm15
0000707b885d150e  movaps [rsp+0x20], xmm2
0000707b885d1513  lea rdi, [rsp]
0000707b885d1517  mov esi, 0x00
0000707b885d151c  mov rax, 0x6471B35AC530
0000707b885d1526  call rax
0000707b885d1528  movaps xmm1, [rsp]
0000707b885d152c  add rsp, 0x30
0000707b885d1530  vmovaps xmm0, [rsp]
0000707b885d1535  vmovaps xmm2, [rsp+0x10]
0000707b885d153b  vmovaps xmm3, [rsp+0x20]
0000707b885d1541  vmovaps xmm4, [rsp+0x30]
0000707b885d1547  vmovaps xmm5, [rsp+0x40]
0000707b885d154d  vmovaps xmm6, [rsp+0x50]
0000707b885d1553  vmovaps xmm7, [rsp+0x60]
0000707b885d1559  vmovaps xmm8, [rsp+0x70]
0000707b885d155f  vmovaps xmm9, [rsp+0x80]
0000707b885d1568  vmovaps xmm10, [rsp+0x90]
0000707b885d1571  vmovaps xmm11, [rsp+0xA0]
0000707b885d157a  vmovaps xmm12, [rsp+0xB0]
0000707b885d1583  vmovaps xmm13, [rsp+0xC0]
0000707b885d158c  vmovaps xmm14, [rsp+0xD0]
0000707b885d1595  vmovaps xmm15, [rsp+0xE0]
0000707b885d159e  add rsp, 0xF0
0000707b885d15a5  pop r11
0000707b885d15a7  pop r10
0000707b885d15a9  pop r9
0000707b885d15ab  pop r8
0000707b885d15ad  pop rsi
0000707b885d15ae  pop rdi
0000707b885d15af  pop rdx
0000707b885d15b0  pop rcx
0000707b885d15b1  pop rax
0000707b885d15b2  add rsp, 0x08
0000707b885d15b6  jmp 0x0000707B885CF8AC
0000707b885d15bb  sub rsp, 0x08
0000707b885d15bf  push rax
0000707b885d15c0  push rcx
0000707b885d15c1  push rdx
0000707b885d15c2  push rdi
0000707b885d15c3  push rsi
0000707b885d15c4  push r8
0000707b885d15c6  push r9
0000707b885d15c8  push r10
0000707b885d15ca  push r11
0000707b885d15cc  sub rsp, 0xF0
0000707b885d15d3  vmovaps [rsp], xmm0
0000707b885d15d8  vmovaps [rsp+0x10], xmm1
0000707b885d15de  vmovaps [rsp+0x20], xmm2
0000707b885d15e4  vmovaps [rsp+0x30], xmm3
0000707b885d15ea  vmovaps [rsp+0x40], xmm4
0000707b885d15f0  vmovaps [rsp+0x50], xmm5
0000707b885d15f6  vmovaps [rsp+0x60], xmm6
0000707b885d15fc  vmovaps [rsp+0x70], xmm7
0000707b885d1602  vmovaps [rsp+0x80], xmm8
0000707b885d160b  vmovaps [rsp+0x90], xmm9
0000707b885d1614  vmovaps [rsp+0xA0], xmm10
0000707b885d161d  vmovaps [rsp+0xB0], xmm11
0000707b885d1626  vmovaps [rsp+0xC0], xmm12
0000707b885d162f  vmovaps [rsp+0xD0], xmm13
0000707b885d1638  vmovaps [rsp+0xE0], xmm15
0000707b885d1641  sub rsp, 0x30
0000707b885d1645  movaps [rsp], xmm14
0000707b885d164a  movaps [rsp+0x10], xmm2
0000707b885d164f  movaps [rsp+0x20], xmm15
0000707b885d1655  lea rdi, [rsp]
0000707b885d1659  mov esi, 0x00
0000707b885d165e  mov rax, 0x6471B35AC530
0000707b885d1668  call rax
0000707b885d166a  movaps xmm14, [rsp]
0000707b885d166f  add rsp, 0x30
0000707b885d1673  vmovaps xmm0, [rsp]
0000707b885d1678  vmovaps xmm1, [rsp+0x10]
0000707b885d167e  vmovaps xmm2, [rsp+0x20]
0000707b885d1684  vmovaps xmm3, [rsp+0x30]
0000707b885d168a  vmovaps xmm4, [rsp+0x40]
0000707b885d1690  vmovaps xmm5, [rsp+0x50]
0000707b885d1696  vmovaps xmm6, [rsp+0x60]
0000707b885d169c  vmovaps xmm7, [rsp+0x70]
0000707b885d16a2  vmovaps xmm8, [rsp+0x80]
0000707b885d16ab  vmovaps xmm9, [rsp+0x90]
0000707b885d16b4  vmovaps xmm10, [rsp+0xA0]
0000707b885d16bd  vmovaps xmm11, [rsp+0xB0]
0000707b885d16c6  vmovaps xmm12, [rsp+0xC0]
0000707b885d16cf  vmovaps xmm13, [rsp+0xD0]
0000707b885d16d8  vmovaps xmm15, [rsp+0xE0]
0000707b885d16e1  add rsp, 0xF0
0000707b885d16e8  pop r11
0000707b885d16ea  pop r10
0000707b885d16ec  pop r9
0000707b885d16ee  pop r8
0000707b885d16f0  pop rsi
0000707b885d16f1  pop rdi
0000707b885d16f2  pop rdx
0000707b885d16f3  pop rcx
0000707b885d16f4  pop rax
0000707b885d16f5  add rsp, 0x08
0000707b885d16f9  jmp 0x0000707B885CF8E7
0000707b885d16fe  sub rsp, 0x08
0000707b885d1702  push rax
0000707b885d1703  push rcx
0000707b885d1704  push rdx
0000707b885d1705  push rdi
0000707b885d1706  push rsi
0000707b885d1707  push r8
0000707b885d1709  push r9
0000707b885d170b  push r10
0000707b885d170d  push r11
0000707b885d170f  sub rsp, 0xF0
0000707b885d1716  vmovaps [rsp], xmm0
0000707b885d171b  vmovaps [rsp+0x10], xmm1
0000707b885d1721  vmovaps [rsp+0x20], xmm2
0000707b885d1727  vmovaps [rsp+0x30], xmm3
0000707b885d172d  vmovaps [rsp+0x40], xmm4
0000707b885d1733  vmovaps [rsp+0x50], xmm5
0000707b885d1739  vmovaps [rsp+0x60], xmm6
0000707b885d173f  vmovaps [rsp+0x70], xmm7
0000707b885d1745  vmovaps [rsp+0x80], xmm8
0000707b885d174e  vmovaps [rsp+0x90], xmm9
0000707b885d1757  vmovaps [rsp+0xA0], xmm10
0000707b885d1760  vmovaps [rsp+0xB0], xmm11
0000707b885d1769  vmovaps [rsp+0xC0], xmm12
0000707b885d1772  vmovaps [rsp+0xD0], xmm13
0000707b885d177b  vmovaps [rsp+0xE0], xmm14
0000707b885d1784  sub rsp, 0x30
0000707b885d1788  movaps [rsp], xmm15
0000707b885d178d  movaps [rsp+0x10], xmm2
0000707b885d1792  movaps [rsp+0x20], xmm1
0000707b885d1797  lea rdi, [rsp]
0000707b885d179b  mov esi, 0x00
0000707b885d17a0  mov rax, 0x6471B35AC530
0000707b885d17aa  call rax
0000707b885d17ac  movaps xmm15, [rsp]
0000707b885d17b1  add rsp, 0x30
0000707b885d17b5  vmovaps xmm0, [rsp]
0000707b885d17ba  vmovaps xmm1, [rsp+0x10]
0000707b885d17c0  vmovaps xmm2, [rsp+0x20]
0000707b885d17c6  vmovaps xmm3, [rsp+0x30]
0000707b885d17cc  vmovaps xmm4, [rsp+0x40]
0000707b885d17d2  vmovaps xmm5, [rsp+0x50]
0000707b885d17d8  vmovaps xmm6, [rsp+0x60]
0000707b885d17de  vmovaps xmm7, [rsp+0x70]
0000707b885d17e4  vmovaps xmm8, [rsp+0x80]
0000707b885d17ed  vmovaps xmm9, [rsp+0x90]
0000707b885d17f6  vmovaps xmm10, [rsp+0xA0]
0000707b885d17ff  vmovaps xmm11, [rsp+0xB0]
0000707b885d1808  vmovaps xmm12, [rsp+0xC0]
0000707b885d1811  vmovaps xmm13, [rsp+0xD0]
0000707b885d181a  vmovaps xmm14, [rsp+0xE0]
0000707b885d1823  add rsp, 0xF0
0000707b885d182a  pop r11
0000707b885d182c  pop r10
0000707b885d182e  pop r9
0000707b885d1830  pop r8
0000707b885d1832  pop rsi
0000707b885d1833  pop rdi
0000707b885d1834  pop rdx
0000707b885d1835  pop rcx
0000707b885d1836  pop rax
0000707b885d1837  add rsp, 0x08
0000707b885d183b  jmp 0x0000707B885CF923
0000707b885d1840  call 0x0000707B883FF430
0000707b885d1845  jmp 0x0000707B885CF930
0000707b885d184a  sub rsp, 0x08
0000707b885d184e  push rax
0000707b885d184f  push rcx
0000707b885d1850  push rdx
0000707b885d1851  push rdi
0000707b885d1852  push rsi
0000707b885d1853  push r8
0000707b885d1855  push r9
0000707b885d1857  push r10
0000707b885d1859  push r11
0000707b885d185b  sub rsp, 0xF0
0000707b885d1862  vmovaps [rsp], xmm0
0000707b885d1867  vmovaps [rsp+0x10], xmm1
0000707b885d186d  vmovaps [rsp+0x20], xmm3
0000707b885d1873  vmovaps [rsp+0x30], xmm4
0000707b885d1879  vmovaps [rsp+0x40], xmm5
0000707b885d187f  vmovaps [rsp+0x50], xmm6
0000707b885d1885  vmovaps [rsp+0x60], xmm7
0000707b885d188b  vmovaps [rsp+0x70], xmm8
0000707b885d1891  vmovaps [rsp+0x80], xmm9
0000707b885d189a  vmovaps [rsp+0x90], xmm10
0000707b885d18a3  vmovaps [rsp+0xA0], xmm11
0000707b885d18ac  vmovaps [rsp+0xB0], xmm12
0000707b885d18b5  vmovaps [rsp+0xC0], xmm13
0000707b885d18be  vmovaps [rsp+0xD0], xmm14
0000707b885d18c7  vmovaps [rsp+0xE0], xmm15
0000707b885d18d0  sub rsp, 0x30
0000707b885d18d4  movaps [rsp], xmm2
0000707b885d18d8  movaps [rsp+0x10], xmm1
0000707b885d18dd  movaps [rsp+0x20], xmm14
0000707b885d18e3  lea rdi, [rsp]
0000707b885d18e7  mov esi, 0x00
0000707b885d18ec  mov rax, 0x6471B35AC530
0000707b885d18f6  call rax
0000707b885d18f8  movaps xmm2, [rsp]
0000707b885d18fc  add rsp, 0x30
0000707b885d1900  vmovaps xmm0, [rsp]
0000707b885d1905  vmovaps xmm1, [rsp+0x10]
0000707b885d190b  vmovaps xmm3, [rsp+0x20]
0000707b885d1911  vmovaps xmm4, [rsp+0x30]
0000707b885d1917  vmovaps xmm5, [rsp+0x40]
0000707b885d191d  vmovaps xmm6, [rsp+0x50]
0000707b885d1923  vmovaps xmm7, [rsp+0x60]
0000707b885d1929  vmovaps xmm8, [rsp+0x70]
0000707b885d192f  vmovaps xmm9, [rsp+0x80]
0000707b885d1938  vmovaps xmm10, [rsp+0x90]
0000707b885d1941  vmovaps xmm11, [rsp+0xA0]
0000707b885d194a  vmovaps xmm12, [rsp+0xB0]
0000707b885d1953  vmovaps xmm13, [rsp+0xC0]
0000707b885d195c  vmovaps xmm14, [rsp+0xD0]
0000707b885d1965  vmovaps xmm15, [rsp+0xE0]
0000707b885d196e  add rsp, 0xF0
0000707b885d1975  pop r11
0000707b885d1977  pop r10
0000707b885d1979  pop r9
0000707b885d197b  pop r8
0000707b885d197d  pop rsi
0000707b885d197e  pop rdi
0000707b885d197f  pop rdx
0000707b885d1980  pop rcx
0000707b885d1981  pop rax
0000707b885d1982  add rsp, 0x08
0000707b885d1986  jmp 0x0000707B885CF96D
0000707b885d198b  sub rsp, 0x08
0000707b885d198f  push rax
0000707b885d1990  push rcx
0000707b885d1991  push rdx
0000707b885d1992  push rdi
0000707b885d1993  push rsi
0000707b885d1994  push r8
0000707b885d1996  push r9
0000707b885d1998  push r10
0000707b885d199a  push r11
0000707b885d199c  sub rsp, 0xF0
0000707b885d19a3  vmovaps [rsp], xmm0
0000707b885d19a8  vmovaps [rsp+0x10], xmm1
0000707b885d19ae  vmovaps [rsp+0x20], xmm2
0000707b885d19b4  vmovaps [rsp+0x30], xmm3
0000707b885d19ba  vmovaps [rsp+0x40], xmm4
0000707b885d19c0  vmovaps [rsp+0x50], xmm5
0000707b885d19c6  vmovaps [rsp+0x60], xmm6
0000707b885d19cc  vmovaps [rsp+0x70], xmm7
0000707b885d19d2  vmovaps [rsp+0x80], xmm8
0000707b885d19db  vmovaps [rsp+0x90], xmm9
0000707b885d19e4  vmovaps [rsp+0xA0], xmm10
0000707b885d19ed  vmovaps [rsp+0xB0], xmm11
0000707b885d19f6  vmovaps [rsp+0xC0], xmm12
0000707b885d19ff  vmovaps [rsp+0xD0], xmm13
0000707b885d1a08  vmovaps [rsp+0xE0], xmm14
0000707b885d1a11  sub rsp, 0x30
0000707b885d1a15  movaps [rsp], xmm15
0000707b885d1a1a  movaps [rsp+0x10], xmm14
0000707b885d1a20  movaps [rsp+0x20], xmm1
0000707b885d1a25  lea rdi, [rsp]
0000707b885d1a29  mov esi, 0x00
0000707b885d1a2e  mov rax, 0x6471B35AC530
0000707b885d1a38  call rax
0000707b885d1a3a  movaps xmm15, [rsp]
0000707b885d1a3f  add rsp, 0x30
0000707b885d1a43  vmovaps xmm0, [rsp]
0000707b885d1a48  vmovaps xmm1, [rsp+0x10]
0000707b885d1a4e  vmovaps xmm2, [rsp+0x20]
0000707b885d1a54  vmovaps xmm3, [rsp+0x30]
0000707b885d1a5a  vmovaps xmm4, [rsp+0x40]
0000707b885d1a60  vmovaps xmm5, [rsp+0x50]
0000707b885d1a66  vmovaps xmm6, [rsp+0x60]
0000707b885d1a6c  vmovaps xmm7, [rsp+0x70]
0000707b885d1a72  vmovaps xmm8, [rsp+0x80]
0000707b885d1a7b  vmovaps xmm9, [rsp+0x90]
0000707b885d1a84  vmovaps xmm10, [rsp+0xA0]
0000707b885d1a8d  vmovaps xmm11, [rsp+0xB0]
0000707b885d1a96  vmovaps xmm12, [rsp+0xC0]
0000707b885d1a9f  vmovaps xmm13, [rsp+0xD0]
0000707b885d1aa8  vmovaps xmm14, [rsp+0xE0]
0000707b885d1ab1  add rsp, 0xF0
0000707b885d1ab8  pop r11
0000707b885d1aba  pop r10
0000707b885d1abc  pop r9
0000707b885d1abe  pop r8
0000707b885d1ac0  pop rsi
0000707b885d1ac1  pop rdi
0000707b885d1ac2  pop rdx
0000707b885d1ac3  pop rcx
0000707b885d1ac4  pop rax
0000707b885d1ac5  add rsp, 0x08
0000707b885d1ac9  jmp 0x0000707B885CF9E7
0000707b885d1ace  call 0x0000707B883FF430
0000707b885d1ad3  jmp 0x0000707B885CF9F4
0000707b885d1ad8  sub rsp, 0x08
0000707b885d1adc  push rax
0000707b885d1add  push rcx
0000707b885d1ade  push rdx
0000707b885d1adf  push rdi
0000707b885d1ae0  push rsi
0000707b885d1ae1  push r8
0000707b885d1ae3  push r9
0000707b885d1ae5  push r10
0000707b885d1ae7  push r11
0000707b885d1ae9  sub rsp, 0xF0
0000707b885d1af0  vmovaps [rsp], xmm0
0000707b885d1af5  vmovaps [rsp+0x10], xmm1
0000707b885d1afb  vmovaps [rsp+0x20], xmm2
0000707b885d1b01  vmovaps [rsp+0x30], xmm3
0000707b885d1b07  vmovaps [rsp+0x40], xmm4
0000707b885d1b0d  vmovaps [rsp+0x50], xmm5
0000707b885d1b13  vmovaps [rsp+0x60], xmm6
0000707b885d1b19  vmovaps [rsp+0x70], xmm7
0000707b885d1b1f  vmovaps [rsp+0x80], xmm8
0000707b885d1b28  vmovaps [rsp+0x90], xmm9
0000707b885d1b31  vmovaps [rsp+0xA0], xmm10
0000707b885d1b3a  vmovaps [rsp+0xB0], xmm11
0000707b885d1b43  vmovaps [rsp+0xC0], xmm12
0000707b885d1b4c  vmovaps [rsp+0xD0], xmm13
0000707b885d1b55  vmovaps [rsp+0xE0], xmm15
0000707b885d1b5e  sub rsp, 0x30
0000707b885d1b62  movaps [rsp], xmm14
0000707b885d1b67  movaps [rsp+0x10], xmm13
0000707b885d1b6d  movaps [rsp+0x20], xmm1
0000707b885d1b72  lea rdi, [rsp]
0000707b885d1b76  mov esi, 0x00
0000707b885d1b7b  mov rax, 0x6471B35AC530
0000707b885d1b85  call rax
0000707b885d1b87  movaps xmm14, [rsp]
0000707b885d1b8c  add rsp, 0x30
0000707b885d1b90  vmovaps xmm0, [rsp]
0000707b885d1b95  vmovaps xmm1, [rsp+0x10]
0000707b885d1b9b  vmovaps xmm2, [rsp+0x20]
0000707b885d1ba1  vmovaps xmm3, [rsp+0x30]
0000707b885d1ba7  vmovaps xmm4, [rsp+0x40]
0000707b885d1bad  vmovaps xmm5, [rsp+0x50]
0000707b885d1bb3  vmovaps xmm6, [rsp+0x60]
0000707b885d1bb9  vmovaps xmm7, [rsp+0x70]
0000707b885d1bbf  vmovaps xmm8, [rsp+0x80]
0000707b885d1bc8  vmovaps xmm9, [rsp+0x90]
0000707b885d1bd1  vmovaps xmm10, [rsp+0xA0]
0000707b885d1bda  vmovaps xmm11, [rsp+0xB0]
0000707b885d1be3  vmovaps xmm12, [rsp+0xC0]
0000707b885d1bec  vmovaps xmm13, [rsp+0xD0]
0000707b885d1bf5  vmovaps xmm15, [rsp+0xE0]
0000707b885d1bfe  add rsp, 0xF0
0000707b885d1c05  pop r11
0000707b885d1c07  pop r10
0000707b885d1c09  pop r9
0000707b885d1c0b  pop r8
0000707b885d1c0d  pop rsi
0000707b885d1c0e  pop rdi
0000707b885d1c0f  pop rdx
0000707b885d1c10  pop rcx
0000707b885d1c11  pop rax
0000707b885d1c12  add rsp, 0x08
0000707b885d1c16  jmp 0x0000707B885CFAAF
0000707b885d1c1b  sub rsp, 0x08
0000707b885d1c1f  push rax
0000707b885d1c20  push rcx
0000707b885d1c21  push rdx
0000707b885d1c22  push rdi
0000707b885d1c23  push rsi
0000707b885d1c24  push r8
0000707b885d1c26  push r9
0000707b885d1c28  push r10
0000707b885d1c2a  push r11
0000707b885d1c2c  sub rsp, 0xF0
0000707b885d1c33  vmovaps [rsp], xmm0
0000707b885d1c38  vmovaps [rsp+0x10], xmm1
0000707b885d1c3e  vmovaps [rsp+0x20], xmm2
0000707b885d1c44  vmovaps [rsp+0x30], xmm3
0000707b885d1c4a  vmovaps [rsp+0x40], xmm4
0000707b885d1c50  vmovaps [rsp+0x50], xmm5
0000707b885d1c56  vmovaps [rsp+0x60], xmm6
0000707b885d1c5c  vmovaps [rsp+0x70], xmm7
0000707b885d1c62  vmovaps [rsp+0x80], xmm8
0000707b885d1c6b  vmovaps [rsp+0x90], xmm9
0000707b885d1c74  vmovaps [rsp+0xA0], xmm10
0000707b885d1c7d  vmovaps [rsp+0xB0], xmm11
0000707b885d1c86  vmovaps [rsp+0xC0], xmm12
0000707b885d1c8f  vmovaps [rsp+0xD0], xmm13
0000707b885d1c98  vmovaps [rsp+0xE0], xmm14
0000707b885d1ca1  sub rsp, 0x30
0000707b885d1ca5  movaps [rsp], xmm15
0000707b885d1caa  movaps [rsp+0x10], xmm13
0000707b885d1cb0  movaps [rsp+0x20], xmm1
0000707b885d1cb5  lea rdi, [rsp]
0000707b885d1cb9  mov esi, 0x00
0000707b885d1cbe  mov rax, 0x6471B35AC530
0000707b885d1cc8  call rax
0000707b885d1cca  movaps xmm15, [rsp]
0000707b885d1ccf  add rsp, 0x30
0000707b885d1cd3  vmovaps xmm0, [rsp]
0000707b885d1cd8  vmovaps xmm1, [rsp+0x10]
0000707b885d1cde  vmovaps xmm2, [rsp+0x20]
0000707b885d1ce4  vmovaps xmm3, [rsp+0x30]
0000707b885d1cea  vmovaps xmm4, [rsp+0x40]
0000707b885d1cf0  vmovaps xmm5, [rsp+0x50]
0000707b885d1cf6  vmovaps xmm6, [rsp+0x60]
0000707b885d1cfc  vmovaps xmm7, [rsp+0x70]
0000707b885d1d02  vmovaps xmm8, [rsp+0x80]
0000707b885d1d0b  vmovaps xmm9, [rsp+0x90]
0000707b885d1d14  vmovaps xmm10, [rsp+0xA0]
0000707b885d1d1d  vmovaps xmm11, [rsp+0xB0]
0000707b885d1d26  vmovaps xmm12, [rsp+0xC0]
0000707b885d1d2f  vmovaps xmm13, [rsp+0xD0]
0000707b885d1d38  vmovaps xmm14, [rsp+0xE0]
0000707b885d1d41  add rsp, 0xF0
0000707b885d1d48  pop r11
0000707b885d1d4a  pop r10
0000707b885d1d4c  pop r9
0000707b885d1d4e  pop r8
0000707b885d1d50  pop rsi
0000707b885d1d51  pop rdi
0000707b885d1d52  pop rdx
0000707b885d1d53  pop rcx
0000707b885d1d54  pop rax
0000707b885d1d55  add rsp, 0x08
0000707b885d1d59  jmp 0x0000707B885CFAEB
0000707b885d1d5e  call 0x0000707B883FF430
0000707b885d1d63  jmp 0x0000707B885CFAF8
0000707b885d1d68  sub rsp, 0x08
0000707b885d1d6c  push rax
0000707b885d1d6d  push rcx
0000707b885d1d6e  push rdx
0000707b885d1d6f  push rdi
0000707b885d1d70  push rsi
0000707b885d1d71  push r8
0000707b885d1d73  push r9
0000707b885d1d75  push r10
0000707b885d1d77  push r11
0000707b885d1d79  sub rsp, 0xF0
0000707b885d1d80  vmovaps [rsp], xmm0
0000707b885d1d85  vmovaps [rsp+0x10], xmm1
0000707b885d1d8b  vmovaps [rsp+0x20], xmm2
0000707b885d1d91  vmovaps [rsp+0x30], xmm3
0000707b885d1d97  vmovaps [rsp+0x40], xmm4
0000707b885d1d9d  vmovaps [rsp+0x50], xmm5
0000707b885d1da3  vmovaps [rsp+0x60], xmm6
0000707b885d1da9  vmovaps [rsp+0x70], xmm7
0000707b885d1daf  vmovaps [rsp+0x80], xmm8
0000707b885d1db8  vmovaps [rsp+0x90], xmm9
0000707b885d1dc1  vmovaps [rsp+0xA0], xmm10
0000707b885d1dca  vmovaps [rsp+0xB0], xmm11
0000707b885d1dd3  vmovaps [rsp+0xC0], xmm12
0000707b885d1ddc  vmovaps [rsp+0xD0], xmm13
0000707b885d1de5  vmovaps [rsp+0xE0], xmm15
0000707b885d1dee  sub rsp, 0x30
0000707b885d1df2  movaps [rsp], xmm14
0000707b885d1df7  movaps [rsp+0x10], xmm13
0000707b885d1dfd  movaps [rsp+0x20], xmm2
0000707b885d1e02  lea rdi, [rsp]
0000707b885d1e06  mov esi, 0x00
0000707b885d1e0b  mov rax, 0x6471B35AC530
0000707b885d1e15  call rax
0000707b885d1e17  movaps xmm14, [rsp]
0000707b885d1e1c  add rsp, 0x30
0000707b885d1e20  vmovaps xmm0, [rsp]
0000707b885d1e25  vmovaps xmm1, [rsp+0x10]
0000707b885d1e2b  vmovaps xmm2, [rsp+0x20]
0000707b885d1e31  vmovaps xmm3, [rsp+0x30]
0000707b885d1e37  vmovaps xmm4, [rsp+0x40]
0000707b885d1e3d  vmovaps xmm5, [rsp+0x50]
0000707b885d1e43  vmovaps xmm6, [rsp+0x60]
0000707b885d1e49  vmovaps xmm7, [rsp+0x70]
0000707b885d1e4f  vmovaps xmm8, [rsp+0x80]
0000707b885d1e58  vmovaps xmm9, [rsp+0x90]
0000707b885d1e61  vmovaps xmm10, [rsp+0xA0]
0000707b885d1e6a  vmovaps xmm11, [rsp+0xB0]
0000707b885d1e73  vmovaps xmm12, [rsp+0xC0]
0000707b885d1e7c  vmovaps xmm13, [rsp+0xD0]
0000707b885d1e85  vmovaps xmm15, [rsp+0xE0]
0000707b885d1e8e  add rsp, 0xF0
0000707b885d1e95  pop r11
0000707b885d1e97  pop r10
0000707b885d1e99  pop r9
0000707b885d1e9b  pop r8
0000707b885d1e9d  pop rsi
0000707b885d1e9e  pop rdi
0000707b885d1e9f  pop rdx
0000707b885d1ea0  pop rcx
0000707b885d1ea1  pop rax
0000707b885d1ea2  add rsp, 0x08
0000707b885d1ea6  jmp 0x0000707B885CFB24
0000707b885d1eab  sub rsp, 0x08
0000707b885d1eaf  push rax
0000707b885d1eb0  push rcx
0000707b885d1eb1  push rdx
0000707b885d1eb2  push rdi
0000707b885d1eb3  push rsi
0000707b885d1eb4  push r8
0000707b885d1eb6  push r9
0000707b885d1eb8  push r10
0000707b885d1eba  push r11
0000707b885d1ebc  sub rsp, 0xF0
0000707b885d1ec3  vmovaps [rsp], xmm0
0000707b885d1ec8  vmovaps [rsp+0x10], xmm2
0000707b885d1ece  vmovaps [rsp+0x20], xmm3
0000707b885d1ed4  vmovaps [rsp+0x30], xmm4
0000707b885d1eda  vmovaps [rsp+0x40], xmm5
0000707b885d1ee0  vmovaps [rsp+0x50], xmm6
0000707b885d1ee6  vmovaps [rsp+0x60], xmm7
0000707b885d1eec  vmovaps [rsp+0x70], xmm8
0000707b885d1ef2  vmovaps [rsp+0x80], xmm9
0000707b885d1efb  vmovaps [rsp+0x90], xmm10
0000707b885d1f04  vmovaps [rsp+0xA0], xmm11
0000707b885d1f0d  vmovaps [rsp+0xB0], xmm12
0000707b885d1f16  vmovaps [rsp+0xC0], xmm13
0000707b885d1f1f  vmovaps [rsp+0xD0], xmm14
0000707b885d1f28  vmovaps [rsp+0xE0], xmm15
0000707b885d1f31  sub rsp, 0x30
0000707b885d1f35  movaps [rsp], xmm1
0000707b885d1f39  movaps [rsp+0x10], xmm13
0000707b885d1f3f  movaps [rsp+0x20], xmm2
0000707b885d1f44  lea rdi, [rsp]
0000707b885d1f48  mov esi, 0x00
0000707b885d1f4d  mov rax, 0x6471B35AC530
0000707b885d1f57  call rax
0000707b885d1f59  movaps xmm1, [rsp]
0000707b885d1f5d  add rsp, 0x30
0000707b885d1f61  vmovaps xmm0, [rsp]
0000707b885d1f66  vmovaps xmm2, [rsp+0x10]
0000707b885d1f6c  vmovaps xmm3, [rsp+0x20]
0000707b885d1f72  vmovaps xmm4, [rsp+0x30]
0000707b885d1f78  vmovaps xmm5, [rsp+0x40]
0000707b885d1f7e  vmovaps xmm6, [rsp+0x50]
0000707b885d1f84  vmovaps xmm7, [rsp+0x60]
0000707b885d1f8a  vmovaps xmm8, [rsp+0x70]
0000707b885d1f90  vmovaps xmm9, [rsp+0x80]
0000707b885d1f99  vmovaps xmm10, [rsp+0x90]
0000707b885d1fa2  vmovaps xmm11, [rsp+0xA0]
0000707b885d1fab  vmovaps xmm12, [rsp+0xB0]
0000707b885d1fb4  vmovaps xmm13, [rsp+0xC0]
0000707b885d1fbd  vmovaps xmm14, [rsp+0xD0]
0000707b885d1fc6  vmovaps xmm15, [rsp+0xE0]
0000707b885d1fcf  add rsp, 0xF0
0000707b885d1fd6  pop r11
0000707b885d1fd8  pop r10
0000707b885d1fda  pop r9
0000707b885d1fdc  pop r8
0000707b885d1fde  pop rsi
0000707b885d1fdf  pop rdi
0000707b885d1fe0  pop rdx
0000707b885d1fe1  pop rcx
0000707b885d1fe2  pop rax
0000707b885d1fe3  add rsp, 0x08
0000707b885d1fe7  jmp 0x0000707B885CFB52
0000707b885d1fec  sub rsp, 0x08
0000707b885d1ff0  push rax
0000707b885d1ff1  push rcx
0000707b885d1ff2  push rdx
0000707b885d1ff3  push rdi
0000707b885d1ff4  push rsi
0000707b885d1ff5  push r8
0000707b885d1ff7  push r9
0000707b885d1ff9  push r10
0000707b885d1ffb  push r11
0000707b885d1ffd  sub rsp, 0xF0
0000707b885d2004  vmovaps [rsp], xmm0
0000707b885d2009  vmovaps [rsp+0x10], xmm1
0000707b885d200f  vmovaps [rsp+0x20], xmm3
0000707b885d2015  vmovaps [rsp+0x30], xmm4
0000707b885d201b  vmovaps [rsp+0x40], xmm5
0000707b885d2021  vmovaps [rsp+0x50], xmm6
0000707b885d2027  vmovaps [rsp+0x60], xmm7
0000707b885d202d  vmovaps [rsp+0x70], xmm8
0000707b885d2033  vmovaps [rsp+0x80], xmm9
0000707b885d203c  vmovaps [rsp+0x90], xmm10
0000707b885d2045  vmovaps [rsp+0xA0], xmm11
0000707b885d204e  vmovaps [rsp+0xB0], xmm12
0000707b885d2057  vmovaps [rsp+0xC0], xmm13
0000707b885d2060  vmovaps [rsp+0xD0], xmm14
0000707b885d2069  vmovaps [rsp+0xE0], xmm15
0000707b885d2072  sub rsp, 0x30
0000707b885d2076  movaps [rsp], xmm2
0000707b885d207a  movaps [rsp+0x10], xmm1
0000707b885d207f  movaps [rsp+0x20], xmm13
0000707b885d2085  lea rdi, [rsp]
0000707b885d2089  mov esi, 0x00
0000707b885d208e  mov rax, 0x6471B35AC530
0000707b885d2098  call rax
0000707b885d209a  movaps xmm2, [rsp]
0000707b885d209e  add rsp, 0x30
0000707b885d20a2  vmovaps xmm0, [rsp]
0000707b885d20a7  vmovaps xmm1, [rsp+0x10]
0000707b885d20ad  vmovaps xmm3, [rsp+0x20]
0000707b885d20b3  vmovaps xmm4, [rsp+0x30]
0000707b885d20b9  vmovaps xmm5, [rsp+0x40]
0000707b885d20bf  vmovaps xmm6, [rsp+0x50]
0000707b885d20c5  vmovaps xmm7, [rsp+0x60]
0000707b885d20cb  vmovaps xmm8, [rsp+0x70]
0000707b885d20d1  vmovaps xmm9, [rsp+0x80]
0000707b885d20da  vmovaps xmm10, [rsp+0x90]
0000707b885d20e3  vmovaps xmm11, [rsp+0xA0]
0000707b885d20ec  vmovaps xmm12, [rsp+0xB0]
0000707b885d20f5  vmovaps xmm13, [rsp+0xC0]
0000707b885d20fe  vmovaps xmm14, [rsp+0xD0]
0000707b885d2107  vmovaps xmm15, [rsp+0xE0]
0000707b885d2110  add rsp, 0xF0
0000707b885d2117  pop r11
0000707b885d2119  pop r10
0000707b885d211b  pop r9
0000707b885d211d  pop r8
0000707b885d211f  pop rsi
0000707b885d2120  pop rdi
0000707b885d2121  pop rdx
0000707b885d2122  pop rcx
0000707b885d2123  pop rax
0000707b885d2124  add rsp, 0x08
0000707b885d2128  jmp 0x0000707B885CFBAB
0000707b885d212d  call 0x0000707B883FF430
0000707b885d2132  jmp 0x0000707B885CFBB8
0000707b885d2137  sub rsp, 0x08
0000707b885d213b  push rax
0000707b885d213c  push rcx
0000707b885d213d  push rdx
0000707b885d213e  push rdi
0000707b885d213f  push rsi
0000707b885d2140  push r8
0000707b885d2142  push r9
0000707b885d2144  push r10
0000707b885d2146  push r11
0000707b885d2148  sub rsp, 0xF0
0000707b885d214f  vmovaps [rsp], xmm0
0000707b885d2154  vmovaps [rsp+0x10], xmm1
0000707b885d215a  vmovaps [rsp+0x20], xmm2
0000707b885d2160  vmovaps [rsp+0x30], xmm3
0000707b885d2166  vmovaps [rsp+0x40], xmm4
0000707b885d216c  vmovaps [rsp+0x50], xmm5
0000707b885d2172  vmovaps [rsp+0x60], xmm6
0000707b885d2178  vmovaps [rsp+0x70], xmm7
0000707b885d217e  vmovaps [rsp+0x80], xmm8
0000707b885d2187  vmovaps [rsp+0x90], xmm9
0000707b885d2190  vmovaps [rsp+0xA0], xmm10
0000707b885d2199  vmovaps [rsp+0xB0], xmm11
0000707b885d21a2  vmovaps [rsp+0xC0], xmm12
0000707b885d21ab  vmovaps [rsp+0xD0], xmm13
0000707b885d21b4  vmovaps [rsp+0xE0], xmm14
0000707b885d21bd  sub rsp, 0x30
0000707b885d21c1  movaps [rsp], xmm15
0000707b885d21c6  movaps [rsp+0x10], xmm13
0000707b885d21cc  movaps [rsp+0x20], xmm1
0000707b885d21d1  lea rdi, [rsp]
0000707b885d21d5  mov esi, 0x00
0000707b885d21da  mov rax, 0x6471B35AC530
0000707b885d21e4  call rax
0000707b885d21e6  movaps xmm15, [rsp]
0000707b885d21eb  add rsp, 0x30
0000707b885d21ef  vmovaps xmm0, [rsp]
0000707b885d21f4  vmovaps xmm1, [rsp+0x10]
0000707b885d21fa  vmovaps xmm2, [rsp+0x20]
0000707b885d2200  vmovaps xmm3, [rsp+0x30]
0000707b885d2206  vmovaps xmm4, [rsp+0x40]
0000707b885d220c  vmovaps xmm5, [rsp+0x50]
0000707b885d2212  vmovaps xmm6, [rsp+0x60]
0000707b885d2218  vmovaps xmm7, [rsp+0x70]
0000707b885d221e  vmovaps xmm8, [rsp+0x80]
0000707b885d2227  vmovaps xmm9, [rsp+0x90]
0000707b885d2230  vmovaps xmm10, [rsp+0xA0]
0000707b885d2239  vmovaps xmm11, [rsp+0xB0]
0000707b885d2242  vmovaps xmm12, [rsp+0xC0]
0000707b885d224b  vmovaps xmm13, [rsp+0xD0]
0000707b885d2254  vmovaps xmm14, [rsp+0xE0]
0000707b885d225d  add rsp, 0xF0
0000707b885d2264  pop r11
0000707b885d2266  pop r10
0000707b885d2268  pop r9
0000707b885d226a  pop r8
0000707b885d226c  pop rsi
0000707b885d226d  pop rdi
0000707b885d226e  pop rdx
0000707b885d226f  pop rcx
0000707b885d2270  pop rax
0000707b885d2271  add rsp, 0x08
0000707b885d2275  jmp 0x0000707B885CFBF7
0000707b885d227a  sub rsp, 0x08
0000707b885d227e  push rax
0000707b885d227f  push rcx
0000707b885d2280  push rdx
0000707b885d2281  push rdi
0000707b885d2282  push rsi
0000707b885d2283  push r8
0000707b885d2285  push r9
0000707b885d2287  push r10
0000707b885d2289  push r11
0000707b885d228b  sub rsp, 0xF0
0000707b885d2292  vmovaps [rsp], xmm0
0000707b885d2297  vmovaps [rsp+0x10], xmm1
0000707b885d229d  vmovaps [rsp+0x20], xmm2
0000707b885d22a3  vmovaps [rsp+0x30], xmm3
0000707b885d22a9  vmovaps [rsp+0x40], xmm4
0000707b885d22af  vmovaps [rsp+0x50], xmm5
0000707b885d22b5  vmovaps [rsp+0x60], xmm6
0000707b885d22bb  vmovaps [rsp+0x70], xmm7
0000707b885d22c1  vmovaps [rsp+0x80], xmm8
0000707b885d22ca  vmovaps [rsp+0x90], xmm9
0000707b885d22d3  vmovaps [rsp+0xA0], xmm10
0000707b885d22dc  vmovaps [rsp+0xB0], xmm11
0000707b885d22e5  vmovaps [rsp+0xC0], xmm12
0000707b885d22ee  vmovaps [rsp+0xD0], xmm13
0000707b885d22f7  vmovaps [rsp+0xE0], xmm15
0000707b885d2300  sub rsp, 0x30
0000707b885d2304  movaps [rsp], xmm14
0000707b885d2309  movaps [rsp+0x10], xmm11
0000707b885d230f  movaps [rsp+0x20], xmm1
0000707b885d2314  lea rdi, [rsp]
0000707b885d2318  mov esi, 0x00
0000707b885d231d  mov rax, 0x6471B35AC530
0000707b885d2327  call rax
0000707b885d2329  movaps xmm14, [rsp]
0000707b885d232e  add rsp, 0x30
0000707b885d2332  vmovaps xmm0, [rsp]
0000707b885d2337  vmovaps xmm1, [rsp+0x10]
0000707b885d233d  vmovaps xmm2, [rsp+0x20]
0000707b885d2343  vmovaps xmm3, [rsp+0x30]
0000707b885d2349  vmovaps xmm4, [rsp+0x40]
0000707b885d234f  vmovaps xmm5, [rsp+0x50]
0000707b885d2355  vmovaps xmm6, [rsp+0x60]
0000707b885d235b  vmovaps xmm7, [rsp+0x70]
0000707b885d2361  vmovaps xmm8, [rsp+0x80]
0000707b885d236a  vmovaps xmm9, [rsp+0x90]
0000707b885d2373  vmovaps xmm10, [rsp+0xA0]
0000707b885d237c  vmovaps xmm11, [rsp+0xB0]
0000707b885d2385  vmovaps xmm12, [rsp+0xC0]
0000707b885d238e  vmovaps xmm13, [rsp+0xD0]
0000707b885d2397  vmovaps xmm15, [rsp+0xE0]
0000707b885d23a0  add rsp, 0xF0
0000707b885d23a7  pop r11
0000707b885d23a9  pop r10
0000707b885d23ab  pop r9
0000707b885d23ad  pop r8
0000707b885d23af  pop rsi
0000707b885d23b0  pop rdi
0000707b885d23b1  pop rdx
0000707b885d23b2  pop rcx
0000707b885d23b3  pop rax
0000707b885d23b4  add rsp, 0x08
0000707b885d23b8  jmp 0x0000707B885CFC21
0000707b885d23bd  sub rsp, 0x08
0000707b885d23c1  push rax
0000707b885d23c2  push rcx
0000707b885d23c3  push rdx
0000707b885d23c4  push rdi
0000707b885d23c5  push rsi
0000707b885d23c6  push r8
0000707b885d23c8  push r9
0000707b885d23ca  push r10
0000707b885d23cc  push r11
0000707b885d23ce  sub rsp, 0xF0
0000707b885d23d5  vmovaps [rsp], xmm0
0000707b885d23da  vmovaps [rsp+0x10], xmm1
0000707b885d23e0  vmovaps [rsp+0x20], xmm2
0000707b885d23e6  vmovaps [rsp+0x30], xmm3
0000707b885d23ec  vmovaps [rsp+0x40], xmm4
0000707b885d23f2  vmovaps [rsp+0x50], xmm5
0000707b885d23f8  vmovaps [rsp+0x60], xmm6
0000707b885d23fe  vmovaps [rsp+0x70], xmm7
0000707b885d2404  vmovaps [rsp+0x80], xmm8
0000707b885d240d  vmovaps [rsp+0x90], xmm9
0000707b885d2416  vmovaps [rsp+0xA0], xmm10
0000707b885d241f  vmovaps [rsp+0xB0], xmm11
0000707b885d2428  vmovaps [rsp+0xC0], xmm12
0000707b885d2431  vmovaps [rsp+0xD0], xmm14
0000707b885d243a  vmovaps [rsp+0xE0], xmm15
0000707b885d2443  sub rsp, 0x30
0000707b885d2447  movaps [rsp], xmm13
0000707b885d244c  movaps [rsp+0x10], xmm11
0000707b885d2452  movaps [rsp+0x20], xmm1
0000707b885d2457  lea rdi, [rsp]
0000707b885d245b  mov esi, 0x00
0000707b885d2460  mov rax, 0x6471B35AC530
0000707b885d246a  call rax
0000707b885d246c  movaps xmm13, [rsp]
0000707b885d2471  add rsp, 0x30
0000707b885d2475  vmovaps xmm0, [rsp]
0000707b885d247a  vmovaps xmm1, [rsp+0x10]
0000707b885d2480  vmovaps xmm2, [rsp+0x20]
0000707b885d2486  vmovaps xmm3, [rsp+0x30]
0000707b885d248c  vmovaps xmm4, [rsp+0x40]
0000707b885d2492  vmovaps xmm5, [rsp+0x50]
0000707b885d2498  vmovaps xmm6, [rsp+0x60]
0000707b885d249e  vmovaps xmm7, [rsp+0x70]
0000707b885d24a4  vmovaps xmm8, [rsp+0x80]
0000707b885d24ad  vmovaps xmm9, [rsp+0x90]
0000707b885d24b6  vmovaps xmm10, [rsp+0xA0]
0000707b885d24bf  vmovaps xmm11, [rsp+0xB0]
0000707b885d24c8  vmovaps xmm12, [rsp+0xC0]
0000707b885d24d1  vmovaps xmm14, [rsp+0xD0]
0000707b885d24da  vmovaps xmm15, [rsp+0xE0]
0000707b885d24e3  add rsp, 0xF0
0000707b885d24ea  pop r11
0000707b885d24ec  pop r10
0000707b885d24ee  pop r9
0000707b885d24f0  pop r8
0000707b885d24f2  pop rsi
0000707b885d24f3  pop rdi
0000707b885d24f4  pop rdx
0000707b885d24f5  pop rcx
0000707b885d24f6  pop rax
0000707b885d24f7  add rsp, 0x08
0000707b885d24fb  jmp 0x0000707B885CFC76
0000707b885d2500  call 0x0000707B883FF430
0000707b885d2505  jmp 0x0000707B885CFC83
0000707b885d250a  sub rsp, 0x08
0000707b885d250e  push rax
0000707b885d250f  push rcx
0000707b885d2510  push rdx
0000707b885d2511  push rdi
0000707b885d2512  push rsi
0000707b885d2513  push r8
0000707b885d2515  push r9
0000707b885d2517  push r10
0000707b885d2519  push r11
0000707b885d251b  sub rsp, 0xF0
0000707b885d2522  vmovaps [rsp], xmm0
0000707b885d2527  vmovaps [rsp+0x10], xmm1
0000707b885d252d  vmovaps [rsp+0x20], xmm2
0000707b885d2533  vmovaps [rsp+0x30], xmm3
0000707b885d2539  vmovaps [rsp+0x40], xmm4
0000707b885d253f  vmovaps [rsp+0x50], xmm5
0000707b885d2545  vmovaps [rsp+0x60], xmm6
0000707b885d254b  vmovaps [rsp+0x70], xmm7
0000707b885d2551  vmovaps [rsp+0x80], xmm8
0000707b885d255a  vmovaps [rsp+0x90], xmm9
0000707b885d2563  vmovaps [rsp+0xA0], xmm10
0000707b885d256c  vmovaps [rsp+0xB0], xmm11
0000707b885d2575  vmovaps [rsp+0xC0], xmm12
0000707b885d257e  vmovaps [rsp+0xD0], xmm13
0000707b885d2587  vmovaps [rsp+0xE0], xmm14
0000707b885d2590  sub rsp, 0x30
0000707b885d2594  movaps [rsp], xmm15
0000707b885d2599  movaps [rsp+0x10], xmm11
0000707b885d259f  movaps [rsp+0x20], xmm1
0000707b885d25a4  lea rdi, [rsp]
0000707b885d25a8  mov esi, 0x00
0000707b885d25ad  mov rax, 0x6471B35AC530
0000707b885d25b7  call rax
0000707b885d25b9  movaps xmm15, [rsp]
0000707b885d25be  add rsp, 0x30
0000707b885d25c2  vmovaps xmm0, [rsp]
0000707b885d25c7  vmovaps xmm1, [rsp+0x10]
0000707b885d25cd  vmovaps xmm2, [rsp+0x20]
0000707b885d25d3  vmovaps xmm3, [rsp+0x30]
0000707b885d25d9  vmovaps xmm4, [rsp+0x40]
0000707b885d25df  vmovaps xmm5, [rsp+0x50]
0000707b885d25e5  vmovaps xmm6, [rsp+0x60]
0000707b885d25eb  vmovaps xmm7, [rsp+0x70]
0000707b885d25f1  vmovaps xmm8, [rsp+0x80]
0000707b885d25fa  vmovaps xmm9, [rsp+0x90]
0000707b885d2603  vmovaps xmm10, [rsp+0xA0]
0000707b885d260c  vmovaps xmm11, [rsp+0xB0]
0000707b885d2615  vmovaps xmm12, [rsp+0xC0]
0000707b885d261e  vmovaps xmm13, [rsp+0xD0]
0000707b885d2627  vmovaps xmm14, [rsp+0xE0]
0000707b885d2630  add rsp, 0xF0
0000707b885d2637  pop r11
0000707b885d2639  pop r10
0000707b885d263b  pop r9
0000707b885d263d  pop r8
0000707b885d263f  pop rsi
0000707b885d2640  pop rdi
0000707b885d2641  pop rdx
0000707b885d2642  pop rcx
0000707b885d2643  pop rax
0000707b885d2644  add rsp, 0x08
0000707b885d2648  jmp 0x0000707B885CFCBC
0000707b885d264d  sub rsp, 0x08
0000707b885d2651  push rax
0000707b885d2652  push rcx
0000707b885d2653  push rdx
0000707b885d2654  push rdi
0000707b885d2655  push rsi
0000707b885d2656  push r8
0000707b885d2658  push r9
0000707b885d265a  push r10
0000707b885d265c  push r11
0000707b885d265e  sub rsp, 0xF0
0000707b885d2665  vmovaps [rsp], xmm0
0000707b885d266a  vmovaps [rsp+0x10], xmm1
0000707b885d2670  vmovaps [rsp+0x20], xmm2
0000707b885d2676  vmovaps [rsp+0x30], xmm3
0000707b885d267c  vmovaps [rsp+0x40], xmm4
0000707b885d2682  vmovaps [rsp+0x50], xmm5
0000707b885d2688  vmovaps [rsp+0x60], xmm6
0000707b885d268e  vmovaps [rsp+0x70], xmm7
0000707b885d2694  vmovaps [rsp+0x80], xmm8
0000707b885d269d  vmovaps [rsp+0x90], xmm9
0000707b885d26a6  vmovaps [rsp+0xA0], xmm10
0000707b885d26af  vmovaps [rsp+0xB0], xmm12
0000707b885d26b8  vmovaps [rsp+0xC0], xmm13
0000707b885d26c1  vmovaps [rsp+0xD0], xmm14
0000707b885d26ca  vmovaps [rsp+0xE0], xmm15
0000707b885d26d3  sub rsp, 0x30
0000707b885d26d7  movaps [rsp], xmm11
0000707b885d26dc  movaps [rsp+0x10], xmm6
0000707b885d26e1  movaps [rsp+0x20], xmm14
0000707b885d26e7  lea rdi, [rsp]
0000707b885d26eb  mov esi, 0x00
0000707b885d26f0  mov rax, 0x6471B35AC530
0000707b885d26fa  call rax
0000707b885d26fc  movaps xmm11, [rsp]
0000707b885d2701  add rsp, 0x30
0000707b885d2705  vmovaps xmm0, [rsp]
0000707b885d270a  vmovaps xmm1, [rsp+0x10]
0000707b885d2710  vmovaps xmm2, [rsp+0x20]
0000707b885d2716  vmovaps xmm3, [rsp+0x30]
0000707b885d271c  vmovaps xmm4, [rsp+0x40]
0000707b885d2722  vmovaps xmm5, [rsp+0x50]
0000707b885d2728  vmovaps xmm6, [rsp+0x60]
0000707b885d272e  vmovaps xmm7, [rsp+0x70]
0000707b885d2734  vmovaps xmm8, [rsp+0x80]
0000707b885d273d  vmovaps xmm9, [rsp+0x90]
0000707b885d2746  vmovaps xmm10, [rsp+0xA0]
0000707b885d274f  vmovaps xmm12, [rsp+0xB0]
0000707b885d2758  vmovaps xmm13, [rsp+0xC0]
0000707b885d2761  vmovaps xmm14, [rsp+0xD0]
0000707b885d276a  vmovaps xmm15, [rsp+0xE0]
0000707b885d2773  add rsp, 0xF0
0000707b885d277a  pop r11
0000707b885d277c  pop r10
0000707b885d277e  pop r9
0000707b885d2780  pop r8
0000707b885d2782  pop rsi
0000707b885d2783  pop rdi
0000707b885d2784  pop rdx
0000707b885d2785  pop rcx
0000707b885d2786  pop rax
0000707b885d2787  add rsp, 0x08
0000707b885d278b  jmp 0x0000707B885CFD34
0000707b885d2790  call 0x0000707B883FF430
0000707b885d2795  jmp 0x0000707B885CFD3E
0000707b885d279a  sub rsp, 0x08
0000707b885d279e  push rax
0000707b885d279f  push rcx
0000707b885d27a0  push rdx
0000707b885d27a1  push rdi
0000707b885d27a2  push rsi
0000707b885d27a3  push r8
0000707b885d27a5  push r9
0000707b885d27a7  push r10
0000707b885d27a9  push r11
0000707b885d27ab  sub rsp, 0xF0
0000707b885d27b2  vmovaps [rsp], xmm0
0000707b885d27b7  vmovaps [rsp+0x10], xmm1
0000707b885d27bd  vmovaps [rsp+0x20], xmm2
0000707b885d27c3  vmovaps [rsp+0x30], xmm3
0000707b885d27c9  vmovaps [rsp+0x40], xmm4
0000707b885d27cf  vmovaps [rsp+0x50], xmm5
0000707b885d27d5  vmovaps [rsp+0x60], xmm6
0000707b885d27db  vmovaps [rsp+0x70], xmm7
0000707b885d27e1  vmovaps [rsp+0x80], xmm8
0000707b885d27ea  vmovaps [rsp+0x90], xmm9
0000707b885d27f3  vmovaps [rsp+0xA0], xmm10
0000707b885d27fc  vmovaps [rsp+0xB0], xmm11
0000707b885d2805  vmovaps [rsp+0xC0], xmm12
0000707b885d280e  vmovaps [rsp+0xD0], xmm13
0000707b885d2817  vmovaps [rsp+0xE0], xmm15
0000707b885d2820  sub rsp, 0x30
0000707b885d2824  movaps [rsp], xmm14
0000707b885d2829  movaps [rsp+0x10], xmm6
0000707b885d282e  movaps [rsp+0x20], xmm2
0000707b885d2833  lea rdi, [rsp]
0000707b885d2837  mov esi, 0x00
0000707b885d283c  mov rax, 0x6471B35AC530
0000707b885d2846  call rax
0000707b885d2848  movaps xmm14, [rsp]
0000707b885d284d  add rsp, 0x30
0000707b885d2851  vmovaps xmm0, [rsp]
0000707b885d2856  vmovaps xmm1, [rsp+0x10]
0000707b885d285c  vmovaps xmm2, [rsp+0x20]
0000707b885d2862  vmovaps xmm3, [rsp+0x30]
0000707b885d2868  vmovaps xmm4, [rsp+0x40]
0000707b885d286e  vmovaps xmm5, [rsp+0x50]
0000707b885d2874  vmovaps xmm6, [rsp+0x60]
0000707b885d287a  vmovaps xmm7, [rsp+0x70]
0000707b885d2880  vmovaps xmm8, [rsp+0x80]
0000707b885d2889  vmovaps xmm9, [rsp+0x90]
0000707b885d2892  vmovaps xmm10, [rsp+0xA0]
0000707b885d289b  vmovaps xmm11, [rsp+0xB0]
0000707b885d28a4  vmovaps xmm12, [rsp+0xC0]
0000707b885d28ad  vmovaps xmm13, [rsp+0xD0]
0000707b885d28b6  vmovaps xmm15, [rsp+0xE0]
0000707b885d28bf  add rsp, 0xF0
0000707b885d28c6  pop r11
0000707b885d28c8  pop r10
0000707b885d28ca  pop r9
0000707b885d28cc  pop r8
0000707b885d28ce  pop rsi
0000707b885d28cf  pop rdi
0000707b885d28d0  pop rdx
0000707b885d28d1  pop rcx
0000707b885d28d2  pop rax
0000707b885d28d3  add rsp, 0x08
0000707b885d28d7  jmp 0x0000707B885CFD72
0000707b885d28dc  sub rsp, 0x08
0000707b885d28e0  push rax
0000707b885d28e1  push rcx
0000707b885d28e2  push rdx
0000707b885d28e3  push rdi
0000707b885d28e4  push rsi
0000707b885d28e5  push r8
0000707b885d28e7  push r9
0000707b885d28e9  push r10
0000707b885d28eb  push r11
0000707b885d28ed  sub rsp, 0xF0
0000707b885d28f4  vmovaps [rsp], xmm0
0000707b885d28f9  vmovaps [rsp+0x10], xmm1
0000707b885d28ff  vmovaps [rsp+0x20], xmm2
0000707b885d2905  vmovaps [rsp+0x30], xmm3
0000707b885d290b  vmovaps [rsp+0x40], xmm4
0000707b885d2911  vmovaps [rsp+0x50], xmm5
0000707b885d2917  vmovaps [rsp+0x60], xmm7
0000707b885d291d  vmovaps [rsp+0x70], xmm8
0000707b885d2923  vmovaps [rsp+0x80], xmm9
0000707b885d292c  vmovaps [rsp+0x90], xmm10
0000707b885d2935  vmovaps [rsp+0xA0], xmm11
0000707b885d293e  vmovaps [rsp+0xB0], xmm12
0000707b885d2947  vmovaps [rsp+0xC0], xmm13
0000707b885d2950  vmovaps [rsp+0xD0], xmm14
0000707b885d2959  vmovaps [rsp+0xE0], xmm15
0000707b885d2962  sub rsp, 0x30
0000707b885d2966  movaps [rsp], xmm6
0000707b885d296a  movaps [rsp+0x10], xmm5
0000707b885d296f  movaps [rsp+0x20], xmm1
0000707b885d2974  lea rdi, [rsp]
0000707b885d2978  mov esi, 0x00
0000707b885d297d  mov rax, 0x6471B35AC530
0000707b885d2987  call rax
0000707b885d2989  movaps xmm6, [rsp]
0000707b885d298d  add rsp, 0x30
0000707b885d2991  vmovaps xmm0, [rsp]
0000707b885d2996  vmovaps xmm1, [rsp+0x10]
0000707b885d299c  vmovaps xmm2, [rsp+0x20]
0000707b885d29a2  vmovaps xmm3, [rsp+0x30]
0000707b885d29a8  vmovaps xmm4, [rsp+0x40]
0000707b885d29ae  vmovaps xmm5, [rsp+0x50]
0000707b885d29b4  vmovaps xmm7, [rsp+0x60]
0000707b885d29ba  vmovaps xmm8, [rsp+0x70]
0000707b885d29c0  vmovaps xmm9, [rsp+0x80]
0000707b885d29c9  vmovaps xmm10, [rsp+0x90]
0000707b885d29d2  vmovaps xmm11, [rsp+0xA0]
0000707b885d29db  vmovaps xmm12, [rsp+0xB0]
0000707b885d29e4  vmovaps xmm13, [rsp+0xC0]
0000707b885d29ed  vmovaps xmm14, [rsp+0xD0]
0000707b885d29f6  vmovaps xmm15, [rsp+0xE0]
0000707b885d29ff  add rsp, 0xF0
0000707b885d2a06  pop r11
0000707b885d2a08  pop r10
0000707b885d2a0a  pop r9
0000707b885d2a0c  pop r8
0000707b885d2a0e  pop rsi
0000707b885d2a0f  pop rdi
0000707b885d2a10  pop rdx
0000707b885d2a11  pop rcx
0000707b885d2a12  pop rax
0000707b885d2a13  add rsp, 0x08
0000707b885d2a17  jmp 0x0000707B885CFD98
0000707b885d2a1c  sub rsp, 0x08
0000707b885d2a20  push rax
0000707b885d2a21  push rcx
0000707b885d2a22  push rdx
0000707b885d2a23  push rdi
0000707b885d2a24  push rsi
0000707b885d2a25  push r8
0000707b885d2a27  push r9
0000707b885d2a29  push r10
0000707b885d2a2b  push r11
0000707b885d2a2d  sub rsp, 0xF0
0000707b885d2a34  vmovaps [rsp], xmm0
0000707b885d2a39  vmovaps [rsp+0x10], xmm2
0000707b885d2a3f  vmovaps [rsp+0x20], xmm3
0000707b885d2a45  vmovaps [rsp+0x30], xmm4
0000707b885d2a4b  vmovaps [rsp+0x40], xmm5
0000707b885d2a51  vmovaps [rsp+0x50], xmm6
0000707b885d2a57  vmovaps [rsp+0x60], xmm7
0000707b885d2a5d  vmovaps [rsp+0x70], xmm8
0000707b885d2a63  vmovaps [rsp+0x80], xmm9
0000707b885d2a6c  vmovaps [rsp+0x90], xmm10
0000707b885d2a75  vmovaps [rsp+0xA0], xmm11
0000707b885d2a7e  vmovaps [rsp+0xB0], xmm12
0000707b885d2a87  vmovaps [rsp+0xC0], xmm13
0000707b885d2a90  vmovaps [rsp+0xD0], xmm14
0000707b885d2a99  vmovaps [rsp+0xE0], xmm15
0000707b885d2aa2  sub rsp, 0x30
0000707b885d2aa6  movaps [rsp], xmm1
0000707b885d2aaa  movaps [rsp+0x10], xmm5
0000707b885d2aaf  movaps [rsp+0x20], xmm13
0000707b885d2ab5  lea rdi, [rsp]
0000707b885d2ab9  mov esi, 0x00
0000707b885d2abe  mov rax, 0x6471B35AC530
0000707b885d2ac8  call rax
0000707b885d2aca  movaps xmm1, [rsp]
0000707b885d2ace  add rsp, 0x30
0000707b885d2ad2  vmovaps xmm0, [rsp]
0000707b885d2ad7  vmovaps xmm2, [rsp+0x10]
0000707b885d2add  vmovaps xmm3, [rsp+0x20]
0000707b885d2ae3  vmovaps xmm4, [rsp+0x30]
0000707b885d2ae9  vmovaps xmm5, [rsp+0x40]
0000707b885d2aef  vmovaps xmm6, [rsp+0x50]
0000707b885d2af5  vmovaps xmm7, [rsp+0x60]
0000707b885d2afb  vmovaps xmm8, [rsp+0x70]
0000707b885d2b01  vmovaps xmm9, [rsp+0x80]
0000707b885d2b0a  vmovaps xmm10, [rsp+0x90]
0000707b885d2b13  vmovaps xmm11, [rsp+0xA0]
0000707b885d2b1c  vmovaps xmm12, [rsp+0xB0]
0000707b885d2b25  vmovaps xmm13, [rsp+0xC0]
0000707b885d2b2e  vmovaps xmm14, [rsp+0xD0]
0000707b885d2b37  vmovaps xmm15, [rsp+0xE0]
0000707b885d2b40  add rsp, 0xF0
0000707b885d2b47  pop r11
0000707b885d2b49  pop r10
0000707b885d2b4b  pop r9
0000707b885d2b4d  pop r8
0000707b885d2b4f  pop rsi
0000707b885d2b50  pop rdi
0000707b885d2b51  pop rdx
0000707b885d2b52  pop rcx
0000707b885d2b53  pop rax
0000707b885d2b54  add rsp, 0x08
0000707b885d2b58  jmp 0x0000707B885CFDB6
0000707b885d2b5d  sub rsp, 0x08
0000707b885d2b61  push rax
0000707b885d2b62  push rcx
0000707b885d2b63  push rdx
0000707b885d2b64  push rdi
0000707b885d2b65  push rsi
0000707b885d2b66  push r8
0000707b885d2b68  push r9
0000707b885d2b6a  push r10
0000707b885d2b6c  push r11
0000707b885d2b6e  sub rsp, 0xF0
0000707b885d2b75  vmovaps [rsp], xmm0
0000707b885d2b7a  vmovaps [rsp+0x10], xmm1
0000707b885d2b80  vmovaps [rsp+0x20], xmm2
0000707b885d2b86  vmovaps [rsp+0x30], xmm3
0000707b885d2b8c  vmovaps [rsp+0x40], xmm4
0000707b885d2b92  vmovaps [rsp+0x50], xmm6
0000707b885d2b98  vmovaps [rsp+0x60], xmm7
0000707b885d2b9e  vmovaps [rsp+0x70], xmm8
0000707b885d2ba4  vmovaps [rsp+0x80], xmm9
0000707b885d2bad  vmovaps [rsp+0x90], xmm10
0000707b885d2bb6  vmovaps [rsp+0xA0], xmm11
0000707b885d2bbf  vmovaps [rsp+0xB0], xmm12
0000707b885d2bc8  vmovaps [rsp+0xC0], xmm13
0000707b885d2bd1  vmovaps [rsp+0xD0], xmm14
0000707b885d2bda  vmovaps [rsp+0xE0], xmm15
0000707b885d2be3  sub rsp, 0x30
0000707b885d2be7  movaps [rsp], xmm5
0000707b885d2beb  movaps [rsp+0x10], xmm2
0000707b885d2bf0  movaps [rsp+0x20], xmm13
0000707b885d2bf6  lea rdi, [rsp]
0000707b885d2bfa  mov esi, 0x00
0000707b885d2bff  mov rax, 0x6471B35AC530
0000707b885d2c09  call rax
0000707b885d2c0b  movaps xmm5, [rsp]
0000707b885d2c0f  add rsp, 0x30
0000707b885d2c13  vmovaps xmm0, [rsp]
0000707b885d2c18  vmovaps xmm1, [rsp+0x10]
0000707b885d2c1e  vmovaps xmm2, [rsp+0x20]
0000707b885d2c24  vmovaps xmm3, [rsp+0x30]
0000707b885d2c2a  vmovaps xmm4, [rsp+0x40]
0000707b885d2c30  vmovaps xmm6, [rsp+0x50]
0000707b885d2c36  vmovaps xmm7, [rsp+0x60]
0000707b885d2c3c  vmovaps xmm8, [rsp+0x70]
0000707b885d2c42  vmovaps xmm9, [rsp+0x80]
0000707b885d2c4b  vmovaps xmm10, [rsp+0x90]
0000707b885d2c54  vmovaps xmm11, [rsp+0xA0]
0000707b885d2c5d  vmovaps xmm12, [rsp+0xB0]
0000707b885d2c66  vmovaps xmm13, [rsp+0xC0]
0000707b885d2c6f  vmovaps xmm14, [rsp+0xD0]
0000707b885d2c78  vmovaps xmm15, [rsp+0xE0]
0000707b885d2c81  add rsp, 0xF0
0000707b885d2c88  pop r11
0000707b885d2c8a  pop r10
0000707b885d2c8c  pop r9
0000707b885d2c8e  pop r8
0000707b885d2c90  pop rsi
0000707b885d2c91  pop rdi
0000707b885d2c92  pop rdx
0000707b885d2c93  pop rcx
0000707b885d2c94  pop rax
0000707b885d2c95  add rsp, 0x08
0000707b885d2c99  jmp 0x0000707B885CFDEC
0000707b885d2c9e  sub rsp, 0x08
0000707b885d2ca2  push rax
0000707b885d2ca3  push rcx
0000707b885d2ca4  push rdx
0000707b885d2ca5  push rdi
0000707b885d2ca6  push rsi
0000707b885d2ca7  push r8
0000707b885d2ca9  push r9
0000707b885d2cab  push r10
0000707b885d2cad  push r11
0000707b885d2caf  sub rsp, 0xF0
0000707b885d2cb6  vmovaps [rsp], xmm0
0000707b885d2cbb  vmovaps [rsp+0x10], xmm1
0000707b885d2cc1  vmovaps [rsp+0x20], xmm2
0000707b885d2cc7  vmovaps [rsp+0x30], xmm3
0000707b885d2ccd  vmovaps [rsp+0x40], xmm4
0000707b885d2cd3  vmovaps [rsp+0x50], xmm5
0000707b885d2cd9  vmovaps [rsp+0x60], xmm6
0000707b885d2cdf  vmovaps [rsp+0x70], xmm7
0000707b885d2ce5  vmovaps [rsp+0x80], xmm8
0000707b885d2cee  vmovaps [rsp+0x90], xmm9
0000707b885d2cf7  vmovaps [rsp+0xA0], xmm10
0000707b885d2d00  vmovaps [rsp+0xB0], xmm11
0000707b885d2d09  vmovaps [rsp+0xC0], xmm12
0000707b885d2d12  vmovaps [rsp+0xD0], xmm14
0000707b885d2d1b  vmovaps [rsp+0xE0], xmm15
0000707b885d2d24  sub rsp, 0x30
0000707b885d2d28  movaps [rsp], xmm13
0000707b885d2d2d  movaps [rsp+0x10], xmm10
0000707b885d2d33  movaps [rsp+0x20], xmm1
0000707b885d2d38  lea rdi, [rsp]
0000707b885d2d3c  mov esi, 0x00
0000707b885d2d41  mov rax, 0x6471B35AC530
0000707b885d2d4b  call rax
0000707b885d2d4d  movaps xmm13, [rsp]
0000707b885d2d52  add rsp, 0x30
0000707b885d2d56  vmovaps xmm0, [rsp]
0000707b885d2d5b  vmovaps xmm1, [rsp+0x10]
0000707b885d2d61  vmovaps xmm2, [rsp+0x20]
0000707b885d2d67  vmovaps xmm3, [rsp+0x30]
0000707b885d2d6d  vmovaps xmm4, [rsp+0x40]
0000707b885d2d73  vmovaps xmm5, [rsp+0x50]
0000707b885d2d79  vmovaps xmm6, [rsp+0x60]
0000707b885d2d7f  vmovaps xmm7, [rsp+0x70]
0000707b885d2d85  vmovaps xmm8, [rsp+0x80]
0000707b885d2d8e  vmovaps xmm9, [rsp+0x90]
0000707b885d2d97  vmovaps xmm10, [rsp+0xA0]
0000707b885d2da0  vmovaps xmm11, [rsp+0xB0]
0000707b885d2da9  vmovaps xmm12, [rsp+0xC0]
0000707b885d2db2  vmovaps xmm14, [rsp+0xD0]
0000707b885d2dbb  vmovaps xmm15, [rsp+0xE0]
0000707b885d2dc4  add rsp, 0xF0
0000707b885d2dcb  pop r11
0000707b885d2dcd  pop r10
0000707b885d2dcf  pop r9
0000707b885d2dd1  pop r8
0000707b885d2dd3  pop rsi
0000707b885d2dd4  pop rdi
0000707b885d2dd5  pop rdx
0000707b885d2dd6  pop rcx
0000707b885d2dd7  pop rax
0000707b885d2dd8  add rsp, 0x08
0000707b885d2ddc  jmp 0x0000707B885CFE15
0000707b885d2de1  sub rsp, 0x08
0000707b885d2de5  push rax
0000707b885d2de6  push rcx
0000707b885d2de7  push rdx
0000707b885d2de8  push rdi
0000707b885d2de9  push rsi
0000707b885d2dea  push r8
0000707b885d2dec  push r9
0000707b885d2dee  push r10
0000707b885d2df0  push r11
0000707b885d2df2  sub rsp, 0xF0
0000707b885d2df9  vmovaps [rsp], xmm0
0000707b885d2dfe  vmovaps [rsp+0x10], xmm2
0000707b885d2e04  vmovaps [rsp+0x20], xmm3
0000707b885d2e0a  vmovaps [rsp+0x30], xmm4
0000707b885d2e10  vmovaps [rsp+0x40], xmm5
0000707b885d2e16  vmovaps [rsp+0x50], xmm6
0000707b885d2e1c  vmovaps [rsp+0x60], xmm7
0000707b885d2e22  vmovaps [rsp+0x70], xmm8
0000707b885d2e28  vmovaps [rsp+0x80], xmm9
0000707b885d2e31  vmovaps [rsp+0x90], xmm10
0000707b885d2e3a  vmovaps [rsp+0xA0], xmm11
0000707b885d2e43  vmovaps [rsp+0xB0], xmm12
0000707b885d2e4c  vmovaps [rsp+0xC0], xmm13
0000707b885d2e55  vmovaps [rsp+0xD0], xmm14
0000707b885d2e5e  vmovaps [rsp+0xE0], xmm15
0000707b885d2e67  sub rsp, 0x30
0000707b885d2e6b  movaps [rsp], xmm1
0000707b885d2e6f  movaps [rsp+0x10], xmm15
0000707b885d2e75  movaps [rsp+0x20], xmm10
0000707b885d2e7b  lea rdi, [rsp]
0000707b885d2e7f  mov esi, 0x00
0000707b885d2e84  mov rax, 0x6471B35AC530
0000707b885d2e8e  call rax
0000707b885d2e90  movaps xmm1, [rsp]
0000707b885d2e94  add rsp, 0x30
0000707b885d2e98  vmovaps xmm0, [rsp]
0000707b885d2e9d  vmovaps xmm2, [rsp+0x10]
0000707b885d2ea3  vmovaps xmm3, [rsp+0x20]
0000707b885d2ea9  vmovaps xmm4, [rsp+0x30]
0000707b885d2eaf  vmovaps xmm5, [rsp+0x40]
0000707b885d2eb5  vmovaps xmm6, [rsp+0x50]
0000707b885d2ebb  vmovaps xmm7, [rsp+0x60]
0000707b885d2ec1  vmovaps xmm8, [rsp+0x70]
0000707b885d2ec7  vmovaps xmm9, [rsp+0x80]
0000707b885d2ed0  vmovaps xmm10, [rsp+0x90]
0000707b885d2ed9  vmovaps xmm11, [rsp+0xA0]
0000707b885d2ee2  vmovaps xmm12, [rsp+0xB0]
0000707b885d2eeb  vmovaps xmm13, [rsp+0xC0]
0000707b885d2ef4  vmovaps xmm14, [rsp+0xD0]
0000707b885d2efd  vmovaps xmm15, [rsp+0xE0]
0000707b885d2f06  add rsp, 0xF0
0000707b885d2f0d  pop r11
0000707b885d2f0f  pop r10
0000707b885d2f11  pop r9
0000707b885d2f13  pop r8
0000707b885d2f15  pop rsi
0000707b885d2f16  pop rdi
0000707b885d2f17  pop rdx
0000707b885d2f18  pop rcx
0000707b885d2f19  pop rax
0000707b885d2f1a  add rsp, 0x08
0000707b885d2f1e  jmp 0x0000707B885CFE34
0000707b885d2f23  sub rsp, 0x08
0000707b885d2f27  push rax
0000707b885d2f28  push rcx
0000707b885d2f29  push rdx
0000707b885d2f2a  push rdi
0000707b885d2f2b  push rsi
0000707b885d2f2c  push r8
0000707b885d2f2e  push r9
0000707b885d2f30  push r10
0000707b885d2f32  push r11
0000707b885d2f34  sub rsp, 0xF0
0000707b885d2f3b  vmovaps [rsp], xmm0
0000707b885d2f40  vmovaps [rsp+0x10], xmm1
0000707b885d2f46  vmovaps [rsp+0x20], xmm2
0000707b885d2f4c  vmovaps [rsp+0x30], xmm3
0000707b885d2f52  vmovaps [rsp+0x40], xmm4
0000707b885d2f58  vmovaps [rsp+0x50], xmm5
0000707b885d2f5e  vmovaps [rsp+0x60], xmm6
0000707b885d2f64  vmovaps [rsp+0x70], xmm7
0000707b885d2f6a  vmovaps [rsp+0x80], xmm8
0000707b885d2f73  vmovaps [rsp+0x90], xmm9
0000707b885d2f7c  vmovaps [rsp+0xA0], xmm10
0000707b885d2f85  vmovaps [rsp+0xB0], xmm11
0000707b885d2f8e  vmovaps [rsp+0xC0], xmm12
0000707b885d2f97  vmovaps [rsp+0xD0], xmm13
0000707b885d2fa0  vmovaps [rsp+0xE0], xmm14
0000707b885d2fa9  sub rsp, 0x30
0000707b885d2fad  movaps [rsp], xmm15
0000707b885d2fb2  movaps [rsp+0x10], xmm10
0000707b885d2fb8  movaps [rsp+0x20], xmm11
0000707b885d2fbe  lea rdi, [rsp]
0000707b885d2fc2  mov esi, 0x00
0000707b885d2fc7  mov rax, 0x6471B35AC530
0000707b885d2fd1  call rax
0000707b885d2fd3  movaps xmm15, [rsp]
0000707b885d2fd8  add rsp, 0x30
0000707b885d2fdc  vmovaps xmm0, [rsp]
0000707b885d2fe1  vmovaps xmm1, [rsp+0x10]
0000707b885d2fe7  vmovaps xmm2, [rsp+0x20]
0000707b885d2fed  vmovaps xmm3, [rsp+0x30]
0000707b885d2ff3  vmovaps xmm4, [rsp+0x40]
0000707b885d2ff9  vmovaps xmm5, [rsp+0x50]
0000707b885d2fff  vmovaps xmm6, [rsp+0x60]
0000707b885d3005  vmovaps xmm7, [rsp+0x70]
0000707b885d300b  vmovaps xmm8, [rsp+0x80]
0000707b885d3014  vmovaps xmm9, [rsp+0x90]
0000707b885d301d  vmovaps xmm10, [rsp+0xA0]
0000707b885d3026  vmovaps xmm11, [rsp+0xB0]
0000707b885d302f  vmovaps xmm12, [rsp+0xC0]
0000707b885d3038  vmovaps xmm13, [rsp+0xD0]
0000707b885d3041  vmovaps xmm14, [rsp+0xE0]
0000707b885d304a  add rsp, 0xF0
0000707b885d3051  pop r11
0000707b885d3053  pop r10
0000707b885d3055  pop r9
0000707b885d3057  pop r8
0000707b885d3059  pop rsi
0000707b885d305a  pop rdi
0000707b885d305b  pop rdx
0000707b885d305c  pop rcx
0000707b885d305d  pop rax
0000707b885d305e  add rsp, 0x08
0000707b885d3062  jmp 0x0000707B885CFE57
0000707b885d3067  sub rsp, 0x08
0000707b885d306b  push rax
0000707b885d306c  push rcx
0000707b885d306d  push rdx
0000707b885d306e  push rdi
0000707b885d306f  push rsi
0000707b885d3070  push r8
0000707b885d3072  push r9
0000707b885d3074  push r10
0000707b885d3076  push r11
0000707b885d3078  sub rsp, 0xF0
0000707b885d307f  vmovaps [rsp], xmm0
0000707b885d3084  vmovaps [rsp+0x10], xmm1
0000707b885d308a  vmovaps [rsp+0x20], xmm2
0000707b885d3090  vmovaps [rsp+0x30], xmm3
0000707b885d3096  vmovaps [rsp+0x40], xmm4
0000707b885d309c  vmovaps [rsp+0x50], xmm5
0000707b885d30a2  vmovaps [rsp+0x60], xmm6
0000707b885d30a8  vmovaps [rsp+0x70], xmm7
0000707b885d30ae  vmovaps [rsp+0x80], xmm8
0000707b885d30b7  vmovaps [rsp+0x90], xmm9
0000707b885d30c0  vmovaps [rsp+0xA0], xmm11
0000707b885d30c9  vmovaps [rsp+0xB0], xmm12
0000707b885d30d2  vmovaps [rsp+0xC0], xmm13
0000707b885d30db  vmovaps [rsp+0xD0], xmm14
0000707b885d30e4  vmovaps [rsp+0xE0], xmm15
0000707b885d30ed  sub rsp, 0x30
0000707b885d30f1  movaps [rsp], xmm10
0000707b885d30f6  movaps [rsp+0x10], xmm12
0000707b885d30fc  movaps [rsp+0x20], xmm11
0000707b885d3102  lea rdi, [rsp]
0000707b885d3106  mov esi, 0x00
0000707b885d310b  mov rax, 0x6471B35AC530
0000707b885d3115  call rax
0000707b885d3117  movaps xmm10, [rsp]
0000707b885d311c  add rsp, 0x30
0000707b885d3120  vmovaps xmm0, [rsp]
0000707b885d3125  vmovaps xmm1, [rsp+0x10]
0000707b885d312b  vmovaps xmm2, [rsp+0x20]
0000707b885d3131  vmovaps xmm3, [rsp+0x30]
0000707b885d3137  vmovaps xmm4, [rsp+0x40]
0000707b885d313d  vmovaps xmm5, [rsp+0x50]
0000707b885d3143  vmovaps xmm6, [rsp+0x60]
0000707b885d3149  vmovaps xmm7, [rsp+0x70]
0000707b885d314f  vmovaps xmm8, [rsp+0x80]
0000707b885d3158  vmovaps xmm9, [rsp+0x90]
0000707b885d3161  vmovaps xmm11, [rsp+0xA0]
0000707b885d316a  vmovaps xmm12, [rsp+0xB0]
0000707b885d3173  vmovaps xmm13, [rsp+0xC0]
0000707b885d317c  vmovaps xmm14, [rsp+0xD0]
0000707b885d3185  vmovaps xmm15, [rsp+0xE0]
0000707b885d318e  add rsp, 0xF0
0000707b885d3195  pop r11
0000707b885d3197  pop r10
0000707b885d3199  pop r9
0000707b885d319b  pop r8
0000707b885d319d  pop rsi
0000707b885d319e  pop rdi
0000707b885d319f  pop rdx
0000707b885d31a0  pop rcx
0000707b885d31a1  pop rax
0000707b885d31a2  add rsp, 0x08
0000707b885d31a6  jmp 0x0000707B885CFE80
0000707b885d31ab  sub rsp, 0x08
0000707b885d31af  push rax
0000707b885d31b0  push rcx
0000707b885d31b1  push rdx
0000707b885d31b2  push rdi
0000707b885d31b3  push rsi
0000707b885d31b4  push r8
0000707b885d31b6  push r9
0000707b885d31b8  push r10
0000707b885d31ba  push r11
0000707b885d31bc  sub rsp, 0xF0
0000707b885d31c3  vmovaps [rsp], xmm0
0000707b885d31c8  vmovaps [rsp+0x10], xmm1
0000707b885d31ce  vmovaps [rsp+0x20], xmm2
0000707b885d31d4  vmovaps [rsp+0x30], xmm3
0000707b885d31da  vmovaps [rsp+0x40], xmm4
0000707b885d31e0  vmovaps [rsp+0x50], xmm5
0000707b885d31e6  vmovaps [rsp+0x60], xmm6
0000707b885d31ec  vmovaps [rsp+0x70], xmm7
0000707b885d31f2  vmovaps [rsp+0x80], xmm8
0000707b885d31fb  vmovaps [rsp+0x90], xmm9
0000707b885d3204  vmovaps [rsp+0xA0], xmm10
0000707b885d320d  vmovaps [rsp+0xB0], xmm12
0000707b885d3216  vmovaps [rsp+0xC0], xmm13
0000707b885d321f  vmovaps [rsp+0xD0], xmm14
0000707b885d3228  vmovaps [rsp+0xE0], xmm15
0000707b885d3231  sub rsp, 0x30
0000707b885d3235  movaps [rsp], xmm11
0000707b885d323a  movaps [rsp+0x10], xmm2
0000707b885d323f  movaps [rsp+0x20], xmm12
0000707b885d3245  lea rdi, [rsp]
0000707b885d3249  mov esi, 0x00
0000707b885d324e  mov rax, 0x6471B35AC530
0000707b885d3258  call rax
0000707b885d325a  movaps xmm11, [rsp]
0000707b885d325f  add rsp, 0x30
0000707b885d3263  vmovaps xmm0, [rsp]
0000707b885d3268  vmovaps xmm1, [rsp+0x10]
0000707b885d326e  vmovaps xmm2, [rsp+0x20]
0000707b885d3274  vmovaps xmm3, [rsp+0x30]
0000707b885d327a  vmovaps xmm4, [rsp+0x40]
0000707b885d3280  vmovaps xmm5, [rsp+0x50]
0000707b885d3286  vmovaps xmm6, [rsp+0x60]
0000707b885d328c  vmovaps xmm7, [rsp+0x70]
0000707b885d3292  vmovaps xmm8, [rsp+0x80]
0000707b885d329b  vmovaps xmm9, [rsp+0x90]
0000707b885d32a4  vmovaps xmm10, [rsp+0xA0]
0000707b885d32ad  vmovaps xmm12, [rsp+0xB0]
0000707b885d32b6  vmovaps xmm13, [rsp+0xC0]
0000707b885d32bf  vmovaps xmm14, [rsp+0xD0]
0000707b885d32c8  vmovaps xmm15, [rsp+0xE0]
0000707b885d32d1  add rsp, 0xF0
0000707b885d32d8  pop r11
0000707b885d32da  pop r10
0000707b885d32dc  pop r9
0000707b885d32de  pop r8
0000707b885d32e0  pop rsi
0000707b885d32e1  pop rdi
0000707b885d32e2  pop rdx
0000707b885d32e3  pop rcx
0000707b885d32e4  pop rax
0000707b885d32e5  add rsp, 0x08
0000707b885d32e9  jmp 0x0000707B885CFEB8
0000707b885d32ee  sub rsp, 0x08
0000707b885d32f2  push rax
0000707b885d32f3  push rcx
0000707b885d32f4  push rdx
0000707b885d32f5  push rdi
0000707b885d32f6  push rsi
0000707b885d32f7  push r8
0000707b885d32f9  push r9
0000707b885d32fb  push r10
0000707b885d32fd  push r11
0000707b885d32ff  sub rsp, 0xF0
0000707b885d3306  vmovaps [rsp], xmm0
0000707b885d330b  vmovaps [rsp+0x10], xmm2
0000707b885d3311  vmovaps [rsp+0x20], xmm3
0000707b885d3317  vmovaps [rsp+0x30], xmm4
0000707b885d331d  vmovaps [rsp+0x40], xmm5
0000707b885d3323  vmovaps [rsp+0x50], xmm6
0000707b885d3329  vmovaps [rsp+0x60], xmm7
0000707b885d332f  vmovaps [rsp+0x70], xmm8
0000707b885d3335  vmovaps [rsp+0x80], xmm9
0000707b885d333e  vmovaps [rsp+0x90], xmm10
0000707b885d3347  vmovaps [rsp+0xA0], xmm11
0000707b885d3350  vmovaps [rsp+0xB0], xmm12
0000707b885d3359  vmovaps [rsp+0xC0], xmm13
0000707b885d3362  vmovaps [rsp+0xD0], xmm14
0000707b885d336b  vmovaps [rsp+0xE0], xmm15
0000707b885d3374  sub rsp, 0x30
0000707b885d3378  movaps [rsp], xmm1
0000707b885d337c  movaps [rsp+0x10], xmm14
0000707b885d3382  movaps [rsp+0x20], xmm6
0000707b885d3387  lea rdi, [rsp]
0000707b885d338b  mov esi, 0x00
0000707b885d3390  mov rax, 0x6471B35AC530
0000707b885d339a  call rax
0000707b885d339c  movaps xmm1, [rsp]
0000707b885d33a0  add rsp, 0x30
0000707b885d33a4  vmovaps xmm0, [rsp]
0000707b885d33a9  vmovaps xmm2, [rsp+0x10]
0000707b885d33af  vmovaps xmm3, [rsp+0x20]
0000707b885d33b5  vmovaps xmm4, [rsp+0x30]
0000707b885d33bb  vmovaps xmm5, [rsp+0x40]
0000707b885d33c1  vmovaps xmm6, [rsp+0x50]
0000707b885d33c7  vmovaps xmm7, [rsp+0x60]
0000707b885d33cd  vmovaps xmm8, [rsp+0x70]
0000707b885d33d3  vmovaps xmm9, [rsp+0x80]
0000707b885d33dc  vmovaps xmm10, [rsp+0x90]
0000707b885d33e5  vmovaps xmm11, [rsp+0xA0]
0000707b885d33ee  vmovaps xmm12, [rsp+0xB0]
0000707b885d33f7  vmovaps xmm13, [rsp+0xC0]
0000707b885d3400  vmovaps xmm14, [rsp+0xD0]
0000707b885d3409  vmovaps xmm15, [rsp+0xE0]
0000707b885d3412  add rsp, 0xF0
0000707b885d3419  pop r11
0000707b885d341b  pop r10
0000707b885d341d  pop r9
0000707b885d341f  pop r8
0000707b885d3421  pop rsi
0000707b885d3422  pop rdi
0000707b885d3423  pop rdx
0000707b885d3424  pop rcx
0000707b885d3425  pop rax
0000707b885d3426  add rsp, 0x08
0000707b885d342a  jmp 0x0000707B885CFED1
0000707b885d342f  sub rsp, 0x08
0000707b885d3433  push rax
0000707b885d3434  push rcx
0000707b885d3435  push rdx
0000707b885d3436  push rdi
0000707b885d3437  push rsi
0000707b885d3438  push r8
0000707b885d343a  push r9
0000707b885d343c  push r10
0000707b885d343e  push r11
0000707b885d3440  sub rsp, 0xF0
0000707b885d3447  vmovaps [rsp], xmm0
0000707b885d344c  vmovaps [rsp+0x10], xmm1
0000707b885d3452  vmovaps [rsp+0x20], xmm2
0000707b885d3458  vmovaps [rsp+0x30], xmm3
0000707b885d345e  vmovaps [rsp+0x40], xmm4
0000707b885d3464  vmovaps [rsp+0x50], xmm5
0000707b885d346a  vmovaps [rsp+0x60], xmm6
0000707b885d3470  vmovaps [rsp+0x70], xmm7
0000707b885d3476  vmovaps [rsp+0x80], xmm8
0000707b885d347f  vmovaps [rsp+0x90], xmm9
0000707b885d3488  vmovaps [rsp+0xA0], xmm10
0000707b885d3491  vmovaps [rsp+0xB0], xmm11
0000707b885d349a  vmovaps [rsp+0xC0], xmm12
0000707b885d34a3  vmovaps [rsp+0xD0], xmm13
0000707b885d34ac  vmovaps [rsp+0xE0], xmm15
0000707b885d34b5  sub rsp, 0x30
0000707b885d34b9  movaps [rsp], xmm14
0000707b885d34be  movaps [rsp+0x10], xmm12
0000707b885d34c4  movaps [rsp+0x20], xmm5
0000707b885d34c9  lea rdi, [rsp]
0000707b885d34cd  mov esi, 0x00
0000707b885d34d2  mov rax, 0x6471B35AC530
0000707b885d34dc  call rax
0000707b885d34de  movaps xmm14, [rsp]
0000707b885d34e3  add rsp, 0x30
0000707b885d34e7  vmovaps xmm0, [rsp]
0000707b885d34ec  vmovaps xmm1, [rsp+0x10]
0000707b885d34f2  vmovaps xmm2, [rsp+0x20]
0000707b885d34f8  vmovaps xmm3, [rsp+0x30]
0000707b885d34fe  vmovaps xmm4, [rsp+0x40]
0000707b885d3504  vmovaps xmm5, [rsp+0x50]
0000707b885d350a  vmovaps xmm6, [rsp+0x60]
0000707b885d3510  vmovaps xmm7, [rsp+0x70]
0000707b885d3516  vmovaps xmm8, [rsp+0x80]
0000707b885d351f  vmovaps xmm9, [rsp+0x90]
0000707b885d3528  vmovaps xmm10, [rsp+0xA0]
0000707b885d3531  vmovaps xmm11, [rsp+0xB0]
0000707b885d353a  vmovaps xmm12, [rsp+0xC0]
0000707b885d3543  vmovaps xmm13, [rsp+0xD0]
0000707b885d354c  vmovaps xmm15, [rsp+0xE0]
0000707b885d3555  add rsp, 0xF0
0000707b885d355c  pop r11
0000707b885d355e  pop r10
0000707b885d3560  pop r9
0000707b885d3562  pop r8
0000707b885d3564  pop rsi
0000707b885d3565  pop rdi
0000707b885d3566  pop rdx
0000707b885d3567  pop rcx
0000707b885d3568  pop rax
0000707b885d3569  add rsp, 0x08
0000707b885d356d  jmp 0x0000707B885CFEF1
0000707b885d3572  sub rsp, 0x08
0000707b885d3576  push rax
0000707b885d3577  push rcx
0000707b885d3578  push rdx
0000707b885d3579  push rdi
0000707b885d357a  push rsi
0000707b885d357b  push r8
0000707b885d357d  push r9
0000707b885d357f  push r10
0000707b885d3581  push r11
0000707b885d3583  sub rsp, 0xF0
0000707b885d358a  vmovaps [rsp], xmm0
0000707b885d358f  vmovaps [rsp+0x10], xmm1
0000707b885d3595  vmovaps [rsp+0x20], xmm2
0000707b885d359b  vmovaps [rsp+0x30], xmm3
0000707b885d35a1  vmovaps [rsp+0x40], xmm4
0000707b885d35a7  vmovaps [rsp+0x50], xmm5
0000707b885d35ad  vmovaps [rsp+0x60], xmm7
0000707b885d35b3  vmovaps [rsp+0x70], xmm8
0000707b885d35b9  vmovaps [rsp+0x80], xmm9
0000707b885d35c2  vmovaps [rsp+0x90], xmm10
0000707b885d35cb  vmovaps [rsp+0xA0], xmm11
0000707b885d35d4  vmovaps [rsp+0xB0], xmm12
0000707b885d35dd  vmovaps [rsp+0xC0], xmm13
0000707b885d35e6  vmovaps [rsp+0xD0], xmm14
0000707b885d35ef  vmovaps [rsp+0xE0], xmm15
0000707b885d35f8  sub rsp, 0x30
0000707b885d35fc  movaps [rsp], xmm6
0000707b885d3600  movaps [rsp+0x10], xmm9
0000707b885d3606  movaps [rsp+0x20], xmm12
0000707b885d360c  lea rdi, [rsp]
0000707b885d3610  mov esi, 0x00
0000707b885d3615  mov rax, 0x6471B35AC530
0000707b885d361f  call rax
0000707b885d3621  movaps xmm6, [rsp]
0000707b885d3625  add rsp, 0x30
0000707b885d3629  vmovaps xmm0, [rsp]
0000707b885d362e  vmovaps xmm1, [rsp+0x10]
0000707b885d3634  vmovaps xmm2, [rsp+0x20]
0000707b885d363a  vmovaps xmm3, [rsp+0x30]
0000707b885d3640  vmovaps xmm4, [rsp+0x40]
0000707b885d3646  vmovaps xmm5, [rsp+0x50]
0000707b885d364c  vmovaps xmm7, [rsp+0x60]
0000707b885d3652  vmovaps xmm8, [rsp+0x70]
0000707b885d3658  vmovaps xmm9, [rsp+0x80]
0000707b885d3661  vmovaps xmm10, [rsp+0x90]
0000707b885d366a  vmovaps xmm11, [rsp+0xA0]
0000707b885d3673  vmovaps xmm12, [rsp+0xB0]
0000707b885d367c  vmovaps xmm13, [rsp+0xC0]
0000707b885d3685  vmovaps xmm14, [rsp+0xD0]
0000707b885d368e  vmovaps xmm15, [rsp+0xE0]
0000707b885d3697  add rsp, 0xF0
0000707b885d369e  pop r11
0000707b885d36a0  pop r10
0000707b885d36a2  pop r9
0000707b885d36a4  pop r8
0000707b885d36a6  pop rsi
0000707b885d36a7  pop rdi
0000707b885d36a8  pop rdx
0000707b885d36a9  pop rcx
0000707b885d36aa  pop rax
0000707b885d36ab  add rsp, 0x08
0000707b885d36af  jmp 0x0000707B885CFF19
0000707b885d36b4  sub rsp, 0x08
0000707b885d36b8  push rax
0000707b885d36b9  push rcx
0000707b885d36ba  push rdx
0000707b885d36bb  push rdi
0000707b885d36bc  push rsi
0000707b885d36bd  push r8
0000707b885d36bf  push r9
0000707b885d36c1  push r10
0000707b885d36c3  push r11
0000707b885d36c5  sub rsp, 0xF0
0000707b885d36cc  vmovaps [rsp], xmm0
0000707b885d36d1  vmovaps [rsp+0x10], xmm1
0000707b885d36d7  vmovaps [rsp+0x20], xmm2
0000707b885d36dd  vmovaps [rsp+0x30], xmm3
0000707b885d36e3  vmovaps [rsp+0x40], xmm4
0000707b885d36e9  vmovaps [rsp+0x50], xmm5
0000707b885d36ef  vmovaps [rsp+0x60], xmm6
0000707b885d36f5  vmovaps [rsp+0x70], xmm7
0000707b885d36fb  vmovaps [rsp+0x80], xmm8
0000707b885d3704  vmovaps [rsp+0x90], xmm9
0000707b885d370d  vmovaps [rsp+0xA0], xmm10
0000707b885d3716  vmovaps [rsp+0xB0], xmm11
0000707b885d371f  vmovaps [rsp+0xC0], xmm13
0000707b885d3728  vmovaps [rsp+0xD0], xmm14
0000707b885d3731  vmovaps [rsp+0xE0], xmm15
0000707b885d373a  sub rsp, 0x30
0000707b885d373e  movaps [rsp], xmm12
0000707b885d3743  movaps [rsp+0x10], xmm15
0000707b885d3749  movaps [rsp+0x20], xmm13
0000707b885d374f  lea rdi, [rsp]
0000707b885d3753  mov esi, 0x00
0000707b885d3758  mov rax, 0x6471B35AC530
0000707b885d3762  call rax
0000707b885d3764  movaps xmm12, [rsp]
0000707b885d3769  add rsp, 0x30
0000707b885d376d  vmovaps xmm0, [rsp]
0000707b885d3772  vmovaps xmm1, [rsp+0x10]
0000707b885d3778  vmovaps xmm2, [rsp+0x20]
0000707b885d377e  vmovaps xmm3, [rsp+0x30]
0000707b885d3784  vmovaps xmm4, [rsp+0x40]
0000707b885d378a  vmovaps xmm5, [rsp+0x50]
0000707b885d3790  vmovaps xmm6, [rsp+0x60]
0000707b885d3796  vmovaps xmm7, [rsp+0x70]
0000707b885d379c  vmovaps xmm8, [rsp+0x80]
0000707b885d37a5  vmovaps xmm9, [rsp+0x90]
0000707b885d37ae  vmovaps xmm10, [rsp+0xA0]
0000707b885d37b7  vmovaps xmm11, [rsp+0xB0]
0000707b885d37c0  vmovaps xmm13, [rsp+0xC0]
0000707b885d37c9  vmovaps xmm14, [rsp+0xD0]
0000707b885d37d2  vmovaps xmm15, [rsp+0xE0]
0000707b885d37db  add rsp, 0xF0
0000707b885d37e2  pop r11
0000707b885d37e4  pop r10
0000707b885d37e6  pop r9
0000707b885d37e8  pop r8
0000707b885d37ea  pop rsi
0000707b885d37eb  pop rdi
0000707b885d37ec  pop rdx
0000707b885d37ed  pop rcx
0000707b885d37ee  pop rax
0000707b885d37ef  add rsp, 0x08
0000707b885d37f3  jmp 0x0000707B885CFF34
0000707b885d37f8  sub rsp, 0x08
0000707b885d37fc  push rax
0000707b885d37fd  push rcx
0000707b885d37fe  push rdx
0000707b885d37ff  push rdi
0000707b885d3800  push rsi
0000707b885d3801  push r8
0000707b885d3803  push r9
0000707b885d3805  push r10
0000707b885d3807  push r11
0000707b885d3809  sub rsp, 0xF0
0000707b885d3810  vmovaps [rsp], xmm0
0000707b885d3815  vmovaps [rsp+0x10], xmm1
0000707b885d381b  vmovaps [rsp+0x20], xmm2
0000707b885d3821  vmovaps [rsp+0x30], xmm3
0000707b885d3827  vmovaps [rsp+0x40], xmm4
0000707b885d382d  vmovaps [rsp+0x50], xmm5
0000707b885d3833  vmovaps [rsp+0x60], xmm6
0000707b885d3839  vmovaps [rsp+0x70], xmm7
0000707b885d383f  vmovaps [rsp+0x80], xmm8
0000707b885d3848  vmovaps [rsp+0x90], xmm9
0000707b885d3851  vmovaps [rsp+0xA0], xmm10
0000707b885d385a  vmovaps [rsp+0xB0], xmm11
0000707b885d3863  vmovaps [rsp+0xC0], xmm12
0000707b885d386c  vmovaps [rsp+0xD0], xmm13
0000707b885d3875  vmovaps [rsp+0xE0], xmm14
0000707b885d387e  sub rsp, 0x30
0000707b885d3882  movaps [rsp], xmm15
0000707b885d3887  movaps [rsp+0x10], xmm13
0000707b885d388d  movaps [rsp+0x20], xmm10
0000707b885d3893  lea rdi, [rsp]
0000707b885d3897  mov esi, 0x00
0000707b885d389c  mov rax, 0x6471B35AC530
0000707b885d38a6  call rax
0000707b885d38a8  movaps xmm15, [rsp]
0000707b885d38ad  add rsp, 0x30
0000707b885d38b1  vmovaps xmm0, [rsp]
0000707b885d38b6  vmovaps xmm1, [rsp+0x10]
0000707b885d38bc  vmovaps xmm2, [rsp+0x20]
0000707b885d38c2  vmovaps xmm3, [rsp+0x30]
0000707b885d38c8  vmovaps xmm4, [rsp+0x40]
0000707b885d38ce  vmovaps xmm5, [rsp+0x50]
0000707b885d38d4  vmovaps xmm6, [rsp+0x60]
0000707b885d38da  vmovaps xmm7, [rsp+0x70]
0000707b885d38e0  vmovaps xmm8, [rsp+0x80]
0000707b885d38e9  vmovaps xmm9, [rsp+0x90]
0000707b885d38f2  vmovaps xmm10, [rsp+0xA0]
0000707b885d38fb  vmovaps xmm11, [rsp+0xB0]
0000707b885d3904  vmovaps xmm12, [rsp+0xC0]
0000707b885d390d  vmovaps xmm13, [rsp+0xD0]
0000707b885d3916  vmovaps xmm14, [rsp+0xE0]
0000707b885d391f  add rsp, 0xF0
0000707b885d3926  pop r11
0000707b885d3928  pop r10
0000707b885d392a  pop r9
0000707b885d392c  pop r8
0000707b885d392e  pop rsi
0000707b885d392f  pop rdi
0000707b885d3930  pop rdx
0000707b885d3931  pop rcx
0000707b885d3932  pop rax
0000707b885d3933  add rsp, 0x08
0000707b885d3937  jmp 0x0000707B885CFF55
0000707b885d393c  call 0x0000707B8840C260
0000707b885d3941  jmp 0x0000707B885CFFB0
0000707b885d3946  sub rsp, 0x08
0000707b885d394a  push rax
0000707b885d394b  push rcx
0000707b885d394c  push rdx
0000707b885d394d  push rdi
0000707b885d394e  push rsi
0000707b885d394f  push r8
0000707b885d3951  push r9
0000707b885d3953  push r10
0000707b885d3955  push r11
0000707b885d3957  sub rsp, 0xF0
0000707b885d395e  vmovaps [rsp], xmm0
0000707b885d3963  vmovaps [rsp+0x10], xmm1
0000707b885d3969  vmovaps [rsp+0x20], xmm2
0000707b885d396f  vmovaps [rsp+0x30], xmm3
0000707b885d3975  vmovaps [rsp+0x40], xmm4
0000707b885d397b  vmovaps [rsp+0x50], xmm5
0000707b885d3981  vmovaps [rsp+0x60], xmm6
0000707b885d3987  vmovaps [rsp+0x70], xmm7
0000707b885d398d  vmovaps [rsp+0x80], xmm8
0000707b885d3996  vmovaps [rsp+0x90], xmm10
0000707b885d399f  vmovaps [rsp+0xA0], xmm11
0000707b885d39a8  vmovaps [rsp+0xB0], xmm12
0000707b885d39b1  vmovaps [rsp+0xC0], xmm13
0000707b885d39ba  vmovaps [rsp+0xD0], xmm14
0000707b885d39c3  vmovaps [rsp+0xE0], xmm15
0000707b885d39cc  sub rsp, 0x30
0000707b885d39d0  movaps [rsp], xmm9
0000707b885d39d5  movaps [rsp+0x10], xmm8
0000707b885d39db  movaps [rsp+0x20], xmm10
0000707b885d39e1  lea rdi, [rsp]
0000707b885d39e5  mov esi, 0x00
0000707b885d39ea  mov rax, 0x6471B35AC530
0000707b885d39f4  call rax
0000707b885d39f6  movaps xmm9, [rsp]
0000707b885d39fb  add rsp, 0x30
0000707b885d39ff  vmovaps xmm0, [rsp]
0000707b885d3a04  vmovaps xmm1, [rsp+0x10]
0000707b885d3a0a  vmovaps xmm2, [rsp+0x20]
0000707b885d3a10  vmovaps xmm3, [rsp+0x30]
0000707b885d3a16  vmovaps xmm4, [rsp+0x40]
0000707b885d3a1c  vmovaps xmm5, [rsp+0x50]
0000707b885d3a22  vmovaps xmm6, [rsp+0x60]
0000707b885d3a28  vmovaps xmm7, [rsp+0x70]
0000707b885d3a2e  vmovaps xmm8, [rsp+0x80]
0000707b885d3a37  vmovaps xmm10, [rsp+0x90]
0000707b885d3a40  vmovaps xmm11, [rsp+0xA0]
0000707b885d3a49  vmovaps xmm12, [rsp+0xB0]
0000707b885d3a52  vmovaps xmm13, [rsp+0xC0]
0000707b885d3a5b  vmovaps xmm14, [rsp+0xD0]
0000707b885d3a64  vmovaps xmm15, [rsp+0xE0]
0000707b885d3a6d  add rsp, 0xF0
0000707b885d3a74  pop r11
0000707b885d3a76  pop r10
0000707b885d3a78  pop r9
0000707b885d3a7a  pop r8
0000707b885d3a7c  pop rsi
0000707b885d3a7d  pop rdi
0000707b885d3a7e  pop rdx
0000707b885d3a7f  pop rcx
0000707b885d3a80  pop rax
0000707b885d3a81  add rsp, 0x08
0000707b885d3a85  jmp 0x0000707B885CFFE1
0000707b885d3a8a  sub rsp, 0x08
0000707b885d3a8e  push rax
0000707b885d3a8f  push rcx
0000707b885d3a90  push rdx
0000707b885d3a91  push rdi
0000707b885d3a92  push rsi
0000707b885d3a93  push r8
0000707b885d3a95  push r9
0000707b885d3a97  push r10
0000707b885d3a99  push r11
0000707b885d3a9b  sub rsp, 0xF0
0000707b885d3aa2  vmovaps [rsp], xmm0
0000707b885d3aa7  vmovaps [rsp+0x10], xmm1
0000707b885d3aad  vmovaps [rsp+0x20], xmm2
0000707b885d3ab3  vmovaps [rsp+0x30], xmm3
0000707b885d3ab9  vmovaps [rsp+0x40], xmm4
0000707b885d3abf  vmovaps [rsp+0x50], xmm5
0000707b885d3ac5  vmovaps [rsp+0x60], xmm6
0000707b885d3acb  vmovaps [rsp+0x70], xmm7
0000707b885d3ad1  vmovaps [rsp+0x80], xmm8
0000707b885d3ada  vmovaps [rsp+0x90], xmm9
0000707b885d3ae3  vmovaps [rsp+0xA0], xmm11
0000707b885d3aec  vmovaps [rsp+0xB0], xmm12
0000707b885d3af5  vmovaps [rsp+0xC0], xmm13
0000707b885d3afe  vmovaps [rsp+0xD0], xmm14
0000707b885d3b07  vmovaps [rsp+0xE0], xmm15
0000707b885d3b10  sub rsp, 0x30
0000707b885d3b14  movaps [rsp], xmm10
0000707b885d3b19  movaps [rsp+0x10], xmm1
0000707b885d3b1e  movaps [rsp+0x20], xmm11
0000707b885d3b24  lea rdi, [rsp]
0000707b885d3b28  mov esi, 0x00
0000707b885d3b2d  mov rax, 0x6471B35AC530
0000707b885d3b37  call rax
0000707b885d3b39  movaps xmm10, [rsp]
0000707b885d3b3e  add rsp, 0x30
0000707b885d3b42  vmovaps xmm0, [rsp]
0000707b885d3b47  vmovaps xmm1, [rsp+0x10]
0000707b885d3b4d  vmovaps xmm2, [rsp+0x20]
0000707b885d3b53  vmovaps xmm3, [rsp+0x30]
0000707b885d3b59  vmovaps xmm4, [rsp+0x40]
0000707b885d3b5f  vmovaps xmm5, [rsp+0x50]
0000707b885d3b65  vmovaps xmm6, [rsp+0x60]
0000707b885d3b6b  vmovaps xmm7, [rsp+0x70]
0000707b885d3b71  vmovaps xmm8, [rsp+0x80]
0000707b885d3b7a  vmovaps xmm9, [rsp+0x90]
0000707b885d3b83  vmovaps xmm11, [rsp+0xA0]
0000707b885d3b8c  vmovaps xmm12, [rsp+0xB0]
0000707b885d3b95  vmovaps xmm13, [rsp+0xC0]
0000707b885d3b9e  vmovaps xmm14, [rsp+0xD0]
0000707b885d3ba7  vmovaps xmm15, [rsp+0xE0]
0000707b885d3bb0  add rsp, 0xF0
0000707b885d3bb7  pop r11
0000707b885d3bb9  pop r10
0000707b885d3bbb  pop r9
0000707b885d3bbd  pop r8
0000707b885d3bbf  pop rsi
0000707b885d3bc0  pop rdi
0000707b885d3bc1  pop rdx
0000707b885d3bc2  pop rcx
0000707b885d3bc3  pop rax
0000707b885d3bc4  add rsp, 0x08
0000707b885d3bc8  jmp 0x0000707B885CFFFC
0000707b885d3bcd  sub rsp, 0x08
0000707b885d3bd1  push rax
0000707b885d3bd2  push rcx
0000707b885d3bd3  push rdx
0000707b885d3bd4  push rdi
0000707b885d3bd5  push rsi
0000707b885d3bd6  push r8
0000707b885d3bd8  push r9
0000707b885d3bda  push r10
0000707b885d3bdc  push r11
0000707b885d3bde  sub rsp, 0xF0
0000707b885d3be5  vmovaps [rsp], xmm0
0000707b885d3bea  vmovaps [rsp+0x10], xmm2
0000707b885d3bf0  vmovaps [rsp+0x20], xmm3
0000707b885d3bf6  vmovaps [rsp+0x30], xmm4
0000707b885d3bfc  vmovaps [rsp+0x40], xmm5
0000707b885d3c02  vmovaps [rsp+0x50], xmm6
0000707b885d3c08  vmovaps [rsp+0x60], xmm7
0000707b885d3c0e  vmovaps [rsp+0x70], xmm8
0000707b885d3c14  vmovaps [rsp+0x80], xmm9
0000707b885d3c1d  vmovaps [rsp+0x90], xmm10
0000707b885d3c26  vmovaps [rsp+0xA0], xmm11
0000707b885d3c2f  vmovaps [rsp+0xB0], xmm12
0000707b885d3c38  vmovaps [rsp+0xC0], xmm13
0000707b885d3c41  vmovaps [rsp+0xD0], xmm14
0000707b885d3c4a  vmovaps [rsp+0xE0], xmm15
0000707b885d3c53  sub rsp, 0x30
0000707b885d3c57  movaps [rsp], xmm1
0000707b885d3c5b  movaps [rsp+0x10], xmm14
0000707b885d3c61  movaps [rsp+0x20], xmm6
0000707b885d3c66  lea rdi, [rsp]
0000707b885d3c6a  mov esi, 0x00
0000707b885d3c6f  mov rax, 0x6471B35AC530
0000707b885d3c79  call rax
0000707b885d3c7b  movaps xmm1, [rsp]
0000707b885d3c7f  add rsp, 0x30
0000707b885d3c83  vmovaps xmm0, [rsp]
0000707b885d3c88  vmovaps xmm2, [rsp+0x10]
0000707b885d3c8e  vmovaps xmm3, [rsp+0x20]
0000707b885d3c94  vmovaps xmm4, [rsp+0x30]
0000707b885d3c9a  vmovaps xmm5, [rsp+0x40]
0000707b885d3ca0  vmovaps xmm6, [rsp+0x50]
0000707b885d3ca6  vmovaps xmm7, [rsp+0x60]
0000707b885d3cac  vmovaps xmm8, [rsp+0x70]
0000707b885d3cb2  vmovaps xmm9, [rsp+0x80]
0000707b885d3cbb  vmovaps xmm10, [rsp+0x90]
0000707b885d3cc4  vmovaps xmm11, [rsp+0xA0]
0000707b885d3ccd  vmovaps xmm12, [rsp+0xB0]
0000707b885d3cd6  vmovaps xmm13, [rsp+0xC0]
0000707b885d3cdf  vmovaps xmm14, [rsp+0xD0]
0000707b885d3ce8  vmovaps xmm15, [rsp+0xE0]
0000707b885d3cf1  add rsp, 0xF0
0000707b885d3cf8  pop r11
0000707b885d3cfa  pop r10
0000707b885d3cfc  pop r9
0000707b885d3cfe  pop r8
0000707b885d3d00  pop rsi
0000707b885d3d01  pop rdi
0000707b885d3d02  pop rdx
0000707b885d3d03  pop rcx
0000707b885d3d04  pop rax
0000707b885d3d05  add rsp, 0x08
0000707b885d3d09  jmp 0x0000707B885D0015
0000707b885d3d0e  sub rsp, 0x08
0000707b885d3d12  push rax
0000707b885d3d13  push rcx
0000707b885d3d14  push rdx
0000707b885d3d15  push rdi
0000707b885d3d16  push rsi
0000707b885d3d17  push r8
0000707b885d3d19  push r9
0000707b885d3d1b  push r10
0000707b885d3d1d  push r11
0000707b885d3d1f  sub rsp, 0xF0
0000707b885d3d26  vmovaps [rsp], xmm0
0000707b885d3d2b  vmovaps [rsp+0x10], xmm1
0000707b885d3d31  vmovaps [rsp+0x20], xmm2
0000707b885d3d37  vmovaps [rsp+0x30], xmm3
0000707b885d3d3d  vmovaps [rsp+0x40], xmm4
0000707b885d3d43  vmovaps [rsp+0x50], xmm5
0000707b885d3d49  vmovaps [rsp+0x60], xmm6
0000707b885d3d4f  vmovaps [rsp+0x70], xmm7
0000707b885d3d55  vmovaps [rsp+0x80], xmm8
0000707b885d3d5e  vmovaps [rsp+0x90], xmm9
0000707b885d3d67  vmovaps [rsp+0xA0], xmm10
0000707b885d3d70  vmovaps [rsp+0xB0], xmm12
0000707b885d3d79  vmovaps [rsp+0xC0], xmm13
0000707b885d3d82  vmovaps [rsp+0xD0], xmm14
0000707b885d3d8b  vmovaps [rsp+0xE0], xmm15
0000707b885d3d94  sub rsp, 0x30
0000707b885d3d98  movaps [rsp], xmm11
0000707b885d3d9d  movaps [rsp+0x10], xmm13
0000707b885d3da3  movaps [rsp+0x20], xmm14
0000707b885d3da9  lea rdi, [rsp]
0000707b885d3dad  mov esi, 0x00
0000707b885d3db2  mov rax, 0x6471B35AC530
0000707b885d3dbc  call rax
0000707b885d3dbe  movaps xmm11, [rsp]
0000707b885d3dc3  add rsp, 0x30
0000707b885d3dc7  vmovaps xmm0, [rsp]
0000707b885d3dcc  vmovaps xmm1, [rsp+0x10]
0000707b885d3dd2  vmovaps xmm2, [rsp+0x20]
0000707b885d3dd8  vmovaps xmm3, [rsp+0x30]
0000707b885d3dde  vmovaps xmm4, [rsp+0x40]
0000707b885d3de4  vmovaps xmm5, [rsp+0x50]
0000707b885d3dea  vmovaps xmm6, [rsp+0x60]
0000707b885d3df0  vmovaps xmm7, [rsp+0x70]
0000707b885d3df6  vmovaps xmm8, [rsp+0x80]
0000707b885d3dff  vmovaps xmm9, [rsp+0x90]
0000707b885d3e08  vmovaps xmm10, [rsp+0xA0]
0000707b885d3e11  vmovaps xmm12, [rsp+0xB0]
0000707b885d3e1a  vmovaps xmm13, [rsp+0xC0]
0000707b885d3e23  vmovaps xmm14, [rsp+0xD0]
0000707b885d3e2c  vmovaps xmm15, [rsp+0xE0]
0000707b885d3e35  add rsp, 0xF0
0000707b885d3e3c  pop r11
0000707b885d3e3e  pop r10
0000707b885d3e40  pop r9
0000707b885d3e42  pop r8
0000707b885d3e44  pop rsi
0000707b885d3e45  pop rdi
0000707b885d3e46  pop rdx
0000707b885d3e47  pop rcx
0000707b885d3e48  pop rax
0000707b885d3e49  add rsp, 0x08
0000707b885d3e4d  jmp 0x0000707B885D003F
0000707b885d3e52  sub rsp, 0x08
0000707b885d3e56  push rax
0000707b885d3e57  push rcx
0000707b885d3e58  push rdx
0000707b885d3e59  push rdi
0000707b885d3e5a  push rsi
0000707b885d3e5b  push r8
0000707b885d3e5d  push r9
0000707b885d3e5f  push r10
0000707b885d3e61  push r11
0000707b885d3e63  sub rsp, 0xF0
0000707b885d3e6a  vmovaps [rsp], xmm0
0000707b885d3e6f  vmovaps [rsp+0x10], xmm1
0000707b885d3e75  vmovaps [rsp+0x20], xmm2
0000707b885d3e7b  vmovaps [rsp+0x30], xmm3
0000707b885d3e81  vmovaps [rsp+0x40], xmm4
0000707b885d3e87  vmovaps [rsp+0x50], xmm5
0000707b885d3e8d  vmovaps [rsp+0x60], xmm6
0000707b885d3e93  vmovaps [rsp+0x70], xmm7
0000707b885d3e99  vmovaps [rsp+0x80], xmm8
0000707b885d3ea2  vmovaps [rsp+0x90], xmm9
0000707b885d3eab  vmovaps [rsp+0xA0], xmm10
0000707b885d3eb4  vmovaps [rsp+0xB0], xmm11
0000707b885d3ebd  vmovaps [rsp+0xC0], xmm12
0000707b885d3ec6  vmovaps [rsp+0xD0], xmm14
0000707b885d3ecf  vmovaps [rsp+0xE0], xmm15
0000707b885d3ed8  sub rsp, 0x30
0000707b885d3edc  movaps [rsp], xmm13
0000707b885d3ee1  movaps [rsp+0x10], xmm8
0000707b885d3ee7  movaps [rsp+0x20], xmm14
0000707b885d3eed  lea rdi, [rsp]
0000707b885d3ef1  mov esi, 0x00
0000707b885d3ef6  mov rax, 0x6471B35AC530
0000707b885d3f00  call rax
0000707b885d3f02  movaps xmm13, [rsp]
0000707b885d3f07  add rsp, 0x30
0000707b885d3f0b  vmovaps xmm0, [rsp]
0000707b885d3f10  vmovaps xmm1, [rsp+0x10]
0000707b885d3f16  vmovaps xmm2, [rsp+0x20]
0000707b885d3f1c  vmovaps xmm3, [rsp+0x30]
0000707b885d3f22  vmovaps xmm4, [rsp+0x40]
0000707b885d3f28  vmovaps xmm5, [rsp+0x50]
0000707b885d3f2e  vmovaps xmm6, [rsp+0x60]
0000707b885d3f34  vmovaps xmm7, [rsp+0x70]
0000707b885d3f3a  vmovaps xmm8, [rsp+0x80]
0000707b885d3f43  vmovaps xmm9, [rsp+0x90]
0000707b885d3f4c  vmovaps xmm10, [rsp+0xA0]
0000707b885d3f55  vmovaps xmm11, [rsp+0xB0]
0000707b885d3f5e  vmovaps xmm12, [rsp+0xC0]
0000707b885d3f67  vmovaps xmm14, [rsp+0xD0]
0000707b885d3f70  vmovaps xmm15, [rsp+0xE0]
0000707b885d3f79  add rsp, 0xF0
0000707b885d3f80  pop r11
0000707b885d3f82  pop r10
0000707b885d3f84  pop r9
0000707b885d3f86  pop r8
0000707b885d3f88  pop rsi
0000707b885d3f89  pop rdi
0000707b885d3f8a  pop rdx
0000707b885d3f8b  pop rcx
0000707b885d3f8c  pop rax
0000707b885d3f8d  add rsp, 0x08
0000707b885d3f91  jmp 0x0000707B885D006E
0000707b885d3f96  sub rsp, 0x08
0000707b885d3f9a  push rax
0000707b885d3f9b  push rcx
0000707b885d3f9c  push rdx
0000707b885d3f9d  push rdi
0000707b885d3f9e  push rsi
0000707b885d3f9f  push r8
0000707b885d3fa1  push r9
0000707b885d3fa3  push r10
0000707b885d3fa5  push r11
0000707b885d3fa7  sub rsp, 0xF0
0000707b885d3fae  vmovaps [rsp], xmm0
0000707b885d3fb3  vmovaps [rsp+0x10], xmm1
0000707b885d3fb9  vmovaps [rsp+0x20], xmm2
0000707b885d3fbf  vmovaps [rsp+0x30], xmm3
0000707b885d3fc5  vmovaps [rsp+0x40], xmm4
0000707b885d3fcb  vmovaps [rsp+0x50], xmm5
0000707b885d3fd1  vmovaps [rsp+0x60], xmm6
0000707b885d3fd7  vmovaps [rsp+0x70], xmm7
0000707b885d3fdd  vmovaps [rsp+0x80], xmm9
0000707b885d3fe6  vmovaps [rsp+0x90], xmm10
0000707b885d3fef  vmovaps [rsp+0xA0], xmm11
0000707b885d3ff8  vmovaps [rsp+0xB0], xmm12
0000707b885d4001  vmovaps [rsp+0xC0], xmm13
0000707b885d400a  vmovaps [rsp+0xD0], xmm14
0000707b885d4013  vmovaps [rsp+0xE0], xmm15
0000707b885d401c  sub rsp, 0x30
0000707b885d4020  movaps [rsp], xmm8
0000707b885d4025  movaps [rsp+0x10], xmm7
0000707b885d402a  movaps [rsp+0x20], xmm14
0000707b885d4030  lea rdi, [rsp]
0000707b885d4034  mov esi, 0x00
0000707b885d4039  mov rax, 0x6471B35AC530
0000707b885d4043  call rax
0000707b885d4045  movaps xmm8, [rsp]
0000707b885d404a  add rsp, 0x30
0000707b885d404e  vmovaps xmm0, [rsp]
0000707b885d4053  vmovaps xmm1, [rsp+0x10]
0000707b885d4059  vmovaps xmm2, [rsp+0x20]
0000707b885d405f  vmovaps xmm3, [rsp+0x30]
0000707b885d4065  vmovaps xmm4, [rsp+0x40]
0000707b885d406b  vmovaps xmm5, [rsp+0x50]
0000707b885d4071  vmovaps xmm6, [rsp+0x60]
0000707b885d4077  vmovaps xmm7, [rsp+0x70]
0000707b885d407d  vmovaps xmm9, [rsp+0x80]
0000707b885d4086  vmovaps xmm10, [rsp+0x90]
0000707b885d408f  vmovaps xmm11, [rsp+0xA0]
0000707b885d4098  vmovaps xmm12, [rsp+0xB0]
0000707b885d40a1  vmovaps xmm13, [rsp+0xC0]
0000707b885d40aa  vmovaps xmm14, [rsp+0xD0]
0000707b885d40b3  vmovaps xmm15, [rsp+0xE0]
0000707b885d40bc  add rsp, 0xF0
0000707b885d40c3  pop r11
0000707b885d40c5  pop r10
0000707b885d40c7  pop r9
0000707b885d40c9  pop r8
0000707b885d40cb  pop rsi
0000707b885d40cc  pop rdi
0000707b885d40cd  pop rdx
0000707b885d40ce  pop rcx
0000707b885d40cf  pop rax
0000707b885d40d0  add rsp, 0x08
0000707b885d40d4  jmp 0x0000707B885D0094
0000707b885d40d9  sub rsp, 0x08
0000707b885d40dd  push rax
0000707b885d40de  push rcx
0000707b885d40df  push rdx
0000707b885d40e0  push rdi
0000707b885d40e1  push rsi
0000707b885d40e2  push r8
0000707b885d40e4  push r9
0000707b885d40e6  push r10
0000707b885d40e8  push r11
0000707b885d40ea  sub rsp, 0xF0
0000707b885d40f1  vmovaps [rsp], xmm0
0000707b885d40f6  vmovaps [rsp+0x10], xmm1
0000707b885d40fc  vmovaps [rsp+0x20], xmm2
0000707b885d4102  vmovaps [rsp+0x30], xmm3
0000707b885d4108  vmovaps [rsp+0x40], xmm4
0000707b885d410e  vmovaps [rsp+0x50], xmm5
0000707b885d4114  vmovaps [rsp+0x60], xmm6
0000707b885d411a  vmovaps [rsp+0x70], xmm7
0000707b885d4120  vmovaps [rsp+0x80], xmm8
0000707b885d4129  vmovaps [rsp+0x90], xmm9
0000707b885d4132  vmovaps [rsp+0xA0], xmm10
0000707b885d413b  vmovaps [rsp+0xB0], xmm11
0000707b885d4144  vmovaps [rsp+0xC0], xmm12
0000707b885d414d  vmovaps [rsp+0xD0], xmm13
0000707b885d4156  vmovaps [rsp+0xE0], xmm15
0000707b885d415f  sub rsp, 0x30
0000707b885d4163  movaps [rsp], xmm14
0000707b885d4168  movaps [rsp+0x10], xmm12
0000707b885d416e  movaps [rsp+0x20], xmm9
0000707b885d4174  lea rdi, [rsp]
0000707b885d4178  mov esi, 0x00
0000707b885d417d  mov rax, 0x6471B35AC530
0000707b885d4187  call rax
0000707b885d4189  movaps xmm14, [rsp]
0000707b885d418e  add rsp, 0x30
0000707b885d4192  vmovaps xmm0, [rsp]
0000707b885d4197  vmovaps xmm1, [rsp+0x10]
0000707b885d419d  vmovaps xmm2, [rsp+0x20]
0000707b885d41a3  vmovaps xmm3, [rsp+0x30]
0000707b885d41a9  vmovaps xmm4, [rsp+0x40]
0000707b885d41af  vmovaps xmm5, [rsp+0x50]
0000707b885d41b5  vmovaps xmm6, [rsp+0x60]
0000707b885d41bb  vmovaps xmm7, [rsp+0x70]
0000707b885d41c1  vmovaps xmm8, [rsp+0x80]
0000707b885d41ca  vmovaps xmm9, [rsp+0x90]
0000707b885d41d3  vmovaps xmm10, [rsp+0xA0]
0000707b885d41dc  vmovaps xmm11, [rsp+0xB0]
0000707b885d41e5  vmovaps xmm12, [rsp+0xC0]
0000707b885d41ee  vmovaps xmm13, [rsp+0xD0]
0000707b885d41f7  vmovaps xmm15, [rsp+0xE0]
0000707b885d4200  add rsp, 0xF0
0000707b885d4207  pop r11
0000707b885d4209  pop r10
0000707b885d420b  pop r9
0000707b885d420d  pop r8
0000707b885d420f  pop rsi
0000707b885d4210  pop rdi
0000707b885d4211  pop rdx
0000707b885d4212  pop rcx
0000707b885d4213  pop rax
0000707b885d4214  add rsp, 0x08
0000707b885d4218  jmp 0x0000707B885D00AE
0000707b885d421d  sub rsp, 0x08
0000707b885d4221  push rax
0000707b885d4222  push rcx
0000707b885d4223  push rdx
0000707b885d4224  push rdi
0000707b885d4225  push rsi
0000707b885d4226  push r8
0000707b885d4228  push r9
0000707b885d422a  push r10
0000707b885d422c  push r11
0000707b885d422e  sub rsp, 0xF0
0000707b885d4235  vmovaps [rsp], xmm0
0000707b885d423a  vmovaps [rsp+0x10], xmm1
0000707b885d4240  vmovaps [rsp+0x20], xmm2
0000707b885d4246  vmovaps [rsp+0x30], xmm3
0000707b885d424c  vmovaps [rsp+0x40], xmm4
0000707b885d4252  vmovaps [rsp+0x50], xmm5
0000707b885d4258  vmovaps [rsp+0x60], xmm6
0000707b885d425e  vmovaps [rsp+0x70], xmm7
0000707b885d4264  vmovaps [rsp+0x80], xmm8
0000707b885d426d  vmovaps [rsp+0x90], xmm10
0000707b885d4276  vmovaps [rsp+0xA0], xmm11
0000707b885d427f  vmovaps [rsp+0xB0], xmm12
0000707b885d4288  vmovaps [rsp+0xC0], xmm13
0000707b885d4291  vmovaps [rsp+0xD0], xmm14
0000707b885d429a  vmovaps [rsp+0xE0], xmm15
0000707b885d42a3  sub rsp, 0x30
0000707b885d42a7  movaps [rsp], xmm9
0000707b885d42ac  movaps [rsp+0x10], xmm7
0000707b885d42b1  movaps [rsp+0x20], xmm12
0000707b885d42b7  lea rdi, [rsp]
0000707b885d42bb  mov esi, 0x00
0000707b885d42c0  mov rax, 0x6471B35AC530
0000707b885d42ca  call rax
0000707b885d42cc  movaps xmm9, [rsp]
0000707b885d42d1  add rsp, 0x30
0000707b885d42d5  vmovaps xmm0, [rsp]
0000707b885d42da  vmovaps xmm1, [rsp+0x10]
0000707b885d42e0  vmovaps xmm2, [rsp+0x20]
0000707b885d42e6  vmovaps xmm3, [rsp+0x30]
0000707b885d42ec  vmovaps xmm4, [rsp+0x40]
0000707b885d42f2  vmovaps xmm5, [rsp+0x50]
0000707b885d42f8  vmovaps xmm6, [rsp+0x60]
0000707b885d42fe  vmovaps xmm7, [rsp+0x70]
0000707b885d4304  vmovaps xmm8, [rsp+0x80]
0000707b885d430d  vmovaps xmm10, [rsp+0x90]
0000707b885d4316  vmovaps xmm11, [rsp+0xA0]
0000707b885d431f  vmovaps xmm12, [rsp+0xB0]
0000707b885d4328  vmovaps xmm13, [rsp+0xC0]
0000707b885d4331  vmovaps xmm14, [rsp+0xD0]
0000707b885d433a  vmovaps xmm15, [rsp+0xE0]
0000707b885d4343  add rsp, 0xF0
0000707b885d434a  pop r11
0000707b885d434c  pop r10
0000707b885d434e  pop r9
0000707b885d4350  pop r8
0000707b885d4352  pop rsi
0000707b885d4353  pop rdi
0000707b885d4354  pop rdx
0000707b885d4355  pop rcx
0000707b885d4356  pop rax
0000707b885d4357  add rsp, 0x08
0000707b885d435b  jmp 0x0000707B885D00DD
0000707b885d4360  sub rsp, 0x08
0000707b885d4364  push rax
0000707b885d4365  push rcx
0000707b885d4366  push rdx
0000707b885d4367  push rdi
0000707b885d4368  push rsi
0000707b885d4369  push r8
0000707b885d436b  push r9
0000707b885d436d  push r10
0000707b885d436f  push r11
0000707b885d4371  sub rsp, 0xF0
0000707b885d4378  vmovaps [rsp], xmm0
0000707b885d437d  vmovaps [rsp+0x10], xmm1
0000707b885d4383  vmovaps [rsp+0x20], xmm2
0000707b885d4389  vmovaps [rsp+0x30], xmm3
0000707b885d438f  vmovaps [rsp+0x40], xmm4
0000707b885d4395  vmovaps [rsp+0x50], xmm5
0000707b885d439b  vmovaps [rsp+0x60], xmm6
0000707b885d43a1  vmovaps [rsp+0x70], xmm7
0000707b885d43a7  vmovaps [rsp+0x80], xmm8
0000707b885d43b0  vmovaps [rsp+0x90], xmm9
0000707b885d43b9  vmovaps [rsp+0xA0], xmm10
0000707b885d43c2  vmovaps [rsp+0xB0], xmm11
0000707b885d43cb  vmovaps [rsp+0xC0], xmm13
0000707b885d43d4  vmovaps [rsp+0xD0], xmm14
0000707b885d43dd  vmovaps [rsp+0xE0], xmm15
0000707b885d43e6  sub rsp, 0x30
0000707b885d43ea  movaps [rsp], xmm12
0000707b885d43ef  movaps [rsp+0x10], xmm15
0000707b885d43f5  movaps [rsp+0x20], xmm11
0000707b885d43fb  lea rdi, [rsp]
0000707b885d43ff  mov esi, 0x00
0000707b885d4404  mov rax, 0x6471B35AC530
0000707b885d440e  call rax
0000707b885d4410  movaps xmm12, [rsp]
0000707b885d4415  add rsp, 0x30
0000707b885d4419  vmovaps xmm0, [rsp]
0000707b885d441e  vmovaps xmm1, [rsp+0x10]
0000707b885d4424  vmovaps xmm2, [rsp+0x20]
0000707b885d442a  vmovaps xmm3, [rsp+0x30]
0000707b885d4430  vmovaps xmm4, [rsp+0x40]
0000707b885d4436  vmovaps xmm5, [rsp+0x50]
0000707b885d443c  vmovaps xmm6, [rsp+0x60]
0000707b885d4442  vmovaps xmm7, [rsp+0x70]
0000707b885d4448  vmovaps xmm8, [rsp+0x80]
0000707b885d4451  vmovaps xmm9, [rsp+0x90]
0000707b885d445a  vmovaps xmm10, [rsp+0xA0]
0000707b885d4463  vmovaps xmm11, [rsp+0xB0]
0000707b885d446c  vmovaps xmm13, [rsp+0xC0]
0000707b885d4475  vmovaps xmm14, [rsp+0xD0]
0000707b885d447e  vmovaps xmm15, [rsp+0xE0]
0000707b885d4487  add rsp, 0xF0
0000707b885d448e  pop r11
0000707b885d4490  pop r10
0000707b885d4492  pop r9
0000707b885d4494  pop r8
0000707b885d4496  pop rsi
0000707b885d4497  pop rdi
0000707b885d4498  pop rdx
0000707b885d4499  pop rcx
0000707b885d449a  pop rax
0000707b885d449b  add rsp, 0x08
0000707b885d449f  jmp 0x0000707B885D00F7
0000707b885d44a4  sub rsp, 0x08
0000707b885d44a8  push rax
0000707b885d44a9  push rcx
0000707b885d44aa  push rdx
0000707b885d44ab  push rdi
0000707b885d44ac  push rsi
0000707b885d44ad  push r8
0000707b885d44af  push r9
0000707b885d44b1  push r10
0000707b885d44b3  push r11
0000707b885d44b5  sub rsp, 0xF0
0000707b885d44bc  vmovaps [rsp], xmm0
0000707b885d44c1  vmovaps [rsp+0x10], xmm1
0000707b885d44c7  vmovaps [rsp+0x20], xmm2
0000707b885d44cd  vmovaps [rsp+0x30], xmm3
0000707b885d44d3  vmovaps [rsp+0x40], xmm4
0000707b885d44d9  vmovaps [rsp+0x50], xmm5
0000707b885d44df  vmovaps [rsp+0x60], xmm6
0000707b885d44e5  vmovaps [rsp+0x70], xmm7
0000707b885d44eb  vmovaps [rsp+0x80], xmm8
0000707b885d44f4  vmovaps [rsp+0x90], xmm9
0000707b885d44fd  vmovaps [rsp+0xA0], xmm10
0000707b885d4506  vmovaps [rsp+0xB0], xmm12
0000707b885d450f  vmovaps [rsp+0xC0], xmm13
0000707b885d4518  vmovaps [rsp+0xD0], xmm14
0000707b885d4521  vmovaps [rsp+0xE0], xmm15
0000707b885d452a  sub rsp, 0x30
0000707b885d452e  movaps [rsp], xmm11
0000707b885d4533  movaps [rsp+0x10], xmm7
0000707b885d4538  movaps [rsp+0x20], xmm15
0000707b885d453e  lea rdi, [rsp]
0000707b885d4542  mov esi, 0x00
0000707b885d4547  mov rax, 0x6471B35AC530
0000707b885d4551  call rax
0000707b885d4553  movaps xmm11, [rsp]
0000707b885d4558  add rsp, 0x30
0000707b885d455c  vmovaps xmm0, [rsp]
0000707b885d4561  vmovaps xmm1, [rsp+0x10]
0000707b885d4567  vmovaps xmm2, [rsp+0x20]
0000707b885d456d  vmovaps xmm3, [rsp+0x30]
0000707b885d4573  vmovaps xmm4, [rsp+0x40]
0000707b885d4579  vmovaps xmm5, [rsp+0x50]
0000707b885d457f  vmovaps xmm6, [rsp+0x60]
0000707b885d4585  vmovaps xmm7, [rsp+0x70]
0000707b885d458b  vmovaps xmm8, [rsp+0x80]
0000707b885d4594  vmovaps xmm9, [rsp+0x90]
0000707b885d459d  vmovaps xmm10, [rsp+0xA0]
0000707b885d45a6  vmovaps xmm12, [rsp+0xB0]
0000707b885d45af  vmovaps xmm13, [rsp+0xC0]
0000707b885d45b8  vmovaps xmm14, [rsp+0xD0]
0000707b885d45c1  vmovaps xmm15, [rsp+0xE0]
0000707b885d45ca  add rsp, 0xF0
0000707b885d45d1  pop r11
0000707b885d45d3  pop r10
0000707b885d45d5  pop r9
0000707b885d45d7  pop r8
0000707b885d45d9  pop rsi
0000707b885d45da  pop rdi
0000707b885d45db  pop rdx
0000707b885d45dc  pop rcx
0000707b885d45dd  pop rax
0000707b885d45de  add rsp, 0x08
0000707b885d45e2  jmp 0x0000707B885D0123
0000707b885d45e7  sub rsp, 0x08
0000707b885d45eb  push rax
0000707b885d45ec  push rcx
0000707b885d45ed  push rdx
0000707b885d45ee  push rdi
0000707b885d45ef  push rsi
0000707b885d45f0  push r8
0000707b885d45f2  push r9
0000707b885d45f4  push r10
0000707b885d45f6  push r11
0000707b885d45f8  sub rsp, 0xF0
0000707b885d45ff  vmovaps [rsp], xmm0
0000707b885d4604  vmovaps [rsp+0x10], xmm1
0000707b885d460a  vmovaps [rsp+0x20], xmm2
0000707b885d4610  vmovaps [rsp+0x30], xmm3
0000707b885d4616  vmovaps [rsp+0x40], xmm4
0000707b885d461c  vmovaps [rsp+0x50], xmm5
0000707b885d4622  vmovaps [rsp+0x60], xmm6
0000707b885d4628  vmovaps [rsp+0x70], xmm7
0000707b885d462e  vmovaps [rsp+0x80], xmm8
0000707b885d4637  vmovaps [rsp+0x90], xmm9
0000707b885d4640  vmovaps [rsp+0xA0], xmm10
0000707b885d4649  vmovaps [rsp+0xB0], xmm11
0000707b885d4652  vmovaps [rsp+0xC0], xmm12
0000707b885d465b  vmovaps [rsp+0xD0], xmm13
0000707b885d4664  vmovaps [rsp+0xE0], xmm14
0000707b885d466d  sub rsp, 0x30
0000707b885d4671  movaps [rsp], xmm15
0000707b885d4676  movaps [rsp+0x10], xmm10
0000707b885d467c  movaps [rsp+0x20], xmm13
0000707b885d4682  lea rdi, [rsp]
0000707b885d4686  mov esi, 0x00
0000707b885d468b  mov rax, 0x6471B35AC530
0000707b885d4695  call rax
0000707b885d4697  movaps xmm15, [rsp]
0000707b885d469c  add rsp, 0x30
0000707b885d46a0  vmovaps xmm0, [rsp]
0000707b885d46a5  vmovaps xmm1, [rsp+0x10]
0000707b885d46ab  vmovaps xmm2, [rsp+0x20]
0000707b885d46b1  vmovaps xmm3, [rsp+0x30]
0000707b885d46b7  vmovaps xmm4, [rsp+0x40]
0000707b885d46bd  vmovaps xmm5, [rsp+0x50]
0000707b885d46c3  vmovaps xmm6, [rsp+0x60]
0000707b885d46c9  vmovaps xmm7, [rsp+0x70]
0000707b885d46cf  vmovaps xmm8, [rsp+0x80]
0000707b885d46d8  vmovaps xmm9, [rsp+0x90]
0000707b885d46e1  vmovaps xmm10, [rsp+0xA0]
0000707b885d46ea  vmovaps xmm11, [rsp+0xB0]
0000707b885d46f3  vmovaps xmm12, [rsp+0xC0]
0000707b885d46fc  vmovaps xmm13, [rsp+0xD0]
0000707b885d4705  vmovaps xmm14, [rsp+0xE0]
0000707b885d470e  add rsp, 0xF0
0000707b885d4715  pop r11
0000707b885d4717  pop r10
0000707b885d4719  pop r9
0000707b885d471b  pop r8
0000707b885d471d  pop rsi
0000707b885d471e  pop rdi
0000707b885d471f  pop rdx
0000707b885d4720  pop rcx
0000707b885d4721  pop rax
0000707b885d4722  add rsp, 0x08
0000707b885d4726  jmp 0x0000707B885D013D
0000707b885d472b  sub rsp, 0x08
0000707b885d472f  push rax
0000707b885d4730  push rcx
0000707b885d4731  push rdx
0000707b885d4732  push rdi
0000707b885d4733  push rsi
0000707b885d4734  push r8
0000707b885d4736  push r9
0000707b885d4738  push r10
0000707b885d473a  push r11
0000707b885d473c  sub rsp, 0xF0
0000707b885d4743  vmovaps [rsp], xmm0
0000707b885d4748  vmovaps [rsp+0x10], xmm1
0000707b885d474e  vmovaps [rsp+0x20], xmm2
0000707b885d4754  vmovaps [rsp+0x30], xmm3
0000707b885d475a  vmovaps [rsp+0x40], xmm4
0000707b885d4760  vmovaps [rsp+0x50], xmm5
0000707b885d4766  vmovaps [rsp+0x60], xmm6
0000707b885d476c  vmovaps [rsp+0x70], xmm7
0000707b885d4772  vmovaps [rsp+0x80], xmm8
0000707b885d477b  vmovaps [rsp+0x90], xmm9
0000707b885d4784  vmovaps [rsp+0xA0], xmm11
0000707b885d478d  vmovaps [rsp+0xB0], xmm12
0000707b885d4796  vmovaps [rsp+0xC0], xmm13
0000707b885d479f  vmovaps [rsp+0xD0], xmm14
0000707b885d47a8  vmovaps [rsp+0xE0], xmm15
0000707b885d47b1  sub rsp, 0x30
0000707b885d47b5  movaps [rsp], xmm10
0000707b885d47ba  movaps [rsp+0x10], xmm7
0000707b885d47bf  movaps [rsp+0x20], xmm13
0000707b885d47c5  lea rdi, [rsp]
0000707b885d47c9  mov esi, 0x00
0000707b885d47ce  mov rax, 0x6471B35AC530
0000707b885d47d8  call rax
0000707b885d47da  movaps xmm10, [rsp]
0000707b885d47df  add rsp, 0x30
0000707b885d47e3  vmovaps xmm0, [rsp]
0000707b885d47e8  vmovaps xmm1, [rsp+0x10]
0000707b885d47ee  vmovaps xmm2, [rsp+0x20]
0000707b885d47f4  vmovaps xmm3, [rsp+0x30]
0000707b885d47fa  vmovaps xmm4, [rsp+0x40]
0000707b885d4800  vmovaps xmm5, [rsp+0x50]
0000707b885d4806  vmovaps xmm6, [rsp+0x60]
0000707b885d480c  vmovaps xmm7, [rsp+0x70]
0000707b885d4812  vmovaps xmm8, [rsp+0x80]
0000707b885d481b  vmovaps xmm9, [rsp+0x90]
0000707b885d4824  vmovaps xmm11, [rsp+0xA0]
0000707b885d482d  vmovaps xmm12, [rsp+0xB0]
0000707b885d4836  vmovaps xmm13, [rsp+0xC0]
0000707b885d483f  vmovaps xmm14, [rsp+0xD0]
0000707b885d4848  vmovaps xmm15, [rsp+0xE0]
0000707b885d4851  add rsp, 0xF0
0000707b885d4858  pop r11
0000707b885d485a  pop r10
0000707b885d485c  pop r9
0000707b885d485e  pop r8
0000707b885d4860  pop rsi
0000707b885d4861  pop rdi
0000707b885d4862  pop rdx
0000707b885d4863  pop rcx
0000707b885d4864  pop rax
0000707b885d4865  add rsp, 0x08
0000707b885d4869  jmp 0x0000707B885D0169
0000707b885d486e  sub rsp, 0x08
0000707b885d4872  push rax
0000707b885d4873  push rcx
0000707b885d4874  push rdx
0000707b885d4875  push rdi
0000707b885d4876  push rsi
0000707b885d4877  push r8
0000707b885d4879  push r9
0000707b885d487b  push r10
0000707b885d487d  push r11
0000707b885d487f  sub rsp, 0xF0
0000707b885d4886  vmovaps [rsp], xmm0
0000707b885d488b  vmovaps [rsp+0x10], xmm1
0000707b885d4891  vmovaps [rsp+0x20], xmm2
0000707b885d4897  vmovaps [rsp+0x30], xmm3
0000707b885d489d  vmovaps [rsp+0x40], xmm4
0000707b885d48a3  vmovaps [rsp+0x50], xmm5
0000707b885d48a9  vmovaps [rsp+0x60], xmm6
0000707b885d48af  vmovaps [rsp+0x70], xmm7
0000707b885d48b5  vmovaps [rsp+0x80], xmm8
0000707b885d48be  vmovaps [rsp+0x90], xmm9
0000707b885d48c7  vmovaps [rsp+0xA0], xmm10
0000707b885d48d0  vmovaps [rsp+0xB0], xmm11
0000707b885d48d9  vmovaps [rsp+0xC0], xmm12
0000707b885d48e2  vmovaps [rsp+0xD0], xmm14
0000707b885d48eb  vmovaps [rsp+0xE0], xmm15
0000707b885d48f4  sub rsp, 0x30
0000707b885d48f8  movaps [rsp], xmm13
0000707b885d48fd  movaps [rsp+0x10], xmm1
0000707b885d4902  movaps [rsp+0x20], xmm8
0000707b885d4908  lea rdi, [rsp]
0000707b885d490c  mov esi, 0x00
0000707b885d4911  mov rax, 0x6471B35AC530
0000707b885d491b  call rax
0000707b885d491d  movaps xmm13, [rsp]
0000707b885d4922  add rsp, 0x30
0000707b885d4926  vmovaps xmm0, [rsp]
0000707b885d492b  vmovaps xmm1, [rsp+0x10]
0000707b885d4931  vmovaps xmm2, [rsp+0x20]
0000707b885d4937  vmovaps xmm3, [rsp+0x30]
0000707b885d493d  vmovaps xmm4, [rsp+0x40]
0000707b885d4943  vmovaps xmm5, [rsp+0x50]
0000707b885d4949  vmovaps xmm6, [rsp+0x60]
0000707b885d494f  vmovaps xmm7, [rsp+0x70]
0000707b885d4955  vmovaps xmm8, [rsp+0x80]
0000707b885d495e  vmovaps xmm9, [rsp+0x90]
0000707b885d4967  vmovaps xmm10, [rsp+0xA0]
0000707b885d4970  vmovaps xmm11, [rsp+0xB0]
0000707b885d4979  vmovaps xmm12, [rsp+0xC0]
0000707b885d4982  vmovaps xmm14, [rsp+0xD0]
0000707b885d498b  vmovaps xmm15, [rsp+0xE0]
0000707b885d4994  add rsp, 0xF0
0000707b885d499b  pop r11
0000707b885d499d  pop r10
0000707b885d499f  pop r9
0000707b885d49a1  pop r8
0000707b885d49a3  pop rsi
0000707b885d49a4  pop rdi
0000707b885d49a5  pop rdx
0000707b885d49a6  pop rcx
0000707b885d49a7  pop rax
0000707b885d49a8  add rsp, 0x08
0000707b885d49ac  jmp 0x0000707B885D0183
0000707b885d49b1  call 0x0000707B883FF430
0000707b885d49b6  jmp 0x0000707B885D018D
0000707b885d49bb  sub rsp, 0x08
0000707b885d49bf  push rax
0000707b885d49c0  push rcx
0000707b885d49c1  push rdx
0000707b885d49c2  push rdi
0000707b885d49c3  push rsi
0000707b885d49c4  push r8
0000707b885d49c6  push r9
0000707b885d49c8  push r10
0000707b885d49ca  push r11
0000707b885d49cc  sub rsp, 0xF0
0000707b885d49d3  vmovaps [rsp], xmm0
0000707b885d49d8  vmovaps [rsp+0x10], xmm1
0000707b885d49de  vmovaps [rsp+0x20], xmm2
0000707b885d49e4  vmovaps [rsp+0x30], xmm3
0000707b885d49ea  vmovaps [rsp+0x40], xmm4
0000707b885d49f0  vmovaps [rsp+0x50], xmm5
0000707b885d49f6  vmovaps [rsp+0x60], xmm6
0000707b885d49fc  vmovaps [rsp+0x70], xmm7
0000707b885d4a02  vmovaps [rsp+0x80], xmm9
0000707b885d4a0b  vmovaps [rsp+0x90], xmm10
0000707b885d4a14  vmovaps [rsp+0xA0], xmm11
0000707b885d4a1d  vmovaps [rsp+0xB0], xmm12
0000707b885d4a26  vmovaps [rsp+0xC0], xmm13
0000707b885d4a2f  vmovaps [rsp+0xD0], xmm14
0000707b885d4a38  vmovaps [rsp+0xE0], xmm15
0000707b885d4a41  sub rsp, 0x30
0000707b885d4a45  movaps [rsp], xmm8
0000707b885d4a4a  movaps [rsp+0x10], xmm14
0000707b885d4a50  movaps [rsp+0x20], xmm9
0000707b885d4a56  lea rdi, [rsp]
0000707b885d4a5a  mov esi, 0x00
0000707b885d4a5f  mov rax, 0x6471B35AC530
0000707b885d4a69  call rax
0000707b885d4a6b  movaps xmm8, [rsp]
0000707b885d4a70  add rsp, 0x30
0000707b885d4a74  vmovaps xmm0, [rsp]
0000707b885d4a79  vmovaps xmm1, [rsp+0x10]
0000707b885d4a7f  vmovaps xmm2, [rsp+0x20]
0000707b885d4a85  vmovaps xmm3, [rsp+0x30]
0000707b885d4a8b  vmovaps xmm4, [rsp+0x40]
0000707b885d4a91  vmovaps xmm5, [rsp+0x50]
0000707b885d4a97  vmovaps xmm6, [rsp+0x60]
0000707b885d4a9d  vmovaps xmm7, [rsp+0x70]
0000707b885d4aa3  vmovaps xmm9, [rsp+0x80]
0000707b885d4aac  vmovaps xmm10, [rsp+0x90]
0000707b885d4ab5  vmovaps xmm11, [rsp+0xA0]
0000707b885d4abe  vmovaps xmm12, [rsp+0xB0]
0000707b885d4ac7  vmovaps xmm13, [rsp+0xC0]
0000707b885d4ad0  vmovaps xmm14, [rsp+0xD0]
0000707b885d4ad9  vmovaps xmm15, [rsp+0xE0]
0000707b885d4ae2  add rsp, 0xF0
0000707b885d4ae9  pop r11
0000707b885d4aeb  pop r10
0000707b885d4aed  pop r9
0000707b885d4aef  pop r8
0000707b885d4af1  pop rsi
0000707b885d4af2  pop rdi
0000707b885d4af3  pop rdx
0000707b885d4af4  pop rcx
0000707b885d4af5  pop rax
0000707b885d4af6  add rsp, 0x08
0000707b885d4afa  jmp 0x0000707B885D01AF
0000707b885d4aff  sub rsp, 0x08
0000707b885d4b03  push rax
0000707b885d4b04  push rcx
0000707b885d4b05  push rdx
0000707b885d4b06  push rdi
0000707b885d4b07  push rsi
0000707b885d4b08  push r8
0000707b885d4b0a  push r9
0000707b885d4b0c  push r10
0000707b885d4b0e  push r11
0000707b885d4b10  sub rsp, 0xF0
0000707b885d4b17  vmovaps [rsp], xmm0
0000707b885d4b1c  vmovaps [rsp+0x10], xmm1
0000707b885d4b22  vmovaps [rsp+0x20], xmm2
0000707b885d4b28  vmovaps [rsp+0x30], xmm3
0000707b885d4b2e  vmovaps [rsp+0x40], xmm4
0000707b885d4b34  vmovaps [rsp+0x50], xmm5
0000707b885d4b3a  vmovaps [rsp+0x60], xmm6
0000707b885d4b40  vmovaps [rsp+0x70], xmm7
0000707b885d4b46  vmovaps [rsp+0x80], xmm8
0000707b885d4b4f  vmovaps [rsp+0x90], xmm10
0000707b885d4b58  vmovaps [rsp+0xA0], xmm11
0000707b885d4b61  vmovaps [rsp+0xB0], xmm12
0000707b885d4b6a  vmovaps [rsp+0xC0], xmm13
0000707b885d4b73  vmovaps [rsp+0xD0], xmm14
0000707b885d4b7c  vmovaps [rsp+0xE0], xmm15
0000707b885d4b85  sub rsp, 0x30
0000707b885d4b89  movaps [rsp], xmm9
0000707b885d4b8e  movaps [rsp+0x10], xmm1
0000707b885d4b93  movaps [rsp+0x20], xmm14
0000707b885d4b99  lea rdi, [rsp]
0000707b885d4b9d  mov esi, 0x00
0000707b885d4ba2  mov rax, 0x6471B35AC530
0000707b885d4bac  call rax
0000707b885d4bae  movaps xmm9, [rsp]
0000707b885d4bb3  add rsp, 0x30
0000707b885d4bb7  vmovaps xmm0, [rsp]
0000707b885d4bbc  vmovaps xmm1, [rsp+0x10]
0000707b885d4bc2  vmovaps xmm2, [rsp+0x20]
0000707b885d4bc8  vmovaps xmm3, [rsp+0x30]
0000707b885d4bce  vmovaps xmm4, [rsp+0x40]
0000707b885d4bd4  vmovaps xmm5, [rsp+0x50]
0000707b885d4bda  vmovaps xmm6, [rsp+0x60]
0000707b885d4be0  vmovaps xmm7, [rsp+0x70]
0000707b885d4be6  vmovaps xmm8, [rsp+0x80]
0000707b885d4bef  vmovaps xmm10, [rsp+0x90]
0000707b885d4bf8  vmovaps xmm11, [rsp+0xA0]
0000707b885d4c01  vmovaps xmm12, [rsp+0xB0]
0000707b885d4c0a  vmovaps xmm13, [rsp+0xC0]
0000707b885d4c13  vmovaps xmm14, [rsp+0xD0]
0000707b885d4c1c  vmovaps xmm15, [rsp+0xE0]
0000707b885d4c25  add rsp, 0xF0
0000707b885d4c2c  pop r11
0000707b885d4c2e  pop r10
0000707b885d4c30  pop r9
0000707b885d4c32  pop r8
0000707b885d4c34  pop rsi
0000707b885d4c35  pop rdi
0000707b885d4c36  pop rdx
0000707b885d4c37  pop rcx
0000707b885d4c38  pop rax
0000707b885d4c39  add rsp, 0x08
0000707b885d4c3d  jmp 0x0000707B885D01DD
0000707b885d4c42  sub rsp, 0x08
0000707b885d4c46  push rax
0000707b885d4c47  push rcx
0000707b885d4c48  push rdx
0000707b885d4c49  push rdi
0000707b885d4c4a  push rsi
0000707b885d4c4b  push r8
0000707b885d4c4d  push r9
0000707b885d4c4f  push r10
0000707b885d4c51  push r11
0000707b885d4c53  sub rsp, 0xF0
0000707b885d4c5a  vmovaps [rsp], xmm0
0000707b885d4c5f  vmovaps [rsp+0x10], xmm1
0000707b885d4c65  vmovaps [rsp+0x20], xmm2
0000707b885d4c6b  vmovaps [rsp+0x30], xmm3
0000707b885d4c71  vmovaps [rsp+0x40], xmm4
0000707b885d4c77  vmovaps [rsp+0x50], xmm5
0000707b885d4c7d  vmovaps [rsp+0x60], xmm6
0000707b885d4c83  vmovaps [rsp+0x70], xmm7
0000707b885d4c89  vmovaps [rsp+0x80], xmm8
0000707b885d4c92  vmovaps [rsp+0x90], xmm9
0000707b885d4c9b  vmovaps [rsp+0xA0], xmm10
0000707b885d4ca4  vmovaps [rsp+0xB0], xmm11
0000707b885d4cad  vmovaps [rsp+0xC0], xmm12
0000707b885d4cb6  vmovaps [rsp+0xD0], xmm13
0000707b885d4cbf  vmovaps [rsp+0xE0], xmm15
0000707b885d4cc8  sub rsp, 0x30
0000707b885d4ccc  movaps [rsp], xmm14
0000707b885d4cd1  movaps [rsp+0x10], xmm4
0000707b885d4cd6  movaps [rsp+0x20], xmm1
0000707b885d4cdb  lea rdi, [rsp]
0000707b885d4cdf  mov esi, 0x00
0000707b885d4ce4  mov rax, 0x6471B35AC530
0000707b885d4cee  call rax
0000707b885d4cf0  movaps xmm14, [rsp]
0000707b885d4cf5  add rsp, 0x30
0000707b885d4cf9  vmovaps xmm0, [rsp]
0000707b885d4cfe  vmovaps xmm1, [rsp+0x10]
0000707b885d4d04  vmovaps xmm2, [rsp+0x20]
0000707b885d4d0a  vmovaps xmm3, [rsp+0x30]
0000707b885d4d10  vmovaps xmm4, [rsp+0x40]
0000707b885d4d16  vmovaps xmm5, [rsp+0x50]
0000707b885d4d1c  vmovaps xmm6, [rsp+0x60]
0000707b885d4d22  vmovaps xmm7, [rsp+0x70]
0000707b885d4d28  vmovaps xmm8, [rsp+0x80]
0000707b885d4d31  vmovaps xmm9, [rsp+0x90]
0000707b885d4d3a  vmovaps xmm10, [rsp+0xA0]
0000707b885d4d43  vmovaps xmm11, [rsp+0xB0]
0000707b885d4d4c  vmovaps xmm12, [rsp+0xC0]
0000707b885d4d55  vmovaps xmm13, [rsp+0xD0]
0000707b885d4d5e  vmovaps xmm15, [rsp+0xE0]
0000707b885d4d67  add rsp, 0xF0
0000707b885d4d6e  pop r11
0000707b885d4d70  pop r10
0000707b885d4d72  pop r9
0000707b885d4d74  pop r8
0000707b885d4d76  pop rsi
0000707b885d4d77  pop rdi
0000707b885d4d78  pop rdx
0000707b885d4d79  pop rcx
0000707b885d4d7a  pop rax
0000707b885d4d7b  add rsp, 0x08
0000707b885d4d7f  jmp 0x0000707B885D0203
0000707b885d4d84  sub rsp, 0x08
0000707b885d4d88  push rax
0000707b885d4d89  push rcx
0000707b885d4d8a  push rdx
0000707b885d4d8b  push rdi
0000707b885d4d8c  push rsi
0000707b885d4d8d  push r8
0000707b885d4d8f  push r9
0000707b885d4d91  push r10
0000707b885d4d93  push r11
0000707b885d4d95  sub rsp, 0xF0
0000707b885d4d9c  vmovaps [rsp], xmm0
0000707b885d4da1  vmovaps [rsp+0x10], xmm2
0000707b885d4da7  vmovaps [rsp+0x20], xmm3
0000707b885d4dad  vmovaps [rsp+0x30], xmm4
0000707b885d4db3  vmovaps [rsp+0x40], xmm5
0000707b885d4db9  vmovaps [rsp+0x50], xmm6
0000707b885d4dbf  vmovaps [rsp+0x60], xmm7
0000707b885d4dc5  vmovaps [rsp+0x70], xmm8
0000707b885d4dcb  vmovaps [rsp+0x80], xmm9
0000707b885d4dd4  vmovaps [rsp+0x90], xmm10
0000707b885d4ddd  vmovaps [rsp+0xA0], xmm11
0000707b885d4de6  vmovaps [rsp+0xB0], xmm12
0000707b885d4def  vmovaps [rsp+0xC0], xmm13
0000707b885d4df8  vmovaps [rsp+0xD0], xmm14
0000707b885d4e01  vmovaps [rsp+0xE0], xmm15
0000707b885d4e0a  sub rsp, 0x30
0000707b885d4e0e  movaps [rsp], xmm1
0000707b885d4e12  movaps [rsp+0x10], xmm12
0000707b885d4e18  movaps [rsp+0x20], xmm11
0000707b885d4e1e  lea rdi, [rsp]
0000707b885d4e22  mov esi, 0x00
0000707b885d4e27  mov rax, 0x6471B35AC530
0000707b885d4e31  call rax
0000707b885d4e33  movaps xmm1, [rsp]
0000707b885d4e37  add rsp, 0x30
0000707b885d4e3b  vmovaps xmm0, [rsp]
0000707b885d4e40  vmovaps xmm2, [rsp+0x10]
0000707b885d4e46  vmovaps xmm3, [rsp+0x20]
0000707b885d4e4c  vmovaps xmm4, [rsp+0x30]
0000707b885d4e52  vmovaps xmm5, [rsp+0x40]
0000707b885d4e58  vmovaps xmm6, [rsp+0x50]
0000707b885d4e5e  vmovaps xmm7, [rsp+0x60]
0000707b885d4e64  vmovaps xmm8, [rsp+0x70]
0000707b885d4e6a  vmovaps xmm9, [rsp+0x80]
0000707b885d4e73  vmovaps xmm10, [rsp+0x90]
0000707b885d4e7c  vmovaps xmm11, [rsp+0xA0]
0000707b885d4e85  vmovaps xmm12, [rsp+0xB0]
0000707b885d4e8e  vmovaps xmm13, [rsp+0xC0]
0000707b885d4e97  vmovaps xmm14, [rsp+0xD0]
0000707b885d4ea0  vmovaps xmm15, [rsp+0xE0]
0000707b885d4ea9  add rsp, 0xF0
0000707b885d4eb0  pop r11
0000707b885d4eb2  pop r10
0000707b885d4eb4  pop r9
0000707b885d4eb6  pop r8
0000707b885d4eb8  pop rsi
0000707b885d4eb9  pop rdi
0000707b885d4eba  pop rdx
0000707b885d4ebb  pop rcx
0000707b885d4ebc  pop rax
0000707b885d4ebd  add rsp, 0x08
0000707b885d4ec1  jmp 0x0000707B885D0224
0000707b885d4ec6  call 0x0000707B884E20A0
0000707b885d4ecb  jmp 0x0000707B885D0232
0000707b885d4ed0  call 0x0000707B88409D70
0000707b885d4ed5  jmp 0x0000707B885D023C
0000707b885d4eda  sub rsp, 0x08
0000707b885d4ede  push rax
0000707b885d4edf  push rcx
0000707b885d4ee0  push rdx
0000707b885d4ee1  push rdi
0000707b885d4ee2  push rsi
0000707b885d4ee3  push r8
0000707b885d4ee5  push r9
0000707b885d4ee7  push r10
0000707b885d4ee9  push r11
0000707b885d4eeb  sub rsp, 0xF0
0000707b885d4ef2  vmovaps [rsp], xmm0
0000707b885d4ef7  vmovaps [rsp+0x10], xmm1
0000707b885d4efd  vmovaps [rsp+0x20], xmm2
0000707b885d4f03  vmovaps [rsp+0x30], xmm3
0000707b885d4f09  vmovaps [rsp+0x40], xmm4
0000707b885d4f0f  vmovaps [rsp+0x50], xmm5
0000707b885d4f15  vmovaps [rsp+0x60], xmm6
0000707b885d4f1b  vmovaps [rsp+0x70], xmm8
0000707b885d4f21  vmovaps [rsp+0x80], xmm9
0000707b885d4f2a  vmovaps [rsp+0x90], xmm10
0000707b885d4f33  vmovaps [rsp+0xA0], xmm11
0000707b885d4f3c  vmovaps [rsp+0xB0], xmm12
0000707b885d4f45  vmovaps [rsp+0xC0], xmm13
0000707b885d4f4e  vmovaps [rsp+0xD0], xmm14
0000707b885d4f57  vmovaps [rsp+0xE0], xmm15
0000707b885d4f60  sub rsp, 0x30
0000707b885d4f64  movaps [rsp], xmm7
0000707b885d4f68  movaps [rsp+0x10], xmm15
0000707b885d4f6e  movaps [rsp+0x20], xmm10
0000707b885d4f74  lea rdi, [rsp]
0000707b885d4f78  mov esi, 0x00
0000707b885d4f7d  mov rax, 0x6471B35AC530
0000707b885d4f87  call rax
0000707b885d4f89  movaps xmm7, [rsp]
0000707b885d4f8d  add rsp, 0x30
0000707b885d4f91  vmovaps xmm0, [rsp]
0000707b885d4f96  vmovaps xmm1, [rsp+0x10]
0000707b885d4f9c  vmovaps xmm2, [rsp+0x20]
0000707b885d4fa2  vmovaps xmm3, [rsp+0x30]
0000707b885d4fa8  vmovaps xmm4, [rsp+0x40]
0000707b885d4fae  vmovaps xmm5, [rsp+0x50]
0000707b885d4fb4  vmovaps xmm6, [rsp+0x60]
0000707b885d4fba  vmovaps xmm8, [rsp+0x70]
0000707b885d4fc0  vmovaps xmm9, [rsp+0x80]
0000707b885d4fc9  vmovaps xmm10, [rsp+0x90]
0000707b885d4fd2  vmovaps xmm11, [rsp+0xA0]
0000707b885d4fdb  vmovaps xmm12, [rsp+0xB0]
0000707b885d4fe4  vmovaps xmm13, [rsp+0xC0]
0000707b885d4fed  vmovaps xmm14, [rsp+0xD0]
0000707b885d4ff6  vmovaps xmm15, [rsp+0xE0]
0000707b885d4fff  add rsp, 0xF0
0000707b885d5006  pop r11
0000707b885d5008  pop r10
0000707b885d500a  pop r9
0000707b885d500c  pop r8
0000707b885d500e  pop rsi
0000707b885d500f  pop rdi
0000707b885d5010  pop rdx
0000707b885d5011  pop rcx
0000707b885d5012  pop rax
0000707b885d5013  add rsp, 0x08
0000707b885d5017  jmp 0x0000707B885D025D
0000707b885d501c  sub rsp, 0x08
0000707b885d5020  push rax
0000707b885d5021  push rcx
0000707b885d5022  push rdx
0000707b885d5023  push rdi
0000707b885d5024  push rsi
0000707b885d5025  push r8
0000707b885d5027  push r9
0000707b885d5029  push r10
0000707b885d502b  push r11
0000707b885d502d  sub rsp, 0xF0
0000707b885d5034  vmovaps [rsp], xmm0
0000707b885d5039  vmovaps [rsp+0x10], xmm1
0000707b885d503f  vmovaps [rsp+0x20], xmm2
0000707b885d5045  vmovaps [rsp+0x30], xmm3
0000707b885d504b  vmovaps [rsp+0x40], xmm4
0000707b885d5051  vmovaps [rsp+0x50], xmm5
0000707b885d5057  vmovaps [rsp+0x60], xmm6
0000707b885d505d  vmovaps [rsp+0x70], xmm7
0000707b885d5063  vmovaps [rsp+0x80], xmm8
0000707b885d506c  vmovaps [rsp+0x90], xmm9
0000707b885d5075  vmovaps [rsp+0xA0], xmm11
0000707b885d507e  vmovaps [rsp+0xB0], xmm12
0000707b885d5087  vmovaps [rsp+0xC0], xmm13
0000707b885d5090  vmovaps [rsp+0xD0], xmm14
0000707b885d5099  vmovaps [rsp+0xE0], xmm15
0000707b885d50a2  sub rsp, 0x30
0000707b885d50a6  movaps [rsp], xmm10
0000707b885d50ab  movaps [rsp+0x10], xmm11
0000707b885d50b1  movaps [rsp+0x20], xmm15
0000707b885d50b7  lea rdi, [rsp]
0000707b885d50bb  mov esi, 0x00
0000707b885d50c0  mov rax, 0x6471B35AC530
0000707b885d50ca  call rax
0000707b885d50cc  movaps xmm10, [rsp]
0000707b885d50d1  add rsp, 0x30
0000707b885d50d5  vmovaps xmm0, [rsp]
0000707b885d50da  vmovaps xmm1, [rsp+0x10]
0000707b885d50e0  vmovaps xmm2, [rsp+0x20]
0000707b885d50e6  vmovaps xmm3, [rsp+0x30]
0000707b885d50ec  vmovaps xmm4, [rsp+0x40]
0000707b885d50f2  vmovaps xmm5, [rsp+0x50]
0000707b885d50f8  vmovaps xmm6, [rsp+0x60]
0000707b885d50fe  vmovaps xmm7, [rsp+0x70]
0000707b885d5104  vmovaps xmm8, [rsp+0x80]
0000707b885d510d  vmovaps xmm9, [rsp+0x90]
0000707b885d5116  vmovaps xmm11, [rsp+0xA0]
0000707b885d511f  vmovaps xmm12, [rsp+0xB0]
0000707b885d5128  vmovaps xmm13, [rsp+0xC0]
0000707b885d5131  vmovaps xmm14, [rsp+0xD0]
0000707b885d513a  vmovaps xmm15, [rsp+0xE0]
0000707b885d5143  add rsp, 0xF0
0000707b885d514a  pop r11
0000707b885d514c  pop r10
0000707b885d514e  pop r9
0000707b885d5150  pop r8
0000707b885d5152  pop rsi
0000707b885d5153  pop rdi
0000707b885d5154  pop rdx
0000707b885d5155  pop rcx
0000707b885d5156  pop rax
0000707b885d5157  add rsp, 0x08
0000707b885d515b  jmp 0x0000707B885D028B
0000707b885d5160  sub rsp, 0x08
0000707b885d5164  push rax
0000707b885d5165  push rcx
0000707b885d5166  push rdx
0000707b885d5167  push rdi
0000707b885d5168  push rsi
0000707b885d5169  push r8
0000707b885d516b  push r9
0000707b885d516d  push r10
0000707b885d516f  push r11
0000707b885d5171  sub rsp, 0xF0
0000707b885d5178  vmovaps [rsp], xmm0
0000707b885d517d  vmovaps [rsp+0x10], xmm1
0000707b885d5183  vmovaps [rsp+0x20], xmm2
0000707b885d5189  vmovaps [rsp+0x30], xmm3
0000707b885d518f  vmovaps [rsp+0x40], xmm4
0000707b885d5195  vmovaps [rsp+0x50], xmm5
0000707b885d519b  vmovaps [rsp+0x60], xmm6
0000707b885d51a1  vmovaps [rsp+0x70], xmm7
0000707b885d51a7  vmovaps [rsp+0x80], xmm8
0000707b885d51b0  vmovaps [rsp+0x90], xmm9
0000707b885d51b9  vmovaps [rsp+0xA0], xmm10
0000707b885d51c2  vmovaps [rsp+0xB0], xmm12
0000707b885d51cb  vmovaps [rsp+0xC0], xmm13
0000707b885d51d4  vmovaps [rsp+0xD0], xmm14
0000707b885d51dd  vmovaps [rsp+0xE0], xmm15
0000707b885d51e6  sub rsp, 0x30
0000707b885d51ea  movaps [rsp], xmm11
0000707b885d51ef  movaps [rsp+0x10], xmm12
0000707b885d51f5  movaps [rsp+0x20], xmm15
0000707b885d51fb  lea rdi, [rsp]
0000707b885d51ff  mov esi, 0x00
0000707b885d5204  mov rax, 0x6471B35AC530
0000707b885d520e  call rax
0000707b885d5210  movaps xmm11, [rsp]
0000707b885d5215  add rsp, 0x30
0000707b885d5219  vmovaps xmm0, [rsp]
0000707b885d521e  vmovaps xmm1, [rsp+0x10]
0000707b885d5224  vmovaps xmm2, [rsp+0x20]
0000707b885d522a  vmovaps xmm3, [rsp+0x30]
0000707b885d5230  vmovaps xmm4, [rsp+0x40]
0000707b885d5236  vmovaps xmm5, [rsp+0x50]
0000707b885d523c  vmovaps xmm6, [rsp+0x60]
0000707b885d5242  vmovaps xmm7, [rsp+0x70]
0000707b885d5248  vmovaps xmm8, [rsp+0x80]
0000707b885d5251  vmovaps xmm9, [rsp+0x90]
0000707b885d525a  vmovaps xmm10, [rsp+0xA0]
0000707b885d5263  vmovaps xmm12, [rsp+0xB0]
0000707b885d526c  vmovaps xmm13, [rsp+0xC0]
0000707b885d5275  vmovaps xmm14, [rsp+0xD0]
0000707b885d527e  vmovaps xmm15, [rsp+0xE0]
0000707b885d5287  add rsp, 0xF0
0000707b885d528e  pop r11
0000707b885d5290  pop r10
0000707b885d5292  pop r9
0000707b885d5294  pop r8
0000707b885d5296  pop rsi
0000707b885d5297  pop rdi
0000707b885d5298  pop rdx
0000707b885d5299  pop rcx
0000707b885d529a  pop rax
0000707b885d529b  add rsp, 0x08
0000707b885d529f  jmp 0x0000707B885D02B9
0000707b885d52a4  sub rsp, 0x08
0000707b885d52a8  push rax
0000707b885d52a9  push rcx
0000707b885d52aa  push rdx
0000707b885d52ab  push rdi
0000707b885d52ac  push rsi
0000707b885d52ad  push r8
0000707b885d52af  push r9
0000707b885d52b1  push r10
0000707b885d52b3  push r11
0000707b885d52b5  sub rsp, 0xF0
0000707b885d52bc  vmovaps [rsp], xmm0
0000707b885d52c1  vmovaps [rsp+0x10], xmm1
0000707b885d52c7  vmovaps [rsp+0x20], xmm2
0000707b885d52cd  vmovaps [rsp+0x30], xmm3
0000707b885d52d3  vmovaps [rsp+0x40], xmm4
0000707b885d52d9  vmovaps [rsp+0x50], xmm5
0000707b885d52df  vmovaps [rsp+0x60], xmm6
0000707b885d52e5  vmovaps [rsp+0x70], xmm7
0000707b885d52eb  vmovaps [rsp+0x80], xmm8
0000707b885d52f4  vmovaps [rsp+0x90], xmm9
0000707b885d52fd  vmovaps [rsp+0xA0], xmm10
0000707b885d5306  vmovaps [rsp+0xB0], xmm11
0000707b885d530f  vmovaps [rsp+0xC0], xmm12
0000707b885d5318  vmovaps [rsp+0xD0], xmm13
0000707b885d5321  vmovaps [rsp+0xE0], xmm14
0000707b885d532a  sub rsp, 0x30
0000707b885d532e  movaps [rsp], xmm15
0000707b885d5333  movaps [rsp+0x10], xmm13
0000707b885d5339  movaps [rsp+0x20], xmm9
0000707b885d533f  lea rdi, [rsp]
0000707b885d5343  mov esi, 0x00
0000707b885d5348  mov rax, 0x6471B35AC530
0000707b885d5352  call rax
0000707b885d5354  movaps xmm15, [rsp]
0000707b885d5359  add rsp, 0x30
0000707b885d535d  vmovaps xmm0, [rsp]
0000707b885d5362  vmovaps xmm1, [rsp+0x10]
0000707b885d5368  vmovaps xmm2, [rsp+0x20]
0000707b885d536e  vmovaps xmm3, [rsp+0x30]
0000707b885d5374  vmovaps xmm4, [rsp+0x40]
0000707b885d537a  vmovaps xmm5, [rsp+0x50]
0000707b885d5380  vmovaps xmm6, [rsp+0x60]
0000707b885d5386  vmovaps xmm7, [rsp+0x70]
0000707b885d538c  vmovaps xmm8, [rsp+0x80]
0000707b885d5395  vmovaps xmm9, [rsp+0x90]
0000707b885d539e  vmovaps xmm10, [rsp+0xA0]
0000707b885d53a7  vmovaps xmm11, [rsp+0xB0]
0000707b885d53b0  vmovaps xmm12, [rsp+0xC0]
0000707b885d53b9  vmovaps xmm13, [rsp+0xD0]
0000707b885d53c2  vmovaps xmm14, [rsp+0xE0]
0000707b885d53cb  add rsp, 0xF0
0000707b885d53d2  pop r11
0000707b885d53d4  pop r10
0000707b885d53d6  pop r9
0000707b885d53d8  pop r8
0000707b885d53da  pop rsi
0000707b885d53db  pop rdi
0000707b885d53dc  pop rdx
0000707b885d53dd  pop rcx
0000707b885d53de  pop rax
0000707b885d53df  add rsp, 0x08
0000707b885d53e3  jmp 0x0000707B885D02D4
0000707b885d53e8  sub rsp, 0x08
0000707b885d53ec  push rax
0000707b885d53ed  push rcx
0000707b885d53ee  push rdx
0000707b885d53ef  push rdi
0000707b885d53f0  push rsi
0000707b885d53f1  push r8
0000707b885d53f3  push r9
0000707b885d53f5  push r10
0000707b885d53f7  push r11
0000707b885d53f9  sub rsp, 0xF0
0000707b885d5400  vmovaps [rsp], xmm0
0000707b885d5405  vmovaps [rsp+0x10], xmm1
0000707b885d540b  vmovaps [rsp+0x20], xmm2
0000707b885d5411  vmovaps [rsp+0x30], xmm3
0000707b885d5417  vmovaps [rsp+0x40], xmm4
0000707b885d541d  vmovaps [rsp+0x50], xmm5
0000707b885d5423  vmovaps [rsp+0x60], xmm6
0000707b885d5429  vmovaps [rsp+0x70], xmm7
0000707b885d542f  vmovaps [rsp+0x80], xmm8
0000707b885d5438  vmovaps [rsp+0x90], xmm9
0000707b885d5441  vmovaps [rsp+0xA0], xmm10
0000707b885d544a  vmovaps [rsp+0xB0], xmm11
0000707b885d5453  vmovaps [rsp+0xC0], xmm12
0000707b885d545c  vmovaps [rsp+0xD0], xmm14
0000707b885d5465  vmovaps [rsp+0xE0], xmm15
0000707b885d546e  sub rsp, 0x30
0000707b885d5472  movaps [rsp], xmm13
0000707b885d5477  movaps [rsp+0x10], xmm8
0000707b885d547d  movaps [rsp+0x20], xmm14
0000707b885d5483  lea rdi, [rsp]
0000707b885d5487  mov esi, 0x00
0000707b885d548c  mov rax, 0x6471B35AC530
0000707b885d5496  call rax
0000707b885d5498  movaps xmm13, [rsp]
0000707b885d549d  add rsp, 0x30
0000707b885d54a1  vmovaps xmm0, [rsp]
0000707b885d54a6  vmovaps xmm1, [rsp+0x10]
0000707b885d54ac  vmovaps xmm2, [rsp+0x20]
0000707b885d54b2  vmovaps xmm3, [rsp+0x30]
0000707b885d54b8  vmovaps xmm4, [rsp+0x40]
0000707b885d54be  vmovaps xmm5, [rsp+0x50]
0000707b885d54c4  vmovaps xmm6, [rsp+0x60]
0000707b885d54ca  vmovaps xmm7, [rsp+0x70]
0000707b885d54d0  vmovaps xmm8, [rsp+0x80]
0000707b885d54d9  vmovaps xmm9, [rsp+0x90]
0000707b885d54e2  vmovaps xmm10, [rsp+0xA0]
0000707b885d54eb  vmovaps xmm11, [rsp+0xB0]
0000707b885d54f4  vmovaps xmm12, [rsp+0xC0]
0000707b885d54fd  vmovaps xmm14, [rsp+0xD0]
0000707b885d5506  vmovaps xmm15, [rsp+0xE0]
0000707b885d550f  add rsp, 0xF0
0000707b885d5516  pop r11
0000707b885d5518  pop r10
0000707b885d551a  pop r9
0000707b885d551c  pop r8
0000707b885d551e  pop rsi
0000707b885d551f  pop rdi
0000707b885d5520  pop rdx
0000707b885d5521  pop rcx
0000707b885d5522  pop rax
0000707b885d5523  add rsp, 0x08
0000707b885d5527  jmp 0x0000707B885D02F7
0000707b885d552c  sub rsp, 0x08
0000707b885d5530  push rax
0000707b885d5531  push rcx
0000707b885d5532  push rdx
0000707b885d5533  push rdi
0000707b885d5534  push rsi
0000707b885d5535  push r8
0000707b885d5537  push r9
0000707b885d5539  push r10
0000707b885d553b  push r11
0000707b885d553d  sub rsp, 0xF0
0000707b885d5544  vmovaps [rsp], xmm0
0000707b885d5549  vmovaps [rsp+0x10], xmm1
0000707b885d554f  vmovaps [rsp+0x20], xmm2
0000707b885d5555  vmovaps [rsp+0x30], xmm3
0000707b885d555b  vmovaps [rsp+0x40], xmm4
0000707b885d5561  vmovaps [rsp+0x50], xmm5
0000707b885d5567  vmovaps [rsp+0x60], xmm6
0000707b885d556d  vmovaps [rsp+0x70], xmm7
0000707b885d5573  vmovaps [rsp+0x80], xmm8
0000707b885d557c  vmovaps [rsp+0x90], xmm9
0000707b885d5585  vmovaps [rsp+0xA0], xmm10
0000707b885d558e  vmovaps [rsp+0xB0], xmm11
0000707b885d5597  vmovaps [rsp+0xC0], xmm12
0000707b885d55a0  vmovaps [rsp+0xD0], xmm13
0000707b885d55a9  vmovaps [rsp+0xE0], xmm15
0000707b885d55b2  sub rsp, 0x30
0000707b885d55b6  movaps [rsp], xmm14
0000707b885d55bb  movaps [rsp+0x10], xmm1
0000707b885d55c0  movaps [rsp+0x20], xmm10
0000707b885d55c6  lea rdi, [rsp]
0000707b885d55ca  mov esi, 0x00
0000707b885d55cf  mov rax, 0x6471B35AC530
0000707b885d55d9  call rax
0000707b885d55db  movaps xmm14, [rsp]
0000707b885d55e0  add rsp, 0x30
0000707b885d55e4  vmovaps xmm0, [rsp]
0000707b885d55e9  vmovaps xmm1, [rsp+0x10]
0000707b885d55ef  vmovaps xmm2, [rsp+0x20]
0000707b885d55f5  vmovaps xmm3, [rsp+0x30]
0000707b885d55fb  vmovaps xmm4, [rsp+0x40]
0000707b885d5601  vmovaps xmm5, [rsp+0x50]
0000707b885d5607  vmovaps xmm6, [rsp+0x60]
0000707b885d560d  vmovaps xmm7, [rsp+0x70]
0000707b885d5613  vmovaps xmm8, [rsp+0x80]
0000707b885d561c  vmovaps xmm9, [rsp+0x90]
0000707b885d5625  vmovaps xmm10, [rsp+0xA0]
0000707b885d562e  vmovaps xmm11, [rsp+0xB0]
0000707b885d5637  vmovaps xmm12, [rsp+0xC0]
0000707b885d5640  vmovaps xmm13, [rsp+0xD0]
0000707b885d5649  vmovaps xmm15, [rsp+0xE0]
0000707b885d5652  add rsp, 0xF0
0000707b885d5659  pop r11
0000707b885d565b  pop r10
0000707b885d565d  pop r9
0000707b885d565f  pop r8
0000707b885d5661  pop rsi
0000707b885d5662  pop rdi
0000707b885d5663  pop rdx
0000707b885d5664  pop rcx
0000707b885d5665  pop rax
0000707b885d5666  add rsp, 0x08
0000707b885d566a  jmp 0x0000707B885D031A
0000707b885d566f  sub rsp, 0x08
0000707b885d5673  push rax
0000707b885d5674  push rcx
0000707b885d5675  push rdx
0000707b885d5676  push rdi
0000707b885d5677  push rsi
0000707b885d5678  push r8
0000707b885d567a  push r9
0000707b885d567c  push r10
0000707b885d567e  push r11
0000707b885d5680  sub rsp, 0xF0
0000707b885d5687  vmovaps [rsp], xmm0
0000707b885d568c  vmovaps [rsp+0x10], xmm2
0000707b885d5692  vmovaps [rsp+0x20], xmm3
0000707b885d5698  vmovaps [rsp+0x30], xmm4
0000707b885d569e  vmovaps [rsp+0x40], xmm5
0000707b885d56a4  vmovaps [rsp+0x50], xmm6
0000707b885d56aa  vmovaps [rsp+0x60], xmm7
0000707b885d56b0  vmovaps [rsp+0x70], xmm8
0000707b885d56b6  vmovaps [rsp+0x80], xmm9
0000707b885d56bf  vmovaps [rsp+0x90], xmm10
0000707b885d56c8  vmovaps [rsp+0xA0], xmm11
0000707b885d56d1  vmovaps [rsp+0xB0], xmm12
0000707b885d56da  vmovaps [rsp+0xC0], xmm13
0000707b885d56e3  vmovaps [rsp+0xD0], xmm14
0000707b885d56ec  vmovaps [rsp+0xE0], xmm15
0000707b885d56f5  sub rsp, 0x30
0000707b885d56f9  movaps [rsp], xmm1
0000707b885d56fd  movaps [rsp+0x10], xmm7
0000707b885d5702  movaps [rsp+0x20], xmm11
0000707b885d5708  lea rdi, [rsp]
0000707b885d570c  mov esi, 0x00
0000707b885d5711  mov rax, 0x6471B35AC530
0000707b885d571b  call rax
0000707b885d571d  movaps xmm1, [rsp]
0000707b885d5721  add rsp, 0x30
0000707b885d5725  vmovaps xmm0, [rsp]
0000707b885d572a  vmovaps xmm2, [rsp+0x10]
0000707b885d5730  vmovaps xmm3, [rsp+0x20]
0000707b885d5736  vmovaps xmm4, [rsp+0x30]
0000707b885d573c  vmovaps xmm5, [rsp+0x40]
0000707b885d5742  vmovaps xmm6, [rsp+0x50]
0000707b885d5748  vmovaps xmm7, [rsp+0x60]
0000707b885d574e  vmovaps xmm8, [rsp+0x70]
0000707b885d5754  vmovaps xmm9, [rsp+0x80]
0000707b885d575d  vmovaps xmm10, [rsp+0x90]
0000707b885d5766  vmovaps xmm11, [rsp+0xA0]
0000707b885d576f  vmovaps xmm12, [rsp+0xB0]
0000707b885d5778  vmovaps xmm13, [rsp+0xC0]
0000707b885d5781  vmovaps xmm14, [rsp+0xD0]
0000707b885d578a  vmovaps xmm15, [rsp+0xE0]
0000707b885d5793  add rsp, 0xF0
0000707b885d579a  pop r11
0000707b885d579c  pop r10
0000707b885d579e  pop r9
0000707b885d57a0  pop r8
0000707b885d57a2  pop rsi
0000707b885d57a3  pop rdi
0000707b885d57a4  pop rdx
0000707b885d57a5  pop rcx
0000707b885d57a6  pop rax
0000707b885d57a7  add rsp, 0x08
0000707b885d57ab  jmp 0x0000707B885D033B
0000707b885d57b0  call 0x0000707B8840E880
0000707b885d57b5  jmp 0x0000707B885D034E
0000707b885d57ba  call 0x0000707B8840C380
0000707b885d57bf  jmp 0x0000707B885D0359
0000707b885d57c4  call 0x0000707B8840D600
0000707b885d57c9  jmp 0x0000707B885D0364
0000707b885d57ce  call 0x0000707B883FF540
0000707b885d57d3  jmp 0x0000707B885D036F
0000707b885d57d8  int3
0000707b885d57d9  nop [rax], eax
0000707b885d57e0  mov rax, [r15+0x40]
0000707b885d57e4  mov r14, [r15+0x58]
0000707b885d57e8  lea r12, [rax+r14*1]
0000707b885d57ec  movaps xmm1, [r15+0x1D0]
0000707b885d57f4  vmovaps [rsp+0x10], xmm1
0000707b885d57fa  vmovaps xmm15, [rsp+0x10]
0000707b885d5800  por xmm1, xmm15
0000707b885d5805  movaps xmm14, [r15+0x1A0]
0000707b885d580d  vmovaps [rsp+0x10], xmm14
0000707b885d5813  vmovaps xmm13, [rsp+0x10]
0000707b885d5819  por xmm14, xmm13
0000707b885d581e  lea rax, [r12+0x30]
0000707b885d5823  mov r11, [r13+rax*1]
0000707b885d5828  lea rax, [r12+0x38]
0000707b885d582d  mov r10, [r13+rax*1]
0000707b885d5832  movq xmm13, r11
0000707b885d5837  movq xmm12, r10
0000707b885d583c  movq xmm13, xmm13
0000707b885d5841  vmovaps [rsp+0x10], xmm13
0000707b885d5847  movq xmm13, xmm13
0000707b885d584c  movaps [r15+0x130], xmm13
0000707b885d5854  movq xmm12, xmm12
0000707b885d5859  vmovaps [rsp+0x20], xmm12
0000707b885d585f  movq xmm12, xmm12
0000707b885d5864  movaps [r15+0x280], xmm12
0000707b885d586c  movaps xmm13, [r15+0x270]
0000707b885d5874  vmovaps [rsp+0x30], xmm13
0000707b885d587a  vmovaps xmm12, [rsp+0x30]
0000707b885d5880  por xmm13, xmm12
0000707b885d5885  lea rax, [r12+0x20]
0000707b885d588a  mov r11, [r13+rax*1]
0000707b885d588f  lea rax, [r12+0x28]
0000707b885d5894  mov r10, [r13+rax*1]
0000707b885d5899  movq xmm12, r11
0000707b885d589e  movq xmm11, r10
0000707b885d58a3  movq xmm12, xmm12
0000707b885d58a8  vmovaps [rsp+0x30], xmm12
0000707b885d58ae  movq xmm12, xmm12
0000707b885d58b3  movaps [r15+0x150], xmm12
0000707b885d58bb  movq xmm11, xmm11
0000707b885d58c0  vmovaps [rsp+0x40], xmm11
0000707b885d58c6  movq xmm11, xmm11
0000707b885d58cb  movaps [r15+0x140], xmm11
0000707b885d58d3  lea rax, [r12+0x10]
0000707b885d58d8  mov r11, [r13+rax*1]
0000707b885d58dd  lea rax, [r12+0x18]
0000707b885d58e2  mov r10, [r13+rax*1]
0000707b885d58e7  movq xmm12, r11
0000707b885d58ec  movq xmm11, r10
0000707b885d58f1  movq xmm12, xmm12
0000707b885d58f6  vmovaps [rsp+0x50], xmm12
0000707b885d58fc  movq xmm12, xmm12
0000707b885d5901  movaps [r15+0x170], xmm12
0000707b885d5909  movq xmm11, xmm11
0000707b885d590e  vmovaps [rsp+0x60], xmm11
0000707b885d5914  movq xmm11, xmm11
0000707b885d5919  movaps [r15+0x160], xmm11
0000707b885d5921  mov rax, [r13+r12*1]
0000707b885d5926  vmovq xmm12, rax
0000707b885d592b  vpbroadcastq xmm12, xmm12
0000707b885d5930  lea rax, [r12+0x08]
0000707b885d5935  mov r12, [r13+rax*1]
0000707b885d593a  movq xmm11, r12
0000707b885d593f  movaps [r15+0x230], xmm11
0000707b885d5947  mov rax, [r15+0xF8]
0000707b885d594e  lea r12, [rax+0x50]
0000707b885d5952  movups xmm11, [r13+r12*1]
0000707b885d5958  lea r12, [rax+0x60]
0000707b885d595c  movups xmm10, [r13+r12*1]
0000707b885d5962  lea r12, [rax+0x30]
0000707b885d5966  movups xmm9, [r13+r12*1]
0000707b885d596c  mov r12, [r15+0x50]
0000707b885d5970  lea r11, [r12+r14*1]
0000707b885d5974  mov [r15+0x60], r11
0000707b885d5978  lea r12, [r14+0x40]
0000707b885d597c  mov [r15+0x58], r12
0000707b885d5980  movaps xmm8, xmm12
0000707b885d5984  mulpd xmm8, xmm15
0000707b885d5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000707b885d598f  ptest xmm7, xmm7
0000707b885d5994  jnz 0x0000707B885D67B7
0000707b885d599a  movq xmm15, qword ptr [r15+0x230]
0000707b885d59a3  vmovaps [rsp+0x70], xmm15
0000707b885d59a9  vpermilpd xmm15, xmm15, 0x00
0000707b885d59af  movaps xmm7, xmm9
0000707b885d59b3  mulpd xmm7, xmm15
0000707b885d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000707b885d59bd  ptest xmm6, xmm6
0000707b885d59c2  jnz 0x0000707B885D68FB
0000707b885d59c8  vxorps xmm15, xmm15, xmm15
0000707b885d59cd  vpbroadcastq xmm15, xmm15
0000707b885d59d2  movaps xmm9, xmm12
0000707b885d59d6  mulpd xmm9, xmm10
0000707b885d59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000707b885d59e1  ptest xmm6, xmm6
0000707b885d59e6  jnz 0x0000707B885D6A3D
0000707b885d59ec  movaps xmm10, xmm12
0000707b885d59f0  mulpd xmm10, xmm11
0000707b885d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000707b885d59fb  ptest xmm6, xmm6
0000707b885d5a00  jnz 0x0000707B885D6B81
0000707b885d5a06  movaps xmm11, [r15+0x1F0]
0000707b885d5a0e  movaps xmm6, xmm12
0000707b885d5a12  mulpd xmm6, xmm11
0000707b885d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000707b885d5a1c  ptest xmm5, xmm5
0000707b885d5a21  jnz 0x0000707B885D6CC5
0000707b885d5a27  movaps xmm12, [r15+0x2A0]
0000707b885d5a2f  vmovaps [rsp+0x80], xmm12
0000707b885d5a38  vmovaps xmm11, [rsp+0x80]
0000707b885d5a41  por xmm12, xmm11
0000707b885d5a46  movaps xmm11, [r15+0x250]
0000707b885d5a4e  vmovaps [rsp+0x80], xmm11
0000707b885d5a57  vmovaps xmm5, [rsp+0x80]
0000707b885d5a60  por xmm11, xmm5
0000707b885d5a65  vmovaps xmm4, [rsp+0x70]
0000707b885d5a6b  vpermilpd xmm4, xmm4, 0x00
0000707b885d5a71  movaps xmm3, xmm5
0000707b885d5a74  mulpd xmm3, xmm4
0000707b885d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000707b885d5a7d  ptest xmm2, xmm2
0000707b885d5a82  jnz 0x0000707B885D6E07
0000707b885d5a88  mov [rsp+0x80], rax
0000707b885d5a90  xor eax, eax
0000707b885d5a92  mov r14d, 0x200
0000707b885d5a98  cmp r12, r14
0000707b885d5a9b  cmc
0000707b885d5a9c  lahf
0000707b885d5a9d  seto al
0000707b885d5aa0  mov [r15+0x108], eax
0000707b885d5aa7  movaps xmm5, xmm8
0000707b885d5aab  addpd xmm5, xmm15
0000707b885d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000707b885d5ab5  ptest xmm4, xmm4
0000707b885d5aba  jnz 0x0000707B885D6F47
0000707b885d5ac0  movaps xmm8, [r15+0x1B0]
0000707b885d5ac8  movaps xmm4, xmm9
0000707b885d5acc  addpd xmm4, xmm8
0000707b885d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000707b885d5ad6  ptest xmm2, xmm2
0000707b885d5adb  jnz 0x0000707B885D7089
0000707b885d5ae1  movaps xmm9, xmm10
0000707b885d5ae5  addpd xmm9, xmm8
0000707b885d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000707b885d5af0  ptest xmm2, xmm2
0000707b885d5af5  jnz 0x0000707B885D71CB
0000707b885d5afb  movaps xmm10, [r15+0x2F0]
0000707b885d5b03  vmovaps [rsp+0x90], xmm10
0000707b885d5b0c  vmovaps xmm8, [rsp+0x90]
0000707b885d5b15  por xmm10, xmm8
0000707b885d5b1a  movaps xmm8, [r15+0x2E0]
0000707b885d5b22  vmovaps [rsp+0x90], xmm8
0000707b885d5b2b  vmovaps xmm2, [rsp+0x90]
0000707b885d5b34  por xmm8, xmm2
0000707b885d5b39  movaps xmm2, [r15+0x2D0]
0000707b885d5b41  vmovaps [rsp+0x90], xmm2
0000707b885d5b4a  vmovaps [rsp+0xA0], xmm1
0000707b885d5b53  vmovaps xmm1, [rsp+0x90]
0000707b885d5b5c  por xmm2, xmm1
0000707b885d5b60  movaps xmm1, [r15+0x200]
0000707b885d5b68  vmovaps [rsp+0x90], xmm1
0000707b885d5b71  vmovaps [rsp+0xB0], xmm15
0000707b885d5b7a  vmovaps xmm15, [rsp+0x90]
0000707b885d5b83  por xmm1, xmm15
0000707b885d5b88  movaps xmm15, [r15+0x1C0]
0000707b885d5b90  vmovaps [rsp+0x90], xmm15
0000707b885d5b99  vmovaps [rsp+0xC0], xmm1
0000707b885d5ba2  vmovaps xmm1, [rsp+0x90]
0000707b885d5bab  por xmm15, xmm1
0000707b885d5bb0  movaps xmm1, [r15+0x190]
0000707b885d5bb8  vmovaps [rsp+0x90], xmm1
0000707b885d5bc1  vmovaps [rsp+0xD0], xmm15
0000707b885d5bca  vmovaps xmm15, [rsp+0x90]
0000707b885d5bd3  por xmm1, xmm15
0000707b885d5bd8  movaps xmm15, [r15+0x300]
0000707b885d5be0  vmovaps [rsp+0x90], xmm15
0000707b885d5be9  vmovaps [rsp+0xE0], xmm1
0000707b885d5bf2  vmovaps xmm1, [rsp+0x90]
0000707b885d5bfb  por xmm15, xmm1
0000707b885d5c00  mov rax, [rsp+0x80]
0000707b885d5c08  lea r14, [rax+0xA0]
0000707b885d5c0f  movups xmm1, [r13+r14*1]
0000707b885d5c15  lea r14, [rax+0xB0]
0000707b885d5c1c  vmovaps [rsp+0x80], xmm1
0000707b885d5c25  movups xmm1, [r13+r14*1]
0000707b885d5c2b  vmovaps [rsp+0x90], xmm1
0000707b885d5c34  vmovaps [rsp+0xF0], xmm15
0000707b885d5c3d  vmovaps xmm15, [rsp+0xB0]
0000707b885d5c46  vmovaps [rsp+0xB0], xmm14
0000707b885d5c4f  movaps xmm1, xmm6
0000707b885d5c52  addpd xmm1, xmm15
0000707b885d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000707b885d5c5c  ptest xmm14, xmm14
0000707b885d5c62  jnz 0x0000707B885D7323
0000707b885d5c68  lea r14, [rax+0xF0]
0000707b885d5c6f  movups xmm15, [r13+r14*1]
0000707b885d5c75  movaps xmm14, xmm4
0000707b885d5c79  addpd xmm14, xmm3
0000707b885d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000707b885d5c84  ptest xmm6, xmm6
0000707b885d5c89  jnz 0x0000707B885D746E
0000707b885d5c8f  movaps xmm6, xmm9
0000707b885d5c93  addpd xmm6, xmm7
0000707b885d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000707b885d5c9c  ptest xmm4, xmm4
0000707b885d5ca1  jnz 0x0000707B885D75B0
0000707b885d5ca7  vmovaps xmm9, [rsp+0x70]
0000707b885d5cad  vpermilpd xmm9, xmm9, 0x00
0000707b885d5cb3  vmovaps xmm4, [rsp+0x90]
0000707b885d5cbc  movaps xmm7, xmm4
0000707b885d5cbf  mulpd xmm7, xmm9
0000707b885d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000707b885d5cc9  ptest xmm3, xmm3
0000707b885d5cce  jnz 0x0000707B885D76F1
0000707b885d5cd4  vmovaps xmm9, [rsp+0x50]
0000707b885d5cda  vpermilpd xmm9, xmm9, 0x00
0000707b885d5ce0  movaps xmm4, xmm15
0000707b885d5ce4  mulpd xmm4, xmm9
0000707b885d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000707b885d5cee  ptest xmm3, xmm3
0000707b885d5cf3  jnz 0x0000707B885D7832
0000707b885d5cf9  lea r14, [rax+0xE0]
0000707b885d5d00  movups xmm15, [r13+r14*1]
0000707b885d5d06  vmovaps xmm9, [rsp+0x70]
0000707b885d5d0c  vpermilpd xmm9, xmm9, 0x00
0000707b885d5d12  vmovaps [rsp+0x70], xmm1
0000707b885d5d18  vmovaps xmm1, [rsp+0x80]
0000707b885d5d21  vmovaps [rsp+0x80], xmm15
0000707b885d5d2a  movaps xmm3, xmm1
0000707b885d5d2d  mulpd xmm3, xmm9
0000707b885d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000707b885d5d37  ptest xmm15, xmm15
0000707b885d5d3d  jnz 0x0000707B885D797E
0000707b885d5d43  vmovaps xmm1, [rsp+0xF0]
0000707b885d5d4c  vmovaps xmm15, [rsp+0xF0]
0000707b885d5d55  por xmm1, xmm15
0000707b885d5d5a  movaps [r15+0x300], xmm1
0000707b885d5d62  vmovaps xmm15, [rsp+0xE0]
0000707b885d5d6b  vmovaps xmm9, [rsp+0xE0]
0000707b885d5d74  por xmm15, xmm9
0000707b885d5d79  movaps [r15+0x190], xmm15
0000707b885d5d81  vmovaps xmm9, [rsp+0x50]
0000707b885d5d87  vpermilpd xmm9, xmm9, 0x00
0000707b885d5d8d  vmovaps [rsp+0x90], xmm1
0000707b885d5d96  vmovaps [rsp+0xE0], xmm15
0000707b885d5d9f  vmovaps xmm15, [rsp+0x80]
0000707b885d5da8  vmovaps [rsp+0x80], xmm14
0000707b885d5db1  movaps xmm1, xmm15
0000707b885d5db5  mulpd xmm1, xmm9
0000707b885d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000707b885d5dbf  ptest xmm14, xmm14
0000707b885d5dc5  jnz 0x0000707B885D7ABF
0000707b885d5dcb  lea r14, [rax+0x90]
0000707b885d5dd2  movups xmm15, [r13+r14*1]
0000707b885d5dd8  vmovaps xmm14, [rsp+0xD0]
0000707b885d5de1  vmovaps xmm9, [rsp+0xD0]
0000707b885d5dea  por xmm14, xmm9
0000707b885d5def  movaps [r15+0x1C0], xmm14
0000707b885d5df7  vmovaps xmm9, [rsp+0xC0]
0000707b885d5e00  vmovaps [rsp+0xD0], xmm1
0000707b885d5e09  vmovaps xmm1, [rsp+0xC0]
0000707b885d5e12  por xmm9, xmm1
0000707b885d5e17  movaps [r15+0x200], xmm9
0000707b885d5e1f  vmovaps [rsp+0xC0], xmm2
0000707b885d5e28  vmovaps xmm1, [rsp+0xC0]
0000707b885d5e31  por xmm2, xmm1
0000707b885d5e35  movaps [r15+0x2D0], xmm2
0000707b885d5e3d  vmovaps [rsp+0xC0], xmm8
0000707b885d5e46  vmovaps xmm1, [rsp+0xC0]
0000707b885d5e4f  por xmm8, xmm1
0000707b885d5e54  movaps [r15+0x2E0], xmm8
0000707b885d5e5c  vmovaps [rsp+0xC0], xmm15
0000707b885d5e65  movaps xmm1, xmm5
0000707b885d5e68  addpd xmm1, xmm7
0000707b885d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000707b885d5e71  ptest xmm15, xmm15
0000707b885d5e77  jnz 0x0000707B885D7C0B
0000707b885d5e7d  vmovaps xmm15, [rsp+0x50]
0000707b885d5e83  vpermilpd xmm15, xmm15, 0x00
0000707b885d5e89  vmovaps xmm5, [rsp+0xC0]
0000707b885d5e92  vmovaps [rsp+0xC0], xmm1
0000707b885d5e9b  movaps xmm7, xmm5
0000707b885d5e9e  mulpd xmm7, xmm15
0000707b885d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000707b885d5ea8  ptest xmm1, xmm1
0000707b885d5ead  jnz 0x0000707B885D7D4B
0000707b885d5eb3  lea r14, [rax+0x80]
0000707b885d5eba  movups xmm1, [r13+r14*1]
0000707b885d5ec0  vmovaps xmm5, [rsp+0x70]
0000707b885d5ec6  vmovaps [rsp+0x70], xmm1
0000707b885d5ecc  movaps xmm15, xmm5
0000707b885d5ed0  addpd xmm15, xmm3
0000707b885d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000707b885d5edb  ptest xmm1, xmm1
0000707b885d5ee0  jnz 0x0000707B885D7E96
0000707b885d5ee6  vmovaps xmm5, [rsp+0x80]
0000707b885d5eef  movaps xmm1, xmm5
0000707b885d5ef2  addpd xmm1, xmm4
0000707b885d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000707b885d5efb  ptest xmm3, xmm3
0000707b885d5f00  jnz 0x0000707B885D7FD8
0000707b885d5f06  vmovaps [rsp+0x80], xmm10
0000707b885d5f0f  vmovaps xmm5, [rsp+0x80]
0000707b885d5f18  por xmm10, xmm5
0000707b885d5f1d  movaps [r15+0x2F0], xmm10
0000707b885d5f25  vmovaps xmm5, [rsp+0x50]
0000707b885d5f2b  vpermilpd xmm5, xmm5, 0x00
0000707b885d5f31  vmovaps xmm3, [rsp+0x70]
0000707b885d5f37  vmovaps [rsp+0x50], xmm1
0000707b885d5f3d  movaps xmm4, xmm3
0000707b885d5f40  mulpd xmm4, xmm5
0000707b885d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000707b885d5f49  ptest xmm1, xmm1
0000707b885d5f4e  jnz 0x0000707B885D8118
0000707b885d5f54  lea r14, [rax+0xD0]
0000707b885d5f5b  movups xmm1, [r13+r14*1]
0000707b885d5f61  vmovaps xmm3, [rsp+0xD0]
0000707b885d5f6a  vmovaps [rsp+0x70], xmm1
0000707b885d5f70  movaps xmm5, xmm6
0000707b885d5f73  addpd xmm5, xmm3
0000707b885d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000707b885d5f7c  ptest xmm1, xmm1
0000707b885d5f81  jnz 0x0000707B885D8262
0000707b885d5f87  vmovaps xmm1, [rsp+0x60]
0000707b885d5f8d  vpermilpd xmm1, xmm1, 0x00
0000707b885d5f93  movaps xmm6, xmm9
0000707b885d5f97  mulpd xmm6, xmm1
0000707b885d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000707b885d5fa0  ptest xmm3, xmm3
0000707b885d5fa5  jnz 0x0000707B885D83A2
0000707b885d5fab  movaps [r15+0x260], xmm6
0000707b885d5fb3  vxorps xmm1, xmm1, xmm1
0000707b885d5fb7  vpbroadcastq xmm1, xmm1
0000707b885d5fbc  movaps [r15+0x1B0], xmm1
0000707b885d5fc4  vmovaps xmm1, [rsp+0x60]
0000707b885d5fca  vpermilpd xmm1, xmm1, 0x00
0000707b885d5fd0  vmovaps xmm3, [rsp+0x70]
0000707b885d5fd6  vmovaps [rsp+0x70], xmm15
0000707b885d5fdc  movaps xmm9, xmm3
0000707b885d5fe0  mulpd xmm9, xmm1
0000707b885d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000707b885d5feb  ptest xmm15, xmm15
0000707b885d5ff1  jnz 0x0000707B885D84E3
0000707b885d5ff7  lea r14, [rax+0xC0]
0000707b885d5ffe  movups xmm1, [r13+r14*1]
0000707b885d6004  vmovaps xmm3, [rsp+0xC0]
0000707b885d600d  vmovaps [rsp+0x80], xmm1
0000707b885d6016  movaps xmm15, xmm3
0000707b885d601a  addpd xmm15, xmm7
0000707b885d601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000707b885d6025  ptest xmm1, xmm1
0000707b885d602a  jnz 0x0000707B885D862F
0000707b885d6030  vmovaps [rsp+0xC0], xmm13
0000707b885d6039  vmovaps xmm1, [rsp+0xC0]
0000707b885d6042  por xmm13, xmm1
0000707b885d6047  movaps [r15+0x270], xmm13
0000707b885d604f  vmovaps xmm1, [rsp+0xB0]
0000707b885d6058  vmovaps xmm7, [rsp+0xB0]
0000707b885d6061  por xmm1, xmm7
0000707b885d6065  movaps [r15+0x1A0], xmm1
0000707b885d606d  vmovaps xmm1, [rsp+0x60]
0000707b885d6073  vpermilpd xmm1, xmm1, 0x00
0000707b885d6079  vmovaps [rsp+0xB0], xmm1
0000707b885d6082  vmovaps xmm1, [rsp+0x80]
0000707b885d608b  vmovaps [rsp+0x80], xmm15
0000707b885d6094  vmovaps xmm15, [rsp+0xB0]
0000707b885d609d  vmovaps [rsp+0xB0], xmm14
0000707b885d60a6  movaps xmm3, xmm1
0000707b885d60a9  mulpd xmm3, xmm15
0000707b885d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000707b885d60b3  ptest xmm14, xmm14
0000707b885d60b9  jnz 0x0000707B885D8771
0000707b885d60bf  lea r14, [rax+0x20]
0000707b885d60c3  movups xmm1, [r13+r14*1]
0000707b885d60c9  movaps [r15+0x110], xmm1
0000707b885d60d1  vmovaps xmm14, [rsp+0x70]
0000707b885d60d7  vmovaps [rsp+0x70], xmm1
0000707b885d60dd  movaps xmm15, xmm14
0000707b885d60e1  addpd xmm15, xmm4
0000707b885d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000707b885d60ec  ptest xmm1, xmm1
0000707b885d60f1  jnz 0x0000707B885D88BC
0000707b885d60f7  vmovaps xmm1, [rsp+0x60]
0000707b885d60fd  vpermilpd xmm1, xmm1, 0x00
0000707b885d6103  movaps xmm14, xmm2
0000707b885d6107  mulpd xmm14, xmm1
0000707b885d610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000707b885d6112  ptest xmm4, xmm4
0000707b885d6117  jnz 0x0000707B885D89FF
0000707b885d611d  vmovaps xmm4, [rsp+0x50]
0000707b885d6123  movaps xmm1, xmm4
0000707b885d6126  addpd xmm1, xmm9
0000707b885d612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000707b885d6130  ptest xmm2, xmm2
0000707b885d6135  jnz 0x0000707B885D8B41
0000707b885d613b  vmovaps xmm9, [rsp+0x30]
0000707b885d6141  vpermilpd xmm9, xmm9, 0x00
0000707b885d6147  vmovaps xmm2, [rsp+0x70]
0000707b885d614d  vmovaps [rsp+0x50], xmm1
0000707b885d6153  movaps xmm4, xmm2
0000707b885d6156  mulpd xmm4, xmm9
0000707b885d615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000707b885d6160  ptest xmm1, xmm1
0000707b885d6165  jnz 0x0000707B885D8C82
0000707b885d616b  vmovaps xmm1, [rsp+0x30]
0000707b885d6171  vpermilpd xmm1, xmm1, 0x00
0000707b885d6177  vmovaps xmm2, [rsp+0x90]
0000707b885d6180  vmovaps [rsp+0x60], xmm15
0000707b885d6186  movaps xmm9, xmm2
0000707b885d618a  mulpd xmm9, xmm1
0000707b885d618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000707b885d6195  ptest xmm15, xmm15
0000707b885d619b  jnz 0x0000707B885D8DC3
0000707b885d61a1  vmovaps xmm15, [rsp+0x80]
0000707b885d61aa  movaps xmm1, xmm15
0000707b885d61ae  addpd xmm1, xmm6
0000707b885d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000707b885d61b7  ptest xmm2, xmm2
0000707b885d61bc  jnz 0x0000707B885D8F05
0000707b885d61c2  movaps xmm15, xmm5
0000707b885d61c6  addpd xmm15, xmm3
0000707b885d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000707b885d61d1  ptest xmm6, xmm6
0000707b885d61d6  jnz 0x0000707B885D9046
0000707b885d61dc  vmovaps xmm6, [rsp+0x30]
0000707b885d61e2  vpermilpd xmm6, xmm6, 0x00
0000707b885d61e8  movaps xmm5, xmm8
0000707b885d61ec  mulpd xmm5, xmm6
0000707b885d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000707b885d61f5  ptest xmm3, xmm3
0000707b885d61fa  jnz 0x0000707B885D9188
0000707b885d6200  vmovaps xmm8, [rsp+0x30]
0000707b885d6206  vpermilpd xmm8, xmm8, 0x00
0000707b885d620c  movaps xmm6, xmm10
0000707b885d6210  mulpd xmm6, xmm8
0000707b885d6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000707b885d621a  ptest xmm3, xmm3
0000707b885d621f  jnz 0x0000707B885D92C9
0000707b885d6225  vmovaps xmm8, [rsp+0x60]
0000707b885d622b  movaps xmm10, xmm8
0000707b885d622f  addpd xmm10, xmm14
0000707b885d6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000707b885d623a  ptest xmm3, xmm3
0000707b885d623f  jnz 0x0000707B885D940B
0000707b885d6245  vmovaps xmm8, [rsp+0x50]
0000707b885d624b  movaps xmm14, xmm8
0000707b885d624f  addpd xmm14, xmm4
0000707b885d6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000707b885d625a  ptest xmm3, xmm3
0000707b885d625f  jnz 0x0000707B885D954F
0000707b885d6265  vmovaps xmm8, [rsp+0x40]
0000707b885d626b  vpermilpd xmm8, xmm8, 0x00
0000707b885d6271  movaps xmm4, xmm13
0000707b885d6275  mulpd xmm4, xmm8
0000707b885d627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000707b885d627f  ptest xmm3, xmm3
0000707b885d6284  jnz 0x0000707B885D9692
0000707b885d628a  movaps xmm13, xmm15
0000707b885d628e  addpd xmm13, xmm9
0000707b885d6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000707b885d6299  ptest xmm8, xmm8
0000707b885d629f  jnz 0x0000707B885D97D4
0000707b885d62a5  movaps xmm15, xmm1
0000707b885d62a9  addpd xmm15, xmm5
0000707b885d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000707b885d62b4  ptest xmm9, xmm9
0000707b885d62ba  jnz 0x0000707B885D9918
0000707b885d62c0  vmovaps [rsp+0x30], xmm11
0000707b885d62c6  vmovaps xmm1, [rsp+0x30]
0000707b885d62cc  por xmm11, xmm1
0000707b885d62d1  movaps [r15+0x250], xmm11
0000707b885d62d9  vmovaps [rsp+0x30], xmm12
0000707b885d62df  vmovaps xmm1, [rsp+0x30]
0000707b885d62e5  por xmm12, xmm1
0000707b885d62ea  movaps [r15+0x2A0], xmm12
0000707b885d62f2  vmovaps xmm1, [rsp+0xA0]
0000707b885d62fb  vmovaps xmm11, [rsp+0xA0]
0000707b885d6304  por xmm1, xmm11
0000707b885d6309  movaps [r15+0x1D0], xmm1
0000707b885d6311  lea r14, [rax+0x40]
0000707b885d6315  movups xmm1, [r13+r14*1]
0000707b885d631b  movaps [r15+0x2C0], xmm1
0000707b885d6323  vmovaps xmm11, [rsp+0x40]
0000707b885d6329  vpermilpd xmm11, xmm11, 0x00
0000707b885d632f  vmovaps xmm8, [rsp+0xE0]
0000707b885d6338  movaps xmm9, xmm8
0000707b885d633c  mulpd xmm9, xmm11
0000707b885d6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000707b885d6347  ptest xmm5, xmm5
0000707b885d634c  jnz 0x0000707B885D9A64
0000707b885d6352  movaps xmm11, xmm10
0000707b885d6356  addpd xmm11, xmm6
0000707b885d635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000707b885d6361  ptest xmm8, xmm8
0000707b885d6367  jnz 0x0000707B885D9BA8
0000707b885d636d  movaps xmm10, xmm14
0000707b885d6371  addpd xmm10, xmm4
0000707b885d6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000707b885d637c  ptest xmm8, xmm8
0000707b885d6382  jnz 0x0000707B885D9CEB
0000707b885d6388  vmovaps xmm14, [rsp+0x40]
0000707b885d638e  vpermilpd xmm14, xmm14, 0x00
0000707b885d6394  movaps xmm8, xmm1
0000707b885d6398  mulpd xmm8, xmm14
0000707b885d639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000707b885d63a3  ptest xmm6, xmm6
0000707b885d63a8  jnz 0x0000707B885D9E2E
0000707b885d63ae  movaps xmm1, [r15+0x2B0]
0000707b885d63b6  vmovaps xmm14, [rsp+0x40]
0000707b885d63bc  vpermilpd xmm14, xmm14, 0x00
0000707b885d63c2  movaps xmm6, xmm1
0000707b885d63c5  mulpd xmm6, xmm14
0000707b885d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000707b885d63cf  ptest xmm5, xmm5
0000707b885d63d4  jnz 0x0000707B885D9F71
0000707b885d63da  vmovaps xmm1, [rsp+0x10]
0000707b885d63e0  vpermilpd xmm1, xmm1, 0x00
0000707b885d63e6  movaps xmm14, xmm12
0000707b885d63ea  mulpd xmm14, xmm1
0000707b885d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000707b885d63f5  ptest xmm5, xmm5
0000707b885d63fa  jnz 0x0000707B885DA0B2
0000707b885d6400  movaps xmm1, xmm13
0000707b885d6404  addpd xmm1, xmm9
0000707b885d6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000707b885d640e  ptest xmm12, xmm12
0000707b885d6414  jnz 0x0000707B885DA1F5
0000707b885d641a  vmovaps xmm13, [rsp+0x10]
0000707b885d6420  vpermilpd xmm13, xmm13, 0x00
0000707b885d6426  movaps xmm12, xmm7
0000707b885d642a  mulpd xmm12, xmm13
0000707b885d642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000707b885d6435  ptest xmm9, xmm9
0000707b885d643b  jnz 0x0000707B885DA337
0000707b885d6441  movaps xmm13, xmm15
0000707b885d6445  addpd xmm13, xmm8
0000707b885d644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000707b885d6450  ptest xmm9, xmm9
0000707b885d6456  jnz 0x0000707B885DA47A
0000707b885d645c  movaps xmm15, [r15+0x290]
0000707b885d6464  vmovaps xmm9, [rsp+0x10]
0000707b885d646a  vpermilpd xmm9, xmm9, 0x00
0000707b885d6470  movaps xmm8, xmm15
0000707b885d6474  mulpd xmm8, xmm9
0000707b885d6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000707b885d647f  ptest xmm7, xmm7
0000707b885d6484  jnz 0x0000707B885DA5BE
0000707b885d648a  movaps xmm15, xmm11
0000707b885d648e  addpd xmm15, xmm6
0000707b885d6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000707b885d6499  ptest xmm9, xmm9
0000707b885d649f  jnz 0x0000707B885DA702
0000707b885d64a5  movaps xmm11, [r15+0x1E0]
0000707b885d64ad  vmovaps xmm9, [rsp+0x10]
0000707b885d64b3  vpermilpd xmm9, xmm9, 0x00
0000707b885d64b9  movaps xmm7, xmm11
0000707b885d64bd  mulpd xmm7, xmm9
0000707b885d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000707b885d64c7  ptest xmm6, xmm6
0000707b885d64cc  jnz 0x0000707B885DA845
0000707b885d64d2  movaps xmm11, xmm10
0000707b885d64d6  addpd xmm11, xmm14
0000707b885d64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000707b885d64e1  ptest xmm9, xmm9
0000707b885d64e7  jnz 0x0000707B885DA987
0000707b885d64ed  lea r14, [rax+0x70]
0000707b885d64f1  movups xmm14, [r13+r14*1]
0000707b885d64f7  movaps [r15+0x240], xmm14
0000707b885d64ff  movaps xmm10, xmm1
0000707b885d6503  addpd xmm10, xmm12
0000707b885d6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000707b885d650e  ptest xmm9, xmm9
0000707b885d6514  jnz 0x0000707B885DAAD5
0000707b885d651a  movaps [r15+0x170], xmm10
0000707b885d6522  vmovaps xmm1, [rsp+0x20]
0000707b885d6528  vpermilpd xmm1, xmm1, 0x00
0000707b885d652e  movaps xmm12, xmm14
0000707b885d6532  mulpd xmm12, xmm1
0000707b885d6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000707b885d653d  ptest xmm9, xmm9
0000707b885d6543  jnz 0x0000707B885DAC18
0000707b885d6549  vmovaps xmm1, [rsp+0x20]
0000707b885d654f  vpermilpd xmm1, xmm1, 0x00
0000707b885d6555  vmovaps xmm9, [rsp+0xB0]
0000707b885d655e  movaps xmm14, xmm9
0000707b885d6562  mulpd xmm14, xmm1
0000707b885d6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000707b885d656d  ptest xmm6, xmm6
0000707b885d6572  jnz 0x0000707B885DAD5B
0000707b885d6578  movaps [r15+0x180], xmm14
0000707b885d6580  movaps xmm1, xmm13
0000707b885d6584  addpd xmm1, xmm8
0000707b885d6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000707b885d658e  ptest xmm9, xmm9
0000707b885d6594  jnz 0x0000707B885DAE9E
0000707b885d659a  movaps [r15+0x210], xmm1
0000707b885d65a2  movups xmm13, [r13+rax*1]
0000707b885d65a8  lea r14, [rax+0x10]
0000707b885d65ac  movups xmm9, [r13+r14*1]
0000707b885d65b2  movaps [r15+0x230], xmm9
0000707b885d65ba  movaps xmm8, xmm15
0000707b885d65be  addpd xmm8, xmm7
0000707b885d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000707b885d65c9  ptest xmm6, xmm6
0000707b885d65ce  jnz 0x0000707B885DAFF4
0000707b885d65d4  movaps [r15+0x130], xmm8
0000707b885d65dc  vmovaps xmm15, [rsp+0x20]
0000707b885d65e2  vpermilpd xmm15, xmm15, 0x00
0000707b885d65e8  movaps xmm7, xmm9
0000707b885d65ec  mulpd xmm7, xmm15
0000707b885d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000707b885d65f6  ptest xmm6, xmm6
0000707b885d65fb  jnz 0x0000707B885DB137
0000707b885d6601  movaps [r15+0x220], xmm7
0000707b885d6609  vmovaps xmm15, [rsp+0x20]
0000707b885d660f  vpermilpd xmm15, xmm15, 0x00
0000707b885d6615  movaps xmm9, xmm13
0000707b885d6619  mulpd xmm9, xmm15
0000707b885d661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000707b885d6624  ptest xmm6, xmm6
0000707b885d6629  jnz 0x0000707B885DB279
0000707b885d662f  movaps xmm15, xmm11
0000707b885d6633  addpd xmm15, xmm12
0000707b885d6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000707b885d663e  ptest xmm13, xmm13
0000707b885d6644  jnz 0x0000707B885DB3BD
0000707b885d664a  movaps [r15+0x140], xmm15
0000707b885d6652  movaps xmm13, xmm10
0000707b885d6656  addpd xmm13, xmm14
0000707b885d665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000707b885d6661  ptest xmm12, xmm12
0000707b885d6667  jnz 0x0000707B885DB501
0000707b885d666d  movaps [r15+0x150], xmm13
0000707b885d6675  movaps xmm14, xmm1
0000707b885d6679  addpd xmm14, xmm7
0000707b885d667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000707b885d6684  ptest xmm12, xmm12
0000707b885d668a  jnz 0x0000707B885DB645
0000707b885d6690  movaps [r15+0x160], xmm14
0000707b885d6698  movaps xmm1, xmm8
0000707b885d669c  addpd xmm1, xmm9
0000707b885d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000707b885d66a6  ptest xmm12, xmm12
0000707b885d66ac  jnz 0x0000707B885DB787
0000707b885d66b2  movaps [r15+0x120], xmm1
0000707b885d66ba  movups [r13+r11*1], xmm15
0000707b885d66c0  lea rax, [r11+0x10]
0000707b885d66c4  movups [r13+rax*1], xmm13
0000707b885d66ca  lea rax, [r11+0x20]
0000707b885d66ce  movups [r13+rax*1], xmm14
0000707b885d66d4  lea rax, [r11+0x30]
0000707b885d66d8  movups [r13+rax*1], xmm1
0000707b885d66de  mov eax, [r15+0x108]
0000707b885d66e5  sahf
0000707b885d66e6  jnz 0x0000707B885D6718
0000707b885d66e8  cmp dword ptr [r15+0x318], 0x00
0000707b885d66f0  jz 0x0000707B885DB900
0000707b885d66f6  nop [rax+rax*1], ax
0000707b885d66ff  nop [rax+rax*1], eax
0000707b885d6707  mov eax, 0x410444
0000707b885d670c  mov [r15+0x100], rax
0000707b885d6713  jmp 0x0000707B883FE110
0000707b885d6718  cmp dword ptr [r15+0x318], 0x00
0000707b885d6720  jz 0x0000707B885D57E0
0000707b885d6726  nop [rax+rax*1], ax
0000707b885d672f  nop [rax+rax*1], eax
0000707b885d6737  mov eax, 0x410278
0000707b885d673c  mov [r15+0x100], rax
0000707b885d6743  jmp 0x0000707B883FE110
0000707b885d6748  int3
0000707b885d6749  call 0x0000707B8840A4B0
0000707b885d674e  jmp 0x0000707B885D5828
0000707b885d6753  call 0x0000707B88409240
0000707b885d6758  jmp 0x0000707B885D5832
0000707b885d675d  call 0x0000707B8840A4B0
0000707b885d6762  jmp 0x0000707B885D588F
0000707b885d6767  call 0x0000707B88409240
0000707b885d676c  jmp 0x0000707B885D5899
0000707b885d6771  call 0x0000707B8840A4B0
0000707b885d6776  jmp 0x0000707B885D58DD
0000707b885d677b  call 0x0000707B88409240
0000707b885d6780  jmp 0x0000707B885D58E7
0000707b885d6785  call 0x0000707B884B47C0
0000707b885d678a  jmp 0x0000707B885D5926
0000707b885d678f  call 0x0000707B8840B720
0000707b885d6794  jmp 0x0000707B885D593A
0000707b885d6799  call 0x0000707B884BFC30
0000707b885d679e  jmp 0x0000707B885D5958
0000707b885d67a3  call 0x0000707B884BE9C0
0000707b885d67a8  jmp 0x0000707B885D5962
0000707b885d67ad  call 0x0000707B884BD750
0000707b885d67b2  jmp 0x0000707B885D596C
0000707b885d67b7  sub rsp, 0x08
0000707b885d67bb  push rax
0000707b885d67bc  push rcx
0000707b885d67bd  push rdx
0000707b885d67be  push rdi
0000707b885d67bf  push rsi
0000707b885d67c0  push r8
0000707b885d67c2  push r9
0000707b885d67c4  push r10
0000707b885d67c6  push r11
0000707b885d67c8  sub rsp, 0xF0
0000707b885d67cf  vmovaps [rsp], xmm0
0000707b885d67d4  vmovaps [rsp+0x10], xmm1
0000707b885d67da  vmovaps [rsp+0x20], xmm2
0000707b885d67e0  vmovaps [rsp+0x30], xmm3
0000707b885d67e6  vmovaps [rsp+0x40], xmm4
0000707b885d67ec  vmovaps [rsp+0x50], xmm5
0000707b885d67f2  vmovaps [rsp+0x60], xmm6
0000707b885d67f8  vmovaps [rsp+0x70], xmm7
0000707b885d67fe  vmovaps [rsp+0x80], xmm9
0000707b885d6807  vmovaps [rsp+0x90], xmm10
0000707b885d6810  vmovaps [rsp+0xA0], xmm11
0000707b885d6819  vmovaps [rsp+0xB0], xmm12
0000707b885d6822  vmovaps [rsp+0xC0], xmm13
0000707b885d682b  vmovaps [rsp+0xD0], xmm14
0000707b885d6834  vmovaps [rsp+0xE0], xmm15
0000707b885d683d  sub rsp, 0x30
0000707b885d6841  movaps [rsp], xmm8
0000707b885d6846  movaps [rsp+0x10], xmm12
0000707b885d684c  movaps [rsp+0x20], xmm15
0000707b885d6852  lea rdi, [rsp]
0000707b885d6856  mov esi, 0x00
0000707b885d685b  mov rax, 0x6471B35AC530
0000707b885d6865  call rax
0000707b885d6867  movaps xmm8, [rsp]
0000707b885d686c  add rsp, 0x30
0000707b885d6870  vmovaps xmm0, [rsp]
0000707b885d6875  vmovaps xmm1, [rsp+0x10]
0000707b885d687b  vmovaps xmm2, [rsp+0x20]
0000707b885d6881  vmovaps xmm3, [rsp+0x30]
0000707b885d6887  vmovaps xmm4, [rsp+0x40]
0000707b885d688d  vmovaps xmm5, [rsp+0x50]
0000707b885d6893  vmovaps xmm6, [rsp+0x60]
0000707b885d6899  vmovaps xmm7, [rsp+0x70]
0000707b885d689f  vmovaps xmm9, [rsp+0x80]
0000707b885d68a8  vmovaps xmm10, [rsp+0x90]
0000707b885d68b1  vmovaps xmm11, [rsp+0xA0]
0000707b885d68ba  vmovaps xmm12, [rsp+0xB0]
0000707b885d68c3  vmovaps xmm13, [rsp+0xC0]
0000707b885d68cc  vmovaps xmm14, [rsp+0xD0]
0000707b885d68d5  vmovaps xmm15, [rsp+0xE0]
0000707b885d68de  add rsp, 0xF0
0000707b885d68e5  pop r11
0000707b885d68e7  pop r10
0000707b885d68e9  pop r9
0000707b885d68eb  pop r8
0000707b885d68ed  pop rsi
0000707b885d68ee  pop rdi
0000707b885d68ef  pop rdx
0000707b885d68f0  pop rcx
0000707b885d68f1  pop rax
0000707b885d68f2  add rsp, 0x08
0000707b885d68f6  jmp 0x0000707B885D599A
0000707b885d68fb  sub rsp, 0x08
0000707b885d68ff  push rax
0000707b885d6900  push rcx
0000707b885d6901  push rdx
0000707b885d6902  push rdi
0000707b885d6903  push rsi
0000707b885d6904  push r8
0000707b885d6906  push r9
0000707b885d6908  push r10
0000707b885d690a  push r11
0000707b885d690c  sub rsp, 0xF0
0000707b885d6913  vmovaps [rsp], xmm0
0000707b885d6918  vmovaps [rsp+0x10], xmm1
0000707b885d691e  vmovaps [rsp+0x20], xmm2
0000707b885d6924  vmovaps [rsp+0x30], xmm3
0000707b885d692a  vmovaps [rsp+0x40], xmm4
0000707b885d6930  vmovaps [rsp+0x50], xmm5
0000707b885d6936  vmovaps [rsp+0x60], xmm6
0000707b885d693c  vmovaps [rsp+0x70], xmm8
0000707b885d6942  vmovaps [rsp+0x80], xmm9
0000707b885d694b  vmovaps [rsp+0x90], xmm10
0000707b885d6954  vmovaps [rsp+0xA0], xmm11
0000707b885d695d  vmovaps [rsp+0xB0], xmm12
0000707b885d6966  vmovaps [rsp+0xC0], xmm13
0000707b885d696f  vmovaps [rsp+0xD0], xmm14
0000707b885d6978  vmovaps [rsp+0xE0], xmm15
0000707b885d6981  sub rsp, 0x30
0000707b885d6985  movaps [rsp], xmm7
0000707b885d6989  movaps [rsp+0x10], xmm9
0000707b885d698f  movaps [rsp+0x20], xmm15
0000707b885d6995  lea rdi, [rsp]
0000707b885d6999  mov esi, 0x00
0000707b885d699e  mov rax, 0x6471B35AC530
0000707b885d69a8  call rax
0000707b885d69aa  movaps xmm7, [rsp]
0000707b885d69ae  add rsp, 0x30
0000707b885d69b2  vmovaps xmm0, [rsp]
0000707b885d69b7  vmovaps xmm1, [rsp+0x10]
0000707b885d69bd  vmovaps xmm2, [rsp+0x20]
0000707b885d69c3  vmovaps xmm3, [rsp+0x30]
0000707b885d69c9  vmovaps xmm4, [rsp+0x40]
0000707b885d69cf  vmovaps xmm5, [rsp+0x50]
0000707b885d69d5  vmovaps xmm6, [rsp+0x60]
0000707b885d69db  vmovaps xmm8, [rsp+0x70]
0000707b885d69e1  vmovaps xmm9, [rsp+0x80]
0000707b885d69ea  vmovaps xmm10, [rsp+0x90]
0000707b885d69f3  vmovaps xmm11, [rsp+0xA0]
0000707b885d69fc  vmovaps xmm12, [rsp+0xB0]
0000707b885d6a05  vmovaps xmm13, [rsp+0xC0]
0000707b885d6a0e  vmovaps xmm14, [rsp+0xD0]
0000707b885d6a17  vmovaps xmm15, [rsp+0xE0]
0000707b885d6a20  add rsp, 0xF0
0000707b885d6a27  pop r11
0000707b885d6a29  pop r10
0000707b885d6a2b  pop r9
0000707b885d6a2d  pop r8
0000707b885d6a2f  pop rsi
0000707b885d6a30  pop rdi
0000707b885d6a31  pop rdx
0000707b885d6a32  pop rcx
0000707b885d6a33  pop rax
0000707b885d6a34  add rsp, 0x08
0000707b885d6a38  jmp 0x0000707B885D59C8
0000707b885d6a3d  sub rsp, 0x08
0000707b885d6a41  push rax
0000707b885d6a42  push rcx
0000707b885d6a43  push rdx
0000707b885d6a44  push rdi
0000707b885d6a45  push rsi
0000707b885d6a46  push r8
0000707b885d6a48  push r9
0000707b885d6a4a  push r10
0000707b885d6a4c  push r11
0000707b885d6a4e  sub rsp, 0xF0
0000707b885d6a55  vmovaps [rsp], xmm0
0000707b885d6a5a  vmovaps [rsp+0x10], xmm1
0000707b885d6a60  vmovaps [rsp+0x20], xmm2
0000707b885d6a66  vmovaps [rsp+0x30], xmm3
0000707b885d6a6c  vmovaps [rsp+0x40], xmm4
0000707b885d6a72  vmovaps [rsp+0x50], xmm5
0000707b885d6a78  vmovaps [rsp+0x60], xmm6
0000707b885d6a7e  vmovaps [rsp+0x70], xmm7
0000707b885d6a84  vmovaps [rsp+0x80], xmm8
0000707b885d6a8d  vmovaps [rsp+0x90], xmm10
0000707b885d6a96  vmovaps [rsp+0xA0], xmm11
0000707b885d6a9f  vmovaps [rsp+0xB0], xmm12
0000707b885d6aa8  vmovaps [rsp+0xC0], xmm13
0000707b885d6ab1  vmovaps [rsp+0xD0], xmm14
0000707b885d6aba  vmovaps [rsp+0xE0], xmm15
0000707b885d6ac3  sub rsp, 0x30
0000707b885d6ac7  movaps [rsp], xmm9
0000707b885d6acc  movaps [rsp+0x10], xmm12
0000707b885d6ad2  movaps [rsp+0x20], xmm10
0000707b885d6ad8  lea rdi, [rsp]
0000707b885d6adc  mov esi, 0x00
0000707b885d6ae1  mov rax, 0x6471B35AC530
0000707b885d6aeb  call rax
0000707b885d6aed  movaps xmm9, [rsp]
0000707b885d6af2  add rsp, 0x30
0000707b885d6af6  vmovaps xmm0, [rsp]
0000707b885d6afb  vmovaps xmm1, [rsp+0x10]
0000707b885d6b01  vmovaps xmm2, [rsp+0x20]
0000707b885d6b07  vmovaps xmm3, [rsp+0x30]
0000707b885d6b0d  vmovaps xmm4, [rsp+0x40]
0000707b885d6b13  vmovaps xmm5, [rsp+0x50]
0000707b885d6b19  vmovaps xmm6, [rsp+0x60]
0000707b885d6b1f  vmovaps xmm7, [rsp+0x70]
0000707b885d6b25  vmovaps xmm8, [rsp+0x80]
0000707b885d6b2e  vmovaps xmm10, [rsp+0x90]
0000707b885d6b37  vmovaps xmm11, [rsp+0xA0]
0000707b885d6b40  vmovaps xmm12, [rsp+0xB0]
0000707b885d6b49  vmovaps xmm13, [rsp+0xC0]
0000707b885d6b52  vmovaps xmm14, [rsp+0xD0]
0000707b885d6b5b  vmovaps xmm15, [rsp+0xE0]
0000707b885d6b64  add rsp, 0xF0
0000707b885d6b6b  pop r11
0000707b885d6b6d  pop r10
0000707b885d6b6f  pop r9
0000707b885d6b71  pop r8
0000707b885d6b73  pop rsi
0000707b885d6b74  pop rdi
0000707b885d6b75  pop rdx
0000707b885d6b76  pop rcx
0000707b885d6b77  pop rax
0000707b885d6b78  add rsp, 0x08
0000707b885d6b7c  jmp 0x0000707B885D59EC
0000707b885d6b81  sub rsp, 0x08
0000707b885d6b85  push rax
0000707b885d6b86  push rcx
0000707b885d6b87  push rdx
0000707b885d6b88  push rdi
0000707b885d6b89  push rsi
0000707b885d6b8a  push r8
0000707b885d6b8c  push r9
0000707b885d6b8e  push r10
0000707b885d6b90  push r11
0000707b885d6b92  sub rsp, 0xF0
0000707b885d6b99  vmovaps [rsp], xmm0
0000707b885d6b9e  vmovaps [rsp+0x10], xmm1
0000707b885d6ba4  vmovaps [rsp+0x20], xmm2
0000707b885d6baa  vmovaps [rsp+0x30], xmm3
0000707b885d6bb0  vmovaps [rsp+0x40], xmm4
0000707b885d6bb6  vmovaps [rsp+0x50], xmm5
0000707b885d6bbc  vmovaps [rsp+0x60], xmm6
0000707b885d6bc2  vmovaps [rsp+0x70], xmm7
0000707b885d6bc8  vmovaps [rsp+0x80], xmm8
0000707b885d6bd1  vmovaps [rsp+0x90], xmm9
0000707b885d6bda  vmovaps [rsp+0xA0], xmm11
0000707b885d6be3  vmovaps [rsp+0xB0], xmm12
0000707b885d6bec  vmovaps [rsp+0xC0], xmm13
0000707b885d6bf5  vmovaps [rsp+0xD0], xmm14
0000707b885d6bfe  vmovaps [rsp+0xE0], xmm15
0000707b885d6c07  sub rsp, 0x30
0000707b885d6c0b  movaps [rsp], xmm10
0000707b885d6c10  movaps [rsp+0x10], xmm12
0000707b885d6c16  movaps [rsp+0x20], xmm11
0000707b885d6c1c  lea rdi, [rsp]
0000707b885d6c20  mov esi, 0x00
0000707b885d6c25  mov rax, 0x6471B35AC530
0000707b885d6c2f  call rax
0000707b885d6c31  movaps xmm10, [rsp]
0000707b885d6c36  add rsp, 0x30
0000707b885d6c3a  vmovaps xmm0, [rsp]
0000707b885d6c3f  vmovaps xmm1, [rsp+0x10]
0000707b885d6c45  vmovaps xmm2, [rsp+0x20]
0000707b885d6c4b  vmovaps xmm3, [rsp+0x30]
0000707b885d6c51  vmovaps xmm4, [rsp+0x40]
0000707b885d6c57  vmovaps xmm5, [rsp+0x50]
0000707b885d6c5d  vmovaps xmm6, [rsp+0x60]
0000707b885d6c63  vmovaps xmm7, [rsp+0x70]
0000707b885d6c69  vmovaps xmm8, [rsp+0x80]
0000707b885d6c72  vmovaps xmm9, [rsp+0x90]
0000707b885d6c7b  vmovaps xmm11, [rsp+0xA0]
0000707b885d6c84  vmovaps xmm12, [rsp+0xB0]
0000707b885d6c8d  vmovaps xmm13, [rsp+0xC0]
0000707b885d6c96  vmovaps xmm14, [rsp+0xD0]
0000707b885d6c9f  vmovaps xmm15, [rsp+0xE0]
0000707b885d6ca8  add rsp, 0xF0
0000707b885d6caf  pop r11
0000707b885d6cb1  pop r10
0000707b885d6cb3  pop r9
0000707b885d6cb5  pop r8
0000707b885d6cb7  pop rsi
0000707b885d6cb8  pop rdi
0000707b885d6cb9  pop rdx
0000707b885d6cba  pop rcx
0000707b885d6cbb  pop rax
0000707b885d6cbc  add rsp, 0x08
0000707b885d6cc0  jmp 0x0000707B885D5A06
0000707b885d6cc5  sub rsp, 0x08
0000707b885d6cc9  push rax
0000707b885d6cca  push rcx
0000707b885d6ccb  push rdx
0000707b885d6ccc  push rdi
0000707b885d6ccd  push rsi
0000707b885d6cce  push r8
0000707b885d6cd0  push r9
0000707b885d6cd2  push r10
0000707b885d6cd4  push r11
0000707b885d6cd6  sub rsp, 0xF0
0000707b885d6cdd  vmovaps [rsp], xmm0
0000707b885d6ce2  vmovaps [rsp+0x10], xmm1
0000707b885d6ce8  vmovaps [rsp+0x20], xmm2
0000707b885d6cee  vmovaps [rsp+0x30], xmm3
0000707b885d6cf4  vmovaps [rsp+0x40], xmm4
0000707b885d6cfa  vmovaps [rsp+0x50], xmm5
0000707b885d6d00  vmovaps [rsp+0x60], xmm7
0000707b885d6d06  vmovaps [rsp+0x70], xmm8
0000707b885d6d0c  vmovaps [rsp+0x80], xmm9
0000707b885d6d15  vmovaps [rsp+0x90], xmm10
0000707b885d6d1e  vmovaps [rsp+0xA0], xmm11
0000707b885d6d27  vmovaps [rsp+0xB0], xmm12
0000707b885d6d30  vmovaps [rsp+0xC0], xmm13
0000707b885d6d39  vmovaps [rsp+0xD0], xmm14
0000707b885d6d42  vmovaps [rsp+0xE0], xmm15
0000707b885d6d4b  sub rsp, 0x30
0000707b885d6d4f  movaps [rsp], xmm6
0000707b885d6d53  movaps [rsp+0x10], xmm12
0000707b885d6d59  movaps [rsp+0x20], xmm11
0000707b885d6d5f  lea rdi, [rsp]
0000707b885d6d63  mov esi, 0x00
0000707b885d6d68  mov rax, 0x6471B35AC530
0000707b885d6d72  call rax
0000707b885d6d74  movaps xmm6, [rsp]
0000707b885d6d78  add rsp, 0x30
0000707b885d6d7c  vmovaps xmm0, [rsp]
0000707b885d6d81  vmovaps xmm1, [rsp+0x10]
0000707b885d6d87  vmovaps xmm2, [rsp+0x20]
0000707b885d6d8d  vmovaps xmm3, [rsp+0x30]
0000707b885d6d93  vmovaps xmm4, [rsp+0x40]
0000707b885d6d99  vmovaps xmm5, [rsp+0x50]
0000707b885d6d9f  vmovaps xmm7, [rsp+0x60]
0000707b885d6da5  vmovaps xmm8, [rsp+0x70]
0000707b885d6dab  vmovaps xmm9, [rsp+0x80]
0000707b885d6db4  vmovaps xmm10, [rsp+0x90]
0000707b885d6dbd  vmovaps xmm11, [rsp+0xA0]
0000707b885d6dc6  vmovaps xmm12, [rsp+0xB0]
0000707b885d6dcf  vmovaps xmm13, [rsp+0xC0]
0000707b885d6dd8  vmovaps xmm14, [rsp+0xD0]
0000707b885d6de1  vmovaps xmm15, [rsp+0xE0]
0000707b885d6dea  add rsp, 0xF0
0000707b885d6df1  pop r11
0000707b885d6df3  pop r10
0000707b885d6df5  pop r9
0000707b885d6df7  pop r8
0000707b885d6df9  pop rsi
0000707b885d6dfa  pop rdi
0000707b885d6dfb  pop rdx
0000707b885d6dfc  pop rcx
0000707b885d6dfd  pop rax
0000707b885d6dfe  add rsp, 0x08
0000707b885d6e02  jmp 0x0000707B885D5A27
0000707b885d6e07  sub rsp, 0x08
0000707b885d6e0b  push rax
0000707b885d6e0c  push rcx
0000707b885d6e0d  push rdx
0000707b885d6e0e  push rdi
0000707b885d6e0f  push rsi
0000707b885d6e10  push r8
0000707b885d6e12  push r9
0000707b885d6e14  push r10
0000707b885d6e16  push r11
0000707b885d6e18  sub rsp, 0xF0
0000707b885d6e1f  vmovaps [rsp], xmm0
0000707b885d6e24  vmovaps [rsp+0x10], xmm1
0000707b885d6e2a  vmovaps [rsp+0x20], xmm2
0000707b885d6e30  vmovaps [rsp+0x30], xmm4
0000707b885d6e36  vmovaps [rsp+0x40], xmm5
0000707b885d6e3c  vmovaps [rsp+0x50], xmm6
0000707b885d6e42  vmovaps [rsp+0x60], xmm7
0000707b885d6e48  vmovaps [rsp+0x70], xmm8
0000707b885d6e4e  vmovaps [rsp+0x80], xmm9
0000707b885d6e57  vmovaps [rsp+0x90], xmm10
0000707b885d6e60  vmovaps [rsp+0xA0], xmm11
0000707b885d6e69  vmovaps [rsp+0xB0], xmm12
0000707b885d6e72  vmovaps [rsp+0xC0], xmm13
0000707b885d6e7b  vmovaps [rsp+0xD0], xmm14
0000707b885d6e84  vmovaps [rsp+0xE0], xmm15
0000707b885d6e8d  sub rsp, 0x30
0000707b885d6e91  movaps [rsp], xmm3
0000707b885d6e95  movaps [rsp+0x10], xmm5
0000707b885d6e9a  movaps [rsp+0x20], xmm4
0000707b885d6e9f  lea rdi, [rsp]
0000707b885d6ea3  mov esi, 0x00
0000707b885d6ea8  mov rax, 0x6471B35AC530
0000707b885d6eb2  call rax
0000707b885d6eb4  movaps xmm3, [rsp]
0000707b885d6eb8  add rsp, 0x30
0000707b885d6ebc  vmovaps xmm0, [rsp]
0000707b885d6ec1  vmovaps xmm1, [rsp+0x10]
0000707b885d6ec7  vmovaps xmm2, [rsp+0x20]
0000707b885d6ecd  vmovaps xmm4, [rsp+0x30]
0000707b885d6ed3  vmovaps xmm5, [rsp+0x40]
0000707b885d6ed9  vmovaps xmm6, [rsp+0x50]
0000707b885d6edf  vmovaps xmm7, [rsp+0x60]
0000707b885d6ee5  vmovaps xmm8, [rsp+0x70]
0000707b885d6eeb  vmovaps xmm9, [rsp+0x80]
0000707b885d6ef4  vmovaps xmm10, [rsp+0x90]
0000707b885d6efd  vmovaps xmm11, [rsp+0xA0]
0000707b885d6f06  vmovaps xmm12, [rsp+0xB0]
0000707b885d6f0f  vmovaps xmm13, [rsp+0xC0]
0000707b885d6f18  vmovaps xmm14, [rsp+0xD0]
0000707b885d6f21  vmovaps xmm15, [rsp+0xE0]
0000707b885d6f2a  add rsp, 0xF0
0000707b885d6f31  pop r11
0000707b885d6f33  pop r10
0000707b885d6f35  pop r9
0000707b885d6f37  pop r8
0000707b885d6f39  pop rsi
0000707b885d6f3a  pop rdi
0000707b885d6f3b  pop rdx
0000707b885d6f3c  pop rcx
0000707b885d6f3d  pop rax
0000707b885d6f3e  add rsp, 0x08
0000707b885d6f42  jmp 0x0000707B885D5A88
0000707b885d6f47  sub rsp, 0x08
0000707b885d6f4b  push rax
0000707b885d6f4c  push rcx
0000707b885d6f4d  push rdx
0000707b885d6f4e  push rdi
0000707b885d6f4f  push rsi
0000707b885d6f50  push r8
0000707b885d6f52  push r9
0000707b885d6f54  push r10
0000707b885d6f56  push r11
0000707b885d6f58  sub rsp, 0xF0
0000707b885d6f5f  vmovaps [rsp], xmm0
0000707b885d6f64  vmovaps [rsp+0x10], xmm1
0000707b885d6f6a  vmovaps [rsp+0x20], xmm2
0000707b885d6f70  vmovaps [rsp+0x30], xmm3
0000707b885d6f76  vmovaps [rsp+0x40], xmm4
0000707b885d6f7c  vmovaps [rsp+0x50], xmm6
0000707b885d6f82  vmovaps [rsp+0x60], xmm7
0000707b885d6f88  vmovaps [rsp+0x70], xmm8
0000707b885d6f8e  vmovaps [rsp+0x80], xmm9
0000707b885d6f97  vmovaps [rsp+0x90], xmm10
0000707b885d6fa0  vmovaps [rsp+0xA0], xmm11
0000707b885d6fa9  vmovaps [rsp+0xB0], xmm12
0000707b885d6fb2  vmovaps [rsp+0xC0], xmm13
0000707b885d6fbb  vmovaps [rsp+0xD0], xmm14
0000707b885d6fc4  vmovaps [rsp+0xE0], xmm15
0000707b885d6fcd  sub rsp, 0x30
0000707b885d6fd1  movaps [rsp], xmm5
0000707b885d6fd5  movaps [rsp+0x10], xmm8
0000707b885d6fdb  movaps [rsp+0x20], xmm15
0000707b885d6fe1  lea rdi, [rsp]
0000707b885d6fe5  mov esi, 0x00
0000707b885d6fea  mov rax, 0x6471B35AC530
0000707b885d6ff4  call rax
0000707b885d6ff6  movaps xmm5, [rsp]
0000707b885d6ffa  add rsp, 0x30
0000707b885d6ffe  vmovaps xmm0, [rsp]
0000707b885d7003  vmovaps xmm1, [rsp+0x10]
0000707b885d7009  vmovaps xmm2, [rsp+0x20]
0000707b885d700f  vmovaps xmm3, [rsp+0x30]
0000707b885d7015  vmovaps xmm4, [rsp+0x40]
0000707b885d701b  vmovaps xmm6, [rsp+0x50]
0000707b885d7021  vmovaps xmm7, [rsp+0x60]
0000707b885d7027  vmovaps xmm8, [rsp+0x70]
0000707b885d702d  vmovaps xmm9, [rsp+0x80]
0000707b885d7036  vmovaps xmm10, [rsp+0x90]
0000707b885d703f  vmovaps xmm11, [rsp+0xA0]
0000707b885d7048  vmovaps xmm12, [rsp+0xB0]
0000707b885d7051  vmovaps xmm13, [rsp+0xC0]
0000707b885d705a  vmovaps xmm14, [rsp+0xD0]
0000707b885d7063  vmovaps xmm15, [rsp+0xE0]
0000707b885d706c  add rsp, 0xF0
0000707b885d7073  pop r11
0000707b885d7075  pop r10
0000707b885d7077  pop r9
0000707b885d7079  pop r8
0000707b885d707b  pop rsi
0000707b885d707c  pop rdi
0000707b885d707d  pop rdx
0000707b885d707e  pop rcx
0000707b885d707f  pop rax
0000707b885d7080  add rsp, 0x08
0000707b885d7084  jmp 0x0000707B885D5AC0
0000707b885d7089  sub rsp, 0x08
0000707b885d708d  push rax
0000707b885d708e  push rcx
0000707b885d708f  push rdx
0000707b885d7090  push rdi
0000707b885d7091  push rsi
0000707b885d7092  push r8
0000707b885d7094  push r9
0000707b885d7096  push r10
0000707b885d7098  push r11
0000707b885d709a  sub rsp, 0xF0
0000707b885d70a1  vmovaps [rsp], xmm0
0000707b885d70a6  vmovaps [rsp+0x10], xmm1
0000707b885d70ac  vmovaps [rsp+0x20], xmm2
0000707b885d70b2  vmovaps [rsp+0x30], xmm3
0000707b885d70b8  vmovaps [rsp+0x40], xmm5
0000707b885d70be  vmovaps [rsp+0x50], xmm6
0000707b885d70c4  vmovaps [rsp+0x60], xmm7
0000707b885d70ca  vmovaps [rsp+0x70], xmm8
0000707b885d70d0  vmovaps [rsp+0x80], xmm9
0000707b885d70d9  vmovaps [rsp+0x90], xmm10
0000707b885d70e2  vmovaps [rsp+0xA0], xmm11
0000707b885d70eb  vmovaps [rsp+0xB0], xmm12
0000707b885d70f4  vmovaps [rsp+0xC0], xmm13
0000707b885d70fd  vmovaps [rsp+0xD0], xmm14
0000707b885d7106  vmovaps [rsp+0xE0], xmm15
0000707b885d710f  sub rsp, 0x30
0000707b885d7113  movaps [rsp], xmm4
0000707b885d7117  movaps [rsp+0x10], xmm9
0000707b885d711d  movaps [rsp+0x20], xmm8
0000707b885d7123  lea rdi, [rsp]
0000707b885d7127  mov esi, 0x00
0000707b885d712c  mov rax, 0x6471B35AC530
0000707b885d7136  call rax
0000707b885d7138  movaps xmm4, [rsp]
0000707b885d713c  add rsp, 0x30
0000707b885d7140  vmovaps xmm0, [rsp]
0000707b885d7145  vmovaps xmm1, [rsp+0x10]
0000707b885d714b  vmovaps xmm2, [rsp+0x20]
0000707b885d7151  vmovaps xmm3, [rsp+0x30]
0000707b885d7157  vmovaps xmm5, [rsp+0x40]
0000707b885d715d  vmovaps xmm6, [rsp+0x50]
0000707b885d7163  vmovaps xmm7, [rsp+0x60]
0000707b885d7169  vmovaps xmm8, [rsp+0x70]
0000707b885d716f  vmovaps xmm9, [rsp+0x80]
0000707b885d7178  vmovaps xmm10, [rsp+0x90]
0000707b885d7181  vmovaps xmm11, [rsp+0xA0]
0000707b885d718a  vmovaps xmm12, [rsp+0xB0]
0000707b885d7193  vmovaps xmm13, [rsp+0xC0]
0000707b885d719c  vmovaps xmm14, [rsp+0xD0]
0000707b885d71a5  vmovaps xmm15, [rsp+0xE0]
0000707b885d71ae  add rsp, 0xF0
0000707b885d71b5  pop r11
0000707b885d71b7  pop r10
0000707b885d71b9  pop r9
0000707b885d71bb  pop r8
0000707b885d71bd  pop rsi
0000707b885d71be  pop rdi
0000707b885d71bf  pop rdx
0000707b885d71c0  pop rcx
0000707b885d71c1  pop rax
0000707b885d71c2  add rsp, 0x08
0000707b885d71c6  jmp 0x0000707B885D5AE1
0000707b885d71cb  sub rsp, 0x08
0000707b885d71cf  push rax
0000707b885d71d0  push rcx
0000707b885d71d1  push rdx
0000707b885d71d2  push rdi
0000707b885d71d3  push rsi
0000707b885d71d4  push r8
0000707b885d71d6  push r9
0000707b885d71d8  push r10
0000707b885d71da  push r11
0000707b885d71dc  sub rsp, 0xF0
0000707b885d71e3  vmovaps [rsp], xmm0
0000707b885d71e8  vmovaps [rsp+0x10], xmm1
0000707b885d71ee  vmovaps [rsp+0x20], xmm2
0000707b885d71f4  vmovaps [rsp+0x30], xmm3
0000707b885d71fa  vmovaps [rsp+0x40], xmm4
0000707b885d7200  vmovaps [rsp+0x50], xmm5
0000707b885d7206  vmovaps [rsp+0x60], xmm6
0000707b885d720c  vmovaps [rsp+0x70], xmm7
0000707b885d7212  vmovaps [rsp+0x80], xmm8
0000707b885d721b  vmovaps [rsp+0x90], xmm10
0000707b885d7224  vmovaps [rsp+0xA0], xmm11
0000707b885d722d  vmovaps [rsp+0xB0], xmm12
0000707b885d7236  vmovaps [rsp+0xC0], xmm13
0000707b885d723f  vmovaps [rsp+0xD0], xmm14
0000707b885d7248  vmovaps [rsp+0xE0], xmm15
0000707b885d7251  sub rsp, 0x30
0000707b885d7255  movaps [rsp], xmm9
0000707b885d725a  movaps [rsp+0x10], xmm10
0000707b885d7260  movaps [rsp+0x20], xmm8
0000707b885d7266  lea rdi, [rsp]
0000707b885d726a  mov esi, 0x00
0000707b885d726f  mov rax, 0x6471B35AC530
0000707b885d7279  call rax
0000707b885d727b  movaps xmm9, [rsp]
0000707b885d7280  add rsp, 0x30
0000707b885d7284  vmovaps xmm0, [rsp]
0000707b885d7289  vmovaps xmm1, [rsp+0x10]
0000707b885d728f  vmovaps xmm2, [rsp+0x20]
0000707b885d7295  vmovaps xmm3, [rsp+0x30]
0000707b885d729b  vmovaps xmm4, [rsp+0x40]
0000707b885d72a1  vmovaps xmm5, [rsp+0x50]
0000707b885d72a7  vmovaps xmm6, [rsp+0x60]
0000707b885d72ad  vmovaps xmm7, [rsp+0x70]
0000707b885d72b3  vmovaps xmm8, [rsp+0x80]
0000707b885d72bc  vmovaps xmm10, [rsp+0x90]
0000707b885d72c5  vmovaps xmm11, [rsp+0xA0]
0000707b885d72ce  vmovaps xmm12, [rsp+0xB0]
0000707b885d72d7  vmovaps xmm13, [rsp+0xC0]
0000707b885d72e0  vmovaps xmm14, [rsp+0xD0]
0000707b885d72e9  vmovaps xmm15, [rsp+0xE0]
0000707b885d72f2  add rsp, 0xF0
0000707b885d72f9  pop r11
0000707b885d72fb  pop r10
0000707b885d72fd  pop r9
0000707b885d72ff  pop r8
0000707b885d7301  pop rsi
0000707b885d7302  pop rdi
0000707b885d7303  pop rdx
0000707b885d7304  pop rcx
0000707b885d7305  pop rax
0000707b885d7306  add rsp, 0x08
0000707b885d730a  jmp 0x0000707B885D5AFB
0000707b885d730f  call 0x0000707B884D64F0
0000707b885d7314  jmp 0x0000707B885D5C15
0000707b885d7319  call 0x0000707B884D64F0
0000707b885d731e  jmp 0x0000707B885D5C2B
0000707b885d7323  sub rsp, 0x08
0000707b885d7327  push rax
0000707b885d7328  push rcx
0000707b885d7329  push rdx
0000707b885d732a  push rdi
0000707b885d732b  push rsi
0000707b885d732c  push r8
0000707b885d732e  push r9
0000707b885d7330  push r10
0000707b885d7332  push r11
0000707b885d7334  sub rsp, 0xF0
0000707b885d733b  vmovaps [rsp], xmm0
0000707b885d7340  vmovaps [rsp+0x10], xmm2
0000707b885d7346  vmovaps [rsp+0x20], xmm3
0000707b885d734c  vmovaps [rsp+0x30], xmm4
0000707b885d7352  vmovaps [rsp+0x40], xmm5
0000707b885d7358  vmovaps [rsp+0x50], xmm6
0000707b885d735e  vmovaps [rsp+0x60], xmm7
0000707b885d7364  vmovaps [rsp+0x70], xmm8
0000707b885d736a  vmovaps [rsp+0x80], xmm9
0000707b885d7373  vmovaps [rsp+0x90], xmm10
0000707b885d737c  vmovaps [rsp+0xA0], xmm11
0000707b885d7385  vmovaps [rsp+0xB0], xmm12
0000707b885d738e  vmovaps [rsp+0xC0], xmm13
0000707b885d7397  vmovaps [rsp+0xD0], xmm14
0000707b885d73a0  vmovaps [rsp+0xE0], xmm15
0000707b885d73a9  sub rsp, 0x30
0000707b885d73ad  movaps [rsp], xmm1
0000707b885d73b1  movaps [rsp+0x10], xmm6
0000707b885d73b6  movaps [rsp+0x20], xmm15
0000707b885d73bc  lea rdi, [rsp]
0000707b885d73c0  mov esi, 0x00
0000707b885d73c5  mov rax, 0x6471B35AC530
0000707b885d73cf  call rax
0000707b885d73d1  movaps xmm1, [rsp]
0000707b885d73d5  add rsp, 0x30
0000707b885d73d9  vmovaps xmm0, [rsp]
0000707b885d73de  vmovaps xmm2, [rsp+0x10]
0000707b885d73e4  vmovaps xmm3, [rsp+0x20]
0000707b885d73ea  vmovaps xmm4, [rsp+0x30]
0000707b885d73f0  vmovaps xmm5, [rsp+0x40]
0000707b885d73f6  vmovaps xmm6, [rsp+0x50]
0000707b885d73fc  vmovaps xmm7, [rsp+0x60]
0000707b885d7402  vmovaps xmm8, [rsp+0x70]
0000707b885d7408  vmovaps xmm9, [rsp+0x80]
0000707b885d7411  vmovaps xmm10, [rsp+0x90]
0000707b885d741a  vmovaps xmm11, [rsp+0xA0]
0000707b885d7423  vmovaps xmm12, [rsp+0xB0]
0000707b885d742c  vmovaps xmm13, [rsp+0xC0]
0000707b885d7435  vmovaps xmm14, [rsp+0xD0]
0000707b885d743e  vmovaps xmm15, [rsp+0xE0]
0000707b885d7447  add rsp, 0xF0
0000707b885d744e  pop r11
0000707b885d7450  pop r10
0000707b885d7452  pop r9
0000707b885d7454  pop r8
0000707b885d7456  pop rsi
0000707b885d7457  pop rdi
0000707b885d7458  pop rdx
0000707b885d7459  pop rcx
0000707b885d745a  pop rax
0000707b885d745b  add rsp, 0x08
0000707b885d745f  jmp 0x0000707B885D5C68
0000707b885d7464  call 0x0000707B884E5820
0000707b885d7469  jmp 0x0000707B885D5C75
0000707b885d746e  sub rsp, 0x08
0000707b885d7472  push rax
0000707b885d7473  push rcx
0000707b885d7474  push rdx
0000707b885d7475  push rdi
0000707b885d7476  push rsi
0000707b885d7477  push r8
0000707b885d7479  push r9
0000707b885d747b  push r10
0000707b885d747d  push r11
0000707b885d747f  sub rsp, 0xF0
0000707b885d7486  vmovaps [rsp], xmm0
0000707b885d748b  vmovaps [rsp+0x10], xmm1
0000707b885d7491  vmovaps [rsp+0x20], xmm2
0000707b885d7497  vmovaps [rsp+0x30], xmm3
0000707b885d749d  vmovaps [rsp+0x40], xmm4
0000707b885d74a3  vmovaps [rsp+0x50], xmm5
0000707b885d74a9  vmovaps [rsp+0x60], xmm6
0000707b885d74af  vmovaps [rsp+0x70], xmm7
0000707b885d74b5  vmovaps [rsp+0x80], xmm8
0000707b885d74be  vmovaps [rsp+0x90], xmm9
0000707b885d74c7  vmovaps [rsp+0xA0], xmm10
0000707b885d74d0  vmovaps [rsp+0xB0], xmm11
0000707b885d74d9  vmovaps [rsp+0xC0], xmm12
0000707b885d74e2  vmovaps [rsp+0xD0], xmm13
0000707b885d74eb  vmovaps [rsp+0xE0], xmm15
0000707b885d74f4  sub rsp, 0x30
0000707b885d74f8  movaps [rsp], xmm14
0000707b885d74fd  movaps [rsp+0x10], xmm4
0000707b885d7502  movaps [rsp+0x20], xmm3
0000707b885d7507  lea rdi, [rsp]
0000707b885d750b  mov esi, 0x00
0000707b885d7510  mov rax, 0x6471B35AC530
0000707b885d751a  call rax
0000707b885d751c  movaps xmm14, [rsp]
0000707b885d7521  add rsp, 0x30
0000707b885d7525  vmovaps xmm0, [rsp]
0000707b885d752a  vmovaps xmm1, [rsp+0x10]
0000707b885d7530  vmovaps xmm2, [rsp+0x20]
0000707b885d7536  vmovaps xmm3, [rsp+0x30]
0000707b885d753c  vmovaps xmm4, [rsp+0x40]
0000707b885d7542  vmovaps xmm5, [rsp+0x50]
0000707b885d7548  vmovaps xmm6, [rsp+0x60]
0000707b885d754e  vmovaps xmm7, [rsp+0x70]
0000707b885d7554  vmovaps xmm8, [rsp+0x80]
0000707b885d755d  vmovaps xmm9, [rsp+0x90]
0000707b885d7566  vmovaps xmm10, [rsp+0xA0]
0000707b885d756f  vmovaps xmm11, [rsp+0xB0]
0000707b885d7578  vmovaps xmm12, [rsp+0xC0]
0000707b885d7581  vmovaps xmm13, [rsp+0xD0]
0000707b885d758a  vmovaps xmm15, [rsp+0xE0]
0000707b885d7593  add rsp, 0xF0
0000707b885d759a  pop r11
0000707b885d759c  pop r10
0000707b885d759e  pop r9
0000707b885d75a0  pop r8
0000707b885d75a2  pop rsi
0000707b885d75a3  pop rdi
0000707b885d75a4  pop rdx
0000707b885d75a5  pop rcx
0000707b885d75a6  pop rax
0000707b885d75a7  add rsp, 0x08
0000707b885d75ab  jmp 0x0000707B885D5C8F
0000707b885d75b0  sub rsp, 0x08
0000707b885d75b4  push rax
0000707b885d75b5  push rcx
0000707b885d75b6  push rdx
0000707b885d75b7  push rdi
0000707b885d75b8  push rsi
0000707b885d75b9  push r8
0000707b885d75bb  push r9
0000707b885d75bd  push r10
0000707b885d75bf  push r11
0000707b885d75c1  sub rsp, 0xF0
0000707b885d75c8  vmovaps [rsp], xmm0
0000707b885d75cd  vmovaps [rsp+0x10], xmm1
0000707b885d75d3  vmovaps [rsp+0x20], xmm2
0000707b885d75d9  vmovaps [rsp+0x30], xmm3
0000707b885d75df  vmovaps [rsp+0x40], xmm4
0000707b885d75e5  vmovaps [rsp+0x50], xmm5
0000707b885d75eb  vmovaps [rsp+0x60], xmm7
0000707b885d75f1  vmovaps [rsp+0x70], xmm8
0000707b885d75f7  vmovaps [rsp+0x80], xmm9
0000707b885d7600  vmovaps [rsp+0x90], xmm10
0000707b885d7609  vmovaps [rsp+0xA0], xmm11
0000707b885d7612  vmovaps [rsp+0xB0], xmm12
0000707b885d761b  vmovaps [rsp+0xC0], xmm13
0000707b885d7624  vmovaps [rsp+0xD0], xmm14
0000707b885d762d  vmovaps [rsp+0xE0], xmm15
0000707b885d7636  sub rsp, 0x30
0000707b885d763a  movaps [rsp], xmm6
0000707b885d763e  movaps [rsp+0x10], xmm9
0000707b885d7644  movaps [rsp+0x20], xmm7
0000707b885d7649  lea rdi, [rsp]
0000707b885d764d  mov esi, 0x00
0000707b885d7652  mov rax, 0x6471B35AC530
0000707b885d765c  call rax
0000707b885d765e  movaps xmm6, [rsp]
0000707b885d7662  add rsp, 0x30
0000707b885d7666  vmovaps xmm0, [rsp]
0000707b885d766b  vmovaps xmm1, [rsp+0x10]
0000707b885d7671  vmovaps xmm2, [rsp+0x20]
0000707b885d7677  vmovaps xmm3, [rsp+0x30]
0000707b885d767d  vmovaps xmm4, [rsp+0x40]
0000707b885d7683  vmovaps xmm5, [rsp+0x50]
0000707b885d7689  vmovaps xmm7, [rsp+0x60]
0000707b885d768f  vmovaps xmm8, [rsp+0x70]
0000707b885d7695  vmovaps xmm9, [rsp+0x80]
0000707b885d769e  vmovaps xmm10, [rsp+0x90]
0000707b885d76a7  vmovaps xmm11, [rsp+0xA0]
0000707b885d76b0  vmovaps xmm12, [rsp+0xB0]
0000707b885d76b9  vmovaps xmm13, [rsp+0xC0]
0000707b885d76c2  vmovaps xmm14, [rsp+0xD0]
0000707b885d76cb  vmovaps xmm15, [rsp+0xE0]
0000707b885d76d4  add rsp, 0xF0
0000707b885d76db  pop r11
0000707b885d76dd  pop r10
0000707b885d76df  pop r9
0000707b885d76e1  pop r8
0000707b885d76e3  pop rsi
0000707b885d76e4  pop rdi
0000707b885d76e5  pop rdx
0000707b885d76e6  pop rcx
0000707b885d76e7  pop rax
0000707b885d76e8  add rsp, 0x08
0000707b885d76ec  jmp 0x0000707B885D5CA7
0000707b885d76f1  sub rsp, 0x08
0000707b885d76f5  push rax
0000707b885d76f6  push rcx
0000707b885d76f7  push rdx
0000707b885d76f8  push rdi
0000707b885d76f9  push rsi
0000707b885d76fa  push r8
0000707b885d76fc  push r9
0000707b885d76fe  push r10
0000707b885d7700  push r11
0000707b885d7702  sub rsp, 0xF0
0000707b885d7709  vmovaps [rsp], xmm0
0000707b885d770e  vmovaps [rsp+0x10], xmm1
0000707b885d7714  vmovaps [rsp+0x20], xmm2
0000707b885d771a  vmovaps [rsp+0x30], xmm3
0000707b885d7720  vmovaps [rsp+0x40], xmm4
0000707b885d7726  vmovaps [rsp+0x50], xmm5
0000707b885d772c  vmovaps [rsp+0x60], xmm6
0000707b885d7732  vmovaps [rsp+0x70], xmm8
0000707b885d7738  vmovaps [rsp+0x80], xmm9
0000707b885d7741  vmovaps [rsp+0x90], xmm10
0000707b885d774a  vmovaps [rsp+0xA0], xmm11
0000707b885d7753  vmovaps [rsp+0xB0], xmm12
0000707b885d775c  vmovaps [rsp+0xC0], xmm13
0000707b885d7765  vmovaps [rsp+0xD0], xmm14
0000707b885d776e  vmovaps [rsp+0xE0], xmm15
0000707b885d7777  sub rsp, 0x30
0000707b885d777b  movaps [rsp], xmm7
0000707b885d777f  movaps [rsp+0x10], xmm4
0000707b885d7784  movaps [rsp+0x20], xmm9
0000707b885d778a  lea rdi, [rsp]
0000707b885d778e  mov esi, 0x00
0000707b885d7793  mov rax, 0x6471B35AC530
0000707b885d779d  call rax
0000707b885d779f  movaps xmm7, [rsp]
0000707b885d77a3  add rsp, 0x30
0000707b885d77a7  vmovaps xmm0, [rsp]
0000707b885d77ac  vmovaps xmm1, [rsp+0x10]
0000707b885d77b2  vmovaps xmm2, [rsp+0x20]
0000707b885d77b8  vmovaps xmm3, [rsp+0x30]
0000707b885d77be  vmovaps xmm4, [rsp+0x40]
0000707b885d77c4  vmovaps xmm5, [rsp+0x50]
0000707b885d77ca  vmovaps xmm6, [rsp+0x60]
0000707b885d77d0  vmovaps xmm8, [rsp+0x70]
0000707b885d77d6  vmovaps xmm9, [rsp+0x80]
0000707b885d77df  vmovaps xmm10, [rsp+0x90]
0000707b885d77e8  vmovaps xmm11, [rsp+0xA0]
0000707b885d77f1  vmovaps xmm12, [rsp+0xB0]
0000707b885d77fa  vmovaps xmm13, [rsp+0xC0]
0000707b885d7803  vmovaps xmm14, [rsp+0xD0]
0000707b885d780c  vmovaps xmm15, [rsp+0xE0]
0000707b885d7815  add rsp, 0xF0
0000707b885d781c  pop r11
0000707b885d781e  pop r10
0000707b885d7820  pop r9
0000707b885d7822  pop r8
0000707b885d7824  pop rsi
0000707b885d7825  pop rdi
0000707b885d7826  pop rdx
0000707b885d7827  pop rcx
0000707b885d7828  pop rax
0000707b885d7829  add rsp, 0x08
0000707b885d782d  jmp 0x0000707B885D5CD4
0000707b885d7832  sub rsp, 0x08
0000707b885d7836  push rax
0000707b885d7837  push rcx
0000707b885d7838  push rdx
0000707b885d7839  push rdi
0000707b885d783a  push rsi
0000707b885d783b  push r8
0000707b885d783d  push r9
0000707b885d783f  push r10
0000707b885d7841  push r11
0000707b885d7843  sub rsp, 0xF0
0000707b885d784a  vmovaps [rsp], xmm0
0000707b885d784f  vmovaps [rsp+0x10], xmm1
0000707b885d7855  vmovaps [rsp+0x20], xmm2
0000707b885d785b  vmovaps [rsp+0x30], xmm3
0000707b885d7861  vmovaps [rsp+0x40], xmm5
0000707b885d7867  vmovaps [rsp+0x50], xmm6
0000707b885d786d  vmovaps [rsp+0x60], xmm7
0000707b885d7873  vmovaps [rsp+0x70], xmm8
0000707b885d7879  vmovaps [rsp+0x80], xmm9
0000707b885d7882  vmovaps [rsp+0x90], xmm10
0000707b885d788b  vmovaps [rsp+0xA0], xmm11
0000707b885d7894  vmovaps [rsp+0xB0], xmm12
0000707b885d789d  vmovaps [rsp+0xC0], xmm13
0000707b885d78a6  vmovaps [rsp+0xD0], xmm14
0000707b885d78af  vmovaps [rsp+0xE0], xmm15
0000707b885d78b8  sub rsp, 0x30
0000707b885d78bc  movaps [rsp], xmm4
0000707b885d78c0  movaps [rsp+0x10], xmm15
0000707b885d78c6  movaps [rsp+0x20], xmm9
0000707b885d78cc  lea rdi, [rsp]
0000707b885d78d0  mov esi, 0x00
0000707b885d78d5  mov rax, 0x6471B35AC530
0000707b885d78df  call rax
0000707b885d78e1  movaps xmm4, [rsp]
0000707b885d78e5  add rsp, 0x30
0000707b885d78e9  vmovaps xmm0, [rsp]
0000707b885d78ee  vmovaps xmm1, [rsp+0x10]
0000707b885d78f4  vmovaps xmm2, [rsp+0x20]
0000707b885d78fa  vmovaps xmm3, [rsp+0x30]
0000707b885d7900  vmovaps xmm5, [rsp+0x40]
0000707b885d7906  vmovaps xmm6, [rsp+0x50]
0000707b885d790c  vmovaps xmm7, [rsp+0x60]
0000707b885d7912  vmovaps xmm8, [rsp+0x70]
0000707b885d7918  vmovaps xmm9, [rsp+0x80]
0000707b885d7921  vmovaps xmm10, [rsp+0x90]
0000707b885d792a  vmovaps xmm11, [rsp+0xA0]
0000707b885d7933  vmovaps xmm12, [rsp+0xB0]
0000707b885d793c  vmovaps xmm13, [rsp+0xC0]
0000707b885d7945  vmovaps xmm14, [rsp+0xD0]
0000707b885d794e  vmovaps xmm15, [rsp+0xE0]
0000707b885d7957  add rsp, 0xF0
0000707b885d795e  pop r11
0000707b885d7960  pop r10
0000707b885d7962  pop r9
0000707b885d7964  pop r8
0000707b885d7966  pop rsi
0000707b885d7967  pop rdi
0000707b885d7968  pop rdx
0000707b885d7969  pop rcx
0000707b885d796a  pop rax
0000707b885d796b  add rsp, 0x08
0000707b885d796f  jmp 0x0000707B885D5CF9
0000707b885d7974  call 0x0000707B884E5820
0000707b885d7979  jmp 0x0000707B885D5D06
0000707b885d797e  sub rsp, 0x08
0000707b885d7982  push rax
0000707b885d7983  push rcx
0000707b885d7984  push rdx
0000707b885d7985  push rdi
0000707b885d7986  push rsi
0000707b885d7987  push r8
0000707b885d7989  push r9
0000707b885d798b  push r10
0000707b885d798d  push r11
0000707b885d798f  sub rsp, 0xF0
0000707b885d7996  vmovaps [rsp], xmm0
0000707b885d799b  vmovaps [rsp+0x10], xmm1
0000707b885d79a1  vmovaps [rsp+0x20], xmm2
0000707b885d79a7  vmovaps [rsp+0x30], xmm4
0000707b885d79ad  vmovaps [rsp+0x40], xmm5
0000707b885d79b3  vmovaps [rsp+0x50], xmm6
0000707b885d79b9  vmovaps [rsp+0x60], xmm7
0000707b885d79bf  vmovaps [rsp+0x70], xmm8
0000707b885d79c5  vmovaps [rsp+0x80], xmm9
0000707b885d79ce  vmovaps [rsp+0x90], xmm10
0000707b885d79d7  vmovaps [rsp+0xA0], xmm11
0000707b885d79e0  vmovaps [rsp+0xB0], xmm12
0000707b885d79e9  vmovaps [rsp+0xC0], xmm13
0000707b885d79f2  vmovaps [rsp+0xD0], xmm14
0000707b885d79fb  vmovaps [rsp+0xE0], xmm15
0000707b885d7a04  sub rsp, 0x30
0000707b885d7a08  movaps [rsp], xmm3
0000707b885d7a0c  movaps [rsp+0x10], xmm1
0000707b885d7a11  movaps [rsp+0x20], xmm9
0000707b885d7a17  lea rdi, [rsp]
0000707b885d7a1b  mov esi, 0x00
0000707b885d7a20  mov rax, 0x6471B35AC530
0000707b885d7a2a  call rax
0000707b885d7a2c  movaps xmm3, [rsp]
0000707b885d7a30  add rsp, 0x30
0000707b885d7a34  vmovaps xmm0, [rsp]
0000707b885d7a39  vmovaps xmm1, [rsp+0x10]
0000707b885d7a3f  vmovaps xmm2, [rsp+0x20]
0000707b885d7a45  vmovaps xmm4, [rsp+0x30]
0000707b885d7a4b  vmovaps xmm5, [rsp+0x40]
0000707b885d7a51  vmovaps xmm6, [rsp+0x50]
0000707b885d7a57  vmovaps xmm7, [rsp+0x60]
0000707b885d7a5d  vmovaps xmm8, [rsp+0x70]
0000707b885d7a63  vmovaps xmm9, [rsp+0x80]
0000707b885d7a6c  vmovaps xmm10, [rsp+0x90]
0000707b885d7a75  vmovaps xmm11, [rsp+0xA0]
0000707b885d7a7e  vmovaps xmm12, [rsp+0xB0]
0000707b885d7a87  vmovaps xmm13, [rsp+0xC0]
0000707b885d7a90  vmovaps xmm14, [rsp+0xD0]
0000707b885d7a99  vmovaps xmm15, [rsp+0xE0]
0000707b885d7aa2  add rsp, 0xF0
0000707b885d7aa9  pop r11
0000707b885d7aab  pop r10
0000707b885d7aad  pop r9
0000707b885d7aaf  pop r8
0000707b885d7ab1  pop rsi
0000707b885d7ab2  pop rdi
0000707b885d7ab3  pop rdx
0000707b885d7ab4  pop rcx
0000707b885d7ab5  pop rax
0000707b885d7ab6  add rsp, 0x08
0000707b885d7aba  jmp 0x0000707B885D5D43
0000707b885d7abf  sub rsp, 0x08
0000707b885d7ac3  push rax
0000707b885d7ac4  push rcx
0000707b885d7ac5  push rdx
0000707b885d7ac6  push rdi
0000707b885d7ac7  push rsi
0000707b885d7ac8  push r8
0000707b885d7aca  push r9
0000707b885d7acc  push r10
0000707b885d7ace  push r11
0000707b885d7ad0  sub rsp, 0xF0
0000707b885d7ad7  vmovaps [rsp], xmm0
0000707b885d7adc  vmovaps [rsp+0x10], xmm2
0000707b885d7ae2  vmovaps [rsp+0x20], xmm3
0000707b885d7ae8  vmovaps [rsp+0x30], xmm4
0000707b885d7aee  vmovaps [rsp+0x40], xmm5
0000707b885d7af4  vmovaps [rsp+0x50], xmm6
0000707b885d7afa  vmovaps [rsp+0x60], xmm7
0000707b885d7b00  vmovaps [rsp+0x70], xmm8
0000707b885d7b06  vmovaps [rsp+0x80], xmm9
0000707b885d7b0f  vmovaps [rsp+0x90], xmm10
0000707b885d7b18  vmovaps [rsp+0xA0], xmm11
0000707b885d7b21  vmovaps [rsp+0xB0], xmm12
0000707b885d7b2a  vmovaps [rsp+0xC0], xmm13
0000707b885d7b33  vmovaps [rsp+0xD0], xmm14
0000707b885d7b3c  vmovaps [rsp+0xE0], xmm15
0000707b885d7b45  sub rsp, 0x30
0000707b885d7b49  movaps [rsp], xmm1
0000707b885d7b4d  movaps [rsp+0x10], xmm15
0000707b885d7b53  movaps [rsp+0x20], xmm9
0000707b885d7b59  lea rdi, [rsp]
0000707b885d7b5d  mov esi, 0x00
0000707b885d7b62  mov rax, 0x6471B35AC530
0000707b885d7b6c  call rax
0000707b885d7b6e  movaps xmm1, [rsp]
0000707b885d7b72  add rsp, 0x30
0000707b885d7b76  vmovaps xmm0, [rsp]
0000707b885d7b7b  vmovaps xmm2, [rsp+0x10]
0000707b885d7b81  vmovaps xmm3, [rsp+0x20]
0000707b885d7b87  vmovaps xmm4, [rsp+0x30]
0000707b885d7b8d  vmovaps xmm5, [rsp+0x40]
0000707b885d7b93  vmovaps xmm6, [rsp+0x50]
0000707b885d7b99  vmovaps xmm7, [rsp+0x60]
0000707b885d7b9f  vmovaps xmm8, [rsp+0x70]
0000707b885d7ba5  vmovaps xmm9, [rsp+0x80]
0000707b885d7bae  vmovaps xmm10, [rsp+0x90]
0000707b885d7bb7  vmovaps xmm11, [rsp+0xA0]
0000707b885d7bc0  vmovaps xmm12, [rsp+0xB0]
0000707b885d7bc9  vmovaps xmm13, [rsp+0xC0]
0000707b885d7bd2  vmovaps xmm14, [rsp+0xD0]
0000707b885d7bdb  vmovaps xmm15, [rsp+0xE0]
0000707b885d7be4  add rsp, 0xF0
0000707b885d7beb  pop r11
0000707b885d7bed  pop r10
0000707b885d7bef  pop r9
0000707b885d7bf1  pop r8
0000707b885d7bf3  pop rsi
0000707b885d7bf4  pop rdi
0000707b885d7bf5  pop rdx
0000707b885d7bf6  pop rcx
0000707b885d7bf7  pop rax
0000707b885d7bf8  add rsp, 0x08
0000707b885d7bfc  jmp 0x0000707B885D5DCB
0000707b885d7c01  call 0x0000707B884E5820
0000707b885d7c06  jmp 0x0000707B885D5DD8
0000707b885d7c0b  sub rsp, 0x08
0000707b885d7c0f  push rax
0000707b885d7c10  push rcx
0000707b885d7c11  push rdx
0000707b885d7c12  push rdi
0000707b885d7c13  push rsi
0000707b885d7c14  push r8
0000707b885d7c16  push r9
0000707b885d7c18  push r10
0000707b885d7c1a  push r11
0000707b885d7c1c  sub rsp, 0xF0
0000707b885d7c23  vmovaps [rsp], xmm0
0000707b885d7c28  vmovaps [rsp+0x10], xmm2
0000707b885d7c2e  vmovaps [rsp+0x20], xmm3
0000707b885d7c34  vmovaps [rsp+0x30], xmm4
0000707b885d7c3a  vmovaps [rsp+0x40], xmm5
0000707b885d7c40  vmovaps [rsp+0x50], xmm6
0000707b885d7c46  vmovaps [rsp+0x60], xmm7
0000707b885d7c4c  vmovaps [rsp+0x70], xmm8
0000707b885d7c52  vmovaps [rsp+0x80], xmm9
0000707b885d7c5b  vmovaps [rsp+0x90], xmm10
0000707b885d7c64  vmovaps [rsp+0xA0], xmm11
0000707b885d7c6d  vmovaps [rsp+0xB0], xmm12
0000707b885d7c76  vmovaps [rsp+0xC0], xmm13
0000707b885d7c7f  vmovaps [rsp+0xD0], xmm14
0000707b885d7c88  vmovaps [rsp+0xE0], xmm15
0000707b885d7c91  sub rsp, 0x30
0000707b885d7c95  movaps [rsp], xmm1
0000707b885d7c99  movaps [rsp+0x10], xmm5
0000707b885d7c9e  movaps [rsp+0x20], xmm7
0000707b885d7ca3  lea rdi, [rsp]
0000707b885d7ca7  mov esi, 0x00
0000707b885d7cac  mov rax, 0x6471B35AC530
0000707b885d7cb6  call rax
0000707b885d7cb8  movaps xmm1, [rsp]
0000707b885d7cbc  add rsp, 0x30
0000707b885d7cc0  vmovaps xmm0, [rsp]
0000707b885d7cc5  vmovaps xmm2, [rsp+0x10]
0000707b885d7ccb  vmovaps xmm3, [rsp+0x20]
0000707b885d7cd1  vmovaps xmm4, [rsp+0x30]
0000707b885d7cd7  vmovaps xmm5, [rsp+0x40]
0000707b885d7cdd  vmovaps xmm6, [rsp+0x50]
0000707b885d7ce3  vmovaps xmm7, [rsp+0x60]
0000707b885d7ce9  vmovaps xmm8, [rsp+0x70]
0000707b885d7cef  vmovaps xmm9, [rsp+0x80]
0000707b885d7cf8  vmovaps xmm10, [rsp+0x90]
0000707b885d7d01  vmovaps xmm11, [rsp+0xA0]
0000707b885d7d0a  vmovaps xmm12, [rsp+0xB0]
0000707b885d7d13  vmovaps xmm13, [rsp+0xC0]
0000707b885d7d1c  vmovaps xmm14, [rsp+0xD0]
0000707b885d7d25  vmovaps xmm15, [rsp+0xE0]
0000707b885d7d2e  add rsp, 0xF0
0000707b885d7d35  pop r11
0000707b885d7d37  pop r10
0000707b885d7d39  pop r9
0000707b885d7d3b  pop r8
0000707b885d7d3d  pop rsi
0000707b885d7d3e  pop rdi
0000707b885d7d3f  pop rdx
0000707b885d7d40  pop rcx
0000707b885d7d41  pop rax
0000707b885d7d42  add rsp, 0x08
0000707b885d7d46  jmp 0x0000707B885D5E7D
0000707b885d7d4b  sub rsp, 0x08
0000707b885d7d4f  push rax
0000707b885d7d50  push rcx
0000707b885d7d51  push rdx
0000707b885d7d52  push rdi
0000707b885d7d53  push rsi
0000707b885d7d54  push r8
0000707b885d7d56  push r9
0000707b885d7d58  push r10
0000707b885d7d5a  push r11
0000707b885d7d5c  sub rsp, 0xF0
0000707b885d7d63  vmovaps [rsp], xmm0
0000707b885d7d68  vmovaps [rsp+0x10], xmm1
0000707b885d7d6e  vmovaps [rsp+0x20], xmm2
0000707b885d7d74  vmovaps [rsp+0x30], xmm3
0000707b885d7d7a  vmovaps [rsp+0x40], xmm4
0000707b885d7d80  vmovaps [rsp+0x50], xmm5
0000707b885d7d86  vmovaps [rsp+0x60], xmm6
0000707b885d7d8c  vmovaps [rsp+0x70], xmm8
0000707b885d7d92  vmovaps [rsp+0x80], xmm9
0000707b885d7d9b  vmovaps [rsp+0x90], xmm10
0000707b885d7da4  vmovaps [rsp+0xA0], xmm11
0000707b885d7dad  vmovaps [rsp+0xB0], xmm12
0000707b885d7db6  vmovaps [rsp+0xC0], xmm13
0000707b885d7dbf  vmovaps [rsp+0xD0], xmm14
0000707b885d7dc8  vmovaps [rsp+0xE0], xmm15
0000707b885d7dd1  sub rsp, 0x30
0000707b885d7dd5  movaps [rsp], xmm7
0000707b885d7dd9  movaps [rsp+0x10], xmm5
0000707b885d7dde  movaps [rsp+0x20], xmm15
0000707b885d7de4  lea rdi, [rsp]
0000707b885d7de8  mov esi, 0x00
0000707b885d7ded  mov rax, 0x6471B35AC530
0000707b885d7df7  call rax
0000707b885d7df9  movaps xmm7, [rsp]
0000707b885d7dfd  add rsp, 0x30
0000707b885d7e01  vmovaps xmm0, [rsp]
0000707b885d7e06  vmovaps xmm1, [rsp+0x10]
0000707b885d7e0c  vmovaps xmm2, [rsp+0x20]
0000707b885d7e12  vmovaps xmm3, [rsp+0x30]
0000707b885d7e18  vmovaps xmm4, [rsp+0x40]
0000707b885d7e1e  vmovaps xmm5, [rsp+0x50]
0000707b885d7e24  vmovaps xmm6, [rsp+0x60]
0000707b885d7e2a  vmovaps xmm8, [rsp+0x70]
0000707b885d7e30  vmovaps xmm9, [rsp+0x80]
0000707b885d7e39  vmovaps xmm10, [rsp+0x90]
0000707b885d7e42  vmovaps xmm11, [rsp+0xA0]
0000707b885d7e4b  vmovaps xmm12, [rsp+0xB0]
0000707b885d7e54  vmovaps xmm13, [rsp+0xC0]
0000707b885d7e5d  vmovaps xmm14, [rsp+0xD0]
0000707b885d7e66  vmovaps xmm15, [rsp+0xE0]
0000707b885d7e6f  add rsp, 0xF0
0000707b885d7e76  pop r11
0000707b885d7e78  pop r10
0000707b885d7e7a  pop r9
0000707b885d7e7c  pop r8
0000707b885d7e7e  pop rsi
0000707b885d7e7f  pop rdi
0000707b885d7e80  pop rdx
0000707b885d7e81  pop rcx
0000707b885d7e82  pop rax
0000707b885d7e83  add rsp, 0x08
0000707b885d7e87  jmp 0x0000707B885D5EB3
0000707b885d7e8c  call 0x0000707B884D64F0
0000707b885d7e91  jmp 0x0000707B885D5EC0
0000707b885d7e96  sub rsp, 0x08
0000707b885d7e9a  push rax
0000707b885d7e9b  push rcx
0000707b885d7e9c  push rdx
0000707b885d7e9d  push rdi
0000707b885d7e9e  push rsi
0000707b885d7e9f  push r8
0000707b885d7ea1  push r9
0000707b885d7ea3  push r10
0000707b885d7ea5  push r11
0000707b885d7ea7  sub rsp, 0xF0
0000707b885d7eae  vmovaps [rsp], xmm0
0000707b885d7eb3  vmovaps [rsp+0x10], xmm1
0000707b885d7eb9  vmovaps [rsp+0x20], xmm2
0000707b885d7ebf  vmovaps [rsp+0x30], xmm3
0000707b885d7ec5  vmovaps [rsp+0x40], xmm4
0000707b885d7ecb  vmovaps [rsp+0x50], xmm5
0000707b885d7ed1  vmovaps [rsp+0x60], xmm6
0000707b885d7ed7  vmovaps [rsp+0x70], xmm7
0000707b885d7edd  vmovaps [rsp+0x80], xmm8
0000707b885d7ee6  vmovaps [rsp+0x90], xmm9
0000707b885d7eef  vmovaps [rsp+0xA0], xmm10
0000707b885d7ef8  vmovaps [rsp+0xB0], xmm11
0000707b885d7f01  vmovaps [rsp+0xC0], xmm12
0000707b885d7f0a  vmovaps [rsp+0xD0], xmm13
0000707b885d7f13  vmovaps [rsp+0xE0], xmm14
0000707b885d7f1c  sub rsp, 0x30
0000707b885d7f20  movaps [rsp], xmm15
0000707b885d7f25  movaps [rsp+0x10], xmm5
0000707b885d7f2a  movaps [rsp+0x20], xmm3
0000707b885d7f2f  lea rdi, [rsp]
0000707b885d7f33  mov esi, 0x00
0000707b885d7f38  mov rax, 0x6471B35AC530
0000707b885d7f42  call rax
0000707b885d7f44  movaps xmm15, [rsp]
0000707b885d7f49  add rsp, 0x30
0000707b885d7f4d  vmovaps xmm0, [rsp]
0000707b885d7f52  vmovaps xmm1, [rsp+0x10]
0000707b885d7f58  vmovaps xmm2, [rsp+0x20]
0000707b885d7f5e  vmovaps xmm3, [rsp+0x30]
0000707b885d7f64  vmovaps xmm4, [rsp+0x40]
0000707b885d7f6a  vmovaps xmm5, [rsp+0x50]
0000707b885d7f70  vmovaps xmm6, [rsp+0x60]
0000707b885d7f76  vmovaps xmm7, [rsp+0x70]
0000707b885d7f7c  vmovaps xmm8, [rsp+0x80]
0000707b885d7f85  vmovaps xmm9, [rsp+0x90]
0000707b885d7f8e  vmovaps xmm10, [rsp+0xA0]
0000707b885d7f97  vmovaps xmm11, [rsp+0xB0]
0000707b885d7fa0  vmovaps xmm12, [rsp+0xC0]
0000707b885d7fa9  vmovaps xmm13, [rsp+0xD0]
0000707b885d7fb2  vmovaps xmm14, [rsp+0xE0]
0000707b885d7fbb  add rsp, 0xF0
0000707b885d7fc2  pop r11
0000707b885d7fc4  pop r10
0000707b885d7fc6  pop r9
0000707b885d7fc8  pop r8
0000707b885d7fca  pop rsi
0000707b885d7fcb  pop rdi
0000707b885d7fcc  pop rdx
0000707b885d7fcd  pop rcx
0000707b885d7fce  pop rax
0000707b885d7fcf  add rsp, 0x08
0000707b885d7fd3  jmp 0x0000707B885D5EE6
0000707b885d7fd8  sub rsp, 0x08
0000707b885d7fdc  push rax
0000707b885d7fdd  push rcx
0000707b885d7fde  push rdx
0000707b885d7fdf  push rdi
0000707b885d7fe0  push rsi
0000707b885d7fe1  push r8
0000707b885d7fe3  push r9
0000707b885d7fe5  push r10
0000707b885d7fe7  push r11
0000707b885d7fe9  sub rsp, 0xF0
0000707b885d7ff0  vmovaps [rsp], xmm0
0000707b885d7ff5  vmovaps [rsp+0x10], xmm2
0000707b885d7ffb  vmovaps [rsp+0x20], xmm3
0000707b885d8001  vmovaps [rsp+0x30], xmm4
0000707b885d8007  vmovaps [rsp+0x40], xmm5
0000707b885d800d  vmovaps [rsp+0x50], xmm6
0000707b885d8013  vmovaps [rsp+0x60], xmm7
0000707b885d8019  vmovaps [rsp+0x70], xmm8
0000707b885d801f  vmovaps [rsp+0x80], xmm9
0000707b885d8028  vmovaps [rsp+0x90], xmm10
0000707b885d8031  vmovaps [rsp+0xA0], xmm11
0000707b885d803a  vmovaps [rsp+0xB0], xmm12
0000707b885d8043  vmovaps [rsp+0xC0], xmm13
0000707b885d804c  vmovaps [rsp+0xD0], xmm14
0000707b885d8055  vmovaps [rsp+0xE0], xmm15
0000707b885d805e  sub rsp, 0x30
0000707b885d8062  movaps [rsp], xmm1
0000707b885d8066  movaps [rsp+0x10], xmm5
0000707b885d806b  movaps [rsp+0x20], xmm4
0000707b885d8070  lea rdi, [rsp]
0000707b885d8074  mov esi, 0x00
0000707b885d8079  mov rax, 0x6471B35AC530
0000707b885d8083  call rax
0000707b885d8085  movaps xmm1, [rsp]
0000707b885d8089  add rsp, 0x30
0000707b885d808d  vmovaps xmm0, [rsp]
0000707b885d8092  vmovaps xmm2, [rsp+0x10]
0000707b885d8098  vmovaps xmm3, [rsp+0x20]
0000707b885d809e  vmovaps xmm4, [rsp+0x30]
0000707b885d80a4  vmovaps xmm5, [rsp+0x40]
0000707b885d80aa  vmovaps xmm6, [rsp+0x50]
0000707b885d80b0  vmovaps xmm7, [rsp+0x60]
0000707b885d80b6  vmovaps xmm8, [rsp+0x70]
0000707b885d80bc  vmovaps xmm9, [rsp+0x80]
0000707b885d80c5  vmovaps xmm10, [rsp+0x90]
0000707b885d80ce  vmovaps xmm11, [rsp+0xA0]
0000707b885d80d7  vmovaps xmm12, [rsp+0xB0]
0000707b885d80e0  vmovaps xmm13, [rsp+0xC0]
0000707b885d80e9  vmovaps xmm14, [rsp+0xD0]
0000707b885d80f2  vmovaps xmm15, [rsp+0xE0]
0000707b885d80fb  add rsp, 0xF0
0000707b885d8102  pop r11
0000707b885d8104  pop r10
0000707b885d8106  pop r9
0000707b885d8108  pop r8
0000707b885d810a  pop rsi
0000707b885d810b  pop rdi
0000707b885d810c  pop rdx
0000707b885d810d  pop rcx
0000707b885d810e  pop rax
0000707b885d810f  add rsp, 0x08
0000707b885d8113  jmp 0x0000707B885D5F06
0000707b885d8118  sub rsp, 0x08
0000707b885d811c  push rax
0000707b885d811d  push rcx
0000707b885d811e  push rdx
0000707b885d811f  push rdi
0000707b885d8120  push rsi
0000707b885d8121  push r8
0000707b885d8123  push r9
0000707b885d8125  push r10
0000707b885d8127  push r11
0000707b885d8129  sub rsp, 0xF0
0000707b885d8130  vmovaps [rsp], xmm0
0000707b885d8135  vmovaps [rsp+0x10], xmm1
0000707b885d813b  vmovaps [rsp+0x20], xmm2
0000707b885d8141  vmovaps [rsp+0x30], xmm3
0000707b885d8147  vmovaps [rsp+0x40], xmm5
0000707b885d814d  vmovaps [rsp+0x50], xmm6
0000707b885d8153  vmovaps [rsp+0x60], xmm7
0000707b885d8159  vmovaps [rsp+0x70], xmm8
0000707b885d815f  vmovaps [rsp+0x80], xmm9
0000707b885d8168  vmovaps [rsp+0x90], xmm10
0000707b885d8171  vmovaps [rsp+0xA0], xmm11
0000707b885d817a  vmovaps [rsp+0xB0], xmm12
0000707b885d8183  vmovaps [rsp+0xC0], xmm13
0000707b885d818c  vmovaps [rsp+0xD0], xmm14
0000707b885d8195  vmovaps [rsp+0xE0], xmm15
0000707b885d819e  sub rsp, 0x30
0000707b885d81a2  movaps [rsp], xmm4
0000707b885d81a6  movaps [rsp+0x10], xmm3
0000707b885d81ab  movaps [rsp+0x20], xmm5
0000707b885d81b0  lea rdi, [rsp]
0000707b885d81b4  mov esi, 0x00
0000707b885d81b9  mov rax, 0x6471B35AC530
0000707b885d81c3  call rax
0000707b885d81c5  movaps xmm4, [rsp]
0000707b885d81c9  add rsp, 0x30
0000707b885d81cd  vmovaps xmm0, [rsp]
0000707b885d81d2  vmovaps xmm1, [rsp+0x10]
0000707b885d81d8  vmovaps xmm2, [rsp+0x20]
0000707b885d81de  vmovaps xmm3, [rsp+0x30]
0000707b885d81e4  vmovaps xmm5, [rsp+0x40]
0000707b885d81ea  vmovaps xmm6, [rsp+0x50]
0000707b885d81f0  vmovaps xmm7, [rsp+0x60]
0000707b885d81f6  vmovaps xmm8, [rsp+0x70]
0000707b885d81fc  vmovaps xmm9, [rsp+0x80]
0000707b885d8205  vmovaps xmm10, [rsp+0x90]
0000707b885d820e  vmovaps xmm11, [rsp+0xA0]
0000707b885d8217  vmovaps xmm12, [rsp+0xB0]
0000707b885d8220  vmovaps xmm13, [rsp+0xC0]
0000707b885d8229  vmovaps xmm14, [rsp+0xD0]
0000707b885d8232  vmovaps xmm15, [rsp+0xE0]
0000707b885d823b  add rsp, 0xF0
0000707b885d8242  pop r11
0000707b885d8244  pop r10
0000707b885d8246  pop r9
0000707b885d8248  pop r8
0000707b885d824a  pop rsi
0000707b885d824b  pop rdi
0000707b885d824c  pop rdx
0000707b885d824d  pop rcx
0000707b885d824e  pop rax
0000707b885d824f  add rsp, 0x08
0000707b885d8253  jmp 0x0000707B885D5F54
0000707b885d8258  call 0x0000707B884D64F0
0000707b885d825d  jmp 0x0000707B885D5F61
0000707b885d8262  sub rsp, 0x08
0000707b885d8266  push rax
0000707b885d8267  push rcx
0000707b885d8268  push rdx
0000707b885d8269  push rdi
0000707b885d826a  push rsi
0000707b885d826b  push r8
0000707b885d826d  push r9
0000707b885d826f  push r10
0000707b885d8271  push r11
0000707b885d8273  sub rsp, 0xF0
0000707b885d827a  vmovaps [rsp], xmm0
0000707b885d827f  vmovaps [rsp+0x10], xmm1
0000707b885d8285  vmovaps [rsp+0x20], xmm2
0000707b885d828b  vmovaps [rsp+0x30], xmm3
0000707b885d8291  vmovaps [rsp+0x40], xmm4
0000707b885d8297  vmovaps [rsp+0x50], xmm6
0000707b885d829d  vmovaps [rsp+0x60], xmm7
0000707b885d82a3  vmovaps [rsp+0x70], xmm8
0000707b885d82a9  vmovaps [rsp+0x80], xmm9
0000707b885d82b2  vmovaps [rsp+0x90], xmm10
0000707b885d82bb  vmovaps [rsp+0xA0], xmm11
0000707b885d82c4  vmovaps [rsp+0xB0], xmm12
0000707b885d82cd  vmovaps [rsp+0xC0], xmm13
0000707b885d82d6  vmovaps [rsp+0xD0], xmm14
0000707b885d82df  vmovaps [rsp+0xE0], xmm15
0000707b885d82e8  sub rsp, 0x30
0000707b885d82ec  movaps [rsp], xmm5
0000707b885d82f0  movaps [rsp+0x10], xmm6
0000707b885d82f5  movaps [rsp+0x20], xmm3
0000707b885d82fa  lea rdi, [rsp]
0000707b885d82fe  mov esi, 0x00
0000707b885d8303  mov rax, 0x6471B35AC530
0000707b885d830d  call rax
0000707b885d830f  movaps xmm5, [rsp]
0000707b885d8313  add rsp, 0x30
0000707b885d8317  vmovaps xmm0, [rsp]
0000707b885d831c  vmovaps xmm1, [rsp+0x10]
0000707b885d8322  vmovaps xmm2, [rsp+0x20]
0000707b885d8328  vmovaps xmm3, [rsp+0x30]
0000707b885d832e  vmovaps xmm4, [rsp+0x40]
0000707b885d8334  vmovaps xmm6, [rsp+0x50]
0000707b885d833a  vmovaps xmm7, [rsp+0x60]
0000707b885d8340  vmovaps xmm8, [rsp+0x70]
0000707b885d8346  vmovaps xmm9, [rsp+0x80]
0000707b885d834f  vmovaps xmm10, [rsp+0x90]
0000707b885d8358  vmovaps xmm11, [rsp+0xA0]
0000707b885d8361  vmovaps xmm12, [rsp+0xB0]
0000707b885d836a  vmovaps xmm13, [rsp+0xC0]
0000707b885d8373  vmovaps xmm14, [rsp+0xD0]
0000707b885d837c  vmovaps xmm15, [rsp+0xE0]
0000707b885d8385  add rsp, 0xF0
0000707b885d838c  pop r11
0000707b885d838e  pop r10
0000707b885d8390  pop r9
0000707b885d8392  pop r8
0000707b885d8394  pop rsi
0000707b885d8395  pop rdi
0000707b885d8396  pop rdx
0000707b885d8397  pop rcx
0000707b885d8398  pop rax
0000707b885d8399  add rsp, 0x08
0000707b885d839d  jmp 0x0000707B885D5F87
0000707b885d83a2  sub rsp, 0x08
0000707b885d83a6  push rax
0000707b885d83a7  push rcx
0000707b885d83a8  push rdx
0000707b885d83a9  push rdi
0000707b885d83aa  push rsi
0000707b885d83ab  push r8
0000707b885d83ad  push r9
0000707b885d83af  push r10
0000707b885d83b1  push r11
0000707b885d83b3  sub rsp, 0xF0
0000707b885d83ba  vmovaps [rsp], xmm0
0000707b885d83bf  vmovaps [rsp+0x10], xmm1
0000707b885d83c5  vmovaps [rsp+0x20], xmm2
0000707b885d83cb  vmovaps [rsp+0x30], xmm3
0000707b885d83d1  vmovaps [rsp+0x40], xmm4
0000707b885d83d7  vmovaps [rsp+0x50], xmm5
0000707b885d83dd  vmovaps [rsp+0x60], xmm7
0000707b885d83e3  vmovaps [rsp+0x70], xmm8
0000707b885d83e9  vmovaps [rsp+0x80], xmm9
0000707b885d83f2  vmovaps [rsp+0x90], xmm10
0000707b885d83fb  vmovaps [rsp+0xA0], xmm11
0000707b885d8404  vmovaps [rsp+0xB0], xmm12
0000707b885d840d  vmovaps [rsp+0xC0], xmm13
0000707b885d8416  vmovaps [rsp+0xD0], xmm14
0000707b885d841f  vmovaps [rsp+0xE0], xmm15
0000707b885d8428  sub rsp, 0x30
0000707b885d842c  movaps [rsp], xmm6
0000707b885d8430  movaps [rsp+0x10], xmm9
0000707b885d8436  movaps [rsp+0x20], xmm1
0000707b885d843b  lea rdi, [rsp]
0000707b885d843f  mov esi, 0x00
0000707b885d8444  mov rax, 0x6471B35AC530
0000707b885d844e  call rax
0000707b885d8450  movaps xmm6, [rsp]
0000707b885d8454  add rsp, 0x30
0000707b885d8458  vmovaps xmm0, [rsp]
0000707b885d845d  vmovaps xmm1, [rsp+0x10]
0000707b885d8463  vmovaps xmm2, [rsp+0x20]
0000707b885d8469  vmovaps xmm3, [rsp+0x30]
0000707b885d846f  vmovaps xmm4, [rsp+0x40]
0000707b885d8475  vmovaps xmm5, [rsp+0x50]
0000707b885d847b  vmovaps xmm7, [rsp+0x60]
0000707b885d8481  vmovaps xmm8, [rsp+0x70]
0000707b885d8487  vmovaps xmm9, [rsp+0x80]
0000707b885d8490  vmovaps xmm10, [rsp+0x90]
0000707b885d8499  vmovaps xmm11, [rsp+0xA0]
0000707b885d84a2  vmovaps xmm12, [rsp+0xB0]
0000707b885d84ab  vmovaps xmm13, [rsp+0xC0]
0000707b885d84b4  vmovaps xmm14, [rsp+0xD0]
0000707b885d84bd  vmovaps xmm15, [rsp+0xE0]
0000707b885d84c6  add rsp, 0xF0
0000707b885d84cd  pop r11
0000707b885d84cf  pop r10
0000707b885d84d1  pop r9
0000707b885d84d3  pop r8
0000707b885d84d5  pop rsi
0000707b885d84d6  pop rdi
0000707b885d84d7  pop rdx
0000707b885d84d8  pop rcx
0000707b885d84d9  pop rax
0000707b885d84da  add rsp, 0x08
0000707b885d84de  jmp 0x0000707B885D5FAB
0000707b885d84e3  sub rsp, 0x08
0000707b885d84e7  push rax
0000707b885d84e8  push rcx
0000707b885d84e9  push rdx
0000707b885d84ea  push rdi
0000707b885d84eb  push rsi
0000707b885d84ec  push r8
0000707b885d84ee  push r9
0000707b885d84f0  push r10
0000707b885d84f2  push r11
0000707b885d84f4  sub rsp, 0xF0
0000707b885d84fb  vmovaps [rsp], xmm0
0000707b885d8500  vmovaps [rsp+0x10], xmm1
0000707b885d8506  vmovaps [rsp+0x20], xmm2
0000707b885d850c  vmovaps [rsp+0x30], xmm3
0000707b885d8512  vmovaps [rsp+0x40], xmm4
0000707b885d8518  vmovaps [rsp+0x50], xmm5
0000707b885d851e  vmovaps [rsp+0x60], xmm6
0000707b885d8524  vmovaps [rsp+0x70], xmm7
0000707b885d852a  vmovaps [rsp+0x80], xmm8
0000707b885d8533  vmovaps [rsp+0x90], xmm10
0000707b885d853c  vmovaps [rsp+0xA0], xmm11
0000707b885d8545  vmovaps [rsp+0xB0], xmm12
0000707b885d854e  vmovaps [rsp+0xC0], xmm13
0000707b885d8557  vmovaps [rsp+0xD0], xmm14
0000707b885d8560  vmovaps [rsp+0xE0], xmm15
0000707b885d8569  sub rsp, 0x30
0000707b885d856d  movaps [rsp], xmm9
0000707b885d8572  movaps [rsp+0x10], xmm3
0000707b885d8577  movaps [rsp+0x20], xmm1
0000707b885d857c  lea rdi, [rsp]
0000707b885d8580  mov esi, 0x00
0000707b885d8585  mov rax, 0x6471B35AC530
0000707b885d858f  call rax
0000707b885d8591  movaps xmm9, [rsp]
0000707b885d8596  add rsp, 0x30
0000707b885d859a  vmovaps xmm0, [rsp]
0000707b885d859f  vmovaps xmm1, [rsp+0x10]
0000707b885d85a5  vmovaps xmm2, [rsp+0x20]
0000707b885d85ab  vmovaps xmm3, [rsp+0x30]
0000707b885d85b1  vmovaps xmm4, [rsp+0x40]
0000707b885d85b7  vmovaps xmm5, [rsp+0x50]
0000707b885d85bd  vmovaps xmm6, [rsp+0x60]
0000707b885d85c3  vmovaps xmm7, [rsp+0x70]
0000707b885d85c9  vmovaps xmm8, [rsp+0x80]
0000707b885d85d2  vmovaps xmm10, [rsp+0x90]
0000707b885d85db  vmovaps xmm11, [rsp+0xA0]
0000707b885d85e4  vmovaps xmm12, [rsp+0xB0]
0000707b885d85ed  vmovaps xmm13, [rsp+0xC0]
0000707b885d85f6  vmovaps xmm14, [rsp+0xD0]
0000707b885d85ff  vmovaps xmm15, [rsp+0xE0]
0000707b885d8608  add rsp, 0xF0
0000707b885d860f  pop r11
0000707b885d8611  pop r10
0000707b885d8613  pop r9
0000707b885d8615  pop r8
0000707b885d8617  pop rsi
0000707b885d8618  pop rdi
0000707b885d8619  pop rdx
0000707b885d861a  pop rcx
0000707b885d861b  pop rax
0000707b885d861c  add rsp, 0x08
0000707b885d8620  jmp 0x0000707B885D5FF7
0000707b885d8625  call 0x0000707B884D64F0
0000707b885d862a  jmp 0x0000707B885D6004
0000707b885d862f  sub rsp, 0x08
0000707b885d8633  push rax
0000707b885d8634  push rcx
0000707b885d8635  push rdx
0000707b885d8636  push rdi
0000707b885d8637  push rsi
0000707b885d8638  push r8
0000707b885d863a  push r9
0000707b885d863c  push r10
0000707b885d863e  push r11
0000707b885d8640  sub rsp, 0xF0
0000707b885d8647  vmovaps [rsp], xmm0
0000707b885d864c  vmovaps [rsp+0x10], xmm1
0000707b885d8652  vmovaps [rsp+0x20], xmm2
0000707b885d8658  vmovaps [rsp+0x30], xmm3
0000707b885d865e  vmovaps [rsp+0x40], xmm4
0000707b885d8664  vmovaps [rsp+0x50], xmm5
0000707b885d866a  vmovaps [rsp+0x60], xmm6
0000707b885d8670  vmovaps [rsp+0x70], xmm7
0000707b885d8676  vmovaps [rsp+0x80], xmm8
0000707b885d867f  vmovaps [rsp+0x90], xmm9
0000707b885d8688  vmovaps [rsp+0xA0], xmm10
0000707b885d8691  vmovaps [rsp+0xB0], xmm11
0000707b885d869a  vmovaps [rsp+0xC0], xmm12
0000707b885d86a3  vmovaps [rsp+0xD0], xmm13
0000707b885d86ac  vmovaps [rsp+0xE0], xmm14
0000707b885d86b5  sub rsp, 0x30
0000707b885d86b9  movaps [rsp], xmm15
0000707b885d86be  movaps [rsp+0x10], xmm3
0000707b885d86c3  movaps [rsp+0x20], xmm7
0000707b885d86c8  lea rdi, [rsp]
0000707b885d86cc  mov esi, 0x00
0000707b885d86d1  mov rax, 0x6471B35AC530
0000707b885d86db  call rax
0000707b885d86dd  movaps xmm15, [rsp]
0000707b885d86e2  add rsp, 0x30
0000707b885d86e6  vmovaps xmm0, [rsp]
0000707b885d86eb  vmovaps xmm1, [rsp+0x10]
0000707b885d86f1  vmovaps xmm2, [rsp+0x20]
0000707b885d86f7  vmovaps xmm3, [rsp+0x30]
0000707b885d86fd  vmovaps xmm4, [rsp+0x40]
0000707b885d8703  vmovaps xmm5, [rsp+0x50]
0000707b885d8709  vmovaps xmm6, [rsp+0x60]
0000707b885d870f  vmovaps xmm7, [rsp+0x70]
0000707b885d8715  vmovaps xmm8, [rsp+0x80]
0000707b885d871e  vmovaps xmm9, [rsp+0x90]
0000707b885d8727  vmovaps xmm10, [rsp+0xA0]
0000707b885d8730  vmovaps xmm11, [rsp+0xB0]
0000707b885d8739  vmovaps xmm12, [rsp+0xC0]
0000707b885d8742  vmovaps xmm13, [rsp+0xD0]
0000707b885d874b  vmovaps xmm14, [rsp+0xE0]
0000707b885d8754  add rsp, 0xF0
0000707b885d875b  pop r11
0000707b885d875d  pop r10
0000707b885d875f  pop r9
0000707b885d8761  pop r8
0000707b885d8763  pop rsi
0000707b885d8764  pop rdi
0000707b885d8765  pop rdx
0000707b885d8766  pop rcx
0000707b885d8767  pop rax
0000707b885d8768  add rsp, 0x08
0000707b885d876c  jmp 0x0000707B885D6030
0000707b885d8771  sub rsp, 0x08
0000707b885d8775  push rax
0000707b885d8776  push rcx
0000707b885d8777  push rdx
0000707b885d8778  push rdi
0000707b885d8779  push rsi
0000707b885d877a  push r8
0000707b885d877c  push r9
0000707b885d877e  push r10
0000707b885d8780  push r11
0000707b885d8782  sub rsp, 0xF0
0000707b885d8789  vmovaps [rsp], xmm0
0000707b885d878e  vmovaps [rsp+0x10], xmm1
0000707b885d8794  vmovaps [rsp+0x20], xmm2
0000707b885d879a  vmovaps [rsp+0x30], xmm4
0000707b885d87a0  vmovaps [rsp+0x40], xmm5
0000707b885d87a6  vmovaps [rsp+0x50], xmm6
0000707b885d87ac  vmovaps [rsp+0x60], xmm7
0000707b885d87b2  vmovaps [rsp+0x70], xmm8
0000707b885d87b8  vmovaps [rsp+0x80], xmm9
0000707b885d87c1  vmovaps [rsp+0x90], xmm10
0000707b885d87ca  vmovaps [rsp+0xA0], xmm11
0000707b885d87d3  vmovaps [rsp+0xB0], xmm12
0000707b885d87dc  vmovaps [rsp+0xC0], xmm13
0000707b885d87e5  vmovaps [rsp+0xD0], xmm14
0000707b885d87ee  vmovaps [rsp+0xE0], xmm15
0000707b885d87f7  sub rsp, 0x30
0000707b885d87fb  movaps [rsp], xmm3
0000707b885d87ff  movaps [rsp+0x10], xmm1
0000707b885d8804  movaps [rsp+0x20], xmm15
0000707b885d880a  lea rdi, [rsp]
0000707b885d880e  mov esi, 0x00
0000707b885d8813  mov rax, 0x6471B35AC530
0000707b885d881d  call rax
0000707b885d881f  movaps xmm3, [rsp]
0000707b885d8823  add rsp, 0x30
0000707b885d8827  vmovaps xmm0, [rsp]
0000707b885d882c  vmovaps xmm1, [rsp+0x10]
0000707b885d8832  vmovaps xmm2, [rsp+0x20]
0000707b885d8838  vmovaps xmm4, [rsp+0x30]
0000707b885d883e  vmovaps xmm5, [rsp+0x40]
0000707b885d8844  vmovaps xmm6, [rsp+0x50]
0000707b885d884a  vmovaps xmm7, [rsp+0x60]
0000707b885d8850  vmovaps xmm8, [rsp+0x70]
0000707b885d8856  vmovaps xmm9, [rsp+0x80]
0000707b885d885f  vmovaps xmm10, [rsp+0x90]
0000707b885d8868  vmovaps xmm11, [rsp+0xA0]
0000707b885d8871  vmovaps xmm12, [rsp+0xB0]
0000707b885d887a  vmovaps xmm13, [rsp+0xC0]
0000707b885d8883  vmovaps xmm14, [rsp+0xD0]
0000707b885d888c  vmovaps xmm15, [rsp+0xE0]
0000707b885d8895  add rsp, 0xF0
0000707b885d889c  pop r11
0000707b885d889e  pop r10
0000707b885d88a0  pop r9
0000707b885d88a2  pop r8
0000707b885d88a4  pop rsi
0000707b885d88a5  pop rdi
0000707b885d88a6  pop rdx
0000707b885d88a7  pop rcx
0000707b885d88a8  pop rax
0000707b885d88a9  add rsp, 0x08
0000707b885d88ad  jmp 0x0000707B885D60BF
0000707b885d88b2  call 0x0000707B884D64F0
0000707b885d88b7  jmp 0x0000707B885D60C9
0000707b885d88bc  sub rsp, 0x08
0000707b885d88c0  push rax
0000707b885d88c1  push rcx
0000707b885d88c2  push rdx
0000707b885d88c3  push rdi
0000707b885d88c4  push rsi
0000707b885d88c5  push r8
0000707b885d88c7  push r9
0000707b885d88c9  push r10
0000707b885d88cb  push r11
0000707b885d88cd  sub rsp, 0xF0
0000707b885d88d4  vmovaps [rsp], xmm0
0000707b885d88d9  vmovaps [rsp+0x10], xmm1
0000707b885d88df  vmovaps [rsp+0x20], xmm2
0000707b885d88e5  vmovaps [rsp+0x30], xmm3
0000707b885d88eb  vmovaps [rsp+0x40], xmm4
0000707b885d88f1  vmovaps [rsp+0x50], xmm5
0000707b885d88f7  vmovaps [rsp+0x60], xmm6
0000707b885d88fd  vmovaps [rsp+0x70], xmm7
0000707b885d8903  vmovaps [rsp+0x80], xmm8
0000707b885d890c  vmovaps [rsp+0x90], xmm9
0000707b885d8915  vmovaps [rsp+0xA0], xmm10
0000707b885d891e  vmovaps [rsp+0xB0], xmm11
0000707b885d8927  vmovaps [rsp+0xC0], xmm12
0000707b885d8930  vmovaps [rsp+0xD0], xmm13
0000707b885d8939  vmovaps [rsp+0xE0], xmm14
0000707b885d8942  sub rsp, 0x30
0000707b885d8946  movaps [rsp], xmm15
0000707b885d894b  movaps [rsp+0x10], xmm14
0000707b885d8951  movaps [rsp+0x20], xmm4
0000707b885d8956  lea rdi, [rsp]
0000707b885d895a  mov esi, 0x00
0000707b885d895f  mov rax, 0x6471B35AC530
0000707b885d8969  call rax
0000707b885d896b  movaps xmm15, [rsp]
0000707b885d8970  add rsp, 0x30
0000707b885d8974  vmovaps xmm0, [rsp]
0000707b885d8979  vmovaps xmm1, [rsp+0x10]
0000707b885d897f  vmovaps xmm2, [rsp+0x20]
0000707b885d8985  vmovaps xmm3, [rsp+0x30]
0000707b885d898b  vmovaps xmm4, [rsp+0x40]
0000707b885d8991  vmovaps xmm5, [rsp+0x50]
0000707b885d8997  vmovaps xmm6, [rsp+0x60]
0000707b885d899d  vmovaps xmm7, [rsp+0x70]
0000707b885d89a3  vmovaps xmm8, [rsp+0x80]
0000707b885d89ac  vmovaps xmm9, [rsp+0x90]
0000707b885d89b5  vmovaps xmm10, [rsp+0xA0]
0000707b885d89be  vmovaps xmm11, [rsp+0xB0]
0000707b885d89c7  vmovaps xmm12, [rsp+0xC0]
0000707b885d89d0  vmovaps xmm13, [rsp+0xD0]
0000707b885d89d9  vmovaps xmm14, [rsp+0xE0]
0000707b885d89e2  add rsp, 0xF0
0000707b885d89e9  pop r11
0000707b885d89eb  pop r10
0000707b885d89ed  pop r9
0000707b885d89ef  pop r8
0000707b885d89f1  pop rsi
0000707b885d89f2  pop rdi
0000707b885d89f3  pop rdx
0000707b885d89f4  pop rcx
0000707b885d89f5  pop rax
0000707b885d89f6  add rsp, 0x08
0000707b885d89fa  jmp 0x0000707B885D60F7
0000707b885d89ff  sub rsp, 0x08
0000707b885d8a03  push rax
0000707b885d8a04  push rcx
0000707b885d8a05  push rdx
0000707b885d8a06  push rdi
0000707b885d8a07  push rsi
0000707b885d8a08  push r8
0000707b885d8a0a  push r9
0000707b885d8a0c  push r10
0000707b885d8a0e  push r11
0000707b885d8a10  sub rsp, 0xF0
0000707b885d8a17  vmovaps [rsp], xmm0
0000707b885d8a1c  vmovaps [rsp+0x10], xmm1
0000707b885d8a22  vmovaps [rsp+0x20], xmm2
0000707b885d8a28  vmovaps [rsp+0x30], xmm3
0000707b885d8a2e  vmovaps [rsp+0x40], xmm4
0000707b885d8a34  vmovaps [rsp+0x50], xmm5
0000707b885d8a3a  vmovaps [rsp+0x60], xmm6
0000707b885d8a40  vmovaps [rsp+0x70], xmm7
0000707b885d8a46  vmovaps [rsp+0x80], xmm8
0000707b885d8a4f  vmovaps [rsp+0x90], xmm9
0000707b885d8a58  vmovaps [rsp+0xA0], xmm10
0000707b885d8a61  vmovaps [rsp+0xB0], xmm11
0000707b885d8a6a  vmovaps [rsp+0xC0], xmm12
0000707b885d8a73  vmovaps [rsp+0xD0], xmm13
0000707b885d8a7c  vmovaps [rsp+0xE0], xmm15
0000707b885d8a85  sub rsp, 0x30
0000707b885d8a89  movaps [rsp], xmm14
0000707b885d8a8e  movaps [rsp+0x10], xmm2
0000707b885d8a93  movaps [rsp+0x20], xmm1
0000707b885d8a98  lea rdi, [rsp]
0000707b885d8a9c  mov esi, 0x00
0000707b885d8aa1  mov rax, 0x6471B35AC530
0000707b885d8aab  call rax
0000707b885d8aad  movaps xmm14, [rsp]
0000707b885d8ab2  add rsp, 0x30
0000707b885d8ab6  vmovaps xmm0, [rsp]
0000707b885d8abb  vmovaps xmm1, [rsp+0x10]
0000707b885d8ac1  vmovaps xmm2, [rsp+0x20]
0000707b885d8ac7  vmovaps xmm3, [rsp+0x30]
0000707b885d8acd  vmovaps xmm4, [rsp+0x40]
0000707b885d8ad3  vmovaps xmm5, [rsp+0x50]
0000707b885d8ad9  vmovaps xmm6, [rsp+0x60]
0000707b885d8adf  vmovaps xmm7, [rsp+0x70]
0000707b885d8ae5  vmovaps xmm8, [rsp+0x80]
0000707b885d8aee  vmovaps xmm9, [rsp+0x90]
0000707b885d8af7  vmovaps xmm10, [rsp+0xA0]
0000707b885d8b00  vmovaps xmm11, [rsp+0xB0]
0000707b885d8b09  vmovaps xmm12, [rsp+0xC0]
0000707b885d8b12  vmovaps xmm13, [rsp+0xD0]
0000707b885d8b1b  vmovaps xmm15, [rsp+0xE0]
0000707b885d8b24  add rsp, 0xF0
0000707b885d8b2b  pop r11
0000707b885d8b2d  pop r10
0000707b885d8b2f  pop r9
0000707b885d8b31  pop r8
0000707b885d8b33  pop rsi
0000707b885d8b34  pop rdi
0000707b885d8b35  pop rdx
0000707b885d8b36  pop rcx
0000707b885d8b37  pop rax
0000707b885d8b38  add rsp, 0x08
0000707b885d8b3c  jmp 0x0000707B885D611D
0000707b885d8b41  sub rsp, 0x08
0000707b885d8b45  push rax
0000707b885d8b46  push rcx
0000707b885d8b47  push rdx
0000707b885d8b48  push rdi
0000707b885d8b49  push rsi
0000707b885d8b4a  push r8
0000707b885d8b4c  push r9
0000707b885d8b4e  push r10
0000707b885d8b50  push r11
0000707b885d8b52  sub rsp, 0xF0
0000707b885d8b59  vmovaps [rsp], xmm0
0000707b885d8b5e  vmovaps [rsp+0x10], xmm2
0000707b885d8b64  vmovaps [rsp+0x20], xmm3
0000707b885d8b6a  vmovaps [rsp+0x30], xmm4
0000707b885d8b70  vmovaps [rsp+0x40], xmm5
0000707b885d8b76  vmovaps [rsp+0x50], xmm6
0000707b885d8b7c  vmovaps [rsp+0x60], xmm7
0000707b885d8b82  vmovaps [rsp+0x70], xmm8
0000707b885d8b88  vmovaps [rsp+0x80], xmm9
0000707b885d8b91  vmovaps [rsp+0x90], xmm10
0000707b885d8b9a  vmovaps [rsp+0xA0], xmm11
0000707b885d8ba3  vmovaps [rsp+0xB0], xmm12
0000707b885d8bac  vmovaps [rsp+0xC0], xmm13
0000707b885d8bb5  vmovaps [rsp+0xD0], xmm14
0000707b885d8bbe  vmovaps [rsp+0xE0], xmm15
0000707b885d8bc7  sub rsp, 0x30
0000707b885d8bcb  movaps [rsp], xmm1
0000707b885d8bcf  movaps [rsp+0x10], xmm4
0000707b885d8bd4  movaps [rsp+0x20], xmm9
0000707b885d8bda  lea rdi, [rsp]
0000707b885d8bde  mov esi, 0x00
0000707b885d8be3  mov rax, 0x6471B35AC530
0000707b885d8bed  call rax
0000707b885d8bef  movaps xmm1, [rsp]
0000707b885d8bf3  add rsp, 0x30
0000707b885d8bf7  vmovaps xmm0, [rsp]
0000707b885d8bfc  vmovaps xmm2, [rsp+0x10]
0000707b885d8c02  vmovaps xmm3, [rsp+0x20]
0000707b885d8c08  vmovaps xmm4, [rsp+0x30]
0000707b885d8c0e  vmovaps xmm5, [rsp+0x40]
0000707b885d8c14  vmovaps xmm6, [rsp+0x50]
0000707b885d8c1a  vmovaps xmm7, [rsp+0x60]
0000707b885d8c20  vmovaps xmm8, [rsp+0x70]
0000707b885d8c26  vmovaps xmm9, [rsp+0x80]
0000707b885d8c2f  vmovaps xmm10, [rsp+0x90]
0000707b885d8c38  vmovaps xmm11, [rsp+0xA0]
0000707b885d8c41  vmovaps xmm12, [rsp+0xB0]
0000707b885d8c4a  vmovaps xmm13, [rsp+0xC0]
0000707b885d8c53  vmovaps xmm14, [rsp+0xD0]
0000707b885d8c5c  vmovaps xmm15, [rsp+0xE0]
0000707b885d8c65  add rsp, 0xF0
0000707b885d8c6c  pop r11
0000707b885d8c6e  pop r10
0000707b885d8c70  pop r9
0000707b885d8c72  pop r8
0000707b885d8c74  pop rsi
0000707b885d8c75  pop rdi
0000707b885d8c76  pop rdx
0000707b885d8c77  pop rcx
0000707b885d8c78  pop rax
0000707b885d8c79  add rsp, 0x08
0000707b885d8c7d  jmp 0x0000707B885D613B
0000707b885d8c82  sub rsp, 0x08
0000707b885d8c86  push rax
0000707b885d8c87  push rcx
0000707b885d8c88  push rdx
0000707b885d8c89  push rdi
0000707b885d8c8a  push rsi
0000707b885d8c8b  push r8
0000707b885d8c8d  push r9
0000707b885d8c8f  push r10
0000707b885d8c91  push r11
0000707b885d8c93  sub rsp, 0xF0
0000707b885d8c9a  vmovaps [rsp], xmm0
0000707b885d8c9f  vmovaps [rsp+0x10], xmm1
0000707b885d8ca5  vmovaps [rsp+0x20], xmm2
0000707b885d8cab  vmovaps [rsp+0x30], xmm3
0000707b885d8cb1  vmovaps [rsp+0x40], xmm5
0000707b885d8cb7  vmovaps [rsp+0x50], xmm6
0000707b885d8cbd  vmovaps [rsp+0x60], xmm7
0000707b885d8cc3  vmovaps [rsp+0x70], xmm8
0000707b885d8cc9  vmovaps [rsp+0x80], xmm9
0000707b885d8cd2  vmovaps [rsp+0x90], xmm10
0000707b885d8cdb  vmovaps [rsp+0xA0], xmm11
0000707b885d8ce4  vmovaps [rsp+0xB0], xmm12
0000707b885d8ced  vmovaps [rsp+0xC0], xmm13
0000707b885d8cf6  vmovaps [rsp+0xD0], xmm14
0000707b885d8cff  vmovaps [rsp+0xE0], xmm15
0000707b885d8d08  sub rsp, 0x30
0000707b885d8d0c  movaps [rsp], xmm4
0000707b885d8d10  movaps [rsp+0x10], xmm2
0000707b885d8d15  movaps [rsp+0x20], xmm9
0000707b885d8d1b  lea rdi, [rsp]
0000707b885d8d1f  mov esi, 0x00
0000707b885d8d24  mov rax, 0x6471B35AC530
0000707b885d8d2e  call rax
0000707b885d8d30  movaps xmm4, [rsp]
0000707b885d8d34  add rsp, 0x30
0000707b885d8d38  vmovaps xmm0, [rsp]
0000707b885d8d3d  vmovaps xmm1, [rsp+0x10]
0000707b885d8d43  vmovaps xmm2, [rsp+0x20]
0000707b885d8d49  vmovaps xmm3, [rsp+0x30]
0000707b885d8d4f  vmovaps xmm5, [rsp+0x40]
0000707b885d8d55  vmovaps xmm6, [rsp+0x50]
0000707b885d8d5b  vmovaps xmm7, [rsp+0x60]
0000707b885d8d61  vmovaps xmm8, [rsp+0x70]
0000707b885d8d67  vmovaps xmm9, [rsp+0x80]
0000707b885d8d70  vmovaps xmm10, [rsp+0x90]
0000707b885d8d79  vmovaps xmm11, [rsp+0xA0]
0000707b885d8d82  vmovaps xmm12, [rsp+0xB0]
0000707b885d8d8b  vmovaps xmm13, [rsp+0xC0]
0000707b885d8d94  vmovaps xmm14, [rsp+0xD0]
0000707b885d8d9d  vmovaps xmm15, [rsp+0xE0]
0000707b885d8da6  add rsp, 0xF0
0000707b885d8dad  pop r11
0000707b885d8daf  pop r10
0000707b885d8db1  pop r9
0000707b885d8db3  pop r8
0000707b885d8db5  pop rsi
0000707b885d8db6  pop rdi
0000707b885d8db7  pop rdx
0000707b885d8db8  pop rcx
0000707b885d8db9  pop rax
0000707b885d8dba  add rsp, 0x08
0000707b885d8dbe  jmp 0x0000707B885D616B
0000707b885d8dc3  sub rsp, 0x08
0000707b885d8dc7  push rax
0000707b885d8dc8  push rcx
0000707b885d8dc9  push rdx
0000707b885d8dca  push rdi
0000707b885d8dcb  push rsi
0000707b885d8dcc  push r8
0000707b885d8dce  push r9
0000707b885d8dd0  push r10
0000707b885d8dd2  push r11
0000707b885d8dd4  sub rsp, 0xF0
0000707b885d8ddb  vmovaps [rsp], xmm0
0000707b885d8de0  vmovaps [rsp+0x10], xmm1
0000707b885d8de6  vmovaps [rsp+0x20], xmm2
0000707b885d8dec  vmovaps [rsp+0x30], xmm3
0000707b885d8df2  vmovaps [rsp+0x40], xmm4
0000707b885d8df8  vmovaps [rsp+0x50], xmm5
0000707b885d8dfe  vmovaps [rsp+0x60], xmm6
0000707b885d8e04  vmovaps [rsp+0x70], xmm7
0000707b885d8e0a  vmovaps [rsp+0x80], xmm8
0000707b885d8e13  vmovaps [rsp+0x90], xmm10
0000707b885d8e1c  vmovaps [rsp+0xA0], xmm11
0000707b885d8e25  vmovaps [rsp+0xB0], xmm12
0000707b885d8e2e  vmovaps [rsp+0xC0], xmm13
0000707b885d8e37  vmovaps [rsp+0xD0], xmm14
0000707b885d8e40  vmovaps [rsp+0xE0], xmm15
0000707b885d8e49  sub rsp, 0x30
0000707b885d8e4d  movaps [rsp], xmm9
0000707b885d8e52  movaps [rsp+0x10], xmm2
0000707b885d8e57  movaps [rsp+0x20], xmm1
0000707b885d8e5c  lea rdi, [rsp]
0000707b885d8e60  mov esi, 0x00
0000707b885d8e65  mov rax, 0x6471B35AC530
0000707b885d8e6f  call rax
0000707b885d8e71  movaps xmm9, [rsp]
0000707b885d8e76  add rsp, 0x30
0000707b885d8e7a  vmovaps xmm0, [rsp]
0000707b885d8e7f  vmovaps xmm1, [rsp+0x10]
0000707b885d8e85  vmovaps xmm2, [rsp+0x20]
0000707b885d8e8b  vmovaps xmm3, [rsp+0x30]
0000707b885d8e91  vmovaps xmm4, [rsp+0x40]
0000707b885d8e97  vmovaps xmm5, [rsp+0x50]
0000707b885d8e9d  vmovaps xmm6, [rsp+0x60]
0000707b885d8ea3  vmovaps xmm7, [rsp+0x70]
0000707b885d8ea9  vmovaps xmm8, [rsp+0x80]
0000707b885d8eb2  vmovaps xmm10, [rsp+0x90]
0000707b885d8ebb  vmovaps xmm11, [rsp+0xA0]
0000707b885d8ec4  vmovaps xmm12, [rsp+0xB0]
0000707b885d8ecd  vmovaps xmm13, [rsp+0xC0]
0000707b885d8ed6  vmovaps xmm14, [rsp+0xD0]
0000707b885d8edf  vmovaps xmm15, [rsp+0xE0]
0000707b885d8ee8  add rsp, 0xF0
0000707b885d8eef  pop r11
0000707b885d8ef1  pop r10
0000707b885d8ef3  pop r9
0000707b885d8ef5  pop r8
0000707b885d8ef7  pop rsi
0000707b885d8ef8  pop rdi
0000707b885d8ef9  pop rdx
0000707b885d8efa  pop rcx
0000707b885d8efb  pop rax
0000707b885d8efc  add rsp, 0x08
0000707b885d8f00  jmp 0x0000707B885D61A1
0000707b885d8f05  sub rsp, 0x08
0000707b885d8f09  push rax
0000707b885d8f0a  push rcx
0000707b885d8f0b  push rdx
0000707b885d8f0c  push rdi
0000707b885d8f0d  push rsi
0000707b885d8f0e  push r8
0000707b885d8f10  push r9
0000707b885d8f12  push r10
0000707b885d8f14  push r11
0000707b885d8f16  sub rsp, 0xF0
0000707b885d8f1d  vmovaps [rsp], xmm0
0000707b885d8f22  vmovaps [rsp+0x10], xmm2
0000707b885d8f28  vmovaps [rsp+0x20], xmm3
0000707b885d8f2e  vmovaps [rsp+0x30], xmm4
0000707b885d8f34  vmovaps [rsp+0x40], xmm5
0000707b885d8f3a  vmovaps [rsp+0x50], xmm6
0000707b885d8f40  vmovaps [rsp+0x60], xmm7
0000707b885d8f46  vmovaps [rsp+0x70], xmm8
0000707b885d8f4c  vmovaps [rsp+0x80], xmm9
0000707b885d8f55  vmovaps [rsp+0x90], xmm10
0000707b885d8f5e  vmovaps [rsp+0xA0], xmm11
0000707b885d8f67  vmovaps [rsp+0xB0], xmm12
0000707b885d8f70  vmovaps [rsp+0xC0], xmm13
0000707b885d8f79  vmovaps [rsp+0xD0], xmm14
0000707b885d8f82  vmovaps [rsp+0xE0], xmm15
0000707b885d8f8b  sub rsp, 0x30
0000707b885d8f8f  movaps [rsp], xmm1
0000707b885d8f93  movaps [rsp+0x10], xmm15
0000707b885d8f99  movaps [rsp+0x20], xmm6
0000707b885d8f9e  lea rdi, [rsp]
0000707b885d8fa2  mov esi, 0x00
0000707b885d8fa7  mov rax, 0x6471B35AC530
0000707b885d8fb1  call rax
0000707b885d8fb3  movaps xmm1, [rsp]
0000707b885d8fb7  add rsp, 0x30
0000707b885d8fbb  vmovaps xmm0, [rsp]
0000707b885d8fc0  vmovaps xmm2, [rsp+0x10]
0000707b885d8fc6  vmovaps xmm3, [rsp+0x20]
0000707b885d8fcc  vmovaps xmm4, [rsp+0x30]
0000707b885d8fd2  vmovaps xmm5, [rsp+0x40]
0000707b885d8fd8  vmovaps xmm6, [rsp+0x50]
0000707b885d8fde  vmovaps xmm7, [rsp+0x60]
0000707b885d8fe4  vmovaps xmm8, [rsp+0x70]
0000707b885d8fea  vmovaps xmm9, [rsp+0x80]
0000707b885d8ff3  vmovaps xmm10, [rsp+0x90]
0000707b885d8ffc  vmovaps xmm11, [rsp+0xA0]
0000707b885d9005  vmovaps xmm12, [rsp+0xB0]
0000707b885d900e  vmovaps xmm13, [rsp+0xC0]
0000707b885d9017  vmovaps xmm14, [rsp+0xD0]
0000707b885d9020  vmovaps xmm15, [rsp+0xE0]
0000707b885d9029  add rsp, 0xF0
0000707b885d9030  pop r11
0000707b885d9032  pop r10
0000707b885d9034  pop r9
0000707b885d9036  pop r8
0000707b885d9038  pop rsi
0000707b885d9039  pop rdi
0000707b885d903a  pop rdx
0000707b885d903b  pop rcx
0000707b885d903c  pop rax
0000707b885d903d  add rsp, 0x08
0000707b885d9041  jmp 0x0000707B885D61C2
0000707b885d9046  sub rsp, 0x08
0000707b885d904a  push rax
0000707b885d904b  push rcx
0000707b885d904c  push rdx
0000707b885d904d  push rdi
0000707b885d904e  push rsi
0000707b885d904f  push r8
0000707b885d9051  push r9
0000707b885d9053  push r10
0000707b885d9055  push r11
0000707b885d9057  sub rsp, 0xF0
0000707b885d905e  vmovaps [rsp], xmm0
0000707b885d9063  vmovaps [rsp+0x10], xmm1
0000707b885d9069  vmovaps [rsp+0x20], xmm2
0000707b885d906f  vmovaps [rsp+0x30], xmm3
0000707b885d9075  vmovaps [rsp+0x40], xmm4
0000707b885d907b  vmovaps [rsp+0x50], xmm5
0000707b885d9081  vmovaps [rsp+0x60], xmm6
0000707b885d9087  vmovaps [rsp+0x70], xmm7
0000707b885d908d  vmovaps [rsp+0x80], xmm8
0000707b885d9096  vmovaps [rsp+0x90], xmm9
0000707b885d909f  vmovaps [rsp+0xA0], xmm10
0000707b885d90a8  vmovaps [rsp+0xB0], xmm11
0000707b885d90b1  vmovaps [rsp+0xC0], xmm12
0000707b885d90ba  vmovaps [rsp+0xD0], xmm13
0000707b885d90c3  vmovaps [rsp+0xE0], xmm14
0000707b885d90cc  sub rsp, 0x30
0000707b885d90d0  movaps [rsp], xmm15
0000707b885d90d5  movaps [rsp+0x10], xmm5
0000707b885d90da  movaps [rsp+0x20], xmm3
0000707b885d90df  lea rdi, [rsp]
0000707b885d90e3  mov esi, 0x00
0000707b885d90e8  mov rax, 0x6471B35AC530
0000707b885d90f2  call rax
0000707b885d90f4  movaps xmm15, [rsp]
0000707b885d90f9  add rsp, 0x30
0000707b885d90fd  vmovaps xmm0, [rsp]
0000707b885d9102  vmovaps xmm1, [rsp+0x10]
0000707b885d9108  vmovaps xmm2, [rsp+0x20]
0000707b885d910e  vmovaps xmm3, [rsp+0x30]
0000707b885d9114  vmovaps xmm4, [rsp+0x40]
0000707b885d911a  vmovaps xmm5, [rsp+0x50]
0000707b885d9120  vmovaps xmm6, [rsp+0x60]
0000707b885d9126  vmovaps xmm7, [rsp+0x70]
0000707b885d912c  vmovaps xmm8, [rsp+0x80]
0000707b885d9135  vmovaps xmm9, [rsp+0x90]
0000707b885d913e  vmovaps xmm10, [rsp+0xA0]
0000707b885d9147  vmovaps xmm11, [rsp+0xB0]
0000707b885d9150  vmovaps xmm12, [rsp+0xC0]
0000707b885d9159  vmovaps xmm13, [rsp+0xD0]
0000707b885d9162  vmovaps xmm14, [rsp+0xE0]
0000707b885d916b  add rsp, 0xF0
0000707b885d9172  pop r11
0000707b885d9174  pop r10
0000707b885d9176  pop r9
0000707b885d9178  pop r8
0000707b885d917a  pop rsi
0000707b885d917b  pop rdi
0000707b885d917c  pop rdx
0000707b885d917d  pop rcx
0000707b885d917e  pop rax
0000707b885d917f  add rsp, 0x08
0000707b885d9183  jmp 0x0000707B885D61DC
0000707b885d9188  sub rsp, 0x08
0000707b885d918c  push rax
0000707b885d918d  push rcx
0000707b885d918e  push rdx
0000707b885d918f  push rdi
0000707b885d9190  push rsi
0000707b885d9191  push r8
0000707b885d9193  push r9
0000707b885d9195  push r10
0000707b885d9197  push r11
0000707b885d9199  sub rsp, 0xF0
0000707b885d91a0  vmovaps [rsp], xmm0
0000707b885d91a5  vmovaps [rsp+0x10], xmm1
0000707b885d91ab  vmovaps [rsp+0x20], xmm2
0000707b885d91b1  vmovaps [rsp+0x30], xmm3
0000707b885d91b7  vmovaps [rsp+0x40], xmm4
0000707b885d91bd  vmovaps [rsp+0x50], xmm6
0000707b885d91c3  vmovaps [rsp+0x60], xmm7
0000707b885d91c9  vmovaps [rsp+0x70], xmm8
0000707b885d91cf  vmovaps [rsp+0x80], xmm9
0000707b885d91d8  vmovaps [rsp+0x90], xmm10
0000707b885d91e1  vmovaps [rsp+0xA0], xmm11
0000707b885d91ea  vmovaps [rsp+0xB0], xmm12
0000707b885d91f3  vmovaps [rsp+0xC0], xmm13
0000707b885d91fc  vmovaps [rsp+0xD0], xmm14
0000707b885d9205  vmovaps [rsp+0xE0], xmm15
0000707b885d920e  sub rsp, 0x30
0000707b885d9212  movaps [rsp], xmm5
0000707b885d9216  movaps [rsp+0x10], xmm8
0000707b885d921c  movaps [rsp+0x20], xmm6
0000707b885d9221  lea rdi, [rsp]
0000707b885d9225  mov esi, 0x00
0000707b885d922a  mov rax, 0x6471B35AC530
0000707b885d9234  call rax
0000707b885d9236  movaps xmm5, [rsp]
0000707b885d923a  add rsp, 0x30
0000707b885d923e  vmovaps xmm0, [rsp]
0000707b885d9243  vmovaps xmm1, [rsp+0x10]
0000707b885d9249  vmovaps xmm2, [rsp+0x20]
0000707b885d924f  vmovaps xmm3, [rsp+0x30]
0000707b885d9255  vmovaps xmm4, [rsp+0x40]
0000707b885d925b  vmovaps xmm6, [rsp+0x50]
0000707b885d9261  vmovaps xmm7, [rsp+0x60]
0000707b885d9267  vmovaps xmm8, [rsp+0x70]
0000707b885d926d  vmovaps xmm9, [rsp+0x80]
0000707b885d9276  vmovaps xmm10, [rsp+0x90]
0000707b885d927f  vmovaps xmm11, [rsp+0xA0]
0000707b885d9288  vmovaps xmm12, [rsp+0xB0]
0000707b885d9291  vmovaps xmm13, [rsp+0xC0]
0000707b885d929a  vmovaps xmm14, [rsp+0xD0]
0000707b885d92a3  vmovaps xmm15, [rsp+0xE0]
0000707b885d92ac  add rsp, 0xF0
0000707b885d92b3  pop r11
0000707b885d92b5  pop r10
0000707b885d92b7  pop r9
0000707b885d92b9  pop r8
0000707b885d92bb  pop rsi
0000707b885d92bc  pop rdi
0000707b885d92bd  pop rdx
0000707b885d92be  pop rcx
0000707b885d92bf  pop rax
0000707b885d92c0  add rsp, 0x08
0000707b885d92c4  jmp 0x0000707B885D6200
0000707b885d92c9  sub rsp, 0x08
0000707b885d92cd  push rax
0000707b885d92ce  push rcx
0000707b885d92cf  push rdx
0000707b885d92d0  push rdi
0000707b885d92d1  push rsi
0000707b885d92d2  push r8
0000707b885d92d4  push r9
0000707b885d92d6  push r10
0000707b885d92d8  push r11
0000707b885d92da  sub rsp, 0xF0
0000707b885d92e1  vmovaps [rsp], xmm0
0000707b885d92e6  vmovaps [rsp+0x10], xmm1
0000707b885d92ec  vmovaps [rsp+0x20], xmm2
0000707b885d92f2  vmovaps [rsp+0x30], xmm3
0000707b885d92f8  vmovaps [rsp+0x40], xmm4
0000707b885d92fe  vmovaps [rsp+0x50], xmm5
0000707b885d9304  vmovaps [rsp+0x60], xmm7
0000707b885d930a  vmovaps [rsp+0x70], xmm8
0000707b885d9310  vmovaps [rsp+0x80], xmm9
0000707b885d9319  vmovaps [rsp+0x90], xmm10
0000707b885d9322  vmovaps [rsp+0xA0], xmm11
0000707b885d932b  vmovaps [rsp+0xB0], xmm12
0000707b885d9334  vmovaps [rsp+0xC0], xmm13
0000707b885d933d  vmovaps [rsp+0xD0], xmm14
0000707b885d9346  vmovaps [rsp+0xE0], xmm15
0000707b885d934f  sub rsp, 0x30
0000707b885d9353  movaps [rsp], xmm6
0000707b885d9357  movaps [rsp+0x10], xmm10
0000707b885d935d  movaps [rsp+0x20], xmm8
0000707b885d9363  lea rdi, [rsp]
0000707b885d9367  mov esi, 0x00
0000707b885d936c  mov rax, 0x6471B35AC530
0000707b885d9376  call rax
0000707b885d9378  movaps xmm6, [rsp]
0000707b885d937c  add rsp, 0x30
0000707b885d9380  vmovaps xmm0, [rsp]
0000707b885d9385  vmovaps xmm1, [rsp+0x10]
0000707b885d938b  vmovaps xmm2, [rsp+0x20]
0000707b885d9391  vmovaps xmm3, [rsp+0x30]
0000707b885d9397  vmovaps xmm4, [rsp+0x40]
0000707b885d939d  vmovaps xmm5, [rsp+0x50]
0000707b885d93a3  vmovaps xmm7, [rsp+0x60]
0000707b885d93a9  vmovaps xmm8, [rsp+0x70]
0000707b885d93af  vmovaps xmm9, [rsp+0x80]
0000707b885d93b8  vmovaps xmm10, [rsp+0x90]
0000707b885d93c1  vmovaps xmm11, [rsp+0xA0]
0000707b885d93ca  vmovaps xmm12, [rsp+0xB0]
0000707b885d93d3  vmovaps xmm13, [rsp+0xC0]
0000707b885d93dc  vmovaps xmm14, [rsp+0xD0]
0000707b885d93e5  vmovaps xmm15, [rsp+0xE0]
0000707b885d93ee  add rsp, 0xF0
0000707b885d93f5  pop r11
0000707b885d93f7  pop r10
0000707b885d93f9  pop r9
0000707b885d93fb  pop r8
0000707b885d93fd  pop rsi
0000707b885d93fe  pop rdi
0000707b885d93ff  pop rdx
0000707b885d9400  pop rcx
0000707b885d9401  pop rax
0000707b885d9402  add rsp, 0x08
0000707b885d9406  jmp 0x0000707B885D6225
0000707b885d940b  sub rsp, 0x08
0000707b885d940f  push rax
0000707b885d9410  push rcx
0000707b885d9411  push rdx
0000707b885d9412  push rdi
0000707b885d9413  push rsi
0000707b885d9414  push r8
0000707b885d9416  push r9
0000707b885d9418  push r10
0000707b885d941a  push r11
0000707b885d941c  sub rsp, 0xF0
0000707b885d9423  vmovaps [rsp], xmm0
0000707b885d9428  vmovaps [rsp+0x10], xmm1
0000707b885d942e  vmovaps [rsp+0x20], xmm2
0000707b885d9434  vmovaps [rsp+0x30], xmm3
0000707b885d943a  vmovaps [rsp+0x40], xmm4
0000707b885d9440  vmovaps [rsp+0x50], xmm5
0000707b885d9446  vmovaps [rsp+0x60], xmm6
0000707b885d944c  vmovaps [rsp+0x70], xmm7
0000707b885d9452  vmovaps [rsp+0x80], xmm8
0000707b885d945b  vmovaps [rsp+0x90], xmm9
0000707b885d9464  vmovaps [rsp+0xA0], xmm11
0000707b885d946d  vmovaps [rsp+0xB0], xmm12
0000707b885d9476  vmovaps [rsp+0xC0], xmm13
0000707b885d947f  vmovaps [rsp+0xD0], xmm14
0000707b885d9488  vmovaps [rsp+0xE0], xmm15
0000707b885d9491  sub rsp, 0x30
0000707b885d9495  movaps [rsp], xmm10
0000707b885d949a  movaps [rsp+0x10], xmm8
0000707b885d94a0  movaps [rsp+0x20], xmm14
0000707b885d94a6  lea rdi, [rsp]
0000707b885d94aa  mov esi, 0x00
0000707b885d94af  mov rax, 0x6471B35AC530
0000707b885d94b9  call rax
0000707b885d94bb  movaps xmm10, [rsp]
0000707b885d94c0  add rsp, 0x30
0000707b885d94c4  vmovaps xmm0, [rsp]
0000707b885d94c9  vmovaps xmm1, [rsp+0x10]
0000707b885d94cf  vmovaps xmm2, [rsp+0x20]
0000707b885d94d5  vmovaps xmm3, [rsp+0x30]
0000707b885d94db  vmovaps xmm4, [rsp+0x40]
0000707b885d94e1  vmovaps xmm5, [rsp+0x50]
0000707b885d94e7  vmovaps xmm6, [rsp+0x60]
0000707b885d94ed  vmovaps xmm7, [rsp+0x70]
0000707b885d94f3  vmovaps xmm8, [rsp+0x80]
0000707b885d94fc  vmovaps xmm9, [rsp+0x90]
0000707b885d9505  vmovaps xmm11, [rsp+0xA0]
0000707b885d950e  vmovaps xmm12, [rsp+0xB0]
0000707b885d9517  vmovaps xmm13, [rsp+0xC0]
0000707b885d9520  vmovaps xmm14, [rsp+0xD0]
0000707b885d9529  vmovaps xmm15, [rsp+0xE0]
0000707b885d9532  add rsp, 0xF0
0000707b885d9539  pop r11
0000707b885d953b  pop r10
0000707b885d953d  pop r9
0000707b885d953f  pop r8
0000707b885d9541  pop rsi
0000707b885d9542  pop rdi
0000707b885d9543  pop rdx
0000707b885d9544  pop rcx
0000707b885d9545  pop rax
0000707b885d9546  add rsp, 0x08
0000707b885d954a  jmp 0x0000707B885D6245
0000707b885d954f  sub rsp, 0x08
0000707b885d9553  push rax
0000707b885d9554  push rcx
0000707b885d9555  push rdx
0000707b885d9556  push rdi
0000707b885d9557  push rsi
0000707b885d9558  push r8
0000707b885d955a  push r9
0000707b885d955c  push r10
0000707b885d955e  push r11
0000707b885d9560  sub rsp, 0xF0
0000707b885d9567  vmovaps [rsp], xmm0
0000707b885d956c  vmovaps [rsp+0x10], xmm1
0000707b885d9572  vmovaps [rsp+0x20], xmm2
0000707b885d9578  vmovaps [rsp+0x30], xmm3
0000707b885d957e  vmovaps [rsp+0x40], xmm4
0000707b885d9584  vmovaps [rsp+0x50], xmm5
0000707b885d958a  vmovaps [rsp+0x60], xmm6
0000707b885d9590  vmovaps [rsp+0x70], xmm7
0000707b885d9596  vmovaps [rsp+0x80], xmm8
0000707b885d959f  vmovaps [rsp+0x90], xmm9
0000707b885d95a8  vmovaps [rsp+0xA0], xmm10
0000707b885d95b1  vmovaps [rsp+0xB0], xmm11
0000707b885d95ba  vmovaps [rsp+0xC0], xmm12
0000707b885d95c3  vmovaps [rsp+0xD0], xmm13
0000707b885d95cc  vmovaps [rsp+0xE0], xmm15
0000707b885d95d5  sub rsp, 0x30
0000707b885d95d9  movaps [rsp], xmm14
0000707b885d95de  movaps [rsp+0x10], xmm8
0000707b885d95e4  movaps [rsp+0x20], xmm4
0000707b885d95e9  lea rdi, [rsp]
0000707b885d95ed  mov esi, 0x00
0000707b885d95f2  mov rax, 0x6471B35AC530
0000707b885d95fc  call rax
0000707b885d95fe  movaps xmm14, [rsp]
0000707b885d9603  add rsp, 0x30
0000707b885d9607  vmovaps xmm0, [rsp]
0000707b885d960c  vmovaps xmm1, [rsp+0x10]
0000707b885d9612  vmovaps xmm2, [rsp+0x20]
0000707b885d9618  vmovaps xmm3, [rsp+0x30]
0000707b885d961e  vmovaps xmm4, [rsp+0x40]
0000707b885d9624  vmovaps xmm5, [rsp+0x50]
0000707b885d962a  vmovaps xmm6, [rsp+0x60]
0000707b885d9630  vmovaps xmm7, [rsp+0x70]
0000707b885d9636  vmovaps xmm8, [rsp+0x80]
0000707b885d963f  vmovaps xmm9, [rsp+0x90]
0000707b885d9648  vmovaps xmm10, [rsp+0xA0]
0000707b885d9651  vmovaps xmm11, [rsp+0xB0]
0000707b885d965a  vmovaps xmm12, [rsp+0xC0]
0000707b885d9663  vmovaps xmm13, [rsp+0xD0]
0000707b885d966c  vmovaps xmm15, [rsp+0xE0]
0000707b885d9675  add rsp, 0xF0
0000707b885d967c  pop r11
0000707b885d967e  pop r10
0000707b885d9680  pop r9
0000707b885d9682  pop r8
0000707b885d9684  pop rsi
0000707b885d9685  pop rdi
0000707b885d9686  pop rdx
0000707b885d9687  pop rcx
0000707b885d9688  pop rax
0000707b885d9689  add rsp, 0x08
0000707b885d968d  jmp 0x0000707B885D6265
0000707b885d9692  sub rsp, 0x08
0000707b885d9696  push rax
0000707b885d9697  push rcx
0000707b885d9698  push rdx
0000707b885d9699  push rdi
0000707b885d969a  push rsi
0000707b885d969b  push r8
0000707b885d969d  push r9
0000707b885d969f  push r10
0000707b885d96a1  push r11
0000707b885d96a3  sub rsp, 0xF0
0000707b885d96aa  vmovaps [rsp], xmm0
0000707b885d96af  vmovaps [rsp+0x10], xmm1
0000707b885d96b5  vmovaps [rsp+0x20], xmm2
0000707b885d96bb  vmovaps [rsp+0x30], xmm3
0000707b885d96c1  vmovaps [rsp+0x40], xmm5
0000707b885d96c7  vmovaps [rsp+0x50], xmm6
0000707b885d96cd  vmovaps [rsp+0x60], xmm7
0000707b885d96d3  vmovaps [rsp+0x70], xmm8
0000707b885d96d9  vmovaps [rsp+0x80], xmm9
0000707b885d96e2  vmovaps [rsp+0x90], xmm10
0000707b885d96eb  vmovaps [rsp+0xA0], xmm11
0000707b885d96f4  vmovaps [rsp+0xB0], xmm12
0000707b885d96fd  vmovaps [rsp+0xC0], xmm13
0000707b885d9706  vmovaps [rsp+0xD0], xmm14
0000707b885d970f  vmovaps [rsp+0xE0], xmm15
0000707b885d9718  sub rsp, 0x30
0000707b885d971c  movaps [rsp], xmm4
0000707b885d9720  movaps [rsp+0x10], xmm13
0000707b885d9726  movaps [rsp+0x20], xmm8
0000707b885d972c  lea rdi, [rsp]
0000707b885d9730  mov esi, 0x00
0000707b885d9735  mov rax, 0x6471B35AC530
0000707b885d973f  call rax
0000707b885d9741  movaps xmm4, [rsp]
0000707b885d9745  add rsp, 0x30
0000707b885d9749  vmovaps xmm0, [rsp]
0000707b885d974e  vmovaps xmm1, [rsp+0x10]
0000707b885d9754  vmovaps xmm2, [rsp+0x20]
0000707b885d975a  vmovaps xmm3, [rsp+0x30]
0000707b885d9760  vmovaps xmm5, [rsp+0x40]
0000707b885d9766  vmovaps xmm6, [rsp+0x50]
0000707b885d976c  vmovaps xmm7, [rsp+0x60]
0000707b885d9772  vmovaps xmm8, [rsp+0x70]
0000707b885d9778  vmovaps xmm9, [rsp+0x80]
0000707b885d9781  vmovaps xmm10, [rsp+0x90]
0000707b885d978a  vmovaps xmm11, [rsp+0xA0]
0000707b885d9793  vmovaps xmm12, [rsp+0xB0]
0000707b885d979c  vmovaps xmm13, [rsp+0xC0]
0000707b885d97a5  vmovaps xmm14, [rsp+0xD0]
0000707b885d97ae  vmovaps xmm15, [rsp+0xE0]
0000707b885d97b7  add rsp, 0xF0
0000707b885d97be  pop r11
0000707b885d97c0  pop r10
0000707b885d97c2  pop r9
0000707b885d97c4  pop r8
0000707b885d97c6  pop rsi
0000707b885d97c7  pop rdi
0000707b885d97c8  pop rdx
0000707b885d97c9  pop rcx
0000707b885d97ca  pop rax
0000707b885d97cb  add rsp, 0x08
0000707b885d97cf  jmp 0x0000707B885D628A
0000707b885d97d4  sub rsp, 0x08
0000707b885d97d8  push rax
0000707b885d97d9  push rcx
0000707b885d97da  push rdx
0000707b885d97db  push rdi
0000707b885d97dc  push rsi
0000707b885d97dd  push r8
0000707b885d97df  push r9
0000707b885d97e1  push r10
0000707b885d97e3  push r11
0000707b885d97e5  sub rsp, 0xF0
0000707b885d97ec  vmovaps [rsp], xmm0
0000707b885d97f1  vmovaps [rsp+0x10], xmm1
0000707b885d97f7  vmovaps [rsp+0x20], xmm2
0000707b885d97fd  vmovaps [rsp+0x30], xmm3
0000707b885d9803  vmovaps [rsp+0x40], xmm4
0000707b885d9809  vmovaps [rsp+0x50], xmm5
0000707b885d980f  vmovaps [rsp+0x60], xmm6
0000707b885d9815  vmovaps [rsp+0x70], xmm7
0000707b885d981b  vmovaps [rsp+0x80], xmm8
0000707b885d9824  vmovaps [rsp+0x90], xmm9
0000707b885d982d  vmovaps [rsp+0xA0], xmm10
0000707b885d9836  vmovaps [rsp+0xB0], xmm11
0000707b885d983f  vmovaps [rsp+0xC0], xmm12
0000707b885d9848  vmovaps [rsp+0xD0], xmm14
0000707b885d9851  vmovaps [rsp+0xE0], xmm15
0000707b885d985a  sub rsp, 0x30
0000707b885d985e  movaps [rsp], xmm13
0000707b885d9863  movaps [rsp+0x10], xmm15
0000707b885d9869  movaps [rsp+0x20], xmm9
0000707b885d986f  lea rdi, [rsp]
0000707b885d9873  mov esi, 0x00
0000707b885d9878  mov rax, 0x6471B35AC530
0000707b885d9882  call rax
0000707b885d9884  movaps xmm13, [rsp]
0000707b885d9889  add rsp, 0x30
0000707b885d988d  vmovaps xmm0, [rsp]
0000707b885d9892  vmovaps xmm1, [rsp+0x10]
0000707b885d9898  vmovaps xmm2, [rsp+0x20]
0000707b885d989e  vmovaps xmm3, [rsp+0x30]
0000707b885d98a4  vmovaps xmm4, [rsp+0x40]
0000707b885d98aa  vmovaps xmm5, [rsp+0x50]
0000707b885d98b0  vmovaps xmm6, [rsp+0x60]
0000707b885d98b6  vmovaps xmm7, [rsp+0x70]
0000707b885d98bc  vmovaps xmm8, [rsp+0x80]
0000707b885d98c5  vmovaps xmm9, [rsp+0x90]
0000707b885d98ce  vmovaps xmm10, [rsp+0xA0]
0000707b885d98d7  vmovaps xmm11, [rsp+0xB0]
0000707b885d98e0  vmovaps xmm12, [rsp+0xC0]
0000707b885d98e9  vmovaps xmm14, [rsp+0xD0]
0000707b885d98f2  vmovaps xmm15, [rsp+0xE0]
0000707b885d98fb  add rsp, 0xF0
0000707b885d9902  pop r11
0000707b885d9904  pop r10
0000707b885d9906  pop r9
0000707b885d9908  pop r8
0000707b885d990a  pop rsi
0000707b885d990b  pop rdi
0000707b885d990c  pop rdx
0000707b885d990d  pop rcx
0000707b885d990e  pop rax
0000707b885d990f  add rsp, 0x08
0000707b885d9913  jmp 0x0000707B885D62A5
0000707b885d9918  sub rsp, 0x08
0000707b885d991c  push rax
0000707b885d991d  push rcx
0000707b885d991e  push rdx
0000707b885d991f  push rdi
0000707b885d9920  push rsi
0000707b885d9921  push r8
0000707b885d9923  push r9
0000707b885d9925  push r10
0000707b885d9927  push r11
0000707b885d9929  sub rsp, 0xF0
0000707b885d9930  vmovaps [rsp], xmm0
0000707b885d9935  vmovaps [rsp+0x10], xmm1
0000707b885d993b  vmovaps [rsp+0x20], xmm2
0000707b885d9941  vmovaps [rsp+0x30], xmm3
0000707b885d9947  vmovaps [rsp+0x40], xmm4
0000707b885d994d  vmovaps [rsp+0x50], xmm5
0000707b885d9953  vmovaps [rsp+0x60], xmm6
0000707b885d9959  vmovaps [rsp+0x70], xmm7
0000707b885d995f  vmovaps [rsp+0x80], xmm8
0000707b885d9968  vmovaps [rsp+0x90], xmm9
0000707b885d9971  vmovaps [rsp+0xA0], xmm10
0000707b885d997a  vmovaps [rsp+0xB0], xmm11
0000707b885d9983  vmovaps [rsp+0xC0], xmm12
0000707b885d998c  vmovaps [rsp+0xD0], xmm13
0000707b885d9995  vmovaps [rsp+0xE0], xmm14
0000707b885d999e  sub rsp, 0x30
0000707b885d99a2  movaps [rsp], xmm15
0000707b885d99a7  movaps [rsp+0x10], xmm1
0000707b885d99ac  movaps [rsp+0x20], xmm5
0000707b885d99b1  lea rdi, [rsp]
0000707b885d99b5  mov esi, 0x00
0000707b885d99ba  mov rax, 0x6471B35AC530
0000707b885d99c4  call rax
0000707b885d99c6  movaps xmm15, [rsp]
0000707b885d99cb  add rsp, 0x30
0000707b885d99cf  vmovaps xmm0, [rsp]
0000707b885d99d4  vmovaps xmm1, [rsp+0x10]
0000707b885d99da  vmovaps xmm2, [rsp+0x20]
0000707b885d99e0  vmovaps xmm3, [rsp+0x30]
0000707b885d99e6  vmovaps xmm4, [rsp+0x40]
0000707b885d99ec  vmovaps xmm5, [rsp+0x50]
0000707b885d99f2  vmovaps xmm6, [rsp+0x60]
0000707b885d99f8  vmovaps xmm7, [rsp+0x70]
0000707b885d99fe  vmovaps xmm8, [rsp+0x80]
0000707b885d9a07  vmovaps xmm9, [rsp+0x90]
0000707b885d9a10  vmovaps xmm10, [rsp+0xA0]
0000707b885d9a19  vmovaps xmm11, [rsp+0xB0]
0000707b885d9a22  vmovaps xmm12, [rsp+0xC0]
0000707b885d9a2b  vmovaps xmm13, [rsp+0xD0]
0000707b885d9a34  vmovaps xmm14, [rsp+0xE0]
0000707b885d9a3d  add rsp, 0xF0
0000707b885d9a44  pop r11
0000707b885d9a46  pop r10
0000707b885d9a48  pop r9
0000707b885d9a4a  pop r8
0000707b885d9a4c  pop rsi
0000707b885d9a4d  pop rdi
0000707b885d9a4e  pop rdx
0000707b885d9a4f  pop rcx
0000707b885d9a50  pop rax
0000707b885d9a51  add rsp, 0x08
0000707b885d9a55  jmp 0x0000707B885D62C0
0000707b885d9a5a  call 0x0000707B884D64F0
0000707b885d9a5f  jmp 0x0000707B885D631B
0000707b885d9a64  sub rsp, 0x08
0000707b885d9a68  push rax
0000707b885d9a69  push rcx
0000707b885d9a6a  push rdx
0000707b885d9a6b  push rdi
0000707b885d9a6c  push rsi
0000707b885d9a6d  push r8
0000707b885d9a6f  push r9
0000707b885d9a71  push r10
0000707b885d9a73  push r11
0000707b885d9a75  sub rsp, 0xF0
0000707b885d9a7c  vmovaps [rsp], xmm0
0000707b885d9a81  vmovaps [rsp+0x10], xmm1
0000707b885d9a87  vmovaps [rsp+0x20], xmm2
0000707b885d9a8d  vmovaps [rsp+0x30], xmm3
0000707b885d9a93  vmovaps [rsp+0x40], xmm4
0000707b885d9a99  vmovaps [rsp+0x50], xmm5
0000707b885d9a9f  vmovaps [rsp+0x60], xmm6
0000707b885d9aa5  vmovaps [rsp+0x70], xmm7
0000707b885d9aab  vmovaps [rsp+0x80], xmm8
0000707b885d9ab4  vmovaps [rsp+0x90], xmm10
0000707b885d9abd  vmovaps [rsp+0xA0], xmm11
0000707b885d9ac6  vmovaps [rsp+0xB0], xmm12
0000707b885d9acf  vmovaps [rsp+0xC0], xmm13
0000707b885d9ad8  vmovaps [rsp+0xD0], xmm14
0000707b885d9ae1  vmovaps [rsp+0xE0], xmm15
0000707b885d9aea  sub rsp, 0x30
0000707b885d9aee  movaps [rsp], xmm9
0000707b885d9af3  movaps [rsp+0x10], xmm8
0000707b885d9af9  movaps [rsp+0x20], xmm11
0000707b885d9aff  lea rdi, [rsp]
0000707b885d9b03  mov esi, 0x00
0000707b885d9b08  mov rax, 0x6471B35AC530
0000707b885d9b12  call rax
0000707b885d9b14  movaps xmm9, [rsp]
0000707b885d9b19  add rsp, 0x30
0000707b885d9b1d  vmovaps xmm0, [rsp]
0000707b885d9b22  vmovaps xmm1, [rsp+0x10]
0000707b885d9b28  vmovaps xmm2, [rsp+0x20]
0000707b885d9b2e  vmovaps xmm3, [rsp+0x30]
0000707b885d9b34  vmovaps xmm4, [rsp+0x40]
0000707b885d9b3a  vmovaps xmm5, [rsp+0x50]
0000707b885d9b40  vmovaps xmm6, [rsp+0x60]
0000707b885d9b46  vmovaps xmm7, [rsp+0x70]
0000707b885d9b4c  vmovaps xmm8, [rsp+0x80]
0000707b885d9b55  vmovaps xmm10, [rsp+0x90]
0000707b885d9b5e  vmovaps xmm11, [rsp+0xA0]
0000707b885d9b67  vmovaps xmm12, [rsp+0xB0]
0000707b885d9b70  vmovaps xmm13, [rsp+0xC0]
0000707b885d9b79  vmovaps xmm14, [rsp+0xD0]
0000707b885d9b82  vmovaps xmm15, [rsp+0xE0]
0000707b885d9b8b  add rsp, 0xF0
0000707b885d9b92  pop r11
0000707b885d9b94  pop r10
0000707b885d9b96  pop r9
0000707b885d9b98  pop r8
0000707b885d9b9a  pop rsi
0000707b885d9b9b  pop rdi
0000707b885d9b9c  pop rdx
0000707b885d9b9d  pop rcx
0000707b885d9b9e  pop rax
0000707b885d9b9f  add rsp, 0x08
0000707b885d9ba3  jmp 0x0000707B885D6352
0000707b885d9ba8  sub rsp, 0x08
0000707b885d9bac  push rax
0000707b885d9bad  push rcx
0000707b885d9bae  push rdx
0000707b885d9baf  push rdi
0000707b885d9bb0  push rsi
0000707b885d9bb1  push r8
0000707b885d9bb3  push r9
0000707b885d9bb5  push r10
0000707b885d9bb7  push r11
0000707b885d9bb9  sub rsp, 0xF0
0000707b885d9bc0  vmovaps [rsp], xmm0
0000707b885d9bc5  vmovaps [rsp+0x10], xmm1
0000707b885d9bcb  vmovaps [rsp+0x20], xmm2
0000707b885d9bd1  vmovaps [rsp+0x30], xmm3
0000707b885d9bd7  vmovaps [rsp+0x40], xmm4
0000707b885d9bdd  vmovaps [rsp+0x50], xmm5
0000707b885d9be3  vmovaps [rsp+0x60], xmm6
0000707b885d9be9  vmovaps [rsp+0x70], xmm7
0000707b885d9bef  vmovaps [rsp+0x80], xmm8
0000707b885d9bf8  vmovaps [rsp+0x90], xmm9
0000707b885d9c01  vmovaps [rsp+0xA0], xmm10
0000707b885d9c0a  vmovaps [rsp+0xB0], xmm12
0000707b885d9c13  vmovaps [rsp+0xC0], xmm13
0000707b885d9c1c  vmovaps [rsp+0xD0], xmm14
0000707b885d9c25  vmovaps [rsp+0xE0], xmm15
0000707b885d9c2e  sub rsp, 0x30
0000707b885d9c32  movaps [rsp], xmm11
0000707b885d9c37  movaps [rsp+0x10], xmm10
0000707b885d9c3d  movaps [rsp+0x20], xmm6
0000707b885d9c42  lea rdi, [rsp]
0000707b885d9c46  mov esi, 0x00
0000707b885d9c4b  mov rax, 0x6471B35AC530
0000707b885d9c55  call rax
0000707b885d9c57  movaps xmm11, [rsp]
0000707b885d9c5c  add rsp, 0x30
0000707b885d9c60  vmovaps xmm0, [rsp]
0000707b885d9c65  vmovaps xmm1, [rsp+0x10]
0000707b885d9c6b  vmovaps xmm2, [rsp+0x20]
0000707b885d9c71  vmovaps xmm3, [rsp+0x30]
0000707b885d9c77  vmovaps xmm4, [rsp+0x40]
0000707b885d9c7d  vmovaps xmm5, [rsp+0x50]
0000707b885d9c83  vmovaps xmm6, [rsp+0x60]
0000707b885d9c89  vmovaps xmm7, [rsp+0x70]
0000707b885d9c8f  vmovaps xmm8, [rsp+0x80]
0000707b885d9c98  vmovaps xmm9, [rsp+0x90]
0000707b885d9ca1  vmovaps xmm10, [rsp+0xA0]
0000707b885d9caa  vmovaps xmm12, [rsp+0xB0]
0000707b885d9cb3  vmovaps xmm13, [rsp+0xC0]
0000707b885d9cbc  vmovaps xmm14, [rsp+0xD0]
0000707b885d9cc5  vmovaps xmm15, [rsp+0xE0]
0000707b885d9cce  add rsp, 0xF0
0000707b885d9cd5  pop r11
0000707b885d9cd7  pop r10
0000707b885d9cd9  pop r9
0000707b885d9cdb  pop r8
0000707b885d9cdd  pop rsi
0000707b885d9cde  pop rdi
0000707b885d9cdf  pop rdx
0000707b885d9ce0  pop rcx
0000707b885d9ce1  pop rax
0000707b885d9ce2  add rsp, 0x08
0000707b885d9ce6  jmp 0x0000707B885D636D
0000707b885d9ceb  sub rsp, 0x08
0000707b885d9cef  push rax
0000707b885d9cf0  push rcx
0000707b885d9cf1  push rdx
0000707b885d9cf2  push rdi
0000707b885d9cf3  push rsi
0000707b885d9cf4  push r8
0000707b885d9cf6  push r9
0000707b885d9cf8  push r10
0000707b885d9cfa  push r11
0000707b885d9cfc  sub rsp, 0xF0
0000707b885d9d03  vmovaps [rsp], xmm0
0000707b885d9d08  vmovaps [rsp+0x10], xmm1
0000707b885d9d0e  vmovaps [rsp+0x20], xmm2
0000707b885d9d14  vmovaps [rsp+0x30], xmm3
0000707b885d9d1a  vmovaps [rsp+0x40], xmm4
0000707b885d9d20  vmovaps [rsp+0x50], xmm5
0000707b885d9d26  vmovaps [rsp+0x60], xmm6
0000707b885d9d2c  vmovaps [rsp+0x70], xmm7
0000707b885d9d32  vmovaps [rsp+0x80], xmm8
0000707b885d9d3b  vmovaps [rsp+0x90], xmm9
0000707b885d9d44  vmovaps [rsp+0xA0], xmm11
0000707b885d9d4d  vmovaps [rsp+0xB0], xmm12
0000707b885d9d56  vmovaps [rsp+0xC0], xmm13
0000707b885d9d5f  vmovaps [rsp+0xD0], xmm14
0000707b885d9d68  vmovaps [rsp+0xE0], xmm15
0000707b885d9d71  sub rsp, 0x30
0000707b885d9d75  movaps [rsp], xmm10
0000707b885d9d7a  movaps [rsp+0x10], xmm14
0000707b885d9d80  movaps [rsp+0x20], xmm4
0000707b885d9d85  lea rdi, [rsp]
0000707b885d9d89  mov esi, 0x00
0000707b885d9d8e  mov rax, 0x6471B35AC530
0000707b885d9d98  call rax
0000707b885d9d9a  movaps xmm10, [rsp]
0000707b885d9d9f  add rsp, 0x30
0000707b885d9da3  vmovaps xmm0, [rsp]
0000707b885d9da8  vmovaps xmm1, [rsp+0x10]
0000707b885d9dae  vmovaps xmm2, [rsp+0x20]
0000707b885d9db4  vmovaps xmm3, [rsp+0x30]
0000707b885d9dba  vmovaps xmm4, [rsp+0x40]
0000707b885d9dc0  vmovaps xmm5, [rsp+0x50]
0000707b885d9dc6  vmovaps xmm6, [rsp+0x60]
0000707b885d9dcc  vmovaps xmm7, [rsp+0x70]
0000707b885d9dd2  vmovaps xmm8, [rsp+0x80]
0000707b885d9ddb  vmovaps xmm9, [rsp+0x90]
0000707b885d9de4  vmovaps xmm11, [rsp+0xA0]
0000707b885d9ded  vmovaps xmm12, [rsp+0xB0]
0000707b885d9df6  vmovaps xmm13, [rsp+0xC0]
0000707b885d9dff  vmovaps xmm14, [rsp+0xD0]
0000707b885d9e08  vmovaps xmm15, [rsp+0xE0]
0000707b885d9e11  add rsp, 0xF0
0000707b885d9e18  pop r11
0000707b885d9e1a  pop r10
0000707b885d9e1c  pop r9
0000707b885d9e1e  pop r8
0000707b885d9e20  pop rsi
0000707b885d9e21  pop rdi
0000707b885d9e22  pop rdx
0000707b885d9e23  pop rcx
0000707b885d9e24  pop rax
0000707b885d9e25  add rsp, 0x08
0000707b885d9e29  jmp 0x0000707B885D6388
0000707b885d9e2e  sub rsp, 0x08
0000707b885d9e32  push rax
0000707b885d9e33  push rcx
0000707b885d9e34  push rdx
0000707b885d9e35  push rdi
0000707b885d9e36  push rsi
0000707b885d9e37  push r8
0000707b885d9e39  push r9
0000707b885d9e3b  push r10
0000707b885d9e3d  push r11
0000707b885d9e3f  sub rsp, 0xF0
0000707b885d9e46  vmovaps [rsp], xmm0
0000707b885d9e4b  vmovaps [rsp+0x10], xmm1
0000707b885d9e51  vmovaps [rsp+0x20], xmm2
0000707b885d9e57  vmovaps [rsp+0x30], xmm3
0000707b885d9e5d  vmovaps [rsp+0x40], xmm4
0000707b885d9e63  vmovaps [rsp+0x50], xmm5
0000707b885d9e69  vmovaps [rsp+0x60], xmm6
0000707b885d9e6f  vmovaps [rsp+0x70], xmm7
0000707b885d9e75  vmovaps [rsp+0x80], xmm9
0000707b885d9e7e  vmovaps [rsp+0x90], xmm10
0000707b885d9e87  vmovaps [rsp+0xA0], xmm11
0000707b885d9e90  vmovaps [rsp+0xB0], xmm12
0000707b885d9e99  vmovaps [rsp+0xC0], xmm13
0000707b885d9ea2  vmovaps [rsp+0xD0], xmm14
0000707b885d9eab  vmovaps [rsp+0xE0], xmm15
0000707b885d9eb4  sub rsp, 0x30
0000707b885d9eb8  movaps [rsp], xmm8
0000707b885d9ebd  movaps [rsp+0x10], xmm1
0000707b885d9ec2  movaps [rsp+0x20], xmm14
0000707b885d9ec8  lea rdi, [rsp]
0000707b885d9ecc  mov esi, 0x00
0000707b885d9ed1  mov rax, 0x6471B35AC530
0000707b885d9edb  call rax
0000707b885d9edd  movaps xmm8, [rsp]
0000707b885d9ee2  add rsp, 0x30
0000707b885d9ee6  vmovaps xmm0, [rsp]
0000707b885d9eeb  vmovaps xmm1, [rsp+0x10]
0000707b885d9ef1  vmovaps xmm2, [rsp+0x20]
0000707b885d9ef7  vmovaps xmm3, [rsp+0x30]
0000707b885d9efd  vmovaps xmm4, [rsp+0x40]
0000707b885d9f03  vmovaps xmm5, [rsp+0x50]
0000707b885d9f09  vmovaps xmm6, [rsp+0x60]
0000707b885d9f0f  vmovaps xmm7, [rsp+0x70]
0000707b885d9f15  vmovaps xmm9, [rsp+0x80]
0000707b885d9f1e  vmovaps xmm10, [rsp+0x90]
0000707b885d9f27  vmovaps xmm11, [rsp+0xA0]
0000707b885d9f30  vmovaps xmm12, [rsp+0xB0]
0000707b885d9f39  vmovaps xmm13, [rsp+0xC0]
0000707b885d9f42  vmovaps xmm14, [rsp+0xD0]
0000707b885d9f4b  vmovaps xmm15, [rsp+0xE0]
0000707b885d9f54  add rsp, 0xF0
0000707b885d9f5b  pop r11
0000707b885d9f5d  pop r10
0000707b885d9f5f  pop r9
0000707b885d9f61  pop r8
0000707b885d9f63  pop rsi
0000707b885d9f64  pop rdi
0000707b885d9f65  pop rdx
0000707b885d9f66  pop rcx
0000707b885d9f67  pop rax
0000707b885d9f68  add rsp, 0x08
0000707b885d9f6c  jmp 0x0000707B885D63AE
0000707b885d9f71  sub rsp, 0x08
0000707b885d9f75  push rax
0000707b885d9f76  push rcx
0000707b885d9f77  push rdx
0000707b885d9f78  push rdi
0000707b885d9f79  push rsi
0000707b885d9f7a  push r8
0000707b885d9f7c  push r9
0000707b885d9f7e  push r10
0000707b885d9f80  push r11
0000707b885d9f82  sub rsp, 0xF0
0000707b885d9f89  vmovaps [rsp], xmm0
0000707b885d9f8e  vmovaps [rsp+0x10], xmm1
0000707b885d9f94  vmovaps [rsp+0x20], xmm2
0000707b885d9f9a  vmovaps [rsp+0x30], xmm3
0000707b885d9fa0  vmovaps [rsp+0x40], xmm4
0000707b885d9fa6  vmovaps [rsp+0x50], xmm5
0000707b885d9fac  vmovaps [rsp+0x60], xmm7
0000707b885d9fb2  vmovaps [rsp+0x70], xmm8
0000707b885d9fb8  vmovaps [rsp+0x80], xmm9
0000707b885d9fc1  vmovaps [rsp+0x90], xmm10
0000707b885d9fca  vmovaps [rsp+0xA0], xmm11
0000707b885d9fd3  vmovaps [rsp+0xB0], xmm12
0000707b885d9fdc  vmovaps [rsp+0xC0], xmm13
0000707b885d9fe5  vmovaps [rsp+0xD0], xmm14
0000707b885d9fee  vmovaps [rsp+0xE0], xmm15
0000707b885d9ff7  sub rsp, 0x30
0000707b885d9ffb  movaps [rsp], xmm6
0000707b885d9fff  movaps [rsp+0x10], xmm1
0000707b885da004  movaps [rsp+0x20], xmm14
0000707b885da00a  lea rdi, [rsp]
0000707b885da00e  mov esi, 0x00
0000707b885da013  mov rax, 0x6471B35AC530
0000707b885da01d  call rax
0000707b885da01f  movaps xmm6, [rsp]
0000707b885da023  add rsp, 0x30
0000707b885da027  vmovaps xmm0, [rsp]
0000707b885da02c  vmovaps xmm1, [rsp+0x10]
0000707b885da032  vmovaps xmm2, [rsp+0x20]
0000707b885da038  vmovaps xmm3, [rsp+0x30]
0000707b885da03e  vmovaps xmm4, [rsp+0x40]
0000707b885da044  vmovaps xmm5, [rsp+0x50]
0000707b885da04a  vmovaps xmm7, [rsp+0x60]
0000707b885da050  vmovaps xmm8, [rsp+0x70]
0000707b885da056  vmovaps xmm9, [rsp+0x80]
0000707b885da05f  vmovaps xmm10, [rsp+0x90]
0000707b885da068  vmovaps xmm11, [rsp+0xA0]
0000707b885da071  vmovaps xmm12, [rsp+0xB0]
0000707b885da07a  vmovaps xmm13, [rsp+0xC0]
0000707b885da083  vmovaps xmm14, [rsp+0xD0]
0000707b885da08c  vmovaps xmm15, [rsp+0xE0]
0000707b885da095  add rsp, 0xF0
0000707b885da09c  pop r11
0000707b885da09e  pop r10
0000707b885da0a0  pop r9
0000707b885da0a2  pop r8
0000707b885da0a4  pop rsi
0000707b885da0a5  pop rdi
0000707b885da0a6  pop rdx
0000707b885da0a7  pop rcx
0000707b885da0a8  pop rax
0000707b885da0a9  add rsp, 0x08
0000707b885da0ad  jmp 0x0000707B885D63DA
0000707b885da0b2  sub rsp, 0x08
0000707b885da0b6  push rax
0000707b885da0b7  push rcx
0000707b885da0b8  push rdx
0000707b885da0b9  push rdi
0000707b885da0ba  push rsi
0000707b885da0bb  push r8
0000707b885da0bd  push r9
0000707b885da0bf  push r10
0000707b885da0c1  push r11
0000707b885da0c3  sub rsp, 0xF0
0000707b885da0ca  vmovaps [rsp], xmm0
0000707b885da0cf  vmovaps [rsp+0x10], xmm1
0000707b885da0d5  vmovaps [rsp+0x20], xmm2
0000707b885da0db  vmovaps [rsp+0x30], xmm3
0000707b885da0e1  vmovaps [rsp+0x40], xmm4
0000707b885da0e7  vmovaps [rsp+0x50], xmm5
0000707b885da0ed  vmovaps [rsp+0x60], xmm6
0000707b885da0f3  vmovaps [rsp+0x70], xmm7
0000707b885da0f9  vmovaps [rsp+0x80], xmm8
0000707b885da102  vmovaps [rsp+0x90], xmm9
0000707b885da10b  vmovaps [rsp+0xA0], xmm10
0000707b885da114  vmovaps [rsp+0xB0], xmm11
0000707b885da11d  vmovaps [rsp+0xC0], xmm12
0000707b885da126  vmovaps [rsp+0xD0], xmm13
0000707b885da12f  vmovaps [rsp+0xE0], xmm15
0000707b885da138  sub rsp, 0x30
0000707b885da13c  movaps [rsp], xmm14
0000707b885da141  movaps [rsp+0x10], xmm12
0000707b885da147  movaps [rsp+0x20], xmm1
0000707b885da14c  lea rdi, [rsp]
0000707b885da150  mov esi, 0x00
0000707b885da155  mov rax, 0x6471B35AC530
0000707b885da15f  call rax
0000707b885da161  movaps xmm14, [rsp]
0000707b885da166  add rsp, 0x30
0000707b885da16a  vmovaps xmm0, [rsp]
0000707b885da16f  vmovaps xmm1, [rsp+0x10]
0000707b885da175  vmovaps xmm2, [rsp+0x20]
0000707b885da17b  vmovaps xmm3, [rsp+0x30]
0000707b885da181  vmovaps xmm4, [rsp+0x40]
0000707b885da187  vmovaps xmm5, [rsp+0x50]
0000707b885da18d  vmovaps xmm6, [rsp+0x60]
0000707b885da193  vmovaps xmm7, [rsp+0x70]
0000707b885da199  vmovaps xmm8, [rsp+0x80]
0000707b885da1a2  vmovaps xmm9, [rsp+0x90]
0000707b885da1ab  vmovaps xmm10, [rsp+0xA0]
0000707b885da1b4  vmovaps xmm11, [rsp+0xB0]
0000707b885da1bd  vmovaps xmm12, [rsp+0xC0]
0000707b885da1c6  vmovaps xmm13, [rsp+0xD0]
0000707b885da1cf  vmovaps xmm15, [rsp+0xE0]
0000707b885da1d8  add rsp, 0xF0
0000707b885da1df  pop r11
0000707b885da1e1  pop r10
0000707b885da1e3  pop r9
0000707b885da1e5  pop r8
0000707b885da1e7  pop rsi
0000707b885da1e8  pop rdi
0000707b885da1e9  pop rdx
0000707b885da1ea  pop rcx
0000707b885da1eb  pop rax
0000707b885da1ec  add rsp, 0x08
0000707b885da1f0  jmp 0x0000707B885D6400
0000707b885da1f5  sub rsp, 0x08
0000707b885da1f9  push rax
0000707b885da1fa  push rcx
0000707b885da1fb  push rdx
0000707b885da1fc  push rdi
0000707b885da1fd  push rsi
0000707b885da1fe  push r8
0000707b885da200  push r9
0000707b885da202  push r10
0000707b885da204  push r11
0000707b885da206  sub rsp, 0xF0
0000707b885da20d  vmovaps [rsp], xmm0
0000707b885da212  vmovaps [rsp+0x10], xmm2
0000707b885da218  vmovaps [rsp+0x20], xmm3
0000707b885da21e  vmovaps [rsp+0x30], xmm4
0000707b885da224  vmovaps [rsp+0x40], xmm5
0000707b885da22a  vmovaps [rsp+0x50], xmm6
0000707b885da230  vmovaps [rsp+0x60], xmm7
0000707b885da236  vmovaps [rsp+0x70], xmm8
0000707b885da23c  vmovaps [rsp+0x80], xmm9
0000707b885da245  vmovaps [rsp+0x90], xmm10
0000707b885da24e  vmovaps [rsp+0xA0], xmm11
0000707b885da257  vmovaps [rsp+0xB0], xmm12
0000707b885da260  vmovaps [rsp+0xC0], xmm13
0000707b885da269  vmovaps [rsp+0xD0], xmm14
0000707b885da272  vmovaps [rsp+0xE0], xmm15
0000707b885da27b  sub rsp, 0x30
0000707b885da27f  movaps [rsp], xmm1
0000707b885da283  movaps [rsp+0x10], xmm13
0000707b885da289  movaps [rsp+0x20], xmm9
0000707b885da28f  lea rdi, [rsp]
0000707b885da293  mov esi, 0x00
0000707b885da298  mov rax, 0x6471B35AC530
0000707b885da2a2  call rax
0000707b885da2a4  movaps xmm1, [rsp]
0000707b885da2a8  add rsp, 0x30
0000707b885da2ac  vmovaps xmm0, [rsp]
0000707b885da2b1  vmovaps xmm2, [rsp+0x10]
0000707b885da2b7  vmovaps xmm3, [rsp+0x20]
0000707b885da2bd  vmovaps xmm4, [rsp+0x30]
0000707b885da2c3  vmovaps xmm5, [rsp+0x40]
0000707b885da2c9  vmovaps xmm6, [rsp+0x50]
0000707b885da2cf  vmovaps xmm7, [rsp+0x60]
0000707b885da2d5  vmovaps xmm8, [rsp+0x70]
0000707b885da2db  vmovaps xmm9, [rsp+0x80]
0000707b885da2e4  vmovaps xmm10, [rsp+0x90]
0000707b885da2ed  vmovaps xmm11, [rsp+0xA0]
0000707b885da2f6  vmovaps xmm12, [rsp+0xB0]
0000707b885da2ff  vmovaps xmm13, [rsp+0xC0]
0000707b885da308  vmovaps xmm14, [rsp+0xD0]
0000707b885da311  vmovaps xmm15, [rsp+0xE0]
0000707b885da31a  add rsp, 0xF0
0000707b885da321  pop r11
0000707b885da323  pop r10
0000707b885da325  pop r9
0000707b885da327  pop r8
0000707b885da329  pop rsi
0000707b885da32a  pop rdi
0000707b885da32b  pop rdx
0000707b885da32c  pop rcx
0000707b885da32d  pop rax
0000707b885da32e  add rsp, 0x08
0000707b885da332  jmp 0x0000707B885D641A
0000707b885da337  sub rsp, 0x08
0000707b885da33b  push rax
0000707b885da33c  push rcx
0000707b885da33d  push rdx
0000707b885da33e  push rdi
0000707b885da33f  push rsi
0000707b885da340  push r8
0000707b885da342  push r9
0000707b885da344  push r10
0000707b885da346  push r11
0000707b885da348  sub rsp, 0xF0
0000707b885da34f  vmovaps [rsp], xmm0
0000707b885da354  vmovaps [rsp+0x10], xmm1
0000707b885da35a  vmovaps [rsp+0x20], xmm2
0000707b885da360  vmovaps [rsp+0x30], xmm3
0000707b885da366  vmovaps [rsp+0x40], xmm4
0000707b885da36c  vmovaps [rsp+0x50], xmm5
0000707b885da372  vmovaps [rsp+0x60], xmm6
0000707b885da378  vmovaps [rsp+0x70], xmm7
0000707b885da37e  vmovaps [rsp+0x80], xmm8
0000707b885da387  vmovaps [rsp+0x90], xmm9
0000707b885da390  vmovaps [rsp+0xA0], xmm10
0000707b885da399  vmovaps [rsp+0xB0], xmm11
0000707b885da3a2  vmovaps [rsp+0xC0], xmm13
0000707b885da3ab  vmovaps [rsp+0xD0], xmm14
0000707b885da3b4  vmovaps [rsp+0xE0], xmm15
0000707b885da3bd  sub rsp, 0x30
0000707b885da3c1  movaps [rsp], xmm12
0000707b885da3c6  movaps [rsp+0x10], xmm7
0000707b885da3cb  movaps [rsp+0x20], xmm13
0000707b885da3d1  lea rdi, [rsp]
0000707b885da3d5  mov esi, 0x00
0000707b885da3da  mov rax, 0x6471B35AC530
0000707b885da3e4  call rax
0000707b885da3e6  movaps xmm12, [rsp]
0000707b885da3eb  add rsp, 0x30
0000707b885da3ef  vmovaps xmm0, [rsp]
0000707b885da3f4  vmovaps xmm1, [rsp+0x10]
0000707b885da3fa  vmovaps xmm2, [rsp+0x20]
0000707b885da400  vmovaps xmm3, [rsp+0x30]
0000707b885da406  vmovaps xmm4, [rsp+0x40]
0000707b885da40c  vmovaps xmm5, [rsp+0x50]
0000707b885da412  vmovaps xmm6, [rsp+0x60]
0000707b885da418  vmovaps xmm7, [rsp+0x70]
0000707b885da41e  vmovaps xmm8, [rsp+0x80]
0000707b885da427  vmovaps xmm9, [rsp+0x90]
0000707b885da430  vmovaps xmm10, [rsp+0xA0]
0000707b885da439  vmovaps xmm11, [rsp+0xB0]
0000707b885da442  vmovaps xmm13, [rsp+0xC0]
0000707b885da44b  vmovaps xmm14, [rsp+0xD0]
0000707b885da454  vmovaps xmm15, [rsp+0xE0]
0000707b885da45d  add rsp, 0xF0
0000707b885da464  pop r11
0000707b885da466  pop r10
0000707b885da468  pop r9
0000707b885da46a  pop r8
0000707b885da46c  pop rsi
0000707b885da46d  pop rdi
0000707b885da46e  pop rdx
0000707b885da46f  pop rcx
0000707b885da470  pop rax
0000707b885da471  add rsp, 0x08
0000707b885da475  jmp 0x0000707B885D6441
0000707b885da47a  sub rsp, 0x08
0000707b885da47e  push rax
0000707b885da47f  push rcx
0000707b885da480  push rdx
0000707b885da481  push rdi
0000707b885da482  push rsi
0000707b885da483  push r8
0000707b885da485  push r9
0000707b885da487  push r10
0000707b885da489  push r11
0000707b885da48b  sub rsp, 0xF0
0000707b885da492  vmovaps [rsp], xmm0
0000707b885da497  vmovaps [rsp+0x10], xmm1
0000707b885da49d  vmovaps [rsp+0x20], xmm2
0000707b885da4a3  vmovaps [rsp+0x30], xmm3
0000707b885da4a9  vmovaps [rsp+0x40], xmm4
0000707b885da4af  vmovaps [rsp+0x50], xmm5
0000707b885da4b5  vmovaps [rsp+0x60], xmm6
0000707b885da4bb  vmovaps [rsp+0x70], xmm7
0000707b885da4c1  vmovaps [rsp+0x80], xmm8
0000707b885da4ca  vmovaps [rsp+0x90], xmm9
0000707b885da4d3  vmovaps [rsp+0xA0], xmm10
0000707b885da4dc  vmovaps [rsp+0xB0], xmm11
0000707b885da4e5  vmovaps [rsp+0xC0], xmm12
0000707b885da4ee  vmovaps [rsp+0xD0], xmm14
0000707b885da4f7  vmovaps [rsp+0xE0], xmm15
0000707b885da500  sub rsp, 0x30
0000707b885da504  movaps [rsp], xmm13
0000707b885da509  movaps [rsp+0x10], xmm15
0000707b885da50f  movaps [rsp+0x20], xmm8
0000707b885da515  lea rdi, [rsp]
0000707b885da519  mov esi, 0x00
0000707b885da51e  mov rax, 0x6471B35AC530
0000707b885da528  call rax
0000707b885da52a  movaps xmm13, [rsp]
0000707b885da52f  add rsp, 0x30
0000707b885da533  vmovaps xmm0, [rsp]
0000707b885da538  vmovaps xmm1, [rsp+0x10]
0000707b885da53e  vmovaps xmm2, [rsp+0x20]
0000707b885da544  vmovaps xmm3, [rsp+0x30]
0000707b885da54a  vmovaps xmm4, [rsp+0x40]
0000707b885da550  vmovaps xmm5, [rsp+0x50]
0000707b885da556  vmovaps xmm6, [rsp+0x60]
0000707b885da55c  vmovaps xmm7, [rsp+0x70]
0000707b885da562  vmovaps xmm8, [rsp+0x80]
0000707b885da56b  vmovaps xmm9, [rsp+0x90]
0000707b885da574  vmovaps xmm10, [rsp+0xA0]
0000707b885da57d  vmovaps xmm11, [rsp+0xB0]
0000707b885da586  vmovaps xmm12, [rsp+0xC0]
0000707b885da58f  vmovaps xmm14, [rsp+0xD0]
0000707b885da598  vmovaps xmm15, [rsp+0xE0]
0000707b885da5a1  add rsp, 0xF0
0000707b885da5a8  pop r11
0000707b885da5aa  pop r10
0000707b885da5ac  pop r9
0000707b885da5ae  pop r8
0000707b885da5b0  pop rsi
0000707b885da5b1  pop rdi
0000707b885da5b2  pop rdx
0000707b885da5b3  pop rcx
0000707b885da5b4  pop rax
0000707b885da5b5  add rsp, 0x08
0000707b885da5b9  jmp 0x0000707B885D645C
0000707b885da5be  sub rsp, 0x08
0000707b885da5c2  push rax
0000707b885da5c3  push rcx
0000707b885da5c4  push rdx
0000707b885da5c5  push rdi
0000707b885da5c6  push rsi
0000707b885da5c7  push r8
0000707b885da5c9  push r9
0000707b885da5cb  push r10
0000707b885da5cd  push r11
0000707b885da5cf  sub rsp, 0xF0
0000707b885da5d6  vmovaps [rsp], xmm0
0000707b885da5db  vmovaps [rsp+0x10], xmm1
0000707b885da5e1  vmovaps [rsp+0x20], xmm2
0000707b885da5e7  vmovaps [rsp+0x30], xmm3
0000707b885da5ed  vmovaps [rsp+0x40], xmm4
0000707b885da5f3  vmovaps [rsp+0x50], xmm5
0000707b885da5f9  vmovaps [rsp+0x60], xmm6
0000707b885da5ff  vmovaps [rsp+0x70], xmm7
0000707b885da605  vmovaps [rsp+0x80], xmm9
0000707b885da60e  vmovaps [rsp+0x90], xmm10
0000707b885da617  vmovaps [rsp+0xA0], xmm11
0000707b885da620  vmovaps [rsp+0xB0], xmm12
0000707b885da629  vmovaps [rsp+0xC0], xmm13
0000707b885da632  vmovaps [rsp+0xD0], xmm14
0000707b885da63b  vmovaps [rsp+0xE0], xmm15
0000707b885da644  sub rsp, 0x30
0000707b885da648  movaps [rsp], xmm8
0000707b885da64d  movaps [rsp+0x10], xmm15
0000707b885da653  movaps [rsp+0x20], xmm9
0000707b885da659  lea rdi, [rsp]
0000707b885da65d  mov esi, 0x00
0000707b885da662  mov rax, 0x6471B35AC530
0000707b885da66c  call rax
0000707b885da66e  movaps xmm8, [rsp]
0000707b885da673  add rsp, 0x30
0000707b885da677  vmovaps xmm0, [rsp]
0000707b885da67c  vmovaps xmm1, [rsp+0x10]
0000707b885da682  vmovaps xmm2, [rsp+0x20]
0000707b885da688  vmovaps xmm3, [rsp+0x30]
0000707b885da68e  vmovaps xmm4, [rsp+0x40]
0000707b885da694  vmovaps xmm5, [rsp+0x50]
0000707b885da69a  vmovaps xmm6, [rsp+0x60]
0000707b885da6a0  vmovaps xmm7, [rsp+0x70]
0000707b885da6a6  vmovaps xmm9, [rsp+0x80]
0000707b885da6af  vmovaps xmm10, [rsp+0x90]
0000707b885da6b8  vmovaps xmm11, [rsp+0xA0]
0000707b885da6c1  vmovaps xmm12, [rsp+0xB0]
0000707b885da6ca  vmovaps xmm13, [rsp+0xC0]
0000707b885da6d3  vmovaps xmm14, [rsp+0xD0]
0000707b885da6dc  vmovaps xmm15, [rsp+0xE0]
0000707b885da6e5  add rsp, 0xF0
0000707b885da6ec  pop r11
0000707b885da6ee  pop r10
0000707b885da6f0  pop r9
0000707b885da6f2  pop r8
0000707b885da6f4  pop rsi
0000707b885da6f5  pop rdi
0000707b885da6f6  pop rdx
0000707b885da6f7  pop rcx
0000707b885da6f8  pop rax
0000707b885da6f9  add rsp, 0x08
0000707b885da6fd  jmp 0x0000707B885D648A
0000707b885da702  sub rsp, 0x08
0000707b885da706  push rax
0000707b885da707  push rcx
0000707b885da708  push rdx
0000707b885da709  push rdi
0000707b885da70a  push rsi
0000707b885da70b  push r8
0000707b885da70d  push r9
0000707b885da70f  push r10
0000707b885da711  push r11
0000707b885da713  sub rsp, 0xF0
0000707b885da71a  vmovaps [rsp], xmm0
0000707b885da71f  vmovaps [rsp+0x10], xmm1
0000707b885da725  vmovaps [rsp+0x20], xmm2
0000707b885da72b  vmovaps [rsp+0x30], xmm3
0000707b885da731  vmovaps [rsp+0x40], xmm4
0000707b885da737  vmovaps [rsp+0x50], xmm5
0000707b885da73d  vmovaps [rsp+0x60], xmm6
0000707b885da743  vmovaps [rsp+0x70], xmm7
0000707b885da749  vmovaps [rsp+0x80], xmm8
0000707b885da752  vmovaps [rsp+0x90], xmm9
0000707b885da75b  vmovaps [rsp+0xA0], xmm10
0000707b885da764  vmovaps [rsp+0xB0], xmm11
0000707b885da76d  vmovaps [rsp+0xC0], xmm12
0000707b885da776  vmovaps [rsp+0xD0], xmm13
0000707b885da77f  vmovaps [rsp+0xE0], xmm14
0000707b885da788  sub rsp, 0x30
0000707b885da78c  movaps [rsp], xmm15
0000707b885da791  movaps [rsp+0x10], xmm11
0000707b885da797  movaps [rsp+0x20], xmm6
0000707b885da79c  lea rdi, [rsp]
0000707b885da7a0  mov esi, 0x00
0000707b885da7a5  mov rax, 0x6471B35AC530
0000707b885da7af  call rax
0000707b885da7b1  movaps xmm15, [rsp]
0000707b885da7b6  add rsp, 0x30
0000707b885da7ba  vmovaps xmm0, [rsp]
0000707b885da7bf  vmovaps xmm1, [rsp+0x10]
0000707b885da7c5  vmovaps xmm2, [rsp+0x20]
0000707b885da7cb  vmovaps xmm3, [rsp+0x30]
0000707b885da7d1  vmovaps xmm4, [rsp+0x40]
0000707b885da7d7  vmovaps xmm5, [rsp+0x50]
0000707b885da7dd  vmovaps xmm6, [rsp+0x60]
0000707b885da7e3  vmovaps xmm7, [rsp+0x70]
0000707b885da7e9  vmovaps xmm8, [rsp+0x80]
0000707b885da7f2  vmovaps xmm9, [rsp+0x90]
0000707b885da7fb  vmovaps xmm10, [rsp+0xA0]
0000707b885da804  vmovaps xmm11, [rsp+0xB0]
0000707b885da80d  vmovaps xmm12, [rsp+0xC0]
0000707b885da816  vmovaps xmm13, [rsp+0xD0]
0000707b885da81f  vmovaps xmm14, [rsp+0xE0]
0000707b885da828  add rsp, 0xF0
0000707b885da82f  pop r11
0000707b885da831  pop r10
0000707b885da833  pop r9
0000707b885da835  pop r8
0000707b885da837  pop rsi
0000707b885da838  pop rdi
0000707b885da839  pop rdx
0000707b885da83a  pop rcx
0000707b885da83b  pop rax
0000707b885da83c  add rsp, 0x08
0000707b885da840  jmp 0x0000707B885D64A5
0000707b885da845  sub rsp, 0x08
0000707b885da849  push rax
0000707b885da84a  push rcx
0000707b885da84b  push rdx
0000707b885da84c  push rdi
0000707b885da84d  push rsi
0000707b885da84e  push r8
0000707b885da850  push r9
0000707b885da852  push r10
0000707b885da854  push r11
0000707b885da856  sub rsp, 0xF0
0000707b885da85d  vmovaps [rsp], xmm0
0000707b885da862  vmovaps [rsp+0x10], xmm1
0000707b885da868  vmovaps [rsp+0x20], xmm2
0000707b885da86e  vmovaps [rsp+0x30], xmm3
0000707b885da874  vmovaps [rsp+0x40], xmm4
0000707b885da87a  vmovaps [rsp+0x50], xmm5
0000707b885da880  vmovaps [rsp+0x60], xmm6
0000707b885da886  vmovaps [rsp+0x70], xmm8
0000707b885da88c  vmovaps [rsp+0x80], xmm9
0000707b885da895  vmovaps [rsp+0x90], xmm10
0000707b885da89e  vmovaps [rsp+0xA0], xmm11
0000707b885da8a7  vmovaps [rsp+0xB0], xmm12
0000707b885da8b0  vmovaps [rsp+0xC0], xmm13
0000707b885da8b9  vmovaps [rsp+0xD0], xmm14
0000707b885da8c2  vmovaps [rsp+0xE0], xmm15
0000707b885da8cb  sub rsp, 0x30
0000707b885da8cf  movaps [rsp], xmm7
0000707b885da8d3  movaps [rsp+0x10], xmm11
0000707b885da8d9  movaps [rsp+0x20], xmm9
0000707b885da8df  lea rdi, [rsp]
0000707b885da8e3  mov esi, 0x00
0000707b885da8e8  mov rax, 0x6471B35AC530
0000707b885da8f2  call rax
0000707b885da8f4  movaps xmm7, [rsp]
0000707b885da8f8  add rsp, 0x30
0000707b885da8fc  vmovaps xmm0, [rsp]
0000707b885da901  vmovaps xmm1, [rsp+0x10]
0000707b885da907  vmovaps xmm2, [rsp+0x20]
0000707b885da90d  vmovaps xmm3, [rsp+0x30]
0000707b885da913  vmovaps xmm4, [rsp+0x40]
0000707b885da919  vmovaps xmm5, [rsp+0x50]
0000707b885da91f  vmovaps xmm6, [rsp+0x60]
0000707b885da925  vmovaps xmm8, [rsp+0x70]
0000707b885da92b  vmovaps xmm9, [rsp+0x80]
0000707b885da934  vmovaps xmm10, [rsp+0x90]
0000707b885da93d  vmovaps xmm11, [rsp+0xA0]
0000707b885da946  vmovaps xmm12, [rsp+0xB0]
0000707b885da94f  vmovaps xmm13, [rsp+0xC0]
0000707b885da958  vmovaps xmm14, [rsp+0xD0]
0000707b885da961  vmovaps xmm15, [rsp+0xE0]
0000707b885da96a  add rsp, 0xF0
0000707b885da971  pop r11
0000707b885da973  pop r10
0000707b885da975  pop r9
0000707b885da977  pop r8
0000707b885da979  pop rsi
0000707b885da97a  pop rdi
0000707b885da97b  pop rdx
0000707b885da97c  pop rcx
0000707b885da97d  pop rax
0000707b885da97e  add rsp, 0x08
0000707b885da982  jmp 0x0000707B885D64D2
0000707b885da987  sub rsp, 0x08
0000707b885da98b  push rax
0000707b885da98c  push rcx
0000707b885da98d  push rdx
0000707b885da98e  push rdi
0000707b885da98f  push rsi
0000707b885da990  push r8
0000707b885da992  push r9
0000707b885da994  push r10
0000707b885da996  push r11
0000707b885da998  sub rsp, 0xF0
0000707b885da99f  vmovaps [rsp], xmm0
0000707b885da9a4  vmovaps [rsp+0x10], xmm1
0000707b885da9aa  vmovaps [rsp+0x20], xmm2
0000707b885da9b0  vmovaps [rsp+0x30], xmm3
0000707b885da9b6  vmovaps [rsp+0x40], xmm4
0000707b885da9bc  vmovaps [rsp+0x50], xmm5
0000707b885da9c2  vmovaps [rsp+0x60], xmm6
0000707b885da9c8  vmovaps [rsp+0x70], xmm7
0000707b885da9ce  vmovaps [rsp+0x80], xmm8
0000707b885da9d7  vmovaps [rsp+0x90], xmm9
0000707b885da9e0  vmovaps [rsp+0xA0], xmm10
0000707b885da9e9  vmovaps [rsp+0xB0], xmm12
0000707b885da9f2  vmovaps [rsp+0xC0], xmm13
0000707b885da9fb  vmovaps [rsp+0xD0], xmm14
0000707b885daa04  vmovaps [rsp+0xE0], xmm15
0000707b885daa0d  sub rsp, 0x30
0000707b885daa11  movaps [rsp], xmm11
0000707b885daa16  movaps [rsp+0x10], xmm10
0000707b885daa1c  movaps [rsp+0x20], xmm14
0000707b885daa22  lea rdi, [rsp]
0000707b885daa26  mov esi, 0x00
0000707b885daa2b  mov rax, 0x6471B35AC530
0000707b885daa35  call rax
0000707b885daa37  movaps xmm11, [rsp]
0000707b885daa3c  add rsp, 0x30
0000707b885daa40  vmovaps xmm0, [rsp]
0000707b885daa45  vmovaps xmm1, [rsp+0x10]
0000707b885daa4b  vmovaps xmm2, [rsp+0x20]
0000707b885daa51  vmovaps xmm3, [rsp+0x30]
0000707b885daa57  vmovaps xmm4, [rsp+0x40]
0000707b885daa5d  vmovaps xmm5, [rsp+0x50]
0000707b885daa63  vmovaps xmm6, [rsp+0x60]
0000707b885daa69  vmovaps xmm7, [rsp+0x70]
0000707b885daa6f  vmovaps xmm8, [rsp+0x80]
0000707b885daa78  vmovaps xmm9, [rsp+0x90]
0000707b885daa81  vmovaps xmm10, [rsp+0xA0]
0000707b885daa8a  vmovaps xmm12, [rsp+0xB0]
0000707b885daa93  vmovaps xmm13, [rsp+0xC0]
0000707b885daa9c  vmovaps xmm14, [rsp+0xD0]
0000707b885daaa5  vmovaps xmm15, [rsp+0xE0]
0000707b885daaae  add rsp, 0xF0
0000707b885daab5  pop r11
0000707b885daab7  pop r10
0000707b885daab9  pop r9
0000707b885daabb  pop r8
0000707b885daabd  pop rsi
0000707b885daabe  pop rdi
0000707b885daabf  pop rdx
0000707b885daac0  pop rcx
0000707b885daac1  pop rax
0000707b885daac2  add rsp, 0x08
0000707b885daac6  jmp 0x0000707B885D64ED
0000707b885daacb  call 0x0000707B884E45A0
0000707b885daad0  jmp 0x0000707B885D64F7
0000707b885daad5  sub rsp, 0x08
0000707b885daad9  push rax
0000707b885daada  push rcx
0000707b885daadb  push rdx
0000707b885daadc  push rdi
0000707b885daadd  push rsi
0000707b885daade  push r8
0000707b885daae0  push r9
0000707b885daae2  push r10
0000707b885daae4  push r11
0000707b885daae6  sub rsp, 0xF0
0000707b885daaed  vmovaps [rsp], xmm0
0000707b885daaf2  vmovaps [rsp+0x10], xmm1
0000707b885daaf8  vmovaps [rsp+0x20], xmm2
0000707b885daafe  vmovaps [rsp+0x30], xmm3
0000707b885dab04  vmovaps [rsp+0x40], xmm4
0000707b885dab0a  vmovaps [rsp+0x50], xmm5
0000707b885dab10  vmovaps [rsp+0x60], xmm6
0000707b885dab16  vmovaps [rsp+0x70], xmm7
0000707b885dab1c  vmovaps [rsp+0x80], xmm8
0000707b885dab25  vmovaps [rsp+0x90], xmm9
0000707b885dab2e  vmovaps [rsp+0xA0], xmm11
0000707b885dab37  vmovaps [rsp+0xB0], xmm12
0000707b885dab40  vmovaps [rsp+0xC0], xmm13
0000707b885dab49  vmovaps [rsp+0xD0], xmm14
0000707b885dab52  vmovaps [rsp+0xE0], xmm15
0000707b885dab5b  sub rsp, 0x30
0000707b885dab5f  movaps [rsp], xmm10
0000707b885dab64  movaps [rsp+0x10], xmm1
0000707b885dab69  movaps [rsp+0x20], xmm12
0000707b885dab6f  lea rdi, [rsp]
0000707b885dab73  mov esi, 0x00
0000707b885dab78  mov rax, 0x6471B35AC530
0000707b885dab82  call rax
0000707b885dab84  movaps xmm10, [rsp]
0000707b885dab89  add rsp, 0x30
0000707b885dab8d  vmovaps xmm0, [rsp]
0000707b885dab92  vmovaps xmm1, [rsp+0x10]
0000707b885dab98  vmovaps xmm2, [rsp+0x20]
0000707b885dab9e  vmovaps xmm3, [rsp+0x30]
0000707b885daba4  vmovaps xmm4, [rsp+0x40]
0000707b885dabaa  vmovaps xmm5, [rsp+0x50]
0000707b885dabb0  vmovaps xmm6, [rsp+0x60]
0000707b885dabb6  vmovaps xmm7, [rsp+0x70]
0000707b885dabbc  vmovaps xmm8, [rsp+0x80]
0000707b885dabc5  vmovaps xmm9, [rsp+0x90]
0000707b885dabce  vmovaps xmm11, [rsp+0xA0]
0000707b885dabd7  vmovaps xmm12, [rsp+0xB0]
0000707b885dabe0  vmovaps xmm13, [rsp+0xC0]
0000707b885dabe9  vmovaps xmm14, [rsp+0xD0]
0000707b885dabf2  vmovaps xmm15, [rsp+0xE0]
0000707b885dabfb  add rsp, 0xF0
0000707b885dac02  pop r11
0000707b885dac04  pop r10
0000707b885dac06  pop r9
0000707b885dac08  pop r8
0000707b885dac0a  pop rsi
0000707b885dac0b  pop rdi
0000707b885dac0c  pop rdx
0000707b885dac0d  pop rcx
0000707b885dac0e  pop rax
0000707b885dac0f  add rsp, 0x08
0000707b885dac13  jmp 0x0000707B885D651A
0000707b885dac18  sub rsp, 0x08
0000707b885dac1c  push rax
0000707b885dac1d  push rcx
0000707b885dac1e  push rdx
0000707b885dac1f  push rdi
0000707b885dac20  push rsi
0000707b885dac21  push r8
0000707b885dac23  push r9
0000707b885dac25  push r10
0000707b885dac27  push r11
0000707b885dac29  sub rsp, 0xF0
0000707b885dac30  vmovaps [rsp], xmm0
0000707b885dac35  vmovaps [rsp+0x10], xmm1
0000707b885dac3b  vmovaps [rsp+0x20], xmm2
0000707b885dac41  vmovaps [rsp+0x30], xmm3
0000707b885dac47  vmovaps [rsp+0x40], xmm4
0000707b885dac4d  vmovaps [rsp+0x50], xmm5
0000707b885dac53  vmovaps [rsp+0x60], xmm6
0000707b885dac59  vmovaps [rsp+0x70], xmm7
0000707b885dac5f  vmovaps [rsp+0x80], xmm8
0000707b885dac68  vmovaps [rsp+0x90], xmm9
0000707b885dac71  vmovaps [rsp+0xA0], xmm10
0000707b885dac7a  vmovaps [rsp+0xB0], xmm11
0000707b885dac83  vmovaps [rsp+0xC0], xmm13
0000707b885dac8c  vmovaps [rsp+0xD0], xmm14
0000707b885dac95  vmovaps [rsp+0xE0], xmm15
0000707b885dac9e  sub rsp, 0x30
0000707b885daca2  movaps [rsp], xmm12
0000707b885daca7  movaps [rsp+0x10], xmm14
0000707b885dacad  movaps [rsp+0x20], xmm1
0000707b885dacb2  lea rdi, [rsp]
0000707b885dacb6  mov esi, 0x00
0000707b885dacbb  mov rax, 0x6471B35AC530
0000707b885dacc5  call rax
0000707b885dacc7  movaps xmm12, [rsp]
0000707b885daccc  add rsp, 0x30
0000707b885dacd0  vmovaps xmm0, [rsp]
0000707b885dacd5  vmovaps xmm1, [rsp+0x10]
0000707b885dacdb  vmovaps xmm2, [rsp+0x20]
0000707b885dace1  vmovaps xmm3, [rsp+0x30]
0000707b885dace7  vmovaps xmm4, [rsp+0x40]
0000707b885daced  vmovaps xmm5, [rsp+0x50]
0000707b885dacf3  vmovaps xmm6, [rsp+0x60]
0000707b885dacf9  vmovaps xmm7, [rsp+0x70]
0000707b885dacff  vmovaps xmm8, [rsp+0x80]
0000707b885dad08  vmovaps xmm9, [rsp+0x90]
0000707b885dad11  vmovaps xmm10, [rsp+0xA0]
0000707b885dad1a  vmovaps xmm11, [rsp+0xB0]
0000707b885dad23  vmovaps xmm13, [rsp+0xC0]
0000707b885dad2c  vmovaps xmm14, [rsp+0xD0]
0000707b885dad35  vmovaps xmm15, [rsp+0xE0]
0000707b885dad3e  add rsp, 0xF0
0000707b885dad45  pop r11
0000707b885dad47  pop r10
0000707b885dad49  pop r9
0000707b885dad4b  pop r8
0000707b885dad4d  pop rsi
0000707b885dad4e  pop rdi
0000707b885dad4f  pop rdx
0000707b885dad50  pop rcx
0000707b885dad51  pop rax
0000707b885dad52  add rsp, 0x08
0000707b885dad56  jmp 0x0000707B885D6549
0000707b885dad5b  sub rsp, 0x08
0000707b885dad5f  push rax
0000707b885dad60  push rcx
0000707b885dad61  push rdx
0000707b885dad62  push rdi
0000707b885dad63  push rsi
0000707b885dad64  push r8
0000707b885dad66  push r9
0000707b885dad68  push r10
0000707b885dad6a  push r11
0000707b885dad6c  sub rsp, 0xF0
0000707b885dad73  vmovaps [rsp], xmm0
0000707b885dad78  vmovaps [rsp+0x10], xmm1
0000707b885dad7e  vmovaps [rsp+0x20], xmm2
0000707b885dad84  vmovaps [rsp+0x30], xmm3
0000707b885dad8a  vmovaps [rsp+0x40], xmm4
0000707b885dad90  vmovaps [rsp+0x50], xmm5
0000707b885dad96  vmovaps [rsp+0x60], xmm6
0000707b885dad9c  vmovaps [rsp+0x70], xmm7
0000707b885dada2  vmovaps [rsp+0x80], xmm8
0000707b885dadab  vmovaps [rsp+0x90], xmm9
0000707b885dadb4  vmovaps [rsp+0xA0], xmm10
0000707b885dadbd  vmovaps [rsp+0xB0], xmm11
0000707b885dadc6  vmovaps [rsp+0xC0], xmm12
0000707b885dadcf  vmovaps [rsp+0xD0], xmm13
0000707b885dadd8  vmovaps [rsp+0xE0], xmm15
0000707b885dade1  sub rsp, 0x30
0000707b885dade5  movaps [rsp], xmm14
0000707b885dadea  movaps [rsp+0x10], xmm9
0000707b885dadf0  movaps [rsp+0x20], xmm1
0000707b885dadf5  lea rdi, [rsp]
0000707b885dadf9  mov esi, 0x00
0000707b885dadfe  mov rax, 0x6471B35AC530
0000707b885dae08  call rax
0000707b885dae0a  movaps xmm14, [rsp]
0000707b885dae0f  add rsp, 0x30
0000707b885dae13  vmovaps xmm0, [rsp]
0000707b885dae18  vmovaps xmm1, [rsp+0x10]
0000707b885dae1e  vmovaps xmm2, [rsp+0x20]
0000707b885dae24  vmovaps xmm3, [rsp+0x30]
0000707b885dae2a  vmovaps xmm4, [rsp+0x40]
0000707b885dae30  vmovaps xmm5, [rsp+0x50]
0000707b885dae36  vmovaps xmm6, [rsp+0x60]
0000707b885dae3c  vmovaps xmm7, [rsp+0x70]
0000707b885dae42  vmovaps xmm8, [rsp+0x80]
0000707b885dae4b  vmovaps xmm9, [rsp+0x90]
0000707b885dae54  vmovaps xmm10, [rsp+0xA0]
0000707b885dae5d  vmovaps xmm11, [rsp+0xB0]
0000707b885dae66  vmovaps xmm12, [rsp+0xC0]
0000707b885dae6f  vmovaps xmm13, [rsp+0xD0]
0000707b885dae78  vmovaps xmm15, [rsp+0xE0]
0000707b885dae81  add rsp, 0xF0
0000707b885dae88  pop r11
0000707b885dae8a  pop r10
0000707b885dae8c  pop r9
0000707b885dae8e  pop r8
0000707b885dae90  pop rsi
0000707b885dae91  pop rdi
0000707b885dae92  pop rdx
0000707b885dae93  pop rcx
0000707b885dae94  pop rax
0000707b885dae95  add rsp, 0x08
0000707b885dae99  jmp 0x0000707B885D6578
0000707b885dae9e  sub rsp, 0x08
0000707b885daea2  push rax
0000707b885daea3  push rcx
0000707b885daea4  push rdx
0000707b885daea5  push rdi
0000707b885daea6  push rsi
0000707b885daea7  push r8
0000707b885daea9  push r9
0000707b885daeab  push r10
0000707b885daead  push r11
0000707b885daeaf  sub rsp, 0xF0
0000707b885daeb6  vmovaps [rsp], xmm0
0000707b885daebb  vmovaps [rsp+0x10], xmm2
0000707b885daec1  vmovaps [rsp+0x20], xmm3
0000707b885daec7  vmovaps [rsp+0x30], xmm4
0000707b885daecd  vmovaps [rsp+0x40], xmm5
0000707b885daed3  vmovaps [rsp+0x50], xmm6
0000707b885daed9  vmovaps [rsp+0x60], xmm7
0000707b885daedf  vmovaps [rsp+0x70], xmm8
0000707b885daee5  vmovaps [rsp+0x80], xmm9
0000707b885daeee  vmovaps [rsp+0x90], xmm10
0000707b885daef7  vmovaps [rsp+0xA0], xmm11
0000707b885daf00  vmovaps [rsp+0xB0], xmm12
0000707b885daf09  vmovaps [rsp+0xC0], xmm13
0000707b885daf12  vmovaps [rsp+0xD0], xmm14
0000707b885daf1b  vmovaps [rsp+0xE0], xmm15
0000707b885daf24  sub rsp, 0x30
0000707b885daf28  movaps [rsp], xmm1
0000707b885daf2c  movaps [rsp+0x10], xmm13
0000707b885daf32  movaps [rsp+0x20], xmm8
0000707b885daf38  lea rdi, [rsp]
0000707b885daf3c  mov esi, 0x00
0000707b885daf41  mov rax, 0x6471B35AC530
0000707b885daf4b  call rax
0000707b885daf4d  movaps xmm1, [rsp]
0000707b885daf51  add rsp, 0x30
0000707b885daf55  vmovaps xmm0, [rsp]
0000707b885daf5a  vmovaps xmm2, [rsp+0x10]
0000707b885daf60  vmovaps xmm3, [rsp+0x20]
0000707b885daf66  vmovaps xmm4, [rsp+0x30]
0000707b885daf6c  vmovaps xmm5, [rsp+0x40]
0000707b885daf72  vmovaps xmm6, [rsp+0x50]
0000707b885daf78  vmovaps xmm7, [rsp+0x60]
0000707b885daf7e  vmovaps xmm8, [rsp+0x70]
0000707b885daf84  vmovaps xmm9, [rsp+0x80]
0000707b885daf8d  vmovaps xmm10, [rsp+0x90]
0000707b885daf96  vmovaps xmm11, [rsp+0xA0]
0000707b885daf9f  vmovaps xmm12, [rsp+0xB0]
0000707b885dafa8  vmovaps xmm13, [rsp+0xC0]
0000707b885dafb1  vmovaps xmm14, [rsp+0xD0]
0000707b885dafba  vmovaps xmm15, [rsp+0xE0]
0000707b885dafc3  add rsp, 0xF0
0000707b885dafca  pop r11
0000707b885dafcc  pop r10
0000707b885dafce  pop r9
0000707b885dafd0  pop r8
0000707b885dafd2  pop rsi
0000707b885dafd3  pop rdi
0000707b885dafd4  pop rdx
0000707b885dafd5  pop rcx
0000707b885dafd6  pop rax
0000707b885dafd7  add rsp, 0x08
0000707b885dafdb  jmp 0x0000707B885D659A
0000707b885dafe0  call 0x0000707B8840C260
0000707b885dafe5  jmp 0x0000707B885D65A8
0000707b885dafea  call 0x0000707B884DE950
0000707b885dafef  jmp 0x0000707B885D65B2
0000707b885daff4  sub rsp, 0x08
0000707b885daff8  push rax
0000707b885daff9  push rcx
0000707b885daffa  push rdx
0000707b885daffb  push rdi
0000707b885daffc  push rsi
0000707b885daffd  push r8
0000707b885dafff  push r9
0000707b885db001  push r10
0000707b885db003  push r11
0000707b885db005  sub rsp, 0xF0
0000707b885db00c  vmovaps [rsp], xmm0
0000707b885db011  vmovaps [rsp+0x10], xmm1
0000707b885db017  vmovaps [rsp+0x20], xmm2
0000707b885db01d  vmovaps [rsp+0x30], xmm3
0000707b885db023  vmovaps [rsp+0x40], xmm4
0000707b885db029  vmovaps [rsp+0x50], xmm5
0000707b885db02f  vmovaps [rsp+0x60], xmm6
0000707b885db035  vmovaps [rsp+0x70], xmm7
0000707b885db03b  vmovaps [rsp+0x80], xmm9
0000707b885db044  vmovaps [rsp+0x90], xmm10
0000707b885db04d  vmovaps [rsp+0xA0], xmm11
0000707b885db056  vmovaps [rsp+0xB0], xmm12
0000707b885db05f  vmovaps [rsp+0xC0], xmm13
0000707b885db068  vmovaps [rsp+0xD0], xmm14
0000707b885db071  vmovaps [rsp+0xE0], xmm15
0000707b885db07a  sub rsp, 0x30
0000707b885db07e  movaps [rsp], xmm8
0000707b885db083  movaps [rsp+0x10], xmm15
0000707b885db089  movaps [rsp+0x20], xmm7
0000707b885db08e  lea rdi, [rsp]
0000707b885db092  mov esi, 0x00
0000707b885db097  mov rax, 0x6471B35AC530
0000707b885db0a1  call rax
0000707b885db0a3  movaps xmm8, [rsp]
0000707b885db0a8  add rsp, 0x30
0000707b885db0ac  vmovaps xmm0, [rsp]
0000707b885db0b1  vmovaps xmm1, [rsp+0x10]
0000707b885db0b7  vmovaps xmm2, [rsp+0x20]
0000707b885db0bd  vmovaps xmm3, [rsp+0x30]
0000707b885db0c3  vmovaps xmm4, [rsp+0x40]
0000707b885db0c9  vmovaps xmm5, [rsp+0x50]
0000707b885db0cf  vmovaps xmm6, [rsp+0x60]
0000707b885db0d5  vmovaps xmm7, [rsp+0x70]
0000707b885db0db  vmovaps xmm9, [rsp+0x80]
0000707b885db0e4  vmovaps xmm10, [rsp+0x90]
0000707b885db0ed  vmovaps xmm11, [rsp+0xA0]
0000707b885db0f6  vmovaps xmm12, [rsp+0xB0]
0000707b885db0ff  vmovaps xmm13, [rsp+0xC0]
0000707b885db108  vmovaps xmm14, [rsp+0xD0]
0000707b885db111  vmovaps xmm15, [rsp+0xE0]
0000707b885db11a  add rsp, 0xF0
0000707b885db121  pop r11
0000707b885db123  pop r10
0000707b885db125  pop r9
0000707b885db127  pop r8
0000707b885db129  pop rsi
0000707b885db12a  pop rdi
0000707b885db12b  pop rdx
0000707b885db12c  pop rcx
0000707b885db12d  pop rax
0000707b885db12e  add rsp, 0x08
0000707b885db132  jmp 0x0000707B885D65D4
0000707b885db137  sub rsp, 0x08
0000707b885db13b  push rax
0000707b885db13c  push rcx
0000707b885db13d  push rdx
0000707b885db13e  push rdi
0000707b885db13f  push rsi
0000707b885db140  push r8
0000707b885db142  push r9
0000707b885db144  push r10
0000707b885db146  push r11
0000707b885db148  sub rsp, 0xF0
0000707b885db14f  vmovaps [rsp], xmm0
0000707b885db154  vmovaps [rsp+0x10], xmm1
0000707b885db15a  vmovaps [rsp+0x20], xmm2
0000707b885db160  vmovaps [rsp+0x30], xmm3
0000707b885db166  vmovaps [rsp+0x40], xmm4
0000707b885db16c  vmovaps [rsp+0x50], xmm5
0000707b885db172  vmovaps [rsp+0x60], xmm6
0000707b885db178  vmovaps [rsp+0x70], xmm8
0000707b885db17e  vmovaps [rsp+0x80], xmm9
0000707b885db187  vmovaps [rsp+0x90], xmm10
0000707b885db190  vmovaps [rsp+0xA0], xmm11
0000707b885db199  vmovaps [rsp+0xB0], xmm12
0000707b885db1a2  vmovaps [rsp+0xC0], xmm13
0000707b885db1ab  vmovaps [rsp+0xD0], xmm14
0000707b885db1b4  vmovaps [rsp+0xE0], xmm15
0000707b885db1bd  sub rsp, 0x30
0000707b885db1c1  movaps [rsp], xmm7
0000707b885db1c5  movaps [rsp+0x10], xmm9
0000707b885db1cb  movaps [rsp+0x20], xmm15
0000707b885db1d1  lea rdi, [rsp]
0000707b885db1d5  mov esi, 0x00
0000707b885db1da  mov rax, 0x6471B35AC530
0000707b885db1e4  call rax
0000707b885db1e6  movaps xmm7, [rsp]
0000707b885db1ea  add rsp, 0x30
0000707b885db1ee  vmovaps xmm0, [rsp]
0000707b885db1f3  vmovaps xmm1, [rsp+0x10]
0000707b885db1f9  vmovaps xmm2, [rsp+0x20]
0000707b885db1ff  vmovaps xmm3, [rsp+0x30]
0000707b885db205  vmovaps xmm4, [rsp+0x40]
0000707b885db20b  vmovaps xmm5, [rsp+0x50]
0000707b885db211  vmovaps xmm6, [rsp+0x60]
0000707b885db217  vmovaps xmm8, [rsp+0x70]
0000707b885db21d  vmovaps xmm9, [rsp+0x80]
0000707b885db226  vmovaps xmm10, [rsp+0x90]
0000707b885db22f  vmovaps xmm11, [rsp+0xA0]
0000707b885db238  vmovaps xmm12, [rsp+0xB0]
0000707b885db241  vmovaps xmm13, [rsp+0xC0]
0000707b885db24a  vmovaps xmm14, [rsp+0xD0]
0000707b885db253  vmovaps xmm15, [rsp+0xE0]
0000707b885db25c  add rsp, 0xF0
0000707b885db263  pop r11
0000707b885db265  pop r10
0000707b885db267  pop r9
0000707b885db269  pop r8
0000707b885db26b  pop rsi
0000707b885db26c  pop rdi
0000707b885db26d  pop rdx
0000707b885db26e  pop rcx
0000707b885db26f  pop rax
0000707b885db270  add rsp, 0x08
0000707b885db274  jmp 0x0000707B885D6601
0000707b885db279  sub rsp, 0x08
0000707b885db27d  push rax
0000707b885db27e  push rcx
0000707b885db27f  push rdx
0000707b885db280  push rdi
0000707b885db281  push rsi
0000707b885db282  push r8
0000707b885db284  push r9
0000707b885db286  push r10
0000707b885db288  push r11
0000707b885db28a  sub rsp, 0xF0
0000707b885db291  vmovaps [rsp], xmm0
0000707b885db296  vmovaps [rsp+0x10], xmm1
0000707b885db29c  vmovaps [rsp+0x20], xmm2
0000707b885db2a2  vmovaps [rsp+0x30], xmm3
0000707b885db2a8  vmovaps [rsp+0x40], xmm4
0000707b885db2ae  vmovaps [rsp+0x50], xmm5
0000707b885db2b4  vmovaps [rsp+0x60], xmm6
0000707b885db2ba  vmovaps [rsp+0x70], xmm7
0000707b885db2c0  vmovaps [rsp+0x80], xmm8
0000707b885db2c9  vmovaps [rsp+0x90], xmm10
0000707b885db2d2  vmovaps [rsp+0xA0], xmm11
0000707b885db2db  vmovaps [rsp+0xB0], xmm12
0000707b885db2e4  vmovaps [rsp+0xC0], xmm13
0000707b885db2ed  vmovaps [rsp+0xD0], xmm14
0000707b885db2f6  vmovaps [rsp+0xE0], xmm15
0000707b885db2ff  sub rsp, 0x30
0000707b885db303  movaps [rsp], xmm9
0000707b885db308  movaps [rsp+0x10], xmm13
0000707b885db30e  movaps [rsp+0x20], xmm15
0000707b885db314  lea rdi, [rsp]
0000707b885db318  mov esi, 0x00
0000707b885db31d  mov rax, 0x6471B35AC530
0000707b885db327  call rax
0000707b885db329  movaps xmm9, [rsp]
0000707b885db32e  add rsp, 0x30
0000707b885db332  vmovaps xmm0, [rsp]
0000707b885db337  vmovaps xmm1, [rsp+0x10]
0000707b885db33d  vmovaps xmm2, [rsp+0x20]
0000707b885db343  vmovaps xmm3, [rsp+0x30]
0000707b885db349  vmovaps xmm4, [rsp+0x40]
0000707b885db34f  vmovaps xmm5, [rsp+0x50]
0000707b885db355  vmovaps xmm6, [rsp+0x60]
0000707b885db35b  vmovaps xmm7, [rsp+0x70]
0000707b885db361  vmovaps xmm8, [rsp+0x80]
0000707b885db36a  vmovaps xmm10, [rsp+0x90]
0000707b885db373  vmovaps xmm11, [rsp+0xA0]
0000707b885db37c  vmovaps xmm12, [rsp+0xB0]
0000707b885db385  vmovaps xmm13, [rsp+0xC0]
0000707b885db38e  vmovaps xmm14, [rsp+0xD0]
0000707b885db397  vmovaps xmm15, [rsp+0xE0]
0000707b885db3a0  add rsp, 0xF0
0000707b885db3a7  pop r11
0000707b885db3a9  pop r10
0000707b885db3ab  pop r9
0000707b885db3ad  pop r8
0000707b885db3af  pop rsi
0000707b885db3b0  pop rdi
0000707b885db3b1  pop rdx
0000707b885db3b2  pop rcx
0000707b885db3b3  pop rax
0000707b885db3b4  add rsp, 0x08
0000707b885db3b8  jmp 0x0000707B885D662F
0000707b885db3bd  sub rsp, 0x08
0000707b885db3c1  push rax
0000707b885db3c2  push rcx
0000707b885db3c3  push rdx
0000707b885db3c4  push rdi
0000707b885db3c5  push rsi
0000707b885db3c6  push r8
0000707b885db3c8  push r9
0000707b885db3ca  push r10
0000707b885db3cc  push r11
0000707b885db3ce  sub rsp, 0xF0
0000707b885db3d5  vmovaps [rsp], xmm0
0000707b885db3da  vmovaps [rsp+0x10], xmm1
0000707b885db3e0  vmovaps [rsp+0x20], xmm2
0000707b885db3e6  vmovaps [rsp+0x30], xmm3
0000707b885db3ec  vmovaps [rsp+0x40], xmm4
0000707b885db3f2  vmovaps [rsp+0x50], xmm5
0000707b885db3f8  vmovaps [rsp+0x60], xmm6
0000707b885db3fe  vmovaps [rsp+0x70], xmm7
0000707b885db404  vmovaps [rsp+0x80], xmm8
0000707b885db40d  vmovaps [rsp+0x90], xmm9
0000707b885db416  vmovaps [rsp+0xA0], xmm10
0000707b885db41f  vmovaps [rsp+0xB0], xmm11
0000707b885db428  vmovaps [rsp+0xC0], xmm12
0000707b885db431  vmovaps [rsp+0xD0], xmm13
0000707b885db43a  vmovaps [rsp+0xE0], xmm14
0000707b885db443  sub rsp, 0x30
0000707b885db447  movaps [rsp], xmm15
0000707b885db44c  movaps [rsp+0x10], xmm11
0000707b885db452  movaps [rsp+0x20], xmm12
0000707b885db458  lea rdi, [rsp]
0000707b885db45c  mov esi, 0x00
0000707b885db461  mov rax, 0x6471B35AC530
0000707b885db46b  call rax
0000707b885db46d  movaps xmm15, [rsp]
0000707b885db472  add rsp, 0x30
0000707b885db476  vmovaps xmm0, [rsp]
0000707b885db47b  vmovaps xmm1, [rsp+0x10]
0000707b885db481  vmovaps xmm2, [rsp+0x20]
0000707b885db487  vmovaps xmm3, [rsp+0x30]
0000707b885db48d  vmovaps xmm4, [rsp+0x40]
0000707b885db493  vmovaps xmm5, [rsp+0x50]
0000707b885db499  vmovaps xmm6, [rsp+0x60]
0000707b885db49f  vmovaps xmm7, [rsp+0x70]
0000707b885db4a5  vmovaps xmm8, [rsp+0x80]
0000707b885db4ae  vmovaps xmm9, [rsp+0x90]
0000707b885db4b7  vmovaps xmm10, [rsp+0xA0]
0000707b885db4c0  vmovaps xmm11, [rsp+0xB0]
0000707b885db4c9  vmovaps xmm12, [rsp+0xC0]
0000707b885db4d2  vmovaps xmm13, [rsp+0xD0]
0000707b885db4db  vmovaps xmm14, [rsp+0xE0]
0000707b885db4e4  add rsp, 0xF0
0000707b885db4eb  pop r11
0000707b885db4ed  pop r10
0000707b885db4ef  pop r9
0000707b885db4f1  pop r8
0000707b885db4f3  pop rsi
0000707b885db4f4  pop rdi
0000707b885db4f5  pop rdx
0000707b885db4f6  pop rcx
0000707b885db4f7  pop rax
0000707b885db4f8  add rsp, 0x08
0000707b885db4fc  jmp 0x0000707B885D664A
0000707b885db501  sub rsp, 0x08
0000707b885db505  push rax
0000707b885db506  push rcx
0000707b885db507  push rdx
0000707b885db508  push rdi
0000707b885db509  push rsi
0000707b885db50a  push r8
0000707b885db50c  push r9
0000707b885db50e  push r10
0000707b885db510  push r11
0000707b885db512  sub rsp, 0xF0
0000707b885db519  vmovaps [rsp], xmm0
0000707b885db51e  vmovaps [rsp+0x10], xmm1
0000707b885db524  vmovaps [rsp+0x20], xmm2
0000707b885db52a  vmovaps [rsp+0x30], xmm3
0000707b885db530  vmovaps [rsp+0x40], xmm4
0000707b885db536  vmovaps [rsp+0x50], xmm5
0000707b885db53c  vmovaps [rsp+0x60], xmm6
0000707b885db542  vmovaps [rsp+0x70], xmm7
0000707b885db548  vmovaps [rsp+0x80], xmm8
0000707b885db551  vmovaps [rsp+0x90], xmm9
0000707b885db55a  vmovaps [rsp+0xA0], xmm10
0000707b885db563  vmovaps [rsp+0xB0], xmm11
0000707b885db56c  vmovaps [rsp+0xC0], xmm12
0000707b885db575  vmovaps [rsp+0xD0], xmm14
0000707b885db57e  vmovaps [rsp+0xE0], xmm15
0000707b885db587  sub rsp, 0x30
0000707b885db58b  movaps [rsp], xmm13
0000707b885db590  movaps [rsp+0x10], xmm10
0000707b885db596  movaps [rsp+0x20], xmm14
0000707b885db59c  lea rdi, [rsp]
0000707b885db5a0  mov esi, 0x00
0000707b885db5a5  mov rax, 0x6471B35AC530
0000707b885db5af  call rax
0000707b885db5b1  movaps xmm13, [rsp]
0000707b885db5b6  add rsp, 0x30
0000707b885db5ba  vmovaps xmm0, [rsp]
0000707b885db5bf  vmovaps xmm1, [rsp+0x10]
0000707b885db5c5  vmovaps xmm2, [rsp+0x20]
0000707b885db5cb  vmovaps xmm3, [rsp+0x30]
0000707b885db5d1  vmovaps xmm4, [rsp+0x40]
0000707b885db5d7  vmovaps xmm5, [rsp+0x50]
0000707b885db5dd  vmovaps xmm6, [rsp+0x60]
0000707b885db5e3  vmovaps xmm7, [rsp+0x70]
0000707b885db5e9  vmovaps xmm8, [rsp+0x80]
0000707b885db5f2  vmovaps xmm9, [rsp+0x90]
0000707b885db5fb  vmovaps xmm10, [rsp+0xA0]
0000707b885db604  vmovaps xmm11, [rsp+0xB0]
0000707b885db60d  vmovaps xmm12, [rsp+0xC0]
0000707b885db616  vmovaps xmm14, [rsp+0xD0]
0000707b885db61f  vmovaps xmm15, [rsp+0xE0]
0000707b885db628  add rsp, 0xF0
0000707b885db62f  pop r11
0000707b885db631  pop r10
0000707b885db633  pop r9
0000707b885db635  pop r8
0000707b885db637  pop rsi
0000707b885db638  pop rdi
0000707b885db639  pop rdx
0000707b885db63a  pop rcx
0000707b885db63b  pop rax
0000707b885db63c  add rsp, 0x08
0000707b885db640  jmp 0x0000707B885D666D
0000707b885db645  sub rsp, 0x08
0000707b885db649  push rax
0000707b885db64a  push rcx
0000707b885db64b  push rdx
0000707b885db64c  push rdi
0000707b885db64d  push rsi
0000707b885db64e  push r8
0000707b885db650  push r9
0000707b885db652  push r10
0000707b885db654  push r11
0000707b885db656  sub rsp, 0xF0
0000707b885db65d  vmovaps [rsp], xmm0
0000707b885db662  vmovaps [rsp+0x10], xmm1
0000707b885db668  vmovaps [rsp+0x20], xmm2
0000707b885db66e  vmovaps [rsp+0x30], xmm3
0000707b885db674  vmovaps [rsp+0x40], xmm4
0000707b885db67a  vmovaps [rsp+0x50], xmm5
0000707b885db680  vmovaps [rsp+0x60], xmm6
0000707b885db686  vmovaps [rsp+0x70], xmm7
0000707b885db68c  vmovaps [rsp+0x80], xmm8
0000707b885db695  vmovaps [rsp+0x90], xmm9
0000707b885db69e  vmovaps [rsp+0xA0], xmm10
0000707b885db6a7  vmovaps [rsp+0xB0], xmm11
0000707b885db6b0  vmovaps [rsp+0xC0], xmm12
0000707b885db6b9  vmovaps [rsp+0xD0], xmm13
0000707b885db6c2  vmovaps [rsp+0xE0], xmm15
0000707b885db6cb  sub rsp, 0x30
0000707b885db6cf  movaps [rsp], xmm14
0000707b885db6d4  movaps [rsp+0x10], xmm1
0000707b885db6d9  movaps [rsp+0x20], xmm7
0000707b885db6de  lea rdi, [rsp]
0000707b885db6e2  mov esi, 0x00
0000707b885db6e7  mov rax, 0x6471B35AC530
0000707b885db6f1  call rax
0000707b885db6f3  movaps xmm14, [rsp]
0000707b885db6f8  add rsp, 0x30
0000707b885db6fc  vmovaps xmm0, [rsp]
0000707b885db701  vmovaps xmm1, [rsp+0x10]
0000707b885db707  vmovaps xmm2, [rsp+0x20]
0000707b885db70d  vmovaps xmm3, [rsp+0x30]
0000707b885db713  vmovaps xmm4, [rsp+0x40]
0000707b885db719  vmovaps xmm5, [rsp+0x50]
0000707b885db71f  vmovaps xmm6, [rsp+0x60]
0000707b885db725  vmovaps xmm7, [rsp+0x70]
0000707b885db72b  vmovaps xmm8, [rsp+0x80]
0000707b885db734  vmovaps xmm9, [rsp+0x90]
0000707b885db73d  vmovaps xmm10, [rsp+0xA0]
0000707b885db746  vmovaps xmm11, [rsp+0xB0]
0000707b885db74f  vmovaps xmm12, [rsp+0xC0]
0000707b885db758  vmovaps xmm13, [rsp+0xD0]
0000707b885db761  vmovaps xmm15, [rsp+0xE0]
0000707b885db76a  add rsp, 0xF0
0000707b885db771  pop r11
0000707b885db773  pop r10
0000707b885db775  pop r9
0000707b885db777  pop r8
0000707b885db779  pop rsi
0000707b885db77a  pop rdi
0000707b885db77b  pop rdx
0000707b885db77c  pop rcx
0000707b885db77d  pop rax
0000707b885db77e  add rsp, 0x08
0000707b885db782  jmp 0x0000707B885D6690
0000707b885db787  sub rsp, 0x08
0000707b885db78b  push rax
0000707b885db78c  push rcx
0000707b885db78d  push rdx
0000707b885db78e  push rdi
0000707b885db78f  push rsi
0000707b885db790  push r8
0000707b885db792  push r9
0000707b885db794  push r10
0000707b885db796  push r11
0000707b885db798  sub rsp, 0xF0
0000707b885db79f  vmovaps [rsp], xmm0
0000707b885db7a4  vmovaps [rsp+0x10], xmm2
0000707b885db7aa  vmovaps [rsp+0x20], xmm3
0000707b885db7b0  vmovaps [rsp+0x30], xmm4
0000707b885db7b6  vmovaps [rsp+0x40], xmm5
0000707b885db7bc  vmovaps [rsp+0x50], xmm6
0000707b885db7c2  vmovaps [rsp+0x60], xmm7
0000707b885db7c8  vmovaps [rsp+0x70], xmm8
0000707b885db7ce  vmovaps [rsp+0x80], xmm9
0000707b885db7d7  vmovaps [rsp+0x90], xmm10
0000707b885db7e0  vmovaps [rsp+0xA0], xmm11
0000707b885db7e9  vmovaps [rsp+0xB0], xmm12
0000707b885db7f2  vmovaps [rsp+0xC0], xmm13
0000707b885db7fb  vmovaps [rsp+0xD0], xmm14
0000707b885db804  vmovaps [rsp+0xE0], xmm15
0000707b885db80d  sub rsp, 0x30
0000707b885db811  movaps [rsp], xmm1
0000707b885db815  movaps [rsp+0x10], xmm8
0000707b885db81b  movaps [rsp+0x20], xmm9
0000707b885db821  lea rdi, [rsp]
0000707b885db825  mov esi, 0x00
0000707b885db82a  mov rax, 0x6471B35AC530
0000707b885db834  call rax
0000707b885db836  movaps xmm1, [rsp]
0000707b885db83a  add rsp, 0x30
0000707b885db83e  vmovaps xmm0, [rsp]
0000707b885db843  vmovaps xmm2, [rsp+0x10]
0000707b885db849  vmovaps xmm3, [rsp+0x20]
0000707b885db84f  vmovaps xmm4, [rsp+0x30]
0000707b885db855  vmovaps xmm5, [rsp+0x40]
0000707b885db85b  vmovaps xmm6, [rsp+0x50]
0000707b885db861  vmovaps xmm7, [rsp+0x60]
0000707b885db867  vmovaps xmm8, [rsp+0x70]
0000707b885db86d  vmovaps xmm9, [rsp+0x80]
0000707b885db876  vmovaps xmm10, [rsp+0x90]
0000707b885db87f  vmovaps xmm11, [rsp+0xA0]
0000707b885db888  vmovaps xmm12, [rsp+0xB0]
0000707b885db891  vmovaps xmm13, [rsp+0xC0]
0000707b885db89a  vmovaps xmm14, [rsp+0xD0]
0000707b885db8a3  vmovaps xmm15, [rsp+0xE0]
0000707b885db8ac  add rsp, 0xF0
0000707b885db8b3  pop r11
0000707b885db8b5  pop r10
0000707b885db8b7  pop r9
0000707b885db8b9  pop r8
0000707b885db8bb  pop rsi
0000707b885db8bc  pop rdi
0000707b885db8bd  pop rdx
0000707b885db8be  pop rcx
0000707b885db8bf  pop rax
0000707b885db8c0  add rsp, 0x08
0000707b885db8c4  jmp 0x0000707B885D66B2
0000707b885db8c9  call 0x0000707B884B3E40
0000707b885db8ce  jmp 0x0000707B885D66C0
0000707b885db8d3  call 0x0000707B8840C380
0000707b885db8d8  jmp 0x0000707B885D66CA
0000707b885db8dd  call 0x0000707B8840D600
0000707b885db8e2  jmp 0x0000707B885D66D4
0000707b885db8e7  call 0x0000707B883FF540
0000707b885db8ec  jmp 0x0000707B885D66DE
0000707b885db8f1  int3
0000707b885db8f2  nop [rax+rax*1], ax
0000707b885db8fb  nop [rax+rax*1], eax
0000707b885db900  mov eax, [r15+0x48]
0000707b885db904  lea r14d, [eax+0x01]
0000707b885db909  mov [rsp+0x10], r14d
0000707b885db90e  mov r14d, r14d
0000707b885db911  mov [r15+0x48], r14
0000707b885db915  xor eax, eax
0000707b885db917  mov r14d, [rsp+0x10]
0000707b885db91c  cmp r14d, 0x1F4
0000707b885db923  cmc
0000707b885db924  lahf
0000707b885db925  seto al
0000707b885db928  mov [r15+0x108], eax
0000707b885db92f  mov eax, [r15+0x108]
0000707b885db936  sahf
0000707b885db937  jnz 0x0000707B885DB969
0000707b885db939  cmp dword ptr [r15+0x318], 0x00
0000707b885db941  jz 0x0000707B885E1AB0
0000707b885db947  nop [rax+rax*1], ax
0000707b885db950  nop [rax+rax*1], eax
0000707b885db958  mov eax, 0x410450
0000707b885db95d  mov [r15+0x100], rax
0000707b885db964  jmp 0x0000707B883FE110
0000707b885db969  cmp dword ptr [r15+0x318], 0x00
0000707b885db971  jz 0x0000707B885DB9A0
0000707b885db977  nop [rax+rax*1], ax
0000707b885db980  nop [rax+rax*1], eax
0000707b885db988  mov eax, 0x410274
0000707b885db98d  mov [r15+0x100], rax
0000707b885db994  jmp 0x0000707B883FE110
0000707b885db999  int3
0000707b885db99a  int3
0000707b885db99b  nop [rax+rax*1], eax
0000707b885db9a0  mov rax, [r15+0x40]
0000707b885db9a4  movaps xmm1, [r15+0x1D0]
0000707b885db9ac  vmovaps [rsp+0x10], xmm1
0000707b885db9b2  vmovaps xmm15, [rsp+0x10]
0000707b885db9b8  por xmm1, xmm15
0000707b885db9bd  movaps xmm14, [r15+0x1A0]
0000707b885db9c5  vmovaps [rsp+0x10], xmm14
0000707b885db9cb  vmovaps xmm13, [rsp+0x10]
0000707b885db9d1  por xmm14, xmm13
0000707b885db9d6  lea r14, [rax+0x30]
0000707b885db9da  mov r12, [r13+r14*1]
0000707b885db9df  lea r14, [rax+0x38]
0000707b885db9e3  mov r11, [r13+r14*1]
0000707b885db9e8  movq xmm13, r12
0000707b885db9ed  movq xmm12, r11
0000707b885db9f2  movq xmm13, xmm13
0000707b885db9f7  vmovaps [rsp+0x10], xmm13
0000707b885db9fd  movq xmm13, xmm13
0000707b885dba02  movaps [r15+0x130], xmm13
0000707b885dba0a  movq xmm12, xmm12
0000707b885dba0f  vmovaps [rsp+0x20], xmm12
0000707b885dba15  movq xmm12, xmm12
0000707b885dba1a  movaps [r15+0x280], xmm12
0000707b885dba22  movaps xmm13, [r15+0x270]
0000707b885dba2a  vmovaps [rsp+0x30], xmm13
0000707b885dba30  vmovaps xmm12, [rsp+0x30]
0000707b885dba36  por xmm13, xmm12
0000707b885dba3b  lea r14, [rax+0x20]
0000707b885dba3f  mov r12, [r13+r14*1]
0000707b885dba44  lea r14, [rax+0x28]
0000707b885dba48  mov r11, [r13+r14*1]
0000707b885dba4d  movq xmm12, r12
0000707b885dba52  movq xmm11, r11
0000707b885dba57  movq xmm12, xmm12
0000707b885dba5c  vmovaps [rsp+0x30], xmm12
0000707b885dba62  movq xmm12, xmm12
0000707b885dba67  movaps [r15+0x150], xmm12
0000707b885dba6f  movq xmm11, xmm11
0000707b885dba74  vmovaps [rsp+0x40], xmm11
0000707b885dba7a  movq xmm11, xmm11
0000707b885dba7f  movaps [r15+0x140], xmm11
0000707b885dba87  lea r14, [rax+0x10]
0000707b885dba8b  mov r12, [r13+r14*1]
0000707b885dba90  lea r14, [rax+0x18]
0000707b885dba94  mov r11, [r13+r14*1]
0000707b885dba99  movq xmm12, r12
0000707b885dba9e  movq xmm11, r11
0000707b885dbaa3  movq xmm12, xmm12
0000707b885dbaa8  vmovaps [rsp+0x50], xmm12
0000707b885dbaae  movq xmm12, xmm12
0000707b885dbab3  movaps [r15+0x170], xmm12
0000707b885dbabb  movq xmm11, xmm11
0000707b885dbac0  vmovaps [rsp+0x60], xmm11
0000707b885dbac6  movq xmm11, xmm11
0000707b885dbacb  movaps [r15+0x160], xmm11
0000707b885dbad3  mov r14, [r13+rax*1]
0000707b885dbad8  vmovq xmm12, r14
0000707b885dbadd  vpbroadcastq xmm12, xmm12
0000707b885dbae2  lea r14, [rax+0x08]
0000707b885dbae6  mov rax, [r13+r14*1]
0000707b885dbaeb  movq xmm11, rax
0000707b885dbaf0  movaps [r15+0x230], xmm11
0000707b885dbaf8  mov rax, [r15+0xF8]
0000707b885dbaff  lea r14, [rax+0x50]
0000707b885dbb03  movups xmm11, [r13+r14*1]
0000707b885dbb09  lea r14, [rax+0x60]
0000707b885dbb0d  movups xmm10, [r13+r14*1]
0000707b885dbb13  lea r14, [rax+0x30]
0000707b885dbb17  movups xmm9, [r13+r14*1]
0000707b885dbb1d  mov r14, [r15+0x50]
0000707b885dbb21  mov [r15+0x60], r14
0000707b885dbb25  mov qword ptr [r15+0x58], 0x40
0000707b885dbb2d  movaps xmm8, xmm12
0000707b885dbb31  mulpd xmm8, xmm15
0000707b885dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000707b885dbb3c  ptest xmm7, xmm7
0000707b885dbb41  jnz 0x0000707B885DC96A
0000707b885dbb47  movq xmm15, qword ptr [r15+0x230]
0000707b885dbb50  vmovaps [rsp+0x70], xmm15
0000707b885dbb56  vpermilpd xmm15, xmm15, 0x00
0000707b885dbb5c  movaps xmm7, xmm9
0000707b885dbb60  mulpd xmm7, xmm15
0000707b885dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000707b885dbb6a  ptest xmm6, xmm6
0000707b885dbb6f  jnz 0x0000707B885DCAAE
0000707b885dbb75  vxorps xmm15, xmm15, xmm15
0000707b885dbb7a  vpbroadcastq xmm15, xmm15
0000707b885dbb7f  movaps xmm9, xmm12
0000707b885dbb83  mulpd xmm9, xmm10
0000707b885dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000707b885dbb8e  ptest xmm6, xmm6
0000707b885dbb93  jnz 0x0000707B885DCBF0
0000707b885dbb99  movaps xmm10, xmm12
0000707b885dbb9d  mulpd xmm10, xmm11
0000707b885dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000707b885dbba8  ptest xmm6, xmm6
0000707b885dbbad  jnz 0x0000707B885DCD34
0000707b885dbbb3  movaps xmm11, [r15+0x1F0]
0000707b885dbbbb  movaps xmm6, xmm12
0000707b885dbbbf  mulpd xmm6, xmm11
0000707b885dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000707b885dbbc9  ptest xmm5, xmm5
0000707b885dbbce  jnz 0x0000707B885DCE78
0000707b885dbbd4  movaps xmm12, [r15+0x2A0]
0000707b885dbbdc  vmovaps [rsp+0x80], xmm12
0000707b885dbbe5  vmovaps xmm11, [rsp+0x80]
0000707b885dbbee  por xmm12, xmm11
0000707b885dbbf3  movaps xmm11, [r15+0x250]
0000707b885dbbfb  vmovaps [rsp+0x80], xmm11
0000707b885dbc04  vmovaps xmm5, [rsp+0x80]
0000707b885dbc0d  por xmm11, xmm5
0000707b885dbc12  vmovaps xmm4, [rsp+0x70]
0000707b885dbc18  vpermilpd xmm4, xmm4, 0x00
0000707b885dbc1e  movaps xmm3, xmm5
0000707b885dbc21  mulpd xmm3, xmm4
0000707b885dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000707b885dbc2a  ptest xmm2, xmm2
0000707b885dbc2f  jnz 0x0000707B885DCFBA
0000707b885dbc35  mov [rsp+0x80], rax
0000707b885dbc3d  xor eax, eax
0000707b885dbc3f  mov r12d, 0x40
0000707b885dbc45  mov r11d, 0x200
0000707b885dbc4b  cmp r12, r11
0000707b885dbc4e  cmc
0000707b885dbc4f  lahf
0000707b885dbc50  seto al
0000707b885dbc53  mov [r15+0x108], eax
0000707b885dbc5a  movaps xmm5, xmm8
0000707b885dbc5e  addpd xmm5, xmm15
0000707b885dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000707b885dbc68  ptest xmm4, xmm4
0000707b885dbc6d  jnz 0x0000707B885DD0FA
0000707b885dbc73  movaps xmm8, [r15+0x1B0]
0000707b885dbc7b  movaps xmm4, xmm9
0000707b885dbc7f  addpd xmm4, xmm8
0000707b885dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000707b885dbc89  ptest xmm2, xmm2
0000707b885dbc8e  jnz 0x0000707B885DD23C
0000707b885dbc94  movaps xmm9, xmm10
0000707b885dbc98  addpd xmm9, xmm8
0000707b885dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000707b885dbca3  ptest xmm2, xmm2
0000707b885dbca8  jnz 0x0000707B885DD37E
0000707b885dbcae  movaps xmm10, [r15+0x2F0]
0000707b885dbcb6  vmovaps [rsp+0x90], xmm10
0000707b885dbcbf  vmovaps xmm8, [rsp+0x90]
0000707b885dbcc8  por xmm10, xmm8
0000707b885dbccd  movaps xmm8, [r15+0x2E0]
0000707b885dbcd5  vmovaps [rsp+0x90], xmm8
0000707b885dbcde  vmovaps xmm2, [rsp+0x90]
0000707b885dbce7  por xmm8, xmm2
0000707b885dbcec  movaps xmm2, [r15+0x2D0]
0000707b885dbcf4  vmovaps [rsp+0x90], xmm2
0000707b885dbcfd  vmovaps [rsp+0xA0], xmm1
0000707b885dbd06  vmovaps xmm1, [rsp+0x90]
0000707b885dbd0f  por xmm2, xmm1
0000707b885dbd13  movaps xmm1, [r15+0x200]
0000707b885dbd1b  vmovaps [rsp+0x90], xmm1
0000707b885dbd24  vmovaps [rsp+0xB0], xmm15
0000707b885dbd2d  vmovaps xmm15, [rsp+0x90]
0000707b885dbd36  por xmm1, xmm15
0000707b885dbd3b  movaps xmm15, [r15+0x1C0]
0000707b885dbd43  vmovaps [rsp+0x90], xmm15
0000707b885dbd4c  vmovaps [rsp+0xC0], xmm1
0000707b885dbd55  vmovaps xmm1, [rsp+0x90]
0000707b885dbd5e  por xmm15, xmm1
0000707b885dbd63  movaps xmm1, [r15+0x190]
0000707b885dbd6b  vmovaps [rsp+0x90], xmm1
0000707b885dbd74  vmovaps [rsp+0xD0], xmm15
0000707b885dbd7d  vmovaps xmm15, [rsp+0x90]
0000707b885dbd86  por xmm1, xmm15
0000707b885dbd8b  movaps xmm15, [r15+0x300]
0000707b885dbd93  vmovaps [rsp+0x90], xmm15
0000707b885dbd9c  vmovaps [rsp+0xE0], xmm1
0000707b885dbda5  vmovaps xmm1, [rsp+0x90]
0000707b885dbdae  por xmm15, xmm1
0000707b885dbdb3  mov rax, [rsp+0x80]
0000707b885dbdbb  lea r12, [rax+0xA0]
0000707b885dbdc2  movups xmm1, [r13+r12*1]
0000707b885dbdc8  lea r12, [rax+0xB0]
0000707b885dbdcf  vmovaps [rsp+0x80], xmm1
0000707b885dbdd8  movups xmm1, [r13+r12*1]
0000707b885dbdde  vmovaps [rsp+0x90], xmm1
0000707b885dbde7  vmovaps [rsp+0xF0], xmm15
0000707b885dbdf0  vmovaps xmm15, [rsp+0xB0]
0000707b885dbdf9  vmovaps [rsp+0xB0], xmm14
0000707b885dbe02  movaps xmm1, xmm6
0000707b885dbe05  addpd xmm1, xmm15
0000707b885dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000707b885dbe0f  ptest xmm14, xmm14
0000707b885dbe15  jnz 0x0000707B885DD4D6
0000707b885dbe1b  lea r12, [rax+0xF0]
0000707b885dbe22  movups xmm15, [r13+r12*1]
0000707b885dbe28  movaps xmm14, xmm4
0000707b885dbe2c  addpd xmm14, xmm3
0000707b885dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000707b885dbe37  ptest xmm6, xmm6
0000707b885dbe3c  jnz 0x0000707B885DD621
0000707b885dbe42  movaps xmm6, xmm9
0000707b885dbe46  addpd xmm6, xmm7
0000707b885dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000707b885dbe4f  ptest xmm4, xmm4
0000707b885dbe54  jnz 0x0000707B885DD763
0000707b885dbe5a  vmovaps xmm9, [rsp+0x70]
0000707b885dbe60  vpermilpd xmm9, xmm9, 0x00
0000707b885dbe66  vmovaps xmm4, [rsp+0x90]
0000707b885dbe6f  movaps xmm7, xmm4
0000707b885dbe72  mulpd xmm7, xmm9
0000707b885dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000707b885dbe7c  ptest xmm3, xmm3
0000707b885dbe81  jnz 0x0000707B885DD8A4
0000707b885dbe87  vmovaps xmm9, [rsp+0x50]
0000707b885dbe8d  vpermilpd xmm9, xmm9, 0x00
0000707b885dbe93  movaps xmm4, xmm15
0000707b885dbe97  mulpd xmm4, xmm9
0000707b885dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000707b885dbea1  ptest xmm3, xmm3
0000707b885dbea6  jnz 0x0000707B885DD9E5
0000707b885dbeac  lea r12, [rax+0xE0]
0000707b885dbeb3  movups xmm15, [r13+r12*1]
0000707b885dbeb9  vmovaps xmm9, [rsp+0x70]
0000707b885dbebf  vpermilpd xmm9, xmm9, 0x00
0000707b885dbec5  vmovaps [rsp+0x70], xmm1
0000707b885dbecb  vmovaps xmm1, [rsp+0x80]
0000707b885dbed4  vmovaps [rsp+0x80], xmm15
0000707b885dbedd  movaps xmm3, xmm1
0000707b885dbee0  mulpd xmm3, xmm9
0000707b885dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000707b885dbeea  ptest xmm15, xmm15
0000707b885dbef0  jnz 0x0000707B885DDB31
0000707b885dbef6  vmovaps xmm1, [rsp+0xF0]
0000707b885dbeff  vmovaps xmm15, [rsp+0xF0]
0000707b885dbf08  por xmm1, xmm15
0000707b885dbf0d  movaps [r15+0x300], xmm1
0000707b885dbf15  vmovaps xmm15, [rsp+0xE0]
0000707b885dbf1e  vmovaps xmm9, [rsp+0xE0]
0000707b885dbf27  por xmm15, xmm9
0000707b885dbf2c  movaps [r15+0x190], xmm15
0000707b885dbf34  vmovaps xmm9, [rsp+0x50]
0000707b885dbf3a  vpermilpd xmm9, xmm9, 0x00
0000707b885dbf40  vmovaps [rsp+0x90], xmm1
0000707b885dbf49  vmovaps [rsp+0xE0], xmm15
0000707b885dbf52  vmovaps xmm15, [rsp+0x80]
0000707b885dbf5b  vmovaps [rsp+0x80], xmm14
0000707b885dbf64  movaps xmm1, xmm15
0000707b885dbf68  mulpd xmm1, xmm9
0000707b885dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000707b885dbf72  ptest xmm14, xmm14
0000707b885dbf78  jnz 0x0000707B885DDC72
0000707b885dbf7e  lea r12, [rax+0x90]
0000707b885dbf85  movups xmm15, [r13+r12*1]
0000707b885dbf8b  vmovaps xmm14, [rsp+0xD0]
0000707b885dbf94  vmovaps xmm9, [rsp+0xD0]
0000707b885dbf9d  por xmm14, xmm9
0000707b885dbfa2  movaps [r15+0x1C0], xmm14
0000707b885dbfaa  vmovaps xmm9, [rsp+0xC0]
0000707b885dbfb3  vmovaps [rsp+0xD0], xmm1
0000707b885dbfbc  vmovaps xmm1, [rsp+0xC0]
0000707b885dbfc5  por xmm9, xmm1
0000707b885dbfca  movaps [r15+0x200], xmm9
0000707b885dbfd2  vmovaps [rsp+0xC0], xmm2
0000707b885dbfdb  vmovaps xmm1, [rsp+0xC0]
0000707b885dbfe4  por xmm2, xmm1
0000707b885dbfe8  movaps [r15+0x2D0], xmm2
0000707b885dbff0  vmovaps [rsp+0xC0], xmm8
0000707b885dbff9  vmovaps xmm1, [rsp+0xC0]
0000707b885dc002  por xmm8, xmm1
0000707b885dc007  movaps [r15+0x2E0], xmm8
0000707b885dc00f  vmovaps [rsp+0xC0], xmm15
0000707b885dc018  movaps xmm1, xmm5
0000707b885dc01b  addpd xmm1, xmm7
0000707b885dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000707b885dc024  ptest xmm15, xmm15
0000707b885dc02a  jnz 0x0000707B885DDDBE
0000707b885dc030  vmovaps xmm15, [rsp+0x50]
0000707b885dc036  vpermilpd xmm15, xmm15, 0x00
0000707b885dc03c  vmovaps xmm5, [rsp+0xC0]
0000707b885dc045  vmovaps [rsp+0xC0], xmm1
0000707b885dc04e  movaps xmm7, xmm5
0000707b885dc051  mulpd xmm7, xmm15
0000707b885dc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000707b885dc05b  ptest xmm1, xmm1
0000707b885dc060  jnz 0x0000707B885DDEFE
0000707b885dc066  lea r12, [rax+0x80]
0000707b885dc06d  movups xmm1, [r13+r12*1]
0000707b885dc073  vmovaps xmm5, [rsp+0x70]
0000707b885dc079  vmovaps [rsp+0x70], xmm1
0000707b885dc07f  movaps xmm15, xmm5
0000707b885dc083  addpd xmm15, xmm3
0000707b885dc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000707b885dc08e  ptest xmm1, xmm1
0000707b885dc093  jnz 0x0000707B885DE049
0000707b885dc099  vmovaps xmm5, [rsp+0x80]
0000707b885dc0a2  movaps xmm1, xmm5
0000707b885dc0a5  addpd xmm1, xmm4
0000707b885dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000707b885dc0ae  ptest xmm3, xmm3
0000707b885dc0b3  jnz 0x0000707B885DE18B
0000707b885dc0b9  vmovaps [rsp+0x80], xmm10
0000707b885dc0c2  vmovaps xmm5, [rsp+0x80]
0000707b885dc0cb  por xmm10, xmm5
0000707b885dc0d0  movaps [r15+0x2F0], xmm10
0000707b885dc0d8  vmovaps xmm5, [rsp+0x50]
0000707b885dc0de  vpermilpd xmm5, xmm5, 0x00
0000707b885dc0e4  vmovaps xmm3, [rsp+0x70]
0000707b885dc0ea  vmovaps [rsp+0x50], xmm1
0000707b885dc0f0  movaps xmm4, xmm3
0000707b885dc0f3  mulpd xmm4, xmm5
0000707b885dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000707b885dc0fc  ptest xmm1, xmm1
0000707b885dc101  jnz 0x0000707B885DE2CB
0000707b885dc107  lea r12, [rax+0xD0]
0000707b885dc10e  movups xmm1, [r13+r12*1]
0000707b885dc114  vmovaps xmm3, [rsp+0xD0]
0000707b885dc11d  vmovaps [rsp+0x70], xmm1
0000707b885dc123  movaps xmm5, xmm6
0000707b885dc126  addpd xmm5, xmm3
0000707b885dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000707b885dc12f  ptest xmm1, xmm1
0000707b885dc134  jnz 0x0000707B885DE415
0000707b885dc13a  vmovaps xmm1, [rsp+0x60]
0000707b885dc140  vpermilpd xmm1, xmm1, 0x00
0000707b885dc146  movaps xmm6, xmm9
0000707b885dc14a  mulpd xmm6, xmm1
0000707b885dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000707b885dc153  ptest xmm3, xmm3
0000707b885dc158  jnz 0x0000707B885DE555
0000707b885dc15e  movaps [r15+0x260], xmm6
0000707b885dc166  vxorps xmm1, xmm1, xmm1
0000707b885dc16a  vpbroadcastq xmm1, xmm1
0000707b885dc16f  movaps [r15+0x1B0], xmm1
0000707b885dc177  vmovaps xmm1, [rsp+0x60]
0000707b885dc17d  vpermilpd xmm1, xmm1, 0x00
0000707b885dc183  vmovaps xmm3, [rsp+0x70]
0000707b885dc189  vmovaps [rsp+0x70], xmm15
0000707b885dc18f  movaps xmm9, xmm3
0000707b885dc193  mulpd xmm9, xmm1
0000707b885dc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000707b885dc19e  ptest xmm15, xmm15
0000707b885dc1a4  jnz 0x0000707B885DE696
0000707b885dc1aa  lea r12, [rax+0xC0]
0000707b885dc1b1  movups xmm1, [r13+r12*1]
0000707b885dc1b7  vmovaps xmm3, [rsp+0xC0]
0000707b885dc1c0  vmovaps [rsp+0x80], xmm1
0000707b885dc1c9  movaps xmm15, xmm3
0000707b885dc1cd  addpd xmm15, xmm7
0000707b885dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000707b885dc1d8  ptest xmm1, xmm1
0000707b885dc1dd  jnz 0x0000707B885DE7E2
0000707b885dc1e3  vmovaps [rsp+0xC0], xmm13
0000707b885dc1ec  vmovaps xmm1, [rsp+0xC0]
0000707b885dc1f5  por xmm13, xmm1
0000707b885dc1fa  movaps [r15+0x270], xmm13
0000707b885dc202  vmovaps xmm1, [rsp+0xB0]
0000707b885dc20b  vmovaps xmm7, [rsp+0xB0]
0000707b885dc214  por xmm1, xmm7
0000707b885dc218  movaps [r15+0x1A0], xmm1
0000707b885dc220  vmovaps xmm1, [rsp+0x60]
0000707b885dc226  vpermilpd xmm1, xmm1, 0x00
0000707b885dc22c  vmovaps [rsp+0xB0], xmm1
0000707b885dc235  vmovaps xmm1, [rsp+0x80]
0000707b885dc23e  vmovaps [rsp+0x80], xmm15
0000707b885dc247  vmovaps xmm15, [rsp+0xB0]
0000707b885dc250  vmovaps [rsp+0xB0], xmm14
0000707b885dc259  movaps xmm3, xmm1
0000707b885dc25c  mulpd xmm3, xmm15
0000707b885dc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000707b885dc266  ptest xmm14, xmm14
0000707b885dc26c  jnz 0x0000707B885DE924
0000707b885dc272  lea r12, [rax+0x20]
0000707b885dc276  movups xmm1, [r13+r12*1]
0000707b885dc27c  movaps [r15+0x110], xmm1
0000707b885dc284  vmovaps xmm14, [rsp+0x70]
0000707b885dc28a  vmovaps [rsp+0x70], xmm1
0000707b885dc290  movaps xmm15, xmm14
0000707b885dc294  addpd xmm15, xmm4
0000707b885dc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000707b885dc29f  ptest xmm1, xmm1
0000707b885dc2a4  jnz 0x0000707B885DEA6F
0000707b885dc2aa  vmovaps xmm1, [rsp+0x60]
0000707b885dc2b0  vpermilpd xmm1, xmm1, 0x00
0000707b885dc2b6  movaps xmm14, xmm2
0000707b885dc2ba  mulpd xmm14, xmm1
0000707b885dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000707b885dc2c5  ptest xmm4, xmm4
0000707b885dc2ca  jnz 0x0000707B885DEBB2
0000707b885dc2d0  vmovaps xmm4, [rsp+0x50]
0000707b885dc2d6  movaps xmm1, xmm4
0000707b885dc2d9  addpd xmm1, xmm9
0000707b885dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000707b885dc2e3  ptest xmm2, xmm2
0000707b885dc2e8  jnz 0x0000707B885DECF4
0000707b885dc2ee  vmovaps xmm9, [rsp+0x30]
0000707b885dc2f4  vpermilpd xmm9, xmm9, 0x00
0000707b885dc2fa  vmovaps xmm2, [rsp+0x70]
0000707b885dc300  vmovaps [rsp+0x50], xmm1
0000707b885dc306  movaps xmm4, xmm2
0000707b885dc309  mulpd xmm4, xmm9
0000707b885dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000707b885dc313  ptest xmm1, xmm1
0000707b885dc318  jnz 0x0000707B885DEE35
0000707b885dc31e  vmovaps xmm1, [rsp+0x30]
0000707b885dc324  vpermilpd xmm1, xmm1, 0x00
0000707b885dc32a  vmovaps xmm2, [rsp+0x90]
0000707b885dc333  vmovaps [rsp+0x60], xmm15
0000707b885dc339  movaps xmm9, xmm2
0000707b885dc33d  mulpd xmm9, xmm1
0000707b885dc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000707b885dc348  ptest xmm15, xmm15
0000707b885dc34e  jnz 0x0000707B885DEF76
0000707b885dc354  vmovaps xmm15, [rsp+0x80]
0000707b885dc35d  movaps xmm1, xmm15
0000707b885dc361  addpd xmm1, xmm6
0000707b885dc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000707b885dc36a  ptest xmm2, xmm2
0000707b885dc36f  jnz 0x0000707B885DF0B8
0000707b885dc375  movaps xmm15, xmm5
0000707b885dc379  addpd xmm15, xmm3
0000707b885dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000707b885dc384  ptest xmm6, xmm6
0000707b885dc389  jnz 0x0000707B885DF1F9
0000707b885dc38f  vmovaps xmm6, [rsp+0x30]
0000707b885dc395  vpermilpd xmm6, xmm6, 0x00
0000707b885dc39b  movaps xmm5, xmm8
0000707b885dc39f  mulpd xmm5, xmm6
0000707b885dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000707b885dc3a8  ptest xmm3, xmm3
0000707b885dc3ad  jnz 0x0000707B885DF33B
0000707b885dc3b3  vmovaps xmm8, [rsp+0x30]
0000707b885dc3b9  vpermilpd xmm8, xmm8, 0x00
0000707b885dc3bf  movaps xmm6, xmm10
0000707b885dc3c3  mulpd xmm6, xmm8
0000707b885dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000707b885dc3cd  ptest xmm3, xmm3
0000707b885dc3d2  jnz 0x0000707B885DF47C
0000707b885dc3d8  vmovaps xmm8, [rsp+0x60]
0000707b885dc3de  movaps xmm10, xmm8
0000707b885dc3e2  addpd xmm10, xmm14
0000707b885dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000707b885dc3ed  ptest xmm3, xmm3
0000707b885dc3f2  jnz 0x0000707B885DF5BE
0000707b885dc3f8  vmovaps xmm8, [rsp+0x50]
0000707b885dc3fe  movaps xmm14, xmm8
0000707b885dc402  addpd xmm14, xmm4
0000707b885dc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000707b885dc40d  ptest xmm3, xmm3
0000707b885dc412  jnz 0x0000707B885DF702
0000707b885dc418  vmovaps xmm8, [rsp+0x40]
0000707b885dc41e  vpermilpd xmm8, xmm8, 0x00
0000707b885dc424  movaps xmm4, xmm13
0000707b885dc428  mulpd xmm4, xmm8
0000707b885dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000707b885dc432  ptest xmm3, xmm3
0000707b885dc437  jnz 0x0000707B885DF845
0000707b885dc43d  movaps xmm13, xmm15
0000707b885dc441  addpd xmm13, xmm9
0000707b885dc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000707b885dc44c  ptest xmm8, xmm8
0000707b885dc452  jnz 0x0000707B885DF987
0000707b885dc458  movaps xmm15, xmm1
0000707b885dc45c  addpd xmm15, xmm5
0000707b885dc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000707b885dc467  ptest xmm9, xmm9
0000707b885dc46d  jnz 0x0000707B885DFACB
0000707b885dc473  vmovaps [rsp+0x30], xmm11
0000707b885dc479  vmovaps xmm1, [rsp+0x30]
0000707b885dc47f  por xmm11, xmm1
0000707b885dc484  movaps [r15+0x250], xmm11
0000707b885dc48c  vmovaps [rsp+0x30], xmm12
0000707b885dc492  vmovaps xmm1, [rsp+0x30]
0000707b885dc498  por xmm12, xmm1
0000707b885dc49d  movaps [r15+0x2A0], xmm12
0000707b885dc4a5  vmovaps xmm1, [rsp+0xA0]
0000707b885dc4ae  vmovaps xmm11, [rsp+0xA0]
0000707b885dc4b7  por xmm1, xmm11
0000707b885dc4bc  movaps [r15+0x1D0], xmm1
0000707b885dc4c4  lea r12, [rax+0x40]
0000707b885dc4c8  movups xmm1, [r13+r12*1]
0000707b885dc4ce  movaps [r15+0x2C0], xmm1
0000707b885dc4d6  vmovaps xmm11, [rsp+0x40]
0000707b885dc4dc  vpermilpd xmm11, xmm11, 0x00
0000707b885dc4e2  vmovaps xmm8, [rsp+0xE0]
0000707b885dc4eb  movaps xmm9, xmm8
0000707b885dc4ef  mulpd xmm9, xmm11
0000707b885dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000707b885dc4fa  ptest xmm5, xmm5
0000707b885dc4ff  jnz 0x0000707B885DFC17
0000707b885dc505  movaps xmm11, xmm10
0000707b885dc509  addpd xmm11, xmm6
0000707b885dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000707b885dc514  ptest xmm8, xmm8
0000707b885dc51a  jnz 0x0000707B885DFD5B
0000707b885dc520  movaps xmm10, xmm14
0000707b885dc524  addpd xmm10, xmm4
0000707b885dc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000707b885dc52f  ptest xmm8, xmm8
0000707b885dc535  jnz 0x0000707B885DFE9E
0000707b885dc53b  vmovaps xmm14, [rsp+0x40]
0000707b885dc541  vpermilpd xmm14, xmm14, 0x00
0000707b885dc547  movaps xmm8, xmm1
0000707b885dc54b  mulpd xmm8, xmm14
0000707b885dc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000707b885dc556  ptest xmm6, xmm6
0000707b885dc55b  jnz 0x0000707B885DFFE1
0000707b885dc561  movaps xmm1, [r15+0x2B0]
0000707b885dc569  vmovaps xmm14, [rsp+0x40]
0000707b885dc56f  vpermilpd xmm14, xmm14, 0x00
0000707b885dc575  movaps xmm6, xmm1
0000707b885dc578  mulpd xmm6, xmm14
0000707b885dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000707b885dc582  ptest xmm5, xmm5
0000707b885dc587  jnz 0x0000707B885E0124
0000707b885dc58d  vmovaps xmm1, [rsp+0x10]
0000707b885dc593  vpermilpd xmm1, xmm1, 0x00
0000707b885dc599  movaps xmm14, xmm12
0000707b885dc59d  mulpd xmm14, xmm1
0000707b885dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000707b885dc5a8  ptest xmm5, xmm5
0000707b885dc5ad  jnz 0x0000707B885E0265
0000707b885dc5b3  movaps xmm1, xmm13
0000707b885dc5b7  addpd xmm1, xmm9
0000707b885dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000707b885dc5c1  ptest xmm12, xmm12
0000707b885dc5c7  jnz 0x0000707B885E03A8
0000707b885dc5cd  vmovaps xmm13, [rsp+0x10]
0000707b885dc5d3  vpermilpd xmm13, xmm13, 0x00
0000707b885dc5d9  movaps xmm12, xmm7
0000707b885dc5dd  mulpd xmm12, xmm13
0000707b885dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000707b885dc5e8  ptest xmm9, xmm9
0000707b885dc5ee  jnz 0x0000707B885E04EA
0000707b885dc5f4  movaps xmm13, xmm15
0000707b885dc5f8  addpd xmm13, xmm8
0000707b885dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000707b885dc603  ptest xmm9, xmm9
0000707b885dc609  jnz 0x0000707B885E062D
0000707b885dc60f  movaps xmm15, [r15+0x290]
0000707b885dc617  vmovaps xmm9, [rsp+0x10]
0000707b885dc61d  vpermilpd xmm9, xmm9, 0x00
0000707b885dc623  movaps xmm8, xmm15
0000707b885dc627  mulpd xmm8, xmm9
0000707b885dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000707b885dc632  ptest xmm7, xmm7
0000707b885dc637  jnz 0x0000707B885E0771
0000707b885dc63d  movaps xmm15, xmm11
0000707b885dc641  addpd xmm15, xmm6
0000707b885dc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000707b885dc64c  ptest xmm9, xmm9
0000707b885dc652  jnz 0x0000707B885E08B5
0000707b885dc658  movaps xmm11, [r15+0x1E0]
0000707b885dc660  vmovaps xmm9, [rsp+0x10]
0000707b885dc666  vpermilpd xmm9, xmm9, 0x00
0000707b885dc66c  movaps xmm7, xmm11
0000707b885dc670  mulpd xmm7, xmm9
0000707b885dc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000707b885dc67a  ptest xmm6, xmm6
0000707b885dc67f  jnz 0x0000707B885E09F8
0000707b885dc685  movaps xmm11, xmm10
0000707b885dc689  addpd xmm11, xmm14
0000707b885dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000707b885dc694  ptest xmm9, xmm9
0000707b885dc69a  jnz 0x0000707B885E0B3A
0000707b885dc6a0  lea r12, [rax+0x70]
0000707b885dc6a4  movups xmm14, [r13+r12*1]
0000707b885dc6aa  movaps [r15+0x240], xmm14
0000707b885dc6b2  movaps xmm10, xmm1
0000707b885dc6b6  addpd xmm10, xmm12
0000707b885dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000707b885dc6c1  ptest xmm9, xmm9
0000707b885dc6c7  jnz 0x0000707B885E0C88
0000707b885dc6cd  movaps [r15+0x170], xmm10
0000707b885dc6d5  vmovaps xmm1, [rsp+0x20]
0000707b885dc6db  vpermilpd xmm1, xmm1, 0x00
0000707b885dc6e1  movaps xmm12, xmm14
0000707b885dc6e5  mulpd xmm12, xmm1
0000707b885dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000707b885dc6f0  ptest xmm9, xmm9
0000707b885dc6f6  jnz 0x0000707B885E0DCB
0000707b885dc6fc  vmovaps xmm1, [rsp+0x20]
0000707b885dc702  vpermilpd xmm1, xmm1, 0x00
0000707b885dc708  vmovaps xmm9, [rsp+0xB0]
0000707b885dc711  movaps xmm14, xmm9
0000707b885dc715  mulpd xmm14, xmm1
0000707b885dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000707b885dc720  ptest xmm6, xmm6
0000707b885dc725  jnz 0x0000707B885E0F0E
0000707b885dc72b  movaps [r15+0x180], xmm14
0000707b885dc733  movaps xmm1, xmm13
0000707b885dc737  addpd xmm1, xmm8
0000707b885dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000707b885dc741  ptest xmm9, xmm9
0000707b885dc747  jnz 0x0000707B885E1051
0000707b885dc74d  movaps [r15+0x210], xmm1
0000707b885dc755  movups xmm13, [r13+rax*1]
0000707b885dc75b  lea r12, [rax+0x10]
0000707b885dc75f  movups xmm9, [r13+r12*1]
0000707b885dc765  movaps [r15+0x230], xmm9
0000707b885dc76d  movaps xmm8, xmm15
0000707b885dc771  addpd xmm8, xmm7
0000707b885dc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000707b885dc77c  ptest xmm6, xmm6
0000707b885dc781  jnz 0x0000707B885E11A7
0000707b885dc787  movaps [r15+0x130], xmm8
0000707b885dc78f  vmovaps xmm15, [rsp+0x20]
0000707b885dc795  vpermilpd xmm15, xmm15, 0x00
0000707b885dc79b  movaps xmm7, xmm9
0000707b885dc79f  mulpd xmm7, xmm15
0000707b885dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000707b885dc7a9  ptest xmm6, xmm6
0000707b885dc7ae  jnz 0x0000707B885E12EA
0000707b885dc7b4  movaps [r15+0x220], xmm7
0000707b885dc7bc  vmovaps xmm15, [rsp+0x20]
0000707b885dc7c2  vpermilpd xmm15, xmm15, 0x00
0000707b885dc7c8  movaps xmm9, xmm13
0000707b885dc7cc  mulpd xmm9, xmm15
0000707b885dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000707b885dc7d7  ptest xmm6, xmm6
0000707b885dc7dc  jnz 0x0000707B885E142C
0000707b885dc7e2  movaps xmm15, xmm11
0000707b885dc7e6  addpd xmm15, xmm12
0000707b885dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000707b885dc7f1  ptest xmm13, xmm13
0000707b885dc7f7  jnz 0x0000707B885E1570
0000707b885dc7fd  movaps [r15+0x140], xmm15
0000707b885dc805  movaps xmm13, xmm10
0000707b885dc809  addpd xmm13, xmm14
0000707b885dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000707b885dc814  ptest xmm12, xmm12
0000707b885dc81a  jnz 0x0000707B885E16B4
0000707b885dc820  movaps [r15+0x150], xmm13
0000707b885dc828  movaps xmm14, xmm1
0000707b885dc82c  addpd xmm14, xmm7
0000707b885dc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000707b885dc837  ptest xmm12, xmm12
0000707b885dc83d  jnz 0x0000707B885E17F8
0000707b885dc843  movaps [r15+0x160], xmm14
0000707b885dc84b  movaps xmm1, xmm8
0000707b885dc84f  addpd xmm1, xmm9
0000707b885dc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000707b885dc859  ptest xmm12, xmm12
0000707b885dc85f  jnz 0x0000707B885E193A
0000707b885dc865  movaps [r15+0x120], xmm1
0000707b885dc86d  movups [r13+r14*1], xmm15
0000707b885dc873  lea rax, [r14+0x10]
0000707b885dc877  movups [r13+rax*1], xmm13
0000707b885dc87d  lea rax, [r14+0x20]
0000707b885dc881  movups [r13+rax*1], xmm14
0000707b885dc887  lea rax, [r14+0x30]
0000707b885dc88b  movups [r13+rax*1], xmm1
0000707b885dc891  mov eax, [r15+0x108]
0000707b885dc898  sahf
0000707b885dc899  jnz 0x0000707B885DC8CB
0000707b885dc89b  cmp dword ptr [r15+0x318], 0x00
0000707b885dc8a3  jz 0x0000707B885DB900
0000707b885dc8a9  nop [rax+rax*1], ax
0000707b885dc8b2  nop [rax+rax*1], eax
0000707b885dc8ba  mov eax, 0x410444
0000707b885dc8bf  mov [r15+0x100], rax
0000707b885dc8c6  jmp 0x0000707B883FE110
0000707b885dc8cb  cmp dword ptr [r15+0x318], 0x00
0000707b885dc8d3  jz 0x0000707B885D57E0
0000707b885dc8d9  nop [rax+rax*1], ax
0000707b885dc8e2  nop [rax+rax*1], eax
0000707b885dc8ea  mov eax, 0x410278
0000707b885dc8ef  mov [r15+0x100], rax
0000707b885dc8f6  jmp 0x0000707B883FE110
0000707b885dc8fb  int3
0000707b885dc8fc  call 0x0000707B884E27E0
0000707b885dc901  jmp 0x0000707B885DB9DF
0000707b885dc906  call 0x0000707B884E1570
0000707b885dc90b  jmp 0x0000707B885DB9E8
0000707b885dc910  call 0x0000707B884E27E0
0000707b885dc915  jmp 0x0000707B885DBA44
0000707b885dc91a  call 0x0000707B884E1570
0000707b885dc91f  jmp 0x0000707B885DBA4D
0000707b885dc924  call 0x0000707B884E27E0
0000707b885dc929  jmp 0x0000707B885DBA90
0000707b885dc92e  call 0x0000707B884E1570
0000707b885dc933  jmp 0x0000707B885DBA99
0000707b885dc938  call 0x0000707B8840DC20
0000707b885dc93d  jmp 0x0000707B885DBAD8
0000707b885dc942  call 0x0000707B884D59C0
0000707b885dc947  jmp 0x0000707B885DBAEB
0000707b885dc94c  call 0x0000707B884E0E30
0000707b885dc951  jmp 0x0000707B885DBB09
0000707b885dc956  call 0x0000707B884DFBC0
0000707b885dc95b  jmp 0x0000707B885DBB13
0000707b885dc960  call 0x0000707B884DE950
0000707b885dc965  jmp 0x0000707B885DBB1D
0000707b885dc96a  sub rsp, 0x08
0000707b885dc96e  push rax
0000707b885dc96f  push rcx
0000707b885dc970  push rdx
0000707b885dc971  push rdi
0000707b885dc972  push rsi
0000707b885dc973  push r8
0000707b885dc975  push r9
0000707b885dc977  push r10
0000707b885dc979  push r11
0000707b885dc97b  sub rsp, 0xF0
0000707b885dc982  vmovaps [rsp], xmm0
0000707b885dc987  vmovaps [rsp+0x10], xmm1
0000707b885dc98d  vmovaps [rsp+0x20], xmm2
0000707b885dc993  vmovaps [rsp+0x30], xmm3
0000707b885dc999  vmovaps [rsp+0x40], xmm4
0000707b885dc99f  vmovaps [rsp+0x50], xmm5
0000707b885dc9a5  vmovaps [rsp+0x60], xmm6
0000707b885dc9ab  vmovaps [rsp+0x70], xmm7
0000707b885dc9b1  vmovaps [rsp+0x80], xmm9
0000707b885dc9ba  vmovaps [rsp+0x90], xmm10
0000707b885dc9c3  vmovaps [rsp+0xA0], xmm11
0000707b885dc9cc  vmovaps [rsp+0xB0], xmm12
0000707b885dc9d5  vmovaps [rsp+0xC0], xmm13
0000707b885dc9de  vmovaps [rsp+0xD0], xmm14
0000707b885dc9e7  vmovaps [rsp+0xE0], xmm15
0000707b885dc9f0  sub rsp, 0x30
0000707b885dc9f4  movaps [rsp], xmm8
0000707b885dc9f9  movaps [rsp+0x10], xmm12
0000707b885dc9ff  movaps [rsp+0x20], xmm15
0000707b885dca05  lea rdi, [rsp]
0000707b885dca09  mov esi, 0x00
0000707b885dca0e  mov rax, 0x6471B35AC530
0000707b885dca18  call rax
0000707b885dca1a  movaps xmm8, [rsp]
0000707b885dca1f  add rsp, 0x30
0000707b885dca23  vmovaps xmm0, [rsp]
0000707b885dca28  vmovaps xmm1, [rsp+0x10]
0000707b885dca2e  vmovaps xmm2, [rsp+0x20]
0000707b885dca34  vmovaps xmm3, [rsp+0x30]
0000707b885dca3a  vmovaps xmm4, [rsp+0x40]
0000707b885dca40  vmovaps xmm5, [rsp+0x50]
0000707b885dca46  vmovaps xmm6, [rsp+0x60]
0000707b885dca4c  vmovaps xmm7, [rsp+0x70]
0000707b885dca52  vmovaps xmm9, [rsp+0x80]
0000707b885dca5b  vmovaps xmm10, [rsp+0x90]
0000707b885dca64  vmovaps xmm11, [rsp+0xA0]
0000707b885dca6d  vmovaps xmm12, [rsp+0xB0]
0000707b885dca76  vmovaps xmm13, [rsp+0xC0]
0000707b885dca7f  vmovaps xmm14, [rsp+0xD0]
0000707b885dca88  vmovaps xmm15, [rsp+0xE0]
0000707b885dca91  add rsp, 0xF0
0000707b885dca98  pop r11
0000707b885dca9a  pop r10
0000707b885dca9c  pop r9
0000707b885dca9e  pop r8
0000707b885dcaa0  pop rsi
0000707b885dcaa1  pop rdi
0000707b885dcaa2  pop rdx
0000707b885dcaa3  pop rcx
0000707b885dcaa4  pop rax
0000707b885dcaa5  add rsp, 0x08
0000707b885dcaa9  jmp 0x0000707B885DBB47
0000707b885dcaae  sub rsp, 0x08
0000707b885dcab2  push rax
0000707b885dcab3  push rcx
0000707b885dcab4  push rdx
0000707b885dcab5  push rdi
0000707b885dcab6  push rsi
0000707b885dcab7  push r8
0000707b885dcab9  push r9
0000707b885dcabb  push r10
0000707b885dcabd  push r11
0000707b885dcabf  sub rsp, 0xF0
0000707b885dcac6  vmovaps [rsp], xmm0
0000707b885dcacb  vmovaps [rsp+0x10], xmm1
0000707b885dcad1  vmovaps [rsp+0x20], xmm2
0000707b885dcad7  vmovaps [rsp+0x30], xmm3
0000707b885dcadd  vmovaps [rsp+0x40], xmm4
0000707b885dcae3  vmovaps [rsp+0x50], xmm5
0000707b885dcae9  vmovaps [rsp+0x60], xmm6
0000707b885dcaef  vmovaps [rsp+0x70], xmm8
0000707b885dcaf5  vmovaps [rsp+0x80], xmm9
0000707b885dcafe  vmovaps [rsp+0x90], xmm10
0000707b885dcb07  vmovaps [rsp+0xA0], xmm11
0000707b885dcb10  vmovaps [rsp+0xB0], xmm12
0000707b885dcb19  vmovaps [rsp+0xC0], xmm13
0000707b885dcb22  vmovaps [rsp+0xD0], xmm14
0000707b885dcb2b  vmovaps [rsp+0xE0], xmm15
0000707b885dcb34  sub rsp, 0x30
0000707b885dcb38  movaps [rsp], xmm7
0000707b885dcb3c  movaps [rsp+0x10], xmm9
0000707b885dcb42  movaps [rsp+0x20], xmm15
0000707b885dcb48  lea rdi, [rsp]
0000707b885dcb4c  mov esi, 0x00
0000707b885dcb51  mov rax, 0x6471B35AC530
0000707b885dcb5b  call rax
0000707b885dcb5d  movaps xmm7, [rsp]
0000707b885dcb61  add rsp, 0x30
0000707b885dcb65  vmovaps xmm0, [rsp]
0000707b885dcb6a  vmovaps xmm1, [rsp+0x10]
0000707b885dcb70  vmovaps xmm2, [rsp+0x20]
0000707b885dcb76  vmovaps xmm3, [rsp+0x30]
0000707b885dcb7c  vmovaps xmm4, [rsp+0x40]
0000707b885dcb82  vmovaps xmm5, [rsp+0x50]
0000707b885dcb88  vmovaps xmm6, [rsp+0x60]
0000707b885dcb8e  vmovaps xmm8, [rsp+0x70]
0000707b885dcb94  vmovaps xmm9, [rsp+0x80]
0000707b885dcb9d  vmovaps xmm10, [rsp+0x90]
0000707b885dcba6  vmovaps xmm11, [rsp+0xA0]
0000707b885dcbaf  vmovaps xmm12, [rsp+0xB0]
0000707b885dcbb8  vmovaps xmm13, [rsp+0xC0]
0000707b885dcbc1  vmovaps xmm14, [rsp+0xD0]
0000707b885dcbca  vmovaps xmm15, [rsp+0xE0]
0000707b885dcbd3  add rsp, 0xF0
0000707b885dcbda  pop r11
0000707b885dcbdc  pop r10
0000707b885dcbde  pop r9
0000707b885dcbe0  pop r8
0000707b885dcbe2  pop rsi
0000707b885dcbe3  pop rdi
0000707b885dcbe4  pop rdx
0000707b885dcbe5  pop rcx
0000707b885dcbe6  pop rax
0000707b885dcbe7  add rsp, 0x08
0000707b885dcbeb  jmp 0x0000707B885DBB75
0000707b885dcbf0  sub rsp, 0x08
0000707b885dcbf4  push rax
0000707b885dcbf5  push rcx
0000707b885dcbf6  push rdx
0000707b885dcbf7  push rdi
0000707b885dcbf8  push rsi
0000707b885dcbf9  push r8
0000707b885dcbfb  push r9
0000707b885dcbfd  push r10
0000707b885dcbff  push r11
0000707b885dcc01  sub rsp, 0xF0
0000707b885dcc08  vmovaps [rsp], xmm0
0000707b885dcc0d  vmovaps [rsp+0x10], xmm1
0000707b885dcc13  vmovaps [rsp+0x20], xmm2
0000707b885dcc19  vmovaps [rsp+0x30], xmm3
0000707b885dcc1f  vmovaps [rsp+0x40], xmm4
0000707b885dcc25  vmovaps [rsp+0x50], xmm5
0000707b885dcc2b  vmovaps [rsp+0x60], xmm6
0000707b885dcc31  vmovaps [rsp+0x70], xmm7
0000707b885dcc37  vmovaps [rsp+0x80], xmm8
0000707b885dcc40  vmovaps [rsp+0x90], xmm10
0000707b885dcc49  vmovaps [rsp+0xA0], xmm11
0000707b885dcc52  vmovaps [rsp+0xB0], xmm12
0000707b885dcc5b  vmovaps [rsp+0xC0], xmm13
0000707b885dcc64  vmovaps [rsp+0xD0], xmm14
0000707b885dcc6d  vmovaps [rsp+0xE0], xmm15
0000707b885dcc76  sub rsp, 0x30
0000707b885dcc7a  movaps [rsp], xmm9
0000707b885dcc7f  movaps [rsp+0x10], xmm12
0000707b885dcc85  movaps [rsp+0x20], xmm10
0000707b885dcc8b  lea rdi, [rsp]
0000707b885dcc8f  mov esi, 0x00
0000707b885dcc94  mov rax, 0x6471B35AC530
0000707b885dcc9e  call rax
0000707b885dcca0  movaps xmm9, [rsp]
0000707b885dcca5  add rsp, 0x30
0000707b885dcca9  vmovaps xmm0, [rsp]
0000707b885dccae  vmovaps xmm1, [rsp+0x10]
0000707b885dccb4  vmovaps xmm2, [rsp+0x20]
0000707b885dccba  vmovaps xmm3, [rsp+0x30]
0000707b885dccc0  vmovaps xmm4, [rsp+0x40]
0000707b885dccc6  vmovaps xmm5, [rsp+0x50]
0000707b885dcccc  vmovaps xmm6, [rsp+0x60]
0000707b885dccd2  vmovaps xmm7, [rsp+0x70]
0000707b885dccd8  vmovaps xmm8, [rsp+0x80]
0000707b885dcce1  vmovaps xmm10, [rsp+0x90]
0000707b885dccea  vmovaps xmm11, [rsp+0xA0]
0000707b885dccf3  vmovaps xmm12, [rsp+0xB0]
0000707b885dccfc  vmovaps xmm13, [rsp+0xC0]
0000707b885dcd05  vmovaps xmm14, [rsp+0xD0]
0000707b885dcd0e  vmovaps xmm15, [rsp+0xE0]
0000707b885dcd17  add rsp, 0xF0
0000707b885dcd1e  pop r11
0000707b885dcd20  pop r10
0000707b885dcd22  pop r9
0000707b885dcd24  pop r8
0000707b885dcd26  pop rsi
0000707b885dcd27  pop rdi
0000707b885dcd28  pop rdx
0000707b885dcd29  pop rcx
0000707b885dcd2a  pop rax
0000707b885dcd2b  add rsp, 0x08
0000707b885dcd2f  jmp 0x0000707B885DBB99
0000707b885dcd34  sub rsp, 0x08
0000707b885dcd38  push rax
0000707b885dcd39  push rcx
0000707b885dcd3a  push rdx
0000707b885dcd3b  push rdi
0000707b885dcd3c  push rsi
0000707b885dcd3d  push r8
0000707b885dcd3f  push r9
0000707b885dcd41  push r10
0000707b885dcd43  push r11
0000707b885dcd45  sub rsp, 0xF0
0000707b885dcd4c  vmovaps [rsp], xmm0
0000707b885dcd51  vmovaps [rsp+0x10], xmm1
0000707b885dcd57  vmovaps [rsp+0x20], xmm2
0000707b885dcd5d  vmovaps [rsp+0x30], xmm3
0000707b885dcd63  vmovaps [rsp+0x40], xmm4
0000707b885dcd69  vmovaps [rsp+0x50], xmm5
0000707b885dcd6f  vmovaps [rsp+0x60], xmm6
0000707b885dcd75  vmovaps [rsp+0x70], xmm7
0000707b885dcd7b  vmovaps [rsp+0x80], xmm8
0000707b885dcd84  vmovaps [rsp+0x90], xmm9
0000707b885dcd8d  vmovaps [rsp+0xA0], xmm11
0000707b885dcd96  vmovaps [rsp+0xB0], xmm12
0000707b885dcd9f  vmovaps [rsp+0xC0], xmm13
0000707b885dcda8  vmovaps [rsp+0xD0], xmm14
0000707b885dcdb1  vmovaps [rsp+0xE0], xmm15
0000707b885dcdba  sub rsp, 0x30
0000707b885dcdbe  movaps [rsp], xmm10
0000707b885dcdc3  movaps [rsp+0x10], xmm12
0000707b885dcdc9  movaps [rsp+0x20], xmm11
0000707b885dcdcf  lea rdi, [rsp]
0000707b885dcdd3  mov esi, 0x00
0000707b885dcdd8  mov rax, 0x6471B35AC530
0000707b885dcde2  call rax
0000707b885dcde4  movaps xmm10, [rsp]
0000707b885dcde9  add rsp, 0x30
0000707b885dcded  vmovaps xmm0, [rsp]
0000707b885dcdf2  vmovaps xmm1, [rsp+0x10]
0000707b885dcdf8  vmovaps xmm2, [rsp+0x20]
0000707b885dcdfe  vmovaps xmm3, [rsp+0x30]
0000707b885dce04  vmovaps xmm4, [rsp+0x40]
0000707b885dce0a  vmovaps xmm5, [rsp+0x50]
0000707b885dce10  vmovaps xmm6, [rsp+0x60]
0000707b885dce16  vmovaps xmm7, [rsp+0x70]
0000707b885dce1c  vmovaps xmm8, [rsp+0x80]
0000707b885dce25  vmovaps xmm9, [rsp+0x90]
0000707b885dce2e  vmovaps xmm11, [rsp+0xA0]
0000707b885dce37  vmovaps xmm12, [rsp+0xB0]
0000707b885dce40  vmovaps xmm13, [rsp+0xC0]
0000707b885dce49  vmovaps xmm14, [rsp+0xD0]
0000707b885dce52  vmovaps xmm15, [rsp+0xE0]
0000707b885dce5b  add rsp, 0xF0
0000707b885dce62  pop r11
0000707b885dce64  pop r10
0000707b885dce66  pop r9
0000707b885dce68  pop r8
0000707b885dce6a  pop rsi
0000707b885dce6b  pop rdi
0000707b885dce6c  pop rdx
0000707b885dce6d  pop rcx
0000707b885dce6e  pop rax
0000707b885dce6f  add rsp, 0x08
0000707b885dce73  jmp 0x0000707B885DBBB3
0000707b885dce78  sub rsp, 0x08
0000707b885dce7c  push rax
0000707b885dce7d  push rcx
0000707b885dce7e  push rdx
0000707b885dce7f  push rdi
0000707b885dce80  push rsi
0000707b885dce81  push r8
0000707b885dce83  push r9
0000707b885dce85  push r10
0000707b885dce87  push r11
0000707b885dce89  sub rsp, 0xF0
0000707b885dce90  vmovaps [rsp], xmm0
0000707b885dce95  vmovaps [rsp+0x10], xmm1
0000707b885dce9b  vmovaps [rsp+0x20], xmm2
0000707b885dcea1  vmovaps [rsp+0x30], xmm3
0000707b885dcea7  vmovaps [rsp+0x40], xmm4
0000707b885dcead  vmovaps [rsp+0x50], xmm5
0000707b885dceb3  vmovaps [rsp+0x60], xmm7
0000707b885dceb9  vmovaps [rsp+0x70], xmm8
0000707b885dcebf  vmovaps [rsp+0x80], xmm9
0000707b885dcec8  vmovaps [rsp+0x90], xmm10
0000707b885dced1  vmovaps [rsp+0xA0], xmm11
0000707b885dceda  vmovaps [rsp+0xB0], xmm12
0000707b885dcee3  vmovaps [rsp+0xC0], xmm13
0000707b885dceec  vmovaps [rsp+0xD0], xmm14
0000707b885dcef5  vmovaps [rsp+0xE0], xmm15
0000707b885dcefe  sub rsp, 0x30
0000707b885dcf02  movaps [rsp], xmm6
0000707b885dcf06  movaps [rsp+0x10], xmm12
0000707b885dcf0c  movaps [rsp+0x20], xmm11
0000707b885dcf12  lea rdi, [rsp]
0000707b885dcf16  mov esi, 0x00
0000707b885dcf1b  mov rax, 0x6471B35AC530
0000707b885dcf25  call rax
0000707b885dcf27  movaps xmm6, [rsp]
0000707b885dcf2b  add rsp, 0x30
0000707b885dcf2f  vmovaps xmm0, [rsp]
0000707b885dcf34  vmovaps xmm1, [rsp+0x10]
0000707b885dcf3a  vmovaps xmm2, [rsp+0x20]
0000707b885dcf40  vmovaps xmm3, [rsp+0x30]
0000707b885dcf46  vmovaps xmm4, [rsp+0x40]
0000707b885dcf4c  vmovaps xmm5, [rsp+0x50]
0000707b885dcf52  vmovaps xmm7, [rsp+0x60]
0000707b885dcf58  vmovaps xmm8, [rsp+0x70]
0000707b885dcf5e  vmovaps xmm9, [rsp+0x80]
0000707b885dcf67  vmovaps xmm10, [rsp+0x90]
0000707b885dcf70  vmovaps xmm11, [rsp+0xA0]
0000707b885dcf79  vmovaps xmm12, [rsp+0xB0]
0000707b885dcf82  vmovaps xmm13, [rsp+0xC0]
0000707b885dcf8b  vmovaps xmm14, [rsp+0xD0]
0000707b885dcf94  vmovaps xmm15, [rsp+0xE0]
0000707b885dcf9d  add rsp, 0xF0
0000707b885dcfa4  pop r11
0000707b885dcfa6  pop r10
0000707b885dcfa8  pop r9
0000707b885dcfaa  pop r8
0000707b885dcfac  pop rsi
0000707b885dcfad  pop rdi
0000707b885dcfae  pop rdx
0000707b885dcfaf  pop rcx
0000707b885dcfb0  pop rax
0000707b885dcfb1  add rsp, 0x08
0000707b885dcfb5  jmp 0x0000707B885DBBD4
0000707b885dcfba  sub rsp, 0x08
0000707b885dcfbe  push rax
0000707b885dcfbf  push rcx
0000707b885dcfc0  push rdx
0000707b885dcfc1  push rdi
0000707b885dcfc2  push rsi
0000707b885dcfc3  push r8
0000707b885dcfc5  push r9
0000707b885dcfc7  push r10
0000707b885dcfc9  push r11
0000707b885dcfcb  sub rsp, 0xF0
0000707b885dcfd2  vmovaps [rsp], xmm0
0000707b885dcfd7  vmovaps [rsp+0x10], xmm1
0000707b885dcfdd  vmovaps [rsp+0x20], xmm2
0000707b885dcfe3  vmovaps [rsp+0x30], xmm4
0000707b885dcfe9  vmovaps [rsp+0x40], xmm5
0000707b885dcfef  vmovaps [rsp+0x50], xmm6
0000707b885dcff5  vmovaps [rsp+0x60], xmm7
0000707b885dcffb  vmovaps [rsp+0x70], xmm8
0000707b885dd001  vmovaps [rsp+0x80], xmm9
0000707b885dd00a  vmovaps [rsp+0x90], xmm10
0000707b885dd013  vmovaps [rsp+0xA0], xmm11
0000707b885dd01c  vmovaps [rsp+0xB0], xmm12
0000707b885dd025  vmovaps [rsp+0xC0], xmm13
0000707b885dd02e  vmovaps [rsp+0xD0], xmm14
0000707b885dd037  vmovaps [rsp+0xE0], xmm15
0000707b885dd040  sub rsp, 0x30
0000707b885dd044  movaps [rsp], xmm3
0000707b885dd048  movaps [rsp+0x10], xmm5
0000707b885dd04d  movaps [rsp+0x20], xmm4
0000707b885dd052  lea rdi, [rsp]
0000707b885dd056  mov esi, 0x00
0000707b885dd05b  mov rax, 0x6471B35AC530
0000707b885dd065  call rax
0000707b885dd067  movaps xmm3, [rsp]
0000707b885dd06b  add rsp, 0x30
0000707b885dd06f  vmovaps xmm0, [rsp]
0000707b885dd074  vmovaps xmm1, [rsp+0x10]
0000707b885dd07a  vmovaps xmm2, [rsp+0x20]
0000707b885dd080  vmovaps xmm4, [rsp+0x30]
0000707b885dd086  vmovaps xmm5, [rsp+0x40]
0000707b885dd08c  vmovaps xmm6, [rsp+0x50]
0000707b885dd092  vmovaps xmm7, [rsp+0x60]
0000707b885dd098  vmovaps xmm8, [rsp+0x70]
0000707b885dd09e  vmovaps xmm9, [rsp+0x80]
0000707b885dd0a7  vmovaps xmm10, [rsp+0x90]
0000707b885dd0b0  vmovaps xmm11, [rsp+0xA0]
0000707b885dd0b9  vmovaps xmm12, [rsp+0xB0]
0000707b885dd0c2  vmovaps xmm13, [rsp+0xC0]
0000707b885dd0cb  vmovaps xmm14, [rsp+0xD0]
0000707b885dd0d4  vmovaps xmm15, [rsp+0xE0]
0000707b885dd0dd  add rsp, 0xF0
0000707b885dd0e4  pop r11
0000707b885dd0e6  pop r10
0000707b885dd0e8  pop r9
0000707b885dd0ea  pop r8
0000707b885dd0ec  pop rsi
0000707b885dd0ed  pop rdi
0000707b885dd0ee  pop rdx
0000707b885dd0ef  pop rcx
0000707b885dd0f0  pop rax
0000707b885dd0f1  add rsp, 0x08
0000707b885dd0f5  jmp 0x0000707B885DBC35
0000707b885dd0fa  sub rsp, 0x08
0000707b885dd0fe  push rax
0000707b885dd0ff  push rcx
0000707b885dd100  push rdx
0000707b885dd101  push rdi
0000707b885dd102  push rsi
0000707b885dd103  push r8
0000707b885dd105  push r9
0000707b885dd107  push r10
0000707b885dd109  push r11
0000707b885dd10b  sub rsp, 0xF0
0000707b885dd112  vmovaps [rsp], xmm0
0000707b885dd117  vmovaps [rsp+0x10], xmm1
0000707b885dd11d  vmovaps [rsp+0x20], xmm2
0000707b885dd123  vmovaps [rsp+0x30], xmm3
0000707b885dd129  vmovaps [rsp+0x40], xmm4
0000707b885dd12f  vmovaps [rsp+0x50], xmm6
0000707b885dd135  vmovaps [rsp+0x60], xmm7
0000707b885dd13b  vmovaps [rsp+0x70], xmm8
0000707b885dd141  vmovaps [rsp+0x80], xmm9
0000707b885dd14a  vmovaps [rsp+0x90], xmm10
0000707b885dd153  vmovaps [rsp+0xA0], xmm11
0000707b885dd15c  vmovaps [rsp+0xB0], xmm12
0000707b885dd165  vmovaps [rsp+0xC0], xmm13
0000707b885dd16e  vmovaps [rsp+0xD0], xmm14
0000707b885dd177  vmovaps [rsp+0xE0], xmm15
0000707b885dd180  sub rsp, 0x30
0000707b885dd184  movaps [rsp], xmm5
0000707b885dd188  movaps [rsp+0x10], xmm8
0000707b885dd18e  movaps [rsp+0x20], xmm15
0000707b885dd194  lea rdi, [rsp]
0000707b885dd198  mov esi, 0x00
0000707b885dd19d  mov rax, 0x6471B35AC530
0000707b885dd1a7  call rax
0000707b885dd1a9  movaps xmm5, [rsp]
0000707b885dd1ad  add rsp, 0x30
0000707b885dd1b1  vmovaps xmm0, [rsp]
0000707b885dd1b6  vmovaps xmm1, [rsp+0x10]
0000707b885dd1bc  vmovaps xmm2, [rsp+0x20]
0000707b885dd1c2  vmovaps xmm3, [rsp+0x30]
0000707b885dd1c8  vmovaps xmm4, [rsp+0x40]
0000707b885dd1ce  vmovaps xmm6, [rsp+0x50]
0000707b885dd1d4  vmovaps xmm7, [rsp+0x60]
0000707b885dd1da  vmovaps xmm8, [rsp+0x70]
0000707b885dd1e0  vmovaps xmm9, [rsp+0x80]
0000707b885dd1e9  vmovaps xmm10, [rsp+0x90]
0000707b885dd1f2  vmovaps xmm11, [rsp+0xA0]
0000707b885dd1fb  vmovaps xmm12, [rsp+0xB0]
0000707b885dd204  vmovaps xmm13, [rsp+0xC0]
0000707b885dd20d  vmovaps xmm14, [rsp+0xD0]
0000707b885dd216  vmovaps xmm15, [rsp+0xE0]
0000707b885dd21f  add rsp, 0xF0
0000707b885dd226  pop r11
0000707b885dd228  pop r10
0000707b885dd22a  pop r9
0000707b885dd22c  pop r8
0000707b885dd22e  pop rsi
0000707b885dd22f  pop rdi
0000707b885dd230  pop rdx
0000707b885dd231  pop rcx
0000707b885dd232  pop rax
0000707b885dd233  add rsp, 0x08
0000707b885dd237  jmp 0x0000707B885DBC73
0000707b885dd23c  sub rsp, 0x08
0000707b885dd240  push rax
0000707b885dd241  push rcx
0000707b885dd242  push rdx
0000707b885dd243  push rdi
0000707b885dd244  push rsi
0000707b885dd245  push r8
0000707b885dd247  push r9
0000707b885dd249  push r10
0000707b885dd24b  push r11
0000707b885dd24d  sub rsp, 0xF0
0000707b885dd254  vmovaps [rsp], xmm0
0000707b885dd259  vmovaps [rsp+0x10], xmm1
0000707b885dd25f  vmovaps [rsp+0x20], xmm2
0000707b885dd265  vmovaps [rsp+0x30], xmm3
0000707b885dd26b  vmovaps [rsp+0x40], xmm5
0000707b885dd271  vmovaps [rsp+0x50], xmm6
0000707b885dd277  vmovaps [rsp+0x60], xmm7
0000707b885dd27d  vmovaps [rsp+0x70], xmm8
0000707b885dd283  vmovaps [rsp+0x80], xmm9
0000707b885dd28c  vmovaps [rsp+0x90], xmm10
0000707b885dd295  vmovaps [rsp+0xA0], xmm11
0000707b885dd29e  vmovaps [rsp+0xB0], xmm12
0000707b885dd2a7  vmovaps [rsp+0xC0], xmm13
0000707b885dd2b0  vmovaps [rsp+0xD0], xmm14
0000707b885dd2b9  vmovaps [rsp+0xE0], xmm15
0000707b885dd2c2  sub rsp, 0x30
0000707b885dd2c6  movaps [rsp], xmm4
0000707b885dd2ca  movaps [rsp+0x10], xmm9
0000707b885dd2d0  movaps [rsp+0x20], xmm8
0000707b885dd2d6  lea rdi, [rsp]
0000707b885dd2da  mov esi, 0x00
0000707b885dd2df  mov rax, 0x6471B35AC530
0000707b885dd2e9  call rax
0000707b885dd2eb  movaps xmm4, [rsp]
0000707b885dd2ef  add rsp, 0x30
0000707b885dd2f3  vmovaps xmm0, [rsp]
0000707b885dd2f8  vmovaps xmm1, [rsp+0x10]
0000707b885dd2fe  vmovaps xmm2, [rsp+0x20]
0000707b885dd304  vmovaps xmm3, [rsp+0x30]
0000707b885dd30a  vmovaps xmm5, [rsp+0x40]
0000707b885dd310  vmovaps xmm6, [rsp+0x50]
0000707b885dd316  vmovaps xmm7, [rsp+0x60]
0000707b885dd31c  vmovaps xmm8, [rsp+0x70]
0000707b885dd322  vmovaps xmm9, [rsp+0x80]
0000707b885dd32b  vmovaps xmm10, [rsp+0x90]
0000707b885dd334  vmovaps xmm11, [rsp+0xA0]
0000707b885dd33d  vmovaps xmm12, [rsp+0xB0]
0000707b885dd346  vmovaps xmm13, [rsp+0xC0]
0000707b885dd34f  vmovaps xmm14, [rsp+0xD0]
0000707b885dd358  vmovaps xmm15, [rsp+0xE0]
0000707b885dd361  add rsp, 0xF0
0000707b885dd368  pop r11
0000707b885dd36a  pop r10
0000707b885dd36c  pop r9
0000707b885dd36e  pop r8
0000707b885dd370  pop rsi
0000707b885dd371  pop rdi
0000707b885dd372  pop rdx
0000707b885dd373  pop rcx
0000707b885dd374  pop rax
0000707b885dd375  add rsp, 0x08
0000707b885dd379  jmp 0x0000707B885DBC94
0000707b885dd37e  sub rsp, 0x08
0000707b885dd382  push rax
0000707b885dd383  push rcx
0000707b885dd384  push rdx
0000707b885dd385  push rdi
0000707b885dd386  push rsi
0000707b885dd387  push r8
0000707b885dd389  push r9
0000707b885dd38b  push r10
0000707b885dd38d  push r11
0000707b885dd38f  sub rsp, 0xF0
0000707b885dd396  vmovaps [rsp], xmm0
0000707b885dd39b  vmovaps [rsp+0x10], xmm1
0000707b885dd3a1  vmovaps [rsp+0x20], xmm2
0000707b885dd3a7  vmovaps [rsp+0x30], xmm3
0000707b885dd3ad  vmovaps [rsp+0x40], xmm4
0000707b885dd3b3  vmovaps [rsp+0x50], xmm5
0000707b885dd3b9  vmovaps [rsp+0x60], xmm6
0000707b885dd3bf  vmovaps [rsp+0x70], xmm7
0000707b885dd3c5  vmovaps [rsp+0x80], xmm8
0000707b885dd3ce  vmovaps [rsp+0x90], xmm10
0000707b885dd3d7  vmovaps [rsp+0xA0], xmm11
0000707b885dd3e0  vmovaps [rsp+0xB0], xmm12
0000707b885dd3e9  vmovaps [rsp+0xC0], xmm13
0000707b885dd3f2  vmovaps [rsp+0xD0], xmm14
0000707b885dd3fb  vmovaps [rsp+0xE0], xmm15
0000707b885dd404  sub rsp, 0x30
0000707b885dd408  movaps [rsp], xmm9
0000707b885dd40d  movaps [rsp+0x10], xmm10
0000707b885dd413  movaps [rsp+0x20], xmm8
0000707b885dd419  lea rdi, [rsp]
0000707b885dd41d  mov esi, 0x00
0000707b885dd422  mov rax, 0x6471B35AC530
0000707b885dd42c  call rax
0000707b885dd42e  movaps xmm9, [rsp]
0000707b885dd433  add rsp, 0x30
0000707b885dd437  vmovaps xmm0, [rsp]
0000707b885dd43c  vmovaps xmm1, [rsp+0x10]
0000707b885dd442  vmovaps xmm2, [rsp+0x20]
0000707b885dd448  vmovaps xmm3, [rsp+0x30]
0000707b885dd44e  vmovaps xmm4, [rsp+0x40]
0000707b885dd454  vmovaps xmm5, [rsp+0x50]
0000707b885dd45a  vmovaps xmm6, [rsp+0x60]
0000707b885dd460  vmovaps xmm7, [rsp+0x70]
0000707b885dd466  vmovaps xmm8, [rsp+0x80]
0000707b885dd46f  vmovaps xmm10, [rsp+0x90]
0000707b885dd478  vmovaps xmm11, [rsp+0xA0]
0000707b885dd481  vmovaps xmm12, [rsp+0xB0]
0000707b885dd48a  vmovaps xmm13, [rsp+0xC0]
0000707b885dd493  vmovaps xmm14, [rsp+0xD0]
0000707b885dd49c  vmovaps xmm15, [rsp+0xE0]
0000707b885dd4a5  add rsp, 0xF0
0000707b885dd4ac  pop r11
0000707b885dd4ae  pop r10
0000707b885dd4b0  pop r9
0000707b885dd4b2  pop r8
0000707b885dd4b4  pop rsi
0000707b885dd4b5  pop rdi
0000707b885dd4b6  pop rdx
0000707b885dd4b7  pop rcx
0000707b885dd4b8  pop rax
0000707b885dd4b9  add rsp, 0x08
0000707b885dd4bd  jmp 0x0000707B885DBCAE
0000707b885dd4c2  call 0x0000707B884B52F0
0000707b885dd4c7  jmp 0x0000707B885DBDC8
0000707b885dd4cc  call 0x0000707B884B52F0
0000707b885dd4d1  jmp 0x0000707B885DBDDE
0000707b885dd4d6  sub rsp, 0x08
0000707b885dd4da  push rax
0000707b885dd4db  push rcx
0000707b885dd4dc  push rdx
0000707b885dd4dd  push rdi
0000707b885dd4de  push rsi
0000707b885dd4df  push r8
0000707b885dd4e1  push r9
0000707b885dd4e3  push r10
0000707b885dd4e5  push r11
0000707b885dd4e7  sub rsp, 0xF0
0000707b885dd4ee  vmovaps [rsp], xmm0
0000707b885dd4f3  vmovaps [rsp+0x10], xmm2
0000707b885dd4f9  vmovaps [rsp+0x20], xmm3
0000707b885dd4ff  vmovaps [rsp+0x30], xmm4
0000707b885dd505  vmovaps [rsp+0x40], xmm5
0000707b885dd50b  vmovaps [rsp+0x50], xmm6
0000707b885dd511  vmovaps [rsp+0x60], xmm7
0000707b885dd517  vmovaps [rsp+0x70], xmm8
0000707b885dd51d  vmovaps [rsp+0x80], xmm9
0000707b885dd526  vmovaps [rsp+0x90], xmm10
0000707b885dd52f  vmovaps [rsp+0xA0], xmm11
0000707b885dd538  vmovaps [rsp+0xB0], xmm12
0000707b885dd541  vmovaps [rsp+0xC0], xmm13
0000707b885dd54a  vmovaps [rsp+0xD0], xmm14
0000707b885dd553  vmovaps [rsp+0xE0], xmm15
0000707b885dd55c  sub rsp, 0x30
0000707b885dd560  movaps [rsp], xmm1
0000707b885dd564  movaps [rsp+0x10], xmm6
0000707b885dd569  movaps [rsp+0x20], xmm15
0000707b885dd56f  lea rdi, [rsp]
0000707b885dd573  mov esi, 0x00
0000707b885dd578  mov rax, 0x6471B35AC530
0000707b885dd582  call rax
0000707b885dd584  movaps xmm1, [rsp]
0000707b885dd588  add rsp, 0x30
0000707b885dd58c  vmovaps xmm0, [rsp]
0000707b885dd591  vmovaps xmm2, [rsp+0x10]
0000707b885dd597  vmovaps xmm3, [rsp+0x20]
0000707b885dd59d  vmovaps xmm4, [rsp+0x30]
0000707b885dd5a3  vmovaps xmm5, [rsp+0x40]
0000707b885dd5a9  vmovaps xmm6, [rsp+0x50]
0000707b885dd5af  vmovaps xmm7, [rsp+0x60]
0000707b885dd5b5  vmovaps xmm8, [rsp+0x70]
0000707b885dd5bb  vmovaps xmm9, [rsp+0x80]
0000707b885dd5c4  vmovaps xmm10, [rsp+0x90]
0000707b885dd5cd  vmovaps xmm11, [rsp+0xA0]
0000707b885dd5d6  vmovaps xmm12, [rsp+0xB0]
0000707b885dd5df  vmovaps xmm13, [rsp+0xC0]
0000707b885dd5e8  vmovaps xmm14, [rsp+0xD0]
0000707b885dd5f1  vmovaps xmm15, [rsp+0xE0]
0000707b885dd5fa  add rsp, 0xF0
0000707b885dd601  pop r11
0000707b885dd603  pop r10
0000707b885dd605  pop r9
0000707b885dd607  pop r8
0000707b885dd609  pop rsi
0000707b885dd60a  pop rdi
0000707b885dd60b  pop rdx
0000707b885dd60c  pop rcx
0000707b885dd60d  pop rax
0000707b885dd60e  add rsp, 0x08
0000707b885dd612  jmp 0x0000707B885DBE1B
0000707b885dd617  call 0x0000707B884C4620
0000707b885dd61c  jmp 0x0000707B885DBE28
0000707b885dd621  sub rsp, 0x08
0000707b885dd625  push rax
0000707b885dd626  push rcx
0000707b885dd627  push rdx
0000707b885dd628  push rdi
0000707b885dd629  push rsi
0000707b885dd62a  push r8
0000707b885dd62c  push r9
0000707b885dd62e  push r10
0000707b885dd630  push r11
0000707b885dd632  sub rsp, 0xF0
0000707b885dd639  vmovaps [rsp], xmm0
0000707b885dd63e  vmovaps [rsp+0x10], xmm1
0000707b885dd644  vmovaps [rsp+0x20], xmm2
0000707b885dd64a  vmovaps [rsp+0x30], xmm3
0000707b885dd650  vmovaps [rsp+0x40], xmm4
0000707b885dd656  vmovaps [rsp+0x50], xmm5
0000707b885dd65c  vmovaps [rsp+0x60], xmm6
0000707b885dd662  vmovaps [rsp+0x70], xmm7
0000707b885dd668  vmovaps [rsp+0x80], xmm8
0000707b885dd671  vmovaps [rsp+0x90], xmm9
0000707b885dd67a  vmovaps [rsp+0xA0], xmm10
0000707b885dd683  vmovaps [rsp+0xB0], xmm11
0000707b885dd68c  vmovaps [rsp+0xC0], xmm12
0000707b885dd695  vmovaps [rsp+0xD0], xmm13
0000707b885dd69e  vmovaps [rsp+0xE0], xmm15
0000707b885dd6a7  sub rsp, 0x30
0000707b885dd6ab  movaps [rsp], xmm14
0000707b885dd6b0  movaps [rsp+0x10], xmm4
0000707b885dd6b5  movaps [rsp+0x20], xmm3
0000707b885dd6ba  lea rdi, [rsp]
0000707b885dd6be  mov esi, 0x00
0000707b885dd6c3  mov rax, 0x6471B35AC530
0000707b885dd6cd  call rax
0000707b885dd6cf  movaps xmm14, [rsp]
0000707b885dd6d4  add rsp, 0x30
0000707b885dd6d8  vmovaps xmm0, [rsp]
0000707b885dd6dd  vmovaps xmm1, [rsp+0x10]
0000707b885dd6e3  vmovaps xmm2, [rsp+0x20]
0000707b885dd6e9  vmovaps xmm3, [rsp+0x30]
0000707b885dd6ef  vmovaps xmm4, [rsp+0x40]
0000707b885dd6f5  vmovaps xmm5, [rsp+0x50]
0000707b885dd6fb  vmovaps xmm6, [rsp+0x60]
0000707b885dd701  vmovaps xmm7, [rsp+0x70]
0000707b885dd707  vmovaps xmm8, [rsp+0x80]
0000707b885dd710  vmovaps xmm9, [rsp+0x90]
0000707b885dd719  vmovaps xmm10, [rsp+0xA0]
0000707b885dd722  vmovaps xmm11, [rsp+0xB0]
0000707b885dd72b  vmovaps xmm12, [rsp+0xC0]
0000707b885dd734  vmovaps xmm13, [rsp+0xD0]
0000707b885dd73d  vmovaps xmm15, [rsp+0xE0]
0000707b885dd746  add rsp, 0xF0
0000707b885dd74d  pop r11
0000707b885dd74f  pop r10
0000707b885dd751  pop r9
0000707b885dd753  pop r8
0000707b885dd755  pop rsi
0000707b885dd756  pop rdi
0000707b885dd757  pop rdx
0000707b885dd758  pop rcx
0000707b885dd759  pop rax
0000707b885dd75a  add rsp, 0x08
0000707b885dd75e  jmp 0x0000707B885DBE42
0000707b885dd763  sub rsp, 0x08
0000707b885dd767  push rax
0000707b885dd768  push rcx
0000707b885dd769  push rdx
0000707b885dd76a  push rdi
0000707b885dd76b  push rsi
0000707b885dd76c  push r8
0000707b885dd76e  push r9
0000707b885dd770  push r10
0000707b885dd772  push r11
0000707b885dd774  sub rsp, 0xF0
0000707b885dd77b  vmovaps [rsp], xmm0
0000707b885dd780  vmovaps [rsp+0x10], xmm1
0000707b885dd786  vmovaps [rsp+0x20], xmm2
0000707b885dd78c  vmovaps [rsp+0x30], xmm3
0000707b885dd792  vmovaps [rsp+0x40], xmm4
0000707b885dd798  vmovaps [rsp+0x50], xmm5
0000707b885dd79e  vmovaps [rsp+0x60], xmm7
0000707b885dd7a4  vmovaps [rsp+0x70], xmm8
0000707b885dd7aa  vmovaps [rsp+0x80], xmm9
0000707b885dd7b3  vmovaps [rsp+0x90], xmm10
0000707b885dd7bc  vmovaps [rsp+0xA0], xmm11
0000707b885dd7c5  vmovaps [rsp+0xB0], xmm12
0000707b885dd7ce  vmovaps [rsp+0xC0], xmm13
0000707b885dd7d7  vmovaps [rsp+0xD0], xmm14
0000707b885dd7e0  vmovaps [rsp+0xE0], xmm15
0000707b885dd7e9  sub rsp, 0x30
0000707b885dd7ed  movaps [rsp], xmm6
0000707b885dd7f1  movaps [rsp+0x10], xmm9
0000707b885dd7f7  movaps [rsp+0x20], xmm7
0000707b885dd7fc  lea rdi, [rsp]
0000707b885dd800  mov esi, 0x00
0000707b885dd805  mov rax, 0x6471B35AC530
0000707b885dd80f  call rax
0000707b885dd811  movaps xmm6, [rsp]
0000707b885dd815  add rsp, 0x30
0000707b885dd819  vmovaps xmm0, [rsp]
0000707b885dd81e  vmovaps xmm1, [rsp+0x10]
0000707b885dd824  vmovaps xmm2, [rsp+0x20]
0000707b885dd82a  vmovaps xmm3, [rsp+0x30]
0000707b885dd830  vmovaps xmm4, [rsp+0x40]
0000707b885dd836  vmovaps xmm5, [rsp+0x50]
0000707b885dd83c  vmovaps xmm7, [rsp+0x60]
0000707b885dd842  vmovaps xmm8, [rsp+0x70]
0000707b885dd848  vmovaps xmm9, [rsp+0x80]
0000707b885dd851  vmovaps xmm10, [rsp+0x90]
0000707b885dd85a  vmovaps xmm11, [rsp+0xA0]
0000707b885dd863  vmovaps xmm12, [rsp+0xB0]
0000707b885dd86c  vmovaps xmm13, [rsp+0xC0]
0000707b885dd875  vmovaps xmm14, [rsp+0xD0]
0000707b885dd87e  vmovaps xmm15, [rsp+0xE0]
0000707b885dd887  add rsp, 0xF0
0000707b885dd88e  pop r11
0000707b885dd890  pop r10
0000707b885dd892  pop r9
0000707b885dd894  pop r8
0000707b885dd896  pop rsi
0000707b885dd897  pop rdi
0000707b885dd898  pop rdx
0000707b885dd899  pop rcx
0000707b885dd89a  pop rax
0000707b885dd89b  add rsp, 0x08
0000707b885dd89f  jmp 0x0000707B885DBE5A
0000707b885dd8a4  sub rsp, 0x08
0000707b885dd8a8  push rax
0000707b885dd8a9  push rcx
0000707b885dd8aa  push rdx
0000707b885dd8ab  push rdi
0000707b885dd8ac  push rsi
0000707b885dd8ad  push r8
0000707b885dd8af  push r9
0000707b885dd8b1  push r10
0000707b885dd8b3  push r11
0000707b885dd8b5  sub rsp, 0xF0
0000707b885dd8bc  vmovaps [rsp], xmm0
0000707b885dd8c1  vmovaps [rsp+0x10], xmm1
0000707b885dd8c7  vmovaps [rsp+0x20], xmm2
0000707b885dd8cd  vmovaps [rsp+0x30], xmm3
0000707b885dd8d3  vmovaps [rsp+0x40], xmm4
0000707b885dd8d9  vmovaps [rsp+0x50], xmm5
0000707b885dd8df  vmovaps [rsp+0x60], xmm6
0000707b885dd8e5  vmovaps [rsp+0x70], xmm8
0000707b885dd8eb  vmovaps [rsp+0x80], xmm9
0000707b885dd8f4  vmovaps [rsp+0x90], xmm10
0000707b885dd8fd  vmovaps [rsp+0xA0], xmm11
0000707b885dd906  vmovaps [rsp+0xB0], xmm12
0000707b885dd90f  vmovaps [rsp+0xC0], xmm13
0000707b885dd918  vmovaps [rsp+0xD0], xmm14
0000707b885dd921  vmovaps [rsp+0xE0], xmm15
0000707b885dd92a  sub rsp, 0x30
0000707b885dd92e  movaps [rsp], xmm7
0000707b885dd932  movaps [rsp+0x10], xmm4
0000707b885dd937  movaps [rsp+0x20], xmm9
0000707b885dd93d  lea rdi, [rsp]
0000707b885dd941  mov esi, 0x00
0000707b885dd946  mov rax, 0x6471B35AC530
0000707b885dd950  call rax
0000707b885dd952  movaps xmm7, [rsp]
0000707b885dd956  add rsp, 0x30
0000707b885dd95a  vmovaps xmm0, [rsp]
0000707b885dd95f  vmovaps xmm1, [rsp+0x10]
0000707b885dd965  vmovaps xmm2, [rsp+0x20]
0000707b885dd96b  vmovaps xmm3, [rsp+0x30]
0000707b885dd971  vmovaps xmm4, [rsp+0x40]
0000707b885dd977  vmovaps xmm5, [rsp+0x50]
0000707b885dd97d  vmovaps xmm6, [rsp+0x60]
0000707b885dd983  vmovaps xmm8, [rsp+0x70]
0000707b885dd989  vmovaps xmm9, [rsp+0x80]
0000707b885dd992  vmovaps xmm10, [rsp+0x90]
0000707b885dd99b  vmovaps xmm11, [rsp+0xA0]
0000707b885dd9a4  vmovaps xmm12, [rsp+0xB0]
0000707b885dd9ad  vmovaps xmm13, [rsp+0xC0]
0000707b885dd9b6  vmovaps xmm14, [rsp+0xD0]
0000707b885dd9bf  vmovaps xmm15, [rsp+0xE0]
0000707b885dd9c8  add rsp, 0xF0
0000707b885dd9cf  pop r11
0000707b885dd9d1  pop r10
0000707b885dd9d3  pop r9
0000707b885dd9d5  pop r8
0000707b885dd9d7  pop rsi
0000707b885dd9d8  pop rdi
0000707b885dd9d9  pop rdx
0000707b885dd9da  pop rcx
0000707b885dd9db  pop rax
0000707b885dd9dc  add rsp, 0x08
0000707b885dd9e0  jmp 0x0000707B885DBE87
0000707b885dd9e5  sub rsp, 0x08
0000707b885dd9e9  push rax
0000707b885dd9ea  push rcx
0000707b885dd9eb  push rdx
0000707b885dd9ec  push rdi
0000707b885dd9ed  push rsi
0000707b885dd9ee  push r8
0000707b885dd9f0  push r9
0000707b885dd9f2  push r10
0000707b885dd9f4  push r11
0000707b885dd9f6  sub rsp, 0xF0
0000707b885dd9fd  vmovaps [rsp], xmm0
0000707b885dda02  vmovaps [rsp+0x10], xmm1
0000707b885dda08  vmovaps [rsp+0x20], xmm2
0000707b885dda0e  vmovaps [rsp+0x30], xmm3
0000707b885dda14  vmovaps [rsp+0x40], xmm5
0000707b885dda1a  vmovaps [rsp+0x50], xmm6
0000707b885dda20  vmovaps [rsp+0x60], xmm7
0000707b885dda26  vmovaps [rsp+0x70], xmm8
0000707b885dda2c  vmovaps [rsp+0x80], xmm9
0000707b885dda35  vmovaps [rsp+0x90], xmm10
0000707b885dda3e  vmovaps [rsp+0xA0], xmm11
0000707b885dda47  vmovaps [rsp+0xB0], xmm12
0000707b885dda50  vmovaps [rsp+0xC0], xmm13
0000707b885dda59  vmovaps [rsp+0xD0], xmm14
0000707b885dda62  vmovaps [rsp+0xE0], xmm15
0000707b885dda6b  sub rsp, 0x30
0000707b885dda6f  movaps [rsp], xmm4
0000707b885dda73  movaps [rsp+0x10], xmm15
0000707b885dda79  movaps [rsp+0x20], xmm9
0000707b885dda7f  lea rdi, [rsp]
0000707b885dda83  mov esi, 0x00
0000707b885dda88  mov rax, 0x6471B35AC530
0000707b885dda92  call rax
0000707b885dda94  movaps xmm4, [rsp]
0000707b885dda98  add rsp, 0x30
0000707b885dda9c  vmovaps xmm0, [rsp]
0000707b885ddaa1  vmovaps xmm1, [rsp+0x10]
0000707b885ddaa7  vmovaps xmm2, [rsp+0x20]
0000707b885ddaad  vmovaps xmm3, [rsp+0x30]
0000707b885ddab3  vmovaps xmm5, [rsp+0x40]
0000707b885ddab9  vmovaps xmm6, [rsp+0x50]
0000707b885ddabf  vmovaps xmm7, [rsp+0x60]
0000707b885ddac5  vmovaps xmm8, [rsp+0x70]
0000707b885ddacb  vmovaps xmm9, [rsp+0x80]
0000707b885ddad4  vmovaps xmm10, [rsp+0x90]
0000707b885ddadd  vmovaps xmm11, [rsp+0xA0]
0000707b885ddae6  vmovaps xmm12, [rsp+0xB0]
0000707b885ddaef  vmovaps xmm13, [rsp+0xC0]
0000707b885ddaf8  vmovaps xmm14, [rsp+0xD0]
0000707b885ddb01  vmovaps xmm15, [rsp+0xE0]
0000707b885ddb0a  add rsp, 0xF0
0000707b885ddb11  pop r11
0000707b885ddb13  pop r10
0000707b885ddb15  pop r9
0000707b885ddb17  pop r8
0000707b885ddb19  pop rsi
0000707b885ddb1a  pop rdi
0000707b885ddb1b  pop rdx
0000707b885ddb1c  pop rcx
0000707b885ddb1d  pop rax
0000707b885ddb1e  add rsp, 0x08
0000707b885ddb22  jmp 0x0000707B885DBEAC
0000707b885ddb27  call 0x0000707B884C4620
0000707b885ddb2c  jmp 0x0000707B885DBEB9
0000707b885ddb31  sub rsp, 0x08
0000707b885ddb35  push rax
0000707b885ddb36  push rcx
0000707b885ddb37  push rdx
0000707b885ddb38  push rdi
0000707b885ddb39  push rsi
0000707b885ddb3a  push r8
0000707b885ddb3c  push r9
0000707b885ddb3e  push r10
0000707b885ddb40  push r11
0000707b885ddb42  sub rsp, 0xF0
0000707b885ddb49  vmovaps [rsp], xmm0
0000707b885ddb4e  vmovaps [rsp+0x10], xmm1
0000707b885ddb54  vmovaps [rsp+0x20], xmm2
0000707b885ddb5a  vmovaps [rsp+0x30], xmm4
0000707b885ddb60  vmovaps [rsp+0x40], xmm5
0000707b885ddb66  vmovaps [rsp+0x50], xmm6
0000707b885ddb6c  vmovaps [rsp+0x60], xmm7
0000707b885ddb72  vmovaps [rsp+0x70], xmm8
0000707b885ddb78  vmovaps [rsp+0x80], xmm9
0000707b885ddb81  vmovaps [rsp+0x90], xmm10
0000707b885ddb8a  vmovaps [rsp+0xA0], xmm11
0000707b885ddb93  vmovaps [rsp+0xB0], xmm12
0000707b885ddb9c  vmovaps [rsp+0xC0], xmm13
0000707b885ddba5  vmovaps [rsp+0xD0], xmm14
0000707b885ddbae  vmovaps [rsp+0xE0], xmm15
0000707b885ddbb7  sub rsp, 0x30
0000707b885ddbbb  movaps [rsp], xmm3
0000707b885ddbbf  movaps [rsp+0x10], xmm1
0000707b885ddbc4  movaps [rsp+0x20], xmm9
0000707b885ddbca  lea rdi, [rsp]
0000707b885ddbce  mov esi, 0x00
0000707b885ddbd3  mov rax, 0x6471B35AC530
0000707b885ddbdd  call rax
0000707b885ddbdf  movaps xmm3, [rsp]
0000707b885ddbe3  add rsp, 0x30
0000707b885ddbe7  vmovaps xmm0, [rsp]
0000707b885ddbec  vmovaps xmm1, [rsp+0x10]
0000707b885ddbf2  vmovaps xmm2, [rsp+0x20]
0000707b885ddbf8  vmovaps xmm4, [rsp+0x30]
0000707b885ddbfe  vmovaps xmm5, [rsp+0x40]
0000707b885ddc04  vmovaps xmm6, [rsp+0x50]
0000707b885ddc0a  vmovaps xmm7, [rsp+0x60]
0000707b885ddc10  vmovaps xmm8, [rsp+0x70]
0000707b885ddc16  vmovaps xmm9, [rsp+0x80]
0000707b885ddc1f  vmovaps xmm10, [rsp+0x90]
0000707b885ddc28  vmovaps xmm11, [rsp+0xA0]
0000707b885ddc31  vmovaps xmm12, [rsp+0xB0]
0000707b885ddc3a  vmovaps xmm13, [rsp+0xC0]
0000707b885ddc43  vmovaps xmm14, [rsp+0xD0]
0000707b885ddc4c  vmovaps xmm15, [rsp+0xE0]
0000707b885ddc55  add rsp, 0xF0
0000707b885ddc5c  pop r11
0000707b885ddc5e  pop r10
0000707b885ddc60  pop r9
0000707b885ddc62  pop r8
0000707b885ddc64  pop rsi
0000707b885ddc65  pop rdi
0000707b885ddc66  pop rdx
0000707b885ddc67  pop rcx
0000707b885ddc68  pop rax
0000707b885ddc69  add rsp, 0x08
0000707b885ddc6d  jmp 0x0000707B885DBEF6
0000707b885ddc72  sub rsp, 0x08
0000707b885ddc76  push rax
0000707b885ddc77  push rcx
0000707b885ddc78  push rdx
0000707b885ddc79  push rdi
0000707b885ddc7a  push rsi
0000707b885ddc7b  push r8
0000707b885ddc7d  push r9
0000707b885ddc7f  push r10
0000707b885ddc81  push r11
0000707b885ddc83  sub rsp, 0xF0
0000707b885ddc8a  vmovaps [rsp], xmm0
0000707b885ddc8f  vmovaps [rsp+0x10], xmm2
0000707b885ddc95  vmovaps [rsp+0x20], xmm3
0000707b885ddc9b  vmovaps [rsp+0x30], xmm4
0000707b885ddca1  vmovaps [rsp+0x40], xmm5
0000707b885ddca7  vmovaps [rsp+0x50], xmm6
0000707b885ddcad  vmovaps [rsp+0x60], xmm7
0000707b885ddcb3  vmovaps [rsp+0x70], xmm8
0000707b885ddcb9  vmovaps [rsp+0x80], xmm9
0000707b885ddcc2  vmovaps [rsp+0x90], xmm10
0000707b885ddccb  vmovaps [rsp+0xA0], xmm11
0000707b885ddcd4  vmovaps [rsp+0xB0], xmm12
0000707b885ddcdd  vmovaps [rsp+0xC0], xmm13
0000707b885ddce6  vmovaps [rsp+0xD0], xmm14
0000707b885ddcef  vmovaps [rsp+0xE0], xmm15
0000707b885ddcf8  sub rsp, 0x30
0000707b885ddcfc  movaps [rsp], xmm1
0000707b885ddd00  movaps [rsp+0x10], xmm15
0000707b885ddd06  movaps [rsp+0x20], xmm9
0000707b885ddd0c  lea rdi, [rsp]
0000707b885ddd10  mov esi, 0x00
0000707b885ddd15  mov rax, 0x6471B35AC530
0000707b885ddd1f  call rax
0000707b885ddd21  movaps xmm1, [rsp]
0000707b885ddd25  add rsp, 0x30
0000707b885ddd29  vmovaps xmm0, [rsp]
0000707b885ddd2e  vmovaps xmm2, [rsp+0x10]
0000707b885ddd34  vmovaps xmm3, [rsp+0x20]
0000707b885ddd3a  vmovaps xmm4, [rsp+0x30]
0000707b885ddd40  vmovaps xmm5, [rsp+0x40]
0000707b885ddd46  vmovaps xmm6, [rsp+0x50]
0000707b885ddd4c  vmovaps xmm7, [rsp+0x60]
0000707b885ddd52  vmovaps xmm8, [rsp+0x70]
0000707b885ddd58  vmovaps xmm9, [rsp+0x80]
0000707b885ddd61  vmovaps xmm10, [rsp+0x90]
0000707b885ddd6a  vmovaps xmm11, [rsp+0xA0]
0000707b885ddd73  vmovaps xmm12, [rsp+0xB0]
0000707b885ddd7c  vmovaps xmm13, [rsp+0xC0]
0000707b885ddd85  vmovaps xmm14, [rsp+0xD0]
0000707b885ddd8e  vmovaps xmm15, [rsp+0xE0]
0000707b885ddd97  add rsp, 0xF0
0000707b885ddd9e  pop r11
0000707b885ddda0  pop r10
0000707b885ddda2  pop r9
0000707b885ddda4  pop r8
0000707b885ddda6  pop rsi
0000707b885ddda7  pop rdi
0000707b885ddda8  pop rdx
0000707b885ddda9  pop rcx
0000707b885dddaa  pop rax
0000707b885dddab  add rsp, 0x08
0000707b885dddaf  jmp 0x0000707B885DBF7E
0000707b885dddb4  call 0x0000707B884C4620
0000707b885dddb9  jmp 0x0000707B885DBF8B
0000707b885dddbe  sub rsp, 0x08
0000707b885dddc2  push rax
0000707b885dddc3  push rcx
0000707b885dddc4  push rdx
0000707b885dddc5  push rdi
0000707b885dddc6  push rsi
0000707b885dddc7  push r8
0000707b885dddc9  push r9
0000707b885dddcb  push r10
0000707b885dddcd  push r11
0000707b885dddcf  sub rsp, 0xF0
0000707b885dddd6  vmovaps [rsp], xmm0
0000707b885ddddb  vmovaps [rsp+0x10], xmm2
0000707b885ddde1  vmovaps [rsp+0x20], xmm3
0000707b885ddde7  vmovaps [rsp+0x30], xmm4
0000707b885ddded  vmovaps [rsp+0x40], xmm5
0000707b885dddf3  vmovaps [rsp+0x50], xmm6
0000707b885dddf9  vmovaps [rsp+0x60], xmm7
0000707b885dddff  vmovaps [rsp+0x70], xmm8
0000707b885dde05  vmovaps [rsp+0x80], xmm9
0000707b885dde0e  vmovaps [rsp+0x90], xmm10
0000707b885dde17  vmovaps [rsp+0xA0], xmm11
0000707b885dde20  vmovaps [rsp+0xB0], xmm12
0000707b885dde29  vmovaps [rsp+0xC0], xmm13
0000707b885dde32  vmovaps [rsp+0xD0], xmm14
0000707b885dde3b  vmovaps [rsp+0xE0], xmm15
0000707b885dde44  sub rsp, 0x30
0000707b885dde48  movaps [rsp], xmm1
0000707b885dde4c  movaps [rsp+0x10], xmm5
0000707b885dde51  movaps [rsp+0x20], xmm7
0000707b885dde56  lea rdi, [rsp]
0000707b885dde5a  mov esi, 0x00
0000707b885dde5f  mov rax, 0x6471B35AC530
0000707b885dde69  call rax
0000707b885dde6b  movaps xmm1, [rsp]
0000707b885dde6f  add rsp, 0x30
0000707b885dde73  vmovaps xmm0, [rsp]
0000707b885dde78  vmovaps xmm2, [rsp+0x10]
0000707b885dde7e  vmovaps xmm3, [rsp+0x20]
0000707b885dde84  vmovaps xmm4, [rsp+0x30]
0000707b885dde8a  vmovaps xmm5, [rsp+0x40]
0000707b885dde90  vmovaps xmm6, [rsp+0x50]
0000707b885dde96  vmovaps xmm7, [rsp+0x60]
0000707b885dde9c  vmovaps xmm8, [rsp+0x70]
0000707b885ddea2  vmovaps xmm9, [rsp+0x80]
0000707b885ddeab  vmovaps xmm10, [rsp+0x90]
0000707b885ddeb4  vmovaps xmm11, [rsp+0xA0]
0000707b885ddebd  vmovaps xmm12, [rsp+0xB0]
0000707b885ddec6  vmovaps xmm13, [rsp+0xC0]
0000707b885ddecf  vmovaps xmm14, [rsp+0xD0]
0000707b885dded8  vmovaps xmm15, [rsp+0xE0]
0000707b885ddee1  add rsp, 0xF0
0000707b885ddee8  pop r11
0000707b885ddeea  pop r10
0000707b885ddeec  pop r9
0000707b885ddeee  pop r8
0000707b885ddef0  pop rsi
0000707b885ddef1  pop rdi
0000707b885ddef2  pop rdx
0000707b885ddef3  pop rcx
0000707b885ddef4  pop rax
0000707b885ddef5  add rsp, 0x08
0000707b885ddef9  jmp 0x0000707B885DC030
0000707b885ddefe  sub rsp, 0x08
0000707b885ddf02  push rax
0000707b885ddf03  push rcx
0000707b885ddf04  push rdx
0000707b885ddf05  push rdi
0000707b885ddf06  push rsi
0000707b885ddf07  push r8
0000707b885ddf09  push r9
0000707b885ddf0b  push r10
0000707b885ddf0d  push r11
0000707b885ddf0f  sub rsp, 0xF0
0000707b885ddf16  vmovaps [rsp], xmm0
0000707b885ddf1b  vmovaps [rsp+0x10], xmm1
0000707b885ddf21  vmovaps [rsp+0x20], xmm2
0000707b885ddf27  vmovaps [rsp+0x30], xmm3
0000707b885ddf2d  vmovaps [rsp+0x40], xmm4
0000707b885ddf33  vmovaps [rsp+0x50], xmm5
0000707b885ddf39  vmovaps [rsp+0x60], xmm6
0000707b885ddf3f  vmovaps [rsp+0x70], xmm8
0000707b885ddf45  vmovaps [rsp+0x80], xmm9
0000707b885ddf4e  vmovaps [rsp+0x90], xmm10
0000707b885ddf57  vmovaps [rsp+0xA0], xmm11
0000707b885ddf60  vmovaps [rsp+0xB0], xmm12
0000707b885ddf69  vmovaps [rsp+0xC0], xmm13
0000707b885ddf72  vmovaps [rsp+0xD0], xmm14
0000707b885ddf7b  vmovaps [rsp+0xE0], xmm15
0000707b885ddf84  sub rsp, 0x30
0000707b885ddf88  movaps [rsp], xmm7
0000707b885ddf8c  movaps [rsp+0x10], xmm5
0000707b885ddf91  movaps [rsp+0x20], xmm15
0000707b885ddf97  lea rdi, [rsp]
0000707b885ddf9b  mov esi, 0x00
0000707b885ddfa0  mov rax, 0x6471B35AC530
0000707b885ddfaa  call rax
0000707b885ddfac  movaps xmm7, [rsp]
0000707b885ddfb0  add rsp, 0x30
0000707b885ddfb4  vmovaps xmm0, [rsp]
0000707b885ddfb9  vmovaps xmm1, [rsp+0x10]
0000707b885ddfbf  vmovaps xmm2, [rsp+0x20]
0000707b885ddfc5  vmovaps xmm3, [rsp+0x30]
0000707b885ddfcb  vmovaps xmm4, [rsp+0x40]
0000707b885ddfd1  vmovaps xmm5, [rsp+0x50]
0000707b885ddfd7  vmovaps xmm6, [rsp+0x60]
0000707b885ddfdd  vmovaps xmm8, [rsp+0x70]
0000707b885ddfe3  vmovaps xmm9, [rsp+0x80]
0000707b885ddfec  vmovaps xmm10, [rsp+0x90]
0000707b885ddff5  vmovaps xmm11, [rsp+0xA0]
0000707b885ddffe  vmovaps xmm12, [rsp+0xB0]
0000707b885de007  vmovaps xmm13, [rsp+0xC0]
0000707b885de010  vmovaps xmm14, [rsp+0xD0]
0000707b885de019  vmovaps xmm15, [rsp+0xE0]
0000707b885de022  add rsp, 0xF0
0000707b885de029  pop r11
0000707b885de02b  pop r10
0000707b885de02d  pop r9
0000707b885de02f  pop r8
0000707b885de031  pop rsi
0000707b885de032  pop rdi
0000707b885de033  pop rdx
0000707b885de034  pop rcx
0000707b885de035  pop rax
0000707b885de036  add rsp, 0x08
0000707b885de03a  jmp 0x0000707B885DC066
0000707b885de03f  call 0x0000707B884B52F0
0000707b885de044  jmp 0x0000707B885DC073
0000707b885de049  sub rsp, 0x08
0000707b885de04d  push rax
0000707b885de04e  push rcx
0000707b885de04f  push rdx
0000707b885de050  push rdi
0000707b885de051  push rsi
0000707b885de052  push r8
0000707b885de054  push r9
0000707b885de056  push r10
0000707b885de058  push r11
0000707b885de05a  sub rsp, 0xF0
0000707b885de061  vmovaps [rsp], xmm0
0000707b885de066  vmovaps [rsp+0x10], xmm1
0000707b885de06c  vmovaps [rsp+0x20], xmm2
0000707b885de072  vmovaps [rsp+0x30], xmm3
0000707b885de078  vmovaps [rsp+0x40], xmm4
0000707b885de07e  vmovaps [rsp+0x50], xmm5
0000707b885de084  vmovaps [rsp+0x60], xmm6
0000707b885de08a  vmovaps [rsp+0x70], xmm7
0000707b885de090  vmovaps [rsp+0x80], xmm8
0000707b885de099  vmovaps [rsp+0x90], xmm9
0000707b885de0a2  vmovaps [rsp+0xA0], xmm10
0000707b885de0ab  vmovaps [rsp+0xB0], xmm11
0000707b885de0b4  vmovaps [rsp+0xC0], xmm12
0000707b885de0bd  vmovaps [rsp+0xD0], xmm13
0000707b885de0c6  vmovaps [rsp+0xE0], xmm14
0000707b885de0cf  sub rsp, 0x30
0000707b885de0d3  movaps [rsp], xmm15
0000707b885de0d8  movaps [rsp+0x10], xmm5
0000707b885de0dd  movaps [rsp+0x20], xmm3
0000707b885de0e2  lea rdi, [rsp]
0000707b885de0e6  mov esi, 0x00
0000707b885de0eb  mov rax, 0x6471B35AC530
0000707b885de0f5  call rax
0000707b885de0f7  movaps xmm15, [rsp]
0000707b885de0fc  add rsp, 0x30
0000707b885de100  vmovaps xmm0, [rsp]
0000707b885de105  vmovaps xmm1, [rsp+0x10]
0000707b885de10b  vmovaps xmm2, [rsp+0x20]
0000707b885de111  vmovaps xmm3, [rsp+0x30]
0000707b885de117  vmovaps xmm4, [rsp+0x40]
0000707b885de11d  vmovaps xmm5, [rsp+0x50]
0000707b885de123  vmovaps xmm6, [rsp+0x60]
0000707b885de129  vmovaps xmm7, [rsp+0x70]
0000707b885de12f  vmovaps xmm8, [rsp+0x80]
0000707b885de138  vmovaps xmm9, [rsp+0x90]
0000707b885de141  vmovaps xmm10, [rsp+0xA0]
0000707b885de14a  vmovaps xmm11, [rsp+0xB0]
0000707b885de153  vmovaps xmm12, [rsp+0xC0]
0000707b885de15c  vmovaps xmm13, [rsp+0xD0]
0000707b885de165  vmovaps xmm14, [rsp+0xE0]
0000707b885de16e  add rsp, 0xF0
0000707b885de175  pop r11
0000707b885de177  pop r10
0000707b885de179  pop r9
0000707b885de17b  pop r8
0000707b885de17d  pop rsi
0000707b885de17e  pop rdi
0000707b885de17f  pop rdx
0000707b885de180  pop rcx
0000707b885de181  pop rax
0000707b885de182  add rsp, 0x08
0000707b885de186  jmp 0x0000707B885DC099
0000707b885de18b  sub rsp, 0x08
0000707b885de18f  push rax
0000707b885de190  push rcx
0000707b885de191  push rdx
0000707b885de192  push rdi
0000707b885de193  push rsi
0000707b885de194  push r8
0000707b885de196  push r9
0000707b885de198  push r10
0000707b885de19a  push r11
0000707b885de19c  sub rsp, 0xF0
0000707b885de1a3  vmovaps [rsp], xmm0
0000707b885de1a8  vmovaps [rsp+0x10], xmm2
0000707b885de1ae  vmovaps [rsp+0x20], xmm3
0000707b885de1b4  vmovaps [rsp+0x30], xmm4
0000707b885de1ba  vmovaps [rsp+0x40], xmm5
0000707b885de1c0  vmovaps [rsp+0x50], xmm6
0000707b885de1c6  vmovaps [rsp+0x60], xmm7
0000707b885de1cc  vmovaps [rsp+0x70], xmm8
0000707b885de1d2  vmovaps [rsp+0x80], xmm9
0000707b885de1db  vmovaps [rsp+0x90], xmm10
0000707b885de1e4  vmovaps [rsp+0xA0], xmm11
0000707b885de1ed  vmovaps [rsp+0xB0], xmm12
0000707b885de1f6  vmovaps [rsp+0xC0], xmm13
0000707b885de1ff  vmovaps [rsp+0xD0], xmm14
0000707b885de208  vmovaps [rsp+0xE0], xmm15
0000707b885de211  sub rsp, 0x30
0000707b885de215  movaps [rsp], xmm1
0000707b885de219  movaps [rsp+0x10], xmm5
0000707b885de21e  movaps [rsp+0x20], xmm4
0000707b885de223  lea rdi, [rsp]
0000707b885de227  mov esi, 0x00
0000707b885de22c  mov rax, 0x6471B35AC530
0000707b885de236  call rax
0000707b885de238  movaps xmm1, [rsp]
0000707b885de23c  add rsp, 0x30
0000707b885de240  vmovaps xmm0, [rsp]
0000707b885de245  vmovaps xmm2, [rsp+0x10]
0000707b885de24b  vmovaps xmm3, [rsp+0x20]
0000707b885de251  vmovaps xmm4, [rsp+0x30]
0000707b885de257  vmovaps xmm5, [rsp+0x40]
0000707b885de25d  vmovaps xmm6, [rsp+0x50]
0000707b885de263  vmovaps xmm7, [rsp+0x60]
0000707b885de269  vmovaps xmm8, [rsp+0x70]
0000707b885de26f  vmovaps xmm9, [rsp+0x80]
0000707b885de278  vmovaps xmm10, [rsp+0x90]
0000707b885de281  vmovaps xmm11, [rsp+0xA0]
0000707b885de28a  vmovaps xmm12, [rsp+0xB0]
0000707b885de293  vmovaps xmm13, [rsp+0xC0]
0000707b885de29c  vmovaps xmm14, [rsp+0xD0]
0000707b885de2a5  vmovaps xmm15, [rsp+0xE0]
0000707b885de2ae  add rsp, 0xF0
0000707b885de2b5  pop r11
0000707b885de2b7  pop r10
0000707b885de2b9  pop r9
0000707b885de2bb  pop r8
0000707b885de2bd  pop rsi
0000707b885de2be  pop rdi
0000707b885de2bf  pop rdx
0000707b885de2c0  pop rcx
0000707b885de2c1  pop rax
0000707b885de2c2  add rsp, 0x08
0000707b885de2c6  jmp 0x0000707B885DC0B9
0000707b885de2cb  sub rsp, 0x08
0000707b885de2cf  push rax
0000707b885de2d0  push rcx
0000707b885de2d1  push rdx
0000707b885de2d2  push rdi
0000707b885de2d3  push rsi
0000707b885de2d4  push r8
0000707b885de2d6  push r9
0000707b885de2d8  push r10
0000707b885de2da  push r11
0000707b885de2dc  sub rsp, 0xF0
0000707b885de2e3  vmovaps [rsp], xmm0
0000707b885de2e8  vmovaps [rsp+0x10], xmm1
0000707b885de2ee  vmovaps [rsp+0x20], xmm2
0000707b885de2f4  vmovaps [rsp+0x30], xmm3
0000707b885de2fa  vmovaps [rsp+0x40], xmm5
0000707b885de300  vmovaps [rsp+0x50], xmm6
0000707b885de306  vmovaps [rsp+0x60], xmm7
0000707b885de30c  vmovaps [rsp+0x70], xmm8
0000707b885de312  vmovaps [rsp+0x80], xmm9
0000707b885de31b  vmovaps [rsp+0x90], xmm10
0000707b885de324  vmovaps [rsp+0xA0], xmm11
0000707b885de32d  vmovaps [rsp+0xB0], xmm12
0000707b885de336  vmovaps [rsp+0xC0], xmm13
0000707b885de33f  vmovaps [rsp+0xD0], xmm14
0000707b885de348  vmovaps [rsp+0xE0], xmm15
0000707b885de351  sub rsp, 0x30
0000707b885de355  movaps [rsp], xmm4
0000707b885de359  movaps [rsp+0x10], xmm3
0000707b885de35e  movaps [rsp+0x20], xmm5
0000707b885de363  lea rdi, [rsp]
0000707b885de367  mov esi, 0x00
0000707b885de36c  mov rax, 0x6471B35AC530
0000707b885de376  call rax
0000707b885de378  movaps xmm4, [rsp]
0000707b885de37c  add rsp, 0x30
0000707b885de380  vmovaps xmm0, [rsp]
0000707b885de385  vmovaps xmm1, [rsp+0x10]
0000707b885de38b  vmovaps xmm2, [rsp+0x20]
0000707b885de391  vmovaps xmm3, [rsp+0x30]
0000707b885de397  vmovaps xmm5, [rsp+0x40]
0000707b885de39d  vmovaps xmm6, [rsp+0x50]
0000707b885de3a3  vmovaps xmm7, [rsp+0x60]
0000707b885de3a9  vmovaps xmm8, [rsp+0x70]
0000707b885de3af  vmovaps xmm9, [rsp+0x80]
0000707b885de3b8  vmovaps xmm10, [rsp+0x90]
0000707b885de3c1  vmovaps xmm11, [rsp+0xA0]
0000707b885de3ca  vmovaps xmm12, [rsp+0xB0]
0000707b885de3d3  vmovaps xmm13, [rsp+0xC0]
0000707b885de3dc  vmovaps xmm14, [rsp+0xD0]
0000707b885de3e5  vmovaps xmm15, [rsp+0xE0]
0000707b885de3ee  add rsp, 0xF0
0000707b885de3f5  pop r11
0000707b885de3f7  pop r10
0000707b885de3f9  pop r9
0000707b885de3fb  pop r8
0000707b885de3fd  pop rsi
0000707b885de3fe  pop rdi
0000707b885de3ff  pop rdx
0000707b885de400  pop rcx
0000707b885de401  pop rax
0000707b885de402  add rsp, 0x08
0000707b885de406  jmp 0x0000707B885DC107
0000707b885de40b  call 0x0000707B884B52F0
0000707b885de410  jmp 0x0000707B885DC114
0000707b885de415  sub rsp, 0x08
0000707b885de419  push rax
0000707b885de41a  push rcx
0000707b885de41b  push rdx
0000707b885de41c  push rdi
0000707b885de41d  push rsi
0000707b885de41e  push r8
0000707b885de420  push r9
0000707b885de422  push r10
0000707b885de424  push r11
0000707b885de426  sub rsp, 0xF0
0000707b885de42d  vmovaps [rsp], xmm0
0000707b885de432  vmovaps [rsp+0x10], xmm1
0000707b885de438  vmovaps [rsp+0x20], xmm2
0000707b885de43e  vmovaps [rsp+0x30], xmm3
0000707b885de444  vmovaps [rsp+0x40], xmm4
0000707b885de44a  vmovaps [rsp+0x50], xmm6
0000707b885de450  vmovaps [rsp+0x60], xmm7
0000707b885de456  vmovaps [rsp+0x70], xmm8
0000707b885de45c  vmovaps [rsp+0x80], xmm9
0000707b885de465  vmovaps [rsp+0x90], xmm10
0000707b885de46e  vmovaps [rsp+0xA0], xmm11
0000707b885de477  vmovaps [rsp+0xB0], xmm12
0000707b885de480  vmovaps [rsp+0xC0], xmm13
0000707b885de489  vmovaps [rsp+0xD0], xmm14
0000707b885de492  vmovaps [rsp+0xE0], xmm15
0000707b885de49b  sub rsp, 0x30
0000707b885de49f  movaps [rsp], xmm5
0000707b885de4a3  movaps [rsp+0x10], xmm6
0000707b885de4a8  movaps [rsp+0x20], xmm3
0000707b885de4ad  lea rdi, [rsp]
0000707b885de4b1  mov esi, 0x00
0000707b885de4b6  mov rax, 0x6471B35AC530
0000707b885de4c0  call rax
0000707b885de4c2  movaps xmm5, [rsp]
0000707b885de4c6  add rsp, 0x30
0000707b885de4ca  vmovaps xmm0, [rsp]
0000707b885de4cf  vmovaps xmm1, [rsp+0x10]
0000707b885de4d5  vmovaps xmm2, [rsp+0x20]
0000707b885de4db  vmovaps xmm3, [rsp+0x30]
0000707b885de4e1  vmovaps xmm4, [rsp+0x40]
0000707b885de4e7  vmovaps xmm6, [rsp+0x50]
0000707b885de4ed  vmovaps xmm7, [rsp+0x60]
0000707b885de4f3  vmovaps xmm8, [rsp+0x70]
0000707b885de4f9  vmovaps xmm9, [rsp+0x80]
0000707b885de502  vmovaps xmm10, [rsp+0x90]
0000707b885de50b  vmovaps xmm11, [rsp+0xA0]
0000707b885de514  vmovaps xmm12, [rsp+0xB0]
0000707b885de51d  vmovaps xmm13, [rsp+0xC0]
0000707b885de526  vmovaps xmm14, [rsp+0xD0]
0000707b885de52f  vmovaps xmm15, [rsp+0xE0]
0000707b885de538  add rsp, 0xF0
0000707b885de53f  pop r11
0000707b885de541  pop r10
0000707b885de543  pop r9
0000707b885de545  pop r8
0000707b885de547  pop rsi
0000707b885de548  pop rdi
0000707b885de549  pop rdx
0000707b885de54a  pop rcx
0000707b885de54b  pop rax
0000707b885de54c  add rsp, 0x08
0000707b885de550  jmp 0x0000707B885DC13A
0000707b885de555  sub rsp, 0x08
0000707b885de559  push rax
0000707b885de55a  push rcx
0000707b885de55b  push rdx
0000707b885de55c  push rdi
0000707b885de55d  push rsi
0000707b885de55e  push r8
0000707b885de560  push r9
0000707b885de562  push r10
0000707b885de564  push r11
0000707b885de566  sub rsp, 0xF0
0000707b885de56d  vmovaps [rsp], xmm0
0000707b885de572  vmovaps [rsp+0x10], xmm1
0000707b885de578  vmovaps [rsp+0x20], xmm2
0000707b885de57e  vmovaps [rsp+0x30], xmm3
0000707b885de584  vmovaps [rsp+0x40], xmm4
0000707b885de58a  vmovaps [rsp+0x50], xmm5
0000707b885de590  vmovaps [rsp+0x60], xmm7
0000707b885de596  vmovaps [rsp+0x70], xmm8
0000707b885de59c  vmovaps [rsp+0x80], xmm9
0000707b885de5a5  vmovaps [rsp+0x90], xmm10
0000707b885de5ae  vmovaps [rsp+0xA0], xmm11
0000707b885de5b7  vmovaps [rsp+0xB0], xmm12
0000707b885de5c0  vmovaps [rsp+0xC0], xmm13
0000707b885de5c9  vmovaps [rsp+0xD0], xmm14
0000707b885de5d2  vmovaps [rsp+0xE0], xmm15
0000707b885de5db  sub rsp, 0x30
0000707b885de5df  movaps [rsp], xmm6
0000707b885de5e3  movaps [rsp+0x10], xmm9
0000707b885de5e9  movaps [rsp+0x20], xmm1
0000707b885de5ee  lea rdi, [rsp]
0000707b885de5f2  mov esi, 0x00
0000707b885de5f7  mov rax, 0x6471B35AC530
0000707b885de601  call rax
0000707b885de603  movaps xmm6, [rsp]
0000707b885de607  add rsp, 0x30
0000707b885de60b  vmovaps xmm0, [rsp]
0000707b885de610  vmovaps xmm1, [rsp+0x10]
0000707b885de616  vmovaps xmm2, [rsp+0x20]
0000707b885de61c  vmovaps xmm3, [rsp+0x30]
0000707b885de622  vmovaps xmm4, [rsp+0x40]
0000707b885de628  vmovaps xmm5, [rsp+0x50]
0000707b885de62e  vmovaps xmm7, [rsp+0x60]
0000707b885de634  vmovaps xmm8, [rsp+0x70]
0000707b885de63a  vmovaps xmm9, [rsp+0x80]
0000707b885de643  vmovaps xmm10, [rsp+0x90]
0000707b885de64c  vmovaps xmm11, [rsp+0xA0]
0000707b885de655  vmovaps xmm12, [rsp+0xB0]
0000707b885de65e  vmovaps xmm13, [rsp+0xC0]
0000707b885de667  vmovaps xmm14, [rsp+0xD0]
0000707b885de670  vmovaps xmm15, [rsp+0xE0]
0000707b885de679  add rsp, 0xF0
0000707b885de680  pop r11
0000707b885de682  pop r10
0000707b885de684  pop r9
0000707b885de686  pop r8
0000707b885de688  pop rsi
0000707b885de689  pop rdi
0000707b885de68a  pop rdx
0000707b885de68b  pop rcx
0000707b885de68c  pop rax
0000707b885de68d  add rsp, 0x08
0000707b885de691  jmp 0x0000707B885DC15E
0000707b885de696  sub rsp, 0x08
0000707b885de69a  push rax
0000707b885de69b  push rcx
0000707b885de69c  push rdx
0000707b885de69d  push rdi
0000707b885de69e  push rsi
0000707b885de69f  push r8
0000707b885de6a1  push r9
0000707b885de6a3  push r10
0000707b885de6a5  push r11
0000707b885de6a7  sub rsp, 0xF0
0000707b885de6ae  vmovaps [rsp], xmm0
0000707b885de6b3  vmovaps [rsp+0x10], xmm1
0000707b885de6b9  vmovaps [rsp+0x20], xmm2
0000707b885de6bf  vmovaps [rsp+0x30], xmm3
0000707b885de6c5  vmovaps [rsp+0x40], xmm4
0000707b885de6cb  vmovaps [rsp+0x50], xmm5
0000707b885de6d1  vmovaps [rsp+0x60], xmm6
0000707b885de6d7  vmovaps [rsp+0x70], xmm7
0000707b885de6dd  vmovaps [rsp+0x80], xmm8
0000707b885de6e6  vmovaps [rsp+0x90], xmm10
0000707b885de6ef  vmovaps [rsp+0xA0], xmm11
0000707b885de6f8  vmovaps [rsp+0xB0], xmm12
0000707b885de701  vmovaps [rsp+0xC0], xmm13
0000707b885de70a  vmovaps [rsp+0xD0], xmm14
0000707b885de713  vmovaps [rsp+0xE0], xmm15
0000707b885de71c  sub rsp, 0x30
0000707b885de720  movaps [rsp], xmm9
0000707b885de725  movaps [rsp+0x10], xmm3
0000707b885de72a  movaps [rsp+0x20], xmm1
0000707b885de72f  lea rdi, [rsp]
0000707b885de733  mov esi, 0x00
0000707b885de738  mov rax, 0x6471B35AC530
0000707b885de742  call rax
0000707b885de744  movaps xmm9, [rsp]
0000707b885de749  add rsp, 0x30
0000707b885de74d  vmovaps xmm0, [rsp]
0000707b885de752  vmovaps xmm1, [rsp+0x10]
0000707b885de758  vmovaps xmm2, [rsp+0x20]
0000707b885de75e  vmovaps xmm3, [rsp+0x30]
0000707b885de764  vmovaps xmm4, [rsp+0x40]
0000707b885de76a  vmovaps xmm5, [rsp+0x50]
0000707b885de770  vmovaps xmm6, [rsp+0x60]
0000707b885de776  vmovaps xmm7, [rsp+0x70]
0000707b885de77c  vmovaps xmm8, [rsp+0x80]
0000707b885de785  vmovaps xmm10, [rsp+0x90]
0000707b885de78e  vmovaps xmm11, [rsp+0xA0]
0000707b885de797  vmovaps xmm12, [rsp+0xB0]
0000707b885de7a0  vmovaps xmm13, [rsp+0xC0]
0000707b885de7a9  vmovaps xmm14, [rsp+0xD0]
0000707b885de7b2  vmovaps xmm15, [rsp+0xE0]
0000707b885de7bb  add rsp, 0xF0
0000707b885de7c2  pop r11
0000707b885de7c4  pop r10
0000707b885de7c6  pop r9
0000707b885de7c8  pop r8
0000707b885de7ca  pop rsi
0000707b885de7cb  pop rdi
0000707b885de7cc  pop rdx
0000707b885de7cd  pop rcx
0000707b885de7ce  pop rax
0000707b885de7cf  add rsp, 0x08
0000707b885de7d3  jmp 0x0000707B885DC1AA
0000707b885de7d8  call 0x0000707B884B52F0
0000707b885de7dd  jmp 0x0000707B885DC1B7
0000707b885de7e2  sub rsp, 0x08
0000707b885de7e6  push rax
0000707b885de7e7  push rcx
0000707b885de7e8  push rdx
0000707b885de7e9  push rdi
0000707b885de7ea  push rsi
0000707b885de7eb  push r8
0000707b885de7ed  push r9
0000707b885de7ef  push r10
0000707b885de7f1  push r11
0000707b885de7f3  sub rsp, 0xF0
0000707b885de7fa  vmovaps [rsp], xmm0
0000707b885de7ff  vmovaps [rsp+0x10], xmm1
0000707b885de805  vmovaps [rsp+0x20], xmm2
0000707b885de80b  vmovaps [rsp+0x30], xmm3
0000707b885de811  vmovaps [rsp+0x40], xmm4
0000707b885de817  vmovaps [rsp+0x50], xmm5
0000707b885de81d  vmovaps [rsp+0x60], xmm6
0000707b885de823  vmovaps [rsp+0x70], xmm7
0000707b885de829  vmovaps [rsp+0x80], xmm8
0000707b885de832  vmovaps [rsp+0x90], xmm9
0000707b885de83b  vmovaps [rsp+0xA0], xmm10
0000707b885de844  vmovaps [rsp+0xB0], xmm11
0000707b885de84d  vmovaps [rsp+0xC0], xmm12
0000707b885de856  vmovaps [rsp+0xD0], xmm13
0000707b885de85f  vmovaps [rsp+0xE0], xmm14
0000707b885de868  sub rsp, 0x30
0000707b885de86c  movaps [rsp], xmm15
0000707b885de871  movaps [rsp+0x10], xmm3
0000707b885de876  movaps [rsp+0x20], xmm7
0000707b885de87b  lea rdi, [rsp]
0000707b885de87f  mov esi, 0x00
0000707b885de884  mov rax, 0x6471B35AC530
0000707b885de88e  call rax
0000707b885de890  movaps xmm15, [rsp]
0000707b885de895  add rsp, 0x30
0000707b885de899  vmovaps xmm0, [rsp]
0000707b885de89e  vmovaps xmm1, [rsp+0x10]
0000707b885de8a4  vmovaps xmm2, [rsp+0x20]
0000707b885de8aa  vmovaps xmm3, [rsp+0x30]
0000707b885de8b0  vmovaps xmm4, [rsp+0x40]
0000707b885de8b6  vmovaps xmm5, [rsp+0x50]
0000707b885de8bc  vmovaps xmm6, [rsp+0x60]
0000707b885de8c2  vmovaps xmm7, [rsp+0x70]
0000707b885de8c8  vmovaps xmm8, [rsp+0x80]
0000707b885de8d1  vmovaps xmm9, [rsp+0x90]
0000707b885de8da  vmovaps xmm10, [rsp+0xA0]
0000707b885de8e3  vmovaps xmm11, [rsp+0xB0]
0000707b885de8ec  vmovaps xmm12, [rsp+0xC0]
0000707b885de8f5  vmovaps xmm13, [rsp+0xD0]
0000707b885de8fe  vmovaps xmm14, [rsp+0xE0]
0000707b885de907  add rsp, 0xF0
0000707b885de90e  pop r11
0000707b885de910  pop r10
0000707b885de912  pop r9
0000707b885de914  pop r8
0000707b885de916  pop rsi
0000707b885de917  pop rdi
0000707b885de918  pop rdx
0000707b885de919  pop rcx
0000707b885de91a  pop rax
0000707b885de91b  add rsp, 0x08
0000707b885de91f  jmp 0x0000707B885DC1E3
0000707b885de924  sub rsp, 0x08
0000707b885de928  push rax
0000707b885de929  push rcx
0000707b885de92a  push rdx
0000707b885de92b  push rdi
0000707b885de92c  push rsi
0000707b885de92d  push r8
0000707b885de92f  push r9
0000707b885de931  push r10
0000707b885de933  push r11
0000707b885de935  sub rsp, 0xF0
0000707b885de93c  vmovaps [rsp], xmm0
0000707b885de941  vmovaps [rsp+0x10], xmm1
0000707b885de947  vmovaps [rsp+0x20], xmm2
0000707b885de94d  vmovaps [rsp+0x30], xmm4
0000707b885de953  vmovaps [rsp+0x40], xmm5
0000707b885de959  vmovaps [rsp+0x50], xmm6
0000707b885de95f  vmovaps [rsp+0x60], xmm7
0000707b885de965  vmovaps [rsp+0x70], xmm8
0000707b885de96b  vmovaps [rsp+0x80], xmm9
0000707b885de974  vmovaps [rsp+0x90], xmm10
0000707b885de97d  vmovaps [rsp+0xA0], xmm11
0000707b885de986  vmovaps [rsp+0xB0], xmm12
0000707b885de98f  vmovaps [rsp+0xC0], xmm13
0000707b885de998  vmovaps [rsp+0xD0], xmm14
0000707b885de9a1  vmovaps [rsp+0xE0], xmm15
0000707b885de9aa  sub rsp, 0x30
0000707b885de9ae  movaps [rsp], xmm3
0000707b885de9b2  movaps [rsp+0x10], xmm1
0000707b885de9b7  movaps [rsp+0x20], xmm15
0000707b885de9bd  lea rdi, [rsp]
0000707b885de9c1  mov esi, 0x00
0000707b885de9c6  mov rax, 0x6471B35AC530
0000707b885de9d0  call rax
0000707b885de9d2  movaps xmm3, [rsp]
0000707b885de9d6  add rsp, 0x30
0000707b885de9da  vmovaps xmm0, [rsp]
0000707b885de9df  vmovaps xmm1, [rsp+0x10]
0000707b885de9e5  vmovaps xmm2, [rsp+0x20]
0000707b885de9eb  vmovaps xmm4, [rsp+0x30]
0000707b885de9f1  vmovaps xmm5, [rsp+0x40]
0000707b885de9f7  vmovaps xmm6, [rsp+0x50]
0000707b885de9fd  vmovaps xmm7, [rsp+0x60]
0000707b885dea03  vmovaps xmm8, [rsp+0x70]
0000707b885dea09  vmovaps xmm9, [rsp+0x80]
0000707b885dea12  vmovaps xmm10, [rsp+0x90]
0000707b885dea1b  vmovaps xmm11, [rsp+0xA0]
0000707b885dea24  vmovaps xmm12, [rsp+0xB0]
0000707b885dea2d  vmovaps xmm13, [rsp+0xC0]
0000707b885dea36  vmovaps xmm14, [rsp+0xD0]
0000707b885dea3f  vmovaps xmm15, [rsp+0xE0]
0000707b885dea48  add rsp, 0xF0
0000707b885dea4f  pop r11
0000707b885dea51  pop r10
0000707b885dea53  pop r9
0000707b885dea55  pop r8
0000707b885dea57  pop rsi
0000707b885dea58  pop rdi
0000707b885dea59  pop rdx
0000707b885dea5a  pop rcx
0000707b885dea5b  pop rax
0000707b885dea5c  add rsp, 0x08
0000707b885dea60  jmp 0x0000707B885DC272
0000707b885dea65  call 0x0000707B884B52F0
0000707b885dea6a  jmp 0x0000707B885DC27C
0000707b885dea6f  sub rsp, 0x08
0000707b885dea73  push rax
0000707b885dea74  push rcx
0000707b885dea75  push rdx
0000707b885dea76  push rdi
0000707b885dea77  push rsi
0000707b885dea78  push r8
0000707b885dea7a  push r9
0000707b885dea7c  push r10
0000707b885dea7e  push r11
0000707b885dea80  sub rsp, 0xF0
0000707b885dea87  vmovaps [rsp], xmm0
0000707b885dea8c  vmovaps [rsp+0x10], xmm1
0000707b885dea92  vmovaps [rsp+0x20], xmm2
0000707b885dea98  vmovaps [rsp+0x30], xmm3
0000707b885dea9e  vmovaps [rsp+0x40], xmm4
0000707b885deaa4  vmovaps [rsp+0x50], xmm5
0000707b885deaaa  vmovaps [rsp+0x60], xmm6
0000707b885deab0  vmovaps [rsp+0x70], xmm7
0000707b885deab6  vmovaps [rsp+0x80], xmm8
0000707b885deabf  vmovaps [rsp+0x90], xmm9
0000707b885deac8  vmovaps [rsp+0xA0], xmm10
0000707b885dead1  vmovaps [rsp+0xB0], xmm11
0000707b885deada  vmovaps [rsp+0xC0], xmm12
0000707b885deae3  vmovaps [rsp+0xD0], xmm13
0000707b885deaec  vmovaps [rsp+0xE0], xmm14
0000707b885deaf5  sub rsp, 0x30
0000707b885deaf9  movaps [rsp], xmm15
0000707b885deafe  movaps [rsp+0x10], xmm14
0000707b885deb04  movaps [rsp+0x20], xmm4
0000707b885deb09  lea rdi, [rsp]
0000707b885deb0d  mov esi, 0x00
0000707b885deb12  mov rax, 0x6471B35AC530
0000707b885deb1c  call rax
0000707b885deb1e  movaps xmm15, [rsp]
0000707b885deb23  add rsp, 0x30
0000707b885deb27  vmovaps xmm0, [rsp]
0000707b885deb2c  vmovaps xmm1, [rsp+0x10]
0000707b885deb32  vmovaps xmm2, [rsp+0x20]
0000707b885deb38  vmovaps xmm3, [rsp+0x30]
0000707b885deb3e  vmovaps xmm4, [rsp+0x40]
0000707b885deb44  vmovaps xmm5, [rsp+0x50]
0000707b885deb4a  vmovaps xmm6, [rsp+0x60]
0000707b885deb50  vmovaps xmm7, [rsp+0x70]
0000707b885deb56  vmovaps xmm8, [rsp+0x80]
0000707b885deb5f  vmovaps xmm9, [rsp+0x90]
0000707b885deb68  vmovaps xmm10, [rsp+0xA0]
0000707b885deb71  vmovaps xmm11, [rsp+0xB0]
0000707b885deb7a  vmovaps xmm12, [rsp+0xC0]
0000707b885deb83  vmovaps xmm13, [rsp+0xD0]
0000707b885deb8c  vmovaps xmm14, [rsp+0xE0]
0000707b885deb95  add rsp, 0xF0
0000707b885deb9c  pop r11
0000707b885deb9e  pop r10
0000707b885deba0  pop r9
0000707b885deba2  pop r8
0000707b885deba4  pop rsi
0000707b885deba5  pop rdi
0000707b885deba6  pop rdx
0000707b885deba7  pop rcx
0000707b885deba8  pop rax
0000707b885deba9  add rsp, 0x08
0000707b885debad  jmp 0x0000707B885DC2AA
0000707b885debb2  sub rsp, 0x08
0000707b885debb6  push rax
0000707b885debb7  push rcx
0000707b885debb8  push rdx
0000707b885debb9  push rdi
0000707b885debba  push rsi
0000707b885debbb  push r8
0000707b885debbd  push r9
0000707b885debbf  push r10
0000707b885debc1  push r11
0000707b885debc3  sub rsp, 0xF0
0000707b885debca  vmovaps [rsp], xmm0
0000707b885debcf  vmovaps [rsp+0x10], xmm1
0000707b885debd5  vmovaps [rsp+0x20], xmm2
0000707b885debdb  vmovaps [rsp+0x30], xmm3
0000707b885debe1  vmovaps [rsp+0x40], xmm4
0000707b885debe7  vmovaps [rsp+0x50], xmm5
0000707b885debed  vmovaps [rsp+0x60], xmm6
0000707b885debf3  vmovaps [rsp+0x70], xmm7
0000707b885debf9  vmovaps [rsp+0x80], xmm8
0000707b885dec02  vmovaps [rsp+0x90], xmm9
0000707b885dec0b  vmovaps [rsp+0xA0], xmm10
0000707b885dec14  vmovaps [rsp+0xB0], xmm11
0000707b885dec1d  vmovaps [rsp+0xC0], xmm12
0000707b885dec26  vmovaps [rsp+0xD0], xmm13
0000707b885dec2f  vmovaps [rsp+0xE0], xmm15
0000707b885dec38  sub rsp, 0x30
0000707b885dec3c  movaps [rsp], xmm14
0000707b885dec41  movaps [rsp+0x10], xmm2
0000707b885dec46  movaps [rsp+0x20], xmm1
0000707b885dec4b  lea rdi, [rsp]
0000707b885dec4f  mov esi, 0x00
0000707b885dec54  mov rax, 0x6471B35AC530
0000707b885dec5e  call rax
0000707b885dec60  movaps xmm14, [rsp]
0000707b885dec65  add rsp, 0x30
0000707b885dec69  vmovaps xmm0, [rsp]
0000707b885dec6e  vmovaps xmm1, [rsp+0x10]
0000707b885dec74  vmovaps xmm2, [rsp+0x20]
0000707b885dec7a  vmovaps xmm3, [rsp+0x30]
0000707b885dec80  vmovaps xmm4, [rsp+0x40]
0000707b885dec86  vmovaps xmm5, [rsp+0x50]
0000707b885dec8c  vmovaps xmm6, [rsp+0x60]
0000707b885dec92  vmovaps xmm7, [rsp+0x70]
0000707b885dec98  vmovaps xmm8, [rsp+0x80]
0000707b885deca1  vmovaps xmm9, [rsp+0x90]
0000707b885decaa  vmovaps xmm10, [rsp+0xA0]
0000707b885decb3  vmovaps xmm11, [rsp+0xB0]
0000707b885decbc  vmovaps xmm12, [rsp+0xC0]
0000707b885decc5  vmovaps xmm13, [rsp+0xD0]
0000707b885decce  vmovaps xmm15, [rsp+0xE0]
0000707b885decd7  add rsp, 0xF0
0000707b885decde  pop r11
0000707b885dece0  pop r10
0000707b885dece2  pop r9
0000707b885dece4  pop r8
0000707b885dece6  pop rsi
0000707b885dece7  pop rdi
0000707b885dece8  pop rdx
0000707b885dece9  pop rcx
0000707b885decea  pop rax
0000707b885deceb  add rsp, 0x08
0000707b885decef  jmp 0x0000707B885DC2D0
0000707b885decf4  sub rsp, 0x08
0000707b885decf8  push rax
0000707b885decf9  push rcx
0000707b885decfa  push rdx
0000707b885decfb  push rdi
0000707b885decfc  push rsi
0000707b885decfd  push r8
0000707b885decff  push r9
0000707b885ded01  push r10
0000707b885ded03  push r11
0000707b885ded05  sub rsp, 0xF0
0000707b885ded0c  vmovaps [rsp], xmm0
0000707b885ded11  vmovaps [rsp+0x10], xmm2
0000707b885ded17  vmovaps [rsp+0x20], xmm3
0000707b885ded1d  vmovaps [rsp+0x30], xmm4
0000707b885ded23  vmovaps [rsp+0x40], xmm5
0000707b885ded29  vmovaps [rsp+0x50], xmm6
0000707b885ded2f  vmovaps [rsp+0x60], xmm7
0000707b885ded35  vmovaps [rsp+0x70], xmm8
0000707b885ded3b  vmovaps [rsp+0x80], xmm9
0000707b885ded44  vmovaps [rsp+0x90], xmm10
0000707b885ded4d  vmovaps [rsp+0xA0], xmm11
0000707b885ded56  vmovaps [rsp+0xB0], xmm12
0000707b885ded5f  vmovaps [rsp+0xC0], xmm13
0000707b885ded68  vmovaps [rsp+0xD0], xmm14
0000707b885ded71  vmovaps [rsp+0xE0], xmm15
0000707b885ded7a  sub rsp, 0x30
0000707b885ded7e  movaps [rsp], xmm1
0000707b885ded82  movaps [rsp+0x10], xmm4
0000707b885ded87  movaps [rsp+0x20], xmm9
0000707b885ded8d  lea rdi, [rsp]
0000707b885ded91  mov esi, 0x00
0000707b885ded96  mov rax, 0x6471B35AC530
0000707b885deda0  call rax
0000707b885deda2  movaps xmm1, [rsp]
0000707b885deda6  add rsp, 0x30
0000707b885dedaa  vmovaps xmm0, [rsp]
0000707b885dedaf  vmovaps xmm2, [rsp+0x10]
0000707b885dedb5  vmovaps xmm3, [rsp+0x20]
0000707b885dedbb  vmovaps xmm4, [rsp+0x30]
0000707b885dedc1  vmovaps xmm5, [rsp+0x40]
0000707b885dedc7  vmovaps xmm6, [rsp+0x50]
0000707b885dedcd  vmovaps xmm7, [rsp+0x60]
0000707b885dedd3  vmovaps xmm8, [rsp+0x70]
0000707b885dedd9  vmovaps xmm9, [rsp+0x80]
0000707b885dede2  vmovaps xmm10, [rsp+0x90]
0000707b885dedeb  vmovaps xmm11, [rsp+0xA0]
0000707b885dedf4  vmovaps xmm12, [rsp+0xB0]
0000707b885dedfd  vmovaps xmm13, [rsp+0xC0]
0000707b885dee06  vmovaps xmm14, [rsp+0xD0]
0000707b885dee0f  vmovaps xmm15, [rsp+0xE0]
0000707b885dee18  add rsp, 0xF0
0000707b885dee1f  pop r11
0000707b885dee21  pop r10
0000707b885dee23  pop r9
0000707b885dee25  pop r8
0000707b885dee27  pop rsi
0000707b885dee28  pop rdi
0000707b885dee29  pop rdx
0000707b885dee2a  pop rcx
0000707b885dee2b  pop rax
0000707b885dee2c  add rsp, 0x08
0000707b885dee30  jmp 0x0000707B885DC2EE
0000707b885dee35  sub rsp, 0x08
0000707b885dee39  push rax
0000707b885dee3a  push rcx
0000707b885dee3b  push rdx
0000707b885dee3c  push rdi
0000707b885dee3d  push rsi
0000707b885dee3e  push r8
0000707b885dee40  push r9
0000707b885dee42  push r10
0000707b885dee44  push r11
0000707b885dee46  sub rsp, 0xF0
0000707b885dee4d  vmovaps [rsp], xmm0
0000707b885dee52  vmovaps [rsp+0x10], xmm1
0000707b885dee58  vmovaps [rsp+0x20], xmm2
0000707b885dee5e  vmovaps [rsp+0x30], xmm3
0000707b885dee64  vmovaps [rsp+0x40], xmm5
0000707b885dee6a  vmovaps [rsp+0x50], xmm6
0000707b885dee70  vmovaps [rsp+0x60], xmm7
0000707b885dee76  vmovaps [rsp+0x70], xmm8
0000707b885dee7c  vmovaps [rsp+0x80], xmm9
0000707b885dee85  vmovaps [rsp+0x90], xmm10
0000707b885dee8e  vmovaps [rsp+0xA0], xmm11
0000707b885dee97  vmovaps [rsp+0xB0], xmm12
0000707b885deea0  vmovaps [rsp+0xC0], xmm13
0000707b885deea9  vmovaps [rsp+0xD0], xmm14
0000707b885deeb2  vmovaps [rsp+0xE0], xmm15
0000707b885deebb  sub rsp, 0x30
0000707b885deebf  movaps [rsp], xmm4
0000707b885deec3  movaps [rsp+0x10], xmm2
0000707b885deec8  movaps [rsp+0x20], xmm9
0000707b885deece  lea rdi, [rsp]
0000707b885deed2  mov esi, 0x00
0000707b885deed7  mov rax, 0x6471B35AC530
0000707b885deee1  call rax
0000707b885deee3  movaps xmm4, [rsp]
0000707b885deee7  add rsp, 0x30
0000707b885deeeb  vmovaps xmm0, [rsp]
0000707b885deef0  vmovaps xmm1, [rsp+0x10]
0000707b885deef6  vmovaps xmm2, [rsp+0x20]
0000707b885deefc  vmovaps xmm3, [rsp+0x30]
0000707b885def02  vmovaps xmm5, [rsp+0x40]
0000707b885def08  vmovaps xmm6, [rsp+0x50]
0000707b885def0e  vmovaps xmm7, [rsp+0x60]
0000707b885def14  vmovaps xmm8, [rsp+0x70]
0000707b885def1a  vmovaps xmm9, [rsp+0x80]
0000707b885def23  vmovaps xmm10, [rsp+0x90]
0000707b885def2c  vmovaps xmm11, [rsp+0xA0]
0000707b885def35  vmovaps xmm12, [rsp+0xB0]
0000707b885def3e  vmovaps xmm13, [rsp+0xC0]
0000707b885def47  vmovaps xmm14, [rsp+0xD0]
0000707b885def50  vmovaps xmm15, [rsp+0xE0]
0000707b885def59  add rsp, 0xF0
0000707b885def60  pop r11
0000707b885def62  pop r10
0000707b885def64  pop r9
0000707b885def66  pop r8
0000707b885def68  pop rsi
0000707b885def69  pop rdi
0000707b885def6a  pop rdx
0000707b885def6b  pop rcx
0000707b885def6c  pop rax
0000707b885def6d  add rsp, 0x08
0000707b885def71  jmp 0x0000707B885DC31E
0000707b885def76  sub rsp, 0x08
0000707b885def7a  push rax
0000707b885def7b  push rcx
0000707b885def7c  push rdx
0000707b885def7d  push rdi
0000707b885def7e  push rsi
0000707b885def7f  push r8
0000707b885def81  push r9
0000707b885def83  push r10
0000707b885def85  push r11
0000707b885def87  sub rsp, 0xF0
0000707b885def8e  vmovaps [rsp], xmm0
0000707b885def93  vmovaps [rsp+0x10], xmm1
0000707b885def99  vmovaps [rsp+0x20], xmm2
0000707b885def9f  vmovaps [rsp+0x30], xmm3
0000707b885defa5  vmovaps [rsp+0x40], xmm4
0000707b885defab  vmovaps [rsp+0x50], xmm5
0000707b885defb1  vmovaps [rsp+0x60], xmm6
0000707b885defb7  vmovaps [rsp+0x70], xmm7
0000707b885defbd  vmovaps [rsp+0x80], xmm8
0000707b885defc6  vmovaps [rsp+0x90], xmm10
0000707b885defcf  vmovaps [rsp+0xA0], xmm11
0000707b885defd8  vmovaps [rsp+0xB0], xmm12
0000707b885defe1  vmovaps [rsp+0xC0], xmm13
0000707b885defea  vmovaps [rsp+0xD0], xmm14
0000707b885deff3  vmovaps [rsp+0xE0], xmm15
0000707b885deffc  sub rsp, 0x30
0000707b885df000  movaps [rsp], xmm9
0000707b885df005  movaps [rsp+0x10], xmm2
0000707b885df00a  movaps [rsp+0x20], xmm1
0000707b885df00f  lea rdi, [rsp]
0000707b885df013  mov esi, 0x00
0000707b885df018  mov rax, 0x6471B35AC530
0000707b885df022  call rax
0000707b885df024  movaps xmm9, [rsp]
0000707b885df029  add rsp, 0x30
0000707b885df02d  vmovaps xmm0, [rsp]
0000707b885df032  vmovaps xmm1, [rsp+0x10]
0000707b885df038  vmovaps xmm2, [rsp+0x20]
0000707b885df03e  vmovaps xmm3, [rsp+0x30]
0000707b885df044  vmovaps xmm4, [rsp+0x40]
0000707b885df04a  vmovaps xmm5, [rsp+0x50]
0000707b885df050  vmovaps xmm6, [rsp+0x60]
0000707b885df056  vmovaps xmm7, [rsp+0x70]
0000707b885df05c  vmovaps xmm8, [rsp+0x80]
0000707b885df065  vmovaps xmm10, [rsp+0x90]
0000707b885df06e  vmovaps xmm11, [rsp+0xA0]
0000707b885df077  vmovaps xmm12, [rsp+0xB0]
0000707b885df080  vmovaps xmm13, [rsp+0xC0]
0000707b885df089  vmovaps xmm14, [rsp+0xD0]
0000707b885df092  vmovaps xmm15, [rsp+0xE0]
0000707b885df09b  add rsp, 0xF0
0000707b885df0a2  pop r11
0000707b885df0a4  pop r10
0000707b885df0a6  pop r9
0000707b885df0a8  pop r8
0000707b885df0aa  pop rsi
0000707b885df0ab  pop rdi
0000707b885df0ac  pop rdx
0000707b885df0ad  pop rcx
0000707b885df0ae  pop rax
0000707b885df0af  add rsp, 0x08
0000707b885df0b3  jmp 0x0000707B885DC354
0000707b885df0b8  sub rsp, 0x08
0000707b885df0bc  push rax
0000707b885df0bd  push rcx
0000707b885df0be  push rdx
0000707b885df0bf  push rdi
0000707b885df0c0  push rsi
0000707b885df0c1  push r8
0000707b885df0c3  push r9
0000707b885df0c5  push r10
0000707b885df0c7  push r11
0000707b885df0c9  sub rsp, 0xF0
0000707b885df0d0  vmovaps [rsp], xmm0
0000707b885df0d5  vmovaps [rsp+0x10], xmm2
0000707b885df0db  vmovaps [rsp+0x20], xmm3
0000707b885df0e1  vmovaps [rsp+0x30], xmm4
0000707b885df0e7  vmovaps [rsp+0x40], xmm5
0000707b885df0ed  vmovaps [rsp+0x50], xmm6
0000707b885df0f3  vmovaps [rsp+0x60], xmm7
0000707b885df0f9  vmovaps [rsp+0x70], xmm8
0000707b885df0ff  vmovaps [rsp+0x80], xmm9
0000707b885df108  vmovaps [rsp+0x90], xmm10
0000707b885df111  vmovaps [rsp+0xA0], xmm11
0000707b885df11a  vmovaps [rsp+0xB0], xmm12
0000707b885df123  vmovaps [rsp+0xC0], xmm13
0000707b885df12c  vmovaps [rsp+0xD0], xmm14
0000707b885df135  vmovaps [rsp+0xE0], xmm15
0000707b885df13e  sub rsp, 0x30
0000707b885df142  movaps [rsp], xmm1
0000707b885df146  movaps [rsp+0x10], xmm15
0000707b885df14c  movaps [rsp+0x20], xmm6
0000707b885df151  lea rdi, [rsp]
0000707b885df155  mov esi, 0x00
0000707b885df15a  mov rax, 0x6471B35AC530
0000707b885df164  call rax
0000707b885df166  movaps xmm1, [rsp]
0000707b885df16a  add rsp, 0x30
0000707b885df16e  vmovaps xmm0, [rsp]
0000707b885df173  vmovaps xmm2, [rsp+0x10]
0000707b885df179  vmovaps xmm3, [rsp+0x20]
0000707b885df17f  vmovaps xmm4, [rsp+0x30]
0000707b885df185  vmovaps xmm5, [rsp+0x40]
0000707b885df18b  vmovaps xmm6, [rsp+0x50]
0000707b885df191  vmovaps xmm7, [rsp+0x60]
0000707b885df197  vmovaps xmm8, [rsp+0x70]
0000707b885df19d  vmovaps xmm9, [rsp+0x80]
0000707b885df1a6  vmovaps xmm10, [rsp+0x90]
0000707b885df1af  vmovaps xmm11, [rsp+0xA0]
0000707b885df1b8  vmovaps xmm12, [rsp+0xB0]
0000707b885df1c1  vmovaps xmm13, [rsp+0xC0]
0000707b885df1ca  vmovaps xmm14, [rsp+0xD0]
0000707b885df1d3  vmovaps xmm15, [rsp+0xE0]
0000707b885df1dc  add rsp, 0xF0
0000707b885df1e3  pop r11
0000707b885df1e5  pop r10
0000707b885df1e7  pop r9
0000707b885df1e9  pop r8
0000707b885df1eb  pop rsi
0000707b885df1ec  pop rdi
0000707b885df1ed  pop rdx
0000707b885df1ee  pop rcx
0000707b885df1ef  pop rax
0000707b885df1f0  add rsp, 0x08
0000707b885df1f4  jmp 0x0000707B885DC375
0000707b885df1f9  sub rsp, 0x08
0000707b885df1fd  push rax
0000707b885df1fe  push rcx
0000707b885df1ff  push rdx
0000707b885df200  push rdi
0000707b885df201  push rsi
0000707b885df202  push r8
0000707b885df204  push r9
0000707b885df206  push r10
0000707b885df208  push r11
0000707b885df20a  sub rsp, 0xF0
0000707b885df211  vmovaps [rsp], xmm0
0000707b885df216  vmovaps [rsp+0x10], xmm1
0000707b885df21c  vmovaps [rsp+0x20], xmm2
0000707b885df222  vmovaps [rsp+0x30], xmm3
0000707b885df228  vmovaps [rsp+0x40], xmm4
0000707b885df22e  vmovaps [rsp+0x50], xmm5
0000707b885df234  vmovaps [rsp+0x60], xmm6
0000707b885df23a  vmovaps [rsp+0x70], xmm7
0000707b885df240  vmovaps [rsp+0x80], xmm8
0000707b885df249  vmovaps [rsp+0x90], xmm9
0000707b885df252  vmovaps [rsp+0xA0], xmm10
0000707b885df25b  vmovaps [rsp+0xB0], xmm11
0000707b885df264  vmovaps [rsp+0xC0], xmm12
0000707b885df26d  vmovaps [rsp+0xD0], xmm13
0000707b885df276  vmovaps [rsp+0xE0], xmm14
0000707b885df27f  sub rsp, 0x30
0000707b885df283  movaps [rsp], xmm15
0000707b885df288  movaps [rsp+0x10], xmm5
0000707b885df28d  movaps [rsp+0x20], xmm3
0000707b885df292  lea rdi, [rsp]
0000707b885df296  mov esi, 0x00
0000707b885df29b  mov rax, 0x6471B35AC530
0000707b885df2a5  call rax
0000707b885df2a7  movaps xmm15, [rsp]
0000707b885df2ac  add rsp, 0x30
0000707b885df2b0  vmovaps xmm0, [rsp]
0000707b885df2b5  vmovaps xmm1, [rsp+0x10]
0000707b885df2bb  vmovaps xmm2, [rsp+0x20]
0000707b885df2c1  vmovaps xmm3, [rsp+0x30]
0000707b885df2c7  vmovaps xmm4, [rsp+0x40]
0000707b885df2cd  vmovaps xmm5, [rsp+0x50]
0000707b885df2d3  vmovaps xmm6, [rsp+0x60]
0000707b885df2d9  vmovaps xmm7, [rsp+0x70]
0000707b885df2df  vmovaps xmm8, [rsp+0x80]
0000707b885df2e8  vmovaps xmm9, [rsp+0x90]
0000707b885df2f1  vmovaps xmm10, [rsp+0xA0]
0000707b885df2fa  vmovaps xmm11, [rsp+0xB0]
0000707b885df303  vmovaps xmm12, [rsp+0xC0]
0000707b885df30c  vmovaps xmm13, [rsp+0xD0]
0000707b885df315  vmovaps xmm14, [rsp+0xE0]
0000707b885df31e  add rsp, 0xF0
0000707b885df325  pop r11
0000707b885df327  pop r10
0000707b885df329  pop r9
0000707b885df32b  pop r8
0000707b885df32d  pop rsi
0000707b885df32e  pop rdi
0000707b885df32f  pop rdx
0000707b885df330  pop rcx
0000707b885df331  pop rax
0000707b885df332  add rsp, 0x08
0000707b885df336  jmp 0x0000707B885DC38F
0000707b885df33b  sub rsp, 0x08
0000707b885df33f  push rax
0000707b885df340  push rcx
0000707b885df341  push rdx
0000707b885df342  push rdi
0000707b885df343  push rsi
0000707b885df344  push r8
0000707b885df346  push r9
0000707b885df348  push r10
0000707b885df34a  push r11
0000707b885df34c  sub rsp, 0xF0
0000707b885df353  vmovaps [rsp], xmm0
0000707b885df358  vmovaps [rsp+0x10], xmm1
0000707b885df35e  vmovaps [rsp+0x20], xmm2
0000707b885df364  vmovaps [rsp+0x30], xmm3
0000707b885df36a  vmovaps [rsp+0x40], xmm4
0000707b885df370  vmovaps [rsp+0x50], xmm6
0000707b885df376  vmovaps [rsp+0x60], xmm7
0000707b885df37c  vmovaps [rsp+0x70], xmm8
0000707b885df382  vmovaps [rsp+0x80], xmm9
0000707b885df38b  vmovaps [rsp+0x90], xmm10
0000707b885df394  vmovaps [rsp+0xA0], xmm11
0000707b885df39d  vmovaps [rsp+0xB0], xmm12
0000707b885df3a6  vmovaps [rsp+0xC0], xmm13
0000707b885df3af  vmovaps [rsp+0xD0], xmm14
0000707b885df3b8  vmovaps [rsp+0xE0], xmm15
0000707b885df3c1  sub rsp, 0x30
0000707b885df3c5  movaps [rsp], xmm5
0000707b885df3c9  movaps [rsp+0x10], xmm8
0000707b885df3cf  movaps [rsp+0x20], xmm6
0000707b885df3d4  lea rdi, [rsp]
0000707b885df3d8  mov esi, 0x00
0000707b885df3dd  mov rax, 0x6471B35AC530
0000707b885df3e7  call rax
0000707b885df3e9  movaps xmm5, [rsp]
0000707b885df3ed  add rsp, 0x30
0000707b885df3f1  vmovaps xmm0, [rsp]
0000707b885df3f6  vmovaps xmm1, [rsp+0x10]
0000707b885df3fc  vmovaps xmm2, [rsp+0x20]
0000707b885df402  vmovaps xmm3, [rsp+0x30]
0000707b885df408  vmovaps xmm4, [rsp+0x40]
0000707b885df40e  vmovaps xmm6, [rsp+0x50]
0000707b885df414  vmovaps xmm7, [rsp+0x60]
0000707b885df41a  vmovaps xmm8, [rsp+0x70]
0000707b885df420  vmovaps xmm9, [rsp+0x80]
0000707b885df429  vmovaps xmm10, [rsp+0x90]
0000707b885df432  vmovaps xmm11, [rsp+0xA0]
0000707b885df43b  vmovaps xmm12, [rsp+0xB0]
0000707b885df444  vmovaps xmm13, [rsp+0xC0]
0000707b885df44d  vmovaps xmm14, [rsp+0xD0]
0000707b885df456  vmovaps xmm15, [rsp+0xE0]
0000707b885df45f  add rsp, 0xF0
0000707b885df466  pop r11
0000707b885df468  pop r10
0000707b885df46a  pop r9
0000707b885df46c  pop r8
0000707b885df46e  pop rsi
0000707b885df46f  pop rdi
0000707b885df470  pop rdx
0000707b885df471  pop rcx
0000707b885df472  pop rax
0000707b885df473  add rsp, 0x08
0000707b885df477  jmp 0x0000707B885DC3B3
0000707b885df47c  sub rsp, 0x08
0000707b885df480  push rax
0000707b885df481  push rcx
0000707b885df482  push rdx
0000707b885df483  push rdi
0000707b885df484  push rsi
0000707b885df485  push r8
0000707b885df487  push r9
0000707b885df489  push r10
0000707b885df48b  push r11
0000707b885df48d  sub rsp, 0xF0
0000707b885df494  vmovaps [rsp], xmm0
0000707b885df499  vmovaps [rsp+0x10], xmm1
0000707b885df49f  vmovaps [rsp+0x20], xmm2
0000707b885df4a5  vmovaps [rsp+0x30], xmm3
0000707b885df4ab  vmovaps [rsp+0x40], xmm4
0000707b885df4b1  vmovaps [rsp+0x50], xmm5
0000707b885df4b7  vmovaps [rsp+0x60], xmm7
0000707b885df4bd  vmovaps [rsp+0x70], xmm8
0000707b885df4c3  vmovaps [rsp+0x80], xmm9
0000707b885df4cc  vmovaps [rsp+0x90], xmm10
0000707b885df4d5  vmovaps [rsp+0xA0], xmm11
0000707b885df4de  vmovaps [rsp+0xB0], xmm12
0000707b885df4e7  vmovaps [rsp+0xC0], xmm13
0000707b885df4f0  vmovaps [rsp+0xD0], xmm14
0000707b885df4f9  vmovaps [rsp+0xE0], xmm15
0000707b885df502  sub rsp, 0x30
0000707b885df506  movaps [rsp], xmm6
0000707b885df50a  movaps [rsp+0x10], xmm10
0000707b885df510  movaps [rsp+0x20], xmm8
0000707b885df516  lea rdi, [rsp]
0000707b885df51a  mov esi, 0x00
0000707b885df51f  mov rax, 0x6471B35AC530
0000707b885df529  call rax
0000707b885df52b  movaps xmm6, [rsp]
0000707b885df52f  add rsp, 0x30
0000707b885df533  vmovaps xmm0, [rsp]
0000707b885df538  vmovaps xmm1, [rsp+0x10]
0000707b885df53e  vmovaps xmm2, [rsp+0x20]
0000707b885df544  vmovaps xmm3, [rsp+0x30]
0000707b885df54a  vmovaps xmm4, [rsp+0x40]
0000707b885df550  vmovaps xmm5, [rsp+0x50]
0000707b885df556  vmovaps xmm7, [rsp+0x60]
0000707b885df55c  vmovaps xmm8, [rsp+0x70]
0000707b885df562  vmovaps xmm9, [rsp+0x80]
0000707b885df56b  vmovaps xmm10, [rsp+0x90]
0000707b885df574  vmovaps xmm11, [rsp+0xA0]
0000707b885df57d  vmovaps xmm12, [rsp+0xB0]
0000707b885df586  vmovaps xmm13, [rsp+0xC0]
0000707b885df58f  vmovaps xmm14, [rsp+0xD0]
0000707b885df598  vmovaps xmm15, [rsp+0xE0]
0000707b885df5a1  add rsp, 0xF0
0000707b885df5a8  pop r11
0000707b885df5aa  pop r10
0000707b885df5ac  pop r9
0000707b885df5ae  pop r8
0000707b885df5b0  pop rsi
0000707b885df5b1  pop rdi
0000707b885df5b2  pop rdx
0000707b885df5b3  pop rcx
0000707b885df5b4  pop rax
0000707b885df5b5  add rsp, 0x08
0000707b885df5b9  jmp 0x0000707B885DC3D8
0000707b885df5be  sub rsp, 0x08
0000707b885df5c2  push rax
0000707b885df5c3  push rcx
0000707b885df5c4  push rdx
0000707b885df5c5  push rdi
0000707b885df5c6  push rsi
0000707b885df5c7  push r8
0000707b885df5c9  push r9
0000707b885df5cb  push r10
0000707b885df5cd  push r11
0000707b885df5cf  sub rsp, 0xF0
0000707b885df5d6  vmovaps [rsp], xmm0
0000707b885df5db  vmovaps [rsp+0x10], xmm1
0000707b885df5e1  vmovaps [rsp+0x20], xmm2
0000707b885df5e7  vmovaps [rsp+0x30], xmm3
0000707b885df5ed  vmovaps [rsp+0x40], xmm4
0000707b885df5f3  vmovaps [rsp+0x50], xmm5
0000707b885df5f9  vmovaps [rsp+0x60], xmm6
0000707b885df5ff  vmovaps [rsp+0x70], xmm7
0000707b885df605  vmovaps [rsp+0x80], xmm8
0000707b885df60e  vmovaps [rsp+0x90], xmm9
0000707b885df617  vmovaps [rsp+0xA0], xmm11
0000707b885df620  vmovaps [rsp+0xB0], xmm12
0000707b885df629  vmovaps [rsp+0xC0], xmm13
0000707b885df632  vmovaps [rsp+0xD0], xmm14
0000707b885df63b  vmovaps [rsp+0xE0], xmm15
0000707b885df644  sub rsp, 0x30
0000707b885df648  movaps [rsp], xmm10
0000707b885df64d  movaps [rsp+0x10], xmm8
0000707b885df653  movaps [rsp+0x20], xmm14
0000707b885df659  lea rdi, [rsp]
0000707b885df65d  mov esi, 0x00
0000707b885df662  mov rax, 0x6471B35AC530
0000707b885df66c  call rax
0000707b885df66e  movaps xmm10, [rsp]
0000707b885df673  add rsp, 0x30
0000707b885df677  vmovaps xmm0, [rsp]
0000707b885df67c  vmovaps xmm1, [rsp+0x10]
0000707b885df682  vmovaps xmm2, [rsp+0x20]
0000707b885df688  vmovaps xmm3, [rsp+0x30]
0000707b885df68e  vmovaps xmm4, [rsp+0x40]
0000707b885df694  vmovaps xmm5, [rsp+0x50]
0000707b885df69a  vmovaps xmm6, [rsp+0x60]
0000707b885df6a0  vmovaps xmm7, [rsp+0x70]
0000707b885df6a6  vmovaps xmm8, [rsp+0x80]
0000707b885df6af  vmovaps xmm9, [rsp+0x90]
0000707b885df6b8  vmovaps xmm11, [rsp+0xA0]
0000707b885df6c1  vmovaps xmm12, [rsp+0xB0]
0000707b885df6ca  vmovaps xmm13, [rsp+0xC0]
0000707b885df6d3  vmovaps xmm14, [rsp+0xD0]
0000707b885df6dc  vmovaps xmm15, [rsp+0xE0]
0000707b885df6e5  add rsp, 0xF0
0000707b885df6ec  pop r11
0000707b885df6ee  pop r10
0000707b885df6f0  pop r9
0000707b885df6f2  pop r8
0000707b885df6f4  pop rsi
0000707b885df6f5  pop rdi
0000707b885df6f6  pop rdx
0000707b885df6f7  pop rcx
0000707b885df6f8  pop rax
0000707b885df6f9  add rsp, 0x08
0000707b885df6fd  jmp 0x0000707B885DC3F8
0000707b885df702  sub rsp, 0x08
0000707b885df706  push rax
0000707b885df707  push rcx
0000707b885df708  push rdx
0000707b885df709  push rdi
0000707b885df70a  push rsi
0000707b885df70b  push r8
0000707b885df70d  push r9
0000707b885df70f  push r10
0000707b885df711  push r11
0000707b885df713  sub rsp, 0xF0
0000707b885df71a  vmovaps [rsp], xmm0
0000707b885df71f  vmovaps [rsp+0x10], xmm1
0000707b885df725  vmovaps [rsp+0x20], xmm2
0000707b885df72b  vmovaps [rsp+0x30], xmm3
0000707b885df731  vmovaps [rsp+0x40], xmm4
0000707b885df737  vmovaps [rsp+0x50], xmm5
0000707b885df73d  vmovaps [rsp+0x60], xmm6
0000707b885df743  vmovaps [rsp+0x70], xmm7
0000707b885df749  vmovaps [rsp+0x80], xmm8
0000707b885df752  vmovaps [rsp+0x90], xmm9
0000707b885df75b  vmovaps [rsp+0xA0], xmm10
0000707b885df764  vmovaps [rsp+0xB0], xmm11
0000707b885df76d  vmovaps [rsp+0xC0], xmm12
0000707b885df776  vmovaps [rsp+0xD0], xmm13
0000707b885df77f  vmovaps [rsp+0xE0], xmm15
0000707b885df788  sub rsp, 0x30
0000707b885df78c  movaps [rsp], xmm14
0000707b885df791  movaps [rsp+0x10], xmm8
0000707b885df797  movaps [rsp+0x20], xmm4
0000707b885df79c  lea rdi, [rsp]
0000707b885df7a0  mov esi, 0x00
0000707b885df7a5  mov rax, 0x6471B35AC530
0000707b885df7af  call rax
0000707b885df7b1  movaps xmm14, [rsp]
0000707b885df7b6  add rsp, 0x30
0000707b885df7ba  vmovaps xmm0, [rsp]
0000707b885df7bf  vmovaps xmm1, [rsp+0x10]
0000707b885df7c5  vmovaps xmm2, [rsp+0x20]
0000707b885df7cb  vmovaps xmm3, [rsp+0x30]
0000707b885df7d1  vmovaps xmm4, [rsp+0x40]
0000707b885df7d7  vmovaps xmm5, [rsp+0x50]
0000707b885df7dd  vmovaps xmm6, [rsp+0x60]
0000707b885df7e3  vmovaps xmm7, [rsp+0x70]
0000707b885df7e9  vmovaps xmm8, [rsp+0x80]
0000707b885df7f2  vmovaps xmm9, [rsp+0x90]
0000707b885df7fb  vmovaps xmm10, [rsp+0xA0]
0000707b885df804  vmovaps xmm11, [rsp+0xB0]
0000707b885df80d  vmovaps xmm12, [rsp+0xC0]
0000707b885df816  vmovaps xmm13, [rsp+0xD0]
0000707b885df81f  vmovaps xmm15, [rsp+0xE0]
0000707b885df828  add rsp, 0xF0
0000707b885df82f  pop r11
0000707b885df831  pop r10
0000707b885df833  pop r9
0000707b885df835  pop r8
0000707b885df837  pop rsi
0000707b885df838  pop rdi
0000707b885df839  pop rdx
0000707b885df83a  pop rcx
0000707b885df83b  pop rax
0000707b885df83c  add rsp, 0x08
0000707b885df840  jmp 0x0000707B885DC418
0000707b885df845  sub rsp, 0x08
0000707b885df849  push rax
0000707b885df84a  push rcx
0000707b885df84b  push rdx
0000707b885df84c  push rdi
0000707b885df84d  push rsi
0000707b885df84e  push r8
0000707b885df850  push r9
0000707b885df852  push r10
0000707b885df854  push r11
0000707b885df856  sub rsp, 0xF0
0000707b885df85d  vmovaps [rsp], xmm0
0000707b885df862  vmovaps [rsp+0x10], xmm1
0000707b885df868  vmovaps [rsp+0x20], xmm2
0000707b885df86e  vmovaps [rsp+0x30], xmm3
0000707b885df874  vmovaps [rsp+0x40], xmm5
0000707b885df87a  vmovaps [rsp+0x50], xmm6
0000707b885df880  vmovaps [rsp+0x60], xmm7
0000707b885df886  vmovaps [rsp+0x70], xmm8
0000707b885df88c  vmovaps [rsp+0x80], xmm9
0000707b885df895  vmovaps [rsp+0x90], xmm10
0000707b885df89e  vmovaps [rsp+0xA0], xmm11
0000707b885df8a7  vmovaps [rsp+0xB0], xmm12
0000707b885df8b0  vmovaps [rsp+0xC0], xmm13
0000707b885df8b9  vmovaps [rsp+0xD0], xmm14
0000707b885df8c2  vmovaps [rsp+0xE0], xmm15
0000707b885df8cb  sub rsp, 0x30
0000707b885df8cf  movaps [rsp], xmm4
0000707b885df8d3  movaps [rsp+0x10], xmm13
0000707b885df8d9  movaps [rsp+0x20], xmm8
0000707b885df8df  lea rdi, [rsp]
0000707b885df8e3  mov esi, 0x00
0000707b885df8e8  mov rax, 0x6471B35AC530
0000707b885df8f2  call rax
0000707b885df8f4  movaps xmm4, [rsp]
0000707b885df8f8  add rsp, 0x30
0000707b885df8fc  vmovaps xmm0, [rsp]
0000707b885df901  vmovaps xmm1, [rsp+0x10]
0000707b885df907  vmovaps xmm2, [rsp+0x20]
0000707b885df90d  vmovaps xmm3, [rsp+0x30]
0000707b885df913  vmovaps xmm5, [rsp+0x40]
0000707b885df919  vmovaps xmm6, [rsp+0x50]
0000707b885df91f  vmovaps xmm7, [rsp+0x60]
0000707b885df925  vmovaps xmm8, [rsp+0x70]
0000707b885df92b  vmovaps xmm9, [rsp+0x80]
0000707b885df934  vmovaps xmm10, [rsp+0x90]
0000707b885df93d  vmovaps xmm11, [rsp+0xA0]
0000707b885df946  vmovaps xmm12, [rsp+0xB0]
0000707b885df94f  vmovaps xmm13, [rsp+0xC0]
0000707b885df958  vmovaps xmm14, [rsp+0xD0]
0000707b885df961  vmovaps xmm15, [rsp+0xE0]
0000707b885df96a  add rsp, 0xF0
0000707b885df971  pop r11
0000707b885df973  pop r10
0000707b885df975  pop r9
0000707b885df977  pop r8
0000707b885df979  pop rsi
0000707b885df97a  pop rdi
0000707b885df97b  pop rdx
0000707b885df97c  pop rcx
0000707b885df97d  pop rax
0000707b885df97e  add rsp, 0x08
0000707b885df982  jmp 0x0000707B885DC43D
0000707b885df987  sub rsp, 0x08
0000707b885df98b  push rax
0000707b885df98c  push rcx
0000707b885df98d  push rdx
0000707b885df98e  push rdi
0000707b885df98f  push rsi
0000707b885df990  push r8
0000707b885df992  push r9
0000707b885df994  push r10
0000707b885df996  push r11
0000707b885df998  sub rsp, 0xF0
0000707b885df99f  vmovaps [rsp], xmm0
0000707b885df9a4  vmovaps [rsp+0x10], xmm1
0000707b885df9aa  vmovaps [rsp+0x20], xmm2
0000707b885df9b0  vmovaps [rsp+0x30], xmm3
0000707b885df9b6  vmovaps [rsp+0x40], xmm4
0000707b885df9bc  vmovaps [rsp+0x50], xmm5
0000707b885df9c2  vmovaps [rsp+0x60], xmm6
0000707b885df9c8  vmovaps [rsp+0x70], xmm7
0000707b885df9ce  vmovaps [rsp+0x80], xmm8
0000707b885df9d7  vmovaps [rsp+0x90], xmm9
0000707b885df9e0  vmovaps [rsp+0xA0], xmm10
0000707b885df9e9  vmovaps [rsp+0xB0], xmm11
0000707b885df9f2  vmovaps [rsp+0xC0], xmm12
0000707b885df9fb  vmovaps [rsp+0xD0], xmm14
0000707b885dfa04  vmovaps [rsp+0xE0], xmm15
0000707b885dfa0d  sub rsp, 0x30
0000707b885dfa11  movaps [rsp], xmm13
0000707b885dfa16  movaps [rsp+0x10], xmm15
0000707b885dfa1c  movaps [rsp+0x20], xmm9
0000707b885dfa22  lea rdi, [rsp]
0000707b885dfa26  mov esi, 0x00
0000707b885dfa2b  mov rax, 0x6471B35AC530
0000707b885dfa35  call rax
0000707b885dfa37  movaps xmm13, [rsp]
0000707b885dfa3c  add rsp, 0x30
0000707b885dfa40  vmovaps xmm0, [rsp]
0000707b885dfa45  vmovaps xmm1, [rsp+0x10]
0000707b885dfa4b  vmovaps xmm2, [rsp+0x20]
0000707b885dfa51  vmovaps xmm3, [rsp+0x30]
0000707b885dfa57  vmovaps xmm4, [rsp+0x40]
0000707b885dfa5d  vmovaps xmm5, [rsp+0x50]
0000707b885dfa63  vmovaps xmm6, [rsp+0x60]
0000707b885dfa69  vmovaps xmm7, [rsp+0x70]
0000707b885dfa6f  vmovaps xmm8, [rsp+0x80]
0000707b885dfa78  vmovaps xmm9, [rsp+0x90]
0000707b885dfa81  vmovaps xmm10, [rsp+0xA0]
0000707b885dfa8a  vmovaps xmm11, [rsp+0xB0]
0000707b885dfa93  vmovaps xmm12, [rsp+0xC0]
0000707b885dfa9c  vmovaps xmm14, [rsp+0xD0]
0000707b885dfaa5  vmovaps xmm15, [rsp+0xE0]
0000707b885dfaae  add rsp, 0xF0
0000707b885dfab5  pop r11
0000707b885dfab7  pop r10
0000707b885dfab9  pop r9
0000707b885dfabb  pop r8
0000707b885dfabd  pop rsi
0000707b885dfabe  pop rdi
0000707b885dfabf  pop rdx
0000707b885dfac0  pop rcx
0000707b885dfac1  pop rax
0000707b885dfac2  add rsp, 0x08
0000707b885dfac6  jmp 0x0000707B885DC458
0000707b885dfacb  sub rsp, 0x08
0000707b885dfacf  push rax
0000707b885dfad0  push rcx
0000707b885dfad1  push rdx
0000707b885dfad2  push rdi
0000707b885dfad3  push rsi
0000707b885dfad4  push r8
0000707b885dfad6  push r9
0000707b885dfad8  push r10
0000707b885dfada  push r11
0000707b885dfadc  sub rsp, 0xF0
0000707b885dfae3  vmovaps [rsp], xmm0
0000707b885dfae8  vmovaps [rsp+0x10], xmm1
0000707b885dfaee  vmovaps [rsp+0x20], xmm2
0000707b885dfaf4  vmovaps [rsp+0x30], xmm3
0000707b885dfafa  vmovaps [rsp+0x40], xmm4
0000707b885dfb00  vmovaps [rsp+0x50], xmm5
0000707b885dfb06  vmovaps [rsp+0x60], xmm6
0000707b885dfb0c  vmovaps [rsp+0x70], xmm7
0000707b885dfb12  vmovaps [rsp+0x80], xmm8
0000707b885dfb1b  vmovaps [rsp+0x90], xmm9
0000707b885dfb24  vmovaps [rsp+0xA0], xmm10
0000707b885dfb2d  vmovaps [rsp+0xB0], xmm11
0000707b885dfb36  vmovaps [rsp+0xC0], xmm12
0000707b885dfb3f  vmovaps [rsp+0xD0], xmm13
0000707b885dfb48  vmovaps [rsp+0xE0], xmm14
0000707b885dfb51  sub rsp, 0x30
0000707b885dfb55  movaps [rsp], xmm15
0000707b885dfb5a  movaps [rsp+0x10], xmm1
0000707b885dfb5f  movaps [rsp+0x20], xmm5
0000707b885dfb64  lea rdi, [rsp]
0000707b885dfb68  mov esi, 0x00
0000707b885dfb6d  mov rax, 0x6471B35AC530
0000707b885dfb77  call rax
0000707b885dfb79  movaps xmm15, [rsp]
0000707b885dfb7e  add rsp, 0x30
0000707b885dfb82  vmovaps xmm0, [rsp]
0000707b885dfb87  vmovaps xmm1, [rsp+0x10]
0000707b885dfb8d  vmovaps xmm2, [rsp+0x20]
0000707b885dfb93  vmovaps xmm3, [rsp+0x30]
0000707b885dfb99  vmovaps xmm4, [rsp+0x40]
0000707b885dfb9f  vmovaps xmm5, [rsp+0x50]
0000707b885dfba5  vmovaps xmm6, [rsp+0x60]
0000707b885dfbab  vmovaps xmm7, [rsp+0x70]
0000707b885dfbb1  vmovaps xmm8, [rsp+0x80]
0000707b885dfbba  vmovaps xmm9, [rsp+0x90]
0000707b885dfbc3  vmovaps xmm10, [rsp+0xA0]
0000707b885dfbcc  vmovaps xmm11, [rsp+0xB0]
0000707b885dfbd5  vmovaps xmm12, [rsp+0xC0]
0000707b885dfbde  vmovaps xmm13, [rsp+0xD0]
0000707b885dfbe7  vmovaps xmm14, [rsp+0xE0]
0000707b885dfbf0  add rsp, 0xF0
0000707b885dfbf7  pop r11
0000707b885dfbf9  pop r10
0000707b885dfbfb  pop r9
0000707b885dfbfd  pop r8
0000707b885dfbff  pop rsi
0000707b885dfc00  pop rdi
0000707b885dfc01  pop rdx
0000707b885dfc02  pop rcx
0000707b885dfc03  pop rax
0000707b885dfc04  add rsp, 0x08
0000707b885dfc08  jmp 0x0000707B885DC473
0000707b885dfc0d  call 0x0000707B884B52F0
0000707b885dfc12  jmp 0x0000707B885DC4CE
0000707b885dfc17  sub rsp, 0x08
0000707b885dfc1b  push rax
0000707b885dfc1c  push rcx
0000707b885dfc1d  push rdx
0000707b885dfc1e  push rdi
0000707b885dfc1f  push rsi
0000707b885dfc20  push r8
0000707b885dfc22  push r9
0000707b885dfc24  push r10
0000707b885dfc26  push r11
0000707b885dfc28  sub rsp, 0xF0
0000707b885dfc2f  vmovaps [rsp], xmm0
0000707b885dfc34  vmovaps [rsp+0x10], xmm1
0000707b885dfc3a  vmovaps [rsp+0x20], xmm2
0000707b885dfc40  vmovaps [rsp+0x30], xmm3
0000707b885dfc46  vmovaps [rsp+0x40], xmm4
0000707b885dfc4c  vmovaps [rsp+0x50], xmm5
0000707b885dfc52  vmovaps [rsp+0x60], xmm6
0000707b885dfc58  vmovaps [rsp+0x70], xmm7
0000707b885dfc5e  vmovaps [rsp+0x80], xmm8
0000707b885dfc67  vmovaps [rsp+0x90], xmm10
0000707b885dfc70  vmovaps [rsp+0xA0], xmm11
0000707b885dfc79  vmovaps [rsp+0xB0], xmm12
0000707b885dfc82  vmovaps [rsp+0xC0], xmm13
0000707b885dfc8b  vmovaps [rsp+0xD0], xmm14
0000707b885dfc94  vmovaps [rsp+0xE0], xmm15
0000707b885dfc9d  sub rsp, 0x30
0000707b885dfca1  movaps [rsp], xmm9
0000707b885dfca6  movaps [rsp+0x10], xmm8
0000707b885dfcac  movaps [rsp+0x20], xmm11
0000707b885dfcb2  lea rdi, [rsp]
0000707b885dfcb6  mov esi, 0x00
0000707b885dfcbb  mov rax, 0x6471B35AC530
0000707b885dfcc5  call rax
0000707b885dfcc7  movaps xmm9, [rsp]
0000707b885dfccc  add rsp, 0x30
0000707b885dfcd0  vmovaps xmm0, [rsp]
0000707b885dfcd5  vmovaps xmm1, [rsp+0x10]
0000707b885dfcdb  vmovaps xmm2, [rsp+0x20]
0000707b885dfce1  vmovaps xmm3, [rsp+0x30]
0000707b885dfce7  vmovaps xmm4, [rsp+0x40]
0000707b885dfced  vmovaps xmm5, [rsp+0x50]
0000707b885dfcf3  vmovaps xmm6, [rsp+0x60]
0000707b885dfcf9  vmovaps xmm7, [rsp+0x70]
0000707b885dfcff  vmovaps xmm8, [rsp+0x80]
0000707b885dfd08  vmovaps xmm10, [rsp+0x90]
0000707b885dfd11  vmovaps xmm11, [rsp+0xA0]
0000707b885dfd1a  vmovaps xmm12, [rsp+0xB0]
0000707b885dfd23  vmovaps xmm13, [rsp+0xC0]
0000707b885dfd2c  vmovaps xmm14, [rsp+0xD0]
0000707b885dfd35  vmovaps xmm15, [rsp+0xE0]
0000707b885dfd3e  add rsp, 0xF0
0000707b885dfd45  pop r11
0000707b885dfd47  pop r10
0000707b885dfd49  pop r9
0000707b885dfd4b  pop r8
0000707b885dfd4d  pop rsi
0000707b885dfd4e  pop rdi
0000707b885dfd4f  pop rdx
0000707b885dfd50  pop rcx
0000707b885dfd51  pop rax
0000707b885dfd52  add rsp, 0x08
0000707b885dfd56  jmp 0x0000707B885DC505
0000707b885dfd5b  sub rsp, 0x08
0000707b885dfd5f  push rax
0000707b885dfd60  push rcx
0000707b885dfd61  push rdx
0000707b885dfd62  push rdi
0000707b885dfd63  push rsi
0000707b885dfd64  push r8
0000707b885dfd66  push r9
0000707b885dfd68  push r10
0000707b885dfd6a  push r11
0000707b885dfd6c  sub rsp, 0xF0
0000707b885dfd73  vmovaps [rsp], xmm0
0000707b885dfd78  vmovaps [rsp+0x10], xmm1
0000707b885dfd7e  vmovaps [rsp+0x20], xmm2
0000707b885dfd84  vmovaps [rsp+0x30], xmm3
0000707b885dfd8a  vmovaps [rsp+0x40], xmm4
0000707b885dfd90  vmovaps [rsp+0x50], xmm5
0000707b885dfd96  vmovaps [rsp+0x60], xmm6
0000707b885dfd9c  vmovaps [rsp+0x70], xmm7
0000707b885dfda2  vmovaps [rsp+0x80], xmm8
0000707b885dfdab  vmovaps [rsp+0x90], xmm9
0000707b885dfdb4  vmovaps [rsp+0xA0], xmm10
0000707b885dfdbd  vmovaps [rsp+0xB0], xmm12
0000707b885dfdc6  vmovaps [rsp+0xC0], xmm13
0000707b885dfdcf  vmovaps [rsp+0xD0], xmm14
0000707b885dfdd8  vmovaps [rsp+0xE0], xmm15
0000707b885dfde1  sub rsp, 0x30
0000707b885dfde5  movaps [rsp], xmm11
0000707b885dfdea  movaps [rsp+0x10], xmm10
0000707b885dfdf0  movaps [rsp+0x20], xmm6
0000707b885dfdf5  lea rdi, [rsp]
0000707b885dfdf9  mov esi, 0x00
0000707b885dfdfe  mov rax, 0x6471B35AC530
0000707b885dfe08  call rax
0000707b885dfe0a  movaps xmm11, [rsp]
0000707b885dfe0f  add rsp, 0x30
0000707b885dfe13  vmovaps xmm0, [rsp]
0000707b885dfe18  vmovaps xmm1, [rsp+0x10]
0000707b885dfe1e  vmovaps xmm2, [rsp+0x20]
0000707b885dfe24  vmovaps xmm3, [rsp+0x30]
0000707b885dfe2a  vmovaps xmm4, [rsp+0x40]
0000707b885dfe30  vmovaps xmm5, [rsp+0x50]
0000707b885dfe36  vmovaps xmm6, [rsp+0x60]
0000707b885dfe3c  vmovaps xmm7, [rsp+0x70]
0000707b885dfe42  vmovaps xmm8, [rsp+0x80]
0000707b885dfe4b  vmovaps xmm9, [rsp+0x90]
0000707b885dfe54  vmovaps xmm10, [rsp+0xA0]
0000707b885dfe5d  vmovaps xmm12, [rsp+0xB0]
0000707b885dfe66  vmovaps xmm13, [rsp+0xC0]
0000707b885dfe6f  vmovaps xmm14, [rsp+0xD0]
0000707b885dfe78  vmovaps xmm15, [rsp+0xE0]
0000707b885dfe81  add rsp, 0xF0
0000707b885dfe88  pop r11
0000707b885dfe8a  pop r10
0000707b885dfe8c  pop r9
0000707b885dfe8e  pop r8
0000707b885dfe90  pop rsi
0000707b885dfe91  pop rdi
0000707b885dfe92  pop rdx
0000707b885dfe93  pop rcx
0000707b885dfe94  pop rax
0000707b885dfe95  add rsp, 0x08
0000707b885dfe99  jmp 0x0000707B885DC520
0000707b885dfe9e  sub rsp, 0x08
0000707b885dfea2  push rax
0000707b885dfea3  push rcx
0000707b885dfea4  push rdx
0000707b885dfea5  push rdi
0000707b885dfea6  push rsi
0000707b885dfea7  push r8
0000707b885dfea9  push r9
0000707b885dfeab  push r10
0000707b885dfead  push r11
0000707b885dfeaf  sub rsp, 0xF0
0000707b885dfeb6  vmovaps [rsp], xmm0
0000707b885dfebb  vmovaps [rsp+0x10], xmm1
0000707b885dfec1  vmovaps [rsp+0x20], xmm2
0000707b885dfec7  vmovaps [rsp+0x30], xmm3
0000707b885dfecd  vmovaps [rsp+0x40], xmm4
0000707b885dfed3  vmovaps [rsp+0x50], xmm5
0000707b885dfed9  vmovaps [rsp+0x60], xmm6
0000707b885dfedf  vmovaps [rsp+0x70], xmm7
0000707b885dfee5  vmovaps [rsp+0x80], xmm8
0000707b885dfeee  vmovaps [rsp+0x90], xmm9
0000707b885dfef7  vmovaps [rsp+0xA0], xmm11
0000707b885dff00  vmovaps [rsp+0xB0], xmm12
0000707b885dff09  vmovaps [rsp+0xC0], xmm13
0000707b885dff12  vmovaps [rsp+0xD0], xmm14
0000707b885dff1b  vmovaps [rsp+0xE0], xmm15
0000707b885dff24  sub rsp, 0x30
0000707b885dff28  movaps [rsp], xmm10
0000707b885dff2d  movaps [rsp+0x10], xmm14
0000707b885dff33  movaps [rsp+0x20], xmm4
0000707b885dff38  lea rdi, [rsp]
0000707b885dff3c  mov esi, 0x00
0000707b885dff41  mov rax, 0x6471B35AC530
0000707b885dff4b  call rax
0000707b885dff4d  movaps xmm10, [rsp]
0000707b885dff52  add rsp, 0x30
0000707b885dff56  vmovaps xmm0, [rsp]
0000707b885dff5b  vmovaps xmm1, [rsp+0x10]
0000707b885dff61  vmovaps xmm2, [rsp+0x20]
0000707b885dff67  vmovaps xmm3, [rsp+0x30]
0000707b885dff6d  vmovaps xmm4, [rsp+0x40]
0000707b885dff73  vmovaps xmm5, [rsp+0x50]
0000707b885dff79  vmovaps xmm6, [rsp+0x60]
0000707b885dff7f  vmovaps xmm7, [rsp+0x70]
0000707b885dff85  vmovaps xmm8, [rsp+0x80]
0000707b885dff8e  vmovaps xmm9, [rsp+0x90]
0000707b885dff97  vmovaps xmm11, [rsp+0xA0]
0000707b885dffa0  vmovaps xmm12, [rsp+0xB0]
0000707b885dffa9  vmovaps xmm13, [rsp+0xC0]
0000707b885dffb2  vmovaps xmm14, [rsp+0xD0]
0000707b885dffbb  vmovaps xmm15, [rsp+0xE0]
0000707b885dffc4  add rsp, 0xF0
0000707b885dffcb  pop r11
0000707b885dffcd  pop r10
0000707b885dffcf  pop r9
0000707b885dffd1  pop r8
0000707b885dffd3  pop rsi
0000707b885dffd4  pop rdi
0000707b885dffd5  pop rdx
0000707b885dffd6  pop rcx
0000707b885dffd7  pop rax
0000707b885dffd8  add rsp, 0x08
0000707b885dffdc  jmp 0x0000707B885DC53B
0000707b885dffe1  sub rsp, 0x08
0000707b885dffe5  push rax
0000707b885dffe6  push rcx
0000707b885dffe7  push rdx
0000707b885dffe8  push rdi
0000707b885dffe9  push rsi
0000707b885dffea  push r8
0000707b885dffec  push r9
0000707b885dffee  push r10
0000707b885dfff0  push r11
0000707b885dfff2  sub rsp, 0xF0
0000707b885dfff9  vmovaps [rsp], xmm0
0000707b885dfffe  vmovaps [rsp+0x10], xmm1
0000707b885e0004  vmovaps [rsp+0x20], xmm2
0000707b885e000a  vmovaps [rsp+0x30], xmm3
0000707b885e0010  vmovaps [rsp+0x40], xmm4
0000707b885e0016  vmovaps [rsp+0x50], xmm5
0000707b885e001c  vmovaps [rsp+0x60], xmm6
0000707b885e0022  vmovaps [rsp+0x70], xmm7
0000707b885e0028  vmovaps [rsp+0x80], xmm9
0000707b885e0031  vmovaps [rsp+0x90], xmm10
0000707b885e003a  vmovaps [rsp+0xA0], xmm11
0000707b885e0043  vmovaps [rsp+0xB0], xmm12
0000707b885e004c  vmovaps [rsp+0xC0], xmm13
0000707b885e0055  vmovaps [rsp+0xD0], xmm14
0000707b885e005e  vmovaps [rsp+0xE0], xmm15
0000707b885e0067  sub rsp, 0x30
0000707b885e006b  movaps [rsp], xmm8
0000707b885e0070  movaps [rsp+0x10], xmm1
0000707b885e0075  movaps [rsp+0x20], xmm14
0000707b885e007b  lea rdi, [rsp]
0000707b885e007f  mov esi, 0x00
0000707b885e0084  mov rax, 0x6471B35AC530
0000707b885e008e  call rax
0000707b885e0090  movaps xmm8, [rsp]
0000707b885e0095  add rsp, 0x30
0000707b885e0099  vmovaps xmm0, [rsp]
0000707b885e009e  vmovaps xmm1, [rsp+0x10]
0000707b885e00a4  vmovaps xmm2, [rsp+0x20]
0000707b885e00aa  vmovaps xmm3, [rsp+0x30]
0000707b885e00b0  vmovaps xmm4, [rsp+0x40]
0000707b885e00b6  vmovaps xmm5, [rsp+0x50]
0000707b885e00bc  vmovaps xmm6, [rsp+0x60]
0000707b885e00c2  vmovaps xmm7, [rsp+0x70]
0000707b885e00c8  vmovaps xmm9, [rsp+0x80]
0000707b885e00d1  vmovaps xmm10, [rsp+0x90]
0000707b885e00da  vmovaps xmm11, [rsp+0xA0]
0000707b885e00e3  vmovaps xmm12, [rsp+0xB0]
0000707b885e00ec  vmovaps xmm13, [rsp+0xC0]
0000707b885e00f5  vmovaps xmm14, [rsp+0xD0]
0000707b885e00fe  vmovaps xmm15, [rsp+0xE0]
0000707b885e0107  add rsp, 0xF0
0000707b885e010e  pop r11
0000707b885e0110  pop r10
0000707b885e0112  pop r9
0000707b885e0114  pop r8
0000707b885e0116  pop rsi
0000707b885e0117  pop rdi
0000707b885e0118  pop rdx
0000707b885e0119  pop rcx
0000707b885e011a  pop rax
0000707b885e011b  add rsp, 0x08
0000707b885e011f  jmp 0x0000707B885DC561
0000707b885e0124  sub rsp, 0x08
0000707b885e0128  push rax
0000707b885e0129  push rcx
0000707b885e012a  push rdx
0000707b885e012b  push rdi
0000707b885e012c  push rsi
0000707b885e012d  push r8
0000707b885e012f  push r9
0000707b885e0131  push r10
0000707b885e0133  push r11
0000707b885e0135  sub rsp, 0xF0
0000707b885e013c  vmovaps [rsp], xmm0
0000707b885e0141  vmovaps [rsp+0x10], xmm1
0000707b885e0147  vmovaps [rsp+0x20], xmm2
0000707b885e014d  vmovaps [rsp+0x30], xmm3
0000707b885e0153  vmovaps [rsp+0x40], xmm4
0000707b885e0159  vmovaps [rsp+0x50], xmm5
0000707b885e015f  vmovaps [rsp+0x60], xmm7
0000707b885e0165  vmovaps [rsp+0x70], xmm8
0000707b885e016b  vmovaps [rsp+0x80], xmm9
0000707b885e0174  vmovaps [rsp+0x90], xmm10
0000707b885e017d  vmovaps [rsp+0xA0], xmm11
0000707b885e0186  vmovaps [rsp+0xB0], xmm12
0000707b885e018f  vmovaps [rsp+0xC0], xmm13
0000707b885e0198  vmovaps [rsp+0xD0], xmm14
0000707b885e01a1  vmovaps [rsp+0xE0], xmm15
0000707b885e01aa  sub rsp, 0x30
0000707b885e01ae  movaps [rsp], xmm6
0000707b885e01b2  movaps [rsp+0x10], xmm1
0000707b885e01b7  movaps [rsp+0x20], xmm14
0000707b885e01bd  lea rdi, [rsp]
0000707b885e01c1  mov esi, 0x00
0000707b885e01c6  mov rax, 0x6471B35AC530
0000707b885e01d0  call rax
0000707b885e01d2  movaps xmm6, [rsp]
0000707b885e01d6  add rsp, 0x30
0000707b885e01da  vmovaps xmm0, [rsp]
0000707b885e01df  vmovaps xmm1, [rsp+0x10]
0000707b885e01e5  vmovaps xmm2, [rsp+0x20]
0000707b885e01eb  vmovaps xmm3, [rsp+0x30]
0000707b885e01f1  vmovaps xmm4, [rsp+0x40]
0000707b885e01f7  vmovaps xmm5, [rsp+0x50]
0000707b885e01fd  vmovaps xmm7, [rsp+0x60]
0000707b885e0203  vmovaps xmm8, [rsp+0x70]
0000707b885e0209  vmovaps xmm9, [rsp+0x80]
0000707b885e0212  vmovaps xmm10, [rsp+0x90]
0000707b885e021b  vmovaps xmm11, [rsp+0xA0]
0000707b885e0224  vmovaps xmm12, [rsp+0xB0]
0000707b885e022d  vmovaps xmm13, [rsp+0xC0]
0000707b885e0236  vmovaps xmm14, [rsp+0xD0]
0000707b885e023f  vmovaps xmm15, [rsp+0xE0]
0000707b885e0248  add rsp, 0xF0
0000707b885e024f  pop r11
0000707b885e0251  pop r10
0000707b885e0253  pop r9
0000707b885e0255  pop r8
0000707b885e0257  pop rsi
0000707b885e0258  pop rdi
0000707b885e0259  pop rdx
0000707b885e025a  pop rcx
0000707b885e025b  pop rax
0000707b885e025c  add rsp, 0x08
0000707b885e0260  jmp 0x0000707B885DC58D
0000707b885e0265  sub rsp, 0x08
0000707b885e0269  push rax
0000707b885e026a  push rcx
0000707b885e026b  push rdx
0000707b885e026c  push rdi
0000707b885e026d  push rsi
0000707b885e026e  push r8
0000707b885e0270  push r9
0000707b885e0272  push r10
0000707b885e0274  push r11
0000707b885e0276  sub rsp, 0xF0
0000707b885e027d  vmovaps [rsp], xmm0
0000707b885e0282  vmovaps [rsp+0x10], xmm1
0000707b885e0288  vmovaps [rsp+0x20], xmm2
0000707b885e028e  vmovaps [rsp+0x30], xmm3
0000707b885e0294  vmovaps [rsp+0x40], xmm4
0000707b885e029a  vmovaps [rsp+0x50], xmm5
0000707b885e02a0  vmovaps [rsp+0x60], xmm6
0000707b885e02a6  vmovaps [rsp+0x70], xmm7
0000707b885e02ac  vmovaps [rsp+0x80], xmm8
0000707b885e02b5  vmovaps [rsp+0x90], xmm9
0000707b885e02be  vmovaps [rsp+0xA0], xmm10
0000707b885e02c7  vmovaps [rsp+0xB0], xmm11
0000707b885e02d0  vmovaps [rsp+0xC0], xmm12
0000707b885e02d9  vmovaps [rsp+0xD0], xmm13
0000707b885e02e2  vmovaps [rsp+0xE0], xmm15
0000707b885e02eb  sub rsp, 0x30
0000707b885e02ef  movaps [rsp], xmm14
0000707b885e02f4  movaps [rsp+0x10], xmm12
0000707b885e02fa  movaps [rsp+0x20], xmm1
0000707b885e02ff  lea rdi, [rsp]
0000707b885e0303  mov esi, 0x00
0000707b885e0308  mov rax, 0x6471B35AC530
0000707b885e0312  call rax
0000707b885e0314  movaps xmm14, [rsp]
0000707b885e0319  add rsp, 0x30
0000707b885e031d  vmovaps xmm0, [rsp]
0000707b885e0322  vmovaps xmm1, [rsp+0x10]
0000707b885e0328  vmovaps xmm2, [rsp+0x20]
0000707b885e032e  vmovaps xmm3, [rsp+0x30]
0000707b885e0334  vmovaps xmm4, [rsp+0x40]
0000707b885e033a  vmovaps xmm5, [rsp+0x50]
0000707b885e0340  vmovaps xmm6, [rsp+0x60]
0000707b885e0346  vmovaps xmm7, [rsp+0x70]
0000707b885e034c  vmovaps xmm8, [rsp+0x80]
0000707b885e0355  vmovaps xmm9, [rsp+0x90]
0000707b885e035e  vmovaps xmm10, [rsp+0xA0]
0000707b885e0367  vmovaps xmm11, [rsp+0xB0]
0000707b885e0370  vmovaps xmm12, [rsp+0xC0]
0000707b885e0379  vmovaps xmm13, [rsp+0xD0]
0000707b885e0382  vmovaps xmm15, [rsp+0xE0]
0000707b885e038b  add rsp, 0xF0
0000707b885e0392  pop r11
0000707b885e0394  pop r10
0000707b885e0396  pop r9
0000707b885e0398  pop r8
0000707b885e039a  pop rsi
0000707b885e039b  pop rdi
0000707b885e039c  pop rdx
0000707b885e039d  pop rcx
0000707b885e039e  pop rax
0000707b885e039f  add rsp, 0x08
0000707b885e03a3  jmp 0x0000707B885DC5B3
0000707b885e03a8  sub rsp, 0x08
0000707b885e03ac  push rax
0000707b885e03ad  push rcx
0000707b885e03ae  push rdx
0000707b885e03af  push rdi
0000707b885e03b0  push rsi
0000707b885e03b1  push r8
0000707b885e03b3  push r9
0000707b885e03b5  push r10
0000707b885e03b7  push r11
0000707b885e03b9  sub rsp, 0xF0
0000707b885e03c0  vmovaps [rsp], xmm0
0000707b885e03c5  vmovaps [rsp+0x10], xmm2
0000707b885e03cb  vmovaps [rsp+0x20], xmm3
0000707b885e03d1  vmovaps [rsp+0x30], xmm4
0000707b885e03d7  vmovaps [rsp+0x40], xmm5
0000707b885e03dd  vmovaps [rsp+0x50], xmm6
0000707b885e03e3  vmovaps [rsp+0x60], xmm7
0000707b885e03e9  vmovaps [rsp+0x70], xmm8
0000707b885e03ef  vmovaps [rsp+0x80], xmm9
0000707b885e03f8  vmovaps [rsp+0x90], xmm10
0000707b885e0401  vmovaps [rsp+0xA0], xmm11
0000707b885e040a  vmovaps [rsp+0xB0], xmm12
0000707b885e0413  vmovaps [rsp+0xC0], xmm13
0000707b885e041c  vmovaps [rsp+0xD0], xmm14
0000707b885e0425  vmovaps [rsp+0xE0], xmm15
0000707b885e042e  sub rsp, 0x30
0000707b885e0432  movaps [rsp], xmm1
0000707b885e0436  movaps [rsp+0x10], xmm13
0000707b885e043c  movaps [rsp+0x20], xmm9
0000707b885e0442  lea rdi, [rsp]
0000707b885e0446  mov esi, 0x00
0000707b885e044b  mov rax, 0x6471B35AC530
0000707b885e0455  call rax
0000707b885e0457  movaps xmm1, [rsp]
0000707b885e045b  add rsp, 0x30
0000707b885e045f  vmovaps xmm0, [rsp]
0000707b885e0464  vmovaps xmm2, [rsp+0x10]
0000707b885e046a  vmovaps xmm3, [rsp+0x20]
0000707b885e0470  vmovaps xmm4, [rsp+0x30]
0000707b885e0476  vmovaps xmm5, [rsp+0x40]
0000707b885e047c  vmovaps xmm6, [rsp+0x50]
0000707b885e0482  vmovaps xmm7, [rsp+0x60]
0000707b885e0488  vmovaps xmm8, [rsp+0x70]
0000707b885e048e  vmovaps xmm9, [rsp+0x80]
0000707b885e0497  vmovaps xmm10, [rsp+0x90]
0000707b885e04a0  vmovaps xmm11, [rsp+0xA0]
0000707b885e04a9  vmovaps xmm12, [rsp+0xB0]
0000707b885e04b2  vmovaps xmm13, [rsp+0xC0]
0000707b885e04bb  vmovaps xmm14, [rsp+0xD0]
0000707b885e04c4  vmovaps xmm15, [rsp+0xE0]
0000707b885e04cd  add rsp, 0xF0
0000707b885e04d4  pop r11
0000707b885e04d6  pop r10
0000707b885e04d8  pop r9
0000707b885e04da  pop r8
0000707b885e04dc  pop rsi
0000707b885e04dd  pop rdi
0000707b885e04de  pop rdx
0000707b885e04df  pop rcx
0000707b885e04e0  pop rax
0000707b885e04e1  add rsp, 0x08
0000707b885e04e5  jmp 0x0000707B885DC5CD
0000707b885e04ea  sub rsp, 0x08
0000707b885e04ee  push rax
0000707b885e04ef  push rcx
0000707b885e04f0  push rdx
0000707b885e04f1  push rdi
0000707b885e04f2  push rsi
0000707b885e04f3  push r8
0000707b885e04f5  push r9
0000707b885e04f7  push r10
0000707b885e04f9  push r11
0000707b885e04fb  sub rsp, 0xF0
0000707b885e0502  vmovaps [rsp], xmm0
0000707b885e0507  vmovaps [rsp+0x10], xmm1
0000707b885e050d  vmovaps [rsp+0x20], xmm2
0000707b885e0513  vmovaps [rsp+0x30], xmm3
0000707b885e0519  vmovaps [rsp+0x40], xmm4
0000707b885e051f  vmovaps [rsp+0x50], xmm5
0000707b885e0525  vmovaps [rsp+0x60], xmm6
0000707b885e052b  vmovaps [rsp+0x70], xmm7
0000707b885e0531  vmovaps [rsp+0x80], xmm8
0000707b885e053a  vmovaps [rsp+0x90], xmm9
0000707b885e0543  vmovaps [rsp+0xA0], xmm10
0000707b885e054c  vmovaps [rsp+0xB0], xmm11
0000707b885e0555  vmovaps [rsp+0xC0], xmm13
0000707b885e055e  vmovaps [rsp+0xD0], xmm14
0000707b885e0567  vmovaps [rsp+0xE0], xmm15
0000707b885e0570  sub rsp, 0x30
0000707b885e0574  movaps [rsp], xmm12
0000707b885e0579  movaps [rsp+0x10], xmm7
0000707b885e057e  movaps [rsp+0x20], xmm13
0000707b885e0584  lea rdi, [rsp]
0000707b885e0588  mov esi, 0x00
0000707b885e058d  mov rax, 0x6471B35AC530
0000707b885e0597  call rax
0000707b885e0599  movaps xmm12, [rsp]
0000707b885e059e  add rsp, 0x30
0000707b885e05a2  vmovaps xmm0, [rsp]
0000707b885e05a7  vmovaps xmm1, [rsp+0x10]
0000707b885e05ad  vmovaps xmm2, [rsp+0x20]
0000707b885e05b3  vmovaps xmm3, [rsp+0x30]
0000707b885e05b9  vmovaps xmm4, [rsp+0x40]
0000707b885e05bf  vmovaps xmm5, [rsp+0x50]
0000707b885e05c5  vmovaps xmm6, [rsp+0x60]
0000707b885e05cb  vmovaps xmm7, [rsp+0x70]
0000707b885e05d1  vmovaps xmm8, [rsp+0x80]
0000707b885e05da  vmovaps xmm9, [rsp+0x90]
0000707b885e05e3  vmovaps xmm10, [rsp+0xA0]
0000707b885e05ec  vmovaps xmm11, [rsp+0xB0]
0000707b885e05f5  vmovaps xmm13, [rsp+0xC0]
0000707b885e05fe  vmovaps xmm14, [rsp+0xD0]
0000707b885e0607  vmovaps xmm15, [rsp+0xE0]
0000707b885e0610  add rsp, 0xF0
0000707b885e0617  pop r11
0000707b885e0619  pop r10
0000707b885e061b  pop r9
0000707b885e061d  pop r8
0000707b885e061f  pop rsi
0000707b885e0620  pop rdi
0000707b885e0621  pop rdx
0000707b885e0622  pop rcx
0000707b885e0623  pop rax
0000707b885e0624  add rsp, 0x08
0000707b885e0628  jmp 0x0000707B885DC5F4
0000707b885e062d  sub rsp, 0x08
0000707b885e0631  push rax
0000707b885e0632  push rcx
0000707b885e0633  push rdx
0000707b885e0634  push rdi
0000707b885e0635  push rsi
0000707b885e0636  push r8
0000707b885e0638  push r9
0000707b885e063a  push r10
0000707b885e063c  push r11
0000707b885e063e  sub rsp, 0xF0
0000707b885e0645  vmovaps [rsp], xmm0
0000707b885e064a  vmovaps [rsp+0x10], xmm1
0000707b885e0650  vmovaps [rsp+0x20], xmm2
0000707b885e0656  vmovaps [rsp+0x30], xmm3
0000707b885e065c  vmovaps [rsp+0x40], xmm4
0000707b885e0662  vmovaps [rsp+0x50], xmm5
0000707b885e0668  vmovaps [rsp+0x60], xmm6
0000707b885e066e  vmovaps [rsp+0x70], xmm7
0000707b885e0674  vmovaps [rsp+0x80], xmm8
0000707b885e067d  vmovaps [rsp+0x90], xmm9
0000707b885e0686  vmovaps [rsp+0xA0], xmm10
0000707b885e068f  vmovaps [rsp+0xB0], xmm11
0000707b885e0698  vmovaps [rsp+0xC0], xmm12
0000707b885e06a1  vmovaps [rsp+0xD0], xmm14
0000707b885e06aa  vmovaps [rsp+0xE0], xmm15
0000707b885e06b3  sub rsp, 0x30
0000707b885e06b7  movaps [rsp], xmm13
0000707b885e06bc  movaps [rsp+0x10], xmm15
0000707b885e06c2  movaps [rsp+0x20], xmm8
0000707b885e06c8  lea rdi, [rsp]
0000707b885e06cc  mov esi, 0x00
0000707b885e06d1  mov rax, 0x6471B35AC530
0000707b885e06db  call rax
0000707b885e06dd  movaps xmm13, [rsp]
0000707b885e06e2  add rsp, 0x30
0000707b885e06e6  vmovaps xmm0, [rsp]
0000707b885e06eb  vmovaps xmm1, [rsp+0x10]
0000707b885e06f1  vmovaps xmm2, [rsp+0x20]
0000707b885e06f7  vmovaps xmm3, [rsp+0x30]
0000707b885e06fd  vmovaps xmm4, [rsp+0x40]
0000707b885e0703  vmovaps xmm5, [rsp+0x50]
0000707b885e0709  vmovaps xmm6, [rsp+0x60]
0000707b885e070f  vmovaps xmm7, [rsp+0x70]
0000707b885e0715  vmovaps xmm8, [rsp+0x80]
0000707b885e071e  vmovaps xmm9, [rsp+0x90]
0000707b885e0727  vmovaps xmm10, [rsp+0xA0]
0000707b885e0730  vmovaps xmm11, [rsp+0xB0]
0000707b885e0739  vmovaps xmm12, [rsp+0xC0]
0000707b885e0742  vmovaps xmm14, [rsp+0xD0]
0000707b885e074b  vmovaps xmm15, [rsp+0xE0]
0000707b885e0754  add rsp, 0xF0
0000707b885e075b  pop r11
0000707b885e075d  pop r10
0000707b885e075f  pop r9
0000707b885e0761  pop r8
0000707b885e0763  pop rsi
0000707b885e0764  pop rdi
0000707b885e0765  pop rdx
0000707b885e0766  pop rcx
0000707b885e0767  pop rax
0000707b885e0768  add rsp, 0x08
0000707b885e076c  jmp 0x0000707B885DC60F
0000707b885e0771  sub rsp, 0x08
0000707b885e0775  push rax
0000707b885e0776  push rcx
0000707b885e0777  push rdx
0000707b885e0778  push rdi
0000707b885e0779  push rsi
0000707b885e077a  push r8
0000707b885e077c  push r9
0000707b885e077e  push r10
0000707b885e0780  push r11
0000707b885e0782  sub rsp, 0xF0
0000707b885e0789  vmovaps [rsp], xmm0
0000707b885e078e  vmovaps [rsp+0x10], xmm1
0000707b885e0794  vmovaps [rsp+0x20], xmm2
0000707b885e079a  vmovaps [rsp+0x30], xmm3
0000707b885e07a0  vmovaps [rsp+0x40], xmm4
0000707b885e07a6  vmovaps [rsp+0x50], xmm5
0000707b885e07ac  vmovaps [rsp+0x60], xmm6
0000707b885e07b2  vmovaps [rsp+0x70], xmm7
0000707b885e07b8  vmovaps [rsp+0x80], xmm9
0000707b885e07c1  vmovaps [rsp+0x90], xmm10
0000707b885e07ca  vmovaps [rsp+0xA0], xmm11
0000707b885e07d3  vmovaps [rsp+0xB0], xmm12
0000707b885e07dc  vmovaps [rsp+0xC0], xmm13
0000707b885e07e5  vmovaps [rsp+0xD0], xmm14
0000707b885e07ee  vmovaps [rsp+0xE0], xmm15
0000707b885e07f7  sub rsp, 0x30
0000707b885e07fb  movaps [rsp], xmm8
0000707b885e0800  movaps [rsp+0x10], xmm15
0000707b885e0806  movaps [rsp+0x20], xmm9
0000707b885e080c  lea rdi, [rsp]
0000707b885e0810  mov esi, 0x00
0000707b885e0815  mov rax, 0x6471B35AC530
0000707b885e081f  call rax
0000707b885e0821  movaps xmm8, [rsp]
0000707b885e0826  add rsp, 0x30
0000707b885e082a  vmovaps xmm0, [rsp]
0000707b885e082f  vmovaps xmm1, [rsp+0x10]
0000707b885e0835  vmovaps xmm2, [rsp+0x20]
0000707b885e083b  vmovaps xmm3, [rsp+0x30]
0000707b885e0841  vmovaps xmm4, [rsp+0x40]
0000707b885e0847  vmovaps xmm5, [rsp+0x50]
0000707b885e084d  vmovaps xmm6, [rsp+0x60]
0000707b885e0853  vmovaps xmm7, [rsp+0x70]
0000707b885e0859  vmovaps xmm9, [rsp+0x80]
0000707b885e0862  vmovaps xmm10, [rsp+0x90]
0000707b885e086b  vmovaps xmm11, [rsp+0xA0]
0000707b885e0874  vmovaps xmm12, [rsp+0xB0]
0000707b885e087d  vmovaps xmm13, [rsp+0xC0]
0000707b885e0886  vmovaps xmm14, [rsp+0xD0]
0000707b885e088f  vmovaps xmm15, [rsp+0xE0]
0000707b885e0898  add rsp, 0xF0
0000707b885e089f  pop r11
0000707b885e08a1  pop r10
0000707b885e08a3  pop r9
0000707b885e08a5  pop r8
0000707b885e08a7  pop rsi
0000707b885e08a8  pop rdi
0000707b885e08a9  pop rdx
0000707b885e08aa  pop rcx
0000707b885e08ab  pop rax
0000707b885e08ac  add rsp, 0x08
0000707b885e08b0  jmp 0x0000707B885DC63D
0000707b885e08b5  sub rsp, 0x08
0000707b885e08b9  push rax
0000707b885e08ba  push rcx
0000707b885e08bb  push rdx
0000707b885e08bc  push rdi
0000707b885e08bd  push rsi
0000707b885e08be  push r8
0000707b885e08c0  push r9
0000707b885e08c2  push r10
0000707b885e08c4  push r11
0000707b885e08c6  sub rsp, 0xF0
0000707b885e08cd  vmovaps [rsp], xmm0
0000707b885e08d2  vmovaps [rsp+0x10], xmm1
0000707b885e08d8  vmovaps [rsp+0x20], xmm2
0000707b885e08de  vmovaps [rsp+0x30], xmm3
0000707b885e08e4  vmovaps [rsp+0x40], xmm4
0000707b885e08ea  vmovaps [rsp+0x50], xmm5
0000707b885e08f0  vmovaps [rsp+0x60], xmm6
0000707b885e08f6  vmovaps [rsp+0x70], xmm7
0000707b885e08fc  vmovaps [rsp+0x80], xmm8
0000707b885e0905  vmovaps [rsp+0x90], xmm9
0000707b885e090e  vmovaps [rsp+0xA0], xmm10
0000707b885e0917  vmovaps [rsp+0xB0], xmm11
0000707b885e0920  vmovaps [rsp+0xC0], xmm12
0000707b885e0929  vmovaps [rsp+0xD0], xmm13
0000707b885e0932  vmovaps [rsp+0xE0], xmm14
0000707b885e093b  sub rsp, 0x30
0000707b885e093f  movaps [rsp], xmm15
0000707b885e0944  movaps [rsp+0x10], xmm11
0000707b885e094a  movaps [rsp+0x20], xmm6
0000707b885e094f  lea rdi, [rsp]
0000707b885e0953  mov esi, 0x00
0000707b885e0958  mov rax, 0x6471B35AC530
0000707b885e0962  call rax
0000707b885e0964  movaps xmm15, [rsp]
0000707b885e0969  add rsp, 0x30
0000707b885e096d  vmovaps xmm0, [rsp]
0000707b885e0972  vmovaps xmm1, [rsp+0x10]
0000707b885e0978  vmovaps xmm2, [rsp+0x20]
0000707b885e097e  vmovaps xmm3, [rsp+0x30]
0000707b885e0984  vmovaps xmm4, [rsp+0x40]
0000707b885e098a  vmovaps xmm5, [rsp+0x50]
0000707b885e0990  vmovaps xmm6, [rsp+0x60]
0000707b885e0996  vmovaps xmm7, [rsp+0x70]
0000707b885e099c  vmovaps xmm8, [rsp+0x80]
0000707b885e09a5  vmovaps xmm9, [rsp+0x90]
0000707b885e09ae  vmovaps xmm10, [rsp+0xA0]
0000707b885e09b7  vmovaps xmm11, [rsp+0xB0]
0000707b885e09c0  vmovaps xmm12, [rsp+0xC0]
0000707b885e09c9  vmovaps xmm13, [rsp+0xD0]
0000707b885e09d2  vmovaps xmm14, [rsp+0xE0]
0000707b885e09db  add rsp, 0xF0
0000707b885e09e2  pop r11
0000707b885e09e4  pop r10
0000707b885e09e6  pop r9
0000707b885e09e8  pop r8
0000707b885e09ea  pop rsi
0000707b885e09eb  pop rdi
0000707b885e09ec  pop rdx
0000707b885e09ed  pop rcx
0000707b885e09ee  pop rax
0000707b885e09ef  add rsp, 0x08
0000707b885e09f3  jmp 0x0000707B885DC658
0000707b885e09f8  sub rsp, 0x08
0000707b885e09fc  push rax
0000707b885e09fd  push rcx
0000707b885e09fe  push rdx
0000707b885e09ff  push rdi
0000707b885e0a00  push rsi
0000707b885e0a01  push r8
0000707b885e0a03  push r9
0000707b885e0a05  push r10
0000707b885e0a07  push r11
0000707b885e0a09  sub rsp, 0xF0
0000707b885e0a10  vmovaps [rsp], xmm0
0000707b885e0a15  vmovaps [rsp+0x10], xmm1
0000707b885e0a1b  vmovaps [rsp+0x20], xmm2
0000707b885e0a21  vmovaps [rsp+0x30], xmm3
0000707b885e0a27  vmovaps [rsp+0x40], xmm4
0000707b885e0a2d  vmovaps [rsp+0x50], xmm5
0000707b885e0a33  vmovaps [rsp+0x60], xmm6
0000707b885e0a39  vmovaps [rsp+0x70], xmm8
0000707b885e0a3f  vmovaps [rsp+0x80], xmm9
0000707b885e0a48  vmovaps [rsp+0x90], xmm10
0000707b885e0a51  vmovaps [rsp+0xA0], xmm11
0000707b885e0a5a  vmovaps [rsp+0xB0], xmm12
0000707b885e0a63  vmovaps [rsp+0xC0], xmm13
0000707b885e0a6c  vmovaps [rsp+0xD0], xmm14
0000707b885e0a75  vmovaps [rsp+0xE0], xmm15
0000707b885e0a7e  sub rsp, 0x30
0000707b885e0a82  movaps [rsp], xmm7
0000707b885e0a86  movaps [rsp+0x10], xmm11
0000707b885e0a8c  movaps [rsp+0x20], xmm9
0000707b885e0a92  lea rdi, [rsp]
0000707b885e0a96  mov esi, 0x00
0000707b885e0a9b  mov rax, 0x6471B35AC530
0000707b885e0aa5  call rax
0000707b885e0aa7  movaps xmm7, [rsp]
0000707b885e0aab  add rsp, 0x30
0000707b885e0aaf  vmovaps xmm0, [rsp]
0000707b885e0ab4  vmovaps xmm1, [rsp+0x10]
0000707b885e0aba  vmovaps xmm2, [rsp+0x20]
0000707b885e0ac0  vmovaps xmm3, [rsp+0x30]
0000707b885e0ac6  vmovaps xmm4, [rsp+0x40]
0000707b885e0acc  vmovaps xmm5, [rsp+0x50]
0000707b885e0ad2  vmovaps xmm6, [rsp+0x60]
0000707b885e0ad8  vmovaps xmm8, [rsp+0x70]
0000707b885e0ade  vmovaps xmm9, [rsp+0x80]
0000707b885e0ae7  vmovaps xmm10, [rsp+0x90]
0000707b885e0af0  vmovaps xmm11, [rsp+0xA0]
0000707b885e0af9  vmovaps xmm12, [rsp+0xB0]
0000707b885e0b02  vmovaps xmm13, [rsp+0xC0]
0000707b885e0b0b  vmovaps xmm14, [rsp+0xD0]
0000707b885e0b14  vmovaps xmm15, [rsp+0xE0]
0000707b885e0b1d  add rsp, 0xF0
0000707b885e0b24  pop r11
0000707b885e0b26  pop r10
0000707b885e0b28  pop r9
0000707b885e0b2a  pop r8
0000707b885e0b2c  pop rsi
0000707b885e0b2d  pop rdi
0000707b885e0b2e  pop rdx
0000707b885e0b2f  pop rcx
0000707b885e0b30  pop rax
0000707b885e0b31  add rsp, 0x08
0000707b885e0b35  jmp 0x0000707B885DC685
0000707b885e0b3a  sub rsp, 0x08
0000707b885e0b3e  push rax
0000707b885e0b3f  push rcx
0000707b885e0b40  push rdx
0000707b885e0b41  push rdi
0000707b885e0b42  push rsi
0000707b885e0b43  push r8
0000707b885e0b45  push r9
0000707b885e0b47  push r10
0000707b885e0b49  push r11
0000707b885e0b4b  sub rsp, 0xF0
0000707b885e0b52  vmovaps [rsp], xmm0
0000707b885e0b57  vmovaps [rsp+0x10], xmm1
0000707b885e0b5d  vmovaps [rsp+0x20], xmm2
0000707b885e0b63  vmovaps [rsp+0x30], xmm3
0000707b885e0b69  vmovaps [rsp+0x40], xmm4
0000707b885e0b6f  vmovaps [rsp+0x50], xmm5
0000707b885e0b75  vmovaps [rsp+0x60], xmm6
0000707b885e0b7b  vmovaps [rsp+0x70], xmm7
0000707b885e0b81  vmovaps [rsp+0x80], xmm8
0000707b885e0b8a  vmovaps [rsp+0x90], xmm9
0000707b885e0b93  vmovaps [rsp+0xA0], xmm10
0000707b885e0b9c  vmovaps [rsp+0xB0], xmm12
0000707b885e0ba5  vmovaps [rsp+0xC0], xmm13
0000707b885e0bae  vmovaps [rsp+0xD0], xmm14
0000707b885e0bb7  vmovaps [rsp+0xE0], xmm15
0000707b885e0bc0  sub rsp, 0x30
0000707b885e0bc4  movaps [rsp], xmm11
0000707b885e0bc9  movaps [rsp+0x10], xmm10
0000707b885e0bcf  movaps [rsp+0x20], xmm14
0000707b885e0bd5  lea rdi, [rsp]
0000707b885e0bd9  mov esi, 0x00
0000707b885e0bde  mov rax, 0x6471B35AC530
0000707b885e0be8  call rax
0000707b885e0bea  movaps xmm11, [rsp]
0000707b885e0bef  add rsp, 0x30
0000707b885e0bf3  vmovaps xmm0, [rsp]
0000707b885e0bf8  vmovaps xmm1, [rsp+0x10]
0000707b885e0bfe  vmovaps xmm2, [rsp+0x20]
0000707b885e0c04  vmovaps xmm3, [rsp+0x30]
0000707b885e0c0a  vmovaps xmm4, [rsp+0x40]
0000707b885e0c10  vmovaps xmm5, [rsp+0x50]
0000707b885e0c16  vmovaps xmm6, [rsp+0x60]
0000707b885e0c1c  vmovaps xmm7, [rsp+0x70]
0000707b885e0c22  vmovaps xmm8, [rsp+0x80]
0000707b885e0c2b  vmovaps xmm9, [rsp+0x90]
0000707b885e0c34  vmovaps xmm10, [rsp+0xA0]
0000707b885e0c3d  vmovaps xmm12, [rsp+0xB0]
0000707b885e0c46  vmovaps xmm13, [rsp+0xC0]
0000707b885e0c4f  vmovaps xmm14, [rsp+0xD0]
0000707b885e0c58  vmovaps xmm15, [rsp+0xE0]
0000707b885e0c61  add rsp, 0xF0
0000707b885e0c68  pop r11
0000707b885e0c6a  pop r10
0000707b885e0c6c  pop r9
0000707b885e0c6e  pop r8
0000707b885e0c70  pop rsi
0000707b885e0c71  pop rdi
0000707b885e0c72  pop rdx
0000707b885e0c73  pop rcx
0000707b885e0c74  pop rax
0000707b885e0c75  add rsp, 0x08
0000707b885e0c79  jmp 0x0000707B885DC6A0
0000707b885e0c7e  call 0x0000707B884C33A0
0000707b885e0c83  jmp 0x0000707B885DC6AA
0000707b885e0c88  sub rsp, 0x08
0000707b885e0c8c  push rax
0000707b885e0c8d  push rcx
0000707b885e0c8e  push rdx
0000707b885e0c8f  push rdi
0000707b885e0c90  push rsi
0000707b885e0c91  push r8
0000707b885e0c93  push r9
0000707b885e0c95  push r10
0000707b885e0c97  push r11
0000707b885e0c99  sub rsp, 0xF0
0000707b885e0ca0  vmovaps [rsp], xmm0
0000707b885e0ca5  vmovaps [rsp+0x10], xmm1
0000707b885e0cab  vmovaps [rsp+0x20], xmm2
0000707b885e0cb1  vmovaps [rsp+0x30], xmm3
0000707b885e0cb7  vmovaps [rsp+0x40], xmm4
0000707b885e0cbd  vmovaps [rsp+0x50], xmm5
0000707b885e0cc3  vmovaps [rsp+0x60], xmm6
0000707b885e0cc9  vmovaps [rsp+0x70], xmm7
0000707b885e0ccf  vmovaps [rsp+0x80], xmm8
0000707b885e0cd8  vmovaps [rsp+0x90], xmm9
0000707b885e0ce1  vmovaps [rsp+0xA0], xmm11
0000707b885e0cea  vmovaps [rsp+0xB0], xmm12
0000707b885e0cf3  vmovaps [rsp+0xC0], xmm13
0000707b885e0cfc  vmovaps [rsp+0xD0], xmm14
0000707b885e0d05  vmovaps [rsp+0xE0], xmm15
0000707b885e0d0e  sub rsp, 0x30
0000707b885e0d12  movaps [rsp], xmm10
0000707b885e0d17  movaps [rsp+0x10], xmm1
0000707b885e0d1c  movaps [rsp+0x20], xmm12
0000707b885e0d22  lea rdi, [rsp]
0000707b885e0d26  mov esi, 0x00
0000707b885e0d2b  mov rax, 0x6471B35AC530
0000707b885e0d35  call rax
0000707b885e0d37  movaps xmm10, [rsp]
0000707b885e0d3c  add rsp, 0x30
0000707b885e0d40  vmovaps xmm0, [rsp]
0000707b885e0d45  vmovaps xmm1, [rsp+0x10]
0000707b885e0d4b  vmovaps xmm2, [rsp+0x20]
0000707b885e0d51  vmovaps xmm3, [rsp+0x30]
0000707b885e0d57  vmovaps xmm4, [rsp+0x40]
0000707b885e0d5d  vmovaps xmm5, [rsp+0x50]
0000707b885e0d63  vmovaps xmm6, [rsp+0x60]
0000707b885e0d69  vmovaps xmm7, [rsp+0x70]
0000707b885e0d6f  vmovaps xmm8, [rsp+0x80]
0000707b885e0d78  vmovaps xmm9, [rsp+0x90]
0000707b885e0d81  vmovaps xmm11, [rsp+0xA0]
0000707b885e0d8a  vmovaps xmm12, [rsp+0xB0]
0000707b885e0d93  vmovaps xmm13, [rsp+0xC0]
0000707b885e0d9c  vmovaps xmm14, [rsp+0xD0]
0000707b885e0da5  vmovaps xmm15, [rsp+0xE0]
0000707b885e0dae  add rsp, 0xF0
0000707b885e0db5  pop r11
0000707b885e0db7  pop r10
0000707b885e0db9  pop r9
0000707b885e0dbb  pop r8
0000707b885e0dbd  pop rsi
0000707b885e0dbe  pop rdi
0000707b885e0dbf  pop rdx
0000707b885e0dc0  pop rcx
0000707b885e0dc1  pop rax
0000707b885e0dc2  add rsp, 0x08
0000707b885e0dc6  jmp 0x0000707B885DC6CD
0000707b885e0dcb  sub rsp, 0x08
0000707b885e0dcf  push rax
0000707b885e0dd0  push rcx
0000707b885e0dd1  push rdx
0000707b885e0dd2  push rdi
0000707b885e0dd3  push rsi
0000707b885e0dd4  push r8
0000707b885e0dd6  push r9
0000707b885e0dd8  push r10
0000707b885e0dda  push r11
0000707b885e0ddc  sub rsp, 0xF0
0000707b885e0de3  vmovaps [rsp], xmm0
0000707b885e0de8  vmovaps [rsp+0x10], xmm1
0000707b885e0dee  vmovaps [rsp+0x20], xmm2
0000707b885e0df4  vmovaps [rsp+0x30], xmm3
0000707b885e0dfa  vmovaps [rsp+0x40], xmm4
0000707b885e0e00  vmovaps [rsp+0x50], xmm5
0000707b885e0e06  vmovaps [rsp+0x60], xmm6
0000707b885e0e0c  vmovaps [rsp+0x70], xmm7
0000707b885e0e12  vmovaps [rsp+0x80], xmm8
0000707b885e0e1b  vmovaps [rsp+0x90], xmm9
0000707b885e0e24  vmovaps [rsp+0xA0], xmm10
0000707b885e0e2d  vmovaps [rsp+0xB0], xmm11
0000707b885e0e36  vmovaps [rsp+0xC0], xmm13
0000707b885e0e3f  vmovaps [rsp+0xD0], xmm14
0000707b885e0e48  vmovaps [rsp+0xE0], xmm15
0000707b885e0e51  sub rsp, 0x30
0000707b885e0e55  movaps [rsp], xmm12
0000707b885e0e5a  movaps [rsp+0x10], xmm14
0000707b885e0e60  movaps [rsp+0x20], xmm1
0000707b885e0e65  lea rdi, [rsp]
0000707b885e0e69  mov esi, 0x00
0000707b885e0e6e  mov rax, 0x6471B35AC530
0000707b885e0e78  call rax
0000707b885e0e7a  movaps xmm12, [rsp]
0000707b885e0e7f  add rsp, 0x30
0000707b885e0e83  vmovaps xmm0, [rsp]
0000707b885e0e88  vmovaps xmm1, [rsp+0x10]
0000707b885e0e8e  vmovaps xmm2, [rsp+0x20]
0000707b885e0e94  vmovaps xmm3, [rsp+0x30]
0000707b885e0e9a  vmovaps xmm4, [rsp+0x40]
0000707b885e0ea0  vmovaps xmm5, [rsp+0x50]
0000707b885e0ea6  vmovaps xmm6, [rsp+0x60]
0000707b885e0eac  vmovaps xmm7, [rsp+0x70]
0000707b885e0eb2  vmovaps xmm8, [rsp+0x80]
0000707b885e0ebb  vmovaps xmm9, [rsp+0x90]
0000707b885e0ec4  vmovaps xmm10, [rsp+0xA0]
0000707b885e0ecd  vmovaps xmm11, [rsp+0xB0]
0000707b885e0ed6  vmovaps xmm13, [rsp+0xC0]
0000707b885e0edf  vmovaps xmm14, [rsp+0xD0]
0000707b885e0ee8  vmovaps xmm15, [rsp+0xE0]
0000707b885e0ef1  add rsp, 0xF0
0000707b885e0ef8  pop r11
0000707b885e0efa  pop r10
0000707b885e0efc  pop r9
0000707b885e0efe  pop r8
0000707b885e0f00  pop rsi
0000707b885e0f01  pop rdi
0000707b885e0f02  pop rdx
0000707b885e0f03  pop rcx
0000707b885e0f04  pop rax
0000707b885e0f05  add rsp, 0x08
0000707b885e0f09  jmp 0x0000707B885DC6FC
0000707b885e0f0e  sub rsp, 0x08
0000707b885e0f12  push rax
0000707b885e0f13  push rcx
0000707b885e0f14  push rdx
0000707b885e0f15  push rdi
0000707b885e0f16  push rsi
0000707b885e0f17  push r8
0000707b885e0f19  push r9
0000707b885e0f1b  push r10
0000707b885e0f1d  push r11
0000707b885e0f1f  sub rsp, 0xF0
0000707b885e0f26  vmovaps [rsp], xmm0
0000707b885e0f2b  vmovaps [rsp+0x10], xmm1
0000707b885e0f31  vmovaps [rsp+0x20], xmm2
0000707b885e0f37  vmovaps [rsp+0x30], xmm3
0000707b885e0f3d  vmovaps [rsp+0x40], xmm4
0000707b885e0f43  vmovaps [rsp+0x50], xmm5
0000707b885e0f49  vmovaps [rsp+0x60], xmm6
0000707b885e0f4f  vmovaps [rsp+0x70], xmm7
0000707b885e0f55  vmovaps [rsp+0x80], xmm8
0000707b885e0f5e  vmovaps [rsp+0x90], xmm9
0000707b885e0f67  vmovaps [rsp+0xA0], xmm10
0000707b885e0f70  vmovaps [rsp+0xB0], xmm11
0000707b885e0f79  vmovaps [rsp+0xC0], xmm12
0000707b885e0f82  vmovaps [rsp+0xD0], xmm13
0000707b885e0f8b  vmovaps [rsp+0xE0], xmm15
0000707b885e0f94  sub rsp, 0x30
0000707b885e0f98  movaps [rsp], xmm14
0000707b885e0f9d  movaps [rsp+0x10], xmm9
0000707b885e0fa3  movaps [rsp+0x20], xmm1
0000707b885e0fa8  lea rdi, [rsp]
0000707b885e0fac  mov esi, 0x00
0000707b885e0fb1  mov rax, 0x6471B35AC530
0000707b885e0fbb  call rax
0000707b885e0fbd  movaps xmm14, [rsp]
0000707b885e0fc2  add rsp, 0x30
0000707b885e0fc6  vmovaps xmm0, [rsp]
0000707b885e0fcb  vmovaps xmm1, [rsp+0x10]
0000707b885e0fd1  vmovaps xmm2, [rsp+0x20]
0000707b885e0fd7  vmovaps xmm3, [rsp+0x30]
0000707b885e0fdd  vmovaps xmm4, [rsp+0x40]
0000707b885e0fe3  vmovaps xmm5, [rsp+0x50]
0000707b885e0fe9  vmovaps xmm6, [rsp+0x60]
0000707b885e0fef  vmovaps xmm7, [rsp+0x70]
0000707b885e0ff5  vmovaps xmm8, [rsp+0x80]
0000707b885e0ffe  vmovaps xmm9, [rsp+0x90]
0000707b885e1007  vmovaps xmm10, [rsp+0xA0]
0000707b885e1010  vmovaps xmm11, [rsp+0xB0]
0000707b885e1019  vmovaps xmm12, [rsp+0xC0]
0000707b885e1022  vmovaps xmm13, [rsp+0xD0]
0000707b885e102b  vmovaps xmm15, [rsp+0xE0]
0000707b885e1034  add rsp, 0xF0
0000707b885e103b  pop r11
0000707b885e103d  pop r10
0000707b885e103f  pop r9
0000707b885e1041  pop r8
0000707b885e1043  pop rsi
0000707b885e1044  pop rdi
0000707b885e1045  pop rdx
0000707b885e1046  pop rcx
0000707b885e1047  pop rax
0000707b885e1048  add rsp, 0x08
0000707b885e104c  jmp 0x0000707B885DC72B
0000707b885e1051  sub rsp, 0x08
0000707b885e1055  push rax
0000707b885e1056  push rcx
0000707b885e1057  push rdx
0000707b885e1058  push rdi
0000707b885e1059  push rsi
0000707b885e105a  push r8
0000707b885e105c  push r9
0000707b885e105e  push r10
0000707b885e1060  push r11
0000707b885e1062  sub rsp, 0xF0
0000707b885e1069  vmovaps [rsp], xmm0
0000707b885e106e  vmovaps [rsp+0x10], xmm2
0000707b885e1074  vmovaps [rsp+0x20], xmm3
0000707b885e107a  vmovaps [rsp+0x30], xmm4
0000707b885e1080  vmovaps [rsp+0x40], xmm5
0000707b885e1086  vmovaps [rsp+0x50], xmm6
0000707b885e108c  vmovaps [rsp+0x60], xmm7
0000707b885e1092  vmovaps [rsp+0x70], xmm8
0000707b885e1098  vmovaps [rsp+0x80], xmm9
0000707b885e10a1  vmovaps [rsp+0x90], xmm10
0000707b885e10aa  vmovaps [rsp+0xA0], xmm11
0000707b885e10b3  vmovaps [rsp+0xB0], xmm12
0000707b885e10bc  vmovaps [rsp+0xC0], xmm13
0000707b885e10c5  vmovaps [rsp+0xD0], xmm14
0000707b885e10ce  vmovaps [rsp+0xE0], xmm15
0000707b885e10d7  sub rsp, 0x30
0000707b885e10db  movaps [rsp], xmm1
0000707b885e10df  movaps [rsp+0x10], xmm13
0000707b885e10e5  movaps [rsp+0x20], xmm8
0000707b885e10eb  lea rdi, [rsp]
0000707b885e10ef  mov esi, 0x00
0000707b885e10f4  mov rax, 0x6471B35AC530
0000707b885e10fe  call rax
0000707b885e1100  movaps xmm1, [rsp]
0000707b885e1104  add rsp, 0x30
0000707b885e1108  vmovaps xmm0, [rsp]
0000707b885e110d  vmovaps xmm2, [rsp+0x10]
0000707b885e1113  vmovaps xmm3, [rsp+0x20]
0000707b885e1119  vmovaps xmm4, [rsp+0x30]
0000707b885e111f  vmovaps xmm5, [rsp+0x40]
0000707b885e1125  vmovaps xmm6, [rsp+0x50]
0000707b885e112b  vmovaps xmm7, [rsp+0x60]
0000707b885e1131  vmovaps xmm8, [rsp+0x70]
0000707b885e1137  vmovaps xmm9, [rsp+0x80]
0000707b885e1140  vmovaps xmm10, [rsp+0x90]
0000707b885e1149  vmovaps xmm11, [rsp+0xA0]
0000707b885e1152  vmovaps xmm12, [rsp+0xB0]
0000707b885e115b  vmovaps xmm13, [rsp+0xC0]
0000707b885e1164  vmovaps xmm14, [rsp+0xD0]
0000707b885e116d  vmovaps xmm15, [rsp+0xE0]
0000707b885e1176  add rsp, 0xF0
0000707b885e117d  pop r11
0000707b885e117f  pop r10
0000707b885e1181  pop r9
0000707b885e1183  pop r8
0000707b885e1185  pop rsi
0000707b885e1186  pop rdi
0000707b885e1187  pop rdx
0000707b885e1188  pop rcx
0000707b885e1189  pop rax
0000707b885e118a  add rsp, 0x08
0000707b885e118e  jmp 0x0000707B885DC74D
0000707b885e1193  call 0x0000707B8840C260
0000707b885e1198  jmp 0x0000707B885DC75B
0000707b885e119d  call 0x0000707B884BD750
0000707b885e11a2  jmp 0x0000707B885DC765
0000707b885e11a7  sub rsp, 0x08
0000707b885e11ab  push rax
0000707b885e11ac  push rcx
0000707b885e11ad  push rdx
0000707b885e11ae  push rdi
0000707b885e11af  push rsi
0000707b885e11b0  push r8
0000707b885e11b2  push r9
0000707b885e11b4  push r10
0000707b885e11b6  push r11
0000707b885e11b8  sub rsp, 0xF0
0000707b885e11bf  vmovaps [rsp], xmm0
0000707b885e11c4  vmovaps [rsp+0x10], xmm1
0000707b885e11ca  vmovaps [rsp+0x20], xmm2
0000707b885e11d0  vmovaps [rsp+0x30], xmm3
0000707b885e11d6  vmovaps [rsp+0x40], xmm4
0000707b885e11dc  vmovaps [rsp+0x50], xmm5
0000707b885e11e2  vmovaps [rsp+0x60], xmm6
0000707b885e11e8  vmovaps [rsp+0x70], xmm7
0000707b885e11ee  vmovaps [rsp+0x80], xmm9
0000707b885e11f7  vmovaps [rsp+0x90], xmm10
0000707b885e1200  vmovaps [rsp+0xA0], xmm11
0000707b885e1209  vmovaps [rsp+0xB0], xmm12
0000707b885e1212  vmovaps [rsp+0xC0], xmm13
0000707b885e121b  vmovaps [rsp+0xD0], xmm14
0000707b885e1224  vmovaps [rsp+0xE0], xmm15
0000707b885e122d  sub rsp, 0x30
0000707b885e1231  movaps [rsp], xmm8
0000707b885e1236  movaps [rsp+0x10], xmm15
0000707b885e123c  movaps [rsp+0x20], xmm7
0000707b885e1241  lea rdi, [rsp]
0000707b885e1245  mov esi, 0x00
0000707b885e124a  mov rax, 0x6471B35AC530
0000707b885e1254  call rax
0000707b885e1256  movaps xmm8, [rsp]
0000707b885e125b  add rsp, 0x30
0000707b885e125f  vmovaps xmm0, [rsp]
0000707b885e1264  vmovaps xmm1, [rsp+0x10]
0000707b885e126a  vmovaps xmm2, [rsp+0x20]
0000707b885e1270  vmovaps xmm3, [rsp+0x30]
0000707b885e1276  vmovaps xmm4, [rsp+0x40]
0000707b885e127c  vmovaps xmm5, [rsp+0x50]
0000707b885e1282  vmovaps xmm6, [rsp+0x60]
0000707b885e1288  vmovaps xmm7, [rsp+0x70]
0000707b885e128e  vmovaps xmm9, [rsp+0x80]
0000707b885e1297  vmovaps xmm10, [rsp+0x90]
0000707b885e12a0  vmovaps xmm11, [rsp+0xA0]
0000707b885e12a9  vmovaps xmm12, [rsp+0xB0]
0000707b885e12b2  vmovaps xmm13, [rsp+0xC0]
0000707b885e12bb  vmovaps xmm14, [rsp+0xD0]
0000707b885e12c4  vmovaps xmm15, [rsp+0xE0]
0000707b885e12cd  add rsp, 0xF0
0000707b885e12d4  pop r11
0000707b885e12d6  pop r10
0000707b885e12d8  pop r9
0000707b885e12da  pop r8
0000707b885e12dc  pop rsi
0000707b885e12dd  pop rdi
0000707b885e12de  pop rdx
0000707b885e12df  pop rcx
0000707b885e12e0  pop rax
0000707b885e12e1  add rsp, 0x08
0000707b885e12e5  jmp 0x0000707B885DC787
0000707b885e12ea  sub rsp, 0x08
0000707b885e12ee  push rax
0000707b885e12ef  push rcx
0000707b885e12f0  push rdx
0000707b885e12f1  push rdi
0000707b885e12f2  push rsi
0000707b885e12f3  push r8
0000707b885e12f5  push r9
0000707b885e12f7  push r10
0000707b885e12f9  push r11
0000707b885e12fb  sub rsp, 0xF0
0000707b885e1302  vmovaps [rsp], xmm0
0000707b885e1307  vmovaps [rsp+0x10], xmm1
0000707b885e130d  vmovaps [rsp+0x20], xmm2
0000707b885e1313  vmovaps [rsp+0x30], xmm3
0000707b885e1319  vmovaps [rsp+0x40], xmm4
0000707b885e131f  vmovaps [rsp+0x50], xmm5
0000707b885e1325  vmovaps [rsp+0x60], xmm6
0000707b885e132b  vmovaps [rsp+0x70], xmm8
0000707b885e1331  vmovaps [rsp+0x80], xmm9
0000707b885e133a  vmovaps [rsp+0x90], xmm10
0000707b885e1343  vmovaps [rsp+0xA0], xmm11
0000707b885e134c  vmovaps [rsp+0xB0], xmm12
0000707b885e1355  vmovaps [rsp+0xC0], xmm13
0000707b885e135e  vmovaps [rsp+0xD0], xmm14
0000707b885e1367  vmovaps [rsp+0xE0], xmm15
0000707b885e1370  sub rsp, 0x30
0000707b885e1374  movaps [rsp], xmm7
0000707b885e1378  movaps [rsp+0x10], xmm9
0000707b885e137e  movaps [rsp+0x20], xmm15
0000707b885e1384  lea rdi, [rsp]
0000707b885e1388  mov esi, 0x00
0000707b885e138d  mov rax, 0x6471B35AC530
0000707b885e1397  call rax
0000707b885e1399  movaps xmm7, [rsp]
0000707b885e139d  add rsp, 0x30
0000707b885e13a1  vmovaps xmm0, [rsp]
0000707b885e13a6  vmovaps xmm1, [rsp+0x10]
0000707b885e13ac  vmovaps xmm2, [rsp+0x20]
0000707b885e13b2  vmovaps xmm3, [rsp+0x30]
0000707b885e13b8  vmovaps xmm4, [rsp+0x40]
0000707b885e13be  vmovaps xmm5, [rsp+0x50]
0000707b885e13c4  vmovaps xmm6, [rsp+0x60]
0000707b885e13ca  vmovaps xmm8, [rsp+0x70]
0000707b885e13d0  vmovaps xmm9, [rsp+0x80]
0000707b885e13d9  vmovaps xmm10, [rsp+0x90]
0000707b885e13e2  vmovaps xmm11, [rsp+0xA0]
0000707b885e13eb  vmovaps xmm12, [rsp+0xB0]
0000707b885e13f4  vmovaps xmm13, [rsp+0xC0]
0000707b885e13fd  vmovaps xmm14, [rsp+0xD0]
0000707b885e1406  vmovaps xmm15, [rsp+0xE0]
0000707b885e140f  add rsp, 0xF0
0000707b885e1416  pop r11
0000707b885e1418  pop r10
0000707b885e141a  pop r9
0000707b885e141c  pop r8
0000707b885e141e  pop rsi
0000707b885e141f  pop rdi
0000707b885e1420  pop rdx
0000707b885e1421  pop rcx
0000707b885e1422  pop rax
0000707b885e1423  add rsp, 0x08
0000707b885e1427  jmp 0x0000707B885DC7B4
0000707b885e142c  sub rsp, 0x08
0000707b885e1430  push rax
0000707b885e1431  push rcx
0000707b885e1432  push rdx
0000707b885e1433  push rdi
0000707b885e1434  push rsi
0000707b885e1435  push r8
0000707b885e1437  push r9
0000707b885e1439  push r10
0000707b885e143b  push r11
0000707b885e143d  sub rsp, 0xF0
0000707b885e1444  vmovaps [rsp], xmm0
0000707b885e1449  vmovaps [rsp+0x10], xmm1
0000707b885e144f  vmovaps [rsp+0x20], xmm2
0000707b885e1455  vmovaps [rsp+0x30], xmm3
0000707b885e145b  vmovaps [rsp+0x40], xmm4
0000707b885e1461  vmovaps [rsp+0x50], xmm5
0000707b885e1467  vmovaps [rsp+0x60], xmm6
0000707b885e146d  vmovaps [rsp+0x70], xmm7
0000707b885e1473  vmovaps [rsp+0x80], xmm8
0000707b885e147c  vmovaps [rsp+0x90], xmm10
0000707b885e1485  vmovaps [rsp+0xA0], xmm11
0000707b885e148e  vmovaps [rsp+0xB0], xmm12
0000707b885e1497  vmovaps [rsp+0xC0], xmm13
0000707b885e14a0  vmovaps [rsp+0xD0], xmm14
0000707b885e14a9  vmovaps [rsp+0xE0], xmm15
0000707b885e14b2  sub rsp, 0x30
0000707b885e14b6  movaps [rsp], xmm9
0000707b885e14bb  movaps [rsp+0x10], xmm13
0000707b885e14c1  movaps [rsp+0x20], xmm15
0000707b885e14c7  lea rdi, [rsp]
0000707b885e14cb  mov esi, 0x00
0000707b885e14d0  mov rax, 0x6471B35AC530
0000707b885e14da  call rax
0000707b885e14dc  movaps xmm9, [rsp]
0000707b885e14e1  add rsp, 0x30
0000707b885e14e5  vmovaps xmm0, [rsp]
0000707b885e14ea  vmovaps xmm1, [rsp+0x10]
0000707b885e14f0  vmovaps xmm2, [rsp+0x20]
0000707b885e14f6  vmovaps xmm3, [rsp+0x30]
0000707b885e14fc  vmovaps xmm4, [rsp+0x40]
0000707b885e1502  vmovaps xmm5, [rsp+0x50]
0000707b885e1508  vmovaps xmm6, [rsp+0x60]
0000707b885e150e  vmovaps xmm7, [rsp+0x70]
0000707b885e1514  vmovaps xmm8, [rsp+0x80]
0000707b885e151d  vmovaps xmm10, [rsp+0x90]
0000707b885e1526  vmovaps xmm11, [rsp+0xA0]
0000707b885e152f  vmovaps xmm12, [rsp+0xB0]
0000707b885e1538  vmovaps xmm13, [rsp+0xC0]
0000707b885e1541  vmovaps xmm14, [rsp+0xD0]
0000707b885e154a  vmovaps xmm15, [rsp+0xE0]
0000707b885e1553  add rsp, 0xF0
0000707b885e155a  pop r11
0000707b885e155c  pop r10
0000707b885e155e  pop r9
0000707b885e1560  pop r8
0000707b885e1562  pop rsi
0000707b885e1563  pop rdi
0000707b885e1564  pop rdx
0000707b885e1565  pop rcx
0000707b885e1566  pop rax
0000707b885e1567  add rsp, 0x08
0000707b885e156b  jmp 0x0000707B885DC7E2
0000707b885e1570  sub rsp, 0x08
0000707b885e1574  push rax
0000707b885e1575  push rcx
0000707b885e1576  push rdx
0000707b885e1577  push rdi
0000707b885e1578  push rsi
0000707b885e1579  push r8
0000707b885e157b  push r9
0000707b885e157d  push r10
0000707b885e157f  push r11
0000707b885e1581  sub rsp, 0xF0
0000707b885e1588  vmovaps [rsp], xmm0
0000707b885e158d  vmovaps [rsp+0x10], xmm1
0000707b885e1593  vmovaps [rsp+0x20], xmm2
0000707b885e1599  vmovaps [rsp+0x30], xmm3
0000707b885e159f  vmovaps [rsp+0x40], xmm4
0000707b885e15a5  vmovaps [rsp+0x50], xmm5
0000707b885e15ab  vmovaps [rsp+0x60], xmm6
0000707b885e15b1  vmovaps [rsp+0x70], xmm7
0000707b885e15b7  vmovaps [rsp+0x80], xmm8
0000707b885e15c0  vmovaps [rsp+0x90], xmm9
0000707b885e15c9  vmovaps [rsp+0xA0], xmm10
0000707b885e15d2  vmovaps [rsp+0xB0], xmm11
0000707b885e15db  vmovaps [rsp+0xC0], xmm12
0000707b885e15e4  vmovaps [rsp+0xD0], xmm13
0000707b885e15ed  vmovaps [rsp+0xE0], xmm14
0000707b885e15f6  sub rsp, 0x30
0000707b885e15fa  movaps [rsp], xmm15
0000707b885e15ff  movaps [rsp+0x10], xmm11
0000707b885e1605  movaps [rsp+0x20], xmm12
0000707b885e160b  lea rdi, [rsp]
0000707b885e160f  mov esi, 0x00
0000707b885e1614  mov rax, 0x6471B35AC530
0000707b885e161e  call rax
0000707b885e1620  movaps xmm15, [rsp]
0000707b885e1625  add rsp, 0x30
0000707b885e1629  vmovaps xmm0, [rsp]
0000707b885e162e  vmovaps xmm1, [rsp+0x10]
0000707b885e1634  vmovaps xmm2, [rsp+0x20]
0000707b885e163a  vmovaps xmm3, [rsp+0x30]
0000707b885e1640  vmovaps xmm4, [rsp+0x40]
0000707b885e1646  vmovaps xmm5, [rsp+0x50]
0000707b885e164c  vmovaps xmm6, [rsp+0x60]
0000707b885e1652  vmovaps xmm7, [rsp+0x70]
0000707b885e1658  vmovaps xmm8, [rsp+0x80]
0000707b885e1661  vmovaps xmm9, [rsp+0x90]
0000707b885e166a  vmovaps xmm10, [rsp+0xA0]
0000707b885e1673  vmovaps xmm11, [rsp+0xB0]
0000707b885e167c  vmovaps xmm12, [rsp+0xC0]
0000707b885e1685  vmovaps xmm13, [rsp+0xD0]
0000707b885e168e  vmovaps xmm14, [rsp+0xE0]
0000707b885e1697  add rsp, 0xF0
0000707b885e169e  pop r11
0000707b885e16a0  pop r10
0000707b885e16a2  pop r9
0000707b885e16a4  pop r8
0000707b885e16a6  pop rsi
0000707b885e16a7  pop rdi
0000707b885e16a8  pop rdx
0000707b885e16a9  pop rcx
0000707b885e16aa  pop rax
0000707b885e16ab  add rsp, 0x08
0000707b885e16af  jmp 0x0000707B885DC7FD
0000707b885e16b4  sub rsp, 0x08
0000707b885e16b8  push rax
0000707b885e16b9  push rcx
0000707b885e16ba  push rdx
0000707b885e16bb  push rdi
0000707b885e16bc  push rsi
0000707b885e16bd  push r8
0000707b885e16bf  push r9
0000707b885e16c1  push r10
0000707b885e16c3  push r11
0000707b885e16c5  sub rsp, 0xF0
0000707b885e16cc  vmovaps [rsp], xmm0
0000707b885e16d1  vmovaps [rsp+0x10], xmm1
0000707b885e16d7  vmovaps [rsp+0x20], xmm2
0000707b885e16dd  vmovaps [rsp+0x30], xmm3
0000707b885e16e3  vmovaps [rsp+0x40], xmm4
0000707b885e16e9  vmovaps [rsp+0x50], xmm5
0000707b885e16ef  vmovaps [rsp+0x60], xmm6
0000707b885e16f5  vmovaps [rsp+0x70], xmm7
0000707b885e16fb  vmovaps [rsp+0x80], xmm8
0000707b885e1704  vmovaps [rsp+0x90], xmm9
0000707b885e170d  vmovaps [rsp+0xA0], xmm10
0000707b885e1716  vmovaps [rsp+0xB0], xmm11
0000707b885e171f  vmovaps [rsp+0xC0], xmm12
0000707b885e1728  vmovaps [rsp+0xD0], xmm14
0000707b885e1731  vmovaps [rsp+0xE0], xmm15
0000707b885e173a  sub rsp, 0x30
0000707b885e173e  movaps [rsp], xmm13
0000707b885e1743  movaps [rsp+0x10], xmm10
0000707b885e1749  movaps [rsp+0x20], xmm14
0000707b885e174f  lea rdi, [rsp]
0000707b885e1753  mov esi, 0x00
0000707b885e1758  mov rax, 0x6471B35AC530
0000707b885e1762  call rax
0000707b885e1764  movaps xmm13, [rsp]
0000707b885e1769  add rsp, 0x30
0000707b885e176d  vmovaps xmm0, [rsp]
0000707b885e1772  vmovaps xmm1, [rsp+0x10]
0000707b885e1778  vmovaps xmm2, [rsp+0x20]
0000707b885e177e  vmovaps xmm3, [rsp+0x30]
0000707b885e1784  vmovaps xmm4, [rsp+0x40]
0000707b885e178a  vmovaps xmm5, [rsp+0x50]
0000707b885e1790  vmovaps xmm6, [rsp+0x60]
0000707b885e1796  vmovaps xmm7, [rsp+0x70]
0000707b885e179c  vmovaps xmm8, [rsp+0x80]
0000707b885e17a5  vmovaps xmm9, [rsp+0x90]
0000707b885e17ae  vmovaps xmm10, [rsp+0xA0]
0000707b885e17b7  vmovaps xmm11, [rsp+0xB0]
0000707b885e17c0  vmovaps xmm12, [rsp+0xC0]
0000707b885e17c9  vmovaps xmm14, [rsp+0xD0]
0000707b885e17d2  vmovaps xmm15, [rsp+0xE0]
0000707b885e17db  add rsp, 0xF0
0000707b885e17e2  pop r11
0000707b885e17e4  pop r10
0000707b885e17e6  pop r9
0000707b885e17e8  pop r8
0000707b885e17ea  pop rsi
0000707b885e17eb  pop rdi
0000707b885e17ec  pop rdx
0000707b885e17ed  pop rcx
0000707b885e17ee  pop rax
0000707b885e17ef  add rsp, 0x08
0000707b885e17f3  jmp 0x0000707B885DC820
0000707b885e17f8  sub rsp, 0x08
0000707b885e17fc  push rax
0000707b885e17fd  push rcx
0000707b885e17fe  push rdx
0000707b885e17ff  push rdi
0000707b885e1800  push rsi
0000707b885e1801  push r8
0000707b885e1803  push r9
0000707b885e1805  push r10
0000707b885e1807  push r11
0000707b885e1809  sub rsp, 0xF0
0000707b885e1810  vmovaps [rsp], xmm0
0000707b885e1815  vmovaps [rsp+0x10], xmm1
0000707b885e181b  vmovaps [rsp+0x20], xmm2
0000707b885e1821  vmovaps [rsp+0x30], xmm3
0000707b885e1827  vmovaps [rsp+0x40], xmm4
0000707b885e182d  vmovaps [rsp+0x50], xmm5
0000707b885e1833  vmovaps [rsp+0x60], xmm6
0000707b885e1839  vmovaps [rsp+0x70], xmm7
0000707b885e183f  vmovaps [rsp+0x80], xmm8
0000707b885e1848  vmovaps [rsp+0x90], xmm9
0000707b885e1851  vmovaps [rsp+0xA0], xmm10
0000707b885e185a  vmovaps [rsp+0xB0], xmm11
0000707b885e1863  vmovaps [rsp+0xC0], xmm12
0000707b885e186c  vmovaps [rsp+0xD0], xmm13
0000707b885e1875  vmovaps [rsp+0xE0], xmm15
0000707b885e187e  sub rsp, 0x30
0000707b885e1882  movaps [rsp], xmm14
0000707b885e1887  movaps [rsp+0x10], xmm1
0000707b885e188c  movaps [rsp+0x20], xmm7
0000707b885e1891  lea rdi, [rsp]
0000707b885e1895  mov esi, 0x00
0000707b885e189a  mov rax, 0x6471B35AC530
0000707b885e18a4  call rax
0000707b885e18a6  movaps xmm14, [rsp]
0000707b885e18ab  add rsp, 0x30
0000707b885e18af  vmovaps xmm0, [rsp]
0000707b885e18b4  vmovaps xmm1, [rsp+0x10]
0000707b885e18ba  vmovaps xmm2, [rsp+0x20]
0000707b885e18c0  vmovaps xmm3, [rsp+0x30]
0000707b885e18c6  vmovaps xmm4, [rsp+0x40]
0000707b885e18cc  vmovaps xmm5, [rsp+0x50]
0000707b885e18d2  vmovaps xmm6, [rsp+0x60]
0000707b885e18d8  vmovaps xmm7, [rsp+0x70]
0000707b885e18de  vmovaps xmm8, [rsp+0x80]
0000707b885e18e7  vmovaps xmm9, [rsp+0x90]
0000707b885e18f0  vmovaps xmm10, [rsp+0xA0]
0000707b885e18f9  vmovaps xmm11, [rsp+0xB0]
0000707b885e1902  vmovaps xmm12, [rsp+0xC0]
0000707b885e190b  vmovaps xmm13, [rsp+0xD0]
0000707b885e1914  vmovaps xmm15, [rsp+0xE0]
0000707b885e191d  add rsp, 0xF0
0000707b885e1924  pop r11
0000707b885e1926  pop r10
0000707b885e1928  pop r9
0000707b885e192a  pop r8
0000707b885e192c  pop rsi
0000707b885e192d  pop rdi
0000707b885e192e  pop rdx
0000707b885e192f  pop rcx
0000707b885e1930  pop rax
0000707b885e1931  add rsp, 0x08
0000707b885e1935  jmp 0x0000707B885DC843
0000707b885e193a  sub rsp, 0x08
0000707b885e193e  push rax
0000707b885e193f  push rcx
0000707b885e1940  push rdx
0000707b885e1941  push rdi
0000707b885e1942  push rsi
0000707b885e1943  push r8
0000707b885e1945  push r9
0000707b885e1947  push r10
0000707b885e1949  push r11
0000707b885e194b  sub rsp, 0xF0
0000707b885e1952  vmovaps [rsp], xmm0
0000707b885e1957  vmovaps [rsp+0x10], xmm2
0000707b885e195d  vmovaps [rsp+0x20], xmm3
0000707b885e1963  vmovaps [rsp+0x30], xmm4
0000707b885e1969  vmovaps [rsp+0x40], xmm5
0000707b885e196f  vmovaps [rsp+0x50], xmm6
0000707b885e1975  vmovaps [rsp+0x60], xmm7
0000707b885e197b  vmovaps [rsp+0x70], xmm8
0000707b885e1981  vmovaps [rsp+0x80], xmm9
0000707b885e198a  vmovaps [rsp+0x90], xmm10
0000707b885e1993  vmovaps [rsp+0xA0], xmm11
0000707b885e199c  vmovaps [rsp+0xB0], xmm12
0000707b885e19a5  vmovaps [rsp+0xC0], xmm13
0000707b885e19ae  vmovaps [rsp+0xD0], xmm14
0000707b885e19b7  vmovaps [rsp+0xE0], xmm15
0000707b885e19c0  sub rsp, 0x30
0000707b885e19c4  movaps [rsp], xmm1
0000707b885e19c8  movaps [rsp+0x10], xmm8
0000707b885e19ce  movaps [rsp+0x20], xmm9
0000707b885e19d4  lea rdi, [rsp]
0000707b885e19d8  mov esi, 0x00
0000707b885e19dd  mov rax, 0x6471B35AC530
0000707b885e19e7  call rax
0000707b885e19e9  movaps xmm1, [rsp]
0000707b885e19ed  add rsp, 0x30
0000707b885e19f1  vmovaps xmm0, [rsp]
0000707b885e19f6  vmovaps xmm2, [rsp+0x10]
0000707b885e19fc  vmovaps xmm3, [rsp+0x20]
0000707b885e1a02  vmovaps xmm4, [rsp+0x30]
0000707b885e1a08  vmovaps xmm5, [rsp+0x40]
0000707b885e1a0e  vmovaps xmm6, [rsp+0x50]
0000707b885e1a14  vmovaps xmm7, [rsp+0x60]
0000707b885e1a1a  vmovaps xmm8, [rsp+0x70]
0000707b885e1a20  vmovaps xmm9, [rsp+0x80]
0000707b885e1a29  vmovaps xmm10, [rsp+0x90]
0000707b885e1a32  vmovaps xmm11, [rsp+0xA0]
0000707b885e1a3b  vmovaps xmm12, [rsp+0xB0]
0000707b885e1a44  vmovaps xmm13, [rsp+0xC0]
0000707b885e1a4d  vmovaps xmm14, [rsp+0xD0]
0000707b885e1a56  vmovaps xmm15, [rsp+0xE0]
0000707b885e1a5f  add rsp, 0xF0
0000707b885e1a66  pop r11
0000707b885e1a68  pop r10
0000707b885e1a6a  pop r9
0000707b885e1a6c  pop r8
0000707b885e1a6e  pop rsi
0000707b885e1a6f  pop rdi
0000707b885e1a70  pop rdx
0000707b885e1a71  pop rcx
0000707b885e1a72  pop rax
0000707b885e1a73  add rsp, 0x08
0000707b885e1a77  jmp 0x0000707B885DC865
0000707b885e1a7c  call 0x0000707B884E5940
0000707b885e1a81  jmp 0x0000707B885DC873
0000707b885e1a86  call 0x0000707B8840C380
0000707b885e1a8b  jmp 0x0000707B885DC87D
0000707b885e1a90  call 0x0000707B8840D600
0000707b885e1a95  jmp 0x0000707B885DC887
0000707b885e1a9a  call 0x0000707B883FF540
0000707b885e1a9f  jmp 0x0000707B885DC891
0000707b885e1aa4  int3
0000707b885e1aa5  nop [rax+rax*1], ax
0000707b885e1aae  nop
0000707b885e1ab0  mov rax, [r15+0xF8]
0000707b885e1ab7  lea r14, [rax+0x140]
0000707b885e1abe  mov r12, [r13+r14*1]
0000707b885e1ac3  mov [r15+0xE8], r12
0000707b885e1aca  lea r14, [rax+0x130]
0000707b885e1ad1  mov r12, [r13+r14*1]
0000707b885e1ad6  lea r14, [rax+0x138]
0000707b885e1add  mov r11, [r13+r14*1]
0000707b885e1ae2  movq xmm1, r12
0000707b885e1ae7  movq xmm15, r11
0000707b885e1aec  movq xmm1, xmm1
0000707b885e1af0  movq xmm1, xmm1
0000707b885e1af4  movaps [r15+0x1A0], xmm1
0000707b885e1afc  movq xmm15, xmm15
0000707b885e1b01  movq xmm15, xmm15
0000707b885e1b06  movaps [r15+0x190], xmm15
0000707b885e1b0e  lea r14, [rax+0x120]
0000707b885e1b15  mov r12, [r13+r14*1]
0000707b885e1b1a  lea r14, [rax+0x128]
0000707b885e1b21  mov r11, [r13+r14*1]
0000707b885e1b26  movq xmm1, r12
0000707b885e1b2b  movq xmm15, r11
0000707b885e1b30  movq xmm1, xmm1
0000707b885e1b34  movq xmm1, xmm1
0000707b885e1b38  movaps [r15+0x1C0], xmm1
0000707b885e1b40  movq xmm15, xmm15
0000707b885e1b45  movq xmm15, xmm15
0000707b885e1b4a  movaps [r15+0x1B0], xmm15
0000707b885e1b52  lea r14, [rax+0x110]
0000707b885e1b59  mov r12, [r13+r14*1]
0000707b885e1b5e  lea r14, [rax+0x118]
0000707b885e1b65  mov r11, [r13+r14*1]
0000707b885e1b6a  movq xmm1, r12
0000707b885e1b6f  movq xmm15, r11
0000707b885e1b74  movq xmm1, xmm1
0000707b885e1b78  movq xmm1, xmm1
0000707b885e1b7c  movaps [r15+0x1E0], xmm1
0000707b885e1b84  movq xmm15, xmm15
0000707b885e1b89  movq xmm15, xmm15
0000707b885e1b8e  movaps [r15+0x1D0], xmm15
0000707b885e1b96  lea r14, [rax+0x100]
0000707b885e1b9d  mov r12, [r13+r14*1]
0000707b885e1ba2  lea r14, [rax+0x108]
0000707b885e1ba9  mov r11, [r13+r14*1]
0000707b885e1bae  movq xmm1, r12
0000707b885e1bb3  movq xmm15, r11
0000707b885e1bb8  movq xmm1, xmm1
0000707b885e1bbc  movq xmm1, xmm1
0000707b885e1bc0  movaps [r15+0x200], xmm1
0000707b885e1bc8  movq xmm15, xmm15
0000707b885e1bcd  movq xmm15, xmm15
0000707b885e1bd2  movaps [r15+0x1F0], xmm15
0000707b885e1bda  mov qword ptr [r15+0x40], 0x430000
0000707b885e1be2  mov r14d, 0x430510
0000707b885e1be8  mov r12, [r13+r14*1]
0000707b885e1bed  movq xmm1, r12
0000707b885e1bf2  lea r14, [rax+0x150]
0000707b885e1bf9  mov [r15+0xF8], r14
0000707b885e1c00  mov rax, [r15+0x50]
0000707b885e1c04  movups xmm15, [r13+rax*1]
0000707b885e1c0a  movaps [r15+0x120], xmm15
0000707b885e1c12  mov qword ptr [r15+0x48], 0x10
0000707b885e1c1a  xor eax, eax
0000707b885e1c1c  mov r14d, 0x10
0000707b885e1c22  mov r12d, 0x200
0000707b885e1c28  cmp r14, r12
0000707b885e1c2b  cmc
0000707b885e1c2c  lahf
0000707b885e1c2d  seto al
0000707b885e1c30  mov [r15+0x108], eax
0000707b885e1c37  pextrq rax, xmm15, 0x01
0000707b885e1c3e  movq xmm14, rax
0000707b885e1c43  movaps [r15+0x130], xmm14
0000707b885e1c4b  movq rax, xmm1
0000707b885e1c50  movq r14, xmm15
0000707b885e1c55  vmovq xmm1, rax
0000707b885e1c5a  vmovq xmm15, r14
0000707b885e1c5f  movaps xmm13, xmm1
0000707b885e1c63  addsd xmm13, xmm15
0000707b885e1c68  ucomisd xmm13, xmm13
0000707b885e1c6d  jp 0x0000707B885E1D86
0000707b885e1c73  movq xmm13, xmm13
0000707b885e1c78  movq rax, xmm13
0000707b885e1c7d  movq r14, xmm14
0000707b885e1c82  vmovq xmm1, rax
0000707b885e1c87  vmovq xmm15, r14
0000707b885e1c8c  movaps xmm14, xmm1
0000707b885e1c90  addsd xmm14, xmm15
0000707b885e1c95  ucomisd xmm14, xmm14
0000707b885e1c9a  jp 0x0000707B885E1DCE
0000707b885e1ca0  movq xmm14, xmm14
0000707b885e1ca5  movaps [r15+0x110], xmm14
0000707b885e1cad  mov eax, [r15+0x108]
0000707b885e1cb4  sahf
0000707b885e1cb5  jnz 0x0000707B885E1CE7
0000707b885e1cb7  cmp dword ptr [r15+0x318], 0x00
0000707b885e1cbf  jz 0x0000707B885E1FE0
0000707b885e1cc5  nop [rax+rax*1], ax
0000707b885e1cce  nop [rax+rax*1], eax
0000707b885e1cd6  mov eax, 0x410490
0000707b885e1cdb  mov [r15+0x100], rax
0000707b885e1ce2  jmp 0x0000707B883FE110
0000707b885e1ce7  cmp dword ptr [r15+0x318], 0x00
0000707b885e1cef  jz 0x0000707B885E1E20
0000707b885e1cf5  nop [rax+rax*1], ax
0000707b885e1cfe  nop [rax+rax*1], eax
0000707b885e1d06  mov eax, 0x410474
0000707b885e1d0b  mov [r15+0x100], rax
0000707b885e1d12  jmp 0x0000707B883FE110
0000707b885e1d17  int3
0000707b885e1d18  call 0x0000707B884E27E0
0000707b885e1d1d  jmp 0x0000707B885E1AC3
0000707b885e1d22  call 0x0000707B884E27E0
0000707b885e1d27  jmp 0x0000707B885E1AD6
0000707b885e1d2c  call 0x0000707B884E1570
0000707b885e1d31  jmp 0x0000707B885E1AE2
0000707b885e1d36  call 0x0000707B884E27E0
0000707b885e1d3b  jmp 0x0000707B885E1B1A
0000707b885e1d40  call 0x0000707B884E1570
0000707b885e1d45  jmp 0x0000707B885E1B26
0000707b885e1d4a  call 0x0000707B884E27E0
0000707b885e1d4f  jmp 0x0000707B885E1B5E
0000707b885e1d54  call 0x0000707B884E1570
0000707b885e1d59  jmp 0x0000707B885E1B6A
0000707b885e1d5e  call 0x0000707B884E27E0
0000707b885e1d63  jmp 0x0000707B885E1BA2
0000707b885e1d68  call 0x0000707B884E1570
0000707b885e1d6d  jmp 0x0000707B885E1BAE
0000707b885e1d72  call 0x0000707B884E27E0
0000707b885e1d77  jmp 0x0000707B885E1BED
0000707b885e1d7c  call 0x0000707B8840E760
0000707b885e1d81  jmp 0x0000707B885E1C0A
0000707b885e1d86  ucomisd xmm1, xmm15
0000707b885e1d8b  jp 0x0000707B885E1D9A
0000707b885e1d8d  movaps xmm13, [0x0000707B881FE060]
0000707b885e1d95  jmp 0x0000707B885E1C73
0000707b885e1d9a  vxorps xmm0, xmm1, xmm15
0000707b885e1d9f  pextrw eax, xmm0, 0x03
0000707b885e1da4  and eax, 0x7FF8
0000707b885e1da9  cmp eax, 0x08
0000707b885e1dac  jnz 0x0000707B885E1C73
0000707b885e1db2  movq rax, xmm15
0000707b885e1db7  shl rax, 0x0D
0000707b885e1dbb  jbe 0x0000707B885E1C73
0000707b885e1dc1  vorps xmm13, xmm15, [0x0000707B881FE070]
0000707b885e1dc9  jmp 0x0000707B885E1C73
0000707b885e1dce  ucomisd xmm1, xmm15
0000707b885e1dd3  jp 0x0000707B885E1DE2
0000707b885e1dd5  movaps xmm14, [0x0000707B881FE060]
0000707b885e1ddd  jmp 0x0000707B885E1CA0
0000707b885e1de2  vxorps xmm0, xmm1, xmm15
0000707b885e1de7  pextrw eax, xmm0, 0x03
0000707b885e1dec  and eax, 0x7FF8
0000707b885e1df1  cmp eax, 0x08
0000707b885e1df4  jnz 0x0000707B885E1CA0
0000707b885e1dfa  movq rax, xmm15
0000707b885e1dff  shl rax, 0x0D
0000707b885e1e03  jbe 0x0000707B885E1CA0
0000707b885e1e09  vorps xmm14, xmm15, [0x0000707B881FE070]
0000707b885e1e11  jmp 0x0000707B885E1CA0
0000707b885e1e16  int3
0000707b885e1e17  nop [rax+rax*1], ax
0000707b885e1e20  mov rax, [r15+0x48]
0000707b885e1e24  mov r14, [r15+0x50]
0000707b885e1e28  lea r12, [r14+rax*1]
0000707b885e1e2c  movups xmm1, [r13+r12*1]
0000707b885e1e32  movaps [r15+0x120], xmm1
0000707b885e1e3a  lea r14, [rax+0x10]
0000707b885e1e3e  mov [r15+0x48], r14
0000707b885e1e42  xor eax, eax
0000707b885e1e44  mov r12d, 0x200
0000707b885e1e4a  cmp r14, r12
0000707b885e1e4d  cmc
0000707b885e1e4e  lahf
0000707b885e1e4f  seto al
0000707b885e1e52  mov [r15+0x108], eax
0000707b885e1e59  pextrq rax, xmm1, 0x01
0000707b885e1e60  movq xmm15, rax
0000707b885e1e65  movaps [r15+0x130], xmm15
0000707b885e1e6d  movaps xmm14, [r15+0x110]
0000707b885e1e75  movq rax, xmm14
0000707b885e1e7a  movq r14, xmm1
0000707b885e1e7f  vmovq xmm1, rax
0000707b885e1e84  vmovq xmm14, r14
0000707b885e1e89  movaps xmm13, xmm1
0000707b885e1e8d  addsd xmm13, xmm14
0000707b885e1e92  ucomisd xmm13, xmm13
0000707b885e1e97  jp 0x0000707B885E1F4C
0000707b885e1e9d  movq xmm13, xmm13
0000707b885e1ea2  movq rax, xmm13
0000707b885e1ea7  movq r14, xmm15
0000707b885e1eac  vmovq xmm1, rax
0000707b885e1eb1  vmovq xmm15, r14
0000707b885e1eb6  movaps xmm14, xmm1
0000707b885e1eba  addsd xmm14, xmm15
0000707b885e1ebf  ucomisd xmm14, xmm14
0000707b885e1ec4  jp 0x0000707B885E1F94
0000707b885e1eca  movq xmm14, xmm14
0000707b885e1ecf  movaps [r15+0x110], xmm14
0000707b885e1ed7  mov eax, [r15+0x108]
0000707b885e1ede  sahf
0000707b885e1edf  jnz 0x0000707B885E1F11
0000707b885e1ee1  cmp dword ptr [r15+0x318], 0x00
0000707b885e1ee9  jz 0x0000707B885E1FE0
0000707b885e1eef  nop [rax+rax*1], ax
0000707b885e1ef8  nop [rax+rax*1], eax
0000707b885e1f00  mov eax, 0x410490
0000707b885e1f05  mov [r15+0x100], rax
0000707b885e1f0c  jmp 0x0000707B883FE110
0000707b885e1f11  cmp dword ptr [r15+0x318], 0x00
0000707b885e1f19  jz 0x0000707B885E1E20
0000707b885e1f1f  nop [rax+rax*1], ax
0000707b885e1f28  nop [rax+rax*1], eax
0000707b885e1f30  mov eax, 0x410474
0000707b885e1f35  mov [r15+0x100], rax
0000707b885e1f3c  jmp 0x0000707B883FE110
0000707b885e1f41  int3
0000707b885e1f42  call 0x0000707B884B52F0
0000707b885e1f47  jmp 0x0000707B885E1E32
0000707b885e1f4c  ucomisd xmm1, xmm14
0000707b885e1f51  jp 0x0000707B885E1F60
0000707b885e1f53  movaps xmm13, [0x0000707B881FE060]
0000707b885e1f5b  jmp 0x0000707B885E1E9D
0000707b885e1f60  vxorps xmm0, xmm1, xmm14
0000707b885e1f65  pextrw eax, xmm0, 0x03
0000707b885e1f6a  and eax, 0x7FF8
0000707b885e1f6f  cmp eax, 0x08
0000707b885e1f72  jnz 0x0000707B885E1E9D
0000707b885e1f78  movq rax, xmm14
0000707b885e1f7d  shl rax, 0x0D
0000707b885e1f81  jbe 0x0000707B885E1E9D
0000707b885e1f87  vorps xmm13, xmm14, [0x0000707B881FE070]
0000707b885e1f8f  jmp 0x0000707B885E1E9D
0000707b885e1f94  ucomisd xmm1, xmm15
0000707b885e1f99  jp 0x0000707B885E1FA8
0000707b885e1f9b  movaps xmm14, [0x0000707B881FE060]
0000707b885e1fa3  jmp 0x0000707B885E1ECA
0000707b885e1fa8  vxorps xmm0, xmm1, xmm15
0000707b885e1fad  pextrw eax, xmm0, 0x03
0000707b885e1fb2  and eax, 0x7FF8
0000707b885e1fb7  cmp eax, 0x08
0000707b885e1fba  jnz 0x0000707B885E1ECA
0000707b885e1fc0  movq rax, xmm15
0000707b885e1fc5  shl rax, 0x0D
0000707b885e1fc9  jbe 0x0000707B885E1ECA
0000707b885e1fcf  vorps xmm14, xmm15, [0x0000707B881FE070]
0000707b885e1fd7  jmp 0x0000707B885E1ECA
0000707b885e1fdc  int3
0000707b885e1fdd  nop [rax], eax
0000707b885e1fe0  mov rax, [r15+0x40]
0000707b885e1fe4  lea r14, [rax+0x510]
0000707b885e1feb  movaps xmm1, [r15+0x110]
0000707b885e1ff3  movq rax, xmm1
0000707b885e1ff8  mov [r13+r14*1], rax
0000707b885e1ffd  mov rax, [r15+0xF0]
0000707b885e2004  mov [r15+0x100], rax
0000707b885e200b  jmp 0x0000707B885CE5C0
0000707b885e2010  int3
0000707b885e2011  call 0x0000707B884D5EB0
0000707b885e2016  jmp 0x0000707B885E1FFD
0000707b885e201b  int3
0000707b885e201c  nop [rax], eax
0000707b885e2020  mov qword ptr [r15+0x100], 0x04
0000707b885e202b  mov esi, 0x00
0000707b885e2030  mov edx, 0x09
0000707b885e2035  mov rdi, 0x7FFC348B4400
0000707b885e203f  mov rax, 0x6471B343F970
0000707b885e2049  call rax
0000707b885e204b  cmp dword ptr [r15+0x318], 0x00
0000707b885e2053  jnz 0x0000707B883FE110
0000707b885e2059  jmp 0x0000707B883FE0A0
0000707b885e205e  int3
0000707b885e205f  int3
