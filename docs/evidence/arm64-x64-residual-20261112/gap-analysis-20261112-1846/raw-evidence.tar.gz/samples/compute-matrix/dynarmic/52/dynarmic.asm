0000762f89bce69b  nop [rax+rax*1], eax
0000762f89bce6a0  vmovaps xmm1, [0x0000762F897FE010]
0000762f89bce6a8  movq xmm1, xmm1
0000762f89bce6ac  movaps [r15+0x110], xmm1
0000762f89bce6b4  vmovaps xmm1, [0x0000762F897FE020]
0000762f89bce6bc  movq xmm1, xmm1
0000762f89bce6c0  movaps [r15+0x120], xmm1
0000762f89bce6c8  mov eax, 0x4204C0
0000762f89bce6cd  mov r14, [r13+rax*1]
0000762f89bce6d2  movq xmm1, r14
0000762f89bce6d7  movaps [r15+0x130], xmm1
0000762f89bce6df  vmovaps xmm1, [0x0000762F897FE030]
0000762f89bce6e7  vpbroadcastq xmm1, xmm1
0000762f89bce6ec  movaps [r15+0x140], xmm1
0000762f89bce6f4  mov qword ptr [r15+0x40], 0x02
0000762f89bce6fc  vmovaps xmm15, [0x0000762F897FE040]
0000762f89bce704  movq xmm15, xmm15
0000762f89bce709  movaps [r15+0x150], xmm15
0000762f89bce711  mov qword ptr [r15+0x58], 0x420000
0000762f89bce719  vmovaps xmm15, [0x0000762F897FE050]
0000762f89bce721  vpbroadcastq xmm15, xmm15
0000762f89bce726  movaps [r15+0x160], xmm15
0000762f89bce72e  mov rax, [r15+0x40]
0000762f89bce732  vmovq xmm14, rax
0000762f89bce737  vpbroadcastq xmm14, xmm14
0000762f89bce73c  movaps [r15+0x170], xmm14
0000762f89bce744  mov eax, 0x4204D0
0000762f89bce749  movups xmm13, [r13+rax*1]
0000762f89bce74f  mov qword ptr [r15+0x40], 0x430518
0000762f89bce757  mov qword ptr [r15+0x50], 0x430720
0000762f89bce75f  vpmovqd xmm12, xmm13
0000762f89bce765  pxor xmm11, xmm11
0000762f89bce76a  punpcklqdq xmm12, xmm11
0000762f89bce76f  movaps [r15+0x210], xmm12
0000762f89bce777  movq xmm12, qword ptr [r15+0x120]
0000762f89bce780  movq xmm11, qword ptr [r15+0x130]
0000762f89bce789  psubd xmm12, xmm11
0000762f89bce78e  movq xmm12, xmm12
0000762f89bce793  paddq xmm13, xmm14
0000762f89bce798  movaps [r15+0x180], xmm13
0000762f89bce7a0  movq xmm14, qword ptr [r15+0x150]
0000762f89bce7a9  paddd xmm11, xmm14
0000762f89bce7ae  movq xmm11, xmm11
0000762f89bce7b3  movq xmm11, xmm11
0000762f89bce7b8  movaps [r15+0x130], xmm11
0000762f89bce7c0  pmovzxdq xmm12, xmm12
0000762f89bce7c6  psllq xmm12, 0x00
0000762f89bce7cc  movq xmm14, qword ptr [r15+0x210]
0000762f89bce7d5  movq xmm13, qword ptr [r15+0x110]
0000762f89bce7de  paddd xmm14, xmm13
0000762f89bce7e3  movq xmm14, xmm14
0000762f89bce7e8  vcvtuqq2pd xmm12, xmm12
0000762f89bce7ee  pmovzxdq xmm14, xmm14
0000762f89bce7f4  psllq xmm14, 0x00
0000762f89bce7fa  vcvtuqq2pd xmm14, xmm14
0000762f89bce800  movaps xmm13, xmm12
0000762f89bce804  mulpd xmm13, xmm1
0000762f89bce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000762f89bce80f  ptest xmm11, xmm11
0000762f89bce815  jnz 0x0000762F89BCE8FF
0000762f89bce81b  movaps [r15+0x220], xmm13
0000762f89bce823  mov eax, 0x430720
0000762f89bce828  movups [r13+rax*1], xmm13
0000762f89bce82e  movaps xmm1, xmm14
0000762f89bce832  mulpd xmm1, xmm15
0000762f89bce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000762f89bce83c  ptest xmm13, xmm13
0000762f89bce842  jnz 0x0000762F89BCEA4C
0000762f89bce848  movaps [r15+0x210], xmm1
0000762f89bce850  mov eax, 0x430518
0000762f89bce855  movups [r13+rax*1], xmm1
0000762f89bce85b  mov qword ptr [r15+0x48], 0x10
0000762f89bce863  xor eax, eax
0000762f89bce865  mov r14d, 0x10
0000762f89bce86b  mov r12d, 0x200
0000762f89bce871  cmp r14, r12
0000762f89bce874  cmc
0000762f89bce875  lahf
0000762f89bce876  seto al
0000762f89bce879  mov [r15+0x108], eax
0000762f89bce880  mov eax, [r15+0x108]
0000762f89bce887  sahf
0000762f89bce888  jnz 0x0000762F89BCE8BA
0000762f89bce88a  cmp dword ptr [r15+0x318], 0x00
0000762f89bce892  jz 0x0000762F89BCEFF0
0000762f89bce898  nop [rax+rax*1], ax
0000762f89bce8a1  nop [rax+rax*1], eax
0000762f89bce8a9  mov eax, 0x4101EC
0000762f89bce8ae  mov [r15+0x100], rax
0000762f89bce8b5  jmp 0x0000762F899FE110
0000762f89bce8ba  cmp dword ptr [r15+0x318], 0x00
0000762f89bce8c2  jz 0x0000762F89BCEBA0
0000762f89bce8c8  nop [rax+rax*1], ax
0000762f89bce8d1  nop [rax+rax*1], eax
0000762f89bce8d9  mov eax, 0x4101AC
0000762f89bce8de  mov [r15+0x100], rax
0000762f89bce8e5  jmp 0x0000762F899FE110
0000762f89bce8ea  int3
0000762f89bce8eb  call 0x0000762F89A0DC20
0000762f89bce8f0  jmp 0x0000762F89BCE6D2
0000762f89bce8f5  call 0x0000762F89A0C260
0000762f89bce8fa  jmp 0x0000762F89BCE74F
0000762f89bce8ff  sub rsp, 0x08
0000762f89bce903  push rax
0000762f89bce904  push rcx
0000762f89bce905  push rdx
0000762f89bce906  push rdi
0000762f89bce907  push rsi
0000762f89bce908  push r8
0000762f89bce90a  push r9
0000762f89bce90c  push r10
0000762f89bce90e  push r11
0000762f89bce910  sub rsp, 0xF0
0000762f89bce917  vmovaps [rsp], xmm0
0000762f89bce91c  vmovaps [rsp+0x10], xmm1
0000762f89bce922  vmovaps [rsp+0x20], xmm2
0000762f89bce928  vmovaps [rsp+0x30], xmm3
0000762f89bce92e  vmovaps [rsp+0x40], xmm4
0000762f89bce934  vmovaps [rsp+0x50], xmm5
0000762f89bce93a  vmovaps [rsp+0x60], xmm6
0000762f89bce940  vmovaps [rsp+0x70], xmm7
0000762f89bce946  vmovaps [rsp+0x80], xmm8
0000762f89bce94f  vmovaps [rsp+0x90], xmm9
0000762f89bce958  vmovaps [rsp+0xA0], xmm10
0000762f89bce961  vmovaps [rsp+0xB0], xmm11
0000762f89bce96a  vmovaps [rsp+0xC0], xmm12
0000762f89bce973  vmovaps [rsp+0xD0], xmm14
0000762f89bce97c  vmovaps [rsp+0xE0], xmm15
0000762f89bce985  sub rsp, 0x30
0000762f89bce989  movaps [rsp], xmm13
0000762f89bce98e  movaps [rsp+0x10], xmm12
0000762f89bce994  movaps [rsp+0x20], xmm1
0000762f89bce999  lea rdi, [rsp]
0000762f89bce99d  mov esi, 0x00
0000762f89bce9a2  mov rax, 0x604D6F946530
0000762f89bce9ac  call rax
0000762f89bce9ae  movaps xmm13, [rsp]
0000762f89bce9b3  add rsp, 0x30
0000762f89bce9b7  vmovaps xmm0, [rsp]
0000762f89bce9bc  vmovaps xmm1, [rsp+0x10]
0000762f89bce9c2  vmovaps xmm2, [rsp+0x20]
0000762f89bce9c8  vmovaps xmm3, [rsp+0x30]
0000762f89bce9ce  vmovaps xmm4, [rsp+0x40]
0000762f89bce9d4  vmovaps xmm5, [rsp+0x50]
0000762f89bce9da  vmovaps xmm6, [rsp+0x60]
0000762f89bce9e0  vmovaps xmm7, [rsp+0x70]
0000762f89bce9e6  vmovaps xmm8, [rsp+0x80]
0000762f89bce9ef  vmovaps xmm9, [rsp+0x90]
0000762f89bce9f8  vmovaps xmm10, [rsp+0xA0]
0000762f89bcea01  vmovaps xmm11, [rsp+0xB0]
0000762f89bcea0a  vmovaps xmm12, [rsp+0xC0]
0000762f89bcea13  vmovaps xmm14, [rsp+0xD0]
0000762f89bcea1c  vmovaps xmm15, [rsp+0xE0]
0000762f89bcea25  add rsp, 0xF0
0000762f89bcea2c  pop r11
0000762f89bcea2e  pop r10
0000762f89bcea30  pop r9
0000762f89bcea32  pop r8
0000762f89bcea34  pop rsi
0000762f89bcea35  pop rdi
0000762f89bcea36  pop rdx
0000762f89bcea37  pop rcx
0000762f89bcea38  pop rax
0000762f89bcea39  add rsp, 0x08
0000762f89bcea3d  jmp 0x0000762F89BCE81B
0000762f89bcea42  call 0x0000762F89A0C380
0000762f89bcea47  jmp 0x0000762F89BCE82E
0000762f89bcea4c  sub rsp, 0x08
0000762f89bcea50  push rax
0000762f89bcea51  push rcx
0000762f89bcea52  push rdx
0000762f89bcea53  push rdi
0000762f89bcea54  push rsi
0000762f89bcea55  push r8
0000762f89bcea57  push r9
0000762f89bcea59  push r10
0000762f89bcea5b  push r11
0000762f89bcea5d  sub rsp, 0xF0
0000762f89bcea64  vmovaps [rsp], xmm0
0000762f89bcea69  vmovaps [rsp+0x10], xmm2
0000762f89bcea6f  vmovaps [rsp+0x20], xmm3
0000762f89bcea75  vmovaps [rsp+0x30], xmm4
0000762f89bcea7b  vmovaps [rsp+0x40], xmm5
0000762f89bcea81  vmovaps [rsp+0x50], xmm6
0000762f89bcea87  vmovaps [rsp+0x60], xmm7
0000762f89bcea8d  vmovaps [rsp+0x70], xmm8
0000762f89bcea93  vmovaps [rsp+0x80], xmm9
0000762f89bcea9c  vmovaps [rsp+0x90], xmm10
0000762f89bceaa5  vmovaps [rsp+0xA0], xmm11
0000762f89bceaae  vmovaps [rsp+0xB0], xmm12
0000762f89bceab7  vmovaps [rsp+0xC0], xmm13
0000762f89bceac0  vmovaps [rsp+0xD0], xmm14
0000762f89bceac9  vmovaps [rsp+0xE0], xmm15
0000762f89bcead2  sub rsp, 0x30
0000762f89bcead6  movaps [rsp], xmm1
0000762f89bceada  movaps [rsp+0x10], xmm14
0000762f89bceae0  movaps [rsp+0x20], xmm15
0000762f89bceae6  lea rdi, [rsp]
0000762f89bceaea  mov esi, 0x00
0000762f89bceaef  mov rax, 0x604D6F946530
0000762f89bceaf9  call rax
0000762f89bceafb  movaps xmm1, [rsp]
0000762f89bceaff  add rsp, 0x30
0000762f89bceb03  vmovaps xmm0, [rsp]
0000762f89bceb08  vmovaps xmm2, [rsp+0x10]
0000762f89bceb0e  vmovaps xmm3, [rsp+0x20]
0000762f89bceb14  vmovaps xmm4, [rsp+0x30]
0000762f89bceb1a  vmovaps xmm5, [rsp+0x40]
0000762f89bceb20  vmovaps xmm6, [rsp+0x50]
0000762f89bceb26  vmovaps xmm7, [rsp+0x60]
0000762f89bceb2c  vmovaps xmm8, [rsp+0x70]
0000762f89bceb32  vmovaps xmm9, [rsp+0x80]
0000762f89bceb3b  vmovaps xmm10, [rsp+0x90]
0000762f89bceb44  vmovaps xmm11, [rsp+0xA0]
0000762f89bceb4d  vmovaps xmm12, [rsp+0xB0]
0000762f89bceb56  vmovaps xmm13, [rsp+0xC0]
0000762f89bceb5f  vmovaps xmm14, [rsp+0xD0]
0000762f89bceb68  vmovaps xmm15, [rsp+0xE0]
0000762f89bceb71  add rsp, 0xF0
0000762f89bceb78  pop r11
0000762f89bceb7a  pop r10
0000762f89bceb7c  pop r9
0000762f89bceb7e  pop r8
0000762f89bceb80  pop rsi
0000762f89bceb81  pop rdi
0000762f89bceb82  pop rdx
0000762f89bceb83  pop rcx
0000762f89bceb84  pop rax
0000762f89bceb85  add rsp, 0x08
0000762f89bceb89  jmp 0x0000762F89BCE848
0000762f89bceb8e  call 0x0000762F899FF540
0000762f89bceb93  jmp 0x0000762F89BCE85B
0000762f89bceb98  int3
0000762f89bceb99  nop [rax], eax
0000762f89bceba0  movaps xmm1, [r15+0x180]
0000762f89bceba8  vpmovqd xmm15, xmm1
0000762f89bcebae  pxor xmm14, xmm14
0000762f89bcebb3  punpcklqdq xmm15, xmm14
0000762f89bcebb8  movaps [r15+0x210], xmm15
0000762f89bcebc0  movq xmm15, qword ptr [r15+0x120]
0000762f89bcebc9  movq xmm14, qword ptr [r15+0x130]
0000762f89bcebd2  psubd xmm15, xmm14
0000762f89bcebd7  movq xmm15, xmm15
0000762f89bcebdc  movaps xmm13, [r15+0x170]
0000762f89bcebe4  paddq xmm1, xmm13
0000762f89bcebe9  movaps [r15+0x180], xmm1
0000762f89bcebf1  movq xmm1, qword ptr [r15+0x150]
0000762f89bcebfa  paddd xmm14, xmm1
0000762f89bcebff  movq xmm14, xmm14
0000762f89bcec04  movq xmm14, xmm14
0000762f89bcec09  movaps [r15+0x130], xmm14
0000762f89bcec11  pmovzxdq xmm15, xmm15
0000762f89bcec17  psllq xmm15, 0x00
0000762f89bcec1d  movq xmm1, qword ptr [r15+0x210]
0000762f89bcec26  movq xmm14, qword ptr [r15+0x110]
0000762f89bcec2f  paddd xmm1, xmm14
0000762f89bcec34  movq xmm1, xmm1
0000762f89bcec38  vcvtuqq2pd xmm15, xmm15
0000762f89bcec3e  pmovzxdq xmm1, xmm1
0000762f89bcec43  psllq xmm1, 0x00
0000762f89bcec48  vcvtuqq2pd xmm1, xmm1
0000762f89bcec4e  movaps xmm14, [r15+0x140]
0000762f89bcec56  movaps xmm13, xmm15
0000762f89bcec5a  mulpd xmm13, xmm14
0000762f89bcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000762f89bcec65  ptest xmm12, xmm12
0000762f89bcec6b  jnz 0x0000762F89BCED4E
0000762f89bcec71  movaps [r15+0x220], xmm13
0000762f89bcec79  mov rax, [r15+0x48]
0000762f89bcec7d  mov r14, [r15+0x50]
0000762f89bcec81  lea r12, [r14+rax*1]
0000762f89bcec85  movups [r13+r12*1], xmm13
0000762f89bcec8b  movaps xmm15, [r15+0x160]
0000762f89bcec93  movaps xmm14, xmm1
0000762f89bcec97  mulpd xmm14, xmm15
0000762f89bcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000762f89bceca2  ptest xmm13, xmm13
0000762f89bceca8  jnz 0x0000762F89BCEE9C
0000762f89bcecae  movaps [r15+0x210], xmm14
0000762f89bcecb6  mov r14, [r15+0x40]
0000762f89bcecba  lea r12, [r14+rax*1]
0000762f89bcecbe  movups [r13+r12*1], xmm14
0000762f89bcecc4  lea r14, [rax+0x10]
0000762f89bcecc8  mov [r15+0x48], r14
0000762f89bceccc  xor eax, eax
0000762f89bcecce  mov r12d, 0x200
0000762f89bcecd4  cmp r14, r12
0000762f89bcecd7  cmc
0000762f89bcecd8  lahf
0000762f89bcecd9  seto al
0000762f89bcecdc  mov [r15+0x108], eax
0000762f89bcece3  mov eax, [r15+0x108]
0000762f89bcecea  sahf
0000762f89bceceb  jnz 0x0000762F89BCED1D
0000762f89bceced  cmp dword ptr [r15+0x318], 0x00
0000762f89bcecf5  jz 0x0000762F89BCEFF0
0000762f89bcecfb  nop [rax+rax*1], ax
0000762f89bced04  nop [rax+rax*1], eax
0000762f89bced0c  mov eax, 0x4101EC
0000762f89bced11  mov [r15+0x100], rax
0000762f89bced18  jmp 0x0000762F899FE110
0000762f89bced1d  cmp dword ptr [r15+0x318], 0x00
0000762f89bced25  jz 0x0000762F89BCEBA0
0000762f89bced2b  nop [rax+rax*1], ax
0000762f89bced34  nop [rax+rax*1], eax
0000762f89bced3c  mov eax, 0x4101AC
0000762f89bced41  mov [r15+0x100], rax
0000762f89bced48  jmp 0x0000762F899FE110
0000762f89bced4d  int3
0000762f89bced4e  sub rsp, 0x08
0000762f89bced52  push rax
0000762f89bced53  push rcx
0000762f89bced54  push rdx
0000762f89bced55  push rdi
0000762f89bced56  push rsi
0000762f89bced57  push r8
0000762f89bced59  push r9
0000762f89bced5b  push r10
0000762f89bced5d  push r11
0000762f89bced5f  sub rsp, 0xF0
0000762f89bced66  vmovaps [rsp], xmm0
0000762f89bced6b  vmovaps [rsp+0x10], xmm1
0000762f89bced71  vmovaps [rsp+0x20], xmm2
0000762f89bced77  vmovaps [rsp+0x30], xmm3
0000762f89bced7d  vmovaps [rsp+0x40], xmm4
0000762f89bced83  vmovaps [rsp+0x50], xmm5
0000762f89bced89  vmovaps [rsp+0x60], xmm6
0000762f89bced8f  vmovaps [rsp+0x70], xmm7
0000762f89bced95  vmovaps [rsp+0x80], xmm8
0000762f89bced9e  vmovaps [rsp+0x90], xmm9
0000762f89bceda7  vmovaps [rsp+0xA0], xmm10
0000762f89bcedb0  vmovaps [rsp+0xB0], xmm11
0000762f89bcedb9  vmovaps [rsp+0xC0], xmm12
0000762f89bcedc2  vmovaps [rsp+0xD0], xmm14
0000762f89bcedcb  vmovaps [rsp+0xE0], xmm15
0000762f89bcedd4  sub rsp, 0x30
0000762f89bcedd8  movaps [rsp], xmm13
0000762f89bceddd  movaps [rsp+0x10], xmm15
0000762f89bcede3  movaps [rsp+0x20], xmm14
0000762f89bcede9  lea rdi, [rsp]
0000762f89bceded  mov esi, 0x00
0000762f89bcedf2  mov rax, 0x604D6F946530
0000762f89bcedfc  call rax
0000762f89bcedfe  movaps xmm13, [rsp]
0000762f89bcee03  add rsp, 0x30
0000762f89bcee07  vmovaps xmm0, [rsp]
0000762f89bcee0c  vmovaps xmm1, [rsp+0x10]
0000762f89bcee12  vmovaps xmm2, [rsp+0x20]
0000762f89bcee18  vmovaps xmm3, [rsp+0x30]
0000762f89bcee1e  vmovaps xmm4, [rsp+0x40]
0000762f89bcee24  vmovaps xmm5, [rsp+0x50]
0000762f89bcee2a  vmovaps xmm6, [rsp+0x60]
0000762f89bcee30  vmovaps xmm7, [rsp+0x70]
0000762f89bcee36  vmovaps xmm8, [rsp+0x80]
0000762f89bcee3f  vmovaps xmm9, [rsp+0x90]
0000762f89bcee48  vmovaps xmm10, [rsp+0xA0]
0000762f89bcee51  vmovaps xmm11, [rsp+0xB0]
0000762f89bcee5a  vmovaps xmm12, [rsp+0xC0]
0000762f89bcee63  vmovaps xmm14, [rsp+0xD0]
0000762f89bcee6c  vmovaps xmm15, [rsp+0xE0]
0000762f89bcee75  add rsp, 0xF0
0000762f89bcee7c  pop r11
0000762f89bcee7e  pop r10
0000762f89bcee80  pop r9
0000762f89bcee82  pop r8
0000762f89bcee84  pop rsi
0000762f89bcee85  pop rdi
0000762f89bcee86  pop rdx
0000762f89bcee87  pop rcx
0000762f89bcee88  pop rax
0000762f89bcee89  add rsp, 0x08
0000762f89bcee8d  jmp 0x0000762F89BCEC71
0000762f89bcee92  call 0x0000762F89AC2240
0000762f89bcee97  jmp 0x0000762F89BCEC8B
0000762f89bcee9c  sub rsp, 0x08
0000762f89bceea0  push rax
0000762f89bceea1  push rcx
0000762f89bceea2  push rdx
0000762f89bceea3  push rdi
0000762f89bceea4  push rsi
0000762f89bceea5  push r8
0000762f89bceea7  push r9
0000762f89bceea9  push r10
0000762f89bceeab  push r11
0000762f89bceead  sub rsp, 0xF0
0000762f89bceeb4  vmovaps [rsp], xmm0
0000762f89bceeb9  vmovaps [rsp+0x10], xmm1
0000762f89bceebf  vmovaps [rsp+0x20], xmm2
0000762f89bceec5  vmovaps [rsp+0x30], xmm3
0000762f89bceecb  vmovaps [rsp+0x40], xmm4
0000762f89bceed1  vmovaps [rsp+0x50], xmm5
0000762f89bceed7  vmovaps [rsp+0x60], xmm6
0000762f89bceedd  vmovaps [rsp+0x70], xmm7
0000762f89bceee3  vmovaps [rsp+0x80], xmm8
0000762f89bceeec  vmovaps [rsp+0x90], xmm9
0000762f89bceef5  vmovaps [rsp+0xA0], xmm10
0000762f89bceefe  vmovaps [rsp+0xB0], xmm11
0000762f89bcef07  vmovaps [rsp+0xC0], xmm12
0000762f89bcef10  vmovaps [rsp+0xD0], xmm13
0000762f89bcef19  vmovaps [rsp+0xE0], xmm15
0000762f89bcef22  sub rsp, 0x30
0000762f89bcef26  movaps [rsp], xmm14
0000762f89bcef2b  movaps [rsp+0x10], xmm1
0000762f89bcef30  movaps [rsp+0x20], xmm15
0000762f89bcef36  lea rdi, [rsp]
0000762f89bcef3a  mov esi, 0x00
0000762f89bcef3f  mov rax, 0x604D6F946530
0000762f89bcef49  call rax
0000762f89bcef4b  movaps xmm14, [rsp]
0000762f89bcef50  add rsp, 0x30
0000762f89bcef54  vmovaps xmm0, [rsp]
0000762f89bcef59  vmovaps xmm1, [rsp+0x10]
0000762f89bcef5f  vmovaps xmm2, [rsp+0x20]
0000762f89bcef65  vmovaps xmm3, [rsp+0x30]
0000762f89bcef6b  vmovaps xmm4, [rsp+0x40]
0000762f89bcef71  vmovaps xmm5, [rsp+0x50]
0000762f89bcef77  vmovaps xmm6, [rsp+0x60]
0000762f89bcef7d  vmovaps xmm7, [rsp+0x70]
0000762f89bcef83  vmovaps xmm8, [rsp+0x80]
0000762f89bcef8c  vmovaps xmm9, [rsp+0x90]
0000762f89bcef95  vmovaps xmm10, [rsp+0xA0]
0000762f89bcef9e  vmovaps xmm11, [rsp+0xB0]
0000762f89bcefa7  vmovaps xmm12, [rsp+0xC0]
0000762f89bcefb0  vmovaps xmm13, [rsp+0xD0]
0000762f89bcefb9  vmovaps xmm15, [rsp+0xE0]
0000762f89bcefc2  add rsp, 0xF0
0000762f89bcefc9  pop r11
0000762f89bcefcb  pop r10
0000762f89bcefcd  pop r9
0000762f89bcefcf  pop r8
0000762f89bcefd1  pop rsi
0000762f89bcefd2  pop rdi
0000762f89bcefd3  pop rdx
0000762f89bcefd4  pop rcx
0000762f89bcefd5  pop rax
0000762f89bcefd6  add rsp, 0x08
0000762f89bcefda  jmp 0x0000762F89BCECAE
0000762f89bcefdf  call 0x0000762F89AC34C0
0000762f89bcefe4  jmp 0x0000762F89BCECC4
0000762f89bcefe9  int3
0000762f89bcefea  nop [rax+rax*1], ax
0000762f89bceff0  mov rax, [r15+0xF8]
0000762f89bceff7  lea r14, [rax-0x150]
0000762f89bceffe  mov [r15+0xF8], r14
0000762f89bcf005  mov rax, [r15+0x50]
0000762f89bcf009  lea r12, [rax+0x80]
0000762f89bcf010  movups xmm1, [r13+r12*1]
0000762f89bcf016  lea r12, [rax+0x90]
0000762f89bcf01d  movups xmm15, [r13+r12*1]
0000762f89bcf023  mov qword ptr [r15+0x48], 0x00
0000762f89bcf02b  lea r12, [rax+0x40]
0000762f89bcf02f  movups xmm14, [r13+r12*1]
0000762f89bcf035  lea r12, [rax+0x50]
0000762f89bcf039  movups xmm13, [r13+r12*1]
0000762f89bcf03f  lea r12, [r14+0x120]
0000762f89bcf046  movq xmm12, qword ptr [r15+0x1C0]
0000762f89bcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000762f89bcf058  movq r11, xmm12
0000762f89bcf05d  movq r10, xmm11
0000762f89bcf062  mov [r13+r12*1], r11
0000762f89bcf067  lea r12, [r14+0x128]
0000762f89bcf06e  mov [r13+r12*1], r10
0000762f89bcf073  vxorps xmm12, xmm12, xmm12
0000762f89bcf078  vpbroadcastq xmm12, xmm12
0000762f89bcf07d  lea r12, [r14+0x100]
0000762f89bcf084  movq xmm11, qword ptr [r15+0x200]
0000762f89bcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000762f89bcf096  movq r11, xmm11
0000762f89bcf09b  movq r10, xmm10
0000762f89bcf0a0  mov [r13+r12*1], r11
0000762f89bcf0a5  lea r12, [r14+0x108]
0000762f89bcf0ac  mov [r13+r12*1], r10
0000762f89bcf0b1  lea r12, [r14+0xE0]
0000762f89bcf0b8  movups [r13+r12*1], xmm15
0000762f89bcf0be  lea r12, [r14+0xF0]
0000762f89bcf0c5  movups [r13+r12*1], xmm1
0000762f89bcf0cb  lea r12, [rax+0xC0]
0000762f89bcf0d2  movups xmm1, [r13+r12*1]
0000762f89bcf0d8  lea r12, [rax+0xD0]
0000762f89bcf0df  movups xmm15, [r13+r12*1]
0000762f89bcf0e5  lea r12, [r14+0x110]
0000762f89bcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000762f89bcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000762f89bcf0fe  movq r11, xmm11
0000762f89bcf103  movq r10, xmm10
0000762f89bcf108  mov [r13+r12*1], r11
0000762f89bcf10d  lea r12, [r14+0x118]
0000762f89bcf114  mov [r13+r12*1], r10
0000762f89bcf119  movups xmm11, [r13+rax*1]
0000762f89bcf11f  lea r12, [rax+0x10]
0000762f89bcf123  movups xmm10, [r13+r12*1]
0000762f89bcf129  lea r12, [r14+0x130]
0000762f89bcf130  movq xmm9, qword ptr [r15+0x1A0]
0000762f89bcf139  movq xmm8, qword ptr [r15+0x190]
0000762f89bcf142  movq r11, xmm9
0000762f89bcf147  movq r10, xmm8
0000762f89bcf14c  mov [r13+r12*1], r11
0000762f89bcf151  lea r12, [r14+0x138]
0000762f89bcf158  mov [r13+r12*1], r10
0000762f89bcf15d  lea r12, [rax+0x140]
0000762f89bcf164  movups xmm9, [r13+r12*1]
0000762f89bcf16a  lea r12, [rax+0x150]
0000762f89bcf171  movups xmm8, [r13+r12*1]
0000762f89bcf177  lea r12, [r14+0xC0]
0000762f89bcf17e  movups [r13+r12*1], xmm15
0000762f89bcf184  lea r12, [r14+0xD0]
0000762f89bcf18b  movups [r13+r12*1], xmm1
0000762f89bcf191  lea r12, [rax+0x100]
0000762f89bcf198  movups xmm1, [r13+r12*1]
0000762f89bcf19e  lea r12, [rax+0x110]
0000762f89bcf1a5  movups xmm15, [r13+r12*1]
0000762f89bcf1ab  lea r12, [r14+0x140]
0000762f89bcf1b2  mov r11, [r15+0xE8]
0000762f89bcf1b9  mov [r13+r12*1], r11
0000762f89bcf1be  lea r12, [rax+0x180]
0000762f89bcf1c5  movups xmm7, [r13+r12*1]
0000762f89bcf1cb  lea r12, [rax+0x190]
0000762f89bcf1d2  movups xmm6, [r13+r12*1]
0000762f89bcf1d8  lea r12, [rax+0x1C0]
0000762f89bcf1df  movups xmm5, [r13+r12*1]
0000762f89bcf1e5  lea r12, [rax+0x1D0]
0000762f89bcf1ec  movups xmm4, [r13+r12*1]
0000762f89bcf1f2  lea r12, [r14+0x20]
0000762f89bcf1f6  movups [r13+r12*1], xmm1
0000762f89bcf1fc  lea r12, [r14+0x30]
0000762f89bcf200  movups [r13+r12*1], xmm13
0000762f89bcf206  lea r12, [rax+0x60]
0000762f89bcf20a  movups xmm1, [r13+r12*1]
0000762f89bcf210  lea r12, [rax+0x70]
0000762f89bcf214  movups xmm13, [r13+r12*1]
0000762f89bcf21a  lea r12, [rax+0x20]
0000762f89bcf21e  movups xmm3, [r13+r12*1]
0000762f89bcf224  lea r12, [rax+0x30]
0000762f89bcf228  movups xmm2, [r13+r12*1]
0000762f89bcf22e  movaps [r15+0x1F0], xmm2
0000762f89bcf236  lea r12, [r14+0x60]
0000762f89bcf23a  movups [r13+r12*1], xmm11
0000762f89bcf240  lea r12, [r14+0x70]
0000762f89bcf244  movups [r13+r12*1], xmm5
0000762f89bcf24a  lea r12, [rax+0xE0]
0000762f89bcf251  movups xmm11, [r13+r12*1]
0000762f89bcf257  lea r12, [rax+0xF0]
0000762f89bcf25e  movups xmm5, [r13+r12*1]
0000762f89bcf264  lea r12, [r14+0xA0]
0000762f89bcf26b  movups [r13+r12*1], xmm13
0000762f89bcf271  lea r12, [r14+0xB0]
0000762f89bcf278  movups [r13+r12*1], xmm1
0000762f89bcf27e  lea r12, [rax+0xA0]
0000762f89bcf285  movups xmm1, [r13+r12*1]
0000762f89bcf28b  lea r12, [rax+0xB0]
0000762f89bcf292  movups xmm13, [r13+r12*1]
0000762f89bcf298  lea r12, [rax+0x120]
0000762f89bcf29f  vmovaps [rsp+0x10], xmm1
0000762f89bcf2a5  movups xmm1, [r13+r12*1]
0000762f89bcf2ab  lea r12, [rax+0x130]
0000762f89bcf2b2  vmovaps [rsp+0x20], xmm1
0000762f89bcf2b8  movups xmm1, [r13+r12*1]
0000762f89bcf2be  lea r12, [rax+0x160]
0000762f89bcf2c5  vmovaps [rsp+0x30], xmm1
0000762f89bcf2cb  movups xmm1, [r13+r12*1]
0000762f89bcf2d1  lea r12, [rax+0x170]
0000762f89bcf2d8  vmovaps [rsp+0x40], xmm1
0000762f89bcf2de  movups xmm1, [r13+r12*1]
0000762f89bcf2e4  movaps [r15+0x2B0], xmm1
0000762f89bcf2ec  lea r12, [r14+0x80]
0000762f89bcf2f3  movups [r13+r12*1], xmm13
0000762f89bcf2f9  lea r12, [r14+0x90]
0000762f89bcf300  vmovaps xmm13, [rsp+0x10]
0000762f89bcf306  movups [r13+r12*1], xmm13
0000762f89bcf30c  lea r12, [rax+0x1A0]
0000762f89bcf313  movups xmm13, [r13+r12*1]
0000762f89bcf319  lea r12, [rax+0x1B0]
0000762f89bcf320  vmovaps [rsp+0x10], xmm1
0000762f89bcf326  movups xmm1, [r13+r12*1]
0000762f89bcf32c  movaps [r15+0x290], xmm13
0000762f89bcf334  movaps [r15+0x1E0], xmm1
0000762f89bcf33c  lea r12, [rax+0x1E0]
0000762f89bcf343  vmovaps [rsp+0x50], xmm1
0000762f89bcf349  movups xmm1, [r13+r12*1]
0000762f89bcf34f  lea r12, [rax+0x1F0]
0000762f89bcf356  vmovaps [rsp+0x60], xmm1
0000762f89bcf35c  movups xmm1, [r13+r12*1]
0000762f89bcf362  mov qword ptr [r15+0x50], 0x430920
0000762f89bcf36a  lea rax, [r14+0x40]
0000762f89bcf36e  vmovaps [rsp+0x70], xmm1
0000762f89bcf374  vmovaps xmm1, [rsp+0x40]
0000762f89bcf37a  movups [r13+rax*1], xmm1
0000762f89bcf380  lea rax, [r14+0x50]
0000762f89bcf384  movups [r13+rax*1], xmm10
0000762f89bcf38a  vmovaps xmm1, [rsp+0x70]
0000762f89bcf390  movups [r13+r14*1], xmm1
0000762f89bcf396  lea rax, [r14+0x10]
0000762f89bcf39a  vmovaps xmm1, [rsp+0x60]
0000762f89bcf3a0  movups [r13+rax*1], xmm1
0000762f89bcf3a6  mov rax, [r15+0x40]
0000762f89bcf3aa  vmovaps [rsp+0x40], xmm3
0000762f89bcf3b0  vmovaps xmm1, [rsp+0x40]
0000762f89bcf3b6  por xmm3, xmm1
0000762f89bcf3ba  vmovaps [rsp+0x40], xmm6
0000762f89bcf3c0  vmovaps xmm10, [rsp+0x40]
0000762f89bcf3c6  por xmm6, xmm10
0000762f89bcf3cb  lea r12, [rax+0x30]
0000762f89bcf3cf  mov r11, [r13+r12*1]
0000762f89bcf3d4  lea r12, [rax+0x38]
0000762f89bcf3d8  mov r10, [r13+r12*1]
0000762f89bcf3dd  movq xmm10, r11
0000762f89bcf3e2  vmovaps [rsp+0x40], xmm1
0000762f89bcf3e8  movq xmm1, r10
0000762f89bcf3ed  movq xmm10, xmm10
0000762f89bcf3f2  vmovaps [rsp+0x60], xmm10
0000762f89bcf3f8  movq xmm10, xmm10
0000762f89bcf3fd  movaps [r15+0x130], xmm10
0000762f89bcf405  movq xmm1, xmm1
0000762f89bcf409  vmovaps [rsp+0x70], xmm1
0000762f89bcf40f  movq xmm1, xmm1
0000762f89bcf413  movaps [r15+0x280], xmm1
0000762f89bcf41b  vmovaps [rsp+0x80], xmm9
0000762f89bcf424  vmovaps xmm1, [rsp+0x80]
0000762f89bcf42d  por xmm9, xmm1
0000762f89bcf432  lea r12, [rax+0x20]
0000762f89bcf436  mov r11, [r13+r12*1]
0000762f89bcf43b  lea r12, [rax+0x28]
0000762f89bcf43f  mov r10, [r13+r12*1]
0000762f89bcf444  movq xmm1, r11
0000762f89bcf449  movq xmm10, r10
0000762f89bcf44e  movq xmm1, xmm1
0000762f89bcf452  vmovaps [rsp+0x80], xmm1
0000762f89bcf45b  movq xmm1, xmm1
0000762f89bcf45f  movaps [r15+0x150], xmm1
0000762f89bcf467  movq xmm10, xmm10
0000762f89bcf46c  vmovaps [rsp+0x90], xmm10
0000762f89bcf475  movq xmm10, xmm10
0000762f89bcf47a  movaps [r15+0x140], xmm10
0000762f89bcf482  lea r12, [rax+0x10]
0000762f89bcf486  mov r11, [r13+r12*1]
0000762f89bcf48b  lea r12, [rax+0x18]
0000762f89bcf48f  mov r10, [r13+r12*1]
0000762f89bcf494  movq xmm1, r11
0000762f89bcf499  movq xmm10, r10
0000762f89bcf49e  movq xmm1, xmm1
0000762f89bcf4a2  vmovaps [rsp+0xA0], xmm1
0000762f89bcf4ab  movq xmm1, xmm1
0000762f89bcf4af  movaps [r15+0x170], xmm1
0000762f89bcf4b7  movq xmm10, xmm10
0000762f89bcf4bc  vmovaps [rsp+0xB0], xmm10
0000762f89bcf4c5  movq xmm10, xmm10
0000762f89bcf4ca  movaps [r15+0x160], xmm10
0000762f89bcf4d2  mov r12, [r13+rax*1]
0000762f89bcf4d7  vmovq xmm1, r12
0000762f89bcf4dc  vpbroadcastq xmm1, xmm1
0000762f89bcf4e1  lea r12, [rax+0x08]
0000762f89bcf4e5  mov rax, [r13+r12*1]
0000762f89bcf4ea  movq xmm10, rax
0000762f89bcf4ef  movaps [r15+0x230], xmm10
0000762f89bcf4f7  lea rax, [r14+0x50]
0000762f89bcf4fb  movups xmm10, [r13+rax*1]
0000762f89bcf501  lea rax, [r14+0x60]
0000762f89bcf505  vmovaps [rsp+0xC0], xmm1
0000762f89bcf50e  movups xmm1, [r13+rax*1]
0000762f89bcf514  lea rax, [r14+0x30]
0000762f89bcf518  vmovaps [rsp+0xD0], xmm1
0000762f89bcf521  movups xmm1, [r13+rax*1]
0000762f89bcf527  mov qword ptr [r15+0x60], 0x430920
0000762f89bcf52f  mov qword ptr [r15+0x58], 0x40
0000762f89bcf537  vmovaps [rsp+0xE0], xmm1
0000762f89bcf540  vmovaps [rsp+0xF0], xmm15
0000762f89bcf549  vmovaps xmm15, [rsp+0xC0]
0000762f89bcf552  vmovaps [rsp+0xC0], xmm14
0000762f89bcf55b  vmovaps xmm14, [rsp+0x40]
0000762f89bcf561  vmovaps [rsp+0x40], xmm13
0000762f89bcf567  movaps xmm1, xmm15
0000762f89bcf56b  mulpd xmm1, xmm14
0000762f89bcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000762f89bcf575  ptest xmm13, xmm13
0000762f89bcf57b  jnz 0x0000762F89BD0682
0000762f89bcf581  movq xmm14, qword ptr [r15+0x230]
0000762f89bcf58a  vmovaps [rsp+0x100], xmm14
0000762f89bcf593  vpermilpd xmm14, xmm14, 0x00
0000762f89bcf599  vmovaps [rsp+0x110], xmm1
0000762f89bcf5a2  vmovaps xmm1, [rsp+0xE0]
0000762f89bcf5ab  vmovaps [rsp+0xE0], xmm15
0000762f89bcf5b4  movaps xmm13, xmm1
0000762f89bcf5b8  mulpd xmm13, xmm14
0000762f89bcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000762f89bcf5c3  ptest xmm15, xmm15
0000762f89bcf5c9  jnz 0x0000762F89BD07C4
0000762f89bcf5cf  vxorps xmm1, xmm1, xmm1
0000762f89bcf5d3  vpbroadcastq xmm1, xmm1
0000762f89bcf5d8  vmovaps xmm14, [rsp+0xE0]
0000762f89bcf5e1  vmovaps [rsp+0xE0], xmm1
0000762f89bcf5ea  vmovaps xmm1, [rsp+0xD0]
0000762f89bcf5f3  vmovaps [rsp+0xD0], xmm13
0000762f89bcf5fc  movaps xmm15, xmm14
0000762f89bcf600  mulpd xmm15, xmm1
0000762f89bcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000762f89bcf60b  ptest xmm13, xmm13
0000762f89bcf611  jnz 0x0000762F89BD0907
0000762f89bcf617  movaps xmm1, xmm14
0000762f89bcf61b  mulpd xmm1, xmm10
0000762f89bcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000762f89bcf625  ptest xmm13, xmm13
0000762f89bcf62b  jnz 0x0000762F89BD0A4A
0000762f89bcf631  movaps xmm13, xmm14
0000762f89bcf635  mulpd xmm13, xmm2
0000762f89bcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000762f89bcf640  ptest xmm10, xmm10
0000762f89bcf646  jnz 0x0000762F89BD0B8C
0000762f89bcf64c  vmovaps [rsp+0x120], xmm7
0000762f89bcf655  vmovaps xmm14, [rsp+0x120]
0000762f89bcf65e  por xmm7, xmm14
0000762f89bcf663  vmovaps xmm14, [rsp+0xC0]
0000762f89bcf66c  vmovaps xmm10, [rsp+0xC0]
0000762f89bcf675  por xmm14, xmm10
0000762f89bcf67a  vmovaps xmm2, [rsp+0x100]
0000762f89bcf683  vpermilpd xmm2, xmm2, 0x00
0000762f89bcf689  vmovaps [rsp+0xC0], xmm1
0000762f89bcf692  vmovaps [rsp+0x120], xmm15
0000762f89bcf69b  movaps xmm1, xmm10
0000762f89bcf69f  mulpd xmm1, xmm2
0000762f89bcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000762f89bcf6a8  ptest xmm15, xmm15
0000762f89bcf6ae  jnz 0x0000762F89BD0CCF
0000762f89bcf6b4  xor eax, eax
0000762f89bcf6b6  mov r12d, 0x40
0000762f89bcf6bc  mov r11d, 0x200
0000762f89bcf6c2  cmp r12, r11
0000762f89bcf6c5  cmc
0000762f89bcf6c6  lahf
0000762f89bcf6c7  seto al
0000762f89bcf6ca  mov [r15+0x108], eax
0000762f89bcf6d1  vmovaps xmm10, [rsp+0x110]
0000762f89bcf6da  vmovaps xmm2, [rsp+0xE0]
0000762f89bcf6e3  vmovaps [rsp+0xE0], xmm1
0000762f89bcf6ec  movaps xmm15, xmm10
0000762f89bcf6f0  addpd xmm15, xmm2
0000762f89bcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000762f89bcf6fb  ptest xmm1, xmm1
0000762f89bcf700  jnz 0x0000762F89BD0E10
0000762f89bcf706  vmovaps xmm10, [rsp+0x120]
0000762f89bcf70f  vmovaps [rsp+0x110], xmm15
0000762f89bcf718  movaps xmm1, xmm10
0000762f89bcf71c  addpd xmm1, xmm12
0000762f89bcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000762f89bcf726  ptest xmm15, xmm15
0000762f89bcf72c  jnz 0x0000762F89BD0F53
0000762f89bcf732  vmovaps xmm10, [rsp+0xC0]
0000762f89bcf73b  vmovaps [rsp+0xC0], xmm1
0000762f89bcf744  movaps xmm15, xmm10
0000762f89bcf748  addpd xmm15, xmm12
0000762f89bcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000762f89bcf753  ptest xmm1, xmm1
0000762f89bcf758  jnz 0x0000762F89BD1095
0000762f89bcf75e  vmovaps xmm1, [rsp+0x30]
0000762f89bcf764  vmovaps xmm12, [rsp+0x30]
0000762f89bcf76a  por xmm1, xmm12
0000762f89bcf76f  vmovaps xmm12, [rsp+0x20]
0000762f89bcf775  vmovaps xmm10, [rsp+0x20]
0000762f89bcf77b  por xmm12, xmm10
0000762f89bcf780  vmovaps [rsp+0x20], xmm5
0000762f89bcf786  vmovaps xmm10, [rsp+0x20]
0000762f89bcf78c  por xmm5, xmm10
0000762f89bcf791  vmovaps [rsp+0x20], xmm11
0000762f89bcf797  vmovaps xmm10, [rsp+0x20]
0000762f89bcf79d  por xmm11, xmm10
0000762f89bcf7a2  vmovaps [rsp+0x20], xmm4
0000762f89bcf7a8  vmovaps xmm10, [rsp+0x20]
0000762f89bcf7ae  por xmm4, xmm10
0000762f89bcf7b3  vmovaps [rsp+0x20], xmm8
0000762f89bcf7b9  vmovaps xmm10, [rsp+0x20]
0000762f89bcf7bf  por xmm8, xmm10
0000762f89bcf7c4  vmovaps xmm10, [rsp+0xF0]
0000762f89bcf7cd  vmovaps [rsp+0x20], xmm1
0000762f89bcf7d3  vmovaps xmm1, [rsp+0xF0]
0000762f89bcf7dc  por xmm10, xmm1
0000762f89bcf7e1  lea rax, [r14+0xA0]
0000762f89bcf7e8  movups xmm1, [r13+rax*1]
0000762f89bcf7ee  lea rax, [r14+0xB0]
0000762f89bcf7f5  vmovaps [rsp+0x30], xmm1
0000762f89bcf7fb  movups xmm1, [r13+rax*1]
0000762f89bcf801  vmovaps [rsp+0xF0], xmm1
0000762f89bcf80a  vmovaps [rsp+0x120], xmm15
0000762f89bcf813  movaps xmm1, xmm13
0000762f89bcf817  addpd xmm1, xmm2
0000762f89bcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000762f89bcf820  ptest xmm15, xmm15
0000762f89bcf826  jnz 0x0000762F89BD11ED
0000762f89bcf82c  lea rax, [r14+0xF0]
0000762f89bcf833  movups xmm15, [r13+rax*1]
0000762f89bcf839  vmovaps xmm2, [rsp+0xC0]
0000762f89bcf842  vmovaps [rsp+0xC0], xmm1
0000762f89bcf84b  vmovaps xmm1, [rsp+0xE0]
0000762f89bcf854  vmovaps [rsp+0xE0], xmm15
0000762f89bcf85d  movaps xmm13, xmm2
0000762f89bcf861  addpd xmm13, xmm1
0000762f89bcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000762f89bcf86c  ptest xmm15, xmm15
0000762f89bcf872  jnz 0x0000762F89BD1338
0000762f89bcf878  vmovaps xmm15, [rsp+0x120]
0000762f89bcf881  vmovaps xmm2, [rsp+0xD0]
0000762f89bcf88a  vmovaps [rsp+0xD0], xmm14
0000762f89bcf893  movaps xmm1, xmm15
0000762f89bcf897  addpd xmm1, xmm2
0000762f89bcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000762f89bcf8a0  ptest xmm14, xmm14
0000762f89bcf8a6  jnz 0x0000762F89BD147A
0000762f89bcf8ac  vmovaps xmm15, [rsp+0x100]
0000762f89bcf8b5  vpermilpd xmm15, xmm15, 0x00
0000762f89bcf8bb  vmovaps xmm2, [rsp+0xF0]
0000762f89bcf8c4  vmovaps [rsp+0xF0], xmm1
0000762f89bcf8cd  movaps xmm14, xmm2
0000762f89bcf8d1  mulpd xmm14, xmm15
0000762f89bcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000762f89bcf8dc  ptest xmm1, xmm1
0000762f89bcf8e1  jnz 0x0000762F89BD15BB
0000762f89bcf8e7  vmovaps xmm1, [rsp+0xA0]
0000762f89bcf8f0  vpermilpd xmm1, xmm1, 0x00
0000762f89bcf8f6  vmovaps xmm2, [rsp+0xE0]
0000762f89bcf8ff  vmovaps [rsp+0xE0], xmm14
0000762f89bcf908  movaps xmm15, xmm2
0000762f89bcf90c  mulpd xmm15, xmm1
0000762f89bcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000762f89bcf917  ptest xmm14, xmm14
0000762f89bcf91d  jnz 0x0000762F89BD16FE
0000762f89bcf923  lea rax, [r14+0xE0]
0000762f89bcf92a  movups xmm1, [r13+rax*1]
0000762f89bcf930  vmovaps xmm14, [rsp+0x100]
0000762f89bcf939  vpermilpd xmm14, xmm14, 0x00
0000762f89bcf93f  vmovaps [rsp+0x100], xmm1
0000762f89bcf948  vmovaps xmm1, [rsp+0x30]
0000762f89bcf94e  vmovaps [rsp+0x30], xmm15
0000762f89bcf954  movaps xmm2, xmm1
0000762f89bcf957  mulpd xmm2, xmm14
0000762f89bcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000762f89bcf961  ptest xmm15, xmm15
0000762f89bcf967  jnz 0x0000762F89BD184A
0000762f89bcf96d  vmovaps [rsp+0x120], xmm10
0000762f89bcf976  vmovaps xmm1, [rsp+0x120]
0000762f89bcf97f  por xmm10, xmm1
0000762f89bcf984  movaps [r15+0x300], xmm10
0000762f89bcf98c  vmovaps [rsp+0x120], xmm8
0000762f89bcf995  vmovaps xmm1, [rsp+0x120]
0000762f89bcf99e  por xmm8, xmm1
0000762f89bcf9a3  movaps [r15+0x190], xmm8
0000762f89bcf9ab  vmovaps xmm1, [rsp+0xA0]
0000762f89bcf9b4  vpermilpd xmm1, xmm1, 0x00
0000762f89bcf9ba  vmovaps xmm14, [rsp+0x100]
0000762f89bcf9c3  vmovaps [rsp+0x100], xmm13
0000762f89bcf9cc  movaps xmm15, xmm14
0000762f89bcf9d0  mulpd xmm15, xmm1
0000762f89bcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000762f89bcf9db  ptest xmm13, xmm13
0000762f89bcf9e1  jnz 0x0000762F89BD198B
0000762f89bcf9e7  lea rax, [r14+0x90]
0000762f89bcf9ee  movups xmm1, [r13+rax*1]
0000762f89bcf9f4  vmovaps [rsp+0x120], xmm4
0000762f89bcf9fd  vmovaps xmm14, [rsp+0x120]
0000762f89bcfa06  por xmm4, xmm14
0000762f89bcfa0b  movaps [r15+0x1C0], xmm4
0000762f89bcfa13  vmovaps [rsp+0x120], xmm11
0000762f89bcfa1c  vmovaps xmm14, [rsp+0x120]
0000762f89bcfa25  por xmm11, xmm14
0000762f89bcfa2a  movaps [r15+0x200], xmm11
0000762f89bcfa32  vmovaps [rsp+0x120], xmm5
0000762f89bcfa3b  vmovaps xmm14, [rsp+0x120]
0000762f89bcfa44  por xmm5, xmm14
0000762f89bcfa49  movaps [r15+0x2D0], xmm5
0000762f89bcfa51  vmovaps [rsp+0x120], xmm12
0000762f89bcfa5a  vmovaps xmm14, [rsp+0x120]
0000762f89bcfa63  por xmm12, xmm14
0000762f89bcfa68  movaps [r15+0x2E0], xmm12
0000762f89bcfa70  vmovaps xmm13, [rsp+0x110]
0000762f89bcfa79  vmovaps [rsp+0x110], xmm1
0000762f89bcfa82  vmovaps xmm1, [rsp+0xE0]
0000762f89bcfa8b  vmovaps [rsp+0xE0], xmm15
0000762f89bcfa94  movaps xmm14, xmm13
0000762f89bcfa98  addpd xmm14, xmm1
0000762f89bcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000762f89bcfaa3  ptest xmm15, xmm15
0000762f89bcfaa9  jnz 0x0000762F89BD1AD8
0000762f89bcfaaf  vmovaps xmm1, [rsp+0xA0]
0000762f89bcfab8  vpermilpd xmm1, xmm1, 0x00
0000762f89bcfabe  vmovaps xmm13, [rsp+0x110]
0000762f89bcfac7  vmovaps [rsp+0x110], xmm14
0000762f89bcfad0  movaps xmm15, xmm13
0000762f89bcfad4  mulpd xmm15, xmm1
0000762f89bcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000762f89bcfadf  ptest xmm14, xmm14
0000762f89bcfae5  jnz 0x0000762F89BD1C1B
0000762f89bcfaeb  lea rax, [r14+0x80]
0000762f89bcfaf2  movups xmm1, [r13+rax*1]
0000762f89bcfaf8  vmovaps xmm13, [rsp+0xC0]
0000762f89bcfb01  vmovaps [rsp+0xC0], xmm1
0000762f89bcfb0a  movaps xmm14, xmm13
0000762f89bcfb0e  addpd xmm14, xmm2
0000762f89bcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000762f89bcfb19  ptest xmm1, xmm1
0000762f89bcfb1e  jnz 0x0000762F89BD1D68
0000762f89bcfb24  vmovaps xmm13, [rsp+0x100]
0000762f89bcfb2d  vmovaps xmm2, [rsp+0x30]
0000762f89bcfb33  vmovaps [rsp+0x30], xmm15
0000762f89bcfb39  movaps xmm1, xmm13
0000762f89bcfb3d  addpd xmm1, xmm2
0000762f89bcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000762f89bcfb46  ptest xmm15, xmm15
0000762f89bcfb4c  jnz 0x0000762F89BD1EAB
0000762f89bcfb52  vmovaps xmm15, [rsp+0x20]
0000762f89bcfb58  vmovaps xmm13, [rsp+0x20]
0000762f89bcfb5e  por xmm15, xmm13
0000762f89bcfb63  movaps [r15+0x2F0], xmm15
0000762f89bcfb6b  vmovaps xmm13, [rsp+0xA0]
0000762f89bcfb74  vpermilpd xmm13, xmm13, 0x00
0000762f89bcfb7a  vmovaps [rsp+0x20], xmm1
0000762f89bcfb80  vmovaps xmm1, [rsp+0xC0]
0000762f89bcfb89  vmovaps [rsp+0xA0], xmm15
0000762f89bcfb92  movaps xmm2, xmm1
0000762f89bcfb95  mulpd xmm2, xmm13
0000762f89bcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000762f89bcfb9f  ptest xmm15, xmm15
0000762f89bcfba5  jnz 0x0000762F89BD1FEC
0000762f89bcfbab  lea rax, [r14+0xD0]
0000762f89bcfbb2  movups xmm1, [r13+rax*1]
0000762f89bcfbb8  vmovaps xmm13, [rsp+0xF0]
0000762f89bcfbc1  vmovaps [rsp+0xC0], xmm1
0000762f89bcfbca  vmovaps xmm1, [rsp+0xE0]
0000762f89bcfbd3  vmovaps [rsp+0xE0], xmm14
0000762f89bcfbdc  movaps xmm15, xmm13
0000762f89bcfbe0  addpd xmm15, xmm1
0000762f89bcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000762f89bcfbeb  ptest xmm14, xmm14
0000762f89bcfbf1  jnz 0x0000762F89BD2137
0000762f89bcfbf7  vmovaps xmm1, [rsp+0xB0]
0000762f89bcfc00  vpermilpd xmm1, xmm1, 0x00
0000762f89bcfc06  movaps xmm14, xmm11
0000762f89bcfc0a  mulpd xmm14, xmm1
0000762f89bcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000762f89bcfc15  ptest xmm13, xmm13
0000762f89bcfc1b  jnz 0x0000762F89BD227A
0000762f89bcfc21  movaps [r15+0x260], xmm14
0000762f89bcfc29  vxorps xmm1, xmm1, xmm1
0000762f89bcfc2d  vpbroadcastq xmm1, xmm1
0000762f89bcfc32  movaps [r15+0x1B0], xmm1
0000762f89bcfc3a  vmovaps xmm1, [rsp+0xB0]
0000762f89bcfc43  vpermilpd xmm1, xmm1, 0x00
0000762f89bcfc49  vmovaps xmm11, [rsp+0xC0]
0000762f89bcfc52  vmovaps [rsp+0xC0], xmm15
0000762f89bcfc5b  movaps xmm13, xmm11
0000762f89bcfc5f  mulpd xmm13, xmm1
0000762f89bcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000762f89bcfc6a  ptest xmm15, xmm15
0000762f89bcfc70  jnz 0x0000762F89BD23BD
0000762f89bcfc76  lea rax, [r14+0xC0]
0000762f89bcfc7d  movups xmm1, [r13+rax*1]
0000762f89bcfc83  vmovaps xmm11, [rsp+0x110]
0000762f89bcfc8c  vmovaps [rsp+0xF0], xmm1
0000762f89bcfc95  vmovaps xmm1, [rsp+0x30]
0000762f89bcfc9b  vmovaps [rsp+0x30], xmm14
0000762f89bcfca1  movaps xmm15, xmm11
0000762f89bcfca5  addpd xmm15, xmm1
0000762f89bcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000762f89bcfcb0  ptest xmm14, xmm14
0000762f89bcfcb6  jnz 0x0000762F89BD250A
0000762f89bcfcbc  vmovaps [rsp+0x100], xmm9
0000762f89bcfcc5  vmovaps xmm1, [rsp+0x100]
0000762f89bcfcce  por xmm9, xmm1
0000762f89bcfcd3  movaps [r15+0x270], xmm9
0000762f89bcfcdb  vmovaps [rsp+0x100], xmm6
0000762f89bcfce4  vmovaps xmm1, [rsp+0x100]
0000762f89bcfced  por xmm6, xmm1
0000762f89bcfcf1  movaps [r15+0x1A0], xmm6
0000762f89bcfcf9  vmovaps xmm14, [rsp+0xB0]
0000762f89bcfd02  vpermilpd xmm14, xmm14, 0x00
0000762f89bcfd08  vmovaps xmm6, [rsp+0xF0]
0000762f89bcfd11  vmovaps [rsp+0xF0], xmm1
0000762f89bcfd1a  movaps xmm11, xmm6
0000762f89bcfd1e  mulpd xmm11, xmm14
0000762f89bcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000762f89bcfd29  ptest xmm1, xmm1
0000762f89bcfd2e  jnz 0x0000762F89BD264D
0000762f89bcfd34  lea rax, [r14+0x20]
0000762f89bcfd38  movups xmm1, [r13+rax*1]
0000762f89bcfd3e  movaps [r15+0x110], xmm1
0000762f89bcfd46  vmovaps xmm6, [rsp+0xE0]
0000762f89bcfd4f  vmovaps [rsp+0xE0], xmm1
0000762f89bcfd58  movaps xmm14, xmm6
0000762f89bcfd5c  addpd xmm14, xmm2
0000762f89bcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000762f89bcfd67  ptest xmm1, xmm1
0000762f89bcfd6c  jnz 0x0000762F89BD279A
0000762f89bcfd72  vmovaps xmm1, [rsp+0xB0]
0000762f89bcfd7b  vpermilpd xmm1, xmm1, 0x00
0000762f89bcfd81  movaps xmm6, xmm5
0000762f89bcfd84  mulpd xmm6, xmm1
0000762f89bcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000762f89bcfd8d  ptest xmm2, xmm2
0000762f89bcfd92  jnz 0x0000762F89BD28DC
0000762f89bcfd98  vmovaps xmm5, [rsp+0x20]
0000762f89bcfd9e  movaps xmm1, xmm5
0000762f89bcfda1  addpd xmm1, xmm13
0000762f89bcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000762f89bcfdab  ptest xmm2, xmm2
0000762f89bcfdb0  jnz 0x0000762F89BD2A1C
0000762f89bcfdb6  vmovaps xmm13, [rsp+0x80]
0000762f89bcfdbf  vpermilpd xmm13, xmm13, 0x00
0000762f89bcfdc5  vmovaps xmm2, [rsp+0xE0]
0000762f89bcfdce  vmovaps [rsp+0x20], xmm1
0000762f89bcfdd4  movaps xmm5, xmm2
0000762f89bcfdd7  mulpd xmm5, xmm13
0000762f89bcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000762f89bcfde1  ptest xmm1, xmm1
0000762f89bcfde6  jnz 0x0000762F89BD2B5D
0000762f89bcfdec  vmovaps xmm1, [rsp+0x80]
0000762f89bcfdf5  vpermilpd xmm1, xmm1, 0x00
0000762f89bcfdfb  movaps xmm13, xmm10
0000762f89bcfdff  mulpd xmm13, xmm1
0000762f89bcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000762f89bcfe0a  ptest xmm2, xmm2
0000762f89bcfe0f  jnz 0x0000762F89BD2C9E
0000762f89bcfe15  vmovaps xmm10, [rsp+0x30]
0000762f89bcfe1b  movaps xmm1, xmm15
0000762f89bcfe1f  addpd xmm1, xmm10
0000762f89bcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000762f89bcfe29  ptest xmm2, xmm2
0000762f89bcfe2e  jnz 0x0000762F89BD2DE1
0000762f89bcfe34  vmovaps xmm10, [rsp+0xC0]
0000762f89bcfe3d  movaps xmm15, xmm10
0000762f89bcfe41  addpd xmm15, xmm11
0000762f89bcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000762f89bcfe4c  ptest xmm2, xmm2
0000762f89bcfe51  jnz 0x0000762F89BD2F23
0000762f89bcfe57  vmovaps xmm11, [rsp+0x80]
0000762f89bcfe60  vpermilpd xmm11, xmm11, 0x00
0000762f89bcfe66  movaps xmm10, xmm12
0000762f89bcfe6a  mulpd xmm10, xmm11
0000762f89bcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000762f89bcfe75  ptest xmm2, xmm2
0000762f89bcfe7a  jnz 0x0000762F89BD3067
0000762f89bcfe80  vmovaps xmm12, [rsp+0x80]
0000762f89bcfe89  vpermilpd xmm12, xmm12, 0x00
0000762f89bcfe8f  vmovaps xmm2, [rsp+0xA0]
0000762f89bcfe98  vmovaps [rsp+0x30], xmm1
0000762f89bcfe9e  movaps xmm11, xmm2
0000762f89bcfea2  mulpd xmm11, xmm12
0000762f89bcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000762f89bcfead  ptest xmm1, xmm1
0000762f89bcfeb2  jnz 0x0000762F89BD31AB
0000762f89bcfeb8  movaps xmm1, xmm14
0000762f89bcfebc  addpd xmm1, xmm6
0000762f89bcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000762f89bcfec5  ptest xmm12, xmm12
0000762f89bcfecb  jnz 0x0000762F89BD32EE
0000762f89bcfed1  vmovaps xmm12, [rsp+0x20]
0000762f89bcfed7  movaps xmm14, xmm12
0000762f89bcfedb  addpd xmm14, xmm5
0000762f89bcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000762f89bcfee6  ptest xmm6, xmm6
0000762f89bcfeeb  jnz 0x0000762F89BD342F
0000762f89bcfef1  vmovaps xmm12, [rsp+0x90]
0000762f89bcfefa  vpermilpd xmm12, xmm12, 0x00
0000762f89bcff00  movaps xmm6, xmm9
0000762f89bcff04  mulpd xmm6, xmm12
0000762f89bcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000762f89bcff0e  ptest xmm5, xmm5
0000762f89bcff13  jnz 0x0000762F89BD3572
0000762f89bcff19  movaps xmm12, xmm15
0000762f89bcff1d  addpd xmm12, xmm13
0000762f89bcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000762f89bcff28  ptest xmm9, xmm9
0000762f89bcff2e  jnz 0x0000762F89BD36B4
0000762f89bcff34  vmovaps xmm13, [rsp+0x30]
0000762f89bcff3a  movaps xmm15, xmm13
0000762f89bcff3e  addpd xmm15, xmm10
0000762f89bcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000762f89bcff49  ptest xmm9, xmm9
0000762f89bcff4f  jnz 0x0000762F89BD37F8
0000762f89bcff55  vmovaps xmm13, [rsp+0xD0]
0000762f89bcff5e  vmovaps xmm10, [rsp+0xD0]
0000762f89bcff67  por xmm13, xmm10
0000762f89bcff6c  movaps [r15+0x250], xmm13
0000762f89bcff74  vmovaps [rsp+0x20], xmm7
0000762f89bcff7a  vmovaps xmm13, [rsp+0x20]
0000762f89bcff80  por xmm7, xmm13
0000762f89bcff85  movaps [r15+0x2A0], xmm7
0000762f89bcff8d  vmovaps [rsp+0x20], xmm3
0000762f89bcff93  vmovaps xmm13, [rsp+0x20]
0000762f89bcff99  por xmm3, xmm13
0000762f89bcff9e  movaps [r15+0x1D0], xmm3
0000762f89bcffa6  lea rax, [r14+0x40]
0000762f89bcffaa  movups xmm13, [r13+rax*1]
0000762f89bcffb0  movaps [r15+0x2C0], xmm13
0000762f89bcffb8  vmovaps xmm10, [rsp+0x90]
0000762f89bcffc1  vpermilpd xmm10, xmm10, 0x00
0000762f89bcffc7  movaps xmm9, xmm8
0000762f89bcffcb  mulpd xmm9, xmm10
0000762f89bcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000762f89bcffd6  ptest xmm5, xmm5
0000762f89bcffdb  jnz 0x0000762F89BD3946
0000762f89bcffe1  movaps xmm10, xmm1
0000762f89bcffe5  addpd xmm10, xmm11
0000762f89bcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000762f89bcfff0  ptest xmm8, xmm8
0000762f89bcfff6  jnz 0x0000762F89BD3A8A
0000762f89bcfffc  movaps xmm1, xmm14
0000762f89bd0000  addpd xmm1, xmm6
0000762f89bd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000762f89bd0009  ptest xmm11, xmm11
0000762f89bd000f  jnz 0x0000762F89BD3BCD
0000762f89bd0015  vmovaps xmm14, [rsp+0x90]
0000762f89bd001e  vpermilpd xmm14, xmm14, 0x00
0000762f89bd0024  movaps xmm11, xmm13
0000762f89bd0028  mulpd xmm11, xmm14
0000762f89bd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000762f89bd0033  ptest xmm8, xmm8
0000762f89bd0039  jnz 0x0000762F89BD3D0E
0000762f89bd003f  vmovaps xmm14, [rsp+0x90]
0000762f89bd0048  vpermilpd xmm14, xmm14, 0x00
0000762f89bd004e  vmovaps xmm8, [rsp+0x10]
0000762f89bd0054  movaps xmm13, xmm8
0000762f89bd0058  mulpd xmm13, xmm14
0000762f89bd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000762f89bd0063  ptest xmm6, xmm6
0000762f89bd0068  jnz 0x0000762F89BD3E52
0000762f89bd006e  vmovaps xmm14, [rsp+0x60]
0000762f89bd0074  vpermilpd xmm14, xmm14, 0x00
0000762f89bd007a  movaps xmm8, xmm7
0000762f89bd007e  mulpd xmm8, xmm14
0000762f89bd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000762f89bd0089  ptest xmm6, xmm6
0000762f89bd008e  jnz 0x0000762F89BD3F96
0000762f89bd0094  movaps xmm14, xmm12
0000762f89bd0098  addpd xmm14, xmm9
0000762f89bd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000762f89bd00a3  ptest xmm7, xmm7
0000762f89bd00a8  jnz 0x0000762F89BD40D9
0000762f89bd00ae  vmovaps xmm12, [rsp+0x60]
0000762f89bd00b4  vpermilpd xmm12, xmm12, 0x00
0000762f89bd00ba  vmovaps xmm7, [rsp+0xF0]
0000762f89bd00c3  movaps xmm9, xmm7
0000762f89bd00c7  mulpd xmm9, xmm12
0000762f89bd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000762f89bd00d2  ptest xmm6, xmm6
0000762f89bd00d7  jnz 0x0000762F89BD421D
0000762f89bd00dd  movaps xmm12, xmm15
0000762f89bd00e1  addpd xmm12, xmm11
0000762f89bd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000762f89bd00ec  ptest xmm7, xmm7
0000762f89bd00f1  jnz 0x0000762F89BD4360
0000762f89bd00f7  vmovaps xmm15, [rsp+0x60]
0000762f89bd00fd  vpermilpd xmm15, xmm15, 0x00
0000762f89bd0103  vmovaps xmm7, [rsp+0x40]
0000762f89bd0109  movaps xmm11, xmm7
0000762f89bd010d  mulpd xmm11, xmm15
0000762f89bd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000762f89bd0118  ptest xmm6, xmm6
0000762f89bd011d  jnz 0x0000762F89BD44A4
0000762f89bd0123  movaps xmm15, xmm10
0000762f89bd0127  addpd xmm15, xmm13
0000762f89bd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000762f89bd0132  ptest xmm7, xmm7
0000762f89bd0137  jnz 0x0000762F89BD45E7
0000762f89bd013d  vmovaps xmm13, [rsp+0x60]
0000762f89bd0143  vpermilpd xmm13, xmm13, 0x00
0000762f89bd0149  vmovaps xmm7, [rsp+0x50]
0000762f89bd014f  movaps xmm10, xmm7
0000762f89bd0153  mulpd xmm10, xmm13
0000762f89bd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000762f89bd015e  ptest xmm6, xmm6
0000762f89bd0163  jnz 0x0000762F89BD472B
0000762f89bd0169  movaps xmm13, xmm1
0000762f89bd016d  addpd xmm13, xmm8
0000762f89bd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000762f89bd0178  ptest xmm7, xmm7
0000762f89bd017d  jnz 0x0000762F89BD486E
0000762f89bd0183  lea rax, [r14+0x70]
0000762f89bd0187  movups xmm1, [r13+rax*1]
0000762f89bd018d  movaps [r15+0x240], xmm1
0000762f89bd0195  movaps xmm8, xmm14
0000762f89bd0199  addpd xmm8, xmm9
0000762f89bd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000762f89bd01a4  ptest xmm7, xmm7
0000762f89bd01a9  jnz 0x0000762F89BD49BB
0000762f89bd01af  movaps [r15+0x170], xmm8
0000762f89bd01b7  vmovaps xmm14, [rsp+0x70]
0000762f89bd01bd  vpermilpd xmm14, xmm14, 0x00
0000762f89bd01c3  movaps xmm9, xmm1
0000762f89bd01c7  mulpd xmm9, xmm14
0000762f89bd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000762f89bd01d2  ptest xmm7, xmm7
0000762f89bd01d7  jnz 0x0000762F89BD4AFF
0000762f89bd01dd  vmovaps xmm1, [rsp+0x70]
0000762f89bd01e3  vpermilpd xmm1, xmm1, 0x00
0000762f89bd01e9  movaps xmm14, xmm4
0000762f89bd01ed  mulpd xmm14, xmm1
0000762f89bd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000762f89bd01f8  ptest xmm7, xmm7
0000762f89bd01fd  jnz 0x0000762F89BD4C42
0000762f89bd0203  movaps [r15+0x180], xmm14
0000762f89bd020b  movaps xmm1, xmm12
0000762f89bd020f  addpd xmm1, xmm11
0000762f89bd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000762f89bd0219  ptest xmm7, xmm7
0000762f89bd021e  jnz 0x0000762F89BD4D84
0000762f89bd0224  movaps [r15+0x210], xmm1
0000762f89bd022c  movups xmm12, [r13+r14*1]
0000762f89bd0232  lea rax, [r14+0x10]
0000762f89bd0236  movups xmm11, [r13+rax*1]
0000762f89bd023c  movaps [r15+0x230], xmm11
0000762f89bd0244  movaps xmm7, xmm15
0000762f89bd0248  addpd xmm7, xmm10
0000762f89bd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000762f89bd0252  ptest xmm6, xmm6
0000762f89bd0257  jnz 0x0000762F89BD4EDA
0000762f89bd025d  movaps [r15+0x130], xmm7
0000762f89bd0265  vmovaps xmm15, [rsp+0x70]
0000762f89bd026b  vpermilpd xmm15, xmm15, 0x00
0000762f89bd0271  movaps xmm10, xmm11
0000762f89bd0275  mulpd xmm10, xmm15
0000762f89bd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000762f89bd0280  ptest xmm6, xmm6
0000762f89bd0285  jnz 0x0000762F89BD501C
0000762f89bd028b  movaps [r15+0x220], xmm10
0000762f89bd0293  vmovaps xmm15, [rsp+0x70]
0000762f89bd0299  vpermilpd xmm15, xmm15, 0x00
0000762f89bd029f  movaps xmm11, xmm12
0000762f89bd02a3  mulpd xmm11, xmm15
0000762f89bd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000762f89bd02ae  ptest xmm6, xmm6
0000762f89bd02b3  jnz 0x0000762F89BD5160
0000762f89bd02b9  movaps xmm15, xmm13
0000762f89bd02bd  addpd xmm15, xmm9
0000762f89bd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000762f89bd02c8  ptest xmm12, xmm12
0000762f89bd02ce  jnz 0x0000762F89BD52A4
0000762f89bd02d4  movaps [r15+0x140], xmm15
0000762f89bd02dc  movaps xmm13, xmm8
0000762f89bd02e0  addpd xmm13, xmm14
0000762f89bd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000762f89bd02eb  ptest xmm12, xmm12
0000762f89bd02f1  jnz 0x0000762F89BD53E8
0000762f89bd02f7  movaps [r15+0x150], xmm13
0000762f89bd02ff  movaps xmm14, xmm1
0000762f89bd0303  addpd xmm14, xmm10
0000762f89bd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000762f89bd030e  ptest xmm12, xmm12
0000762f89bd0314  jnz 0x0000762F89BD552C
0000762f89bd031a  movaps [r15+0x160], xmm14
0000762f89bd0322  movaps xmm1, xmm7
0000762f89bd0325  addpd xmm1, xmm11
0000762f89bd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000762f89bd032f  ptest xmm12, xmm12
0000762f89bd0335  jnz 0x0000762F89BD566F
0000762f89bd033b  movaps [r15+0x120], xmm1
0000762f89bd0343  mov eax, 0x430920
0000762f89bd0348  movups [r13+rax*1], xmm15
0000762f89bd034e  mov eax, 0x430930
0000762f89bd0353  movups [r13+rax*1], xmm13
0000762f89bd0359  mov eax, 0x430940
0000762f89bd035e  movups [r13+rax*1], xmm14
0000762f89bd0364  mov eax, 0x430950
0000762f89bd0369  movups [r13+rax*1], xmm1
0000762f89bd036f  mov eax, [r15+0x108]
0000762f89bd0376  sahf
0000762f89bd0377  jnz 0x0000762F89BD03A9
0000762f89bd0379  cmp dword ptr [r15+0x318], 0x00
0000762f89bd0381  jz 0x0000762F89BDB900
0000762f89bd0387  nop [rax+rax*1], ax
0000762f89bd0390  nop [rax+rax*1], eax
0000762f89bd0398  mov eax, 0x410444
0000762f89bd039d  mov [r15+0x100], rax
0000762f89bd03a4  jmp 0x0000762F899FE110
0000762f89bd03a9  cmp dword ptr [r15+0x318], 0x00
0000762f89bd03b1  jz 0x0000762F89BD57E0
0000762f89bd03b7  nop [rax+rax*1], ax
0000762f89bd03c0  nop [rax+rax*1], eax
0000762f89bd03c8  mov eax, 0x410278
0000762f89bd03cd  mov [r15+0x100], rax
0000762f89bd03d4  jmp 0x0000762F899FE110
0000762f89bd03d9  int3
0000762f89bd03da  call 0x0000762F89AB52F0
0000762f89bd03df  jmp 0x0000762F89BCF016
0000762f89bd03e4  call 0x0000762F89AC4620
0000762f89bd03e9  jmp 0x0000762F89BCF023
0000762f89bd03ee  call 0x0000762F89AC33A0
0000762f89bd03f3  jmp 0x0000762F89BCF035
0000762f89bd03f8  call 0x0000762F89AC2120
0000762f89bd03fd  jmp 0x0000762F89BCF03F
0000762f89bd0402  call 0x0000762F89AC0860
0000762f89bd0407  jmp 0x0000762F89BCF067
0000762f89bd040c  call 0x0000762F89ABF5F0
0000762f89bd0411  jmp 0x0000762F89BCF073
0000762f89bd0416  call 0x0000762F89AC0860
0000762f89bd041b  jmp 0x0000762F89BCF0A5
0000762f89bd0420  call 0x0000762F89ABF5F0
0000762f89bd0425  jmp 0x0000762F89BCF0B1
0000762f89bd042a  call 0x0000762F89AC4740
0000762f89bd042f  jmp 0x0000762F89BCF0BE
0000762f89bd0434  call 0x0000762F89AB5400
0000762f89bd0439  jmp 0x0000762F89BCF0CB
0000762f89bd043e  call 0x0000762F89AB52F0
0000762f89bd0443  jmp 0x0000762F89BCF0D8
0000762f89bd0448  call 0x0000762F89AC4620
0000762f89bd044d  jmp 0x0000762F89BCF0E5
0000762f89bd0452  call 0x0000762F89AC0860
0000762f89bd0457  jmp 0x0000762F89BCF10D
0000762f89bd045c  call 0x0000762F89ABF5F0
0000762f89bd0461  jmp 0x0000762F89BCF119
0000762f89bd0466  call 0x0000762F89A09D70
0000762f89bd046b  jmp 0x0000762F89BCF11F
0000762f89bd0470  call 0x0000762F89ABE9C0
0000762f89bd0475  jmp 0x0000762F89BCF129
0000762f89bd047a  call 0x0000762F89AC0860
0000762f89bd047f  jmp 0x0000762F89BCF151
0000762f89bd0484  call 0x0000762F89ABF5F0
0000762f89bd0489  jmp 0x0000762F89BCF15D
0000762f89bd048e  call 0x0000762F89ABD750
0000762f89bd0493  jmp 0x0000762F89BCF16A
0000762f89bd0498  call 0x0000762F89ABC4E0
0000762f89bd049d  jmp 0x0000762F89BCF177
0000762f89bd04a2  call 0x0000762F89AC4740
0000762f89bd04a7  jmp 0x0000762F89BCF184
0000762f89bd04ac  call 0x0000762F89AB5400
0000762f89bd04b1  jmp 0x0000762F89BCF191
0000762f89bd04b6  call 0x0000762F89AB52F0
0000762f89bd04bb  jmp 0x0000762F89BCF19E
0000762f89bd04c0  call 0x0000762F89AC4620
0000762f89bd04c5  jmp 0x0000762F89BCF1AB
0000762f89bd04ca  call 0x0000762F89AC0860
0000762f89bd04cf  jmp 0x0000762F89BCF1BE
0000762f89bd04d4  call 0x0000762F89ABB270
0000762f89bd04d9  jmp 0x0000762F89BCF1CB
0000762f89bd04de  call 0x0000762F89ABA000
0000762f89bd04e3  jmp 0x0000762F89BCF1D8
0000762f89bd04e8  call 0x0000762F89AB8D90
0000762f89bd04ed  jmp 0x0000762F89BCF1E5
0000762f89bd04f2  call 0x0000762F89AB8A20
0000762f89bd04f7  jmp 0x0000762F89BCF1F2
0000762f89bd04fc  call 0x0000762F89AB5400
0000762f89bd0501  jmp 0x0000762F89BCF1FC
0000762f89bd0506  call 0x0000762F89AC2240
0000762f89bd050b  jmp 0x0000762F89BCF206
0000762f89bd0510  call 0x0000762F89AB52F0
0000762f89bd0515  jmp 0x0000762F89BCF210
0000762f89bd051a  call 0x0000762F89AC2120
0000762f89bd051f  jmp 0x0000762F89BCF21A
0000762f89bd0524  call 0x0000762F89AB77B0
0000762f89bd0529  jmp 0x0000762F89BCF224
0000762f89bd052e  call 0x0000762F89AB6550
0000762f89bd0533  jmp 0x0000762F89BCF22E
0000762f89bd0538  call 0x0000762F89ABFD50
0000762f89bd053d  jmp 0x0000762F89BCF240
0000762f89bd0542  call 0x0000762F89AB8EA0
0000762f89bd0547  jmp 0x0000762F89BCF24A
0000762f89bd054c  call 0x0000762F89ABFC30
0000762f89bd0551  jmp 0x0000762F89BCF257
0000762f89bd0556  call 0x0000762F89AB8D90
0000762f89bd055b  jmp 0x0000762F89BCF264
0000762f89bd0560  call 0x0000762F89AC2240
0000762f89bd0565  jmp 0x0000762F89BCF271
0000762f89bd056a  call 0x0000762F89AB5400
0000762f89bd056f  jmp 0x0000762F89BCF27E
0000762f89bd0574  call 0x0000762F89AB52F0
0000762f89bd0579  jmp 0x0000762F89BCF28B
0000762f89bd057e  call 0x0000762F89AC2120
0000762f89bd0583  jmp 0x0000762F89BCF298
0000762f89bd0588  call 0x0000762F89AB52F0
0000762f89bd058d  jmp 0x0000762F89BCF2AB
0000762f89bd0592  call 0x0000762F89AB52F0
0000762f89bd0597  jmp 0x0000762F89BCF2BE
0000762f89bd059c  call 0x0000762F89AB52F0
0000762f89bd05a1  jmp 0x0000762F89BCF2D1
0000762f89bd05a6  call 0x0000762F89AB52F0
0000762f89bd05ab  jmp 0x0000762F89BCF2E4
0000762f89bd05b0  call 0x0000762F89AC2240
0000762f89bd05b5  jmp 0x0000762F89BCF2F9
0000762f89bd05ba  call 0x0000762F89AC2240
0000762f89bd05bf  jmp 0x0000762F89BCF30C
0000762f89bd05c4  call 0x0000762F89AC2120
0000762f89bd05c9  jmp 0x0000762F89BCF319
0000762f89bd05ce  call 0x0000762F89AB52F0
0000762f89bd05d3  jmp 0x0000762F89BCF32C
0000762f89bd05d8  call 0x0000762F89AB52F0
0000762f89bd05dd  jmp 0x0000762F89BCF34F
0000762f89bd05e2  call 0x0000762F89AB52F0
0000762f89bd05e7  jmp 0x0000762F89BCF362
0000762f89bd05ec  call 0x0000762F899FF540
0000762f89bd05f1  jmp 0x0000762F89BCF380
0000762f89bd05f6  call 0x0000762F89A08C20
0000762f89bd05fb  jmp 0x0000762F89BCF38A
0000762f89bd0600  call 0x0000762F89AD6600
0000762f89bd0605  jmp 0x0000762F89BCF396
0000762f89bd060a  call 0x0000762F899FF540
0000762f89bd060f  jmp 0x0000762F89BCF3A6
0000762f89bd0614  call 0x0000762F89AC0370
0000762f89bd0619  jmp 0x0000762F89BCF3D4
0000762f89bd061e  call 0x0000762F89ABF100
0000762f89bd0623  jmp 0x0000762F89BCF3DD
0000762f89bd0628  call 0x0000762F89AC0370
0000762f89bd062d  jmp 0x0000762F89BCF43B
0000762f89bd0632  call 0x0000762F89ABF100
0000762f89bd0637  jmp 0x0000762F89BCF444
0000762f89bd063c  call 0x0000762F89AC0370
0000762f89bd0641  jmp 0x0000762F89BCF48B
0000762f89bd0646  call 0x0000762F89ABF100
0000762f89bd064b  jmp 0x0000762F89BCF494
0000762f89bd0650  call 0x0000762F89A0B720
0000762f89bd0655  jmp 0x0000762F89BCF4D7
0000762f89bd065a  call 0x0000762F89AB47C0
0000762f89bd065f  jmp 0x0000762F89BCF4EA
0000762f89bd0664  call 0x0000762F89A08B00
0000762f89bd0669  jmp 0x0000762F89BCF501
0000762f89bd066e  call 0x0000762F899FF430
0000762f89bd0673  jmp 0x0000762F89BCF514
0000762f89bd0678  call 0x0000762F899FF430
0000762f89bd067d  jmp 0x0000762F89BCF527
0000762f89bd0682  sub rsp, 0x08
0000762f89bd0686  push rax
0000762f89bd0687  push rcx
0000762f89bd0688  push rdx
0000762f89bd0689  push rdi
0000762f89bd068a  push rsi
0000762f89bd068b  push r8
0000762f89bd068d  push r9
0000762f89bd068f  push r10
0000762f89bd0691  push r11
0000762f89bd0693  sub rsp, 0xF0
0000762f89bd069a  vmovaps [rsp], xmm0
0000762f89bd069f  vmovaps [rsp+0x10], xmm2
0000762f89bd06a5  vmovaps [rsp+0x20], xmm3
0000762f89bd06ab  vmovaps [rsp+0x30], xmm4
0000762f89bd06b1  vmovaps [rsp+0x40], xmm5
0000762f89bd06b7  vmovaps [rsp+0x50], xmm6
0000762f89bd06bd  vmovaps [rsp+0x60], xmm7
0000762f89bd06c3  vmovaps [rsp+0x70], xmm8
0000762f89bd06c9  vmovaps [rsp+0x80], xmm9
0000762f89bd06d2  vmovaps [rsp+0x90], xmm10
0000762f89bd06db  vmovaps [rsp+0xA0], xmm11
0000762f89bd06e4  vmovaps [rsp+0xB0], xmm12
0000762f89bd06ed  vmovaps [rsp+0xC0], xmm13
0000762f89bd06f6  vmovaps [rsp+0xD0], xmm14
0000762f89bd06ff  vmovaps [rsp+0xE0], xmm15
0000762f89bd0708  sub rsp, 0x30
0000762f89bd070c  movaps [rsp], xmm1
0000762f89bd0710  movaps [rsp+0x10], xmm15
0000762f89bd0716  movaps [rsp+0x20], xmm14
0000762f89bd071c  lea rdi, [rsp]
0000762f89bd0720  mov esi, 0x00
0000762f89bd0725  mov rax, 0x604D6F946530
0000762f89bd072f  call rax
0000762f89bd0731  movaps xmm1, [rsp]
0000762f89bd0735  add rsp, 0x30
0000762f89bd0739  vmovaps xmm0, [rsp]
0000762f89bd073e  vmovaps xmm2, [rsp+0x10]
0000762f89bd0744  vmovaps xmm3, [rsp+0x20]
0000762f89bd074a  vmovaps xmm4, [rsp+0x30]
0000762f89bd0750  vmovaps xmm5, [rsp+0x40]
0000762f89bd0756  vmovaps xmm6, [rsp+0x50]
0000762f89bd075c  vmovaps xmm7, [rsp+0x60]
0000762f89bd0762  vmovaps xmm8, [rsp+0x70]
0000762f89bd0768  vmovaps xmm9, [rsp+0x80]
0000762f89bd0771  vmovaps xmm10, [rsp+0x90]
0000762f89bd077a  vmovaps xmm11, [rsp+0xA0]
0000762f89bd0783  vmovaps xmm12, [rsp+0xB0]
0000762f89bd078c  vmovaps xmm13, [rsp+0xC0]
0000762f89bd0795  vmovaps xmm14, [rsp+0xD0]
0000762f89bd079e  vmovaps xmm15, [rsp+0xE0]
0000762f89bd07a7  add rsp, 0xF0
0000762f89bd07ae  pop r11
0000762f89bd07b0  pop r10
0000762f89bd07b2  pop r9
0000762f89bd07b4  pop r8
0000762f89bd07b6  pop rsi
0000762f89bd07b7  pop rdi
0000762f89bd07b8  pop rdx
0000762f89bd07b9  pop rcx
0000762f89bd07ba  pop rax
0000762f89bd07bb  add rsp, 0x08
0000762f89bd07bf  jmp 0x0000762F89BCF581
0000762f89bd07c4  sub rsp, 0x08
0000762f89bd07c8  push rax
0000762f89bd07c9  push rcx
0000762f89bd07ca  push rdx
0000762f89bd07cb  push rdi
0000762f89bd07cc  push rsi
0000762f89bd07cd  push r8
0000762f89bd07cf  push r9
0000762f89bd07d1  push r10
0000762f89bd07d3  push r11
0000762f89bd07d5  sub rsp, 0xF0
0000762f89bd07dc  vmovaps [rsp], xmm0
0000762f89bd07e1  vmovaps [rsp+0x10], xmm1
0000762f89bd07e7  vmovaps [rsp+0x20], xmm2
0000762f89bd07ed  vmovaps [rsp+0x30], xmm3
0000762f89bd07f3  vmovaps [rsp+0x40], xmm4
0000762f89bd07f9  vmovaps [rsp+0x50], xmm5
0000762f89bd07ff  vmovaps [rsp+0x60], xmm6
0000762f89bd0805  vmovaps [rsp+0x70], xmm7
0000762f89bd080b  vmovaps [rsp+0x80], xmm8
0000762f89bd0814  vmovaps [rsp+0x90], xmm9
0000762f89bd081d  vmovaps [rsp+0xA0], xmm10
0000762f89bd0826  vmovaps [rsp+0xB0], xmm11
0000762f89bd082f  vmovaps [rsp+0xC0], xmm12
0000762f89bd0838  vmovaps [rsp+0xD0], xmm14
0000762f89bd0841  vmovaps [rsp+0xE0], xmm15
0000762f89bd084a  sub rsp, 0x30
0000762f89bd084e  movaps [rsp], xmm13
0000762f89bd0853  movaps [rsp+0x10], xmm1
0000762f89bd0858  movaps [rsp+0x20], xmm14
0000762f89bd085e  lea rdi, [rsp]
0000762f89bd0862  mov esi, 0x00
0000762f89bd0867  mov rax, 0x604D6F946530
0000762f89bd0871  call rax
0000762f89bd0873  movaps xmm13, [rsp]
0000762f89bd0878  add rsp, 0x30
0000762f89bd087c  vmovaps xmm0, [rsp]
0000762f89bd0881  vmovaps xmm1, [rsp+0x10]
0000762f89bd0887  vmovaps xmm2, [rsp+0x20]
0000762f89bd088d  vmovaps xmm3, [rsp+0x30]
0000762f89bd0893  vmovaps xmm4, [rsp+0x40]
0000762f89bd0899  vmovaps xmm5, [rsp+0x50]
0000762f89bd089f  vmovaps xmm6, [rsp+0x60]
0000762f89bd08a5  vmovaps xmm7, [rsp+0x70]
0000762f89bd08ab  vmovaps xmm8, [rsp+0x80]
0000762f89bd08b4  vmovaps xmm9, [rsp+0x90]
0000762f89bd08bd  vmovaps xmm10, [rsp+0xA0]
0000762f89bd08c6  vmovaps xmm11, [rsp+0xB0]
0000762f89bd08cf  vmovaps xmm12, [rsp+0xC0]
0000762f89bd08d8  vmovaps xmm14, [rsp+0xD0]
0000762f89bd08e1  vmovaps xmm15, [rsp+0xE0]
0000762f89bd08ea  add rsp, 0xF0
0000762f89bd08f1  pop r11
0000762f89bd08f3  pop r10
0000762f89bd08f5  pop r9
0000762f89bd08f7  pop r8
0000762f89bd08f9  pop rsi
0000762f89bd08fa  pop rdi
0000762f89bd08fb  pop rdx
0000762f89bd08fc  pop rcx
0000762f89bd08fd  pop rax
0000762f89bd08fe  add rsp, 0x08
0000762f89bd0902  jmp 0x0000762F89BCF5CF
0000762f89bd0907  sub rsp, 0x08
0000762f89bd090b  push rax
0000762f89bd090c  push rcx
0000762f89bd090d  push rdx
0000762f89bd090e  push rdi
0000762f89bd090f  push rsi
0000762f89bd0910  push r8
0000762f89bd0912  push r9
0000762f89bd0914  push r10
0000762f89bd0916  push r11
0000762f89bd0918  sub rsp, 0xF0
0000762f89bd091f  vmovaps [rsp], xmm0
0000762f89bd0924  vmovaps [rsp+0x10], xmm1
0000762f89bd092a  vmovaps [rsp+0x20], xmm2
0000762f89bd0930  vmovaps [rsp+0x30], xmm3
0000762f89bd0936  vmovaps [rsp+0x40], xmm4
0000762f89bd093c  vmovaps [rsp+0x50], xmm5
0000762f89bd0942  vmovaps [rsp+0x60], xmm6
0000762f89bd0948  vmovaps [rsp+0x70], xmm7
0000762f89bd094e  vmovaps [rsp+0x80], xmm8
0000762f89bd0957  vmovaps [rsp+0x90], xmm9
0000762f89bd0960  vmovaps [rsp+0xA0], xmm10
0000762f89bd0969  vmovaps [rsp+0xB0], xmm11
0000762f89bd0972  vmovaps [rsp+0xC0], xmm12
0000762f89bd097b  vmovaps [rsp+0xD0], xmm13
0000762f89bd0984  vmovaps [rsp+0xE0], xmm14
0000762f89bd098d  sub rsp, 0x30
0000762f89bd0991  movaps [rsp], xmm15
0000762f89bd0996  movaps [rsp+0x10], xmm14
0000762f89bd099c  movaps [rsp+0x20], xmm1
0000762f89bd09a1  lea rdi, [rsp]
0000762f89bd09a5  mov esi, 0x00
0000762f89bd09aa  mov rax, 0x604D6F946530
0000762f89bd09b4  call rax
0000762f89bd09b6  movaps xmm15, [rsp]
0000762f89bd09bb  add rsp, 0x30
0000762f89bd09bf  vmovaps xmm0, [rsp]
0000762f89bd09c4  vmovaps xmm1, [rsp+0x10]
0000762f89bd09ca  vmovaps xmm2, [rsp+0x20]
0000762f89bd09d0  vmovaps xmm3, [rsp+0x30]
0000762f89bd09d6  vmovaps xmm4, [rsp+0x40]
0000762f89bd09dc  vmovaps xmm5, [rsp+0x50]
0000762f89bd09e2  vmovaps xmm6, [rsp+0x60]
0000762f89bd09e8  vmovaps xmm7, [rsp+0x70]
0000762f89bd09ee  vmovaps xmm8, [rsp+0x80]
0000762f89bd09f7  vmovaps xmm9, [rsp+0x90]
0000762f89bd0a00  vmovaps xmm10, [rsp+0xA0]
0000762f89bd0a09  vmovaps xmm11, [rsp+0xB0]
0000762f89bd0a12  vmovaps xmm12, [rsp+0xC0]
0000762f89bd0a1b  vmovaps xmm13, [rsp+0xD0]
0000762f89bd0a24  vmovaps xmm14, [rsp+0xE0]
0000762f89bd0a2d  add rsp, 0xF0
0000762f89bd0a34  pop r11
0000762f89bd0a36  pop r10
0000762f89bd0a38  pop r9
0000762f89bd0a3a  pop r8
0000762f89bd0a3c  pop rsi
0000762f89bd0a3d  pop rdi
0000762f89bd0a3e  pop rdx
0000762f89bd0a3f  pop rcx
0000762f89bd0a40  pop rax
0000762f89bd0a41  add rsp, 0x08
0000762f89bd0a45  jmp 0x0000762F89BCF617
0000762f89bd0a4a  sub rsp, 0x08
0000762f89bd0a4e  push rax
0000762f89bd0a4f  push rcx
0000762f89bd0a50  push rdx
0000762f89bd0a51  push rdi
0000762f89bd0a52  push rsi
0000762f89bd0a53  push r8
0000762f89bd0a55  push r9
0000762f89bd0a57  push r10
0000762f89bd0a59  push r11
0000762f89bd0a5b  sub rsp, 0xF0
0000762f89bd0a62  vmovaps [rsp], xmm0
0000762f89bd0a67  vmovaps [rsp+0x10], xmm2
0000762f89bd0a6d  vmovaps [rsp+0x20], xmm3
0000762f89bd0a73  vmovaps [rsp+0x30], xmm4
0000762f89bd0a79  vmovaps [rsp+0x40], xmm5
0000762f89bd0a7f  vmovaps [rsp+0x50], xmm6
0000762f89bd0a85  vmovaps [rsp+0x60], xmm7
0000762f89bd0a8b  vmovaps [rsp+0x70], xmm8
0000762f89bd0a91  vmovaps [rsp+0x80], xmm9
0000762f89bd0a9a  vmovaps [rsp+0x90], xmm10
0000762f89bd0aa3  vmovaps [rsp+0xA0], xmm11
0000762f89bd0aac  vmovaps [rsp+0xB0], xmm12
0000762f89bd0ab5  vmovaps [rsp+0xC0], xmm13
0000762f89bd0abe  vmovaps [rsp+0xD0], xmm14
0000762f89bd0ac7  vmovaps [rsp+0xE0], xmm15
0000762f89bd0ad0  sub rsp, 0x30
0000762f89bd0ad4  movaps [rsp], xmm1
0000762f89bd0ad8  movaps [rsp+0x10], xmm14
0000762f89bd0ade  movaps [rsp+0x20], xmm10
0000762f89bd0ae4  lea rdi, [rsp]
0000762f89bd0ae8  mov esi, 0x00
0000762f89bd0aed  mov rax, 0x604D6F946530
0000762f89bd0af7  call rax
0000762f89bd0af9  movaps xmm1, [rsp]
0000762f89bd0afd  add rsp, 0x30
0000762f89bd0b01  vmovaps xmm0, [rsp]
0000762f89bd0b06  vmovaps xmm2, [rsp+0x10]
0000762f89bd0b0c  vmovaps xmm3, [rsp+0x20]
0000762f89bd0b12  vmovaps xmm4, [rsp+0x30]
0000762f89bd0b18  vmovaps xmm5, [rsp+0x40]
0000762f89bd0b1e  vmovaps xmm6, [rsp+0x50]
0000762f89bd0b24  vmovaps xmm7, [rsp+0x60]
0000762f89bd0b2a  vmovaps xmm8, [rsp+0x70]
0000762f89bd0b30  vmovaps xmm9, [rsp+0x80]
0000762f89bd0b39  vmovaps xmm10, [rsp+0x90]
0000762f89bd0b42  vmovaps xmm11, [rsp+0xA0]
0000762f89bd0b4b  vmovaps xmm12, [rsp+0xB0]
0000762f89bd0b54  vmovaps xmm13, [rsp+0xC0]
0000762f89bd0b5d  vmovaps xmm14, [rsp+0xD0]
0000762f89bd0b66  vmovaps xmm15, [rsp+0xE0]
0000762f89bd0b6f  add rsp, 0xF0
0000762f89bd0b76  pop r11
0000762f89bd0b78  pop r10
0000762f89bd0b7a  pop r9
0000762f89bd0b7c  pop r8
0000762f89bd0b7e  pop rsi
0000762f89bd0b7f  pop rdi
0000762f89bd0b80  pop rdx
0000762f89bd0b81  pop rcx
0000762f89bd0b82  pop rax
0000762f89bd0b83  add rsp, 0x08
0000762f89bd0b87  jmp 0x0000762F89BCF631
0000762f89bd0b8c  sub rsp, 0x08
0000762f89bd0b90  push rax
0000762f89bd0b91  push rcx
0000762f89bd0b92  push rdx
0000762f89bd0b93  push rdi
0000762f89bd0b94  push rsi
0000762f89bd0b95  push r8
0000762f89bd0b97  push r9
0000762f89bd0b99  push r10
0000762f89bd0b9b  push r11
0000762f89bd0b9d  sub rsp, 0xF0
0000762f89bd0ba4  vmovaps [rsp], xmm0
0000762f89bd0ba9  vmovaps [rsp+0x10], xmm1
0000762f89bd0baf  vmovaps [rsp+0x20], xmm2
0000762f89bd0bb5  vmovaps [rsp+0x30], xmm3
0000762f89bd0bbb  vmovaps [rsp+0x40], xmm4
0000762f89bd0bc1  vmovaps [rsp+0x50], xmm5
0000762f89bd0bc7  vmovaps [rsp+0x60], xmm6
0000762f89bd0bcd  vmovaps [rsp+0x70], xmm7
0000762f89bd0bd3  vmovaps [rsp+0x80], xmm8
0000762f89bd0bdc  vmovaps [rsp+0x90], xmm9
0000762f89bd0be5  vmovaps [rsp+0xA0], xmm10
0000762f89bd0bee  vmovaps [rsp+0xB0], xmm11
0000762f89bd0bf7  vmovaps [rsp+0xC0], xmm12
0000762f89bd0c00  vmovaps [rsp+0xD0], xmm14
0000762f89bd0c09  vmovaps [rsp+0xE0], xmm15
0000762f89bd0c12  sub rsp, 0x30
0000762f89bd0c16  movaps [rsp], xmm13
0000762f89bd0c1b  movaps [rsp+0x10], xmm14
0000762f89bd0c21  movaps [rsp+0x20], xmm2
0000762f89bd0c26  lea rdi, [rsp]
0000762f89bd0c2a  mov esi, 0x00
0000762f89bd0c2f  mov rax, 0x604D6F946530
0000762f89bd0c39  call rax
0000762f89bd0c3b  movaps xmm13, [rsp]
0000762f89bd0c40  add rsp, 0x30
0000762f89bd0c44  vmovaps xmm0, [rsp]
0000762f89bd0c49  vmovaps xmm1, [rsp+0x10]
0000762f89bd0c4f  vmovaps xmm2, [rsp+0x20]
0000762f89bd0c55  vmovaps xmm3, [rsp+0x30]
0000762f89bd0c5b  vmovaps xmm4, [rsp+0x40]
0000762f89bd0c61  vmovaps xmm5, [rsp+0x50]
0000762f89bd0c67  vmovaps xmm6, [rsp+0x60]
0000762f89bd0c6d  vmovaps xmm7, [rsp+0x70]
0000762f89bd0c73  vmovaps xmm8, [rsp+0x80]
0000762f89bd0c7c  vmovaps xmm9, [rsp+0x90]
0000762f89bd0c85  vmovaps xmm10, [rsp+0xA0]
0000762f89bd0c8e  vmovaps xmm11, [rsp+0xB0]
0000762f89bd0c97  vmovaps xmm12, [rsp+0xC0]
0000762f89bd0ca0  vmovaps xmm14, [rsp+0xD0]
0000762f89bd0ca9  vmovaps xmm15, [rsp+0xE0]
0000762f89bd0cb2  add rsp, 0xF0
0000762f89bd0cb9  pop r11
0000762f89bd0cbb  pop r10
0000762f89bd0cbd  pop r9
0000762f89bd0cbf  pop r8
0000762f89bd0cc1  pop rsi
0000762f89bd0cc2  pop rdi
0000762f89bd0cc3  pop rdx
0000762f89bd0cc4  pop rcx
0000762f89bd0cc5  pop rax
0000762f89bd0cc6  add rsp, 0x08
0000762f89bd0cca  jmp 0x0000762F89BCF64C
0000762f89bd0ccf  sub rsp, 0x08
0000762f89bd0cd3  push rax
0000762f89bd0cd4  push rcx
0000762f89bd0cd5  push rdx
0000762f89bd0cd6  push rdi
0000762f89bd0cd7  push rsi
0000762f89bd0cd8  push r8
0000762f89bd0cda  push r9
0000762f89bd0cdc  push r10
0000762f89bd0cde  push r11
0000762f89bd0ce0  sub rsp, 0xF0
0000762f89bd0ce7  vmovaps [rsp], xmm0
0000762f89bd0cec  vmovaps [rsp+0x10], xmm2
0000762f89bd0cf2  vmovaps [rsp+0x20], xmm3
0000762f89bd0cf8  vmovaps [rsp+0x30], xmm4
0000762f89bd0cfe  vmovaps [rsp+0x40], xmm5
0000762f89bd0d04  vmovaps [rsp+0x50], xmm6
0000762f89bd0d0a  vmovaps [rsp+0x60], xmm7
0000762f89bd0d10  vmovaps [rsp+0x70], xmm8
0000762f89bd0d16  vmovaps [rsp+0x80], xmm9
0000762f89bd0d1f  vmovaps [rsp+0x90], xmm10
0000762f89bd0d28  vmovaps [rsp+0xA0], xmm11
0000762f89bd0d31  vmovaps [rsp+0xB0], xmm12
0000762f89bd0d3a  vmovaps [rsp+0xC0], xmm13
0000762f89bd0d43  vmovaps [rsp+0xD0], xmm14
0000762f89bd0d4c  vmovaps [rsp+0xE0], xmm15
0000762f89bd0d55  sub rsp, 0x30
0000762f89bd0d59  movaps [rsp], xmm1
0000762f89bd0d5d  movaps [rsp+0x10], xmm10
0000762f89bd0d63  movaps [rsp+0x20], xmm2
0000762f89bd0d68  lea rdi, [rsp]
0000762f89bd0d6c  mov esi, 0x00
0000762f89bd0d71  mov rax, 0x604D6F946530
0000762f89bd0d7b  call rax
0000762f89bd0d7d  movaps xmm1, [rsp]
0000762f89bd0d81  add rsp, 0x30
0000762f89bd0d85  vmovaps xmm0, [rsp]
0000762f89bd0d8a  vmovaps xmm2, [rsp+0x10]
0000762f89bd0d90  vmovaps xmm3, [rsp+0x20]
0000762f89bd0d96  vmovaps xmm4, [rsp+0x30]
0000762f89bd0d9c  vmovaps xmm5, [rsp+0x40]
0000762f89bd0da2  vmovaps xmm6, [rsp+0x50]
0000762f89bd0da8  vmovaps xmm7, [rsp+0x60]
0000762f89bd0dae  vmovaps xmm8, [rsp+0x70]
0000762f89bd0db4  vmovaps xmm9, [rsp+0x80]
0000762f89bd0dbd  vmovaps xmm10, [rsp+0x90]
0000762f89bd0dc6  vmovaps xmm11, [rsp+0xA0]
0000762f89bd0dcf  vmovaps xmm12, [rsp+0xB0]
0000762f89bd0dd8  vmovaps xmm13, [rsp+0xC0]
0000762f89bd0de1  vmovaps xmm14, [rsp+0xD0]
0000762f89bd0dea  vmovaps xmm15, [rsp+0xE0]
0000762f89bd0df3  add rsp, 0xF0
0000762f89bd0dfa  pop r11
0000762f89bd0dfc  pop r10
0000762f89bd0dfe  pop r9
0000762f89bd0e00  pop r8
0000762f89bd0e02  pop rsi
0000762f89bd0e03  pop rdi
0000762f89bd0e04  pop rdx
0000762f89bd0e05  pop rcx
0000762f89bd0e06  pop rax
0000762f89bd0e07  add rsp, 0x08
0000762f89bd0e0b  jmp 0x0000762F89BCF6B4
0000762f89bd0e10  sub rsp, 0x08
0000762f89bd0e14  push rax
0000762f89bd0e15  push rcx
0000762f89bd0e16  push rdx
0000762f89bd0e17  push rdi
0000762f89bd0e18  push rsi
0000762f89bd0e19  push r8
0000762f89bd0e1b  push r9
0000762f89bd0e1d  push r10
0000762f89bd0e1f  push r11
0000762f89bd0e21  sub rsp, 0xF0
0000762f89bd0e28  vmovaps [rsp], xmm0
0000762f89bd0e2d  vmovaps [rsp+0x10], xmm1
0000762f89bd0e33  vmovaps [rsp+0x20], xmm2
0000762f89bd0e39  vmovaps [rsp+0x30], xmm3
0000762f89bd0e3f  vmovaps [rsp+0x40], xmm4
0000762f89bd0e45  vmovaps [rsp+0x50], xmm5
0000762f89bd0e4b  vmovaps [rsp+0x60], xmm6
0000762f89bd0e51  vmovaps [rsp+0x70], xmm7
0000762f89bd0e57  vmovaps [rsp+0x80], xmm8
0000762f89bd0e60  vmovaps [rsp+0x90], xmm9
0000762f89bd0e69  vmovaps [rsp+0xA0], xmm10
0000762f89bd0e72  vmovaps [rsp+0xB0], xmm11
0000762f89bd0e7b  vmovaps [rsp+0xC0], xmm12
0000762f89bd0e84  vmovaps [rsp+0xD0], xmm13
0000762f89bd0e8d  vmovaps [rsp+0xE0], xmm14
0000762f89bd0e96  sub rsp, 0x30
0000762f89bd0e9a  movaps [rsp], xmm15
0000762f89bd0e9f  movaps [rsp+0x10], xmm10
0000762f89bd0ea5  movaps [rsp+0x20], xmm2
0000762f89bd0eaa  lea rdi, [rsp]
0000762f89bd0eae  mov esi, 0x00
0000762f89bd0eb3  mov rax, 0x604D6F946530
0000762f89bd0ebd  call rax
0000762f89bd0ebf  movaps xmm15, [rsp]
0000762f89bd0ec4  add rsp, 0x30
0000762f89bd0ec8  vmovaps xmm0, [rsp]
0000762f89bd0ecd  vmovaps xmm1, [rsp+0x10]
0000762f89bd0ed3  vmovaps xmm2, [rsp+0x20]
0000762f89bd0ed9  vmovaps xmm3, [rsp+0x30]
0000762f89bd0edf  vmovaps xmm4, [rsp+0x40]
0000762f89bd0ee5  vmovaps xmm5, [rsp+0x50]
0000762f89bd0eeb  vmovaps xmm6, [rsp+0x60]
0000762f89bd0ef1  vmovaps xmm7, [rsp+0x70]
0000762f89bd0ef7  vmovaps xmm8, [rsp+0x80]
0000762f89bd0f00  vmovaps xmm9, [rsp+0x90]
0000762f89bd0f09  vmovaps xmm10, [rsp+0xA0]
0000762f89bd0f12  vmovaps xmm11, [rsp+0xB0]
0000762f89bd0f1b  vmovaps xmm12, [rsp+0xC0]
0000762f89bd0f24  vmovaps xmm13, [rsp+0xD0]
0000762f89bd0f2d  vmovaps xmm14, [rsp+0xE0]
0000762f89bd0f36  add rsp, 0xF0
0000762f89bd0f3d  pop r11
0000762f89bd0f3f  pop r10
0000762f89bd0f41  pop r9
0000762f89bd0f43  pop r8
0000762f89bd0f45  pop rsi
0000762f89bd0f46  pop rdi
0000762f89bd0f47  pop rdx
0000762f89bd0f48  pop rcx
0000762f89bd0f49  pop rax
0000762f89bd0f4a  add rsp, 0x08
0000762f89bd0f4e  jmp 0x0000762F89BCF706
0000762f89bd0f53  sub rsp, 0x08
0000762f89bd0f57  push rax
0000762f89bd0f58  push rcx
0000762f89bd0f59  push rdx
0000762f89bd0f5a  push rdi
0000762f89bd0f5b  push rsi
0000762f89bd0f5c  push r8
0000762f89bd0f5e  push r9
0000762f89bd0f60  push r10
0000762f89bd0f62  push r11
0000762f89bd0f64  sub rsp, 0xF0
0000762f89bd0f6b  vmovaps [rsp], xmm0
0000762f89bd0f70  vmovaps [rsp+0x10], xmm2
0000762f89bd0f76  vmovaps [rsp+0x20], xmm3
0000762f89bd0f7c  vmovaps [rsp+0x30], xmm4
0000762f89bd0f82  vmovaps [rsp+0x40], xmm5
0000762f89bd0f88  vmovaps [rsp+0x50], xmm6
0000762f89bd0f8e  vmovaps [rsp+0x60], xmm7
0000762f89bd0f94  vmovaps [rsp+0x70], xmm8
0000762f89bd0f9a  vmovaps [rsp+0x80], xmm9
0000762f89bd0fa3  vmovaps [rsp+0x90], xmm10
0000762f89bd0fac  vmovaps [rsp+0xA0], xmm11
0000762f89bd0fb5  vmovaps [rsp+0xB0], xmm12
0000762f89bd0fbe  vmovaps [rsp+0xC0], xmm13
0000762f89bd0fc7  vmovaps [rsp+0xD0], xmm14
0000762f89bd0fd0  vmovaps [rsp+0xE0], xmm15
0000762f89bd0fd9  sub rsp, 0x30
0000762f89bd0fdd  movaps [rsp], xmm1
0000762f89bd0fe1  movaps [rsp+0x10], xmm10
0000762f89bd0fe7  movaps [rsp+0x20], xmm12
0000762f89bd0fed  lea rdi, [rsp]
0000762f89bd0ff1  mov esi, 0x00
0000762f89bd0ff6  mov rax, 0x604D6F946530
0000762f89bd1000  call rax
0000762f89bd1002  movaps xmm1, [rsp]
0000762f89bd1006  add rsp, 0x30
0000762f89bd100a  vmovaps xmm0, [rsp]
0000762f89bd100f  vmovaps xmm2, [rsp+0x10]
0000762f89bd1015  vmovaps xmm3, [rsp+0x20]
0000762f89bd101b  vmovaps xmm4, [rsp+0x30]
0000762f89bd1021  vmovaps xmm5, [rsp+0x40]
0000762f89bd1027  vmovaps xmm6, [rsp+0x50]
0000762f89bd102d  vmovaps xmm7, [rsp+0x60]
0000762f89bd1033  vmovaps xmm8, [rsp+0x70]
0000762f89bd1039  vmovaps xmm9, [rsp+0x80]
0000762f89bd1042  vmovaps xmm10, [rsp+0x90]
0000762f89bd104b  vmovaps xmm11, [rsp+0xA0]
0000762f89bd1054  vmovaps xmm12, [rsp+0xB0]
0000762f89bd105d  vmovaps xmm13, [rsp+0xC0]
0000762f89bd1066  vmovaps xmm14, [rsp+0xD0]
0000762f89bd106f  vmovaps xmm15, [rsp+0xE0]
0000762f89bd1078  add rsp, 0xF0
0000762f89bd107f  pop r11
0000762f89bd1081  pop r10
0000762f89bd1083  pop r9
0000762f89bd1085  pop r8
0000762f89bd1087  pop rsi
0000762f89bd1088  pop rdi
0000762f89bd1089  pop rdx
0000762f89bd108a  pop rcx
0000762f89bd108b  pop rax
0000762f89bd108c  add rsp, 0x08
0000762f89bd1090  jmp 0x0000762F89BCF732
0000762f89bd1095  sub rsp, 0x08
0000762f89bd1099  push rax
0000762f89bd109a  push rcx
0000762f89bd109b  push rdx
0000762f89bd109c  push rdi
0000762f89bd109d  push rsi
0000762f89bd109e  push r8
0000762f89bd10a0  push r9
0000762f89bd10a2  push r10
0000762f89bd10a4  push r11
0000762f89bd10a6  sub rsp, 0xF0
0000762f89bd10ad  vmovaps [rsp], xmm0
0000762f89bd10b2  vmovaps [rsp+0x10], xmm1
0000762f89bd10b8  vmovaps [rsp+0x20], xmm2
0000762f89bd10be  vmovaps [rsp+0x30], xmm3
0000762f89bd10c4  vmovaps [rsp+0x40], xmm4
0000762f89bd10ca  vmovaps [rsp+0x50], xmm5
0000762f89bd10d0  vmovaps [rsp+0x60], xmm6
0000762f89bd10d6  vmovaps [rsp+0x70], xmm7
0000762f89bd10dc  vmovaps [rsp+0x80], xmm8
0000762f89bd10e5  vmovaps [rsp+0x90], xmm9
0000762f89bd10ee  vmovaps [rsp+0xA0], xmm10
0000762f89bd10f7  vmovaps [rsp+0xB0], xmm11
0000762f89bd1100  vmovaps [rsp+0xC0], xmm12
0000762f89bd1109  vmovaps [rsp+0xD0], xmm13
0000762f89bd1112  vmovaps [rsp+0xE0], xmm14
0000762f89bd111b  sub rsp, 0x30
0000762f89bd111f  movaps [rsp], xmm15
0000762f89bd1124  movaps [rsp+0x10], xmm10
0000762f89bd112a  movaps [rsp+0x20], xmm12
0000762f89bd1130  lea rdi, [rsp]
0000762f89bd1134  mov esi, 0x00
0000762f89bd1139  mov rax, 0x604D6F946530
0000762f89bd1143  call rax
0000762f89bd1145  movaps xmm15, [rsp]
0000762f89bd114a  add rsp, 0x30
0000762f89bd114e  vmovaps xmm0, [rsp]
0000762f89bd1153  vmovaps xmm1, [rsp+0x10]
0000762f89bd1159  vmovaps xmm2, [rsp+0x20]
0000762f89bd115f  vmovaps xmm3, [rsp+0x30]
0000762f89bd1165  vmovaps xmm4, [rsp+0x40]
0000762f89bd116b  vmovaps xmm5, [rsp+0x50]
0000762f89bd1171  vmovaps xmm6, [rsp+0x60]
0000762f89bd1177  vmovaps xmm7, [rsp+0x70]
0000762f89bd117d  vmovaps xmm8, [rsp+0x80]
0000762f89bd1186  vmovaps xmm9, [rsp+0x90]
0000762f89bd118f  vmovaps xmm10, [rsp+0xA0]
0000762f89bd1198  vmovaps xmm11, [rsp+0xB0]
0000762f89bd11a1  vmovaps xmm12, [rsp+0xC0]
0000762f89bd11aa  vmovaps xmm13, [rsp+0xD0]
0000762f89bd11b3  vmovaps xmm14, [rsp+0xE0]
0000762f89bd11bc  add rsp, 0xF0
0000762f89bd11c3  pop r11
0000762f89bd11c5  pop r10
0000762f89bd11c7  pop r9
0000762f89bd11c9  pop r8
0000762f89bd11cb  pop rsi
0000762f89bd11cc  pop rdi
0000762f89bd11cd  pop rdx
0000762f89bd11ce  pop rcx
0000762f89bd11cf  pop rax
0000762f89bd11d0  add rsp, 0x08
0000762f89bd11d4  jmp 0x0000762F89BCF75E
0000762f89bd11d9  call 0x0000762F899FF430
0000762f89bd11de  jmp 0x0000762F89BCF7EE
0000762f89bd11e3  call 0x0000762F899FF430
0000762f89bd11e8  jmp 0x0000762F89BCF801
0000762f89bd11ed  sub rsp, 0x08
0000762f89bd11f1  push rax
0000762f89bd11f2  push rcx
0000762f89bd11f3  push rdx
0000762f89bd11f4  push rdi
0000762f89bd11f5  push rsi
0000762f89bd11f6  push r8
0000762f89bd11f8  push r9
0000762f89bd11fa  push r10
0000762f89bd11fc  push r11
0000762f89bd11fe  sub rsp, 0xF0
0000762f89bd1205  vmovaps [rsp], xmm0
0000762f89bd120a  vmovaps [rsp+0x10], xmm2
0000762f89bd1210  vmovaps [rsp+0x20], xmm3
0000762f89bd1216  vmovaps [rsp+0x30], xmm4
0000762f89bd121c  vmovaps [rsp+0x40], xmm5
0000762f89bd1222  vmovaps [rsp+0x50], xmm6
0000762f89bd1228  vmovaps [rsp+0x60], xmm7
0000762f89bd122e  vmovaps [rsp+0x70], xmm8
0000762f89bd1234  vmovaps [rsp+0x80], xmm9
0000762f89bd123d  vmovaps [rsp+0x90], xmm10
0000762f89bd1246  vmovaps [rsp+0xA0], xmm11
0000762f89bd124f  vmovaps [rsp+0xB0], xmm12
0000762f89bd1258  vmovaps [rsp+0xC0], xmm13
0000762f89bd1261  vmovaps [rsp+0xD0], xmm14
0000762f89bd126a  vmovaps [rsp+0xE0], xmm15
0000762f89bd1273  sub rsp, 0x30
0000762f89bd1277  movaps [rsp], xmm1
0000762f89bd127b  movaps [rsp+0x10], xmm13
0000762f89bd1281  movaps [rsp+0x20], xmm2
0000762f89bd1286  lea rdi, [rsp]
0000762f89bd128a  mov esi, 0x00
0000762f89bd128f  mov rax, 0x604D6F946530
0000762f89bd1299  call rax
0000762f89bd129b  movaps xmm1, [rsp]
0000762f89bd129f  add rsp, 0x30
0000762f89bd12a3  vmovaps xmm0, [rsp]
0000762f89bd12a8  vmovaps xmm2, [rsp+0x10]
0000762f89bd12ae  vmovaps xmm3, [rsp+0x20]
0000762f89bd12b4  vmovaps xmm4, [rsp+0x30]
0000762f89bd12ba  vmovaps xmm5, [rsp+0x40]
0000762f89bd12c0  vmovaps xmm6, [rsp+0x50]
0000762f89bd12c6  vmovaps xmm7, [rsp+0x60]
0000762f89bd12cc  vmovaps xmm8, [rsp+0x70]
0000762f89bd12d2  vmovaps xmm9, [rsp+0x80]
0000762f89bd12db  vmovaps xmm10, [rsp+0x90]
0000762f89bd12e4  vmovaps xmm11, [rsp+0xA0]
0000762f89bd12ed  vmovaps xmm12, [rsp+0xB0]
0000762f89bd12f6  vmovaps xmm13, [rsp+0xC0]
0000762f89bd12ff  vmovaps xmm14, [rsp+0xD0]
0000762f89bd1308  vmovaps xmm15, [rsp+0xE0]
0000762f89bd1311  add rsp, 0xF0
0000762f89bd1318  pop r11
0000762f89bd131a  pop r10
0000762f89bd131c  pop r9
0000762f89bd131e  pop r8
0000762f89bd1320  pop rsi
0000762f89bd1321  pop rdi
0000762f89bd1322  pop rdx
0000762f89bd1323  pop rcx
0000762f89bd1324  pop rax
0000762f89bd1325  add rsp, 0x08
0000762f89bd1329  jmp 0x0000762F89BCF82C
0000762f89bd132e  call 0x0000762F89A0E760
0000762f89bd1333  jmp 0x0000762F89BCF839
0000762f89bd1338  sub rsp, 0x08
0000762f89bd133c  push rax
0000762f89bd133d  push rcx
0000762f89bd133e  push rdx
0000762f89bd133f  push rdi
0000762f89bd1340  push rsi
0000762f89bd1341  push r8
0000762f89bd1343  push r9
0000762f89bd1345  push r10
0000762f89bd1347  push r11
0000762f89bd1349  sub rsp, 0xF0
0000762f89bd1350  vmovaps [rsp], xmm0
0000762f89bd1355  vmovaps [rsp+0x10], xmm1
0000762f89bd135b  vmovaps [rsp+0x20], xmm2
0000762f89bd1361  vmovaps [rsp+0x30], xmm3
0000762f89bd1367  vmovaps [rsp+0x40], xmm4
0000762f89bd136d  vmovaps [rsp+0x50], xmm5
0000762f89bd1373  vmovaps [rsp+0x60], xmm6
0000762f89bd1379  vmovaps [rsp+0x70], xmm7
0000762f89bd137f  vmovaps [rsp+0x80], xmm8
0000762f89bd1388  vmovaps [rsp+0x90], xmm9
0000762f89bd1391  vmovaps [rsp+0xA0], xmm10
0000762f89bd139a  vmovaps [rsp+0xB0], xmm11
0000762f89bd13a3  vmovaps [rsp+0xC0], xmm12
0000762f89bd13ac  vmovaps [rsp+0xD0], xmm14
0000762f89bd13b5  vmovaps [rsp+0xE0], xmm15
0000762f89bd13be  sub rsp, 0x30
0000762f89bd13c2  movaps [rsp], xmm13
0000762f89bd13c7  movaps [rsp+0x10], xmm2
0000762f89bd13cc  movaps [rsp+0x20], xmm1
0000762f89bd13d1  lea rdi, [rsp]
0000762f89bd13d5  mov esi, 0x00
0000762f89bd13da  mov rax, 0x604D6F946530
0000762f89bd13e4  call rax
0000762f89bd13e6  movaps xmm13, [rsp]
0000762f89bd13eb  add rsp, 0x30
0000762f89bd13ef  vmovaps xmm0, [rsp]
0000762f89bd13f4  vmovaps xmm1, [rsp+0x10]
0000762f89bd13fa  vmovaps xmm2, [rsp+0x20]
0000762f89bd1400  vmovaps xmm3, [rsp+0x30]
0000762f89bd1406  vmovaps xmm4, [rsp+0x40]
0000762f89bd140c  vmovaps xmm5, [rsp+0x50]
0000762f89bd1412  vmovaps xmm6, [rsp+0x60]
0000762f89bd1418  vmovaps xmm7, [rsp+0x70]
0000762f89bd141e  vmovaps xmm8, [rsp+0x80]
0000762f89bd1427  vmovaps xmm9, [rsp+0x90]
0000762f89bd1430  vmovaps xmm10, [rsp+0xA0]
0000762f89bd1439  vmovaps xmm11, [rsp+0xB0]
0000762f89bd1442  vmovaps xmm12, [rsp+0xC0]
0000762f89bd144b  vmovaps xmm14, [rsp+0xD0]
0000762f89bd1454  vmovaps xmm15, [rsp+0xE0]
0000762f89bd145d  add rsp, 0xF0
0000762f89bd1464  pop r11
0000762f89bd1466  pop r10
0000762f89bd1468  pop r9
0000762f89bd146a  pop r8
0000762f89bd146c  pop rsi
0000762f89bd146d  pop rdi
0000762f89bd146e  pop rdx
0000762f89bd146f  pop rcx
0000762f89bd1470  pop rax
0000762f89bd1471  add rsp, 0x08
0000762f89bd1475  jmp 0x0000762F89BCF878
0000762f89bd147a  sub rsp, 0x08
0000762f89bd147e  push rax
0000762f89bd147f  push rcx
0000762f89bd1480  push rdx
0000762f89bd1481  push rdi
0000762f89bd1482  push rsi
0000762f89bd1483  push r8
0000762f89bd1485  push r9
0000762f89bd1487  push r10
0000762f89bd1489  push r11
0000762f89bd148b  sub rsp, 0xF0
0000762f89bd1492  vmovaps [rsp], xmm0
0000762f89bd1497  vmovaps [rsp+0x10], xmm2
0000762f89bd149d  vmovaps [rsp+0x20], xmm3
0000762f89bd14a3  vmovaps [rsp+0x30], xmm4
0000762f89bd14a9  vmovaps [rsp+0x40], xmm5
0000762f89bd14af  vmovaps [rsp+0x50], xmm6
0000762f89bd14b5  vmovaps [rsp+0x60], xmm7
0000762f89bd14bb  vmovaps [rsp+0x70], xmm8
0000762f89bd14c1  vmovaps [rsp+0x80], xmm9
0000762f89bd14ca  vmovaps [rsp+0x90], xmm10
0000762f89bd14d3  vmovaps [rsp+0xA0], xmm11
0000762f89bd14dc  vmovaps [rsp+0xB0], xmm12
0000762f89bd14e5  vmovaps [rsp+0xC0], xmm13
0000762f89bd14ee  vmovaps [rsp+0xD0], xmm14
0000762f89bd14f7  vmovaps [rsp+0xE0], xmm15
0000762f89bd1500  sub rsp, 0x30
0000762f89bd1504  movaps [rsp], xmm1
0000762f89bd1508  movaps [rsp+0x10], xmm15
0000762f89bd150e  movaps [rsp+0x20], xmm2
0000762f89bd1513  lea rdi, [rsp]
0000762f89bd1517  mov esi, 0x00
0000762f89bd151c  mov rax, 0x604D6F946530
0000762f89bd1526  call rax
0000762f89bd1528  movaps xmm1, [rsp]
0000762f89bd152c  add rsp, 0x30
0000762f89bd1530  vmovaps xmm0, [rsp]
0000762f89bd1535  vmovaps xmm2, [rsp+0x10]
0000762f89bd153b  vmovaps xmm3, [rsp+0x20]
0000762f89bd1541  vmovaps xmm4, [rsp+0x30]
0000762f89bd1547  vmovaps xmm5, [rsp+0x40]
0000762f89bd154d  vmovaps xmm6, [rsp+0x50]
0000762f89bd1553  vmovaps xmm7, [rsp+0x60]
0000762f89bd1559  vmovaps xmm8, [rsp+0x70]
0000762f89bd155f  vmovaps xmm9, [rsp+0x80]
0000762f89bd1568  vmovaps xmm10, [rsp+0x90]
0000762f89bd1571  vmovaps xmm11, [rsp+0xA0]
0000762f89bd157a  vmovaps xmm12, [rsp+0xB0]
0000762f89bd1583  vmovaps xmm13, [rsp+0xC0]
0000762f89bd158c  vmovaps xmm14, [rsp+0xD0]
0000762f89bd1595  vmovaps xmm15, [rsp+0xE0]
0000762f89bd159e  add rsp, 0xF0
0000762f89bd15a5  pop r11
0000762f89bd15a7  pop r10
0000762f89bd15a9  pop r9
0000762f89bd15ab  pop r8
0000762f89bd15ad  pop rsi
0000762f89bd15ae  pop rdi
0000762f89bd15af  pop rdx
0000762f89bd15b0  pop rcx
0000762f89bd15b1  pop rax
0000762f89bd15b2  add rsp, 0x08
0000762f89bd15b6  jmp 0x0000762F89BCF8AC
0000762f89bd15bb  sub rsp, 0x08
0000762f89bd15bf  push rax
0000762f89bd15c0  push rcx
0000762f89bd15c1  push rdx
0000762f89bd15c2  push rdi
0000762f89bd15c3  push rsi
0000762f89bd15c4  push r8
0000762f89bd15c6  push r9
0000762f89bd15c8  push r10
0000762f89bd15ca  push r11
0000762f89bd15cc  sub rsp, 0xF0
0000762f89bd15d3  vmovaps [rsp], xmm0
0000762f89bd15d8  vmovaps [rsp+0x10], xmm1
0000762f89bd15de  vmovaps [rsp+0x20], xmm2
0000762f89bd15e4  vmovaps [rsp+0x30], xmm3
0000762f89bd15ea  vmovaps [rsp+0x40], xmm4
0000762f89bd15f0  vmovaps [rsp+0x50], xmm5
0000762f89bd15f6  vmovaps [rsp+0x60], xmm6
0000762f89bd15fc  vmovaps [rsp+0x70], xmm7
0000762f89bd1602  vmovaps [rsp+0x80], xmm8
0000762f89bd160b  vmovaps [rsp+0x90], xmm9
0000762f89bd1614  vmovaps [rsp+0xA0], xmm10
0000762f89bd161d  vmovaps [rsp+0xB0], xmm11
0000762f89bd1626  vmovaps [rsp+0xC0], xmm12
0000762f89bd162f  vmovaps [rsp+0xD0], xmm13
0000762f89bd1638  vmovaps [rsp+0xE0], xmm15
0000762f89bd1641  sub rsp, 0x30
0000762f89bd1645  movaps [rsp], xmm14
0000762f89bd164a  movaps [rsp+0x10], xmm2
0000762f89bd164f  movaps [rsp+0x20], xmm15
0000762f89bd1655  lea rdi, [rsp]
0000762f89bd1659  mov esi, 0x00
0000762f89bd165e  mov rax, 0x604D6F946530
0000762f89bd1668  call rax
0000762f89bd166a  movaps xmm14, [rsp]
0000762f89bd166f  add rsp, 0x30
0000762f89bd1673  vmovaps xmm0, [rsp]
0000762f89bd1678  vmovaps xmm1, [rsp+0x10]
0000762f89bd167e  vmovaps xmm2, [rsp+0x20]
0000762f89bd1684  vmovaps xmm3, [rsp+0x30]
0000762f89bd168a  vmovaps xmm4, [rsp+0x40]
0000762f89bd1690  vmovaps xmm5, [rsp+0x50]
0000762f89bd1696  vmovaps xmm6, [rsp+0x60]
0000762f89bd169c  vmovaps xmm7, [rsp+0x70]
0000762f89bd16a2  vmovaps xmm8, [rsp+0x80]
0000762f89bd16ab  vmovaps xmm9, [rsp+0x90]
0000762f89bd16b4  vmovaps xmm10, [rsp+0xA0]
0000762f89bd16bd  vmovaps xmm11, [rsp+0xB0]
0000762f89bd16c6  vmovaps xmm12, [rsp+0xC0]
0000762f89bd16cf  vmovaps xmm13, [rsp+0xD0]
0000762f89bd16d8  vmovaps xmm15, [rsp+0xE0]
0000762f89bd16e1  add rsp, 0xF0
0000762f89bd16e8  pop r11
0000762f89bd16ea  pop r10
0000762f89bd16ec  pop r9
0000762f89bd16ee  pop r8
0000762f89bd16f0  pop rsi
0000762f89bd16f1  pop rdi
0000762f89bd16f2  pop rdx
0000762f89bd16f3  pop rcx
0000762f89bd16f4  pop rax
0000762f89bd16f5  add rsp, 0x08
0000762f89bd16f9  jmp 0x0000762F89BCF8E7
0000762f89bd16fe  sub rsp, 0x08
0000762f89bd1702  push rax
0000762f89bd1703  push rcx
0000762f89bd1704  push rdx
0000762f89bd1705  push rdi
0000762f89bd1706  push rsi
0000762f89bd1707  push r8
0000762f89bd1709  push r9
0000762f89bd170b  push r10
0000762f89bd170d  push r11
0000762f89bd170f  sub rsp, 0xF0
0000762f89bd1716  vmovaps [rsp], xmm0
0000762f89bd171b  vmovaps [rsp+0x10], xmm1
0000762f89bd1721  vmovaps [rsp+0x20], xmm2
0000762f89bd1727  vmovaps [rsp+0x30], xmm3
0000762f89bd172d  vmovaps [rsp+0x40], xmm4
0000762f89bd1733  vmovaps [rsp+0x50], xmm5
0000762f89bd1739  vmovaps [rsp+0x60], xmm6
0000762f89bd173f  vmovaps [rsp+0x70], xmm7
0000762f89bd1745  vmovaps [rsp+0x80], xmm8
0000762f89bd174e  vmovaps [rsp+0x90], xmm9
0000762f89bd1757  vmovaps [rsp+0xA0], xmm10
0000762f89bd1760  vmovaps [rsp+0xB0], xmm11
0000762f89bd1769  vmovaps [rsp+0xC0], xmm12
0000762f89bd1772  vmovaps [rsp+0xD0], xmm13
0000762f89bd177b  vmovaps [rsp+0xE0], xmm14
0000762f89bd1784  sub rsp, 0x30
0000762f89bd1788  movaps [rsp], xmm15
0000762f89bd178d  movaps [rsp+0x10], xmm2
0000762f89bd1792  movaps [rsp+0x20], xmm1
0000762f89bd1797  lea rdi, [rsp]
0000762f89bd179b  mov esi, 0x00
0000762f89bd17a0  mov rax, 0x604D6F946530
0000762f89bd17aa  call rax
0000762f89bd17ac  movaps xmm15, [rsp]
0000762f89bd17b1  add rsp, 0x30
0000762f89bd17b5  vmovaps xmm0, [rsp]
0000762f89bd17ba  vmovaps xmm1, [rsp+0x10]
0000762f89bd17c0  vmovaps xmm2, [rsp+0x20]
0000762f89bd17c6  vmovaps xmm3, [rsp+0x30]
0000762f89bd17cc  vmovaps xmm4, [rsp+0x40]
0000762f89bd17d2  vmovaps xmm5, [rsp+0x50]
0000762f89bd17d8  vmovaps xmm6, [rsp+0x60]
0000762f89bd17de  vmovaps xmm7, [rsp+0x70]
0000762f89bd17e4  vmovaps xmm8, [rsp+0x80]
0000762f89bd17ed  vmovaps xmm9, [rsp+0x90]
0000762f89bd17f6  vmovaps xmm10, [rsp+0xA0]
0000762f89bd17ff  vmovaps xmm11, [rsp+0xB0]
0000762f89bd1808  vmovaps xmm12, [rsp+0xC0]
0000762f89bd1811  vmovaps xmm13, [rsp+0xD0]
0000762f89bd181a  vmovaps xmm14, [rsp+0xE0]
0000762f89bd1823  add rsp, 0xF0
0000762f89bd182a  pop r11
0000762f89bd182c  pop r10
0000762f89bd182e  pop r9
0000762f89bd1830  pop r8
0000762f89bd1832  pop rsi
0000762f89bd1833  pop rdi
0000762f89bd1834  pop rdx
0000762f89bd1835  pop rcx
0000762f89bd1836  pop rax
0000762f89bd1837  add rsp, 0x08
0000762f89bd183b  jmp 0x0000762F89BCF923
0000762f89bd1840  call 0x0000762F899FF430
0000762f89bd1845  jmp 0x0000762F89BCF930
0000762f89bd184a  sub rsp, 0x08
0000762f89bd184e  push rax
0000762f89bd184f  push rcx
0000762f89bd1850  push rdx
0000762f89bd1851  push rdi
0000762f89bd1852  push rsi
0000762f89bd1853  push r8
0000762f89bd1855  push r9
0000762f89bd1857  push r10
0000762f89bd1859  push r11
0000762f89bd185b  sub rsp, 0xF0
0000762f89bd1862  vmovaps [rsp], xmm0
0000762f89bd1867  vmovaps [rsp+0x10], xmm1
0000762f89bd186d  vmovaps [rsp+0x20], xmm3
0000762f89bd1873  vmovaps [rsp+0x30], xmm4
0000762f89bd1879  vmovaps [rsp+0x40], xmm5
0000762f89bd187f  vmovaps [rsp+0x50], xmm6
0000762f89bd1885  vmovaps [rsp+0x60], xmm7
0000762f89bd188b  vmovaps [rsp+0x70], xmm8
0000762f89bd1891  vmovaps [rsp+0x80], xmm9
0000762f89bd189a  vmovaps [rsp+0x90], xmm10
0000762f89bd18a3  vmovaps [rsp+0xA0], xmm11
0000762f89bd18ac  vmovaps [rsp+0xB0], xmm12
0000762f89bd18b5  vmovaps [rsp+0xC0], xmm13
0000762f89bd18be  vmovaps [rsp+0xD0], xmm14
0000762f89bd18c7  vmovaps [rsp+0xE0], xmm15
0000762f89bd18d0  sub rsp, 0x30
0000762f89bd18d4  movaps [rsp], xmm2
0000762f89bd18d8  movaps [rsp+0x10], xmm1
0000762f89bd18dd  movaps [rsp+0x20], xmm14
0000762f89bd18e3  lea rdi, [rsp]
0000762f89bd18e7  mov esi, 0x00
0000762f89bd18ec  mov rax, 0x604D6F946530
0000762f89bd18f6  call rax
0000762f89bd18f8  movaps xmm2, [rsp]
0000762f89bd18fc  add rsp, 0x30
0000762f89bd1900  vmovaps xmm0, [rsp]
0000762f89bd1905  vmovaps xmm1, [rsp+0x10]
0000762f89bd190b  vmovaps xmm3, [rsp+0x20]
0000762f89bd1911  vmovaps xmm4, [rsp+0x30]
0000762f89bd1917  vmovaps xmm5, [rsp+0x40]
0000762f89bd191d  vmovaps xmm6, [rsp+0x50]
0000762f89bd1923  vmovaps xmm7, [rsp+0x60]
0000762f89bd1929  vmovaps xmm8, [rsp+0x70]
0000762f89bd192f  vmovaps xmm9, [rsp+0x80]
0000762f89bd1938  vmovaps xmm10, [rsp+0x90]
0000762f89bd1941  vmovaps xmm11, [rsp+0xA0]
0000762f89bd194a  vmovaps xmm12, [rsp+0xB0]
0000762f89bd1953  vmovaps xmm13, [rsp+0xC0]
0000762f89bd195c  vmovaps xmm14, [rsp+0xD0]
0000762f89bd1965  vmovaps xmm15, [rsp+0xE0]
0000762f89bd196e  add rsp, 0xF0
0000762f89bd1975  pop r11
0000762f89bd1977  pop r10
0000762f89bd1979  pop r9
0000762f89bd197b  pop r8
0000762f89bd197d  pop rsi
0000762f89bd197e  pop rdi
0000762f89bd197f  pop rdx
0000762f89bd1980  pop rcx
0000762f89bd1981  pop rax
0000762f89bd1982  add rsp, 0x08
0000762f89bd1986  jmp 0x0000762F89BCF96D
0000762f89bd198b  sub rsp, 0x08
0000762f89bd198f  push rax
0000762f89bd1990  push rcx
0000762f89bd1991  push rdx
0000762f89bd1992  push rdi
0000762f89bd1993  push rsi
0000762f89bd1994  push r8
0000762f89bd1996  push r9
0000762f89bd1998  push r10
0000762f89bd199a  push r11
0000762f89bd199c  sub rsp, 0xF0
0000762f89bd19a3  vmovaps [rsp], xmm0
0000762f89bd19a8  vmovaps [rsp+0x10], xmm1
0000762f89bd19ae  vmovaps [rsp+0x20], xmm2
0000762f89bd19b4  vmovaps [rsp+0x30], xmm3
0000762f89bd19ba  vmovaps [rsp+0x40], xmm4
0000762f89bd19c0  vmovaps [rsp+0x50], xmm5
0000762f89bd19c6  vmovaps [rsp+0x60], xmm6
0000762f89bd19cc  vmovaps [rsp+0x70], xmm7
0000762f89bd19d2  vmovaps [rsp+0x80], xmm8
0000762f89bd19db  vmovaps [rsp+0x90], xmm9
0000762f89bd19e4  vmovaps [rsp+0xA0], xmm10
0000762f89bd19ed  vmovaps [rsp+0xB0], xmm11
0000762f89bd19f6  vmovaps [rsp+0xC0], xmm12
0000762f89bd19ff  vmovaps [rsp+0xD0], xmm13
0000762f89bd1a08  vmovaps [rsp+0xE0], xmm14
0000762f89bd1a11  sub rsp, 0x30
0000762f89bd1a15  movaps [rsp], xmm15
0000762f89bd1a1a  movaps [rsp+0x10], xmm14
0000762f89bd1a20  movaps [rsp+0x20], xmm1
0000762f89bd1a25  lea rdi, [rsp]
0000762f89bd1a29  mov esi, 0x00
0000762f89bd1a2e  mov rax, 0x604D6F946530
0000762f89bd1a38  call rax
0000762f89bd1a3a  movaps xmm15, [rsp]
0000762f89bd1a3f  add rsp, 0x30
0000762f89bd1a43  vmovaps xmm0, [rsp]
0000762f89bd1a48  vmovaps xmm1, [rsp+0x10]
0000762f89bd1a4e  vmovaps xmm2, [rsp+0x20]
0000762f89bd1a54  vmovaps xmm3, [rsp+0x30]
0000762f89bd1a5a  vmovaps xmm4, [rsp+0x40]
0000762f89bd1a60  vmovaps xmm5, [rsp+0x50]
0000762f89bd1a66  vmovaps xmm6, [rsp+0x60]
0000762f89bd1a6c  vmovaps xmm7, [rsp+0x70]
0000762f89bd1a72  vmovaps xmm8, [rsp+0x80]
0000762f89bd1a7b  vmovaps xmm9, [rsp+0x90]
0000762f89bd1a84  vmovaps xmm10, [rsp+0xA0]
0000762f89bd1a8d  vmovaps xmm11, [rsp+0xB0]
0000762f89bd1a96  vmovaps xmm12, [rsp+0xC0]
0000762f89bd1a9f  vmovaps xmm13, [rsp+0xD0]
0000762f89bd1aa8  vmovaps xmm14, [rsp+0xE0]
0000762f89bd1ab1  add rsp, 0xF0
0000762f89bd1ab8  pop r11
0000762f89bd1aba  pop r10
0000762f89bd1abc  pop r9
0000762f89bd1abe  pop r8
0000762f89bd1ac0  pop rsi
0000762f89bd1ac1  pop rdi
0000762f89bd1ac2  pop rdx
0000762f89bd1ac3  pop rcx
0000762f89bd1ac4  pop rax
0000762f89bd1ac5  add rsp, 0x08
0000762f89bd1ac9  jmp 0x0000762F89BCF9E7
0000762f89bd1ace  call 0x0000762F899FF430
0000762f89bd1ad3  jmp 0x0000762F89BCF9F4
0000762f89bd1ad8  sub rsp, 0x08
0000762f89bd1adc  push rax
0000762f89bd1add  push rcx
0000762f89bd1ade  push rdx
0000762f89bd1adf  push rdi
0000762f89bd1ae0  push rsi
0000762f89bd1ae1  push r8
0000762f89bd1ae3  push r9
0000762f89bd1ae5  push r10
0000762f89bd1ae7  push r11
0000762f89bd1ae9  sub rsp, 0xF0
0000762f89bd1af0  vmovaps [rsp], xmm0
0000762f89bd1af5  vmovaps [rsp+0x10], xmm1
0000762f89bd1afb  vmovaps [rsp+0x20], xmm2
0000762f89bd1b01  vmovaps [rsp+0x30], xmm3
0000762f89bd1b07  vmovaps [rsp+0x40], xmm4
0000762f89bd1b0d  vmovaps [rsp+0x50], xmm5
0000762f89bd1b13  vmovaps [rsp+0x60], xmm6
0000762f89bd1b19  vmovaps [rsp+0x70], xmm7
0000762f89bd1b1f  vmovaps [rsp+0x80], xmm8
0000762f89bd1b28  vmovaps [rsp+0x90], xmm9
0000762f89bd1b31  vmovaps [rsp+0xA0], xmm10
0000762f89bd1b3a  vmovaps [rsp+0xB0], xmm11
0000762f89bd1b43  vmovaps [rsp+0xC0], xmm12
0000762f89bd1b4c  vmovaps [rsp+0xD0], xmm13
0000762f89bd1b55  vmovaps [rsp+0xE0], xmm15
0000762f89bd1b5e  sub rsp, 0x30
0000762f89bd1b62  movaps [rsp], xmm14
0000762f89bd1b67  movaps [rsp+0x10], xmm13
0000762f89bd1b6d  movaps [rsp+0x20], xmm1
0000762f89bd1b72  lea rdi, [rsp]
0000762f89bd1b76  mov esi, 0x00
0000762f89bd1b7b  mov rax, 0x604D6F946530
0000762f89bd1b85  call rax
0000762f89bd1b87  movaps xmm14, [rsp]
0000762f89bd1b8c  add rsp, 0x30
0000762f89bd1b90  vmovaps xmm0, [rsp]
0000762f89bd1b95  vmovaps xmm1, [rsp+0x10]
0000762f89bd1b9b  vmovaps xmm2, [rsp+0x20]
0000762f89bd1ba1  vmovaps xmm3, [rsp+0x30]
0000762f89bd1ba7  vmovaps xmm4, [rsp+0x40]
0000762f89bd1bad  vmovaps xmm5, [rsp+0x50]
0000762f89bd1bb3  vmovaps xmm6, [rsp+0x60]
0000762f89bd1bb9  vmovaps xmm7, [rsp+0x70]
0000762f89bd1bbf  vmovaps xmm8, [rsp+0x80]
0000762f89bd1bc8  vmovaps xmm9, [rsp+0x90]
0000762f89bd1bd1  vmovaps xmm10, [rsp+0xA0]
0000762f89bd1bda  vmovaps xmm11, [rsp+0xB0]
0000762f89bd1be3  vmovaps xmm12, [rsp+0xC0]
0000762f89bd1bec  vmovaps xmm13, [rsp+0xD0]
0000762f89bd1bf5  vmovaps xmm15, [rsp+0xE0]
0000762f89bd1bfe  add rsp, 0xF0
0000762f89bd1c05  pop r11
0000762f89bd1c07  pop r10
0000762f89bd1c09  pop r9
0000762f89bd1c0b  pop r8
0000762f89bd1c0d  pop rsi
0000762f89bd1c0e  pop rdi
0000762f89bd1c0f  pop rdx
0000762f89bd1c10  pop rcx
0000762f89bd1c11  pop rax
0000762f89bd1c12  add rsp, 0x08
0000762f89bd1c16  jmp 0x0000762F89BCFAAF
0000762f89bd1c1b  sub rsp, 0x08
0000762f89bd1c1f  push rax
0000762f89bd1c20  push rcx
0000762f89bd1c21  push rdx
0000762f89bd1c22  push rdi
0000762f89bd1c23  push rsi
0000762f89bd1c24  push r8
0000762f89bd1c26  push r9
0000762f89bd1c28  push r10
0000762f89bd1c2a  push r11
0000762f89bd1c2c  sub rsp, 0xF0
0000762f89bd1c33  vmovaps [rsp], xmm0
0000762f89bd1c38  vmovaps [rsp+0x10], xmm1
0000762f89bd1c3e  vmovaps [rsp+0x20], xmm2
0000762f89bd1c44  vmovaps [rsp+0x30], xmm3
0000762f89bd1c4a  vmovaps [rsp+0x40], xmm4
0000762f89bd1c50  vmovaps [rsp+0x50], xmm5
0000762f89bd1c56  vmovaps [rsp+0x60], xmm6
0000762f89bd1c5c  vmovaps [rsp+0x70], xmm7
0000762f89bd1c62  vmovaps [rsp+0x80], xmm8
0000762f89bd1c6b  vmovaps [rsp+0x90], xmm9
0000762f89bd1c74  vmovaps [rsp+0xA0], xmm10
0000762f89bd1c7d  vmovaps [rsp+0xB0], xmm11
0000762f89bd1c86  vmovaps [rsp+0xC0], xmm12
0000762f89bd1c8f  vmovaps [rsp+0xD0], xmm13
0000762f89bd1c98  vmovaps [rsp+0xE0], xmm14
0000762f89bd1ca1  sub rsp, 0x30
0000762f89bd1ca5  movaps [rsp], xmm15
0000762f89bd1caa  movaps [rsp+0x10], xmm13
0000762f89bd1cb0  movaps [rsp+0x20], xmm1
0000762f89bd1cb5  lea rdi, [rsp]
0000762f89bd1cb9  mov esi, 0x00
0000762f89bd1cbe  mov rax, 0x604D6F946530
0000762f89bd1cc8  call rax
0000762f89bd1cca  movaps xmm15, [rsp]
0000762f89bd1ccf  add rsp, 0x30
0000762f89bd1cd3  vmovaps xmm0, [rsp]
0000762f89bd1cd8  vmovaps xmm1, [rsp+0x10]
0000762f89bd1cde  vmovaps xmm2, [rsp+0x20]
0000762f89bd1ce4  vmovaps xmm3, [rsp+0x30]
0000762f89bd1cea  vmovaps xmm4, [rsp+0x40]
0000762f89bd1cf0  vmovaps xmm5, [rsp+0x50]
0000762f89bd1cf6  vmovaps xmm6, [rsp+0x60]
0000762f89bd1cfc  vmovaps xmm7, [rsp+0x70]
0000762f89bd1d02  vmovaps xmm8, [rsp+0x80]
0000762f89bd1d0b  vmovaps xmm9, [rsp+0x90]
0000762f89bd1d14  vmovaps xmm10, [rsp+0xA0]
0000762f89bd1d1d  vmovaps xmm11, [rsp+0xB0]
0000762f89bd1d26  vmovaps xmm12, [rsp+0xC0]
0000762f89bd1d2f  vmovaps xmm13, [rsp+0xD0]
0000762f89bd1d38  vmovaps xmm14, [rsp+0xE0]
0000762f89bd1d41  add rsp, 0xF0
0000762f89bd1d48  pop r11
0000762f89bd1d4a  pop r10
0000762f89bd1d4c  pop r9
0000762f89bd1d4e  pop r8
0000762f89bd1d50  pop rsi
0000762f89bd1d51  pop rdi
0000762f89bd1d52  pop rdx
0000762f89bd1d53  pop rcx
0000762f89bd1d54  pop rax
0000762f89bd1d55  add rsp, 0x08
0000762f89bd1d59  jmp 0x0000762F89BCFAEB
0000762f89bd1d5e  call 0x0000762F899FF430
0000762f89bd1d63  jmp 0x0000762F89BCFAF8
0000762f89bd1d68  sub rsp, 0x08
0000762f89bd1d6c  push rax
0000762f89bd1d6d  push rcx
0000762f89bd1d6e  push rdx
0000762f89bd1d6f  push rdi
0000762f89bd1d70  push rsi
0000762f89bd1d71  push r8
0000762f89bd1d73  push r9
0000762f89bd1d75  push r10
0000762f89bd1d77  push r11
0000762f89bd1d79  sub rsp, 0xF0
0000762f89bd1d80  vmovaps [rsp], xmm0
0000762f89bd1d85  vmovaps [rsp+0x10], xmm1
0000762f89bd1d8b  vmovaps [rsp+0x20], xmm2
0000762f89bd1d91  vmovaps [rsp+0x30], xmm3
0000762f89bd1d97  vmovaps [rsp+0x40], xmm4
0000762f89bd1d9d  vmovaps [rsp+0x50], xmm5
0000762f89bd1da3  vmovaps [rsp+0x60], xmm6
0000762f89bd1da9  vmovaps [rsp+0x70], xmm7
0000762f89bd1daf  vmovaps [rsp+0x80], xmm8
0000762f89bd1db8  vmovaps [rsp+0x90], xmm9
0000762f89bd1dc1  vmovaps [rsp+0xA0], xmm10
0000762f89bd1dca  vmovaps [rsp+0xB0], xmm11
0000762f89bd1dd3  vmovaps [rsp+0xC0], xmm12
0000762f89bd1ddc  vmovaps [rsp+0xD0], xmm13
0000762f89bd1de5  vmovaps [rsp+0xE0], xmm15
0000762f89bd1dee  sub rsp, 0x30
0000762f89bd1df2  movaps [rsp], xmm14
0000762f89bd1df7  movaps [rsp+0x10], xmm13
0000762f89bd1dfd  movaps [rsp+0x20], xmm2
0000762f89bd1e02  lea rdi, [rsp]
0000762f89bd1e06  mov esi, 0x00
0000762f89bd1e0b  mov rax, 0x604D6F946530
0000762f89bd1e15  call rax
0000762f89bd1e17  movaps xmm14, [rsp]
0000762f89bd1e1c  add rsp, 0x30
0000762f89bd1e20  vmovaps xmm0, [rsp]
0000762f89bd1e25  vmovaps xmm1, [rsp+0x10]
0000762f89bd1e2b  vmovaps xmm2, [rsp+0x20]
0000762f89bd1e31  vmovaps xmm3, [rsp+0x30]
0000762f89bd1e37  vmovaps xmm4, [rsp+0x40]
0000762f89bd1e3d  vmovaps xmm5, [rsp+0x50]
0000762f89bd1e43  vmovaps xmm6, [rsp+0x60]
0000762f89bd1e49  vmovaps xmm7, [rsp+0x70]
0000762f89bd1e4f  vmovaps xmm8, [rsp+0x80]
0000762f89bd1e58  vmovaps xmm9, [rsp+0x90]
0000762f89bd1e61  vmovaps xmm10, [rsp+0xA0]
0000762f89bd1e6a  vmovaps xmm11, [rsp+0xB0]
0000762f89bd1e73  vmovaps xmm12, [rsp+0xC0]
0000762f89bd1e7c  vmovaps xmm13, [rsp+0xD0]
0000762f89bd1e85  vmovaps xmm15, [rsp+0xE0]
0000762f89bd1e8e  add rsp, 0xF0
0000762f89bd1e95  pop r11
0000762f89bd1e97  pop r10
0000762f89bd1e99  pop r9
0000762f89bd1e9b  pop r8
0000762f89bd1e9d  pop rsi
0000762f89bd1e9e  pop rdi
0000762f89bd1e9f  pop rdx
0000762f89bd1ea0  pop rcx
0000762f89bd1ea1  pop rax
0000762f89bd1ea2  add rsp, 0x08
0000762f89bd1ea6  jmp 0x0000762F89BCFB24
0000762f89bd1eab  sub rsp, 0x08
0000762f89bd1eaf  push rax
0000762f89bd1eb0  push rcx
0000762f89bd1eb1  push rdx
0000762f89bd1eb2  push rdi
0000762f89bd1eb3  push rsi
0000762f89bd1eb4  push r8
0000762f89bd1eb6  push r9
0000762f89bd1eb8  push r10
0000762f89bd1eba  push r11
0000762f89bd1ebc  sub rsp, 0xF0
0000762f89bd1ec3  vmovaps [rsp], xmm0
0000762f89bd1ec8  vmovaps [rsp+0x10], xmm2
0000762f89bd1ece  vmovaps [rsp+0x20], xmm3
0000762f89bd1ed4  vmovaps [rsp+0x30], xmm4
0000762f89bd1eda  vmovaps [rsp+0x40], xmm5
0000762f89bd1ee0  vmovaps [rsp+0x50], xmm6
0000762f89bd1ee6  vmovaps [rsp+0x60], xmm7
0000762f89bd1eec  vmovaps [rsp+0x70], xmm8
0000762f89bd1ef2  vmovaps [rsp+0x80], xmm9
0000762f89bd1efb  vmovaps [rsp+0x90], xmm10
0000762f89bd1f04  vmovaps [rsp+0xA0], xmm11
0000762f89bd1f0d  vmovaps [rsp+0xB0], xmm12
0000762f89bd1f16  vmovaps [rsp+0xC0], xmm13
0000762f89bd1f1f  vmovaps [rsp+0xD0], xmm14
0000762f89bd1f28  vmovaps [rsp+0xE0], xmm15
0000762f89bd1f31  sub rsp, 0x30
0000762f89bd1f35  movaps [rsp], xmm1
0000762f89bd1f39  movaps [rsp+0x10], xmm13
0000762f89bd1f3f  movaps [rsp+0x20], xmm2
0000762f89bd1f44  lea rdi, [rsp]
0000762f89bd1f48  mov esi, 0x00
0000762f89bd1f4d  mov rax, 0x604D6F946530
0000762f89bd1f57  call rax
0000762f89bd1f59  movaps xmm1, [rsp]
0000762f89bd1f5d  add rsp, 0x30
0000762f89bd1f61  vmovaps xmm0, [rsp]
0000762f89bd1f66  vmovaps xmm2, [rsp+0x10]
0000762f89bd1f6c  vmovaps xmm3, [rsp+0x20]
0000762f89bd1f72  vmovaps xmm4, [rsp+0x30]
0000762f89bd1f78  vmovaps xmm5, [rsp+0x40]
0000762f89bd1f7e  vmovaps xmm6, [rsp+0x50]
0000762f89bd1f84  vmovaps xmm7, [rsp+0x60]
0000762f89bd1f8a  vmovaps xmm8, [rsp+0x70]
0000762f89bd1f90  vmovaps xmm9, [rsp+0x80]
0000762f89bd1f99  vmovaps xmm10, [rsp+0x90]
0000762f89bd1fa2  vmovaps xmm11, [rsp+0xA0]
0000762f89bd1fab  vmovaps xmm12, [rsp+0xB0]
0000762f89bd1fb4  vmovaps xmm13, [rsp+0xC0]
0000762f89bd1fbd  vmovaps xmm14, [rsp+0xD0]
0000762f89bd1fc6  vmovaps xmm15, [rsp+0xE0]
0000762f89bd1fcf  add rsp, 0xF0
0000762f89bd1fd6  pop r11
0000762f89bd1fd8  pop r10
0000762f89bd1fda  pop r9
0000762f89bd1fdc  pop r8
0000762f89bd1fde  pop rsi
0000762f89bd1fdf  pop rdi
0000762f89bd1fe0  pop rdx
0000762f89bd1fe1  pop rcx
0000762f89bd1fe2  pop rax
0000762f89bd1fe3  add rsp, 0x08
0000762f89bd1fe7  jmp 0x0000762F89BCFB52
0000762f89bd1fec  sub rsp, 0x08
0000762f89bd1ff0  push rax
0000762f89bd1ff1  push rcx
0000762f89bd1ff2  push rdx
0000762f89bd1ff3  push rdi
0000762f89bd1ff4  push rsi
0000762f89bd1ff5  push r8
0000762f89bd1ff7  push r9
0000762f89bd1ff9  push r10
0000762f89bd1ffb  push r11
0000762f89bd1ffd  sub rsp, 0xF0
0000762f89bd2004  vmovaps [rsp], xmm0
0000762f89bd2009  vmovaps [rsp+0x10], xmm1
0000762f89bd200f  vmovaps [rsp+0x20], xmm3
0000762f89bd2015  vmovaps [rsp+0x30], xmm4
0000762f89bd201b  vmovaps [rsp+0x40], xmm5
0000762f89bd2021  vmovaps [rsp+0x50], xmm6
0000762f89bd2027  vmovaps [rsp+0x60], xmm7
0000762f89bd202d  vmovaps [rsp+0x70], xmm8
0000762f89bd2033  vmovaps [rsp+0x80], xmm9
0000762f89bd203c  vmovaps [rsp+0x90], xmm10
0000762f89bd2045  vmovaps [rsp+0xA0], xmm11
0000762f89bd204e  vmovaps [rsp+0xB0], xmm12
0000762f89bd2057  vmovaps [rsp+0xC0], xmm13
0000762f89bd2060  vmovaps [rsp+0xD0], xmm14
0000762f89bd2069  vmovaps [rsp+0xE0], xmm15
0000762f89bd2072  sub rsp, 0x30
0000762f89bd2076  movaps [rsp], xmm2
0000762f89bd207a  movaps [rsp+0x10], xmm1
0000762f89bd207f  movaps [rsp+0x20], xmm13
0000762f89bd2085  lea rdi, [rsp]
0000762f89bd2089  mov esi, 0x00
0000762f89bd208e  mov rax, 0x604D6F946530
0000762f89bd2098  call rax
0000762f89bd209a  movaps xmm2, [rsp]
0000762f89bd209e  add rsp, 0x30
0000762f89bd20a2  vmovaps xmm0, [rsp]
0000762f89bd20a7  vmovaps xmm1, [rsp+0x10]
0000762f89bd20ad  vmovaps xmm3, [rsp+0x20]
0000762f89bd20b3  vmovaps xmm4, [rsp+0x30]
0000762f89bd20b9  vmovaps xmm5, [rsp+0x40]
0000762f89bd20bf  vmovaps xmm6, [rsp+0x50]
0000762f89bd20c5  vmovaps xmm7, [rsp+0x60]
0000762f89bd20cb  vmovaps xmm8, [rsp+0x70]
0000762f89bd20d1  vmovaps xmm9, [rsp+0x80]
0000762f89bd20da  vmovaps xmm10, [rsp+0x90]
0000762f89bd20e3  vmovaps xmm11, [rsp+0xA0]
0000762f89bd20ec  vmovaps xmm12, [rsp+0xB0]
0000762f89bd20f5  vmovaps xmm13, [rsp+0xC0]
0000762f89bd20fe  vmovaps xmm14, [rsp+0xD0]
0000762f89bd2107  vmovaps xmm15, [rsp+0xE0]
0000762f89bd2110  add rsp, 0xF0
0000762f89bd2117  pop r11
0000762f89bd2119  pop r10
0000762f89bd211b  pop r9
0000762f89bd211d  pop r8
0000762f89bd211f  pop rsi
0000762f89bd2120  pop rdi
0000762f89bd2121  pop rdx
0000762f89bd2122  pop rcx
0000762f89bd2123  pop rax
0000762f89bd2124  add rsp, 0x08
0000762f89bd2128  jmp 0x0000762F89BCFBAB
0000762f89bd212d  call 0x0000762F899FF430
0000762f89bd2132  jmp 0x0000762F89BCFBB8
0000762f89bd2137  sub rsp, 0x08
0000762f89bd213b  push rax
0000762f89bd213c  push rcx
0000762f89bd213d  push rdx
0000762f89bd213e  push rdi
0000762f89bd213f  push rsi
0000762f89bd2140  push r8
0000762f89bd2142  push r9
0000762f89bd2144  push r10
0000762f89bd2146  push r11
0000762f89bd2148  sub rsp, 0xF0
0000762f89bd214f  vmovaps [rsp], xmm0
0000762f89bd2154  vmovaps [rsp+0x10], xmm1
0000762f89bd215a  vmovaps [rsp+0x20], xmm2
0000762f89bd2160  vmovaps [rsp+0x30], xmm3
0000762f89bd2166  vmovaps [rsp+0x40], xmm4
0000762f89bd216c  vmovaps [rsp+0x50], xmm5
0000762f89bd2172  vmovaps [rsp+0x60], xmm6
0000762f89bd2178  vmovaps [rsp+0x70], xmm7
0000762f89bd217e  vmovaps [rsp+0x80], xmm8
0000762f89bd2187  vmovaps [rsp+0x90], xmm9
0000762f89bd2190  vmovaps [rsp+0xA0], xmm10
0000762f89bd2199  vmovaps [rsp+0xB0], xmm11
0000762f89bd21a2  vmovaps [rsp+0xC0], xmm12
0000762f89bd21ab  vmovaps [rsp+0xD0], xmm13
0000762f89bd21b4  vmovaps [rsp+0xE0], xmm14
0000762f89bd21bd  sub rsp, 0x30
0000762f89bd21c1  movaps [rsp], xmm15
0000762f89bd21c6  movaps [rsp+0x10], xmm13
0000762f89bd21cc  movaps [rsp+0x20], xmm1
0000762f89bd21d1  lea rdi, [rsp]
0000762f89bd21d5  mov esi, 0x00
0000762f89bd21da  mov rax, 0x604D6F946530
0000762f89bd21e4  call rax
0000762f89bd21e6  movaps xmm15, [rsp]
0000762f89bd21eb  add rsp, 0x30
0000762f89bd21ef  vmovaps xmm0, [rsp]
0000762f89bd21f4  vmovaps xmm1, [rsp+0x10]
0000762f89bd21fa  vmovaps xmm2, [rsp+0x20]
0000762f89bd2200  vmovaps xmm3, [rsp+0x30]
0000762f89bd2206  vmovaps xmm4, [rsp+0x40]
0000762f89bd220c  vmovaps xmm5, [rsp+0x50]
0000762f89bd2212  vmovaps xmm6, [rsp+0x60]
0000762f89bd2218  vmovaps xmm7, [rsp+0x70]
0000762f89bd221e  vmovaps xmm8, [rsp+0x80]
0000762f89bd2227  vmovaps xmm9, [rsp+0x90]
0000762f89bd2230  vmovaps xmm10, [rsp+0xA0]
0000762f89bd2239  vmovaps xmm11, [rsp+0xB0]
0000762f89bd2242  vmovaps xmm12, [rsp+0xC0]
0000762f89bd224b  vmovaps xmm13, [rsp+0xD0]
0000762f89bd2254  vmovaps xmm14, [rsp+0xE0]
0000762f89bd225d  add rsp, 0xF0
0000762f89bd2264  pop r11
0000762f89bd2266  pop r10
0000762f89bd2268  pop r9
0000762f89bd226a  pop r8
0000762f89bd226c  pop rsi
0000762f89bd226d  pop rdi
0000762f89bd226e  pop rdx
0000762f89bd226f  pop rcx
0000762f89bd2270  pop rax
0000762f89bd2271  add rsp, 0x08
0000762f89bd2275  jmp 0x0000762F89BCFBF7
0000762f89bd227a  sub rsp, 0x08
0000762f89bd227e  push rax
0000762f89bd227f  push rcx
0000762f89bd2280  push rdx
0000762f89bd2281  push rdi
0000762f89bd2282  push rsi
0000762f89bd2283  push r8
0000762f89bd2285  push r9
0000762f89bd2287  push r10
0000762f89bd2289  push r11
0000762f89bd228b  sub rsp, 0xF0
0000762f89bd2292  vmovaps [rsp], xmm0
0000762f89bd2297  vmovaps [rsp+0x10], xmm1
0000762f89bd229d  vmovaps [rsp+0x20], xmm2
0000762f89bd22a3  vmovaps [rsp+0x30], xmm3
0000762f89bd22a9  vmovaps [rsp+0x40], xmm4
0000762f89bd22af  vmovaps [rsp+0x50], xmm5
0000762f89bd22b5  vmovaps [rsp+0x60], xmm6
0000762f89bd22bb  vmovaps [rsp+0x70], xmm7
0000762f89bd22c1  vmovaps [rsp+0x80], xmm8
0000762f89bd22ca  vmovaps [rsp+0x90], xmm9
0000762f89bd22d3  vmovaps [rsp+0xA0], xmm10
0000762f89bd22dc  vmovaps [rsp+0xB0], xmm11
0000762f89bd22e5  vmovaps [rsp+0xC0], xmm12
0000762f89bd22ee  vmovaps [rsp+0xD0], xmm13
0000762f89bd22f7  vmovaps [rsp+0xE0], xmm15
0000762f89bd2300  sub rsp, 0x30
0000762f89bd2304  movaps [rsp], xmm14
0000762f89bd2309  movaps [rsp+0x10], xmm11
0000762f89bd230f  movaps [rsp+0x20], xmm1
0000762f89bd2314  lea rdi, [rsp]
0000762f89bd2318  mov esi, 0x00
0000762f89bd231d  mov rax, 0x604D6F946530
0000762f89bd2327  call rax
0000762f89bd2329  movaps xmm14, [rsp]
0000762f89bd232e  add rsp, 0x30
0000762f89bd2332  vmovaps xmm0, [rsp]
0000762f89bd2337  vmovaps xmm1, [rsp+0x10]
0000762f89bd233d  vmovaps xmm2, [rsp+0x20]
0000762f89bd2343  vmovaps xmm3, [rsp+0x30]
0000762f89bd2349  vmovaps xmm4, [rsp+0x40]
0000762f89bd234f  vmovaps xmm5, [rsp+0x50]
0000762f89bd2355  vmovaps xmm6, [rsp+0x60]
0000762f89bd235b  vmovaps xmm7, [rsp+0x70]
0000762f89bd2361  vmovaps xmm8, [rsp+0x80]
0000762f89bd236a  vmovaps xmm9, [rsp+0x90]
0000762f89bd2373  vmovaps xmm10, [rsp+0xA0]
0000762f89bd237c  vmovaps xmm11, [rsp+0xB0]
0000762f89bd2385  vmovaps xmm12, [rsp+0xC0]
0000762f89bd238e  vmovaps xmm13, [rsp+0xD0]
0000762f89bd2397  vmovaps xmm15, [rsp+0xE0]
0000762f89bd23a0  add rsp, 0xF0
0000762f89bd23a7  pop r11
0000762f89bd23a9  pop r10
0000762f89bd23ab  pop r9
0000762f89bd23ad  pop r8
0000762f89bd23af  pop rsi
0000762f89bd23b0  pop rdi
0000762f89bd23b1  pop rdx
0000762f89bd23b2  pop rcx
0000762f89bd23b3  pop rax
0000762f89bd23b4  add rsp, 0x08
0000762f89bd23b8  jmp 0x0000762F89BCFC21
0000762f89bd23bd  sub rsp, 0x08
0000762f89bd23c1  push rax
0000762f89bd23c2  push rcx
0000762f89bd23c3  push rdx
0000762f89bd23c4  push rdi
0000762f89bd23c5  push rsi
0000762f89bd23c6  push r8
0000762f89bd23c8  push r9
0000762f89bd23ca  push r10
0000762f89bd23cc  push r11
0000762f89bd23ce  sub rsp, 0xF0
0000762f89bd23d5  vmovaps [rsp], xmm0
0000762f89bd23da  vmovaps [rsp+0x10], xmm1
0000762f89bd23e0  vmovaps [rsp+0x20], xmm2
0000762f89bd23e6  vmovaps [rsp+0x30], xmm3
0000762f89bd23ec  vmovaps [rsp+0x40], xmm4
0000762f89bd23f2  vmovaps [rsp+0x50], xmm5
0000762f89bd23f8  vmovaps [rsp+0x60], xmm6
0000762f89bd23fe  vmovaps [rsp+0x70], xmm7
0000762f89bd2404  vmovaps [rsp+0x80], xmm8
0000762f89bd240d  vmovaps [rsp+0x90], xmm9
0000762f89bd2416  vmovaps [rsp+0xA0], xmm10
0000762f89bd241f  vmovaps [rsp+0xB0], xmm11
0000762f89bd2428  vmovaps [rsp+0xC0], xmm12
0000762f89bd2431  vmovaps [rsp+0xD0], xmm14
0000762f89bd243a  vmovaps [rsp+0xE0], xmm15
0000762f89bd2443  sub rsp, 0x30
0000762f89bd2447  movaps [rsp], xmm13
0000762f89bd244c  movaps [rsp+0x10], xmm11
0000762f89bd2452  movaps [rsp+0x20], xmm1
0000762f89bd2457  lea rdi, [rsp]
0000762f89bd245b  mov esi, 0x00
0000762f89bd2460  mov rax, 0x604D6F946530
0000762f89bd246a  call rax
0000762f89bd246c  movaps xmm13, [rsp]
0000762f89bd2471  add rsp, 0x30
0000762f89bd2475  vmovaps xmm0, [rsp]
0000762f89bd247a  vmovaps xmm1, [rsp+0x10]
0000762f89bd2480  vmovaps xmm2, [rsp+0x20]
0000762f89bd2486  vmovaps xmm3, [rsp+0x30]
0000762f89bd248c  vmovaps xmm4, [rsp+0x40]
0000762f89bd2492  vmovaps xmm5, [rsp+0x50]
0000762f89bd2498  vmovaps xmm6, [rsp+0x60]
0000762f89bd249e  vmovaps xmm7, [rsp+0x70]
0000762f89bd24a4  vmovaps xmm8, [rsp+0x80]
0000762f89bd24ad  vmovaps xmm9, [rsp+0x90]
0000762f89bd24b6  vmovaps xmm10, [rsp+0xA0]
0000762f89bd24bf  vmovaps xmm11, [rsp+0xB0]
0000762f89bd24c8  vmovaps xmm12, [rsp+0xC0]
0000762f89bd24d1  vmovaps xmm14, [rsp+0xD0]
0000762f89bd24da  vmovaps xmm15, [rsp+0xE0]
0000762f89bd24e3  add rsp, 0xF0
0000762f89bd24ea  pop r11
0000762f89bd24ec  pop r10
0000762f89bd24ee  pop r9
0000762f89bd24f0  pop r8
0000762f89bd24f2  pop rsi
0000762f89bd24f3  pop rdi
0000762f89bd24f4  pop rdx
0000762f89bd24f5  pop rcx
0000762f89bd24f6  pop rax
0000762f89bd24f7  add rsp, 0x08
0000762f89bd24fb  jmp 0x0000762F89BCFC76
0000762f89bd2500  call 0x0000762F899FF430
0000762f89bd2505  jmp 0x0000762F89BCFC83
0000762f89bd250a  sub rsp, 0x08
0000762f89bd250e  push rax
0000762f89bd250f  push rcx
0000762f89bd2510  push rdx
0000762f89bd2511  push rdi
0000762f89bd2512  push rsi
0000762f89bd2513  push r8
0000762f89bd2515  push r9
0000762f89bd2517  push r10
0000762f89bd2519  push r11
0000762f89bd251b  sub rsp, 0xF0
0000762f89bd2522  vmovaps [rsp], xmm0
0000762f89bd2527  vmovaps [rsp+0x10], xmm1
0000762f89bd252d  vmovaps [rsp+0x20], xmm2
0000762f89bd2533  vmovaps [rsp+0x30], xmm3
0000762f89bd2539  vmovaps [rsp+0x40], xmm4
0000762f89bd253f  vmovaps [rsp+0x50], xmm5
0000762f89bd2545  vmovaps [rsp+0x60], xmm6
0000762f89bd254b  vmovaps [rsp+0x70], xmm7
0000762f89bd2551  vmovaps [rsp+0x80], xmm8
0000762f89bd255a  vmovaps [rsp+0x90], xmm9
0000762f89bd2563  vmovaps [rsp+0xA0], xmm10
0000762f89bd256c  vmovaps [rsp+0xB0], xmm11
0000762f89bd2575  vmovaps [rsp+0xC0], xmm12
0000762f89bd257e  vmovaps [rsp+0xD0], xmm13
0000762f89bd2587  vmovaps [rsp+0xE0], xmm14
0000762f89bd2590  sub rsp, 0x30
0000762f89bd2594  movaps [rsp], xmm15
0000762f89bd2599  movaps [rsp+0x10], xmm11
0000762f89bd259f  movaps [rsp+0x20], xmm1
0000762f89bd25a4  lea rdi, [rsp]
0000762f89bd25a8  mov esi, 0x00
0000762f89bd25ad  mov rax, 0x604D6F946530
0000762f89bd25b7  call rax
0000762f89bd25b9  movaps xmm15, [rsp]
0000762f89bd25be  add rsp, 0x30
0000762f89bd25c2  vmovaps xmm0, [rsp]
0000762f89bd25c7  vmovaps xmm1, [rsp+0x10]
0000762f89bd25cd  vmovaps xmm2, [rsp+0x20]
0000762f89bd25d3  vmovaps xmm3, [rsp+0x30]
0000762f89bd25d9  vmovaps xmm4, [rsp+0x40]
0000762f89bd25df  vmovaps xmm5, [rsp+0x50]
0000762f89bd25e5  vmovaps xmm6, [rsp+0x60]
0000762f89bd25eb  vmovaps xmm7, [rsp+0x70]
0000762f89bd25f1  vmovaps xmm8, [rsp+0x80]
0000762f89bd25fa  vmovaps xmm9, [rsp+0x90]
0000762f89bd2603  vmovaps xmm10, [rsp+0xA0]
0000762f89bd260c  vmovaps xmm11, [rsp+0xB0]
0000762f89bd2615  vmovaps xmm12, [rsp+0xC0]
0000762f89bd261e  vmovaps xmm13, [rsp+0xD0]
0000762f89bd2627  vmovaps xmm14, [rsp+0xE0]
0000762f89bd2630  add rsp, 0xF0
0000762f89bd2637  pop r11
0000762f89bd2639  pop r10
0000762f89bd263b  pop r9
0000762f89bd263d  pop r8
0000762f89bd263f  pop rsi
0000762f89bd2640  pop rdi
0000762f89bd2641  pop rdx
0000762f89bd2642  pop rcx
0000762f89bd2643  pop rax
0000762f89bd2644  add rsp, 0x08
0000762f89bd2648  jmp 0x0000762F89BCFCBC
0000762f89bd264d  sub rsp, 0x08
0000762f89bd2651  push rax
0000762f89bd2652  push rcx
0000762f89bd2653  push rdx
0000762f89bd2654  push rdi
0000762f89bd2655  push rsi
0000762f89bd2656  push r8
0000762f89bd2658  push r9
0000762f89bd265a  push r10
0000762f89bd265c  push r11
0000762f89bd265e  sub rsp, 0xF0
0000762f89bd2665  vmovaps [rsp], xmm0
0000762f89bd266a  vmovaps [rsp+0x10], xmm1
0000762f89bd2670  vmovaps [rsp+0x20], xmm2
0000762f89bd2676  vmovaps [rsp+0x30], xmm3
0000762f89bd267c  vmovaps [rsp+0x40], xmm4
0000762f89bd2682  vmovaps [rsp+0x50], xmm5
0000762f89bd2688  vmovaps [rsp+0x60], xmm6
0000762f89bd268e  vmovaps [rsp+0x70], xmm7
0000762f89bd2694  vmovaps [rsp+0x80], xmm8
0000762f89bd269d  vmovaps [rsp+0x90], xmm9
0000762f89bd26a6  vmovaps [rsp+0xA0], xmm10
0000762f89bd26af  vmovaps [rsp+0xB0], xmm12
0000762f89bd26b8  vmovaps [rsp+0xC0], xmm13
0000762f89bd26c1  vmovaps [rsp+0xD0], xmm14
0000762f89bd26ca  vmovaps [rsp+0xE0], xmm15
0000762f89bd26d3  sub rsp, 0x30
0000762f89bd26d7  movaps [rsp], xmm11
0000762f89bd26dc  movaps [rsp+0x10], xmm6
0000762f89bd26e1  movaps [rsp+0x20], xmm14
0000762f89bd26e7  lea rdi, [rsp]
0000762f89bd26eb  mov esi, 0x00
0000762f89bd26f0  mov rax, 0x604D6F946530
0000762f89bd26fa  call rax
0000762f89bd26fc  movaps xmm11, [rsp]
0000762f89bd2701  add rsp, 0x30
0000762f89bd2705  vmovaps xmm0, [rsp]
0000762f89bd270a  vmovaps xmm1, [rsp+0x10]
0000762f89bd2710  vmovaps xmm2, [rsp+0x20]
0000762f89bd2716  vmovaps xmm3, [rsp+0x30]
0000762f89bd271c  vmovaps xmm4, [rsp+0x40]
0000762f89bd2722  vmovaps xmm5, [rsp+0x50]
0000762f89bd2728  vmovaps xmm6, [rsp+0x60]
0000762f89bd272e  vmovaps xmm7, [rsp+0x70]
0000762f89bd2734  vmovaps xmm8, [rsp+0x80]
0000762f89bd273d  vmovaps xmm9, [rsp+0x90]
0000762f89bd2746  vmovaps xmm10, [rsp+0xA0]
0000762f89bd274f  vmovaps xmm12, [rsp+0xB0]
0000762f89bd2758  vmovaps xmm13, [rsp+0xC0]
0000762f89bd2761  vmovaps xmm14, [rsp+0xD0]
0000762f89bd276a  vmovaps xmm15, [rsp+0xE0]
0000762f89bd2773  add rsp, 0xF0
0000762f89bd277a  pop r11
0000762f89bd277c  pop r10
0000762f89bd277e  pop r9
0000762f89bd2780  pop r8
0000762f89bd2782  pop rsi
0000762f89bd2783  pop rdi
0000762f89bd2784  pop rdx
0000762f89bd2785  pop rcx
0000762f89bd2786  pop rax
0000762f89bd2787  add rsp, 0x08
0000762f89bd278b  jmp 0x0000762F89BCFD34
0000762f89bd2790  call 0x0000762F899FF430
0000762f89bd2795  jmp 0x0000762F89BCFD3E
0000762f89bd279a  sub rsp, 0x08
0000762f89bd279e  push rax
0000762f89bd279f  push rcx
0000762f89bd27a0  push rdx
0000762f89bd27a1  push rdi
0000762f89bd27a2  push rsi
0000762f89bd27a3  push r8
0000762f89bd27a5  push r9
0000762f89bd27a7  push r10
0000762f89bd27a9  push r11
0000762f89bd27ab  sub rsp, 0xF0
0000762f89bd27b2  vmovaps [rsp], xmm0
0000762f89bd27b7  vmovaps [rsp+0x10], xmm1
0000762f89bd27bd  vmovaps [rsp+0x20], xmm2
0000762f89bd27c3  vmovaps [rsp+0x30], xmm3
0000762f89bd27c9  vmovaps [rsp+0x40], xmm4
0000762f89bd27cf  vmovaps [rsp+0x50], xmm5
0000762f89bd27d5  vmovaps [rsp+0x60], xmm6
0000762f89bd27db  vmovaps [rsp+0x70], xmm7
0000762f89bd27e1  vmovaps [rsp+0x80], xmm8
0000762f89bd27ea  vmovaps [rsp+0x90], xmm9
0000762f89bd27f3  vmovaps [rsp+0xA0], xmm10
0000762f89bd27fc  vmovaps [rsp+0xB0], xmm11
0000762f89bd2805  vmovaps [rsp+0xC0], xmm12
0000762f89bd280e  vmovaps [rsp+0xD0], xmm13
0000762f89bd2817  vmovaps [rsp+0xE0], xmm15
0000762f89bd2820  sub rsp, 0x30
0000762f89bd2824  movaps [rsp], xmm14
0000762f89bd2829  movaps [rsp+0x10], xmm6
0000762f89bd282e  movaps [rsp+0x20], xmm2
0000762f89bd2833  lea rdi, [rsp]
0000762f89bd2837  mov esi, 0x00
0000762f89bd283c  mov rax, 0x604D6F946530
0000762f89bd2846  call rax
0000762f89bd2848  movaps xmm14, [rsp]
0000762f89bd284d  add rsp, 0x30
0000762f89bd2851  vmovaps xmm0, [rsp]
0000762f89bd2856  vmovaps xmm1, [rsp+0x10]
0000762f89bd285c  vmovaps xmm2, [rsp+0x20]
0000762f89bd2862  vmovaps xmm3, [rsp+0x30]
0000762f89bd2868  vmovaps xmm4, [rsp+0x40]
0000762f89bd286e  vmovaps xmm5, [rsp+0x50]
0000762f89bd2874  vmovaps xmm6, [rsp+0x60]
0000762f89bd287a  vmovaps xmm7, [rsp+0x70]
0000762f89bd2880  vmovaps xmm8, [rsp+0x80]
0000762f89bd2889  vmovaps xmm9, [rsp+0x90]
0000762f89bd2892  vmovaps xmm10, [rsp+0xA0]
0000762f89bd289b  vmovaps xmm11, [rsp+0xB0]
0000762f89bd28a4  vmovaps xmm12, [rsp+0xC0]
0000762f89bd28ad  vmovaps xmm13, [rsp+0xD0]
0000762f89bd28b6  vmovaps xmm15, [rsp+0xE0]
0000762f89bd28bf  add rsp, 0xF0
0000762f89bd28c6  pop r11
0000762f89bd28c8  pop r10
0000762f89bd28ca  pop r9
0000762f89bd28cc  pop r8
0000762f89bd28ce  pop rsi
0000762f89bd28cf  pop rdi
0000762f89bd28d0  pop rdx
0000762f89bd28d1  pop rcx
0000762f89bd28d2  pop rax
0000762f89bd28d3  add rsp, 0x08
0000762f89bd28d7  jmp 0x0000762F89BCFD72
0000762f89bd28dc  sub rsp, 0x08
0000762f89bd28e0  push rax
0000762f89bd28e1  push rcx
0000762f89bd28e2  push rdx
0000762f89bd28e3  push rdi
0000762f89bd28e4  push rsi
0000762f89bd28e5  push r8
0000762f89bd28e7  push r9
0000762f89bd28e9  push r10
0000762f89bd28eb  push r11
0000762f89bd28ed  sub rsp, 0xF0
0000762f89bd28f4  vmovaps [rsp], xmm0
0000762f89bd28f9  vmovaps [rsp+0x10], xmm1
0000762f89bd28ff  vmovaps [rsp+0x20], xmm2
0000762f89bd2905  vmovaps [rsp+0x30], xmm3
0000762f89bd290b  vmovaps [rsp+0x40], xmm4
0000762f89bd2911  vmovaps [rsp+0x50], xmm5
0000762f89bd2917  vmovaps [rsp+0x60], xmm7
0000762f89bd291d  vmovaps [rsp+0x70], xmm8
0000762f89bd2923  vmovaps [rsp+0x80], xmm9
0000762f89bd292c  vmovaps [rsp+0x90], xmm10
0000762f89bd2935  vmovaps [rsp+0xA0], xmm11
0000762f89bd293e  vmovaps [rsp+0xB0], xmm12
0000762f89bd2947  vmovaps [rsp+0xC0], xmm13
0000762f89bd2950  vmovaps [rsp+0xD0], xmm14
0000762f89bd2959  vmovaps [rsp+0xE0], xmm15
0000762f89bd2962  sub rsp, 0x30
0000762f89bd2966  movaps [rsp], xmm6
0000762f89bd296a  movaps [rsp+0x10], xmm5
0000762f89bd296f  movaps [rsp+0x20], xmm1
0000762f89bd2974  lea rdi, [rsp]
0000762f89bd2978  mov esi, 0x00
0000762f89bd297d  mov rax, 0x604D6F946530
0000762f89bd2987  call rax
0000762f89bd2989  movaps xmm6, [rsp]
0000762f89bd298d  add rsp, 0x30
0000762f89bd2991  vmovaps xmm0, [rsp]
0000762f89bd2996  vmovaps xmm1, [rsp+0x10]
0000762f89bd299c  vmovaps xmm2, [rsp+0x20]
0000762f89bd29a2  vmovaps xmm3, [rsp+0x30]
0000762f89bd29a8  vmovaps xmm4, [rsp+0x40]
0000762f89bd29ae  vmovaps xmm5, [rsp+0x50]
0000762f89bd29b4  vmovaps xmm7, [rsp+0x60]
0000762f89bd29ba  vmovaps xmm8, [rsp+0x70]
0000762f89bd29c0  vmovaps xmm9, [rsp+0x80]
0000762f89bd29c9  vmovaps xmm10, [rsp+0x90]
0000762f89bd29d2  vmovaps xmm11, [rsp+0xA0]
0000762f89bd29db  vmovaps xmm12, [rsp+0xB0]
0000762f89bd29e4  vmovaps xmm13, [rsp+0xC0]
0000762f89bd29ed  vmovaps xmm14, [rsp+0xD0]
0000762f89bd29f6  vmovaps xmm15, [rsp+0xE0]
0000762f89bd29ff  add rsp, 0xF0
0000762f89bd2a06  pop r11
0000762f89bd2a08  pop r10
0000762f89bd2a0a  pop r9
0000762f89bd2a0c  pop r8
0000762f89bd2a0e  pop rsi
0000762f89bd2a0f  pop rdi
0000762f89bd2a10  pop rdx
0000762f89bd2a11  pop rcx
0000762f89bd2a12  pop rax
0000762f89bd2a13  add rsp, 0x08
0000762f89bd2a17  jmp 0x0000762F89BCFD98
0000762f89bd2a1c  sub rsp, 0x08
0000762f89bd2a20  push rax
0000762f89bd2a21  push rcx
0000762f89bd2a22  push rdx
0000762f89bd2a23  push rdi
0000762f89bd2a24  push rsi
0000762f89bd2a25  push r8
0000762f89bd2a27  push r9
0000762f89bd2a29  push r10
0000762f89bd2a2b  push r11
0000762f89bd2a2d  sub rsp, 0xF0
0000762f89bd2a34  vmovaps [rsp], xmm0
0000762f89bd2a39  vmovaps [rsp+0x10], xmm2
0000762f89bd2a3f  vmovaps [rsp+0x20], xmm3
0000762f89bd2a45  vmovaps [rsp+0x30], xmm4
0000762f89bd2a4b  vmovaps [rsp+0x40], xmm5
0000762f89bd2a51  vmovaps [rsp+0x50], xmm6
0000762f89bd2a57  vmovaps [rsp+0x60], xmm7
0000762f89bd2a5d  vmovaps [rsp+0x70], xmm8
0000762f89bd2a63  vmovaps [rsp+0x80], xmm9
0000762f89bd2a6c  vmovaps [rsp+0x90], xmm10
0000762f89bd2a75  vmovaps [rsp+0xA0], xmm11
0000762f89bd2a7e  vmovaps [rsp+0xB0], xmm12
0000762f89bd2a87  vmovaps [rsp+0xC0], xmm13
0000762f89bd2a90  vmovaps [rsp+0xD0], xmm14
0000762f89bd2a99  vmovaps [rsp+0xE0], xmm15
0000762f89bd2aa2  sub rsp, 0x30
0000762f89bd2aa6  movaps [rsp], xmm1
0000762f89bd2aaa  movaps [rsp+0x10], xmm5
0000762f89bd2aaf  movaps [rsp+0x20], xmm13
0000762f89bd2ab5  lea rdi, [rsp]
0000762f89bd2ab9  mov esi, 0x00
0000762f89bd2abe  mov rax, 0x604D6F946530
0000762f89bd2ac8  call rax
0000762f89bd2aca  movaps xmm1, [rsp]
0000762f89bd2ace  add rsp, 0x30
0000762f89bd2ad2  vmovaps xmm0, [rsp]
0000762f89bd2ad7  vmovaps xmm2, [rsp+0x10]
0000762f89bd2add  vmovaps xmm3, [rsp+0x20]
0000762f89bd2ae3  vmovaps xmm4, [rsp+0x30]
0000762f89bd2ae9  vmovaps xmm5, [rsp+0x40]
0000762f89bd2aef  vmovaps xmm6, [rsp+0x50]
0000762f89bd2af5  vmovaps xmm7, [rsp+0x60]
0000762f89bd2afb  vmovaps xmm8, [rsp+0x70]
0000762f89bd2b01  vmovaps xmm9, [rsp+0x80]
0000762f89bd2b0a  vmovaps xmm10, [rsp+0x90]
0000762f89bd2b13  vmovaps xmm11, [rsp+0xA0]
0000762f89bd2b1c  vmovaps xmm12, [rsp+0xB0]
0000762f89bd2b25  vmovaps xmm13, [rsp+0xC0]
0000762f89bd2b2e  vmovaps xmm14, [rsp+0xD0]
0000762f89bd2b37  vmovaps xmm15, [rsp+0xE0]
0000762f89bd2b40  add rsp, 0xF0
0000762f89bd2b47  pop r11
0000762f89bd2b49  pop r10
0000762f89bd2b4b  pop r9
0000762f89bd2b4d  pop r8
0000762f89bd2b4f  pop rsi
0000762f89bd2b50  pop rdi
0000762f89bd2b51  pop rdx
0000762f89bd2b52  pop rcx
0000762f89bd2b53  pop rax
0000762f89bd2b54  add rsp, 0x08
0000762f89bd2b58  jmp 0x0000762F89BCFDB6
0000762f89bd2b5d  sub rsp, 0x08
0000762f89bd2b61  push rax
0000762f89bd2b62  push rcx
0000762f89bd2b63  push rdx
0000762f89bd2b64  push rdi
0000762f89bd2b65  push rsi
0000762f89bd2b66  push r8
0000762f89bd2b68  push r9
0000762f89bd2b6a  push r10
0000762f89bd2b6c  push r11
0000762f89bd2b6e  sub rsp, 0xF0
0000762f89bd2b75  vmovaps [rsp], xmm0
0000762f89bd2b7a  vmovaps [rsp+0x10], xmm1
0000762f89bd2b80  vmovaps [rsp+0x20], xmm2
0000762f89bd2b86  vmovaps [rsp+0x30], xmm3
0000762f89bd2b8c  vmovaps [rsp+0x40], xmm4
0000762f89bd2b92  vmovaps [rsp+0x50], xmm6
0000762f89bd2b98  vmovaps [rsp+0x60], xmm7
0000762f89bd2b9e  vmovaps [rsp+0x70], xmm8
0000762f89bd2ba4  vmovaps [rsp+0x80], xmm9
0000762f89bd2bad  vmovaps [rsp+0x90], xmm10
0000762f89bd2bb6  vmovaps [rsp+0xA0], xmm11
0000762f89bd2bbf  vmovaps [rsp+0xB0], xmm12
0000762f89bd2bc8  vmovaps [rsp+0xC0], xmm13
0000762f89bd2bd1  vmovaps [rsp+0xD0], xmm14
0000762f89bd2bda  vmovaps [rsp+0xE0], xmm15
0000762f89bd2be3  sub rsp, 0x30
0000762f89bd2be7  movaps [rsp], xmm5
0000762f89bd2beb  movaps [rsp+0x10], xmm2
0000762f89bd2bf0  movaps [rsp+0x20], xmm13
0000762f89bd2bf6  lea rdi, [rsp]
0000762f89bd2bfa  mov esi, 0x00
0000762f89bd2bff  mov rax, 0x604D6F946530
0000762f89bd2c09  call rax
0000762f89bd2c0b  movaps xmm5, [rsp]
0000762f89bd2c0f  add rsp, 0x30
0000762f89bd2c13  vmovaps xmm0, [rsp]
0000762f89bd2c18  vmovaps xmm1, [rsp+0x10]
0000762f89bd2c1e  vmovaps xmm2, [rsp+0x20]
0000762f89bd2c24  vmovaps xmm3, [rsp+0x30]
0000762f89bd2c2a  vmovaps xmm4, [rsp+0x40]
0000762f89bd2c30  vmovaps xmm6, [rsp+0x50]
0000762f89bd2c36  vmovaps xmm7, [rsp+0x60]
0000762f89bd2c3c  vmovaps xmm8, [rsp+0x70]
0000762f89bd2c42  vmovaps xmm9, [rsp+0x80]
0000762f89bd2c4b  vmovaps xmm10, [rsp+0x90]
0000762f89bd2c54  vmovaps xmm11, [rsp+0xA0]
0000762f89bd2c5d  vmovaps xmm12, [rsp+0xB0]
0000762f89bd2c66  vmovaps xmm13, [rsp+0xC0]
0000762f89bd2c6f  vmovaps xmm14, [rsp+0xD0]
0000762f89bd2c78  vmovaps xmm15, [rsp+0xE0]
0000762f89bd2c81  add rsp, 0xF0
0000762f89bd2c88  pop r11
0000762f89bd2c8a  pop r10
0000762f89bd2c8c  pop r9
0000762f89bd2c8e  pop r8
0000762f89bd2c90  pop rsi
0000762f89bd2c91  pop rdi
0000762f89bd2c92  pop rdx
0000762f89bd2c93  pop rcx
0000762f89bd2c94  pop rax
0000762f89bd2c95  add rsp, 0x08
0000762f89bd2c99  jmp 0x0000762F89BCFDEC
0000762f89bd2c9e  sub rsp, 0x08
0000762f89bd2ca2  push rax
0000762f89bd2ca3  push rcx
0000762f89bd2ca4  push rdx
0000762f89bd2ca5  push rdi
0000762f89bd2ca6  push rsi
0000762f89bd2ca7  push r8
0000762f89bd2ca9  push r9
0000762f89bd2cab  push r10
0000762f89bd2cad  push r11
0000762f89bd2caf  sub rsp, 0xF0
0000762f89bd2cb6  vmovaps [rsp], xmm0
0000762f89bd2cbb  vmovaps [rsp+0x10], xmm1
0000762f89bd2cc1  vmovaps [rsp+0x20], xmm2
0000762f89bd2cc7  vmovaps [rsp+0x30], xmm3
0000762f89bd2ccd  vmovaps [rsp+0x40], xmm4
0000762f89bd2cd3  vmovaps [rsp+0x50], xmm5
0000762f89bd2cd9  vmovaps [rsp+0x60], xmm6
0000762f89bd2cdf  vmovaps [rsp+0x70], xmm7
0000762f89bd2ce5  vmovaps [rsp+0x80], xmm8
0000762f89bd2cee  vmovaps [rsp+0x90], xmm9
0000762f89bd2cf7  vmovaps [rsp+0xA0], xmm10
0000762f89bd2d00  vmovaps [rsp+0xB0], xmm11
0000762f89bd2d09  vmovaps [rsp+0xC0], xmm12
0000762f89bd2d12  vmovaps [rsp+0xD0], xmm14
0000762f89bd2d1b  vmovaps [rsp+0xE0], xmm15
0000762f89bd2d24  sub rsp, 0x30
0000762f89bd2d28  movaps [rsp], xmm13
0000762f89bd2d2d  movaps [rsp+0x10], xmm10
0000762f89bd2d33  movaps [rsp+0x20], xmm1
0000762f89bd2d38  lea rdi, [rsp]
0000762f89bd2d3c  mov esi, 0x00
0000762f89bd2d41  mov rax, 0x604D6F946530
0000762f89bd2d4b  call rax
0000762f89bd2d4d  movaps xmm13, [rsp]
0000762f89bd2d52  add rsp, 0x30
0000762f89bd2d56  vmovaps xmm0, [rsp]
0000762f89bd2d5b  vmovaps xmm1, [rsp+0x10]
0000762f89bd2d61  vmovaps xmm2, [rsp+0x20]
0000762f89bd2d67  vmovaps xmm3, [rsp+0x30]
0000762f89bd2d6d  vmovaps xmm4, [rsp+0x40]
0000762f89bd2d73  vmovaps xmm5, [rsp+0x50]
0000762f89bd2d79  vmovaps xmm6, [rsp+0x60]
0000762f89bd2d7f  vmovaps xmm7, [rsp+0x70]
0000762f89bd2d85  vmovaps xmm8, [rsp+0x80]
0000762f89bd2d8e  vmovaps xmm9, [rsp+0x90]
0000762f89bd2d97  vmovaps xmm10, [rsp+0xA0]
0000762f89bd2da0  vmovaps xmm11, [rsp+0xB0]
0000762f89bd2da9  vmovaps xmm12, [rsp+0xC0]
0000762f89bd2db2  vmovaps xmm14, [rsp+0xD0]
0000762f89bd2dbb  vmovaps xmm15, [rsp+0xE0]
0000762f89bd2dc4  add rsp, 0xF0
0000762f89bd2dcb  pop r11
0000762f89bd2dcd  pop r10
0000762f89bd2dcf  pop r9
0000762f89bd2dd1  pop r8
0000762f89bd2dd3  pop rsi
0000762f89bd2dd4  pop rdi
0000762f89bd2dd5  pop rdx
0000762f89bd2dd6  pop rcx
0000762f89bd2dd7  pop rax
0000762f89bd2dd8  add rsp, 0x08
0000762f89bd2ddc  jmp 0x0000762F89BCFE15
0000762f89bd2de1  sub rsp, 0x08
0000762f89bd2de5  push rax
0000762f89bd2de6  push rcx
0000762f89bd2de7  push rdx
0000762f89bd2de8  push rdi
0000762f89bd2de9  push rsi
0000762f89bd2dea  push r8
0000762f89bd2dec  push r9
0000762f89bd2dee  push r10
0000762f89bd2df0  push r11
0000762f89bd2df2  sub rsp, 0xF0
0000762f89bd2df9  vmovaps [rsp], xmm0
0000762f89bd2dfe  vmovaps [rsp+0x10], xmm2
0000762f89bd2e04  vmovaps [rsp+0x20], xmm3
0000762f89bd2e0a  vmovaps [rsp+0x30], xmm4
0000762f89bd2e10  vmovaps [rsp+0x40], xmm5
0000762f89bd2e16  vmovaps [rsp+0x50], xmm6
0000762f89bd2e1c  vmovaps [rsp+0x60], xmm7
0000762f89bd2e22  vmovaps [rsp+0x70], xmm8
0000762f89bd2e28  vmovaps [rsp+0x80], xmm9
0000762f89bd2e31  vmovaps [rsp+0x90], xmm10
0000762f89bd2e3a  vmovaps [rsp+0xA0], xmm11
0000762f89bd2e43  vmovaps [rsp+0xB0], xmm12
0000762f89bd2e4c  vmovaps [rsp+0xC0], xmm13
0000762f89bd2e55  vmovaps [rsp+0xD0], xmm14
0000762f89bd2e5e  vmovaps [rsp+0xE0], xmm15
0000762f89bd2e67  sub rsp, 0x30
0000762f89bd2e6b  movaps [rsp], xmm1
0000762f89bd2e6f  movaps [rsp+0x10], xmm15
0000762f89bd2e75  movaps [rsp+0x20], xmm10
0000762f89bd2e7b  lea rdi, [rsp]
0000762f89bd2e7f  mov esi, 0x00
0000762f89bd2e84  mov rax, 0x604D6F946530
0000762f89bd2e8e  call rax
0000762f89bd2e90  movaps xmm1, [rsp]
0000762f89bd2e94  add rsp, 0x30
0000762f89bd2e98  vmovaps xmm0, [rsp]
0000762f89bd2e9d  vmovaps xmm2, [rsp+0x10]
0000762f89bd2ea3  vmovaps xmm3, [rsp+0x20]
0000762f89bd2ea9  vmovaps xmm4, [rsp+0x30]
0000762f89bd2eaf  vmovaps xmm5, [rsp+0x40]
0000762f89bd2eb5  vmovaps xmm6, [rsp+0x50]
0000762f89bd2ebb  vmovaps xmm7, [rsp+0x60]
0000762f89bd2ec1  vmovaps xmm8, [rsp+0x70]
0000762f89bd2ec7  vmovaps xmm9, [rsp+0x80]
0000762f89bd2ed0  vmovaps xmm10, [rsp+0x90]
0000762f89bd2ed9  vmovaps xmm11, [rsp+0xA0]
0000762f89bd2ee2  vmovaps xmm12, [rsp+0xB0]
0000762f89bd2eeb  vmovaps xmm13, [rsp+0xC0]
0000762f89bd2ef4  vmovaps xmm14, [rsp+0xD0]
0000762f89bd2efd  vmovaps xmm15, [rsp+0xE0]
0000762f89bd2f06  add rsp, 0xF0
0000762f89bd2f0d  pop r11
0000762f89bd2f0f  pop r10
0000762f89bd2f11  pop r9
0000762f89bd2f13  pop r8
0000762f89bd2f15  pop rsi
0000762f89bd2f16  pop rdi
0000762f89bd2f17  pop rdx
0000762f89bd2f18  pop rcx
0000762f89bd2f19  pop rax
0000762f89bd2f1a  add rsp, 0x08
0000762f89bd2f1e  jmp 0x0000762F89BCFE34
0000762f89bd2f23  sub rsp, 0x08
0000762f89bd2f27  push rax
0000762f89bd2f28  push rcx
0000762f89bd2f29  push rdx
0000762f89bd2f2a  push rdi
0000762f89bd2f2b  push rsi
0000762f89bd2f2c  push r8
0000762f89bd2f2e  push r9
0000762f89bd2f30  push r10
0000762f89bd2f32  push r11
0000762f89bd2f34  sub rsp, 0xF0
0000762f89bd2f3b  vmovaps [rsp], xmm0
0000762f89bd2f40  vmovaps [rsp+0x10], xmm1
0000762f89bd2f46  vmovaps [rsp+0x20], xmm2
0000762f89bd2f4c  vmovaps [rsp+0x30], xmm3
0000762f89bd2f52  vmovaps [rsp+0x40], xmm4
0000762f89bd2f58  vmovaps [rsp+0x50], xmm5
0000762f89bd2f5e  vmovaps [rsp+0x60], xmm6
0000762f89bd2f64  vmovaps [rsp+0x70], xmm7
0000762f89bd2f6a  vmovaps [rsp+0x80], xmm8
0000762f89bd2f73  vmovaps [rsp+0x90], xmm9
0000762f89bd2f7c  vmovaps [rsp+0xA0], xmm10
0000762f89bd2f85  vmovaps [rsp+0xB0], xmm11
0000762f89bd2f8e  vmovaps [rsp+0xC0], xmm12
0000762f89bd2f97  vmovaps [rsp+0xD0], xmm13
0000762f89bd2fa0  vmovaps [rsp+0xE0], xmm14
0000762f89bd2fa9  sub rsp, 0x30
0000762f89bd2fad  movaps [rsp], xmm15
0000762f89bd2fb2  movaps [rsp+0x10], xmm10
0000762f89bd2fb8  movaps [rsp+0x20], xmm11
0000762f89bd2fbe  lea rdi, [rsp]
0000762f89bd2fc2  mov esi, 0x00
0000762f89bd2fc7  mov rax, 0x604D6F946530
0000762f89bd2fd1  call rax
0000762f89bd2fd3  movaps xmm15, [rsp]
0000762f89bd2fd8  add rsp, 0x30
0000762f89bd2fdc  vmovaps xmm0, [rsp]
0000762f89bd2fe1  vmovaps xmm1, [rsp+0x10]
0000762f89bd2fe7  vmovaps xmm2, [rsp+0x20]
0000762f89bd2fed  vmovaps xmm3, [rsp+0x30]
0000762f89bd2ff3  vmovaps xmm4, [rsp+0x40]
0000762f89bd2ff9  vmovaps xmm5, [rsp+0x50]
0000762f89bd2fff  vmovaps xmm6, [rsp+0x60]
0000762f89bd3005  vmovaps xmm7, [rsp+0x70]
0000762f89bd300b  vmovaps xmm8, [rsp+0x80]
0000762f89bd3014  vmovaps xmm9, [rsp+0x90]
0000762f89bd301d  vmovaps xmm10, [rsp+0xA0]
0000762f89bd3026  vmovaps xmm11, [rsp+0xB0]
0000762f89bd302f  vmovaps xmm12, [rsp+0xC0]
0000762f89bd3038  vmovaps xmm13, [rsp+0xD0]
0000762f89bd3041  vmovaps xmm14, [rsp+0xE0]
0000762f89bd304a  add rsp, 0xF0
0000762f89bd3051  pop r11
0000762f89bd3053  pop r10
0000762f89bd3055  pop r9
0000762f89bd3057  pop r8
0000762f89bd3059  pop rsi
0000762f89bd305a  pop rdi
0000762f89bd305b  pop rdx
0000762f89bd305c  pop rcx
0000762f89bd305d  pop rax
0000762f89bd305e  add rsp, 0x08
0000762f89bd3062  jmp 0x0000762F89BCFE57
0000762f89bd3067  sub rsp, 0x08
0000762f89bd306b  push rax
0000762f89bd306c  push rcx
0000762f89bd306d  push rdx
0000762f89bd306e  push rdi
0000762f89bd306f  push rsi
0000762f89bd3070  push r8
0000762f89bd3072  push r9
0000762f89bd3074  push r10
0000762f89bd3076  push r11
0000762f89bd3078  sub rsp, 0xF0
0000762f89bd307f  vmovaps [rsp], xmm0
0000762f89bd3084  vmovaps [rsp+0x10], xmm1
0000762f89bd308a  vmovaps [rsp+0x20], xmm2
0000762f89bd3090  vmovaps [rsp+0x30], xmm3
0000762f89bd3096  vmovaps [rsp+0x40], xmm4
0000762f89bd309c  vmovaps [rsp+0x50], xmm5
0000762f89bd30a2  vmovaps [rsp+0x60], xmm6
0000762f89bd30a8  vmovaps [rsp+0x70], xmm7
0000762f89bd30ae  vmovaps [rsp+0x80], xmm8
0000762f89bd30b7  vmovaps [rsp+0x90], xmm9
0000762f89bd30c0  vmovaps [rsp+0xA0], xmm11
0000762f89bd30c9  vmovaps [rsp+0xB0], xmm12
0000762f89bd30d2  vmovaps [rsp+0xC0], xmm13
0000762f89bd30db  vmovaps [rsp+0xD0], xmm14
0000762f89bd30e4  vmovaps [rsp+0xE0], xmm15
0000762f89bd30ed  sub rsp, 0x30
0000762f89bd30f1  movaps [rsp], xmm10
0000762f89bd30f6  movaps [rsp+0x10], xmm12
0000762f89bd30fc  movaps [rsp+0x20], xmm11
0000762f89bd3102  lea rdi, [rsp]
0000762f89bd3106  mov esi, 0x00
0000762f89bd310b  mov rax, 0x604D6F946530
0000762f89bd3115  call rax
0000762f89bd3117  movaps xmm10, [rsp]
0000762f89bd311c  add rsp, 0x30
0000762f89bd3120  vmovaps xmm0, [rsp]
0000762f89bd3125  vmovaps xmm1, [rsp+0x10]
0000762f89bd312b  vmovaps xmm2, [rsp+0x20]
0000762f89bd3131  vmovaps xmm3, [rsp+0x30]
0000762f89bd3137  vmovaps xmm4, [rsp+0x40]
0000762f89bd313d  vmovaps xmm5, [rsp+0x50]
0000762f89bd3143  vmovaps xmm6, [rsp+0x60]
0000762f89bd3149  vmovaps xmm7, [rsp+0x70]
0000762f89bd314f  vmovaps xmm8, [rsp+0x80]
0000762f89bd3158  vmovaps xmm9, [rsp+0x90]
0000762f89bd3161  vmovaps xmm11, [rsp+0xA0]
0000762f89bd316a  vmovaps xmm12, [rsp+0xB0]
0000762f89bd3173  vmovaps xmm13, [rsp+0xC0]
0000762f89bd317c  vmovaps xmm14, [rsp+0xD0]
0000762f89bd3185  vmovaps xmm15, [rsp+0xE0]
0000762f89bd318e  add rsp, 0xF0
0000762f89bd3195  pop r11
0000762f89bd3197  pop r10
0000762f89bd3199  pop r9
0000762f89bd319b  pop r8
0000762f89bd319d  pop rsi
0000762f89bd319e  pop rdi
0000762f89bd319f  pop rdx
0000762f89bd31a0  pop rcx
0000762f89bd31a1  pop rax
0000762f89bd31a2  add rsp, 0x08
0000762f89bd31a6  jmp 0x0000762F89BCFE80
0000762f89bd31ab  sub rsp, 0x08
0000762f89bd31af  push rax
0000762f89bd31b0  push rcx
0000762f89bd31b1  push rdx
0000762f89bd31b2  push rdi
0000762f89bd31b3  push rsi
0000762f89bd31b4  push r8
0000762f89bd31b6  push r9
0000762f89bd31b8  push r10
0000762f89bd31ba  push r11
0000762f89bd31bc  sub rsp, 0xF0
0000762f89bd31c3  vmovaps [rsp], xmm0
0000762f89bd31c8  vmovaps [rsp+0x10], xmm1
0000762f89bd31ce  vmovaps [rsp+0x20], xmm2
0000762f89bd31d4  vmovaps [rsp+0x30], xmm3
0000762f89bd31da  vmovaps [rsp+0x40], xmm4
0000762f89bd31e0  vmovaps [rsp+0x50], xmm5
0000762f89bd31e6  vmovaps [rsp+0x60], xmm6
0000762f89bd31ec  vmovaps [rsp+0x70], xmm7
0000762f89bd31f2  vmovaps [rsp+0x80], xmm8
0000762f89bd31fb  vmovaps [rsp+0x90], xmm9
0000762f89bd3204  vmovaps [rsp+0xA0], xmm10
0000762f89bd320d  vmovaps [rsp+0xB0], xmm12
0000762f89bd3216  vmovaps [rsp+0xC0], xmm13
0000762f89bd321f  vmovaps [rsp+0xD0], xmm14
0000762f89bd3228  vmovaps [rsp+0xE0], xmm15
0000762f89bd3231  sub rsp, 0x30
0000762f89bd3235  movaps [rsp], xmm11
0000762f89bd323a  movaps [rsp+0x10], xmm2
0000762f89bd323f  movaps [rsp+0x20], xmm12
0000762f89bd3245  lea rdi, [rsp]
0000762f89bd3249  mov esi, 0x00
0000762f89bd324e  mov rax, 0x604D6F946530
0000762f89bd3258  call rax
0000762f89bd325a  movaps xmm11, [rsp]
0000762f89bd325f  add rsp, 0x30
0000762f89bd3263  vmovaps xmm0, [rsp]
0000762f89bd3268  vmovaps xmm1, [rsp+0x10]
0000762f89bd326e  vmovaps xmm2, [rsp+0x20]
0000762f89bd3274  vmovaps xmm3, [rsp+0x30]
0000762f89bd327a  vmovaps xmm4, [rsp+0x40]
0000762f89bd3280  vmovaps xmm5, [rsp+0x50]
0000762f89bd3286  vmovaps xmm6, [rsp+0x60]
0000762f89bd328c  vmovaps xmm7, [rsp+0x70]
0000762f89bd3292  vmovaps xmm8, [rsp+0x80]
0000762f89bd329b  vmovaps xmm9, [rsp+0x90]
0000762f89bd32a4  vmovaps xmm10, [rsp+0xA0]
0000762f89bd32ad  vmovaps xmm12, [rsp+0xB0]
0000762f89bd32b6  vmovaps xmm13, [rsp+0xC0]
0000762f89bd32bf  vmovaps xmm14, [rsp+0xD0]
0000762f89bd32c8  vmovaps xmm15, [rsp+0xE0]
0000762f89bd32d1  add rsp, 0xF0
0000762f89bd32d8  pop r11
0000762f89bd32da  pop r10
0000762f89bd32dc  pop r9
0000762f89bd32de  pop r8
0000762f89bd32e0  pop rsi
0000762f89bd32e1  pop rdi
0000762f89bd32e2  pop rdx
0000762f89bd32e3  pop rcx
0000762f89bd32e4  pop rax
0000762f89bd32e5  add rsp, 0x08
0000762f89bd32e9  jmp 0x0000762F89BCFEB8
0000762f89bd32ee  sub rsp, 0x08
0000762f89bd32f2  push rax
0000762f89bd32f3  push rcx
0000762f89bd32f4  push rdx
0000762f89bd32f5  push rdi
0000762f89bd32f6  push rsi
0000762f89bd32f7  push r8
0000762f89bd32f9  push r9
0000762f89bd32fb  push r10
0000762f89bd32fd  push r11
0000762f89bd32ff  sub rsp, 0xF0
0000762f89bd3306  vmovaps [rsp], xmm0
0000762f89bd330b  vmovaps [rsp+0x10], xmm2
0000762f89bd3311  vmovaps [rsp+0x20], xmm3
0000762f89bd3317  vmovaps [rsp+0x30], xmm4
0000762f89bd331d  vmovaps [rsp+0x40], xmm5
0000762f89bd3323  vmovaps [rsp+0x50], xmm6
0000762f89bd3329  vmovaps [rsp+0x60], xmm7
0000762f89bd332f  vmovaps [rsp+0x70], xmm8
0000762f89bd3335  vmovaps [rsp+0x80], xmm9
0000762f89bd333e  vmovaps [rsp+0x90], xmm10
0000762f89bd3347  vmovaps [rsp+0xA0], xmm11
0000762f89bd3350  vmovaps [rsp+0xB0], xmm12
0000762f89bd3359  vmovaps [rsp+0xC0], xmm13
0000762f89bd3362  vmovaps [rsp+0xD0], xmm14
0000762f89bd336b  vmovaps [rsp+0xE0], xmm15
0000762f89bd3374  sub rsp, 0x30
0000762f89bd3378  movaps [rsp], xmm1
0000762f89bd337c  movaps [rsp+0x10], xmm14
0000762f89bd3382  movaps [rsp+0x20], xmm6
0000762f89bd3387  lea rdi, [rsp]
0000762f89bd338b  mov esi, 0x00
0000762f89bd3390  mov rax, 0x604D6F946530
0000762f89bd339a  call rax
0000762f89bd339c  movaps xmm1, [rsp]
0000762f89bd33a0  add rsp, 0x30
0000762f89bd33a4  vmovaps xmm0, [rsp]
0000762f89bd33a9  vmovaps xmm2, [rsp+0x10]
0000762f89bd33af  vmovaps xmm3, [rsp+0x20]
0000762f89bd33b5  vmovaps xmm4, [rsp+0x30]
0000762f89bd33bb  vmovaps xmm5, [rsp+0x40]
0000762f89bd33c1  vmovaps xmm6, [rsp+0x50]
0000762f89bd33c7  vmovaps xmm7, [rsp+0x60]
0000762f89bd33cd  vmovaps xmm8, [rsp+0x70]
0000762f89bd33d3  vmovaps xmm9, [rsp+0x80]
0000762f89bd33dc  vmovaps xmm10, [rsp+0x90]
0000762f89bd33e5  vmovaps xmm11, [rsp+0xA0]
0000762f89bd33ee  vmovaps xmm12, [rsp+0xB0]
0000762f89bd33f7  vmovaps xmm13, [rsp+0xC0]
0000762f89bd3400  vmovaps xmm14, [rsp+0xD0]
0000762f89bd3409  vmovaps xmm15, [rsp+0xE0]
0000762f89bd3412  add rsp, 0xF0
0000762f89bd3419  pop r11
0000762f89bd341b  pop r10
0000762f89bd341d  pop r9
0000762f89bd341f  pop r8
0000762f89bd3421  pop rsi
0000762f89bd3422  pop rdi
0000762f89bd3423  pop rdx
0000762f89bd3424  pop rcx
0000762f89bd3425  pop rax
0000762f89bd3426  add rsp, 0x08
0000762f89bd342a  jmp 0x0000762F89BCFED1
0000762f89bd342f  sub rsp, 0x08
0000762f89bd3433  push rax
0000762f89bd3434  push rcx
0000762f89bd3435  push rdx
0000762f89bd3436  push rdi
0000762f89bd3437  push rsi
0000762f89bd3438  push r8
0000762f89bd343a  push r9
0000762f89bd343c  push r10
0000762f89bd343e  push r11
0000762f89bd3440  sub rsp, 0xF0
0000762f89bd3447  vmovaps [rsp], xmm0
0000762f89bd344c  vmovaps [rsp+0x10], xmm1
0000762f89bd3452  vmovaps [rsp+0x20], xmm2
0000762f89bd3458  vmovaps [rsp+0x30], xmm3
0000762f89bd345e  vmovaps [rsp+0x40], xmm4
0000762f89bd3464  vmovaps [rsp+0x50], xmm5
0000762f89bd346a  vmovaps [rsp+0x60], xmm6
0000762f89bd3470  vmovaps [rsp+0x70], xmm7
0000762f89bd3476  vmovaps [rsp+0x80], xmm8
0000762f89bd347f  vmovaps [rsp+0x90], xmm9
0000762f89bd3488  vmovaps [rsp+0xA0], xmm10
0000762f89bd3491  vmovaps [rsp+0xB0], xmm11
0000762f89bd349a  vmovaps [rsp+0xC0], xmm12
0000762f89bd34a3  vmovaps [rsp+0xD0], xmm13
0000762f89bd34ac  vmovaps [rsp+0xE0], xmm15
0000762f89bd34b5  sub rsp, 0x30
0000762f89bd34b9  movaps [rsp], xmm14
0000762f89bd34be  movaps [rsp+0x10], xmm12
0000762f89bd34c4  movaps [rsp+0x20], xmm5
0000762f89bd34c9  lea rdi, [rsp]
0000762f89bd34cd  mov esi, 0x00
0000762f89bd34d2  mov rax, 0x604D6F946530
0000762f89bd34dc  call rax
0000762f89bd34de  movaps xmm14, [rsp]
0000762f89bd34e3  add rsp, 0x30
0000762f89bd34e7  vmovaps xmm0, [rsp]
0000762f89bd34ec  vmovaps xmm1, [rsp+0x10]
0000762f89bd34f2  vmovaps xmm2, [rsp+0x20]
0000762f89bd34f8  vmovaps xmm3, [rsp+0x30]
0000762f89bd34fe  vmovaps xmm4, [rsp+0x40]
0000762f89bd3504  vmovaps xmm5, [rsp+0x50]
0000762f89bd350a  vmovaps xmm6, [rsp+0x60]
0000762f89bd3510  vmovaps xmm7, [rsp+0x70]
0000762f89bd3516  vmovaps xmm8, [rsp+0x80]
0000762f89bd351f  vmovaps xmm9, [rsp+0x90]
0000762f89bd3528  vmovaps xmm10, [rsp+0xA0]
0000762f89bd3531  vmovaps xmm11, [rsp+0xB0]
0000762f89bd353a  vmovaps xmm12, [rsp+0xC0]
0000762f89bd3543  vmovaps xmm13, [rsp+0xD0]
0000762f89bd354c  vmovaps xmm15, [rsp+0xE0]
0000762f89bd3555  add rsp, 0xF0
0000762f89bd355c  pop r11
0000762f89bd355e  pop r10
0000762f89bd3560  pop r9
0000762f89bd3562  pop r8
0000762f89bd3564  pop rsi
0000762f89bd3565  pop rdi
0000762f89bd3566  pop rdx
0000762f89bd3567  pop rcx
0000762f89bd3568  pop rax
0000762f89bd3569  add rsp, 0x08
0000762f89bd356d  jmp 0x0000762F89BCFEF1
0000762f89bd3572  sub rsp, 0x08
0000762f89bd3576  push rax
0000762f89bd3577  push rcx
0000762f89bd3578  push rdx
0000762f89bd3579  push rdi
0000762f89bd357a  push rsi
0000762f89bd357b  push r8
0000762f89bd357d  push r9
0000762f89bd357f  push r10
0000762f89bd3581  push r11
0000762f89bd3583  sub rsp, 0xF0
0000762f89bd358a  vmovaps [rsp], xmm0
0000762f89bd358f  vmovaps [rsp+0x10], xmm1
0000762f89bd3595  vmovaps [rsp+0x20], xmm2
0000762f89bd359b  vmovaps [rsp+0x30], xmm3
0000762f89bd35a1  vmovaps [rsp+0x40], xmm4
0000762f89bd35a7  vmovaps [rsp+0x50], xmm5
0000762f89bd35ad  vmovaps [rsp+0x60], xmm7
0000762f89bd35b3  vmovaps [rsp+0x70], xmm8
0000762f89bd35b9  vmovaps [rsp+0x80], xmm9
0000762f89bd35c2  vmovaps [rsp+0x90], xmm10
0000762f89bd35cb  vmovaps [rsp+0xA0], xmm11
0000762f89bd35d4  vmovaps [rsp+0xB0], xmm12
0000762f89bd35dd  vmovaps [rsp+0xC0], xmm13
0000762f89bd35e6  vmovaps [rsp+0xD0], xmm14
0000762f89bd35ef  vmovaps [rsp+0xE0], xmm15
0000762f89bd35f8  sub rsp, 0x30
0000762f89bd35fc  movaps [rsp], xmm6
0000762f89bd3600  movaps [rsp+0x10], xmm9
0000762f89bd3606  movaps [rsp+0x20], xmm12
0000762f89bd360c  lea rdi, [rsp]
0000762f89bd3610  mov esi, 0x00
0000762f89bd3615  mov rax, 0x604D6F946530
0000762f89bd361f  call rax
0000762f89bd3621  movaps xmm6, [rsp]
0000762f89bd3625  add rsp, 0x30
0000762f89bd3629  vmovaps xmm0, [rsp]
0000762f89bd362e  vmovaps xmm1, [rsp+0x10]
0000762f89bd3634  vmovaps xmm2, [rsp+0x20]
0000762f89bd363a  vmovaps xmm3, [rsp+0x30]
0000762f89bd3640  vmovaps xmm4, [rsp+0x40]
0000762f89bd3646  vmovaps xmm5, [rsp+0x50]
0000762f89bd364c  vmovaps xmm7, [rsp+0x60]
0000762f89bd3652  vmovaps xmm8, [rsp+0x70]
0000762f89bd3658  vmovaps xmm9, [rsp+0x80]
0000762f89bd3661  vmovaps xmm10, [rsp+0x90]
0000762f89bd366a  vmovaps xmm11, [rsp+0xA0]
0000762f89bd3673  vmovaps xmm12, [rsp+0xB0]
0000762f89bd367c  vmovaps xmm13, [rsp+0xC0]
0000762f89bd3685  vmovaps xmm14, [rsp+0xD0]
0000762f89bd368e  vmovaps xmm15, [rsp+0xE0]
0000762f89bd3697  add rsp, 0xF0
0000762f89bd369e  pop r11
0000762f89bd36a0  pop r10
0000762f89bd36a2  pop r9
0000762f89bd36a4  pop r8
0000762f89bd36a6  pop rsi
0000762f89bd36a7  pop rdi
0000762f89bd36a8  pop rdx
0000762f89bd36a9  pop rcx
0000762f89bd36aa  pop rax
0000762f89bd36ab  add rsp, 0x08
0000762f89bd36af  jmp 0x0000762F89BCFF19
0000762f89bd36b4  sub rsp, 0x08
0000762f89bd36b8  push rax
0000762f89bd36b9  push rcx
0000762f89bd36ba  push rdx
0000762f89bd36bb  push rdi
0000762f89bd36bc  push rsi
0000762f89bd36bd  push r8
0000762f89bd36bf  push r9
0000762f89bd36c1  push r10
0000762f89bd36c3  push r11
0000762f89bd36c5  sub rsp, 0xF0
0000762f89bd36cc  vmovaps [rsp], xmm0
0000762f89bd36d1  vmovaps [rsp+0x10], xmm1
0000762f89bd36d7  vmovaps [rsp+0x20], xmm2
0000762f89bd36dd  vmovaps [rsp+0x30], xmm3
0000762f89bd36e3  vmovaps [rsp+0x40], xmm4
0000762f89bd36e9  vmovaps [rsp+0x50], xmm5
0000762f89bd36ef  vmovaps [rsp+0x60], xmm6
0000762f89bd36f5  vmovaps [rsp+0x70], xmm7
0000762f89bd36fb  vmovaps [rsp+0x80], xmm8
0000762f89bd3704  vmovaps [rsp+0x90], xmm9
0000762f89bd370d  vmovaps [rsp+0xA0], xmm10
0000762f89bd3716  vmovaps [rsp+0xB0], xmm11
0000762f89bd371f  vmovaps [rsp+0xC0], xmm13
0000762f89bd3728  vmovaps [rsp+0xD0], xmm14
0000762f89bd3731  vmovaps [rsp+0xE0], xmm15
0000762f89bd373a  sub rsp, 0x30
0000762f89bd373e  movaps [rsp], xmm12
0000762f89bd3743  movaps [rsp+0x10], xmm15
0000762f89bd3749  movaps [rsp+0x20], xmm13
0000762f89bd374f  lea rdi, [rsp]
0000762f89bd3753  mov esi, 0x00
0000762f89bd3758  mov rax, 0x604D6F946530
0000762f89bd3762  call rax
0000762f89bd3764  movaps xmm12, [rsp]
0000762f89bd3769  add rsp, 0x30
0000762f89bd376d  vmovaps xmm0, [rsp]
0000762f89bd3772  vmovaps xmm1, [rsp+0x10]
0000762f89bd3778  vmovaps xmm2, [rsp+0x20]
0000762f89bd377e  vmovaps xmm3, [rsp+0x30]
0000762f89bd3784  vmovaps xmm4, [rsp+0x40]
0000762f89bd378a  vmovaps xmm5, [rsp+0x50]
0000762f89bd3790  vmovaps xmm6, [rsp+0x60]
0000762f89bd3796  vmovaps xmm7, [rsp+0x70]
0000762f89bd379c  vmovaps xmm8, [rsp+0x80]
0000762f89bd37a5  vmovaps xmm9, [rsp+0x90]
0000762f89bd37ae  vmovaps xmm10, [rsp+0xA0]
0000762f89bd37b7  vmovaps xmm11, [rsp+0xB0]
0000762f89bd37c0  vmovaps xmm13, [rsp+0xC0]
0000762f89bd37c9  vmovaps xmm14, [rsp+0xD0]
0000762f89bd37d2  vmovaps xmm15, [rsp+0xE0]
0000762f89bd37db  add rsp, 0xF0
0000762f89bd37e2  pop r11
0000762f89bd37e4  pop r10
0000762f89bd37e6  pop r9
0000762f89bd37e8  pop r8
0000762f89bd37ea  pop rsi
0000762f89bd37eb  pop rdi
0000762f89bd37ec  pop rdx
0000762f89bd37ed  pop rcx
0000762f89bd37ee  pop rax
0000762f89bd37ef  add rsp, 0x08
0000762f89bd37f3  jmp 0x0000762F89BCFF34
0000762f89bd37f8  sub rsp, 0x08
0000762f89bd37fc  push rax
0000762f89bd37fd  push rcx
0000762f89bd37fe  push rdx
0000762f89bd37ff  push rdi
0000762f89bd3800  push rsi
0000762f89bd3801  push r8
0000762f89bd3803  push r9
0000762f89bd3805  push r10
0000762f89bd3807  push r11
0000762f89bd3809  sub rsp, 0xF0
0000762f89bd3810  vmovaps [rsp], xmm0
0000762f89bd3815  vmovaps [rsp+0x10], xmm1
0000762f89bd381b  vmovaps [rsp+0x20], xmm2
0000762f89bd3821  vmovaps [rsp+0x30], xmm3
0000762f89bd3827  vmovaps [rsp+0x40], xmm4
0000762f89bd382d  vmovaps [rsp+0x50], xmm5
0000762f89bd3833  vmovaps [rsp+0x60], xmm6
0000762f89bd3839  vmovaps [rsp+0x70], xmm7
0000762f89bd383f  vmovaps [rsp+0x80], xmm8
0000762f89bd3848  vmovaps [rsp+0x90], xmm9
0000762f89bd3851  vmovaps [rsp+0xA0], xmm10
0000762f89bd385a  vmovaps [rsp+0xB0], xmm11
0000762f89bd3863  vmovaps [rsp+0xC0], xmm12
0000762f89bd386c  vmovaps [rsp+0xD0], xmm13
0000762f89bd3875  vmovaps [rsp+0xE0], xmm14
0000762f89bd387e  sub rsp, 0x30
0000762f89bd3882  movaps [rsp], xmm15
0000762f89bd3887  movaps [rsp+0x10], xmm13
0000762f89bd388d  movaps [rsp+0x20], xmm10
0000762f89bd3893  lea rdi, [rsp]
0000762f89bd3897  mov esi, 0x00
0000762f89bd389c  mov rax, 0x604D6F946530
0000762f89bd38a6  call rax
0000762f89bd38a8  movaps xmm15, [rsp]
0000762f89bd38ad  add rsp, 0x30
0000762f89bd38b1  vmovaps xmm0, [rsp]
0000762f89bd38b6  vmovaps xmm1, [rsp+0x10]
0000762f89bd38bc  vmovaps xmm2, [rsp+0x20]
0000762f89bd38c2  vmovaps xmm3, [rsp+0x30]
0000762f89bd38c8  vmovaps xmm4, [rsp+0x40]
0000762f89bd38ce  vmovaps xmm5, [rsp+0x50]
0000762f89bd38d4  vmovaps xmm6, [rsp+0x60]
0000762f89bd38da  vmovaps xmm7, [rsp+0x70]
0000762f89bd38e0  vmovaps xmm8, [rsp+0x80]
0000762f89bd38e9  vmovaps xmm9, [rsp+0x90]
0000762f89bd38f2  vmovaps xmm10, [rsp+0xA0]
0000762f89bd38fb  vmovaps xmm11, [rsp+0xB0]
0000762f89bd3904  vmovaps xmm12, [rsp+0xC0]
0000762f89bd390d  vmovaps xmm13, [rsp+0xD0]
0000762f89bd3916  vmovaps xmm14, [rsp+0xE0]
0000762f89bd391f  add rsp, 0xF0
0000762f89bd3926  pop r11
0000762f89bd3928  pop r10
0000762f89bd392a  pop r9
0000762f89bd392c  pop r8
0000762f89bd392e  pop rsi
0000762f89bd392f  pop rdi
0000762f89bd3930  pop rdx
0000762f89bd3931  pop rcx
0000762f89bd3932  pop rax
0000762f89bd3933  add rsp, 0x08
0000762f89bd3937  jmp 0x0000762F89BCFF55
0000762f89bd393c  call 0x0000762F89A0C260
0000762f89bd3941  jmp 0x0000762F89BCFFB0
0000762f89bd3946  sub rsp, 0x08
0000762f89bd394a  push rax
0000762f89bd394b  push rcx
0000762f89bd394c  push rdx
0000762f89bd394d  push rdi
0000762f89bd394e  push rsi
0000762f89bd394f  push r8
0000762f89bd3951  push r9
0000762f89bd3953  push r10
0000762f89bd3955  push r11
0000762f89bd3957  sub rsp, 0xF0
0000762f89bd395e  vmovaps [rsp], xmm0
0000762f89bd3963  vmovaps [rsp+0x10], xmm1
0000762f89bd3969  vmovaps [rsp+0x20], xmm2
0000762f89bd396f  vmovaps [rsp+0x30], xmm3
0000762f89bd3975  vmovaps [rsp+0x40], xmm4
0000762f89bd397b  vmovaps [rsp+0x50], xmm5
0000762f89bd3981  vmovaps [rsp+0x60], xmm6
0000762f89bd3987  vmovaps [rsp+0x70], xmm7
0000762f89bd398d  vmovaps [rsp+0x80], xmm8
0000762f89bd3996  vmovaps [rsp+0x90], xmm10
0000762f89bd399f  vmovaps [rsp+0xA0], xmm11
0000762f89bd39a8  vmovaps [rsp+0xB0], xmm12
0000762f89bd39b1  vmovaps [rsp+0xC0], xmm13
0000762f89bd39ba  vmovaps [rsp+0xD0], xmm14
0000762f89bd39c3  vmovaps [rsp+0xE0], xmm15
0000762f89bd39cc  sub rsp, 0x30
0000762f89bd39d0  movaps [rsp], xmm9
0000762f89bd39d5  movaps [rsp+0x10], xmm8
0000762f89bd39db  movaps [rsp+0x20], xmm10
0000762f89bd39e1  lea rdi, [rsp]
0000762f89bd39e5  mov esi, 0x00
0000762f89bd39ea  mov rax, 0x604D6F946530
0000762f89bd39f4  call rax
0000762f89bd39f6  movaps xmm9, [rsp]
0000762f89bd39fb  add rsp, 0x30
0000762f89bd39ff  vmovaps xmm0, [rsp]
0000762f89bd3a04  vmovaps xmm1, [rsp+0x10]
0000762f89bd3a0a  vmovaps xmm2, [rsp+0x20]
0000762f89bd3a10  vmovaps xmm3, [rsp+0x30]
0000762f89bd3a16  vmovaps xmm4, [rsp+0x40]
0000762f89bd3a1c  vmovaps xmm5, [rsp+0x50]
0000762f89bd3a22  vmovaps xmm6, [rsp+0x60]
0000762f89bd3a28  vmovaps xmm7, [rsp+0x70]
0000762f89bd3a2e  vmovaps xmm8, [rsp+0x80]
0000762f89bd3a37  vmovaps xmm10, [rsp+0x90]
0000762f89bd3a40  vmovaps xmm11, [rsp+0xA0]
0000762f89bd3a49  vmovaps xmm12, [rsp+0xB0]
0000762f89bd3a52  vmovaps xmm13, [rsp+0xC0]
0000762f89bd3a5b  vmovaps xmm14, [rsp+0xD0]
0000762f89bd3a64  vmovaps xmm15, [rsp+0xE0]
0000762f89bd3a6d  add rsp, 0xF0
0000762f89bd3a74  pop r11
0000762f89bd3a76  pop r10
0000762f89bd3a78  pop r9
0000762f89bd3a7a  pop r8
0000762f89bd3a7c  pop rsi
0000762f89bd3a7d  pop rdi
0000762f89bd3a7e  pop rdx
0000762f89bd3a7f  pop rcx
0000762f89bd3a80  pop rax
0000762f89bd3a81  add rsp, 0x08
0000762f89bd3a85  jmp 0x0000762F89BCFFE1
0000762f89bd3a8a  sub rsp, 0x08
0000762f89bd3a8e  push rax
0000762f89bd3a8f  push rcx
0000762f89bd3a90  push rdx
0000762f89bd3a91  push rdi
0000762f89bd3a92  push rsi
0000762f89bd3a93  push r8
0000762f89bd3a95  push r9
0000762f89bd3a97  push r10
0000762f89bd3a99  push r11
0000762f89bd3a9b  sub rsp, 0xF0
0000762f89bd3aa2  vmovaps [rsp], xmm0
0000762f89bd3aa7  vmovaps [rsp+0x10], xmm1
0000762f89bd3aad  vmovaps [rsp+0x20], xmm2
0000762f89bd3ab3  vmovaps [rsp+0x30], xmm3
0000762f89bd3ab9  vmovaps [rsp+0x40], xmm4
0000762f89bd3abf  vmovaps [rsp+0x50], xmm5
0000762f89bd3ac5  vmovaps [rsp+0x60], xmm6
0000762f89bd3acb  vmovaps [rsp+0x70], xmm7
0000762f89bd3ad1  vmovaps [rsp+0x80], xmm8
0000762f89bd3ada  vmovaps [rsp+0x90], xmm9
0000762f89bd3ae3  vmovaps [rsp+0xA0], xmm11
0000762f89bd3aec  vmovaps [rsp+0xB0], xmm12
0000762f89bd3af5  vmovaps [rsp+0xC0], xmm13
0000762f89bd3afe  vmovaps [rsp+0xD0], xmm14
0000762f89bd3b07  vmovaps [rsp+0xE0], xmm15
0000762f89bd3b10  sub rsp, 0x30
0000762f89bd3b14  movaps [rsp], xmm10
0000762f89bd3b19  movaps [rsp+0x10], xmm1
0000762f89bd3b1e  movaps [rsp+0x20], xmm11
0000762f89bd3b24  lea rdi, [rsp]
0000762f89bd3b28  mov esi, 0x00
0000762f89bd3b2d  mov rax, 0x604D6F946530
0000762f89bd3b37  call rax
0000762f89bd3b39  movaps xmm10, [rsp]
0000762f89bd3b3e  add rsp, 0x30
0000762f89bd3b42  vmovaps xmm0, [rsp]
0000762f89bd3b47  vmovaps xmm1, [rsp+0x10]
0000762f89bd3b4d  vmovaps xmm2, [rsp+0x20]
0000762f89bd3b53  vmovaps xmm3, [rsp+0x30]
0000762f89bd3b59  vmovaps xmm4, [rsp+0x40]
0000762f89bd3b5f  vmovaps xmm5, [rsp+0x50]
0000762f89bd3b65  vmovaps xmm6, [rsp+0x60]
0000762f89bd3b6b  vmovaps xmm7, [rsp+0x70]
0000762f89bd3b71  vmovaps xmm8, [rsp+0x80]
0000762f89bd3b7a  vmovaps xmm9, [rsp+0x90]
0000762f89bd3b83  vmovaps xmm11, [rsp+0xA0]
0000762f89bd3b8c  vmovaps xmm12, [rsp+0xB0]
0000762f89bd3b95  vmovaps xmm13, [rsp+0xC0]
0000762f89bd3b9e  vmovaps xmm14, [rsp+0xD0]
0000762f89bd3ba7  vmovaps xmm15, [rsp+0xE0]
0000762f89bd3bb0  add rsp, 0xF0
0000762f89bd3bb7  pop r11
0000762f89bd3bb9  pop r10
0000762f89bd3bbb  pop r9
0000762f89bd3bbd  pop r8
0000762f89bd3bbf  pop rsi
0000762f89bd3bc0  pop rdi
0000762f89bd3bc1  pop rdx
0000762f89bd3bc2  pop rcx
0000762f89bd3bc3  pop rax
0000762f89bd3bc4  add rsp, 0x08
0000762f89bd3bc8  jmp 0x0000762F89BCFFFC
0000762f89bd3bcd  sub rsp, 0x08
0000762f89bd3bd1  push rax
0000762f89bd3bd2  push rcx
0000762f89bd3bd3  push rdx
0000762f89bd3bd4  push rdi
0000762f89bd3bd5  push rsi
0000762f89bd3bd6  push r8
0000762f89bd3bd8  push r9
0000762f89bd3bda  push r10
0000762f89bd3bdc  push r11
0000762f89bd3bde  sub rsp, 0xF0
0000762f89bd3be5  vmovaps [rsp], xmm0
0000762f89bd3bea  vmovaps [rsp+0x10], xmm2
0000762f89bd3bf0  vmovaps [rsp+0x20], xmm3
0000762f89bd3bf6  vmovaps [rsp+0x30], xmm4
0000762f89bd3bfc  vmovaps [rsp+0x40], xmm5
0000762f89bd3c02  vmovaps [rsp+0x50], xmm6
0000762f89bd3c08  vmovaps [rsp+0x60], xmm7
0000762f89bd3c0e  vmovaps [rsp+0x70], xmm8
0000762f89bd3c14  vmovaps [rsp+0x80], xmm9
0000762f89bd3c1d  vmovaps [rsp+0x90], xmm10
0000762f89bd3c26  vmovaps [rsp+0xA0], xmm11
0000762f89bd3c2f  vmovaps [rsp+0xB0], xmm12
0000762f89bd3c38  vmovaps [rsp+0xC0], xmm13
0000762f89bd3c41  vmovaps [rsp+0xD0], xmm14
0000762f89bd3c4a  vmovaps [rsp+0xE0], xmm15
0000762f89bd3c53  sub rsp, 0x30
0000762f89bd3c57  movaps [rsp], xmm1
0000762f89bd3c5b  movaps [rsp+0x10], xmm14
0000762f89bd3c61  movaps [rsp+0x20], xmm6
0000762f89bd3c66  lea rdi, [rsp]
0000762f89bd3c6a  mov esi, 0x00
0000762f89bd3c6f  mov rax, 0x604D6F946530
0000762f89bd3c79  call rax
0000762f89bd3c7b  movaps xmm1, [rsp]
0000762f89bd3c7f  add rsp, 0x30
0000762f89bd3c83  vmovaps xmm0, [rsp]
0000762f89bd3c88  vmovaps xmm2, [rsp+0x10]
0000762f89bd3c8e  vmovaps xmm3, [rsp+0x20]
0000762f89bd3c94  vmovaps xmm4, [rsp+0x30]
0000762f89bd3c9a  vmovaps xmm5, [rsp+0x40]
0000762f89bd3ca0  vmovaps xmm6, [rsp+0x50]
0000762f89bd3ca6  vmovaps xmm7, [rsp+0x60]
0000762f89bd3cac  vmovaps xmm8, [rsp+0x70]
0000762f89bd3cb2  vmovaps xmm9, [rsp+0x80]
0000762f89bd3cbb  vmovaps xmm10, [rsp+0x90]
0000762f89bd3cc4  vmovaps xmm11, [rsp+0xA0]
0000762f89bd3ccd  vmovaps xmm12, [rsp+0xB0]
0000762f89bd3cd6  vmovaps xmm13, [rsp+0xC0]
0000762f89bd3cdf  vmovaps xmm14, [rsp+0xD0]
0000762f89bd3ce8  vmovaps xmm15, [rsp+0xE0]
0000762f89bd3cf1  add rsp, 0xF0
0000762f89bd3cf8  pop r11
0000762f89bd3cfa  pop r10
0000762f89bd3cfc  pop r9
0000762f89bd3cfe  pop r8
0000762f89bd3d00  pop rsi
0000762f89bd3d01  pop rdi
0000762f89bd3d02  pop rdx
0000762f89bd3d03  pop rcx
0000762f89bd3d04  pop rax
0000762f89bd3d05  add rsp, 0x08
0000762f89bd3d09  jmp 0x0000762F89BD0015
0000762f89bd3d0e  sub rsp, 0x08
0000762f89bd3d12  push rax
0000762f89bd3d13  push rcx
0000762f89bd3d14  push rdx
0000762f89bd3d15  push rdi
0000762f89bd3d16  push rsi
0000762f89bd3d17  push r8
0000762f89bd3d19  push r9
0000762f89bd3d1b  push r10
0000762f89bd3d1d  push r11
0000762f89bd3d1f  sub rsp, 0xF0
0000762f89bd3d26  vmovaps [rsp], xmm0
0000762f89bd3d2b  vmovaps [rsp+0x10], xmm1
0000762f89bd3d31  vmovaps [rsp+0x20], xmm2
0000762f89bd3d37  vmovaps [rsp+0x30], xmm3
0000762f89bd3d3d  vmovaps [rsp+0x40], xmm4
0000762f89bd3d43  vmovaps [rsp+0x50], xmm5
0000762f89bd3d49  vmovaps [rsp+0x60], xmm6
0000762f89bd3d4f  vmovaps [rsp+0x70], xmm7
0000762f89bd3d55  vmovaps [rsp+0x80], xmm8
0000762f89bd3d5e  vmovaps [rsp+0x90], xmm9
0000762f89bd3d67  vmovaps [rsp+0xA0], xmm10
0000762f89bd3d70  vmovaps [rsp+0xB0], xmm12
0000762f89bd3d79  vmovaps [rsp+0xC0], xmm13
0000762f89bd3d82  vmovaps [rsp+0xD0], xmm14
0000762f89bd3d8b  vmovaps [rsp+0xE0], xmm15
0000762f89bd3d94  sub rsp, 0x30
0000762f89bd3d98  movaps [rsp], xmm11
0000762f89bd3d9d  movaps [rsp+0x10], xmm13
0000762f89bd3da3  movaps [rsp+0x20], xmm14
0000762f89bd3da9  lea rdi, [rsp]
0000762f89bd3dad  mov esi, 0x00
0000762f89bd3db2  mov rax, 0x604D6F946530
0000762f89bd3dbc  call rax
0000762f89bd3dbe  movaps xmm11, [rsp]
0000762f89bd3dc3  add rsp, 0x30
0000762f89bd3dc7  vmovaps xmm0, [rsp]
0000762f89bd3dcc  vmovaps xmm1, [rsp+0x10]
0000762f89bd3dd2  vmovaps xmm2, [rsp+0x20]
0000762f89bd3dd8  vmovaps xmm3, [rsp+0x30]
0000762f89bd3dde  vmovaps xmm4, [rsp+0x40]
0000762f89bd3de4  vmovaps xmm5, [rsp+0x50]
0000762f89bd3dea  vmovaps xmm6, [rsp+0x60]
0000762f89bd3df0  vmovaps xmm7, [rsp+0x70]
0000762f89bd3df6  vmovaps xmm8, [rsp+0x80]
0000762f89bd3dff  vmovaps xmm9, [rsp+0x90]
0000762f89bd3e08  vmovaps xmm10, [rsp+0xA0]
0000762f89bd3e11  vmovaps xmm12, [rsp+0xB0]
0000762f89bd3e1a  vmovaps xmm13, [rsp+0xC0]
0000762f89bd3e23  vmovaps xmm14, [rsp+0xD0]
0000762f89bd3e2c  vmovaps xmm15, [rsp+0xE0]
0000762f89bd3e35  add rsp, 0xF0
0000762f89bd3e3c  pop r11
0000762f89bd3e3e  pop r10
0000762f89bd3e40  pop r9
0000762f89bd3e42  pop r8
0000762f89bd3e44  pop rsi
0000762f89bd3e45  pop rdi
0000762f89bd3e46  pop rdx
0000762f89bd3e47  pop rcx
0000762f89bd3e48  pop rax
0000762f89bd3e49  add rsp, 0x08
0000762f89bd3e4d  jmp 0x0000762F89BD003F
0000762f89bd3e52  sub rsp, 0x08
0000762f89bd3e56  push rax
0000762f89bd3e57  push rcx
0000762f89bd3e58  push rdx
0000762f89bd3e59  push rdi
0000762f89bd3e5a  push rsi
0000762f89bd3e5b  push r8
0000762f89bd3e5d  push r9
0000762f89bd3e5f  push r10
0000762f89bd3e61  push r11
0000762f89bd3e63  sub rsp, 0xF0
0000762f89bd3e6a  vmovaps [rsp], xmm0
0000762f89bd3e6f  vmovaps [rsp+0x10], xmm1
0000762f89bd3e75  vmovaps [rsp+0x20], xmm2
0000762f89bd3e7b  vmovaps [rsp+0x30], xmm3
0000762f89bd3e81  vmovaps [rsp+0x40], xmm4
0000762f89bd3e87  vmovaps [rsp+0x50], xmm5
0000762f89bd3e8d  vmovaps [rsp+0x60], xmm6
0000762f89bd3e93  vmovaps [rsp+0x70], xmm7
0000762f89bd3e99  vmovaps [rsp+0x80], xmm8
0000762f89bd3ea2  vmovaps [rsp+0x90], xmm9
0000762f89bd3eab  vmovaps [rsp+0xA0], xmm10
0000762f89bd3eb4  vmovaps [rsp+0xB0], xmm11
0000762f89bd3ebd  vmovaps [rsp+0xC0], xmm12
0000762f89bd3ec6  vmovaps [rsp+0xD0], xmm14
0000762f89bd3ecf  vmovaps [rsp+0xE0], xmm15
0000762f89bd3ed8  sub rsp, 0x30
0000762f89bd3edc  movaps [rsp], xmm13
0000762f89bd3ee1  movaps [rsp+0x10], xmm8
0000762f89bd3ee7  movaps [rsp+0x20], xmm14
0000762f89bd3eed  lea rdi, [rsp]
0000762f89bd3ef1  mov esi, 0x00
0000762f89bd3ef6  mov rax, 0x604D6F946530
0000762f89bd3f00  call rax
0000762f89bd3f02  movaps xmm13, [rsp]
0000762f89bd3f07  add rsp, 0x30
0000762f89bd3f0b  vmovaps xmm0, [rsp]
0000762f89bd3f10  vmovaps xmm1, [rsp+0x10]
0000762f89bd3f16  vmovaps xmm2, [rsp+0x20]
0000762f89bd3f1c  vmovaps xmm3, [rsp+0x30]
0000762f89bd3f22  vmovaps xmm4, [rsp+0x40]
0000762f89bd3f28  vmovaps xmm5, [rsp+0x50]
0000762f89bd3f2e  vmovaps xmm6, [rsp+0x60]
0000762f89bd3f34  vmovaps xmm7, [rsp+0x70]
0000762f89bd3f3a  vmovaps xmm8, [rsp+0x80]
0000762f89bd3f43  vmovaps xmm9, [rsp+0x90]
0000762f89bd3f4c  vmovaps xmm10, [rsp+0xA0]
0000762f89bd3f55  vmovaps xmm11, [rsp+0xB0]
0000762f89bd3f5e  vmovaps xmm12, [rsp+0xC0]
0000762f89bd3f67  vmovaps xmm14, [rsp+0xD0]
0000762f89bd3f70  vmovaps xmm15, [rsp+0xE0]
0000762f89bd3f79  add rsp, 0xF0
0000762f89bd3f80  pop r11
0000762f89bd3f82  pop r10
0000762f89bd3f84  pop r9
0000762f89bd3f86  pop r8
0000762f89bd3f88  pop rsi
0000762f89bd3f89  pop rdi
0000762f89bd3f8a  pop rdx
0000762f89bd3f8b  pop rcx
0000762f89bd3f8c  pop rax
0000762f89bd3f8d  add rsp, 0x08
0000762f89bd3f91  jmp 0x0000762F89BD006E
0000762f89bd3f96  sub rsp, 0x08
0000762f89bd3f9a  push rax
0000762f89bd3f9b  push rcx
0000762f89bd3f9c  push rdx
0000762f89bd3f9d  push rdi
0000762f89bd3f9e  push rsi
0000762f89bd3f9f  push r8
0000762f89bd3fa1  push r9
0000762f89bd3fa3  push r10
0000762f89bd3fa5  push r11
0000762f89bd3fa7  sub rsp, 0xF0
0000762f89bd3fae  vmovaps [rsp], xmm0
0000762f89bd3fb3  vmovaps [rsp+0x10], xmm1
0000762f89bd3fb9  vmovaps [rsp+0x20], xmm2
0000762f89bd3fbf  vmovaps [rsp+0x30], xmm3
0000762f89bd3fc5  vmovaps [rsp+0x40], xmm4
0000762f89bd3fcb  vmovaps [rsp+0x50], xmm5
0000762f89bd3fd1  vmovaps [rsp+0x60], xmm6
0000762f89bd3fd7  vmovaps [rsp+0x70], xmm7
0000762f89bd3fdd  vmovaps [rsp+0x80], xmm9
0000762f89bd3fe6  vmovaps [rsp+0x90], xmm10
0000762f89bd3fef  vmovaps [rsp+0xA0], xmm11
0000762f89bd3ff8  vmovaps [rsp+0xB0], xmm12
0000762f89bd4001  vmovaps [rsp+0xC0], xmm13
0000762f89bd400a  vmovaps [rsp+0xD0], xmm14
0000762f89bd4013  vmovaps [rsp+0xE0], xmm15
0000762f89bd401c  sub rsp, 0x30
0000762f89bd4020  movaps [rsp], xmm8
0000762f89bd4025  movaps [rsp+0x10], xmm7
0000762f89bd402a  movaps [rsp+0x20], xmm14
0000762f89bd4030  lea rdi, [rsp]
0000762f89bd4034  mov esi, 0x00
0000762f89bd4039  mov rax, 0x604D6F946530
0000762f89bd4043  call rax
0000762f89bd4045  movaps xmm8, [rsp]
0000762f89bd404a  add rsp, 0x30
0000762f89bd404e  vmovaps xmm0, [rsp]
0000762f89bd4053  vmovaps xmm1, [rsp+0x10]
0000762f89bd4059  vmovaps xmm2, [rsp+0x20]
0000762f89bd405f  vmovaps xmm3, [rsp+0x30]
0000762f89bd4065  vmovaps xmm4, [rsp+0x40]
0000762f89bd406b  vmovaps xmm5, [rsp+0x50]
0000762f89bd4071  vmovaps xmm6, [rsp+0x60]
0000762f89bd4077  vmovaps xmm7, [rsp+0x70]
0000762f89bd407d  vmovaps xmm9, [rsp+0x80]
0000762f89bd4086  vmovaps xmm10, [rsp+0x90]
0000762f89bd408f  vmovaps xmm11, [rsp+0xA0]
0000762f89bd4098  vmovaps xmm12, [rsp+0xB0]
0000762f89bd40a1  vmovaps xmm13, [rsp+0xC0]
0000762f89bd40aa  vmovaps xmm14, [rsp+0xD0]
0000762f89bd40b3  vmovaps xmm15, [rsp+0xE0]
0000762f89bd40bc  add rsp, 0xF0
0000762f89bd40c3  pop r11
0000762f89bd40c5  pop r10
0000762f89bd40c7  pop r9
0000762f89bd40c9  pop r8
0000762f89bd40cb  pop rsi
0000762f89bd40cc  pop rdi
0000762f89bd40cd  pop rdx
0000762f89bd40ce  pop rcx
0000762f89bd40cf  pop rax
0000762f89bd40d0  add rsp, 0x08
0000762f89bd40d4  jmp 0x0000762F89BD0094
0000762f89bd40d9  sub rsp, 0x08
0000762f89bd40dd  push rax
0000762f89bd40de  push rcx
0000762f89bd40df  push rdx
0000762f89bd40e0  push rdi
0000762f89bd40e1  push rsi
0000762f89bd40e2  push r8
0000762f89bd40e4  push r9
0000762f89bd40e6  push r10
0000762f89bd40e8  push r11
0000762f89bd40ea  sub rsp, 0xF0
0000762f89bd40f1  vmovaps [rsp], xmm0
0000762f89bd40f6  vmovaps [rsp+0x10], xmm1
0000762f89bd40fc  vmovaps [rsp+0x20], xmm2
0000762f89bd4102  vmovaps [rsp+0x30], xmm3
0000762f89bd4108  vmovaps [rsp+0x40], xmm4
0000762f89bd410e  vmovaps [rsp+0x50], xmm5
0000762f89bd4114  vmovaps [rsp+0x60], xmm6
0000762f89bd411a  vmovaps [rsp+0x70], xmm7
0000762f89bd4120  vmovaps [rsp+0x80], xmm8
0000762f89bd4129  vmovaps [rsp+0x90], xmm9
0000762f89bd4132  vmovaps [rsp+0xA0], xmm10
0000762f89bd413b  vmovaps [rsp+0xB0], xmm11
0000762f89bd4144  vmovaps [rsp+0xC0], xmm12
0000762f89bd414d  vmovaps [rsp+0xD0], xmm13
0000762f89bd4156  vmovaps [rsp+0xE0], xmm15
0000762f89bd415f  sub rsp, 0x30
0000762f89bd4163  movaps [rsp], xmm14
0000762f89bd4168  movaps [rsp+0x10], xmm12
0000762f89bd416e  movaps [rsp+0x20], xmm9
0000762f89bd4174  lea rdi, [rsp]
0000762f89bd4178  mov esi, 0x00
0000762f89bd417d  mov rax, 0x604D6F946530
0000762f89bd4187  call rax
0000762f89bd4189  movaps xmm14, [rsp]
0000762f89bd418e  add rsp, 0x30
0000762f89bd4192  vmovaps xmm0, [rsp]
0000762f89bd4197  vmovaps xmm1, [rsp+0x10]
0000762f89bd419d  vmovaps xmm2, [rsp+0x20]
0000762f89bd41a3  vmovaps xmm3, [rsp+0x30]
0000762f89bd41a9  vmovaps xmm4, [rsp+0x40]
0000762f89bd41af  vmovaps xmm5, [rsp+0x50]
0000762f89bd41b5  vmovaps xmm6, [rsp+0x60]
0000762f89bd41bb  vmovaps xmm7, [rsp+0x70]
0000762f89bd41c1  vmovaps xmm8, [rsp+0x80]
0000762f89bd41ca  vmovaps xmm9, [rsp+0x90]
0000762f89bd41d3  vmovaps xmm10, [rsp+0xA0]
0000762f89bd41dc  vmovaps xmm11, [rsp+0xB0]
0000762f89bd41e5  vmovaps xmm12, [rsp+0xC0]
0000762f89bd41ee  vmovaps xmm13, [rsp+0xD0]
0000762f89bd41f7  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4200  add rsp, 0xF0
0000762f89bd4207  pop r11
0000762f89bd4209  pop r10
0000762f89bd420b  pop r9
0000762f89bd420d  pop r8
0000762f89bd420f  pop rsi
0000762f89bd4210  pop rdi
0000762f89bd4211  pop rdx
0000762f89bd4212  pop rcx
0000762f89bd4213  pop rax
0000762f89bd4214  add rsp, 0x08
0000762f89bd4218  jmp 0x0000762F89BD00AE
0000762f89bd421d  sub rsp, 0x08
0000762f89bd4221  push rax
0000762f89bd4222  push rcx
0000762f89bd4223  push rdx
0000762f89bd4224  push rdi
0000762f89bd4225  push rsi
0000762f89bd4226  push r8
0000762f89bd4228  push r9
0000762f89bd422a  push r10
0000762f89bd422c  push r11
0000762f89bd422e  sub rsp, 0xF0
0000762f89bd4235  vmovaps [rsp], xmm0
0000762f89bd423a  vmovaps [rsp+0x10], xmm1
0000762f89bd4240  vmovaps [rsp+0x20], xmm2
0000762f89bd4246  vmovaps [rsp+0x30], xmm3
0000762f89bd424c  vmovaps [rsp+0x40], xmm4
0000762f89bd4252  vmovaps [rsp+0x50], xmm5
0000762f89bd4258  vmovaps [rsp+0x60], xmm6
0000762f89bd425e  vmovaps [rsp+0x70], xmm7
0000762f89bd4264  vmovaps [rsp+0x80], xmm8
0000762f89bd426d  vmovaps [rsp+0x90], xmm10
0000762f89bd4276  vmovaps [rsp+0xA0], xmm11
0000762f89bd427f  vmovaps [rsp+0xB0], xmm12
0000762f89bd4288  vmovaps [rsp+0xC0], xmm13
0000762f89bd4291  vmovaps [rsp+0xD0], xmm14
0000762f89bd429a  vmovaps [rsp+0xE0], xmm15
0000762f89bd42a3  sub rsp, 0x30
0000762f89bd42a7  movaps [rsp], xmm9
0000762f89bd42ac  movaps [rsp+0x10], xmm7
0000762f89bd42b1  movaps [rsp+0x20], xmm12
0000762f89bd42b7  lea rdi, [rsp]
0000762f89bd42bb  mov esi, 0x00
0000762f89bd42c0  mov rax, 0x604D6F946530
0000762f89bd42ca  call rax
0000762f89bd42cc  movaps xmm9, [rsp]
0000762f89bd42d1  add rsp, 0x30
0000762f89bd42d5  vmovaps xmm0, [rsp]
0000762f89bd42da  vmovaps xmm1, [rsp+0x10]
0000762f89bd42e0  vmovaps xmm2, [rsp+0x20]
0000762f89bd42e6  vmovaps xmm3, [rsp+0x30]
0000762f89bd42ec  vmovaps xmm4, [rsp+0x40]
0000762f89bd42f2  vmovaps xmm5, [rsp+0x50]
0000762f89bd42f8  vmovaps xmm6, [rsp+0x60]
0000762f89bd42fe  vmovaps xmm7, [rsp+0x70]
0000762f89bd4304  vmovaps xmm8, [rsp+0x80]
0000762f89bd430d  vmovaps xmm10, [rsp+0x90]
0000762f89bd4316  vmovaps xmm11, [rsp+0xA0]
0000762f89bd431f  vmovaps xmm12, [rsp+0xB0]
0000762f89bd4328  vmovaps xmm13, [rsp+0xC0]
0000762f89bd4331  vmovaps xmm14, [rsp+0xD0]
0000762f89bd433a  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4343  add rsp, 0xF0
0000762f89bd434a  pop r11
0000762f89bd434c  pop r10
0000762f89bd434e  pop r9
0000762f89bd4350  pop r8
0000762f89bd4352  pop rsi
0000762f89bd4353  pop rdi
0000762f89bd4354  pop rdx
0000762f89bd4355  pop rcx
0000762f89bd4356  pop rax
0000762f89bd4357  add rsp, 0x08
0000762f89bd435b  jmp 0x0000762F89BD00DD
0000762f89bd4360  sub rsp, 0x08
0000762f89bd4364  push rax
0000762f89bd4365  push rcx
0000762f89bd4366  push rdx
0000762f89bd4367  push rdi
0000762f89bd4368  push rsi
0000762f89bd4369  push r8
0000762f89bd436b  push r9
0000762f89bd436d  push r10
0000762f89bd436f  push r11
0000762f89bd4371  sub rsp, 0xF0
0000762f89bd4378  vmovaps [rsp], xmm0
0000762f89bd437d  vmovaps [rsp+0x10], xmm1
0000762f89bd4383  vmovaps [rsp+0x20], xmm2
0000762f89bd4389  vmovaps [rsp+0x30], xmm3
0000762f89bd438f  vmovaps [rsp+0x40], xmm4
0000762f89bd4395  vmovaps [rsp+0x50], xmm5
0000762f89bd439b  vmovaps [rsp+0x60], xmm6
0000762f89bd43a1  vmovaps [rsp+0x70], xmm7
0000762f89bd43a7  vmovaps [rsp+0x80], xmm8
0000762f89bd43b0  vmovaps [rsp+0x90], xmm9
0000762f89bd43b9  vmovaps [rsp+0xA0], xmm10
0000762f89bd43c2  vmovaps [rsp+0xB0], xmm11
0000762f89bd43cb  vmovaps [rsp+0xC0], xmm13
0000762f89bd43d4  vmovaps [rsp+0xD0], xmm14
0000762f89bd43dd  vmovaps [rsp+0xE0], xmm15
0000762f89bd43e6  sub rsp, 0x30
0000762f89bd43ea  movaps [rsp], xmm12
0000762f89bd43ef  movaps [rsp+0x10], xmm15
0000762f89bd43f5  movaps [rsp+0x20], xmm11
0000762f89bd43fb  lea rdi, [rsp]
0000762f89bd43ff  mov esi, 0x00
0000762f89bd4404  mov rax, 0x604D6F946530
0000762f89bd440e  call rax
0000762f89bd4410  movaps xmm12, [rsp]
0000762f89bd4415  add rsp, 0x30
0000762f89bd4419  vmovaps xmm0, [rsp]
0000762f89bd441e  vmovaps xmm1, [rsp+0x10]
0000762f89bd4424  vmovaps xmm2, [rsp+0x20]
0000762f89bd442a  vmovaps xmm3, [rsp+0x30]
0000762f89bd4430  vmovaps xmm4, [rsp+0x40]
0000762f89bd4436  vmovaps xmm5, [rsp+0x50]
0000762f89bd443c  vmovaps xmm6, [rsp+0x60]
0000762f89bd4442  vmovaps xmm7, [rsp+0x70]
0000762f89bd4448  vmovaps xmm8, [rsp+0x80]
0000762f89bd4451  vmovaps xmm9, [rsp+0x90]
0000762f89bd445a  vmovaps xmm10, [rsp+0xA0]
0000762f89bd4463  vmovaps xmm11, [rsp+0xB0]
0000762f89bd446c  vmovaps xmm13, [rsp+0xC0]
0000762f89bd4475  vmovaps xmm14, [rsp+0xD0]
0000762f89bd447e  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4487  add rsp, 0xF0
0000762f89bd448e  pop r11
0000762f89bd4490  pop r10
0000762f89bd4492  pop r9
0000762f89bd4494  pop r8
0000762f89bd4496  pop rsi
0000762f89bd4497  pop rdi
0000762f89bd4498  pop rdx
0000762f89bd4499  pop rcx
0000762f89bd449a  pop rax
0000762f89bd449b  add rsp, 0x08
0000762f89bd449f  jmp 0x0000762F89BD00F7
0000762f89bd44a4  sub rsp, 0x08
0000762f89bd44a8  push rax
0000762f89bd44a9  push rcx
0000762f89bd44aa  push rdx
0000762f89bd44ab  push rdi
0000762f89bd44ac  push rsi
0000762f89bd44ad  push r8
0000762f89bd44af  push r9
0000762f89bd44b1  push r10
0000762f89bd44b3  push r11
0000762f89bd44b5  sub rsp, 0xF0
0000762f89bd44bc  vmovaps [rsp], xmm0
0000762f89bd44c1  vmovaps [rsp+0x10], xmm1
0000762f89bd44c7  vmovaps [rsp+0x20], xmm2
0000762f89bd44cd  vmovaps [rsp+0x30], xmm3
0000762f89bd44d3  vmovaps [rsp+0x40], xmm4
0000762f89bd44d9  vmovaps [rsp+0x50], xmm5
0000762f89bd44df  vmovaps [rsp+0x60], xmm6
0000762f89bd44e5  vmovaps [rsp+0x70], xmm7
0000762f89bd44eb  vmovaps [rsp+0x80], xmm8
0000762f89bd44f4  vmovaps [rsp+0x90], xmm9
0000762f89bd44fd  vmovaps [rsp+0xA0], xmm10
0000762f89bd4506  vmovaps [rsp+0xB0], xmm12
0000762f89bd450f  vmovaps [rsp+0xC0], xmm13
0000762f89bd4518  vmovaps [rsp+0xD0], xmm14
0000762f89bd4521  vmovaps [rsp+0xE0], xmm15
0000762f89bd452a  sub rsp, 0x30
0000762f89bd452e  movaps [rsp], xmm11
0000762f89bd4533  movaps [rsp+0x10], xmm7
0000762f89bd4538  movaps [rsp+0x20], xmm15
0000762f89bd453e  lea rdi, [rsp]
0000762f89bd4542  mov esi, 0x00
0000762f89bd4547  mov rax, 0x604D6F946530
0000762f89bd4551  call rax
0000762f89bd4553  movaps xmm11, [rsp]
0000762f89bd4558  add rsp, 0x30
0000762f89bd455c  vmovaps xmm0, [rsp]
0000762f89bd4561  vmovaps xmm1, [rsp+0x10]
0000762f89bd4567  vmovaps xmm2, [rsp+0x20]
0000762f89bd456d  vmovaps xmm3, [rsp+0x30]
0000762f89bd4573  vmovaps xmm4, [rsp+0x40]
0000762f89bd4579  vmovaps xmm5, [rsp+0x50]
0000762f89bd457f  vmovaps xmm6, [rsp+0x60]
0000762f89bd4585  vmovaps xmm7, [rsp+0x70]
0000762f89bd458b  vmovaps xmm8, [rsp+0x80]
0000762f89bd4594  vmovaps xmm9, [rsp+0x90]
0000762f89bd459d  vmovaps xmm10, [rsp+0xA0]
0000762f89bd45a6  vmovaps xmm12, [rsp+0xB0]
0000762f89bd45af  vmovaps xmm13, [rsp+0xC0]
0000762f89bd45b8  vmovaps xmm14, [rsp+0xD0]
0000762f89bd45c1  vmovaps xmm15, [rsp+0xE0]
0000762f89bd45ca  add rsp, 0xF0
0000762f89bd45d1  pop r11
0000762f89bd45d3  pop r10
0000762f89bd45d5  pop r9
0000762f89bd45d7  pop r8
0000762f89bd45d9  pop rsi
0000762f89bd45da  pop rdi
0000762f89bd45db  pop rdx
0000762f89bd45dc  pop rcx
0000762f89bd45dd  pop rax
0000762f89bd45de  add rsp, 0x08
0000762f89bd45e2  jmp 0x0000762F89BD0123
0000762f89bd45e7  sub rsp, 0x08
0000762f89bd45eb  push rax
0000762f89bd45ec  push rcx
0000762f89bd45ed  push rdx
0000762f89bd45ee  push rdi
0000762f89bd45ef  push rsi
0000762f89bd45f0  push r8
0000762f89bd45f2  push r9
0000762f89bd45f4  push r10
0000762f89bd45f6  push r11
0000762f89bd45f8  sub rsp, 0xF0
0000762f89bd45ff  vmovaps [rsp], xmm0
0000762f89bd4604  vmovaps [rsp+0x10], xmm1
0000762f89bd460a  vmovaps [rsp+0x20], xmm2
0000762f89bd4610  vmovaps [rsp+0x30], xmm3
0000762f89bd4616  vmovaps [rsp+0x40], xmm4
0000762f89bd461c  vmovaps [rsp+0x50], xmm5
0000762f89bd4622  vmovaps [rsp+0x60], xmm6
0000762f89bd4628  vmovaps [rsp+0x70], xmm7
0000762f89bd462e  vmovaps [rsp+0x80], xmm8
0000762f89bd4637  vmovaps [rsp+0x90], xmm9
0000762f89bd4640  vmovaps [rsp+0xA0], xmm10
0000762f89bd4649  vmovaps [rsp+0xB0], xmm11
0000762f89bd4652  vmovaps [rsp+0xC0], xmm12
0000762f89bd465b  vmovaps [rsp+0xD0], xmm13
0000762f89bd4664  vmovaps [rsp+0xE0], xmm14
0000762f89bd466d  sub rsp, 0x30
0000762f89bd4671  movaps [rsp], xmm15
0000762f89bd4676  movaps [rsp+0x10], xmm10
0000762f89bd467c  movaps [rsp+0x20], xmm13
0000762f89bd4682  lea rdi, [rsp]
0000762f89bd4686  mov esi, 0x00
0000762f89bd468b  mov rax, 0x604D6F946530
0000762f89bd4695  call rax
0000762f89bd4697  movaps xmm15, [rsp]
0000762f89bd469c  add rsp, 0x30
0000762f89bd46a0  vmovaps xmm0, [rsp]
0000762f89bd46a5  vmovaps xmm1, [rsp+0x10]
0000762f89bd46ab  vmovaps xmm2, [rsp+0x20]
0000762f89bd46b1  vmovaps xmm3, [rsp+0x30]
0000762f89bd46b7  vmovaps xmm4, [rsp+0x40]
0000762f89bd46bd  vmovaps xmm5, [rsp+0x50]
0000762f89bd46c3  vmovaps xmm6, [rsp+0x60]
0000762f89bd46c9  vmovaps xmm7, [rsp+0x70]
0000762f89bd46cf  vmovaps xmm8, [rsp+0x80]
0000762f89bd46d8  vmovaps xmm9, [rsp+0x90]
0000762f89bd46e1  vmovaps xmm10, [rsp+0xA0]
0000762f89bd46ea  vmovaps xmm11, [rsp+0xB0]
0000762f89bd46f3  vmovaps xmm12, [rsp+0xC0]
0000762f89bd46fc  vmovaps xmm13, [rsp+0xD0]
0000762f89bd4705  vmovaps xmm14, [rsp+0xE0]
0000762f89bd470e  add rsp, 0xF0
0000762f89bd4715  pop r11
0000762f89bd4717  pop r10
0000762f89bd4719  pop r9
0000762f89bd471b  pop r8
0000762f89bd471d  pop rsi
0000762f89bd471e  pop rdi
0000762f89bd471f  pop rdx
0000762f89bd4720  pop rcx
0000762f89bd4721  pop rax
0000762f89bd4722  add rsp, 0x08
0000762f89bd4726  jmp 0x0000762F89BD013D
0000762f89bd472b  sub rsp, 0x08
0000762f89bd472f  push rax
0000762f89bd4730  push rcx
0000762f89bd4731  push rdx
0000762f89bd4732  push rdi
0000762f89bd4733  push rsi
0000762f89bd4734  push r8
0000762f89bd4736  push r9
0000762f89bd4738  push r10
0000762f89bd473a  push r11
0000762f89bd473c  sub rsp, 0xF0
0000762f89bd4743  vmovaps [rsp], xmm0
0000762f89bd4748  vmovaps [rsp+0x10], xmm1
0000762f89bd474e  vmovaps [rsp+0x20], xmm2
0000762f89bd4754  vmovaps [rsp+0x30], xmm3
0000762f89bd475a  vmovaps [rsp+0x40], xmm4
0000762f89bd4760  vmovaps [rsp+0x50], xmm5
0000762f89bd4766  vmovaps [rsp+0x60], xmm6
0000762f89bd476c  vmovaps [rsp+0x70], xmm7
0000762f89bd4772  vmovaps [rsp+0x80], xmm8
0000762f89bd477b  vmovaps [rsp+0x90], xmm9
0000762f89bd4784  vmovaps [rsp+0xA0], xmm11
0000762f89bd478d  vmovaps [rsp+0xB0], xmm12
0000762f89bd4796  vmovaps [rsp+0xC0], xmm13
0000762f89bd479f  vmovaps [rsp+0xD0], xmm14
0000762f89bd47a8  vmovaps [rsp+0xE0], xmm15
0000762f89bd47b1  sub rsp, 0x30
0000762f89bd47b5  movaps [rsp], xmm10
0000762f89bd47ba  movaps [rsp+0x10], xmm7
0000762f89bd47bf  movaps [rsp+0x20], xmm13
0000762f89bd47c5  lea rdi, [rsp]
0000762f89bd47c9  mov esi, 0x00
0000762f89bd47ce  mov rax, 0x604D6F946530
0000762f89bd47d8  call rax
0000762f89bd47da  movaps xmm10, [rsp]
0000762f89bd47df  add rsp, 0x30
0000762f89bd47e3  vmovaps xmm0, [rsp]
0000762f89bd47e8  vmovaps xmm1, [rsp+0x10]
0000762f89bd47ee  vmovaps xmm2, [rsp+0x20]
0000762f89bd47f4  vmovaps xmm3, [rsp+0x30]
0000762f89bd47fa  vmovaps xmm4, [rsp+0x40]
0000762f89bd4800  vmovaps xmm5, [rsp+0x50]
0000762f89bd4806  vmovaps xmm6, [rsp+0x60]
0000762f89bd480c  vmovaps xmm7, [rsp+0x70]
0000762f89bd4812  vmovaps xmm8, [rsp+0x80]
0000762f89bd481b  vmovaps xmm9, [rsp+0x90]
0000762f89bd4824  vmovaps xmm11, [rsp+0xA0]
0000762f89bd482d  vmovaps xmm12, [rsp+0xB0]
0000762f89bd4836  vmovaps xmm13, [rsp+0xC0]
0000762f89bd483f  vmovaps xmm14, [rsp+0xD0]
0000762f89bd4848  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4851  add rsp, 0xF0
0000762f89bd4858  pop r11
0000762f89bd485a  pop r10
0000762f89bd485c  pop r9
0000762f89bd485e  pop r8
0000762f89bd4860  pop rsi
0000762f89bd4861  pop rdi
0000762f89bd4862  pop rdx
0000762f89bd4863  pop rcx
0000762f89bd4864  pop rax
0000762f89bd4865  add rsp, 0x08
0000762f89bd4869  jmp 0x0000762F89BD0169
0000762f89bd486e  sub rsp, 0x08
0000762f89bd4872  push rax
0000762f89bd4873  push rcx
0000762f89bd4874  push rdx
0000762f89bd4875  push rdi
0000762f89bd4876  push rsi
0000762f89bd4877  push r8
0000762f89bd4879  push r9
0000762f89bd487b  push r10
0000762f89bd487d  push r11
0000762f89bd487f  sub rsp, 0xF0
0000762f89bd4886  vmovaps [rsp], xmm0
0000762f89bd488b  vmovaps [rsp+0x10], xmm1
0000762f89bd4891  vmovaps [rsp+0x20], xmm2
0000762f89bd4897  vmovaps [rsp+0x30], xmm3
0000762f89bd489d  vmovaps [rsp+0x40], xmm4
0000762f89bd48a3  vmovaps [rsp+0x50], xmm5
0000762f89bd48a9  vmovaps [rsp+0x60], xmm6
0000762f89bd48af  vmovaps [rsp+0x70], xmm7
0000762f89bd48b5  vmovaps [rsp+0x80], xmm8
0000762f89bd48be  vmovaps [rsp+0x90], xmm9
0000762f89bd48c7  vmovaps [rsp+0xA0], xmm10
0000762f89bd48d0  vmovaps [rsp+0xB0], xmm11
0000762f89bd48d9  vmovaps [rsp+0xC0], xmm12
0000762f89bd48e2  vmovaps [rsp+0xD0], xmm14
0000762f89bd48eb  vmovaps [rsp+0xE0], xmm15
0000762f89bd48f4  sub rsp, 0x30
0000762f89bd48f8  movaps [rsp], xmm13
0000762f89bd48fd  movaps [rsp+0x10], xmm1
0000762f89bd4902  movaps [rsp+0x20], xmm8
0000762f89bd4908  lea rdi, [rsp]
0000762f89bd490c  mov esi, 0x00
0000762f89bd4911  mov rax, 0x604D6F946530
0000762f89bd491b  call rax
0000762f89bd491d  movaps xmm13, [rsp]
0000762f89bd4922  add rsp, 0x30
0000762f89bd4926  vmovaps xmm0, [rsp]
0000762f89bd492b  vmovaps xmm1, [rsp+0x10]
0000762f89bd4931  vmovaps xmm2, [rsp+0x20]
0000762f89bd4937  vmovaps xmm3, [rsp+0x30]
0000762f89bd493d  vmovaps xmm4, [rsp+0x40]
0000762f89bd4943  vmovaps xmm5, [rsp+0x50]
0000762f89bd4949  vmovaps xmm6, [rsp+0x60]
0000762f89bd494f  vmovaps xmm7, [rsp+0x70]
0000762f89bd4955  vmovaps xmm8, [rsp+0x80]
0000762f89bd495e  vmovaps xmm9, [rsp+0x90]
0000762f89bd4967  vmovaps xmm10, [rsp+0xA0]
0000762f89bd4970  vmovaps xmm11, [rsp+0xB0]
0000762f89bd4979  vmovaps xmm12, [rsp+0xC0]
0000762f89bd4982  vmovaps xmm14, [rsp+0xD0]
0000762f89bd498b  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4994  add rsp, 0xF0
0000762f89bd499b  pop r11
0000762f89bd499d  pop r10
0000762f89bd499f  pop r9
0000762f89bd49a1  pop r8
0000762f89bd49a3  pop rsi
0000762f89bd49a4  pop rdi
0000762f89bd49a5  pop rdx
0000762f89bd49a6  pop rcx
0000762f89bd49a7  pop rax
0000762f89bd49a8  add rsp, 0x08
0000762f89bd49ac  jmp 0x0000762F89BD0183
0000762f89bd49b1  call 0x0000762F899FF430
0000762f89bd49b6  jmp 0x0000762F89BD018D
0000762f89bd49bb  sub rsp, 0x08
0000762f89bd49bf  push rax
0000762f89bd49c0  push rcx
0000762f89bd49c1  push rdx
0000762f89bd49c2  push rdi
0000762f89bd49c3  push rsi
0000762f89bd49c4  push r8
0000762f89bd49c6  push r9
0000762f89bd49c8  push r10
0000762f89bd49ca  push r11
0000762f89bd49cc  sub rsp, 0xF0
0000762f89bd49d3  vmovaps [rsp], xmm0
0000762f89bd49d8  vmovaps [rsp+0x10], xmm1
0000762f89bd49de  vmovaps [rsp+0x20], xmm2
0000762f89bd49e4  vmovaps [rsp+0x30], xmm3
0000762f89bd49ea  vmovaps [rsp+0x40], xmm4
0000762f89bd49f0  vmovaps [rsp+0x50], xmm5
0000762f89bd49f6  vmovaps [rsp+0x60], xmm6
0000762f89bd49fc  vmovaps [rsp+0x70], xmm7
0000762f89bd4a02  vmovaps [rsp+0x80], xmm9
0000762f89bd4a0b  vmovaps [rsp+0x90], xmm10
0000762f89bd4a14  vmovaps [rsp+0xA0], xmm11
0000762f89bd4a1d  vmovaps [rsp+0xB0], xmm12
0000762f89bd4a26  vmovaps [rsp+0xC0], xmm13
0000762f89bd4a2f  vmovaps [rsp+0xD0], xmm14
0000762f89bd4a38  vmovaps [rsp+0xE0], xmm15
0000762f89bd4a41  sub rsp, 0x30
0000762f89bd4a45  movaps [rsp], xmm8
0000762f89bd4a4a  movaps [rsp+0x10], xmm14
0000762f89bd4a50  movaps [rsp+0x20], xmm9
0000762f89bd4a56  lea rdi, [rsp]
0000762f89bd4a5a  mov esi, 0x00
0000762f89bd4a5f  mov rax, 0x604D6F946530
0000762f89bd4a69  call rax
0000762f89bd4a6b  movaps xmm8, [rsp]
0000762f89bd4a70  add rsp, 0x30
0000762f89bd4a74  vmovaps xmm0, [rsp]
0000762f89bd4a79  vmovaps xmm1, [rsp+0x10]
0000762f89bd4a7f  vmovaps xmm2, [rsp+0x20]
0000762f89bd4a85  vmovaps xmm3, [rsp+0x30]
0000762f89bd4a8b  vmovaps xmm4, [rsp+0x40]
0000762f89bd4a91  vmovaps xmm5, [rsp+0x50]
0000762f89bd4a97  vmovaps xmm6, [rsp+0x60]
0000762f89bd4a9d  vmovaps xmm7, [rsp+0x70]
0000762f89bd4aa3  vmovaps xmm9, [rsp+0x80]
0000762f89bd4aac  vmovaps xmm10, [rsp+0x90]
0000762f89bd4ab5  vmovaps xmm11, [rsp+0xA0]
0000762f89bd4abe  vmovaps xmm12, [rsp+0xB0]
0000762f89bd4ac7  vmovaps xmm13, [rsp+0xC0]
0000762f89bd4ad0  vmovaps xmm14, [rsp+0xD0]
0000762f89bd4ad9  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4ae2  add rsp, 0xF0
0000762f89bd4ae9  pop r11
0000762f89bd4aeb  pop r10
0000762f89bd4aed  pop r9
0000762f89bd4aef  pop r8
0000762f89bd4af1  pop rsi
0000762f89bd4af2  pop rdi
0000762f89bd4af3  pop rdx
0000762f89bd4af4  pop rcx
0000762f89bd4af5  pop rax
0000762f89bd4af6  add rsp, 0x08
0000762f89bd4afa  jmp 0x0000762F89BD01AF
0000762f89bd4aff  sub rsp, 0x08
0000762f89bd4b03  push rax
0000762f89bd4b04  push rcx
0000762f89bd4b05  push rdx
0000762f89bd4b06  push rdi
0000762f89bd4b07  push rsi
0000762f89bd4b08  push r8
0000762f89bd4b0a  push r9
0000762f89bd4b0c  push r10
0000762f89bd4b0e  push r11
0000762f89bd4b10  sub rsp, 0xF0
0000762f89bd4b17  vmovaps [rsp], xmm0
0000762f89bd4b1c  vmovaps [rsp+0x10], xmm1
0000762f89bd4b22  vmovaps [rsp+0x20], xmm2
0000762f89bd4b28  vmovaps [rsp+0x30], xmm3
0000762f89bd4b2e  vmovaps [rsp+0x40], xmm4
0000762f89bd4b34  vmovaps [rsp+0x50], xmm5
0000762f89bd4b3a  vmovaps [rsp+0x60], xmm6
0000762f89bd4b40  vmovaps [rsp+0x70], xmm7
0000762f89bd4b46  vmovaps [rsp+0x80], xmm8
0000762f89bd4b4f  vmovaps [rsp+0x90], xmm10
0000762f89bd4b58  vmovaps [rsp+0xA0], xmm11
0000762f89bd4b61  vmovaps [rsp+0xB0], xmm12
0000762f89bd4b6a  vmovaps [rsp+0xC0], xmm13
0000762f89bd4b73  vmovaps [rsp+0xD0], xmm14
0000762f89bd4b7c  vmovaps [rsp+0xE0], xmm15
0000762f89bd4b85  sub rsp, 0x30
0000762f89bd4b89  movaps [rsp], xmm9
0000762f89bd4b8e  movaps [rsp+0x10], xmm1
0000762f89bd4b93  movaps [rsp+0x20], xmm14
0000762f89bd4b99  lea rdi, [rsp]
0000762f89bd4b9d  mov esi, 0x00
0000762f89bd4ba2  mov rax, 0x604D6F946530
0000762f89bd4bac  call rax
0000762f89bd4bae  movaps xmm9, [rsp]
0000762f89bd4bb3  add rsp, 0x30
0000762f89bd4bb7  vmovaps xmm0, [rsp]
0000762f89bd4bbc  vmovaps xmm1, [rsp+0x10]
0000762f89bd4bc2  vmovaps xmm2, [rsp+0x20]
0000762f89bd4bc8  vmovaps xmm3, [rsp+0x30]
0000762f89bd4bce  vmovaps xmm4, [rsp+0x40]
0000762f89bd4bd4  vmovaps xmm5, [rsp+0x50]
0000762f89bd4bda  vmovaps xmm6, [rsp+0x60]
0000762f89bd4be0  vmovaps xmm7, [rsp+0x70]
0000762f89bd4be6  vmovaps xmm8, [rsp+0x80]
0000762f89bd4bef  vmovaps xmm10, [rsp+0x90]
0000762f89bd4bf8  vmovaps xmm11, [rsp+0xA0]
0000762f89bd4c01  vmovaps xmm12, [rsp+0xB0]
0000762f89bd4c0a  vmovaps xmm13, [rsp+0xC0]
0000762f89bd4c13  vmovaps xmm14, [rsp+0xD0]
0000762f89bd4c1c  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4c25  add rsp, 0xF0
0000762f89bd4c2c  pop r11
0000762f89bd4c2e  pop r10
0000762f89bd4c30  pop r9
0000762f89bd4c32  pop r8
0000762f89bd4c34  pop rsi
0000762f89bd4c35  pop rdi
0000762f89bd4c36  pop rdx
0000762f89bd4c37  pop rcx
0000762f89bd4c38  pop rax
0000762f89bd4c39  add rsp, 0x08
0000762f89bd4c3d  jmp 0x0000762F89BD01DD
0000762f89bd4c42  sub rsp, 0x08
0000762f89bd4c46  push rax
0000762f89bd4c47  push rcx
0000762f89bd4c48  push rdx
0000762f89bd4c49  push rdi
0000762f89bd4c4a  push rsi
0000762f89bd4c4b  push r8
0000762f89bd4c4d  push r9
0000762f89bd4c4f  push r10
0000762f89bd4c51  push r11
0000762f89bd4c53  sub rsp, 0xF0
0000762f89bd4c5a  vmovaps [rsp], xmm0
0000762f89bd4c5f  vmovaps [rsp+0x10], xmm1
0000762f89bd4c65  vmovaps [rsp+0x20], xmm2
0000762f89bd4c6b  vmovaps [rsp+0x30], xmm3
0000762f89bd4c71  vmovaps [rsp+0x40], xmm4
0000762f89bd4c77  vmovaps [rsp+0x50], xmm5
0000762f89bd4c7d  vmovaps [rsp+0x60], xmm6
0000762f89bd4c83  vmovaps [rsp+0x70], xmm7
0000762f89bd4c89  vmovaps [rsp+0x80], xmm8
0000762f89bd4c92  vmovaps [rsp+0x90], xmm9
0000762f89bd4c9b  vmovaps [rsp+0xA0], xmm10
0000762f89bd4ca4  vmovaps [rsp+0xB0], xmm11
0000762f89bd4cad  vmovaps [rsp+0xC0], xmm12
0000762f89bd4cb6  vmovaps [rsp+0xD0], xmm13
0000762f89bd4cbf  vmovaps [rsp+0xE0], xmm15
0000762f89bd4cc8  sub rsp, 0x30
0000762f89bd4ccc  movaps [rsp], xmm14
0000762f89bd4cd1  movaps [rsp+0x10], xmm4
0000762f89bd4cd6  movaps [rsp+0x20], xmm1
0000762f89bd4cdb  lea rdi, [rsp]
0000762f89bd4cdf  mov esi, 0x00
0000762f89bd4ce4  mov rax, 0x604D6F946530
0000762f89bd4cee  call rax
0000762f89bd4cf0  movaps xmm14, [rsp]
0000762f89bd4cf5  add rsp, 0x30
0000762f89bd4cf9  vmovaps xmm0, [rsp]
0000762f89bd4cfe  vmovaps xmm1, [rsp+0x10]
0000762f89bd4d04  vmovaps xmm2, [rsp+0x20]
0000762f89bd4d0a  vmovaps xmm3, [rsp+0x30]
0000762f89bd4d10  vmovaps xmm4, [rsp+0x40]
0000762f89bd4d16  vmovaps xmm5, [rsp+0x50]
0000762f89bd4d1c  vmovaps xmm6, [rsp+0x60]
0000762f89bd4d22  vmovaps xmm7, [rsp+0x70]
0000762f89bd4d28  vmovaps xmm8, [rsp+0x80]
0000762f89bd4d31  vmovaps xmm9, [rsp+0x90]
0000762f89bd4d3a  vmovaps xmm10, [rsp+0xA0]
0000762f89bd4d43  vmovaps xmm11, [rsp+0xB0]
0000762f89bd4d4c  vmovaps xmm12, [rsp+0xC0]
0000762f89bd4d55  vmovaps xmm13, [rsp+0xD0]
0000762f89bd4d5e  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4d67  add rsp, 0xF0
0000762f89bd4d6e  pop r11
0000762f89bd4d70  pop r10
0000762f89bd4d72  pop r9
0000762f89bd4d74  pop r8
0000762f89bd4d76  pop rsi
0000762f89bd4d77  pop rdi
0000762f89bd4d78  pop rdx
0000762f89bd4d79  pop rcx
0000762f89bd4d7a  pop rax
0000762f89bd4d7b  add rsp, 0x08
0000762f89bd4d7f  jmp 0x0000762F89BD0203
0000762f89bd4d84  sub rsp, 0x08
0000762f89bd4d88  push rax
0000762f89bd4d89  push rcx
0000762f89bd4d8a  push rdx
0000762f89bd4d8b  push rdi
0000762f89bd4d8c  push rsi
0000762f89bd4d8d  push r8
0000762f89bd4d8f  push r9
0000762f89bd4d91  push r10
0000762f89bd4d93  push r11
0000762f89bd4d95  sub rsp, 0xF0
0000762f89bd4d9c  vmovaps [rsp], xmm0
0000762f89bd4da1  vmovaps [rsp+0x10], xmm2
0000762f89bd4da7  vmovaps [rsp+0x20], xmm3
0000762f89bd4dad  vmovaps [rsp+0x30], xmm4
0000762f89bd4db3  vmovaps [rsp+0x40], xmm5
0000762f89bd4db9  vmovaps [rsp+0x50], xmm6
0000762f89bd4dbf  vmovaps [rsp+0x60], xmm7
0000762f89bd4dc5  vmovaps [rsp+0x70], xmm8
0000762f89bd4dcb  vmovaps [rsp+0x80], xmm9
0000762f89bd4dd4  vmovaps [rsp+0x90], xmm10
0000762f89bd4ddd  vmovaps [rsp+0xA0], xmm11
0000762f89bd4de6  vmovaps [rsp+0xB0], xmm12
0000762f89bd4def  vmovaps [rsp+0xC0], xmm13
0000762f89bd4df8  vmovaps [rsp+0xD0], xmm14
0000762f89bd4e01  vmovaps [rsp+0xE0], xmm15
0000762f89bd4e0a  sub rsp, 0x30
0000762f89bd4e0e  movaps [rsp], xmm1
0000762f89bd4e12  movaps [rsp+0x10], xmm12
0000762f89bd4e18  movaps [rsp+0x20], xmm11
0000762f89bd4e1e  lea rdi, [rsp]
0000762f89bd4e22  mov esi, 0x00
0000762f89bd4e27  mov rax, 0x604D6F946530
0000762f89bd4e31  call rax
0000762f89bd4e33  movaps xmm1, [rsp]
0000762f89bd4e37  add rsp, 0x30
0000762f89bd4e3b  vmovaps xmm0, [rsp]
0000762f89bd4e40  vmovaps xmm2, [rsp+0x10]
0000762f89bd4e46  vmovaps xmm3, [rsp+0x20]
0000762f89bd4e4c  vmovaps xmm4, [rsp+0x30]
0000762f89bd4e52  vmovaps xmm5, [rsp+0x40]
0000762f89bd4e58  vmovaps xmm6, [rsp+0x50]
0000762f89bd4e5e  vmovaps xmm7, [rsp+0x60]
0000762f89bd4e64  vmovaps xmm8, [rsp+0x70]
0000762f89bd4e6a  vmovaps xmm9, [rsp+0x80]
0000762f89bd4e73  vmovaps xmm10, [rsp+0x90]
0000762f89bd4e7c  vmovaps xmm11, [rsp+0xA0]
0000762f89bd4e85  vmovaps xmm12, [rsp+0xB0]
0000762f89bd4e8e  vmovaps xmm13, [rsp+0xC0]
0000762f89bd4e97  vmovaps xmm14, [rsp+0xD0]
0000762f89bd4ea0  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4ea9  add rsp, 0xF0
0000762f89bd4eb0  pop r11
0000762f89bd4eb2  pop r10
0000762f89bd4eb4  pop r9
0000762f89bd4eb6  pop r8
0000762f89bd4eb8  pop rsi
0000762f89bd4eb9  pop rdi
0000762f89bd4eba  pop rdx
0000762f89bd4ebb  pop rcx
0000762f89bd4ebc  pop rax
0000762f89bd4ebd  add rsp, 0x08
0000762f89bd4ec1  jmp 0x0000762F89BD0224
0000762f89bd4ec6  call 0x0000762F89AE20A0
0000762f89bd4ecb  jmp 0x0000762F89BD0232
0000762f89bd4ed0  call 0x0000762F89A09D70
0000762f89bd4ed5  jmp 0x0000762F89BD023C
0000762f89bd4eda  sub rsp, 0x08
0000762f89bd4ede  push rax
0000762f89bd4edf  push rcx
0000762f89bd4ee0  push rdx
0000762f89bd4ee1  push rdi
0000762f89bd4ee2  push rsi
0000762f89bd4ee3  push r8
0000762f89bd4ee5  push r9
0000762f89bd4ee7  push r10
0000762f89bd4ee9  push r11
0000762f89bd4eeb  sub rsp, 0xF0
0000762f89bd4ef2  vmovaps [rsp], xmm0
0000762f89bd4ef7  vmovaps [rsp+0x10], xmm1
0000762f89bd4efd  vmovaps [rsp+0x20], xmm2
0000762f89bd4f03  vmovaps [rsp+0x30], xmm3
0000762f89bd4f09  vmovaps [rsp+0x40], xmm4
0000762f89bd4f0f  vmovaps [rsp+0x50], xmm5
0000762f89bd4f15  vmovaps [rsp+0x60], xmm6
0000762f89bd4f1b  vmovaps [rsp+0x70], xmm8
0000762f89bd4f21  vmovaps [rsp+0x80], xmm9
0000762f89bd4f2a  vmovaps [rsp+0x90], xmm10
0000762f89bd4f33  vmovaps [rsp+0xA0], xmm11
0000762f89bd4f3c  vmovaps [rsp+0xB0], xmm12
0000762f89bd4f45  vmovaps [rsp+0xC0], xmm13
0000762f89bd4f4e  vmovaps [rsp+0xD0], xmm14
0000762f89bd4f57  vmovaps [rsp+0xE0], xmm15
0000762f89bd4f60  sub rsp, 0x30
0000762f89bd4f64  movaps [rsp], xmm7
0000762f89bd4f68  movaps [rsp+0x10], xmm15
0000762f89bd4f6e  movaps [rsp+0x20], xmm10
0000762f89bd4f74  lea rdi, [rsp]
0000762f89bd4f78  mov esi, 0x00
0000762f89bd4f7d  mov rax, 0x604D6F946530
0000762f89bd4f87  call rax
0000762f89bd4f89  movaps xmm7, [rsp]
0000762f89bd4f8d  add rsp, 0x30
0000762f89bd4f91  vmovaps xmm0, [rsp]
0000762f89bd4f96  vmovaps xmm1, [rsp+0x10]
0000762f89bd4f9c  vmovaps xmm2, [rsp+0x20]
0000762f89bd4fa2  vmovaps xmm3, [rsp+0x30]
0000762f89bd4fa8  vmovaps xmm4, [rsp+0x40]
0000762f89bd4fae  vmovaps xmm5, [rsp+0x50]
0000762f89bd4fb4  vmovaps xmm6, [rsp+0x60]
0000762f89bd4fba  vmovaps xmm8, [rsp+0x70]
0000762f89bd4fc0  vmovaps xmm9, [rsp+0x80]
0000762f89bd4fc9  vmovaps xmm10, [rsp+0x90]
0000762f89bd4fd2  vmovaps xmm11, [rsp+0xA0]
0000762f89bd4fdb  vmovaps xmm12, [rsp+0xB0]
0000762f89bd4fe4  vmovaps xmm13, [rsp+0xC0]
0000762f89bd4fed  vmovaps xmm14, [rsp+0xD0]
0000762f89bd4ff6  vmovaps xmm15, [rsp+0xE0]
0000762f89bd4fff  add rsp, 0xF0
0000762f89bd5006  pop r11
0000762f89bd5008  pop r10
0000762f89bd500a  pop r9
0000762f89bd500c  pop r8
0000762f89bd500e  pop rsi
0000762f89bd500f  pop rdi
0000762f89bd5010  pop rdx
0000762f89bd5011  pop rcx
0000762f89bd5012  pop rax
0000762f89bd5013  add rsp, 0x08
0000762f89bd5017  jmp 0x0000762F89BD025D
0000762f89bd501c  sub rsp, 0x08
0000762f89bd5020  push rax
0000762f89bd5021  push rcx
0000762f89bd5022  push rdx
0000762f89bd5023  push rdi
0000762f89bd5024  push rsi
0000762f89bd5025  push r8
0000762f89bd5027  push r9
0000762f89bd5029  push r10
0000762f89bd502b  push r11
0000762f89bd502d  sub rsp, 0xF0
0000762f89bd5034  vmovaps [rsp], xmm0
0000762f89bd5039  vmovaps [rsp+0x10], xmm1
0000762f89bd503f  vmovaps [rsp+0x20], xmm2
0000762f89bd5045  vmovaps [rsp+0x30], xmm3
0000762f89bd504b  vmovaps [rsp+0x40], xmm4
0000762f89bd5051  vmovaps [rsp+0x50], xmm5
0000762f89bd5057  vmovaps [rsp+0x60], xmm6
0000762f89bd505d  vmovaps [rsp+0x70], xmm7
0000762f89bd5063  vmovaps [rsp+0x80], xmm8
0000762f89bd506c  vmovaps [rsp+0x90], xmm9
0000762f89bd5075  vmovaps [rsp+0xA0], xmm11
0000762f89bd507e  vmovaps [rsp+0xB0], xmm12
0000762f89bd5087  vmovaps [rsp+0xC0], xmm13
0000762f89bd5090  vmovaps [rsp+0xD0], xmm14
0000762f89bd5099  vmovaps [rsp+0xE0], xmm15
0000762f89bd50a2  sub rsp, 0x30
0000762f89bd50a6  movaps [rsp], xmm10
0000762f89bd50ab  movaps [rsp+0x10], xmm11
0000762f89bd50b1  movaps [rsp+0x20], xmm15
0000762f89bd50b7  lea rdi, [rsp]
0000762f89bd50bb  mov esi, 0x00
0000762f89bd50c0  mov rax, 0x604D6F946530
0000762f89bd50ca  call rax
0000762f89bd50cc  movaps xmm10, [rsp]
0000762f89bd50d1  add rsp, 0x30
0000762f89bd50d5  vmovaps xmm0, [rsp]
0000762f89bd50da  vmovaps xmm1, [rsp+0x10]
0000762f89bd50e0  vmovaps xmm2, [rsp+0x20]
0000762f89bd50e6  vmovaps xmm3, [rsp+0x30]
0000762f89bd50ec  vmovaps xmm4, [rsp+0x40]
0000762f89bd50f2  vmovaps xmm5, [rsp+0x50]
0000762f89bd50f8  vmovaps xmm6, [rsp+0x60]
0000762f89bd50fe  vmovaps xmm7, [rsp+0x70]
0000762f89bd5104  vmovaps xmm8, [rsp+0x80]
0000762f89bd510d  vmovaps xmm9, [rsp+0x90]
0000762f89bd5116  vmovaps xmm11, [rsp+0xA0]
0000762f89bd511f  vmovaps xmm12, [rsp+0xB0]
0000762f89bd5128  vmovaps xmm13, [rsp+0xC0]
0000762f89bd5131  vmovaps xmm14, [rsp+0xD0]
0000762f89bd513a  vmovaps xmm15, [rsp+0xE0]
0000762f89bd5143  add rsp, 0xF0
0000762f89bd514a  pop r11
0000762f89bd514c  pop r10
0000762f89bd514e  pop r9
0000762f89bd5150  pop r8
0000762f89bd5152  pop rsi
0000762f89bd5153  pop rdi
0000762f89bd5154  pop rdx
0000762f89bd5155  pop rcx
0000762f89bd5156  pop rax
0000762f89bd5157  add rsp, 0x08
0000762f89bd515b  jmp 0x0000762F89BD028B
0000762f89bd5160  sub rsp, 0x08
0000762f89bd5164  push rax
0000762f89bd5165  push rcx
0000762f89bd5166  push rdx
0000762f89bd5167  push rdi
0000762f89bd5168  push rsi
0000762f89bd5169  push r8
0000762f89bd516b  push r9
0000762f89bd516d  push r10
0000762f89bd516f  push r11
0000762f89bd5171  sub rsp, 0xF0
0000762f89bd5178  vmovaps [rsp], xmm0
0000762f89bd517d  vmovaps [rsp+0x10], xmm1
0000762f89bd5183  vmovaps [rsp+0x20], xmm2
0000762f89bd5189  vmovaps [rsp+0x30], xmm3
0000762f89bd518f  vmovaps [rsp+0x40], xmm4
0000762f89bd5195  vmovaps [rsp+0x50], xmm5
0000762f89bd519b  vmovaps [rsp+0x60], xmm6
0000762f89bd51a1  vmovaps [rsp+0x70], xmm7
0000762f89bd51a7  vmovaps [rsp+0x80], xmm8
0000762f89bd51b0  vmovaps [rsp+0x90], xmm9
0000762f89bd51b9  vmovaps [rsp+0xA0], xmm10
0000762f89bd51c2  vmovaps [rsp+0xB0], xmm12
0000762f89bd51cb  vmovaps [rsp+0xC0], xmm13
0000762f89bd51d4  vmovaps [rsp+0xD0], xmm14
0000762f89bd51dd  vmovaps [rsp+0xE0], xmm15
0000762f89bd51e6  sub rsp, 0x30
0000762f89bd51ea  movaps [rsp], xmm11
0000762f89bd51ef  movaps [rsp+0x10], xmm12
0000762f89bd51f5  movaps [rsp+0x20], xmm15
0000762f89bd51fb  lea rdi, [rsp]
0000762f89bd51ff  mov esi, 0x00
0000762f89bd5204  mov rax, 0x604D6F946530
0000762f89bd520e  call rax
0000762f89bd5210  movaps xmm11, [rsp]
0000762f89bd5215  add rsp, 0x30
0000762f89bd5219  vmovaps xmm0, [rsp]
0000762f89bd521e  vmovaps xmm1, [rsp+0x10]
0000762f89bd5224  vmovaps xmm2, [rsp+0x20]
0000762f89bd522a  vmovaps xmm3, [rsp+0x30]
0000762f89bd5230  vmovaps xmm4, [rsp+0x40]
0000762f89bd5236  vmovaps xmm5, [rsp+0x50]
0000762f89bd523c  vmovaps xmm6, [rsp+0x60]
0000762f89bd5242  vmovaps xmm7, [rsp+0x70]
0000762f89bd5248  vmovaps xmm8, [rsp+0x80]
0000762f89bd5251  vmovaps xmm9, [rsp+0x90]
0000762f89bd525a  vmovaps xmm10, [rsp+0xA0]
0000762f89bd5263  vmovaps xmm12, [rsp+0xB0]
0000762f89bd526c  vmovaps xmm13, [rsp+0xC0]
0000762f89bd5275  vmovaps xmm14, [rsp+0xD0]
0000762f89bd527e  vmovaps xmm15, [rsp+0xE0]
0000762f89bd5287  add rsp, 0xF0
0000762f89bd528e  pop r11
0000762f89bd5290  pop r10
0000762f89bd5292  pop r9
0000762f89bd5294  pop r8
0000762f89bd5296  pop rsi
0000762f89bd5297  pop rdi
0000762f89bd5298  pop rdx
0000762f89bd5299  pop rcx
0000762f89bd529a  pop rax
0000762f89bd529b  add rsp, 0x08
0000762f89bd529f  jmp 0x0000762F89BD02B9
0000762f89bd52a4  sub rsp, 0x08
0000762f89bd52a8  push rax
0000762f89bd52a9  push rcx
0000762f89bd52aa  push rdx
0000762f89bd52ab  push rdi
0000762f89bd52ac  push rsi
0000762f89bd52ad  push r8
0000762f89bd52af  push r9
0000762f89bd52b1  push r10
0000762f89bd52b3  push r11
0000762f89bd52b5  sub rsp, 0xF0
0000762f89bd52bc  vmovaps [rsp], xmm0
0000762f89bd52c1  vmovaps [rsp+0x10], xmm1
0000762f89bd52c7  vmovaps [rsp+0x20], xmm2
0000762f89bd52cd  vmovaps [rsp+0x30], xmm3
0000762f89bd52d3  vmovaps [rsp+0x40], xmm4
0000762f89bd52d9  vmovaps [rsp+0x50], xmm5
0000762f89bd52df  vmovaps [rsp+0x60], xmm6
0000762f89bd52e5  vmovaps [rsp+0x70], xmm7
0000762f89bd52eb  vmovaps [rsp+0x80], xmm8
0000762f89bd52f4  vmovaps [rsp+0x90], xmm9
0000762f89bd52fd  vmovaps [rsp+0xA0], xmm10
0000762f89bd5306  vmovaps [rsp+0xB0], xmm11
0000762f89bd530f  vmovaps [rsp+0xC0], xmm12
0000762f89bd5318  vmovaps [rsp+0xD0], xmm13
0000762f89bd5321  vmovaps [rsp+0xE0], xmm14
0000762f89bd532a  sub rsp, 0x30
0000762f89bd532e  movaps [rsp], xmm15
0000762f89bd5333  movaps [rsp+0x10], xmm13
0000762f89bd5339  movaps [rsp+0x20], xmm9
0000762f89bd533f  lea rdi, [rsp]
0000762f89bd5343  mov esi, 0x00
0000762f89bd5348  mov rax, 0x604D6F946530
0000762f89bd5352  call rax
0000762f89bd5354  movaps xmm15, [rsp]
0000762f89bd5359  add rsp, 0x30
0000762f89bd535d  vmovaps xmm0, [rsp]
0000762f89bd5362  vmovaps xmm1, [rsp+0x10]
0000762f89bd5368  vmovaps xmm2, [rsp+0x20]
0000762f89bd536e  vmovaps xmm3, [rsp+0x30]
0000762f89bd5374  vmovaps xmm4, [rsp+0x40]
0000762f89bd537a  vmovaps xmm5, [rsp+0x50]
0000762f89bd5380  vmovaps xmm6, [rsp+0x60]
0000762f89bd5386  vmovaps xmm7, [rsp+0x70]
0000762f89bd538c  vmovaps xmm8, [rsp+0x80]
0000762f89bd5395  vmovaps xmm9, [rsp+0x90]
0000762f89bd539e  vmovaps xmm10, [rsp+0xA0]
0000762f89bd53a7  vmovaps xmm11, [rsp+0xB0]
0000762f89bd53b0  vmovaps xmm12, [rsp+0xC0]
0000762f89bd53b9  vmovaps xmm13, [rsp+0xD0]
0000762f89bd53c2  vmovaps xmm14, [rsp+0xE0]
0000762f89bd53cb  add rsp, 0xF0
0000762f89bd53d2  pop r11
0000762f89bd53d4  pop r10
0000762f89bd53d6  pop r9
0000762f89bd53d8  pop r8
0000762f89bd53da  pop rsi
0000762f89bd53db  pop rdi
0000762f89bd53dc  pop rdx
0000762f89bd53dd  pop rcx
0000762f89bd53de  pop rax
0000762f89bd53df  add rsp, 0x08
0000762f89bd53e3  jmp 0x0000762F89BD02D4
0000762f89bd53e8  sub rsp, 0x08
0000762f89bd53ec  push rax
0000762f89bd53ed  push rcx
0000762f89bd53ee  push rdx
0000762f89bd53ef  push rdi
0000762f89bd53f0  push rsi
0000762f89bd53f1  push r8
0000762f89bd53f3  push r9
0000762f89bd53f5  push r10
0000762f89bd53f7  push r11
0000762f89bd53f9  sub rsp, 0xF0
0000762f89bd5400  vmovaps [rsp], xmm0
0000762f89bd5405  vmovaps [rsp+0x10], xmm1
0000762f89bd540b  vmovaps [rsp+0x20], xmm2
0000762f89bd5411  vmovaps [rsp+0x30], xmm3
0000762f89bd5417  vmovaps [rsp+0x40], xmm4
0000762f89bd541d  vmovaps [rsp+0x50], xmm5
0000762f89bd5423  vmovaps [rsp+0x60], xmm6
0000762f89bd5429  vmovaps [rsp+0x70], xmm7
0000762f89bd542f  vmovaps [rsp+0x80], xmm8
0000762f89bd5438  vmovaps [rsp+0x90], xmm9
0000762f89bd5441  vmovaps [rsp+0xA0], xmm10
0000762f89bd544a  vmovaps [rsp+0xB0], xmm11
0000762f89bd5453  vmovaps [rsp+0xC0], xmm12
0000762f89bd545c  vmovaps [rsp+0xD0], xmm14
0000762f89bd5465  vmovaps [rsp+0xE0], xmm15
0000762f89bd546e  sub rsp, 0x30
0000762f89bd5472  movaps [rsp], xmm13
0000762f89bd5477  movaps [rsp+0x10], xmm8
0000762f89bd547d  movaps [rsp+0x20], xmm14
0000762f89bd5483  lea rdi, [rsp]
0000762f89bd5487  mov esi, 0x00
0000762f89bd548c  mov rax, 0x604D6F946530
0000762f89bd5496  call rax
0000762f89bd5498  movaps xmm13, [rsp]
0000762f89bd549d  add rsp, 0x30
0000762f89bd54a1  vmovaps xmm0, [rsp]
0000762f89bd54a6  vmovaps xmm1, [rsp+0x10]
0000762f89bd54ac  vmovaps xmm2, [rsp+0x20]
0000762f89bd54b2  vmovaps xmm3, [rsp+0x30]
0000762f89bd54b8  vmovaps xmm4, [rsp+0x40]
0000762f89bd54be  vmovaps xmm5, [rsp+0x50]
0000762f89bd54c4  vmovaps xmm6, [rsp+0x60]
0000762f89bd54ca  vmovaps xmm7, [rsp+0x70]
0000762f89bd54d0  vmovaps xmm8, [rsp+0x80]
0000762f89bd54d9  vmovaps xmm9, [rsp+0x90]
0000762f89bd54e2  vmovaps xmm10, [rsp+0xA0]
0000762f89bd54eb  vmovaps xmm11, [rsp+0xB0]
0000762f89bd54f4  vmovaps xmm12, [rsp+0xC0]
0000762f89bd54fd  vmovaps xmm14, [rsp+0xD0]
0000762f89bd5506  vmovaps xmm15, [rsp+0xE0]
0000762f89bd550f  add rsp, 0xF0
0000762f89bd5516  pop r11
0000762f89bd5518  pop r10
0000762f89bd551a  pop r9
0000762f89bd551c  pop r8
0000762f89bd551e  pop rsi
0000762f89bd551f  pop rdi
0000762f89bd5520  pop rdx
0000762f89bd5521  pop rcx
0000762f89bd5522  pop rax
0000762f89bd5523  add rsp, 0x08
0000762f89bd5527  jmp 0x0000762F89BD02F7
0000762f89bd552c  sub rsp, 0x08
0000762f89bd5530  push rax
0000762f89bd5531  push rcx
0000762f89bd5532  push rdx
0000762f89bd5533  push rdi
0000762f89bd5534  push rsi
0000762f89bd5535  push r8
0000762f89bd5537  push r9
0000762f89bd5539  push r10
0000762f89bd553b  push r11
0000762f89bd553d  sub rsp, 0xF0
0000762f89bd5544  vmovaps [rsp], xmm0
0000762f89bd5549  vmovaps [rsp+0x10], xmm1
0000762f89bd554f  vmovaps [rsp+0x20], xmm2
0000762f89bd5555  vmovaps [rsp+0x30], xmm3
0000762f89bd555b  vmovaps [rsp+0x40], xmm4
0000762f89bd5561  vmovaps [rsp+0x50], xmm5
0000762f89bd5567  vmovaps [rsp+0x60], xmm6
0000762f89bd556d  vmovaps [rsp+0x70], xmm7
0000762f89bd5573  vmovaps [rsp+0x80], xmm8
0000762f89bd557c  vmovaps [rsp+0x90], xmm9
0000762f89bd5585  vmovaps [rsp+0xA0], xmm10
0000762f89bd558e  vmovaps [rsp+0xB0], xmm11
0000762f89bd5597  vmovaps [rsp+0xC0], xmm12
0000762f89bd55a0  vmovaps [rsp+0xD0], xmm13
0000762f89bd55a9  vmovaps [rsp+0xE0], xmm15
0000762f89bd55b2  sub rsp, 0x30
0000762f89bd55b6  movaps [rsp], xmm14
0000762f89bd55bb  movaps [rsp+0x10], xmm1
0000762f89bd55c0  movaps [rsp+0x20], xmm10
0000762f89bd55c6  lea rdi, [rsp]
0000762f89bd55ca  mov esi, 0x00
0000762f89bd55cf  mov rax, 0x604D6F946530
0000762f89bd55d9  call rax
0000762f89bd55db  movaps xmm14, [rsp]
0000762f89bd55e0  add rsp, 0x30
0000762f89bd55e4  vmovaps xmm0, [rsp]
0000762f89bd55e9  vmovaps xmm1, [rsp+0x10]
0000762f89bd55ef  vmovaps xmm2, [rsp+0x20]
0000762f89bd55f5  vmovaps xmm3, [rsp+0x30]
0000762f89bd55fb  vmovaps xmm4, [rsp+0x40]
0000762f89bd5601  vmovaps xmm5, [rsp+0x50]
0000762f89bd5607  vmovaps xmm6, [rsp+0x60]
0000762f89bd560d  vmovaps xmm7, [rsp+0x70]
0000762f89bd5613  vmovaps xmm8, [rsp+0x80]
0000762f89bd561c  vmovaps xmm9, [rsp+0x90]
0000762f89bd5625  vmovaps xmm10, [rsp+0xA0]
0000762f89bd562e  vmovaps xmm11, [rsp+0xB0]
0000762f89bd5637  vmovaps xmm12, [rsp+0xC0]
0000762f89bd5640  vmovaps xmm13, [rsp+0xD0]
0000762f89bd5649  vmovaps xmm15, [rsp+0xE0]
0000762f89bd5652  add rsp, 0xF0
0000762f89bd5659  pop r11
0000762f89bd565b  pop r10
0000762f89bd565d  pop r9
0000762f89bd565f  pop r8
0000762f89bd5661  pop rsi
0000762f89bd5662  pop rdi
0000762f89bd5663  pop rdx
0000762f89bd5664  pop rcx
0000762f89bd5665  pop rax
0000762f89bd5666  add rsp, 0x08
0000762f89bd566a  jmp 0x0000762F89BD031A
0000762f89bd566f  sub rsp, 0x08
0000762f89bd5673  push rax
0000762f89bd5674  push rcx
0000762f89bd5675  push rdx
0000762f89bd5676  push rdi
0000762f89bd5677  push rsi
0000762f89bd5678  push r8
0000762f89bd567a  push r9
0000762f89bd567c  push r10
0000762f89bd567e  push r11
0000762f89bd5680  sub rsp, 0xF0
0000762f89bd5687  vmovaps [rsp], xmm0
0000762f89bd568c  vmovaps [rsp+0x10], xmm2
0000762f89bd5692  vmovaps [rsp+0x20], xmm3
0000762f89bd5698  vmovaps [rsp+0x30], xmm4
0000762f89bd569e  vmovaps [rsp+0x40], xmm5
0000762f89bd56a4  vmovaps [rsp+0x50], xmm6
0000762f89bd56aa  vmovaps [rsp+0x60], xmm7
0000762f89bd56b0  vmovaps [rsp+0x70], xmm8
0000762f89bd56b6  vmovaps [rsp+0x80], xmm9
0000762f89bd56bf  vmovaps [rsp+0x90], xmm10
0000762f89bd56c8  vmovaps [rsp+0xA0], xmm11
0000762f89bd56d1  vmovaps [rsp+0xB0], xmm12
0000762f89bd56da  vmovaps [rsp+0xC0], xmm13
0000762f89bd56e3  vmovaps [rsp+0xD0], xmm14
0000762f89bd56ec  vmovaps [rsp+0xE0], xmm15
0000762f89bd56f5  sub rsp, 0x30
0000762f89bd56f9  movaps [rsp], xmm1
0000762f89bd56fd  movaps [rsp+0x10], xmm7
0000762f89bd5702  movaps [rsp+0x20], xmm11
0000762f89bd5708  lea rdi, [rsp]
0000762f89bd570c  mov esi, 0x00
0000762f89bd5711  mov rax, 0x604D6F946530
0000762f89bd571b  call rax
0000762f89bd571d  movaps xmm1, [rsp]
0000762f89bd5721  add rsp, 0x30
0000762f89bd5725  vmovaps xmm0, [rsp]
0000762f89bd572a  vmovaps xmm2, [rsp+0x10]
0000762f89bd5730  vmovaps xmm3, [rsp+0x20]
0000762f89bd5736  vmovaps xmm4, [rsp+0x30]
0000762f89bd573c  vmovaps xmm5, [rsp+0x40]
0000762f89bd5742  vmovaps xmm6, [rsp+0x50]
0000762f89bd5748  vmovaps xmm7, [rsp+0x60]
0000762f89bd574e  vmovaps xmm8, [rsp+0x70]
0000762f89bd5754  vmovaps xmm9, [rsp+0x80]
0000762f89bd575d  vmovaps xmm10, [rsp+0x90]
0000762f89bd5766  vmovaps xmm11, [rsp+0xA0]
0000762f89bd576f  vmovaps xmm12, [rsp+0xB0]
0000762f89bd5778  vmovaps xmm13, [rsp+0xC0]
0000762f89bd5781  vmovaps xmm14, [rsp+0xD0]
0000762f89bd578a  vmovaps xmm15, [rsp+0xE0]
0000762f89bd5793  add rsp, 0xF0
0000762f89bd579a  pop r11
0000762f89bd579c  pop r10
0000762f89bd579e  pop r9
0000762f89bd57a0  pop r8
0000762f89bd57a2  pop rsi
0000762f89bd57a3  pop rdi
0000762f89bd57a4  pop rdx
0000762f89bd57a5  pop rcx
0000762f89bd57a6  pop rax
0000762f89bd57a7  add rsp, 0x08
0000762f89bd57ab  jmp 0x0000762F89BD033B
0000762f89bd57b0  call 0x0000762F89A0E880
0000762f89bd57b5  jmp 0x0000762F89BD034E
0000762f89bd57ba  call 0x0000762F89A0C380
0000762f89bd57bf  jmp 0x0000762F89BD0359
0000762f89bd57c4  call 0x0000762F89A0D600
0000762f89bd57c9  jmp 0x0000762F89BD0364
0000762f89bd57ce  call 0x0000762F899FF540
0000762f89bd57d3  jmp 0x0000762F89BD036F
0000762f89bd57d8  int3
0000762f89bd57d9  nop [rax], eax
0000762f89bd57e0  mov rax, [r15+0x40]
0000762f89bd57e4  mov r14, [r15+0x58]
0000762f89bd57e8  lea r12, [rax+r14*1]
0000762f89bd57ec  movaps xmm1, [r15+0x1D0]
0000762f89bd57f4  vmovaps [rsp+0x10], xmm1
0000762f89bd57fa  vmovaps xmm15, [rsp+0x10]
0000762f89bd5800  por xmm1, xmm15
0000762f89bd5805  movaps xmm14, [r15+0x1A0]
0000762f89bd580d  vmovaps [rsp+0x10], xmm14
0000762f89bd5813  vmovaps xmm13, [rsp+0x10]
0000762f89bd5819  por xmm14, xmm13
0000762f89bd581e  lea rax, [r12+0x30]
0000762f89bd5823  mov r11, [r13+rax*1]
0000762f89bd5828  lea rax, [r12+0x38]
0000762f89bd582d  mov r10, [r13+rax*1]
0000762f89bd5832  movq xmm13, r11
0000762f89bd5837  movq xmm12, r10
0000762f89bd583c  movq xmm13, xmm13
0000762f89bd5841  vmovaps [rsp+0x10], xmm13
0000762f89bd5847  movq xmm13, xmm13
0000762f89bd584c  movaps [r15+0x130], xmm13
0000762f89bd5854  movq xmm12, xmm12
0000762f89bd5859  vmovaps [rsp+0x20], xmm12
0000762f89bd585f  movq xmm12, xmm12
0000762f89bd5864  movaps [r15+0x280], xmm12
0000762f89bd586c  movaps xmm13, [r15+0x270]
0000762f89bd5874  vmovaps [rsp+0x30], xmm13
0000762f89bd587a  vmovaps xmm12, [rsp+0x30]
0000762f89bd5880  por xmm13, xmm12
0000762f89bd5885  lea rax, [r12+0x20]
0000762f89bd588a  mov r11, [r13+rax*1]
0000762f89bd588f  lea rax, [r12+0x28]
0000762f89bd5894  mov r10, [r13+rax*1]
0000762f89bd5899  movq xmm12, r11
0000762f89bd589e  movq xmm11, r10
0000762f89bd58a3  movq xmm12, xmm12
0000762f89bd58a8  vmovaps [rsp+0x30], xmm12
0000762f89bd58ae  movq xmm12, xmm12
0000762f89bd58b3  movaps [r15+0x150], xmm12
0000762f89bd58bb  movq xmm11, xmm11
0000762f89bd58c0  vmovaps [rsp+0x40], xmm11
0000762f89bd58c6  movq xmm11, xmm11
0000762f89bd58cb  movaps [r15+0x140], xmm11
0000762f89bd58d3  lea rax, [r12+0x10]
0000762f89bd58d8  mov r11, [r13+rax*1]
0000762f89bd58dd  lea rax, [r12+0x18]
0000762f89bd58e2  mov r10, [r13+rax*1]
0000762f89bd58e7  movq xmm12, r11
0000762f89bd58ec  movq xmm11, r10
0000762f89bd58f1  movq xmm12, xmm12
0000762f89bd58f6  vmovaps [rsp+0x50], xmm12
0000762f89bd58fc  movq xmm12, xmm12
0000762f89bd5901  movaps [r15+0x170], xmm12
0000762f89bd5909  movq xmm11, xmm11
0000762f89bd590e  vmovaps [rsp+0x60], xmm11
0000762f89bd5914  movq xmm11, xmm11
0000762f89bd5919  movaps [r15+0x160], xmm11
0000762f89bd5921  mov rax, [r13+r12*1]
0000762f89bd5926  vmovq xmm12, rax
0000762f89bd592b  vpbroadcastq xmm12, xmm12
0000762f89bd5930  lea rax, [r12+0x08]
0000762f89bd5935  mov r12, [r13+rax*1]
0000762f89bd593a  movq xmm11, r12
0000762f89bd593f  movaps [r15+0x230], xmm11
0000762f89bd5947  mov rax, [r15+0xF8]
0000762f89bd594e  lea r12, [rax+0x50]
0000762f89bd5952  movups xmm11, [r13+r12*1]
0000762f89bd5958  lea r12, [rax+0x60]
0000762f89bd595c  movups xmm10, [r13+r12*1]
0000762f89bd5962  lea r12, [rax+0x30]
0000762f89bd5966  movups xmm9, [r13+r12*1]
0000762f89bd596c  mov r12, [r15+0x50]
0000762f89bd5970  lea r11, [r12+r14*1]
0000762f89bd5974  mov [r15+0x60], r11
0000762f89bd5978  lea r12, [r14+0x40]
0000762f89bd597c  mov [r15+0x58], r12
0000762f89bd5980  movaps xmm8, xmm12
0000762f89bd5984  mulpd xmm8, xmm15
0000762f89bd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000762f89bd598f  ptest xmm7, xmm7
0000762f89bd5994  jnz 0x0000762F89BD67B7
0000762f89bd599a  movq xmm15, qword ptr [r15+0x230]
0000762f89bd59a3  vmovaps [rsp+0x70], xmm15
0000762f89bd59a9  vpermilpd xmm15, xmm15, 0x00
0000762f89bd59af  movaps xmm7, xmm9
0000762f89bd59b3  mulpd xmm7, xmm15
0000762f89bd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000762f89bd59bd  ptest xmm6, xmm6
0000762f89bd59c2  jnz 0x0000762F89BD68FB
0000762f89bd59c8  vxorps xmm15, xmm15, xmm15
0000762f89bd59cd  vpbroadcastq xmm15, xmm15
0000762f89bd59d2  movaps xmm9, xmm12
0000762f89bd59d6  mulpd xmm9, xmm10
0000762f89bd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000762f89bd59e1  ptest xmm6, xmm6
0000762f89bd59e6  jnz 0x0000762F89BD6A3D
0000762f89bd59ec  movaps xmm10, xmm12
0000762f89bd59f0  mulpd xmm10, xmm11
0000762f89bd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000762f89bd59fb  ptest xmm6, xmm6
0000762f89bd5a00  jnz 0x0000762F89BD6B81
0000762f89bd5a06  movaps xmm11, [r15+0x1F0]
0000762f89bd5a0e  movaps xmm6, xmm12
0000762f89bd5a12  mulpd xmm6, xmm11
0000762f89bd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000762f89bd5a1c  ptest xmm5, xmm5
0000762f89bd5a21  jnz 0x0000762F89BD6CC5
0000762f89bd5a27  movaps xmm12, [r15+0x2A0]
0000762f89bd5a2f  vmovaps [rsp+0x80], xmm12
0000762f89bd5a38  vmovaps xmm11, [rsp+0x80]
0000762f89bd5a41  por xmm12, xmm11
0000762f89bd5a46  movaps xmm11, [r15+0x250]
0000762f89bd5a4e  vmovaps [rsp+0x80], xmm11
0000762f89bd5a57  vmovaps xmm5, [rsp+0x80]
0000762f89bd5a60  por xmm11, xmm5
0000762f89bd5a65  vmovaps xmm4, [rsp+0x70]
0000762f89bd5a6b  vpermilpd xmm4, xmm4, 0x00
0000762f89bd5a71  movaps xmm3, xmm5
0000762f89bd5a74  mulpd xmm3, xmm4
0000762f89bd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000762f89bd5a7d  ptest xmm2, xmm2
0000762f89bd5a82  jnz 0x0000762F89BD6E07
0000762f89bd5a88  mov [rsp+0x80], rax
0000762f89bd5a90  xor eax, eax
0000762f89bd5a92  mov r14d, 0x200
0000762f89bd5a98  cmp r12, r14
0000762f89bd5a9b  cmc
0000762f89bd5a9c  lahf
0000762f89bd5a9d  seto al
0000762f89bd5aa0  mov [r15+0x108], eax
0000762f89bd5aa7  movaps xmm5, xmm8
0000762f89bd5aab  addpd xmm5, xmm15
0000762f89bd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000762f89bd5ab5  ptest xmm4, xmm4
0000762f89bd5aba  jnz 0x0000762F89BD6F47
0000762f89bd5ac0  movaps xmm8, [r15+0x1B0]
0000762f89bd5ac8  movaps xmm4, xmm9
0000762f89bd5acc  addpd xmm4, xmm8
0000762f89bd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000762f89bd5ad6  ptest xmm2, xmm2
0000762f89bd5adb  jnz 0x0000762F89BD7089
0000762f89bd5ae1  movaps xmm9, xmm10
0000762f89bd5ae5  addpd xmm9, xmm8
0000762f89bd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000762f89bd5af0  ptest xmm2, xmm2
0000762f89bd5af5  jnz 0x0000762F89BD71CB
0000762f89bd5afb  movaps xmm10, [r15+0x2F0]
0000762f89bd5b03  vmovaps [rsp+0x90], xmm10
0000762f89bd5b0c  vmovaps xmm8, [rsp+0x90]
0000762f89bd5b15  por xmm10, xmm8
0000762f89bd5b1a  movaps xmm8, [r15+0x2E0]
0000762f89bd5b22  vmovaps [rsp+0x90], xmm8
0000762f89bd5b2b  vmovaps xmm2, [rsp+0x90]
0000762f89bd5b34  por xmm8, xmm2
0000762f89bd5b39  movaps xmm2, [r15+0x2D0]
0000762f89bd5b41  vmovaps [rsp+0x90], xmm2
0000762f89bd5b4a  vmovaps [rsp+0xA0], xmm1
0000762f89bd5b53  vmovaps xmm1, [rsp+0x90]
0000762f89bd5b5c  por xmm2, xmm1
0000762f89bd5b60  movaps xmm1, [r15+0x200]
0000762f89bd5b68  vmovaps [rsp+0x90], xmm1
0000762f89bd5b71  vmovaps [rsp+0xB0], xmm15
0000762f89bd5b7a  vmovaps xmm15, [rsp+0x90]
0000762f89bd5b83  por xmm1, xmm15
0000762f89bd5b88  movaps xmm15, [r15+0x1C0]
0000762f89bd5b90  vmovaps [rsp+0x90], xmm15
0000762f89bd5b99  vmovaps [rsp+0xC0], xmm1
0000762f89bd5ba2  vmovaps xmm1, [rsp+0x90]
0000762f89bd5bab  por xmm15, xmm1
0000762f89bd5bb0  movaps xmm1, [r15+0x190]
0000762f89bd5bb8  vmovaps [rsp+0x90], xmm1
0000762f89bd5bc1  vmovaps [rsp+0xD0], xmm15
0000762f89bd5bca  vmovaps xmm15, [rsp+0x90]
0000762f89bd5bd3  por xmm1, xmm15
0000762f89bd5bd8  movaps xmm15, [r15+0x300]
0000762f89bd5be0  vmovaps [rsp+0x90], xmm15
0000762f89bd5be9  vmovaps [rsp+0xE0], xmm1
0000762f89bd5bf2  vmovaps xmm1, [rsp+0x90]
0000762f89bd5bfb  por xmm15, xmm1
0000762f89bd5c00  mov rax, [rsp+0x80]
0000762f89bd5c08  lea r14, [rax+0xA0]
0000762f89bd5c0f  movups xmm1, [r13+r14*1]
0000762f89bd5c15  lea r14, [rax+0xB0]
0000762f89bd5c1c  vmovaps [rsp+0x80], xmm1
0000762f89bd5c25  movups xmm1, [r13+r14*1]
0000762f89bd5c2b  vmovaps [rsp+0x90], xmm1
0000762f89bd5c34  vmovaps [rsp+0xF0], xmm15
0000762f89bd5c3d  vmovaps xmm15, [rsp+0xB0]
0000762f89bd5c46  vmovaps [rsp+0xB0], xmm14
0000762f89bd5c4f  movaps xmm1, xmm6
0000762f89bd5c52  addpd xmm1, xmm15
0000762f89bd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000762f89bd5c5c  ptest xmm14, xmm14
0000762f89bd5c62  jnz 0x0000762F89BD7323
0000762f89bd5c68  lea r14, [rax+0xF0]
0000762f89bd5c6f  movups xmm15, [r13+r14*1]
0000762f89bd5c75  movaps xmm14, xmm4
0000762f89bd5c79  addpd xmm14, xmm3
0000762f89bd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000762f89bd5c84  ptest xmm6, xmm6
0000762f89bd5c89  jnz 0x0000762F89BD746E
0000762f89bd5c8f  movaps xmm6, xmm9
0000762f89bd5c93  addpd xmm6, xmm7
0000762f89bd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000762f89bd5c9c  ptest xmm4, xmm4
0000762f89bd5ca1  jnz 0x0000762F89BD75B0
0000762f89bd5ca7  vmovaps xmm9, [rsp+0x70]
0000762f89bd5cad  vpermilpd xmm9, xmm9, 0x00
0000762f89bd5cb3  vmovaps xmm4, [rsp+0x90]
0000762f89bd5cbc  movaps xmm7, xmm4
0000762f89bd5cbf  mulpd xmm7, xmm9
0000762f89bd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000762f89bd5cc9  ptest xmm3, xmm3
0000762f89bd5cce  jnz 0x0000762F89BD76F1
0000762f89bd5cd4  vmovaps xmm9, [rsp+0x50]
0000762f89bd5cda  vpermilpd xmm9, xmm9, 0x00
0000762f89bd5ce0  movaps xmm4, xmm15
0000762f89bd5ce4  mulpd xmm4, xmm9
0000762f89bd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000762f89bd5cee  ptest xmm3, xmm3
0000762f89bd5cf3  jnz 0x0000762F89BD7832
0000762f89bd5cf9  lea r14, [rax+0xE0]
0000762f89bd5d00  movups xmm15, [r13+r14*1]
0000762f89bd5d06  vmovaps xmm9, [rsp+0x70]
0000762f89bd5d0c  vpermilpd xmm9, xmm9, 0x00
0000762f89bd5d12  vmovaps [rsp+0x70], xmm1
0000762f89bd5d18  vmovaps xmm1, [rsp+0x80]
0000762f89bd5d21  vmovaps [rsp+0x80], xmm15
0000762f89bd5d2a  movaps xmm3, xmm1
0000762f89bd5d2d  mulpd xmm3, xmm9
0000762f89bd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000762f89bd5d37  ptest xmm15, xmm15
0000762f89bd5d3d  jnz 0x0000762F89BD797E
0000762f89bd5d43  vmovaps xmm1, [rsp+0xF0]
0000762f89bd5d4c  vmovaps xmm15, [rsp+0xF0]
0000762f89bd5d55  por xmm1, xmm15
0000762f89bd5d5a  movaps [r15+0x300], xmm1
0000762f89bd5d62  vmovaps xmm15, [rsp+0xE0]
0000762f89bd5d6b  vmovaps xmm9, [rsp+0xE0]
0000762f89bd5d74  por xmm15, xmm9
0000762f89bd5d79  movaps [r15+0x190], xmm15
0000762f89bd5d81  vmovaps xmm9, [rsp+0x50]
0000762f89bd5d87  vpermilpd xmm9, xmm9, 0x00
0000762f89bd5d8d  vmovaps [rsp+0x90], xmm1
0000762f89bd5d96  vmovaps [rsp+0xE0], xmm15
0000762f89bd5d9f  vmovaps xmm15, [rsp+0x80]
0000762f89bd5da8  vmovaps [rsp+0x80], xmm14
0000762f89bd5db1  movaps xmm1, xmm15
0000762f89bd5db5  mulpd xmm1, xmm9
0000762f89bd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000762f89bd5dbf  ptest xmm14, xmm14
0000762f89bd5dc5  jnz 0x0000762F89BD7ABF
0000762f89bd5dcb  lea r14, [rax+0x90]
0000762f89bd5dd2  movups xmm15, [r13+r14*1]
0000762f89bd5dd8  vmovaps xmm14, [rsp+0xD0]
0000762f89bd5de1  vmovaps xmm9, [rsp+0xD0]
0000762f89bd5dea  por xmm14, xmm9
0000762f89bd5def  movaps [r15+0x1C0], xmm14
0000762f89bd5df7  vmovaps xmm9, [rsp+0xC0]
0000762f89bd5e00  vmovaps [rsp+0xD0], xmm1
0000762f89bd5e09  vmovaps xmm1, [rsp+0xC0]
0000762f89bd5e12  por xmm9, xmm1
0000762f89bd5e17  movaps [r15+0x200], xmm9
0000762f89bd5e1f  vmovaps [rsp+0xC0], xmm2
0000762f89bd5e28  vmovaps xmm1, [rsp+0xC0]
0000762f89bd5e31  por xmm2, xmm1
0000762f89bd5e35  movaps [r15+0x2D0], xmm2
0000762f89bd5e3d  vmovaps [rsp+0xC0], xmm8
0000762f89bd5e46  vmovaps xmm1, [rsp+0xC0]
0000762f89bd5e4f  por xmm8, xmm1
0000762f89bd5e54  movaps [r15+0x2E0], xmm8
0000762f89bd5e5c  vmovaps [rsp+0xC0], xmm15
0000762f89bd5e65  movaps xmm1, xmm5
0000762f89bd5e68  addpd xmm1, xmm7
0000762f89bd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000762f89bd5e71  ptest xmm15, xmm15
0000762f89bd5e77  jnz 0x0000762F89BD7C0B
0000762f89bd5e7d  vmovaps xmm15, [rsp+0x50]
0000762f89bd5e83  vpermilpd xmm15, xmm15, 0x00
0000762f89bd5e89  vmovaps xmm5, [rsp+0xC0]
0000762f89bd5e92  vmovaps [rsp+0xC0], xmm1
0000762f89bd5e9b  movaps xmm7, xmm5
0000762f89bd5e9e  mulpd xmm7, xmm15
0000762f89bd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000762f89bd5ea8  ptest xmm1, xmm1
0000762f89bd5ead  jnz 0x0000762F89BD7D4B
0000762f89bd5eb3  lea r14, [rax+0x80]
0000762f89bd5eba  movups xmm1, [r13+r14*1]
0000762f89bd5ec0  vmovaps xmm5, [rsp+0x70]
0000762f89bd5ec6  vmovaps [rsp+0x70], xmm1
0000762f89bd5ecc  movaps xmm15, xmm5
0000762f89bd5ed0  addpd xmm15, xmm3
0000762f89bd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000762f89bd5edb  ptest xmm1, xmm1
0000762f89bd5ee0  jnz 0x0000762F89BD7E96
0000762f89bd5ee6  vmovaps xmm5, [rsp+0x80]
0000762f89bd5eef  movaps xmm1, xmm5
0000762f89bd5ef2  addpd xmm1, xmm4
0000762f89bd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000762f89bd5efb  ptest xmm3, xmm3
0000762f89bd5f00  jnz 0x0000762F89BD7FD8
0000762f89bd5f06  vmovaps [rsp+0x80], xmm10
0000762f89bd5f0f  vmovaps xmm5, [rsp+0x80]
0000762f89bd5f18  por xmm10, xmm5
0000762f89bd5f1d  movaps [r15+0x2F0], xmm10
0000762f89bd5f25  vmovaps xmm5, [rsp+0x50]
0000762f89bd5f2b  vpermilpd xmm5, xmm5, 0x00
0000762f89bd5f31  vmovaps xmm3, [rsp+0x70]
0000762f89bd5f37  vmovaps [rsp+0x50], xmm1
0000762f89bd5f3d  movaps xmm4, xmm3
0000762f89bd5f40  mulpd xmm4, xmm5
0000762f89bd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000762f89bd5f49  ptest xmm1, xmm1
0000762f89bd5f4e  jnz 0x0000762F89BD8118
0000762f89bd5f54  lea r14, [rax+0xD0]
0000762f89bd5f5b  movups xmm1, [r13+r14*1]
0000762f89bd5f61  vmovaps xmm3, [rsp+0xD0]
0000762f89bd5f6a  vmovaps [rsp+0x70], xmm1
0000762f89bd5f70  movaps xmm5, xmm6
0000762f89bd5f73  addpd xmm5, xmm3
0000762f89bd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000762f89bd5f7c  ptest xmm1, xmm1
0000762f89bd5f81  jnz 0x0000762F89BD8262
0000762f89bd5f87  vmovaps xmm1, [rsp+0x60]
0000762f89bd5f8d  vpermilpd xmm1, xmm1, 0x00
0000762f89bd5f93  movaps xmm6, xmm9
0000762f89bd5f97  mulpd xmm6, xmm1
0000762f89bd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000762f89bd5fa0  ptest xmm3, xmm3
0000762f89bd5fa5  jnz 0x0000762F89BD83A2
0000762f89bd5fab  movaps [r15+0x260], xmm6
0000762f89bd5fb3  vxorps xmm1, xmm1, xmm1
0000762f89bd5fb7  vpbroadcastq xmm1, xmm1
0000762f89bd5fbc  movaps [r15+0x1B0], xmm1
0000762f89bd5fc4  vmovaps xmm1, [rsp+0x60]
0000762f89bd5fca  vpermilpd xmm1, xmm1, 0x00
0000762f89bd5fd0  vmovaps xmm3, [rsp+0x70]
0000762f89bd5fd6  vmovaps [rsp+0x70], xmm15
0000762f89bd5fdc  movaps xmm9, xmm3
0000762f89bd5fe0  mulpd xmm9, xmm1
0000762f89bd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000762f89bd5feb  ptest xmm15, xmm15
0000762f89bd5ff1  jnz 0x0000762F89BD84E3
0000762f89bd5ff7  lea r14, [rax+0xC0]
0000762f89bd5ffe  movups xmm1, [r13+r14*1]
0000762f89bd6004  vmovaps xmm3, [rsp+0xC0]
0000762f89bd600d  vmovaps [rsp+0x80], xmm1
0000762f89bd6016  movaps xmm15, xmm3
0000762f89bd601a  addpd xmm15, xmm7
0000762f89bd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000762f89bd6025  ptest xmm1, xmm1
0000762f89bd602a  jnz 0x0000762F89BD862F
0000762f89bd6030  vmovaps [rsp+0xC0], xmm13
0000762f89bd6039  vmovaps xmm1, [rsp+0xC0]
0000762f89bd6042  por xmm13, xmm1
0000762f89bd6047  movaps [r15+0x270], xmm13
0000762f89bd604f  vmovaps xmm1, [rsp+0xB0]
0000762f89bd6058  vmovaps xmm7, [rsp+0xB0]
0000762f89bd6061  por xmm1, xmm7
0000762f89bd6065  movaps [r15+0x1A0], xmm1
0000762f89bd606d  vmovaps xmm1, [rsp+0x60]
0000762f89bd6073  vpermilpd xmm1, xmm1, 0x00
0000762f89bd6079  vmovaps [rsp+0xB0], xmm1
0000762f89bd6082  vmovaps xmm1, [rsp+0x80]
0000762f89bd608b  vmovaps [rsp+0x80], xmm15
0000762f89bd6094  vmovaps xmm15, [rsp+0xB0]
0000762f89bd609d  vmovaps [rsp+0xB0], xmm14
0000762f89bd60a6  movaps xmm3, xmm1
0000762f89bd60a9  mulpd xmm3, xmm15
0000762f89bd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000762f89bd60b3  ptest xmm14, xmm14
0000762f89bd60b9  jnz 0x0000762F89BD8771
0000762f89bd60bf  lea r14, [rax+0x20]
0000762f89bd60c3  movups xmm1, [r13+r14*1]
0000762f89bd60c9  movaps [r15+0x110], xmm1
0000762f89bd60d1  vmovaps xmm14, [rsp+0x70]
0000762f89bd60d7  vmovaps [rsp+0x70], xmm1
0000762f89bd60dd  movaps xmm15, xmm14
0000762f89bd60e1  addpd xmm15, xmm4
0000762f89bd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000762f89bd60ec  ptest xmm1, xmm1
0000762f89bd60f1  jnz 0x0000762F89BD88BC
0000762f89bd60f7  vmovaps xmm1, [rsp+0x60]
0000762f89bd60fd  vpermilpd xmm1, xmm1, 0x00
0000762f89bd6103  movaps xmm14, xmm2
0000762f89bd6107  mulpd xmm14, xmm1
0000762f89bd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000762f89bd6112  ptest xmm4, xmm4
0000762f89bd6117  jnz 0x0000762F89BD89FF
0000762f89bd611d  vmovaps xmm4, [rsp+0x50]
0000762f89bd6123  movaps xmm1, xmm4
0000762f89bd6126  addpd xmm1, xmm9
0000762f89bd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000762f89bd6130  ptest xmm2, xmm2
0000762f89bd6135  jnz 0x0000762F89BD8B41
0000762f89bd613b  vmovaps xmm9, [rsp+0x30]
0000762f89bd6141  vpermilpd xmm9, xmm9, 0x00
0000762f89bd6147  vmovaps xmm2, [rsp+0x70]
0000762f89bd614d  vmovaps [rsp+0x50], xmm1
0000762f89bd6153  movaps xmm4, xmm2
0000762f89bd6156  mulpd xmm4, xmm9
0000762f89bd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000762f89bd6160  ptest xmm1, xmm1
0000762f89bd6165  jnz 0x0000762F89BD8C82
0000762f89bd616b  vmovaps xmm1, [rsp+0x30]
0000762f89bd6171  vpermilpd xmm1, xmm1, 0x00
0000762f89bd6177  vmovaps xmm2, [rsp+0x90]
0000762f89bd6180  vmovaps [rsp+0x60], xmm15
0000762f89bd6186  movaps xmm9, xmm2
0000762f89bd618a  mulpd xmm9, xmm1
0000762f89bd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000762f89bd6195  ptest xmm15, xmm15
0000762f89bd619b  jnz 0x0000762F89BD8DC3
0000762f89bd61a1  vmovaps xmm15, [rsp+0x80]
0000762f89bd61aa  movaps xmm1, xmm15
0000762f89bd61ae  addpd xmm1, xmm6
0000762f89bd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000762f89bd61b7  ptest xmm2, xmm2
0000762f89bd61bc  jnz 0x0000762F89BD8F05
0000762f89bd61c2  movaps xmm15, xmm5
0000762f89bd61c6  addpd xmm15, xmm3
0000762f89bd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000762f89bd61d1  ptest xmm6, xmm6
0000762f89bd61d6  jnz 0x0000762F89BD9046
0000762f89bd61dc  vmovaps xmm6, [rsp+0x30]
0000762f89bd61e2  vpermilpd xmm6, xmm6, 0x00
0000762f89bd61e8  movaps xmm5, xmm8
0000762f89bd61ec  mulpd xmm5, xmm6
0000762f89bd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000762f89bd61f5  ptest xmm3, xmm3
0000762f89bd61fa  jnz 0x0000762F89BD9188
0000762f89bd6200  vmovaps xmm8, [rsp+0x30]
0000762f89bd6206  vpermilpd xmm8, xmm8, 0x00
0000762f89bd620c  movaps xmm6, xmm10
0000762f89bd6210  mulpd xmm6, xmm8
0000762f89bd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000762f89bd621a  ptest xmm3, xmm3
0000762f89bd621f  jnz 0x0000762F89BD92C9
0000762f89bd6225  vmovaps xmm8, [rsp+0x60]
0000762f89bd622b  movaps xmm10, xmm8
0000762f89bd622f  addpd xmm10, xmm14
0000762f89bd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000762f89bd623a  ptest xmm3, xmm3
0000762f89bd623f  jnz 0x0000762F89BD940B
0000762f89bd6245  vmovaps xmm8, [rsp+0x50]
0000762f89bd624b  movaps xmm14, xmm8
0000762f89bd624f  addpd xmm14, xmm4
0000762f89bd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000762f89bd625a  ptest xmm3, xmm3
0000762f89bd625f  jnz 0x0000762F89BD954F
0000762f89bd6265  vmovaps xmm8, [rsp+0x40]
0000762f89bd626b  vpermilpd xmm8, xmm8, 0x00
0000762f89bd6271  movaps xmm4, xmm13
0000762f89bd6275  mulpd xmm4, xmm8
0000762f89bd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000762f89bd627f  ptest xmm3, xmm3
0000762f89bd6284  jnz 0x0000762F89BD9692
0000762f89bd628a  movaps xmm13, xmm15
0000762f89bd628e  addpd xmm13, xmm9
0000762f89bd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000762f89bd6299  ptest xmm8, xmm8
0000762f89bd629f  jnz 0x0000762F89BD97D4
0000762f89bd62a5  movaps xmm15, xmm1
0000762f89bd62a9  addpd xmm15, xmm5
0000762f89bd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000762f89bd62b4  ptest xmm9, xmm9
0000762f89bd62ba  jnz 0x0000762F89BD9918
0000762f89bd62c0  vmovaps [rsp+0x30], xmm11
0000762f89bd62c6  vmovaps xmm1, [rsp+0x30]
0000762f89bd62cc  por xmm11, xmm1
0000762f89bd62d1  movaps [r15+0x250], xmm11
0000762f89bd62d9  vmovaps [rsp+0x30], xmm12
0000762f89bd62df  vmovaps xmm1, [rsp+0x30]
0000762f89bd62e5  por xmm12, xmm1
0000762f89bd62ea  movaps [r15+0x2A0], xmm12
0000762f89bd62f2  vmovaps xmm1, [rsp+0xA0]
0000762f89bd62fb  vmovaps xmm11, [rsp+0xA0]
0000762f89bd6304  por xmm1, xmm11
0000762f89bd6309  movaps [r15+0x1D0], xmm1
0000762f89bd6311  lea r14, [rax+0x40]
0000762f89bd6315  movups xmm1, [r13+r14*1]
0000762f89bd631b  movaps [r15+0x2C0], xmm1
0000762f89bd6323  vmovaps xmm11, [rsp+0x40]
0000762f89bd6329  vpermilpd xmm11, xmm11, 0x00
0000762f89bd632f  vmovaps xmm8, [rsp+0xE0]
0000762f89bd6338  movaps xmm9, xmm8
0000762f89bd633c  mulpd xmm9, xmm11
0000762f89bd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000762f89bd6347  ptest xmm5, xmm5
0000762f89bd634c  jnz 0x0000762F89BD9A64
0000762f89bd6352  movaps xmm11, xmm10
0000762f89bd6356  addpd xmm11, xmm6
0000762f89bd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000762f89bd6361  ptest xmm8, xmm8
0000762f89bd6367  jnz 0x0000762F89BD9BA8
0000762f89bd636d  movaps xmm10, xmm14
0000762f89bd6371  addpd xmm10, xmm4
0000762f89bd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000762f89bd637c  ptest xmm8, xmm8
0000762f89bd6382  jnz 0x0000762F89BD9CEB
0000762f89bd6388  vmovaps xmm14, [rsp+0x40]
0000762f89bd638e  vpermilpd xmm14, xmm14, 0x00
0000762f89bd6394  movaps xmm8, xmm1
0000762f89bd6398  mulpd xmm8, xmm14
0000762f89bd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000762f89bd63a3  ptest xmm6, xmm6
0000762f89bd63a8  jnz 0x0000762F89BD9E2E
0000762f89bd63ae  movaps xmm1, [r15+0x2B0]
0000762f89bd63b6  vmovaps xmm14, [rsp+0x40]
0000762f89bd63bc  vpermilpd xmm14, xmm14, 0x00
0000762f89bd63c2  movaps xmm6, xmm1
0000762f89bd63c5  mulpd xmm6, xmm14
0000762f89bd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000762f89bd63cf  ptest xmm5, xmm5
0000762f89bd63d4  jnz 0x0000762F89BD9F71
0000762f89bd63da  vmovaps xmm1, [rsp+0x10]
0000762f89bd63e0  vpermilpd xmm1, xmm1, 0x00
0000762f89bd63e6  movaps xmm14, xmm12
0000762f89bd63ea  mulpd xmm14, xmm1
0000762f89bd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000762f89bd63f5  ptest xmm5, xmm5
0000762f89bd63fa  jnz 0x0000762F89BDA0B2
0000762f89bd6400  movaps xmm1, xmm13
0000762f89bd6404  addpd xmm1, xmm9
0000762f89bd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000762f89bd640e  ptest xmm12, xmm12
0000762f89bd6414  jnz 0x0000762F89BDA1F5
0000762f89bd641a  vmovaps xmm13, [rsp+0x10]
0000762f89bd6420  vpermilpd xmm13, xmm13, 0x00
0000762f89bd6426  movaps xmm12, xmm7
0000762f89bd642a  mulpd xmm12, xmm13
0000762f89bd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000762f89bd6435  ptest xmm9, xmm9
0000762f89bd643b  jnz 0x0000762F89BDA337
0000762f89bd6441  movaps xmm13, xmm15
0000762f89bd6445  addpd xmm13, xmm8
0000762f89bd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000762f89bd6450  ptest xmm9, xmm9
0000762f89bd6456  jnz 0x0000762F89BDA47A
0000762f89bd645c  movaps xmm15, [r15+0x290]
0000762f89bd6464  vmovaps xmm9, [rsp+0x10]
0000762f89bd646a  vpermilpd xmm9, xmm9, 0x00
0000762f89bd6470  movaps xmm8, xmm15
0000762f89bd6474  mulpd xmm8, xmm9
0000762f89bd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000762f89bd647f  ptest xmm7, xmm7
0000762f89bd6484  jnz 0x0000762F89BDA5BE
0000762f89bd648a  movaps xmm15, xmm11
0000762f89bd648e  addpd xmm15, xmm6
0000762f89bd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000762f89bd6499  ptest xmm9, xmm9
0000762f89bd649f  jnz 0x0000762F89BDA702
0000762f89bd64a5  movaps xmm11, [r15+0x1E0]
0000762f89bd64ad  vmovaps xmm9, [rsp+0x10]
0000762f89bd64b3  vpermilpd xmm9, xmm9, 0x00
0000762f89bd64b9  movaps xmm7, xmm11
0000762f89bd64bd  mulpd xmm7, xmm9
0000762f89bd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000762f89bd64c7  ptest xmm6, xmm6
0000762f89bd64cc  jnz 0x0000762F89BDA845
0000762f89bd64d2  movaps xmm11, xmm10
0000762f89bd64d6  addpd xmm11, xmm14
0000762f89bd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000762f89bd64e1  ptest xmm9, xmm9
0000762f89bd64e7  jnz 0x0000762F89BDA987
0000762f89bd64ed  lea r14, [rax+0x70]
0000762f89bd64f1  movups xmm14, [r13+r14*1]
0000762f89bd64f7  movaps [r15+0x240], xmm14
0000762f89bd64ff  movaps xmm10, xmm1
0000762f89bd6503  addpd xmm10, xmm12
0000762f89bd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000762f89bd650e  ptest xmm9, xmm9
0000762f89bd6514  jnz 0x0000762F89BDAAD5
0000762f89bd651a  movaps [r15+0x170], xmm10
0000762f89bd6522  vmovaps xmm1, [rsp+0x20]
0000762f89bd6528  vpermilpd xmm1, xmm1, 0x00
0000762f89bd652e  movaps xmm12, xmm14
0000762f89bd6532  mulpd xmm12, xmm1
0000762f89bd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000762f89bd653d  ptest xmm9, xmm9
0000762f89bd6543  jnz 0x0000762F89BDAC18
0000762f89bd6549  vmovaps xmm1, [rsp+0x20]
0000762f89bd654f  vpermilpd xmm1, xmm1, 0x00
0000762f89bd6555  vmovaps xmm9, [rsp+0xB0]
0000762f89bd655e  movaps xmm14, xmm9
0000762f89bd6562  mulpd xmm14, xmm1
0000762f89bd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000762f89bd656d  ptest xmm6, xmm6
0000762f89bd6572  jnz 0x0000762F89BDAD5B
0000762f89bd6578  movaps [r15+0x180], xmm14
0000762f89bd6580  movaps xmm1, xmm13
0000762f89bd6584  addpd xmm1, xmm8
0000762f89bd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000762f89bd658e  ptest xmm9, xmm9
0000762f89bd6594  jnz 0x0000762F89BDAE9E
0000762f89bd659a  movaps [r15+0x210], xmm1
0000762f89bd65a2  movups xmm13, [r13+rax*1]
0000762f89bd65a8  lea r14, [rax+0x10]
0000762f89bd65ac  movups xmm9, [r13+r14*1]
0000762f89bd65b2  movaps [r15+0x230], xmm9
0000762f89bd65ba  movaps xmm8, xmm15
0000762f89bd65be  addpd xmm8, xmm7
0000762f89bd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000762f89bd65c9  ptest xmm6, xmm6
0000762f89bd65ce  jnz 0x0000762F89BDAFF4
0000762f89bd65d4  movaps [r15+0x130], xmm8
0000762f89bd65dc  vmovaps xmm15, [rsp+0x20]
0000762f89bd65e2  vpermilpd xmm15, xmm15, 0x00
0000762f89bd65e8  movaps xmm7, xmm9
0000762f89bd65ec  mulpd xmm7, xmm15
0000762f89bd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000762f89bd65f6  ptest xmm6, xmm6
0000762f89bd65fb  jnz 0x0000762F89BDB137
0000762f89bd6601  movaps [r15+0x220], xmm7
0000762f89bd6609  vmovaps xmm15, [rsp+0x20]
0000762f89bd660f  vpermilpd xmm15, xmm15, 0x00
0000762f89bd6615  movaps xmm9, xmm13
0000762f89bd6619  mulpd xmm9, xmm15
0000762f89bd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000762f89bd6624  ptest xmm6, xmm6
0000762f89bd6629  jnz 0x0000762F89BDB279
0000762f89bd662f  movaps xmm15, xmm11
0000762f89bd6633  addpd xmm15, xmm12
0000762f89bd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000762f89bd663e  ptest xmm13, xmm13
0000762f89bd6644  jnz 0x0000762F89BDB3BD
0000762f89bd664a  movaps [r15+0x140], xmm15
0000762f89bd6652  movaps xmm13, xmm10
0000762f89bd6656  addpd xmm13, xmm14
0000762f89bd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000762f89bd6661  ptest xmm12, xmm12
0000762f89bd6667  jnz 0x0000762F89BDB501
0000762f89bd666d  movaps [r15+0x150], xmm13
0000762f89bd6675  movaps xmm14, xmm1
0000762f89bd6679  addpd xmm14, xmm7
0000762f89bd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000762f89bd6684  ptest xmm12, xmm12
0000762f89bd668a  jnz 0x0000762F89BDB645
0000762f89bd6690  movaps [r15+0x160], xmm14
0000762f89bd6698  movaps xmm1, xmm8
0000762f89bd669c  addpd xmm1, xmm9
0000762f89bd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000762f89bd66a6  ptest xmm12, xmm12
0000762f89bd66ac  jnz 0x0000762F89BDB787
0000762f89bd66b2  movaps [r15+0x120], xmm1
0000762f89bd66ba  movups [r13+r11*1], xmm15
0000762f89bd66c0  lea rax, [r11+0x10]
0000762f89bd66c4  movups [r13+rax*1], xmm13
0000762f89bd66ca  lea rax, [r11+0x20]
0000762f89bd66ce  movups [r13+rax*1], xmm14
0000762f89bd66d4  lea rax, [r11+0x30]
0000762f89bd66d8  movups [r13+rax*1], xmm1
0000762f89bd66de  mov eax, [r15+0x108]
0000762f89bd66e5  sahf
0000762f89bd66e6  jnz 0x0000762F89BD6718
0000762f89bd66e8  cmp dword ptr [r15+0x318], 0x00
0000762f89bd66f0  jz 0x0000762F89BDB900
0000762f89bd66f6  nop [rax+rax*1], ax
0000762f89bd66ff  nop [rax+rax*1], eax
0000762f89bd6707  mov eax, 0x410444
0000762f89bd670c  mov [r15+0x100], rax
0000762f89bd6713  jmp 0x0000762F899FE110
0000762f89bd6718  cmp dword ptr [r15+0x318], 0x00
0000762f89bd6720  jz 0x0000762F89BD57E0
0000762f89bd6726  nop [rax+rax*1], ax
0000762f89bd672f  nop [rax+rax*1], eax
0000762f89bd6737  mov eax, 0x410278
0000762f89bd673c  mov [r15+0x100], rax
0000762f89bd6743  jmp 0x0000762F899FE110
0000762f89bd6748  int3
0000762f89bd6749  call 0x0000762F89A0A4B0
0000762f89bd674e  jmp 0x0000762F89BD5828
0000762f89bd6753  call 0x0000762F89A09240
0000762f89bd6758  jmp 0x0000762F89BD5832
0000762f89bd675d  call 0x0000762F89A0A4B0
0000762f89bd6762  jmp 0x0000762F89BD588F
0000762f89bd6767  call 0x0000762F89A09240
0000762f89bd676c  jmp 0x0000762F89BD5899
0000762f89bd6771  call 0x0000762F89A0A4B0
0000762f89bd6776  jmp 0x0000762F89BD58DD
0000762f89bd677b  call 0x0000762F89A09240
0000762f89bd6780  jmp 0x0000762F89BD58E7
0000762f89bd6785  call 0x0000762F89AB47C0
0000762f89bd678a  jmp 0x0000762F89BD5926
0000762f89bd678f  call 0x0000762F89A0B720
0000762f89bd6794  jmp 0x0000762F89BD593A
0000762f89bd6799  call 0x0000762F89ABFC30
0000762f89bd679e  jmp 0x0000762F89BD5958
0000762f89bd67a3  call 0x0000762F89ABE9C0
0000762f89bd67a8  jmp 0x0000762F89BD5962
0000762f89bd67ad  call 0x0000762F89ABD750
0000762f89bd67b2  jmp 0x0000762F89BD596C
0000762f89bd67b7  sub rsp, 0x08
0000762f89bd67bb  push rax
0000762f89bd67bc  push rcx
0000762f89bd67bd  push rdx
0000762f89bd67be  push rdi
0000762f89bd67bf  push rsi
0000762f89bd67c0  push r8
0000762f89bd67c2  push r9
0000762f89bd67c4  push r10
0000762f89bd67c6  push r11
0000762f89bd67c8  sub rsp, 0xF0
0000762f89bd67cf  vmovaps [rsp], xmm0
0000762f89bd67d4  vmovaps [rsp+0x10], xmm1
0000762f89bd67da  vmovaps [rsp+0x20], xmm2
0000762f89bd67e0  vmovaps [rsp+0x30], xmm3
0000762f89bd67e6  vmovaps [rsp+0x40], xmm4
0000762f89bd67ec  vmovaps [rsp+0x50], xmm5
0000762f89bd67f2  vmovaps [rsp+0x60], xmm6
0000762f89bd67f8  vmovaps [rsp+0x70], xmm7
0000762f89bd67fe  vmovaps [rsp+0x80], xmm9
0000762f89bd6807  vmovaps [rsp+0x90], xmm10
0000762f89bd6810  vmovaps [rsp+0xA0], xmm11
0000762f89bd6819  vmovaps [rsp+0xB0], xmm12
0000762f89bd6822  vmovaps [rsp+0xC0], xmm13
0000762f89bd682b  vmovaps [rsp+0xD0], xmm14
0000762f89bd6834  vmovaps [rsp+0xE0], xmm15
0000762f89bd683d  sub rsp, 0x30
0000762f89bd6841  movaps [rsp], xmm8
0000762f89bd6846  movaps [rsp+0x10], xmm12
0000762f89bd684c  movaps [rsp+0x20], xmm15
0000762f89bd6852  lea rdi, [rsp]
0000762f89bd6856  mov esi, 0x00
0000762f89bd685b  mov rax, 0x604D6F946530
0000762f89bd6865  call rax
0000762f89bd6867  movaps xmm8, [rsp]
0000762f89bd686c  add rsp, 0x30
0000762f89bd6870  vmovaps xmm0, [rsp]
0000762f89bd6875  vmovaps xmm1, [rsp+0x10]
0000762f89bd687b  vmovaps xmm2, [rsp+0x20]
0000762f89bd6881  vmovaps xmm3, [rsp+0x30]
0000762f89bd6887  vmovaps xmm4, [rsp+0x40]
0000762f89bd688d  vmovaps xmm5, [rsp+0x50]
0000762f89bd6893  vmovaps xmm6, [rsp+0x60]
0000762f89bd6899  vmovaps xmm7, [rsp+0x70]
0000762f89bd689f  vmovaps xmm9, [rsp+0x80]
0000762f89bd68a8  vmovaps xmm10, [rsp+0x90]
0000762f89bd68b1  vmovaps xmm11, [rsp+0xA0]
0000762f89bd68ba  vmovaps xmm12, [rsp+0xB0]
0000762f89bd68c3  vmovaps xmm13, [rsp+0xC0]
0000762f89bd68cc  vmovaps xmm14, [rsp+0xD0]
0000762f89bd68d5  vmovaps xmm15, [rsp+0xE0]
0000762f89bd68de  add rsp, 0xF0
0000762f89bd68e5  pop r11
0000762f89bd68e7  pop r10
0000762f89bd68e9  pop r9
0000762f89bd68eb  pop r8
0000762f89bd68ed  pop rsi
0000762f89bd68ee  pop rdi
0000762f89bd68ef  pop rdx
0000762f89bd68f0  pop rcx
0000762f89bd68f1  pop rax
0000762f89bd68f2  add rsp, 0x08
0000762f89bd68f6  jmp 0x0000762F89BD599A
0000762f89bd68fb  sub rsp, 0x08
0000762f89bd68ff  push rax
0000762f89bd6900  push rcx
0000762f89bd6901  push rdx
0000762f89bd6902  push rdi
0000762f89bd6903  push rsi
0000762f89bd6904  push r8
0000762f89bd6906  push r9
0000762f89bd6908  push r10
0000762f89bd690a  push r11
0000762f89bd690c  sub rsp, 0xF0
0000762f89bd6913  vmovaps [rsp], xmm0
0000762f89bd6918  vmovaps [rsp+0x10], xmm1
0000762f89bd691e  vmovaps [rsp+0x20], xmm2
0000762f89bd6924  vmovaps [rsp+0x30], xmm3
0000762f89bd692a  vmovaps [rsp+0x40], xmm4
0000762f89bd6930  vmovaps [rsp+0x50], xmm5
0000762f89bd6936  vmovaps [rsp+0x60], xmm6
0000762f89bd693c  vmovaps [rsp+0x70], xmm8
0000762f89bd6942  vmovaps [rsp+0x80], xmm9
0000762f89bd694b  vmovaps [rsp+0x90], xmm10
0000762f89bd6954  vmovaps [rsp+0xA0], xmm11
0000762f89bd695d  vmovaps [rsp+0xB0], xmm12
0000762f89bd6966  vmovaps [rsp+0xC0], xmm13
0000762f89bd696f  vmovaps [rsp+0xD0], xmm14
0000762f89bd6978  vmovaps [rsp+0xE0], xmm15
0000762f89bd6981  sub rsp, 0x30
0000762f89bd6985  movaps [rsp], xmm7
0000762f89bd6989  movaps [rsp+0x10], xmm9
0000762f89bd698f  movaps [rsp+0x20], xmm15
0000762f89bd6995  lea rdi, [rsp]
0000762f89bd6999  mov esi, 0x00
0000762f89bd699e  mov rax, 0x604D6F946530
0000762f89bd69a8  call rax
0000762f89bd69aa  movaps xmm7, [rsp]
0000762f89bd69ae  add rsp, 0x30
0000762f89bd69b2  vmovaps xmm0, [rsp]
0000762f89bd69b7  vmovaps xmm1, [rsp+0x10]
0000762f89bd69bd  vmovaps xmm2, [rsp+0x20]
0000762f89bd69c3  vmovaps xmm3, [rsp+0x30]
0000762f89bd69c9  vmovaps xmm4, [rsp+0x40]
0000762f89bd69cf  vmovaps xmm5, [rsp+0x50]
0000762f89bd69d5  vmovaps xmm6, [rsp+0x60]
0000762f89bd69db  vmovaps xmm8, [rsp+0x70]
0000762f89bd69e1  vmovaps xmm9, [rsp+0x80]
0000762f89bd69ea  vmovaps xmm10, [rsp+0x90]
0000762f89bd69f3  vmovaps xmm11, [rsp+0xA0]
0000762f89bd69fc  vmovaps xmm12, [rsp+0xB0]
0000762f89bd6a05  vmovaps xmm13, [rsp+0xC0]
0000762f89bd6a0e  vmovaps xmm14, [rsp+0xD0]
0000762f89bd6a17  vmovaps xmm15, [rsp+0xE0]
0000762f89bd6a20  add rsp, 0xF0
0000762f89bd6a27  pop r11
0000762f89bd6a29  pop r10
0000762f89bd6a2b  pop r9
0000762f89bd6a2d  pop r8
0000762f89bd6a2f  pop rsi
0000762f89bd6a30  pop rdi
0000762f89bd6a31  pop rdx
0000762f89bd6a32  pop rcx
0000762f89bd6a33  pop rax
0000762f89bd6a34  add rsp, 0x08
0000762f89bd6a38  jmp 0x0000762F89BD59C8
0000762f89bd6a3d  sub rsp, 0x08
0000762f89bd6a41  push rax
0000762f89bd6a42  push rcx
0000762f89bd6a43  push rdx
0000762f89bd6a44  push rdi
0000762f89bd6a45  push rsi
0000762f89bd6a46  push r8
0000762f89bd6a48  push r9
0000762f89bd6a4a  push r10
0000762f89bd6a4c  push r11
0000762f89bd6a4e  sub rsp, 0xF0
0000762f89bd6a55  vmovaps [rsp], xmm0
0000762f89bd6a5a  vmovaps [rsp+0x10], xmm1
0000762f89bd6a60  vmovaps [rsp+0x20], xmm2
0000762f89bd6a66  vmovaps [rsp+0x30], xmm3
0000762f89bd6a6c  vmovaps [rsp+0x40], xmm4
0000762f89bd6a72  vmovaps [rsp+0x50], xmm5
0000762f89bd6a78  vmovaps [rsp+0x60], xmm6
0000762f89bd6a7e  vmovaps [rsp+0x70], xmm7
0000762f89bd6a84  vmovaps [rsp+0x80], xmm8
0000762f89bd6a8d  vmovaps [rsp+0x90], xmm10
0000762f89bd6a96  vmovaps [rsp+0xA0], xmm11
0000762f89bd6a9f  vmovaps [rsp+0xB0], xmm12
0000762f89bd6aa8  vmovaps [rsp+0xC0], xmm13
0000762f89bd6ab1  vmovaps [rsp+0xD0], xmm14
0000762f89bd6aba  vmovaps [rsp+0xE0], xmm15
0000762f89bd6ac3  sub rsp, 0x30
0000762f89bd6ac7  movaps [rsp], xmm9
0000762f89bd6acc  movaps [rsp+0x10], xmm12
0000762f89bd6ad2  movaps [rsp+0x20], xmm10
0000762f89bd6ad8  lea rdi, [rsp]
0000762f89bd6adc  mov esi, 0x00
0000762f89bd6ae1  mov rax, 0x604D6F946530
0000762f89bd6aeb  call rax
0000762f89bd6aed  movaps xmm9, [rsp]
0000762f89bd6af2  add rsp, 0x30
0000762f89bd6af6  vmovaps xmm0, [rsp]
0000762f89bd6afb  vmovaps xmm1, [rsp+0x10]
0000762f89bd6b01  vmovaps xmm2, [rsp+0x20]
0000762f89bd6b07  vmovaps xmm3, [rsp+0x30]
0000762f89bd6b0d  vmovaps xmm4, [rsp+0x40]
0000762f89bd6b13  vmovaps xmm5, [rsp+0x50]
0000762f89bd6b19  vmovaps xmm6, [rsp+0x60]
0000762f89bd6b1f  vmovaps xmm7, [rsp+0x70]
0000762f89bd6b25  vmovaps xmm8, [rsp+0x80]
0000762f89bd6b2e  vmovaps xmm10, [rsp+0x90]
0000762f89bd6b37  vmovaps xmm11, [rsp+0xA0]
0000762f89bd6b40  vmovaps xmm12, [rsp+0xB0]
0000762f89bd6b49  vmovaps xmm13, [rsp+0xC0]
0000762f89bd6b52  vmovaps xmm14, [rsp+0xD0]
0000762f89bd6b5b  vmovaps xmm15, [rsp+0xE0]
0000762f89bd6b64  add rsp, 0xF0
0000762f89bd6b6b  pop r11
0000762f89bd6b6d  pop r10
0000762f89bd6b6f  pop r9
0000762f89bd6b71  pop r8
0000762f89bd6b73  pop rsi
0000762f89bd6b74  pop rdi
0000762f89bd6b75  pop rdx
0000762f89bd6b76  pop rcx
0000762f89bd6b77  pop rax
0000762f89bd6b78  add rsp, 0x08
0000762f89bd6b7c  jmp 0x0000762F89BD59EC
0000762f89bd6b81  sub rsp, 0x08
0000762f89bd6b85  push rax
0000762f89bd6b86  push rcx
0000762f89bd6b87  push rdx
0000762f89bd6b88  push rdi
0000762f89bd6b89  push rsi
0000762f89bd6b8a  push r8
0000762f89bd6b8c  push r9
0000762f89bd6b8e  push r10
0000762f89bd6b90  push r11
0000762f89bd6b92  sub rsp, 0xF0
0000762f89bd6b99  vmovaps [rsp], xmm0
0000762f89bd6b9e  vmovaps [rsp+0x10], xmm1
0000762f89bd6ba4  vmovaps [rsp+0x20], xmm2
0000762f89bd6baa  vmovaps [rsp+0x30], xmm3
0000762f89bd6bb0  vmovaps [rsp+0x40], xmm4
0000762f89bd6bb6  vmovaps [rsp+0x50], xmm5
0000762f89bd6bbc  vmovaps [rsp+0x60], xmm6
0000762f89bd6bc2  vmovaps [rsp+0x70], xmm7
0000762f89bd6bc8  vmovaps [rsp+0x80], xmm8
0000762f89bd6bd1  vmovaps [rsp+0x90], xmm9
0000762f89bd6bda  vmovaps [rsp+0xA0], xmm11
0000762f89bd6be3  vmovaps [rsp+0xB0], xmm12
0000762f89bd6bec  vmovaps [rsp+0xC0], xmm13
0000762f89bd6bf5  vmovaps [rsp+0xD0], xmm14
0000762f89bd6bfe  vmovaps [rsp+0xE0], xmm15
0000762f89bd6c07  sub rsp, 0x30
0000762f89bd6c0b  movaps [rsp], xmm10
0000762f89bd6c10  movaps [rsp+0x10], xmm12
0000762f89bd6c16  movaps [rsp+0x20], xmm11
0000762f89bd6c1c  lea rdi, [rsp]
0000762f89bd6c20  mov esi, 0x00
0000762f89bd6c25  mov rax, 0x604D6F946530
0000762f89bd6c2f  call rax
0000762f89bd6c31  movaps xmm10, [rsp]
0000762f89bd6c36  add rsp, 0x30
0000762f89bd6c3a  vmovaps xmm0, [rsp]
0000762f89bd6c3f  vmovaps xmm1, [rsp+0x10]
0000762f89bd6c45  vmovaps xmm2, [rsp+0x20]
0000762f89bd6c4b  vmovaps xmm3, [rsp+0x30]
0000762f89bd6c51  vmovaps xmm4, [rsp+0x40]
0000762f89bd6c57  vmovaps xmm5, [rsp+0x50]
0000762f89bd6c5d  vmovaps xmm6, [rsp+0x60]
0000762f89bd6c63  vmovaps xmm7, [rsp+0x70]
0000762f89bd6c69  vmovaps xmm8, [rsp+0x80]
0000762f89bd6c72  vmovaps xmm9, [rsp+0x90]
0000762f89bd6c7b  vmovaps xmm11, [rsp+0xA0]
0000762f89bd6c84  vmovaps xmm12, [rsp+0xB0]
0000762f89bd6c8d  vmovaps xmm13, [rsp+0xC0]
0000762f89bd6c96  vmovaps xmm14, [rsp+0xD0]
0000762f89bd6c9f  vmovaps xmm15, [rsp+0xE0]
0000762f89bd6ca8  add rsp, 0xF0
0000762f89bd6caf  pop r11
0000762f89bd6cb1  pop r10
0000762f89bd6cb3  pop r9
0000762f89bd6cb5  pop r8
0000762f89bd6cb7  pop rsi
0000762f89bd6cb8  pop rdi
0000762f89bd6cb9  pop rdx
0000762f89bd6cba  pop rcx
0000762f89bd6cbb  pop rax
0000762f89bd6cbc  add rsp, 0x08
0000762f89bd6cc0  jmp 0x0000762F89BD5A06
0000762f89bd6cc5  sub rsp, 0x08
0000762f89bd6cc9  push rax
0000762f89bd6cca  push rcx
0000762f89bd6ccb  push rdx
0000762f89bd6ccc  push rdi
0000762f89bd6ccd  push rsi
0000762f89bd6cce  push r8
0000762f89bd6cd0  push r9
0000762f89bd6cd2  push r10
0000762f89bd6cd4  push r11
0000762f89bd6cd6  sub rsp, 0xF0
0000762f89bd6cdd  vmovaps [rsp], xmm0
0000762f89bd6ce2  vmovaps [rsp+0x10], xmm1
0000762f89bd6ce8  vmovaps [rsp+0x20], xmm2
0000762f89bd6cee  vmovaps [rsp+0x30], xmm3
0000762f89bd6cf4  vmovaps [rsp+0x40], xmm4
0000762f89bd6cfa  vmovaps [rsp+0x50], xmm5
0000762f89bd6d00  vmovaps [rsp+0x60], xmm7
0000762f89bd6d06  vmovaps [rsp+0x70], xmm8
0000762f89bd6d0c  vmovaps [rsp+0x80], xmm9
0000762f89bd6d15  vmovaps [rsp+0x90], xmm10
0000762f89bd6d1e  vmovaps [rsp+0xA0], xmm11
0000762f89bd6d27  vmovaps [rsp+0xB0], xmm12
0000762f89bd6d30  vmovaps [rsp+0xC0], xmm13
0000762f89bd6d39  vmovaps [rsp+0xD0], xmm14
0000762f89bd6d42  vmovaps [rsp+0xE0], xmm15
0000762f89bd6d4b  sub rsp, 0x30
0000762f89bd6d4f  movaps [rsp], xmm6
0000762f89bd6d53  movaps [rsp+0x10], xmm12
0000762f89bd6d59  movaps [rsp+0x20], xmm11
0000762f89bd6d5f  lea rdi, [rsp]
0000762f89bd6d63  mov esi, 0x00
0000762f89bd6d68  mov rax, 0x604D6F946530
0000762f89bd6d72  call rax
0000762f89bd6d74  movaps xmm6, [rsp]
0000762f89bd6d78  add rsp, 0x30
0000762f89bd6d7c  vmovaps xmm0, [rsp]
0000762f89bd6d81  vmovaps xmm1, [rsp+0x10]
0000762f89bd6d87  vmovaps xmm2, [rsp+0x20]
0000762f89bd6d8d  vmovaps xmm3, [rsp+0x30]
0000762f89bd6d93  vmovaps xmm4, [rsp+0x40]
0000762f89bd6d99  vmovaps xmm5, [rsp+0x50]
0000762f89bd6d9f  vmovaps xmm7, [rsp+0x60]
0000762f89bd6da5  vmovaps xmm8, [rsp+0x70]
0000762f89bd6dab  vmovaps xmm9, [rsp+0x80]
0000762f89bd6db4  vmovaps xmm10, [rsp+0x90]
0000762f89bd6dbd  vmovaps xmm11, [rsp+0xA0]
0000762f89bd6dc6  vmovaps xmm12, [rsp+0xB0]
0000762f89bd6dcf  vmovaps xmm13, [rsp+0xC0]
0000762f89bd6dd8  vmovaps xmm14, [rsp+0xD0]
0000762f89bd6de1  vmovaps xmm15, [rsp+0xE0]
0000762f89bd6dea  add rsp, 0xF0
0000762f89bd6df1  pop r11
0000762f89bd6df3  pop r10
0000762f89bd6df5  pop r9
0000762f89bd6df7  pop r8
0000762f89bd6df9  pop rsi
0000762f89bd6dfa  pop rdi
0000762f89bd6dfb  pop rdx
0000762f89bd6dfc  pop rcx
0000762f89bd6dfd  pop rax
0000762f89bd6dfe  add rsp, 0x08
0000762f89bd6e02  jmp 0x0000762F89BD5A27
0000762f89bd6e07  sub rsp, 0x08
0000762f89bd6e0b  push rax
0000762f89bd6e0c  push rcx
0000762f89bd6e0d  push rdx
0000762f89bd6e0e  push rdi
0000762f89bd6e0f  push rsi
0000762f89bd6e10  push r8
0000762f89bd6e12  push r9
0000762f89bd6e14  push r10
0000762f89bd6e16  push r11
0000762f89bd6e18  sub rsp, 0xF0
0000762f89bd6e1f  vmovaps [rsp], xmm0
0000762f89bd6e24  vmovaps [rsp+0x10], xmm1
0000762f89bd6e2a  vmovaps [rsp+0x20], xmm2
0000762f89bd6e30  vmovaps [rsp+0x30], xmm4
0000762f89bd6e36  vmovaps [rsp+0x40], xmm5
0000762f89bd6e3c  vmovaps [rsp+0x50], xmm6
0000762f89bd6e42  vmovaps [rsp+0x60], xmm7
0000762f89bd6e48  vmovaps [rsp+0x70], xmm8
0000762f89bd6e4e  vmovaps [rsp+0x80], xmm9
0000762f89bd6e57  vmovaps [rsp+0x90], xmm10
0000762f89bd6e60  vmovaps [rsp+0xA0], xmm11
0000762f89bd6e69  vmovaps [rsp+0xB0], xmm12
0000762f89bd6e72  vmovaps [rsp+0xC0], xmm13
0000762f89bd6e7b  vmovaps [rsp+0xD0], xmm14
0000762f89bd6e84  vmovaps [rsp+0xE0], xmm15
0000762f89bd6e8d  sub rsp, 0x30
0000762f89bd6e91  movaps [rsp], xmm3
0000762f89bd6e95  movaps [rsp+0x10], xmm5
0000762f89bd6e9a  movaps [rsp+0x20], xmm4
0000762f89bd6e9f  lea rdi, [rsp]
0000762f89bd6ea3  mov esi, 0x00
0000762f89bd6ea8  mov rax, 0x604D6F946530
0000762f89bd6eb2  call rax
0000762f89bd6eb4  movaps xmm3, [rsp]
0000762f89bd6eb8  add rsp, 0x30
0000762f89bd6ebc  vmovaps xmm0, [rsp]
0000762f89bd6ec1  vmovaps xmm1, [rsp+0x10]
0000762f89bd6ec7  vmovaps xmm2, [rsp+0x20]
0000762f89bd6ecd  vmovaps xmm4, [rsp+0x30]
0000762f89bd6ed3  vmovaps xmm5, [rsp+0x40]
0000762f89bd6ed9  vmovaps xmm6, [rsp+0x50]
0000762f89bd6edf  vmovaps xmm7, [rsp+0x60]
0000762f89bd6ee5  vmovaps xmm8, [rsp+0x70]
0000762f89bd6eeb  vmovaps xmm9, [rsp+0x80]
0000762f89bd6ef4  vmovaps xmm10, [rsp+0x90]
0000762f89bd6efd  vmovaps xmm11, [rsp+0xA0]
0000762f89bd6f06  vmovaps xmm12, [rsp+0xB0]
0000762f89bd6f0f  vmovaps xmm13, [rsp+0xC0]
0000762f89bd6f18  vmovaps xmm14, [rsp+0xD0]
0000762f89bd6f21  vmovaps xmm15, [rsp+0xE0]
0000762f89bd6f2a  add rsp, 0xF0
0000762f89bd6f31  pop r11
0000762f89bd6f33  pop r10
0000762f89bd6f35  pop r9
0000762f89bd6f37  pop r8
0000762f89bd6f39  pop rsi
0000762f89bd6f3a  pop rdi
0000762f89bd6f3b  pop rdx
0000762f89bd6f3c  pop rcx
0000762f89bd6f3d  pop rax
0000762f89bd6f3e  add rsp, 0x08
0000762f89bd6f42  jmp 0x0000762F89BD5A88
0000762f89bd6f47  sub rsp, 0x08
0000762f89bd6f4b  push rax
0000762f89bd6f4c  push rcx
0000762f89bd6f4d  push rdx
0000762f89bd6f4e  push rdi
0000762f89bd6f4f  push rsi
0000762f89bd6f50  push r8
0000762f89bd6f52  push r9
0000762f89bd6f54  push r10
0000762f89bd6f56  push r11
0000762f89bd6f58  sub rsp, 0xF0
0000762f89bd6f5f  vmovaps [rsp], xmm0
0000762f89bd6f64  vmovaps [rsp+0x10], xmm1
0000762f89bd6f6a  vmovaps [rsp+0x20], xmm2
0000762f89bd6f70  vmovaps [rsp+0x30], xmm3
0000762f89bd6f76  vmovaps [rsp+0x40], xmm4
0000762f89bd6f7c  vmovaps [rsp+0x50], xmm6
0000762f89bd6f82  vmovaps [rsp+0x60], xmm7
0000762f89bd6f88  vmovaps [rsp+0x70], xmm8
0000762f89bd6f8e  vmovaps [rsp+0x80], xmm9
0000762f89bd6f97  vmovaps [rsp+0x90], xmm10
0000762f89bd6fa0  vmovaps [rsp+0xA0], xmm11
0000762f89bd6fa9  vmovaps [rsp+0xB0], xmm12
0000762f89bd6fb2  vmovaps [rsp+0xC0], xmm13
0000762f89bd6fbb  vmovaps [rsp+0xD0], xmm14
0000762f89bd6fc4  vmovaps [rsp+0xE0], xmm15
0000762f89bd6fcd  sub rsp, 0x30
0000762f89bd6fd1  movaps [rsp], xmm5
0000762f89bd6fd5  movaps [rsp+0x10], xmm8
0000762f89bd6fdb  movaps [rsp+0x20], xmm15
0000762f89bd6fe1  lea rdi, [rsp]
0000762f89bd6fe5  mov esi, 0x00
0000762f89bd6fea  mov rax, 0x604D6F946530
0000762f89bd6ff4  call rax
0000762f89bd6ff6  movaps xmm5, [rsp]
0000762f89bd6ffa  add rsp, 0x30
0000762f89bd6ffe  vmovaps xmm0, [rsp]
0000762f89bd7003  vmovaps xmm1, [rsp+0x10]
0000762f89bd7009  vmovaps xmm2, [rsp+0x20]
0000762f89bd700f  vmovaps xmm3, [rsp+0x30]
0000762f89bd7015  vmovaps xmm4, [rsp+0x40]
0000762f89bd701b  vmovaps xmm6, [rsp+0x50]
0000762f89bd7021  vmovaps xmm7, [rsp+0x60]
0000762f89bd7027  vmovaps xmm8, [rsp+0x70]
0000762f89bd702d  vmovaps xmm9, [rsp+0x80]
0000762f89bd7036  vmovaps xmm10, [rsp+0x90]
0000762f89bd703f  vmovaps xmm11, [rsp+0xA0]
0000762f89bd7048  vmovaps xmm12, [rsp+0xB0]
0000762f89bd7051  vmovaps xmm13, [rsp+0xC0]
0000762f89bd705a  vmovaps xmm14, [rsp+0xD0]
0000762f89bd7063  vmovaps xmm15, [rsp+0xE0]
0000762f89bd706c  add rsp, 0xF0
0000762f89bd7073  pop r11
0000762f89bd7075  pop r10
0000762f89bd7077  pop r9
0000762f89bd7079  pop r8
0000762f89bd707b  pop rsi
0000762f89bd707c  pop rdi
0000762f89bd707d  pop rdx
0000762f89bd707e  pop rcx
0000762f89bd707f  pop rax
0000762f89bd7080  add rsp, 0x08
0000762f89bd7084  jmp 0x0000762F89BD5AC0
0000762f89bd7089  sub rsp, 0x08
0000762f89bd708d  push rax
0000762f89bd708e  push rcx
0000762f89bd708f  push rdx
0000762f89bd7090  push rdi
0000762f89bd7091  push rsi
0000762f89bd7092  push r8
0000762f89bd7094  push r9
0000762f89bd7096  push r10
0000762f89bd7098  push r11
0000762f89bd709a  sub rsp, 0xF0
0000762f89bd70a1  vmovaps [rsp], xmm0
0000762f89bd70a6  vmovaps [rsp+0x10], xmm1
0000762f89bd70ac  vmovaps [rsp+0x20], xmm2
0000762f89bd70b2  vmovaps [rsp+0x30], xmm3
0000762f89bd70b8  vmovaps [rsp+0x40], xmm5
0000762f89bd70be  vmovaps [rsp+0x50], xmm6
0000762f89bd70c4  vmovaps [rsp+0x60], xmm7
0000762f89bd70ca  vmovaps [rsp+0x70], xmm8
0000762f89bd70d0  vmovaps [rsp+0x80], xmm9
0000762f89bd70d9  vmovaps [rsp+0x90], xmm10
0000762f89bd70e2  vmovaps [rsp+0xA0], xmm11
0000762f89bd70eb  vmovaps [rsp+0xB0], xmm12
0000762f89bd70f4  vmovaps [rsp+0xC0], xmm13
0000762f89bd70fd  vmovaps [rsp+0xD0], xmm14
0000762f89bd7106  vmovaps [rsp+0xE0], xmm15
0000762f89bd710f  sub rsp, 0x30
0000762f89bd7113  movaps [rsp], xmm4
0000762f89bd7117  movaps [rsp+0x10], xmm9
0000762f89bd711d  movaps [rsp+0x20], xmm8
0000762f89bd7123  lea rdi, [rsp]
0000762f89bd7127  mov esi, 0x00
0000762f89bd712c  mov rax, 0x604D6F946530
0000762f89bd7136  call rax
0000762f89bd7138  movaps xmm4, [rsp]
0000762f89bd713c  add rsp, 0x30
0000762f89bd7140  vmovaps xmm0, [rsp]
0000762f89bd7145  vmovaps xmm1, [rsp+0x10]
0000762f89bd714b  vmovaps xmm2, [rsp+0x20]
0000762f89bd7151  vmovaps xmm3, [rsp+0x30]
0000762f89bd7157  vmovaps xmm5, [rsp+0x40]
0000762f89bd715d  vmovaps xmm6, [rsp+0x50]
0000762f89bd7163  vmovaps xmm7, [rsp+0x60]
0000762f89bd7169  vmovaps xmm8, [rsp+0x70]
0000762f89bd716f  vmovaps xmm9, [rsp+0x80]
0000762f89bd7178  vmovaps xmm10, [rsp+0x90]
0000762f89bd7181  vmovaps xmm11, [rsp+0xA0]
0000762f89bd718a  vmovaps xmm12, [rsp+0xB0]
0000762f89bd7193  vmovaps xmm13, [rsp+0xC0]
0000762f89bd719c  vmovaps xmm14, [rsp+0xD0]
0000762f89bd71a5  vmovaps xmm15, [rsp+0xE0]
0000762f89bd71ae  add rsp, 0xF0
0000762f89bd71b5  pop r11
0000762f89bd71b7  pop r10
0000762f89bd71b9  pop r9
0000762f89bd71bb  pop r8
0000762f89bd71bd  pop rsi
0000762f89bd71be  pop rdi
0000762f89bd71bf  pop rdx
0000762f89bd71c0  pop rcx
0000762f89bd71c1  pop rax
0000762f89bd71c2  add rsp, 0x08
0000762f89bd71c6  jmp 0x0000762F89BD5AE1
0000762f89bd71cb  sub rsp, 0x08
0000762f89bd71cf  push rax
0000762f89bd71d0  push rcx
0000762f89bd71d1  push rdx
0000762f89bd71d2  push rdi
0000762f89bd71d3  push rsi
0000762f89bd71d4  push r8
0000762f89bd71d6  push r9
0000762f89bd71d8  push r10
0000762f89bd71da  push r11
0000762f89bd71dc  sub rsp, 0xF0
0000762f89bd71e3  vmovaps [rsp], xmm0
0000762f89bd71e8  vmovaps [rsp+0x10], xmm1
0000762f89bd71ee  vmovaps [rsp+0x20], xmm2
0000762f89bd71f4  vmovaps [rsp+0x30], xmm3
0000762f89bd71fa  vmovaps [rsp+0x40], xmm4
0000762f89bd7200  vmovaps [rsp+0x50], xmm5
0000762f89bd7206  vmovaps [rsp+0x60], xmm6
0000762f89bd720c  vmovaps [rsp+0x70], xmm7
0000762f89bd7212  vmovaps [rsp+0x80], xmm8
0000762f89bd721b  vmovaps [rsp+0x90], xmm10
0000762f89bd7224  vmovaps [rsp+0xA0], xmm11
0000762f89bd722d  vmovaps [rsp+0xB0], xmm12
0000762f89bd7236  vmovaps [rsp+0xC0], xmm13
0000762f89bd723f  vmovaps [rsp+0xD0], xmm14
0000762f89bd7248  vmovaps [rsp+0xE0], xmm15
0000762f89bd7251  sub rsp, 0x30
0000762f89bd7255  movaps [rsp], xmm9
0000762f89bd725a  movaps [rsp+0x10], xmm10
0000762f89bd7260  movaps [rsp+0x20], xmm8
0000762f89bd7266  lea rdi, [rsp]
0000762f89bd726a  mov esi, 0x00
0000762f89bd726f  mov rax, 0x604D6F946530
0000762f89bd7279  call rax
0000762f89bd727b  movaps xmm9, [rsp]
0000762f89bd7280  add rsp, 0x30
0000762f89bd7284  vmovaps xmm0, [rsp]
0000762f89bd7289  vmovaps xmm1, [rsp+0x10]
0000762f89bd728f  vmovaps xmm2, [rsp+0x20]
0000762f89bd7295  vmovaps xmm3, [rsp+0x30]
0000762f89bd729b  vmovaps xmm4, [rsp+0x40]
0000762f89bd72a1  vmovaps xmm5, [rsp+0x50]
0000762f89bd72a7  vmovaps xmm6, [rsp+0x60]
0000762f89bd72ad  vmovaps xmm7, [rsp+0x70]
0000762f89bd72b3  vmovaps xmm8, [rsp+0x80]
0000762f89bd72bc  vmovaps xmm10, [rsp+0x90]
0000762f89bd72c5  vmovaps xmm11, [rsp+0xA0]
0000762f89bd72ce  vmovaps xmm12, [rsp+0xB0]
0000762f89bd72d7  vmovaps xmm13, [rsp+0xC0]
0000762f89bd72e0  vmovaps xmm14, [rsp+0xD0]
0000762f89bd72e9  vmovaps xmm15, [rsp+0xE0]
0000762f89bd72f2  add rsp, 0xF0
0000762f89bd72f9  pop r11
0000762f89bd72fb  pop r10
0000762f89bd72fd  pop r9
0000762f89bd72ff  pop r8
0000762f89bd7301  pop rsi
0000762f89bd7302  pop rdi
0000762f89bd7303  pop rdx
0000762f89bd7304  pop rcx
0000762f89bd7305  pop rax
0000762f89bd7306  add rsp, 0x08
0000762f89bd730a  jmp 0x0000762F89BD5AFB
0000762f89bd730f  call 0x0000762F89AD64F0
0000762f89bd7314  jmp 0x0000762F89BD5C15
0000762f89bd7319  call 0x0000762F89AD64F0
0000762f89bd731e  jmp 0x0000762F89BD5C2B
0000762f89bd7323  sub rsp, 0x08
0000762f89bd7327  push rax
0000762f89bd7328  push rcx
0000762f89bd7329  push rdx
0000762f89bd732a  push rdi
0000762f89bd732b  push rsi
0000762f89bd732c  push r8
0000762f89bd732e  push r9
0000762f89bd7330  push r10
0000762f89bd7332  push r11
0000762f89bd7334  sub rsp, 0xF0
0000762f89bd733b  vmovaps [rsp], xmm0
0000762f89bd7340  vmovaps [rsp+0x10], xmm2
0000762f89bd7346  vmovaps [rsp+0x20], xmm3
0000762f89bd734c  vmovaps [rsp+0x30], xmm4
0000762f89bd7352  vmovaps [rsp+0x40], xmm5
0000762f89bd7358  vmovaps [rsp+0x50], xmm6
0000762f89bd735e  vmovaps [rsp+0x60], xmm7
0000762f89bd7364  vmovaps [rsp+0x70], xmm8
0000762f89bd736a  vmovaps [rsp+0x80], xmm9
0000762f89bd7373  vmovaps [rsp+0x90], xmm10
0000762f89bd737c  vmovaps [rsp+0xA0], xmm11
0000762f89bd7385  vmovaps [rsp+0xB0], xmm12
0000762f89bd738e  vmovaps [rsp+0xC0], xmm13
0000762f89bd7397  vmovaps [rsp+0xD0], xmm14
0000762f89bd73a0  vmovaps [rsp+0xE0], xmm15
0000762f89bd73a9  sub rsp, 0x30
0000762f89bd73ad  movaps [rsp], xmm1
0000762f89bd73b1  movaps [rsp+0x10], xmm6
0000762f89bd73b6  movaps [rsp+0x20], xmm15
0000762f89bd73bc  lea rdi, [rsp]
0000762f89bd73c0  mov esi, 0x00
0000762f89bd73c5  mov rax, 0x604D6F946530
0000762f89bd73cf  call rax
0000762f89bd73d1  movaps xmm1, [rsp]
0000762f89bd73d5  add rsp, 0x30
0000762f89bd73d9  vmovaps xmm0, [rsp]
0000762f89bd73de  vmovaps xmm2, [rsp+0x10]
0000762f89bd73e4  vmovaps xmm3, [rsp+0x20]
0000762f89bd73ea  vmovaps xmm4, [rsp+0x30]
0000762f89bd73f0  vmovaps xmm5, [rsp+0x40]
0000762f89bd73f6  vmovaps xmm6, [rsp+0x50]
0000762f89bd73fc  vmovaps xmm7, [rsp+0x60]
0000762f89bd7402  vmovaps xmm8, [rsp+0x70]
0000762f89bd7408  vmovaps xmm9, [rsp+0x80]
0000762f89bd7411  vmovaps xmm10, [rsp+0x90]
0000762f89bd741a  vmovaps xmm11, [rsp+0xA0]
0000762f89bd7423  vmovaps xmm12, [rsp+0xB0]
0000762f89bd742c  vmovaps xmm13, [rsp+0xC0]
0000762f89bd7435  vmovaps xmm14, [rsp+0xD0]
0000762f89bd743e  vmovaps xmm15, [rsp+0xE0]
0000762f89bd7447  add rsp, 0xF0
0000762f89bd744e  pop r11
0000762f89bd7450  pop r10
0000762f89bd7452  pop r9
0000762f89bd7454  pop r8
0000762f89bd7456  pop rsi
0000762f89bd7457  pop rdi
0000762f89bd7458  pop rdx
0000762f89bd7459  pop rcx
0000762f89bd745a  pop rax
0000762f89bd745b  add rsp, 0x08
0000762f89bd745f  jmp 0x0000762F89BD5C68
0000762f89bd7464  call 0x0000762F89AE5820
0000762f89bd7469  jmp 0x0000762F89BD5C75
0000762f89bd746e  sub rsp, 0x08
0000762f89bd7472  push rax
0000762f89bd7473  push rcx
0000762f89bd7474  push rdx
0000762f89bd7475  push rdi
0000762f89bd7476  push rsi
0000762f89bd7477  push r8
0000762f89bd7479  push r9
0000762f89bd747b  push r10
0000762f89bd747d  push r11
0000762f89bd747f  sub rsp, 0xF0
0000762f89bd7486  vmovaps [rsp], xmm0
0000762f89bd748b  vmovaps [rsp+0x10], xmm1
0000762f89bd7491  vmovaps [rsp+0x20], xmm2
0000762f89bd7497  vmovaps [rsp+0x30], xmm3
0000762f89bd749d  vmovaps [rsp+0x40], xmm4
0000762f89bd74a3  vmovaps [rsp+0x50], xmm5
0000762f89bd74a9  vmovaps [rsp+0x60], xmm6
0000762f89bd74af  vmovaps [rsp+0x70], xmm7
0000762f89bd74b5  vmovaps [rsp+0x80], xmm8
0000762f89bd74be  vmovaps [rsp+0x90], xmm9
0000762f89bd74c7  vmovaps [rsp+0xA0], xmm10
0000762f89bd74d0  vmovaps [rsp+0xB0], xmm11
0000762f89bd74d9  vmovaps [rsp+0xC0], xmm12
0000762f89bd74e2  vmovaps [rsp+0xD0], xmm13
0000762f89bd74eb  vmovaps [rsp+0xE0], xmm15
0000762f89bd74f4  sub rsp, 0x30
0000762f89bd74f8  movaps [rsp], xmm14
0000762f89bd74fd  movaps [rsp+0x10], xmm4
0000762f89bd7502  movaps [rsp+0x20], xmm3
0000762f89bd7507  lea rdi, [rsp]
0000762f89bd750b  mov esi, 0x00
0000762f89bd7510  mov rax, 0x604D6F946530
0000762f89bd751a  call rax
0000762f89bd751c  movaps xmm14, [rsp]
0000762f89bd7521  add rsp, 0x30
0000762f89bd7525  vmovaps xmm0, [rsp]
0000762f89bd752a  vmovaps xmm1, [rsp+0x10]
0000762f89bd7530  vmovaps xmm2, [rsp+0x20]
0000762f89bd7536  vmovaps xmm3, [rsp+0x30]
0000762f89bd753c  vmovaps xmm4, [rsp+0x40]
0000762f89bd7542  vmovaps xmm5, [rsp+0x50]
0000762f89bd7548  vmovaps xmm6, [rsp+0x60]
0000762f89bd754e  vmovaps xmm7, [rsp+0x70]
0000762f89bd7554  vmovaps xmm8, [rsp+0x80]
0000762f89bd755d  vmovaps xmm9, [rsp+0x90]
0000762f89bd7566  vmovaps xmm10, [rsp+0xA0]
0000762f89bd756f  vmovaps xmm11, [rsp+0xB0]
0000762f89bd7578  vmovaps xmm12, [rsp+0xC0]
0000762f89bd7581  vmovaps xmm13, [rsp+0xD0]
0000762f89bd758a  vmovaps xmm15, [rsp+0xE0]
0000762f89bd7593  add rsp, 0xF0
0000762f89bd759a  pop r11
0000762f89bd759c  pop r10
0000762f89bd759e  pop r9
0000762f89bd75a0  pop r8
0000762f89bd75a2  pop rsi
0000762f89bd75a3  pop rdi
0000762f89bd75a4  pop rdx
0000762f89bd75a5  pop rcx
0000762f89bd75a6  pop rax
0000762f89bd75a7  add rsp, 0x08
0000762f89bd75ab  jmp 0x0000762F89BD5C8F
0000762f89bd75b0  sub rsp, 0x08
0000762f89bd75b4  push rax
0000762f89bd75b5  push rcx
0000762f89bd75b6  push rdx
0000762f89bd75b7  push rdi
0000762f89bd75b8  push rsi
0000762f89bd75b9  push r8
0000762f89bd75bb  push r9
0000762f89bd75bd  push r10
0000762f89bd75bf  push r11
0000762f89bd75c1  sub rsp, 0xF0
0000762f89bd75c8  vmovaps [rsp], xmm0
0000762f89bd75cd  vmovaps [rsp+0x10], xmm1
0000762f89bd75d3  vmovaps [rsp+0x20], xmm2
0000762f89bd75d9  vmovaps [rsp+0x30], xmm3
0000762f89bd75df  vmovaps [rsp+0x40], xmm4
0000762f89bd75e5  vmovaps [rsp+0x50], xmm5
0000762f89bd75eb  vmovaps [rsp+0x60], xmm7
0000762f89bd75f1  vmovaps [rsp+0x70], xmm8
0000762f89bd75f7  vmovaps [rsp+0x80], xmm9
0000762f89bd7600  vmovaps [rsp+0x90], xmm10
0000762f89bd7609  vmovaps [rsp+0xA0], xmm11
0000762f89bd7612  vmovaps [rsp+0xB0], xmm12
0000762f89bd761b  vmovaps [rsp+0xC0], xmm13
0000762f89bd7624  vmovaps [rsp+0xD0], xmm14
0000762f89bd762d  vmovaps [rsp+0xE0], xmm15
0000762f89bd7636  sub rsp, 0x30
0000762f89bd763a  movaps [rsp], xmm6
0000762f89bd763e  movaps [rsp+0x10], xmm9
0000762f89bd7644  movaps [rsp+0x20], xmm7
0000762f89bd7649  lea rdi, [rsp]
0000762f89bd764d  mov esi, 0x00
0000762f89bd7652  mov rax, 0x604D6F946530
0000762f89bd765c  call rax
0000762f89bd765e  movaps xmm6, [rsp]
0000762f89bd7662  add rsp, 0x30
0000762f89bd7666  vmovaps xmm0, [rsp]
0000762f89bd766b  vmovaps xmm1, [rsp+0x10]
0000762f89bd7671  vmovaps xmm2, [rsp+0x20]
0000762f89bd7677  vmovaps xmm3, [rsp+0x30]
0000762f89bd767d  vmovaps xmm4, [rsp+0x40]
0000762f89bd7683  vmovaps xmm5, [rsp+0x50]
0000762f89bd7689  vmovaps xmm7, [rsp+0x60]
0000762f89bd768f  vmovaps xmm8, [rsp+0x70]
0000762f89bd7695  vmovaps xmm9, [rsp+0x80]
0000762f89bd769e  vmovaps xmm10, [rsp+0x90]
0000762f89bd76a7  vmovaps xmm11, [rsp+0xA0]
0000762f89bd76b0  vmovaps xmm12, [rsp+0xB0]
0000762f89bd76b9  vmovaps xmm13, [rsp+0xC0]
0000762f89bd76c2  vmovaps xmm14, [rsp+0xD0]
0000762f89bd76cb  vmovaps xmm15, [rsp+0xE0]
0000762f89bd76d4  add rsp, 0xF0
0000762f89bd76db  pop r11
0000762f89bd76dd  pop r10
0000762f89bd76df  pop r9
0000762f89bd76e1  pop r8
0000762f89bd76e3  pop rsi
0000762f89bd76e4  pop rdi
0000762f89bd76e5  pop rdx
0000762f89bd76e6  pop rcx
0000762f89bd76e7  pop rax
0000762f89bd76e8  add rsp, 0x08
0000762f89bd76ec  jmp 0x0000762F89BD5CA7
0000762f89bd76f1  sub rsp, 0x08
0000762f89bd76f5  push rax
0000762f89bd76f6  push rcx
0000762f89bd76f7  push rdx
0000762f89bd76f8  push rdi
0000762f89bd76f9  push rsi
0000762f89bd76fa  push r8
0000762f89bd76fc  push r9
0000762f89bd76fe  push r10
0000762f89bd7700  push r11
0000762f89bd7702  sub rsp, 0xF0
0000762f89bd7709  vmovaps [rsp], xmm0
0000762f89bd770e  vmovaps [rsp+0x10], xmm1
0000762f89bd7714  vmovaps [rsp+0x20], xmm2
0000762f89bd771a  vmovaps [rsp+0x30], xmm3
0000762f89bd7720  vmovaps [rsp+0x40], xmm4
0000762f89bd7726  vmovaps [rsp+0x50], xmm5
0000762f89bd772c  vmovaps [rsp+0x60], xmm6
0000762f89bd7732  vmovaps [rsp+0x70], xmm8
0000762f89bd7738  vmovaps [rsp+0x80], xmm9
0000762f89bd7741  vmovaps [rsp+0x90], xmm10
0000762f89bd774a  vmovaps [rsp+0xA0], xmm11
0000762f89bd7753  vmovaps [rsp+0xB0], xmm12
0000762f89bd775c  vmovaps [rsp+0xC0], xmm13
0000762f89bd7765  vmovaps [rsp+0xD0], xmm14
0000762f89bd776e  vmovaps [rsp+0xE0], xmm15
0000762f89bd7777  sub rsp, 0x30
0000762f89bd777b  movaps [rsp], xmm7
0000762f89bd777f  movaps [rsp+0x10], xmm4
0000762f89bd7784  movaps [rsp+0x20], xmm9
0000762f89bd778a  lea rdi, [rsp]
0000762f89bd778e  mov esi, 0x00
0000762f89bd7793  mov rax, 0x604D6F946530
0000762f89bd779d  call rax
0000762f89bd779f  movaps xmm7, [rsp]
0000762f89bd77a3  add rsp, 0x30
0000762f89bd77a7  vmovaps xmm0, [rsp]
0000762f89bd77ac  vmovaps xmm1, [rsp+0x10]
0000762f89bd77b2  vmovaps xmm2, [rsp+0x20]
0000762f89bd77b8  vmovaps xmm3, [rsp+0x30]
0000762f89bd77be  vmovaps xmm4, [rsp+0x40]
0000762f89bd77c4  vmovaps xmm5, [rsp+0x50]
0000762f89bd77ca  vmovaps xmm6, [rsp+0x60]
0000762f89bd77d0  vmovaps xmm8, [rsp+0x70]
0000762f89bd77d6  vmovaps xmm9, [rsp+0x80]
0000762f89bd77df  vmovaps xmm10, [rsp+0x90]
0000762f89bd77e8  vmovaps xmm11, [rsp+0xA0]
0000762f89bd77f1  vmovaps xmm12, [rsp+0xB0]
0000762f89bd77fa  vmovaps xmm13, [rsp+0xC0]
0000762f89bd7803  vmovaps xmm14, [rsp+0xD0]
0000762f89bd780c  vmovaps xmm15, [rsp+0xE0]
0000762f89bd7815  add rsp, 0xF0
0000762f89bd781c  pop r11
0000762f89bd781e  pop r10
0000762f89bd7820  pop r9
0000762f89bd7822  pop r8
0000762f89bd7824  pop rsi
0000762f89bd7825  pop rdi
0000762f89bd7826  pop rdx
0000762f89bd7827  pop rcx
0000762f89bd7828  pop rax
0000762f89bd7829  add rsp, 0x08
0000762f89bd782d  jmp 0x0000762F89BD5CD4
0000762f89bd7832  sub rsp, 0x08
0000762f89bd7836  push rax
0000762f89bd7837  push rcx
0000762f89bd7838  push rdx
0000762f89bd7839  push rdi
0000762f89bd783a  push rsi
0000762f89bd783b  push r8
0000762f89bd783d  push r9
0000762f89bd783f  push r10
0000762f89bd7841  push r11
0000762f89bd7843  sub rsp, 0xF0
0000762f89bd784a  vmovaps [rsp], xmm0
0000762f89bd784f  vmovaps [rsp+0x10], xmm1
0000762f89bd7855  vmovaps [rsp+0x20], xmm2
0000762f89bd785b  vmovaps [rsp+0x30], xmm3
0000762f89bd7861  vmovaps [rsp+0x40], xmm5
0000762f89bd7867  vmovaps [rsp+0x50], xmm6
0000762f89bd786d  vmovaps [rsp+0x60], xmm7
0000762f89bd7873  vmovaps [rsp+0x70], xmm8
0000762f89bd7879  vmovaps [rsp+0x80], xmm9
0000762f89bd7882  vmovaps [rsp+0x90], xmm10
0000762f89bd788b  vmovaps [rsp+0xA0], xmm11
0000762f89bd7894  vmovaps [rsp+0xB0], xmm12
0000762f89bd789d  vmovaps [rsp+0xC0], xmm13
0000762f89bd78a6  vmovaps [rsp+0xD0], xmm14
0000762f89bd78af  vmovaps [rsp+0xE0], xmm15
0000762f89bd78b8  sub rsp, 0x30
0000762f89bd78bc  movaps [rsp], xmm4
0000762f89bd78c0  movaps [rsp+0x10], xmm15
0000762f89bd78c6  movaps [rsp+0x20], xmm9
0000762f89bd78cc  lea rdi, [rsp]
0000762f89bd78d0  mov esi, 0x00
0000762f89bd78d5  mov rax, 0x604D6F946530
0000762f89bd78df  call rax
0000762f89bd78e1  movaps xmm4, [rsp]
0000762f89bd78e5  add rsp, 0x30
0000762f89bd78e9  vmovaps xmm0, [rsp]
0000762f89bd78ee  vmovaps xmm1, [rsp+0x10]
0000762f89bd78f4  vmovaps xmm2, [rsp+0x20]
0000762f89bd78fa  vmovaps xmm3, [rsp+0x30]
0000762f89bd7900  vmovaps xmm5, [rsp+0x40]
0000762f89bd7906  vmovaps xmm6, [rsp+0x50]
0000762f89bd790c  vmovaps xmm7, [rsp+0x60]
0000762f89bd7912  vmovaps xmm8, [rsp+0x70]
0000762f89bd7918  vmovaps xmm9, [rsp+0x80]
0000762f89bd7921  vmovaps xmm10, [rsp+0x90]
0000762f89bd792a  vmovaps xmm11, [rsp+0xA0]
0000762f89bd7933  vmovaps xmm12, [rsp+0xB0]
0000762f89bd793c  vmovaps xmm13, [rsp+0xC0]
0000762f89bd7945  vmovaps xmm14, [rsp+0xD0]
0000762f89bd794e  vmovaps xmm15, [rsp+0xE0]
0000762f89bd7957  add rsp, 0xF0
0000762f89bd795e  pop r11
0000762f89bd7960  pop r10
0000762f89bd7962  pop r9
0000762f89bd7964  pop r8
0000762f89bd7966  pop rsi
0000762f89bd7967  pop rdi
0000762f89bd7968  pop rdx
0000762f89bd7969  pop rcx
0000762f89bd796a  pop rax
0000762f89bd796b  add rsp, 0x08
0000762f89bd796f  jmp 0x0000762F89BD5CF9
0000762f89bd7974  call 0x0000762F89AE5820
0000762f89bd7979  jmp 0x0000762F89BD5D06
0000762f89bd797e  sub rsp, 0x08
0000762f89bd7982  push rax
0000762f89bd7983  push rcx
0000762f89bd7984  push rdx
0000762f89bd7985  push rdi
0000762f89bd7986  push rsi
0000762f89bd7987  push r8
0000762f89bd7989  push r9
0000762f89bd798b  push r10
0000762f89bd798d  push r11
0000762f89bd798f  sub rsp, 0xF0
0000762f89bd7996  vmovaps [rsp], xmm0
0000762f89bd799b  vmovaps [rsp+0x10], xmm1
0000762f89bd79a1  vmovaps [rsp+0x20], xmm2
0000762f89bd79a7  vmovaps [rsp+0x30], xmm4
0000762f89bd79ad  vmovaps [rsp+0x40], xmm5
0000762f89bd79b3  vmovaps [rsp+0x50], xmm6
0000762f89bd79b9  vmovaps [rsp+0x60], xmm7
0000762f89bd79bf  vmovaps [rsp+0x70], xmm8
0000762f89bd79c5  vmovaps [rsp+0x80], xmm9
0000762f89bd79ce  vmovaps [rsp+0x90], xmm10
0000762f89bd79d7  vmovaps [rsp+0xA0], xmm11
0000762f89bd79e0  vmovaps [rsp+0xB0], xmm12
0000762f89bd79e9  vmovaps [rsp+0xC0], xmm13
0000762f89bd79f2  vmovaps [rsp+0xD0], xmm14
0000762f89bd79fb  vmovaps [rsp+0xE0], xmm15
0000762f89bd7a04  sub rsp, 0x30
0000762f89bd7a08  movaps [rsp], xmm3
0000762f89bd7a0c  movaps [rsp+0x10], xmm1
0000762f89bd7a11  movaps [rsp+0x20], xmm9
0000762f89bd7a17  lea rdi, [rsp]
0000762f89bd7a1b  mov esi, 0x00
0000762f89bd7a20  mov rax, 0x604D6F946530
0000762f89bd7a2a  call rax
0000762f89bd7a2c  movaps xmm3, [rsp]
0000762f89bd7a30  add rsp, 0x30
0000762f89bd7a34  vmovaps xmm0, [rsp]
0000762f89bd7a39  vmovaps xmm1, [rsp+0x10]
0000762f89bd7a3f  vmovaps xmm2, [rsp+0x20]
0000762f89bd7a45  vmovaps xmm4, [rsp+0x30]
0000762f89bd7a4b  vmovaps xmm5, [rsp+0x40]
0000762f89bd7a51  vmovaps xmm6, [rsp+0x50]
0000762f89bd7a57  vmovaps xmm7, [rsp+0x60]
0000762f89bd7a5d  vmovaps xmm8, [rsp+0x70]
0000762f89bd7a63  vmovaps xmm9, [rsp+0x80]
0000762f89bd7a6c  vmovaps xmm10, [rsp+0x90]
0000762f89bd7a75  vmovaps xmm11, [rsp+0xA0]
0000762f89bd7a7e  vmovaps xmm12, [rsp+0xB0]
0000762f89bd7a87  vmovaps xmm13, [rsp+0xC0]
0000762f89bd7a90  vmovaps xmm14, [rsp+0xD0]
0000762f89bd7a99  vmovaps xmm15, [rsp+0xE0]
0000762f89bd7aa2  add rsp, 0xF0
0000762f89bd7aa9  pop r11
0000762f89bd7aab  pop r10
0000762f89bd7aad  pop r9
0000762f89bd7aaf  pop r8
0000762f89bd7ab1  pop rsi
0000762f89bd7ab2  pop rdi
0000762f89bd7ab3  pop rdx
0000762f89bd7ab4  pop rcx
0000762f89bd7ab5  pop rax
0000762f89bd7ab6  add rsp, 0x08
0000762f89bd7aba  jmp 0x0000762F89BD5D43
0000762f89bd7abf  sub rsp, 0x08
0000762f89bd7ac3  push rax
0000762f89bd7ac4  push rcx
0000762f89bd7ac5  push rdx
0000762f89bd7ac6  push rdi
0000762f89bd7ac7  push rsi
0000762f89bd7ac8  push r8
0000762f89bd7aca  push r9
0000762f89bd7acc  push r10
0000762f89bd7ace  push r11
0000762f89bd7ad0  sub rsp, 0xF0
0000762f89bd7ad7  vmovaps [rsp], xmm0
0000762f89bd7adc  vmovaps [rsp+0x10], xmm2
0000762f89bd7ae2  vmovaps [rsp+0x20], xmm3
0000762f89bd7ae8  vmovaps [rsp+0x30], xmm4
0000762f89bd7aee  vmovaps [rsp+0x40], xmm5
0000762f89bd7af4  vmovaps [rsp+0x50], xmm6
0000762f89bd7afa  vmovaps [rsp+0x60], xmm7
0000762f89bd7b00  vmovaps [rsp+0x70], xmm8
0000762f89bd7b06  vmovaps [rsp+0x80], xmm9
0000762f89bd7b0f  vmovaps [rsp+0x90], xmm10
0000762f89bd7b18  vmovaps [rsp+0xA0], xmm11
0000762f89bd7b21  vmovaps [rsp+0xB0], xmm12
0000762f89bd7b2a  vmovaps [rsp+0xC0], xmm13
0000762f89bd7b33  vmovaps [rsp+0xD0], xmm14
0000762f89bd7b3c  vmovaps [rsp+0xE0], xmm15
0000762f89bd7b45  sub rsp, 0x30
0000762f89bd7b49  movaps [rsp], xmm1
0000762f89bd7b4d  movaps [rsp+0x10], xmm15
0000762f89bd7b53  movaps [rsp+0x20], xmm9
0000762f89bd7b59  lea rdi, [rsp]
0000762f89bd7b5d  mov esi, 0x00
0000762f89bd7b62  mov rax, 0x604D6F946530
0000762f89bd7b6c  call rax
0000762f89bd7b6e  movaps xmm1, [rsp]
0000762f89bd7b72  add rsp, 0x30
0000762f89bd7b76  vmovaps xmm0, [rsp]
0000762f89bd7b7b  vmovaps xmm2, [rsp+0x10]
0000762f89bd7b81  vmovaps xmm3, [rsp+0x20]
0000762f89bd7b87  vmovaps xmm4, [rsp+0x30]
0000762f89bd7b8d  vmovaps xmm5, [rsp+0x40]
0000762f89bd7b93  vmovaps xmm6, [rsp+0x50]
0000762f89bd7b99  vmovaps xmm7, [rsp+0x60]
0000762f89bd7b9f  vmovaps xmm8, [rsp+0x70]
0000762f89bd7ba5  vmovaps xmm9, [rsp+0x80]
0000762f89bd7bae  vmovaps xmm10, [rsp+0x90]
0000762f89bd7bb7  vmovaps xmm11, [rsp+0xA0]
0000762f89bd7bc0  vmovaps xmm12, [rsp+0xB0]
0000762f89bd7bc9  vmovaps xmm13, [rsp+0xC0]
0000762f89bd7bd2  vmovaps xmm14, [rsp+0xD0]
0000762f89bd7bdb  vmovaps xmm15, [rsp+0xE0]
0000762f89bd7be4  add rsp, 0xF0
0000762f89bd7beb  pop r11
0000762f89bd7bed  pop r10
0000762f89bd7bef  pop r9
0000762f89bd7bf1  pop r8
0000762f89bd7bf3  pop rsi
0000762f89bd7bf4  pop rdi
0000762f89bd7bf5  pop rdx
0000762f89bd7bf6  pop rcx
0000762f89bd7bf7  pop rax
0000762f89bd7bf8  add rsp, 0x08
0000762f89bd7bfc  jmp 0x0000762F89BD5DCB
0000762f89bd7c01  call 0x0000762F89AE5820
0000762f89bd7c06  jmp 0x0000762F89BD5DD8
0000762f89bd7c0b  sub rsp, 0x08
0000762f89bd7c0f  push rax
0000762f89bd7c10  push rcx
0000762f89bd7c11  push rdx
0000762f89bd7c12  push rdi
0000762f89bd7c13  push rsi
0000762f89bd7c14  push r8
0000762f89bd7c16  push r9
0000762f89bd7c18  push r10
0000762f89bd7c1a  push r11
0000762f89bd7c1c  sub rsp, 0xF0
0000762f89bd7c23  vmovaps [rsp], xmm0
0000762f89bd7c28  vmovaps [rsp+0x10], xmm2
0000762f89bd7c2e  vmovaps [rsp+0x20], xmm3
0000762f89bd7c34  vmovaps [rsp+0x30], xmm4
0000762f89bd7c3a  vmovaps [rsp+0x40], xmm5
0000762f89bd7c40  vmovaps [rsp+0x50], xmm6
0000762f89bd7c46  vmovaps [rsp+0x60], xmm7
0000762f89bd7c4c  vmovaps [rsp+0x70], xmm8
0000762f89bd7c52  vmovaps [rsp+0x80], xmm9
0000762f89bd7c5b  vmovaps [rsp+0x90], xmm10
0000762f89bd7c64  vmovaps [rsp+0xA0], xmm11
0000762f89bd7c6d  vmovaps [rsp+0xB0], xmm12
0000762f89bd7c76  vmovaps [rsp+0xC0], xmm13
0000762f89bd7c7f  vmovaps [rsp+0xD0], xmm14
0000762f89bd7c88  vmovaps [rsp+0xE0], xmm15
0000762f89bd7c91  sub rsp, 0x30
0000762f89bd7c95  movaps [rsp], xmm1
0000762f89bd7c99  movaps [rsp+0x10], xmm5
0000762f89bd7c9e  movaps [rsp+0x20], xmm7
0000762f89bd7ca3  lea rdi, [rsp]
0000762f89bd7ca7  mov esi, 0x00
0000762f89bd7cac  mov rax, 0x604D6F946530
0000762f89bd7cb6  call rax
0000762f89bd7cb8  movaps xmm1, [rsp]
0000762f89bd7cbc  add rsp, 0x30
0000762f89bd7cc0  vmovaps xmm0, [rsp]
0000762f89bd7cc5  vmovaps xmm2, [rsp+0x10]
0000762f89bd7ccb  vmovaps xmm3, [rsp+0x20]
0000762f89bd7cd1  vmovaps xmm4, [rsp+0x30]
0000762f89bd7cd7  vmovaps xmm5, [rsp+0x40]
0000762f89bd7cdd  vmovaps xmm6, [rsp+0x50]
0000762f89bd7ce3  vmovaps xmm7, [rsp+0x60]
0000762f89bd7ce9  vmovaps xmm8, [rsp+0x70]
0000762f89bd7cef  vmovaps xmm9, [rsp+0x80]
0000762f89bd7cf8  vmovaps xmm10, [rsp+0x90]
0000762f89bd7d01  vmovaps xmm11, [rsp+0xA0]
0000762f89bd7d0a  vmovaps xmm12, [rsp+0xB0]
0000762f89bd7d13  vmovaps xmm13, [rsp+0xC0]
0000762f89bd7d1c  vmovaps xmm14, [rsp+0xD0]
0000762f89bd7d25  vmovaps xmm15, [rsp+0xE0]
0000762f89bd7d2e  add rsp, 0xF0
0000762f89bd7d35  pop r11
0000762f89bd7d37  pop r10
0000762f89bd7d39  pop r9
0000762f89bd7d3b  pop r8
0000762f89bd7d3d  pop rsi
0000762f89bd7d3e  pop rdi
0000762f89bd7d3f  pop rdx
0000762f89bd7d40  pop rcx
0000762f89bd7d41  pop rax
0000762f89bd7d42  add rsp, 0x08
0000762f89bd7d46  jmp 0x0000762F89BD5E7D
0000762f89bd7d4b  sub rsp, 0x08
0000762f89bd7d4f  push rax
0000762f89bd7d50  push rcx
0000762f89bd7d51  push rdx
0000762f89bd7d52  push rdi
0000762f89bd7d53  push rsi
0000762f89bd7d54  push r8
0000762f89bd7d56  push r9
0000762f89bd7d58  push r10
0000762f89bd7d5a  push r11
0000762f89bd7d5c  sub rsp, 0xF0
0000762f89bd7d63  vmovaps [rsp], xmm0
0000762f89bd7d68  vmovaps [rsp+0x10], xmm1
0000762f89bd7d6e  vmovaps [rsp+0x20], xmm2
0000762f89bd7d74  vmovaps [rsp+0x30], xmm3
0000762f89bd7d7a  vmovaps [rsp+0x40], xmm4
0000762f89bd7d80  vmovaps [rsp+0x50], xmm5
0000762f89bd7d86  vmovaps [rsp+0x60], xmm6
0000762f89bd7d8c  vmovaps [rsp+0x70], xmm8
0000762f89bd7d92  vmovaps [rsp+0x80], xmm9
0000762f89bd7d9b  vmovaps [rsp+0x90], xmm10
0000762f89bd7da4  vmovaps [rsp+0xA0], xmm11
0000762f89bd7dad  vmovaps [rsp+0xB0], xmm12
0000762f89bd7db6  vmovaps [rsp+0xC0], xmm13
0000762f89bd7dbf  vmovaps [rsp+0xD0], xmm14
0000762f89bd7dc8  vmovaps [rsp+0xE0], xmm15
0000762f89bd7dd1  sub rsp, 0x30
0000762f89bd7dd5  movaps [rsp], xmm7
0000762f89bd7dd9  movaps [rsp+0x10], xmm5
0000762f89bd7dde  movaps [rsp+0x20], xmm15
0000762f89bd7de4  lea rdi, [rsp]
0000762f89bd7de8  mov esi, 0x00
0000762f89bd7ded  mov rax, 0x604D6F946530
0000762f89bd7df7  call rax
0000762f89bd7df9  movaps xmm7, [rsp]
0000762f89bd7dfd  add rsp, 0x30
0000762f89bd7e01  vmovaps xmm0, [rsp]
0000762f89bd7e06  vmovaps xmm1, [rsp+0x10]
0000762f89bd7e0c  vmovaps xmm2, [rsp+0x20]
0000762f89bd7e12  vmovaps xmm3, [rsp+0x30]
0000762f89bd7e18  vmovaps xmm4, [rsp+0x40]
0000762f89bd7e1e  vmovaps xmm5, [rsp+0x50]
0000762f89bd7e24  vmovaps xmm6, [rsp+0x60]
0000762f89bd7e2a  vmovaps xmm8, [rsp+0x70]
0000762f89bd7e30  vmovaps xmm9, [rsp+0x80]
0000762f89bd7e39  vmovaps xmm10, [rsp+0x90]
0000762f89bd7e42  vmovaps xmm11, [rsp+0xA0]
0000762f89bd7e4b  vmovaps xmm12, [rsp+0xB0]
0000762f89bd7e54  vmovaps xmm13, [rsp+0xC0]
0000762f89bd7e5d  vmovaps xmm14, [rsp+0xD0]
0000762f89bd7e66  vmovaps xmm15, [rsp+0xE0]
0000762f89bd7e6f  add rsp, 0xF0
0000762f89bd7e76  pop r11
0000762f89bd7e78  pop r10
0000762f89bd7e7a  pop r9
0000762f89bd7e7c  pop r8
0000762f89bd7e7e  pop rsi
0000762f89bd7e7f  pop rdi
0000762f89bd7e80  pop rdx
0000762f89bd7e81  pop rcx
0000762f89bd7e82  pop rax
0000762f89bd7e83  add rsp, 0x08
0000762f89bd7e87  jmp 0x0000762F89BD5EB3
0000762f89bd7e8c  call 0x0000762F89AD64F0
0000762f89bd7e91  jmp 0x0000762F89BD5EC0
0000762f89bd7e96  sub rsp, 0x08
0000762f89bd7e9a  push rax
0000762f89bd7e9b  push rcx
0000762f89bd7e9c  push rdx
0000762f89bd7e9d  push rdi
0000762f89bd7e9e  push rsi
0000762f89bd7e9f  push r8
0000762f89bd7ea1  push r9
0000762f89bd7ea3  push r10
0000762f89bd7ea5  push r11
0000762f89bd7ea7  sub rsp, 0xF0
0000762f89bd7eae  vmovaps [rsp], xmm0
0000762f89bd7eb3  vmovaps [rsp+0x10], xmm1
0000762f89bd7eb9  vmovaps [rsp+0x20], xmm2
0000762f89bd7ebf  vmovaps [rsp+0x30], xmm3
0000762f89bd7ec5  vmovaps [rsp+0x40], xmm4
0000762f89bd7ecb  vmovaps [rsp+0x50], xmm5
0000762f89bd7ed1  vmovaps [rsp+0x60], xmm6
0000762f89bd7ed7  vmovaps [rsp+0x70], xmm7
0000762f89bd7edd  vmovaps [rsp+0x80], xmm8
0000762f89bd7ee6  vmovaps [rsp+0x90], xmm9
0000762f89bd7eef  vmovaps [rsp+0xA0], xmm10
0000762f89bd7ef8  vmovaps [rsp+0xB0], xmm11
0000762f89bd7f01  vmovaps [rsp+0xC0], xmm12
0000762f89bd7f0a  vmovaps [rsp+0xD0], xmm13
0000762f89bd7f13  vmovaps [rsp+0xE0], xmm14
0000762f89bd7f1c  sub rsp, 0x30
0000762f89bd7f20  movaps [rsp], xmm15
0000762f89bd7f25  movaps [rsp+0x10], xmm5
0000762f89bd7f2a  movaps [rsp+0x20], xmm3
0000762f89bd7f2f  lea rdi, [rsp]
0000762f89bd7f33  mov esi, 0x00
0000762f89bd7f38  mov rax, 0x604D6F946530
0000762f89bd7f42  call rax
0000762f89bd7f44  movaps xmm15, [rsp]
0000762f89bd7f49  add rsp, 0x30
0000762f89bd7f4d  vmovaps xmm0, [rsp]
0000762f89bd7f52  vmovaps xmm1, [rsp+0x10]
0000762f89bd7f58  vmovaps xmm2, [rsp+0x20]
0000762f89bd7f5e  vmovaps xmm3, [rsp+0x30]
0000762f89bd7f64  vmovaps xmm4, [rsp+0x40]
0000762f89bd7f6a  vmovaps xmm5, [rsp+0x50]
0000762f89bd7f70  vmovaps xmm6, [rsp+0x60]
0000762f89bd7f76  vmovaps xmm7, [rsp+0x70]
0000762f89bd7f7c  vmovaps xmm8, [rsp+0x80]
0000762f89bd7f85  vmovaps xmm9, [rsp+0x90]
0000762f89bd7f8e  vmovaps xmm10, [rsp+0xA0]
0000762f89bd7f97  vmovaps xmm11, [rsp+0xB0]
0000762f89bd7fa0  vmovaps xmm12, [rsp+0xC0]
0000762f89bd7fa9  vmovaps xmm13, [rsp+0xD0]
0000762f89bd7fb2  vmovaps xmm14, [rsp+0xE0]
0000762f89bd7fbb  add rsp, 0xF0
0000762f89bd7fc2  pop r11
0000762f89bd7fc4  pop r10
0000762f89bd7fc6  pop r9
0000762f89bd7fc8  pop r8
0000762f89bd7fca  pop rsi
0000762f89bd7fcb  pop rdi
0000762f89bd7fcc  pop rdx
0000762f89bd7fcd  pop rcx
0000762f89bd7fce  pop rax
0000762f89bd7fcf  add rsp, 0x08
0000762f89bd7fd3  jmp 0x0000762F89BD5EE6
0000762f89bd7fd8  sub rsp, 0x08
0000762f89bd7fdc  push rax
0000762f89bd7fdd  push rcx
0000762f89bd7fde  push rdx
0000762f89bd7fdf  push rdi
0000762f89bd7fe0  push rsi
0000762f89bd7fe1  push r8
0000762f89bd7fe3  push r9
0000762f89bd7fe5  push r10
0000762f89bd7fe7  push r11
0000762f89bd7fe9  sub rsp, 0xF0
0000762f89bd7ff0  vmovaps [rsp], xmm0
0000762f89bd7ff5  vmovaps [rsp+0x10], xmm2
0000762f89bd7ffb  vmovaps [rsp+0x20], xmm3
0000762f89bd8001  vmovaps [rsp+0x30], xmm4
0000762f89bd8007  vmovaps [rsp+0x40], xmm5
0000762f89bd800d  vmovaps [rsp+0x50], xmm6
0000762f89bd8013  vmovaps [rsp+0x60], xmm7
0000762f89bd8019  vmovaps [rsp+0x70], xmm8
0000762f89bd801f  vmovaps [rsp+0x80], xmm9
0000762f89bd8028  vmovaps [rsp+0x90], xmm10
0000762f89bd8031  vmovaps [rsp+0xA0], xmm11
0000762f89bd803a  vmovaps [rsp+0xB0], xmm12
0000762f89bd8043  vmovaps [rsp+0xC0], xmm13
0000762f89bd804c  vmovaps [rsp+0xD0], xmm14
0000762f89bd8055  vmovaps [rsp+0xE0], xmm15
0000762f89bd805e  sub rsp, 0x30
0000762f89bd8062  movaps [rsp], xmm1
0000762f89bd8066  movaps [rsp+0x10], xmm5
0000762f89bd806b  movaps [rsp+0x20], xmm4
0000762f89bd8070  lea rdi, [rsp]
0000762f89bd8074  mov esi, 0x00
0000762f89bd8079  mov rax, 0x604D6F946530
0000762f89bd8083  call rax
0000762f89bd8085  movaps xmm1, [rsp]
0000762f89bd8089  add rsp, 0x30
0000762f89bd808d  vmovaps xmm0, [rsp]
0000762f89bd8092  vmovaps xmm2, [rsp+0x10]
0000762f89bd8098  vmovaps xmm3, [rsp+0x20]
0000762f89bd809e  vmovaps xmm4, [rsp+0x30]
0000762f89bd80a4  vmovaps xmm5, [rsp+0x40]
0000762f89bd80aa  vmovaps xmm6, [rsp+0x50]
0000762f89bd80b0  vmovaps xmm7, [rsp+0x60]
0000762f89bd80b6  vmovaps xmm8, [rsp+0x70]
0000762f89bd80bc  vmovaps xmm9, [rsp+0x80]
0000762f89bd80c5  vmovaps xmm10, [rsp+0x90]
0000762f89bd80ce  vmovaps xmm11, [rsp+0xA0]
0000762f89bd80d7  vmovaps xmm12, [rsp+0xB0]
0000762f89bd80e0  vmovaps xmm13, [rsp+0xC0]
0000762f89bd80e9  vmovaps xmm14, [rsp+0xD0]
0000762f89bd80f2  vmovaps xmm15, [rsp+0xE0]
0000762f89bd80fb  add rsp, 0xF0
0000762f89bd8102  pop r11
0000762f89bd8104  pop r10
0000762f89bd8106  pop r9
0000762f89bd8108  pop r8
0000762f89bd810a  pop rsi
0000762f89bd810b  pop rdi
0000762f89bd810c  pop rdx
0000762f89bd810d  pop rcx
0000762f89bd810e  pop rax
0000762f89bd810f  add rsp, 0x08
0000762f89bd8113  jmp 0x0000762F89BD5F06
0000762f89bd8118  sub rsp, 0x08
0000762f89bd811c  push rax
0000762f89bd811d  push rcx
0000762f89bd811e  push rdx
0000762f89bd811f  push rdi
0000762f89bd8120  push rsi
0000762f89bd8121  push r8
0000762f89bd8123  push r9
0000762f89bd8125  push r10
0000762f89bd8127  push r11
0000762f89bd8129  sub rsp, 0xF0
0000762f89bd8130  vmovaps [rsp], xmm0
0000762f89bd8135  vmovaps [rsp+0x10], xmm1
0000762f89bd813b  vmovaps [rsp+0x20], xmm2
0000762f89bd8141  vmovaps [rsp+0x30], xmm3
0000762f89bd8147  vmovaps [rsp+0x40], xmm5
0000762f89bd814d  vmovaps [rsp+0x50], xmm6
0000762f89bd8153  vmovaps [rsp+0x60], xmm7
0000762f89bd8159  vmovaps [rsp+0x70], xmm8
0000762f89bd815f  vmovaps [rsp+0x80], xmm9
0000762f89bd8168  vmovaps [rsp+0x90], xmm10
0000762f89bd8171  vmovaps [rsp+0xA0], xmm11
0000762f89bd817a  vmovaps [rsp+0xB0], xmm12
0000762f89bd8183  vmovaps [rsp+0xC0], xmm13
0000762f89bd818c  vmovaps [rsp+0xD0], xmm14
0000762f89bd8195  vmovaps [rsp+0xE0], xmm15
0000762f89bd819e  sub rsp, 0x30
0000762f89bd81a2  movaps [rsp], xmm4
0000762f89bd81a6  movaps [rsp+0x10], xmm3
0000762f89bd81ab  movaps [rsp+0x20], xmm5
0000762f89bd81b0  lea rdi, [rsp]
0000762f89bd81b4  mov esi, 0x00
0000762f89bd81b9  mov rax, 0x604D6F946530
0000762f89bd81c3  call rax
0000762f89bd81c5  movaps xmm4, [rsp]
0000762f89bd81c9  add rsp, 0x30
0000762f89bd81cd  vmovaps xmm0, [rsp]
0000762f89bd81d2  vmovaps xmm1, [rsp+0x10]
0000762f89bd81d8  vmovaps xmm2, [rsp+0x20]
0000762f89bd81de  vmovaps xmm3, [rsp+0x30]
0000762f89bd81e4  vmovaps xmm5, [rsp+0x40]
0000762f89bd81ea  vmovaps xmm6, [rsp+0x50]
0000762f89bd81f0  vmovaps xmm7, [rsp+0x60]
0000762f89bd81f6  vmovaps xmm8, [rsp+0x70]
0000762f89bd81fc  vmovaps xmm9, [rsp+0x80]
0000762f89bd8205  vmovaps xmm10, [rsp+0x90]
0000762f89bd820e  vmovaps xmm11, [rsp+0xA0]
0000762f89bd8217  vmovaps xmm12, [rsp+0xB0]
0000762f89bd8220  vmovaps xmm13, [rsp+0xC0]
0000762f89bd8229  vmovaps xmm14, [rsp+0xD0]
0000762f89bd8232  vmovaps xmm15, [rsp+0xE0]
0000762f89bd823b  add rsp, 0xF0
0000762f89bd8242  pop r11
0000762f89bd8244  pop r10
0000762f89bd8246  pop r9
0000762f89bd8248  pop r8
0000762f89bd824a  pop rsi
0000762f89bd824b  pop rdi
0000762f89bd824c  pop rdx
0000762f89bd824d  pop rcx
0000762f89bd824e  pop rax
0000762f89bd824f  add rsp, 0x08
0000762f89bd8253  jmp 0x0000762F89BD5F54
0000762f89bd8258  call 0x0000762F89AD64F0
0000762f89bd825d  jmp 0x0000762F89BD5F61
0000762f89bd8262  sub rsp, 0x08
0000762f89bd8266  push rax
0000762f89bd8267  push rcx
0000762f89bd8268  push rdx
0000762f89bd8269  push rdi
0000762f89bd826a  push rsi
0000762f89bd826b  push r8
0000762f89bd826d  push r9
0000762f89bd826f  push r10
0000762f89bd8271  push r11
0000762f89bd8273  sub rsp, 0xF0
0000762f89bd827a  vmovaps [rsp], xmm0
0000762f89bd827f  vmovaps [rsp+0x10], xmm1
0000762f89bd8285  vmovaps [rsp+0x20], xmm2
0000762f89bd828b  vmovaps [rsp+0x30], xmm3
0000762f89bd8291  vmovaps [rsp+0x40], xmm4
0000762f89bd8297  vmovaps [rsp+0x50], xmm6
0000762f89bd829d  vmovaps [rsp+0x60], xmm7
0000762f89bd82a3  vmovaps [rsp+0x70], xmm8
0000762f89bd82a9  vmovaps [rsp+0x80], xmm9
0000762f89bd82b2  vmovaps [rsp+0x90], xmm10
0000762f89bd82bb  vmovaps [rsp+0xA0], xmm11
0000762f89bd82c4  vmovaps [rsp+0xB0], xmm12
0000762f89bd82cd  vmovaps [rsp+0xC0], xmm13
0000762f89bd82d6  vmovaps [rsp+0xD0], xmm14
0000762f89bd82df  vmovaps [rsp+0xE0], xmm15
0000762f89bd82e8  sub rsp, 0x30
0000762f89bd82ec  movaps [rsp], xmm5
0000762f89bd82f0  movaps [rsp+0x10], xmm6
0000762f89bd82f5  movaps [rsp+0x20], xmm3
0000762f89bd82fa  lea rdi, [rsp]
0000762f89bd82fe  mov esi, 0x00
0000762f89bd8303  mov rax, 0x604D6F946530
0000762f89bd830d  call rax
0000762f89bd830f  movaps xmm5, [rsp]
0000762f89bd8313  add rsp, 0x30
0000762f89bd8317  vmovaps xmm0, [rsp]
0000762f89bd831c  vmovaps xmm1, [rsp+0x10]
0000762f89bd8322  vmovaps xmm2, [rsp+0x20]
0000762f89bd8328  vmovaps xmm3, [rsp+0x30]
0000762f89bd832e  vmovaps xmm4, [rsp+0x40]
0000762f89bd8334  vmovaps xmm6, [rsp+0x50]
0000762f89bd833a  vmovaps xmm7, [rsp+0x60]
0000762f89bd8340  vmovaps xmm8, [rsp+0x70]
0000762f89bd8346  vmovaps xmm9, [rsp+0x80]
0000762f89bd834f  vmovaps xmm10, [rsp+0x90]
0000762f89bd8358  vmovaps xmm11, [rsp+0xA0]
0000762f89bd8361  vmovaps xmm12, [rsp+0xB0]
0000762f89bd836a  vmovaps xmm13, [rsp+0xC0]
0000762f89bd8373  vmovaps xmm14, [rsp+0xD0]
0000762f89bd837c  vmovaps xmm15, [rsp+0xE0]
0000762f89bd8385  add rsp, 0xF0
0000762f89bd838c  pop r11
0000762f89bd838e  pop r10
0000762f89bd8390  pop r9
0000762f89bd8392  pop r8
0000762f89bd8394  pop rsi
0000762f89bd8395  pop rdi
0000762f89bd8396  pop rdx
0000762f89bd8397  pop rcx
0000762f89bd8398  pop rax
0000762f89bd8399  add rsp, 0x08
0000762f89bd839d  jmp 0x0000762F89BD5F87
0000762f89bd83a2  sub rsp, 0x08
0000762f89bd83a6  push rax
0000762f89bd83a7  push rcx
0000762f89bd83a8  push rdx
0000762f89bd83a9  push rdi
0000762f89bd83aa  push rsi
0000762f89bd83ab  push r8
0000762f89bd83ad  push r9
0000762f89bd83af  push r10
0000762f89bd83b1  push r11
0000762f89bd83b3  sub rsp, 0xF0
0000762f89bd83ba  vmovaps [rsp], xmm0
0000762f89bd83bf  vmovaps [rsp+0x10], xmm1
0000762f89bd83c5  vmovaps [rsp+0x20], xmm2
0000762f89bd83cb  vmovaps [rsp+0x30], xmm3
0000762f89bd83d1  vmovaps [rsp+0x40], xmm4
0000762f89bd83d7  vmovaps [rsp+0x50], xmm5
0000762f89bd83dd  vmovaps [rsp+0x60], xmm7
0000762f89bd83e3  vmovaps [rsp+0x70], xmm8
0000762f89bd83e9  vmovaps [rsp+0x80], xmm9
0000762f89bd83f2  vmovaps [rsp+0x90], xmm10
0000762f89bd83fb  vmovaps [rsp+0xA0], xmm11
0000762f89bd8404  vmovaps [rsp+0xB0], xmm12
0000762f89bd840d  vmovaps [rsp+0xC0], xmm13
0000762f89bd8416  vmovaps [rsp+0xD0], xmm14
0000762f89bd841f  vmovaps [rsp+0xE0], xmm15
0000762f89bd8428  sub rsp, 0x30
0000762f89bd842c  movaps [rsp], xmm6
0000762f89bd8430  movaps [rsp+0x10], xmm9
0000762f89bd8436  movaps [rsp+0x20], xmm1
0000762f89bd843b  lea rdi, [rsp]
0000762f89bd843f  mov esi, 0x00
0000762f89bd8444  mov rax, 0x604D6F946530
0000762f89bd844e  call rax
0000762f89bd8450  movaps xmm6, [rsp]
0000762f89bd8454  add rsp, 0x30
0000762f89bd8458  vmovaps xmm0, [rsp]
0000762f89bd845d  vmovaps xmm1, [rsp+0x10]
0000762f89bd8463  vmovaps xmm2, [rsp+0x20]
0000762f89bd8469  vmovaps xmm3, [rsp+0x30]
0000762f89bd846f  vmovaps xmm4, [rsp+0x40]
0000762f89bd8475  vmovaps xmm5, [rsp+0x50]
0000762f89bd847b  vmovaps xmm7, [rsp+0x60]
0000762f89bd8481  vmovaps xmm8, [rsp+0x70]
0000762f89bd8487  vmovaps xmm9, [rsp+0x80]
0000762f89bd8490  vmovaps xmm10, [rsp+0x90]
0000762f89bd8499  vmovaps xmm11, [rsp+0xA0]
0000762f89bd84a2  vmovaps xmm12, [rsp+0xB0]
0000762f89bd84ab  vmovaps xmm13, [rsp+0xC0]
0000762f89bd84b4  vmovaps xmm14, [rsp+0xD0]
0000762f89bd84bd  vmovaps xmm15, [rsp+0xE0]
0000762f89bd84c6  add rsp, 0xF0
0000762f89bd84cd  pop r11
0000762f89bd84cf  pop r10
0000762f89bd84d1  pop r9
0000762f89bd84d3  pop r8
0000762f89bd84d5  pop rsi
0000762f89bd84d6  pop rdi
0000762f89bd84d7  pop rdx
0000762f89bd84d8  pop rcx
0000762f89bd84d9  pop rax
0000762f89bd84da  add rsp, 0x08
0000762f89bd84de  jmp 0x0000762F89BD5FAB
0000762f89bd84e3  sub rsp, 0x08
0000762f89bd84e7  push rax
0000762f89bd84e8  push rcx
0000762f89bd84e9  push rdx
0000762f89bd84ea  push rdi
0000762f89bd84eb  push rsi
0000762f89bd84ec  push r8
0000762f89bd84ee  push r9
0000762f89bd84f0  push r10
0000762f89bd84f2  push r11
0000762f89bd84f4  sub rsp, 0xF0
0000762f89bd84fb  vmovaps [rsp], xmm0
0000762f89bd8500  vmovaps [rsp+0x10], xmm1
0000762f89bd8506  vmovaps [rsp+0x20], xmm2
0000762f89bd850c  vmovaps [rsp+0x30], xmm3
0000762f89bd8512  vmovaps [rsp+0x40], xmm4
0000762f89bd8518  vmovaps [rsp+0x50], xmm5
0000762f89bd851e  vmovaps [rsp+0x60], xmm6
0000762f89bd8524  vmovaps [rsp+0x70], xmm7
0000762f89bd852a  vmovaps [rsp+0x80], xmm8
0000762f89bd8533  vmovaps [rsp+0x90], xmm10
0000762f89bd853c  vmovaps [rsp+0xA0], xmm11
0000762f89bd8545  vmovaps [rsp+0xB0], xmm12
0000762f89bd854e  vmovaps [rsp+0xC0], xmm13
0000762f89bd8557  vmovaps [rsp+0xD0], xmm14
0000762f89bd8560  vmovaps [rsp+0xE0], xmm15
0000762f89bd8569  sub rsp, 0x30
0000762f89bd856d  movaps [rsp], xmm9
0000762f89bd8572  movaps [rsp+0x10], xmm3
0000762f89bd8577  movaps [rsp+0x20], xmm1
0000762f89bd857c  lea rdi, [rsp]
0000762f89bd8580  mov esi, 0x00
0000762f89bd8585  mov rax, 0x604D6F946530
0000762f89bd858f  call rax
0000762f89bd8591  movaps xmm9, [rsp]
0000762f89bd8596  add rsp, 0x30
0000762f89bd859a  vmovaps xmm0, [rsp]
0000762f89bd859f  vmovaps xmm1, [rsp+0x10]
0000762f89bd85a5  vmovaps xmm2, [rsp+0x20]
0000762f89bd85ab  vmovaps xmm3, [rsp+0x30]
0000762f89bd85b1  vmovaps xmm4, [rsp+0x40]
0000762f89bd85b7  vmovaps xmm5, [rsp+0x50]
0000762f89bd85bd  vmovaps xmm6, [rsp+0x60]
0000762f89bd85c3  vmovaps xmm7, [rsp+0x70]
0000762f89bd85c9  vmovaps xmm8, [rsp+0x80]
0000762f89bd85d2  vmovaps xmm10, [rsp+0x90]
0000762f89bd85db  vmovaps xmm11, [rsp+0xA0]
0000762f89bd85e4  vmovaps xmm12, [rsp+0xB0]
0000762f89bd85ed  vmovaps xmm13, [rsp+0xC0]
0000762f89bd85f6  vmovaps xmm14, [rsp+0xD0]
0000762f89bd85ff  vmovaps xmm15, [rsp+0xE0]
0000762f89bd8608  add rsp, 0xF0
0000762f89bd860f  pop r11
0000762f89bd8611  pop r10
0000762f89bd8613  pop r9
0000762f89bd8615  pop r8
0000762f89bd8617  pop rsi
0000762f89bd8618  pop rdi
0000762f89bd8619  pop rdx
0000762f89bd861a  pop rcx
0000762f89bd861b  pop rax
0000762f89bd861c  add rsp, 0x08
0000762f89bd8620  jmp 0x0000762F89BD5FF7
0000762f89bd8625  call 0x0000762F89AD64F0
0000762f89bd862a  jmp 0x0000762F89BD6004
0000762f89bd862f  sub rsp, 0x08
0000762f89bd8633  push rax
0000762f89bd8634  push rcx
0000762f89bd8635  push rdx
0000762f89bd8636  push rdi
0000762f89bd8637  push rsi
0000762f89bd8638  push r8
0000762f89bd863a  push r9
0000762f89bd863c  push r10
0000762f89bd863e  push r11
0000762f89bd8640  sub rsp, 0xF0
0000762f89bd8647  vmovaps [rsp], xmm0
0000762f89bd864c  vmovaps [rsp+0x10], xmm1
0000762f89bd8652  vmovaps [rsp+0x20], xmm2
0000762f89bd8658  vmovaps [rsp+0x30], xmm3
0000762f89bd865e  vmovaps [rsp+0x40], xmm4
0000762f89bd8664  vmovaps [rsp+0x50], xmm5
0000762f89bd866a  vmovaps [rsp+0x60], xmm6
0000762f89bd8670  vmovaps [rsp+0x70], xmm7
0000762f89bd8676  vmovaps [rsp+0x80], xmm8
0000762f89bd867f  vmovaps [rsp+0x90], xmm9
0000762f89bd8688  vmovaps [rsp+0xA0], xmm10
0000762f89bd8691  vmovaps [rsp+0xB0], xmm11
0000762f89bd869a  vmovaps [rsp+0xC0], xmm12
0000762f89bd86a3  vmovaps [rsp+0xD0], xmm13
0000762f89bd86ac  vmovaps [rsp+0xE0], xmm14
0000762f89bd86b5  sub rsp, 0x30
0000762f89bd86b9  movaps [rsp], xmm15
0000762f89bd86be  movaps [rsp+0x10], xmm3
0000762f89bd86c3  movaps [rsp+0x20], xmm7
0000762f89bd86c8  lea rdi, [rsp]
0000762f89bd86cc  mov esi, 0x00
0000762f89bd86d1  mov rax, 0x604D6F946530
0000762f89bd86db  call rax
0000762f89bd86dd  movaps xmm15, [rsp]
0000762f89bd86e2  add rsp, 0x30
0000762f89bd86e6  vmovaps xmm0, [rsp]
0000762f89bd86eb  vmovaps xmm1, [rsp+0x10]
0000762f89bd86f1  vmovaps xmm2, [rsp+0x20]
0000762f89bd86f7  vmovaps xmm3, [rsp+0x30]
0000762f89bd86fd  vmovaps xmm4, [rsp+0x40]
0000762f89bd8703  vmovaps xmm5, [rsp+0x50]
0000762f89bd8709  vmovaps xmm6, [rsp+0x60]
0000762f89bd870f  vmovaps xmm7, [rsp+0x70]
0000762f89bd8715  vmovaps xmm8, [rsp+0x80]
0000762f89bd871e  vmovaps xmm9, [rsp+0x90]
0000762f89bd8727  vmovaps xmm10, [rsp+0xA0]
0000762f89bd8730  vmovaps xmm11, [rsp+0xB0]
0000762f89bd8739  vmovaps xmm12, [rsp+0xC0]
0000762f89bd8742  vmovaps xmm13, [rsp+0xD0]
0000762f89bd874b  vmovaps xmm14, [rsp+0xE0]
0000762f89bd8754  add rsp, 0xF0
0000762f89bd875b  pop r11
0000762f89bd875d  pop r10
0000762f89bd875f  pop r9
0000762f89bd8761  pop r8
0000762f89bd8763  pop rsi
0000762f89bd8764  pop rdi
0000762f89bd8765  pop rdx
0000762f89bd8766  pop rcx
0000762f89bd8767  pop rax
0000762f89bd8768  add rsp, 0x08
0000762f89bd876c  jmp 0x0000762F89BD6030
0000762f89bd8771  sub rsp, 0x08
0000762f89bd8775  push rax
0000762f89bd8776  push rcx
0000762f89bd8777  push rdx
0000762f89bd8778  push rdi
0000762f89bd8779  push rsi
0000762f89bd877a  push r8
0000762f89bd877c  push r9
0000762f89bd877e  push r10
0000762f89bd8780  push r11
0000762f89bd8782  sub rsp, 0xF0
0000762f89bd8789  vmovaps [rsp], xmm0
0000762f89bd878e  vmovaps [rsp+0x10], xmm1
0000762f89bd8794  vmovaps [rsp+0x20], xmm2
0000762f89bd879a  vmovaps [rsp+0x30], xmm4
0000762f89bd87a0  vmovaps [rsp+0x40], xmm5
0000762f89bd87a6  vmovaps [rsp+0x50], xmm6
0000762f89bd87ac  vmovaps [rsp+0x60], xmm7
0000762f89bd87b2  vmovaps [rsp+0x70], xmm8
0000762f89bd87b8  vmovaps [rsp+0x80], xmm9
0000762f89bd87c1  vmovaps [rsp+0x90], xmm10
0000762f89bd87ca  vmovaps [rsp+0xA0], xmm11
0000762f89bd87d3  vmovaps [rsp+0xB0], xmm12
0000762f89bd87dc  vmovaps [rsp+0xC0], xmm13
0000762f89bd87e5  vmovaps [rsp+0xD0], xmm14
0000762f89bd87ee  vmovaps [rsp+0xE0], xmm15
0000762f89bd87f7  sub rsp, 0x30
0000762f89bd87fb  movaps [rsp], xmm3
0000762f89bd87ff  movaps [rsp+0x10], xmm1
0000762f89bd8804  movaps [rsp+0x20], xmm15
0000762f89bd880a  lea rdi, [rsp]
0000762f89bd880e  mov esi, 0x00
0000762f89bd8813  mov rax, 0x604D6F946530
0000762f89bd881d  call rax
0000762f89bd881f  movaps xmm3, [rsp]
0000762f89bd8823  add rsp, 0x30
0000762f89bd8827  vmovaps xmm0, [rsp]
0000762f89bd882c  vmovaps xmm1, [rsp+0x10]
0000762f89bd8832  vmovaps xmm2, [rsp+0x20]
0000762f89bd8838  vmovaps xmm4, [rsp+0x30]
0000762f89bd883e  vmovaps xmm5, [rsp+0x40]
0000762f89bd8844  vmovaps xmm6, [rsp+0x50]
0000762f89bd884a  vmovaps xmm7, [rsp+0x60]
0000762f89bd8850  vmovaps xmm8, [rsp+0x70]
0000762f89bd8856  vmovaps xmm9, [rsp+0x80]
0000762f89bd885f  vmovaps xmm10, [rsp+0x90]
0000762f89bd8868  vmovaps xmm11, [rsp+0xA0]
0000762f89bd8871  vmovaps xmm12, [rsp+0xB0]
0000762f89bd887a  vmovaps xmm13, [rsp+0xC0]
0000762f89bd8883  vmovaps xmm14, [rsp+0xD0]
0000762f89bd888c  vmovaps xmm15, [rsp+0xE0]
0000762f89bd8895  add rsp, 0xF0
0000762f89bd889c  pop r11
0000762f89bd889e  pop r10
0000762f89bd88a0  pop r9
0000762f89bd88a2  pop r8
0000762f89bd88a4  pop rsi
0000762f89bd88a5  pop rdi
0000762f89bd88a6  pop rdx
0000762f89bd88a7  pop rcx
0000762f89bd88a8  pop rax
0000762f89bd88a9  add rsp, 0x08
0000762f89bd88ad  jmp 0x0000762F89BD60BF
0000762f89bd88b2  call 0x0000762F89AD64F0
0000762f89bd88b7  jmp 0x0000762F89BD60C9
0000762f89bd88bc  sub rsp, 0x08
0000762f89bd88c0  push rax
0000762f89bd88c1  push rcx
0000762f89bd88c2  push rdx
0000762f89bd88c3  push rdi
0000762f89bd88c4  push rsi
0000762f89bd88c5  push r8
0000762f89bd88c7  push r9
0000762f89bd88c9  push r10
0000762f89bd88cb  push r11
0000762f89bd88cd  sub rsp, 0xF0
0000762f89bd88d4  vmovaps [rsp], xmm0
0000762f89bd88d9  vmovaps [rsp+0x10], xmm1
0000762f89bd88df  vmovaps [rsp+0x20], xmm2
0000762f89bd88e5  vmovaps [rsp+0x30], xmm3
0000762f89bd88eb  vmovaps [rsp+0x40], xmm4
0000762f89bd88f1  vmovaps [rsp+0x50], xmm5
0000762f89bd88f7  vmovaps [rsp+0x60], xmm6
0000762f89bd88fd  vmovaps [rsp+0x70], xmm7
0000762f89bd8903  vmovaps [rsp+0x80], xmm8
0000762f89bd890c  vmovaps [rsp+0x90], xmm9
0000762f89bd8915  vmovaps [rsp+0xA0], xmm10
0000762f89bd891e  vmovaps [rsp+0xB0], xmm11
0000762f89bd8927  vmovaps [rsp+0xC0], xmm12
0000762f89bd8930  vmovaps [rsp+0xD0], xmm13
0000762f89bd8939  vmovaps [rsp+0xE0], xmm14
0000762f89bd8942  sub rsp, 0x30
0000762f89bd8946  movaps [rsp], xmm15
0000762f89bd894b  movaps [rsp+0x10], xmm14
0000762f89bd8951  movaps [rsp+0x20], xmm4
0000762f89bd8956  lea rdi, [rsp]
0000762f89bd895a  mov esi, 0x00
0000762f89bd895f  mov rax, 0x604D6F946530
0000762f89bd8969  call rax
0000762f89bd896b  movaps xmm15, [rsp]
0000762f89bd8970  add rsp, 0x30
0000762f89bd8974  vmovaps xmm0, [rsp]
0000762f89bd8979  vmovaps xmm1, [rsp+0x10]
0000762f89bd897f  vmovaps xmm2, [rsp+0x20]
0000762f89bd8985  vmovaps xmm3, [rsp+0x30]
0000762f89bd898b  vmovaps xmm4, [rsp+0x40]
0000762f89bd8991  vmovaps xmm5, [rsp+0x50]
0000762f89bd8997  vmovaps xmm6, [rsp+0x60]
0000762f89bd899d  vmovaps xmm7, [rsp+0x70]
0000762f89bd89a3  vmovaps xmm8, [rsp+0x80]
0000762f89bd89ac  vmovaps xmm9, [rsp+0x90]
0000762f89bd89b5  vmovaps xmm10, [rsp+0xA0]
0000762f89bd89be  vmovaps xmm11, [rsp+0xB0]
0000762f89bd89c7  vmovaps xmm12, [rsp+0xC0]
0000762f89bd89d0  vmovaps xmm13, [rsp+0xD0]
0000762f89bd89d9  vmovaps xmm14, [rsp+0xE0]
0000762f89bd89e2  add rsp, 0xF0
0000762f89bd89e9  pop r11
0000762f89bd89eb  pop r10
0000762f89bd89ed  pop r9
0000762f89bd89ef  pop r8
0000762f89bd89f1  pop rsi
0000762f89bd89f2  pop rdi
0000762f89bd89f3  pop rdx
0000762f89bd89f4  pop rcx
0000762f89bd89f5  pop rax
0000762f89bd89f6  add rsp, 0x08
0000762f89bd89fa  jmp 0x0000762F89BD60F7
0000762f89bd89ff  sub rsp, 0x08
0000762f89bd8a03  push rax
0000762f89bd8a04  push rcx
0000762f89bd8a05  push rdx
0000762f89bd8a06  push rdi
0000762f89bd8a07  push rsi
0000762f89bd8a08  push r8
0000762f89bd8a0a  push r9
0000762f89bd8a0c  push r10
0000762f89bd8a0e  push r11
0000762f89bd8a10  sub rsp, 0xF0
0000762f89bd8a17  vmovaps [rsp], xmm0
0000762f89bd8a1c  vmovaps [rsp+0x10], xmm1
0000762f89bd8a22  vmovaps [rsp+0x20], xmm2
0000762f89bd8a28  vmovaps [rsp+0x30], xmm3
0000762f89bd8a2e  vmovaps [rsp+0x40], xmm4
0000762f89bd8a34  vmovaps [rsp+0x50], xmm5
0000762f89bd8a3a  vmovaps [rsp+0x60], xmm6
0000762f89bd8a40  vmovaps [rsp+0x70], xmm7
0000762f89bd8a46  vmovaps [rsp+0x80], xmm8
0000762f89bd8a4f  vmovaps [rsp+0x90], xmm9
0000762f89bd8a58  vmovaps [rsp+0xA0], xmm10
0000762f89bd8a61  vmovaps [rsp+0xB0], xmm11
0000762f89bd8a6a  vmovaps [rsp+0xC0], xmm12
0000762f89bd8a73  vmovaps [rsp+0xD0], xmm13
0000762f89bd8a7c  vmovaps [rsp+0xE0], xmm15
0000762f89bd8a85  sub rsp, 0x30
0000762f89bd8a89  movaps [rsp], xmm14
0000762f89bd8a8e  movaps [rsp+0x10], xmm2
0000762f89bd8a93  movaps [rsp+0x20], xmm1
0000762f89bd8a98  lea rdi, [rsp]
0000762f89bd8a9c  mov esi, 0x00
0000762f89bd8aa1  mov rax, 0x604D6F946530
0000762f89bd8aab  call rax
0000762f89bd8aad  movaps xmm14, [rsp]
0000762f89bd8ab2  add rsp, 0x30
0000762f89bd8ab6  vmovaps xmm0, [rsp]
0000762f89bd8abb  vmovaps xmm1, [rsp+0x10]
0000762f89bd8ac1  vmovaps xmm2, [rsp+0x20]
0000762f89bd8ac7  vmovaps xmm3, [rsp+0x30]
0000762f89bd8acd  vmovaps xmm4, [rsp+0x40]
0000762f89bd8ad3  vmovaps xmm5, [rsp+0x50]
0000762f89bd8ad9  vmovaps xmm6, [rsp+0x60]
0000762f89bd8adf  vmovaps xmm7, [rsp+0x70]
0000762f89bd8ae5  vmovaps xmm8, [rsp+0x80]
0000762f89bd8aee  vmovaps xmm9, [rsp+0x90]
0000762f89bd8af7  vmovaps xmm10, [rsp+0xA0]
0000762f89bd8b00  vmovaps xmm11, [rsp+0xB0]
0000762f89bd8b09  vmovaps xmm12, [rsp+0xC0]
0000762f89bd8b12  vmovaps xmm13, [rsp+0xD0]
0000762f89bd8b1b  vmovaps xmm15, [rsp+0xE0]
0000762f89bd8b24  add rsp, 0xF0
0000762f89bd8b2b  pop r11
0000762f89bd8b2d  pop r10
0000762f89bd8b2f  pop r9
0000762f89bd8b31  pop r8
0000762f89bd8b33  pop rsi
0000762f89bd8b34  pop rdi
0000762f89bd8b35  pop rdx
0000762f89bd8b36  pop rcx
0000762f89bd8b37  pop rax
0000762f89bd8b38  add rsp, 0x08
0000762f89bd8b3c  jmp 0x0000762F89BD611D
0000762f89bd8b41  sub rsp, 0x08
0000762f89bd8b45  push rax
0000762f89bd8b46  push rcx
0000762f89bd8b47  push rdx
0000762f89bd8b48  push rdi
0000762f89bd8b49  push rsi
0000762f89bd8b4a  push r8
0000762f89bd8b4c  push r9
0000762f89bd8b4e  push r10
0000762f89bd8b50  push r11
0000762f89bd8b52  sub rsp, 0xF0
0000762f89bd8b59  vmovaps [rsp], xmm0
0000762f89bd8b5e  vmovaps [rsp+0x10], xmm2
0000762f89bd8b64  vmovaps [rsp+0x20], xmm3
0000762f89bd8b6a  vmovaps [rsp+0x30], xmm4
0000762f89bd8b70  vmovaps [rsp+0x40], xmm5
0000762f89bd8b76  vmovaps [rsp+0x50], xmm6
0000762f89bd8b7c  vmovaps [rsp+0x60], xmm7
0000762f89bd8b82  vmovaps [rsp+0x70], xmm8
0000762f89bd8b88  vmovaps [rsp+0x80], xmm9
0000762f89bd8b91  vmovaps [rsp+0x90], xmm10
0000762f89bd8b9a  vmovaps [rsp+0xA0], xmm11
0000762f89bd8ba3  vmovaps [rsp+0xB0], xmm12
0000762f89bd8bac  vmovaps [rsp+0xC0], xmm13
0000762f89bd8bb5  vmovaps [rsp+0xD0], xmm14
0000762f89bd8bbe  vmovaps [rsp+0xE0], xmm15
0000762f89bd8bc7  sub rsp, 0x30
0000762f89bd8bcb  movaps [rsp], xmm1
0000762f89bd8bcf  movaps [rsp+0x10], xmm4
0000762f89bd8bd4  movaps [rsp+0x20], xmm9
0000762f89bd8bda  lea rdi, [rsp]
0000762f89bd8bde  mov esi, 0x00
0000762f89bd8be3  mov rax, 0x604D6F946530
0000762f89bd8bed  call rax
0000762f89bd8bef  movaps xmm1, [rsp]
0000762f89bd8bf3  add rsp, 0x30
0000762f89bd8bf7  vmovaps xmm0, [rsp]
0000762f89bd8bfc  vmovaps xmm2, [rsp+0x10]
0000762f89bd8c02  vmovaps xmm3, [rsp+0x20]
0000762f89bd8c08  vmovaps xmm4, [rsp+0x30]
0000762f89bd8c0e  vmovaps xmm5, [rsp+0x40]
0000762f89bd8c14  vmovaps xmm6, [rsp+0x50]
0000762f89bd8c1a  vmovaps xmm7, [rsp+0x60]
0000762f89bd8c20  vmovaps xmm8, [rsp+0x70]
0000762f89bd8c26  vmovaps xmm9, [rsp+0x80]
0000762f89bd8c2f  vmovaps xmm10, [rsp+0x90]
0000762f89bd8c38  vmovaps xmm11, [rsp+0xA0]
0000762f89bd8c41  vmovaps xmm12, [rsp+0xB0]
0000762f89bd8c4a  vmovaps xmm13, [rsp+0xC0]
0000762f89bd8c53  vmovaps xmm14, [rsp+0xD0]
0000762f89bd8c5c  vmovaps xmm15, [rsp+0xE0]
0000762f89bd8c65  add rsp, 0xF0
0000762f89bd8c6c  pop r11
0000762f89bd8c6e  pop r10
0000762f89bd8c70  pop r9
0000762f89bd8c72  pop r8
0000762f89bd8c74  pop rsi
0000762f89bd8c75  pop rdi
0000762f89bd8c76  pop rdx
0000762f89bd8c77  pop rcx
0000762f89bd8c78  pop rax
0000762f89bd8c79  add rsp, 0x08
0000762f89bd8c7d  jmp 0x0000762F89BD613B
0000762f89bd8c82  sub rsp, 0x08
0000762f89bd8c86  push rax
0000762f89bd8c87  push rcx
0000762f89bd8c88  push rdx
0000762f89bd8c89  push rdi
0000762f89bd8c8a  push rsi
0000762f89bd8c8b  push r8
0000762f89bd8c8d  push r9
0000762f89bd8c8f  push r10
0000762f89bd8c91  push r11
0000762f89bd8c93  sub rsp, 0xF0
0000762f89bd8c9a  vmovaps [rsp], xmm0
0000762f89bd8c9f  vmovaps [rsp+0x10], xmm1
0000762f89bd8ca5  vmovaps [rsp+0x20], xmm2
0000762f89bd8cab  vmovaps [rsp+0x30], xmm3
0000762f89bd8cb1  vmovaps [rsp+0x40], xmm5
0000762f89bd8cb7  vmovaps [rsp+0x50], xmm6
0000762f89bd8cbd  vmovaps [rsp+0x60], xmm7
0000762f89bd8cc3  vmovaps [rsp+0x70], xmm8
0000762f89bd8cc9  vmovaps [rsp+0x80], xmm9
0000762f89bd8cd2  vmovaps [rsp+0x90], xmm10
0000762f89bd8cdb  vmovaps [rsp+0xA0], xmm11
0000762f89bd8ce4  vmovaps [rsp+0xB0], xmm12
0000762f89bd8ced  vmovaps [rsp+0xC0], xmm13
0000762f89bd8cf6  vmovaps [rsp+0xD0], xmm14
0000762f89bd8cff  vmovaps [rsp+0xE0], xmm15
0000762f89bd8d08  sub rsp, 0x30
0000762f89bd8d0c  movaps [rsp], xmm4
0000762f89bd8d10  movaps [rsp+0x10], xmm2
0000762f89bd8d15  movaps [rsp+0x20], xmm9
0000762f89bd8d1b  lea rdi, [rsp]
0000762f89bd8d1f  mov esi, 0x00
0000762f89bd8d24  mov rax, 0x604D6F946530
0000762f89bd8d2e  call rax
0000762f89bd8d30  movaps xmm4, [rsp]
0000762f89bd8d34  add rsp, 0x30
0000762f89bd8d38  vmovaps xmm0, [rsp]
0000762f89bd8d3d  vmovaps xmm1, [rsp+0x10]
0000762f89bd8d43  vmovaps xmm2, [rsp+0x20]
0000762f89bd8d49  vmovaps xmm3, [rsp+0x30]
0000762f89bd8d4f  vmovaps xmm5, [rsp+0x40]
0000762f89bd8d55  vmovaps xmm6, [rsp+0x50]
0000762f89bd8d5b  vmovaps xmm7, [rsp+0x60]
0000762f89bd8d61  vmovaps xmm8, [rsp+0x70]
0000762f89bd8d67  vmovaps xmm9, [rsp+0x80]
0000762f89bd8d70  vmovaps xmm10, [rsp+0x90]
0000762f89bd8d79  vmovaps xmm11, [rsp+0xA0]
0000762f89bd8d82  vmovaps xmm12, [rsp+0xB0]
0000762f89bd8d8b  vmovaps xmm13, [rsp+0xC0]
0000762f89bd8d94  vmovaps xmm14, [rsp+0xD0]
0000762f89bd8d9d  vmovaps xmm15, [rsp+0xE0]
0000762f89bd8da6  add rsp, 0xF0
0000762f89bd8dad  pop r11
0000762f89bd8daf  pop r10
0000762f89bd8db1  pop r9
0000762f89bd8db3  pop r8
0000762f89bd8db5  pop rsi
0000762f89bd8db6  pop rdi
0000762f89bd8db7  pop rdx
0000762f89bd8db8  pop rcx
0000762f89bd8db9  pop rax
0000762f89bd8dba  add rsp, 0x08
0000762f89bd8dbe  jmp 0x0000762F89BD616B
0000762f89bd8dc3  sub rsp, 0x08
0000762f89bd8dc7  push rax
0000762f89bd8dc8  push rcx
0000762f89bd8dc9  push rdx
0000762f89bd8dca  push rdi
0000762f89bd8dcb  push rsi
0000762f89bd8dcc  push r8
0000762f89bd8dce  push r9
0000762f89bd8dd0  push r10
0000762f89bd8dd2  push r11
0000762f89bd8dd4  sub rsp, 0xF0
0000762f89bd8ddb  vmovaps [rsp], xmm0
0000762f89bd8de0  vmovaps [rsp+0x10], xmm1
0000762f89bd8de6  vmovaps [rsp+0x20], xmm2
0000762f89bd8dec  vmovaps [rsp+0x30], xmm3
0000762f89bd8df2  vmovaps [rsp+0x40], xmm4
0000762f89bd8df8  vmovaps [rsp+0x50], xmm5
0000762f89bd8dfe  vmovaps [rsp+0x60], xmm6
0000762f89bd8e04  vmovaps [rsp+0x70], xmm7
0000762f89bd8e0a  vmovaps [rsp+0x80], xmm8
0000762f89bd8e13  vmovaps [rsp+0x90], xmm10
0000762f89bd8e1c  vmovaps [rsp+0xA0], xmm11
0000762f89bd8e25  vmovaps [rsp+0xB0], xmm12
0000762f89bd8e2e  vmovaps [rsp+0xC0], xmm13
0000762f89bd8e37  vmovaps [rsp+0xD0], xmm14
0000762f89bd8e40  vmovaps [rsp+0xE0], xmm15
0000762f89bd8e49  sub rsp, 0x30
0000762f89bd8e4d  movaps [rsp], xmm9
0000762f89bd8e52  movaps [rsp+0x10], xmm2
0000762f89bd8e57  movaps [rsp+0x20], xmm1
0000762f89bd8e5c  lea rdi, [rsp]
0000762f89bd8e60  mov esi, 0x00
0000762f89bd8e65  mov rax, 0x604D6F946530
0000762f89bd8e6f  call rax
0000762f89bd8e71  movaps xmm9, [rsp]
0000762f89bd8e76  add rsp, 0x30
0000762f89bd8e7a  vmovaps xmm0, [rsp]
0000762f89bd8e7f  vmovaps xmm1, [rsp+0x10]
0000762f89bd8e85  vmovaps xmm2, [rsp+0x20]
0000762f89bd8e8b  vmovaps xmm3, [rsp+0x30]
0000762f89bd8e91  vmovaps xmm4, [rsp+0x40]
0000762f89bd8e97  vmovaps xmm5, [rsp+0x50]
0000762f89bd8e9d  vmovaps xmm6, [rsp+0x60]
0000762f89bd8ea3  vmovaps xmm7, [rsp+0x70]
0000762f89bd8ea9  vmovaps xmm8, [rsp+0x80]
0000762f89bd8eb2  vmovaps xmm10, [rsp+0x90]
0000762f89bd8ebb  vmovaps xmm11, [rsp+0xA0]
0000762f89bd8ec4  vmovaps xmm12, [rsp+0xB0]
0000762f89bd8ecd  vmovaps xmm13, [rsp+0xC0]
0000762f89bd8ed6  vmovaps xmm14, [rsp+0xD0]
0000762f89bd8edf  vmovaps xmm15, [rsp+0xE0]
0000762f89bd8ee8  add rsp, 0xF0
0000762f89bd8eef  pop r11
0000762f89bd8ef1  pop r10
0000762f89bd8ef3  pop r9
0000762f89bd8ef5  pop r8
0000762f89bd8ef7  pop rsi
0000762f89bd8ef8  pop rdi
0000762f89bd8ef9  pop rdx
0000762f89bd8efa  pop rcx
0000762f89bd8efb  pop rax
0000762f89bd8efc  add rsp, 0x08
0000762f89bd8f00  jmp 0x0000762F89BD61A1
0000762f89bd8f05  sub rsp, 0x08
0000762f89bd8f09  push rax
0000762f89bd8f0a  push rcx
0000762f89bd8f0b  push rdx
0000762f89bd8f0c  push rdi
0000762f89bd8f0d  push rsi
0000762f89bd8f0e  push r8
0000762f89bd8f10  push r9
0000762f89bd8f12  push r10
0000762f89bd8f14  push r11
0000762f89bd8f16  sub rsp, 0xF0
0000762f89bd8f1d  vmovaps [rsp], xmm0
0000762f89bd8f22  vmovaps [rsp+0x10], xmm2
0000762f89bd8f28  vmovaps [rsp+0x20], xmm3
0000762f89bd8f2e  vmovaps [rsp+0x30], xmm4
0000762f89bd8f34  vmovaps [rsp+0x40], xmm5
0000762f89bd8f3a  vmovaps [rsp+0x50], xmm6
0000762f89bd8f40  vmovaps [rsp+0x60], xmm7
0000762f89bd8f46  vmovaps [rsp+0x70], xmm8
0000762f89bd8f4c  vmovaps [rsp+0x80], xmm9
0000762f89bd8f55  vmovaps [rsp+0x90], xmm10
0000762f89bd8f5e  vmovaps [rsp+0xA0], xmm11
0000762f89bd8f67  vmovaps [rsp+0xB0], xmm12
0000762f89bd8f70  vmovaps [rsp+0xC0], xmm13
0000762f89bd8f79  vmovaps [rsp+0xD0], xmm14
0000762f89bd8f82  vmovaps [rsp+0xE0], xmm15
0000762f89bd8f8b  sub rsp, 0x30
0000762f89bd8f8f  movaps [rsp], xmm1
0000762f89bd8f93  movaps [rsp+0x10], xmm15
0000762f89bd8f99  movaps [rsp+0x20], xmm6
0000762f89bd8f9e  lea rdi, [rsp]
0000762f89bd8fa2  mov esi, 0x00
0000762f89bd8fa7  mov rax, 0x604D6F946530
0000762f89bd8fb1  call rax
0000762f89bd8fb3  movaps xmm1, [rsp]
0000762f89bd8fb7  add rsp, 0x30
0000762f89bd8fbb  vmovaps xmm0, [rsp]
0000762f89bd8fc0  vmovaps xmm2, [rsp+0x10]
0000762f89bd8fc6  vmovaps xmm3, [rsp+0x20]
0000762f89bd8fcc  vmovaps xmm4, [rsp+0x30]
0000762f89bd8fd2  vmovaps xmm5, [rsp+0x40]
0000762f89bd8fd8  vmovaps xmm6, [rsp+0x50]
0000762f89bd8fde  vmovaps xmm7, [rsp+0x60]
0000762f89bd8fe4  vmovaps xmm8, [rsp+0x70]
0000762f89bd8fea  vmovaps xmm9, [rsp+0x80]
0000762f89bd8ff3  vmovaps xmm10, [rsp+0x90]
0000762f89bd8ffc  vmovaps xmm11, [rsp+0xA0]
0000762f89bd9005  vmovaps xmm12, [rsp+0xB0]
0000762f89bd900e  vmovaps xmm13, [rsp+0xC0]
0000762f89bd9017  vmovaps xmm14, [rsp+0xD0]
0000762f89bd9020  vmovaps xmm15, [rsp+0xE0]
0000762f89bd9029  add rsp, 0xF0
0000762f89bd9030  pop r11
0000762f89bd9032  pop r10
0000762f89bd9034  pop r9
0000762f89bd9036  pop r8
0000762f89bd9038  pop rsi
0000762f89bd9039  pop rdi
0000762f89bd903a  pop rdx
0000762f89bd903b  pop rcx
0000762f89bd903c  pop rax
0000762f89bd903d  add rsp, 0x08
0000762f89bd9041  jmp 0x0000762F89BD61C2
0000762f89bd9046  sub rsp, 0x08
0000762f89bd904a  push rax
0000762f89bd904b  push rcx
0000762f89bd904c  push rdx
0000762f89bd904d  push rdi
0000762f89bd904e  push rsi
0000762f89bd904f  push r8
0000762f89bd9051  push r9
0000762f89bd9053  push r10
0000762f89bd9055  push r11
0000762f89bd9057  sub rsp, 0xF0
0000762f89bd905e  vmovaps [rsp], xmm0
0000762f89bd9063  vmovaps [rsp+0x10], xmm1
0000762f89bd9069  vmovaps [rsp+0x20], xmm2
0000762f89bd906f  vmovaps [rsp+0x30], xmm3
0000762f89bd9075  vmovaps [rsp+0x40], xmm4
0000762f89bd907b  vmovaps [rsp+0x50], xmm5
0000762f89bd9081  vmovaps [rsp+0x60], xmm6
0000762f89bd9087  vmovaps [rsp+0x70], xmm7
0000762f89bd908d  vmovaps [rsp+0x80], xmm8
0000762f89bd9096  vmovaps [rsp+0x90], xmm9
0000762f89bd909f  vmovaps [rsp+0xA0], xmm10
0000762f89bd90a8  vmovaps [rsp+0xB0], xmm11
0000762f89bd90b1  vmovaps [rsp+0xC0], xmm12
0000762f89bd90ba  vmovaps [rsp+0xD0], xmm13
0000762f89bd90c3  vmovaps [rsp+0xE0], xmm14
0000762f89bd90cc  sub rsp, 0x30
0000762f89bd90d0  movaps [rsp], xmm15
0000762f89bd90d5  movaps [rsp+0x10], xmm5
0000762f89bd90da  movaps [rsp+0x20], xmm3
0000762f89bd90df  lea rdi, [rsp]
0000762f89bd90e3  mov esi, 0x00
0000762f89bd90e8  mov rax, 0x604D6F946530
0000762f89bd90f2  call rax
0000762f89bd90f4  movaps xmm15, [rsp]
0000762f89bd90f9  add rsp, 0x30
0000762f89bd90fd  vmovaps xmm0, [rsp]
0000762f89bd9102  vmovaps xmm1, [rsp+0x10]
0000762f89bd9108  vmovaps xmm2, [rsp+0x20]
0000762f89bd910e  vmovaps xmm3, [rsp+0x30]
0000762f89bd9114  vmovaps xmm4, [rsp+0x40]
0000762f89bd911a  vmovaps xmm5, [rsp+0x50]
0000762f89bd9120  vmovaps xmm6, [rsp+0x60]
0000762f89bd9126  vmovaps xmm7, [rsp+0x70]
0000762f89bd912c  vmovaps xmm8, [rsp+0x80]
0000762f89bd9135  vmovaps xmm9, [rsp+0x90]
0000762f89bd913e  vmovaps xmm10, [rsp+0xA0]
0000762f89bd9147  vmovaps xmm11, [rsp+0xB0]
0000762f89bd9150  vmovaps xmm12, [rsp+0xC0]
0000762f89bd9159  vmovaps xmm13, [rsp+0xD0]
0000762f89bd9162  vmovaps xmm14, [rsp+0xE0]
0000762f89bd916b  add rsp, 0xF0
0000762f89bd9172  pop r11
0000762f89bd9174  pop r10
0000762f89bd9176  pop r9
0000762f89bd9178  pop r8
0000762f89bd917a  pop rsi
0000762f89bd917b  pop rdi
0000762f89bd917c  pop rdx
0000762f89bd917d  pop rcx
0000762f89bd917e  pop rax
0000762f89bd917f  add rsp, 0x08
0000762f89bd9183  jmp 0x0000762F89BD61DC
0000762f89bd9188  sub rsp, 0x08
0000762f89bd918c  push rax
0000762f89bd918d  push rcx
0000762f89bd918e  push rdx
0000762f89bd918f  push rdi
0000762f89bd9190  push rsi
0000762f89bd9191  push r8
0000762f89bd9193  push r9
0000762f89bd9195  push r10
0000762f89bd9197  push r11
0000762f89bd9199  sub rsp, 0xF0
0000762f89bd91a0  vmovaps [rsp], xmm0
0000762f89bd91a5  vmovaps [rsp+0x10], xmm1
0000762f89bd91ab  vmovaps [rsp+0x20], xmm2
0000762f89bd91b1  vmovaps [rsp+0x30], xmm3
0000762f89bd91b7  vmovaps [rsp+0x40], xmm4
0000762f89bd91bd  vmovaps [rsp+0x50], xmm6
0000762f89bd91c3  vmovaps [rsp+0x60], xmm7
0000762f89bd91c9  vmovaps [rsp+0x70], xmm8
0000762f89bd91cf  vmovaps [rsp+0x80], xmm9
0000762f89bd91d8  vmovaps [rsp+0x90], xmm10
0000762f89bd91e1  vmovaps [rsp+0xA0], xmm11
0000762f89bd91ea  vmovaps [rsp+0xB0], xmm12
0000762f89bd91f3  vmovaps [rsp+0xC0], xmm13
0000762f89bd91fc  vmovaps [rsp+0xD0], xmm14
0000762f89bd9205  vmovaps [rsp+0xE0], xmm15
0000762f89bd920e  sub rsp, 0x30
0000762f89bd9212  movaps [rsp], xmm5
0000762f89bd9216  movaps [rsp+0x10], xmm8
0000762f89bd921c  movaps [rsp+0x20], xmm6
0000762f89bd9221  lea rdi, [rsp]
0000762f89bd9225  mov esi, 0x00
0000762f89bd922a  mov rax, 0x604D6F946530
0000762f89bd9234  call rax
0000762f89bd9236  movaps xmm5, [rsp]
0000762f89bd923a  add rsp, 0x30
0000762f89bd923e  vmovaps xmm0, [rsp]
0000762f89bd9243  vmovaps xmm1, [rsp+0x10]
0000762f89bd9249  vmovaps xmm2, [rsp+0x20]
0000762f89bd924f  vmovaps xmm3, [rsp+0x30]
0000762f89bd9255  vmovaps xmm4, [rsp+0x40]
0000762f89bd925b  vmovaps xmm6, [rsp+0x50]
0000762f89bd9261  vmovaps xmm7, [rsp+0x60]
0000762f89bd9267  vmovaps xmm8, [rsp+0x70]
0000762f89bd926d  vmovaps xmm9, [rsp+0x80]
0000762f89bd9276  vmovaps xmm10, [rsp+0x90]
0000762f89bd927f  vmovaps xmm11, [rsp+0xA0]
0000762f89bd9288  vmovaps xmm12, [rsp+0xB0]
0000762f89bd9291  vmovaps xmm13, [rsp+0xC0]
0000762f89bd929a  vmovaps xmm14, [rsp+0xD0]
0000762f89bd92a3  vmovaps xmm15, [rsp+0xE0]
0000762f89bd92ac  add rsp, 0xF0
0000762f89bd92b3  pop r11
0000762f89bd92b5  pop r10
0000762f89bd92b7  pop r9
0000762f89bd92b9  pop r8
0000762f89bd92bb  pop rsi
0000762f89bd92bc  pop rdi
0000762f89bd92bd  pop rdx
0000762f89bd92be  pop rcx
0000762f89bd92bf  pop rax
0000762f89bd92c0  add rsp, 0x08
0000762f89bd92c4  jmp 0x0000762F89BD6200
0000762f89bd92c9  sub rsp, 0x08
0000762f89bd92cd  push rax
0000762f89bd92ce  push rcx
0000762f89bd92cf  push rdx
0000762f89bd92d0  push rdi
0000762f89bd92d1  push rsi
0000762f89bd92d2  push r8
0000762f89bd92d4  push r9
0000762f89bd92d6  push r10
0000762f89bd92d8  push r11
0000762f89bd92da  sub rsp, 0xF0
0000762f89bd92e1  vmovaps [rsp], xmm0
0000762f89bd92e6  vmovaps [rsp+0x10], xmm1
0000762f89bd92ec  vmovaps [rsp+0x20], xmm2
0000762f89bd92f2  vmovaps [rsp+0x30], xmm3
0000762f89bd92f8  vmovaps [rsp+0x40], xmm4
0000762f89bd92fe  vmovaps [rsp+0x50], xmm5
0000762f89bd9304  vmovaps [rsp+0x60], xmm7
0000762f89bd930a  vmovaps [rsp+0x70], xmm8
0000762f89bd9310  vmovaps [rsp+0x80], xmm9
0000762f89bd9319  vmovaps [rsp+0x90], xmm10
0000762f89bd9322  vmovaps [rsp+0xA0], xmm11
0000762f89bd932b  vmovaps [rsp+0xB0], xmm12
0000762f89bd9334  vmovaps [rsp+0xC0], xmm13
0000762f89bd933d  vmovaps [rsp+0xD0], xmm14
0000762f89bd9346  vmovaps [rsp+0xE0], xmm15
0000762f89bd934f  sub rsp, 0x30
0000762f89bd9353  movaps [rsp], xmm6
0000762f89bd9357  movaps [rsp+0x10], xmm10
0000762f89bd935d  movaps [rsp+0x20], xmm8
0000762f89bd9363  lea rdi, [rsp]
0000762f89bd9367  mov esi, 0x00
0000762f89bd936c  mov rax, 0x604D6F946530
0000762f89bd9376  call rax
0000762f89bd9378  movaps xmm6, [rsp]
0000762f89bd937c  add rsp, 0x30
0000762f89bd9380  vmovaps xmm0, [rsp]
0000762f89bd9385  vmovaps xmm1, [rsp+0x10]
0000762f89bd938b  vmovaps xmm2, [rsp+0x20]
0000762f89bd9391  vmovaps xmm3, [rsp+0x30]
0000762f89bd9397  vmovaps xmm4, [rsp+0x40]
0000762f89bd939d  vmovaps xmm5, [rsp+0x50]
0000762f89bd93a3  vmovaps xmm7, [rsp+0x60]
0000762f89bd93a9  vmovaps xmm8, [rsp+0x70]
0000762f89bd93af  vmovaps xmm9, [rsp+0x80]
0000762f89bd93b8  vmovaps xmm10, [rsp+0x90]
0000762f89bd93c1  vmovaps xmm11, [rsp+0xA0]
0000762f89bd93ca  vmovaps xmm12, [rsp+0xB0]
0000762f89bd93d3  vmovaps xmm13, [rsp+0xC0]
0000762f89bd93dc  vmovaps xmm14, [rsp+0xD0]
0000762f89bd93e5  vmovaps xmm15, [rsp+0xE0]
0000762f89bd93ee  add rsp, 0xF0
0000762f89bd93f5  pop r11
0000762f89bd93f7  pop r10
0000762f89bd93f9  pop r9
0000762f89bd93fb  pop r8
0000762f89bd93fd  pop rsi
0000762f89bd93fe  pop rdi
0000762f89bd93ff  pop rdx
0000762f89bd9400  pop rcx
0000762f89bd9401  pop rax
0000762f89bd9402  add rsp, 0x08
0000762f89bd9406  jmp 0x0000762F89BD6225
0000762f89bd940b  sub rsp, 0x08
0000762f89bd940f  push rax
0000762f89bd9410  push rcx
0000762f89bd9411  push rdx
0000762f89bd9412  push rdi
0000762f89bd9413  push rsi
0000762f89bd9414  push r8
0000762f89bd9416  push r9
0000762f89bd9418  push r10
0000762f89bd941a  push r11
0000762f89bd941c  sub rsp, 0xF0
0000762f89bd9423  vmovaps [rsp], xmm0
0000762f89bd9428  vmovaps [rsp+0x10], xmm1
0000762f89bd942e  vmovaps [rsp+0x20], xmm2
0000762f89bd9434  vmovaps [rsp+0x30], xmm3
0000762f89bd943a  vmovaps [rsp+0x40], xmm4
0000762f89bd9440  vmovaps [rsp+0x50], xmm5
0000762f89bd9446  vmovaps [rsp+0x60], xmm6
0000762f89bd944c  vmovaps [rsp+0x70], xmm7
0000762f89bd9452  vmovaps [rsp+0x80], xmm8
0000762f89bd945b  vmovaps [rsp+0x90], xmm9
0000762f89bd9464  vmovaps [rsp+0xA0], xmm11
0000762f89bd946d  vmovaps [rsp+0xB0], xmm12
0000762f89bd9476  vmovaps [rsp+0xC0], xmm13
0000762f89bd947f  vmovaps [rsp+0xD0], xmm14
0000762f89bd9488  vmovaps [rsp+0xE0], xmm15
0000762f89bd9491  sub rsp, 0x30
0000762f89bd9495  movaps [rsp], xmm10
0000762f89bd949a  movaps [rsp+0x10], xmm8
0000762f89bd94a0  movaps [rsp+0x20], xmm14
0000762f89bd94a6  lea rdi, [rsp]
0000762f89bd94aa  mov esi, 0x00
0000762f89bd94af  mov rax, 0x604D6F946530
0000762f89bd94b9  call rax
0000762f89bd94bb  movaps xmm10, [rsp]
0000762f89bd94c0  add rsp, 0x30
0000762f89bd94c4  vmovaps xmm0, [rsp]
0000762f89bd94c9  vmovaps xmm1, [rsp+0x10]
0000762f89bd94cf  vmovaps xmm2, [rsp+0x20]
0000762f89bd94d5  vmovaps xmm3, [rsp+0x30]
0000762f89bd94db  vmovaps xmm4, [rsp+0x40]
0000762f89bd94e1  vmovaps xmm5, [rsp+0x50]
0000762f89bd94e7  vmovaps xmm6, [rsp+0x60]
0000762f89bd94ed  vmovaps xmm7, [rsp+0x70]
0000762f89bd94f3  vmovaps xmm8, [rsp+0x80]
0000762f89bd94fc  vmovaps xmm9, [rsp+0x90]
0000762f89bd9505  vmovaps xmm11, [rsp+0xA0]
0000762f89bd950e  vmovaps xmm12, [rsp+0xB0]
0000762f89bd9517  vmovaps xmm13, [rsp+0xC0]
0000762f89bd9520  vmovaps xmm14, [rsp+0xD0]
0000762f89bd9529  vmovaps xmm15, [rsp+0xE0]
0000762f89bd9532  add rsp, 0xF0
0000762f89bd9539  pop r11
0000762f89bd953b  pop r10
0000762f89bd953d  pop r9
0000762f89bd953f  pop r8
0000762f89bd9541  pop rsi
0000762f89bd9542  pop rdi
0000762f89bd9543  pop rdx
0000762f89bd9544  pop rcx
0000762f89bd9545  pop rax
0000762f89bd9546  add rsp, 0x08
0000762f89bd954a  jmp 0x0000762F89BD6245
0000762f89bd954f  sub rsp, 0x08
0000762f89bd9553  push rax
0000762f89bd9554  push rcx
0000762f89bd9555  push rdx
0000762f89bd9556  push rdi
0000762f89bd9557  push rsi
0000762f89bd9558  push r8
0000762f89bd955a  push r9
0000762f89bd955c  push r10
0000762f89bd955e  push r11
0000762f89bd9560  sub rsp, 0xF0
0000762f89bd9567  vmovaps [rsp], xmm0
0000762f89bd956c  vmovaps [rsp+0x10], xmm1
0000762f89bd9572  vmovaps [rsp+0x20], xmm2
0000762f89bd9578  vmovaps [rsp+0x30], xmm3
0000762f89bd957e  vmovaps [rsp+0x40], xmm4
0000762f89bd9584  vmovaps [rsp+0x50], xmm5
0000762f89bd958a  vmovaps [rsp+0x60], xmm6
0000762f89bd9590  vmovaps [rsp+0x70], xmm7
0000762f89bd9596  vmovaps [rsp+0x80], xmm8
0000762f89bd959f  vmovaps [rsp+0x90], xmm9
0000762f89bd95a8  vmovaps [rsp+0xA0], xmm10
0000762f89bd95b1  vmovaps [rsp+0xB0], xmm11
0000762f89bd95ba  vmovaps [rsp+0xC0], xmm12
0000762f89bd95c3  vmovaps [rsp+0xD0], xmm13
0000762f89bd95cc  vmovaps [rsp+0xE0], xmm15
0000762f89bd95d5  sub rsp, 0x30
0000762f89bd95d9  movaps [rsp], xmm14
0000762f89bd95de  movaps [rsp+0x10], xmm8
0000762f89bd95e4  movaps [rsp+0x20], xmm4
0000762f89bd95e9  lea rdi, [rsp]
0000762f89bd95ed  mov esi, 0x00
0000762f89bd95f2  mov rax, 0x604D6F946530
0000762f89bd95fc  call rax
0000762f89bd95fe  movaps xmm14, [rsp]
0000762f89bd9603  add rsp, 0x30
0000762f89bd9607  vmovaps xmm0, [rsp]
0000762f89bd960c  vmovaps xmm1, [rsp+0x10]
0000762f89bd9612  vmovaps xmm2, [rsp+0x20]
0000762f89bd9618  vmovaps xmm3, [rsp+0x30]
0000762f89bd961e  vmovaps xmm4, [rsp+0x40]
0000762f89bd9624  vmovaps xmm5, [rsp+0x50]
0000762f89bd962a  vmovaps xmm6, [rsp+0x60]
0000762f89bd9630  vmovaps xmm7, [rsp+0x70]
0000762f89bd9636  vmovaps xmm8, [rsp+0x80]
0000762f89bd963f  vmovaps xmm9, [rsp+0x90]
0000762f89bd9648  vmovaps xmm10, [rsp+0xA0]
0000762f89bd9651  vmovaps xmm11, [rsp+0xB0]
0000762f89bd965a  vmovaps xmm12, [rsp+0xC0]
0000762f89bd9663  vmovaps xmm13, [rsp+0xD0]
0000762f89bd966c  vmovaps xmm15, [rsp+0xE0]
0000762f89bd9675  add rsp, 0xF0
0000762f89bd967c  pop r11
0000762f89bd967e  pop r10
0000762f89bd9680  pop r9
0000762f89bd9682  pop r8
0000762f89bd9684  pop rsi
0000762f89bd9685  pop rdi
0000762f89bd9686  pop rdx
0000762f89bd9687  pop rcx
0000762f89bd9688  pop rax
0000762f89bd9689  add rsp, 0x08
0000762f89bd968d  jmp 0x0000762F89BD6265
0000762f89bd9692  sub rsp, 0x08
0000762f89bd9696  push rax
0000762f89bd9697  push rcx
0000762f89bd9698  push rdx
0000762f89bd9699  push rdi
0000762f89bd969a  push rsi
0000762f89bd969b  push r8
0000762f89bd969d  push r9
0000762f89bd969f  push r10
0000762f89bd96a1  push r11
0000762f89bd96a3  sub rsp, 0xF0
0000762f89bd96aa  vmovaps [rsp], xmm0
0000762f89bd96af  vmovaps [rsp+0x10], xmm1
0000762f89bd96b5  vmovaps [rsp+0x20], xmm2
0000762f89bd96bb  vmovaps [rsp+0x30], xmm3
0000762f89bd96c1  vmovaps [rsp+0x40], xmm5
0000762f89bd96c7  vmovaps [rsp+0x50], xmm6
0000762f89bd96cd  vmovaps [rsp+0x60], xmm7
0000762f89bd96d3  vmovaps [rsp+0x70], xmm8
0000762f89bd96d9  vmovaps [rsp+0x80], xmm9
0000762f89bd96e2  vmovaps [rsp+0x90], xmm10
0000762f89bd96eb  vmovaps [rsp+0xA0], xmm11
0000762f89bd96f4  vmovaps [rsp+0xB0], xmm12
0000762f89bd96fd  vmovaps [rsp+0xC0], xmm13
0000762f89bd9706  vmovaps [rsp+0xD0], xmm14
0000762f89bd970f  vmovaps [rsp+0xE0], xmm15
0000762f89bd9718  sub rsp, 0x30
0000762f89bd971c  movaps [rsp], xmm4
0000762f89bd9720  movaps [rsp+0x10], xmm13
0000762f89bd9726  movaps [rsp+0x20], xmm8
0000762f89bd972c  lea rdi, [rsp]
0000762f89bd9730  mov esi, 0x00
0000762f89bd9735  mov rax, 0x604D6F946530
0000762f89bd973f  call rax
0000762f89bd9741  movaps xmm4, [rsp]
0000762f89bd9745  add rsp, 0x30
0000762f89bd9749  vmovaps xmm0, [rsp]
0000762f89bd974e  vmovaps xmm1, [rsp+0x10]
0000762f89bd9754  vmovaps xmm2, [rsp+0x20]
0000762f89bd975a  vmovaps xmm3, [rsp+0x30]
0000762f89bd9760  vmovaps xmm5, [rsp+0x40]
0000762f89bd9766  vmovaps xmm6, [rsp+0x50]
0000762f89bd976c  vmovaps xmm7, [rsp+0x60]
0000762f89bd9772  vmovaps xmm8, [rsp+0x70]
0000762f89bd9778  vmovaps xmm9, [rsp+0x80]
0000762f89bd9781  vmovaps xmm10, [rsp+0x90]
0000762f89bd978a  vmovaps xmm11, [rsp+0xA0]
0000762f89bd9793  vmovaps xmm12, [rsp+0xB0]
0000762f89bd979c  vmovaps xmm13, [rsp+0xC0]
0000762f89bd97a5  vmovaps xmm14, [rsp+0xD0]
0000762f89bd97ae  vmovaps xmm15, [rsp+0xE0]
0000762f89bd97b7  add rsp, 0xF0
0000762f89bd97be  pop r11
0000762f89bd97c0  pop r10
0000762f89bd97c2  pop r9
0000762f89bd97c4  pop r8
0000762f89bd97c6  pop rsi
0000762f89bd97c7  pop rdi
0000762f89bd97c8  pop rdx
0000762f89bd97c9  pop rcx
0000762f89bd97ca  pop rax
0000762f89bd97cb  add rsp, 0x08
0000762f89bd97cf  jmp 0x0000762F89BD628A
0000762f89bd97d4  sub rsp, 0x08
0000762f89bd97d8  push rax
0000762f89bd97d9  push rcx
0000762f89bd97da  push rdx
0000762f89bd97db  push rdi
0000762f89bd97dc  push rsi
0000762f89bd97dd  push r8
0000762f89bd97df  push r9
0000762f89bd97e1  push r10
0000762f89bd97e3  push r11
0000762f89bd97e5  sub rsp, 0xF0
0000762f89bd97ec  vmovaps [rsp], xmm0
0000762f89bd97f1  vmovaps [rsp+0x10], xmm1
0000762f89bd97f7  vmovaps [rsp+0x20], xmm2
0000762f89bd97fd  vmovaps [rsp+0x30], xmm3
0000762f89bd9803  vmovaps [rsp+0x40], xmm4
0000762f89bd9809  vmovaps [rsp+0x50], xmm5
0000762f89bd980f  vmovaps [rsp+0x60], xmm6
0000762f89bd9815  vmovaps [rsp+0x70], xmm7
0000762f89bd981b  vmovaps [rsp+0x80], xmm8
0000762f89bd9824  vmovaps [rsp+0x90], xmm9
0000762f89bd982d  vmovaps [rsp+0xA0], xmm10
0000762f89bd9836  vmovaps [rsp+0xB0], xmm11
0000762f89bd983f  vmovaps [rsp+0xC0], xmm12
0000762f89bd9848  vmovaps [rsp+0xD0], xmm14
0000762f89bd9851  vmovaps [rsp+0xE0], xmm15
0000762f89bd985a  sub rsp, 0x30
0000762f89bd985e  movaps [rsp], xmm13
0000762f89bd9863  movaps [rsp+0x10], xmm15
0000762f89bd9869  movaps [rsp+0x20], xmm9
0000762f89bd986f  lea rdi, [rsp]
0000762f89bd9873  mov esi, 0x00
0000762f89bd9878  mov rax, 0x604D6F946530
0000762f89bd9882  call rax
0000762f89bd9884  movaps xmm13, [rsp]
0000762f89bd9889  add rsp, 0x30
0000762f89bd988d  vmovaps xmm0, [rsp]
0000762f89bd9892  vmovaps xmm1, [rsp+0x10]
0000762f89bd9898  vmovaps xmm2, [rsp+0x20]
0000762f89bd989e  vmovaps xmm3, [rsp+0x30]
0000762f89bd98a4  vmovaps xmm4, [rsp+0x40]
0000762f89bd98aa  vmovaps xmm5, [rsp+0x50]
0000762f89bd98b0  vmovaps xmm6, [rsp+0x60]
0000762f89bd98b6  vmovaps xmm7, [rsp+0x70]
0000762f89bd98bc  vmovaps xmm8, [rsp+0x80]
0000762f89bd98c5  vmovaps xmm9, [rsp+0x90]
0000762f89bd98ce  vmovaps xmm10, [rsp+0xA0]
0000762f89bd98d7  vmovaps xmm11, [rsp+0xB0]
0000762f89bd98e0  vmovaps xmm12, [rsp+0xC0]
0000762f89bd98e9  vmovaps xmm14, [rsp+0xD0]
0000762f89bd98f2  vmovaps xmm15, [rsp+0xE0]
0000762f89bd98fb  add rsp, 0xF0
0000762f89bd9902  pop r11
0000762f89bd9904  pop r10
0000762f89bd9906  pop r9
0000762f89bd9908  pop r8
0000762f89bd990a  pop rsi
0000762f89bd990b  pop rdi
0000762f89bd990c  pop rdx
0000762f89bd990d  pop rcx
0000762f89bd990e  pop rax
0000762f89bd990f  add rsp, 0x08
0000762f89bd9913  jmp 0x0000762F89BD62A5
0000762f89bd9918  sub rsp, 0x08
0000762f89bd991c  push rax
0000762f89bd991d  push rcx
0000762f89bd991e  push rdx
0000762f89bd991f  push rdi
0000762f89bd9920  push rsi
0000762f89bd9921  push r8
0000762f89bd9923  push r9
0000762f89bd9925  push r10
0000762f89bd9927  push r11
0000762f89bd9929  sub rsp, 0xF0
0000762f89bd9930  vmovaps [rsp], xmm0
0000762f89bd9935  vmovaps [rsp+0x10], xmm1
0000762f89bd993b  vmovaps [rsp+0x20], xmm2
0000762f89bd9941  vmovaps [rsp+0x30], xmm3
0000762f89bd9947  vmovaps [rsp+0x40], xmm4
0000762f89bd994d  vmovaps [rsp+0x50], xmm5
0000762f89bd9953  vmovaps [rsp+0x60], xmm6
0000762f89bd9959  vmovaps [rsp+0x70], xmm7
0000762f89bd995f  vmovaps [rsp+0x80], xmm8
0000762f89bd9968  vmovaps [rsp+0x90], xmm9
0000762f89bd9971  vmovaps [rsp+0xA0], xmm10
0000762f89bd997a  vmovaps [rsp+0xB0], xmm11
0000762f89bd9983  vmovaps [rsp+0xC0], xmm12
0000762f89bd998c  vmovaps [rsp+0xD0], xmm13
0000762f89bd9995  vmovaps [rsp+0xE0], xmm14
0000762f89bd999e  sub rsp, 0x30
0000762f89bd99a2  movaps [rsp], xmm15
0000762f89bd99a7  movaps [rsp+0x10], xmm1
0000762f89bd99ac  movaps [rsp+0x20], xmm5
0000762f89bd99b1  lea rdi, [rsp]
0000762f89bd99b5  mov esi, 0x00
0000762f89bd99ba  mov rax, 0x604D6F946530
0000762f89bd99c4  call rax
0000762f89bd99c6  movaps xmm15, [rsp]
0000762f89bd99cb  add rsp, 0x30
0000762f89bd99cf  vmovaps xmm0, [rsp]
0000762f89bd99d4  vmovaps xmm1, [rsp+0x10]
0000762f89bd99da  vmovaps xmm2, [rsp+0x20]
0000762f89bd99e0  vmovaps xmm3, [rsp+0x30]
0000762f89bd99e6  vmovaps xmm4, [rsp+0x40]
0000762f89bd99ec  vmovaps xmm5, [rsp+0x50]
0000762f89bd99f2  vmovaps xmm6, [rsp+0x60]
0000762f89bd99f8  vmovaps xmm7, [rsp+0x70]
0000762f89bd99fe  vmovaps xmm8, [rsp+0x80]
0000762f89bd9a07  vmovaps xmm9, [rsp+0x90]
0000762f89bd9a10  vmovaps xmm10, [rsp+0xA0]
0000762f89bd9a19  vmovaps xmm11, [rsp+0xB0]
0000762f89bd9a22  vmovaps xmm12, [rsp+0xC0]
0000762f89bd9a2b  vmovaps xmm13, [rsp+0xD0]
0000762f89bd9a34  vmovaps xmm14, [rsp+0xE0]
0000762f89bd9a3d  add rsp, 0xF0
0000762f89bd9a44  pop r11
0000762f89bd9a46  pop r10
0000762f89bd9a48  pop r9
0000762f89bd9a4a  pop r8
0000762f89bd9a4c  pop rsi
0000762f89bd9a4d  pop rdi
0000762f89bd9a4e  pop rdx
0000762f89bd9a4f  pop rcx
0000762f89bd9a50  pop rax
0000762f89bd9a51  add rsp, 0x08
0000762f89bd9a55  jmp 0x0000762F89BD62C0
0000762f89bd9a5a  call 0x0000762F89AD64F0
0000762f89bd9a5f  jmp 0x0000762F89BD631B
0000762f89bd9a64  sub rsp, 0x08
0000762f89bd9a68  push rax
0000762f89bd9a69  push rcx
0000762f89bd9a6a  push rdx
0000762f89bd9a6b  push rdi
0000762f89bd9a6c  push rsi
0000762f89bd9a6d  push r8
0000762f89bd9a6f  push r9
0000762f89bd9a71  push r10
0000762f89bd9a73  push r11
0000762f89bd9a75  sub rsp, 0xF0
0000762f89bd9a7c  vmovaps [rsp], xmm0
0000762f89bd9a81  vmovaps [rsp+0x10], xmm1
0000762f89bd9a87  vmovaps [rsp+0x20], xmm2
0000762f89bd9a8d  vmovaps [rsp+0x30], xmm3
0000762f89bd9a93  vmovaps [rsp+0x40], xmm4
0000762f89bd9a99  vmovaps [rsp+0x50], xmm5
0000762f89bd9a9f  vmovaps [rsp+0x60], xmm6
0000762f89bd9aa5  vmovaps [rsp+0x70], xmm7
0000762f89bd9aab  vmovaps [rsp+0x80], xmm8
0000762f89bd9ab4  vmovaps [rsp+0x90], xmm10
0000762f89bd9abd  vmovaps [rsp+0xA0], xmm11
0000762f89bd9ac6  vmovaps [rsp+0xB0], xmm12
0000762f89bd9acf  vmovaps [rsp+0xC0], xmm13
0000762f89bd9ad8  vmovaps [rsp+0xD0], xmm14
0000762f89bd9ae1  vmovaps [rsp+0xE0], xmm15
0000762f89bd9aea  sub rsp, 0x30
0000762f89bd9aee  movaps [rsp], xmm9
0000762f89bd9af3  movaps [rsp+0x10], xmm8
0000762f89bd9af9  movaps [rsp+0x20], xmm11
0000762f89bd9aff  lea rdi, [rsp]
0000762f89bd9b03  mov esi, 0x00
0000762f89bd9b08  mov rax, 0x604D6F946530
0000762f89bd9b12  call rax
0000762f89bd9b14  movaps xmm9, [rsp]
0000762f89bd9b19  add rsp, 0x30
0000762f89bd9b1d  vmovaps xmm0, [rsp]
0000762f89bd9b22  vmovaps xmm1, [rsp+0x10]
0000762f89bd9b28  vmovaps xmm2, [rsp+0x20]
0000762f89bd9b2e  vmovaps xmm3, [rsp+0x30]
0000762f89bd9b34  vmovaps xmm4, [rsp+0x40]
0000762f89bd9b3a  vmovaps xmm5, [rsp+0x50]
0000762f89bd9b40  vmovaps xmm6, [rsp+0x60]
0000762f89bd9b46  vmovaps xmm7, [rsp+0x70]
0000762f89bd9b4c  vmovaps xmm8, [rsp+0x80]
0000762f89bd9b55  vmovaps xmm10, [rsp+0x90]
0000762f89bd9b5e  vmovaps xmm11, [rsp+0xA0]
0000762f89bd9b67  vmovaps xmm12, [rsp+0xB0]
0000762f89bd9b70  vmovaps xmm13, [rsp+0xC0]
0000762f89bd9b79  vmovaps xmm14, [rsp+0xD0]
0000762f89bd9b82  vmovaps xmm15, [rsp+0xE0]
0000762f89bd9b8b  add rsp, 0xF0
0000762f89bd9b92  pop r11
0000762f89bd9b94  pop r10
0000762f89bd9b96  pop r9
0000762f89bd9b98  pop r8
0000762f89bd9b9a  pop rsi
0000762f89bd9b9b  pop rdi
0000762f89bd9b9c  pop rdx
0000762f89bd9b9d  pop rcx
0000762f89bd9b9e  pop rax
0000762f89bd9b9f  add rsp, 0x08
0000762f89bd9ba3  jmp 0x0000762F89BD6352
0000762f89bd9ba8  sub rsp, 0x08
0000762f89bd9bac  push rax
0000762f89bd9bad  push rcx
0000762f89bd9bae  push rdx
0000762f89bd9baf  push rdi
0000762f89bd9bb0  push rsi
0000762f89bd9bb1  push r8
0000762f89bd9bb3  push r9
0000762f89bd9bb5  push r10
0000762f89bd9bb7  push r11
0000762f89bd9bb9  sub rsp, 0xF0
0000762f89bd9bc0  vmovaps [rsp], xmm0
0000762f89bd9bc5  vmovaps [rsp+0x10], xmm1
0000762f89bd9bcb  vmovaps [rsp+0x20], xmm2
0000762f89bd9bd1  vmovaps [rsp+0x30], xmm3
0000762f89bd9bd7  vmovaps [rsp+0x40], xmm4
0000762f89bd9bdd  vmovaps [rsp+0x50], xmm5
0000762f89bd9be3  vmovaps [rsp+0x60], xmm6
0000762f89bd9be9  vmovaps [rsp+0x70], xmm7
0000762f89bd9bef  vmovaps [rsp+0x80], xmm8
0000762f89bd9bf8  vmovaps [rsp+0x90], xmm9
0000762f89bd9c01  vmovaps [rsp+0xA0], xmm10
0000762f89bd9c0a  vmovaps [rsp+0xB0], xmm12
0000762f89bd9c13  vmovaps [rsp+0xC0], xmm13
0000762f89bd9c1c  vmovaps [rsp+0xD0], xmm14
0000762f89bd9c25  vmovaps [rsp+0xE0], xmm15
0000762f89bd9c2e  sub rsp, 0x30
0000762f89bd9c32  movaps [rsp], xmm11
0000762f89bd9c37  movaps [rsp+0x10], xmm10
0000762f89bd9c3d  movaps [rsp+0x20], xmm6
0000762f89bd9c42  lea rdi, [rsp]
0000762f89bd9c46  mov esi, 0x00
0000762f89bd9c4b  mov rax, 0x604D6F946530
0000762f89bd9c55  call rax
0000762f89bd9c57  movaps xmm11, [rsp]
0000762f89bd9c5c  add rsp, 0x30
0000762f89bd9c60  vmovaps xmm0, [rsp]
0000762f89bd9c65  vmovaps xmm1, [rsp+0x10]
0000762f89bd9c6b  vmovaps xmm2, [rsp+0x20]
0000762f89bd9c71  vmovaps xmm3, [rsp+0x30]
0000762f89bd9c77  vmovaps xmm4, [rsp+0x40]
0000762f89bd9c7d  vmovaps xmm5, [rsp+0x50]
0000762f89bd9c83  vmovaps xmm6, [rsp+0x60]
0000762f89bd9c89  vmovaps xmm7, [rsp+0x70]
0000762f89bd9c8f  vmovaps xmm8, [rsp+0x80]
0000762f89bd9c98  vmovaps xmm9, [rsp+0x90]
0000762f89bd9ca1  vmovaps xmm10, [rsp+0xA0]
0000762f89bd9caa  vmovaps xmm12, [rsp+0xB0]
0000762f89bd9cb3  vmovaps xmm13, [rsp+0xC0]
0000762f89bd9cbc  vmovaps xmm14, [rsp+0xD0]
0000762f89bd9cc5  vmovaps xmm15, [rsp+0xE0]
0000762f89bd9cce  add rsp, 0xF0
0000762f89bd9cd5  pop r11
0000762f89bd9cd7  pop r10
0000762f89bd9cd9  pop r9
0000762f89bd9cdb  pop r8
0000762f89bd9cdd  pop rsi
0000762f89bd9cde  pop rdi
0000762f89bd9cdf  pop rdx
0000762f89bd9ce0  pop rcx
0000762f89bd9ce1  pop rax
0000762f89bd9ce2  add rsp, 0x08
0000762f89bd9ce6  jmp 0x0000762F89BD636D
0000762f89bd9ceb  sub rsp, 0x08
0000762f89bd9cef  push rax
0000762f89bd9cf0  push rcx
0000762f89bd9cf1  push rdx
0000762f89bd9cf2  push rdi
0000762f89bd9cf3  push rsi
0000762f89bd9cf4  push r8
0000762f89bd9cf6  push r9
0000762f89bd9cf8  push r10
0000762f89bd9cfa  push r11
0000762f89bd9cfc  sub rsp, 0xF0
0000762f89bd9d03  vmovaps [rsp], xmm0
0000762f89bd9d08  vmovaps [rsp+0x10], xmm1
0000762f89bd9d0e  vmovaps [rsp+0x20], xmm2
0000762f89bd9d14  vmovaps [rsp+0x30], xmm3
0000762f89bd9d1a  vmovaps [rsp+0x40], xmm4
0000762f89bd9d20  vmovaps [rsp+0x50], xmm5
0000762f89bd9d26  vmovaps [rsp+0x60], xmm6
0000762f89bd9d2c  vmovaps [rsp+0x70], xmm7
0000762f89bd9d32  vmovaps [rsp+0x80], xmm8
0000762f89bd9d3b  vmovaps [rsp+0x90], xmm9
0000762f89bd9d44  vmovaps [rsp+0xA0], xmm11
0000762f89bd9d4d  vmovaps [rsp+0xB0], xmm12
0000762f89bd9d56  vmovaps [rsp+0xC0], xmm13
0000762f89bd9d5f  vmovaps [rsp+0xD0], xmm14
0000762f89bd9d68  vmovaps [rsp+0xE0], xmm15
0000762f89bd9d71  sub rsp, 0x30
0000762f89bd9d75  movaps [rsp], xmm10
0000762f89bd9d7a  movaps [rsp+0x10], xmm14
0000762f89bd9d80  movaps [rsp+0x20], xmm4
0000762f89bd9d85  lea rdi, [rsp]
0000762f89bd9d89  mov esi, 0x00
0000762f89bd9d8e  mov rax, 0x604D6F946530
0000762f89bd9d98  call rax
0000762f89bd9d9a  movaps xmm10, [rsp]
0000762f89bd9d9f  add rsp, 0x30
0000762f89bd9da3  vmovaps xmm0, [rsp]
0000762f89bd9da8  vmovaps xmm1, [rsp+0x10]
0000762f89bd9dae  vmovaps xmm2, [rsp+0x20]
0000762f89bd9db4  vmovaps xmm3, [rsp+0x30]
0000762f89bd9dba  vmovaps xmm4, [rsp+0x40]
0000762f89bd9dc0  vmovaps xmm5, [rsp+0x50]
0000762f89bd9dc6  vmovaps xmm6, [rsp+0x60]
0000762f89bd9dcc  vmovaps xmm7, [rsp+0x70]
0000762f89bd9dd2  vmovaps xmm8, [rsp+0x80]
0000762f89bd9ddb  vmovaps xmm9, [rsp+0x90]
0000762f89bd9de4  vmovaps xmm11, [rsp+0xA0]
0000762f89bd9ded  vmovaps xmm12, [rsp+0xB0]
0000762f89bd9df6  vmovaps xmm13, [rsp+0xC0]
0000762f89bd9dff  vmovaps xmm14, [rsp+0xD0]
0000762f89bd9e08  vmovaps xmm15, [rsp+0xE0]
0000762f89bd9e11  add rsp, 0xF0
0000762f89bd9e18  pop r11
0000762f89bd9e1a  pop r10
0000762f89bd9e1c  pop r9
0000762f89bd9e1e  pop r8
0000762f89bd9e20  pop rsi
0000762f89bd9e21  pop rdi
0000762f89bd9e22  pop rdx
0000762f89bd9e23  pop rcx
0000762f89bd9e24  pop rax
0000762f89bd9e25  add rsp, 0x08
0000762f89bd9e29  jmp 0x0000762F89BD6388
0000762f89bd9e2e  sub rsp, 0x08
0000762f89bd9e32  push rax
0000762f89bd9e33  push rcx
0000762f89bd9e34  push rdx
0000762f89bd9e35  push rdi
0000762f89bd9e36  push rsi
0000762f89bd9e37  push r8
0000762f89bd9e39  push r9
0000762f89bd9e3b  push r10
0000762f89bd9e3d  push r11
0000762f89bd9e3f  sub rsp, 0xF0
0000762f89bd9e46  vmovaps [rsp], xmm0
0000762f89bd9e4b  vmovaps [rsp+0x10], xmm1
0000762f89bd9e51  vmovaps [rsp+0x20], xmm2
0000762f89bd9e57  vmovaps [rsp+0x30], xmm3
0000762f89bd9e5d  vmovaps [rsp+0x40], xmm4
0000762f89bd9e63  vmovaps [rsp+0x50], xmm5
0000762f89bd9e69  vmovaps [rsp+0x60], xmm6
0000762f89bd9e6f  vmovaps [rsp+0x70], xmm7
0000762f89bd9e75  vmovaps [rsp+0x80], xmm9
0000762f89bd9e7e  vmovaps [rsp+0x90], xmm10
0000762f89bd9e87  vmovaps [rsp+0xA0], xmm11
0000762f89bd9e90  vmovaps [rsp+0xB0], xmm12
0000762f89bd9e99  vmovaps [rsp+0xC0], xmm13
0000762f89bd9ea2  vmovaps [rsp+0xD0], xmm14
0000762f89bd9eab  vmovaps [rsp+0xE0], xmm15
0000762f89bd9eb4  sub rsp, 0x30
0000762f89bd9eb8  movaps [rsp], xmm8
0000762f89bd9ebd  movaps [rsp+0x10], xmm1
0000762f89bd9ec2  movaps [rsp+0x20], xmm14
0000762f89bd9ec8  lea rdi, [rsp]
0000762f89bd9ecc  mov esi, 0x00
0000762f89bd9ed1  mov rax, 0x604D6F946530
0000762f89bd9edb  call rax
0000762f89bd9edd  movaps xmm8, [rsp]
0000762f89bd9ee2  add rsp, 0x30
0000762f89bd9ee6  vmovaps xmm0, [rsp]
0000762f89bd9eeb  vmovaps xmm1, [rsp+0x10]
0000762f89bd9ef1  vmovaps xmm2, [rsp+0x20]
0000762f89bd9ef7  vmovaps xmm3, [rsp+0x30]
0000762f89bd9efd  vmovaps xmm4, [rsp+0x40]
0000762f89bd9f03  vmovaps xmm5, [rsp+0x50]
0000762f89bd9f09  vmovaps xmm6, [rsp+0x60]
0000762f89bd9f0f  vmovaps xmm7, [rsp+0x70]
0000762f89bd9f15  vmovaps xmm9, [rsp+0x80]
0000762f89bd9f1e  vmovaps xmm10, [rsp+0x90]
0000762f89bd9f27  vmovaps xmm11, [rsp+0xA0]
0000762f89bd9f30  vmovaps xmm12, [rsp+0xB0]
0000762f89bd9f39  vmovaps xmm13, [rsp+0xC0]
0000762f89bd9f42  vmovaps xmm14, [rsp+0xD0]
0000762f89bd9f4b  vmovaps xmm15, [rsp+0xE0]
0000762f89bd9f54  add rsp, 0xF0
0000762f89bd9f5b  pop r11
0000762f89bd9f5d  pop r10
0000762f89bd9f5f  pop r9
0000762f89bd9f61  pop r8
0000762f89bd9f63  pop rsi
0000762f89bd9f64  pop rdi
0000762f89bd9f65  pop rdx
0000762f89bd9f66  pop rcx
0000762f89bd9f67  pop rax
0000762f89bd9f68  add rsp, 0x08
0000762f89bd9f6c  jmp 0x0000762F89BD63AE
0000762f89bd9f71  sub rsp, 0x08
0000762f89bd9f75  push rax
0000762f89bd9f76  push rcx
0000762f89bd9f77  push rdx
0000762f89bd9f78  push rdi
0000762f89bd9f79  push rsi
0000762f89bd9f7a  push r8
0000762f89bd9f7c  push r9
0000762f89bd9f7e  push r10
0000762f89bd9f80  push r11
0000762f89bd9f82  sub rsp, 0xF0
0000762f89bd9f89  vmovaps [rsp], xmm0
0000762f89bd9f8e  vmovaps [rsp+0x10], xmm1
0000762f89bd9f94  vmovaps [rsp+0x20], xmm2
0000762f89bd9f9a  vmovaps [rsp+0x30], xmm3
0000762f89bd9fa0  vmovaps [rsp+0x40], xmm4
0000762f89bd9fa6  vmovaps [rsp+0x50], xmm5
0000762f89bd9fac  vmovaps [rsp+0x60], xmm7
0000762f89bd9fb2  vmovaps [rsp+0x70], xmm8
0000762f89bd9fb8  vmovaps [rsp+0x80], xmm9
0000762f89bd9fc1  vmovaps [rsp+0x90], xmm10
0000762f89bd9fca  vmovaps [rsp+0xA0], xmm11
0000762f89bd9fd3  vmovaps [rsp+0xB0], xmm12
0000762f89bd9fdc  vmovaps [rsp+0xC0], xmm13
0000762f89bd9fe5  vmovaps [rsp+0xD0], xmm14
0000762f89bd9fee  vmovaps [rsp+0xE0], xmm15
0000762f89bd9ff7  sub rsp, 0x30
0000762f89bd9ffb  movaps [rsp], xmm6
0000762f89bd9fff  movaps [rsp+0x10], xmm1
0000762f89bda004  movaps [rsp+0x20], xmm14
0000762f89bda00a  lea rdi, [rsp]
0000762f89bda00e  mov esi, 0x00
0000762f89bda013  mov rax, 0x604D6F946530
0000762f89bda01d  call rax
0000762f89bda01f  movaps xmm6, [rsp]
0000762f89bda023  add rsp, 0x30
0000762f89bda027  vmovaps xmm0, [rsp]
0000762f89bda02c  vmovaps xmm1, [rsp+0x10]
0000762f89bda032  vmovaps xmm2, [rsp+0x20]
0000762f89bda038  vmovaps xmm3, [rsp+0x30]
0000762f89bda03e  vmovaps xmm4, [rsp+0x40]
0000762f89bda044  vmovaps xmm5, [rsp+0x50]
0000762f89bda04a  vmovaps xmm7, [rsp+0x60]
0000762f89bda050  vmovaps xmm8, [rsp+0x70]
0000762f89bda056  vmovaps xmm9, [rsp+0x80]
0000762f89bda05f  vmovaps xmm10, [rsp+0x90]
0000762f89bda068  vmovaps xmm11, [rsp+0xA0]
0000762f89bda071  vmovaps xmm12, [rsp+0xB0]
0000762f89bda07a  vmovaps xmm13, [rsp+0xC0]
0000762f89bda083  vmovaps xmm14, [rsp+0xD0]
0000762f89bda08c  vmovaps xmm15, [rsp+0xE0]
0000762f89bda095  add rsp, 0xF0
0000762f89bda09c  pop r11
0000762f89bda09e  pop r10
0000762f89bda0a0  pop r9
0000762f89bda0a2  pop r8
0000762f89bda0a4  pop rsi
0000762f89bda0a5  pop rdi
0000762f89bda0a6  pop rdx
0000762f89bda0a7  pop rcx
0000762f89bda0a8  pop rax
0000762f89bda0a9  add rsp, 0x08
0000762f89bda0ad  jmp 0x0000762F89BD63DA
0000762f89bda0b2  sub rsp, 0x08
0000762f89bda0b6  push rax
0000762f89bda0b7  push rcx
0000762f89bda0b8  push rdx
0000762f89bda0b9  push rdi
0000762f89bda0ba  push rsi
0000762f89bda0bb  push r8
0000762f89bda0bd  push r9
0000762f89bda0bf  push r10
0000762f89bda0c1  push r11
0000762f89bda0c3  sub rsp, 0xF0
0000762f89bda0ca  vmovaps [rsp], xmm0
0000762f89bda0cf  vmovaps [rsp+0x10], xmm1
0000762f89bda0d5  vmovaps [rsp+0x20], xmm2
0000762f89bda0db  vmovaps [rsp+0x30], xmm3
0000762f89bda0e1  vmovaps [rsp+0x40], xmm4
0000762f89bda0e7  vmovaps [rsp+0x50], xmm5
0000762f89bda0ed  vmovaps [rsp+0x60], xmm6
0000762f89bda0f3  vmovaps [rsp+0x70], xmm7
0000762f89bda0f9  vmovaps [rsp+0x80], xmm8
0000762f89bda102  vmovaps [rsp+0x90], xmm9
0000762f89bda10b  vmovaps [rsp+0xA0], xmm10
0000762f89bda114  vmovaps [rsp+0xB0], xmm11
0000762f89bda11d  vmovaps [rsp+0xC0], xmm12
0000762f89bda126  vmovaps [rsp+0xD0], xmm13
0000762f89bda12f  vmovaps [rsp+0xE0], xmm15
0000762f89bda138  sub rsp, 0x30
0000762f89bda13c  movaps [rsp], xmm14
0000762f89bda141  movaps [rsp+0x10], xmm12
0000762f89bda147  movaps [rsp+0x20], xmm1
0000762f89bda14c  lea rdi, [rsp]
0000762f89bda150  mov esi, 0x00
0000762f89bda155  mov rax, 0x604D6F946530
0000762f89bda15f  call rax
0000762f89bda161  movaps xmm14, [rsp]
0000762f89bda166  add rsp, 0x30
0000762f89bda16a  vmovaps xmm0, [rsp]
0000762f89bda16f  vmovaps xmm1, [rsp+0x10]
0000762f89bda175  vmovaps xmm2, [rsp+0x20]
0000762f89bda17b  vmovaps xmm3, [rsp+0x30]
0000762f89bda181  vmovaps xmm4, [rsp+0x40]
0000762f89bda187  vmovaps xmm5, [rsp+0x50]
0000762f89bda18d  vmovaps xmm6, [rsp+0x60]
0000762f89bda193  vmovaps xmm7, [rsp+0x70]
0000762f89bda199  vmovaps xmm8, [rsp+0x80]
0000762f89bda1a2  vmovaps xmm9, [rsp+0x90]
0000762f89bda1ab  vmovaps xmm10, [rsp+0xA0]
0000762f89bda1b4  vmovaps xmm11, [rsp+0xB0]
0000762f89bda1bd  vmovaps xmm12, [rsp+0xC0]
0000762f89bda1c6  vmovaps xmm13, [rsp+0xD0]
0000762f89bda1cf  vmovaps xmm15, [rsp+0xE0]
0000762f89bda1d8  add rsp, 0xF0
0000762f89bda1df  pop r11
0000762f89bda1e1  pop r10
0000762f89bda1e3  pop r9
0000762f89bda1e5  pop r8
0000762f89bda1e7  pop rsi
0000762f89bda1e8  pop rdi
0000762f89bda1e9  pop rdx
0000762f89bda1ea  pop rcx
0000762f89bda1eb  pop rax
0000762f89bda1ec  add rsp, 0x08
0000762f89bda1f0  jmp 0x0000762F89BD6400
0000762f89bda1f5  sub rsp, 0x08
0000762f89bda1f9  push rax
0000762f89bda1fa  push rcx
0000762f89bda1fb  push rdx
0000762f89bda1fc  push rdi
0000762f89bda1fd  push rsi
0000762f89bda1fe  push r8
0000762f89bda200  push r9
0000762f89bda202  push r10
0000762f89bda204  push r11
0000762f89bda206  sub rsp, 0xF0
0000762f89bda20d  vmovaps [rsp], xmm0
0000762f89bda212  vmovaps [rsp+0x10], xmm2
0000762f89bda218  vmovaps [rsp+0x20], xmm3
0000762f89bda21e  vmovaps [rsp+0x30], xmm4
0000762f89bda224  vmovaps [rsp+0x40], xmm5
0000762f89bda22a  vmovaps [rsp+0x50], xmm6
0000762f89bda230  vmovaps [rsp+0x60], xmm7
0000762f89bda236  vmovaps [rsp+0x70], xmm8
0000762f89bda23c  vmovaps [rsp+0x80], xmm9
0000762f89bda245  vmovaps [rsp+0x90], xmm10
0000762f89bda24e  vmovaps [rsp+0xA0], xmm11
0000762f89bda257  vmovaps [rsp+0xB0], xmm12
0000762f89bda260  vmovaps [rsp+0xC0], xmm13
0000762f89bda269  vmovaps [rsp+0xD0], xmm14
0000762f89bda272  vmovaps [rsp+0xE0], xmm15
0000762f89bda27b  sub rsp, 0x30
0000762f89bda27f  movaps [rsp], xmm1
0000762f89bda283  movaps [rsp+0x10], xmm13
0000762f89bda289  movaps [rsp+0x20], xmm9
0000762f89bda28f  lea rdi, [rsp]
0000762f89bda293  mov esi, 0x00
0000762f89bda298  mov rax, 0x604D6F946530
0000762f89bda2a2  call rax
0000762f89bda2a4  movaps xmm1, [rsp]
0000762f89bda2a8  add rsp, 0x30
0000762f89bda2ac  vmovaps xmm0, [rsp]
0000762f89bda2b1  vmovaps xmm2, [rsp+0x10]
0000762f89bda2b7  vmovaps xmm3, [rsp+0x20]
0000762f89bda2bd  vmovaps xmm4, [rsp+0x30]
0000762f89bda2c3  vmovaps xmm5, [rsp+0x40]
0000762f89bda2c9  vmovaps xmm6, [rsp+0x50]
0000762f89bda2cf  vmovaps xmm7, [rsp+0x60]
0000762f89bda2d5  vmovaps xmm8, [rsp+0x70]
0000762f89bda2db  vmovaps xmm9, [rsp+0x80]
0000762f89bda2e4  vmovaps xmm10, [rsp+0x90]
0000762f89bda2ed  vmovaps xmm11, [rsp+0xA0]
0000762f89bda2f6  vmovaps xmm12, [rsp+0xB0]
0000762f89bda2ff  vmovaps xmm13, [rsp+0xC0]
0000762f89bda308  vmovaps xmm14, [rsp+0xD0]
0000762f89bda311  vmovaps xmm15, [rsp+0xE0]
0000762f89bda31a  add rsp, 0xF0
0000762f89bda321  pop r11
0000762f89bda323  pop r10
0000762f89bda325  pop r9
0000762f89bda327  pop r8
0000762f89bda329  pop rsi
0000762f89bda32a  pop rdi
0000762f89bda32b  pop rdx
0000762f89bda32c  pop rcx
0000762f89bda32d  pop rax
0000762f89bda32e  add rsp, 0x08
0000762f89bda332  jmp 0x0000762F89BD641A
0000762f89bda337  sub rsp, 0x08
0000762f89bda33b  push rax
0000762f89bda33c  push rcx
0000762f89bda33d  push rdx
0000762f89bda33e  push rdi
0000762f89bda33f  push rsi
0000762f89bda340  push r8
0000762f89bda342  push r9
0000762f89bda344  push r10
0000762f89bda346  push r11
0000762f89bda348  sub rsp, 0xF0
0000762f89bda34f  vmovaps [rsp], xmm0
0000762f89bda354  vmovaps [rsp+0x10], xmm1
0000762f89bda35a  vmovaps [rsp+0x20], xmm2
0000762f89bda360  vmovaps [rsp+0x30], xmm3
0000762f89bda366  vmovaps [rsp+0x40], xmm4
0000762f89bda36c  vmovaps [rsp+0x50], xmm5
0000762f89bda372  vmovaps [rsp+0x60], xmm6
0000762f89bda378  vmovaps [rsp+0x70], xmm7
0000762f89bda37e  vmovaps [rsp+0x80], xmm8
0000762f89bda387  vmovaps [rsp+0x90], xmm9
0000762f89bda390  vmovaps [rsp+0xA0], xmm10
0000762f89bda399  vmovaps [rsp+0xB0], xmm11
0000762f89bda3a2  vmovaps [rsp+0xC0], xmm13
0000762f89bda3ab  vmovaps [rsp+0xD0], xmm14
0000762f89bda3b4  vmovaps [rsp+0xE0], xmm15
0000762f89bda3bd  sub rsp, 0x30
0000762f89bda3c1  movaps [rsp], xmm12
0000762f89bda3c6  movaps [rsp+0x10], xmm7
0000762f89bda3cb  movaps [rsp+0x20], xmm13
0000762f89bda3d1  lea rdi, [rsp]
0000762f89bda3d5  mov esi, 0x00
0000762f89bda3da  mov rax, 0x604D6F946530
0000762f89bda3e4  call rax
0000762f89bda3e6  movaps xmm12, [rsp]
0000762f89bda3eb  add rsp, 0x30
0000762f89bda3ef  vmovaps xmm0, [rsp]
0000762f89bda3f4  vmovaps xmm1, [rsp+0x10]
0000762f89bda3fa  vmovaps xmm2, [rsp+0x20]
0000762f89bda400  vmovaps xmm3, [rsp+0x30]
0000762f89bda406  vmovaps xmm4, [rsp+0x40]
0000762f89bda40c  vmovaps xmm5, [rsp+0x50]
0000762f89bda412  vmovaps xmm6, [rsp+0x60]
0000762f89bda418  vmovaps xmm7, [rsp+0x70]
0000762f89bda41e  vmovaps xmm8, [rsp+0x80]
0000762f89bda427  vmovaps xmm9, [rsp+0x90]
0000762f89bda430  vmovaps xmm10, [rsp+0xA0]
0000762f89bda439  vmovaps xmm11, [rsp+0xB0]
0000762f89bda442  vmovaps xmm13, [rsp+0xC0]
0000762f89bda44b  vmovaps xmm14, [rsp+0xD0]
0000762f89bda454  vmovaps xmm15, [rsp+0xE0]
0000762f89bda45d  add rsp, 0xF0
0000762f89bda464  pop r11
0000762f89bda466  pop r10
0000762f89bda468  pop r9
0000762f89bda46a  pop r8
0000762f89bda46c  pop rsi
0000762f89bda46d  pop rdi
0000762f89bda46e  pop rdx
0000762f89bda46f  pop rcx
0000762f89bda470  pop rax
0000762f89bda471  add rsp, 0x08
0000762f89bda475  jmp 0x0000762F89BD6441
0000762f89bda47a  sub rsp, 0x08
0000762f89bda47e  push rax
0000762f89bda47f  push rcx
0000762f89bda480  push rdx
0000762f89bda481  push rdi
0000762f89bda482  push rsi
0000762f89bda483  push r8
0000762f89bda485  push r9
0000762f89bda487  push r10
0000762f89bda489  push r11
0000762f89bda48b  sub rsp, 0xF0
0000762f89bda492  vmovaps [rsp], xmm0
0000762f89bda497  vmovaps [rsp+0x10], xmm1
0000762f89bda49d  vmovaps [rsp+0x20], xmm2
0000762f89bda4a3  vmovaps [rsp+0x30], xmm3
0000762f89bda4a9  vmovaps [rsp+0x40], xmm4
0000762f89bda4af  vmovaps [rsp+0x50], xmm5
0000762f89bda4b5  vmovaps [rsp+0x60], xmm6
0000762f89bda4bb  vmovaps [rsp+0x70], xmm7
0000762f89bda4c1  vmovaps [rsp+0x80], xmm8
0000762f89bda4ca  vmovaps [rsp+0x90], xmm9
0000762f89bda4d3  vmovaps [rsp+0xA0], xmm10
0000762f89bda4dc  vmovaps [rsp+0xB0], xmm11
0000762f89bda4e5  vmovaps [rsp+0xC0], xmm12
0000762f89bda4ee  vmovaps [rsp+0xD0], xmm14
0000762f89bda4f7  vmovaps [rsp+0xE0], xmm15
0000762f89bda500  sub rsp, 0x30
0000762f89bda504  movaps [rsp], xmm13
0000762f89bda509  movaps [rsp+0x10], xmm15
0000762f89bda50f  movaps [rsp+0x20], xmm8
0000762f89bda515  lea rdi, [rsp]
0000762f89bda519  mov esi, 0x00
0000762f89bda51e  mov rax, 0x604D6F946530
0000762f89bda528  call rax
0000762f89bda52a  movaps xmm13, [rsp]
0000762f89bda52f  add rsp, 0x30
0000762f89bda533  vmovaps xmm0, [rsp]
0000762f89bda538  vmovaps xmm1, [rsp+0x10]
0000762f89bda53e  vmovaps xmm2, [rsp+0x20]
0000762f89bda544  vmovaps xmm3, [rsp+0x30]
0000762f89bda54a  vmovaps xmm4, [rsp+0x40]
0000762f89bda550  vmovaps xmm5, [rsp+0x50]
0000762f89bda556  vmovaps xmm6, [rsp+0x60]
0000762f89bda55c  vmovaps xmm7, [rsp+0x70]
0000762f89bda562  vmovaps xmm8, [rsp+0x80]
0000762f89bda56b  vmovaps xmm9, [rsp+0x90]
0000762f89bda574  vmovaps xmm10, [rsp+0xA0]
0000762f89bda57d  vmovaps xmm11, [rsp+0xB0]
0000762f89bda586  vmovaps xmm12, [rsp+0xC0]
0000762f89bda58f  vmovaps xmm14, [rsp+0xD0]
0000762f89bda598  vmovaps xmm15, [rsp+0xE0]
0000762f89bda5a1  add rsp, 0xF0
0000762f89bda5a8  pop r11
0000762f89bda5aa  pop r10
0000762f89bda5ac  pop r9
0000762f89bda5ae  pop r8
0000762f89bda5b0  pop rsi
0000762f89bda5b1  pop rdi
0000762f89bda5b2  pop rdx
0000762f89bda5b3  pop rcx
0000762f89bda5b4  pop rax
0000762f89bda5b5  add rsp, 0x08
0000762f89bda5b9  jmp 0x0000762F89BD645C
0000762f89bda5be  sub rsp, 0x08
0000762f89bda5c2  push rax
0000762f89bda5c3  push rcx
0000762f89bda5c4  push rdx
0000762f89bda5c5  push rdi
0000762f89bda5c6  push rsi
0000762f89bda5c7  push r8
0000762f89bda5c9  push r9
0000762f89bda5cb  push r10
0000762f89bda5cd  push r11
0000762f89bda5cf  sub rsp, 0xF0
0000762f89bda5d6  vmovaps [rsp], xmm0
0000762f89bda5db  vmovaps [rsp+0x10], xmm1
0000762f89bda5e1  vmovaps [rsp+0x20], xmm2
0000762f89bda5e7  vmovaps [rsp+0x30], xmm3
0000762f89bda5ed  vmovaps [rsp+0x40], xmm4
0000762f89bda5f3  vmovaps [rsp+0x50], xmm5
0000762f89bda5f9  vmovaps [rsp+0x60], xmm6
0000762f89bda5ff  vmovaps [rsp+0x70], xmm7
0000762f89bda605  vmovaps [rsp+0x80], xmm9
0000762f89bda60e  vmovaps [rsp+0x90], xmm10
0000762f89bda617  vmovaps [rsp+0xA0], xmm11
0000762f89bda620  vmovaps [rsp+0xB0], xmm12
0000762f89bda629  vmovaps [rsp+0xC0], xmm13
0000762f89bda632  vmovaps [rsp+0xD0], xmm14
0000762f89bda63b  vmovaps [rsp+0xE0], xmm15
0000762f89bda644  sub rsp, 0x30
0000762f89bda648  movaps [rsp], xmm8
0000762f89bda64d  movaps [rsp+0x10], xmm15
0000762f89bda653  movaps [rsp+0x20], xmm9
0000762f89bda659  lea rdi, [rsp]
0000762f89bda65d  mov esi, 0x00
0000762f89bda662  mov rax, 0x604D6F946530
0000762f89bda66c  call rax
0000762f89bda66e  movaps xmm8, [rsp]
0000762f89bda673  add rsp, 0x30
0000762f89bda677  vmovaps xmm0, [rsp]
0000762f89bda67c  vmovaps xmm1, [rsp+0x10]
0000762f89bda682  vmovaps xmm2, [rsp+0x20]
0000762f89bda688  vmovaps xmm3, [rsp+0x30]
0000762f89bda68e  vmovaps xmm4, [rsp+0x40]
0000762f89bda694  vmovaps xmm5, [rsp+0x50]
0000762f89bda69a  vmovaps xmm6, [rsp+0x60]
0000762f89bda6a0  vmovaps xmm7, [rsp+0x70]
0000762f89bda6a6  vmovaps xmm9, [rsp+0x80]
0000762f89bda6af  vmovaps xmm10, [rsp+0x90]
0000762f89bda6b8  vmovaps xmm11, [rsp+0xA0]
0000762f89bda6c1  vmovaps xmm12, [rsp+0xB0]
0000762f89bda6ca  vmovaps xmm13, [rsp+0xC0]
0000762f89bda6d3  vmovaps xmm14, [rsp+0xD0]
0000762f89bda6dc  vmovaps xmm15, [rsp+0xE0]
0000762f89bda6e5  add rsp, 0xF0
0000762f89bda6ec  pop r11
0000762f89bda6ee  pop r10
0000762f89bda6f0  pop r9
0000762f89bda6f2  pop r8
0000762f89bda6f4  pop rsi
0000762f89bda6f5  pop rdi
0000762f89bda6f6  pop rdx
0000762f89bda6f7  pop rcx
0000762f89bda6f8  pop rax
0000762f89bda6f9  add rsp, 0x08
0000762f89bda6fd  jmp 0x0000762F89BD648A
0000762f89bda702  sub rsp, 0x08
0000762f89bda706  push rax
0000762f89bda707  push rcx
0000762f89bda708  push rdx
0000762f89bda709  push rdi
0000762f89bda70a  push rsi
0000762f89bda70b  push r8
0000762f89bda70d  push r9
0000762f89bda70f  push r10
0000762f89bda711  push r11
0000762f89bda713  sub rsp, 0xF0
0000762f89bda71a  vmovaps [rsp], xmm0
0000762f89bda71f  vmovaps [rsp+0x10], xmm1
0000762f89bda725  vmovaps [rsp+0x20], xmm2
0000762f89bda72b  vmovaps [rsp+0x30], xmm3
0000762f89bda731  vmovaps [rsp+0x40], xmm4
0000762f89bda737  vmovaps [rsp+0x50], xmm5
0000762f89bda73d  vmovaps [rsp+0x60], xmm6
0000762f89bda743  vmovaps [rsp+0x70], xmm7
0000762f89bda749  vmovaps [rsp+0x80], xmm8
0000762f89bda752  vmovaps [rsp+0x90], xmm9
0000762f89bda75b  vmovaps [rsp+0xA0], xmm10
0000762f89bda764  vmovaps [rsp+0xB0], xmm11
0000762f89bda76d  vmovaps [rsp+0xC0], xmm12
0000762f89bda776  vmovaps [rsp+0xD0], xmm13
0000762f89bda77f  vmovaps [rsp+0xE0], xmm14
0000762f89bda788  sub rsp, 0x30
0000762f89bda78c  movaps [rsp], xmm15
0000762f89bda791  movaps [rsp+0x10], xmm11
0000762f89bda797  movaps [rsp+0x20], xmm6
0000762f89bda79c  lea rdi, [rsp]
0000762f89bda7a0  mov esi, 0x00
0000762f89bda7a5  mov rax, 0x604D6F946530
0000762f89bda7af  call rax
0000762f89bda7b1  movaps xmm15, [rsp]
0000762f89bda7b6  add rsp, 0x30
0000762f89bda7ba  vmovaps xmm0, [rsp]
0000762f89bda7bf  vmovaps xmm1, [rsp+0x10]
0000762f89bda7c5  vmovaps xmm2, [rsp+0x20]
0000762f89bda7cb  vmovaps xmm3, [rsp+0x30]
0000762f89bda7d1  vmovaps xmm4, [rsp+0x40]
0000762f89bda7d7  vmovaps xmm5, [rsp+0x50]
0000762f89bda7dd  vmovaps xmm6, [rsp+0x60]
0000762f89bda7e3  vmovaps xmm7, [rsp+0x70]
0000762f89bda7e9  vmovaps xmm8, [rsp+0x80]
0000762f89bda7f2  vmovaps xmm9, [rsp+0x90]
0000762f89bda7fb  vmovaps xmm10, [rsp+0xA0]
0000762f89bda804  vmovaps xmm11, [rsp+0xB0]
0000762f89bda80d  vmovaps xmm12, [rsp+0xC0]
0000762f89bda816  vmovaps xmm13, [rsp+0xD0]
0000762f89bda81f  vmovaps xmm14, [rsp+0xE0]
0000762f89bda828  add rsp, 0xF0
0000762f89bda82f  pop r11
0000762f89bda831  pop r10
0000762f89bda833  pop r9
0000762f89bda835  pop r8
0000762f89bda837  pop rsi
0000762f89bda838  pop rdi
0000762f89bda839  pop rdx
0000762f89bda83a  pop rcx
0000762f89bda83b  pop rax
0000762f89bda83c  add rsp, 0x08
0000762f89bda840  jmp 0x0000762F89BD64A5
0000762f89bda845  sub rsp, 0x08
0000762f89bda849  push rax
0000762f89bda84a  push rcx
0000762f89bda84b  push rdx
0000762f89bda84c  push rdi
0000762f89bda84d  push rsi
0000762f89bda84e  push r8
0000762f89bda850  push r9
0000762f89bda852  push r10
0000762f89bda854  push r11
0000762f89bda856  sub rsp, 0xF0
0000762f89bda85d  vmovaps [rsp], xmm0
0000762f89bda862  vmovaps [rsp+0x10], xmm1
0000762f89bda868  vmovaps [rsp+0x20], xmm2
0000762f89bda86e  vmovaps [rsp+0x30], xmm3
0000762f89bda874  vmovaps [rsp+0x40], xmm4
0000762f89bda87a  vmovaps [rsp+0x50], xmm5
0000762f89bda880  vmovaps [rsp+0x60], xmm6
0000762f89bda886  vmovaps [rsp+0x70], xmm8
0000762f89bda88c  vmovaps [rsp+0x80], xmm9
0000762f89bda895  vmovaps [rsp+0x90], xmm10
0000762f89bda89e  vmovaps [rsp+0xA0], xmm11
0000762f89bda8a7  vmovaps [rsp+0xB0], xmm12
0000762f89bda8b0  vmovaps [rsp+0xC0], xmm13
0000762f89bda8b9  vmovaps [rsp+0xD0], xmm14
0000762f89bda8c2  vmovaps [rsp+0xE0], xmm15
0000762f89bda8cb  sub rsp, 0x30
0000762f89bda8cf  movaps [rsp], xmm7
0000762f89bda8d3  movaps [rsp+0x10], xmm11
0000762f89bda8d9  movaps [rsp+0x20], xmm9
0000762f89bda8df  lea rdi, [rsp]
0000762f89bda8e3  mov esi, 0x00
0000762f89bda8e8  mov rax, 0x604D6F946530
0000762f89bda8f2  call rax
0000762f89bda8f4  movaps xmm7, [rsp]
0000762f89bda8f8  add rsp, 0x30
0000762f89bda8fc  vmovaps xmm0, [rsp]
0000762f89bda901  vmovaps xmm1, [rsp+0x10]
0000762f89bda907  vmovaps xmm2, [rsp+0x20]
0000762f89bda90d  vmovaps xmm3, [rsp+0x30]
0000762f89bda913  vmovaps xmm4, [rsp+0x40]
0000762f89bda919  vmovaps xmm5, [rsp+0x50]
0000762f89bda91f  vmovaps xmm6, [rsp+0x60]
0000762f89bda925  vmovaps xmm8, [rsp+0x70]
0000762f89bda92b  vmovaps xmm9, [rsp+0x80]
0000762f89bda934  vmovaps xmm10, [rsp+0x90]
0000762f89bda93d  vmovaps xmm11, [rsp+0xA0]
0000762f89bda946  vmovaps xmm12, [rsp+0xB0]
0000762f89bda94f  vmovaps xmm13, [rsp+0xC0]
0000762f89bda958  vmovaps xmm14, [rsp+0xD0]
0000762f89bda961  vmovaps xmm15, [rsp+0xE0]
0000762f89bda96a  add rsp, 0xF0
0000762f89bda971  pop r11
0000762f89bda973  pop r10
0000762f89bda975  pop r9
0000762f89bda977  pop r8
0000762f89bda979  pop rsi
0000762f89bda97a  pop rdi
0000762f89bda97b  pop rdx
0000762f89bda97c  pop rcx
0000762f89bda97d  pop rax
0000762f89bda97e  add rsp, 0x08
0000762f89bda982  jmp 0x0000762F89BD64D2
0000762f89bda987  sub rsp, 0x08
0000762f89bda98b  push rax
0000762f89bda98c  push rcx
0000762f89bda98d  push rdx
0000762f89bda98e  push rdi
0000762f89bda98f  push rsi
0000762f89bda990  push r8
0000762f89bda992  push r9
0000762f89bda994  push r10
0000762f89bda996  push r11
0000762f89bda998  sub rsp, 0xF0
0000762f89bda99f  vmovaps [rsp], xmm0
0000762f89bda9a4  vmovaps [rsp+0x10], xmm1
0000762f89bda9aa  vmovaps [rsp+0x20], xmm2
0000762f89bda9b0  vmovaps [rsp+0x30], xmm3
0000762f89bda9b6  vmovaps [rsp+0x40], xmm4
0000762f89bda9bc  vmovaps [rsp+0x50], xmm5
0000762f89bda9c2  vmovaps [rsp+0x60], xmm6
0000762f89bda9c8  vmovaps [rsp+0x70], xmm7
0000762f89bda9ce  vmovaps [rsp+0x80], xmm8
0000762f89bda9d7  vmovaps [rsp+0x90], xmm9
0000762f89bda9e0  vmovaps [rsp+0xA0], xmm10
0000762f89bda9e9  vmovaps [rsp+0xB0], xmm12
0000762f89bda9f2  vmovaps [rsp+0xC0], xmm13
0000762f89bda9fb  vmovaps [rsp+0xD0], xmm14
0000762f89bdaa04  vmovaps [rsp+0xE0], xmm15
0000762f89bdaa0d  sub rsp, 0x30
0000762f89bdaa11  movaps [rsp], xmm11
0000762f89bdaa16  movaps [rsp+0x10], xmm10
0000762f89bdaa1c  movaps [rsp+0x20], xmm14
0000762f89bdaa22  lea rdi, [rsp]
0000762f89bdaa26  mov esi, 0x00
0000762f89bdaa2b  mov rax, 0x604D6F946530
0000762f89bdaa35  call rax
0000762f89bdaa37  movaps xmm11, [rsp]
0000762f89bdaa3c  add rsp, 0x30
0000762f89bdaa40  vmovaps xmm0, [rsp]
0000762f89bdaa45  vmovaps xmm1, [rsp+0x10]
0000762f89bdaa4b  vmovaps xmm2, [rsp+0x20]
0000762f89bdaa51  vmovaps xmm3, [rsp+0x30]
0000762f89bdaa57  vmovaps xmm4, [rsp+0x40]
0000762f89bdaa5d  vmovaps xmm5, [rsp+0x50]
0000762f89bdaa63  vmovaps xmm6, [rsp+0x60]
0000762f89bdaa69  vmovaps xmm7, [rsp+0x70]
0000762f89bdaa6f  vmovaps xmm8, [rsp+0x80]
0000762f89bdaa78  vmovaps xmm9, [rsp+0x90]
0000762f89bdaa81  vmovaps xmm10, [rsp+0xA0]
0000762f89bdaa8a  vmovaps xmm12, [rsp+0xB0]
0000762f89bdaa93  vmovaps xmm13, [rsp+0xC0]
0000762f89bdaa9c  vmovaps xmm14, [rsp+0xD0]
0000762f89bdaaa5  vmovaps xmm15, [rsp+0xE0]
0000762f89bdaaae  add rsp, 0xF0
0000762f89bdaab5  pop r11
0000762f89bdaab7  pop r10
0000762f89bdaab9  pop r9
0000762f89bdaabb  pop r8
0000762f89bdaabd  pop rsi
0000762f89bdaabe  pop rdi
0000762f89bdaabf  pop rdx
0000762f89bdaac0  pop rcx
0000762f89bdaac1  pop rax
0000762f89bdaac2  add rsp, 0x08
0000762f89bdaac6  jmp 0x0000762F89BD64ED
0000762f89bdaacb  call 0x0000762F89AE45A0
0000762f89bdaad0  jmp 0x0000762F89BD64F7
0000762f89bdaad5  sub rsp, 0x08
0000762f89bdaad9  push rax
0000762f89bdaada  push rcx
0000762f89bdaadb  push rdx
0000762f89bdaadc  push rdi
0000762f89bdaadd  push rsi
0000762f89bdaade  push r8
0000762f89bdaae0  push r9
0000762f89bdaae2  push r10
0000762f89bdaae4  push r11
0000762f89bdaae6  sub rsp, 0xF0
0000762f89bdaaed  vmovaps [rsp], xmm0
0000762f89bdaaf2  vmovaps [rsp+0x10], xmm1
0000762f89bdaaf8  vmovaps [rsp+0x20], xmm2
0000762f89bdaafe  vmovaps [rsp+0x30], xmm3
0000762f89bdab04  vmovaps [rsp+0x40], xmm4
0000762f89bdab0a  vmovaps [rsp+0x50], xmm5
0000762f89bdab10  vmovaps [rsp+0x60], xmm6
0000762f89bdab16  vmovaps [rsp+0x70], xmm7
0000762f89bdab1c  vmovaps [rsp+0x80], xmm8
0000762f89bdab25  vmovaps [rsp+0x90], xmm9
0000762f89bdab2e  vmovaps [rsp+0xA0], xmm11
0000762f89bdab37  vmovaps [rsp+0xB0], xmm12
0000762f89bdab40  vmovaps [rsp+0xC0], xmm13
0000762f89bdab49  vmovaps [rsp+0xD0], xmm14
0000762f89bdab52  vmovaps [rsp+0xE0], xmm15
0000762f89bdab5b  sub rsp, 0x30
0000762f89bdab5f  movaps [rsp], xmm10
0000762f89bdab64  movaps [rsp+0x10], xmm1
0000762f89bdab69  movaps [rsp+0x20], xmm12
0000762f89bdab6f  lea rdi, [rsp]
0000762f89bdab73  mov esi, 0x00
0000762f89bdab78  mov rax, 0x604D6F946530
0000762f89bdab82  call rax
0000762f89bdab84  movaps xmm10, [rsp]
0000762f89bdab89  add rsp, 0x30
0000762f89bdab8d  vmovaps xmm0, [rsp]
0000762f89bdab92  vmovaps xmm1, [rsp+0x10]
0000762f89bdab98  vmovaps xmm2, [rsp+0x20]
0000762f89bdab9e  vmovaps xmm3, [rsp+0x30]
0000762f89bdaba4  vmovaps xmm4, [rsp+0x40]
0000762f89bdabaa  vmovaps xmm5, [rsp+0x50]
0000762f89bdabb0  vmovaps xmm6, [rsp+0x60]
0000762f89bdabb6  vmovaps xmm7, [rsp+0x70]
0000762f89bdabbc  vmovaps xmm8, [rsp+0x80]
0000762f89bdabc5  vmovaps xmm9, [rsp+0x90]
0000762f89bdabce  vmovaps xmm11, [rsp+0xA0]
0000762f89bdabd7  vmovaps xmm12, [rsp+0xB0]
0000762f89bdabe0  vmovaps xmm13, [rsp+0xC0]
0000762f89bdabe9  vmovaps xmm14, [rsp+0xD0]
0000762f89bdabf2  vmovaps xmm15, [rsp+0xE0]
0000762f89bdabfb  add rsp, 0xF0
0000762f89bdac02  pop r11
0000762f89bdac04  pop r10
0000762f89bdac06  pop r9
0000762f89bdac08  pop r8
0000762f89bdac0a  pop rsi
0000762f89bdac0b  pop rdi
0000762f89bdac0c  pop rdx
0000762f89bdac0d  pop rcx
0000762f89bdac0e  pop rax
0000762f89bdac0f  add rsp, 0x08
0000762f89bdac13  jmp 0x0000762F89BD651A
0000762f89bdac18  sub rsp, 0x08
0000762f89bdac1c  push rax
0000762f89bdac1d  push rcx
0000762f89bdac1e  push rdx
0000762f89bdac1f  push rdi
0000762f89bdac20  push rsi
0000762f89bdac21  push r8
0000762f89bdac23  push r9
0000762f89bdac25  push r10
0000762f89bdac27  push r11
0000762f89bdac29  sub rsp, 0xF0
0000762f89bdac30  vmovaps [rsp], xmm0
0000762f89bdac35  vmovaps [rsp+0x10], xmm1
0000762f89bdac3b  vmovaps [rsp+0x20], xmm2
0000762f89bdac41  vmovaps [rsp+0x30], xmm3
0000762f89bdac47  vmovaps [rsp+0x40], xmm4
0000762f89bdac4d  vmovaps [rsp+0x50], xmm5
0000762f89bdac53  vmovaps [rsp+0x60], xmm6
0000762f89bdac59  vmovaps [rsp+0x70], xmm7
0000762f89bdac5f  vmovaps [rsp+0x80], xmm8
0000762f89bdac68  vmovaps [rsp+0x90], xmm9
0000762f89bdac71  vmovaps [rsp+0xA0], xmm10
0000762f89bdac7a  vmovaps [rsp+0xB0], xmm11
0000762f89bdac83  vmovaps [rsp+0xC0], xmm13
0000762f89bdac8c  vmovaps [rsp+0xD0], xmm14
0000762f89bdac95  vmovaps [rsp+0xE0], xmm15
0000762f89bdac9e  sub rsp, 0x30
0000762f89bdaca2  movaps [rsp], xmm12
0000762f89bdaca7  movaps [rsp+0x10], xmm14
0000762f89bdacad  movaps [rsp+0x20], xmm1
0000762f89bdacb2  lea rdi, [rsp]
0000762f89bdacb6  mov esi, 0x00
0000762f89bdacbb  mov rax, 0x604D6F946530
0000762f89bdacc5  call rax
0000762f89bdacc7  movaps xmm12, [rsp]
0000762f89bdaccc  add rsp, 0x30
0000762f89bdacd0  vmovaps xmm0, [rsp]
0000762f89bdacd5  vmovaps xmm1, [rsp+0x10]
0000762f89bdacdb  vmovaps xmm2, [rsp+0x20]
0000762f89bdace1  vmovaps xmm3, [rsp+0x30]
0000762f89bdace7  vmovaps xmm4, [rsp+0x40]
0000762f89bdaced  vmovaps xmm5, [rsp+0x50]
0000762f89bdacf3  vmovaps xmm6, [rsp+0x60]
0000762f89bdacf9  vmovaps xmm7, [rsp+0x70]
0000762f89bdacff  vmovaps xmm8, [rsp+0x80]
0000762f89bdad08  vmovaps xmm9, [rsp+0x90]
0000762f89bdad11  vmovaps xmm10, [rsp+0xA0]
0000762f89bdad1a  vmovaps xmm11, [rsp+0xB0]
0000762f89bdad23  vmovaps xmm13, [rsp+0xC0]
0000762f89bdad2c  vmovaps xmm14, [rsp+0xD0]
0000762f89bdad35  vmovaps xmm15, [rsp+0xE0]
0000762f89bdad3e  add rsp, 0xF0
0000762f89bdad45  pop r11
0000762f89bdad47  pop r10
0000762f89bdad49  pop r9
0000762f89bdad4b  pop r8
0000762f89bdad4d  pop rsi
0000762f89bdad4e  pop rdi
0000762f89bdad4f  pop rdx
0000762f89bdad50  pop rcx
0000762f89bdad51  pop rax
0000762f89bdad52  add rsp, 0x08
0000762f89bdad56  jmp 0x0000762F89BD6549
0000762f89bdad5b  sub rsp, 0x08
0000762f89bdad5f  push rax
0000762f89bdad60  push rcx
0000762f89bdad61  push rdx
0000762f89bdad62  push rdi
0000762f89bdad63  push rsi
0000762f89bdad64  push r8
0000762f89bdad66  push r9
0000762f89bdad68  push r10
0000762f89bdad6a  push r11
0000762f89bdad6c  sub rsp, 0xF0
0000762f89bdad73  vmovaps [rsp], xmm0
0000762f89bdad78  vmovaps [rsp+0x10], xmm1
0000762f89bdad7e  vmovaps [rsp+0x20], xmm2
0000762f89bdad84  vmovaps [rsp+0x30], xmm3
0000762f89bdad8a  vmovaps [rsp+0x40], xmm4
0000762f89bdad90  vmovaps [rsp+0x50], xmm5
0000762f89bdad96  vmovaps [rsp+0x60], xmm6
0000762f89bdad9c  vmovaps [rsp+0x70], xmm7
0000762f89bdada2  vmovaps [rsp+0x80], xmm8
0000762f89bdadab  vmovaps [rsp+0x90], xmm9
0000762f89bdadb4  vmovaps [rsp+0xA0], xmm10
0000762f89bdadbd  vmovaps [rsp+0xB0], xmm11
0000762f89bdadc6  vmovaps [rsp+0xC0], xmm12
0000762f89bdadcf  vmovaps [rsp+0xD0], xmm13
0000762f89bdadd8  vmovaps [rsp+0xE0], xmm15
0000762f89bdade1  sub rsp, 0x30
0000762f89bdade5  movaps [rsp], xmm14
0000762f89bdadea  movaps [rsp+0x10], xmm9
0000762f89bdadf0  movaps [rsp+0x20], xmm1
0000762f89bdadf5  lea rdi, [rsp]
0000762f89bdadf9  mov esi, 0x00
0000762f89bdadfe  mov rax, 0x604D6F946530
0000762f89bdae08  call rax
0000762f89bdae0a  movaps xmm14, [rsp]
0000762f89bdae0f  add rsp, 0x30
0000762f89bdae13  vmovaps xmm0, [rsp]
0000762f89bdae18  vmovaps xmm1, [rsp+0x10]
0000762f89bdae1e  vmovaps xmm2, [rsp+0x20]
0000762f89bdae24  vmovaps xmm3, [rsp+0x30]
0000762f89bdae2a  vmovaps xmm4, [rsp+0x40]
0000762f89bdae30  vmovaps xmm5, [rsp+0x50]
0000762f89bdae36  vmovaps xmm6, [rsp+0x60]
0000762f89bdae3c  vmovaps xmm7, [rsp+0x70]
0000762f89bdae42  vmovaps xmm8, [rsp+0x80]
0000762f89bdae4b  vmovaps xmm9, [rsp+0x90]
0000762f89bdae54  vmovaps xmm10, [rsp+0xA0]
0000762f89bdae5d  vmovaps xmm11, [rsp+0xB0]
0000762f89bdae66  vmovaps xmm12, [rsp+0xC0]
0000762f89bdae6f  vmovaps xmm13, [rsp+0xD0]
0000762f89bdae78  vmovaps xmm15, [rsp+0xE0]
0000762f89bdae81  add rsp, 0xF0
0000762f89bdae88  pop r11
0000762f89bdae8a  pop r10
0000762f89bdae8c  pop r9
0000762f89bdae8e  pop r8
0000762f89bdae90  pop rsi
0000762f89bdae91  pop rdi
0000762f89bdae92  pop rdx
0000762f89bdae93  pop rcx
0000762f89bdae94  pop rax
0000762f89bdae95  add rsp, 0x08
0000762f89bdae99  jmp 0x0000762F89BD6578
0000762f89bdae9e  sub rsp, 0x08
0000762f89bdaea2  push rax
0000762f89bdaea3  push rcx
0000762f89bdaea4  push rdx
0000762f89bdaea5  push rdi
0000762f89bdaea6  push rsi
0000762f89bdaea7  push r8
0000762f89bdaea9  push r9
0000762f89bdaeab  push r10
0000762f89bdaead  push r11
0000762f89bdaeaf  sub rsp, 0xF0
0000762f89bdaeb6  vmovaps [rsp], xmm0
0000762f89bdaebb  vmovaps [rsp+0x10], xmm2
0000762f89bdaec1  vmovaps [rsp+0x20], xmm3
0000762f89bdaec7  vmovaps [rsp+0x30], xmm4
0000762f89bdaecd  vmovaps [rsp+0x40], xmm5
0000762f89bdaed3  vmovaps [rsp+0x50], xmm6
0000762f89bdaed9  vmovaps [rsp+0x60], xmm7
0000762f89bdaedf  vmovaps [rsp+0x70], xmm8
0000762f89bdaee5  vmovaps [rsp+0x80], xmm9
0000762f89bdaeee  vmovaps [rsp+0x90], xmm10
0000762f89bdaef7  vmovaps [rsp+0xA0], xmm11
0000762f89bdaf00  vmovaps [rsp+0xB0], xmm12
0000762f89bdaf09  vmovaps [rsp+0xC0], xmm13
0000762f89bdaf12  vmovaps [rsp+0xD0], xmm14
0000762f89bdaf1b  vmovaps [rsp+0xE0], xmm15
0000762f89bdaf24  sub rsp, 0x30
0000762f89bdaf28  movaps [rsp], xmm1
0000762f89bdaf2c  movaps [rsp+0x10], xmm13
0000762f89bdaf32  movaps [rsp+0x20], xmm8
0000762f89bdaf38  lea rdi, [rsp]
0000762f89bdaf3c  mov esi, 0x00
0000762f89bdaf41  mov rax, 0x604D6F946530
0000762f89bdaf4b  call rax
0000762f89bdaf4d  movaps xmm1, [rsp]
0000762f89bdaf51  add rsp, 0x30
0000762f89bdaf55  vmovaps xmm0, [rsp]
0000762f89bdaf5a  vmovaps xmm2, [rsp+0x10]
0000762f89bdaf60  vmovaps xmm3, [rsp+0x20]
0000762f89bdaf66  vmovaps xmm4, [rsp+0x30]
0000762f89bdaf6c  vmovaps xmm5, [rsp+0x40]
0000762f89bdaf72  vmovaps xmm6, [rsp+0x50]
0000762f89bdaf78  vmovaps xmm7, [rsp+0x60]
0000762f89bdaf7e  vmovaps xmm8, [rsp+0x70]
0000762f89bdaf84  vmovaps xmm9, [rsp+0x80]
0000762f89bdaf8d  vmovaps xmm10, [rsp+0x90]
0000762f89bdaf96  vmovaps xmm11, [rsp+0xA0]
0000762f89bdaf9f  vmovaps xmm12, [rsp+0xB0]
0000762f89bdafa8  vmovaps xmm13, [rsp+0xC0]
0000762f89bdafb1  vmovaps xmm14, [rsp+0xD0]
0000762f89bdafba  vmovaps xmm15, [rsp+0xE0]
0000762f89bdafc3  add rsp, 0xF0
0000762f89bdafca  pop r11
0000762f89bdafcc  pop r10
0000762f89bdafce  pop r9
0000762f89bdafd0  pop r8
0000762f89bdafd2  pop rsi
0000762f89bdafd3  pop rdi
0000762f89bdafd4  pop rdx
0000762f89bdafd5  pop rcx
0000762f89bdafd6  pop rax
0000762f89bdafd7  add rsp, 0x08
0000762f89bdafdb  jmp 0x0000762F89BD659A
0000762f89bdafe0  call 0x0000762F89A0C260
0000762f89bdafe5  jmp 0x0000762F89BD65A8
0000762f89bdafea  call 0x0000762F89ADE950
0000762f89bdafef  jmp 0x0000762F89BD65B2
0000762f89bdaff4  sub rsp, 0x08
0000762f89bdaff8  push rax
0000762f89bdaff9  push rcx
0000762f89bdaffa  push rdx
0000762f89bdaffb  push rdi
0000762f89bdaffc  push rsi
0000762f89bdaffd  push r8
0000762f89bdafff  push r9
0000762f89bdb001  push r10
0000762f89bdb003  push r11
0000762f89bdb005  sub rsp, 0xF0
0000762f89bdb00c  vmovaps [rsp], xmm0
0000762f89bdb011  vmovaps [rsp+0x10], xmm1
0000762f89bdb017  vmovaps [rsp+0x20], xmm2
0000762f89bdb01d  vmovaps [rsp+0x30], xmm3
0000762f89bdb023  vmovaps [rsp+0x40], xmm4
0000762f89bdb029  vmovaps [rsp+0x50], xmm5
0000762f89bdb02f  vmovaps [rsp+0x60], xmm6
0000762f89bdb035  vmovaps [rsp+0x70], xmm7
0000762f89bdb03b  vmovaps [rsp+0x80], xmm9
0000762f89bdb044  vmovaps [rsp+0x90], xmm10
0000762f89bdb04d  vmovaps [rsp+0xA0], xmm11
0000762f89bdb056  vmovaps [rsp+0xB0], xmm12
0000762f89bdb05f  vmovaps [rsp+0xC0], xmm13
0000762f89bdb068  vmovaps [rsp+0xD0], xmm14
0000762f89bdb071  vmovaps [rsp+0xE0], xmm15
0000762f89bdb07a  sub rsp, 0x30
0000762f89bdb07e  movaps [rsp], xmm8
0000762f89bdb083  movaps [rsp+0x10], xmm15
0000762f89bdb089  movaps [rsp+0x20], xmm7
0000762f89bdb08e  lea rdi, [rsp]
0000762f89bdb092  mov esi, 0x00
0000762f89bdb097  mov rax, 0x604D6F946530
0000762f89bdb0a1  call rax
0000762f89bdb0a3  movaps xmm8, [rsp]
0000762f89bdb0a8  add rsp, 0x30
0000762f89bdb0ac  vmovaps xmm0, [rsp]
0000762f89bdb0b1  vmovaps xmm1, [rsp+0x10]
0000762f89bdb0b7  vmovaps xmm2, [rsp+0x20]
0000762f89bdb0bd  vmovaps xmm3, [rsp+0x30]
0000762f89bdb0c3  vmovaps xmm4, [rsp+0x40]
0000762f89bdb0c9  vmovaps xmm5, [rsp+0x50]
0000762f89bdb0cf  vmovaps xmm6, [rsp+0x60]
0000762f89bdb0d5  vmovaps xmm7, [rsp+0x70]
0000762f89bdb0db  vmovaps xmm9, [rsp+0x80]
0000762f89bdb0e4  vmovaps xmm10, [rsp+0x90]
0000762f89bdb0ed  vmovaps xmm11, [rsp+0xA0]
0000762f89bdb0f6  vmovaps xmm12, [rsp+0xB0]
0000762f89bdb0ff  vmovaps xmm13, [rsp+0xC0]
0000762f89bdb108  vmovaps xmm14, [rsp+0xD0]
0000762f89bdb111  vmovaps xmm15, [rsp+0xE0]
0000762f89bdb11a  add rsp, 0xF0
0000762f89bdb121  pop r11
0000762f89bdb123  pop r10
0000762f89bdb125  pop r9
0000762f89bdb127  pop r8
0000762f89bdb129  pop rsi
0000762f89bdb12a  pop rdi
0000762f89bdb12b  pop rdx
0000762f89bdb12c  pop rcx
0000762f89bdb12d  pop rax
0000762f89bdb12e  add rsp, 0x08
0000762f89bdb132  jmp 0x0000762F89BD65D4
0000762f89bdb137  sub rsp, 0x08
0000762f89bdb13b  push rax
0000762f89bdb13c  push rcx
0000762f89bdb13d  push rdx
0000762f89bdb13e  push rdi
0000762f89bdb13f  push rsi
0000762f89bdb140  push r8
0000762f89bdb142  push r9
0000762f89bdb144  push r10
0000762f89bdb146  push r11
0000762f89bdb148  sub rsp, 0xF0
0000762f89bdb14f  vmovaps [rsp], xmm0
0000762f89bdb154  vmovaps [rsp+0x10], xmm1
0000762f89bdb15a  vmovaps [rsp+0x20], xmm2
0000762f89bdb160  vmovaps [rsp+0x30], xmm3
0000762f89bdb166  vmovaps [rsp+0x40], xmm4
0000762f89bdb16c  vmovaps [rsp+0x50], xmm5
0000762f89bdb172  vmovaps [rsp+0x60], xmm6
0000762f89bdb178  vmovaps [rsp+0x70], xmm8
0000762f89bdb17e  vmovaps [rsp+0x80], xmm9
0000762f89bdb187  vmovaps [rsp+0x90], xmm10
0000762f89bdb190  vmovaps [rsp+0xA0], xmm11
0000762f89bdb199  vmovaps [rsp+0xB0], xmm12
0000762f89bdb1a2  vmovaps [rsp+0xC0], xmm13
0000762f89bdb1ab  vmovaps [rsp+0xD0], xmm14
0000762f89bdb1b4  vmovaps [rsp+0xE0], xmm15
0000762f89bdb1bd  sub rsp, 0x30
0000762f89bdb1c1  movaps [rsp], xmm7
0000762f89bdb1c5  movaps [rsp+0x10], xmm9
0000762f89bdb1cb  movaps [rsp+0x20], xmm15
0000762f89bdb1d1  lea rdi, [rsp]
0000762f89bdb1d5  mov esi, 0x00
0000762f89bdb1da  mov rax, 0x604D6F946530
0000762f89bdb1e4  call rax
0000762f89bdb1e6  movaps xmm7, [rsp]
0000762f89bdb1ea  add rsp, 0x30
0000762f89bdb1ee  vmovaps xmm0, [rsp]
0000762f89bdb1f3  vmovaps xmm1, [rsp+0x10]
0000762f89bdb1f9  vmovaps xmm2, [rsp+0x20]
0000762f89bdb1ff  vmovaps xmm3, [rsp+0x30]
0000762f89bdb205  vmovaps xmm4, [rsp+0x40]
0000762f89bdb20b  vmovaps xmm5, [rsp+0x50]
0000762f89bdb211  vmovaps xmm6, [rsp+0x60]
0000762f89bdb217  vmovaps xmm8, [rsp+0x70]
0000762f89bdb21d  vmovaps xmm9, [rsp+0x80]
0000762f89bdb226  vmovaps xmm10, [rsp+0x90]
0000762f89bdb22f  vmovaps xmm11, [rsp+0xA0]
0000762f89bdb238  vmovaps xmm12, [rsp+0xB0]
0000762f89bdb241  vmovaps xmm13, [rsp+0xC0]
0000762f89bdb24a  vmovaps xmm14, [rsp+0xD0]
0000762f89bdb253  vmovaps xmm15, [rsp+0xE0]
0000762f89bdb25c  add rsp, 0xF0
0000762f89bdb263  pop r11
0000762f89bdb265  pop r10
0000762f89bdb267  pop r9
0000762f89bdb269  pop r8
0000762f89bdb26b  pop rsi
0000762f89bdb26c  pop rdi
0000762f89bdb26d  pop rdx
0000762f89bdb26e  pop rcx
0000762f89bdb26f  pop rax
0000762f89bdb270  add rsp, 0x08
0000762f89bdb274  jmp 0x0000762F89BD6601
0000762f89bdb279  sub rsp, 0x08
0000762f89bdb27d  push rax
0000762f89bdb27e  push rcx
0000762f89bdb27f  push rdx
0000762f89bdb280  push rdi
0000762f89bdb281  push rsi
0000762f89bdb282  push r8
0000762f89bdb284  push r9
0000762f89bdb286  push r10
0000762f89bdb288  push r11
0000762f89bdb28a  sub rsp, 0xF0
0000762f89bdb291  vmovaps [rsp], xmm0
0000762f89bdb296  vmovaps [rsp+0x10], xmm1
0000762f89bdb29c  vmovaps [rsp+0x20], xmm2
0000762f89bdb2a2  vmovaps [rsp+0x30], xmm3
0000762f89bdb2a8  vmovaps [rsp+0x40], xmm4
0000762f89bdb2ae  vmovaps [rsp+0x50], xmm5
0000762f89bdb2b4  vmovaps [rsp+0x60], xmm6
0000762f89bdb2ba  vmovaps [rsp+0x70], xmm7
0000762f89bdb2c0  vmovaps [rsp+0x80], xmm8
0000762f89bdb2c9  vmovaps [rsp+0x90], xmm10
0000762f89bdb2d2  vmovaps [rsp+0xA0], xmm11
0000762f89bdb2db  vmovaps [rsp+0xB0], xmm12
0000762f89bdb2e4  vmovaps [rsp+0xC0], xmm13
0000762f89bdb2ed  vmovaps [rsp+0xD0], xmm14
0000762f89bdb2f6  vmovaps [rsp+0xE0], xmm15
0000762f89bdb2ff  sub rsp, 0x30
0000762f89bdb303  movaps [rsp], xmm9
0000762f89bdb308  movaps [rsp+0x10], xmm13
0000762f89bdb30e  movaps [rsp+0x20], xmm15
0000762f89bdb314  lea rdi, [rsp]
0000762f89bdb318  mov esi, 0x00
0000762f89bdb31d  mov rax, 0x604D6F946530
0000762f89bdb327  call rax
0000762f89bdb329  movaps xmm9, [rsp]
0000762f89bdb32e  add rsp, 0x30
0000762f89bdb332  vmovaps xmm0, [rsp]
0000762f89bdb337  vmovaps xmm1, [rsp+0x10]
0000762f89bdb33d  vmovaps xmm2, [rsp+0x20]
0000762f89bdb343  vmovaps xmm3, [rsp+0x30]
0000762f89bdb349  vmovaps xmm4, [rsp+0x40]
0000762f89bdb34f  vmovaps xmm5, [rsp+0x50]
0000762f89bdb355  vmovaps xmm6, [rsp+0x60]
0000762f89bdb35b  vmovaps xmm7, [rsp+0x70]
0000762f89bdb361  vmovaps xmm8, [rsp+0x80]
0000762f89bdb36a  vmovaps xmm10, [rsp+0x90]
0000762f89bdb373  vmovaps xmm11, [rsp+0xA0]
0000762f89bdb37c  vmovaps xmm12, [rsp+0xB0]
0000762f89bdb385  vmovaps xmm13, [rsp+0xC0]
0000762f89bdb38e  vmovaps xmm14, [rsp+0xD0]
0000762f89bdb397  vmovaps xmm15, [rsp+0xE0]
0000762f89bdb3a0  add rsp, 0xF0
0000762f89bdb3a7  pop r11
0000762f89bdb3a9  pop r10
0000762f89bdb3ab  pop r9
0000762f89bdb3ad  pop r8
0000762f89bdb3af  pop rsi
0000762f89bdb3b0  pop rdi
0000762f89bdb3b1  pop rdx
0000762f89bdb3b2  pop rcx
0000762f89bdb3b3  pop rax
0000762f89bdb3b4  add rsp, 0x08
0000762f89bdb3b8  jmp 0x0000762F89BD662F
0000762f89bdb3bd  sub rsp, 0x08
0000762f89bdb3c1  push rax
0000762f89bdb3c2  push rcx
0000762f89bdb3c3  push rdx
0000762f89bdb3c4  push rdi
0000762f89bdb3c5  push rsi
0000762f89bdb3c6  push r8
0000762f89bdb3c8  push r9
0000762f89bdb3ca  push r10
0000762f89bdb3cc  push r11
0000762f89bdb3ce  sub rsp, 0xF0
0000762f89bdb3d5  vmovaps [rsp], xmm0
0000762f89bdb3da  vmovaps [rsp+0x10], xmm1
0000762f89bdb3e0  vmovaps [rsp+0x20], xmm2
0000762f89bdb3e6  vmovaps [rsp+0x30], xmm3
0000762f89bdb3ec  vmovaps [rsp+0x40], xmm4
0000762f89bdb3f2  vmovaps [rsp+0x50], xmm5
0000762f89bdb3f8  vmovaps [rsp+0x60], xmm6
0000762f89bdb3fe  vmovaps [rsp+0x70], xmm7
0000762f89bdb404  vmovaps [rsp+0x80], xmm8
0000762f89bdb40d  vmovaps [rsp+0x90], xmm9
0000762f89bdb416  vmovaps [rsp+0xA0], xmm10
0000762f89bdb41f  vmovaps [rsp+0xB0], xmm11
0000762f89bdb428  vmovaps [rsp+0xC0], xmm12
0000762f89bdb431  vmovaps [rsp+0xD0], xmm13
0000762f89bdb43a  vmovaps [rsp+0xE0], xmm14
0000762f89bdb443  sub rsp, 0x30
0000762f89bdb447  movaps [rsp], xmm15
0000762f89bdb44c  movaps [rsp+0x10], xmm11
0000762f89bdb452  movaps [rsp+0x20], xmm12
0000762f89bdb458  lea rdi, [rsp]
0000762f89bdb45c  mov esi, 0x00
0000762f89bdb461  mov rax, 0x604D6F946530
0000762f89bdb46b  call rax
0000762f89bdb46d  movaps xmm15, [rsp]
0000762f89bdb472  add rsp, 0x30
0000762f89bdb476  vmovaps xmm0, [rsp]
0000762f89bdb47b  vmovaps xmm1, [rsp+0x10]
0000762f89bdb481  vmovaps xmm2, [rsp+0x20]
0000762f89bdb487  vmovaps xmm3, [rsp+0x30]
0000762f89bdb48d  vmovaps xmm4, [rsp+0x40]
0000762f89bdb493  vmovaps xmm5, [rsp+0x50]
0000762f89bdb499  vmovaps xmm6, [rsp+0x60]
0000762f89bdb49f  vmovaps xmm7, [rsp+0x70]
0000762f89bdb4a5  vmovaps xmm8, [rsp+0x80]
0000762f89bdb4ae  vmovaps xmm9, [rsp+0x90]
0000762f89bdb4b7  vmovaps xmm10, [rsp+0xA0]
0000762f89bdb4c0  vmovaps xmm11, [rsp+0xB0]
0000762f89bdb4c9  vmovaps xmm12, [rsp+0xC0]
0000762f89bdb4d2  vmovaps xmm13, [rsp+0xD0]
0000762f89bdb4db  vmovaps xmm14, [rsp+0xE0]
0000762f89bdb4e4  add rsp, 0xF0
0000762f89bdb4eb  pop r11
0000762f89bdb4ed  pop r10
0000762f89bdb4ef  pop r9
0000762f89bdb4f1  pop r8
0000762f89bdb4f3  pop rsi
0000762f89bdb4f4  pop rdi
0000762f89bdb4f5  pop rdx
0000762f89bdb4f6  pop rcx
0000762f89bdb4f7  pop rax
0000762f89bdb4f8  add rsp, 0x08
0000762f89bdb4fc  jmp 0x0000762F89BD664A
0000762f89bdb501  sub rsp, 0x08
0000762f89bdb505  push rax
0000762f89bdb506  push rcx
0000762f89bdb507  push rdx
0000762f89bdb508  push rdi
0000762f89bdb509  push rsi
0000762f89bdb50a  push r8
0000762f89bdb50c  push r9
0000762f89bdb50e  push r10
0000762f89bdb510  push r11
0000762f89bdb512  sub rsp, 0xF0
0000762f89bdb519  vmovaps [rsp], xmm0
0000762f89bdb51e  vmovaps [rsp+0x10], xmm1
0000762f89bdb524  vmovaps [rsp+0x20], xmm2
0000762f89bdb52a  vmovaps [rsp+0x30], xmm3
0000762f89bdb530  vmovaps [rsp+0x40], xmm4
0000762f89bdb536  vmovaps [rsp+0x50], xmm5
0000762f89bdb53c  vmovaps [rsp+0x60], xmm6
0000762f89bdb542  vmovaps [rsp+0x70], xmm7
0000762f89bdb548  vmovaps [rsp+0x80], xmm8
0000762f89bdb551  vmovaps [rsp+0x90], xmm9
0000762f89bdb55a  vmovaps [rsp+0xA0], xmm10
0000762f89bdb563  vmovaps [rsp+0xB0], xmm11
0000762f89bdb56c  vmovaps [rsp+0xC0], xmm12
0000762f89bdb575  vmovaps [rsp+0xD0], xmm14
0000762f89bdb57e  vmovaps [rsp+0xE0], xmm15
0000762f89bdb587  sub rsp, 0x30
0000762f89bdb58b  movaps [rsp], xmm13
0000762f89bdb590  movaps [rsp+0x10], xmm10
0000762f89bdb596  movaps [rsp+0x20], xmm14
0000762f89bdb59c  lea rdi, [rsp]
0000762f89bdb5a0  mov esi, 0x00
0000762f89bdb5a5  mov rax, 0x604D6F946530
0000762f89bdb5af  call rax
0000762f89bdb5b1  movaps xmm13, [rsp]
0000762f89bdb5b6  add rsp, 0x30
0000762f89bdb5ba  vmovaps xmm0, [rsp]
0000762f89bdb5bf  vmovaps xmm1, [rsp+0x10]
0000762f89bdb5c5  vmovaps xmm2, [rsp+0x20]
0000762f89bdb5cb  vmovaps xmm3, [rsp+0x30]
0000762f89bdb5d1  vmovaps xmm4, [rsp+0x40]
0000762f89bdb5d7  vmovaps xmm5, [rsp+0x50]
0000762f89bdb5dd  vmovaps xmm6, [rsp+0x60]
0000762f89bdb5e3  vmovaps xmm7, [rsp+0x70]
0000762f89bdb5e9  vmovaps xmm8, [rsp+0x80]
0000762f89bdb5f2  vmovaps xmm9, [rsp+0x90]
0000762f89bdb5fb  vmovaps xmm10, [rsp+0xA0]
0000762f89bdb604  vmovaps xmm11, [rsp+0xB0]
0000762f89bdb60d  vmovaps xmm12, [rsp+0xC0]
0000762f89bdb616  vmovaps xmm14, [rsp+0xD0]
0000762f89bdb61f  vmovaps xmm15, [rsp+0xE0]
0000762f89bdb628  add rsp, 0xF0
0000762f89bdb62f  pop r11
0000762f89bdb631  pop r10
0000762f89bdb633  pop r9
0000762f89bdb635  pop r8
0000762f89bdb637  pop rsi
0000762f89bdb638  pop rdi
0000762f89bdb639  pop rdx
0000762f89bdb63a  pop rcx
0000762f89bdb63b  pop rax
0000762f89bdb63c  add rsp, 0x08
0000762f89bdb640  jmp 0x0000762F89BD666D
0000762f89bdb645  sub rsp, 0x08
0000762f89bdb649  push rax
0000762f89bdb64a  push rcx
0000762f89bdb64b  push rdx
0000762f89bdb64c  push rdi
0000762f89bdb64d  push rsi
0000762f89bdb64e  push r8
0000762f89bdb650  push r9
0000762f89bdb652  push r10
0000762f89bdb654  push r11
0000762f89bdb656  sub rsp, 0xF0
0000762f89bdb65d  vmovaps [rsp], xmm0
0000762f89bdb662  vmovaps [rsp+0x10], xmm1
0000762f89bdb668  vmovaps [rsp+0x20], xmm2
0000762f89bdb66e  vmovaps [rsp+0x30], xmm3
0000762f89bdb674  vmovaps [rsp+0x40], xmm4
0000762f89bdb67a  vmovaps [rsp+0x50], xmm5
0000762f89bdb680  vmovaps [rsp+0x60], xmm6
0000762f89bdb686  vmovaps [rsp+0x70], xmm7
0000762f89bdb68c  vmovaps [rsp+0x80], xmm8
0000762f89bdb695  vmovaps [rsp+0x90], xmm9
0000762f89bdb69e  vmovaps [rsp+0xA0], xmm10
0000762f89bdb6a7  vmovaps [rsp+0xB0], xmm11
0000762f89bdb6b0  vmovaps [rsp+0xC0], xmm12
0000762f89bdb6b9  vmovaps [rsp+0xD0], xmm13
0000762f89bdb6c2  vmovaps [rsp+0xE0], xmm15
0000762f89bdb6cb  sub rsp, 0x30
0000762f89bdb6cf  movaps [rsp], xmm14
0000762f89bdb6d4  movaps [rsp+0x10], xmm1
0000762f89bdb6d9  movaps [rsp+0x20], xmm7
0000762f89bdb6de  lea rdi, [rsp]
0000762f89bdb6e2  mov esi, 0x00
0000762f89bdb6e7  mov rax, 0x604D6F946530
0000762f89bdb6f1  call rax
0000762f89bdb6f3  movaps xmm14, [rsp]
0000762f89bdb6f8  add rsp, 0x30
0000762f89bdb6fc  vmovaps xmm0, [rsp]
0000762f89bdb701  vmovaps xmm1, [rsp+0x10]
0000762f89bdb707  vmovaps xmm2, [rsp+0x20]
0000762f89bdb70d  vmovaps xmm3, [rsp+0x30]
0000762f89bdb713  vmovaps xmm4, [rsp+0x40]
0000762f89bdb719  vmovaps xmm5, [rsp+0x50]
0000762f89bdb71f  vmovaps xmm6, [rsp+0x60]
0000762f89bdb725  vmovaps xmm7, [rsp+0x70]
0000762f89bdb72b  vmovaps xmm8, [rsp+0x80]
0000762f89bdb734  vmovaps xmm9, [rsp+0x90]
0000762f89bdb73d  vmovaps xmm10, [rsp+0xA0]
0000762f89bdb746  vmovaps xmm11, [rsp+0xB0]
0000762f89bdb74f  vmovaps xmm12, [rsp+0xC0]
0000762f89bdb758  vmovaps xmm13, [rsp+0xD0]
0000762f89bdb761  vmovaps xmm15, [rsp+0xE0]
0000762f89bdb76a  add rsp, 0xF0
0000762f89bdb771  pop r11
0000762f89bdb773  pop r10
0000762f89bdb775  pop r9
0000762f89bdb777  pop r8
0000762f89bdb779  pop rsi
0000762f89bdb77a  pop rdi
0000762f89bdb77b  pop rdx
0000762f89bdb77c  pop rcx
0000762f89bdb77d  pop rax
0000762f89bdb77e  add rsp, 0x08
0000762f89bdb782  jmp 0x0000762F89BD6690
0000762f89bdb787  sub rsp, 0x08
0000762f89bdb78b  push rax
0000762f89bdb78c  push rcx
0000762f89bdb78d  push rdx
0000762f89bdb78e  push rdi
0000762f89bdb78f  push rsi
0000762f89bdb790  push r8
0000762f89bdb792  push r9
0000762f89bdb794  push r10
0000762f89bdb796  push r11
0000762f89bdb798  sub rsp, 0xF0
0000762f89bdb79f  vmovaps [rsp], xmm0
0000762f89bdb7a4  vmovaps [rsp+0x10], xmm2
0000762f89bdb7aa  vmovaps [rsp+0x20], xmm3
0000762f89bdb7b0  vmovaps [rsp+0x30], xmm4
0000762f89bdb7b6  vmovaps [rsp+0x40], xmm5
0000762f89bdb7bc  vmovaps [rsp+0x50], xmm6
0000762f89bdb7c2  vmovaps [rsp+0x60], xmm7
0000762f89bdb7c8  vmovaps [rsp+0x70], xmm8
0000762f89bdb7ce  vmovaps [rsp+0x80], xmm9
0000762f89bdb7d7  vmovaps [rsp+0x90], xmm10
0000762f89bdb7e0  vmovaps [rsp+0xA0], xmm11
0000762f89bdb7e9  vmovaps [rsp+0xB0], xmm12
0000762f89bdb7f2  vmovaps [rsp+0xC0], xmm13
0000762f89bdb7fb  vmovaps [rsp+0xD0], xmm14
0000762f89bdb804  vmovaps [rsp+0xE0], xmm15
0000762f89bdb80d  sub rsp, 0x30
0000762f89bdb811  movaps [rsp], xmm1
0000762f89bdb815  movaps [rsp+0x10], xmm8
0000762f89bdb81b  movaps [rsp+0x20], xmm9
0000762f89bdb821  lea rdi, [rsp]
0000762f89bdb825  mov esi, 0x00
0000762f89bdb82a  mov rax, 0x604D6F946530
0000762f89bdb834  call rax
0000762f89bdb836  movaps xmm1, [rsp]
0000762f89bdb83a  add rsp, 0x30
0000762f89bdb83e  vmovaps xmm0, [rsp]
0000762f89bdb843  vmovaps xmm2, [rsp+0x10]
0000762f89bdb849  vmovaps xmm3, [rsp+0x20]
0000762f89bdb84f  vmovaps xmm4, [rsp+0x30]
0000762f89bdb855  vmovaps xmm5, [rsp+0x40]
0000762f89bdb85b  vmovaps xmm6, [rsp+0x50]
0000762f89bdb861  vmovaps xmm7, [rsp+0x60]
0000762f89bdb867  vmovaps xmm8, [rsp+0x70]
0000762f89bdb86d  vmovaps xmm9, [rsp+0x80]
0000762f89bdb876  vmovaps xmm10, [rsp+0x90]
0000762f89bdb87f  vmovaps xmm11, [rsp+0xA0]
0000762f89bdb888  vmovaps xmm12, [rsp+0xB0]
0000762f89bdb891  vmovaps xmm13, [rsp+0xC0]
0000762f89bdb89a  vmovaps xmm14, [rsp+0xD0]
0000762f89bdb8a3  vmovaps xmm15, [rsp+0xE0]
0000762f89bdb8ac  add rsp, 0xF0
0000762f89bdb8b3  pop r11
0000762f89bdb8b5  pop r10
0000762f89bdb8b7  pop r9
0000762f89bdb8b9  pop r8
0000762f89bdb8bb  pop rsi
0000762f89bdb8bc  pop rdi
0000762f89bdb8bd  pop rdx
0000762f89bdb8be  pop rcx
0000762f89bdb8bf  pop rax
0000762f89bdb8c0  add rsp, 0x08
0000762f89bdb8c4  jmp 0x0000762F89BD66B2
0000762f89bdb8c9  call 0x0000762F89AB3E40
0000762f89bdb8ce  jmp 0x0000762F89BD66C0
0000762f89bdb8d3  call 0x0000762F89A0C380
0000762f89bdb8d8  jmp 0x0000762F89BD66CA
0000762f89bdb8dd  call 0x0000762F89A0D600
0000762f89bdb8e2  jmp 0x0000762F89BD66D4
0000762f89bdb8e7  call 0x0000762F899FF540
0000762f89bdb8ec  jmp 0x0000762F89BD66DE
0000762f89bdb8f1  int3
0000762f89bdb8f2  nop [rax+rax*1], ax
0000762f89bdb8fb  nop [rax+rax*1], eax
0000762f89bdb900  mov eax, [r15+0x48]
0000762f89bdb904  lea r14d, [eax+0x01]
0000762f89bdb909  mov [rsp+0x10], r14d
0000762f89bdb90e  mov r14d, r14d
0000762f89bdb911  mov [r15+0x48], r14
0000762f89bdb915  xor eax, eax
0000762f89bdb917  mov r14d, [rsp+0x10]
0000762f89bdb91c  cmp r14d, 0x1F4
0000762f89bdb923  cmc
0000762f89bdb924  lahf
0000762f89bdb925  seto al
0000762f89bdb928  mov [r15+0x108], eax
0000762f89bdb92f  mov eax, [r15+0x108]
0000762f89bdb936  sahf
0000762f89bdb937  jnz 0x0000762F89BDB969
0000762f89bdb939  cmp dword ptr [r15+0x318], 0x00
0000762f89bdb941  jz 0x0000762F89BE1AB0
0000762f89bdb947  nop [rax+rax*1], ax
0000762f89bdb950  nop [rax+rax*1], eax
0000762f89bdb958  mov eax, 0x410450
0000762f89bdb95d  mov [r15+0x100], rax
0000762f89bdb964  jmp 0x0000762F899FE110
0000762f89bdb969  cmp dword ptr [r15+0x318], 0x00
0000762f89bdb971  jz 0x0000762F89BDB9A0
0000762f89bdb977  nop [rax+rax*1], ax
0000762f89bdb980  nop [rax+rax*1], eax
0000762f89bdb988  mov eax, 0x410274
0000762f89bdb98d  mov [r15+0x100], rax
0000762f89bdb994  jmp 0x0000762F899FE110
0000762f89bdb999  int3
0000762f89bdb99a  int3
0000762f89bdb99b  nop [rax+rax*1], eax
0000762f89bdb9a0  mov rax, [r15+0x40]
0000762f89bdb9a4  movaps xmm1, [r15+0x1D0]
0000762f89bdb9ac  vmovaps [rsp+0x10], xmm1
0000762f89bdb9b2  vmovaps xmm15, [rsp+0x10]
0000762f89bdb9b8  por xmm1, xmm15
0000762f89bdb9bd  movaps xmm14, [r15+0x1A0]
0000762f89bdb9c5  vmovaps [rsp+0x10], xmm14
0000762f89bdb9cb  vmovaps xmm13, [rsp+0x10]
0000762f89bdb9d1  por xmm14, xmm13
0000762f89bdb9d6  lea r14, [rax+0x30]
0000762f89bdb9da  mov r12, [r13+r14*1]
0000762f89bdb9df  lea r14, [rax+0x38]
0000762f89bdb9e3  mov r11, [r13+r14*1]
0000762f89bdb9e8  movq xmm13, r12
0000762f89bdb9ed  movq xmm12, r11
0000762f89bdb9f2  movq xmm13, xmm13
0000762f89bdb9f7  vmovaps [rsp+0x10], xmm13
0000762f89bdb9fd  movq xmm13, xmm13
0000762f89bdba02  movaps [r15+0x130], xmm13
0000762f89bdba0a  movq xmm12, xmm12
0000762f89bdba0f  vmovaps [rsp+0x20], xmm12
0000762f89bdba15  movq xmm12, xmm12
0000762f89bdba1a  movaps [r15+0x280], xmm12
0000762f89bdba22  movaps xmm13, [r15+0x270]
0000762f89bdba2a  vmovaps [rsp+0x30], xmm13
0000762f89bdba30  vmovaps xmm12, [rsp+0x30]
0000762f89bdba36  por xmm13, xmm12
0000762f89bdba3b  lea r14, [rax+0x20]
0000762f89bdba3f  mov r12, [r13+r14*1]
0000762f89bdba44  lea r14, [rax+0x28]
0000762f89bdba48  mov r11, [r13+r14*1]
0000762f89bdba4d  movq xmm12, r12
0000762f89bdba52  movq xmm11, r11
0000762f89bdba57  movq xmm12, xmm12
0000762f89bdba5c  vmovaps [rsp+0x30], xmm12
0000762f89bdba62  movq xmm12, xmm12
0000762f89bdba67  movaps [r15+0x150], xmm12
0000762f89bdba6f  movq xmm11, xmm11
0000762f89bdba74  vmovaps [rsp+0x40], xmm11
0000762f89bdba7a  movq xmm11, xmm11
0000762f89bdba7f  movaps [r15+0x140], xmm11
0000762f89bdba87  lea r14, [rax+0x10]
0000762f89bdba8b  mov r12, [r13+r14*1]
0000762f89bdba90  lea r14, [rax+0x18]
0000762f89bdba94  mov r11, [r13+r14*1]
0000762f89bdba99  movq xmm12, r12
0000762f89bdba9e  movq xmm11, r11
0000762f89bdbaa3  movq xmm12, xmm12
0000762f89bdbaa8  vmovaps [rsp+0x50], xmm12
0000762f89bdbaae  movq xmm12, xmm12
0000762f89bdbab3  movaps [r15+0x170], xmm12
0000762f89bdbabb  movq xmm11, xmm11
0000762f89bdbac0  vmovaps [rsp+0x60], xmm11
0000762f89bdbac6  movq xmm11, xmm11
0000762f89bdbacb  movaps [r15+0x160], xmm11
0000762f89bdbad3  mov r14, [r13+rax*1]
0000762f89bdbad8  vmovq xmm12, r14
0000762f89bdbadd  vpbroadcastq xmm12, xmm12
0000762f89bdbae2  lea r14, [rax+0x08]
0000762f89bdbae6  mov rax, [r13+r14*1]
0000762f89bdbaeb  movq xmm11, rax
0000762f89bdbaf0  movaps [r15+0x230], xmm11
0000762f89bdbaf8  mov rax, [r15+0xF8]
0000762f89bdbaff  lea r14, [rax+0x50]
0000762f89bdbb03  movups xmm11, [r13+r14*1]
0000762f89bdbb09  lea r14, [rax+0x60]
0000762f89bdbb0d  movups xmm10, [r13+r14*1]
0000762f89bdbb13  lea r14, [rax+0x30]
0000762f89bdbb17  movups xmm9, [r13+r14*1]
0000762f89bdbb1d  mov r14, [r15+0x50]
0000762f89bdbb21  mov [r15+0x60], r14
0000762f89bdbb25  mov qword ptr [r15+0x58], 0x40
0000762f89bdbb2d  movaps xmm8, xmm12
0000762f89bdbb31  mulpd xmm8, xmm15
0000762f89bdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000762f89bdbb3c  ptest xmm7, xmm7
0000762f89bdbb41  jnz 0x0000762F89BDC96A
0000762f89bdbb47  movq xmm15, qword ptr [r15+0x230]
0000762f89bdbb50  vmovaps [rsp+0x70], xmm15
0000762f89bdbb56  vpermilpd xmm15, xmm15, 0x00
0000762f89bdbb5c  movaps xmm7, xmm9
0000762f89bdbb60  mulpd xmm7, xmm15
0000762f89bdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000762f89bdbb6a  ptest xmm6, xmm6
0000762f89bdbb6f  jnz 0x0000762F89BDCAAE
0000762f89bdbb75  vxorps xmm15, xmm15, xmm15
0000762f89bdbb7a  vpbroadcastq xmm15, xmm15
0000762f89bdbb7f  movaps xmm9, xmm12
0000762f89bdbb83  mulpd xmm9, xmm10
0000762f89bdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000762f89bdbb8e  ptest xmm6, xmm6
0000762f89bdbb93  jnz 0x0000762F89BDCBF0
0000762f89bdbb99  movaps xmm10, xmm12
0000762f89bdbb9d  mulpd xmm10, xmm11
0000762f89bdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000762f89bdbba8  ptest xmm6, xmm6
0000762f89bdbbad  jnz 0x0000762F89BDCD34
0000762f89bdbbb3  movaps xmm11, [r15+0x1F0]
0000762f89bdbbbb  movaps xmm6, xmm12
0000762f89bdbbbf  mulpd xmm6, xmm11
0000762f89bdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000762f89bdbbc9  ptest xmm5, xmm5
0000762f89bdbbce  jnz 0x0000762F89BDCE78
0000762f89bdbbd4  movaps xmm12, [r15+0x2A0]
0000762f89bdbbdc  vmovaps [rsp+0x80], xmm12
0000762f89bdbbe5  vmovaps xmm11, [rsp+0x80]
0000762f89bdbbee  por xmm12, xmm11
0000762f89bdbbf3  movaps xmm11, [r15+0x250]
0000762f89bdbbfb  vmovaps [rsp+0x80], xmm11
0000762f89bdbc04  vmovaps xmm5, [rsp+0x80]
0000762f89bdbc0d  por xmm11, xmm5
0000762f89bdbc12  vmovaps xmm4, [rsp+0x70]
0000762f89bdbc18  vpermilpd xmm4, xmm4, 0x00
0000762f89bdbc1e  movaps xmm3, xmm5
0000762f89bdbc21  mulpd xmm3, xmm4
0000762f89bdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000762f89bdbc2a  ptest xmm2, xmm2
0000762f89bdbc2f  jnz 0x0000762F89BDCFBA
0000762f89bdbc35  mov [rsp+0x80], rax
0000762f89bdbc3d  xor eax, eax
0000762f89bdbc3f  mov r12d, 0x40
0000762f89bdbc45  mov r11d, 0x200
0000762f89bdbc4b  cmp r12, r11
0000762f89bdbc4e  cmc
0000762f89bdbc4f  lahf
0000762f89bdbc50  seto al
0000762f89bdbc53  mov [r15+0x108], eax
0000762f89bdbc5a  movaps xmm5, xmm8
0000762f89bdbc5e  addpd xmm5, xmm15
0000762f89bdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000762f89bdbc68  ptest xmm4, xmm4
0000762f89bdbc6d  jnz 0x0000762F89BDD0FA
0000762f89bdbc73  movaps xmm8, [r15+0x1B0]
0000762f89bdbc7b  movaps xmm4, xmm9
0000762f89bdbc7f  addpd xmm4, xmm8
0000762f89bdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000762f89bdbc89  ptest xmm2, xmm2
0000762f89bdbc8e  jnz 0x0000762F89BDD23C
0000762f89bdbc94  movaps xmm9, xmm10
0000762f89bdbc98  addpd xmm9, xmm8
0000762f89bdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000762f89bdbca3  ptest xmm2, xmm2
0000762f89bdbca8  jnz 0x0000762F89BDD37E
0000762f89bdbcae  movaps xmm10, [r15+0x2F0]
0000762f89bdbcb6  vmovaps [rsp+0x90], xmm10
0000762f89bdbcbf  vmovaps xmm8, [rsp+0x90]
0000762f89bdbcc8  por xmm10, xmm8
0000762f89bdbccd  movaps xmm8, [r15+0x2E0]
0000762f89bdbcd5  vmovaps [rsp+0x90], xmm8
0000762f89bdbcde  vmovaps xmm2, [rsp+0x90]
0000762f89bdbce7  por xmm8, xmm2
0000762f89bdbcec  movaps xmm2, [r15+0x2D0]
0000762f89bdbcf4  vmovaps [rsp+0x90], xmm2
0000762f89bdbcfd  vmovaps [rsp+0xA0], xmm1
0000762f89bdbd06  vmovaps xmm1, [rsp+0x90]
0000762f89bdbd0f  por xmm2, xmm1
0000762f89bdbd13  movaps xmm1, [r15+0x200]
0000762f89bdbd1b  vmovaps [rsp+0x90], xmm1
0000762f89bdbd24  vmovaps [rsp+0xB0], xmm15
0000762f89bdbd2d  vmovaps xmm15, [rsp+0x90]
0000762f89bdbd36  por xmm1, xmm15
0000762f89bdbd3b  movaps xmm15, [r15+0x1C0]
0000762f89bdbd43  vmovaps [rsp+0x90], xmm15
0000762f89bdbd4c  vmovaps [rsp+0xC0], xmm1
0000762f89bdbd55  vmovaps xmm1, [rsp+0x90]
0000762f89bdbd5e  por xmm15, xmm1
0000762f89bdbd63  movaps xmm1, [r15+0x190]
0000762f89bdbd6b  vmovaps [rsp+0x90], xmm1
0000762f89bdbd74  vmovaps [rsp+0xD0], xmm15
0000762f89bdbd7d  vmovaps xmm15, [rsp+0x90]
0000762f89bdbd86  por xmm1, xmm15
0000762f89bdbd8b  movaps xmm15, [r15+0x300]
0000762f89bdbd93  vmovaps [rsp+0x90], xmm15
0000762f89bdbd9c  vmovaps [rsp+0xE0], xmm1
0000762f89bdbda5  vmovaps xmm1, [rsp+0x90]
0000762f89bdbdae  por xmm15, xmm1
0000762f89bdbdb3  mov rax, [rsp+0x80]
0000762f89bdbdbb  lea r12, [rax+0xA0]
0000762f89bdbdc2  movups xmm1, [r13+r12*1]
0000762f89bdbdc8  lea r12, [rax+0xB0]
0000762f89bdbdcf  vmovaps [rsp+0x80], xmm1
0000762f89bdbdd8  movups xmm1, [r13+r12*1]
0000762f89bdbdde  vmovaps [rsp+0x90], xmm1
0000762f89bdbde7  vmovaps [rsp+0xF0], xmm15
0000762f89bdbdf0  vmovaps xmm15, [rsp+0xB0]
0000762f89bdbdf9  vmovaps [rsp+0xB0], xmm14
0000762f89bdbe02  movaps xmm1, xmm6
0000762f89bdbe05  addpd xmm1, xmm15
0000762f89bdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000762f89bdbe0f  ptest xmm14, xmm14
0000762f89bdbe15  jnz 0x0000762F89BDD4D6
0000762f89bdbe1b  lea r12, [rax+0xF0]
0000762f89bdbe22  movups xmm15, [r13+r12*1]
0000762f89bdbe28  movaps xmm14, xmm4
0000762f89bdbe2c  addpd xmm14, xmm3
0000762f89bdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000762f89bdbe37  ptest xmm6, xmm6
0000762f89bdbe3c  jnz 0x0000762F89BDD621
0000762f89bdbe42  movaps xmm6, xmm9
0000762f89bdbe46  addpd xmm6, xmm7
0000762f89bdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000762f89bdbe4f  ptest xmm4, xmm4
0000762f89bdbe54  jnz 0x0000762F89BDD763
0000762f89bdbe5a  vmovaps xmm9, [rsp+0x70]
0000762f89bdbe60  vpermilpd xmm9, xmm9, 0x00
0000762f89bdbe66  vmovaps xmm4, [rsp+0x90]
0000762f89bdbe6f  movaps xmm7, xmm4
0000762f89bdbe72  mulpd xmm7, xmm9
0000762f89bdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000762f89bdbe7c  ptest xmm3, xmm3
0000762f89bdbe81  jnz 0x0000762F89BDD8A4
0000762f89bdbe87  vmovaps xmm9, [rsp+0x50]
0000762f89bdbe8d  vpermilpd xmm9, xmm9, 0x00
0000762f89bdbe93  movaps xmm4, xmm15
0000762f89bdbe97  mulpd xmm4, xmm9
0000762f89bdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000762f89bdbea1  ptest xmm3, xmm3
0000762f89bdbea6  jnz 0x0000762F89BDD9E5
0000762f89bdbeac  lea r12, [rax+0xE0]
0000762f89bdbeb3  movups xmm15, [r13+r12*1]
0000762f89bdbeb9  vmovaps xmm9, [rsp+0x70]
0000762f89bdbebf  vpermilpd xmm9, xmm9, 0x00
0000762f89bdbec5  vmovaps [rsp+0x70], xmm1
0000762f89bdbecb  vmovaps xmm1, [rsp+0x80]
0000762f89bdbed4  vmovaps [rsp+0x80], xmm15
0000762f89bdbedd  movaps xmm3, xmm1
0000762f89bdbee0  mulpd xmm3, xmm9
0000762f89bdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000762f89bdbeea  ptest xmm15, xmm15
0000762f89bdbef0  jnz 0x0000762F89BDDB31
0000762f89bdbef6  vmovaps xmm1, [rsp+0xF0]
0000762f89bdbeff  vmovaps xmm15, [rsp+0xF0]
0000762f89bdbf08  por xmm1, xmm15
0000762f89bdbf0d  movaps [r15+0x300], xmm1
0000762f89bdbf15  vmovaps xmm15, [rsp+0xE0]
0000762f89bdbf1e  vmovaps xmm9, [rsp+0xE0]
0000762f89bdbf27  por xmm15, xmm9
0000762f89bdbf2c  movaps [r15+0x190], xmm15
0000762f89bdbf34  vmovaps xmm9, [rsp+0x50]
0000762f89bdbf3a  vpermilpd xmm9, xmm9, 0x00
0000762f89bdbf40  vmovaps [rsp+0x90], xmm1
0000762f89bdbf49  vmovaps [rsp+0xE0], xmm15
0000762f89bdbf52  vmovaps xmm15, [rsp+0x80]
0000762f89bdbf5b  vmovaps [rsp+0x80], xmm14
0000762f89bdbf64  movaps xmm1, xmm15
0000762f89bdbf68  mulpd xmm1, xmm9
0000762f89bdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000762f89bdbf72  ptest xmm14, xmm14
0000762f89bdbf78  jnz 0x0000762F89BDDC72
0000762f89bdbf7e  lea r12, [rax+0x90]
0000762f89bdbf85  movups xmm15, [r13+r12*1]
0000762f89bdbf8b  vmovaps xmm14, [rsp+0xD0]
0000762f89bdbf94  vmovaps xmm9, [rsp+0xD0]
0000762f89bdbf9d  por xmm14, xmm9
0000762f89bdbfa2  movaps [r15+0x1C0], xmm14
0000762f89bdbfaa  vmovaps xmm9, [rsp+0xC0]
0000762f89bdbfb3  vmovaps [rsp+0xD0], xmm1
0000762f89bdbfbc  vmovaps xmm1, [rsp+0xC0]
0000762f89bdbfc5  por xmm9, xmm1
0000762f89bdbfca  movaps [r15+0x200], xmm9
0000762f89bdbfd2  vmovaps [rsp+0xC0], xmm2
0000762f89bdbfdb  vmovaps xmm1, [rsp+0xC0]
0000762f89bdbfe4  por xmm2, xmm1
0000762f89bdbfe8  movaps [r15+0x2D0], xmm2
0000762f89bdbff0  vmovaps [rsp+0xC0], xmm8
0000762f89bdbff9  vmovaps xmm1, [rsp+0xC0]
0000762f89bdc002  por xmm8, xmm1
0000762f89bdc007  movaps [r15+0x2E0], xmm8
0000762f89bdc00f  vmovaps [rsp+0xC0], xmm15
0000762f89bdc018  movaps xmm1, xmm5
0000762f89bdc01b  addpd xmm1, xmm7
0000762f89bdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000762f89bdc024  ptest xmm15, xmm15
0000762f89bdc02a  jnz 0x0000762F89BDDDBE
0000762f89bdc030  vmovaps xmm15, [rsp+0x50]
0000762f89bdc036  vpermilpd xmm15, xmm15, 0x00
0000762f89bdc03c  vmovaps xmm5, [rsp+0xC0]
0000762f89bdc045  vmovaps [rsp+0xC0], xmm1
0000762f89bdc04e  movaps xmm7, xmm5
0000762f89bdc051  mulpd xmm7, xmm15
0000762f89bdc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000762f89bdc05b  ptest xmm1, xmm1
0000762f89bdc060  jnz 0x0000762F89BDDEFE
0000762f89bdc066  lea r12, [rax+0x80]
0000762f89bdc06d  movups xmm1, [r13+r12*1]
0000762f89bdc073  vmovaps xmm5, [rsp+0x70]
0000762f89bdc079  vmovaps [rsp+0x70], xmm1
0000762f89bdc07f  movaps xmm15, xmm5
0000762f89bdc083  addpd xmm15, xmm3
0000762f89bdc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000762f89bdc08e  ptest xmm1, xmm1
0000762f89bdc093  jnz 0x0000762F89BDE049
0000762f89bdc099  vmovaps xmm5, [rsp+0x80]
0000762f89bdc0a2  movaps xmm1, xmm5
0000762f89bdc0a5  addpd xmm1, xmm4
0000762f89bdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000762f89bdc0ae  ptest xmm3, xmm3
0000762f89bdc0b3  jnz 0x0000762F89BDE18B
0000762f89bdc0b9  vmovaps [rsp+0x80], xmm10
0000762f89bdc0c2  vmovaps xmm5, [rsp+0x80]
0000762f89bdc0cb  por xmm10, xmm5
0000762f89bdc0d0  movaps [r15+0x2F0], xmm10
0000762f89bdc0d8  vmovaps xmm5, [rsp+0x50]
0000762f89bdc0de  vpermilpd xmm5, xmm5, 0x00
0000762f89bdc0e4  vmovaps xmm3, [rsp+0x70]
0000762f89bdc0ea  vmovaps [rsp+0x50], xmm1
0000762f89bdc0f0  movaps xmm4, xmm3
0000762f89bdc0f3  mulpd xmm4, xmm5
0000762f89bdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000762f89bdc0fc  ptest xmm1, xmm1
0000762f89bdc101  jnz 0x0000762F89BDE2CB
0000762f89bdc107  lea r12, [rax+0xD0]
0000762f89bdc10e  movups xmm1, [r13+r12*1]
0000762f89bdc114  vmovaps xmm3, [rsp+0xD0]
0000762f89bdc11d  vmovaps [rsp+0x70], xmm1
0000762f89bdc123  movaps xmm5, xmm6
0000762f89bdc126  addpd xmm5, xmm3
0000762f89bdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000762f89bdc12f  ptest xmm1, xmm1
0000762f89bdc134  jnz 0x0000762F89BDE415
0000762f89bdc13a  vmovaps xmm1, [rsp+0x60]
0000762f89bdc140  vpermilpd xmm1, xmm1, 0x00
0000762f89bdc146  movaps xmm6, xmm9
0000762f89bdc14a  mulpd xmm6, xmm1
0000762f89bdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000762f89bdc153  ptest xmm3, xmm3
0000762f89bdc158  jnz 0x0000762F89BDE555
0000762f89bdc15e  movaps [r15+0x260], xmm6
0000762f89bdc166  vxorps xmm1, xmm1, xmm1
0000762f89bdc16a  vpbroadcastq xmm1, xmm1
0000762f89bdc16f  movaps [r15+0x1B0], xmm1
0000762f89bdc177  vmovaps xmm1, [rsp+0x60]
0000762f89bdc17d  vpermilpd xmm1, xmm1, 0x00
0000762f89bdc183  vmovaps xmm3, [rsp+0x70]
0000762f89bdc189  vmovaps [rsp+0x70], xmm15
0000762f89bdc18f  movaps xmm9, xmm3
0000762f89bdc193  mulpd xmm9, xmm1
0000762f89bdc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000762f89bdc19e  ptest xmm15, xmm15
0000762f89bdc1a4  jnz 0x0000762F89BDE696
0000762f89bdc1aa  lea r12, [rax+0xC0]
0000762f89bdc1b1  movups xmm1, [r13+r12*1]
0000762f89bdc1b7  vmovaps xmm3, [rsp+0xC0]
0000762f89bdc1c0  vmovaps [rsp+0x80], xmm1
0000762f89bdc1c9  movaps xmm15, xmm3
0000762f89bdc1cd  addpd xmm15, xmm7
0000762f89bdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000762f89bdc1d8  ptest xmm1, xmm1
0000762f89bdc1dd  jnz 0x0000762F89BDE7E2
0000762f89bdc1e3  vmovaps [rsp+0xC0], xmm13
0000762f89bdc1ec  vmovaps xmm1, [rsp+0xC0]
0000762f89bdc1f5  por xmm13, xmm1
0000762f89bdc1fa  movaps [r15+0x270], xmm13
0000762f89bdc202  vmovaps xmm1, [rsp+0xB0]
0000762f89bdc20b  vmovaps xmm7, [rsp+0xB0]
0000762f89bdc214  por xmm1, xmm7
0000762f89bdc218  movaps [r15+0x1A0], xmm1
0000762f89bdc220  vmovaps xmm1, [rsp+0x60]
0000762f89bdc226  vpermilpd xmm1, xmm1, 0x00
0000762f89bdc22c  vmovaps [rsp+0xB0], xmm1
0000762f89bdc235  vmovaps xmm1, [rsp+0x80]
0000762f89bdc23e  vmovaps [rsp+0x80], xmm15
0000762f89bdc247  vmovaps xmm15, [rsp+0xB0]
0000762f89bdc250  vmovaps [rsp+0xB0], xmm14
0000762f89bdc259  movaps xmm3, xmm1
0000762f89bdc25c  mulpd xmm3, xmm15
0000762f89bdc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000762f89bdc266  ptest xmm14, xmm14
0000762f89bdc26c  jnz 0x0000762F89BDE924
0000762f89bdc272  lea r12, [rax+0x20]
0000762f89bdc276  movups xmm1, [r13+r12*1]
0000762f89bdc27c  movaps [r15+0x110], xmm1
0000762f89bdc284  vmovaps xmm14, [rsp+0x70]
0000762f89bdc28a  vmovaps [rsp+0x70], xmm1
0000762f89bdc290  movaps xmm15, xmm14
0000762f89bdc294  addpd xmm15, xmm4
0000762f89bdc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000762f89bdc29f  ptest xmm1, xmm1
0000762f89bdc2a4  jnz 0x0000762F89BDEA6F
0000762f89bdc2aa  vmovaps xmm1, [rsp+0x60]
0000762f89bdc2b0  vpermilpd xmm1, xmm1, 0x00
0000762f89bdc2b6  movaps xmm14, xmm2
0000762f89bdc2ba  mulpd xmm14, xmm1
0000762f89bdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000762f89bdc2c5  ptest xmm4, xmm4
0000762f89bdc2ca  jnz 0x0000762F89BDEBB2
0000762f89bdc2d0  vmovaps xmm4, [rsp+0x50]
0000762f89bdc2d6  movaps xmm1, xmm4
0000762f89bdc2d9  addpd xmm1, xmm9
0000762f89bdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000762f89bdc2e3  ptest xmm2, xmm2
0000762f89bdc2e8  jnz 0x0000762F89BDECF4
0000762f89bdc2ee  vmovaps xmm9, [rsp+0x30]
0000762f89bdc2f4  vpermilpd xmm9, xmm9, 0x00
0000762f89bdc2fa  vmovaps xmm2, [rsp+0x70]
0000762f89bdc300  vmovaps [rsp+0x50], xmm1
0000762f89bdc306  movaps xmm4, xmm2
0000762f89bdc309  mulpd xmm4, xmm9
0000762f89bdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000762f89bdc313  ptest xmm1, xmm1
0000762f89bdc318  jnz 0x0000762F89BDEE35
0000762f89bdc31e  vmovaps xmm1, [rsp+0x30]
0000762f89bdc324  vpermilpd xmm1, xmm1, 0x00
0000762f89bdc32a  vmovaps xmm2, [rsp+0x90]
0000762f89bdc333  vmovaps [rsp+0x60], xmm15
0000762f89bdc339  movaps xmm9, xmm2
0000762f89bdc33d  mulpd xmm9, xmm1
0000762f89bdc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000762f89bdc348  ptest xmm15, xmm15
0000762f89bdc34e  jnz 0x0000762F89BDEF76
0000762f89bdc354  vmovaps xmm15, [rsp+0x80]
0000762f89bdc35d  movaps xmm1, xmm15
0000762f89bdc361  addpd xmm1, xmm6
0000762f89bdc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000762f89bdc36a  ptest xmm2, xmm2
0000762f89bdc36f  jnz 0x0000762F89BDF0B8
0000762f89bdc375  movaps xmm15, xmm5
0000762f89bdc379  addpd xmm15, xmm3
0000762f89bdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000762f89bdc384  ptest xmm6, xmm6
0000762f89bdc389  jnz 0x0000762F89BDF1F9
0000762f89bdc38f  vmovaps xmm6, [rsp+0x30]
0000762f89bdc395  vpermilpd xmm6, xmm6, 0x00
0000762f89bdc39b  movaps xmm5, xmm8
0000762f89bdc39f  mulpd xmm5, xmm6
0000762f89bdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000762f89bdc3a8  ptest xmm3, xmm3
0000762f89bdc3ad  jnz 0x0000762F89BDF33B
0000762f89bdc3b3  vmovaps xmm8, [rsp+0x30]
0000762f89bdc3b9  vpermilpd xmm8, xmm8, 0x00
0000762f89bdc3bf  movaps xmm6, xmm10
0000762f89bdc3c3  mulpd xmm6, xmm8
0000762f89bdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000762f89bdc3cd  ptest xmm3, xmm3
0000762f89bdc3d2  jnz 0x0000762F89BDF47C
0000762f89bdc3d8  vmovaps xmm8, [rsp+0x60]
0000762f89bdc3de  movaps xmm10, xmm8
0000762f89bdc3e2  addpd xmm10, xmm14
0000762f89bdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000762f89bdc3ed  ptest xmm3, xmm3
0000762f89bdc3f2  jnz 0x0000762F89BDF5BE
0000762f89bdc3f8  vmovaps xmm8, [rsp+0x50]
0000762f89bdc3fe  movaps xmm14, xmm8
0000762f89bdc402  addpd xmm14, xmm4
0000762f89bdc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000762f89bdc40d  ptest xmm3, xmm3
0000762f89bdc412  jnz 0x0000762F89BDF702
0000762f89bdc418  vmovaps xmm8, [rsp+0x40]
0000762f89bdc41e  vpermilpd xmm8, xmm8, 0x00
0000762f89bdc424  movaps xmm4, xmm13
0000762f89bdc428  mulpd xmm4, xmm8
0000762f89bdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000762f89bdc432  ptest xmm3, xmm3
0000762f89bdc437  jnz 0x0000762F89BDF845
0000762f89bdc43d  movaps xmm13, xmm15
0000762f89bdc441  addpd xmm13, xmm9
0000762f89bdc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000762f89bdc44c  ptest xmm8, xmm8
0000762f89bdc452  jnz 0x0000762F89BDF987
0000762f89bdc458  movaps xmm15, xmm1
0000762f89bdc45c  addpd xmm15, xmm5
0000762f89bdc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000762f89bdc467  ptest xmm9, xmm9
0000762f89bdc46d  jnz 0x0000762F89BDFACB
0000762f89bdc473  vmovaps [rsp+0x30], xmm11
0000762f89bdc479  vmovaps xmm1, [rsp+0x30]
0000762f89bdc47f  por xmm11, xmm1
0000762f89bdc484  movaps [r15+0x250], xmm11
0000762f89bdc48c  vmovaps [rsp+0x30], xmm12
0000762f89bdc492  vmovaps xmm1, [rsp+0x30]
0000762f89bdc498  por xmm12, xmm1
0000762f89bdc49d  movaps [r15+0x2A0], xmm12
0000762f89bdc4a5  vmovaps xmm1, [rsp+0xA0]
0000762f89bdc4ae  vmovaps xmm11, [rsp+0xA0]
0000762f89bdc4b7  por xmm1, xmm11
0000762f89bdc4bc  movaps [r15+0x1D0], xmm1
0000762f89bdc4c4  lea r12, [rax+0x40]
0000762f89bdc4c8  movups xmm1, [r13+r12*1]
0000762f89bdc4ce  movaps [r15+0x2C0], xmm1
0000762f89bdc4d6  vmovaps xmm11, [rsp+0x40]
0000762f89bdc4dc  vpermilpd xmm11, xmm11, 0x00
0000762f89bdc4e2  vmovaps xmm8, [rsp+0xE0]
0000762f89bdc4eb  movaps xmm9, xmm8
0000762f89bdc4ef  mulpd xmm9, xmm11
0000762f89bdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000762f89bdc4fa  ptest xmm5, xmm5
0000762f89bdc4ff  jnz 0x0000762F89BDFC17
0000762f89bdc505  movaps xmm11, xmm10
0000762f89bdc509  addpd xmm11, xmm6
0000762f89bdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000762f89bdc514  ptest xmm8, xmm8
0000762f89bdc51a  jnz 0x0000762F89BDFD5B
0000762f89bdc520  movaps xmm10, xmm14
0000762f89bdc524  addpd xmm10, xmm4
0000762f89bdc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000762f89bdc52f  ptest xmm8, xmm8
0000762f89bdc535  jnz 0x0000762F89BDFE9E
0000762f89bdc53b  vmovaps xmm14, [rsp+0x40]
0000762f89bdc541  vpermilpd xmm14, xmm14, 0x00
0000762f89bdc547  movaps xmm8, xmm1
0000762f89bdc54b  mulpd xmm8, xmm14
0000762f89bdc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000762f89bdc556  ptest xmm6, xmm6
0000762f89bdc55b  jnz 0x0000762F89BDFFE1
0000762f89bdc561  movaps xmm1, [r15+0x2B0]
0000762f89bdc569  vmovaps xmm14, [rsp+0x40]
0000762f89bdc56f  vpermilpd xmm14, xmm14, 0x00
0000762f89bdc575  movaps xmm6, xmm1
0000762f89bdc578  mulpd xmm6, xmm14
0000762f89bdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000762f89bdc582  ptest xmm5, xmm5
0000762f89bdc587  jnz 0x0000762F89BE0124
0000762f89bdc58d  vmovaps xmm1, [rsp+0x10]
0000762f89bdc593  vpermilpd xmm1, xmm1, 0x00
0000762f89bdc599  movaps xmm14, xmm12
0000762f89bdc59d  mulpd xmm14, xmm1
0000762f89bdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000762f89bdc5a8  ptest xmm5, xmm5
0000762f89bdc5ad  jnz 0x0000762F89BE0265
0000762f89bdc5b3  movaps xmm1, xmm13
0000762f89bdc5b7  addpd xmm1, xmm9
0000762f89bdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000762f89bdc5c1  ptest xmm12, xmm12
0000762f89bdc5c7  jnz 0x0000762F89BE03A8
0000762f89bdc5cd  vmovaps xmm13, [rsp+0x10]
0000762f89bdc5d3  vpermilpd xmm13, xmm13, 0x00
0000762f89bdc5d9  movaps xmm12, xmm7
0000762f89bdc5dd  mulpd xmm12, xmm13
0000762f89bdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000762f89bdc5e8  ptest xmm9, xmm9
0000762f89bdc5ee  jnz 0x0000762F89BE04EA
0000762f89bdc5f4  movaps xmm13, xmm15
0000762f89bdc5f8  addpd xmm13, xmm8
0000762f89bdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000762f89bdc603  ptest xmm9, xmm9
0000762f89bdc609  jnz 0x0000762F89BE062D
0000762f89bdc60f  movaps xmm15, [r15+0x290]
0000762f89bdc617  vmovaps xmm9, [rsp+0x10]
0000762f89bdc61d  vpermilpd xmm9, xmm9, 0x00
0000762f89bdc623  movaps xmm8, xmm15
0000762f89bdc627  mulpd xmm8, xmm9
0000762f89bdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000762f89bdc632  ptest xmm7, xmm7
0000762f89bdc637  jnz 0x0000762F89BE0771
0000762f89bdc63d  movaps xmm15, xmm11
0000762f89bdc641  addpd xmm15, xmm6
0000762f89bdc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000762f89bdc64c  ptest xmm9, xmm9
0000762f89bdc652  jnz 0x0000762F89BE08B5
0000762f89bdc658  movaps xmm11, [r15+0x1E0]
0000762f89bdc660  vmovaps xmm9, [rsp+0x10]
0000762f89bdc666  vpermilpd xmm9, xmm9, 0x00
0000762f89bdc66c  movaps xmm7, xmm11
0000762f89bdc670  mulpd xmm7, xmm9
0000762f89bdc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000762f89bdc67a  ptest xmm6, xmm6
0000762f89bdc67f  jnz 0x0000762F89BE09F8
0000762f89bdc685  movaps xmm11, xmm10
0000762f89bdc689  addpd xmm11, xmm14
0000762f89bdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000762f89bdc694  ptest xmm9, xmm9
0000762f89bdc69a  jnz 0x0000762F89BE0B3A
0000762f89bdc6a0  lea r12, [rax+0x70]
0000762f89bdc6a4  movups xmm14, [r13+r12*1]
0000762f89bdc6aa  movaps [r15+0x240], xmm14
0000762f89bdc6b2  movaps xmm10, xmm1
0000762f89bdc6b6  addpd xmm10, xmm12
0000762f89bdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000762f89bdc6c1  ptest xmm9, xmm9
0000762f89bdc6c7  jnz 0x0000762F89BE0C88
0000762f89bdc6cd  movaps [r15+0x170], xmm10
0000762f89bdc6d5  vmovaps xmm1, [rsp+0x20]
0000762f89bdc6db  vpermilpd xmm1, xmm1, 0x00
0000762f89bdc6e1  movaps xmm12, xmm14
0000762f89bdc6e5  mulpd xmm12, xmm1
0000762f89bdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000762f89bdc6f0  ptest xmm9, xmm9
0000762f89bdc6f6  jnz 0x0000762F89BE0DCB
0000762f89bdc6fc  vmovaps xmm1, [rsp+0x20]
0000762f89bdc702  vpermilpd xmm1, xmm1, 0x00
0000762f89bdc708  vmovaps xmm9, [rsp+0xB0]
0000762f89bdc711  movaps xmm14, xmm9
0000762f89bdc715  mulpd xmm14, xmm1
0000762f89bdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000762f89bdc720  ptest xmm6, xmm6
0000762f89bdc725  jnz 0x0000762F89BE0F0E
0000762f89bdc72b  movaps [r15+0x180], xmm14
0000762f89bdc733  movaps xmm1, xmm13
0000762f89bdc737  addpd xmm1, xmm8
0000762f89bdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000762f89bdc741  ptest xmm9, xmm9
0000762f89bdc747  jnz 0x0000762F89BE1051
0000762f89bdc74d  movaps [r15+0x210], xmm1
0000762f89bdc755  movups xmm13, [r13+rax*1]
0000762f89bdc75b  lea r12, [rax+0x10]
0000762f89bdc75f  movups xmm9, [r13+r12*1]
0000762f89bdc765  movaps [r15+0x230], xmm9
0000762f89bdc76d  movaps xmm8, xmm15
0000762f89bdc771  addpd xmm8, xmm7
0000762f89bdc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000762f89bdc77c  ptest xmm6, xmm6
0000762f89bdc781  jnz 0x0000762F89BE11A7
0000762f89bdc787  movaps [r15+0x130], xmm8
0000762f89bdc78f  vmovaps xmm15, [rsp+0x20]
0000762f89bdc795  vpermilpd xmm15, xmm15, 0x00
0000762f89bdc79b  movaps xmm7, xmm9
0000762f89bdc79f  mulpd xmm7, xmm15
0000762f89bdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000762f89bdc7a9  ptest xmm6, xmm6
0000762f89bdc7ae  jnz 0x0000762F89BE12EA
0000762f89bdc7b4  movaps [r15+0x220], xmm7
0000762f89bdc7bc  vmovaps xmm15, [rsp+0x20]
0000762f89bdc7c2  vpermilpd xmm15, xmm15, 0x00
0000762f89bdc7c8  movaps xmm9, xmm13
0000762f89bdc7cc  mulpd xmm9, xmm15
0000762f89bdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000762f89bdc7d7  ptest xmm6, xmm6
0000762f89bdc7dc  jnz 0x0000762F89BE142C
0000762f89bdc7e2  movaps xmm15, xmm11
0000762f89bdc7e6  addpd xmm15, xmm12
0000762f89bdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000762f89bdc7f1  ptest xmm13, xmm13
0000762f89bdc7f7  jnz 0x0000762F89BE1570
0000762f89bdc7fd  movaps [r15+0x140], xmm15
0000762f89bdc805  movaps xmm13, xmm10
0000762f89bdc809  addpd xmm13, xmm14
0000762f89bdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000762f89bdc814  ptest xmm12, xmm12
0000762f89bdc81a  jnz 0x0000762F89BE16B4
0000762f89bdc820  movaps [r15+0x150], xmm13
0000762f89bdc828  movaps xmm14, xmm1
0000762f89bdc82c  addpd xmm14, xmm7
0000762f89bdc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000762f89bdc837  ptest xmm12, xmm12
0000762f89bdc83d  jnz 0x0000762F89BE17F8
0000762f89bdc843  movaps [r15+0x160], xmm14
0000762f89bdc84b  movaps xmm1, xmm8
0000762f89bdc84f  addpd xmm1, xmm9
0000762f89bdc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000762f89bdc859  ptest xmm12, xmm12
0000762f89bdc85f  jnz 0x0000762F89BE193A
0000762f89bdc865  movaps [r15+0x120], xmm1
0000762f89bdc86d  movups [r13+r14*1], xmm15
0000762f89bdc873  lea rax, [r14+0x10]
0000762f89bdc877  movups [r13+rax*1], xmm13
0000762f89bdc87d  lea rax, [r14+0x20]
0000762f89bdc881  movups [r13+rax*1], xmm14
0000762f89bdc887  lea rax, [r14+0x30]
0000762f89bdc88b  movups [r13+rax*1], xmm1
0000762f89bdc891  mov eax, [r15+0x108]
0000762f89bdc898  sahf
0000762f89bdc899  jnz 0x0000762F89BDC8CB
0000762f89bdc89b  cmp dword ptr [r15+0x318], 0x00
0000762f89bdc8a3  jz 0x0000762F89BDB900
0000762f89bdc8a9  nop [rax+rax*1], ax
0000762f89bdc8b2  nop [rax+rax*1], eax
0000762f89bdc8ba  mov eax, 0x410444
0000762f89bdc8bf  mov [r15+0x100], rax
0000762f89bdc8c6  jmp 0x0000762F899FE110
0000762f89bdc8cb  cmp dword ptr [r15+0x318], 0x00
0000762f89bdc8d3  jz 0x0000762F89BD57E0
0000762f89bdc8d9  nop [rax+rax*1], ax
0000762f89bdc8e2  nop [rax+rax*1], eax
0000762f89bdc8ea  mov eax, 0x410278
0000762f89bdc8ef  mov [r15+0x100], rax
0000762f89bdc8f6  jmp 0x0000762F899FE110
0000762f89bdc8fb  int3
0000762f89bdc8fc  call 0x0000762F89AE27E0
0000762f89bdc901  jmp 0x0000762F89BDB9DF
0000762f89bdc906  call 0x0000762F89AE1570
0000762f89bdc90b  jmp 0x0000762F89BDB9E8
0000762f89bdc910  call 0x0000762F89AE27E0
0000762f89bdc915  jmp 0x0000762F89BDBA44
0000762f89bdc91a  call 0x0000762F89AE1570
0000762f89bdc91f  jmp 0x0000762F89BDBA4D
0000762f89bdc924  call 0x0000762F89AE27E0
0000762f89bdc929  jmp 0x0000762F89BDBA90
0000762f89bdc92e  call 0x0000762F89AE1570
0000762f89bdc933  jmp 0x0000762F89BDBA99
0000762f89bdc938  call 0x0000762F89A0DC20
0000762f89bdc93d  jmp 0x0000762F89BDBAD8
0000762f89bdc942  call 0x0000762F89AD59C0
0000762f89bdc947  jmp 0x0000762F89BDBAEB
0000762f89bdc94c  call 0x0000762F89AE0E30
0000762f89bdc951  jmp 0x0000762F89BDBB09
0000762f89bdc956  call 0x0000762F89ADFBC0
0000762f89bdc95b  jmp 0x0000762F89BDBB13
0000762f89bdc960  call 0x0000762F89ADE950
0000762f89bdc965  jmp 0x0000762F89BDBB1D
0000762f89bdc96a  sub rsp, 0x08
0000762f89bdc96e  push rax
0000762f89bdc96f  push rcx
0000762f89bdc970  push rdx
0000762f89bdc971  push rdi
0000762f89bdc972  push rsi
0000762f89bdc973  push r8
0000762f89bdc975  push r9
0000762f89bdc977  push r10
0000762f89bdc979  push r11
0000762f89bdc97b  sub rsp, 0xF0
0000762f89bdc982  vmovaps [rsp], xmm0
0000762f89bdc987  vmovaps [rsp+0x10], xmm1
0000762f89bdc98d  vmovaps [rsp+0x20], xmm2
0000762f89bdc993  vmovaps [rsp+0x30], xmm3
0000762f89bdc999  vmovaps [rsp+0x40], xmm4
0000762f89bdc99f  vmovaps [rsp+0x50], xmm5
0000762f89bdc9a5  vmovaps [rsp+0x60], xmm6
0000762f89bdc9ab  vmovaps [rsp+0x70], xmm7
0000762f89bdc9b1  vmovaps [rsp+0x80], xmm9
0000762f89bdc9ba  vmovaps [rsp+0x90], xmm10
0000762f89bdc9c3  vmovaps [rsp+0xA0], xmm11
0000762f89bdc9cc  vmovaps [rsp+0xB0], xmm12
0000762f89bdc9d5  vmovaps [rsp+0xC0], xmm13
0000762f89bdc9de  vmovaps [rsp+0xD0], xmm14
0000762f89bdc9e7  vmovaps [rsp+0xE0], xmm15
0000762f89bdc9f0  sub rsp, 0x30
0000762f89bdc9f4  movaps [rsp], xmm8
0000762f89bdc9f9  movaps [rsp+0x10], xmm12
0000762f89bdc9ff  movaps [rsp+0x20], xmm15
0000762f89bdca05  lea rdi, [rsp]
0000762f89bdca09  mov esi, 0x00
0000762f89bdca0e  mov rax, 0x604D6F946530
0000762f89bdca18  call rax
0000762f89bdca1a  movaps xmm8, [rsp]
0000762f89bdca1f  add rsp, 0x30
0000762f89bdca23  vmovaps xmm0, [rsp]
0000762f89bdca28  vmovaps xmm1, [rsp+0x10]
0000762f89bdca2e  vmovaps xmm2, [rsp+0x20]
0000762f89bdca34  vmovaps xmm3, [rsp+0x30]
0000762f89bdca3a  vmovaps xmm4, [rsp+0x40]
0000762f89bdca40  vmovaps xmm5, [rsp+0x50]
0000762f89bdca46  vmovaps xmm6, [rsp+0x60]
0000762f89bdca4c  vmovaps xmm7, [rsp+0x70]
0000762f89bdca52  vmovaps xmm9, [rsp+0x80]
0000762f89bdca5b  vmovaps xmm10, [rsp+0x90]
0000762f89bdca64  vmovaps xmm11, [rsp+0xA0]
0000762f89bdca6d  vmovaps xmm12, [rsp+0xB0]
0000762f89bdca76  vmovaps xmm13, [rsp+0xC0]
0000762f89bdca7f  vmovaps xmm14, [rsp+0xD0]
0000762f89bdca88  vmovaps xmm15, [rsp+0xE0]
0000762f89bdca91  add rsp, 0xF0
0000762f89bdca98  pop r11
0000762f89bdca9a  pop r10
0000762f89bdca9c  pop r9
0000762f89bdca9e  pop r8
0000762f89bdcaa0  pop rsi
0000762f89bdcaa1  pop rdi
0000762f89bdcaa2  pop rdx
0000762f89bdcaa3  pop rcx
0000762f89bdcaa4  pop rax
0000762f89bdcaa5  add rsp, 0x08
0000762f89bdcaa9  jmp 0x0000762F89BDBB47
0000762f89bdcaae  sub rsp, 0x08
0000762f89bdcab2  push rax
0000762f89bdcab3  push rcx
0000762f89bdcab4  push rdx
0000762f89bdcab5  push rdi
0000762f89bdcab6  push rsi
0000762f89bdcab7  push r8
0000762f89bdcab9  push r9
0000762f89bdcabb  push r10
0000762f89bdcabd  push r11
0000762f89bdcabf  sub rsp, 0xF0
0000762f89bdcac6  vmovaps [rsp], xmm0
0000762f89bdcacb  vmovaps [rsp+0x10], xmm1
0000762f89bdcad1  vmovaps [rsp+0x20], xmm2
0000762f89bdcad7  vmovaps [rsp+0x30], xmm3
0000762f89bdcadd  vmovaps [rsp+0x40], xmm4
0000762f89bdcae3  vmovaps [rsp+0x50], xmm5
0000762f89bdcae9  vmovaps [rsp+0x60], xmm6
0000762f89bdcaef  vmovaps [rsp+0x70], xmm8
0000762f89bdcaf5  vmovaps [rsp+0x80], xmm9
0000762f89bdcafe  vmovaps [rsp+0x90], xmm10
0000762f89bdcb07  vmovaps [rsp+0xA0], xmm11
0000762f89bdcb10  vmovaps [rsp+0xB0], xmm12
0000762f89bdcb19  vmovaps [rsp+0xC0], xmm13
0000762f89bdcb22  vmovaps [rsp+0xD0], xmm14
0000762f89bdcb2b  vmovaps [rsp+0xE0], xmm15
0000762f89bdcb34  sub rsp, 0x30
0000762f89bdcb38  movaps [rsp], xmm7
0000762f89bdcb3c  movaps [rsp+0x10], xmm9
0000762f89bdcb42  movaps [rsp+0x20], xmm15
0000762f89bdcb48  lea rdi, [rsp]
0000762f89bdcb4c  mov esi, 0x00
0000762f89bdcb51  mov rax, 0x604D6F946530
0000762f89bdcb5b  call rax
0000762f89bdcb5d  movaps xmm7, [rsp]
0000762f89bdcb61  add rsp, 0x30
0000762f89bdcb65  vmovaps xmm0, [rsp]
0000762f89bdcb6a  vmovaps xmm1, [rsp+0x10]
0000762f89bdcb70  vmovaps xmm2, [rsp+0x20]
0000762f89bdcb76  vmovaps xmm3, [rsp+0x30]
0000762f89bdcb7c  vmovaps xmm4, [rsp+0x40]
0000762f89bdcb82  vmovaps xmm5, [rsp+0x50]
0000762f89bdcb88  vmovaps xmm6, [rsp+0x60]
0000762f89bdcb8e  vmovaps xmm8, [rsp+0x70]
0000762f89bdcb94  vmovaps xmm9, [rsp+0x80]
0000762f89bdcb9d  vmovaps xmm10, [rsp+0x90]
0000762f89bdcba6  vmovaps xmm11, [rsp+0xA0]
0000762f89bdcbaf  vmovaps xmm12, [rsp+0xB0]
0000762f89bdcbb8  vmovaps xmm13, [rsp+0xC0]
0000762f89bdcbc1  vmovaps xmm14, [rsp+0xD0]
0000762f89bdcbca  vmovaps xmm15, [rsp+0xE0]
0000762f89bdcbd3  add rsp, 0xF0
0000762f89bdcbda  pop r11
0000762f89bdcbdc  pop r10
0000762f89bdcbde  pop r9
0000762f89bdcbe0  pop r8
0000762f89bdcbe2  pop rsi
0000762f89bdcbe3  pop rdi
0000762f89bdcbe4  pop rdx
0000762f89bdcbe5  pop rcx
0000762f89bdcbe6  pop rax
0000762f89bdcbe7  add rsp, 0x08
0000762f89bdcbeb  jmp 0x0000762F89BDBB75
0000762f89bdcbf0  sub rsp, 0x08
0000762f89bdcbf4  push rax
0000762f89bdcbf5  push rcx
0000762f89bdcbf6  push rdx
0000762f89bdcbf7  push rdi
0000762f89bdcbf8  push rsi
0000762f89bdcbf9  push r8
0000762f89bdcbfb  push r9
0000762f89bdcbfd  push r10
0000762f89bdcbff  push r11
0000762f89bdcc01  sub rsp, 0xF0
0000762f89bdcc08  vmovaps [rsp], xmm0
0000762f89bdcc0d  vmovaps [rsp+0x10], xmm1
0000762f89bdcc13  vmovaps [rsp+0x20], xmm2
0000762f89bdcc19  vmovaps [rsp+0x30], xmm3
0000762f89bdcc1f  vmovaps [rsp+0x40], xmm4
0000762f89bdcc25  vmovaps [rsp+0x50], xmm5
0000762f89bdcc2b  vmovaps [rsp+0x60], xmm6
0000762f89bdcc31  vmovaps [rsp+0x70], xmm7
0000762f89bdcc37  vmovaps [rsp+0x80], xmm8
0000762f89bdcc40  vmovaps [rsp+0x90], xmm10
0000762f89bdcc49  vmovaps [rsp+0xA0], xmm11
0000762f89bdcc52  vmovaps [rsp+0xB0], xmm12
0000762f89bdcc5b  vmovaps [rsp+0xC0], xmm13
0000762f89bdcc64  vmovaps [rsp+0xD0], xmm14
0000762f89bdcc6d  vmovaps [rsp+0xE0], xmm15
0000762f89bdcc76  sub rsp, 0x30
0000762f89bdcc7a  movaps [rsp], xmm9
0000762f89bdcc7f  movaps [rsp+0x10], xmm12
0000762f89bdcc85  movaps [rsp+0x20], xmm10
0000762f89bdcc8b  lea rdi, [rsp]
0000762f89bdcc8f  mov esi, 0x00
0000762f89bdcc94  mov rax, 0x604D6F946530
0000762f89bdcc9e  call rax
0000762f89bdcca0  movaps xmm9, [rsp]
0000762f89bdcca5  add rsp, 0x30
0000762f89bdcca9  vmovaps xmm0, [rsp]
0000762f89bdccae  vmovaps xmm1, [rsp+0x10]
0000762f89bdccb4  vmovaps xmm2, [rsp+0x20]
0000762f89bdccba  vmovaps xmm3, [rsp+0x30]
0000762f89bdccc0  vmovaps xmm4, [rsp+0x40]
0000762f89bdccc6  vmovaps xmm5, [rsp+0x50]
0000762f89bdcccc  vmovaps xmm6, [rsp+0x60]
0000762f89bdccd2  vmovaps xmm7, [rsp+0x70]
0000762f89bdccd8  vmovaps xmm8, [rsp+0x80]
0000762f89bdcce1  vmovaps xmm10, [rsp+0x90]
0000762f89bdccea  vmovaps xmm11, [rsp+0xA0]
0000762f89bdccf3  vmovaps xmm12, [rsp+0xB0]
0000762f89bdccfc  vmovaps xmm13, [rsp+0xC0]
0000762f89bdcd05  vmovaps xmm14, [rsp+0xD0]
0000762f89bdcd0e  vmovaps xmm15, [rsp+0xE0]
0000762f89bdcd17  add rsp, 0xF0
0000762f89bdcd1e  pop r11
0000762f89bdcd20  pop r10
0000762f89bdcd22  pop r9
0000762f89bdcd24  pop r8
0000762f89bdcd26  pop rsi
0000762f89bdcd27  pop rdi
0000762f89bdcd28  pop rdx
0000762f89bdcd29  pop rcx
0000762f89bdcd2a  pop rax
0000762f89bdcd2b  add rsp, 0x08
0000762f89bdcd2f  jmp 0x0000762F89BDBB99
0000762f89bdcd34  sub rsp, 0x08
0000762f89bdcd38  push rax
0000762f89bdcd39  push rcx
0000762f89bdcd3a  push rdx
0000762f89bdcd3b  push rdi
0000762f89bdcd3c  push rsi
0000762f89bdcd3d  push r8
0000762f89bdcd3f  push r9
0000762f89bdcd41  push r10
0000762f89bdcd43  push r11
0000762f89bdcd45  sub rsp, 0xF0
0000762f89bdcd4c  vmovaps [rsp], xmm0
0000762f89bdcd51  vmovaps [rsp+0x10], xmm1
0000762f89bdcd57  vmovaps [rsp+0x20], xmm2
0000762f89bdcd5d  vmovaps [rsp+0x30], xmm3
0000762f89bdcd63  vmovaps [rsp+0x40], xmm4
0000762f89bdcd69  vmovaps [rsp+0x50], xmm5
0000762f89bdcd6f  vmovaps [rsp+0x60], xmm6
0000762f89bdcd75  vmovaps [rsp+0x70], xmm7
0000762f89bdcd7b  vmovaps [rsp+0x80], xmm8
0000762f89bdcd84  vmovaps [rsp+0x90], xmm9
0000762f89bdcd8d  vmovaps [rsp+0xA0], xmm11
0000762f89bdcd96  vmovaps [rsp+0xB0], xmm12
0000762f89bdcd9f  vmovaps [rsp+0xC0], xmm13
0000762f89bdcda8  vmovaps [rsp+0xD0], xmm14
0000762f89bdcdb1  vmovaps [rsp+0xE0], xmm15
0000762f89bdcdba  sub rsp, 0x30
0000762f89bdcdbe  movaps [rsp], xmm10
0000762f89bdcdc3  movaps [rsp+0x10], xmm12
0000762f89bdcdc9  movaps [rsp+0x20], xmm11
0000762f89bdcdcf  lea rdi, [rsp]
0000762f89bdcdd3  mov esi, 0x00
0000762f89bdcdd8  mov rax, 0x604D6F946530
0000762f89bdcde2  call rax
0000762f89bdcde4  movaps xmm10, [rsp]
0000762f89bdcde9  add rsp, 0x30
0000762f89bdcded  vmovaps xmm0, [rsp]
0000762f89bdcdf2  vmovaps xmm1, [rsp+0x10]
0000762f89bdcdf8  vmovaps xmm2, [rsp+0x20]
0000762f89bdcdfe  vmovaps xmm3, [rsp+0x30]
0000762f89bdce04  vmovaps xmm4, [rsp+0x40]
0000762f89bdce0a  vmovaps xmm5, [rsp+0x50]
0000762f89bdce10  vmovaps xmm6, [rsp+0x60]
0000762f89bdce16  vmovaps xmm7, [rsp+0x70]
0000762f89bdce1c  vmovaps xmm8, [rsp+0x80]
0000762f89bdce25  vmovaps xmm9, [rsp+0x90]
0000762f89bdce2e  vmovaps xmm11, [rsp+0xA0]
0000762f89bdce37  vmovaps xmm12, [rsp+0xB0]
0000762f89bdce40  vmovaps xmm13, [rsp+0xC0]
0000762f89bdce49  vmovaps xmm14, [rsp+0xD0]
0000762f89bdce52  vmovaps xmm15, [rsp+0xE0]
0000762f89bdce5b  add rsp, 0xF0
0000762f89bdce62  pop r11
0000762f89bdce64  pop r10
0000762f89bdce66  pop r9
0000762f89bdce68  pop r8
0000762f89bdce6a  pop rsi
0000762f89bdce6b  pop rdi
0000762f89bdce6c  pop rdx
0000762f89bdce6d  pop rcx
0000762f89bdce6e  pop rax
0000762f89bdce6f  add rsp, 0x08
0000762f89bdce73  jmp 0x0000762F89BDBBB3
0000762f89bdce78  sub rsp, 0x08
0000762f89bdce7c  push rax
0000762f89bdce7d  push rcx
0000762f89bdce7e  push rdx
0000762f89bdce7f  push rdi
0000762f89bdce80  push rsi
0000762f89bdce81  push r8
0000762f89bdce83  push r9
0000762f89bdce85  push r10
0000762f89bdce87  push r11
0000762f89bdce89  sub rsp, 0xF0
0000762f89bdce90  vmovaps [rsp], xmm0
0000762f89bdce95  vmovaps [rsp+0x10], xmm1
0000762f89bdce9b  vmovaps [rsp+0x20], xmm2
0000762f89bdcea1  vmovaps [rsp+0x30], xmm3
0000762f89bdcea7  vmovaps [rsp+0x40], xmm4
0000762f89bdcead  vmovaps [rsp+0x50], xmm5
0000762f89bdceb3  vmovaps [rsp+0x60], xmm7
0000762f89bdceb9  vmovaps [rsp+0x70], xmm8
0000762f89bdcebf  vmovaps [rsp+0x80], xmm9
0000762f89bdcec8  vmovaps [rsp+0x90], xmm10
0000762f89bdced1  vmovaps [rsp+0xA0], xmm11
0000762f89bdceda  vmovaps [rsp+0xB0], xmm12
0000762f89bdcee3  vmovaps [rsp+0xC0], xmm13
0000762f89bdceec  vmovaps [rsp+0xD0], xmm14
0000762f89bdcef5  vmovaps [rsp+0xE0], xmm15
0000762f89bdcefe  sub rsp, 0x30
0000762f89bdcf02  movaps [rsp], xmm6
0000762f89bdcf06  movaps [rsp+0x10], xmm12
0000762f89bdcf0c  movaps [rsp+0x20], xmm11
0000762f89bdcf12  lea rdi, [rsp]
0000762f89bdcf16  mov esi, 0x00
0000762f89bdcf1b  mov rax, 0x604D6F946530
0000762f89bdcf25  call rax
0000762f89bdcf27  movaps xmm6, [rsp]
0000762f89bdcf2b  add rsp, 0x30
0000762f89bdcf2f  vmovaps xmm0, [rsp]
0000762f89bdcf34  vmovaps xmm1, [rsp+0x10]
0000762f89bdcf3a  vmovaps xmm2, [rsp+0x20]
0000762f89bdcf40  vmovaps xmm3, [rsp+0x30]
0000762f89bdcf46  vmovaps xmm4, [rsp+0x40]
0000762f89bdcf4c  vmovaps xmm5, [rsp+0x50]
0000762f89bdcf52  vmovaps xmm7, [rsp+0x60]
0000762f89bdcf58  vmovaps xmm8, [rsp+0x70]
0000762f89bdcf5e  vmovaps xmm9, [rsp+0x80]
0000762f89bdcf67  vmovaps xmm10, [rsp+0x90]
0000762f89bdcf70  vmovaps xmm11, [rsp+0xA0]
0000762f89bdcf79  vmovaps xmm12, [rsp+0xB0]
0000762f89bdcf82  vmovaps xmm13, [rsp+0xC0]
0000762f89bdcf8b  vmovaps xmm14, [rsp+0xD0]
0000762f89bdcf94  vmovaps xmm15, [rsp+0xE0]
0000762f89bdcf9d  add rsp, 0xF0
0000762f89bdcfa4  pop r11
0000762f89bdcfa6  pop r10
0000762f89bdcfa8  pop r9
0000762f89bdcfaa  pop r8
0000762f89bdcfac  pop rsi
0000762f89bdcfad  pop rdi
0000762f89bdcfae  pop rdx
0000762f89bdcfaf  pop rcx
0000762f89bdcfb0  pop rax
0000762f89bdcfb1  add rsp, 0x08
0000762f89bdcfb5  jmp 0x0000762F89BDBBD4
0000762f89bdcfba  sub rsp, 0x08
0000762f89bdcfbe  push rax
0000762f89bdcfbf  push rcx
0000762f89bdcfc0  push rdx
0000762f89bdcfc1  push rdi
0000762f89bdcfc2  push rsi
0000762f89bdcfc3  push r8
0000762f89bdcfc5  push r9
0000762f89bdcfc7  push r10
0000762f89bdcfc9  push r11
0000762f89bdcfcb  sub rsp, 0xF0
0000762f89bdcfd2  vmovaps [rsp], xmm0
0000762f89bdcfd7  vmovaps [rsp+0x10], xmm1
0000762f89bdcfdd  vmovaps [rsp+0x20], xmm2
0000762f89bdcfe3  vmovaps [rsp+0x30], xmm4
0000762f89bdcfe9  vmovaps [rsp+0x40], xmm5
0000762f89bdcfef  vmovaps [rsp+0x50], xmm6
0000762f89bdcff5  vmovaps [rsp+0x60], xmm7
0000762f89bdcffb  vmovaps [rsp+0x70], xmm8
0000762f89bdd001  vmovaps [rsp+0x80], xmm9
0000762f89bdd00a  vmovaps [rsp+0x90], xmm10
0000762f89bdd013  vmovaps [rsp+0xA0], xmm11
0000762f89bdd01c  vmovaps [rsp+0xB0], xmm12
0000762f89bdd025  vmovaps [rsp+0xC0], xmm13
0000762f89bdd02e  vmovaps [rsp+0xD0], xmm14
0000762f89bdd037  vmovaps [rsp+0xE0], xmm15
0000762f89bdd040  sub rsp, 0x30
0000762f89bdd044  movaps [rsp], xmm3
0000762f89bdd048  movaps [rsp+0x10], xmm5
0000762f89bdd04d  movaps [rsp+0x20], xmm4
0000762f89bdd052  lea rdi, [rsp]
0000762f89bdd056  mov esi, 0x00
0000762f89bdd05b  mov rax, 0x604D6F946530
0000762f89bdd065  call rax
0000762f89bdd067  movaps xmm3, [rsp]
0000762f89bdd06b  add rsp, 0x30
0000762f89bdd06f  vmovaps xmm0, [rsp]
0000762f89bdd074  vmovaps xmm1, [rsp+0x10]
0000762f89bdd07a  vmovaps xmm2, [rsp+0x20]
0000762f89bdd080  vmovaps xmm4, [rsp+0x30]
0000762f89bdd086  vmovaps xmm5, [rsp+0x40]
0000762f89bdd08c  vmovaps xmm6, [rsp+0x50]
0000762f89bdd092  vmovaps xmm7, [rsp+0x60]
0000762f89bdd098  vmovaps xmm8, [rsp+0x70]
0000762f89bdd09e  vmovaps xmm9, [rsp+0x80]
0000762f89bdd0a7  vmovaps xmm10, [rsp+0x90]
0000762f89bdd0b0  vmovaps xmm11, [rsp+0xA0]
0000762f89bdd0b9  vmovaps xmm12, [rsp+0xB0]
0000762f89bdd0c2  vmovaps xmm13, [rsp+0xC0]
0000762f89bdd0cb  vmovaps xmm14, [rsp+0xD0]
0000762f89bdd0d4  vmovaps xmm15, [rsp+0xE0]
0000762f89bdd0dd  add rsp, 0xF0
0000762f89bdd0e4  pop r11
0000762f89bdd0e6  pop r10
0000762f89bdd0e8  pop r9
0000762f89bdd0ea  pop r8
0000762f89bdd0ec  pop rsi
0000762f89bdd0ed  pop rdi
0000762f89bdd0ee  pop rdx
0000762f89bdd0ef  pop rcx
0000762f89bdd0f0  pop rax
0000762f89bdd0f1  add rsp, 0x08
0000762f89bdd0f5  jmp 0x0000762F89BDBC35
0000762f89bdd0fa  sub rsp, 0x08
0000762f89bdd0fe  push rax
0000762f89bdd0ff  push rcx
0000762f89bdd100  push rdx
0000762f89bdd101  push rdi
0000762f89bdd102  push rsi
0000762f89bdd103  push r8
0000762f89bdd105  push r9
0000762f89bdd107  push r10
0000762f89bdd109  push r11
0000762f89bdd10b  sub rsp, 0xF0
0000762f89bdd112  vmovaps [rsp], xmm0
0000762f89bdd117  vmovaps [rsp+0x10], xmm1
0000762f89bdd11d  vmovaps [rsp+0x20], xmm2
0000762f89bdd123  vmovaps [rsp+0x30], xmm3
0000762f89bdd129  vmovaps [rsp+0x40], xmm4
0000762f89bdd12f  vmovaps [rsp+0x50], xmm6
0000762f89bdd135  vmovaps [rsp+0x60], xmm7
0000762f89bdd13b  vmovaps [rsp+0x70], xmm8
0000762f89bdd141  vmovaps [rsp+0x80], xmm9
0000762f89bdd14a  vmovaps [rsp+0x90], xmm10
0000762f89bdd153  vmovaps [rsp+0xA0], xmm11
0000762f89bdd15c  vmovaps [rsp+0xB0], xmm12
0000762f89bdd165  vmovaps [rsp+0xC0], xmm13
0000762f89bdd16e  vmovaps [rsp+0xD0], xmm14
0000762f89bdd177  vmovaps [rsp+0xE0], xmm15
0000762f89bdd180  sub rsp, 0x30
0000762f89bdd184  movaps [rsp], xmm5
0000762f89bdd188  movaps [rsp+0x10], xmm8
0000762f89bdd18e  movaps [rsp+0x20], xmm15
0000762f89bdd194  lea rdi, [rsp]
0000762f89bdd198  mov esi, 0x00
0000762f89bdd19d  mov rax, 0x604D6F946530
0000762f89bdd1a7  call rax
0000762f89bdd1a9  movaps xmm5, [rsp]
0000762f89bdd1ad  add rsp, 0x30
0000762f89bdd1b1  vmovaps xmm0, [rsp]
0000762f89bdd1b6  vmovaps xmm1, [rsp+0x10]
0000762f89bdd1bc  vmovaps xmm2, [rsp+0x20]
0000762f89bdd1c2  vmovaps xmm3, [rsp+0x30]
0000762f89bdd1c8  vmovaps xmm4, [rsp+0x40]
0000762f89bdd1ce  vmovaps xmm6, [rsp+0x50]
0000762f89bdd1d4  vmovaps xmm7, [rsp+0x60]
0000762f89bdd1da  vmovaps xmm8, [rsp+0x70]
0000762f89bdd1e0  vmovaps xmm9, [rsp+0x80]
0000762f89bdd1e9  vmovaps xmm10, [rsp+0x90]
0000762f89bdd1f2  vmovaps xmm11, [rsp+0xA0]
0000762f89bdd1fb  vmovaps xmm12, [rsp+0xB0]
0000762f89bdd204  vmovaps xmm13, [rsp+0xC0]
0000762f89bdd20d  vmovaps xmm14, [rsp+0xD0]
0000762f89bdd216  vmovaps xmm15, [rsp+0xE0]
0000762f89bdd21f  add rsp, 0xF0
0000762f89bdd226  pop r11
0000762f89bdd228  pop r10
0000762f89bdd22a  pop r9
0000762f89bdd22c  pop r8
0000762f89bdd22e  pop rsi
0000762f89bdd22f  pop rdi
0000762f89bdd230  pop rdx
0000762f89bdd231  pop rcx
0000762f89bdd232  pop rax
0000762f89bdd233  add rsp, 0x08
0000762f89bdd237  jmp 0x0000762F89BDBC73
0000762f89bdd23c  sub rsp, 0x08
0000762f89bdd240  push rax
0000762f89bdd241  push rcx
0000762f89bdd242  push rdx
0000762f89bdd243  push rdi
0000762f89bdd244  push rsi
0000762f89bdd245  push r8
0000762f89bdd247  push r9
0000762f89bdd249  push r10
0000762f89bdd24b  push r11
0000762f89bdd24d  sub rsp, 0xF0
0000762f89bdd254  vmovaps [rsp], xmm0
0000762f89bdd259  vmovaps [rsp+0x10], xmm1
0000762f89bdd25f  vmovaps [rsp+0x20], xmm2
0000762f89bdd265  vmovaps [rsp+0x30], xmm3
0000762f89bdd26b  vmovaps [rsp+0x40], xmm5
0000762f89bdd271  vmovaps [rsp+0x50], xmm6
0000762f89bdd277  vmovaps [rsp+0x60], xmm7
0000762f89bdd27d  vmovaps [rsp+0x70], xmm8
0000762f89bdd283  vmovaps [rsp+0x80], xmm9
0000762f89bdd28c  vmovaps [rsp+0x90], xmm10
0000762f89bdd295  vmovaps [rsp+0xA0], xmm11
0000762f89bdd29e  vmovaps [rsp+0xB0], xmm12
0000762f89bdd2a7  vmovaps [rsp+0xC0], xmm13
0000762f89bdd2b0  vmovaps [rsp+0xD0], xmm14
0000762f89bdd2b9  vmovaps [rsp+0xE0], xmm15
0000762f89bdd2c2  sub rsp, 0x30
0000762f89bdd2c6  movaps [rsp], xmm4
0000762f89bdd2ca  movaps [rsp+0x10], xmm9
0000762f89bdd2d0  movaps [rsp+0x20], xmm8
0000762f89bdd2d6  lea rdi, [rsp]
0000762f89bdd2da  mov esi, 0x00
0000762f89bdd2df  mov rax, 0x604D6F946530
0000762f89bdd2e9  call rax
0000762f89bdd2eb  movaps xmm4, [rsp]
0000762f89bdd2ef  add rsp, 0x30
0000762f89bdd2f3  vmovaps xmm0, [rsp]
0000762f89bdd2f8  vmovaps xmm1, [rsp+0x10]
0000762f89bdd2fe  vmovaps xmm2, [rsp+0x20]
0000762f89bdd304  vmovaps xmm3, [rsp+0x30]
0000762f89bdd30a  vmovaps xmm5, [rsp+0x40]
0000762f89bdd310  vmovaps xmm6, [rsp+0x50]
0000762f89bdd316  vmovaps xmm7, [rsp+0x60]
0000762f89bdd31c  vmovaps xmm8, [rsp+0x70]
0000762f89bdd322  vmovaps xmm9, [rsp+0x80]
0000762f89bdd32b  vmovaps xmm10, [rsp+0x90]
0000762f89bdd334  vmovaps xmm11, [rsp+0xA0]
0000762f89bdd33d  vmovaps xmm12, [rsp+0xB0]
0000762f89bdd346  vmovaps xmm13, [rsp+0xC0]
0000762f89bdd34f  vmovaps xmm14, [rsp+0xD0]
0000762f89bdd358  vmovaps xmm15, [rsp+0xE0]
0000762f89bdd361  add rsp, 0xF0
0000762f89bdd368  pop r11
0000762f89bdd36a  pop r10
0000762f89bdd36c  pop r9
0000762f89bdd36e  pop r8
0000762f89bdd370  pop rsi
0000762f89bdd371  pop rdi
0000762f89bdd372  pop rdx
0000762f89bdd373  pop rcx
0000762f89bdd374  pop rax
0000762f89bdd375  add rsp, 0x08
0000762f89bdd379  jmp 0x0000762F89BDBC94
0000762f89bdd37e  sub rsp, 0x08
0000762f89bdd382  push rax
0000762f89bdd383  push rcx
0000762f89bdd384  push rdx
0000762f89bdd385  push rdi
0000762f89bdd386  push rsi
0000762f89bdd387  push r8
0000762f89bdd389  push r9
0000762f89bdd38b  push r10
0000762f89bdd38d  push r11
0000762f89bdd38f  sub rsp, 0xF0
0000762f89bdd396  vmovaps [rsp], xmm0
0000762f89bdd39b  vmovaps [rsp+0x10], xmm1
0000762f89bdd3a1  vmovaps [rsp+0x20], xmm2
0000762f89bdd3a7  vmovaps [rsp+0x30], xmm3
0000762f89bdd3ad  vmovaps [rsp+0x40], xmm4
0000762f89bdd3b3  vmovaps [rsp+0x50], xmm5
0000762f89bdd3b9  vmovaps [rsp+0x60], xmm6
0000762f89bdd3bf  vmovaps [rsp+0x70], xmm7
0000762f89bdd3c5  vmovaps [rsp+0x80], xmm8
0000762f89bdd3ce  vmovaps [rsp+0x90], xmm10
0000762f89bdd3d7  vmovaps [rsp+0xA0], xmm11
0000762f89bdd3e0  vmovaps [rsp+0xB0], xmm12
0000762f89bdd3e9  vmovaps [rsp+0xC0], xmm13
0000762f89bdd3f2  vmovaps [rsp+0xD0], xmm14
0000762f89bdd3fb  vmovaps [rsp+0xE0], xmm15
0000762f89bdd404  sub rsp, 0x30
0000762f89bdd408  movaps [rsp], xmm9
0000762f89bdd40d  movaps [rsp+0x10], xmm10
0000762f89bdd413  movaps [rsp+0x20], xmm8
0000762f89bdd419  lea rdi, [rsp]
0000762f89bdd41d  mov esi, 0x00
0000762f89bdd422  mov rax, 0x604D6F946530
0000762f89bdd42c  call rax
0000762f89bdd42e  movaps xmm9, [rsp]
0000762f89bdd433  add rsp, 0x30
0000762f89bdd437  vmovaps xmm0, [rsp]
0000762f89bdd43c  vmovaps xmm1, [rsp+0x10]
0000762f89bdd442  vmovaps xmm2, [rsp+0x20]
0000762f89bdd448  vmovaps xmm3, [rsp+0x30]
0000762f89bdd44e  vmovaps xmm4, [rsp+0x40]
0000762f89bdd454  vmovaps xmm5, [rsp+0x50]
0000762f89bdd45a  vmovaps xmm6, [rsp+0x60]
0000762f89bdd460  vmovaps xmm7, [rsp+0x70]
0000762f89bdd466  vmovaps xmm8, [rsp+0x80]
0000762f89bdd46f  vmovaps xmm10, [rsp+0x90]
0000762f89bdd478  vmovaps xmm11, [rsp+0xA0]
0000762f89bdd481  vmovaps xmm12, [rsp+0xB0]
0000762f89bdd48a  vmovaps xmm13, [rsp+0xC0]
0000762f89bdd493  vmovaps xmm14, [rsp+0xD0]
0000762f89bdd49c  vmovaps xmm15, [rsp+0xE0]
0000762f89bdd4a5  add rsp, 0xF0
0000762f89bdd4ac  pop r11
0000762f89bdd4ae  pop r10
0000762f89bdd4b0  pop r9
0000762f89bdd4b2  pop r8
0000762f89bdd4b4  pop rsi
0000762f89bdd4b5  pop rdi
0000762f89bdd4b6  pop rdx
0000762f89bdd4b7  pop rcx
0000762f89bdd4b8  pop rax
0000762f89bdd4b9  add rsp, 0x08
0000762f89bdd4bd  jmp 0x0000762F89BDBCAE
0000762f89bdd4c2  call 0x0000762F89AB52F0
0000762f89bdd4c7  jmp 0x0000762F89BDBDC8
0000762f89bdd4cc  call 0x0000762F89AB52F0
0000762f89bdd4d1  jmp 0x0000762F89BDBDDE
0000762f89bdd4d6  sub rsp, 0x08
0000762f89bdd4da  push rax
0000762f89bdd4db  push rcx
0000762f89bdd4dc  push rdx
0000762f89bdd4dd  push rdi
0000762f89bdd4de  push rsi
0000762f89bdd4df  push r8
0000762f89bdd4e1  push r9
0000762f89bdd4e3  push r10
0000762f89bdd4e5  push r11
0000762f89bdd4e7  sub rsp, 0xF0
0000762f89bdd4ee  vmovaps [rsp], xmm0
0000762f89bdd4f3  vmovaps [rsp+0x10], xmm2
0000762f89bdd4f9  vmovaps [rsp+0x20], xmm3
0000762f89bdd4ff  vmovaps [rsp+0x30], xmm4
0000762f89bdd505  vmovaps [rsp+0x40], xmm5
0000762f89bdd50b  vmovaps [rsp+0x50], xmm6
0000762f89bdd511  vmovaps [rsp+0x60], xmm7
0000762f89bdd517  vmovaps [rsp+0x70], xmm8
0000762f89bdd51d  vmovaps [rsp+0x80], xmm9
0000762f89bdd526  vmovaps [rsp+0x90], xmm10
0000762f89bdd52f  vmovaps [rsp+0xA0], xmm11
0000762f89bdd538  vmovaps [rsp+0xB0], xmm12
0000762f89bdd541  vmovaps [rsp+0xC0], xmm13
0000762f89bdd54a  vmovaps [rsp+0xD0], xmm14
0000762f89bdd553  vmovaps [rsp+0xE0], xmm15
0000762f89bdd55c  sub rsp, 0x30
0000762f89bdd560  movaps [rsp], xmm1
0000762f89bdd564  movaps [rsp+0x10], xmm6
0000762f89bdd569  movaps [rsp+0x20], xmm15
0000762f89bdd56f  lea rdi, [rsp]
0000762f89bdd573  mov esi, 0x00
0000762f89bdd578  mov rax, 0x604D6F946530
0000762f89bdd582  call rax
0000762f89bdd584  movaps xmm1, [rsp]
0000762f89bdd588  add rsp, 0x30
0000762f89bdd58c  vmovaps xmm0, [rsp]
0000762f89bdd591  vmovaps xmm2, [rsp+0x10]
0000762f89bdd597  vmovaps xmm3, [rsp+0x20]
0000762f89bdd59d  vmovaps xmm4, [rsp+0x30]
0000762f89bdd5a3  vmovaps xmm5, [rsp+0x40]
0000762f89bdd5a9  vmovaps xmm6, [rsp+0x50]
0000762f89bdd5af  vmovaps xmm7, [rsp+0x60]
0000762f89bdd5b5  vmovaps xmm8, [rsp+0x70]
0000762f89bdd5bb  vmovaps xmm9, [rsp+0x80]
0000762f89bdd5c4  vmovaps xmm10, [rsp+0x90]
0000762f89bdd5cd  vmovaps xmm11, [rsp+0xA0]
0000762f89bdd5d6  vmovaps xmm12, [rsp+0xB0]
0000762f89bdd5df  vmovaps xmm13, [rsp+0xC0]
0000762f89bdd5e8  vmovaps xmm14, [rsp+0xD0]
0000762f89bdd5f1  vmovaps xmm15, [rsp+0xE0]
0000762f89bdd5fa  add rsp, 0xF0
0000762f89bdd601  pop r11
0000762f89bdd603  pop r10
0000762f89bdd605  pop r9
0000762f89bdd607  pop r8
0000762f89bdd609  pop rsi
0000762f89bdd60a  pop rdi
0000762f89bdd60b  pop rdx
0000762f89bdd60c  pop rcx
0000762f89bdd60d  pop rax
0000762f89bdd60e  add rsp, 0x08
0000762f89bdd612  jmp 0x0000762F89BDBE1B
0000762f89bdd617  call 0x0000762F89AC4620
0000762f89bdd61c  jmp 0x0000762F89BDBE28
0000762f89bdd621  sub rsp, 0x08
0000762f89bdd625  push rax
0000762f89bdd626  push rcx
0000762f89bdd627  push rdx
0000762f89bdd628  push rdi
0000762f89bdd629  push rsi
0000762f89bdd62a  push r8
0000762f89bdd62c  push r9
0000762f89bdd62e  push r10
0000762f89bdd630  push r11
0000762f89bdd632  sub rsp, 0xF0
0000762f89bdd639  vmovaps [rsp], xmm0
0000762f89bdd63e  vmovaps [rsp+0x10], xmm1
0000762f89bdd644  vmovaps [rsp+0x20], xmm2
0000762f89bdd64a  vmovaps [rsp+0x30], xmm3
0000762f89bdd650  vmovaps [rsp+0x40], xmm4
0000762f89bdd656  vmovaps [rsp+0x50], xmm5
0000762f89bdd65c  vmovaps [rsp+0x60], xmm6
0000762f89bdd662  vmovaps [rsp+0x70], xmm7
0000762f89bdd668  vmovaps [rsp+0x80], xmm8
0000762f89bdd671  vmovaps [rsp+0x90], xmm9
0000762f89bdd67a  vmovaps [rsp+0xA0], xmm10
0000762f89bdd683  vmovaps [rsp+0xB0], xmm11
0000762f89bdd68c  vmovaps [rsp+0xC0], xmm12
0000762f89bdd695  vmovaps [rsp+0xD0], xmm13
0000762f89bdd69e  vmovaps [rsp+0xE0], xmm15
0000762f89bdd6a7  sub rsp, 0x30
0000762f89bdd6ab  movaps [rsp], xmm14
0000762f89bdd6b0  movaps [rsp+0x10], xmm4
0000762f89bdd6b5  movaps [rsp+0x20], xmm3
0000762f89bdd6ba  lea rdi, [rsp]
0000762f89bdd6be  mov esi, 0x00
0000762f89bdd6c3  mov rax, 0x604D6F946530
0000762f89bdd6cd  call rax
0000762f89bdd6cf  movaps xmm14, [rsp]
0000762f89bdd6d4  add rsp, 0x30
0000762f89bdd6d8  vmovaps xmm0, [rsp]
0000762f89bdd6dd  vmovaps xmm1, [rsp+0x10]
0000762f89bdd6e3  vmovaps xmm2, [rsp+0x20]
0000762f89bdd6e9  vmovaps xmm3, [rsp+0x30]
0000762f89bdd6ef  vmovaps xmm4, [rsp+0x40]
0000762f89bdd6f5  vmovaps xmm5, [rsp+0x50]
0000762f89bdd6fb  vmovaps xmm6, [rsp+0x60]
0000762f89bdd701  vmovaps xmm7, [rsp+0x70]
0000762f89bdd707  vmovaps xmm8, [rsp+0x80]
0000762f89bdd710  vmovaps xmm9, [rsp+0x90]
0000762f89bdd719  vmovaps xmm10, [rsp+0xA0]
0000762f89bdd722  vmovaps xmm11, [rsp+0xB0]
0000762f89bdd72b  vmovaps xmm12, [rsp+0xC0]
0000762f89bdd734  vmovaps xmm13, [rsp+0xD0]
0000762f89bdd73d  vmovaps xmm15, [rsp+0xE0]
0000762f89bdd746  add rsp, 0xF0
0000762f89bdd74d  pop r11
0000762f89bdd74f  pop r10
0000762f89bdd751  pop r9
0000762f89bdd753  pop r8
0000762f89bdd755  pop rsi
0000762f89bdd756  pop rdi
0000762f89bdd757  pop rdx
0000762f89bdd758  pop rcx
0000762f89bdd759  pop rax
0000762f89bdd75a  add rsp, 0x08
0000762f89bdd75e  jmp 0x0000762F89BDBE42
0000762f89bdd763  sub rsp, 0x08
0000762f89bdd767  push rax
0000762f89bdd768  push rcx
0000762f89bdd769  push rdx
0000762f89bdd76a  push rdi
0000762f89bdd76b  push rsi
0000762f89bdd76c  push r8
0000762f89bdd76e  push r9
0000762f89bdd770  push r10
0000762f89bdd772  push r11
0000762f89bdd774  sub rsp, 0xF0
0000762f89bdd77b  vmovaps [rsp], xmm0
0000762f89bdd780  vmovaps [rsp+0x10], xmm1
0000762f89bdd786  vmovaps [rsp+0x20], xmm2
0000762f89bdd78c  vmovaps [rsp+0x30], xmm3
0000762f89bdd792  vmovaps [rsp+0x40], xmm4
0000762f89bdd798  vmovaps [rsp+0x50], xmm5
0000762f89bdd79e  vmovaps [rsp+0x60], xmm7
0000762f89bdd7a4  vmovaps [rsp+0x70], xmm8
0000762f89bdd7aa  vmovaps [rsp+0x80], xmm9
0000762f89bdd7b3  vmovaps [rsp+0x90], xmm10
0000762f89bdd7bc  vmovaps [rsp+0xA0], xmm11
0000762f89bdd7c5  vmovaps [rsp+0xB0], xmm12
0000762f89bdd7ce  vmovaps [rsp+0xC0], xmm13
0000762f89bdd7d7  vmovaps [rsp+0xD0], xmm14
0000762f89bdd7e0  vmovaps [rsp+0xE0], xmm15
0000762f89bdd7e9  sub rsp, 0x30
0000762f89bdd7ed  movaps [rsp], xmm6
0000762f89bdd7f1  movaps [rsp+0x10], xmm9
0000762f89bdd7f7  movaps [rsp+0x20], xmm7
0000762f89bdd7fc  lea rdi, [rsp]
0000762f89bdd800  mov esi, 0x00
0000762f89bdd805  mov rax, 0x604D6F946530
0000762f89bdd80f  call rax
0000762f89bdd811  movaps xmm6, [rsp]
0000762f89bdd815  add rsp, 0x30
0000762f89bdd819  vmovaps xmm0, [rsp]
0000762f89bdd81e  vmovaps xmm1, [rsp+0x10]
0000762f89bdd824  vmovaps xmm2, [rsp+0x20]
0000762f89bdd82a  vmovaps xmm3, [rsp+0x30]
0000762f89bdd830  vmovaps xmm4, [rsp+0x40]
0000762f89bdd836  vmovaps xmm5, [rsp+0x50]
0000762f89bdd83c  vmovaps xmm7, [rsp+0x60]
0000762f89bdd842  vmovaps xmm8, [rsp+0x70]
0000762f89bdd848  vmovaps xmm9, [rsp+0x80]
0000762f89bdd851  vmovaps xmm10, [rsp+0x90]
0000762f89bdd85a  vmovaps xmm11, [rsp+0xA0]
0000762f89bdd863  vmovaps xmm12, [rsp+0xB0]
0000762f89bdd86c  vmovaps xmm13, [rsp+0xC0]
0000762f89bdd875  vmovaps xmm14, [rsp+0xD0]
0000762f89bdd87e  vmovaps xmm15, [rsp+0xE0]
0000762f89bdd887  add rsp, 0xF0
0000762f89bdd88e  pop r11
0000762f89bdd890  pop r10
0000762f89bdd892  pop r9
0000762f89bdd894  pop r8
0000762f89bdd896  pop rsi
0000762f89bdd897  pop rdi
0000762f89bdd898  pop rdx
0000762f89bdd899  pop rcx
0000762f89bdd89a  pop rax
0000762f89bdd89b  add rsp, 0x08
0000762f89bdd89f  jmp 0x0000762F89BDBE5A
0000762f89bdd8a4  sub rsp, 0x08
0000762f89bdd8a8  push rax
0000762f89bdd8a9  push rcx
0000762f89bdd8aa  push rdx
0000762f89bdd8ab  push rdi
0000762f89bdd8ac  push rsi
0000762f89bdd8ad  push r8
0000762f89bdd8af  push r9
0000762f89bdd8b1  push r10
0000762f89bdd8b3  push r11
0000762f89bdd8b5  sub rsp, 0xF0
0000762f89bdd8bc  vmovaps [rsp], xmm0
0000762f89bdd8c1  vmovaps [rsp+0x10], xmm1
0000762f89bdd8c7  vmovaps [rsp+0x20], xmm2
0000762f89bdd8cd  vmovaps [rsp+0x30], xmm3
0000762f89bdd8d3  vmovaps [rsp+0x40], xmm4
0000762f89bdd8d9  vmovaps [rsp+0x50], xmm5
0000762f89bdd8df  vmovaps [rsp+0x60], xmm6
0000762f89bdd8e5  vmovaps [rsp+0x70], xmm8
0000762f89bdd8eb  vmovaps [rsp+0x80], xmm9
0000762f89bdd8f4  vmovaps [rsp+0x90], xmm10
0000762f89bdd8fd  vmovaps [rsp+0xA0], xmm11
0000762f89bdd906  vmovaps [rsp+0xB0], xmm12
0000762f89bdd90f  vmovaps [rsp+0xC0], xmm13
0000762f89bdd918  vmovaps [rsp+0xD0], xmm14
0000762f89bdd921  vmovaps [rsp+0xE0], xmm15
0000762f89bdd92a  sub rsp, 0x30
0000762f89bdd92e  movaps [rsp], xmm7
0000762f89bdd932  movaps [rsp+0x10], xmm4
0000762f89bdd937  movaps [rsp+0x20], xmm9
0000762f89bdd93d  lea rdi, [rsp]
0000762f89bdd941  mov esi, 0x00
0000762f89bdd946  mov rax, 0x604D6F946530
0000762f89bdd950  call rax
0000762f89bdd952  movaps xmm7, [rsp]
0000762f89bdd956  add rsp, 0x30
0000762f89bdd95a  vmovaps xmm0, [rsp]
0000762f89bdd95f  vmovaps xmm1, [rsp+0x10]
0000762f89bdd965  vmovaps xmm2, [rsp+0x20]
0000762f89bdd96b  vmovaps xmm3, [rsp+0x30]
0000762f89bdd971  vmovaps xmm4, [rsp+0x40]
0000762f89bdd977  vmovaps xmm5, [rsp+0x50]
0000762f89bdd97d  vmovaps xmm6, [rsp+0x60]
0000762f89bdd983  vmovaps xmm8, [rsp+0x70]
0000762f89bdd989  vmovaps xmm9, [rsp+0x80]
0000762f89bdd992  vmovaps xmm10, [rsp+0x90]
0000762f89bdd99b  vmovaps xmm11, [rsp+0xA0]
0000762f89bdd9a4  vmovaps xmm12, [rsp+0xB0]
0000762f89bdd9ad  vmovaps xmm13, [rsp+0xC0]
0000762f89bdd9b6  vmovaps xmm14, [rsp+0xD0]
0000762f89bdd9bf  vmovaps xmm15, [rsp+0xE0]
0000762f89bdd9c8  add rsp, 0xF0
0000762f89bdd9cf  pop r11
0000762f89bdd9d1  pop r10
0000762f89bdd9d3  pop r9
0000762f89bdd9d5  pop r8
0000762f89bdd9d7  pop rsi
0000762f89bdd9d8  pop rdi
0000762f89bdd9d9  pop rdx
0000762f89bdd9da  pop rcx
0000762f89bdd9db  pop rax
0000762f89bdd9dc  add rsp, 0x08
0000762f89bdd9e0  jmp 0x0000762F89BDBE87
0000762f89bdd9e5  sub rsp, 0x08
0000762f89bdd9e9  push rax
0000762f89bdd9ea  push rcx
0000762f89bdd9eb  push rdx
0000762f89bdd9ec  push rdi
0000762f89bdd9ed  push rsi
0000762f89bdd9ee  push r8
0000762f89bdd9f0  push r9
0000762f89bdd9f2  push r10
0000762f89bdd9f4  push r11
0000762f89bdd9f6  sub rsp, 0xF0
0000762f89bdd9fd  vmovaps [rsp], xmm0
0000762f89bdda02  vmovaps [rsp+0x10], xmm1
0000762f89bdda08  vmovaps [rsp+0x20], xmm2
0000762f89bdda0e  vmovaps [rsp+0x30], xmm3
0000762f89bdda14  vmovaps [rsp+0x40], xmm5
0000762f89bdda1a  vmovaps [rsp+0x50], xmm6
0000762f89bdda20  vmovaps [rsp+0x60], xmm7
0000762f89bdda26  vmovaps [rsp+0x70], xmm8
0000762f89bdda2c  vmovaps [rsp+0x80], xmm9
0000762f89bdda35  vmovaps [rsp+0x90], xmm10
0000762f89bdda3e  vmovaps [rsp+0xA0], xmm11
0000762f89bdda47  vmovaps [rsp+0xB0], xmm12
0000762f89bdda50  vmovaps [rsp+0xC0], xmm13
0000762f89bdda59  vmovaps [rsp+0xD0], xmm14
0000762f89bdda62  vmovaps [rsp+0xE0], xmm15
0000762f89bdda6b  sub rsp, 0x30
0000762f89bdda6f  movaps [rsp], xmm4
0000762f89bdda73  movaps [rsp+0x10], xmm15
0000762f89bdda79  movaps [rsp+0x20], xmm9
0000762f89bdda7f  lea rdi, [rsp]
0000762f89bdda83  mov esi, 0x00
0000762f89bdda88  mov rax, 0x604D6F946530
0000762f89bdda92  call rax
0000762f89bdda94  movaps xmm4, [rsp]
0000762f89bdda98  add rsp, 0x30
0000762f89bdda9c  vmovaps xmm0, [rsp]
0000762f89bddaa1  vmovaps xmm1, [rsp+0x10]
0000762f89bddaa7  vmovaps xmm2, [rsp+0x20]
0000762f89bddaad  vmovaps xmm3, [rsp+0x30]
0000762f89bddab3  vmovaps xmm5, [rsp+0x40]
0000762f89bddab9  vmovaps xmm6, [rsp+0x50]
0000762f89bddabf  vmovaps xmm7, [rsp+0x60]
0000762f89bddac5  vmovaps xmm8, [rsp+0x70]
0000762f89bddacb  vmovaps xmm9, [rsp+0x80]
0000762f89bddad4  vmovaps xmm10, [rsp+0x90]
0000762f89bddadd  vmovaps xmm11, [rsp+0xA0]
0000762f89bddae6  vmovaps xmm12, [rsp+0xB0]
0000762f89bddaef  vmovaps xmm13, [rsp+0xC0]
0000762f89bddaf8  vmovaps xmm14, [rsp+0xD0]
0000762f89bddb01  vmovaps xmm15, [rsp+0xE0]
0000762f89bddb0a  add rsp, 0xF0
0000762f89bddb11  pop r11
0000762f89bddb13  pop r10
0000762f89bddb15  pop r9
0000762f89bddb17  pop r8
0000762f89bddb19  pop rsi
0000762f89bddb1a  pop rdi
0000762f89bddb1b  pop rdx
0000762f89bddb1c  pop rcx
0000762f89bddb1d  pop rax
0000762f89bddb1e  add rsp, 0x08
0000762f89bddb22  jmp 0x0000762F89BDBEAC
0000762f89bddb27  call 0x0000762F89AC4620
0000762f89bddb2c  jmp 0x0000762F89BDBEB9
0000762f89bddb31  sub rsp, 0x08
0000762f89bddb35  push rax
0000762f89bddb36  push rcx
0000762f89bddb37  push rdx
0000762f89bddb38  push rdi
0000762f89bddb39  push rsi
0000762f89bddb3a  push r8
0000762f89bddb3c  push r9
0000762f89bddb3e  push r10
0000762f89bddb40  push r11
0000762f89bddb42  sub rsp, 0xF0
0000762f89bddb49  vmovaps [rsp], xmm0
0000762f89bddb4e  vmovaps [rsp+0x10], xmm1
0000762f89bddb54  vmovaps [rsp+0x20], xmm2
0000762f89bddb5a  vmovaps [rsp+0x30], xmm4
0000762f89bddb60  vmovaps [rsp+0x40], xmm5
0000762f89bddb66  vmovaps [rsp+0x50], xmm6
0000762f89bddb6c  vmovaps [rsp+0x60], xmm7
0000762f89bddb72  vmovaps [rsp+0x70], xmm8
0000762f89bddb78  vmovaps [rsp+0x80], xmm9
0000762f89bddb81  vmovaps [rsp+0x90], xmm10
0000762f89bddb8a  vmovaps [rsp+0xA0], xmm11
0000762f89bddb93  vmovaps [rsp+0xB0], xmm12
0000762f89bddb9c  vmovaps [rsp+0xC0], xmm13
0000762f89bddba5  vmovaps [rsp+0xD0], xmm14
0000762f89bddbae  vmovaps [rsp+0xE0], xmm15
0000762f89bddbb7  sub rsp, 0x30
0000762f89bddbbb  movaps [rsp], xmm3
0000762f89bddbbf  movaps [rsp+0x10], xmm1
0000762f89bddbc4  movaps [rsp+0x20], xmm9
0000762f89bddbca  lea rdi, [rsp]
0000762f89bddbce  mov esi, 0x00
0000762f89bddbd3  mov rax, 0x604D6F946530
0000762f89bddbdd  call rax
0000762f89bddbdf  movaps xmm3, [rsp]
0000762f89bddbe3  add rsp, 0x30
0000762f89bddbe7  vmovaps xmm0, [rsp]
0000762f89bddbec  vmovaps xmm1, [rsp+0x10]
0000762f89bddbf2  vmovaps xmm2, [rsp+0x20]
0000762f89bddbf8  vmovaps xmm4, [rsp+0x30]
0000762f89bddbfe  vmovaps xmm5, [rsp+0x40]
0000762f89bddc04  vmovaps xmm6, [rsp+0x50]
0000762f89bddc0a  vmovaps xmm7, [rsp+0x60]
0000762f89bddc10  vmovaps xmm8, [rsp+0x70]
0000762f89bddc16  vmovaps xmm9, [rsp+0x80]
0000762f89bddc1f  vmovaps xmm10, [rsp+0x90]
0000762f89bddc28  vmovaps xmm11, [rsp+0xA0]
0000762f89bddc31  vmovaps xmm12, [rsp+0xB0]
0000762f89bddc3a  vmovaps xmm13, [rsp+0xC0]
0000762f89bddc43  vmovaps xmm14, [rsp+0xD0]
0000762f89bddc4c  vmovaps xmm15, [rsp+0xE0]
0000762f89bddc55  add rsp, 0xF0
0000762f89bddc5c  pop r11
0000762f89bddc5e  pop r10
0000762f89bddc60  pop r9
0000762f89bddc62  pop r8
0000762f89bddc64  pop rsi
0000762f89bddc65  pop rdi
0000762f89bddc66  pop rdx
0000762f89bddc67  pop rcx
0000762f89bddc68  pop rax
0000762f89bddc69  add rsp, 0x08
0000762f89bddc6d  jmp 0x0000762F89BDBEF6
0000762f89bddc72  sub rsp, 0x08
0000762f89bddc76  push rax
0000762f89bddc77  push rcx
0000762f89bddc78  push rdx
0000762f89bddc79  push rdi
0000762f89bddc7a  push rsi
0000762f89bddc7b  push r8
0000762f89bddc7d  push r9
0000762f89bddc7f  push r10
0000762f89bddc81  push r11
0000762f89bddc83  sub rsp, 0xF0
0000762f89bddc8a  vmovaps [rsp], xmm0
0000762f89bddc8f  vmovaps [rsp+0x10], xmm2
0000762f89bddc95  vmovaps [rsp+0x20], xmm3
0000762f89bddc9b  vmovaps [rsp+0x30], xmm4
0000762f89bddca1  vmovaps [rsp+0x40], xmm5
0000762f89bddca7  vmovaps [rsp+0x50], xmm6
0000762f89bddcad  vmovaps [rsp+0x60], xmm7
0000762f89bddcb3  vmovaps [rsp+0x70], xmm8
0000762f89bddcb9  vmovaps [rsp+0x80], xmm9
0000762f89bddcc2  vmovaps [rsp+0x90], xmm10
0000762f89bddccb  vmovaps [rsp+0xA0], xmm11
0000762f89bddcd4  vmovaps [rsp+0xB0], xmm12
0000762f89bddcdd  vmovaps [rsp+0xC0], xmm13
0000762f89bddce6  vmovaps [rsp+0xD0], xmm14
0000762f89bddcef  vmovaps [rsp+0xE0], xmm15
0000762f89bddcf8  sub rsp, 0x30
0000762f89bddcfc  movaps [rsp], xmm1
0000762f89bddd00  movaps [rsp+0x10], xmm15
0000762f89bddd06  movaps [rsp+0x20], xmm9
0000762f89bddd0c  lea rdi, [rsp]
0000762f89bddd10  mov esi, 0x00
0000762f89bddd15  mov rax, 0x604D6F946530
0000762f89bddd1f  call rax
0000762f89bddd21  movaps xmm1, [rsp]
0000762f89bddd25  add rsp, 0x30
0000762f89bddd29  vmovaps xmm0, [rsp]
0000762f89bddd2e  vmovaps xmm2, [rsp+0x10]
0000762f89bddd34  vmovaps xmm3, [rsp+0x20]
0000762f89bddd3a  vmovaps xmm4, [rsp+0x30]
0000762f89bddd40  vmovaps xmm5, [rsp+0x40]
0000762f89bddd46  vmovaps xmm6, [rsp+0x50]
0000762f89bddd4c  vmovaps xmm7, [rsp+0x60]
0000762f89bddd52  vmovaps xmm8, [rsp+0x70]
0000762f89bddd58  vmovaps xmm9, [rsp+0x80]
0000762f89bddd61  vmovaps xmm10, [rsp+0x90]
0000762f89bddd6a  vmovaps xmm11, [rsp+0xA0]
0000762f89bddd73  vmovaps xmm12, [rsp+0xB0]
0000762f89bddd7c  vmovaps xmm13, [rsp+0xC0]
0000762f89bddd85  vmovaps xmm14, [rsp+0xD0]
0000762f89bddd8e  vmovaps xmm15, [rsp+0xE0]
0000762f89bddd97  add rsp, 0xF0
0000762f89bddd9e  pop r11
0000762f89bddda0  pop r10
0000762f89bddda2  pop r9
0000762f89bddda4  pop r8
0000762f89bddda6  pop rsi
0000762f89bddda7  pop rdi
0000762f89bddda8  pop rdx
0000762f89bddda9  pop rcx
0000762f89bdddaa  pop rax
0000762f89bdddab  add rsp, 0x08
0000762f89bdddaf  jmp 0x0000762F89BDBF7E
0000762f89bdddb4  call 0x0000762F89AC4620
0000762f89bdddb9  jmp 0x0000762F89BDBF8B
0000762f89bdddbe  sub rsp, 0x08
0000762f89bdddc2  push rax
0000762f89bdddc3  push rcx
0000762f89bdddc4  push rdx
0000762f89bdddc5  push rdi
0000762f89bdddc6  push rsi
0000762f89bdddc7  push r8
0000762f89bdddc9  push r9
0000762f89bdddcb  push r10
0000762f89bdddcd  push r11
0000762f89bdddcf  sub rsp, 0xF0
0000762f89bdddd6  vmovaps [rsp], xmm0
0000762f89bddddb  vmovaps [rsp+0x10], xmm2
0000762f89bddde1  vmovaps [rsp+0x20], xmm3
0000762f89bddde7  vmovaps [rsp+0x30], xmm4
0000762f89bddded  vmovaps [rsp+0x40], xmm5
0000762f89bdddf3  vmovaps [rsp+0x50], xmm6
0000762f89bdddf9  vmovaps [rsp+0x60], xmm7
0000762f89bdddff  vmovaps [rsp+0x70], xmm8
0000762f89bdde05  vmovaps [rsp+0x80], xmm9
0000762f89bdde0e  vmovaps [rsp+0x90], xmm10
0000762f89bdde17  vmovaps [rsp+0xA0], xmm11
0000762f89bdde20  vmovaps [rsp+0xB0], xmm12
0000762f89bdde29  vmovaps [rsp+0xC0], xmm13
0000762f89bdde32  vmovaps [rsp+0xD0], xmm14
0000762f89bdde3b  vmovaps [rsp+0xE0], xmm15
0000762f89bdde44  sub rsp, 0x30
0000762f89bdde48  movaps [rsp], xmm1
0000762f89bdde4c  movaps [rsp+0x10], xmm5
0000762f89bdde51  movaps [rsp+0x20], xmm7
0000762f89bdde56  lea rdi, [rsp]
0000762f89bdde5a  mov esi, 0x00
0000762f89bdde5f  mov rax, 0x604D6F946530
0000762f89bdde69  call rax
0000762f89bdde6b  movaps xmm1, [rsp]
0000762f89bdde6f  add rsp, 0x30
0000762f89bdde73  vmovaps xmm0, [rsp]
0000762f89bdde78  vmovaps xmm2, [rsp+0x10]
0000762f89bdde7e  vmovaps xmm3, [rsp+0x20]
0000762f89bdde84  vmovaps xmm4, [rsp+0x30]
0000762f89bdde8a  vmovaps xmm5, [rsp+0x40]
0000762f89bdde90  vmovaps xmm6, [rsp+0x50]
0000762f89bdde96  vmovaps xmm7, [rsp+0x60]
0000762f89bdde9c  vmovaps xmm8, [rsp+0x70]
0000762f89bddea2  vmovaps xmm9, [rsp+0x80]
0000762f89bddeab  vmovaps xmm10, [rsp+0x90]
0000762f89bddeb4  vmovaps xmm11, [rsp+0xA0]
0000762f89bddebd  vmovaps xmm12, [rsp+0xB0]
0000762f89bddec6  vmovaps xmm13, [rsp+0xC0]
0000762f89bddecf  vmovaps xmm14, [rsp+0xD0]
0000762f89bdded8  vmovaps xmm15, [rsp+0xE0]
0000762f89bddee1  add rsp, 0xF0
0000762f89bddee8  pop r11
0000762f89bddeea  pop r10
0000762f89bddeec  pop r9
0000762f89bddeee  pop r8
0000762f89bddef0  pop rsi
0000762f89bddef1  pop rdi
0000762f89bddef2  pop rdx
0000762f89bddef3  pop rcx
0000762f89bddef4  pop rax
0000762f89bddef5  add rsp, 0x08
0000762f89bddef9  jmp 0x0000762F89BDC030
0000762f89bddefe  sub rsp, 0x08
0000762f89bddf02  push rax
0000762f89bddf03  push rcx
0000762f89bddf04  push rdx
0000762f89bddf05  push rdi
0000762f89bddf06  push rsi
0000762f89bddf07  push r8
0000762f89bddf09  push r9
0000762f89bddf0b  push r10
0000762f89bddf0d  push r11
0000762f89bddf0f  sub rsp, 0xF0
0000762f89bddf16  vmovaps [rsp], xmm0
0000762f89bddf1b  vmovaps [rsp+0x10], xmm1
0000762f89bddf21  vmovaps [rsp+0x20], xmm2
0000762f89bddf27  vmovaps [rsp+0x30], xmm3
0000762f89bddf2d  vmovaps [rsp+0x40], xmm4
0000762f89bddf33  vmovaps [rsp+0x50], xmm5
0000762f89bddf39  vmovaps [rsp+0x60], xmm6
0000762f89bddf3f  vmovaps [rsp+0x70], xmm8
0000762f89bddf45  vmovaps [rsp+0x80], xmm9
0000762f89bddf4e  vmovaps [rsp+0x90], xmm10
0000762f89bddf57  vmovaps [rsp+0xA0], xmm11
0000762f89bddf60  vmovaps [rsp+0xB0], xmm12
0000762f89bddf69  vmovaps [rsp+0xC0], xmm13
0000762f89bddf72  vmovaps [rsp+0xD0], xmm14
0000762f89bddf7b  vmovaps [rsp+0xE0], xmm15
0000762f89bddf84  sub rsp, 0x30
0000762f89bddf88  movaps [rsp], xmm7
0000762f89bddf8c  movaps [rsp+0x10], xmm5
0000762f89bddf91  movaps [rsp+0x20], xmm15
0000762f89bddf97  lea rdi, [rsp]
0000762f89bddf9b  mov esi, 0x00
0000762f89bddfa0  mov rax, 0x604D6F946530
0000762f89bddfaa  call rax
0000762f89bddfac  movaps xmm7, [rsp]
0000762f89bddfb0  add rsp, 0x30
0000762f89bddfb4  vmovaps xmm0, [rsp]
0000762f89bddfb9  vmovaps xmm1, [rsp+0x10]
0000762f89bddfbf  vmovaps xmm2, [rsp+0x20]
0000762f89bddfc5  vmovaps xmm3, [rsp+0x30]
0000762f89bddfcb  vmovaps xmm4, [rsp+0x40]
0000762f89bddfd1  vmovaps xmm5, [rsp+0x50]
0000762f89bddfd7  vmovaps xmm6, [rsp+0x60]
0000762f89bddfdd  vmovaps xmm8, [rsp+0x70]
0000762f89bddfe3  vmovaps xmm9, [rsp+0x80]
0000762f89bddfec  vmovaps xmm10, [rsp+0x90]
0000762f89bddff5  vmovaps xmm11, [rsp+0xA0]
0000762f89bddffe  vmovaps xmm12, [rsp+0xB0]
0000762f89bde007  vmovaps xmm13, [rsp+0xC0]
0000762f89bde010  vmovaps xmm14, [rsp+0xD0]
0000762f89bde019  vmovaps xmm15, [rsp+0xE0]
0000762f89bde022  add rsp, 0xF0
0000762f89bde029  pop r11
0000762f89bde02b  pop r10
0000762f89bde02d  pop r9
0000762f89bde02f  pop r8
0000762f89bde031  pop rsi
0000762f89bde032  pop rdi
0000762f89bde033  pop rdx
0000762f89bde034  pop rcx
0000762f89bde035  pop rax
0000762f89bde036  add rsp, 0x08
0000762f89bde03a  jmp 0x0000762F89BDC066
0000762f89bde03f  call 0x0000762F89AB52F0
0000762f89bde044  jmp 0x0000762F89BDC073
0000762f89bde049  sub rsp, 0x08
0000762f89bde04d  push rax
0000762f89bde04e  push rcx
0000762f89bde04f  push rdx
0000762f89bde050  push rdi
0000762f89bde051  push rsi
0000762f89bde052  push r8
0000762f89bde054  push r9
0000762f89bde056  push r10
0000762f89bde058  push r11
0000762f89bde05a  sub rsp, 0xF0
0000762f89bde061  vmovaps [rsp], xmm0
0000762f89bde066  vmovaps [rsp+0x10], xmm1
0000762f89bde06c  vmovaps [rsp+0x20], xmm2
0000762f89bde072  vmovaps [rsp+0x30], xmm3
0000762f89bde078  vmovaps [rsp+0x40], xmm4
0000762f89bde07e  vmovaps [rsp+0x50], xmm5
0000762f89bde084  vmovaps [rsp+0x60], xmm6
0000762f89bde08a  vmovaps [rsp+0x70], xmm7
0000762f89bde090  vmovaps [rsp+0x80], xmm8
0000762f89bde099  vmovaps [rsp+0x90], xmm9
0000762f89bde0a2  vmovaps [rsp+0xA0], xmm10
0000762f89bde0ab  vmovaps [rsp+0xB0], xmm11
0000762f89bde0b4  vmovaps [rsp+0xC0], xmm12
0000762f89bde0bd  vmovaps [rsp+0xD0], xmm13
0000762f89bde0c6  vmovaps [rsp+0xE0], xmm14
0000762f89bde0cf  sub rsp, 0x30
0000762f89bde0d3  movaps [rsp], xmm15
0000762f89bde0d8  movaps [rsp+0x10], xmm5
0000762f89bde0dd  movaps [rsp+0x20], xmm3
0000762f89bde0e2  lea rdi, [rsp]
0000762f89bde0e6  mov esi, 0x00
0000762f89bde0eb  mov rax, 0x604D6F946530
0000762f89bde0f5  call rax
0000762f89bde0f7  movaps xmm15, [rsp]
0000762f89bde0fc  add rsp, 0x30
0000762f89bde100  vmovaps xmm0, [rsp]
0000762f89bde105  vmovaps xmm1, [rsp+0x10]
0000762f89bde10b  vmovaps xmm2, [rsp+0x20]
0000762f89bde111  vmovaps xmm3, [rsp+0x30]
0000762f89bde117  vmovaps xmm4, [rsp+0x40]
0000762f89bde11d  vmovaps xmm5, [rsp+0x50]
0000762f89bde123  vmovaps xmm6, [rsp+0x60]
0000762f89bde129  vmovaps xmm7, [rsp+0x70]
0000762f89bde12f  vmovaps xmm8, [rsp+0x80]
0000762f89bde138  vmovaps xmm9, [rsp+0x90]
0000762f89bde141  vmovaps xmm10, [rsp+0xA0]
0000762f89bde14a  vmovaps xmm11, [rsp+0xB0]
0000762f89bde153  vmovaps xmm12, [rsp+0xC0]
0000762f89bde15c  vmovaps xmm13, [rsp+0xD0]
0000762f89bde165  vmovaps xmm14, [rsp+0xE0]
0000762f89bde16e  add rsp, 0xF0
0000762f89bde175  pop r11
0000762f89bde177  pop r10
0000762f89bde179  pop r9
0000762f89bde17b  pop r8
0000762f89bde17d  pop rsi
0000762f89bde17e  pop rdi
0000762f89bde17f  pop rdx
0000762f89bde180  pop rcx
0000762f89bde181  pop rax
0000762f89bde182  add rsp, 0x08
0000762f89bde186  jmp 0x0000762F89BDC099
0000762f89bde18b  sub rsp, 0x08
0000762f89bde18f  push rax
0000762f89bde190  push rcx
0000762f89bde191  push rdx
0000762f89bde192  push rdi
0000762f89bde193  push rsi
0000762f89bde194  push r8
0000762f89bde196  push r9
0000762f89bde198  push r10
0000762f89bde19a  push r11
0000762f89bde19c  sub rsp, 0xF0
0000762f89bde1a3  vmovaps [rsp], xmm0
0000762f89bde1a8  vmovaps [rsp+0x10], xmm2
0000762f89bde1ae  vmovaps [rsp+0x20], xmm3
0000762f89bde1b4  vmovaps [rsp+0x30], xmm4
0000762f89bde1ba  vmovaps [rsp+0x40], xmm5
0000762f89bde1c0  vmovaps [rsp+0x50], xmm6
0000762f89bde1c6  vmovaps [rsp+0x60], xmm7
0000762f89bde1cc  vmovaps [rsp+0x70], xmm8
0000762f89bde1d2  vmovaps [rsp+0x80], xmm9
0000762f89bde1db  vmovaps [rsp+0x90], xmm10
0000762f89bde1e4  vmovaps [rsp+0xA0], xmm11
0000762f89bde1ed  vmovaps [rsp+0xB0], xmm12
0000762f89bde1f6  vmovaps [rsp+0xC0], xmm13
0000762f89bde1ff  vmovaps [rsp+0xD0], xmm14
0000762f89bde208  vmovaps [rsp+0xE0], xmm15
0000762f89bde211  sub rsp, 0x30
0000762f89bde215  movaps [rsp], xmm1
0000762f89bde219  movaps [rsp+0x10], xmm5
0000762f89bde21e  movaps [rsp+0x20], xmm4
0000762f89bde223  lea rdi, [rsp]
0000762f89bde227  mov esi, 0x00
0000762f89bde22c  mov rax, 0x604D6F946530
0000762f89bde236  call rax
0000762f89bde238  movaps xmm1, [rsp]
0000762f89bde23c  add rsp, 0x30
0000762f89bde240  vmovaps xmm0, [rsp]
0000762f89bde245  vmovaps xmm2, [rsp+0x10]
0000762f89bde24b  vmovaps xmm3, [rsp+0x20]
0000762f89bde251  vmovaps xmm4, [rsp+0x30]
0000762f89bde257  vmovaps xmm5, [rsp+0x40]
0000762f89bde25d  vmovaps xmm6, [rsp+0x50]
0000762f89bde263  vmovaps xmm7, [rsp+0x60]
0000762f89bde269  vmovaps xmm8, [rsp+0x70]
0000762f89bde26f  vmovaps xmm9, [rsp+0x80]
0000762f89bde278  vmovaps xmm10, [rsp+0x90]
0000762f89bde281  vmovaps xmm11, [rsp+0xA0]
0000762f89bde28a  vmovaps xmm12, [rsp+0xB0]
0000762f89bde293  vmovaps xmm13, [rsp+0xC0]
0000762f89bde29c  vmovaps xmm14, [rsp+0xD0]
0000762f89bde2a5  vmovaps xmm15, [rsp+0xE0]
0000762f89bde2ae  add rsp, 0xF0
0000762f89bde2b5  pop r11
0000762f89bde2b7  pop r10
0000762f89bde2b9  pop r9
0000762f89bde2bb  pop r8
0000762f89bde2bd  pop rsi
0000762f89bde2be  pop rdi
0000762f89bde2bf  pop rdx
0000762f89bde2c0  pop rcx
0000762f89bde2c1  pop rax
0000762f89bde2c2  add rsp, 0x08
0000762f89bde2c6  jmp 0x0000762F89BDC0B9
0000762f89bde2cb  sub rsp, 0x08
0000762f89bde2cf  push rax
0000762f89bde2d0  push rcx
0000762f89bde2d1  push rdx
0000762f89bde2d2  push rdi
0000762f89bde2d3  push rsi
0000762f89bde2d4  push r8
0000762f89bde2d6  push r9
0000762f89bde2d8  push r10
0000762f89bde2da  push r11
0000762f89bde2dc  sub rsp, 0xF0
0000762f89bde2e3  vmovaps [rsp], xmm0
0000762f89bde2e8  vmovaps [rsp+0x10], xmm1
0000762f89bde2ee  vmovaps [rsp+0x20], xmm2
0000762f89bde2f4  vmovaps [rsp+0x30], xmm3
0000762f89bde2fa  vmovaps [rsp+0x40], xmm5
0000762f89bde300  vmovaps [rsp+0x50], xmm6
0000762f89bde306  vmovaps [rsp+0x60], xmm7
0000762f89bde30c  vmovaps [rsp+0x70], xmm8
0000762f89bde312  vmovaps [rsp+0x80], xmm9
0000762f89bde31b  vmovaps [rsp+0x90], xmm10
0000762f89bde324  vmovaps [rsp+0xA0], xmm11
0000762f89bde32d  vmovaps [rsp+0xB0], xmm12
0000762f89bde336  vmovaps [rsp+0xC0], xmm13
0000762f89bde33f  vmovaps [rsp+0xD0], xmm14
0000762f89bde348  vmovaps [rsp+0xE0], xmm15
0000762f89bde351  sub rsp, 0x30
0000762f89bde355  movaps [rsp], xmm4
0000762f89bde359  movaps [rsp+0x10], xmm3
0000762f89bde35e  movaps [rsp+0x20], xmm5
0000762f89bde363  lea rdi, [rsp]
0000762f89bde367  mov esi, 0x00
0000762f89bde36c  mov rax, 0x604D6F946530
0000762f89bde376  call rax
0000762f89bde378  movaps xmm4, [rsp]
0000762f89bde37c  add rsp, 0x30
0000762f89bde380  vmovaps xmm0, [rsp]
0000762f89bde385  vmovaps xmm1, [rsp+0x10]
0000762f89bde38b  vmovaps xmm2, [rsp+0x20]
0000762f89bde391  vmovaps xmm3, [rsp+0x30]
0000762f89bde397  vmovaps xmm5, [rsp+0x40]
0000762f89bde39d  vmovaps xmm6, [rsp+0x50]
0000762f89bde3a3  vmovaps xmm7, [rsp+0x60]
0000762f89bde3a9  vmovaps xmm8, [rsp+0x70]
0000762f89bde3af  vmovaps xmm9, [rsp+0x80]
0000762f89bde3b8  vmovaps xmm10, [rsp+0x90]
0000762f89bde3c1  vmovaps xmm11, [rsp+0xA0]
0000762f89bde3ca  vmovaps xmm12, [rsp+0xB0]
0000762f89bde3d3  vmovaps xmm13, [rsp+0xC0]
0000762f89bde3dc  vmovaps xmm14, [rsp+0xD0]
0000762f89bde3e5  vmovaps xmm15, [rsp+0xE0]
0000762f89bde3ee  add rsp, 0xF0
0000762f89bde3f5  pop r11
0000762f89bde3f7  pop r10
0000762f89bde3f9  pop r9
0000762f89bde3fb  pop r8
0000762f89bde3fd  pop rsi
0000762f89bde3fe  pop rdi
0000762f89bde3ff  pop rdx
0000762f89bde400  pop rcx
0000762f89bde401  pop rax
0000762f89bde402  add rsp, 0x08
0000762f89bde406  jmp 0x0000762F89BDC107
0000762f89bde40b  call 0x0000762F89AB52F0
0000762f89bde410  jmp 0x0000762F89BDC114
0000762f89bde415  sub rsp, 0x08
0000762f89bde419  push rax
0000762f89bde41a  push rcx
0000762f89bde41b  push rdx
0000762f89bde41c  push rdi
0000762f89bde41d  push rsi
0000762f89bde41e  push r8
0000762f89bde420  push r9
0000762f89bde422  push r10
0000762f89bde424  push r11
0000762f89bde426  sub rsp, 0xF0
0000762f89bde42d  vmovaps [rsp], xmm0
0000762f89bde432  vmovaps [rsp+0x10], xmm1
0000762f89bde438  vmovaps [rsp+0x20], xmm2
0000762f89bde43e  vmovaps [rsp+0x30], xmm3
0000762f89bde444  vmovaps [rsp+0x40], xmm4
0000762f89bde44a  vmovaps [rsp+0x50], xmm6
0000762f89bde450  vmovaps [rsp+0x60], xmm7
0000762f89bde456  vmovaps [rsp+0x70], xmm8
0000762f89bde45c  vmovaps [rsp+0x80], xmm9
0000762f89bde465  vmovaps [rsp+0x90], xmm10
0000762f89bde46e  vmovaps [rsp+0xA0], xmm11
0000762f89bde477  vmovaps [rsp+0xB0], xmm12
0000762f89bde480  vmovaps [rsp+0xC0], xmm13
0000762f89bde489  vmovaps [rsp+0xD0], xmm14
0000762f89bde492  vmovaps [rsp+0xE0], xmm15
0000762f89bde49b  sub rsp, 0x30
0000762f89bde49f  movaps [rsp], xmm5
0000762f89bde4a3  movaps [rsp+0x10], xmm6
0000762f89bde4a8  movaps [rsp+0x20], xmm3
0000762f89bde4ad  lea rdi, [rsp]
0000762f89bde4b1  mov esi, 0x00
0000762f89bde4b6  mov rax, 0x604D6F946530
0000762f89bde4c0  call rax
0000762f89bde4c2  movaps xmm5, [rsp]
0000762f89bde4c6  add rsp, 0x30
0000762f89bde4ca  vmovaps xmm0, [rsp]
0000762f89bde4cf  vmovaps xmm1, [rsp+0x10]
0000762f89bde4d5  vmovaps xmm2, [rsp+0x20]
0000762f89bde4db  vmovaps xmm3, [rsp+0x30]
0000762f89bde4e1  vmovaps xmm4, [rsp+0x40]
0000762f89bde4e7  vmovaps xmm6, [rsp+0x50]
0000762f89bde4ed  vmovaps xmm7, [rsp+0x60]
0000762f89bde4f3  vmovaps xmm8, [rsp+0x70]
0000762f89bde4f9  vmovaps xmm9, [rsp+0x80]
0000762f89bde502  vmovaps xmm10, [rsp+0x90]
0000762f89bde50b  vmovaps xmm11, [rsp+0xA0]
0000762f89bde514  vmovaps xmm12, [rsp+0xB0]
0000762f89bde51d  vmovaps xmm13, [rsp+0xC0]
0000762f89bde526  vmovaps xmm14, [rsp+0xD0]
0000762f89bde52f  vmovaps xmm15, [rsp+0xE0]
0000762f89bde538  add rsp, 0xF0
0000762f89bde53f  pop r11
0000762f89bde541  pop r10
0000762f89bde543  pop r9
0000762f89bde545  pop r8
0000762f89bde547  pop rsi
0000762f89bde548  pop rdi
0000762f89bde549  pop rdx
0000762f89bde54a  pop rcx
0000762f89bde54b  pop rax
0000762f89bde54c  add rsp, 0x08
0000762f89bde550  jmp 0x0000762F89BDC13A
0000762f89bde555  sub rsp, 0x08
0000762f89bde559  push rax
0000762f89bde55a  push rcx
0000762f89bde55b  push rdx
0000762f89bde55c  push rdi
0000762f89bde55d  push rsi
0000762f89bde55e  push r8
0000762f89bde560  push r9
0000762f89bde562  push r10
0000762f89bde564  push r11
0000762f89bde566  sub rsp, 0xF0
0000762f89bde56d  vmovaps [rsp], xmm0
0000762f89bde572  vmovaps [rsp+0x10], xmm1
0000762f89bde578  vmovaps [rsp+0x20], xmm2
0000762f89bde57e  vmovaps [rsp+0x30], xmm3
0000762f89bde584  vmovaps [rsp+0x40], xmm4
0000762f89bde58a  vmovaps [rsp+0x50], xmm5
0000762f89bde590  vmovaps [rsp+0x60], xmm7
0000762f89bde596  vmovaps [rsp+0x70], xmm8
0000762f89bde59c  vmovaps [rsp+0x80], xmm9
0000762f89bde5a5  vmovaps [rsp+0x90], xmm10
0000762f89bde5ae  vmovaps [rsp+0xA0], xmm11
0000762f89bde5b7  vmovaps [rsp+0xB0], xmm12
0000762f89bde5c0  vmovaps [rsp+0xC0], xmm13
0000762f89bde5c9  vmovaps [rsp+0xD0], xmm14
0000762f89bde5d2  vmovaps [rsp+0xE0], xmm15
0000762f89bde5db  sub rsp, 0x30
0000762f89bde5df  movaps [rsp], xmm6
0000762f89bde5e3  movaps [rsp+0x10], xmm9
0000762f89bde5e9  movaps [rsp+0x20], xmm1
0000762f89bde5ee  lea rdi, [rsp]
0000762f89bde5f2  mov esi, 0x00
0000762f89bde5f7  mov rax, 0x604D6F946530
0000762f89bde601  call rax
0000762f89bde603  movaps xmm6, [rsp]
0000762f89bde607  add rsp, 0x30
0000762f89bde60b  vmovaps xmm0, [rsp]
0000762f89bde610  vmovaps xmm1, [rsp+0x10]
0000762f89bde616  vmovaps xmm2, [rsp+0x20]
0000762f89bde61c  vmovaps xmm3, [rsp+0x30]
0000762f89bde622  vmovaps xmm4, [rsp+0x40]
0000762f89bde628  vmovaps xmm5, [rsp+0x50]
0000762f89bde62e  vmovaps xmm7, [rsp+0x60]
0000762f89bde634  vmovaps xmm8, [rsp+0x70]
0000762f89bde63a  vmovaps xmm9, [rsp+0x80]
0000762f89bde643  vmovaps xmm10, [rsp+0x90]
0000762f89bde64c  vmovaps xmm11, [rsp+0xA0]
0000762f89bde655  vmovaps xmm12, [rsp+0xB0]
0000762f89bde65e  vmovaps xmm13, [rsp+0xC0]
0000762f89bde667  vmovaps xmm14, [rsp+0xD0]
0000762f89bde670  vmovaps xmm15, [rsp+0xE0]
0000762f89bde679  add rsp, 0xF0
0000762f89bde680  pop r11
0000762f89bde682  pop r10
0000762f89bde684  pop r9
0000762f89bde686  pop r8
0000762f89bde688  pop rsi
0000762f89bde689  pop rdi
0000762f89bde68a  pop rdx
0000762f89bde68b  pop rcx
0000762f89bde68c  pop rax
0000762f89bde68d  add rsp, 0x08
0000762f89bde691  jmp 0x0000762F89BDC15E
0000762f89bde696  sub rsp, 0x08
0000762f89bde69a  push rax
0000762f89bde69b  push rcx
0000762f89bde69c  push rdx
0000762f89bde69d  push rdi
0000762f89bde69e  push rsi
0000762f89bde69f  push r8
0000762f89bde6a1  push r9
0000762f89bde6a3  push r10
0000762f89bde6a5  push r11
0000762f89bde6a7  sub rsp, 0xF0
0000762f89bde6ae  vmovaps [rsp], xmm0
0000762f89bde6b3  vmovaps [rsp+0x10], xmm1
0000762f89bde6b9  vmovaps [rsp+0x20], xmm2
0000762f89bde6bf  vmovaps [rsp+0x30], xmm3
0000762f89bde6c5  vmovaps [rsp+0x40], xmm4
0000762f89bde6cb  vmovaps [rsp+0x50], xmm5
0000762f89bde6d1  vmovaps [rsp+0x60], xmm6
0000762f89bde6d7  vmovaps [rsp+0x70], xmm7
0000762f89bde6dd  vmovaps [rsp+0x80], xmm8
0000762f89bde6e6  vmovaps [rsp+0x90], xmm10
0000762f89bde6ef  vmovaps [rsp+0xA0], xmm11
0000762f89bde6f8  vmovaps [rsp+0xB0], xmm12
0000762f89bde701  vmovaps [rsp+0xC0], xmm13
0000762f89bde70a  vmovaps [rsp+0xD0], xmm14
0000762f89bde713  vmovaps [rsp+0xE0], xmm15
0000762f89bde71c  sub rsp, 0x30
0000762f89bde720  movaps [rsp], xmm9
0000762f89bde725  movaps [rsp+0x10], xmm3
0000762f89bde72a  movaps [rsp+0x20], xmm1
0000762f89bde72f  lea rdi, [rsp]
0000762f89bde733  mov esi, 0x00
0000762f89bde738  mov rax, 0x604D6F946530
0000762f89bde742  call rax
0000762f89bde744  movaps xmm9, [rsp]
0000762f89bde749  add rsp, 0x30
0000762f89bde74d  vmovaps xmm0, [rsp]
0000762f89bde752  vmovaps xmm1, [rsp+0x10]
0000762f89bde758  vmovaps xmm2, [rsp+0x20]
0000762f89bde75e  vmovaps xmm3, [rsp+0x30]
0000762f89bde764  vmovaps xmm4, [rsp+0x40]
0000762f89bde76a  vmovaps xmm5, [rsp+0x50]
0000762f89bde770  vmovaps xmm6, [rsp+0x60]
0000762f89bde776  vmovaps xmm7, [rsp+0x70]
0000762f89bde77c  vmovaps xmm8, [rsp+0x80]
0000762f89bde785  vmovaps xmm10, [rsp+0x90]
0000762f89bde78e  vmovaps xmm11, [rsp+0xA0]
0000762f89bde797  vmovaps xmm12, [rsp+0xB0]
0000762f89bde7a0  vmovaps xmm13, [rsp+0xC0]
0000762f89bde7a9  vmovaps xmm14, [rsp+0xD0]
0000762f89bde7b2  vmovaps xmm15, [rsp+0xE0]
0000762f89bde7bb  add rsp, 0xF0
0000762f89bde7c2  pop r11
0000762f89bde7c4  pop r10
0000762f89bde7c6  pop r9
0000762f89bde7c8  pop r8
0000762f89bde7ca  pop rsi
0000762f89bde7cb  pop rdi
0000762f89bde7cc  pop rdx
0000762f89bde7cd  pop rcx
0000762f89bde7ce  pop rax
0000762f89bde7cf  add rsp, 0x08
0000762f89bde7d3  jmp 0x0000762F89BDC1AA
0000762f89bde7d8  call 0x0000762F89AB52F0
0000762f89bde7dd  jmp 0x0000762F89BDC1B7
0000762f89bde7e2  sub rsp, 0x08
0000762f89bde7e6  push rax
0000762f89bde7e7  push rcx
0000762f89bde7e8  push rdx
0000762f89bde7e9  push rdi
0000762f89bde7ea  push rsi
0000762f89bde7eb  push r8
0000762f89bde7ed  push r9
0000762f89bde7ef  push r10
0000762f89bde7f1  push r11
0000762f89bde7f3  sub rsp, 0xF0
0000762f89bde7fa  vmovaps [rsp], xmm0
0000762f89bde7ff  vmovaps [rsp+0x10], xmm1
0000762f89bde805  vmovaps [rsp+0x20], xmm2
0000762f89bde80b  vmovaps [rsp+0x30], xmm3
0000762f89bde811  vmovaps [rsp+0x40], xmm4
0000762f89bde817  vmovaps [rsp+0x50], xmm5
0000762f89bde81d  vmovaps [rsp+0x60], xmm6
0000762f89bde823  vmovaps [rsp+0x70], xmm7
0000762f89bde829  vmovaps [rsp+0x80], xmm8
0000762f89bde832  vmovaps [rsp+0x90], xmm9
0000762f89bde83b  vmovaps [rsp+0xA0], xmm10
0000762f89bde844  vmovaps [rsp+0xB0], xmm11
0000762f89bde84d  vmovaps [rsp+0xC0], xmm12
0000762f89bde856  vmovaps [rsp+0xD0], xmm13
0000762f89bde85f  vmovaps [rsp+0xE0], xmm14
0000762f89bde868  sub rsp, 0x30
0000762f89bde86c  movaps [rsp], xmm15
0000762f89bde871  movaps [rsp+0x10], xmm3
0000762f89bde876  movaps [rsp+0x20], xmm7
0000762f89bde87b  lea rdi, [rsp]
0000762f89bde87f  mov esi, 0x00
0000762f89bde884  mov rax, 0x604D6F946530
0000762f89bde88e  call rax
0000762f89bde890  movaps xmm15, [rsp]
0000762f89bde895  add rsp, 0x30
0000762f89bde899  vmovaps xmm0, [rsp]
0000762f89bde89e  vmovaps xmm1, [rsp+0x10]
0000762f89bde8a4  vmovaps xmm2, [rsp+0x20]
0000762f89bde8aa  vmovaps xmm3, [rsp+0x30]
0000762f89bde8b0  vmovaps xmm4, [rsp+0x40]
0000762f89bde8b6  vmovaps xmm5, [rsp+0x50]
0000762f89bde8bc  vmovaps xmm6, [rsp+0x60]
0000762f89bde8c2  vmovaps xmm7, [rsp+0x70]
0000762f89bde8c8  vmovaps xmm8, [rsp+0x80]
0000762f89bde8d1  vmovaps xmm9, [rsp+0x90]
0000762f89bde8da  vmovaps xmm10, [rsp+0xA0]
0000762f89bde8e3  vmovaps xmm11, [rsp+0xB0]
0000762f89bde8ec  vmovaps xmm12, [rsp+0xC0]
0000762f89bde8f5  vmovaps xmm13, [rsp+0xD0]
0000762f89bde8fe  vmovaps xmm14, [rsp+0xE0]
0000762f89bde907  add rsp, 0xF0
0000762f89bde90e  pop r11
0000762f89bde910  pop r10
0000762f89bde912  pop r9
0000762f89bde914  pop r8
0000762f89bde916  pop rsi
0000762f89bde917  pop rdi
0000762f89bde918  pop rdx
0000762f89bde919  pop rcx
0000762f89bde91a  pop rax
0000762f89bde91b  add rsp, 0x08
0000762f89bde91f  jmp 0x0000762F89BDC1E3
0000762f89bde924  sub rsp, 0x08
0000762f89bde928  push rax
0000762f89bde929  push rcx
0000762f89bde92a  push rdx
0000762f89bde92b  push rdi
0000762f89bde92c  push rsi
0000762f89bde92d  push r8
0000762f89bde92f  push r9
0000762f89bde931  push r10
0000762f89bde933  push r11
0000762f89bde935  sub rsp, 0xF0
0000762f89bde93c  vmovaps [rsp], xmm0
0000762f89bde941  vmovaps [rsp+0x10], xmm1
0000762f89bde947  vmovaps [rsp+0x20], xmm2
0000762f89bde94d  vmovaps [rsp+0x30], xmm4
0000762f89bde953  vmovaps [rsp+0x40], xmm5
0000762f89bde959  vmovaps [rsp+0x50], xmm6
0000762f89bde95f  vmovaps [rsp+0x60], xmm7
0000762f89bde965  vmovaps [rsp+0x70], xmm8
0000762f89bde96b  vmovaps [rsp+0x80], xmm9
0000762f89bde974  vmovaps [rsp+0x90], xmm10
0000762f89bde97d  vmovaps [rsp+0xA0], xmm11
0000762f89bde986  vmovaps [rsp+0xB0], xmm12
0000762f89bde98f  vmovaps [rsp+0xC0], xmm13
0000762f89bde998  vmovaps [rsp+0xD0], xmm14
0000762f89bde9a1  vmovaps [rsp+0xE0], xmm15
0000762f89bde9aa  sub rsp, 0x30
0000762f89bde9ae  movaps [rsp], xmm3
0000762f89bde9b2  movaps [rsp+0x10], xmm1
0000762f89bde9b7  movaps [rsp+0x20], xmm15
0000762f89bde9bd  lea rdi, [rsp]
0000762f89bde9c1  mov esi, 0x00
0000762f89bde9c6  mov rax, 0x604D6F946530
0000762f89bde9d0  call rax
0000762f89bde9d2  movaps xmm3, [rsp]
0000762f89bde9d6  add rsp, 0x30
0000762f89bde9da  vmovaps xmm0, [rsp]
0000762f89bde9df  vmovaps xmm1, [rsp+0x10]
0000762f89bde9e5  vmovaps xmm2, [rsp+0x20]
0000762f89bde9eb  vmovaps xmm4, [rsp+0x30]
0000762f89bde9f1  vmovaps xmm5, [rsp+0x40]
0000762f89bde9f7  vmovaps xmm6, [rsp+0x50]
0000762f89bde9fd  vmovaps xmm7, [rsp+0x60]
0000762f89bdea03  vmovaps xmm8, [rsp+0x70]
0000762f89bdea09  vmovaps xmm9, [rsp+0x80]
0000762f89bdea12  vmovaps xmm10, [rsp+0x90]
0000762f89bdea1b  vmovaps xmm11, [rsp+0xA0]
0000762f89bdea24  vmovaps xmm12, [rsp+0xB0]
0000762f89bdea2d  vmovaps xmm13, [rsp+0xC0]
0000762f89bdea36  vmovaps xmm14, [rsp+0xD0]
0000762f89bdea3f  vmovaps xmm15, [rsp+0xE0]
0000762f89bdea48  add rsp, 0xF0
0000762f89bdea4f  pop r11
0000762f89bdea51  pop r10
0000762f89bdea53  pop r9
0000762f89bdea55  pop r8
0000762f89bdea57  pop rsi
0000762f89bdea58  pop rdi
0000762f89bdea59  pop rdx
0000762f89bdea5a  pop rcx
0000762f89bdea5b  pop rax
0000762f89bdea5c  add rsp, 0x08
0000762f89bdea60  jmp 0x0000762F89BDC272
0000762f89bdea65  call 0x0000762F89AB52F0
0000762f89bdea6a  jmp 0x0000762F89BDC27C
0000762f89bdea6f  sub rsp, 0x08
0000762f89bdea73  push rax
0000762f89bdea74  push rcx
0000762f89bdea75  push rdx
0000762f89bdea76  push rdi
0000762f89bdea77  push rsi
0000762f89bdea78  push r8
0000762f89bdea7a  push r9
0000762f89bdea7c  push r10
0000762f89bdea7e  push r11
0000762f89bdea80  sub rsp, 0xF0
0000762f89bdea87  vmovaps [rsp], xmm0
0000762f89bdea8c  vmovaps [rsp+0x10], xmm1
0000762f89bdea92  vmovaps [rsp+0x20], xmm2
0000762f89bdea98  vmovaps [rsp+0x30], xmm3
0000762f89bdea9e  vmovaps [rsp+0x40], xmm4
0000762f89bdeaa4  vmovaps [rsp+0x50], xmm5
0000762f89bdeaaa  vmovaps [rsp+0x60], xmm6
0000762f89bdeab0  vmovaps [rsp+0x70], xmm7
0000762f89bdeab6  vmovaps [rsp+0x80], xmm8
0000762f89bdeabf  vmovaps [rsp+0x90], xmm9
0000762f89bdeac8  vmovaps [rsp+0xA0], xmm10
0000762f89bdead1  vmovaps [rsp+0xB0], xmm11
0000762f89bdeada  vmovaps [rsp+0xC0], xmm12
0000762f89bdeae3  vmovaps [rsp+0xD0], xmm13
0000762f89bdeaec  vmovaps [rsp+0xE0], xmm14
0000762f89bdeaf5  sub rsp, 0x30
0000762f89bdeaf9  movaps [rsp], xmm15
0000762f89bdeafe  movaps [rsp+0x10], xmm14
0000762f89bdeb04  movaps [rsp+0x20], xmm4
0000762f89bdeb09  lea rdi, [rsp]
0000762f89bdeb0d  mov esi, 0x00
0000762f89bdeb12  mov rax, 0x604D6F946530
0000762f89bdeb1c  call rax
0000762f89bdeb1e  movaps xmm15, [rsp]
0000762f89bdeb23  add rsp, 0x30
0000762f89bdeb27  vmovaps xmm0, [rsp]
0000762f89bdeb2c  vmovaps xmm1, [rsp+0x10]
0000762f89bdeb32  vmovaps xmm2, [rsp+0x20]
0000762f89bdeb38  vmovaps xmm3, [rsp+0x30]
0000762f89bdeb3e  vmovaps xmm4, [rsp+0x40]
0000762f89bdeb44  vmovaps xmm5, [rsp+0x50]
0000762f89bdeb4a  vmovaps xmm6, [rsp+0x60]
0000762f89bdeb50  vmovaps xmm7, [rsp+0x70]
0000762f89bdeb56  vmovaps xmm8, [rsp+0x80]
0000762f89bdeb5f  vmovaps xmm9, [rsp+0x90]
0000762f89bdeb68  vmovaps xmm10, [rsp+0xA0]
0000762f89bdeb71  vmovaps xmm11, [rsp+0xB0]
0000762f89bdeb7a  vmovaps xmm12, [rsp+0xC0]
0000762f89bdeb83  vmovaps xmm13, [rsp+0xD0]
0000762f89bdeb8c  vmovaps xmm14, [rsp+0xE0]
0000762f89bdeb95  add rsp, 0xF0
0000762f89bdeb9c  pop r11
0000762f89bdeb9e  pop r10
0000762f89bdeba0  pop r9
0000762f89bdeba2  pop r8
0000762f89bdeba4  pop rsi
0000762f89bdeba5  pop rdi
0000762f89bdeba6  pop rdx
0000762f89bdeba7  pop rcx
0000762f89bdeba8  pop rax
0000762f89bdeba9  add rsp, 0x08
0000762f89bdebad  jmp 0x0000762F89BDC2AA
0000762f89bdebb2  sub rsp, 0x08
0000762f89bdebb6  push rax
0000762f89bdebb7  push rcx
0000762f89bdebb8  push rdx
0000762f89bdebb9  push rdi
0000762f89bdebba  push rsi
0000762f89bdebbb  push r8
0000762f89bdebbd  push r9
0000762f89bdebbf  push r10
0000762f89bdebc1  push r11
0000762f89bdebc3  sub rsp, 0xF0
0000762f89bdebca  vmovaps [rsp], xmm0
0000762f89bdebcf  vmovaps [rsp+0x10], xmm1
0000762f89bdebd5  vmovaps [rsp+0x20], xmm2
0000762f89bdebdb  vmovaps [rsp+0x30], xmm3
0000762f89bdebe1  vmovaps [rsp+0x40], xmm4
0000762f89bdebe7  vmovaps [rsp+0x50], xmm5
0000762f89bdebed  vmovaps [rsp+0x60], xmm6
0000762f89bdebf3  vmovaps [rsp+0x70], xmm7
0000762f89bdebf9  vmovaps [rsp+0x80], xmm8
0000762f89bdec02  vmovaps [rsp+0x90], xmm9
0000762f89bdec0b  vmovaps [rsp+0xA0], xmm10
0000762f89bdec14  vmovaps [rsp+0xB0], xmm11
0000762f89bdec1d  vmovaps [rsp+0xC0], xmm12
0000762f89bdec26  vmovaps [rsp+0xD0], xmm13
0000762f89bdec2f  vmovaps [rsp+0xE0], xmm15
0000762f89bdec38  sub rsp, 0x30
0000762f89bdec3c  movaps [rsp], xmm14
0000762f89bdec41  movaps [rsp+0x10], xmm2
0000762f89bdec46  movaps [rsp+0x20], xmm1
0000762f89bdec4b  lea rdi, [rsp]
0000762f89bdec4f  mov esi, 0x00
0000762f89bdec54  mov rax, 0x604D6F946530
0000762f89bdec5e  call rax
0000762f89bdec60  movaps xmm14, [rsp]
0000762f89bdec65  add rsp, 0x30
0000762f89bdec69  vmovaps xmm0, [rsp]
0000762f89bdec6e  vmovaps xmm1, [rsp+0x10]
0000762f89bdec74  vmovaps xmm2, [rsp+0x20]
0000762f89bdec7a  vmovaps xmm3, [rsp+0x30]
0000762f89bdec80  vmovaps xmm4, [rsp+0x40]
0000762f89bdec86  vmovaps xmm5, [rsp+0x50]
0000762f89bdec8c  vmovaps xmm6, [rsp+0x60]
0000762f89bdec92  vmovaps xmm7, [rsp+0x70]
0000762f89bdec98  vmovaps xmm8, [rsp+0x80]
0000762f89bdeca1  vmovaps xmm9, [rsp+0x90]
0000762f89bdecaa  vmovaps xmm10, [rsp+0xA0]
0000762f89bdecb3  vmovaps xmm11, [rsp+0xB0]
0000762f89bdecbc  vmovaps xmm12, [rsp+0xC0]
0000762f89bdecc5  vmovaps xmm13, [rsp+0xD0]
0000762f89bdecce  vmovaps xmm15, [rsp+0xE0]
0000762f89bdecd7  add rsp, 0xF0
0000762f89bdecde  pop r11
0000762f89bdece0  pop r10
0000762f89bdece2  pop r9
0000762f89bdece4  pop r8
0000762f89bdece6  pop rsi
0000762f89bdece7  pop rdi
0000762f89bdece8  pop rdx
0000762f89bdece9  pop rcx
0000762f89bdecea  pop rax
0000762f89bdeceb  add rsp, 0x08
0000762f89bdecef  jmp 0x0000762F89BDC2D0
0000762f89bdecf4  sub rsp, 0x08
0000762f89bdecf8  push rax
0000762f89bdecf9  push rcx
0000762f89bdecfa  push rdx
0000762f89bdecfb  push rdi
0000762f89bdecfc  push rsi
0000762f89bdecfd  push r8
0000762f89bdecff  push r9
0000762f89bded01  push r10
0000762f89bded03  push r11
0000762f89bded05  sub rsp, 0xF0
0000762f89bded0c  vmovaps [rsp], xmm0
0000762f89bded11  vmovaps [rsp+0x10], xmm2
0000762f89bded17  vmovaps [rsp+0x20], xmm3
0000762f89bded1d  vmovaps [rsp+0x30], xmm4
0000762f89bded23  vmovaps [rsp+0x40], xmm5
0000762f89bded29  vmovaps [rsp+0x50], xmm6
0000762f89bded2f  vmovaps [rsp+0x60], xmm7
0000762f89bded35  vmovaps [rsp+0x70], xmm8
0000762f89bded3b  vmovaps [rsp+0x80], xmm9
0000762f89bded44  vmovaps [rsp+0x90], xmm10
0000762f89bded4d  vmovaps [rsp+0xA0], xmm11
0000762f89bded56  vmovaps [rsp+0xB0], xmm12
0000762f89bded5f  vmovaps [rsp+0xC0], xmm13
0000762f89bded68  vmovaps [rsp+0xD0], xmm14
0000762f89bded71  vmovaps [rsp+0xE0], xmm15
0000762f89bded7a  sub rsp, 0x30
0000762f89bded7e  movaps [rsp], xmm1
0000762f89bded82  movaps [rsp+0x10], xmm4
0000762f89bded87  movaps [rsp+0x20], xmm9
0000762f89bded8d  lea rdi, [rsp]
0000762f89bded91  mov esi, 0x00
0000762f89bded96  mov rax, 0x604D6F946530
0000762f89bdeda0  call rax
0000762f89bdeda2  movaps xmm1, [rsp]
0000762f89bdeda6  add rsp, 0x30
0000762f89bdedaa  vmovaps xmm0, [rsp]
0000762f89bdedaf  vmovaps xmm2, [rsp+0x10]
0000762f89bdedb5  vmovaps xmm3, [rsp+0x20]
0000762f89bdedbb  vmovaps xmm4, [rsp+0x30]
0000762f89bdedc1  vmovaps xmm5, [rsp+0x40]
0000762f89bdedc7  vmovaps xmm6, [rsp+0x50]
0000762f89bdedcd  vmovaps xmm7, [rsp+0x60]
0000762f89bdedd3  vmovaps xmm8, [rsp+0x70]
0000762f89bdedd9  vmovaps xmm9, [rsp+0x80]
0000762f89bdede2  vmovaps xmm10, [rsp+0x90]
0000762f89bdedeb  vmovaps xmm11, [rsp+0xA0]
0000762f89bdedf4  vmovaps xmm12, [rsp+0xB0]
0000762f89bdedfd  vmovaps xmm13, [rsp+0xC0]
0000762f89bdee06  vmovaps xmm14, [rsp+0xD0]
0000762f89bdee0f  vmovaps xmm15, [rsp+0xE0]
0000762f89bdee18  add rsp, 0xF0
0000762f89bdee1f  pop r11
0000762f89bdee21  pop r10
0000762f89bdee23  pop r9
0000762f89bdee25  pop r8
0000762f89bdee27  pop rsi
0000762f89bdee28  pop rdi
0000762f89bdee29  pop rdx
0000762f89bdee2a  pop rcx
0000762f89bdee2b  pop rax
0000762f89bdee2c  add rsp, 0x08
0000762f89bdee30  jmp 0x0000762F89BDC2EE
0000762f89bdee35  sub rsp, 0x08
0000762f89bdee39  push rax
0000762f89bdee3a  push rcx
0000762f89bdee3b  push rdx
0000762f89bdee3c  push rdi
0000762f89bdee3d  push rsi
0000762f89bdee3e  push r8
0000762f89bdee40  push r9
0000762f89bdee42  push r10
0000762f89bdee44  push r11
0000762f89bdee46  sub rsp, 0xF0
0000762f89bdee4d  vmovaps [rsp], xmm0
0000762f89bdee52  vmovaps [rsp+0x10], xmm1
0000762f89bdee58  vmovaps [rsp+0x20], xmm2
0000762f89bdee5e  vmovaps [rsp+0x30], xmm3
0000762f89bdee64  vmovaps [rsp+0x40], xmm5
0000762f89bdee6a  vmovaps [rsp+0x50], xmm6
0000762f89bdee70  vmovaps [rsp+0x60], xmm7
0000762f89bdee76  vmovaps [rsp+0x70], xmm8
0000762f89bdee7c  vmovaps [rsp+0x80], xmm9
0000762f89bdee85  vmovaps [rsp+0x90], xmm10
0000762f89bdee8e  vmovaps [rsp+0xA0], xmm11
0000762f89bdee97  vmovaps [rsp+0xB0], xmm12
0000762f89bdeea0  vmovaps [rsp+0xC0], xmm13
0000762f89bdeea9  vmovaps [rsp+0xD0], xmm14
0000762f89bdeeb2  vmovaps [rsp+0xE0], xmm15
0000762f89bdeebb  sub rsp, 0x30
0000762f89bdeebf  movaps [rsp], xmm4
0000762f89bdeec3  movaps [rsp+0x10], xmm2
0000762f89bdeec8  movaps [rsp+0x20], xmm9
0000762f89bdeece  lea rdi, [rsp]
0000762f89bdeed2  mov esi, 0x00
0000762f89bdeed7  mov rax, 0x604D6F946530
0000762f89bdeee1  call rax
0000762f89bdeee3  movaps xmm4, [rsp]
0000762f89bdeee7  add rsp, 0x30
0000762f89bdeeeb  vmovaps xmm0, [rsp]
0000762f89bdeef0  vmovaps xmm1, [rsp+0x10]
0000762f89bdeef6  vmovaps xmm2, [rsp+0x20]
0000762f89bdeefc  vmovaps xmm3, [rsp+0x30]
0000762f89bdef02  vmovaps xmm5, [rsp+0x40]
0000762f89bdef08  vmovaps xmm6, [rsp+0x50]
0000762f89bdef0e  vmovaps xmm7, [rsp+0x60]
0000762f89bdef14  vmovaps xmm8, [rsp+0x70]
0000762f89bdef1a  vmovaps xmm9, [rsp+0x80]
0000762f89bdef23  vmovaps xmm10, [rsp+0x90]
0000762f89bdef2c  vmovaps xmm11, [rsp+0xA0]
0000762f89bdef35  vmovaps xmm12, [rsp+0xB0]
0000762f89bdef3e  vmovaps xmm13, [rsp+0xC0]
0000762f89bdef47  vmovaps xmm14, [rsp+0xD0]
0000762f89bdef50  vmovaps xmm15, [rsp+0xE0]
0000762f89bdef59  add rsp, 0xF0
0000762f89bdef60  pop r11
0000762f89bdef62  pop r10
0000762f89bdef64  pop r9
0000762f89bdef66  pop r8
0000762f89bdef68  pop rsi
0000762f89bdef69  pop rdi
0000762f89bdef6a  pop rdx
0000762f89bdef6b  pop rcx
0000762f89bdef6c  pop rax
0000762f89bdef6d  add rsp, 0x08
0000762f89bdef71  jmp 0x0000762F89BDC31E
0000762f89bdef76  sub rsp, 0x08
0000762f89bdef7a  push rax
0000762f89bdef7b  push rcx
0000762f89bdef7c  push rdx
0000762f89bdef7d  push rdi
0000762f89bdef7e  push rsi
0000762f89bdef7f  push r8
0000762f89bdef81  push r9
0000762f89bdef83  push r10
0000762f89bdef85  push r11
0000762f89bdef87  sub rsp, 0xF0
0000762f89bdef8e  vmovaps [rsp], xmm0
0000762f89bdef93  vmovaps [rsp+0x10], xmm1
0000762f89bdef99  vmovaps [rsp+0x20], xmm2
0000762f89bdef9f  vmovaps [rsp+0x30], xmm3
0000762f89bdefa5  vmovaps [rsp+0x40], xmm4
0000762f89bdefab  vmovaps [rsp+0x50], xmm5
0000762f89bdefb1  vmovaps [rsp+0x60], xmm6
0000762f89bdefb7  vmovaps [rsp+0x70], xmm7
0000762f89bdefbd  vmovaps [rsp+0x80], xmm8
0000762f89bdefc6  vmovaps [rsp+0x90], xmm10
0000762f89bdefcf  vmovaps [rsp+0xA0], xmm11
0000762f89bdefd8  vmovaps [rsp+0xB0], xmm12
0000762f89bdefe1  vmovaps [rsp+0xC0], xmm13
0000762f89bdefea  vmovaps [rsp+0xD0], xmm14
0000762f89bdeff3  vmovaps [rsp+0xE0], xmm15
0000762f89bdeffc  sub rsp, 0x30
0000762f89bdf000  movaps [rsp], xmm9
0000762f89bdf005  movaps [rsp+0x10], xmm2
0000762f89bdf00a  movaps [rsp+0x20], xmm1
0000762f89bdf00f  lea rdi, [rsp]
0000762f89bdf013  mov esi, 0x00
0000762f89bdf018  mov rax, 0x604D6F946530
0000762f89bdf022  call rax
0000762f89bdf024  movaps xmm9, [rsp]
0000762f89bdf029  add rsp, 0x30
0000762f89bdf02d  vmovaps xmm0, [rsp]
0000762f89bdf032  vmovaps xmm1, [rsp+0x10]
0000762f89bdf038  vmovaps xmm2, [rsp+0x20]
0000762f89bdf03e  vmovaps xmm3, [rsp+0x30]
0000762f89bdf044  vmovaps xmm4, [rsp+0x40]
0000762f89bdf04a  vmovaps xmm5, [rsp+0x50]
0000762f89bdf050  vmovaps xmm6, [rsp+0x60]
0000762f89bdf056  vmovaps xmm7, [rsp+0x70]
0000762f89bdf05c  vmovaps xmm8, [rsp+0x80]
0000762f89bdf065  vmovaps xmm10, [rsp+0x90]
0000762f89bdf06e  vmovaps xmm11, [rsp+0xA0]
0000762f89bdf077  vmovaps xmm12, [rsp+0xB0]
0000762f89bdf080  vmovaps xmm13, [rsp+0xC0]
0000762f89bdf089  vmovaps xmm14, [rsp+0xD0]
0000762f89bdf092  vmovaps xmm15, [rsp+0xE0]
0000762f89bdf09b  add rsp, 0xF0
0000762f89bdf0a2  pop r11
0000762f89bdf0a4  pop r10
0000762f89bdf0a6  pop r9
0000762f89bdf0a8  pop r8
0000762f89bdf0aa  pop rsi
0000762f89bdf0ab  pop rdi
0000762f89bdf0ac  pop rdx
0000762f89bdf0ad  pop rcx
0000762f89bdf0ae  pop rax
0000762f89bdf0af  add rsp, 0x08
0000762f89bdf0b3  jmp 0x0000762F89BDC354
0000762f89bdf0b8  sub rsp, 0x08
0000762f89bdf0bc  push rax
0000762f89bdf0bd  push rcx
0000762f89bdf0be  push rdx
0000762f89bdf0bf  push rdi
0000762f89bdf0c0  push rsi
0000762f89bdf0c1  push r8
0000762f89bdf0c3  push r9
0000762f89bdf0c5  push r10
0000762f89bdf0c7  push r11
0000762f89bdf0c9  sub rsp, 0xF0
0000762f89bdf0d0  vmovaps [rsp], xmm0
0000762f89bdf0d5  vmovaps [rsp+0x10], xmm2
0000762f89bdf0db  vmovaps [rsp+0x20], xmm3
0000762f89bdf0e1  vmovaps [rsp+0x30], xmm4
0000762f89bdf0e7  vmovaps [rsp+0x40], xmm5
0000762f89bdf0ed  vmovaps [rsp+0x50], xmm6
0000762f89bdf0f3  vmovaps [rsp+0x60], xmm7
0000762f89bdf0f9  vmovaps [rsp+0x70], xmm8
0000762f89bdf0ff  vmovaps [rsp+0x80], xmm9
0000762f89bdf108  vmovaps [rsp+0x90], xmm10
0000762f89bdf111  vmovaps [rsp+0xA0], xmm11
0000762f89bdf11a  vmovaps [rsp+0xB0], xmm12
0000762f89bdf123  vmovaps [rsp+0xC0], xmm13
0000762f89bdf12c  vmovaps [rsp+0xD0], xmm14
0000762f89bdf135  vmovaps [rsp+0xE0], xmm15
0000762f89bdf13e  sub rsp, 0x30
0000762f89bdf142  movaps [rsp], xmm1
0000762f89bdf146  movaps [rsp+0x10], xmm15
0000762f89bdf14c  movaps [rsp+0x20], xmm6
0000762f89bdf151  lea rdi, [rsp]
0000762f89bdf155  mov esi, 0x00
0000762f89bdf15a  mov rax, 0x604D6F946530
0000762f89bdf164  call rax
0000762f89bdf166  movaps xmm1, [rsp]
0000762f89bdf16a  add rsp, 0x30
0000762f89bdf16e  vmovaps xmm0, [rsp]
0000762f89bdf173  vmovaps xmm2, [rsp+0x10]
0000762f89bdf179  vmovaps xmm3, [rsp+0x20]
0000762f89bdf17f  vmovaps xmm4, [rsp+0x30]
0000762f89bdf185  vmovaps xmm5, [rsp+0x40]
0000762f89bdf18b  vmovaps xmm6, [rsp+0x50]
0000762f89bdf191  vmovaps xmm7, [rsp+0x60]
0000762f89bdf197  vmovaps xmm8, [rsp+0x70]
0000762f89bdf19d  vmovaps xmm9, [rsp+0x80]
0000762f89bdf1a6  vmovaps xmm10, [rsp+0x90]
0000762f89bdf1af  vmovaps xmm11, [rsp+0xA0]
0000762f89bdf1b8  vmovaps xmm12, [rsp+0xB0]
0000762f89bdf1c1  vmovaps xmm13, [rsp+0xC0]
0000762f89bdf1ca  vmovaps xmm14, [rsp+0xD0]
0000762f89bdf1d3  vmovaps xmm15, [rsp+0xE0]
0000762f89bdf1dc  add rsp, 0xF0
0000762f89bdf1e3  pop r11
0000762f89bdf1e5  pop r10
0000762f89bdf1e7  pop r9
0000762f89bdf1e9  pop r8
0000762f89bdf1eb  pop rsi
0000762f89bdf1ec  pop rdi
0000762f89bdf1ed  pop rdx
0000762f89bdf1ee  pop rcx
0000762f89bdf1ef  pop rax
0000762f89bdf1f0  add rsp, 0x08
0000762f89bdf1f4  jmp 0x0000762F89BDC375
0000762f89bdf1f9  sub rsp, 0x08
0000762f89bdf1fd  push rax
0000762f89bdf1fe  push rcx
0000762f89bdf1ff  push rdx
0000762f89bdf200  push rdi
0000762f89bdf201  push rsi
0000762f89bdf202  push r8
0000762f89bdf204  push r9
0000762f89bdf206  push r10
0000762f89bdf208  push r11
0000762f89bdf20a  sub rsp, 0xF0
0000762f89bdf211  vmovaps [rsp], xmm0
0000762f89bdf216  vmovaps [rsp+0x10], xmm1
0000762f89bdf21c  vmovaps [rsp+0x20], xmm2
0000762f89bdf222  vmovaps [rsp+0x30], xmm3
0000762f89bdf228  vmovaps [rsp+0x40], xmm4
0000762f89bdf22e  vmovaps [rsp+0x50], xmm5
0000762f89bdf234  vmovaps [rsp+0x60], xmm6
0000762f89bdf23a  vmovaps [rsp+0x70], xmm7
0000762f89bdf240  vmovaps [rsp+0x80], xmm8
0000762f89bdf249  vmovaps [rsp+0x90], xmm9
0000762f89bdf252  vmovaps [rsp+0xA0], xmm10
0000762f89bdf25b  vmovaps [rsp+0xB0], xmm11
0000762f89bdf264  vmovaps [rsp+0xC0], xmm12
0000762f89bdf26d  vmovaps [rsp+0xD0], xmm13
0000762f89bdf276  vmovaps [rsp+0xE0], xmm14
0000762f89bdf27f  sub rsp, 0x30
0000762f89bdf283  movaps [rsp], xmm15
0000762f89bdf288  movaps [rsp+0x10], xmm5
0000762f89bdf28d  movaps [rsp+0x20], xmm3
0000762f89bdf292  lea rdi, [rsp]
0000762f89bdf296  mov esi, 0x00
0000762f89bdf29b  mov rax, 0x604D6F946530
0000762f89bdf2a5  call rax
0000762f89bdf2a7  movaps xmm15, [rsp]
0000762f89bdf2ac  add rsp, 0x30
0000762f89bdf2b0  vmovaps xmm0, [rsp]
0000762f89bdf2b5  vmovaps xmm1, [rsp+0x10]
0000762f89bdf2bb  vmovaps xmm2, [rsp+0x20]
0000762f89bdf2c1  vmovaps xmm3, [rsp+0x30]
0000762f89bdf2c7  vmovaps xmm4, [rsp+0x40]
0000762f89bdf2cd  vmovaps xmm5, [rsp+0x50]
0000762f89bdf2d3  vmovaps xmm6, [rsp+0x60]
0000762f89bdf2d9  vmovaps xmm7, [rsp+0x70]
0000762f89bdf2df  vmovaps xmm8, [rsp+0x80]
0000762f89bdf2e8  vmovaps xmm9, [rsp+0x90]
0000762f89bdf2f1  vmovaps xmm10, [rsp+0xA0]
0000762f89bdf2fa  vmovaps xmm11, [rsp+0xB0]
0000762f89bdf303  vmovaps xmm12, [rsp+0xC0]
0000762f89bdf30c  vmovaps xmm13, [rsp+0xD0]
0000762f89bdf315  vmovaps xmm14, [rsp+0xE0]
0000762f89bdf31e  add rsp, 0xF0
0000762f89bdf325  pop r11
0000762f89bdf327  pop r10
0000762f89bdf329  pop r9
0000762f89bdf32b  pop r8
0000762f89bdf32d  pop rsi
0000762f89bdf32e  pop rdi
0000762f89bdf32f  pop rdx
0000762f89bdf330  pop rcx
0000762f89bdf331  pop rax
0000762f89bdf332  add rsp, 0x08
0000762f89bdf336  jmp 0x0000762F89BDC38F
0000762f89bdf33b  sub rsp, 0x08
0000762f89bdf33f  push rax
0000762f89bdf340  push rcx
0000762f89bdf341  push rdx
0000762f89bdf342  push rdi
0000762f89bdf343  push rsi
0000762f89bdf344  push r8
0000762f89bdf346  push r9
0000762f89bdf348  push r10
0000762f89bdf34a  push r11
0000762f89bdf34c  sub rsp, 0xF0
0000762f89bdf353  vmovaps [rsp], xmm0
0000762f89bdf358  vmovaps [rsp+0x10], xmm1
0000762f89bdf35e  vmovaps [rsp+0x20], xmm2
0000762f89bdf364  vmovaps [rsp+0x30], xmm3
0000762f89bdf36a  vmovaps [rsp+0x40], xmm4
0000762f89bdf370  vmovaps [rsp+0x50], xmm6
0000762f89bdf376  vmovaps [rsp+0x60], xmm7
0000762f89bdf37c  vmovaps [rsp+0x70], xmm8
0000762f89bdf382  vmovaps [rsp+0x80], xmm9
0000762f89bdf38b  vmovaps [rsp+0x90], xmm10
0000762f89bdf394  vmovaps [rsp+0xA0], xmm11
0000762f89bdf39d  vmovaps [rsp+0xB0], xmm12
0000762f89bdf3a6  vmovaps [rsp+0xC0], xmm13
0000762f89bdf3af  vmovaps [rsp+0xD0], xmm14
0000762f89bdf3b8  vmovaps [rsp+0xE0], xmm15
0000762f89bdf3c1  sub rsp, 0x30
0000762f89bdf3c5  movaps [rsp], xmm5
0000762f89bdf3c9  movaps [rsp+0x10], xmm8
0000762f89bdf3cf  movaps [rsp+0x20], xmm6
0000762f89bdf3d4  lea rdi, [rsp]
0000762f89bdf3d8  mov esi, 0x00
0000762f89bdf3dd  mov rax, 0x604D6F946530
0000762f89bdf3e7  call rax
0000762f89bdf3e9  movaps xmm5, [rsp]
0000762f89bdf3ed  add rsp, 0x30
0000762f89bdf3f1  vmovaps xmm0, [rsp]
0000762f89bdf3f6  vmovaps xmm1, [rsp+0x10]
0000762f89bdf3fc  vmovaps xmm2, [rsp+0x20]
0000762f89bdf402  vmovaps xmm3, [rsp+0x30]
0000762f89bdf408  vmovaps xmm4, [rsp+0x40]
0000762f89bdf40e  vmovaps xmm6, [rsp+0x50]
0000762f89bdf414  vmovaps xmm7, [rsp+0x60]
0000762f89bdf41a  vmovaps xmm8, [rsp+0x70]
0000762f89bdf420  vmovaps xmm9, [rsp+0x80]
0000762f89bdf429  vmovaps xmm10, [rsp+0x90]
0000762f89bdf432  vmovaps xmm11, [rsp+0xA0]
0000762f89bdf43b  vmovaps xmm12, [rsp+0xB0]
0000762f89bdf444  vmovaps xmm13, [rsp+0xC0]
0000762f89bdf44d  vmovaps xmm14, [rsp+0xD0]
0000762f89bdf456  vmovaps xmm15, [rsp+0xE0]
0000762f89bdf45f  add rsp, 0xF0
0000762f89bdf466  pop r11
0000762f89bdf468  pop r10
0000762f89bdf46a  pop r9
0000762f89bdf46c  pop r8
0000762f89bdf46e  pop rsi
0000762f89bdf46f  pop rdi
0000762f89bdf470  pop rdx
0000762f89bdf471  pop rcx
0000762f89bdf472  pop rax
0000762f89bdf473  add rsp, 0x08
0000762f89bdf477  jmp 0x0000762F89BDC3B3
0000762f89bdf47c  sub rsp, 0x08
0000762f89bdf480  push rax
0000762f89bdf481  push rcx
0000762f89bdf482  push rdx
0000762f89bdf483  push rdi
0000762f89bdf484  push rsi
0000762f89bdf485  push r8
0000762f89bdf487  push r9
0000762f89bdf489  push r10
0000762f89bdf48b  push r11
0000762f89bdf48d  sub rsp, 0xF0
0000762f89bdf494  vmovaps [rsp], xmm0
0000762f89bdf499  vmovaps [rsp+0x10], xmm1
0000762f89bdf49f  vmovaps [rsp+0x20], xmm2
0000762f89bdf4a5  vmovaps [rsp+0x30], xmm3
0000762f89bdf4ab  vmovaps [rsp+0x40], xmm4
0000762f89bdf4b1  vmovaps [rsp+0x50], xmm5
0000762f89bdf4b7  vmovaps [rsp+0x60], xmm7
0000762f89bdf4bd  vmovaps [rsp+0x70], xmm8
0000762f89bdf4c3  vmovaps [rsp+0x80], xmm9
0000762f89bdf4cc  vmovaps [rsp+0x90], xmm10
0000762f89bdf4d5  vmovaps [rsp+0xA0], xmm11
0000762f89bdf4de  vmovaps [rsp+0xB0], xmm12
0000762f89bdf4e7  vmovaps [rsp+0xC0], xmm13
0000762f89bdf4f0  vmovaps [rsp+0xD0], xmm14
0000762f89bdf4f9  vmovaps [rsp+0xE0], xmm15
0000762f89bdf502  sub rsp, 0x30
0000762f89bdf506  movaps [rsp], xmm6
0000762f89bdf50a  movaps [rsp+0x10], xmm10
0000762f89bdf510  movaps [rsp+0x20], xmm8
0000762f89bdf516  lea rdi, [rsp]
0000762f89bdf51a  mov esi, 0x00
0000762f89bdf51f  mov rax, 0x604D6F946530
0000762f89bdf529  call rax
0000762f89bdf52b  movaps xmm6, [rsp]
0000762f89bdf52f  add rsp, 0x30
0000762f89bdf533  vmovaps xmm0, [rsp]
0000762f89bdf538  vmovaps xmm1, [rsp+0x10]
0000762f89bdf53e  vmovaps xmm2, [rsp+0x20]
0000762f89bdf544  vmovaps xmm3, [rsp+0x30]
0000762f89bdf54a  vmovaps xmm4, [rsp+0x40]
0000762f89bdf550  vmovaps xmm5, [rsp+0x50]
0000762f89bdf556  vmovaps xmm7, [rsp+0x60]
0000762f89bdf55c  vmovaps xmm8, [rsp+0x70]
0000762f89bdf562  vmovaps xmm9, [rsp+0x80]
0000762f89bdf56b  vmovaps xmm10, [rsp+0x90]
0000762f89bdf574  vmovaps xmm11, [rsp+0xA0]
0000762f89bdf57d  vmovaps xmm12, [rsp+0xB0]
0000762f89bdf586  vmovaps xmm13, [rsp+0xC0]
0000762f89bdf58f  vmovaps xmm14, [rsp+0xD0]
0000762f89bdf598  vmovaps xmm15, [rsp+0xE0]
0000762f89bdf5a1  add rsp, 0xF0
0000762f89bdf5a8  pop r11
0000762f89bdf5aa  pop r10
0000762f89bdf5ac  pop r9
0000762f89bdf5ae  pop r8
0000762f89bdf5b0  pop rsi
0000762f89bdf5b1  pop rdi
0000762f89bdf5b2  pop rdx
0000762f89bdf5b3  pop rcx
0000762f89bdf5b4  pop rax
0000762f89bdf5b5  add rsp, 0x08
0000762f89bdf5b9  jmp 0x0000762F89BDC3D8
0000762f89bdf5be  sub rsp, 0x08
0000762f89bdf5c2  push rax
0000762f89bdf5c3  push rcx
0000762f89bdf5c4  push rdx
0000762f89bdf5c5  push rdi
0000762f89bdf5c6  push rsi
0000762f89bdf5c7  push r8
0000762f89bdf5c9  push r9
0000762f89bdf5cb  push r10
0000762f89bdf5cd  push r11
0000762f89bdf5cf  sub rsp, 0xF0
0000762f89bdf5d6  vmovaps [rsp], xmm0
0000762f89bdf5db  vmovaps [rsp+0x10], xmm1
0000762f89bdf5e1  vmovaps [rsp+0x20], xmm2
0000762f89bdf5e7  vmovaps [rsp+0x30], xmm3
0000762f89bdf5ed  vmovaps [rsp+0x40], xmm4
0000762f89bdf5f3  vmovaps [rsp+0x50], xmm5
0000762f89bdf5f9  vmovaps [rsp+0x60], xmm6
0000762f89bdf5ff  vmovaps [rsp+0x70], xmm7
0000762f89bdf605  vmovaps [rsp+0x80], xmm8
0000762f89bdf60e  vmovaps [rsp+0x90], xmm9
0000762f89bdf617  vmovaps [rsp+0xA0], xmm11
0000762f89bdf620  vmovaps [rsp+0xB0], xmm12
0000762f89bdf629  vmovaps [rsp+0xC0], xmm13
0000762f89bdf632  vmovaps [rsp+0xD0], xmm14
0000762f89bdf63b  vmovaps [rsp+0xE0], xmm15
0000762f89bdf644  sub rsp, 0x30
0000762f89bdf648  movaps [rsp], xmm10
0000762f89bdf64d  movaps [rsp+0x10], xmm8
0000762f89bdf653  movaps [rsp+0x20], xmm14
0000762f89bdf659  lea rdi, [rsp]
0000762f89bdf65d  mov esi, 0x00
0000762f89bdf662  mov rax, 0x604D6F946530
0000762f89bdf66c  call rax
0000762f89bdf66e  movaps xmm10, [rsp]
0000762f89bdf673  add rsp, 0x30
0000762f89bdf677  vmovaps xmm0, [rsp]
0000762f89bdf67c  vmovaps xmm1, [rsp+0x10]
0000762f89bdf682  vmovaps xmm2, [rsp+0x20]
0000762f89bdf688  vmovaps xmm3, [rsp+0x30]
0000762f89bdf68e  vmovaps xmm4, [rsp+0x40]
0000762f89bdf694  vmovaps xmm5, [rsp+0x50]
0000762f89bdf69a  vmovaps xmm6, [rsp+0x60]
0000762f89bdf6a0  vmovaps xmm7, [rsp+0x70]
0000762f89bdf6a6  vmovaps xmm8, [rsp+0x80]
0000762f89bdf6af  vmovaps xmm9, [rsp+0x90]
0000762f89bdf6b8  vmovaps xmm11, [rsp+0xA0]
0000762f89bdf6c1  vmovaps xmm12, [rsp+0xB0]
0000762f89bdf6ca  vmovaps xmm13, [rsp+0xC0]
0000762f89bdf6d3  vmovaps xmm14, [rsp+0xD0]
0000762f89bdf6dc  vmovaps xmm15, [rsp+0xE0]
0000762f89bdf6e5  add rsp, 0xF0
0000762f89bdf6ec  pop r11
0000762f89bdf6ee  pop r10
0000762f89bdf6f0  pop r9
0000762f89bdf6f2  pop r8
0000762f89bdf6f4  pop rsi
0000762f89bdf6f5  pop rdi
0000762f89bdf6f6  pop rdx
0000762f89bdf6f7  pop rcx
0000762f89bdf6f8  pop rax
0000762f89bdf6f9  add rsp, 0x08
0000762f89bdf6fd  jmp 0x0000762F89BDC3F8
0000762f89bdf702  sub rsp, 0x08
0000762f89bdf706  push rax
0000762f89bdf707  push rcx
0000762f89bdf708  push rdx
0000762f89bdf709  push rdi
0000762f89bdf70a  push rsi
0000762f89bdf70b  push r8
0000762f89bdf70d  push r9
0000762f89bdf70f  push r10
0000762f89bdf711  push r11
0000762f89bdf713  sub rsp, 0xF0
0000762f89bdf71a  vmovaps [rsp], xmm0
0000762f89bdf71f  vmovaps [rsp+0x10], xmm1
0000762f89bdf725  vmovaps [rsp+0x20], xmm2
0000762f89bdf72b  vmovaps [rsp+0x30], xmm3
0000762f89bdf731  vmovaps [rsp+0x40], xmm4
0000762f89bdf737  vmovaps [rsp+0x50], xmm5
0000762f89bdf73d  vmovaps [rsp+0x60], xmm6
0000762f89bdf743  vmovaps [rsp+0x70], xmm7
0000762f89bdf749  vmovaps [rsp+0x80], xmm8
0000762f89bdf752  vmovaps [rsp+0x90], xmm9
0000762f89bdf75b  vmovaps [rsp+0xA0], xmm10
0000762f89bdf764  vmovaps [rsp+0xB0], xmm11
0000762f89bdf76d  vmovaps [rsp+0xC0], xmm12
0000762f89bdf776  vmovaps [rsp+0xD0], xmm13
0000762f89bdf77f  vmovaps [rsp+0xE0], xmm15
0000762f89bdf788  sub rsp, 0x30
0000762f89bdf78c  movaps [rsp], xmm14
0000762f89bdf791  movaps [rsp+0x10], xmm8
0000762f89bdf797  movaps [rsp+0x20], xmm4
0000762f89bdf79c  lea rdi, [rsp]
0000762f89bdf7a0  mov esi, 0x00
0000762f89bdf7a5  mov rax, 0x604D6F946530
0000762f89bdf7af  call rax
0000762f89bdf7b1  movaps xmm14, [rsp]
0000762f89bdf7b6  add rsp, 0x30
0000762f89bdf7ba  vmovaps xmm0, [rsp]
0000762f89bdf7bf  vmovaps xmm1, [rsp+0x10]
0000762f89bdf7c5  vmovaps xmm2, [rsp+0x20]
0000762f89bdf7cb  vmovaps xmm3, [rsp+0x30]
0000762f89bdf7d1  vmovaps xmm4, [rsp+0x40]
0000762f89bdf7d7  vmovaps xmm5, [rsp+0x50]
0000762f89bdf7dd  vmovaps xmm6, [rsp+0x60]
0000762f89bdf7e3  vmovaps xmm7, [rsp+0x70]
0000762f89bdf7e9  vmovaps xmm8, [rsp+0x80]
0000762f89bdf7f2  vmovaps xmm9, [rsp+0x90]
0000762f89bdf7fb  vmovaps xmm10, [rsp+0xA0]
0000762f89bdf804  vmovaps xmm11, [rsp+0xB0]
0000762f89bdf80d  vmovaps xmm12, [rsp+0xC0]
0000762f89bdf816  vmovaps xmm13, [rsp+0xD0]
0000762f89bdf81f  vmovaps xmm15, [rsp+0xE0]
0000762f89bdf828  add rsp, 0xF0
0000762f89bdf82f  pop r11
0000762f89bdf831  pop r10
0000762f89bdf833  pop r9
0000762f89bdf835  pop r8
0000762f89bdf837  pop rsi
0000762f89bdf838  pop rdi
0000762f89bdf839  pop rdx
0000762f89bdf83a  pop rcx
0000762f89bdf83b  pop rax
0000762f89bdf83c  add rsp, 0x08
0000762f89bdf840  jmp 0x0000762F89BDC418
0000762f89bdf845  sub rsp, 0x08
0000762f89bdf849  push rax
0000762f89bdf84a  push rcx
0000762f89bdf84b  push rdx
0000762f89bdf84c  push rdi
0000762f89bdf84d  push rsi
0000762f89bdf84e  push r8
0000762f89bdf850  push r9
0000762f89bdf852  push r10
0000762f89bdf854  push r11
0000762f89bdf856  sub rsp, 0xF0
0000762f89bdf85d  vmovaps [rsp], xmm0
0000762f89bdf862  vmovaps [rsp+0x10], xmm1
0000762f89bdf868  vmovaps [rsp+0x20], xmm2
0000762f89bdf86e  vmovaps [rsp+0x30], xmm3
0000762f89bdf874  vmovaps [rsp+0x40], xmm5
0000762f89bdf87a  vmovaps [rsp+0x50], xmm6
0000762f89bdf880  vmovaps [rsp+0x60], xmm7
0000762f89bdf886  vmovaps [rsp+0x70], xmm8
0000762f89bdf88c  vmovaps [rsp+0x80], xmm9
0000762f89bdf895  vmovaps [rsp+0x90], xmm10
0000762f89bdf89e  vmovaps [rsp+0xA0], xmm11
0000762f89bdf8a7  vmovaps [rsp+0xB0], xmm12
0000762f89bdf8b0  vmovaps [rsp+0xC0], xmm13
0000762f89bdf8b9  vmovaps [rsp+0xD0], xmm14
0000762f89bdf8c2  vmovaps [rsp+0xE0], xmm15
0000762f89bdf8cb  sub rsp, 0x30
0000762f89bdf8cf  movaps [rsp], xmm4
0000762f89bdf8d3  movaps [rsp+0x10], xmm13
0000762f89bdf8d9  movaps [rsp+0x20], xmm8
0000762f89bdf8df  lea rdi, [rsp]
0000762f89bdf8e3  mov esi, 0x00
0000762f89bdf8e8  mov rax, 0x604D6F946530
0000762f89bdf8f2  call rax
0000762f89bdf8f4  movaps xmm4, [rsp]
0000762f89bdf8f8  add rsp, 0x30
0000762f89bdf8fc  vmovaps xmm0, [rsp]
0000762f89bdf901  vmovaps xmm1, [rsp+0x10]
0000762f89bdf907  vmovaps xmm2, [rsp+0x20]
0000762f89bdf90d  vmovaps xmm3, [rsp+0x30]
0000762f89bdf913  vmovaps xmm5, [rsp+0x40]
0000762f89bdf919  vmovaps xmm6, [rsp+0x50]
0000762f89bdf91f  vmovaps xmm7, [rsp+0x60]
0000762f89bdf925  vmovaps xmm8, [rsp+0x70]
0000762f89bdf92b  vmovaps xmm9, [rsp+0x80]
0000762f89bdf934  vmovaps xmm10, [rsp+0x90]
0000762f89bdf93d  vmovaps xmm11, [rsp+0xA0]
0000762f89bdf946  vmovaps xmm12, [rsp+0xB0]
0000762f89bdf94f  vmovaps xmm13, [rsp+0xC0]
0000762f89bdf958  vmovaps xmm14, [rsp+0xD0]
0000762f89bdf961  vmovaps xmm15, [rsp+0xE0]
0000762f89bdf96a  add rsp, 0xF0
0000762f89bdf971  pop r11
0000762f89bdf973  pop r10
0000762f89bdf975  pop r9
0000762f89bdf977  pop r8
0000762f89bdf979  pop rsi
0000762f89bdf97a  pop rdi
0000762f89bdf97b  pop rdx
0000762f89bdf97c  pop rcx
0000762f89bdf97d  pop rax
0000762f89bdf97e  add rsp, 0x08
0000762f89bdf982  jmp 0x0000762F89BDC43D
0000762f89bdf987  sub rsp, 0x08
0000762f89bdf98b  push rax
0000762f89bdf98c  push rcx
0000762f89bdf98d  push rdx
0000762f89bdf98e  push rdi
0000762f89bdf98f  push rsi
0000762f89bdf990  push r8
0000762f89bdf992  push r9
0000762f89bdf994  push r10
0000762f89bdf996  push r11
0000762f89bdf998  sub rsp, 0xF0
0000762f89bdf99f  vmovaps [rsp], xmm0
0000762f89bdf9a4  vmovaps [rsp+0x10], xmm1
0000762f89bdf9aa  vmovaps [rsp+0x20], xmm2
0000762f89bdf9b0  vmovaps [rsp+0x30], xmm3
0000762f89bdf9b6  vmovaps [rsp+0x40], xmm4
0000762f89bdf9bc  vmovaps [rsp+0x50], xmm5
0000762f89bdf9c2  vmovaps [rsp+0x60], xmm6
0000762f89bdf9c8  vmovaps [rsp+0x70], xmm7
0000762f89bdf9ce  vmovaps [rsp+0x80], xmm8
0000762f89bdf9d7  vmovaps [rsp+0x90], xmm9
0000762f89bdf9e0  vmovaps [rsp+0xA0], xmm10
0000762f89bdf9e9  vmovaps [rsp+0xB0], xmm11
0000762f89bdf9f2  vmovaps [rsp+0xC0], xmm12
0000762f89bdf9fb  vmovaps [rsp+0xD0], xmm14
0000762f89bdfa04  vmovaps [rsp+0xE0], xmm15
0000762f89bdfa0d  sub rsp, 0x30
0000762f89bdfa11  movaps [rsp], xmm13
0000762f89bdfa16  movaps [rsp+0x10], xmm15
0000762f89bdfa1c  movaps [rsp+0x20], xmm9
0000762f89bdfa22  lea rdi, [rsp]
0000762f89bdfa26  mov esi, 0x00
0000762f89bdfa2b  mov rax, 0x604D6F946530
0000762f89bdfa35  call rax
0000762f89bdfa37  movaps xmm13, [rsp]
0000762f89bdfa3c  add rsp, 0x30
0000762f89bdfa40  vmovaps xmm0, [rsp]
0000762f89bdfa45  vmovaps xmm1, [rsp+0x10]
0000762f89bdfa4b  vmovaps xmm2, [rsp+0x20]
0000762f89bdfa51  vmovaps xmm3, [rsp+0x30]
0000762f89bdfa57  vmovaps xmm4, [rsp+0x40]
0000762f89bdfa5d  vmovaps xmm5, [rsp+0x50]
0000762f89bdfa63  vmovaps xmm6, [rsp+0x60]
0000762f89bdfa69  vmovaps xmm7, [rsp+0x70]
0000762f89bdfa6f  vmovaps xmm8, [rsp+0x80]
0000762f89bdfa78  vmovaps xmm9, [rsp+0x90]
0000762f89bdfa81  vmovaps xmm10, [rsp+0xA0]
0000762f89bdfa8a  vmovaps xmm11, [rsp+0xB0]
0000762f89bdfa93  vmovaps xmm12, [rsp+0xC0]
0000762f89bdfa9c  vmovaps xmm14, [rsp+0xD0]
0000762f89bdfaa5  vmovaps xmm15, [rsp+0xE0]
0000762f89bdfaae  add rsp, 0xF0
0000762f89bdfab5  pop r11
0000762f89bdfab7  pop r10
0000762f89bdfab9  pop r9
0000762f89bdfabb  pop r8
0000762f89bdfabd  pop rsi
0000762f89bdfabe  pop rdi
0000762f89bdfabf  pop rdx
0000762f89bdfac0  pop rcx
0000762f89bdfac1  pop rax
0000762f89bdfac2  add rsp, 0x08
0000762f89bdfac6  jmp 0x0000762F89BDC458
0000762f89bdfacb  sub rsp, 0x08
0000762f89bdfacf  push rax
0000762f89bdfad0  push rcx
0000762f89bdfad1  push rdx
0000762f89bdfad2  push rdi
0000762f89bdfad3  push rsi
0000762f89bdfad4  push r8
0000762f89bdfad6  push r9
0000762f89bdfad8  push r10
0000762f89bdfada  push r11
0000762f89bdfadc  sub rsp, 0xF0
0000762f89bdfae3  vmovaps [rsp], xmm0
0000762f89bdfae8  vmovaps [rsp+0x10], xmm1
0000762f89bdfaee  vmovaps [rsp+0x20], xmm2
0000762f89bdfaf4  vmovaps [rsp+0x30], xmm3
0000762f89bdfafa  vmovaps [rsp+0x40], xmm4
0000762f89bdfb00  vmovaps [rsp+0x50], xmm5
0000762f89bdfb06  vmovaps [rsp+0x60], xmm6
0000762f89bdfb0c  vmovaps [rsp+0x70], xmm7
0000762f89bdfb12  vmovaps [rsp+0x80], xmm8
0000762f89bdfb1b  vmovaps [rsp+0x90], xmm9
0000762f89bdfb24  vmovaps [rsp+0xA0], xmm10
0000762f89bdfb2d  vmovaps [rsp+0xB0], xmm11
0000762f89bdfb36  vmovaps [rsp+0xC0], xmm12
0000762f89bdfb3f  vmovaps [rsp+0xD0], xmm13
0000762f89bdfb48  vmovaps [rsp+0xE0], xmm14
0000762f89bdfb51  sub rsp, 0x30
0000762f89bdfb55  movaps [rsp], xmm15
0000762f89bdfb5a  movaps [rsp+0x10], xmm1
0000762f89bdfb5f  movaps [rsp+0x20], xmm5
0000762f89bdfb64  lea rdi, [rsp]
0000762f89bdfb68  mov esi, 0x00
0000762f89bdfb6d  mov rax, 0x604D6F946530
0000762f89bdfb77  call rax
0000762f89bdfb79  movaps xmm15, [rsp]
0000762f89bdfb7e  add rsp, 0x30
0000762f89bdfb82  vmovaps xmm0, [rsp]
0000762f89bdfb87  vmovaps xmm1, [rsp+0x10]
0000762f89bdfb8d  vmovaps xmm2, [rsp+0x20]
0000762f89bdfb93  vmovaps xmm3, [rsp+0x30]
0000762f89bdfb99  vmovaps xmm4, [rsp+0x40]
0000762f89bdfb9f  vmovaps xmm5, [rsp+0x50]
0000762f89bdfba5  vmovaps xmm6, [rsp+0x60]
0000762f89bdfbab  vmovaps xmm7, [rsp+0x70]
0000762f89bdfbb1  vmovaps xmm8, [rsp+0x80]
0000762f89bdfbba  vmovaps xmm9, [rsp+0x90]
0000762f89bdfbc3  vmovaps xmm10, [rsp+0xA0]
0000762f89bdfbcc  vmovaps xmm11, [rsp+0xB0]
0000762f89bdfbd5  vmovaps xmm12, [rsp+0xC0]
0000762f89bdfbde  vmovaps xmm13, [rsp+0xD0]
0000762f89bdfbe7  vmovaps xmm14, [rsp+0xE0]
0000762f89bdfbf0  add rsp, 0xF0
0000762f89bdfbf7  pop r11
0000762f89bdfbf9  pop r10
0000762f89bdfbfb  pop r9
0000762f89bdfbfd  pop r8
0000762f89bdfbff  pop rsi
0000762f89bdfc00  pop rdi
0000762f89bdfc01  pop rdx
0000762f89bdfc02  pop rcx
0000762f89bdfc03  pop rax
0000762f89bdfc04  add rsp, 0x08
0000762f89bdfc08  jmp 0x0000762F89BDC473
0000762f89bdfc0d  call 0x0000762F89AB52F0
0000762f89bdfc12  jmp 0x0000762F89BDC4CE
0000762f89bdfc17  sub rsp, 0x08
0000762f89bdfc1b  push rax
0000762f89bdfc1c  push rcx
0000762f89bdfc1d  push rdx
0000762f89bdfc1e  push rdi
0000762f89bdfc1f  push rsi
0000762f89bdfc20  push r8
0000762f89bdfc22  push r9
0000762f89bdfc24  push r10
0000762f89bdfc26  push r11
0000762f89bdfc28  sub rsp, 0xF0
0000762f89bdfc2f  vmovaps [rsp], xmm0
0000762f89bdfc34  vmovaps [rsp+0x10], xmm1
0000762f89bdfc3a  vmovaps [rsp+0x20], xmm2
0000762f89bdfc40  vmovaps [rsp+0x30], xmm3
0000762f89bdfc46  vmovaps [rsp+0x40], xmm4
0000762f89bdfc4c  vmovaps [rsp+0x50], xmm5
0000762f89bdfc52  vmovaps [rsp+0x60], xmm6
0000762f89bdfc58  vmovaps [rsp+0x70], xmm7
0000762f89bdfc5e  vmovaps [rsp+0x80], xmm8
0000762f89bdfc67  vmovaps [rsp+0x90], xmm10
0000762f89bdfc70  vmovaps [rsp+0xA0], xmm11
0000762f89bdfc79  vmovaps [rsp+0xB0], xmm12
0000762f89bdfc82  vmovaps [rsp+0xC0], xmm13
0000762f89bdfc8b  vmovaps [rsp+0xD0], xmm14
0000762f89bdfc94  vmovaps [rsp+0xE0], xmm15
0000762f89bdfc9d  sub rsp, 0x30
0000762f89bdfca1  movaps [rsp], xmm9
0000762f89bdfca6  movaps [rsp+0x10], xmm8
0000762f89bdfcac  movaps [rsp+0x20], xmm11
0000762f89bdfcb2  lea rdi, [rsp]
0000762f89bdfcb6  mov esi, 0x00
0000762f89bdfcbb  mov rax, 0x604D6F946530
0000762f89bdfcc5  call rax
0000762f89bdfcc7  movaps xmm9, [rsp]
0000762f89bdfccc  add rsp, 0x30
0000762f89bdfcd0  vmovaps xmm0, [rsp]
0000762f89bdfcd5  vmovaps xmm1, [rsp+0x10]
0000762f89bdfcdb  vmovaps xmm2, [rsp+0x20]
0000762f89bdfce1  vmovaps xmm3, [rsp+0x30]
0000762f89bdfce7  vmovaps xmm4, [rsp+0x40]
0000762f89bdfced  vmovaps xmm5, [rsp+0x50]
0000762f89bdfcf3  vmovaps xmm6, [rsp+0x60]
0000762f89bdfcf9  vmovaps xmm7, [rsp+0x70]
0000762f89bdfcff  vmovaps xmm8, [rsp+0x80]
0000762f89bdfd08  vmovaps xmm10, [rsp+0x90]
0000762f89bdfd11  vmovaps xmm11, [rsp+0xA0]
0000762f89bdfd1a  vmovaps xmm12, [rsp+0xB0]
0000762f89bdfd23  vmovaps xmm13, [rsp+0xC0]
0000762f89bdfd2c  vmovaps xmm14, [rsp+0xD0]
0000762f89bdfd35  vmovaps xmm15, [rsp+0xE0]
0000762f89bdfd3e  add rsp, 0xF0
0000762f89bdfd45  pop r11
0000762f89bdfd47  pop r10
0000762f89bdfd49  pop r9
0000762f89bdfd4b  pop r8
0000762f89bdfd4d  pop rsi
0000762f89bdfd4e  pop rdi
0000762f89bdfd4f  pop rdx
0000762f89bdfd50  pop rcx
0000762f89bdfd51  pop rax
0000762f89bdfd52  add rsp, 0x08
0000762f89bdfd56  jmp 0x0000762F89BDC505
0000762f89bdfd5b  sub rsp, 0x08
0000762f89bdfd5f  push rax
0000762f89bdfd60  push rcx
0000762f89bdfd61  push rdx
0000762f89bdfd62  push rdi
0000762f89bdfd63  push rsi
0000762f89bdfd64  push r8
0000762f89bdfd66  push r9
0000762f89bdfd68  push r10
0000762f89bdfd6a  push r11
0000762f89bdfd6c  sub rsp, 0xF0
0000762f89bdfd73  vmovaps [rsp], xmm0
0000762f89bdfd78  vmovaps [rsp+0x10], xmm1
0000762f89bdfd7e  vmovaps [rsp+0x20], xmm2
0000762f89bdfd84  vmovaps [rsp+0x30], xmm3
0000762f89bdfd8a  vmovaps [rsp+0x40], xmm4
0000762f89bdfd90  vmovaps [rsp+0x50], xmm5
0000762f89bdfd96  vmovaps [rsp+0x60], xmm6
0000762f89bdfd9c  vmovaps [rsp+0x70], xmm7
0000762f89bdfda2  vmovaps [rsp+0x80], xmm8
0000762f89bdfdab  vmovaps [rsp+0x90], xmm9
0000762f89bdfdb4  vmovaps [rsp+0xA0], xmm10
0000762f89bdfdbd  vmovaps [rsp+0xB0], xmm12
0000762f89bdfdc6  vmovaps [rsp+0xC0], xmm13
0000762f89bdfdcf  vmovaps [rsp+0xD0], xmm14
0000762f89bdfdd8  vmovaps [rsp+0xE0], xmm15
0000762f89bdfde1  sub rsp, 0x30
0000762f89bdfde5  movaps [rsp], xmm11
0000762f89bdfdea  movaps [rsp+0x10], xmm10
0000762f89bdfdf0  movaps [rsp+0x20], xmm6
0000762f89bdfdf5  lea rdi, [rsp]
0000762f89bdfdf9  mov esi, 0x00
0000762f89bdfdfe  mov rax, 0x604D6F946530
0000762f89bdfe08  call rax
0000762f89bdfe0a  movaps xmm11, [rsp]
0000762f89bdfe0f  add rsp, 0x30
0000762f89bdfe13  vmovaps xmm0, [rsp]
0000762f89bdfe18  vmovaps xmm1, [rsp+0x10]
0000762f89bdfe1e  vmovaps xmm2, [rsp+0x20]
0000762f89bdfe24  vmovaps xmm3, [rsp+0x30]
0000762f89bdfe2a  vmovaps xmm4, [rsp+0x40]
0000762f89bdfe30  vmovaps xmm5, [rsp+0x50]
0000762f89bdfe36  vmovaps xmm6, [rsp+0x60]
0000762f89bdfe3c  vmovaps xmm7, [rsp+0x70]
0000762f89bdfe42  vmovaps xmm8, [rsp+0x80]
0000762f89bdfe4b  vmovaps xmm9, [rsp+0x90]
0000762f89bdfe54  vmovaps xmm10, [rsp+0xA0]
0000762f89bdfe5d  vmovaps xmm12, [rsp+0xB0]
0000762f89bdfe66  vmovaps xmm13, [rsp+0xC0]
0000762f89bdfe6f  vmovaps xmm14, [rsp+0xD0]
0000762f89bdfe78  vmovaps xmm15, [rsp+0xE0]
0000762f89bdfe81  add rsp, 0xF0
0000762f89bdfe88  pop r11
0000762f89bdfe8a  pop r10
0000762f89bdfe8c  pop r9
0000762f89bdfe8e  pop r8
0000762f89bdfe90  pop rsi
0000762f89bdfe91  pop rdi
0000762f89bdfe92  pop rdx
0000762f89bdfe93  pop rcx
0000762f89bdfe94  pop rax
0000762f89bdfe95  add rsp, 0x08
0000762f89bdfe99  jmp 0x0000762F89BDC520
0000762f89bdfe9e  sub rsp, 0x08
0000762f89bdfea2  push rax
0000762f89bdfea3  push rcx
0000762f89bdfea4  push rdx
0000762f89bdfea5  push rdi
0000762f89bdfea6  push rsi
0000762f89bdfea7  push r8
0000762f89bdfea9  push r9
0000762f89bdfeab  push r10
0000762f89bdfead  push r11
0000762f89bdfeaf  sub rsp, 0xF0
0000762f89bdfeb6  vmovaps [rsp], xmm0
0000762f89bdfebb  vmovaps [rsp+0x10], xmm1
0000762f89bdfec1  vmovaps [rsp+0x20], xmm2
0000762f89bdfec7  vmovaps [rsp+0x30], xmm3
0000762f89bdfecd  vmovaps [rsp+0x40], xmm4
0000762f89bdfed3  vmovaps [rsp+0x50], xmm5
0000762f89bdfed9  vmovaps [rsp+0x60], xmm6
0000762f89bdfedf  vmovaps [rsp+0x70], xmm7
0000762f89bdfee5  vmovaps [rsp+0x80], xmm8
0000762f89bdfeee  vmovaps [rsp+0x90], xmm9
0000762f89bdfef7  vmovaps [rsp+0xA0], xmm11
0000762f89bdff00  vmovaps [rsp+0xB0], xmm12
0000762f89bdff09  vmovaps [rsp+0xC0], xmm13
0000762f89bdff12  vmovaps [rsp+0xD0], xmm14
0000762f89bdff1b  vmovaps [rsp+0xE0], xmm15
0000762f89bdff24  sub rsp, 0x30
0000762f89bdff28  movaps [rsp], xmm10
0000762f89bdff2d  movaps [rsp+0x10], xmm14
0000762f89bdff33  movaps [rsp+0x20], xmm4
0000762f89bdff38  lea rdi, [rsp]
0000762f89bdff3c  mov esi, 0x00
0000762f89bdff41  mov rax, 0x604D6F946530
0000762f89bdff4b  call rax
0000762f89bdff4d  movaps xmm10, [rsp]
0000762f89bdff52  add rsp, 0x30
0000762f89bdff56  vmovaps xmm0, [rsp]
0000762f89bdff5b  vmovaps xmm1, [rsp+0x10]
0000762f89bdff61  vmovaps xmm2, [rsp+0x20]
0000762f89bdff67  vmovaps xmm3, [rsp+0x30]
0000762f89bdff6d  vmovaps xmm4, [rsp+0x40]
0000762f89bdff73  vmovaps xmm5, [rsp+0x50]
0000762f89bdff79  vmovaps xmm6, [rsp+0x60]
0000762f89bdff7f  vmovaps xmm7, [rsp+0x70]
0000762f89bdff85  vmovaps xmm8, [rsp+0x80]
0000762f89bdff8e  vmovaps xmm9, [rsp+0x90]
0000762f89bdff97  vmovaps xmm11, [rsp+0xA0]
0000762f89bdffa0  vmovaps xmm12, [rsp+0xB0]
0000762f89bdffa9  vmovaps xmm13, [rsp+0xC0]
0000762f89bdffb2  vmovaps xmm14, [rsp+0xD0]
0000762f89bdffbb  vmovaps xmm15, [rsp+0xE0]
0000762f89bdffc4  add rsp, 0xF0
0000762f89bdffcb  pop r11
0000762f89bdffcd  pop r10
0000762f89bdffcf  pop r9
0000762f89bdffd1  pop r8
0000762f89bdffd3  pop rsi
0000762f89bdffd4  pop rdi
0000762f89bdffd5  pop rdx
0000762f89bdffd6  pop rcx
0000762f89bdffd7  pop rax
0000762f89bdffd8  add rsp, 0x08
0000762f89bdffdc  jmp 0x0000762F89BDC53B
0000762f89bdffe1  sub rsp, 0x08
0000762f89bdffe5  push rax
0000762f89bdffe6  push rcx
0000762f89bdffe7  push rdx
0000762f89bdffe8  push rdi
0000762f89bdffe9  push rsi
0000762f89bdffea  push r8
0000762f89bdffec  push r9
0000762f89bdffee  push r10
0000762f89bdfff0  push r11
0000762f89bdfff2  sub rsp, 0xF0
0000762f89bdfff9  vmovaps [rsp], xmm0
0000762f89bdfffe  vmovaps [rsp+0x10], xmm1
0000762f89be0004  vmovaps [rsp+0x20], xmm2
0000762f89be000a  vmovaps [rsp+0x30], xmm3
0000762f89be0010  vmovaps [rsp+0x40], xmm4
0000762f89be0016  vmovaps [rsp+0x50], xmm5
0000762f89be001c  vmovaps [rsp+0x60], xmm6
0000762f89be0022  vmovaps [rsp+0x70], xmm7
0000762f89be0028  vmovaps [rsp+0x80], xmm9
0000762f89be0031  vmovaps [rsp+0x90], xmm10
0000762f89be003a  vmovaps [rsp+0xA0], xmm11
0000762f89be0043  vmovaps [rsp+0xB0], xmm12
0000762f89be004c  vmovaps [rsp+0xC0], xmm13
0000762f89be0055  vmovaps [rsp+0xD0], xmm14
0000762f89be005e  vmovaps [rsp+0xE0], xmm15
0000762f89be0067  sub rsp, 0x30
0000762f89be006b  movaps [rsp], xmm8
0000762f89be0070  movaps [rsp+0x10], xmm1
0000762f89be0075  movaps [rsp+0x20], xmm14
0000762f89be007b  lea rdi, [rsp]
0000762f89be007f  mov esi, 0x00
0000762f89be0084  mov rax, 0x604D6F946530
0000762f89be008e  call rax
0000762f89be0090  movaps xmm8, [rsp]
0000762f89be0095  add rsp, 0x30
0000762f89be0099  vmovaps xmm0, [rsp]
0000762f89be009e  vmovaps xmm1, [rsp+0x10]
0000762f89be00a4  vmovaps xmm2, [rsp+0x20]
0000762f89be00aa  vmovaps xmm3, [rsp+0x30]
0000762f89be00b0  vmovaps xmm4, [rsp+0x40]
0000762f89be00b6  vmovaps xmm5, [rsp+0x50]
0000762f89be00bc  vmovaps xmm6, [rsp+0x60]
0000762f89be00c2  vmovaps xmm7, [rsp+0x70]
0000762f89be00c8  vmovaps xmm9, [rsp+0x80]
0000762f89be00d1  vmovaps xmm10, [rsp+0x90]
0000762f89be00da  vmovaps xmm11, [rsp+0xA0]
0000762f89be00e3  vmovaps xmm12, [rsp+0xB0]
0000762f89be00ec  vmovaps xmm13, [rsp+0xC0]
0000762f89be00f5  vmovaps xmm14, [rsp+0xD0]
0000762f89be00fe  vmovaps xmm15, [rsp+0xE0]
0000762f89be0107  add rsp, 0xF0
0000762f89be010e  pop r11
0000762f89be0110  pop r10
0000762f89be0112  pop r9
0000762f89be0114  pop r8
0000762f89be0116  pop rsi
0000762f89be0117  pop rdi
0000762f89be0118  pop rdx
0000762f89be0119  pop rcx
0000762f89be011a  pop rax
0000762f89be011b  add rsp, 0x08
0000762f89be011f  jmp 0x0000762F89BDC561
0000762f89be0124  sub rsp, 0x08
0000762f89be0128  push rax
0000762f89be0129  push rcx
0000762f89be012a  push rdx
0000762f89be012b  push rdi
0000762f89be012c  push rsi
0000762f89be012d  push r8
0000762f89be012f  push r9
0000762f89be0131  push r10
0000762f89be0133  push r11
0000762f89be0135  sub rsp, 0xF0
0000762f89be013c  vmovaps [rsp], xmm0
0000762f89be0141  vmovaps [rsp+0x10], xmm1
0000762f89be0147  vmovaps [rsp+0x20], xmm2
0000762f89be014d  vmovaps [rsp+0x30], xmm3
0000762f89be0153  vmovaps [rsp+0x40], xmm4
0000762f89be0159  vmovaps [rsp+0x50], xmm5
0000762f89be015f  vmovaps [rsp+0x60], xmm7
0000762f89be0165  vmovaps [rsp+0x70], xmm8
0000762f89be016b  vmovaps [rsp+0x80], xmm9
0000762f89be0174  vmovaps [rsp+0x90], xmm10
0000762f89be017d  vmovaps [rsp+0xA0], xmm11
0000762f89be0186  vmovaps [rsp+0xB0], xmm12
0000762f89be018f  vmovaps [rsp+0xC0], xmm13
0000762f89be0198  vmovaps [rsp+0xD0], xmm14
0000762f89be01a1  vmovaps [rsp+0xE0], xmm15
0000762f89be01aa  sub rsp, 0x30
0000762f89be01ae  movaps [rsp], xmm6
0000762f89be01b2  movaps [rsp+0x10], xmm1
0000762f89be01b7  movaps [rsp+0x20], xmm14
0000762f89be01bd  lea rdi, [rsp]
0000762f89be01c1  mov esi, 0x00
0000762f89be01c6  mov rax, 0x604D6F946530
0000762f89be01d0  call rax
0000762f89be01d2  movaps xmm6, [rsp]
0000762f89be01d6  add rsp, 0x30
0000762f89be01da  vmovaps xmm0, [rsp]
0000762f89be01df  vmovaps xmm1, [rsp+0x10]
0000762f89be01e5  vmovaps xmm2, [rsp+0x20]
0000762f89be01eb  vmovaps xmm3, [rsp+0x30]
0000762f89be01f1  vmovaps xmm4, [rsp+0x40]
0000762f89be01f7  vmovaps xmm5, [rsp+0x50]
0000762f89be01fd  vmovaps xmm7, [rsp+0x60]
0000762f89be0203  vmovaps xmm8, [rsp+0x70]
0000762f89be0209  vmovaps xmm9, [rsp+0x80]
0000762f89be0212  vmovaps xmm10, [rsp+0x90]
0000762f89be021b  vmovaps xmm11, [rsp+0xA0]
0000762f89be0224  vmovaps xmm12, [rsp+0xB0]
0000762f89be022d  vmovaps xmm13, [rsp+0xC0]
0000762f89be0236  vmovaps xmm14, [rsp+0xD0]
0000762f89be023f  vmovaps xmm15, [rsp+0xE0]
0000762f89be0248  add rsp, 0xF0
0000762f89be024f  pop r11
0000762f89be0251  pop r10
0000762f89be0253  pop r9
0000762f89be0255  pop r8
0000762f89be0257  pop rsi
0000762f89be0258  pop rdi
0000762f89be0259  pop rdx
0000762f89be025a  pop rcx
0000762f89be025b  pop rax
0000762f89be025c  add rsp, 0x08
0000762f89be0260  jmp 0x0000762F89BDC58D
0000762f89be0265  sub rsp, 0x08
0000762f89be0269  push rax
0000762f89be026a  push rcx
0000762f89be026b  push rdx
0000762f89be026c  push rdi
0000762f89be026d  push rsi
0000762f89be026e  push r8
0000762f89be0270  push r9
0000762f89be0272  push r10
0000762f89be0274  push r11
0000762f89be0276  sub rsp, 0xF0
0000762f89be027d  vmovaps [rsp], xmm0
0000762f89be0282  vmovaps [rsp+0x10], xmm1
0000762f89be0288  vmovaps [rsp+0x20], xmm2
0000762f89be028e  vmovaps [rsp+0x30], xmm3
0000762f89be0294  vmovaps [rsp+0x40], xmm4
0000762f89be029a  vmovaps [rsp+0x50], xmm5
0000762f89be02a0  vmovaps [rsp+0x60], xmm6
0000762f89be02a6  vmovaps [rsp+0x70], xmm7
0000762f89be02ac  vmovaps [rsp+0x80], xmm8
0000762f89be02b5  vmovaps [rsp+0x90], xmm9
0000762f89be02be  vmovaps [rsp+0xA0], xmm10
0000762f89be02c7  vmovaps [rsp+0xB0], xmm11
0000762f89be02d0  vmovaps [rsp+0xC0], xmm12
0000762f89be02d9  vmovaps [rsp+0xD0], xmm13
0000762f89be02e2  vmovaps [rsp+0xE0], xmm15
0000762f89be02eb  sub rsp, 0x30
0000762f89be02ef  movaps [rsp], xmm14
0000762f89be02f4  movaps [rsp+0x10], xmm12
0000762f89be02fa  movaps [rsp+0x20], xmm1
0000762f89be02ff  lea rdi, [rsp]
0000762f89be0303  mov esi, 0x00
0000762f89be0308  mov rax, 0x604D6F946530
0000762f89be0312  call rax
0000762f89be0314  movaps xmm14, [rsp]
0000762f89be0319  add rsp, 0x30
0000762f89be031d  vmovaps xmm0, [rsp]
0000762f89be0322  vmovaps xmm1, [rsp+0x10]
0000762f89be0328  vmovaps xmm2, [rsp+0x20]
0000762f89be032e  vmovaps xmm3, [rsp+0x30]
0000762f89be0334  vmovaps xmm4, [rsp+0x40]
0000762f89be033a  vmovaps xmm5, [rsp+0x50]
0000762f89be0340  vmovaps xmm6, [rsp+0x60]
0000762f89be0346  vmovaps xmm7, [rsp+0x70]
0000762f89be034c  vmovaps xmm8, [rsp+0x80]
0000762f89be0355  vmovaps xmm9, [rsp+0x90]
0000762f89be035e  vmovaps xmm10, [rsp+0xA0]
0000762f89be0367  vmovaps xmm11, [rsp+0xB0]
0000762f89be0370  vmovaps xmm12, [rsp+0xC0]
0000762f89be0379  vmovaps xmm13, [rsp+0xD0]
0000762f89be0382  vmovaps xmm15, [rsp+0xE0]
0000762f89be038b  add rsp, 0xF0
0000762f89be0392  pop r11
0000762f89be0394  pop r10
0000762f89be0396  pop r9
0000762f89be0398  pop r8
0000762f89be039a  pop rsi
0000762f89be039b  pop rdi
0000762f89be039c  pop rdx
0000762f89be039d  pop rcx
0000762f89be039e  pop rax
0000762f89be039f  add rsp, 0x08
0000762f89be03a3  jmp 0x0000762F89BDC5B3
0000762f89be03a8  sub rsp, 0x08
0000762f89be03ac  push rax
0000762f89be03ad  push rcx
0000762f89be03ae  push rdx
0000762f89be03af  push rdi
0000762f89be03b0  push rsi
0000762f89be03b1  push r8
0000762f89be03b3  push r9
0000762f89be03b5  push r10
0000762f89be03b7  push r11
0000762f89be03b9  sub rsp, 0xF0
0000762f89be03c0  vmovaps [rsp], xmm0
0000762f89be03c5  vmovaps [rsp+0x10], xmm2
0000762f89be03cb  vmovaps [rsp+0x20], xmm3
0000762f89be03d1  vmovaps [rsp+0x30], xmm4
0000762f89be03d7  vmovaps [rsp+0x40], xmm5
0000762f89be03dd  vmovaps [rsp+0x50], xmm6
0000762f89be03e3  vmovaps [rsp+0x60], xmm7
0000762f89be03e9  vmovaps [rsp+0x70], xmm8
0000762f89be03ef  vmovaps [rsp+0x80], xmm9
0000762f89be03f8  vmovaps [rsp+0x90], xmm10
0000762f89be0401  vmovaps [rsp+0xA0], xmm11
0000762f89be040a  vmovaps [rsp+0xB0], xmm12
0000762f89be0413  vmovaps [rsp+0xC0], xmm13
0000762f89be041c  vmovaps [rsp+0xD0], xmm14
0000762f89be0425  vmovaps [rsp+0xE0], xmm15
0000762f89be042e  sub rsp, 0x30
0000762f89be0432  movaps [rsp], xmm1
0000762f89be0436  movaps [rsp+0x10], xmm13
0000762f89be043c  movaps [rsp+0x20], xmm9
0000762f89be0442  lea rdi, [rsp]
0000762f89be0446  mov esi, 0x00
0000762f89be044b  mov rax, 0x604D6F946530
0000762f89be0455  call rax
0000762f89be0457  movaps xmm1, [rsp]
0000762f89be045b  add rsp, 0x30
0000762f89be045f  vmovaps xmm0, [rsp]
0000762f89be0464  vmovaps xmm2, [rsp+0x10]
0000762f89be046a  vmovaps xmm3, [rsp+0x20]
0000762f89be0470  vmovaps xmm4, [rsp+0x30]
0000762f89be0476  vmovaps xmm5, [rsp+0x40]
0000762f89be047c  vmovaps xmm6, [rsp+0x50]
0000762f89be0482  vmovaps xmm7, [rsp+0x60]
0000762f89be0488  vmovaps xmm8, [rsp+0x70]
0000762f89be048e  vmovaps xmm9, [rsp+0x80]
0000762f89be0497  vmovaps xmm10, [rsp+0x90]
0000762f89be04a0  vmovaps xmm11, [rsp+0xA0]
0000762f89be04a9  vmovaps xmm12, [rsp+0xB0]
0000762f89be04b2  vmovaps xmm13, [rsp+0xC0]
0000762f89be04bb  vmovaps xmm14, [rsp+0xD0]
0000762f89be04c4  vmovaps xmm15, [rsp+0xE0]
0000762f89be04cd  add rsp, 0xF0
0000762f89be04d4  pop r11
0000762f89be04d6  pop r10
0000762f89be04d8  pop r9
0000762f89be04da  pop r8
0000762f89be04dc  pop rsi
0000762f89be04dd  pop rdi
0000762f89be04de  pop rdx
0000762f89be04df  pop rcx
0000762f89be04e0  pop rax
0000762f89be04e1  add rsp, 0x08
0000762f89be04e5  jmp 0x0000762F89BDC5CD
0000762f89be04ea  sub rsp, 0x08
0000762f89be04ee  push rax
0000762f89be04ef  push rcx
0000762f89be04f0  push rdx
0000762f89be04f1  push rdi
0000762f89be04f2  push rsi
0000762f89be04f3  push r8
0000762f89be04f5  push r9
0000762f89be04f7  push r10
0000762f89be04f9  push r11
0000762f89be04fb  sub rsp, 0xF0
0000762f89be0502  vmovaps [rsp], xmm0
0000762f89be0507  vmovaps [rsp+0x10], xmm1
0000762f89be050d  vmovaps [rsp+0x20], xmm2
0000762f89be0513  vmovaps [rsp+0x30], xmm3
0000762f89be0519  vmovaps [rsp+0x40], xmm4
0000762f89be051f  vmovaps [rsp+0x50], xmm5
0000762f89be0525  vmovaps [rsp+0x60], xmm6
0000762f89be052b  vmovaps [rsp+0x70], xmm7
0000762f89be0531  vmovaps [rsp+0x80], xmm8
0000762f89be053a  vmovaps [rsp+0x90], xmm9
0000762f89be0543  vmovaps [rsp+0xA0], xmm10
0000762f89be054c  vmovaps [rsp+0xB0], xmm11
0000762f89be0555  vmovaps [rsp+0xC0], xmm13
0000762f89be055e  vmovaps [rsp+0xD0], xmm14
0000762f89be0567  vmovaps [rsp+0xE0], xmm15
0000762f89be0570  sub rsp, 0x30
0000762f89be0574  movaps [rsp], xmm12
0000762f89be0579  movaps [rsp+0x10], xmm7
0000762f89be057e  movaps [rsp+0x20], xmm13
0000762f89be0584  lea rdi, [rsp]
0000762f89be0588  mov esi, 0x00
0000762f89be058d  mov rax, 0x604D6F946530
0000762f89be0597  call rax
0000762f89be0599  movaps xmm12, [rsp]
0000762f89be059e  add rsp, 0x30
0000762f89be05a2  vmovaps xmm0, [rsp]
0000762f89be05a7  vmovaps xmm1, [rsp+0x10]
0000762f89be05ad  vmovaps xmm2, [rsp+0x20]
0000762f89be05b3  vmovaps xmm3, [rsp+0x30]
0000762f89be05b9  vmovaps xmm4, [rsp+0x40]
0000762f89be05bf  vmovaps xmm5, [rsp+0x50]
0000762f89be05c5  vmovaps xmm6, [rsp+0x60]
0000762f89be05cb  vmovaps xmm7, [rsp+0x70]
0000762f89be05d1  vmovaps xmm8, [rsp+0x80]
0000762f89be05da  vmovaps xmm9, [rsp+0x90]
0000762f89be05e3  vmovaps xmm10, [rsp+0xA0]
0000762f89be05ec  vmovaps xmm11, [rsp+0xB0]
0000762f89be05f5  vmovaps xmm13, [rsp+0xC0]
0000762f89be05fe  vmovaps xmm14, [rsp+0xD0]
0000762f89be0607  vmovaps xmm15, [rsp+0xE0]
0000762f89be0610  add rsp, 0xF0
0000762f89be0617  pop r11
0000762f89be0619  pop r10
0000762f89be061b  pop r9
0000762f89be061d  pop r8
0000762f89be061f  pop rsi
0000762f89be0620  pop rdi
0000762f89be0621  pop rdx
0000762f89be0622  pop rcx
0000762f89be0623  pop rax
0000762f89be0624  add rsp, 0x08
0000762f89be0628  jmp 0x0000762F89BDC5F4
0000762f89be062d  sub rsp, 0x08
0000762f89be0631  push rax
0000762f89be0632  push rcx
0000762f89be0633  push rdx
0000762f89be0634  push rdi
0000762f89be0635  push rsi
0000762f89be0636  push r8
0000762f89be0638  push r9
0000762f89be063a  push r10
0000762f89be063c  push r11
0000762f89be063e  sub rsp, 0xF0
0000762f89be0645  vmovaps [rsp], xmm0
0000762f89be064a  vmovaps [rsp+0x10], xmm1
0000762f89be0650  vmovaps [rsp+0x20], xmm2
0000762f89be0656  vmovaps [rsp+0x30], xmm3
0000762f89be065c  vmovaps [rsp+0x40], xmm4
0000762f89be0662  vmovaps [rsp+0x50], xmm5
0000762f89be0668  vmovaps [rsp+0x60], xmm6
0000762f89be066e  vmovaps [rsp+0x70], xmm7
0000762f89be0674  vmovaps [rsp+0x80], xmm8
0000762f89be067d  vmovaps [rsp+0x90], xmm9
0000762f89be0686  vmovaps [rsp+0xA0], xmm10
0000762f89be068f  vmovaps [rsp+0xB0], xmm11
0000762f89be0698  vmovaps [rsp+0xC0], xmm12
0000762f89be06a1  vmovaps [rsp+0xD0], xmm14
0000762f89be06aa  vmovaps [rsp+0xE0], xmm15
0000762f89be06b3  sub rsp, 0x30
0000762f89be06b7  movaps [rsp], xmm13
0000762f89be06bc  movaps [rsp+0x10], xmm15
0000762f89be06c2  movaps [rsp+0x20], xmm8
0000762f89be06c8  lea rdi, [rsp]
0000762f89be06cc  mov esi, 0x00
0000762f89be06d1  mov rax, 0x604D6F946530
0000762f89be06db  call rax
0000762f89be06dd  movaps xmm13, [rsp]
0000762f89be06e2  add rsp, 0x30
0000762f89be06e6  vmovaps xmm0, [rsp]
0000762f89be06eb  vmovaps xmm1, [rsp+0x10]
0000762f89be06f1  vmovaps xmm2, [rsp+0x20]
0000762f89be06f7  vmovaps xmm3, [rsp+0x30]
0000762f89be06fd  vmovaps xmm4, [rsp+0x40]
0000762f89be0703  vmovaps xmm5, [rsp+0x50]
0000762f89be0709  vmovaps xmm6, [rsp+0x60]
0000762f89be070f  vmovaps xmm7, [rsp+0x70]
0000762f89be0715  vmovaps xmm8, [rsp+0x80]
0000762f89be071e  vmovaps xmm9, [rsp+0x90]
0000762f89be0727  vmovaps xmm10, [rsp+0xA0]
0000762f89be0730  vmovaps xmm11, [rsp+0xB0]
0000762f89be0739  vmovaps xmm12, [rsp+0xC0]
0000762f89be0742  vmovaps xmm14, [rsp+0xD0]
0000762f89be074b  vmovaps xmm15, [rsp+0xE0]
0000762f89be0754  add rsp, 0xF0
0000762f89be075b  pop r11
0000762f89be075d  pop r10
0000762f89be075f  pop r9
0000762f89be0761  pop r8
0000762f89be0763  pop rsi
0000762f89be0764  pop rdi
0000762f89be0765  pop rdx
0000762f89be0766  pop rcx
0000762f89be0767  pop rax
0000762f89be0768  add rsp, 0x08
0000762f89be076c  jmp 0x0000762F89BDC60F
0000762f89be0771  sub rsp, 0x08
0000762f89be0775  push rax
0000762f89be0776  push rcx
0000762f89be0777  push rdx
0000762f89be0778  push rdi
0000762f89be0779  push rsi
0000762f89be077a  push r8
0000762f89be077c  push r9
0000762f89be077e  push r10
0000762f89be0780  push r11
0000762f89be0782  sub rsp, 0xF0
0000762f89be0789  vmovaps [rsp], xmm0
0000762f89be078e  vmovaps [rsp+0x10], xmm1
0000762f89be0794  vmovaps [rsp+0x20], xmm2
0000762f89be079a  vmovaps [rsp+0x30], xmm3
0000762f89be07a0  vmovaps [rsp+0x40], xmm4
0000762f89be07a6  vmovaps [rsp+0x50], xmm5
0000762f89be07ac  vmovaps [rsp+0x60], xmm6
0000762f89be07b2  vmovaps [rsp+0x70], xmm7
0000762f89be07b8  vmovaps [rsp+0x80], xmm9
0000762f89be07c1  vmovaps [rsp+0x90], xmm10
0000762f89be07ca  vmovaps [rsp+0xA0], xmm11
0000762f89be07d3  vmovaps [rsp+0xB0], xmm12
0000762f89be07dc  vmovaps [rsp+0xC0], xmm13
0000762f89be07e5  vmovaps [rsp+0xD0], xmm14
0000762f89be07ee  vmovaps [rsp+0xE0], xmm15
0000762f89be07f7  sub rsp, 0x30
0000762f89be07fb  movaps [rsp], xmm8
0000762f89be0800  movaps [rsp+0x10], xmm15
0000762f89be0806  movaps [rsp+0x20], xmm9
0000762f89be080c  lea rdi, [rsp]
0000762f89be0810  mov esi, 0x00
0000762f89be0815  mov rax, 0x604D6F946530
0000762f89be081f  call rax
0000762f89be0821  movaps xmm8, [rsp]
0000762f89be0826  add rsp, 0x30
0000762f89be082a  vmovaps xmm0, [rsp]
0000762f89be082f  vmovaps xmm1, [rsp+0x10]
0000762f89be0835  vmovaps xmm2, [rsp+0x20]
0000762f89be083b  vmovaps xmm3, [rsp+0x30]
0000762f89be0841  vmovaps xmm4, [rsp+0x40]
0000762f89be0847  vmovaps xmm5, [rsp+0x50]
0000762f89be084d  vmovaps xmm6, [rsp+0x60]
0000762f89be0853  vmovaps xmm7, [rsp+0x70]
0000762f89be0859  vmovaps xmm9, [rsp+0x80]
0000762f89be0862  vmovaps xmm10, [rsp+0x90]
0000762f89be086b  vmovaps xmm11, [rsp+0xA0]
0000762f89be0874  vmovaps xmm12, [rsp+0xB0]
0000762f89be087d  vmovaps xmm13, [rsp+0xC0]
0000762f89be0886  vmovaps xmm14, [rsp+0xD0]
0000762f89be088f  vmovaps xmm15, [rsp+0xE0]
0000762f89be0898  add rsp, 0xF0
0000762f89be089f  pop r11
0000762f89be08a1  pop r10
0000762f89be08a3  pop r9
0000762f89be08a5  pop r8
0000762f89be08a7  pop rsi
0000762f89be08a8  pop rdi
0000762f89be08a9  pop rdx
0000762f89be08aa  pop rcx
0000762f89be08ab  pop rax
0000762f89be08ac  add rsp, 0x08
0000762f89be08b0  jmp 0x0000762F89BDC63D
0000762f89be08b5  sub rsp, 0x08
0000762f89be08b9  push rax
0000762f89be08ba  push rcx
0000762f89be08bb  push rdx
0000762f89be08bc  push rdi
0000762f89be08bd  push rsi
0000762f89be08be  push r8
0000762f89be08c0  push r9
0000762f89be08c2  push r10
0000762f89be08c4  push r11
0000762f89be08c6  sub rsp, 0xF0
0000762f89be08cd  vmovaps [rsp], xmm0
0000762f89be08d2  vmovaps [rsp+0x10], xmm1
0000762f89be08d8  vmovaps [rsp+0x20], xmm2
0000762f89be08de  vmovaps [rsp+0x30], xmm3
0000762f89be08e4  vmovaps [rsp+0x40], xmm4
0000762f89be08ea  vmovaps [rsp+0x50], xmm5
0000762f89be08f0  vmovaps [rsp+0x60], xmm6
0000762f89be08f6  vmovaps [rsp+0x70], xmm7
0000762f89be08fc  vmovaps [rsp+0x80], xmm8
0000762f89be0905  vmovaps [rsp+0x90], xmm9
0000762f89be090e  vmovaps [rsp+0xA0], xmm10
0000762f89be0917  vmovaps [rsp+0xB0], xmm11
0000762f89be0920  vmovaps [rsp+0xC0], xmm12
0000762f89be0929  vmovaps [rsp+0xD0], xmm13
0000762f89be0932  vmovaps [rsp+0xE0], xmm14
0000762f89be093b  sub rsp, 0x30
0000762f89be093f  movaps [rsp], xmm15
0000762f89be0944  movaps [rsp+0x10], xmm11
0000762f89be094a  movaps [rsp+0x20], xmm6
0000762f89be094f  lea rdi, [rsp]
0000762f89be0953  mov esi, 0x00
0000762f89be0958  mov rax, 0x604D6F946530
0000762f89be0962  call rax
0000762f89be0964  movaps xmm15, [rsp]
0000762f89be0969  add rsp, 0x30
0000762f89be096d  vmovaps xmm0, [rsp]
0000762f89be0972  vmovaps xmm1, [rsp+0x10]
0000762f89be0978  vmovaps xmm2, [rsp+0x20]
0000762f89be097e  vmovaps xmm3, [rsp+0x30]
0000762f89be0984  vmovaps xmm4, [rsp+0x40]
0000762f89be098a  vmovaps xmm5, [rsp+0x50]
0000762f89be0990  vmovaps xmm6, [rsp+0x60]
0000762f89be0996  vmovaps xmm7, [rsp+0x70]
0000762f89be099c  vmovaps xmm8, [rsp+0x80]
0000762f89be09a5  vmovaps xmm9, [rsp+0x90]
0000762f89be09ae  vmovaps xmm10, [rsp+0xA0]
0000762f89be09b7  vmovaps xmm11, [rsp+0xB0]
0000762f89be09c0  vmovaps xmm12, [rsp+0xC0]
0000762f89be09c9  vmovaps xmm13, [rsp+0xD0]
0000762f89be09d2  vmovaps xmm14, [rsp+0xE0]
0000762f89be09db  add rsp, 0xF0
0000762f89be09e2  pop r11
0000762f89be09e4  pop r10
0000762f89be09e6  pop r9
0000762f89be09e8  pop r8
0000762f89be09ea  pop rsi
0000762f89be09eb  pop rdi
0000762f89be09ec  pop rdx
0000762f89be09ed  pop rcx
0000762f89be09ee  pop rax
0000762f89be09ef  add rsp, 0x08
0000762f89be09f3  jmp 0x0000762F89BDC658
0000762f89be09f8  sub rsp, 0x08
0000762f89be09fc  push rax
0000762f89be09fd  push rcx
0000762f89be09fe  push rdx
0000762f89be09ff  push rdi
0000762f89be0a00  push rsi
0000762f89be0a01  push r8
0000762f89be0a03  push r9
0000762f89be0a05  push r10
0000762f89be0a07  push r11
0000762f89be0a09  sub rsp, 0xF0
0000762f89be0a10  vmovaps [rsp], xmm0
0000762f89be0a15  vmovaps [rsp+0x10], xmm1
0000762f89be0a1b  vmovaps [rsp+0x20], xmm2
0000762f89be0a21  vmovaps [rsp+0x30], xmm3
0000762f89be0a27  vmovaps [rsp+0x40], xmm4
0000762f89be0a2d  vmovaps [rsp+0x50], xmm5
0000762f89be0a33  vmovaps [rsp+0x60], xmm6
0000762f89be0a39  vmovaps [rsp+0x70], xmm8
0000762f89be0a3f  vmovaps [rsp+0x80], xmm9
0000762f89be0a48  vmovaps [rsp+0x90], xmm10
0000762f89be0a51  vmovaps [rsp+0xA0], xmm11
0000762f89be0a5a  vmovaps [rsp+0xB0], xmm12
0000762f89be0a63  vmovaps [rsp+0xC0], xmm13
0000762f89be0a6c  vmovaps [rsp+0xD0], xmm14
0000762f89be0a75  vmovaps [rsp+0xE0], xmm15
0000762f89be0a7e  sub rsp, 0x30
0000762f89be0a82  movaps [rsp], xmm7
0000762f89be0a86  movaps [rsp+0x10], xmm11
0000762f89be0a8c  movaps [rsp+0x20], xmm9
0000762f89be0a92  lea rdi, [rsp]
0000762f89be0a96  mov esi, 0x00
0000762f89be0a9b  mov rax, 0x604D6F946530
0000762f89be0aa5  call rax
0000762f89be0aa7  movaps xmm7, [rsp]
0000762f89be0aab  add rsp, 0x30
0000762f89be0aaf  vmovaps xmm0, [rsp]
0000762f89be0ab4  vmovaps xmm1, [rsp+0x10]
0000762f89be0aba  vmovaps xmm2, [rsp+0x20]
0000762f89be0ac0  vmovaps xmm3, [rsp+0x30]
0000762f89be0ac6  vmovaps xmm4, [rsp+0x40]
0000762f89be0acc  vmovaps xmm5, [rsp+0x50]
0000762f89be0ad2  vmovaps xmm6, [rsp+0x60]
0000762f89be0ad8  vmovaps xmm8, [rsp+0x70]
0000762f89be0ade  vmovaps xmm9, [rsp+0x80]
0000762f89be0ae7  vmovaps xmm10, [rsp+0x90]
0000762f89be0af0  vmovaps xmm11, [rsp+0xA0]
0000762f89be0af9  vmovaps xmm12, [rsp+0xB0]
0000762f89be0b02  vmovaps xmm13, [rsp+0xC0]
0000762f89be0b0b  vmovaps xmm14, [rsp+0xD0]
0000762f89be0b14  vmovaps xmm15, [rsp+0xE0]
0000762f89be0b1d  add rsp, 0xF0
0000762f89be0b24  pop r11
0000762f89be0b26  pop r10
0000762f89be0b28  pop r9
0000762f89be0b2a  pop r8
0000762f89be0b2c  pop rsi
0000762f89be0b2d  pop rdi
0000762f89be0b2e  pop rdx
0000762f89be0b2f  pop rcx
0000762f89be0b30  pop rax
0000762f89be0b31  add rsp, 0x08
0000762f89be0b35  jmp 0x0000762F89BDC685
0000762f89be0b3a  sub rsp, 0x08
0000762f89be0b3e  push rax
0000762f89be0b3f  push rcx
0000762f89be0b40  push rdx
0000762f89be0b41  push rdi
0000762f89be0b42  push rsi
0000762f89be0b43  push r8
0000762f89be0b45  push r9
0000762f89be0b47  push r10
0000762f89be0b49  push r11
0000762f89be0b4b  sub rsp, 0xF0
0000762f89be0b52  vmovaps [rsp], xmm0
0000762f89be0b57  vmovaps [rsp+0x10], xmm1
0000762f89be0b5d  vmovaps [rsp+0x20], xmm2
0000762f89be0b63  vmovaps [rsp+0x30], xmm3
0000762f89be0b69  vmovaps [rsp+0x40], xmm4
0000762f89be0b6f  vmovaps [rsp+0x50], xmm5
0000762f89be0b75  vmovaps [rsp+0x60], xmm6
0000762f89be0b7b  vmovaps [rsp+0x70], xmm7
0000762f89be0b81  vmovaps [rsp+0x80], xmm8
0000762f89be0b8a  vmovaps [rsp+0x90], xmm9
0000762f89be0b93  vmovaps [rsp+0xA0], xmm10
0000762f89be0b9c  vmovaps [rsp+0xB0], xmm12
0000762f89be0ba5  vmovaps [rsp+0xC0], xmm13
0000762f89be0bae  vmovaps [rsp+0xD0], xmm14
0000762f89be0bb7  vmovaps [rsp+0xE0], xmm15
0000762f89be0bc0  sub rsp, 0x30
0000762f89be0bc4  movaps [rsp], xmm11
0000762f89be0bc9  movaps [rsp+0x10], xmm10
0000762f89be0bcf  movaps [rsp+0x20], xmm14
0000762f89be0bd5  lea rdi, [rsp]
0000762f89be0bd9  mov esi, 0x00
0000762f89be0bde  mov rax, 0x604D6F946530
0000762f89be0be8  call rax
0000762f89be0bea  movaps xmm11, [rsp]
0000762f89be0bef  add rsp, 0x30
0000762f89be0bf3  vmovaps xmm0, [rsp]
0000762f89be0bf8  vmovaps xmm1, [rsp+0x10]
0000762f89be0bfe  vmovaps xmm2, [rsp+0x20]
0000762f89be0c04  vmovaps xmm3, [rsp+0x30]
0000762f89be0c0a  vmovaps xmm4, [rsp+0x40]
0000762f89be0c10  vmovaps xmm5, [rsp+0x50]
0000762f89be0c16  vmovaps xmm6, [rsp+0x60]
0000762f89be0c1c  vmovaps xmm7, [rsp+0x70]
0000762f89be0c22  vmovaps xmm8, [rsp+0x80]
0000762f89be0c2b  vmovaps xmm9, [rsp+0x90]
0000762f89be0c34  vmovaps xmm10, [rsp+0xA0]
0000762f89be0c3d  vmovaps xmm12, [rsp+0xB0]
0000762f89be0c46  vmovaps xmm13, [rsp+0xC0]
0000762f89be0c4f  vmovaps xmm14, [rsp+0xD0]
0000762f89be0c58  vmovaps xmm15, [rsp+0xE0]
0000762f89be0c61  add rsp, 0xF0
0000762f89be0c68  pop r11
0000762f89be0c6a  pop r10
0000762f89be0c6c  pop r9
0000762f89be0c6e  pop r8
0000762f89be0c70  pop rsi
0000762f89be0c71  pop rdi
0000762f89be0c72  pop rdx
0000762f89be0c73  pop rcx
0000762f89be0c74  pop rax
0000762f89be0c75  add rsp, 0x08
0000762f89be0c79  jmp 0x0000762F89BDC6A0
0000762f89be0c7e  call 0x0000762F89AC33A0
0000762f89be0c83  jmp 0x0000762F89BDC6AA
0000762f89be0c88  sub rsp, 0x08
0000762f89be0c8c  push rax
0000762f89be0c8d  push rcx
0000762f89be0c8e  push rdx
0000762f89be0c8f  push rdi
0000762f89be0c90  push rsi
0000762f89be0c91  push r8
0000762f89be0c93  push r9
0000762f89be0c95  push r10
0000762f89be0c97  push r11
0000762f89be0c99  sub rsp, 0xF0
0000762f89be0ca0  vmovaps [rsp], xmm0
0000762f89be0ca5  vmovaps [rsp+0x10], xmm1
0000762f89be0cab  vmovaps [rsp+0x20], xmm2
0000762f89be0cb1  vmovaps [rsp+0x30], xmm3
0000762f89be0cb7  vmovaps [rsp+0x40], xmm4
0000762f89be0cbd  vmovaps [rsp+0x50], xmm5
0000762f89be0cc3  vmovaps [rsp+0x60], xmm6
0000762f89be0cc9  vmovaps [rsp+0x70], xmm7
0000762f89be0ccf  vmovaps [rsp+0x80], xmm8
0000762f89be0cd8  vmovaps [rsp+0x90], xmm9
0000762f89be0ce1  vmovaps [rsp+0xA0], xmm11
0000762f89be0cea  vmovaps [rsp+0xB0], xmm12
0000762f89be0cf3  vmovaps [rsp+0xC0], xmm13
0000762f89be0cfc  vmovaps [rsp+0xD0], xmm14
0000762f89be0d05  vmovaps [rsp+0xE0], xmm15
0000762f89be0d0e  sub rsp, 0x30
0000762f89be0d12  movaps [rsp], xmm10
0000762f89be0d17  movaps [rsp+0x10], xmm1
0000762f89be0d1c  movaps [rsp+0x20], xmm12
0000762f89be0d22  lea rdi, [rsp]
0000762f89be0d26  mov esi, 0x00
0000762f89be0d2b  mov rax, 0x604D6F946530
0000762f89be0d35  call rax
0000762f89be0d37  movaps xmm10, [rsp]
0000762f89be0d3c  add rsp, 0x30
0000762f89be0d40  vmovaps xmm0, [rsp]
0000762f89be0d45  vmovaps xmm1, [rsp+0x10]
0000762f89be0d4b  vmovaps xmm2, [rsp+0x20]
0000762f89be0d51  vmovaps xmm3, [rsp+0x30]
0000762f89be0d57  vmovaps xmm4, [rsp+0x40]
0000762f89be0d5d  vmovaps xmm5, [rsp+0x50]
0000762f89be0d63  vmovaps xmm6, [rsp+0x60]
0000762f89be0d69  vmovaps xmm7, [rsp+0x70]
0000762f89be0d6f  vmovaps xmm8, [rsp+0x80]
0000762f89be0d78  vmovaps xmm9, [rsp+0x90]
0000762f89be0d81  vmovaps xmm11, [rsp+0xA0]
0000762f89be0d8a  vmovaps xmm12, [rsp+0xB0]
0000762f89be0d93  vmovaps xmm13, [rsp+0xC0]
0000762f89be0d9c  vmovaps xmm14, [rsp+0xD0]
0000762f89be0da5  vmovaps xmm15, [rsp+0xE0]
0000762f89be0dae  add rsp, 0xF0
0000762f89be0db5  pop r11
0000762f89be0db7  pop r10
0000762f89be0db9  pop r9
0000762f89be0dbb  pop r8
0000762f89be0dbd  pop rsi
0000762f89be0dbe  pop rdi
0000762f89be0dbf  pop rdx
0000762f89be0dc0  pop rcx
0000762f89be0dc1  pop rax
0000762f89be0dc2  add rsp, 0x08
0000762f89be0dc6  jmp 0x0000762F89BDC6CD
0000762f89be0dcb  sub rsp, 0x08
0000762f89be0dcf  push rax
0000762f89be0dd0  push rcx
0000762f89be0dd1  push rdx
0000762f89be0dd2  push rdi
0000762f89be0dd3  push rsi
0000762f89be0dd4  push r8
0000762f89be0dd6  push r9
0000762f89be0dd8  push r10
0000762f89be0dda  push r11
0000762f89be0ddc  sub rsp, 0xF0
0000762f89be0de3  vmovaps [rsp], xmm0
0000762f89be0de8  vmovaps [rsp+0x10], xmm1
0000762f89be0dee  vmovaps [rsp+0x20], xmm2
0000762f89be0df4  vmovaps [rsp+0x30], xmm3
0000762f89be0dfa  vmovaps [rsp+0x40], xmm4
0000762f89be0e00  vmovaps [rsp+0x50], xmm5
0000762f89be0e06  vmovaps [rsp+0x60], xmm6
0000762f89be0e0c  vmovaps [rsp+0x70], xmm7
0000762f89be0e12  vmovaps [rsp+0x80], xmm8
0000762f89be0e1b  vmovaps [rsp+0x90], xmm9
0000762f89be0e24  vmovaps [rsp+0xA0], xmm10
0000762f89be0e2d  vmovaps [rsp+0xB0], xmm11
0000762f89be0e36  vmovaps [rsp+0xC0], xmm13
0000762f89be0e3f  vmovaps [rsp+0xD0], xmm14
0000762f89be0e48  vmovaps [rsp+0xE0], xmm15
0000762f89be0e51  sub rsp, 0x30
0000762f89be0e55  movaps [rsp], xmm12
0000762f89be0e5a  movaps [rsp+0x10], xmm14
0000762f89be0e60  movaps [rsp+0x20], xmm1
0000762f89be0e65  lea rdi, [rsp]
0000762f89be0e69  mov esi, 0x00
0000762f89be0e6e  mov rax, 0x604D6F946530
0000762f89be0e78  call rax
0000762f89be0e7a  movaps xmm12, [rsp]
0000762f89be0e7f  add rsp, 0x30
0000762f89be0e83  vmovaps xmm0, [rsp]
0000762f89be0e88  vmovaps xmm1, [rsp+0x10]
0000762f89be0e8e  vmovaps xmm2, [rsp+0x20]
0000762f89be0e94  vmovaps xmm3, [rsp+0x30]
0000762f89be0e9a  vmovaps xmm4, [rsp+0x40]
0000762f89be0ea0  vmovaps xmm5, [rsp+0x50]
0000762f89be0ea6  vmovaps xmm6, [rsp+0x60]
0000762f89be0eac  vmovaps xmm7, [rsp+0x70]
0000762f89be0eb2  vmovaps xmm8, [rsp+0x80]
0000762f89be0ebb  vmovaps xmm9, [rsp+0x90]
0000762f89be0ec4  vmovaps xmm10, [rsp+0xA0]
0000762f89be0ecd  vmovaps xmm11, [rsp+0xB0]
0000762f89be0ed6  vmovaps xmm13, [rsp+0xC0]
0000762f89be0edf  vmovaps xmm14, [rsp+0xD0]
0000762f89be0ee8  vmovaps xmm15, [rsp+0xE0]
0000762f89be0ef1  add rsp, 0xF0
0000762f89be0ef8  pop r11
0000762f89be0efa  pop r10
0000762f89be0efc  pop r9
0000762f89be0efe  pop r8
0000762f89be0f00  pop rsi
0000762f89be0f01  pop rdi
0000762f89be0f02  pop rdx
0000762f89be0f03  pop rcx
0000762f89be0f04  pop rax
0000762f89be0f05  add rsp, 0x08
0000762f89be0f09  jmp 0x0000762F89BDC6FC
0000762f89be0f0e  sub rsp, 0x08
0000762f89be0f12  push rax
0000762f89be0f13  push rcx
0000762f89be0f14  push rdx
0000762f89be0f15  push rdi
0000762f89be0f16  push rsi
0000762f89be0f17  push r8
0000762f89be0f19  push r9
0000762f89be0f1b  push r10
0000762f89be0f1d  push r11
0000762f89be0f1f  sub rsp, 0xF0
0000762f89be0f26  vmovaps [rsp], xmm0
0000762f89be0f2b  vmovaps [rsp+0x10], xmm1
0000762f89be0f31  vmovaps [rsp+0x20], xmm2
0000762f89be0f37  vmovaps [rsp+0x30], xmm3
0000762f89be0f3d  vmovaps [rsp+0x40], xmm4
0000762f89be0f43  vmovaps [rsp+0x50], xmm5
0000762f89be0f49  vmovaps [rsp+0x60], xmm6
0000762f89be0f4f  vmovaps [rsp+0x70], xmm7
0000762f89be0f55  vmovaps [rsp+0x80], xmm8
0000762f89be0f5e  vmovaps [rsp+0x90], xmm9
0000762f89be0f67  vmovaps [rsp+0xA0], xmm10
0000762f89be0f70  vmovaps [rsp+0xB0], xmm11
0000762f89be0f79  vmovaps [rsp+0xC0], xmm12
0000762f89be0f82  vmovaps [rsp+0xD0], xmm13
0000762f89be0f8b  vmovaps [rsp+0xE0], xmm15
0000762f89be0f94  sub rsp, 0x30
0000762f89be0f98  movaps [rsp], xmm14
0000762f89be0f9d  movaps [rsp+0x10], xmm9
0000762f89be0fa3  movaps [rsp+0x20], xmm1
0000762f89be0fa8  lea rdi, [rsp]
0000762f89be0fac  mov esi, 0x00
0000762f89be0fb1  mov rax, 0x604D6F946530
0000762f89be0fbb  call rax
0000762f89be0fbd  movaps xmm14, [rsp]
0000762f89be0fc2  add rsp, 0x30
0000762f89be0fc6  vmovaps xmm0, [rsp]
0000762f89be0fcb  vmovaps xmm1, [rsp+0x10]
0000762f89be0fd1  vmovaps xmm2, [rsp+0x20]
0000762f89be0fd7  vmovaps xmm3, [rsp+0x30]
0000762f89be0fdd  vmovaps xmm4, [rsp+0x40]
0000762f89be0fe3  vmovaps xmm5, [rsp+0x50]
0000762f89be0fe9  vmovaps xmm6, [rsp+0x60]
0000762f89be0fef  vmovaps xmm7, [rsp+0x70]
0000762f89be0ff5  vmovaps xmm8, [rsp+0x80]
0000762f89be0ffe  vmovaps xmm9, [rsp+0x90]
0000762f89be1007  vmovaps xmm10, [rsp+0xA0]
0000762f89be1010  vmovaps xmm11, [rsp+0xB0]
0000762f89be1019  vmovaps xmm12, [rsp+0xC0]
0000762f89be1022  vmovaps xmm13, [rsp+0xD0]
0000762f89be102b  vmovaps xmm15, [rsp+0xE0]
0000762f89be1034  add rsp, 0xF0
0000762f89be103b  pop r11
0000762f89be103d  pop r10
0000762f89be103f  pop r9
0000762f89be1041  pop r8
0000762f89be1043  pop rsi
0000762f89be1044  pop rdi
0000762f89be1045  pop rdx
0000762f89be1046  pop rcx
0000762f89be1047  pop rax
0000762f89be1048  add rsp, 0x08
0000762f89be104c  jmp 0x0000762F89BDC72B
0000762f89be1051  sub rsp, 0x08
0000762f89be1055  push rax
0000762f89be1056  push rcx
0000762f89be1057  push rdx
0000762f89be1058  push rdi
0000762f89be1059  push rsi
0000762f89be105a  push r8
0000762f89be105c  push r9
0000762f89be105e  push r10
0000762f89be1060  push r11
0000762f89be1062  sub rsp, 0xF0
0000762f89be1069  vmovaps [rsp], xmm0
0000762f89be106e  vmovaps [rsp+0x10], xmm2
0000762f89be1074  vmovaps [rsp+0x20], xmm3
0000762f89be107a  vmovaps [rsp+0x30], xmm4
0000762f89be1080  vmovaps [rsp+0x40], xmm5
0000762f89be1086  vmovaps [rsp+0x50], xmm6
0000762f89be108c  vmovaps [rsp+0x60], xmm7
0000762f89be1092  vmovaps [rsp+0x70], xmm8
0000762f89be1098  vmovaps [rsp+0x80], xmm9
0000762f89be10a1  vmovaps [rsp+0x90], xmm10
0000762f89be10aa  vmovaps [rsp+0xA0], xmm11
0000762f89be10b3  vmovaps [rsp+0xB0], xmm12
0000762f89be10bc  vmovaps [rsp+0xC0], xmm13
0000762f89be10c5  vmovaps [rsp+0xD0], xmm14
0000762f89be10ce  vmovaps [rsp+0xE0], xmm15
0000762f89be10d7  sub rsp, 0x30
0000762f89be10db  movaps [rsp], xmm1
0000762f89be10df  movaps [rsp+0x10], xmm13
0000762f89be10e5  movaps [rsp+0x20], xmm8
0000762f89be10eb  lea rdi, [rsp]
0000762f89be10ef  mov esi, 0x00
0000762f89be10f4  mov rax, 0x604D6F946530
0000762f89be10fe  call rax
0000762f89be1100  movaps xmm1, [rsp]
0000762f89be1104  add rsp, 0x30
0000762f89be1108  vmovaps xmm0, [rsp]
0000762f89be110d  vmovaps xmm2, [rsp+0x10]
0000762f89be1113  vmovaps xmm3, [rsp+0x20]
0000762f89be1119  vmovaps xmm4, [rsp+0x30]
0000762f89be111f  vmovaps xmm5, [rsp+0x40]
0000762f89be1125  vmovaps xmm6, [rsp+0x50]
0000762f89be112b  vmovaps xmm7, [rsp+0x60]
0000762f89be1131  vmovaps xmm8, [rsp+0x70]
0000762f89be1137  vmovaps xmm9, [rsp+0x80]
0000762f89be1140  vmovaps xmm10, [rsp+0x90]
0000762f89be1149  vmovaps xmm11, [rsp+0xA0]
0000762f89be1152  vmovaps xmm12, [rsp+0xB0]
0000762f89be115b  vmovaps xmm13, [rsp+0xC0]
0000762f89be1164  vmovaps xmm14, [rsp+0xD0]
0000762f89be116d  vmovaps xmm15, [rsp+0xE0]
0000762f89be1176  add rsp, 0xF0
0000762f89be117d  pop r11
0000762f89be117f  pop r10
0000762f89be1181  pop r9
0000762f89be1183  pop r8
0000762f89be1185  pop rsi
0000762f89be1186  pop rdi
0000762f89be1187  pop rdx
0000762f89be1188  pop rcx
0000762f89be1189  pop rax
0000762f89be118a  add rsp, 0x08
0000762f89be118e  jmp 0x0000762F89BDC74D
0000762f89be1193  call 0x0000762F89A0C260
0000762f89be1198  jmp 0x0000762F89BDC75B
0000762f89be119d  call 0x0000762F89ABD750
0000762f89be11a2  jmp 0x0000762F89BDC765
0000762f89be11a7  sub rsp, 0x08
0000762f89be11ab  push rax
0000762f89be11ac  push rcx
0000762f89be11ad  push rdx
0000762f89be11ae  push rdi
0000762f89be11af  push rsi
0000762f89be11b0  push r8
0000762f89be11b2  push r9
0000762f89be11b4  push r10
0000762f89be11b6  push r11
0000762f89be11b8  sub rsp, 0xF0
0000762f89be11bf  vmovaps [rsp], xmm0
0000762f89be11c4  vmovaps [rsp+0x10], xmm1
0000762f89be11ca  vmovaps [rsp+0x20], xmm2
0000762f89be11d0  vmovaps [rsp+0x30], xmm3
0000762f89be11d6  vmovaps [rsp+0x40], xmm4
0000762f89be11dc  vmovaps [rsp+0x50], xmm5
0000762f89be11e2  vmovaps [rsp+0x60], xmm6
0000762f89be11e8  vmovaps [rsp+0x70], xmm7
0000762f89be11ee  vmovaps [rsp+0x80], xmm9
0000762f89be11f7  vmovaps [rsp+0x90], xmm10
0000762f89be1200  vmovaps [rsp+0xA0], xmm11
0000762f89be1209  vmovaps [rsp+0xB0], xmm12
0000762f89be1212  vmovaps [rsp+0xC0], xmm13
0000762f89be121b  vmovaps [rsp+0xD0], xmm14
0000762f89be1224  vmovaps [rsp+0xE0], xmm15
0000762f89be122d  sub rsp, 0x30
0000762f89be1231  movaps [rsp], xmm8
0000762f89be1236  movaps [rsp+0x10], xmm15
0000762f89be123c  movaps [rsp+0x20], xmm7
0000762f89be1241  lea rdi, [rsp]
0000762f89be1245  mov esi, 0x00
0000762f89be124a  mov rax, 0x604D6F946530
0000762f89be1254  call rax
0000762f89be1256  movaps xmm8, [rsp]
0000762f89be125b  add rsp, 0x30
0000762f89be125f  vmovaps xmm0, [rsp]
0000762f89be1264  vmovaps xmm1, [rsp+0x10]
0000762f89be126a  vmovaps xmm2, [rsp+0x20]
0000762f89be1270  vmovaps xmm3, [rsp+0x30]
0000762f89be1276  vmovaps xmm4, [rsp+0x40]
0000762f89be127c  vmovaps xmm5, [rsp+0x50]
0000762f89be1282  vmovaps xmm6, [rsp+0x60]
0000762f89be1288  vmovaps xmm7, [rsp+0x70]
0000762f89be128e  vmovaps xmm9, [rsp+0x80]
0000762f89be1297  vmovaps xmm10, [rsp+0x90]
0000762f89be12a0  vmovaps xmm11, [rsp+0xA0]
0000762f89be12a9  vmovaps xmm12, [rsp+0xB0]
0000762f89be12b2  vmovaps xmm13, [rsp+0xC0]
0000762f89be12bb  vmovaps xmm14, [rsp+0xD0]
0000762f89be12c4  vmovaps xmm15, [rsp+0xE0]
0000762f89be12cd  add rsp, 0xF0
0000762f89be12d4  pop r11
0000762f89be12d6  pop r10
0000762f89be12d8  pop r9
0000762f89be12da  pop r8
0000762f89be12dc  pop rsi
0000762f89be12dd  pop rdi
0000762f89be12de  pop rdx
0000762f89be12df  pop rcx
0000762f89be12e0  pop rax
0000762f89be12e1  add rsp, 0x08
0000762f89be12e5  jmp 0x0000762F89BDC787
0000762f89be12ea  sub rsp, 0x08
0000762f89be12ee  push rax
0000762f89be12ef  push rcx
0000762f89be12f0  push rdx
0000762f89be12f1  push rdi
0000762f89be12f2  push rsi
0000762f89be12f3  push r8
0000762f89be12f5  push r9
0000762f89be12f7  push r10
0000762f89be12f9  push r11
0000762f89be12fb  sub rsp, 0xF0
0000762f89be1302  vmovaps [rsp], xmm0
0000762f89be1307  vmovaps [rsp+0x10], xmm1
0000762f89be130d  vmovaps [rsp+0x20], xmm2
0000762f89be1313  vmovaps [rsp+0x30], xmm3
0000762f89be1319  vmovaps [rsp+0x40], xmm4
0000762f89be131f  vmovaps [rsp+0x50], xmm5
0000762f89be1325  vmovaps [rsp+0x60], xmm6
0000762f89be132b  vmovaps [rsp+0x70], xmm8
0000762f89be1331  vmovaps [rsp+0x80], xmm9
0000762f89be133a  vmovaps [rsp+0x90], xmm10
0000762f89be1343  vmovaps [rsp+0xA0], xmm11
0000762f89be134c  vmovaps [rsp+0xB0], xmm12
0000762f89be1355  vmovaps [rsp+0xC0], xmm13
0000762f89be135e  vmovaps [rsp+0xD0], xmm14
0000762f89be1367  vmovaps [rsp+0xE0], xmm15
0000762f89be1370  sub rsp, 0x30
0000762f89be1374  movaps [rsp], xmm7
0000762f89be1378  movaps [rsp+0x10], xmm9
0000762f89be137e  movaps [rsp+0x20], xmm15
0000762f89be1384  lea rdi, [rsp]
0000762f89be1388  mov esi, 0x00
0000762f89be138d  mov rax, 0x604D6F946530
0000762f89be1397  call rax
0000762f89be1399  movaps xmm7, [rsp]
0000762f89be139d  add rsp, 0x30
0000762f89be13a1  vmovaps xmm0, [rsp]
0000762f89be13a6  vmovaps xmm1, [rsp+0x10]
0000762f89be13ac  vmovaps xmm2, [rsp+0x20]
0000762f89be13b2  vmovaps xmm3, [rsp+0x30]
0000762f89be13b8  vmovaps xmm4, [rsp+0x40]
0000762f89be13be  vmovaps xmm5, [rsp+0x50]
0000762f89be13c4  vmovaps xmm6, [rsp+0x60]
0000762f89be13ca  vmovaps xmm8, [rsp+0x70]
0000762f89be13d0  vmovaps xmm9, [rsp+0x80]
0000762f89be13d9  vmovaps xmm10, [rsp+0x90]
0000762f89be13e2  vmovaps xmm11, [rsp+0xA0]
0000762f89be13eb  vmovaps xmm12, [rsp+0xB0]
0000762f89be13f4  vmovaps xmm13, [rsp+0xC0]
0000762f89be13fd  vmovaps xmm14, [rsp+0xD0]
0000762f89be1406  vmovaps xmm15, [rsp+0xE0]
0000762f89be140f  add rsp, 0xF0
0000762f89be1416  pop r11
0000762f89be1418  pop r10
0000762f89be141a  pop r9
0000762f89be141c  pop r8
0000762f89be141e  pop rsi
0000762f89be141f  pop rdi
0000762f89be1420  pop rdx
0000762f89be1421  pop rcx
0000762f89be1422  pop rax
0000762f89be1423  add rsp, 0x08
0000762f89be1427  jmp 0x0000762F89BDC7B4
0000762f89be142c  sub rsp, 0x08
0000762f89be1430  push rax
0000762f89be1431  push rcx
0000762f89be1432  push rdx
0000762f89be1433  push rdi
0000762f89be1434  push rsi
0000762f89be1435  push r8
0000762f89be1437  push r9
0000762f89be1439  push r10
0000762f89be143b  push r11
0000762f89be143d  sub rsp, 0xF0
0000762f89be1444  vmovaps [rsp], xmm0
0000762f89be1449  vmovaps [rsp+0x10], xmm1
0000762f89be144f  vmovaps [rsp+0x20], xmm2
0000762f89be1455  vmovaps [rsp+0x30], xmm3
0000762f89be145b  vmovaps [rsp+0x40], xmm4
0000762f89be1461  vmovaps [rsp+0x50], xmm5
0000762f89be1467  vmovaps [rsp+0x60], xmm6
0000762f89be146d  vmovaps [rsp+0x70], xmm7
0000762f89be1473  vmovaps [rsp+0x80], xmm8
0000762f89be147c  vmovaps [rsp+0x90], xmm10
0000762f89be1485  vmovaps [rsp+0xA0], xmm11
0000762f89be148e  vmovaps [rsp+0xB0], xmm12
0000762f89be1497  vmovaps [rsp+0xC0], xmm13
0000762f89be14a0  vmovaps [rsp+0xD0], xmm14
0000762f89be14a9  vmovaps [rsp+0xE0], xmm15
0000762f89be14b2  sub rsp, 0x30
0000762f89be14b6  movaps [rsp], xmm9
0000762f89be14bb  movaps [rsp+0x10], xmm13
0000762f89be14c1  movaps [rsp+0x20], xmm15
0000762f89be14c7  lea rdi, [rsp]
0000762f89be14cb  mov esi, 0x00
0000762f89be14d0  mov rax, 0x604D6F946530
0000762f89be14da  call rax
0000762f89be14dc  movaps xmm9, [rsp]
0000762f89be14e1  add rsp, 0x30
0000762f89be14e5  vmovaps xmm0, [rsp]
0000762f89be14ea  vmovaps xmm1, [rsp+0x10]
0000762f89be14f0  vmovaps xmm2, [rsp+0x20]
0000762f89be14f6  vmovaps xmm3, [rsp+0x30]
0000762f89be14fc  vmovaps xmm4, [rsp+0x40]
0000762f89be1502  vmovaps xmm5, [rsp+0x50]
0000762f89be1508  vmovaps xmm6, [rsp+0x60]
0000762f89be150e  vmovaps xmm7, [rsp+0x70]
0000762f89be1514  vmovaps xmm8, [rsp+0x80]
0000762f89be151d  vmovaps xmm10, [rsp+0x90]
0000762f89be1526  vmovaps xmm11, [rsp+0xA0]
0000762f89be152f  vmovaps xmm12, [rsp+0xB0]
0000762f89be1538  vmovaps xmm13, [rsp+0xC0]
0000762f89be1541  vmovaps xmm14, [rsp+0xD0]
0000762f89be154a  vmovaps xmm15, [rsp+0xE0]
0000762f89be1553  add rsp, 0xF0
0000762f89be155a  pop r11
0000762f89be155c  pop r10
0000762f89be155e  pop r9
0000762f89be1560  pop r8
0000762f89be1562  pop rsi
0000762f89be1563  pop rdi
0000762f89be1564  pop rdx
0000762f89be1565  pop rcx
0000762f89be1566  pop rax
0000762f89be1567  add rsp, 0x08
0000762f89be156b  jmp 0x0000762F89BDC7E2
0000762f89be1570  sub rsp, 0x08
0000762f89be1574  push rax
0000762f89be1575  push rcx
0000762f89be1576  push rdx
0000762f89be1577  push rdi
0000762f89be1578  push rsi
0000762f89be1579  push r8
0000762f89be157b  push r9
0000762f89be157d  push r10
0000762f89be157f  push r11
0000762f89be1581  sub rsp, 0xF0
0000762f89be1588  vmovaps [rsp], xmm0
0000762f89be158d  vmovaps [rsp+0x10], xmm1
0000762f89be1593  vmovaps [rsp+0x20], xmm2
0000762f89be1599  vmovaps [rsp+0x30], xmm3
0000762f89be159f  vmovaps [rsp+0x40], xmm4
0000762f89be15a5  vmovaps [rsp+0x50], xmm5
0000762f89be15ab  vmovaps [rsp+0x60], xmm6
0000762f89be15b1  vmovaps [rsp+0x70], xmm7
0000762f89be15b7  vmovaps [rsp+0x80], xmm8
0000762f89be15c0  vmovaps [rsp+0x90], xmm9
0000762f89be15c9  vmovaps [rsp+0xA0], xmm10
0000762f89be15d2  vmovaps [rsp+0xB0], xmm11
0000762f89be15db  vmovaps [rsp+0xC0], xmm12
0000762f89be15e4  vmovaps [rsp+0xD0], xmm13
0000762f89be15ed  vmovaps [rsp+0xE0], xmm14
0000762f89be15f6  sub rsp, 0x30
0000762f89be15fa  movaps [rsp], xmm15
0000762f89be15ff  movaps [rsp+0x10], xmm11
0000762f89be1605  movaps [rsp+0x20], xmm12
0000762f89be160b  lea rdi, [rsp]
0000762f89be160f  mov esi, 0x00
0000762f89be1614  mov rax, 0x604D6F946530
0000762f89be161e  call rax
0000762f89be1620  movaps xmm15, [rsp]
0000762f89be1625  add rsp, 0x30
0000762f89be1629  vmovaps xmm0, [rsp]
0000762f89be162e  vmovaps xmm1, [rsp+0x10]
0000762f89be1634  vmovaps xmm2, [rsp+0x20]
0000762f89be163a  vmovaps xmm3, [rsp+0x30]
0000762f89be1640  vmovaps xmm4, [rsp+0x40]
0000762f89be1646  vmovaps xmm5, [rsp+0x50]
0000762f89be164c  vmovaps xmm6, [rsp+0x60]
0000762f89be1652  vmovaps xmm7, [rsp+0x70]
0000762f89be1658  vmovaps xmm8, [rsp+0x80]
0000762f89be1661  vmovaps xmm9, [rsp+0x90]
0000762f89be166a  vmovaps xmm10, [rsp+0xA0]
0000762f89be1673  vmovaps xmm11, [rsp+0xB0]
0000762f89be167c  vmovaps xmm12, [rsp+0xC0]
0000762f89be1685  vmovaps xmm13, [rsp+0xD0]
0000762f89be168e  vmovaps xmm14, [rsp+0xE0]
0000762f89be1697  add rsp, 0xF0
0000762f89be169e  pop r11
0000762f89be16a0  pop r10
0000762f89be16a2  pop r9
0000762f89be16a4  pop r8
0000762f89be16a6  pop rsi
0000762f89be16a7  pop rdi
0000762f89be16a8  pop rdx
0000762f89be16a9  pop rcx
0000762f89be16aa  pop rax
0000762f89be16ab  add rsp, 0x08
0000762f89be16af  jmp 0x0000762F89BDC7FD
0000762f89be16b4  sub rsp, 0x08
0000762f89be16b8  push rax
0000762f89be16b9  push rcx
0000762f89be16ba  push rdx
0000762f89be16bb  push rdi
0000762f89be16bc  push rsi
0000762f89be16bd  push r8
0000762f89be16bf  push r9
0000762f89be16c1  push r10
0000762f89be16c3  push r11
0000762f89be16c5  sub rsp, 0xF0
0000762f89be16cc  vmovaps [rsp], xmm0
0000762f89be16d1  vmovaps [rsp+0x10], xmm1
0000762f89be16d7  vmovaps [rsp+0x20], xmm2
0000762f89be16dd  vmovaps [rsp+0x30], xmm3
0000762f89be16e3  vmovaps [rsp+0x40], xmm4
0000762f89be16e9  vmovaps [rsp+0x50], xmm5
0000762f89be16ef  vmovaps [rsp+0x60], xmm6
0000762f89be16f5  vmovaps [rsp+0x70], xmm7
0000762f89be16fb  vmovaps [rsp+0x80], xmm8
0000762f89be1704  vmovaps [rsp+0x90], xmm9
0000762f89be170d  vmovaps [rsp+0xA0], xmm10
0000762f89be1716  vmovaps [rsp+0xB0], xmm11
0000762f89be171f  vmovaps [rsp+0xC0], xmm12
0000762f89be1728  vmovaps [rsp+0xD0], xmm14
0000762f89be1731  vmovaps [rsp+0xE0], xmm15
0000762f89be173a  sub rsp, 0x30
0000762f89be173e  movaps [rsp], xmm13
0000762f89be1743  movaps [rsp+0x10], xmm10
0000762f89be1749  movaps [rsp+0x20], xmm14
0000762f89be174f  lea rdi, [rsp]
0000762f89be1753  mov esi, 0x00
0000762f89be1758  mov rax, 0x604D6F946530
0000762f89be1762  call rax
0000762f89be1764  movaps xmm13, [rsp]
0000762f89be1769  add rsp, 0x30
0000762f89be176d  vmovaps xmm0, [rsp]
0000762f89be1772  vmovaps xmm1, [rsp+0x10]
0000762f89be1778  vmovaps xmm2, [rsp+0x20]
0000762f89be177e  vmovaps xmm3, [rsp+0x30]
0000762f89be1784  vmovaps xmm4, [rsp+0x40]
0000762f89be178a  vmovaps xmm5, [rsp+0x50]
0000762f89be1790  vmovaps xmm6, [rsp+0x60]
0000762f89be1796  vmovaps xmm7, [rsp+0x70]
0000762f89be179c  vmovaps xmm8, [rsp+0x80]
0000762f89be17a5  vmovaps xmm9, [rsp+0x90]
0000762f89be17ae  vmovaps xmm10, [rsp+0xA0]
0000762f89be17b7  vmovaps xmm11, [rsp+0xB0]
0000762f89be17c0  vmovaps xmm12, [rsp+0xC0]
0000762f89be17c9  vmovaps xmm14, [rsp+0xD0]
0000762f89be17d2  vmovaps xmm15, [rsp+0xE0]
0000762f89be17db  add rsp, 0xF0
0000762f89be17e2  pop r11
0000762f89be17e4  pop r10
0000762f89be17e6  pop r9
0000762f89be17e8  pop r8
0000762f89be17ea  pop rsi
0000762f89be17eb  pop rdi
0000762f89be17ec  pop rdx
0000762f89be17ed  pop rcx
0000762f89be17ee  pop rax
0000762f89be17ef  add rsp, 0x08
0000762f89be17f3  jmp 0x0000762F89BDC820
0000762f89be17f8  sub rsp, 0x08
0000762f89be17fc  push rax
0000762f89be17fd  push rcx
0000762f89be17fe  push rdx
0000762f89be17ff  push rdi
0000762f89be1800  push rsi
0000762f89be1801  push r8
0000762f89be1803  push r9
0000762f89be1805  push r10
0000762f89be1807  push r11
0000762f89be1809  sub rsp, 0xF0
0000762f89be1810  vmovaps [rsp], xmm0
0000762f89be1815  vmovaps [rsp+0x10], xmm1
0000762f89be181b  vmovaps [rsp+0x20], xmm2
0000762f89be1821  vmovaps [rsp+0x30], xmm3
0000762f89be1827  vmovaps [rsp+0x40], xmm4
0000762f89be182d  vmovaps [rsp+0x50], xmm5
0000762f89be1833  vmovaps [rsp+0x60], xmm6
0000762f89be1839  vmovaps [rsp+0x70], xmm7
0000762f89be183f  vmovaps [rsp+0x80], xmm8
0000762f89be1848  vmovaps [rsp+0x90], xmm9
0000762f89be1851  vmovaps [rsp+0xA0], xmm10
0000762f89be185a  vmovaps [rsp+0xB0], xmm11
0000762f89be1863  vmovaps [rsp+0xC0], xmm12
0000762f89be186c  vmovaps [rsp+0xD0], xmm13
0000762f89be1875  vmovaps [rsp+0xE0], xmm15
0000762f89be187e  sub rsp, 0x30
0000762f89be1882  movaps [rsp], xmm14
0000762f89be1887  movaps [rsp+0x10], xmm1
0000762f89be188c  movaps [rsp+0x20], xmm7
0000762f89be1891  lea rdi, [rsp]
0000762f89be1895  mov esi, 0x00
0000762f89be189a  mov rax, 0x604D6F946530
0000762f89be18a4  call rax
0000762f89be18a6  movaps xmm14, [rsp]
0000762f89be18ab  add rsp, 0x30
0000762f89be18af  vmovaps xmm0, [rsp]
0000762f89be18b4  vmovaps xmm1, [rsp+0x10]
0000762f89be18ba  vmovaps xmm2, [rsp+0x20]
0000762f89be18c0  vmovaps xmm3, [rsp+0x30]
0000762f89be18c6  vmovaps xmm4, [rsp+0x40]
0000762f89be18cc  vmovaps xmm5, [rsp+0x50]
0000762f89be18d2  vmovaps xmm6, [rsp+0x60]
0000762f89be18d8  vmovaps xmm7, [rsp+0x70]
0000762f89be18de  vmovaps xmm8, [rsp+0x80]
0000762f89be18e7  vmovaps xmm9, [rsp+0x90]
0000762f89be18f0  vmovaps xmm10, [rsp+0xA0]
0000762f89be18f9  vmovaps xmm11, [rsp+0xB0]
0000762f89be1902  vmovaps xmm12, [rsp+0xC0]
0000762f89be190b  vmovaps xmm13, [rsp+0xD0]
0000762f89be1914  vmovaps xmm15, [rsp+0xE0]
0000762f89be191d  add rsp, 0xF0
0000762f89be1924  pop r11
0000762f89be1926  pop r10
0000762f89be1928  pop r9
0000762f89be192a  pop r8
0000762f89be192c  pop rsi
0000762f89be192d  pop rdi
0000762f89be192e  pop rdx
0000762f89be192f  pop rcx
0000762f89be1930  pop rax
0000762f89be1931  add rsp, 0x08
0000762f89be1935  jmp 0x0000762F89BDC843
0000762f89be193a  sub rsp, 0x08
0000762f89be193e  push rax
0000762f89be193f  push rcx
0000762f89be1940  push rdx
0000762f89be1941  push rdi
0000762f89be1942  push rsi
0000762f89be1943  push r8
0000762f89be1945  push r9
0000762f89be1947  push r10
0000762f89be1949  push r11
0000762f89be194b  sub rsp, 0xF0
0000762f89be1952  vmovaps [rsp], xmm0
0000762f89be1957  vmovaps [rsp+0x10], xmm2
0000762f89be195d  vmovaps [rsp+0x20], xmm3
0000762f89be1963  vmovaps [rsp+0x30], xmm4
0000762f89be1969  vmovaps [rsp+0x40], xmm5
0000762f89be196f  vmovaps [rsp+0x50], xmm6
0000762f89be1975  vmovaps [rsp+0x60], xmm7
0000762f89be197b  vmovaps [rsp+0x70], xmm8
0000762f89be1981  vmovaps [rsp+0x80], xmm9
0000762f89be198a  vmovaps [rsp+0x90], xmm10
0000762f89be1993  vmovaps [rsp+0xA0], xmm11
0000762f89be199c  vmovaps [rsp+0xB0], xmm12
0000762f89be19a5  vmovaps [rsp+0xC0], xmm13
0000762f89be19ae  vmovaps [rsp+0xD0], xmm14
0000762f89be19b7  vmovaps [rsp+0xE0], xmm15
0000762f89be19c0  sub rsp, 0x30
0000762f89be19c4  movaps [rsp], xmm1
0000762f89be19c8  movaps [rsp+0x10], xmm8
0000762f89be19ce  movaps [rsp+0x20], xmm9
0000762f89be19d4  lea rdi, [rsp]
0000762f89be19d8  mov esi, 0x00
0000762f89be19dd  mov rax, 0x604D6F946530
0000762f89be19e7  call rax
0000762f89be19e9  movaps xmm1, [rsp]
0000762f89be19ed  add rsp, 0x30
0000762f89be19f1  vmovaps xmm0, [rsp]
0000762f89be19f6  vmovaps xmm2, [rsp+0x10]
0000762f89be19fc  vmovaps xmm3, [rsp+0x20]
0000762f89be1a02  vmovaps xmm4, [rsp+0x30]
0000762f89be1a08  vmovaps xmm5, [rsp+0x40]
0000762f89be1a0e  vmovaps xmm6, [rsp+0x50]
0000762f89be1a14  vmovaps xmm7, [rsp+0x60]
0000762f89be1a1a  vmovaps xmm8, [rsp+0x70]
0000762f89be1a20  vmovaps xmm9, [rsp+0x80]
0000762f89be1a29  vmovaps xmm10, [rsp+0x90]
0000762f89be1a32  vmovaps xmm11, [rsp+0xA0]
0000762f89be1a3b  vmovaps xmm12, [rsp+0xB0]
0000762f89be1a44  vmovaps xmm13, [rsp+0xC0]
0000762f89be1a4d  vmovaps xmm14, [rsp+0xD0]
0000762f89be1a56  vmovaps xmm15, [rsp+0xE0]
0000762f89be1a5f  add rsp, 0xF0
0000762f89be1a66  pop r11
0000762f89be1a68  pop r10
0000762f89be1a6a  pop r9
0000762f89be1a6c  pop r8
0000762f89be1a6e  pop rsi
0000762f89be1a6f  pop rdi
0000762f89be1a70  pop rdx
0000762f89be1a71  pop rcx
0000762f89be1a72  pop rax
0000762f89be1a73  add rsp, 0x08
0000762f89be1a77  jmp 0x0000762F89BDC865
0000762f89be1a7c  call 0x0000762F89AE5940
0000762f89be1a81  jmp 0x0000762F89BDC873
0000762f89be1a86  call 0x0000762F89A0C380
0000762f89be1a8b  jmp 0x0000762F89BDC87D
0000762f89be1a90  call 0x0000762F89A0D600
0000762f89be1a95  jmp 0x0000762F89BDC887
0000762f89be1a9a  call 0x0000762F899FF540
0000762f89be1a9f  jmp 0x0000762F89BDC891
0000762f89be1aa4  int3
0000762f89be1aa5  nop [rax+rax*1], ax
0000762f89be1aae  nop
0000762f89be1ab0  mov rax, [r15+0xF8]
0000762f89be1ab7  lea r14, [rax+0x140]
0000762f89be1abe  mov r12, [r13+r14*1]
0000762f89be1ac3  mov [r15+0xE8], r12
0000762f89be1aca  lea r14, [rax+0x130]
0000762f89be1ad1  mov r12, [r13+r14*1]
0000762f89be1ad6  lea r14, [rax+0x138]
0000762f89be1add  mov r11, [r13+r14*1]
0000762f89be1ae2  movq xmm1, r12
0000762f89be1ae7  movq xmm15, r11
0000762f89be1aec  movq xmm1, xmm1
0000762f89be1af0  movq xmm1, xmm1
0000762f89be1af4  movaps [r15+0x1A0], xmm1
0000762f89be1afc  movq xmm15, xmm15
0000762f89be1b01  movq xmm15, xmm15
0000762f89be1b06  movaps [r15+0x190], xmm15
0000762f89be1b0e  lea r14, [rax+0x120]
0000762f89be1b15  mov r12, [r13+r14*1]
0000762f89be1b1a  lea r14, [rax+0x128]
0000762f89be1b21  mov r11, [r13+r14*1]
0000762f89be1b26  movq xmm1, r12
0000762f89be1b2b  movq xmm15, r11
0000762f89be1b30  movq xmm1, xmm1
0000762f89be1b34  movq xmm1, xmm1
0000762f89be1b38  movaps [r15+0x1C0], xmm1
0000762f89be1b40  movq xmm15, xmm15
0000762f89be1b45  movq xmm15, xmm15
0000762f89be1b4a  movaps [r15+0x1B0], xmm15
0000762f89be1b52  lea r14, [rax+0x110]
0000762f89be1b59  mov r12, [r13+r14*1]
0000762f89be1b5e  lea r14, [rax+0x118]
0000762f89be1b65  mov r11, [r13+r14*1]
0000762f89be1b6a  movq xmm1, r12
0000762f89be1b6f  movq xmm15, r11
0000762f89be1b74  movq xmm1, xmm1
0000762f89be1b78  movq xmm1, xmm1
0000762f89be1b7c  movaps [r15+0x1E0], xmm1
0000762f89be1b84  movq xmm15, xmm15
0000762f89be1b89  movq xmm15, xmm15
0000762f89be1b8e  movaps [r15+0x1D0], xmm15
0000762f89be1b96  lea r14, [rax+0x100]
0000762f89be1b9d  mov r12, [r13+r14*1]
0000762f89be1ba2  lea r14, [rax+0x108]
0000762f89be1ba9  mov r11, [r13+r14*1]
0000762f89be1bae  movq xmm1, r12
0000762f89be1bb3  movq xmm15, r11
0000762f89be1bb8  movq xmm1, xmm1
0000762f89be1bbc  movq xmm1, xmm1
0000762f89be1bc0  movaps [r15+0x200], xmm1
0000762f89be1bc8  movq xmm15, xmm15
0000762f89be1bcd  movq xmm15, xmm15
0000762f89be1bd2  movaps [r15+0x1F0], xmm15
0000762f89be1bda  mov qword ptr [r15+0x40], 0x430000
0000762f89be1be2  mov r14d, 0x430510
0000762f89be1be8  mov r12, [r13+r14*1]
0000762f89be1bed  movq xmm1, r12
0000762f89be1bf2  lea r14, [rax+0x150]
0000762f89be1bf9  mov [r15+0xF8], r14
0000762f89be1c00  mov rax, [r15+0x50]
0000762f89be1c04  movups xmm15, [r13+rax*1]
0000762f89be1c0a  movaps [r15+0x120], xmm15
0000762f89be1c12  mov qword ptr [r15+0x48], 0x10
0000762f89be1c1a  xor eax, eax
0000762f89be1c1c  mov r14d, 0x10
0000762f89be1c22  mov r12d, 0x200
0000762f89be1c28  cmp r14, r12
0000762f89be1c2b  cmc
0000762f89be1c2c  lahf
0000762f89be1c2d  seto al
0000762f89be1c30  mov [r15+0x108], eax
0000762f89be1c37  pextrq rax, xmm15, 0x01
0000762f89be1c3e  movq xmm14, rax
0000762f89be1c43  movaps [r15+0x130], xmm14
0000762f89be1c4b  movq rax, xmm1
0000762f89be1c50  movq r14, xmm15
0000762f89be1c55  vmovq xmm1, rax
0000762f89be1c5a  vmovq xmm15, r14
0000762f89be1c5f  movaps xmm13, xmm1
0000762f89be1c63  addsd xmm13, xmm15
0000762f89be1c68  ucomisd xmm13, xmm13
0000762f89be1c6d  jp 0x0000762F89BE1D86
0000762f89be1c73  movq xmm13, xmm13
0000762f89be1c78  movq rax, xmm13
0000762f89be1c7d  movq r14, xmm14
0000762f89be1c82  vmovq xmm1, rax
0000762f89be1c87  vmovq xmm15, r14
0000762f89be1c8c  movaps xmm14, xmm1
0000762f89be1c90  addsd xmm14, xmm15
0000762f89be1c95  ucomisd xmm14, xmm14
0000762f89be1c9a  jp 0x0000762F89BE1DCE
0000762f89be1ca0  movq xmm14, xmm14
0000762f89be1ca5  movaps [r15+0x110], xmm14
0000762f89be1cad  mov eax, [r15+0x108]
0000762f89be1cb4  sahf
0000762f89be1cb5  jnz 0x0000762F89BE1CE7
0000762f89be1cb7  cmp dword ptr [r15+0x318], 0x00
0000762f89be1cbf  jz 0x0000762F89BE1FE0
0000762f89be1cc5  nop [rax+rax*1], ax
0000762f89be1cce  nop [rax+rax*1], eax
0000762f89be1cd6  mov eax, 0x410490
0000762f89be1cdb  mov [r15+0x100], rax
0000762f89be1ce2  jmp 0x0000762F899FE110
0000762f89be1ce7  cmp dword ptr [r15+0x318], 0x00
0000762f89be1cef  jz 0x0000762F89BE1E20
0000762f89be1cf5  nop [rax+rax*1], ax
0000762f89be1cfe  nop [rax+rax*1], eax
0000762f89be1d06  mov eax, 0x410474
0000762f89be1d0b  mov [r15+0x100], rax
0000762f89be1d12  jmp 0x0000762F899FE110
0000762f89be1d17  int3
0000762f89be1d18  call 0x0000762F89AE27E0
0000762f89be1d1d  jmp 0x0000762F89BE1AC3
0000762f89be1d22  call 0x0000762F89AE27E0
0000762f89be1d27  jmp 0x0000762F89BE1AD6
0000762f89be1d2c  call 0x0000762F89AE1570
0000762f89be1d31  jmp 0x0000762F89BE1AE2
0000762f89be1d36  call 0x0000762F89AE27E0
0000762f89be1d3b  jmp 0x0000762F89BE1B1A
0000762f89be1d40  call 0x0000762F89AE1570
0000762f89be1d45  jmp 0x0000762F89BE1B26
0000762f89be1d4a  call 0x0000762F89AE27E0
0000762f89be1d4f  jmp 0x0000762F89BE1B5E
0000762f89be1d54  call 0x0000762F89AE1570
0000762f89be1d59  jmp 0x0000762F89BE1B6A
0000762f89be1d5e  call 0x0000762F89AE27E0
0000762f89be1d63  jmp 0x0000762F89BE1BA2
0000762f89be1d68  call 0x0000762F89AE1570
0000762f89be1d6d  jmp 0x0000762F89BE1BAE
0000762f89be1d72  call 0x0000762F89AE27E0
0000762f89be1d77  jmp 0x0000762F89BE1BED
0000762f89be1d7c  call 0x0000762F89A0E760
0000762f89be1d81  jmp 0x0000762F89BE1C0A
0000762f89be1d86  ucomisd xmm1, xmm15
0000762f89be1d8b  jp 0x0000762F89BE1D9A
0000762f89be1d8d  movaps xmm13, [0x0000762F897FE060]
0000762f89be1d95  jmp 0x0000762F89BE1C73
0000762f89be1d9a  vxorps xmm0, xmm1, xmm15
0000762f89be1d9f  pextrw eax, xmm0, 0x03
0000762f89be1da4  and eax, 0x7FF8
0000762f89be1da9  cmp eax, 0x08
0000762f89be1dac  jnz 0x0000762F89BE1C73
0000762f89be1db2  movq rax, xmm15
0000762f89be1db7  shl rax, 0x0D
0000762f89be1dbb  jbe 0x0000762F89BE1C73
0000762f89be1dc1  vorps xmm13, xmm15, [0x0000762F897FE070]
0000762f89be1dc9  jmp 0x0000762F89BE1C73
0000762f89be1dce  ucomisd xmm1, xmm15
0000762f89be1dd3  jp 0x0000762F89BE1DE2
0000762f89be1dd5  movaps xmm14, [0x0000762F897FE060]
0000762f89be1ddd  jmp 0x0000762F89BE1CA0
0000762f89be1de2  vxorps xmm0, xmm1, xmm15
0000762f89be1de7  pextrw eax, xmm0, 0x03
0000762f89be1dec  and eax, 0x7FF8
0000762f89be1df1  cmp eax, 0x08
0000762f89be1df4  jnz 0x0000762F89BE1CA0
0000762f89be1dfa  movq rax, xmm15
0000762f89be1dff  shl rax, 0x0D
0000762f89be1e03  jbe 0x0000762F89BE1CA0
0000762f89be1e09  vorps xmm14, xmm15, [0x0000762F897FE070]
0000762f89be1e11  jmp 0x0000762F89BE1CA0
0000762f89be1e16  int3
0000762f89be1e17  nop [rax+rax*1], ax
0000762f89be1e20  mov rax, [r15+0x48]
0000762f89be1e24  mov r14, [r15+0x50]
0000762f89be1e28  lea r12, [r14+rax*1]
0000762f89be1e2c  movups xmm1, [r13+r12*1]
0000762f89be1e32  movaps [r15+0x120], xmm1
0000762f89be1e3a  lea r14, [rax+0x10]
0000762f89be1e3e  mov [r15+0x48], r14
0000762f89be1e42  xor eax, eax
0000762f89be1e44  mov r12d, 0x200
0000762f89be1e4a  cmp r14, r12
0000762f89be1e4d  cmc
0000762f89be1e4e  lahf
0000762f89be1e4f  seto al
0000762f89be1e52  mov [r15+0x108], eax
0000762f89be1e59  pextrq rax, xmm1, 0x01
0000762f89be1e60  movq xmm15, rax
0000762f89be1e65  movaps [r15+0x130], xmm15
0000762f89be1e6d  movaps xmm14, [r15+0x110]
0000762f89be1e75  movq rax, xmm14
0000762f89be1e7a  movq r14, xmm1
0000762f89be1e7f  vmovq xmm1, rax
0000762f89be1e84  vmovq xmm14, r14
0000762f89be1e89  movaps xmm13, xmm1
0000762f89be1e8d  addsd xmm13, xmm14
0000762f89be1e92  ucomisd xmm13, xmm13
0000762f89be1e97  jp 0x0000762F89BE1F4C
0000762f89be1e9d  movq xmm13, xmm13
0000762f89be1ea2  movq rax, xmm13
0000762f89be1ea7  movq r14, xmm15
0000762f89be1eac  vmovq xmm1, rax
0000762f89be1eb1  vmovq xmm15, r14
0000762f89be1eb6  movaps xmm14, xmm1
0000762f89be1eba  addsd xmm14, xmm15
0000762f89be1ebf  ucomisd xmm14, xmm14
0000762f89be1ec4  jp 0x0000762F89BE1F94
0000762f89be1eca  movq xmm14, xmm14
0000762f89be1ecf  movaps [r15+0x110], xmm14
0000762f89be1ed7  mov eax, [r15+0x108]
0000762f89be1ede  sahf
0000762f89be1edf  jnz 0x0000762F89BE1F11
0000762f89be1ee1  cmp dword ptr [r15+0x318], 0x00
0000762f89be1ee9  jz 0x0000762F89BE1FE0
0000762f89be1eef  nop [rax+rax*1], ax
0000762f89be1ef8  nop [rax+rax*1], eax
0000762f89be1f00  mov eax, 0x410490
0000762f89be1f05  mov [r15+0x100], rax
0000762f89be1f0c  jmp 0x0000762F899FE110
0000762f89be1f11  cmp dword ptr [r15+0x318], 0x00
0000762f89be1f19  jz 0x0000762F89BE1E20
0000762f89be1f1f  nop [rax+rax*1], ax
0000762f89be1f28  nop [rax+rax*1], eax
0000762f89be1f30  mov eax, 0x410474
0000762f89be1f35  mov [r15+0x100], rax
0000762f89be1f3c  jmp 0x0000762F899FE110
0000762f89be1f41  int3
0000762f89be1f42  call 0x0000762F89AB52F0
0000762f89be1f47  jmp 0x0000762F89BE1E32
0000762f89be1f4c  ucomisd xmm1, xmm14
0000762f89be1f51  jp 0x0000762F89BE1F60
0000762f89be1f53  movaps xmm13, [0x0000762F897FE060]
0000762f89be1f5b  jmp 0x0000762F89BE1E9D
0000762f89be1f60  vxorps xmm0, xmm1, xmm14
0000762f89be1f65  pextrw eax, xmm0, 0x03
0000762f89be1f6a  and eax, 0x7FF8
0000762f89be1f6f  cmp eax, 0x08
0000762f89be1f72  jnz 0x0000762F89BE1E9D
0000762f89be1f78  movq rax, xmm14
0000762f89be1f7d  shl rax, 0x0D
0000762f89be1f81  jbe 0x0000762F89BE1E9D
0000762f89be1f87  vorps xmm13, xmm14, [0x0000762F897FE070]
0000762f89be1f8f  jmp 0x0000762F89BE1E9D
0000762f89be1f94  ucomisd xmm1, xmm15
0000762f89be1f99  jp 0x0000762F89BE1FA8
0000762f89be1f9b  movaps xmm14, [0x0000762F897FE060]
0000762f89be1fa3  jmp 0x0000762F89BE1ECA
0000762f89be1fa8  vxorps xmm0, xmm1, xmm15
0000762f89be1fad  pextrw eax, xmm0, 0x03
0000762f89be1fb2  and eax, 0x7FF8
0000762f89be1fb7  cmp eax, 0x08
0000762f89be1fba  jnz 0x0000762F89BE1ECA
0000762f89be1fc0  movq rax, xmm15
0000762f89be1fc5  shl rax, 0x0D
0000762f89be1fc9  jbe 0x0000762F89BE1ECA
0000762f89be1fcf  vorps xmm14, xmm15, [0x0000762F897FE070]
0000762f89be1fd7  jmp 0x0000762F89BE1ECA
0000762f89be1fdc  int3
0000762f89be1fdd  nop [rax], eax
0000762f89be1fe0  mov rax, [r15+0x40]
0000762f89be1fe4  lea r14, [rax+0x510]
0000762f89be1feb  movaps xmm1, [r15+0x110]
0000762f89be1ff3  movq rax, xmm1
0000762f89be1ff8  mov [r13+r14*1], rax
0000762f89be1ffd  mov rax, [r15+0xF0]
0000762f89be2004  mov [r15+0x100], rax
0000762f89be200b  jmp 0x0000762F89BCE5C0
0000762f89be2010  int3
0000762f89be2011  call 0x0000762F89AD5EB0
0000762f89be2016  jmp 0x0000762F89BE1FFD
0000762f89be201b  int3
0000762f89be201c  nop [rax], eax
0000762f89be2020  mov qword ptr [r15+0x100], 0x04
0000762f89be202b  mov esi, 0x00
0000762f89be2030  mov edx, 0x09
0000762f89be2035  mov rdi, 0x7FFC2F339AC0
0000762f89be203f  mov rax, 0x604D6F7D9970
0000762f89be2049  call rax
0000762f89be204b  cmp dword ptr [r15+0x318], 0x00
0000762f89be2053  jnz 0x0000762F899FE110
0000762f89be2059  jmp 0x0000762F899FE0A0
0000762f89be205e  int3
0000762f89be205f  int3
