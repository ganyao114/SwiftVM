0000747fd7fce69b  nop [rax+rax*1], eax
0000747fd7fce6a0  vmovaps xmm1, [0x0000747FD7BFE010]
0000747fd7fce6a8  movq xmm1, xmm1
0000747fd7fce6ac  movaps [r15+0x110], xmm1
0000747fd7fce6b4  vmovaps xmm1, [0x0000747FD7BFE020]
0000747fd7fce6bc  movq xmm1, xmm1
0000747fd7fce6c0  movaps [r15+0x120], xmm1
0000747fd7fce6c8  mov eax, 0x4204C0
0000747fd7fce6cd  mov r14, [r13+rax*1]
0000747fd7fce6d2  movq xmm1, r14
0000747fd7fce6d7  movaps [r15+0x130], xmm1
0000747fd7fce6df  vmovaps xmm1, [0x0000747FD7BFE030]
0000747fd7fce6e7  vpbroadcastq xmm1, xmm1
0000747fd7fce6ec  movaps [r15+0x140], xmm1
0000747fd7fce6f4  mov qword ptr [r15+0x40], 0x02
0000747fd7fce6fc  vmovaps xmm15, [0x0000747FD7BFE040]
0000747fd7fce704  movq xmm15, xmm15
0000747fd7fce709  movaps [r15+0x150], xmm15
0000747fd7fce711  mov qword ptr [r15+0x58], 0x420000
0000747fd7fce719  vmovaps xmm15, [0x0000747FD7BFE050]
0000747fd7fce721  vpbroadcastq xmm15, xmm15
0000747fd7fce726  movaps [r15+0x160], xmm15
0000747fd7fce72e  mov rax, [r15+0x40]
0000747fd7fce732  vmovq xmm14, rax
0000747fd7fce737  vpbroadcastq xmm14, xmm14
0000747fd7fce73c  movaps [r15+0x170], xmm14
0000747fd7fce744  mov eax, 0x4204D0
0000747fd7fce749  movups xmm13, [r13+rax*1]
0000747fd7fce74f  mov qword ptr [r15+0x40], 0x430518
0000747fd7fce757  mov qword ptr [r15+0x50], 0x430720
0000747fd7fce75f  vpmovqd xmm12, xmm13
0000747fd7fce765  pxor xmm11, xmm11
0000747fd7fce76a  punpcklqdq xmm12, xmm11
0000747fd7fce76f  movaps [r15+0x210], xmm12
0000747fd7fce777  movq xmm12, qword ptr [r15+0x120]
0000747fd7fce780  movq xmm11, qword ptr [r15+0x130]
0000747fd7fce789  psubd xmm12, xmm11
0000747fd7fce78e  movq xmm12, xmm12
0000747fd7fce793  paddq xmm13, xmm14
0000747fd7fce798  movaps [r15+0x180], xmm13
0000747fd7fce7a0  movq xmm14, qword ptr [r15+0x150]
0000747fd7fce7a9  paddd xmm11, xmm14
0000747fd7fce7ae  movq xmm11, xmm11
0000747fd7fce7b3  movq xmm11, xmm11
0000747fd7fce7b8  movaps [r15+0x130], xmm11
0000747fd7fce7c0  pmovzxdq xmm12, xmm12
0000747fd7fce7c6  psllq xmm12, 0x00
0000747fd7fce7cc  movq xmm14, qword ptr [r15+0x210]
0000747fd7fce7d5  movq xmm13, qword ptr [r15+0x110]
0000747fd7fce7de  paddd xmm14, xmm13
0000747fd7fce7e3  movq xmm14, xmm14
0000747fd7fce7e8  vcvtuqq2pd xmm12, xmm12
0000747fd7fce7ee  pmovzxdq xmm14, xmm14
0000747fd7fce7f4  psllq xmm14, 0x00
0000747fd7fce7fa  vcvtuqq2pd xmm14, xmm14
0000747fd7fce800  movaps xmm13, xmm12
0000747fd7fce804  mulpd xmm13, xmm1
0000747fd7fce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000747fd7fce80f  ptest xmm11, xmm11
0000747fd7fce815  jnz 0x0000747FD7FCE8FF
0000747fd7fce81b  movaps [r15+0x220], xmm13
0000747fd7fce823  mov eax, 0x430720
0000747fd7fce828  movups [r13+rax*1], xmm13
0000747fd7fce82e  movaps xmm1, xmm14
0000747fd7fce832  mulpd xmm1, xmm15
0000747fd7fce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000747fd7fce83c  ptest xmm13, xmm13
0000747fd7fce842  jnz 0x0000747FD7FCEA4C
0000747fd7fce848  movaps [r15+0x210], xmm1
0000747fd7fce850  mov eax, 0x430518
0000747fd7fce855  movups [r13+rax*1], xmm1
0000747fd7fce85b  mov qword ptr [r15+0x48], 0x10
0000747fd7fce863  xor eax, eax
0000747fd7fce865  mov r14d, 0x10
0000747fd7fce86b  mov r12d, 0x200
0000747fd7fce871  cmp r14, r12
0000747fd7fce874  cmc
0000747fd7fce875  lahf
0000747fd7fce876  seto al
0000747fd7fce879  mov [r15+0x108], eax
0000747fd7fce880  mov eax, [r15+0x108]
0000747fd7fce887  sahf
0000747fd7fce888  jnz 0x0000747FD7FCE8BA
0000747fd7fce88a  cmp dword ptr [r15+0x318], 0x00
0000747fd7fce892  jz 0x0000747FD7FCEFF0
0000747fd7fce898  nop [rax+rax*1], ax
0000747fd7fce8a1  nop [rax+rax*1], eax
0000747fd7fce8a9  mov eax, 0x4101EC
0000747fd7fce8ae  mov [r15+0x100], rax
0000747fd7fce8b5  jmp 0x0000747FD7DFE110
0000747fd7fce8ba  cmp dword ptr [r15+0x318], 0x00
0000747fd7fce8c2  jz 0x0000747FD7FCEBA0
0000747fd7fce8c8  nop [rax+rax*1], ax
0000747fd7fce8d1  nop [rax+rax*1], eax
0000747fd7fce8d9  mov eax, 0x4101AC
0000747fd7fce8de  mov [r15+0x100], rax
0000747fd7fce8e5  jmp 0x0000747FD7DFE110
0000747fd7fce8ea  int3
0000747fd7fce8eb  call 0x0000747FD7E0DC20
0000747fd7fce8f0  jmp 0x0000747FD7FCE6D2
0000747fd7fce8f5  call 0x0000747FD7E0C260
0000747fd7fce8fa  jmp 0x0000747FD7FCE74F
0000747fd7fce8ff  sub rsp, 0x08
0000747fd7fce903  push rax
0000747fd7fce904  push rcx
0000747fd7fce905  push rdx
0000747fd7fce906  push rdi
0000747fd7fce907  push rsi
0000747fd7fce908  push r8
0000747fd7fce90a  push r9
0000747fd7fce90c  push r10
0000747fd7fce90e  push r11
0000747fd7fce910  sub rsp, 0xF0
0000747fd7fce917  vmovaps [rsp], xmm0
0000747fd7fce91c  vmovaps [rsp+0x10], xmm1
0000747fd7fce922  vmovaps [rsp+0x20], xmm2
0000747fd7fce928  vmovaps [rsp+0x30], xmm3
0000747fd7fce92e  vmovaps [rsp+0x40], xmm4
0000747fd7fce934  vmovaps [rsp+0x50], xmm5
0000747fd7fce93a  vmovaps [rsp+0x60], xmm6
0000747fd7fce940  vmovaps [rsp+0x70], xmm7
0000747fd7fce946  vmovaps [rsp+0x80], xmm8
0000747fd7fce94f  vmovaps [rsp+0x90], xmm9
0000747fd7fce958  vmovaps [rsp+0xA0], xmm10
0000747fd7fce961  vmovaps [rsp+0xB0], xmm11
0000747fd7fce96a  vmovaps [rsp+0xC0], xmm12
0000747fd7fce973  vmovaps [rsp+0xD0], xmm14
0000747fd7fce97c  vmovaps [rsp+0xE0], xmm15
0000747fd7fce985  sub rsp, 0x30
0000747fd7fce989  movaps [rsp], xmm13
0000747fd7fce98e  movaps [rsp+0x10], xmm12
0000747fd7fce994  movaps [rsp+0x20], xmm1
0000747fd7fce999  lea rdi, [rsp]
0000747fd7fce99d  mov esi, 0x00
0000747fd7fce9a2  mov rax, 0x6055A0B6E530
0000747fd7fce9ac  call rax
0000747fd7fce9ae  movaps xmm13, [rsp]
0000747fd7fce9b3  add rsp, 0x30
0000747fd7fce9b7  vmovaps xmm0, [rsp]
0000747fd7fce9bc  vmovaps xmm1, [rsp+0x10]
0000747fd7fce9c2  vmovaps xmm2, [rsp+0x20]
0000747fd7fce9c8  vmovaps xmm3, [rsp+0x30]
0000747fd7fce9ce  vmovaps xmm4, [rsp+0x40]
0000747fd7fce9d4  vmovaps xmm5, [rsp+0x50]
0000747fd7fce9da  vmovaps xmm6, [rsp+0x60]
0000747fd7fce9e0  vmovaps xmm7, [rsp+0x70]
0000747fd7fce9e6  vmovaps xmm8, [rsp+0x80]
0000747fd7fce9ef  vmovaps xmm9, [rsp+0x90]
0000747fd7fce9f8  vmovaps xmm10, [rsp+0xA0]
0000747fd7fcea01  vmovaps xmm11, [rsp+0xB0]
0000747fd7fcea0a  vmovaps xmm12, [rsp+0xC0]
0000747fd7fcea13  vmovaps xmm14, [rsp+0xD0]
0000747fd7fcea1c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fcea25  add rsp, 0xF0
0000747fd7fcea2c  pop r11
0000747fd7fcea2e  pop r10
0000747fd7fcea30  pop r9
0000747fd7fcea32  pop r8
0000747fd7fcea34  pop rsi
0000747fd7fcea35  pop rdi
0000747fd7fcea36  pop rdx
0000747fd7fcea37  pop rcx
0000747fd7fcea38  pop rax
0000747fd7fcea39  add rsp, 0x08
0000747fd7fcea3d  jmp 0x0000747FD7FCE81B
0000747fd7fcea42  call 0x0000747FD7E0C380
0000747fd7fcea47  jmp 0x0000747FD7FCE82E
0000747fd7fcea4c  sub rsp, 0x08
0000747fd7fcea50  push rax
0000747fd7fcea51  push rcx
0000747fd7fcea52  push rdx
0000747fd7fcea53  push rdi
0000747fd7fcea54  push rsi
0000747fd7fcea55  push r8
0000747fd7fcea57  push r9
0000747fd7fcea59  push r10
0000747fd7fcea5b  push r11
0000747fd7fcea5d  sub rsp, 0xF0
0000747fd7fcea64  vmovaps [rsp], xmm0
0000747fd7fcea69  vmovaps [rsp+0x10], xmm2
0000747fd7fcea6f  vmovaps [rsp+0x20], xmm3
0000747fd7fcea75  vmovaps [rsp+0x30], xmm4
0000747fd7fcea7b  vmovaps [rsp+0x40], xmm5
0000747fd7fcea81  vmovaps [rsp+0x50], xmm6
0000747fd7fcea87  vmovaps [rsp+0x60], xmm7
0000747fd7fcea8d  vmovaps [rsp+0x70], xmm8
0000747fd7fcea93  vmovaps [rsp+0x80], xmm9
0000747fd7fcea9c  vmovaps [rsp+0x90], xmm10
0000747fd7fceaa5  vmovaps [rsp+0xA0], xmm11
0000747fd7fceaae  vmovaps [rsp+0xB0], xmm12
0000747fd7fceab7  vmovaps [rsp+0xC0], xmm13
0000747fd7fceac0  vmovaps [rsp+0xD0], xmm14
0000747fd7fceac9  vmovaps [rsp+0xE0], xmm15
0000747fd7fcead2  sub rsp, 0x30
0000747fd7fcead6  movaps [rsp], xmm1
0000747fd7fceada  movaps [rsp+0x10], xmm14
0000747fd7fceae0  movaps [rsp+0x20], xmm15
0000747fd7fceae6  lea rdi, [rsp]
0000747fd7fceaea  mov esi, 0x00
0000747fd7fceaef  mov rax, 0x6055A0B6E530
0000747fd7fceaf9  call rax
0000747fd7fceafb  movaps xmm1, [rsp]
0000747fd7fceaff  add rsp, 0x30
0000747fd7fceb03  vmovaps xmm0, [rsp]
0000747fd7fceb08  vmovaps xmm2, [rsp+0x10]
0000747fd7fceb0e  vmovaps xmm3, [rsp+0x20]
0000747fd7fceb14  vmovaps xmm4, [rsp+0x30]
0000747fd7fceb1a  vmovaps xmm5, [rsp+0x40]
0000747fd7fceb20  vmovaps xmm6, [rsp+0x50]
0000747fd7fceb26  vmovaps xmm7, [rsp+0x60]
0000747fd7fceb2c  vmovaps xmm8, [rsp+0x70]
0000747fd7fceb32  vmovaps xmm9, [rsp+0x80]
0000747fd7fceb3b  vmovaps xmm10, [rsp+0x90]
0000747fd7fceb44  vmovaps xmm11, [rsp+0xA0]
0000747fd7fceb4d  vmovaps xmm12, [rsp+0xB0]
0000747fd7fceb56  vmovaps xmm13, [rsp+0xC0]
0000747fd7fceb5f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fceb68  vmovaps xmm15, [rsp+0xE0]
0000747fd7fceb71  add rsp, 0xF0
0000747fd7fceb78  pop r11
0000747fd7fceb7a  pop r10
0000747fd7fceb7c  pop r9
0000747fd7fceb7e  pop r8
0000747fd7fceb80  pop rsi
0000747fd7fceb81  pop rdi
0000747fd7fceb82  pop rdx
0000747fd7fceb83  pop rcx
0000747fd7fceb84  pop rax
0000747fd7fceb85  add rsp, 0x08
0000747fd7fceb89  jmp 0x0000747FD7FCE848
0000747fd7fceb8e  call 0x0000747FD7DFF540
0000747fd7fceb93  jmp 0x0000747FD7FCE85B
0000747fd7fceb98  int3
0000747fd7fceb99  nop [rax], eax
0000747fd7fceba0  movaps xmm1, [r15+0x180]
0000747fd7fceba8  vpmovqd xmm15, xmm1
0000747fd7fcebae  pxor xmm14, xmm14
0000747fd7fcebb3  punpcklqdq xmm15, xmm14
0000747fd7fcebb8  movaps [r15+0x210], xmm15
0000747fd7fcebc0  movq xmm15, qword ptr [r15+0x120]
0000747fd7fcebc9  movq xmm14, qword ptr [r15+0x130]
0000747fd7fcebd2  psubd xmm15, xmm14
0000747fd7fcebd7  movq xmm15, xmm15
0000747fd7fcebdc  movaps xmm13, [r15+0x170]
0000747fd7fcebe4  paddq xmm1, xmm13
0000747fd7fcebe9  movaps [r15+0x180], xmm1
0000747fd7fcebf1  movq xmm1, qword ptr [r15+0x150]
0000747fd7fcebfa  paddd xmm14, xmm1
0000747fd7fcebff  movq xmm14, xmm14
0000747fd7fcec04  movq xmm14, xmm14
0000747fd7fcec09  movaps [r15+0x130], xmm14
0000747fd7fcec11  pmovzxdq xmm15, xmm15
0000747fd7fcec17  psllq xmm15, 0x00
0000747fd7fcec1d  movq xmm1, qword ptr [r15+0x210]
0000747fd7fcec26  movq xmm14, qword ptr [r15+0x110]
0000747fd7fcec2f  paddd xmm1, xmm14
0000747fd7fcec34  movq xmm1, xmm1
0000747fd7fcec38  vcvtuqq2pd xmm15, xmm15
0000747fd7fcec3e  pmovzxdq xmm1, xmm1
0000747fd7fcec43  psllq xmm1, 0x00
0000747fd7fcec48  vcvtuqq2pd xmm1, xmm1
0000747fd7fcec4e  movaps xmm14, [r15+0x140]
0000747fd7fcec56  movaps xmm13, xmm15
0000747fd7fcec5a  mulpd xmm13, xmm14
0000747fd7fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000747fd7fcec65  ptest xmm12, xmm12
0000747fd7fcec6b  jnz 0x0000747FD7FCED4E
0000747fd7fcec71  movaps [r15+0x220], xmm13
0000747fd7fcec79  mov rax, [r15+0x48]
0000747fd7fcec7d  mov r14, [r15+0x50]
0000747fd7fcec81  lea r12, [r14+rax*1]
0000747fd7fcec85  movups [r13+r12*1], xmm13
0000747fd7fcec8b  movaps xmm15, [r15+0x160]
0000747fd7fcec93  movaps xmm14, xmm1
0000747fd7fcec97  mulpd xmm14, xmm15
0000747fd7fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000747fd7fceca2  ptest xmm13, xmm13
0000747fd7fceca8  jnz 0x0000747FD7FCEE9C
0000747fd7fcecae  movaps [r15+0x210], xmm14
0000747fd7fcecb6  mov r14, [r15+0x40]
0000747fd7fcecba  lea r12, [r14+rax*1]
0000747fd7fcecbe  movups [r13+r12*1], xmm14
0000747fd7fcecc4  lea r14, [rax+0x10]
0000747fd7fcecc8  mov [r15+0x48], r14
0000747fd7fceccc  xor eax, eax
0000747fd7fcecce  mov r12d, 0x200
0000747fd7fcecd4  cmp r14, r12
0000747fd7fcecd7  cmc
0000747fd7fcecd8  lahf
0000747fd7fcecd9  seto al
0000747fd7fcecdc  mov [r15+0x108], eax
0000747fd7fcece3  mov eax, [r15+0x108]
0000747fd7fcecea  sahf
0000747fd7fceceb  jnz 0x0000747FD7FCED1D
0000747fd7fceced  cmp dword ptr [r15+0x318], 0x00
0000747fd7fcecf5  jz 0x0000747FD7FCEFF0
0000747fd7fcecfb  nop [rax+rax*1], ax
0000747fd7fced04  nop [rax+rax*1], eax
0000747fd7fced0c  mov eax, 0x4101EC
0000747fd7fced11  mov [r15+0x100], rax
0000747fd7fced18  jmp 0x0000747FD7DFE110
0000747fd7fced1d  cmp dword ptr [r15+0x318], 0x00
0000747fd7fced25  jz 0x0000747FD7FCEBA0
0000747fd7fced2b  nop [rax+rax*1], ax
0000747fd7fced34  nop [rax+rax*1], eax
0000747fd7fced3c  mov eax, 0x4101AC
0000747fd7fced41  mov [r15+0x100], rax
0000747fd7fced48  jmp 0x0000747FD7DFE110
0000747fd7fced4d  int3
0000747fd7fced4e  sub rsp, 0x08
0000747fd7fced52  push rax
0000747fd7fced53  push rcx
0000747fd7fced54  push rdx
0000747fd7fced55  push rdi
0000747fd7fced56  push rsi
0000747fd7fced57  push r8
0000747fd7fced59  push r9
0000747fd7fced5b  push r10
0000747fd7fced5d  push r11
0000747fd7fced5f  sub rsp, 0xF0
0000747fd7fced66  vmovaps [rsp], xmm0
0000747fd7fced6b  vmovaps [rsp+0x10], xmm1
0000747fd7fced71  vmovaps [rsp+0x20], xmm2
0000747fd7fced77  vmovaps [rsp+0x30], xmm3
0000747fd7fced7d  vmovaps [rsp+0x40], xmm4
0000747fd7fced83  vmovaps [rsp+0x50], xmm5
0000747fd7fced89  vmovaps [rsp+0x60], xmm6
0000747fd7fced8f  vmovaps [rsp+0x70], xmm7
0000747fd7fced95  vmovaps [rsp+0x80], xmm8
0000747fd7fced9e  vmovaps [rsp+0x90], xmm9
0000747fd7fceda7  vmovaps [rsp+0xA0], xmm10
0000747fd7fcedb0  vmovaps [rsp+0xB0], xmm11
0000747fd7fcedb9  vmovaps [rsp+0xC0], xmm12
0000747fd7fcedc2  vmovaps [rsp+0xD0], xmm14
0000747fd7fcedcb  vmovaps [rsp+0xE0], xmm15
0000747fd7fcedd4  sub rsp, 0x30
0000747fd7fcedd8  movaps [rsp], xmm13
0000747fd7fceddd  movaps [rsp+0x10], xmm15
0000747fd7fcede3  movaps [rsp+0x20], xmm14
0000747fd7fcede9  lea rdi, [rsp]
0000747fd7fceded  mov esi, 0x00
0000747fd7fcedf2  mov rax, 0x6055A0B6E530
0000747fd7fcedfc  call rax
0000747fd7fcedfe  movaps xmm13, [rsp]
0000747fd7fcee03  add rsp, 0x30
0000747fd7fcee07  vmovaps xmm0, [rsp]
0000747fd7fcee0c  vmovaps xmm1, [rsp+0x10]
0000747fd7fcee12  vmovaps xmm2, [rsp+0x20]
0000747fd7fcee18  vmovaps xmm3, [rsp+0x30]
0000747fd7fcee1e  vmovaps xmm4, [rsp+0x40]
0000747fd7fcee24  vmovaps xmm5, [rsp+0x50]
0000747fd7fcee2a  vmovaps xmm6, [rsp+0x60]
0000747fd7fcee30  vmovaps xmm7, [rsp+0x70]
0000747fd7fcee36  vmovaps xmm8, [rsp+0x80]
0000747fd7fcee3f  vmovaps xmm9, [rsp+0x90]
0000747fd7fcee48  vmovaps xmm10, [rsp+0xA0]
0000747fd7fcee51  vmovaps xmm11, [rsp+0xB0]
0000747fd7fcee5a  vmovaps xmm12, [rsp+0xC0]
0000747fd7fcee63  vmovaps xmm14, [rsp+0xD0]
0000747fd7fcee6c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fcee75  add rsp, 0xF0
0000747fd7fcee7c  pop r11
0000747fd7fcee7e  pop r10
0000747fd7fcee80  pop r9
0000747fd7fcee82  pop r8
0000747fd7fcee84  pop rsi
0000747fd7fcee85  pop rdi
0000747fd7fcee86  pop rdx
0000747fd7fcee87  pop rcx
0000747fd7fcee88  pop rax
0000747fd7fcee89  add rsp, 0x08
0000747fd7fcee8d  jmp 0x0000747FD7FCEC71
0000747fd7fcee92  call 0x0000747FD7EC2240
0000747fd7fcee97  jmp 0x0000747FD7FCEC8B
0000747fd7fcee9c  sub rsp, 0x08
0000747fd7fceea0  push rax
0000747fd7fceea1  push rcx
0000747fd7fceea2  push rdx
0000747fd7fceea3  push rdi
0000747fd7fceea4  push rsi
0000747fd7fceea5  push r8
0000747fd7fceea7  push r9
0000747fd7fceea9  push r10
0000747fd7fceeab  push r11
0000747fd7fceead  sub rsp, 0xF0
0000747fd7fceeb4  vmovaps [rsp], xmm0
0000747fd7fceeb9  vmovaps [rsp+0x10], xmm1
0000747fd7fceebf  vmovaps [rsp+0x20], xmm2
0000747fd7fceec5  vmovaps [rsp+0x30], xmm3
0000747fd7fceecb  vmovaps [rsp+0x40], xmm4
0000747fd7fceed1  vmovaps [rsp+0x50], xmm5
0000747fd7fceed7  vmovaps [rsp+0x60], xmm6
0000747fd7fceedd  vmovaps [rsp+0x70], xmm7
0000747fd7fceee3  vmovaps [rsp+0x80], xmm8
0000747fd7fceeec  vmovaps [rsp+0x90], xmm9
0000747fd7fceef5  vmovaps [rsp+0xA0], xmm10
0000747fd7fceefe  vmovaps [rsp+0xB0], xmm11
0000747fd7fcef07  vmovaps [rsp+0xC0], xmm12
0000747fd7fcef10  vmovaps [rsp+0xD0], xmm13
0000747fd7fcef19  vmovaps [rsp+0xE0], xmm15
0000747fd7fcef22  sub rsp, 0x30
0000747fd7fcef26  movaps [rsp], xmm14
0000747fd7fcef2b  movaps [rsp+0x10], xmm1
0000747fd7fcef30  movaps [rsp+0x20], xmm15
0000747fd7fcef36  lea rdi, [rsp]
0000747fd7fcef3a  mov esi, 0x00
0000747fd7fcef3f  mov rax, 0x6055A0B6E530
0000747fd7fcef49  call rax
0000747fd7fcef4b  movaps xmm14, [rsp]
0000747fd7fcef50  add rsp, 0x30
0000747fd7fcef54  vmovaps xmm0, [rsp]
0000747fd7fcef59  vmovaps xmm1, [rsp+0x10]
0000747fd7fcef5f  vmovaps xmm2, [rsp+0x20]
0000747fd7fcef65  vmovaps xmm3, [rsp+0x30]
0000747fd7fcef6b  vmovaps xmm4, [rsp+0x40]
0000747fd7fcef71  vmovaps xmm5, [rsp+0x50]
0000747fd7fcef77  vmovaps xmm6, [rsp+0x60]
0000747fd7fcef7d  vmovaps xmm7, [rsp+0x70]
0000747fd7fcef83  vmovaps xmm8, [rsp+0x80]
0000747fd7fcef8c  vmovaps xmm9, [rsp+0x90]
0000747fd7fcef95  vmovaps xmm10, [rsp+0xA0]
0000747fd7fcef9e  vmovaps xmm11, [rsp+0xB0]
0000747fd7fcefa7  vmovaps xmm12, [rsp+0xC0]
0000747fd7fcefb0  vmovaps xmm13, [rsp+0xD0]
0000747fd7fcefb9  vmovaps xmm15, [rsp+0xE0]
0000747fd7fcefc2  add rsp, 0xF0
0000747fd7fcefc9  pop r11
0000747fd7fcefcb  pop r10
0000747fd7fcefcd  pop r9
0000747fd7fcefcf  pop r8
0000747fd7fcefd1  pop rsi
0000747fd7fcefd2  pop rdi
0000747fd7fcefd3  pop rdx
0000747fd7fcefd4  pop rcx
0000747fd7fcefd5  pop rax
0000747fd7fcefd6  add rsp, 0x08
0000747fd7fcefda  jmp 0x0000747FD7FCECAE
0000747fd7fcefdf  call 0x0000747FD7EC34C0
0000747fd7fcefe4  jmp 0x0000747FD7FCECC4
0000747fd7fcefe9  int3
0000747fd7fcefea  nop [rax+rax*1], ax
0000747fd7fceff0  mov rax, [r15+0xF8]
0000747fd7fceff7  lea r14, [rax-0x150]
0000747fd7fceffe  mov [r15+0xF8], r14
0000747fd7fcf005  mov rax, [r15+0x50]
0000747fd7fcf009  lea r12, [rax+0x80]
0000747fd7fcf010  movups xmm1, [r13+r12*1]
0000747fd7fcf016  lea r12, [rax+0x90]
0000747fd7fcf01d  movups xmm15, [r13+r12*1]
0000747fd7fcf023  mov qword ptr [r15+0x48], 0x00
0000747fd7fcf02b  lea r12, [rax+0x40]
0000747fd7fcf02f  movups xmm14, [r13+r12*1]
0000747fd7fcf035  lea r12, [rax+0x50]
0000747fd7fcf039  movups xmm13, [r13+r12*1]
0000747fd7fcf03f  lea r12, [r14+0x120]
0000747fd7fcf046  movq xmm12, qword ptr [r15+0x1C0]
0000747fd7fcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000747fd7fcf058  movq r11, xmm12
0000747fd7fcf05d  movq r10, xmm11
0000747fd7fcf062  mov [r13+r12*1], r11
0000747fd7fcf067  lea r12, [r14+0x128]
0000747fd7fcf06e  mov [r13+r12*1], r10
0000747fd7fcf073  vxorps xmm12, xmm12, xmm12
0000747fd7fcf078  vpbroadcastq xmm12, xmm12
0000747fd7fcf07d  lea r12, [r14+0x100]
0000747fd7fcf084  movq xmm11, qword ptr [r15+0x200]
0000747fd7fcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000747fd7fcf096  movq r11, xmm11
0000747fd7fcf09b  movq r10, xmm10
0000747fd7fcf0a0  mov [r13+r12*1], r11
0000747fd7fcf0a5  lea r12, [r14+0x108]
0000747fd7fcf0ac  mov [r13+r12*1], r10
0000747fd7fcf0b1  lea r12, [r14+0xE0]
0000747fd7fcf0b8  movups [r13+r12*1], xmm15
0000747fd7fcf0be  lea r12, [r14+0xF0]
0000747fd7fcf0c5  movups [r13+r12*1], xmm1
0000747fd7fcf0cb  lea r12, [rax+0xC0]
0000747fd7fcf0d2  movups xmm1, [r13+r12*1]
0000747fd7fcf0d8  lea r12, [rax+0xD0]
0000747fd7fcf0df  movups xmm15, [r13+r12*1]
0000747fd7fcf0e5  lea r12, [r14+0x110]
0000747fd7fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000747fd7fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000747fd7fcf0fe  movq r11, xmm11
0000747fd7fcf103  movq r10, xmm10
0000747fd7fcf108  mov [r13+r12*1], r11
0000747fd7fcf10d  lea r12, [r14+0x118]
0000747fd7fcf114  mov [r13+r12*1], r10
0000747fd7fcf119  movups xmm11, [r13+rax*1]
0000747fd7fcf11f  lea r12, [rax+0x10]
0000747fd7fcf123  movups xmm10, [r13+r12*1]
0000747fd7fcf129  lea r12, [r14+0x130]
0000747fd7fcf130  movq xmm9, qword ptr [r15+0x1A0]
0000747fd7fcf139  movq xmm8, qword ptr [r15+0x190]
0000747fd7fcf142  movq r11, xmm9
0000747fd7fcf147  movq r10, xmm8
0000747fd7fcf14c  mov [r13+r12*1], r11
0000747fd7fcf151  lea r12, [r14+0x138]
0000747fd7fcf158  mov [r13+r12*1], r10
0000747fd7fcf15d  lea r12, [rax+0x140]
0000747fd7fcf164  movups xmm9, [r13+r12*1]
0000747fd7fcf16a  lea r12, [rax+0x150]
0000747fd7fcf171  movups xmm8, [r13+r12*1]
0000747fd7fcf177  lea r12, [r14+0xC0]
0000747fd7fcf17e  movups [r13+r12*1], xmm15
0000747fd7fcf184  lea r12, [r14+0xD0]
0000747fd7fcf18b  movups [r13+r12*1], xmm1
0000747fd7fcf191  lea r12, [rax+0x100]
0000747fd7fcf198  movups xmm1, [r13+r12*1]
0000747fd7fcf19e  lea r12, [rax+0x110]
0000747fd7fcf1a5  movups xmm15, [r13+r12*1]
0000747fd7fcf1ab  lea r12, [r14+0x140]
0000747fd7fcf1b2  mov r11, [r15+0xE8]
0000747fd7fcf1b9  mov [r13+r12*1], r11
0000747fd7fcf1be  lea r12, [rax+0x180]
0000747fd7fcf1c5  movups xmm7, [r13+r12*1]
0000747fd7fcf1cb  lea r12, [rax+0x190]
0000747fd7fcf1d2  movups xmm6, [r13+r12*1]
0000747fd7fcf1d8  lea r12, [rax+0x1C0]
0000747fd7fcf1df  movups xmm5, [r13+r12*1]
0000747fd7fcf1e5  lea r12, [rax+0x1D0]
0000747fd7fcf1ec  movups xmm4, [r13+r12*1]
0000747fd7fcf1f2  lea r12, [r14+0x20]
0000747fd7fcf1f6  movups [r13+r12*1], xmm1
0000747fd7fcf1fc  lea r12, [r14+0x30]
0000747fd7fcf200  movups [r13+r12*1], xmm13
0000747fd7fcf206  lea r12, [rax+0x60]
0000747fd7fcf20a  movups xmm1, [r13+r12*1]
0000747fd7fcf210  lea r12, [rax+0x70]
0000747fd7fcf214  movups xmm13, [r13+r12*1]
0000747fd7fcf21a  lea r12, [rax+0x20]
0000747fd7fcf21e  movups xmm3, [r13+r12*1]
0000747fd7fcf224  lea r12, [rax+0x30]
0000747fd7fcf228  movups xmm2, [r13+r12*1]
0000747fd7fcf22e  movaps [r15+0x1F0], xmm2
0000747fd7fcf236  lea r12, [r14+0x60]
0000747fd7fcf23a  movups [r13+r12*1], xmm11
0000747fd7fcf240  lea r12, [r14+0x70]
0000747fd7fcf244  movups [r13+r12*1], xmm5
0000747fd7fcf24a  lea r12, [rax+0xE0]
0000747fd7fcf251  movups xmm11, [r13+r12*1]
0000747fd7fcf257  lea r12, [rax+0xF0]
0000747fd7fcf25e  movups xmm5, [r13+r12*1]
0000747fd7fcf264  lea r12, [r14+0xA0]
0000747fd7fcf26b  movups [r13+r12*1], xmm13
0000747fd7fcf271  lea r12, [r14+0xB0]
0000747fd7fcf278  movups [r13+r12*1], xmm1
0000747fd7fcf27e  lea r12, [rax+0xA0]
0000747fd7fcf285  movups xmm1, [r13+r12*1]
0000747fd7fcf28b  lea r12, [rax+0xB0]
0000747fd7fcf292  movups xmm13, [r13+r12*1]
0000747fd7fcf298  lea r12, [rax+0x120]
0000747fd7fcf29f  vmovaps [rsp+0x10], xmm1
0000747fd7fcf2a5  movups xmm1, [r13+r12*1]
0000747fd7fcf2ab  lea r12, [rax+0x130]
0000747fd7fcf2b2  vmovaps [rsp+0x20], xmm1
0000747fd7fcf2b8  movups xmm1, [r13+r12*1]
0000747fd7fcf2be  lea r12, [rax+0x160]
0000747fd7fcf2c5  vmovaps [rsp+0x30], xmm1
0000747fd7fcf2cb  movups xmm1, [r13+r12*1]
0000747fd7fcf2d1  lea r12, [rax+0x170]
0000747fd7fcf2d8  vmovaps [rsp+0x40], xmm1
0000747fd7fcf2de  movups xmm1, [r13+r12*1]
0000747fd7fcf2e4  movaps [r15+0x2B0], xmm1
0000747fd7fcf2ec  lea r12, [r14+0x80]
0000747fd7fcf2f3  movups [r13+r12*1], xmm13
0000747fd7fcf2f9  lea r12, [r14+0x90]
0000747fd7fcf300  vmovaps xmm13, [rsp+0x10]
0000747fd7fcf306  movups [r13+r12*1], xmm13
0000747fd7fcf30c  lea r12, [rax+0x1A0]
0000747fd7fcf313  movups xmm13, [r13+r12*1]
0000747fd7fcf319  lea r12, [rax+0x1B0]
0000747fd7fcf320  vmovaps [rsp+0x10], xmm1
0000747fd7fcf326  movups xmm1, [r13+r12*1]
0000747fd7fcf32c  movaps [r15+0x290], xmm13
0000747fd7fcf334  movaps [r15+0x1E0], xmm1
0000747fd7fcf33c  lea r12, [rax+0x1E0]
0000747fd7fcf343  vmovaps [rsp+0x50], xmm1
0000747fd7fcf349  movups xmm1, [r13+r12*1]
0000747fd7fcf34f  lea r12, [rax+0x1F0]
0000747fd7fcf356  vmovaps [rsp+0x60], xmm1
0000747fd7fcf35c  movups xmm1, [r13+r12*1]
0000747fd7fcf362  mov qword ptr [r15+0x50], 0x430920
0000747fd7fcf36a  lea rax, [r14+0x40]
0000747fd7fcf36e  vmovaps [rsp+0x70], xmm1
0000747fd7fcf374  vmovaps xmm1, [rsp+0x40]
0000747fd7fcf37a  movups [r13+rax*1], xmm1
0000747fd7fcf380  lea rax, [r14+0x50]
0000747fd7fcf384  movups [r13+rax*1], xmm10
0000747fd7fcf38a  vmovaps xmm1, [rsp+0x70]
0000747fd7fcf390  movups [r13+r14*1], xmm1
0000747fd7fcf396  lea rax, [r14+0x10]
0000747fd7fcf39a  vmovaps xmm1, [rsp+0x60]
0000747fd7fcf3a0  movups [r13+rax*1], xmm1
0000747fd7fcf3a6  mov rax, [r15+0x40]
0000747fd7fcf3aa  vmovaps [rsp+0x40], xmm3
0000747fd7fcf3b0  vmovaps xmm1, [rsp+0x40]
0000747fd7fcf3b6  por xmm3, xmm1
0000747fd7fcf3ba  vmovaps [rsp+0x40], xmm6
0000747fd7fcf3c0  vmovaps xmm10, [rsp+0x40]
0000747fd7fcf3c6  por xmm6, xmm10
0000747fd7fcf3cb  lea r12, [rax+0x30]
0000747fd7fcf3cf  mov r11, [r13+r12*1]
0000747fd7fcf3d4  lea r12, [rax+0x38]
0000747fd7fcf3d8  mov r10, [r13+r12*1]
0000747fd7fcf3dd  movq xmm10, r11
0000747fd7fcf3e2  vmovaps [rsp+0x40], xmm1
0000747fd7fcf3e8  movq xmm1, r10
0000747fd7fcf3ed  movq xmm10, xmm10
0000747fd7fcf3f2  vmovaps [rsp+0x60], xmm10
0000747fd7fcf3f8  movq xmm10, xmm10
0000747fd7fcf3fd  movaps [r15+0x130], xmm10
0000747fd7fcf405  movq xmm1, xmm1
0000747fd7fcf409  vmovaps [rsp+0x70], xmm1
0000747fd7fcf40f  movq xmm1, xmm1
0000747fd7fcf413  movaps [r15+0x280], xmm1
0000747fd7fcf41b  vmovaps [rsp+0x80], xmm9
0000747fd7fcf424  vmovaps xmm1, [rsp+0x80]
0000747fd7fcf42d  por xmm9, xmm1
0000747fd7fcf432  lea r12, [rax+0x20]
0000747fd7fcf436  mov r11, [r13+r12*1]
0000747fd7fcf43b  lea r12, [rax+0x28]
0000747fd7fcf43f  mov r10, [r13+r12*1]
0000747fd7fcf444  movq xmm1, r11
0000747fd7fcf449  movq xmm10, r10
0000747fd7fcf44e  movq xmm1, xmm1
0000747fd7fcf452  vmovaps [rsp+0x80], xmm1
0000747fd7fcf45b  movq xmm1, xmm1
0000747fd7fcf45f  movaps [r15+0x150], xmm1
0000747fd7fcf467  movq xmm10, xmm10
0000747fd7fcf46c  vmovaps [rsp+0x90], xmm10
0000747fd7fcf475  movq xmm10, xmm10
0000747fd7fcf47a  movaps [r15+0x140], xmm10
0000747fd7fcf482  lea r12, [rax+0x10]
0000747fd7fcf486  mov r11, [r13+r12*1]
0000747fd7fcf48b  lea r12, [rax+0x18]
0000747fd7fcf48f  mov r10, [r13+r12*1]
0000747fd7fcf494  movq xmm1, r11
0000747fd7fcf499  movq xmm10, r10
0000747fd7fcf49e  movq xmm1, xmm1
0000747fd7fcf4a2  vmovaps [rsp+0xA0], xmm1
0000747fd7fcf4ab  movq xmm1, xmm1
0000747fd7fcf4af  movaps [r15+0x170], xmm1
0000747fd7fcf4b7  movq xmm10, xmm10
0000747fd7fcf4bc  vmovaps [rsp+0xB0], xmm10
0000747fd7fcf4c5  movq xmm10, xmm10
0000747fd7fcf4ca  movaps [r15+0x160], xmm10
0000747fd7fcf4d2  mov r12, [r13+rax*1]
0000747fd7fcf4d7  vmovq xmm1, r12
0000747fd7fcf4dc  vpbroadcastq xmm1, xmm1
0000747fd7fcf4e1  lea r12, [rax+0x08]
0000747fd7fcf4e5  mov rax, [r13+r12*1]
0000747fd7fcf4ea  movq xmm10, rax
0000747fd7fcf4ef  movaps [r15+0x230], xmm10
0000747fd7fcf4f7  lea rax, [r14+0x50]
0000747fd7fcf4fb  movups xmm10, [r13+rax*1]
0000747fd7fcf501  lea rax, [r14+0x60]
0000747fd7fcf505  vmovaps [rsp+0xC0], xmm1
0000747fd7fcf50e  movups xmm1, [r13+rax*1]
0000747fd7fcf514  lea rax, [r14+0x30]
0000747fd7fcf518  vmovaps [rsp+0xD0], xmm1
0000747fd7fcf521  movups xmm1, [r13+rax*1]
0000747fd7fcf527  mov qword ptr [r15+0x60], 0x430920
0000747fd7fcf52f  mov qword ptr [r15+0x58], 0x40
0000747fd7fcf537  vmovaps [rsp+0xE0], xmm1
0000747fd7fcf540  vmovaps [rsp+0xF0], xmm15
0000747fd7fcf549  vmovaps xmm15, [rsp+0xC0]
0000747fd7fcf552  vmovaps [rsp+0xC0], xmm14
0000747fd7fcf55b  vmovaps xmm14, [rsp+0x40]
0000747fd7fcf561  vmovaps [rsp+0x40], xmm13
0000747fd7fcf567  movaps xmm1, xmm15
0000747fd7fcf56b  mulpd xmm1, xmm14
0000747fd7fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000747fd7fcf575  ptest xmm13, xmm13
0000747fd7fcf57b  jnz 0x0000747FD7FD0682
0000747fd7fcf581  movq xmm14, qword ptr [r15+0x230]
0000747fd7fcf58a  vmovaps [rsp+0x100], xmm14
0000747fd7fcf593  vpermilpd xmm14, xmm14, 0x00
0000747fd7fcf599  vmovaps [rsp+0x110], xmm1
0000747fd7fcf5a2  vmovaps xmm1, [rsp+0xE0]
0000747fd7fcf5ab  vmovaps [rsp+0xE0], xmm15
0000747fd7fcf5b4  movaps xmm13, xmm1
0000747fd7fcf5b8  mulpd xmm13, xmm14
0000747fd7fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000747fd7fcf5c3  ptest xmm15, xmm15
0000747fd7fcf5c9  jnz 0x0000747FD7FD07C4
0000747fd7fcf5cf  vxorps xmm1, xmm1, xmm1
0000747fd7fcf5d3  vpbroadcastq xmm1, xmm1
0000747fd7fcf5d8  vmovaps xmm14, [rsp+0xE0]
0000747fd7fcf5e1  vmovaps [rsp+0xE0], xmm1
0000747fd7fcf5ea  vmovaps xmm1, [rsp+0xD0]
0000747fd7fcf5f3  vmovaps [rsp+0xD0], xmm13
0000747fd7fcf5fc  movaps xmm15, xmm14
0000747fd7fcf600  mulpd xmm15, xmm1
0000747fd7fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000747fd7fcf60b  ptest xmm13, xmm13
0000747fd7fcf611  jnz 0x0000747FD7FD0907
0000747fd7fcf617  movaps xmm1, xmm14
0000747fd7fcf61b  mulpd xmm1, xmm10
0000747fd7fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000747fd7fcf625  ptest xmm13, xmm13
0000747fd7fcf62b  jnz 0x0000747FD7FD0A4A
0000747fd7fcf631  movaps xmm13, xmm14
0000747fd7fcf635  mulpd xmm13, xmm2
0000747fd7fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000747fd7fcf640  ptest xmm10, xmm10
0000747fd7fcf646  jnz 0x0000747FD7FD0B8C
0000747fd7fcf64c  vmovaps [rsp+0x120], xmm7
0000747fd7fcf655  vmovaps xmm14, [rsp+0x120]
0000747fd7fcf65e  por xmm7, xmm14
0000747fd7fcf663  vmovaps xmm14, [rsp+0xC0]
0000747fd7fcf66c  vmovaps xmm10, [rsp+0xC0]
0000747fd7fcf675  por xmm14, xmm10
0000747fd7fcf67a  vmovaps xmm2, [rsp+0x100]
0000747fd7fcf683  vpermilpd xmm2, xmm2, 0x00
0000747fd7fcf689  vmovaps [rsp+0xC0], xmm1
0000747fd7fcf692  vmovaps [rsp+0x120], xmm15
0000747fd7fcf69b  movaps xmm1, xmm10
0000747fd7fcf69f  mulpd xmm1, xmm2
0000747fd7fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000747fd7fcf6a8  ptest xmm15, xmm15
0000747fd7fcf6ae  jnz 0x0000747FD7FD0CCF
0000747fd7fcf6b4  xor eax, eax
0000747fd7fcf6b6  mov r12d, 0x40
0000747fd7fcf6bc  mov r11d, 0x200
0000747fd7fcf6c2  cmp r12, r11
0000747fd7fcf6c5  cmc
0000747fd7fcf6c6  lahf
0000747fd7fcf6c7  seto al
0000747fd7fcf6ca  mov [r15+0x108], eax
0000747fd7fcf6d1  vmovaps xmm10, [rsp+0x110]
0000747fd7fcf6da  vmovaps xmm2, [rsp+0xE0]
0000747fd7fcf6e3  vmovaps [rsp+0xE0], xmm1
0000747fd7fcf6ec  movaps xmm15, xmm10
0000747fd7fcf6f0  addpd xmm15, xmm2
0000747fd7fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000747fd7fcf6fb  ptest xmm1, xmm1
0000747fd7fcf700  jnz 0x0000747FD7FD0E10
0000747fd7fcf706  vmovaps xmm10, [rsp+0x120]
0000747fd7fcf70f  vmovaps [rsp+0x110], xmm15
0000747fd7fcf718  movaps xmm1, xmm10
0000747fd7fcf71c  addpd xmm1, xmm12
0000747fd7fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000747fd7fcf726  ptest xmm15, xmm15
0000747fd7fcf72c  jnz 0x0000747FD7FD0F53
0000747fd7fcf732  vmovaps xmm10, [rsp+0xC0]
0000747fd7fcf73b  vmovaps [rsp+0xC0], xmm1
0000747fd7fcf744  movaps xmm15, xmm10
0000747fd7fcf748  addpd xmm15, xmm12
0000747fd7fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000747fd7fcf753  ptest xmm1, xmm1
0000747fd7fcf758  jnz 0x0000747FD7FD1095
0000747fd7fcf75e  vmovaps xmm1, [rsp+0x30]
0000747fd7fcf764  vmovaps xmm12, [rsp+0x30]
0000747fd7fcf76a  por xmm1, xmm12
0000747fd7fcf76f  vmovaps xmm12, [rsp+0x20]
0000747fd7fcf775  vmovaps xmm10, [rsp+0x20]
0000747fd7fcf77b  por xmm12, xmm10
0000747fd7fcf780  vmovaps [rsp+0x20], xmm5
0000747fd7fcf786  vmovaps xmm10, [rsp+0x20]
0000747fd7fcf78c  por xmm5, xmm10
0000747fd7fcf791  vmovaps [rsp+0x20], xmm11
0000747fd7fcf797  vmovaps xmm10, [rsp+0x20]
0000747fd7fcf79d  por xmm11, xmm10
0000747fd7fcf7a2  vmovaps [rsp+0x20], xmm4
0000747fd7fcf7a8  vmovaps xmm10, [rsp+0x20]
0000747fd7fcf7ae  por xmm4, xmm10
0000747fd7fcf7b3  vmovaps [rsp+0x20], xmm8
0000747fd7fcf7b9  vmovaps xmm10, [rsp+0x20]
0000747fd7fcf7bf  por xmm8, xmm10
0000747fd7fcf7c4  vmovaps xmm10, [rsp+0xF0]
0000747fd7fcf7cd  vmovaps [rsp+0x20], xmm1
0000747fd7fcf7d3  vmovaps xmm1, [rsp+0xF0]
0000747fd7fcf7dc  por xmm10, xmm1
0000747fd7fcf7e1  lea rax, [r14+0xA0]
0000747fd7fcf7e8  movups xmm1, [r13+rax*1]
0000747fd7fcf7ee  lea rax, [r14+0xB0]
0000747fd7fcf7f5  vmovaps [rsp+0x30], xmm1
0000747fd7fcf7fb  movups xmm1, [r13+rax*1]
0000747fd7fcf801  vmovaps [rsp+0xF0], xmm1
0000747fd7fcf80a  vmovaps [rsp+0x120], xmm15
0000747fd7fcf813  movaps xmm1, xmm13
0000747fd7fcf817  addpd xmm1, xmm2
0000747fd7fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000747fd7fcf820  ptest xmm15, xmm15
0000747fd7fcf826  jnz 0x0000747FD7FD11ED
0000747fd7fcf82c  lea rax, [r14+0xF0]
0000747fd7fcf833  movups xmm15, [r13+rax*1]
0000747fd7fcf839  vmovaps xmm2, [rsp+0xC0]
0000747fd7fcf842  vmovaps [rsp+0xC0], xmm1
0000747fd7fcf84b  vmovaps xmm1, [rsp+0xE0]
0000747fd7fcf854  vmovaps [rsp+0xE0], xmm15
0000747fd7fcf85d  movaps xmm13, xmm2
0000747fd7fcf861  addpd xmm13, xmm1
0000747fd7fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000747fd7fcf86c  ptest xmm15, xmm15
0000747fd7fcf872  jnz 0x0000747FD7FD1338
0000747fd7fcf878  vmovaps xmm15, [rsp+0x120]
0000747fd7fcf881  vmovaps xmm2, [rsp+0xD0]
0000747fd7fcf88a  vmovaps [rsp+0xD0], xmm14
0000747fd7fcf893  movaps xmm1, xmm15
0000747fd7fcf897  addpd xmm1, xmm2
0000747fd7fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000747fd7fcf8a0  ptest xmm14, xmm14
0000747fd7fcf8a6  jnz 0x0000747FD7FD147A
0000747fd7fcf8ac  vmovaps xmm15, [rsp+0x100]
0000747fd7fcf8b5  vpermilpd xmm15, xmm15, 0x00
0000747fd7fcf8bb  vmovaps xmm2, [rsp+0xF0]
0000747fd7fcf8c4  vmovaps [rsp+0xF0], xmm1
0000747fd7fcf8cd  movaps xmm14, xmm2
0000747fd7fcf8d1  mulpd xmm14, xmm15
0000747fd7fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000747fd7fcf8dc  ptest xmm1, xmm1
0000747fd7fcf8e1  jnz 0x0000747FD7FD15BB
0000747fd7fcf8e7  vmovaps xmm1, [rsp+0xA0]
0000747fd7fcf8f0  vpermilpd xmm1, xmm1, 0x00
0000747fd7fcf8f6  vmovaps xmm2, [rsp+0xE0]
0000747fd7fcf8ff  vmovaps [rsp+0xE0], xmm14
0000747fd7fcf908  movaps xmm15, xmm2
0000747fd7fcf90c  mulpd xmm15, xmm1
0000747fd7fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000747fd7fcf917  ptest xmm14, xmm14
0000747fd7fcf91d  jnz 0x0000747FD7FD16FE
0000747fd7fcf923  lea rax, [r14+0xE0]
0000747fd7fcf92a  movups xmm1, [r13+rax*1]
0000747fd7fcf930  vmovaps xmm14, [rsp+0x100]
0000747fd7fcf939  vpermilpd xmm14, xmm14, 0x00
0000747fd7fcf93f  vmovaps [rsp+0x100], xmm1
0000747fd7fcf948  vmovaps xmm1, [rsp+0x30]
0000747fd7fcf94e  vmovaps [rsp+0x30], xmm15
0000747fd7fcf954  movaps xmm2, xmm1
0000747fd7fcf957  mulpd xmm2, xmm14
0000747fd7fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000747fd7fcf961  ptest xmm15, xmm15
0000747fd7fcf967  jnz 0x0000747FD7FD184A
0000747fd7fcf96d  vmovaps [rsp+0x120], xmm10
0000747fd7fcf976  vmovaps xmm1, [rsp+0x120]
0000747fd7fcf97f  por xmm10, xmm1
0000747fd7fcf984  movaps [r15+0x300], xmm10
0000747fd7fcf98c  vmovaps [rsp+0x120], xmm8
0000747fd7fcf995  vmovaps xmm1, [rsp+0x120]
0000747fd7fcf99e  por xmm8, xmm1
0000747fd7fcf9a3  movaps [r15+0x190], xmm8
0000747fd7fcf9ab  vmovaps xmm1, [rsp+0xA0]
0000747fd7fcf9b4  vpermilpd xmm1, xmm1, 0x00
0000747fd7fcf9ba  vmovaps xmm14, [rsp+0x100]
0000747fd7fcf9c3  vmovaps [rsp+0x100], xmm13
0000747fd7fcf9cc  movaps xmm15, xmm14
0000747fd7fcf9d0  mulpd xmm15, xmm1
0000747fd7fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000747fd7fcf9db  ptest xmm13, xmm13
0000747fd7fcf9e1  jnz 0x0000747FD7FD198B
0000747fd7fcf9e7  lea rax, [r14+0x90]
0000747fd7fcf9ee  movups xmm1, [r13+rax*1]
0000747fd7fcf9f4  vmovaps [rsp+0x120], xmm4
0000747fd7fcf9fd  vmovaps xmm14, [rsp+0x120]
0000747fd7fcfa06  por xmm4, xmm14
0000747fd7fcfa0b  movaps [r15+0x1C0], xmm4
0000747fd7fcfa13  vmovaps [rsp+0x120], xmm11
0000747fd7fcfa1c  vmovaps xmm14, [rsp+0x120]
0000747fd7fcfa25  por xmm11, xmm14
0000747fd7fcfa2a  movaps [r15+0x200], xmm11
0000747fd7fcfa32  vmovaps [rsp+0x120], xmm5
0000747fd7fcfa3b  vmovaps xmm14, [rsp+0x120]
0000747fd7fcfa44  por xmm5, xmm14
0000747fd7fcfa49  movaps [r15+0x2D0], xmm5
0000747fd7fcfa51  vmovaps [rsp+0x120], xmm12
0000747fd7fcfa5a  vmovaps xmm14, [rsp+0x120]
0000747fd7fcfa63  por xmm12, xmm14
0000747fd7fcfa68  movaps [r15+0x2E0], xmm12
0000747fd7fcfa70  vmovaps xmm13, [rsp+0x110]
0000747fd7fcfa79  vmovaps [rsp+0x110], xmm1
0000747fd7fcfa82  vmovaps xmm1, [rsp+0xE0]
0000747fd7fcfa8b  vmovaps [rsp+0xE0], xmm15
0000747fd7fcfa94  movaps xmm14, xmm13
0000747fd7fcfa98  addpd xmm14, xmm1
0000747fd7fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000747fd7fcfaa3  ptest xmm15, xmm15
0000747fd7fcfaa9  jnz 0x0000747FD7FD1AD8
0000747fd7fcfaaf  vmovaps xmm1, [rsp+0xA0]
0000747fd7fcfab8  vpermilpd xmm1, xmm1, 0x00
0000747fd7fcfabe  vmovaps xmm13, [rsp+0x110]
0000747fd7fcfac7  vmovaps [rsp+0x110], xmm14
0000747fd7fcfad0  movaps xmm15, xmm13
0000747fd7fcfad4  mulpd xmm15, xmm1
0000747fd7fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000747fd7fcfadf  ptest xmm14, xmm14
0000747fd7fcfae5  jnz 0x0000747FD7FD1C1B
0000747fd7fcfaeb  lea rax, [r14+0x80]
0000747fd7fcfaf2  movups xmm1, [r13+rax*1]
0000747fd7fcfaf8  vmovaps xmm13, [rsp+0xC0]
0000747fd7fcfb01  vmovaps [rsp+0xC0], xmm1
0000747fd7fcfb0a  movaps xmm14, xmm13
0000747fd7fcfb0e  addpd xmm14, xmm2
0000747fd7fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000747fd7fcfb19  ptest xmm1, xmm1
0000747fd7fcfb1e  jnz 0x0000747FD7FD1D68
0000747fd7fcfb24  vmovaps xmm13, [rsp+0x100]
0000747fd7fcfb2d  vmovaps xmm2, [rsp+0x30]
0000747fd7fcfb33  vmovaps [rsp+0x30], xmm15
0000747fd7fcfb39  movaps xmm1, xmm13
0000747fd7fcfb3d  addpd xmm1, xmm2
0000747fd7fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000747fd7fcfb46  ptest xmm15, xmm15
0000747fd7fcfb4c  jnz 0x0000747FD7FD1EAB
0000747fd7fcfb52  vmovaps xmm15, [rsp+0x20]
0000747fd7fcfb58  vmovaps xmm13, [rsp+0x20]
0000747fd7fcfb5e  por xmm15, xmm13
0000747fd7fcfb63  movaps [r15+0x2F0], xmm15
0000747fd7fcfb6b  vmovaps xmm13, [rsp+0xA0]
0000747fd7fcfb74  vpermilpd xmm13, xmm13, 0x00
0000747fd7fcfb7a  vmovaps [rsp+0x20], xmm1
0000747fd7fcfb80  vmovaps xmm1, [rsp+0xC0]
0000747fd7fcfb89  vmovaps [rsp+0xA0], xmm15
0000747fd7fcfb92  movaps xmm2, xmm1
0000747fd7fcfb95  mulpd xmm2, xmm13
0000747fd7fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000747fd7fcfb9f  ptest xmm15, xmm15
0000747fd7fcfba5  jnz 0x0000747FD7FD1FEC
0000747fd7fcfbab  lea rax, [r14+0xD0]
0000747fd7fcfbb2  movups xmm1, [r13+rax*1]
0000747fd7fcfbb8  vmovaps xmm13, [rsp+0xF0]
0000747fd7fcfbc1  vmovaps [rsp+0xC0], xmm1
0000747fd7fcfbca  vmovaps xmm1, [rsp+0xE0]
0000747fd7fcfbd3  vmovaps [rsp+0xE0], xmm14
0000747fd7fcfbdc  movaps xmm15, xmm13
0000747fd7fcfbe0  addpd xmm15, xmm1
0000747fd7fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000747fd7fcfbeb  ptest xmm14, xmm14
0000747fd7fcfbf1  jnz 0x0000747FD7FD2137
0000747fd7fcfbf7  vmovaps xmm1, [rsp+0xB0]
0000747fd7fcfc00  vpermilpd xmm1, xmm1, 0x00
0000747fd7fcfc06  movaps xmm14, xmm11
0000747fd7fcfc0a  mulpd xmm14, xmm1
0000747fd7fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000747fd7fcfc15  ptest xmm13, xmm13
0000747fd7fcfc1b  jnz 0x0000747FD7FD227A
0000747fd7fcfc21  movaps [r15+0x260], xmm14
0000747fd7fcfc29  vxorps xmm1, xmm1, xmm1
0000747fd7fcfc2d  vpbroadcastq xmm1, xmm1
0000747fd7fcfc32  movaps [r15+0x1B0], xmm1
0000747fd7fcfc3a  vmovaps xmm1, [rsp+0xB0]
0000747fd7fcfc43  vpermilpd xmm1, xmm1, 0x00
0000747fd7fcfc49  vmovaps xmm11, [rsp+0xC0]
0000747fd7fcfc52  vmovaps [rsp+0xC0], xmm15
0000747fd7fcfc5b  movaps xmm13, xmm11
0000747fd7fcfc5f  mulpd xmm13, xmm1
0000747fd7fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000747fd7fcfc6a  ptest xmm15, xmm15
0000747fd7fcfc70  jnz 0x0000747FD7FD23BD
0000747fd7fcfc76  lea rax, [r14+0xC0]
0000747fd7fcfc7d  movups xmm1, [r13+rax*1]
0000747fd7fcfc83  vmovaps xmm11, [rsp+0x110]
0000747fd7fcfc8c  vmovaps [rsp+0xF0], xmm1
0000747fd7fcfc95  vmovaps xmm1, [rsp+0x30]
0000747fd7fcfc9b  vmovaps [rsp+0x30], xmm14
0000747fd7fcfca1  movaps xmm15, xmm11
0000747fd7fcfca5  addpd xmm15, xmm1
0000747fd7fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000747fd7fcfcb0  ptest xmm14, xmm14
0000747fd7fcfcb6  jnz 0x0000747FD7FD250A
0000747fd7fcfcbc  vmovaps [rsp+0x100], xmm9
0000747fd7fcfcc5  vmovaps xmm1, [rsp+0x100]
0000747fd7fcfcce  por xmm9, xmm1
0000747fd7fcfcd3  movaps [r15+0x270], xmm9
0000747fd7fcfcdb  vmovaps [rsp+0x100], xmm6
0000747fd7fcfce4  vmovaps xmm1, [rsp+0x100]
0000747fd7fcfced  por xmm6, xmm1
0000747fd7fcfcf1  movaps [r15+0x1A0], xmm6
0000747fd7fcfcf9  vmovaps xmm14, [rsp+0xB0]
0000747fd7fcfd02  vpermilpd xmm14, xmm14, 0x00
0000747fd7fcfd08  vmovaps xmm6, [rsp+0xF0]
0000747fd7fcfd11  vmovaps [rsp+0xF0], xmm1
0000747fd7fcfd1a  movaps xmm11, xmm6
0000747fd7fcfd1e  mulpd xmm11, xmm14
0000747fd7fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000747fd7fcfd29  ptest xmm1, xmm1
0000747fd7fcfd2e  jnz 0x0000747FD7FD264D
0000747fd7fcfd34  lea rax, [r14+0x20]
0000747fd7fcfd38  movups xmm1, [r13+rax*1]
0000747fd7fcfd3e  movaps [r15+0x110], xmm1
0000747fd7fcfd46  vmovaps xmm6, [rsp+0xE0]
0000747fd7fcfd4f  vmovaps [rsp+0xE0], xmm1
0000747fd7fcfd58  movaps xmm14, xmm6
0000747fd7fcfd5c  addpd xmm14, xmm2
0000747fd7fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000747fd7fcfd67  ptest xmm1, xmm1
0000747fd7fcfd6c  jnz 0x0000747FD7FD279A
0000747fd7fcfd72  vmovaps xmm1, [rsp+0xB0]
0000747fd7fcfd7b  vpermilpd xmm1, xmm1, 0x00
0000747fd7fcfd81  movaps xmm6, xmm5
0000747fd7fcfd84  mulpd xmm6, xmm1
0000747fd7fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000747fd7fcfd8d  ptest xmm2, xmm2
0000747fd7fcfd92  jnz 0x0000747FD7FD28DC
0000747fd7fcfd98  vmovaps xmm5, [rsp+0x20]
0000747fd7fcfd9e  movaps xmm1, xmm5
0000747fd7fcfda1  addpd xmm1, xmm13
0000747fd7fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000747fd7fcfdab  ptest xmm2, xmm2
0000747fd7fcfdb0  jnz 0x0000747FD7FD2A1C
0000747fd7fcfdb6  vmovaps xmm13, [rsp+0x80]
0000747fd7fcfdbf  vpermilpd xmm13, xmm13, 0x00
0000747fd7fcfdc5  vmovaps xmm2, [rsp+0xE0]
0000747fd7fcfdce  vmovaps [rsp+0x20], xmm1
0000747fd7fcfdd4  movaps xmm5, xmm2
0000747fd7fcfdd7  mulpd xmm5, xmm13
0000747fd7fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000747fd7fcfde1  ptest xmm1, xmm1
0000747fd7fcfde6  jnz 0x0000747FD7FD2B5D
0000747fd7fcfdec  vmovaps xmm1, [rsp+0x80]
0000747fd7fcfdf5  vpermilpd xmm1, xmm1, 0x00
0000747fd7fcfdfb  movaps xmm13, xmm10
0000747fd7fcfdff  mulpd xmm13, xmm1
0000747fd7fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000747fd7fcfe0a  ptest xmm2, xmm2
0000747fd7fcfe0f  jnz 0x0000747FD7FD2C9E
0000747fd7fcfe15  vmovaps xmm10, [rsp+0x30]
0000747fd7fcfe1b  movaps xmm1, xmm15
0000747fd7fcfe1f  addpd xmm1, xmm10
0000747fd7fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000747fd7fcfe29  ptest xmm2, xmm2
0000747fd7fcfe2e  jnz 0x0000747FD7FD2DE1
0000747fd7fcfe34  vmovaps xmm10, [rsp+0xC0]
0000747fd7fcfe3d  movaps xmm15, xmm10
0000747fd7fcfe41  addpd xmm15, xmm11
0000747fd7fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000747fd7fcfe4c  ptest xmm2, xmm2
0000747fd7fcfe51  jnz 0x0000747FD7FD2F23
0000747fd7fcfe57  vmovaps xmm11, [rsp+0x80]
0000747fd7fcfe60  vpermilpd xmm11, xmm11, 0x00
0000747fd7fcfe66  movaps xmm10, xmm12
0000747fd7fcfe6a  mulpd xmm10, xmm11
0000747fd7fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000747fd7fcfe75  ptest xmm2, xmm2
0000747fd7fcfe7a  jnz 0x0000747FD7FD3067
0000747fd7fcfe80  vmovaps xmm12, [rsp+0x80]
0000747fd7fcfe89  vpermilpd xmm12, xmm12, 0x00
0000747fd7fcfe8f  vmovaps xmm2, [rsp+0xA0]
0000747fd7fcfe98  vmovaps [rsp+0x30], xmm1
0000747fd7fcfe9e  movaps xmm11, xmm2
0000747fd7fcfea2  mulpd xmm11, xmm12
0000747fd7fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000747fd7fcfead  ptest xmm1, xmm1
0000747fd7fcfeb2  jnz 0x0000747FD7FD31AB
0000747fd7fcfeb8  movaps xmm1, xmm14
0000747fd7fcfebc  addpd xmm1, xmm6
0000747fd7fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000747fd7fcfec5  ptest xmm12, xmm12
0000747fd7fcfecb  jnz 0x0000747FD7FD32EE
0000747fd7fcfed1  vmovaps xmm12, [rsp+0x20]
0000747fd7fcfed7  movaps xmm14, xmm12
0000747fd7fcfedb  addpd xmm14, xmm5
0000747fd7fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000747fd7fcfee6  ptest xmm6, xmm6
0000747fd7fcfeeb  jnz 0x0000747FD7FD342F
0000747fd7fcfef1  vmovaps xmm12, [rsp+0x90]
0000747fd7fcfefa  vpermilpd xmm12, xmm12, 0x00
0000747fd7fcff00  movaps xmm6, xmm9
0000747fd7fcff04  mulpd xmm6, xmm12
0000747fd7fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000747fd7fcff0e  ptest xmm5, xmm5
0000747fd7fcff13  jnz 0x0000747FD7FD3572
0000747fd7fcff19  movaps xmm12, xmm15
0000747fd7fcff1d  addpd xmm12, xmm13
0000747fd7fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000747fd7fcff28  ptest xmm9, xmm9
0000747fd7fcff2e  jnz 0x0000747FD7FD36B4
0000747fd7fcff34  vmovaps xmm13, [rsp+0x30]
0000747fd7fcff3a  movaps xmm15, xmm13
0000747fd7fcff3e  addpd xmm15, xmm10
0000747fd7fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000747fd7fcff49  ptest xmm9, xmm9
0000747fd7fcff4f  jnz 0x0000747FD7FD37F8
0000747fd7fcff55  vmovaps xmm13, [rsp+0xD0]
0000747fd7fcff5e  vmovaps xmm10, [rsp+0xD0]
0000747fd7fcff67  por xmm13, xmm10
0000747fd7fcff6c  movaps [r15+0x250], xmm13
0000747fd7fcff74  vmovaps [rsp+0x20], xmm7
0000747fd7fcff7a  vmovaps xmm13, [rsp+0x20]
0000747fd7fcff80  por xmm7, xmm13
0000747fd7fcff85  movaps [r15+0x2A0], xmm7
0000747fd7fcff8d  vmovaps [rsp+0x20], xmm3
0000747fd7fcff93  vmovaps xmm13, [rsp+0x20]
0000747fd7fcff99  por xmm3, xmm13
0000747fd7fcff9e  movaps [r15+0x1D0], xmm3
0000747fd7fcffa6  lea rax, [r14+0x40]
0000747fd7fcffaa  movups xmm13, [r13+rax*1]
0000747fd7fcffb0  movaps [r15+0x2C0], xmm13
0000747fd7fcffb8  vmovaps xmm10, [rsp+0x90]
0000747fd7fcffc1  vpermilpd xmm10, xmm10, 0x00
0000747fd7fcffc7  movaps xmm9, xmm8
0000747fd7fcffcb  mulpd xmm9, xmm10
0000747fd7fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000747fd7fcffd6  ptest xmm5, xmm5
0000747fd7fcffdb  jnz 0x0000747FD7FD3946
0000747fd7fcffe1  movaps xmm10, xmm1
0000747fd7fcffe5  addpd xmm10, xmm11
0000747fd7fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000747fd7fcfff0  ptest xmm8, xmm8
0000747fd7fcfff6  jnz 0x0000747FD7FD3A8A
0000747fd7fcfffc  movaps xmm1, xmm14
0000747fd7fd0000  addpd xmm1, xmm6
0000747fd7fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000747fd7fd0009  ptest xmm11, xmm11
0000747fd7fd000f  jnz 0x0000747FD7FD3BCD
0000747fd7fd0015  vmovaps xmm14, [rsp+0x90]
0000747fd7fd001e  vpermilpd xmm14, xmm14, 0x00
0000747fd7fd0024  movaps xmm11, xmm13
0000747fd7fd0028  mulpd xmm11, xmm14
0000747fd7fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000747fd7fd0033  ptest xmm8, xmm8
0000747fd7fd0039  jnz 0x0000747FD7FD3D0E
0000747fd7fd003f  vmovaps xmm14, [rsp+0x90]
0000747fd7fd0048  vpermilpd xmm14, xmm14, 0x00
0000747fd7fd004e  vmovaps xmm8, [rsp+0x10]
0000747fd7fd0054  movaps xmm13, xmm8
0000747fd7fd0058  mulpd xmm13, xmm14
0000747fd7fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000747fd7fd0063  ptest xmm6, xmm6
0000747fd7fd0068  jnz 0x0000747FD7FD3E52
0000747fd7fd006e  vmovaps xmm14, [rsp+0x60]
0000747fd7fd0074  vpermilpd xmm14, xmm14, 0x00
0000747fd7fd007a  movaps xmm8, xmm7
0000747fd7fd007e  mulpd xmm8, xmm14
0000747fd7fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000747fd7fd0089  ptest xmm6, xmm6
0000747fd7fd008e  jnz 0x0000747FD7FD3F96
0000747fd7fd0094  movaps xmm14, xmm12
0000747fd7fd0098  addpd xmm14, xmm9
0000747fd7fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000747fd7fd00a3  ptest xmm7, xmm7
0000747fd7fd00a8  jnz 0x0000747FD7FD40D9
0000747fd7fd00ae  vmovaps xmm12, [rsp+0x60]
0000747fd7fd00b4  vpermilpd xmm12, xmm12, 0x00
0000747fd7fd00ba  vmovaps xmm7, [rsp+0xF0]
0000747fd7fd00c3  movaps xmm9, xmm7
0000747fd7fd00c7  mulpd xmm9, xmm12
0000747fd7fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000747fd7fd00d2  ptest xmm6, xmm6
0000747fd7fd00d7  jnz 0x0000747FD7FD421D
0000747fd7fd00dd  movaps xmm12, xmm15
0000747fd7fd00e1  addpd xmm12, xmm11
0000747fd7fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000747fd7fd00ec  ptest xmm7, xmm7
0000747fd7fd00f1  jnz 0x0000747FD7FD4360
0000747fd7fd00f7  vmovaps xmm15, [rsp+0x60]
0000747fd7fd00fd  vpermilpd xmm15, xmm15, 0x00
0000747fd7fd0103  vmovaps xmm7, [rsp+0x40]
0000747fd7fd0109  movaps xmm11, xmm7
0000747fd7fd010d  mulpd xmm11, xmm15
0000747fd7fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000747fd7fd0118  ptest xmm6, xmm6
0000747fd7fd011d  jnz 0x0000747FD7FD44A4
0000747fd7fd0123  movaps xmm15, xmm10
0000747fd7fd0127  addpd xmm15, xmm13
0000747fd7fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000747fd7fd0132  ptest xmm7, xmm7
0000747fd7fd0137  jnz 0x0000747FD7FD45E7
0000747fd7fd013d  vmovaps xmm13, [rsp+0x60]
0000747fd7fd0143  vpermilpd xmm13, xmm13, 0x00
0000747fd7fd0149  vmovaps xmm7, [rsp+0x50]
0000747fd7fd014f  movaps xmm10, xmm7
0000747fd7fd0153  mulpd xmm10, xmm13
0000747fd7fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000747fd7fd015e  ptest xmm6, xmm6
0000747fd7fd0163  jnz 0x0000747FD7FD472B
0000747fd7fd0169  movaps xmm13, xmm1
0000747fd7fd016d  addpd xmm13, xmm8
0000747fd7fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000747fd7fd0178  ptest xmm7, xmm7
0000747fd7fd017d  jnz 0x0000747FD7FD486E
0000747fd7fd0183  lea rax, [r14+0x70]
0000747fd7fd0187  movups xmm1, [r13+rax*1]
0000747fd7fd018d  movaps [r15+0x240], xmm1
0000747fd7fd0195  movaps xmm8, xmm14
0000747fd7fd0199  addpd xmm8, xmm9
0000747fd7fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000747fd7fd01a4  ptest xmm7, xmm7
0000747fd7fd01a9  jnz 0x0000747FD7FD49BB
0000747fd7fd01af  movaps [r15+0x170], xmm8
0000747fd7fd01b7  vmovaps xmm14, [rsp+0x70]
0000747fd7fd01bd  vpermilpd xmm14, xmm14, 0x00
0000747fd7fd01c3  movaps xmm9, xmm1
0000747fd7fd01c7  mulpd xmm9, xmm14
0000747fd7fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000747fd7fd01d2  ptest xmm7, xmm7
0000747fd7fd01d7  jnz 0x0000747FD7FD4AFF
0000747fd7fd01dd  vmovaps xmm1, [rsp+0x70]
0000747fd7fd01e3  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd01e9  movaps xmm14, xmm4
0000747fd7fd01ed  mulpd xmm14, xmm1
0000747fd7fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000747fd7fd01f8  ptest xmm7, xmm7
0000747fd7fd01fd  jnz 0x0000747FD7FD4C42
0000747fd7fd0203  movaps [r15+0x180], xmm14
0000747fd7fd020b  movaps xmm1, xmm12
0000747fd7fd020f  addpd xmm1, xmm11
0000747fd7fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000747fd7fd0219  ptest xmm7, xmm7
0000747fd7fd021e  jnz 0x0000747FD7FD4D84
0000747fd7fd0224  movaps [r15+0x210], xmm1
0000747fd7fd022c  movups xmm12, [r13+r14*1]
0000747fd7fd0232  lea rax, [r14+0x10]
0000747fd7fd0236  movups xmm11, [r13+rax*1]
0000747fd7fd023c  movaps [r15+0x230], xmm11
0000747fd7fd0244  movaps xmm7, xmm15
0000747fd7fd0248  addpd xmm7, xmm10
0000747fd7fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000747fd7fd0252  ptest xmm6, xmm6
0000747fd7fd0257  jnz 0x0000747FD7FD4EDA
0000747fd7fd025d  movaps [r15+0x130], xmm7
0000747fd7fd0265  vmovaps xmm15, [rsp+0x70]
0000747fd7fd026b  vpermilpd xmm15, xmm15, 0x00
0000747fd7fd0271  movaps xmm10, xmm11
0000747fd7fd0275  mulpd xmm10, xmm15
0000747fd7fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000747fd7fd0280  ptest xmm6, xmm6
0000747fd7fd0285  jnz 0x0000747FD7FD501C
0000747fd7fd028b  movaps [r15+0x220], xmm10
0000747fd7fd0293  vmovaps xmm15, [rsp+0x70]
0000747fd7fd0299  vpermilpd xmm15, xmm15, 0x00
0000747fd7fd029f  movaps xmm11, xmm12
0000747fd7fd02a3  mulpd xmm11, xmm15
0000747fd7fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000747fd7fd02ae  ptest xmm6, xmm6
0000747fd7fd02b3  jnz 0x0000747FD7FD5160
0000747fd7fd02b9  movaps xmm15, xmm13
0000747fd7fd02bd  addpd xmm15, xmm9
0000747fd7fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000747fd7fd02c8  ptest xmm12, xmm12
0000747fd7fd02ce  jnz 0x0000747FD7FD52A4
0000747fd7fd02d4  movaps [r15+0x140], xmm15
0000747fd7fd02dc  movaps xmm13, xmm8
0000747fd7fd02e0  addpd xmm13, xmm14
0000747fd7fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000747fd7fd02eb  ptest xmm12, xmm12
0000747fd7fd02f1  jnz 0x0000747FD7FD53E8
0000747fd7fd02f7  movaps [r15+0x150], xmm13
0000747fd7fd02ff  movaps xmm14, xmm1
0000747fd7fd0303  addpd xmm14, xmm10
0000747fd7fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000747fd7fd030e  ptest xmm12, xmm12
0000747fd7fd0314  jnz 0x0000747FD7FD552C
0000747fd7fd031a  movaps [r15+0x160], xmm14
0000747fd7fd0322  movaps xmm1, xmm7
0000747fd7fd0325  addpd xmm1, xmm11
0000747fd7fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000747fd7fd032f  ptest xmm12, xmm12
0000747fd7fd0335  jnz 0x0000747FD7FD566F
0000747fd7fd033b  movaps [r15+0x120], xmm1
0000747fd7fd0343  mov eax, 0x430920
0000747fd7fd0348  movups [r13+rax*1], xmm15
0000747fd7fd034e  mov eax, 0x430930
0000747fd7fd0353  movups [r13+rax*1], xmm13
0000747fd7fd0359  mov eax, 0x430940
0000747fd7fd035e  movups [r13+rax*1], xmm14
0000747fd7fd0364  mov eax, 0x430950
0000747fd7fd0369  movups [r13+rax*1], xmm1
0000747fd7fd036f  mov eax, [r15+0x108]
0000747fd7fd0376  sahf
0000747fd7fd0377  jnz 0x0000747FD7FD03A9
0000747fd7fd0379  cmp dword ptr [r15+0x318], 0x00
0000747fd7fd0381  jz 0x0000747FD7FDB900
0000747fd7fd0387  nop [rax+rax*1], ax
0000747fd7fd0390  nop [rax+rax*1], eax
0000747fd7fd0398  mov eax, 0x410444
0000747fd7fd039d  mov [r15+0x100], rax
0000747fd7fd03a4  jmp 0x0000747FD7DFE110
0000747fd7fd03a9  cmp dword ptr [r15+0x318], 0x00
0000747fd7fd03b1  jz 0x0000747FD7FD57E0
0000747fd7fd03b7  nop [rax+rax*1], ax
0000747fd7fd03c0  nop [rax+rax*1], eax
0000747fd7fd03c8  mov eax, 0x410278
0000747fd7fd03cd  mov [r15+0x100], rax
0000747fd7fd03d4  jmp 0x0000747FD7DFE110
0000747fd7fd03d9  int3
0000747fd7fd03da  call 0x0000747FD7EB52F0
0000747fd7fd03df  jmp 0x0000747FD7FCF016
0000747fd7fd03e4  call 0x0000747FD7EC4620
0000747fd7fd03e9  jmp 0x0000747FD7FCF023
0000747fd7fd03ee  call 0x0000747FD7EC33A0
0000747fd7fd03f3  jmp 0x0000747FD7FCF035
0000747fd7fd03f8  call 0x0000747FD7EC2120
0000747fd7fd03fd  jmp 0x0000747FD7FCF03F
0000747fd7fd0402  call 0x0000747FD7EC0860
0000747fd7fd0407  jmp 0x0000747FD7FCF067
0000747fd7fd040c  call 0x0000747FD7EBF5F0
0000747fd7fd0411  jmp 0x0000747FD7FCF073
0000747fd7fd0416  call 0x0000747FD7EC0860
0000747fd7fd041b  jmp 0x0000747FD7FCF0A5
0000747fd7fd0420  call 0x0000747FD7EBF5F0
0000747fd7fd0425  jmp 0x0000747FD7FCF0B1
0000747fd7fd042a  call 0x0000747FD7EC4740
0000747fd7fd042f  jmp 0x0000747FD7FCF0BE
0000747fd7fd0434  call 0x0000747FD7EB5400
0000747fd7fd0439  jmp 0x0000747FD7FCF0CB
0000747fd7fd043e  call 0x0000747FD7EB52F0
0000747fd7fd0443  jmp 0x0000747FD7FCF0D8
0000747fd7fd0448  call 0x0000747FD7EC4620
0000747fd7fd044d  jmp 0x0000747FD7FCF0E5
0000747fd7fd0452  call 0x0000747FD7EC0860
0000747fd7fd0457  jmp 0x0000747FD7FCF10D
0000747fd7fd045c  call 0x0000747FD7EBF5F0
0000747fd7fd0461  jmp 0x0000747FD7FCF119
0000747fd7fd0466  call 0x0000747FD7E09D70
0000747fd7fd046b  jmp 0x0000747FD7FCF11F
0000747fd7fd0470  call 0x0000747FD7EBE9C0
0000747fd7fd0475  jmp 0x0000747FD7FCF129
0000747fd7fd047a  call 0x0000747FD7EC0860
0000747fd7fd047f  jmp 0x0000747FD7FCF151
0000747fd7fd0484  call 0x0000747FD7EBF5F0
0000747fd7fd0489  jmp 0x0000747FD7FCF15D
0000747fd7fd048e  call 0x0000747FD7EBD750
0000747fd7fd0493  jmp 0x0000747FD7FCF16A
0000747fd7fd0498  call 0x0000747FD7EBC4E0
0000747fd7fd049d  jmp 0x0000747FD7FCF177
0000747fd7fd04a2  call 0x0000747FD7EC4740
0000747fd7fd04a7  jmp 0x0000747FD7FCF184
0000747fd7fd04ac  call 0x0000747FD7EB5400
0000747fd7fd04b1  jmp 0x0000747FD7FCF191
0000747fd7fd04b6  call 0x0000747FD7EB52F0
0000747fd7fd04bb  jmp 0x0000747FD7FCF19E
0000747fd7fd04c0  call 0x0000747FD7EC4620
0000747fd7fd04c5  jmp 0x0000747FD7FCF1AB
0000747fd7fd04ca  call 0x0000747FD7EC0860
0000747fd7fd04cf  jmp 0x0000747FD7FCF1BE
0000747fd7fd04d4  call 0x0000747FD7EBB270
0000747fd7fd04d9  jmp 0x0000747FD7FCF1CB
0000747fd7fd04de  call 0x0000747FD7EBA000
0000747fd7fd04e3  jmp 0x0000747FD7FCF1D8
0000747fd7fd04e8  call 0x0000747FD7EB8D90
0000747fd7fd04ed  jmp 0x0000747FD7FCF1E5
0000747fd7fd04f2  call 0x0000747FD7EB8A20
0000747fd7fd04f7  jmp 0x0000747FD7FCF1F2
0000747fd7fd04fc  call 0x0000747FD7EB5400
0000747fd7fd0501  jmp 0x0000747FD7FCF1FC
0000747fd7fd0506  call 0x0000747FD7EC2240
0000747fd7fd050b  jmp 0x0000747FD7FCF206
0000747fd7fd0510  call 0x0000747FD7EB52F0
0000747fd7fd0515  jmp 0x0000747FD7FCF210
0000747fd7fd051a  call 0x0000747FD7EC2120
0000747fd7fd051f  jmp 0x0000747FD7FCF21A
0000747fd7fd0524  call 0x0000747FD7EB77B0
0000747fd7fd0529  jmp 0x0000747FD7FCF224
0000747fd7fd052e  call 0x0000747FD7EB6550
0000747fd7fd0533  jmp 0x0000747FD7FCF22E
0000747fd7fd0538  call 0x0000747FD7EBFD50
0000747fd7fd053d  jmp 0x0000747FD7FCF240
0000747fd7fd0542  call 0x0000747FD7EB8EA0
0000747fd7fd0547  jmp 0x0000747FD7FCF24A
0000747fd7fd054c  call 0x0000747FD7EBFC30
0000747fd7fd0551  jmp 0x0000747FD7FCF257
0000747fd7fd0556  call 0x0000747FD7EB8D90
0000747fd7fd055b  jmp 0x0000747FD7FCF264
0000747fd7fd0560  call 0x0000747FD7EC2240
0000747fd7fd0565  jmp 0x0000747FD7FCF271
0000747fd7fd056a  call 0x0000747FD7EB5400
0000747fd7fd056f  jmp 0x0000747FD7FCF27E
0000747fd7fd0574  call 0x0000747FD7EB52F0
0000747fd7fd0579  jmp 0x0000747FD7FCF28B
0000747fd7fd057e  call 0x0000747FD7EC2120
0000747fd7fd0583  jmp 0x0000747FD7FCF298
0000747fd7fd0588  call 0x0000747FD7EB52F0
0000747fd7fd058d  jmp 0x0000747FD7FCF2AB
0000747fd7fd0592  call 0x0000747FD7EB52F0
0000747fd7fd0597  jmp 0x0000747FD7FCF2BE
0000747fd7fd059c  call 0x0000747FD7EB52F0
0000747fd7fd05a1  jmp 0x0000747FD7FCF2D1
0000747fd7fd05a6  call 0x0000747FD7EB52F0
0000747fd7fd05ab  jmp 0x0000747FD7FCF2E4
0000747fd7fd05b0  call 0x0000747FD7EC2240
0000747fd7fd05b5  jmp 0x0000747FD7FCF2F9
0000747fd7fd05ba  call 0x0000747FD7EC2240
0000747fd7fd05bf  jmp 0x0000747FD7FCF30C
0000747fd7fd05c4  call 0x0000747FD7EC2120
0000747fd7fd05c9  jmp 0x0000747FD7FCF319
0000747fd7fd05ce  call 0x0000747FD7EB52F0
0000747fd7fd05d3  jmp 0x0000747FD7FCF32C
0000747fd7fd05d8  call 0x0000747FD7EB52F0
0000747fd7fd05dd  jmp 0x0000747FD7FCF34F
0000747fd7fd05e2  call 0x0000747FD7EB52F0
0000747fd7fd05e7  jmp 0x0000747FD7FCF362
0000747fd7fd05ec  call 0x0000747FD7DFF540
0000747fd7fd05f1  jmp 0x0000747FD7FCF380
0000747fd7fd05f6  call 0x0000747FD7E08C20
0000747fd7fd05fb  jmp 0x0000747FD7FCF38A
0000747fd7fd0600  call 0x0000747FD7ED6600
0000747fd7fd0605  jmp 0x0000747FD7FCF396
0000747fd7fd060a  call 0x0000747FD7DFF540
0000747fd7fd060f  jmp 0x0000747FD7FCF3A6
0000747fd7fd0614  call 0x0000747FD7EC0370
0000747fd7fd0619  jmp 0x0000747FD7FCF3D4
0000747fd7fd061e  call 0x0000747FD7EBF100
0000747fd7fd0623  jmp 0x0000747FD7FCF3DD
0000747fd7fd0628  call 0x0000747FD7EC0370
0000747fd7fd062d  jmp 0x0000747FD7FCF43B
0000747fd7fd0632  call 0x0000747FD7EBF100
0000747fd7fd0637  jmp 0x0000747FD7FCF444
0000747fd7fd063c  call 0x0000747FD7EC0370
0000747fd7fd0641  jmp 0x0000747FD7FCF48B
0000747fd7fd0646  call 0x0000747FD7EBF100
0000747fd7fd064b  jmp 0x0000747FD7FCF494
0000747fd7fd0650  call 0x0000747FD7E0B720
0000747fd7fd0655  jmp 0x0000747FD7FCF4D7
0000747fd7fd065a  call 0x0000747FD7EB47C0
0000747fd7fd065f  jmp 0x0000747FD7FCF4EA
0000747fd7fd0664  call 0x0000747FD7E08B00
0000747fd7fd0669  jmp 0x0000747FD7FCF501
0000747fd7fd066e  call 0x0000747FD7DFF430
0000747fd7fd0673  jmp 0x0000747FD7FCF514
0000747fd7fd0678  call 0x0000747FD7DFF430
0000747fd7fd067d  jmp 0x0000747FD7FCF527
0000747fd7fd0682  sub rsp, 0x08
0000747fd7fd0686  push rax
0000747fd7fd0687  push rcx
0000747fd7fd0688  push rdx
0000747fd7fd0689  push rdi
0000747fd7fd068a  push rsi
0000747fd7fd068b  push r8
0000747fd7fd068d  push r9
0000747fd7fd068f  push r10
0000747fd7fd0691  push r11
0000747fd7fd0693  sub rsp, 0xF0
0000747fd7fd069a  vmovaps [rsp], xmm0
0000747fd7fd069f  vmovaps [rsp+0x10], xmm2
0000747fd7fd06a5  vmovaps [rsp+0x20], xmm3
0000747fd7fd06ab  vmovaps [rsp+0x30], xmm4
0000747fd7fd06b1  vmovaps [rsp+0x40], xmm5
0000747fd7fd06b7  vmovaps [rsp+0x50], xmm6
0000747fd7fd06bd  vmovaps [rsp+0x60], xmm7
0000747fd7fd06c3  vmovaps [rsp+0x70], xmm8
0000747fd7fd06c9  vmovaps [rsp+0x80], xmm9
0000747fd7fd06d2  vmovaps [rsp+0x90], xmm10
0000747fd7fd06db  vmovaps [rsp+0xA0], xmm11
0000747fd7fd06e4  vmovaps [rsp+0xB0], xmm12
0000747fd7fd06ed  vmovaps [rsp+0xC0], xmm13
0000747fd7fd06f6  vmovaps [rsp+0xD0], xmm14
0000747fd7fd06ff  vmovaps [rsp+0xE0], xmm15
0000747fd7fd0708  sub rsp, 0x30
0000747fd7fd070c  movaps [rsp], xmm1
0000747fd7fd0710  movaps [rsp+0x10], xmm15
0000747fd7fd0716  movaps [rsp+0x20], xmm14
0000747fd7fd071c  lea rdi, [rsp]
0000747fd7fd0720  mov esi, 0x00
0000747fd7fd0725  mov rax, 0x6055A0B6E530
0000747fd7fd072f  call rax
0000747fd7fd0731  movaps xmm1, [rsp]
0000747fd7fd0735  add rsp, 0x30
0000747fd7fd0739  vmovaps xmm0, [rsp]
0000747fd7fd073e  vmovaps xmm2, [rsp+0x10]
0000747fd7fd0744  vmovaps xmm3, [rsp+0x20]
0000747fd7fd074a  vmovaps xmm4, [rsp+0x30]
0000747fd7fd0750  vmovaps xmm5, [rsp+0x40]
0000747fd7fd0756  vmovaps xmm6, [rsp+0x50]
0000747fd7fd075c  vmovaps xmm7, [rsp+0x60]
0000747fd7fd0762  vmovaps xmm8, [rsp+0x70]
0000747fd7fd0768  vmovaps xmm9, [rsp+0x80]
0000747fd7fd0771  vmovaps xmm10, [rsp+0x90]
0000747fd7fd077a  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd0783  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd078c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd0795  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd079e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd07a7  add rsp, 0xF0
0000747fd7fd07ae  pop r11
0000747fd7fd07b0  pop r10
0000747fd7fd07b2  pop r9
0000747fd7fd07b4  pop r8
0000747fd7fd07b6  pop rsi
0000747fd7fd07b7  pop rdi
0000747fd7fd07b8  pop rdx
0000747fd7fd07b9  pop rcx
0000747fd7fd07ba  pop rax
0000747fd7fd07bb  add rsp, 0x08
0000747fd7fd07bf  jmp 0x0000747FD7FCF581
0000747fd7fd07c4  sub rsp, 0x08
0000747fd7fd07c8  push rax
0000747fd7fd07c9  push rcx
0000747fd7fd07ca  push rdx
0000747fd7fd07cb  push rdi
0000747fd7fd07cc  push rsi
0000747fd7fd07cd  push r8
0000747fd7fd07cf  push r9
0000747fd7fd07d1  push r10
0000747fd7fd07d3  push r11
0000747fd7fd07d5  sub rsp, 0xF0
0000747fd7fd07dc  vmovaps [rsp], xmm0
0000747fd7fd07e1  vmovaps [rsp+0x10], xmm1
0000747fd7fd07e7  vmovaps [rsp+0x20], xmm2
0000747fd7fd07ed  vmovaps [rsp+0x30], xmm3
0000747fd7fd07f3  vmovaps [rsp+0x40], xmm4
0000747fd7fd07f9  vmovaps [rsp+0x50], xmm5
0000747fd7fd07ff  vmovaps [rsp+0x60], xmm6
0000747fd7fd0805  vmovaps [rsp+0x70], xmm7
0000747fd7fd080b  vmovaps [rsp+0x80], xmm8
0000747fd7fd0814  vmovaps [rsp+0x90], xmm9
0000747fd7fd081d  vmovaps [rsp+0xA0], xmm10
0000747fd7fd0826  vmovaps [rsp+0xB0], xmm11
0000747fd7fd082f  vmovaps [rsp+0xC0], xmm12
0000747fd7fd0838  vmovaps [rsp+0xD0], xmm14
0000747fd7fd0841  vmovaps [rsp+0xE0], xmm15
0000747fd7fd084a  sub rsp, 0x30
0000747fd7fd084e  movaps [rsp], xmm13
0000747fd7fd0853  movaps [rsp+0x10], xmm1
0000747fd7fd0858  movaps [rsp+0x20], xmm14
0000747fd7fd085e  lea rdi, [rsp]
0000747fd7fd0862  mov esi, 0x00
0000747fd7fd0867  mov rax, 0x6055A0B6E530
0000747fd7fd0871  call rax
0000747fd7fd0873  movaps xmm13, [rsp]
0000747fd7fd0878  add rsp, 0x30
0000747fd7fd087c  vmovaps xmm0, [rsp]
0000747fd7fd0881  vmovaps xmm1, [rsp+0x10]
0000747fd7fd0887  vmovaps xmm2, [rsp+0x20]
0000747fd7fd088d  vmovaps xmm3, [rsp+0x30]
0000747fd7fd0893  vmovaps xmm4, [rsp+0x40]
0000747fd7fd0899  vmovaps xmm5, [rsp+0x50]
0000747fd7fd089f  vmovaps xmm6, [rsp+0x60]
0000747fd7fd08a5  vmovaps xmm7, [rsp+0x70]
0000747fd7fd08ab  vmovaps xmm8, [rsp+0x80]
0000747fd7fd08b4  vmovaps xmm9, [rsp+0x90]
0000747fd7fd08bd  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd08c6  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd08cf  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd08d8  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd08e1  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd08ea  add rsp, 0xF0
0000747fd7fd08f1  pop r11
0000747fd7fd08f3  pop r10
0000747fd7fd08f5  pop r9
0000747fd7fd08f7  pop r8
0000747fd7fd08f9  pop rsi
0000747fd7fd08fa  pop rdi
0000747fd7fd08fb  pop rdx
0000747fd7fd08fc  pop rcx
0000747fd7fd08fd  pop rax
0000747fd7fd08fe  add rsp, 0x08
0000747fd7fd0902  jmp 0x0000747FD7FCF5CF
0000747fd7fd0907  sub rsp, 0x08
0000747fd7fd090b  push rax
0000747fd7fd090c  push rcx
0000747fd7fd090d  push rdx
0000747fd7fd090e  push rdi
0000747fd7fd090f  push rsi
0000747fd7fd0910  push r8
0000747fd7fd0912  push r9
0000747fd7fd0914  push r10
0000747fd7fd0916  push r11
0000747fd7fd0918  sub rsp, 0xF0
0000747fd7fd091f  vmovaps [rsp], xmm0
0000747fd7fd0924  vmovaps [rsp+0x10], xmm1
0000747fd7fd092a  vmovaps [rsp+0x20], xmm2
0000747fd7fd0930  vmovaps [rsp+0x30], xmm3
0000747fd7fd0936  vmovaps [rsp+0x40], xmm4
0000747fd7fd093c  vmovaps [rsp+0x50], xmm5
0000747fd7fd0942  vmovaps [rsp+0x60], xmm6
0000747fd7fd0948  vmovaps [rsp+0x70], xmm7
0000747fd7fd094e  vmovaps [rsp+0x80], xmm8
0000747fd7fd0957  vmovaps [rsp+0x90], xmm9
0000747fd7fd0960  vmovaps [rsp+0xA0], xmm10
0000747fd7fd0969  vmovaps [rsp+0xB0], xmm11
0000747fd7fd0972  vmovaps [rsp+0xC0], xmm12
0000747fd7fd097b  vmovaps [rsp+0xD0], xmm13
0000747fd7fd0984  vmovaps [rsp+0xE0], xmm14
0000747fd7fd098d  sub rsp, 0x30
0000747fd7fd0991  movaps [rsp], xmm15
0000747fd7fd0996  movaps [rsp+0x10], xmm14
0000747fd7fd099c  movaps [rsp+0x20], xmm1
0000747fd7fd09a1  lea rdi, [rsp]
0000747fd7fd09a5  mov esi, 0x00
0000747fd7fd09aa  mov rax, 0x6055A0B6E530
0000747fd7fd09b4  call rax
0000747fd7fd09b6  movaps xmm15, [rsp]
0000747fd7fd09bb  add rsp, 0x30
0000747fd7fd09bf  vmovaps xmm0, [rsp]
0000747fd7fd09c4  vmovaps xmm1, [rsp+0x10]
0000747fd7fd09ca  vmovaps xmm2, [rsp+0x20]
0000747fd7fd09d0  vmovaps xmm3, [rsp+0x30]
0000747fd7fd09d6  vmovaps xmm4, [rsp+0x40]
0000747fd7fd09dc  vmovaps xmm5, [rsp+0x50]
0000747fd7fd09e2  vmovaps xmm6, [rsp+0x60]
0000747fd7fd09e8  vmovaps xmm7, [rsp+0x70]
0000747fd7fd09ee  vmovaps xmm8, [rsp+0x80]
0000747fd7fd09f7  vmovaps xmm9, [rsp+0x90]
0000747fd7fd0a00  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd0a09  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd0a12  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd0a1b  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd0a24  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd0a2d  add rsp, 0xF0
0000747fd7fd0a34  pop r11
0000747fd7fd0a36  pop r10
0000747fd7fd0a38  pop r9
0000747fd7fd0a3a  pop r8
0000747fd7fd0a3c  pop rsi
0000747fd7fd0a3d  pop rdi
0000747fd7fd0a3e  pop rdx
0000747fd7fd0a3f  pop rcx
0000747fd7fd0a40  pop rax
0000747fd7fd0a41  add rsp, 0x08
0000747fd7fd0a45  jmp 0x0000747FD7FCF617
0000747fd7fd0a4a  sub rsp, 0x08
0000747fd7fd0a4e  push rax
0000747fd7fd0a4f  push rcx
0000747fd7fd0a50  push rdx
0000747fd7fd0a51  push rdi
0000747fd7fd0a52  push rsi
0000747fd7fd0a53  push r8
0000747fd7fd0a55  push r9
0000747fd7fd0a57  push r10
0000747fd7fd0a59  push r11
0000747fd7fd0a5b  sub rsp, 0xF0
0000747fd7fd0a62  vmovaps [rsp], xmm0
0000747fd7fd0a67  vmovaps [rsp+0x10], xmm2
0000747fd7fd0a6d  vmovaps [rsp+0x20], xmm3
0000747fd7fd0a73  vmovaps [rsp+0x30], xmm4
0000747fd7fd0a79  vmovaps [rsp+0x40], xmm5
0000747fd7fd0a7f  vmovaps [rsp+0x50], xmm6
0000747fd7fd0a85  vmovaps [rsp+0x60], xmm7
0000747fd7fd0a8b  vmovaps [rsp+0x70], xmm8
0000747fd7fd0a91  vmovaps [rsp+0x80], xmm9
0000747fd7fd0a9a  vmovaps [rsp+0x90], xmm10
0000747fd7fd0aa3  vmovaps [rsp+0xA0], xmm11
0000747fd7fd0aac  vmovaps [rsp+0xB0], xmm12
0000747fd7fd0ab5  vmovaps [rsp+0xC0], xmm13
0000747fd7fd0abe  vmovaps [rsp+0xD0], xmm14
0000747fd7fd0ac7  vmovaps [rsp+0xE0], xmm15
0000747fd7fd0ad0  sub rsp, 0x30
0000747fd7fd0ad4  movaps [rsp], xmm1
0000747fd7fd0ad8  movaps [rsp+0x10], xmm14
0000747fd7fd0ade  movaps [rsp+0x20], xmm10
0000747fd7fd0ae4  lea rdi, [rsp]
0000747fd7fd0ae8  mov esi, 0x00
0000747fd7fd0aed  mov rax, 0x6055A0B6E530
0000747fd7fd0af7  call rax
0000747fd7fd0af9  movaps xmm1, [rsp]
0000747fd7fd0afd  add rsp, 0x30
0000747fd7fd0b01  vmovaps xmm0, [rsp]
0000747fd7fd0b06  vmovaps xmm2, [rsp+0x10]
0000747fd7fd0b0c  vmovaps xmm3, [rsp+0x20]
0000747fd7fd0b12  vmovaps xmm4, [rsp+0x30]
0000747fd7fd0b18  vmovaps xmm5, [rsp+0x40]
0000747fd7fd0b1e  vmovaps xmm6, [rsp+0x50]
0000747fd7fd0b24  vmovaps xmm7, [rsp+0x60]
0000747fd7fd0b2a  vmovaps xmm8, [rsp+0x70]
0000747fd7fd0b30  vmovaps xmm9, [rsp+0x80]
0000747fd7fd0b39  vmovaps xmm10, [rsp+0x90]
0000747fd7fd0b42  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd0b4b  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd0b54  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd0b5d  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd0b66  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd0b6f  add rsp, 0xF0
0000747fd7fd0b76  pop r11
0000747fd7fd0b78  pop r10
0000747fd7fd0b7a  pop r9
0000747fd7fd0b7c  pop r8
0000747fd7fd0b7e  pop rsi
0000747fd7fd0b7f  pop rdi
0000747fd7fd0b80  pop rdx
0000747fd7fd0b81  pop rcx
0000747fd7fd0b82  pop rax
0000747fd7fd0b83  add rsp, 0x08
0000747fd7fd0b87  jmp 0x0000747FD7FCF631
0000747fd7fd0b8c  sub rsp, 0x08
0000747fd7fd0b90  push rax
0000747fd7fd0b91  push rcx
0000747fd7fd0b92  push rdx
0000747fd7fd0b93  push rdi
0000747fd7fd0b94  push rsi
0000747fd7fd0b95  push r8
0000747fd7fd0b97  push r9
0000747fd7fd0b99  push r10
0000747fd7fd0b9b  push r11
0000747fd7fd0b9d  sub rsp, 0xF0
0000747fd7fd0ba4  vmovaps [rsp], xmm0
0000747fd7fd0ba9  vmovaps [rsp+0x10], xmm1
0000747fd7fd0baf  vmovaps [rsp+0x20], xmm2
0000747fd7fd0bb5  vmovaps [rsp+0x30], xmm3
0000747fd7fd0bbb  vmovaps [rsp+0x40], xmm4
0000747fd7fd0bc1  vmovaps [rsp+0x50], xmm5
0000747fd7fd0bc7  vmovaps [rsp+0x60], xmm6
0000747fd7fd0bcd  vmovaps [rsp+0x70], xmm7
0000747fd7fd0bd3  vmovaps [rsp+0x80], xmm8
0000747fd7fd0bdc  vmovaps [rsp+0x90], xmm9
0000747fd7fd0be5  vmovaps [rsp+0xA0], xmm10
0000747fd7fd0bee  vmovaps [rsp+0xB0], xmm11
0000747fd7fd0bf7  vmovaps [rsp+0xC0], xmm12
0000747fd7fd0c00  vmovaps [rsp+0xD0], xmm14
0000747fd7fd0c09  vmovaps [rsp+0xE0], xmm15
0000747fd7fd0c12  sub rsp, 0x30
0000747fd7fd0c16  movaps [rsp], xmm13
0000747fd7fd0c1b  movaps [rsp+0x10], xmm14
0000747fd7fd0c21  movaps [rsp+0x20], xmm2
0000747fd7fd0c26  lea rdi, [rsp]
0000747fd7fd0c2a  mov esi, 0x00
0000747fd7fd0c2f  mov rax, 0x6055A0B6E530
0000747fd7fd0c39  call rax
0000747fd7fd0c3b  movaps xmm13, [rsp]
0000747fd7fd0c40  add rsp, 0x30
0000747fd7fd0c44  vmovaps xmm0, [rsp]
0000747fd7fd0c49  vmovaps xmm1, [rsp+0x10]
0000747fd7fd0c4f  vmovaps xmm2, [rsp+0x20]
0000747fd7fd0c55  vmovaps xmm3, [rsp+0x30]
0000747fd7fd0c5b  vmovaps xmm4, [rsp+0x40]
0000747fd7fd0c61  vmovaps xmm5, [rsp+0x50]
0000747fd7fd0c67  vmovaps xmm6, [rsp+0x60]
0000747fd7fd0c6d  vmovaps xmm7, [rsp+0x70]
0000747fd7fd0c73  vmovaps xmm8, [rsp+0x80]
0000747fd7fd0c7c  vmovaps xmm9, [rsp+0x90]
0000747fd7fd0c85  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd0c8e  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd0c97  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd0ca0  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd0ca9  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd0cb2  add rsp, 0xF0
0000747fd7fd0cb9  pop r11
0000747fd7fd0cbb  pop r10
0000747fd7fd0cbd  pop r9
0000747fd7fd0cbf  pop r8
0000747fd7fd0cc1  pop rsi
0000747fd7fd0cc2  pop rdi
0000747fd7fd0cc3  pop rdx
0000747fd7fd0cc4  pop rcx
0000747fd7fd0cc5  pop rax
0000747fd7fd0cc6  add rsp, 0x08
0000747fd7fd0cca  jmp 0x0000747FD7FCF64C
0000747fd7fd0ccf  sub rsp, 0x08
0000747fd7fd0cd3  push rax
0000747fd7fd0cd4  push rcx
0000747fd7fd0cd5  push rdx
0000747fd7fd0cd6  push rdi
0000747fd7fd0cd7  push rsi
0000747fd7fd0cd8  push r8
0000747fd7fd0cda  push r9
0000747fd7fd0cdc  push r10
0000747fd7fd0cde  push r11
0000747fd7fd0ce0  sub rsp, 0xF0
0000747fd7fd0ce7  vmovaps [rsp], xmm0
0000747fd7fd0cec  vmovaps [rsp+0x10], xmm2
0000747fd7fd0cf2  vmovaps [rsp+0x20], xmm3
0000747fd7fd0cf8  vmovaps [rsp+0x30], xmm4
0000747fd7fd0cfe  vmovaps [rsp+0x40], xmm5
0000747fd7fd0d04  vmovaps [rsp+0x50], xmm6
0000747fd7fd0d0a  vmovaps [rsp+0x60], xmm7
0000747fd7fd0d10  vmovaps [rsp+0x70], xmm8
0000747fd7fd0d16  vmovaps [rsp+0x80], xmm9
0000747fd7fd0d1f  vmovaps [rsp+0x90], xmm10
0000747fd7fd0d28  vmovaps [rsp+0xA0], xmm11
0000747fd7fd0d31  vmovaps [rsp+0xB0], xmm12
0000747fd7fd0d3a  vmovaps [rsp+0xC0], xmm13
0000747fd7fd0d43  vmovaps [rsp+0xD0], xmm14
0000747fd7fd0d4c  vmovaps [rsp+0xE0], xmm15
0000747fd7fd0d55  sub rsp, 0x30
0000747fd7fd0d59  movaps [rsp], xmm1
0000747fd7fd0d5d  movaps [rsp+0x10], xmm10
0000747fd7fd0d63  movaps [rsp+0x20], xmm2
0000747fd7fd0d68  lea rdi, [rsp]
0000747fd7fd0d6c  mov esi, 0x00
0000747fd7fd0d71  mov rax, 0x6055A0B6E530
0000747fd7fd0d7b  call rax
0000747fd7fd0d7d  movaps xmm1, [rsp]
0000747fd7fd0d81  add rsp, 0x30
0000747fd7fd0d85  vmovaps xmm0, [rsp]
0000747fd7fd0d8a  vmovaps xmm2, [rsp+0x10]
0000747fd7fd0d90  vmovaps xmm3, [rsp+0x20]
0000747fd7fd0d96  vmovaps xmm4, [rsp+0x30]
0000747fd7fd0d9c  vmovaps xmm5, [rsp+0x40]
0000747fd7fd0da2  vmovaps xmm6, [rsp+0x50]
0000747fd7fd0da8  vmovaps xmm7, [rsp+0x60]
0000747fd7fd0dae  vmovaps xmm8, [rsp+0x70]
0000747fd7fd0db4  vmovaps xmm9, [rsp+0x80]
0000747fd7fd0dbd  vmovaps xmm10, [rsp+0x90]
0000747fd7fd0dc6  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd0dcf  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd0dd8  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd0de1  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd0dea  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd0df3  add rsp, 0xF0
0000747fd7fd0dfa  pop r11
0000747fd7fd0dfc  pop r10
0000747fd7fd0dfe  pop r9
0000747fd7fd0e00  pop r8
0000747fd7fd0e02  pop rsi
0000747fd7fd0e03  pop rdi
0000747fd7fd0e04  pop rdx
0000747fd7fd0e05  pop rcx
0000747fd7fd0e06  pop rax
0000747fd7fd0e07  add rsp, 0x08
0000747fd7fd0e0b  jmp 0x0000747FD7FCF6B4
0000747fd7fd0e10  sub rsp, 0x08
0000747fd7fd0e14  push rax
0000747fd7fd0e15  push rcx
0000747fd7fd0e16  push rdx
0000747fd7fd0e17  push rdi
0000747fd7fd0e18  push rsi
0000747fd7fd0e19  push r8
0000747fd7fd0e1b  push r9
0000747fd7fd0e1d  push r10
0000747fd7fd0e1f  push r11
0000747fd7fd0e21  sub rsp, 0xF0
0000747fd7fd0e28  vmovaps [rsp], xmm0
0000747fd7fd0e2d  vmovaps [rsp+0x10], xmm1
0000747fd7fd0e33  vmovaps [rsp+0x20], xmm2
0000747fd7fd0e39  vmovaps [rsp+0x30], xmm3
0000747fd7fd0e3f  vmovaps [rsp+0x40], xmm4
0000747fd7fd0e45  vmovaps [rsp+0x50], xmm5
0000747fd7fd0e4b  vmovaps [rsp+0x60], xmm6
0000747fd7fd0e51  vmovaps [rsp+0x70], xmm7
0000747fd7fd0e57  vmovaps [rsp+0x80], xmm8
0000747fd7fd0e60  vmovaps [rsp+0x90], xmm9
0000747fd7fd0e69  vmovaps [rsp+0xA0], xmm10
0000747fd7fd0e72  vmovaps [rsp+0xB0], xmm11
0000747fd7fd0e7b  vmovaps [rsp+0xC0], xmm12
0000747fd7fd0e84  vmovaps [rsp+0xD0], xmm13
0000747fd7fd0e8d  vmovaps [rsp+0xE0], xmm14
0000747fd7fd0e96  sub rsp, 0x30
0000747fd7fd0e9a  movaps [rsp], xmm15
0000747fd7fd0e9f  movaps [rsp+0x10], xmm10
0000747fd7fd0ea5  movaps [rsp+0x20], xmm2
0000747fd7fd0eaa  lea rdi, [rsp]
0000747fd7fd0eae  mov esi, 0x00
0000747fd7fd0eb3  mov rax, 0x6055A0B6E530
0000747fd7fd0ebd  call rax
0000747fd7fd0ebf  movaps xmm15, [rsp]
0000747fd7fd0ec4  add rsp, 0x30
0000747fd7fd0ec8  vmovaps xmm0, [rsp]
0000747fd7fd0ecd  vmovaps xmm1, [rsp+0x10]
0000747fd7fd0ed3  vmovaps xmm2, [rsp+0x20]
0000747fd7fd0ed9  vmovaps xmm3, [rsp+0x30]
0000747fd7fd0edf  vmovaps xmm4, [rsp+0x40]
0000747fd7fd0ee5  vmovaps xmm5, [rsp+0x50]
0000747fd7fd0eeb  vmovaps xmm6, [rsp+0x60]
0000747fd7fd0ef1  vmovaps xmm7, [rsp+0x70]
0000747fd7fd0ef7  vmovaps xmm8, [rsp+0x80]
0000747fd7fd0f00  vmovaps xmm9, [rsp+0x90]
0000747fd7fd0f09  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd0f12  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd0f1b  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd0f24  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd0f2d  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd0f36  add rsp, 0xF0
0000747fd7fd0f3d  pop r11
0000747fd7fd0f3f  pop r10
0000747fd7fd0f41  pop r9
0000747fd7fd0f43  pop r8
0000747fd7fd0f45  pop rsi
0000747fd7fd0f46  pop rdi
0000747fd7fd0f47  pop rdx
0000747fd7fd0f48  pop rcx
0000747fd7fd0f49  pop rax
0000747fd7fd0f4a  add rsp, 0x08
0000747fd7fd0f4e  jmp 0x0000747FD7FCF706
0000747fd7fd0f53  sub rsp, 0x08
0000747fd7fd0f57  push rax
0000747fd7fd0f58  push rcx
0000747fd7fd0f59  push rdx
0000747fd7fd0f5a  push rdi
0000747fd7fd0f5b  push rsi
0000747fd7fd0f5c  push r8
0000747fd7fd0f5e  push r9
0000747fd7fd0f60  push r10
0000747fd7fd0f62  push r11
0000747fd7fd0f64  sub rsp, 0xF0
0000747fd7fd0f6b  vmovaps [rsp], xmm0
0000747fd7fd0f70  vmovaps [rsp+0x10], xmm2
0000747fd7fd0f76  vmovaps [rsp+0x20], xmm3
0000747fd7fd0f7c  vmovaps [rsp+0x30], xmm4
0000747fd7fd0f82  vmovaps [rsp+0x40], xmm5
0000747fd7fd0f88  vmovaps [rsp+0x50], xmm6
0000747fd7fd0f8e  vmovaps [rsp+0x60], xmm7
0000747fd7fd0f94  vmovaps [rsp+0x70], xmm8
0000747fd7fd0f9a  vmovaps [rsp+0x80], xmm9
0000747fd7fd0fa3  vmovaps [rsp+0x90], xmm10
0000747fd7fd0fac  vmovaps [rsp+0xA0], xmm11
0000747fd7fd0fb5  vmovaps [rsp+0xB0], xmm12
0000747fd7fd0fbe  vmovaps [rsp+0xC0], xmm13
0000747fd7fd0fc7  vmovaps [rsp+0xD0], xmm14
0000747fd7fd0fd0  vmovaps [rsp+0xE0], xmm15
0000747fd7fd0fd9  sub rsp, 0x30
0000747fd7fd0fdd  movaps [rsp], xmm1
0000747fd7fd0fe1  movaps [rsp+0x10], xmm10
0000747fd7fd0fe7  movaps [rsp+0x20], xmm12
0000747fd7fd0fed  lea rdi, [rsp]
0000747fd7fd0ff1  mov esi, 0x00
0000747fd7fd0ff6  mov rax, 0x6055A0B6E530
0000747fd7fd1000  call rax
0000747fd7fd1002  movaps xmm1, [rsp]
0000747fd7fd1006  add rsp, 0x30
0000747fd7fd100a  vmovaps xmm0, [rsp]
0000747fd7fd100f  vmovaps xmm2, [rsp+0x10]
0000747fd7fd1015  vmovaps xmm3, [rsp+0x20]
0000747fd7fd101b  vmovaps xmm4, [rsp+0x30]
0000747fd7fd1021  vmovaps xmm5, [rsp+0x40]
0000747fd7fd1027  vmovaps xmm6, [rsp+0x50]
0000747fd7fd102d  vmovaps xmm7, [rsp+0x60]
0000747fd7fd1033  vmovaps xmm8, [rsp+0x70]
0000747fd7fd1039  vmovaps xmm9, [rsp+0x80]
0000747fd7fd1042  vmovaps xmm10, [rsp+0x90]
0000747fd7fd104b  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd1054  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd105d  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd1066  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd106f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd1078  add rsp, 0xF0
0000747fd7fd107f  pop r11
0000747fd7fd1081  pop r10
0000747fd7fd1083  pop r9
0000747fd7fd1085  pop r8
0000747fd7fd1087  pop rsi
0000747fd7fd1088  pop rdi
0000747fd7fd1089  pop rdx
0000747fd7fd108a  pop rcx
0000747fd7fd108b  pop rax
0000747fd7fd108c  add rsp, 0x08
0000747fd7fd1090  jmp 0x0000747FD7FCF732
0000747fd7fd1095  sub rsp, 0x08
0000747fd7fd1099  push rax
0000747fd7fd109a  push rcx
0000747fd7fd109b  push rdx
0000747fd7fd109c  push rdi
0000747fd7fd109d  push rsi
0000747fd7fd109e  push r8
0000747fd7fd10a0  push r9
0000747fd7fd10a2  push r10
0000747fd7fd10a4  push r11
0000747fd7fd10a6  sub rsp, 0xF0
0000747fd7fd10ad  vmovaps [rsp], xmm0
0000747fd7fd10b2  vmovaps [rsp+0x10], xmm1
0000747fd7fd10b8  vmovaps [rsp+0x20], xmm2
0000747fd7fd10be  vmovaps [rsp+0x30], xmm3
0000747fd7fd10c4  vmovaps [rsp+0x40], xmm4
0000747fd7fd10ca  vmovaps [rsp+0x50], xmm5
0000747fd7fd10d0  vmovaps [rsp+0x60], xmm6
0000747fd7fd10d6  vmovaps [rsp+0x70], xmm7
0000747fd7fd10dc  vmovaps [rsp+0x80], xmm8
0000747fd7fd10e5  vmovaps [rsp+0x90], xmm9
0000747fd7fd10ee  vmovaps [rsp+0xA0], xmm10
0000747fd7fd10f7  vmovaps [rsp+0xB0], xmm11
0000747fd7fd1100  vmovaps [rsp+0xC0], xmm12
0000747fd7fd1109  vmovaps [rsp+0xD0], xmm13
0000747fd7fd1112  vmovaps [rsp+0xE0], xmm14
0000747fd7fd111b  sub rsp, 0x30
0000747fd7fd111f  movaps [rsp], xmm15
0000747fd7fd1124  movaps [rsp+0x10], xmm10
0000747fd7fd112a  movaps [rsp+0x20], xmm12
0000747fd7fd1130  lea rdi, [rsp]
0000747fd7fd1134  mov esi, 0x00
0000747fd7fd1139  mov rax, 0x6055A0B6E530
0000747fd7fd1143  call rax
0000747fd7fd1145  movaps xmm15, [rsp]
0000747fd7fd114a  add rsp, 0x30
0000747fd7fd114e  vmovaps xmm0, [rsp]
0000747fd7fd1153  vmovaps xmm1, [rsp+0x10]
0000747fd7fd1159  vmovaps xmm2, [rsp+0x20]
0000747fd7fd115f  vmovaps xmm3, [rsp+0x30]
0000747fd7fd1165  vmovaps xmm4, [rsp+0x40]
0000747fd7fd116b  vmovaps xmm5, [rsp+0x50]
0000747fd7fd1171  vmovaps xmm6, [rsp+0x60]
0000747fd7fd1177  vmovaps xmm7, [rsp+0x70]
0000747fd7fd117d  vmovaps xmm8, [rsp+0x80]
0000747fd7fd1186  vmovaps xmm9, [rsp+0x90]
0000747fd7fd118f  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd1198  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd11a1  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd11aa  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd11b3  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd11bc  add rsp, 0xF0
0000747fd7fd11c3  pop r11
0000747fd7fd11c5  pop r10
0000747fd7fd11c7  pop r9
0000747fd7fd11c9  pop r8
0000747fd7fd11cb  pop rsi
0000747fd7fd11cc  pop rdi
0000747fd7fd11cd  pop rdx
0000747fd7fd11ce  pop rcx
0000747fd7fd11cf  pop rax
0000747fd7fd11d0  add rsp, 0x08
0000747fd7fd11d4  jmp 0x0000747FD7FCF75E
0000747fd7fd11d9  call 0x0000747FD7DFF430
0000747fd7fd11de  jmp 0x0000747FD7FCF7EE
0000747fd7fd11e3  call 0x0000747FD7DFF430
0000747fd7fd11e8  jmp 0x0000747FD7FCF801
0000747fd7fd11ed  sub rsp, 0x08
0000747fd7fd11f1  push rax
0000747fd7fd11f2  push rcx
0000747fd7fd11f3  push rdx
0000747fd7fd11f4  push rdi
0000747fd7fd11f5  push rsi
0000747fd7fd11f6  push r8
0000747fd7fd11f8  push r9
0000747fd7fd11fa  push r10
0000747fd7fd11fc  push r11
0000747fd7fd11fe  sub rsp, 0xF0
0000747fd7fd1205  vmovaps [rsp], xmm0
0000747fd7fd120a  vmovaps [rsp+0x10], xmm2
0000747fd7fd1210  vmovaps [rsp+0x20], xmm3
0000747fd7fd1216  vmovaps [rsp+0x30], xmm4
0000747fd7fd121c  vmovaps [rsp+0x40], xmm5
0000747fd7fd1222  vmovaps [rsp+0x50], xmm6
0000747fd7fd1228  vmovaps [rsp+0x60], xmm7
0000747fd7fd122e  vmovaps [rsp+0x70], xmm8
0000747fd7fd1234  vmovaps [rsp+0x80], xmm9
0000747fd7fd123d  vmovaps [rsp+0x90], xmm10
0000747fd7fd1246  vmovaps [rsp+0xA0], xmm11
0000747fd7fd124f  vmovaps [rsp+0xB0], xmm12
0000747fd7fd1258  vmovaps [rsp+0xC0], xmm13
0000747fd7fd1261  vmovaps [rsp+0xD0], xmm14
0000747fd7fd126a  vmovaps [rsp+0xE0], xmm15
0000747fd7fd1273  sub rsp, 0x30
0000747fd7fd1277  movaps [rsp], xmm1
0000747fd7fd127b  movaps [rsp+0x10], xmm13
0000747fd7fd1281  movaps [rsp+0x20], xmm2
0000747fd7fd1286  lea rdi, [rsp]
0000747fd7fd128a  mov esi, 0x00
0000747fd7fd128f  mov rax, 0x6055A0B6E530
0000747fd7fd1299  call rax
0000747fd7fd129b  movaps xmm1, [rsp]
0000747fd7fd129f  add rsp, 0x30
0000747fd7fd12a3  vmovaps xmm0, [rsp]
0000747fd7fd12a8  vmovaps xmm2, [rsp+0x10]
0000747fd7fd12ae  vmovaps xmm3, [rsp+0x20]
0000747fd7fd12b4  vmovaps xmm4, [rsp+0x30]
0000747fd7fd12ba  vmovaps xmm5, [rsp+0x40]
0000747fd7fd12c0  vmovaps xmm6, [rsp+0x50]
0000747fd7fd12c6  vmovaps xmm7, [rsp+0x60]
0000747fd7fd12cc  vmovaps xmm8, [rsp+0x70]
0000747fd7fd12d2  vmovaps xmm9, [rsp+0x80]
0000747fd7fd12db  vmovaps xmm10, [rsp+0x90]
0000747fd7fd12e4  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd12ed  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd12f6  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd12ff  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd1308  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd1311  add rsp, 0xF0
0000747fd7fd1318  pop r11
0000747fd7fd131a  pop r10
0000747fd7fd131c  pop r9
0000747fd7fd131e  pop r8
0000747fd7fd1320  pop rsi
0000747fd7fd1321  pop rdi
0000747fd7fd1322  pop rdx
0000747fd7fd1323  pop rcx
0000747fd7fd1324  pop rax
0000747fd7fd1325  add rsp, 0x08
0000747fd7fd1329  jmp 0x0000747FD7FCF82C
0000747fd7fd132e  call 0x0000747FD7E0E760
0000747fd7fd1333  jmp 0x0000747FD7FCF839
0000747fd7fd1338  sub rsp, 0x08
0000747fd7fd133c  push rax
0000747fd7fd133d  push rcx
0000747fd7fd133e  push rdx
0000747fd7fd133f  push rdi
0000747fd7fd1340  push rsi
0000747fd7fd1341  push r8
0000747fd7fd1343  push r9
0000747fd7fd1345  push r10
0000747fd7fd1347  push r11
0000747fd7fd1349  sub rsp, 0xF0
0000747fd7fd1350  vmovaps [rsp], xmm0
0000747fd7fd1355  vmovaps [rsp+0x10], xmm1
0000747fd7fd135b  vmovaps [rsp+0x20], xmm2
0000747fd7fd1361  vmovaps [rsp+0x30], xmm3
0000747fd7fd1367  vmovaps [rsp+0x40], xmm4
0000747fd7fd136d  vmovaps [rsp+0x50], xmm5
0000747fd7fd1373  vmovaps [rsp+0x60], xmm6
0000747fd7fd1379  vmovaps [rsp+0x70], xmm7
0000747fd7fd137f  vmovaps [rsp+0x80], xmm8
0000747fd7fd1388  vmovaps [rsp+0x90], xmm9
0000747fd7fd1391  vmovaps [rsp+0xA0], xmm10
0000747fd7fd139a  vmovaps [rsp+0xB0], xmm11
0000747fd7fd13a3  vmovaps [rsp+0xC0], xmm12
0000747fd7fd13ac  vmovaps [rsp+0xD0], xmm14
0000747fd7fd13b5  vmovaps [rsp+0xE0], xmm15
0000747fd7fd13be  sub rsp, 0x30
0000747fd7fd13c2  movaps [rsp], xmm13
0000747fd7fd13c7  movaps [rsp+0x10], xmm2
0000747fd7fd13cc  movaps [rsp+0x20], xmm1
0000747fd7fd13d1  lea rdi, [rsp]
0000747fd7fd13d5  mov esi, 0x00
0000747fd7fd13da  mov rax, 0x6055A0B6E530
0000747fd7fd13e4  call rax
0000747fd7fd13e6  movaps xmm13, [rsp]
0000747fd7fd13eb  add rsp, 0x30
0000747fd7fd13ef  vmovaps xmm0, [rsp]
0000747fd7fd13f4  vmovaps xmm1, [rsp+0x10]
0000747fd7fd13fa  vmovaps xmm2, [rsp+0x20]
0000747fd7fd1400  vmovaps xmm3, [rsp+0x30]
0000747fd7fd1406  vmovaps xmm4, [rsp+0x40]
0000747fd7fd140c  vmovaps xmm5, [rsp+0x50]
0000747fd7fd1412  vmovaps xmm6, [rsp+0x60]
0000747fd7fd1418  vmovaps xmm7, [rsp+0x70]
0000747fd7fd141e  vmovaps xmm8, [rsp+0x80]
0000747fd7fd1427  vmovaps xmm9, [rsp+0x90]
0000747fd7fd1430  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd1439  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd1442  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd144b  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd1454  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd145d  add rsp, 0xF0
0000747fd7fd1464  pop r11
0000747fd7fd1466  pop r10
0000747fd7fd1468  pop r9
0000747fd7fd146a  pop r8
0000747fd7fd146c  pop rsi
0000747fd7fd146d  pop rdi
0000747fd7fd146e  pop rdx
0000747fd7fd146f  pop rcx
0000747fd7fd1470  pop rax
0000747fd7fd1471  add rsp, 0x08
0000747fd7fd1475  jmp 0x0000747FD7FCF878
0000747fd7fd147a  sub rsp, 0x08
0000747fd7fd147e  push rax
0000747fd7fd147f  push rcx
0000747fd7fd1480  push rdx
0000747fd7fd1481  push rdi
0000747fd7fd1482  push rsi
0000747fd7fd1483  push r8
0000747fd7fd1485  push r9
0000747fd7fd1487  push r10
0000747fd7fd1489  push r11
0000747fd7fd148b  sub rsp, 0xF0
0000747fd7fd1492  vmovaps [rsp], xmm0
0000747fd7fd1497  vmovaps [rsp+0x10], xmm2
0000747fd7fd149d  vmovaps [rsp+0x20], xmm3
0000747fd7fd14a3  vmovaps [rsp+0x30], xmm4
0000747fd7fd14a9  vmovaps [rsp+0x40], xmm5
0000747fd7fd14af  vmovaps [rsp+0x50], xmm6
0000747fd7fd14b5  vmovaps [rsp+0x60], xmm7
0000747fd7fd14bb  vmovaps [rsp+0x70], xmm8
0000747fd7fd14c1  vmovaps [rsp+0x80], xmm9
0000747fd7fd14ca  vmovaps [rsp+0x90], xmm10
0000747fd7fd14d3  vmovaps [rsp+0xA0], xmm11
0000747fd7fd14dc  vmovaps [rsp+0xB0], xmm12
0000747fd7fd14e5  vmovaps [rsp+0xC0], xmm13
0000747fd7fd14ee  vmovaps [rsp+0xD0], xmm14
0000747fd7fd14f7  vmovaps [rsp+0xE0], xmm15
0000747fd7fd1500  sub rsp, 0x30
0000747fd7fd1504  movaps [rsp], xmm1
0000747fd7fd1508  movaps [rsp+0x10], xmm15
0000747fd7fd150e  movaps [rsp+0x20], xmm2
0000747fd7fd1513  lea rdi, [rsp]
0000747fd7fd1517  mov esi, 0x00
0000747fd7fd151c  mov rax, 0x6055A0B6E530
0000747fd7fd1526  call rax
0000747fd7fd1528  movaps xmm1, [rsp]
0000747fd7fd152c  add rsp, 0x30
0000747fd7fd1530  vmovaps xmm0, [rsp]
0000747fd7fd1535  vmovaps xmm2, [rsp+0x10]
0000747fd7fd153b  vmovaps xmm3, [rsp+0x20]
0000747fd7fd1541  vmovaps xmm4, [rsp+0x30]
0000747fd7fd1547  vmovaps xmm5, [rsp+0x40]
0000747fd7fd154d  vmovaps xmm6, [rsp+0x50]
0000747fd7fd1553  vmovaps xmm7, [rsp+0x60]
0000747fd7fd1559  vmovaps xmm8, [rsp+0x70]
0000747fd7fd155f  vmovaps xmm9, [rsp+0x80]
0000747fd7fd1568  vmovaps xmm10, [rsp+0x90]
0000747fd7fd1571  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd157a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd1583  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd158c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd1595  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd159e  add rsp, 0xF0
0000747fd7fd15a5  pop r11
0000747fd7fd15a7  pop r10
0000747fd7fd15a9  pop r9
0000747fd7fd15ab  pop r8
0000747fd7fd15ad  pop rsi
0000747fd7fd15ae  pop rdi
0000747fd7fd15af  pop rdx
0000747fd7fd15b0  pop rcx
0000747fd7fd15b1  pop rax
0000747fd7fd15b2  add rsp, 0x08
0000747fd7fd15b6  jmp 0x0000747FD7FCF8AC
0000747fd7fd15bb  sub rsp, 0x08
0000747fd7fd15bf  push rax
0000747fd7fd15c0  push rcx
0000747fd7fd15c1  push rdx
0000747fd7fd15c2  push rdi
0000747fd7fd15c3  push rsi
0000747fd7fd15c4  push r8
0000747fd7fd15c6  push r9
0000747fd7fd15c8  push r10
0000747fd7fd15ca  push r11
0000747fd7fd15cc  sub rsp, 0xF0
0000747fd7fd15d3  vmovaps [rsp], xmm0
0000747fd7fd15d8  vmovaps [rsp+0x10], xmm1
0000747fd7fd15de  vmovaps [rsp+0x20], xmm2
0000747fd7fd15e4  vmovaps [rsp+0x30], xmm3
0000747fd7fd15ea  vmovaps [rsp+0x40], xmm4
0000747fd7fd15f0  vmovaps [rsp+0x50], xmm5
0000747fd7fd15f6  vmovaps [rsp+0x60], xmm6
0000747fd7fd15fc  vmovaps [rsp+0x70], xmm7
0000747fd7fd1602  vmovaps [rsp+0x80], xmm8
0000747fd7fd160b  vmovaps [rsp+0x90], xmm9
0000747fd7fd1614  vmovaps [rsp+0xA0], xmm10
0000747fd7fd161d  vmovaps [rsp+0xB0], xmm11
0000747fd7fd1626  vmovaps [rsp+0xC0], xmm12
0000747fd7fd162f  vmovaps [rsp+0xD0], xmm13
0000747fd7fd1638  vmovaps [rsp+0xE0], xmm15
0000747fd7fd1641  sub rsp, 0x30
0000747fd7fd1645  movaps [rsp], xmm14
0000747fd7fd164a  movaps [rsp+0x10], xmm2
0000747fd7fd164f  movaps [rsp+0x20], xmm15
0000747fd7fd1655  lea rdi, [rsp]
0000747fd7fd1659  mov esi, 0x00
0000747fd7fd165e  mov rax, 0x6055A0B6E530
0000747fd7fd1668  call rax
0000747fd7fd166a  movaps xmm14, [rsp]
0000747fd7fd166f  add rsp, 0x30
0000747fd7fd1673  vmovaps xmm0, [rsp]
0000747fd7fd1678  vmovaps xmm1, [rsp+0x10]
0000747fd7fd167e  vmovaps xmm2, [rsp+0x20]
0000747fd7fd1684  vmovaps xmm3, [rsp+0x30]
0000747fd7fd168a  vmovaps xmm4, [rsp+0x40]
0000747fd7fd1690  vmovaps xmm5, [rsp+0x50]
0000747fd7fd1696  vmovaps xmm6, [rsp+0x60]
0000747fd7fd169c  vmovaps xmm7, [rsp+0x70]
0000747fd7fd16a2  vmovaps xmm8, [rsp+0x80]
0000747fd7fd16ab  vmovaps xmm9, [rsp+0x90]
0000747fd7fd16b4  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd16bd  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd16c6  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd16cf  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd16d8  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd16e1  add rsp, 0xF0
0000747fd7fd16e8  pop r11
0000747fd7fd16ea  pop r10
0000747fd7fd16ec  pop r9
0000747fd7fd16ee  pop r8
0000747fd7fd16f0  pop rsi
0000747fd7fd16f1  pop rdi
0000747fd7fd16f2  pop rdx
0000747fd7fd16f3  pop rcx
0000747fd7fd16f4  pop rax
0000747fd7fd16f5  add rsp, 0x08
0000747fd7fd16f9  jmp 0x0000747FD7FCF8E7
0000747fd7fd16fe  sub rsp, 0x08
0000747fd7fd1702  push rax
0000747fd7fd1703  push rcx
0000747fd7fd1704  push rdx
0000747fd7fd1705  push rdi
0000747fd7fd1706  push rsi
0000747fd7fd1707  push r8
0000747fd7fd1709  push r9
0000747fd7fd170b  push r10
0000747fd7fd170d  push r11
0000747fd7fd170f  sub rsp, 0xF0
0000747fd7fd1716  vmovaps [rsp], xmm0
0000747fd7fd171b  vmovaps [rsp+0x10], xmm1
0000747fd7fd1721  vmovaps [rsp+0x20], xmm2
0000747fd7fd1727  vmovaps [rsp+0x30], xmm3
0000747fd7fd172d  vmovaps [rsp+0x40], xmm4
0000747fd7fd1733  vmovaps [rsp+0x50], xmm5
0000747fd7fd1739  vmovaps [rsp+0x60], xmm6
0000747fd7fd173f  vmovaps [rsp+0x70], xmm7
0000747fd7fd1745  vmovaps [rsp+0x80], xmm8
0000747fd7fd174e  vmovaps [rsp+0x90], xmm9
0000747fd7fd1757  vmovaps [rsp+0xA0], xmm10
0000747fd7fd1760  vmovaps [rsp+0xB0], xmm11
0000747fd7fd1769  vmovaps [rsp+0xC0], xmm12
0000747fd7fd1772  vmovaps [rsp+0xD0], xmm13
0000747fd7fd177b  vmovaps [rsp+0xE0], xmm14
0000747fd7fd1784  sub rsp, 0x30
0000747fd7fd1788  movaps [rsp], xmm15
0000747fd7fd178d  movaps [rsp+0x10], xmm2
0000747fd7fd1792  movaps [rsp+0x20], xmm1
0000747fd7fd1797  lea rdi, [rsp]
0000747fd7fd179b  mov esi, 0x00
0000747fd7fd17a0  mov rax, 0x6055A0B6E530
0000747fd7fd17aa  call rax
0000747fd7fd17ac  movaps xmm15, [rsp]
0000747fd7fd17b1  add rsp, 0x30
0000747fd7fd17b5  vmovaps xmm0, [rsp]
0000747fd7fd17ba  vmovaps xmm1, [rsp+0x10]
0000747fd7fd17c0  vmovaps xmm2, [rsp+0x20]
0000747fd7fd17c6  vmovaps xmm3, [rsp+0x30]
0000747fd7fd17cc  vmovaps xmm4, [rsp+0x40]
0000747fd7fd17d2  vmovaps xmm5, [rsp+0x50]
0000747fd7fd17d8  vmovaps xmm6, [rsp+0x60]
0000747fd7fd17de  vmovaps xmm7, [rsp+0x70]
0000747fd7fd17e4  vmovaps xmm8, [rsp+0x80]
0000747fd7fd17ed  vmovaps xmm9, [rsp+0x90]
0000747fd7fd17f6  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd17ff  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd1808  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd1811  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd181a  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd1823  add rsp, 0xF0
0000747fd7fd182a  pop r11
0000747fd7fd182c  pop r10
0000747fd7fd182e  pop r9
0000747fd7fd1830  pop r8
0000747fd7fd1832  pop rsi
0000747fd7fd1833  pop rdi
0000747fd7fd1834  pop rdx
0000747fd7fd1835  pop rcx
0000747fd7fd1836  pop rax
0000747fd7fd1837  add rsp, 0x08
0000747fd7fd183b  jmp 0x0000747FD7FCF923
0000747fd7fd1840  call 0x0000747FD7DFF430
0000747fd7fd1845  jmp 0x0000747FD7FCF930
0000747fd7fd184a  sub rsp, 0x08
0000747fd7fd184e  push rax
0000747fd7fd184f  push rcx
0000747fd7fd1850  push rdx
0000747fd7fd1851  push rdi
0000747fd7fd1852  push rsi
0000747fd7fd1853  push r8
0000747fd7fd1855  push r9
0000747fd7fd1857  push r10
0000747fd7fd1859  push r11
0000747fd7fd185b  sub rsp, 0xF0
0000747fd7fd1862  vmovaps [rsp], xmm0
0000747fd7fd1867  vmovaps [rsp+0x10], xmm1
0000747fd7fd186d  vmovaps [rsp+0x20], xmm3
0000747fd7fd1873  vmovaps [rsp+0x30], xmm4
0000747fd7fd1879  vmovaps [rsp+0x40], xmm5
0000747fd7fd187f  vmovaps [rsp+0x50], xmm6
0000747fd7fd1885  vmovaps [rsp+0x60], xmm7
0000747fd7fd188b  vmovaps [rsp+0x70], xmm8
0000747fd7fd1891  vmovaps [rsp+0x80], xmm9
0000747fd7fd189a  vmovaps [rsp+0x90], xmm10
0000747fd7fd18a3  vmovaps [rsp+0xA0], xmm11
0000747fd7fd18ac  vmovaps [rsp+0xB0], xmm12
0000747fd7fd18b5  vmovaps [rsp+0xC0], xmm13
0000747fd7fd18be  vmovaps [rsp+0xD0], xmm14
0000747fd7fd18c7  vmovaps [rsp+0xE0], xmm15
0000747fd7fd18d0  sub rsp, 0x30
0000747fd7fd18d4  movaps [rsp], xmm2
0000747fd7fd18d8  movaps [rsp+0x10], xmm1
0000747fd7fd18dd  movaps [rsp+0x20], xmm14
0000747fd7fd18e3  lea rdi, [rsp]
0000747fd7fd18e7  mov esi, 0x00
0000747fd7fd18ec  mov rax, 0x6055A0B6E530
0000747fd7fd18f6  call rax
0000747fd7fd18f8  movaps xmm2, [rsp]
0000747fd7fd18fc  add rsp, 0x30
0000747fd7fd1900  vmovaps xmm0, [rsp]
0000747fd7fd1905  vmovaps xmm1, [rsp+0x10]
0000747fd7fd190b  vmovaps xmm3, [rsp+0x20]
0000747fd7fd1911  vmovaps xmm4, [rsp+0x30]
0000747fd7fd1917  vmovaps xmm5, [rsp+0x40]
0000747fd7fd191d  vmovaps xmm6, [rsp+0x50]
0000747fd7fd1923  vmovaps xmm7, [rsp+0x60]
0000747fd7fd1929  vmovaps xmm8, [rsp+0x70]
0000747fd7fd192f  vmovaps xmm9, [rsp+0x80]
0000747fd7fd1938  vmovaps xmm10, [rsp+0x90]
0000747fd7fd1941  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd194a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd1953  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd195c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd1965  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd196e  add rsp, 0xF0
0000747fd7fd1975  pop r11
0000747fd7fd1977  pop r10
0000747fd7fd1979  pop r9
0000747fd7fd197b  pop r8
0000747fd7fd197d  pop rsi
0000747fd7fd197e  pop rdi
0000747fd7fd197f  pop rdx
0000747fd7fd1980  pop rcx
0000747fd7fd1981  pop rax
0000747fd7fd1982  add rsp, 0x08
0000747fd7fd1986  jmp 0x0000747FD7FCF96D
0000747fd7fd198b  sub rsp, 0x08
0000747fd7fd198f  push rax
0000747fd7fd1990  push rcx
0000747fd7fd1991  push rdx
0000747fd7fd1992  push rdi
0000747fd7fd1993  push rsi
0000747fd7fd1994  push r8
0000747fd7fd1996  push r9
0000747fd7fd1998  push r10
0000747fd7fd199a  push r11
0000747fd7fd199c  sub rsp, 0xF0
0000747fd7fd19a3  vmovaps [rsp], xmm0
0000747fd7fd19a8  vmovaps [rsp+0x10], xmm1
0000747fd7fd19ae  vmovaps [rsp+0x20], xmm2
0000747fd7fd19b4  vmovaps [rsp+0x30], xmm3
0000747fd7fd19ba  vmovaps [rsp+0x40], xmm4
0000747fd7fd19c0  vmovaps [rsp+0x50], xmm5
0000747fd7fd19c6  vmovaps [rsp+0x60], xmm6
0000747fd7fd19cc  vmovaps [rsp+0x70], xmm7
0000747fd7fd19d2  vmovaps [rsp+0x80], xmm8
0000747fd7fd19db  vmovaps [rsp+0x90], xmm9
0000747fd7fd19e4  vmovaps [rsp+0xA0], xmm10
0000747fd7fd19ed  vmovaps [rsp+0xB0], xmm11
0000747fd7fd19f6  vmovaps [rsp+0xC0], xmm12
0000747fd7fd19ff  vmovaps [rsp+0xD0], xmm13
0000747fd7fd1a08  vmovaps [rsp+0xE0], xmm14
0000747fd7fd1a11  sub rsp, 0x30
0000747fd7fd1a15  movaps [rsp], xmm15
0000747fd7fd1a1a  movaps [rsp+0x10], xmm14
0000747fd7fd1a20  movaps [rsp+0x20], xmm1
0000747fd7fd1a25  lea rdi, [rsp]
0000747fd7fd1a29  mov esi, 0x00
0000747fd7fd1a2e  mov rax, 0x6055A0B6E530
0000747fd7fd1a38  call rax
0000747fd7fd1a3a  movaps xmm15, [rsp]
0000747fd7fd1a3f  add rsp, 0x30
0000747fd7fd1a43  vmovaps xmm0, [rsp]
0000747fd7fd1a48  vmovaps xmm1, [rsp+0x10]
0000747fd7fd1a4e  vmovaps xmm2, [rsp+0x20]
0000747fd7fd1a54  vmovaps xmm3, [rsp+0x30]
0000747fd7fd1a5a  vmovaps xmm4, [rsp+0x40]
0000747fd7fd1a60  vmovaps xmm5, [rsp+0x50]
0000747fd7fd1a66  vmovaps xmm6, [rsp+0x60]
0000747fd7fd1a6c  vmovaps xmm7, [rsp+0x70]
0000747fd7fd1a72  vmovaps xmm8, [rsp+0x80]
0000747fd7fd1a7b  vmovaps xmm9, [rsp+0x90]
0000747fd7fd1a84  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd1a8d  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd1a96  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd1a9f  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd1aa8  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd1ab1  add rsp, 0xF0
0000747fd7fd1ab8  pop r11
0000747fd7fd1aba  pop r10
0000747fd7fd1abc  pop r9
0000747fd7fd1abe  pop r8
0000747fd7fd1ac0  pop rsi
0000747fd7fd1ac1  pop rdi
0000747fd7fd1ac2  pop rdx
0000747fd7fd1ac3  pop rcx
0000747fd7fd1ac4  pop rax
0000747fd7fd1ac5  add rsp, 0x08
0000747fd7fd1ac9  jmp 0x0000747FD7FCF9E7
0000747fd7fd1ace  call 0x0000747FD7DFF430
0000747fd7fd1ad3  jmp 0x0000747FD7FCF9F4
0000747fd7fd1ad8  sub rsp, 0x08
0000747fd7fd1adc  push rax
0000747fd7fd1add  push rcx
0000747fd7fd1ade  push rdx
0000747fd7fd1adf  push rdi
0000747fd7fd1ae0  push rsi
0000747fd7fd1ae1  push r8
0000747fd7fd1ae3  push r9
0000747fd7fd1ae5  push r10
0000747fd7fd1ae7  push r11
0000747fd7fd1ae9  sub rsp, 0xF0
0000747fd7fd1af0  vmovaps [rsp], xmm0
0000747fd7fd1af5  vmovaps [rsp+0x10], xmm1
0000747fd7fd1afb  vmovaps [rsp+0x20], xmm2
0000747fd7fd1b01  vmovaps [rsp+0x30], xmm3
0000747fd7fd1b07  vmovaps [rsp+0x40], xmm4
0000747fd7fd1b0d  vmovaps [rsp+0x50], xmm5
0000747fd7fd1b13  vmovaps [rsp+0x60], xmm6
0000747fd7fd1b19  vmovaps [rsp+0x70], xmm7
0000747fd7fd1b1f  vmovaps [rsp+0x80], xmm8
0000747fd7fd1b28  vmovaps [rsp+0x90], xmm9
0000747fd7fd1b31  vmovaps [rsp+0xA0], xmm10
0000747fd7fd1b3a  vmovaps [rsp+0xB0], xmm11
0000747fd7fd1b43  vmovaps [rsp+0xC0], xmm12
0000747fd7fd1b4c  vmovaps [rsp+0xD0], xmm13
0000747fd7fd1b55  vmovaps [rsp+0xE0], xmm15
0000747fd7fd1b5e  sub rsp, 0x30
0000747fd7fd1b62  movaps [rsp], xmm14
0000747fd7fd1b67  movaps [rsp+0x10], xmm13
0000747fd7fd1b6d  movaps [rsp+0x20], xmm1
0000747fd7fd1b72  lea rdi, [rsp]
0000747fd7fd1b76  mov esi, 0x00
0000747fd7fd1b7b  mov rax, 0x6055A0B6E530
0000747fd7fd1b85  call rax
0000747fd7fd1b87  movaps xmm14, [rsp]
0000747fd7fd1b8c  add rsp, 0x30
0000747fd7fd1b90  vmovaps xmm0, [rsp]
0000747fd7fd1b95  vmovaps xmm1, [rsp+0x10]
0000747fd7fd1b9b  vmovaps xmm2, [rsp+0x20]
0000747fd7fd1ba1  vmovaps xmm3, [rsp+0x30]
0000747fd7fd1ba7  vmovaps xmm4, [rsp+0x40]
0000747fd7fd1bad  vmovaps xmm5, [rsp+0x50]
0000747fd7fd1bb3  vmovaps xmm6, [rsp+0x60]
0000747fd7fd1bb9  vmovaps xmm7, [rsp+0x70]
0000747fd7fd1bbf  vmovaps xmm8, [rsp+0x80]
0000747fd7fd1bc8  vmovaps xmm9, [rsp+0x90]
0000747fd7fd1bd1  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd1bda  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd1be3  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd1bec  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd1bf5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd1bfe  add rsp, 0xF0
0000747fd7fd1c05  pop r11
0000747fd7fd1c07  pop r10
0000747fd7fd1c09  pop r9
0000747fd7fd1c0b  pop r8
0000747fd7fd1c0d  pop rsi
0000747fd7fd1c0e  pop rdi
0000747fd7fd1c0f  pop rdx
0000747fd7fd1c10  pop rcx
0000747fd7fd1c11  pop rax
0000747fd7fd1c12  add rsp, 0x08
0000747fd7fd1c16  jmp 0x0000747FD7FCFAAF
0000747fd7fd1c1b  sub rsp, 0x08
0000747fd7fd1c1f  push rax
0000747fd7fd1c20  push rcx
0000747fd7fd1c21  push rdx
0000747fd7fd1c22  push rdi
0000747fd7fd1c23  push rsi
0000747fd7fd1c24  push r8
0000747fd7fd1c26  push r9
0000747fd7fd1c28  push r10
0000747fd7fd1c2a  push r11
0000747fd7fd1c2c  sub rsp, 0xF0
0000747fd7fd1c33  vmovaps [rsp], xmm0
0000747fd7fd1c38  vmovaps [rsp+0x10], xmm1
0000747fd7fd1c3e  vmovaps [rsp+0x20], xmm2
0000747fd7fd1c44  vmovaps [rsp+0x30], xmm3
0000747fd7fd1c4a  vmovaps [rsp+0x40], xmm4
0000747fd7fd1c50  vmovaps [rsp+0x50], xmm5
0000747fd7fd1c56  vmovaps [rsp+0x60], xmm6
0000747fd7fd1c5c  vmovaps [rsp+0x70], xmm7
0000747fd7fd1c62  vmovaps [rsp+0x80], xmm8
0000747fd7fd1c6b  vmovaps [rsp+0x90], xmm9
0000747fd7fd1c74  vmovaps [rsp+0xA0], xmm10
0000747fd7fd1c7d  vmovaps [rsp+0xB0], xmm11
0000747fd7fd1c86  vmovaps [rsp+0xC0], xmm12
0000747fd7fd1c8f  vmovaps [rsp+0xD0], xmm13
0000747fd7fd1c98  vmovaps [rsp+0xE0], xmm14
0000747fd7fd1ca1  sub rsp, 0x30
0000747fd7fd1ca5  movaps [rsp], xmm15
0000747fd7fd1caa  movaps [rsp+0x10], xmm13
0000747fd7fd1cb0  movaps [rsp+0x20], xmm1
0000747fd7fd1cb5  lea rdi, [rsp]
0000747fd7fd1cb9  mov esi, 0x00
0000747fd7fd1cbe  mov rax, 0x6055A0B6E530
0000747fd7fd1cc8  call rax
0000747fd7fd1cca  movaps xmm15, [rsp]
0000747fd7fd1ccf  add rsp, 0x30
0000747fd7fd1cd3  vmovaps xmm0, [rsp]
0000747fd7fd1cd8  vmovaps xmm1, [rsp+0x10]
0000747fd7fd1cde  vmovaps xmm2, [rsp+0x20]
0000747fd7fd1ce4  vmovaps xmm3, [rsp+0x30]
0000747fd7fd1cea  vmovaps xmm4, [rsp+0x40]
0000747fd7fd1cf0  vmovaps xmm5, [rsp+0x50]
0000747fd7fd1cf6  vmovaps xmm6, [rsp+0x60]
0000747fd7fd1cfc  vmovaps xmm7, [rsp+0x70]
0000747fd7fd1d02  vmovaps xmm8, [rsp+0x80]
0000747fd7fd1d0b  vmovaps xmm9, [rsp+0x90]
0000747fd7fd1d14  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd1d1d  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd1d26  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd1d2f  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd1d38  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd1d41  add rsp, 0xF0
0000747fd7fd1d48  pop r11
0000747fd7fd1d4a  pop r10
0000747fd7fd1d4c  pop r9
0000747fd7fd1d4e  pop r8
0000747fd7fd1d50  pop rsi
0000747fd7fd1d51  pop rdi
0000747fd7fd1d52  pop rdx
0000747fd7fd1d53  pop rcx
0000747fd7fd1d54  pop rax
0000747fd7fd1d55  add rsp, 0x08
0000747fd7fd1d59  jmp 0x0000747FD7FCFAEB
0000747fd7fd1d5e  call 0x0000747FD7DFF430
0000747fd7fd1d63  jmp 0x0000747FD7FCFAF8
0000747fd7fd1d68  sub rsp, 0x08
0000747fd7fd1d6c  push rax
0000747fd7fd1d6d  push rcx
0000747fd7fd1d6e  push rdx
0000747fd7fd1d6f  push rdi
0000747fd7fd1d70  push rsi
0000747fd7fd1d71  push r8
0000747fd7fd1d73  push r9
0000747fd7fd1d75  push r10
0000747fd7fd1d77  push r11
0000747fd7fd1d79  sub rsp, 0xF0
0000747fd7fd1d80  vmovaps [rsp], xmm0
0000747fd7fd1d85  vmovaps [rsp+0x10], xmm1
0000747fd7fd1d8b  vmovaps [rsp+0x20], xmm2
0000747fd7fd1d91  vmovaps [rsp+0x30], xmm3
0000747fd7fd1d97  vmovaps [rsp+0x40], xmm4
0000747fd7fd1d9d  vmovaps [rsp+0x50], xmm5
0000747fd7fd1da3  vmovaps [rsp+0x60], xmm6
0000747fd7fd1da9  vmovaps [rsp+0x70], xmm7
0000747fd7fd1daf  vmovaps [rsp+0x80], xmm8
0000747fd7fd1db8  vmovaps [rsp+0x90], xmm9
0000747fd7fd1dc1  vmovaps [rsp+0xA0], xmm10
0000747fd7fd1dca  vmovaps [rsp+0xB0], xmm11
0000747fd7fd1dd3  vmovaps [rsp+0xC0], xmm12
0000747fd7fd1ddc  vmovaps [rsp+0xD0], xmm13
0000747fd7fd1de5  vmovaps [rsp+0xE0], xmm15
0000747fd7fd1dee  sub rsp, 0x30
0000747fd7fd1df2  movaps [rsp], xmm14
0000747fd7fd1df7  movaps [rsp+0x10], xmm13
0000747fd7fd1dfd  movaps [rsp+0x20], xmm2
0000747fd7fd1e02  lea rdi, [rsp]
0000747fd7fd1e06  mov esi, 0x00
0000747fd7fd1e0b  mov rax, 0x6055A0B6E530
0000747fd7fd1e15  call rax
0000747fd7fd1e17  movaps xmm14, [rsp]
0000747fd7fd1e1c  add rsp, 0x30
0000747fd7fd1e20  vmovaps xmm0, [rsp]
0000747fd7fd1e25  vmovaps xmm1, [rsp+0x10]
0000747fd7fd1e2b  vmovaps xmm2, [rsp+0x20]
0000747fd7fd1e31  vmovaps xmm3, [rsp+0x30]
0000747fd7fd1e37  vmovaps xmm4, [rsp+0x40]
0000747fd7fd1e3d  vmovaps xmm5, [rsp+0x50]
0000747fd7fd1e43  vmovaps xmm6, [rsp+0x60]
0000747fd7fd1e49  vmovaps xmm7, [rsp+0x70]
0000747fd7fd1e4f  vmovaps xmm8, [rsp+0x80]
0000747fd7fd1e58  vmovaps xmm9, [rsp+0x90]
0000747fd7fd1e61  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd1e6a  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd1e73  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd1e7c  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd1e85  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd1e8e  add rsp, 0xF0
0000747fd7fd1e95  pop r11
0000747fd7fd1e97  pop r10
0000747fd7fd1e99  pop r9
0000747fd7fd1e9b  pop r8
0000747fd7fd1e9d  pop rsi
0000747fd7fd1e9e  pop rdi
0000747fd7fd1e9f  pop rdx
0000747fd7fd1ea0  pop rcx
0000747fd7fd1ea1  pop rax
0000747fd7fd1ea2  add rsp, 0x08
0000747fd7fd1ea6  jmp 0x0000747FD7FCFB24
0000747fd7fd1eab  sub rsp, 0x08
0000747fd7fd1eaf  push rax
0000747fd7fd1eb0  push rcx
0000747fd7fd1eb1  push rdx
0000747fd7fd1eb2  push rdi
0000747fd7fd1eb3  push rsi
0000747fd7fd1eb4  push r8
0000747fd7fd1eb6  push r9
0000747fd7fd1eb8  push r10
0000747fd7fd1eba  push r11
0000747fd7fd1ebc  sub rsp, 0xF0
0000747fd7fd1ec3  vmovaps [rsp], xmm0
0000747fd7fd1ec8  vmovaps [rsp+0x10], xmm2
0000747fd7fd1ece  vmovaps [rsp+0x20], xmm3
0000747fd7fd1ed4  vmovaps [rsp+0x30], xmm4
0000747fd7fd1eda  vmovaps [rsp+0x40], xmm5
0000747fd7fd1ee0  vmovaps [rsp+0x50], xmm6
0000747fd7fd1ee6  vmovaps [rsp+0x60], xmm7
0000747fd7fd1eec  vmovaps [rsp+0x70], xmm8
0000747fd7fd1ef2  vmovaps [rsp+0x80], xmm9
0000747fd7fd1efb  vmovaps [rsp+0x90], xmm10
0000747fd7fd1f04  vmovaps [rsp+0xA0], xmm11
0000747fd7fd1f0d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd1f16  vmovaps [rsp+0xC0], xmm13
0000747fd7fd1f1f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd1f28  vmovaps [rsp+0xE0], xmm15
0000747fd7fd1f31  sub rsp, 0x30
0000747fd7fd1f35  movaps [rsp], xmm1
0000747fd7fd1f39  movaps [rsp+0x10], xmm13
0000747fd7fd1f3f  movaps [rsp+0x20], xmm2
0000747fd7fd1f44  lea rdi, [rsp]
0000747fd7fd1f48  mov esi, 0x00
0000747fd7fd1f4d  mov rax, 0x6055A0B6E530
0000747fd7fd1f57  call rax
0000747fd7fd1f59  movaps xmm1, [rsp]
0000747fd7fd1f5d  add rsp, 0x30
0000747fd7fd1f61  vmovaps xmm0, [rsp]
0000747fd7fd1f66  vmovaps xmm2, [rsp+0x10]
0000747fd7fd1f6c  vmovaps xmm3, [rsp+0x20]
0000747fd7fd1f72  vmovaps xmm4, [rsp+0x30]
0000747fd7fd1f78  vmovaps xmm5, [rsp+0x40]
0000747fd7fd1f7e  vmovaps xmm6, [rsp+0x50]
0000747fd7fd1f84  vmovaps xmm7, [rsp+0x60]
0000747fd7fd1f8a  vmovaps xmm8, [rsp+0x70]
0000747fd7fd1f90  vmovaps xmm9, [rsp+0x80]
0000747fd7fd1f99  vmovaps xmm10, [rsp+0x90]
0000747fd7fd1fa2  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd1fab  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd1fb4  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd1fbd  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd1fc6  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd1fcf  add rsp, 0xF0
0000747fd7fd1fd6  pop r11
0000747fd7fd1fd8  pop r10
0000747fd7fd1fda  pop r9
0000747fd7fd1fdc  pop r8
0000747fd7fd1fde  pop rsi
0000747fd7fd1fdf  pop rdi
0000747fd7fd1fe0  pop rdx
0000747fd7fd1fe1  pop rcx
0000747fd7fd1fe2  pop rax
0000747fd7fd1fe3  add rsp, 0x08
0000747fd7fd1fe7  jmp 0x0000747FD7FCFB52
0000747fd7fd1fec  sub rsp, 0x08
0000747fd7fd1ff0  push rax
0000747fd7fd1ff1  push rcx
0000747fd7fd1ff2  push rdx
0000747fd7fd1ff3  push rdi
0000747fd7fd1ff4  push rsi
0000747fd7fd1ff5  push r8
0000747fd7fd1ff7  push r9
0000747fd7fd1ff9  push r10
0000747fd7fd1ffb  push r11
0000747fd7fd1ffd  sub rsp, 0xF0
0000747fd7fd2004  vmovaps [rsp], xmm0
0000747fd7fd2009  vmovaps [rsp+0x10], xmm1
0000747fd7fd200f  vmovaps [rsp+0x20], xmm3
0000747fd7fd2015  vmovaps [rsp+0x30], xmm4
0000747fd7fd201b  vmovaps [rsp+0x40], xmm5
0000747fd7fd2021  vmovaps [rsp+0x50], xmm6
0000747fd7fd2027  vmovaps [rsp+0x60], xmm7
0000747fd7fd202d  vmovaps [rsp+0x70], xmm8
0000747fd7fd2033  vmovaps [rsp+0x80], xmm9
0000747fd7fd203c  vmovaps [rsp+0x90], xmm10
0000747fd7fd2045  vmovaps [rsp+0xA0], xmm11
0000747fd7fd204e  vmovaps [rsp+0xB0], xmm12
0000747fd7fd2057  vmovaps [rsp+0xC0], xmm13
0000747fd7fd2060  vmovaps [rsp+0xD0], xmm14
0000747fd7fd2069  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2072  sub rsp, 0x30
0000747fd7fd2076  movaps [rsp], xmm2
0000747fd7fd207a  movaps [rsp+0x10], xmm1
0000747fd7fd207f  movaps [rsp+0x20], xmm13
0000747fd7fd2085  lea rdi, [rsp]
0000747fd7fd2089  mov esi, 0x00
0000747fd7fd208e  mov rax, 0x6055A0B6E530
0000747fd7fd2098  call rax
0000747fd7fd209a  movaps xmm2, [rsp]
0000747fd7fd209e  add rsp, 0x30
0000747fd7fd20a2  vmovaps xmm0, [rsp]
0000747fd7fd20a7  vmovaps xmm1, [rsp+0x10]
0000747fd7fd20ad  vmovaps xmm3, [rsp+0x20]
0000747fd7fd20b3  vmovaps xmm4, [rsp+0x30]
0000747fd7fd20b9  vmovaps xmm5, [rsp+0x40]
0000747fd7fd20bf  vmovaps xmm6, [rsp+0x50]
0000747fd7fd20c5  vmovaps xmm7, [rsp+0x60]
0000747fd7fd20cb  vmovaps xmm8, [rsp+0x70]
0000747fd7fd20d1  vmovaps xmm9, [rsp+0x80]
0000747fd7fd20da  vmovaps xmm10, [rsp+0x90]
0000747fd7fd20e3  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd20ec  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd20f5  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd20fe  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd2107  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd2110  add rsp, 0xF0
0000747fd7fd2117  pop r11
0000747fd7fd2119  pop r10
0000747fd7fd211b  pop r9
0000747fd7fd211d  pop r8
0000747fd7fd211f  pop rsi
0000747fd7fd2120  pop rdi
0000747fd7fd2121  pop rdx
0000747fd7fd2122  pop rcx
0000747fd7fd2123  pop rax
0000747fd7fd2124  add rsp, 0x08
0000747fd7fd2128  jmp 0x0000747FD7FCFBAB
0000747fd7fd212d  call 0x0000747FD7DFF430
0000747fd7fd2132  jmp 0x0000747FD7FCFBB8
0000747fd7fd2137  sub rsp, 0x08
0000747fd7fd213b  push rax
0000747fd7fd213c  push rcx
0000747fd7fd213d  push rdx
0000747fd7fd213e  push rdi
0000747fd7fd213f  push rsi
0000747fd7fd2140  push r8
0000747fd7fd2142  push r9
0000747fd7fd2144  push r10
0000747fd7fd2146  push r11
0000747fd7fd2148  sub rsp, 0xF0
0000747fd7fd214f  vmovaps [rsp], xmm0
0000747fd7fd2154  vmovaps [rsp+0x10], xmm1
0000747fd7fd215a  vmovaps [rsp+0x20], xmm2
0000747fd7fd2160  vmovaps [rsp+0x30], xmm3
0000747fd7fd2166  vmovaps [rsp+0x40], xmm4
0000747fd7fd216c  vmovaps [rsp+0x50], xmm5
0000747fd7fd2172  vmovaps [rsp+0x60], xmm6
0000747fd7fd2178  vmovaps [rsp+0x70], xmm7
0000747fd7fd217e  vmovaps [rsp+0x80], xmm8
0000747fd7fd2187  vmovaps [rsp+0x90], xmm9
0000747fd7fd2190  vmovaps [rsp+0xA0], xmm10
0000747fd7fd2199  vmovaps [rsp+0xB0], xmm11
0000747fd7fd21a2  vmovaps [rsp+0xC0], xmm12
0000747fd7fd21ab  vmovaps [rsp+0xD0], xmm13
0000747fd7fd21b4  vmovaps [rsp+0xE0], xmm14
0000747fd7fd21bd  sub rsp, 0x30
0000747fd7fd21c1  movaps [rsp], xmm15
0000747fd7fd21c6  movaps [rsp+0x10], xmm13
0000747fd7fd21cc  movaps [rsp+0x20], xmm1
0000747fd7fd21d1  lea rdi, [rsp]
0000747fd7fd21d5  mov esi, 0x00
0000747fd7fd21da  mov rax, 0x6055A0B6E530
0000747fd7fd21e4  call rax
0000747fd7fd21e6  movaps xmm15, [rsp]
0000747fd7fd21eb  add rsp, 0x30
0000747fd7fd21ef  vmovaps xmm0, [rsp]
0000747fd7fd21f4  vmovaps xmm1, [rsp+0x10]
0000747fd7fd21fa  vmovaps xmm2, [rsp+0x20]
0000747fd7fd2200  vmovaps xmm3, [rsp+0x30]
0000747fd7fd2206  vmovaps xmm4, [rsp+0x40]
0000747fd7fd220c  vmovaps xmm5, [rsp+0x50]
0000747fd7fd2212  vmovaps xmm6, [rsp+0x60]
0000747fd7fd2218  vmovaps xmm7, [rsp+0x70]
0000747fd7fd221e  vmovaps xmm8, [rsp+0x80]
0000747fd7fd2227  vmovaps xmm9, [rsp+0x90]
0000747fd7fd2230  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd2239  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd2242  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd224b  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd2254  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd225d  add rsp, 0xF0
0000747fd7fd2264  pop r11
0000747fd7fd2266  pop r10
0000747fd7fd2268  pop r9
0000747fd7fd226a  pop r8
0000747fd7fd226c  pop rsi
0000747fd7fd226d  pop rdi
0000747fd7fd226e  pop rdx
0000747fd7fd226f  pop rcx
0000747fd7fd2270  pop rax
0000747fd7fd2271  add rsp, 0x08
0000747fd7fd2275  jmp 0x0000747FD7FCFBF7
0000747fd7fd227a  sub rsp, 0x08
0000747fd7fd227e  push rax
0000747fd7fd227f  push rcx
0000747fd7fd2280  push rdx
0000747fd7fd2281  push rdi
0000747fd7fd2282  push rsi
0000747fd7fd2283  push r8
0000747fd7fd2285  push r9
0000747fd7fd2287  push r10
0000747fd7fd2289  push r11
0000747fd7fd228b  sub rsp, 0xF0
0000747fd7fd2292  vmovaps [rsp], xmm0
0000747fd7fd2297  vmovaps [rsp+0x10], xmm1
0000747fd7fd229d  vmovaps [rsp+0x20], xmm2
0000747fd7fd22a3  vmovaps [rsp+0x30], xmm3
0000747fd7fd22a9  vmovaps [rsp+0x40], xmm4
0000747fd7fd22af  vmovaps [rsp+0x50], xmm5
0000747fd7fd22b5  vmovaps [rsp+0x60], xmm6
0000747fd7fd22bb  vmovaps [rsp+0x70], xmm7
0000747fd7fd22c1  vmovaps [rsp+0x80], xmm8
0000747fd7fd22ca  vmovaps [rsp+0x90], xmm9
0000747fd7fd22d3  vmovaps [rsp+0xA0], xmm10
0000747fd7fd22dc  vmovaps [rsp+0xB0], xmm11
0000747fd7fd22e5  vmovaps [rsp+0xC0], xmm12
0000747fd7fd22ee  vmovaps [rsp+0xD0], xmm13
0000747fd7fd22f7  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2300  sub rsp, 0x30
0000747fd7fd2304  movaps [rsp], xmm14
0000747fd7fd2309  movaps [rsp+0x10], xmm11
0000747fd7fd230f  movaps [rsp+0x20], xmm1
0000747fd7fd2314  lea rdi, [rsp]
0000747fd7fd2318  mov esi, 0x00
0000747fd7fd231d  mov rax, 0x6055A0B6E530
0000747fd7fd2327  call rax
0000747fd7fd2329  movaps xmm14, [rsp]
0000747fd7fd232e  add rsp, 0x30
0000747fd7fd2332  vmovaps xmm0, [rsp]
0000747fd7fd2337  vmovaps xmm1, [rsp+0x10]
0000747fd7fd233d  vmovaps xmm2, [rsp+0x20]
0000747fd7fd2343  vmovaps xmm3, [rsp+0x30]
0000747fd7fd2349  vmovaps xmm4, [rsp+0x40]
0000747fd7fd234f  vmovaps xmm5, [rsp+0x50]
0000747fd7fd2355  vmovaps xmm6, [rsp+0x60]
0000747fd7fd235b  vmovaps xmm7, [rsp+0x70]
0000747fd7fd2361  vmovaps xmm8, [rsp+0x80]
0000747fd7fd236a  vmovaps xmm9, [rsp+0x90]
0000747fd7fd2373  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd237c  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd2385  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd238e  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd2397  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd23a0  add rsp, 0xF0
0000747fd7fd23a7  pop r11
0000747fd7fd23a9  pop r10
0000747fd7fd23ab  pop r9
0000747fd7fd23ad  pop r8
0000747fd7fd23af  pop rsi
0000747fd7fd23b0  pop rdi
0000747fd7fd23b1  pop rdx
0000747fd7fd23b2  pop rcx
0000747fd7fd23b3  pop rax
0000747fd7fd23b4  add rsp, 0x08
0000747fd7fd23b8  jmp 0x0000747FD7FCFC21
0000747fd7fd23bd  sub rsp, 0x08
0000747fd7fd23c1  push rax
0000747fd7fd23c2  push rcx
0000747fd7fd23c3  push rdx
0000747fd7fd23c4  push rdi
0000747fd7fd23c5  push rsi
0000747fd7fd23c6  push r8
0000747fd7fd23c8  push r9
0000747fd7fd23ca  push r10
0000747fd7fd23cc  push r11
0000747fd7fd23ce  sub rsp, 0xF0
0000747fd7fd23d5  vmovaps [rsp], xmm0
0000747fd7fd23da  vmovaps [rsp+0x10], xmm1
0000747fd7fd23e0  vmovaps [rsp+0x20], xmm2
0000747fd7fd23e6  vmovaps [rsp+0x30], xmm3
0000747fd7fd23ec  vmovaps [rsp+0x40], xmm4
0000747fd7fd23f2  vmovaps [rsp+0x50], xmm5
0000747fd7fd23f8  vmovaps [rsp+0x60], xmm6
0000747fd7fd23fe  vmovaps [rsp+0x70], xmm7
0000747fd7fd2404  vmovaps [rsp+0x80], xmm8
0000747fd7fd240d  vmovaps [rsp+0x90], xmm9
0000747fd7fd2416  vmovaps [rsp+0xA0], xmm10
0000747fd7fd241f  vmovaps [rsp+0xB0], xmm11
0000747fd7fd2428  vmovaps [rsp+0xC0], xmm12
0000747fd7fd2431  vmovaps [rsp+0xD0], xmm14
0000747fd7fd243a  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2443  sub rsp, 0x30
0000747fd7fd2447  movaps [rsp], xmm13
0000747fd7fd244c  movaps [rsp+0x10], xmm11
0000747fd7fd2452  movaps [rsp+0x20], xmm1
0000747fd7fd2457  lea rdi, [rsp]
0000747fd7fd245b  mov esi, 0x00
0000747fd7fd2460  mov rax, 0x6055A0B6E530
0000747fd7fd246a  call rax
0000747fd7fd246c  movaps xmm13, [rsp]
0000747fd7fd2471  add rsp, 0x30
0000747fd7fd2475  vmovaps xmm0, [rsp]
0000747fd7fd247a  vmovaps xmm1, [rsp+0x10]
0000747fd7fd2480  vmovaps xmm2, [rsp+0x20]
0000747fd7fd2486  vmovaps xmm3, [rsp+0x30]
0000747fd7fd248c  vmovaps xmm4, [rsp+0x40]
0000747fd7fd2492  vmovaps xmm5, [rsp+0x50]
0000747fd7fd2498  vmovaps xmm6, [rsp+0x60]
0000747fd7fd249e  vmovaps xmm7, [rsp+0x70]
0000747fd7fd24a4  vmovaps xmm8, [rsp+0x80]
0000747fd7fd24ad  vmovaps xmm9, [rsp+0x90]
0000747fd7fd24b6  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd24bf  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd24c8  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd24d1  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd24da  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd24e3  add rsp, 0xF0
0000747fd7fd24ea  pop r11
0000747fd7fd24ec  pop r10
0000747fd7fd24ee  pop r9
0000747fd7fd24f0  pop r8
0000747fd7fd24f2  pop rsi
0000747fd7fd24f3  pop rdi
0000747fd7fd24f4  pop rdx
0000747fd7fd24f5  pop rcx
0000747fd7fd24f6  pop rax
0000747fd7fd24f7  add rsp, 0x08
0000747fd7fd24fb  jmp 0x0000747FD7FCFC76
0000747fd7fd2500  call 0x0000747FD7DFF430
0000747fd7fd2505  jmp 0x0000747FD7FCFC83
0000747fd7fd250a  sub rsp, 0x08
0000747fd7fd250e  push rax
0000747fd7fd250f  push rcx
0000747fd7fd2510  push rdx
0000747fd7fd2511  push rdi
0000747fd7fd2512  push rsi
0000747fd7fd2513  push r8
0000747fd7fd2515  push r9
0000747fd7fd2517  push r10
0000747fd7fd2519  push r11
0000747fd7fd251b  sub rsp, 0xF0
0000747fd7fd2522  vmovaps [rsp], xmm0
0000747fd7fd2527  vmovaps [rsp+0x10], xmm1
0000747fd7fd252d  vmovaps [rsp+0x20], xmm2
0000747fd7fd2533  vmovaps [rsp+0x30], xmm3
0000747fd7fd2539  vmovaps [rsp+0x40], xmm4
0000747fd7fd253f  vmovaps [rsp+0x50], xmm5
0000747fd7fd2545  vmovaps [rsp+0x60], xmm6
0000747fd7fd254b  vmovaps [rsp+0x70], xmm7
0000747fd7fd2551  vmovaps [rsp+0x80], xmm8
0000747fd7fd255a  vmovaps [rsp+0x90], xmm9
0000747fd7fd2563  vmovaps [rsp+0xA0], xmm10
0000747fd7fd256c  vmovaps [rsp+0xB0], xmm11
0000747fd7fd2575  vmovaps [rsp+0xC0], xmm12
0000747fd7fd257e  vmovaps [rsp+0xD0], xmm13
0000747fd7fd2587  vmovaps [rsp+0xE0], xmm14
0000747fd7fd2590  sub rsp, 0x30
0000747fd7fd2594  movaps [rsp], xmm15
0000747fd7fd2599  movaps [rsp+0x10], xmm11
0000747fd7fd259f  movaps [rsp+0x20], xmm1
0000747fd7fd25a4  lea rdi, [rsp]
0000747fd7fd25a8  mov esi, 0x00
0000747fd7fd25ad  mov rax, 0x6055A0B6E530
0000747fd7fd25b7  call rax
0000747fd7fd25b9  movaps xmm15, [rsp]
0000747fd7fd25be  add rsp, 0x30
0000747fd7fd25c2  vmovaps xmm0, [rsp]
0000747fd7fd25c7  vmovaps xmm1, [rsp+0x10]
0000747fd7fd25cd  vmovaps xmm2, [rsp+0x20]
0000747fd7fd25d3  vmovaps xmm3, [rsp+0x30]
0000747fd7fd25d9  vmovaps xmm4, [rsp+0x40]
0000747fd7fd25df  vmovaps xmm5, [rsp+0x50]
0000747fd7fd25e5  vmovaps xmm6, [rsp+0x60]
0000747fd7fd25eb  vmovaps xmm7, [rsp+0x70]
0000747fd7fd25f1  vmovaps xmm8, [rsp+0x80]
0000747fd7fd25fa  vmovaps xmm9, [rsp+0x90]
0000747fd7fd2603  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd260c  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd2615  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd261e  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd2627  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd2630  add rsp, 0xF0
0000747fd7fd2637  pop r11
0000747fd7fd2639  pop r10
0000747fd7fd263b  pop r9
0000747fd7fd263d  pop r8
0000747fd7fd263f  pop rsi
0000747fd7fd2640  pop rdi
0000747fd7fd2641  pop rdx
0000747fd7fd2642  pop rcx
0000747fd7fd2643  pop rax
0000747fd7fd2644  add rsp, 0x08
0000747fd7fd2648  jmp 0x0000747FD7FCFCBC
0000747fd7fd264d  sub rsp, 0x08
0000747fd7fd2651  push rax
0000747fd7fd2652  push rcx
0000747fd7fd2653  push rdx
0000747fd7fd2654  push rdi
0000747fd7fd2655  push rsi
0000747fd7fd2656  push r8
0000747fd7fd2658  push r9
0000747fd7fd265a  push r10
0000747fd7fd265c  push r11
0000747fd7fd265e  sub rsp, 0xF0
0000747fd7fd2665  vmovaps [rsp], xmm0
0000747fd7fd266a  vmovaps [rsp+0x10], xmm1
0000747fd7fd2670  vmovaps [rsp+0x20], xmm2
0000747fd7fd2676  vmovaps [rsp+0x30], xmm3
0000747fd7fd267c  vmovaps [rsp+0x40], xmm4
0000747fd7fd2682  vmovaps [rsp+0x50], xmm5
0000747fd7fd2688  vmovaps [rsp+0x60], xmm6
0000747fd7fd268e  vmovaps [rsp+0x70], xmm7
0000747fd7fd2694  vmovaps [rsp+0x80], xmm8
0000747fd7fd269d  vmovaps [rsp+0x90], xmm9
0000747fd7fd26a6  vmovaps [rsp+0xA0], xmm10
0000747fd7fd26af  vmovaps [rsp+0xB0], xmm12
0000747fd7fd26b8  vmovaps [rsp+0xC0], xmm13
0000747fd7fd26c1  vmovaps [rsp+0xD0], xmm14
0000747fd7fd26ca  vmovaps [rsp+0xE0], xmm15
0000747fd7fd26d3  sub rsp, 0x30
0000747fd7fd26d7  movaps [rsp], xmm11
0000747fd7fd26dc  movaps [rsp+0x10], xmm6
0000747fd7fd26e1  movaps [rsp+0x20], xmm14
0000747fd7fd26e7  lea rdi, [rsp]
0000747fd7fd26eb  mov esi, 0x00
0000747fd7fd26f0  mov rax, 0x6055A0B6E530
0000747fd7fd26fa  call rax
0000747fd7fd26fc  movaps xmm11, [rsp]
0000747fd7fd2701  add rsp, 0x30
0000747fd7fd2705  vmovaps xmm0, [rsp]
0000747fd7fd270a  vmovaps xmm1, [rsp+0x10]
0000747fd7fd2710  vmovaps xmm2, [rsp+0x20]
0000747fd7fd2716  vmovaps xmm3, [rsp+0x30]
0000747fd7fd271c  vmovaps xmm4, [rsp+0x40]
0000747fd7fd2722  vmovaps xmm5, [rsp+0x50]
0000747fd7fd2728  vmovaps xmm6, [rsp+0x60]
0000747fd7fd272e  vmovaps xmm7, [rsp+0x70]
0000747fd7fd2734  vmovaps xmm8, [rsp+0x80]
0000747fd7fd273d  vmovaps xmm9, [rsp+0x90]
0000747fd7fd2746  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd274f  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd2758  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd2761  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd276a  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd2773  add rsp, 0xF0
0000747fd7fd277a  pop r11
0000747fd7fd277c  pop r10
0000747fd7fd277e  pop r9
0000747fd7fd2780  pop r8
0000747fd7fd2782  pop rsi
0000747fd7fd2783  pop rdi
0000747fd7fd2784  pop rdx
0000747fd7fd2785  pop rcx
0000747fd7fd2786  pop rax
0000747fd7fd2787  add rsp, 0x08
0000747fd7fd278b  jmp 0x0000747FD7FCFD34
0000747fd7fd2790  call 0x0000747FD7DFF430
0000747fd7fd2795  jmp 0x0000747FD7FCFD3E
0000747fd7fd279a  sub rsp, 0x08
0000747fd7fd279e  push rax
0000747fd7fd279f  push rcx
0000747fd7fd27a0  push rdx
0000747fd7fd27a1  push rdi
0000747fd7fd27a2  push rsi
0000747fd7fd27a3  push r8
0000747fd7fd27a5  push r9
0000747fd7fd27a7  push r10
0000747fd7fd27a9  push r11
0000747fd7fd27ab  sub rsp, 0xF0
0000747fd7fd27b2  vmovaps [rsp], xmm0
0000747fd7fd27b7  vmovaps [rsp+0x10], xmm1
0000747fd7fd27bd  vmovaps [rsp+0x20], xmm2
0000747fd7fd27c3  vmovaps [rsp+0x30], xmm3
0000747fd7fd27c9  vmovaps [rsp+0x40], xmm4
0000747fd7fd27cf  vmovaps [rsp+0x50], xmm5
0000747fd7fd27d5  vmovaps [rsp+0x60], xmm6
0000747fd7fd27db  vmovaps [rsp+0x70], xmm7
0000747fd7fd27e1  vmovaps [rsp+0x80], xmm8
0000747fd7fd27ea  vmovaps [rsp+0x90], xmm9
0000747fd7fd27f3  vmovaps [rsp+0xA0], xmm10
0000747fd7fd27fc  vmovaps [rsp+0xB0], xmm11
0000747fd7fd2805  vmovaps [rsp+0xC0], xmm12
0000747fd7fd280e  vmovaps [rsp+0xD0], xmm13
0000747fd7fd2817  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2820  sub rsp, 0x30
0000747fd7fd2824  movaps [rsp], xmm14
0000747fd7fd2829  movaps [rsp+0x10], xmm6
0000747fd7fd282e  movaps [rsp+0x20], xmm2
0000747fd7fd2833  lea rdi, [rsp]
0000747fd7fd2837  mov esi, 0x00
0000747fd7fd283c  mov rax, 0x6055A0B6E530
0000747fd7fd2846  call rax
0000747fd7fd2848  movaps xmm14, [rsp]
0000747fd7fd284d  add rsp, 0x30
0000747fd7fd2851  vmovaps xmm0, [rsp]
0000747fd7fd2856  vmovaps xmm1, [rsp+0x10]
0000747fd7fd285c  vmovaps xmm2, [rsp+0x20]
0000747fd7fd2862  vmovaps xmm3, [rsp+0x30]
0000747fd7fd2868  vmovaps xmm4, [rsp+0x40]
0000747fd7fd286e  vmovaps xmm5, [rsp+0x50]
0000747fd7fd2874  vmovaps xmm6, [rsp+0x60]
0000747fd7fd287a  vmovaps xmm7, [rsp+0x70]
0000747fd7fd2880  vmovaps xmm8, [rsp+0x80]
0000747fd7fd2889  vmovaps xmm9, [rsp+0x90]
0000747fd7fd2892  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd289b  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd28a4  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd28ad  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd28b6  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd28bf  add rsp, 0xF0
0000747fd7fd28c6  pop r11
0000747fd7fd28c8  pop r10
0000747fd7fd28ca  pop r9
0000747fd7fd28cc  pop r8
0000747fd7fd28ce  pop rsi
0000747fd7fd28cf  pop rdi
0000747fd7fd28d0  pop rdx
0000747fd7fd28d1  pop rcx
0000747fd7fd28d2  pop rax
0000747fd7fd28d3  add rsp, 0x08
0000747fd7fd28d7  jmp 0x0000747FD7FCFD72
0000747fd7fd28dc  sub rsp, 0x08
0000747fd7fd28e0  push rax
0000747fd7fd28e1  push rcx
0000747fd7fd28e2  push rdx
0000747fd7fd28e3  push rdi
0000747fd7fd28e4  push rsi
0000747fd7fd28e5  push r8
0000747fd7fd28e7  push r9
0000747fd7fd28e9  push r10
0000747fd7fd28eb  push r11
0000747fd7fd28ed  sub rsp, 0xF0
0000747fd7fd28f4  vmovaps [rsp], xmm0
0000747fd7fd28f9  vmovaps [rsp+0x10], xmm1
0000747fd7fd28ff  vmovaps [rsp+0x20], xmm2
0000747fd7fd2905  vmovaps [rsp+0x30], xmm3
0000747fd7fd290b  vmovaps [rsp+0x40], xmm4
0000747fd7fd2911  vmovaps [rsp+0x50], xmm5
0000747fd7fd2917  vmovaps [rsp+0x60], xmm7
0000747fd7fd291d  vmovaps [rsp+0x70], xmm8
0000747fd7fd2923  vmovaps [rsp+0x80], xmm9
0000747fd7fd292c  vmovaps [rsp+0x90], xmm10
0000747fd7fd2935  vmovaps [rsp+0xA0], xmm11
0000747fd7fd293e  vmovaps [rsp+0xB0], xmm12
0000747fd7fd2947  vmovaps [rsp+0xC0], xmm13
0000747fd7fd2950  vmovaps [rsp+0xD0], xmm14
0000747fd7fd2959  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2962  sub rsp, 0x30
0000747fd7fd2966  movaps [rsp], xmm6
0000747fd7fd296a  movaps [rsp+0x10], xmm5
0000747fd7fd296f  movaps [rsp+0x20], xmm1
0000747fd7fd2974  lea rdi, [rsp]
0000747fd7fd2978  mov esi, 0x00
0000747fd7fd297d  mov rax, 0x6055A0B6E530
0000747fd7fd2987  call rax
0000747fd7fd2989  movaps xmm6, [rsp]
0000747fd7fd298d  add rsp, 0x30
0000747fd7fd2991  vmovaps xmm0, [rsp]
0000747fd7fd2996  vmovaps xmm1, [rsp+0x10]
0000747fd7fd299c  vmovaps xmm2, [rsp+0x20]
0000747fd7fd29a2  vmovaps xmm3, [rsp+0x30]
0000747fd7fd29a8  vmovaps xmm4, [rsp+0x40]
0000747fd7fd29ae  vmovaps xmm5, [rsp+0x50]
0000747fd7fd29b4  vmovaps xmm7, [rsp+0x60]
0000747fd7fd29ba  vmovaps xmm8, [rsp+0x70]
0000747fd7fd29c0  vmovaps xmm9, [rsp+0x80]
0000747fd7fd29c9  vmovaps xmm10, [rsp+0x90]
0000747fd7fd29d2  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd29db  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd29e4  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd29ed  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd29f6  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd29ff  add rsp, 0xF0
0000747fd7fd2a06  pop r11
0000747fd7fd2a08  pop r10
0000747fd7fd2a0a  pop r9
0000747fd7fd2a0c  pop r8
0000747fd7fd2a0e  pop rsi
0000747fd7fd2a0f  pop rdi
0000747fd7fd2a10  pop rdx
0000747fd7fd2a11  pop rcx
0000747fd7fd2a12  pop rax
0000747fd7fd2a13  add rsp, 0x08
0000747fd7fd2a17  jmp 0x0000747FD7FCFD98
0000747fd7fd2a1c  sub rsp, 0x08
0000747fd7fd2a20  push rax
0000747fd7fd2a21  push rcx
0000747fd7fd2a22  push rdx
0000747fd7fd2a23  push rdi
0000747fd7fd2a24  push rsi
0000747fd7fd2a25  push r8
0000747fd7fd2a27  push r9
0000747fd7fd2a29  push r10
0000747fd7fd2a2b  push r11
0000747fd7fd2a2d  sub rsp, 0xF0
0000747fd7fd2a34  vmovaps [rsp], xmm0
0000747fd7fd2a39  vmovaps [rsp+0x10], xmm2
0000747fd7fd2a3f  vmovaps [rsp+0x20], xmm3
0000747fd7fd2a45  vmovaps [rsp+0x30], xmm4
0000747fd7fd2a4b  vmovaps [rsp+0x40], xmm5
0000747fd7fd2a51  vmovaps [rsp+0x50], xmm6
0000747fd7fd2a57  vmovaps [rsp+0x60], xmm7
0000747fd7fd2a5d  vmovaps [rsp+0x70], xmm8
0000747fd7fd2a63  vmovaps [rsp+0x80], xmm9
0000747fd7fd2a6c  vmovaps [rsp+0x90], xmm10
0000747fd7fd2a75  vmovaps [rsp+0xA0], xmm11
0000747fd7fd2a7e  vmovaps [rsp+0xB0], xmm12
0000747fd7fd2a87  vmovaps [rsp+0xC0], xmm13
0000747fd7fd2a90  vmovaps [rsp+0xD0], xmm14
0000747fd7fd2a99  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2aa2  sub rsp, 0x30
0000747fd7fd2aa6  movaps [rsp], xmm1
0000747fd7fd2aaa  movaps [rsp+0x10], xmm5
0000747fd7fd2aaf  movaps [rsp+0x20], xmm13
0000747fd7fd2ab5  lea rdi, [rsp]
0000747fd7fd2ab9  mov esi, 0x00
0000747fd7fd2abe  mov rax, 0x6055A0B6E530
0000747fd7fd2ac8  call rax
0000747fd7fd2aca  movaps xmm1, [rsp]
0000747fd7fd2ace  add rsp, 0x30
0000747fd7fd2ad2  vmovaps xmm0, [rsp]
0000747fd7fd2ad7  vmovaps xmm2, [rsp+0x10]
0000747fd7fd2add  vmovaps xmm3, [rsp+0x20]
0000747fd7fd2ae3  vmovaps xmm4, [rsp+0x30]
0000747fd7fd2ae9  vmovaps xmm5, [rsp+0x40]
0000747fd7fd2aef  vmovaps xmm6, [rsp+0x50]
0000747fd7fd2af5  vmovaps xmm7, [rsp+0x60]
0000747fd7fd2afb  vmovaps xmm8, [rsp+0x70]
0000747fd7fd2b01  vmovaps xmm9, [rsp+0x80]
0000747fd7fd2b0a  vmovaps xmm10, [rsp+0x90]
0000747fd7fd2b13  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd2b1c  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd2b25  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd2b2e  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd2b37  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd2b40  add rsp, 0xF0
0000747fd7fd2b47  pop r11
0000747fd7fd2b49  pop r10
0000747fd7fd2b4b  pop r9
0000747fd7fd2b4d  pop r8
0000747fd7fd2b4f  pop rsi
0000747fd7fd2b50  pop rdi
0000747fd7fd2b51  pop rdx
0000747fd7fd2b52  pop rcx
0000747fd7fd2b53  pop rax
0000747fd7fd2b54  add rsp, 0x08
0000747fd7fd2b58  jmp 0x0000747FD7FCFDB6
0000747fd7fd2b5d  sub rsp, 0x08
0000747fd7fd2b61  push rax
0000747fd7fd2b62  push rcx
0000747fd7fd2b63  push rdx
0000747fd7fd2b64  push rdi
0000747fd7fd2b65  push rsi
0000747fd7fd2b66  push r8
0000747fd7fd2b68  push r9
0000747fd7fd2b6a  push r10
0000747fd7fd2b6c  push r11
0000747fd7fd2b6e  sub rsp, 0xF0
0000747fd7fd2b75  vmovaps [rsp], xmm0
0000747fd7fd2b7a  vmovaps [rsp+0x10], xmm1
0000747fd7fd2b80  vmovaps [rsp+0x20], xmm2
0000747fd7fd2b86  vmovaps [rsp+0x30], xmm3
0000747fd7fd2b8c  vmovaps [rsp+0x40], xmm4
0000747fd7fd2b92  vmovaps [rsp+0x50], xmm6
0000747fd7fd2b98  vmovaps [rsp+0x60], xmm7
0000747fd7fd2b9e  vmovaps [rsp+0x70], xmm8
0000747fd7fd2ba4  vmovaps [rsp+0x80], xmm9
0000747fd7fd2bad  vmovaps [rsp+0x90], xmm10
0000747fd7fd2bb6  vmovaps [rsp+0xA0], xmm11
0000747fd7fd2bbf  vmovaps [rsp+0xB0], xmm12
0000747fd7fd2bc8  vmovaps [rsp+0xC0], xmm13
0000747fd7fd2bd1  vmovaps [rsp+0xD0], xmm14
0000747fd7fd2bda  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2be3  sub rsp, 0x30
0000747fd7fd2be7  movaps [rsp], xmm5
0000747fd7fd2beb  movaps [rsp+0x10], xmm2
0000747fd7fd2bf0  movaps [rsp+0x20], xmm13
0000747fd7fd2bf6  lea rdi, [rsp]
0000747fd7fd2bfa  mov esi, 0x00
0000747fd7fd2bff  mov rax, 0x6055A0B6E530
0000747fd7fd2c09  call rax
0000747fd7fd2c0b  movaps xmm5, [rsp]
0000747fd7fd2c0f  add rsp, 0x30
0000747fd7fd2c13  vmovaps xmm0, [rsp]
0000747fd7fd2c18  vmovaps xmm1, [rsp+0x10]
0000747fd7fd2c1e  vmovaps xmm2, [rsp+0x20]
0000747fd7fd2c24  vmovaps xmm3, [rsp+0x30]
0000747fd7fd2c2a  vmovaps xmm4, [rsp+0x40]
0000747fd7fd2c30  vmovaps xmm6, [rsp+0x50]
0000747fd7fd2c36  vmovaps xmm7, [rsp+0x60]
0000747fd7fd2c3c  vmovaps xmm8, [rsp+0x70]
0000747fd7fd2c42  vmovaps xmm9, [rsp+0x80]
0000747fd7fd2c4b  vmovaps xmm10, [rsp+0x90]
0000747fd7fd2c54  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd2c5d  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd2c66  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd2c6f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd2c78  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd2c81  add rsp, 0xF0
0000747fd7fd2c88  pop r11
0000747fd7fd2c8a  pop r10
0000747fd7fd2c8c  pop r9
0000747fd7fd2c8e  pop r8
0000747fd7fd2c90  pop rsi
0000747fd7fd2c91  pop rdi
0000747fd7fd2c92  pop rdx
0000747fd7fd2c93  pop rcx
0000747fd7fd2c94  pop rax
0000747fd7fd2c95  add rsp, 0x08
0000747fd7fd2c99  jmp 0x0000747FD7FCFDEC
0000747fd7fd2c9e  sub rsp, 0x08
0000747fd7fd2ca2  push rax
0000747fd7fd2ca3  push rcx
0000747fd7fd2ca4  push rdx
0000747fd7fd2ca5  push rdi
0000747fd7fd2ca6  push rsi
0000747fd7fd2ca7  push r8
0000747fd7fd2ca9  push r9
0000747fd7fd2cab  push r10
0000747fd7fd2cad  push r11
0000747fd7fd2caf  sub rsp, 0xF0
0000747fd7fd2cb6  vmovaps [rsp], xmm0
0000747fd7fd2cbb  vmovaps [rsp+0x10], xmm1
0000747fd7fd2cc1  vmovaps [rsp+0x20], xmm2
0000747fd7fd2cc7  vmovaps [rsp+0x30], xmm3
0000747fd7fd2ccd  vmovaps [rsp+0x40], xmm4
0000747fd7fd2cd3  vmovaps [rsp+0x50], xmm5
0000747fd7fd2cd9  vmovaps [rsp+0x60], xmm6
0000747fd7fd2cdf  vmovaps [rsp+0x70], xmm7
0000747fd7fd2ce5  vmovaps [rsp+0x80], xmm8
0000747fd7fd2cee  vmovaps [rsp+0x90], xmm9
0000747fd7fd2cf7  vmovaps [rsp+0xA0], xmm10
0000747fd7fd2d00  vmovaps [rsp+0xB0], xmm11
0000747fd7fd2d09  vmovaps [rsp+0xC0], xmm12
0000747fd7fd2d12  vmovaps [rsp+0xD0], xmm14
0000747fd7fd2d1b  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2d24  sub rsp, 0x30
0000747fd7fd2d28  movaps [rsp], xmm13
0000747fd7fd2d2d  movaps [rsp+0x10], xmm10
0000747fd7fd2d33  movaps [rsp+0x20], xmm1
0000747fd7fd2d38  lea rdi, [rsp]
0000747fd7fd2d3c  mov esi, 0x00
0000747fd7fd2d41  mov rax, 0x6055A0B6E530
0000747fd7fd2d4b  call rax
0000747fd7fd2d4d  movaps xmm13, [rsp]
0000747fd7fd2d52  add rsp, 0x30
0000747fd7fd2d56  vmovaps xmm0, [rsp]
0000747fd7fd2d5b  vmovaps xmm1, [rsp+0x10]
0000747fd7fd2d61  vmovaps xmm2, [rsp+0x20]
0000747fd7fd2d67  vmovaps xmm3, [rsp+0x30]
0000747fd7fd2d6d  vmovaps xmm4, [rsp+0x40]
0000747fd7fd2d73  vmovaps xmm5, [rsp+0x50]
0000747fd7fd2d79  vmovaps xmm6, [rsp+0x60]
0000747fd7fd2d7f  vmovaps xmm7, [rsp+0x70]
0000747fd7fd2d85  vmovaps xmm8, [rsp+0x80]
0000747fd7fd2d8e  vmovaps xmm9, [rsp+0x90]
0000747fd7fd2d97  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd2da0  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd2da9  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd2db2  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd2dbb  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd2dc4  add rsp, 0xF0
0000747fd7fd2dcb  pop r11
0000747fd7fd2dcd  pop r10
0000747fd7fd2dcf  pop r9
0000747fd7fd2dd1  pop r8
0000747fd7fd2dd3  pop rsi
0000747fd7fd2dd4  pop rdi
0000747fd7fd2dd5  pop rdx
0000747fd7fd2dd6  pop rcx
0000747fd7fd2dd7  pop rax
0000747fd7fd2dd8  add rsp, 0x08
0000747fd7fd2ddc  jmp 0x0000747FD7FCFE15
0000747fd7fd2de1  sub rsp, 0x08
0000747fd7fd2de5  push rax
0000747fd7fd2de6  push rcx
0000747fd7fd2de7  push rdx
0000747fd7fd2de8  push rdi
0000747fd7fd2de9  push rsi
0000747fd7fd2dea  push r8
0000747fd7fd2dec  push r9
0000747fd7fd2dee  push r10
0000747fd7fd2df0  push r11
0000747fd7fd2df2  sub rsp, 0xF0
0000747fd7fd2df9  vmovaps [rsp], xmm0
0000747fd7fd2dfe  vmovaps [rsp+0x10], xmm2
0000747fd7fd2e04  vmovaps [rsp+0x20], xmm3
0000747fd7fd2e0a  vmovaps [rsp+0x30], xmm4
0000747fd7fd2e10  vmovaps [rsp+0x40], xmm5
0000747fd7fd2e16  vmovaps [rsp+0x50], xmm6
0000747fd7fd2e1c  vmovaps [rsp+0x60], xmm7
0000747fd7fd2e22  vmovaps [rsp+0x70], xmm8
0000747fd7fd2e28  vmovaps [rsp+0x80], xmm9
0000747fd7fd2e31  vmovaps [rsp+0x90], xmm10
0000747fd7fd2e3a  vmovaps [rsp+0xA0], xmm11
0000747fd7fd2e43  vmovaps [rsp+0xB0], xmm12
0000747fd7fd2e4c  vmovaps [rsp+0xC0], xmm13
0000747fd7fd2e55  vmovaps [rsp+0xD0], xmm14
0000747fd7fd2e5e  vmovaps [rsp+0xE0], xmm15
0000747fd7fd2e67  sub rsp, 0x30
0000747fd7fd2e6b  movaps [rsp], xmm1
0000747fd7fd2e6f  movaps [rsp+0x10], xmm15
0000747fd7fd2e75  movaps [rsp+0x20], xmm10
0000747fd7fd2e7b  lea rdi, [rsp]
0000747fd7fd2e7f  mov esi, 0x00
0000747fd7fd2e84  mov rax, 0x6055A0B6E530
0000747fd7fd2e8e  call rax
0000747fd7fd2e90  movaps xmm1, [rsp]
0000747fd7fd2e94  add rsp, 0x30
0000747fd7fd2e98  vmovaps xmm0, [rsp]
0000747fd7fd2e9d  vmovaps xmm2, [rsp+0x10]
0000747fd7fd2ea3  vmovaps xmm3, [rsp+0x20]
0000747fd7fd2ea9  vmovaps xmm4, [rsp+0x30]
0000747fd7fd2eaf  vmovaps xmm5, [rsp+0x40]
0000747fd7fd2eb5  vmovaps xmm6, [rsp+0x50]
0000747fd7fd2ebb  vmovaps xmm7, [rsp+0x60]
0000747fd7fd2ec1  vmovaps xmm8, [rsp+0x70]
0000747fd7fd2ec7  vmovaps xmm9, [rsp+0x80]
0000747fd7fd2ed0  vmovaps xmm10, [rsp+0x90]
0000747fd7fd2ed9  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd2ee2  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd2eeb  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd2ef4  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd2efd  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd2f06  add rsp, 0xF0
0000747fd7fd2f0d  pop r11
0000747fd7fd2f0f  pop r10
0000747fd7fd2f11  pop r9
0000747fd7fd2f13  pop r8
0000747fd7fd2f15  pop rsi
0000747fd7fd2f16  pop rdi
0000747fd7fd2f17  pop rdx
0000747fd7fd2f18  pop rcx
0000747fd7fd2f19  pop rax
0000747fd7fd2f1a  add rsp, 0x08
0000747fd7fd2f1e  jmp 0x0000747FD7FCFE34
0000747fd7fd2f23  sub rsp, 0x08
0000747fd7fd2f27  push rax
0000747fd7fd2f28  push rcx
0000747fd7fd2f29  push rdx
0000747fd7fd2f2a  push rdi
0000747fd7fd2f2b  push rsi
0000747fd7fd2f2c  push r8
0000747fd7fd2f2e  push r9
0000747fd7fd2f30  push r10
0000747fd7fd2f32  push r11
0000747fd7fd2f34  sub rsp, 0xF0
0000747fd7fd2f3b  vmovaps [rsp], xmm0
0000747fd7fd2f40  vmovaps [rsp+0x10], xmm1
0000747fd7fd2f46  vmovaps [rsp+0x20], xmm2
0000747fd7fd2f4c  vmovaps [rsp+0x30], xmm3
0000747fd7fd2f52  vmovaps [rsp+0x40], xmm4
0000747fd7fd2f58  vmovaps [rsp+0x50], xmm5
0000747fd7fd2f5e  vmovaps [rsp+0x60], xmm6
0000747fd7fd2f64  vmovaps [rsp+0x70], xmm7
0000747fd7fd2f6a  vmovaps [rsp+0x80], xmm8
0000747fd7fd2f73  vmovaps [rsp+0x90], xmm9
0000747fd7fd2f7c  vmovaps [rsp+0xA0], xmm10
0000747fd7fd2f85  vmovaps [rsp+0xB0], xmm11
0000747fd7fd2f8e  vmovaps [rsp+0xC0], xmm12
0000747fd7fd2f97  vmovaps [rsp+0xD0], xmm13
0000747fd7fd2fa0  vmovaps [rsp+0xE0], xmm14
0000747fd7fd2fa9  sub rsp, 0x30
0000747fd7fd2fad  movaps [rsp], xmm15
0000747fd7fd2fb2  movaps [rsp+0x10], xmm10
0000747fd7fd2fb8  movaps [rsp+0x20], xmm11
0000747fd7fd2fbe  lea rdi, [rsp]
0000747fd7fd2fc2  mov esi, 0x00
0000747fd7fd2fc7  mov rax, 0x6055A0B6E530
0000747fd7fd2fd1  call rax
0000747fd7fd2fd3  movaps xmm15, [rsp]
0000747fd7fd2fd8  add rsp, 0x30
0000747fd7fd2fdc  vmovaps xmm0, [rsp]
0000747fd7fd2fe1  vmovaps xmm1, [rsp+0x10]
0000747fd7fd2fe7  vmovaps xmm2, [rsp+0x20]
0000747fd7fd2fed  vmovaps xmm3, [rsp+0x30]
0000747fd7fd2ff3  vmovaps xmm4, [rsp+0x40]
0000747fd7fd2ff9  vmovaps xmm5, [rsp+0x50]
0000747fd7fd2fff  vmovaps xmm6, [rsp+0x60]
0000747fd7fd3005  vmovaps xmm7, [rsp+0x70]
0000747fd7fd300b  vmovaps xmm8, [rsp+0x80]
0000747fd7fd3014  vmovaps xmm9, [rsp+0x90]
0000747fd7fd301d  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd3026  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd302f  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd3038  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd3041  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd304a  add rsp, 0xF0
0000747fd7fd3051  pop r11
0000747fd7fd3053  pop r10
0000747fd7fd3055  pop r9
0000747fd7fd3057  pop r8
0000747fd7fd3059  pop rsi
0000747fd7fd305a  pop rdi
0000747fd7fd305b  pop rdx
0000747fd7fd305c  pop rcx
0000747fd7fd305d  pop rax
0000747fd7fd305e  add rsp, 0x08
0000747fd7fd3062  jmp 0x0000747FD7FCFE57
0000747fd7fd3067  sub rsp, 0x08
0000747fd7fd306b  push rax
0000747fd7fd306c  push rcx
0000747fd7fd306d  push rdx
0000747fd7fd306e  push rdi
0000747fd7fd306f  push rsi
0000747fd7fd3070  push r8
0000747fd7fd3072  push r9
0000747fd7fd3074  push r10
0000747fd7fd3076  push r11
0000747fd7fd3078  sub rsp, 0xF0
0000747fd7fd307f  vmovaps [rsp], xmm0
0000747fd7fd3084  vmovaps [rsp+0x10], xmm1
0000747fd7fd308a  vmovaps [rsp+0x20], xmm2
0000747fd7fd3090  vmovaps [rsp+0x30], xmm3
0000747fd7fd3096  vmovaps [rsp+0x40], xmm4
0000747fd7fd309c  vmovaps [rsp+0x50], xmm5
0000747fd7fd30a2  vmovaps [rsp+0x60], xmm6
0000747fd7fd30a8  vmovaps [rsp+0x70], xmm7
0000747fd7fd30ae  vmovaps [rsp+0x80], xmm8
0000747fd7fd30b7  vmovaps [rsp+0x90], xmm9
0000747fd7fd30c0  vmovaps [rsp+0xA0], xmm11
0000747fd7fd30c9  vmovaps [rsp+0xB0], xmm12
0000747fd7fd30d2  vmovaps [rsp+0xC0], xmm13
0000747fd7fd30db  vmovaps [rsp+0xD0], xmm14
0000747fd7fd30e4  vmovaps [rsp+0xE0], xmm15
0000747fd7fd30ed  sub rsp, 0x30
0000747fd7fd30f1  movaps [rsp], xmm10
0000747fd7fd30f6  movaps [rsp+0x10], xmm12
0000747fd7fd30fc  movaps [rsp+0x20], xmm11
0000747fd7fd3102  lea rdi, [rsp]
0000747fd7fd3106  mov esi, 0x00
0000747fd7fd310b  mov rax, 0x6055A0B6E530
0000747fd7fd3115  call rax
0000747fd7fd3117  movaps xmm10, [rsp]
0000747fd7fd311c  add rsp, 0x30
0000747fd7fd3120  vmovaps xmm0, [rsp]
0000747fd7fd3125  vmovaps xmm1, [rsp+0x10]
0000747fd7fd312b  vmovaps xmm2, [rsp+0x20]
0000747fd7fd3131  vmovaps xmm3, [rsp+0x30]
0000747fd7fd3137  vmovaps xmm4, [rsp+0x40]
0000747fd7fd313d  vmovaps xmm5, [rsp+0x50]
0000747fd7fd3143  vmovaps xmm6, [rsp+0x60]
0000747fd7fd3149  vmovaps xmm7, [rsp+0x70]
0000747fd7fd314f  vmovaps xmm8, [rsp+0x80]
0000747fd7fd3158  vmovaps xmm9, [rsp+0x90]
0000747fd7fd3161  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd316a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd3173  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd317c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd3185  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd318e  add rsp, 0xF0
0000747fd7fd3195  pop r11
0000747fd7fd3197  pop r10
0000747fd7fd3199  pop r9
0000747fd7fd319b  pop r8
0000747fd7fd319d  pop rsi
0000747fd7fd319e  pop rdi
0000747fd7fd319f  pop rdx
0000747fd7fd31a0  pop rcx
0000747fd7fd31a1  pop rax
0000747fd7fd31a2  add rsp, 0x08
0000747fd7fd31a6  jmp 0x0000747FD7FCFE80
0000747fd7fd31ab  sub rsp, 0x08
0000747fd7fd31af  push rax
0000747fd7fd31b0  push rcx
0000747fd7fd31b1  push rdx
0000747fd7fd31b2  push rdi
0000747fd7fd31b3  push rsi
0000747fd7fd31b4  push r8
0000747fd7fd31b6  push r9
0000747fd7fd31b8  push r10
0000747fd7fd31ba  push r11
0000747fd7fd31bc  sub rsp, 0xF0
0000747fd7fd31c3  vmovaps [rsp], xmm0
0000747fd7fd31c8  vmovaps [rsp+0x10], xmm1
0000747fd7fd31ce  vmovaps [rsp+0x20], xmm2
0000747fd7fd31d4  vmovaps [rsp+0x30], xmm3
0000747fd7fd31da  vmovaps [rsp+0x40], xmm4
0000747fd7fd31e0  vmovaps [rsp+0x50], xmm5
0000747fd7fd31e6  vmovaps [rsp+0x60], xmm6
0000747fd7fd31ec  vmovaps [rsp+0x70], xmm7
0000747fd7fd31f2  vmovaps [rsp+0x80], xmm8
0000747fd7fd31fb  vmovaps [rsp+0x90], xmm9
0000747fd7fd3204  vmovaps [rsp+0xA0], xmm10
0000747fd7fd320d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd3216  vmovaps [rsp+0xC0], xmm13
0000747fd7fd321f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd3228  vmovaps [rsp+0xE0], xmm15
0000747fd7fd3231  sub rsp, 0x30
0000747fd7fd3235  movaps [rsp], xmm11
0000747fd7fd323a  movaps [rsp+0x10], xmm2
0000747fd7fd323f  movaps [rsp+0x20], xmm12
0000747fd7fd3245  lea rdi, [rsp]
0000747fd7fd3249  mov esi, 0x00
0000747fd7fd324e  mov rax, 0x6055A0B6E530
0000747fd7fd3258  call rax
0000747fd7fd325a  movaps xmm11, [rsp]
0000747fd7fd325f  add rsp, 0x30
0000747fd7fd3263  vmovaps xmm0, [rsp]
0000747fd7fd3268  vmovaps xmm1, [rsp+0x10]
0000747fd7fd326e  vmovaps xmm2, [rsp+0x20]
0000747fd7fd3274  vmovaps xmm3, [rsp+0x30]
0000747fd7fd327a  vmovaps xmm4, [rsp+0x40]
0000747fd7fd3280  vmovaps xmm5, [rsp+0x50]
0000747fd7fd3286  vmovaps xmm6, [rsp+0x60]
0000747fd7fd328c  vmovaps xmm7, [rsp+0x70]
0000747fd7fd3292  vmovaps xmm8, [rsp+0x80]
0000747fd7fd329b  vmovaps xmm9, [rsp+0x90]
0000747fd7fd32a4  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd32ad  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd32b6  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd32bf  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd32c8  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd32d1  add rsp, 0xF0
0000747fd7fd32d8  pop r11
0000747fd7fd32da  pop r10
0000747fd7fd32dc  pop r9
0000747fd7fd32de  pop r8
0000747fd7fd32e0  pop rsi
0000747fd7fd32e1  pop rdi
0000747fd7fd32e2  pop rdx
0000747fd7fd32e3  pop rcx
0000747fd7fd32e4  pop rax
0000747fd7fd32e5  add rsp, 0x08
0000747fd7fd32e9  jmp 0x0000747FD7FCFEB8
0000747fd7fd32ee  sub rsp, 0x08
0000747fd7fd32f2  push rax
0000747fd7fd32f3  push rcx
0000747fd7fd32f4  push rdx
0000747fd7fd32f5  push rdi
0000747fd7fd32f6  push rsi
0000747fd7fd32f7  push r8
0000747fd7fd32f9  push r9
0000747fd7fd32fb  push r10
0000747fd7fd32fd  push r11
0000747fd7fd32ff  sub rsp, 0xF0
0000747fd7fd3306  vmovaps [rsp], xmm0
0000747fd7fd330b  vmovaps [rsp+0x10], xmm2
0000747fd7fd3311  vmovaps [rsp+0x20], xmm3
0000747fd7fd3317  vmovaps [rsp+0x30], xmm4
0000747fd7fd331d  vmovaps [rsp+0x40], xmm5
0000747fd7fd3323  vmovaps [rsp+0x50], xmm6
0000747fd7fd3329  vmovaps [rsp+0x60], xmm7
0000747fd7fd332f  vmovaps [rsp+0x70], xmm8
0000747fd7fd3335  vmovaps [rsp+0x80], xmm9
0000747fd7fd333e  vmovaps [rsp+0x90], xmm10
0000747fd7fd3347  vmovaps [rsp+0xA0], xmm11
0000747fd7fd3350  vmovaps [rsp+0xB0], xmm12
0000747fd7fd3359  vmovaps [rsp+0xC0], xmm13
0000747fd7fd3362  vmovaps [rsp+0xD0], xmm14
0000747fd7fd336b  vmovaps [rsp+0xE0], xmm15
0000747fd7fd3374  sub rsp, 0x30
0000747fd7fd3378  movaps [rsp], xmm1
0000747fd7fd337c  movaps [rsp+0x10], xmm14
0000747fd7fd3382  movaps [rsp+0x20], xmm6
0000747fd7fd3387  lea rdi, [rsp]
0000747fd7fd338b  mov esi, 0x00
0000747fd7fd3390  mov rax, 0x6055A0B6E530
0000747fd7fd339a  call rax
0000747fd7fd339c  movaps xmm1, [rsp]
0000747fd7fd33a0  add rsp, 0x30
0000747fd7fd33a4  vmovaps xmm0, [rsp]
0000747fd7fd33a9  vmovaps xmm2, [rsp+0x10]
0000747fd7fd33af  vmovaps xmm3, [rsp+0x20]
0000747fd7fd33b5  vmovaps xmm4, [rsp+0x30]
0000747fd7fd33bb  vmovaps xmm5, [rsp+0x40]
0000747fd7fd33c1  vmovaps xmm6, [rsp+0x50]
0000747fd7fd33c7  vmovaps xmm7, [rsp+0x60]
0000747fd7fd33cd  vmovaps xmm8, [rsp+0x70]
0000747fd7fd33d3  vmovaps xmm9, [rsp+0x80]
0000747fd7fd33dc  vmovaps xmm10, [rsp+0x90]
0000747fd7fd33e5  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd33ee  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd33f7  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd3400  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd3409  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd3412  add rsp, 0xF0
0000747fd7fd3419  pop r11
0000747fd7fd341b  pop r10
0000747fd7fd341d  pop r9
0000747fd7fd341f  pop r8
0000747fd7fd3421  pop rsi
0000747fd7fd3422  pop rdi
0000747fd7fd3423  pop rdx
0000747fd7fd3424  pop rcx
0000747fd7fd3425  pop rax
0000747fd7fd3426  add rsp, 0x08
0000747fd7fd342a  jmp 0x0000747FD7FCFED1
0000747fd7fd342f  sub rsp, 0x08
0000747fd7fd3433  push rax
0000747fd7fd3434  push rcx
0000747fd7fd3435  push rdx
0000747fd7fd3436  push rdi
0000747fd7fd3437  push rsi
0000747fd7fd3438  push r8
0000747fd7fd343a  push r9
0000747fd7fd343c  push r10
0000747fd7fd343e  push r11
0000747fd7fd3440  sub rsp, 0xF0
0000747fd7fd3447  vmovaps [rsp], xmm0
0000747fd7fd344c  vmovaps [rsp+0x10], xmm1
0000747fd7fd3452  vmovaps [rsp+0x20], xmm2
0000747fd7fd3458  vmovaps [rsp+0x30], xmm3
0000747fd7fd345e  vmovaps [rsp+0x40], xmm4
0000747fd7fd3464  vmovaps [rsp+0x50], xmm5
0000747fd7fd346a  vmovaps [rsp+0x60], xmm6
0000747fd7fd3470  vmovaps [rsp+0x70], xmm7
0000747fd7fd3476  vmovaps [rsp+0x80], xmm8
0000747fd7fd347f  vmovaps [rsp+0x90], xmm9
0000747fd7fd3488  vmovaps [rsp+0xA0], xmm10
0000747fd7fd3491  vmovaps [rsp+0xB0], xmm11
0000747fd7fd349a  vmovaps [rsp+0xC0], xmm12
0000747fd7fd34a3  vmovaps [rsp+0xD0], xmm13
0000747fd7fd34ac  vmovaps [rsp+0xE0], xmm15
0000747fd7fd34b5  sub rsp, 0x30
0000747fd7fd34b9  movaps [rsp], xmm14
0000747fd7fd34be  movaps [rsp+0x10], xmm12
0000747fd7fd34c4  movaps [rsp+0x20], xmm5
0000747fd7fd34c9  lea rdi, [rsp]
0000747fd7fd34cd  mov esi, 0x00
0000747fd7fd34d2  mov rax, 0x6055A0B6E530
0000747fd7fd34dc  call rax
0000747fd7fd34de  movaps xmm14, [rsp]
0000747fd7fd34e3  add rsp, 0x30
0000747fd7fd34e7  vmovaps xmm0, [rsp]
0000747fd7fd34ec  vmovaps xmm1, [rsp+0x10]
0000747fd7fd34f2  vmovaps xmm2, [rsp+0x20]
0000747fd7fd34f8  vmovaps xmm3, [rsp+0x30]
0000747fd7fd34fe  vmovaps xmm4, [rsp+0x40]
0000747fd7fd3504  vmovaps xmm5, [rsp+0x50]
0000747fd7fd350a  vmovaps xmm6, [rsp+0x60]
0000747fd7fd3510  vmovaps xmm7, [rsp+0x70]
0000747fd7fd3516  vmovaps xmm8, [rsp+0x80]
0000747fd7fd351f  vmovaps xmm9, [rsp+0x90]
0000747fd7fd3528  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd3531  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd353a  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd3543  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd354c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd3555  add rsp, 0xF0
0000747fd7fd355c  pop r11
0000747fd7fd355e  pop r10
0000747fd7fd3560  pop r9
0000747fd7fd3562  pop r8
0000747fd7fd3564  pop rsi
0000747fd7fd3565  pop rdi
0000747fd7fd3566  pop rdx
0000747fd7fd3567  pop rcx
0000747fd7fd3568  pop rax
0000747fd7fd3569  add rsp, 0x08
0000747fd7fd356d  jmp 0x0000747FD7FCFEF1
0000747fd7fd3572  sub rsp, 0x08
0000747fd7fd3576  push rax
0000747fd7fd3577  push rcx
0000747fd7fd3578  push rdx
0000747fd7fd3579  push rdi
0000747fd7fd357a  push rsi
0000747fd7fd357b  push r8
0000747fd7fd357d  push r9
0000747fd7fd357f  push r10
0000747fd7fd3581  push r11
0000747fd7fd3583  sub rsp, 0xF0
0000747fd7fd358a  vmovaps [rsp], xmm0
0000747fd7fd358f  vmovaps [rsp+0x10], xmm1
0000747fd7fd3595  vmovaps [rsp+0x20], xmm2
0000747fd7fd359b  vmovaps [rsp+0x30], xmm3
0000747fd7fd35a1  vmovaps [rsp+0x40], xmm4
0000747fd7fd35a7  vmovaps [rsp+0x50], xmm5
0000747fd7fd35ad  vmovaps [rsp+0x60], xmm7
0000747fd7fd35b3  vmovaps [rsp+0x70], xmm8
0000747fd7fd35b9  vmovaps [rsp+0x80], xmm9
0000747fd7fd35c2  vmovaps [rsp+0x90], xmm10
0000747fd7fd35cb  vmovaps [rsp+0xA0], xmm11
0000747fd7fd35d4  vmovaps [rsp+0xB0], xmm12
0000747fd7fd35dd  vmovaps [rsp+0xC0], xmm13
0000747fd7fd35e6  vmovaps [rsp+0xD0], xmm14
0000747fd7fd35ef  vmovaps [rsp+0xE0], xmm15
0000747fd7fd35f8  sub rsp, 0x30
0000747fd7fd35fc  movaps [rsp], xmm6
0000747fd7fd3600  movaps [rsp+0x10], xmm9
0000747fd7fd3606  movaps [rsp+0x20], xmm12
0000747fd7fd360c  lea rdi, [rsp]
0000747fd7fd3610  mov esi, 0x00
0000747fd7fd3615  mov rax, 0x6055A0B6E530
0000747fd7fd361f  call rax
0000747fd7fd3621  movaps xmm6, [rsp]
0000747fd7fd3625  add rsp, 0x30
0000747fd7fd3629  vmovaps xmm0, [rsp]
0000747fd7fd362e  vmovaps xmm1, [rsp+0x10]
0000747fd7fd3634  vmovaps xmm2, [rsp+0x20]
0000747fd7fd363a  vmovaps xmm3, [rsp+0x30]
0000747fd7fd3640  vmovaps xmm4, [rsp+0x40]
0000747fd7fd3646  vmovaps xmm5, [rsp+0x50]
0000747fd7fd364c  vmovaps xmm7, [rsp+0x60]
0000747fd7fd3652  vmovaps xmm8, [rsp+0x70]
0000747fd7fd3658  vmovaps xmm9, [rsp+0x80]
0000747fd7fd3661  vmovaps xmm10, [rsp+0x90]
0000747fd7fd366a  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd3673  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd367c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd3685  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd368e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd3697  add rsp, 0xF0
0000747fd7fd369e  pop r11
0000747fd7fd36a0  pop r10
0000747fd7fd36a2  pop r9
0000747fd7fd36a4  pop r8
0000747fd7fd36a6  pop rsi
0000747fd7fd36a7  pop rdi
0000747fd7fd36a8  pop rdx
0000747fd7fd36a9  pop rcx
0000747fd7fd36aa  pop rax
0000747fd7fd36ab  add rsp, 0x08
0000747fd7fd36af  jmp 0x0000747FD7FCFF19
0000747fd7fd36b4  sub rsp, 0x08
0000747fd7fd36b8  push rax
0000747fd7fd36b9  push rcx
0000747fd7fd36ba  push rdx
0000747fd7fd36bb  push rdi
0000747fd7fd36bc  push rsi
0000747fd7fd36bd  push r8
0000747fd7fd36bf  push r9
0000747fd7fd36c1  push r10
0000747fd7fd36c3  push r11
0000747fd7fd36c5  sub rsp, 0xF0
0000747fd7fd36cc  vmovaps [rsp], xmm0
0000747fd7fd36d1  vmovaps [rsp+0x10], xmm1
0000747fd7fd36d7  vmovaps [rsp+0x20], xmm2
0000747fd7fd36dd  vmovaps [rsp+0x30], xmm3
0000747fd7fd36e3  vmovaps [rsp+0x40], xmm4
0000747fd7fd36e9  vmovaps [rsp+0x50], xmm5
0000747fd7fd36ef  vmovaps [rsp+0x60], xmm6
0000747fd7fd36f5  vmovaps [rsp+0x70], xmm7
0000747fd7fd36fb  vmovaps [rsp+0x80], xmm8
0000747fd7fd3704  vmovaps [rsp+0x90], xmm9
0000747fd7fd370d  vmovaps [rsp+0xA0], xmm10
0000747fd7fd3716  vmovaps [rsp+0xB0], xmm11
0000747fd7fd371f  vmovaps [rsp+0xC0], xmm13
0000747fd7fd3728  vmovaps [rsp+0xD0], xmm14
0000747fd7fd3731  vmovaps [rsp+0xE0], xmm15
0000747fd7fd373a  sub rsp, 0x30
0000747fd7fd373e  movaps [rsp], xmm12
0000747fd7fd3743  movaps [rsp+0x10], xmm15
0000747fd7fd3749  movaps [rsp+0x20], xmm13
0000747fd7fd374f  lea rdi, [rsp]
0000747fd7fd3753  mov esi, 0x00
0000747fd7fd3758  mov rax, 0x6055A0B6E530
0000747fd7fd3762  call rax
0000747fd7fd3764  movaps xmm12, [rsp]
0000747fd7fd3769  add rsp, 0x30
0000747fd7fd376d  vmovaps xmm0, [rsp]
0000747fd7fd3772  vmovaps xmm1, [rsp+0x10]
0000747fd7fd3778  vmovaps xmm2, [rsp+0x20]
0000747fd7fd377e  vmovaps xmm3, [rsp+0x30]
0000747fd7fd3784  vmovaps xmm4, [rsp+0x40]
0000747fd7fd378a  vmovaps xmm5, [rsp+0x50]
0000747fd7fd3790  vmovaps xmm6, [rsp+0x60]
0000747fd7fd3796  vmovaps xmm7, [rsp+0x70]
0000747fd7fd379c  vmovaps xmm8, [rsp+0x80]
0000747fd7fd37a5  vmovaps xmm9, [rsp+0x90]
0000747fd7fd37ae  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd37b7  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd37c0  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd37c9  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd37d2  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd37db  add rsp, 0xF0
0000747fd7fd37e2  pop r11
0000747fd7fd37e4  pop r10
0000747fd7fd37e6  pop r9
0000747fd7fd37e8  pop r8
0000747fd7fd37ea  pop rsi
0000747fd7fd37eb  pop rdi
0000747fd7fd37ec  pop rdx
0000747fd7fd37ed  pop rcx
0000747fd7fd37ee  pop rax
0000747fd7fd37ef  add rsp, 0x08
0000747fd7fd37f3  jmp 0x0000747FD7FCFF34
0000747fd7fd37f8  sub rsp, 0x08
0000747fd7fd37fc  push rax
0000747fd7fd37fd  push rcx
0000747fd7fd37fe  push rdx
0000747fd7fd37ff  push rdi
0000747fd7fd3800  push rsi
0000747fd7fd3801  push r8
0000747fd7fd3803  push r9
0000747fd7fd3805  push r10
0000747fd7fd3807  push r11
0000747fd7fd3809  sub rsp, 0xF0
0000747fd7fd3810  vmovaps [rsp], xmm0
0000747fd7fd3815  vmovaps [rsp+0x10], xmm1
0000747fd7fd381b  vmovaps [rsp+0x20], xmm2
0000747fd7fd3821  vmovaps [rsp+0x30], xmm3
0000747fd7fd3827  vmovaps [rsp+0x40], xmm4
0000747fd7fd382d  vmovaps [rsp+0x50], xmm5
0000747fd7fd3833  vmovaps [rsp+0x60], xmm6
0000747fd7fd3839  vmovaps [rsp+0x70], xmm7
0000747fd7fd383f  vmovaps [rsp+0x80], xmm8
0000747fd7fd3848  vmovaps [rsp+0x90], xmm9
0000747fd7fd3851  vmovaps [rsp+0xA0], xmm10
0000747fd7fd385a  vmovaps [rsp+0xB0], xmm11
0000747fd7fd3863  vmovaps [rsp+0xC0], xmm12
0000747fd7fd386c  vmovaps [rsp+0xD0], xmm13
0000747fd7fd3875  vmovaps [rsp+0xE0], xmm14
0000747fd7fd387e  sub rsp, 0x30
0000747fd7fd3882  movaps [rsp], xmm15
0000747fd7fd3887  movaps [rsp+0x10], xmm13
0000747fd7fd388d  movaps [rsp+0x20], xmm10
0000747fd7fd3893  lea rdi, [rsp]
0000747fd7fd3897  mov esi, 0x00
0000747fd7fd389c  mov rax, 0x6055A0B6E530
0000747fd7fd38a6  call rax
0000747fd7fd38a8  movaps xmm15, [rsp]
0000747fd7fd38ad  add rsp, 0x30
0000747fd7fd38b1  vmovaps xmm0, [rsp]
0000747fd7fd38b6  vmovaps xmm1, [rsp+0x10]
0000747fd7fd38bc  vmovaps xmm2, [rsp+0x20]
0000747fd7fd38c2  vmovaps xmm3, [rsp+0x30]
0000747fd7fd38c8  vmovaps xmm4, [rsp+0x40]
0000747fd7fd38ce  vmovaps xmm5, [rsp+0x50]
0000747fd7fd38d4  vmovaps xmm6, [rsp+0x60]
0000747fd7fd38da  vmovaps xmm7, [rsp+0x70]
0000747fd7fd38e0  vmovaps xmm8, [rsp+0x80]
0000747fd7fd38e9  vmovaps xmm9, [rsp+0x90]
0000747fd7fd38f2  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd38fb  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd3904  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd390d  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd3916  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd391f  add rsp, 0xF0
0000747fd7fd3926  pop r11
0000747fd7fd3928  pop r10
0000747fd7fd392a  pop r9
0000747fd7fd392c  pop r8
0000747fd7fd392e  pop rsi
0000747fd7fd392f  pop rdi
0000747fd7fd3930  pop rdx
0000747fd7fd3931  pop rcx
0000747fd7fd3932  pop rax
0000747fd7fd3933  add rsp, 0x08
0000747fd7fd3937  jmp 0x0000747FD7FCFF55
0000747fd7fd393c  call 0x0000747FD7E0C260
0000747fd7fd3941  jmp 0x0000747FD7FCFFB0
0000747fd7fd3946  sub rsp, 0x08
0000747fd7fd394a  push rax
0000747fd7fd394b  push rcx
0000747fd7fd394c  push rdx
0000747fd7fd394d  push rdi
0000747fd7fd394e  push rsi
0000747fd7fd394f  push r8
0000747fd7fd3951  push r9
0000747fd7fd3953  push r10
0000747fd7fd3955  push r11
0000747fd7fd3957  sub rsp, 0xF0
0000747fd7fd395e  vmovaps [rsp], xmm0
0000747fd7fd3963  vmovaps [rsp+0x10], xmm1
0000747fd7fd3969  vmovaps [rsp+0x20], xmm2
0000747fd7fd396f  vmovaps [rsp+0x30], xmm3
0000747fd7fd3975  vmovaps [rsp+0x40], xmm4
0000747fd7fd397b  vmovaps [rsp+0x50], xmm5
0000747fd7fd3981  vmovaps [rsp+0x60], xmm6
0000747fd7fd3987  vmovaps [rsp+0x70], xmm7
0000747fd7fd398d  vmovaps [rsp+0x80], xmm8
0000747fd7fd3996  vmovaps [rsp+0x90], xmm10
0000747fd7fd399f  vmovaps [rsp+0xA0], xmm11
0000747fd7fd39a8  vmovaps [rsp+0xB0], xmm12
0000747fd7fd39b1  vmovaps [rsp+0xC0], xmm13
0000747fd7fd39ba  vmovaps [rsp+0xD0], xmm14
0000747fd7fd39c3  vmovaps [rsp+0xE0], xmm15
0000747fd7fd39cc  sub rsp, 0x30
0000747fd7fd39d0  movaps [rsp], xmm9
0000747fd7fd39d5  movaps [rsp+0x10], xmm8
0000747fd7fd39db  movaps [rsp+0x20], xmm10
0000747fd7fd39e1  lea rdi, [rsp]
0000747fd7fd39e5  mov esi, 0x00
0000747fd7fd39ea  mov rax, 0x6055A0B6E530
0000747fd7fd39f4  call rax
0000747fd7fd39f6  movaps xmm9, [rsp]
0000747fd7fd39fb  add rsp, 0x30
0000747fd7fd39ff  vmovaps xmm0, [rsp]
0000747fd7fd3a04  vmovaps xmm1, [rsp+0x10]
0000747fd7fd3a0a  vmovaps xmm2, [rsp+0x20]
0000747fd7fd3a10  vmovaps xmm3, [rsp+0x30]
0000747fd7fd3a16  vmovaps xmm4, [rsp+0x40]
0000747fd7fd3a1c  vmovaps xmm5, [rsp+0x50]
0000747fd7fd3a22  vmovaps xmm6, [rsp+0x60]
0000747fd7fd3a28  vmovaps xmm7, [rsp+0x70]
0000747fd7fd3a2e  vmovaps xmm8, [rsp+0x80]
0000747fd7fd3a37  vmovaps xmm10, [rsp+0x90]
0000747fd7fd3a40  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd3a49  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd3a52  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd3a5b  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd3a64  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd3a6d  add rsp, 0xF0
0000747fd7fd3a74  pop r11
0000747fd7fd3a76  pop r10
0000747fd7fd3a78  pop r9
0000747fd7fd3a7a  pop r8
0000747fd7fd3a7c  pop rsi
0000747fd7fd3a7d  pop rdi
0000747fd7fd3a7e  pop rdx
0000747fd7fd3a7f  pop rcx
0000747fd7fd3a80  pop rax
0000747fd7fd3a81  add rsp, 0x08
0000747fd7fd3a85  jmp 0x0000747FD7FCFFE1
0000747fd7fd3a8a  sub rsp, 0x08
0000747fd7fd3a8e  push rax
0000747fd7fd3a8f  push rcx
0000747fd7fd3a90  push rdx
0000747fd7fd3a91  push rdi
0000747fd7fd3a92  push rsi
0000747fd7fd3a93  push r8
0000747fd7fd3a95  push r9
0000747fd7fd3a97  push r10
0000747fd7fd3a99  push r11
0000747fd7fd3a9b  sub rsp, 0xF0
0000747fd7fd3aa2  vmovaps [rsp], xmm0
0000747fd7fd3aa7  vmovaps [rsp+0x10], xmm1
0000747fd7fd3aad  vmovaps [rsp+0x20], xmm2
0000747fd7fd3ab3  vmovaps [rsp+0x30], xmm3
0000747fd7fd3ab9  vmovaps [rsp+0x40], xmm4
0000747fd7fd3abf  vmovaps [rsp+0x50], xmm5
0000747fd7fd3ac5  vmovaps [rsp+0x60], xmm6
0000747fd7fd3acb  vmovaps [rsp+0x70], xmm7
0000747fd7fd3ad1  vmovaps [rsp+0x80], xmm8
0000747fd7fd3ada  vmovaps [rsp+0x90], xmm9
0000747fd7fd3ae3  vmovaps [rsp+0xA0], xmm11
0000747fd7fd3aec  vmovaps [rsp+0xB0], xmm12
0000747fd7fd3af5  vmovaps [rsp+0xC0], xmm13
0000747fd7fd3afe  vmovaps [rsp+0xD0], xmm14
0000747fd7fd3b07  vmovaps [rsp+0xE0], xmm15
0000747fd7fd3b10  sub rsp, 0x30
0000747fd7fd3b14  movaps [rsp], xmm10
0000747fd7fd3b19  movaps [rsp+0x10], xmm1
0000747fd7fd3b1e  movaps [rsp+0x20], xmm11
0000747fd7fd3b24  lea rdi, [rsp]
0000747fd7fd3b28  mov esi, 0x00
0000747fd7fd3b2d  mov rax, 0x6055A0B6E530
0000747fd7fd3b37  call rax
0000747fd7fd3b39  movaps xmm10, [rsp]
0000747fd7fd3b3e  add rsp, 0x30
0000747fd7fd3b42  vmovaps xmm0, [rsp]
0000747fd7fd3b47  vmovaps xmm1, [rsp+0x10]
0000747fd7fd3b4d  vmovaps xmm2, [rsp+0x20]
0000747fd7fd3b53  vmovaps xmm3, [rsp+0x30]
0000747fd7fd3b59  vmovaps xmm4, [rsp+0x40]
0000747fd7fd3b5f  vmovaps xmm5, [rsp+0x50]
0000747fd7fd3b65  vmovaps xmm6, [rsp+0x60]
0000747fd7fd3b6b  vmovaps xmm7, [rsp+0x70]
0000747fd7fd3b71  vmovaps xmm8, [rsp+0x80]
0000747fd7fd3b7a  vmovaps xmm9, [rsp+0x90]
0000747fd7fd3b83  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd3b8c  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd3b95  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd3b9e  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd3ba7  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd3bb0  add rsp, 0xF0
0000747fd7fd3bb7  pop r11
0000747fd7fd3bb9  pop r10
0000747fd7fd3bbb  pop r9
0000747fd7fd3bbd  pop r8
0000747fd7fd3bbf  pop rsi
0000747fd7fd3bc0  pop rdi
0000747fd7fd3bc1  pop rdx
0000747fd7fd3bc2  pop rcx
0000747fd7fd3bc3  pop rax
0000747fd7fd3bc4  add rsp, 0x08
0000747fd7fd3bc8  jmp 0x0000747FD7FCFFFC
0000747fd7fd3bcd  sub rsp, 0x08
0000747fd7fd3bd1  push rax
0000747fd7fd3bd2  push rcx
0000747fd7fd3bd3  push rdx
0000747fd7fd3bd4  push rdi
0000747fd7fd3bd5  push rsi
0000747fd7fd3bd6  push r8
0000747fd7fd3bd8  push r9
0000747fd7fd3bda  push r10
0000747fd7fd3bdc  push r11
0000747fd7fd3bde  sub rsp, 0xF0
0000747fd7fd3be5  vmovaps [rsp], xmm0
0000747fd7fd3bea  vmovaps [rsp+0x10], xmm2
0000747fd7fd3bf0  vmovaps [rsp+0x20], xmm3
0000747fd7fd3bf6  vmovaps [rsp+0x30], xmm4
0000747fd7fd3bfc  vmovaps [rsp+0x40], xmm5
0000747fd7fd3c02  vmovaps [rsp+0x50], xmm6
0000747fd7fd3c08  vmovaps [rsp+0x60], xmm7
0000747fd7fd3c0e  vmovaps [rsp+0x70], xmm8
0000747fd7fd3c14  vmovaps [rsp+0x80], xmm9
0000747fd7fd3c1d  vmovaps [rsp+0x90], xmm10
0000747fd7fd3c26  vmovaps [rsp+0xA0], xmm11
0000747fd7fd3c2f  vmovaps [rsp+0xB0], xmm12
0000747fd7fd3c38  vmovaps [rsp+0xC0], xmm13
0000747fd7fd3c41  vmovaps [rsp+0xD0], xmm14
0000747fd7fd3c4a  vmovaps [rsp+0xE0], xmm15
0000747fd7fd3c53  sub rsp, 0x30
0000747fd7fd3c57  movaps [rsp], xmm1
0000747fd7fd3c5b  movaps [rsp+0x10], xmm14
0000747fd7fd3c61  movaps [rsp+0x20], xmm6
0000747fd7fd3c66  lea rdi, [rsp]
0000747fd7fd3c6a  mov esi, 0x00
0000747fd7fd3c6f  mov rax, 0x6055A0B6E530
0000747fd7fd3c79  call rax
0000747fd7fd3c7b  movaps xmm1, [rsp]
0000747fd7fd3c7f  add rsp, 0x30
0000747fd7fd3c83  vmovaps xmm0, [rsp]
0000747fd7fd3c88  vmovaps xmm2, [rsp+0x10]
0000747fd7fd3c8e  vmovaps xmm3, [rsp+0x20]
0000747fd7fd3c94  vmovaps xmm4, [rsp+0x30]
0000747fd7fd3c9a  vmovaps xmm5, [rsp+0x40]
0000747fd7fd3ca0  vmovaps xmm6, [rsp+0x50]
0000747fd7fd3ca6  vmovaps xmm7, [rsp+0x60]
0000747fd7fd3cac  vmovaps xmm8, [rsp+0x70]
0000747fd7fd3cb2  vmovaps xmm9, [rsp+0x80]
0000747fd7fd3cbb  vmovaps xmm10, [rsp+0x90]
0000747fd7fd3cc4  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd3ccd  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd3cd6  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd3cdf  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd3ce8  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd3cf1  add rsp, 0xF0
0000747fd7fd3cf8  pop r11
0000747fd7fd3cfa  pop r10
0000747fd7fd3cfc  pop r9
0000747fd7fd3cfe  pop r8
0000747fd7fd3d00  pop rsi
0000747fd7fd3d01  pop rdi
0000747fd7fd3d02  pop rdx
0000747fd7fd3d03  pop rcx
0000747fd7fd3d04  pop rax
0000747fd7fd3d05  add rsp, 0x08
0000747fd7fd3d09  jmp 0x0000747FD7FD0015
0000747fd7fd3d0e  sub rsp, 0x08
0000747fd7fd3d12  push rax
0000747fd7fd3d13  push rcx
0000747fd7fd3d14  push rdx
0000747fd7fd3d15  push rdi
0000747fd7fd3d16  push rsi
0000747fd7fd3d17  push r8
0000747fd7fd3d19  push r9
0000747fd7fd3d1b  push r10
0000747fd7fd3d1d  push r11
0000747fd7fd3d1f  sub rsp, 0xF0
0000747fd7fd3d26  vmovaps [rsp], xmm0
0000747fd7fd3d2b  vmovaps [rsp+0x10], xmm1
0000747fd7fd3d31  vmovaps [rsp+0x20], xmm2
0000747fd7fd3d37  vmovaps [rsp+0x30], xmm3
0000747fd7fd3d3d  vmovaps [rsp+0x40], xmm4
0000747fd7fd3d43  vmovaps [rsp+0x50], xmm5
0000747fd7fd3d49  vmovaps [rsp+0x60], xmm6
0000747fd7fd3d4f  vmovaps [rsp+0x70], xmm7
0000747fd7fd3d55  vmovaps [rsp+0x80], xmm8
0000747fd7fd3d5e  vmovaps [rsp+0x90], xmm9
0000747fd7fd3d67  vmovaps [rsp+0xA0], xmm10
0000747fd7fd3d70  vmovaps [rsp+0xB0], xmm12
0000747fd7fd3d79  vmovaps [rsp+0xC0], xmm13
0000747fd7fd3d82  vmovaps [rsp+0xD0], xmm14
0000747fd7fd3d8b  vmovaps [rsp+0xE0], xmm15
0000747fd7fd3d94  sub rsp, 0x30
0000747fd7fd3d98  movaps [rsp], xmm11
0000747fd7fd3d9d  movaps [rsp+0x10], xmm13
0000747fd7fd3da3  movaps [rsp+0x20], xmm14
0000747fd7fd3da9  lea rdi, [rsp]
0000747fd7fd3dad  mov esi, 0x00
0000747fd7fd3db2  mov rax, 0x6055A0B6E530
0000747fd7fd3dbc  call rax
0000747fd7fd3dbe  movaps xmm11, [rsp]
0000747fd7fd3dc3  add rsp, 0x30
0000747fd7fd3dc7  vmovaps xmm0, [rsp]
0000747fd7fd3dcc  vmovaps xmm1, [rsp+0x10]
0000747fd7fd3dd2  vmovaps xmm2, [rsp+0x20]
0000747fd7fd3dd8  vmovaps xmm3, [rsp+0x30]
0000747fd7fd3dde  vmovaps xmm4, [rsp+0x40]
0000747fd7fd3de4  vmovaps xmm5, [rsp+0x50]
0000747fd7fd3dea  vmovaps xmm6, [rsp+0x60]
0000747fd7fd3df0  vmovaps xmm7, [rsp+0x70]
0000747fd7fd3df6  vmovaps xmm8, [rsp+0x80]
0000747fd7fd3dff  vmovaps xmm9, [rsp+0x90]
0000747fd7fd3e08  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd3e11  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd3e1a  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd3e23  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd3e2c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd3e35  add rsp, 0xF0
0000747fd7fd3e3c  pop r11
0000747fd7fd3e3e  pop r10
0000747fd7fd3e40  pop r9
0000747fd7fd3e42  pop r8
0000747fd7fd3e44  pop rsi
0000747fd7fd3e45  pop rdi
0000747fd7fd3e46  pop rdx
0000747fd7fd3e47  pop rcx
0000747fd7fd3e48  pop rax
0000747fd7fd3e49  add rsp, 0x08
0000747fd7fd3e4d  jmp 0x0000747FD7FD003F
0000747fd7fd3e52  sub rsp, 0x08
0000747fd7fd3e56  push rax
0000747fd7fd3e57  push rcx
0000747fd7fd3e58  push rdx
0000747fd7fd3e59  push rdi
0000747fd7fd3e5a  push rsi
0000747fd7fd3e5b  push r8
0000747fd7fd3e5d  push r9
0000747fd7fd3e5f  push r10
0000747fd7fd3e61  push r11
0000747fd7fd3e63  sub rsp, 0xF0
0000747fd7fd3e6a  vmovaps [rsp], xmm0
0000747fd7fd3e6f  vmovaps [rsp+0x10], xmm1
0000747fd7fd3e75  vmovaps [rsp+0x20], xmm2
0000747fd7fd3e7b  vmovaps [rsp+0x30], xmm3
0000747fd7fd3e81  vmovaps [rsp+0x40], xmm4
0000747fd7fd3e87  vmovaps [rsp+0x50], xmm5
0000747fd7fd3e8d  vmovaps [rsp+0x60], xmm6
0000747fd7fd3e93  vmovaps [rsp+0x70], xmm7
0000747fd7fd3e99  vmovaps [rsp+0x80], xmm8
0000747fd7fd3ea2  vmovaps [rsp+0x90], xmm9
0000747fd7fd3eab  vmovaps [rsp+0xA0], xmm10
0000747fd7fd3eb4  vmovaps [rsp+0xB0], xmm11
0000747fd7fd3ebd  vmovaps [rsp+0xC0], xmm12
0000747fd7fd3ec6  vmovaps [rsp+0xD0], xmm14
0000747fd7fd3ecf  vmovaps [rsp+0xE0], xmm15
0000747fd7fd3ed8  sub rsp, 0x30
0000747fd7fd3edc  movaps [rsp], xmm13
0000747fd7fd3ee1  movaps [rsp+0x10], xmm8
0000747fd7fd3ee7  movaps [rsp+0x20], xmm14
0000747fd7fd3eed  lea rdi, [rsp]
0000747fd7fd3ef1  mov esi, 0x00
0000747fd7fd3ef6  mov rax, 0x6055A0B6E530
0000747fd7fd3f00  call rax
0000747fd7fd3f02  movaps xmm13, [rsp]
0000747fd7fd3f07  add rsp, 0x30
0000747fd7fd3f0b  vmovaps xmm0, [rsp]
0000747fd7fd3f10  vmovaps xmm1, [rsp+0x10]
0000747fd7fd3f16  vmovaps xmm2, [rsp+0x20]
0000747fd7fd3f1c  vmovaps xmm3, [rsp+0x30]
0000747fd7fd3f22  vmovaps xmm4, [rsp+0x40]
0000747fd7fd3f28  vmovaps xmm5, [rsp+0x50]
0000747fd7fd3f2e  vmovaps xmm6, [rsp+0x60]
0000747fd7fd3f34  vmovaps xmm7, [rsp+0x70]
0000747fd7fd3f3a  vmovaps xmm8, [rsp+0x80]
0000747fd7fd3f43  vmovaps xmm9, [rsp+0x90]
0000747fd7fd3f4c  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd3f55  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd3f5e  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd3f67  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd3f70  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd3f79  add rsp, 0xF0
0000747fd7fd3f80  pop r11
0000747fd7fd3f82  pop r10
0000747fd7fd3f84  pop r9
0000747fd7fd3f86  pop r8
0000747fd7fd3f88  pop rsi
0000747fd7fd3f89  pop rdi
0000747fd7fd3f8a  pop rdx
0000747fd7fd3f8b  pop rcx
0000747fd7fd3f8c  pop rax
0000747fd7fd3f8d  add rsp, 0x08
0000747fd7fd3f91  jmp 0x0000747FD7FD006E
0000747fd7fd3f96  sub rsp, 0x08
0000747fd7fd3f9a  push rax
0000747fd7fd3f9b  push rcx
0000747fd7fd3f9c  push rdx
0000747fd7fd3f9d  push rdi
0000747fd7fd3f9e  push rsi
0000747fd7fd3f9f  push r8
0000747fd7fd3fa1  push r9
0000747fd7fd3fa3  push r10
0000747fd7fd3fa5  push r11
0000747fd7fd3fa7  sub rsp, 0xF0
0000747fd7fd3fae  vmovaps [rsp], xmm0
0000747fd7fd3fb3  vmovaps [rsp+0x10], xmm1
0000747fd7fd3fb9  vmovaps [rsp+0x20], xmm2
0000747fd7fd3fbf  vmovaps [rsp+0x30], xmm3
0000747fd7fd3fc5  vmovaps [rsp+0x40], xmm4
0000747fd7fd3fcb  vmovaps [rsp+0x50], xmm5
0000747fd7fd3fd1  vmovaps [rsp+0x60], xmm6
0000747fd7fd3fd7  vmovaps [rsp+0x70], xmm7
0000747fd7fd3fdd  vmovaps [rsp+0x80], xmm9
0000747fd7fd3fe6  vmovaps [rsp+0x90], xmm10
0000747fd7fd3fef  vmovaps [rsp+0xA0], xmm11
0000747fd7fd3ff8  vmovaps [rsp+0xB0], xmm12
0000747fd7fd4001  vmovaps [rsp+0xC0], xmm13
0000747fd7fd400a  vmovaps [rsp+0xD0], xmm14
0000747fd7fd4013  vmovaps [rsp+0xE0], xmm15
0000747fd7fd401c  sub rsp, 0x30
0000747fd7fd4020  movaps [rsp], xmm8
0000747fd7fd4025  movaps [rsp+0x10], xmm7
0000747fd7fd402a  movaps [rsp+0x20], xmm14
0000747fd7fd4030  lea rdi, [rsp]
0000747fd7fd4034  mov esi, 0x00
0000747fd7fd4039  mov rax, 0x6055A0B6E530
0000747fd7fd4043  call rax
0000747fd7fd4045  movaps xmm8, [rsp]
0000747fd7fd404a  add rsp, 0x30
0000747fd7fd404e  vmovaps xmm0, [rsp]
0000747fd7fd4053  vmovaps xmm1, [rsp+0x10]
0000747fd7fd4059  vmovaps xmm2, [rsp+0x20]
0000747fd7fd405f  vmovaps xmm3, [rsp+0x30]
0000747fd7fd4065  vmovaps xmm4, [rsp+0x40]
0000747fd7fd406b  vmovaps xmm5, [rsp+0x50]
0000747fd7fd4071  vmovaps xmm6, [rsp+0x60]
0000747fd7fd4077  vmovaps xmm7, [rsp+0x70]
0000747fd7fd407d  vmovaps xmm9, [rsp+0x80]
0000747fd7fd4086  vmovaps xmm10, [rsp+0x90]
0000747fd7fd408f  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd4098  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd40a1  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd40aa  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd40b3  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd40bc  add rsp, 0xF0
0000747fd7fd40c3  pop r11
0000747fd7fd40c5  pop r10
0000747fd7fd40c7  pop r9
0000747fd7fd40c9  pop r8
0000747fd7fd40cb  pop rsi
0000747fd7fd40cc  pop rdi
0000747fd7fd40cd  pop rdx
0000747fd7fd40ce  pop rcx
0000747fd7fd40cf  pop rax
0000747fd7fd40d0  add rsp, 0x08
0000747fd7fd40d4  jmp 0x0000747FD7FD0094
0000747fd7fd40d9  sub rsp, 0x08
0000747fd7fd40dd  push rax
0000747fd7fd40de  push rcx
0000747fd7fd40df  push rdx
0000747fd7fd40e0  push rdi
0000747fd7fd40e1  push rsi
0000747fd7fd40e2  push r8
0000747fd7fd40e4  push r9
0000747fd7fd40e6  push r10
0000747fd7fd40e8  push r11
0000747fd7fd40ea  sub rsp, 0xF0
0000747fd7fd40f1  vmovaps [rsp], xmm0
0000747fd7fd40f6  vmovaps [rsp+0x10], xmm1
0000747fd7fd40fc  vmovaps [rsp+0x20], xmm2
0000747fd7fd4102  vmovaps [rsp+0x30], xmm3
0000747fd7fd4108  vmovaps [rsp+0x40], xmm4
0000747fd7fd410e  vmovaps [rsp+0x50], xmm5
0000747fd7fd4114  vmovaps [rsp+0x60], xmm6
0000747fd7fd411a  vmovaps [rsp+0x70], xmm7
0000747fd7fd4120  vmovaps [rsp+0x80], xmm8
0000747fd7fd4129  vmovaps [rsp+0x90], xmm9
0000747fd7fd4132  vmovaps [rsp+0xA0], xmm10
0000747fd7fd413b  vmovaps [rsp+0xB0], xmm11
0000747fd7fd4144  vmovaps [rsp+0xC0], xmm12
0000747fd7fd414d  vmovaps [rsp+0xD0], xmm13
0000747fd7fd4156  vmovaps [rsp+0xE0], xmm15
0000747fd7fd415f  sub rsp, 0x30
0000747fd7fd4163  movaps [rsp], xmm14
0000747fd7fd4168  movaps [rsp+0x10], xmm12
0000747fd7fd416e  movaps [rsp+0x20], xmm9
0000747fd7fd4174  lea rdi, [rsp]
0000747fd7fd4178  mov esi, 0x00
0000747fd7fd417d  mov rax, 0x6055A0B6E530
0000747fd7fd4187  call rax
0000747fd7fd4189  movaps xmm14, [rsp]
0000747fd7fd418e  add rsp, 0x30
0000747fd7fd4192  vmovaps xmm0, [rsp]
0000747fd7fd4197  vmovaps xmm1, [rsp+0x10]
0000747fd7fd419d  vmovaps xmm2, [rsp+0x20]
0000747fd7fd41a3  vmovaps xmm3, [rsp+0x30]
0000747fd7fd41a9  vmovaps xmm4, [rsp+0x40]
0000747fd7fd41af  vmovaps xmm5, [rsp+0x50]
0000747fd7fd41b5  vmovaps xmm6, [rsp+0x60]
0000747fd7fd41bb  vmovaps xmm7, [rsp+0x70]
0000747fd7fd41c1  vmovaps xmm8, [rsp+0x80]
0000747fd7fd41ca  vmovaps xmm9, [rsp+0x90]
0000747fd7fd41d3  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd41dc  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd41e5  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd41ee  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd41f7  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4200  add rsp, 0xF0
0000747fd7fd4207  pop r11
0000747fd7fd4209  pop r10
0000747fd7fd420b  pop r9
0000747fd7fd420d  pop r8
0000747fd7fd420f  pop rsi
0000747fd7fd4210  pop rdi
0000747fd7fd4211  pop rdx
0000747fd7fd4212  pop rcx
0000747fd7fd4213  pop rax
0000747fd7fd4214  add rsp, 0x08
0000747fd7fd4218  jmp 0x0000747FD7FD00AE
0000747fd7fd421d  sub rsp, 0x08
0000747fd7fd4221  push rax
0000747fd7fd4222  push rcx
0000747fd7fd4223  push rdx
0000747fd7fd4224  push rdi
0000747fd7fd4225  push rsi
0000747fd7fd4226  push r8
0000747fd7fd4228  push r9
0000747fd7fd422a  push r10
0000747fd7fd422c  push r11
0000747fd7fd422e  sub rsp, 0xF0
0000747fd7fd4235  vmovaps [rsp], xmm0
0000747fd7fd423a  vmovaps [rsp+0x10], xmm1
0000747fd7fd4240  vmovaps [rsp+0x20], xmm2
0000747fd7fd4246  vmovaps [rsp+0x30], xmm3
0000747fd7fd424c  vmovaps [rsp+0x40], xmm4
0000747fd7fd4252  vmovaps [rsp+0x50], xmm5
0000747fd7fd4258  vmovaps [rsp+0x60], xmm6
0000747fd7fd425e  vmovaps [rsp+0x70], xmm7
0000747fd7fd4264  vmovaps [rsp+0x80], xmm8
0000747fd7fd426d  vmovaps [rsp+0x90], xmm10
0000747fd7fd4276  vmovaps [rsp+0xA0], xmm11
0000747fd7fd427f  vmovaps [rsp+0xB0], xmm12
0000747fd7fd4288  vmovaps [rsp+0xC0], xmm13
0000747fd7fd4291  vmovaps [rsp+0xD0], xmm14
0000747fd7fd429a  vmovaps [rsp+0xE0], xmm15
0000747fd7fd42a3  sub rsp, 0x30
0000747fd7fd42a7  movaps [rsp], xmm9
0000747fd7fd42ac  movaps [rsp+0x10], xmm7
0000747fd7fd42b1  movaps [rsp+0x20], xmm12
0000747fd7fd42b7  lea rdi, [rsp]
0000747fd7fd42bb  mov esi, 0x00
0000747fd7fd42c0  mov rax, 0x6055A0B6E530
0000747fd7fd42ca  call rax
0000747fd7fd42cc  movaps xmm9, [rsp]
0000747fd7fd42d1  add rsp, 0x30
0000747fd7fd42d5  vmovaps xmm0, [rsp]
0000747fd7fd42da  vmovaps xmm1, [rsp+0x10]
0000747fd7fd42e0  vmovaps xmm2, [rsp+0x20]
0000747fd7fd42e6  vmovaps xmm3, [rsp+0x30]
0000747fd7fd42ec  vmovaps xmm4, [rsp+0x40]
0000747fd7fd42f2  vmovaps xmm5, [rsp+0x50]
0000747fd7fd42f8  vmovaps xmm6, [rsp+0x60]
0000747fd7fd42fe  vmovaps xmm7, [rsp+0x70]
0000747fd7fd4304  vmovaps xmm8, [rsp+0x80]
0000747fd7fd430d  vmovaps xmm10, [rsp+0x90]
0000747fd7fd4316  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd431f  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd4328  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd4331  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd433a  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4343  add rsp, 0xF0
0000747fd7fd434a  pop r11
0000747fd7fd434c  pop r10
0000747fd7fd434e  pop r9
0000747fd7fd4350  pop r8
0000747fd7fd4352  pop rsi
0000747fd7fd4353  pop rdi
0000747fd7fd4354  pop rdx
0000747fd7fd4355  pop rcx
0000747fd7fd4356  pop rax
0000747fd7fd4357  add rsp, 0x08
0000747fd7fd435b  jmp 0x0000747FD7FD00DD
0000747fd7fd4360  sub rsp, 0x08
0000747fd7fd4364  push rax
0000747fd7fd4365  push rcx
0000747fd7fd4366  push rdx
0000747fd7fd4367  push rdi
0000747fd7fd4368  push rsi
0000747fd7fd4369  push r8
0000747fd7fd436b  push r9
0000747fd7fd436d  push r10
0000747fd7fd436f  push r11
0000747fd7fd4371  sub rsp, 0xF0
0000747fd7fd4378  vmovaps [rsp], xmm0
0000747fd7fd437d  vmovaps [rsp+0x10], xmm1
0000747fd7fd4383  vmovaps [rsp+0x20], xmm2
0000747fd7fd4389  vmovaps [rsp+0x30], xmm3
0000747fd7fd438f  vmovaps [rsp+0x40], xmm4
0000747fd7fd4395  vmovaps [rsp+0x50], xmm5
0000747fd7fd439b  vmovaps [rsp+0x60], xmm6
0000747fd7fd43a1  vmovaps [rsp+0x70], xmm7
0000747fd7fd43a7  vmovaps [rsp+0x80], xmm8
0000747fd7fd43b0  vmovaps [rsp+0x90], xmm9
0000747fd7fd43b9  vmovaps [rsp+0xA0], xmm10
0000747fd7fd43c2  vmovaps [rsp+0xB0], xmm11
0000747fd7fd43cb  vmovaps [rsp+0xC0], xmm13
0000747fd7fd43d4  vmovaps [rsp+0xD0], xmm14
0000747fd7fd43dd  vmovaps [rsp+0xE0], xmm15
0000747fd7fd43e6  sub rsp, 0x30
0000747fd7fd43ea  movaps [rsp], xmm12
0000747fd7fd43ef  movaps [rsp+0x10], xmm15
0000747fd7fd43f5  movaps [rsp+0x20], xmm11
0000747fd7fd43fb  lea rdi, [rsp]
0000747fd7fd43ff  mov esi, 0x00
0000747fd7fd4404  mov rax, 0x6055A0B6E530
0000747fd7fd440e  call rax
0000747fd7fd4410  movaps xmm12, [rsp]
0000747fd7fd4415  add rsp, 0x30
0000747fd7fd4419  vmovaps xmm0, [rsp]
0000747fd7fd441e  vmovaps xmm1, [rsp+0x10]
0000747fd7fd4424  vmovaps xmm2, [rsp+0x20]
0000747fd7fd442a  vmovaps xmm3, [rsp+0x30]
0000747fd7fd4430  vmovaps xmm4, [rsp+0x40]
0000747fd7fd4436  vmovaps xmm5, [rsp+0x50]
0000747fd7fd443c  vmovaps xmm6, [rsp+0x60]
0000747fd7fd4442  vmovaps xmm7, [rsp+0x70]
0000747fd7fd4448  vmovaps xmm8, [rsp+0x80]
0000747fd7fd4451  vmovaps xmm9, [rsp+0x90]
0000747fd7fd445a  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd4463  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd446c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd4475  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd447e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4487  add rsp, 0xF0
0000747fd7fd448e  pop r11
0000747fd7fd4490  pop r10
0000747fd7fd4492  pop r9
0000747fd7fd4494  pop r8
0000747fd7fd4496  pop rsi
0000747fd7fd4497  pop rdi
0000747fd7fd4498  pop rdx
0000747fd7fd4499  pop rcx
0000747fd7fd449a  pop rax
0000747fd7fd449b  add rsp, 0x08
0000747fd7fd449f  jmp 0x0000747FD7FD00F7
0000747fd7fd44a4  sub rsp, 0x08
0000747fd7fd44a8  push rax
0000747fd7fd44a9  push rcx
0000747fd7fd44aa  push rdx
0000747fd7fd44ab  push rdi
0000747fd7fd44ac  push rsi
0000747fd7fd44ad  push r8
0000747fd7fd44af  push r9
0000747fd7fd44b1  push r10
0000747fd7fd44b3  push r11
0000747fd7fd44b5  sub rsp, 0xF0
0000747fd7fd44bc  vmovaps [rsp], xmm0
0000747fd7fd44c1  vmovaps [rsp+0x10], xmm1
0000747fd7fd44c7  vmovaps [rsp+0x20], xmm2
0000747fd7fd44cd  vmovaps [rsp+0x30], xmm3
0000747fd7fd44d3  vmovaps [rsp+0x40], xmm4
0000747fd7fd44d9  vmovaps [rsp+0x50], xmm5
0000747fd7fd44df  vmovaps [rsp+0x60], xmm6
0000747fd7fd44e5  vmovaps [rsp+0x70], xmm7
0000747fd7fd44eb  vmovaps [rsp+0x80], xmm8
0000747fd7fd44f4  vmovaps [rsp+0x90], xmm9
0000747fd7fd44fd  vmovaps [rsp+0xA0], xmm10
0000747fd7fd4506  vmovaps [rsp+0xB0], xmm12
0000747fd7fd450f  vmovaps [rsp+0xC0], xmm13
0000747fd7fd4518  vmovaps [rsp+0xD0], xmm14
0000747fd7fd4521  vmovaps [rsp+0xE0], xmm15
0000747fd7fd452a  sub rsp, 0x30
0000747fd7fd452e  movaps [rsp], xmm11
0000747fd7fd4533  movaps [rsp+0x10], xmm7
0000747fd7fd4538  movaps [rsp+0x20], xmm15
0000747fd7fd453e  lea rdi, [rsp]
0000747fd7fd4542  mov esi, 0x00
0000747fd7fd4547  mov rax, 0x6055A0B6E530
0000747fd7fd4551  call rax
0000747fd7fd4553  movaps xmm11, [rsp]
0000747fd7fd4558  add rsp, 0x30
0000747fd7fd455c  vmovaps xmm0, [rsp]
0000747fd7fd4561  vmovaps xmm1, [rsp+0x10]
0000747fd7fd4567  vmovaps xmm2, [rsp+0x20]
0000747fd7fd456d  vmovaps xmm3, [rsp+0x30]
0000747fd7fd4573  vmovaps xmm4, [rsp+0x40]
0000747fd7fd4579  vmovaps xmm5, [rsp+0x50]
0000747fd7fd457f  vmovaps xmm6, [rsp+0x60]
0000747fd7fd4585  vmovaps xmm7, [rsp+0x70]
0000747fd7fd458b  vmovaps xmm8, [rsp+0x80]
0000747fd7fd4594  vmovaps xmm9, [rsp+0x90]
0000747fd7fd459d  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd45a6  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd45af  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd45b8  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd45c1  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd45ca  add rsp, 0xF0
0000747fd7fd45d1  pop r11
0000747fd7fd45d3  pop r10
0000747fd7fd45d5  pop r9
0000747fd7fd45d7  pop r8
0000747fd7fd45d9  pop rsi
0000747fd7fd45da  pop rdi
0000747fd7fd45db  pop rdx
0000747fd7fd45dc  pop rcx
0000747fd7fd45dd  pop rax
0000747fd7fd45de  add rsp, 0x08
0000747fd7fd45e2  jmp 0x0000747FD7FD0123
0000747fd7fd45e7  sub rsp, 0x08
0000747fd7fd45eb  push rax
0000747fd7fd45ec  push rcx
0000747fd7fd45ed  push rdx
0000747fd7fd45ee  push rdi
0000747fd7fd45ef  push rsi
0000747fd7fd45f0  push r8
0000747fd7fd45f2  push r9
0000747fd7fd45f4  push r10
0000747fd7fd45f6  push r11
0000747fd7fd45f8  sub rsp, 0xF0
0000747fd7fd45ff  vmovaps [rsp], xmm0
0000747fd7fd4604  vmovaps [rsp+0x10], xmm1
0000747fd7fd460a  vmovaps [rsp+0x20], xmm2
0000747fd7fd4610  vmovaps [rsp+0x30], xmm3
0000747fd7fd4616  vmovaps [rsp+0x40], xmm4
0000747fd7fd461c  vmovaps [rsp+0x50], xmm5
0000747fd7fd4622  vmovaps [rsp+0x60], xmm6
0000747fd7fd4628  vmovaps [rsp+0x70], xmm7
0000747fd7fd462e  vmovaps [rsp+0x80], xmm8
0000747fd7fd4637  vmovaps [rsp+0x90], xmm9
0000747fd7fd4640  vmovaps [rsp+0xA0], xmm10
0000747fd7fd4649  vmovaps [rsp+0xB0], xmm11
0000747fd7fd4652  vmovaps [rsp+0xC0], xmm12
0000747fd7fd465b  vmovaps [rsp+0xD0], xmm13
0000747fd7fd4664  vmovaps [rsp+0xE0], xmm14
0000747fd7fd466d  sub rsp, 0x30
0000747fd7fd4671  movaps [rsp], xmm15
0000747fd7fd4676  movaps [rsp+0x10], xmm10
0000747fd7fd467c  movaps [rsp+0x20], xmm13
0000747fd7fd4682  lea rdi, [rsp]
0000747fd7fd4686  mov esi, 0x00
0000747fd7fd468b  mov rax, 0x6055A0B6E530
0000747fd7fd4695  call rax
0000747fd7fd4697  movaps xmm15, [rsp]
0000747fd7fd469c  add rsp, 0x30
0000747fd7fd46a0  vmovaps xmm0, [rsp]
0000747fd7fd46a5  vmovaps xmm1, [rsp+0x10]
0000747fd7fd46ab  vmovaps xmm2, [rsp+0x20]
0000747fd7fd46b1  vmovaps xmm3, [rsp+0x30]
0000747fd7fd46b7  vmovaps xmm4, [rsp+0x40]
0000747fd7fd46bd  vmovaps xmm5, [rsp+0x50]
0000747fd7fd46c3  vmovaps xmm6, [rsp+0x60]
0000747fd7fd46c9  vmovaps xmm7, [rsp+0x70]
0000747fd7fd46cf  vmovaps xmm8, [rsp+0x80]
0000747fd7fd46d8  vmovaps xmm9, [rsp+0x90]
0000747fd7fd46e1  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd46ea  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd46f3  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd46fc  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd4705  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd470e  add rsp, 0xF0
0000747fd7fd4715  pop r11
0000747fd7fd4717  pop r10
0000747fd7fd4719  pop r9
0000747fd7fd471b  pop r8
0000747fd7fd471d  pop rsi
0000747fd7fd471e  pop rdi
0000747fd7fd471f  pop rdx
0000747fd7fd4720  pop rcx
0000747fd7fd4721  pop rax
0000747fd7fd4722  add rsp, 0x08
0000747fd7fd4726  jmp 0x0000747FD7FD013D
0000747fd7fd472b  sub rsp, 0x08
0000747fd7fd472f  push rax
0000747fd7fd4730  push rcx
0000747fd7fd4731  push rdx
0000747fd7fd4732  push rdi
0000747fd7fd4733  push rsi
0000747fd7fd4734  push r8
0000747fd7fd4736  push r9
0000747fd7fd4738  push r10
0000747fd7fd473a  push r11
0000747fd7fd473c  sub rsp, 0xF0
0000747fd7fd4743  vmovaps [rsp], xmm0
0000747fd7fd4748  vmovaps [rsp+0x10], xmm1
0000747fd7fd474e  vmovaps [rsp+0x20], xmm2
0000747fd7fd4754  vmovaps [rsp+0x30], xmm3
0000747fd7fd475a  vmovaps [rsp+0x40], xmm4
0000747fd7fd4760  vmovaps [rsp+0x50], xmm5
0000747fd7fd4766  vmovaps [rsp+0x60], xmm6
0000747fd7fd476c  vmovaps [rsp+0x70], xmm7
0000747fd7fd4772  vmovaps [rsp+0x80], xmm8
0000747fd7fd477b  vmovaps [rsp+0x90], xmm9
0000747fd7fd4784  vmovaps [rsp+0xA0], xmm11
0000747fd7fd478d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd4796  vmovaps [rsp+0xC0], xmm13
0000747fd7fd479f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd47a8  vmovaps [rsp+0xE0], xmm15
0000747fd7fd47b1  sub rsp, 0x30
0000747fd7fd47b5  movaps [rsp], xmm10
0000747fd7fd47ba  movaps [rsp+0x10], xmm7
0000747fd7fd47bf  movaps [rsp+0x20], xmm13
0000747fd7fd47c5  lea rdi, [rsp]
0000747fd7fd47c9  mov esi, 0x00
0000747fd7fd47ce  mov rax, 0x6055A0B6E530
0000747fd7fd47d8  call rax
0000747fd7fd47da  movaps xmm10, [rsp]
0000747fd7fd47df  add rsp, 0x30
0000747fd7fd47e3  vmovaps xmm0, [rsp]
0000747fd7fd47e8  vmovaps xmm1, [rsp+0x10]
0000747fd7fd47ee  vmovaps xmm2, [rsp+0x20]
0000747fd7fd47f4  vmovaps xmm3, [rsp+0x30]
0000747fd7fd47fa  vmovaps xmm4, [rsp+0x40]
0000747fd7fd4800  vmovaps xmm5, [rsp+0x50]
0000747fd7fd4806  vmovaps xmm6, [rsp+0x60]
0000747fd7fd480c  vmovaps xmm7, [rsp+0x70]
0000747fd7fd4812  vmovaps xmm8, [rsp+0x80]
0000747fd7fd481b  vmovaps xmm9, [rsp+0x90]
0000747fd7fd4824  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd482d  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd4836  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd483f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd4848  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4851  add rsp, 0xF0
0000747fd7fd4858  pop r11
0000747fd7fd485a  pop r10
0000747fd7fd485c  pop r9
0000747fd7fd485e  pop r8
0000747fd7fd4860  pop rsi
0000747fd7fd4861  pop rdi
0000747fd7fd4862  pop rdx
0000747fd7fd4863  pop rcx
0000747fd7fd4864  pop rax
0000747fd7fd4865  add rsp, 0x08
0000747fd7fd4869  jmp 0x0000747FD7FD0169
0000747fd7fd486e  sub rsp, 0x08
0000747fd7fd4872  push rax
0000747fd7fd4873  push rcx
0000747fd7fd4874  push rdx
0000747fd7fd4875  push rdi
0000747fd7fd4876  push rsi
0000747fd7fd4877  push r8
0000747fd7fd4879  push r9
0000747fd7fd487b  push r10
0000747fd7fd487d  push r11
0000747fd7fd487f  sub rsp, 0xF0
0000747fd7fd4886  vmovaps [rsp], xmm0
0000747fd7fd488b  vmovaps [rsp+0x10], xmm1
0000747fd7fd4891  vmovaps [rsp+0x20], xmm2
0000747fd7fd4897  vmovaps [rsp+0x30], xmm3
0000747fd7fd489d  vmovaps [rsp+0x40], xmm4
0000747fd7fd48a3  vmovaps [rsp+0x50], xmm5
0000747fd7fd48a9  vmovaps [rsp+0x60], xmm6
0000747fd7fd48af  vmovaps [rsp+0x70], xmm7
0000747fd7fd48b5  vmovaps [rsp+0x80], xmm8
0000747fd7fd48be  vmovaps [rsp+0x90], xmm9
0000747fd7fd48c7  vmovaps [rsp+0xA0], xmm10
0000747fd7fd48d0  vmovaps [rsp+0xB0], xmm11
0000747fd7fd48d9  vmovaps [rsp+0xC0], xmm12
0000747fd7fd48e2  vmovaps [rsp+0xD0], xmm14
0000747fd7fd48eb  vmovaps [rsp+0xE0], xmm15
0000747fd7fd48f4  sub rsp, 0x30
0000747fd7fd48f8  movaps [rsp], xmm13
0000747fd7fd48fd  movaps [rsp+0x10], xmm1
0000747fd7fd4902  movaps [rsp+0x20], xmm8
0000747fd7fd4908  lea rdi, [rsp]
0000747fd7fd490c  mov esi, 0x00
0000747fd7fd4911  mov rax, 0x6055A0B6E530
0000747fd7fd491b  call rax
0000747fd7fd491d  movaps xmm13, [rsp]
0000747fd7fd4922  add rsp, 0x30
0000747fd7fd4926  vmovaps xmm0, [rsp]
0000747fd7fd492b  vmovaps xmm1, [rsp+0x10]
0000747fd7fd4931  vmovaps xmm2, [rsp+0x20]
0000747fd7fd4937  vmovaps xmm3, [rsp+0x30]
0000747fd7fd493d  vmovaps xmm4, [rsp+0x40]
0000747fd7fd4943  vmovaps xmm5, [rsp+0x50]
0000747fd7fd4949  vmovaps xmm6, [rsp+0x60]
0000747fd7fd494f  vmovaps xmm7, [rsp+0x70]
0000747fd7fd4955  vmovaps xmm8, [rsp+0x80]
0000747fd7fd495e  vmovaps xmm9, [rsp+0x90]
0000747fd7fd4967  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd4970  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd4979  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd4982  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd498b  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4994  add rsp, 0xF0
0000747fd7fd499b  pop r11
0000747fd7fd499d  pop r10
0000747fd7fd499f  pop r9
0000747fd7fd49a1  pop r8
0000747fd7fd49a3  pop rsi
0000747fd7fd49a4  pop rdi
0000747fd7fd49a5  pop rdx
0000747fd7fd49a6  pop rcx
0000747fd7fd49a7  pop rax
0000747fd7fd49a8  add rsp, 0x08
0000747fd7fd49ac  jmp 0x0000747FD7FD0183
0000747fd7fd49b1  call 0x0000747FD7DFF430
0000747fd7fd49b6  jmp 0x0000747FD7FD018D
0000747fd7fd49bb  sub rsp, 0x08
0000747fd7fd49bf  push rax
0000747fd7fd49c0  push rcx
0000747fd7fd49c1  push rdx
0000747fd7fd49c2  push rdi
0000747fd7fd49c3  push rsi
0000747fd7fd49c4  push r8
0000747fd7fd49c6  push r9
0000747fd7fd49c8  push r10
0000747fd7fd49ca  push r11
0000747fd7fd49cc  sub rsp, 0xF0
0000747fd7fd49d3  vmovaps [rsp], xmm0
0000747fd7fd49d8  vmovaps [rsp+0x10], xmm1
0000747fd7fd49de  vmovaps [rsp+0x20], xmm2
0000747fd7fd49e4  vmovaps [rsp+0x30], xmm3
0000747fd7fd49ea  vmovaps [rsp+0x40], xmm4
0000747fd7fd49f0  vmovaps [rsp+0x50], xmm5
0000747fd7fd49f6  vmovaps [rsp+0x60], xmm6
0000747fd7fd49fc  vmovaps [rsp+0x70], xmm7
0000747fd7fd4a02  vmovaps [rsp+0x80], xmm9
0000747fd7fd4a0b  vmovaps [rsp+0x90], xmm10
0000747fd7fd4a14  vmovaps [rsp+0xA0], xmm11
0000747fd7fd4a1d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd4a26  vmovaps [rsp+0xC0], xmm13
0000747fd7fd4a2f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd4a38  vmovaps [rsp+0xE0], xmm15
0000747fd7fd4a41  sub rsp, 0x30
0000747fd7fd4a45  movaps [rsp], xmm8
0000747fd7fd4a4a  movaps [rsp+0x10], xmm14
0000747fd7fd4a50  movaps [rsp+0x20], xmm9
0000747fd7fd4a56  lea rdi, [rsp]
0000747fd7fd4a5a  mov esi, 0x00
0000747fd7fd4a5f  mov rax, 0x6055A0B6E530
0000747fd7fd4a69  call rax
0000747fd7fd4a6b  movaps xmm8, [rsp]
0000747fd7fd4a70  add rsp, 0x30
0000747fd7fd4a74  vmovaps xmm0, [rsp]
0000747fd7fd4a79  vmovaps xmm1, [rsp+0x10]
0000747fd7fd4a7f  vmovaps xmm2, [rsp+0x20]
0000747fd7fd4a85  vmovaps xmm3, [rsp+0x30]
0000747fd7fd4a8b  vmovaps xmm4, [rsp+0x40]
0000747fd7fd4a91  vmovaps xmm5, [rsp+0x50]
0000747fd7fd4a97  vmovaps xmm6, [rsp+0x60]
0000747fd7fd4a9d  vmovaps xmm7, [rsp+0x70]
0000747fd7fd4aa3  vmovaps xmm9, [rsp+0x80]
0000747fd7fd4aac  vmovaps xmm10, [rsp+0x90]
0000747fd7fd4ab5  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd4abe  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd4ac7  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd4ad0  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd4ad9  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4ae2  add rsp, 0xF0
0000747fd7fd4ae9  pop r11
0000747fd7fd4aeb  pop r10
0000747fd7fd4aed  pop r9
0000747fd7fd4aef  pop r8
0000747fd7fd4af1  pop rsi
0000747fd7fd4af2  pop rdi
0000747fd7fd4af3  pop rdx
0000747fd7fd4af4  pop rcx
0000747fd7fd4af5  pop rax
0000747fd7fd4af6  add rsp, 0x08
0000747fd7fd4afa  jmp 0x0000747FD7FD01AF
0000747fd7fd4aff  sub rsp, 0x08
0000747fd7fd4b03  push rax
0000747fd7fd4b04  push rcx
0000747fd7fd4b05  push rdx
0000747fd7fd4b06  push rdi
0000747fd7fd4b07  push rsi
0000747fd7fd4b08  push r8
0000747fd7fd4b0a  push r9
0000747fd7fd4b0c  push r10
0000747fd7fd4b0e  push r11
0000747fd7fd4b10  sub rsp, 0xF0
0000747fd7fd4b17  vmovaps [rsp], xmm0
0000747fd7fd4b1c  vmovaps [rsp+0x10], xmm1
0000747fd7fd4b22  vmovaps [rsp+0x20], xmm2
0000747fd7fd4b28  vmovaps [rsp+0x30], xmm3
0000747fd7fd4b2e  vmovaps [rsp+0x40], xmm4
0000747fd7fd4b34  vmovaps [rsp+0x50], xmm5
0000747fd7fd4b3a  vmovaps [rsp+0x60], xmm6
0000747fd7fd4b40  vmovaps [rsp+0x70], xmm7
0000747fd7fd4b46  vmovaps [rsp+0x80], xmm8
0000747fd7fd4b4f  vmovaps [rsp+0x90], xmm10
0000747fd7fd4b58  vmovaps [rsp+0xA0], xmm11
0000747fd7fd4b61  vmovaps [rsp+0xB0], xmm12
0000747fd7fd4b6a  vmovaps [rsp+0xC0], xmm13
0000747fd7fd4b73  vmovaps [rsp+0xD0], xmm14
0000747fd7fd4b7c  vmovaps [rsp+0xE0], xmm15
0000747fd7fd4b85  sub rsp, 0x30
0000747fd7fd4b89  movaps [rsp], xmm9
0000747fd7fd4b8e  movaps [rsp+0x10], xmm1
0000747fd7fd4b93  movaps [rsp+0x20], xmm14
0000747fd7fd4b99  lea rdi, [rsp]
0000747fd7fd4b9d  mov esi, 0x00
0000747fd7fd4ba2  mov rax, 0x6055A0B6E530
0000747fd7fd4bac  call rax
0000747fd7fd4bae  movaps xmm9, [rsp]
0000747fd7fd4bb3  add rsp, 0x30
0000747fd7fd4bb7  vmovaps xmm0, [rsp]
0000747fd7fd4bbc  vmovaps xmm1, [rsp+0x10]
0000747fd7fd4bc2  vmovaps xmm2, [rsp+0x20]
0000747fd7fd4bc8  vmovaps xmm3, [rsp+0x30]
0000747fd7fd4bce  vmovaps xmm4, [rsp+0x40]
0000747fd7fd4bd4  vmovaps xmm5, [rsp+0x50]
0000747fd7fd4bda  vmovaps xmm6, [rsp+0x60]
0000747fd7fd4be0  vmovaps xmm7, [rsp+0x70]
0000747fd7fd4be6  vmovaps xmm8, [rsp+0x80]
0000747fd7fd4bef  vmovaps xmm10, [rsp+0x90]
0000747fd7fd4bf8  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd4c01  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd4c0a  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd4c13  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd4c1c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4c25  add rsp, 0xF0
0000747fd7fd4c2c  pop r11
0000747fd7fd4c2e  pop r10
0000747fd7fd4c30  pop r9
0000747fd7fd4c32  pop r8
0000747fd7fd4c34  pop rsi
0000747fd7fd4c35  pop rdi
0000747fd7fd4c36  pop rdx
0000747fd7fd4c37  pop rcx
0000747fd7fd4c38  pop rax
0000747fd7fd4c39  add rsp, 0x08
0000747fd7fd4c3d  jmp 0x0000747FD7FD01DD
0000747fd7fd4c42  sub rsp, 0x08
0000747fd7fd4c46  push rax
0000747fd7fd4c47  push rcx
0000747fd7fd4c48  push rdx
0000747fd7fd4c49  push rdi
0000747fd7fd4c4a  push rsi
0000747fd7fd4c4b  push r8
0000747fd7fd4c4d  push r9
0000747fd7fd4c4f  push r10
0000747fd7fd4c51  push r11
0000747fd7fd4c53  sub rsp, 0xF0
0000747fd7fd4c5a  vmovaps [rsp], xmm0
0000747fd7fd4c5f  vmovaps [rsp+0x10], xmm1
0000747fd7fd4c65  vmovaps [rsp+0x20], xmm2
0000747fd7fd4c6b  vmovaps [rsp+0x30], xmm3
0000747fd7fd4c71  vmovaps [rsp+0x40], xmm4
0000747fd7fd4c77  vmovaps [rsp+0x50], xmm5
0000747fd7fd4c7d  vmovaps [rsp+0x60], xmm6
0000747fd7fd4c83  vmovaps [rsp+0x70], xmm7
0000747fd7fd4c89  vmovaps [rsp+0x80], xmm8
0000747fd7fd4c92  vmovaps [rsp+0x90], xmm9
0000747fd7fd4c9b  vmovaps [rsp+0xA0], xmm10
0000747fd7fd4ca4  vmovaps [rsp+0xB0], xmm11
0000747fd7fd4cad  vmovaps [rsp+0xC0], xmm12
0000747fd7fd4cb6  vmovaps [rsp+0xD0], xmm13
0000747fd7fd4cbf  vmovaps [rsp+0xE0], xmm15
0000747fd7fd4cc8  sub rsp, 0x30
0000747fd7fd4ccc  movaps [rsp], xmm14
0000747fd7fd4cd1  movaps [rsp+0x10], xmm4
0000747fd7fd4cd6  movaps [rsp+0x20], xmm1
0000747fd7fd4cdb  lea rdi, [rsp]
0000747fd7fd4cdf  mov esi, 0x00
0000747fd7fd4ce4  mov rax, 0x6055A0B6E530
0000747fd7fd4cee  call rax
0000747fd7fd4cf0  movaps xmm14, [rsp]
0000747fd7fd4cf5  add rsp, 0x30
0000747fd7fd4cf9  vmovaps xmm0, [rsp]
0000747fd7fd4cfe  vmovaps xmm1, [rsp+0x10]
0000747fd7fd4d04  vmovaps xmm2, [rsp+0x20]
0000747fd7fd4d0a  vmovaps xmm3, [rsp+0x30]
0000747fd7fd4d10  vmovaps xmm4, [rsp+0x40]
0000747fd7fd4d16  vmovaps xmm5, [rsp+0x50]
0000747fd7fd4d1c  vmovaps xmm6, [rsp+0x60]
0000747fd7fd4d22  vmovaps xmm7, [rsp+0x70]
0000747fd7fd4d28  vmovaps xmm8, [rsp+0x80]
0000747fd7fd4d31  vmovaps xmm9, [rsp+0x90]
0000747fd7fd4d3a  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd4d43  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd4d4c  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd4d55  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd4d5e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4d67  add rsp, 0xF0
0000747fd7fd4d6e  pop r11
0000747fd7fd4d70  pop r10
0000747fd7fd4d72  pop r9
0000747fd7fd4d74  pop r8
0000747fd7fd4d76  pop rsi
0000747fd7fd4d77  pop rdi
0000747fd7fd4d78  pop rdx
0000747fd7fd4d79  pop rcx
0000747fd7fd4d7a  pop rax
0000747fd7fd4d7b  add rsp, 0x08
0000747fd7fd4d7f  jmp 0x0000747FD7FD0203
0000747fd7fd4d84  sub rsp, 0x08
0000747fd7fd4d88  push rax
0000747fd7fd4d89  push rcx
0000747fd7fd4d8a  push rdx
0000747fd7fd4d8b  push rdi
0000747fd7fd4d8c  push rsi
0000747fd7fd4d8d  push r8
0000747fd7fd4d8f  push r9
0000747fd7fd4d91  push r10
0000747fd7fd4d93  push r11
0000747fd7fd4d95  sub rsp, 0xF0
0000747fd7fd4d9c  vmovaps [rsp], xmm0
0000747fd7fd4da1  vmovaps [rsp+0x10], xmm2
0000747fd7fd4da7  vmovaps [rsp+0x20], xmm3
0000747fd7fd4dad  vmovaps [rsp+0x30], xmm4
0000747fd7fd4db3  vmovaps [rsp+0x40], xmm5
0000747fd7fd4db9  vmovaps [rsp+0x50], xmm6
0000747fd7fd4dbf  vmovaps [rsp+0x60], xmm7
0000747fd7fd4dc5  vmovaps [rsp+0x70], xmm8
0000747fd7fd4dcb  vmovaps [rsp+0x80], xmm9
0000747fd7fd4dd4  vmovaps [rsp+0x90], xmm10
0000747fd7fd4ddd  vmovaps [rsp+0xA0], xmm11
0000747fd7fd4de6  vmovaps [rsp+0xB0], xmm12
0000747fd7fd4def  vmovaps [rsp+0xC0], xmm13
0000747fd7fd4df8  vmovaps [rsp+0xD0], xmm14
0000747fd7fd4e01  vmovaps [rsp+0xE0], xmm15
0000747fd7fd4e0a  sub rsp, 0x30
0000747fd7fd4e0e  movaps [rsp], xmm1
0000747fd7fd4e12  movaps [rsp+0x10], xmm12
0000747fd7fd4e18  movaps [rsp+0x20], xmm11
0000747fd7fd4e1e  lea rdi, [rsp]
0000747fd7fd4e22  mov esi, 0x00
0000747fd7fd4e27  mov rax, 0x6055A0B6E530
0000747fd7fd4e31  call rax
0000747fd7fd4e33  movaps xmm1, [rsp]
0000747fd7fd4e37  add rsp, 0x30
0000747fd7fd4e3b  vmovaps xmm0, [rsp]
0000747fd7fd4e40  vmovaps xmm2, [rsp+0x10]
0000747fd7fd4e46  vmovaps xmm3, [rsp+0x20]
0000747fd7fd4e4c  vmovaps xmm4, [rsp+0x30]
0000747fd7fd4e52  vmovaps xmm5, [rsp+0x40]
0000747fd7fd4e58  vmovaps xmm6, [rsp+0x50]
0000747fd7fd4e5e  vmovaps xmm7, [rsp+0x60]
0000747fd7fd4e64  vmovaps xmm8, [rsp+0x70]
0000747fd7fd4e6a  vmovaps xmm9, [rsp+0x80]
0000747fd7fd4e73  vmovaps xmm10, [rsp+0x90]
0000747fd7fd4e7c  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd4e85  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd4e8e  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd4e97  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd4ea0  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4ea9  add rsp, 0xF0
0000747fd7fd4eb0  pop r11
0000747fd7fd4eb2  pop r10
0000747fd7fd4eb4  pop r9
0000747fd7fd4eb6  pop r8
0000747fd7fd4eb8  pop rsi
0000747fd7fd4eb9  pop rdi
0000747fd7fd4eba  pop rdx
0000747fd7fd4ebb  pop rcx
0000747fd7fd4ebc  pop rax
0000747fd7fd4ebd  add rsp, 0x08
0000747fd7fd4ec1  jmp 0x0000747FD7FD0224
0000747fd7fd4ec6  call 0x0000747FD7EE20A0
0000747fd7fd4ecb  jmp 0x0000747FD7FD0232
0000747fd7fd4ed0  call 0x0000747FD7E09D70
0000747fd7fd4ed5  jmp 0x0000747FD7FD023C
0000747fd7fd4eda  sub rsp, 0x08
0000747fd7fd4ede  push rax
0000747fd7fd4edf  push rcx
0000747fd7fd4ee0  push rdx
0000747fd7fd4ee1  push rdi
0000747fd7fd4ee2  push rsi
0000747fd7fd4ee3  push r8
0000747fd7fd4ee5  push r9
0000747fd7fd4ee7  push r10
0000747fd7fd4ee9  push r11
0000747fd7fd4eeb  sub rsp, 0xF0
0000747fd7fd4ef2  vmovaps [rsp], xmm0
0000747fd7fd4ef7  vmovaps [rsp+0x10], xmm1
0000747fd7fd4efd  vmovaps [rsp+0x20], xmm2
0000747fd7fd4f03  vmovaps [rsp+0x30], xmm3
0000747fd7fd4f09  vmovaps [rsp+0x40], xmm4
0000747fd7fd4f0f  vmovaps [rsp+0x50], xmm5
0000747fd7fd4f15  vmovaps [rsp+0x60], xmm6
0000747fd7fd4f1b  vmovaps [rsp+0x70], xmm8
0000747fd7fd4f21  vmovaps [rsp+0x80], xmm9
0000747fd7fd4f2a  vmovaps [rsp+0x90], xmm10
0000747fd7fd4f33  vmovaps [rsp+0xA0], xmm11
0000747fd7fd4f3c  vmovaps [rsp+0xB0], xmm12
0000747fd7fd4f45  vmovaps [rsp+0xC0], xmm13
0000747fd7fd4f4e  vmovaps [rsp+0xD0], xmm14
0000747fd7fd4f57  vmovaps [rsp+0xE0], xmm15
0000747fd7fd4f60  sub rsp, 0x30
0000747fd7fd4f64  movaps [rsp], xmm7
0000747fd7fd4f68  movaps [rsp+0x10], xmm15
0000747fd7fd4f6e  movaps [rsp+0x20], xmm10
0000747fd7fd4f74  lea rdi, [rsp]
0000747fd7fd4f78  mov esi, 0x00
0000747fd7fd4f7d  mov rax, 0x6055A0B6E530
0000747fd7fd4f87  call rax
0000747fd7fd4f89  movaps xmm7, [rsp]
0000747fd7fd4f8d  add rsp, 0x30
0000747fd7fd4f91  vmovaps xmm0, [rsp]
0000747fd7fd4f96  vmovaps xmm1, [rsp+0x10]
0000747fd7fd4f9c  vmovaps xmm2, [rsp+0x20]
0000747fd7fd4fa2  vmovaps xmm3, [rsp+0x30]
0000747fd7fd4fa8  vmovaps xmm4, [rsp+0x40]
0000747fd7fd4fae  vmovaps xmm5, [rsp+0x50]
0000747fd7fd4fb4  vmovaps xmm6, [rsp+0x60]
0000747fd7fd4fba  vmovaps xmm8, [rsp+0x70]
0000747fd7fd4fc0  vmovaps xmm9, [rsp+0x80]
0000747fd7fd4fc9  vmovaps xmm10, [rsp+0x90]
0000747fd7fd4fd2  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd4fdb  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd4fe4  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd4fed  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd4ff6  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd4fff  add rsp, 0xF0
0000747fd7fd5006  pop r11
0000747fd7fd5008  pop r10
0000747fd7fd500a  pop r9
0000747fd7fd500c  pop r8
0000747fd7fd500e  pop rsi
0000747fd7fd500f  pop rdi
0000747fd7fd5010  pop rdx
0000747fd7fd5011  pop rcx
0000747fd7fd5012  pop rax
0000747fd7fd5013  add rsp, 0x08
0000747fd7fd5017  jmp 0x0000747FD7FD025D
0000747fd7fd501c  sub rsp, 0x08
0000747fd7fd5020  push rax
0000747fd7fd5021  push rcx
0000747fd7fd5022  push rdx
0000747fd7fd5023  push rdi
0000747fd7fd5024  push rsi
0000747fd7fd5025  push r8
0000747fd7fd5027  push r9
0000747fd7fd5029  push r10
0000747fd7fd502b  push r11
0000747fd7fd502d  sub rsp, 0xF0
0000747fd7fd5034  vmovaps [rsp], xmm0
0000747fd7fd5039  vmovaps [rsp+0x10], xmm1
0000747fd7fd503f  vmovaps [rsp+0x20], xmm2
0000747fd7fd5045  vmovaps [rsp+0x30], xmm3
0000747fd7fd504b  vmovaps [rsp+0x40], xmm4
0000747fd7fd5051  vmovaps [rsp+0x50], xmm5
0000747fd7fd5057  vmovaps [rsp+0x60], xmm6
0000747fd7fd505d  vmovaps [rsp+0x70], xmm7
0000747fd7fd5063  vmovaps [rsp+0x80], xmm8
0000747fd7fd506c  vmovaps [rsp+0x90], xmm9
0000747fd7fd5075  vmovaps [rsp+0xA0], xmm11
0000747fd7fd507e  vmovaps [rsp+0xB0], xmm12
0000747fd7fd5087  vmovaps [rsp+0xC0], xmm13
0000747fd7fd5090  vmovaps [rsp+0xD0], xmm14
0000747fd7fd5099  vmovaps [rsp+0xE0], xmm15
0000747fd7fd50a2  sub rsp, 0x30
0000747fd7fd50a6  movaps [rsp], xmm10
0000747fd7fd50ab  movaps [rsp+0x10], xmm11
0000747fd7fd50b1  movaps [rsp+0x20], xmm15
0000747fd7fd50b7  lea rdi, [rsp]
0000747fd7fd50bb  mov esi, 0x00
0000747fd7fd50c0  mov rax, 0x6055A0B6E530
0000747fd7fd50ca  call rax
0000747fd7fd50cc  movaps xmm10, [rsp]
0000747fd7fd50d1  add rsp, 0x30
0000747fd7fd50d5  vmovaps xmm0, [rsp]
0000747fd7fd50da  vmovaps xmm1, [rsp+0x10]
0000747fd7fd50e0  vmovaps xmm2, [rsp+0x20]
0000747fd7fd50e6  vmovaps xmm3, [rsp+0x30]
0000747fd7fd50ec  vmovaps xmm4, [rsp+0x40]
0000747fd7fd50f2  vmovaps xmm5, [rsp+0x50]
0000747fd7fd50f8  vmovaps xmm6, [rsp+0x60]
0000747fd7fd50fe  vmovaps xmm7, [rsp+0x70]
0000747fd7fd5104  vmovaps xmm8, [rsp+0x80]
0000747fd7fd510d  vmovaps xmm9, [rsp+0x90]
0000747fd7fd5116  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd511f  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd5128  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd5131  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd513a  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd5143  add rsp, 0xF0
0000747fd7fd514a  pop r11
0000747fd7fd514c  pop r10
0000747fd7fd514e  pop r9
0000747fd7fd5150  pop r8
0000747fd7fd5152  pop rsi
0000747fd7fd5153  pop rdi
0000747fd7fd5154  pop rdx
0000747fd7fd5155  pop rcx
0000747fd7fd5156  pop rax
0000747fd7fd5157  add rsp, 0x08
0000747fd7fd515b  jmp 0x0000747FD7FD028B
0000747fd7fd5160  sub rsp, 0x08
0000747fd7fd5164  push rax
0000747fd7fd5165  push rcx
0000747fd7fd5166  push rdx
0000747fd7fd5167  push rdi
0000747fd7fd5168  push rsi
0000747fd7fd5169  push r8
0000747fd7fd516b  push r9
0000747fd7fd516d  push r10
0000747fd7fd516f  push r11
0000747fd7fd5171  sub rsp, 0xF0
0000747fd7fd5178  vmovaps [rsp], xmm0
0000747fd7fd517d  vmovaps [rsp+0x10], xmm1
0000747fd7fd5183  vmovaps [rsp+0x20], xmm2
0000747fd7fd5189  vmovaps [rsp+0x30], xmm3
0000747fd7fd518f  vmovaps [rsp+0x40], xmm4
0000747fd7fd5195  vmovaps [rsp+0x50], xmm5
0000747fd7fd519b  vmovaps [rsp+0x60], xmm6
0000747fd7fd51a1  vmovaps [rsp+0x70], xmm7
0000747fd7fd51a7  vmovaps [rsp+0x80], xmm8
0000747fd7fd51b0  vmovaps [rsp+0x90], xmm9
0000747fd7fd51b9  vmovaps [rsp+0xA0], xmm10
0000747fd7fd51c2  vmovaps [rsp+0xB0], xmm12
0000747fd7fd51cb  vmovaps [rsp+0xC0], xmm13
0000747fd7fd51d4  vmovaps [rsp+0xD0], xmm14
0000747fd7fd51dd  vmovaps [rsp+0xE0], xmm15
0000747fd7fd51e6  sub rsp, 0x30
0000747fd7fd51ea  movaps [rsp], xmm11
0000747fd7fd51ef  movaps [rsp+0x10], xmm12
0000747fd7fd51f5  movaps [rsp+0x20], xmm15
0000747fd7fd51fb  lea rdi, [rsp]
0000747fd7fd51ff  mov esi, 0x00
0000747fd7fd5204  mov rax, 0x6055A0B6E530
0000747fd7fd520e  call rax
0000747fd7fd5210  movaps xmm11, [rsp]
0000747fd7fd5215  add rsp, 0x30
0000747fd7fd5219  vmovaps xmm0, [rsp]
0000747fd7fd521e  vmovaps xmm1, [rsp+0x10]
0000747fd7fd5224  vmovaps xmm2, [rsp+0x20]
0000747fd7fd522a  vmovaps xmm3, [rsp+0x30]
0000747fd7fd5230  vmovaps xmm4, [rsp+0x40]
0000747fd7fd5236  vmovaps xmm5, [rsp+0x50]
0000747fd7fd523c  vmovaps xmm6, [rsp+0x60]
0000747fd7fd5242  vmovaps xmm7, [rsp+0x70]
0000747fd7fd5248  vmovaps xmm8, [rsp+0x80]
0000747fd7fd5251  vmovaps xmm9, [rsp+0x90]
0000747fd7fd525a  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd5263  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd526c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd5275  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd527e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd5287  add rsp, 0xF0
0000747fd7fd528e  pop r11
0000747fd7fd5290  pop r10
0000747fd7fd5292  pop r9
0000747fd7fd5294  pop r8
0000747fd7fd5296  pop rsi
0000747fd7fd5297  pop rdi
0000747fd7fd5298  pop rdx
0000747fd7fd5299  pop rcx
0000747fd7fd529a  pop rax
0000747fd7fd529b  add rsp, 0x08
0000747fd7fd529f  jmp 0x0000747FD7FD02B9
0000747fd7fd52a4  sub rsp, 0x08
0000747fd7fd52a8  push rax
0000747fd7fd52a9  push rcx
0000747fd7fd52aa  push rdx
0000747fd7fd52ab  push rdi
0000747fd7fd52ac  push rsi
0000747fd7fd52ad  push r8
0000747fd7fd52af  push r9
0000747fd7fd52b1  push r10
0000747fd7fd52b3  push r11
0000747fd7fd52b5  sub rsp, 0xF0
0000747fd7fd52bc  vmovaps [rsp], xmm0
0000747fd7fd52c1  vmovaps [rsp+0x10], xmm1
0000747fd7fd52c7  vmovaps [rsp+0x20], xmm2
0000747fd7fd52cd  vmovaps [rsp+0x30], xmm3
0000747fd7fd52d3  vmovaps [rsp+0x40], xmm4
0000747fd7fd52d9  vmovaps [rsp+0x50], xmm5
0000747fd7fd52df  vmovaps [rsp+0x60], xmm6
0000747fd7fd52e5  vmovaps [rsp+0x70], xmm7
0000747fd7fd52eb  vmovaps [rsp+0x80], xmm8
0000747fd7fd52f4  vmovaps [rsp+0x90], xmm9
0000747fd7fd52fd  vmovaps [rsp+0xA0], xmm10
0000747fd7fd5306  vmovaps [rsp+0xB0], xmm11
0000747fd7fd530f  vmovaps [rsp+0xC0], xmm12
0000747fd7fd5318  vmovaps [rsp+0xD0], xmm13
0000747fd7fd5321  vmovaps [rsp+0xE0], xmm14
0000747fd7fd532a  sub rsp, 0x30
0000747fd7fd532e  movaps [rsp], xmm15
0000747fd7fd5333  movaps [rsp+0x10], xmm13
0000747fd7fd5339  movaps [rsp+0x20], xmm9
0000747fd7fd533f  lea rdi, [rsp]
0000747fd7fd5343  mov esi, 0x00
0000747fd7fd5348  mov rax, 0x6055A0B6E530
0000747fd7fd5352  call rax
0000747fd7fd5354  movaps xmm15, [rsp]
0000747fd7fd5359  add rsp, 0x30
0000747fd7fd535d  vmovaps xmm0, [rsp]
0000747fd7fd5362  vmovaps xmm1, [rsp+0x10]
0000747fd7fd5368  vmovaps xmm2, [rsp+0x20]
0000747fd7fd536e  vmovaps xmm3, [rsp+0x30]
0000747fd7fd5374  vmovaps xmm4, [rsp+0x40]
0000747fd7fd537a  vmovaps xmm5, [rsp+0x50]
0000747fd7fd5380  vmovaps xmm6, [rsp+0x60]
0000747fd7fd5386  vmovaps xmm7, [rsp+0x70]
0000747fd7fd538c  vmovaps xmm8, [rsp+0x80]
0000747fd7fd5395  vmovaps xmm9, [rsp+0x90]
0000747fd7fd539e  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd53a7  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd53b0  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd53b9  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd53c2  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd53cb  add rsp, 0xF0
0000747fd7fd53d2  pop r11
0000747fd7fd53d4  pop r10
0000747fd7fd53d6  pop r9
0000747fd7fd53d8  pop r8
0000747fd7fd53da  pop rsi
0000747fd7fd53db  pop rdi
0000747fd7fd53dc  pop rdx
0000747fd7fd53dd  pop rcx
0000747fd7fd53de  pop rax
0000747fd7fd53df  add rsp, 0x08
0000747fd7fd53e3  jmp 0x0000747FD7FD02D4
0000747fd7fd53e8  sub rsp, 0x08
0000747fd7fd53ec  push rax
0000747fd7fd53ed  push rcx
0000747fd7fd53ee  push rdx
0000747fd7fd53ef  push rdi
0000747fd7fd53f0  push rsi
0000747fd7fd53f1  push r8
0000747fd7fd53f3  push r9
0000747fd7fd53f5  push r10
0000747fd7fd53f7  push r11
0000747fd7fd53f9  sub rsp, 0xF0
0000747fd7fd5400  vmovaps [rsp], xmm0
0000747fd7fd5405  vmovaps [rsp+0x10], xmm1
0000747fd7fd540b  vmovaps [rsp+0x20], xmm2
0000747fd7fd5411  vmovaps [rsp+0x30], xmm3
0000747fd7fd5417  vmovaps [rsp+0x40], xmm4
0000747fd7fd541d  vmovaps [rsp+0x50], xmm5
0000747fd7fd5423  vmovaps [rsp+0x60], xmm6
0000747fd7fd5429  vmovaps [rsp+0x70], xmm7
0000747fd7fd542f  vmovaps [rsp+0x80], xmm8
0000747fd7fd5438  vmovaps [rsp+0x90], xmm9
0000747fd7fd5441  vmovaps [rsp+0xA0], xmm10
0000747fd7fd544a  vmovaps [rsp+0xB0], xmm11
0000747fd7fd5453  vmovaps [rsp+0xC0], xmm12
0000747fd7fd545c  vmovaps [rsp+0xD0], xmm14
0000747fd7fd5465  vmovaps [rsp+0xE0], xmm15
0000747fd7fd546e  sub rsp, 0x30
0000747fd7fd5472  movaps [rsp], xmm13
0000747fd7fd5477  movaps [rsp+0x10], xmm8
0000747fd7fd547d  movaps [rsp+0x20], xmm14
0000747fd7fd5483  lea rdi, [rsp]
0000747fd7fd5487  mov esi, 0x00
0000747fd7fd548c  mov rax, 0x6055A0B6E530
0000747fd7fd5496  call rax
0000747fd7fd5498  movaps xmm13, [rsp]
0000747fd7fd549d  add rsp, 0x30
0000747fd7fd54a1  vmovaps xmm0, [rsp]
0000747fd7fd54a6  vmovaps xmm1, [rsp+0x10]
0000747fd7fd54ac  vmovaps xmm2, [rsp+0x20]
0000747fd7fd54b2  vmovaps xmm3, [rsp+0x30]
0000747fd7fd54b8  vmovaps xmm4, [rsp+0x40]
0000747fd7fd54be  vmovaps xmm5, [rsp+0x50]
0000747fd7fd54c4  vmovaps xmm6, [rsp+0x60]
0000747fd7fd54ca  vmovaps xmm7, [rsp+0x70]
0000747fd7fd54d0  vmovaps xmm8, [rsp+0x80]
0000747fd7fd54d9  vmovaps xmm9, [rsp+0x90]
0000747fd7fd54e2  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd54eb  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd54f4  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd54fd  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd5506  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd550f  add rsp, 0xF0
0000747fd7fd5516  pop r11
0000747fd7fd5518  pop r10
0000747fd7fd551a  pop r9
0000747fd7fd551c  pop r8
0000747fd7fd551e  pop rsi
0000747fd7fd551f  pop rdi
0000747fd7fd5520  pop rdx
0000747fd7fd5521  pop rcx
0000747fd7fd5522  pop rax
0000747fd7fd5523  add rsp, 0x08
0000747fd7fd5527  jmp 0x0000747FD7FD02F7
0000747fd7fd552c  sub rsp, 0x08
0000747fd7fd5530  push rax
0000747fd7fd5531  push rcx
0000747fd7fd5532  push rdx
0000747fd7fd5533  push rdi
0000747fd7fd5534  push rsi
0000747fd7fd5535  push r8
0000747fd7fd5537  push r9
0000747fd7fd5539  push r10
0000747fd7fd553b  push r11
0000747fd7fd553d  sub rsp, 0xF0
0000747fd7fd5544  vmovaps [rsp], xmm0
0000747fd7fd5549  vmovaps [rsp+0x10], xmm1
0000747fd7fd554f  vmovaps [rsp+0x20], xmm2
0000747fd7fd5555  vmovaps [rsp+0x30], xmm3
0000747fd7fd555b  vmovaps [rsp+0x40], xmm4
0000747fd7fd5561  vmovaps [rsp+0x50], xmm5
0000747fd7fd5567  vmovaps [rsp+0x60], xmm6
0000747fd7fd556d  vmovaps [rsp+0x70], xmm7
0000747fd7fd5573  vmovaps [rsp+0x80], xmm8
0000747fd7fd557c  vmovaps [rsp+0x90], xmm9
0000747fd7fd5585  vmovaps [rsp+0xA0], xmm10
0000747fd7fd558e  vmovaps [rsp+0xB0], xmm11
0000747fd7fd5597  vmovaps [rsp+0xC0], xmm12
0000747fd7fd55a0  vmovaps [rsp+0xD0], xmm13
0000747fd7fd55a9  vmovaps [rsp+0xE0], xmm15
0000747fd7fd55b2  sub rsp, 0x30
0000747fd7fd55b6  movaps [rsp], xmm14
0000747fd7fd55bb  movaps [rsp+0x10], xmm1
0000747fd7fd55c0  movaps [rsp+0x20], xmm10
0000747fd7fd55c6  lea rdi, [rsp]
0000747fd7fd55ca  mov esi, 0x00
0000747fd7fd55cf  mov rax, 0x6055A0B6E530
0000747fd7fd55d9  call rax
0000747fd7fd55db  movaps xmm14, [rsp]
0000747fd7fd55e0  add rsp, 0x30
0000747fd7fd55e4  vmovaps xmm0, [rsp]
0000747fd7fd55e9  vmovaps xmm1, [rsp+0x10]
0000747fd7fd55ef  vmovaps xmm2, [rsp+0x20]
0000747fd7fd55f5  vmovaps xmm3, [rsp+0x30]
0000747fd7fd55fb  vmovaps xmm4, [rsp+0x40]
0000747fd7fd5601  vmovaps xmm5, [rsp+0x50]
0000747fd7fd5607  vmovaps xmm6, [rsp+0x60]
0000747fd7fd560d  vmovaps xmm7, [rsp+0x70]
0000747fd7fd5613  vmovaps xmm8, [rsp+0x80]
0000747fd7fd561c  vmovaps xmm9, [rsp+0x90]
0000747fd7fd5625  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd562e  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd5637  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd5640  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd5649  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd5652  add rsp, 0xF0
0000747fd7fd5659  pop r11
0000747fd7fd565b  pop r10
0000747fd7fd565d  pop r9
0000747fd7fd565f  pop r8
0000747fd7fd5661  pop rsi
0000747fd7fd5662  pop rdi
0000747fd7fd5663  pop rdx
0000747fd7fd5664  pop rcx
0000747fd7fd5665  pop rax
0000747fd7fd5666  add rsp, 0x08
0000747fd7fd566a  jmp 0x0000747FD7FD031A
0000747fd7fd566f  sub rsp, 0x08
0000747fd7fd5673  push rax
0000747fd7fd5674  push rcx
0000747fd7fd5675  push rdx
0000747fd7fd5676  push rdi
0000747fd7fd5677  push rsi
0000747fd7fd5678  push r8
0000747fd7fd567a  push r9
0000747fd7fd567c  push r10
0000747fd7fd567e  push r11
0000747fd7fd5680  sub rsp, 0xF0
0000747fd7fd5687  vmovaps [rsp], xmm0
0000747fd7fd568c  vmovaps [rsp+0x10], xmm2
0000747fd7fd5692  vmovaps [rsp+0x20], xmm3
0000747fd7fd5698  vmovaps [rsp+0x30], xmm4
0000747fd7fd569e  vmovaps [rsp+0x40], xmm5
0000747fd7fd56a4  vmovaps [rsp+0x50], xmm6
0000747fd7fd56aa  vmovaps [rsp+0x60], xmm7
0000747fd7fd56b0  vmovaps [rsp+0x70], xmm8
0000747fd7fd56b6  vmovaps [rsp+0x80], xmm9
0000747fd7fd56bf  vmovaps [rsp+0x90], xmm10
0000747fd7fd56c8  vmovaps [rsp+0xA0], xmm11
0000747fd7fd56d1  vmovaps [rsp+0xB0], xmm12
0000747fd7fd56da  vmovaps [rsp+0xC0], xmm13
0000747fd7fd56e3  vmovaps [rsp+0xD0], xmm14
0000747fd7fd56ec  vmovaps [rsp+0xE0], xmm15
0000747fd7fd56f5  sub rsp, 0x30
0000747fd7fd56f9  movaps [rsp], xmm1
0000747fd7fd56fd  movaps [rsp+0x10], xmm7
0000747fd7fd5702  movaps [rsp+0x20], xmm11
0000747fd7fd5708  lea rdi, [rsp]
0000747fd7fd570c  mov esi, 0x00
0000747fd7fd5711  mov rax, 0x6055A0B6E530
0000747fd7fd571b  call rax
0000747fd7fd571d  movaps xmm1, [rsp]
0000747fd7fd5721  add rsp, 0x30
0000747fd7fd5725  vmovaps xmm0, [rsp]
0000747fd7fd572a  vmovaps xmm2, [rsp+0x10]
0000747fd7fd5730  vmovaps xmm3, [rsp+0x20]
0000747fd7fd5736  vmovaps xmm4, [rsp+0x30]
0000747fd7fd573c  vmovaps xmm5, [rsp+0x40]
0000747fd7fd5742  vmovaps xmm6, [rsp+0x50]
0000747fd7fd5748  vmovaps xmm7, [rsp+0x60]
0000747fd7fd574e  vmovaps xmm8, [rsp+0x70]
0000747fd7fd5754  vmovaps xmm9, [rsp+0x80]
0000747fd7fd575d  vmovaps xmm10, [rsp+0x90]
0000747fd7fd5766  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd576f  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd5778  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd5781  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd578a  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd5793  add rsp, 0xF0
0000747fd7fd579a  pop r11
0000747fd7fd579c  pop r10
0000747fd7fd579e  pop r9
0000747fd7fd57a0  pop r8
0000747fd7fd57a2  pop rsi
0000747fd7fd57a3  pop rdi
0000747fd7fd57a4  pop rdx
0000747fd7fd57a5  pop rcx
0000747fd7fd57a6  pop rax
0000747fd7fd57a7  add rsp, 0x08
0000747fd7fd57ab  jmp 0x0000747FD7FD033B
0000747fd7fd57b0  call 0x0000747FD7E0E880
0000747fd7fd57b5  jmp 0x0000747FD7FD034E
0000747fd7fd57ba  call 0x0000747FD7E0C380
0000747fd7fd57bf  jmp 0x0000747FD7FD0359
0000747fd7fd57c4  call 0x0000747FD7E0D600
0000747fd7fd57c9  jmp 0x0000747FD7FD0364
0000747fd7fd57ce  call 0x0000747FD7DFF540
0000747fd7fd57d3  jmp 0x0000747FD7FD036F
0000747fd7fd57d8  int3
0000747fd7fd57d9  nop [rax], eax
0000747fd7fd57e0  mov rax, [r15+0x40]
0000747fd7fd57e4  mov r14, [r15+0x58]
0000747fd7fd57e8  lea r12, [rax+r14*1]
0000747fd7fd57ec  movaps xmm1, [r15+0x1D0]
0000747fd7fd57f4  vmovaps [rsp+0x10], xmm1
0000747fd7fd57fa  vmovaps xmm15, [rsp+0x10]
0000747fd7fd5800  por xmm1, xmm15
0000747fd7fd5805  movaps xmm14, [r15+0x1A0]
0000747fd7fd580d  vmovaps [rsp+0x10], xmm14
0000747fd7fd5813  vmovaps xmm13, [rsp+0x10]
0000747fd7fd5819  por xmm14, xmm13
0000747fd7fd581e  lea rax, [r12+0x30]
0000747fd7fd5823  mov r11, [r13+rax*1]
0000747fd7fd5828  lea rax, [r12+0x38]
0000747fd7fd582d  mov r10, [r13+rax*1]
0000747fd7fd5832  movq xmm13, r11
0000747fd7fd5837  movq xmm12, r10
0000747fd7fd583c  movq xmm13, xmm13
0000747fd7fd5841  vmovaps [rsp+0x10], xmm13
0000747fd7fd5847  movq xmm13, xmm13
0000747fd7fd584c  movaps [r15+0x130], xmm13
0000747fd7fd5854  movq xmm12, xmm12
0000747fd7fd5859  vmovaps [rsp+0x20], xmm12
0000747fd7fd585f  movq xmm12, xmm12
0000747fd7fd5864  movaps [r15+0x280], xmm12
0000747fd7fd586c  movaps xmm13, [r15+0x270]
0000747fd7fd5874  vmovaps [rsp+0x30], xmm13
0000747fd7fd587a  vmovaps xmm12, [rsp+0x30]
0000747fd7fd5880  por xmm13, xmm12
0000747fd7fd5885  lea rax, [r12+0x20]
0000747fd7fd588a  mov r11, [r13+rax*1]
0000747fd7fd588f  lea rax, [r12+0x28]
0000747fd7fd5894  mov r10, [r13+rax*1]
0000747fd7fd5899  movq xmm12, r11
0000747fd7fd589e  movq xmm11, r10
0000747fd7fd58a3  movq xmm12, xmm12
0000747fd7fd58a8  vmovaps [rsp+0x30], xmm12
0000747fd7fd58ae  movq xmm12, xmm12
0000747fd7fd58b3  movaps [r15+0x150], xmm12
0000747fd7fd58bb  movq xmm11, xmm11
0000747fd7fd58c0  vmovaps [rsp+0x40], xmm11
0000747fd7fd58c6  movq xmm11, xmm11
0000747fd7fd58cb  movaps [r15+0x140], xmm11
0000747fd7fd58d3  lea rax, [r12+0x10]
0000747fd7fd58d8  mov r11, [r13+rax*1]
0000747fd7fd58dd  lea rax, [r12+0x18]
0000747fd7fd58e2  mov r10, [r13+rax*1]
0000747fd7fd58e7  movq xmm12, r11
0000747fd7fd58ec  movq xmm11, r10
0000747fd7fd58f1  movq xmm12, xmm12
0000747fd7fd58f6  vmovaps [rsp+0x50], xmm12
0000747fd7fd58fc  movq xmm12, xmm12
0000747fd7fd5901  movaps [r15+0x170], xmm12
0000747fd7fd5909  movq xmm11, xmm11
0000747fd7fd590e  vmovaps [rsp+0x60], xmm11
0000747fd7fd5914  movq xmm11, xmm11
0000747fd7fd5919  movaps [r15+0x160], xmm11
0000747fd7fd5921  mov rax, [r13+r12*1]
0000747fd7fd5926  vmovq xmm12, rax
0000747fd7fd592b  vpbroadcastq xmm12, xmm12
0000747fd7fd5930  lea rax, [r12+0x08]
0000747fd7fd5935  mov r12, [r13+rax*1]
0000747fd7fd593a  movq xmm11, r12
0000747fd7fd593f  movaps [r15+0x230], xmm11
0000747fd7fd5947  mov rax, [r15+0xF8]
0000747fd7fd594e  lea r12, [rax+0x50]
0000747fd7fd5952  movups xmm11, [r13+r12*1]
0000747fd7fd5958  lea r12, [rax+0x60]
0000747fd7fd595c  movups xmm10, [r13+r12*1]
0000747fd7fd5962  lea r12, [rax+0x30]
0000747fd7fd5966  movups xmm9, [r13+r12*1]
0000747fd7fd596c  mov r12, [r15+0x50]
0000747fd7fd5970  lea r11, [r12+r14*1]
0000747fd7fd5974  mov [r15+0x60], r11
0000747fd7fd5978  lea r12, [r14+0x40]
0000747fd7fd597c  mov [r15+0x58], r12
0000747fd7fd5980  movaps xmm8, xmm12
0000747fd7fd5984  mulpd xmm8, xmm15
0000747fd7fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000747fd7fd598f  ptest xmm7, xmm7
0000747fd7fd5994  jnz 0x0000747FD7FD67B7
0000747fd7fd599a  movq xmm15, qword ptr [r15+0x230]
0000747fd7fd59a3  vmovaps [rsp+0x70], xmm15
0000747fd7fd59a9  vpermilpd xmm15, xmm15, 0x00
0000747fd7fd59af  movaps xmm7, xmm9
0000747fd7fd59b3  mulpd xmm7, xmm15
0000747fd7fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000747fd7fd59bd  ptest xmm6, xmm6
0000747fd7fd59c2  jnz 0x0000747FD7FD68FB
0000747fd7fd59c8  vxorps xmm15, xmm15, xmm15
0000747fd7fd59cd  vpbroadcastq xmm15, xmm15
0000747fd7fd59d2  movaps xmm9, xmm12
0000747fd7fd59d6  mulpd xmm9, xmm10
0000747fd7fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000747fd7fd59e1  ptest xmm6, xmm6
0000747fd7fd59e6  jnz 0x0000747FD7FD6A3D
0000747fd7fd59ec  movaps xmm10, xmm12
0000747fd7fd59f0  mulpd xmm10, xmm11
0000747fd7fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000747fd7fd59fb  ptest xmm6, xmm6
0000747fd7fd5a00  jnz 0x0000747FD7FD6B81
0000747fd7fd5a06  movaps xmm11, [r15+0x1F0]
0000747fd7fd5a0e  movaps xmm6, xmm12
0000747fd7fd5a12  mulpd xmm6, xmm11
0000747fd7fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000747fd7fd5a1c  ptest xmm5, xmm5
0000747fd7fd5a21  jnz 0x0000747FD7FD6CC5
0000747fd7fd5a27  movaps xmm12, [r15+0x2A0]
0000747fd7fd5a2f  vmovaps [rsp+0x80], xmm12
0000747fd7fd5a38  vmovaps xmm11, [rsp+0x80]
0000747fd7fd5a41  por xmm12, xmm11
0000747fd7fd5a46  movaps xmm11, [r15+0x250]
0000747fd7fd5a4e  vmovaps [rsp+0x80], xmm11
0000747fd7fd5a57  vmovaps xmm5, [rsp+0x80]
0000747fd7fd5a60  por xmm11, xmm5
0000747fd7fd5a65  vmovaps xmm4, [rsp+0x70]
0000747fd7fd5a6b  vpermilpd xmm4, xmm4, 0x00
0000747fd7fd5a71  movaps xmm3, xmm5
0000747fd7fd5a74  mulpd xmm3, xmm4
0000747fd7fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000747fd7fd5a7d  ptest xmm2, xmm2
0000747fd7fd5a82  jnz 0x0000747FD7FD6E07
0000747fd7fd5a88  mov [rsp+0x80], rax
0000747fd7fd5a90  xor eax, eax
0000747fd7fd5a92  mov r14d, 0x200
0000747fd7fd5a98  cmp r12, r14
0000747fd7fd5a9b  cmc
0000747fd7fd5a9c  lahf
0000747fd7fd5a9d  seto al
0000747fd7fd5aa0  mov [r15+0x108], eax
0000747fd7fd5aa7  movaps xmm5, xmm8
0000747fd7fd5aab  addpd xmm5, xmm15
0000747fd7fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000747fd7fd5ab5  ptest xmm4, xmm4
0000747fd7fd5aba  jnz 0x0000747FD7FD6F47
0000747fd7fd5ac0  movaps xmm8, [r15+0x1B0]
0000747fd7fd5ac8  movaps xmm4, xmm9
0000747fd7fd5acc  addpd xmm4, xmm8
0000747fd7fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000747fd7fd5ad6  ptest xmm2, xmm2
0000747fd7fd5adb  jnz 0x0000747FD7FD7089
0000747fd7fd5ae1  movaps xmm9, xmm10
0000747fd7fd5ae5  addpd xmm9, xmm8
0000747fd7fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000747fd7fd5af0  ptest xmm2, xmm2
0000747fd7fd5af5  jnz 0x0000747FD7FD71CB
0000747fd7fd5afb  movaps xmm10, [r15+0x2F0]
0000747fd7fd5b03  vmovaps [rsp+0x90], xmm10
0000747fd7fd5b0c  vmovaps xmm8, [rsp+0x90]
0000747fd7fd5b15  por xmm10, xmm8
0000747fd7fd5b1a  movaps xmm8, [r15+0x2E0]
0000747fd7fd5b22  vmovaps [rsp+0x90], xmm8
0000747fd7fd5b2b  vmovaps xmm2, [rsp+0x90]
0000747fd7fd5b34  por xmm8, xmm2
0000747fd7fd5b39  movaps xmm2, [r15+0x2D0]
0000747fd7fd5b41  vmovaps [rsp+0x90], xmm2
0000747fd7fd5b4a  vmovaps [rsp+0xA0], xmm1
0000747fd7fd5b53  vmovaps xmm1, [rsp+0x90]
0000747fd7fd5b5c  por xmm2, xmm1
0000747fd7fd5b60  movaps xmm1, [r15+0x200]
0000747fd7fd5b68  vmovaps [rsp+0x90], xmm1
0000747fd7fd5b71  vmovaps [rsp+0xB0], xmm15
0000747fd7fd5b7a  vmovaps xmm15, [rsp+0x90]
0000747fd7fd5b83  por xmm1, xmm15
0000747fd7fd5b88  movaps xmm15, [r15+0x1C0]
0000747fd7fd5b90  vmovaps [rsp+0x90], xmm15
0000747fd7fd5b99  vmovaps [rsp+0xC0], xmm1
0000747fd7fd5ba2  vmovaps xmm1, [rsp+0x90]
0000747fd7fd5bab  por xmm15, xmm1
0000747fd7fd5bb0  movaps xmm1, [r15+0x190]
0000747fd7fd5bb8  vmovaps [rsp+0x90], xmm1
0000747fd7fd5bc1  vmovaps [rsp+0xD0], xmm15
0000747fd7fd5bca  vmovaps xmm15, [rsp+0x90]
0000747fd7fd5bd3  por xmm1, xmm15
0000747fd7fd5bd8  movaps xmm15, [r15+0x300]
0000747fd7fd5be0  vmovaps [rsp+0x90], xmm15
0000747fd7fd5be9  vmovaps [rsp+0xE0], xmm1
0000747fd7fd5bf2  vmovaps xmm1, [rsp+0x90]
0000747fd7fd5bfb  por xmm15, xmm1
0000747fd7fd5c00  mov rax, [rsp+0x80]
0000747fd7fd5c08  lea r14, [rax+0xA0]
0000747fd7fd5c0f  movups xmm1, [r13+r14*1]
0000747fd7fd5c15  lea r14, [rax+0xB0]
0000747fd7fd5c1c  vmovaps [rsp+0x80], xmm1
0000747fd7fd5c25  movups xmm1, [r13+r14*1]
0000747fd7fd5c2b  vmovaps [rsp+0x90], xmm1
0000747fd7fd5c34  vmovaps [rsp+0xF0], xmm15
0000747fd7fd5c3d  vmovaps xmm15, [rsp+0xB0]
0000747fd7fd5c46  vmovaps [rsp+0xB0], xmm14
0000747fd7fd5c4f  movaps xmm1, xmm6
0000747fd7fd5c52  addpd xmm1, xmm15
0000747fd7fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000747fd7fd5c5c  ptest xmm14, xmm14
0000747fd7fd5c62  jnz 0x0000747FD7FD7323
0000747fd7fd5c68  lea r14, [rax+0xF0]
0000747fd7fd5c6f  movups xmm15, [r13+r14*1]
0000747fd7fd5c75  movaps xmm14, xmm4
0000747fd7fd5c79  addpd xmm14, xmm3
0000747fd7fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000747fd7fd5c84  ptest xmm6, xmm6
0000747fd7fd5c89  jnz 0x0000747FD7FD746E
0000747fd7fd5c8f  movaps xmm6, xmm9
0000747fd7fd5c93  addpd xmm6, xmm7
0000747fd7fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000747fd7fd5c9c  ptest xmm4, xmm4
0000747fd7fd5ca1  jnz 0x0000747FD7FD75B0
0000747fd7fd5ca7  vmovaps xmm9, [rsp+0x70]
0000747fd7fd5cad  vpermilpd xmm9, xmm9, 0x00
0000747fd7fd5cb3  vmovaps xmm4, [rsp+0x90]
0000747fd7fd5cbc  movaps xmm7, xmm4
0000747fd7fd5cbf  mulpd xmm7, xmm9
0000747fd7fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000747fd7fd5cc9  ptest xmm3, xmm3
0000747fd7fd5cce  jnz 0x0000747FD7FD76F1
0000747fd7fd5cd4  vmovaps xmm9, [rsp+0x50]
0000747fd7fd5cda  vpermilpd xmm9, xmm9, 0x00
0000747fd7fd5ce0  movaps xmm4, xmm15
0000747fd7fd5ce4  mulpd xmm4, xmm9
0000747fd7fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000747fd7fd5cee  ptest xmm3, xmm3
0000747fd7fd5cf3  jnz 0x0000747FD7FD7832
0000747fd7fd5cf9  lea r14, [rax+0xE0]
0000747fd7fd5d00  movups xmm15, [r13+r14*1]
0000747fd7fd5d06  vmovaps xmm9, [rsp+0x70]
0000747fd7fd5d0c  vpermilpd xmm9, xmm9, 0x00
0000747fd7fd5d12  vmovaps [rsp+0x70], xmm1
0000747fd7fd5d18  vmovaps xmm1, [rsp+0x80]
0000747fd7fd5d21  vmovaps [rsp+0x80], xmm15
0000747fd7fd5d2a  movaps xmm3, xmm1
0000747fd7fd5d2d  mulpd xmm3, xmm9
0000747fd7fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000747fd7fd5d37  ptest xmm15, xmm15
0000747fd7fd5d3d  jnz 0x0000747FD7FD797E
0000747fd7fd5d43  vmovaps xmm1, [rsp+0xF0]
0000747fd7fd5d4c  vmovaps xmm15, [rsp+0xF0]
0000747fd7fd5d55  por xmm1, xmm15
0000747fd7fd5d5a  movaps [r15+0x300], xmm1
0000747fd7fd5d62  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd5d6b  vmovaps xmm9, [rsp+0xE0]
0000747fd7fd5d74  por xmm15, xmm9
0000747fd7fd5d79  movaps [r15+0x190], xmm15
0000747fd7fd5d81  vmovaps xmm9, [rsp+0x50]
0000747fd7fd5d87  vpermilpd xmm9, xmm9, 0x00
0000747fd7fd5d8d  vmovaps [rsp+0x90], xmm1
0000747fd7fd5d96  vmovaps [rsp+0xE0], xmm15
0000747fd7fd5d9f  vmovaps xmm15, [rsp+0x80]
0000747fd7fd5da8  vmovaps [rsp+0x80], xmm14
0000747fd7fd5db1  movaps xmm1, xmm15
0000747fd7fd5db5  mulpd xmm1, xmm9
0000747fd7fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000747fd7fd5dbf  ptest xmm14, xmm14
0000747fd7fd5dc5  jnz 0x0000747FD7FD7ABF
0000747fd7fd5dcb  lea r14, [rax+0x90]
0000747fd7fd5dd2  movups xmm15, [r13+r14*1]
0000747fd7fd5dd8  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd5de1  vmovaps xmm9, [rsp+0xD0]
0000747fd7fd5dea  por xmm14, xmm9
0000747fd7fd5def  movaps [r15+0x1C0], xmm14
0000747fd7fd5df7  vmovaps xmm9, [rsp+0xC0]
0000747fd7fd5e00  vmovaps [rsp+0xD0], xmm1
0000747fd7fd5e09  vmovaps xmm1, [rsp+0xC0]
0000747fd7fd5e12  por xmm9, xmm1
0000747fd7fd5e17  movaps [r15+0x200], xmm9
0000747fd7fd5e1f  vmovaps [rsp+0xC0], xmm2
0000747fd7fd5e28  vmovaps xmm1, [rsp+0xC0]
0000747fd7fd5e31  por xmm2, xmm1
0000747fd7fd5e35  movaps [r15+0x2D0], xmm2
0000747fd7fd5e3d  vmovaps [rsp+0xC0], xmm8
0000747fd7fd5e46  vmovaps xmm1, [rsp+0xC0]
0000747fd7fd5e4f  por xmm8, xmm1
0000747fd7fd5e54  movaps [r15+0x2E0], xmm8
0000747fd7fd5e5c  vmovaps [rsp+0xC0], xmm15
0000747fd7fd5e65  movaps xmm1, xmm5
0000747fd7fd5e68  addpd xmm1, xmm7
0000747fd7fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000747fd7fd5e71  ptest xmm15, xmm15
0000747fd7fd5e77  jnz 0x0000747FD7FD7C0B
0000747fd7fd5e7d  vmovaps xmm15, [rsp+0x50]
0000747fd7fd5e83  vpermilpd xmm15, xmm15, 0x00
0000747fd7fd5e89  vmovaps xmm5, [rsp+0xC0]
0000747fd7fd5e92  vmovaps [rsp+0xC0], xmm1
0000747fd7fd5e9b  movaps xmm7, xmm5
0000747fd7fd5e9e  mulpd xmm7, xmm15
0000747fd7fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000747fd7fd5ea8  ptest xmm1, xmm1
0000747fd7fd5ead  jnz 0x0000747FD7FD7D4B
0000747fd7fd5eb3  lea r14, [rax+0x80]
0000747fd7fd5eba  movups xmm1, [r13+r14*1]
0000747fd7fd5ec0  vmovaps xmm5, [rsp+0x70]
0000747fd7fd5ec6  vmovaps [rsp+0x70], xmm1
0000747fd7fd5ecc  movaps xmm15, xmm5
0000747fd7fd5ed0  addpd xmm15, xmm3
0000747fd7fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000747fd7fd5edb  ptest xmm1, xmm1
0000747fd7fd5ee0  jnz 0x0000747FD7FD7E96
0000747fd7fd5ee6  vmovaps xmm5, [rsp+0x80]
0000747fd7fd5eef  movaps xmm1, xmm5
0000747fd7fd5ef2  addpd xmm1, xmm4
0000747fd7fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000747fd7fd5efb  ptest xmm3, xmm3
0000747fd7fd5f00  jnz 0x0000747FD7FD7FD8
0000747fd7fd5f06  vmovaps [rsp+0x80], xmm10
0000747fd7fd5f0f  vmovaps xmm5, [rsp+0x80]
0000747fd7fd5f18  por xmm10, xmm5
0000747fd7fd5f1d  movaps [r15+0x2F0], xmm10
0000747fd7fd5f25  vmovaps xmm5, [rsp+0x50]
0000747fd7fd5f2b  vpermilpd xmm5, xmm5, 0x00
0000747fd7fd5f31  vmovaps xmm3, [rsp+0x70]
0000747fd7fd5f37  vmovaps [rsp+0x50], xmm1
0000747fd7fd5f3d  movaps xmm4, xmm3
0000747fd7fd5f40  mulpd xmm4, xmm5
0000747fd7fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000747fd7fd5f49  ptest xmm1, xmm1
0000747fd7fd5f4e  jnz 0x0000747FD7FD8118
0000747fd7fd5f54  lea r14, [rax+0xD0]
0000747fd7fd5f5b  movups xmm1, [r13+r14*1]
0000747fd7fd5f61  vmovaps xmm3, [rsp+0xD0]
0000747fd7fd5f6a  vmovaps [rsp+0x70], xmm1
0000747fd7fd5f70  movaps xmm5, xmm6
0000747fd7fd5f73  addpd xmm5, xmm3
0000747fd7fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000747fd7fd5f7c  ptest xmm1, xmm1
0000747fd7fd5f81  jnz 0x0000747FD7FD8262
0000747fd7fd5f87  vmovaps xmm1, [rsp+0x60]
0000747fd7fd5f8d  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd5f93  movaps xmm6, xmm9
0000747fd7fd5f97  mulpd xmm6, xmm1
0000747fd7fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000747fd7fd5fa0  ptest xmm3, xmm3
0000747fd7fd5fa5  jnz 0x0000747FD7FD83A2
0000747fd7fd5fab  movaps [r15+0x260], xmm6
0000747fd7fd5fb3  vxorps xmm1, xmm1, xmm1
0000747fd7fd5fb7  vpbroadcastq xmm1, xmm1
0000747fd7fd5fbc  movaps [r15+0x1B0], xmm1
0000747fd7fd5fc4  vmovaps xmm1, [rsp+0x60]
0000747fd7fd5fca  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd5fd0  vmovaps xmm3, [rsp+0x70]
0000747fd7fd5fd6  vmovaps [rsp+0x70], xmm15
0000747fd7fd5fdc  movaps xmm9, xmm3
0000747fd7fd5fe0  mulpd xmm9, xmm1
0000747fd7fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000747fd7fd5feb  ptest xmm15, xmm15
0000747fd7fd5ff1  jnz 0x0000747FD7FD84E3
0000747fd7fd5ff7  lea r14, [rax+0xC0]
0000747fd7fd5ffe  movups xmm1, [r13+r14*1]
0000747fd7fd6004  vmovaps xmm3, [rsp+0xC0]
0000747fd7fd600d  vmovaps [rsp+0x80], xmm1
0000747fd7fd6016  movaps xmm15, xmm3
0000747fd7fd601a  addpd xmm15, xmm7
0000747fd7fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000747fd7fd6025  ptest xmm1, xmm1
0000747fd7fd602a  jnz 0x0000747FD7FD862F
0000747fd7fd6030  vmovaps [rsp+0xC0], xmm13
0000747fd7fd6039  vmovaps xmm1, [rsp+0xC0]
0000747fd7fd6042  por xmm13, xmm1
0000747fd7fd6047  movaps [r15+0x270], xmm13
0000747fd7fd604f  vmovaps xmm1, [rsp+0xB0]
0000747fd7fd6058  vmovaps xmm7, [rsp+0xB0]
0000747fd7fd6061  por xmm1, xmm7
0000747fd7fd6065  movaps [r15+0x1A0], xmm1
0000747fd7fd606d  vmovaps xmm1, [rsp+0x60]
0000747fd7fd6073  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd6079  vmovaps [rsp+0xB0], xmm1
0000747fd7fd6082  vmovaps xmm1, [rsp+0x80]
0000747fd7fd608b  vmovaps [rsp+0x80], xmm15
0000747fd7fd6094  vmovaps xmm15, [rsp+0xB0]
0000747fd7fd609d  vmovaps [rsp+0xB0], xmm14
0000747fd7fd60a6  movaps xmm3, xmm1
0000747fd7fd60a9  mulpd xmm3, xmm15
0000747fd7fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000747fd7fd60b3  ptest xmm14, xmm14
0000747fd7fd60b9  jnz 0x0000747FD7FD8771
0000747fd7fd60bf  lea r14, [rax+0x20]
0000747fd7fd60c3  movups xmm1, [r13+r14*1]
0000747fd7fd60c9  movaps [r15+0x110], xmm1
0000747fd7fd60d1  vmovaps xmm14, [rsp+0x70]
0000747fd7fd60d7  vmovaps [rsp+0x70], xmm1
0000747fd7fd60dd  movaps xmm15, xmm14
0000747fd7fd60e1  addpd xmm15, xmm4
0000747fd7fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000747fd7fd60ec  ptest xmm1, xmm1
0000747fd7fd60f1  jnz 0x0000747FD7FD88BC
0000747fd7fd60f7  vmovaps xmm1, [rsp+0x60]
0000747fd7fd60fd  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd6103  movaps xmm14, xmm2
0000747fd7fd6107  mulpd xmm14, xmm1
0000747fd7fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000747fd7fd6112  ptest xmm4, xmm4
0000747fd7fd6117  jnz 0x0000747FD7FD89FF
0000747fd7fd611d  vmovaps xmm4, [rsp+0x50]
0000747fd7fd6123  movaps xmm1, xmm4
0000747fd7fd6126  addpd xmm1, xmm9
0000747fd7fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000747fd7fd6130  ptest xmm2, xmm2
0000747fd7fd6135  jnz 0x0000747FD7FD8B41
0000747fd7fd613b  vmovaps xmm9, [rsp+0x30]
0000747fd7fd6141  vpermilpd xmm9, xmm9, 0x00
0000747fd7fd6147  vmovaps xmm2, [rsp+0x70]
0000747fd7fd614d  vmovaps [rsp+0x50], xmm1
0000747fd7fd6153  movaps xmm4, xmm2
0000747fd7fd6156  mulpd xmm4, xmm9
0000747fd7fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000747fd7fd6160  ptest xmm1, xmm1
0000747fd7fd6165  jnz 0x0000747FD7FD8C82
0000747fd7fd616b  vmovaps xmm1, [rsp+0x30]
0000747fd7fd6171  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd6177  vmovaps xmm2, [rsp+0x90]
0000747fd7fd6180  vmovaps [rsp+0x60], xmm15
0000747fd7fd6186  movaps xmm9, xmm2
0000747fd7fd618a  mulpd xmm9, xmm1
0000747fd7fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000747fd7fd6195  ptest xmm15, xmm15
0000747fd7fd619b  jnz 0x0000747FD7FD8DC3
0000747fd7fd61a1  vmovaps xmm15, [rsp+0x80]
0000747fd7fd61aa  movaps xmm1, xmm15
0000747fd7fd61ae  addpd xmm1, xmm6
0000747fd7fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000747fd7fd61b7  ptest xmm2, xmm2
0000747fd7fd61bc  jnz 0x0000747FD7FD8F05
0000747fd7fd61c2  movaps xmm15, xmm5
0000747fd7fd61c6  addpd xmm15, xmm3
0000747fd7fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000747fd7fd61d1  ptest xmm6, xmm6
0000747fd7fd61d6  jnz 0x0000747FD7FD9046
0000747fd7fd61dc  vmovaps xmm6, [rsp+0x30]
0000747fd7fd61e2  vpermilpd xmm6, xmm6, 0x00
0000747fd7fd61e8  movaps xmm5, xmm8
0000747fd7fd61ec  mulpd xmm5, xmm6
0000747fd7fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000747fd7fd61f5  ptest xmm3, xmm3
0000747fd7fd61fa  jnz 0x0000747FD7FD9188
0000747fd7fd6200  vmovaps xmm8, [rsp+0x30]
0000747fd7fd6206  vpermilpd xmm8, xmm8, 0x00
0000747fd7fd620c  movaps xmm6, xmm10
0000747fd7fd6210  mulpd xmm6, xmm8
0000747fd7fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000747fd7fd621a  ptest xmm3, xmm3
0000747fd7fd621f  jnz 0x0000747FD7FD92C9
0000747fd7fd6225  vmovaps xmm8, [rsp+0x60]
0000747fd7fd622b  movaps xmm10, xmm8
0000747fd7fd622f  addpd xmm10, xmm14
0000747fd7fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000747fd7fd623a  ptest xmm3, xmm3
0000747fd7fd623f  jnz 0x0000747FD7FD940B
0000747fd7fd6245  vmovaps xmm8, [rsp+0x50]
0000747fd7fd624b  movaps xmm14, xmm8
0000747fd7fd624f  addpd xmm14, xmm4
0000747fd7fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000747fd7fd625a  ptest xmm3, xmm3
0000747fd7fd625f  jnz 0x0000747FD7FD954F
0000747fd7fd6265  vmovaps xmm8, [rsp+0x40]
0000747fd7fd626b  vpermilpd xmm8, xmm8, 0x00
0000747fd7fd6271  movaps xmm4, xmm13
0000747fd7fd6275  mulpd xmm4, xmm8
0000747fd7fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000747fd7fd627f  ptest xmm3, xmm3
0000747fd7fd6284  jnz 0x0000747FD7FD9692
0000747fd7fd628a  movaps xmm13, xmm15
0000747fd7fd628e  addpd xmm13, xmm9
0000747fd7fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000747fd7fd6299  ptest xmm8, xmm8
0000747fd7fd629f  jnz 0x0000747FD7FD97D4
0000747fd7fd62a5  movaps xmm15, xmm1
0000747fd7fd62a9  addpd xmm15, xmm5
0000747fd7fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000747fd7fd62b4  ptest xmm9, xmm9
0000747fd7fd62ba  jnz 0x0000747FD7FD9918
0000747fd7fd62c0  vmovaps [rsp+0x30], xmm11
0000747fd7fd62c6  vmovaps xmm1, [rsp+0x30]
0000747fd7fd62cc  por xmm11, xmm1
0000747fd7fd62d1  movaps [r15+0x250], xmm11
0000747fd7fd62d9  vmovaps [rsp+0x30], xmm12
0000747fd7fd62df  vmovaps xmm1, [rsp+0x30]
0000747fd7fd62e5  por xmm12, xmm1
0000747fd7fd62ea  movaps [r15+0x2A0], xmm12
0000747fd7fd62f2  vmovaps xmm1, [rsp+0xA0]
0000747fd7fd62fb  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd6304  por xmm1, xmm11
0000747fd7fd6309  movaps [r15+0x1D0], xmm1
0000747fd7fd6311  lea r14, [rax+0x40]
0000747fd7fd6315  movups xmm1, [r13+r14*1]
0000747fd7fd631b  movaps [r15+0x2C0], xmm1
0000747fd7fd6323  vmovaps xmm11, [rsp+0x40]
0000747fd7fd6329  vpermilpd xmm11, xmm11, 0x00
0000747fd7fd632f  vmovaps xmm8, [rsp+0xE0]
0000747fd7fd6338  movaps xmm9, xmm8
0000747fd7fd633c  mulpd xmm9, xmm11
0000747fd7fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000747fd7fd6347  ptest xmm5, xmm5
0000747fd7fd634c  jnz 0x0000747FD7FD9A64
0000747fd7fd6352  movaps xmm11, xmm10
0000747fd7fd6356  addpd xmm11, xmm6
0000747fd7fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000747fd7fd6361  ptest xmm8, xmm8
0000747fd7fd6367  jnz 0x0000747FD7FD9BA8
0000747fd7fd636d  movaps xmm10, xmm14
0000747fd7fd6371  addpd xmm10, xmm4
0000747fd7fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000747fd7fd637c  ptest xmm8, xmm8
0000747fd7fd6382  jnz 0x0000747FD7FD9CEB
0000747fd7fd6388  vmovaps xmm14, [rsp+0x40]
0000747fd7fd638e  vpermilpd xmm14, xmm14, 0x00
0000747fd7fd6394  movaps xmm8, xmm1
0000747fd7fd6398  mulpd xmm8, xmm14
0000747fd7fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000747fd7fd63a3  ptest xmm6, xmm6
0000747fd7fd63a8  jnz 0x0000747FD7FD9E2E
0000747fd7fd63ae  movaps xmm1, [r15+0x2B0]
0000747fd7fd63b6  vmovaps xmm14, [rsp+0x40]
0000747fd7fd63bc  vpermilpd xmm14, xmm14, 0x00
0000747fd7fd63c2  movaps xmm6, xmm1
0000747fd7fd63c5  mulpd xmm6, xmm14
0000747fd7fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000747fd7fd63cf  ptest xmm5, xmm5
0000747fd7fd63d4  jnz 0x0000747FD7FD9F71
0000747fd7fd63da  vmovaps xmm1, [rsp+0x10]
0000747fd7fd63e0  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd63e6  movaps xmm14, xmm12
0000747fd7fd63ea  mulpd xmm14, xmm1
0000747fd7fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000747fd7fd63f5  ptest xmm5, xmm5
0000747fd7fd63fa  jnz 0x0000747FD7FDA0B2
0000747fd7fd6400  movaps xmm1, xmm13
0000747fd7fd6404  addpd xmm1, xmm9
0000747fd7fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000747fd7fd640e  ptest xmm12, xmm12
0000747fd7fd6414  jnz 0x0000747FD7FDA1F5
0000747fd7fd641a  vmovaps xmm13, [rsp+0x10]
0000747fd7fd6420  vpermilpd xmm13, xmm13, 0x00
0000747fd7fd6426  movaps xmm12, xmm7
0000747fd7fd642a  mulpd xmm12, xmm13
0000747fd7fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000747fd7fd6435  ptest xmm9, xmm9
0000747fd7fd643b  jnz 0x0000747FD7FDA337
0000747fd7fd6441  movaps xmm13, xmm15
0000747fd7fd6445  addpd xmm13, xmm8
0000747fd7fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000747fd7fd6450  ptest xmm9, xmm9
0000747fd7fd6456  jnz 0x0000747FD7FDA47A
0000747fd7fd645c  movaps xmm15, [r15+0x290]
0000747fd7fd6464  vmovaps xmm9, [rsp+0x10]
0000747fd7fd646a  vpermilpd xmm9, xmm9, 0x00
0000747fd7fd6470  movaps xmm8, xmm15
0000747fd7fd6474  mulpd xmm8, xmm9
0000747fd7fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000747fd7fd647f  ptest xmm7, xmm7
0000747fd7fd6484  jnz 0x0000747FD7FDA5BE
0000747fd7fd648a  movaps xmm15, xmm11
0000747fd7fd648e  addpd xmm15, xmm6
0000747fd7fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000747fd7fd6499  ptest xmm9, xmm9
0000747fd7fd649f  jnz 0x0000747FD7FDA702
0000747fd7fd64a5  movaps xmm11, [r15+0x1E0]
0000747fd7fd64ad  vmovaps xmm9, [rsp+0x10]
0000747fd7fd64b3  vpermilpd xmm9, xmm9, 0x00
0000747fd7fd64b9  movaps xmm7, xmm11
0000747fd7fd64bd  mulpd xmm7, xmm9
0000747fd7fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000747fd7fd64c7  ptest xmm6, xmm6
0000747fd7fd64cc  jnz 0x0000747FD7FDA845
0000747fd7fd64d2  movaps xmm11, xmm10
0000747fd7fd64d6  addpd xmm11, xmm14
0000747fd7fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000747fd7fd64e1  ptest xmm9, xmm9
0000747fd7fd64e7  jnz 0x0000747FD7FDA987
0000747fd7fd64ed  lea r14, [rax+0x70]
0000747fd7fd64f1  movups xmm14, [r13+r14*1]
0000747fd7fd64f7  movaps [r15+0x240], xmm14
0000747fd7fd64ff  movaps xmm10, xmm1
0000747fd7fd6503  addpd xmm10, xmm12
0000747fd7fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000747fd7fd650e  ptest xmm9, xmm9
0000747fd7fd6514  jnz 0x0000747FD7FDAAD5
0000747fd7fd651a  movaps [r15+0x170], xmm10
0000747fd7fd6522  vmovaps xmm1, [rsp+0x20]
0000747fd7fd6528  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd652e  movaps xmm12, xmm14
0000747fd7fd6532  mulpd xmm12, xmm1
0000747fd7fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000747fd7fd653d  ptest xmm9, xmm9
0000747fd7fd6543  jnz 0x0000747FD7FDAC18
0000747fd7fd6549  vmovaps xmm1, [rsp+0x20]
0000747fd7fd654f  vpermilpd xmm1, xmm1, 0x00
0000747fd7fd6555  vmovaps xmm9, [rsp+0xB0]
0000747fd7fd655e  movaps xmm14, xmm9
0000747fd7fd6562  mulpd xmm14, xmm1
0000747fd7fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000747fd7fd656d  ptest xmm6, xmm6
0000747fd7fd6572  jnz 0x0000747FD7FDAD5B
0000747fd7fd6578  movaps [r15+0x180], xmm14
0000747fd7fd6580  movaps xmm1, xmm13
0000747fd7fd6584  addpd xmm1, xmm8
0000747fd7fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000747fd7fd658e  ptest xmm9, xmm9
0000747fd7fd6594  jnz 0x0000747FD7FDAE9E
0000747fd7fd659a  movaps [r15+0x210], xmm1
0000747fd7fd65a2  movups xmm13, [r13+rax*1]
0000747fd7fd65a8  lea r14, [rax+0x10]
0000747fd7fd65ac  movups xmm9, [r13+r14*1]
0000747fd7fd65b2  movaps [r15+0x230], xmm9
0000747fd7fd65ba  movaps xmm8, xmm15
0000747fd7fd65be  addpd xmm8, xmm7
0000747fd7fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000747fd7fd65c9  ptest xmm6, xmm6
0000747fd7fd65ce  jnz 0x0000747FD7FDAFF4
0000747fd7fd65d4  movaps [r15+0x130], xmm8
0000747fd7fd65dc  vmovaps xmm15, [rsp+0x20]
0000747fd7fd65e2  vpermilpd xmm15, xmm15, 0x00
0000747fd7fd65e8  movaps xmm7, xmm9
0000747fd7fd65ec  mulpd xmm7, xmm15
0000747fd7fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000747fd7fd65f6  ptest xmm6, xmm6
0000747fd7fd65fb  jnz 0x0000747FD7FDB137
0000747fd7fd6601  movaps [r15+0x220], xmm7
0000747fd7fd6609  vmovaps xmm15, [rsp+0x20]
0000747fd7fd660f  vpermilpd xmm15, xmm15, 0x00
0000747fd7fd6615  movaps xmm9, xmm13
0000747fd7fd6619  mulpd xmm9, xmm15
0000747fd7fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000747fd7fd6624  ptest xmm6, xmm6
0000747fd7fd6629  jnz 0x0000747FD7FDB279
0000747fd7fd662f  movaps xmm15, xmm11
0000747fd7fd6633  addpd xmm15, xmm12
0000747fd7fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000747fd7fd663e  ptest xmm13, xmm13
0000747fd7fd6644  jnz 0x0000747FD7FDB3BD
0000747fd7fd664a  movaps [r15+0x140], xmm15
0000747fd7fd6652  movaps xmm13, xmm10
0000747fd7fd6656  addpd xmm13, xmm14
0000747fd7fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000747fd7fd6661  ptest xmm12, xmm12
0000747fd7fd6667  jnz 0x0000747FD7FDB501
0000747fd7fd666d  movaps [r15+0x150], xmm13
0000747fd7fd6675  movaps xmm14, xmm1
0000747fd7fd6679  addpd xmm14, xmm7
0000747fd7fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000747fd7fd6684  ptest xmm12, xmm12
0000747fd7fd668a  jnz 0x0000747FD7FDB645
0000747fd7fd6690  movaps [r15+0x160], xmm14
0000747fd7fd6698  movaps xmm1, xmm8
0000747fd7fd669c  addpd xmm1, xmm9
0000747fd7fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000747fd7fd66a6  ptest xmm12, xmm12
0000747fd7fd66ac  jnz 0x0000747FD7FDB787
0000747fd7fd66b2  movaps [r15+0x120], xmm1
0000747fd7fd66ba  movups [r13+r11*1], xmm15
0000747fd7fd66c0  lea rax, [r11+0x10]
0000747fd7fd66c4  movups [r13+rax*1], xmm13
0000747fd7fd66ca  lea rax, [r11+0x20]
0000747fd7fd66ce  movups [r13+rax*1], xmm14
0000747fd7fd66d4  lea rax, [r11+0x30]
0000747fd7fd66d8  movups [r13+rax*1], xmm1
0000747fd7fd66de  mov eax, [r15+0x108]
0000747fd7fd66e5  sahf
0000747fd7fd66e6  jnz 0x0000747FD7FD6718
0000747fd7fd66e8  cmp dword ptr [r15+0x318], 0x00
0000747fd7fd66f0  jz 0x0000747FD7FDB900
0000747fd7fd66f6  nop [rax+rax*1], ax
0000747fd7fd66ff  nop [rax+rax*1], eax
0000747fd7fd6707  mov eax, 0x410444
0000747fd7fd670c  mov [r15+0x100], rax
0000747fd7fd6713  jmp 0x0000747FD7DFE110
0000747fd7fd6718  cmp dword ptr [r15+0x318], 0x00
0000747fd7fd6720  jz 0x0000747FD7FD57E0
0000747fd7fd6726  nop [rax+rax*1], ax
0000747fd7fd672f  nop [rax+rax*1], eax
0000747fd7fd6737  mov eax, 0x410278
0000747fd7fd673c  mov [r15+0x100], rax
0000747fd7fd6743  jmp 0x0000747FD7DFE110
0000747fd7fd6748  int3
0000747fd7fd6749  call 0x0000747FD7E0A4B0
0000747fd7fd674e  jmp 0x0000747FD7FD5828
0000747fd7fd6753  call 0x0000747FD7E09240
0000747fd7fd6758  jmp 0x0000747FD7FD5832
0000747fd7fd675d  call 0x0000747FD7E0A4B0
0000747fd7fd6762  jmp 0x0000747FD7FD588F
0000747fd7fd6767  call 0x0000747FD7E09240
0000747fd7fd676c  jmp 0x0000747FD7FD5899
0000747fd7fd6771  call 0x0000747FD7E0A4B0
0000747fd7fd6776  jmp 0x0000747FD7FD58DD
0000747fd7fd677b  call 0x0000747FD7E09240
0000747fd7fd6780  jmp 0x0000747FD7FD58E7
0000747fd7fd6785  call 0x0000747FD7EB47C0
0000747fd7fd678a  jmp 0x0000747FD7FD5926
0000747fd7fd678f  call 0x0000747FD7E0B720
0000747fd7fd6794  jmp 0x0000747FD7FD593A
0000747fd7fd6799  call 0x0000747FD7EBFC30
0000747fd7fd679e  jmp 0x0000747FD7FD5958
0000747fd7fd67a3  call 0x0000747FD7EBE9C0
0000747fd7fd67a8  jmp 0x0000747FD7FD5962
0000747fd7fd67ad  call 0x0000747FD7EBD750
0000747fd7fd67b2  jmp 0x0000747FD7FD596C
0000747fd7fd67b7  sub rsp, 0x08
0000747fd7fd67bb  push rax
0000747fd7fd67bc  push rcx
0000747fd7fd67bd  push rdx
0000747fd7fd67be  push rdi
0000747fd7fd67bf  push rsi
0000747fd7fd67c0  push r8
0000747fd7fd67c2  push r9
0000747fd7fd67c4  push r10
0000747fd7fd67c6  push r11
0000747fd7fd67c8  sub rsp, 0xF0
0000747fd7fd67cf  vmovaps [rsp], xmm0
0000747fd7fd67d4  vmovaps [rsp+0x10], xmm1
0000747fd7fd67da  vmovaps [rsp+0x20], xmm2
0000747fd7fd67e0  vmovaps [rsp+0x30], xmm3
0000747fd7fd67e6  vmovaps [rsp+0x40], xmm4
0000747fd7fd67ec  vmovaps [rsp+0x50], xmm5
0000747fd7fd67f2  vmovaps [rsp+0x60], xmm6
0000747fd7fd67f8  vmovaps [rsp+0x70], xmm7
0000747fd7fd67fe  vmovaps [rsp+0x80], xmm9
0000747fd7fd6807  vmovaps [rsp+0x90], xmm10
0000747fd7fd6810  vmovaps [rsp+0xA0], xmm11
0000747fd7fd6819  vmovaps [rsp+0xB0], xmm12
0000747fd7fd6822  vmovaps [rsp+0xC0], xmm13
0000747fd7fd682b  vmovaps [rsp+0xD0], xmm14
0000747fd7fd6834  vmovaps [rsp+0xE0], xmm15
0000747fd7fd683d  sub rsp, 0x30
0000747fd7fd6841  movaps [rsp], xmm8
0000747fd7fd6846  movaps [rsp+0x10], xmm12
0000747fd7fd684c  movaps [rsp+0x20], xmm15
0000747fd7fd6852  lea rdi, [rsp]
0000747fd7fd6856  mov esi, 0x00
0000747fd7fd685b  mov rax, 0x6055A0B6E530
0000747fd7fd6865  call rax
0000747fd7fd6867  movaps xmm8, [rsp]
0000747fd7fd686c  add rsp, 0x30
0000747fd7fd6870  vmovaps xmm0, [rsp]
0000747fd7fd6875  vmovaps xmm1, [rsp+0x10]
0000747fd7fd687b  vmovaps xmm2, [rsp+0x20]
0000747fd7fd6881  vmovaps xmm3, [rsp+0x30]
0000747fd7fd6887  vmovaps xmm4, [rsp+0x40]
0000747fd7fd688d  vmovaps xmm5, [rsp+0x50]
0000747fd7fd6893  vmovaps xmm6, [rsp+0x60]
0000747fd7fd6899  vmovaps xmm7, [rsp+0x70]
0000747fd7fd689f  vmovaps xmm9, [rsp+0x80]
0000747fd7fd68a8  vmovaps xmm10, [rsp+0x90]
0000747fd7fd68b1  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd68ba  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd68c3  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd68cc  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd68d5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd68de  add rsp, 0xF0
0000747fd7fd68e5  pop r11
0000747fd7fd68e7  pop r10
0000747fd7fd68e9  pop r9
0000747fd7fd68eb  pop r8
0000747fd7fd68ed  pop rsi
0000747fd7fd68ee  pop rdi
0000747fd7fd68ef  pop rdx
0000747fd7fd68f0  pop rcx
0000747fd7fd68f1  pop rax
0000747fd7fd68f2  add rsp, 0x08
0000747fd7fd68f6  jmp 0x0000747FD7FD599A
0000747fd7fd68fb  sub rsp, 0x08
0000747fd7fd68ff  push rax
0000747fd7fd6900  push rcx
0000747fd7fd6901  push rdx
0000747fd7fd6902  push rdi
0000747fd7fd6903  push rsi
0000747fd7fd6904  push r8
0000747fd7fd6906  push r9
0000747fd7fd6908  push r10
0000747fd7fd690a  push r11
0000747fd7fd690c  sub rsp, 0xF0
0000747fd7fd6913  vmovaps [rsp], xmm0
0000747fd7fd6918  vmovaps [rsp+0x10], xmm1
0000747fd7fd691e  vmovaps [rsp+0x20], xmm2
0000747fd7fd6924  vmovaps [rsp+0x30], xmm3
0000747fd7fd692a  vmovaps [rsp+0x40], xmm4
0000747fd7fd6930  vmovaps [rsp+0x50], xmm5
0000747fd7fd6936  vmovaps [rsp+0x60], xmm6
0000747fd7fd693c  vmovaps [rsp+0x70], xmm8
0000747fd7fd6942  vmovaps [rsp+0x80], xmm9
0000747fd7fd694b  vmovaps [rsp+0x90], xmm10
0000747fd7fd6954  vmovaps [rsp+0xA0], xmm11
0000747fd7fd695d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd6966  vmovaps [rsp+0xC0], xmm13
0000747fd7fd696f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd6978  vmovaps [rsp+0xE0], xmm15
0000747fd7fd6981  sub rsp, 0x30
0000747fd7fd6985  movaps [rsp], xmm7
0000747fd7fd6989  movaps [rsp+0x10], xmm9
0000747fd7fd698f  movaps [rsp+0x20], xmm15
0000747fd7fd6995  lea rdi, [rsp]
0000747fd7fd6999  mov esi, 0x00
0000747fd7fd699e  mov rax, 0x6055A0B6E530
0000747fd7fd69a8  call rax
0000747fd7fd69aa  movaps xmm7, [rsp]
0000747fd7fd69ae  add rsp, 0x30
0000747fd7fd69b2  vmovaps xmm0, [rsp]
0000747fd7fd69b7  vmovaps xmm1, [rsp+0x10]
0000747fd7fd69bd  vmovaps xmm2, [rsp+0x20]
0000747fd7fd69c3  vmovaps xmm3, [rsp+0x30]
0000747fd7fd69c9  vmovaps xmm4, [rsp+0x40]
0000747fd7fd69cf  vmovaps xmm5, [rsp+0x50]
0000747fd7fd69d5  vmovaps xmm6, [rsp+0x60]
0000747fd7fd69db  vmovaps xmm8, [rsp+0x70]
0000747fd7fd69e1  vmovaps xmm9, [rsp+0x80]
0000747fd7fd69ea  vmovaps xmm10, [rsp+0x90]
0000747fd7fd69f3  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd69fc  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd6a05  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd6a0e  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd6a17  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd6a20  add rsp, 0xF0
0000747fd7fd6a27  pop r11
0000747fd7fd6a29  pop r10
0000747fd7fd6a2b  pop r9
0000747fd7fd6a2d  pop r8
0000747fd7fd6a2f  pop rsi
0000747fd7fd6a30  pop rdi
0000747fd7fd6a31  pop rdx
0000747fd7fd6a32  pop rcx
0000747fd7fd6a33  pop rax
0000747fd7fd6a34  add rsp, 0x08
0000747fd7fd6a38  jmp 0x0000747FD7FD59C8
0000747fd7fd6a3d  sub rsp, 0x08
0000747fd7fd6a41  push rax
0000747fd7fd6a42  push rcx
0000747fd7fd6a43  push rdx
0000747fd7fd6a44  push rdi
0000747fd7fd6a45  push rsi
0000747fd7fd6a46  push r8
0000747fd7fd6a48  push r9
0000747fd7fd6a4a  push r10
0000747fd7fd6a4c  push r11
0000747fd7fd6a4e  sub rsp, 0xF0
0000747fd7fd6a55  vmovaps [rsp], xmm0
0000747fd7fd6a5a  vmovaps [rsp+0x10], xmm1
0000747fd7fd6a60  vmovaps [rsp+0x20], xmm2
0000747fd7fd6a66  vmovaps [rsp+0x30], xmm3
0000747fd7fd6a6c  vmovaps [rsp+0x40], xmm4
0000747fd7fd6a72  vmovaps [rsp+0x50], xmm5
0000747fd7fd6a78  vmovaps [rsp+0x60], xmm6
0000747fd7fd6a7e  vmovaps [rsp+0x70], xmm7
0000747fd7fd6a84  vmovaps [rsp+0x80], xmm8
0000747fd7fd6a8d  vmovaps [rsp+0x90], xmm10
0000747fd7fd6a96  vmovaps [rsp+0xA0], xmm11
0000747fd7fd6a9f  vmovaps [rsp+0xB0], xmm12
0000747fd7fd6aa8  vmovaps [rsp+0xC0], xmm13
0000747fd7fd6ab1  vmovaps [rsp+0xD0], xmm14
0000747fd7fd6aba  vmovaps [rsp+0xE0], xmm15
0000747fd7fd6ac3  sub rsp, 0x30
0000747fd7fd6ac7  movaps [rsp], xmm9
0000747fd7fd6acc  movaps [rsp+0x10], xmm12
0000747fd7fd6ad2  movaps [rsp+0x20], xmm10
0000747fd7fd6ad8  lea rdi, [rsp]
0000747fd7fd6adc  mov esi, 0x00
0000747fd7fd6ae1  mov rax, 0x6055A0B6E530
0000747fd7fd6aeb  call rax
0000747fd7fd6aed  movaps xmm9, [rsp]
0000747fd7fd6af2  add rsp, 0x30
0000747fd7fd6af6  vmovaps xmm0, [rsp]
0000747fd7fd6afb  vmovaps xmm1, [rsp+0x10]
0000747fd7fd6b01  vmovaps xmm2, [rsp+0x20]
0000747fd7fd6b07  vmovaps xmm3, [rsp+0x30]
0000747fd7fd6b0d  vmovaps xmm4, [rsp+0x40]
0000747fd7fd6b13  vmovaps xmm5, [rsp+0x50]
0000747fd7fd6b19  vmovaps xmm6, [rsp+0x60]
0000747fd7fd6b1f  vmovaps xmm7, [rsp+0x70]
0000747fd7fd6b25  vmovaps xmm8, [rsp+0x80]
0000747fd7fd6b2e  vmovaps xmm10, [rsp+0x90]
0000747fd7fd6b37  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd6b40  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd6b49  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd6b52  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd6b5b  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd6b64  add rsp, 0xF0
0000747fd7fd6b6b  pop r11
0000747fd7fd6b6d  pop r10
0000747fd7fd6b6f  pop r9
0000747fd7fd6b71  pop r8
0000747fd7fd6b73  pop rsi
0000747fd7fd6b74  pop rdi
0000747fd7fd6b75  pop rdx
0000747fd7fd6b76  pop rcx
0000747fd7fd6b77  pop rax
0000747fd7fd6b78  add rsp, 0x08
0000747fd7fd6b7c  jmp 0x0000747FD7FD59EC
0000747fd7fd6b81  sub rsp, 0x08
0000747fd7fd6b85  push rax
0000747fd7fd6b86  push rcx
0000747fd7fd6b87  push rdx
0000747fd7fd6b88  push rdi
0000747fd7fd6b89  push rsi
0000747fd7fd6b8a  push r8
0000747fd7fd6b8c  push r9
0000747fd7fd6b8e  push r10
0000747fd7fd6b90  push r11
0000747fd7fd6b92  sub rsp, 0xF0
0000747fd7fd6b99  vmovaps [rsp], xmm0
0000747fd7fd6b9e  vmovaps [rsp+0x10], xmm1
0000747fd7fd6ba4  vmovaps [rsp+0x20], xmm2
0000747fd7fd6baa  vmovaps [rsp+0x30], xmm3
0000747fd7fd6bb0  vmovaps [rsp+0x40], xmm4
0000747fd7fd6bb6  vmovaps [rsp+0x50], xmm5
0000747fd7fd6bbc  vmovaps [rsp+0x60], xmm6
0000747fd7fd6bc2  vmovaps [rsp+0x70], xmm7
0000747fd7fd6bc8  vmovaps [rsp+0x80], xmm8
0000747fd7fd6bd1  vmovaps [rsp+0x90], xmm9
0000747fd7fd6bda  vmovaps [rsp+0xA0], xmm11
0000747fd7fd6be3  vmovaps [rsp+0xB0], xmm12
0000747fd7fd6bec  vmovaps [rsp+0xC0], xmm13
0000747fd7fd6bf5  vmovaps [rsp+0xD0], xmm14
0000747fd7fd6bfe  vmovaps [rsp+0xE0], xmm15
0000747fd7fd6c07  sub rsp, 0x30
0000747fd7fd6c0b  movaps [rsp], xmm10
0000747fd7fd6c10  movaps [rsp+0x10], xmm12
0000747fd7fd6c16  movaps [rsp+0x20], xmm11
0000747fd7fd6c1c  lea rdi, [rsp]
0000747fd7fd6c20  mov esi, 0x00
0000747fd7fd6c25  mov rax, 0x6055A0B6E530
0000747fd7fd6c2f  call rax
0000747fd7fd6c31  movaps xmm10, [rsp]
0000747fd7fd6c36  add rsp, 0x30
0000747fd7fd6c3a  vmovaps xmm0, [rsp]
0000747fd7fd6c3f  vmovaps xmm1, [rsp+0x10]
0000747fd7fd6c45  vmovaps xmm2, [rsp+0x20]
0000747fd7fd6c4b  vmovaps xmm3, [rsp+0x30]
0000747fd7fd6c51  vmovaps xmm4, [rsp+0x40]
0000747fd7fd6c57  vmovaps xmm5, [rsp+0x50]
0000747fd7fd6c5d  vmovaps xmm6, [rsp+0x60]
0000747fd7fd6c63  vmovaps xmm7, [rsp+0x70]
0000747fd7fd6c69  vmovaps xmm8, [rsp+0x80]
0000747fd7fd6c72  vmovaps xmm9, [rsp+0x90]
0000747fd7fd6c7b  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd6c84  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd6c8d  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd6c96  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd6c9f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd6ca8  add rsp, 0xF0
0000747fd7fd6caf  pop r11
0000747fd7fd6cb1  pop r10
0000747fd7fd6cb3  pop r9
0000747fd7fd6cb5  pop r8
0000747fd7fd6cb7  pop rsi
0000747fd7fd6cb8  pop rdi
0000747fd7fd6cb9  pop rdx
0000747fd7fd6cba  pop rcx
0000747fd7fd6cbb  pop rax
0000747fd7fd6cbc  add rsp, 0x08
0000747fd7fd6cc0  jmp 0x0000747FD7FD5A06
0000747fd7fd6cc5  sub rsp, 0x08
0000747fd7fd6cc9  push rax
0000747fd7fd6cca  push rcx
0000747fd7fd6ccb  push rdx
0000747fd7fd6ccc  push rdi
0000747fd7fd6ccd  push rsi
0000747fd7fd6cce  push r8
0000747fd7fd6cd0  push r9
0000747fd7fd6cd2  push r10
0000747fd7fd6cd4  push r11
0000747fd7fd6cd6  sub rsp, 0xF0
0000747fd7fd6cdd  vmovaps [rsp], xmm0
0000747fd7fd6ce2  vmovaps [rsp+0x10], xmm1
0000747fd7fd6ce8  vmovaps [rsp+0x20], xmm2
0000747fd7fd6cee  vmovaps [rsp+0x30], xmm3
0000747fd7fd6cf4  vmovaps [rsp+0x40], xmm4
0000747fd7fd6cfa  vmovaps [rsp+0x50], xmm5
0000747fd7fd6d00  vmovaps [rsp+0x60], xmm7
0000747fd7fd6d06  vmovaps [rsp+0x70], xmm8
0000747fd7fd6d0c  vmovaps [rsp+0x80], xmm9
0000747fd7fd6d15  vmovaps [rsp+0x90], xmm10
0000747fd7fd6d1e  vmovaps [rsp+0xA0], xmm11
0000747fd7fd6d27  vmovaps [rsp+0xB0], xmm12
0000747fd7fd6d30  vmovaps [rsp+0xC0], xmm13
0000747fd7fd6d39  vmovaps [rsp+0xD0], xmm14
0000747fd7fd6d42  vmovaps [rsp+0xE0], xmm15
0000747fd7fd6d4b  sub rsp, 0x30
0000747fd7fd6d4f  movaps [rsp], xmm6
0000747fd7fd6d53  movaps [rsp+0x10], xmm12
0000747fd7fd6d59  movaps [rsp+0x20], xmm11
0000747fd7fd6d5f  lea rdi, [rsp]
0000747fd7fd6d63  mov esi, 0x00
0000747fd7fd6d68  mov rax, 0x6055A0B6E530
0000747fd7fd6d72  call rax
0000747fd7fd6d74  movaps xmm6, [rsp]
0000747fd7fd6d78  add rsp, 0x30
0000747fd7fd6d7c  vmovaps xmm0, [rsp]
0000747fd7fd6d81  vmovaps xmm1, [rsp+0x10]
0000747fd7fd6d87  vmovaps xmm2, [rsp+0x20]
0000747fd7fd6d8d  vmovaps xmm3, [rsp+0x30]
0000747fd7fd6d93  vmovaps xmm4, [rsp+0x40]
0000747fd7fd6d99  vmovaps xmm5, [rsp+0x50]
0000747fd7fd6d9f  vmovaps xmm7, [rsp+0x60]
0000747fd7fd6da5  vmovaps xmm8, [rsp+0x70]
0000747fd7fd6dab  vmovaps xmm9, [rsp+0x80]
0000747fd7fd6db4  vmovaps xmm10, [rsp+0x90]
0000747fd7fd6dbd  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd6dc6  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd6dcf  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd6dd8  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd6de1  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd6dea  add rsp, 0xF0
0000747fd7fd6df1  pop r11
0000747fd7fd6df3  pop r10
0000747fd7fd6df5  pop r9
0000747fd7fd6df7  pop r8
0000747fd7fd6df9  pop rsi
0000747fd7fd6dfa  pop rdi
0000747fd7fd6dfb  pop rdx
0000747fd7fd6dfc  pop rcx
0000747fd7fd6dfd  pop rax
0000747fd7fd6dfe  add rsp, 0x08
0000747fd7fd6e02  jmp 0x0000747FD7FD5A27
0000747fd7fd6e07  sub rsp, 0x08
0000747fd7fd6e0b  push rax
0000747fd7fd6e0c  push rcx
0000747fd7fd6e0d  push rdx
0000747fd7fd6e0e  push rdi
0000747fd7fd6e0f  push rsi
0000747fd7fd6e10  push r8
0000747fd7fd6e12  push r9
0000747fd7fd6e14  push r10
0000747fd7fd6e16  push r11
0000747fd7fd6e18  sub rsp, 0xF0
0000747fd7fd6e1f  vmovaps [rsp], xmm0
0000747fd7fd6e24  vmovaps [rsp+0x10], xmm1
0000747fd7fd6e2a  vmovaps [rsp+0x20], xmm2
0000747fd7fd6e30  vmovaps [rsp+0x30], xmm4
0000747fd7fd6e36  vmovaps [rsp+0x40], xmm5
0000747fd7fd6e3c  vmovaps [rsp+0x50], xmm6
0000747fd7fd6e42  vmovaps [rsp+0x60], xmm7
0000747fd7fd6e48  vmovaps [rsp+0x70], xmm8
0000747fd7fd6e4e  vmovaps [rsp+0x80], xmm9
0000747fd7fd6e57  vmovaps [rsp+0x90], xmm10
0000747fd7fd6e60  vmovaps [rsp+0xA0], xmm11
0000747fd7fd6e69  vmovaps [rsp+0xB0], xmm12
0000747fd7fd6e72  vmovaps [rsp+0xC0], xmm13
0000747fd7fd6e7b  vmovaps [rsp+0xD0], xmm14
0000747fd7fd6e84  vmovaps [rsp+0xE0], xmm15
0000747fd7fd6e8d  sub rsp, 0x30
0000747fd7fd6e91  movaps [rsp], xmm3
0000747fd7fd6e95  movaps [rsp+0x10], xmm5
0000747fd7fd6e9a  movaps [rsp+0x20], xmm4
0000747fd7fd6e9f  lea rdi, [rsp]
0000747fd7fd6ea3  mov esi, 0x00
0000747fd7fd6ea8  mov rax, 0x6055A0B6E530
0000747fd7fd6eb2  call rax
0000747fd7fd6eb4  movaps xmm3, [rsp]
0000747fd7fd6eb8  add rsp, 0x30
0000747fd7fd6ebc  vmovaps xmm0, [rsp]
0000747fd7fd6ec1  vmovaps xmm1, [rsp+0x10]
0000747fd7fd6ec7  vmovaps xmm2, [rsp+0x20]
0000747fd7fd6ecd  vmovaps xmm4, [rsp+0x30]
0000747fd7fd6ed3  vmovaps xmm5, [rsp+0x40]
0000747fd7fd6ed9  vmovaps xmm6, [rsp+0x50]
0000747fd7fd6edf  vmovaps xmm7, [rsp+0x60]
0000747fd7fd6ee5  vmovaps xmm8, [rsp+0x70]
0000747fd7fd6eeb  vmovaps xmm9, [rsp+0x80]
0000747fd7fd6ef4  vmovaps xmm10, [rsp+0x90]
0000747fd7fd6efd  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd6f06  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd6f0f  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd6f18  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd6f21  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd6f2a  add rsp, 0xF0
0000747fd7fd6f31  pop r11
0000747fd7fd6f33  pop r10
0000747fd7fd6f35  pop r9
0000747fd7fd6f37  pop r8
0000747fd7fd6f39  pop rsi
0000747fd7fd6f3a  pop rdi
0000747fd7fd6f3b  pop rdx
0000747fd7fd6f3c  pop rcx
0000747fd7fd6f3d  pop rax
0000747fd7fd6f3e  add rsp, 0x08
0000747fd7fd6f42  jmp 0x0000747FD7FD5A88
0000747fd7fd6f47  sub rsp, 0x08
0000747fd7fd6f4b  push rax
0000747fd7fd6f4c  push rcx
0000747fd7fd6f4d  push rdx
0000747fd7fd6f4e  push rdi
0000747fd7fd6f4f  push rsi
0000747fd7fd6f50  push r8
0000747fd7fd6f52  push r9
0000747fd7fd6f54  push r10
0000747fd7fd6f56  push r11
0000747fd7fd6f58  sub rsp, 0xF0
0000747fd7fd6f5f  vmovaps [rsp], xmm0
0000747fd7fd6f64  vmovaps [rsp+0x10], xmm1
0000747fd7fd6f6a  vmovaps [rsp+0x20], xmm2
0000747fd7fd6f70  vmovaps [rsp+0x30], xmm3
0000747fd7fd6f76  vmovaps [rsp+0x40], xmm4
0000747fd7fd6f7c  vmovaps [rsp+0x50], xmm6
0000747fd7fd6f82  vmovaps [rsp+0x60], xmm7
0000747fd7fd6f88  vmovaps [rsp+0x70], xmm8
0000747fd7fd6f8e  vmovaps [rsp+0x80], xmm9
0000747fd7fd6f97  vmovaps [rsp+0x90], xmm10
0000747fd7fd6fa0  vmovaps [rsp+0xA0], xmm11
0000747fd7fd6fa9  vmovaps [rsp+0xB0], xmm12
0000747fd7fd6fb2  vmovaps [rsp+0xC0], xmm13
0000747fd7fd6fbb  vmovaps [rsp+0xD0], xmm14
0000747fd7fd6fc4  vmovaps [rsp+0xE0], xmm15
0000747fd7fd6fcd  sub rsp, 0x30
0000747fd7fd6fd1  movaps [rsp], xmm5
0000747fd7fd6fd5  movaps [rsp+0x10], xmm8
0000747fd7fd6fdb  movaps [rsp+0x20], xmm15
0000747fd7fd6fe1  lea rdi, [rsp]
0000747fd7fd6fe5  mov esi, 0x00
0000747fd7fd6fea  mov rax, 0x6055A0B6E530
0000747fd7fd6ff4  call rax
0000747fd7fd6ff6  movaps xmm5, [rsp]
0000747fd7fd6ffa  add rsp, 0x30
0000747fd7fd6ffe  vmovaps xmm0, [rsp]
0000747fd7fd7003  vmovaps xmm1, [rsp+0x10]
0000747fd7fd7009  vmovaps xmm2, [rsp+0x20]
0000747fd7fd700f  vmovaps xmm3, [rsp+0x30]
0000747fd7fd7015  vmovaps xmm4, [rsp+0x40]
0000747fd7fd701b  vmovaps xmm6, [rsp+0x50]
0000747fd7fd7021  vmovaps xmm7, [rsp+0x60]
0000747fd7fd7027  vmovaps xmm8, [rsp+0x70]
0000747fd7fd702d  vmovaps xmm9, [rsp+0x80]
0000747fd7fd7036  vmovaps xmm10, [rsp+0x90]
0000747fd7fd703f  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd7048  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd7051  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd705a  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd7063  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd706c  add rsp, 0xF0
0000747fd7fd7073  pop r11
0000747fd7fd7075  pop r10
0000747fd7fd7077  pop r9
0000747fd7fd7079  pop r8
0000747fd7fd707b  pop rsi
0000747fd7fd707c  pop rdi
0000747fd7fd707d  pop rdx
0000747fd7fd707e  pop rcx
0000747fd7fd707f  pop rax
0000747fd7fd7080  add rsp, 0x08
0000747fd7fd7084  jmp 0x0000747FD7FD5AC0
0000747fd7fd7089  sub rsp, 0x08
0000747fd7fd708d  push rax
0000747fd7fd708e  push rcx
0000747fd7fd708f  push rdx
0000747fd7fd7090  push rdi
0000747fd7fd7091  push rsi
0000747fd7fd7092  push r8
0000747fd7fd7094  push r9
0000747fd7fd7096  push r10
0000747fd7fd7098  push r11
0000747fd7fd709a  sub rsp, 0xF0
0000747fd7fd70a1  vmovaps [rsp], xmm0
0000747fd7fd70a6  vmovaps [rsp+0x10], xmm1
0000747fd7fd70ac  vmovaps [rsp+0x20], xmm2
0000747fd7fd70b2  vmovaps [rsp+0x30], xmm3
0000747fd7fd70b8  vmovaps [rsp+0x40], xmm5
0000747fd7fd70be  vmovaps [rsp+0x50], xmm6
0000747fd7fd70c4  vmovaps [rsp+0x60], xmm7
0000747fd7fd70ca  vmovaps [rsp+0x70], xmm8
0000747fd7fd70d0  vmovaps [rsp+0x80], xmm9
0000747fd7fd70d9  vmovaps [rsp+0x90], xmm10
0000747fd7fd70e2  vmovaps [rsp+0xA0], xmm11
0000747fd7fd70eb  vmovaps [rsp+0xB0], xmm12
0000747fd7fd70f4  vmovaps [rsp+0xC0], xmm13
0000747fd7fd70fd  vmovaps [rsp+0xD0], xmm14
0000747fd7fd7106  vmovaps [rsp+0xE0], xmm15
0000747fd7fd710f  sub rsp, 0x30
0000747fd7fd7113  movaps [rsp], xmm4
0000747fd7fd7117  movaps [rsp+0x10], xmm9
0000747fd7fd711d  movaps [rsp+0x20], xmm8
0000747fd7fd7123  lea rdi, [rsp]
0000747fd7fd7127  mov esi, 0x00
0000747fd7fd712c  mov rax, 0x6055A0B6E530
0000747fd7fd7136  call rax
0000747fd7fd7138  movaps xmm4, [rsp]
0000747fd7fd713c  add rsp, 0x30
0000747fd7fd7140  vmovaps xmm0, [rsp]
0000747fd7fd7145  vmovaps xmm1, [rsp+0x10]
0000747fd7fd714b  vmovaps xmm2, [rsp+0x20]
0000747fd7fd7151  vmovaps xmm3, [rsp+0x30]
0000747fd7fd7157  vmovaps xmm5, [rsp+0x40]
0000747fd7fd715d  vmovaps xmm6, [rsp+0x50]
0000747fd7fd7163  vmovaps xmm7, [rsp+0x60]
0000747fd7fd7169  vmovaps xmm8, [rsp+0x70]
0000747fd7fd716f  vmovaps xmm9, [rsp+0x80]
0000747fd7fd7178  vmovaps xmm10, [rsp+0x90]
0000747fd7fd7181  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd718a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd7193  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd719c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd71a5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd71ae  add rsp, 0xF0
0000747fd7fd71b5  pop r11
0000747fd7fd71b7  pop r10
0000747fd7fd71b9  pop r9
0000747fd7fd71bb  pop r8
0000747fd7fd71bd  pop rsi
0000747fd7fd71be  pop rdi
0000747fd7fd71bf  pop rdx
0000747fd7fd71c0  pop rcx
0000747fd7fd71c1  pop rax
0000747fd7fd71c2  add rsp, 0x08
0000747fd7fd71c6  jmp 0x0000747FD7FD5AE1
0000747fd7fd71cb  sub rsp, 0x08
0000747fd7fd71cf  push rax
0000747fd7fd71d0  push rcx
0000747fd7fd71d1  push rdx
0000747fd7fd71d2  push rdi
0000747fd7fd71d3  push rsi
0000747fd7fd71d4  push r8
0000747fd7fd71d6  push r9
0000747fd7fd71d8  push r10
0000747fd7fd71da  push r11
0000747fd7fd71dc  sub rsp, 0xF0
0000747fd7fd71e3  vmovaps [rsp], xmm0
0000747fd7fd71e8  vmovaps [rsp+0x10], xmm1
0000747fd7fd71ee  vmovaps [rsp+0x20], xmm2
0000747fd7fd71f4  vmovaps [rsp+0x30], xmm3
0000747fd7fd71fa  vmovaps [rsp+0x40], xmm4
0000747fd7fd7200  vmovaps [rsp+0x50], xmm5
0000747fd7fd7206  vmovaps [rsp+0x60], xmm6
0000747fd7fd720c  vmovaps [rsp+0x70], xmm7
0000747fd7fd7212  vmovaps [rsp+0x80], xmm8
0000747fd7fd721b  vmovaps [rsp+0x90], xmm10
0000747fd7fd7224  vmovaps [rsp+0xA0], xmm11
0000747fd7fd722d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd7236  vmovaps [rsp+0xC0], xmm13
0000747fd7fd723f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd7248  vmovaps [rsp+0xE0], xmm15
0000747fd7fd7251  sub rsp, 0x30
0000747fd7fd7255  movaps [rsp], xmm9
0000747fd7fd725a  movaps [rsp+0x10], xmm10
0000747fd7fd7260  movaps [rsp+0x20], xmm8
0000747fd7fd7266  lea rdi, [rsp]
0000747fd7fd726a  mov esi, 0x00
0000747fd7fd726f  mov rax, 0x6055A0B6E530
0000747fd7fd7279  call rax
0000747fd7fd727b  movaps xmm9, [rsp]
0000747fd7fd7280  add rsp, 0x30
0000747fd7fd7284  vmovaps xmm0, [rsp]
0000747fd7fd7289  vmovaps xmm1, [rsp+0x10]
0000747fd7fd728f  vmovaps xmm2, [rsp+0x20]
0000747fd7fd7295  vmovaps xmm3, [rsp+0x30]
0000747fd7fd729b  vmovaps xmm4, [rsp+0x40]
0000747fd7fd72a1  vmovaps xmm5, [rsp+0x50]
0000747fd7fd72a7  vmovaps xmm6, [rsp+0x60]
0000747fd7fd72ad  vmovaps xmm7, [rsp+0x70]
0000747fd7fd72b3  vmovaps xmm8, [rsp+0x80]
0000747fd7fd72bc  vmovaps xmm10, [rsp+0x90]
0000747fd7fd72c5  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd72ce  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd72d7  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd72e0  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd72e9  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd72f2  add rsp, 0xF0
0000747fd7fd72f9  pop r11
0000747fd7fd72fb  pop r10
0000747fd7fd72fd  pop r9
0000747fd7fd72ff  pop r8
0000747fd7fd7301  pop rsi
0000747fd7fd7302  pop rdi
0000747fd7fd7303  pop rdx
0000747fd7fd7304  pop rcx
0000747fd7fd7305  pop rax
0000747fd7fd7306  add rsp, 0x08
0000747fd7fd730a  jmp 0x0000747FD7FD5AFB
0000747fd7fd730f  call 0x0000747FD7ED64F0
0000747fd7fd7314  jmp 0x0000747FD7FD5C15
0000747fd7fd7319  call 0x0000747FD7ED64F0
0000747fd7fd731e  jmp 0x0000747FD7FD5C2B
0000747fd7fd7323  sub rsp, 0x08
0000747fd7fd7327  push rax
0000747fd7fd7328  push rcx
0000747fd7fd7329  push rdx
0000747fd7fd732a  push rdi
0000747fd7fd732b  push rsi
0000747fd7fd732c  push r8
0000747fd7fd732e  push r9
0000747fd7fd7330  push r10
0000747fd7fd7332  push r11
0000747fd7fd7334  sub rsp, 0xF0
0000747fd7fd733b  vmovaps [rsp], xmm0
0000747fd7fd7340  vmovaps [rsp+0x10], xmm2
0000747fd7fd7346  vmovaps [rsp+0x20], xmm3
0000747fd7fd734c  vmovaps [rsp+0x30], xmm4
0000747fd7fd7352  vmovaps [rsp+0x40], xmm5
0000747fd7fd7358  vmovaps [rsp+0x50], xmm6
0000747fd7fd735e  vmovaps [rsp+0x60], xmm7
0000747fd7fd7364  vmovaps [rsp+0x70], xmm8
0000747fd7fd736a  vmovaps [rsp+0x80], xmm9
0000747fd7fd7373  vmovaps [rsp+0x90], xmm10
0000747fd7fd737c  vmovaps [rsp+0xA0], xmm11
0000747fd7fd7385  vmovaps [rsp+0xB0], xmm12
0000747fd7fd738e  vmovaps [rsp+0xC0], xmm13
0000747fd7fd7397  vmovaps [rsp+0xD0], xmm14
0000747fd7fd73a0  vmovaps [rsp+0xE0], xmm15
0000747fd7fd73a9  sub rsp, 0x30
0000747fd7fd73ad  movaps [rsp], xmm1
0000747fd7fd73b1  movaps [rsp+0x10], xmm6
0000747fd7fd73b6  movaps [rsp+0x20], xmm15
0000747fd7fd73bc  lea rdi, [rsp]
0000747fd7fd73c0  mov esi, 0x00
0000747fd7fd73c5  mov rax, 0x6055A0B6E530
0000747fd7fd73cf  call rax
0000747fd7fd73d1  movaps xmm1, [rsp]
0000747fd7fd73d5  add rsp, 0x30
0000747fd7fd73d9  vmovaps xmm0, [rsp]
0000747fd7fd73de  vmovaps xmm2, [rsp+0x10]
0000747fd7fd73e4  vmovaps xmm3, [rsp+0x20]
0000747fd7fd73ea  vmovaps xmm4, [rsp+0x30]
0000747fd7fd73f0  vmovaps xmm5, [rsp+0x40]
0000747fd7fd73f6  vmovaps xmm6, [rsp+0x50]
0000747fd7fd73fc  vmovaps xmm7, [rsp+0x60]
0000747fd7fd7402  vmovaps xmm8, [rsp+0x70]
0000747fd7fd7408  vmovaps xmm9, [rsp+0x80]
0000747fd7fd7411  vmovaps xmm10, [rsp+0x90]
0000747fd7fd741a  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd7423  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd742c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd7435  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd743e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd7447  add rsp, 0xF0
0000747fd7fd744e  pop r11
0000747fd7fd7450  pop r10
0000747fd7fd7452  pop r9
0000747fd7fd7454  pop r8
0000747fd7fd7456  pop rsi
0000747fd7fd7457  pop rdi
0000747fd7fd7458  pop rdx
0000747fd7fd7459  pop rcx
0000747fd7fd745a  pop rax
0000747fd7fd745b  add rsp, 0x08
0000747fd7fd745f  jmp 0x0000747FD7FD5C68
0000747fd7fd7464  call 0x0000747FD7EE5820
0000747fd7fd7469  jmp 0x0000747FD7FD5C75
0000747fd7fd746e  sub rsp, 0x08
0000747fd7fd7472  push rax
0000747fd7fd7473  push rcx
0000747fd7fd7474  push rdx
0000747fd7fd7475  push rdi
0000747fd7fd7476  push rsi
0000747fd7fd7477  push r8
0000747fd7fd7479  push r9
0000747fd7fd747b  push r10
0000747fd7fd747d  push r11
0000747fd7fd747f  sub rsp, 0xF0
0000747fd7fd7486  vmovaps [rsp], xmm0
0000747fd7fd748b  vmovaps [rsp+0x10], xmm1
0000747fd7fd7491  vmovaps [rsp+0x20], xmm2
0000747fd7fd7497  vmovaps [rsp+0x30], xmm3
0000747fd7fd749d  vmovaps [rsp+0x40], xmm4
0000747fd7fd74a3  vmovaps [rsp+0x50], xmm5
0000747fd7fd74a9  vmovaps [rsp+0x60], xmm6
0000747fd7fd74af  vmovaps [rsp+0x70], xmm7
0000747fd7fd74b5  vmovaps [rsp+0x80], xmm8
0000747fd7fd74be  vmovaps [rsp+0x90], xmm9
0000747fd7fd74c7  vmovaps [rsp+0xA0], xmm10
0000747fd7fd74d0  vmovaps [rsp+0xB0], xmm11
0000747fd7fd74d9  vmovaps [rsp+0xC0], xmm12
0000747fd7fd74e2  vmovaps [rsp+0xD0], xmm13
0000747fd7fd74eb  vmovaps [rsp+0xE0], xmm15
0000747fd7fd74f4  sub rsp, 0x30
0000747fd7fd74f8  movaps [rsp], xmm14
0000747fd7fd74fd  movaps [rsp+0x10], xmm4
0000747fd7fd7502  movaps [rsp+0x20], xmm3
0000747fd7fd7507  lea rdi, [rsp]
0000747fd7fd750b  mov esi, 0x00
0000747fd7fd7510  mov rax, 0x6055A0B6E530
0000747fd7fd751a  call rax
0000747fd7fd751c  movaps xmm14, [rsp]
0000747fd7fd7521  add rsp, 0x30
0000747fd7fd7525  vmovaps xmm0, [rsp]
0000747fd7fd752a  vmovaps xmm1, [rsp+0x10]
0000747fd7fd7530  vmovaps xmm2, [rsp+0x20]
0000747fd7fd7536  vmovaps xmm3, [rsp+0x30]
0000747fd7fd753c  vmovaps xmm4, [rsp+0x40]
0000747fd7fd7542  vmovaps xmm5, [rsp+0x50]
0000747fd7fd7548  vmovaps xmm6, [rsp+0x60]
0000747fd7fd754e  vmovaps xmm7, [rsp+0x70]
0000747fd7fd7554  vmovaps xmm8, [rsp+0x80]
0000747fd7fd755d  vmovaps xmm9, [rsp+0x90]
0000747fd7fd7566  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd756f  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd7578  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd7581  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd758a  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd7593  add rsp, 0xF0
0000747fd7fd759a  pop r11
0000747fd7fd759c  pop r10
0000747fd7fd759e  pop r9
0000747fd7fd75a0  pop r8
0000747fd7fd75a2  pop rsi
0000747fd7fd75a3  pop rdi
0000747fd7fd75a4  pop rdx
0000747fd7fd75a5  pop rcx
0000747fd7fd75a6  pop rax
0000747fd7fd75a7  add rsp, 0x08
0000747fd7fd75ab  jmp 0x0000747FD7FD5C8F
0000747fd7fd75b0  sub rsp, 0x08
0000747fd7fd75b4  push rax
0000747fd7fd75b5  push rcx
0000747fd7fd75b6  push rdx
0000747fd7fd75b7  push rdi
0000747fd7fd75b8  push rsi
0000747fd7fd75b9  push r8
0000747fd7fd75bb  push r9
0000747fd7fd75bd  push r10
0000747fd7fd75bf  push r11
0000747fd7fd75c1  sub rsp, 0xF0
0000747fd7fd75c8  vmovaps [rsp], xmm0
0000747fd7fd75cd  vmovaps [rsp+0x10], xmm1
0000747fd7fd75d3  vmovaps [rsp+0x20], xmm2
0000747fd7fd75d9  vmovaps [rsp+0x30], xmm3
0000747fd7fd75df  vmovaps [rsp+0x40], xmm4
0000747fd7fd75e5  vmovaps [rsp+0x50], xmm5
0000747fd7fd75eb  vmovaps [rsp+0x60], xmm7
0000747fd7fd75f1  vmovaps [rsp+0x70], xmm8
0000747fd7fd75f7  vmovaps [rsp+0x80], xmm9
0000747fd7fd7600  vmovaps [rsp+0x90], xmm10
0000747fd7fd7609  vmovaps [rsp+0xA0], xmm11
0000747fd7fd7612  vmovaps [rsp+0xB0], xmm12
0000747fd7fd761b  vmovaps [rsp+0xC0], xmm13
0000747fd7fd7624  vmovaps [rsp+0xD0], xmm14
0000747fd7fd762d  vmovaps [rsp+0xE0], xmm15
0000747fd7fd7636  sub rsp, 0x30
0000747fd7fd763a  movaps [rsp], xmm6
0000747fd7fd763e  movaps [rsp+0x10], xmm9
0000747fd7fd7644  movaps [rsp+0x20], xmm7
0000747fd7fd7649  lea rdi, [rsp]
0000747fd7fd764d  mov esi, 0x00
0000747fd7fd7652  mov rax, 0x6055A0B6E530
0000747fd7fd765c  call rax
0000747fd7fd765e  movaps xmm6, [rsp]
0000747fd7fd7662  add rsp, 0x30
0000747fd7fd7666  vmovaps xmm0, [rsp]
0000747fd7fd766b  vmovaps xmm1, [rsp+0x10]
0000747fd7fd7671  vmovaps xmm2, [rsp+0x20]
0000747fd7fd7677  vmovaps xmm3, [rsp+0x30]
0000747fd7fd767d  vmovaps xmm4, [rsp+0x40]
0000747fd7fd7683  vmovaps xmm5, [rsp+0x50]
0000747fd7fd7689  vmovaps xmm7, [rsp+0x60]
0000747fd7fd768f  vmovaps xmm8, [rsp+0x70]
0000747fd7fd7695  vmovaps xmm9, [rsp+0x80]
0000747fd7fd769e  vmovaps xmm10, [rsp+0x90]
0000747fd7fd76a7  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd76b0  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd76b9  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd76c2  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd76cb  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd76d4  add rsp, 0xF0
0000747fd7fd76db  pop r11
0000747fd7fd76dd  pop r10
0000747fd7fd76df  pop r9
0000747fd7fd76e1  pop r8
0000747fd7fd76e3  pop rsi
0000747fd7fd76e4  pop rdi
0000747fd7fd76e5  pop rdx
0000747fd7fd76e6  pop rcx
0000747fd7fd76e7  pop rax
0000747fd7fd76e8  add rsp, 0x08
0000747fd7fd76ec  jmp 0x0000747FD7FD5CA7
0000747fd7fd76f1  sub rsp, 0x08
0000747fd7fd76f5  push rax
0000747fd7fd76f6  push rcx
0000747fd7fd76f7  push rdx
0000747fd7fd76f8  push rdi
0000747fd7fd76f9  push rsi
0000747fd7fd76fa  push r8
0000747fd7fd76fc  push r9
0000747fd7fd76fe  push r10
0000747fd7fd7700  push r11
0000747fd7fd7702  sub rsp, 0xF0
0000747fd7fd7709  vmovaps [rsp], xmm0
0000747fd7fd770e  vmovaps [rsp+0x10], xmm1
0000747fd7fd7714  vmovaps [rsp+0x20], xmm2
0000747fd7fd771a  vmovaps [rsp+0x30], xmm3
0000747fd7fd7720  vmovaps [rsp+0x40], xmm4
0000747fd7fd7726  vmovaps [rsp+0x50], xmm5
0000747fd7fd772c  vmovaps [rsp+0x60], xmm6
0000747fd7fd7732  vmovaps [rsp+0x70], xmm8
0000747fd7fd7738  vmovaps [rsp+0x80], xmm9
0000747fd7fd7741  vmovaps [rsp+0x90], xmm10
0000747fd7fd774a  vmovaps [rsp+0xA0], xmm11
0000747fd7fd7753  vmovaps [rsp+0xB0], xmm12
0000747fd7fd775c  vmovaps [rsp+0xC0], xmm13
0000747fd7fd7765  vmovaps [rsp+0xD0], xmm14
0000747fd7fd776e  vmovaps [rsp+0xE0], xmm15
0000747fd7fd7777  sub rsp, 0x30
0000747fd7fd777b  movaps [rsp], xmm7
0000747fd7fd777f  movaps [rsp+0x10], xmm4
0000747fd7fd7784  movaps [rsp+0x20], xmm9
0000747fd7fd778a  lea rdi, [rsp]
0000747fd7fd778e  mov esi, 0x00
0000747fd7fd7793  mov rax, 0x6055A0B6E530
0000747fd7fd779d  call rax
0000747fd7fd779f  movaps xmm7, [rsp]
0000747fd7fd77a3  add rsp, 0x30
0000747fd7fd77a7  vmovaps xmm0, [rsp]
0000747fd7fd77ac  vmovaps xmm1, [rsp+0x10]
0000747fd7fd77b2  vmovaps xmm2, [rsp+0x20]
0000747fd7fd77b8  vmovaps xmm3, [rsp+0x30]
0000747fd7fd77be  vmovaps xmm4, [rsp+0x40]
0000747fd7fd77c4  vmovaps xmm5, [rsp+0x50]
0000747fd7fd77ca  vmovaps xmm6, [rsp+0x60]
0000747fd7fd77d0  vmovaps xmm8, [rsp+0x70]
0000747fd7fd77d6  vmovaps xmm9, [rsp+0x80]
0000747fd7fd77df  vmovaps xmm10, [rsp+0x90]
0000747fd7fd77e8  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd77f1  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd77fa  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd7803  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd780c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd7815  add rsp, 0xF0
0000747fd7fd781c  pop r11
0000747fd7fd781e  pop r10
0000747fd7fd7820  pop r9
0000747fd7fd7822  pop r8
0000747fd7fd7824  pop rsi
0000747fd7fd7825  pop rdi
0000747fd7fd7826  pop rdx
0000747fd7fd7827  pop rcx
0000747fd7fd7828  pop rax
0000747fd7fd7829  add rsp, 0x08
0000747fd7fd782d  jmp 0x0000747FD7FD5CD4
0000747fd7fd7832  sub rsp, 0x08
0000747fd7fd7836  push rax
0000747fd7fd7837  push rcx
0000747fd7fd7838  push rdx
0000747fd7fd7839  push rdi
0000747fd7fd783a  push rsi
0000747fd7fd783b  push r8
0000747fd7fd783d  push r9
0000747fd7fd783f  push r10
0000747fd7fd7841  push r11
0000747fd7fd7843  sub rsp, 0xF0
0000747fd7fd784a  vmovaps [rsp], xmm0
0000747fd7fd784f  vmovaps [rsp+0x10], xmm1
0000747fd7fd7855  vmovaps [rsp+0x20], xmm2
0000747fd7fd785b  vmovaps [rsp+0x30], xmm3
0000747fd7fd7861  vmovaps [rsp+0x40], xmm5
0000747fd7fd7867  vmovaps [rsp+0x50], xmm6
0000747fd7fd786d  vmovaps [rsp+0x60], xmm7
0000747fd7fd7873  vmovaps [rsp+0x70], xmm8
0000747fd7fd7879  vmovaps [rsp+0x80], xmm9
0000747fd7fd7882  vmovaps [rsp+0x90], xmm10
0000747fd7fd788b  vmovaps [rsp+0xA0], xmm11
0000747fd7fd7894  vmovaps [rsp+0xB0], xmm12
0000747fd7fd789d  vmovaps [rsp+0xC0], xmm13
0000747fd7fd78a6  vmovaps [rsp+0xD0], xmm14
0000747fd7fd78af  vmovaps [rsp+0xE0], xmm15
0000747fd7fd78b8  sub rsp, 0x30
0000747fd7fd78bc  movaps [rsp], xmm4
0000747fd7fd78c0  movaps [rsp+0x10], xmm15
0000747fd7fd78c6  movaps [rsp+0x20], xmm9
0000747fd7fd78cc  lea rdi, [rsp]
0000747fd7fd78d0  mov esi, 0x00
0000747fd7fd78d5  mov rax, 0x6055A0B6E530
0000747fd7fd78df  call rax
0000747fd7fd78e1  movaps xmm4, [rsp]
0000747fd7fd78e5  add rsp, 0x30
0000747fd7fd78e9  vmovaps xmm0, [rsp]
0000747fd7fd78ee  vmovaps xmm1, [rsp+0x10]
0000747fd7fd78f4  vmovaps xmm2, [rsp+0x20]
0000747fd7fd78fa  vmovaps xmm3, [rsp+0x30]
0000747fd7fd7900  vmovaps xmm5, [rsp+0x40]
0000747fd7fd7906  vmovaps xmm6, [rsp+0x50]
0000747fd7fd790c  vmovaps xmm7, [rsp+0x60]
0000747fd7fd7912  vmovaps xmm8, [rsp+0x70]
0000747fd7fd7918  vmovaps xmm9, [rsp+0x80]
0000747fd7fd7921  vmovaps xmm10, [rsp+0x90]
0000747fd7fd792a  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd7933  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd793c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd7945  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd794e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd7957  add rsp, 0xF0
0000747fd7fd795e  pop r11
0000747fd7fd7960  pop r10
0000747fd7fd7962  pop r9
0000747fd7fd7964  pop r8
0000747fd7fd7966  pop rsi
0000747fd7fd7967  pop rdi
0000747fd7fd7968  pop rdx
0000747fd7fd7969  pop rcx
0000747fd7fd796a  pop rax
0000747fd7fd796b  add rsp, 0x08
0000747fd7fd796f  jmp 0x0000747FD7FD5CF9
0000747fd7fd7974  call 0x0000747FD7EE5820
0000747fd7fd7979  jmp 0x0000747FD7FD5D06
0000747fd7fd797e  sub rsp, 0x08
0000747fd7fd7982  push rax
0000747fd7fd7983  push rcx
0000747fd7fd7984  push rdx
0000747fd7fd7985  push rdi
0000747fd7fd7986  push rsi
0000747fd7fd7987  push r8
0000747fd7fd7989  push r9
0000747fd7fd798b  push r10
0000747fd7fd798d  push r11
0000747fd7fd798f  sub rsp, 0xF0
0000747fd7fd7996  vmovaps [rsp], xmm0
0000747fd7fd799b  vmovaps [rsp+0x10], xmm1
0000747fd7fd79a1  vmovaps [rsp+0x20], xmm2
0000747fd7fd79a7  vmovaps [rsp+0x30], xmm4
0000747fd7fd79ad  vmovaps [rsp+0x40], xmm5
0000747fd7fd79b3  vmovaps [rsp+0x50], xmm6
0000747fd7fd79b9  vmovaps [rsp+0x60], xmm7
0000747fd7fd79bf  vmovaps [rsp+0x70], xmm8
0000747fd7fd79c5  vmovaps [rsp+0x80], xmm9
0000747fd7fd79ce  vmovaps [rsp+0x90], xmm10
0000747fd7fd79d7  vmovaps [rsp+0xA0], xmm11
0000747fd7fd79e0  vmovaps [rsp+0xB0], xmm12
0000747fd7fd79e9  vmovaps [rsp+0xC0], xmm13
0000747fd7fd79f2  vmovaps [rsp+0xD0], xmm14
0000747fd7fd79fb  vmovaps [rsp+0xE0], xmm15
0000747fd7fd7a04  sub rsp, 0x30
0000747fd7fd7a08  movaps [rsp], xmm3
0000747fd7fd7a0c  movaps [rsp+0x10], xmm1
0000747fd7fd7a11  movaps [rsp+0x20], xmm9
0000747fd7fd7a17  lea rdi, [rsp]
0000747fd7fd7a1b  mov esi, 0x00
0000747fd7fd7a20  mov rax, 0x6055A0B6E530
0000747fd7fd7a2a  call rax
0000747fd7fd7a2c  movaps xmm3, [rsp]
0000747fd7fd7a30  add rsp, 0x30
0000747fd7fd7a34  vmovaps xmm0, [rsp]
0000747fd7fd7a39  vmovaps xmm1, [rsp+0x10]
0000747fd7fd7a3f  vmovaps xmm2, [rsp+0x20]
0000747fd7fd7a45  vmovaps xmm4, [rsp+0x30]
0000747fd7fd7a4b  vmovaps xmm5, [rsp+0x40]
0000747fd7fd7a51  vmovaps xmm6, [rsp+0x50]
0000747fd7fd7a57  vmovaps xmm7, [rsp+0x60]
0000747fd7fd7a5d  vmovaps xmm8, [rsp+0x70]
0000747fd7fd7a63  vmovaps xmm9, [rsp+0x80]
0000747fd7fd7a6c  vmovaps xmm10, [rsp+0x90]
0000747fd7fd7a75  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd7a7e  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd7a87  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd7a90  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd7a99  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd7aa2  add rsp, 0xF0
0000747fd7fd7aa9  pop r11
0000747fd7fd7aab  pop r10
0000747fd7fd7aad  pop r9
0000747fd7fd7aaf  pop r8
0000747fd7fd7ab1  pop rsi
0000747fd7fd7ab2  pop rdi
0000747fd7fd7ab3  pop rdx
0000747fd7fd7ab4  pop rcx
0000747fd7fd7ab5  pop rax
0000747fd7fd7ab6  add rsp, 0x08
0000747fd7fd7aba  jmp 0x0000747FD7FD5D43
0000747fd7fd7abf  sub rsp, 0x08
0000747fd7fd7ac3  push rax
0000747fd7fd7ac4  push rcx
0000747fd7fd7ac5  push rdx
0000747fd7fd7ac6  push rdi
0000747fd7fd7ac7  push rsi
0000747fd7fd7ac8  push r8
0000747fd7fd7aca  push r9
0000747fd7fd7acc  push r10
0000747fd7fd7ace  push r11
0000747fd7fd7ad0  sub rsp, 0xF0
0000747fd7fd7ad7  vmovaps [rsp], xmm0
0000747fd7fd7adc  vmovaps [rsp+0x10], xmm2
0000747fd7fd7ae2  vmovaps [rsp+0x20], xmm3
0000747fd7fd7ae8  vmovaps [rsp+0x30], xmm4
0000747fd7fd7aee  vmovaps [rsp+0x40], xmm5
0000747fd7fd7af4  vmovaps [rsp+0x50], xmm6
0000747fd7fd7afa  vmovaps [rsp+0x60], xmm7
0000747fd7fd7b00  vmovaps [rsp+0x70], xmm8
0000747fd7fd7b06  vmovaps [rsp+0x80], xmm9
0000747fd7fd7b0f  vmovaps [rsp+0x90], xmm10
0000747fd7fd7b18  vmovaps [rsp+0xA0], xmm11
0000747fd7fd7b21  vmovaps [rsp+0xB0], xmm12
0000747fd7fd7b2a  vmovaps [rsp+0xC0], xmm13
0000747fd7fd7b33  vmovaps [rsp+0xD0], xmm14
0000747fd7fd7b3c  vmovaps [rsp+0xE0], xmm15
0000747fd7fd7b45  sub rsp, 0x30
0000747fd7fd7b49  movaps [rsp], xmm1
0000747fd7fd7b4d  movaps [rsp+0x10], xmm15
0000747fd7fd7b53  movaps [rsp+0x20], xmm9
0000747fd7fd7b59  lea rdi, [rsp]
0000747fd7fd7b5d  mov esi, 0x00
0000747fd7fd7b62  mov rax, 0x6055A0B6E530
0000747fd7fd7b6c  call rax
0000747fd7fd7b6e  movaps xmm1, [rsp]
0000747fd7fd7b72  add rsp, 0x30
0000747fd7fd7b76  vmovaps xmm0, [rsp]
0000747fd7fd7b7b  vmovaps xmm2, [rsp+0x10]
0000747fd7fd7b81  vmovaps xmm3, [rsp+0x20]
0000747fd7fd7b87  vmovaps xmm4, [rsp+0x30]
0000747fd7fd7b8d  vmovaps xmm5, [rsp+0x40]
0000747fd7fd7b93  vmovaps xmm6, [rsp+0x50]
0000747fd7fd7b99  vmovaps xmm7, [rsp+0x60]
0000747fd7fd7b9f  vmovaps xmm8, [rsp+0x70]
0000747fd7fd7ba5  vmovaps xmm9, [rsp+0x80]
0000747fd7fd7bae  vmovaps xmm10, [rsp+0x90]
0000747fd7fd7bb7  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd7bc0  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd7bc9  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd7bd2  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd7bdb  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd7be4  add rsp, 0xF0
0000747fd7fd7beb  pop r11
0000747fd7fd7bed  pop r10
0000747fd7fd7bef  pop r9
0000747fd7fd7bf1  pop r8
0000747fd7fd7bf3  pop rsi
0000747fd7fd7bf4  pop rdi
0000747fd7fd7bf5  pop rdx
0000747fd7fd7bf6  pop rcx
0000747fd7fd7bf7  pop rax
0000747fd7fd7bf8  add rsp, 0x08
0000747fd7fd7bfc  jmp 0x0000747FD7FD5DCB
0000747fd7fd7c01  call 0x0000747FD7EE5820
0000747fd7fd7c06  jmp 0x0000747FD7FD5DD8
0000747fd7fd7c0b  sub rsp, 0x08
0000747fd7fd7c0f  push rax
0000747fd7fd7c10  push rcx
0000747fd7fd7c11  push rdx
0000747fd7fd7c12  push rdi
0000747fd7fd7c13  push rsi
0000747fd7fd7c14  push r8
0000747fd7fd7c16  push r9
0000747fd7fd7c18  push r10
0000747fd7fd7c1a  push r11
0000747fd7fd7c1c  sub rsp, 0xF0
0000747fd7fd7c23  vmovaps [rsp], xmm0
0000747fd7fd7c28  vmovaps [rsp+0x10], xmm2
0000747fd7fd7c2e  vmovaps [rsp+0x20], xmm3
0000747fd7fd7c34  vmovaps [rsp+0x30], xmm4
0000747fd7fd7c3a  vmovaps [rsp+0x40], xmm5
0000747fd7fd7c40  vmovaps [rsp+0x50], xmm6
0000747fd7fd7c46  vmovaps [rsp+0x60], xmm7
0000747fd7fd7c4c  vmovaps [rsp+0x70], xmm8
0000747fd7fd7c52  vmovaps [rsp+0x80], xmm9
0000747fd7fd7c5b  vmovaps [rsp+0x90], xmm10
0000747fd7fd7c64  vmovaps [rsp+0xA0], xmm11
0000747fd7fd7c6d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd7c76  vmovaps [rsp+0xC0], xmm13
0000747fd7fd7c7f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd7c88  vmovaps [rsp+0xE0], xmm15
0000747fd7fd7c91  sub rsp, 0x30
0000747fd7fd7c95  movaps [rsp], xmm1
0000747fd7fd7c99  movaps [rsp+0x10], xmm5
0000747fd7fd7c9e  movaps [rsp+0x20], xmm7
0000747fd7fd7ca3  lea rdi, [rsp]
0000747fd7fd7ca7  mov esi, 0x00
0000747fd7fd7cac  mov rax, 0x6055A0B6E530
0000747fd7fd7cb6  call rax
0000747fd7fd7cb8  movaps xmm1, [rsp]
0000747fd7fd7cbc  add rsp, 0x30
0000747fd7fd7cc0  vmovaps xmm0, [rsp]
0000747fd7fd7cc5  vmovaps xmm2, [rsp+0x10]
0000747fd7fd7ccb  vmovaps xmm3, [rsp+0x20]
0000747fd7fd7cd1  vmovaps xmm4, [rsp+0x30]
0000747fd7fd7cd7  vmovaps xmm5, [rsp+0x40]
0000747fd7fd7cdd  vmovaps xmm6, [rsp+0x50]
0000747fd7fd7ce3  vmovaps xmm7, [rsp+0x60]
0000747fd7fd7ce9  vmovaps xmm8, [rsp+0x70]
0000747fd7fd7cef  vmovaps xmm9, [rsp+0x80]
0000747fd7fd7cf8  vmovaps xmm10, [rsp+0x90]
0000747fd7fd7d01  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd7d0a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd7d13  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd7d1c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd7d25  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd7d2e  add rsp, 0xF0
0000747fd7fd7d35  pop r11
0000747fd7fd7d37  pop r10
0000747fd7fd7d39  pop r9
0000747fd7fd7d3b  pop r8
0000747fd7fd7d3d  pop rsi
0000747fd7fd7d3e  pop rdi
0000747fd7fd7d3f  pop rdx
0000747fd7fd7d40  pop rcx
0000747fd7fd7d41  pop rax
0000747fd7fd7d42  add rsp, 0x08
0000747fd7fd7d46  jmp 0x0000747FD7FD5E7D
0000747fd7fd7d4b  sub rsp, 0x08
0000747fd7fd7d4f  push rax
0000747fd7fd7d50  push rcx
0000747fd7fd7d51  push rdx
0000747fd7fd7d52  push rdi
0000747fd7fd7d53  push rsi
0000747fd7fd7d54  push r8
0000747fd7fd7d56  push r9
0000747fd7fd7d58  push r10
0000747fd7fd7d5a  push r11
0000747fd7fd7d5c  sub rsp, 0xF0
0000747fd7fd7d63  vmovaps [rsp], xmm0
0000747fd7fd7d68  vmovaps [rsp+0x10], xmm1
0000747fd7fd7d6e  vmovaps [rsp+0x20], xmm2
0000747fd7fd7d74  vmovaps [rsp+0x30], xmm3
0000747fd7fd7d7a  vmovaps [rsp+0x40], xmm4
0000747fd7fd7d80  vmovaps [rsp+0x50], xmm5
0000747fd7fd7d86  vmovaps [rsp+0x60], xmm6
0000747fd7fd7d8c  vmovaps [rsp+0x70], xmm8
0000747fd7fd7d92  vmovaps [rsp+0x80], xmm9
0000747fd7fd7d9b  vmovaps [rsp+0x90], xmm10
0000747fd7fd7da4  vmovaps [rsp+0xA0], xmm11
0000747fd7fd7dad  vmovaps [rsp+0xB0], xmm12
0000747fd7fd7db6  vmovaps [rsp+0xC0], xmm13
0000747fd7fd7dbf  vmovaps [rsp+0xD0], xmm14
0000747fd7fd7dc8  vmovaps [rsp+0xE0], xmm15
0000747fd7fd7dd1  sub rsp, 0x30
0000747fd7fd7dd5  movaps [rsp], xmm7
0000747fd7fd7dd9  movaps [rsp+0x10], xmm5
0000747fd7fd7dde  movaps [rsp+0x20], xmm15
0000747fd7fd7de4  lea rdi, [rsp]
0000747fd7fd7de8  mov esi, 0x00
0000747fd7fd7ded  mov rax, 0x6055A0B6E530
0000747fd7fd7df7  call rax
0000747fd7fd7df9  movaps xmm7, [rsp]
0000747fd7fd7dfd  add rsp, 0x30
0000747fd7fd7e01  vmovaps xmm0, [rsp]
0000747fd7fd7e06  vmovaps xmm1, [rsp+0x10]
0000747fd7fd7e0c  vmovaps xmm2, [rsp+0x20]
0000747fd7fd7e12  vmovaps xmm3, [rsp+0x30]
0000747fd7fd7e18  vmovaps xmm4, [rsp+0x40]
0000747fd7fd7e1e  vmovaps xmm5, [rsp+0x50]
0000747fd7fd7e24  vmovaps xmm6, [rsp+0x60]
0000747fd7fd7e2a  vmovaps xmm8, [rsp+0x70]
0000747fd7fd7e30  vmovaps xmm9, [rsp+0x80]
0000747fd7fd7e39  vmovaps xmm10, [rsp+0x90]
0000747fd7fd7e42  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd7e4b  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd7e54  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd7e5d  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd7e66  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd7e6f  add rsp, 0xF0
0000747fd7fd7e76  pop r11
0000747fd7fd7e78  pop r10
0000747fd7fd7e7a  pop r9
0000747fd7fd7e7c  pop r8
0000747fd7fd7e7e  pop rsi
0000747fd7fd7e7f  pop rdi
0000747fd7fd7e80  pop rdx
0000747fd7fd7e81  pop rcx
0000747fd7fd7e82  pop rax
0000747fd7fd7e83  add rsp, 0x08
0000747fd7fd7e87  jmp 0x0000747FD7FD5EB3
0000747fd7fd7e8c  call 0x0000747FD7ED64F0
0000747fd7fd7e91  jmp 0x0000747FD7FD5EC0
0000747fd7fd7e96  sub rsp, 0x08
0000747fd7fd7e9a  push rax
0000747fd7fd7e9b  push rcx
0000747fd7fd7e9c  push rdx
0000747fd7fd7e9d  push rdi
0000747fd7fd7e9e  push rsi
0000747fd7fd7e9f  push r8
0000747fd7fd7ea1  push r9
0000747fd7fd7ea3  push r10
0000747fd7fd7ea5  push r11
0000747fd7fd7ea7  sub rsp, 0xF0
0000747fd7fd7eae  vmovaps [rsp], xmm0
0000747fd7fd7eb3  vmovaps [rsp+0x10], xmm1
0000747fd7fd7eb9  vmovaps [rsp+0x20], xmm2
0000747fd7fd7ebf  vmovaps [rsp+0x30], xmm3
0000747fd7fd7ec5  vmovaps [rsp+0x40], xmm4
0000747fd7fd7ecb  vmovaps [rsp+0x50], xmm5
0000747fd7fd7ed1  vmovaps [rsp+0x60], xmm6
0000747fd7fd7ed7  vmovaps [rsp+0x70], xmm7
0000747fd7fd7edd  vmovaps [rsp+0x80], xmm8
0000747fd7fd7ee6  vmovaps [rsp+0x90], xmm9
0000747fd7fd7eef  vmovaps [rsp+0xA0], xmm10
0000747fd7fd7ef8  vmovaps [rsp+0xB0], xmm11
0000747fd7fd7f01  vmovaps [rsp+0xC0], xmm12
0000747fd7fd7f0a  vmovaps [rsp+0xD0], xmm13
0000747fd7fd7f13  vmovaps [rsp+0xE0], xmm14
0000747fd7fd7f1c  sub rsp, 0x30
0000747fd7fd7f20  movaps [rsp], xmm15
0000747fd7fd7f25  movaps [rsp+0x10], xmm5
0000747fd7fd7f2a  movaps [rsp+0x20], xmm3
0000747fd7fd7f2f  lea rdi, [rsp]
0000747fd7fd7f33  mov esi, 0x00
0000747fd7fd7f38  mov rax, 0x6055A0B6E530
0000747fd7fd7f42  call rax
0000747fd7fd7f44  movaps xmm15, [rsp]
0000747fd7fd7f49  add rsp, 0x30
0000747fd7fd7f4d  vmovaps xmm0, [rsp]
0000747fd7fd7f52  vmovaps xmm1, [rsp+0x10]
0000747fd7fd7f58  vmovaps xmm2, [rsp+0x20]
0000747fd7fd7f5e  vmovaps xmm3, [rsp+0x30]
0000747fd7fd7f64  vmovaps xmm4, [rsp+0x40]
0000747fd7fd7f6a  vmovaps xmm5, [rsp+0x50]
0000747fd7fd7f70  vmovaps xmm6, [rsp+0x60]
0000747fd7fd7f76  vmovaps xmm7, [rsp+0x70]
0000747fd7fd7f7c  vmovaps xmm8, [rsp+0x80]
0000747fd7fd7f85  vmovaps xmm9, [rsp+0x90]
0000747fd7fd7f8e  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd7f97  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd7fa0  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd7fa9  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd7fb2  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd7fbb  add rsp, 0xF0
0000747fd7fd7fc2  pop r11
0000747fd7fd7fc4  pop r10
0000747fd7fd7fc6  pop r9
0000747fd7fd7fc8  pop r8
0000747fd7fd7fca  pop rsi
0000747fd7fd7fcb  pop rdi
0000747fd7fd7fcc  pop rdx
0000747fd7fd7fcd  pop rcx
0000747fd7fd7fce  pop rax
0000747fd7fd7fcf  add rsp, 0x08
0000747fd7fd7fd3  jmp 0x0000747FD7FD5EE6
0000747fd7fd7fd8  sub rsp, 0x08
0000747fd7fd7fdc  push rax
0000747fd7fd7fdd  push rcx
0000747fd7fd7fde  push rdx
0000747fd7fd7fdf  push rdi
0000747fd7fd7fe0  push rsi
0000747fd7fd7fe1  push r8
0000747fd7fd7fe3  push r9
0000747fd7fd7fe5  push r10
0000747fd7fd7fe7  push r11
0000747fd7fd7fe9  sub rsp, 0xF0
0000747fd7fd7ff0  vmovaps [rsp], xmm0
0000747fd7fd7ff5  vmovaps [rsp+0x10], xmm2
0000747fd7fd7ffb  vmovaps [rsp+0x20], xmm3
0000747fd7fd8001  vmovaps [rsp+0x30], xmm4
0000747fd7fd8007  vmovaps [rsp+0x40], xmm5
0000747fd7fd800d  vmovaps [rsp+0x50], xmm6
0000747fd7fd8013  vmovaps [rsp+0x60], xmm7
0000747fd7fd8019  vmovaps [rsp+0x70], xmm8
0000747fd7fd801f  vmovaps [rsp+0x80], xmm9
0000747fd7fd8028  vmovaps [rsp+0x90], xmm10
0000747fd7fd8031  vmovaps [rsp+0xA0], xmm11
0000747fd7fd803a  vmovaps [rsp+0xB0], xmm12
0000747fd7fd8043  vmovaps [rsp+0xC0], xmm13
0000747fd7fd804c  vmovaps [rsp+0xD0], xmm14
0000747fd7fd8055  vmovaps [rsp+0xE0], xmm15
0000747fd7fd805e  sub rsp, 0x30
0000747fd7fd8062  movaps [rsp], xmm1
0000747fd7fd8066  movaps [rsp+0x10], xmm5
0000747fd7fd806b  movaps [rsp+0x20], xmm4
0000747fd7fd8070  lea rdi, [rsp]
0000747fd7fd8074  mov esi, 0x00
0000747fd7fd8079  mov rax, 0x6055A0B6E530
0000747fd7fd8083  call rax
0000747fd7fd8085  movaps xmm1, [rsp]
0000747fd7fd8089  add rsp, 0x30
0000747fd7fd808d  vmovaps xmm0, [rsp]
0000747fd7fd8092  vmovaps xmm2, [rsp+0x10]
0000747fd7fd8098  vmovaps xmm3, [rsp+0x20]
0000747fd7fd809e  vmovaps xmm4, [rsp+0x30]
0000747fd7fd80a4  vmovaps xmm5, [rsp+0x40]
0000747fd7fd80aa  vmovaps xmm6, [rsp+0x50]
0000747fd7fd80b0  vmovaps xmm7, [rsp+0x60]
0000747fd7fd80b6  vmovaps xmm8, [rsp+0x70]
0000747fd7fd80bc  vmovaps xmm9, [rsp+0x80]
0000747fd7fd80c5  vmovaps xmm10, [rsp+0x90]
0000747fd7fd80ce  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd80d7  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd80e0  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd80e9  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd80f2  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd80fb  add rsp, 0xF0
0000747fd7fd8102  pop r11
0000747fd7fd8104  pop r10
0000747fd7fd8106  pop r9
0000747fd7fd8108  pop r8
0000747fd7fd810a  pop rsi
0000747fd7fd810b  pop rdi
0000747fd7fd810c  pop rdx
0000747fd7fd810d  pop rcx
0000747fd7fd810e  pop rax
0000747fd7fd810f  add rsp, 0x08
0000747fd7fd8113  jmp 0x0000747FD7FD5F06
0000747fd7fd8118  sub rsp, 0x08
0000747fd7fd811c  push rax
0000747fd7fd811d  push rcx
0000747fd7fd811e  push rdx
0000747fd7fd811f  push rdi
0000747fd7fd8120  push rsi
0000747fd7fd8121  push r8
0000747fd7fd8123  push r9
0000747fd7fd8125  push r10
0000747fd7fd8127  push r11
0000747fd7fd8129  sub rsp, 0xF0
0000747fd7fd8130  vmovaps [rsp], xmm0
0000747fd7fd8135  vmovaps [rsp+0x10], xmm1
0000747fd7fd813b  vmovaps [rsp+0x20], xmm2
0000747fd7fd8141  vmovaps [rsp+0x30], xmm3
0000747fd7fd8147  vmovaps [rsp+0x40], xmm5
0000747fd7fd814d  vmovaps [rsp+0x50], xmm6
0000747fd7fd8153  vmovaps [rsp+0x60], xmm7
0000747fd7fd8159  vmovaps [rsp+0x70], xmm8
0000747fd7fd815f  vmovaps [rsp+0x80], xmm9
0000747fd7fd8168  vmovaps [rsp+0x90], xmm10
0000747fd7fd8171  vmovaps [rsp+0xA0], xmm11
0000747fd7fd817a  vmovaps [rsp+0xB0], xmm12
0000747fd7fd8183  vmovaps [rsp+0xC0], xmm13
0000747fd7fd818c  vmovaps [rsp+0xD0], xmm14
0000747fd7fd8195  vmovaps [rsp+0xE0], xmm15
0000747fd7fd819e  sub rsp, 0x30
0000747fd7fd81a2  movaps [rsp], xmm4
0000747fd7fd81a6  movaps [rsp+0x10], xmm3
0000747fd7fd81ab  movaps [rsp+0x20], xmm5
0000747fd7fd81b0  lea rdi, [rsp]
0000747fd7fd81b4  mov esi, 0x00
0000747fd7fd81b9  mov rax, 0x6055A0B6E530
0000747fd7fd81c3  call rax
0000747fd7fd81c5  movaps xmm4, [rsp]
0000747fd7fd81c9  add rsp, 0x30
0000747fd7fd81cd  vmovaps xmm0, [rsp]
0000747fd7fd81d2  vmovaps xmm1, [rsp+0x10]
0000747fd7fd81d8  vmovaps xmm2, [rsp+0x20]
0000747fd7fd81de  vmovaps xmm3, [rsp+0x30]
0000747fd7fd81e4  vmovaps xmm5, [rsp+0x40]
0000747fd7fd81ea  vmovaps xmm6, [rsp+0x50]
0000747fd7fd81f0  vmovaps xmm7, [rsp+0x60]
0000747fd7fd81f6  vmovaps xmm8, [rsp+0x70]
0000747fd7fd81fc  vmovaps xmm9, [rsp+0x80]
0000747fd7fd8205  vmovaps xmm10, [rsp+0x90]
0000747fd7fd820e  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd8217  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd8220  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd8229  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd8232  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd823b  add rsp, 0xF0
0000747fd7fd8242  pop r11
0000747fd7fd8244  pop r10
0000747fd7fd8246  pop r9
0000747fd7fd8248  pop r8
0000747fd7fd824a  pop rsi
0000747fd7fd824b  pop rdi
0000747fd7fd824c  pop rdx
0000747fd7fd824d  pop rcx
0000747fd7fd824e  pop rax
0000747fd7fd824f  add rsp, 0x08
0000747fd7fd8253  jmp 0x0000747FD7FD5F54
0000747fd7fd8258  call 0x0000747FD7ED64F0
0000747fd7fd825d  jmp 0x0000747FD7FD5F61
0000747fd7fd8262  sub rsp, 0x08
0000747fd7fd8266  push rax
0000747fd7fd8267  push rcx
0000747fd7fd8268  push rdx
0000747fd7fd8269  push rdi
0000747fd7fd826a  push rsi
0000747fd7fd826b  push r8
0000747fd7fd826d  push r9
0000747fd7fd826f  push r10
0000747fd7fd8271  push r11
0000747fd7fd8273  sub rsp, 0xF0
0000747fd7fd827a  vmovaps [rsp], xmm0
0000747fd7fd827f  vmovaps [rsp+0x10], xmm1
0000747fd7fd8285  vmovaps [rsp+0x20], xmm2
0000747fd7fd828b  vmovaps [rsp+0x30], xmm3
0000747fd7fd8291  vmovaps [rsp+0x40], xmm4
0000747fd7fd8297  vmovaps [rsp+0x50], xmm6
0000747fd7fd829d  vmovaps [rsp+0x60], xmm7
0000747fd7fd82a3  vmovaps [rsp+0x70], xmm8
0000747fd7fd82a9  vmovaps [rsp+0x80], xmm9
0000747fd7fd82b2  vmovaps [rsp+0x90], xmm10
0000747fd7fd82bb  vmovaps [rsp+0xA0], xmm11
0000747fd7fd82c4  vmovaps [rsp+0xB0], xmm12
0000747fd7fd82cd  vmovaps [rsp+0xC0], xmm13
0000747fd7fd82d6  vmovaps [rsp+0xD0], xmm14
0000747fd7fd82df  vmovaps [rsp+0xE0], xmm15
0000747fd7fd82e8  sub rsp, 0x30
0000747fd7fd82ec  movaps [rsp], xmm5
0000747fd7fd82f0  movaps [rsp+0x10], xmm6
0000747fd7fd82f5  movaps [rsp+0x20], xmm3
0000747fd7fd82fa  lea rdi, [rsp]
0000747fd7fd82fe  mov esi, 0x00
0000747fd7fd8303  mov rax, 0x6055A0B6E530
0000747fd7fd830d  call rax
0000747fd7fd830f  movaps xmm5, [rsp]
0000747fd7fd8313  add rsp, 0x30
0000747fd7fd8317  vmovaps xmm0, [rsp]
0000747fd7fd831c  vmovaps xmm1, [rsp+0x10]
0000747fd7fd8322  vmovaps xmm2, [rsp+0x20]
0000747fd7fd8328  vmovaps xmm3, [rsp+0x30]
0000747fd7fd832e  vmovaps xmm4, [rsp+0x40]
0000747fd7fd8334  vmovaps xmm6, [rsp+0x50]
0000747fd7fd833a  vmovaps xmm7, [rsp+0x60]
0000747fd7fd8340  vmovaps xmm8, [rsp+0x70]
0000747fd7fd8346  vmovaps xmm9, [rsp+0x80]
0000747fd7fd834f  vmovaps xmm10, [rsp+0x90]
0000747fd7fd8358  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd8361  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd836a  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd8373  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd837c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd8385  add rsp, 0xF0
0000747fd7fd838c  pop r11
0000747fd7fd838e  pop r10
0000747fd7fd8390  pop r9
0000747fd7fd8392  pop r8
0000747fd7fd8394  pop rsi
0000747fd7fd8395  pop rdi
0000747fd7fd8396  pop rdx
0000747fd7fd8397  pop rcx
0000747fd7fd8398  pop rax
0000747fd7fd8399  add rsp, 0x08
0000747fd7fd839d  jmp 0x0000747FD7FD5F87
0000747fd7fd83a2  sub rsp, 0x08
0000747fd7fd83a6  push rax
0000747fd7fd83a7  push rcx
0000747fd7fd83a8  push rdx
0000747fd7fd83a9  push rdi
0000747fd7fd83aa  push rsi
0000747fd7fd83ab  push r8
0000747fd7fd83ad  push r9
0000747fd7fd83af  push r10
0000747fd7fd83b1  push r11
0000747fd7fd83b3  sub rsp, 0xF0
0000747fd7fd83ba  vmovaps [rsp], xmm0
0000747fd7fd83bf  vmovaps [rsp+0x10], xmm1
0000747fd7fd83c5  vmovaps [rsp+0x20], xmm2
0000747fd7fd83cb  vmovaps [rsp+0x30], xmm3
0000747fd7fd83d1  vmovaps [rsp+0x40], xmm4
0000747fd7fd83d7  vmovaps [rsp+0x50], xmm5
0000747fd7fd83dd  vmovaps [rsp+0x60], xmm7
0000747fd7fd83e3  vmovaps [rsp+0x70], xmm8
0000747fd7fd83e9  vmovaps [rsp+0x80], xmm9
0000747fd7fd83f2  vmovaps [rsp+0x90], xmm10
0000747fd7fd83fb  vmovaps [rsp+0xA0], xmm11
0000747fd7fd8404  vmovaps [rsp+0xB0], xmm12
0000747fd7fd840d  vmovaps [rsp+0xC0], xmm13
0000747fd7fd8416  vmovaps [rsp+0xD0], xmm14
0000747fd7fd841f  vmovaps [rsp+0xE0], xmm15
0000747fd7fd8428  sub rsp, 0x30
0000747fd7fd842c  movaps [rsp], xmm6
0000747fd7fd8430  movaps [rsp+0x10], xmm9
0000747fd7fd8436  movaps [rsp+0x20], xmm1
0000747fd7fd843b  lea rdi, [rsp]
0000747fd7fd843f  mov esi, 0x00
0000747fd7fd8444  mov rax, 0x6055A0B6E530
0000747fd7fd844e  call rax
0000747fd7fd8450  movaps xmm6, [rsp]
0000747fd7fd8454  add rsp, 0x30
0000747fd7fd8458  vmovaps xmm0, [rsp]
0000747fd7fd845d  vmovaps xmm1, [rsp+0x10]
0000747fd7fd8463  vmovaps xmm2, [rsp+0x20]
0000747fd7fd8469  vmovaps xmm3, [rsp+0x30]
0000747fd7fd846f  vmovaps xmm4, [rsp+0x40]
0000747fd7fd8475  vmovaps xmm5, [rsp+0x50]
0000747fd7fd847b  vmovaps xmm7, [rsp+0x60]
0000747fd7fd8481  vmovaps xmm8, [rsp+0x70]
0000747fd7fd8487  vmovaps xmm9, [rsp+0x80]
0000747fd7fd8490  vmovaps xmm10, [rsp+0x90]
0000747fd7fd8499  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd84a2  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd84ab  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd84b4  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd84bd  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd84c6  add rsp, 0xF0
0000747fd7fd84cd  pop r11
0000747fd7fd84cf  pop r10
0000747fd7fd84d1  pop r9
0000747fd7fd84d3  pop r8
0000747fd7fd84d5  pop rsi
0000747fd7fd84d6  pop rdi
0000747fd7fd84d7  pop rdx
0000747fd7fd84d8  pop rcx
0000747fd7fd84d9  pop rax
0000747fd7fd84da  add rsp, 0x08
0000747fd7fd84de  jmp 0x0000747FD7FD5FAB
0000747fd7fd84e3  sub rsp, 0x08
0000747fd7fd84e7  push rax
0000747fd7fd84e8  push rcx
0000747fd7fd84e9  push rdx
0000747fd7fd84ea  push rdi
0000747fd7fd84eb  push rsi
0000747fd7fd84ec  push r8
0000747fd7fd84ee  push r9
0000747fd7fd84f0  push r10
0000747fd7fd84f2  push r11
0000747fd7fd84f4  sub rsp, 0xF0
0000747fd7fd84fb  vmovaps [rsp], xmm0
0000747fd7fd8500  vmovaps [rsp+0x10], xmm1
0000747fd7fd8506  vmovaps [rsp+0x20], xmm2
0000747fd7fd850c  vmovaps [rsp+0x30], xmm3
0000747fd7fd8512  vmovaps [rsp+0x40], xmm4
0000747fd7fd8518  vmovaps [rsp+0x50], xmm5
0000747fd7fd851e  vmovaps [rsp+0x60], xmm6
0000747fd7fd8524  vmovaps [rsp+0x70], xmm7
0000747fd7fd852a  vmovaps [rsp+0x80], xmm8
0000747fd7fd8533  vmovaps [rsp+0x90], xmm10
0000747fd7fd853c  vmovaps [rsp+0xA0], xmm11
0000747fd7fd8545  vmovaps [rsp+0xB0], xmm12
0000747fd7fd854e  vmovaps [rsp+0xC0], xmm13
0000747fd7fd8557  vmovaps [rsp+0xD0], xmm14
0000747fd7fd8560  vmovaps [rsp+0xE0], xmm15
0000747fd7fd8569  sub rsp, 0x30
0000747fd7fd856d  movaps [rsp], xmm9
0000747fd7fd8572  movaps [rsp+0x10], xmm3
0000747fd7fd8577  movaps [rsp+0x20], xmm1
0000747fd7fd857c  lea rdi, [rsp]
0000747fd7fd8580  mov esi, 0x00
0000747fd7fd8585  mov rax, 0x6055A0B6E530
0000747fd7fd858f  call rax
0000747fd7fd8591  movaps xmm9, [rsp]
0000747fd7fd8596  add rsp, 0x30
0000747fd7fd859a  vmovaps xmm0, [rsp]
0000747fd7fd859f  vmovaps xmm1, [rsp+0x10]
0000747fd7fd85a5  vmovaps xmm2, [rsp+0x20]
0000747fd7fd85ab  vmovaps xmm3, [rsp+0x30]
0000747fd7fd85b1  vmovaps xmm4, [rsp+0x40]
0000747fd7fd85b7  vmovaps xmm5, [rsp+0x50]
0000747fd7fd85bd  vmovaps xmm6, [rsp+0x60]
0000747fd7fd85c3  vmovaps xmm7, [rsp+0x70]
0000747fd7fd85c9  vmovaps xmm8, [rsp+0x80]
0000747fd7fd85d2  vmovaps xmm10, [rsp+0x90]
0000747fd7fd85db  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd85e4  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd85ed  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd85f6  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd85ff  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd8608  add rsp, 0xF0
0000747fd7fd860f  pop r11
0000747fd7fd8611  pop r10
0000747fd7fd8613  pop r9
0000747fd7fd8615  pop r8
0000747fd7fd8617  pop rsi
0000747fd7fd8618  pop rdi
0000747fd7fd8619  pop rdx
0000747fd7fd861a  pop rcx
0000747fd7fd861b  pop rax
0000747fd7fd861c  add rsp, 0x08
0000747fd7fd8620  jmp 0x0000747FD7FD5FF7
0000747fd7fd8625  call 0x0000747FD7ED64F0
0000747fd7fd862a  jmp 0x0000747FD7FD6004
0000747fd7fd862f  sub rsp, 0x08
0000747fd7fd8633  push rax
0000747fd7fd8634  push rcx
0000747fd7fd8635  push rdx
0000747fd7fd8636  push rdi
0000747fd7fd8637  push rsi
0000747fd7fd8638  push r8
0000747fd7fd863a  push r9
0000747fd7fd863c  push r10
0000747fd7fd863e  push r11
0000747fd7fd8640  sub rsp, 0xF0
0000747fd7fd8647  vmovaps [rsp], xmm0
0000747fd7fd864c  vmovaps [rsp+0x10], xmm1
0000747fd7fd8652  vmovaps [rsp+0x20], xmm2
0000747fd7fd8658  vmovaps [rsp+0x30], xmm3
0000747fd7fd865e  vmovaps [rsp+0x40], xmm4
0000747fd7fd8664  vmovaps [rsp+0x50], xmm5
0000747fd7fd866a  vmovaps [rsp+0x60], xmm6
0000747fd7fd8670  vmovaps [rsp+0x70], xmm7
0000747fd7fd8676  vmovaps [rsp+0x80], xmm8
0000747fd7fd867f  vmovaps [rsp+0x90], xmm9
0000747fd7fd8688  vmovaps [rsp+0xA0], xmm10
0000747fd7fd8691  vmovaps [rsp+0xB0], xmm11
0000747fd7fd869a  vmovaps [rsp+0xC0], xmm12
0000747fd7fd86a3  vmovaps [rsp+0xD0], xmm13
0000747fd7fd86ac  vmovaps [rsp+0xE0], xmm14
0000747fd7fd86b5  sub rsp, 0x30
0000747fd7fd86b9  movaps [rsp], xmm15
0000747fd7fd86be  movaps [rsp+0x10], xmm3
0000747fd7fd86c3  movaps [rsp+0x20], xmm7
0000747fd7fd86c8  lea rdi, [rsp]
0000747fd7fd86cc  mov esi, 0x00
0000747fd7fd86d1  mov rax, 0x6055A0B6E530
0000747fd7fd86db  call rax
0000747fd7fd86dd  movaps xmm15, [rsp]
0000747fd7fd86e2  add rsp, 0x30
0000747fd7fd86e6  vmovaps xmm0, [rsp]
0000747fd7fd86eb  vmovaps xmm1, [rsp+0x10]
0000747fd7fd86f1  vmovaps xmm2, [rsp+0x20]
0000747fd7fd86f7  vmovaps xmm3, [rsp+0x30]
0000747fd7fd86fd  vmovaps xmm4, [rsp+0x40]
0000747fd7fd8703  vmovaps xmm5, [rsp+0x50]
0000747fd7fd8709  vmovaps xmm6, [rsp+0x60]
0000747fd7fd870f  vmovaps xmm7, [rsp+0x70]
0000747fd7fd8715  vmovaps xmm8, [rsp+0x80]
0000747fd7fd871e  vmovaps xmm9, [rsp+0x90]
0000747fd7fd8727  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd8730  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd8739  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd8742  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd874b  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd8754  add rsp, 0xF0
0000747fd7fd875b  pop r11
0000747fd7fd875d  pop r10
0000747fd7fd875f  pop r9
0000747fd7fd8761  pop r8
0000747fd7fd8763  pop rsi
0000747fd7fd8764  pop rdi
0000747fd7fd8765  pop rdx
0000747fd7fd8766  pop rcx
0000747fd7fd8767  pop rax
0000747fd7fd8768  add rsp, 0x08
0000747fd7fd876c  jmp 0x0000747FD7FD6030
0000747fd7fd8771  sub rsp, 0x08
0000747fd7fd8775  push rax
0000747fd7fd8776  push rcx
0000747fd7fd8777  push rdx
0000747fd7fd8778  push rdi
0000747fd7fd8779  push rsi
0000747fd7fd877a  push r8
0000747fd7fd877c  push r9
0000747fd7fd877e  push r10
0000747fd7fd8780  push r11
0000747fd7fd8782  sub rsp, 0xF0
0000747fd7fd8789  vmovaps [rsp], xmm0
0000747fd7fd878e  vmovaps [rsp+0x10], xmm1
0000747fd7fd8794  vmovaps [rsp+0x20], xmm2
0000747fd7fd879a  vmovaps [rsp+0x30], xmm4
0000747fd7fd87a0  vmovaps [rsp+0x40], xmm5
0000747fd7fd87a6  vmovaps [rsp+0x50], xmm6
0000747fd7fd87ac  vmovaps [rsp+0x60], xmm7
0000747fd7fd87b2  vmovaps [rsp+0x70], xmm8
0000747fd7fd87b8  vmovaps [rsp+0x80], xmm9
0000747fd7fd87c1  vmovaps [rsp+0x90], xmm10
0000747fd7fd87ca  vmovaps [rsp+0xA0], xmm11
0000747fd7fd87d3  vmovaps [rsp+0xB0], xmm12
0000747fd7fd87dc  vmovaps [rsp+0xC0], xmm13
0000747fd7fd87e5  vmovaps [rsp+0xD0], xmm14
0000747fd7fd87ee  vmovaps [rsp+0xE0], xmm15
0000747fd7fd87f7  sub rsp, 0x30
0000747fd7fd87fb  movaps [rsp], xmm3
0000747fd7fd87ff  movaps [rsp+0x10], xmm1
0000747fd7fd8804  movaps [rsp+0x20], xmm15
0000747fd7fd880a  lea rdi, [rsp]
0000747fd7fd880e  mov esi, 0x00
0000747fd7fd8813  mov rax, 0x6055A0B6E530
0000747fd7fd881d  call rax
0000747fd7fd881f  movaps xmm3, [rsp]
0000747fd7fd8823  add rsp, 0x30
0000747fd7fd8827  vmovaps xmm0, [rsp]
0000747fd7fd882c  vmovaps xmm1, [rsp+0x10]
0000747fd7fd8832  vmovaps xmm2, [rsp+0x20]
0000747fd7fd8838  vmovaps xmm4, [rsp+0x30]
0000747fd7fd883e  vmovaps xmm5, [rsp+0x40]
0000747fd7fd8844  vmovaps xmm6, [rsp+0x50]
0000747fd7fd884a  vmovaps xmm7, [rsp+0x60]
0000747fd7fd8850  vmovaps xmm8, [rsp+0x70]
0000747fd7fd8856  vmovaps xmm9, [rsp+0x80]
0000747fd7fd885f  vmovaps xmm10, [rsp+0x90]
0000747fd7fd8868  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd8871  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd887a  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd8883  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd888c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd8895  add rsp, 0xF0
0000747fd7fd889c  pop r11
0000747fd7fd889e  pop r10
0000747fd7fd88a0  pop r9
0000747fd7fd88a2  pop r8
0000747fd7fd88a4  pop rsi
0000747fd7fd88a5  pop rdi
0000747fd7fd88a6  pop rdx
0000747fd7fd88a7  pop rcx
0000747fd7fd88a8  pop rax
0000747fd7fd88a9  add rsp, 0x08
0000747fd7fd88ad  jmp 0x0000747FD7FD60BF
0000747fd7fd88b2  call 0x0000747FD7ED64F0
0000747fd7fd88b7  jmp 0x0000747FD7FD60C9
0000747fd7fd88bc  sub rsp, 0x08
0000747fd7fd88c0  push rax
0000747fd7fd88c1  push rcx
0000747fd7fd88c2  push rdx
0000747fd7fd88c3  push rdi
0000747fd7fd88c4  push rsi
0000747fd7fd88c5  push r8
0000747fd7fd88c7  push r9
0000747fd7fd88c9  push r10
0000747fd7fd88cb  push r11
0000747fd7fd88cd  sub rsp, 0xF0
0000747fd7fd88d4  vmovaps [rsp], xmm0
0000747fd7fd88d9  vmovaps [rsp+0x10], xmm1
0000747fd7fd88df  vmovaps [rsp+0x20], xmm2
0000747fd7fd88e5  vmovaps [rsp+0x30], xmm3
0000747fd7fd88eb  vmovaps [rsp+0x40], xmm4
0000747fd7fd88f1  vmovaps [rsp+0x50], xmm5
0000747fd7fd88f7  vmovaps [rsp+0x60], xmm6
0000747fd7fd88fd  vmovaps [rsp+0x70], xmm7
0000747fd7fd8903  vmovaps [rsp+0x80], xmm8
0000747fd7fd890c  vmovaps [rsp+0x90], xmm9
0000747fd7fd8915  vmovaps [rsp+0xA0], xmm10
0000747fd7fd891e  vmovaps [rsp+0xB0], xmm11
0000747fd7fd8927  vmovaps [rsp+0xC0], xmm12
0000747fd7fd8930  vmovaps [rsp+0xD0], xmm13
0000747fd7fd8939  vmovaps [rsp+0xE0], xmm14
0000747fd7fd8942  sub rsp, 0x30
0000747fd7fd8946  movaps [rsp], xmm15
0000747fd7fd894b  movaps [rsp+0x10], xmm14
0000747fd7fd8951  movaps [rsp+0x20], xmm4
0000747fd7fd8956  lea rdi, [rsp]
0000747fd7fd895a  mov esi, 0x00
0000747fd7fd895f  mov rax, 0x6055A0B6E530
0000747fd7fd8969  call rax
0000747fd7fd896b  movaps xmm15, [rsp]
0000747fd7fd8970  add rsp, 0x30
0000747fd7fd8974  vmovaps xmm0, [rsp]
0000747fd7fd8979  vmovaps xmm1, [rsp+0x10]
0000747fd7fd897f  vmovaps xmm2, [rsp+0x20]
0000747fd7fd8985  vmovaps xmm3, [rsp+0x30]
0000747fd7fd898b  vmovaps xmm4, [rsp+0x40]
0000747fd7fd8991  vmovaps xmm5, [rsp+0x50]
0000747fd7fd8997  vmovaps xmm6, [rsp+0x60]
0000747fd7fd899d  vmovaps xmm7, [rsp+0x70]
0000747fd7fd89a3  vmovaps xmm8, [rsp+0x80]
0000747fd7fd89ac  vmovaps xmm9, [rsp+0x90]
0000747fd7fd89b5  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd89be  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd89c7  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd89d0  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd89d9  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd89e2  add rsp, 0xF0
0000747fd7fd89e9  pop r11
0000747fd7fd89eb  pop r10
0000747fd7fd89ed  pop r9
0000747fd7fd89ef  pop r8
0000747fd7fd89f1  pop rsi
0000747fd7fd89f2  pop rdi
0000747fd7fd89f3  pop rdx
0000747fd7fd89f4  pop rcx
0000747fd7fd89f5  pop rax
0000747fd7fd89f6  add rsp, 0x08
0000747fd7fd89fa  jmp 0x0000747FD7FD60F7
0000747fd7fd89ff  sub rsp, 0x08
0000747fd7fd8a03  push rax
0000747fd7fd8a04  push rcx
0000747fd7fd8a05  push rdx
0000747fd7fd8a06  push rdi
0000747fd7fd8a07  push rsi
0000747fd7fd8a08  push r8
0000747fd7fd8a0a  push r9
0000747fd7fd8a0c  push r10
0000747fd7fd8a0e  push r11
0000747fd7fd8a10  sub rsp, 0xF0
0000747fd7fd8a17  vmovaps [rsp], xmm0
0000747fd7fd8a1c  vmovaps [rsp+0x10], xmm1
0000747fd7fd8a22  vmovaps [rsp+0x20], xmm2
0000747fd7fd8a28  vmovaps [rsp+0x30], xmm3
0000747fd7fd8a2e  vmovaps [rsp+0x40], xmm4
0000747fd7fd8a34  vmovaps [rsp+0x50], xmm5
0000747fd7fd8a3a  vmovaps [rsp+0x60], xmm6
0000747fd7fd8a40  vmovaps [rsp+0x70], xmm7
0000747fd7fd8a46  vmovaps [rsp+0x80], xmm8
0000747fd7fd8a4f  vmovaps [rsp+0x90], xmm9
0000747fd7fd8a58  vmovaps [rsp+0xA0], xmm10
0000747fd7fd8a61  vmovaps [rsp+0xB0], xmm11
0000747fd7fd8a6a  vmovaps [rsp+0xC0], xmm12
0000747fd7fd8a73  vmovaps [rsp+0xD0], xmm13
0000747fd7fd8a7c  vmovaps [rsp+0xE0], xmm15
0000747fd7fd8a85  sub rsp, 0x30
0000747fd7fd8a89  movaps [rsp], xmm14
0000747fd7fd8a8e  movaps [rsp+0x10], xmm2
0000747fd7fd8a93  movaps [rsp+0x20], xmm1
0000747fd7fd8a98  lea rdi, [rsp]
0000747fd7fd8a9c  mov esi, 0x00
0000747fd7fd8aa1  mov rax, 0x6055A0B6E530
0000747fd7fd8aab  call rax
0000747fd7fd8aad  movaps xmm14, [rsp]
0000747fd7fd8ab2  add rsp, 0x30
0000747fd7fd8ab6  vmovaps xmm0, [rsp]
0000747fd7fd8abb  vmovaps xmm1, [rsp+0x10]
0000747fd7fd8ac1  vmovaps xmm2, [rsp+0x20]
0000747fd7fd8ac7  vmovaps xmm3, [rsp+0x30]
0000747fd7fd8acd  vmovaps xmm4, [rsp+0x40]
0000747fd7fd8ad3  vmovaps xmm5, [rsp+0x50]
0000747fd7fd8ad9  vmovaps xmm6, [rsp+0x60]
0000747fd7fd8adf  vmovaps xmm7, [rsp+0x70]
0000747fd7fd8ae5  vmovaps xmm8, [rsp+0x80]
0000747fd7fd8aee  vmovaps xmm9, [rsp+0x90]
0000747fd7fd8af7  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd8b00  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd8b09  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd8b12  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd8b1b  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd8b24  add rsp, 0xF0
0000747fd7fd8b2b  pop r11
0000747fd7fd8b2d  pop r10
0000747fd7fd8b2f  pop r9
0000747fd7fd8b31  pop r8
0000747fd7fd8b33  pop rsi
0000747fd7fd8b34  pop rdi
0000747fd7fd8b35  pop rdx
0000747fd7fd8b36  pop rcx
0000747fd7fd8b37  pop rax
0000747fd7fd8b38  add rsp, 0x08
0000747fd7fd8b3c  jmp 0x0000747FD7FD611D
0000747fd7fd8b41  sub rsp, 0x08
0000747fd7fd8b45  push rax
0000747fd7fd8b46  push rcx
0000747fd7fd8b47  push rdx
0000747fd7fd8b48  push rdi
0000747fd7fd8b49  push rsi
0000747fd7fd8b4a  push r8
0000747fd7fd8b4c  push r9
0000747fd7fd8b4e  push r10
0000747fd7fd8b50  push r11
0000747fd7fd8b52  sub rsp, 0xF0
0000747fd7fd8b59  vmovaps [rsp], xmm0
0000747fd7fd8b5e  vmovaps [rsp+0x10], xmm2
0000747fd7fd8b64  vmovaps [rsp+0x20], xmm3
0000747fd7fd8b6a  vmovaps [rsp+0x30], xmm4
0000747fd7fd8b70  vmovaps [rsp+0x40], xmm5
0000747fd7fd8b76  vmovaps [rsp+0x50], xmm6
0000747fd7fd8b7c  vmovaps [rsp+0x60], xmm7
0000747fd7fd8b82  vmovaps [rsp+0x70], xmm8
0000747fd7fd8b88  vmovaps [rsp+0x80], xmm9
0000747fd7fd8b91  vmovaps [rsp+0x90], xmm10
0000747fd7fd8b9a  vmovaps [rsp+0xA0], xmm11
0000747fd7fd8ba3  vmovaps [rsp+0xB0], xmm12
0000747fd7fd8bac  vmovaps [rsp+0xC0], xmm13
0000747fd7fd8bb5  vmovaps [rsp+0xD0], xmm14
0000747fd7fd8bbe  vmovaps [rsp+0xE0], xmm15
0000747fd7fd8bc7  sub rsp, 0x30
0000747fd7fd8bcb  movaps [rsp], xmm1
0000747fd7fd8bcf  movaps [rsp+0x10], xmm4
0000747fd7fd8bd4  movaps [rsp+0x20], xmm9
0000747fd7fd8bda  lea rdi, [rsp]
0000747fd7fd8bde  mov esi, 0x00
0000747fd7fd8be3  mov rax, 0x6055A0B6E530
0000747fd7fd8bed  call rax
0000747fd7fd8bef  movaps xmm1, [rsp]
0000747fd7fd8bf3  add rsp, 0x30
0000747fd7fd8bf7  vmovaps xmm0, [rsp]
0000747fd7fd8bfc  vmovaps xmm2, [rsp+0x10]
0000747fd7fd8c02  vmovaps xmm3, [rsp+0x20]
0000747fd7fd8c08  vmovaps xmm4, [rsp+0x30]
0000747fd7fd8c0e  vmovaps xmm5, [rsp+0x40]
0000747fd7fd8c14  vmovaps xmm6, [rsp+0x50]
0000747fd7fd8c1a  vmovaps xmm7, [rsp+0x60]
0000747fd7fd8c20  vmovaps xmm8, [rsp+0x70]
0000747fd7fd8c26  vmovaps xmm9, [rsp+0x80]
0000747fd7fd8c2f  vmovaps xmm10, [rsp+0x90]
0000747fd7fd8c38  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd8c41  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd8c4a  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd8c53  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd8c5c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd8c65  add rsp, 0xF0
0000747fd7fd8c6c  pop r11
0000747fd7fd8c6e  pop r10
0000747fd7fd8c70  pop r9
0000747fd7fd8c72  pop r8
0000747fd7fd8c74  pop rsi
0000747fd7fd8c75  pop rdi
0000747fd7fd8c76  pop rdx
0000747fd7fd8c77  pop rcx
0000747fd7fd8c78  pop rax
0000747fd7fd8c79  add rsp, 0x08
0000747fd7fd8c7d  jmp 0x0000747FD7FD613B
0000747fd7fd8c82  sub rsp, 0x08
0000747fd7fd8c86  push rax
0000747fd7fd8c87  push rcx
0000747fd7fd8c88  push rdx
0000747fd7fd8c89  push rdi
0000747fd7fd8c8a  push rsi
0000747fd7fd8c8b  push r8
0000747fd7fd8c8d  push r9
0000747fd7fd8c8f  push r10
0000747fd7fd8c91  push r11
0000747fd7fd8c93  sub rsp, 0xF0
0000747fd7fd8c9a  vmovaps [rsp], xmm0
0000747fd7fd8c9f  vmovaps [rsp+0x10], xmm1
0000747fd7fd8ca5  vmovaps [rsp+0x20], xmm2
0000747fd7fd8cab  vmovaps [rsp+0x30], xmm3
0000747fd7fd8cb1  vmovaps [rsp+0x40], xmm5
0000747fd7fd8cb7  vmovaps [rsp+0x50], xmm6
0000747fd7fd8cbd  vmovaps [rsp+0x60], xmm7
0000747fd7fd8cc3  vmovaps [rsp+0x70], xmm8
0000747fd7fd8cc9  vmovaps [rsp+0x80], xmm9
0000747fd7fd8cd2  vmovaps [rsp+0x90], xmm10
0000747fd7fd8cdb  vmovaps [rsp+0xA0], xmm11
0000747fd7fd8ce4  vmovaps [rsp+0xB0], xmm12
0000747fd7fd8ced  vmovaps [rsp+0xC0], xmm13
0000747fd7fd8cf6  vmovaps [rsp+0xD0], xmm14
0000747fd7fd8cff  vmovaps [rsp+0xE0], xmm15
0000747fd7fd8d08  sub rsp, 0x30
0000747fd7fd8d0c  movaps [rsp], xmm4
0000747fd7fd8d10  movaps [rsp+0x10], xmm2
0000747fd7fd8d15  movaps [rsp+0x20], xmm9
0000747fd7fd8d1b  lea rdi, [rsp]
0000747fd7fd8d1f  mov esi, 0x00
0000747fd7fd8d24  mov rax, 0x6055A0B6E530
0000747fd7fd8d2e  call rax
0000747fd7fd8d30  movaps xmm4, [rsp]
0000747fd7fd8d34  add rsp, 0x30
0000747fd7fd8d38  vmovaps xmm0, [rsp]
0000747fd7fd8d3d  vmovaps xmm1, [rsp+0x10]
0000747fd7fd8d43  vmovaps xmm2, [rsp+0x20]
0000747fd7fd8d49  vmovaps xmm3, [rsp+0x30]
0000747fd7fd8d4f  vmovaps xmm5, [rsp+0x40]
0000747fd7fd8d55  vmovaps xmm6, [rsp+0x50]
0000747fd7fd8d5b  vmovaps xmm7, [rsp+0x60]
0000747fd7fd8d61  vmovaps xmm8, [rsp+0x70]
0000747fd7fd8d67  vmovaps xmm9, [rsp+0x80]
0000747fd7fd8d70  vmovaps xmm10, [rsp+0x90]
0000747fd7fd8d79  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd8d82  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd8d8b  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd8d94  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd8d9d  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd8da6  add rsp, 0xF0
0000747fd7fd8dad  pop r11
0000747fd7fd8daf  pop r10
0000747fd7fd8db1  pop r9
0000747fd7fd8db3  pop r8
0000747fd7fd8db5  pop rsi
0000747fd7fd8db6  pop rdi
0000747fd7fd8db7  pop rdx
0000747fd7fd8db8  pop rcx
0000747fd7fd8db9  pop rax
0000747fd7fd8dba  add rsp, 0x08
0000747fd7fd8dbe  jmp 0x0000747FD7FD616B
0000747fd7fd8dc3  sub rsp, 0x08
0000747fd7fd8dc7  push rax
0000747fd7fd8dc8  push rcx
0000747fd7fd8dc9  push rdx
0000747fd7fd8dca  push rdi
0000747fd7fd8dcb  push rsi
0000747fd7fd8dcc  push r8
0000747fd7fd8dce  push r9
0000747fd7fd8dd0  push r10
0000747fd7fd8dd2  push r11
0000747fd7fd8dd4  sub rsp, 0xF0
0000747fd7fd8ddb  vmovaps [rsp], xmm0
0000747fd7fd8de0  vmovaps [rsp+0x10], xmm1
0000747fd7fd8de6  vmovaps [rsp+0x20], xmm2
0000747fd7fd8dec  vmovaps [rsp+0x30], xmm3
0000747fd7fd8df2  vmovaps [rsp+0x40], xmm4
0000747fd7fd8df8  vmovaps [rsp+0x50], xmm5
0000747fd7fd8dfe  vmovaps [rsp+0x60], xmm6
0000747fd7fd8e04  vmovaps [rsp+0x70], xmm7
0000747fd7fd8e0a  vmovaps [rsp+0x80], xmm8
0000747fd7fd8e13  vmovaps [rsp+0x90], xmm10
0000747fd7fd8e1c  vmovaps [rsp+0xA0], xmm11
0000747fd7fd8e25  vmovaps [rsp+0xB0], xmm12
0000747fd7fd8e2e  vmovaps [rsp+0xC0], xmm13
0000747fd7fd8e37  vmovaps [rsp+0xD0], xmm14
0000747fd7fd8e40  vmovaps [rsp+0xE0], xmm15
0000747fd7fd8e49  sub rsp, 0x30
0000747fd7fd8e4d  movaps [rsp], xmm9
0000747fd7fd8e52  movaps [rsp+0x10], xmm2
0000747fd7fd8e57  movaps [rsp+0x20], xmm1
0000747fd7fd8e5c  lea rdi, [rsp]
0000747fd7fd8e60  mov esi, 0x00
0000747fd7fd8e65  mov rax, 0x6055A0B6E530
0000747fd7fd8e6f  call rax
0000747fd7fd8e71  movaps xmm9, [rsp]
0000747fd7fd8e76  add rsp, 0x30
0000747fd7fd8e7a  vmovaps xmm0, [rsp]
0000747fd7fd8e7f  vmovaps xmm1, [rsp+0x10]
0000747fd7fd8e85  vmovaps xmm2, [rsp+0x20]
0000747fd7fd8e8b  vmovaps xmm3, [rsp+0x30]
0000747fd7fd8e91  vmovaps xmm4, [rsp+0x40]
0000747fd7fd8e97  vmovaps xmm5, [rsp+0x50]
0000747fd7fd8e9d  vmovaps xmm6, [rsp+0x60]
0000747fd7fd8ea3  vmovaps xmm7, [rsp+0x70]
0000747fd7fd8ea9  vmovaps xmm8, [rsp+0x80]
0000747fd7fd8eb2  vmovaps xmm10, [rsp+0x90]
0000747fd7fd8ebb  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd8ec4  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd8ecd  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd8ed6  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd8edf  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd8ee8  add rsp, 0xF0
0000747fd7fd8eef  pop r11
0000747fd7fd8ef1  pop r10
0000747fd7fd8ef3  pop r9
0000747fd7fd8ef5  pop r8
0000747fd7fd8ef7  pop rsi
0000747fd7fd8ef8  pop rdi
0000747fd7fd8ef9  pop rdx
0000747fd7fd8efa  pop rcx
0000747fd7fd8efb  pop rax
0000747fd7fd8efc  add rsp, 0x08
0000747fd7fd8f00  jmp 0x0000747FD7FD61A1
0000747fd7fd8f05  sub rsp, 0x08
0000747fd7fd8f09  push rax
0000747fd7fd8f0a  push rcx
0000747fd7fd8f0b  push rdx
0000747fd7fd8f0c  push rdi
0000747fd7fd8f0d  push rsi
0000747fd7fd8f0e  push r8
0000747fd7fd8f10  push r9
0000747fd7fd8f12  push r10
0000747fd7fd8f14  push r11
0000747fd7fd8f16  sub rsp, 0xF0
0000747fd7fd8f1d  vmovaps [rsp], xmm0
0000747fd7fd8f22  vmovaps [rsp+0x10], xmm2
0000747fd7fd8f28  vmovaps [rsp+0x20], xmm3
0000747fd7fd8f2e  vmovaps [rsp+0x30], xmm4
0000747fd7fd8f34  vmovaps [rsp+0x40], xmm5
0000747fd7fd8f3a  vmovaps [rsp+0x50], xmm6
0000747fd7fd8f40  vmovaps [rsp+0x60], xmm7
0000747fd7fd8f46  vmovaps [rsp+0x70], xmm8
0000747fd7fd8f4c  vmovaps [rsp+0x80], xmm9
0000747fd7fd8f55  vmovaps [rsp+0x90], xmm10
0000747fd7fd8f5e  vmovaps [rsp+0xA0], xmm11
0000747fd7fd8f67  vmovaps [rsp+0xB0], xmm12
0000747fd7fd8f70  vmovaps [rsp+0xC0], xmm13
0000747fd7fd8f79  vmovaps [rsp+0xD0], xmm14
0000747fd7fd8f82  vmovaps [rsp+0xE0], xmm15
0000747fd7fd8f8b  sub rsp, 0x30
0000747fd7fd8f8f  movaps [rsp], xmm1
0000747fd7fd8f93  movaps [rsp+0x10], xmm15
0000747fd7fd8f99  movaps [rsp+0x20], xmm6
0000747fd7fd8f9e  lea rdi, [rsp]
0000747fd7fd8fa2  mov esi, 0x00
0000747fd7fd8fa7  mov rax, 0x6055A0B6E530
0000747fd7fd8fb1  call rax
0000747fd7fd8fb3  movaps xmm1, [rsp]
0000747fd7fd8fb7  add rsp, 0x30
0000747fd7fd8fbb  vmovaps xmm0, [rsp]
0000747fd7fd8fc0  vmovaps xmm2, [rsp+0x10]
0000747fd7fd8fc6  vmovaps xmm3, [rsp+0x20]
0000747fd7fd8fcc  vmovaps xmm4, [rsp+0x30]
0000747fd7fd8fd2  vmovaps xmm5, [rsp+0x40]
0000747fd7fd8fd8  vmovaps xmm6, [rsp+0x50]
0000747fd7fd8fde  vmovaps xmm7, [rsp+0x60]
0000747fd7fd8fe4  vmovaps xmm8, [rsp+0x70]
0000747fd7fd8fea  vmovaps xmm9, [rsp+0x80]
0000747fd7fd8ff3  vmovaps xmm10, [rsp+0x90]
0000747fd7fd8ffc  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd9005  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd900e  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd9017  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd9020  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd9029  add rsp, 0xF0
0000747fd7fd9030  pop r11
0000747fd7fd9032  pop r10
0000747fd7fd9034  pop r9
0000747fd7fd9036  pop r8
0000747fd7fd9038  pop rsi
0000747fd7fd9039  pop rdi
0000747fd7fd903a  pop rdx
0000747fd7fd903b  pop rcx
0000747fd7fd903c  pop rax
0000747fd7fd903d  add rsp, 0x08
0000747fd7fd9041  jmp 0x0000747FD7FD61C2
0000747fd7fd9046  sub rsp, 0x08
0000747fd7fd904a  push rax
0000747fd7fd904b  push rcx
0000747fd7fd904c  push rdx
0000747fd7fd904d  push rdi
0000747fd7fd904e  push rsi
0000747fd7fd904f  push r8
0000747fd7fd9051  push r9
0000747fd7fd9053  push r10
0000747fd7fd9055  push r11
0000747fd7fd9057  sub rsp, 0xF0
0000747fd7fd905e  vmovaps [rsp], xmm0
0000747fd7fd9063  vmovaps [rsp+0x10], xmm1
0000747fd7fd9069  vmovaps [rsp+0x20], xmm2
0000747fd7fd906f  vmovaps [rsp+0x30], xmm3
0000747fd7fd9075  vmovaps [rsp+0x40], xmm4
0000747fd7fd907b  vmovaps [rsp+0x50], xmm5
0000747fd7fd9081  vmovaps [rsp+0x60], xmm6
0000747fd7fd9087  vmovaps [rsp+0x70], xmm7
0000747fd7fd908d  vmovaps [rsp+0x80], xmm8
0000747fd7fd9096  vmovaps [rsp+0x90], xmm9
0000747fd7fd909f  vmovaps [rsp+0xA0], xmm10
0000747fd7fd90a8  vmovaps [rsp+0xB0], xmm11
0000747fd7fd90b1  vmovaps [rsp+0xC0], xmm12
0000747fd7fd90ba  vmovaps [rsp+0xD0], xmm13
0000747fd7fd90c3  vmovaps [rsp+0xE0], xmm14
0000747fd7fd90cc  sub rsp, 0x30
0000747fd7fd90d0  movaps [rsp], xmm15
0000747fd7fd90d5  movaps [rsp+0x10], xmm5
0000747fd7fd90da  movaps [rsp+0x20], xmm3
0000747fd7fd90df  lea rdi, [rsp]
0000747fd7fd90e3  mov esi, 0x00
0000747fd7fd90e8  mov rax, 0x6055A0B6E530
0000747fd7fd90f2  call rax
0000747fd7fd90f4  movaps xmm15, [rsp]
0000747fd7fd90f9  add rsp, 0x30
0000747fd7fd90fd  vmovaps xmm0, [rsp]
0000747fd7fd9102  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9108  vmovaps xmm2, [rsp+0x20]
0000747fd7fd910e  vmovaps xmm3, [rsp+0x30]
0000747fd7fd9114  vmovaps xmm4, [rsp+0x40]
0000747fd7fd911a  vmovaps xmm5, [rsp+0x50]
0000747fd7fd9120  vmovaps xmm6, [rsp+0x60]
0000747fd7fd9126  vmovaps xmm7, [rsp+0x70]
0000747fd7fd912c  vmovaps xmm8, [rsp+0x80]
0000747fd7fd9135  vmovaps xmm9, [rsp+0x90]
0000747fd7fd913e  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd9147  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd9150  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd9159  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd9162  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd916b  add rsp, 0xF0
0000747fd7fd9172  pop r11
0000747fd7fd9174  pop r10
0000747fd7fd9176  pop r9
0000747fd7fd9178  pop r8
0000747fd7fd917a  pop rsi
0000747fd7fd917b  pop rdi
0000747fd7fd917c  pop rdx
0000747fd7fd917d  pop rcx
0000747fd7fd917e  pop rax
0000747fd7fd917f  add rsp, 0x08
0000747fd7fd9183  jmp 0x0000747FD7FD61DC
0000747fd7fd9188  sub rsp, 0x08
0000747fd7fd918c  push rax
0000747fd7fd918d  push rcx
0000747fd7fd918e  push rdx
0000747fd7fd918f  push rdi
0000747fd7fd9190  push rsi
0000747fd7fd9191  push r8
0000747fd7fd9193  push r9
0000747fd7fd9195  push r10
0000747fd7fd9197  push r11
0000747fd7fd9199  sub rsp, 0xF0
0000747fd7fd91a0  vmovaps [rsp], xmm0
0000747fd7fd91a5  vmovaps [rsp+0x10], xmm1
0000747fd7fd91ab  vmovaps [rsp+0x20], xmm2
0000747fd7fd91b1  vmovaps [rsp+0x30], xmm3
0000747fd7fd91b7  vmovaps [rsp+0x40], xmm4
0000747fd7fd91bd  vmovaps [rsp+0x50], xmm6
0000747fd7fd91c3  vmovaps [rsp+0x60], xmm7
0000747fd7fd91c9  vmovaps [rsp+0x70], xmm8
0000747fd7fd91cf  vmovaps [rsp+0x80], xmm9
0000747fd7fd91d8  vmovaps [rsp+0x90], xmm10
0000747fd7fd91e1  vmovaps [rsp+0xA0], xmm11
0000747fd7fd91ea  vmovaps [rsp+0xB0], xmm12
0000747fd7fd91f3  vmovaps [rsp+0xC0], xmm13
0000747fd7fd91fc  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9205  vmovaps [rsp+0xE0], xmm15
0000747fd7fd920e  sub rsp, 0x30
0000747fd7fd9212  movaps [rsp], xmm5
0000747fd7fd9216  movaps [rsp+0x10], xmm8
0000747fd7fd921c  movaps [rsp+0x20], xmm6
0000747fd7fd9221  lea rdi, [rsp]
0000747fd7fd9225  mov esi, 0x00
0000747fd7fd922a  mov rax, 0x6055A0B6E530
0000747fd7fd9234  call rax
0000747fd7fd9236  movaps xmm5, [rsp]
0000747fd7fd923a  add rsp, 0x30
0000747fd7fd923e  vmovaps xmm0, [rsp]
0000747fd7fd9243  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9249  vmovaps xmm2, [rsp+0x20]
0000747fd7fd924f  vmovaps xmm3, [rsp+0x30]
0000747fd7fd9255  vmovaps xmm4, [rsp+0x40]
0000747fd7fd925b  vmovaps xmm6, [rsp+0x50]
0000747fd7fd9261  vmovaps xmm7, [rsp+0x60]
0000747fd7fd9267  vmovaps xmm8, [rsp+0x70]
0000747fd7fd926d  vmovaps xmm9, [rsp+0x80]
0000747fd7fd9276  vmovaps xmm10, [rsp+0x90]
0000747fd7fd927f  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd9288  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd9291  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd929a  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd92a3  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd92ac  add rsp, 0xF0
0000747fd7fd92b3  pop r11
0000747fd7fd92b5  pop r10
0000747fd7fd92b7  pop r9
0000747fd7fd92b9  pop r8
0000747fd7fd92bb  pop rsi
0000747fd7fd92bc  pop rdi
0000747fd7fd92bd  pop rdx
0000747fd7fd92be  pop rcx
0000747fd7fd92bf  pop rax
0000747fd7fd92c0  add rsp, 0x08
0000747fd7fd92c4  jmp 0x0000747FD7FD6200
0000747fd7fd92c9  sub rsp, 0x08
0000747fd7fd92cd  push rax
0000747fd7fd92ce  push rcx
0000747fd7fd92cf  push rdx
0000747fd7fd92d0  push rdi
0000747fd7fd92d1  push rsi
0000747fd7fd92d2  push r8
0000747fd7fd92d4  push r9
0000747fd7fd92d6  push r10
0000747fd7fd92d8  push r11
0000747fd7fd92da  sub rsp, 0xF0
0000747fd7fd92e1  vmovaps [rsp], xmm0
0000747fd7fd92e6  vmovaps [rsp+0x10], xmm1
0000747fd7fd92ec  vmovaps [rsp+0x20], xmm2
0000747fd7fd92f2  vmovaps [rsp+0x30], xmm3
0000747fd7fd92f8  vmovaps [rsp+0x40], xmm4
0000747fd7fd92fe  vmovaps [rsp+0x50], xmm5
0000747fd7fd9304  vmovaps [rsp+0x60], xmm7
0000747fd7fd930a  vmovaps [rsp+0x70], xmm8
0000747fd7fd9310  vmovaps [rsp+0x80], xmm9
0000747fd7fd9319  vmovaps [rsp+0x90], xmm10
0000747fd7fd9322  vmovaps [rsp+0xA0], xmm11
0000747fd7fd932b  vmovaps [rsp+0xB0], xmm12
0000747fd7fd9334  vmovaps [rsp+0xC0], xmm13
0000747fd7fd933d  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9346  vmovaps [rsp+0xE0], xmm15
0000747fd7fd934f  sub rsp, 0x30
0000747fd7fd9353  movaps [rsp], xmm6
0000747fd7fd9357  movaps [rsp+0x10], xmm10
0000747fd7fd935d  movaps [rsp+0x20], xmm8
0000747fd7fd9363  lea rdi, [rsp]
0000747fd7fd9367  mov esi, 0x00
0000747fd7fd936c  mov rax, 0x6055A0B6E530
0000747fd7fd9376  call rax
0000747fd7fd9378  movaps xmm6, [rsp]
0000747fd7fd937c  add rsp, 0x30
0000747fd7fd9380  vmovaps xmm0, [rsp]
0000747fd7fd9385  vmovaps xmm1, [rsp+0x10]
0000747fd7fd938b  vmovaps xmm2, [rsp+0x20]
0000747fd7fd9391  vmovaps xmm3, [rsp+0x30]
0000747fd7fd9397  vmovaps xmm4, [rsp+0x40]
0000747fd7fd939d  vmovaps xmm5, [rsp+0x50]
0000747fd7fd93a3  vmovaps xmm7, [rsp+0x60]
0000747fd7fd93a9  vmovaps xmm8, [rsp+0x70]
0000747fd7fd93af  vmovaps xmm9, [rsp+0x80]
0000747fd7fd93b8  vmovaps xmm10, [rsp+0x90]
0000747fd7fd93c1  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd93ca  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd93d3  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd93dc  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd93e5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd93ee  add rsp, 0xF0
0000747fd7fd93f5  pop r11
0000747fd7fd93f7  pop r10
0000747fd7fd93f9  pop r9
0000747fd7fd93fb  pop r8
0000747fd7fd93fd  pop rsi
0000747fd7fd93fe  pop rdi
0000747fd7fd93ff  pop rdx
0000747fd7fd9400  pop rcx
0000747fd7fd9401  pop rax
0000747fd7fd9402  add rsp, 0x08
0000747fd7fd9406  jmp 0x0000747FD7FD6225
0000747fd7fd940b  sub rsp, 0x08
0000747fd7fd940f  push rax
0000747fd7fd9410  push rcx
0000747fd7fd9411  push rdx
0000747fd7fd9412  push rdi
0000747fd7fd9413  push rsi
0000747fd7fd9414  push r8
0000747fd7fd9416  push r9
0000747fd7fd9418  push r10
0000747fd7fd941a  push r11
0000747fd7fd941c  sub rsp, 0xF0
0000747fd7fd9423  vmovaps [rsp], xmm0
0000747fd7fd9428  vmovaps [rsp+0x10], xmm1
0000747fd7fd942e  vmovaps [rsp+0x20], xmm2
0000747fd7fd9434  vmovaps [rsp+0x30], xmm3
0000747fd7fd943a  vmovaps [rsp+0x40], xmm4
0000747fd7fd9440  vmovaps [rsp+0x50], xmm5
0000747fd7fd9446  vmovaps [rsp+0x60], xmm6
0000747fd7fd944c  vmovaps [rsp+0x70], xmm7
0000747fd7fd9452  vmovaps [rsp+0x80], xmm8
0000747fd7fd945b  vmovaps [rsp+0x90], xmm9
0000747fd7fd9464  vmovaps [rsp+0xA0], xmm11
0000747fd7fd946d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd9476  vmovaps [rsp+0xC0], xmm13
0000747fd7fd947f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9488  vmovaps [rsp+0xE0], xmm15
0000747fd7fd9491  sub rsp, 0x30
0000747fd7fd9495  movaps [rsp], xmm10
0000747fd7fd949a  movaps [rsp+0x10], xmm8
0000747fd7fd94a0  movaps [rsp+0x20], xmm14
0000747fd7fd94a6  lea rdi, [rsp]
0000747fd7fd94aa  mov esi, 0x00
0000747fd7fd94af  mov rax, 0x6055A0B6E530
0000747fd7fd94b9  call rax
0000747fd7fd94bb  movaps xmm10, [rsp]
0000747fd7fd94c0  add rsp, 0x30
0000747fd7fd94c4  vmovaps xmm0, [rsp]
0000747fd7fd94c9  vmovaps xmm1, [rsp+0x10]
0000747fd7fd94cf  vmovaps xmm2, [rsp+0x20]
0000747fd7fd94d5  vmovaps xmm3, [rsp+0x30]
0000747fd7fd94db  vmovaps xmm4, [rsp+0x40]
0000747fd7fd94e1  vmovaps xmm5, [rsp+0x50]
0000747fd7fd94e7  vmovaps xmm6, [rsp+0x60]
0000747fd7fd94ed  vmovaps xmm7, [rsp+0x70]
0000747fd7fd94f3  vmovaps xmm8, [rsp+0x80]
0000747fd7fd94fc  vmovaps xmm9, [rsp+0x90]
0000747fd7fd9505  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd950e  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd9517  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd9520  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd9529  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd9532  add rsp, 0xF0
0000747fd7fd9539  pop r11
0000747fd7fd953b  pop r10
0000747fd7fd953d  pop r9
0000747fd7fd953f  pop r8
0000747fd7fd9541  pop rsi
0000747fd7fd9542  pop rdi
0000747fd7fd9543  pop rdx
0000747fd7fd9544  pop rcx
0000747fd7fd9545  pop rax
0000747fd7fd9546  add rsp, 0x08
0000747fd7fd954a  jmp 0x0000747FD7FD6245
0000747fd7fd954f  sub rsp, 0x08
0000747fd7fd9553  push rax
0000747fd7fd9554  push rcx
0000747fd7fd9555  push rdx
0000747fd7fd9556  push rdi
0000747fd7fd9557  push rsi
0000747fd7fd9558  push r8
0000747fd7fd955a  push r9
0000747fd7fd955c  push r10
0000747fd7fd955e  push r11
0000747fd7fd9560  sub rsp, 0xF0
0000747fd7fd9567  vmovaps [rsp], xmm0
0000747fd7fd956c  vmovaps [rsp+0x10], xmm1
0000747fd7fd9572  vmovaps [rsp+0x20], xmm2
0000747fd7fd9578  vmovaps [rsp+0x30], xmm3
0000747fd7fd957e  vmovaps [rsp+0x40], xmm4
0000747fd7fd9584  vmovaps [rsp+0x50], xmm5
0000747fd7fd958a  vmovaps [rsp+0x60], xmm6
0000747fd7fd9590  vmovaps [rsp+0x70], xmm7
0000747fd7fd9596  vmovaps [rsp+0x80], xmm8
0000747fd7fd959f  vmovaps [rsp+0x90], xmm9
0000747fd7fd95a8  vmovaps [rsp+0xA0], xmm10
0000747fd7fd95b1  vmovaps [rsp+0xB0], xmm11
0000747fd7fd95ba  vmovaps [rsp+0xC0], xmm12
0000747fd7fd95c3  vmovaps [rsp+0xD0], xmm13
0000747fd7fd95cc  vmovaps [rsp+0xE0], xmm15
0000747fd7fd95d5  sub rsp, 0x30
0000747fd7fd95d9  movaps [rsp], xmm14
0000747fd7fd95de  movaps [rsp+0x10], xmm8
0000747fd7fd95e4  movaps [rsp+0x20], xmm4
0000747fd7fd95e9  lea rdi, [rsp]
0000747fd7fd95ed  mov esi, 0x00
0000747fd7fd95f2  mov rax, 0x6055A0B6E530
0000747fd7fd95fc  call rax
0000747fd7fd95fe  movaps xmm14, [rsp]
0000747fd7fd9603  add rsp, 0x30
0000747fd7fd9607  vmovaps xmm0, [rsp]
0000747fd7fd960c  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9612  vmovaps xmm2, [rsp+0x20]
0000747fd7fd9618  vmovaps xmm3, [rsp+0x30]
0000747fd7fd961e  vmovaps xmm4, [rsp+0x40]
0000747fd7fd9624  vmovaps xmm5, [rsp+0x50]
0000747fd7fd962a  vmovaps xmm6, [rsp+0x60]
0000747fd7fd9630  vmovaps xmm7, [rsp+0x70]
0000747fd7fd9636  vmovaps xmm8, [rsp+0x80]
0000747fd7fd963f  vmovaps xmm9, [rsp+0x90]
0000747fd7fd9648  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd9651  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd965a  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd9663  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd966c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd9675  add rsp, 0xF0
0000747fd7fd967c  pop r11
0000747fd7fd967e  pop r10
0000747fd7fd9680  pop r9
0000747fd7fd9682  pop r8
0000747fd7fd9684  pop rsi
0000747fd7fd9685  pop rdi
0000747fd7fd9686  pop rdx
0000747fd7fd9687  pop rcx
0000747fd7fd9688  pop rax
0000747fd7fd9689  add rsp, 0x08
0000747fd7fd968d  jmp 0x0000747FD7FD6265
0000747fd7fd9692  sub rsp, 0x08
0000747fd7fd9696  push rax
0000747fd7fd9697  push rcx
0000747fd7fd9698  push rdx
0000747fd7fd9699  push rdi
0000747fd7fd969a  push rsi
0000747fd7fd969b  push r8
0000747fd7fd969d  push r9
0000747fd7fd969f  push r10
0000747fd7fd96a1  push r11
0000747fd7fd96a3  sub rsp, 0xF0
0000747fd7fd96aa  vmovaps [rsp], xmm0
0000747fd7fd96af  vmovaps [rsp+0x10], xmm1
0000747fd7fd96b5  vmovaps [rsp+0x20], xmm2
0000747fd7fd96bb  vmovaps [rsp+0x30], xmm3
0000747fd7fd96c1  vmovaps [rsp+0x40], xmm5
0000747fd7fd96c7  vmovaps [rsp+0x50], xmm6
0000747fd7fd96cd  vmovaps [rsp+0x60], xmm7
0000747fd7fd96d3  vmovaps [rsp+0x70], xmm8
0000747fd7fd96d9  vmovaps [rsp+0x80], xmm9
0000747fd7fd96e2  vmovaps [rsp+0x90], xmm10
0000747fd7fd96eb  vmovaps [rsp+0xA0], xmm11
0000747fd7fd96f4  vmovaps [rsp+0xB0], xmm12
0000747fd7fd96fd  vmovaps [rsp+0xC0], xmm13
0000747fd7fd9706  vmovaps [rsp+0xD0], xmm14
0000747fd7fd970f  vmovaps [rsp+0xE0], xmm15
0000747fd7fd9718  sub rsp, 0x30
0000747fd7fd971c  movaps [rsp], xmm4
0000747fd7fd9720  movaps [rsp+0x10], xmm13
0000747fd7fd9726  movaps [rsp+0x20], xmm8
0000747fd7fd972c  lea rdi, [rsp]
0000747fd7fd9730  mov esi, 0x00
0000747fd7fd9735  mov rax, 0x6055A0B6E530
0000747fd7fd973f  call rax
0000747fd7fd9741  movaps xmm4, [rsp]
0000747fd7fd9745  add rsp, 0x30
0000747fd7fd9749  vmovaps xmm0, [rsp]
0000747fd7fd974e  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9754  vmovaps xmm2, [rsp+0x20]
0000747fd7fd975a  vmovaps xmm3, [rsp+0x30]
0000747fd7fd9760  vmovaps xmm5, [rsp+0x40]
0000747fd7fd9766  vmovaps xmm6, [rsp+0x50]
0000747fd7fd976c  vmovaps xmm7, [rsp+0x60]
0000747fd7fd9772  vmovaps xmm8, [rsp+0x70]
0000747fd7fd9778  vmovaps xmm9, [rsp+0x80]
0000747fd7fd9781  vmovaps xmm10, [rsp+0x90]
0000747fd7fd978a  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd9793  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd979c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd97a5  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd97ae  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd97b7  add rsp, 0xF0
0000747fd7fd97be  pop r11
0000747fd7fd97c0  pop r10
0000747fd7fd97c2  pop r9
0000747fd7fd97c4  pop r8
0000747fd7fd97c6  pop rsi
0000747fd7fd97c7  pop rdi
0000747fd7fd97c8  pop rdx
0000747fd7fd97c9  pop rcx
0000747fd7fd97ca  pop rax
0000747fd7fd97cb  add rsp, 0x08
0000747fd7fd97cf  jmp 0x0000747FD7FD628A
0000747fd7fd97d4  sub rsp, 0x08
0000747fd7fd97d8  push rax
0000747fd7fd97d9  push rcx
0000747fd7fd97da  push rdx
0000747fd7fd97db  push rdi
0000747fd7fd97dc  push rsi
0000747fd7fd97dd  push r8
0000747fd7fd97df  push r9
0000747fd7fd97e1  push r10
0000747fd7fd97e3  push r11
0000747fd7fd97e5  sub rsp, 0xF0
0000747fd7fd97ec  vmovaps [rsp], xmm0
0000747fd7fd97f1  vmovaps [rsp+0x10], xmm1
0000747fd7fd97f7  vmovaps [rsp+0x20], xmm2
0000747fd7fd97fd  vmovaps [rsp+0x30], xmm3
0000747fd7fd9803  vmovaps [rsp+0x40], xmm4
0000747fd7fd9809  vmovaps [rsp+0x50], xmm5
0000747fd7fd980f  vmovaps [rsp+0x60], xmm6
0000747fd7fd9815  vmovaps [rsp+0x70], xmm7
0000747fd7fd981b  vmovaps [rsp+0x80], xmm8
0000747fd7fd9824  vmovaps [rsp+0x90], xmm9
0000747fd7fd982d  vmovaps [rsp+0xA0], xmm10
0000747fd7fd9836  vmovaps [rsp+0xB0], xmm11
0000747fd7fd983f  vmovaps [rsp+0xC0], xmm12
0000747fd7fd9848  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9851  vmovaps [rsp+0xE0], xmm15
0000747fd7fd985a  sub rsp, 0x30
0000747fd7fd985e  movaps [rsp], xmm13
0000747fd7fd9863  movaps [rsp+0x10], xmm15
0000747fd7fd9869  movaps [rsp+0x20], xmm9
0000747fd7fd986f  lea rdi, [rsp]
0000747fd7fd9873  mov esi, 0x00
0000747fd7fd9878  mov rax, 0x6055A0B6E530
0000747fd7fd9882  call rax
0000747fd7fd9884  movaps xmm13, [rsp]
0000747fd7fd9889  add rsp, 0x30
0000747fd7fd988d  vmovaps xmm0, [rsp]
0000747fd7fd9892  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9898  vmovaps xmm2, [rsp+0x20]
0000747fd7fd989e  vmovaps xmm3, [rsp+0x30]
0000747fd7fd98a4  vmovaps xmm4, [rsp+0x40]
0000747fd7fd98aa  vmovaps xmm5, [rsp+0x50]
0000747fd7fd98b0  vmovaps xmm6, [rsp+0x60]
0000747fd7fd98b6  vmovaps xmm7, [rsp+0x70]
0000747fd7fd98bc  vmovaps xmm8, [rsp+0x80]
0000747fd7fd98c5  vmovaps xmm9, [rsp+0x90]
0000747fd7fd98ce  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd98d7  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd98e0  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd98e9  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd98f2  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd98fb  add rsp, 0xF0
0000747fd7fd9902  pop r11
0000747fd7fd9904  pop r10
0000747fd7fd9906  pop r9
0000747fd7fd9908  pop r8
0000747fd7fd990a  pop rsi
0000747fd7fd990b  pop rdi
0000747fd7fd990c  pop rdx
0000747fd7fd990d  pop rcx
0000747fd7fd990e  pop rax
0000747fd7fd990f  add rsp, 0x08
0000747fd7fd9913  jmp 0x0000747FD7FD62A5
0000747fd7fd9918  sub rsp, 0x08
0000747fd7fd991c  push rax
0000747fd7fd991d  push rcx
0000747fd7fd991e  push rdx
0000747fd7fd991f  push rdi
0000747fd7fd9920  push rsi
0000747fd7fd9921  push r8
0000747fd7fd9923  push r9
0000747fd7fd9925  push r10
0000747fd7fd9927  push r11
0000747fd7fd9929  sub rsp, 0xF0
0000747fd7fd9930  vmovaps [rsp], xmm0
0000747fd7fd9935  vmovaps [rsp+0x10], xmm1
0000747fd7fd993b  vmovaps [rsp+0x20], xmm2
0000747fd7fd9941  vmovaps [rsp+0x30], xmm3
0000747fd7fd9947  vmovaps [rsp+0x40], xmm4
0000747fd7fd994d  vmovaps [rsp+0x50], xmm5
0000747fd7fd9953  vmovaps [rsp+0x60], xmm6
0000747fd7fd9959  vmovaps [rsp+0x70], xmm7
0000747fd7fd995f  vmovaps [rsp+0x80], xmm8
0000747fd7fd9968  vmovaps [rsp+0x90], xmm9
0000747fd7fd9971  vmovaps [rsp+0xA0], xmm10
0000747fd7fd997a  vmovaps [rsp+0xB0], xmm11
0000747fd7fd9983  vmovaps [rsp+0xC0], xmm12
0000747fd7fd998c  vmovaps [rsp+0xD0], xmm13
0000747fd7fd9995  vmovaps [rsp+0xE0], xmm14
0000747fd7fd999e  sub rsp, 0x30
0000747fd7fd99a2  movaps [rsp], xmm15
0000747fd7fd99a7  movaps [rsp+0x10], xmm1
0000747fd7fd99ac  movaps [rsp+0x20], xmm5
0000747fd7fd99b1  lea rdi, [rsp]
0000747fd7fd99b5  mov esi, 0x00
0000747fd7fd99ba  mov rax, 0x6055A0B6E530
0000747fd7fd99c4  call rax
0000747fd7fd99c6  movaps xmm15, [rsp]
0000747fd7fd99cb  add rsp, 0x30
0000747fd7fd99cf  vmovaps xmm0, [rsp]
0000747fd7fd99d4  vmovaps xmm1, [rsp+0x10]
0000747fd7fd99da  vmovaps xmm2, [rsp+0x20]
0000747fd7fd99e0  vmovaps xmm3, [rsp+0x30]
0000747fd7fd99e6  vmovaps xmm4, [rsp+0x40]
0000747fd7fd99ec  vmovaps xmm5, [rsp+0x50]
0000747fd7fd99f2  vmovaps xmm6, [rsp+0x60]
0000747fd7fd99f8  vmovaps xmm7, [rsp+0x70]
0000747fd7fd99fe  vmovaps xmm8, [rsp+0x80]
0000747fd7fd9a07  vmovaps xmm9, [rsp+0x90]
0000747fd7fd9a10  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd9a19  vmovaps xmm11, [rsp+0xB0]
0000747fd7fd9a22  vmovaps xmm12, [rsp+0xC0]
0000747fd7fd9a2b  vmovaps xmm13, [rsp+0xD0]
0000747fd7fd9a34  vmovaps xmm14, [rsp+0xE0]
0000747fd7fd9a3d  add rsp, 0xF0
0000747fd7fd9a44  pop r11
0000747fd7fd9a46  pop r10
0000747fd7fd9a48  pop r9
0000747fd7fd9a4a  pop r8
0000747fd7fd9a4c  pop rsi
0000747fd7fd9a4d  pop rdi
0000747fd7fd9a4e  pop rdx
0000747fd7fd9a4f  pop rcx
0000747fd7fd9a50  pop rax
0000747fd7fd9a51  add rsp, 0x08
0000747fd7fd9a55  jmp 0x0000747FD7FD62C0
0000747fd7fd9a5a  call 0x0000747FD7ED64F0
0000747fd7fd9a5f  jmp 0x0000747FD7FD631B
0000747fd7fd9a64  sub rsp, 0x08
0000747fd7fd9a68  push rax
0000747fd7fd9a69  push rcx
0000747fd7fd9a6a  push rdx
0000747fd7fd9a6b  push rdi
0000747fd7fd9a6c  push rsi
0000747fd7fd9a6d  push r8
0000747fd7fd9a6f  push r9
0000747fd7fd9a71  push r10
0000747fd7fd9a73  push r11
0000747fd7fd9a75  sub rsp, 0xF0
0000747fd7fd9a7c  vmovaps [rsp], xmm0
0000747fd7fd9a81  vmovaps [rsp+0x10], xmm1
0000747fd7fd9a87  vmovaps [rsp+0x20], xmm2
0000747fd7fd9a8d  vmovaps [rsp+0x30], xmm3
0000747fd7fd9a93  vmovaps [rsp+0x40], xmm4
0000747fd7fd9a99  vmovaps [rsp+0x50], xmm5
0000747fd7fd9a9f  vmovaps [rsp+0x60], xmm6
0000747fd7fd9aa5  vmovaps [rsp+0x70], xmm7
0000747fd7fd9aab  vmovaps [rsp+0x80], xmm8
0000747fd7fd9ab4  vmovaps [rsp+0x90], xmm10
0000747fd7fd9abd  vmovaps [rsp+0xA0], xmm11
0000747fd7fd9ac6  vmovaps [rsp+0xB0], xmm12
0000747fd7fd9acf  vmovaps [rsp+0xC0], xmm13
0000747fd7fd9ad8  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9ae1  vmovaps [rsp+0xE0], xmm15
0000747fd7fd9aea  sub rsp, 0x30
0000747fd7fd9aee  movaps [rsp], xmm9
0000747fd7fd9af3  movaps [rsp+0x10], xmm8
0000747fd7fd9af9  movaps [rsp+0x20], xmm11
0000747fd7fd9aff  lea rdi, [rsp]
0000747fd7fd9b03  mov esi, 0x00
0000747fd7fd9b08  mov rax, 0x6055A0B6E530
0000747fd7fd9b12  call rax
0000747fd7fd9b14  movaps xmm9, [rsp]
0000747fd7fd9b19  add rsp, 0x30
0000747fd7fd9b1d  vmovaps xmm0, [rsp]
0000747fd7fd9b22  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9b28  vmovaps xmm2, [rsp+0x20]
0000747fd7fd9b2e  vmovaps xmm3, [rsp+0x30]
0000747fd7fd9b34  vmovaps xmm4, [rsp+0x40]
0000747fd7fd9b3a  vmovaps xmm5, [rsp+0x50]
0000747fd7fd9b40  vmovaps xmm6, [rsp+0x60]
0000747fd7fd9b46  vmovaps xmm7, [rsp+0x70]
0000747fd7fd9b4c  vmovaps xmm8, [rsp+0x80]
0000747fd7fd9b55  vmovaps xmm10, [rsp+0x90]
0000747fd7fd9b5e  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd9b67  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd9b70  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd9b79  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd9b82  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd9b8b  add rsp, 0xF0
0000747fd7fd9b92  pop r11
0000747fd7fd9b94  pop r10
0000747fd7fd9b96  pop r9
0000747fd7fd9b98  pop r8
0000747fd7fd9b9a  pop rsi
0000747fd7fd9b9b  pop rdi
0000747fd7fd9b9c  pop rdx
0000747fd7fd9b9d  pop rcx
0000747fd7fd9b9e  pop rax
0000747fd7fd9b9f  add rsp, 0x08
0000747fd7fd9ba3  jmp 0x0000747FD7FD6352
0000747fd7fd9ba8  sub rsp, 0x08
0000747fd7fd9bac  push rax
0000747fd7fd9bad  push rcx
0000747fd7fd9bae  push rdx
0000747fd7fd9baf  push rdi
0000747fd7fd9bb0  push rsi
0000747fd7fd9bb1  push r8
0000747fd7fd9bb3  push r9
0000747fd7fd9bb5  push r10
0000747fd7fd9bb7  push r11
0000747fd7fd9bb9  sub rsp, 0xF0
0000747fd7fd9bc0  vmovaps [rsp], xmm0
0000747fd7fd9bc5  vmovaps [rsp+0x10], xmm1
0000747fd7fd9bcb  vmovaps [rsp+0x20], xmm2
0000747fd7fd9bd1  vmovaps [rsp+0x30], xmm3
0000747fd7fd9bd7  vmovaps [rsp+0x40], xmm4
0000747fd7fd9bdd  vmovaps [rsp+0x50], xmm5
0000747fd7fd9be3  vmovaps [rsp+0x60], xmm6
0000747fd7fd9be9  vmovaps [rsp+0x70], xmm7
0000747fd7fd9bef  vmovaps [rsp+0x80], xmm8
0000747fd7fd9bf8  vmovaps [rsp+0x90], xmm9
0000747fd7fd9c01  vmovaps [rsp+0xA0], xmm10
0000747fd7fd9c0a  vmovaps [rsp+0xB0], xmm12
0000747fd7fd9c13  vmovaps [rsp+0xC0], xmm13
0000747fd7fd9c1c  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9c25  vmovaps [rsp+0xE0], xmm15
0000747fd7fd9c2e  sub rsp, 0x30
0000747fd7fd9c32  movaps [rsp], xmm11
0000747fd7fd9c37  movaps [rsp+0x10], xmm10
0000747fd7fd9c3d  movaps [rsp+0x20], xmm6
0000747fd7fd9c42  lea rdi, [rsp]
0000747fd7fd9c46  mov esi, 0x00
0000747fd7fd9c4b  mov rax, 0x6055A0B6E530
0000747fd7fd9c55  call rax
0000747fd7fd9c57  movaps xmm11, [rsp]
0000747fd7fd9c5c  add rsp, 0x30
0000747fd7fd9c60  vmovaps xmm0, [rsp]
0000747fd7fd9c65  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9c6b  vmovaps xmm2, [rsp+0x20]
0000747fd7fd9c71  vmovaps xmm3, [rsp+0x30]
0000747fd7fd9c77  vmovaps xmm4, [rsp+0x40]
0000747fd7fd9c7d  vmovaps xmm5, [rsp+0x50]
0000747fd7fd9c83  vmovaps xmm6, [rsp+0x60]
0000747fd7fd9c89  vmovaps xmm7, [rsp+0x70]
0000747fd7fd9c8f  vmovaps xmm8, [rsp+0x80]
0000747fd7fd9c98  vmovaps xmm9, [rsp+0x90]
0000747fd7fd9ca1  vmovaps xmm10, [rsp+0xA0]
0000747fd7fd9caa  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd9cb3  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd9cbc  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd9cc5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd9cce  add rsp, 0xF0
0000747fd7fd9cd5  pop r11
0000747fd7fd9cd7  pop r10
0000747fd7fd9cd9  pop r9
0000747fd7fd9cdb  pop r8
0000747fd7fd9cdd  pop rsi
0000747fd7fd9cde  pop rdi
0000747fd7fd9cdf  pop rdx
0000747fd7fd9ce0  pop rcx
0000747fd7fd9ce1  pop rax
0000747fd7fd9ce2  add rsp, 0x08
0000747fd7fd9ce6  jmp 0x0000747FD7FD636D
0000747fd7fd9ceb  sub rsp, 0x08
0000747fd7fd9cef  push rax
0000747fd7fd9cf0  push rcx
0000747fd7fd9cf1  push rdx
0000747fd7fd9cf2  push rdi
0000747fd7fd9cf3  push rsi
0000747fd7fd9cf4  push r8
0000747fd7fd9cf6  push r9
0000747fd7fd9cf8  push r10
0000747fd7fd9cfa  push r11
0000747fd7fd9cfc  sub rsp, 0xF0
0000747fd7fd9d03  vmovaps [rsp], xmm0
0000747fd7fd9d08  vmovaps [rsp+0x10], xmm1
0000747fd7fd9d0e  vmovaps [rsp+0x20], xmm2
0000747fd7fd9d14  vmovaps [rsp+0x30], xmm3
0000747fd7fd9d1a  vmovaps [rsp+0x40], xmm4
0000747fd7fd9d20  vmovaps [rsp+0x50], xmm5
0000747fd7fd9d26  vmovaps [rsp+0x60], xmm6
0000747fd7fd9d2c  vmovaps [rsp+0x70], xmm7
0000747fd7fd9d32  vmovaps [rsp+0x80], xmm8
0000747fd7fd9d3b  vmovaps [rsp+0x90], xmm9
0000747fd7fd9d44  vmovaps [rsp+0xA0], xmm11
0000747fd7fd9d4d  vmovaps [rsp+0xB0], xmm12
0000747fd7fd9d56  vmovaps [rsp+0xC0], xmm13
0000747fd7fd9d5f  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9d68  vmovaps [rsp+0xE0], xmm15
0000747fd7fd9d71  sub rsp, 0x30
0000747fd7fd9d75  movaps [rsp], xmm10
0000747fd7fd9d7a  movaps [rsp+0x10], xmm14
0000747fd7fd9d80  movaps [rsp+0x20], xmm4
0000747fd7fd9d85  lea rdi, [rsp]
0000747fd7fd9d89  mov esi, 0x00
0000747fd7fd9d8e  mov rax, 0x6055A0B6E530
0000747fd7fd9d98  call rax
0000747fd7fd9d9a  movaps xmm10, [rsp]
0000747fd7fd9d9f  add rsp, 0x30
0000747fd7fd9da3  vmovaps xmm0, [rsp]
0000747fd7fd9da8  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9dae  vmovaps xmm2, [rsp+0x20]
0000747fd7fd9db4  vmovaps xmm3, [rsp+0x30]
0000747fd7fd9dba  vmovaps xmm4, [rsp+0x40]
0000747fd7fd9dc0  vmovaps xmm5, [rsp+0x50]
0000747fd7fd9dc6  vmovaps xmm6, [rsp+0x60]
0000747fd7fd9dcc  vmovaps xmm7, [rsp+0x70]
0000747fd7fd9dd2  vmovaps xmm8, [rsp+0x80]
0000747fd7fd9ddb  vmovaps xmm9, [rsp+0x90]
0000747fd7fd9de4  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd9ded  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd9df6  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd9dff  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd9e08  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd9e11  add rsp, 0xF0
0000747fd7fd9e18  pop r11
0000747fd7fd9e1a  pop r10
0000747fd7fd9e1c  pop r9
0000747fd7fd9e1e  pop r8
0000747fd7fd9e20  pop rsi
0000747fd7fd9e21  pop rdi
0000747fd7fd9e22  pop rdx
0000747fd7fd9e23  pop rcx
0000747fd7fd9e24  pop rax
0000747fd7fd9e25  add rsp, 0x08
0000747fd7fd9e29  jmp 0x0000747FD7FD6388
0000747fd7fd9e2e  sub rsp, 0x08
0000747fd7fd9e32  push rax
0000747fd7fd9e33  push rcx
0000747fd7fd9e34  push rdx
0000747fd7fd9e35  push rdi
0000747fd7fd9e36  push rsi
0000747fd7fd9e37  push r8
0000747fd7fd9e39  push r9
0000747fd7fd9e3b  push r10
0000747fd7fd9e3d  push r11
0000747fd7fd9e3f  sub rsp, 0xF0
0000747fd7fd9e46  vmovaps [rsp], xmm0
0000747fd7fd9e4b  vmovaps [rsp+0x10], xmm1
0000747fd7fd9e51  vmovaps [rsp+0x20], xmm2
0000747fd7fd9e57  vmovaps [rsp+0x30], xmm3
0000747fd7fd9e5d  vmovaps [rsp+0x40], xmm4
0000747fd7fd9e63  vmovaps [rsp+0x50], xmm5
0000747fd7fd9e69  vmovaps [rsp+0x60], xmm6
0000747fd7fd9e6f  vmovaps [rsp+0x70], xmm7
0000747fd7fd9e75  vmovaps [rsp+0x80], xmm9
0000747fd7fd9e7e  vmovaps [rsp+0x90], xmm10
0000747fd7fd9e87  vmovaps [rsp+0xA0], xmm11
0000747fd7fd9e90  vmovaps [rsp+0xB0], xmm12
0000747fd7fd9e99  vmovaps [rsp+0xC0], xmm13
0000747fd7fd9ea2  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9eab  vmovaps [rsp+0xE0], xmm15
0000747fd7fd9eb4  sub rsp, 0x30
0000747fd7fd9eb8  movaps [rsp], xmm8
0000747fd7fd9ebd  movaps [rsp+0x10], xmm1
0000747fd7fd9ec2  movaps [rsp+0x20], xmm14
0000747fd7fd9ec8  lea rdi, [rsp]
0000747fd7fd9ecc  mov esi, 0x00
0000747fd7fd9ed1  mov rax, 0x6055A0B6E530
0000747fd7fd9edb  call rax
0000747fd7fd9edd  movaps xmm8, [rsp]
0000747fd7fd9ee2  add rsp, 0x30
0000747fd7fd9ee6  vmovaps xmm0, [rsp]
0000747fd7fd9eeb  vmovaps xmm1, [rsp+0x10]
0000747fd7fd9ef1  vmovaps xmm2, [rsp+0x20]
0000747fd7fd9ef7  vmovaps xmm3, [rsp+0x30]
0000747fd7fd9efd  vmovaps xmm4, [rsp+0x40]
0000747fd7fd9f03  vmovaps xmm5, [rsp+0x50]
0000747fd7fd9f09  vmovaps xmm6, [rsp+0x60]
0000747fd7fd9f0f  vmovaps xmm7, [rsp+0x70]
0000747fd7fd9f15  vmovaps xmm9, [rsp+0x80]
0000747fd7fd9f1e  vmovaps xmm10, [rsp+0x90]
0000747fd7fd9f27  vmovaps xmm11, [rsp+0xA0]
0000747fd7fd9f30  vmovaps xmm12, [rsp+0xB0]
0000747fd7fd9f39  vmovaps xmm13, [rsp+0xC0]
0000747fd7fd9f42  vmovaps xmm14, [rsp+0xD0]
0000747fd7fd9f4b  vmovaps xmm15, [rsp+0xE0]
0000747fd7fd9f54  add rsp, 0xF0
0000747fd7fd9f5b  pop r11
0000747fd7fd9f5d  pop r10
0000747fd7fd9f5f  pop r9
0000747fd7fd9f61  pop r8
0000747fd7fd9f63  pop rsi
0000747fd7fd9f64  pop rdi
0000747fd7fd9f65  pop rdx
0000747fd7fd9f66  pop rcx
0000747fd7fd9f67  pop rax
0000747fd7fd9f68  add rsp, 0x08
0000747fd7fd9f6c  jmp 0x0000747FD7FD63AE
0000747fd7fd9f71  sub rsp, 0x08
0000747fd7fd9f75  push rax
0000747fd7fd9f76  push rcx
0000747fd7fd9f77  push rdx
0000747fd7fd9f78  push rdi
0000747fd7fd9f79  push rsi
0000747fd7fd9f7a  push r8
0000747fd7fd9f7c  push r9
0000747fd7fd9f7e  push r10
0000747fd7fd9f80  push r11
0000747fd7fd9f82  sub rsp, 0xF0
0000747fd7fd9f89  vmovaps [rsp], xmm0
0000747fd7fd9f8e  vmovaps [rsp+0x10], xmm1
0000747fd7fd9f94  vmovaps [rsp+0x20], xmm2
0000747fd7fd9f9a  vmovaps [rsp+0x30], xmm3
0000747fd7fd9fa0  vmovaps [rsp+0x40], xmm4
0000747fd7fd9fa6  vmovaps [rsp+0x50], xmm5
0000747fd7fd9fac  vmovaps [rsp+0x60], xmm7
0000747fd7fd9fb2  vmovaps [rsp+0x70], xmm8
0000747fd7fd9fb8  vmovaps [rsp+0x80], xmm9
0000747fd7fd9fc1  vmovaps [rsp+0x90], xmm10
0000747fd7fd9fca  vmovaps [rsp+0xA0], xmm11
0000747fd7fd9fd3  vmovaps [rsp+0xB0], xmm12
0000747fd7fd9fdc  vmovaps [rsp+0xC0], xmm13
0000747fd7fd9fe5  vmovaps [rsp+0xD0], xmm14
0000747fd7fd9fee  vmovaps [rsp+0xE0], xmm15
0000747fd7fd9ff7  sub rsp, 0x30
0000747fd7fd9ffb  movaps [rsp], xmm6
0000747fd7fd9fff  movaps [rsp+0x10], xmm1
0000747fd7fda004  movaps [rsp+0x20], xmm14
0000747fd7fda00a  lea rdi, [rsp]
0000747fd7fda00e  mov esi, 0x00
0000747fd7fda013  mov rax, 0x6055A0B6E530
0000747fd7fda01d  call rax
0000747fd7fda01f  movaps xmm6, [rsp]
0000747fd7fda023  add rsp, 0x30
0000747fd7fda027  vmovaps xmm0, [rsp]
0000747fd7fda02c  vmovaps xmm1, [rsp+0x10]
0000747fd7fda032  vmovaps xmm2, [rsp+0x20]
0000747fd7fda038  vmovaps xmm3, [rsp+0x30]
0000747fd7fda03e  vmovaps xmm4, [rsp+0x40]
0000747fd7fda044  vmovaps xmm5, [rsp+0x50]
0000747fd7fda04a  vmovaps xmm7, [rsp+0x60]
0000747fd7fda050  vmovaps xmm8, [rsp+0x70]
0000747fd7fda056  vmovaps xmm9, [rsp+0x80]
0000747fd7fda05f  vmovaps xmm10, [rsp+0x90]
0000747fd7fda068  vmovaps xmm11, [rsp+0xA0]
0000747fd7fda071  vmovaps xmm12, [rsp+0xB0]
0000747fd7fda07a  vmovaps xmm13, [rsp+0xC0]
0000747fd7fda083  vmovaps xmm14, [rsp+0xD0]
0000747fd7fda08c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fda095  add rsp, 0xF0
0000747fd7fda09c  pop r11
0000747fd7fda09e  pop r10
0000747fd7fda0a0  pop r9
0000747fd7fda0a2  pop r8
0000747fd7fda0a4  pop rsi
0000747fd7fda0a5  pop rdi
0000747fd7fda0a6  pop rdx
0000747fd7fda0a7  pop rcx
0000747fd7fda0a8  pop rax
0000747fd7fda0a9  add rsp, 0x08
0000747fd7fda0ad  jmp 0x0000747FD7FD63DA
0000747fd7fda0b2  sub rsp, 0x08
0000747fd7fda0b6  push rax
0000747fd7fda0b7  push rcx
0000747fd7fda0b8  push rdx
0000747fd7fda0b9  push rdi
0000747fd7fda0ba  push rsi
0000747fd7fda0bb  push r8
0000747fd7fda0bd  push r9
0000747fd7fda0bf  push r10
0000747fd7fda0c1  push r11
0000747fd7fda0c3  sub rsp, 0xF0
0000747fd7fda0ca  vmovaps [rsp], xmm0
0000747fd7fda0cf  vmovaps [rsp+0x10], xmm1
0000747fd7fda0d5  vmovaps [rsp+0x20], xmm2
0000747fd7fda0db  vmovaps [rsp+0x30], xmm3
0000747fd7fda0e1  vmovaps [rsp+0x40], xmm4
0000747fd7fda0e7  vmovaps [rsp+0x50], xmm5
0000747fd7fda0ed  vmovaps [rsp+0x60], xmm6
0000747fd7fda0f3  vmovaps [rsp+0x70], xmm7
0000747fd7fda0f9  vmovaps [rsp+0x80], xmm8
0000747fd7fda102  vmovaps [rsp+0x90], xmm9
0000747fd7fda10b  vmovaps [rsp+0xA0], xmm10
0000747fd7fda114  vmovaps [rsp+0xB0], xmm11
0000747fd7fda11d  vmovaps [rsp+0xC0], xmm12
0000747fd7fda126  vmovaps [rsp+0xD0], xmm13
0000747fd7fda12f  vmovaps [rsp+0xE0], xmm15
0000747fd7fda138  sub rsp, 0x30
0000747fd7fda13c  movaps [rsp], xmm14
0000747fd7fda141  movaps [rsp+0x10], xmm12
0000747fd7fda147  movaps [rsp+0x20], xmm1
0000747fd7fda14c  lea rdi, [rsp]
0000747fd7fda150  mov esi, 0x00
0000747fd7fda155  mov rax, 0x6055A0B6E530
0000747fd7fda15f  call rax
0000747fd7fda161  movaps xmm14, [rsp]
0000747fd7fda166  add rsp, 0x30
0000747fd7fda16a  vmovaps xmm0, [rsp]
0000747fd7fda16f  vmovaps xmm1, [rsp+0x10]
0000747fd7fda175  vmovaps xmm2, [rsp+0x20]
0000747fd7fda17b  vmovaps xmm3, [rsp+0x30]
0000747fd7fda181  vmovaps xmm4, [rsp+0x40]
0000747fd7fda187  vmovaps xmm5, [rsp+0x50]
0000747fd7fda18d  vmovaps xmm6, [rsp+0x60]
0000747fd7fda193  vmovaps xmm7, [rsp+0x70]
0000747fd7fda199  vmovaps xmm8, [rsp+0x80]
0000747fd7fda1a2  vmovaps xmm9, [rsp+0x90]
0000747fd7fda1ab  vmovaps xmm10, [rsp+0xA0]
0000747fd7fda1b4  vmovaps xmm11, [rsp+0xB0]
0000747fd7fda1bd  vmovaps xmm12, [rsp+0xC0]
0000747fd7fda1c6  vmovaps xmm13, [rsp+0xD0]
0000747fd7fda1cf  vmovaps xmm15, [rsp+0xE0]
0000747fd7fda1d8  add rsp, 0xF0
0000747fd7fda1df  pop r11
0000747fd7fda1e1  pop r10
0000747fd7fda1e3  pop r9
0000747fd7fda1e5  pop r8
0000747fd7fda1e7  pop rsi
0000747fd7fda1e8  pop rdi
0000747fd7fda1e9  pop rdx
0000747fd7fda1ea  pop rcx
0000747fd7fda1eb  pop rax
0000747fd7fda1ec  add rsp, 0x08
0000747fd7fda1f0  jmp 0x0000747FD7FD6400
0000747fd7fda1f5  sub rsp, 0x08
0000747fd7fda1f9  push rax
0000747fd7fda1fa  push rcx
0000747fd7fda1fb  push rdx
0000747fd7fda1fc  push rdi
0000747fd7fda1fd  push rsi
0000747fd7fda1fe  push r8
0000747fd7fda200  push r9
0000747fd7fda202  push r10
0000747fd7fda204  push r11
0000747fd7fda206  sub rsp, 0xF0
0000747fd7fda20d  vmovaps [rsp], xmm0
0000747fd7fda212  vmovaps [rsp+0x10], xmm2
0000747fd7fda218  vmovaps [rsp+0x20], xmm3
0000747fd7fda21e  vmovaps [rsp+0x30], xmm4
0000747fd7fda224  vmovaps [rsp+0x40], xmm5
0000747fd7fda22a  vmovaps [rsp+0x50], xmm6
0000747fd7fda230  vmovaps [rsp+0x60], xmm7
0000747fd7fda236  vmovaps [rsp+0x70], xmm8
0000747fd7fda23c  vmovaps [rsp+0x80], xmm9
0000747fd7fda245  vmovaps [rsp+0x90], xmm10
0000747fd7fda24e  vmovaps [rsp+0xA0], xmm11
0000747fd7fda257  vmovaps [rsp+0xB0], xmm12
0000747fd7fda260  vmovaps [rsp+0xC0], xmm13
0000747fd7fda269  vmovaps [rsp+0xD0], xmm14
0000747fd7fda272  vmovaps [rsp+0xE0], xmm15
0000747fd7fda27b  sub rsp, 0x30
0000747fd7fda27f  movaps [rsp], xmm1
0000747fd7fda283  movaps [rsp+0x10], xmm13
0000747fd7fda289  movaps [rsp+0x20], xmm9
0000747fd7fda28f  lea rdi, [rsp]
0000747fd7fda293  mov esi, 0x00
0000747fd7fda298  mov rax, 0x6055A0B6E530
0000747fd7fda2a2  call rax
0000747fd7fda2a4  movaps xmm1, [rsp]
0000747fd7fda2a8  add rsp, 0x30
0000747fd7fda2ac  vmovaps xmm0, [rsp]
0000747fd7fda2b1  vmovaps xmm2, [rsp+0x10]
0000747fd7fda2b7  vmovaps xmm3, [rsp+0x20]
0000747fd7fda2bd  vmovaps xmm4, [rsp+0x30]
0000747fd7fda2c3  vmovaps xmm5, [rsp+0x40]
0000747fd7fda2c9  vmovaps xmm6, [rsp+0x50]
0000747fd7fda2cf  vmovaps xmm7, [rsp+0x60]
0000747fd7fda2d5  vmovaps xmm8, [rsp+0x70]
0000747fd7fda2db  vmovaps xmm9, [rsp+0x80]
0000747fd7fda2e4  vmovaps xmm10, [rsp+0x90]
0000747fd7fda2ed  vmovaps xmm11, [rsp+0xA0]
0000747fd7fda2f6  vmovaps xmm12, [rsp+0xB0]
0000747fd7fda2ff  vmovaps xmm13, [rsp+0xC0]
0000747fd7fda308  vmovaps xmm14, [rsp+0xD0]
0000747fd7fda311  vmovaps xmm15, [rsp+0xE0]
0000747fd7fda31a  add rsp, 0xF0
0000747fd7fda321  pop r11
0000747fd7fda323  pop r10
0000747fd7fda325  pop r9
0000747fd7fda327  pop r8
0000747fd7fda329  pop rsi
0000747fd7fda32a  pop rdi
0000747fd7fda32b  pop rdx
0000747fd7fda32c  pop rcx
0000747fd7fda32d  pop rax
0000747fd7fda32e  add rsp, 0x08
0000747fd7fda332  jmp 0x0000747FD7FD641A
0000747fd7fda337  sub rsp, 0x08
0000747fd7fda33b  push rax
0000747fd7fda33c  push rcx
0000747fd7fda33d  push rdx
0000747fd7fda33e  push rdi
0000747fd7fda33f  push rsi
0000747fd7fda340  push r8
0000747fd7fda342  push r9
0000747fd7fda344  push r10
0000747fd7fda346  push r11
0000747fd7fda348  sub rsp, 0xF0
0000747fd7fda34f  vmovaps [rsp], xmm0
0000747fd7fda354  vmovaps [rsp+0x10], xmm1
0000747fd7fda35a  vmovaps [rsp+0x20], xmm2
0000747fd7fda360  vmovaps [rsp+0x30], xmm3
0000747fd7fda366  vmovaps [rsp+0x40], xmm4
0000747fd7fda36c  vmovaps [rsp+0x50], xmm5
0000747fd7fda372  vmovaps [rsp+0x60], xmm6
0000747fd7fda378  vmovaps [rsp+0x70], xmm7
0000747fd7fda37e  vmovaps [rsp+0x80], xmm8
0000747fd7fda387  vmovaps [rsp+0x90], xmm9
0000747fd7fda390  vmovaps [rsp+0xA0], xmm10
0000747fd7fda399  vmovaps [rsp+0xB0], xmm11
0000747fd7fda3a2  vmovaps [rsp+0xC0], xmm13
0000747fd7fda3ab  vmovaps [rsp+0xD0], xmm14
0000747fd7fda3b4  vmovaps [rsp+0xE0], xmm15
0000747fd7fda3bd  sub rsp, 0x30
0000747fd7fda3c1  movaps [rsp], xmm12
0000747fd7fda3c6  movaps [rsp+0x10], xmm7
0000747fd7fda3cb  movaps [rsp+0x20], xmm13
0000747fd7fda3d1  lea rdi, [rsp]
0000747fd7fda3d5  mov esi, 0x00
0000747fd7fda3da  mov rax, 0x6055A0B6E530
0000747fd7fda3e4  call rax
0000747fd7fda3e6  movaps xmm12, [rsp]
0000747fd7fda3eb  add rsp, 0x30
0000747fd7fda3ef  vmovaps xmm0, [rsp]
0000747fd7fda3f4  vmovaps xmm1, [rsp+0x10]
0000747fd7fda3fa  vmovaps xmm2, [rsp+0x20]
0000747fd7fda400  vmovaps xmm3, [rsp+0x30]
0000747fd7fda406  vmovaps xmm4, [rsp+0x40]
0000747fd7fda40c  vmovaps xmm5, [rsp+0x50]
0000747fd7fda412  vmovaps xmm6, [rsp+0x60]
0000747fd7fda418  vmovaps xmm7, [rsp+0x70]
0000747fd7fda41e  vmovaps xmm8, [rsp+0x80]
0000747fd7fda427  vmovaps xmm9, [rsp+0x90]
0000747fd7fda430  vmovaps xmm10, [rsp+0xA0]
0000747fd7fda439  vmovaps xmm11, [rsp+0xB0]
0000747fd7fda442  vmovaps xmm13, [rsp+0xC0]
0000747fd7fda44b  vmovaps xmm14, [rsp+0xD0]
0000747fd7fda454  vmovaps xmm15, [rsp+0xE0]
0000747fd7fda45d  add rsp, 0xF0
0000747fd7fda464  pop r11
0000747fd7fda466  pop r10
0000747fd7fda468  pop r9
0000747fd7fda46a  pop r8
0000747fd7fda46c  pop rsi
0000747fd7fda46d  pop rdi
0000747fd7fda46e  pop rdx
0000747fd7fda46f  pop rcx
0000747fd7fda470  pop rax
0000747fd7fda471  add rsp, 0x08
0000747fd7fda475  jmp 0x0000747FD7FD6441
0000747fd7fda47a  sub rsp, 0x08
0000747fd7fda47e  push rax
0000747fd7fda47f  push rcx
0000747fd7fda480  push rdx
0000747fd7fda481  push rdi
0000747fd7fda482  push rsi
0000747fd7fda483  push r8
0000747fd7fda485  push r9
0000747fd7fda487  push r10
0000747fd7fda489  push r11
0000747fd7fda48b  sub rsp, 0xF0
0000747fd7fda492  vmovaps [rsp], xmm0
0000747fd7fda497  vmovaps [rsp+0x10], xmm1
0000747fd7fda49d  vmovaps [rsp+0x20], xmm2
0000747fd7fda4a3  vmovaps [rsp+0x30], xmm3
0000747fd7fda4a9  vmovaps [rsp+0x40], xmm4
0000747fd7fda4af  vmovaps [rsp+0x50], xmm5
0000747fd7fda4b5  vmovaps [rsp+0x60], xmm6
0000747fd7fda4bb  vmovaps [rsp+0x70], xmm7
0000747fd7fda4c1  vmovaps [rsp+0x80], xmm8
0000747fd7fda4ca  vmovaps [rsp+0x90], xmm9
0000747fd7fda4d3  vmovaps [rsp+0xA0], xmm10
0000747fd7fda4dc  vmovaps [rsp+0xB0], xmm11
0000747fd7fda4e5  vmovaps [rsp+0xC0], xmm12
0000747fd7fda4ee  vmovaps [rsp+0xD0], xmm14
0000747fd7fda4f7  vmovaps [rsp+0xE0], xmm15
0000747fd7fda500  sub rsp, 0x30
0000747fd7fda504  movaps [rsp], xmm13
0000747fd7fda509  movaps [rsp+0x10], xmm15
0000747fd7fda50f  movaps [rsp+0x20], xmm8
0000747fd7fda515  lea rdi, [rsp]
0000747fd7fda519  mov esi, 0x00
0000747fd7fda51e  mov rax, 0x6055A0B6E530
0000747fd7fda528  call rax
0000747fd7fda52a  movaps xmm13, [rsp]
0000747fd7fda52f  add rsp, 0x30
0000747fd7fda533  vmovaps xmm0, [rsp]
0000747fd7fda538  vmovaps xmm1, [rsp+0x10]
0000747fd7fda53e  vmovaps xmm2, [rsp+0x20]
0000747fd7fda544  vmovaps xmm3, [rsp+0x30]
0000747fd7fda54a  vmovaps xmm4, [rsp+0x40]
0000747fd7fda550  vmovaps xmm5, [rsp+0x50]
0000747fd7fda556  vmovaps xmm6, [rsp+0x60]
0000747fd7fda55c  vmovaps xmm7, [rsp+0x70]
0000747fd7fda562  vmovaps xmm8, [rsp+0x80]
0000747fd7fda56b  vmovaps xmm9, [rsp+0x90]
0000747fd7fda574  vmovaps xmm10, [rsp+0xA0]
0000747fd7fda57d  vmovaps xmm11, [rsp+0xB0]
0000747fd7fda586  vmovaps xmm12, [rsp+0xC0]
0000747fd7fda58f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fda598  vmovaps xmm15, [rsp+0xE0]
0000747fd7fda5a1  add rsp, 0xF0
0000747fd7fda5a8  pop r11
0000747fd7fda5aa  pop r10
0000747fd7fda5ac  pop r9
0000747fd7fda5ae  pop r8
0000747fd7fda5b0  pop rsi
0000747fd7fda5b1  pop rdi
0000747fd7fda5b2  pop rdx
0000747fd7fda5b3  pop rcx
0000747fd7fda5b4  pop rax
0000747fd7fda5b5  add rsp, 0x08
0000747fd7fda5b9  jmp 0x0000747FD7FD645C
0000747fd7fda5be  sub rsp, 0x08
0000747fd7fda5c2  push rax
0000747fd7fda5c3  push rcx
0000747fd7fda5c4  push rdx
0000747fd7fda5c5  push rdi
0000747fd7fda5c6  push rsi
0000747fd7fda5c7  push r8
0000747fd7fda5c9  push r9
0000747fd7fda5cb  push r10
0000747fd7fda5cd  push r11
0000747fd7fda5cf  sub rsp, 0xF0
0000747fd7fda5d6  vmovaps [rsp], xmm0
0000747fd7fda5db  vmovaps [rsp+0x10], xmm1
0000747fd7fda5e1  vmovaps [rsp+0x20], xmm2
0000747fd7fda5e7  vmovaps [rsp+0x30], xmm3
0000747fd7fda5ed  vmovaps [rsp+0x40], xmm4
0000747fd7fda5f3  vmovaps [rsp+0x50], xmm5
0000747fd7fda5f9  vmovaps [rsp+0x60], xmm6
0000747fd7fda5ff  vmovaps [rsp+0x70], xmm7
0000747fd7fda605  vmovaps [rsp+0x80], xmm9
0000747fd7fda60e  vmovaps [rsp+0x90], xmm10
0000747fd7fda617  vmovaps [rsp+0xA0], xmm11
0000747fd7fda620  vmovaps [rsp+0xB0], xmm12
0000747fd7fda629  vmovaps [rsp+0xC0], xmm13
0000747fd7fda632  vmovaps [rsp+0xD0], xmm14
0000747fd7fda63b  vmovaps [rsp+0xE0], xmm15
0000747fd7fda644  sub rsp, 0x30
0000747fd7fda648  movaps [rsp], xmm8
0000747fd7fda64d  movaps [rsp+0x10], xmm15
0000747fd7fda653  movaps [rsp+0x20], xmm9
0000747fd7fda659  lea rdi, [rsp]
0000747fd7fda65d  mov esi, 0x00
0000747fd7fda662  mov rax, 0x6055A0B6E530
0000747fd7fda66c  call rax
0000747fd7fda66e  movaps xmm8, [rsp]
0000747fd7fda673  add rsp, 0x30
0000747fd7fda677  vmovaps xmm0, [rsp]
0000747fd7fda67c  vmovaps xmm1, [rsp+0x10]
0000747fd7fda682  vmovaps xmm2, [rsp+0x20]
0000747fd7fda688  vmovaps xmm3, [rsp+0x30]
0000747fd7fda68e  vmovaps xmm4, [rsp+0x40]
0000747fd7fda694  vmovaps xmm5, [rsp+0x50]
0000747fd7fda69a  vmovaps xmm6, [rsp+0x60]
0000747fd7fda6a0  vmovaps xmm7, [rsp+0x70]
0000747fd7fda6a6  vmovaps xmm9, [rsp+0x80]
0000747fd7fda6af  vmovaps xmm10, [rsp+0x90]
0000747fd7fda6b8  vmovaps xmm11, [rsp+0xA0]
0000747fd7fda6c1  vmovaps xmm12, [rsp+0xB0]
0000747fd7fda6ca  vmovaps xmm13, [rsp+0xC0]
0000747fd7fda6d3  vmovaps xmm14, [rsp+0xD0]
0000747fd7fda6dc  vmovaps xmm15, [rsp+0xE0]
0000747fd7fda6e5  add rsp, 0xF0
0000747fd7fda6ec  pop r11
0000747fd7fda6ee  pop r10
0000747fd7fda6f0  pop r9
0000747fd7fda6f2  pop r8
0000747fd7fda6f4  pop rsi
0000747fd7fda6f5  pop rdi
0000747fd7fda6f6  pop rdx
0000747fd7fda6f7  pop rcx
0000747fd7fda6f8  pop rax
0000747fd7fda6f9  add rsp, 0x08
0000747fd7fda6fd  jmp 0x0000747FD7FD648A
0000747fd7fda702  sub rsp, 0x08
0000747fd7fda706  push rax
0000747fd7fda707  push rcx
0000747fd7fda708  push rdx
0000747fd7fda709  push rdi
0000747fd7fda70a  push rsi
0000747fd7fda70b  push r8
0000747fd7fda70d  push r9
0000747fd7fda70f  push r10
0000747fd7fda711  push r11
0000747fd7fda713  sub rsp, 0xF0
0000747fd7fda71a  vmovaps [rsp], xmm0
0000747fd7fda71f  vmovaps [rsp+0x10], xmm1
0000747fd7fda725  vmovaps [rsp+0x20], xmm2
0000747fd7fda72b  vmovaps [rsp+0x30], xmm3
0000747fd7fda731  vmovaps [rsp+0x40], xmm4
0000747fd7fda737  vmovaps [rsp+0x50], xmm5
0000747fd7fda73d  vmovaps [rsp+0x60], xmm6
0000747fd7fda743  vmovaps [rsp+0x70], xmm7
0000747fd7fda749  vmovaps [rsp+0x80], xmm8
0000747fd7fda752  vmovaps [rsp+0x90], xmm9
0000747fd7fda75b  vmovaps [rsp+0xA0], xmm10
0000747fd7fda764  vmovaps [rsp+0xB0], xmm11
0000747fd7fda76d  vmovaps [rsp+0xC0], xmm12
0000747fd7fda776  vmovaps [rsp+0xD0], xmm13
0000747fd7fda77f  vmovaps [rsp+0xE0], xmm14
0000747fd7fda788  sub rsp, 0x30
0000747fd7fda78c  movaps [rsp], xmm15
0000747fd7fda791  movaps [rsp+0x10], xmm11
0000747fd7fda797  movaps [rsp+0x20], xmm6
0000747fd7fda79c  lea rdi, [rsp]
0000747fd7fda7a0  mov esi, 0x00
0000747fd7fda7a5  mov rax, 0x6055A0B6E530
0000747fd7fda7af  call rax
0000747fd7fda7b1  movaps xmm15, [rsp]
0000747fd7fda7b6  add rsp, 0x30
0000747fd7fda7ba  vmovaps xmm0, [rsp]
0000747fd7fda7bf  vmovaps xmm1, [rsp+0x10]
0000747fd7fda7c5  vmovaps xmm2, [rsp+0x20]
0000747fd7fda7cb  vmovaps xmm3, [rsp+0x30]
0000747fd7fda7d1  vmovaps xmm4, [rsp+0x40]
0000747fd7fda7d7  vmovaps xmm5, [rsp+0x50]
0000747fd7fda7dd  vmovaps xmm6, [rsp+0x60]
0000747fd7fda7e3  vmovaps xmm7, [rsp+0x70]
0000747fd7fda7e9  vmovaps xmm8, [rsp+0x80]
0000747fd7fda7f2  vmovaps xmm9, [rsp+0x90]
0000747fd7fda7fb  vmovaps xmm10, [rsp+0xA0]
0000747fd7fda804  vmovaps xmm11, [rsp+0xB0]
0000747fd7fda80d  vmovaps xmm12, [rsp+0xC0]
0000747fd7fda816  vmovaps xmm13, [rsp+0xD0]
0000747fd7fda81f  vmovaps xmm14, [rsp+0xE0]
0000747fd7fda828  add rsp, 0xF0
0000747fd7fda82f  pop r11
0000747fd7fda831  pop r10
0000747fd7fda833  pop r9
0000747fd7fda835  pop r8
0000747fd7fda837  pop rsi
0000747fd7fda838  pop rdi
0000747fd7fda839  pop rdx
0000747fd7fda83a  pop rcx
0000747fd7fda83b  pop rax
0000747fd7fda83c  add rsp, 0x08
0000747fd7fda840  jmp 0x0000747FD7FD64A5
0000747fd7fda845  sub rsp, 0x08
0000747fd7fda849  push rax
0000747fd7fda84a  push rcx
0000747fd7fda84b  push rdx
0000747fd7fda84c  push rdi
0000747fd7fda84d  push rsi
0000747fd7fda84e  push r8
0000747fd7fda850  push r9
0000747fd7fda852  push r10
0000747fd7fda854  push r11
0000747fd7fda856  sub rsp, 0xF0
0000747fd7fda85d  vmovaps [rsp], xmm0
0000747fd7fda862  vmovaps [rsp+0x10], xmm1
0000747fd7fda868  vmovaps [rsp+0x20], xmm2
0000747fd7fda86e  vmovaps [rsp+0x30], xmm3
0000747fd7fda874  vmovaps [rsp+0x40], xmm4
0000747fd7fda87a  vmovaps [rsp+0x50], xmm5
0000747fd7fda880  vmovaps [rsp+0x60], xmm6
0000747fd7fda886  vmovaps [rsp+0x70], xmm8
0000747fd7fda88c  vmovaps [rsp+0x80], xmm9
0000747fd7fda895  vmovaps [rsp+0x90], xmm10
0000747fd7fda89e  vmovaps [rsp+0xA0], xmm11
0000747fd7fda8a7  vmovaps [rsp+0xB0], xmm12
0000747fd7fda8b0  vmovaps [rsp+0xC0], xmm13
0000747fd7fda8b9  vmovaps [rsp+0xD0], xmm14
0000747fd7fda8c2  vmovaps [rsp+0xE0], xmm15
0000747fd7fda8cb  sub rsp, 0x30
0000747fd7fda8cf  movaps [rsp], xmm7
0000747fd7fda8d3  movaps [rsp+0x10], xmm11
0000747fd7fda8d9  movaps [rsp+0x20], xmm9
0000747fd7fda8df  lea rdi, [rsp]
0000747fd7fda8e3  mov esi, 0x00
0000747fd7fda8e8  mov rax, 0x6055A0B6E530
0000747fd7fda8f2  call rax
0000747fd7fda8f4  movaps xmm7, [rsp]
0000747fd7fda8f8  add rsp, 0x30
0000747fd7fda8fc  vmovaps xmm0, [rsp]
0000747fd7fda901  vmovaps xmm1, [rsp+0x10]
0000747fd7fda907  vmovaps xmm2, [rsp+0x20]
0000747fd7fda90d  vmovaps xmm3, [rsp+0x30]
0000747fd7fda913  vmovaps xmm4, [rsp+0x40]
0000747fd7fda919  vmovaps xmm5, [rsp+0x50]
0000747fd7fda91f  vmovaps xmm6, [rsp+0x60]
0000747fd7fda925  vmovaps xmm8, [rsp+0x70]
0000747fd7fda92b  vmovaps xmm9, [rsp+0x80]
0000747fd7fda934  vmovaps xmm10, [rsp+0x90]
0000747fd7fda93d  vmovaps xmm11, [rsp+0xA0]
0000747fd7fda946  vmovaps xmm12, [rsp+0xB0]
0000747fd7fda94f  vmovaps xmm13, [rsp+0xC0]
0000747fd7fda958  vmovaps xmm14, [rsp+0xD0]
0000747fd7fda961  vmovaps xmm15, [rsp+0xE0]
0000747fd7fda96a  add rsp, 0xF0
0000747fd7fda971  pop r11
0000747fd7fda973  pop r10
0000747fd7fda975  pop r9
0000747fd7fda977  pop r8
0000747fd7fda979  pop rsi
0000747fd7fda97a  pop rdi
0000747fd7fda97b  pop rdx
0000747fd7fda97c  pop rcx
0000747fd7fda97d  pop rax
0000747fd7fda97e  add rsp, 0x08
0000747fd7fda982  jmp 0x0000747FD7FD64D2
0000747fd7fda987  sub rsp, 0x08
0000747fd7fda98b  push rax
0000747fd7fda98c  push rcx
0000747fd7fda98d  push rdx
0000747fd7fda98e  push rdi
0000747fd7fda98f  push rsi
0000747fd7fda990  push r8
0000747fd7fda992  push r9
0000747fd7fda994  push r10
0000747fd7fda996  push r11
0000747fd7fda998  sub rsp, 0xF0
0000747fd7fda99f  vmovaps [rsp], xmm0
0000747fd7fda9a4  vmovaps [rsp+0x10], xmm1
0000747fd7fda9aa  vmovaps [rsp+0x20], xmm2
0000747fd7fda9b0  vmovaps [rsp+0x30], xmm3
0000747fd7fda9b6  vmovaps [rsp+0x40], xmm4
0000747fd7fda9bc  vmovaps [rsp+0x50], xmm5
0000747fd7fda9c2  vmovaps [rsp+0x60], xmm6
0000747fd7fda9c8  vmovaps [rsp+0x70], xmm7
0000747fd7fda9ce  vmovaps [rsp+0x80], xmm8
0000747fd7fda9d7  vmovaps [rsp+0x90], xmm9
0000747fd7fda9e0  vmovaps [rsp+0xA0], xmm10
0000747fd7fda9e9  vmovaps [rsp+0xB0], xmm12
0000747fd7fda9f2  vmovaps [rsp+0xC0], xmm13
0000747fd7fda9fb  vmovaps [rsp+0xD0], xmm14
0000747fd7fdaa04  vmovaps [rsp+0xE0], xmm15
0000747fd7fdaa0d  sub rsp, 0x30
0000747fd7fdaa11  movaps [rsp], xmm11
0000747fd7fdaa16  movaps [rsp+0x10], xmm10
0000747fd7fdaa1c  movaps [rsp+0x20], xmm14
0000747fd7fdaa22  lea rdi, [rsp]
0000747fd7fdaa26  mov esi, 0x00
0000747fd7fdaa2b  mov rax, 0x6055A0B6E530
0000747fd7fdaa35  call rax
0000747fd7fdaa37  movaps xmm11, [rsp]
0000747fd7fdaa3c  add rsp, 0x30
0000747fd7fdaa40  vmovaps xmm0, [rsp]
0000747fd7fdaa45  vmovaps xmm1, [rsp+0x10]
0000747fd7fdaa4b  vmovaps xmm2, [rsp+0x20]
0000747fd7fdaa51  vmovaps xmm3, [rsp+0x30]
0000747fd7fdaa57  vmovaps xmm4, [rsp+0x40]
0000747fd7fdaa5d  vmovaps xmm5, [rsp+0x50]
0000747fd7fdaa63  vmovaps xmm6, [rsp+0x60]
0000747fd7fdaa69  vmovaps xmm7, [rsp+0x70]
0000747fd7fdaa6f  vmovaps xmm8, [rsp+0x80]
0000747fd7fdaa78  vmovaps xmm9, [rsp+0x90]
0000747fd7fdaa81  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdaa8a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdaa93  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdaa9c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdaaa5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdaaae  add rsp, 0xF0
0000747fd7fdaab5  pop r11
0000747fd7fdaab7  pop r10
0000747fd7fdaab9  pop r9
0000747fd7fdaabb  pop r8
0000747fd7fdaabd  pop rsi
0000747fd7fdaabe  pop rdi
0000747fd7fdaabf  pop rdx
0000747fd7fdaac0  pop rcx
0000747fd7fdaac1  pop rax
0000747fd7fdaac2  add rsp, 0x08
0000747fd7fdaac6  jmp 0x0000747FD7FD64ED
0000747fd7fdaacb  call 0x0000747FD7EE45A0
0000747fd7fdaad0  jmp 0x0000747FD7FD64F7
0000747fd7fdaad5  sub rsp, 0x08
0000747fd7fdaad9  push rax
0000747fd7fdaada  push rcx
0000747fd7fdaadb  push rdx
0000747fd7fdaadc  push rdi
0000747fd7fdaadd  push rsi
0000747fd7fdaade  push r8
0000747fd7fdaae0  push r9
0000747fd7fdaae2  push r10
0000747fd7fdaae4  push r11
0000747fd7fdaae6  sub rsp, 0xF0
0000747fd7fdaaed  vmovaps [rsp], xmm0
0000747fd7fdaaf2  vmovaps [rsp+0x10], xmm1
0000747fd7fdaaf8  vmovaps [rsp+0x20], xmm2
0000747fd7fdaafe  vmovaps [rsp+0x30], xmm3
0000747fd7fdab04  vmovaps [rsp+0x40], xmm4
0000747fd7fdab0a  vmovaps [rsp+0x50], xmm5
0000747fd7fdab10  vmovaps [rsp+0x60], xmm6
0000747fd7fdab16  vmovaps [rsp+0x70], xmm7
0000747fd7fdab1c  vmovaps [rsp+0x80], xmm8
0000747fd7fdab25  vmovaps [rsp+0x90], xmm9
0000747fd7fdab2e  vmovaps [rsp+0xA0], xmm11
0000747fd7fdab37  vmovaps [rsp+0xB0], xmm12
0000747fd7fdab40  vmovaps [rsp+0xC0], xmm13
0000747fd7fdab49  vmovaps [rsp+0xD0], xmm14
0000747fd7fdab52  vmovaps [rsp+0xE0], xmm15
0000747fd7fdab5b  sub rsp, 0x30
0000747fd7fdab5f  movaps [rsp], xmm10
0000747fd7fdab64  movaps [rsp+0x10], xmm1
0000747fd7fdab69  movaps [rsp+0x20], xmm12
0000747fd7fdab6f  lea rdi, [rsp]
0000747fd7fdab73  mov esi, 0x00
0000747fd7fdab78  mov rax, 0x6055A0B6E530
0000747fd7fdab82  call rax
0000747fd7fdab84  movaps xmm10, [rsp]
0000747fd7fdab89  add rsp, 0x30
0000747fd7fdab8d  vmovaps xmm0, [rsp]
0000747fd7fdab92  vmovaps xmm1, [rsp+0x10]
0000747fd7fdab98  vmovaps xmm2, [rsp+0x20]
0000747fd7fdab9e  vmovaps xmm3, [rsp+0x30]
0000747fd7fdaba4  vmovaps xmm4, [rsp+0x40]
0000747fd7fdabaa  vmovaps xmm5, [rsp+0x50]
0000747fd7fdabb0  vmovaps xmm6, [rsp+0x60]
0000747fd7fdabb6  vmovaps xmm7, [rsp+0x70]
0000747fd7fdabbc  vmovaps xmm8, [rsp+0x80]
0000747fd7fdabc5  vmovaps xmm9, [rsp+0x90]
0000747fd7fdabce  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdabd7  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdabe0  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdabe9  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdabf2  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdabfb  add rsp, 0xF0
0000747fd7fdac02  pop r11
0000747fd7fdac04  pop r10
0000747fd7fdac06  pop r9
0000747fd7fdac08  pop r8
0000747fd7fdac0a  pop rsi
0000747fd7fdac0b  pop rdi
0000747fd7fdac0c  pop rdx
0000747fd7fdac0d  pop rcx
0000747fd7fdac0e  pop rax
0000747fd7fdac0f  add rsp, 0x08
0000747fd7fdac13  jmp 0x0000747FD7FD651A
0000747fd7fdac18  sub rsp, 0x08
0000747fd7fdac1c  push rax
0000747fd7fdac1d  push rcx
0000747fd7fdac1e  push rdx
0000747fd7fdac1f  push rdi
0000747fd7fdac20  push rsi
0000747fd7fdac21  push r8
0000747fd7fdac23  push r9
0000747fd7fdac25  push r10
0000747fd7fdac27  push r11
0000747fd7fdac29  sub rsp, 0xF0
0000747fd7fdac30  vmovaps [rsp], xmm0
0000747fd7fdac35  vmovaps [rsp+0x10], xmm1
0000747fd7fdac3b  vmovaps [rsp+0x20], xmm2
0000747fd7fdac41  vmovaps [rsp+0x30], xmm3
0000747fd7fdac47  vmovaps [rsp+0x40], xmm4
0000747fd7fdac4d  vmovaps [rsp+0x50], xmm5
0000747fd7fdac53  vmovaps [rsp+0x60], xmm6
0000747fd7fdac59  vmovaps [rsp+0x70], xmm7
0000747fd7fdac5f  vmovaps [rsp+0x80], xmm8
0000747fd7fdac68  vmovaps [rsp+0x90], xmm9
0000747fd7fdac71  vmovaps [rsp+0xA0], xmm10
0000747fd7fdac7a  vmovaps [rsp+0xB0], xmm11
0000747fd7fdac83  vmovaps [rsp+0xC0], xmm13
0000747fd7fdac8c  vmovaps [rsp+0xD0], xmm14
0000747fd7fdac95  vmovaps [rsp+0xE0], xmm15
0000747fd7fdac9e  sub rsp, 0x30
0000747fd7fdaca2  movaps [rsp], xmm12
0000747fd7fdaca7  movaps [rsp+0x10], xmm14
0000747fd7fdacad  movaps [rsp+0x20], xmm1
0000747fd7fdacb2  lea rdi, [rsp]
0000747fd7fdacb6  mov esi, 0x00
0000747fd7fdacbb  mov rax, 0x6055A0B6E530
0000747fd7fdacc5  call rax
0000747fd7fdacc7  movaps xmm12, [rsp]
0000747fd7fdaccc  add rsp, 0x30
0000747fd7fdacd0  vmovaps xmm0, [rsp]
0000747fd7fdacd5  vmovaps xmm1, [rsp+0x10]
0000747fd7fdacdb  vmovaps xmm2, [rsp+0x20]
0000747fd7fdace1  vmovaps xmm3, [rsp+0x30]
0000747fd7fdace7  vmovaps xmm4, [rsp+0x40]
0000747fd7fdaced  vmovaps xmm5, [rsp+0x50]
0000747fd7fdacf3  vmovaps xmm6, [rsp+0x60]
0000747fd7fdacf9  vmovaps xmm7, [rsp+0x70]
0000747fd7fdacff  vmovaps xmm8, [rsp+0x80]
0000747fd7fdad08  vmovaps xmm9, [rsp+0x90]
0000747fd7fdad11  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdad1a  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdad23  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdad2c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdad35  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdad3e  add rsp, 0xF0
0000747fd7fdad45  pop r11
0000747fd7fdad47  pop r10
0000747fd7fdad49  pop r9
0000747fd7fdad4b  pop r8
0000747fd7fdad4d  pop rsi
0000747fd7fdad4e  pop rdi
0000747fd7fdad4f  pop rdx
0000747fd7fdad50  pop rcx
0000747fd7fdad51  pop rax
0000747fd7fdad52  add rsp, 0x08
0000747fd7fdad56  jmp 0x0000747FD7FD6549
0000747fd7fdad5b  sub rsp, 0x08
0000747fd7fdad5f  push rax
0000747fd7fdad60  push rcx
0000747fd7fdad61  push rdx
0000747fd7fdad62  push rdi
0000747fd7fdad63  push rsi
0000747fd7fdad64  push r8
0000747fd7fdad66  push r9
0000747fd7fdad68  push r10
0000747fd7fdad6a  push r11
0000747fd7fdad6c  sub rsp, 0xF0
0000747fd7fdad73  vmovaps [rsp], xmm0
0000747fd7fdad78  vmovaps [rsp+0x10], xmm1
0000747fd7fdad7e  vmovaps [rsp+0x20], xmm2
0000747fd7fdad84  vmovaps [rsp+0x30], xmm3
0000747fd7fdad8a  vmovaps [rsp+0x40], xmm4
0000747fd7fdad90  vmovaps [rsp+0x50], xmm5
0000747fd7fdad96  vmovaps [rsp+0x60], xmm6
0000747fd7fdad9c  vmovaps [rsp+0x70], xmm7
0000747fd7fdada2  vmovaps [rsp+0x80], xmm8
0000747fd7fdadab  vmovaps [rsp+0x90], xmm9
0000747fd7fdadb4  vmovaps [rsp+0xA0], xmm10
0000747fd7fdadbd  vmovaps [rsp+0xB0], xmm11
0000747fd7fdadc6  vmovaps [rsp+0xC0], xmm12
0000747fd7fdadcf  vmovaps [rsp+0xD0], xmm13
0000747fd7fdadd8  vmovaps [rsp+0xE0], xmm15
0000747fd7fdade1  sub rsp, 0x30
0000747fd7fdade5  movaps [rsp], xmm14
0000747fd7fdadea  movaps [rsp+0x10], xmm9
0000747fd7fdadf0  movaps [rsp+0x20], xmm1
0000747fd7fdadf5  lea rdi, [rsp]
0000747fd7fdadf9  mov esi, 0x00
0000747fd7fdadfe  mov rax, 0x6055A0B6E530
0000747fd7fdae08  call rax
0000747fd7fdae0a  movaps xmm14, [rsp]
0000747fd7fdae0f  add rsp, 0x30
0000747fd7fdae13  vmovaps xmm0, [rsp]
0000747fd7fdae18  vmovaps xmm1, [rsp+0x10]
0000747fd7fdae1e  vmovaps xmm2, [rsp+0x20]
0000747fd7fdae24  vmovaps xmm3, [rsp+0x30]
0000747fd7fdae2a  vmovaps xmm4, [rsp+0x40]
0000747fd7fdae30  vmovaps xmm5, [rsp+0x50]
0000747fd7fdae36  vmovaps xmm6, [rsp+0x60]
0000747fd7fdae3c  vmovaps xmm7, [rsp+0x70]
0000747fd7fdae42  vmovaps xmm8, [rsp+0x80]
0000747fd7fdae4b  vmovaps xmm9, [rsp+0x90]
0000747fd7fdae54  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdae5d  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdae66  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdae6f  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdae78  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdae81  add rsp, 0xF0
0000747fd7fdae88  pop r11
0000747fd7fdae8a  pop r10
0000747fd7fdae8c  pop r9
0000747fd7fdae8e  pop r8
0000747fd7fdae90  pop rsi
0000747fd7fdae91  pop rdi
0000747fd7fdae92  pop rdx
0000747fd7fdae93  pop rcx
0000747fd7fdae94  pop rax
0000747fd7fdae95  add rsp, 0x08
0000747fd7fdae99  jmp 0x0000747FD7FD6578
0000747fd7fdae9e  sub rsp, 0x08
0000747fd7fdaea2  push rax
0000747fd7fdaea3  push rcx
0000747fd7fdaea4  push rdx
0000747fd7fdaea5  push rdi
0000747fd7fdaea6  push rsi
0000747fd7fdaea7  push r8
0000747fd7fdaea9  push r9
0000747fd7fdaeab  push r10
0000747fd7fdaead  push r11
0000747fd7fdaeaf  sub rsp, 0xF0
0000747fd7fdaeb6  vmovaps [rsp], xmm0
0000747fd7fdaebb  vmovaps [rsp+0x10], xmm2
0000747fd7fdaec1  vmovaps [rsp+0x20], xmm3
0000747fd7fdaec7  vmovaps [rsp+0x30], xmm4
0000747fd7fdaecd  vmovaps [rsp+0x40], xmm5
0000747fd7fdaed3  vmovaps [rsp+0x50], xmm6
0000747fd7fdaed9  vmovaps [rsp+0x60], xmm7
0000747fd7fdaedf  vmovaps [rsp+0x70], xmm8
0000747fd7fdaee5  vmovaps [rsp+0x80], xmm9
0000747fd7fdaeee  vmovaps [rsp+0x90], xmm10
0000747fd7fdaef7  vmovaps [rsp+0xA0], xmm11
0000747fd7fdaf00  vmovaps [rsp+0xB0], xmm12
0000747fd7fdaf09  vmovaps [rsp+0xC0], xmm13
0000747fd7fdaf12  vmovaps [rsp+0xD0], xmm14
0000747fd7fdaf1b  vmovaps [rsp+0xE0], xmm15
0000747fd7fdaf24  sub rsp, 0x30
0000747fd7fdaf28  movaps [rsp], xmm1
0000747fd7fdaf2c  movaps [rsp+0x10], xmm13
0000747fd7fdaf32  movaps [rsp+0x20], xmm8
0000747fd7fdaf38  lea rdi, [rsp]
0000747fd7fdaf3c  mov esi, 0x00
0000747fd7fdaf41  mov rax, 0x6055A0B6E530
0000747fd7fdaf4b  call rax
0000747fd7fdaf4d  movaps xmm1, [rsp]
0000747fd7fdaf51  add rsp, 0x30
0000747fd7fdaf55  vmovaps xmm0, [rsp]
0000747fd7fdaf5a  vmovaps xmm2, [rsp+0x10]
0000747fd7fdaf60  vmovaps xmm3, [rsp+0x20]
0000747fd7fdaf66  vmovaps xmm4, [rsp+0x30]
0000747fd7fdaf6c  vmovaps xmm5, [rsp+0x40]
0000747fd7fdaf72  vmovaps xmm6, [rsp+0x50]
0000747fd7fdaf78  vmovaps xmm7, [rsp+0x60]
0000747fd7fdaf7e  vmovaps xmm8, [rsp+0x70]
0000747fd7fdaf84  vmovaps xmm9, [rsp+0x80]
0000747fd7fdaf8d  vmovaps xmm10, [rsp+0x90]
0000747fd7fdaf96  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdaf9f  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdafa8  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdafb1  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdafba  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdafc3  add rsp, 0xF0
0000747fd7fdafca  pop r11
0000747fd7fdafcc  pop r10
0000747fd7fdafce  pop r9
0000747fd7fdafd0  pop r8
0000747fd7fdafd2  pop rsi
0000747fd7fdafd3  pop rdi
0000747fd7fdafd4  pop rdx
0000747fd7fdafd5  pop rcx
0000747fd7fdafd6  pop rax
0000747fd7fdafd7  add rsp, 0x08
0000747fd7fdafdb  jmp 0x0000747FD7FD659A
0000747fd7fdafe0  call 0x0000747FD7E0C260
0000747fd7fdafe5  jmp 0x0000747FD7FD65A8
0000747fd7fdafea  call 0x0000747FD7EDE950
0000747fd7fdafef  jmp 0x0000747FD7FD65B2
0000747fd7fdaff4  sub rsp, 0x08
0000747fd7fdaff8  push rax
0000747fd7fdaff9  push rcx
0000747fd7fdaffa  push rdx
0000747fd7fdaffb  push rdi
0000747fd7fdaffc  push rsi
0000747fd7fdaffd  push r8
0000747fd7fdafff  push r9
0000747fd7fdb001  push r10
0000747fd7fdb003  push r11
0000747fd7fdb005  sub rsp, 0xF0
0000747fd7fdb00c  vmovaps [rsp], xmm0
0000747fd7fdb011  vmovaps [rsp+0x10], xmm1
0000747fd7fdb017  vmovaps [rsp+0x20], xmm2
0000747fd7fdb01d  vmovaps [rsp+0x30], xmm3
0000747fd7fdb023  vmovaps [rsp+0x40], xmm4
0000747fd7fdb029  vmovaps [rsp+0x50], xmm5
0000747fd7fdb02f  vmovaps [rsp+0x60], xmm6
0000747fd7fdb035  vmovaps [rsp+0x70], xmm7
0000747fd7fdb03b  vmovaps [rsp+0x80], xmm9
0000747fd7fdb044  vmovaps [rsp+0x90], xmm10
0000747fd7fdb04d  vmovaps [rsp+0xA0], xmm11
0000747fd7fdb056  vmovaps [rsp+0xB0], xmm12
0000747fd7fdb05f  vmovaps [rsp+0xC0], xmm13
0000747fd7fdb068  vmovaps [rsp+0xD0], xmm14
0000747fd7fdb071  vmovaps [rsp+0xE0], xmm15
0000747fd7fdb07a  sub rsp, 0x30
0000747fd7fdb07e  movaps [rsp], xmm8
0000747fd7fdb083  movaps [rsp+0x10], xmm15
0000747fd7fdb089  movaps [rsp+0x20], xmm7
0000747fd7fdb08e  lea rdi, [rsp]
0000747fd7fdb092  mov esi, 0x00
0000747fd7fdb097  mov rax, 0x6055A0B6E530
0000747fd7fdb0a1  call rax
0000747fd7fdb0a3  movaps xmm8, [rsp]
0000747fd7fdb0a8  add rsp, 0x30
0000747fd7fdb0ac  vmovaps xmm0, [rsp]
0000747fd7fdb0b1  vmovaps xmm1, [rsp+0x10]
0000747fd7fdb0b7  vmovaps xmm2, [rsp+0x20]
0000747fd7fdb0bd  vmovaps xmm3, [rsp+0x30]
0000747fd7fdb0c3  vmovaps xmm4, [rsp+0x40]
0000747fd7fdb0c9  vmovaps xmm5, [rsp+0x50]
0000747fd7fdb0cf  vmovaps xmm6, [rsp+0x60]
0000747fd7fdb0d5  vmovaps xmm7, [rsp+0x70]
0000747fd7fdb0db  vmovaps xmm9, [rsp+0x80]
0000747fd7fdb0e4  vmovaps xmm10, [rsp+0x90]
0000747fd7fdb0ed  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdb0f6  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdb0ff  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdb108  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdb111  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdb11a  add rsp, 0xF0
0000747fd7fdb121  pop r11
0000747fd7fdb123  pop r10
0000747fd7fdb125  pop r9
0000747fd7fdb127  pop r8
0000747fd7fdb129  pop rsi
0000747fd7fdb12a  pop rdi
0000747fd7fdb12b  pop rdx
0000747fd7fdb12c  pop rcx
0000747fd7fdb12d  pop rax
0000747fd7fdb12e  add rsp, 0x08
0000747fd7fdb132  jmp 0x0000747FD7FD65D4
0000747fd7fdb137  sub rsp, 0x08
0000747fd7fdb13b  push rax
0000747fd7fdb13c  push rcx
0000747fd7fdb13d  push rdx
0000747fd7fdb13e  push rdi
0000747fd7fdb13f  push rsi
0000747fd7fdb140  push r8
0000747fd7fdb142  push r9
0000747fd7fdb144  push r10
0000747fd7fdb146  push r11
0000747fd7fdb148  sub rsp, 0xF0
0000747fd7fdb14f  vmovaps [rsp], xmm0
0000747fd7fdb154  vmovaps [rsp+0x10], xmm1
0000747fd7fdb15a  vmovaps [rsp+0x20], xmm2
0000747fd7fdb160  vmovaps [rsp+0x30], xmm3
0000747fd7fdb166  vmovaps [rsp+0x40], xmm4
0000747fd7fdb16c  vmovaps [rsp+0x50], xmm5
0000747fd7fdb172  vmovaps [rsp+0x60], xmm6
0000747fd7fdb178  vmovaps [rsp+0x70], xmm8
0000747fd7fdb17e  vmovaps [rsp+0x80], xmm9
0000747fd7fdb187  vmovaps [rsp+0x90], xmm10
0000747fd7fdb190  vmovaps [rsp+0xA0], xmm11
0000747fd7fdb199  vmovaps [rsp+0xB0], xmm12
0000747fd7fdb1a2  vmovaps [rsp+0xC0], xmm13
0000747fd7fdb1ab  vmovaps [rsp+0xD0], xmm14
0000747fd7fdb1b4  vmovaps [rsp+0xE0], xmm15
0000747fd7fdb1bd  sub rsp, 0x30
0000747fd7fdb1c1  movaps [rsp], xmm7
0000747fd7fdb1c5  movaps [rsp+0x10], xmm9
0000747fd7fdb1cb  movaps [rsp+0x20], xmm15
0000747fd7fdb1d1  lea rdi, [rsp]
0000747fd7fdb1d5  mov esi, 0x00
0000747fd7fdb1da  mov rax, 0x6055A0B6E530
0000747fd7fdb1e4  call rax
0000747fd7fdb1e6  movaps xmm7, [rsp]
0000747fd7fdb1ea  add rsp, 0x30
0000747fd7fdb1ee  vmovaps xmm0, [rsp]
0000747fd7fdb1f3  vmovaps xmm1, [rsp+0x10]
0000747fd7fdb1f9  vmovaps xmm2, [rsp+0x20]
0000747fd7fdb1ff  vmovaps xmm3, [rsp+0x30]
0000747fd7fdb205  vmovaps xmm4, [rsp+0x40]
0000747fd7fdb20b  vmovaps xmm5, [rsp+0x50]
0000747fd7fdb211  vmovaps xmm6, [rsp+0x60]
0000747fd7fdb217  vmovaps xmm8, [rsp+0x70]
0000747fd7fdb21d  vmovaps xmm9, [rsp+0x80]
0000747fd7fdb226  vmovaps xmm10, [rsp+0x90]
0000747fd7fdb22f  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdb238  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdb241  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdb24a  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdb253  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdb25c  add rsp, 0xF0
0000747fd7fdb263  pop r11
0000747fd7fdb265  pop r10
0000747fd7fdb267  pop r9
0000747fd7fdb269  pop r8
0000747fd7fdb26b  pop rsi
0000747fd7fdb26c  pop rdi
0000747fd7fdb26d  pop rdx
0000747fd7fdb26e  pop rcx
0000747fd7fdb26f  pop rax
0000747fd7fdb270  add rsp, 0x08
0000747fd7fdb274  jmp 0x0000747FD7FD6601
0000747fd7fdb279  sub rsp, 0x08
0000747fd7fdb27d  push rax
0000747fd7fdb27e  push rcx
0000747fd7fdb27f  push rdx
0000747fd7fdb280  push rdi
0000747fd7fdb281  push rsi
0000747fd7fdb282  push r8
0000747fd7fdb284  push r9
0000747fd7fdb286  push r10
0000747fd7fdb288  push r11
0000747fd7fdb28a  sub rsp, 0xF0
0000747fd7fdb291  vmovaps [rsp], xmm0
0000747fd7fdb296  vmovaps [rsp+0x10], xmm1
0000747fd7fdb29c  vmovaps [rsp+0x20], xmm2
0000747fd7fdb2a2  vmovaps [rsp+0x30], xmm3
0000747fd7fdb2a8  vmovaps [rsp+0x40], xmm4
0000747fd7fdb2ae  vmovaps [rsp+0x50], xmm5
0000747fd7fdb2b4  vmovaps [rsp+0x60], xmm6
0000747fd7fdb2ba  vmovaps [rsp+0x70], xmm7
0000747fd7fdb2c0  vmovaps [rsp+0x80], xmm8
0000747fd7fdb2c9  vmovaps [rsp+0x90], xmm10
0000747fd7fdb2d2  vmovaps [rsp+0xA0], xmm11
0000747fd7fdb2db  vmovaps [rsp+0xB0], xmm12
0000747fd7fdb2e4  vmovaps [rsp+0xC0], xmm13
0000747fd7fdb2ed  vmovaps [rsp+0xD0], xmm14
0000747fd7fdb2f6  vmovaps [rsp+0xE0], xmm15
0000747fd7fdb2ff  sub rsp, 0x30
0000747fd7fdb303  movaps [rsp], xmm9
0000747fd7fdb308  movaps [rsp+0x10], xmm13
0000747fd7fdb30e  movaps [rsp+0x20], xmm15
0000747fd7fdb314  lea rdi, [rsp]
0000747fd7fdb318  mov esi, 0x00
0000747fd7fdb31d  mov rax, 0x6055A0B6E530
0000747fd7fdb327  call rax
0000747fd7fdb329  movaps xmm9, [rsp]
0000747fd7fdb32e  add rsp, 0x30
0000747fd7fdb332  vmovaps xmm0, [rsp]
0000747fd7fdb337  vmovaps xmm1, [rsp+0x10]
0000747fd7fdb33d  vmovaps xmm2, [rsp+0x20]
0000747fd7fdb343  vmovaps xmm3, [rsp+0x30]
0000747fd7fdb349  vmovaps xmm4, [rsp+0x40]
0000747fd7fdb34f  vmovaps xmm5, [rsp+0x50]
0000747fd7fdb355  vmovaps xmm6, [rsp+0x60]
0000747fd7fdb35b  vmovaps xmm7, [rsp+0x70]
0000747fd7fdb361  vmovaps xmm8, [rsp+0x80]
0000747fd7fdb36a  vmovaps xmm10, [rsp+0x90]
0000747fd7fdb373  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdb37c  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdb385  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdb38e  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdb397  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdb3a0  add rsp, 0xF0
0000747fd7fdb3a7  pop r11
0000747fd7fdb3a9  pop r10
0000747fd7fdb3ab  pop r9
0000747fd7fdb3ad  pop r8
0000747fd7fdb3af  pop rsi
0000747fd7fdb3b0  pop rdi
0000747fd7fdb3b1  pop rdx
0000747fd7fdb3b2  pop rcx
0000747fd7fdb3b3  pop rax
0000747fd7fdb3b4  add rsp, 0x08
0000747fd7fdb3b8  jmp 0x0000747FD7FD662F
0000747fd7fdb3bd  sub rsp, 0x08
0000747fd7fdb3c1  push rax
0000747fd7fdb3c2  push rcx
0000747fd7fdb3c3  push rdx
0000747fd7fdb3c4  push rdi
0000747fd7fdb3c5  push rsi
0000747fd7fdb3c6  push r8
0000747fd7fdb3c8  push r9
0000747fd7fdb3ca  push r10
0000747fd7fdb3cc  push r11
0000747fd7fdb3ce  sub rsp, 0xF0
0000747fd7fdb3d5  vmovaps [rsp], xmm0
0000747fd7fdb3da  vmovaps [rsp+0x10], xmm1
0000747fd7fdb3e0  vmovaps [rsp+0x20], xmm2
0000747fd7fdb3e6  vmovaps [rsp+0x30], xmm3
0000747fd7fdb3ec  vmovaps [rsp+0x40], xmm4
0000747fd7fdb3f2  vmovaps [rsp+0x50], xmm5
0000747fd7fdb3f8  vmovaps [rsp+0x60], xmm6
0000747fd7fdb3fe  vmovaps [rsp+0x70], xmm7
0000747fd7fdb404  vmovaps [rsp+0x80], xmm8
0000747fd7fdb40d  vmovaps [rsp+0x90], xmm9
0000747fd7fdb416  vmovaps [rsp+0xA0], xmm10
0000747fd7fdb41f  vmovaps [rsp+0xB0], xmm11
0000747fd7fdb428  vmovaps [rsp+0xC0], xmm12
0000747fd7fdb431  vmovaps [rsp+0xD0], xmm13
0000747fd7fdb43a  vmovaps [rsp+0xE0], xmm14
0000747fd7fdb443  sub rsp, 0x30
0000747fd7fdb447  movaps [rsp], xmm15
0000747fd7fdb44c  movaps [rsp+0x10], xmm11
0000747fd7fdb452  movaps [rsp+0x20], xmm12
0000747fd7fdb458  lea rdi, [rsp]
0000747fd7fdb45c  mov esi, 0x00
0000747fd7fdb461  mov rax, 0x6055A0B6E530
0000747fd7fdb46b  call rax
0000747fd7fdb46d  movaps xmm15, [rsp]
0000747fd7fdb472  add rsp, 0x30
0000747fd7fdb476  vmovaps xmm0, [rsp]
0000747fd7fdb47b  vmovaps xmm1, [rsp+0x10]
0000747fd7fdb481  vmovaps xmm2, [rsp+0x20]
0000747fd7fdb487  vmovaps xmm3, [rsp+0x30]
0000747fd7fdb48d  vmovaps xmm4, [rsp+0x40]
0000747fd7fdb493  vmovaps xmm5, [rsp+0x50]
0000747fd7fdb499  vmovaps xmm6, [rsp+0x60]
0000747fd7fdb49f  vmovaps xmm7, [rsp+0x70]
0000747fd7fdb4a5  vmovaps xmm8, [rsp+0x80]
0000747fd7fdb4ae  vmovaps xmm9, [rsp+0x90]
0000747fd7fdb4b7  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdb4c0  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdb4c9  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdb4d2  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdb4db  vmovaps xmm14, [rsp+0xE0]
0000747fd7fdb4e4  add rsp, 0xF0
0000747fd7fdb4eb  pop r11
0000747fd7fdb4ed  pop r10
0000747fd7fdb4ef  pop r9
0000747fd7fdb4f1  pop r8
0000747fd7fdb4f3  pop rsi
0000747fd7fdb4f4  pop rdi
0000747fd7fdb4f5  pop rdx
0000747fd7fdb4f6  pop rcx
0000747fd7fdb4f7  pop rax
0000747fd7fdb4f8  add rsp, 0x08
0000747fd7fdb4fc  jmp 0x0000747FD7FD664A
0000747fd7fdb501  sub rsp, 0x08
0000747fd7fdb505  push rax
0000747fd7fdb506  push rcx
0000747fd7fdb507  push rdx
0000747fd7fdb508  push rdi
0000747fd7fdb509  push rsi
0000747fd7fdb50a  push r8
0000747fd7fdb50c  push r9
0000747fd7fdb50e  push r10
0000747fd7fdb510  push r11
0000747fd7fdb512  sub rsp, 0xF0
0000747fd7fdb519  vmovaps [rsp], xmm0
0000747fd7fdb51e  vmovaps [rsp+0x10], xmm1
0000747fd7fdb524  vmovaps [rsp+0x20], xmm2
0000747fd7fdb52a  vmovaps [rsp+0x30], xmm3
0000747fd7fdb530  vmovaps [rsp+0x40], xmm4
0000747fd7fdb536  vmovaps [rsp+0x50], xmm5
0000747fd7fdb53c  vmovaps [rsp+0x60], xmm6
0000747fd7fdb542  vmovaps [rsp+0x70], xmm7
0000747fd7fdb548  vmovaps [rsp+0x80], xmm8
0000747fd7fdb551  vmovaps [rsp+0x90], xmm9
0000747fd7fdb55a  vmovaps [rsp+0xA0], xmm10
0000747fd7fdb563  vmovaps [rsp+0xB0], xmm11
0000747fd7fdb56c  vmovaps [rsp+0xC0], xmm12
0000747fd7fdb575  vmovaps [rsp+0xD0], xmm14
0000747fd7fdb57e  vmovaps [rsp+0xE0], xmm15
0000747fd7fdb587  sub rsp, 0x30
0000747fd7fdb58b  movaps [rsp], xmm13
0000747fd7fdb590  movaps [rsp+0x10], xmm10
0000747fd7fdb596  movaps [rsp+0x20], xmm14
0000747fd7fdb59c  lea rdi, [rsp]
0000747fd7fdb5a0  mov esi, 0x00
0000747fd7fdb5a5  mov rax, 0x6055A0B6E530
0000747fd7fdb5af  call rax
0000747fd7fdb5b1  movaps xmm13, [rsp]
0000747fd7fdb5b6  add rsp, 0x30
0000747fd7fdb5ba  vmovaps xmm0, [rsp]
0000747fd7fdb5bf  vmovaps xmm1, [rsp+0x10]
0000747fd7fdb5c5  vmovaps xmm2, [rsp+0x20]
0000747fd7fdb5cb  vmovaps xmm3, [rsp+0x30]
0000747fd7fdb5d1  vmovaps xmm4, [rsp+0x40]
0000747fd7fdb5d7  vmovaps xmm5, [rsp+0x50]
0000747fd7fdb5dd  vmovaps xmm6, [rsp+0x60]
0000747fd7fdb5e3  vmovaps xmm7, [rsp+0x70]
0000747fd7fdb5e9  vmovaps xmm8, [rsp+0x80]
0000747fd7fdb5f2  vmovaps xmm9, [rsp+0x90]
0000747fd7fdb5fb  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdb604  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdb60d  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdb616  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdb61f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdb628  add rsp, 0xF0
0000747fd7fdb62f  pop r11
0000747fd7fdb631  pop r10
0000747fd7fdb633  pop r9
0000747fd7fdb635  pop r8
0000747fd7fdb637  pop rsi
0000747fd7fdb638  pop rdi
0000747fd7fdb639  pop rdx
0000747fd7fdb63a  pop rcx
0000747fd7fdb63b  pop rax
0000747fd7fdb63c  add rsp, 0x08
0000747fd7fdb640  jmp 0x0000747FD7FD666D
0000747fd7fdb645  sub rsp, 0x08
0000747fd7fdb649  push rax
0000747fd7fdb64a  push rcx
0000747fd7fdb64b  push rdx
0000747fd7fdb64c  push rdi
0000747fd7fdb64d  push rsi
0000747fd7fdb64e  push r8
0000747fd7fdb650  push r9
0000747fd7fdb652  push r10
0000747fd7fdb654  push r11
0000747fd7fdb656  sub rsp, 0xF0
0000747fd7fdb65d  vmovaps [rsp], xmm0
0000747fd7fdb662  vmovaps [rsp+0x10], xmm1
0000747fd7fdb668  vmovaps [rsp+0x20], xmm2
0000747fd7fdb66e  vmovaps [rsp+0x30], xmm3
0000747fd7fdb674  vmovaps [rsp+0x40], xmm4
0000747fd7fdb67a  vmovaps [rsp+0x50], xmm5
0000747fd7fdb680  vmovaps [rsp+0x60], xmm6
0000747fd7fdb686  vmovaps [rsp+0x70], xmm7
0000747fd7fdb68c  vmovaps [rsp+0x80], xmm8
0000747fd7fdb695  vmovaps [rsp+0x90], xmm9
0000747fd7fdb69e  vmovaps [rsp+0xA0], xmm10
0000747fd7fdb6a7  vmovaps [rsp+0xB0], xmm11
0000747fd7fdb6b0  vmovaps [rsp+0xC0], xmm12
0000747fd7fdb6b9  vmovaps [rsp+0xD0], xmm13
0000747fd7fdb6c2  vmovaps [rsp+0xE0], xmm15
0000747fd7fdb6cb  sub rsp, 0x30
0000747fd7fdb6cf  movaps [rsp], xmm14
0000747fd7fdb6d4  movaps [rsp+0x10], xmm1
0000747fd7fdb6d9  movaps [rsp+0x20], xmm7
0000747fd7fdb6de  lea rdi, [rsp]
0000747fd7fdb6e2  mov esi, 0x00
0000747fd7fdb6e7  mov rax, 0x6055A0B6E530
0000747fd7fdb6f1  call rax
0000747fd7fdb6f3  movaps xmm14, [rsp]
0000747fd7fdb6f8  add rsp, 0x30
0000747fd7fdb6fc  vmovaps xmm0, [rsp]
0000747fd7fdb701  vmovaps xmm1, [rsp+0x10]
0000747fd7fdb707  vmovaps xmm2, [rsp+0x20]
0000747fd7fdb70d  vmovaps xmm3, [rsp+0x30]
0000747fd7fdb713  vmovaps xmm4, [rsp+0x40]
0000747fd7fdb719  vmovaps xmm5, [rsp+0x50]
0000747fd7fdb71f  vmovaps xmm6, [rsp+0x60]
0000747fd7fdb725  vmovaps xmm7, [rsp+0x70]
0000747fd7fdb72b  vmovaps xmm8, [rsp+0x80]
0000747fd7fdb734  vmovaps xmm9, [rsp+0x90]
0000747fd7fdb73d  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdb746  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdb74f  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdb758  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdb761  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdb76a  add rsp, 0xF0
0000747fd7fdb771  pop r11
0000747fd7fdb773  pop r10
0000747fd7fdb775  pop r9
0000747fd7fdb777  pop r8
0000747fd7fdb779  pop rsi
0000747fd7fdb77a  pop rdi
0000747fd7fdb77b  pop rdx
0000747fd7fdb77c  pop rcx
0000747fd7fdb77d  pop rax
0000747fd7fdb77e  add rsp, 0x08
0000747fd7fdb782  jmp 0x0000747FD7FD6690
0000747fd7fdb787  sub rsp, 0x08
0000747fd7fdb78b  push rax
0000747fd7fdb78c  push rcx
0000747fd7fdb78d  push rdx
0000747fd7fdb78e  push rdi
0000747fd7fdb78f  push rsi
0000747fd7fdb790  push r8
0000747fd7fdb792  push r9
0000747fd7fdb794  push r10
0000747fd7fdb796  push r11
0000747fd7fdb798  sub rsp, 0xF0
0000747fd7fdb79f  vmovaps [rsp], xmm0
0000747fd7fdb7a4  vmovaps [rsp+0x10], xmm2
0000747fd7fdb7aa  vmovaps [rsp+0x20], xmm3
0000747fd7fdb7b0  vmovaps [rsp+0x30], xmm4
0000747fd7fdb7b6  vmovaps [rsp+0x40], xmm5
0000747fd7fdb7bc  vmovaps [rsp+0x50], xmm6
0000747fd7fdb7c2  vmovaps [rsp+0x60], xmm7
0000747fd7fdb7c8  vmovaps [rsp+0x70], xmm8
0000747fd7fdb7ce  vmovaps [rsp+0x80], xmm9
0000747fd7fdb7d7  vmovaps [rsp+0x90], xmm10
0000747fd7fdb7e0  vmovaps [rsp+0xA0], xmm11
0000747fd7fdb7e9  vmovaps [rsp+0xB0], xmm12
0000747fd7fdb7f2  vmovaps [rsp+0xC0], xmm13
0000747fd7fdb7fb  vmovaps [rsp+0xD0], xmm14
0000747fd7fdb804  vmovaps [rsp+0xE0], xmm15
0000747fd7fdb80d  sub rsp, 0x30
0000747fd7fdb811  movaps [rsp], xmm1
0000747fd7fdb815  movaps [rsp+0x10], xmm8
0000747fd7fdb81b  movaps [rsp+0x20], xmm9
0000747fd7fdb821  lea rdi, [rsp]
0000747fd7fdb825  mov esi, 0x00
0000747fd7fdb82a  mov rax, 0x6055A0B6E530
0000747fd7fdb834  call rax
0000747fd7fdb836  movaps xmm1, [rsp]
0000747fd7fdb83a  add rsp, 0x30
0000747fd7fdb83e  vmovaps xmm0, [rsp]
0000747fd7fdb843  vmovaps xmm2, [rsp+0x10]
0000747fd7fdb849  vmovaps xmm3, [rsp+0x20]
0000747fd7fdb84f  vmovaps xmm4, [rsp+0x30]
0000747fd7fdb855  vmovaps xmm5, [rsp+0x40]
0000747fd7fdb85b  vmovaps xmm6, [rsp+0x50]
0000747fd7fdb861  vmovaps xmm7, [rsp+0x60]
0000747fd7fdb867  vmovaps xmm8, [rsp+0x70]
0000747fd7fdb86d  vmovaps xmm9, [rsp+0x80]
0000747fd7fdb876  vmovaps xmm10, [rsp+0x90]
0000747fd7fdb87f  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdb888  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdb891  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdb89a  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdb8a3  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdb8ac  add rsp, 0xF0
0000747fd7fdb8b3  pop r11
0000747fd7fdb8b5  pop r10
0000747fd7fdb8b7  pop r9
0000747fd7fdb8b9  pop r8
0000747fd7fdb8bb  pop rsi
0000747fd7fdb8bc  pop rdi
0000747fd7fdb8bd  pop rdx
0000747fd7fdb8be  pop rcx
0000747fd7fdb8bf  pop rax
0000747fd7fdb8c0  add rsp, 0x08
0000747fd7fdb8c4  jmp 0x0000747FD7FD66B2
0000747fd7fdb8c9  call 0x0000747FD7EB3E40
0000747fd7fdb8ce  jmp 0x0000747FD7FD66C0
0000747fd7fdb8d3  call 0x0000747FD7E0C380
0000747fd7fdb8d8  jmp 0x0000747FD7FD66CA
0000747fd7fdb8dd  call 0x0000747FD7E0D600
0000747fd7fdb8e2  jmp 0x0000747FD7FD66D4
0000747fd7fdb8e7  call 0x0000747FD7DFF540
0000747fd7fdb8ec  jmp 0x0000747FD7FD66DE
0000747fd7fdb8f1  int3
0000747fd7fdb8f2  nop [rax+rax*1], ax
0000747fd7fdb8fb  nop [rax+rax*1], eax
0000747fd7fdb900  mov eax, [r15+0x48]
0000747fd7fdb904  lea r14d, [eax+0x01]
0000747fd7fdb909  mov [rsp+0x10], r14d
0000747fd7fdb90e  mov r14d, r14d
0000747fd7fdb911  mov [r15+0x48], r14
0000747fd7fdb915  xor eax, eax
0000747fd7fdb917  mov r14d, [rsp+0x10]
0000747fd7fdb91c  cmp r14d, 0x1F4
0000747fd7fdb923  cmc
0000747fd7fdb924  lahf
0000747fd7fdb925  seto al
0000747fd7fdb928  mov [r15+0x108], eax
0000747fd7fdb92f  mov eax, [r15+0x108]
0000747fd7fdb936  sahf
0000747fd7fdb937  jnz 0x0000747FD7FDB969
0000747fd7fdb939  cmp dword ptr [r15+0x318], 0x00
0000747fd7fdb941  jz 0x0000747FD7FE1AB0
0000747fd7fdb947  nop [rax+rax*1], ax
0000747fd7fdb950  nop [rax+rax*1], eax
0000747fd7fdb958  mov eax, 0x410450
0000747fd7fdb95d  mov [r15+0x100], rax
0000747fd7fdb964  jmp 0x0000747FD7DFE110
0000747fd7fdb969  cmp dword ptr [r15+0x318], 0x00
0000747fd7fdb971  jz 0x0000747FD7FDB9A0
0000747fd7fdb977  nop [rax+rax*1], ax
0000747fd7fdb980  nop [rax+rax*1], eax
0000747fd7fdb988  mov eax, 0x410274
0000747fd7fdb98d  mov [r15+0x100], rax
0000747fd7fdb994  jmp 0x0000747FD7DFE110
0000747fd7fdb999  int3
0000747fd7fdb99a  int3
0000747fd7fdb99b  nop [rax+rax*1], eax
0000747fd7fdb9a0  mov rax, [r15+0x40]
0000747fd7fdb9a4  movaps xmm1, [r15+0x1D0]
0000747fd7fdb9ac  vmovaps [rsp+0x10], xmm1
0000747fd7fdb9b2  vmovaps xmm15, [rsp+0x10]
0000747fd7fdb9b8  por xmm1, xmm15
0000747fd7fdb9bd  movaps xmm14, [r15+0x1A0]
0000747fd7fdb9c5  vmovaps [rsp+0x10], xmm14
0000747fd7fdb9cb  vmovaps xmm13, [rsp+0x10]
0000747fd7fdb9d1  por xmm14, xmm13
0000747fd7fdb9d6  lea r14, [rax+0x30]
0000747fd7fdb9da  mov r12, [r13+r14*1]
0000747fd7fdb9df  lea r14, [rax+0x38]
0000747fd7fdb9e3  mov r11, [r13+r14*1]
0000747fd7fdb9e8  movq xmm13, r12
0000747fd7fdb9ed  movq xmm12, r11
0000747fd7fdb9f2  movq xmm13, xmm13
0000747fd7fdb9f7  vmovaps [rsp+0x10], xmm13
0000747fd7fdb9fd  movq xmm13, xmm13
0000747fd7fdba02  movaps [r15+0x130], xmm13
0000747fd7fdba0a  movq xmm12, xmm12
0000747fd7fdba0f  vmovaps [rsp+0x20], xmm12
0000747fd7fdba15  movq xmm12, xmm12
0000747fd7fdba1a  movaps [r15+0x280], xmm12
0000747fd7fdba22  movaps xmm13, [r15+0x270]
0000747fd7fdba2a  vmovaps [rsp+0x30], xmm13
0000747fd7fdba30  vmovaps xmm12, [rsp+0x30]
0000747fd7fdba36  por xmm13, xmm12
0000747fd7fdba3b  lea r14, [rax+0x20]
0000747fd7fdba3f  mov r12, [r13+r14*1]
0000747fd7fdba44  lea r14, [rax+0x28]
0000747fd7fdba48  mov r11, [r13+r14*1]
0000747fd7fdba4d  movq xmm12, r12
0000747fd7fdba52  movq xmm11, r11
0000747fd7fdba57  movq xmm12, xmm12
0000747fd7fdba5c  vmovaps [rsp+0x30], xmm12
0000747fd7fdba62  movq xmm12, xmm12
0000747fd7fdba67  movaps [r15+0x150], xmm12
0000747fd7fdba6f  movq xmm11, xmm11
0000747fd7fdba74  vmovaps [rsp+0x40], xmm11
0000747fd7fdba7a  movq xmm11, xmm11
0000747fd7fdba7f  movaps [r15+0x140], xmm11
0000747fd7fdba87  lea r14, [rax+0x10]
0000747fd7fdba8b  mov r12, [r13+r14*1]
0000747fd7fdba90  lea r14, [rax+0x18]
0000747fd7fdba94  mov r11, [r13+r14*1]
0000747fd7fdba99  movq xmm12, r12
0000747fd7fdba9e  movq xmm11, r11
0000747fd7fdbaa3  movq xmm12, xmm12
0000747fd7fdbaa8  vmovaps [rsp+0x50], xmm12
0000747fd7fdbaae  movq xmm12, xmm12
0000747fd7fdbab3  movaps [r15+0x170], xmm12
0000747fd7fdbabb  movq xmm11, xmm11
0000747fd7fdbac0  vmovaps [rsp+0x60], xmm11
0000747fd7fdbac6  movq xmm11, xmm11
0000747fd7fdbacb  movaps [r15+0x160], xmm11
0000747fd7fdbad3  mov r14, [r13+rax*1]
0000747fd7fdbad8  vmovq xmm12, r14
0000747fd7fdbadd  vpbroadcastq xmm12, xmm12
0000747fd7fdbae2  lea r14, [rax+0x08]
0000747fd7fdbae6  mov rax, [r13+r14*1]
0000747fd7fdbaeb  movq xmm11, rax
0000747fd7fdbaf0  movaps [r15+0x230], xmm11
0000747fd7fdbaf8  mov rax, [r15+0xF8]
0000747fd7fdbaff  lea r14, [rax+0x50]
0000747fd7fdbb03  movups xmm11, [r13+r14*1]
0000747fd7fdbb09  lea r14, [rax+0x60]
0000747fd7fdbb0d  movups xmm10, [r13+r14*1]
0000747fd7fdbb13  lea r14, [rax+0x30]
0000747fd7fdbb17  movups xmm9, [r13+r14*1]
0000747fd7fdbb1d  mov r14, [r15+0x50]
0000747fd7fdbb21  mov [r15+0x60], r14
0000747fd7fdbb25  mov qword ptr [r15+0x58], 0x40
0000747fd7fdbb2d  movaps xmm8, xmm12
0000747fd7fdbb31  mulpd xmm8, xmm15
0000747fd7fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000747fd7fdbb3c  ptest xmm7, xmm7
0000747fd7fdbb41  jnz 0x0000747FD7FDC96A
0000747fd7fdbb47  movq xmm15, qword ptr [r15+0x230]
0000747fd7fdbb50  vmovaps [rsp+0x70], xmm15
0000747fd7fdbb56  vpermilpd xmm15, xmm15, 0x00
0000747fd7fdbb5c  movaps xmm7, xmm9
0000747fd7fdbb60  mulpd xmm7, xmm15
0000747fd7fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000747fd7fdbb6a  ptest xmm6, xmm6
0000747fd7fdbb6f  jnz 0x0000747FD7FDCAAE
0000747fd7fdbb75  vxorps xmm15, xmm15, xmm15
0000747fd7fdbb7a  vpbroadcastq xmm15, xmm15
0000747fd7fdbb7f  movaps xmm9, xmm12
0000747fd7fdbb83  mulpd xmm9, xmm10
0000747fd7fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000747fd7fdbb8e  ptest xmm6, xmm6
0000747fd7fdbb93  jnz 0x0000747FD7FDCBF0
0000747fd7fdbb99  movaps xmm10, xmm12
0000747fd7fdbb9d  mulpd xmm10, xmm11
0000747fd7fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000747fd7fdbba8  ptest xmm6, xmm6
0000747fd7fdbbad  jnz 0x0000747FD7FDCD34
0000747fd7fdbbb3  movaps xmm11, [r15+0x1F0]
0000747fd7fdbbbb  movaps xmm6, xmm12
0000747fd7fdbbbf  mulpd xmm6, xmm11
0000747fd7fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000747fd7fdbbc9  ptest xmm5, xmm5
0000747fd7fdbbce  jnz 0x0000747FD7FDCE78
0000747fd7fdbbd4  movaps xmm12, [r15+0x2A0]
0000747fd7fdbbdc  vmovaps [rsp+0x80], xmm12
0000747fd7fdbbe5  vmovaps xmm11, [rsp+0x80]
0000747fd7fdbbee  por xmm12, xmm11
0000747fd7fdbbf3  movaps xmm11, [r15+0x250]
0000747fd7fdbbfb  vmovaps [rsp+0x80], xmm11
0000747fd7fdbc04  vmovaps xmm5, [rsp+0x80]
0000747fd7fdbc0d  por xmm11, xmm5
0000747fd7fdbc12  vmovaps xmm4, [rsp+0x70]
0000747fd7fdbc18  vpermilpd xmm4, xmm4, 0x00
0000747fd7fdbc1e  movaps xmm3, xmm5
0000747fd7fdbc21  mulpd xmm3, xmm4
0000747fd7fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000747fd7fdbc2a  ptest xmm2, xmm2
0000747fd7fdbc2f  jnz 0x0000747FD7FDCFBA
0000747fd7fdbc35  mov [rsp+0x80], rax
0000747fd7fdbc3d  xor eax, eax
0000747fd7fdbc3f  mov r12d, 0x40
0000747fd7fdbc45  mov r11d, 0x200
0000747fd7fdbc4b  cmp r12, r11
0000747fd7fdbc4e  cmc
0000747fd7fdbc4f  lahf
0000747fd7fdbc50  seto al
0000747fd7fdbc53  mov [r15+0x108], eax
0000747fd7fdbc5a  movaps xmm5, xmm8
0000747fd7fdbc5e  addpd xmm5, xmm15
0000747fd7fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000747fd7fdbc68  ptest xmm4, xmm4
0000747fd7fdbc6d  jnz 0x0000747FD7FDD0FA
0000747fd7fdbc73  movaps xmm8, [r15+0x1B0]
0000747fd7fdbc7b  movaps xmm4, xmm9
0000747fd7fdbc7f  addpd xmm4, xmm8
0000747fd7fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000747fd7fdbc89  ptest xmm2, xmm2
0000747fd7fdbc8e  jnz 0x0000747FD7FDD23C
0000747fd7fdbc94  movaps xmm9, xmm10
0000747fd7fdbc98  addpd xmm9, xmm8
0000747fd7fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000747fd7fdbca3  ptest xmm2, xmm2
0000747fd7fdbca8  jnz 0x0000747FD7FDD37E
0000747fd7fdbcae  movaps xmm10, [r15+0x2F0]
0000747fd7fdbcb6  vmovaps [rsp+0x90], xmm10
0000747fd7fdbcbf  vmovaps xmm8, [rsp+0x90]
0000747fd7fdbcc8  por xmm10, xmm8
0000747fd7fdbccd  movaps xmm8, [r15+0x2E0]
0000747fd7fdbcd5  vmovaps [rsp+0x90], xmm8
0000747fd7fdbcde  vmovaps xmm2, [rsp+0x90]
0000747fd7fdbce7  por xmm8, xmm2
0000747fd7fdbcec  movaps xmm2, [r15+0x2D0]
0000747fd7fdbcf4  vmovaps [rsp+0x90], xmm2
0000747fd7fdbcfd  vmovaps [rsp+0xA0], xmm1
0000747fd7fdbd06  vmovaps xmm1, [rsp+0x90]
0000747fd7fdbd0f  por xmm2, xmm1
0000747fd7fdbd13  movaps xmm1, [r15+0x200]
0000747fd7fdbd1b  vmovaps [rsp+0x90], xmm1
0000747fd7fdbd24  vmovaps [rsp+0xB0], xmm15
0000747fd7fdbd2d  vmovaps xmm15, [rsp+0x90]
0000747fd7fdbd36  por xmm1, xmm15
0000747fd7fdbd3b  movaps xmm15, [r15+0x1C0]
0000747fd7fdbd43  vmovaps [rsp+0x90], xmm15
0000747fd7fdbd4c  vmovaps [rsp+0xC0], xmm1
0000747fd7fdbd55  vmovaps xmm1, [rsp+0x90]
0000747fd7fdbd5e  por xmm15, xmm1
0000747fd7fdbd63  movaps xmm1, [r15+0x190]
0000747fd7fdbd6b  vmovaps [rsp+0x90], xmm1
0000747fd7fdbd74  vmovaps [rsp+0xD0], xmm15
0000747fd7fdbd7d  vmovaps xmm15, [rsp+0x90]
0000747fd7fdbd86  por xmm1, xmm15
0000747fd7fdbd8b  movaps xmm15, [r15+0x300]
0000747fd7fdbd93  vmovaps [rsp+0x90], xmm15
0000747fd7fdbd9c  vmovaps [rsp+0xE0], xmm1
0000747fd7fdbda5  vmovaps xmm1, [rsp+0x90]
0000747fd7fdbdae  por xmm15, xmm1
0000747fd7fdbdb3  mov rax, [rsp+0x80]
0000747fd7fdbdbb  lea r12, [rax+0xA0]
0000747fd7fdbdc2  movups xmm1, [r13+r12*1]
0000747fd7fdbdc8  lea r12, [rax+0xB0]
0000747fd7fdbdcf  vmovaps [rsp+0x80], xmm1
0000747fd7fdbdd8  movups xmm1, [r13+r12*1]
0000747fd7fdbdde  vmovaps [rsp+0x90], xmm1
0000747fd7fdbde7  vmovaps [rsp+0xF0], xmm15
0000747fd7fdbdf0  vmovaps xmm15, [rsp+0xB0]
0000747fd7fdbdf9  vmovaps [rsp+0xB0], xmm14
0000747fd7fdbe02  movaps xmm1, xmm6
0000747fd7fdbe05  addpd xmm1, xmm15
0000747fd7fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000747fd7fdbe0f  ptest xmm14, xmm14
0000747fd7fdbe15  jnz 0x0000747FD7FDD4D6
0000747fd7fdbe1b  lea r12, [rax+0xF0]
0000747fd7fdbe22  movups xmm15, [r13+r12*1]
0000747fd7fdbe28  movaps xmm14, xmm4
0000747fd7fdbe2c  addpd xmm14, xmm3
0000747fd7fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000747fd7fdbe37  ptest xmm6, xmm6
0000747fd7fdbe3c  jnz 0x0000747FD7FDD621
0000747fd7fdbe42  movaps xmm6, xmm9
0000747fd7fdbe46  addpd xmm6, xmm7
0000747fd7fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000747fd7fdbe4f  ptest xmm4, xmm4
0000747fd7fdbe54  jnz 0x0000747FD7FDD763
0000747fd7fdbe5a  vmovaps xmm9, [rsp+0x70]
0000747fd7fdbe60  vpermilpd xmm9, xmm9, 0x00
0000747fd7fdbe66  vmovaps xmm4, [rsp+0x90]
0000747fd7fdbe6f  movaps xmm7, xmm4
0000747fd7fdbe72  mulpd xmm7, xmm9
0000747fd7fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000747fd7fdbe7c  ptest xmm3, xmm3
0000747fd7fdbe81  jnz 0x0000747FD7FDD8A4
0000747fd7fdbe87  vmovaps xmm9, [rsp+0x50]
0000747fd7fdbe8d  vpermilpd xmm9, xmm9, 0x00
0000747fd7fdbe93  movaps xmm4, xmm15
0000747fd7fdbe97  mulpd xmm4, xmm9
0000747fd7fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000747fd7fdbea1  ptest xmm3, xmm3
0000747fd7fdbea6  jnz 0x0000747FD7FDD9E5
0000747fd7fdbeac  lea r12, [rax+0xE0]
0000747fd7fdbeb3  movups xmm15, [r13+r12*1]
0000747fd7fdbeb9  vmovaps xmm9, [rsp+0x70]
0000747fd7fdbebf  vpermilpd xmm9, xmm9, 0x00
0000747fd7fdbec5  vmovaps [rsp+0x70], xmm1
0000747fd7fdbecb  vmovaps xmm1, [rsp+0x80]
0000747fd7fdbed4  vmovaps [rsp+0x80], xmm15
0000747fd7fdbedd  movaps xmm3, xmm1
0000747fd7fdbee0  mulpd xmm3, xmm9
0000747fd7fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000747fd7fdbeea  ptest xmm15, xmm15
0000747fd7fdbef0  jnz 0x0000747FD7FDDB31
0000747fd7fdbef6  vmovaps xmm1, [rsp+0xF0]
0000747fd7fdbeff  vmovaps xmm15, [rsp+0xF0]
0000747fd7fdbf08  por xmm1, xmm15
0000747fd7fdbf0d  movaps [r15+0x300], xmm1
0000747fd7fdbf15  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdbf1e  vmovaps xmm9, [rsp+0xE0]
0000747fd7fdbf27  por xmm15, xmm9
0000747fd7fdbf2c  movaps [r15+0x190], xmm15
0000747fd7fdbf34  vmovaps xmm9, [rsp+0x50]
0000747fd7fdbf3a  vpermilpd xmm9, xmm9, 0x00
0000747fd7fdbf40  vmovaps [rsp+0x90], xmm1
0000747fd7fdbf49  vmovaps [rsp+0xE0], xmm15
0000747fd7fdbf52  vmovaps xmm15, [rsp+0x80]
0000747fd7fdbf5b  vmovaps [rsp+0x80], xmm14
0000747fd7fdbf64  movaps xmm1, xmm15
0000747fd7fdbf68  mulpd xmm1, xmm9
0000747fd7fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000747fd7fdbf72  ptest xmm14, xmm14
0000747fd7fdbf78  jnz 0x0000747FD7FDDC72
0000747fd7fdbf7e  lea r12, [rax+0x90]
0000747fd7fdbf85  movups xmm15, [r13+r12*1]
0000747fd7fdbf8b  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdbf94  vmovaps xmm9, [rsp+0xD0]
0000747fd7fdbf9d  por xmm14, xmm9
0000747fd7fdbfa2  movaps [r15+0x1C0], xmm14
0000747fd7fdbfaa  vmovaps xmm9, [rsp+0xC0]
0000747fd7fdbfb3  vmovaps [rsp+0xD0], xmm1
0000747fd7fdbfbc  vmovaps xmm1, [rsp+0xC0]
0000747fd7fdbfc5  por xmm9, xmm1
0000747fd7fdbfca  movaps [r15+0x200], xmm9
0000747fd7fdbfd2  vmovaps [rsp+0xC0], xmm2
0000747fd7fdbfdb  vmovaps xmm1, [rsp+0xC0]
0000747fd7fdbfe4  por xmm2, xmm1
0000747fd7fdbfe8  movaps [r15+0x2D0], xmm2
0000747fd7fdbff0  vmovaps [rsp+0xC0], xmm8
0000747fd7fdbff9  vmovaps xmm1, [rsp+0xC0]
0000747fd7fdc002  por xmm8, xmm1
0000747fd7fdc007  movaps [r15+0x2E0], xmm8
0000747fd7fdc00f  vmovaps [rsp+0xC0], xmm15
0000747fd7fdc018  movaps xmm1, xmm5
0000747fd7fdc01b  addpd xmm1, xmm7
0000747fd7fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000747fd7fdc024  ptest xmm15, xmm15
0000747fd7fdc02a  jnz 0x0000747FD7FDDDBE
0000747fd7fdc030  vmovaps xmm15, [rsp+0x50]
0000747fd7fdc036  vpermilpd xmm15, xmm15, 0x00
0000747fd7fdc03c  vmovaps xmm5, [rsp+0xC0]
0000747fd7fdc045  vmovaps [rsp+0xC0], xmm1
0000747fd7fdc04e  movaps xmm7, xmm5
0000747fd7fdc051  mulpd xmm7, xmm15
0000747fd7fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000747fd7fdc05b  ptest xmm1, xmm1
0000747fd7fdc060  jnz 0x0000747FD7FDDEFE
0000747fd7fdc066  lea r12, [rax+0x80]
0000747fd7fdc06d  movups xmm1, [r13+r12*1]
0000747fd7fdc073  vmovaps xmm5, [rsp+0x70]
0000747fd7fdc079  vmovaps [rsp+0x70], xmm1
0000747fd7fdc07f  movaps xmm15, xmm5
0000747fd7fdc083  addpd xmm15, xmm3
0000747fd7fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000747fd7fdc08e  ptest xmm1, xmm1
0000747fd7fdc093  jnz 0x0000747FD7FDE049
0000747fd7fdc099  vmovaps xmm5, [rsp+0x80]
0000747fd7fdc0a2  movaps xmm1, xmm5
0000747fd7fdc0a5  addpd xmm1, xmm4
0000747fd7fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000747fd7fdc0ae  ptest xmm3, xmm3
0000747fd7fdc0b3  jnz 0x0000747FD7FDE18B
0000747fd7fdc0b9  vmovaps [rsp+0x80], xmm10
0000747fd7fdc0c2  vmovaps xmm5, [rsp+0x80]
0000747fd7fdc0cb  por xmm10, xmm5
0000747fd7fdc0d0  movaps [r15+0x2F0], xmm10
0000747fd7fdc0d8  vmovaps xmm5, [rsp+0x50]
0000747fd7fdc0de  vpermilpd xmm5, xmm5, 0x00
0000747fd7fdc0e4  vmovaps xmm3, [rsp+0x70]
0000747fd7fdc0ea  vmovaps [rsp+0x50], xmm1
0000747fd7fdc0f0  movaps xmm4, xmm3
0000747fd7fdc0f3  mulpd xmm4, xmm5
0000747fd7fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000747fd7fdc0fc  ptest xmm1, xmm1
0000747fd7fdc101  jnz 0x0000747FD7FDE2CB
0000747fd7fdc107  lea r12, [rax+0xD0]
0000747fd7fdc10e  movups xmm1, [r13+r12*1]
0000747fd7fdc114  vmovaps xmm3, [rsp+0xD0]
0000747fd7fdc11d  vmovaps [rsp+0x70], xmm1
0000747fd7fdc123  movaps xmm5, xmm6
0000747fd7fdc126  addpd xmm5, xmm3
0000747fd7fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000747fd7fdc12f  ptest xmm1, xmm1
0000747fd7fdc134  jnz 0x0000747FD7FDE415
0000747fd7fdc13a  vmovaps xmm1, [rsp+0x60]
0000747fd7fdc140  vpermilpd xmm1, xmm1, 0x00
0000747fd7fdc146  movaps xmm6, xmm9
0000747fd7fdc14a  mulpd xmm6, xmm1
0000747fd7fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000747fd7fdc153  ptest xmm3, xmm3
0000747fd7fdc158  jnz 0x0000747FD7FDE555
0000747fd7fdc15e  movaps [r15+0x260], xmm6
0000747fd7fdc166  vxorps xmm1, xmm1, xmm1
0000747fd7fdc16a  vpbroadcastq xmm1, xmm1
0000747fd7fdc16f  movaps [r15+0x1B0], xmm1
0000747fd7fdc177  vmovaps xmm1, [rsp+0x60]
0000747fd7fdc17d  vpermilpd xmm1, xmm1, 0x00
0000747fd7fdc183  vmovaps xmm3, [rsp+0x70]
0000747fd7fdc189  vmovaps [rsp+0x70], xmm15
0000747fd7fdc18f  movaps xmm9, xmm3
0000747fd7fdc193  mulpd xmm9, xmm1
0000747fd7fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000747fd7fdc19e  ptest xmm15, xmm15
0000747fd7fdc1a4  jnz 0x0000747FD7FDE696
0000747fd7fdc1aa  lea r12, [rax+0xC0]
0000747fd7fdc1b1  movups xmm1, [r13+r12*1]
0000747fd7fdc1b7  vmovaps xmm3, [rsp+0xC0]
0000747fd7fdc1c0  vmovaps [rsp+0x80], xmm1
0000747fd7fdc1c9  movaps xmm15, xmm3
0000747fd7fdc1cd  addpd xmm15, xmm7
0000747fd7fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000747fd7fdc1d8  ptest xmm1, xmm1
0000747fd7fdc1dd  jnz 0x0000747FD7FDE7E2
0000747fd7fdc1e3  vmovaps [rsp+0xC0], xmm13
0000747fd7fdc1ec  vmovaps xmm1, [rsp+0xC0]
0000747fd7fdc1f5  por xmm13, xmm1
0000747fd7fdc1fa  movaps [r15+0x270], xmm13
0000747fd7fdc202  vmovaps xmm1, [rsp+0xB0]
0000747fd7fdc20b  vmovaps xmm7, [rsp+0xB0]
0000747fd7fdc214  por xmm1, xmm7
0000747fd7fdc218  movaps [r15+0x1A0], xmm1
0000747fd7fdc220  vmovaps xmm1, [rsp+0x60]
0000747fd7fdc226  vpermilpd xmm1, xmm1, 0x00
0000747fd7fdc22c  vmovaps [rsp+0xB0], xmm1
0000747fd7fdc235  vmovaps xmm1, [rsp+0x80]
0000747fd7fdc23e  vmovaps [rsp+0x80], xmm15
0000747fd7fdc247  vmovaps xmm15, [rsp+0xB0]
0000747fd7fdc250  vmovaps [rsp+0xB0], xmm14
0000747fd7fdc259  movaps xmm3, xmm1
0000747fd7fdc25c  mulpd xmm3, xmm15
0000747fd7fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000747fd7fdc266  ptest xmm14, xmm14
0000747fd7fdc26c  jnz 0x0000747FD7FDE924
0000747fd7fdc272  lea r12, [rax+0x20]
0000747fd7fdc276  movups xmm1, [r13+r12*1]
0000747fd7fdc27c  movaps [r15+0x110], xmm1
0000747fd7fdc284  vmovaps xmm14, [rsp+0x70]
0000747fd7fdc28a  vmovaps [rsp+0x70], xmm1
0000747fd7fdc290  movaps xmm15, xmm14
0000747fd7fdc294  addpd xmm15, xmm4
0000747fd7fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000747fd7fdc29f  ptest xmm1, xmm1
0000747fd7fdc2a4  jnz 0x0000747FD7FDEA6F
0000747fd7fdc2aa  vmovaps xmm1, [rsp+0x60]
0000747fd7fdc2b0  vpermilpd xmm1, xmm1, 0x00
0000747fd7fdc2b6  movaps xmm14, xmm2
0000747fd7fdc2ba  mulpd xmm14, xmm1
0000747fd7fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000747fd7fdc2c5  ptest xmm4, xmm4
0000747fd7fdc2ca  jnz 0x0000747FD7FDEBB2
0000747fd7fdc2d0  vmovaps xmm4, [rsp+0x50]
0000747fd7fdc2d6  movaps xmm1, xmm4
0000747fd7fdc2d9  addpd xmm1, xmm9
0000747fd7fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000747fd7fdc2e3  ptest xmm2, xmm2
0000747fd7fdc2e8  jnz 0x0000747FD7FDECF4
0000747fd7fdc2ee  vmovaps xmm9, [rsp+0x30]
0000747fd7fdc2f4  vpermilpd xmm9, xmm9, 0x00
0000747fd7fdc2fa  vmovaps xmm2, [rsp+0x70]
0000747fd7fdc300  vmovaps [rsp+0x50], xmm1
0000747fd7fdc306  movaps xmm4, xmm2
0000747fd7fdc309  mulpd xmm4, xmm9
0000747fd7fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000747fd7fdc313  ptest xmm1, xmm1
0000747fd7fdc318  jnz 0x0000747FD7FDEE35
0000747fd7fdc31e  vmovaps xmm1, [rsp+0x30]
0000747fd7fdc324  vpermilpd xmm1, xmm1, 0x00
0000747fd7fdc32a  vmovaps xmm2, [rsp+0x90]
0000747fd7fdc333  vmovaps [rsp+0x60], xmm15
0000747fd7fdc339  movaps xmm9, xmm2
0000747fd7fdc33d  mulpd xmm9, xmm1
0000747fd7fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000747fd7fdc348  ptest xmm15, xmm15
0000747fd7fdc34e  jnz 0x0000747FD7FDEF76
0000747fd7fdc354  vmovaps xmm15, [rsp+0x80]
0000747fd7fdc35d  movaps xmm1, xmm15
0000747fd7fdc361  addpd xmm1, xmm6
0000747fd7fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000747fd7fdc36a  ptest xmm2, xmm2
0000747fd7fdc36f  jnz 0x0000747FD7FDF0B8
0000747fd7fdc375  movaps xmm15, xmm5
0000747fd7fdc379  addpd xmm15, xmm3
0000747fd7fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000747fd7fdc384  ptest xmm6, xmm6
0000747fd7fdc389  jnz 0x0000747FD7FDF1F9
0000747fd7fdc38f  vmovaps xmm6, [rsp+0x30]
0000747fd7fdc395  vpermilpd xmm6, xmm6, 0x00
0000747fd7fdc39b  movaps xmm5, xmm8
0000747fd7fdc39f  mulpd xmm5, xmm6
0000747fd7fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000747fd7fdc3a8  ptest xmm3, xmm3
0000747fd7fdc3ad  jnz 0x0000747FD7FDF33B
0000747fd7fdc3b3  vmovaps xmm8, [rsp+0x30]
0000747fd7fdc3b9  vpermilpd xmm8, xmm8, 0x00
0000747fd7fdc3bf  movaps xmm6, xmm10
0000747fd7fdc3c3  mulpd xmm6, xmm8
0000747fd7fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000747fd7fdc3cd  ptest xmm3, xmm3
0000747fd7fdc3d2  jnz 0x0000747FD7FDF47C
0000747fd7fdc3d8  vmovaps xmm8, [rsp+0x60]
0000747fd7fdc3de  movaps xmm10, xmm8
0000747fd7fdc3e2  addpd xmm10, xmm14
0000747fd7fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000747fd7fdc3ed  ptest xmm3, xmm3
0000747fd7fdc3f2  jnz 0x0000747FD7FDF5BE
0000747fd7fdc3f8  vmovaps xmm8, [rsp+0x50]
0000747fd7fdc3fe  movaps xmm14, xmm8
0000747fd7fdc402  addpd xmm14, xmm4
0000747fd7fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000747fd7fdc40d  ptest xmm3, xmm3
0000747fd7fdc412  jnz 0x0000747FD7FDF702
0000747fd7fdc418  vmovaps xmm8, [rsp+0x40]
0000747fd7fdc41e  vpermilpd xmm8, xmm8, 0x00
0000747fd7fdc424  movaps xmm4, xmm13
0000747fd7fdc428  mulpd xmm4, xmm8
0000747fd7fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000747fd7fdc432  ptest xmm3, xmm3
0000747fd7fdc437  jnz 0x0000747FD7FDF845
0000747fd7fdc43d  movaps xmm13, xmm15
0000747fd7fdc441  addpd xmm13, xmm9
0000747fd7fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000747fd7fdc44c  ptest xmm8, xmm8
0000747fd7fdc452  jnz 0x0000747FD7FDF987
0000747fd7fdc458  movaps xmm15, xmm1
0000747fd7fdc45c  addpd xmm15, xmm5
0000747fd7fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000747fd7fdc467  ptest xmm9, xmm9
0000747fd7fdc46d  jnz 0x0000747FD7FDFACB
0000747fd7fdc473  vmovaps [rsp+0x30], xmm11
0000747fd7fdc479  vmovaps xmm1, [rsp+0x30]
0000747fd7fdc47f  por xmm11, xmm1
0000747fd7fdc484  movaps [r15+0x250], xmm11
0000747fd7fdc48c  vmovaps [rsp+0x30], xmm12
0000747fd7fdc492  vmovaps xmm1, [rsp+0x30]
0000747fd7fdc498  por xmm12, xmm1
0000747fd7fdc49d  movaps [r15+0x2A0], xmm12
0000747fd7fdc4a5  vmovaps xmm1, [rsp+0xA0]
0000747fd7fdc4ae  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdc4b7  por xmm1, xmm11
0000747fd7fdc4bc  movaps [r15+0x1D0], xmm1
0000747fd7fdc4c4  lea r12, [rax+0x40]
0000747fd7fdc4c8  movups xmm1, [r13+r12*1]
0000747fd7fdc4ce  movaps [r15+0x2C0], xmm1
0000747fd7fdc4d6  vmovaps xmm11, [rsp+0x40]
0000747fd7fdc4dc  vpermilpd xmm11, xmm11, 0x00
0000747fd7fdc4e2  vmovaps xmm8, [rsp+0xE0]
0000747fd7fdc4eb  movaps xmm9, xmm8
0000747fd7fdc4ef  mulpd xmm9, xmm11
0000747fd7fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000747fd7fdc4fa  ptest xmm5, xmm5
0000747fd7fdc4ff  jnz 0x0000747FD7FDFC17
0000747fd7fdc505  movaps xmm11, xmm10
0000747fd7fdc509  addpd xmm11, xmm6
0000747fd7fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000747fd7fdc514  ptest xmm8, xmm8
0000747fd7fdc51a  jnz 0x0000747FD7FDFD5B
0000747fd7fdc520  movaps xmm10, xmm14
0000747fd7fdc524  addpd xmm10, xmm4
0000747fd7fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000747fd7fdc52f  ptest xmm8, xmm8
0000747fd7fdc535  jnz 0x0000747FD7FDFE9E
0000747fd7fdc53b  vmovaps xmm14, [rsp+0x40]
0000747fd7fdc541  vpermilpd xmm14, xmm14, 0x00
0000747fd7fdc547  movaps xmm8, xmm1
0000747fd7fdc54b  mulpd xmm8, xmm14
0000747fd7fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000747fd7fdc556  ptest xmm6, xmm6
0000747fd7fdc55b  jnz 0x0000747FD7FDFFE1
0000747fd7fdc561  movaps xmm1, [r15+0x2B0]
0000747fd7fdc569  vmovaps xmm14, [rsp+0x40]
0000747fd7fdc56f  vpermilpd xmm14, xmm14, 0x00
0000747fd7fdc575  movaps xmm6, xmm1
0000747fd7fdc578  mulpd xmm6, xmm14
0000747fd7fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000747fd7fdc582  ptest xmm5, xmm5
0000747fd7fdc587  jnz 0x0000747FD7FE0124
0000747fd7fdc58d  vmovaps xmm1, [rsp+0x10]
0000747fd7fdc593  vpermilpd xmm1, xmm1, 0x00
0000747fd7fdc599  movaps xmm14, xmm12
0000747fd7fdc59d  mulpd xmm14, xmm1
0000747fd7fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000747fd7fdc5a8  ptest xmm5, xmm5
0000747fd7fdc5ad  jnz 0x0000747FD7FE0265
0000747fd7fdc5b3  movaps xmm1, xmm13
0000747fd7fdc5b7  addpd xmm1, xmm9
0000747fd7fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000747fd7fdc5c1  ptest xmm12, xmm12
0000747fd7fdc5c7  jnz 0x0000747FD7FE03A8
0000747fd7fdc5cd  vmovaps xmm13, [rsp+0x10]
0000747fd7fdc5d3  vpermilpd xmm13, xmm13, 0x00
0000747fd7fdc5d9  movaps xmm12, xmm7
0000747fd7fdc5dd  mulpd xmm12, xmm13
0000747fd7fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000747fd7fdc5e8  ptest xmm9, xmm9
0000747fd7fdc5ee  jnz 0x0000747FD7FE04EA
0000747fd7fdc5f4  movaps xmm13, xmm15
0000747fd7fdc5f8  addpd xmm13, xmm8
0000747fd7fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000747fd7fdc603  ptest xmm9, xmm9
0000747fd7fdc609  jnz 0x0000747FD7FE062D
0000747fd7fdc60f  movaps xmm15, [r15+0x290]
0000747fd7fdc617  vmovaps xmm9, [rsp+0x10]
0000747fd7fdc61d  vpermilpd xmm9, xmm9, 0x00
0000747fd7fdc623  movaps xmm8, xmm15
0000747fd7fdc627  mulpd xmm8, xmm9
0000747fd7fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000747fd7fdc632  ptest xmm7, xmm7
0000747fd7fdc637  jnz 0x0000747FD7FE0771
0000747fd7fdc63d  movaps xmm15, xmm11
0000747fd7fdc641  addpd xmm15, xmm6
0000747fd7fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000747fd7fdc64c  ptest xmm9, xmm9
0000747fd7fdc652  jnz 0x0000747FD7FE08B5
0000747fd7fdc658  movaps xmm11, [r15+0x1E0]
0000747fd7fdc660  vmovaps xmm9, [rsp+0x10]
0000747fd7fdc666  vpermilpd xmm9, xmm9, 0x00
0000747fd7fdc66c  movaps xmm7, xmm11
0000747fd7fdc670  mulpd xmm7, xmm9
0000747fd7fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000747fd7fdc67a  ptest xmm6, xmm6
0000747fd7fdc67f  jnz 0x0000747FD7FE09F8
0000747fd7fdc685  movaps xmm11, xmm10
0000747fd7fdc689  addpd xmm11, xmm14
0000747fd7fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000747fd7fdc694  ptest xmm9, xmm9
0000747fd7fdc69a  jnz 0x0000747FD7FE0B3A
0000747fd7fdc6a0  lea r12, [rax+0x70]
0000747fd7fdc6a4  movups xmm14, [r13+r12*1]
0000747fd7fdc6aa  movaps [r15+0x240], xmm14
0000747fd7fdc6b2  movaps xmm10, xmm1
0000747fd7fdc6b6  addpd xmm10, xmm12
0000747fd7fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000747fd7fdc6c1  ptest xmm9, xmm9
0000747fd7fdc6c7  jnz 0x0000747FD7FE0C88
0000747fd7fdc6cd  movaps [r15+0x170], xmm10
0000747fd7fdc6d5  vmovaps xmm1, [rsp+0x20]
0000747fd7fdc6db  vpermilpd xmm1, xmm1, 0x00
0000747fd7fdc6e1  movaps xmm12, xmm14
0000747fd7fdc6e5  mulpd xmm12, xmm1
0000747fd7fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000747fd7fdc6f0  ptest xmm9, xmm9
0000747fd7fdc6f6  jnz 0x0000747FD7FE0DCB
0000747fd7fdc6fc  vmovaps xmm1, [rsp+0x20]
0000747fd7fdc702  vpermilpd xmm1, xmm1, 0x00
0000747fd7fdc708  vmovaps xmm9, [rsp+0xB0]
0000747fd7fdc711  movaps xmm14, xmm9
0000747fd7fdc715  mulpd xmm14, xmm1
0000747fd7fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000747fd7fdc720  ptest xmm6, xmm6
0000747fd7fdc725  jnz 0x0000747FD7FE0F0E
0000747fd7fdc72b  movaps [r15+0x180], xmm14
0000747fd7fdc733  movaps xmm1, xmm13
0000747fd7fdc737  addpd xmm1, xmm8
0000747fd7fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000747fd7fdc741  ptest xmm9, xmm9
0000747fd7fdc747  jnz 0x0000747FD7FE1051
0000747fd7fdc74d  movaps [r15+0x210], xmm1
0000747fd7fdc755  movups xmm13, [r13+rax*1]
0000747fd7fdc75b  lea r12, [rax+0x10]
0000747fd7fdc75f  movups xmm9, [r13+r12*1]
0000747fd7fdc765  movaps [r15+0x230], xmm9
0000747fd7fdc76d  movaps xmm8, xmm15
0000747fd7fdc771  addpd xmm8, xmm7
0000747fd7fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000747fd7fdc77c  ptest xmm6, xmm6
0000747fd7fdc781  jnz 0x0000747FD7FE11A7
0000747fd7fdc787  movaps [r15+0x130], xmm8
0000747fd7fdc78f  vmovaps xmm15, [rsp+0x20]
0000747fd7fdc795  vpermilpd xmm15, xmm15, 0x00
0000747fd7fdc79b  movaps xmm7, xmm9
0000747fd7fdc79f  mulpd xmm7, xmm15
0000747fd7fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000747fd7fdc7a9  ptest xmm6, xmm6
0000747fd7fdc7ae  jnz 0x0000747FD7FE12EA
0000747fd7fdc7b4  movaps [r15+0x220], xmm7
0000747fd7fdc7bc  vmovaps xmm15, [rsp+0x20]
0000747fd7fdc7c2  vpermilpd xmm15, xmm15, 0x00
0000747fd7fdc7c8  movaps xmm9, xmm13
0000747fd7fdc7cc  mulpd xmm9, xmm15
0000747fd7fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000747fd7fdc7d7  ptest xmm6, xmm6
0000747fd7fdc7dc  jnz 0x0000747FD7FE142C
0000747fd7fdc7e2  movaps xmm15, xmm11
0000747fd7fdc7e6  addpd xmm15, xmm12
0000747fd7fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000747fd7fdc7f1  ptest xmm13, xmm13
0000747fd7fdc7f7  jnz 0x0000747FD7FE1570
0000747fd7fdc7fd  movaps [r15+0x140], xmm15
0000747fd7fdc805  movaps xmm13, xmm10
0000747fd7fdc809  addpd xmm13, xmm14
0000747fd7fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000747fd7fdc814  ptest xmm12, xmm12
0000747fd7fdc81a  jnz 0x0000747FD7FE16B4
0000747fd7fdc820  movaps [r15+0x150], xmm13
0000747fd7fdc828  movaps xmm14, xmm1
0000747fd7fdc82c  addpd xmm14, xmm7
0000747fd7fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000747fd7fdc837  ptest xmm12, xmm12
0000747fd7fdc83d  jnz 0x0000747FD7FE17F8
0000747fd7fdc843  movaps [r15+0x160], xmm14
0000747fd7fdc84b  movaps xmm1, xmm8
0000747fd7fdc84f  addpd xmm1, xmm9
0000747fd7fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000747fd7fdc859  ptest xmm12, xmm12
0000747fd7fdc85f  jnz 0x0000747FD7FE193A
0000747fd7fdc865  movaps [r15+0x120], xmm1
0000747fd7fdc86d  movups [r13+r14*1], xmm15
0000747fd7fdc873  lea rax, [r14+0x10]
0000747fd7fdc877  movups [r13+rax*1], xmm13
0000747fd7fdc87d  lea rax, [r14+0x20]
0000747fd7fdc881  movups [r13+rax*1], xmm14
0000747fd7fdc887  lea rax, [r14+0x30]
0000747fd7fdc88b  movups [r13+rax*1], xmm1
0000747fd7fdc891  mov eax, [r15+0x108]
0000747fd7fdc898  sahf
0000747fd7fdc899  jnz 0x0000747FD7FDC8CB
0000747fd7fdc89b  cmp dword ptr [r15+0x318], 0x00
0000747fd7fdc8a3  jz 0x0000747FD7FDB900
0000747fd7fdc8a9  nop [rax+rax*1], ax
0000747fd7fdc8b2  nop [rax+rax*1], eax
0000747fd7fdc8ba  mov eax, 0x410444
0000747fd7fdc8bf  mov [r15+0x100], rax
0000747fd7fdc8c6  jmp 0x0000747FD7DFE110
0000747fd7fdc8cb  cmp dword ptr [r15+0x318], 0x00
0000747fd7fdc8d3  jz 0x0000747FD7FD57E0
0000747fd7fdc8d9  nop [rax+rax*1], ax
0000747fd7fdc8e2  nop [rax+rax*1], eax
0000747fd7fdc8ea  mov eax, 0x410278
0000747fd7fdc8ef  mov [r15+0x100], rax
0000747fd7fdc8f6  jmp 0x0000747FD7DFE110
0000747fd7fdc8fb  int3
0000747fd7fdc8fc  call 0x0000747FD7EE27E0
0000747fd7fdc901  jmp 0x0000747FD7FDB9DF
0000747fd7fdc906  call 0x0000747FD7EE1570
0000747fd7fdc90b  jmp 0x0000747FD7FDB9E8
0000747fd7fdc910  call 0x0000747FD7EE27E0
0000747fd7fdc915  jmp 0x0000747FD7FDBA44
0000747fd7fdc91a  call 0x0000747FD7EE1570
0000747fd7fdc91f  jmp 0x0000747FD7FDBA4D
0000747fd7fdc924  call 0x0000747FD7EE27E0
0000747fd7fdc929  jmp 0x0000747FD7FDBA90
0000747fd7fdc92e  call 0x0000747FD7EE1570
0000747fd7fdc933  jmp 0x0000747FD7FDBA99
0000747fd7fdc938  call 0x0000747FD7E0DC20
0000747fd7fdc93d  jmp 0x0000747FD7FDBAD8
0000747fd7fdc942  call 0x0000747FD7ED59C0
0000747fd7fdc947  jmp 0x0000747FD7FDBAEB
0000747fd7fdc94c  call 0x0000747FD7EE0E30
0000747fd7fdc951  jmp 0x0000747FD7FDBB09
0000747fd7fdc956  call 0x0000747FD7EDFBC0
0000747fd7fdc95b  jmp 0x0000747FD7FDBB13
0000747fd7fdc960  call 0x0000747FD7EDE950
0000747fd7fdc965  jmp 0x0000747FD7FDBB1D
0000747fd7fdc96a  sub rsp, 0x08
0000747fd7fdc96e  push rax
0000747fd7fdc96f  push rcx
0000747fd7fdc970  push rdx
0000747fd7fdc971  push rdi
0000747fd7fdc972  push rsi
0000747fd7fdc973  push r8
0000747fd7fdc975  push r9
0000747fd7fdc977  push r10
0000747fd7fdc979  push r11
0000747fd7fdc97b  sub rsp, 0xF0
0000747fd7fdc982  vmovaps [rsp], xmm0
0000747fd7fdc987  vmovaps [rsp+0x10], xmm1
0000747fd7fdc98d  vmovaps [rsp+0x20], xmm2
0000747fd7fdc993  vmovaps [rsp+0x30], xmm3
0000747fd7fdc999  vmovaps [rsp+0x40], xmm4
0000747fd7fdc99f  vmovaps [rsp+0x50], xmm5
0000747fd7fdc9a5  vmovaps [rsp+0x60], xmm6
0000747fd7fdc9ab  vmovaps [rsp+0x70], xmm7
0000747fd7fdc9b1  vmovaps [rsp+0x80], xmm9
0000747fd7fdc9ba  vmovaps [rsp+0x90], xmm10
0000747fd7fdc9c3  vmovaps [rsp+0xA0], xmm11
0000747fd7fdc9cc  vmovaps [rsp+0xB0], xmm12
0000747fd7fdc9d5  vmovaps [rsp+0xC0], xmm13
0000747fd7fdc9de  vmovaps [rsp+0xD0], xmm14
0000747fd7fdc9e7  vmovaps [rsp+0xE0], xmm15
0000747fd7fdc9f0  sub rsp, 0x30
0000747fd7fdc9f4  movaps [rsp], xmm8
0000747fd7fdc9f9  movaps [rsp+0x10], xmm12
0000747fd7fdc9ff  movaps [rsp+0x20], xmm15
0000747fd7fdca05  lea rdi, [rsp]
0000747fd7fdca09  mov esi, 0x00
0000747fd7fdca0e  mov rax, 0x6055A0B6E530
0000747fd7fdca18  call rax
0000747fd7fdca1a  movaps xmm8, [rsp]
0000747fd7fdca1f  add rsp, 0x30
0000747fd7fdca23  vmovaps xmm0, [rsp]
0000747fd7fdca28  vmovaps xmm1, [rsp+0x10]
0000747fd7fdca2e  vmovaps xmm2, [rsp+0x20]
0000747fd7fdca34  vmovaps xmm3, [rsp+0x30]
0000747fd7fdca3a  vmovaps xmm4, [rsp+0x40]
0000747fd7fdca40  vmovaps xmm5, [rsp+0x50]
0000747fd7fdca46  vmovaps xmm6, [rsp+0x60]
0000747fd7fdca4c  vmovaps xmm7, [rsp+0x70]
0000747fd7fdca52  vmovaps xmm9, [rsp+0x80]
0000747fd7fdca5b  vmovaps xmm10, [rsp+0x90]
0000747fd7fdca64  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdca6d  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdca76  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdca7f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdca88  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdca91  add rsp, 0xF0
0000747fd7fdca98  pop r11
0000747fd7fdca9a  pop r10
0000747fd7fdca9c  pop r9
0000747fd7fdca9e  pop r8
0000747fd7fdcaa0  pop rsi
0000747fd7fdcaa1  pop rdi
0000747fd7fdcaa2  pop rdx
0000747fd7fdcaa3  pop rcx
0000747fd7fdcaa4  pop rax
0000747fd7fdcaa5  add rsp, 0x08
0000747fd7fdcaa9  jmp 0x0000747FD7FDBB47
0000747fd7fdcaae  sub rsp, 0x08
0000747fd7fdcab2  push rax
0000747fd7fdcab3  push rcx
0000747fd7fdcab4  push rdx
0000747fd7fdcab5  push rdi
0000747fd7fdcab6  push rsi
0000747fd7fdcab7  push r8
0000747fd7fdcab9  push r9
0000747fd7fdcabb  push r10
0000747fd7fdcabd  push r11
0000747fd7fdcabf  sub rsp, 0xF0
0000747fd7fdcac6  vmovaps [rsp], xmm0
0000747fd7fdcacb  vmovaps [rsp+0x10], xmm1
0000747fd7fdcad1  vmovaps [rsp+0x20], xmm2
0000747fd7fdcad7  vmovaps [rsp+0x30], xmm3
0000747fd7fdcadd  vmovaps [rsp+0x40], xmm4
0000747fd7fdcae3  vmovaps [rsp+0x50], xmm5
0000747fd7fdcae9  vmovaps [rsp+0x60], xmm6
0000747fd7fdcaef  vmovaps [rsp+0x70], xmm8
0000747fd7fdcaf5  vmovaps [rsp+0x80], xmm9
0000747fd7fdcafe  vmovaps [rsp+0x90], xmm10
0000747fd7fdcb07  vmovaps [rsp+0xA0], xmm11
0000747fd7fdcb10  vmovaps [rsp+0xB0], xmm12
0000747fd7fdcb19  vmovaps [rsp+0xC0], xmm13
0000747fd7fdcb22  vmovaps [rsp+0xD0], xmm14
0000747fd7fdcb2b  vmovaps [rsp+0xE0], xmm15
0000747fd7fdcb34  sub rsp, 0x30
0000747fd7fdcb38  movaps [rsp], xmm7
0000747fd7fdcb3c  movaps [rsp+0x10], xmm9
0000747fd7fdcb42  movaps [rsp+0x20], xmm15
0000747fd7fdcb48  lea rdi, [rsp]
0000747fd7fdcb4c  mov esi, 0x00
0000747fd7fdcb51  mov rax, 0x6055A0B6E530
0000747fd7fdcb5b  call rax
0000747fd7fdcb5d  movaps xmm7, [rsp]
0000747fd7fdcb61  add rsp, 0x30
0000747fd7fdcb65  vmovaps xmm0, [rsp]
0000747fd7fdcb6a  vmovaps xmm1, [rsp+0x10]
0000747fd7fdcb70  vmovaps xmm2, [rsp+0x20]
0000747fd7fdcb76  vmovaps xmm3, [rsp+0x30]
0000747fd7fdcb7c  vmovaps xmm4, [rsp+0x40]
0000747fd7fdcb82  vmovaps xmm5, [rsp+0x50]
0000747fd7fdcb88  vmovaps xmm6, [rsp+0x60]
0000747fd7fdcb8e  vmovaps xmm8, [rsp+0x70]
0000747fd7fdcb94  vmovaps xmm9, [rsp+0x80]
0000747fd7fdcb9d  vmovaps xmm10, [rsp+0x90]
0000747fd7fdcba6  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdcbaf  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdcbb8  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdcbc1  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdcbca  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdcbd3  add rsp, 0xF0
0000747fd7fdcbda  pop r11
0000747fd7fdcbdc  pop r10
0000747fd7fdcbde  pop r9
0000747fd7fdcbe0  pop r8
0000747fd7fdcbe2  pop rsi
0000747fd7fdcbe3  pop rdi
0000747fd7fdcbe4  pop rdx
0000747fd7fdcbe5  pop rcx
0000747fd7fdcbe6  pop rax
0000747fd7fdcbe7  add rsp, 0x08
0000747fd7fdcbeb  jmp 0x0000747FD7FDBB75
0000747fd7fdcbf0  sub rsp, 0x08
0000747fd7fdcbf4  push rax
0000747fd7fdcbf5  push rcx
0000747fd7fdcbf6  push rdx
0000747fd7fdcbf7  push rdi
0000747fd7fdcbf8  push rsi
0000747fd7fdcbf9  push r8
0000747fd7fdcbfb  push r9
0000747fd7fdcbfd  push r10
0000747fd7fdcbff  push r11
0000747fd7fdcc01  sub rsp, 0xF0
0000747fd7fdcc08  vmovaps [rsp], xmm0
0000747fd7fdcc0d  vmovaps [rsp+0x10], xmm1
0000747fd7fdcc13  vmovaps [rsp+0x20], xmm2
0000747fd7fdcc19  vmovaps [rsp+0x30], xmm3
0000747fd7fdcc1f  vmovaps [rsp+0x40], xmm4
0000747fd7fdcc25  vmovaps [rsp+0x50], xmm5
0000747fd7fdcc2b  vmovaps [rsp+0x60], xmm6
0000747fd7fdcc31  vmovaps [rsp+0x70], xmm7
0000747fd7fdcc37  vmovaps [rsp+0x80], xmm8
0000747fd7fdcc40  vmovaps [rsp+0x90], xmm10
0000747fd7fdcc49  vmovaps [rsp+0xA0], xmm11
0000747fd7fdcc52  vmovaps [rsp+0xB0], xmm12
0000747fd7fdcc5b  vmovaps [rsp+0xC0], xmm13
0000747fd7fdcc64  vmovaps [rsp+0xD0], xmm14
0000747fd7fdcc6d  vmovaps [rsp+0xE0], xmm15
0000747fd7fdcc76  sub rsp, 0x30
0000747fd7fdcc7a  movaps [rsp], xmm9
0000747fd7fdcc7f  movaps [rsp+0x10], xmm12
0000747fd7fdcc85  movaps [rsp+0x20], xmm10
0000747fd7fdcc8b  lea rdi, [rsp]
0000747fd7fdcc8f  mov esi, 0x00
0000747fd7fdcc94  mov rax, 0x6055A0B6E530
0000747fd7fdcc9e  call rax
0000747fd7fdcca0  movaps xmm9, [rsp]
0000747fd7fdcca5  add rsp, 0x30
0000747fd7fdcca9  vmovaps xmm0, [rsp]
0000747fd7fdccae  vmovaps xmm1, [rsp+0x10]
0000747fd7fdccb4  vmovaps xmm2, [rsp+0x20]
0000747fd7fdccba  vmovaps xmm3, [rsp+0x30]
0000747fd7fdccc0  vmovaps xmm4, [rsp+0x40]
0000747fd7fdccc6  vmovaps xmm5, [rsp+0x50]
0000747fd7fdcccc  vmovaps xmm6, [rsp+0x60]
0000747fd7fdccd2  vmovaps xmm7, [rsp+0x70]
0000747fd7fdccd8  vmovaps xmm8, [rsp+0x80]
0000747fd7fdcce1  vmovaps xmm10, [rsp+0x90]
0000747fd7fdccea  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdccf3  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdccfc  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdcd05  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdcd0e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdcd17  add rsp, 0xF0
0000747fd7fdcd1e  pop r11
0000747fd7fdcd20  pop r10
0000747fd7fdcd22  pop r9
0000747fd7fdcd24  pop r8
0000747fd7fdcd26  pop rsi
0000747fd7fdcd27  pop rdi
0000747fd7fdcd28  pop rdx
0000747fd7fdcd29  pop rcx
0000747fd7fdcd2a  pop rax
0000747fd7fdcd2b  add rsp, 0x08
0000747fd7fdcd2f  jmp 0x0000747FD7FDBB99
0000747fd7fdcd34  sub rsp, 0x08
0000747fd7fdcd38  push rax
0000747fd7fdcd39  push rcx
0000747fd7fdcd3a  push rdx
0000747fd7fdcd3b  push rdi
0000747fd7fdcd3c  push rsi
0000747fd7fdcd3d  push r8
0000747fd7fdcd3f  push r9
0000747fd7fdcd41  push r10
0000747fd7fdcd43  push r11
0000747fd7fdcd45  sub rsp, 0xF0
0000747fd7fdcd4c  vmovaps [rsp], xmm0
0000747fd7fdcd51  vmovaps [rsp+0x10], xmm1
0000747fd7fdcd57  vmovaps [rsp+0x20], xmm2
0000747fd7fdcd5d  vmovaps [rsp+0x30], xmm3
0000747fd7fdcd63  vmovaps [rsp+0x40], xmm4
0000747fd7fdcd69  vmovaps [rsp+0x50], xmm5
0000747fd7fdcd6f  vmovaps [rsp+0x60], xmm6
0000747fd7fdcd75  vmovaps [rsp+0x70], xmm7
0000747fd7fdcd7b  vmovaps [rsp+0x80], xmm8
0000747fd7fdcd84  vmovaps [rsp+0x90], xmm9
0000747fd7fdcd8d  vmovaps [rsp+0xA0], xmm11
0000747fd7fdcd96  vmovaps [rsp+0xB0], xmm12
0000747fd7fdcd9f  vmovaps [rsp+0xC0], xmm13
0000747fd7fdcda8  vmovaps [rsp+0xD0], xmm14
0000747fd7fdcdb1  vmovaps [rsp+0xE0], xmm15
0000747fd7fdcdba  sub rsp, 0x30
0000747fd7fdcdbe  movaps [rsp], xmm10
0000747fd7fdcdc3  movaps [rsp+0x10], xmm12
0000747fd7fdcdc9  movaps [rsp+0x20], xmm11
0000747fd7fdcdcf  lea rdi, [rsp]
0000747fd7fdcdd3  mov esi, 0x00
0000747fd7fdcdd8  mov rax, 0x6055A0B6E530
0000747fd7fdcde2  call rax
0000747fd7fdcde4  movaps xmm10, [rsp]
0000747fd7fdcde9  add rsp, 0x30
0000747fd7fdcded  vmovaps xmm0, [rsp]
0000747fd7fdcdf2  vmovaps xmm1, [rsp+0x10]
0000747fd7fdcdf8  vmovaps xmm2, [rsp+0x20]
0000747fd7fdcdfe  vmovaps xmm3, [rsp+0x30]
0000747fd7fdce04  vmovaps xmm4, [rsp+0x40]
0000747fd7fdce0a  vmovaps xmm5, [rsp+0x50]
0000747fd7fdce10  vmovaps xmm6, [rsp+0x60]
0000747fd7fdce16  vmovaps xmm7, [rsp+0x70]
0000747fd7fdce1c  vmovaps xmm8, [rsp+0x80]
0000747fd7fdce25  vmovaps xmm9, [rsp+0x90]
0000747fd7fdce2e  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdce37  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdce40  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdce49  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdce52  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdce5b  add rsp, 0xF0
0000747fd7fdce62  pop r11
0000747fd7fdce64  pop r10
0000747fd7fdce66  pop r9
0000747fd7fdce68  pop r8
0000747fd7fdce6a  pop rsi
0000747fd7fdce6b  pop rdi
0000747fd7fdce6c  pop rdx
0000747fd7fdce6d  pop rcx
0000747fd7fdce6e  pop rax
0000747fd7fdce6f  add rsp, 0x08
0000747fd7fdce73  jmp 0x0000747FD7FDBBB3
0000747fd7fdce78  sub rsp, 0x08
0000747fd7fdce7c  push rax
0000747fd7fdce7d  push rcx
0000747fd7fdce7e  push rdx
0000747fd7fdce7f  push rdi
0000747fd7fdce80  push rsi
0000747fd7fdce81  push r8
0000747fd7fdce83  push r9
0000747fd7fdce85  push r10
0000747fd7fdce87  push r11
0000747fd7fdce89  sub rsp, 0xF0
0000747fd7fdce90  vmovaps [rsp], xmm0
0000747fd7fdce95  vmovaps [rsp+0x10], xmm1
0000747fd7fdce9b  vmovaps [rsp+0x20], xmm2
0000747fd7fdcea1  vmovaps [rsp+0x30], xmm3
0000747fd7fdcea7  vmovaps [rsp+0x40], xmm4
0000747fd7fdcead  vmovaps [rsp+0x50], xmm5
0000747fd7fdceb3  vmovaps [rsp+0x60], xmm7
0000747fd7fdceb9  vmovaps [rsp+0x70], xmm8
0000747fd7fdcebf  vmovaps [rsp+0x80], xmm9
0000747fd7fdcec8  vmovaps [rsp+0x90], xmm10
0000747fd7fdced1  vmovaps [rsp+0xA0], xmm11
0000747fd7fdceda  vmovaps [rsp+0xB0], xmm12
0000747fd7fdcee3  vmovaps [rsp+0xC0], xmm13
0000747fd7fdceec  vmovaps [rsp+0xD0], xmm14
0000747fd7fdcef5  vmovaps [rsp+0xE0], xmm15
0000747fd7fdcefe  sub rsp, 0x30
0000747fd7fdcf02  movaps [rsp], xmm6
0000747fd7fdcf06  movaps [rsp+0x10], xmm12
0000747fd7fdcf0c  movaps [rsp+0x20], xmm11
0000747fd7fdcf12  lea rdi, [rsp]
0000747fd7fdcf16  mov esi, 0x00
0000747fd7fdcf1b  mov rax, 0x6055A0B6E530
0000747fd7fdcf25  call rax
0000747fd7fdcf27  movaps xmm6, [rsp]
0000747fd7fdcf2b  add rsp, 0x30
0000747fd7fdcf2f  vmovaps xmm0, [rsp]
0000747fd7fdcf34  vmovaps xmm1, [rsp+0x10]
0000747fd7fdcf3a  vmovaps xmm2, [rsp+0x20]
0000747fd7fdcf40  vmovaps xmm3, [rsp+0x30]
0000747fd7fdcf46  vmovaps xmm4, [rsp+0x40]
0000747fd7fdcf4c  vmovaps xmm5, [rsp+0x50]
0000747fd7fdcf52  vmovaps xmm7, [rsp+0x60]
0000747fd7fdcf58  vmovaps xmm8, [rsp+0x70]
0000747fd7fdcf5e  vmovaps xmm9, [rsp+0x80]
0000747fd7fdcf67  vmovaps xmm10, [rsp+0x90]
0000747fd7fdcf70  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdcf79  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdcf82  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdcf8b  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdcf94  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdcf9d  add rsp, 0xF0
0000747fd7fdcfa4  pop r11
0000747fd7fdcfa6  pop r10
0000747fd7fdcfa8  pop r9
0000747fd7fdcfaa  pop r8
0000747fd7fdcfac  pop rsi
0000747fd7fdcfad  pop rdi
0000747fd7fdcfae  pop rdx
0000747fd7fdcfaf  pop rcx
0000747fd7fdcfb0  pop rax
0000747fd7fdcfb1  add rsp, 0x08
0000747fd7fdcfb5  jmp 0x0000747FD7FDBBD4
0000747fd7fdcfba  sub rsp, 0x08
0000747fd7fdcfbe  push rax
0000747fd7fdcfbf  push rcx
0000747fd7fdcfc0  push rdx
0000747fd7fdcfc1  push rdi
0000747fd7fdcfc2  push rsi
0000747fd7fdcfc3  push r8
0000747fd7fdcfc5  push r9
0000747fd7fdcfc7  push r10
0000747fd7fdcfc9  push r11
0000747fd7fdcfcb  sub rsp, 0xF0
0000747fd7fdcfd2  vmovaps [rsp], xmm0
0000747fd7fdcfd7  vmovaps [rsp+0x10], xmm1
0000747fd7fdcfdd  vmovaps [rsp+0x20], xmm2
0000747fd7fdcfe3  vmovaps [rsp+0x30], xmm4
0000747fd7fdcfe9  vmovaps [rsp+0x40], xmm5
0000747fd7fdcfef  vmovaps [rsp+0x50], xmm6
0000747fd7fdcff5  vmovaps [rsp+0x60], xmm7
0000747fd7fdcffb  vmovaps [rsp+0x70], xmm8
0000747fd7fdd001  vmovaps [rsp+0x80], xmm9
0000747fd7fdd00a  vmovaps [rsp+0x90], xmm10
0000747fd7fdd013  vmovaps [rsp+0xA0], xmm11
0000747fd7fdd01c  vmovaps [rsp+0xB0], xmm12
0000747fd7fdd025  vmovaps [rsp+0xC0], xmm13
0000747fd7fdd02e  vmovaps [rsp+0xD0], xmm14
0000747fd7fdd037  vmovaps [rsp+0xE0], xmm15
0000747fd7fdd040  sub rsp, 0x30
0000747fd7fdd044  movaps [rsp], xmm3
0000747fd7fdd048  movaps [rsp+0x10], xmm5
0000747fd7fdd04d  movaps [rsp+0x20], xmm4
0000747fd7fdd052  lea rdi, [rsp]
0000747fd7fdd056  mov esi, 0x00
0000747fd7fdd05b  mov rax, 0x6055A0B6E530
0000747fd7fdd065  call rax
0000747fd7fdd067  movaps xmm3, [rsp]
0000747fd7fdd06b  add rsp, 0x30
0000747fd7fdd06f  vmovaps xmm0, [rsp]
0000747fd7fdd074  vmovaps xmm1, [rsp+0x10]
0000747fd7fdd07a  vmovaps xmm2, [rsp+0x20]
0000747fd7fdd080  vmovaps xmm4, [rsp+0x30]
0000747fd7fdd086  vmovaps xmm5, [rsp+0x40]
0000747fd7fdd08c  vmovaps xmm6, [rsp+0x50]
0000747fd7fdd092  vmovaps xmm7, [rsp+0x60]
0000747fd7fdd098  vmovaps xmm8, [rsp+0x70]
0000747fd7fdd09e  vmovaps xmm9, [rsp+0x80]
0000747fd7fdd0a7  vmovaps xmm10, [rsp+0x90]
0000747fd7fdd0b0  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdd0b9  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdd0c2  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdd0cb  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdd0d4  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdd0dd  add rsp, 0xF0
0000747fd7fdd0e4  pop r11
0000747fd7fdd0e6  pop r10
0000747fd7fdd0e8  pop r9
0000747fd7fdd0ea  pop r8
0000747fd7fdd0ec  pop rsi
0000747fd7fdd0ed  pop rdi
0000747fd7fdd0ee  pop rdx
0000747fd7fdd0ef  pop rcx
0000747fd7fdd0f0  pop rax
0000747fd7fdd0f1  add rsp, 0x08
0000747fd7fdd0f5  jmp 0x0000747FD7FDBC35
0000747fd7fdd0fa  sub rsp, 0x08
0000747fd7fdd0fe  push rax
0000747fd7fdd0ff  push rcx
0000747fd7fdd100  push rdx
0000747fd7fdd101  push rdi
0000747fd7fdd102  push rsi
0000747fd7fdd103  push r8
0000747fd7fdd105  push r9
0000747fd7fdd107  push r10
0000747fd7fdd109  push r11
0000747fd7fdd10b  sub rsp, 0xF0
0000747fd7fdd112  vmovaps [rsp], xmm0
0000747fd7fdd117  vmovaps [rsp+0x10], xmm1
0000747fd7fdd11d  vmovaps [rsp+0x20], xmm2
0000747fd7fdd123  vmovaps [rsp+0x30], xmm3
0000747fd7fdd129  vmovaps [rsp+0x40], xmm4
0000747fd7fdd12f  vmovaps [rsp+0x50], xmm6
0000747fd7fdd135  vmovaps [rsp+0x60], xmm7
0000747fd7fdd13b  vmovaps [rsp+0x70], xmm8
0000747fd7fdd141  vmovaps [rsp+0x80], xmm9
0000747fd7fdd14a  vmovaps [rsp+0x90], xmm10
0000747fd7fdd153  vmovaps [rsp+0xA0], xmm11
0000747fd7fdd15c  vmovaps [rsp+0xB0], xmm12
0000747fd7fdd165  vmovaps [rsp+0xC0], xmm13
0000747fd7fdd16e  vmovaps [rsp+0xD0], xmm14
0000747fd7fdd177  vmovaps [rsp+0xE0], xmm15
0000747fd7fdd180  sub rsp, 0x30
0000747fd7fdd184  movaps [rsp], xmm5
0000747fd7fdd188  movaps [rsp+0x10], xmm8
0000747fd7fdd18e  movaps [rsp+0x20], xmm15
0000747fd7fdd194  lea rdi, [rsp]
0000747fd7fdd198  mov esi, 0x00
0000747fd7fdd19d  mov rax, 0x6055A0B6E530
0000747fd7fdd1a7  call rax
0000747fd7fdd1a9  movaps xmm5, [rsp]
0000747fd7fdd1ad  add rsp, 0x30
0000747fd7fdd1b1  vmovaps xmm0, [rsp]
0000747fd7fdd1b6  vmovaps xmm1, [rsp+0x10]
0000747fd7fdd1bc  vmovaps xmm2, [rsp+0x20]
0000747fd7fdd1c2  vmovaps xmm3, [rsp+0x30]
0000747fd7fdd1c8  vmovaps xmm4, [rsp+0x40]
0000747fd7fdd1ce  vmovaps xmm6, [rsp+0x50]
0000747fd7fdd1d4  vmovaps xmm7, [rsp+0x60]
0000747fd7fdd1da  vmovaps xmm8, [rsp+0x70]
0000747fd7fdd1e0  vmovaps xmm9, [rsp+0x80]
0000747fd7fdd1e9  vmovaps xmm10, [rsp+0x90]
0000747fd7fdd1f2  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdd1fb  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdd204  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdd20d  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdd216  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdd21f  add rsp, 0xF0
0000747fd7fdd226  pop r11
0000747fd7fdd228  pop r10
0000747fd7fdd22a  pop r9
0000747fd7fdd22c  pop r8
0000747fd7fdd22e  pop rsi
0000747fd7fdd22f  pop rdi
0000747fd7fdd230  pop rdx
0000747fd7fdd231  pop rcx
0000747fd7fdd232  pop rax
0000747fd7fdd233  add rsp, 0x08
0000747fd7fdd237  jmp 0x0000747FD7FDBC73
0000747fd7fdd23c  sub rsp, 0x08
0000747fd7fdd240  push rax
0000747fd7fdd241  push rcx
0000747fd7fdd242  push rdx
0000747fd7fdd243  push rdi
0000747fd7fdd244  push rsi
0000747fd7fdd245  push r8
0000747fd7fdd247  push r9
0000747fd7fdd249  push r10
0000747fd7fdd24b  push r11
0000747fd7fdd24d  sub rsp, 0xF0
0000747fd7fdd254  vmovaps [rsp], xmm0
0000747fd7fdd259  vmovaps [rsp+0x10], xmm1
0000747fd7fdd25f  vmovaps [rsp+0x20], xmm2
0000747fd7fdd265  vmovaps [rsp+0x30], xmm3
0000747fd7fdd26b  vmovaps [rsp+0x40], xmm5
0000747fd7fdd271  vmovaps [rsp+0x50], xmm6
0000747fd7fdd277  vmovaps [rsp+0x60], xmm7
0000747fd7fdd27d  vmovaps [rsp+0x70], xmm8
0000747fd7fdd283  vmovaps [rsp+0x80], xmm9
0000747fd7fdd28c  vmovaps [rsp+0x90], xmm10
0000747fd7fdd295  vmovaps [rsp+0xA0], xmm11
0000747fd7fdd29e  vmovaps [rsp+0xB0], xmm12
0000747fd7fdd2a7  vmovaps [rsp+0xC0], xmm13
0000747fd7fdd2b0  vmovaps [rsp+0xD0], xmm14
0000747fd7fdd2b9  vmovaps [rsp+0xE0], xmm15
0000747fd7fdd2c2  sub rsp, 0x30
0000747fd7fdd2c6  movaps [rsp], xmm4
0000747fd7fdd2ca  movaps [rsp+0x10], xmm9
0000747fd7fdd2d0  movaps [rsp+0x20], xmm8
0000747fd7fdd2d6  lea rdi, [rsp]
0000747fd7fdd2da  mov esi, 0x00
0000747fd7fdd2df  mov rax, 0x6055A0B6E530
0000747fd7fdd2e9  call rax
0000747fd7fdd2eb  movaps xmm4, [rsp]
0000747fd7fdd2ef  add rsp, 0x30
0000747fd7fdd2f3  vmovaps xmm0, [rsp]
0000747fd7fdd2f8  vmovaps xmm1, [rsp+0x10]
0000747fd7fdd2fe  vmovaps xmm2, [rsp+0x20]
0000747fd7fdd304  vmovaps xmm3, [rsp+0x30]
0000747fd7fdd30a  vmovaps xmm5, [rsp+0x40]
0000747fd7fdd310  vmovaps xmm6, [rsp+0x50]
0000747fd7fdd316  vmovaps xmm7, [rsp+0x60]
0000747fd7fdd31c  vmovaps xmm8, [rsp+0x70]
0000747fd7fdd322  vmovaps xmm9, [rsp+0x80]
0000747fd7fdd32b  vmovaps xmm10, [rsp+0x90]
0000747fd7fdd334  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdd33d  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdd346  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdd34f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdd358  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdd361  add rsp, 0xF0
0000747fd7fdd368  pop r11
0000747fd7fdd36a  pop r10
0000747fd7fdd36c  pop r9
0000747fd7fdd36e  pop r8
0000747fd7fdd370  pop rsi
0000747fd7fdd371  pop rdi
0000747fd7fdd372  pop rdx
0000747fd7fdd373  pop rcx
0000747fd7fdd374  pop rax
0000747fd7fdd375  add rsp, 0x08
0000747fd7fdd379  jmp 0x0000747FD7FDBC94
0000747fd7fdd37e  sub rsp, 0x08
0000747fd7fdd382  push rax
0000747fd7fdd383  push rcx
0000747fd7fdd384  push rdx
0000747fd7fdd385  push rdi
0000747fd7fdd386  push rsi
0000747fd7fdd387  push r8
0000747fd7fdd389  push r9
0000747fd7fdd38b  push r10
0000747fd7fdd38d  push r11
0000747fd7fdd38f  sub rsp, 0xF0
0000747fd7fdd396  vmovaps [rsp], xmm0
0000747fd7fdd39b  vmovaps [rsp+0x10], xmm1
0000747fd7fdd3a1  vmovaps [rsp+0x20], xmm2
0000747fd7fdd3a7  vmovaps [rsp+0x30], xmm3
0000747fd7fdd3ad  vmovaps [rsp+0x40], xmm4
0000747fd7fdd3b3  vmovaps [rsp+0x50], xmm5
0000747fd7fdd3b9  vmovaps [rsp+0x60], xmm6
0000747fd7fdd3bf  vmovaps [rsp+0x70], xmm7
0000747fd7fdd3c5  vmovaps [rsp+0x80], xmm8
0000747fd7fdd3ce  vmovaps [rsp+0x90], xmm10
0000747fd7fdd3d7  vmovaps [rsp+0xA0], xmm11
0000747fd7fdd3e0  vmovaps [rsp+0xB0], xmm12
0000747fd7fdd3e9  vmovaps [rsp+0xC0], xmm13
0000747fd7fdd3f2  vmovaps [rsp+0xD0], xmm14
0000747fd7fdd3fb  vmovaps [rsp+0xE0], xmm15
0000747fd7fdd404  sub rsp, 0x30
0000747fd7fdd408  movaps [rsp], xmm9
0000747fd7fdd40d  movaps [rsp+0x10], xmm10
0000747fd7fdd413  movaps [rsp+0x20], xmm8
0000747fd7fdd419  lea rdi, [rsp]
0000747fd7fdd41d  mov esi, 0x00
0000747fd7fdd422  mov rax, 0x6055A0B6E530
0000747fd7fdd42c  call rax
0000747fd7fdd42e  movaps xmm9, [rsp]
0000747fd7fdd433  add rsp, 0x30
0000747fd7fdd437  vmovaps xmm0, [rsp]
0000747fd7fdd43c  vmovaps xmm1, [rsp+0x10]
0000747fd7fdd442  vmovaps xmm2, [rsp+0x20]
0000747fd7fdd448  vmovaps xmm3, [rsp+0x30]
0000747fd7fdd44e  vmovaps xmm4, [rsp+0x40]
0000747fd7fdd454  vmovaps xmm5, [rsp+0x50]
0000747fd7fdd45a  vmovaps xmm6, [rsp+0x60]
0000747fd7fdd460  vmovaps xmm7, [rsp+0x70]
0000747fd7fdd466  vmovaps xmm8, [rsp+0x80]
0000747fd7fdd46f  vmovaps xmm10, [rsp+0x90]
0000747fd7fdd478  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdd481  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdd48a  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdd493  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdd49c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdd4a5  add rsp, 0xF0
0000747fd7fdd4ac  pop r11
0000747fd7fdd4ae  pop r10
0000747fd7fdd4b0  pop r9
0000747fd7fdd4b2  pop r8
0000747fd7fdd4b4  pop rsi
0000747fd7fdd4b5  pop rdi
0000747fd7fdd4b6  pop rdx
0000747fd7fdd4b7  pop rcx
0000747fd7fdd4b8  pop rax
0000747fd7fdd4b9  add rsp, 0x08
0000747fd7fdd4bd  jmp 0x0000747FD7FDBCAE
0000747fd7fdd4c2  call 0x0000747FD7EB52F0
0000747fd7fdd4c7  jmp 0x0000747FD7FDBDC8
0000747fd7fdd4cc  call 0x0000747FD7EB52F0
0000747fd7fdd4d1  jmp 0x0000747FD7FDBDDE
0000747fd7fdd4d6  sub rsp, 0x08
0000747fd7fdd4da  push rax
0000747fd7fdd4db  push rcx
0000747fd7fdd4dc  push rdx
0000747fd7fdd4dd  push rdi
0000747fd7fdd4de  push rsi
0000747fd7fdd4df  push r8
0000747fd7fdd4e1  push r9
0000747fd7fdd4e3  push r10
0000747fd7fdd4e5  push r11
0000747fd7fdd4e7  sub rsp, 0xF0
0000747fd7fdd4ee  vmovaps [rsp], xmm0
0000747fd7fdd4f3  vmovaps [rsp+0x10], xmm2
0000747fd7fdd4f9  vmovaps [rsp+0x20], xmm3
0000747fd7fdd4ff  vmovaps [rsp+0x30], xmm4
0000747fd7fdd505  vmovaps [rsp+0x40], xmm5
0000747fd7fdd50b  vmovaps [rsp+0x50], xmm6
0000747fd7fdd511  vmovaps [rsp+0x60], xmm7
0000747fd7fdd517  vmovaps [rsp+0x70], xmm8
0000747fd7fdd51d  vmovaps [rsp+0x80], xmm9
0000747fd7fdd526  vmovaps [rsp+0x90], xmm10
0000747fd7fdd52f  vmovaps [rsp+0xA0], xmm11
0000747fd7fdd538  vmovaps [rsp+0xB0], xmm12
0000747fd7fdd541  vmovaps [rsp+0xC0], xmm13
0000747fd7fdd54a  vmovaps [rsp+0xD0], xmm14
0000747fd7fdd553  vmovaps [rsp+0xE0], xmm15
0000747fd7fdd55c  sub rsp, 0x30
0000747fd7fdd560  movaps [rsp], xmm1
0000747fd7fdd564  movaps [rsp+0x10], xmm6
0000747fd7fdd569  movaps [rsp+0x20], xmm15
0000747fd7fdd56f  lea rdi, [rsp]
0000747fd7fdd573  mov esi, 0x00
0000747fd7fdd578  mov rax, 0x6055A0B6E530
0000747fd7fdd582  call rax
0000747fd7fdd584  movaps xmm1, [rsp]
0000747fd7fdd588  add rsp, 0x30
0000747fd7fdd58c  vmovaps xmm0, [rsp]
0000747fd7fdd591  vmovaps xmm2, [rsp+0x10]
0000747fd7fdd597  vmovaps xmm3, [rsp+0x20]
0000747fd7fdd59d  vmovaps xmm4, [rsp+0x30]
0000747fd7fdd5a3  vmovaps xmm5, [rsp+0x40]
0000747fd7fdd5a9  vmovaps xmm6, [rsp+0x50]
0000747fd7fdd5af  vmovaps xmm7, [rsp+0x60]
0000747fd7fdd5b5  vmovaps xmm8, [rsp+0x70]
0000747fd7fdd5bb  vmovaps xmm9, [rsp+0x80]
0000747fd7fdd5c4  vmovaps xmm10, [rsp+0x90]
0000747fd7fdd5cd  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdd5d6  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdd5df  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdd5e8  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdd5f1  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdd5fa  add rsp, 0xF0
0000747fd7fdd601  pop r11
0000747fd7fdd603  pop r10
0000747fd7fdd605  pop r9
0000747fd7fdd607  pop r8
0000747fd7fdd609  pop rsi
0000747fd7fdd60a  pop rdi
0000747fd7fdd60b  pop rdx
0000747fd7fdd60c  pop rcx
0000747fd7fdd60d  pop rax
0000747fd7fdd60e  add rsp, 0x08
0000747fd7fdd612  jmp 0x0000747FD7FDBE1B
0000747fd7fdd617  call 0x0000747FD7EC4620
0000747fd7fdd61c  jmp 0x0000747FD7FDBE28
0000747fd7fdd621  sub rsp, 0x08
0000747fd7fdd625  push rax
0000747fd7fdd626  push rcx
0000747fd7fdd627  push rdx
0000747fd7fdd628  push rdi
0000747fd7fdd629  push rsi
0000747fd7fdd62a  push r8
0000747fd7fdd62c  push r9
0000747fd7fdd62e  push r10
0000747fd7fdd630  push r11
0000747fd7fdd632  sub rsp, 0xF0
0000747fd7fdd639  vmovaps [rsp], xmm0
0000747fd7fdd63e  vmovaps [rsp+0x10], xmm1
0000747fd7fdd644  vmovaps [rsp+0x20], xmm2
0000747fd7fdd64a  vmovaps [rsp+0x30], xmm3
0000747fd7fdd650  vmovaps [rsp+0x40], xmm4
0000747fd7fdd656  vmovaps [rsp+0x50], xmm5
0000747fd7fdd65c  vmovaps [rsp+0x60], xmm6
0000747fd7fdd662  vmovaps [rsp+0x70], xmm7
0000747fd7fdd668  vmovaps [rsp+0x80], xmm8
0000747fd7fdd671  vmovaps [rsp+0x90], xmm9
0000747fd7fdd67a  vmovaps [rsp+0xA0], xmm10
0000747fd7fdd683  vmovaps [rsp+0xB0], xmm11
0000747fd7fdd68c  vmovaps [rsp+0xC0], xmm12
0000747fd7fdd695  vmovaps [rsp+0xD0], xmm13
0000747fd7fdd69e  vmovaps [rsp+0xE0], xmm15
0000747fd7fdd6a7  sub rsp, 0x30
0000747fd7fdd6ab  movaps [rsp], xmm14
0000747fd7fdd6b0  movaps [rsp+0x10], xmm4
0000747fd7fdd6b5  movaps [rsp+0x20], xmm3
0000747fd7fdd6ba  lea rdi, [rsp]
0000747fd7fdd6be  mov esi, 0x00
0000747fd7fdd6c3  mov rax, 0x6055A0B6E530
0000747fd7fdd6cd  call rax
0000747fd7fdd6cf  movaps xmm14, [rsp]
0000747fd7fdd6d4  add rsp, 0x30
0000747fd7fdd6d8  vmovaps xmm0, [rsp]
0000747fd7fdd6dd  vmovaps xmm1, [rsp+0x10]
0000747fd7fdd6e3  vmovaps xmm2, [rsp+0x20]
0000747fd7fdd6e9  vmovaps xmm3, [rsp+0x30]
0000747fd7fdd6ef  vmovaps xmm4, [rsp+0x40]
0000747fd7fdd6f5  vmovaps xmm5, [rsp+0x50]
0000747fd7fdd6fb  vmovaps xmm6, [rsp+0x60]
0000747fd7fdd701  vmovaps xmm7, [rsp+0x70]
0000747fd7fdd707  vmovaps xmm8, [rsp+0x80]
0000747fd7fdd710  vmovaps xmm9, [rsp+0x90]
0000747fd7fdd719  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdd722  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdd72b  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdd734  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdd73d  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdd746  add rsp, 0xF0
0000747fd7fdd74d  pop r11
0000747fd7fdd74f  pop r10
0000747fd7fdd751  pop r9
0000747fd7fdd753  pop r8
0000747fd7fdd755  pop rsi
0000747fd7fdd756  pop rdi
0000747fd7fdd757  pop rdx
0000747fd7fdd758  pop rcx
0000747fd7fdd759  pop rax
0000747fd7fdd75a  add rsp, 0x08
0000747fd7fdd75e  jmp 0x0000747FD7FDBE42
0000747fd7fdd763  sub rsp, 0x08
0000747fd7fdd767  push rax
0000747fd7fdd768  push rcx
0000747fd7fdd769  push rdx
0000747fd7fdd76a  push rdi
0000747fd7fdd76b  push rsi
0000747fd7fdd76c  push r8
0000747fd7fdd76e  push r9
0000747fd7fdd770  push r10
0000747fd7fdd772  push r11
0000747fd7fdd774  sub rsp, 0xF0
0000747fd7fdd77b  vmovaps [rsp], xmm0
0000747fd7fdd780  vmovaps [rsp+0x10], xmm1
0000747fd7fdd786  vmovaps [rsp+0x20], xmm2
0000747fd7fdd78c  vmovaps [rsp+0x30], xmm3
0000747fd7fdd792  vmovaps [rsp+0x40], xmm4
0000747fd7fdd798  vmovaps [rsp+0x50], xmm5
0000747fd7fdd79e  vmovaps [rsp+0x60], xmm7
0000747fd7fdd7a4  vmovaps [rsp+0x70], xmm8
0000747fd7fdd7aa  vmovaps [rsp+0x80], xmm9
0000747fd7fdd7b3  vmovaps [rsp+0x90], xmm10
0000747fd7fdd7bc  vmovaps [rsp+0xA0], xmm11
0000747fd7fdd7c5  vmovaps [rsp+0xB0], xmm12
0000747fd7fdd7ce  vmovaps [rsp+0xC0], xmm13
0000747fd7fdd7d7  vmovaps [rsp+0xD0], xmm14
0000747fd7fdd7e0  vmovaps [rsp+0xE0], xmm15
0000747fd7fdd7e9  sub rsp, 0x30
0000747fd7fdd7ed  movaps [rsp], xmm6
0000747fd7fdd7f1  movaps [rsp+0x10], xmm9
0000747fd7fdd7f7  movaps [rsp+0x20], xmm7
0000747fd7fdd7fc  lea rdi, [rsp]
0000747fd7fdd800  mov esi, 0x00
0000747fd7fdd805  mov rax, 0x6055A0B6E530
0000747fd7fdd80f  call rax
0000747fd7fdd811  movaps xmm6, [rsp]
0000747fd7fdd815  add rsp, 0x30
0000747fd7fdd819  vmovaps xmm0, [rsp]
0000747fd7fdd81e  vmovaps xmm1, [rsp+0x10]
0000747fd7fdd824  vmovaps xmm2, [rsp+0x20]
0000747fd7fdd82a  vmovaps xmm3, [rsp+0x30]
0000747fd7fdd830  vmovaps xmm4, [rsp+0x40]
0000747fd7fdd836  vmovaps xmm5, [rsp+0x50]
0000747fd7fdd83c  vmovaps xmm7, [rsp+0x60]
0000747fd7fdd842  vmovaps xmm8, [rsp+0x70]
0000747fd7fdd848  vmovaps xmm9, [rsp+0x80]
0000747fd7fdd851  vmovaps xmm10, [rsp+0x90]
0000747fd7fdd85a  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdd863  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdd86c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdd875  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdd87e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdd887  add rsp, 0xF0
0000747fd7fdd88e  pop r11
0000747fd7fdd890  pop r10
0000747fd7fdd892  pop r9
0000747fd7fdd894  pop r8
0000747fd7fdd896  pop rsi
0000747fd7fdd897  pop rdi
0000747fd7fdd898  pop rdx
0000747fd7fdd899  pop rcx
0000747fd7fdd89a  pop rax
0000747fd7fdd89b  add rsp, 0x08
0000747fd7fdd89f  jmp 0x0000747FD7FDBE5A
0000747fd7fdd8a4  sub rsp, 0x08
0000747fd7fdd8a8  push rax
0000747fd7fdd8a9  push rcx
0000747fd7fdd8aa  push rdx
0000747fd7fdd8ab  push rdi
0000747fd7fdd8ac  push rsi
0000747fd7fdd8ad  push r8
0000747fd7fdd8af  push r9
0000747fd7fdd8b1  push r10
0000747fd7fdd8b3  push r11
0000747fd7fdd8b5  sub rsp, 0xF0
0000747fd7fdd8bc  vmovaps [rsp], xmm0
0000747fd7fdd8c1  vmovaps [rsp+0x10], xmm1
0000747fd7fdd8c7  vmovaps [rsp+0x20], xmm2
0000747fd7fdd8cd  vmovaps [rsp+0x30], xmm3
0000747fd7fdd8d3  vmovaps [rsp+0x40], xmm4
0000747fd7fdd8d9  vmovaps [rsp+0x50], xmm5
0000747fd7fdd8df  vmovaps [rsp+0x60], xmm6
0000747fd7fdd8e5  vmovaps [rsp+0x70], xmm8
0000747fd7fdd8eb  vmovaps [rsp+0x80], xmm9
0000747fd7fdd8f4  vmovaps [rsp+0x90], xmm10
0000747fd7fdd8fd  vmovaps [rsp+0xA0], xmm11
0000747fd7fdd906  vmovaps [rsp+0xB0], xmm12
0000747fd7fdd90f  vmovaps [rsp+0xC0], xmm13
0000747fd7fdd918  vmovaps [rsp+0xD0], xmm14
0000747fd7fdd921  vmovaps [rsp+0xE0], xmm15
0000747fd7fdd92a  sub rsp, 0x30
0000747fd7fdd92e  movaps [rsp], xmm7
0000747fd7fdd932  movaps [rsp+0x10], xmm4
0000747fd7fdd937  movaps [rsp+0x20], xmm9
0000747fd7fdd93d  lea rdi, [rsp]
0000747fd7fdd941  mov esi, 0x00
0000747fd7fdd946  mov rax, 0x6055A0B6E530
0000747fd7fdd950  call rax
0000747fd7fdd952  movaps xmm7, [rsp]
0000747fd7fdd956  add rsp, 0x30
0000747fd7fdd95a  vmovaps xmm0, [rsp]
0000747fd7fdd95f  vmovaps xmm1, [rsp+0x10]
0000747fd7fdd965  vmovaps xmm2, [rsp+0x20]
0000747fd7fdd96b  vmovaps xmm3, [rsp+0x30]
0000747fd7fdd971  vmovaps xmm4, [rsp+0x40]
0000747fd7fdd977  vmovaps xmm5, [rsp+0x50]
0000747fd7fdd97d  vmovaps xmm6, [rsp+0x60]
0000747fd7fdd983  vmovaps xmm8, [rsp+0x70]
0000747fd7fdd989  vmovaps xmm9, [rsp+0x80]
0000747fd7fdd992  vmovaps xmm10, [rsp+0x90]
0000747fd7fdd99b  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdd9a4  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdd9ad  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdd9b6  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdd9bf  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdd9c8  add rsp, 0xF0
0000747fd7fdd9cf  pop r11
0000747fd7fdd9d1  pop r10
0000747fd7fdd9d3  pop r9
0000747fd7fdd9d5  pop r8
0000747fd7fdd9d7  pop rsi
0000747fd7fdd9d8  pop rdi
0000747fd7fdd9d9  pop rdx
0000747fd7fdd9da  pop rcx
0000747fd7fdd9db  pop rax
0000747fd7fdd9dc  add rsp, 0x08
0000747fd7fdd9e0  jmp 0x0000747FD7FDBE87
0000747fd7fdd9e5  sub rsp, 0x08
0000747fd7fdd9e9  push rax
0000747fd7fdd9ea  push rcx
0000747fd7fdd9eb  push rdx
0000747fd7fdd9ec  push rdi
0000747fd7fdd9ed  push rsi
0000747fd7fdd9ee  push r8
0000747fd7fdd9f0  push r9
0000747fd7fdd9f2  push r10
0000747fd7fdd9f4  push r11
0000747fd7fdd9f6  sub rsp, 0xF0
0000747fd7fdd9fd  vmovaps [rsp], xmm0
0000747fd7fdda02  vmovaps [rsp+0x10], xmm1
0000747fd7fdda08  vmovaps [rsp+0x20], xmm2
0000747fd7fdda0e  vmovaps [rsp+0x30], xmm3
0000747fd7fdda14  vmovaps [rsp+0x40], xmm5
0000747fd7fdda1a  vmovaps [rsp+0x50], xmm6
0000747fd7fdda20  vmovaps [rsp+0x60], xmm7
0000747fd7fdda26  vmovaps [rsp+0x70], xmm8
0000747fd7fdda2c  vmovaps [rsp+0x80], xmm9
0000747fd7fdda35  vmovaps [rsp+0x90], xmm10
0000747fd7fdda3e  vmovaps [rsp+0xA0], xmm11
0000747fd7fdda47  vmovaps [rsp+0xB0], xmm12
0000747fd7fdda50  vmovaps [rsp+0xC0], xmm13
0000747fd7fdda59  vmovaps [rsp+0xD0], xmm14
0000747fd7fdda62  vmovaps [rsp+0xE0], xmm15
0000747fd7fdda6b  sub rsp, 0x30
0000747fd7fdda6f  movaps [rsp], xmm4
0000747fd7fdda73  movaps [rsp+0x10], xmm15
0000747fd7fdda79  movaps [rsp+0x20], xmm9
0000747fd7fdda7f  lea rdi, [rsp]
0000747fd7fdda83  mov esi, 0x00
0000747fd7fdda88  mov rax, 0x6055A0B6E530
0000747fd7fdda92  call rax
0000747fd7fdda94  movaps xmm4, [rsp]
0000747fd7fdda98  add rsp, 0x30
0000747fd7fdda9c  vmovaps xmm0, [rsp]
0000747fd7fddaa1  vmovaps xmm1, [rsp+0x10]
0000747fd7fddaa7  vmovaps xmm2, [rsp+0x20]
0000747fd7fddaad  vmovaps xmm3, [rsp+0x30]
0000747fd7fddab3  vmovaps xmm5, [rsp+0x40]
0000747fd7fddab9  vmovaps xmm6, [rsp+0x50]
0000747fd7fddabf  vmovaps xmm7, [rsp+0x60]
0000747fd7fddac5  vmovaps xmm8, [rsp+0x70]
0000747fd7fddacb  vmovaps xmm9, [rsp+0x80]
0000747fd7fddad4  vmovaps xmm10, [rsp+0x90]
0000747fd7fddadd  vmovaps xmm11, [rsp+0xA0]
0000747fd7fddae6  vmovaps xmm12, [rsp+0xB0]
0000747fd7fddaef  vmovaps xmm13, [rsp+0xC0]
0000747fd7fddaf8  vmovaps xmm14, [rsp+0xD0]
0000747fd7fddb01  vmovaps xmm15, [rsp+0xE0]
0000747fd7fddb0a  add rsp, 0xF0
0000747fd7fddb11  pop r11
0000747fd7fddb13  pop r10
0000747fd7fddb15  pop r9
0000747fd7fddb17  pop r8
0000747fd7fddb19  pop rsi
0000747fd7fddb1a  pop rdi
0000747fd7fddb1b  pop rdx
0000747fd7fddb1c  pop rcx
0000747fd7fddb1d  pop rax
0000747fd7fddb1e  add rsp, 0x08
0000747fd7fddb22  jmp 0x0000747FD7FDBEAC
0000747fd7fddb27  call 0x0000747FD7EC4620
0000747fd7fddb2c  jmp 0x0000747FD7FDBEB9
0000747fd7fddb31  sub rsp, 0x08
0000747fd7fddb35  push rax
0000747fd7fddb36  push rcx
0000747fd7fddb37  push rdx
0000747fd7fddb38  push rdi
0000747fd7fddb39  push rsi
0000747fd7fddb3a  push r8
0000747fd7fddb3c  push r9
0000747fd7fddb3e  push r10
0000747fd7fddb40  push r11
0000747fd7fddb42  sub rsp, 0xF0
0000747fd7fddb49  vmovaps [rsp], xmm0
0000747fd7fddb4e  vmovaps [rsp+0x10], xmm1
0000747fd7fddb54  vmovaps [rsp+0x20], xmm2
0000747fd7fddb5a  vmovaps [rsp+0x30], xmm4
0000747fd7fddb60  vmovaps [rsp+0x40], xmm5
0000747fd7fddb66  vmovaps [rsp+0x50], xmm6
0000747fd7fddb6c  vmovaps [rsp+0x60], xmm7
0000747fd7fddb72  vmovaps [rsp+0x70], xmm8
0000747fd7fddb78  vmovaps [rsp+0x80], xmm9
0000747fd7fddb81  vmovaps [rsp+0x90], xmm10
0000747fd7fddb8a  vmovaps [rsp+0xA0], xmm11
0000747fd7fddb93  vmovaps [rsp+0xB0], xmm12
0000747fd7fddb9c  vmovaps [rsp+0xC0], xmm13
0000747fd7fddba5  vmovaps [rsp+0xD0], xmm14
0000747fd7fddbae  vmovaps [rsp+0xE0], xmm15
0000747fd7fddbb7  sub rsp, 0x30
0000747fd7fddbbb  movaps [rsp], xmm3
0000747fd7fddbbf  movaps [rsp+0x10], xmm1
0000747fd7fddbc4  movaps [rsp+0x20], xmm9
0000747fd7fddbca  lea rdi, [rsp]
0000747fd7fddbce  mov esi, 0x00
0000747fd7fddbd3  mov rax, 0x6055A0B6E530
0000747fd7fddbdd  call rax
0000747fd7fddbdf  movaps xmm3, [rsp]
0000747fd7fddbe3  add rsp, 0x30
0000747fd7fddbe7  vmovaps xmm0, [rsp]
0000747fd7fddbec  vmovaps xmm1, [rsp+0x10]
0000747fd7fddbf2  vmovaps xmm2, [rsp+0x20]
0000747fd7fddbf8  vmovaps xmm4, [rsp+0x30]
0000747fd7fddbfe  vmovaps xmm5, [rsp+0x40]
0000747fd7fddc04  vmovaps xmm6, [rsp+0x50]
0000747fd7fddc0a  vmovaps xmm7, [rsp+0x60]
0000747fd7fddc10  vmovaps xmm8, [rsp+0x70]
0000747fd7fddc16  vmovaps xmm9, [rsp+0x80]
0000747fd7fddc1f  vmovaps xmm10, [rsp+0x90]
0000747fd7fddc28  vmovaps xmm11, [rsp+0xA0]
0000747fd7fddc31  vmovaps xmm12, [rsp+0xB0]
0000747fd7fddc3a  vmovaps xmm13, [rsp+0xC0]
0000747fd7fddc43  vmovaps xmm14, [rsp+0xD0]
0000747fd7fddc4c  vmovaps xmm15, [rsp+0xE0]
0000747fd7fddc55  add rsp, 0xF0
0000747fd7fddc5c  pop r11
0000747fd7fddc5e  pop r10
0000747fd7fddc60  pop r9
0000747fd7fddc62  pop r8
0000747fd7fddc64  pop rsi
0000747fd7fddc65  pop rdi
0000747fd7fddc66  pop rdx
0000747fd7fddc67  pop rcx
0000747fd7fddc68  pop rax
0000747fd7fddc69  add rsp, 0x08
0000747fd7fddc6d  jmp 0x0000747FD7FDBEF6
0000747fd7fddc72  sub rsp, 0x08
0000747fd7fddc76  push rax
0000747fd7fddc77  push rcx
0000747fd7fddc78  push rdx
0000747fd7fddc79  push rdi
0000747fd7fddc7a  push rsi
0000747fd7fddc7b  push r8
0000747fd7fddc7d  push r9
0000747fd7fddc7f  push r10
0000747fd7fddc81  push r11
0000747fd7fddc83  sub rsp, 0xF0
0000747fd7fddc8a  vmovaps [rsp], xmm0
0000747fd7fddc8f  vmovaps [rsp+0x10], xmm2
0000747fd7fddc95  vmovaps [rsp+0x20], xmm3
0000747fd7fddc9b  vmovaps [rsp+0x30], xmm4
0000747fd7fddca1  vmovaps [rsp+0x40], xmm5
0000747fd7fddca7  vmovaps [rsp+0x50], xmm6
0000747fd7fddcad  vmovaps [rsp+0x60], xmm7
0000747fd7fddcb3  vmovaps [rsp+0x70], xmm8
0000747fd7fddcb9  vmovaps [rsp+0x80], xmm9
0000747fd7fddcc2  vmovaps [rsp+0x90], xmm10
0000747fd7fddccb  vmovaps [rsp+0xA0], xmm11
0000747fd7fddcd4  vmovaps [rsp+0xB0], xmm12
0000747fd7fddcdd  vmovaps [rsp+0xC0], xmm13
0000747fd7fddce6  vmovaps [rsp+0xD0], xmm14
0000747fd7fddcef  vmovaps [rsp+0xE0], xmm15
0000747fd7fddcf8  sub rsp, 0x30
0000747fd7fddcfc  movaps [rsp], xmm1
0000747fd7fddd00  movaps [rsp+0x10], xmm15
0000747fd7fddd06  movaps [rsp+0x20], xmm9
0000747fd7fddd0c  lea rdi, [rsp]
0000747fd7fddd10  mov esi, 0x00
0000747fd7fddd15  mov rax, 0x6055A0B6E530
0000747fd7fddd1f  call rax
0000747fd7fddd21  movaps xmm1, [rsp]
0000747fd7fddd25  add rsp, 0x30
0000747fd7fddd29  vmovaps xmm0, [rsp]
0000747fd7fddd2e  vmovaps xmm2, [rsp+0x10]
0000747fd7fddd34  vmovaps xmm3, [rsp+0x20]
0000747fd7fddd3a  vmovaps xmm4, [rsp+0x30]
0000747fd7fddd40  vmovaps xmm5, [rsp+0x40]
0000747fd7fddd46  vmovaps xmm6, [rsp+0x50]
0000747fd7fddd4c  vmovaps xmm7, [rsp+0x60]
0000747fd7fddd52  vmovaps xmm8, [rsp+0x70]
0000747fd7fddd58  vmovaps xmm9, [rsp+0x80]
0000747fd7fddd61  vmovaps xmm10, [rsp+0x90]
0000747fd7fddd6a  vmovaps xmm11, [rsp+0xA0]
0000747fd7fddd73  vmovaps xmm12, [rsp+0xB0]
0000747fd7fddd7c  vmovaps xmm13, [rsp+0xC0]
0000747fd7fddd85  vmovaps xmm14, [rsp+0xD0]
0000747fd7fddd8e  vmovaps xmm15, [rsp+0xE0]
0000747fd7fddd97  add rsp, 0xF0
0000747fd7fddd9e  pop r11
0000747fd7fddda0  pop r10
0000747fd7fddda2  pop r9
0000747fd7fddda4  pop r8
0000747fd7fddda6  pop rsi
0000747fd7fddda7  pop rdi
0000747fd7fddda8  pop rdx
0000747fd7fddda9  pop rcx
0000747fd7fdddaa  pop rax
0000747fd7fdddab  add rsp, 0x08
0000747fd7fdddaf  jmp 0x0000747FD7FDBF7E
0000747fd7fdddb4  call 0x0000747FD7EC4620
0000747fd7fdddb9  jmp 0x0000747FD7FDBF8B
0000747fd7fdddbe  sub rsp, 0x08
0000747fd7fdddc2  push rax
0000747fd7fdddc3  push rcx
0000747fd7fdddc4  push rdx
0000747fd7fdddc5  push rdi
0000747fd7fdddc6  push rsi
0000747fd7fdddc7  push r8
0000747fd7fdddc9  push r9
0000747fd7fdddcb  push r10
0000747fd7fdddcd  push r11
0000747fd7fdddcf  sub rsp, 0xF0
0000747fd7fdddd6  vmovaps [rsp], xmm0
0000747fd7fddddb  vmovaps [rsp+0x10], xmm2
0000747fd7fddde1  vmovaps [rsp+0x20], xmm3
0000747fd7fddde7  vmovaps [rsp+0x30], xmm4
0000747fd7fddded  vmovaps [rsp+0x40], xmm5
0000747fd7fdddf3  vmovaps [rsp+0x50], xmm6
0000747fd7fdddf9  vmovaps [rsp+0x60], xmm7
0000747fd7fdddff  vmovaps [rsp+0x70], xmm8
0000747fd7fdde05  vmovaps [rsp+0x80], xmm9
0000747fd7fdde0e  vmovaps [rsp+0x90], xmm10
0000747fd7fdde17  vmovaps [rsp+0xA0], xmm11
0000747fd7fdde20  vmovaps [rsp+0xB0], xmm12
0000747fd7fdde29  vmovaps [rsp+0xC0], xmm13
0000747fd7fdde32  vmovaps [rsp+0xD0], xmm14
0000747fd7fdde3b  vmovaps [rsp+0xE0], xmm15
0000747fd7fdde44  sub rsp, 0x30
0000747fd7fdde48  movaps [rsp], xmm1
0000747fd7fdde4c  movaps [rsp+0x10], xmm5
0000747fd7fdde51  movaps [rsp+0x20], xmm7
0000747fd7fdde56  lea rdi, [rsp]
0000747fd7fdde5a  mov esi, 0x00
0000747fd7fdde5f  mov rax, 0x6055A0B6E530
0000747fd7fdde69  call rax
0000747fd7fdde6b  movaps xmm1, [rsp]
0000747fd7fdde6f  add rsp, 0x30
0000747fd7fdde73  vmovaps xmm0, [rsp]
0000747fd7fdde78  vmovaps xmm2, [rsp+0x10]
0000747fd7fdde7e  vmovaps xmm3, [rsp+0x20]
0000747fd7fdde84  vmovaps xmm4, [rsp+0x30]
0000747fd7fdde8a  vmovaps xmm5, [rsp+0x40]
0000747fd7fdde90  vmovaps xmm6, [rsp+0x50]
0000747fd7fdde96  vmovaps xmm7, [rsp+0x60]
0000747fd7fdde9c  vmovaps xmm8, [rsp+0x70]
0000747fd7fddea2  vmovaps xmm9, [rsp+0x80]
0000747fd7fddeab  vmovaps xmm10, [rsp+0x90]
0000747fd7fddeb4  vmovaps xmm11, [rsp+0xA0]
0000747fd7fddebd  vmovaps xmm12, [rsp+0xB0]
0000747fd7fddec6  vmovaps xmm13, [rsp+0xC0]
0000747fd7fddecf  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdded8  vmovaps xmm15, [rsp+0xE0]
0000747fd7fddee1  add rsp, 0xF0
0000747fd7fddee8  pop r11
0000747fd7fddeea  pop r10
0000747fd7fddeec  pop r9
0000747fd7fddeee  pop r8
0000747fd7fddef0  pop rsi
0000747fd7fddef1  pop rdi
0000747fd7fddef2  pop rdx
0000747fd7fddef3  pop rcx
0000747fd7fddef4  pop rax
0000747fd7fddef5  add rsp, 0x08
0000747fd7fddef9  jmp 0x0000747FD7FDC030
0000747fd7fddefe  sub rsp, 0x08
0000747fd7fddf02  push rax
0000747fd7fddf03  push rcx
0000747fd7fddf04  push rdx
0000747fd7fddf05  push rdi
0000747fd7fddf06  push rsi
0000747fd7fddf07  push r8
0000747fd7fddf09  push r9
0000747fd7fddf0b  push r10
0000747fd7fddf0d  push r11
0000747fd7fddf0f  sub rsp, 0xF0
0000747fd7fddf16  vmovaps [rsp], xmm0
0000747fd7fddf1b  vmovaps [rsp+0x10], xmm1
0000747fd7fddf21  vmovaps [rsp+0x20], xmm2
0000747fd7fddf27  vmovaps [rsp+0x30], xmm3
0000747fd7fddf2d  vmovaps [rsp+0x40], xmm4
0000747fd7fddf33  vmovaps [rsp+0x50], xmm5
0000747fd7fddf39  vmovaps [rsp+0x60], xmm6
0000747fd7fddf3f  vmovaps [rsp+0x70], xmm8
0000747fd7fddf45  vmovaps [rsp+0x80], xmm9
0000747fd7fddf4e  vmovaps [rsp+0x90], xmm10
0000747fd7fddf57  vmovaps [rsp+0xA0], xmm11
0000747fd7fddf60  vmovaps [rsp+0xB0], xmm12
0000747fd7fddf69  vmovaps [rsp+0xC0], xmm13
0000747fd7fddf72  vmovaps [rsp+0xD0], xmm14
0000747fd7fddf7b  vmovaps [rsp+0xE0], xmm15
0000747fd7fddf84  sub rsp, 0x30
0000747fd7fddf88  movaps [rsp], xmm7
0000747fd7fddf8c  movaps [rsp+0x10], xmm5
0000747fd7fddf91  movaps [rsp+0x20], xmm15
0000747fd7fddf97  lea rdi, [rsp]
0000747fd7fddf9b  mov esi, 0x00
0000747fd7fddfa0  mov rax, 0x6055A0B6E530
0000747fd7fddfaa  call rax
0000747fd7fddfac  movaps xmm7, [rsp]
0000747fd7fddfb0  add rsp, 0x30
0000747fd7fddfb4  vmovaps xmm0, [rsp]
0000747fd7fddfb9  vmovaps xmm1, [rsp+0x10]
0000747fd7fddfbf  vmovaps xmm2, [rsp+0x20]
0000747fd7fddfc5  vmovaps xmm3, [rsp+0x30]
0000747fd7fddfcb  vmovaps xmm4, [rsp+0x40]
0000747fd7fddfd1  vmovaps xmm5, [rsp+0x50]
0000747fd7fddfd7  vmovaps xmm6, [rsp+0x60]
0000747fd7fddfdd  vmovaps xmm8, [rsp+0x70]
0000747fd7fddfe3  vmovaps xmm9, [rsp+0x80]
0000747fd7fddfec  vmovaps xmm10, [rsp+0x90]
0000747fd7fddff5  vmovaps xmm11, [rsp+0xA0]
0000747fd7fddffe  vmovaps xmm12, [rsp+0xB0]
0000747fd7fde007  vmovaps xmm13, [rsp+0xC0]
0000747fd7fde010  vmovaps xmm14, [rsp+0xD0]
0000747fd7fde019  vmovaps xmm15, [rsp+0xE0]
0000747fd7fde022  add rsp, 0xF0
0000747fd7fde029  pop r11
0000747fd7fde02b  pop r10
0000747fd7fde02d  pop r9
0000747fd7fde02f  pop r8
0000747fd7fde031  pop rsi
0000747fd7fde032  pop rdi
0000747fd7fde033  pop rdx
0000747fd7fde034  pop rcx
0000747fd7fde035  pop rax
0000747fd7fde036  add rsp, 0x08
0000747fd7fde03a  jmp 0x0000747FD7FDC066
0000747fd7fde03f  call 0x0000747FD7EB52F0
0000747fd7fde044  jmp 0x0000747FD7FDC073
0000747fd7fde049  sub rsp, 0x08
0000747fd7fde04d  push rax
0000747fd7fde04e  push rcx
0000747fd7fde04f  push rdx
0000747fd7fde050  push rdi
0000747fd7fde051  push rsi
0000747fd7fde052  push r8
0000747fd7fde054  push r9
0000747fd7fde056  push r10
0000747fd7fde058  push r11
0000747fd7fde05a  sub rsp, 0xF0
0000747fd7fde061  vmovaps [rsp], xmm0
0000747fd7fde066  vmovaps [rsp+0x10], xmm1
0000747fd7fde06c  vmovaps [rsp+0x20], xmm2
0000747fd7fde072  vmovaps [rsp+0x30], xmm3
0000747fd7fde078  vmovaps [rsp+0x40], xmm4
0000747fd7fde07e  vmovaps [rsp+0x50], xmm5
0000747fd7fde084  vmovaps [rsp+0x60], xmm6
0000747fd7fde08a  vmovaps [rsp+0x70], xmm7
0000747fd7fde090  vmovaps [rsp+0x80], xmm8
0000747fd7fde099  vmovaps [rsp+0x90], xmm9
0000747fd7fde0a2  vmovaps [rsp+0xA0], xmm10
0000747fd7fde0ab  vmovaps [rsp+0xB0], xmm11
0000747fd7fde0b4  vmovaps [rsp+0xC0], xmm12
0000747fd7fde0bd  vmovaps [rsp+0xD0], xmm13
0000747fd7fde0c6  vmovaps [rsp+0xE0], xmm14
0000747fd7fde0cf  sub rsp, 0x30
0000747fd7fde0d3  movaps [rsp], xmm15
0000747fd7fde0d8  movaps [rsp+0x10], xmm5
0000747fd7fde0dd  movaps [rsp+0x20], xmm3
0000747fd7fde0e2  lea rdi, [rsp]
0000747fd7fde0e6  mov esi, 0x00
0000747fd7fde0eb  mov rax, 0x6055A0B6E530
0000747fd7fde0f5  call rax
0000747fd7fde0f7  movaps xmm15, [rsp]
0000747fd7fde0fc  add rsp, 0x30
0000747fd7fde100  vmovaps xmm0, [rsp]
0000747fd7fde105  vmovaps xmm1, [rsp+0x10]
0000747fd7fde10b  vmovaps xmm2, [rsp+0x20]
0000747fd7fde111  vmovaps xmm3, [rsp+0x30]
0000747fd7fde117  vmovaps xmm4, [rsp+0x40]
0000747fd7fde11d  vmovaps xmm5, [rsp+0x50]
0000747fd7fde123  vmovaps xmm6, [rsp+0x60]
0000747fd7fde129  vmovaps xmm7, [rsp+0x70]
0000747fd7fde12f  vmovaps xmm8, [rsp+0x80]
0000747fd7fde138  vmovaps xmm9, [rsp+0x90]
0000747fd7fde141  vmovaps xmm10, [rsp+0xA0]
0000747fd7fde14a  vmovaps xmm11, [rsp+0xB0]
0000747fd7fde153  vmovaps xmm12, [rsp+0xC0]
0000747fd7fde15c  vmovaps xmm13, [rsp+0xD0]
0000747fd7fde165  vmovaps xmm14, [rsp+0xE0]
0000747fd7fde16e  add rsp, 0xF0
0000747fd7fde175  pop r11
0000747fd7fde177  pop r10
0000747fd7fde179  pop r9
0000747fd7fde17b  pop r8
0000747fd7fde17d  pop rsi
0000747fd7fde17e  pop rdi
0000747fd7fde17f  pop rdx
0000747fd7fde180  pop rcx
0000747fd7fde181  pop rax
0000747fd7fde182  add rsp, 0x08
0000747fd7fde186  jmp 0x0000747FD7FDC099
0000747fd7fde18b  sub rsp, 0x08
0000747fd7fde18f  push rax
0000747fd7fde190  push rcx
0000747fd7fde191  push rdx
0000747fd7fde192  push rdi
0000747fd7fde193  push rsi
0000747fd7fde194  push r8
0000747fd7fde196  push r9
0000747fd7fde198  push r10
0000747fd7fde19a  push r11
0000747fd7fde19c  sub rsp, 0xF0
0000747fd7fde1a3  vmovaps [rsp], xmm0
0000747fd7fde1a8  vmovaps [rsp+0x10], xmm2
0000747fd7fde1ae  vmovaps [rsp+0x20], xmm3
0000747fd7fde1b4  vmovaps [rsp+0x30], xmm4
0000747fd7fde1ba  vmovaps [rsp+0x40], xmm5
0000747fd7fde1c0  vmovaps [rsp+0x50], xmm6
0000747fd7fde1c6  vmovaps [rsp+0x60], xmm7
0000747fd7fde1cc  vmovaps [rsp+0x70], xmm8
0000747fd7fde1d2  vmovaps [rsp+0x80], xmm9
0000747fd7fde1db  vmovaps [rsp+0x90], xmm10
0000747fd7fde1e4  vmovaps [rsp+0xA0], xmm11
0000747fd7fde1ed  vmovaps [rsp+0xB0], xmm12
0000747fd7fde1f6  vmovaps [rsp+0xC0], xmm13
0000747fd7fde1ff  vmovaps [rsp+0xD0], xmm14
0000747fd7fde208  vmovaps [rsp+0xE0], xmm15
0000747fd7fde211  sub rsp, 0x30
0000747fd7fde215  movaps [rsp], xmm1
0000747fd7fde219  movaps [rsp+0x10], xmm5
0000747fd7fde21e  movaps [rsp+0x20], xmm4
0000747fd7fde223  lea rdi, [rsp]
0000747fd7fde227  mov esi, 0x00
0000747fd7fde22c  mov rax, 0x6055A0B6E530
0000747fd7fde236  call rax
0000747fd7fde238  movaps xmm1, [rsp]
0000747fd7fde23c  add rsp, 0x30
0000747fd7fde240  vmovaps xmm0, [rsp]
0000747fd7fde245  vmovaps xmm2, [rsp+0x10]
0000747fd7fde24b  vmovaps xmm3, [rsp+0x20]
0000747fd7fde251  vmovaps xmm4, [rsp+0x30]
0000747fd7fde257  vmovaps xmm5, [rsp+0x40]
0000747fd7fde25d  vmovaps xmm6, [rsp+0x50]
0000747fd7fde263  vmovaps xmm7, [rsp+0x60]
0000747fd7fde269  vmovaps xmm8, [rsp+0x70]
0000747fd7fde26f  vmovaps xmm9, [rsp+0x80]
0000747fd7fde278  vmovaps xmm10, [rsp+0x90]
0000747fd7fde281  vmovaps xmm11, [rsp+0xA0]
0000747fd7fde28a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fde293  vmovaps xmm13, [rsp+0xC0]
0000747fd7fde29c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fde2a5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fde2ae  add rsp, 0xF0
0000747fd7fde2b5  pop r11
0000747fd7fde2b7  pop r10
0000747fd7fde2b9  pop r9
0000747fd7fde2bb  pop r8
0000747fd7fde2bd  pop rsi
0000747fd7fde2be  pop rdi
0000747fd7fde2bf  pop rdx
0000747fd7fde2c0  pop rcx
0000747fd7fde2c1  pop rax
0000747fd7fde2c2  add rsp, 0x08
0000747fd7fde2c6  jmp 0x0000747FD7FDC0B9
0000747fd7fde2cb  sub rsp, 0x08
0000747fd7fde2cf  push rax
0000747fd7fde2d0  push rcx
0000747fd7fde2d1  push rdx
0000747fd7fde2d2  push rdi
0000747fd7fde2d3  push rsi
0000747fd7fde2d4  push r8
0000747fd7fde2d6  push r9
0000747fd7fde2d8  push r10
0000747fd7fde2da  push r11
0000747fd7fde2dc  sub rsp, 0xF0
0000747fd7fde2e3  vmovaps [rsp], xmm0
0000747fd7fde2e8  vmovaps [rsp+0x10], xmm1
0000747fd7fde2ee  vmovaps [rsp+0x20], xmm2
0000747fd7fde2f4  vmovaps [rsp+0x30], xmm3
0000747fd7fde2fa  vmovaps [rsp+0x40], xmm5
0000747fd7fde300  vmovaps [rsp+0x50], xmm6
0000747fd7fde306  vmovaps [rsp+0x60], xmm7
0000747fd7fde30c  vmovaps [rsp+0x70], xmm8
0000747fd7fde312  vmovaps [rsp+0x80], xmm9
0000747fd7fde31b  vmovaps [rsp+0x90], xmm10
0000747fd7fde324  vmovaps [rsp+0xA0], xmm11
0000747fd7fde32d  vmovaps [rsp+0xB0], xmm12
0000747fd7fde336  vmovaps [rsp+0xC0], xmm13
0000747fd7fde33f  vmovaps [rsp+0xD0], xmm14
0000747fd7fde348  vmovaps [rsp+0xE0], xmm15
0000747fd7fde351  sub rsp, 0x30
0000747fd7fde355  movaps [rsp], xmm4
0000747fd7fde359  movaps [rsp+0x10], xmm3
0000747fd7fde35e  movaps [rsp+0x20], xmm5
0000747fd7fde363  lea rdi, [rsp]
0000747fd7fde367  mov esi, 0x00
0000747fd7fde36c  mov rax, 0x6055A0B6E530
0000747fd7fde376  call rax
0000747fd7fde378  movaps xmm4, [rsp]
0000747fd7fde37c  add rsp, 0x30
0000747fd7fde380  vmovaps xmm0, [rsp]
0000747fd7fde385  vmovaps xmm1, [rsp+0x10]
0000747fd7fde38b  vmovaps xmm2, [rsp+0x20]
0000747fd7fde391  vmovaps xmm3, [rsp+0x30]
0000747fd7fde397  vmovaps xmm5, [rsp+0x40]
0000747fd7fde39d  vmovaps xmm6, [rsp+0x50]
0000747fd7fde3a3  vmovaps xmm7, [rsp+0x60]
0000747fd7fde3a9  vmovaps xmm8, [rsp+0x70]
0000747fd7fde3af  vmovaps xmm9, [rsp+0x80]
0000747fd7fde3b8  vmovaps xmm10, [rsp+0x90]
0000747fd7fde3c1  vmovaps xmm11, [rsp+0xA0]
0000747fd7fde3ca  vmovaps xmm12, [rsp+0xB0]
0000747fd7fde3d3  vmovaps xmm13, [rsp+0xC0]
0000747fd7fde3dc  vmovaps xmm14, [rsp+0xD0]
0000747fd7fde3e5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fde3ee  add rsp, 0xF0
0000747fd7fde3f5  pop r11
0000747fd7fde3f7  pop r10
0000747fd7fde3f9  pop r9
0000747fd7fde3fb  pop r8
0000747fd7fde3fd  pop rsi
0000747fd7fde3fe  pop rdi
0000747fd7fde3ff  pop rdx
0000747fd7fde400  pop rcx
0000747fd7fde401  pop rax
0000747fd7fde402  add rsp, 0x08
0000747fd7fde406  jmp 0x0000747FD7FDC107
0000747fd7fde40b  call 0x0000747FD7EB52F0
0000747fd7fde410  jmp 0x0000747FD7FDC114
0000747fd7fde415  sub rsp, 0x08
0000747fd7fde419  push rax
0000747fd7fde41a  push rcx
0000747fd7fde41b  push rdx
0000747fd7fde41c  push rdi
0000747fd7fde41d  push rsi
0000747fd7fde41e  push r8
0000747fd7fde420  push r9
0000747fd7fde422  push r10
0000747fd7fde424  push r11
0000747fd7fde426  sub rsp, 0xF0
0000747fd7fde42d  vmovaps [rsp], xmm0
0000747fd7fde432  vmovaps [rsp+0x10], xmm1
0000747fd7fde438  vmovaps [rsp+0x20], xmm2
0000747fd7fde43e  vmovaps [rsp+0x30], xmm3
0000747fd7fde444  vmovaps [rsp+0x40], xmm4
0000747fd7fde44a  vmovaps [rsp+0x50], xmm6
0000747fd7fde450  vmovaps [rsp+0x60], xmm7
0000747fd7fde456  vmovaps [rsp+0x70], xmm8
0000747fd7fde45c  vmovaps [rsp+0x80], xmm9
0000747fd7fde465  vmovaps [rsp+0x90], xmm10
0000747fd7fde46e  vmovaps [rsp+0xA0], xmm11
0000747fd7fde477  vmovaps [rsp+0xB0], xmm12
0000747fd7fde480  vmovaps [rsp+0xC0], xmm13
0000747fd7fde489  vmovaps [rsp+0xD0], xmm14
0000747fd7fde492  vmovaps [rsp+0xE0], xmm15
0000747fd7fde49b  sub rsp, 0x30
0000747fd7fde49f  movaps [rsp], xmm5
0000747fd7fde4a3  movaps [rsp+0x10], xmm6
0000747fd7fde4a8  movaps [rsp+0x20], xmm3
0000747fd7fde4ad  lea rdi, [rsp]
0000747fd7fde4b1  mov esi, 0x00
0000747fd7fde4b6  mov rax, 0x6055A0B6E530
0000747fd7fde4c0  call rax
0000747fd7fde4c2  movaps xmm5, [rsp]
0000747fd7fde4c6  add rsp, 0x30
0000747fd7fde4ca  vmovaps xmm0, [rsp]
0000747fd7fde4cf  vmovaps xmm1, [rsp+0x10]
0000747fd7fde4d5  vmovaps xmm2, [rsp+0x20]
0000747fd7fde4db  vmovaps xmm3, [rsp+0x30]
0000747fd7fde4e1  vmovaps xmm4, [rsp+0x40]
0000747fd7fde4e7  vmovaps xmm6, [rsp+0x50]
0000747fd7fde4ed  vmovaps xmm7, [rsp+0x60]
0000747fd7fde4f3  vmovaps xmm8, [rsp+0x70]
0000747fd7fde4f9  vmovaps xmm9, [rsp+0x80]
0000747fd7fde502  vmovaps xmm10, [rsp+0x90]
0000747fd7fde50b  vmovaps xmm11, [rsp+0xA0]
0000747fd7fde514  vmovaps xmm12, [rsp+0xB0]
0000747fd7fde51d  vmovaps xmm13, [rsp+0xC0]
0000747fd7fde526  vmovaps xmm14, [rsp+0xD0]
0000747fd7fde52f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fde538  add rsp, 0xF0
0000747fd7fde53f  pop r11
0000747fd7fde541  pop r10
0000747fd7fde543  pop r9
0000747fd7fde545  pop r8
0000747fd7fde547  pop rsi
0000747fd7fde548  pop rdi
0000747fd7fde549  pop rdx
0000747fd7fde54a  pop rcx
0000747fd7fde54b  pop rax
0000747fd7fde54c  add rsp, 0x08
0000747fd7fde550  jmp 0x0000747FD7FDC13A
0000747fd7fde555  sub rsp, 0x08
0000747fd7fde559  push rax
0000747fd7fde55a  push rcx
0000747fd7fde55b  push rdx
0000747fd7fde55c  push rdi
0000747fd7fde55d  push rsi
0000747fd7fde55e  push r8
0000747fd7fde560  push r9
0000747fd7fde562  push r10
0000747fd7fde564  push r11
0000747fd7fde566  sub rsp, 0xF0
0000747fd7fde56d  vmovaps [rsp], xmm0
0000747fd7fde572  vmovaps [rsp+0x10], xmm1
0000747fd7fde578  vmovaps [rsp+0x20], xmm2
0000747fd7fde57e  vmovaps [rsp+0x30], xmm3
0000747fd7fde584  vmovaps [rsp+0x40], xmm4
0000747fd7fde58a  vmovaps [rsp+0x50], xmm5
0000747fd7fde590  vmovaps [rsp+0x60], xmm7
0000747fd7fde596  vmovaps [rsp+0x70], xmm8
0000747fd7fde59c  vmovaps [rsp+0x80], xmm9
0000747fd7fde5a5  vmovaps [rsp+0x90], xmm10
0000747fd7fde5ae  vmovaps [rsp+0xA0], xmm11
0000747fd7fde5b7  vmovaps [rsp+0xB0], xmm12
0000747fd7fde5c0  vmovaps [rsp+0xC0], xmm13
0000747fd7fde5c9  vmovaps [rsp+0xD0], xmm14
0000747fd7fde5d2  vmovaps [rsp+0xE0], xmm15
0000747fd7fde5db  sub rsp, 0x30
0000747fd7fde5df  movaps [rsp], xmm6
0000747fd7fde5e3  movaps [rsp+0x10], xmm9
0000747fd7fde5e9  movaps [rsp+0x20], xmm1
0000747fd7fde5ee  lea rdi, [rsp]
0000747fd7fde5f2  mov esi, 0x00
0000747fd7fde5f7  mov rax, 0x6055A0B6E530
0000747fd7fde601  call rax
0000747fd7fde603  movaps xmm6, [rsp]
0000747fd7fde607  add rsp, 0x30
0000747fd7fde60b  vmovaps xmm0, [rsp]
0000747fd7fde610  vmovaps xmm1, [rsp+0x10]
0000747fd7fde616  vmovaps xmm2, [rsp+0x20]
0000747fd7fde61c  vmovaps xmm3, [rsp+0x30]
0000747fd7fde622  vmovaps xmm4, [rsp+0x40]
0000747fd7fde628  vmovaps xmm5, [rsp+0x50]
0000747fd7fde62e  vmovaps xmm7, [rsp+0x60]
0000747fd7fde634  vmovaps xmm8, [rsp+0x70]
0000747fd7fde63a  vmovaps xmm9, [rsp+0x80]
0000747fd7fde643  vmovaps xmm10, [rsp+0x90]
0000747fd7fde64c  vmovaps xmm11, [rsp+0xA0]
0000747fd7fde655  vmovaps xmm12, [rsp+0xB0]
0000747fd7fde65e  vmovaps xmm13, [rsp+0xC0]
0000747fd7fde667  vmovaps xmm14, [rsp+0xD0]
0000747fd7fde670  vmovaps xmm15, [rsp+0xE0]
0000747fd7fde679  add rsp, 0xF0
0000747fd7fde680  pop r11
0000747fd7fde682  pop r10
0000747fd7fde684  pop r9
0000747fd7fde686  pop r8
0000747fd7fde688  pop rsi
0000747fd7fde689  pop rdi
0000747fd7fde68a  pop rdx
0000747fd7fde68b  pop rcx
0000747fd7fde68c  pop rax
0000747fd7fde68d  add rsp, 0x08
0000747fd7fde691  jmp 0x0000747FD7FDC15E
0000747fd7fde696  sub rsp, 0x08
0000747fd7fde69a  push rax
0000747fd7fde69b  push rcx
0000747fd7fde69c  push rdx
0000747fd7fde69d  push rdi
0000747fd7fde69e  push rsi
0000747fd7fde69f  push r8
0000747fd7fde6a1  push r9
0000747fd7fde6a3  push r10
0000747fd7fde6a5  push r11
0000747fd7fde6a7  sub rsp, 0xF0
0000747fd7fde6ae  vmovaps [rsp], xmm0
0000747fd7fde6b3  vmovaps [rsp+0x10], xmm1
0000747fd7fde6b9  vmovaps [rsp+0x20], xmm2
0000747fd7fde6bf  vmovaps [rsp+0x30], xmm3
0000747fd7fde6c5  vmovaps [rsp+0x40], xmm4
0000747fd7fde6cb  vmovaps [rsp+0x50], xmm5
0000747fd7fde6d1  vmovaps [rsp+0x60], xmm6
0000747fd7fde6d7  vmovaps [rsp+0x70], xmm7
0000747fd7fde6dd  vmovaps [rsp+0x80], xmm8
0000747fd7fde6e6  vmovaps [rsp+0x90], xmm10
0000747fd7fde6ef  vmovaps [rsp+0xA0], xmm11
0000747fd7fde6f8  vmovaps [rsp+0xB0], xmm12
0000747fd7fde701  vmovaps [rsp+0xC0], xmm13
0000747fd7fde70a  vmovaps [rsp+0xD0], xmm14
0000747fd7fde713  vmovaps [rsp+0xE0], xmm15
0000747fd7fde71c  sub rsp, 0x30
0000747fd7fde720  movaps [rsp], xmm9
0000747fd7fde725  movaps [rsp+0x10], xmm3
0000747fd7fde72a  movaps [rsp+0x20], xmm1
0000747fd7fde72f  lea rdi, [rsp]
0000747fd7fde733  mov esi, 0x00
0000747fd7fde738  mov rax, 0x6055A0B6E530
0000747fd7fde742  call rax
0000747fd7fde744  movaps xmm9, [rsp]
0000747fd7fde749  add rsp, 0x30
0000747fd7fde74d  vmovaps xmm0, [rsp]
0000747fd7fde752  vmovaps xmm1, [rsp+0x10]
0000747fd7fde758  vmovaps xmm2, [rsp+0x20]
0000747fd7fde75e  vmovaps xmm3, [rsp+0x30]
0000747fd7fde764  vmovaps xmm4, [rsp+0x40]
0000747fd7fde76a  vmovaps xmm5, [rsp+0x50]
0000747fd7fde770  vmovaps xmm6, [rsp+0x60]
0000747fd7fde776  vmovaps xmm7, [rsp+0x70]
0000747fd7fde77c  vmovaps xmm8, [rsp+0x80]
0000747fd7fde785  vmovaps xmm10, [rsp+0x90]
0000747fd7fde78e  vmovaps xmm11, [rsp+0xA0]
0000747fd7fde797  vmovaps xmm12, [rsp+0xB0]
0000747fd7fde7a0  vmovaps xmm13, [rsp+0xC0]
0000747fd7fde7a9  vmovaps xmm14, [rsp+0xD0]
0000747fd7fde7b2  vmovaps xmm15, [rsp+0xE0]
0000747fd7fde7bb  add rsp, 0xF0
0000747fd7fde7c2  pop r11
0000747fd7fde7c4  pop r10
0000747fd7fde7c6  pop r9
0000747fd7fde7c8  pop r8
0000747fd7fde7ca  pop rsi
0000747fd7fde7cb  pop rdi
0000747fd7fde7cc  pop rdx
0000747fd7fde7cd  pop rcx
0000747fd7fde7ce  pop rax
0000747fd7fde7cf  add rsp, 0x08
0000747fd7fde7d3  jmp 0x0000747FD7FDC1AA
0000747fd7fde7d8  call 0x0000747FD7EB52F0
0000747fd7fde7dd  jmp 0x0000747FD7FDC1B7
0000747fd7fde7e2  sub rsp, 0x08
0000747fd7fde7e6  push rax
0000747fd7fde7e7  push rcx
0000747fd7fde7e8  push rdx
0000747fd7fde7e9  push rdi
0000747fd7fde7ea  push rsi
0000747fd7fde7eb  push r8
0000747fd7fde7ed  push r9
0000747fd7fde7ef  push r10
0000747fd7fde7f1  push r11
0000747fd7fde7f3  sub rsp, 0xF0
0000747fd7fde7fa  vmovaps [rsp], xmm0
0000747fd7fde7ff  vmovaps [rsp+0x10], xmm1
0000747fd7fde805  vmovaps [rsp+0x20], xmm2
0000747fd7fde80b  vmovaps [rsp+0x30], xmm3
0000747fd7fde811  vmovaps [rsp+0x40], xmm4
0000747fd7fde817  vmovaps [rsp+0x50], xmm5
0000747fd7fde81d  vmovaps [rsp+0x60], xmm6
0000747fd7fde823  vmovaps [rsp+0x70], xmm7
0000747fd7fde829  vmovaps [rsp+0x80], xmm8
0000747fd7fde832  vmovaps [rsp+0x90], xmm9
0000747fd7fde83b  vmovaps [rsp+0xA0], xmm10
0000747fd7fde844  vmovaps [rsp+0xB0], xmm11
0000747fd7fde84d  vmovaps [rsp+0xC0], xmm12
0000747fd7fde856  vmovaps [rsp+0xD0], xmm13
0000747fd7fde85f  vmovaps [rsp+0xE0], xmm14
0000747fd7fde868  sub rsp, 0x30
0000747fd7fde86c  movaps [rsp], xmm15
0000747fd7fde871  movaps [rsp+0x10], xmm3
0000747fd7fde876  movaps [rsp+0x20], xmm7
0000747fd7fde87b  lea rdi, [rsp]
0000747fd7fde87f  mov esi, 0x00
0000747fd7fde884  mov rax, 0x6055A0B6E530
0000747fd7fde88e  call rax
0000747fd7fde890  movaps xmm15, [rsp]
0000747fd7fde895  add rsp, 0x30
0000747fd7fde899  vmovaps xmm0, [rsp]
0000747fd7fde89e  vmovaps xmm1, [rsp+0x10]
0000747fd7fde8a4  vmovaps xmm2, [rsp+0x20]
0000747fd7fde8aa  vmovaps xmm3, [rsp+0x30]
0000747fd7fde8b0  vmovaps xmm4, [rsp+0x40]
0000747fd7fde8b6  vmovaps xmm5, [rsp+0x50]
0000747fd7fde8bc  vmovaps xmm6, [rsp+0x60]
0000747fd7fde8c2  vmovaps xmm7, [rsp+0x70]
0000747fd7fde8c8  vmovaps xmm8, [rsp+0x80]
0000747fd7fde8d1  vmovaps xmm9, [rsp+0x90]
0000747fd7fde8da  vmovaps xmm10, [rsp+0xA0]
0000747fd7fde8e3  vmovaps xmm11, [rsp+0xB0]
0000747fd7fde8ec  vmovaps xmm12, [rsp+0xC0]
0000747fd7fde8f5  vmovaps xmm13, [rsp+0xD0]
0000747fd7fde8fe  vmovaps xmm14, [rsp+0xE0]
0000747fd7fde907  add rsp, 0xF0
0000747fd7fde90e  pop r11
0000747fd7fde910  pop r10
0000747fd7fde912  pop r9
0000747fd7fde914  pop r8
0000747fd7fde916  pop rsi
0000747fd7fde917  pop rdi
0000747fd7fde918  pop rdx
0000747fd7fde919  pop rcx
0000747fd7fde91a  pop rax
0000747fd7fde91b  add rsp, 0x08
0000747fd7fde91f  jmp 0x0000747FD7FDC1E3
0000747fd7fde924  sub rsp, 0x08
0000747fd7fde928  push rax
0000747fd7fde929  push rcx
0000747fd7fde92a  push rdx
0000747fd7fde92b  push rdi
0000747fd7fde92c  push rsi
0000747fd7fde92d  push r8
0000747fd7fde92f  push r9
0000747fd7fde931  push r10
0000747fd7fde933  push r11
0000747fd7fde935  sub rsp, 0xF0
0000747fd7fde93c  vmovaps [rsp], xmm0
0000747fd7fde941  vmovaps [rsp+0x10], xmm1
0000747fd7fde947  vmovaps [rsp+0x20], xmm2
0000747fd7fde94d  vmovaps [rsp+0x30], xmm4
0000747fd7fde953  vmovaps [rsp+0x40], xmm5
0000747fd7fde959  vmovaps [rsp+0x50], xmm6
0000747fd7fde95f  vmovaps [rsp+0x60], xmm7
0000747fd7fde965  vmovaps [rsp+0x70], xmm8
0000747fd7fde96b  vmovaps [rsp+0x80], xmm9
0000747fd7fde974  vmovaps [rsp+0x90], xmm10
0000747fd7fde97d  vmovaps [rsp+0xA0], xmm11
0000747fd7fde986  vmovaps [rsp+0xB0], xmm12
0000747fd7fde98f  vmovaps [rsp+0xC0], xmm13
0000747fd7fde998  vmovaps [rsp+0xD0], xmm14
0000747fd7fde9a1  vmovaps [rsp+0xE0], xmm15
0000747fd7fde9aa  sub rsp, 0x30
0000747fd7fde9ae  movaps [rsp], xmm3
0000747fd7fde9b2  movaps [rsp+0x10], xmm1
0000747fd7fde9b7  movaps [rsp+0x20], xmm15
0000747fd7fde9bd  lea rdi, [rsp]
0000747fd7fde9c1  mov esi, 0x00
0000747fd7fde9c6  mov rax, 0x6055A0B6E530
0000747fd7fde9d0  call rax
0000747fd7fde9d2  movaps xmm3, [rsp]
0000747fd7fde9d6  add rsp, 0x30
0000747fd7fde9da  vmovaps xmm0, [rsp]
0000747fd7fde9df  vmovaps xmm1, [rsp+0x10]
0000747fd7fde9e5  vmovaps xmm2, [rsp+0x20]
0000747fd7fde9eb  vmovaps xmm4, [rsp+0x30]
0000747fd7fde9f1  vmovaps xmm5, [rsp+0x40]
0000747fd7fde9f7  vmovaps xmm6, [rsp+0x50]
0000747fd7fde9fd  vmovaps xmm7, [rsp+0x60]
0000747fd7fdea03  vmovaps xmm8, [rsp+0x70]
0000747fd7fdea09  vmovaps xmm9, [rsp+0x80]
0000747fd7fdea12  vmovaps xmm10, [rsp+0x90]
0000747fd7fdea1b  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdea24  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdea2d  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdea36  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdea3f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdea48  add rsp, 0xF0
0000747fd7fdea4f  pop r11
0000747fd7fdea51  pop r10
0000747fd7fdea53  pop r9
0000747fd7fdea55  pop r8
0000747fd7fdea57  pop rsi
0000747fd7fdea58  pop rdi
0000747fd7fdea59  pop rdx
0000747fd7fdea5a  pop rcx
0000747fd7fdea5b  pop rax
0000747fd7fdea5c  add rsp, 0x08
0000747fd7fdea60  jmp 0x0000747FD7FDC272
0000747fd7fdea65  call 0x0000747FD7EB52F0
0000747fd7fdea6a  jmp 0x0000747FD7FDC27C
0000747fd7fdea6f  sub rsp, 0x08
0000747fd7fdea73  push rax
0000747fd7fdea74  push rcx
0000747fd7fdea75  push rdx
0000747fd7fdea76  push rdi
0000747fd7fdea77  push rsi
0000747fd7fdea78  push r8
0000747fd7fdea7a  push r9
0000747fd7fdea7c  push r10
0000747fd7fdea7e  push r11
0000747fd7fdea80  sub rsp, 0xF0
0000747fd7fdea87  vmovaps [rsp], xmm0
0000747fd7fdea8c  vmovaps [rsp+0x10], xmm1
0000747fd7fdea92  vmovaps [rsp+0x20], xmm2
0000747fd7fdea98  vmovaps [rsp+0x30], xmm3
0000747fd7fdea9e  vmovaps [rsp+0x40], xmm4
0000747fd7fdeaa4  vmovaps [rsp+0x50], xmm5
0000747fd7fdeaaa  vmovaps [rsp+0x60], xmm6
0000747fd7fdeab0  vmovaps [rsp+0x70], xmm7
0000747fd7fdeab6  vmovaps [rsp+0x80], xmm8
0000747fd7fdeabf  vmovaps [rsp+0x90], xmm9
0000747fd7fdeac8  vmovaps [rsp+0xA0], xmm10
0000747fd7fdead1  vmovaps [rsp+0xB0], xmm11
0000747fd7fdeada  vmovaps [rsp+0xC0], xmm12
0000747fd7fdeae3  vmovaps [rsp+0xD0], xmm13
0000747fd7fdeaec  vmovaps [rsp+0xE0], xmm14
0000747fd7fdeaf5  sub rsp, 0x30
0000747fd7fdeaf9  movaps [rsp], xmm15
0000747fd7fdeafe  movaps [rsp+0x10], xmm14
0000747fd7fdeb04  movaps [rsp+0x20], xmm4
0000747fd7fdeb09  lea rdi, [rsp]
0000747fd7fdeb0d  mov esi, 0x00
0000747fd7fdeb12  mov rax, 0x6055A0B6E530
0000747fd7fdeb1c  call rax
0000747fd7fdeb1e  movaps xmm15, [rsp]
0000747fd7fdeb23  add rsp, 0x30
0000747fd7fdeb27  vmovaps xmm0, [rsp]
0000747fd7fdeb2c  vmovaps xmm1, [rsp+0x10]
0000747fd7fdeb32  vmovaps xmm2, [rsp+0x20]
0000747fd7fdeb38  vmovaps xmm3, [rsp+0x30]
0000747fd7fdeb3e  vmovaps xmm4, [rsp+0x40]
0000747fd7fdeb44  vmovaps xmm5, [rsp+0x50]
0000747fd7fdeb4a  vmovaps xmm6, [rsp+0x60]
0000747fd7fdeb50  vmovaps xmm7, [rsp+0x70]
0000747fd7fdeb56  vmovaps xmm8, [rsp+0x80]
0000747fd7fdeb5f  vmovaps xmm9, [rsp+0x90]
0000747fd7fdeb68  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdeb71  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdeb7a  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdeb83  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdeb8c  vmovaps xmm14, [rsp+0xE0]
0000747fd7fdeb95  add rsp, 0xF0
0000747fd7fdeb9c  pop r11
0000747fd7fdeb9e  pop r10
0000747fd7fdeba0  pop r9
0000747fd7fdeba2  pop r8
0000747fd7fdeba4  pop rsi
0000747fd7fdeba5  pop rdi
0000747fd7fdeba6  pop rdx
0000747fd7fdeba7  pop rcx
0000747fd7fdeba8  pop rax
0000747fd7fdeba9  add rsp, 0x08
0000747fd7fdebad  jmp 0x0000747FD7FDC2AA
0000747fd7fdebb2  sub rsp, 0x08
0000747fd7fdebb6  push rax
0000747fd7fdebb7  push rcx
0000747fd7fdebb8  push rdx
0000747fd7fdebb9  push rdi
0000747fd7fdebba  push rsi
0000747fd7fdebbb  push r8
0000747fd7fdebbd  push r9
0000747fd7fdebbf  push r10
0000747fd7fdebc1  push r11
0000747fd7fdebc3  sub rsp, 0xF0
0000747fd7fdebca  vmovaps [rsp], xmm0
0000747fd7fdebcf  vmovaps [rsp+0x10], xmm1
0000747fd7fdebd5  vmovaps [rsp+0x20], xmm2
0000747fd7fdebdb  vmovaps [rsp+0x30], xmm3
0000747fd7fdebe1  vmovaps [rsp+0x40], xmm4
0000747fd7fdebe7  vmovaps [rsp+0x50], xmm5
0000747fd7fdebed  vmovaps [rsp+0x60], xmm6
0000747fd7fdebf3  vmovaps [rsp+0x70], xmm7
0000747fd7fdebf9  vmovaps [rsp+0x80], xmm8
0000747fd7fdec02  vmovaps [rsp+0x90], xmm9
0000747fd7fdec0b  vmovaps [rsp+0xA0], xmm10
0000747fd7fdec14  vmovaps [rsp+0xB0], xmm11
0000747fd7fdec1d  vmovaps [rsp+0xC0], xmm12
0000747fd7fdec26  vmovaps [rsp+0xD0], xmm13
0000747fd7fdec2f  vmovaps [rsp+0xE0], xmm15
0000747fd7fdec38  sub rsp, 0x30
0000747fd7fdec3c  movaps [rsp], xmm14
0000747fd7fdec41  movaps [rsp+0x10], xmm2
0000747fd7fdec46  movaps [rsp+0x20], xmm1
0000747fd7fdec4b  lea rdi, [rsp]
0000747fd7fdec4f  mov esi, 0x00
0000747fd7fdec54  mov rax, 0x6055A0B6E530
0000747fd7fdec5e  call rax
0000747fd7fdec60  movaps xmm14, [rsp]
0000747fd7fdec65  add rsp, 0x30
0000747fd7fdec69  vmovaps xmm0, [rsp]
0000747fd7fdec6e  vmovaps xmm1, [rsp+0x10]
0000747fd7fdec74  vmovaps xmm2, [rsp+0x20]
0000747fd7fdec7a  vmovaps xmm3, [rsp+0x30]
0000747fd7fdec80  vmovaps xmm4, [rsp+0x40]
0000747fd7fdec86  vmovaps xmm5, [rsp+0x50]
0000747fd7fdec8c  vmovaps xmm6, [rsp+0x60]
0000747fd7fdec92  vmovaps xmm7, [rsp+0x70]
0000747fd7fdec98  vmovaps xmm8, [rsp+0x80]
0000747fd7fdeca1  vmovaps xmm9, [rsp+0x90]
0000747fd7fdecaa  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdecb3  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdecbc  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdecc5  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdecce  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdecd7  add rsp, 0xF0
0000747fd7fdecde  pop r11
0000747fd7fdece0  pop r10
0000747fd7fdece2  pop r9
0000747fd7fdece4  pop r8
0000747fd7fdece6  pop rsi
0000747fd7fdece7  pop rdi
0000747fd7fdece8  pop rdx
0000747fd7fdece9  pop rcx
0000747fd7fdecea  pop rax
0000747fd7fdeceb  add rsp, 0x08
0000747fd7fdecef  jmp 0x0000747FD7FDC2D0
0000747fd7fdecf4  sub rsp, 0x08
0000747fd7fdecf8  push rax
0000747fd7fdecf9  push rcx
0000747fd7fdecfa  push rdx
0000747fd7fdecfb  push rdi
0000747fd7fdecfc  push rsi
0000747fd7fdecfd  push r8
0000747fd7fdecff  push r9
0000747fd7fded01  push r10
0000747fd7fded03  push r11
0000747fd7fded05  sub rsp, 0xF0
0000747fd7fded0c  vmovaps [rsp], xmm0
0000747fd7fded11  vmovaps [rsp+0x10], xmm2
0000747fd7fded17  vmovaps [rsp+0x20], xmm3
0000747fd7fded1d  vmovaps [rsp+0x30], xmm4
0000747fd7fded23  vmovaps [rsp+0x40], xmm5
0000747fd7fded29  vmovaps [rsp+0x50], xmm6
0000747fd7fded2f  vmovaps [rsp+0x60], xmm7
0000747fd7fded35  vmovaps [rsp+0x70], xmm8
0000747fd7fded3b  vmovaps [rsp+0x80], xmm9
0000747fd7fded44  vmovaps [rsp+0x90], xmm10
0000747fd7fded4d  vmovaps [rsp+0xA0], xmm11
0000747fd7fded56  vmovaps [rsp+0xB0], xmm12
0000747fd7fded5f  vmovaps [rsp+0xC0], xmm13
0000747fd7fded68  vmovaps [rsp+0xD0], xmm14
0000747fd7fded71  vmovaps [rsp+0xE0], xmm15
0000747fd7fded7a  sub rsp, 0x30
0000747fd7fded7e  movaps [rsp], xmm1
0000747fd7fded82  movaps [rsp+0x10], xmm4
0000747fd7fded87  movaps [rsp+0x20], xmm9
0000747fd7fded8d  lea rdi, [rsp]
0000747fd7fded91  mov esi, 0x00
0000747fd7fded96  mov rax, 0x6055A0B6E530
0000747fd7fdeda0  call rax
0000747fd7fdeda2  movaps xmm1, [rsp]
0000747fd7fdeda6  add rsp, 0x30
0000747fd7fdedaa  vmovaps xmm0, [rsp]
0000747fd7fdedaf  vmovaps xmm2, [rsp+0x10]
0000747fd7fdedb5  vmovaps xmm3, [rsp+0x20]
0000747fd7fdedbb  vmovaps xmm4, [rsp+0x30]
0000747fd7fdedc1  vmovaps xmm5, [rsp+0x40]
0000747fd7fdedc7  vmovaps xmm6, [rsp+0x50]
0000747fd7fdedcd  vmovaps xmm7, [rsp+0x60]
0000747fd7fdedd3  vmovaps xmm8, [rsp+0x70]
0000747fd7fdedd9  vmovaps xmm9, [rsp+0x80]
0000747fd7fdede2  vmovaps xmm10, [rsp+0x90]
0000747fd7fdedeb  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdedf4  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdedfd  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdee06  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdee0f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdee18  add rsp, 0xF0
0000747fd7fdee1f  pop r11
0000747fd7fdee21  pop r10
0000747fd7fdee23  pop r9
0000747fd7fdee25  pop r8
0000747fd7fdee27  pop rsi
0000747fd7fdee28  pop rdi
0000747fd7fdee29  pop rdx
0000747fd7fdee2a  pop rcx
0000747fd7fdee2b  pop rax
0000747fd7fdee2c  add rsp, 0x08
0000747fd7fdee30  jmp 0x0000747FD7FDC2EE
0000747fd7fdee35  sub rsp, 0x08
0000747fd7fdee39  push rax
0000747fd7fdee3a  push rcx
0000747fd7fdee3b  push rdx
0000747fd7fdee3c  push rdi
0000747fd7fdee3d  push rsi
0000747fd7fdee3e  push r8
0000747fd7fdee40  push r9
0000747fd7fdee42  push r10
0000747fd7fdee44  push r11
0000747fd7fdee46  sub rsp, 0xF0
0000747fd7fdee4d  vmovaps [rsp], xmm0
0000747fd7fdee52  vmovaps [rsp+0x10], xmm1
0000747fd7fdee58  vmovaps [rsp+0x20], xmm2
0000747fd7fdee5e  vmovaps [rsp+0x30], xmm3
0000747fd7fdee64  vmovaps [rsp+0x40], xmm5
0000747fd7fdee6a  vmovaps [rsp+0x50], xmm6
0000747fd7fdee70  vmovaps [rsp+0x60], xmm7
0000747fd7fdee76  vmovaps [rsp+0x70], xmm8
0000747fd7fdee7c  vmovaps [rsp+0x80], xmm9
0000747fd7fdee85  vmovaps [rsp+0x90], xmm10
0000747fd7fdee8e  vmovaps [rsp+0xA0], xmm11
0000747fd7fdee97  vmovaps [rsp+0xB0], xmm12
0000747fd7fdeea0  vmovaps [rsp+0xC0], xmm13
0000747fd7fdeea9  vmovaps [rsp+0xD0], xmm14
0000747fd7fdeeb2  vmovaps [rsp+0xE0], xmm15
0000747fd7fdeebb  sub rsp, 0x30
0000747fd7fdeebf  movaps [rsp], xmm4
0000747fd7fdeec3  movaps [rsp+0x10], xmm2
0000747fd7fdeec8  movaps [rsp+0x20], xmm9
0000747fd7fdeece  lea rdi, [rsp]
0000747fd7fdeed2  mov esi, 0x00
0000747fd7fdeed7  mov rax, 0x6055A0B6E530
0000747fd7fdeee1  call rax
0000747fd7fdeee3  movaps xmm4, [rsp]
0000747fd7fdeee7  add rsp, 0x30
0000747fd7fdeeeb  vmovaps xmm0, [rsp]
0000747fd7fdeef0  vmovaps xmm1, [rsp+0x10]
0000747fd7fdeef6  vmovaps xmm2, [rsp+0x20]
0000747fd7fdeefc  vmovaps xmm3, [rsp+0x30]
0000747fd7fdef02  vmovaps xmm5, [rsp+0x40]
0000747fd7fdef08  vmovaps xmm6, [rsp+0x50]
0000747fd7fdef0e  vmovaps xmm7, [rsp+0x60]
0000747fd7fdef14  vmovaps xmm8, [rsp+0x70]
0000747fd7fdef1a  vmovaps xmm9, [rsp+0x80]
0000747fd7fdef23  vmovaps xmm10, [rsp+0x90]
0000747fd7fdef2c  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdef35  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdef3e  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdef47  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdef50  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdef59  add rsp, 0xF0
0000747fd7fdef60  pop r11
0000747fd7fdef62  pop r10
0000747fd7fdef64  pop r9
0000747fd7fdef66  pop r8
0000747fd7fdef68  pop rsi
0000747fd7fdef69  pop rdi
0000747fd7fdef6a  pop rdx
0000747fd7fdef6b  pop rcx
0000747fd7fdef6c  pop rax
0000747fd7fdef6d  add rsp, 0x08
0000747fd7fdef71  jmp 0x0000747FD7FDC31E
0000747fd7fdef76  sub rsp, 0x08
0000747fd7fdef7a  push rax
0000747fd7fdef7b  push rcx
0000747fd7fdef7c  push rdx
0000747fd7fdef7d  push rdi
0000747fd7fdef7e  push rsi
0000747fd7fdef7f  push r8
0000747fd7fdef81  push r9
0000747fd7fdef83  push r10
0000747fd7fdef85  push r11
0000747fd7fdef87  sub rsp, 0xF0
0000747fd7fdef8e  vmovaps [rsp], xmm0
0000747fd7fdef93  vmovaps [rsp+0x10], xmm1
0000747fd7fdef99  vmovaps [rsp+0x20], xmm2
0000747fd7fdef9f  vmovaps [rsp+0x30], xmm3
0000747fd7fdefa5  vmovaps [rsp+0x40], xmm4
0000747fd7fdefab  vmovaps [rsp+0x50], xmm5
0000747fd7fdefb1  vmovaps [rsp+0x60], xmm6
0000747fd7fdefb7  vmovaps [rsp+0x70], xmm7
0000747fd7fdefbd  vmovaps [rsp+0x80], xmm8
0000747fd7fdefc6  vmovaps [rsp+0x90], xmm10
0000747fd7fdefcf  vmovaps [rsp+0xA0], xmm11
0000747fd7fdefd8  vmovaps [rsp+0xB0], xmm12
0000747fd7fdefe1  vmovaps [rsp+0xC0], xmm13
0000747fd7fdefea  vmovaps [rsp+0xD0], xmm14
0000747fd7fdeff3  vmovaps [rsp+0xE0], xmm15
0000747fd7fdeffc  sub rsp, 0x30
0000747fd7fdf000  movaps [rsp], xmm9
0000747fd7fdf005  movaps [rsp+0x10], xmm2
0000747fd7fdf00a  movaps [rsp+0x20], xmm1
0000747fd7fdf00f  lea rdi, [rsp]
0000747fd7fdf013  mov esi, 0x00
0000747fd7fdf018  mov rax, 0x6055A0B6E530
0000747fd7fdf022  call rax
0000747fd7fdf024  movaps xmm9, [rsp]
0000747fd7fdf029  add rsp, 0x30
0000747fd7fdf02d  vmovaps xmm0, [rsp]
0000747fd7fdf032  vmovaps xmm1, [rsp+0x10]
0000747fd7fdf038  vmovaps xmm2, [rsp+0x20]
0000747fd7fdf03e  vmovaps xmm3, [rsp+0x30]
0000747fd7fdf044  vmovaps xmm4, [rsp+0x40]
0000747fd7fdf04a  vmovaps xmm5, [rsp+0x50]
0000747fd7fdf050  vmovaps xmm6, [rsp+0x60]
0000747fd7fdf056  vmovaps xmm7, [rsp+0x70]
0000747fd7fdf05c  vmovaps xmm8, [rsp+0x80]
0000747fd7fdf065  vmovaps xmm10, [rsp+0x90]
0000747fd7fdf06e  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdf077  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdf080  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdf089  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdf092  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdf09b  add rsp, 0xF0
0000747fd7fdf0a2  pop r11
0000747fd7fdf0a4  pop r10
0000747fd7fdf0a6  pop r9
0000747fd7fdf0a8  pop r8
0000747fd7fdf0aa  pop rsi
0000747fd7fdf0ab  pop rdi
0000747fd7fdf0ac  pop rdx
0000747fd7fdf0ad  pop rcx
0000747fd7fdf0ae  pop rax
0000747fd7fdf0af  add rsp, 0x08
0000747fd7fdf0b3  jmp 0x0000747FD7FDC354
0000747fd7fdf0b8  sub rsp, 0x08
0000747fd7fdf0bc  push rax
0000747fd7fdf0bd  push rcx
0000747fd7fdf0be  push rdx
0000747fd7fdf0bf  push rdi
0000747fd7fdf0c0  push rsi
0000747fd7fdf0c1  push r8
0000747fd7fdf0c3  push r9
0000747fd7fdf0c5  push r10
0000747fd7fdf0c7  push r11
0000747fd7fdf0c9  sub rsp, 0xF0
0000747fd7fdf0d0  vmovaps [rsp], xmm0
0000747fd7fdf0d5  vmovaps [rsp+0x10], xmm2
0000747fd7fdf0db  vmovaps [rsp+0x20], xmm3
0000747fd7fdf0e1  vmovaps [rsp+0x30], xmm4
0000747fd7fdf0e7  vmovaps [rsp+0x40], xmm5
0000747fd7fdf0ed  vmovaps [rsp+0x50], xmm6
0000747fd7fdf0f3  vmovaps [rsp+0x60], xmm7
0000747fd7fdf0f9  vmovaps [rsp+0x70], xmm8
0000747fd7fdf0ff  vmovaps [rsp+0x80], xmm9
0000747fd7fdf108  vmovaps [rsp+0x90], xmm10
0000747fd7fdf111  vmovaps [rsp+0xA0], xmm11
0000747fd7fdf11a  vmovaps [rsp+0xB0], xmm12
0000747fd7fdf123  vmovaps [rsp+0xC0], xmm13
0000747fd7fdf12c  vmovaps [rsp+0xD0], xmm14
0000747fd7fdf135  vmovaps [rsp+0xE0], xmm15
0000747fd7fdf13e  sub rsp, 0x30
0000747fd7fdf142  movaps [rsp], xmm1
0000747fd7fdf146  movaps [rsp+0x10], xmm15
0000747fd7fdf14c  movaps [rsp+0x20], xmm6
0000747fd7fdf151  lea rdi, [rsp]
0000747fd7fdf155  mov esi, 0x00
0000747fd7fdf15a  mov rax, 0x6055A0B6E530
0000747fd7fdf164  call rax
0000747fd7fdf166  movaps xmm1, [rsp]
0000747fd7fdf16a  add rsp, 0x30
0000747fd7fdf16e  vmovaps xmm0, [rsp]
0000747fd7fdf173  vmovaps xmm2, [rsp+0x10]
0000747fd7fdf179  vmovaps xmm3, [rsp+0x20]
0000747fd7fdf17f  vmovaps xmm4, [rsp+0x30]
0000747fd7fdf185  vmovaps xmm5, [rsp+0x40]
0000747fd7fdf18b  vmovaps xmm6, [rsp+0x50]
0000747fd7fdf191  vmovaps xmm7, [rsp+0x60]
0000747fd7fdf197  vmovaps xmm8, [rsp+0x70]
0000747fd7fdf19d  vmovaps xmm9, [rsp+0x80]
0000747fd7fdf1a6  vmovaps xmm10, [rsp+0x90]
0000747fd7fdf1af  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdf1b8  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdf1c1  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdf1ca  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdf1d3  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdf1dc  add rsp, 0xF0
0000747fd7fdf1e3  pop r11
0000747fd7fdf1e5  pop r10
0000747fd7fdf1e7  pop r9
0000747fd7fdf1e9  pop r8
0000747fd7fdf1eb  pop rsi
0000747fd7fdf1ec  pop rdi
0000747fd7fdf1ed  pop rdx
0000747fd7fdf1ee  pop rcx
0000747fd7fdf1ef  pop rax
0000747fd7fdf1f0  add rsp, 0x08
0000747fd7fdf1f4  jmp 0x0000747FD7FDC375
0000747fd7fdf1f9  sub rsp, 0x08
0000747fd7fdf1fd  push rax
0000747fd7fdf1fe  push rcx
0000747fd7fdf1ff  push rdx
0000747fd7fdf200  push rdi
0000747fd7fdf201  push rsi
0000747fd7fdf202  push r8
0000747fd7fdf204  push r9
0000747fd7fdf206  push r10
0000747fd7fdf208  push r11
0000747fd7fdf20a  sub rsp, 0xF0
0000747fd7fdf211  vmovaps [rsp], xmm0
0000747fd7fdf216  vmovaps [rsp+0x10], xmm1
0000747fd7fdf21c  vmovaps [rsp+0x20], xmm2
0000747fd7fdf222  vmovaps [rsp+0x30], xmm3
0000747fd7fdf228  vmovaps [rsp+0x40], xmm4
0000747fd7fdf22e  vmovaps [rsp+0x50], xmm5
0000747fd7fdf234  vmovaps [rsp+0x60], xmm6
0000747fd7fdf23a  vmovaps [rsp+0x70], xmm7
0000747fd7fdf240  vmovaps [rsp+0x80], xmm8
0000747fd7fdf249  vmovaps [rsp+0x90], xmm9
0000747fd7fdf252  vmovaps [rsp+0xA0], xmm10
0000747fd7fdf25b  vmovaps [rsp+0xB0], xmm11
0000747fd7fdf264  vmovaps [rsp+0xC0], xmm12
0000747fd7fdf26d  vmovaps [rsp+0xD0], xmm13
0000747fd7fdf276  vmovaps [rsp+0xE0], xmm14
0000747fd7fdf27f  sub rsp, 0x30
0000747fd7fdf283  movaps [rsp], xmm15
0000747fd7fdf288  movaps [rsp+0x10], xmm5
0000747fd7fdf28d  movaps [rsp+0x20], xmm3
0000747fd7fdf292  lea rdi, [rsp]
0000747fd7fdf296  mov esi, 0x00
0000747fd7fdf29b  mov rax, 0x6055A0B6E530
0000747fd7fdf2a5  call rax
0000747fd7fdf2a7  movaps xmm15, [rsp]
0000747fd7fdf2ac  add rsp, 0x30
0000747fd7fdf2b0  vmovaps xmm0, [rsp]
0000747fd7fdf2b5  vmovaps xmm1, [rsp+0x10]
0000747fd7fdf2bb  vmovaps xmm2, [rsp+0x20]
0000747fd7fdf2c1  vmovaps xmm3, [rsp+0x30]
0000747fd7fdf2c7  vmovaps xmm4, [rsp+0x40]
0000747fd7fdf2cd  vmovaps xmm5, [rsp+0x50]
0000747fd7fdf2d3  vmovaps xmm6, [rsp+0x60]
0000747fd7fdf2d9  vmovaps xmm7, [rsp+0x70]
0000747fd7fdf2df  vmovaps xmm8, [rsp+0x80]
0000747fd7fdf2e8  vmovaps xmm9, [rsp+0x90]
0000747fd7fdf2f1  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdf2fa  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdf303  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdf30c  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdf315  vmovaps xmm14, [rsp+0xE0]
0000747fd7fdf31e  add rsp, 0xF0
0000747fd7fdf325  pop r11
0000747fd7fdf327  pop r10
0000747fd7fdf329  pop r9
0000747fd7fdf32b  pop r8
0000747fd7fdf32d  pop rsi
0000747fd7fdf32e  pop rdi
0000747fd7fdf32f  pop rdx
0000747fd7fdf330  pop rcx
0000747fd7fdf331  pop rax
0000747fd7fdf332  add rsp, 0x08
0000747fd7fdf336  jmp 0x0000747FD7FDC38F
0000747fd7fdf33b  sub rsp, 0x08
0000747fd7fdf33f  push rax
0000747fd7fdf340  push rcx
0000747fd7fdf341  push rdx
0000747fd7fdf342  push rdi
0000747fd7fdf343  push rsi
0000747fd7fdf344  push r8
0000747fd7fdf346  push r9
0000747fd7fdf348  push r10
0000747fd7fdf34a  push r11
0000747fd7fdf34c  sub rsp, 0xF0
0000747fd7fdf353  vmovaps [rsp], xmm0
0000747fd7fdf358  vmovaps [rsp+0x10], xmm1
0000747fd7fdf35e  vmovaps [rsp+0x20], xmm2
0000747fd7fdf364  vmovaps [rsp+0x30], xmm3
0000747fd7fdf36a  vmovaps [rsp+0x40], xmm4
0000747fd7fdf370  vmovaps [rsp+0x50], xmm6
0000747fd7fdf376  vmovaps [rsp+0x60], xmm7
0000747fd7fdf37c  vmovaps [rsp+0x70], xmm8
0000747fd7fdf382  vmovaps [rsp+0x80], xmm9
0000747fd7fdf38b  vmovaps [rsp+0x90], xmm10
0000747fd7fdf394  vmovaps [rsp+0xA0], xmm11
0000747fd7fdf39d  vmovaps [rsp+0xB0], xmm12
0000747fd7fdf3a6  vmovaps [rsp+0xC0], xmm13
0000747fd7fdf3af  vmovaps [rsp+0xD0], xmm14
0000747fd7fdf3b8  vmovaps [rsp+0xE0], xmm15
0000747fd7fdf3c1  sub rsp, 0x30
0000747fd7fdf3c5  movaps [rsp], xmm5
0000747fd7fdf3c9  movaps [rsp+0x10], xmm8
0000747fd7fdf3cf  movaps [rsp+0x20], xmm6
0000747fd7fdf3d4  lea rdi, [rsp]
0000747fd7fdf3d8  mov esi, 0x00
0000747fd7fdf3dd  mov rax, 0x6055A0B6E530
0000747fd7fdf3e7  call rax
0000747fd7fdf3e9  movaps xmm5, [rsp]
0000747fd7fdf3ed  add rsp, 0x30
0000747fd7fdf3f1  vmovaps xmm0, [rsp]
0000747fd7fdf3f6  vmovaps xmm1, [rsp+0x10]
0000747fd7fdf3fc  vmovaps xmm2, [rsp+0x20]
0000747fd7fdf402  vmovaps xmm3, [rsp+0x30]
0000747fd7fdf408  vmovaps xmm4, [rsp+0x40]
0000747fd7fdf40e  vmovaps xmm6, [rsp+0x50]
0000747fd7fdf414  vmovaps xmm7, [rsp+0x60]
0000747fd7fdf41a  vmovaps xmm8, [rsp+0x70]
0000747fd7fdf420  vmovaps xmm9, [rsp+0x80]
0000747fd7fdf429  vmovaps xmm10, [rsp+0x90]
0000747fd7fdf432  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdf43b  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdf444  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdf44d  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdf456  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdf45f  add rsp, 0xF0
0000747fd7fdf466  pop r11
0000747fd7fdf468  pop r10
0000747fd7fdf46a  pop r9
0000747fd7fdf46c  pop r8
0000747fd7fdf46e  pop rsi
0000747fd7fdf46f  pop rdi
0000747fd7fdf470  pop rdx
0000747fd7fdf471  pop rcx
0000747fd7fdf472  pop rax
0000747fd7fdf473  add rsp, 0x08
0000747fd7fdf477  jmp 0x0000747FD7FDC3B3
0000747fd7fdf47c  sub rsp, 0x08
0000747fd7fdf480  push rax
0000747fd7fdf481  push rcx
0000747fd7fdf482  push rdx
0000747fd7fdf483  push rdi
0000747fd7fdf484  push rsi
0000747fd7fdf485  push r8
0000747fd7fdf487  push r9
0000747fd7fdf489  push r10
0000747fd7fdf48b  push r11
0000747fd7fdf48d  sub rsp, 0xF0
0000747fd7fdf494  vmovaps [rsp], xmm0
0000747fd7fdf499  vmovaps [rsp+0x10], xmm1
0000747fd7fdf49f  vmovaps [rsp+0x20], xmm2
0000747fd7fdf4a5  vmovaps [rsp+0x30], xmm3
0000747fd7fdf4ab  vmovaps [rsp+0x40], xmm4
0000747fd7fdf4b1  vmovaps [rsp+0x50], xmm5
0000747fd7fdf4b7  vmovaps [rsp+0x60], xmm7
0000747fd7fdf4bd  vmovaps [rsp+0x70], xmm8
0000747fd7fdf4c3  vmovaps [rsp+0x80], xmm9
0000747fd7fdf4cc  vmovaps [rsp+0x90], xmm10
0000747fd7fdf4d5  vmovaps [rsp+0xA0], xmm11
0000747fd7fdf4de  vmovaps [rsp+0xB0], xmm12
0000747fd7fdf4e7  vmovaps [rsp+0xC0], xmm13
0000747fd7fdf4f0  vmovaps [rsp+0xD0], xmm14
0000747fd7fdf4f9  vmovaps [rsp+0xE0], xmm15
0000747fd7fdf502  sub rsp, 0x30
0000747fd7fdf506  movaps [rsp], xmm6
0000747fd7fdf50a  movaps [rsp+0x10], xmm10
0000747fd7fdf510  movaps [rsp+0x20], xmm8
0000747fd7fdf516  lea rdi, [rsp]
0000747fd7fdf51a  mov esi, 0x00
0000747fd7fdf51f  mov rax, 0x6055A0B6E530
0000747fd7fdf529  call rax
0000747fd7fdf52b  movaps xmm6, [rsp]
0000747fd7fdf52f  add rsp, 0x30
0000747fd7fdf533  vmovaps xmm0, [rsp]
0000747fd7fdf538  vmovaps xmm1, [rsp+0x10]
0000747fd7fdf53e  vmovaps xmm2, [rsp+0x20]
0000747fd7fdf544  vmovaps xmm3, [rsp+0x30]
0000747fd7fdf54a  vmovaps xmm4, [rsp+0x40]
0000747fd7fdf550  vmovaps xmm5, [rsp+0x50]
0000747fd7fdf556  vmovaps xmm7, [rsp+0x60]
0000747fd7fdf55c  vmovaps xmm8, [rsp+0x70]
0000747fd7fdf562  vmovaps xmm9, [rsp+0x80]
0000747fd7fdf56b  vmovaps xmm10, [rsp+0x90]
0000747fd7fdf574  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdf57d  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdf586  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdf58f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdf598  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdf5a1  add rsp, 0xF0
0000747fd7fdf5a8  pop r11
0000747fd7fdf5aa  pop r10
0000747fd7fdf5ac  pop r9
0000747fd7fdf5ae  pop r8
0000747fd7fdf5b0  pop rsi
0000747fd7fdf5b1  pop rdi
0000747fd7fdf5b2  pop rdx
0000747fd7fdf5b3  pop rcx
0000747fd7fdf5b4  pop rax
0000747fd7fdf5b5  add rsp, 0x08
0000747fd7fdf5b9  jmp 0x0000747FD7FDC3D8
0000747fd7fdf5be  sub rsp, 0x08
0000747fd7fdf5c2  push rax
0000747fd7fdf5c3  push rcx
0000747fd7fdf5c4  push rdx
0000747fd7fdf5c5  push rdi
0000747fd7fdf5c6  push rsi
0000747fd7fdf5c7  push r8
0000747fd7fdf5c9  push r9
0000747fd7fdf5cb  push r10
0000747fd7fdf5cd  push r11
0000747fd7fdf5cf  sub rsp, 0xF0
0000747fd7fdf5d6  vmovaps [rsp], xmm0
0000747fd7fdf5db  vmovaps [rsp+0x10], xmm1
0000747fd7fdf5e1  vmovaps [rsp+0x20], xmm2
0000747fd7fdf5e7  vmovaps [rsp+0x30], xmm3
0000747fd7fdf5ed  vmovaps [rsp+0x40], xmm4
0000747fd7fdf5f3  vmovaps [rsp+0x50], xmm5
0000747fd7fdf5f9  vmovaps [rsp+0x60], xmm6
0000747fd7fdf5ff  vmovaps [rsp+0x70], xmm7
0000747fd7fdf605  vmovaps [rsp+0x80], xmm8
0000747fd7fdf60e  vmovaps [rsp+0x90], xmm9
0000747fd7fdf617  vmovaps [rsp+0xA0], xmm11
0000747fd7fdf620  vmovaps [rsp+0xB0], xmm12
0000747fd7fdf629  vmovaps [rsp+0xC0], xmm13
0000747fd7fdf632  vmovaps [rsp+0xD0], xmm14
0000747fd7fdf63b  vmovaps [rsp+0xE0], xmm15
0000747fd7fdf644  sub rsp, 0x30
0000747fd7fdf648  movaps [rsp], xmm10
0000747fd7fdf64d  movaps [rsp+0x10], xmm8
0000747fd7fdf653  movaps [rsp+0x20], xmm14
0000747fd7fdf659  lea rdi, [rsp]
0000747fd7fdf65d  mov esi, 0x00
0000747fd7fdf662  mov rax, 0x6055A0B6E530
0000747fd7fdf66c  call rax
0000747fd7fdf66e  movaps xmm10, [rsp]
0000747fd7fdf673  add rsp, 0x30
0000747fd7fdf677  vmovaps xmm0, [rsp]
0000747fd7fdf67c  vmovaps xmm1, [rsp+0x10]
0000747fd7fdf682  vmovaps xmm2, [rsp+0x20]
0000747fd7fdf688  vmovaps xmm3, [rsp+0x30]
0000747fd7fdf68e  vmovaps xmm4, [rsp+0x40]
0000747fd7fdf694  vmovaps xmm5, [rsp+0x50]
0000747fd7fdf69a  vmovaps xmm6, [rsp+0x60]
0000747fd7fdf6a0  vmovaps xmm7, [rsp+0x70]
0000747fd7fdf6a6  vmovaps xmm8, [rsp+0x80]
0000747fd7fdf6af  vmovaps xmm9, [rsp+0x90]
0000747fd7fdf6b8  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdf6c1  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdf6ca  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdf6d3  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdf6dc  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdf6e5  add rsp, 0xF0
0000747fd7fdf6ec  pop r11
0000747fd7fdf6ee  pop r10
0000747fd7fdf6f0  pop r9
0000747fd7fdf6f2  pop r8
0000747fd7fdf6f4  pop rsi
0000747fd7fdf6f5  pop rdi
0000747fd7fdf6f6  pop rdx
0000747fd7fdf6f7  pop rcx
0000747fd7fdf6f8  pop rax
0000747fd7fdf6f9  add rsp, 0x08
0000747fd7fdf6fd  jmp 0x0000747FD7FDC3F8
0000747fd7fdf702  sub rsp, 0x08
0000747fd7fdf706  push rax
0000747fd7fdf707  push rcx
0000747fd7fdf708  push rdx
0000747fd7fdf709  push rdi
0000747fd7fdf70a  push rsi
0000747fd7fdf70b  push r8
0000747fd7fdf70d  push r9
0000747fd7fdf70f  push r10
0000747fd7fdf711  push r11
0000747fd7fdf713  sub rsp, 0xF0
0000747fd7fdf71a  vmovaps [rsp], xmm0
0000747fd7fdf71f  vmovaps [rsp+0x10], xmm1
0000747fd7fdf725  vmovaps [rsp+0x20], xmm2
0000747fd7fdf72b  vmovaps [rsp+0x30], xmm3
0000747fd7fdf731  vmovaps [rsp+0x40], xmm4
0000747fd7fdf737  vmovaps [rsp+0x50], xmm5
0000747fd7fdf73d  vmovaps [rsp+0x60], xmm6
0000747fd7fdf743  vmovaps [rsp+0x70], xmm7
0000747fd7fdf749  vmovaps [rsp+0x80], xmm8
0000747fd7fdf752  vmovaps [rsp+0x90], xmm9
0000747fd7fdf75b  vmovaps [rsp+0xA0], xmm10
0000747fd7fdf764  vmovaps [rsp+0xB0], xmm11
0000747fd7fdf76d  vmovaps [rsp+0xC0], xmm12
0000747fd7fdf776  vmovaps [rsp+0xD0], xmm13
0000747fd7fdf77f  vmovaps [rsp+0xE0], xmm15
0000747fd7fdf788  sub rsp, 0x30
0000747fd7fdf78c  movaps [rsp], xmm14
0000747fd7fdf791  movaps [rsp+0x10], xmm8
0000747fd7fdf797  movaps [rsp+0x20], xmm4
0000747fd7fdf79c  lea rdi, [rsp]
0000747fd7fdf7a0  mov esi, 0x00
0000747fd7fdf7a5  mov rax, 0x6055A0B6E530
0000747fd7fdf7af  call rax
0000747fd7fdf7b1  movaps xmm14, [rsp]
0000747fd7fdf7b6  add rsp, 0x30
0000747fd7fdf7ba  vmovaps xmm0, [rsp]
0000747fd7fdf7bf  vmovaps xmm1, [rsp+0x10]
0000747fd7fdf7c5  vmovaps xmm2, [rsp+0x20]
0000747fd7fdf7cb  vmovaps xmm3, [rsp+0x30]
0000747fd7fdf7d1  vmovaps xmm4, [rsp+0x40]
0000747fd7fdf7d7  vmovaps xmm5, [rsp+0x50]
0000747fd7fdf7dd  vmovaps xmm6, [rsp+0x60]
0000747fd7fdf7e3  vmovaps xmm7, [rsp+0x70]
0000747fd7fdf7e9  vmovaps xmm8, [rsp+0x80]
0000747fd7fdf7f2  vmovaps xmm9, [rsp+0x90]
0000747fd7fdf7fb  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdf804  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdf80d  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdf816  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdf81f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdf828  add rsp, 0xF0
0000747fd7fdf82f  pop r11
0000747fd7fdf831  pop r10
0000747fd7fdf833  pop r9
0000747fd7fdf835  pop r8
0000747fd7fdf837  pop rsi
0000747fd7fdf838  pop rdi
0000747fd7fdf839  pop rdx
0000747fd7fdf83a  pop rcx
0000747fd7fdf83b  pop rax
0000747fd7fdf83c  add rsp, 0x08
0000747fd7fdf840  jmp 0x0000747FD7FDC418
0000747fd7fdf845  sub rsp, 0x08
0000747fd7fdf849  push rax
0000747fd7fdf84a  push rcx
0000747fd7fdf84b  push rdx
0000747fd7fdf84c  push rdi
0000747fd7fdf84d  push rsi
0000747fd7fdf84e  push r8
0000747fd7fdf850  push r9
0000747fd7fdf852  push r10
0000747fd7fdf854  push r11
0000747fd7fdf856  sub rsp, 0xF0
0000747fd7fdf85d  vmovaps [rsp], xmm0
0000747fd7fdf862  vmovaps [rsp+0x10], xmm1
0000747fd7fdf868  vmovaps [rsp+0x20], xmm2
0000747fd7fdf86e  vmovaps [rsp+0x30], xmm3
0000747fd7fdf874  vmovaps [rsp+0x40], xmm5
0000747fd7fdf87a  vmovaps [rsp+0x50], xmm6
0000747fd7fdf880  vmovaps [rsp+0x60], xmm7
0000747fd7fdf886  vmovaps [rsp+0x70], xmm8
0000747fd7fdf88c  vmovaps [rsp+0x80], xmm9
0000747fd7fdf895  vmovaps [rsp+0x90], xmm10
0000747fd7fdf89e  vmovaps [rsp+0xA0], xmm11
0000747fd7fdf8a7  vmovaps [rsp+0xB0], xmm12
0000747fd7fdf8b0  vmovaps [rsp+0xC0], xmm13
0000747fd7fdf8b9  vmovaps [rsp+0xD0], xmm14
0000747fd7fdf8c2  vmovaps [rsp+0xE0], xmm15
0000747fd7fdf8cb  sub rsp, 0x30
0000747fd7fdf8cf  movaps [rsp], xmm4
0000747fd7fdf8d3  movaps [rsp+0x10], xmm13
0000747fd7fdf8d9  movaps [rsp+0x20], xmm8
0000747fd7fdf8df  lea rdi, [rsp]
0000747fd7fdf8e3  mov esi, 0x00
0000747fd7fdf8e8  mov rax, 0x6055A0B6E530
0000747fd7fdf8f2  call rax
0000747fd7fdf8f4  movaps xmm4, [rsp]
0000747fd7fdf8f8  add rsp, 0x30
0000747fd7fdf8fc  vmovaps xmm0, [rsp]
0000747fd7fdf901  vmovaps xmm1, [rsp+0x10]
0000747fd7fdf907  vmovaps xmm2, [rsp+0x20]
0000747fd7fdf90d  vmovaps xmm3, [rsp+0x30]
0000747fd7fdf913  vmovaps xmm5, [rsp+0x40]
0000747fd7fdf919  vmovaps xmm6, [rsp+0x50]
0000747fd7fdf91f  vmovaps xmm7, [rsp+0x60]
0000747fd7fdf925  vmovaps xmm8, [rsp+0x70]
0000747fd7fdf92b  vmovaps xmm9, [rsp+0x80]
0000747fd7fdf934  vmovaps xmm10, [rsp+0x90]
0000747fd7fdf93d  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdf946  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdf94f  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdf958  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdf961  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdf96a  add rsp, 0xF0
0000747fd7fdf971  pop r11
0000747fd7fdf973  pop r10
0000747fd7fdf975  pop r9
0000747fd7fdf977  pop r8
0000747fd7fdf979  pop rsi
0000747fd7fdf97a  pop rdi
0000747fd7fdf97b  pop rdx
0000747fd7fdf97c  pop rcx
0000747fd7fdf97d  pop rax
0000747fd7fdf97e  add rsp, 0x08
0000747fd7fdf982  jmp 0x0000747FD7FDC43D
0000747fd7fdf987  sub rsp, 0x08
0000747fd7fdf98b  push rax
0000747fd7fdf98c  push rcx
0000747fd7fdf98d  push rdx
0000747fd7fdf98e  push rdi
0000747fd7fdf98f  push rsi
0000747fd7fdf990  push r8
0000747fd7fdf992  push r9
0000747fd7fdf994  push r10
0000747fd7fdf996  push r11
0000747fd7fdf998  sub rsp, 0xF0
0000747fd7fdf99f  vmovaps [rsp], xmm0
0000747fd7fdf9a4  vmovaps [rsp+0x10], xmm1
0000747fd7fdf9aa  vmovaps [rsp+0x20], xmm2
0000747fd7fdf9b0  vmovaps [rsp+0x30], xmm3
0000747fd7fdf9b6  vmovaps [rsp+0x40], xmm4
0000747fd7fdf9bc  vmovaps [rsp+0x50], xmm5
0000747fd7fdf9c2  vmovaps [rsp+0x60], xmm6
0000747fd7fdf9c8  vmovaps [rsp+0x70], xmm7
0000747fd7fdf9ce  vmovaps [rsp+0x80], xmm8
0000747fd7fdf9d7  vmovaps [rsp+0x90], xmm9
0000747fd7fdf9e0  vmovaps [rsp+0xA0], xmm10
0000747fd7fdf9e9  vmovaps [rsp+0xB0], xmm11
0000747fd7fdf9f2  vmovaps [rsp+0xC0], xmm12
0000747fd7fdf9fb  vmovaps [rsp+0xD0], xmm14
0000747fd7fdfa04  vmovaps [rsp+0xE0], xmm15
0000747fd7fdfa0d  sub rsp, 0x30
0000747fd7fdfa11  movaps [rsp], xmm13
0000747fd7fdfa16  movaps [rsp+0x10], xmm15
0000747fd7fdfa1c  movaps [rsp+0x20], xmm9
0000747fd7fdfa22  lea rdi, [rsp]
0000747fd7fdfa26  mov esi, 0x00
0000747fd7fdfa2b  mov rax, 0x6055A0B6E530
0000747fd7fdfa35  call rax
0000747fd7fdfa37  movaps xmm13, [rsp]
0000747fd7fdfa3c  add rsp, 0x30
0000747fd7fdfa40  vmovaps xmm0, [rsp]
0000747fd7fdfa45  vmovaps xmm1, [rsp+0x10]
0000747fd7fdfa4b  vmovaps xmm2, [rsp+0x20]
0000747fd7fdfa51  vmovaps xmm3, [rsp+0x30]
0000747fd7fdfa57  vmovaps xmm4, [rsp+0x40]
0000747fd7fdfa5d  vmovaps xmm5, [rsp+0x50]
0000747fd7fdfa63  vmovaps xmm6, [rsp+0x60]
0000747fd7fdfa69  vmovaps xmm7, [rsp+0x70]
0000747fd7fdfa6f  vmovaps xmm8, [rsp+0x80]
0000747fd7fdfa78  vmovaps xmm9, [rsp+0x90]
0000747fd7fdfa81  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdfa8a  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdfa93  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdfa9c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdfaa5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdfaae  add rsp, 0xF0
0000747fd7fdfab5  pop r11
0000747fd7fdfab7  pop r10
0000747fd7fdfab9  pop r9
0000747fd7fdfabb  pop r8
0000747fd7fdfabd  pop rsi
0000747fd7fdfabe  pop rdi
0000747fd7fdfabf  pop rdx
0000747fd7fdfac0  pop rcx
0000747fd7fdfac1  pop rax
0000747fd7fdfac2  add rsp, 0x08
0000747fd7fdfac6  jmp 0x0000747FD7FDC458
0000747fd7fdfacb  sub rsp, 0x08
0000747fd7fdfacf  push rax
0000747fd7fdfad0  push rcx
0000747fd7fdfad1  push rdx
0000747fd7fdfad2  push rdi
0000747fd7fdfad3  push rsi
0000747fd7fdfad4  push r8
0000747fd7fdfad6  push r9
0000747fd7fdfad8  push r10
0000747fd7fdfada  push r11
0000747fd7fdfadc  sub rsp, 0xF0
0000747fd7fdfae3  vmovaps [rsp], xmm0
0000747fd7fdfae8  vmovaps [rsp+0x10], xmm1
0000747fd7fdfaee  vmovaps [rsp+0x20], xmm2
0000747fd7fdfaf4  vmovaps [rsp+0x30], xmm3
0000747fd7fdfafa  vmovaps [rsp+0x40], xmm4
0000747fd7fdfb00  vmovaps [rsp+0x50], xmm5
0000747fd7fdfb06  vmovaps [rsp+0x60], xmm6
0000747fd7fdfb0c  vmovaps [rsp+0x70], xmm7
0000747fd7fdfb12  vmovaps [rsp+0x80], xmm8
0000747fd7fdfb1b  vmovaps [rsp+0x90], xmm9
0000747fd7fdfb24  vmovaps [rsp+0xA0], xmm10
0000747fd7fdfb2d  vmovaps [rsp+0xB0], xmm11
0000747fd7fdfb36  vmovaps [rsp+0xC0], xmm12
0000747fd7fdfb3f  vmovaps [rsp+0xD0], xmm13
0000747fd7fdfb48  vmovaps [rsp+0xE0], xmm14
0000747fd7fdfb51  sub rsp, 0x30
0000747fd7fdfb55  movaps [rsp], xmm15
0000747fd7fdfb5a  movaps [rsp+0x10], xmm1
0000747fd7fdfb5f  movaps [rsp+0x20], xmm5
0000747fd7fdfb64  lea rdi, [rsp]
0000747fd7fdfb68  mov esi, 0x00
0000747fd7fdfb6d  mov rax, 0x6055A0B6E530
0000747fd7fdfb77  call rax
0000747fd7fdfb79  movaps xmm15, [rsp]
0000747fd7fdfb7e  add rsp, 0x30
0000747fd7fdfb82  vmovaps xmm0, [rsp]
0000747fd7fdfb87  vmovaps xmm1, [rsp+0x10]
0000747fd7fdfb8d  vmovaps xmm2, [rsp+0x20]
0000747fd7fdfb93  vmovaps xmm3, [rsp+0x30]
0000747fd7fdfb99  vmovaps xmm4, [rsp+0x40]
0000747fd7fdfb9f  vmovaps xmm5, [rsp+0x50]
0000747fd7fdfba5  vmovaps xmm6, [rsp+0x60]
0000747fd7fdfbab  vmovaps xmm7, [rsp+0x70]
0000747fd7fdfbb1  vmovaps xmm8, [rsp+0x80]
0000747fd7fdfbba  vmovaps xmm9, [rsp+0x90]
0000747fd7fdfbc3  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdfbcc  vmovaps xmm11, [rsp+0xB0]
0000747fd7fdfbd5  vmovaps xmm12, [rsp+0xC0]
0000747fd7fdfbde  vmovaps xmm13, [rsp+0xD0]
0000747fd7fdfbe7  vmovaps xmm14, [rsp+0xE0]
0000747fd7fdfbf0  add rsp, 0xF0
0000747fd7fdfbf7  pop r11
0000747fd7fdfbf9  pop r10
0000747fd7fdfbfb  pop r9
0000747fd7fdfbfd  pop r8
0000747fd7fdfbff  pop rsi
0000747fd7fdfc00  pop rdi
0000747fd7fdfc01  pop rdx
0000747fd7fdfc02  pop rcx
0000747fd7fdfc03  pop rax
0000747fd7fdfc04  add rsp, 0x08
0000747fd7fdfc08  jmp 0x0000747FD7FDC473
0000747fd7fdfc0d  call 0x0000747FD7EB52F0
0000747fd7fdfc12  jmp 0x0000747FD7FDC4CE
0000747fd7fdfc17  sub rsp, 0x08
0000747fd7fdfc1b  push rax
0000747fd7fdfc1c  push rcx
0000747fd7fdfc1d  push rdx
0000747fd7fdfc1e  push rdi
0000747fd7fdfc1f  push rsi
0000747fd7fdfc20  push r8
0000747fd7fdfc22  push r9
0000747fd7fdfc24  push r10
0000747fd7fdfc26  push r11
0000747fd7fdfc28  sub rsp, 0xF0
0000747fd7fdfc2f  vmovaps [rsp], xmm0
0000747fd7fdfc34  vmovaps [rsp+0x10], xmm1
0000747fd7fdfc3a  vmovaps [rsp+0x20], xmm2
0000747fd7fdfc40  vmovaps [rsp+0x30], xmm3
0000747fd7fdfc46  vmovaps [rsp+0x40], xmm4
0000747fd7fdfc4c  vmovaps [rsp+0x50], xmm5
0000747fd7fdfc52  vmovaps [rsp+0x60], xmm6
0000747fd7fdfc58  vmovaps [rsp+0x70], xmm7
0000747fd7fdfc5e  vmovaps [rsp+0x80], xmm8
0000747fd7fdfc67  vmovaps [rsp+0x90], xmm10
0000747fd7fdfc70  vmovaps [rsp+0xA0], xmm11
0000747fd7fdfc79  vmovaps [rsp+0xB0], xmm12
0000747fd7fdfc82  vmovaps [rsp+0xC0], xmm13
0000747fd7fdfc8b  vmovaps [rsp+0xD0], xmm14
0000747fd7fdfc94  vmovaps [rsp+0xE0], xmm15
0000747fd7fdfc9d  sub rsp, 0x30
0000747fd7fdfca1  movaps [rsp], xmm9
0000747fd7fdfca6  movaps [rsp+0x10], xmm8
0000747fd7fdfcac  movaps [rsp+0x20], xmm11
0000747fd7fdfcb2  lea rdi, [rsp]
0000747fd7fdfcb6  mov esi, 0x00
0000747fd7fdfcbb  mov rax, 0x6055A0B6E530
0000747fd7fdfcc5  call rax
0000747fd7fdfcc7  movaps xmm9, [rsp]
0000747fd7fdfccc  add rsp, 0x30
0000747fd7fdfcd0  vmovaps xmm0, [rsp]
0000747fd7fdfcd5  vmovaps xmm1, [rsp+0x10]
0000747fd7fdfcdb  vmovaps xmm2, [rsp+0x20]
0000747fd7fdfce1  vmovaps xmm3, [rsp+0x30]
0000747fd7fdfce7  vmovaps xmm4, [rsp+0x40]
0000747fd7fdfced  vmovaps xmm5, [rsp+0x50]
0000747fd7fdfcf3  vmovaps xmm6, [rsp+0x60]
0000747fd7fdfcf9  vmovaps xmm7, [rsp+0x70]
0000747fd7fdfcff  vmovaps xmm8, [rsp+0x80]
0000747fd7fdfd08  vmovaps xmm10, [rsp+0x90]
0000747fd7fdfd11  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdfd1a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdfd23  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdfd2c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdfd35  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdfd3e  add rsp, 0xF0
0000747fd7fdfd45  pop r11
0000747fd7fdfd47  pop r10
0000747fd7fdfd49  pop r9
0000747fd7fdfd4b  pop r8
0000747fd7fdfd4d  pop rsi
0000747fd7fdfd4e  pop rdi
0000747fd7fdfd4f  pop rdx
0000747fd7fdfd50  pop rcx
0000747fd7fdfd51  pop rax
0000747fd7fdfd52  add rsp, 0x08
0000747fd7fdfd56  jmp 0x0000747FD7FDC505
0000747fd7fdfd5b  sub rsp, 0x08
0000747fd7fdfd5f  push rax
0000747fd7fdfd60  push rcx
0000747fd7fdfd61  push rdx
0000747fd7fdfd62  push rdi
0000747fd7fdfd63  push rsi
0000747fd7fdfd64  push r8
0000747fd7fdfd66  push r9
0000747fd7fdfd68  push r10
0000747fd7fdfd6a  push r11
0000747fd7fdfd6c  sub rsp, 0xF0
0000747fd7fdfd73  vmovaps [rsp], xmm0
0000747fd7fdfd78  vmovaps [rsp+0x10], xmm1
0000747fd7fdfd7e  vmovaps [rsp+0x20], xmm2
0000747fd7fdfd84  vmovaps [rsp+0x30], xmm3
0000747fd7fdfd8a  vmovaps [rsp+0x40], xmm4
0000747fd7fdfd90  vmovaps [rsp+0x50], xmm5
0000747fd7fdfd96  vmovaps [rsp+0x60], xmm6
0000747fd7fdfd9c  vmovaps [rsp+0x70], xmm7
0000747fd7fdfda2  vmovaps [rsp+0x80], xmm8
0000747fd7fdfdab  vmovaps [rsp+0x90], xmm9
0000747fd7fdfdb4  vmovaps [rsp+0xA0], xmm10
0000747fd7fdfdbd  vmovaps [rsp+0xB0], xmm12
0000747fd7fdfdc6  vmovaps [rsp+0xC0], xmm13
0000747fd7fdfdcf  vmovaps [rsp+0xD0], xmm14
0000747fd7fdfdd8  vmovaps [rsp+0xE0], xmm15
0000747fd7fdfde1  sub rsp, 0x30
0000747fd7fdfde5  movaps [rsp], xmm11
0000747fd7fdfdea  movaps [rsp+0x10], xmm10
0000747fd7fdfdf0  movaps [rsp+0x20], xmm6
0000747fd7fdfdf5  lea rdi, [rsp]
0000747fd7fdfdf9  mov esi, 0x00
0000747fd7fdfdfe  mov rax, 0x6055A0B6E530
0000747fd7fdfe08  call rax
0000747fd7fdfe0a  movaps xmm11, [rsp]
0000747fd7fdfe0f  add rsp, 0x30
0000747fd7fdfe13  vmovaps xmm0, [rsp]
0000747fd7fdfe18  vmovaps xmm1, [rsp+0x10]
0000747fd7fdfe1e  vmovaps xmm2, [rsp+0x20]
0000747fd7fdfe24  vmovaps xmm3, [rsp+0x30]
0000747fd7fdfe2a  vmovaps xmm4, [rsp+0x40]
0000747fd7fdfe30  vmovaps xmm5, [rsp+0x50]
0000747fd7fdfe36  vmovaps xmm6, [rsp+0x60]
0000747fd7fdfe3c  vmovaps xmm7, [rsp+0x70]
0000747fd7fdfe42  vmovaps xmm8, [rsp+0x80]
0000747fd7fdfe4b  vmovaps xmm9, [rsp+0x90]
0000747fd7fdfe54  vmovaps xmm10, [rsp+0xA0]
0000747fd7fdfe5d  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdfe66  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdfe6f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdfe78  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdfe81  add rsp, 0xF0
0000747fd7fdfe88  pop r11
0000747fd7fdfe8a  pop r10
0000747fd7fdfe8c  pop r9
0000747fd7fdfe8e  pop r8
0000747fd7fdfe90  pop rsi
0000747fd7fdfe91  pop rdi
0000747fd7fdfe92  pop rdx
0000747fd7fdfe93  pop rcx
0000747fd7fdfe94  pop rax
0000747fd7fdfe95  add rsp, 0x08
0000747fd7fdfe99  jmp 0x0000747FD7FDC520
0000747fd7fdfe9e  sub rsp, 0x08
0000747fd7fdfea2  push rax
0000747fd7fdfea3  push rcx
0000747fd7fdfea4  push rdx
0000747fd7fdfea5  push rdi
0000747fd7fdfea6  push rsi
0000747fd7fdfea7  push r8
0000747fd7fdfea9  push r9
0000747fd7fdfeab  push r10
0000747fd7fdfead  push r11
0000747fd7fdfeaf  sub rsp, 0xF0
0000747fd7fdfeb6  vmovaps [rsp], xmm0
0000747fd7fdfebb  vmovaps [rsp+0x10], xmm1
0000747fd7fdfec1  vmovaps [rsp+0x20], xmm2
0000747fd7fdfec7  vmovaps [rsp+0x30], xmm3
0000747fd7fdfecd  vmovaps [rsp+0x40], xmm4
0000747fd7fdfed3  vmovaps [rsp+0x50], xmm5
0000747fd7fdfed9  vmovaps [rsp+0x60], xmm6
0000747fd7fdfedf  vmovaps [rsp+0x70], xmm7
0000747fd7fdfee5  vmovaps [rsp+0x80], xmm8
0000747fd7fdfeee  vmovaps [rsp+0x90], xmm9
0000747fd7fdfef7  vmovaps [rsp+0xA0], xmm11
0000747fd7fdff00  vmovaps [rsp+0xB0], xmm12
0000747fd7fdff09  vmovaps [rsp+0xC0], xmm13
0000747fd7fdff12  vmovaps [rsp+0xD0], xmm14
0000747fd7fdff1b  vmovaps [rsp+0xE0], xmm15
0000747fd7fdff24  sub rsp, 0x30
0000747fd7fdff28  movaps [rsp], xmm10
0000747fd7fdff2d  movaps [rsp+0x10], xmm14
0000747fd7fdff33  movaps [rsp+0x20], xmm4
0000747fd7fdff38  lea rdi, [rsp]
0000747fd7fdff3c  mov esi, 0x00
0000747fd7fdff41  mov rax, 0x6055A0B6E530
0000747fd7fdff4b  call rax
0000747fd7fdff4d  movaps xmm10, [rsp]
0000747fd7fdff52  add rsp, 0x30
0000747fd7fdff56  vmovaps xmm0, [rsp]
0000747fd7fdff5b  vmovaps xmm1, [rsp+0x10]
0000747fd7fdff61  vmovaps xmm2, [rsp+0x20]
0000747fd7fdff67  vmovaps xmm3, [rsp+0x30]
0000747fd7fdff6d  vmovaps xmm4, [rsp+0x40]
0000747fd7fdff73  vmovaps xmm5, [rsp+0x50]
0000747fd7fdff79  vmovaps xmm6, [rsp+0x60]
0000747fd7fdff7f  vmovaps xmm7, [rsp+0x70]
0000747fd7fdff85  vmovaps xmm8, [rsp+0x80]
0000747fd7fdff8e  vmovaps xmm9, [rsp+0x90]
0000747fd7fdff97  vmovaps xmm11, [rsp+0xA0]
0000747fd7fdffa0  vmovaps xmm12, [rsp+0xB0]
0000747fd7fdffa9  vmovaps xmm13, [rsp+0xC0]
0000747fd7fdffb2  vmovaps xmm14, [rsp+0xD0]
0000747fd7fdffbb  vmovaps xmm15, [rsp+0xE0]
0000747fd7fdffc4  add rsp, 0xF0
0000747fd7fdffcb  pop r11
0000747fd7fdffcd  pop r10
0000747fd7fdffcf  pop r9
0000747fd7fdffd1  pop r8
0000747fd7fdffd3  pop rsi
0000747fd7fdffd4  pop rdi
0000747fd7fdffd5  pop rdx
0000747fd7fdffd6  pop rcx
0000747fd7fdffd7  pop rax
0000747fd7fdffd8  add rsp, 0x08
0000747fd7fdffdc  jmp 0x0000747FD7FDC53B
0000747fd7fdffe1  sub rsp, 0x08
0000747fd7fdffe5  push rax
0000747fd7fdffe6  push rcx
0000747fd7fdffe7  push rdx
0000747fd7fdffe8  push rdi
0000747fd7fdffe9  push rsi
0000747fd7fdffea  push r8
0000747fd7fdffec  push r9
0000747fd7fdffee  push r10
0000747fd7fdfff0  push r11
0000747fd7fdfff2  sub rsp, 0xF0
0000747fd7fdfff9  vmovaps [rsp], xmm0
0000747fd7fdfffe  vmovaps [rsp+0x10], xmm1
0000747fd7fe0004  vmovaps [rsp+0x20], xmm2
0000747fd7fe000a  vmovaps [rsp+0x30], xmm3
0000747fd7fe0010  vmovaps [rsp+0x40], xmm4
0000747fd7fe0016  vmovaps [rsp+0x50], xmm5
0000747fd7fe001c  vmovaps [rsp+0x60], xmm6
0000747fd7fe0022  vmovaps [rsp+0x70], xmm7
0000747fd7fe0028  vmovaps [rsp+0x80], xmm9
0000747fd7fe0031  vmovaps [rsp+0x90], xmm10
0000747fd7fe003a  vmovaps [rsp+0xA0], xmm11
0000747fd7fe0043  vmovaps [rsp+0xB0], xmm12
0000747fd7fe004c  vmovaps [rsp+0xC0], xmm13
0000747fd7fe0055  vmovaps [rsp+0xD0], xmm14
0000747fd7fe005e  vmovaps [rsp+0xE0], xmm15
0000747fd7fe0067  sub rsp, 0x30
0000747fd7fe006b  movaps [rsp], xmm8
0000747fd7fe0070  movaps [rsp+0x10], xmm1
0000747fd7fe0075  movaps [rsp+0x20], xmm14
0000747fd7fe007b  lea rdi, [rsp]
0000747fd7fe007f  mov esi, 0x00
0000747fd7fe0084  mov rax, 0x6055A0B6E530
0000747fd7fe008e  call rax
0000747fd7fe0090  movaps xmm8, [rsp]
0000747fd7fe0095  add rsp, 0x30
0000747fd7fe0099  vmovaps xmm0, [rsp]
0000747fd7fe009e  vmovaps xmm1, [rsp+0x10]
0000747fd7fe00a4  vmovaps xmm2, [rsp+0x20]
0000747fd7fe00aa  vmovaps xmm3, [rsp+0x30]
0000747fd7fe00b0  vmovaps xmm4, [rsp+0x40]
0000747fd7fe00b6  vmovaps xmm5, [rsp+0x50]
0000747fd7fe00bc  vmovaps xmm6, [rsp+0x60]
0000747fd7fe00c2  vmovaps xmm7, [rsp+0x70]
0000747fd7fe00c8  vmovaps xmm9, [rsp+0x80]
0000747fd7fe00d1  vmovaps xmm10, [rsp+0x90]
0000747fd7fe00da  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe00e3  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe00ec  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe00f5  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe00fe  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0107  add rsp, 0xF0
0000747fd7fe010e  pop r11
0000747fd7fe0110  pop r10
0000747fd7fe0112  pop r9
0000747fd7fe0114  pop r8
0000747fd7fe0116  pop rsi
0000747fd7fe0117  pop rdi
0000747fd7fe0118  pop rdx
0000747fd7fe0119  pop rcx
0000747fd7fe011a  pop rax
0000747fd7fe011b  add rsp, 0x08
0000747fd7fe011f  jmp 0x0000747FD7FDC561
0000747fd7fe0124  sub rsp, 0x08
0000747fd7fe0128  push rax
0000747fd7fe0129  push rcx
0000747fd7fe012a  push rdx
0000747fd7fe012b  push rdi
0000747fd7fe012c  push rsi
0000747fd7fe012d  push r8
0000747fd7fe012f  push r9
0000747fd7fe0131  push r10
0000747fd7fe0133  push r11
0000747fd7fe0135  sub rsp, 0xF0
0000747fd7fe013c  vmovaps [rsp], xmm0
0000747fd7fe0141  vmovaps [rsp+0x10], xmm1
0000747fd7fe0147  vmovaps [rsp+0x20], xmm2
0000747fd7fe014d  vmovaps [rsp+0x30], xmm3
0000747fd7fe0153  vmovaps [rsp+0x40], xmm4
0000747fd7fe0159  vmovaps [rsp+0x50], xmm5
0000747fd7fe015f  vmovaps [rsp+0x60], xmm7
0000747fd7fe0165  vmovaps [rsp+0x70], xmm8
0000747fd7fe016b  vmovaps [rsp+0x80], xmm9
0000747fd7fe0174  vmovaps [rsp+0x90], xmm10
0000747fd7fe017d  vmovaps [rsp+0xA0], xmm11
0000747fd7fe0186  vmovaps [rsp+0xB0], xmm12
0000747fd7fe018f  vmovaps [rsp+0xC0], xmm13
0000747fd7fe0198  vmovaps [rsp+0xD0], xmm14
0000747fd7fe01a1  vmovaps [rsp+0xE0], xmm15
0000747fd7fe01aa  sub rsp, 0x30
0000747fd7fe01ae  movaps [rsp], xmm6
0000747fd7fe01b2  movaps [rsp+0x10], xmm1
0000747fd7fe01b7  movaps [rsp+0x20], xmm14
0000747fd7fe01bd  lea rdi, [rsp]
0000747fd7fe01c1  mov esi, 0x00
0000747fd7fe01c6  mov rax, 0x6055A0B6E530
0000747fd7fe01d0  call rax
0000747fd7fe01d2  movaps xmm6, [rsp]
0000747fd7fe01d6  add rsp, 0x30
0000747fd7fe01da  vmovaps xmm0, [rsp]
0000747fd7fe01df  vmovaps xmm1, [rsp+0x10]
0000747fd7fe01e5  vmovaps xmm2, [rsp+0x20]
0000747fd7fe01eb  vmovaps xmm3, [rsp+0x30]
0000747fd7fe01f1  vmovaps xmm4, [rsp+0x40]
0000747fd7fe01f7  vmovaps xmm5, [rsp+0x50]
0000747fd7fe01fd  vmovaps xmm7, [rsp+0x60]
0000747fd7fe0203  vmovaps xmm8, [rsp+0x70]
0000747fd7fe0209  vmovaps xmm9, [rsp+0x80]
0000747fd7fe0212  vmovaps xmm10, [rsp+0x90]
0000747fd7fe021b  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe0224  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe022d  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe0236  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe023f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0248  add rsp, 0xF0
0000747fd7fe024f  pop r11
0000747fd7fe0251  pop r10
0000747fd7fe0253  pop r9
0000747fd7fe0255  pop r8
0000747fd7fe0257  pop rsi
0000747fd7fe0258  pop rdi
0000747fd7fe0259  pop rdx
0000747fd7fe025a  pop rcx
0000747fd7fe025b  pop rax
0000747fd7fe025c  add rsp, 0x08
0000747fd7fe0260  jmp 0x0000747FD7FDC58D
0000747fd7fe0265  sub rsp, 0x08
0000747fd7fe0269  push rax
0000747fd7fe026a  push rcx
0000747fd7fe026b  push rdx
0000747fd7fe026c  push rdi
0000747fd7fe026d  push rsi
0000747fd7fe026e  push r8
0000747fd7fe0270  push r9
0000747fd7fe0272  push r10
0000747fd7fe0274  push r11
0000747fd7fe0276  sub rsp, 0xF0
0000747fd7fe027d  vmovaps [rsp], xmm0
0000747fd7fe0282  vmovaps [rsp+0x10], xmm1
0000747fd7fe0288  vmovaps [rsp+0x20], xmm2
0000747fd7fe028e  vmovaps [rsp+0x30], xmm3
0000747fd7fe0294  vmovaps [rsp+0x40], xmm4
0000747fd7fe029a  vmovaps [rsp+0x50], xmm5
0000747fd7fe02a0  vmovaps [rsp+0x60], xmm6
0000747fd7fe02a6  vmovaps [rsp+0x70], xmm7
0000747fd7fe02ac  vmovaps [rsp+0x80], xmm8
0000747fd7fe02b5  vmovaps [rsp+0x90], xmm9
0000747fd7fe02be  vmovaps [rsp+0xA0], xmm10
0000747fd7fe02c7  vmovaps [rsp+0xB0], xmm11
0000747fd7fe02d0  vmovaps [rsp+0xC0], xmm12
0000747fd7fe02d9  vmovaps [rsp+0xD0], xmm13
0000747fd7fe02e2  vmovaps [rsp+0xE0], xmm15
0000747fd7fe02eb  sub rsp, 0x30
0000747fd7fe02ef  movaps [rsp], xmm14
0000747fd7fe02f4  movaps [rsp+0x10], xmm12
0000747fd7fe02fa  movaps [rsp+0x20], xmm1
0000747fd7fe02ff  lea rdi, [rsp]
0000747fd7fe0303  mov esi, 0x00
0000747fd7fe0308  mov rax, 0x6055A0B6E530
0000747fd7fe0312  call rax
0000747fd7fe0314  movaps xmm14, [rsp]
0000747fd7fe0319  add rsp, 0x30
0000747fd7fe031d  vmovaps xmm0, [rsp]
0000747fd7fe0322  vmovaps xmm1, [rsp+0x10]
0000747fd7fe0328  vmovaps xmm2, [rsp+0x20]
0000747fd7fe032e  vmovaps xmm3, [rsp+0x30]
0000747fd7fe0334  vmovaps xmm4, [rsp+0x40]
0000747fd7fe033a  vmovaps xmm5, [rsp+0x50]
0000747fd7fe0340  vmovaps xmm6, [rsp+0x60]
0000747fd7fe0346  vmovaps xmm7, [rsp+0x70]
0000747fd7fe034c  vmovaps xmm8, [rsp+0x80]
0000747fd7fe0355  vmovaps xmm9, [rsp+0x90]
0000747fd7fe035e  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe0367  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe0370  vmovaps xmm12, [rsp+0xC0]
0000747fd7fe0379  vmovaps xmm13, [rsp+0xD0]
0000747fd7fe0382  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe038b  add rsp, 0xF0
0000747fd7fe0392  pop r11
0000747fd7fe0394  pop r10
0000747fd7fe0396  pop r9
0000747fd7fe0398  pop r8
0000747fd7fe039a  pop rsi
0000747fd7fe039b  pop rdi
0000747fd7fe039c  pop rdx
0000747fd7fe039d  pop rcx
0000747fd7fe039e  pop rax
0000747fd7fe039f  add rsp, 0x08
0000747fd7fe03a3  jmp 0x0000747FD7FDC5B3
0000747fd7fe03a8  sub rsp, 0x08
0000747fd7fe03ac  push rax
0000747fd7fe03ad  push rcx
0000747fd7fe03ae  push rdx
0000747fd7fe03af  push rdi
0000747fd7fe03b0  push rsi
0000747fd7fe03b1  push r8
0000747fd7fe03b3  push r9
0000747fd7fe03b5  push r10
0000747fd7fe03b7  push r11
0000747fd7fe03b9  sub rsp, 0xF0
0000747fd7fe03c0  vmovaps [rsp], xmm0
0000747fd7fe03c5  vmovaps [rsp+0x10], xmm2
0000747fd7fe03cb  vmovaps [rsp+0x20], xmm3
0000747fd7fe03d1  vmovaps [rsp+0x30], xmm4
0000747fd7fe03d7  vmovaps [rsp+0x40], xmm5
0000747fd7fe03dd  vmovaps [rsp+0x50], xmm6
0000747fd7fe03e3  vmovaps [rsp+0x60], xmm7
0000747fd7fe03e9  vmovaps [rsp+0x70], xmm8
0000747fd7fe03ef  vmovaps [rsp+0x80], xmm9
0000747fd7fe03f8  vmovaps [rsp+0x90], xmm10
0000747fd7fe0401  vmovaps [rsp+0xA0], xmm11
0000747fd7fe040a  vmovaps [rsp+0xB0], xmm12
0000747fd7fe0413  vmovaps [rsp+0xC0], xmm13
0000747fd7fe041c  vmovaps [rsp+0xD0], xmm14
0000747fd7fe0425  vmovaps [rsp+0xE0], xmm15
0000747fd7fe042e  sub rsp, 0x30
0000747fd7fe0432  movaps [rsp], xmm1
0000747fd7fe0436  movaps [rsp+0x10], xmm13
0000747fd7fe043c  movaps [rsp+0x20], xmm9
0000747fd7fe0442  lea rdi, [rsp]
0000747fd7fe0446  mov esi, 0x00
0000747fd7fe044b  mov rax, 0x6055A0B6E530
0000747fd7fe0455  call rax
0000747fd7fe0457  movaps xmm1, [rsp]
0000747fd7fe045b  add rsp, 0x30
0000747fd7fe045f  vmovaps xmm0, [rsp]
0000747fd7fe0464  vmovaps xmm2, [rsp+0x10]
0000747fd7fe046a  vmovaps xmm3, [rsp+0x20]
0000747fd7fe0470  vmovaps xmm4, [rsp+0x30]
0000747fd7fe0476  vmovaps xmm5, [rsp+0x40]
0000747fd7fe047c  vmovaps xmm6, [rsp+0x50]
0000747fd7fe0482  vmovaps xmm7, [rsp+0x60]
0000747fd7fe0488  vmovaps xmm8, [rsp+0x70]
0000747fd7fe048e  vmovaps xmm9, [rsp+0x80]
0000747fd7fe0497  vmovaps xmm10, [rsp+0x90]
0000747fd7fe04a0  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe04a9  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe04b2  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe04bb  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe04c4  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe04cd  add rsp, 0xF0
0000747fd7fe04d4  pop r11
0000747fd7fe04d6  pop r10
0000747fd7fe04d8  pop r9
0000747fd7fe04da  pop r8
0000747fd7fe04dc  pop rsi
0000747fd7fe04dd  pop rdi
0000747fd7fe04de  pop rdx
0000747fd7fe04df  pop rcx
0000747fd7fe04e0  pop rax
0000747fd7fe04e1  add rsp, 0x08
0000747fd7fe04e5  jmp 0x0000747FD7FDC5CD
0000747fd7fe04ea  sub rsp, 0x08
0000747fd7fe04ee  push rax
0000747fd7fe04ef  push rcx
0000747fd7fe04f0  push rdx
0000747fd7fe04f1  push rdi
0000747fd7fe04f2  push rsi
0000747fd7fe04f3  push r8
0000747fd7fe04f5  push r9
0000747fd7fe04f7  push r10
0000747fd7fe04f9  push r11
0000747fd7fe04fb  sub rsp, 0xF0
0000747fd7fe0502  vmovaps [rsp], xmm0
0000747fd7fe0507  vmovaps [rsp+0x10], xmm1
0000747fd7fe050d  vmovaps [rsp+0x20], xmm2
0000747fd7fe0513  vmovaps [rsp+0x30], xmm3
0000747fd7fe0519  vmovaps [rsp+0x40], xmm4
0000747fd7fe051f  vmovaps [rsp+0x50], xmm5
0000747fd7fe0525  vmovaps [rsp+0x60], xmm6
0000747fd7fe052b  vmovaps [rsp+0x70], xmm7
0000747fd7fe0531  vmovaps [rsp+0x80], xmm8
0000747fd7fe053a  vmovaps [rsp+0x90], xmm9
0000747fd7fe0543  vmovaps [rsp+0xA0], xmm10
0000747fd7fe054c  vmovaps [rsp+0xB0], xmm11
0000747fd7fe0555  vmovaps [rsp+0xC0], xmm13
0000747fd7fe055e  vmovaps [rsp+0xD0], xmm14
0000747fd7fe0567  vmovaps [rsp+0xE0], xmm15
0000747fd7fe0570  sub rsp, 0x30
0000747fd7fe0574  movaps [rsp], xmm12
0000747fd7fe0579  movaps [rsp+0x10], xmm7
0000747fd7fe057e  movaps [rsp+0x20], xmm13
0000747fd7fe0584  lea rdi, [rsp]
0000747fd7fe0588  mov esi, 0x00
0000747fd7fe058d  mov rax, 0x6055A0B6E530
0000747fd7fe0597  call rax
0000747fd7fe0599  movaps xmm12, [rsp]
0000747fd7fe059e  add rsp, 0x30
0000747fd7fe05a2  vmovaps xmm0, [rsp]
0000747fd7fe05a7  vmovaps xmm1, [rsp+0x10]
0000747fd7fe05ad  vmovaps xmm2, [rsp+0x20]
0000747fd7fe05b3  vmovaps xmm3, [rsp+0x30]
0000747fd7fe05b9  vmovaps xmm4, [rsp+0x40]
0000747fd7fe05bf  vmovaps xmm5, [rsp+0x50]
0000747fd7fe05c5  vmovaps xmm6, [rsp+0x60]
0000747fd7fe05cb  vmovaps xmm7, [rsp+0x70]
0000747fd7fe05d1  vmovaps xmm8, [rsp+0x80]
0000747fd7fe05da  vmovaps xmm9, [rsp+0x90]
0000747fd7fe05e3  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe05ec  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe05f5  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe05fe  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe0607  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0610  add rsp, 0xF0
0000747fd7fe0617  pop r11
0000747fd7fe0619  pop r10
0000747fd7fe061b  pop r9
0000747fd7fe061d  pop r8
0000747fd7fe061f  pop rsi
0000747fd7fe0620  pop rdi
0000747fd7fe0621  pop rdx
0000747fd7fe0622  pop rcx
0000747fd7fe0623  pop rax
0000747fd7fe0624  add rsp, 0x08
0000747fd7fe0628  jmp 0x0000747FD7FDC5F4
0000747fd7fe062d  sub rsp, 0x08
0000747fd7fe0631  push rax
0000747fd7fe0632  push rcx
0000747fd7fe0633  push rdx
0000747fd7fe0634  push rdi
0000747fd7fe0635  push rsi
0000747fd7fe0636  push r8
0000747fd7fe0638  push r9
0000747fd7fe063a  push r10
0000747fd7fe063c  push r11
0000747fd7fe063e  sub rsp, 0xF0
0000747fd7fe0645  vmovaps [rsp], xmm0
0000747fd7fe064a  vmovaps [rsp+0x10], xmm1
0000747fd7fe0650  vmovaps [rsp+0x20], xmm2
0000747fd7fe0656  vmovaps [rsp+0x30], xmm3
0000747fd7fe065c  vmovaps [rsp+0x40], xmm4
0000747fd7fe0662  vmovaps [rsp+0x50], xmm5
0000747fd7fe0668  vmovaps [rsp+0x60], xmm6
0000747fd7fe066e  vmovaps [rsp+0x70], xmm7
0000747fd7fe0674  vmovaps [rsp+0x80], xmm8
0000747fd7fe067d  vmovaps [rsp+0x90], xmm9
0000747fd7fe0686  vmovaps [rsp+0xA0], xmm10
0000747fd7fe068f  vmovaps [rsp+0xB0], xmm11
0000747fd7fe0698  vmovaps [rsp+0xC0], xmm12
0000747fd7fe06a1  vmovaps [rsp+0xD0], xmm14
0000747fd7fe06aa  vmovaps [rsp+0xE0], xmm15
0000747fd7fe06b3  sub rsp, 0x30
0000747fd7fe06b7  movaps [rsp], xmm13
0000747fd7fe06bc  movaps [rsp+0x10], xmm15
0000747fd7fe06c2  movaps [rsp+0x20], xmm8
0000747fd7fe06c8  lea rdi, [rsp]
0000747fd7fe06cc  mov esi, 0x00
0000747fd7fe06d1  mov rax, 0x6055A0B6E530
0000747fd7fe06db  call rax
0000747fd7fe06dd  movaps xmm13, [rsp]
0000747fd7fe06e2  add rsp, 0x30
0000747fd7fe06e6  vmovaps xmm0, [rsp]
0000747fd7fe06eb  vmovaps xmm1, [rsp+0x10]
0000747fd7fe06f1  vmovaps xmm2, [rsp+0x20]
0000747fd7fe06f7  vmovaps xmm3, [rsp+0x30]
0000747fd7fe06fd  vmovaps xmm4, [rsp+0x40]
0000747fd7fe0703  vmovaps xmm5, [rsp+0x50]
0000747fd7fe0709  vmovaps xmm6, [rsp+0x60]
0000747fd7fe070f  vmovaps xmm7, [rsp+0x70]
0000747fd7fe0715  vmovaps xmm8, [rsp+0x80]
0000747fd7fe071e  vmovaps xmm9, [rsp+0x90]
0000747fd7fe0727  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe0730  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe0739  vmovaps xmm12, [rsp+0xC0]
0000747fd7fe0742  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe074b  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0754  add rsp, 0xF0
0000747fd7fe075b  pop r11
0000747fd7fe075d  pop r10
0000747fd7fe075f  pop r9
0000747fd7fe0761  pop r8
0000747fd7fe0763  pop rsi
0000747fd7fe0764  pop rdi
0000747fd7fe0765  pop rdx
0000747fd7fe0766  pop rcx
0000747fd7fe0767  pop rax
0000747fd7fe0768  add rsp, 0x08
0000747fd7fe076c  jmp 0x0000747FD7FDC60F
0000747fd7fe0771  sub rsp, 0x08
0000747fd7fe0775  push rax
0000747fd7fe0776  push rcx
0000747fd7fe0777  push rdx
0000747fd7fe0778  push rdi
0000747fd7fe0779  push rsi
0000747fd7fe077a  push r8
0000747fd7fe077c  push r9
0000747fd7fe077e  push r10
0000747fd7fe0780  push r11
0000747fd7fe0782  sub rsp, 0xF0
0000747fd7fe0789  vmovaps [rsp], xmm0
0000747fd7fe078e  vmovaps [rsp+0x10], xmm1
0000747fd7fe0794  vmovaps [rsp+0x20], xmm2
0000747fd7fe079a  vmovaps [rsp+0x30], xmm3
0000747fd7fe07a0  vmovaps [rsp+0x40], xmm4
0000747fd7fe07a6  vmovaps [rsp+0x50], xmm5
0000747fd7fe07ac  vmovaps [rsp+0x60], xmm6
0000747fd7fe07b2  vmovaps [rsp+0x70], xmm7
0000747fd7fe07b8  vmovaps [rsp+0x80], xmm9
0000747fd7fe07c1  vmovaps [rsp+0x90], xmm10
0000747fd7fe07ca  vmovaps [rsp+0xA0], xmm11
0000747fd7fe07d3  vmovaps [rsp+0xB0], xmm12
0000747fd7fe07dc  vmovaps [rsp+0xC0], xmm13
0000747fd7fe07e5  vmovaps [rsp+0xD0], xmm14
0000747fd7fe07ee  vmovaps [rsp+0xE0], xmm15
0000747fd7fe07f7  sub rsp, 0x30
0000747fd7fe07fb  movaps [rsp], xmm8
0000747fd7fe0800  movaps [rsp+0x10], xmm15
0000747fd7fe0806  movaps [rsp+0x20], xmm9
0000747fd7fe080c  lea rdi, [rsp]
0000747fd7fe0810  mov esi, 0x00
0000747fd7fe0815  mov rax, 0x6055A0B6E530
0000747fd7fe081f  call rax
0000747fd7fe0821  movaps xmm8, [rsp]
0000747fd7fe0826  add rsp, 0x30
0000747fd7fe082a  vmovaps xmm0, [rsp]
0000747fd7fe082f  vmovaps xmm1, [rsp+0x10]
0000747fd7fe0835  vmovaps xmm2, [rsp+0x20]
0000747fd7fe083b  vmovaps xmm3, [rsp+0x30]
0000747fd7fe0841  vmovaps xmm4, [rsp+0x40]
0000747fd7fe0847  vmovaps xmm5, [rsp+0x50]
0000747fd7fe084d  vmovaps xmm6, [rsp+0x60]
0000747fd7fe0853  vmovaps xmm7, [rsp+0x70]
0000747fd7fe0859  vmovaps xmm9, [rsp+0x80]
0000747fd7fe0862  vmovaps xmm10, [rsp+0x90]
0000747fd7fe086b  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe0874  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe087d  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe0886  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe088f  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0898  add rsp, 0xF0
0000747fd7fe089f  pop r11
0000747fd7fe08a1  pop r10
0000747fd7fe08a3  pop r9
0000747fd7fe08a5  pop r8
0000747fd7fe08a7  pop rsi
0000747fd7fe08a8  pop rdi
0000747fd7fe08a9  pop rdx
0000747fd7fe08aa  pop rcx
0000747fd7fe08ab  pop rax
0000747fd7fe08ac  add rsp, 0x08
0000747fd7fe08b0  jmp 0x0000747FD7FDC63D
0000747fd7fe08b5  sub rsp, 0x08
0000747fd7fe08b9  push rax
0000747fd7fe08ba  push rcx
0000747fd7fe08bb  push rdx
0000747fd7fe08bc  push rdi
0000747fd7fe08bd  push rsi
0000747fd7fe08be  push r8
0000747fd7fe08c0  push r9
0000747fd7fe08c2  push r10
0000747fd7fe08c4  push r11
0000747fd7fe08c6  sub rsp, 0xF0
0000747fd7fe08cd  vmovaps [rsp], xmm0
0000747fd7fe08d2  vmovaps [rsp+0x10], xmm1
0000747fd7fe08d8  vmovaps [rsp+0x20], xmm2
0000747fd7fe08de  vmovaps [rsp+0x30], xmm3
0000747fd7fe08e4  vmovaps [rsp+0x40], xmm4
0000747fd7fe08ea  vmovaps [rsp+0x50], xmm5
0000747fd7fe08f0  vmovaps [rsp+0x60], xmm6
0000747fd7fe08f6  vmovaps [rsp+0x70], xmm7
0000747fd7fe08fc  vmovaps [rsp+0x80], xmm8
0000747fd7fe0905  vmovaps [rsp+0x90], xmm9
0000747fd7fe090e  vmovaps [rsp+0xA0], xmm10
0000747fd7fe0917  vmovaps [rsp+0xB0], xmm11
0000747fd7fe0920  vmovaps [rsp+0xC0], xmm12
0000747fd7fe0929  vmovaps [rsp+0xD0], xmm13
0000747fd7fe0932  vmovaps [rsp+0xE0], xmm14
0000747fd7fe093b  sub rsp, 0x30
0000747fd7fe093f  movaps [rsp], xmm15
0000747fd7fe0944  movaps [rsp+0x10], xmm11
0000747fd7fe094a  movaps [rsp+0x20], xmm6
0000747fd7fe094f  lea rdi, [rsp]
0000747fd7fe0953  mov esi, 0x00
0000747fd7fe0958  mov rax, 0x6055A0B6E530
0000747fd7fe0962  call rax
0000747fd7fe0964  movaps xmm15, [rsp]
0000747fd7fe0969  add rsp, 0x30
0000747fd7fe096d  vmovaps xmm0, [rsp]
0000747fd7fe0972  vmovaps xmm1, [rsp+0x10]
0000747fd7fe0978  vmovaps xmm2, [rsp+0x20]
0000747fd7fe097e  vmovaps xmm3, [rsp+0x30]
0000747fd7fe0984  vmovaps xmm4, [rsp+0x40]
0000747fd7fe098a  vmovaps xmm5, [rsp+0x50]
0000747fd7fe0990  vmovaps xmm6, [rsp+0x60]
0000747fd7fe0996  vmovaps xmm7, [rsp+0x70]
0000747fd7fe099c  vmovaps xmm8, [rsp+0x80]
0000747fd7fe09a5  vmovaps xmm9, [rsp+0x90]
0000747fd7fe09ae  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe09b7  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe09c0  vmovaps xmm12, [rsp+0xC0]
0000747fd7fe09c9  vmovaps xmm13, [rsp+0xD0]
0000747fd7fe09d2  vmovaps xmm14, [rsp+0xE0]
0000747fd7fe09db  add rsp, 0xF0
0000747fd7fe09e2  pop r11
0000747fd7fe09e4  pop r10
0000747fd7fe09e6  pop r9
0000747fd7fe09e8  pop r8
0000747fd7fe09ea  pop rsi
0000747fd7fe09eb  pop rdi
0000747fd7fe09ec  pop rdx
0000747fd7fe09ed  pop rcx
0000747fd7fe09ee  pop rax
0000747fd7fe09ef  add rsp, 0x08
0000747fd7fe09f3  jmp 0x0000747FD7FDC658
0000747fd7fe09f8  sub rsp, 0x08
0000747fd7fe09fc  push rax
0000747fd7fe09fd  push rcx
0000747fd7fe09fe  push rdx
0000747fd7fe09ff  push rdi
0000747fd7fe0a00  push rsi
0000747fd7fe0a01  push r8
0000747fd7fe0a03  push r9
0000747fd7fe0a05  push r10
0000747fd7fe0a07  push r11
0000747fd7fe0a09  sub rsp, 0xF0
0000747fd7fe0a10  vmovaps [rsp], xmm0
0000747fd7fe0a15  vmovaps [rsp+0x10], xmm1
0000747fd7fe0a1b  vmovaps [rsp+0x20], xmm2
0000747fd7fe0a21  vmovaps [rsp+0x30], xmm3
0000747fd7fe0a27  vmovaps [rsp+0x40], xmm4
0000747fd7fe0a2d  vmovaps [rsp+0x50], xmm5
0000747fd7fe0a33  vmovaps [rsp+0x60], xmm6
0000747fd7fe0a39  vmovaps [rsp+0x70], xmm8
0000747fd7fe0a3f  vmovaps [rsp+0x80], xmm9
0000747fd7fe0a48  vmovaps [rsp+0x90], xmm10
0000747fd7fe0a51  vmovaps [rsp+0xA0], xmm11
0000747fd7fe0a5a  vmovaps [rsp+0xB0], xmm12
0000747fd7fe0a63  vmovaps [rsp+0xC0], xmm13
0000747fd7fe0a6c  vmovaps [rsp+0xD0], xmm14
0000747fd7fe0a75  vmovaps [rsp+0xE0], xmm15
0000747fd7fe0a7e  sub rsp, 0x30
0000747fd7fe0a82  movaps [rsp], xmm7
0000747fd7fe0a86  movaps [rsp+0x10], xmm11
0000747fd7fe0a8c  movaps [rsp+0x20], xmm9
0000747fd7fe0a92  lea rdi, [rsp]
0000747fd7fe0a96  mov esi, 0x00
0000747fd7fe0a9b  mov rax, 0x6055A0B6E530
0000747fd7fe0aa5  call rax
0000747fd7fe0aa7  movaps xmm7, [rsp]
0000747fd7fe0aab  add rsp, 0x30
0000747fd7fe0aaf  vmovaps xmm0, [rsp]
0000747fd7fe0ab4  vmovaps xmm1, [rsp+0x10]
0000747fd7fe0aba  vmovaps xmm2, [rsp+0x20]
0000747fd7fe0ac0  vmovaps xmm3, [rsp+0x30]
0000747fd7fe0ac6  vmovaps xmm4, [rsp+0x40]
0000747fd7fe0acc  vmovaps xmm5, [rsp+0x50]
0000747fd7fe0ad2  vmovaps xmm6, [rsp+0x60]
0000747fd7fe0ad8  vmovaps xmm8, [rsp+0x70]
0000747fd7fe0ade  vmovaps xmm9, [rsp+0x80]
0000747fd7fe0ae7  vmovaps xmm10, [rsp+0x90]
0000747fd7fe0af0  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe0af9  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe0b02  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe0b0b  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe0b14  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0b1d  add rsp, 0xF0
0000747fd7fe0b24  pop r11
0000747fd7fe0b26  pop r10
0000747fd7fe0b28  pop r9
0000747fd7fe0b2a  pop r8
0000747fd7fe0b2c  pop rsi
0000747fd7fe0b2d  pop rdi
0000747fd7fe0b2e  pop rdx
0000747fd7fe0b2f  pop rcx
0000747fd7fe0b30  pop rax
0000747fd7fe0b31  add rsp, 0x08
0000747fd7fe0b35  jmp 0x0000747FD7FDC685
0000747fd7fe0b3a  sub rsp, 0x08
0000747fd7fe0b3e  push rax
0000747fd7fe0b3f  push rcx
0000747fd7fe0b40  push rdx
0000747fd7fe0b41  push rdi
0000747fd7fe0b42  push rsi
0000747fd7fe0b43  push r8
0000747fd7fe0b45  push r9
0000747fd7fe0b47  push r10
0000747fd7fe0b49  push r11
0000747fd7fe0b4b  sub rsp, 0xF0
0000747fd7fe0b52  vmovaps [rsp], xmm0
0000747fd7fe0b57  vmovaps [rsp+0x10], xmm1
0000747fd7fe0b5d  vmovaps [rsp+0x20], xmm2
0000747fd7fe0b63  vmovaps [rsp+0x30], xmm3
0000747fd7fe0b69  vmovaps [rsp+0x40], xmm4
0000747fd7fe0b6f  vmovaps [rsp+0x50], xmm5
0000747fd7fe0b75  vmovaps [rsp+0x60], xmm6
0000747fd7fe0b7b  vmovaps [rsp+0x70], xmm7
0000747fd7fe0b81  vmovaps [rsp+0x80], xmm8
0000747fd7fe0b8a  vmovaps [rsp+0x90], xmm9
0000747fd7fe0b93  vmovaps [rsp+0xA0], xmm10
0000747fd7fe0b9c  vmovaps [rsp+0xB0], xmm12
0000747fd7fe0ba5  vmovaps [rsp+0xC0], xmm13
0000747fd7fe0bae  vmovaps [rsp+0xD0], xmm14
0000747fd7fe0bb7  vmovaps [rsp+0xE0], xmm15
0000747fd7fe0bc0  sub rsp, 0x30
0000747fd7fe0bc4  movaps [rsp], xmm11
0000747fd7fe0bc9  movaps [rsp+0x10], xmm10
0000747fd7fe0bcf  movaps [rsp+0x20], xmm14
0000747fd7fe0bd5  lea rdi, [rsp]
0000747fd7fe0bd9  mov esi, 0x00
0000747fd7fe0bde  mov rax, 0x6055A0B6E530
0000747fd7fe0be8  call rax
0000747fd7fe0bea  movaps xmm11, [rsp]
0000747fd7fe0bef  add rsp, 0x30
0000747fd7fe0bf3  vmovaps xmm0, [rsp]
0000747fd7fe0bf8  vmovaps xmm1, [rsp+0x10]
0000747fd7fe0bfe  vmovaps xmm2, [rsp+0x20]
0000747fd7fe0c04  vmovaps xmm3, [rsp+0x30]
0000747fd7fe0c0a  vmovaps xmm4, [rsp+0x40]
0000747fd7fe0c10  vmovaps xmm5, [rsp+0x50]
0000747fd7fe0c16  vmovaps xmm6, [rsp+0x60]
0000747fd7fe0c1c  vmovaps xmm7, [rsp+0x70]
0000747fd7fe0c22  vmovaps xmm8, [rsp+0x80]
0000747fd7fe0c2b  vmovaps xmm9, [rsp+0x90]
0000747fd7fe0c34  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe0c3d  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe0c46  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe0c4f  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe0c58  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0c61  add rsp, 0xF0
0000747fd7fe0c68  pop r11
0000747fd7fe0c6a  pop r10
0000747fd7fe0c6c  pop r9
0000747fd7fe0c6e  pop r8
0000747fd7fe0c70  pop rsi
0000747fd7fe0c71  pop rdi
0000747fd7fe0c72  pop rdx
0000747fd7fe0c73  pop rcx
0000747fd7fe0c74  pop rax
0000747fd7fe0c75  add rsp, 0x08
0000747fd7fe0c79  jmp 0x0000747FD7FDC6A0
0000747fd7fe0c7e  call 0x0000747FD7EC33A0
0000747fd7fe0c83  jmp 0x0000747FD7FDC6AA
0000747fd7fe0c88  sub rsp, 0x08
0000747fd7fe0c8c  push rax
0000747fd7fe0c8d  push rcx
0000747fd7fe0c8e  push rdx
0000747fd7fe0c8f  push rdi
0000747fd7fe0c90  push rsi
0000747fd7fe0c91  push r8
0000747fd7fe0c93  push r9
0000747fd7fe0c95  push r10
0000747fd7fe0c97  push r11
0000747fd7fe0c99  sub rsp, 0xF0
0000747fd7fe0ca0  vmovaps [rsp], xmm0
0000747fd7fe0ca5  vmovaps [rsp+0x10], xmm1
0000747fd7fe0cab  vmovaps [rsp+0x20], xmm2
0000747fd7fe0cb1  vmovaps [rsp+0x30], xmm3
0000747fd7fe0cb7  vmovaps [rsp+0x40], xmm4
0000747fd7fe0cbd  vmovaps [rsp+0x50], xmm5
0000747fd7fe0cc3  vmovaps [rsp+0x60], xmm6
0000747fd7fe0cc9  vmovaps [rsp+0x70], xmm7
0000747fd7fe0ccf  vmovaps [rsp+0x80], xmm8
0000747fd7fe0cd8  vmovaps [rsp+0x90], xmm9
0000747fd7fe0ce1  vmovaps [rsp+0xA0], xmm11
0000747fd7fe0cea  vmovaps [rsp+0xB0], xmm12
0000747fd7fe0cf3  vmovaps [rsp+0xC0], xmm13
0000747fd7fe0cfc  vmovaps [rsp+0xD0], xmm14
0000747fd7fe0d05  vmovaps [rsp+0xE0], xmm15
0000747fd7fe0d0e  sub rsp, 0x30
0000747fd7fe0d12  movaps [rsp], xmm10
0000747fd7fe0d17  movaps [rsp+0x10], xmm1
0000747fd7fe0d1c  movaps [rsp+0x20], xmm12
0000747fd7fe0d22  lea rdi, [rsp]
0000747fd7fe0d26  mov esi, 0x00
0000747fd7fe0d2b  mov rax, 0x6055A0B6E530
0000747fd7fe0d35  call rax
0000747fd7fe0d37  movaps xmm10, [rsp]
0000747fd7fe0d3c  add rsp, 0x30
0000747fd7fe0d40  vmovaps xmm0, [rsp]
0000747fd7fe0d45  vmovaps xmm1, [rsp+0x10]
0000747fd7fe0d4b  vmovaps xmm2, [rsp+0x20]
0000747fd7fe0d51  vmovaps xmm3, [rsp+0x30]
0000747fd7fe0d57  vmovaps xmm4, [rsp+0x40]
0000747fd7fe0d5d  vmovaps xmm5, [rsp+0x50]
0000747fd7fe0d63  vmovaps xmm6, [rsp+0x60]
0000747fd7fe0d69  vmovaps xmm7, [rsp+0x70]
0000747fd7fe0d6f  vmovaps xmm8, [rsp+0x80]
0000747fd7fe0d78  vmovaps xmm9, [rsp+0x90]
0000747fd7fe0d81  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe0d8a  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe0d93  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe0d9c  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe0da5  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0dae  add rsp, 0xF0
0000747fd7fe0db5  pop r11
0000747fd7fe0db7  pop r10
0000747fd7fe0db9  pop r9
0000747fd7fe0dbb  pop r8
0000747fd7fe0dbd  pop rsi
0000747fd7fe0dbe  pop rdi
0000747fd7fe0dbf  pop rdx
0000747fd7fe0dc0  pop rcx
0000747fd7fe0dc1  pop rax
0000747fd7fe0dc2  add rsp, 0x08
0000747fd7fe0dc6  jmp 0x0000747FD7FDC6CD
0000747fd7fe0dcb  sub rsp, 0x08
0000747fd7fe0dcf  push rax
0000747fd7fe0dd0  push rcx
0000747fd7fe0dd1  push rdx
0000747fd7fe0dd2  push rdi
0000747fd7fe0dd3  push rsi
0000747fd7fe0dd4  push r8
0000747fd7fe0dd6  push r9
0000747fd7fe0dd8  push r10
0000747fd7fe0dda  push r11
0000747fd7fe0ddc  sub rsp, 0xF0
0000747fd7fe0de3  vmovaps [rsp], xmm0
0000747fd7fe0de8  vmovaps [rsp+0x10], xmm1
0000747fd7fe0dee  vmovaps [rsp+0x20], xmm2
0000747fd7fe0df4  vmovaps [rsp+0x30], xmm3
0000747fd7fe0dfa  vmovaps [rsp+0x40], xmm4
0000747fd7fe0e00  vmovaps [rsp+0x50], xmm5
0000747fd7fe0e06  vmovaps [rsp+0x60], xmm6
0000747fd7fe0e0c  vmovaps [rsp+0x70], xmm7
0000747fd7fe0e12  vmovaps [rsp+0x80], xmm8
0000747fd7fe0e1b  vmovaps [rsp+0x90], xmm9
0000747fd7fe0e24  vmovaps [rsp+0xA0], xmm10
0000747fd7fe0e2d  vmovaps [rsp+0xB0], xmm11
0000747fd7fe0e36  vmovaps [rsp+0xC0], xmm13
0000747fd7fe0e3f  vmovaps [rsp+0xD0], xmm14
0000747fd7fe0e48  vmovaps [rsp+0xE0], xmm15
0000747fd7fe0e51  sub rsp, 0x30
0000747fd7fe0e55  movaps [rsp], xmm12
0000747fd7fe0e5a  movaps [rsp+0x10], xmm14
0000747fd7fe0e60  movaps [rsp+0x20], xmm1
0000747fd7fe0e65  lea rdi, [rsp]
0000747fd7fe0e69  mov esi, 0x00
0000747fd7fe0e6e  mov rax, 0x6055A0B6E530
0000747fd7fe0e78  call rax
0000747fd7fe0e7a  movaps xmm12, [rsp]
0000747fd7fe0e7f  add rsp, 0x30
0000747fd7fe0e83  vmovaps xmm0, [rsp]
0000747fd7fe0e88  vmovaps xmm1, [rsp+0x10]
0000747fd7fe0e8e  vmovaps xmm2, [rsp+0x20]
0000747fd7fe0e94  vmovaps xmm3, [rsp+0x30]
0000747fd7fe0e9a  vmovaps xmm4, [rsp+0x40]
0000747fd7fe0ea0  vmovaps xmm5, [rsp+0x50]
0000747fd7fe0ea6  vmovaps xmm6, [rsp+0x60]
0000747fd7fe0eac  vmovaps xmm7, [rsp+0x70]
0000747fd7fe0eb2  vmovaps xmm8, [rsp+0x80]
0000747fd7fe0ebb  vmovaps xmm9, [rsp+0x90]
0000747fd7fe0ec4  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe0ecd  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe0ed6  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe0edf  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe0ee8  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe0ef1  add rsp, 0xF0
0000747fd7fe0ef8  pop r11
0000747fd7fe0efa  pop r10
0000747fd7fe0efc  pop r9
0000747fd7fe0efe  pop r8
0000747fd7fe0f00  pop rsi
0000747fd7fe0f01  pop rdi
0000747fd7fe0f02  pop rdx
0000747fd7fe0f03  pop rcx
0000747fd7fe0f04  pop rax
0000747fd7fe0f05  add rsp, 0x08
0000747fd7fe0f09  jmp 0x0000747FD7FDC6FC
0000747fd7fe0f0e  sub rsp, 0x08
0000747fd7fe0f12  push rax
0000747fd7fe0f13  push rcx
0000747fd7fe0f14  push rdx
0000747fd7fe0f15  push rdi
0000747fd7fe0f16  push rsi
0000747fd7fe0f17  push r8
0000747fd7fe0f19  push r9
0000747fd7fe0f1b  push r10
0000747fd7fe0f1d  push r11
0000747fd7fe0f1f  sub rsp, 0xF0
0000747fd7fe0f26  vmovaps [rsp], xmm0
0000747fd7fe0f2b  vmovaps [rsp+0x10], xmm1
0000747fd7fe0f31  vmovaps [rsp+0x20], xmm2
0000747fd7fe0f37  vmovaps [rsp+0x30], xmm3
0000747fd7fe0f3d  vmovaps [rsp+0x40], xmm4
0000747fd7fe0f43  vmovaps [rsp+0x50], xmm5
0000747fd7fe0f49  vmovaps [rsp+0x60], xmm6
0000747fd7fe0f4f  vmovaps [rsp+0x70], xmm7
0000747fd7fe0f55  vmovaps [rsp+0x80], xmm8
0000747fd7fe0f5e  vmovaps [rsp+0x90], xmm9
0000747fd7fe0f67  vmovaps [rsp+0xA0], xmm10
0000747fd7fe0f70  vmovaps [rsp+0xB0], xmm11
0000747fd7fe0f79  vmovaps [rsp+0xC0], xmm12
0000747fd7fe0f82  vmovaps [rsp+0xD0], xmm13
0000747fd7fe0f8b  vmovaps [rsp+0xE0], xmm15
0000747fd7fe0f94  sub rsp, 0x30
0000747fd7fe0f98  movaps [rsp], xmm14
0000747fd7fe0f9d  movaps [rsp+0x10], xmm9
0000747fd7fe0fa3  movaps [rsp+0x20], xmm1
0000747fd7fe0fa8  lea rdi, [rsp]
0000747fd7fe0fac  mov esi, 0x00
0000747fd7fe0fb1  mov rax, 0x6055A0B6E530
0000747fd7fe0fbb  call rax
0000747fd7fe0fbd  movaps xmm14, [rsp]
0000747fd7fe0fc2  add rsp, 0x30
0000747fd7fe0fc6  vmovaps xmm0, [rsp]
0000747fd7fe0fcb  vmovaps xmm1, [rsp+0x10]
0000747fd7fe0fd1  vmovaps xmm2, [rsp+0x20]
0000747fd7fe0fd7  vmovaps xmm3, [rsp+0x30]
0000747fd7fe0fdd  vmovaps xmm4, [rsp+0x40]
0000747fd7fe0fe3  vmovaps xmm5, [rsp+0x50]
0000747fd7fe0fe9  vmovaps xmm6, [rsp+0x60]
0000747fd7fe0fef  vmovaps xmm7, [rsp+0x70]
0000747fd7fe0ff5  vmovaps xmm8, [rsp+0x80]
0000747fd7fe0ffe  vmovaps xmm9, [rsp+0x90]
0000747fd7fe1007  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe1010  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe1019  vmovaps xmm12, [rsp+0xC0]
0000747fd7fe1022  vmovaps xmm13, [rsp+0xD0]
0000747fd7fe102b  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe1034  add rsp, 0xF0
0000747fd7fe103b  pop r11
0000747fd7fe103d  pop r10
0000747fd7fe103f  pop r9
0000747fd7fe1041  pop r8
0000747fd7fe1043  pop rsi
0000747fd7fe1044  pop rdi
0000747fd7fe1045  pop rdx
0000747fd7fe1046  pop rcx
0000747fd7fe1047  pop rax
0000747fd7fe1048  add rsp, 0x08
0000747fd7fe104c  jmp 0x0000747FD7FDC72B
0000747fd7fe1051  sub rsp, 0x08
0000747fd7fe1055  push rax
0000747fd7fe1056  push rcx
0000747fd7fe1057  push rdx
0000747fd7fe1058  push rdi
0000747fd7fe1059  push rsi
0000747fd7fe105a  push r8
0000747fd7fe105c  push r9
0000747fd7fe105e  push r10
0000747fd7fe1060  push r11
0000747fd7fe1062  sub rsp, 0xF0
0000747fd7fe1069  vmovaps [rsp], xmm0
0000747fd7fe106e  vmovaps [rsp+0x10], xmm2
0000747fd7fe1074  vmovaps [rsp+0x20], xmm3
0000747fd7fe107a  vmovaps [rsp+0x30], xmm4
0000747fd7fe1080  vmovaps [rsp+0x40], xmm5
0000747fd7fe1086  vmovaps [rsp+0x50], xmm6
0000747fd7fe108c  vmovaps [rsp+0x60], xmm7
0000747fd7fe1092  vmovaps [rsp+0x70], xmm8
0000747fd7fe1098  vmovaps [rsp+0x80], xmm9
0000747fd7fe10a1  vmovaps [rsp+0x90], xmm10
0000747fd7fe10aa  vmovaps [rsp+0xA0], xmm11
0000747fd7fe10b3  vmovaps [rsp+0xB0], xmm12
0000747fd7fe10bc  vmovaps [rsp+0xC0], xmm13
0000747fd7fe10c5  vmovaps [rsp+0xD0], xmm14
0000747fd7fe10ce  vmovaps [rsp+0xE0], xmm15
0000747fd7fe10d7  sub rsp, 0x30
0000747fd7fe10db  movaps [rsp], xmm1
0000747fd7fe10df  movaps [rsp+0x10], xmm13
0000747fd7fe10e5  movaps [rsp+0x20], xmm8
0000747fd7fe10eb  lea rdi, [rsp]
0000747fd7fe10ef  mov esi, 0x00
0000747fd7fe10f4  mov rax, 0x6055A0B6E530
0000747fd7fe10fe  call rax
0000747fd7fe1100  movaps xmm1, [rsp]
0000747fd7fe1104  add rsp, 0x30
0000747fd7fe1108  vmovaps xmm0, [rsp]
0000747fd7fe110d  vmovaps xmm2, [rsp+0x10]
0000747fd7fe1113  vmovaps xmm3, [rsp+0x20]
0000747fd7fe1119  vmovaps xmm4, [rsp+0x30]
0000747fd7fe111f  vmovaps xmm5, [rsp+0x40]
0000747fd7fe1125  vmovaps xmm6, [rsp+0x50]
0000747fd7fe112b  vmovaps xmm7, [rsp+0x60]
0000747fd7fe1131  vmovaps xmm8, [rsp+0x70]
0000747fd7fe1137  vmovaps xmm9, [rsp+0x80]
0000747fd7fe1140  vmovaps xmm10, [rsp+0x90]
0000747fd7fe1149  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe1152  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe115b  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe1164  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe116d  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe1176  add rsp, 0xF0
0000747fd7fe117d  pop r11
0000747fd7fe117f  pop r10
0000747fd7fe1181  pop r9
0000747fd7fe1183  pop r8
0000747fd7fe1185  pop rsi
0000747fd7fe1186  pop rdi
0000747fd7fe1187  pop rdx
0000747fd7fe1188  pop rcx
0000747fd7fe1189  pop rax
0000747fd7fe118a  add rsp, 0x08
0000747fd7fe118e  jmp 0x0000747FD7FDC74D
0000747fd7fe1193  call 0x0000747FD7E0C260
0000747fd7fe1198  jmp 0x0000747FD7FDC75B
0000747fd7fe119d  call 0x0000747FD7EBD750
0000747fd7fe11a2  jmp 0x0000747FD7FDC765
0000747fd7fe11a7  sub rsp, 0x08
0000747fd7fe11ab  push rax
0000747fd7fe11ac  push rcx
0000747fd7fe11ad  push rdx
0000747fd7fe11ae  push rdi
0000747fd7fe11af  push rsi
0000747fd7fe11b0  push r8
0000747fd7fe11b2  push r9
0000747fd7fe11b4  push r10
0000747fd7fe11b6  push r11
0000747fd7fe11b8  sub rsp, 0xF0
0000747fd7fe11bf  vmovaps [rsp], xmm0
0000747fd7fe11c4  vmovaps [rsp+0x10], xmm1
0000747fd7fe11ca  vmovaps [rsp+0x20], xmm2
0000747fd7fe11d0  vmovaps [rsp+0x30], xmm3
0000747fd7fe11d6  vmovaps [rsp+0x40], xmm4
0000747fd7fe11dc  vmovaps [rsp+0x50], xmm5
0000747fd7fe11e2  vmovaps [rsp+0x60], xmm6
0000747fd7fe11e8  vmovaps [rsp+0x70], xmm7
0000747fd7fe11ee  vmovaps [rsp+0x80], xmm9
0000747fd7fe11f7  vmovaps [rsp+0x90], xmm10
0000747fd7fe1200  vmovaps [rsp+0xA0], xmm11
0000747fd7fe1209  vmovaps [rsp+0xB0], xmm12
0000747fd7fe1212  vmovaps [rsp+0xC0], xmm13
0000747fd7fe121b  vmovaps [rsp+0xD0], xmm14
0000747fd7fe1224  vmovaps [rsp+0xE0], xmm15
0000747fd7fe122d  sub rsp, 0x30
0000747fd7fe1231  movaps [rsp], xmm8
0000747fd7fe1236  movaps [rsp+0x10], xmm15
0000747fd7fe123c  movaps [rsp+0x20], xmm7
0000747fd7fe1241  lea rdi, [rsp]
0000747fd7fe1245  mov esi, 0x00
0000747fd7fe124a  mov rax, 0x6055A0B6E530
0000747fd7fe1254  call rax
0000747fd7fe1256  movaps xmm8, [rsp]
0000747fd7fe125b  add rsp, 0x30
0000747fd7fe125f  vmovaps xmm0, [rsp]
0000747fd7fe1264  vmovaps xmm1, [rsp+0x10]
0000747fd7fe126a  vmovaps xmm2, [rsp+0x20]
0000747fd7fe1270  vmovaps xmm3, [rsp+0x30]
0000747fd7fe1276  vmovaps xmm4, [rsp+0x40]
0000747fd7fe127c  vmovaps xmm5, [rsp+0x50]
0000747fd7fe1282  vmovaps xmm6, [rsp+0x60]
0000747fd7fe1288  vmovaps xmm7, [rsp+0x70]
0000747fd7fe128e  vmovaps xmm9, [rsp+0x80]
0000747fd7fe1297  vmovaps xmm10, [rsp+0x90]
0000747fd7fe12a0  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe12a9  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe12b2  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe12bb  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe12c4  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe12cd  add rsp, 0xF0
0000747fd7fe12d4  pop r11
0000747fd7fe12d6  pop r10
0000747fd7fe12d8  pop r9
0000747fd7fe12da  pop r8
0000747fd7fe12dc  pop rsi
0000747fd7fe12dd  pop rdi
0000747fd7fe12de  pop rdx
0000747fd7fe12df  pop rcx
0000747fd7fe12e0  pop rax
0000747fd7fe12e1  add rsp, 0x08
0000747fd7fe12e5  jmp 0x0000747FD7FDC787
0000747fd7fe12ea  sub rsp, 0x08
0000747fd7fe12ee  push rax
0000747fd7fe12ef  push rcx
0000747fd7fe12f0  push rdx
0000747fd7fe12f1  push rdi
0000747fd7fe12f2  push rsi
0000747fd7fe12f3  push r8
0000747fd7fe12f5  push r9
0000747fd7fe12f7  push r10
0000747fd7fe12f9  push r11
0000747fd7fe12fb  sub rsp, 0xF0
0000747fd7fe1302  vmovaps [rsp], xmm0
0000747fd7fe1307  vmovaps [rsp+0x10], xmm1
0000747fd7fe130d  vmovaps [rsp+0x20], xmm2
0000747fd7fe1313  vmovaps [rsp+0x30], xmm3
0000747fd7fe1319  vmovaps [rsp+0x40], xmm4
0000747fd7fe131f  vmovaps [rsp+0x50], xmm5
0000747fd7fe1325  vmovaps [rsp+0x60], xmm6
0000747fd7fe132b  vmovaps [rsp+0x70], xmm8
0000747fd7fe1331  vmovaps [rsp+0x80], xmm9
0000747fd7fe133a  vmovaps [rsp+0x90], xmm10
0000747fd7fe1343  vmovaps [rsp+0xA0], xmm11
0000747fd7fe134c  vmovaps [rsp+0xB0], xmm12
0000747fd7fe1355  vmovaps [rsp+0xC0], xmm13
0000747fd7fe135e  vmovaps [rsp+0xD0], xmm14
0000747fd7fe1367  vmovaps [rsp+0xE0], xmm15
0000747fd7fe1370  sub rsp, 0x30
0000747fd7fe1374  movaps [rsp], xmm7
0000747fd7fe1378  movaps [rsp+0x10], xmm9
0000747fd7fe137e  movaps [rsp+0x20], xmm15
0000747fd7fe1384  lea rdi, [rsp]
0000747fd7fe1388  mov esi, 0x00
0000747fd7fe138d  mov rax, 0x6055A0B6E530
0000747fd7fe1397  call rax
0000747fd7fe1399  movaps xmm7, [rsp]
0000747fd7fe139d  add rsp, 0x30
0000747fd7fe13a1  vmovaps xmm0, [rsp]
0000747fd7fe13a6  vmovaps xmm1, [rsp+0x10]
0000747fd7fe13ac  vmovaps xmm2, [rsp+0x20]
0000747fd7fe13b2  vmovaps xmm3, [rsp+0x30]
0000747fd7fe13b8  vmovaps xmm4, [rsp+0x40]
0000747fd7fe13be  vmovaps xmm5, [rsp+0x50]
0000747fd7fe13c4  vmovaps xmm6, [rsp+0x60]
0000747fd7fe13ca  vmovaps xmm8, [rsp+0x70]
0000747fd7fe13d0  vmovaps xmm9, [rsp+0x80]
0000747fd7fe13d9  vmovaps xmm10, [rsp+0x90]
0000747fd7fe13e2  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe13eb  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe13f4  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe13fd  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe1406  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe140f  add rsp, 0xF0
0000747fd7fe1416  pop r11
0000747fd7fe1418  pop r10
0000747fd7fe141a  pop r9
0000747fd7fe141c  pop r8
0000747fd7fe141e  pop rsi
0000747fd7fe141f  pop rdi
0000747fd7fe1420  pop rdx
0000747fd7fe1421  pop rcx
0000747fd7fe1422  pop rax
0000747fd7fe1423  add rsp, 0x08
0000747fd7fe1427  jmp 0x0000747FD7FDC7B4
0000747fd7fe142c  sub rsp, 0x08
0000747fd7fe1430  push rax
0000747fd7fe1431  push rcx
0000747fd7fe1432  push rdx
0000747fd7fe1433  push rdi
0000747fd7fe1434  push rsi
0000747fd7fe1435  push r8
0000747fd7fe1437  push r9
0000747fd7fe1439  push r10
0000747fd7fe143b  push r11
0000747fd7fe143d  sub rsp, 0xF0
0000747fd7fe1444  vmovaps [rsp], xmm0
0000747fd7fe1449  vmovaps [rsp+0x10], xmm1
0000747fd7fe144f  vmovaps [rsp+0x20], xmm2
0000747fd7fe1455  vmovaps [rsp+0x30], xmm3
0000747fd7fe145b  vmovaps [rsp+0x40], xmm4
0000747fd7fe1461  vmovaps [rsp+0x50], xmm5
0000747fd7fe1467  vmovaps [rsp+0x60], xmm6
0000747fd7fe146d  vmovaps [rsp+0x70], xmm7
0000747fd7fe1473  vmovaps [rsp+0x80], xmm8
0000747fd7fe147c  vmovaps [rsp+0x90], xmm10
0000747fd7fe1485  vmovaps [rsp+0xA0], xmm11
0000747fd7fe148e  vmovaps [rsp+0xB0], xmm12
0000747fd7fe1497  vmovaps [rsp+0xC0], xmm13
0000747fd7fe14a0  vmovaps [rsp+0xD0], xmm14
0000747fd7fe14a9  vmovaps [rsp+0xE0], xmm15
0000747fd7fe14b2  sub rsp, 0x30
0000747fd7fe14b6  movaps [rsp], xmm9
0000747fd7fe14bb  movaps [rsp+0x10], xmm13
0000747fd7fe14c1  movaps [rsp+0x20], xmm15
0000747fd7fe14c7  lea rdi, [rsp]
0000747fd7fe14cb  mov esi, 0x00
0000747fd7fe14d0  mov rax, 0x6055A0B6E530
0000747fd7fe14da  call rax
0000747fd7fe14dc  movaps xmm9, [rsp]
0000747fd7fe14e1  add rsp, 0x30
0000747fd7fe14e5  vmovaps xmm0, [rsp]
0000747fd7fe14ea  vmovaps xmm1, [rsp+0x10]
0000747fd7fe14f0  vmovaps xmm2, [rsp+0x20]
0000747fd7fe14f6  vmovaps xmm3, [rsp+0x30]
0000747fd7fe14fc  vmovaps xmm4, [rsp+0x40]
0000747fd7fe1502  vmovaps xmm5, [rsp+0x50]
0000747fd7fe1508  vmovaps xmm6, [rsp+0x60]
0000747fd7fe150e  vmovaps xmm7, [rsp+0x70]
0000747fd7fe1514  vmovaps xmm8, [rsp+0x80]
0000747fd7fe151d  vmovaps xmm10, [rsp+0x90]
0000747fd7fe1526  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe152f  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe1538  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe1541  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe154a  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe1553  add rsp, 0xF0
0000747fd7fe155a  pop r11
0000747fd7fe155c  pop r10
0000747fd7fe155e  pop r9
0000747fd7fe1560  pop r8
0000747fd7fe1562  pop rsi
0000747fd7fe1563  pop rdi
0000747fd7fe1564  pop rdx
0000747fd7fe1565  pop rcx
0000747fd7fe1566  pop rax
0000747fd7fe1567  add rsp, 0x08
0000747fd7fe156b  jmp 0x0000747FD7FDC7E2
0000747fd7fe1570  sub rsp, 0x08
0000747fd7fe1574  push rax
0000747fd7fe1575  push rcx
0000747fd7fe1576  push rdx
0000747fd7fe1577  push rdi
0000747fd7fe1578  push rsi
0000747fd7fe1579  push r8
0000747fd7fe157b  push r9
0000747fd7fe157d  push r10
0000747fd7fe157f  push r11
0000747fd7fe1581  sub rsp, 0xF0
0000747fd7fe1588  vmovaps [rsp], xmm0
0000747fd7fe158d  vmovaps [rsp+0x10], xmm1
0000747fd7fe1593  vmovaps [rsp+0x20], xmm2
0000747fd7fe1599  vmovaps [rsp+0x30], xmm3
0000747fd7fe159f  vmovaps [rsp+0x40], xmm4
0000747fd7fe15a5  vmovaps [rsp+0x50], xmm5
0000747fd7fe15ab  vmovaps [rsp+0x60], xmm6
0000747fd7fe15b1  vmovaps [rsp+0x70], xmm7
0000747fd7fe15b7  vmovaps [rsp+0x80], xmm8
0000747fd7fe15c0  vmovaps [rsp+0x90], xmm9
0000747fd7fe15c9  vmovaps [rsp+0xA0], xmm10
0000747fd7fe15d2  vmovaps [rsp+0xB0], xmm11
0000747fd7fe15db  vmovaps [rsp+0xC0], xmm12
0000747fd7fe15e4  vmovaps [rsp+0xD0], xmm13
0000747fd7fe15ed  vmovaps [rsp+0xE0], xmm14
0000747fd7fe15f6  sub rsp, 0x30
0000747fd7fe15fa  movaps [rsp], xmm15
0000747fd7fe15ff  movaps [rsp+0x10], xmm11
0000747fd7fe1605  movaps [rsp+0x20], xmm12
0000747fd7fe160b  lea rdi, [rsp]
0000747fd7fe160f  mov esi, 0x00
0000747fd7fe1614  mov rax, 0x6055A0B6E530
0000747fd7fe161e  call rax
0000747fd7fe1620  movaps xmm15, [rsp]
0000747fd7fe1625  add rsp, 0x30
0000747fd7fe1629  vmovaps xmm0, [rsp]
0000747fd7fe162e  vmovaps xmm1, [rsp+0x10]
0000747fd7fe1634  vmovaps xmm2, [rsp+0x20]
0000747fd7fe163a  vmovaps xmm3, [rsp+0x30]
0000747fd7fe1640  vmovaps xmm4, [rsp+0x40]
0000747fd7fe1646  vmovaps xmm5, [rsp+0x50]
0000747fd7fe164c  vmovaps xmm6, [rsp+0x60]
0000747fd7fe1652  vmovaps xmm7, [rsp+0x70]
0000747fd7fe1658  vmovaps xmm8, [rsp+0x80]
0000747fd7fe1661  vmovaps xmm9, [rsp+0x90]
0000747fd7fe166a  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe1673  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe167c  vmovaps xmm12, [rsp+0xC0]
0000747fd7fe1685  vmovaps xmm13, [rsp+0xD0]
0000747fd7fe168e  vmovaps xmm14, [rsp+0xE0]
0000747fd7fe1697  add rsp, 0xF0
0000747fd7fe169e  pop r11
0000747fd7fe16a0  pop r10
0000747fd7fe16a2  pop r9
0000747fd7fe16a4  pop r8
0000747fd7fe16a6  pop rsi
0000747fd7fe16a7  pop rdi
0000747fd7fe16a8  pop rdx
0000747fd7fe16a9  pop rcx
0000747fd7fe16aa  pop rax
0000747fd7fe16ab  add rsp, 0x08
0000747fd7fe16af  jmp 0x0000747FD7FDC7FD
0000747fd7fe16b4  sub rsp, 0x08
0000747fd7fe16b8  push rax
0000747fd7fe16b9  push rcx
0000747fd7fe16ba  push rdx
0000747fd7fe16bb  push rdi
0000747fd7fe16bc  push rsi
0000747fd7fe16bd  push r8
0000747fd7fe16bf  push r9
0000747fd7fe16c1  push r10
0000747fd7fe16c3  push r11
0000747fd7fe16c5  sub rsp, 0xF0
0000747fd7fe16cc  vmovaps [rsp], xmm0
0000747fd7fe16d1  vmovaps [rsp+0x10], xmm1
0000747fd7fe16d7  vmovaps [rsp+0x20], xmm2
0000747fd7fe16dd  vmovaps [rsp+0x30], xmm3
0000747fd7fe16e3  vmovaps [rsp+0x40], xmm4
0000747fd7fe16e9  vmovaps [rsp+0x50], xmm5
0000747fd7fe16ef  vmovaps [rsp+0x60], xmm6
0000747fd7fe16f5  vmovaps [rsp+0x70], xmm7
0000747fd7fe16fb  vmovaps [rsp+0x80], xmm8
0000747fd7fe1704  vmovaps [rsp+0x90], xmm9
0000747fd7fe170d  vmovaps [rsp+0xA0], xmm10
0000747fd7fe1716  vmovaps [rsp+0xB0], xmm11
0000747fd7fe171f  vmovaps [rsp+0xC0], xmm12
0000747fd7fe1728  vmovaps [rsp+0xD0], xmm14
0000747fd7fe1731  vmovaps [rsp+0xE0], xmm15
0000747fd7fe173a  sub rsp, 0x30
0000747fd7fe173e  movaps [rsp], xmm13
0000747fd7fe1743  movaps [rsp+0x10], xmm10
0000747fd7fe1749  movaps [rsp+0x20], xmm14
0000747fd7fe174f  lea rdi, [rsp]
0000747fd7fe1753  mov esi, 0x00
0000747fd7fe1758  mov rax, 0x6055A0B6E530
0000747fd7fe1762  call rax
0000747fd7fe1764  movaps xmm13, [rsp]
0000747fd7fe1769  add rsp, 0x30
0000747fd7fe176d  vmovaps xmm0, [rsp]
0000747fd7fe1772  vmovaps xmm1, [rsp+0x10]
0000747fd7fe1778  vmovaps xmm2, [rsp+0x20]
0000747fd7fe177e  vmovaps xmm3, [rsp+0x30]
0000747fd7fe1784  vmovaps xmm4, [rsp+0x40]
0000747fd7fe178a  vmovaps xmm5, [rsp+0x50]
0000747fd7fe1790  vmovaps xmm6, [rsp+0x60]
0000747fd7fe1796  vmovaps xmm7, [rsp+0x70]
0000747fd7fe179c  vmovaps xmm8, [rsp+0x80]
0000747fd7fe17a5  vmovaps xmm9, [rsp+0x90]
0000747fd7fe17ae  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe17b7  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe17c0  vmovaps xmm12, [rsp+0xC0]
0000747fd7fe17c9  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe17d2  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe17db  add rsp, 0xF0
0000747fd7fe17e2  pop r11
0000747fd7fe17e4  pop r10
0000747fd7fe17e6  pop r9
0000747fd7fe17e8  pop r8
0000747fd7fe17ea  pop rsi
0000747fd7fe17eb  pop rdi
0000747fd7fe17ec  pop rdx
0000747fd7fe17ed  pop rcx
0000747fd7fe17ee  pop rax
0000747fd7fe17ef  add rsp, 0x08
0000747fd7fe17f3  jmp 0x0000747FD7FDC820
0000747fd7fe17f8  sub rsp, 0x08
0000747fd7fe17fc  push rax
0000747fd7fe17fd  push rcx
0000747fd7fe17fe  push rdx
0000747fd7fe17ff  push rdi
0000747fd7fe1800  push rsi
0000747fd7fe1801  push r8
0000747fd7fe1803  push r9
0000747fd7fe1805  push r10
0000747fd7fe1807  push r11
0000747fd7fe1809  sub rsp, 0xF0
0000747fd7fe1810  vmovaps [rsp], xmm0
0000747fd7fe1815  vmovaps [rsp+0x10], xmm1
0000747fd7fe181b  vmovaps [rsp+0x20], xmm2
0000747fd7fe1821  vmovaps [rsp+0x30], xmm3
0000747fd7fe1827  vmovaps [rsp+0x40], xmm4
0000747fd7fe182d  vmovaps [rsp+0x50], xmm5
0000747fd7fe1833  vmovaps [rsp+0x60], xmm6
0000747fd7fe1839  vmovaps [rsp+0x70], xmm7
0000747fd7fe183f  vmovaps [rsp+0x80], xmm8
0000747fd7fe1848  vmovaps [rsp+0x90], xmm9
0000747fd7fe1851  vmovaps [rsp+0xA0], xmm10
0000747fd7fe185a  vmovaps [rsp+0xB0], xmm11
0000747fd7fe1863  vmovaps [rsp+0xC0], xmm12
0000747fd7fe186c  vmovaps [rsp+0xD0], xmm13
0000747fd7fe1875  vmovaps [rsp+0xE0], xmm15
0000747fd7fe187e  sub rsp, 0x30
0000747fd7fe1882  movaps [rsp], xmm14
0000747fd7fe1887  movaps [rsp+0x10], xmm1
0000747fd7fe188c  movaps [rsp+0x20], xmm7
0000747fd7fe1891  lea rdi, [rsp]
0000747fd7fe1895  mov esi, 0x00
0000747fd7fe189a  mov rax, 0x6055A0B6E530
0000747fd7fe18a4  call rax
0000747fd7fe18a6  movaps xmm14, [rsp]
0000747fd7fe18ab  add rsp, 0x30
0000747fd7fe18af  vmovaps xmm0, [rsp]
0000747fd7fe18b4  vmovaps xmm1, [rsp+0x10]
0000747fd7fe18ba  vmovaps xmm2, [rsp+0x20]
0000747fd7fe18c0  vmovaps xmm3, [rsp+0x30]
0000747fd7fe18c6  vmovaps xmm4, [rsp+0x40]
0000747fd7fe18cc  vmovaps xmm5, [rsp+0x50]
0000747fd7fe18d2  vmovaps xmm6, [rsp+0x60]
0000747fd7fe18d8  vmovaps xmm7, [rsp+0x70]
0000747fd7fe18de  vmovaps xmm8, [rsp+0x80]
0000747fd7fe18e7  vmovaps xmm9, [rsp+0x90]
0000747fd7fe18f0  vmovaps xmm10, [rsp+0xA0]
0000747fd7fe18f9  vmovaps xmm11, [rsp+0xB0]
0000747fd7fe1902  vmovaps xmm12, [rsp+0xC0]
0000747fd7fe190b  vmovaps xmm13, [rsp+0xD0]
0000747fd7fe1914  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe191d  add rsp, 0xF0
0000747fd7fe1924  pop r11
0000747fd7fe1926  pop r10
0000747fd7fe1928  pop r9
0000747fd7fe192a  pop r8
0000747fd7fe192c  pop rsi
0000747fd7fe192d  pop rdi
0000747fd7fe192e  pop rdx
0000747fd7fe192f  pop rcx
0000747fd7fe1930  pop rax
0000747fd7fe1931  add rsp, 0x08
0000747fd7fe1935  jmp 0x0000747FD7FDC843
0000747fd7fe193a  sub rsp, 0x08
0000747fd7fe193e  push rax
0000747fd7fe193f  push rcx
0000747fd7fe1940  push rdx
0000747fd7fe1941  push rdi
0000747fd7fe1942  push rsi
0000747fd7fe1943  push r8
0000747fd7fe1945  push r9
0000747fd7fe1947  push r10
0000747fd7fe1949  push r11
0000747fd7fe194b  sub rsp, 0xF0
0000747fd7fe1952  vmovaps [rsp], xmm0
0000747fd7fe1957  vmovaps [rsp+0x10], xmm2
0000747fd7fe195d  vmovaps [rsp+0x20], xmm3
0000747fd7fe1963  vmovaps [rsp+0x30], xmm4
0000747fd7fe1969  vmovaps [rsp+0x40], xmm5
0000747fd7fe196f  vmovaps [rsp+0x50], xmm6
0000747fd7fe1975  vmovaps [rsp+0x60], xmm7
0000747fd7fe197b  vmovaps [rsp+0x70], xmm8
0000747fd7fe1981  vmovaps [rsp+0x80], xmm9
0000747fd7fe198a  vmovaps [rsp+0x90], xmm10
0000747fd7fe1993  vmovaps [rsp+0xA0], xmm11
0000747fd7fe199c  vmovaps [rsp+0xB0], xmm12
0000747fd7fe19a5  vmovaps [rsp+0xC0], xmm13
0000747fd7fe19ae  vmovaps [rsp+0xD0], xmm14
0000747fd7fe19b7  vmovaps [rsp+0xE0], xmm15
0000747fd7fe19c0  sub rsp, 0x30
0000747fd7fe19c4  movaps [rsp], xmm1
0000747fd7fe19c8  movaps [rsp+0x10], xmm8
0000747fd7fe19ce  movaps [rsp+0x20], xmm9
0000747fd7fe19d4  lea rdi, [rsp]
0000747fd7fe19d8  mov esi, 0x00
0000747fd7fe19dd  mov rax, 0x6055A0B6E530
0000747fd7fe19e7  call rax
0000747fd7fe19e9  movaps xmm1, [rsp]
0000747fd7fe19ed  add rsp, 0x30
0000747fd7fe19f1  vmovaps xmm0, [rsp]
0000747fd7fe19f6  vmovaps xmm2, [rsp+0x10]
0000747fd7fe19fc  vmovaps xmm3, [rsp+0x20]
0000747fd7fe1a02  vmovaps xmm4, [rsp+0x30]
0000747fd7fe1a08  vmovaps xmm5, [rsp+0x40]
0000747fd7fe1a0e  vmovaps xmm6, [rsp+0x50]
0000747fd7fe1a14  vmovaps xmm7, [rsp+0x60]
0000747fd7fe1a1a  vmovaps xmm8, [rsp+0x70]
0000747fd7fe1a20  vmovaps xmm9, [rsp+0x80]
0000747fd7fe1a29  vmovaps xmm10, [rsp+0x90]
0000747fd7fe1a32  vmovaps xmm11, [rsp+0xA0]
0000747fd7fe1a3b  vmovaps xmm12, [rsp+0xB0]
0000747fd7fe1a44  vmovaps xmm13, [rsp+0xC0]
0000747fd7fe1a4d  vmovaps xmm14, [rsp+0xD0]
0000747fd7fe1a56  vmovaps xmm15, [rsp+0xE0]
0000747fd7fe1a5f  add rsp, 0xF0
0000747fd7fe1a66  pop r11
0000747fd7fe1a68  pop r10
0000747fd7fe1a6a  pop r9
0000747fd7fe1a6c  pop r8
0000747fd7fe1a6e  pop rsi
0000747fd7fe1a6f  pop rdi
0000747fd7fe1a70  pop rdx
0000747fd7fe1a71  pop rcx
0000747fd7fe1a72  pop rax
0000747fd7fe1a73  add rsp, 0x08
0000747fd7fe1a77  jmp 0x0000747FD7FDC865
0000747fd7fe1a7c  call 0x0000747FD7EE5940
0000747fd7fe1a81  jmp 0x0000747FD7FDC873
0000747fd7fe1a86  call 0x0000747FD7E0C380
0000747fd7fe1a8b  jmp 0x0000747FD7FDC87D
0000747fd7fe1a90  call 0x0000747FD7E0D600
0000747fd7fe1a95  jmp 0x0000747FD7FDC887
0000747fd7fe1a9a  call 0x0000747FD7DFF540
0000747fd7fe1a9f  jmp 0x0000747FD7FDC891
0000747fd7fe1aa4  int3
0000747fd7fe1aa5  nop [rax+rax*1], ax
0000747fd7fe1aae  nop
0000747fd7fe1ab0  mov rax, [r15+0xF8]
0000747fd7fe1ab7  lea r14, [rax+0x140]
0000747fd7fe1abe  mov r12, [r13+r14*1]
0000747fd7fe1ac3  mov [r15+0xE8], r12
0000747fd7fe1aca  lea r14, [rax+0x130]
0000747fd7fe1ad1  mov r12, [r13+r14*1]
0000747fd7fe1ad6  lea r14, [rax+0x138]
0000747fd7fe1add  mov r11, [r13+r14*1]
0000747fd7fe1ae2  movq xmm1, r12
0000747fd7fe1ae7  movq xmm15, r11
0000747fd7fe1aec  movq xmm1, xmm1
0000747fd7fe1af0  movq xmm1, xmm1
0000747fd7fe1af4  movaps [r15+0x1A0], xmm1
0000747fd7fe1afc  movq xmm15, xmm15
0000747fd7fe1b01  movq xmm15, xmm15
0000747fd7fe1b06  movaps [r15+0x190], xmm15
0000747fd7fe1b0e  lea r14, [rax+0x120]
0000747fd7fe1b15  mov r12, [r13+r14*1]
0000747fd7fe1b1a  lea r14, [rax+0x128]
0000747fd7fe1b21  mov r11, [r13+r14*1]
0000747fd7fe1b26  movq xmm1, r12
0000747fd7fe1b2b  movq xmm15, r11
0000747fd7fe1b30  movq xmm1, xmm1
0000747fd7fe1b34  movq xmm1, xmm1
0000747fd7fe1b38  movaps [r15+0x1C0], xmm1
0000747fd7fe1b40  movq xmm15, xmm15
0000747fd7fe1b45  movq xmm15, xmm15
0000747fd7fe1b4a  movaps [r15+0x1B0], xmm15
0000747fd7fe1b52  lea r14, [rax+0x110]
0000747fd7fe1b59  mov r12, [r13+r14*1]
0000747fd7fe1b5e  lea r14, [rax+0x118]
0000747fd7fe1b65  mov r11, [r13+r14*1]
0000747fd7fe1b6a  movq xmm1, r12
0000747fd7fe1b6f  movq xmm15, r11
0000747fd7fe1b74  movq xmm1, xmm1
0000747fd7fe1b78  movq xmm1, xmm1
0000747fd7fe1b7c  movaps [r15+0x1E0], xmm1
0000747fd7fe1b84  movq xmm15, xmm15
0000747fd7fe1b89  movq xmm15, xmm15
0000747fd7fe1b8e  movaps [r15+0x1D0], xmm15
0000747fd7fe1b96  lea r14, [rax+0x100]
0000747fd7fe1b9d  mov r12, [r13+r14*1]
0000747fd7fe1ba2  lea r14, [rax+0x108]
0000747fd7fe1ba9  mov r11, [r13+r14*1]
0000747fd7fe1bae  movq xmm1, r12
0000747fd7fe1bb3  movq xmm15, r11
0000747fd7fe1bb8  movq xmm1, xmm1
0000747fd7fe1bbc  movq xmm1, xmm1
0000747fd7fe1bc0  movaps [r15+0x200], xmm1
0000747fd7fe1bc8  movq xmm15, xmm15
0000747fd7fe1bcd  movq xmm15, xmm15
0000747fd7fe1bd2  movaps [r15+0x1F0], xmm15
0000747fd7fe1bda  mov qword ptr [r15+0x40], 0x430000
0000747fd7fe1be2  mov r14d, 0x430510
0000747fd7fe1be8  mov r12, [r13+r14*1]
0000747fd7fe1bed  movq xmm1, r12
0000747fd7fe1bf2  lea r14, [rax+0x150]
0000747fd7fe1bf9  mov [r15+0xF8], r14
0000747fd7fe1c00  mov rax, [r15+0x50]
0000747fd7fe1c04  movups xmm15, [r13+rax*1]
0000747fd7fe1c0a  movaps [r15+0x120], xmm15
0000747fd7fe1c12  mov qword ptr [r15+0x48], 0x10
0000747fd7fe1c1a  xor eax, eax
0000747fd7fe1c1c  mov r14d, 0x10
0000747fd7fe1c22  mov r12d, 0x200
0000747fd7fe1c28  cmp r14, r12
0000747fd7fe1c2b  cmc
0000747fd7fe1c2c  lahf
0000747fd7fe1c2d  seto al
0000747fd7fe1c30  mov [r15+0x108], eax
0000747fd7fe1c37  pextrq rax, xmm15, 0x01
0000747fd7fe1c3e  movq xmm14, rax
0000747fd7fe1c43  movaps [r15+0x130], xmm14
0000747fd7fe1c4b  movq rax, xmm1
0000747fd7fe1c50  movq r14, xmm15
0000747fd7fe1c55  vmovq xmm1, rax
0000747fd7fe1c5a  vmovq xmm15, r14
0000747fd7fe1c5f  movaps xmm13, xmm1
0000747fd7fe1c63  addsd xmm13, xmm15
0000747fd7fe1c68  ucomisd xmm13, xmm13
0000747fd7fe1c6d  jp 0x0000747FD7FE1D86
0000747fd7fe1c73  movq xmm13, xmm13
0000747fd7fe1c78  movq rax, xmm13
0000747fd7fe1c7d  movq r14, xmm14
0000747fd7fe1c82  vmovq xmm1, rax
0000747fd7fe1c87  vmovq xmm15, r14
0000747fd7fe1c8c  movaps xmm14, xmm1
0000747fd7fe1c90  addsd xmm14, xmm15
0000747fd7fe1c95  ucomisd xmm14, xmm14
0000747fd7fe1c9a  jp 0x0000747FD7FE1DCE
0000747fd7fe1ca0  movq xmm14, xmm14
0000747fd7fe1ca5  movaps [r15+0x110], xmm14
0000747fd7fe1cad  mov eax, [r15+0x108]
0000747fd7fe1cb4  sahf
0000747fd7fe1cb5  jnz 0x0000747FD7FE1CE7
0000747fd7fe1cb7  cmp dword ptr [r15+0x318], 0x00
0000747fd7fe1cbf  jz 0x0000747FD7FE1FE0
0000747fd7fe1cc5  nop [rax+rax*1], ax
0000747fd7fe1cce  nop [rax+rax*1], eax
0000747fd7fe1cd6  mov eax, 0x410490
0000747fd7fe1cdb  mov [r15+0x100], rax
0000747fd7fe1ce2  jmp 0x0000747FD7DFE110
0000747fd7fe1ce7  cmp dword ptr [r15+0x318], 0x00
0000747fd7fe1cef  jz 0x0000747FD7FE1E20
0000747fd7fe1cf5  nop [rax+rax*1], ax
0000747fd7fe1cfe  nop [rax+rax*1], eax
0000747fd7fe1d06  mov eax, 0x410474
0000747fd7fe1d0b  mov [r15+0x100], rax
0000747fd7fe1d12  jmp 0x0000747FD7DFE110
0000747fd7fe1d17  int3
0000747fd7fe1d18  call 0x0000747FD7EE27E0
0000747fd7fe1d1d  jmp 0x0000747FD7FE1AC3
0000747fd7fe1d22  call 0x0000747FD7EE27E0
0000747fd7fe1d27  jmp 0x0000747FD7FE1AD6
0000747fd7fe1d2c  call 0x0000747FD7EE1570
0000747fd7fe1d31  jmp 0x0000747FD7FE1AE2
0000747fd7fe1d36  call 0x0000747FD7EE27E0
0000747fd7fe1d3b  jmp 0x0000747FD7FE1B1A
0000747fd7fe1d40  call 0x0000747FD7EE1570
0000747fd7fe1d45  jmp 0x0000747FD7FE1B26
0000747fd7fe1d4a  call 0x0000747FD7EE27E0
0000747fd7fe1d4f  jmp 0x0000747FD7FE1B5E
0000747fd7fe1d54  call 0x0000747FD7EE1570
0000747fd7fe1d59  jmp 0x0000747FD7FE1B6A
0000747fd7fe1d5e  call 0x0000747FD7EE27E0
0000747fd7fe1d63  jmp 0x0000747FD7FE1BA2
0000747fd7fe1d68  call 0x0000747FD7EE1570
0000747fd7fe1d6d  jmp 0x0000747FD7FE1BAE
0000747fd7fe1d72  call 0x0000747FD7EE27E0
0000747fd7fe1d77  jmp 0x0000747FD7FE1BED
0000747fd7fe1d7c  call 0x0000747FD7E0E760
0000747fd7fe1d81  jmp 0x0000747FD7FE1C0A
0000747fd7fe1d86  ucomisd xmm1, xmm15
0000747fd7fe1d8b  jp 0x0000747FD7FE1D9A
0000747fd7fe1d8d  movaps xmm13, [0x0000747FD7BFE060]
0000747fd7fe1d95  jmp 0x0000747FD7FE1C73
0000747fd7fe1d9a  vxorps xmm0, xmm1, xmm15
0000747fd7fe1d9f  pextrw eax, xmm0, 0x03
0000747fd7fe1da4  and eax, 0x7FF8
0000747fd7fe1da9  cmp eax, 0x08
0000747fd7fe1dac  jnz 0x0000747FD7FE1C73
0000747fd7fe1db2  movq rax, xmm15
0000747fd7fe1db7  shl rax, 0x0D
0000747fd7fe1dbb  jbe 0x0000747FD7FE1C73
0000747fd7fe1dc1  vorps xmm13, xmm15, [0x0000747FD7BFE070]
0000747fd7fe1dc9  jmp 0x0000747FD7FE1C73
0000747fd7fe1dce  ucomisd xmm1, xmm15
0000747fd7fe1dd3  jp 0x0000747FD7FE1DE2
0000747fd7fe1dd5  movaps xmm14, [0x0000747FD7BFE060]
0000747fd7fe1ddd  jmp 0x0000747FD7FE1CA0
0000747fd7fe1de2  vxorps xmm0, xmm1, xmm15
0000747fd7fe1de7  pextrw eax, xmm0, 0x03
0000747fd7fe1dec  and eax, 0x7FF8
0000747fd7fe1df1  cmp eax, 0x08
0000747fd7fe1df4  jnz 0x0000747FD7FE1CA0
0000747fd7fe1dfa  movq rax, xmm15
0000747fd7fe1dff  shl rax, 0x0D
0000747fd7fe1e03  jbe 0x0000747FD7FE1CA0
0000747fd7fe1e09  vorps xmm14, xmm15, [0x0000747FD7BFE070]
0000747fd7fe1e11  jmp 0x0000747FD7FE1CA0
0000747fd7fe1e16  int3
0000747fd7fe1e17  nop [rax+rax*1], ax
0000747fd7fe1e20  mov rax, [r15+0x48]
0000747fd7fe1e24  mov r14, [r15+0x50]
0000747fd7fe1e28  lea r12, [r14+rax*1]
0000747fd7fe1e2c  movups xmm1, [r13+r12*1]
0000747fd7fe1e32  movaps [r15+0x120], xmm1
0000747fd7fe1e3a  lea r14, [rax+0x10]
0000747fd7fe1e3e  mov [r15+0x48], r14
0000747fd7fe1e42  xor eax, eax
0000747fd7fe1e44  mov r12d, 0x200
0000747fd7fe1e4a  cmp r14, r12
0000747fd7fe1e4d  cmc
0000747fd7fe1e4e  lahf
0000747fd7fe1e4f  seto al
0000747fd7fe1e52  mov [r15+0x108], eax
0000747fd7fe1e59  pextrq rax, xmm1, 0x01
0000747fd7fe1e60  movq xmm15, rax
0000747fd7fe1e65  movaps [r15+0x130], xmm15
0000747fd7fe1e6d  movaps xmm14, [r15+0x110]
0000747fd7fe1e75  movq rax, xmm14
0000747fd7fe1e7a  movq r14, xmm1
0000747fd7fe1e7f  vmovq xmm1, rax
0000747fd7fe1e84  vmovq xmm14, r14
0000747fd7fe1e89  movaps xmm13, xmm1
0000747fd7fe1e8d  addsd xmm13, xmm14
0000747fd7fe1e92  ucomisd xmm13, xmm13
0000747fd7fe1e97  jp 0x0000747FD7FE1F4C
0000747fd7fe1e9d  movq xmm13, xmm13
0000747fd7fe1ea2  movq rax, xmm13
0000747fd7fe1ea7  movq r14, xmm15
0000747fd7fe1eac  vmovq xmm1, rax
0000747fd7fe1eb1  vmovq xmm15, r14
0000747fd7fe1eb6  movaps xmm14, xmm1
0000747fd7fe1eba  addsd xmm14, xmm15
0000747fd7fe1ebf  ucomisd xmm14, xmm14
0000747fd7fe1ec4  jp 0x0000747FD7FE1F94
0000747fd7fe1eca  movq xmm14, xmm14
0000747fd7fe1ecf  movaps [r15+0x110], xmm14
0000747fd7fe1ed7  mov eax, [r15+0x108]
0000747fd7fe1ede  sahf
0000747fd7fe1edf  jnz 0x0000747FD7FE1F11
0000747fd7fe1ee1  cmp dword ptr [r15+0x318], 0x00
0000747fd7fe1ee9  jz 0x0000747FD7FE1FE0
0000747fd7fe1eef  nop [rax+rax*1], ax
0000747fd7fe1ef8  nop [rax+rax*1], eax
0000747fd7fe1f00  mov eax, 0x410490
0000747fd7fe1f05  mov [r15+0x100], rax
0000747fd7fe1f0c  jmp 0x0000747FD7DFE110
0000747fd7fe1f11  cmp dword ptr [r15+0x318], 0x00
0000747fd7fe1f19  jz 0x0000747FD7FE1E20
0000747fd7fe1f1f  nop [rax+rax*1], ax
0000747fd7fe1f28  nop [rax+rax*1], eax
0000747fd7fe1f30  mov eax, 0x410474
0000747fd7fe1f35  mov [r15+0x100], rax
0000747fd7fe1f3c  jmp 0x0000747FD7DFE110
0000747fd7fe1f41  int3
0000747fd7fe1f42  call 0x0000747FD7EB52F0
0000747fd7fe1f47  jmp 0x0000747FD7FE1E32
0000747fd7fe1f4c  ucomisd xmm1, xmm14
0000747fd7fe1f51  jp 0x0000747FD7FE1F60
0000747fd7fe1f53  movaps xmm13, [0x0000747FD7BFE060]
0000747fd7fe1f5b  jmp 0x0000747FD7FE1E9D
0000747fd7fe1f60  vxorps xmm0, xmm1, xmm14
0000747fd7fe1f65  pextrw eax, xmm0, 0x03
0000747fd7fe1f6a  and eax, 0x7FF8
0000747fd7fe1f6f  cmp eax, 0x08
0000747fd7fe1f72  jnz 0x0000747FD7FE1E9D
0000747fd7fe1f78  movq rax, xmm14
0000747fd7fe1f7d  shl rax, 0x0D
0000747fd7fe1f81  jbe 0x0000747FD7FE1E9D
0000747fd7fe1f87  vorps xmm13, xmm14, [0x0000747FD7BFE070]
0000747fd7fe1f8f  jmp 0x0000747FD7FE1E9D
0000747fd7fe1f94  ucomisd xmm1, xmm15
0000747fd7fe1f99  jp 0x0000747FD7FE1FA8
0000747fd7fe1f9b  movaps xmm14, [0x0000747FD7BFE060]
0000747fd7fe1fa3  jmp 0x0000747FD7FE1ECA
0000747fd7fe1fa8  vxorps xmm0, xmm1, xmm15
0000747fd7fe1fad  pextrw eax, xmm0, 0x03
0000747fd7fe1fb2  and eax, 0x7FF8
0000747fd7fe1fb7  cmp eax, 0x08
0000747fd7fe1fba  jnz 0x0000747FD7FE1ECA
0000747fd7fe1fc0  movq rax, xmm15
0000747fd7fe1fc5  shl rax, 0x0D
0000747fd7fe1fc9  jbe 0x0000747FD7FE1ECA
0000747fd7fe1fcf  vorps xmm14, xmm15, [0x0000747FD7BFE070]
0000747fd7fe1fd7  jmp 0x0000747FD7FE1ECA
0000747fd7fe1fdc  int3
0000747fd7fe1fdd  nop [rax], eax
0000747fd7fe1fe0  mov rax, [r15+0x40]
0000747fd7fe1fe4  lea r14, [rax+0x510]
0000747fd7fe1feb  movaps xmm1, [r15+0x110]
0000747fd7fe1ff3  movq rax, xmm1
0000747fd7fe1ff8  mov [r13+r14*1], rax
0000747fd7fe1ffd  mov rax, [r15+0xF0]
0000747fd7fe2004  mov [r15+0x100], rax
0000747fd7fe200b  jmp 0x0000747FD7FCE5C0
0000747fd7fe2010  int3
0000747fd7fe2011  call 0x0000747FD7ED5EB0
0000747fd7fe2016  jmp 0x0000747FD7FE1FFD
0000747fd7fe201b  int3
0000747fd7fe201c  nop [rax], eax
0000747fd7fe2020  mov qword ptr [r15+0x100], 0x04
0000747fd7fe202b  mov esi, 0x00
0000747fd7fe2030  mov edx, 0x09
0000747fd7fe2035  mov rdi, 0x7FFD9F92F810
0000747fd7fe203f  mov rax, 0x6055A0A01970
0000747fd7fe2049  call rax
0000747fd7fe204b  cmp dword ptr [r15+0x318], 0x00
0000747fd7fe2053  jnz 0x0000747FD7DFE110
0000747fd7fe2059  jmp 0x0000747FD7DFE0A0
0000747fd7fe205e  int3
0000747fd7fe205f  int3
