000076c1d9dce69b  nop [rax+rax*1], eax
000076c1d9dce6a0  vmovaps xmm1, [0x000076C1D99FE010]
000076c1d9dce6a8  movq xmm1, xmm1
000076c1d9dce6ac  movaps [r15+0x110], xmm1
000076c1d9dce6b4  vmovaps xmm1, [0x000076C1D99FE020]
000076c1d9dce6bc  movq xmm1, xmm1
000076c1d9dce6c0  movaps [r15+0x120], xmm1
000076c1d9dce6c8  mov eax, 0x4204C0
000076c1d9dce6cd  mov r14, [r13+rax*1]
000076c1d9dce6d2  movq xmm1, r14
000076c1d9dce6d7  movaps [r15+0x130], xmm1
000076c1d9dce6df  vmovaps xmm1, [0x000076C1D99FE030]
000076c1d9dce6e7  vpbroadcastq xmm1, xmm1
000076c1d9dce6ec  movaps [r15+0x140], xmm1
000076c1d9dce6f4  mov qword ptr [r15+0x40], 0x02
000076c1d9dce6fc  vmovaps xmm15, [0x000076C1D99FE040]
000076c1d9dce704  movq xmm15, xmm15
000076c1d9dce709  movaps [r15+0x150], xmm15
000076c1d9dce711  mov qword ptr [r15+0x58], 0x420000
000076c1d9dce719  vmovaps xmm15, [0x000076C1D99FE050]
000076c1d9dce721  vpbroadcastq xmm15, xmm15
000076c1d9dce726  movaps [r15+0x160], xmm15
000076c1d9dce72e  mov rax, [r15+0x40]
000076c1d9dce732  vmovq xmm14, rax
000076c1d9dce737  vpbroadcastq xmm14, xmm14
000076c1d9dce73c  movaps [r15+0x170], xmm14
000076c1d9dce744  mov eax, 0x4204D0
000076c1d9dce749  movups xmm13, [r13+rax*1]
000076c1d9dce74f  mov qword ptr [r15+0x40], 0x430518
000076c1d9dce757  mov qword ptr [r15+0x50], 0x430720
000076c1d9dce75f  vpmovqd xmm12, xmm13
000076c1d9dce765  pxor xmm11, xmm11
000076c1d9dce76a  punpcklqdq xmm12, xmm11
000076c1d9dce76f  movaps [r15+0x210], xmm12
000076c1d9dce777  movq xmm12, qword ptr [r15+0x120]
000076c1d9dce780  movq xmm11, qword ptr [r15+0x130]
000076c1d9dce789  psubd xmm12, xmm11
000076c1d9dce78e  movq xmm12, xmm12
000076c1d9dce793  paddq xmm13, xmm14
000076c1d9dce798  movaps [r15+0x180], xmm13
000076c1d9dce7a0  movq xmm14, qword ptr [r15+0x150]
000076c1d9dce7a9  paddd xmm11, xmm14
000076c1d9dce7ae  movq xmm11, xmm11
000076c1d9dce7b3  movq xmm11, xmm11
000076c1d9dce7b8  movaps [r15+0x130], xmm11
000076c1d9dce7c0  pmovzxdq xmm12, xmm12
000076c1d9dce7c6  psllq xmm12, 0x00
000076c1d9dce7cc  movq xmm14, qword ptr [r15+0x210]
000076c1d9dce7d5  movq xmm13, qword ptr [r15+0x110]
000076c1d9dce7de  paddd xmm14, xmm13
000076c1d9dce7e3  movq xmm14, xmm14
000076c1d9dce7e8  vcvtuqq2pd xmm12, xmm12
000076c1d9dce7ee  pmovzxdq xmm14, xmm14
000076c1d9dce7f4  psllq xmm14, 0x00
000076c1d9dce7fa  vcvtuqq2pd xmm14, xmm14
000076c1d9dce800  movaps xmm13, xmm12
000076c1d9dce804  mulpd xmm13, xmm1
000076c1d9dce809  vcmppd xmm11, xmm13, xmm13, 0x03
000076c1d9dce80f  ptest xmm11, xmm11
000076c1d9dce815  jnz 0x000076C1D9DCE8FF
000076c1d9dce81b  movaps [r15+0x220], xmm13
000076c1d9dce823  mov eax, 0x430720
000076c1d9dce828  movups [r13+rax*1], xmm13
000076c1d9dce82e  movaps xmm1, xmm14
000076c1d9dce832  mulpd xmm1, xmm15
000076c1d9dce837  vcmppd xmm13, xmm1, xmm1, 0x03
000076c1d9dce83c  ptest xmm13, xmm13
000076c1d9dce842  jnz 0x000076C1D9DCEA4C
000076c1d9dce848  movaps [r15+0x210], xmm1
000076c1d9dce850  mov eax, 0x430518
000076c1d9dce855  movups [r13+rax*1], xmm1
000076c1d9dce85b  mov qword ptr [r15+0x48], 0x10
000076c1d9dce863  xor eax, eax
000076c1d9dce865  mov r14d, 0x10
000076c1d9dce86b  mov r12d, 0x200
000076c1d9dce871  cmp r14, r12
000076c1d9dce874  cmc
000076c1d9dce875  lahf
000076c1d9dce876  seto al
000076c1d9dce879  mov [r15+0x108], eax
000076c1d9dce880  mov eax, [r15+0x108]
000076c1d9dce887  sahf
000076c1d9dce888  jnz 0x000076C1D9DCE8BA
000076c1d9dce88a  cmp dword ptr [r15+0x318], 0x00
000076c1d9dce892  jz 0x000076C1D9DCEFF0
000076c1d9dce898  nop [rax+rax*1], ax
000076c1d9dce8a1  nop [rax+rax*1], eax
000076c1d9dce8a9  mov eax, 0x4101EC
000076c1d9dce8ae  mov [r15+0x100], rax
000076c1d9dce8b5  jmp 0x000076C1D9BFE110
000076c1d9dce8ba  cmp dword ptr [r15+0x318], 0x00
000076c1d9dce8c2  jz 0x000076C1D9DCEBA0
000076c1d9dce8c8  nop [rax+rax*1], ax
000076c1d9dce8d1  nop [rax+rax*1], eax
000076c1d9dce8d9  mov eax, 0x4101AC
000076c1d9dce8de  mov [r15+0x100], rax
000076c1d9dce8e5  jmp 0x000076C1D9BFE110
000076c1d9dce8ea  int3
000076c1d9dce8eb  call 0x000076C1D9C0DC20
000076c1d9dce8f0  jmp 0x000076C1D9DCE6D2
000076c1d9dce8f5  call 0x000076C1D9C0C260
000076c1d9dce8fa  jmp 0x000076C1D9DCE74F
000076c1d9dce8ff  sub rsp, 0x08
000076c1d9dce903  push rax
000076c1d9dce904  push rcx
000076c1d9dce905  push rdx
000076c1d9dce906  push rdi
000076c1d9dce907  push rsi
000076c1d9dce908  push r8
000076c1d9dce90a  push r9
000076c1d9dce90c  push r10
000076c1d9dce90e  push r11
000076c1d9dce910  sub rsp, 0xF0
000076c1d9dce917  vmovaps [rsp], xmm0
000076c1d9dce91c  vmovaps [rsp+0x10], xmm1
000076c1d9dce922  vmovaps [rsp+0x20], xmm2
000076c1d9dce928  vmovaps [rsp+0x30], xmm3
000076c1d9dce92e  vmovaps [rsp+0x40], xmm4
000076c1d9dce934  vmovaps [rsp+0x50], xmm5
000076c1d9dce93a  vmovaps [rsp+0x60], xmm6
000076c1d9dce940  vmovaps [rsp+0x70], xmm7
000076c1d9dce946  vmovaps [rsp+0x80], xmm8
000076c1d9dce94f  vmovaps [rsp+0x90], xmm9
000076c1d9dce958  vmovaps [rsp+0xA0], xmm10
000076c1d9dce961  vmovaps [rsp+0xB0], xmm11
000076c1d9dce96a  vmovaps [rsp+0xC0], xmm12
000076c1d9dce973  vmovaps [rsp+0xD0], xmm14
000076c1d9dce97c  vmovaps [rsp+0xE0], xmm15
000076c1d9dce985  sub rsp, 0x30
000076c1d9dce989  movaps [rsp], xmm13
000076c1d9dce98e  movaps [rsp+0x10], xmm12
000076c1d9dce994  movaps [rsp+0x20], xmm1
000076c1d9dce999  lea rdi, [rsp]
000076c1d9dce99d  mov esi, 0x00
000076c1d9dce9a2  mov rax, 0x5EA58B9E0530
000076c1d9dce9ac  call rax
000076c1d9dce9ae  movaps xmm13, [rsp]
000076c1d9dce9b3  add rsp, 0x30
000076c1d9dce9b7  vmovaps xmm0, [rsp]
000076c1d9dce9bc  vmovaps xmm1, [rsp+0x10]
000076c1d9dce9c2  vmovaps xmm2, [rsp+0x20]
000076c1d9dce9c8  vmovaps xmm3, [rsp+0x30]
000076c1d9dce9ce  vmovaps xmm4, [rsp+0x40]
000076c1d9dce9d4  vmovaps xmm5, [rsp+0x50]
000076c1d9dce9da  vmovaps xmm6, [rsp+0x60]
000076c1d9dce9e0  vmovaps xmm7, [rsp+0x70]
000076c1d9dce9e6  vmovaps xmm8, [rsp+0x80]
000076c1d9dce9ef  vmovaps xmm9, [rsp+0x90]
000076c1d9dce9f8  vmovaps xmm10, [rsp+0xA0]
000076c1d9dcea01  vmovaps xmm11, [rsp+0xB0]
000076c1d9dcea0a  vmovaps xmm12, [rsp+0xC0]
000076c1d9dcea13  vmovaps xmm14, [rsp+0xD0]
000076c1d9dcea1c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dcea25  add rsp, 0xF0
000076c1d9dcea2c  pop r11
000076c1d9dcea2e  pop r10
000076c1d9dcea30  pop r9
000076c1d9dcea32  pop r8
000076c1d9dcea34  pop rsi
000076c1d9dcea35  pop rdi
000076c1d9dcea36  pop rdx
000076c1d9dcea37  pop rcx
000076c1d9dcea38  pop rax
000076c1d9dcea39  add rsp, 0x08
000076c1d9dcea3d  jmp 0x000076C1D9DCE81B
000076c1d9dcea42  call 0x000076C1D9C0C380
000076c1d9dcea47  jmp 0x000076C1D9DCE82E
000076c1d9dcea4c  sub rsp, 0x08
000076c1d9dcea50  push rax
000076c1d9dcea51  push rcx
000076c1d9dcea52  push rdx
000076c1d9dcea53  push rdi
000076c1d9dcea54  push rsi
000076c1d9dcea55  push r8
000076c1d9dcea57  push r9
000076c1d9dcea59  push r10
000076c1d9dcea5b  push r11
000076c1d9dcea5d  sub rsp, 0xF0
000076c1d9dcea64  vmovaps [rsp], xmm0
000076c1d9dcea69  vmovaps [rsp+0x10], xmm2
000076c1d9dcea6f  vmovaps [rsp+0x20], xmm3
000076c1d9dcea75  vmovaps [rsp+0x30], xmm4
000076c1d9dcea7b  vmovaps [rsp+0x40], xmm5
000076c1d9dcea81  vmovaps [rsp+0x50], xmm6
000076c1d9dcea87  vmovaps [rsp+0x60], xmm7
000076c1d9dcea8d  vmovaps [rsp+0x70], xmm8
000076c1d9dcea93  vmovaps [rsp+0x80], xmm9
000076c1d9dcea9c  vmovaps [rsp+0x90], xmm10
000076c1d9dceaa5  vmovaps [rsp+0xA0], xmm11
000076c1d9dceaae  vmovaps [rsp+0xB0], xmm12
000076c1d9dceab7  vmovaps [rsp+0xC0], xmm13
000076c1d9dceac0  vmovaps [rsp+0xD0], xmm14
000076c1d9dceac9  vmovaps [rsp+0xE0], xmm15
000076c1d9dcead2  sub rsp, 0x30
000076c1d9dcead6  movaps [rsp], xmm1
000076c1d9dceada  movaps [rsp+0x10], xmm14
000076c1d9dceae0  movaps [rsp+0x20], xmm15
000076c1d9dceae6  lea rdi, [rsp]
000076c1d9dceaea  mov esi, 0x00
000076c1d9dceaef  mov rax, 0x5EA58B9E0530
000076c1d9dceaf9  call rax
000076c1d9dceafb  movaps xmm1, [rsp]
000076c1d9dceaff  add rsp, 0x30
000076c1d9dceb03  vmovaps xmm0, [rsp]
000076c1d9dceb08  vmovaps xmm2, [rsp+0x10]
000076c1d9dceb0e  vmovaps xmm3, [rsp+0x20]
000076c1d9dceb14  vmovaps xmm4, [rsp+0x30]
000076c1d9dceb1a  vmovaps xmm5, [rsp+0x40]
000076c1d9dceb20  vmovaps xmm6, [rsp+0x50]
000076c1d9dceb26  vmovaps xmm7, [rsp+0x60]
000076c1d9dceb2c  vmovaps xmm8, [rsp+0x70]
000076c1d9dceb32  vmovaps xmm9, [rsp+0x80]
000076c1d9dceb3b  vmovaps xmm10, [rsp+0x90]
000076c1d9dceb44  vmovaps xmm11, [rsp+0xA0]
000076c1d9dceb4d  vmovaps xmm12, [rsp+0xB0]
000076c1d9dceb56  vmovaps xmm13, [rsp+0xC0]
000076c1d9dceb5f  vmovaps xmm14, [rsp+0xD0]
000076c1d9dceb68  vmovaps xmm15, [rsp+0xE0]
000076c1d9dceb71  add rsp, 0xF0
000076c1d9dceb78  pop r11
000076c1d9dceb7a  pop r10
000076c1d9dceb7c  pop r9
000076c1d9dceb7e  pop r8
000076c1d9dceb80  pop rsi
000076c1d9dceb81  pop rdi
000076c1d9dceb82  pop rdx
000076c1d9dceb83  pop rcx
000076c1d9dceb84  pop rax
000076c1d9dceb85  add rsp, 0x08
000076c1d9dceb89  jmp 0x000076C1D9DCE848
000076c1d9dceb8e  call 0x000076C1D9BFF540
000076c1d9dceb93  jmp 0x000076C1D9DCE85B
000076c1d9dceb98  int3
000076c1d9dceb99  nop [rax], eax
000076c1d9dceba0  movaps xmm1, [r15+0x180]
000076c1d9dceba8  vpmovqd xmm15, xmm1
000076c1d9dcebae  pxor xmm14, xmm14
000076c1d9dcebb3  punpcklqdq xmm15, xmm14
000076c1d9dcebb8  movaps [r15+0x210], xmm15
000076c1d9dcebc0  movq xmm15, qword ptr [r15+0x120]
000076c1d9dcebc9  movq xmm14, qword ptr [r15+0x130]
000076c1d9dcebd2  psubd xmm15, xmm14
000076c1d9dcebd7  movq xmm15, xmm15
000076c1d9dcebdc  movaps xmm13, [r15+0x170]
000076c1d9dcebe4  paddq xmm1, xmm13
000076c1d9dcebe9  movaps [r15+0x180], xmm1
000076c1d9dcebf1  movq xmm1, qword ptr [r15+0x150]
000076c1d9dcebfa  paddd xmm14, xmm1
000076c1d9dcebff  movq xmm14, xmm14
000076c1d9dcec04  movq xmm14, xmm14
000076c1d9dcec09  movaps [r15+0x130], xmm14
000076c1d9dcec11  pmovzxdq xmm15, xmm15
000076c1d9dcec17  psllq xmm15, 0x00
000076c1d9dcec1d  movq xmm1, qword ptr [r15+0x210]
000076c1d9dcec26  movq xmm14, qword ptr [r15+0x110]
000076c1d9dcec2f  paddd xmm1, xmm14
000076c1d9dcec34  movq xmm1, xmm1
000076c1d9dcec38  vcvtuqq2pd xmm15, xmm15
000076c1d9dcec3e  pmovzxdq xmm1, xmm1
000076c1d9dcec43  psllq xmm1, 0x00
000076c1d9dcec48  vcvtuqq2pd xmm1, xmm1
000076c1d9dcec4e  movaps xmm14, [r15+0x140]
000076c1d9dcec56  movaps xmm13, xmm15
000076c1d9dcec5a  mulpd xmm13, xmm14
000076c1d9dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000076c1d9dcec65  ptest xmm12, xmm12
000076c1d9dcec6b  jnz 0x000076C1D9DCED4E
000076c1d9dcec71  movaps [r15+0x220], xmm13
000076c1d9dcec79  mov rax, [r15+0x48]
000076c1d9dcec7d  mov r14, [r15+0x50]
000076c1d9dcec81  lea r12, [r14+rax*1]
000076c1d9dcec85  movups [r13+r12*1], xmm13
000076c1d9dcec8b  movaps xmm15, [r15+0x160]
000076c1d9dcec93  movaps xmm14, xmm1
000076c1d9dcec97  mulpd xmm14, xmm15
000076c1d9dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000076c1d9dceca2  ptest xmm13, xmm13
000076c1d9dceca8  jnz 0x000076C1D9DCEE9C
000076c1d9dcecae  movaps [r15+0x210], xmm14
000076c1d9dcecb6  mov r14, [r15+0x40]
000076c1d9dcecba  lea r12, [r14+rax*1]
000076c1d9dcecbe  movups [r13+r12*1], xmm14
000076c1d9dcecc4  lea r14, [rax+0x10]
000076c1d9dcecc8  mov [r15+0x48], r14
000076c1d9dceccc  xor eax, eax
000076c1d9dcecce  mov r12d, 0x200
000076c1d9dcecd4  cmp r14, r12
000076c1d9dcecd7  cmc
000076c1d9dcecd8  lahf
000076c1d9dcecd9  seto al
000076c1d9dcecdc  mov [r15+0x108], eax
000076c1d9dcece3  mov eax, [r15+0x108]
000076c1d9dcecea  sahf
000076c1d9dceceb  jnz 0x000076C1D9DCED1D
000076c1d9dceced  cmp dword ptr [r15+0x318], 0x00
000076c1d9dcecf5  jz 0x000076C1D9DCEFF0
000076c1d9dcecfb  nop [rax+rax*1], ax
000076c1d9dced04  nop [rax+rax*1], eax
000076c1d9dced0c  mov eax, 0x4101EC
000076c1d9dced11  mov [r15+0x100], rax
000076c1d9dced18  jmp 0x000076C1D9BFE110
000076c1d9dced1d  cmp dword ptr [r15+0x318], 0x00
000076c1d9dced25  jz 0x000076C1D9DCEBA0
000076c1d9dced2b  nop [rax+rax*1], ax
000076c1d9dced34  nop [rax+rax*1], eax
000076c1d9dced3c  mov eax, 0x4101AC
000076c1d9dced41  mov [r15+0x100], rax
000076c1d9dced48  jmp 0x000076C1D9BFE110
000076c1d9dced4d  int3
000076c1d9dced4e  sub rsp, 0x08
000076c1d9dced52  push rax
000076c1d9dced53  push rcx
000076c1d9dced54  push rdx
000076c1d9dced55  push rdi
000076c1d9dced56  push rsi
000076c1d9dced57  push r8
000076c1d9dced59  push r9
000076c1d9dced5b  push r10
000076c1d9dced5d  push r11
000076c1d9dced5f  sub rsp, 0xF0
000076c1d9dced66  vmovaps [rsp], xmm0
000076c1d9dced6b  vmovaps [rsp+0x10], xmm1
000076c1d9dced71  vmovaps [rsp+0x20], xmm2
000076c1d9dced77  vmovaps [rsp+0x30], xmm3
000076c1d9dced7d  vmovaps [rsp+0x40], xmm4
000076c1d9dced83  vmovaps [rsp+0x50], xmm5
000076c1d9dced89  vmovaps [rsp+0x60], xmm6
000076c1d9dced8f  vmovaps [rsp+0x70], xmm7
000076c1d9dced95  vmovaps [rsp+0x80], xmm8
000076c1d9dced9e  vmovaps [rsp+0x90], xmm9
000076c1d9dceda7  vmovaps [rsp+0xA0], xmm10
000076c1d9dcedb0  vmovaps [rsp+0xB0], xmm11
000076c1d9dcedb9  vmovaps [rsp+0xC0], xmm12
000076c1d9dcedc2  vmovaps [rsp+0xD0], xmm14
000076c1d9dcedcb  vmovaps [rsp+0xE0], xmm15
000076c1d9dcedd4  sub rsp, 0x30
000076c1d9dcedd8  movaps [rsp], xmm13
000076c1d9dceddd  movaps [rsp+0x10], xmm15
000076c1d9dcede3  movaps [rsp+0x20], xmm14
000076c1d9dcede9  lea rdi, [rsp]
000076c1d9dceded  mov esi, 0x00
000076c1d9dcedf2  mov rax, 0x5EA58B9E0530
000076c1d9dcedfc  call rax
000076c1d9dcedfe  movaps xmm13, [rsp]
000076c1d9dcee03  add rsp, 0x30
000076c1d9dcee07  vmovaps xmm0, [rsp]
000076c1d9dcee0c  vmovaps xmm1, [rsp+0x10]
000076c1d9dcee12  vmovaps xmm2, [rsp+0x20]
000076c1d9dcee18  vmovaps xmm3, [rsp+0x30]
000076c1d9dcee1e  vmovaps xmm4, [rsp+0x40]
000076c1d9dcee24  vmovaps xmm5, [rsp+0x50]
000076c1d9dcee2a  vmovaps xmm6, [rsp+0x60]
000076c1d9dcee30  vmovaps xmm7, [rsp+0x70]
000076c1d9dcee36  vmovaps xmm8, [rsp+0x80]
000076c1d9dcee3f  vmovaps xmm9, [rsp+0x90]
000076c1d9dcee48  vmovaps xmm10, [rsp+0xA0]
000076c1d9dcee51  vmovaps xmm11, [rsp+0xB0]
000076c1d9dcee5a  vmovaps xmm12, [rsp+0xC0]
000076c1d9dcee63  vmovaps xmm14, [rsp+0xD0]
000076c1d9dcee6c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dcee75  add rsp, 0xF0
000076c1d9dcee7c  pop r11
000076c1d9dcee7e  pop r10
000076c1d9dcee80  pop r9
000076c1d9dcee82  pop r8
000076c1d9dcee84  pop rsi
000076c1d9dcee85  pop rdi
000076c1d9dcee86  pop rdx
000076c1d9dcee87  pop rcx
000076c1d9dcee88  pop rax
000076c1d9dcee89  add rsp, 0x08
000076c1d9dcee8d  jmp 0x000076C1D9DCEC71
000076c1d9dcee92  call 0x000076C1D9CC2240
000076c1d9dcee97  jmp 0x000076C1D9DCEC8B
000076c1d9dcee9c  sub rsp, 0x08
000076c1d9dceea0  push rax
000076c1d9dceea1  push rcx
000076c1d9dceea2  push rdx
000076c1d9dceea3  push rdi
000076c1d9dceea4  push rsi
000076c1d9dceea5  push r8
000076c1d9dceea7  push r9
000076c1d9dceea9  push r10
000076c1d9dceeab  push r11
000076c1d9dceead  sub rsp, 0xF0
000076c1d9dceeb4  vmovaps [rsp], xmm0
000076c1d9dceeb9  vmovaps [rsp+0x10], xmm1
000076c1d9dceebf  vmovaps [rsp+0x20], xmm2
000076c1d9dceec5  vmovaps [rsp+0x30], xmm3
000076c1d9dceecb  vmovaps [rsp+0x40], xmm4
000076c1d9dceed1  vmovaps [rsp+0x50], xmm5
000076c1d9dceed7  vmovaps [rsp+0x60], xmm6
000076c1d9dceedd  vmovaps [rsp+0x70], xmm7
000076c1d9dceee3  vmovaps [rsp+0x80], xmm8
000076c1d9dceeec  vmovaps [rsp+0x90], xmm9
000076c1d9dceef5  vmovaps [rsp+0xA0], xmm10
000076c1d9dceefe  vmovaps [rsp+0xB0], xmm11
000076c1d9dcef07  vmovaps [rsp+0xC0], xmm12
000076c1d9dcef10  vmovaps [rsp+0xD0], xmm13
000076c1d9dcef19  vmovaps [rsp+0xE0], xmm15
000076c1d9dcef22  sub rsp, 0x30
000076c1d9dcef26  movaps [rsp], xmm14
000076c1d9dcef2b  movaps [rsp+0x10], xmm1
000076c1d9dcef30  movaps [rsp+0x20], xmm15
000076c1d9dcef36  lea rdi, [rsp]
000076c1d9dcef3a  mov esi, 0x00
000076c1d9dcef3f  mov rax, 0x5EA58B9E0530
000076c1d9dcef49  call rax
000076c1d9dcef4b  movaps xmm14, [rsp]
000076c1d9dcef50  add rsp, 0x30
000076c1d9dcef54  vmovaps xmm0, [rsp]
000076c1d9dcef59  vmovaps xmm1, [rsp+0x10]
000076c1d9dcef5f  vmovaps xmm2, [rsp+0x20]
000076c1d9dcef65  vmovaps xmm3, [rsp+0x30]
000076c1d9dcef6b  vmovaps xmm4, [rsp+0x40]
000076c1d9dcef71  vmovaps xmm5, [rsp+0x50]
000076c1d9dcef77  vmovaps xmm6, [rsp+0x60]
000076c1d9dcef7d  vmovaps xmm7, [rsp+0x70]
000076c1d9dcef83  vmovaps xmm8, [rsp+0x80]
000076c1d9dcef8c  vmovaps xmm9, [rsp+0x90]
000076c1d9dcef95  vmovaps xmm10, [rsp+0xA0]
000076c1d9dcef9e  vmovaps xmm11, [rsp+0xB0]
000076c1d9dcefa7  vmovaps xmm12, [rsp+0xC0]
000076c1d9dcefb0  vmovaps xmm13, [rsp+0xD0]
000076c1d9dcefb9  vmovaps xmm15, [rsp+0xE0]
000076c1d9dcefc2  add rsp, 0xF0
000076c1d9dcefc9  pop r11
000076c1d9dcefcb  pop r10
000076c1d9dcefcd  pop r9
000076c1d9dcefcf  pop r8
000076c1d9dcefd1  pop rsi
000076c1d9dcefd2  pop rdi
000076c1d9dcefd3  pop rdx
000076c1d9dcefd4  pop rcx
000076c1d9dcefd5  pop rax
000076c1d9dcefd6  add rsp, 0x08
000076c1d9dcefda  jmp 0x000076C1D9DCECAE
000076c1d9dcefdf  call 0x000076C1D9CC34C0
000076c1d9dcefe4  jmp 0x000076C1D9DCECC4
000076c1d9dcefe9  int3
000076c1d9dcefea  nop [rax+rax*1], ax
000076c1d9dceff0  mov rax, [r15+0xF8]
000076c1d9dceff7  lea r14, [rax-0x150]
000076c1d9dceffe  mov [r15+0xF8], r14
000076c1d9dcf005  mov rax, [r15+0x50]
000076c1d9dcf009  lea r12, [rax+0x80]
000076c1d9dcf010  movups xmm1, [r13+r12*1]
000076c1d9dcf016  lea r12, [rax+0x90]
000076c1d9dcf01d  movups xmm15, [r13+r12*1]
000076c1d9dcf023  mov qword ptr [r15+0x48], 0x00
000076c1d9dcf02b  lea r12, [rax+0x40]
000076c1d9dcf02f  movups xmm14, [r13+r12*1]
000076c1d9dcf035  lea r12, [rax+0x50]
000076c1d9dcf039  movups xmm13, [r13+r12*1]
000076c1d9dcf03f  lea r12, [r14+0x120]
000076c1d9dcf046  movq xmm12, qword ptr [r15+0x1C0]
000076c1d9dcf04f  movq xmm11, qword ptr [r15+0x1B0]
000076c1d9dcf058  movq r11, xmm12
000076c1d9dcf05d  movq r10, xmm11
000076c1d9dcf062  mov [r13+r12*1], r11
000076c1d9dcf067  lea r12, [r14+0x128]
000076c1d9dcf06e  mov [r13+r12*1], r10
000076c1d9dcf073  vxorps xmm12, xmm12, xmm12
000076c1d9dcf078  vpbroadcastq xmm12, xmm12
000076c1d9dcf07d  lea r12, [r14+0x100]
000076c1d9dcf084  movq xmm11, qword ptr [r15+0x200]
000076c1d9dcf08d  movq xmm10, qword ptr [r15+0x1F0]
000076c1d9dcf096  movq r11, xmm11
000076c1d9dcf09b  movq r10, xmm10
000076c1d9dcf0a0  mov [r13+r12*1], r11
000076c1d9dcf0a5  lea r12, [r14+0x108]
000076c1d9dcf0ac  mov [r13+r12*1], r10
000076c1d9dcf0b1  lea r12, [r14+0xE0]
000076c1d9dcf0b8  movups [r13+r12*1], xmm15
000076c1d9dcf0be  lea r12, [r14+0xF0]
000076c1d9dcf0c5  movups [r13+r12*1], xmm1
000076c1d9dcf0cb  lea r12, [rax+0xC0]
000076c1d9dcf0d2  movups xmm1, [r13+r12*1]
000076c1d9dcf0d8  lea r12, [rax+0xD0]
000076c1d9dcf0df  movups xmm15, [r13+r12*1]
000076c1d9dcf0e5  lea r12, [r14+0x110]
000076c1d9dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000076c1d9dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000076c1d9dcf0fe  movq r11, xmm11
000076c1d9dcf103  movq r10, xmm10
000076c1d9dcf108  mov [r13+r12*1], r11
000076c1d9dcf10d  lea r12, [r14+0x118]
000076c1d9dcf114  mov [r13+r12*1], r10
000076c1d9dcf119  movups xmm11, [r13+rax*1]
000076c1d9dcf11f  lea r12, [rax+0x10]
000076c1d9dcf123  movups xmm10, [r13+r12*1]
000076c1d9dcf129  lea r12, [r14+0x130]
000076c1d9dcf130  movq xmm9, qword ptr [r15+0x1A0]
000076c1d9dcf139  movq xmm8, qword ptr [r15+0x190]
000076c1d9dcf142  movq r11, xmm9
000076c1d9dcf147  movq r10, xmm8
000076c1d9dcf14c  mov [r13+r12*1], r11
000076c1d9dcf151  lea r12, [r14+0x138]
000076c1d9dcf158  mov [r13+r12*1], r10
000076c1d9dcf15d  lea r12, [rax+0x140]
000076c1d9dcf164  movups xmm9, [r13+r12*1]
000076c1d9dcf16a  lea r12, [rax+0x150]
000076c1d9dcf171  movups xmm8, [r13+r12*1]
000076c1d9dcf177  lea r12, [r14+0xC0]
000076c1d9dcf17e  movups [r13+r12*1], xmm15
000076c1d9dcf184  lea r12, [r14+0xD0]
000076c1d9dcf18b  movups [r13+r12*1], xmm1
000076c1d9dcf191  lea r12, [rax+0x100]
000076c1d9dcf198  movups xmm1, [r13+r12*1]
000076c1d9dcf19e  lea r12, [rax+0x110]
000076c1d9dcf1a5  movups xmm15, [r13+r12*1]
000076c1d9dcf1ab  lea r12, [r14+0x140]
000076c1d9dcf1b2  mov r11, [r15+0xE8]
000076c1d9dcf1b9  mov [r13+r12*1], r11
000076c1d9dcf1be  lea r12, [rax+0x180]
000076c1d9dcf1c5  movups xmm7, [r13+r12*1]
000076c1d9dcf1cb  lea r12, [rax+0x190]
000076c1d9dcf1d2  movups xmm6, [r13+r12*1]
000076c1d9dcf1d8  lea r12, [rax+0x1C0]
000076c1d9dcf1df  movups xmm5, [r13+r12*1]
000076c1d9dcf1e5  lea r12, [rax+0x1D0]
000076c1d9dcf1ec  movups xmm4, [r13+r12*1]
000076c1d9dcf1f2  lea r12, [r14+0x20]
000076c1d9dcf1f6  movups [r13+r12*1], xmm1
000076c1d9dcf1fc  lea r12, [r14+0x30]
000076c1d9dcf200  movups [r13+r12*1], xmm13
000076c1d9dcf206  lea r12, [rax+0x60]
000076c1d9dcf20a  movups xmm1, [r13+r12*1]
000076c1d9dcf210  lea r12, [rax+0x70]
000076c1d9dcf214  movups xmm13, [r13+r12*1]
000076c1d9dcf21a  lea r12, [rax+0x20]
000076c1d9dcf21e  movups xmm3, [r13+r12*1]
000076c1d9dcf224  lea r12, [rax+0x30]
000076c1d9dcf228  movups xmm2, [r13+r12*1]
000076c1d9dcf22e  movaps [r15+0x1F0], xmm2
000076c1d9dcf236  lea r12, [r14+0x60]
000076c1d9dcf23a  movups [r13+r12*1], xmm11
000076c1d9dcf240  lea r12, [r14+0x70]
000076c1d9dcf244  movups [r13+r12*1], xmm5
000076c1d9dcf24a  lea r12, [rax+0xE0]
000076c1d9dcf251  movups xmm11, [r13+r12*1]
000076c1d9dcf257  lea r12, [rax+0xF0]
000076c1d9dcf25e  movups xmm5, [r13+r12*1]
000076c1d9dcf264  lea r12, [r14+0xA0]
000076c1d9dcf26b  movups [r13+r12*1], xmm13
000076c1d9dcf271  lea r12, [r14+0xB0]
000076c1d9dcf278  movups [r13+r12*1], xmm1
000076c1d9dcf27e  lea r12, [rax+0xA0]
000076c1d9dcf285  movups xmm1, [r13+r12*1]
000076c1d9dcf28b  lea r12, [rax+0xB0]
000076c1d9dcf292  movups xmm13, [r13+r12*1]
000076c1d9dcf298  lea r12, [rax+0x120]
000076c1d9dcf29f  vmovaps [rsp+0x10], xmm1
000076c1d9dcf2a5  movups xmm1, [r13+r12*1]
000076c1d9dcf2ab  lea r12, [rax+0x130]
000076c1d9dcf2b2  vmovaps [rsp+0x20], xmm1
000076c1d9dcf2b8  movups xmm1, [r13+r12*1]
000076c1d9dcf2be  lea r12, [rax+0x160]
000076c1d9dcf2c5  vmovaps [rsp+0x30], xmm1
000076c1d9dcf2cb  movups xmm1, [r13+r12*1]
000076c1d9dcf2d1  lea r12, [rax+0x170]
000076c1d9dcf2d8  vmovaps [rsp+0x40], xmm1
000076c1d9dcf2de  movups xmm1, [r13+r12*1]
000076c1d9dcf2e4  movaps [r15+0x2B0], xmm1
000076c1d9dcf2ec  lea r12, [r14+0x80]
000076c1d9dcf2f3  movups [r13+r12*1], xmm13
000076c1d9dcf2f9  lea r12, [r14+0x90]
000076c1d9dcf300  vmovaps xmm13, [rsp+0x10]
000076c1d9dcf306  movups [r13+r12*1], xmm13
000076c1d9dcf30c  lea r12, [rax+0x1A0]
000076c1d9dcf313  movups xmm13, [r13+r12*1]
000076c1d9dcf319  lea r12, [rax+0x1B0]
000076c1d9dcf320  vmovaps [rsp+0x10], xmm1
000076c1d9dcf326  movups xmm1, [r13+r12*1]
000076c1d9dcf32c  movaps [r15+0x290], xmm13
000076c1d9dcf334  movaps [r15+0x1E0], xmm1
000076c1d9dcf33c  lea r12, [rax+0x1E0]
000076c1d9dcf343  vmovaps [rsp+0x50], xmm1
000076c1d9dcf349  movups xmm1, [r13+r12*1]
000076c1d9dcf34f  lea r12, [rax+0x1F0]
000076c1d9dcf356  vmovaps [rsp+0x60], xmm1
000076c1d9dcf35c  movups xmm1, [r13+r12*1]
000076c1d9dcf362  mov qword ptr [r15+0x50], 0x430920
000076c1d9dcf36a  lea rax, [r14+0x40]
000076c1d9dcf36e  vmovaps [rsp+0x70], xmm1
000076c1d9dcf374  vmovaps xmm1, [rsp+0x40]
000076c1d9dcf37a  movups [r13+rax*1], xmm1
000076c1d9dcf380  lea rax, [r14+0x50]
000076c1d9dcf384  movups [r13+rax*1], xmm10
000076c1d9dcf38a  vmovaps xmm1, [rsp+0x70]
000076c1d9dcf390  movups [r13+r14*1], xmm1
000076c1d9dcf396  lea rax, [r14+0x10]
000076c1d9dcf39a  vmovaps xmm1, [rsp+0x60]
000076c1d9dcf3a0  movups [r13+rax*1], xmm1
000076c1d9dcf3a6  mov rax, [r15+0x40]
000076c1d9dcf3aa  vmovaps [rsp+0x40], xmm3
000076c1d9dcf3b0  vmovaps xmm1, [rsp+0x40]
000076c1d9dcf3b6  por xmm3, xmm1
000076c1d9dcf3ba  vmovaps [rsp+0x40], xmm6
000076c1d9dcf3c0  vmovaps xmm10, [rsp+0x40]
000076c1d9dcf3c6  por xmm6, xmm10
000076c1d9dcf3cb  lea r12, [rax+0x30]
000076c1d9dcf3cf  mov r11, [r13+r12*1]
000076c1d9dcf3d4  lea r12, [rax+0x38]
000076c1d9dcf3d8  mov r10, [r13+r12*1]
000076c1d9dcf3dd  movq xmm10, r11
000076c1d9dcf3e2  vmovaps [rsp+0x40], xmm1
000076c1d9dcf3e8  movq xmm1, r10
000076c1d9dcf3ed  movq xmm10, xmm10
000076c1d9dcf3f2  vmovaps [rsp+0x60], xmm10
000076c1d9dcf3f8  movq xmm10, xmm10
000076c1d9dcf3fd  movaps [r15+0x130], xmm10
000076c1d9dcf405  movq xmm1, xmm1
000076c1d9dcf409  vmovaps [rsp+0x70], xmm1
000076c1d9dcf40f  movq xmm1, xmm1
000076c1d9dcf413  movaps [r15+0x280], xmm1
000076c1d9dcf41b  vmovaps [rsp+0x80], xmm9
000076c1d9dcf424  vmovaps xmm1, [rsp+0x80]
000076c1d9dcf42d  por xmm9, xmm1
000076c1d9dcf432  lea r12, [rax+0x20]
000076c1d9dcf436  mov r11, [r13+r12*1]
000076c1d9dcf43b  lea r12, [rax+0x28]
000076c1d9dcf43f  mov r10, [r13+r12*1]
000076c1d9dcf444  movq xmm1, r11
000076c1d9dcf449  movq xmm10, r10
000076c1d9dcf44e  movq xmm1, xmm1
000076c1d9dcf452  vmovaps [rsp+0x80], xmm1
000076c1d9dcf45b  movq xmm1, xmm1
000076c1d9dcf45f  movaps [r15+0x150], xmm1
000076c1d9dcf467  movq xmm10, xmm10
000076c1d9dcf46c  vmovaps [rsp+0x90], xmm10
000076c1d9dcf475  movq xmm10, xmm10
000076c1d9dcf47a  movaps [r15+0x140], xmm10
000076c1d9dcf482  lea r12, [rax+0x10]
000076c1d9dcf486  mov r11, [r13+r12*1]
000076c1d9dcf48b  lea r12, [rax+0x18]
000076c1d9dcf48f  mov r10, [r13+r12*1]
000076c1d9dcf494  movq xmm1, r11
000076c1d9dcf499  movq xmm10, r10
000076c1d9dcf49e  movq xmm1, xmm1
000076c1d9dcf4a2  vmovaps [rsp+0xA0], xmm1
000076c1d9dcf4ab  movq xmm1, xmm1
000076c1d9dcf4af  movaps [r15+0x170], xmm1
000076c1d9dcf4b7  movq xmm10, xmm10
000076c1d9dcf4bc  vmovaps [rsp+0xB0], xmm10
000076c1d9dcf4c5  movq xmm10, xmm10
000076c1d9dcf4ca  movaps [r15+0x160], xmm10
000076c1d9dcf4d2  mov r12, [r13+rax*1]
000076c1d9dcf4d7  vmovq xmm1, r12
000076c1d9dcf4dc  vpbroadcastq xmm1, xmm1
000076c1d9dcf4e1  lea r12, [rax+0x08]
000076c1d9dcf4e5  mov rax, [r13+r12*1]
000076c1d9dcf4ea  movq xmm10, rax
000076c1d9dcf4ef  movaps [r15+0x230], xmm10
000076c1d9dcf4f7  lea rax, [r14+0x50]
000076c1d9dcf4fb  movups xmm10, [r13+rax*1]
000076c1d9dcf501  lea rax, [r14+0x60]
000076c1d9dcf505  vmovaps [rsp+0xC0], xmm1
000076c1d9dcf50e  movups xmm1, [r13+rax*1]
000076c1d9dcf514  lea rax, [r14+0x30]
000076c1d9dcf518  vmovaps [rsp+0xD0], xmm1
000076c1d9dcf521  movups xmm1, [r13+rax*1]
000076c1d9dcf527  mov qword ptr [r15+0x60], 0x430920
000076c1d9dcf52f  mov qword ptr [r15+0x58], 0x40
000076c1d9dcf537  vmovaps [rsp+0xE0], xmm1
000076c1d9dcf540  vmovaps [rsp+0xF0], xmm15
000076c1d9dcf549  vmovaps xmm15, [rsp+0xC0]
000076c1d9dcf552  vmovaps [rsp+0xC0], xmm14
000076c1d9dcf55b  vmovaps xmm14, [rsp+0x40]
000076c1d9dcf561  vmovaps [rsp+0x40], xmm13
000076c1d9dcf567  movaps xmm1, xmm15
000076c1d9dcf56b  mulpd xmm1, xmm14
000076c1d9dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000076c1d9dcf575  ptest xmm13, xmm13
000076c1d9dcf57b  jnz 0x000076C1D9DD0682
000076c1d9dcf581  movq xmm14, qword ptr [r15+0x230]
000076c1d9dcf58a  vmovaps [rsp+0x100], xmm14
000076c1d9dcf593  vpermilpd xmm14, xmm14, 0x00
000076c1d9dcf599  vmovaps [rsp+0x110], xmm1
000076c1d9dcf5a2  vmovaps xmm1, [rsp+0xE0]
000076c1d9dcf5ab  vmovaps [rsp+0xE0], xmm15
000076c1d9dcf5b4  movaps xmm13, xmm1
000076c1d9dcf5b8  mulpd xmm13, xmm14
000076c1d9dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000076c1d9dcf5c3  ptest xmm15, xmm15
000076c1d9dcf5c9  jnz 0x000076C1D9DD07C4
000076c1d9dcf5cf  vxorps xmm1, xmm1, xmm1
000076c1d9dcf5d3  vpbroadcastq xmm1, xmm1
000076c1d9dcf5d8  vmovaps xmm14, [rsp+0xE0]
000076c1d9dcf5e1  vmovaps [rsp+0xE0], xmm1
000076c1d9dcf5ea  vmovaps xmm1, [rsp+0xD0]
000076c1d9dcf5f3  vmovaps [rsp+0xD0], xmm13
000076c1d9dcf5fc  movaps xmm15, xmm14
000076c1d9dcf600  mulpd xmm15, xmm1
000076c1d9dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000076c1d9dcf60b  ptest xmm13, xmm13
000076c1d9dcf611  jnz 0x000076C1D9DD0907
000076c1d9dcf617  movaps xmm1, xmm14
000076c1d9dcf61b  mulpd xmm1, xmm10
000076c1d9dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000076c1d9dcf625  ptest xmm13, xmm13
000076c1d9dcf62b  jnz 0x000076C1D9DD0A4A
000076c1d9dcf631  movaps xmm13, xmm14
000076c1d9dcf635  mulpd xmm13, xmm2
000076c1d9dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000076c1d9dcf640  ptest xmm10, xmm10
000076c1d9dcf646  jnz 0x000076C1D9DD0B8C
000076c1d9dcf64c  vmovaps [rsp+0x120], xmm7
000076c1d9dcf655  vmovaps xmm14, [rsp+0x120]
000076c1d9dcf65e  por xmm7, xmm14
000076c1d9dcf663  vmovaps xmm14, [rsp+0xC0]
000076c1d9dcf66c  vmovaps xmm10, [rsp+0xC0]
000076c1d9dcf675  por xmm14, xmm10
000076c1d9dcf67a  vmovaps xmm2, [rsp+0x100]
000076c1d9dcf683  vpermilpd xmm2, xmm2, 0x00
000076c1d9dcf689  vmovaps [rsp+0xC0], xmm1
000076c1d9dcf692  vmovaps [rsp+0x120], xmm15
000076c1d9dcf69b  movaps xmm1, xmm10
000076c1d9dcf69f  mulpd xmm1, xmm2
000076c1d9dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000076c1d9dcf6a8  ptest xmm15, xmm15
000076c1d9dcf6ae  jnz 0x000076C1D9DD0CCF
000076c1d9dcf6b4  xor eax, eax
000076c1d9dcf6b6  mov r12d, 0x40
000076c1d9dcf6bc  mov r11d, 0x200
000076c1d9dcf6c2  cmp r12, r11
000076c1d9dcf6c5  cmc
000076c1d9dcf6c6  lahf
000076c1d9dcf6c7  seto al
000076c1d9dcf6ca  mov [r15+0x108], eax
000076c1d9dcf6d1  vmovaps xmm10, [rsp+0x110]
000076c1d9dcf6da  vmovaps xmm2, [rsp+0xE0]
000076c1d9dcf6e3  vmovaps [rsp+0xE0], xmm1
000076c1d9dcf6ec  movaps xmm15, xmm10
000076c1d9dcf6f0  addpd xmm15, xmm2
000076c1d9dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000076c1d9dcf6fb  ptest xmm1, xmm1
000076c1d9dcf700  jnz 0x000076C1D9DD0E10
000076c1d9dcf706  vmovaps xmm10, [rsp+0x120]
000076c1d9dcf70f  vmovaps [rsp+0x110], xmm15
000076c1d9dcf718  movaps xmm1, xmm10
000076c1d9dcf71c  addpd xmm1, xmm12
000076c1d9dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000076c1d9dcf726  ptest xmm15, xmm15
000076c1d9dcf72c  jnz 0x000076C1D9DD0F53
000076c1d9dcf732  vmovaps xmm10, [rsp+0xC0]
000076c1d9dcf73b  vmovaps [rsp+0xC0], xmm1
000076c1d9dcf744  movaps xmm15, xmm10
000076c1d9dcf748  addpd xmm15, xmm12
000076c1d9dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000076c1d9dcf753  ptest xmm1, xmm1
000076c1d9dcf758  jnz 0x000076C1D9DD1095
000076c1d9dcf75e  vmovaps xmm1, [rsp+0x30]
000076c1d9dcf764  vmovaps xmm12, [rsp+0x30]
000076c1d9dcf76a  por xmm1, xmm12
000076c1d9dcf76f  vmovaps xmm12, [rsp+0x20]
000076c1d9dcf775  vmovaps xmm10, [rsp+0x20]
000076c1d9dcf77b  por xmm12, xmm10
000076c1d9dcf780  vmovaps [rsp+0x20], xmm5
000076c1d9dcf786  vmovaps xmm10, [rsp+0x20]
000076c1d9dcf78c  por xmm5, xmm10
000076c1d9dcf791  vmovaps [rsp+0x20], xmm11
000076c1d9dcf797  vmovaps xmm10, [rsp+0x20]
000076c1d9dcf79d  por xmm11, xmm10
000076c1d9dcf7a2  vmovaps [rsp+0x20], xmm4
000076c1d9dcf7a8  vmovaps xmm10, [rsp+0x20]
000076c1d9dcf7ae  por xmm4, xmm10
000076c1d9dcf7b3  vmovaps [rsp+0x20], xmm8
000076c1d9dcf7b9  vmovaps xmm10, [rsp+0x20]
000076c1d9dcf7bf  por xmm8, xmm10
000076c1d9dcf7c4  vmovaps xmm10, [rsp+0xF0]
000076c1d9dcf7cd  vmovaps [rsp+0x20], xmm1
000076c1d9dcf7d3  vmovaps xmm1, [rsp+0xF0]
000076c1d9dcf7dc  por xmm10, xmm1
000076c1d9dcf7e1  lea rax, [r14+0xA0]
000076c1d9dcf7e8  movups xmm1, [r13+rax*1]
000076c1d9dcf7ee  lea rax, [r14+0xB0]
000076c1d9dcf7f5  vmovaps [rsp+0x30], xmm1
000076c1d9dcf7fb  movups xmm1, [r13+rax*1]
000076c1d9dcf801  vmovaps [rsp+0xF0], xmm1
000076c1d9dcf80a  vmovaps [rsp+0x120], xmm15
000076c1d9dcf813  movaps xmm1, xmm13
000076c1d9dcf817  addpd xmm1, xmm2
000076c1d9dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000076c1d9dcf820  ptest xmm15, xmm15
000076c1d9dcf826  jnz 0x000076C1D9DD11ED
000076c1d9dcf82c  lea rax, [r14+0xF0]
000076c1d9dcf833  movups xmm15, [r13+rax*1]
000076c1d9dcf839  vmovaps xmm2, [rsp+0xC0]
000076c1d9dcf842  vmovaps [rsp+0xC0], xmm1
000076c1d9dcf84b  vmovaps xmm1, [rsp+0xE0]
000076c1d9dcf854  vmovaps [rsp+0xE0], xmm15
000076c1d9dcf85d  movaps xmm13, xmm2
000076c1d9dcf861  addpd xmm13, xmm1
000076c1d9dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000076c1d9dcf86c  ptest xmm15, xmm15
000076c1d9dcf872  jnz 0x000076C1D9DD1338
000076c1d9dcf878  vmovaps xmm15, [rsp+0x120]
000076c1d9dcf881  vmovaps xmm2, [rsp+0xD0]
000076c1d9dcf88a  vmovaps [rsp+0xD0], xmm14
000076c1d9dcf893  movaps xmm1, xmm15
000076c1d9dcf897  addpd xmm1, xmm2
000076c1d9dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000076c1d9dcf8a0  ptest xmm14, xmm14
000076c1d9dcf8a6  jnz 0x000076C1D9DD147A
000076c1d9dcf8ac  vmovaps xmm15, [rsp+0x100]
000076c1d9dcf8b5  vpermilpd xmm15, xmm15, 0x00
000076c1d9dcf8bb  vmovaps xmm2, [rsp+0xF0]
000076c1d9dcf8c4  vmovaps [rsp+0xF0], xmm1
000076c1d9dcf8cd  movaps xmm14, xmm2
000076c1d9dcf8d1  mulpd xmm14, xmm15
000076c1d9dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000076c1d9dcf8dc  ptest xmm1, xmm1
000076c1d9dcf8e1  jnz 0x000076C1D9DD15BB
000076c1d9dcf8e7  vmovaps xmm1, [rsp+0xA0]
000076c1d9dcf8f0  vpermilpd xmm1, xmm1, 0x00
000076c1d9dcf8f6  vmovaps xmm2, [rsp+0xE0]
000076c1d9dcf8ff  vmovaps [rsp+0xE0], xmm14
000076c1d9dcf908  movaps xmm15, xmm2
000076c1d9dcf90c  mulpd xmm15, xmm1
000076c1d9dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000076c1d9dcf917  ptest xmm14, xmm14
000076c1d9dcf91d  jnz 0x000076C1D9DD16FE
000076c1d9dcf923  lea rax, [r14+0xE0]
000076c1d9dcf92a  movups xmm1, [r13+rax*1]
000076c1d9dcf930  vmovaps xmm14, [rsp+0x100]
000076c1d9dcf939  vpermilpd xmm14, xmm14, 0x00
000076c1d9dcf93f  vmovaps [rsp+0x100], xmm1
000076c1d9dcf948  vmovaps xmm1, [rsp+0x30]
000076c1d9dcf94e  vmovaps [rsp+0x30], xmm15
000076c1d9dcf954  movaps xmm2, xmm1
000076c1d9dcf957  mulpd xmm2, xmm14
000076c1d9dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000076c1d9dcf961  ptest xmm15, xmm15
000076c1d9dcf967  jnz 0x000076C1D9DD184A
000076c1d9dcf96d  vmovaps [rsp+0x120], xmm10
000076c1d9dcf976  vmovaps xmm1, [rsp+0x120]
000076c1d9dcf97f  por xmm10, xmm1
000076c1d9dcf984  movaps [r15+0x300], xmm10
000076c1d9dcf98c  vmovaps [rsp+0x120], xmm8
000076c1d9dcf995  vmovaps xmm1, [rsp+0x120]
000076c1d9dcf99e  por xmm8, xmm1
000076c1d9dcf9a3  movaps [r15+0x190], xmm8
000076c1d9dcf9ab  vmovaps xmm1, [rsp+0xA0]
000076c1d9dcf9b4  vpermilpd xmm1, xmm1, 0x00
000076c1d9dcf9ba  vmovaps xmm14, [rsp+0x100]
000076c1d9dcf9c3  vmovaps [rsp+0x100], xmm13
000076c1d9dcf9cc  movaps xmm15, xmm14
000076c1d9dcf9d0  mulpd xmm15, xmm1
000076c1d9dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000076c1d9dcf9db  ptest xmm13, xmm13
000076c1d9dcf9e1  jnz 0x000076C1D9DD198B
000076c1d9dcf9e7  lea rax, [r14+0x90]
000076c1d9dcf9ee  movups xmm1, [r13+rax*1]
000076c1d9dcf9f4  vmovaps [rsp+0x120], xmm4
000076c1d9dcf9fd  vmovaps xmm14, [rsp+0x120]
000076c1d9dcfa06  por xmm4, xmm14
000076c1d9dcfa0b  movaps [r15+0x1C0], xmm4
000076c1d9dcfa13  vmovaps [rsp+0x120], xmm11
000076c1d9dcfa1c  vmovaps xmm14, [rsp+0x120]
000076c1d9dcfa25  por xmm11, xmm14
000076c1d9dcfa2a  movaps [r15+0x200], xmm11
000076c1d9dcfa32  vmovaps [rsp+0x120], xmm5
000076c1d9dcfa3b  vmovaps xmm14, [rsp+0x120]
000076c1d9dcfa44  por xmm5, xmm14
000076c1d9dcfa49  movaps [r15+0x2D0], xmm5
000076c1d9dcfa51  vmovaps [rsp+0x120], xmm12
000076c1d9dcfa5a  vmovaps xmm14, [rsp+0x120]
000076c1d9dcfa63  por xmm12, xmm14
000076c1d9dcfa68  movaps [r15+0x2E0], xmm12
000076c1d9dcfa70  vmovaps xmm13, [rsp+0x110]
000076c1d9dcfa79  vmovaps [rsp+0x110], xmm1
000076c1d9dcfa82  vmovaps xmm1, [rsp+0xE0]
000076c1d9dcfa8b  vmovaps [rsp+0xE0], xmm15
000076c1d9dcfa94  movaps xmm14, xmm13
000076c1d9dcfa98  addpd xmm14, xmm1
000076c1d9dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000076c1d9dcfaa3  ptest xmm15, xmm15
000076c1d9dcfaa9  jnz 0x000076C1D9DD1AD8
000076c1d9dcfaaf  vmovaps xmm1, [rsp+0xA0]
000076c1d9dcfab8  vpermilpd xmm1, xmm1, 0x00
000076c1d9dcfabe  vmovaps xmm13, [rsp+0x110]
000076c1d9dcfac7  vmovaps [rsp+0x110], xmm14
000076c1d9dcfad0  movaps xmm15, xmm13
000076c1d9dcfad4  mulpd xmm15, xmm1
000076c1d9dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000076c1d9dcfadf  ptest xmm14, xmm14
000076c1d9dcfae5  jnz 0x000076C1D9DD1C1B
000076c1d9dcfaeb  lea rax, [r14+0x80]
000076c1d9dcfaf2  movups xmm1, [r13+rax*1]
000076c1d9dcfaf8  vmovaps xmm13, [rsp+0xC0]
000076c1d9dcfb01  vmovaps [rsp+0xC0], xmm1
000076c1d9dcfb0a  movaps xmm14, xmm13
000076c1d9dcfb0e  addpd xmm14, xmm2
000076c1d9dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000076c1d9dcfb19  ptest xmm1, xmm1
000076c1d9dcfb1e  jnz 0x000076C1D9DD1D68
000076c1d9dcfb24  vmovaps xmm13, [rsp+0x100]
000076c1d9dcfb2d  vmovaps xmm2, [rsp+0x30]
000076c1d9dcfb33  vmovaps [rsp+0x30], xmm15
000076c1d9dcfb39  movaps xmm1, xmm13
000076c1d9dcfb3d  addpd xmm1, xmm2
000076c1d9dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000076c1d9dcfb46  ptest xmm15, xmm15
000076c1d9dcfb4c  jnz 0x000076C1D9DD1EAB
000076c1d9dcfb52  vmovaps xmm15, [rsp+0x20]
000076c1d9dcfb58  vmovaps xmm13, [rsp+0x20]
000076c1d9dcfb5e  por xmm15, xmm13
000076c1d9dcfb63  movaps [r15+0x2F0], xmm15
000076c1d9dcfb6b  vmovaps xmm13, [rsp+0xA0]
000076c1d9dcfb74  vpermilpd xmm13, xmm13, 0x00
000076c1d9dcfb7a  vmovaps [rsp+0x20], xmm1
000076c1d9dcfb80  vmovaps xmm1, [rsp+0xC0]
000076c1d9dcfb89  vmovaps [rsp+0xA0], xmm15
000076c1d9dcfb92  movaps xmm2, xmm1
000076c1d9dcfb95  mulpd xmm2, xmm13
000076c1d9dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000076c1d9dcfb9f  ptest xmm15, xmm15
000076c1d9dcfba5  jnz 0x000076C1D9DD1FEC
000076c1d9dcfbab  lea rax, [r14+0xD0]
000076c1d9dcfbb2  movups xmm1, [r13+rax*1]
000076c1d9dcfbb8  vmovaps xmm13, [rsp+0xF0]
000076c1d9dcfbc1  vmovaps [rsp+0xC0], xmm1
000076c1d9dcfbca  vmovaps xmm1, [rsp+0xE0]
000076c1d9dcfbd3  vmovaps [rsp+0xE0], xmm14
000076c1d9dcfbdc  movaps xmm15, xmm13
000076c1d9dcfbe0  addpd xmm15, xmm1
000076c1d9dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000076c1d9dcfbeb  ptest xmm14, xmm14
000076c1d9dcfbf1  jnz 0x000076C1D9DD2137
000076c1d9dcfbf7  vmovaps xmm1, [rsp+0xB0]
000076c1d9dcfc00  vpermilpd xmm1, xmm1, 0x00
000076c1d9dcfc06  movaps xmm14, xmm11
000076c1d9dcfc0a  mulpd xmm14, xmm1
000076c1d9dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000076c1d9dcfc15  ptest xmm13, xmm13
000076c1d9dcfc1b  jnz 0x000076C1D9DD227A
000076c1d9dcfc21  movaps [r15+0x260], xmm14
000076c1d9dcfc29  vxorps xmm1, xmm1, xmm1
000076c1d9dcfc2d  vpbroadcastq xmm1, xmm1
000076c1d9dcfc32  movaps [r15+0x1B0], xmm1
000076c1d9dcfc3a  vmovaps xmm1, [rsp+0xB0]
000076c1d9dcfc43  vpermilpd xmm1, xmm1, 0x00
000076c1d9dcfc49  vmovaps xmm11, [rsp+0xC0]
000076c1d9dcfc52  vmovaps [rsp+0xC0], xmm15
000076c1d9dcfc5b  movaps xmm13, xmm11
000076c1d9dcfc5f  mulpd xmm13, xmm1
000076c1d9dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000076c1d9dcfc6a  ptest xmm15, xmm15
000076c1d9dcfc70  jnz 0x000076C1D9DD23BD
000076c1d9dcfc76  lea rax, [r14+0xC0]
000076c1d9dcfc7d  movups xmm1, [r13+rax*1]
000076c1d9dcfc83  vmovaps xmm11, [rsp+0x110]
000076c1d9dcfc8c  vmovaps [rsp+0xF0], xmm1
000076c1d9dcfc95  vmovaps xmm1, [rsp+0x30]
000076c1d9dcfc9b  vmovaps [rsp+0x30], xmm14
000076c1d9dcfca1  movaps xmm15, xmm11
000076c1d9dcfca5  addpd xmm15, xmm1
000076c1d9dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000076c1d9dcfcb0  ptest xmm14, xmm14
000076c1d9dcfcb6  jnz 0x000076C1D9DD250A
000076c1d9dcfcbc  vmovaps [rsp+0x100], xmm9
000076c1d9dcfcc5  vmovaps xmm1, [rsp+0x100]
000076c1d9dcfcce  por xmm9, xmm1
000076c1d9dcfcd3  movaps [r15+0x270], xmm9
000076c1d9dcfcdb  vmovaps [rsp+0x100], xmm6
000076c1d9dcfce4  vmovaps xmm1, [rsp+0x100]
000076c1d9dcfced  por xmm6, xmm1
000076c1d9dcfcf1  movaps [r15+0x1A0], xmm6
000076c1d9dcfcf9  vmovaps xmm14, [rsp+0xB0]
000076c1d9dcfd02  vpermilpd xmm14, xmm14, 0x00
000076c1d9dcfd08  vmovaps xmm6, [rsp+0xF0]
000076c1d9dcfd11  vmovaps [rsp+0xF0], xmm1
000076c1d9dcfd1a  movaps xmm11, xmm6
000076c1d9dcfd1e  mulpd xmm11, xmm14
000076c1d9dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000076c1d9dcfd29  ptest xmm1, xmm1
000076c1d9dcfd2e  jnz 0x000076C1D9DD264D
000076c1d9dcfd34  lea rax, [r14+0x20]
000076c1d9dcfd38  movups xmm1, [r13+rax*1]
000076c1d9dcfd3e  movaps [r15+0x110], xmm1
000076c1d9dcfd46  vmovaps xmm6, [rsp+0xE0]
000076c1d9dcfd4f  vmovaps [rsp+0xE0], xmm1
000076c1d9dcfd58  movaps xmm14, xmm6
000076c1d9dcfd5c  addpd xmm14, xmm2
000076c1d9dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000076c1d9dcfd67  ptest xmm1, xmm1
000076c1d9dcfd6c  jnz 0x000076C1D9DD279A
000076c1d9dcfd72  vmovaps xmm1, [rsp+0xB0]
000076c1d9dcfd7b  vpermilpd xmm1, xmm1, 0x00
000076c1d9dcfd81  movaps xmm6, xmm5
000076c1d9dcfd84  mulpd xmm6, xmm1
000076c1d9dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000076c1d9dcfd8d  ptest xmm2, xmm2
000076c1d9dcfd92  jnz 0x000076C1D9DD28DC
000076c1d9dcfd98  vmovaps xmm5, [rsp+0x20]
000076c1d9dcfd9e  movaps xmm1, xmm5
000076c1d9dcfda1  addpd xmm1, xmm13
000076c1d9dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000076c1d9dcfdab  ptest xmm2, xmm2
000076c1d9dcfdb0  jnz 0x000076C1D9DD2A1C
000076c1d9dcfdb6  vmovaps xmm13, [rsp+0x80]
000076c1d9dcfdbf  vpermilpd xmm13, xmm13, 0x00
000076c1d9dcfdc5  vmovaps xmm2, [rsp+0xE0]
000076c1d9dcfdce  vmovaps [rsp+0x20], xmm1
000076c1d9dcfdd4  movaps xmm5, xmm2
000076c1d9dcfdd7  mulpd xmm5, xmm13
000076c1d9dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000076c1d9dcfde1  ptest xmm1, xmm1
000076c1d9dcfde6  jnz 0x000076C1D9DD2B5D
000076c1d9dcfdec  vmovaps xmm1, [rsp+0x80]
000076c1d9dcfdf5  vpermilpd xmm1, xmm1, 0x00
000076c1d9dcfdfb  movaps xmm13, xmm10
000076c1d9dcfdff  mulpd xmm13, xmm1
000076c1d9dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000076c1d9dcfe0a  ptest xmm2, xmm2
000076c1d9dcfe0f  jnz 0x000076C1D9DD2C9E
000076c1d9dcfe15  vmovaps xmm10, [rsp+0x30]
000076c1d9dcfe1b  movaps xmm1, xmm15
000076c1d9dcfe1f  addpd xmm1, xmm10
000076c1d9dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000076c1d9dcfe29  ptest xmm2, xmm2
000076c1d9dcfe2e  jnz 0x000076C1D9DD2DE1
000076c1d9dcfe34  vmovaps xmm10, [rsp+0xC0]
000076c1d9dcfe3d  movaps xmm15, xmm10
000076c1d9dcfe41  addpd xmm15, xmm11
000076c1d9dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000076c1d9dcfe4c  ptest xmm2, xmm2
000076c1d9dcfe51  jnz 0x000076C1D9DD2F23
000076c1d9dcfe57  vmovaps xmm11, [rsp+0x80]
000076c1d9dcfe60  vpermilpd xmm11, xmm11, 0x00
000076c1d9dcfe66  movaps xmm10, xmm12
000076c1d9dcfe6a  mulpd xmm10, xmm11
000076c1d9dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000076c1d9dcfe75  ptest xmm2, xmm2
000076c1d9dcfe7a  jnz 0x000076C1D9DD3067
000076c1d9dcfe80  vmovaps xmm12, [rsp+0x80]
000076c1d9dcfe89  vpermilpd xmm12, xmm12, 0x00
000076c1d9dcfe8f  vmovaps xmm2, [rsp+0xA0]
000076c1d9dcfe98  vmovaps [rsp+0x30], xmm1
000076c1d9dcfe9e  movaps xmm11, xmm2
000076c1d9dcfea2  mulpd xmm11, xmm12
000076c1d9dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000076c1d9dcfead  ptest xmm1, xmm1
000076c1d9dcfeb2  jnz 0x000076C1D9DD31AB
000076c1d9dcfeb8  movaps xmm1, xmm14
000076c1d9dcfebc  addpd xmm1, xmm6
000076c1d9dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000076c1d9dcfec5  ptest xmm12, xmm12
000076c1d9dcfecb  jnz 0x000076C1D9DD32EE
000076c1d9dcfed1  vmovaps xmm12, [rsp+0x20]
000076c1d9dcfed7  movaps xmm14, xmm12
000076c1d9dcfedb  addpd xmm14, xmm5
000076c1d9dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000076c1d9dcfee6  ptest xmm6, xmm6
000076c1d9dcfeeb  jnz 0x000076C1D9DD342F
000076c1d9dcfef1  vmovaps xmm12, [rsp+0x90]
000076c1d9dcfefa  vpermilpd xmm12, xmm12, 0x00
000076c1d9dcff00  movaps xmm6, xmm9
000076c1d9dcff04  mulpd xmm6, xmm12
000076c1d9dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000076c1d9dcff0e  ptest xmm5, xmm5
000076c1d9dcff13  jnz 0x000076C1D9DD3572
000076c1d9dcff19  movaps xmm12, xmm15
000076c1d9dcff1d  addpd xmm12, xmm13
000076c1d9dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000076c1d9dcff28  ptest xmm9, xmm9
000076c1d9dcff2e  jnz 0x000076C1D9DD36B4
000076c1d9dcff34  vmovaps xmm13, [rsp+0x30]
000076c1d9dcff3a  movaps xmm15, xmm13
000076c1d9dcff3e  addpd xmm15, xmm10
000076c1d9dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000076c1d9dcff49  ptest xmm9, xmm9
000076c1d9dcff4f  jnz 0x000076C1D9DD37F8
000076c1d9dcff55  vmovaps xmm13, [rsp+0xD0]
000076c1d9dcff5e  vmovaps xmm10, [rsp+0xD0]
000076c1d9dcff67  por xmm13, xmm10
000076c1d9dcff6c  movaps [r15+0x250], xmm13
000076c1d9dcff74  vmovaps [rsp+0x20], xmm7
000076c1d9dcff7a  vmovaps xmm13, [rsp+0x20]
000076c1d9dcff80  por xmm7, xmm13
000076c1d9dcff85  movaps [r15+0x2A0], xmm7
000076c1d9dcff8d  vmovaps [rsp+0x20], xmm3
000076c1d9dcff93  vmovaps xmm13, [rsp+0x20]
000076c1d9dcff99  por xmm3, xmm13
000076c1d9dcff9e  movaps [r15+0x1D0], xmm3
000076c1d9dcffa6  lea rax, [r14+0x40]
000076c1d9dcffaa  movups xmm13, [r13+rax*1]
000076c1d9dcffb0  movaps [r15+0x2C0], xmm13
000076c1d9dcffb8  vmovaps xmm10, [rsp+0x90]
000076c1d9dcffc1  vpermilpd xmm10, xmm10, 0x00
000076c1d9dcffc7  movaps xmm9, xmm8
000076c1d9dcffcb  mulpd xmm9, xmm10
000076c1d9dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000076c1d9dcffd6  ptest xmm5, xmm5
000076c1d9dcffdb  jnz 0x000076C1D9DD3946
000076c1d9dcffe1  movaps xmm10, xmm1
000076c1d9dcffe5  addpd xmm10, xmm11
000076c1d9dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000076c1d9dcfff0  ptest xmm8, xmm8
000076c1d9dcfff6  jnz 0x000076C1D9DD3A8A
000076c1d9dcfffc  movaps xmm1, xmm14
000076c1d9dd0000  addpd xmm1, xmm6
000076c1d9dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000076c1d9dd0009  ptest xmm11, xmm11
000076c1d9dd000f  jnz 0x000076C1D9DD3BCD
000076c1d9dd0015  vmovaps xmm14, [rsp+0x90]
000076c1d9dd001e  vpermilpd xmm14, xmm14, 0x00
000076c1d9dd0024  movaps xmm11, xmm13
000076c1d9dd0028  mulpd xmm11, xmm14
000076c1d9dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000076c1d9dd0033  ptest xmm8, xmm8
000076c1d9dd0039  jnz 0x000076C1D9DD3D0E
000076c1d9dd003f  vmovaps xmm14, [rsp+0x90]
000076c1d9dd0048  vpermilpd xmm14, xmm14, 0x00
000076c1d9dd004e  vmovaps xmm8, [rsp+0x10]
000076c1d9dd0054  movaps xmm13, xmm8
000076c1d9dd0058  mulpd xmm13, xmm14
000076c1d9dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000076c1d9dd0063  ptest xmm6, xmm6
000076c1d9dd0068  jnz 0x000076C1D9DD3E52
000076c1d9dd006e  vmovaps xmm14, [rsp+0x60]
000076c1d9dd0074  vpermilpd xmm14, xmm14, 0x00
000076c1d9dd007a  movaps xmm8, xmm7
000076c1d9dd007e  mulpd xmm8, xmm14
000076c1d9dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000076c1d9dd0089  ptest xmm6, xmm6
000076c1d9dd008e  jnz 0x000076C1D9DD3F96
000076c1d9dd0094  movaps xmm14, xmm12
000076c1d9dd0098  addpd xmm14, xmm9
000076c1d9dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000076c1d9dd00a3  ptest xmm7, xmm7
000076c1d9dd00a8  jnz 0x000076C1D9DD40D9
000076c1d9dd00ae  vmovaps xmm12, [rsp+0x60]
000076c1d9dd00b4  vpermilpd xmm12, xmm12, 0x00
000076c1d9dd00ba  vmovaps xmm7, [rsp+0xF0]
000076c1d9dd00c3  movaps xmm9, xmm7
000076c1d9dd00c7  mulpd xmm9, xmm12
000076c1d9dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000076c1d9dd00d2  ptest xmm6, xmm6
000076c1d9dd00d7  jnz 0x000076C1D9DD421D
000076c1d9dd00dd  movaps xmm12, xmm15
000076c1d9dd00e1  addpd xmm12, xmm11
000076c1d9dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000076c1d9dd00ec  ptest xmm7, xmm7
000076c1d9dd00f1  jnz 0x000076C1D9DD4360
000076c1d9dd00f7  vmovaps xmm15, [rsp+0x60]
000076c1d9dd00fd  vpermilpd xmm15, xmm15, 0x00
000076c1d9dd0103  vmovaps xmm7, [rsp+0x40]
000076c1d9dd0109  movaps xmm11, xmm7
000076c1d9dd010d  mulpd xmm11, xmm15
000076c1d9dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000076c1d9dd0118  ptest xmm6, xmm6
000076c1d9dd011d  jnz 0x000076C1D9DD44A4
000076c1d9dd0123  movaps xmm15, xmm10
000076c1d9dd0127  addpd xmm15, xmm13
000076c1d9dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000076c1d9dd0132  ptest xmm7, xmm7
000076c1d9dd0137  jnz 0x000076C1D9DD45E7
000076c1d9dd013d  vmovaps xmm13, [rsp+0x60]
000076c1d9dd0143  vpermilpd xmm13, xmm13, 0x00
000076c1d9dd0149  vmovaps xmm7, [rsp+0x50]
000076c1d9dd014f  movaps xmm10, xmm7
000076c1d9dd0153  mulpd xmm10, xmm13
000076c1d9dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000076c1d9dd015e  ptest xmm6, xmm6
000076c1d9dd0163  jnz 0x000076C1D9DD472B
000076c1d9dd0169  movaps xmm13, xmm1
000076c1d9dd016d  addpd xmm13, xmm8
000076c1d9dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000076c1d9dd0178  ptest xmm7, xmm7
000076c1d9dd017d  jnz 0x000076C1D9DD486E
000076c1d9dd0183  lea rax, [r14+0x70]
000076c1d9dd0187  movups xmm1, [r13+rax*1]
000076c1d9dd018d  movaps [r15+0x240], xmm1
000076c1d9dd0195  movaps xmm8, xmm14
000076c1d9dd0199  addpd xmm8, xmm9
000076c1d9dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000076c1d9dd01a4  ptest xmm7, xmm7
000076c1d9dd01a9  jnz 0x000076C1D9DD49BB
000076c1d9dd01af  movaps [r15+0x170], xmm8
000076c1d9dd01b7  vmovaps xmm14, [rsp+0x70]
000076c1d9dd01bd  vpermilpd xmm14, xmm14, 0x00
000076c1d9dd01c3  movaps xmm9, xmm1
000076c1d9dd01c7  mulpd xmm9, xmm14
000076c1d9dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000076c1d9dd01d2  ptest xmm7, xmm7
000076c1d9dd01d7  jnz 0x000076C1D9DD4AFF
000076c1d9dd01dd  vmovaps xmm1, [rsp+0x70]
000076c1d9dd01e3  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd01e9  movaps xmm14, xmm4
000076c1d9dd01ed  mulpd xmm14, xmm1
000076c1d9dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000076c1d9dd01f8  ptest xmm7, xmm7
000076c1d9dd01fd  jnz 0x000076C1D9DD4C42
000076c1d9dd0203  movaps [r15+0x180], xmm14
000076c1d9dd020b  movaps xmm1, xmm12
000076c1d9dd020f  addpd xmm1, xmm11
000076c1d9dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000076c1d9dd0219  ptest xmm7, xmm7
000076c1d9dd021e  jnz 0x000076C1D9DD4D84
000076c1d9dd0224  movaps [r15+0x210], xmm1
000076c1d9dd022c  movups xmm12, [r13+r14*1]
000076c1d9dd0232  lea rax, [r14+0x10]
000076c1d9dd0236  movups xmm11, [r13+rax*1]
000076c1d9dd023c  movaps [r15+0x230], xmm11
000076c1d9dd0244  movaps xmm7, xmm15
000076c1d9dd0248  addpd xmm7, xmm10
000076c1d9dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000076c1d9dd0252  ptest xmm6, xmm6
000076c1d9dd0257  jnz 0x000076C1D9DD4EDA
000076c1d9dd025d  movaps [r15+0x130], xmm7
000076c1d9dd0265  vmovaps xmm15, [rsp+0x70]
000076c1d9dd026b  vpermilpd xmm15, xmm15, 0x00
000076c1d9dd0271  movaps xmm10, xmm11
000076c1d9dd0275  mulpd xmm10, xmm15
000076c1d9dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000076c1d9dd0280  ptest xmm6, xmm6
000076c1d9dd0285  jnz 0x000076C1D9DD501C
000076c1d9dd028b  movaps [r15+0x220], xmm10
000076c1d9dd0293  vmovaps xmm15, [rsp+0x70]
000076c1d9dd0299  vpermilpd xmm15, xmm15, 0x00
000076c1d9dd029f  movaps xmm11, xmm12
000076c1d9dd02a3  mulpd xmm11, xmm15
000076c1d9dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000076c1d9dd02ae  ptest xmm6, xmm6
000076c1d9dd02b3  jnz 0x000076C1D9DD5160
000076c1d9dd02b9  movaps xmm15, xmm13
000076c1d9dd02bd  addpd xmm15, xmm9
000076c1d9dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000076c1d9dd02c8  ptest xmm12, xmm12
000076c1d9dd02ce  jnz 0x000076C1D9DD52A4
000076c1d9dd02d4  movaps [r15+0x140], xmm15
000076c1d9dd02dc  movaps xmm13, xmm8
000076c1d9dd02e0  addpd xmm13, xmm14
000076c1d9dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000076c1d9dd02eb  ptest xmm12, xmm12
000076c1d9dd02f1  jnz 0x000076C1D9DD53E8
000076c1d9dd02f7  movaps [r15+0x150], xmm13
000076c1d9dd02ff  movaps xmm14, xmm1
000076c1d9dd0303  addpd xmm14, xmm10
000076c1d9dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000076c1d9dd030e  ptest xmm12, xmm12
000076c1d9dd0314  jnz 0x000076C1D9DD552C
000076c1d9dd031a  movaps [r15+0x160], xmm14
000076c1d9dd0322  movaps xmm1, xmm7
000076c1d9dd0325  addpd xmm1, xmm11
000076c1d9dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000076c1d9dd032f  ptest xmm12, xmm12
000076c1d9dd0335  jnz 0x000076C1D9DD566F
000076c1d9dd033b  movaps [r15+0x120], xmm1
000076c1d9dd0343  mov eax, 0x430920
000076c1d9dd0348  movups [r13+rax*1], xmm15
000076c1d9dd034e  mov eax, 0x430930
000076c1d9dd0353  movups [r13+rax*1], xmm13
000076c1d9dd0359  mov eax, 0x430940
000076c1d9dd035e  movups [r13+rax*1], xmm14
000076c1d9dd0364  mov eax, 0x430950
000076c1d9dd0369  movups [r13+rax*1], xmm1
000076c1d9dd036f  mov eax, [r15+0x108]
000076c1d9dd0376  sahf
000076c1d9dd0377  jnz 0x000076C1D9DD03A9
000076c1d9dd0379  cmp dword ptr [r15+0x318], 0x00
000076c1d9dd0381  jz 0x000076C1D9DDB900
000076c1d9dd0387  nop [rax+rax*1], ax
000076c1d9dd0390  nop [rax+rax*1], eax
000076c1d9dd0398  mov eax, 0x410444
000076c1d9dd039d  mov [r15+0x100], rax
000076c1d9dd03a4  jmp 0x000076C1D9BFE110
000076c1d9dd03a9  cmp dword ptr [r15+0x318], 0x00
000076c1d9dd03b1  jz 0x000076C1D9DD57E0
000076c1d9dd03b7  nop [rax+rax*1], ax
000076c1d9dd03c0  nop [rax+rax*1], eax
000076c1d9dd03c8  mov eax, 0x410278
000076c1d9dd03cd  mov [r15+0x100], rax
000076c1d9dd03d4  jmp 0x000076C1D9BFE110
000076c1d9dd03d9  int3
000076c1d9dd03da  call 0x000076C1D9CB52F0
000076c1d9dd03df  jmp 0x000076C1D9DCF016
000076c1d9dd03e4  call 0x000076C1D9CC4620
000076c1d9dd03e9  jmp 0x000076C1D9DCF023
000076c1d9dd03ee  call 0x000076C1D9CC33A0
000076c1d9dd03f3  jmp 0x000076C1D9DCF035
000076c1d9dd03f8  call 0x000076C1D9CC2120
000076c1d9dd03fd  jmp 0x000076C1D9DCF03F
000076c1d9dd0402  call 0x000076C1D9CC0860
000076c1d9dd0407  jmp 0x000076C1D9DCF067
000076c1d9dd040c  call 0x000076C1D9CBF5F0
000076c1d9dd0411  jmp 0x000076C1D9DCF073
000076c1d9dd0416  call 0x000076C1D9CC0860
000076c1d9dd041b  jmp 0x000076C1D9DCF0A5
000076c1d9dd0420  call 0x000076C1D9CBF5F0
000076c1d9dd0425  jmp 0x000076C1D9DCF0B1
000076c1d9dd042a  call 0x000076C1D9CC4740
000076c1d9dd042f  jmp 0x000076C1D9DCF0BE
000076c1d9dd0434  call 0x000076C1D9CB5400
000076c1d9dd0439  jmp 0x000076C1D9DCF0CB
000076c1d9dd043e  call 0x000076C1D9CB52F0
000076c1d9dd0443  jmp 0x000076C1D9DCF0D8
000076c1d9dd0448  call 0x000076C1D9CC4620
000076c1d9dd044d  jmp 0x000076C1D9DCF0E5
000076c1d9dd0452  call 0x000076C1D9CC0860
000076c1d9dd0457  jmp 0x000076C1D9DCF10D
000076c1d9dd045c  call 0x000076C1D9CBF5F0
000076c1d9dd0461  jmp 0x000076C1D9DCF119
000076c1d9dd0466  call 0x000076C1D9C09D70
000076c1d9dd046b  jmp 0x000076C1D9DCF11F
000076c1d9dd0470  call 0x000076C1D9CBE9C0
000076c1d9dd0475  jmp 0x000076C1D9DCF129
000076c1d9dd047a  call 0x000076C1D9CC0860
000076c1d9dd047f  jmp 0x000076C1D9DCF151
000076c1d9dd0484  call 0x000076C1D9CBF5F0
000076c1d9dd0489  jmp 0x000076C1D9DCF15D
000076c1d9dd048e  call 0x000076C1D9CBD750
000076c1d9dd0493  jmp 0x000076C1D9DCF16A
000076c1d9dd0498  call 0x000076C1D9CBC4E0
000076c1d9dd049d  jmp 0x000076C1D9DCF177
000076c1d9dd04a2  call 0x000076C1D9CC4740
000076c1d9dd04a7  jmp 0x000076C1D9DCF184
000076c1d9dd04ac  call 0x000076C1D9CB5400
000076c1d9dd04b1  jmp 0x000076C1D9DCF191
000076c1d9dd04b6  call 0x000076C1D9CB52F0
000076c1d9dd04bb  jmp 0x000076C1D9DCF19E
000076c1d9dd04c0  call 0x000076C1D9CC4620
000076c1d9dd04c5  jmp 0x000076C1D9DCF1AB
000076c1d9dd04ca  call 0x000076C1D9CC0860
000076c1d9dd04cf  jmp 0x000076C1D9DCF1BE
000076c1d9dd04d4  call 0x000076C1D9CBB270
000076c1d9dd04d9  jmp 0x000076C1D9DCF1CB
000076c1d9dd04de  call 0x000076C1D9CBA000
000076c1d9dd04e3  jmp 0x000076C1D9DCF1D8
000076c1d9dd04e8  call 0x000076C1D9CB8D90
000076c1d9dd04ed  jmp 0x000076C1D9DCF1E5
000076c1d9dd04f2  call 0x000076C1D9CB8A20
000076c1d9dd04f7  jmp 0x000076C1D9DCF1F2
000076c1d9dd04fc  call 0x000076C1D9CB5400
000076c1d9dd0501  jmp 0x000076C1D9DCF1FC
000076c1d9dd0506  call 0x000076C1D9CC2240
000076c1d9dd050b  jmp 0x000076C1D9DCF206
000076c1d9dd0510  call 0x000076C1D9CB52F0
000076c1d9dd0515  jmp 0x000076C1D9DCF210
000076c1d9dd051a  call 0x000076C1D9CC2120
000076c1d9dd051f  jmp 0x000076C1D9DCF21A
000076c1d9dd0524  call 0x000076C1D9CB77B0
000076c1d9dd0529  jmp 0x000076C1D9DCF224
000076c1d9dd052e  call 0x000076C1D9CB6550
000076c1d9dd0533  jmp 0x000076C1D9DCF22E
000076c1d9dd0538  call 0x000076C1D9CBFD50
000076c1d9dd053d  jmp 0x000076C1D9DCF240
000076c1d9dd0542  call 0x000076C1D9CB8EA0
000076c1d9dd0547  jmp 0x000076C1D9DCF24A
000076c1d9dd054c  call 0x000076C1D9CBFC30
000076c1d9dd0551  jmp 0x000076C1D9DCF257
000076c1d9dd0556  call 0x000076C1D9CB8D90
000076c1d9dd055b  jmp 0x000076C1D9DCF264
000076c1d9dd0560  call 0x000076C1D9CC2240
000076c1d9dd0565  jmp 0x000076C1D9DCF271
000076c1d9dd056a  call 0x000076C1D9CB5400
000076c1d9dd056f  jmp 0x000076C1D9DCF27E
000076c1d9dd0574  call 0x000076C1D9CB52F0
000076c1d9dd0579  jmp 0x000076C1D9DCF28B
000076c1d9dd057e  call 0x000076C1D9CC2120
000076c1d9dd0583  jmp 0x000076C1D9DCF298
000076c1d9dd0588  call 0x000076C1D9CB52F0
000076c1d9dd058d  jmp 0x000076C1D9DCF2AB
000076c1d9dd0592  call 0x000076C1D9CB52F0
000076c1d9dd0597  jmp 0x000076C1D9DCF2BE
000076c1d9dd059c  call 0x000076C1D9CB52F0
000076c1d9dd05a1  jmp 0x000076C1D9DCF2D1
000076c1d9dd05a6  call 0x000076C1D9CB52F0
000076c1d9dd05ab  jmp 0x000076C1D9DCF2E4
000076c1d9dd05b0  call 0x000076C1D9CC2240
000076c1d9dd05b5  jmp 0x000076C1D9DCF2F9
000076c1d9dd05ba  call 0x000076C1D9CC2240
000076c1d9dd05bf  jmp 0x000076C1D9DCF30C
000076c1d9dd05c4  call 0x000076C1D9CC2120
000076c1d9dd05c9  jmp 0x000076C1D9DCF319
000076c1d9dd05ce  call 0x000076C1D9CB52F0
000076c1d9dd05d3  jmp 0x000076C1D9DCF32C
000076c1d9dd05d8  call 0x000076C1D9CB52F0
000076c1d9dd05dd  jmp 0x000076C1D9DCF34F
000076c1d9dd05e2  call 0x000076C1D9CB52F0
000076c1d9dd05e7  jmp 0x000076C1D9DCF362
000076c1d9dd05ec  call 0x000076C1D9BFF540
000076c1d9dd05f1  jmp 0x000076C1D9DCF380
000076c1d9dd05f6  call 0x000076C1D9C08C20
000076c1d9dd05fb  jmp 0x000076C1D9DCF38A
000076c1d9dd0600  call 0x000076C1D9CD6600
000076c1d9dd0605  jmp 0x000076C1D9DCF396
000076c1d9dd060a  call 0x000076C1D9BFF540
000076c1d9dd060f  jmp 0x000076C1D9DCF3A6
000076c1d9dd0614  call 0x000076C1D9CC0370
000076c1d9dd0619  jmp 0x000076C1D9DCF3D4
000076c1d9dd061e  call 0x000076C1D9CBF100
000076c1d9dd0623  jmp 0x000076C1D9DCF3DD
000076c1d9dd0628  call 0x000076C1D9CC0370
000076c1d9dd062d  jmp 0x000076C1D9DCF43B
000076c1d9dd0632  call 0x000076C1D9CBF100
000076c1d9dd0637  jmp 0x000076C1D9DCF444
000076c1d9dd063c  call 0x000076C1D9CC0370
000076c1d9dd0641  jmp 0x000076C1D9DCF48B
000076c1d9dd0646  call 0x000076C1D9CBF100
000076c1d9dd064b  jmp 0x000076C1D9DCF494
000076c1d9dd0650  call 0x000076C1D9C0B720
000076c1d9dd0655  jmp 0x000076C1D9DCF4D7
000076c1d9dd065a  call 0x000076C1D9CB47C0
000076c1d9dd065f  jmp 0x000076C1D9DCF4EA
000076c1d9dd0664  call 0x000076C1D9C08B00
000076c1d9dd0669  jmp 0x000076C1D9DCF501
000076c1d9dd066e  call 0x000076C1D9BFF430
000076c1d9dd0673  jmp 0x000076C1D9DCF514
000076c1d9dd0678  call 0x000076C1D9BFF430
000076c1d9dd067d  jmp 0x000076C1D9DCF527
000076c1d9dd0682  sub rsp, 0x08
000076c1d9dd0686  push rax
000076c1d9dd0687  push rcx
000076c1d9dd0688  push rdx
000076c1d9dd0689  push rdi
000076c1d9dd068a  push rsi
000076c1d9dd068b  push r8
000076c1d9dd068d  push r9
000076c1d9dd068f  push r10
000076c1d9dd0691  push r11
000076c1d9dd0693  sub rsp, 0xF0
000076c1d9dd069a  vmovaps [rsp], xmm0
000076c1d9dd069f  vmovaps [rsp+0x10], xmm2
000076c1d9dd06a5  vmovaps [rsp+0x20], xmm3
000076c1d9dd06ab  vmovaps [rsp+0x30], xmm4
000076c1d9dd06b1  vmovaps [rsp+0x40], xmm5
000076c1d9dd06b7  vmovaps [rsp+0x50], xmm6
000076c1d9dd06bd  vmovaps [rsp+0x60], xmm7
000076c1d9dd06c3  vmovaps [rsp+0x70], xmm8
000076c1d9dd06c9  vmovaps [rsp+0x80], xmm9
000076c1d9dd06d2  vmovaps [rsp+0x90], xmm10
000076c1d9dd06db  vmovaps [rsp+0xA0], xmm11
000076c1d9dd06e4  vmovaps [rsp+0xB0], xmm12
000076c1d9dd06ed  vmovaps [rsp+0xC0], xmm13
000076c1d9dd06f6  vmovaps [rsp+0xD0], xmm14
000076c1d9dd06ff  vmovaps [rsp+0xE0], xmm15
000076c1d9dd0708  sub rsp, 0x30
000076c1d9dd070c  movaps [rsp], xmm1
000076c1d9dd0710  movaps [rsp+0x10], xmm15
000076c1d9dd0716  movaps [rsp+0x20], xmm14
000076c1d9dd071c  lea rdi, [rsp]
000076c1d9dd0720  mov esi, 0x00
000076c1d9dd0725  mov rax, 0x5EA58B9E0530
000076c1d9dd072f  call rax
000076c1d9dd0731  movaps xmm1, [rsp]
000076c1d9dd0735  add rsp, 0x30
000076c1d9dd0739  vmovaps xmm0, [rsp]
000076c1d9dd073e  vmovaps xmm2, [rsp+0x10]
000076c1d9dd0744  vmovaps xmm3, [rsp+0x20]
000076c1d9dd074a  vmovaps xmm4, [rsp+0x30]
000076c1d9dd0750  vmovaps xmm5, [rsp+0x40]
000076c1d9dd0756  vmovaps xmm6, [rsp+0x50]
000076c1d9dd075c  vmovaps xmm7, [rsp+0x60]
000076c1d9dd0762  vmovaps xmm8, [rsp+0x70]
000076c1d9dd0768  vmovaps xmm9, [rsp+0x80]
000076c1d9dd0771  vmovaps xmm10, [rsp+0x90]
000076c1d9dd077a  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd0783  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd078c  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd0795  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd079e  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd07a7  add rsp, 0xF0
000076c1d9dd07ae  pop r11
000076c1d9dd07b0  pop r10
000076c1d9dd07b2  pop r9
000076c1d9dd07b4  pop r8
000076c1d9dd07b6  pop rsi
000076c1d9dd07b7  pop rdi
000076c1d9dd07b8  pop rdx
000076c1d9dd07b9  pop rcx
000076c1d9dd07ba  pop rax
000076c1d9dd07bb  add rsp, 0x08
000076c1d9dd07bf  jmp 0x000076C1D9DCF581
000076c1d9dd07c4  sub rsp, 0x08
000076c1d9dd07c8  push rax
000076c1d9dd07c9  push rcx
000076c1d9dd07ca  push rdx
000076c1d9dd07cb  push rdi
000076c1d9dd07cc  push rsi
000076c1d9dd07cd  push r8
000076c1d9dd07cf  push r9
000076c1d9dd07d1  push r10
000076c1d9dd07d3  push r11
000076c1d9dd07d5  sub rsp, 0xF0
000076c1d9dd07dc  vmovaps [rsp], xmm0
000076c1d9dd07e1  vmovaps [rsp+0x10], xmm1
000076c1d9dd07e7  vmovaps [rsp+0x20], xmm2
000076c1d9dd07ed  vmovaps [rsp+0x30], xmm3
000076c1d9dd07f3  vmovaps [rsp+0x40], xmm4
000076c1d9dd07f9  vmovaps [rsp+0x50], xmm5
000076c1d9dd07ff  vmovaps [rsp+0x60], xmm6
000076c1d9dd0805  vmovaps [rsp+0x70], xmm7
000076c1d9dd080b  vmovaps [rsp+0x80], xmm8
000076c1d9dd0814  vmovaps [rsp+0x90], xmm9
000076c1d9dd081d  vmovaps [rsp+0xA0], xmm10
000076c1d9dd0826  vmovaps [rsp+0xB0], xmm11
000076c1d9dd082f  vmovaps [rsp+0xC0], xmm12
000076c1d9dd0838  vmovaps [rsp+0xD0], xmm14
000076c1d9dd0841  vmovaps [rsp+0xE0], xmm15
000076c1d9dd084a  sub rsp, 0x30
000076c1d9dd084e  movaps [rsp], xmm13
000076c1d9dd0853  movaps [rsp+0x10], xmm1
000076c1d9dd0858  movaps [rsp+0x20], xmm14
000076c1d9dd085e  lea rdi, [rsp]
000076c1d9dd0862  mov esi, 0x00
000076c1d9dd0867  mov rax, 0x5EA58B9E0530
000076c1d9dd0871  call rax
000076c1d9dd0873  movaps xmm13, [rsp]
000076c1d9dd0878  add rsp, 0x30
000076c1d9dd087c  vmovaps xmm0, [rsp]
000076c1d9dd0881  vmovaps xmm1, [rsp+0x10]
000076c1d9dd0887  vmovaps xmm2, [rsp+0x20]
000076c1d9dd088d  vmovaps xmm3, [rsp+0x30]
000076c1d9dd0893  vmovaps xmm4, [rsp+0x40]
000076c1d9dd0899  vmovaps xmm5, [rsp+0x50]
000076c1d9dd089f  vmovaps xmm6, [rsp+0x60]
000076c1d9dd08a5  vmovaps xmm7, [rsp+0x70]
000076c1d9dd08ab  vmovaps xmm8, [rsp+0x80]
000076c1d9dd08b4  vmovaps xmm9, [rsp+0x90]
000076c1d9dd08bd  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd08c6  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd08cf  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd08d8  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd08e1  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd08ea  add rsp, 0xF0
000076c1d9dd08f1  pop r11
000076c1d9dd08f3  pop r10
000076c1d9dd08f5  pop r9
000076c1d9dd08f7  pop r8
000076c1d9dd08f9  pop rsi
000076c1d9dd08fa  pop rdi
000076c1d9dd08fb  pop rdx
000076c1d9dd08fc  pop rcx
000076c1d9dd08fd  pop rax
000076c1d9dd08fe  add rsp, 0x08
000076c1d9dd0902  jmp 0x000076C1D9DCF5CF
000076c1d9dd0907  sub rsp, 0x08
000076c1d9dd090b  push rax
000076c1d9dd090c  push rcx
000076c1d9dd090d  push rdx
000076c1d9dd090e  push rdi
000076c1d9dd090f  push rsi
000076c1d9dd0910  push r8
000076c1d9dd0912  push r9
000076c1d9dd0914  push r10
000076c1d9dd0916  push r11
000076c1d9dd0918  sub rsp, 0xF0
000076c1d9dd091f  vmovaps [rsp], xmm0
000076c1d9dd0924  vmovaps [rsp+0x10], xmm1
000076c1d9dd092a  vmovaps [rsp+0x20], xmm2
000076c1d9dd0930  vmovaps [rsp+0x30], xmm3
000076c1d9dd0936  vmovaps [rsp+0x40], xmm4
000076c1d9dd093c  vmovaps [rsp+0x50], xmm5
000076c1d9dd0942  vmovaps [rsp+0x60], xmm6
000076c1d9dd0948  vmovaps [rsp+0x70], xmm7
000076c1d9dd094e  vmovaps [rsp+0x80], xmm8
000076c1d9dd0957  vmovaps [rsp+0x90], xmm9
000076c1d9dd0960  vmovaps [rsp+0xA0], xmm10
000076c1d9dd0969  vmovaps [rsp+0xB0], xmm11
000076c1d9dd0972  vmovaps [rsp+0xC0], xmm12
000076c1d9dd097b  vmovaps [rsp+0xD0], xmm13
000076c1d9dd0984  vmovaps [rsp+0xE0], xmm14
000076c1d9dd098d  sub rsp, 0x30
000076c1d9dd0991  movaps [rsp], xmm15
000076c1d9dd0996  movaps [rsp+0x10], xmm14
000076c1d9dd099c  movaps [rsp+0x20], xmm1
000076c1d9dd09a1  lea rdi, [rsp]
000076c1d9dd09a5  mov esi, 0x00
000076c1d9dd09aa  mov rax, 0x5EA58B9E0530
000076c1d9dd09b4  call rax
000076c1d9dd09b6  movaps xmm15, [rsp]
000076c1d9dd09bb  add rsp, 0x30
000076c1d9dd09bf  vmovaps xmm0, [rsp]
000076c1d9dd09c4  vmovaps xmm1, [rsp+0x10]
000076c1d9dd09ca  vmovaps xmm2, [rsp+0x20]
000076c1d9dd09d0  vmovaps xmm3, [rsp+0x30]
000076c1d9dd09d6  vmovaps xmm4, [rsp+0x40]
000076c1d9dd09dc  vmovaps xmm5, [rsp+0x50]
000076c1d9dd09e2  vmovaps xmm6, [rsp+0x60]
000076c1d9dd09e8  vmovaps xmm7, [rsp+0x70]
000076c1d9dd09ee  vmovaps xmm8, [rsp+0x80]
000076c1d9dd09f7  vmovaps xmm9, [rsp+0x90]
000076c1d9dd0a00  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd0a09  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd0a12  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd0a1b  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd0a24  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd0a2d  add rsp, 0xF0
000076c1d9dd0a34  pop r11
000076c1d9dd0a36  pop r10
000076c1d9dd0a38  pop r9
000076c1d9dd0a3a  pop r8
000076c1d9dd0a3c  pop rsi
000076c1d9dd0a3d  pop rdi
000076c1d9dd0a3e  pop rdx
000076c1d9dd0a3f  pop rcx
000076c1d9dd0a40  pop rax
000076c1d9dd0a41  add rsp, 0x08
000076c1d9dd0a45  jmp 0x000076C1D9DCF617
000076c1d9dd0a4a  sub rsp, 0x08
000076c1d9dd0a4e  push rax
000076c1d9dd0a4f  push rcx
000076c1d9dd0a50  push rdx
000076c1d9dd0a51  push rdi
000076c1d9dd0a52  push rsi
000076c1d9dd0a53  push r8
000076c1d9dd0a55  push r9
000076c1d9dd0a57  push r10
000076c1d9dd0a59  push r11
000076c1d9dd0a5b  sub rsp, 0xF0
000076c1d9dd0a62  vmovaps [rsp], xmm0
000076c1d9dd0a67  vmovaps [rsp+0x10], xmm2
000076c1d9dd0a6d  vmovaps [rsp+0x20], xmm3
000076c1d9dd0a73  vmovaps [rsp+0x30], xmm4
000076c1d9dd0a79  vmovaps [rsp+0x40], xmm5
000076c1d9dd0a7f  vmovaps [rsp+0x50], xmm6
000076c1d9dd0a85  vmovaps [rsp+0x60], xmm7
000076c1d9dd0a8b  vmovaps [rsp+0x70], xmm8
000076c1d9dd0a91  vmovaps [rsp+0x80], xmm9
000076c1d9dd0a9a  vmovaps [rsp+0x90], xmm10
000076c1d9dd0aa3  vmovaps [rsp+0xA0], xmm11
000076c1d9dd0aac  vmovaps [rsp+0xB0], xmm12
000076c1d9dd0ab5  vmovaps [rsp+0xC0], xmm13
000076c1d9dd0abe  vmovaps [rsp+0xD0], xmm14
000076c1d9dd0ac7  vmovaps [rsp+0xE0], xmm15
000076c1d9dd0ad0  sub rsp, 0x30
000076c1d9dd0ad4  movaps [rsp], xmm1
000076c1d9dd0ad8  movaps [rsp+0x10], xmm14
000076c1d9dd0ade  movaps [rsp+0x20], xmm10
000076c1d9dd0ae4  lea rdi, [rsp]
000076c1d9dd0ae8  mov esi, 0x00
000076c1d9dd0aed  mov rax, 0x5EA58B9E0530
000076c1d9dd0af7  call rax
000076c1d9dd0af9  movaps xmm1, [rsp]
000076c1d9dd0afd  add rsp, 0x30
000076c1d9dd0b01  vmovaps xmm0, [rsp]
000076c1d9dd0b06  vmovaps xmm2, [rsp+0x10]
000076c1d9dd0b0c  vmovaps xmm3, [rsp+0x20]
000076c1d9dd0b12  vmovaps xmm4, [rsp+0x30]
000076c1d9dd0b18  vmovaps xmm5, [rsp+0x40]
000076c1d9dd0b1e  vmovaps xmm6, [rsp+0x50]
000076c1d9dd0b24  vmovaps xmm7, [rsp+0x60]
000076c1d9dd0b2a  vmovaps xmm8, [rsp+0x70]
000076c1d9dd0b30  vmovaps xmm9, [rsp+0x80]
000076c1d9dd0b39  vmovaps xmm10, [rsp+0x90]
000076c1d9dd0b42  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd0b4b  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd0b54  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd0b5d  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd0b66  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd0b6f  add rsp, 0xF0
000076c1d9dd0b76  pop r11
000076c1d9dd0b78  pop r10
000076c1d9dd0b7a  pop r9
000076c1d9dd0b7c  pop r8
000076c1d9dd0b7e  pop rsi
000076c1d9dd0b7f  pop rdi
000076c1d9dd0b80  pop rdx
000076c1d9dd0b81  pop rcx
000076c1d9dd0b82  pop rax
000076c1d9dd0b83  add rsp, 0x08
000076c1d9dd0b87  jmp 0x000076C1D9DCF631
000076c1d9dd0b8c  sub rsp, 0x08
000076c1d9dd0b90  push rax
000076c1d9dd0b91  push rcx
000076c1d9dd0b92  push rdx
000076c1d9dd0b93  push rdi
000076c1d9dd0b94  push rsi
000076c1d9dd0b95  push r8
000076c1d9dd0b97  push r9
000076c1d9dd0b99  push r10
000076c1d9dd0b9b  push r11
000076c1d9dd0b9d  sub rsp, 0xF0
000076c1d9dd0ba4  vmovaps [rsp], xmm0
000076c1d9dd0ba9  vmovaps [rsp+0x10], xmm1
000076c1d9dd0baf  vmovaps [rsp+0x20], xmm2
000076c1d9dd0bb5  vmovaps [rsp+0x30], xmm3
000076c1d9dd0bbb  vmovaps [rsp+0x40], xmm4
000076c1d9dd0bc1  vmovaps [rsp+0x50], xmm5
000076c1d9dd0bc7  vmovaps [rsp+0x60], xmm6
000076c1d9dd0bcd  vmovaps [rsp+0x70], xmm7
000076c1d9dd0bd3  vmovaps [rsp+0x80], xmm8
000076c1d9dd0bdc  vmovaps [rsp+0x90], xmm9
000076c1d9dd0be5  vmovaps [rsp+0xA0], xmm10
000076c1d9dd0bee  vmovaps [rsp+0xB0], xmm11
000076c1d9dd0bf7  vmovaps [rsp+0xC0], xmm12
000076c1d9dd0c00  vmovaps [rsp+0xD0], xmm14
000076c1d9dd0c09  vmovaps [rsp+0xE0], xmm15
000076c1d9dd0c12  sub rsp, 0x30
000076c1d9dd0c16  movaps [rsp], xmm13
000076c1d9dd0c1b  movaps [rsp+0x10], xmm14
000076c1d9dd0c21  movaps [rsp+0x20], xmm2
000076c1d9dd0c26  lea rdi, [rsp]
000076c1d9dd0c2a  mov esi, 0x00
000076c1d9dd0c2f  mov rax, 0x5EA58B9E0530
000076c1d9dd0c39  call rax
000076c1d9dd0c3b  movaps xmm13, [rsp]
000076c1d9dd0c40  add rsp, 0x30
000076c1d9dd0c44  vmovaps xmm0, [rsp]
000076c1d9dd0c49  vmovaps xmm1, [rsp+0x10]
000076c1d9dd0c4f  vmovaps xmm2, [rsp+0x20]
000076c1d9dd0c55  vmovaps xmm3, [rsp+0x30]
000076c1d9dd0c5b  vmovaps xmm4, [rsp+0x40]
000076c1d9dd0c61  vmovaps xmm5, [rsp+0x50]
000076c1d9dd0c67  vmovaps xmm6, [rsp+0x60]
000076c1d9dd0c6d  vmovaps xmm7, [rsp+0x70]
000076c1d9dd0c73  vmovaps xmm8, [rsp+0x80]
000076c1d9dd0c7c  vmovaps xmm9, [rsp+0x90]
000076c1d9dd0c85  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd0c8e  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd0c97  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd0ca0  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd0ca9  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd0cb2  add rsp, 0xF0
000076c1d9dd0cb9  pop r11
000076c1d9dd0cbb  pop r10
000076c1d9dd0cbd  pop r9
000076c1d9dd0cbf  pop r8
000076c1d9dd0cc1  pop rsi
000076c1d9dd0cc2  pop rdi
000076c1d9dd0cc3  pop rdx
000076c1d9dd0cc4  pop rcx
000076c1d9dd0cc5  pop rax
000076c1d9dd0cc6  add rsp, 0x08
000076c1d9dd0cca  jmp 0x000076C1D9DCF64C
000076c1d9dd0ccf  sub rsp, 0x08
000076c1d9dd0cd3  push rax
000076c1d9dd0cd4  push rcx
000076c1d9dd0cd5  push rdx
000076c1d9dd0cd6  push rdi
000076c1d9dd0cd7  push rsi
000076c1d9dd0cd8  push r8
000076c1d9dd0cda  push r9
000076c1d9dd0cdc  push r10
000076c1d9dd0cde  push r11
000076c1d9dd0ce0  sub rsp, 0xF0
000076c1d9dd0ce7  vmovaps [rsp], xmm0
000076c1d9dd0cec  vmovaps [rsp+0x10], xmm2
000076c1d9dd0cf2  vmovaps [rsp+0x20], xmm3
000076c1d9dd0cf8  vmovaps [rsp+0x30], xmm4
000076c1d9dd0cfe  vmovaps [rsp+0x40], xmm5
000076c1d9dd0d04  vmovaps [rsp+0x50], xmm6
000076c1d9dd0d0a  vmovaps [rsp+0x60], xmm7
000076c1d9dd0d10  vmovaps [rsp+0x70], xmm8
000076c1d9dd0d16  vmovaps [rsp+0x80], xmm9
000076c1d9dd0d1f  vmovaps [rsp+0x90], xmm10
000076c1d9dd0d28  vmovaps [rsp+0xA0], xmm11
000076c1d9dd0d31  vmovaps [rsp+0xB0], xmm12
000076c1d9dd0d3a  vmovaps [rsp+0xC0], xmm13
000076c1d9dd0d43  vmovaps [rsp+0xD0], xmm14
000076c1d9dd0d4c  vmovaps [rsp+0xE0], xmm15
000076c1d9dd0d55  sub rsp, 0x30
000076c1d9dd0d59  movaps [rsp], xmm1
000076c1d9dd0d5d  movaps [rsp+0x10], xmm10
000076c1d9dd0d63  movaps [rsp+0x20], xmm2
000076c1d9dd0d68  lea rdi, [rsp]
000076c1d9dd0d6c  mov esi, 0x00
000076c1d9dd0d71  mov rax, 0x5EA58B9E0530
000076c1d9dd0d7b  call rax
000076c1d9dd0d7d  movaps xmm1, [rsp]
000076c1d9dd0d81  add rsp, 0x30
000076c1d9dd0d85  vmovaps xmm0, [rsp]
000076c1d9dd0d8a  vmovaps xmm2, [rsp+0x10]
000076c1d9dd0d90  vmovaps xmm3, [rsp+0x20]
000076c1d9dd0d96  vmovaps xmm4, [rsp+0x30]
000076c1d9dd0d9c  vmovaps xmm5, [rsp+0x40]
000076c1d9dd0da2  vmovaps xmm6, [rsp+0x50]
000076c1d9dd0da8  vmovaps xmm7, [rsp+0x60]
000076c1d9dd0dae  vmovaps xmm8, [rsp+0x70]
000076c1d9dd0db4  vmovaps xmm9, [rsp+0x80]
000076c1d9dd0dbd  vmovaps xmm10, [rsp+0x90]
000076c1d9dd0dc6  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd0dcf  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd0dd8  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd0de1  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd0dea  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd0df3  add rsp, 0xF0
000076c1d9dd0dfa  pop r11
000076c1d9dd0dfc  pop r10
000076c1d9dd0dfe  pop r9
000076c1d9dd0e00  pop r8
000076c1d9dd0e02  pop rsi
000076c1d9dd0e03  pop rdi
000076c1d9dd0e04  pop rdx
000076c1d9dd0e05  pop rcx
000076c1d9dd0e06  pop rax
000076c1d9dd0e07  add rsp, 0x08
000076c1d9dd0e0b  jmp 0x000076C1D9DCF6B4
000076c1d9dd0e10  sub rsp, 0x08
000076c1d9dd0e14  push rax
000076c1d9dd0e15  push rcx
000076c1d9dd0e16  push rdx
000076c1d9dd0e17  push rdi
000076c1d9dd0e18  push rsi
000076c1d9dd0e19  push r8
000076c1d9dd0e1b  push r9
000076c1d9dd0e1d  push r10
000076c1d9dd0e1f  push r11
000076c1d9dd0e21  sub rsp, 0xF0
000076c1d9dd0e28  vmovaps [rsp], xmm0
000076c1d9dd0e2d  vmovaps [rsp+0x10], xmm1
000076c1d9dd0e33  vmovaps [rsp+0x20], xmm2
000076c1d9dd0e39  vmovaps [rsp+0x30], xmm3
000076c1d9dd0e3f  vmovaps [rsp+0x40], xmm4
000076c1d9dd0e45  vmovaps [rsp+0x50], xmm5
000076c1d9dd0e4b  vmovaps [rsp+0x60], xmm6
000076c1d9dd0e51  vmovaps [rsp+0x70], xmm7
000076c1d9dd0e57  vmovaps [rsp+0x80], xmm8
000076c1d9dd0e60  vmovaps [rsp+0x90], xmm9
000076c1d9dd0e69  vmovaps [rsp+0xA0], xmm10
000076c1d9dd0e72  vmovaps [rsp+0xB0], xmm11
000076c1d9dd0e7b  vmovaps [rsp+0xC0], xmm12
000076c1d9dd0e84  vmovaps [rsp+0xD0], xmm13
000076c1d9dd0e8d  vmovaps [rsp+0xE0], xmm14
000076c1d9dd0e96  sub rsp, 0x30
000076c1d9dd0e9a  movaps [rsp], xmm15
000076c1d9dd0e9f  movaps [rsp+0x10], xmm10
000076c1d9dd0ea5  movaps [rsp+0x20], xmm2
000076c1d9dd0eaa  lea rdi, [rsp]
000076c1d9dd0eae  mov esi, 0x00
000076c1d9dd0eb3  mov rax, 0x5EA58B9E0530
000076c1d9dd0ebd  call rax
000076c1d9dd0ebf  movaps xmm15, [rsp]
000076c1d9dd0ec4  add rsp, 0x30
000076c1d9dd0ec8  vmovaps xmm0, [rsp]
000076c1d9dd0ecd  vmovaps xmm1, [rsp+0x10]
000076c1d9dd0ed3  vmovaps xmm2, [rsp+0x20]
000076c1d9dd0ed9  vmovaps xmm3, [rsp+0x30]
000076c1d9dd0edf  vmovaps xmm4, [rsp+0x40]
000076c1d9dd0ee5  vmovaps xmm5, [rsp+0x50]
000076c1d9dd0eeb  vmovaps xmm6, [rsp+0x60]
000076c1d9dd0ef1  vmovaps xmm7, [rsp+0x70]
000076c1d9dd0ef7  vmovaps xmm8, [rsp+0x80]
000076c1d9dd0f00  vmovaps xmm9, [rsp+0x90]
000076c1d9dd0f09  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd0f12  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd0f1b  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd0f24  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd0f2d  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd0f36  add rsp, 0xF0
000076c1d9dd0f3d  pop r11
000076c1d9dd0f3f  pop r10
000076c1d9dd0f41  pop r9
000076c1d9dd0f43  pop r8
000076c1d9dd0f45  pop rsi
000076c1d9dd0f46  pop rdi
000076c1d9dd0f47  pop rdx
000076c1d9dd0f48  pop rcx
000076c1d9dd0f49  pop rax
000076c1d9dd0f4a  add rsp, 0x08
000076c1d9dd0f4e  jmp 0x000076C1D9DCF706
000076c1d9dd0f53  sub rsp, 0x08
000076c1d9dd0f57  push rax
000076c1d9dd0f58  push rcx
000076c1d9dd0f59  push rdx
000076c1d9dd0f5a  push rdi
000076c1d9dd0f5b  push rsi
000076c1d9dd0f5c  push r8
000076c1d9dd0f5e  push r9
000076c1d9dd0f60  push r10
000076c1d9dd0f62  push r11
000076c1d9dd0f64  sub rsp, 0xF0
000076c1d9dd0f6b  vmovaps [rsp], xmm0
000076c1d9dd0f70  vmovaps [rsp+0x10], xmm2
000076c1d9dd0f76  vmovaps [rsp+0x20], xmm3
000076c1d9dd0f7c  vmovaps [rsp+0x30], xmm4
000076c1d9dd0f82  vmovaps [rsp+0x40], xmm5
000076c1d9dd0f88  vmovaps [rsp+0x50], xmm6
000076c1d9dd0f8e  vmovaps [rsp+0x60], xmm7
000076c1d9dd0f94  vmovaps [rsp+0x70], xmm8
000076c1d9dd0f9a  vmovaps [rsp+0x80], xmm9
000076c1d9dd0fa3  vmovaps [rsp+0x90], xmm10
000076c1d9dd0fac  vmovaps [rsp+0xA0], xmm11
000076c1d9dd0fb5  vmovaps [rsp+0xB0], xmm12
000076c1d9dd0fbe  vmovaps [rsp+0xC0], xmm13
000076c1d9dd0fc7  vmovaps [rsp+0xD0], xmm14
000076c1d9dd0fd0  vmovaps [rsp+0xE0], xmm15
000076c1d9dd0fd9  sub rsp, 0x30
000076c1d9dd0fdd  movaps [rsp], xmm1
000076c1d9dd0fe1  movaps [rsp+0x10], xmm10
000076c1d9dd0fe7  movaps [rsp+0x20], xmm12
000076c1d9dd0fed  lea rdi, [rsp]
000076c1d9dd0ff1  mov esi, 0x00
000076c1d9dd0ff6  mov rax, 0x5EA58B9E0530
000076c1d9dd1000  call rax
000076c1d9dd1002  movaps xmm1, [rsp]
000076c1d9dd1006  add rsp, 0x30
000076c1d9dd100a  vmovaps xmm0, [rsp]
000076c1d9dd100f  vmovaps xmm2, [rsp+0x10]
000076c1d9dd1015  vmovaps xmm3, [rsp+0x20]
000076c1d9dd101b  vmovaps xmm4, [rsp+0x30]
000076c1d9dd1021  vmovaps xmm5, [rsp+0x40]
000076c1d9dd1027  vmovaps xmm6, [rsp+0x50]
000076c1d9dd102d  vmovaps xmm7, [rsp+0x60]
000076c1d9dd1033  vmovaps xmm8, [rsp+0x70]
000076c1d9dd1039  vmovaps xmm9, [rsp+0x80]
000076c1d9dd1042  vmovaps xmm10, [rsp+0x90]
000076c1d9dd104b  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd1054  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd105d  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd1066  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd106f  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd1078  add rsp, 0xF0
000076c1d9dd107f  pop r11
000076c1d9dd1081  pop r10
000076c1d9dd1083  pop r9
000076c1d9dd1085  pop r8
000076c1d9dd1087  pop rsi
000076c1d9dd1088  pop rdi
000076c1d9dd1089  pop rdx
000076c1d9dd108a  pop rcx
000076c1d9dd108b  pop rax
000076c1d9dd108c  add rsp, 0x08
000076c1d9dd1090  jmp 0x000076C1D9DCF732
000076c1d9dd1095  sub rsp, 0x08
000076c1d9dd1099  push rax
000076c1d9dd109a  push rcx
000076c1d9dd109b  push rdx
000076c1d9dd109c  push rdi
000076c1d9dd109d  push rsi
000076c1d9dd109e  push r8
000076c1d9dd10a0  push r9
000076c1d9dd10a2  push r10
000076c1d9dd10a4  push r11
000076c1d9dd10a6  sub rsp, 0xF0
000076c1d9dd10ad  vmovaps [rsp], xmm0
000076c1d9dd10b2  vmovaps [rsp+0x10], xmm1
000076c1d9dd10b8  vmovaps [rsp+0x20], xmm2
000076c1d9dd10be  vmovaps [rsp+0x30], xmm3
000076c1d9dd10c4  vmovaps [rsp+0x40], xmm4
000076c1d9dd10ca  vmovaps [rsp+0x50], xmm5
000076c1d9dd10d0  vmovaps [rsp+0x60], xmm6
000076c1d9dd10d6  vmovaps [rsp+0x70], xmm7
000076c1d9dd10dc  vmovaps [rsp+0x80], xmm8
000076c1d9dd10e5  vmovaps [rsp+0x90], xmm9
000076c1d9dd10ee  vmovaps [rsp+0xA0], xmm10
000076c1d9dd10f7  vmovaps [rsp+0xB0], xmm11
000076c1d9dd1100  vmovaps [rsp+0xC0], xmm12
000076c1d9dd1109  vmovaps [rsp+0xD0], xmm13
000076c1d9dd1112  vmovaps [rsp+0xE0], xmm14
000076c1d9dd111b  sub rsp, 0x30
000076c1d9dd111f  movaps [rsp], xmm15
000076c1d9dd1124  movaps [rsp+0x10], xmm10
000076c1d9dd112a  movaps [rsp+0x20], xmm12
000076c1d9dd1130  lea rdi, [rsp]
000076c1d9dd1134  mov esi, 0x00
000076c1d9dd1139  mov rax, 0x5EA58B9E0530
000076c1d9dd1143  call rax
000076c1d9dd1145  movaps xmm15, [rsp]
000076c1d9dd114a  add rsp, 0x30
000076c1d9dd114e  vmovaps xmm0, [rsp]
000076c1d9dd1153  vmovaps xmm1, [rsp+0x10]
000076c1d9dd1159  vmovaps xmm2, [rsp+0x20]
000076c1d9dd115f  vmovaps xmm3, [rsp+0x30]
000076c1d9dd1165  vmovaps xmm4, [rsp+0x40]
000076c1d9dd116b  vmovaps xmm5, [rsp+0x50]
000076c1d9dd1171  vmovaps xmm6, [rsp+0x60]
000076c1d9dd1177  vmovaps xmm7, [rsp+0x70]
000076c1d9dd117d  vmovaps xmm8, [rsp+0x80]
000076c1d9dd1186  vmovaps xmm9, [rsp+0x90]
000076c1d9dd118f  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd1198  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd11a1  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd11aa  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd11b3  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd11bc  add rsp, 0xF0
000076c1d9dd11c3  pop r11
000076c1d9dd11c5  pop r10
000076c1d9dd11c7  pop r9
000076c1d9dd11c9  pop r8
000076c1d9dd11cb  pop rsi
000076c1d9dd11cc  pop rdi
000076c1d9dd11cd  pop rdx
000076c1d9dd11ce  pop rcx
000076c1d9dd11cf  pop rax
000076c1d9dd11d0  add rsp, 0x08
000076c1d9dd11d4  jmp 0x000076C1D9DCF75E
000076c1d9dd11d9  call 0x000076C1D9BFF430
000076c1d9dd11de  jmp 0x000076C1D9DCF7EE
000076c1d9dd11e3  call 0x000076C1D9BFF430
000076c1d9dd11e8  jmp 0x000076C1D9DCF801
000076c1d9dd11ed  sub rsp, 0x08
000076c1d9dd11f1  push rax
000076c1d9dd11f2  push rcx
000076c1d9dd11f3  push rdx
000076c1d9dd11f4  push rdi
000076c1d9dd11f5  push rsi
000076c1d9dd11f6  push r8
000076c1d9dd11f8  push r9
000076c1d9dd11fa  push r10
000076c1d9dd11fc  push r11
000076c1d9dd11fe  sub rsp, 0xF0
000076c1d9dd1205  vmovaps [rsp], xmm0
000076c1d9dd120a  vmovaps [rsp+0x10], xmm2
000076c1d9dd1210  vmovaps [rsp+0x20], xmm3
000076c1d9dd1216  vmovaps [rsp+0x30], xmm4
000076c1d9dd121c  vmovaps [rsp+0x40], xmm5
000076c1d9dd1222  vmovaps [rsp+0x50], xmm6
000076c1d9dd1228  vmovaps [rsp+0x60], xmm7
000076c1d9dd122e  vmovaps [rsp+0x70], xmm8
000076c1d9dd1234  vmovaps [rsp+0x80], xmm9
000076c1d9dd123d  vmovaps [rsp+0x90], xmm10
000076c1d9dd1246  vmovaps [rsp+0xA0], xmm11
000076c1d9dd124f  vmovaps [rsp+0xB0], xmm12
000076c1d9dd1258  vmovaps [rsp+0xC0], xmm13
000076c1d9dd1261  vmovaps [rsp+0xD0], xmm14
000076c1d9dd126a  vmovaps [rsp+0xE0], xmm15
000076c1d9dd1273  sub rsp, 0x30
000076c1d9dd1277  movaps [rsp], xmm1
000076c1d9dd127b  movaps [rsp+0x10], xmm13
000076c1d9dd1281  movaps [rsp+0x20], xmm2
000076c1d9dd1286  lea rdi, [rsp]
000076c1d9dd128a  mov esi, 0x00
000076c1d9dd128f  mov rax, 0x5EA58B9E0530
000076c1d9dd1299  call rax
000076c1d9dd129b  movaps xmm1, [rsp]
000076c1d9dd129f  add rsp, 0x30
000076c1d9dd12a3  vmovaps xmm0, [rsp]
000076c1d9dd12a8  vmovaps xmm2, [rsp+0x10]
000076c1d9dd12ae  vmovaps xmm3, [rsp+0x20]
000076c1d9dd12b4  vmovaps xmm4, [rsp+0x30]
000076c1d9dd12ba  vmovaps xmm5, [rsp+0x40]
000076c1d9dd12c0  vmovaps xmm6, [rsp+0x50]
000076c1d9dd12c6  vmovaps xmm7, [rsp+0x60]
000076c1d9dd12cc  vmovaps xmm8, [rsp+0x70]
000076c1d9dd12d2  vmovaps xmm9, [rsp+0x80]
000076c1d9dd12db  vmovaps xmm10, [rsp+0x90]
000076c1d9dd12e4  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd12ed  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd12f6  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd12ff  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd1308  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd1311  add rsp, 0xF0
000076c1d9dd1318  pop r11
000076c1d9dd131a  pop r10
000076c1d9dd131c  pop r9
000076c1d9dd131e  pop r8
000076c1d9dd1320  pop rsi
000076c1d9dd1321  pop rdi
000076c1d9dd1322  pop rdx
000076c1d9dd1323  pop rcx
000076c1d9dd1324  pop rax
000076c1d9dd1325  add rsp, 0x08
000076c1d9dd1329  jmp 0x000076C1D9DCF82C
000076c1d9dd132e  call 0x000076C1D9C0E760
000076c1d9dd1333  jmp 0x000076C1D9DCF839
000076c1d9dd1338  sub rsp, 0x08
000076c1d9dd133c  push rax
000076c1d9dd133d  push rcx
000076c1d9dd133e  push rdx
000076c1d9dd133f  push rdi
000076c1d9dd1340  push rsi
000076c1d9dd1341  push r8
000076c1d9dd1343  push r9
000076c1d9dd1345  push r10
000076c1d9dd1347  push r11
000076c1d9dd1349  sub rsp, 0xF0
000076c1d9dd1350  vmovaps [rsp], xmm0
000076c1d9dd1355  vmovaps [rsp+0x10], xmm1
000076c1d9dd135b  vmovaps [rsp+0x20], xmm2
000076c1d9dd1361  vmovaps [rsp+0x30], xmm3
000076c1d9dd1367  vmovaps [rsp+0x40], xmm4
000076c1d9dd136d  vmovaps [rsp+0x50], xmm5
000076c1d9dd1373  vmovaps [rsp+0x60], xmm6
000076c1d9dd1379  vmovaps [rsp+0x70], xmm7
000076c1d9dd137f  vmovaps [rsp+0x80], xmm8
000076c1d9dd1388  vmovaps [rsp+0x90], xmm9
000076c1d9dd1391  vmovaps [rsp+0xA0], xmm10
000076c1d9dd139a  vmovaps [rsp+0xB0], xmm11
000076c1d9dd13a3  vmovaps [rsp+0xC0], xmm12
000076c1d9dd13ac  vmovaps [rsp+0xD0], xmm14
000076c1d9dd13b5  vmovaps [rsp+0xE0], xmm15
000076c1d9dd13be  sub rsp, 0x30
000076c1d9dd13c2  movaps [rsp], xmm13
000076c1d9dd13c7  movaps [rsp+0x10], xmm2
000076c1d9dd13cc  movaps [rsp+0x20], xmm1
000076c1d9dd13d1  lea rdi, [rsp]
000076c1d9dd13d5  mov esi, 0x00
000076c1d9dd13da  mov rax, 0x5EA58B9E0530
000076c1d9dd13e4  call rax
000076c1d9dd13e6  movaps xmm13, [rsp]
000076c1d9dd13eb  add rsp, 0x30
000076c1d9dd13ef  vmovaps xmm0, [rsp]
000076c1d9dd13f4  vmovaps xmm1, [rsp+0x10]
000076c1d9dd13fa  vmovaps xmm2, [rsp+0x20]
000076c1d9dd1400  vmovaps xmm3, [rsp+0x30]
000076c1d9dd1406  vmovaps xmm4, [rsp+0x40]
000076c1d9dd140c  vmovaps xmm5, [rsp+0x50]
000076c1d9dd1412  vmovaps xmm6, [rsp+0x60]
000076c1d9dd1418  vmovaps xmm7, [rsp+0x70]
000076c1d9dd141e  vmovaps xmm8, [rsp+0x80]
000076c1d9dd1427  vmovaps xmm9, [rsp+0x90]
000076c1d9dd1430  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd1439  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd1442  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd144b  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd1454  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd145d  add rsp, 0xF0
000076c1d9dd1464  pop r11
000076c1d9dd1466  pop r10
000076c1d9dd1468  pop r9
000076c1d9dd146a  pop r8
000076c1d9dd146c  pop rsi
000076c1d9dd146d  pop rdi
000076c1d9dd146e  pop rdx
000076c1d9dd146f  pop rcx
000076c1d9dd1470  pop rax
000076c1d9dd1471  add rsp, 0x08
000076c1d9dd1475  jmp 0x000076C1D9DCF878
000076c1d9dd147a  sub rsp, 0x08
000076c1d9dd147e  push rax
000076c1d9dd147f  push rcx
000076c1d9dd1480  push rdx
000076c1d9dd1481  push rdi
000076c1d9dd1482  push rsi
000076c1d9dd1483  push r8
000076c1d9dd1485  push r9
000076c1d9dd1487  push r10
000076c1d9dd1489  push r11
000076c1d9dd148b  sub rsp, 0xF0
000076c1d9dd1492  vmovaps [rsp], xmm0
000076c1d9dd1497  vmovaps [rsp+0x10], xmm2
000076c1d9dd149d  vmovaps [rsp+0x20], xmm3
000076c1d9dd14a3  vmovaps [rsp+0x30], xmm4
000076c1d9dd14a9  vmovaps [rsp+0x40], xmm5
000076c1d9dd14af  vmovaps [rsp+0x50], xmm6
000076c1d9dd14b5  vmovaps [rsp+0x60], xmm7
000076c1d9dd14bb  vmovaps [rsp+0x70], xmm8
000076c1d9dd14c1  vmovaps [rsp+0x80], xmm9
000076c1d9dd14ca  vmovaps [rsp+0x90], xmm10
000076c1d9dd14d3  vmovaps [rsp+0xA0], xmm11
000076c1d9dd14dc  vmovaps [rsp+0xB0], xmm12
000076c1d9dd14e5  vmovaps [rsp+0xC0], xmm13
000076c1d9dd14ee  vmovaps [rsp+0xD0], xmm14
000076c1d9dd14f7  vmovaps [rsp+0xE0], xmm15
000076c1d9dd1500  sub rsp, 0x30
000076c1d9dd1504  movaps [rsp], xmm1
000076c1d9dd1508  movaps [rsp+0x10], xmm15
000076c1d9dd150e  movaps [rsp+0x20], xmm2
000076c1d9dd1513  lea rdi, [rsp]
000076c1d9dd1517  mov esi, 0x00
000076c1d9dd151c  mov rax, 0x5EA58B9E0530
000076c1d9dd1526  call rax
000076c1d9dd1528  movaps xmm1, [rsp]
000076c1d9dd152c  add rsp, 0x30
000076c1d9dd1530  vmovaps xmm0, [rsp]
000076c1d9dd1535  vmovaps xmm2, [rsp+0x10]
000076c1d9dd153b  vmovaps xmm3, [rsp+0x20]
000076c1d9dd1541  vmovaps xmm4, [rsp+0x30]
000076c1d9dd1547  vmovaps xmm5, [rsp+0x40]
000076c1d9dd154d  vmovaps xmm6, [rsp+0x50]
000076c1d9dd1553  vmovaps xmm7, [rsp+0x60]
000076c1d9dd1559  vmovaps xmm8, [rsp+0x70]
000076c1d9dd155f  vmovaps xmm9, [rsp+0x80]
000076c1d9dd1568  vmovaps xmm10, [rsp+0x90]
000076c1d9dd1571  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd157a  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd1583  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd158c  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd1595  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd159e  add rsp, 0xF0
000076c1d9dd15a5  pop r11
000076c1d9dd15a7  pop r10
000076c1d9dd15a9  pop r9
000076c1d9dd15ab  pop r8
000076c1d9dd15ad  pop rsi
000076c1d9dd15ae  pop rdi
000076c1d9dd15af  pop rdx
000076c1d9dd15b0  pop rcx
000076c1d9dd15b1  pop rax
000076c1d9dd15b2  add rsp, 0x08
000076c1d9dd15b6  jmp 0x000076C1D9DCF8AC
000076c1d9dd15bb  sub rsp, 0x08
000076c1d9dd15bf  push rax
000076c1d9dd15c0  push rcx
000076c1d9dd15c1  push rdx
000076c1d9dd15c2  push rdi
000076c1d9dd15c3  push rsi
000076c1d9dd15c4  push r8
000076c1d9dd15c6  push r9
000076c1d9dd15c8  push r10
000076c1d9dd15ca  push r11
000076c1d9dd15cc  sub rsp, 0xF0
000076c1d9dd15d3  vmovaps [rsp], xmm0
000076c1d9dd15d8  vmovaps [rsp+0x10], xmm1
000076c1d9dd15de  vmovaps [rsp+0x20], xmm2
000076c1d9dd15e4  vmovaps [rsp+0x30], xmm3
000076c1d9dd15ea  vmovaps [rsp+0x40], xmm4
000076c1d9dd15f0  vmovaps [rsp+0x50], xmm5
000076c1d9dd15f6  vmovaps [rsp+0x60], xmm6
000076c1d9dd15fc  vmovaps [rsp+0x70], xmm7
000076c1d9dd1602  vmovaps [rsp+0x80], xmm8
000076c1d9dd160b  vmovaps [rsp+0x90], xmm9
000076c1d9dd1614  vmovaps [rsp+0xA0], xmm10
000076c1d9dd161d  vmovaps [rsp+0xB0], xmm11
000076c1d9dd1626  vmovaps [rsp+0xC0], xmm12
000076c1d9dd162f  vmovaps [rsp+0xD0], xmm13
000076c1d9dd1638  vmovaps [rsp+0xE0], xmm15
000076c1d9dd1641  sub rsp, 0x30
000076c1d9dd1645  movaps [rsp], xmm14
000076c1d9dd164a  movaps [rsp+0x10], xmm2
000076c1d9dd164f  movaps [rsp+0x20], xmm15
000076c1d9dd1655  lea rdi, [rsp]
000076c1d9dd1659  mov esi, 0x00
000076c1d9dd165e  mov rax, 0x5EA58B9E0530
000076c1d9dd1668  call rax
000076c1d9dd166a  movaps xmm14, [rsp]
000076c1d9dd166f  add rsp, 0x30
000076c1d9dd1673  vmovaps xmm0, [rsp]
000076c1d9dd1678  vmovaps xmm1, [rsp+0x10]
000076c1d9dd167e  vmovaps xmm2, [rsp+0x20]
000076c1d9dd1684  vmovaps xmm3, [rsp+0x30]
000076c1d9dd168a  vmovaps xmm4, [rsp+0x40]
000076c1d9dd1690  vmovaps xmm5, [rsp+0x50]
000076c1d9dd1696  vmovaps xmm6, [rsp+0x60]
000076c1d9dd169c  vmovaps xmm7, [rsp+0x70]
000076c1d9dd16a2  vmovaps xmm8, [rsp+0x80]
000076c1d9dd16ab  vmovaps xmm9, [rsp+0x90]
000076c1d9dd16b4  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd16bd  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd16c6  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd16cf  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd16d8  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd16e1  add rsp, 0xF0
000076c1d9dd16e8  pop r11
000076c1d9dd16ea  pop r10
000076c1d9dd16ec  pop r9
000076c1d9dd16ee  pop r8
000076c1d9dd16f0  pop rsi
000076c1d9dd16f1  pop rdi
000076c1d9dd16f2  pop rdx
000076c1d9dd16f3  pop rcx
000076c1d9dd16f4  pop rax
000076c1d9dd16f5  add rsp, 0x08
000076c1d9dd16f9  jmp 0x000076C1D9DCF8E7
000076c1d9dd16fe  sub rsp, 0x08
000076c1d9dd1702  push rax
000076c1d9dd1703  push rcx
000076c1d9dd1704  push rdx
000076c1d9dd1705  push rdi
000076c1d9dd1706  push rsi
000076c1d9dd1707  push r8
000076c1d9dd1709  push r9
000076c1d9dd170b  push r10
000076c1d9dd170d  push r11
000076c1d9dd170f  sub rsp, 0xF0
000076c1d9dd1716  vmovaps [rsp], xmm0
000076c1d9dd171b  vmovaps [rsp+0x10], xmm1
000076c1d9dd1721  vmovaps [rsp+0x20], xmm2
000076c1d9dd1727  vmovaps [rsp+0x30], xmm3
000076c1d9dd172d  vmovaps [rsp+0x40], xmm4
000076c1d9dd1733  vmovaps [rsp+0x50], xmm5
000076c1d9dd1739  vmovaps [rsp+0x60], xmm6
000076c1d9dd173f  vmovaps [rsp+0x70], xmm7
000076c1d9dd1745  vmovaps [rsp+0x80], xmm8
000076c1d9dd174e  vmovaps [rsp+0x90], xmm9
000076c1d9dd1757  vmovaps [rsp+0xA0], xmm10
000076c1d9dd1760  vmovaps [rsp+0xB0], xmm11
000076c1d9dd1769  vmovaps [rsp+0xC0], xmm12
000076c1d9dd1772  vmovaps [rsp+0xD0], xmm13
000076c1d9dd177b  vmovaps [rsp+0xE0], xmm14
000076c1d9dd1784  sub rsp, 0x30
000076c1d9dd1788  movaps [rsp], xmm15
000076c1d9dd178d  movaps [rsp+0x10], xmm2
000076c1d9dd1792  movaps [rsp+0x20], xmm1
000076c1d9dd1797  lea rdi, [rsp]
000076c1d9dd179b  mov esi, 0x00
000076c1d9dd17a0  mov rax, 0x5EA58B9E0530
000076c1d9dd17aa  call rax
000076c1d9dd17ac  movaps xmm15, [rsp]
000076c1d9dd17b1  add rsp, 0x30
000076c1d9dd17b5  vmovaps xmm0, [rsp]
000076c1d9dd17ba  vmovaps xmm1, [rsp+0x10]
000076c1d9dd17c0  vmovaps xmm2, [rsp+0x20]
000076c1d9dd17c6  vmovaps xmm3, [rsp+0x30]
000076c1d9dd17cc  vmovaps xmm4, [rsp+0x40]
000076c1d9dd17d2  vmovaps xmm5, [rsp+0x50]
000076c1d9dd17d8  vmovaps xmm6, [rsp+0x60]
000076c1d9dd17de  vmovaps xmm7, [rsp+0x70]
000076c1d9dd17e4  vmovaps xmm8, [rsp+0x80]
000076c1d9dd17ed  vmovaps xmm9, [rsp+0x90]
000076c1d9dd17f6  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd17ff  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd1808  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd1811  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd181a  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd1823  add rsp, 0xF0
000076c1d9dd182a  pop r11
000076c1d9dd182c  pop r10
000076c1d9dd182e  pop r9
000076c1d9dd1830  pop r8
000076c1d9dd1832  pop rsi
000076c1d9dd1833  pop rdi
000076c1d9dd1834  pop rdx
000076c1d9dd1835  pop rcx
000076c1d9dd1836  pop rax
000076c1d9dd1837  add rsp, 0x08
000076c1d9dd183b  jmp 0x000076C1D9DCF923
000076c1d9dd1840  call 0x000076C1D9BFF430
000076c1d9dd1845  jmp 0x000076C1D9DCF930
000076c1d9dd184a  sub rsp, 0x08
000076c1d9dd184e  push rax
000076c1d9dd184f  push rcx
000076c1d9dd1850  push rdx
000076c1d9dd1851  push rdi
000076c1d9dd1852  push rsi
000076c1d9dd1853  push r8
000076c1d9dd1855  push r9
000076c1d9dd1857  push r10
000076c1d9dd1859  push r11
000076c1d9dd185b  sub rsp, 0xF0
000076c1d9dd1862  vmovaps [rsp], xmm0
000076c1d9dd1867  vmovaps [rsp+0x10], xmm1
000076c1d9dd186d  vmovaps [rsp+0x20], xmm3
000076c1d9dd1873  vmovaps [rsp+0x30], xmm4
000076c1d9dd1879  vmovaps [rsp+0x40], xmm5
000076c1d9dd187f  vmovaps [rsp+0x50], xmm6
000076c1d9dd1885  vmovaps [rsp+0x60], xmm7
000076c1d9dd188b  vmovaps [rsp+0x70], xmm8
000076c1d9dd1891  vmovaps [rsp+0x80], xmm9
000076c1d9dd189a  vmovaps [rsp+0x90], xmm10
000076c1d9dd18a3  vmovaps [rsp+0xA0], xmm11
000076c1d9dd18ac  vmovaps [rsp+0xB0], xmm12
000076c1d9dd18b5  vmovaps [rsp+0xC0], xmm13
000076c1d9dd18be  vmovaps [rsp+0xD0], xmm14
000076c1d9dd18c7  vmovaps [rsp+0xE0], xmm15
000076c1d9dd18d0  sub rsp, 0x30
000076c1d9dd18d4  movaps [rsp], xmm2
000076c1d9dd18d8  movaps [rsp+0x10], xmm1
000076c1d9dd18dd  movaps [rsp+0x20], xmm14
000076c1d9dd18e3  lea rdi, [rsp]
000076c1d9dd18e7  mov esi, 0x00
000076c1d9dd18ec  mov rax, 0x5EA58B9E0530
000076c1d9dd18f6  call rax
000076c1d9dd18f8  movaps xmm2, [rsp]
000076c1d9dd18fc  add rsp, 0x30
000076c1d9dd1900  vmovaps xmm0, [rsp]
000076c1d9dd1905  vmovaps xmm1, [rsp+0x10]
000076c1d9dd190b  vmovaps xmm3, [rsp+0x20]
000076c1d9dd1911  vmovaps xmm4, [rsp+0x30]
000076c1d9dd1917  vmovaps xmm5, [rsp+0x40]
000076c1d9dd191d  vmovaps xmm6, [rsp+0x50]
000076c1d9dd1923  vmovaps xmm7, [rsp+0x60]
000076c1d9dd1929  vmovaps xmm8, [rsp+0x70]
000076c1d9dd192f  vmovaps xmm9, [rsp+0x80]
000076c1d9dd1938  vmovaps xmm10, [rsp+0x90]
000076c1d9dd1941  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd194a  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd1953  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd195c  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd1965  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd196e  add rsp, 0xF0
000076c1d9dd1975  pop r11
000076c1d9dd1977  pop r10
000076c1d9dd1979  pop r9
000076c1d9dd197b  pop r8
000076c1d9dd197d  pop rsi
000076c1d9dd197e  pop rdi
000076c1d9dd197f  pop rdx
000076c1d9dd1980  pop rcx
000076c1d9dd1981  pop rax
000076c1d9dd1982  add rsp, 0x08
000076c1d9dd1986  jmp 0x000076C1D9DCF96D
000076c1d9dd198b  sub rsp, 0x08
000076c1d9dd198f  push rax
000076c1d9dd1990  push rcx
000076c1d9dd1991  push rdx
000076c1d9dd1992  push rdi
000076c1d9dd1993  push rsi
000076c1d9dd1994  push r8
000076c1d9dd1996  push r9
000076c1d9dd1998  push r10
000076c1d9dd199a  push r11
000076c1d9dd199c  sub rsp, 0xF0
000076c1d9dd19a3  vmovaps [rsp], xmm0
000076c1d9dd19a8  vmovaps [rsp+0x10], xmm1
000076c1d9dd19ae  vmovaps [rsp+0x20], xmm2
000076c1d9dd19b4  vmovaps [rsp+0x30], xmm3
000076c1d9dd19ba  vmovaps [rsp+0x40], xmm4
000076c1d9dd19c0  vmovaps [rsp+0x50], xmm5
000076c1d9dd19c6  vmovaps [rsp+0x60], xmm6
000076c1d9dd19cc  vmovaps [rsp+0x70], xmm7
000076c1d9dd19d2  vmovaps [rsp+0x80], xmm8
000076c1d9dd19db  vmovaps [rsp+0x90], xmm9
000076c1d9dd19e4  vmovaps [rsp+0xA0], xmm10
000076c1d9dd19ed  vmovaps [rsp+0xB0], xmm11
000076c1d9dd19f6  vmovaps [rsp+0xC0], xmm12
000076c1d9dd19ff  vmovaps [rsp+0xD0], xmm13
000076c1d9dd1a08  vmovaps [rsp+0xE0], xmm14
000076c1d9dd1a11  sub rsp, 0x30
000076c1d9dd1a15  movaps [rsp], xmm15
000076c1d9dd1a1a  movaps [rsp+0x10], xmm14
000076c1d9dd1a20  movaps [rsp+0x20], xmm1
000076c1d9dd1a25  lea rdi, [rsp]
000076c1d9dd1a29  mov esi, 0x00
000076c1d9dd1a2e  mov rax, 0x5EA58B9E0530
000076c1d9dd1a38  call rax
000076c1d9dd1a3a  movaps xmm15, [rsp]
000076c1d9dd1a3f  add rsp, 0x30
000076c1d9dd1a43  vmovaps xmm0, [rsp]
000076c1d9dd1a48  vmovaps xmm1, [rsp+0x10]
000076c1d9dd1a4e  vmovaps xmm2, [rsp+0x20]
000076c1d9dd1a54  vmovaps xmm3, [rsp+0x30]
000076c1d9dd1a5a  vmovaps xmm4, [rsp+0x40]
000076c1d9dd1a60  vmovaps xmm5, [rsp+0x50]
000076c1d9dd1a66  vmovaps xmm6, [rsp+0x60]
000076c1d9dd1a6c  vmovaps xmm7, [rsp+0x70]
000076c1d9dd1a72  vmovaps xmm8, [rsp+0x80]
000076c1d9dd1a7b  vmovaps xmm9, [rsp+0x90]
000076c1d9dd1a84  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd1a8d  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd1a96  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd1a9f  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd1aa8  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd1ab1  add rsp, 0xF0
000076c1d9dd1ab8  pop r11
000076c1d9dd1aba  pop r10
000076c1d9dd1abc  pop r9
000076c1d9dd1abe  pop r8
000076c1d9dd1ac0  pop rsi
000076c1d9dd1ac1  pop rdi
000076c1d9dd1ac2  pop rdx
000076c1d9dd1ac3  pop rcx
000076c1d9dd1ac4  pop rax
000076c1d9dd1ac5  add rsp, 0x08
000076c1d9dd1ac9  jmp 0x000076C1D9DCF9E7
000076c1d9dd1ace  call 0x000076C1D9BFF430
000076c1d9dd1ad3  jmp 0x000076C1D9DCF9F4
000076c1d9dd1ad8  sub rsp, 0x08
000076c1d9dd1adc  push rax
000076c1d9dd1add  push rcx
000076c1d9dd1ade  push rdx
000076c1d9dd1adf  push rdi
000076c1d9dd1ae0  push rsi
000076c1d9dd1ae1  push r8
000076c1d9dd1ae3  push r9
000076c1d9dd1ae5  push r10
000076c1d9dd1ae7  push r11
000076c1d9dd1ae9  sub rsp, 0xF0
000076c1d9dd1af0  vmovaps [rsp], xmm0
000076c1d9dd1af5  vmovaps [rsp+0x10], xmm1
000076c1d9dd1afb  vmovaps [rsp+0x20], xmm2
000076c1d9dd1b01  vmovaps [rsp+0x30], xmm3
000076c1d9dd1b07  vmovaps [rsp+0x40], xmm4
000076c1d9dd1b0d  vmovaps [rsp+0x50], xmm5
000076c1d9dd1b13  vmovaps [rsp+0x60], xmm6
000076c1d9dd1b19  vmovaps [rsp+0x70], xmm7
000076c1d9dd1b1f  vmovaps [rsp+0x80], xmm8
000076c1d9dd1b28  vmovaps [rsp+0x90], xmm9
000076c1d9dd1b31  vmovaps [rsp+0xA0], xmm10
000076c1d9dd1b3a  vmovaps [rsp+0xB0], xmm11
000076c1d9dd1b43  vmovaps [rsp+0xC0], xmm12
000076c1d9dd1b4c  vmovaps [rsp+0xD0], xmm13
000076c1d9dd1b55  vmovaps [rsp+0xE0], xmm15
000076c1d9dd1b5e  sub rsp, 0x30
000076c1d9dd1b62  movaps [rsp], xmm14
000076c1d9dd1b67  movaps [rsp+0x10], xmm13
000076c1d9dd1b6d  movaps [rsp+0x20], xmm1
000076c1d9dd1b72  lea rdi, [rsp]
000076c1d9dd1b76  mov esi, 0x00
000076c1d9dd1b7b  mov rax, 0x5EA58B9E0530
000076c1d9dd1b85  call rax
000076c1d9dd1b87  movaps xmm14, [rsp]
000076c1d9dd1b8c  add rsp, 0x30
000076c1d9dd1b90  vmovaps xmm0, [rsp]
000076c1d9dd1b95  vmovaps xmm1, [rsp+0x10]
000076c1d9dd1b9b  vmovaps xmm2, [rsp+0x20]
000076c1d9dd1ba1  vmovaps xmm3, [rsp+0x30]
000076c1d9dd1ba7  vmovaps xmm4, [rsp+0x40]
000076c1d9dd1bad  vmovaps xmm5, [rsp+0x50]
000076c1d9dd1bb3  vmovaps xmm6, [rsp+0x60]
000076c1d9dd1bb9  vmovaps xmm7, [rsp+0x70]
000076c1d9dd1bbf  vmovaps xmm8, [rsp+0x80]
000076c1d9dd1bc8  vmovaps xmm9, [rsp+0x90]
000076c1d9dd1bd1  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd1bda  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd1be3  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd1bec  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd1bf5  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd1bfe  add rsp, 0xF0
000076c1d9dd1c05  pop r11
000076c1d9dd1c07  pop r10
000076c1d9dd1c09  pop r9
000076c1d9dd1c0b  pop r8
000076c1d9dd1c0d  pop rsi
000076c1d9dd1c0e  pop rdi
000076c1d9dd1c0f  pop rdx
000076c1d9dd1c10  pop rcx
000076c1d9dd1c11  pop rax
000076c1d9dd1c12  add rsp, 0x08
000076c1d9dd1c16  jmp 0x000076C1D9DCFAAF
000076c1d9dd1c1b  sub rsp, 0x08
000076c1d9dd1c1f  push rax
000076c1d9dd1c20  push rcx
000076c1d9dd1c21  push rdx
000076c1d9dd1c22  push rdi
000076c1d9dd1c23  push rsi
000076c1d9dd1c24  push r8
000076c1d9dd1c26  push r9
000076c1d9dd1c28  push r10
000076c1d9dd1c2a  push r11
000076c1d9dd1c2c  sub rsp, 0xF0
000076c1d9dd1c33  vmovaps [rsp], xmm0
000076c1d9dd1c38  vmovaps [rsp+0x10], xmm1
000076c1d9dd1c3e  vmovaps [rsp+0x20], xmm2
000076c1d9dd1c44  vmovaps [rsp+0x30], xmm3
000076c1d9dd1c4a  vmovaps [rsp+0x40], xmm4
000076c1d9dd1c50  vmovaps [rsp+0x50], xmm5
000076c1d9dd1c56  vmovaps [rsp+0x60], xmm6
000076c1d9dd1c5c  vmovaps [rsp+0x70], xmm7
000076c1d9dd1c62  vmovaps [rsp+0x80], xmm8
000076c1d9dd1c6b  vmovaps [rsp+0x90], xmm9
000076c1d9dd1c74  vmovaps [rsp+0xA0], xmm10
000076c1d9dd1c7d  vmovaps [rsp+0xB0], xmm11
000076c1d9dd1c86  vmovaps [rsp+0xC0], xmm12
000076c1d9dd1c8f  vmovaps [rsp+0xD0], xmm13
000076c1d9dd1c98  vmovaps [rsp+0xE0], xmm14
000076c1d9dd1ca1  sub rsp, 0x30
000076c1d9dd1ca5  movaps [rsp], xmm15
000076c1d9dd1caa  movaps [rsp+0x10], xmm13
000076c1d9dd1cb0  movaps [rsp+0x20], xmm1
000076c1d9dd1cb5  lea rdi, [rsp]
000076c1d9dd1cb9  mov esi, 0x00
000076c1d9dd1cbe  mov rax, 0x5EA58B9E0530
000076c1d9dd1cc8  call rax
000076c1d9dd1cca  movaps xmm15, [rsp]
000076c1d9dd1ccf  add rsp, 0x30
000076c1d9dd1cd3  vmovaps xmm0, [rsp]
000076c1d9dd1cd8  vmovaps xmm1, [rsp+0x10]
000076c1d9dd1cde  vmovaps xmm2, [rsp+0x20]
000076c1d9dd1ce4  vmovaps xmm3, [rsp+0x30]
000076c1d9dd1cea  vmovaps xmm4, [rsp+0x40]
000076c1d9dd1cf0  vmovaps xmm5, [rsp+0x50]
000076c1d9dd1cf6  vmovaps xmm6, [rsp+0x60]
000076c1d9dd1cfc  vmovaps xmm7, [rsp+0x70]
000076c1d9dd1d02  vmovaps xmm8, [rsp+0x80]
000076c1d9dd1d0b  vmovaps xmm9, [rsp+0x90]
000076c1d9dd1d14  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd1d1d  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd1d26  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd1d2f  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd1d38  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd1d41  add rsp, 0xF0
000076c1d9dd1d48  pop r11
000076c1d9dd1d4a  pop r10
000076c1d9dd1d4c  pop r9
000076c1d9dd1d4e  pop r8
000076c1d9dd1d50  pop rsi
000076c1d9dd1d51  pop rdi
000076c1d9dd1d52  pop rdx
000076c1d9dd1d53  pop rcx
000076c1d9dd1d54  pop rax
000076c1d9dd1d55  add rsp, 0x08
000076c1d9dd1d59  jmp 0x000076C1D9DCFAEB
000076c1d9dd1d5e  call 0x000076C1D9BFF430
000076c1d9dd1d63  jmp 0x000076C1D9DCFAF8
000076c1d9dd1d68  sub rsp, 0x08
000076c1d9dd1d6c  push rax
000076c1d9dd1d6d  push rcx
000076c1d9dd1d6e  push rdx
000076c1d9dd1d6f  push rdi
000076c1d9dd1d70  push rsi
000076c1d9dd1d71  push r8
000076c1d9dd1d73  push r9
000076c1d9dd1d75  push r10
000076c1d9dd1d77  push r11
000076c1d9dd1d79  sub rsp, 0xF0
000076c1d9dd1d80  vmovaps [rsp], xmm0
000076c1d9dd1d85  vmovaps [rsp+0x10], xmm1
000076c1d9dd1d8b  vmovaps [rsp+0x20], xmm2
000076c1d9dd1d91  vmovaps [rsp+0x30], xmm3
000076c1d9dd1d97  vmovaps [rsp+0x40], xmm4
000076c1d9dd1d9d  vmovaps [rsp+0x50], xmm5
000076c1d9dd1da3  vmovaps [rsp+0x60], xmm6
000076c1d9dd1da9  vmovaps [rsp+0x70], xmm7
000076c1d9dd1daf  vmovaps [rsp+0x80], xmm8
000076c1d9dd1db8  vmovaps [rsp+0x90], xmm9
000076c1d9dd1dc1  vmovaps [rsp+0xA0], xmm10
000076c1d9dd1dca  vmovaps [rsp+0xB0], xmm11
000076c1d9dd1dd3  vmovaps [rsp+0xC0], xmm12
000076c1d9dd1ddc  vmovaps [rsp+0xD0], xmm13
000076c1d9dd1de5  vmovaps [rsp+0xE0], xmm15
000076c1d9dd1dee  sub rsp, 0x30
000076c1d9dd1df2  movaps [rsp], xmm14
000076c1d9dd1df7  movaps [rsp+0x10], xmm13
000076c1d9dd1dfd  movaps [rsp+0x20], xmm2
000076c1d9dd1e02  lea rdi, [rsp]
000076c1d9dd1e06  mov esi, 0x00
000076c1d9dd1e0b  mov rax, 0x5EA58B9E0530
000076c1d9dd1e15  call rax
000076c1d9dd1e17  movaps xmm14, [rsp]
000076c1d9dd1e1c  add rsp, 0x30
000076c1d9dd1e20  vmovaps xmm0, [rsp]
000076c1d9dd1e25  vmovaps xmm1, [rsp+0x10]
000076c1d9dd1e2b  vmovaps xmm2, [rsp+0x20]
000076c1d9dd1e31  vmovaps xmm3, [rsp+0x30]
000076c1d9dd1e37  vmovaps xmm4, [rsp+0x40]
000076c1d9dd1e3d  vmovaps xmm5, [rsp+0x50]
000076c1d9dd1e43  vmovaps xmm6, [rsp+0x60]
000076c1d9dd1e49  vmovaps xmm7, [rsp+0x70]
000076c1d9dd1e4f  vmovaps xmm8, [rsp+0x80]
000076c1d9dd1e58  vmovaps xmm9, [rsp+0x90]
000076c1d9dd1e61  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd1e6a  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd1e73  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd1e7c  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd1e85  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd1e8e  add rsp, 0xF0
000076c1d9dd1e95  pop r11
000076c1d9dd1e97  pop r10
000076c1d9dd1e99  pop r9
000076c1d9dd1e9b  pop r8
000076c1d9dd1e9d  pop rsi
000076c1d9dd1e9e  pop rdi
000076c1d9dd1e9f  pop rdx
000076c1d9dd1ea0  pop rcx
000076c1d9dd1ea1  pop rax
000076c1d9dd1ea2  add rsp, 0x08
000076c1d9dd1ea6  jmp 0x000076C1D9DCFB24
000076c1d9dd1eab  sub rsp, 0x08
000076c1d9dd1eaf  push rax
000076c1d9dd1eb0  push rcx
000076c1d9dd1eb1  push rdx
000076c1d9dd1eb2  push rdi
000076c1d9dd1eb3  push rsi
000076c1d9dd1eb4  push r8
000076c1d9dd1eb6  push r9
000076c1d9dd1eb8  push r10
000076c1d9dd1eba  push r11
000076c1d9dd1ebc  sub rsp, 0xF0
000076c1d9dd1ec3  vmovaps [rsp], xmm0
000076c1d9dd1ec8  vmovaps [rsp+0x10], xmm2
000076c1d9dd1ece  vmovaps [rsp+0x20], xmm3
000076c1d9dd1ed4  vmovaps [rsp+0x30], xmm4
000076c1d9dd1eda  vmovaps [rsp+0x40], xmm5
000076c1d9dd1ee0  vmovaps [rsp+0x50], xmm6
000076c1d9dd1ee6  vmovaps [rsp+0x60], xmm7
000076c1d9dd1eec  vmovaps [rsp+0x70], xmm8
000076c1d9dd1ef2  vmovaps [rsp+0x80], xmm9
000076c1d9dd1efb  vmovaps [rsp+0x90], xmm10
000076c1d9dd1f04  vmovaps [rsp+0xA0], xmm11
000076c1d9dd1f0d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd1f16  vmovaps [rsp+0xC0], xmm13
000076c1d9dd1f1f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd1f28  vmovaps [rsp+0xE0], xmm15
000076c1d9dd1f31  sub rsp, 0x30
000076c1d9dd1f35  movaps [rsp], xmm1
000076c1d9dd1f39  movaps [rsp+0x10], xmm13
000076c1d9dd1f3f  movaps [rsp+0x20], xmm2
000076c1d9dd1f44  lea rdi, [rsp]
000076c1d9dd1f48  mov esi, 0x00
000076c1d9dd1f4d  mov rax, 0x5EA58B9E0530
000076c1d9dd1f57  call rax
000076c1d9dd1f59  movaps xmm1, [rsp]
000076c1d9dd1f5d  add rsp, 0x30
000076c1d9dd1f61  vmovaps xmm0, [rsp]
000076c1d9dd1f66  vmovaps xmm2, [rsp+0x10]
000076c1d9dd1f6c  vmovaps xmm3, [rsp+0x20]
000076c1d9dd1f72  vmovaps xmm4, [rsp+0x30]
000076c1d9dd1f78  vmovaps xmm5, [rsp+0x40]
000076c1d9dd1f7e  vmovaps xmm6, [rsp+0x50]
000076c1d9dd1f84  vmovaps xmm7, [rsp+0x60]
000076c1d9dd1f8a  vmovaps xmm8, [rsp+0x70]
000076c1d9dd1f90  vmovaps xmm9, [rsp+0x80]
000076c1d9dd1f99  vmovaps xmm10, [rsp+0x90]
000076c1d9dd1fa2  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd1fab  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd1fb4  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd1fbd  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd1fc6  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd1fcf  add rsp, 0xF0
000076c1d9dd1fd6  pop r11
000076c1d9dd1fd8  pop r10
000076c1d9dd1fda  pop r9
000076c1d9dd1fdc  pop r8
000076c1d9dd1fde  pop rsi
000076c1d9dd1fdf  pop rdi
000076c1d9dd1fe0  pop rdx
000076c1d9dd1fe1  pop rcx
000076c1d9dd1fe2  pop rax
000076c1d9dd1fe3  add rsp, 0x08
000076c1d9dd1fe7  jmp 0x000076C1D9DCFB52
000076c1d9dd1fec  sub rsp, 0x08
000076c1d9dd1ff0  push rax
000076c1d9dd1ff1  push rcx
000076c1d9dd1ff2  push rdx
000076c1d9dd1ff3  push rdi
000076c1d9dd1ff4  push rsi
000076c1d9dd1ff5  push r8
000076c1d9dd1ff7  push r9
000076c1d9dd1ff9  push r10
000076c1d9dd1ffb  push r11
000076c1d9dd1ffd  sub rsp, 0xF0
000076c1d9dd2004  vmovaps [rsp], xmm0
000076c1d9dd2009  vmovaps [rsp+0x10], xmm1
000076c1d9dd200f  vmovaps [rsp+0x20], xmm3
000076c1d9dd2015  vmovaps [rsp+0x30], xmm4
000076c1d9dd201b  vmovaps [rsp+0x40], xmm5
000076c1d9dd2021  vmovaps [rsp+0x50], xmm6
000076c1d9dd2027  vmovaps [rsp+0x60], xmm7
000076c1d9dd202d  vmovaps [rsp+0x70], xmm8
000076c1d9dd2033  vmovaps [rsp+0x80], xmm9
000076c1d9dd203c  vmovaps [rsp+0x90], xmm10
000076c1d9dd2045  vmovaps [rsp+0xA0], xmm11
000076c1d9dd204e  vmovaps [rsp+0xB0], xmm12
000076c1d9dd2057  vmovaps [rsp+0xC0], xmm13
000076c1d9dd2060  vmovaps [rsp+0xD0], xmm14
000076c1d9dd2069  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2072  sub rsp, 0x30
000076c1d9dd2076  movaps [rsp], xmm2
000076c1d9dd207a  movaps [rsp+0x10], xmm1
000076c1d9dd207f  movaps [rsp+0x20], xmm13
000076c1d9dd2085  lea rdi, [rsp]
000076c1d9dd2089  mov esi, 0x00
000076c1d9dd208e  mov rax, 0x5EA58B9E0530
000076c1d9dd2098  call rax
000076c1d9dd209a  movaps xmm2, [rsp]
000076c1d9dd209e  add rsp, 0x30
000076c1d9dd20a2  vmovaps xmm0, [rsp]
000076c1d9dd20a7  vmovaps xmm1, [rsp+0x10]
000076c1d9dd20ad  vmovaps xmm3, [rsp+0x20]
000076c1d9dd20b3  vmovaps xmm4, [rsp+0x30]
000076c1d9dd20b9  vmovaps xmm5, [rsp+0x40]
000076c1d9dd20bf  vmovaps xmm6, [rsp+0x50]
000076c1d9dd20c5  vmovaps xmm7, [rsp+0x60]
000076c1d9dd20cb  vmovaps xmm8, [rsp+0x70]
000076c1d9dd20d1  vmovaps xmm9, [rsp+0x80]
000076c1d9dd20da  vmovaps xmm10, [rsp+0x90]
000076c1d9dd20e3  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd20ec  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd20f5  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd20fe  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd2107  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd2110  add rsp, 0xF0
000076c1d9dd2117  pop r11
000076c1d9dd2119  pop r10
000076c1d9dd211b  pop r9
000076c1d9dd211d  pop r8
000076c1d9dd211f  pop rsi
000076c1d9dd2120  pop rdi
000076c1d9dd2121  pop rdx
000076c1d9dd2122  pop rcx
000076c1d9dd2123  pop rax
000076c1d9dd2124  add rsp, 0x08
000076c1d9dd2128  jmp 0x000076C1D9DCFBAB
000076c1d9dd212d  call 0x000076C1D9BFF430
000076c1d9dd2132  jmp 0x000076C1D9DCFBB8
000076c1d9dd2137  sub rsp, 0x08
000076c1d9dd213b  push rax
000076c1d9dd213c  push rcx
000076c1d9dd213d  push rdx
000076c1d9dd213e  push rdi
000076c1d9dd213f  push rsi
000076c1d9dd2140  push r8
000076c1d9dd2142  push r9
000076c1d9dd2144  push r10
000076c1d9dd2146  push r11
000076c1d9dd2148  sub rsp, 0xF0
000076c1d9dd214f  vmovaps [rsp], xmm0
000076c1d9dd2154  vmovaps [rsp+0x10], xmm1
000076c1d9dd215a  vmovaps [rsp+0x20], xmm2
000076c1d9dd2160  vmovaps [rsp+0x30], xmm3
000076c1d9dd2166  vmovaps [rsp+0x40], xmm4
000076c1d9dd216c  vmovaps [rsp+0x50], xmm5
000076c1d9dd2172  vmovaps [rsp+0x60], xmm6
000076c1d9dd2178  vmovaps [rsp+0x70], xmm7
000076c1d9dd217e  vmovaps [rsp+0x80], xmm8
000076c1d9dd2187  vmovaps [rsp+0x90], xmm9
000076c1d9dd2190  vmovaps [rsp+0xA0], xmm10
000076c1d9dd2199  vmovaps [rsp+0xB0], xmm11
000076c1d9dd21a2  vmovaps [rsp+0xC0], xmm12
000076c1d9dd21ab  vmovaps [rsp+0xD0], xmm13
000076c1d9dd21b4  vmovaps [rsp+0xE0], xmm14
000076c1d9dd21bd  sub rsp, 0x30
000076c1d9dd21c1  movaps [rsp], xmm15
000076c1d9dd21c6  movaps [rsp+0x10], xmm13
000076c1d9dd21cc  movaps [rsp+0x20], xmm1
000076c1d9dd21d1  lea rdi, [rsp]
000076c1d9dd21d5  mov esi, 0x00
000076c1d9dd21da  mov rax, 0x5EA58B9E0530
000076c1d9dd21e4  call rax
000076c1d9dd21e6  movaps xmm15, [rsp]
000076c1d9dd21eb  add rsp, 0x30
000076c1d9dd21ef  vmovaps xmm0, [rsp]
000076c1d9dd21f4  vmovaps xmm1, [rsp+0x10]
000076c1d9dd21fa  vmovaps xmm2, [rsp+0x20]
000076c1d9dd2200  vmovaps xmm3, [rsp+0x30]
000076c1d9dd2206  vmovaps xmm4, [rsp+0x40]
000076c1d9dd220c  vmovaps xmm5, [rsp+0x50]
000076c1d9dd2212  vmovaps xmm6, [rsp+0x60]
000076c1d9dd2218  vmovaps xmm7, [rsp+0x70]
000076c1d9dd221e  vmovaps xmm8, [rsp+0x80]
000076c1d9dd2227  vmovaps xmm9, [rsp+0x90]
000076c1d9dd2230  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd2239  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd2242  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd224b  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd2254  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd225d  add rsp, 0xF0
000076c1d9dd2264  pop r11
000076c1d9dd2266  pop r10
000076c1d9dd2268  pop r9
000076c1d9dd226a  pop r8
000076c1d9dd226c  pop rsi
000076c1d9dd226d  pop rdi
000076c1d9dd226e  pop rdx
000076c1d9dd226f  pop rcx
000076c1d9dd2270  pop rax
000076c1d9dd2271  add rsp, 0x08
000076c1d9dd2275  jmp 0x000076C1D9DCFBF7
000076c1d9dd227a  sub rsp, 0x08
000076c1d9dd227e  push rax
000076c1d9dd227f  push rcx
000076c1d9dd2280  push rdx
000076c1d9dd2281  push rdi
000076c1d9dd2282  push rsi
000076c1d9dd2283  push r8
000076c1d9dd2285  push r9
000076c1d9dd2287  push r10
000076c1d9dd2289  push r11
000076c1d9dd228b  sub rsp, 0xF0
000076c1d9dd2292  vmovaps [rsp], xmm0
000076c1d9dd2297  vmovaps [rsp+0x10], xmm1
000076c1d9dd229d  vmovaps [rsp+0x20], xmm2
000076c1d9dd22a3  vmovaps [rsp+0x30], xmm3
000076c1d9dd22a9  vmovaps [rsp+0x40], xmm4
000076c1d9dd22af  vmovaps [rsp+0x50], xmm5
000076c1d9dd22b5  vmovaps [rsp+0x60], xmm6
000076c1d9dd22bb  vmovaps [rsp+0x70], xmm7
000076c1d9dd22c1  vmovaps [rsp+0x80], xmm8
000076c1d9dd22ca  vmovaps [rsp+0x90], xmm9
000076c1d9dd22d3  vmovaps [rsp+0xA0], xmm10
000076c1d9dd22dc  vmovaps [rsp+0xB0], xmm11
000076c1d9dd22e5  vmovaps [rsp+0xC0], xmm12
000076c1d9dd22ee  vmovaps [rsp+0xD0], xmm13
000076c1d9dd22f7  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2300  sub rsp, 0x30
000076c1d9dd2304  movaps [rsp], xmm14
000076c1d9dd2309  movaps [rsp+0x10], xmm11
000076c1d9dd230f  movaps [rsp+0x20], xmm1
000076c1d9dd2314  lea rdi, [rsp]
000076c1d9dd2318  mov esi, 0x00
000076c1d9dd231d  mov rax, 0x5EA58B9E0530
000076c1d9dd2327  call rax
000076c1d9dd2329  movaps xmm14, [rsp]
000076c1d9dd232e  add rsp, 0x30
000076c1d9dd2332  vmovaps xmm0, [rsp]
000076c1d9dd2337  vmovaps xmm1, [rsp+0x10]
000076c1d9dd233d  vmovaps xmm2, [rsp+0x20]
000076c1d9dd2343  vmovaps xmm3, [rsp+0x30]
000076c1d9dd2349  vmovaps xmm4, [rsp+0x40]
000076c1d9dd234f  vmovaps xmm5, [rsp+0x50]
000076c1d9dd2355  vmovaps xmm6, [rsp+0x60]
000076c1d9dd235b  vmovaps xmm7, [rsp+0x70]
000076c1d9dd2361  vmovaps xmm8, [rsp+0x80]
000076c1d9dd236a  vmovaps xmm9, [rsp+0x90]
000076c1d9dd2373  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd237c  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd2385  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd238e  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd2397  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd23a0  add rsp, 0xF0
000076c1d9dd23a7  pop r11
000076c1d9dd23a9  pop r10
000076c1d9dd23ab  pop r9
000076c1d9dd23ad  pop r8
000076c1d9dd23af  pop rsi
000076c1d9dd23b0  pop rdi
000076c1d9dd23b1  pop rdx
000076c1d9dd23b2  pop rcx
000076c1d9dd23b3  pop rax
000076c1d9dd23b4  add rsp, 0x08
000076c1d9dd23b8  jmp 0x000076C1D9DCFC21
000076c1d9dd23bd  sub rsp, 0x08
000076c1d9dd23c1  push rax
000076c1d9dd23c2  push rcx
000076c1d9dd23c3  push rdx
000076c1d9dd23c4  push rdi
000076c1d9dd23c5  push rsi
000076c1d9dd23c6  push r8
000076c1d9dd23c8  push r9
000076c1d9dd23ca  push r10
000076c1d9dd23cc  push r11
000076c1d9dd23ce  sub rsp, 0xF0
000076c1d9dd23d5  vmovaps [rsp], xmm0
000076c1d9dd23da  vmovaps [rsp+0x10], xmm1
000076c1d9dd23e0  vmovaps [rsp+0x20], xmm2
000076c1d9dd23e6  vmovaps [rsp+0x30], xmm3
000076c1d9dd23ec  vmovaps [rsp+0x40], xmm4
000076c1d9dd23f2  vmovaps [rsp+0x50], xmm5
000076c1d9dd23f8  vmovaps [rsp+0x60], xmm6
000076c1d9dd23fe  vmovaps [rsp+0x70], xmm7
000076c1d9dd2404  vmovaps [rsp+0x80], xmm8
000076c1d9dd240d  vmovaps [rsp+0x90], xmm9
000076c1d9dd2416  vmovaps [rsp+0xA0], xmm10
000076c1d9dd241f  vmovaps [rsp+0xB0], xmm11
000076c1d9dd2428  vmovaps [rsp+0xC0], xmm12
000076c1d9dd2431  vmovaps [rsp+0xD0], xmm14
000076c1d9dd243a  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2443  sub rsp, 0x30
000076c1d9dd2447  movaps [rsp], xmm13
000076c1d9dd244c  movaps [rsp+0x10], xmm11
000076c1d9dd2452  movaps [rsp+0x20], xmm1
000076c1d9dd2457  lea rdi, [rsp]
000076c1d9dd245b  mov esi, 0x00
000076c1d9dd2460  mov rax, 0x5EA58B9E0530
000076c1d9dd246a  call rax
000076c1d9dd246c  movaps xmm13, [rsp]
000076c1d9dd2471  add rsp, 0x30
000076c1d9dd2475  vmovaps xmm0, [rsp]
000076c1d9dd247a  vmovaps xmm1, [rsp+0x10]
000076c1d9dd2480  vmovaps xmm2, [rsp+0x20]
000076c1d9dd2486  vmovaps xmm3, [rsp+0x30]
000076c1d9dd248c  vmovaps xmm4, [rsp+0x40]
000076c1d9dd2492  vmovaps xmm5, [rsp+0x50]
000076c1d9dd2498  vmovaps xmm6, [rsp+0x60]
000076c1d9dd249e  vmovaps xmm7, [rsp+0x70]
000076c1d9dd24a4  vmovaps xmm8, [rsp+0x80]
000076c1d9dd24ad  vmovaps xmm9, [rsp+0x90]
000076c1d9dd24b6  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd24bf  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd24c8  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd24d1  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd24da  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd24e3  add rsp, 0xF0
000076c1d9dd24ea  pop r11
000076c1d9dd24ec  pop r10
000076c1d9dd24ee  pop r9
000076c1d9dd24f0  pop r8
000076c1d9dd24f2  pop rsi
000076c1d9dd24f3  pop rdi
000076c1d9dd24f4  pop rdx
000076c1d9dd24f5  pop rcx
000076c1d9dd24f6  pop rax
000076c1d9dd24f7  add rsp, 0x08
000076c1d9dd24fb  jmp 0x000076C1D9DCFC76
000076c1d9dd2500  call 0x000076C1D9BFF430
000076c1d9dd2505  jmp 0x000076C1D9DCFC83
000076c1d9dd250a  sub rsp, 0x08
000076c1d9dd250e  push rax
000076c1d9dd250f  push rcx
000076c1d9dd2510  push rdx
000076c1d9dd2511  push rdi
000076c1d9dd2512  push rsi
000076c1d9dd2513  push r8
000076c1d9dd2515  push r9
000076c1d9dd2517  push r10
000076c1d9dd2519  push r11
000076c1d9dd251b  sub rsp, 0xF0
000076c1d9dd2522  vmovaps [rsp], xmm0
000076c1d9dd2527  vmovaps [rsp+0x10], xmm1
000076c1d9dd252d  vmovaps [rsp+0x20], xmm2
000076c1d9dd2533  vmovaps [rsp+0x30], xmm3
000076c1d9dd2539  vmovaps [rsp+0x40], xmm4
000076c1d9dd253f  vmovaps [rsp+0x50], xmm5
000076c1d9dd2545  vmovaps [rsp+0x60], xmm6
000076c1d9dd254b  vmovaps [rsp+0x70], xmm7
000076c1d9dd2551  vmovaps [rsp+0x80], xmm8
000076c1d9dd255a  vmovaps [rsp+0x90], xmm9
000076c1d9dd2563  vmovaps [rsp+0xA0], xmm10
000076c1d9dd256c  vmovaps [rsp+0xB0], xmm11
000076c1d9dd2575  vmovaps [rsp+0xC0], xmm12
000076c1d9dd257e  vmovaps [rsp+0xD0], xmm13
000076c1d9dd2587  vmovaps [rsp+0xE0], xmm14
000076c1d9dd2590  sub rsp, 0x30
000076c1d9dd2594  movaps [rsp], xmm15
000076c1d9dd2599  movaps [rsp+0x10], xmm11
000076c1d9dd259f  movaps [rsp+0x20], xmm1
000076c1d9dd25a4  lea rdi, [rsp]
000076c1d9dd25a8  mov esi, 0x00
000076c1d9dd25ad  mov rax, 0x5EA58B9E0530
000076c1d9dd25b7  call rax
000076c1d9dd25b9  movaps xmm15, [rsp]
000076c1d9dd25be  add rsp, 0x30
000076c1d9dd25c2  vmovaps xmm0, [rsp]
000076c1d9dd25c7  vmovaps xmm1, [rsp+0x10]
000076c1d9dd25cd  vmovaps xmm2, [rsp+0x20]
000076c1d9dd25d3  vmovaps xmm3, [rsp+0x30]
000076c1d9dd25d9  vmovaps xmm4, [rsp+0x40]
000076c1d9dd25df  vmovaps xmm5, [rsp+0x50]
000076c1d9dd25e5  vmovaps xmm6, [rsp+0x60]
000076c1d9dd25eb  vmovaps xmm7, [rsp+0x70]
000076c1d9dd25f1  vmovaps xmm8, [rsp+0x80]
000076c1d9dd25fa  vmovaps xmm9, [rsp+0x90]
000076c1d9dd2603  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd260c  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd2615  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd261e  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd2627  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd2630  add rsp, 0xF0
000076c1d9dd2637  pop r11
000076c1d9dd2639  pop r10
000076c1d9dd263b  pop r9
000076c1d9dd263d  pop r8
000076c1d9dd263f  pop rsi
000076c1d9dd2640  pop rdi
000076c1d9dd2641  pop rdx
000076c1d9dd2642  pop rcx
000076c1d9dd2643  pop rax
000076c1d9dd2644  add rsp, 0x08
000076c1d9dd2648  jmp 0x000076C1D9DCFCBC
000076c1d9dd264d  sub rsp, 0x08
000076c1d9dd2651  push rax
000076c1d9dd2652  push rcx
000076c1d9dd2653  push rdx
000076c1d9dd2654  push rdi
000076c1d9dd2655  push rsi
000076c1d9dd2656  push r8
000076c1d9dd2658  push r9
000076c1d9dd265a  push r10
000076c1d9dd265c  push r11
000076c1d9dd265e  sub rsp, 0xF0
000076c1d9dd2665  vmovaps [rsp], xmm0
000076c1d9dd266a  vmovaps [rsp+0x10], xmm1
000076c1d9dd2670  vmovaps [rsp+0x20], xmm2
000076c1d9dd2676  vmovaps [rsp+0x30], xmm3
000076c1d9dd267c  vmovaps [rsp+0x40], xmm4
000076c1d9dd2682  vmovaps [rsp+0x50], xmm5
000076c1d9dd2688  vmovaps [rsp+0x60], xmm6
000076c1d9dd268e  vmovaps [rsp+0x70], xmm7
000076c1d9dd2694  vmovaps [rsp+0x80], xmm8
000076c1d9dd269d  vmovaps [rsp+0x90], xmm9
000076c1d9dd26a6  vmovaps [rsp+0xA0], xmm10
000076c1d9dd26af  vmovaps [rsp+0xB0], xmm12
000076c1d9dd26b8  vmovaps [rsp+0xC0], xmm13
000076c1d9dd26c1  vmovaps [rsp+0xD0], xmm14
000076c1d9dd26ca  vmovaps [rsp+0xE0], xmm15
000076c1d9dd26d3  sub rsp, 0x30
000076c1d9dd26d7  movaps [rsp], xmm11
000076c1d9dd26dc  movaps [rsp+0x10], xmm6
000076c1d9dd26e1  movaps [rsp+0x20], xmm14
000076c1d9dd26e7  lea rdi, [rsp]
000076c1d9dd26eb  mov esi, 0x00
000076c1d9dd26f0  mov rax, 0x5EA58B9E0530
000076c1d9dd26fa  call rax
000076c1d9dd26fc  movaps xmm11, [rsp]
000076c1d9dd2701  add rsp, 0x30
000076c1d9dd2705  vmovaps xmm0, [rsp]
000076c1d9dd270a  vmovaps xmm1, [rsp+0x10]
000076c1d9dd2710  vmovaps xmm2, [rsp+0x20]
000076c1d9dd2716  vmovaps xmm3, [rsp+0x30]
000076c1d9dd271c  vmovaps xmm4, [rsp+0x40]
000076c1d9dd2722  vmovaps xmm5, [rsp+0x50]
000076c1d9dd2728  vmovaps xmm6, [rsp+0x60]
000076c1d9dd272e  vmovaps xmm7, [rsp+0x70]
000076c1d9dd2734  vmovaps xmm8, [rsp+0x80]
000076c1d9dd273d  vmovaps xmm9, [rsp+0x90]
000076c1d9dd2746  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd274f  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd2758  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd2761  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd276a  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd2773  add rsp, 0xF0
000076c1d9dd277a  pop r11
000076c1d9dd277c  pop r10
000076c1d9dd277e  pop r9
000076c1d9dd2780  pop r8
000076c1d9dd2782  pop rsi
000076c1d9dd2783  pop rdi
000076c1d9dd2784  pop rdx
000076c1d9dd2785  pop rcx
000076c1d9dd2786  pop rax
000076c1d9dd2787  add rsp, 0x08
000076c1d9dd278b  jmp 0x000076C1D9DCFD34
000076c1d9dd2790  call 0x000076C1D9BFF430
000076c1d9dd2795  jmp 0x000076C1D9DCFD3E
000076c1d9dd279a  sub rsp, 0x08
000076c1d9dd279e  push rax
000076c1d9dd279f  push rcx
000076c1d9dd27a0  push rdx
000076c1d9dd27a1  push rdi
000076c1d9dd27a2  push rsi
000076c1d9dd27a3  push r8
000076c1d9dd27a5  push r9
000076c1d9dd27a7  push r10
000076c1d9dd27a9  push r11
000076c1d9dd27ab  sub rsp, 0xF0
000076c1d9dd27b2  vmovaps [rsp], xmm0
000076c1d9dd27b7  vmovaps [rsp+0x10], xmm1
000076c1d9dd27bd  vmovaps [rsp+0x20], xmm2
000076c1d9dd27c3  vmovaps [rsp+0x30], xmm3
000076c1d9dd27c9  vmovaps [rsp+0x40], xmm4
000076c1d9dd27cf  vmovaps [rsp+0x50], xmm5
000076c1d9dd27d5  vmovaps [rsp+0x60], xmm6
000076c1d9dd27db  vmovaps [rsp+0x70], xmm7
000076c1d9dd27e1  vmovaps [rsp+0x80], xmm8
000076c1d9dd27ea  vmovaps [rsp+0x90], xmm9
000076c1d9dd27f3  vmovaps [rsp+0xA0], xmm10
000076c1d9dd27fc  vmovaps [rsp+0xB0], xmm11
000076c1d9dd2805  vmovaps [rsp+0xC0], xmm12
000076c1d9dd280e  vmovaps [rsp+0xD0], xmm13
000076c1d9dd2817  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2820  sub rsp, 0x30
000076c1d9dd2824  movaps [rsp], xmm14
000076c1d9dd2829  movaps [rsp+0x10], xmm6
000076c1d9dd282e  movaps [rsp+0x20], xmm2
000076c1d9dd2833  lea rdi, [rsp]
000076c1d9dd2837  mov esi, 0x00
000076c1d9dd283c  mov rax, 0x5EA58B9E0530
000076c1d9dd2846  call rax
000076c1d9dd2848  movaps xmm14, [rsp]
000076c1d9dd284d  add rsp, 0x30
000076c1d9dd2851  vmovaps xmm0, [rsp]
000076c1d9dd2856  vmovaps xmm1, [rsp+0x10]
000076c1d9dd285c  vmovaps xmm2, [rsp+0x20]
000076c1d9dd2862  vmovaps xmm3, [rsp+0x30]
000076c1d9dd2868  vmovaps xmm4, [rsp+0x40]
000076c1d9dd286e  vmovaps xmm5, [rsp+0x50]
000076c1d9dd2874  vmovaps xmm6, [rsp+0x60]
000076c1d9dd287a  vmovaps xmm7, [rsp+0x70]
000076c1d9dd2880  vmovaps xmm8, [rsp+0x80]
000076c1d9dd2889  vmovaps xmm9, [rsp+0x90]
000076c1d9dd2892  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd289b  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd28a4  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd28ad  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd28b6  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd28bf  add rsp, 0xF0
000076c1d9dd28c6  pop r11
000076c1d9dd28c8  pop r10
000076c1d9dd28ca  pop r9
000076c1d9dd28cc  pop r8
000076c1d9dd28ce  pop rsi
000076c1d9dd28cf  pop rdi
000076c1d9dd28d0  pop rdx
000076c1d9dd28d1  pop rcx
000076c1d9dd28d2  pop rax
000076c1d9dd28d3  add rsp, 0x08
000076c1d9dd28d7  jmp 0x000076C1D9DCFD72
000076c1d9dd28dc  sub rsp, 0x08
000076c1d9dd28e0  push rax
000076c1d9dd28e1  push rcx
000076c1d9dd28e2  push rdx
000076c1d9dd28e3  push rdi
000076c1d9dd28e4  push rsi
000076c1d9dd28e5  push r8
000076c1d9dd28e7  push r9
000076c1d9dd28e9  push r10
000076c1d9dd28eb  push r11
000076c1d9dd28ed  sub rsp, 0xF0
000076c1d9dd28f4  vmovaps [rsp], xmm0
000076c1d9dd28f9  vmovaps [rsp+0x10], xmm1
000076c1d9dd28ff  vmovaps [rsp+0x20], xmm2
000076c1d9dd2905  vmovaps [rsp+0x30], xmm3
000076c1d9dd290b  vmovaps [rsp+0x40], xmm4
000076c1d9dd2911  vmovaps [rsp+0x50], xmm5
000076c1d9dd2917  vmovaps [rsp+0x60], xmm7
000076c1d9dd291d  vmovaps [rsp+0x70], xmm8
000076c1d9dd2923  vmovaps [rsp+0x80], xmm9
000076c1d9dd292c  vmovaps [rsp+0x90], xmm10
000076c1d9dd2935  vmovaps [rsp+0xA0], xmm11
000076c1d9dd293e  vmovaps [rsp+0xB0], xmm12
000076c1d9dd2947  vmovaps [rsp+0xC0], xmm13
000076c1d9dd2950  vmovaps [rsp+0xD0], xmm14
000076c1d9dd2959  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2962  sub rsp, 0x30
000076c1d9dd2966  movaps [rsp], xmm6
000076c1d9dd296a  movaps [rsp+0x10], xmm5
000076c1d9dd296f  movaps [rsp+0x20], xmm1
000076c1d9dd2974  lea rdi, [rsp]
000076c1d9dd2978  mov esi, 0x00
000076c1d9dd297d  mov rax, 0x5EA58B9E0530
000076c1d9dd2987  call rax
000076c1d9dd2989  movaps xmm6, [rsp]
000076c1d9dd298d  add rsp, 0x30
000076c1d9dd2991  vmovaps xmm0, [rsp]
000076c1d9dd2996  vmovaps xmm1, [rsp+0x10]
000076c1d9dd299c  vmovaps xmm2, [rsp+0x20]
000076c1d9dd29a2  vmovaps xmm3, [rsp+0x30]
000076c1d9dd29a8  vmovaps xmm4, [rsp+0x40]
000076c1d9dd29ae  vmovaps xmm5, [rsp+0x50]
000076c1d9dd29b4  vmovaps xmm7, [rsp+0x60]
000076c1d9dd29ba  vmovaps xmm8, [rsp+0x70]
000076c1d9dd29c0  vmovaps xmm9, [rsp+0x80]
000076c1d9dd29c9  vmovaps xmm10, [rsp+0x90]
000076c1d9dd29d2  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd29db  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd29e4  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd29ed  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd29f6  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd29ff  add rsp, 0xF0
000076c1d9dd2a06  pop r11
000076c1d9dd2a08  pop r10
000076c1d9dd2a0a  pop r9
000076c1d9dd2a0c  pop r8
000076c1d9dd2a0e  pop rsi
000076c1d9dd2a0f  pop rdi
000076c1d9dd2a10  pop rdx
000076c1d9dd2a11  pop rcx
000076c1d9dd2a12  pop rax
000076c1d9dd2a13  add rsp, 0x08
000076c1d9dd2a17  jmp 0x000076C1D9DCFD98
000076c1d9dd2a1c  sub rsp, 0x08
000076c1d9dd2a20  push rax
000076c1d9dd2a21  push rcx
000076c1d9dd2a22  push rdx
000076c1d9dd2a23  push rdi
000076c1d9dd2a24  push rsi
000076c1d9dd2a25  push r8
000076c1d9dd2a27  push r9
000076c1d9dd2a29  push r10
000076c1d9dd2a2b  push r11
000076c1d9dd2a2d  sub rsp, 0xF0
000076c1d9dd2a34  vmovaps [rsp], xmm0
000076c1d9dd2a39  vmovaps [rsp+0x10], xmm2
000076c1d9dd2a3f  vmovaps [rsp+0x20], xmm3
000076c1d9dd2a45  vmovaps [rsp+0x30], xmm4
000076c1d9dd2a4b  vmovaps [rsp+0x40], xmm5
000076c1d9dd2a51  vmovaps [rsp+0x50], xmm6
000076c1d9dd2a57  vmovaps [rsp+0x60], xmm7
000076c1d9dd2a5d  vmovaps [rsp+0x70], xmm8
000076c1d9dd2a63  vmovaps [rsp+0x80], xmm9
000076c1d9dd2a6c  vmovaps [rsp+0x90], xmm10
000076c1d9dd2a75  vmovaps [rsp+0xA0], xmm11
000076c1d9dd2a7e  vmovaps [rsp+0xB0], xmm12
000076c1d9dd2a87  vmovaps [rsp+0xC0], xmm13
000076c1d9dd2a90  vmovaps [rsp+0xD0], xmm14
000076c1d9dd2a99  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2aa2  sub rsp, 0x30
000076c1d9dd2aa6  movaps [rsp], xmm1
000076c1d9dd2aaa  movaps [rsp+0x10], xmm5
000076c1d9dd2aaf  movaps [rsp+0x20], xmm13
000076c1d9dd2ab5  lea rdi, [rsp]
000076c1d9dd2ab9  mov esi, 0x00
000076c1d9dd2abe  mov rax, 0x5EA58B9E0530
000076c1d9dd2ac8  call rax
000076c1d9dd2aca  movaps xmm1, [rsp]
000076c1d9dd2ace  add rsp, 0x30
000076c1d9dd2ad2  vmovaps xmm0, [rsp]
000076c1d9dd2ad7  vmovaps xmm2, [rsp+0x10]
000076c1d9dd2add  vmovaps xmm3, [rsp+0x20]
000076c1d9dd2ae3  vmovaps xmm4, [rsp+0x30]
000076c1d9dd2ae9  vmovaps xmm5, [rsp+0x40]
000076c1d9dd2aef  vmovaps xmm6, [rsp+0x50]
000076c1d9dd2af5  vmovaps xmm7, [rsp+0x60]
000076c1d9dd2afb  vmovaps xmm8, [rsp+0x70]
000076c1d9dd2b01  vmovaps xmm9, [rsp+0x80]
000076c1d9dd2b0a  vmovaps xmm10, [rsp+0x90]
000076c1d9dd2b13  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd2b1c  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd2b25  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd2b2e  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd2b37  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd2b40  add rsp, 0xF0
000076c1d9dd2b47  pop r11
000076c1d9dd2b49  pop r10
000076c1d9dd2b4b  pop r9
000076c1d9dd2b4d  pop r8
000076c1d9dd2b4f  pop rsi
000076c1d9dd2b50  pop rdi
000076c1d9dd2b51  pop rdx
000076c1d9dd2b52  pop rcx
000076c1d9dd2b53  pop rax
000076c1d9dd2b54  add rsp, 0x08
000076c1d9dd2b58  jmp 0x000076C1D9DCFDB6
000076c1d9dd2b5d  sub rsp, 0x08
000076c1d9dd2b61  push rax
000076c1d9dd2b62  push rcx
000076c1d9dd2b63  push rdx
000076c1d9dd2b64  push rdi
000076c1d9dd2b65  push rsi
000076c1d9dd2b66  push r8
000076c1d9dd2b68  push r9
000076c1d9dd2b6a  push r10
000076c1d9dd2b6c  push r11
000076c1d9dd2b6e  sub rsp, 0xF0
000076c1d9dd2b75  vmovaps [rsp], xmm0
000076c1d9dd2b7a  vmovaps [rsp+0x10], xmm1
000076c1d9dd2b80  vmovaps [rsp+0x20], xmm2
000076c1d9dd2b86  vmovaps [rsp+0x30], xmm3
000076c1d9dd2b8c  vmovaps [rsp+0x40], xmm4
000076c1d9dd2b92  vmovaps [rsp+0x50], xmm6
000076c1d9dd2b98  vmovaps [rsp+0x60], xmm7
000076c1d9dd2b9e  vmovaps [rsp+0x70], xmm8
000076c1d9dd2ba4  vmovaps [rsp+0x80], xmm9
000076c1d9dd2bad  vmovaps [rsp+0x90], xmm10
000076c1d9dd2bb6  vmovaps [rsp+0xA0], xmm11
000076c1d9dd2bbf  vmovaps [rsp+0xB0], xmm12
000076c1d9dd2bc8  vmovaps [rsp+0xC0], xmm13
000076c1d9dd2bd1  vmovaps [rsp+0xD0], xmm14
000076c1d9dd2bda  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2be3  sub rsp, 0x30
000076c1d9dd2be7  movaps [rsp], xmm5
000076c1d9dd2beb  movaps [rsp+0x10], xmm2
000076c1d9dd2bf0  movaps [rsp+0x20], xmm13
000076c1d9dd2bf6  lea rdi, [rsp]
000076c1d9dd2bfa  mov esi, 0x00
000076c1d9dd2bff  mov rax, 0x5EA58B9E0530
000076c1d9dd2c09  call rax
000076c1d9dd2c0b  movaps xmm5, [rsp]
000076c1d9dd2c0f  add rsp, 0x30
000076c1d9dd2c13  vmovaps xmm0, [rsp]
000076c1d9dd2c18  vmovaps xmm1, [rsp+0x10]
000076c1d9dd2c1e  vmovaps xmm2, [rsp+0x20]
000076c1d9dd2c24  vmovaps xmm3, [rsp+0x30]
000076c1d9dd2c2a  vmovaps xmm4, [rsp+0x40]
000076c1d9dd2c30  vmovaps xmm6, [rsp+0x50]
000076c1d9dd2c36  vmovaps xmm7, [rsp+0x60]
000076c1d9dd2c3c  vmovaps xmm8, [rsp+0x70]
000076c1d9dd2c42  vmovaps xmm9, [rsp+0x80]
000076c1d9dd2c4b  vmovaps xmm10, [rsp+0x90]
000076c1d9dd2c54  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd2c5d  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd2c66  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd2c6f  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd2c78  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd2c81  add rsp, 0xF0
000076c1d9dd2c88  pop r11
000076c1d9dd2c8a  pop r10
000076c1d9dd2c8c  pop r9
000076c1d9dd2c8e  pop r8
000076c1d9dd2c90  pop rsi
000076c1d9dd2c91  pop rdi
000076c1d9dd2c92  pop rdx
000076c1d9dd2c93  pop rcx
000076c1d9dd2c94  pop rax
000076c1d9dd2c95  add rsp, 0x08
000076c1d9dd2c99  jmp 0x000076C1D9DCFDEC
000076c1d9dd2c9e  sub rsp, 0x08
000076c1d9dd2ca2  push rax
000076c1d9dd2ca3  push rcx
000076c1d9dd2ca4  push rdx
000076c1d9dd2ca5  push rdi
000076c1d9dd2ca6  push rsi
000076c1d9dd2ca7  push r8
000076c1d9dd2ca9  push r9
000076c1d9dd2cab  push r10
000076c1d9dd2cad  push r11
000076c1d9dd2caf  sub rsp, 0xF0
000076c1d9dd2cb6  vmovaps [rsp], xmm0
000076c1d9dd2cbb  vmovaps [rsp+0x10], xmm1
000076c1d9dd2cc1  vmovaps [rsp+0x20], xmm2
000076c1d9dd2cc7  vmovaps [rsp+0x30], xmm3
000076c1d9dd2ccd  vmovaps [rsp+0x40], xmm4
000076c1d9dd2cd3  vmovaps [rsp+0x50], xmm5
000076c1d9dd2cd9  vmovaps [rsp+0x60], xmm6
000076c1d9dd2cdf  vmovaps [rsp+0x70], xmm7
000076c1d9dd2ce5  vmovaps [rsp+0x80], xmm8
000076c1d9dd2cee  vmovaps [rsp+0x90], xmm9
000076c1d9dd2cf7  vmovaps [rsp+0xA0], xmm10
000076c1d9dd2d00  vmovaps [rsp+0xB0], xmm11
000076c1d9dd2d09  vmovaps [rsp+0xC0], xmm12
000076c1d9dd2d12  vmovaps [rsp+0xD0], xmm14
000076c1d9dd2d1b  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2d24  sub rsp, 0x30
000076c1d9dd2d28  movaps [rsp], xmm13
000076c1d9dd2d2d  movaps [rsp+0x10], xmm10
000076c1d9dd2d33  movaps [rsp+0x20], xmm1
000076c1d9dd2d38  lea rdi, [rsp]
000076c1d9dd2d3c  mov esi, 0x00
000076c1d9dd2d41  mov rax, 0x5EA58B9E0530
000076c1d9dd2d4b  call rax
000076c1d9dd2d4d  movaps xmm13, [rsp]
000076c1d9dd2d52  add rsp, 0x30
000076c1d9dd2d56  vmovaps xmm0, [rsp]
000076c1d9dd2d5b  vmovaps xmm1, [rsp+0x10]
000076c1d9dd2d61  vmovaps xmm2, [rsp+0x20]
000076c1d9dd2d67  vmovaps xmm3, [rsp+0x30]
000076c1d9dd2d6d  vmovaps xmm4, [rsp+0x40]
000076c1d9dd2d73  vmovaps xmm5, [rsp+0x50]
000076c1d9dd2d79  vmovaps xmm6, [rsp+0x60]
000076c1d9dd2d7f  vmovaps xmm7, [rsp+0x70]
000076c1d9dd2d85  vmovaps xmm8, [rsp+0x80]
000076c1d9dd2d8e  vmovaps xmm9, [rsp+0x90]
000076c1d9dd2d97  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd2da0  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd2da9  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd2db2  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd2dbb  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd2dc4  add rsp, 0xF0
000076c1d9dd2dcb  pop r11
000076c1d9dd2dcd  pop r10
000076c1d9dd2dcf  pop r9
000076c1d9dd2dd1  pop r8
000076c1d9dd2dd3  pop rsi
000076c1d9dd2dd4  pop rdi
000076c1d9dd2dd5  pop rdx
000076c1d9dd2dd6  pop rcx
000076c1d9dd2dd7  pop rax
000076c1d9dd2dd8  add rsp, 0x08
000076c1d9dd2ddc  jmp 0x000076C1D9DCFE15
000076c1d9dd2de1  sub rsp, 0x08
000076c1d9dd2de5  push rax
000076c1d9dd2de6  push rcx
000076c1d9dd2de7  push rdx
000076c1d9dd2de8  push rdi
000076c1d9dd2de9  push rsi
000076c1d9dd2dea  push r8
000076c1d9dd2dec  push r9
000076c1d9dd2dee  push r10
000076c1d9dd2df0  push r11
000076c1d9dd2df2  sub rsp, 0xF0
000076c1d9dd2df9  vmovaps [rsp], xmm0
000076c1d9dd2dfe  vmovaps [rsp+0x10], xmm2
000076c1d9dd2e04  vmovaps [rsp+0x20], xmm3
000076c1d9dd2e0a  vmovaps [rsp+0x30], xmm4
000076c1d9dd2e10  vmovaps [rsp+0x40], xmm5
000076c1d9dd2e16  vmovaps [rsp+0x50], xmm6
000076c1d9dd2e1c  vmovaps [rsp+0x60], xmm7
000076c1d9dd2e22  vmovaps [rsp+0x70], xmm8
000076c1d9dd2e28  vmovaps [rsp+0x80], xmm9
000076c1d9dd2e31  vmovaps [rsp+0x90], xmm10
000076c1d9dd2e3a  vmovaps [rsp+0xA0], xmm11
000076c1d9dd2e43  vmovaps [rsp+0xB0], xmm12
000076c1d9dd2e4c  vmovaps [rsp+0xC0], xmm13
000076c1d9dd2e55  vmovaps [rsp+0xD0], xmm14
000076c1d9dd2e5e  vmovaps [rsp+0xE0], xmm15
000076c1d9dd2e67  sub rsp, 0x30
000076c1d9dd2e6b  movaps [rsp], xmm1
000076c1d9dd2e6f  movaps [rsp+0x10], xmm15
000076c1d9dd2e75  movaps [rsp+0x20], xmm10
000076c1d9dd2e7b  lea rdi, [rsp]
000076c1d9dd2e7f  mov esi, 0x00
000076c1d9dd2e84  mov rax, 0x5EA58B9E0530
000076c1d9dd2e8e  call rax
000076c1d9dd2e90  movaps xmm1, [rsp]
000076c1d9dd2e94  add rsp, 0x30
000076c1d9dd2e98  vmovaps xmm0, [rsp]
000076c1d9dd2e9d  vmovaps xmm2, [rsp+0x10]
000076c1d9dd2ea3  vmovaps xmm3, [rsp+0x20]
000076c1d9dd2ea9  vmovaps xmm4, [rsp+0x30]
000076c1d9dd2eaf  vmovaps xmm5, [rsp+0x40]
000076c1d9dd2eb5  vmovaps xmm6, [rsp+0x50]
000076c1d9dd2ebb  vmovaps xmm7, [rsp+0x60]
000076c1d9dd2ec1  vmovaps xmm8, [rsp+0x70]
000076c1d9dd2ec7  vmovaps xmm9, [rsp+0x80]
000076c1d9dd2ed0  vmovaps xmm10, [rsp+0x90]
000076c1d9dd2ed9  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd2ee2  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd2eeb  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd2ef4  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd2efd  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd2f06  add rsp, 0xF0
000076c1d9dd2f0d  pop r11
000076c1d9dd2f0f  pop r10
000076c1d9dd2f11  pop r9
000076c1d9dd2f13  pop r8
000076c1d9dd2f15  pop rsi
000076c1d9dd2f16  pop rdi
000076c1d9dd2f17  pop rdx
000076c1d9dd2f18  pop rcx
000076c1d9dd2f19  pop rax
000076c1d9dd2f1a  add rsp, 0x08
000076c1d9dd2f1e  jmp 0x000076C1D9DCFE34
000076c1d9dd2f23  sub rsp, 0x08
000076c1d9dd2f27  push rax
000076c1d9dd2f28  push rcx
000076c1d9dd2f29  push rdx
000076c1d9dd2f2a  push rdi
000076c1d9dd2f2b  push rsi
000076c1d9dd2f2c  push r8
000076c1d9dd2f2e  push r9
000076c1d9dd2f30  push r10
000076c1d9dd2f32  push r11
000076c1d9dd2f34  sub rsp, 0xF0
000076c1d9dd2f3b  vmovaps [rsp], xmm0
000076c1d9dd2f40  vmovaps [rsp+0x10], xmm1
000076c1d9dd2f46  vmovaps [rsp+0x20], xmm2
000076c1d9dd2f4c  vmovaps [rsp+0x30], xmm3
000076c1d9dd2f52  vmovaps [rsp+0x40], xmm4
000076c1d9dd2f58  vmovaps [rsp+0x50], xmm5
000076c1d9dd2f5e  vmovaps [rsp+0x60], xmm6
000076c1d9dd2f64  vmovaps [rsp+0x70], xmm7
000076c1d9dd2f6a  vmovaps [rsp+0x80], xmm8
000076c1d9dd2f73  vmovaps [rsp+0x90], xmm9
000076c1d9dd2f7c  vmovaps [rsp+0xA0], xmm10
000076c1d9dd2f85  vmovaps [rsp+0xB0], xmm11
000076c1d9dd2f8e  vmovaps [rsp+0xC0], xmm12
000076c1d9dd2f97  vmovaps [rsp+0xD0], xmm13
000076c1d9dd2fa0  vmovaps [rsp+0xE0], xmm14
000076c1d9dd2fa9  sub rsp, 0x30
000076c1d9dd2fad  movaps [rsp], xmm15
000076c1d9dd2fb2  movaps [rsp+0x10], xmm10
000076c1d9dd2fb8  movaps [rsp+0x20], xmm11
000076c1d9dd2fbe  lea rdi, [rsp]
000076c1d9dd2fc2  mov esi, 0x00
000076c1d9dd2fc7  mov rax, 0x5EA58B9E0530
000076c1d9dd2fd1  call rax
000076c1d9dd2fd3  movaps xmm15, [rsp]
000076c1d9dd2fd8  add rsp, 0x30
000076c1d9dd2fdc  vmovaps xmm0, [rsp]
000076c1d9dd2fe1  vmovaps xmm1, [rsp+0x10]
000076c1d9dd2fe7  vmovaps xmm2, [rsp+0x20]
000076c1d9dd2fed  vmovaps xmm3, [rsp+0x30]
000076c1d9dd2ff3  vmovaps xmm4, [rsp+0x40]
000076c1d9dd2ff9  vmovaps xmm5, [rsp+0x50]
000076c1d9dd2fff  vmovaps xmm6, [rsp+0x60]
000076c1d9dd3005  vmovaps xmm7, [rsp+0x70]
000076c1d9dd300b  vmovaps xmm8, [rsp+0x80]
000076c1d9dd3014  vmovaps xmm9, [rsp+0x90]
000076c1d9dd301d  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd3026  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd302f  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd3038  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd3041  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd304a  add rsp, 0xF0
000076c1d9dd3051  pop r11
000076c1d9dd3053  pop r10
000076c1d9dd3055  pop r9
000076c1d9dd3057  pop r8
000076c1d9dd3059  pop rsi
000076c1d9dd305a  pop rdi
000076c1d9dd305b  pop rdx
000076c1d9dd305c  pop rcx
000076c1d9dd305d  pop rax
000076c1d9dd305e  add rsp, 0x08
000076c1d9dd3062  jmp 0x000076C1D9DCFE57
000076c1d9dd3067  sub rsp, 0x08
000076c1d9dd306b  push rax
000076c1d9dd306c  push rcx
000076c1d9dd306d  push rdx
000076c1d9dd306e  push rdi
000076c1d9dd306f  push rsi
000076c1d9dd3070  push r8
000076c1d9dd3072  push r9
000076c1d9dd3074  push r10
000076c1d9dd3076  push r11
000076c1d9dd3078  sub rsp, 0xF0
000076c1d9dd307f  vmovaps [rsp], xmm0
000076c1d9dd3084  vmovaps [rsp+0x10], xmm1
000076c1d9dd308a  vmovaps [rsp+0x20], xmm2
000076c1d9dd3090  vmovaps [rsp+0x30], xmm3
000076c1d9dd3096  vmovaps [rsp+0x40], xmm4
000076c1d9dd309c  vmovaps [rsp+0x50], xmm5
000076c1d9dd30a2  vmovaps [rsp+0x60], xmm6
000076c1d9dd30a8  vmovaps [rsp+0x70], xmm7
000076c1d9dd30ae  vmovaps [rsp+0x80], xmm8
000076c1d9dd30b7  vmovaps [rsp+0x90], xmm9
000076c1d9dd30c0  vmovaps [rsp+0xA0], xmm11
000076c1d9dd30c9  vmovaps [rsp+0xB0], xmm12
000076c1d9dd30d2  vmovaps [rsp+0xC0], xmm13
000076c1d9dd30db  vmovaps [rsp+0xD0], xmm14
000076c1d9dd30e4  vmovaps [rsp+0xE0], xmm15
000076c1d9dd30ed  sub rsp, 0x30
000076c1d9dd30f1  movaps [rsp], xmm10
000076c1d9dd30f6  movaps [rsp+0x10], xmm12
000076c1d9dd30fc  movaps [rsp+0x20], xmm11
000076c1d9dd3102  lea rdi, [rsp]
000076c1d9dd3106  mov esi, 0x00
000076c1d9dd310b  mov rax, 0x5EA58B9E0530
000076c1d9dd3115  call rax
000076c1d9dd3117  movaps xmm10, [rsp]
000076c1d9dd311c  add rsp, 0x30
000076c1d9dd3120  vmovaps xmm0, [rsp]
000076c1d9dd3125  vmovaps xmm1, [rsp+0x10]
000076c1d9dd312b  vmovaps xmm2, [rsp+0x20]
000076c1d9dd3131  vmovaps xmm3, [rsp+0x30]
000076c1d9dd3137  vmovaps xmm4, [rsp+0x40]
000076c1d9dd313d  vmovaps xmm5, [rsp+0x50]
000076c1d9dd3143  vmovaps xmm6, [rsp+0x60]
000076c1d9dd3149  vmovaps xmm7, [rsp+0x70]
000076c1d9dd314f  vmovaps xmm8, [rsp+0x80]
000076c1d9dd3158  vmovaps xmm9, [rsp+0x90]
000076c1d9dd3161  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd316a  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd3173  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd317c  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd3185  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd318e  add rsp, 0xF0
000076c1d9dd3195  pop r11
000076c1d9dd3197  pop r10
000076c1d9dd3199  pop r9
000076c1d9dd319b  pop r8
000076c1d9dd319d  pop rsi
000076c1d9dd319e  pop rdi
000076c1d9dd319f  pop rdx
000076c1d9dd31a0  pop rcx
000076c1d9dd31a1  pop rax
000076c1d9dd31a2  add rsp, 0x08
000076c1d9dd31a6  jmp 0x000076C1D9DCFE80
000076c1d9dd31ab  sub rsp, 0x08
000076c1d9dd31af  push rax
000076c1d9dd31b0  push rcx
000076c1d9dd31b1  push rdx
000076c1d9dd31b2  push rdi
000076c1d9dd31b3  push rsi
000076c1d9dd31b4  push r8
000076c1d9dd31b6  push r9
000076c1d9dd31b8  push r10
000076c1d9dd31ba  push r11
000076c1d9dd31bc  sub rsp, 0xF0
000076c1d9dd31c3  vmovaps [rsp], xmm0
000076c1d9dd31c8  vmovaps [rsp+0x10], xmm1
000076c1d9dd31ce  vmovaps [rsp+0x20], xmm2
000076c1d9dd31d4  vmovaps [rsp+0x30], xmm3
000076c1d9dd31da  vmovaps [rsp+0x40], xmm4
000076c1d9dd31e0  vmovaps [rsp+0x50], xmm5
000076c1d9dd31e6  vmovaps [rsp+0x60], xmm6
000076c1d9dd31ec  vmovaps [rsp+0x70], xmm7
000076c1d9dd31f2  vmovaps [rsp+0x80], xmm8
000076c1d9dd31fb  vmovaps [rsp+0x90], xmm9
000076c1d9dd3204  vmovaps [rsp+0xA0], xmm10
000076c1d9dd320d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd3216  vmovaps [rsp+0xC0], xmm13
000076c1d9dd321f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd3228  vmovaps [rsp+0xE0], xmm15
000076c1d9dd3231  sub rsp, 0x30
000076c1d9dd3235  movaps [rsp], xmm11
000076c1d9dd323a  movaps [rsp+0x10], xmm2
000076c1d9dd323f  movaps [rsp+0x20], xmm12
000076c1d9dd3245  lea rdi, [rsp]
000076c1d9dd3249  mov esi, 0x00
000076c1d9dd324e  mov rax, 0x5EA58B9E0530
000076c1d9dd3258  call rax
000076c1d9dd325a  movaps xmm11, [rsp]
000076c1d9dd325f  add rsp, 0x30
000076c1d9dd3263  vmovaps xmm0, [rsp]
000076c1d9dd3268  vmovaps xmm1, [rsp+0x10]
000076c1d9dd326e  vmovaps xmm2, [rsp+0x20]
000076c1d9dd3274  vmovaps xmm3, [rsp+0x30]
000076c1d9dd327a  vmovaps xmm4, [rsp+0x40]
000076c1d9dd3280  vmovaps xmm5, [rsp+0x50]
000076c1d9dd3286  vmovaps xmm6, [rsp+0x60]
000076c1d9dd328c  vmovaps xmm7, [rsp+0x70]
000076c1d9dd3292  vmovaps xmm8, [rsp+0x80]
000076c1d9dd329b  vmovaps xmm9, [rsp+0x90]
000076c1d9dd32a4  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd32ad  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd32b6  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd32bf  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd32c8  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd32d1  add rsp, 0xF0
000076c1d9dd32d8  pop r11
000076c1d9dd32da  pop r10
000076c1d9dd32dc  pop r9
000076c1d9dd32de  pop r8
000076c1d9dd32e0  pop rsi
000076c1d9dd32e1  pop rdi
000076c1d9dd32e2  pop rdx
000076c1d9dd32e3  pop rcx
000076c1d9dd32e4  pop rax
000076c1d9dd32e5  add rsp, 0x08
000076c1d9dd32e9  jmp 0x000076C1D9DCFEB8
000076c1d9dd32ee  sub rsp, 0x08
000076c1d9dd32f2  push rax
000076c1d9dd32f3  push rcx
000076c1d9dd32f4  push rdx
000076c1d9dd32f5  push rdi
000076c1d9dd32f6  push rsi
000076c1d9dd32f7  push r8
000076c1d9dd32f9  push r9
000076c1d9dd32fb  push r10
000076c1d9dd32fd  push r11
000076c1d9dd32ff  sub rsp, 0xF0
000076c1d9dd3306  vmovaps [rsp], xmm0
000076c1d9dd330b  vmovaps [rsp+0x10], xmm2
000076c1d9dd3311  vmovaps [rsp+0x20], xmm3
000076c1d9dd3317  vmovaps [rsp+0x30], xmm4
000076c1d9dd331d  vmovaps [rsp+0x40], xmm5
000076c1d9dd3323  vmovaps [rsp+0x50], xmm6
000076c1d9dd3329  vmovaps [rsp+0x60], xmm7
000076c1d9dd332f  vmovaps [rsp+0x70], xmm8
000076c1d9dd3335  vmovaps [rsp+0x80], xmm9
000076c1d9dd333e  vmovaps [rsp+0x90], xmm10
000076c1d9dd3347  vmovaps [rsp+0xA0], xmm11
000076c1d9dd3350  vmovaps [rsp+0xB0], xmm12
000076c1d9dd3359  vmovaps [rsp+0xC0], xmm13
000076c1d9dd3362  vmovaps [rsp+0xD0], xmm14
000076c1d9dd336b  vmovaps [rsp+0xE0], xmm15
000076c1d9dd3374  sub rsp, 0x30
000076c1d9dd3378  movaps [rsp], xmm1
000076c1d9dd337c  movaps [rsp+0x10], xmm14
000076c1d9dd3382  movaps [rsp+0x20], xmm6
000076c1d9dd3387  lea rdi, [rsp]
000076c1d9dd338b  mov esi, 0x00
000076c1d9dd3390  mov rax, 0x5EA58B9E0530
000076c1d9dd339a  call rax
000076c1d9dd339c  movaps xmm1, [rsp]
000076c1d9dd33a0  add rsp, 0x30
000076c1d9dd33a4  vmovaps xmm0, [rsp]
000076c1d9dd33a9  vmovaps xmm2, [rsp+0x10]
000076c1d9dd33af  vmovaps xmm3, [rsp+0x20]
000076c1d9dd33b5  vmovaps xmm4, [rsp+0x30]
000076c1d9dd33bb  vmovaps xmm5, [rsp+0x40]
000076c1d9dd33c1  vmovaps xmm6, [rsp+0x50]
000076c1d9dd33c7  vmovaps xmm7, [rsp+0x60]
000076c1d9dd33cd  vmovaps xmm8, [rsp+0x70]
000076c1d9dd33d3  vmovaps xmm9, [rsp+0x80]
000076c1d9dd33dc  vmovaps xmm10, [rsp+0x90]
000076c1d9dd33e5  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd33ee  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd33f7  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd3400  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd3409  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd3412  add rsp, 0xF0
000076c1d9dd3419  pop r11
000076c1d9dd341b  pop r10
000076c1d9dd341d  pop r9
000076c1d9dd341f  pop r8
000076c1d9dd3421  pop rsi
000076c1d9dd3422  pop rdi
000076c1d9dd3423  pop rdx
000076c1d9dd3424  pop rcx
000076c1d9dd3425  pop rax
000076c1d9dd3426  add rsp, 0x08
000076c1d9dd342a  jmp 0x000076C1D9DCFED1
000076c1d9dd342f  sub rsp, 0x08
000076c1d9dd3433  push rax
000076c1d9dd3434  push rcx
000076c1d9dd3435  push rdx
000076c1d9dd3436  push rdi
000076c1d9dd3437  push rsi
000076c1d9dd3438  push r8
000076c1d9dd343a  push r9
000076c1d9dd343c  push r10
000076c1d9dd343e  push r11
000076c1d9dd3440  sub rsp, 0xF0
000076c1d9dd3447  vmovaps [rsp], xmm0
000076c1d9dd344c  vmovaps [rsp+0x10], xmm1
000076c1d9dd3452  vmovaps [rsp+0x20], xmm2
000076c1d9dd3458  vmovaps [rsp+0x30], xmm3
000076c1d9dd345e  vmovaps [rsp+0x40], xmm4
000076c1d9dd3464  vmovaps [rsp+0x50], xmm5
000076c1d9dd346a  vmovaps [rsp+0x60], xmm6
000076c1d9dd3470  vmovaps [rsp+0x70], xmm7
000076c1d9dd3476  vmovaps [rsp+0x80], xmm8
000076c1d9dd347f  vmovaps [rsp+0x90], xmm9
000076c1d9dd3488  vmovaps [rsp+0xA0], xmm10
000076c1d9dd3491  vmovaps [rsp+0xB0], xmm11
000076c1d9dd349a  vmovaps [rsp+0xC0], xmm12
000076c1d9dd34a3  vmovaps [rsp+0xD0], xmm13
000076c1d9dd34ac  vmovaps [rsp+0xE0], xmm15
000076c1d9dd34b5  sub rsp, 0x30
000076c1d9dd34b9  movaps [rsp], xmm14
000076c1d9dd34be  movaps [rsp+0x10], xmm12
000076c1d9dd34c4  movaps [rsp+0x20], xmm5
000076c1d9dd34c9  lea rdi, [rsp]
000076c1d9dd34cd  mov esi, 0x00
000076c1d9dd34d2  mov rax, 0x5EA58B9E0530
000076c1d9dd34dc  call rax
000076c1d9dd34de  movaps xmm14, [rsp]
000076c1d9dd34e3  add rsp, 0x30
000076c1d9dd34e7  vmovaps xmm0, [rsp]
000076c1d9dd34ec  vmovaps xmm1, [rsp+0x10]
000076c1d9dd34f2  vmovaps xmm2, [rsp+0x20]
000076c1d9dd34f8  vmovaps xmm3, [rsp+0x30]
000076c1d9dd34fe  vmovaps xmm4, [rsp+0x40]
000076c1d9dd3504  vmovaps xmm5, [rsp+0x50]
000076c1d9dd350a  vmovaps xmm6, [rsp+0x60]
000076c1d9dd3510  vmovaps xmm7, [rsp+0x70]
000076c1d9dd3516  vmovaps xmm8, [rsp+0x80]
000076c1d9dd351f  vmovaps xmm9, [rsp+0x90]
000076c1d9dd3528  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd3531  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd353a  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd3543  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd354c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd3555  add rsp, 0xF0
000076c1d9dd355c  pop r11
000076c1d9dd355e  pop r10
000076c1d9dd3560  pop r9
000076c1d9dd3562  pop r8
000076c1d9dd3564  pop rsi
000076c1d9dd3565  pop rdi
000076c1d9dd3566  pop rdx
000076c1d9dd3567  pop rcx
000076c1d9dd3568  pop rax
000076c1d9dd3569  add rsp, 0x08
000076c1d9dd356d  jmp 0x000076C1D9DCFEF1
000076c1d9dd3572  sub rsp, 0x08
000076c1d9dd3576  push rax
000076c1d9dd3577  push rcx
000076c1d9dd3578  push rdx
000076c1d9dd3579  push rdi
000076c1d9dd357a  push rsi
000076c1d9dd357b  push r8
000076c1d9dd357d  push r9
000076c1d9dd357f  push r10
000076c1d9dd3581  push r11
000076c1d9dd3583  sub rsp, 0xF0
000076c1d9dd358a  vmovaps [rsp], xmm0
000076c1d9dd358f  vmovaps [rsp+0x10], xmm1
000076c1d9dd3595  vmovaps [rsp+0x20], xmm2
000076c1d9dd359b  vmovaps [rsp+0x30], xmm3
000076c1d9dd35a1  vmovaps [rsp+0x40], xmm4
000076c1d9dd35a7  vmovaps [rsp+0x50], xmm5
000076c1d9dd35ad  vmovaps [rsp+0x60], xmm7
000076c1d9dd35b3  vmovaps [rsp+0x70], xmm8
000076c1d9dd35b9  vmovaps [rsp+0x80], xmm9
000076c1d9dd35c2  vmovaps [rsp+0x90], xmm10
000076c1d9dd35cb  vmovaps [rsp+0xA0], xmm11
000076c1d9dd35d4  vmovaps [rsp+0xB0], xmm12
000076c1d9dd35dd  vmovaps [rsp+0xC0], xmm13
000076c1d9dd35e6  vmovaps [rsp+0xD0], xmm14
000076c1d9dd35ef  vmovaps [rsp+0xE0], xmm15
000076c1d9dd35f8  sub rsp, 0x30
000076c1d9dd35fc  movaps [rsp], xmm6
000076c1d9dd3600  movaps [rsp+0x10], xmm9
000076c1d9dd3606  movaps [rsp+0x20], xmm12
000076c1d9dd360c  lea rdi, [rsp]
000076c1d9dd3610  mov esi, 0x00
000076c1d9dd3615  mov rax, 0x5EA58B9E0530
000076c1d9dd361f  call rax
000076c1d9dd3621  movaps xmm6, [rsp]
000076c1d9dd3625  add rsp, 0x30
000076c1d9dd3629  vmovaps xmm0, [rsp]
000076c1d9dd362e  vmovaps xmm1, [rsp+0x10]
000076c1d9dd3634  vmovaps xmm2, [rsp+0x20]
000076c1d9dd363a  vmovaps xmm3, [rsp+0x30]
000076c1d9dd3640  vmovaps xmm4, [rsp+0x40]
000076c1d9dd3646  vmovaps xmm5, [rsp+0x50]
000076c1d9dd364c  vmovaps xmm7, [rsp+0x60]
000076c1d9dd3652  vmovaps xmm8, [rsp+0x70]
000076c1d9dd3658  vmovaps xmm9, [rsp+0x80]
000076c1d9dd3661  vmovaps xmm10, [rsp+0x90]
000076c1d9dd366a  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd3673  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd367c  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd3685  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd368e  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd3697  add rsp, 0xF0
000076c1d9dd369e  pop r11
000076c1d9dd36a0  pop r10
000076c1d9dd36a2  pop r9
000076c1d9dd36a4  pop r8
000076c1d9dd36a6  pop rsi
000076c1d9dd36a7  pop rdi
000076c1d9dd36a8  pop rdx
000076c1d9dd36a9  pop rcx
000076c1d9dd36aa  pop rax
000076c1d9dd36ab  add rsp, 0x08
000076c1d9dd36af  jmp 0x000076C1D9DCFF19
000076c1d9dd36b4  sub rsp, 0x08
000076c1d9dd36b8  push rax
000076c1d9dd36b9  push rcx
000076c1d9dd36ba  push rdx
000076c1d9dd36bb  push rdi
000076c1d9dd36bc  push rsi
000076c1d9dd36bd  push r8
000076c1d9dd36bf  push r9
000076c1d9dd36c1  push r10
000076c1d9dd36c3  push r11
000076c1d9dd36c5  sub rsp, 0xF0
000076c1d9dd36cc  vmovaps [rsp], xmm0
000076c1d9dd36d1  vmovaps [rsp+0x10], xmm1
000076c1d9dd36d7  vmovaps [rsp+0x20], xmm2
000076c1d9dd36dd  vmovaps [rsp+0x30], xmm3
000076c1d9dd36e3  vmovaps [rsp+0x40], xmm4
000076c1d9dd36e9  vmovaps [rsp+0x50], xmm5
000076c1d9dd36ef  vmovaps [rsp+0x60], xmm6
000076c1d9dd36f5  vmovaps [rsp+0x70], xmm7
000076c1d9dd36fb  vmovaps [rsp+0x80], xmm8
000076c1d9dd3704  vmovaps [rsp+0x90], xmm9
000076c1d9dd370d  vmovaps [rsp+0xA0], xmm10
000076c1d9dd3716  vmovaps [rsp+0xB0], xmm11
000076c1d9dd371f  vmovaps [rsp+0xC0], xmm13
000076c1d9dd3728  vmovaps [rsp+0xD0], xmm14
000076c1d9dd3731  vmovaps [rsp+0xE0], xmm15
000076c1d9dd373a  sub rsp, 0x30
000076c1d9dd373e  movaps [rsp], xmm12
000076c1d9dd3743  movaps [rsp+0x10], xmm15
000076c1d9dd3749  movaps [rsp+0x20], xmm13
000076c1d9dd374f  lea rdi, [rsp]
000076c1d9dd3753  mov esi, 0x00
000076c1d9dd3758  mov rax, 0x5EA58B9E0530
000076c1d9dd3762  call rax
000076c1d9dd3764  movaps xmm12, [rsp]
000076c1d9dd3769  add rsp, 0x30
000076c1d9dd376d  vmovaps xmm0, [rsp]
000076c1d9dd3772  vmovaps xmm1, [rsp+0x10]
000076c1d9dd3778  vmovaps xmm2, [rsp+0x20]
000076c1d9dd377e  vmovaps xmm3, [rsp+0x30]
000076c1d9dd3784  vmovaps xmm4, [rsp+0x40]
000076c1d9dd378a  vmovaps xmm5, [rsp+0x50]
000076c1d9dd3790  vmovaps xmm6, [rsp+0x60]
000076c1d9dd3796  vmovaps xmm7, [rsp+0x70]
000076c1d9dd379c  vmovaps xmm8, [rsp+0x80]
000076c1d9dd37a5  vmovaps xmm9, [rsp+0x90]
000076c1d9dd37ae  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd37b7  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd37c0  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd37c9  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd37d2  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd37db  add rsp, 0xF0
000076c1d9dd37e2  pop r11
000076c1d9dd37e4  pop r10
000076c1d9dd37e6  pop r9
000076c1d9dd37e8  pop r8
000076c1d9dd37ea  pop rsi
000076c1d9dd37eb  pop rdi
000076c1d9dd37ec  pop rdx
000076c1d9dd37ed  pop rcx
000076c1d9dd37ee  pop rax
000076c1d9dd37ef  add rsp, 0x08
000076c1d9dd37f3  jmp 0x000076C1D9DCFF34
000076c1d9dd37f8  sub rsp, 0x08
000076c1d9dd37fc  push rax
000076c1d9dd37fd  push rcx
000076c1d9dd37fe  push rdx
000076c1d9dd37ff  push rdi
000076c1d9dd3800  push rsi
000076c1d9dd3801  push r8
000076c1d9dd3803  push r9
000076c1d9dd3805  push r10
000076c1d9dd3807  push r11
000076c1d9dd3809  sub rsp, 0xF0
000076c1d9dd3810  vmovaps [rsp], xmm0
000076c1d9dd3815  vmovaps [rsp+0x10], xmm1
000076c1d9dd381b  vmovaps [rsp+0x20], xmm2
000076c1d9dd3821  vmovaps [rsp+0x30], xmm3
000076c1d9dd3827  vmovaps [rsp+0x40], xmm4
000076c1d9dd382d  vmovaps [rsp+0x50], xmm5
000076c1d9dd3833  vmovaps [rsp+0x60], xmm6
000076c1d9dd3839  vmovaps [rsp+0x70], xmm7
000076c1d9dd383f  vmovaps [rsp+0x80], xmm8
000076c1d9dd3848  vmovaps [rsp+0x90], xmm9
000076c1d9dd3851  vmovaps [rsp+0xA0], xmm10
000076c1d9dd385a  vmovaps [rsp+0xB0], xmm11
000076c1d9dd3863  vmovaps [rsp+0xC0], xmm12
000076c1d9dd386c  vmovaps [rsp+0xD0], xmm13
000076c1d9dd3875  vmovaps [rsp+0xE0], xmm14
000076c1d9dd387e  sub rsp, 0x30
000076c1d9dd3882  movaps [rsp], xmm15
000076c1d9dd3887  movaps [rsp+0x10], xmm13
000076c1d9dd388d  movaps [rsp+0x20], xmm10
000076c1d9dd3893  lea rdi, [rsp]
000076c1d9dd3897  mov esi, 0x00
000076c1d9dd389c  mov rax, 0x5EA58B9E0530
000076c1d9dd38a6  call rax
000076c1d9dd38a8  movaps xmm15, [rsp]
000076c1d9dd38ad  add rsp, 0x30
000076c1d9dd38b1  vmovaps xmm0, [rsp]
000076c1d9dd38b6  vmovaps xmm1, [rsp+0x10]
000076c1d9dd38bc  vmovaps xmm2, [rsp+0x20]
000076c1d9dd38c2  vmovaps xmm3, [rsp+0x30]
000076c1d9dd38c8  vmovaps xmm4, [rsp+0x40]
000076c1d9dd38ce  vmovaps xmm5, [rsp+0x50]
000076c1d9dd38d4  vmovaps xmm6, [rsp+0x60]
000076c1d9dd38da  vmovaps xmm7, [rsp+0x70]
000076c1d9dd38e0  vmovaps xmm8, [rsp+0x80]
000076c1d9dd38e9  vmovaps xmm9, [rsp+0x90]
000076c1d9dd38f2  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd38fb  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd3904  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd390d  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd3916  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd391f  add rsp, 0xF0
000076c1d9dd3926  pop r11
000076c1d9dd3928  pop r10
000076c1d9dd392a  pop r9
000076c1d9dd392c  pop r8
000076c1d9dd392e  pop rsi
000076c1d9dd392f  pop rdi
000076c1d9dd3930  pop rdx
000076c1d9dd3931  pop rcx
000076c1d9dd3932  pop rax
000076c1d9dd3933  add rsp, 0x08
000076c1d9dd3937  jmp 0x000076C1D9DCFF55
000076c1d9dd393c  call 0x000076C1D9C0C260
000076c1d9dd3941  jmp 0x000076C1D9DCFFB0
000076c1d9dd3946  sub rsp, 0x08
000076c1d9dd394a  push rax
000076c1d9dd394b  push rcx
000076c1d9dd394c  push rdx
000076c1d9dd394d  push rdi
000076c1d9dd394e  push rsi
000076c1d9dd394f  push r8
000076c1d9dd3951  push r9
000076c1d9dd3953  push r10
000076c1d9dd3955  push r11
000076c1d9dd3957  sub rsp, 0xF0
000076c1d9dd395e  vmovaps [rsp], xmm0
000076c1d9dd3963  vmovaps [rsp+0x10], xmm1
000076c1d9dd3969  vmovaps [rsp+0x20], xmm2
000076c1d9dd396f  vmovaps [rsp+0x30], xmm3
000076c1d9dd3975  vmovaps [rsp+0x40], xmm4
000076c1d9dd397b  vmovaps [rsp+0x50], xmm5
000076c1d9dd3981  vmovaps [rsp+0x60], xmm6
000076c1d9dd3987  vmovaps [rsp+0x70], xmm7
000076c1d9dd398d  vmovaps [rsp+0x80], xmm8
000076c1d9dd3996  vmovaps [rsp+0x90], xmm10
000076c1d9dd399f  vmovaps [rsp+0xA0], xmm11
000076c1d9dd39a8  vmovaps [rsp+0xB0], xmm12
000076c1d9dd39b1  vmovaps [rsp+0xC0], xmm13
000076c1d9dd39ba  vmovaps [rsp+0xD0], xmm14
000076c1d9dd39c3  vmovaps [rsp+0xE0], xmm15
000076c1d9dd39cc  sub rsp, 0x30
000076c1d9dd39d0  movaps [rsp], xmm9
000076c1d9dd39d5  movaps [rsp+0x10], xmm8
000076c1d9dd39db  movaps [rsp+0x20], xmm10
000076c1d9dd39e1  lea rdi, [rsp]
000076c1d9dd39e5  mov esi, 0x00
000076c1d9dd39ea  mov rax, 0x5EA58B9E0530
000076c1d9dd39f4  call rax
000076c1d9dd39f6  movaps xmm9, [rsp]
000076c1d9dd39fb  add rsp, 0x30
000076c1d9dd39ff  vmovaps xmm0, [rsp]
000076c1d9dd3a04  vmovaps xmm1, [rsp+0x10]
000076c1d9dd3a0a  vmovaps xmm2, [rsp+0x20]
000076c1d9dd3a10  vmovaps xmm3, [rsp+0x30]
000076c1d9dd3a16  vmovaps xmm4, [rsp+0x40]
000076c1d9dd3a1c  vmovaps xmm5, [rsp+0x50]
000076c1d9dd3a22  vmovaps xmm6, [rsp+0x60]
000076c1d9dd3a28  vmovaps xmm7, [rsp+0x70]
000076c1d9dd3a2e  vmovaps xmm8, [rsp+0x80]
000076c1d9dd3a37  vmovaps xmm10, [rsp+0x90]
000076c1d9dd3a40  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd3a49  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd3a52  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd3a5b  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd3a64  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd3a6d  add rsp, 0xF0
000076c1d9dd3a74  pop r11
000076c1d9dd3a76  pop r10
000076c1d9dd3a78  pop r9
000076c1d9dd3a7a  pop r8
000076c1d9dd3a7c  pop rsi
000076c1d9dd3a7d  pop rdi
000076c1d9dd3a7e  pop rdx
000076c1d9dd3a7f  pop rcx
000076c1d9dd3a80  pop rax
000076c1d9dd3a81  add rsp, 0x08
000076c1d9dd3a85  jmp 0x000076C1D9DCFFE1
000076c1d9dd3a8a  sub rsp, 0x08
000076c1d9dd3a8e  push rax
000076c1d9dd3a8f  push rcx
000076c1d9dd3a90  push rdx
000076c1d9dd3a91  push rdi
000076c1d9dd3a92  push rsi
000076c1d9dd3a93  push r8
000076c1d9dd3a95  push r9
000076c1d9dd3a97  push r10
000076c1d9dd3a99  push r11
000076c1d9dd3a9b  sub rsp, 0xF0
000076c1d9dd3aa2  vmovaps [rsp], xmm0
000076c1d9dd3aa7  vmovaps [rsp+0x10], xmm1
000076c1d9dd3aad  vmovaps [rsp+0x20], xmm2
000076c1d9dd3ab3  vmovaps [rsp+0x30], xmm3
000076c1d9dd3ab9  vmovaps [rsp+0x40], xmm4
000076c1d9dd3abf  vmovaps [rsp+0x50], xmm5
000076c1d9dd3ac5  vmovaps [rsp+0x60], xmm6
000076c1d9dd3acb  vmovaps [rsp+0x70], xmm7
000076c1d9dd3ad1  vmovaps [rsp+0x80], xmm8
000076c1d9dd3ada  vmovaps [rsp+0x90], xmm9
000076c1d9dd3ae3  vmovaps [rsp+0xA0], xmm11
000076c1d9dd3aec  vmovaps [rsp+0xB0], xmm12
000076c1d9dd3af5  vmovaps [rsp+0xC0], xmm13
000076c1d9dd3afe  vmovaps [rsp+0xD0], xmm14
000076c1d9dd3b07  vmovaps [rsp+0xE0], xmm15
000076c1d9dd3b10  sub rsp, 0x30
000076c1d9dd3b14  movaps [rsp], xmm10
000076c1d9dd3b19  movaps [rsp+0x10], xmm1
000076c1d9dd3b1e  movaps [rsp+0x20], xmm11
000076c1d9dd3b24  lea rdi, [rsp]
000076c1d9dd3b28  mov esi, 0x00
000076c1d9dd3b2d  mov rax, 0x5EA58B9E0530
000076c1d9dd3b37  call rax
000076c1d9dd3b39  movaps xmm10, [rsp]
000076c1d9dd3b3e  add rsp, 0x30
000076c1d9dd3b42  vmovaps xmm0, [rsp]
000076c1d9dd3b47  vmovaps xmm1, [rsp+0x10]
000076c1d9dd3b4d  vmovaps xmm2, [rsp+0x20]
000076c1d9dd3b53  vmovaps xmm3, [rsp+0x30]
000076c1d9dd3b59  vmovaps xmm4, [rsp+0x40]
000076c1d9dd3b5f  vmovaps xmm5, [rsp+0x50]
000076c1d9dd3b65  vmovaps xmm6, [rsp+0x60]
000076c1d9dd3b6b  vmovaps xmm7, [rsp+0x70]
000076c1d9dd3b71  vmovaps xmm8, [rsp+0x80]
000076c1d9dd3b7a  vmovaps xmm9, [rsp+0x90]
000076c1d9dd3b83  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd3b8c  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd3b95  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd3b9e  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd3ba7  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd3bb0  add rsp, 0xF0
000076c1d9dd3bb7  pop r11
000076c1d9dd3bb9  pop r10
000076c1d9dd3bbb  pop r9
000076c1d9dd3bbd  pop r8
000076c1d9dd3bbf  pop rsi
000076c1d9dd3bc0  pop rdi
000076c1d9dd3bc1  pop rdx
000076c1d9dd3bc2  pop rcx
000076c1d9dd3bc3  pop rax
000076c1d9dd3bc4  add rsp, 0x08
000076c1d9dd3bc8  jmp 0x000076C1D9DCFFFC
000076c1d9dd3bcd  sub rsp, 0x08
000076c1d9dd3bd1  push rax
000076c1d9dd3bd2  push rcx
000076c1d9dd3bd3  push rdx
000076c1d9dd3bd4  push rdi
000076c1d9dd3bd5  push rsi
000076c1d9dd3bd6  push r8
000076c1d9dd3bd8  push r9
000076c1d9dd3bda  push r10
000076c1d9dd3bdc  push r11
000076c1d9dd3bde  sub rsp, 0xF0
000076c1d9dd3be5  vmovaps [rsp], xmm0
000076c1d9dd3bea  vmovaps [rsp+0x10], xmm2
000076c1d9dd3bf0  vmovaps [rsp+0x20], xmm3
000076c1d9dd3bf6  vmovaps [rsp+0x30], xmm4
000076c1d9dd3bfc  vmovaps [rsp+0x40], xmm5
000076c1d9dd3c02  vmovaps [rsp+0x50], xmm6
000076c1d9dd3c08  vmovaps [rsp+0x60], xmm7
000076c1d9dd3c0e  vmovaps [rsp+0x70], xmm8
000076c1d9dd3c14  vmovaps [rsp+0x80], xmm9
000076c1d9dd3c1d  vmovaps [rsp+0x90], xmm10
000076c1d9dd3c26  vmovaps [rsp+0xA0], xmm11
000076c1d9dd3c2f  vmovaps [rsp+0xB0], xmm12
000076c1d9dd3c38  vmovaps [rsp+0xC0], xmm13
000076c1d9dd3c41  vmovaps [rsp+0xD0], xmm14
000076c1d9dd3c4a  vmovaps [rsp+0xE0], xmm15
000076c1d9dd3c53  sub rsp, 0x30
000076c1d9dd3c57  movaps [rsp], xmm1
000076c1d9dd3c5b  movaps [rsp+0x10], xmm14
000076c1d9dd3c61  movaps [rsp+0x20], xmm6
000076c1d9dd3c66  lea rdi, [rsp]
000076c1d9dd3c6a  mov esi, 0x00
000076c1d9dd3c6f  mov rax, 0x5EA58B9E0530
000076c1d9dd3c79  call rax
000076c1d9dd3c7b  movaps xmm1, [rsp]
000076c1d9dd3c7f  add rsp, 0x30
000076c1d9dd3c83  vmovaps xmm0, [rsp]
000076c1d9dd3c88  vmovaps xmm2, [rsp+0x10]
000076c1d9dd3c8e  vmovaps xmm3, [rsp+0x20]
000076c1d9dd3c94  vmovaps xmm4, [rsp+0x30]
000076c1d9dd3c9a  vmovaps xmm5, [rsp+0x40]
000076c1d9dd3ca0  vmovaps xmm6, [rsp+0x50]
000076c1d9dd3ca6  vmovaps xmm7, [rsp+0x60]
000076c1d9dd3cac  vmovaps xmm8, [rsp+0x70]
000076c1d9dd3cb2  vmovaps xmm9, [rsp+0x80]
000076c1d9dd3cbb  vmovaps xmm10, [rsp+0x90]
000076c1d9dd3cc4  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd3ccd  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd3cd6  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd3cdf  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd3ce8  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd3cf1  add rsp, 0xF0
000076c1d9dd3cf8  pop r11
000076c1d9dd3cfa  pop r10
000076c1d9dd3cfc  pop r9
000076c1d9dd3cfe  pop r8
000076c1d9dd3d00  pop rsi
000076c1d9dd3d01  pop rdi
000076c1d9dd3d02  pop rdx
000076c1d9dd3d03  pop rcx
000076c1d9dd3d04  pop rax
000076c1d9dd3d05  add rsp, 0x08
000076c1d9dd3d09  jmp 0x000076C1D9DD0015
000076c1d9dd3d0e  sub rsp, 0x08
000076c1d9dd3d12  push rax
000076c1d9dd3d13  push rcx
000076c1d9dd3d14  push rdx
000076c1d9dd3d15  push rdi
000076c1d9dd3d16  push rsi
000076c1d9dd3d17  push r8
000076c1d9dd3d19  push r9
000076c1d9dd3d1b  push r10
000076c1d9dd3d1d  push r11
000076c1d9dd3d1f  sub rsp, 0xF0
000076c1d9dd3d26  vmovaps [rsp], xmm0
000076c1d9dd3d2b  vmovaps [rsp+0x10], xmm1
000076c1d9dd3d31  vmovaps [rsp+0x20], xmm2
000076c1d9dd3d37  vmovaps [rsp+0x30], xmm3
000076c1d9dd3d3d  vmovaps [rsp+0x40], xmm4
000076c1d9dd3d43  vmovaps [rsp+0x50], xmm5
000076c1d9dd3d49  vmovaps [rsp+0x60], xmm6
000076c1d9dd3d4f  vmovaps [rsp+0x70], xmm7
000076c1d9dd3d55  vmovaps [rsp+0x80], xmm8
000076c1d9dd3d5e  vmovaps [rsp+0x90], xmm9
000076c1d9dd3d67  vmovaps [rsp+0xA0], xmm10
000076c1d9dd3d70  vmovaps [rsp+0xB0], xmm12
000076c1d9dd3d79  vmovaps [rsp+0xC0], xmm13
000076c1d9dd3d82  vmovaps [rsp+0xD0], xmm14
000076c1d9dd3d8b  vmovaps [rsp+0xE0], xmm15
000076c1d9dd3d94  sub rsp, 0x30
000076c1d9dd3d98  movaps [rsp], xmm11
000076c1d9dd3d9d  movaps [rsp+0x10], xmm13
000076c1d9dd3da3  movaps [rsp+0x20], xmm14
000076c1d9dd3da9  lea rdi, [rsp]
000076c1d9dd3dad  mov esi, 0x00
000076c1d9dd3db2  mov rax, 0x5EA58B9E0530
000076c1d9dd3dbc  call rax
000076c1d9dd3dbe  movaps xmm11, [rsp]
000076c1d9dd3dc3  add rsp, 0x30
000076c1d9dd3dc7  vmovaps xmm0, [rsp]
000076c1d9dd3dcc  vmovaps xmm1, [rsp+0x10]
000076c1d9dd3dd2  vmovaps xmm2, [rsp+0x20]
000076c1d9dd3dd8  vmovaps xmm3, [rsp+0x30]
000076c1d9dd3dde  vmovaps xmm4, [rsp+0x40]
000076c1d9dd3de4  vmovaps xmm5, [rsp+0x50]
000076c1d9dd3dea  vmovaps xmm6, [rsp+0x60]
000076c1d9dd3df0  vmovaps xmm7, [rsp+0x70]
000076c1d9dd3df6  vmovaps xmm8, [rsp+0x80]
000076c1d9dd3dff  vmovaps xmm9, [rsp+0x90]
000076c1d9dd3e08  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd3e11  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd3e1a  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd3e23  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd3e2c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd3e35  add rsp, 0xF0
000076c1d9dd3e3c  pop r11
000076c1d9dd3e3e  pop r10
000076c1d9dd3e40  pop r9
000076c1d9dd3e42  pop r8
000076c1d9dd3e44  pop rsi
000076c1d9dd3e45  pop rdi
000076c1d9dd3e46  pop rdx
000076c1d9dd3e47  pop rcx
000076c1d9dd3e48  pop rax
000076c1d9dd3e49  add rsp, 0x08
000076c1d9dd3e4d  jmp 0x000076C1D9DD003F
000076c1d9dd3e52  sub rsp, 0x08
000076c1d9dd3e56  push rax
000076c1d9dd3e57  push rcx
000076c1d9dd3e58  push rdx
000076c1d9dd3e59  push rdi
000076c1d9dd3e5a  push rsi
000076c1d9dd3e5b  push r8
000076c1d9dd3e5d  push r9
000076c1d9dd3e5f  push r10
000076c1d9dd3e61  push r11
000076c1d9dd3e63  sub rsp, 0xF0
000076c1d9dd3e6a  vmovaps [rsp], xmm0
000076c1d9dd3e6f  vmovaps [rsp+0x10], xmm1
000076c1d9dd3e75  vmovaps [rsp+0x20], xmm2
000076c1d9dd3e7b  vmovaps [rsp+0x30], xmm3
000076c1d9dd3e81  vmovaps [rsp+0x40], xmm4
000076c1d9dd3e87  vmovaps [rsp+0x50], xmm5
000076c1d9dd3e8d  vmovaps [rsp+0x60], xmm6
000076c1d9dd3e93  vmovaps [rsp+0x70], xmm7
000076c1d9dd3e99  vmovaps [rsp+0x80], xmm8
000076c1d9dd3ea2  vmovaps [rsp+0x90], xmm9
000076c1d9dd3eab  vmovaps [rsp+0xA0], xmm10
000076c1d9dd3eb4  vmovaps [rsp+0xB0], xmm11
000076c1d9dd3ebd  vmovaps [rsp+0xC0], xmm12
000076c1d9dd3ec6  vmovaps [rsp+0xD0], xmm14
000076c1d9dd3ecf  vmovaps [rsp+0xE0], xmm15
000076c1d9dd3ed8  sub rsp, 0x30
000076c1d9dd3edc  movaps [rsp], xmm13
000076c1d9dd3ee1  movaps [rsp+0x10], xmm8
000076c1d9dd3ee7  movaps [rsp+0x20], xmm14
000076c1d9dd3eed  lea rdi, [rsp]
000076c1d9dd3ef1  mov esi, 0x00
000076c1d9dd3ef6  mov rax, 0x5EA58B9E0530
000076c1d9dd3f00  call rax
000076c1d9dd3f02  movaps xmm13, [rsp]
000076c1d9dd3f07  add rsp, 0x30
000076c1d9dd3f0b  vmovaps xmm0, [rsp]
000076c1d9dd3f10  vmovaps xmm1, [rsp+0x10]
000076c1d9dd3f16  vmovaps xmm2, [rsp+0x20]
000076c1d9dd3f1c  vmovaps xmm3, [rsp+0x30]
000076c1d9dd3f22  vmovaps xmm4, [rsp+0x40]
000076c1d9dd3f28  vmovaps xmm5, [rsp+0x50]
000076c1d9dd3f2e  vmovaps xmm6, [rsp+0x60]
000076c1d9dd3f34  vmovaps xmm7, [rsp+0x70]
000076c1d9dd3f3a  vmovaps xmm8, [rsp+0x80]
000076c1d9dd3f43  vmovaps xmm9, [rsp+0x90]
000076c1d9dd3f4c  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd3f55  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd3f5e  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd3f67  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd3f70  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd3f79  add rsp, 0xF0
000076c1d9dd3f80  pop r11
000076c1d9dd3f82  pop r10
000076c1d9dd3f84  pop r9
000076c1d9dd3f86  pop r8
000076c1d9dd3f88  pop rsi
000076c1d9dd3f89  pop rdi
000076c1d9dd3f8a  pop rdx
000076c1d9dd3f8b  pop rcx
000076c1d9dd3f8c  pop rax
000076c1d9dd3f8d  add rsp, 0x08
000076c1d9dd3f91  jmp 0x000076C1D9DD006E
000076c1d9dd3f96  sub rsp, 0x08
000076c1d9dd3f9a  push rax
000076c1d9dd3f9b  push rcx
000076c1d9dd3f9c  push rdx
000076c1d9dd3f9d  push rdi
000076c1d9dd3f9e  push rsi
000076c1d9dd3f9f  push r8
000076c1d9dd3fa1  push r9
000076c1d9dd3fa3  push r10
000076c1d9dd3fa5  push r11
000076c1d9dd3fa7  sub rsp, 0xF0
000076c1d9dd3fae  vmovaps [rsp], xmm0
000076c1d9dd3fb3  vmovaps [rsp+0x10], xmm1
000076c1d9dd3fb9  vmovaps [rsp+0x20], xmm2
000076c1d9dd3fbf  vmovaps [rsp+0x30], xmm3
000076c1d9dd3fc5  vmovaps [rsp+0x40], xmm4
000076c1d9dd3fcb  vmovaps [rsp+0x50], xmm5
000076c1d9dd3fd1  vmovaps [rsp+0x60], xmm6
000076c1d9dd3fd7  vmovaps [rsp+0x70], xmm7
000076c1d9dd3fdd  vmovaps [rsp+0x80], xmm9
000076c1d9dd3fe6  vmovaps [rsp+0x90], xmm10
000076c1d9dd3fef  vmovaps [rsp+0xA0], xmm11
000076c1d9dd3ff8  vmovaps [rsp+0xB0], xmm12
000076c1d9dd4001  vmovaps [rsp+0xC0], xmm13
000076c1d9dd400a  vmovaps [rsp+0xD0], xmm14
000076c1d9dd4013  vmovaps [rsp+0xE0], xmm15
000076c1d9dd401c  sub rsp, 0x30
000076c1d9dd4020  movaps [rsp], xmm8
000076c1d9dd4025  movaps [rsp+0x10], xmm7
000076c1d9dd402a  movaps [rsp+0x20], xmm14
000076c1d9dd4030  lea rdi, [rsp]
000076c1d9dd4034  mov esi, 0x00
000076c1d9dd4039  mov rax, 0x5EA58B9E0530
000076c1d9dd4043  call rax
000076c1d9dd4045  movaps xmm8, [rsp]
000076c1d9dd404a  add rsp, 0x30
000076c1d9dd404e  vmovaps xmm0, [rsp]
000076c1d9dd4053  vmovaps xmm1, [rsp+0x10]
000076c1d9dd4059  vmovaps xmm2, [rsp+0x20]
000076c1d9dd405f  vmovaps xmm3, [rsp+0x30]
000076c1d9dd4065  vmovaps xmm4, [rsp+0x40]
000076c1d9dd406b  vmovaps xmm5, [rsp+0x50]
000076c1d9dd4071  vmovaps xmm6, [rsp+0x60]
000076c1d9dd4077  vmovaps xmm7, [rsp+0x70]
000076c1d9dd407d  vmovaps xmm9, [rsp+0x80]
000076c1d9dd4086  vmovaps xmm10, [rsp+0x90]
000076c1d9dd408f  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd4098  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd40a1  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd40aa  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd40b3  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd40bc  add rsp, 0xF0
000076c1d9dd40c3  pop r11
000076c1d9dd40c5  pop r10
000076c1d9dd40c7  pop r9
000076c1d9dd40c9  pop r8
000076c1d9dd40cb  pop rsi
000076c1d9dd40cc  pop rdi
000076c1d9dd40cd  pop rdx
000076c1d9dd40ce  pop rcx
000076c1d9dd40cf  pop rax
000076c1d9dd40d0  add rsp, 0x08
000076c1d9dd40d4  jmp 0x000076C1D9DD0094
000076c1d9dd40d9  sub rsp, 0x08
000076c1d9dd40dd  push rax
000076c1d9dd40de  push rcx
000076c1d9dd40df  push rdx
000076c1d9dd40e0  push rdi
000076c1d9dd40e1  push rsi
000076c1d9dd40e2  push r8
000076c1d9dd40e4  push r9
000076c1d9dd40e6  push r10
000076c1d9dd40e8  push r11
000076c1d9dd40ea  sub rsp, 0xF0
000076c1d9dd40f1  vmovaps [rsp], xmm0
000076c1d9dd40f6  vmovaps [rsp+0x10], xmm1
000076c1d9dd40fc  vmovaps [rsp+0x20], xmm2
000076c1d9dd4102  vmovaps [rsp+0x30], xmm3
000076c1d9dd4108  vmovaps [rsp+0x40], xmm4
000076c1d9dd410e  vmovaps [rsp+0x50], xmm5
000076c1d9dd4114  vmovaps [rsp+0x60], xmm6
000076c1d9dd411a  vmovaps [rsp+0x70], xmm7
000076c1d9dd4120  vmovaps [rsp+0x80], xmm8
000076c1d9dd4129  vmovaps [rsp+0x90], xmm9
000076c1d9dd4132  vmovaps [rsp+0xA0], xmm10
000076c1d9dd413b  vmovaps [rsp+0xB0], xmm11
000076c1d9dd4144  vmovaps [rsp+0xC0], xmm12
000076c1d9dd414d  vmovaps [rsp+0xD0], xmm13
000076c1d9dd4156  vmovaps [rsp+0xE0], xmm15
000076c1d9dd415f  sub rsp, 0x30
000076c1d9dd4163  movaps [rsp], xmm14
000076c1d9dd4168  movaps [rsp+0x10], xmm12
000076c1d9dd416e  movaps [rsp+0x20], xmm9
000076c1d9dd4174  lea rdi, [rsp]
000076c1d9dd4178  mov esi, 0x00
000076c1d9dd417d  mov rax, 0x5EA58B9E0530
000076c1d9dd4187  call rax
000076c1d9dd4189  movaps xmm14, [rsp]
000076c1d9dd418e  add rsp, 0x30
000076c1d9dd4192  vmovaps xmm0, [rsp]
000076c1d9dd4197  vmovaps xmm1, [rsp+0x10]
000076c1d9dd419d  vmovaps xmm2, [rsp+0x20]
000076c1d9dd41a3  vmovaps xmm3, [rsp+0x30]
000076c1d9dd41a9  vmovaps xmm4, [rsp+0x40]
000076c1d9dd41af  vmovaps xmm5, [rsp+0x50]
000076c1d9dd41b5  vmovaps xmm6, [rsp+0x60]
000076c1d9dd41bb  vmovaps xmm7, [rsp+0x70]
000076c1d9dd41c1  vmovaps xmm8, [rsp+0x80]
000076c1d9dd41ca  vmovaps xmm9, [rsp+0x90]
000076c1d9dd41d3  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd41dc  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd41e5  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd41ee  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd41f7  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4200  add rsp, 0xF0
000076c1d9dd4207  pop r11
000076c1d9dd4209  pop r10
000076c1d9dd420b  pop r9
000076c1d9dd420d  pop r8
000076c1d9dd420f  pop rsi
000076c1d9dd4210  pop rdi
000076c1d9dd4211  pop rdx
000076c1d9dd4212  pop rcx
000076c1d9dd4213  pop rax
000076c1d9dd4214  add rsp, 0x08
000076c1d9dd4218  jmp 0x000076C1D9DD00AE
000076c1d9dd421d  sub rsp, 0x08
000076c1d9dd4221  push rax
000076c1d9dd4222  push rcx
000076c1d9dd4223  push rdx
000076c1d9dd4224  push rdi
000076c1d9dd4225  push rsi
000076c1d9dd4226  push r8
000076c1d9dd4228  push r9
000076c1d9dd422a  push r10
000076c1d9dd422c  push r11
000076c1d9dd422e  sub rsp, 0xF0
000076c1d9dd4235  vmovaps [rsp], xmm0
000076c1d9dd423a  vmovaps [rsp+0x10], xmm1
000076c1d9dd4240  vmovaps [rsp+0x20], xmm2
000076c1d9dd4246  vmovaps [rsp+0x30], xmm3
000076c1d9dd424c  vmovaps [rsp+0x40], xmm4
000076c1d9dd4252  vmovaps [rsp+0x50], xmm5
000076c1d9dd4258  vmovaps [rsp+0x60], xmm6
000076c1d9dd425e  vmovaps [rsp+0x70], xmm7
000076c1d9dd4264  vmovaps [rsp+0x80], xmm8
000076c1d9dd426d  vmovaps [rsp+0x90], xmm10
000076c1d9dd4276  vmovaps [rsp+0xA0], xmm11
000076c1d9dd427f  vmovaps [rsp+0xB0], xmm12
000076c1d9dd4288  vmovaps [rsp+0xC0], xmm13
000076c1d9dd4291  vmovaps [rsp+0xD0], xmm14
000076c1d9dd429a  vmovaps [rsp+0xE0], xmm15
000076c1d9dd42a3  sub rsp, 0x30
000076c1d9dd42a7  movaps [rsp], xmm9
000076c1d9dd42ac  movaps [rsp+0x10], xmm7
000076c1d9dd42b1  movaps [rsp+0x20], xmm12
000076c1d9dd42b7  lea rdi, [rsp]
000076c1d9dd42bb  mov esi, 0x00
000076c1d9dd42c0  mov rax, 0x5EA58B9E0530
000076c1d9dd42ca  call rax
000076c1d9dd42cc  movaps xmm9, [rsp]
000076c1d9dd42d1  add rsp, 0x30
000076c1d9dd42d5  vmovaps xmm0, [rsp]
000076c1d9dd42da  vmovaps xmm1, [rsp+0x10]
000076c1d9dd42e0  vmovaps xmm2, [rsp+0x20]
000076c1d9dd42e6  vmovaps xmm3, [rsp+0x30]
000076c1d9dd42ec  vmovaps xmm4, [rsp+0x40]
000076c1d9dd42f2  vmovaps xmm5, [rsp+0x50]
000076c1d9dd42f8  vmovaps xmm6, [rsp+0x60]
000076c1d9dd42fe  vmovaps xmm7, [rsp+0x70]
000076c1d9dd4304  vmovaps xmm8, [rsp+0x80]
000076c1d9dd430d  vmovaps xmm10, [rsp+0x90]
000076c1d9dd4316  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd431f  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd4328  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd4331  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd433a  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4343  add rsp, 0xF0
000076c1d9dd434a  pop r11
000076c1d9dd434c  pop r10
000076c1d9dd434e  pop r9
000076c1d9dd4350  pop r8
000076c1d9dd4352  pop rsi
000076c1d9dd4353  pop rdi
000076c1d9dd4354  pop rdx
000076c1d9dd4355  pop rcx
000076c1d9dd4356  pop rax
000076c1d9dd4357  add rsp, 0x08
000076c1d9dd435b  jmp 0x000076C1D9DD00DD
000076c1d9dd4360  sub rsp, 0x08
000076c1d9dd4364  push rax
000076c1d9dd4365  push rcx
000076c1d9dd4366  push rdx
000076c1d9dd4367  push rdi
000076c1d9dd4368  push rsi
000076c1d9dd4369  push r8
000076c1d9dd436b  push r9
000076c1d9dd436d  push r10
000076c1d9dd436f  push r11
000076c1d9dd4371  sub rsp, 0xF0
000076c1d9dd4378  vmovaps [rsp], xmm0
000076c1d9dd437d  vmovaps [rsp+0x10], xmm1
000076c1d9dd4383  vmovaps [rsp+0x20], xmm2
000076c1d9dd4389  vmovaps [rsp+0x30], xmm3
000076c1d9dd438f  vmovaps [rsp+0x40], xmm4
000076c1d9dd4395  vmovaps [rsp+0x50], xmm5
000076c1d9dd439b  vmovaps [rsp+0x60], xmm6
000076c1d9dd43a1  vmovaps [rsp+0x70], xmm7
000076c1d9dd43a7  vmovaps [rsp+0x80], xmm8
000076c1d9dd43b0  vmovaps [rsp+0x90], xmm9
000076c1d9dd43b9  vmovaps [rsp+0xA0], xmm10
000076c1d9dd43c2  vmovaps [rsp+0xB0], xmm11
000076c1d9dd43cb  vmovaps [rsp+0xC0], xmm13
000076c1d9dd43d4  vmovaps [rsp+0xD0], xmm14
000076c1d9dd43dd  vmovaps [rsp+0xE0], xmm15
000076c1d9dd43e6  sub rsp, 0x30
000076c1d9dd43ea  movaps [rsp], xmm12
000076c1d9dd43ef  movaps [rsp+0x10], xmm15
000076c1d9dd43f5  movaps [rsp+0x20], xmm11
000076c1d9dd43fb  lea rdi, [rsp]
000076c1d9dd43ff  mov esi, 0x00
000076c1d9dd4404  mov rax, 0x5EA58B9E0530
000076c1d9dd440e  call rax
000076c1d9dd4410  movaps xmm12, [rsp]
000076c1d9dd4415  add rsp, 0x30
000076c1d9dd4419  vmovaps xmm0, [rsp]
000076c1d9dd441e  vmovaps xmm1, [rsp+0x10]
000076c1d9dd4424  vmovaps xmm2, [rsp+0x20]
000076c1d9dd442a  vmovaps xmm3, [rsp+0x30]
000076c1d9dd4430  vmovaps xmm4, [rsp+0x40]
000076c1d9dd4436  vmovaps xmm5, [rsp+0x50]
000076c1d9dd443c  vmovaps xmm6, [rsp+0x60]
000076c1d9dd4442  vmovaps xmm7, [rsp+0x70]
000076c1d9dd4448  vmovaps xmm8, [rsp+0x80]
000076c1d9dd4451  vmovaps xmm9, [rsp+0x90]
000076c1d9dd445a  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd4463  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd446c  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd4475  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd447e  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4487  add rsp, 0xF0
000076c1d9dd448e  pop r11
000076c1d9dd4490  pop r10
000076c1d9dd4492  pop r9
000076c1d9dd4494  pop r8
000076c1d9dd4496  pop rsi
000076c1d9dd4497  pop rdi
000076c1d9dd4498  pop rdx
000076c1d9dd4499  pop rcx
000076c1d9dd449a  pop rax
000076c1d9dd449b  add rsp, 0x08
000076c1d9dd449f  jmp 0x000076C1D9DD00F7
000076c1d9dd44a4  sub rsp, 0x08
000076c1d9dd44a8  push rax
000076c1d9dd44a9  push rcx
000076c1d9dd44aa  push rdx
000076c1d9dd44ab  push rdi
000076c1d9dd44ac  push rsi
000076c1d9dd44ad  push r8
000076c1d9dd44af  push r9
000076c1d9dd44b1  push r10
000076c1d9dd44b3  push r11
000076c1d9dd44b5  sub rsp, 0xF0
000076c1d9dd44bc  vmovaps [rsp], xmm0
000076c1d9dd44c1  vmovaps [rsp+0x10], xmm1
000076c1d9dd44c7  vmovaps [rsp+0x20], xmm2
000076c1d9dd44cd  vmovaps [rsp+0x30], xmm3
000076c1d9dd44d3  vmovaps [rsp+0x40], xmm4
000076c1d9dd44d9  vmovaps [rsp+0x50], xmm5
000076c1d9dd44df  vmovaps [rsp+0x60], xmm6
000076c1d9dd44e5  vmovaps [rsp+0x70], xmm7
000076c1d9dd44eb  vmovaps [rsp+0x80], xmm8
000076c1d9dd44f4  vmovaps [rsp+0x90], xmm9
000076c1d9dd44fd  vmovaps [rsp+0xA0], xmm10
000076c1d9dd4506  vmovaps [rsp+0xB0], xmm12
000076c1d9dd450f  vmovaps [rsp+0xC0], xmm13
000076c1d9dd4518  vmovaps [rsp+0xD0], xmm14
000076c1d9dd4521  vmovaps [rsp+0xE0], xmm15
000076c1d9dd452a  sub rsp, 0x30
000076c1d9dd452e  movaps [rsp], xmm11
000076c1d9dd4533  movaps [rsp+0x10], xmm7
000076c1d9dd4538  movaps [rsp+0x20], xmm15
000076c1d9dd453e  lea rdi, [rsp]
000076c1d9dd4542  mov esi, 0x00
000076c1d9dd4547  mov rax, 0x5EA58B9E0530
000076c1d9dd4551  call rax
000076c1d9dd4553  movaps xmm11, [rsp]
000076c1d9dd4558  add rsp, 0x30
000076c1d9dd455c  vmovaps xmm0, [rsp]
000076c1d9dd4561  vmovaps xmm1, [rsp+0x10]
000076c1d9dd4567  vmovaps xmm2, [rsp+0x20]
000076c1d9dd456d  vmovaps xmm3, [rsp+0x30]
000076c1d9dd4573  vmovaps xmm4, [rsp+0x40]
000076c1d9dd4579  vmovaps xmm5, [rsp+0x50]
000076c1d9dd457f  vmovaps xmm6, [rsp+0x60]
000076c1d9dd4585  vmovaps xmm7, [rsp+0x70]
000076c1d9dd458b  vmovaps xmm8, [rsp+0x80]
000076c1d9dd4594  vmovaps xmm9, [rsp+0x90]
000076c1d9dd459d  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd45a6  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd45af  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd45b8  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd45c1  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd45ca  add rsp, 0xF0
000076c1d9dd45d1  pop r11
000076c1d9dd45d3  pop r10
000076c1d9dd45d5  pop r9
000076c1d9dd45d7  pop r8
000076c1d9dd45d9  pop rsi
000076c1d9dd45da  pop rdi
000076c1d9dd45db  pop rdx
000076c1d9dd45dc  pop rcx
000076c1d9dd45dd  pop rax
000076c1d9dd45de  add rsp, 0x08
000076c1d9dd45e2  jmp 0x000076C1D9DD0123
000076c1d9dd45e7  sub rsp, 0x08
000076c1d9dd45eb  push rax
000076c1d9dd45ec  push rcx
000076c1d9dd45ed  push rdx
000076c1d9dd45ee  push rdi
000076c1d9dd45ef  push rsi
000076c1d9dd45f0  push r8
000076c1d9dd45f2  push r9
000076c1d9dd45f4  push r10
000076c1d9dd45f6  push r11
000076c1d9dd45f8  sub rsp, 0xF0
000076c1d9dd45ff  vmovaps [rsp], xmm0
000076c1d9dd4604  vmovaps [rsp+0x10], xmm1
000076c1d9dd460a  vmovaps [rsp+0x20], xmm2
000076c1d9dd4610  vmovaps [rsp+0x30], xmm3
000076c1d9dd4616  vmovaps [rsp+0x40], xmm4
000076c1d9dd461c  vmovaps [rsp+0x50], xmm5
000076c1d9dd4622  vmovaps [rsp+0x60], xmm6
000076c1d9dd4628  vmovaps [rsp+0x70], xmm7
000076c1d9dd462e  vmovaps [rsp+0x80], xmm8
000076c1d9dd4637  vmovaps [rsp+0x90], xmm9
000076c1d9dd4640  vmovaps [rsp+0xA0], xmm10
000076c1d9dd4649  vmovaps [rsp+0xB0], xmm11
000076c1d9dd4652  vmovaps [rsp+0xC0], xmm12
000076c1d9dd465b  vmovaps [rsp+0xD0], xmm13
000076c1d9dd4664  vmovaps [rsp+0xE0], xmm14
000076c1d9dd466d  sub rsp, 0x30
000076c1d9dd4671  movaps [rsp], xmm15
000076c1d9dd4676  movaps [rsp+0x10], xmm10
000076c1d9dd467c  movaps [rsp+0x20], xmm13
000076c1d9dd4682  lea rdi, [rsp]
000076c1d9dd4686  mov esi, 0x00
000076c1d9dd468b  mov rax, 0x5EA58B9E0530
000076c1d9dd4695  call rax
000076c1d9dd4697  movaps xmm15, [rsp]
000076c1d9dd469c  add rsp, 0x30
000076c1d9dd46a0  vmovaps xmm0, [rsp]
000076c1d9dd46a5  vmovaps xmm1, [rsp+0x10]
000076c1d9dd46ab  vmovaps xmm2, [rsp+0x20]
000076c1d9dd46b1  vmovaps xmm3, [rsp+0x30]
000076c1d9dd46b7  vmovaps xmm4, [rsp+0x40]
000076c1d9dd46bd  vmovaps xmm5, [rsp+0x50]
000076c1d9dd46c3  vmovaps xmm6, [rsp+0x60]
000076c1d9dd46c9  vmovaps xmm7, [rsp+0x70]
000076c1d9dd46cf  vmovaps xmm8, [rsp+0x80]
000076c1d9dd46d8  vmovaps xmm9, [rsp+0x90]
000076c1d9dd46e1  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd46ea  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd46f3  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd46fc  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd4705  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd470e  add rsp, 0xF0
000076c1d9dd4715  pop r11
000076c1d9dd4717  pop r10
000076c1d9dd4719  pop r9
000076c1d9dd471b  pop r8
000076c1d9dd471d  pop rsi
000076c1d9dd471e  pop rdi
000076c1d9dd471f  pop rdx
000076c1d9dd4720  pop rcx
000076c1d9dd4721  pop rax
000076c1d9dd4722  add rsp, 0x08
000076c1d9dd4726  jmp 0x000076C1D9DD013D
000076c1d9dd472b  sub rsp, 0x08
000076c1d9dd472f  push rax
000076c1d9dd4730  push rcx
000076c1d9dd4731  push rdx
000076c1d9dd4732  push rdi
000076c1d9dd4733  push rsi
000076c1d9dd4734  push r8
000076c1d9dd4736  push r9
000076c1d9dd4738  push r10
000076c1d9dd473a  push r11
000076c1d9dd473c  sub rsp, 0xF0
000076c1d9dd4743  vmovaps [rsp], xmm0
000076c1d9dd4748  vmovaps [rsp+0x10], xmm1
000076c1d9dd474e  vmovaps [rsp+0x20], xmm2
000076c1d9dd4754  vmovaps [rsp+0x30], xmm3
000076c1d9dd475a  vmovaps [rsp+0x40], xmm4
000076c1d9dd4760  vmovaps [rsp+0x50], xmm5
000076c1d9dd4766  vmovaps [rsp+0x60], xmm6
000076c1d9dd476c  vmovaps [rsp+0x70], xmm7
000076c1d9dd4772  vmovaps [rsp+0x80], xmm8
000076c1d9dd477b  vmovaps [rsp+0x90], xmm9
000076c1d9dd4784  vmovaps [rsp+0xA0], xmm11
000076c1d9dd478d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd4796  vmovaps [rsp+0xC0], xmm13
000076c1d9dd479f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd47a8  vmovaps [rsp+0xE0], xmm15
000076c1d9dd47b1  sub rsp, 0x30
000076c1d9dd47b5  movaps [rsp], xmm10
000076c1d9dd47ba  movaps [rsp+0x10], xmm7
000076c1d9dd47bf  movaps [rsp+0x20], xmm13
000076c1d9dd47c5  lea rdi, [rsp]
000076c1d9dd47c9  mov esi, 0x00
000076c1d9dd47ce  mov rax, 0x5EA58B9E0530
000076c1d9dd47d8  call rax
000076c1d9dd47da  movaps xmm10, [rsp]
000076c1d9dd47df  add rsp, 0x30
000076c1d9dd47e3  vmovaps xmm0, [rsp]
000076c1d9dd47e8  vmovaps xmm1, [rsp+0x10]
000076c1d9dd47ee  vmovaps xmm2, [rsp+0x20]
000076c1d9dd47f4  vmovaps xmm3, [rsp+0x30]
000076c1d9dd47fa  vmovaps xmm4, [rsp+0x40]
000076c1d9dd4800  vmovaps xmm5, [rsp+0x50]
000076c1d9dd4806  vmovaps xmm6, [rsp+0x60]
000076c1d9dd480c  vmovaps xmm7, [rsp+0x70]
000076c1d9dd4812  vmovaps xmm8, [rsp+0x80]
000076c1d9dd481b  vmovaps xmm9, [rsp+0x90]
000076c1d9dd4824  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd482d  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd4836  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd483f  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd4848  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4851  add rsp, 0xF0
000076c1d9dd4858  pop r11
000076c1d9dd485a  pop r10
000076c1d9dd485c  pop r9
000076c1d9dd485e  pop r8
000076c1d9dd4860  pop rsi
000076c1d9dd4861  pop rdi
000076c1d9dd4862  pop rdx
000076c1d9dd4863  pop rcx
000076c1d9dd4864  pop rax
000076c1d9dd4865  add rsp, 0x08
000076c1d9dd4869  jmp 0x000076C1D9DD0169
000076c1d9dd486e  sub rsp, 0x08
000076c1d9dd4872  push rax
000076c1d9dd4873  push rcx
000076c1d9dd4874  push rdx
000076c1d9dd4875  push rdi
000076c1d9dd4876  push rsi
000076c1d9dd4877  push r8
000076c1d9dd4879  push r9
000076c1d9dd487b  push r10
000076c1d9dd487d  push r11
000076c1d9dd487f  sub rsp, 0xF0
000076c1d9dd4886  vmovaps [rsp], xmm0
000076c1d9dd488b  vmovaps [rsp+0x10], xmm1
000076c1d9dd4891  vmovaps [rsp+0x20], xmm2
000076c1d9dd4897  vmovaps [rsp+0x30], xmm3
000076c1d9dd489d  vmovaps [rsp+0x40], xmm4
000076c1d9dd48a3  vmovaps [rsp+0x50], xmm5
000076c1d9dd48a9  vmovaps [rsp+0x60], xmm6
000076c1d9dd48af  vmovaps [rsp+0x70], xmm7
000076c1d9dd48b5  vmovaps [rsp+0x80], xmm8
000076c1d9dd48be  vmovaps [rsp+0x90], xmm9
000076c1d9dd48c7  vmovaps [rsp+0xA0], xmm10
000076c1d9dd48d0  vmovaps [rsp+0xB0], xmm11
000076c1d9dd48d9  vmovaps [rsp+0xC0], xmm12
000076c1d9dd48e2  vmovaps [rsp+0xD0], xmm14
000076c1d9dd48eb  vmovaps [rsp+0xE0], xmm15
000076c1d9dd48f4  sub rsp, 0x30
000076c1d9dd48f8  movaps [rsp], xmm13
000076c1d9dd48fd  movaps [rsp+0x10], xmm1
000076c1d9dd4902  movaps [rsp+0x20], xmm8
000076c1d9dd4908  lea rdi, [rsp]
000076c1d9dd490c  mov esi, 0x00
000076c1d9dd4911  mov rax, 0x5EA58B9E0530
000076c1d9dd491b  call rax
000076c1d9dd491d  movaps xmm13, [rsp]
000076c1d9dd4922  add rsp, 0x30
000076c1d9dd4926  vmovaps xmm0, [rsp]
000076c1d9dd492b  vmovaps xmm1, [rsp+0x10]
000076c1d9dd4931  vmovaps xmm2, [rsp+0x20]
000076c1d9dd4937  vmovaps xmm3, [rsp+0x30]
000076c1d9dd493d  vmovaps xmm4, [rsp+0x40]
000076c1d9dd4943  vmovaps xmm5, [rsp+0x50]
000076c1d9dd4949  vmovaps xmm6, [rsp+0x60]
000076c1d9dd494f  vmovaps xmm7, [rsp+0x70]
000076c1d9dd4955  vmovaps xmm8, [rsp+0x80]
000076c1d9dd495e  vmovaps xmm9, [rsp+0x90]
000076c1d9dd4967  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd4970  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd4979  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd4982  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd498b  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4994  add rsp, 0xF0
000076c1d9dd499b  pop r11
000076c1d9dd499d  pop r10
000076c1d9dd499f  pop r9
000076c1d9dd49a1  pop r8
000076c1d9dd49a3  pop rsi
000076c1d9dd49a4  pop rdi
000076c1d9dd49a5  pop rdx
000076c1d9dd49a6  pop rcx
000076c1d9dd49a7  pop rax
000076c1d9dd49a8  add rsp, 0x08
000076c1d9dd49ac  jmp 0x000076C1D9DD0183
000076c1d9dd49b1  call 0x000076C1D9BFF430
000076c1d9dd49b6  jmp 0x000076C1D9DD018D
000076c1d9dd49bb  sub rsp, 0x08
000076c1d9dd49bf  push rax
000076c1d9dd49c0  push rcx
000076c1d9dd49c1  push rdx
000076c1d9dd49c2  push rdi
000076c1d9dd49c3  push rsi
000076c1d9dd49c4  push r8
000076c1d9dd49c6  push r9
000076c1d9dd49c8  push r10
000076c1d9dd49ca  push r11
000076c1d9dd49cc  sub rsp, 0xF0
000076c1d9dd49d3  vmovaps [rsp], xmm0
000076c1d9dd49d8  vmovaps [rsp+0x10], xmm1
000076c1d9dd49de  vmovaps [rsp+0x20], xmm2
000076c1d9dd49e4  vmovaps [rsp+0x30], xmm3
000076c1d9dd49ea  vmovaps [rsp+0x40], xmm4
000076c1d9dd49f0  vmovaps [rsp+0x50], xmm5
000076c1d9dd49f6  vmovaps [rsp+0x60], xmm6
000076c1d9dd49fc  vmovaps [rsp+0x70], xmm7
000076c1d9dd4a02  vmovaps [rsp+0x80], xmm9
000076c1d9dd4a0b  vmovaps [rsp+0x90], xmm10
000076c1d9dd4a14  vmovaps [rsp+0xA0], xmm11
000076c1d9dd4a1d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd4a26  vmovaps [rsp+0xC0], xmm13
000076c1d9dd4a2f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd4a38  vmovaps [rsp+0xE0], xmm15
000076c1d9dd4a41  sub rsp, 0x30
000076c1d9dd4a45  movaps [rsp], xmm8
000076c1d9dd4a4a  movaps [rsp+0x10], xmm14
000076c1d9dd4a50  movaps [rsp+0x20], xmm9
000076c1d9dd4a56  lea rdi, [rsp]
000076c1d9dd4a5a  mov esi, 0x00
000076c1d9dd4a5f  mov rax, 0x5EA58B9E0530
000076c1d9dd4a69  call rax
000076c1d9dd4a6b  movaps xmm8, [rsp]
000076c1d9dd4a70  add rsp, 0x30
000076c1d9dd4a74  vmovaps xmm0, [rsp]
000076c1d9dd4a79  vmovaps xmm1, [rsp+0x10]
000076c1d9dd4a7f  vmovaps xmm2, [rsp+0x20]
000076c1d9dd4a85  vmovaps xmm3, [rsp+0x30]
000076c1d9dd4a8b  vmovaps xmm4, [rsp+0x40]
000076c1d9dd4a91  vmovaps xmm5, [rsp+0x50]
000076c1d9dd4a97  vmovaps xmm6, [rsp+0x60]
000076c1d9dd4a9d  vmovaps xmm7, [rsp+0x70]
000076c1d9dd4aa3  vmovaps xmm9, [rsp+0x80]
000076c1d9dd4aac  vmovaps xmm10, [rsp+0x90]
000076c1d9dd4ab5  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd4abe  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd4ac7  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd4ad0  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd4ad9  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4ae2  add rsp, 0xF0
000076c1d9dd4ae9  pop r11
000076c1d9dd4aeb  pop r10
000076c1d9dd4aed  pop r9
000076c1d9dd4aef  pop r8
000076c1d9dd4af1  pop rsi
000076c1d9dd4af2  pop rdi
000076c1d9dd4af3  pop rdx
000076c1d9dd4af4  pop rcx
000076c1d9dd4af5  pop rax
000076c1d9dd4af6  add rsp, 0x08
000076c1d9dd4afa  jmp 0x000076C1D9DD01AF
000076c1d9dd4aff  sub rsp, 0x08
000076c1d9dd4b03  push rax
000076c1d9dd4b04  push rcx
000076c1d9dd4b05  push rdx
000076c1d9dd4b06  push rdi
000076c1d9dd4b07  push rsi
000076c1d9dd4b08  push r8
000076c1d9dd4b0a  push r9
000076c1d9dd4b0c  push r10
000076c1d9dd4b0e  push r11
000076c1d9dd4b10  sub rsp, 0xF0
000076c1d9dd4b17  vmovaps [rsp], xmm0
000076c1d9dd4b1c  vmovaps [rsp+0x10], xmm1
000076c1d9dd4b22  vmovaps [rsp+0x20], xmm2
000076c1d9dd4b28  vmovaps [rsp+0x30], xmm3
000076c1d9dd4b2e  vmovaps [rsp+0x40], xmm4
000076c1d9dd4b34  vmovaps [rsp+0x50], xmm5
000076c1d9dd4b3a  vmovaps [rsp+0x60], xmm6
000076c1d9dd4b40  vmovaps [rsp+0x70], xmm7
000076c1d9dd4b46  vmovaps [rsp+0x80], xmm8
000076c1d9dd4b4f  vmovaps [rsp+0x90], xmm10
000076c1d9dd4b58  vmovaps [rsp+0xA0], xmm11
000076c1d9dd4b61  vmovaps [rsp+0xB0], xmm12
000076c1d9dd4b6a  vmovaps [rsp+0xC0], xmm13
000076c1d9dd4b73  vmovaps [rsp+0xD0], xmm14
000076c1d9dd4b7c  vmovaps [rsp+0xE0], xmm15
000076c1d9dd4b85  sub rsp, 0x30
000076c1d9dd4b89  movaps [rsp], xmm9
000076c1d9dd4b8e  movaps [rsp+0x10], xmm1
000076c1d9dd4b93  movaps [rsp+0x20], xmm14
000076c1d9dd4b99  lea rdi, [rsp]
000076c1d9dd4b9d  mov esi, 0x00
000076c1d9dd4ba2  mov rax, 0x5EA58B9E0530
000076c1d9dd4bac  call rax
000076c1d9dd4bae  movaps xmm9, [rsp]
000076c1d9dd4bb3  add rsp, 0x30
000076c1d9dd4bb7  vmovaps xmm0, [rsp]
000076c1d9dd4bbc  vmovaps xmm1, [rsp+0x10]
000076c1d9dd4bc2  vmovaps xmm2, [rsp+0x20]
000076c1d9dd4bc8  vmovaps xmm3, [rsp+0x30]
000076c1d9dd4bce  vmovaps xmm4, [rsp+0x40]
000076c1d9dd4bd4  vmovaps xmm5, [rsp+0x50]
000076c1d9dd4bda  vmovaps xmm6, [rsp+0x60]
000076c1d9dd4be0  vmovaps xmm7, [rsp+0x70]
000076c1d9dd4be6  vmovaps xmm8, [rsp+0x80]
000076c1d9dd4bef  vmovaps xmm10, [rsp+0x90]
000076c1d9dd4bf8  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd4c01  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd4c0a  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd4c13  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd4c1c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4c25  add rsp, 0xF0
000076c1d9dd4c2c  pop r11
000076c1d9dd4c2e  pop r10
000076c1d9dd4c30  pop r9
000076c1d9dd4c32  pop r8
000076c1d9dd4c34  pop rsi
000076c1d9dd4c35  pop rdi
000076c1d9dd4c36  pop rdx
000076c1d9dd4c37  pop rcx
000076c1d9dd4c38  pop rax
000076c1d9dd4c39  add rsp, 0x08
000076c1d9dd4c3d  jmp 0x000076C1D9DD01DD
000076c1d9dd4c42  sub rsp, 0x08
000076c1d9dd4c46  push rax
000076c1d9dd4c47  push rcx
000076c1d9dd4c48  push rdx
000076c1d9dd4c49  push rdi
000076c1d9dd4c4a  push rsi
000076c1d9dd4c4b  push r8
000076c1d9dd4c4d  push r9
000076c1d9dd4c4f  push r10
000076c1d9dd4c51  push r11
000076c1d9dd4c53  sub rsp, 0xF0
000076c1d9dd4c5a  vmovaps [rsp], xmm0
000076c1d9dd4c5f  vmovaps [rsp+0x10], xmm1
000076c1d9dd4c65  vmovaps [rsp+0x20], xmm2
000076c1d9dd4c6b  vmovaps [rsp+0x30], xmm3
000076c1d9dd4c71  vmovaps [rsp+0x40], xmm4
000076c1d9dd4c77  vmovaps [rsp+0x50], xmm5
000076c1d9dd4c7d  vmovaps [rsp+0x60], xmm6
000076c1d9dd4c83  vmovaps [rsp+0x70], xmm7
000076c1d9dd4c89  vmovaps [rsp+0x80], xmm8
000076c1d9dd4c92  vmovaps [rsp+0x90], xmm9
000076c1d9dd4c9b  vmovaps [rsp+0xA0], xmm10
000076c1d9dd4ca4  vmovaps [rsp+0xB0], xmm11
000076c1d9dd4cad  vmovaps [rsp+0xC0], xmm12
000076c1d9dd4cb6  vmovaps [rsp+0xD0], xmm13
000076c1d9dd4cbf  vmovaps [rsp+0xE0], xmm15
000076c1d9dd4cc8  sub rsp, 0x30
000076c1d9dd4ccc  movaps [rsp], xmm14
000076c1d9dd4cd1  movaps [rsp+0x10], xmm4
000076c1d9dd4cd6  movaps [rsp+0x20], xmm1
000076c1d9dd4cdb  lea rdi, [rsp]
000076c1d9dd4cdf  mov esi, 0x00
000076c1d9dd4ce4  mov rax, 0x5EA58B9E0530
000076c1d9dd4cee  call rax
000076c1d9dd4cf0  movaps xmm14, [rsp]
000076c1d9dd4cf5  add rsp, 0x30
000076c1d9dd4cf9  vmovaps xmm0, [rsp]
000076c1d9dd4cfe  vmovaps xmm1, [rsp+0x10]
000076c1d9dd4d04  vmovaps xmm2, [rsp+0x20]
000076c1d9dd4d0a  vmovaps xmm3, [rsp+0x30]
000076c1d9dd4d10  vmovaps xmm4, [rsp+0x40]
000076c1d9dd4d16  vmovaps xmm5, [rsp+0x50]
000076c1d9dd4d1c  vmovaps xmm6, [rsp+0x60]
000076c1d9dd4d22  vmovaps xmm7, [rsp+0x70]
000076c1d9dd4d28  vmovaps xmm8, [rsp+0x80]
000076c1d9dd4d31  vmovaps xmm9, [rsp+0x90]
000076c1d9dd4d3a  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd4d43  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd4d4c  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd4d55  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd4d5e  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4d67  add rsp, 0xF0
000076c1d9dd4d6e  pop r11
000076c1d9dd4d70  pop r10
000076c1d9dd4d72  pop r9
000076c1d9dd4d74  pop r8
000076c1d9dd4d76  pop rsi
000076c1d9dd4d77  pop rdi
000076c1d9dd4d78  pop rdx
000076c1d9dd4d79  pop rcx
000076c1d9dd4d7a  pop rax
000076c1d9dd4d7b  add rsp, 0x08
000076c1d9dd4d7f  jmp 0x000076C1D9DD0203
000076c1d9dd4d84  sub rsp, 0x08
000076c1d9dd4d88  push rax
000076c1d9dd4d89  push rcx
000076c1d9dd4d8a  push rdx
000076c1d9dd4d8b  push rdi
000076c1d9dd4d8c  push rsi
000076c1d9dd4d8d  push r8
000076c1d9dd4d8f  push r9
000076c1d9dd4d91  push r10
000076c1d9dd4d93  push r11
000076c1d9dd4d95  sub rsp, 0xF0
000076c1d9dd4d9c  vmovaps [rsp], xmm0
000076c1d9dd4da1  vmovaps [rsp+0x10], xmm2
000076c1d9dd4da7  vmovaps [rsp+0x20], xmm3
000076c1d9dd4dad  vmovaps [rsp+0x30], xmm4
000076c1d9dd4db3  vmovaps [rsp+0x40], xmm5
000076c1d9dd4db9  vmovaps [rsp+0x50], xmm6
000076c1d9dd4dbf  vmovaps [rsp+0x60], xmm7
000076c1d9dd4dc5  vmovaps [rsp+0x70], xmm8
000076c1d9dd4dcb  vmovaps [rsp+0x80], xmm9
000076c1d9dd4dd4  vmovaps [rsp+0x90], xmm10
000076c1d9dd4ddd  vmovaps [rsp+0xA0], xmm11
000076c1d9dd4de6  vmovaps [rsp+0xB0], xmm12
000076c1d9dd4def  vmovaps [rsp+0xC0], xmm13
000076c1d9dd4df8  vmovaps [rsp+0xD0], xmm14
000076c1d9dd4e01  vmovaps [rsp+0xE0], xmm15
000076c1d9dd4e0a  sub rsp, 0x30
000076c1d9dd4e0e  movaps [rsp], xmm1
000076c1d9dd4e12  movaps [rsp+0x10], xmm12
000076c1d9dd4e18  movaps [rsp+0x20], xmm11
000076c1d9dd4e1e  lea rdi, [rsp]
000076c1d9dd4e22  mov esi, 0x00
000076c1d9dd4e27  mov rax, 0x5EA58B9E0530
000076c1d9dd4e31  call rax
000076c1d9dd4e33  movaps xmm1, [rsp]
000076c1d9dd4e37  add rsp, 0x30
000076c1d9dd4e3b  vmovaps xmm0, [rsp]
000076c1d9dd4e40  vmovaps xmm2, [rsp+0x10]
000076c1d9dd4e46  vmovaps xmm3, [rsp+0x20]
000076c1d9dd4e4c  vmovaps xmm4, [rsp+0x30]
000076c1d9dd4e52  vmovaps xmm5, [rsp+0x40]
000076c1d9dd4e58  vmovaps xmm6, [rsp+0x50]
000076c1d9dd4e5e  vmovaps xmm7, [rsp+0x60]
000076c1d9dd4e64  vmovaps xmm8, [rsp+0x70]
000076c1d9dd4e6a  vmovaps xmm9, [rsp+0x80]
000076c1d9dd4e73  vmovaps xmm10, [rsp+0x90]
000076c1d9dd4e7c  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd4e85  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd4e8e  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd4e97  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd4ea0  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4ea9  add rsp, 0xF0
000076c1d9dd4eb0  pop r11
000076c1d9dd4eb2  pop r10
000076c1d9dd4eb4  pop r9
000076c1d9dd4eb6  pop r8
000076c1d9dd4eb8  pop rsi
000076c1d9dd4eb9  pop rdi
000076c1d9dd4eba  pop rdx
000076c1d9dd4ebb  pop rcx
000076c1d9dd4ebc  pop rax
000076c1d9dd4ebd  add rsp, 0x08
000076c1d9dd4ec1  jmp 0x000076C1D9DD0224
000076c1d9dd4ec6  call 0x000076C1D9CE20A0
000076c1d9dd4ecb  jmp 0x000076C1D9DD0232
000076c1d9dd4ed0  call 0x000076C1D9C09D70
000076c1d9dd4ed5  jmp 0x000076C1D9DD023C
000076c1d9dd4eda  sub rsp, 0x08
000076c1d9dd4ede  push rax
000076c1d9dd4edf  push rcx
000076c1d9dd4ee0  push rdx
000076c1d9dd4ee1  push rdi
000076c1d9dd4ee2  push rsi
000076c1d9dd4ee3  push r8
000076c1d9dd4ee5  push r9
000076c1d9dd4ee7  push r10
000076c1d9dd4ee9  push r11
000076c1d9dd4eeb  sub rsp, 0xF0
000076c1d9dd4ef2  vmovaps [rsp], xmm0
000076c1d9dd4ef7  vmovaps [rsp+0x10], xmm1
000076c1d9dd4efd  vmovaps [rsp+0x20], xmm2
000076c1d9dd4f03  vmovaps [rsp+0x30], xmm3
000076c1d9dd4f09  vmovaps [rsp+0x40], xmm4
000076c1d9dd4f0f  vmovaps [rsp+0x50], xmm5
000076c1d9dd4f15  vmovaps [rsp+0x60], xmm6
000076c1d9dd4f1b  vmovaps [rsp+0x70], xmm8
000076c1d9dd4f21  vmovaps [rsp+0x80], xmm9
000076c1d9dd4f2a  vmovaps [rsp+0x90], xmm10
000076c1d9dd4f33  vmovaps [rsp+0xA0], xmm11
000076c1d9dd4f3c  vmovaps [rsp+0xB0], xmm12
000076c1d9dd4f45  vmovaps [rsp+0xC0], xmm13
000076c1d9dd4f4e  vmovaps [rsp+0xD0], xmm14
000076c1d9dd4f57  vmovaps [rsp+0xE0], xmm15
000076c1d9dd4f60  sub rsp, 0x30
000076c1d9dd4f64  movaps [rsp], xmm7
000076c1d9dd4f68  movaps [rsp+0x10], xmm15
000076c1d9dd4f6e  movaps [rsp+0x20], xmm10
000076c1d9dd4f74  lea rdi, [rsp]
000076c1d9dd4f78  mov esi, 0x00
000076c1d9dd4f7d  mov rax, 0x5EA58B9E0530
000076c1d9dd4f87  call rax
000076c1d9dd4f89  movaps xmm7, [rsp]
000076c1d9dd4f8d  add rsp, 0x30
000076c1d9dd4f91  vmovaps xmm0, [rsp]
000076c1d9dd4f96  vmovaps xmm1, [rsp+0x10]
000076c1d9dd4f9c  vmovaps xmm2, [rsp+0x20]
000076c1d9dd4fa2  vmovaps xmm3, [rsp+0x30]
000076c1d9dd4fa8  vmovaps xmm4, [rsp+0x40]
000076c1d9dd4fae  vmovaps xmm5, [rsp+0x50]
000076c1d9dd4fb4  vmovaps xmm6, [rsp+0x60]
000076c1d9dd4fba  vmovaps xmm8, [rsp+0x70]
000076c1d9dd4fc0  vmovaps xmm9, [rsp+0x80]
000076c1d9dd4fc9  vmovaps xmm10, [rsp+0x90]
000076c1d9dd4fd2  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd4fdb  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd4fe4  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd4fed  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd4ff6  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd4fff  add rsp, 0xF0
000076c1d9dd5006  pop r11
000076c1d9dd5008  pop r10
000076c1d9dd500a  pop r9
000076c1d9dd500c  pop r8
000076c1d9dd500e  pop rsi
000076c1d9dd500f  pop rdi
000076c1d9dd5010  pop rdx
000076c1d9dd5011  pop rcx
000076c1d9dd5012  pop rax
000076c1d9dd5013  add rsp, 0x08
000076c1d9dd5017  jmp 0x000076C1D9DD025D
000076c1d9dd501c  sub rsp, 0x08
000076c1d9dd5020  push rax
000076c1d9dd5021  push rcx
000076c1d9dd5022  push rdx
000076c1d9dd5023  push rdi
000076c1d9dd5024  push rsi
000076c1d9dd5025  push r8
000076c1d9dd5027  push r9
000076c1d9dd5029  push r10
000076c1d9dd502b  push r11
000076c1d9dd502d  sub rsp, 0xF0
000076c1d9dd5034  vmovaps [rsp], xmm0
000076c1d9dd5039  vmovaps [rsp+0x10], xmm1
000076c1d9dd503f  vmovaps [rsp+0x20], xmm2
000076c1d9dd5045  vmovaps [rsp+0x30], xmm3
000076c1d9dd504b  vmovaps [rsp+0x40], xmm4
000076c1d9dd5051  vmovaps [rsp+0x50], xmm5
000076c1d9dd5057  vmovaps [rsp+0x60], xmm6
000076c1d9dd505d  vmovaps [rsp+0x70], xmm7
000076c1d9dd5063  vmovaps [rsp+0x80], xmm8
000076c1d9dd506c  vmovaps [rsp+0x90], xmm9
000076c1d9dd5075  vmovaps [rsp+0xA0], xmm11
000076c1d9dd507e  vmovaps [rsp+0xB0], xmm12
000076c1d9dd5087  vmovaps [rsp+0xC0], xmm13
000076c1d9dd5090  vmovaps [rsp+0xD0], xmm14
000076c1d9dd5099  vmovaps [rsp+0xE0], xmm15
000076c1d9dd50a2  sub rsp, 0x30
000076c1d9dd50a6  movaps [rsp], xmm10
000076c1d9dd50ab  movaps [rsp+0x10], xmm11
000076c1d9dd50b1  movaps [rsp+0x20], xmm15
000076c1d9dd50b7  lea rdi, [rsp]
000076c1d9dd50bb  mov esi, 0x00
000076c1d9dd50c0  mov rax, 0x5EA58B9E0530
000076c1d9dd50ca  call rax
000076c1d9dd50cc  movaps xmm10, [rsp]
000076c1d9dd50d1  add rsp, 0x30
000076c1d9dd50d5  vmovaps xmm0, [rsp]
000076c1d9dd50da  vmovaps xmm1, [rsp+0x10]
000076c1d9dd50e0  vmovaps xmm2, [rsp+0x20]
000076c1d9dd50e6  vmovaps xmm3, [rsp+0x30]
000076c1d9dd50ec  vmovaps xmm4, [rsp+0x40]
000076c1d9dd50f2  vmovaps xmm5, [rsp+0x50]
000076c1d9dd50f8  vmovaps xmm6, [rsp+0x60]
000076c1d9dd50fe  vmovaps xmm7, [rsp+0x70]
000076c1d9dd5104  vmovaps xmm8, [rsp+0x80]
000076c1d9dd510d  vmovaps xmm9, [rsp+0x90]
000076c1d9dd5116  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd511f  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd5128  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd5131  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd513a  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd5143  add rsp, 0xF0
000076c1d9dd514a  pop r11
000076c1d9dd514c  pop r10
000076c1d9dd514e  pop r9
000076c1d9dd5150  pop r8
000076c1d9dd5152  pop rsi
000076c1d9dd5153  pop rdi
000076c1d9dd5154  pop rdx
000076c1d9dd5155  pop rcx
000076c1d9dd5156  pop rax
000076c1d9dd5157  add rsp, 0x08
000076c1d9dd515b  jmp 0x000076C1D9DD028B
000076c1d9dd5160  sub rsp, 0x08
000076c1d9dd5164  push rax
000076c1d9dd5165  push rcx
000076c1d9dd5166  push rdx
000076c1d9dd5167  push rdi
000076c1d9dd5168  push rsi
000076c1d9dd5169  push r8
000076c1d9dd516b  push r9
000076c1d9dd516d  push r10
000076c1d9dd516f  push r11
000076c1d9dd5171  sub rsp, 0xF0
000076c1d9dd5178  vmovaps [rsp], xmm0
000076c1d9dd517d  vmovaps [rsp+0x10], xmm1
000076c1d9dd5183  vmovaps [rsp+0x20], xmm2
000076c1d9dd5189  vmovaps [rsp+0x30], xmm3
000076c1d9dd518f  vmovaps [rsp+0x40], xmm4
000076c1d9dd5195  vmovaps [rsp+0x50], xmm5
000076c1d9dd519b  vmovaps [rsp+0x60], xmm6
000076c1d9dd51a1  vmovaps [rsp+0x70], xmm7
000076c1d9dd51a7  vmovaps [rsp+0x80], xmm8
000076c1d9dd51b0  vmovaps [rsp+0x90], xmm9
000076c1d9dd51b9  vmovaps [rsp+0xA0], xmm10
000076c1d9dd51c2  vmovaps [rsp+0xB0], xmm12
000076c1d9dd51cb  vmovaps [rsp+0xC0], xmm13
000076c1d9dd51d4  vmovaps [rsp+0xD0], xmm14
000076c1d9dd51dd  vmovaps [rsp+0xE0], xmm15
000076c1d9dd51e6  sub rsp, 0x30
000076c1d9dd51ea  movaps [rsp], xmm11
000076c1d9dd51ef  movaps [rsp+0x10], xmm12
000076c1d9dd51f5  movaps [rsp+0x20], xmm15
000076c1d9dd51fb  lea rdi, [rsp]
000076c1d9dd51ff  mov esi, 0x00
000076c1d9dd5204  mov rax, 0x5EA58B9E0530
000076c1d9dd520e  call rax
000076c1d9dd5210  movaps xmm11, [rsp]
000076c1d9dd5215  add rsp, 0x30
000076c1d9dd5219  vmovaps xmm0, [rsp]
000076c1d9dd521e  vmovaps xmm1, [rsp+0x10]
000076c1d9dd5224  vmovaps xmm2, [rsp+0x20]
000076c1d9dd522a  vmovaps xmm3, [rsp+0x30]
000076c1d9dd5230  vmovaps xmm4, [rsp+0x40]
000076c1d9dd5236  vmovaps xmm5, [rsp+0x50]
000076c1d9dd523c  vmovaps xmm6, [rsp+0x60]
000076c1d9dd5242  vmovaps xmm7, [rsp+0x70]
000076c1d9dd5248  vmovaps xmm8, [rsp+0x80]
000076c1d9dd5251  vmovaps xmm9, [rsp+0x90]
000076c1d9dd525a  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd5263  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd526c  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd5275  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd527e  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd5287  add rsp, 0xF0
000076c1d9dd528e  pop r11
000076c1d9dd5290  pop r10
000076c1d9dd5292  pop r9
000076c1d9dd5294  pop r8
000076c1d9dd5296  pop rsi
000076c1d9dd5297  pop rdi
000076c1d9dd5298  pop rdx
000076c1d9dd5299  pop rcx
000076c1d9dd529a  pop rax
000076c1d9dd529b  add rsp, 0x08
000076c1d9dd529f  jmp 0x000076C1D9DD02B9
000076c1d9dd52a4  sub rsp, 0x08
000076c1d9dd52a8  push rax
000076c1d9dd52a9  push rcx
000076c1d9dd52aa  push rdx
000076c1d9dd52ab  push rdi
000076c1d9dd52ac  push rsi
000076c1d9dd52ad  push r8
000076c1d9dd52af  push r9
000076c1d9dd52b1  push r10
000076c1d9dd52b3  push r11
000076c1d9dd52b5  sub rsp, 0xF0
000076c1d9dd52bc  vmovaps [rsp], xmm0
000076c1d9dd52c1  vmovaps [rsp+0x10], xmm1
000076c1d9dd52c7  vmovaps [rsp+0x20], xmm2
000076c1d9dd52cd  vmovaps [rsp+0x30], xmm3
000076c1d9dd52d3  vmovaps [rsp+0x40], xmm4
000076c1d9dd52d9  vmovaps [rsp+0x50], xmm5
000076c1d9dd52df  vmovaps [rsp+0x60], xmm6
000076c1d9dd52e5  vmovaps [rsp+0x70], xmm7
000076c1d9dd52eb  vmovaps [rsp+0x80], xmm8
000076c1d9dd52f4  vmovaps [rsp+0x90], xmm9
000076c1d9dd52fd  vmovaps [rsp+0xA0], xmm10
000076c1d9dd5306  vmovaps [rsp+0xB0], xmm11
000076c1d9dd530f  vmovaps [rsp+0xC0], xmm12
000076c1d9dd5318  vmovaps [rsp+0xD0], xmm13
000076c1d9dd5321  vmovaps [rsp+0xE0], xmm14
000076c1d9dd532a  sub rsp, 0x30
000076c1d9dd532e  movaps [rsp], xmm15
000076c1d9dd5333  movaps [rsp+0x10], xmm13
000076c1d9dd5339  movaps [rsp+0x20], xmm9
000076c1d9dd533f  lea rdi, [rsp]
000076c1d9dd5343  mov esi, 0x00
000076c1d9dd5348  mov rax, 0x5EA58B9E0530
000076c1d9dd5352  call rax
000076c1d9dd5354  movaps xmm15, [rsp]
000076c1d9dd5359  add rsp, 0x30
000076c1d9dd535d  vmovaps xmm0, [rsp]
000076c1d9dd5362  vmovaps xmm1, [rsp+0x10]
000076c1d9dd5368  vmovaps xmm2, [rsp+0x20]
000076c1d9dd536e  vmovaps xmm3, [rsp+0x30]
000076c1d9dd5374  vmovaps xmm4, [rsp+0x40]
000076c1d9dd537a  vmovaps xmm5, [rsp+0x50]
000076c1d9dd5380  vmovaps xmm6, [rsp+0x60]
000076c1d9dd5386  vmovaps xmm7, [rsp+0x70]
000076c1d9dd538c  vmovaps xmm8, [rsp+0x80]
000076c1d9dd5395  vmovaps xmm9, [rsp+0x90]
000076c1d9dd539e  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd53a7  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd53b0  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd53b9  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd53c2  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd53cb  add rsp, 0xF0
000076c1d9dd53d2  pop r11
000076c1d9dd53d4  pop r10
000076c1d9dd53d6  pop r9
000076c1d9dd53d8  pop r8
000076c1d9dd53da  pop rsi
000076c1d9dd53db  pop rdi
000076c1d9dd53dc  pop rdx
000076c1d9dd53dd  pop rcx
000076c1d9dd53de  pop rax
000076c1d9dd53df  add rsp, 0x08
000076c1d9dd53e3  jmp 0x000076C1D9DD02D4
000076c1d9dd53e8  sub rsp, 0x08
000076c1d9dd53ec  push rax
000076c1d9dd53ed  push rcx
000076c1d9dd53ee  push rdx
000076c1d9dd53ef  push rdi
000076c1d9dd53f0  push rsi
000076c1d9dd53f1  push r8
000076c1d9dd53f3  push r9
000076c1d9dd53f5  push r10
000076c1d9dd53f7  push r11
000076c1d9dd53f9  sub rsp, 0xF0
000076c1d9dd5400  vmovaps [rsp], xmm0
000076c1d9dd5405  vmovaps [rsp+0x10], xmm1
000076c1d9dd540b  vmovaps [rsp+0x20], xmm2
000076c1d9dd5411  vmovaps [rsp+0x30], xmm3
000076c1d9dd5417  vmovaps [rsp+0x40], xmm4
000076c1d9dd541d  vmovaps [rsp+0x50], xmm5
000076c1d9dd5423  vmovaps [rsp+0x60], xmm6
000076c1d9dd5429  vmovaps [rsp+0x70], xmm7
000076c1d9dd542f  vmovaps [rsp+0x80], xmm8
000076c1d9dd5438  vmovaps [rsp+0x90], xmm9
000076c1d9dd5441  vmovaps [rsp+0xA0], xmm10
000076c1d9dd544a  vmovaps [rsp+0xB0], xmm11
000076c1d9dd5453  vmovaps [rsp+0xC0], xmm12
000076c1d9dd545c  vmovaps [rsp+0xD0], xmm14
000076c1d9dd5465  vmovaps [rsp+0xE0], xmm15
000076c1d9dd546e  sub rsp, 0x30
000076c1d9dd5472  movaps [rsp], xmm13
000076c1d9dd5477  movaps [rsp+0x10], xmm8
000076c1d9dd547d  movaps [rsp+0x20], xmm14
000076c1d9dd5483  lea rdi, [rsp]
000076c1d9dd5487  mov esi, 0x00
000076c1d9dd548c  mov rax, 0x5EA58B9E0530
000076c1d9dd5496  call rax
000076c1d9dd5498  movaps xmm13, [rsp]
000076c1d9dd549d  add rsp, 0x30
000076c1d9dd54a1  vmovaps xmm0, [rsp]
000076c1d9dd54a6  vmovaps xmm1, [rsp+0x10]
000076c1d9dd54ac  vmovaps xmm2, [rsp+0x20]
000076c1d9dd54b2  vmovaps xmm3, [rsp+0x30]
000076c1d9dd54b8  vmovaps xmm4, [rsp+0x40]
000076c1d9dd54be  vmovaps xmm5, [rsp+0x50]
000076c1d9dd54c4  vmovaps xmm6, [rsp+0x60]
000076c1d9dd54ca  vmovaps xmm7, [rsp+0x70]
000076c1d9dd54d0  vmovaps xmm8, [rsp+0x80]
000076c1d9dd54d9  vmovaps xmm9, [rsp+0x90]
000076c1d9dd54e2  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd54eb  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd54f4  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd54fd  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd5506  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd550f  add rsp, 0xF0
000076c1d9dd5516  pop r11
000076c1d9dd5518  pop r10
000076c1d9dd551a  pop r9
000076c1d9dd551c  pop r8
000076c1d9dd551e  pop rsi
000076c1d9dd551f  pop rdi
000076c1d9dd5520  pop rdx
000076c1d9dd5521  pop rcx
000076c1d9dd5522  pop rax
000076c1d9dd5523  add rsp, 0x08
000076c1d9dd5527  jmp 0x000076C1D9DD02F7
000076c1d9dd552c  sub rsp, 0x08
000076c1d9dd5530  push rax
000076c1d9dd5531  push rcx
000076c1d9dd5532  push rdx
000076c1d9dd5533  push rdi
000076c1d9dd5534  push rsi
000076c1d9dd5535  push r8
000076c1d9dd5537  push r9
000076c1d9dd5539  push r10
000076c1d9dd553b  push r11
000076c1d9dd553d  sub rsp, 0xF0
000076c1d9dd5544  vmovaps [rsp], xmm0
000076c1d9dd5549  vmovaps [rsp+0x10], xmm1
000076c1d9dd554f  vmovaps [rsp+0x20], xmm2
000076c1d9dd5555  vmovaps [rsp+0x30], xmm3
000076c1d9dd555b  vmovaps [rsp+0x40], xmm4
000076c1d9dd5561  vmovaps [rsp+0x50], xmm5
000076c1d9dd5567  vmovaps [rsp+0x60], xmm6
000076c1d9dd556d  vmovaps [rsp+0x70], xmm7
000076c1d9dd5573  vmovaps [rsp+0x80], xmm8
000076c1d9dd557c  vmovaps [rsp+0x90], xmm9
000076c1d9dd5585  vmovaps [rsp+0xA0], xmm10
000076c1d9dd558e  vmovaps [rsp+0xB0], xmm11
000076c1d9dd5597  vmovaps [rsp+0xC0], xmm12
000076c1d9dd55a0  vmovaps [rsp+0xD0], xmm13
000076c1d9dd55a9  vmovaps [rsp+0xE0], xmm15
000076c1d9dd55b2  sub rsp, 0x30
000076c1d9dd55b6  movaps [rsp], xmm14
000076c1d9dd55bb  movaps [rsp+0x10], xmm1
000076c1d9dd55c0  movaps [rsp+0x20], xmm10
000076c1d9dd55c6  lea rdi, [rsp]
000076c1d9dd55ca  mov esi, 0x00
000076c1d9dd55cf  mov rax, 0x5EA58B9E0530
000076c1d9dd55d9  call rax
000076c1d9dd55db  movaps xmm14, [rsp]
000076c1d9dd55e0  add rsp, 0x30
000076c1d9dd55e4  vmovaps xmm0, [rsp]
000076c1d9dd55e9  vmovaps xmm1, [rsp+0x10]
000076c1d9dd55ef  vmovaps xmm2, [rsp+0x20]
000076c1d9dd55f5  vmovaps xmm3, [rsp+0x30]
000076c1d9dd55fb  vmovaps xmm4, [rsp+0x40]
000076c1d9dd5601  vmovaps xmm5, [rsp+0x50]
000076c1d9dd5607  vmovaps xmm6, [rsp+0x60]
000076c1d9dd560d  vmovaps xmm7, [rsp+0x70]
000076c1d9dd5613  vmovaps xmm8, [rsp+0x80]
000076c1d9dd561c  vmovaps xmm9, [rsp+0x90]
000076c1d9dd5625  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd562e  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd5637  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd5640  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd5649  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd5652  add rsp, 0xF0
000076c1d9dd5659  pop r11
000076c1d9dd565b  pop r10
000076c1d9dd565d  pop r9
000076c1d9dd565f  pop r8
000076c1d9dd5661  pop rsi
000076c1d9dd5662  pop rdi
000076c1d9dd5663  pop rdx
000076c1d9dd5664  pop rcx
000076c1d9dd5665  pop rax
000076c1d9dd5666  add rsp, 0x08
000076c1d9dd566a  jmp 0x000076C1D9DD031A
000076c1d9dd566f  sub rsp, 0x08
000076c1d9dd5673  push rax
000076c1d9dd5674  push rcx
000076c1d9dd5675  push rdx
000076c1d9dd5676  push rdi
000076c1d9dd5677  push rsi
000076c1d9dd5678  push r8
000076c1d9dd567a  push r9
000076c1d9dd567c  push r10
000076c1d9dd567e  push r11
000076c1d9dd5680  sub rsp, 0xF0
000076c1d9dd5687  vmovaps [rsp], xmm0
000076c1d9dd568c  vmovaps [rsp+0x10], xmm2
000076c1d9dd5692  vmovaps [rsp+0x20], xmm3
000076c1d9dd5698  vmovaps [rsp+0x30], xmm4
000076c1d9dd569e  vmovaps [rsp+0x40], xmm5
000076c1d9dd56a4  vmovaps [rsp+0x50], xmm6
000076c1d9dd56aa  vmovaps [rsp+0x60], xmm7
000076c1d9dd56b0  vmovaps [rsp+0x70], xmm8
000076c1d9dd56b6  vmovaps [rsp+0x80], xmm9
000076c1d9dd56bf  vmovaps [rsp+0x90], xmm10
000076c1d9dd56c8  vmovaps [rsp+0xA0], xmm11
000076c1d9dd56d1  vmovaps [rsp+0xB0], xmm12
000076c1d9dd56da  vmovaps [rsp+0xC0], xmm13
000076c1d9dd56e3  vmovaps [rsp+0xD0], xmm14
000076c1d9dd56ec  vmovaps [rsp+0xE0], xmm15
000076c1d9dd56f5  sub rsp, 0x30
000076c1d9dd56f9  movaps [rsp], xmm1
000076c1d9dd56fd  movaps [rsp+0x10], xmm7
000076c1d9dd5702  movaps [rsp+0x20], xmm11
000076c1d9dd5708  lea rdi, [rsp]
000076c1d9dd570c  mov esi, 0x00
000076c1d9dd5711  mov rax, 0x5EA58B9E0530
000076c1d9dd571b  call rax
000076c1d9dd571d  movaps xmm1, [rsp]
000076c1d9dd5721  add rsp, 0x30
000076c1d9dd5725  vmovaps xmm0, [rsp]
000076c1d9dd572a  vmovaps xmm2, [rsp+0x10]
000076c1d9dd5730  vmovaps xmm3, [rsp+0x20]
000076c1d9dd5736  vmovaps xmm4, [rsp+0x30]
000076c1d9dd573c  vmovaps xmm5, [rsp+0x40]
000076c1d9dd5742  vmovaps xmm6, [rsp+0x50]
000076c1d9dd5748  vmovaps xmm7, [rsp+0x60]
000076c1d9dd574e  vmovaps xmm8, [rsp+0x70]
000076c1d9dd5754  vmovaps xmm9, [rsp+0x80]
000076c1d9dd575d  vmovaps xmm10, [rsp+0x90]
000076c1d9dd5766  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd576f  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd5778  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd5781  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd578a  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd5793  add rsp, 0xF0
000076c1d9dd579a  pop r11
000076c1d9dd579c  pop r10
000076c1d9dd579e  pop r9
000076c1d9dd57a0  pop r8
000076c1d9dd57a2  pop rsi
000076c1d9dd57a3  pop rdi
000076c1d9dd57a4  pop rdx
000076c1d9dd57a5  pop rcx
000076c1d9dd57a6  pop rax
000076c1d9dd57a7  add rsp, 0x08
000076c1d9dd57ab  jmp 0x000076C1D9DD033B
000076c1d9dd57b0  call 0x000076C1D9C0E880
000076c1d9dd57b5  jmp 0x000076C1D9DD034E
000076c1d9dd57ba  call 0x000076C1D9C0C380
000076c1d9dd57bf  jmp 0x000076C1D9DD0359
000076c1d9dd57c4  call 0x000076C1D9C0D600
000076c1d9dd57c9  jmp 0x000076C1D9DD0364
000076c1d9dd57ce  call 0x000076C1D9BFF540
000076c1d9dd57d3  jmp 0x000076C1D9DD036F
000076c1d9dd57d8  int3
000076c1d9dd57d9  nop [rax], eax
000076c1d9dd57e0  mov rax, [r15+0x40]
000076c1d9dd57e4  mov r14, [r15+0x58]
000076c1d9dd57e8  lea r12, [rax+r14*1]
000076c1d9dd57ec  movaps xmm1, [r15+0x1D0]
000076c1d9dd57f4  vmovaps [rsp+0x10], xmm1
000076c1d9dd57fa  vmovaps xmm15, [rsp+0x10]
000076c1d9dd5800  por xmm1, xmm15
000076c1d9dd5805  movaps xmm14, [r15+0x1A0]
000076c1d9dd580d  vmovaps [rsp+0x10], xmm14
000076c1d9dd5813  vmovaps xmm13, [rsp+0x10]
000076c1d9dd5819  por xmm14, xmm13
000076c1d9dd581e  lea rax, [r12+0x30]
000076c1d9dd5823  mov r11, [r13+rax*1]
000076c1d9dd5828  lea rax, [r12+0x38]
000076c1d9dd582d  mov r10, [r13+rax*1]
000076c1d9dd5832  movq xmm13, r11
000076c1d9dd5837  movq xmm12, r10
000076c1d9dd583c  movq xmm13, xmm13
000076c1d9dd5841  vmovaps [rsp+0x10], xmm13
000076c1d9dd5847  movq xmm13, xmm13
000076c1d9dd584c  movaps [r15+0x130], xmm13
000076c1d9dd5854  movq xmm12, xmm12
000076c1d9dd5859  vmovaps [rsp+0x20], xmm12
000076c1d9dd585f  movq xmm12, xmm12
000076c1d9dd5864  movaps [r15+0x280], xmm12
000076c1d9dd586c  movaps xmm13, [r15+0x270]
000076c1d9dd5874  vmovaps [rsp+0x30], xmm13
000076c1d9dd587a  vmovaps xmm12, [rsp+0x30]
000076c1d9dd5880  por xmm13, xmm12
000076c1d9dd5885  lea rax, [r12+0x20]
000076c1d9dd588a  mov r11, [r13+rax*1]
000076c1d9dd588f  lea rax, [r12+0x28]
000076c1d9dd5894  mov r10, [r13+rax*1]
000076c1d9dd5899  movq xmm12, r11
000076c1d9dd589e  movq xmm11, r10
000076c1d9dd58a3  movq xmm12, xmm12
000076c1d9dd58a8  vmovaps [rsp+0x30], xmm12
000076c1d9dd58ae  movq xmm12, xmm12
000076c1d9dd58b3  movaps [r15+0x150], xmm12
000076c1d9dd58bb  movq xmm11, xmm11
000076c1d9dd58c0  vmovaps [rsp+0x40], xmm11
000076c1d9dd58c6  movq xmm11, xmm11
000076c1d9dd58cb  movaps [r15+0x140], xmm11
000076c1d9dd58d3  lea rax, [r12+0x10]
000076c1d9dd58d8  mov r11, [r13+rax*1]
000076c1d9dd58dd  lea rax, [r12+0x18]
000076c1d9dd58e2  mov r10, [r13+rax*1]
000076c1d9dd58e7  movq xmm12, r11
000076c1d9dd58ec  movq xmm11, r10
000076c1d9dd58f1  movq xmm12, xmm12
000076c1d9dd58f6  vmovaps [rsp+0x50], xmm12
000076c1d9dd58fc  movq xmm12, xmm12
000076c1d9dd5901  movaps [r15+0x170], xmm12
000076c1d9dd5909  movq xmm11, xmm11
000076c1d9dd590e  vmovaps [rsp+0x60], xmm11
000076c1d9dd5914  movq xmm11, xmm11
000076c1d9dd5919  movaps [r15+0x160], xmm11
000076c1d9dd5921  mov rax, [r13+r12*1]
000076c1d9dd5926  vmovq xmm12, rax
000076c1d9dd592b  vpbroadcastq xmm12, xmm12
000076c1d9dd5930  lea rax, [r12+0x08]
000076c1d9dd5935  mov r12, [r13+rax*1]
000076c1d9dd593a  movq xmm11, r12
000076c1d9dd593f  movaps [r15+0x230], xmm11
000076c1d9dd5947  mov rax, [r15+0xF8]
000076c1d9dd594e  lea r12, [rax+0x50]
000076c1d9dd5952  movups xmm11, [r13+r12*1]
000076c1d9dd5958  lea r12, [rax+0x60]
000076c1d9dd595c  movups xmm10, [r13+r12*1]
000076c1d9dd5962  lea r12, [rax+0x30]
000076c1d9dd5966  movups xmm9, [r13+r12*1]
000076c1d9dd596c  mov r12, [r15+0x50]
000076c1d9dd5970  lea r11, [r12+r14*1]
000076c1d9dd5974  mov [r15+0x60], r11
000076c1d9dd5978  lea r12, [r14+0x40]
000076c1d9dd597c  mov [r15+0x58], r12
000076c1d9dd5980  movaps xmm8, xmm12
000076c1d9dd5984  mulpd xmm8, xmm15
000076c1d9dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000076c1d9dd598f  ptest xmm7, xmm7
000076c1d9dd5994  jnz 0x000076C1D9DD67B7
000076c1d9dd599a  movq xmm15, qword ptr [r15+0x230]
000076c1d9dd59a3  vmovaps [rsp+0x70], xmm15
000076c1d9dd59a9  vpermilpd xmm15, xmm15, 0x00
000076c1d9dd59af  movaps xmm7, xmm9
000076c1d9dd59b3  mulpd xmm7, xmm15
000076c1d9dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000076c1d9dd59bd  ptest xmm6, xmm6
000076c1d9dd59c2  jnz 0x000076C1D9DD68FB
000076c1d9dd59c8  vxorps xmm15, xmm15, xmm15
000076c1d9dd59cd  vpbroadcastq xmm15, xmm15
000076c1d9dd59d2  movaps xmm9, xmm12
000076c1d9dd59d6  mulpd xmm9, xmm10
000076c1d9dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000076c1d9dd59e1  ptest xmm6, xmm6
000076c1d9dd59e6  jnz 0x000076C1D9DD6A3D
000076c1d9dd59ec  movaps xmm10, xmm12
000076c1d9dd59f0  mulpd xmm10, xmm11
000076c1d9dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000076c1d9dd59fb  ptest xmm6, xmm6
000076c1d9dd5a00  jnz 0x000076C1D9DD6B81
000076c1d9dd5a06  movaps xmm11, [r15+0x1F0]
000076c1d9dd5a0e  movaps xmm6, xmm12
000076c1d9dd5a12  mulpd xmm6, xmm11
000076c1d9dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000076c1d9dd5a1c  ptest xmm5, xmm5
000076c1d9dd5a21  jnz 0x000076C1D9DD6CC5
000076c1d9dd5a27  movaps xmm12, [r15+0x2A0]
000076c1d9dd5a2f  vmovaps [rsp+0x80], xmm12
000076c1d9dd5a38  vmovaps xmm11, [rsp+0x80]
000076c1d9dd5a41  por xmm12, xmm11
000076c1d9dd5a46  movaps xmm11, [r15+0x250]
000076c1d9dd5a4e  vmovaps [rsp+0x80], xmm11
000076c1d9dd5a57  vmovaps xmm5, [rsp+0x80]
000076c1d9dd5a60  por xmm11, xmm5
000076c1d9dd5a65  vmovaps xmm4, [rsp+0x70]
000076c1d9dd5a6b  vpermilpd xmm4, xmm4, 0x00
000076c1d9dd5a71  movaps xmm3, xmm5
000076c1d9dd5a74  mulpd xmm3, xmm4
000076c1d9dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000076c1d9dd5a7d  ptest xmm2, xmm2
000076c1d9dd5a82  jnz 0x000076C1D9DD6E07
000076c1d9dd5a88  mov [rsp+0x80], rax
000076c1d9dd5a90  xor eax, eax
000076c1d9dd5a92  mov r14d, 0x200
000076c1d9dd5a98  cmp r12, r14
000076c1d9dd5a9b  cmc
000076c1d9dd5a9c  lahf
000076c1d9dd5a9d  seto al
000076c1d9dd5aa0  mov [r15+0x108], eax
000076c1d9dd5aa7  movaps xmm5, xmm8
000076c1d9dd5aab  addpd xmm5, xmm15
000076c1d9dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000076c1d9dd5ab5  ptest xmm4, xmm4
000076c1d9dd5aba  jnz 0x000076C1D9DD6F47
000076c1d9dd5ac0  movaps xmm8, [r15+0x1B0]
000076c1d9dd5ac8  movaps xmm4, xmm9
000076c1d9dd5acc  addpd xmm4, xmm8
000076c1d9dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000076c1d9dd5ad6  ptest xmm2, xmm2
000076c1d9dd5adb  jnz 0x000076C1D9DD7089
000076c1d9dd5ae1  movaps xmm9, xmm10
000076c1d9dd5ae5  addpd xmm9, xmm8
000076c1d9dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000076c1d9dd5af0  ptest xmm2, xmm2
000076c1d9dd5af5  jnz 0x000076C1D9DD71CB
000076c1d9dd5afb  movaps xmm10, [r15+0x2F0]
000076c1d9dd5b03  vmovaps [rsp+0x90], xmm10
000076c1d9dd5b0c  vmovaps xmm8, [rsp+0x90]
000076c1d9dd5b15  por xmm10, xmm8
000076c1d9dd5b1a  movaps xmm8, [r15+0x2E0]
000076c1d9dd5b22  vmovaps [rsp+0x90], xmm8
000076c1d9dd5b2b  vmovaps xmm2, [rsp+0x90]
000076c1d9dd5b34  por xmm8, xmm2
000076c1d9dd5b39  movaps xmm2, [r15+0x2D0]
000076c1d9dd5b41  vmovaps [rsp+0x90], xmm2
000076c1d9dd5b4a  vmovaps [rsp+0xA0], xmm1
000076c1d9dd5b53  vmovaps xmm1, [rsp+0x90]
000076c1d9dd5b5c  por xmm2, xmm1
000076c1d9dd5b60  movaps xmm1, [r15+0x200]
000076c1d9dd5b68  vmovaps [rsp+0x90], xmm1
000076c1d9dd5b71  vmovaps [rsp+0xB0], xmm15
000076c1d9dd5b7a  vmovaps xmm15, [rsp+0x90]
000076c1d9dd5b83  por xmm1, xmm15
000076c1d9dd5b88  movaps xmm15, [r15+0x1C0]
000076c1d9dd5b90  vmovaps [rsp+0x90], xmm15
000076c1d9dd5b99  vmovaps [rsp+0xC0], xmm1
000076c1d9dd5ba2  vmovaps xmm1, [rsp+0x90]
000076c1d9dd5bab  por xmm15, xmm1
000076c1d9dd5bb0  movaps xmm1, [r15+0x190]
000076c1d9dd5bb8  vmovaps [rsp+0x90], xmm1
000076c1d9dd5bc1  vmovaps [rsp+0xD0], xmm15
000076c1d9dd5bca  vmovaps xmm15, [rsp+0x90]
000076c1d9dd5bd3  por xmm1, xmm15
000076c1d9dd5bd8  movaps xmm15, [r15+0x300]
000076c1d9dd5be0  vmovaps [rsp+0x90], xmm15
000076c1d9dd5be9  vmovaps [rsp+0xE0], xmm1
000076c1d9dd5bf2  vmovaps xmm1, [rsp+0x90]
000076c1d9dd5bfb  por xmm15, xmm1
000076c1d9dd5c00  mov rax, [rsp+0x80]
000076c1d9dd5c08  lea r14, [rax+0xA0]
000076c1d9dd5c0f  movups xmm1, [r13+r14*1]
000076c1d9dd5c15  lea r14, [rax+0xB0]
000076c1d9dd5c1c  vmovaps [rsp+0x80], xmm1
000076c1d9dd5c25  movups xmm1, [r13+r14*1]
000076c1d9dd5c2b  vmovaps [rsp+0x90], xmm1
000076c1d9dd5c34  vmovaps [rsp+0xF0], xmm15
000076c1d9dd5c3d  vmovaps xmm15, [rsp+0xB0]
000076c1d9dd5c46  vmovaps [rsp+0xB0], xmm14
000076c1d9dd5c4f  movaps xmm1, xmm6
000076c1d9dd5c52  addpd xmm1, xmm15
000076c1d9dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000076c1d9dd5c5c  ptest xmm14, xmm14
000076c1d9dd5c62  jnz 0x000076C1D9DD7323
000076c1d9dd5c68  lea r14, [rax+0xF0]
000076c1d9dd5c6f  movups xmm15, [r13+r14*1]
000076c1d9dd5c75  movaps xmm14, xmm4
000076c1d9dd5c79  addpd xmm14, xmm3
000076c1d9dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000076c1d9dd5c84  ptest xmm6, xmm6
000076c1d9dd5c89  jnz 0x000076C1D9DD746E
000076c1d9dd5c8f  movaps xmm6, xmm9
000076c1d9dd5c93  addpd xmm6, xmm7
000076c1d9dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000076c1d9dd5c9c  ptest xmm4, xmm4
000076c1d9dd5ca1  jnz 0x000076C1D9DD75B0
000076c1d9dd5ca7  vmovaps xmm9, [rsp+0x70]
000076c1d9dd5cad  vpermilpd xmm9, xmm9, 0x00
000076c1d9dd5cb3  vmovaps xmm4, [rsp+0x90]
000076c1d9dd5cbc  movaps xmm7, xmm4
000076c1d9dd5cbf  mulpd xmm7, xmm9
000076c1d9dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000076c1d9dd5cc9  ptest xmm3, xmm3
000076c1d9dd5cce  jnz 0x000076C1D9DD76F1
000076c1d9dd5cd4  vmovaps xmm9, [rsp+0x50]
000076c1d9dd5cda  vpermilpd xmm9, xmm9, 0x00
000076c1d9dd5ce0  movaps xmm4, xmm15
000076c1d9dd5ce4  mulpd xmm4, xmm9
000076c1d9dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000076c1d9dd5cee  ptest xmm3, xmm3
000076c1d9dd5cf3  jnz 0x000076C1D9DD7832
000076c1d9dd5cf9  lea r14, [rax+0xE0]
000076c1d9dd5d00  movups xmm15, [r13+r14*1]
000076c1d9dd5d06  vmovaps xmm9, [rsp+0x70]
000076c1d9dd5d0c  vpermilpd xmm9, xmm9, 0x00
000076c1d9dd5d12  vmovaps [rsp+0x70], xmm1
000076c1d9dd5d18  vmovaps xmm1, [rsp+0x80]
000076c1d9dd5d21  vmovaps [rsp+0x80], xmm15
000076c1d9dd5d2a  movaps xmm3, xmm1
000076c1d9dd5d2d  mulpd xmm3, xmm9
000076c1d9dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000076c1d9dd5d37  ptest xmm15, xmm15
000076c1d9dd5d3d  jnz 0x000076C1D9DD797E
000076c1d9dd5d43  vmovaps xmm1, [rsp+0xF0]
000076c1d9dd5d4c  vmovaps xmm15, [rsp+0xF0]
000076c1d9dd5d55  por xmm1, xmm15
000076c1d9dd5d5a  movaps [r15+0x300], xmm1
000076c1d9dd5d62  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd5d6b  vmovaps xmm9, [rsp+0xE0]
000076c1d9dd5d74  por xmm15, xmm9
000076c1d9dd5d79  movaps [r15+0x190], xmm15
000076c1d9dd5d81  vmovaps xmm9, [rsp+0x50]
000076c1d9dd5d87  vpermilpd xmm9, xmm9, 0x00
000076c1d9dd5d8d  vmovaps [rsp+0x90], xmm1
000076c1d9dd5d96  vmovaps [rsp+0xE0], xmm15
000076c1d9dd5d9f  vmovaps xmm15, [rsp+0x80]
000076c1d9dd5da8  vmovaps [rsp+0x80], xmm14
000076c1d9dd5db1  movaps xmm1, xmm15
000076c1d9dd5db5  mulpd xmm1, xmm9
000076c1d9dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000076c1d9dd5dbf  ptest xmm14, xmm14
000076c1d9dd5dc5  jnz 0x000076C1D9DD7ABF
000076c1d9dd5dcb  lea r14, [rax+0x90]
000076c1d9dd5dd2  movups xmm15, [r13+r14*1]
000076c1d9dd5dd8  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd5de1  vmovaps xmm9, [rsp+0xD0]
000076c1d9dd5dea  por xmm14, xmm9
000076c1d9dd5def  movaps [r15+0x1C0], xmm14
000076c1d9dd5df7  vmovaps xmm9, [rsp+0xC0]
000076c1d9dd5e00  vmovaps [rsp+0xD0], xmm1
000076c1d9dd5e09  vmovaps xmm1, [rsp+0xC0]
000076c1d9dd5e12  por xmm9, xmm1
000076c1d9dd5e17  movaps [r15+0x200], xmm9
000076c1d9dd5e1f  vmovaps [rsp+0xC0], xmm2
000076c1d9dd5e28  vmovaps xmm1, [rsp+0xC0]
000076c1d9dd5e31  por xmm2, xmm1
000076c1d9dd5e35  movaps [r15+0x2D0], xmm2
000076c1d9dd5e3d  vmovaps [rsp+0xC0], xmm8
000076c1d9dd5e46  vmovaps xmm1, [rsp+0xC0]
000076c1d9dd5e4f  por xmm8, xmm1
000076c1d9dd5e54  movaps [r15+0x2E0], xmm8
000076c1d9dd5e5c  vmovaps [rsp+0xC0], xmm15
000076c1d9dd5e65  movaps xmm1, xmm5
000076c1d9dd5e68  addpd xmm1, xmm7
000076c1d9dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000076c1d9dd5e71  ptest xmm15, xmm15
000076c1d9dd5e77  jnz 0x000076C1D9DD7C0B
000076c1d9dd5e7d  vmovaps xmm15, [rsp+0x50]
000076c1d9dd5e83  vpermilpd xmm15, xmm15, 0x00
000076c1d9dd5e89  vmovaps xmm5, [rsp+0xC0]
000076c1d9dd5e92  vmovaps [rsp+0xC0], xmm1
000076c1d9dd5e9b  movaps xmm7, xmm5
000076c1d9dd5e9e  mulpd xmm7, xmm15
000076c1d9dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000076c1d9dd5ea8  ptest xmm1, xmm1
000076c1d9dd5ead  jnz 0x000076C1D9DD7D4B
000076c1d9dd5eb3  lea r14, [rax+0x80]
000076c1d9dd5eba  movups xmm1, [r13+r14*1]
000076c1d9dd5ec0  vmovaps xmm5, [rsp+0x70]
000076c1d9dd5ec6  vmovaps [rsp+0x70], xmm1
000076c1d9dd5ecc  movaps xmm15, xmm5
000076c1d9dd5ed0  addpd xmm15, xmm3
000076c1d9dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000076c1d9dd5edb  ptest xmm1, xmm1
000076c1d9dd5ee0  jnz 0x000076C1D9DD7E96
000076c1d9dd5ee6  vmovaps xmm5, [rsp+0x80]
000076c1d9dd5eef  movaps xmm1, xmm5
000076c1d9dd5ef2  addpd xmm1, xmm4
000076c1d9dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000076c1d9dd5efb  ptest xmm3, xmm3
000076c1d9dd5f00  jnz 0x000076C1D9DD7FD8
000076c1d9dd5f06  vmovaps [rsp+0x80], xmm10
000076c1d9dd5f0f  vmovaps xmm5, [rsp+0x80]
000076c1d9dd5f18  por xmm10, xmm5
000076c1d9dd5f1d  movaps [r15+0x2F0], xmm10
000076c1d9dd5f25  vmovaps xmm5, [rsp+0x50]
000076c1d9dd5f2b  vpermilpd xmm5, xmm5, 0x00
000076c1d9dd5f31  vmovaps xmm3, [rsp+0x70]
000076c1d9dd5f37  vmovaps [rsp+0x50], xmm1
000076c1d9dd5f3d  movaps xmm4, xmm3
000076c1d9dd5f40  mulpd xmm4, xmm5
000076c1d9dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000076c1d9dd5f49  ptest xmm1, xmm1
000076c1d9dd5f4e  jnz 0x000076C1D9DD8118
000076c1d9dd5f54  lea r14, [rax+0xD0]
000076c1d9dd5f5b  movups xmm1, [r13+r14*1]
000076c1d9dd5f61  vmovaps xmm3, [rsp+0xD0]
000076c1d9dd5f6a  vmovaps [rsp+0x70], xmm1
000076c1d9dd5f70  movaps xmm5, xmm6
000076c1d9dd5f73  addpd xmm5, xmm3
000076c1d9dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000076c1d9dd5f7c  ptest xmm1, xmm1
000076c1d9dd5f81  jnz 0x000076C1D9DD8262
000076c1d9dd5f87  vmovaps xmm1, [rsp+0x60]
000076c1d9dd5f8d  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd5f93  movaps xmm6, xmm9
000076c1d9dd5f97  mulpd xmm6, xmm1
000076c1d9dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000076c1d9dd5fa0  ptest xmm3, xmm3
000076c1d9dd5fa5  jnz 0x000076C1D9DD83A2
000076c1d9dd5fab  movaps [r15+0x260], xmm6
000076c1d9dd5fb3  vxorps xmm1, xmm1, xmm1
000076c1d9dd5fb7  vpbroadcastq xmm1, xmm1
000076c1d9dd5fbc  movaps [r15+0x1B0], xmm1
000076c1d9dd5fc4  vmovaps xmm1, [rsp+0x60]
000076c1d9dd5fca  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd5fd0  vmovaps xmm3, [rsp+0x70]
000076c1d9dd5fd6  vmovaps [rsp+0x70], xmm15
000076c1d9dd5fdc  movaps xmm9, xmm3
000076c1d9dd5fe0  mulpd xmm9, xmm1
000076c1d9dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000076c1d9dd5feb  ptest xmm15, xmm15
000076c1d9dd5ff1  jnz 0x000076C1D9DD84E3
000076c1d9dd5ff7  lea r14, [rax+0xC0]
000076c1d9dd5ffe  movups xmm1, [r13+r14*1]
000076c1d9dd6004  vmovaps xmm3, [rsp+0xC0]
000076c1d9dd600d  vmovaps [rsp+0x80], xmm1
000076c1d9dd6016  movaps xmm15, xmm3
000076c1d9dd601a  addpd xmm15, xmm7
000076c1d9dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000076c1d9dd6025  ptest xmm1, xmm1
000076c1d9dd602a  jnz 0x000076C1D9DD862F
000076c1d9dd6030  vmovaps [rsp+0xC0], xmm13
000076c1d9dd6039  vmovaps xmm1, [rsp+0xC0]
000076c1d9dd6042  por xmm13, xmm1
000076c1d9dd6047  movaps [r15+0x270], xmm13
000076c1d9dd604f  vmovaps xmm1, [rsp+0xB0]
000076c1d9dd6058  vmovaps xmm7, [rsp+0xB0]
000076c1d9dd6061  por xmm1, xmm7
000076c1d9dd6065  movaps [r15+0x1A0], xmm1
000076c1d9dd606d  vmovaps xmm1, [rsp+0x60]
000076c1d9dd6073  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd6079  vmovaps [rsp+0xB0], xmm1
000076c1d9dd6082  vmovaps xmm1, [rsp+0x80]
000076c1d9dd608b  vmovaps [rsp+0x80], xmm15
000076c1d9dd6094  vmovaps xmm15, [rsp+0xB0]
000076c1d9dd609d  vmovaps [rsp+0xB0], xmm14
000076c1d9dd60a6  movaps xmm3, xmm1
000076c1d9dd60a9  mulpd xmm3, xmm15
000076c1d9dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000076c1d9dd60b3  ptest xmm14, xmm14
000076c1d9dd60b9  jnz 0x000076C1D9DD8771
000076c1d9dd60bf  lea r14, [rax+0x20]
000076c1d9dd60c3  movups xmm1, [r13+r14*1]
000076c1d9dd60c9  movaps [r15+0x110], xmm1
000076c1d9dd60d1  vmovaps xmm14, [rsp+0x70]
000076c1d9dd60d7  vmovaps [rsp+0x70], xmm1
000076c1d9dd60dd  movaps xmm15, xmm14
000076c1d9dd60e1  addpd xmm15, xmm4
000076c1d9dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000076c1d9dd60ec  ptest xmm1, xmm1
000076c1d9dd60f1  jnz 0x000076C1D9DD88BC
000076c1d9dd60f7  vmovaps xmm1, [rsp+0x60]
000076c1d9dd60fd  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd6103  movaps xmm14, xmm2
000076c1d9dd6107  mulpd xmm14, xmm1
000076c1d9dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000076c1d9dd6112  ptest xmm4, xmm4
000076c1d9dd6117  jnz 0x000076C1D9DD89FF
000076c1d9dd611d  vmovaps xmm4, [rsp+0x50]
000076c1d9dd6123  movaps xmm1, xmm4
000076c1d9dd6126  addpd xmm1, xmm9
000076c1d9dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000076c1d9dd6130  ptest xmm2, xmm2
000076c1d9dd6135  jnz 0x000076C1D9DD8B41
000076c1d9dd613b  vmovaps xmm9, [rsp+0x30]
000076c1d9dd6141  vpermilpd xmm9, xmm9, 0x00
000076c1d9dd6147  vmovaps xmm2, [rsp+0x70]
000076c1d9dd614d  vmovaps [rsp+0x50], xmm1
000076c1d9dd6153  movaps xmm4, xmm2
000076c1d9dd6156  mulpd xmm4, xmm9
000076c1d9dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000076c1d9dd6160  ptest xmm1, xmm1
000076c1d9dd6165  jnz 0x000076C1D9DD8C82
000076c1d9dd616b  vmovaps xmm1, [rsp+0x30]
000076c1d9dd6171  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd6177  vmovaps xmm2, [rsp+0x90]
000076c1d9dd6180  vmovaps [rsp+0x60], xmm15
000076c1d9dd6186  movaps xmm9, xmm2
000076c1d9dd618a  mulpd xmm9, xmm1
000076c1d9dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000076c1d9dd6195  ptest xmm15, xmm15
000076c1d9dd619b  jnz 0x000076C1D9DD8DC3
000076c1d9dd61a1  vmovaps xmm15, [rsp+0x80]
000076c1d9dd61aa  movaps xmm1, xmm15
000076c1d9dd61ae  addpd xmm1, xmm6
000076c1d9dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000076c1d9dd61b7  ptest xmm2, xmm2
000076c1d9dd61bc  jnz 0x000076C1D9DD8F05
000076c1d9dd61c2  movaps xmm15, xmm5
000076c1d9dd61c6  addpd xmm15, xmm3
000076c1d9dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000076c1d9dd61d1  ptest xmm6, xmm6
000076c1d9dd61d6  jnz 0x000076C1D9DD9046
000076c1d9dd61dc  vmovaps xmm6, [rsp+0x30]
000076c1d9dd61e2  vpermilpd xmm6, xmm6, 0x00
000076c1d9dd61e8  movaps xmm5, xmm8
000076c1d9dd61ec  mulpd xmm5, xmm6
000076c1d9dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000076c1d9dd61f5  ptest xmm3, xmm3
000076c1d9dd61fa  jnz 0x000076C1D9DD9188
000076c1d9dd6200  vmovaps xmm8, [rsp+0x30]
000076c1d9dd6206  vpermilpd xmm8, xmm8, 0x00
000076c1d9dd620c  movaps xmm6, xmm10
000076c1d9dd6210  mulpd xmm6, xmm8
000076c1d9dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000076c1d9dd621a  ptest xmm3, xmm3
000076c1d9dd621f  jnz 0x000076C1D9DD92C9
000076c1d9dd6225  vmovaps xmm8, [rsp+0x60]
000076c1d9dd622b  movaps xmm10, xmm8
000076c1d9dd622f  addpd xmm10, xmm14
000076c1d9dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000076c1d9dd623a  ptest xmm3, xmm3
000076c1d9dd623f  jnz 0x000076C1D9DD940B
000076c1d9dd6245  vmovaps xmm8, [rsp+0x50]
000076c1d9dd624b  movaps xmm14, xmm8
000076c1d9dd624f  addpd xmm14, xmm4
000076c1d9dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000076c1d9dd625a  ptest xmm3, xmm3
000076c1d9dd625f  jnz 0x000076C1D9DD954F
000076c1d9dd6265  vmovaps xmm8, [rsp+0x40]
000076c1d9dd626b  vpermilpd xmm8, xmm8, 0x00
000076c1d9dd6271  movaps xmm4, xmm13
000076c1d9dd6275  mulpd xmm4, xmm8
000076c1d9dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000076c1d9dd627f  ptest xmm3, xmm3
000076c1d9dd6284  jnz 0x000076C1D9DD9692
000076c1d9dd628a  movaps xmm13, xmm15
000076c1d9dd628e  addpd xmm13, xmm9
000076c1d9dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000076c1d9dd6299  ptest xmm8, xmm8
000076c1d9dd629f  jnz 0x000076C1D9DD97D4
000076c1d9dd62a5  movaps xmm15, xmm1
000076c1d9dd62a9  addpd xmm15, xmm5
000076c1d9dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000076c1d9dd62b4  ptest xmm9, xmm9
000076c1d9dd62ba  jnz 0x000076C1D9DD9918
000076c1d9dd62c0  vmovaps [rsp+0x30], xmm11
000076c1d9dd62c6  vmovaps xmm1, [rsp+0x30]
000076c1d9dd62cc  por xmm11, xmm1
000076c1d9dd62d1  movaps [r15+0x250], xmm11
000076c1d9dd62d9  vmovaps [rsp+0x30], xmm12
000076c1d9dd62df  vmovaps xmm1, [rsp+0x30]
000076c1d9dd62e5  por xmm12, xmm1
000076c1d9dd62ea  movaps [r15+0x2A0], xmm12
000076c1d9dd62f2  vmovaps xmm1, [rsp+0xA0]
000076c1d9dd62fb  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd6304  por xmm1, xmm11
000076c1d9dd6309  movaps [r15+0x1D0], xmm1
000076c1d9dd6311  lea r14, [rax+0x40]
000076c1d9dd6315  movups xmm1, [r13+r14*1]
000076c1d9dd631b  movaps [r15+0x2C0], xmm1
000076c1d9dd6323  vmovaps xmm11, [rsp+0x40]
000076c1d9dd6329  vpermilpd xmm11, xmm11, 0x00
000076c1d9dd632f  vmovaps xmm8, [rsp+0xE0]
000076c1d9dd6338  movaps xmm9, xmm8
000076c1d9dd633c  mulpd xmm9, xmm11
000076c1d9dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000076c1d9dd6347  ptest xmm5, xmm5
000076c1d9dd634c  jnz 0x000076C1D9DD9A64
000076c1d9dd6352  movaps xmm11, xmm10
000076c1d9dd6356  addpd xmm11, xmm6
000076c1d9dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000076c1d9dd6361  ptest xmm8, xmm8
000076c1d9dd6367  jnz 0x000076C1D9DD9BA8
000076c1d9dd636d  movaps xmm10, xmm14
000076c1d9dd6371  addpd xmm10, xmm4
000076c1d9dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000076c1d9dd637c  ptest xmm8, xmm8
000076c1d9dd6382  jnz 0x000076C1D9DD9CEB
000076c1d9dd6388  vmovaps xmm14, [rsp+0x40]
000076c1d9dd638e  vpermilpd xmm14, xmm14, 0x00
000076c1d9dd6394  movaps xmm8, xmm1
000076c1d9dd6398  mulpd xmm8, xmm14
000076c1d9dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000076c1d9dd63a3  ptest xmm6, xmm6
000076c1d9dd63a8  jnz 0x000076C1D9DD9E2E
000076c1d9dd63ae  movaps xmm1, [r15+0x2B0]
000076c1d9dd63b6  vmovaps xmm14, [rsp+0x40]
000076c1d9dd63bc  vpermilpd xmm14, xmm14, 0x00
000076c1d9dd63c2  movaps xmm6, xmm1
000076c1d9dd63c5  mulpd xmm6, xmm14
000076c1d9dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000076c1d9dd63cf  ptest xmm5, xmm5
000076c1d9dd63d4  jnz 0x000076C1D9DD9F71
000076c1d9dd63da  vmovaps xmm1, [rsp+0x10]
000076c1d9dd63e0  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd63e6  movaps xmm14, xmm12
000076c1d9dd63ea  mulpd xmm14, xmm1
000076c1d9dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000076c1d9dd63f5  ptest xmm5, xmm5
000076c1d9dd63fa  jnz 0x000076C1D9DDA0B2
000076c1d9dd6400  movaps xmm1, xmm13
000076c1d9dd6404  addpd xmm1, xmm9
000076c1d9dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000076c1d9dd640e  ptest xmm12, xmm12
000076c1d9dd6414  jnz 0x000076C1D9DDA1F5
000076c1d9dd641a  vmovaps xmm13, [rsp+0x10]
000076c1d9dd6420  vpermilpd xmm13, xmm13, 0x00
000076c1d9dd6426  movaps xmm12, xmm7
000076c1d9dd642a  mulpd xmm12, xmm13
000076c1d9dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000076c1d9dd6435  ptest xmm9, xmm9
000076c1d9dd643b  jnz 0x000076C1D9DDA337
000076c1d9dd6441  movaps xmm13, xmm15
000076c1d9dd6445  addpd xmm13, xmm8
000076c1d9dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000076c1d9dd6450  ptest xmm9, xmm9
000076c1d9dd6456  jnz 0x000076C1D9DDA47A
000076c1d9dd645c  movaps xmm15, [r15+0x290]
000076c1d9dd6464  vmovaps xmm9, [rsp+0x10]
000076c1d9dd646a  vpermilpd xmm9, xmm9, 0x00
000076c1d9dd6470  movaps xmm8, xmm15
000076c1d9dd6474  mulpd xmm8, xmm9
000076c1d9dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000076c1d9dd647f  ptest xmm7, xmm7
000076c1d9dd6484  jnz 0x000076C1D9DDA5BE
000076c1d9dd648a  movaps xmm15, xmm11
000076c1d9dd648e  addpd xmm15, xmm6
000076c1d9dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000076c1d9dd6499  ptest xmm9, xmm9
000076c1d9dd649f  jnz 0x000076C1D9DDA702
000076c1d9dd64a5  movaps xmm11, [r15+0x1E0]
000076c1d9dd64ad  vmovaps xmm9, [rsp+0x10]
000076c1d9dd64b3  vpermilpd xmm9, xmm9, 0x00
000076c1d9dd64b9  movaps xmm7, xmm11
000076c1d9dd64bd  mulpd xmm7, xmm9
000076c1d9dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000076c1d9dd64c7  ptest xmm6, xmm6
000076c1d9dd64cc  jnz 0x000076C1D9DDA845
000076c1d9dd64d2  movaps xmm11, xmm10
000076c1d9dd64d6  addpd xmm11, xmm14
000076c1d9dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000076c1d9dd64e1  ptest xmm9, xmm9
000076c1d9dd64e7  jnz 0x000076C1D9DDA987
000076c1d9dd64ed  lea r14, [rax+0x70]
000076c1d9dd64f1  movups xmm14, [r13+r14*1]
000076c1d9dd64f7  movaps [r15+0x240], xmm14
000076c1d9dd64ff  movaps xmm10, xmm1
000076c1d9dd6503  addpd xmm10, xmm12
000076c1d9dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000076c1d9dd650e  ptest xmm9, xmm9
000076c1d9dd6514  jnz 0x000076C1D9DDAAD5
000076c1d9dd651a  movaps [r15+0x170], xmm10
000076c1d9dd6522  vmovaps xmm1, [rsp+0x20]
000076c1d9dd6528  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd652e  movaps xmm12, xmm14
000076c1d9dd6532  mulpd xmm12, xmm1
000076c1d9dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000076c1d9dd653d  ptest xmm9, xmm9
000076c1d9dd6543  jnz 0x000076C1D9DDAC18
000076c1d9dd6549  vmovaps xmm1, [rsp+0x20]
000076c1d9dd654f  vpermilpd xmm1, xmm1, 0x00
000076c1d9dd6555  vmovaps xmm9, [rsp+0xB0]
000076c1d9dd655e  movaps xmm14, xmm9
000076c1d9dd6562  mulpd xmm14, xmm1
000076c1d9dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000076c1d9dd656d  ptest xmm6, xmm6
000076c1d9dd6572  jnz 0x000076C1D9DDAD5B
000076c1d9dd6578  movaps [r15+0x180], xmm14
000076c1d9dd6580  movaps xmm1, xmm13
000076c1d9dd6584  addpd xmm1, xmm8
000076c1d9dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000076c1d9dd658e  ptest xmm9, xmm9
000076c1d9dd6594  jnz 0x000076C1D9DDAE9E
000076c1d9dd659a  movaps [r15+0x210], xmm1
000076c1d9dd65a2  movups xmm13, [r13+rax*1]
000076c1d9dd65a8  lea r14, [rax+0x10]
000076c1d9dd65ac  movups xmm9, [r13+r14*1]
000076c1d9dd65b2  movaps [r15+0x230], xmm9
000076c1d9dd65ba  movaps xmm8, xmm15
000076c1d9dd65be  addpd xmm8, xmm7
000076c1d9dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000076c1d9dd65c9  ptest xmm6, xmm6
000076c1d9dd65ce  jnz 0x000076C1D9DDAFF4
000076c1d9dd65d4  movaps [r15+0x130], xmm8
000076c1d9dd65dc  vmovaps xmm15, [rsp+0x20]
000076c1d9dd65e2  vpermilpd xmm15, xmm15, 0x00
000076c1d9dd65e8  movaps xmm7, xmm9
000076c1d9dd65ec  mulpd xmm7, xmm15
000076c1d9dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000076c1d9dd65f6  ptest xmm6, xmm6
000076c1d9dd65fb  jnz 0x000076C1D9DDB137
000076c1d9dd6601  movaps [r15+0x220], xmm7
000076c1d9dd6609  vmovaps xmm15, [rsp+0x20]
000076c1d9dd660f  vpermilpd xmm15, xmm15, 0x00
000076c1d9dd6615  movaps xmm9, xmm13
000076c1d9dd6619  mulpd xmm9, xmm15
000076c1d9dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000076c1d9dd6624  ptest xmm6, xmm6
000076c1d9dd6629  jnz 0x000076C1D9DDB279
000076c1d9dd662f  movaps xmm15, xmm11
000076c1d9dd6633  addpd xmm15, xmm12
000076c1d9dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000076c1d9dd663e  ptest xmm13, xmm13
000076c1d9dd6644  jnz 0x000076C1D9DDB3BD
000076c1d9dd664a  movaps [r15+0x140], xmm15
000076c1d9dd6652  movaps xmm13, xmm10
000076c1d9dd6656  addpd xmm13, xmm14
000076c1d9dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000076c1d9dd6661  ptest xmm12, xmm12
000076c1d9dd6667  jnz 0x000076C1D9DDB501
000076c1d9dd666d  movaps [r15+0x150], xmm13
000076c1d9dd6675  movaps xmm14, xmm1
000076c1d9dd6679  addpd xmm14, xmm7
000076c1d9dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000076c1d9dd6684  ptest xmm12, xmm12
000076c1d9dd668a  jnz 0x000076C1D9DDB645
000076c1d9dd6690  movaps [r15+0x160], xmm14
000076c1d9dd6698  movaps xmm1, xmm8
000076c1d9dd669c  addpd xmm1, xmm9
000076c1d9dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000076c1d9dd66a6  ptest xmm12, xmm12
000076c1d9dd66ac  jnz 0x000076C1D9DDB787
000076c1d9dd66b2  movaps [r15+0x120], xmm1
000076c1d9dd66ba  movups [r13+r11*1], xmm15
000076c1d9dd66c0  lea rax, [r11+0x10]
000076c1d9dd66c4  movups [r13+rax*1], xmm13
000076c1d9dd66ca  lea rax, [r11+0x20]
000076c1d9dd66ce  movups [r13+rax*1], xmm14
000076c1d9dd66d4  lea rax, [r11+0x30]
000076c1d9dd66d8  movups [r13+rax*1], xmm1
000076c1d9dd66de  mov eax, [r15+0x108]
000076c1d9dd66e5  sahf
000076c1d9dd66e6  jnz 0x000076C1D9DD6718
000076c1d9dd66e8  cmp dword ptr [r15+0x318], 0x00
000076c1d9dd66f0  jz 0x000076C1D9DDB900
000076c1d9dd66f6  nop [rax+rax*1], ax
000076c1d9dd66ff  nop [rax+rax*1], eax
000076c1d9dd6707  mov eax, 0x410444
000076c1d9dd670c  mov [r15+0x100], rax
000076c1d9dd6713  jmp 0x000076C1D9BFE110
000076c1d9dd6718  cmp dword ptr [r15+0x318], 0x00
000076c1d9dd6720  jz 0x000076C1D9DD57E0
000076c1d9dd6726  nop [rax+rax*1], ax
000076c1d9dd672f  nop [rax+rax*1], eax
000076c1d9dd6737  mov eax, 0x410278
000076c1d9dd673c  mov [r15+0x100], rax
000076c1d9dd6743  jmp 0x000076C1D9BFE110
000076c1d9dd6748  int3
000076c1d9dd6749  call 0x000076C1D9C0A4B0
000076c1d9dd674e  jmp 0x000076C1D9DD5828
000076c1d9dd6753  call 0x000076C1D9C09240
000076c1d9dd6758  jmp 0x000076C1D9DD5832
000076c1d9dd675d  call 0x000076C1D9C0A4B0
000076c1d9dd6762  jmp 0x000076C1D9DD588F
000076c1d9dd6767  call 0x000076C1D9C09240
000076c1d9dd676c  jmp 0x000076C1D9DD5899
000076c1d9dd6771  call 0x000076C1D9C0A4B0
000076c1d9dd6776  jmp 0x000076C1D9DD58DD
000076c1d9dd677b  call 0x000076C1D9C09240
000076c1d9dd6780  jmp 0x000076C1D9DD58E7
000076c1d9dd6785  call 0x000076C1D9CB47C0
000076c1d9dd678a  jmp 0x000076C1D9DD5926
000076c1d9dd678f  call 0x000076C1D9C0B720
000076c1d9dd6794  jmp 0x000076C1D9DD593A
000076c1d9dd6799  call 0x000076C1D9CBFC30
000076c1d9dd679e  jmp 0x000076C1D9DD5958
000076c1d9dd67a3  call 0x000076C1D9CBE9C0
000076c1d9dd67a8  jmp 0x000076C1D9DD5962
000076c1d9dd67ad  call 0x000076C1D9CBD750
000076c1d9dd67b2  jmp 0x000076C1D9DD596C
000076c1d9dd67b7  sub rsp, 0x08
000076c1d9dd67bb  push rax
000076c1d9dd67bc  push rcx
000076c1d9dd67bd  push rdx
000076c1d9dd67be  push rdi
000076c1d9dd67bf  push rsi
000076c1d9dd67c0  push r8
000076c1d9dd67c2  push r9
000076c1d9dd67c4  push r10
000076c1d9dd67c6  push r11
000076c1d9dd67c8  sub rsp, 0xF0
000076c1d9dd67cf  vmovaps [rsp], xmm0
000076c1d9dd67d4  vmovaps [rsp+0x10], xmm1
000076c1d9dd67da  vmovaps [rsp+0x20], xmm2
000076c1d9dd67e0  vmovaps [rsp+0x30], xmm3
000076c1d9dd67e6  vmovaps [rsp+0x40], xmm4
000076c1d9dd67ec  vmovaps [rsp+0x50], xmm5
000076c1d9dd67f2  vmovaps [rsp+0x60], xmm6
000076c1d9dd67f8  vmovaps [rsp+0x70], xmm7
000076c1d9dd67fe  vmovaps [rsp+0x80], xmm9
000076c1d9dd6807  vmovaps [rsp+0x90], xmm10
000076c1d9dd6810  vmovaps [rsp+0xA0], xmm11
000076c1d9dd6819  vmovaps [rsp+0xB0], xmm12
000076c1d9dd6822  vmovaps [rsp+0xC0], xmm13
000076c1d9dd682b  vmovaps [rsp+0xD0], xmm14
000076c1d9dd6834  vmovaps [rsp+0xE0], xmm15
000076c1d9dd683d  sub rsp, 0x30
000076c1d9dd6841  movaps [rsp], xmm8
000076c1d9dd6846  movaps [rsp+0x10], xmm12
000076c1d9dd684c  movaps [rsp+0x20], xmm15
000076c1d9dd6852  lea rdi, [rsp]
000076c1d9dd6856  mov esi, 0x00
000076c1d9dd685b  mov rax, 0x5EA58B9E0530
000076c1d9dd6865  call rax
000076c1d9dd6867  movaps xmm8, [rsp]
000076c1d9dd686c  add rsp, 0x30
000076c1d9dd6870  vmovaps xmm0, [rsp]
000076c1d9dd6875  vmovaps xmm1, [rsp+0x10]
000076c1d9dd687b  vmovaps xmm2, [rsp+0x20]
000076c1d9dd6881  vmovaps xmm3, [rsp+0x30]
000076c1d9dd6887  vmovaps xmm4, [rsp+0x40]
000076c1d9dd688d  vmovaps xmm5, [rsp+0x50]
000076c1d9dd6893  vmovaps xmm6, [rsp+0x60]
000076c1d9dd6899  vmovaps xmm7, [rsp+0x70]
000076c1d9dd689f  vmovaps xmm9, [rsp+0x80]
000076c1d9dd68a8  vmovaps xmm10, [rsp+0x90]
000076c1d9dd68b1  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd68ba  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd68c3  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd68cc  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd68d5  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd68de  add rsp, 0xF0
000076c1d9dd68e5  pop r11
000076c1d9dd68e7  pop r10
000076c1d9dd68e9  pop r9
000076c1d9dd68eb  pop r8
000076c1d9dd68ed  pop rsi
000076c1d9dd68ee  pop rdi
000076c1d9dd68ef  pop rdx
000076c1d9dd68f0  pop rcx
000076c1d9dd68f1  pop rax
000076c1d9dd68f2  add rsp, 0x08
000076c1d9dd68f6  jmp 0x000076C1D9DD599A
000076c1d9dd68fb  sub rsp, 0x08
000076c1d9dd68ff  push rax
000076c1d9dd6900  push rcx
000076c1d9dd6901  push rdx
000076c1d9dd6902  push rdi
000076c1d9dd6903  push rsi
000076c1d9dd6904  push r8
000076c1d9dd6906  push r9
000076c1d9dd6908  push r10
000076c1d9dd690a  push r11
000076c1d9dd690c  sub rsp, 0xF0
000076c1d9dd6913  vmovaps [rsp], xmm0
000076c1d9dd6918  vmovaps [rsp+0x10], xmm1
000076c1d9dd691e  vmovaps [rsp+0x20], xmm2
000076c1d9dd6924  vmovaps [rsp+0x30], xmm3
000076c1d9dd692a  vmovaps [rsp+0x40], xmm4
000076c1d9dd6930  vmovaps [rsp+0x50], xmm5
000076c1d9dd6936  vmovaps [rsp+0x60], xmm6
000076c1d9dd693c  vmovaps [rsp+0x70], xmm8
000076c1d9dd6942  vmovaps [rsp+0x80], xmm9
000076c1d9dd694b  vmovaps [rsp+0x90], xmm10
000076c1d9dd6954  vmovaps [rsp+0xA0], xmm11
000076c1d9dd695d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd6966  vmovaps [rsp+0xC0], xmm13
000076c1d9dd696f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd6978  vmovaps [rsp+0xE0], xmm15
000076c1d9dd6981  sub rsp, 0x30
000076c1d9dd6985  movaps [rsp], xmm7
000076c1d9dd6989  movaps [rsp+0x10], xmm9
000076c1d9dd698f  movaps [rsp+0x20], xmm15
000076c1d9dd6995  lea rdi, [rsp]
000076c1d9dd6999  mov esi, 0x00
000076c1d9dd699e  mov rax, 0x5EA58B9E0530
000076c1d9dd69a8  call rax
000076c1d9dd69aa  movaps xmm7, [rsp]
000076c1d9dd69ae  add rsp, 0x30
000076c1d9dd69b2  vmovaps xmm0, [rsp]
000076c1d9dd69b7  vmovaps xmm1, [rsp+0x10]
000076c1d9dd69bd  vmovaps xmm2, [rsp+0x20]
000076c1d9dd69c3  vmovaps xmm3, [rsp+0x30]
000076c1d9dd69c9  vmovaps xmm4, [rsp+0x40]
000076c1d9dd69cf  vmovaps xmm5, [rsp+0x50]
000076c1d9dd69d5  vmovaps xmm6, [rsp+0x60]
000076c1d9dd69db  vmovaps xmm8, [rsp+0x70]
000076c1d9dd69e1  vmovaps xmm9, [rsp+0x80]
000076c1d9dd69ea  vmovaps xmm10, [rsp+0x90]
000076c1d9dd69f3  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd69fc  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd6a05  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd6a0e  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd6a17  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd6a20  add rsp, 0xF0
000076c1d9dd6a27  pop r11
000076c1d9dd6a29  pop r10
000076c1d9dd6a2b  pop r9
000076c1d9dd6a2d  pop r8
000076c1d9dd6a2f  pop rsi
000076c1d9dd6a30  pop rdi
000076c1d9dd6a31  pop rdx
000076c1d9dd6a32  pop rcx
000076c1d9dd6a33  pop rax
000076c1d9dd6a34  add rsp, 0x08
000076c1d9dd6a38  jmp 0x000076C1D9DD59C8
000076c1d9dd6a3d  sub rsp, 0x08
000076c1d9dd6a41  push rax
000076c1d9dd6a42  push rcx
000076c1d9dd6a43  push rdx
000076c1d9dd6a44  push rdi
000076c1d9dd6a45  push rsi
000076c1d9dd6a46  push r8
000076c1d9dd6a48  push r9
000076c1d9dd6a4a  push r10
000076c1d9dd6a4c  push r11
000076c1d9dd6a4e  sub rsp, 0xF0
000076c1d9dd6a55  vmovaps [rsp], xmm0
000076c1d9dd6a5a  vmovaps [rsp+0x10], xmm1
000076c1d9dd6a60  vmovaps [rsp+0x20], xmm2
000076c1d9dd6a66  vmovaps [rsp+0x30], xmm3
000076c1d9dd6a6c  vmovaps [rsp+0x40], xmm4
000076c1d9dd6a72  vmovaps [rsp+0x50], xmm5
000076c1d9dd6a78  vmovaps [rsp+0x60], xmm6
000076c1d9dd6a7e  vmovaps [rsp+0x70], xmm7
000076c1d9dd6a84  vmovaps [rsp+0x80], xmm8
000076c1d9dd6a8d  vmovaps [rsp+0x90], xmm10
000076c1d9dd6a96  vmovaps [rsp+0xA0], xmm11
000076c1d9dd6a9f  vmovaps [rsp+0xB0], xmm12
000076c1d9dd6aa8  vmovaps [rsp+0xC0], xmm13
000076c1d9dd6ab1  vmovaps [rsp+0xD0], xmm14
000076c1d9dd6aba  vmovaps [rsp+0xE0], xmm15
000076c1d9dd6ac3  sub rsp, 0x30
000076c1d9dd6ac7  movaps [rsp], xmm9
000076c1d9dd6acc  movaps [rsp+0x10], xmm12
000076c1d9dd6ad2  movaps [rsp+0x20], xmm10
000076c1d9dd6ad8  lea rdi, [rsp]
000076c1d9dd6adc  mov esi, 0x00
000076c1d9dd6ae1  mov rax, 0x5EA58B9E0530
000076c1d9dd6aeb  call rax
000076c1d9dd6aed  movaps xmm9, [rsp]
000076c1d9dd6af2  add rsp, 0x30
000076c1d9dd6af6  vmovaps xmm0, [rsp]
000076c1d9dd6afb  vmovaps xmm1, [rsp+0x10]
000076c1d9dd6b01  vmovaps xmm2, [rsp+0x20]
000076c1d9dd6b07  vmovaps xmm3, [rsp+0x30]
000076c1d9dd6b0d  vmovaps xmm4, [rsp+0x40]
000076c1d9dd6b13  vmovaps xmm5, [rsp+0x50]
000076c1d9dd6b19  vmovaps xmm6, [rsp+0x60]
000076c1d9dd6b1f  vmovaps xmm7, [rsp+0x70]
000076c1d9dd6b25  vmovaps xmm8, [rsp+0x80]
000076c1d9dd6b2e  vmovaps xmm10, [rsp+0x90]
000076c1d9dd6b37  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd6b40  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd6b49  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd6b52  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd6b5b  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd6b64  add rsp, 0xF0
000076c1d9dd6b6b  pop r11
000076c1d9dd6b6d  pop r10
000076c1d9dd6b6f  pop r9
000076c1d9dd6b71  pop r8
000076c1d9dd6b73  pop rsi
000076c1d9dd6b74  pop rdi
000076c1d9dd6b75  pop rdx
000076c1d9dd6b76  pop rcx
000076c1d9dd6b77  pop rax
000076c1d9dd6b78  add rsp, 0x08
000076c1d9dd6b7c  jmp 0x000076C1D9DD59EC
000076c1d9dd6b81  sub rsp, 0x08
000076c1d9dd6b85  push rax
000076c1d9dd6b86  push rcx
000076c1d9dd6b87  push rdx
000076c1d9dd6b88  push rdi
000076c1d9dd6b89  push rsi
000076c1d9dd6b8a  push r8
000076c1d9dd6b8c  push r9
000076c1d9dd6b8e  push r10
000076c1d9dd6b90  push r11
000076c1d9dd6b92  sub rsp, 0xF0
000076c1d9dd6b99  vmovaps [rsp], xmm0
000076c1d9dd6b9e  vmovaps [rsp+0x10], xmm1
000076c1d9dd6ba4  vmovaps [rsp+0x20], xmm2
000076c1d9dd6baa  vmovaps [rsp+0x30], xmm3
000076c1d9dd6bb0  vmovaps [rsp+0x40], xmm4
000076c1d9dd6bb6  vmovaps [rsp+0x50], xmm5
000076c1d9dd6bbc  vmovaps [rsp+0x60], xmm6
000076c1d9dd6bc2  vmovaps [rsp+0x70], xmm7
000076c1d9dd6bc8  vmovaps [rsp+0x80], xmm8
000076c1d9dd6bd1  vmovaps [rsp+0x90], xmm9
000076c1d9dd6bda  vmovaps [rsp+0xA0], xmm11
000076c1d9dd6be3  vmovaps [rsp+0xB0], xmm12
000076c1d9dd6bec  vmovaps [rsp+0xC0], xmm13
000076c1d9dd6bf5  vmovaps [rsp+0xD0], xmm14
000076c1d9dd6bfe  vmovaps [rsp+0xE0], xmm15
000076c1d9dd6c07  sub rsp, 0x30
000076c1d9dd6c0b  movaps [rsp], xmm10
000076c1d9dd6c10  movaps [rsp+0x10], xmm12
000076c1d9dd6c16  movaps [rsp+0x20], xmm11
000076c1d9dd6c1c  lea rdi, [rsp]
000076c1d9dd6c20  mov esi, 0x00
000076c1d9dd6c25  mov rax, 0x5EA58B9E0530
000076c1d9dd6c2f  call rax
000076c1d9dd6c31  movaps xmm10, [rsp]
000076c1d9dd6c36  add rsp, 0x30
000076c1d9dd6c3a  vmovaps xmm0, [rsp]
000076c1d9dd6c3f  vmovaps xmm1, [rsp+0x10]
000076c1d9dd6c45  vmovaps xmm2, [rsp+0x20]
000076c1d9dd6c4b  vmovaps xmm3, [rsp+0x30]
000076c1d9dd6c51  vmovaps xmm4, [rsp+0x40]
000076c1d9dd6c57  vmovaps xmm5, [rsp+0x50]
000076c1d9dd6c5d  vmovaps xmm6, [rsp+0x60]
000076c1d9dd6c63  vmovaps xmm7, [rsp+0x70]
000076c1d9dd6c69  vmovaps xmm8, [rsp+0x80]
000076c1d9dd6c72  vmovaps xmm9, [rsp+0x90]
000076c1d9dd6c7b  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd6c84  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd6c8d  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd6c96  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd6c9f  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd6ca8  add rsp, 0xF0
000076c1d9dd6caf  pop r11
000076c1d9dd6cb1  pop r10
000076c1d9dd6cb3  pop r9
000076c1d9dd6cb5  pop r8
000076c1d9dd6cb7  pop rsi
000076c1d9dd6cb8  pop rdi
000076c1d9dd6cb9  pop rdx
000076c1d9dd6cba  pop rcx
000076c1d9dd6cbb  pop rax
000076c1d9dd6cbc  add rsp, 0x08
000076c1d9dd6cc0  jmp 0x000076C1D9DD5A06
000076c1d9dd6cc5  sub rsp, 0x08
000076c1d9dd6cc9  push rax
000076c1d9dd6cca  push rcx
000076c1d9dd6ccb  push rdx
000076c1d9dd6ccc  push rdi
000076c1d9dd6ccd  push rsi
000076c1d9dd6cce  push r8
000076c1d9dd6cd0  push r9
000076c1d9dd6cd2  push r10
000076c1d9dd6cd4  push r11
000076c1d9dd6cd6  sub rsp, 0xF0
000076c1d9dd6cdd  vmovaps [rsp], xmm0
000076c1d9dd6ce2  vmovaps [rsp+0x10], xmm1
000076c1d9dd6ce8  vmovaps [rsp+0x20], xmm2
000076c1d9dd6cee  vmovaps [rsp+0x30], xmm3
000076c1d9dd6cf4  vmovaps [rsp+0x40], xmm4
000076c1d9dd6cfa  vmovaps [rsp+0x50], xmm5
000076c1d9dd6d00  vmovaps [rsp+0x60], xmm7
000076c1d9dd6d06  vmovaps [rsp+0x70], xmm8
000076c1d9dd6d0c  vmovaps [rsp+0x80], xmm9
000076c1d9dd6d15  vmovaps [rsp+0x90], xmm10
000076c1d9dd6d1e  vmovaps [rsp+0xA0], xmm11
000076c1d9dd6d27  vmovaps [rsp+0xB0], xmm12
000076c1d9dd6d30  vmovaps [rsp+0xC0], xmm13
000076c1d9dd6d39  vmovaps [rsp+0xD0], xmm14
000076c1d9dd6d42  vmovaps [rsp+0xE0], xmm15
000076c1d9dd6d4b  sub rsp, 0x30
000076c1d9dd6d4f  movaps [rsp], xmm6
000076c1d9dd6d53  movaps [rsp+0x10], xmm12
000076c1d9dd6d59  movaps [rsp+0x20], xmm11
000076c1d9dd6d5f  lea rdi, [rsp]
000076c1d9dd6d63  mov esi, 0x00
000076c1d9dd6d68  mov rax, 0x5EA58B9E0530
000076c1d9dd6d72  call rax
000076c1d9dd6d74  movaps xmm6, [rsp]
000076c1d9dd6d78  add rsp, 0x30
000076c1d9dd6d7c  vmovaps xmm0, [rsp]
000076c1d9dd6d81  vmovaps xmm1, [rsp+0x10]
000076c1d9dd6d87  vmovaps xmm2, [rsp+0x20]
000076c1d9dd6d8d  vmovaps xmm3, [rsp+0x30]
000076c1d9dd6d93  vmovaps xmm4, [rsp+0x40]
000076c1d9dd6d99  vmovaps xmm5, [rsp+0x50]
000076c1d9dd6d9f  vmovaps xmm7, [rsp+0x60]
000076c1d9dd6da5  vmovaps xmm8, [rsp+0x70]
000076c1d9dd6dab  vmovaps xmm9, [rsp+0x80]
000076c1d9dd6db4  vmovaps xmm10, [rsp+0x90]
000076c1d9dd6dbd  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd6dc6  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd6dcf  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd6dd8  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd6de1  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd6dea  add rsp, 0xF0
000076c1d9dd6df1  pop r11
000076c1d9dd6df3  pop r10
000076c1d9dd6df5  pop r9
000076c1d9dd6df7  pop r8
000076c1d9dd6df9  pop rsi
000076c1d9dd6dfa  pop rdi
000076c1d9dd6dfb  pop rdx
000076c1d9dd6dfc  pop rcx
000076c1d9dd6dfd  pop rax
000076c1d9dd6dfe  add rsp, 0x08
000076c1d9dd6e02  jmp 0x000076C1D9DD5A27
000076c1d9dd6e07  sub rsp, 0x08
000076c1d9dd6e0b  push rax
000076c1d9dd6e0c  push rcx
000076c1d9dd6e0d  push rdx
000076c1d9dd6e0e  push rdi
000076c1d9dd6e0f  push rsi
000076c1d9dd6e10  push r8
000076c1d9dd6e12  push r9
000076c1d9dd6e14  push r10
000076c1d9dd6e16  push r11
000076c1d9dd6e18  sub rsp, 0xF0
000076c1d9dd6e1f  vmovaps [rsp], xmm0
000076c1d9dd6e24  vmovaps [rsp+0x10], xmm1
000076c1d9dd6e2a  vmovaps [rsp+0x20], xmm2
000076c1d9dd6e30  vmovaps [rsp+0x30], xmm4
000076c1d9dd6e36  vmovaps [rsp+0x40], xmm5
000076c1d9dd6e3c  vmovaps [rsp+0x50], xmm6
000076c1d9dd6e42  vmovaps [rsp+0x60], xmm7
000076c1d9dd6e48  vmovaps [rsp+0x70], xmm8
000076c1d9dd6e4e  vmovaps [rsp+0x80], xmm9
000076c1d9dd6e57  vmovaps [rsp+0x90], xmm10
000076c1d9dd6e60  vmovaps [rsp+0xA0], xmm11
000076c1d9dd6e69  vmovaps [rsp+0xB0], xmm12
000076c1d9dd6e72  vmovaps [rsp+0xC0], xmm13
000076c1d9dd6e7b  vmovaps [rsp+0xD0], xmm14
000076c1d9dd6e84  vmovaps [rsp+0xE0], xmm15
000076c1d9dd6e8d  sub rsp, 0x30
000076c1d9dd6e91  movaps [rsp], xmm3
000076c1d9dd6e95  movaps [rsp+0x10], xmm5
000076c1d9dd6e9a  movaps [rsp+0x20], xmm4
000076c1d9dd6e9f  lea rdi, [rsp]
000076c1d9dd6ea3  mov esi, 0x00
000076c1d9dd6ea8  mov rax, 0x5EA58B9E0530
000076c1d9dd6eb2  call rax
000076c1d9dd6eb4  movaps xmm3, [rsp]
000076c1d9dd6eb8  add rsp, 0x30
000076c1d9dd6ebc  vmovaps xmm0, [rsp]
000076c1d9dd6ec1  vmovaps xmm1, [rsp+0x10]
000076c1d9dd6ec7  vmovaps xmm2, [rsp+0x20]
000076c1d9dd6ecd  vmovaps xmm4, [rsp+0x30]
000076c1d9dd6ed3  vmovaps xmm5, [rsp+0x40]
000076c1d9dd6ed9  vmovaps xmm6, [rsp+0x50]
000076c1d9dd6edf  vmovaps xmm7, [rsp+0x60]
000076c1d9dd6ee5  vmovaps xmm8, [rsp+0x70]
000076c1d9dd6eeb  vmovaps xmm9, [rsp+0x80]
000076c1d9dd6ef4  vmovaps xmm10, [rsp+0x90]
000076c1d9dd6efd  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd6f06  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd6f0f  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd6f18  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd6f21  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd6f2a  add rsp, 0xF0
000076c1d9dd6f31  pop r11
000076c1d9dd6f33  pop r10
000076c1d9dd6f35  pop r9
000076c1d9dd6f37  pop r8
000076c1d9dd6f39  pop rsi
000076c1d9dd6f3a  pop rdi
000076c1d9dd6f3b  pop rdx
000076c1d9dd6f3c  pop rcx
000076c1d9dd6f3d  pop rax
000076c1d9dd6f3e  add rsp, 0x08
000076c1d9dd6f42  jmp 0x000076C1D9DD5A88
000076c1d9dd6f47  sub rsp, 0x08
000076c1d9dd6f4b  push rax
000076c1d9dd6f4c  push rcx
000076c1d9dd6f4d  push rdx
000076c1d9dd6f4e  push rdi
000076c1d9dd6f4f  push rsi
000076c1d9dd6f50  push r8
000076c1d9dd6f52  push r9
000076c1d9dd6f54  push r10
000076c1d9dd6f56  push r11
000076c1d9dd6f58  sub rsp, 0xF0
000076c1d9dd6f5f  vmovaps [rsp], xmm0
000076c1d9dd6f64  vmovaps [rsp+0x10], xmm1
000076c1d9dd6f6a  vmovaps [rsp+0x20], xmm2
000076c1d9dd6f70  vmovaps [rsp+0x30], xmm3
000076c1d9dd6f76  vmovaps [rsp+0x40], xmm4
000076c1d9dd6f7c  vmovaps [rsp+0x50], xmm6
000076c1d9dd6f82  vmovaps [rsp+0x60], xmm7
000076c1d9dd6f88  vmovaps [rsp+0x70], xmm8
000076c1d9dd6f8e  vmovaps [rsp+0x80], xmm9
000076c1d9dd6f97  vmovaps [rsp+0x90], xmm10
000076c1d9dd6fa0  vmovaps [rsp+0xA0], xmm11
000076c1d9dd6fa9  vmovaps [rsp+0xB0], xmm12
000076c1d9dd6fb2  vmovaps [rsp+0xC0], xmm13
000076c1d9dd6fbb  vmovaps [rsp+0xD0], xmm14
000076c1d9dd6fc4  vmovaps [rsp+0xE0], xmm15
000076c1d9dd6fcd  sub rsp, 0x30
000076c1d9dd6fd1  movaps [rsp], xmm5
000076c1d9dd6fd5  movaps [rsp+0x10], xmm8
000076c1d9dd6fdb  movaps [rsp+0x20], xmm15
000076c1d9dd6fe1  lea rdi, [rsp]
000076c1d9dd6fe5  mov esi, 0x00
000076c1d9dd6fea  mov rax, 0x5EA58B9E0530
000076c1d9dd6ff4  call rax
000076c1d9dd6ff6  movaps xmm5, [rsp]
000076c1d9dd6ffa  add rsp, 0x30
000076c1d9dd6ffe  vmovaps xmm0, [rsp]
000076c1d9dd7003  vmovaps xmm1, [rsp+0x10]
000076c1d9dd7009  vmovaps xmm2, [rsp+0x20]
000076c1d9dd700f  vmovaps xmm3, [rsp+0x30]
000076c1d9dd7015  vmovaps xmm4, [rsp+0x40]
000076c1d9dd701b  vmovaps xmm6, [rsp+0x50]
000076c1d9dd7021  vmovaps xmm7, [rsp+0x60]
000076c1d9dd7027  vmovaps xmm8, [rsp+0x70]
000076c1d9dd702d  vmovaps xmm9, [rsp+0x80]
000076c1d9dd7036  vmovaps xmm10, [rsp+0x90]
000076c1d9dd703f  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd7048  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd7051  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd705a  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd7063  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd706c  add rsp, 0xF0
000076c1d9dd7073  pop r11
000076c1d9dd7075  pop r10
000076c1d9dd7077  pop r9
000076c1d9dd7079  pop r8
000076c1d9dd707b  pop rsi
000076c1d9dd707c  pop rdi
000076c1d9dd707d  pop rdx
000076c1d9dd707e  pop rcx
000076c1d9dd707f  pop rax
000076c1d9dd7080  add rsp, 0x08
000076c1d9dd7084  jmp 0x000076C1D9DD5AC0
000076c1d9dd7089  sub rsp, 0x08
000076c1d9dd708d  push rax
000076c1d9dd708e  push rcx
000076c1d9dd708f  push rdx
000076c1d9dd7090  push rdi
000076c1d9dd7091  push rsi
000076c1d9dd7092  push r8
000076c1d9dd7094  push r9
000076c1d9dd7096  push r10
000076c1d9dd7098  push r11
000076c1d9dd709a  sub rsp, 0xF0
000076c1d9dd70a1  vmovaps [rsp], xmm0
000076c1d9dd70a6  vmovaps [rsp+0x10], xmm1
000076c1d9dd70ac  vmovaps [rsp+0x20], xmm2
000076c1d9dd70b2  vmovaps [rsp+0x30], xmm3
000076c1d9dd70b8  vmovaps [rsp+0x40], xmm5
000076c1d9dd70be  vmovaps [rsp+0x50], xmm6
000076c1d9dd70c4  vmovaps [rsp+0x60], xmm7
000076c1d9dd70ca  vmovaps [rsp+0x70], xmm8
000076c1d9dd70d0  vmovaps [rsp+0x80], xmm9
000076c1d9dd70d9  vmovaps [rsp+0x90], xmm10
000076c1d9dd70e2  vmovaps [rsp+0xA0], xmm11
000076c1d9dd70eb  vmovaps [rsp+0xB0], xmm12
000076c1d9dd70f4  vmovaps [rsp+0xC0], xmm13
000076c1d9dd70fd  vmovaps [rsp+0xD0], xmm14
000076c1d9dd7106  vmovaps [rsp+0xE0], xmm15
000076c1d9dd710f  sub rsp, 0x30
000076c1d9dd7113  movaps [rsp], xmm4
000076c1d9dd7117  movaps [rsp+0x10], xmm9
000076c1d9dd711d  movaps [rsp+0x20], xmm8
000076c1d9dd7123  lea rdi, [rsp]
000076c1d9dd7127  mov esi, 0x00
000076c1d9dd712c  mov rax, 0x5EA58B9E0530
000076c1d9dd7136  call rax
000076c1d9dd7138  movaps xmm4, [rsp]
000076c1d9dd713c  add rsp, 0x30
000076c1d9dd7140  vmovaps xmm0, [rsp]
000076c1d9dd7145  vmovaps xmm1, [rsp+0x10]
000076c1d9dd714b  vmovaps xmm2, [rsp+0x20]
000076c1d9dd7151  vmovaps xmm3, [rsp+0x30]
000076c1d9dd7157  vmovaps xmm5, [rsp+0x40]
000076c1d9dd715d  vmovaps xmm6, [rsp+0x50]
000076c1d9dd7163  vmovaps xmm7, [rsp+0x60]
000076c1d9dd7169  vmovaps xmm8, [rsp+0x70]
000076c1d9dd716f  vmovaps xmm9, [rsp+0x80]
000076c1d9dd7178  vmovaps xmm10, [rsp+0x90]
000076c1d9dd7181  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd718a  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd7193  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd719c  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd71a5  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd71ae  add rsp, 0xF0
000076c1d9dd71b5  pop r11
000076c1d9dd71b7  pop r10
000076c1d9dd71b9  pop r9
000076c1d9dd71bb  pop r8
000076c1d9dd71bd  pop rsi
000076c1d9dd71be  pop rdi
000076c1d9dd71bf  pop rdx
000076c1d9dd71c0  pop rcx
000076c1d9dd71c1  pop rax
000076c1d9dd71c2  add rsp, 0x08
000076c1d9dd71c6  jmp 0x000076C1D9DD5AE1
000076c1d9dd71cb  sub rsp, 0x08
000076c1d9dd71cf  push rax
000076c1d9dd71d0  push rcx
000076c1d9dd71d1  push rdx
000076c1d9dd71d2  push rdi
000076c1d9dd71d3  push rsi
000076c1d9dd71d4  push r8
000076c1d9dd71d6  push r9
000076c1d9dd71d8  push r10
000076c1d9dd71da  push r11
000076c1d9dd71dc  sub rsp, 0xF0
000076c1d9dd71e3  vmovaps [rsp], xmm0
000076c1d9dd71e8  vmovaps [rsp+0x10], xmm1
000076c1d9dd71ee  vmovaps [rsp+0x20], xmm2
000076c1d9dd71f4  vmovaps [rsp+0x30], xmm3
000076c1d9dd71fa  vmovaps [rsp+0x40], xmm4
000076c1d9dd7200  vmovaps [rsp+0x50], xmm5
000076c1d9dd7206  vmovaps [rsp+0x60], xmm6
000076c1d9dd720c  vmovaps [rsp+0x70], xmm7
000076c1d9dd7212  vmovaps [rsp+0x80], xmm8
000076c1d9dd721b  vmovaps [rsp+0x90], xmm10
000076c1d9dd7224  vmovaps [rsp+0xA0], xmm11
000076c1d9dd722d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd7236  vmovaps [rsp+0xC0], xmm13
000076c1d9dd723f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd7248  vmovaps [rsp+0xE0], xmm15
000076c1d9dd7251  sub rsp, 0x30
000076c1d9dd7255  movaps [rsp], xmm9
000076c1d9dd725a  movaps [rsp+0x10], xmm10
000076c1d9dd7260  movaps [rsp+0x20], xmm8
000076c1d9dd7266  lea rdi, [rsp]
000076c1d9dd726a  mov esi, 0x00
000076c1d9dd726f  mov rax, 0x5EA58B9E0530
000076c1d9dd7279  call rax
000076c1d9dd727b  movaps xmm9, [rsp]
000076c1d9dd7280  add rsp, 0x30
000076c1d9dd7284  vmovaps xmm0, [rsp]
000076c1d9dd7289  vmovaps xmm1, [rsp+0x10]
000076c1d9dd728f  vmovaps xmm2, [rsp+0x20]
000076c1d9dd7295  vmovaps xmm3, [rsp+0x30]
000076c1d9dd729b  vmovaps xmm4, [rsp+0x40]
000076c1d9dd72a1  vmovaps xmm5, [rsp+0x50]
000076c1d9dd72a7  vmovaps xmm6, [rsp+0x60]
000076c1d9dd72ad  vmovaps xmm7, [rsp+0x70]
000076c1d9dd72b3  vmovaps xmm8, [rsp+0x80]
000076c1d9dd72bc  vmovaps xmm10, [rsp+0x90]
000076c1d9dd72c5  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd72ce  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd72d7  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd72e0  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd72e9  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd72f2  add rsp, 0xF0
000076c1d9dd72f9  pop r11
000076c1d9dd72fb  pop r10
000076c1d9dd72fd  pop r9
000076c1d9dd72ff  pop r8
000076c1d9dd7301  pop rsi
000076c1d9dd7302  pop rdi
000076c1d9dd7303  pop rdx
000076c1d9dd7304  pop rcx
000076c1d9dd7305  pop rax
000076c1d9dd7306  add rsp, 0x08
000076c1d9dd730a  jmp 0x000076C1D9DD5AFB
000076c1d9dd730f  call 0x000076C1D9CD64F0
000076c1d9dd7314  jmp 0x000076C1D9DD5C15
000076c1d9dd7319  call 0x000076C1D9CD64F0
000076c1d9dd731e  jmp 0x000076C1D9DD5C2B
000076c1d9dd7323  sub rsp, 0x08
000076c1d9dd7327  push rax
000076c1d9dd7328  push rcx
000076c1d9dd7329  push rdx
000076c1d9dd732a  push rdi
000076c1d9dd732b  push rsi
000076c1d9dd732c  push r8
000076c1d9dd732e  push r9
000076c1d9dd7330  push r10
000076c1d9dd7332  push r11
000076c1d9dd7334  sub rsp, 0xF0
000076c1d9dd733b  vmovaps [rsp], xmm0
000076c1d9dd7340  vmovaps [rsp+0x10], xmm2
000076c1d9dd7346  vmovaps [rsp+0x20], xmm3
000076c1d9dd734c  vmovaps [rsp+0x30], xmm4
000076c1d9dd7352  vmovaps [rsp+0x40], xmm5
000076c1d9dd7358  vmovaps [rsp+0x50], xmm6
000076c1d9dd735e  vmovaps [rsp+0x60], xmm7
000076c1d9dd7364  vmovaps [rsp+0x70], xmm8
000076c1d9dd736a  vmovaps [rsp+0x80], xmm9
000076c1d9dd7373  vmovaps [rsp+0x90], xmm10
000076c1d9dd737c  vmovaps [rsp+0xA0], xmm11
000076c1d9dd7385  vmovaps [rsp+0xB0], xmm12
000076c1d9dd738e  vmovaps [rsp+0xC0], xmm13
000076c1d9dd7397  vmovaps [rsp+0xD0], xmm14
000076c1d9dd73a0  vmovaps [rsp+0xE0], xmm15
000076c1d9dd73a9  sub rsp, 0x30
000076c1d9dd73ad  movaps [rsp], xmm1
000076c1d9dd73b1  movaps [rsp+0x10], xmm6
000076c1d9dd73b6  movaps [rsp+0x20], xmm15
000076c1d9dd73bc  lea rdi, [rsp]
000076c1d9dd73c0  mov esi, 0x00
000076c1d9dd73c5  mov rax, 0x5EA58B9E0530
000076c1d9dd73cf  call rax
000076c1d9dd73d1  movaps xmm1, [rsp]
000076c1d9dd73d5  add rsp, 0x30
000076c1d9dd73d9  vmovaps xmm0, [rsp]
000076c1d9dd73de  vmovaps xmm2, [rsp+0x10]
000076c1d9dd73e4  vmovaps xmm3, [rsp+0x20]
000076c1d9dd73ea  vmovaps xmm4, [rsp+0x30]
000076c1d9dd73f0  vmovaps xmm5, [rsp+0x40]
000076c1d9dd73f6  vmovaps xmm6, [rsp+0x50]
000076c1d9dd73fc  vmovaps xmm7, [rsp+0x60]
000076c1d9dd7402  vmovaps xmm8, [rsp+0x70]
000076c1d9dd7408  vmovaps xmm9, [rsp+0x80]
000076c1d9dd7411  vmovaps xmm10, [rsp+0x90]
000076c1d9dd741a  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd7423  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd742c  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd7435  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd743e  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd7447  add rsp, 0xF0
000076c1d9dd744e  pop r11
000076c1d9dd7450  pop r10
000076c1d9dd7452  pop r9
000076c1d9dd7454  pop r8
000076c1d9dd7456  pop rsi
000076c1d9dd7457  pop rdi
000076c1d9dd7458  pop rdx
000076c1d9dd7459  pop rcx
000076c1d9dd745a  pop rax
000076c1d9dd745b  add rsp, 0x08
000076c1d9dd745f  jmp 0x000076C1D9DD5C68
000076c1d9dd7464  call 0x000076C1D9CE5820
000076c1d9dd7469  jmp 0x000076C1D9DD5C75
000076c1d9dd746e  sub rsp, 0x08
000076c1d9dd7472  push rax
000076c1d9dd7473  push rcx
000076c1d9dd7474  push rdx
000076c1d9dd7475  push rdi
000076c1d9dd7476  push rsi
000076c1d9dd7477  push r8
000076c1d9dd7479  push r9
000076c1d9dd747b  push r10
000076c1d9dd747d  push r11
000076c1d9dd747f  sub rsp, 0xF0
000076c1d9dd7486  vmovaps [rsp], xmm0
000076c1d9dd748b  vmovaps [rsp+0x10], xmm1
000076c1d9dd7491  vmovaps [rsp+0x20], xmm2
000076c1d9dd7497  vmovaps [rsp+0x30], xmm3
000076c1d9dd749d  vmovaps [rsp+0x40], xmm4
000076c1d9dd74a3  vmovaps [rsp+0x50], xmm5
000076c1d9dd74a9  vmovaps [rsp+0x60], xmm6
000076c1d9dd74af  vmovaps [rsp+0x70], xmm7
000076c1d9dd74b5  vmovaps [rsp+0x80], xmm8
000076c1d9dd74be  vmovaps [rsp+0x90], xmm9
000076c1d9dd74c7  vmovaps [rsp+0xA0], xmm10
000076c1d9dd74d0  vmovaps [rsp+0xB0], xmm11
000076c1d9dd74d9  vmovaps [rsp+0xC0], xmm12
000076c1d9dd74e2  vmovaps [rsp+0xD0], xmm13
000076c1d9dd74eb  vmovaps [rsp+0xE0], xmm15
000076c1d9dd74f4  sub rsp, 0x30
000076c1d9dd74f8  movaps [rsp], xmm14
000076c1d9dd74fd  movaps [rsp+0x10], xmm4
000076c1d9dd7502  movaps [rsp+0x20], xmm3
000076c1d9dd7507  lea rdi, [rsp]
000076c1d9dd750b  mov esi, 0x00
000076c1d9dd7510  mov rax, 0x5EA58B9E0530
000076c1d9dd751a  call rax
000076c1d9dd751c  movaps xmm14, [rsp]
000076c1d9dd7521  add rsp, 0x30
000076c1d9dd7525  vmovaps xmm0, [rsp]
000076c1d9dd752a  vmovaps xmm1, [rsp+0x10]
000076c1d9dd7530  vmovaps xmm2, [rsp+0x20]
000076c1d9dd7536  vmovaps xmm3, [rsp+0x30]
000076c1d9dd753c  vmovaps xmm4, [rsp+0x40]
000076c1d9dd7542  vmovaps xmm5, [rsp+0x50]
000076c1d9dd7548  vmovaps xmm6, [rsp+0x60]
000076c1d9dd754e  vmovaps xmm7, [rsp+0x70]
000076c1d9dd7554  vmovaps xmm8, [rsp+0x80]
000076c1d9dd755d  vmovaps xmm9, [rsp+0x90]
000076c1d9dd7566  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd756f  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd7578  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd7581  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd758a  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd7593  add rsp, 0xF0
000076c1d9dd759a  pop r11
000076c1d9dd759c  pop r10
000076c1d9dd759e  pop r9
000076c1d9dd75a0  pop r8
000076c1d9dd75a2  pop rsi
000076c1d9dd75a3  pop rdi
000076c1d9dd75a4  pop rdx
000076c1d9dd75a5  pop rcx
000076c1d9dd75a6  pop rax
000076c1d9dd75a7  add rsp, 0x08
000076c1d9dd75ab  jmp 0x000076C1D9DD5C8F
000076c1d9dd75b0  sub rsp, 0x08
000076c1d9dd75b4  push rax
000076c1d9dd75b5  push rcx
000076c1d9dd75b6  push rdx
000076c1d9dd75b7  push rdi
000076c1d9dd75b8  push rsi
000076c1d9dd75b9  push r8
000076c1d9dd75bb  push r9
000076c1d9dd75bd  push r10
000076c1d9dd75bf  push r11
000076c1d9dd75c1  sub rsp, 0xF0
000076c1d9dd75c8  vmovaps [rsp], xmm0
000076c1d9dd75cd  vmovaps [rsp+0x10], xmm1
000076c1d9dd75d3  vmovaps [rsp+0x20], xmm2
000076c1d9dd75d9  vmovaps [rsp+0x30], xmm3
000076c1d9dd75df  vmovaps [rsp+0x40], xmm4
000076c1d9dd75e5  vmovaps [rsp+0x50], xmm5
000076c1d9dd75eb  vmovaps [rsp+0x60], xmm7
000076c1d9dd75f1  vmovaps [rsp+0x70], xmm8
000076c1d9dd75f7  vmovaps [rsp+0x80], xmm9
000076c1d9dd7600  vmovaps [rsp+0x90], xmm10
000076c1d9dd7609  vmovaps [rsp+0xA0], xmm11
000076c1d9dd7612  vmovaps [rsp+0xB0], xmm12
000076c1d9dd761b  vmovaps [rsp+0xC0], xmm13
000076c1d9dd7624  vmovaps [rsp+0xD0], xmm14
000076c1d9dd762d  vmovaps [rsp+0xE0], xmm15
000076c1d9dd7636  sub rsp, 0x30
000076c1d9dd763a  movaps [rsp], xmm6
000076c1d9dd763e  movaps [rsp+0x10], xmm9
000076c1d9dd7644  movaps [rsp+0x20], xmm7
000076c1d9dd7649  lea rdi, [rsp]
000076c1d9dd764d  mov esi, 0x00
000076c1d9dd7652  mov rax, 0x5EA58B9E0530
000076c1d9dd765c  call rax
000076c1d9dd765e  movaps xmm6, [rsp]
000076c1d9dd7662  add rsp, 0x30
000076c1d9dd7666  vmovaps xmm0, [rsp]
000076c1d9dd766b  vmovaps xmm1, [rsp+0x10]
000076c1d9dd7671  vmovaps xmm2, [rsp+0x20]
000076c1d9dd7677  vmovaps xmm3, [rsp+0x30]
000076c1d9dd767d  vmovaps xmm4, [rsp+0x40]
000076c1d9dd7683  vmovaps xmm5, [rsp+0x50]
000076c1d9dd7689  vmovaps xmm7, [rsp+0x60]
000076c1d9dd768f  vmovaps xmm8, [rsp+0x70]
000076c1d9dd7695  vmovaps xmm9, [rsp+0x80]
000076c1d9dd769e  vmovaps xmm10, [rsp+0x90]
000076c1d9dd76a7  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd76b0  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd76b9  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd76c2  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd76cb  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd76d4  add rsp, 0xF0
000076c1d9dd76db  pop r11
000076c1d9dd76dd  pop r10
000076c1d9dd76df  pop r9
000076c1d9dd76e1  pop r8
000076c1d9dd76e3  pop rsi
000076c1d9dd76e4  pop rdi
000076c1d9dd76e5  pop rdx
000076c1d9dd76e6  pop rcx
000076c1d9dd76e7  pop rax
000076c1d9dd76e8  add rsp, 0x08
000076c1d9dd76ec  jmp 0x000076C1D9DD5CA7
000076c1d9dd76f1  sub rsp, 0x08
000076c1d9dd76f5  push rax
000076c1d9dd76f6  push rcx
000076c1d9dd76f7  push rdx
000076c1d9dd76f8  push rdi
000076c1d9dd76f9  push rsi
000076c1d9dd76fa  push r8
000076c1d9dd76fc  push r9
000076c1d9dd76fe  push r10
000076c1d9dd7700  push r11
000076c1d9dd7702  sub rsp, 0xF0
000076c1d9dd7709  vmovaps [rsp], xmm0
000076c1d9dd770e  vmovaps [rsp+0x10], xmm1
000076c1d9dd7714  vmovaps [rsp+0x20], xmm2
000076c1d9dd771a  vmovaps [rsp+0x30], xmm3
000076c1d9dd7720  vmovaps [rsp+0x40], xmm4
000076c1d9dd7726  vmovaps [rsp+0x50], xmm5
000076c1d9dd772c  vmovaps [rsp+0x60], xmm6
000076c1d9dd7732  vmovaps [rsp+0x70], xmm8
000076c1d9dd7738  vmovaps [rsp+0x80], xmm9
000076c1d9dd7741  vmovaps [rsp+0x90], xmm10
000076c1d9dd774a  vmovaps [rsp+0xA0], xmm11
000076c1d9dd7753  vmovaps [rsp+0xB0], xmm12
000076c1d9dd775c  vmovaps [rsp+0xC0], xmm13
000076c1d9dd7765  vmovaps [rsp+0xD0], xmm14
000076c1d9dd776e  vmovaps [rsp+0xE0], xmm15
000076c1d9dd7777  sub rsp, 0x30
000076c1d9dd777b  movaps [rsp], xmm7
000076c1d9dd777f  movaps [rsp+0x10], xmm4
000076c1d9dd7784  movaps [rsp+0x20], xmm9
000076c1d9dd778a  lea rdi, [rsp]
000076c1d9dd778e  mov esi, 0x00
000076c1d9dd7793  mov rax, 0x5EA58B9E0530
000076c1d9dd779d  call rax
000076c1d9dd779f  movaps xmm7, [rsp]
000076c1d9dd77a3  add rsp, 0x30
000076c1d9dd77a7  vmovaps xmm0, [rsp]
000076c1d9dd77ac  vmovaps xmm1, [rsp+0x10]
000076c1d9dd77b2  vmovaps xmm2, [rsp+0x20]
000076c1d9dd77b8  vmovaps xmm3, [rsp+0x30]
000076c1d9dd77be  vmovaps xmm4, [rsp+0x40]
000076c1d9dd77c4  vmovaps xmm5, [rsp+0x50]
000076c1d9dd77ca  vmovaps xmm6, [rsp+0x60]
000076c1d9dd77d0  vmovaps xmm8, [rsp+0x70]
000076c1d9dd77d6  vmovaps xmm9, [rsp+0x80]
000076c1d9dd77df  vmovaps xmm10, [rsp+0x90]
000076c1d9dd77e8  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd77f1  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd77fa  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd7803  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd780c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd7815  add rsp, 0xF0
000076c1d9dd781c  pop r11
000076c1d9dd781e  pop r10
000076c1d9dd7820  pop r9
000076c1d9dd7822  pop r8
000076c1d9dd7824  pop rsi
000076c1d9dd7825  pop rdi
000076c1d9dd7826  pop rdx
000076c1d9dd7827  pop rcx
000076c1d9dd7828  pop rax
000076c1d9dd7829  add rsp, 0x08
000076c1d9dd782d  jmp 0x000076C1D9DD5CD4
000076c1d9dd7832  sub rsp, 0x08
000076c1d9dd7836  push rax
000076c1d9dd7837  push rcx
000076c1d9dd7838  push rdx
000076c1d9dd7839  push rdi
000076c1d9dd783a  push rsi
000076c1d9dd783b  push r8
000076c1d9dd783d  push r9
000076c1d9dd783f  push r10
000076c1d9dd7841  push r11
000076c1d9dd7843  sub rsp, 0xF0
000076c1d9dd784a  vmovaps [rsp], xmm0
000076c1d9dd784f  vmovaps [rsp+0x10], xmm1
000076c1d9dd7855  vmovaps [rsp+0x20], xmm2
000076c1d9dd785b  vmovaps [rsp+0x30], xmm3
000076c1d9dd7861  vmovaps [rsp+0x40], xmm5
000076c1d9dd7867  vmovaps [rsp+0x50], xmm6
000076c1d9dd786d  vmovaps [rsp+0x60], xmm7
000076c1d9dd7873  vmovaps [rsp+0x70], xmm8
000076c1d9dd7879  vmovaps [rsp+0x80], xmm9
000076c1d9dd7882  vmovaps [rsp+0x90], xmm10
000076c1d9dd788b  vmovaps [rsp+0xA0], xmm11
000076c1d9dd7894  vmovaps [rsp+0xB0], xmm12
000076c1d9dd789d  vmovaps [rsp+0xC0], xmm13
000076c1d9dd78a6  vmovaps [rsp+0xD0], xmm14
000076c1d9dd78af  vmovaps [rsp+0xE0], xmm15
000076c1d9dd78b8  sub rsp, 0x30
000076c1d9dd78bc  movaps [rsp], xmm4
000076c1d9dd78c0  movaps [rsp+0x10], xmm15
000076c1d9dd78c6  movaps [rsp+0x20], xmm9
000076c1d9dd78cc  lea rdi, [rsp]
000076c1d9dd78d0  mov esi, 0x00
000076c1d9dd78d5  mov rax, 0x5EA58B9E0530
000076c1d9dd78df  call rax
000076c1d9dd78e1  movaps xmm4, [rsp]
000076c1d9dd78e5  add rsp, 0x30
000076c1d9dd78e9  vmovaps xmm0, [rsp]
000076c1d9dd78ee  vmovaps xmm1, [rsp+0x10]
000076c1d9dd78f4  vmovaps xmm2, [rsp+0x20]
000076c1d9dd78fa  vmovaps xmm3, [rsp+0x30]
000076c1d9dd7900  vmovaps xmm5, [rsp+0x40]
000076c1d9dd7906  vmovaps xmm6, [rsp+0x50]
000076c1d9dd790c  vmovaps xmm7, [rsp+0x60]
000076c1d9dd7912  vmovaps xmm8, [rsp+0x70]
000076c1d9dd7918  vmovaps xmm9, [rsp+0x80]
000076c1d9dd7921  vmovaps xmm10, [rsp+0x90]
000076c1d9dd792a  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd7933  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd793c  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd7945  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd794e  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd7957  add rsp, 0xF0
000076c1d9dd795e  pop r11
000076c1d9dd7960  pop r10
000076c1d9dd7962  pop r9
000076c1d9dd7964  pop r8
000076c1d9dd7966  pop rsi
000076c1d9dd7967  pop rdi
000076c1d9dd7968  pop rdx
000076c1d9dd7969  pop rcx
000076c1d9dd796a  pop rax
000076c1d9dd796b  add rsp, 0x08
000076c1d9dd796f  jmp 0x000076C1D9DD5CF9
000076c1d9dd7974  call 0x000076C1D9CE5820
000076c1d9dd7979  jmp 0x000076C1D9DD5D06
000076c1d9dd797e  sub rsp, 0x08
000076c1d9dd7982  push rax
000076c1d9dd7983  push rcx
000076c1d9dd7984  push rdx
000076c1d9dd7985  push rdi
000076c1d9dd7986  push rsi
000076c1d9dd7987  push r8
000076c1d9dd7989  push r9
000076c1d9dd798b  push r10
000076c1d9dd798d  push r11
000076c1d9dd798f  sub rsp, 0xF0
000076c1d9dd7996  vmovaps [rsp], xmm0
000076c1d9dd799b  vmovaps [rsp+0x10], xmm1
000076c1d9dd79a1  vmovaps [rsp+0x20], xmm2
000076c1d9dd79a7  vmovaps [rsp+0x30], xmm4
000076c1d9dd79ad  vmovaps [rsp+0x40], xmm5
000076c1d9dd79b3  vmovaps [rsp+0x50], xmm6
000076c1d9dd79b9  vmovaps [rsp+0x60], xmm7
000076c1d9dd79bf  vmovaps [rsp+0x70], xmm8
000076c1d9dd79c5  vmovaps [rsp+0x80], xmm9
000076c1d9dd79ce  vmovaps [rsp+0x90], xmm10
000076c1d9dd79d7  vmovaps [rsp+0xA0], xmm11
000076c1d9dd79e0  vmovaps [rsp+0xB0], xmm12
000076c1d9dd79e9  vmovaps [rsp+0xC0], xmm13
000076c1d9dd79f2  vmovaps [rsp+0xD0], xmm14
000076c1d9dd79fb  vmovaps [rsp+0xE0], xmm15
000076c1d9dd7a04  sub rsp, 0x30
000076c1d9dd7a08  movaps [rsp], xmm3
000076c1d9dd7a0c  movaps [rsp+0x10], xmm1
000076c1d9dd7a11  movaps [rsp+0x20], xmm9
000076c1d9dd7a17  lea rdi, [rsp]
000076c1d9dd7a1b  mov esi, 0x00
000076c1d9dd7a20  mov rax, 0x5EA58B9E0530
000076c1d9dd7a2a  call rax
000076c1d9dd7a2c  movaps xmm3, [rsp]
000076c1d9dd7a30  add rsp, 0x30
000076c1d9dd7a34  vmovaps xmm0, [rsp]
000076c1d9dd7a39  vmovaps xmm1, [rsp+0x10]
000076c1d9dd7a3f  vmovaps xmm2, [rsp+0x20]
000076c1d9dd7a45  vmovaps xmm4, [rsp+0x30]
000076c1d9dd7a4b  vmovaps xmm5, [rsp+0x40]
000076c1d9dd7a51  vmovaps xmm6, [rsp+0x50]
000076c1d9dd7a57  vmovaps xmm7, [rsp+0x60]
000076c1d9dd7a5d  vmovaps xmm8, [rsp+0x70]
000076c1d9dd7a63  vmovaps xmm9, [rsp+0x80]
000076c1d9dd7a6c  vmovaps xmm10, [rsp+0x90]
000076c1d9dd7a75  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd7a7e  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd7a87  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd7a90  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd7a99  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd7aa2  add rsp, 0xF0
000076c1d9dd7aa9  pop r11
000076c1d9dd7aab  pop r10
000076c1d9dd7aad  pop r9
000076c1d9dd7aaf  pop r8
000076c1d9dd7ab1  pop rsi
000076c1d9dd7ab2  pop rdi
000076c1d9dd7ab3  pop rdx
000076c1d9dd7ab4  pop rcx
000076c1d9dd7ab5  pop rax
000076c1d9dd7ab6  add rsp, 0x08
000076c1d9dd7aba  jmp 0x000076C1D9DD5D43
000076c1d9dd7abf  sub rsp, 0x08
000076c1d9dd7ac3  push rax
000076c1d9dd7ac4  push rcx
000076c1d9dd7ac5  push rdx
000076c1d9dd7ac6  push rdi
000076c1d9dd7ac7  push rsi
000076c1d9dd7ac8  push r8
000076c1d9dd7aca  push r9
000076c1d9dd7acc  push r10
000076c1d9dd7ace  push r11
000076c1d9dd7ad0  sub rsp, 0xF0
000076c1d9dd7ad7  vmovaps [rsp], xmm0
000076c1d9dd7adc  vmovaps [rsp+0x10], xmm2
000076c1d9dd7ae2  vmovaps [rsp+0x20], xmm3
000076c1d9dd7ae8  vmovaps [rsp+0x30], xmm4
000076c1d9dd7aee  vmovaps [rsp+0x40], xmm5
000076c1d9dd7af4  vmovaps [rsp+0x50], xmm6
000076c1d9dd7afa  vmovaps [rsp+0x60], xmm7
000076c1d9dd7b00  vmovaps [rsp+0x70], xmm8
000076c1d9dd7b06  vmovaps [rsp+0x80], xmm9
000076c1d9dd7b0f  vmovaps [rsp+0x90], xmm10
000076c1d9dd7b18  vmovaps [rsp+0xA0], xmm11
000076c1d9dd7b21  vmovaps [rsp+0xB0], xmm12
000076c1d9dd7b2a  vmovaps [rsp+0xC0], xmm13
000076c1d9dd7b33  vmovaps [rsp+0xD0], xmm14
000076c1d9dd7b3c  vmovaps [rsp+0xE0], xmm15
000076c1d9dd7b45  sub rsp, 0x30
000076c1d9dd7b49  movaps [rsp], xmm1
000076c1d9dd7b4d  movaps [rsp+0x10], xmm15
000076c1d9dd7b53  movaps [rsp+0x20], xmm9
000076c1d9dd7b59  lea rdi, [rsp]
000076c1d9dd7b5d  mov esi, 0x00
000076c1d9dd7b62  mov rax, 0x5EA58B9E0530
000076c1d9dd7b6c  call rax
000076c1d9dd7b6e  movaps xmm1, [rsp]
000076c1d9dd7b72  add rsp, 0x30
000076c1d9dd7b76  vmovaps xmm0, [rsp]
000076c1d9dd7b7b  vmovaps xmm2, [rsp+0x10]
000076c1d9dd7b81  vmovaps xmm3, [rsp+0x20]
000076c1d9dd7b87  vmovaps xmm4, [rsp+0x30]
000076c1d9dd7b8d  vmovaps xmm5, [rsp+0x40]
000076c1d9dd7b93  vmovaps xmm6, [rsp+0x50]
000076c1d9dd7b99  vmovaps xmm7, [rsp+0x60]
000076c1d9dd7b9f  vmovaps xmm8, [rsp+0x70]
000076c1d9dd7ba5  vmovaps xmm9, [rsp+0x80]
000076c1d9dd7bae  vmovaps xmm10, [rsp+0x90]
000076c1d9dd7bb7  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd7bc0  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd7bc9  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd7bd2  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd7bdb  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd7be4  add rsp, 0xF0
000076c1d9dd7beb  pop r11
000076c1d9dd7bed  pop r10
000076c1d9dd7bef  pop r9
000076c1d9dd7bf1  pop r8
000076c1d9dd7bf3  pop rsi
000076c1d9dd7bf4  pop rdi
000076c1d9dd7bf5  pop rdx
000076c1d9dd7bf6  pop rcx
000076c1d9dd7bf7  pop rax
000076c1d9dd7bf8  add rsp, 0x08
000076c1d9dd7bfc  jmp 0x000076C1D9DD5DCB
000076c1d9dd7c01  call 0x000076C1D9CE5820
000076c1d9dd7c06  jmp 0x000076C1D9DD5DD8
000076c1d9dd7c0b  sub rsp, 0x08
000076c1d9dd7c0f  push rax
000076c1d9dd7c10  push rcx
000076c1d9dd7c11  push rdx
000076c1d9dd7c12  push rdi
000076c1d9dd7c13  push rsi
000076c1d9dd7c14  push r8
000076c1d9dd7c16  push r9
000076c1d9dd7c18  push r10
000076c1d9dd7c1a  push r11
000076c1d9dd7c1c  sub rsp, 0xF0
000076c1d9dd7c23  vmovaps [rsp], xmm0
000076c1d9dd7c28  vmovaps [rsp+0x10], xmm2
000076c1d9dd7c2e  vmovaps [rsp+0x20], xmm3
000076c1d9dd7c34  vmovaps [rsp+0x30], xmm4
000076c1d9dd7c3a  vmovaps [rsp+0x40], xmm5
000076c1d9dd7c40  vmovaps [rsp+0x50], xmm6
000076c1d9dd7c46  vmovaps [rsp+0x60], xmm7
000076c1d9dd7c4c  vmovaps [rsp+0x70], xmm8
000076c1d9dd7c52  vmovaps [rsp+0x80], xmm9
000076c1d9dd7c5b  vmovaps [rsp+0x90], xmm10
000076c1d9dd7c64  vmovaps [rsp+0xA0], xmm11
000076c1d9dd7c6d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd7c76  vmovaps [rsp+0xC0], xmm13
000076c1d9dd7c7f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd7c88  vmovaps [rsp+0xE0], xmm15
000076c1d9dd7c91  sub rsp, 0x30
000076c1d9dd7c95  movaps [rsp], xmm1
000076c1d9dd7c99  movaps [rsp+0x10], xmm5
000076c1d9dd7c9e  movaps [rsp+0x20], xmm7
000076c1d9dd7ca3  lea rdi, [rsp]
000076c1d9dd7ca7  mov esi, 0x00
000076c1d9dd7cac  mov rax, 0x5EA58B9E0530
000076c1d9dd7cb6  call rax
000076c1d9dd7cb8  movaps xmm1, [rsp]
000076c1d9dd7cbc  add rsp, 0x30
000076c1d9dd7cc0  vmovaps xmm0, [rsp]
000076c1d9dd7cc5  vmovaps xmm2, [rsp+0x10]
000076c1d9dd7ccb  vmovaps xmm3, [rsp+0x20]
000076c1d9dd7cd1  vmovaps xmm4, [rsp+0x30]
000076c1d9dd7cd7  vmovaps xmm5, [rsp+0x40]
000076c1d9dd7cdd  vmovaps xmm6, [rsp+0x50]
000076c1d9dd7ce3  vmovaps xmm7, [rsp+0x60]
000076c1d9dd7ce9  vmovaps xmm8, [rsp+0x70]
000076c1d9dd7cef  vmovaps xmm9, [rsp+0x80]
000076c1d9dd7cf8  vmovaps xmm10, [rsp+0x90]
000076c1d9dd7d01  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd7d0a  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd7d13  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd7d1c  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd7d25  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd7d2e  add rsp, 0xF0
000076c1d9dd7d35  pop r11
000076c1d9dd7d37  pop r10
000076c1d9dd7d39  pop r9
000076c1d9dd7d3b  pop r8
000076c1d9dd7d3d  pop rsi
000076c1d9dd7d3e  pop rdi
000076c1d9dd7d3f  pop rdx
000076c1d9dd7d40  pop rcx
000076c1d9dd7d41  pop rax
000076c1d9dd7d42  add rsp, 0x08
000076c1d9dd7d46  jmp 0x000076C1D9DD5E7D
000076c1d9dd7d4b  sub rsp, 0x08
000076c1d9dd7d4f  push rax
000076c1d9dd7d50  push rcx
000076c1d9dd7d51  push rdx
000076c1d9dd7d52  push rdi
000076c1d9dd7d53  push rsi
000076c1d9dd7d54  push r8
000076c1d9dd7d56  push r9
000076c1d9dd7d58  push r10
000076c1d9dd7d5a  push r11
000076c1d9dd7d5c  sub rsp, 0xF0
000076c1d9dd7d63  vmovaps [rsp], xmm0
000076c1d9dd7d68  vmovaps [rsp+0x10], xmm1
000076c1d9dd7d6e  vmovaps [rsp+0x20], xmm2
000076c1d9dd7d74  vmovaps [rsp+0x30], xmm3
000076c1d9dd7d7a  vmovaps [rsp+0x40], xmm4
000076c1d9dd7d80  vmovaps [rsp+0x50], xmm5
000076c1d9dd7d86  vmovaps [rsp+0x60], xmm6
000076c1d9dd7d8c  vmovaps [rsp+0x70], xmm8
000076c1d9dd7d92  vmovaps [rsp+0x80], xmm9
000076c1d9dd7d9b  vmovaps [rsp+0x90], xmm10
000076c1d9dd7da4  vmovaps [rsp+0xA0], xmm11
000076c1d9dd7dad  vmovaps [rsp+0xB0], xmm12
000076c1d9dd7db6  vmovaps [rsp+0xC0], xmm13
000076c1d9dd7dbf  vmovaps [rsp+0xD0], xmm14
000076c1d9dd7dc8  vmovaps [rsp+0xE0], xmm15
000076c1d9dd7dd1  sub rsp, 0x30
000076c1d9dd7dd5  movaps [rsp], xmm7
000076c1d9dd7dd9  movaps [rsp+0x10], xmm5
000076c1d9dd7dde  movaps [rsp+0x20], xmm15
000076c1d9dd7de4  lea rdi, [rsp]
000076c1d9dd7de8  mov esi, 0x00
000076c1d9dd7ded  mov rax, 0x5EA58B9E0530
000076c1d9dd7df7  call rax
000076c1d9dd7df9  movaps xmm7, [rsp]
000076c1d9dd7dfd  add rsp, 0x30
000076c1d9dd7e01  vmovaps xmm0, [rsp]
000076c1d9dd7e06  vmovaps xmm1, [rsp+0x10]
000076c1d9dd7e0c  vmovaps xmm2, [rsp+0x20]
000076c1d9dd7e12  vmovaps xmm3, [rsp+0x30]
000076c1d9dd7e18  vmovaps xmm4, [rsp+0x40]
000076c1d9dd7e1e  vmovaps xmm5, [rsp+0x50]
000076c1d9dd7e24  vmovaps xmm6, [rsp+0x60]
000076c1d9dd7e2a  vmovaps xmm8, [rsp+0x70]
000076c1d9dd7e30  vmovaps xmm9, [rsp+0x80]
000076c1d9dd7e39  vmovaps xmm10, [rsp+0x90]
000076c1d9dd7e42  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd7e4b  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd7e54  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd7e5d  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd7e66  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd7e6f  add rsp, 0xF0
000076c1d9dd7e76  pop r11
000076c1d9dd7e78  pop r10
000076c1d9dd7e7a  pop r9
000076c1d9dd7e7c  pop r8
000076c1d9dd7e7e  pop rsi
000076c1d9dd7e7f  pop rdi
000076c1d9dd7e80  pop rdx
000076c1d9dd7e81  pop rcx
000076c1d9dd7e82  pop rax
000076c1d9dd7e83  add rsp, 0x08
000076c1d9dd7e87  jmp 0x000076C1D9DD5EB3
000076c1d9dd7e8c  call 0x000076C1D9CD64F0
000076c1d9dd7e91  jmp 0x000076C1D9DD5EC0
000076c1d9dd7e96  sub rsp, 0x08
000076c1d9dd7e9a  push rax
000076c1d9dd7e9b  push rcx
000076c1d9dd7e9c  push rdx
000076c1d9dd7e9d  push rdi
000076c1d9dd7e9e  push rsi
000076c1d9dd7e9f  push r8
000076c1d9dd7ea1  push r9
000076c1d9dd7ea3  push r10
000076c1d9dd7ea5  push r11
000076c1d9dd7ea7  sub rsp, 0xF0
000076c1d9dd7eae  vmovaps [rsp], xmm0
000076c1d9dd7eb3  vmovaps [rsp+0x10], xmm1
000076c1d9dd7eb9  vmovaps [rsp+0x20], xmm2
000076c1d9dd7ebf  vmovaps [rsp+0x30], xmm3
000076c1d9dd7ec5  vmovaps [rsp+0x40], xmm4
000076c1d9dd7ecb  vmovaps [rsp+0x50], xmm5
000076c1d9dd7ed1  vmovaps [rsp+0x60], xmm6
000076c1d9dd7ed7  vmovaps [rsp+0x70], xmm7
000076c1d9dd7edd  vmovaps [rsp+0x80], xmm8
000076c1d9dd7ee6  vmovaps [rsp+0x90], xmm9
000076c1d9dd7eef  vmovaps [rsp+0xA0], xmm10
000076c1d9dd7ef8  vmovaps [rsp+0xB0], xmm11
000076c1d9dd7f01  vmovaps [rsp+0xC0], xmm12
000076c1d9dd7f0a  vmovaps [rsp+0xD0], xmm13
000076c1d9dd7f13  vmovaps [rsp+0xE0], xmm14
000076c1d9dd7f1c  sub rsp, 0x30
000076c1d9dd7f20  movaps [rsp], xmm15
000076c1d9dd7f25  movaps [rsp+0x10], xmm5
000076c1d9dd7f2a  movaps [rsp+0x20], xmm3
000076c1d9dd7f2f  lea rdi, [rsp]
000076c1d9dd7f33  mov esi, 0x00
000076c1d9dd7f38  mov rax, 0x5EA58B9E0530
000076c1d9dd7f42  call rax
000076c1d9dd7f44  movaps xmm15, [rsp]
000076c1d9dd7f49  add rsp, 0x30
000076c1d9dd7f4d  vmovaps xmm0, [rsp]
000076c1d9dd7f52  vmovaps xmm1, [rsp+0x10]
000076c1d9dd7f58  vmovaps xmm2, [rsp+0x20]
000076c1d9dd7f5e  vmovaps xmm3, [rsp+0x30]
000076c1d9dd7f64  vmovaps xmm4, [rsp+0x40]
000076c1d9dd7f6a  vmovaps xmm5, [rsp+0x50]
000076c1d9dd7f70  vmovaps xmm6, [rsp+0x60]
000076c1d9dd7f76  vmovaps xmm7, [rsp+0x70]
000076c1d9dd7f7c  vmovaps xmm8, [rsp+0x80]
000076c1d9dd7f85  vmovaps xmm9, [rsp+0x90]
000076c1d9dd7f8e  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd7f97  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd7fa0  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd7fa9  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd7fb2  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd7fbb  add rsp, 0xF0
000076c1d9dd7fc2  pop r11
000076c1d9dd7fc4  pop r10
000076c1d9dd7fc6  pop r9
000076c1d9dd7fc8  pop r8
000076c1d9dd7fca  pop rsi
000076c1d9dd7fcb  pop rdi
000076c1d9dd7fcc  pop rdx
000076c1d9dd7fcd  pop rcx
000076c1d9dd7fce  pop rax
000076c1d9dd7fcf  add rsp, 0x08
000076c1d9dd7fd3  jmp 0x000076C1D9DD5EE6
000076c1d9dd7fd8  sub rsp, 0x08
000076c1d9dd7fdc  push rax
000076c1d9dd7fdd  push rcx
000076c1d9dd7fde  push rdx
000076c1d9dd7fdf  push rdi
000076c1d9dd7fe0  push rsi
000076c1d9dd7fe1  push r8
000076c1d9dd7fe3  push r9
000076c1d9dd7fe5  push r10
000076c1d9dd7fe7  push r11
000076c1d9dd7fe9  sub rsp, 0xF0
000076c1d9dd7ff0  vmovaps [rsp], xmm0
000076c1d9dd7ff5  vmovaps [rsp+0x10], xmm2
000076c1d9dd7ffb  vmovaps [rsp+0x20], xmm3
000076c1d9dd8001  vmovaps [rsp+0x30], xmm4
000076c1d9dd8007  vmovaps [rsp+0x40], xmm5
000076c1d9dd800d  vmovaps [rsp+0x50], xmm6
000076c1d9dd8013  vmovaps [rsp+0x60], xmm7
000076c1d9dd8019  vmovaps [rsp+0x70], xmm8
000076c1d9dd801f  vmovaps [rsp+0x80], xmm9
000076c1d9dd8028  vmovaps [rsp+0x90], xmm10
000076c1d9dd8031  vmovaps [rsp+0xA0], xmm11
000076c1d9dd803a  vmovaps [rsp+0xB0], xmm12
000076c1d9dd8043  vmovaps [rsp+0xC0], xmm13
000076c1d9dd804c  vmovaps [rsp+0xD0], xmm14
000076c1d9dd8055  vmovaps [rsp+0xE0], xmm15
000076c1d9dd805e  sub rsp, 0x30
000076c1d9dd8062  movaps [rsp], xmm1
000076c1d9dd8066  movaps [rsp+0x10], xmm5
000076c1d9dd806b  movaps [rsp+0x20], xmm4
000076c1d9dd8070  lea rdi, [rsp]
000076c1d9dd8074  mov esi, 0x00
000076c1d9dd8079  mov rax, 0x5EA58B9E0530
000076c1d9dd8083  call rax
000076c1d9dd8085  movaps xmm1, [rsp]
000076c1d9dd8089  add rsp, 0x30
000076c1d9dd808d  vmovaps xmm0, [rsp]
000076c1d9dd8092  vmovaps xmm2, [rsp+0x10]
000076c1d9dd8098  vmovaps xmm3, [rsp+0x20]
000076c1d9dd809e  vmovaps xmm4, [rsp+0x30]
000076c1d9dd80a4  vmovaps xmm5, [rsp+0x40]
000076c1d9dd80aa  vmovaps xmm6, [rsp+0x50]
000076c1d9dd80b0  vmovaps xmm7, [rsp+0x60]
000076c1d9dd80b6  vmovaps xmm8, [rsp+0x70]
000076c1d9dd80bc  vmovaps xmm9, [rsp+0x80]
000076c1d9dd80c5  vmovaps xmm10, [rsp+0x90]
000076c1d9dd80ce  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd80d7  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd80e0  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd80e9  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd80f2  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd80fb  add rsp, 0xF0
000076c1d9dd8102  pop r11
000076c1d9dd8104  pop r10
000076c1d9dd8106  pop r9
000076c1d9dd8108  pop r8
000076c1d9dd810a  pop rsi
000076c1d9dd810b  pop rdi
000076c1d9dd810c  pop rdx
000076c1d9dd810d  pop rcx
000076c1d9dd810e  pop rax
000076c1d9dd810f  add rsp, 0x08
000076c1d9dd8113  jmp 0x000076C1D9DD5F06
000076c1d9dd8118  sub rsp, 0x08
000076c1d9dd811c  push rax
000076c1d9dd811d  push rcx
000076c1d9dd811e  push rdx
000076c1d9dd811f  push rdi
000076c1d9dd8120  push rsi
000076c1d9dd8121  push r8
000076c1d9dd8123  push r9
000076c1d9dd8125  push r10
000076c1d9dd8127  push r11
000076c1d9dd8129  sub rsp, 0xF0
000076c1d9dd8130  vmovaps [rsp], xmm0
000076c1d9dd8135  vmovaps [rsp+0x10], xmm1
000076c1d9dd813b  vmovaps [rsp+0x20], xmm2
000076c1d9dd8141  vmovaps [rsp+0x30], xmm3
000076c1d9dd8147  vmovaps [rsp+0x40], xmm5
000076c1d9dd814d  vmovaps [rsp+0x50], xmm6
000076c1d9dd8153  vmovaps [rsp+0x60], xmm7
000076c1d9dd8159  vmovaps [rsp+0x70], xmm8
000076c1d9dd815f  vmovaps [rsp+0x80], xmm9
000076c1d9dd8168  vmovaps [rsp+0x90], xmm10
000076c1d9dd8171  vmovaps [rsp+0xA0], xmm11
000076c1d9dd817a  vmovaps [rsp+0xB0], xmm12
000076c1d9dd8183  vmovaps [rsp+0xC0], xmm13
000076c1d9dd818c  vmovaps [rsp+0xD0], xmm14
000076c1d9dd8195  vmovaps [rsp+0xE0], xmm15
000076c1d9dd819e  sub rsp, 0x30
000076c1d9dd81a2  movaps [rsp], xmm4
000076c1d9dd81a6  movaps [rsp+0x10], xmm3
000076c1d9dd81ab  movaps [rsp+0x20], xmm5
000076c1d9dd81b0  lea rdi, [rsp]
000076c1d9dd81b4  mov esi, 0x00
000076c1d9dd81b9  mov rax, 0x5EA58B9E0530
000076c1d9dd81c3  call rax
000076c1d9dd81c5  movaps xmm4, [rsp]
000076c1d9dd81c9  add rsp, 0x30
000076c1d9dd81cd  vmovaps xmm0, [rsp]
000076c1d9dd81d2  vmovaps xmm1, [rsp+0x10]
000076c1d9dd81d8  vmovaps xmm2, [rsp+0x20]
000076c1d9dd81de  vmovaps xmm3, [rsp+0x30]
000076c1d9dd81e4  vmovaps xmm5, [rsp+0x40]
000076c1d9dd81ea  vmovaps xmm6, [rsp+0x50]
000076c1d9dd81f0  vmovaps xmm7, [rsp+0x60]
000076c1d9dd81f6  vmovaps xmm8, [rsp+0x70]
000076c1d9dd81fc  vmovaps xmm9, [rsp+0x80]
000076c1d9dd8205  vmovaps xmm10, [rsp+0x90]
000076c1d9dd820e  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd8217  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd8220  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd8229  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd8232  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd823b  add rsp, 0xF0
000076c1d9dd8242  pop r11
000076c1d9dd8244  pop r10
000076c1d9dd8246  pop r9
000076c1d9dd8248  pop r8
000076c1d9dd824a  pop rsi
000076c1d9dd824b  pop rdi
000076c1d9dd824c  pop rdx
000076c1d9dd824d  pop rcx
000076c1d9dd824e  pop rax
000076c1d9dd824f  add rsp, 0x08
000076c1d9dd8253  jmp 0x000076C1D9DD5F54
000076c1d9dd8258  call 0x000076C1D9CD64F0
000076c1d9dd825d  jmp 0x000076C1D9DD5F61
000076c1d9dd8262  sub rsp, 0x08
000076c1d9dd8266  push rax
000076c1d9dd8267  push rcx
000076c1d9dd8268  push rdx
000076c1d9dd8269  push rdi
000076c1d9dd826a  push rsi
000076c1d9dd826b  push r8
000076c1d9dd826d  push r9
000076c1d9dd826f  push r10
000076c1d9dd8271  push r11
000076c1d9dd8273  sub rsp, 0xF0
000076c1d9dd827a  vmovaps [rsp], xmm0
000076c1d9dd827f  vmovaps [rsp+0x10], xmm1
000076c1d9dd8285  vmovaps [rsp+0x20], xmm2
000076c1d9dd828b  vmovaps [rsp+0x30], xmm3
000076c1d9dd8291  vmovaps [rsp+0x40], xmm4
000076c1d9dd8297  vmovaps [rsp+0x50], xmm6
000076c1d9dd829d  vmovaps [rsp+0x60], xmm7
000076c1d9dd82a3  vmovaps [rsp+0x70], xmm8
000076c1d9dd82a9  vmovaps [rsp+0x80], xmm9
000076c1d9dd82b2  vmovaps [rsp+0x90], xmm10
000076c1d9dd82bb  vmovaps [rsp+0xA0], xmm11
000076c1d9dd82c4  vmovaps [rsp+0xB0], xmm12
000076c1d9dd82cd  vmovaps [rsp+0xC0], xmm13
000076c1d9dd82d6  vmovaps [rsp+0xD0], xmm14
000076c1d9dd82df  vmovaps [rsp+0xE0], xmm15
000076c1d9dd82e8  sub rsp, 0x30
000076c1d9dd82ec  movaps [rsp], xmm5
000076c1d9dd82f0  movaps [rsp+0x10], xmm6
000076c1d9dd82f5  movaps [rsp+0x20], xmm3
000076c1d9dd82fa  lea rdi, [rsp]
000076c1d9dd82fe  mov esi, 0x00
000076c1d9dd8303  mov rax, 0x5EA58B9E0530
000076c1d9dd830d  call rax
000076c1d9dd830f  movaps xmm5, [rsp]
000076c1d9dd8313  add rsp, 0x30
000076c1d9dd8317  vmovaps xmm0, [rsp]
000076c1d9dd831c  vmovaps xmm1, [rsp+0x10]
000076c1d9dd8322  vmovaps xmm2, [rsp+0x20]
000076c1d9dd8328  vmovaps xmm3, [rsp+0x30]
000076c1d9dd832e  vmovaps xmm4, [rsp+0x40]
000076c1d9dd8334  vmovaps xmm6, [rsp+0x50]
000076c1d9dd833a  vmovaps xmm7, [rsp+0x60]
000076c1d9dd8340  vmovaps xmm8, [rsp+0x70]
000076c1d9dd8346  vmovaps xmm9, [rsp+0x80]
000076c1d9dd834f  vmovaps xmm10, [rsp+0x90]
000076c1d9dd8358  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd8361  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd836a  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd8373  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd837c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd8385  add rsp, 0xF0
000076c1d9dd838c  pop r11
000076c1d9dd838e  pop r10
000076c1d9dd8390  pop r9
000076c1d9dd8392  pop r8
000076c1d9dd8394  pop rsi
000076c1d9dd8395  pop rdi
000076c1d9dd8396  pop rdx
000076c1d9dd8397  pop rcx
000076c1d9dd8398  pop rax
000076c1d9dd8399  add rsp, 0x08
000076c1d9dd839d  jmp 0x000076C1D9DD5F87
000076c1d9dd83a2  sub rsp, 0x08
000076c1d9dd83a6  push rax
000076c1d9dd83a7  push rcx
000076c1d9dd83a8  push rdx
000076c1d9dd83a9  push rdi
000076c1d9dd83aa  push rsi
000076c1d9dd83ab  push r8
000076c1d9dd83ad  push r9
000076c1d9dd83af  push r10
000076c1d9dd83b1  push r11
000076c1d9dd83b3  sub rsp, 0xF0
000076c1d9dd83ba  vmovaps [rsp], xmm0
000076c1d9dd83bf  vmovaps [rsp+0x10], xmm1
000076c1d9dd83c5  vmovaps [rsp+0x20], xmm2
000076c1d9dd83cb  vmovaps [rsp+0x30], xmm3
000076c1d9dd83d1  vmovaps [rsp+0x40], xmm4
000076c1d9dd83d7  vmovaps [rsp+0x50], xmm5
000076c1d9dd83dd  vmovaps [rsp+0x60], xmm7
000076c1d9dd83e3  vmovaps [rsp+0x70], xmm8
000076c1d9dd83e9  vmovaps [rsp+0x80], xmm9
000076c1d9dd83f2  vmovaps [rsp+0x90], xmm10
000076c1d9dd83fb  vmovaps [rsp+0xA0], xmm11
000076c1d9dd8404  vmovaps [rsp+0xB0], xmm12
000076c1d9dd840d  vmovaps [rsp+0xC0], xmm13
000076c1d9dd8416  vmovaps [rsp+0xD0], xmm14
000076c1d9dd841f  vmovaps [rsp+0xE0], xmm15
000076c1d9dd8428  sub rsp, 0x30
000076c1d9dd842c  movaps [rsp], xmm6
000076c1d9dd8430  movaps [rsp+0x10], xmm9
000076c1d9dd8436  movaps [rsp+0x20], xmm1
000076c1d9dd843b  lea rdi, [rsp]
000076c1d9dd843f  mov esi, 0x00
000076c1d9dd8444  mov rax, 0x5EA58B9E0530
000076c1d9dd844e  call rax
000076c1d9dd8450  movaps xmm6, [rsp]
000076c1d9dd8454  add rsp, 0x30
000076c1d9dd8458  vmovaps xmm0, [rsp]
000076c1d9dd845d  vmovaps xmm1, [rsp+0x10]
000076c1d9dd8463  vmovaps xmm2, [rsp+0x20]
000076c1d9dd8469  vmovaps xmm3, [rsp+0x30]
000076c1d9dd846f  vmovaps xmm4, [rsp+0x40]
000076c1d9dd8475  vmovaps xmm5, [rsp+0x50]
000076c1d9dd847b  vmovaps xmm7, [rsp+0x60]
000076c1d9dd8481  vmovaps xmm8, [rsp+0x70]
000076c1d9dd8487  vmovaps xmm9, [rsp+0x80]
000076c1d9dd8490  vmovaps xmm10, [rsp+0x90]
000076c1d9dd8499  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd84a2  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd84ab  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd84b4  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd84bd  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd84c6  add rsp, 0xF0
000076c1d9dd84cd  pop r11
000076c1d9dd84cf  pop r10
000076c1d9dd84d1  pop r9
000076c1d9dd84d3  pop r8
000076c1d9dd84d5  pop rsi
000076c1d9dd84d6  pop rdi
000076c1d9dd84d7  pop rdx
000076c1d9dd84d8  pop rcx
000076c1d9dd84d9  pop rax
000076c1d9dd84da  add rsp, 0x08
000076c1d9dd84de  jmp 0x000076C1D9DD5FAB
000076c1d9dd84e3  sub rsp, 0x08
000076c1d9dd84e7  push rax
000076c1d9dd84e8  push rcx
000076c1d9dd84e9  push rdx
000076c1d9dd84ea  push rdi
000076c1d9dd84eb  push rsi
000076c1d9dd84ec  push r8
000076c1d9dd84ee  push r9
000076c1d9dd84f0  push r10
000076c1d9dd84f2  push r11
000076c1d9dd84f4  sub rsp, 0xF0
000076c1d9dd84fb  vmovaps [rsp], xmm0
000076c1d9dd8500  vmovaps [rsp+0x10], xmm1
000076c1d9dd8506  vmovaps [rsp+0x20], xmm2
000076c1d9dd850c  vmovaps [rsp+0x30], xmm3
000076c1d9dd8512  vmovaps [rsp+0x40], xmm4
000076c1d9dd8518  vmovaps [rsp+0x50], xmm5
000076c1d9dd851e  vmovaps [rsp+0x60], xmm6
000076c1d9dd8524  vmovaps [rsp+0x70], xmm7
000076c1d9dd852a  vmovaps [rsp+0x80], xmm8
000076c1d9dd8533  vmovaps [rsp+0x90], xmm10
000076c1d9dd853c  vmovaps [rsp+0xA0], xmm11
000076c1d9dd8545  vmovaps [rsp+0xB0], xmm12
000076c1d9dd854e  vmovaps [rsp+0xC0], xmm13
000076c1d9dd8557  vmovaps [rsp+0xD0], xmm14
000076c1d9dd8560  vmovaps [rsp+0xE0], xmm15
000076c1d9dd8569  sub rsp, 0x30
000076c1d9dd856d  movaps [rsp], xmm9
000076c1d9dd8572  movaps [rsp+0x10], xmm3
000076c1d9dd8577  movaps [rsp+0x20], xmm1
000076c1d9dd857c  lea rdi, [rsp]
000076c1d9dd8580  mov esi, 0x00
000076c1d9dd8585  mov rax, 0x5EA58B9E0530
000076c1d9dd858f  call rax
000076c1d9dd8591  movaps xmm9, [rsp]
000076c1d9dd8596  add rsp, 0x30
000076c1d9dd859a  vmovaps xmm0, [rsp]
000076c1d9dd859f  vmovaps xmm1, [rsp+0x10]
000076c1d9dd85a5  vmovaps xmm2, [rsp+0x20]
000076c1d9dd85ab  vmovaps xmm3, [rsp+0x30]
000076c1d9dd85b1  vmovaps xmm4, [rsp+0x40]
000076c1d9dd85b7  vmovaps xmm5, [rsp+0x50]
000076c1d9dd85bd  vmovaps xmm6, [rsp+0x60]
000076c1d9dd85c3  vmovaps xmm7, [rsp+0x70]
000076c1d9dd85c9  vmovaps xmm8, [rsp+0x80]
000076c1d9dd85d2  vmovaps xmm10, [rsp+0x90]
000076c1d9dd85db  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd85e4  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd85ed  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd85f6  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd85ff  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd8608  add rsp, 0xF0
000076c1d9dd860f  pop r11
000076c1d9dd8611  pop r10
000076c1d9dd8613  pop r9
000076c1d9dd8615  pop r8
000076c1d9dd8617  pop rsi
000076c1d9dd8618  pop rdi
000076c1d9dd8619  pop rdx
000076c1d9dd861a  pop rcx
000076c1d9dd861b  pop rax
000076c1d9dd861c  add rsp, 0x08
000076c1d9dd8620  jmp 0x000076C1D9DD5FF7
000076c1d9dd8625  call 0x000076C1D9CD64F0
000076c1d9dd862a  jmp 0x000076C1D9DD6004
000076c1d9dd862f  sub rsp, 0x08
000076c1d9dd8633  push rax
000076c1d9dd8634  push rcx
000076c1d9dd8635  push rdx
000076c1d9dd8636  push rdi
000076c1d9dd8637  push rsi
000076c1d9dd8638  push r8
000076c1d9dd863a  push r9
000076c1d9dd863c  push r10
000076c1d9dd863e  push r11
000076c1d9dd8640  sub rsp, 0xF0
000076c1d9dd8647  vmovaps [rsp], xmm0
000076c1d9dd864c  vmovaps [rsp+0x10], xmm1
000076c1d9dd8652  vmovaps [rsp+0x20], xmm2
000076c1d9dd8658  vmovaps [rsp+0x30], xmm3
000076c1d9dd865e  vmovaps [rsp+0x40], xmm4
000076c1d9dd8664  vmovaps [rsp+0x50], xmm5
000076c1d9dd866a  vmovaps [rsp+0x60], xmm6
000076c1d9dd8670  vmovaps [rsp+0x70], xmm7
000076c1d9dd8676  vmovaps [rsp+0x80], xmm8
000076c1d9dd867f  vmovaps [rsp+0x90], xmm9
000076c1d9dd8688  vmovaps [rsp+0xA0], xmm10
000076c1d9dd8691  vmovaps [rsp+0xB0], xmm11
000076c1d9dd869a  vmovaps [rsp+0xC0], xmm12
000076c1d9dd86a3  vmovaps [rsp+0xD0], xmm13
000076c1d9dd86ac  vmovaps [rsp+0xE0], xmm14
000076c1d9dd86b5  sub rsp, 0x30
000076c1d9dd86b9  movaps [rsp], xmm15
000076c1d9dd86be  movaps [rsp+0x10], xmm3
000076c1d9dd86c3  movaps [rsp+0x20], xmm7
000076c1d9dd86c8  lea rdi, [rsp]
000076c1d9dd86cc  mov esi, 0x00
000076c1d9dd86d1  mov rax, 0x5EA58B9E0530
000076c1d9dd86db  call rax
000076c1d9dd86dd  movaps xmm15, [rsp]
000076c1d9dd86e2  add rsp, 0x30
000076c1d9dd86e6  vmovaps xmm0, [rsp]
000076c1d9dd86eb  vmovaps xmm1, [rsp+0x10]
000076c1d9dd86f1  vmovaps xmm2, [rsp+0x20]
000076c1d9dd86f7  vmovaps xmm3, [rsp+0x30]
000076c1d9dd86fd  vmovaps xmm4, [rsp+0x40]
000076c1d9dd8703  vmovaps xmm5, [rsp+0x50]
000076c1d9dd8709  vmovaps xmm6, [rsp+0x60]
000076c1d9dd870f  vmovaps xmm7, [rsp+0x70]
000076c1d9dd8715  vmovaps xmm8, [rsp+0x80]
000076c1d9dd871e  vmovaps xmm9, [rsp+0x90]
000076c1d9dd8727  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd8730  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd8739  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd8742  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd874b  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd8754  add rsp, 0xF0
000076c1d9dd875b  pop r11
000076c1d9dd875d  pop r10
000076c1d9dd875f  pop r9
000076c1d9dd8761  pop r8
000076c1d9dd8763  pop rsi
000076c1d9dd8764  pop rdi
000076c1d9dd8765  pop rdx
000076c1d9dd8766  pop rcx
000076c1d9dd8767  pop rax
000076c1d9dd8768  add rsp, 0x08
000076c1d9dd876c  jmp 0x000076C1D9DD6030
000076c1d9dd8771  sub rsp, 0x08
000076c1d9dd8775  push rax
000076c1d9dd8776  push rcx
000076c1d9dd8777  push rdx
000076c1d9dd8778  push rdi
000076c1d9dd8779  push rsi
000076c1d9dd877a  push r8
000076c1d9dd877c  push r9
000076c1d9dd877e  push r10
000076c1d9dd8780  push r11
000076c1d9dd8782  sub rsp, 0xF0
000076c1d9dd8789  vmovaps [rsp], xmm0
000076c1d9dd878e  vmovaps [rsp+0x10], xmm1
000076c1d9dd8794  vmovaps [rsp+0x20], xmm2
000076c1d9dd879a  vmovaps [rsp+0x30], xmm4
000076c1d9dd87a0  vmovaps [rsp+0x40], xmm5
000076c1d9dd87a6  vmovaps [rsp+0x50], xmm6
000076c1d9dd87ac  vmovaps [rsp+0x60], xmm7
000076c1d9dd87b2  vmovaps [rsp+0x70], xmm8
000076c1d9dd87b8  vmovaps [rsp+0x80], xmm9
000076c1d9dd87c1  vmovaps [rsp+0x90], xmm10
000076c1d9dd87ca  vmovaps [rsp+0xA0], xmm11
000076c1d9dd87d3  vmovaps [rsp+0xB0], xmm12
000076c1d9dd87dc  vmovaps [rsp+0xC0], xmm13
000076c1d9dd87e5  vmovaps [rsp+0xD0], xmm14
000076c1d9dd87ee  vmovaps [rsp+0xE0], xmm15
000076c1d9dd87f7  sub rsp, 0x30
000076c1d9dd87fb  movaps [rsp], xmm3
000076c1d9dd87ff  movaps [rsp+0x10], xmm1
000076c1d9dd8804  movaps [rsp+0x20], xmm15
000076c1d9dd880a  lea rdi, [rsp]
000076c1d9dd880e  mov esi, 0x00
000076c1d9dd8813  mov rax, 0x5EA58B9E0530
000076c1d9dd881d  call rax
000076c1d9dd881f  movaps xmm3, [rsp]
000076c1d9dd8823  add rsp, 0x30
000076c1d9dd8827  vmovaps xmm0, [rsp]
000076c1d9dd882c  vmovaps xmm1, [rsp+0x10]
000076c1d9dd8832  vmovaps xmm2, [rsp+0x20]
000076c1d9dd8838  vmovaps xmm4, [rsp+0x30]
000076c1d9dd883e  vmovaps xmm5, [rsp+0x40]
000076c1d9dd8844  vmovaps xmm6, [rsp+0x50]
000076c1d9dd884a  vmovaps xmm7, [rsp+0x60]
000076c1d9dd8850  vmovaps xmm8, [rsp+0x70]
000076c1d9dd8856  vmovaps xmm9, [rsp+0x80]
000076c1d9dd885f  vmovaps xmm10, [rsp+0x90]
000076c1d9dd8868  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd8871  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd887a  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd8883  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd888c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd8895  add rsp, 0xF0
000076c1d9dd889c  pop r11
000076c1d9dd889e  pop r10
000076c1d9dd88a0  pop r9
000076c1d9dd88a2  pop r8
000076c1d9dd88a4  pop rsi
000076c1d9dd88a5  pop rdi
000076c1d9dd88a6  pop rdx
000076c1d9dd88a7  pop rcx
000076c1d9dd88a8  pop rax
000076c1d9dd88a9  add rsp, 0x08
000076c1d9dd88ad  jmp 0x000076C1D9DD60BF
000076c1d9dd88b2  call 0x000076C1D9CD64F0
000076c1d9dd88b7  jmp 0x000076C1D9DD60C9
000076c1d9dd88bc  sub rsp, 0x08
000076c1d9dd88c0  push rax
000076c1d9dd88c1  push rcx
000076c1d9dd88c2  push rdx
000076c1d9dd88c3  push rdi
000076c1d9dd88c4  push rsi
000076c1d9dd88c5  push r8
000076c1d9dd88c7  push r9
000076c1d9dd88c9  push r10
000076c1d9dd88cb  push r11
000076c1d9dd88cd  sub rsp, 0xF0
000076c1d9dd88d4  vmovaps [rsp], xmm0
000076c1d9dd88d9  vmovaps [rsp+0x10], xmm1
000076c1d9dd88df  vmovaps [rsp+0x20], xmm2
000076c1d9dd88e5  vmovaps [rsp+0x30], xmm3
000076c1d9dd88eb  vmovaps [rsp+0x40], xmm4
000076c1d9dd88f1  vmovaps [rsp+0x50], xmm5
000076c1d9dd88f7  vmovaps [rsp+0x60], xmm6
000076c1d9dd88fd  vmovaps [rsp+0x70], xmm7
000076c1d9dd8903  vmovaps [rsp+0x80], xmm8
000076c1d9dd890c  vmovaps [rsp+0x90], xmm9
000076c1d9dd8915  vmovaps [rsp+0xA0], xmm10
000076c1d9dd891e  vmovaps [rsp+0xB0], xmm11
000076c1d9dd8927  vmovaps [rsp+0xC0], xmm12
000076c1d9dd8930  vmovaps [rsp+0xD0], xmm13
000076c1d9dd8939  vmovaps [rsp+0xE0], xmm14
000076c1d9dd8942  sub rsp, 0x30
000076c1d9dd8946  movaps [rsp], xmm15
000076c1d9dd894b  movaps [rsp+0x10], xmm14
000076c1d9dd8951  movaps [rsp+0x20], xmm4
000076c1d9dd8956  lea rdi, [rsp]
000076c1d9dd895a  mov esi, 0x00
000076c1d9dd895f  mov rax, 0x5EA58B9E0530
000076c1d9dd8969  call rax
000076c1d9dd896b  movaps xmm15, [rsp]
000076c1d9dd8970  add rsp, 0x30
000076c1d9dd8974  vmovaps xmm0, [rsp]
000076c1d9dd8979  vmovaps xmm1, [rsp+0x10]
000076c1d9dd897f  vmovaps xmm2, [rsp+0x20]
000076c1d9dd8985  vmovaps xmm3, [rsp+0x30]
000076c1d9dd898b  vmovaps xmm4, [rsp+0x40]
000076c1d9dd8991  vmovaps xmm5, [rsp+0x50]
000076c1d9dd8997  vmovaps xmm6, [rsp+0x60]
000076c1d9dd899d  vmovaps xmm7, [rsp+0x70]
000076c1d9dd89a3  vmovaps xmm8, [rsp+0x80]
000076c1d9dd89ac  vmovaps xmm9, [rsp+0x90]
000076c1d9dd89b5  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd89be  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd89c7  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd89d0  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd89d9  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd89e2  add rsp, 0xF0
000076c1d9dd89e9  pop r11
000076c1d9dd89eb  pop r10
000076c1d9dd89ed  pop r9
000076c1d9dd89ef  pop r8
000076c1d9dd89f1  pop rsi
000076c1d9dd89f2  pop rdi
000076c1d9dd89f3  pop rdx
000076c1d9dd89f4  pop rcx
000076c1d9dd89f5  pop rax
000076c1d9dd89f6  add rsp, 0x08
000076c1d9dd89fa  jmp 0x000076C1D9DD60F7
000076c1d9dd89ff  sub rsp, 0x08
000076c1d9dd8a03  push rax
000076c1d9dd8a04  push rcx
000076c1d9dd8a05  push rdx
000076c1d9dd8a06  push rdi
000076c1d9dd8a07  push rsi
000076c1d9dd8a08  push r8
000076c1d9dd8a0a  push r9
000076c1d9dd8a0c  push r10
000076c1d9dd8a0e  push r11
000076c1d9dd8a10  sub rsp, 0xF0
000076c1d9dd8a17  vmovaps [rsp], xmm0
000076c1d9dd8a1c  vmovaps [rsp+0x10], xmm1
000076c1d9dd8a22  vmovaps [rsp+0x20], xmm2
000076c1d9dd8a28  vmovaps [rsp+0x30], xmm3
000076c1d9dd8a2e  vmovaps [rsp+0x40], xmm4
000076c1d9dd8a34  vmovaps [rsp+0x50], xmm5
000076c1d9dd8a3a  vmovaps [rsp+0x60], xmm6
000076c1d9dd8a40  vmovaps [rsp+0x70], xmm7
000076c1d9dd8a46  vmovaps [rsp+0x80], xmm8
000076c1d9dd8a4f  vmovaps [rsp+0x90], xmm9
000076c1d9dd8a58  vmovaps [rsp+0xA0], xmm10
000076c1d9dd8a61  vmovaps [rsp+0xB0], xmm11
000076c1d9dd8a6a  vmovaps [rsp+0xC0], xmm12
000076c1d9dd8a73  vmovaps [rsp+0xD0], xmm13
000076c1d9dd8a7c  vmovaps [rsp+0xE0], xmm15
000076c1d9dd8a85  sub rsp, 0x30
000076c1d9dd8a89  movaps [rsp], xmm14
000076c1d9dd8a8e  movaps [rsp+0x10], xmm2
000076c1d9dd8a93  movaps [rsp+0x20], xmm1
000076c1d9dd8a98  lea rdi, [rsp]
000076c1d9dd8a9c  mov esi, 0x00
000076c1d9dd8aa1  mov rax, 0x5EA58B9E0530
000076c1d9dd8aab  call rax
000076c1d9dd8aad  movaps xmm14, [rsp]
000076c1d9dd8ab2  add rsp, 0x30
000076c1d9dd8ab6  vmovaps xmm0, [rsp]
000076c1d9dd8abb  vmovaps xmm1, [rsp+0x10]
000076c1d9dd8ac1  vmovaps xmm2, [rsp+0x20]
000076c1d9dd8ac7  vmovaps xmm3, [rsp+0x30]
000076c1d9dd8acd  vmovaps xmm4, [rsp+0x40]
000076c1d9dd8ad3  vmovaps xmm5, [rsp+0x50]
000076c1d9dd8ad9  vmovaps xmm6, [rsp+0x60]
000076c1d9dd8adf  vmovaps xmm7, [rsp+0x70]
000076c1d9dd8ae5  vmovaps xmm8, [rsp+0x80]
000076c1d9dd8aee  vmovaps xmm9, [rsp+0x90]
000076c1d9dd8af7  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd8b00  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd8b09  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd8b12  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd8b1b  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd8b24  add rsp, 0xF0
000076c1d9dd8b2b  pop r11
000076c1d9dd8b2d  pop r10
000076c1d9dd8b2f  pop r9
000076c1d9dd8b31  pop r8
000076c1d9dd8b33  pop rsi
000076c1d9dd8b34  pop rdi
000076c1d9dd8b35  pop rdx
000076c1d9dd8b36  pop rcx
000076c1d9dd8b37  pop rax
000076c1d9dd8b38  add rsp, 0x08
000076c1d9dd8b3c  jmp 0x000076C1D9DD611D
000076c1d9dd8b41  sub rsp, 0x08
000076c1d9dd8b45  push rax
000076c1d9dd8b46  push rcx
000076c1d9dd8b47  push rdx
000076c1d9dd8b48  push rdi
000076c1d9dd8b49  push rsi
000076c1d9dd8b4a  push r8
000076c1d9dd8b4c  push r9
000076c1d9dd8b4e  push r10
000076c1d9dd8b50  push r11
000076c1d9dd8b52  sub rsp, 0xF0
000076c1d9dd8b59  vmovaps [rsp], xmm0
000076c1d9dd8b5e  vmovaps [rsp+0x10], xmm2
000076c1d9dd8b64  vmovaps [rsp+0x20], xmm3
000076c1d9dd8b6a  vmovaps [rsp+0x30], xmm4
000076c1d9dd8b70  vmovaps [rsp+0x40], xmm5
000076c1d9dd8b76  vmovaps [rsp+0x50], xmm6
000076c1d9dd8b7c  vmovaps [rsp+0x60], xmm7
000076c1d9dd8b82  vmovaps [rsp+0x70], xmm8
000076c1d9dd8b88  vmovaps [rsp+0x80], xmm9
000076c1d9dd8b91  vmovaps [rsp+0x90], xmm10
000076c1d9dd8b9a  vmovaps [rsp+0xA0], xmm11
000076c1d9dd8ba3  vmovaps [rsp+0xB0], xmm12
000076c1d9dd8bac  vmovaps [rsp+0xC0], xmm13
000076c1d9dd8bb5  vmovaps [rsp+0xD0], xmm14
000076c1d9dd8bbe  vmovaps [rsp+0xE0], xmm15
000076c1d9dd8bc7  sub rsp, 0x30
000076c1d9dd8bcb  movaps [rsp], xmm1
000076c1d9dd8bcf  movaps [rsp+0x10], xmm4
000076c1d9dd8bd4  movaps [rsp+0x20], xmm9
000076c1d9dd8bda  lea rdi, [rsp]
000076c1d9dd8bde  mov esi, 0x00
000076c1d9dd8be3  mov rax, 0x5EA58B9E0530
000076c1d9dd8bed  call rax
000076c1d9dd8bef  movaps xmm1, [rsp]
000076c1d9dd8bf3  add rsp, 0x30
000076c1d9dd8bf7  vmovaps xmm0, [rsp]
000076c1d9dd8bfc  vmovaps xmm2, [rsp+0x10]
000076c1d9dd8c02  vmovaps xmm3, [rsp+0x20]
000076c1d9dd8c08  vmovaps xmm4, [rsp+0x30]
000076c1d9dd8c0e  vmovaps xmm5, [rsp+0x40]
000076c1d9dd8c14  vmovaps xmm6, [rsp+0x50]
000076c1d9dd8c1a  vmovaps xmm7, [rsp+0x60]
000076c1d9dd8c20  vmovaps xmm8, [rsp+0x70]
000076c1d9dd8c26  vmovaps xmm9, [rsp+0x80]
000076c1d9dd8c2f  vmovaps xmm10, [rsp+0x90]
000076c1d9dd8c38  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd8c41  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd8c4a  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd8c53  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd8c5c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd8c65  add rsp, 0xF0
000076c1d9dd8c6c  pop r11
000076c1d9dd8c6e  pop r10
000076c1d9dd8c70  pop r9
000076c1d9dd8c72  pop r8
000076c1d9dd8c74  pop rsi
000076c1d9dd8c75  pop rdi
000076c1d9dd8c76  pop rdx
000076c1d9dd8c77  pop rcx
000076c1d9dd8c78  pop rax
000076c1d9dd8c79  add rsp, 0x08
000076c1d9dd8c7d  jmp 0x000076C1D9DD613B
000076c1d9dd8c82  sub rsp, 0x08
000076c1d9dd8c86  push rax
000076c1d9dd8c87  push rcx
000076c1d9dd8c88  push rdx
000076c1d9dd8c89  push rdi
000076c1d9dd8c8a  push rsi
000076c1d9dd8c8b  push r8
000076c1d9dd8c8d  push r9
000076c1d9dd8c8f  push r10
000076c1d9dd8c91  push r11
000076c1d9dd8c93  sub rsp, 0xF0
000076c1d9dd8c9a  vmovaps [rsp], xmm0
000076c1d9dd8c9f  vmovaps [rsp+0x10], xmm1
000076c1d9dd8ca5  vmovaps [rsp+0x20], xmm2
000076c1d9dd8cab  vmovaps [rsp+0x30], xmm3
000076c1d9dd8cb1  vmovaps [rsp+0x40], xmm5
000076c1d9dd8cb7  vmovaps [rsp+0x50], xmm6
000076c1d9dd8cbd  vmovaps [rsp+0x60], xmm7
000076c1d9dd8cc3  vmovaps [rsp+0x70], xmm8
000076c1d9dd8cc9  vmovaps [rsp+0x80], xmm9
000076c1d9dd8cd2  vmovaps [rsp+0x90], xmm10
000076c1d9dd8cdb  vmovaps [rsp+0xA0], xmm11
000076c1d9dd8ce4  vmovaps [rsp+0xB0], xmm12
000076c1d9dd8ced  vmovaps [rsp+0xC0], xmm13
000076c1d9dd8cf6  vmovaps [rsp+0xD0], xmm14
000076c1d9dd8cff  vmovaps [rsp+0xE0], xmm15
000076c1d9dd8d08  sub rsp, 0x30
000076c1d9dd8d0c  movaps [rsp], xmm4
000076c1d9dd8d10  movaps [rsp+0x10], xmm2
000076c1d9dd8d15  movaps [rsp+0x20], xmm9
000076c1d9dd8d1b  lea rdi, [rsp]
000076c1d9dd8d1f  mov esi, 0x00
000076c1d9dd8d24  mov rax, 0x5EA58B9E0530
000076c1d9dd8d2e  call rax
000076c1d9dd8d30  movaps xmm4, [rsp]
000076c1d9dd8d34  add rsp, 0x30
000076c1d9dd8d38  vmovaps xmm0, [rsp]
000076c1d9dd8d3d  vmovaps xmm1, [rsp+0x10]
000076c1d9dd8d43  vmovaps xmm2, [rsp+0x20]
000076c1d9dd8d49  vmovaps xmm3, [rsp+0x30]
000076c1d9dd8d4f  vmovaps xmm5, [rsp+0x40]
000076c1d9dd8d55  vmovaps xmm6, [rsp+0x50]
000076c1d9dd8d5b  vmovaps xmm7, [rsp+0x60]
000076c1d9dd8d61  vmovaps xmm8, [rsp+0x70]
000076c1d9dd8d67  vmovaps xmm9, [rsp+0x80]
000076c1d9dd8d70  vmovaps xmm10, [rsp+0x90]
000076c1d9dd8d79  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd8d82  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd8d8b  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd8d94  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd8d9d  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd8da6  add rsp, 0xF0
000076c1d9dd8dad  pop r11
000076c1d9dd8daf  pop r10
000076c1d9dd8db1  pop r9
000076c1d9dd8db3  pop r8
000076c1d9dd8db5  pop rsi
000076c1d9dd8db6  pop rdi
000076c1d9dd8db7  pop rdx
000076c1d9dd8db8  pop rcx
000076c1d9dd8db9  pop rax
000076c1d9dd8dba  add rsp, 0x08
000076c1d9dd8dbe  jmp 0x000076C1D9DD616B
000076c1d9dd8dc3  sub rsp, 0x08
000076c1d9dd8dc7  push rax
000076c1d9dd8dc8  push rcx
000076c1d9dd8dc9  push rdx
000076c1d9dd8dca  push rdi
000076c1d9dd8dcb  push rsi
000076c1d9dd8dcc  push r8
000076c1d9dd8dce  push r9
000076c1d9dd8dd0  push r10
000076c1d9dd8dd2  push r11
000076c1d9dd8dd4  sub rsp, 0xF0
000076c1d9dd8ddb  vmovaps [rsp], xmm0
000076c1d9dd8de0  vmovaps [rsp+0x10], xmm1
000076c1d9dd8de6  vmovaps [rsp+0x20], xmm2
000076c1d9dd8dec  vmovaps [rsp+0x30], xmm3
000076c1d9dd8df2  vmovaps [rsp+0x40], xmm4
000076c1d9dd8df8  vmovaps [rsp+0x50], xmm5
000076c1d9dd8dfe  vmovaps [rsp+0x60], xmm6
000076c1d9dd8e04  vmovaps [rsp+0x70], xmm7
000076c1d9dd8e0a  vmovaps [rsp+0x80], xmm8
000076c1d9dd8e13  vmovaps [rsp+0x90], xmm10
000076c1d9dd8e1c  vmovaps [rsp+0xA0], xmm11
000076c1d9dd8e25  vmovaps [rsp+0xB0], xmm12
000076c1d9dd8e2e  vmovaps [rsp+0xC0], xmm13
000076c1d9dd8e37  vmovaps [rsp+0xD0], xmm14
000076c1d9dd8e40  vmovaps [rsp+0xE0], xmm15
000076c1d9dd8e49  sub rsp, 0x30
000076c1d9dd8e4d  movaps [rsp], xmm9
000076c1d9dd8e52  movaps [rsp+0x10], xmm2
000076c1d9dd8e57  movaps [rsp+0x20], xmm1
000076c1d9dd8e5c  lea rdi, [rsp]
000076c1d9dd8e60  mov esi, 0x00
000076c1d9dd8e65  mov rax, 0x5EA58B9E0530
000076c1d9dd8e6f  call rax
000076c1d9dd8e71  movaps xmm9, [rsp]
000076c1d9dd8e76  add rsp, 0x30
000076c1d9dd8e7a  vmovaps xmm0, [rsp]
000076c1d9dd8e7f  vmovaps xmm1, [rsp+0x10]
000076c1d9dd8e85  vmovaps xmm2, [rsp+0x20]
000076c1d9dd8e8b  vmovaps xmm3, [rsp+0x30]
000076c1d9dd8e91  vmovaps xmm4, [rsp+0x40]
000076c1d9dd8e97  vmovaps xmm5, [rsp+0x50]
000076c1d9dd8e9d  vmovaps xmm6, [rsp+0x60]
000076c1d9dd8ea3  vmovaps xmm7, [rsp+0x70]
000076c1d9dd8ea9  vmovaps xmm8, [rsp+0x80]
000076c1d9dd8eb2  vmovaps xmm10, [rsp+0x90]
000076c1d9dd8ebb  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd8ec4  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd8ecd  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd8ed6  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd8edf  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd8ee8  add rsp, 0xF0
000076c1d9dd8eef  pop r11
000076c1d9dd8ef1  pop r10
000076c1d9dd8ef3  pop r9
000076c1d9dd8ef5  pop r8
000076c1d9dd8ef7  pop rsi
000076c1d9dd8ef8  pop rdi
000076c1d9dd8ef9  pop rdx
000076c1d9dd8efa  pop rcx
000076c1d9dd8efb  pop rax
000076c1d9dd8efc  add rsp, 0x08
000076c1d9dd8f00  jmp 0x000076C1D9DD61A1
000076c1d9dd8f05  sub rsp, 0x08
000076c1d9dd8f09  push rax
000076c1d9dd8f0a  push rcx
000076c1d9dd8f0b  push rdx
000076c1d9dd8f0c  push rdi
000076c1d9dd8f0d  push rsi
000076c1d9dd8f0e  push r8
000076c1d9dd8f10  push r9
000076c1d9dd8f12  push r10
000076c1d9dd8f14  push r11
000076c1d9dd8f16  sub rsp, 0xF0
000076c1d9dd8f1d  vmovaps [rsp], xmm0
000076c1d9dd8f22  vmovaps [rsp+0x10], xmm2
000076c1d9dd8f28  vmovaps [rsp+0x20], xmm3
000076c1d9dd8f2e  vmovaps [rsp+0x30], xmm4
000076c1d9dd8f34  vmovaps [rsp+0x40], xmm5
000076c1d9dd8f3a  vmovaps [rsp+0x50], xmm6
000076c1d9dd8f40  vmovaps [rsp+0x60], xmm7
000076c1d9dd8f46  vmovaps [rsp+0x70], xmm8
000076c1d9dd8f4c  vmovaps [rsp+0x80], xmm9
000076c1d9dd8f55  vmovaps [rsp+0x90], xmm10
000076c1d9dd8f5e  vmovaps [rsp+0xA0], xmm11
000076c1d9dd8f67  vmovaps [rsp+0xB0], xmm12
000076c1d9dd8f70  vmovaps [rsp+0xC0], xmm13
000076c1d9dd8f79  vmovaps [rsp+0xD0], xmm14
000076c1d9dd8f82  vmovaps [rsp+0xE0], xmm15
000076c1d9dd8f8b  sub rsp, 0x30
000076c1d9dd8f8f  movaps [rsp], xmm1
000076c1d9dd8f93  movaps [rsp+0x10], xmm15
000076c1d9dd8f99  movaps [rsp+0x20], xmm6
000076c1d9dd8f9e  lea rdi, [rsp]
000076c1d9dd8fa2  mov esi, 0x00
000076c1d9dd8fa7  mov rax, 0x5EA58B9E0530
000076c1d9dd8fb1  call rax
000076c1d9dd8fb3  movaps xmm1, [rsp]
000076c1d9dd8fb7  add rsp, 0x30
000076c1d9dd8fbb  vmovaps xmm0, [rsp]
000076c1d9dd8fc0  vmovaps xmm2, [rsp+0x10]
000076c1d9dd8fc6  vmovaps xmm3, [rsp+0x20]
000076c1d9dd8fcc  vmovaps xmm4, [rsp+0x30]
000076c1d9dd8fd2  vmovaps xmm5, [rsp+0x40]
000076c1d9dd8fd8  vmovaps xmm6, [rsp+0x50]
000076c1d9dd8fde  vmovaps xmm7, [rsp+0x60]
000076c1d9dd8fe4  vmovaps xmm8, [rsp+0x70]
000076c1d9dd8fea  vmovaps xmm9, [rsp+0x80]
000076c1d9dd8ff3  vmovaps xmm10, [rsp+0x90]
000076c1d9dd8ffc  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd9005  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd900e  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd9017  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd9020  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd9029  add rsp, 0xF0
000076c1d9dd9030  pop r11
000076c1d9dd9032  pop r10
000076c1d9dd9034  pop r9
000076c1d9dd9036  pop r8
000076c1d9dd9038  pop rsi
000076c1d9dd9039  pop rdi
000076c1d9dd903a  pop rdx
000076c1d9dd903b  pop rcx
000076c1d9dd903c  pop rax
000076c1d9dd903d  add rsp, 0x08
000076c1d9dd9041  jmp 0x000076C1D9DD61C2
000076c1d9dd9046  sub rsp, 0x08
000076c1d9dd904a  push rax
000076c1d9dd904b  push rcx
000076c1d9dd904c  push rdx
000076c1d9dd904d  push rdi
000076c1d9dd904e  push rsi
000076c1d9dd904f  push r8
000076c1d9dd9051  push r9
000076c1d9dd9053  push r10
000076c1d9dd9055  push r11
000076c1d9dd9057  sub rsp, 0xF0
000076c1d9dd905e  vmovaps [rsp], xmm0
000076c1d9dd9063  vmovaps [rsp+0x10], xmm1
000076c1d9dd9069  vmovaps [rsp+0x20], xmm2
000076c1d9dd906f  vmovaps [rsp+0x30], xmm3
000076c1d9dd9075  vmovaps [rsp+0x40], xmm4
000076c1d9dd907b  vmovaps [rsp+0x50], xmm5
000076c1d9dd9081  vmovaps [rsp+0x60], xmm6
000076c1d9dd9087  vmovaps [rsp+0x70], xmm7
000076c1d9dd908d  vmovaps [rsp+0x80], xmm8
000076c1d9dd9096  vmovaps [rsp+0x90], xmm9
000076c1d9dd909f  vmovaps [rsp+0xA0], xmm10
000076c1d9dd90a8  vmovaps [rsp+0xB0], xmm11
000076c1d9dd90b1  vmovaps [rsp+0xC0], xmm12
000076c1d9dd90ba  vmovaps [rsp+0xD0], xmm13
000076c1d9dd90c3  vmovaps [rsp+0xE0], xmm14
000076c1d9dd90cc  sub rsp, 0x30
000076c1d9dd90d0  movaps [rsp], xmm15
000076c1d9dd90d5  movaps [rsp+0x10], xmm5
000076c1d9dd90da  movaps [rsp+0x20], xmm3
000076c1d9dd90df  lea rdi, [rsp]
000076c1d9dd90e3  mov esi, 0x00
000076c1d9dd90e8  mov rax, 0x5EA58B9E0530
000076c1d9dd90f2  call rax
000076c1d9dd90f4  movaps xmm15, [rsp]
000076c1d9dd90f9  add rsp, 0x30
000076c1d9dd90fd  vmovaps xmm0, [rsp]
000076c1d9dd9102  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9108  vmovaps xmm2, [rsp+0x20]
000076c1d9dd910e  vmovaps xmm3, [rsp+0x30]
000076c1d9dd9114  vmovaps xmm4, [rsp+0x40]
000076c1d9dd911a  vmovaps xmm5, [rsp+0x50]
000076c1d9dd9120  vmovaps xmm6, [rsp+0x60]
000076c1d9dd9126  vmovaps xmm7, [rsp+0x70]
000076c1d9dd912c  vmovaps xmm8, [rsp+0x80]
000076c1d9dd9135  vmovaps xmm9, [rsp+0x90]
000076c1d9dd913e  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd9147  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd9150  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd9159  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd9162  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd916b  add rsp, 0xF0
000076c1d9dd9172  pop r11
000076c1d9dd9174  pop r10
000076c1d9dd9176  pop r9
000076c1d9dd9178  pop r8
000076c1d9dd917a  pop rsi
000076c1d9dd917b  pop rdi
000076c1d9dd917c  pop rdx
000076c1d9dd917d  pop rcx
000076c1d9dd917e  pop rax
000076c1d9dd917f  add rsp, 0x08
000076c1d9dd9183  jmp 0x000076C1D9DD61DC
000076c1d9dd9188  sub rsp, 0x08
000076c1d9dd918c  push rax
000076c1d9dd918d  push rcx
000076c1d9dd918e  push rdx
000076c1d9dd918f  push rdi
000076c1d9dd9190  push rsi
000076c1d9dd9191  push r8
000076c1d9dd9193  push r9
000076c1d9dd9195  push r10
000076c1d9dd9197  push r11
000076c1d9dd9199  sub rsp, 0xF0
000076c1d9dd91a0  vmovaps [rsp], xmm0
000076c1d9dd91a5  vmovaps [rsp+0x10], xmm1
000076c1d9dd91ab  vmovaps [rsp+0x20], xmm2
000076c1d9dd91b1  vmovaps [rsp+0x30], xmm3
000076c1d9dd91b7  vmovaps [rsp+0x40], xmm4
000076c1d9dd91bd  vmovaps [rsp+0x50], xmm6
000076c1d9dd91c3  vmovaps [rsp+0x60], xmm7
000076c1d9dd91c9  vmovaps [rsp+0x70], xmm8
000076c1d9dd91cf  vmovaps [rsp+0x80], xmm9
000076c1d9dd91d8  vmovaps [rsp+0x90], xmm10
000076c1d9dd91e1  vmovaps [rsp+0xA0], xmm11
000076c1d9dd91ea  vmovaps [rsp+0xB0], xmm12
000076c1d9dd91f3  vmovaps [rsp+0xC0], xmm13
000076c1d9dd91fc  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9205  vmovaps [rsp+0xE0], xmm15
000076c1d9dd920e  sub rsp, 0x30
000076c1d9dd9212  movaps [rsp], xmm5
000076c1d9dd9216  movaps [rsp+0x10], xmm8
000076c1d9dd921c  movaps [rsp+0x20], xmm6
000076c1d9dd9221  lea rdi, [rsp]
000076c1d9dd9225  mov esi, 0x00
000076c1d9dd922a  mov rax, 0x5EA58B9E0530
000076c1d9dd9234  call rax
000076c1d9dd9236  movaps xmm5, [rsp]
000076c1d9dd923a  add rsp, 0x30
000076c1d9dd923e  vmovaps xmm0, [rsp]
000076c1d9dd9243  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9249  vmovaps xmm2, [rsp+0x20]
000076c1d9dd924f  vmovaps xmm3, [rsp+0x30]
000076c1d9dd9255  vmovaps xmm4, [rsp+0x40]
000076c1d9dd925b  vmovaps xmm6, [rsp+0x50]
000076c1d9dd9261  vmovaps xmm7, [rsp+0x60]
000076c1d9dd9267  vmovaps xmm8, [rsp+0x70]
000076c1d9dd926d  vmovaps xmm9, [rsp+0x80]
000076c1d9dd9276  vmovaps xmm10, [rsp+0x90]
000076c1d9dd927f  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd9288  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd9291  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd929a  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd92a3  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd92ac  add rsp, 0xF0
000076c1d9dd92b3  pop r11
000076c1d9dd92b5  pop r10
000076c1d9dd92b7  pop r9
000076c1d9dd92b9  pop r8
000076c1d9dd92bb  pop rsi
000076c1d9dd92bc  pop rdi
000076c1d9dd92bd  pop rdx
000076c1d9dd92be  pop rcx
000076c1d9dd92bf  pop rax
000076c1d9dd92c0  add rsp, 0x08
000076c1d9dd92c4  jmp 0x000076C1D9DD6200
000076c1d9dd92c9  sub rsp, 0x08
000076c1d9dd92cd  push rax
000076c1d9dd92ce  push rcx
000076c1d9dd92cf  push rdx
000076c1d9dd92d0  push rdi
000076c1d9dd92d1  push rsi
000076c1d9dd92d2  push r8
000076c1d9dd92d4  push r9
000076c1d9dd92d6  push r10
000076c1d9dd92d8  push r11
000076c1d9dd92da  sub rsp, 0xF0
000076c1d9dd92e1  vmovaps [rsp], xmm0
000076c1d9dd92e6  vmovaps [rsp+0x10], xmm1
000076c1d9dd92ec  vmovaps [rsp+0x20], xmm2
000076c1d9dd92f2  vmovaps [rsp+0x30], xmm3
000076c1d9dd92f8  vmovaps [rsp+0x40], xmm4
000076c1d9dd92fe  vmovaps [rsp+0x50], xmm5
000076c1d9dd9304  vmovaps [rsp+0x60], xmm7
000076c1d9dd930a  vmovaps [rsp+0x70], xmm8
000076c1d9dd9310  vmovaps [rsp+0x80], xmm9
000076c1d9dd9319  vmovaps [rsp+0x90], xmm10
000076c1d9dd9322  vmovaps [rsp+0xA0], xmm11
000076c1d9dd932b  vmovaps [rsp+0xB0], xmm12
000076c1d9dd9334  vmovaps [rsp+0xC0], xmm13
000076c1d9dd933d  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9346  vmovaps [rsp+0xE0], xmm15
000076c1d9dd934f  sub rsp, 0x30
000076c1d9dd9353  movaps [rsp], xmm6
000076c1d9dd9357  movaps [rsp+0x10], xmm10
000076c1d9dd935d  movaps [rsp+0x20], xmm8
000076c1d9dd9363  lea rdi, [rsp]
000076c1d9dd9367  mov esi, 0x00
000076c1d9dd936c  mov rax, 0x5EA58B9E0530
000076c1d9dd9376  call rax
000076c1d9dd9378  movaps xmm6, [rsp]
000076c1d9dd937c  add rsp, 0x30
000076c1d9dd9380  vmovaps xmm0, [rsp]
000076c1d9dd9385  vmovaps xmm1, [rsp+0x10]
000076c1d9dd938b  vmovaps xmm2, [rsp+0x20]
000076c1d9dd9391  vmovaps xmm3, [rsp+0x30]
000076c1d9dd9397  vmovaps xmm4, [rsp+0x40]
000076c1d9dd939d  vmovaps xmm5, [rsp+0x50]
000076c1d9dd93a3  vmovaps xmm7, [rsp+0x60]
000076c1d9dd93a9  vmovaps xmm8, [rsp+0x70]
000076c1d9dd93af  vmovaps xmm9, [rsp+0x80]
000076c1d9dd93b8  vmovaps xmm10, [rsp+0x90]
000076c1d9dd93c1  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd93ca  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd93d3  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd93dc  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd93e5  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd93ee  add rsp, 0xF0
000076c1d9dd93f5  pop r11
000076c1d9dd93f7  pop r10
000076c1d9dd93f9  pop r9
000076c1d9dd93fb  pop r8
000076c1d9dd93fd  pop rsi
000076c1d9dd93fe  pop rdi
000076c1d9dd93ff  pop rdx
000076c1d9dd9400  pop rcx
000076c1d9dd9401  pop rax
000076c1d9dd9402  add rsp, 0x08
000076c1d9dd9406  jmp 0x000076C1D9DD6225
000076c1d9dd940b  sub rsp, 0x08
000076c1d9dd940f  push rax
000076c1d9dd9410  push rcx
000076c1d9dd9411  push rdx
000076c1d9dd9412  push rdi
000076c1d9dd9413  push rsi
000076c1d9dd9414  push r8
000076c1d9dd9416  push r9
000076c1d9dd9418  push r10
000076c1d9dd941a  push r11
000076c1d9dd941c  sub rsp, 0xF0
000076c1d9dd9423  vmovaps [rsp], xmm0
000076c1d9dd9428  vmovaps [rsp+0x10], xmm1
000076c1d9dd942e  vmovaps [rsp+0x20], xmm2
000076c1d9dd9434  vmovaps [rsp+0x30], xmm3
000076c1d9dd943a  vmovaps [rsp+0x40], xmm4
000076c1d9dd9440  vmovaps [rsp+0x50], xmm5
000076c1d9dd9446  vmovaps [rsp+0x60], xmm6
000076c1d9dd944c  vmovaps [rsp+0x70], xmm7
000076c1d9dd9452  vmovaps [rsp+0x80], xmm8
000076c1d9dd945b  vmovaps [rsp+0x90], xmm9
000076c1d9dd9464  vmovaps [rsp+0xA0], xmm11
000076c1d9dd946d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd9476  vmovaps [rsp+0xC0], xmm13
000076c1d9dd947f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9488  vmovaps [rsp+0xE0], xmm15
000076c1d9dd9491  sub rsp, 0x30
000076c1d9dd9495  movaps [rsp], xmm10
000076c1d9dd949a  movaps [rsp+0x10], xmm8
000076c1d9dd94a0  movaps [rsp+0x20], xmm14
000076c1d9dd94a6  lea rdi, [rsp]
000076c1d9dd94aa  mov esi, 0x00
000076c1d9dd94af  mov rax, 0x5EA58B9E0530
000076c1d9dd94b9  call rax
000076c1d9dd94bb  movaps xmm10, [rsp]
000076c1d9dd94c0  add rsp, 0x30
000076c1d9dd94c4  vmovaps xmm0, [rsp]
000076c1d9dd94c9  vmovaps xmm1, [rsp+0x10]
000076c1d9dd94cf  vmovaps xmm2, [rsp+0x20]
000076c1d9dd94d5  vmovaps xmm3, [rsp+0x30]
000076c1d9dd94db  vmovaps xmm4, [rsp+0x40]
000076c1d9dd94e1  vmovaps xmm5, [rsp+0x50]
000076c1d9dd94e7  vmovaps xmm6, [rsp+0x60]
000076c1d9dd94ed  vmovaps xmm7, [rsp+0x70]
000076c1d9dd94f3  vmovaps xmm8, [rsp+0x80]
000076c1d9dd94fc  vmovaps xmm9, [rsp+0x90]
000076c1d9dd9505  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd950e  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd9517  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd9520  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd9529  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd9532  add rsp, 0xF0
000076c1d9dd9539  pop r11
000076c1d9dd953b  pop r10
000076c1d9dd953d  pop r9
000076c1d9dd953f  pop r8
000076c1d9dd9541  pop rsi
000076c1d9dd9542  pop rdi
000076c1d9dd9543  pop rdx
000076c1d9dd9544  pop rcx
000076c1d9dd9545  pop rax
000076c1d9dd9546  add rsp, 0x08
000076c1d9dd954a  jmp 0x000076C1D9DD6245
000076c1d9dd954f  sub rsp, 0x08
000076c1d9dd9553  push rax
000076c1d9dd9554  push rcx
000076c1d9dd9555  push rdx
000076c1d9dd9556  push rdi
000076c1d9dd9557  push rsi
000076c1d9dd9558  push r8
000076c1d9dd955a  push r9
000076c1d9dd955c  push r10
000076c1d9dd955e  push r11
000076c1d9dd9560  sub rsp, 0xF0
000076c1d9dd9567  vmovaps [rsp], xmm0
000076c1d9dd956c  vmovaps [rsp+0x10], xmm1
000076c1d9dd9572  vmovaps [rsp+0x20], xmm2
000076c1d9dd9578  vmovaps [rsp+0x30], xmm3
000076c1d9dd957e  vmovaps [rsp+0x40], xmm4
000076c1d9dd9584  vmovaps [rsp+0x50], xmm5
000076c1d9dd958a  vmovaps [rsp+0x60], xmm6
000076c1d9dd9590  vmovaps [rsp+0x70], xmm7
000076c1d9dd9596  vmovaps [rsp+0x80], xmm8
000076c1d9dd959f  vmovaps [rsp+0x90], xmm9
000076c1d9dd95a8  vmovaps [rsp+0xA0], xmm10
000076c1d9dd95b1  vmovaps [rsp+0xB0], xmm11
000076c1d9dd95ba  vmovaps [rsp+0xC0], xmm12
000076c1d9dd95c3  vmovaps [rsp+0xD0], xmm13
000076c1d9dd95cc  vmovaps [rsp+0xE0], xmm15
000076c1d9dd95d5  sub rsp, 0x30
000076c1d9dd95d9  movaps [rsp], xmm14
000076c1d9dd95de  movaps [rsp+0x10], xmm8
000076c1d9dd95e4  movaps [rsp+0x20], xmm4
000076c1d9dd95e9  lea rdi, [rsp]
000076c1d9dd95ed  mov esi, 0x00
000076c1d9dd95f2  mov rax, 0x5EA58B9E0530
000076c1d9dd95fc  call rax
000076c1d9dd95fe  movaps xmm14, [rsp]
000076c1d9dd9603  add rsp, 0x30
000076c1d9dd9607  vmovaps xmm0, [rsp]
000076c1d9dd960c  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9612  vmovaps xmm2, [rsp+0x20]
000076c1d9dd9618  vmovaps xmm3, [rsp+0x30]
000076c1d9dd961e  vmovaps xmm4, [rsp+0x40]
000076c1d9dd9624  vmovaps xmm5, [rsp+0x50]
000076c1d9dd962a  vmovaps xmm6, [rsp+0x60]
000076c1d9dd9630  vmovaps xmm7, [rsp+0x70]
000076c1d9dd9636  vmovaps xmm8, [rsp+0x80]
000076c1d9dd963f  vmovaps xmm9, [rsp+0x90]
000076c1d9dd9648  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd9651  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd965a  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd9663  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd966c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd9675  add rsp, 0xF0
000076c1d9dd967c  pop r11
000076c1d9dd967e  pop r10
000076c1d9dd9680  pop r9
000076c1d9dd9682  pop r8
000076c1d9dd9684  pop rsi
000076c1d9dd9685  pop rdi
000076c1d9dd9686  pop rdx
000076c1d9dd9687  pop rcx
000076c1d9dd9688  pop rax
000076c1d9dd9689  add rsp, 0x08
000076c1d9dd968d  jmp 0x000076C1D9DD6265
000076c1d9dd9692  sub rsp, 0x08
000076c1d9dd9696  push rax
000076c1d9dd9697  push rcx
000076c1d9dd9698  push rdx
000076c1d9dd9699  push rdi
000076c1d9dd969a  push rsi
000076c1d9dd969b  push r8
000076c1d9dd969d  push r9
000076c1d9dd969f  push r10
000076c1d9dd96a1  push r11
000076c1d9dd96a3  sub rsp, 0xF0
000076c1d9dd96aa  vmovaps [rsp], xmm0
000076c1d9dd96af  vmovaps [rsp+0x10], xmm1
000076c1d9dd96b5  vmovaps [rsp+0x20], xmm2
000076c1d9dd96bb  vmovaps [rsp+0x30], xmm3
000076c1d9dd96c1  vmovaps [rsp+0x40], xmm5
000076c1d9dd96c7  vmovaps [rsp+0x50], xmm6
000076c1d9dd96cd  vmovaps [rsp+0x60], xmm7
000076c1d9dd96d3  vmovaps [rsp+0x70], xmm8
000076c1d9dd96d9  vmovaps [rsp+0x80], xmm9
000076c1d9dd96e2  vmovaps [rsp+0x90], xmm10
000076c1d9dd96eb  vmovaps [rsp+0xA0], xmm11
000076c1d9dd96f4  vmovaps [rsp+0xB0], xmm12
000076c1d9dd96fd  vmovaps [rsp+0xC0], xmm13
000076c1d9dd9706  vmovaps [rsp+0xD0], xmm14
000076c1d9dd970f  vmovaps [rsp+0xE0], xmm15
000076c1d9dd9718  sub rsp, 0x30
000076c1d9dd971c  movaps [rsp], xmm4
000076c1d9dd9720  movaps [rsp+0x10], xmm13
000076c1d9dd9726  movaps [rsp+0x20], xmm8
000076c1d9dd972c  lea rdi, [rsp]
000076c1d9dd9730  mov esi, 0x00
000076c1d9dd9735  mov rax, 0x5EA58B9E0530
000076c1d9dd973f  call rax
000076c1d9dd9741  movaps xmm4, [rsp]
000076c1d9dd9745  add rsp, 0x30
000076c1d9dd9749  vmovaps xmm0, [rsp]
000076c1d9dd974e  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9754  vmovaps xmm2, [rsp+0x20]
000076c1d9dd975a  vmovaps xmm3, [rsp+0x30]
000076c1d9dd9760  vmovaps xmm5, [rsp+0x40]
000076c1d9dd9766  vmovaps xmm6, [rsp+0x50]
000076c1d9dd976c  vmovaps xmm7, [rsp+0x60]
000076c1d9dd9772  vmovaps xmm8, [rsp+0x70]
000076c1d9dd9778  vmovaps xmm9, [rsp+0x80]
000076c1d9dd9781  vmovaps xmm10, [rsp+0x90]
000076c1d9dd978a  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd9793  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd979c  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd97a5  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd97ae  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd97b7  add rsp, 0xF0
000076c1d9dd97be  pop r11
000076c1d9dd97c0  pop r10
000076c1d9dd97c2  pop r9
000076c1d9dd97c4  pop r8
000076c1d9dd97c6  pop rsi
000076c1d9dd97c7  pop rdi
000076c1d9dd97c8  pop rdx
000076c1d9dd97c9  pop rcx
000076c1d9dd97ca  pop rax
000076c1d9dd97cb  add rsp, 0x08
000076c1d9dd97cf  jmp 0x000076C1D9DD628A
000076c1d9dd97d4  sub rsp, 0x08
000076c1d9dd97d8  push rax
000076c1d9dd97d9  push rcx
000076c1d9dd97da  push rdx
000076c1d9dd97db  push rdi
000076c1d9dd97dc  push rsi
000076c1d9dd97dd  push r8
000076c1d9dd97df  push r9
000076c1d9dd97e1  push r10
000076c1d9dd97e3  push r11
000076c1d9dd97e5  sub rsp, 0xF0
000076c1d9dd97ec  vmovaps [rsp], xmm0
000076c1d9dd97f1  vmovaps [rsp+0x10], xmm1
000076c1d9dd97f7  vmovaps [rsp+0x20], xmm2
000076c1d9dd97fd  vmovaps [rsp+0x30], xmm3
000076c1d9dd9803  vmovaps [rsp+0x40], xmm4
000076c1d9dd9809  vmovaps [rsp+0x50], xmm5
000076c1d9dd980f  vmovaps [rsp+0x60], xmm6
000076c1d9dd9815  vmovaps [rsp+0x70], xmm7
000076c1d9dd981b  vmovaps [rsp+0x80], xmm8
000076c1d9dd9824  vmovaps [rsp+0x90], xmm9
000076c1d9dd982d  vmovaps [rsp+0xA0], xmm10
000076c1d9dd9836  vmovaps [rsp+0xB0], xmm11
000076c1d9dd983f  vmovaps [rsp+0xC0], xmm12
000076c1d9dd9848  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9851  vmovaps [rsp+0xE0], xmm15
000076c1d9dd985a  sub rsp, 0x30
000076c1d9dd985e  movaps [rsp], xmm13
000076c1d9dd9863  movaps [rsp+0x10], xmm15
000076c1d9dd9869  movaps [rsp+0x20], xmm9
000076c1d9dd986f  lea rdi, [rsp]
000076c1d9dd9873  mov esi, 0x00
000076c1d9dd9878  mov rax, 0x5EA58B9E0530
000076c1d9dd9882  call rax
000076c1d9dd9884  movaps xmm13, [rsp]
000076c1d9dd9889  add rsp, 0x30
000076c1d9dd988d  vmovaps xmm0, [rsp]
000076c1d9dd9892  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9898  vmovaps xmm2, [rsp+0x20]
000076c1d9dd989e  vmovaps xmm3, [rsp+0x30]
000076c1d9dd98a4  vmovaps xmm4, [rsp+0x40]
000076c1d9dd98aa  vmovaps xmm5, [rsp+0x50]
000076c1d9dd98b0  vmovaps xmm6, [rsp+0x60]
000076c1d9dd98b6  vmovaps xmm7, [rsp+0x70]
000076c1d9dd98bc  vmovaps xmm8, [rsp+0x80]
000076c1d9dd98c5  vmovaps xmm9, [rsp+0x90]
000076c1d9dd98ce  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd98d7  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd98e0  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd98e9  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd98f2  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd98fb  add rsp, 0xF0
000076c1d9dd9902  pop r11
000076c1d9dd9904  pop r10
000076c1d9dd9906  pop r9
000076c1d9dd9908  pop r8
000076c1d9dd990a  pop rsi
000076c1d9dd990b  pop rdi
000076c1d9dd990c  pop rdx
000076c1d9dd990d  pop rcx
000076c1d9dd990e  pop rax
000076c1d9dd990f  add rsp, 0x08
000076c1d9dd9913  jmp 0x000076C1D9DD62A5
000076c1d9dd9918  sub rsp, 0x08
000076c1d9dd991c  push rax
000076c1d9dd991d  push rcx
000076c1d9dd991e  push rdx
000076c1d9dd991f  push rdi
000076c1d9dd9920  push rsi
000076c1d9dd9921  push r8
000076c1d9dd9923  push r9
000076c1d9dd9925  push r10
000076c1d9dd9927  push r11
000076c1d9dd9929  sub rsp, 0xF0
000076c1d9dd9930  vmovaps [rsp], xmm0
000076c1d9dd9935  vmovaps [rsp+0x10], xmm1
000076c1d9dd993b  vmovaps [rsp+0x20], xmm2
000076c1d9dd9941  vmovaps [rsp+0x30], xmm3
000076c1d9dd9947  vmovaps [rsp+0x40], xmm4
000076c1d9dd994d  vmovaps [rsp+0x50], xmm5
000076c1d9dd9953  vmovaps [rsp+0x60], xmm6
000076c1d9dd9959  vmovaps [rsp+0x70], xmm7
000076c1d9dd995f  vmovaps [rsp+0x80], xmm8
000076c1d9dd9968  vmovaps [rsp+0x90], xmm9
000076c1d9dd9971  vmovaps [rsp+0xA0], xmm10
000076c1d9dd997a  vmovaps [rsp+0xB0], xmm11
000076c1d9dd9983  vmovaps [rsp+0xC0], xmm12
000076c1d9dd998c  vmovaps [rsp+0xD0], xmm13
000076c1d9dd9995  vmovaps [rsp+0xE0], xmm14
000076c1d9dd999e  sub rsp, 0x30
000076c1d9dd99a2  movaps [rsp], xmm15
000076c1d9dd99a7  movaps [rsp+0x10], xmm1
000076c1d9dd99ac  movaps [rsp+0x20], xmm5
000076c1d9dd99b1  lea rdi, [rsp]
000076c1d9dd99b5  mov esi, 0x00
000076c1d9dd99ba  mov rax, 0x5EA58B9E0530
000076c1d9dd99c4  call rax
000076c1d9dd99c6  movaps xmm15, [rsp]
000076c1d9dd99cb  add rsp, 0x30
000076c1d9dd99cf  vmovaps xmm0, [rsp]
000076c1d9dd99d4  vmovaps xmm1, [rsp+0x10]
000076c1d9dd99da  vmovaps xmm2, [rsp+0x20]
000076c1d9dd99e0  vmovaps xmm3, [rsp+0x30]
000076c1d9dd99e6  vmovaps xmm4, [rsp+0x40]
000076c1d9dd99ec  vmovaps xmm5, [rsp+0x50]
000076c1d9dd99f2  vmovaps xmm6, [rsp+0x60]
000076c1d9dd99f8  vmovaps xmm7, [rsp+0x70]
000076c1d9dd99fe  vmovaps xmm8, [rsp+0x80]
000076c1d9dd9a07  vmovaps xmm9, [rsp+0x90]
000076c1d9dd9a10  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd9a19  vmovaps xmm11, [rsp+0xB0]
000076c1d9dd9a22  vmovaps xmm12, [rsp+0xC0]
000076c1d9dd9a2b  vmovaps xmm13, [rsp+0xD0]
000076c1d9dd9a34  vmovaps xmm14, [rsp+0xE0]
000076c1d9dd9a3d  add rsp, 0xF0
000076c1d9dd9a44  pop r11
000076c1d9dd9a46  pop r10
000076c1d9dd9a48  pop r9
000076c1d9dd9a4a  pop r8
000076c1d9dd9a4c  pop rsi
000076c1d9dd9a4d  pop rdi
000076c1d9dd9a4e  pop rdx
000076c1d9dd9a4f  pop rcx
000076c1d9dd9a50  pop rax
000076c1d9dd9a51  add rsp, 0x08
000076c1d9dd9a55  jmp 0x000076C1D9DD62C0
000076c1d9dd9a5a  call 0x000076C1D9CD64F0
000076c1d9dd9a5f  jmp 0x000076C1D9DD631B
000076c1d9dd9a64  sub rsp, 0x08
000076c1d9dd9a68  push rax
000076c1d9dd9a69  push rcx
000076c1d9dd9a6a  push rdx
000076c1d9dd9a6b  push rdi
000076c1d9dd9a6c  push rsi
000076c1d9dd9a6d  push r8
000076c1d9dd9a6f  push r9
000076c1d9dd9a71  push r10
000076c1d9dd9a73  push r11
000076c1d9dd9a75  sub rsp, 0xF0
000076c1d9dd9a7c  vmovaps [rsp], xmm0
000076c1d9dd9a81  vmovaps [rsp+0x10], xmm1
000076c1d9dd9a87  vmovaps [rsp+0x20], xmm2
000076c1d9dd9a8d  vmovaps [rsp+0x30], xmm3
000076c1d9dd9a93  vmovaps [rsp+0x40], xmm4
000076c1d9dd9a99  vmovaps [rsp+0x50], xmm5
000076c1d9dd9a9f  vmovaps [rsp+0x60], xmm6
000076c1d9dd9aa5  vmovaps [rsp+0x70], xmm7
000076c1d9dd9aab  vmovaps [rsp+0x80], xmm8
000076c1d9dd9ab4  vmovaps [rsp+0x90], xmm10
000076c1d9dd9abd  vmovaps [rsp+0xA0], xmm11
000076c1d9dd9ac6  vmovaps [rsp+0xB0], xmm12
000076c1d9dd9acf  vmovaps [rsp+0xC0], xmm13
000076c1d9dd9ad8  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9ae1  vmovaps [rsp+0xE0], xmm15
000076c1d9dd9aea  sub rsp, 0x30
000076c1d9dd9aee  movaps [rsp], xmm9
000076c1d9dd9af3  movaps [rsp+0x10], xmm8
000076c1d9dd9af9  movaps [rsp+0x20], xmm11
000076c1d9dd9aff  lea rdi, [rsp]
000076c1d9dd9b03  mov esi, 0x00
000076c1d9dd9b08  mov rax, 0x5EA58B9E0530
000076c1d9dd9b12  call rax
000076c1d9dd9b14  movaps xmm9, [rsp]
000076c1d9dd9b19  add rsp, 0x30
000076c1d9dd9b1d  vmovaps xmm0, [rsp]
000076c1d9dd9b22  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9b28  vmovaps xmm2, [rsp+0x20]
000076c1d9dd9b2e  vmovaps xmm3, [rsp+0x30]
000076c1d9dd9b34  vmovaps xmm4, [rsp+0x40]
000076c1d9dd9b3a  vmovaps xmm5, [rsp+0x50]
000076c1d9dd9b40  vmovaps xmm6, [rsp+0x60]
000076c1d9dd9b46  vmovaps xmm7, [rsp+0x70]
000076c1d9dd9b4c  vmovaps xmm8, [rsp+0x80]
000076c1d9dd9b55  vmovaps xmm10, [rsp+0x90]
000076c1d9dd9b5e  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd9b67  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd9b70  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd9b79  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd9b82  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd9b8b  add rsp, 0xF0
000076c1d9dd9b92  pop r11
000076c1d9dd9b94  pop r10
000076c1d9dd9b96  pop r9
000076c1d9dd9b98  pop r8
000076c1d9dd9b9a  pop rsi
000076c1d9dd9b9b  pop rdi
000076c1d9dd9b9c  pop rdx
000076c1d9dd9b9d  pop rcx
000076c1d9dd9b9e  pop rax
000076c1d9dd9b9f  add rsp, 0x08
000076c1d9dd9ba3  jmp 0x000076C1D9DD6352
000076c1d9dd9ba8  sub rsp, 0x08
000076c1d9dd9bac  push rax
000076c1d9dd9bad  push rcx
000076c1d9dd9bae  push rdx
000076c1d9dd9baf  push rdi
000076c1d9dd9bb0  push rsi
000076c1d9dd9bb1  push r8
000076c1d9dd9bb3  push r9
000076c1d9dd9bb5  push r10
000076c1d9dd9bb7  push r11
000076c1d9dd9bb9  sub rsp, 0xF0
000076c1d9dd9bc0  vmovaps [rsp], xmm0
000076c1d9dd9bc5  vmovaps [rsp+0x10], xmm1
000076c1d9dd9bcb  vmovaps [rsp+0x20], xmm2
000076c1d9dd9bd1  vmovaps [rsp+0x30], xmm3
000076c1d9dd9bd7  vmovaps [rsp+0x40], xmm4
000076c1d9dd9bdd  vmovaps [rsp+0x50], xmm5
000076c1d9dd9be3  vmovaps [rsp+0x60], xmm6
000076c1d9dd9be9  vmovaps [rsp+0x70], xmm7
000076c1d9dd9bef  vmovaps [rsp+0x80], xmm8
000076c1d9dd9bf8  vmovaps [rsp+0x90], xmm9
000076c1d9dd9c01  vmovaps [rsp+0xA0], xmm10
000076c1d9dd9c0a  vmovaps [rsp+0xB0], xmm12
000076c1d9dd9c13  vmovaps [rsp+0xC0], xmm13
000076c1d9dd9c1c  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9c25  vmovaps [rsp+0xE0], xmm15
000076c1d9dd9c2e  sub rsp, 0x30
000076c1d9dd9c32  movaps [rsp], xmm11
000076c1d9dd9c37  movaps [rsp+0x10], xmm10
000076c1d9dd9c3d  movaps [rsp+0x20], xmm6
000076c1d9dd9c42  lea rdi, [rsp]
000076c1d9dd9c46  mov esi, 0x00
000076c1d9dd9c4b  mov rax, 0x5EA58B9E0530
000076c1d9dd9c55  call rax
000076c1d9dd9c57  movaps xmm11, [rsp]
000076c1d9dd9c5c  add rsp, 0x30
000076c1d9dd9c60  vmovaps xmm0, [rsp]
000076c1d9dd9c65  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9c6b  vmovaps xmm2, [rsp+0x20]
000076c1d9dd9c71  vmovaps xmm3, [rsp+0x30]
000076c1d9dd9c77  vmovaps xmm4, [rsp+0x40]
000076c1d9dd9c7d  vmovaps xmm5, [rsp+0x50]
000076c1d9dd9c83  vmovaps xmm6, [rsp+0x60]
000076c1d9dd9c89  vmovaps xmm7, [rsp+0x70]
000076c1d9dd9c8f  vmovaps xmm8, [rsp+0x80]
000076c1d9dd9c98  vmovaps xmm9, [rsp+0x90]
000076c1d9dd9ca1  vmovaps xmm10, [rsp+0xA0]
000076c1d9dd9caa  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd9cb3  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd9cbc  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd9cc5  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd9cce  add rsp, 0xF0
000076c1d9dd9cd5  pop r11
000076c1d9dd9cd7  pop r10
000076c1d9dd9cd9  pop r9
000076c1d9dd9cdb  pop r8
000076c1d9dd9cdd  pop rsi
000076c1d9dd9cde  pop rdi
000076c1d9dd9cdf  pop rdx
000076c1d9dd9ce0  pop rcx
000076c1d9dd9ce1  pop rax
000076c1d9dd9ce2  add rsp, 0x08
000076c1d9dd9ce6  jmp 0x000076C1D9DD636D
000076c1d9dd9ceb  sub rsp, 0x08
000076c1d9dd9cef  push rax
000076c1d9dd9cf0  push rcx
000076c1d9dd9cf1  push rdx
000076c1d9dd9cf2  push rdi
000076c1d9dd9cf3  push rsi
000076c1d9dd9cf4  push r8
000076c1d9dd9cf6  push r9
000076c1d9dd9cf8  push r10
000076c1d9dd9cfa  push r11
000076c1d9dd9cfc  sub rsp, 0xF0
000076c1d9dd9d03  vmovaps [rsp], xmm0
000076c1d9dd9d08  vmovaps [rsp+0x10], xmm1
000076c1d9dd9d0e  vmovaps [rsp+0x20], xmm2
000076c1d9dd9d14  vmovaps [rsp+0x30], xmm3
000076c1d9dd9d1a  vmovaps [rsp+0x40], xmm4
000076c1d9dd9d20  vmovaps [rsp+0x50], xmm5
000076c1d9dd9d26  vmovaps [rsp+0x60], xmm6
000076c1d9dd9d2c  vmovaps [rsp+0x70], xmm7
000076c1d9dd9d32  vmovaps [rsp+0x80], xmm8
000076c1d9dd9d3b  vmovaps [rsp+0x90], xmm9
000076c1d9dd9d44  vmovaps [rsp+0xA0], xmm11
000076c1d9dd9d4d  vmovaps [rsp+0xB0], xmm12
000076c1d9dd9d56  vmovaps [rsp+0xC0], xmm13
000076c1d9dd9d5f  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9d68  vmovaps [rsp+0xE0], xmm15
000076c1d9dd9d71  sub rsp, 0x30
000076c1d9dd9d75  movaps [rsp], xmm10
000076c1d9dd9d7a  movaps [rsp+0x10], xmm14
000076c1d9dd9d80  movaps [rsp+0x20], xmm4
000076c1d9dd9d85  lea rdi, [rsp]
000076c1d9dd9d89  mov esi, 0x00
000076c1d9dd9d8e  mov rax, 0x5EA58B9E0530
000076c1d9dd9d98  call rax
000076c1d9dd9d9a  movaps xmm10, [rsp]
000076c1d9dd9d9f  add rsp, 0x30
000076c1d9dd9da3  vmovaps xmm0, [rsp]
000076c1d9dd9da8  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9dae  vmovaps xmm2, [rsp+0x20]
000076c1d9dd9db4  vmovaps xmm3, [rsp+0x30]
000076c1d9dd9dba  vmovaps xmm4, [rsp+0x40]
000076c1d9dd9dc0  vmovaps xmm5, [rsp+0x50]
000076c1d9dd9dc6  vmovaps xmm6, [rsp+0x60]
000076c1d9dd9dcc  vmovaps xmm7, [rsp+0x70]
000076c1d9dd9dd2  vmovaps xmm8, [rsp+0x80]
000076c1d9dd9ddb  vmovaps xmm9, [rsp+0x90]
000076c1d9dd9de4  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd9ded  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd9df6  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd9dff  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd9e08  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd9e11  add rsp, 0xF0
000076c1d9dd9e18  pop r11
000076c1d9dd9e1a  pop r10
000076c1d9dd9e1c  pop r9
000076c1d9dd9e1e  pop r8
000076c1d9dd9e20  pop rsi
000076c1d9dd9e21  pop rdi
000076c1d9dd9e22  pop rdx
000076c1d9dd9e23  pop rcx
000076c1d9dd9e24  pop rax
000076c1d9dd9e25  add rsp, 0x08
000076c1d9dd9e29  jmp 0x000076C1D9DD6388
000076c1d9dd9e2e  sub rsp, 0x08
000076c1d9dd9e32  push rax
000076c1d9dd9e33  push rcx
000076c1d9dd9e34  push rdx
000076c1d9dd9e35  push rdi
000076c1d9dd9e36  push rsi
000076c1d9dd9e37  push r8
000076c1d9dd9e39  push r9
000076c1d9dd9e3b  push r10
000076c1d9dd9e3d  push r11
000076c1d9dd9e3f  sub rsp, 0xF0
000076c1d9dd9e46  vmovaps [rsp], xmm0
000076c1d9dd9e4b  vmovaps [rsp+0x10], xmm1
000076c1d9dd9e51  vmovaps [rsp+0x20], xmm2
000076c1d9dd9e57  vmovaps [rsp+0x30], xmm3
000076c1d9dd9e5d  vmovaps [rsp+0x40], xmm4
000076c1d9dd9e63  vmovaps [rsp+0x50], xmm5
000076c1d9dd9e69  vmovaps [rsp+0x60], xmm6
000076c1d9dd9e6f  vmovaps [rsp+0x70], xmm7
000076c1d9dd9e75  vmovaps [rsp+0x80], xmm9
000076c1d9dd9e7e  vmovaps [rsp+0x90], xmm10
000076c1d9dd9e87  vmovaps [rsp+0xA0], xmm11
000076c1d9dd9e90  vmovaps [rsp+0xB0], xmm12
000076c1d9dd9e99  vmovaps [rsp+0xC0], xmm13
000076c1d9dd9ea2  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9eab  vmovaps [rsp+0xE0], xmm15
000076c1d9dd9eb4  sub rsp, 0x30
000076c1d9dd9eb8  movaps [rsp], xmm8
000076c1d9dd9ebd  movaps [rsp+0x10], xmm1
000076c1d9dd9ec2  movaps [rsp+0x20], xmm14
000076c1d9dd9ec8  lea rdi, [rsp]
000076c1d9dd9ecc  mov esi, 0x00
000076c1d9dd9ed1  mov rax, 0x5EA58B9E0530
000076c1d9dd9edb  call rax
000076c1d9dd9edd  movaps xmm8, [rsp]
000076c1d9dd9ee2  add rsp, 0x30
000076c1d9dd9ee6  vmovaps xmm0, [rsp]
000076c1d9dd9eeb  vmovaps xmm1, [rsp+0x10]
000076c1d9dd9ef1  vmovaps xmm2, [rsp+0x20]
000076c1d9dd9ef7  vmovaps xmm3, [rsp+0x30]
000076c1d9dd9efd  vmovaps xmm4, [rsp+0x40]
000076c1d9dd9f03  vmovaps xmm5, [rsp+0x50]
000076c1d9dd9f09  vmovaps xmm6, [rsp+0x60]
000076c1d9dd9f0f  vmovaps xmm7, [rsp+0x70]
000076c1d9dd9f15  vmovaps xmm9, [rsp+0x80]
000076c1d9dd9f1e  vmovaps xmm10, [rsp+0x90]
000076c1d9dd9f27  vmovaps xmm11, [rsp+0xA0]
000076c1d9dd9f30  vmovaps xmm12, [rsp+0xB0]
000076c1d9dd9f39  vmovaps xmm13, [rsp+0xC0]
000076c1d9dd9f42  vmovaps xmm14, [rsp+0xD0]
000076c1d9dd9f4b  vmovaps xmm15, [rsp+0xE0]
000076c1d9dd9f54  add rsp, 0xF0
000076c1d9dd9f5b  pop r11
000076c1d9dd9f5d  pop r10
000076c1d9dd9f5f  pop r9
000076c1d9dd9f61  pop r8
000076c1d9dd9f63  pop rsi
000076c1d9dd9f64  pop rdi
000076c1d9dd9f65  pop rdx
000076c1d9dd9f66  pop rcx
000076c1d9dd9f67  pop rax
000076c1d9dd9f68  add rsp, 0x08
000076c1d9dd9f6c  jmp 0x000076C1D9DD63AE
000076c1d9dd9f71  sub rsp, 0x08
000076c1d9dd9f75  push rax
000076c1d9dd9f76  push rcx
000076c1d9dd9f77  push rdx
000076c1d9dd9f78  push rdi
000076c1d9dd9f79  push rsi
000076c1d9dd9f7a  push r8
000076c1d9dd9f7c  push r9
000076c1d9dd9f7e  push r10
000076c1d9dd9f80  push r11
000076c1d9dd9f82  sub rsp, 0xF0
000076c1d9dd9f89  vmovaps [rsp], xmm0
000076c1d9dd9f8e  vmovaps [rsp+0x10], xmm1
000076c1d9dd9f94  vmovaps [rsp+0x20], xmm2
000076c1d9dd9f9a  vmovaps [rsp+0x30], xmm3
000076c1d9dd9fa0  vmovaps [rsp+0x40], xmm4
000076c1d9dd9fa6  vmovaps [rsp+0x50], xmm5
000076c1d9dd9fac  vmovaps [rsp+0x60], xmm7
000076c1d9dd9fb2  vmovaps [rsp+0x70], xmm8
000076c1d9dd9fb8  vmovaps [rsp+0x80], xmm9
000076c1d9dd9fc1  vmovaps [rsp+0x90], xmm10
000076c1d9dd9fca  vmovaps [rsp+0xA0], xmm11
000076c1d9dd9fd3  vmovaps [rsp+0xB0], xmm12
000076c1d9dd9fdc  vmovaps [rsp+0xC0], xmm13
000076c1d9dd9fe5  vmovaps [rsp+0xD0], xmm14
000076c1d9dd9fee  vmovaps [rsp+0xE0], xmm15
000076c1d9dd9ff7  sub rsp, 0x30
000076c1d9dd9ffb  movaps [rsp], xmm6
000076c1d9dd9fff  movaps [rsp+0x10], xmm1
000076c1d9dda004  movaps [rsp+0x20], xmm14
000076c1d9dda00a  lea rdi, [rsp]
000076c1d9dda00e  mov esi, 0x00
000076c1d9dda013  mov rax, 0x5EA58B9E0530
000076c1d9dda01d  call rax
000076c1d9dda01f  movaps xmm6, [rsp]
000076c1d9dda023  add rsp, 0x30
000076c1d9dda027  vmovaps xmm0, [rsp]
000076c1d9dda02c  vmovaps xmm1, [rsp+0x10]
000076c1d9dda032  vmovaps xmm2, [rsp+0x20]
000076c1d9dda038  vmovaps xmm3, [rsp+0x30]
000076c1d9dda03e  vmovaps xmm4, [rsp+0x40]
000076c1d9dda044  vmovaps xmm5, [rsp+0x50]
000076c1d9dda04a  vmovaps xmm7, [rsp+0x60]
000076c1d9dda050  vmovaps xmm8, [rsp+0x70]
000076c1d9dda056  vmovaps xmm9, [rsp+0x80]
000076c1d9dda05f  vmovaps xmm10, [rsp+0x90]
000076c1d9dda068  vmovaps xmm11, [rsp+0xA0]
000076c1d9dda071  vmovaps xmm12, [rsp+0xB0]
000076c1d9dda07a  vmovaps xmm13, [rsp+0xC0]
000076c1d9dda083  vmovaps xmm14, [rsp+0xD0]
000076c1d9dda08c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dda095  add rsp, 0xF0
000076c1d9dda09c  pop r11
000076c1d9dda09e  pop r10
000076c1d9dda0a0  pop r9
000076c1d9dda0a2  pop r8
000076c1d9dda0a4  pop rsi
000076c1d9dda0a5  pop rdi
000076c1d9dda0a6  pop rdx
000076c1d9dda0a7  pop rcx
000076c1d9dda0a8  pop rax
000076c1d9dda0a9  add rsp, 0x08
000076c1d9dda0ad  jmp 0x000076C1D9DD63DA
000076c1d9dda0b2  sub rsp, 0x08
000076c1d9dda0b6  push rax
000076c1d9dda0b7  push rcx
000076c1d9dda0b8  push rdx
000076c1d9dda0b9  push rdi
000076c1d9dda0ba  push rsi
000076c1d9dda0bb  push r8
000076c1d9dda0bd  push r9
000076c1d9dda0bf  push r10
000076c1d9dda0c1  push r11
000076c1d9dda0c3  sub rsp, 0xF0
000076c1d9dda0ca  vmovaps [rsp], xmm0
000076c1d9dda0cf  vmovaps [rsp+0x10], xmm1
000076c1d9dda0d5  vmovaps [rsp+0x20], xmm2
000076c1d9dda0db  vmovaps [rsp+0x30], xmm3
000076c1d9dda0e1  vmovaps [rsp+0x40], xmm4
000076c1d9dda0e7  vmovaps [rsp+0x50], xmm5
000076c1d9dda0ed  vmovaps [rsp+0x60], xmm6
000076c1d9dda0f3  vmovaps [rsp+0x70], xmm7
000076c1d9dda0f9  vmovaps [rsp+0x80], xmm8
000076c1d9dda102  vmovaps [rsp+0x90], xmm9
000076c1d9dda10b  vmovaps [rsp+0xA0], xmm10
000076c1d9dda114  vmovaps [rsp+0xB0], xmm11
000076c1d9dda11d  vmovaps [rsp+0xC0], xmm12
000076c1d9dda126  vmovaps [rsp+0xD0], xmm13
000076c1d9dda12f  vmovaps [rsp+0xE0], xmm15
000076c1d9dda138  sub rsp, 0x30
000076c1d9dda13c  movaps [rsp], xmm14
000076c1d9dda141  movaps [rsp+0x10], xmm12
000076c1d9dda147  movaps [rsp+0x20], xmm1
000076c1d9dda14c  lea rdi, [rsp]
000076c1d9dda150  mov esi, 0x00
000076c1d9dda155  mov rax, 0x5EA58B9E0530
000076c1d9dda15f  call rax
000076c1d9dda161  movaps xmm14, [rsp]
000076c1d9dda166  add rsp, 0x30
000076c1d9dda16a  vmovaps xmm0, [rsp]
000076c1d9dda16f  vmovaps xmm1, [rsp+0x10]
000076c1d9dda175  vmovaps xmm2, [rsp+0x20]
000076c1d9dda17b  vmovaps xmm3, [rsp+0x30]
000076c1d9dda181  vmovaps xmm4, [rsp+0x40]
000076c1d9dda187  vmovaps xmm5, [rsp+0x50]
000076c1d9dda18d  vmovaps xmm6, [rsp+0x60]
000076c1d9dda193  vmovaps xmm7, [rsp+0x70]
000076c1d9dda199  vmovaps xmm8, [rsp+0x80]
000076c1d9dda1a2  vmovaps xmm9, [rsp+0x90]
000076c1d9dda1ab  vmovaps xmm10, [rsp+0xA0]
000076c1d9dda1b4  vmovaps xmm11, [rsp+0xB0]
000076c1d9dda1bd  vmovaps xmm12, [rsp+0xC0]
000076c1d9dda1c6  vmovaps xmm13, [rsp+0xD0]
000076c1d9dda1cf  vmovaps xmm15, [rsp+0xE0]
000076c1d9dda1d8  add rsp, 0xF0
000076c1d9dda1df  pop r11
000076c1d9dda1e1  pop r10
000076c1d9dda1e3  pop r9
000076c1d9dda1e5  pop r8
000076c1d9dda1e7  pop rsi
000076c1d9dda1e8  pop rdi
000076c1d9dda1e9  pop rdx
000076c1d9dda1ea  pop rcx
000076c1d9dda1eb  pop rax
000076c1d9dda1ec  add rsp, 0x08
000076c1d9dda1f0  jmp 0x000076C1D9DD6400
000076c1d9dda1f5  sub rsp, 0x08
000076c1d9dda1f9  push rax
000076c1d9dda1fa  push rcx
000076c1d9dda1fb  push rdx
000076c1d9dda1fc  push rdi
000076c1d9dda1fd  push rsi
000076c1d9dda1fe  push r8
000076c1d9dda200  push r9
000076c1d9dda202  push r10
000076c1d9dda204  push r11
000076c1d9dda206  sub rsp, 0xF0
000076c1d9dda20d  vmovaps [rsp], xmm0
000076c1d9dda212  vmovaps [rsp+0x10], xmm2
000076c1d9dda218  vmovaps [rsp+0x20], xmm3
000076c1d9dda21e  vmovaps [rsp+0x30], xmm4
000076c1d9dda224  vmovaps [rsp+0x40], xmm5
000076c1d9dda22a  vmovaps [rsp+0x50], xmm6
000076c1d9dda230  vmovaps [rsp+0x60], xmm7
000076c1d9dda236  vmovaps [rsp+0x70], xmm8
000076c1d9dda23c  vmovaps [rsp+0x80], xmm9
000076c1d9dda245  vmovaps [rsp+0x90], xmm10
000076c1d9dda24e  vmovaps [rsp+0xA0], xmm11
000076c1d9dda257  vmovaps [rsp+0xB0], xmm12
000076c1d9dda260  vmovaps [rsp+0xC0], xmm13
000076c1d9dda269  vmovaps [rsp+0xD0], xmm14
000076c1d9dda272  vmovaps [rsp+0xE0], xmm15
000076c1d9dda27b  sub rsp, 0x30
000076c1d9dda27f  movaps [rsp], xmm1
000076c1d9dda283  movaps [rsp+0x10], xmm13
000076c1d9dda289  movaps [rsp+0x20], xmm9
000076c1d9dda28f  lea rdi, [rsp]
000076c1d9dda293  mov esi, 0x00
000076c1d9dda298  mov rax, 0x5EA58B9E0530
000076c1d9dda2a2  call rax
000076c1d9dda2a4  movaps xmm1, [rsp]
000076c1d9dda2a8  add rsp, 0x30
000076c1d9dda2ac  vmovaps xmm0, [rsp]
000076c1d9dda2b1  vmovaps xmm2, [rsp+0x10]
000076c1d9dda2b7  vmovaps xmm3, [rsp+0x20]
000076c1d9dda2bd  vmovaps xmm4, [rsp+0x30]
000076c1d9dda2c3  vmovaps xmm5, [rsp+0x40]
000076c1d9dda2c9  vmovaps xmm6, [rsp+0x50]
000076c1d9dda2cf  vmovaps xmm7, [rsp+0x60]
000076c1d9dda2d5  vmovaps xmm8, [rsp+0x70]
000076c1d9dda2db  vmovaps xmm9, [rsp+0x80]
000076c1d9dda2e4  vmovaps xmm10, [rsp+0x90]
000076c1d9dda2ed  vmovaps xmm11, [rsp+0xA0]
000076c1d9dda2f6  vmovaps xmm12, [rsp+0xB0]
000076c1d9dda2ff  vmovaps xmm13, [rsp+0xC0]
000076c1d9dda308  vmovaps xmm14, [rsp+0xD0]
000076c1d9dda311  vmovaps xmm15, [rsp+0xE0]
000076c1d9dda31a  add rsp, 0xF0
000076c1d9dda321  pop r11
000076c1d9dda323  pop r10
000076c1d9dda325  pop r9
000076c1d9dda327  pop r8
000076c1d9dda329  pop rsi
000076c1d9dda32a  pop rdi
000076c1d9dda32b  pop rdx
000076c1d9dda32c  pop rcx
000076c1d9dda32d  pop rax
000076c1d9dda32e  add rsp, 0x08
000076c1d9dda332  jmp 0x000076C1D9DD641A
000076c1d9dda337  sub rsp, 0x08
000076c1d9dda33b  push rax
000076c1d9dda33c  push rcx
000076c1d9dda33d  push rdx
000076c1d9dda33e  push rdi
000076c1d9dda33f  push rsi
000076c1d9dda340  push r8
000076c1d9dda342  push r9
000076c1d9dda344  push r10
000076c1d9dda346  push r11
000076c1d9dda348  sub rsp, 0xF0
000076c1d9dda34f  vmovaps [rsp], xmm0
000076c1d9dda354  vmovaps [rsp+0x10], xmm1
000076c1d9dda35a  vmovaps [rsp+0x20], xmm2
000076c1d9dda360  vmovaps [rsp+0x30], xmm3
000076c1d9dda366  vmovaps [rsp+0x40], xmm4
000076c1d9dda36c  vmovaps [rsp+0x50], xmm5
000076c1d9dda372  vmovaps [rsp+0x60], xmm6
000076c1d9dda378  vmovaps [rsp+0x70], xmm7
000076c1d9dda37e  vmovaps [rsp+0x80], xmm8
000076c1d9dda387  vmovaps [rsp+0x90], xmm9
000076c1d9dda390  vmovaps [rsp+0xA0], xmm10
000076c1d9dda399  vmovaps [rsp+0xB0], xmm11
000076c1d9dda3a2  vmovaps [rsp+0xC0], xmm13
000076c1d9dda3ab  vmovaps [rsp+0xD0], xmm14
000076c1d9dda3b4  vmovaps [rsp+0xE0], xmm15
000076c1d9dda3bd  sub rsp, 0x30
000076c1d9dda3c1  movaps [rsp], xmm12
000076c1d9dda3c6  movaps [rsp+0x10], xmm7
000076c1d9dda3cb  movaps [rsp+0x20], xmm13
000076c1d9dda3d1  lea rdi, [rsp]
000076c1d9dda3d5  mov esi, 0x00
000076c1d9dda3da  mov rax, 0x5EA58B9E0530
000076c1d9dda3e4  call rax
000076c1d9dda3e6  movaps xmm12, [rsp]
000076c1d9dda3eb  add rsp, 0x30
000076c1d9dda3ef  vmovaps xmm0, [rsp]
000076c1d9dda3f4  vmovaps xmm1, [rsp+0x10]
000076c1d9dda3fa  vmovaps xmm2, [rsp+0x20]
000076c1d9dda400  vmovaps xmm3, [rsp+0x30]
000076c1d9dda406  vmovaps xmm4, [rsp+0x40]
000076c1d9dda40c  vmovaps xmm5, [rsp+0x50]
000076c1d9dda412  vmovaps xmm6, [rsp+0x60]
000076c1d9dda418  vmovaps xmm7, [rsp+0x70]
000076c1d9dda41e  vmovaps xmm8, [rsp+0x80]
000076c1d9dda427  vmovaps xmm9, [rsp+0x90]
000076c1d9dda430  vmovaps xmm10, [rsp+0xA0]
000076c1d9dda439  vmovaps xmm11, [rsp+0xB0]
000076c1d9dda442  vmovaps xmm13, [rsp+0xC0]
000076c1d9dda44b  vmovaps xmm14, [rsp+0xD0]
000076c1d9dda454  vmovaps xmm15, [rsp+0xE0]
000076c1d9dda45d  add rsp, 0xF0
000076c1d9dda464  pop r11
000076c1d9dda466  pop r10
000076c1d9dda468  pop r9
000076c1d9dda46a  pop r8
000076c1d9dda46c  pop rsi
000076c1d9dda46d  pop rdi
000076c1d9dda46e  pop rdx
000076c1d9dda46f  pop rcx
000076c1d9dda470  pop rax
000076c1d9dda471  add rsp, 0x08
000076c1d9dda475  jmp 0x000076C1D9DD6441
000076c1d9dda47a  sub rsp, 0x08
000076c1d9dda47e  push rax
000076c1d9dda47f  push rcx
000076c1d9dda480  push rdx
000076c1d9dda481  push rdi
000076c1d9dda482  push rsi
000076c1d9dda483  push r8
000076c1d9dda485  push r9
000076c1d9dda487  push r10
000076c1d9dda489  push r11
000076c1d9dda48b  sub rsp, 0xF0
000076c1d9dda492  vmovaps [rsp], xmm0
000076c1d9dda497  vmovaps [rsp+0x10], xmm1
000076c1d9dda49d  vmovaps [rsp+0x20], xmm2
000076c1d9dda4a3  vmovaps [rsp+0x30], xmm3
000076c1d9dda4a9  vmovaps [rsp+0x40], xmm4
000076c1d9dda4af  vmovaps [rsp+0x50], xmm5
000076c1d9dda4b5  vmovaps [rsp+0x60], xmm6
000076c1d9dda4bb  vmovaps [rsp+0x70], xmm7
000076c1d9dda4c1  vmovaps [rsp+0x80], xmm8
000076c1d9dda4ca  vmovaps [rsp+0x90], xmm9
000076c1d9dda4d3  vmovaps [rsp+0xA0], xmm10
000076c1d9dda4dc  vmovaps [rsp+0xB0], xmm11
000076c1d9dda4e5  vmovaps [rsp+0xC0], xmm12
000076c1d9dda4ee  vmovaps [rsp+0xD0], xmm14
000076c1d9dda4f7  vmovaps [rsp+0xE0], xmm15
000076c1d9dda500  sub rsp, 0x30
000076c1d9dda504  movaps [rsp], xmm13
000076c1d9dda509  movaps [rsp+0x10], xmm15
000076c1d9dda50f  movaps [rsp+0x20], xmm8
000076c1d9dda515  lea rdi, [rsp]
000076c1d9dda519  mov esi, 0x00
000076c1d9dda51e  mov rax, 0x5EA58B9E0530
000076c1d9dda528  call rax
000076c1d9dda52a  movaps xmm13, [rsp]
000076c1d9dda52f  add rsp, 0x30
000076c1d9dda533  vmovaps xmm0, [rsp]
000076c1d9dda538  vmovaps xmm1, [rsp+0x10]
000076c1d9dda53e  vmovaps xmm2, [rsp+0x20]
000076c1d9dda544  vmovaps xmm3, [rsp+0x30]
000076c1d9dda54a  vmovaps xmm4, [rsp+0x40]
000076c1d9dda550  vmovaps xmm5, [rsp+0x50]
000076c1d9dda556  vmovaps xmm6, [rsp+0x60]
000076c1d9dda55c  vmovaps xmm7, [rsp+0x70]
000076c1d9dda562  vmovaps xmm8, [rsp+0x80]
000076c1d9dda56b  vmovaps xmm9, [rsp+0x90]
000076c1d9dda574  vmovaps xmm10, [rsp+0xA0]
000076c1d9dda57d  vmovaps xmm11, [rsp+0xB0]
000076c1d9dda586  vmovaps xmm12, [rsp+0xC0]
000076c1d9dda58f  vmovaps xmm14, [rsp+0xD0]
000076c1d9dda598  vmovaps xmm15, [rsp+0xE0]
000076c1d9dda5a1  add rsp, 0xF0
000076c1d9dda5a8  pop r11
000076c1d9dda5aa  pop r10
000076c1d9dda5ac  pop r9
000076c1d9dda5ae  pop r8
000076c1d9dda5b0  pop rsi
000076c1d9dda5b1  pop rdi
000076c1d9dda5b2  pop rdx
000076c1d9dda5b3  pop rcx
000076c1d9dda5b4  pop rax
000076c1d9dda5b5  add rsp, 0x08
000076c1d9dda5b9  jmp 0x000076C1D9DD645C
000076c1d9dda5be  sub rsp, 0x08
000076c1d9dda5c2  push rax
000076c1d9dda5c3  push rcx
000076c1d9dda5c4  push rdx
000076c1d9dda5c5  push rdi
000076c1d9dda5c6  push rsi
000076c1d9dda5c7  push r8
000076c1d9dda5c9  push r9
000076c1d9dda5cb  push r10
000076c1d9dda5cd  push r11
000076c1d9dda5cf  sub rsp, 0xF0
000076c1d9dda5d6  vmovaps [rsp], xmm0
000076c1d9dda5db  vmovaps [rsp+0x10], xmm1
000076c1d9dda5e1  vmovaps [rsp+0x20], xmm2
000076c1d9dda5e7  vmovaps [rsp+0x30], xmm3
000076c1d9dda5ed  vmovaps [rsp+0x40], xmm4
000076c1d9dda5f3  vmovaps [rsp+0x50], xmm5
000076c1d9dda5f9  vmovaps [rsp+0x60], xmm6
000076c1d9dda5ff  vmovaps [rsp+0x70], xmm7
000076c1d9dda605  vmovaps [rsp+0x80], xmm9
000076c1d9dda60e  vmovaps [rsp+0x90], xmm10
000076c1d9dda617  vmovaps [rsp+0xA0], xmm11
000076c1d9dda620  vmovaps [rsp+0xB0], xmm12
000076c1d9dda629  vmovaps [rsp+0xC0], xmm13
000076c1d9dda632  vmovaps [rsp+0xD0], xmm14
000076c1d9dda63b  vmovaps [rsp+0xE0], xmm15
000076c1d9dda644  sub rsp, 0x30
000076c1d9dda648  movaps [rsp], xmm8
000076c1d9dda64d  movaps [rsp+0x10], xmm15
000076c1d9dda653  movaps [rsp+0x20], xmm9
000076c1d9dda659  lea rdi, [rsp]
000076c1d9dda65d  mov esi, 0x00
000076c1d9dda662  mov rax, 0x5EA58B9E0530
000076c1d9dda66c  call rax
000076c1d9dda66e  movaps xmm8, [rsp]
000076c1d9dda673  add rsp, 0x30
000076c1d9dda677  vmovaps xmm0, [rsp]
000076c1d9dda67c  vmovaps xmm1, [rsp+0x10]
000076c1d9dda682  vmovaps xmm2, [rsp+0x20]
000076c1d9dda688  vmovaps xmm3, [rsp+0x30]
000076c1d9dda68e  vmovaps xmm4, [rsp+0x40]
000076c1d9dda694  vmovaps xmm5, [rsp+0x50]
000076c1d9dda69a  vmovaps xmm6, [rsp+0x60]
000076c1d9dda6a0  vmovaps xmm7, [rsp+0x70]
000076c1d9dda6a6  vmovaps xmm9, [rsp+0x80]
000076c1d9dda6af  vmovaps xmm10, [rsp+0x90]
000076c1d9dda6b8  vmovaps xmm11, [rsp+0xA0]
000076c1d9dda6c1  vmovaps xmm12, [rsp+0xB0]
000076c1d9dda6ca  vmovaps xmm13, [rsp+0xC0]
000076c1d9dda6d3  vmovaps xmm14, [rsp+0xD0]
000076c1d9dda6dc  vmovaps xmm15, [rsp+0xE0]
000076c1d9dda6e5  add rsp, 0xF0
000076c1d9dda6ec  pop r11
000076c1d9dda6ee  pop r10
000076c1d9dda6f0  pop r9
000076c1d9dda6f2  pop r8
000076c1d9dda6f4  pop rsi
000076c1d9dda6f5  pop rdi
000076c1d9dda6f6  pop rdx
000076c1d9dda6f7  pop rcx
000076c1d9dda6f8  pop rax
000076c1d9dda6f9  add rsp, 0x08
000076c1d9dda6fd  jmp 0x000076C1D9DD648A
000076c1d9dda702  sub rsp, 0x08
000076c1d9dda706  push rax
000076c1d9dda707  push rcx
000076c1d9dda708  push rdx
000076c1d9dda709  push rdi
000076c1d9dda70a  push rsi
000076c1d9dda70b  push r8
000076c1d9dda70d  push r9
000076c1d9dda70f  push r10
000076c1d9dda711  push r11
000076c1d9dda713  sub rsp, 0xF0
000076c1d9dda71a  vmovaps [rsp], xmm0
000076c1d9dda71f  vmovaps [rsp+0x10], xmm1
000076c1d9dda725  vmovaps [rsp+0x20], xmm2
000076c1d9dda72b  vmovaps [rsp+0x30], xmm3
000076c1d9dda731  vmovaps [rsp+0x40], xmm4
000076c1d9dda737  vmovaps [rsp+0x50], xmm5
000076c1d9dda73d  vmovaps [rsp+0x60], xmm6
000076c1d9dda743  vmovaps [rsp+0x70], xmm7
000076c1d9dda749  vmovaps [rsp+0x80], xmm8
000076c1d9dda752  vmovaps [rsp+0x90], xmm9
000076c1d9dda75b  vmovaps [rsp+0xA0], xmm10
000076c1d9dda764  vmovaps [rsp+0xB0], xmm11
000076c1d9dda76d  vmovaps [rsp+0xC0], xmm12
000076c1d9dda776  vmovaps [rsp+0xD0], xmm13
000076c1d9dda77f  vmovaps [rsp+0xE0], xmm14
000076c1d9dda788  sub rsp, 0x30
000076c1d9dda78c  movaps [rsp], xmm15
000076c1d9dda791  movaps [rsp+0x10], xmm11
000076c1d9dda797  movaps [rsp+0x20], xmm6
000076c1d9dda79c  lea rdi, [rsp]
000076c1d9dda7a0  mov esi, 0x00
000076c1d9dda7a5  mov rax, 0x5EA58B9E0530
000076c1d9dda7af  call rax
000076c1d9dda7b1  movaps xmm15, [rsp]
000076c1d9dda7b6  add rsp, 0x30
000076c1d9dda7ba  vmovaps xmm0, [rsp]
000076c1d9dda7bf  vmovaps xmm1, [rsp+0x10]
000076c1d9dda7c5  vmovaps xmm2, [rsp+0x20]
000076c1d9dda7cb  vmovaps xmm3, [rsp+0x30]
000076c1d9dda7d1  vmovaps xmm4, [rsp+0x40]
000076c1d9dda7d7  vmovaps xmm5, [rsp+0x50]
000076c1d9dda7dd  vmovaps xmm6, [rsp+0x60]
000076c1d9dda7e3  vmovaps xmm7, [rsp+0x70]
000076c1d9dda7e9  vmovaps xmm8, [rsp+0x80]
000076c1d9dda7f2  vmovaps xmm9, [rsp+0x90]
000076c1d9dda7fb  vmovaps xmm10, [rsp+0xA0]
000076c1d9dda804  vmovaps xmm11, [rsp+0xB0]
000076c1d9dda80d  vmovaps xmm12, [rsp+0xC0]
000076c1d9dda816  vmovaps xmm13, [rsp+0xD0]
000076c1d9dda81f  vmovaps xmm14, [rsp+0xE0]
000076c1d9dda828  add rsp, 0xF0
000076c1d9dda82f  pop r11
000076c1d9dda831  pop r10
000076c1d9dda833  pop r9
000076c1d9dda835  pop r8
000076c1d9dda837  pop rsi
000076c1d9dda838  pop rdi
000076c1d9dda839  pop rdx
000076c1d9dda83a  pop rcx
000076c1d9dda83b  pop rax
000076c1d9dda83c  add rsp, 0x08
000076c1d9dda840  jmp 0x000076C1D9DD64A5
000076c1d9dda845  sub rsp, 0x08
000076c1d9dda849  push rax
000076c1d9dda84a  push rcx
000076c1d9dda84b  push rdx
000076c1d9dda84c  push rdi
000076c1d9dda84d  push rsi
000076c1d9dda84e  push r8
000076c1d9dda850  push r9
000076c1d9dda852  push r10
000076c1d9dda854  push r11
000076c1d9dda856  sub rsp, 0xF0
000076c1d9dda85d  vmovaps [rsp], xmm0
000076c1d9dda862  vmovaps [rsp+0x10], xmm1
000076c1d9dda868  vmovaps [rsp+0x20], xmm2
000076c1d9dda86e  vmovaps [rsp+0x30], xmm3
000076c1d9dda874  vmovaps [rsp+0x40], xmm4
000076c1d9dda87a  vmovaps [rsp+0x50], xmm5
000076c1d9dda880  vmovaps [rsp+0x60], xmm6
000076c1d9dda886  vmovaps [rsp+0x70], xmm8
000076c1d9dda88c  vmovaps [rsp+0x80], xmm9
000076c1d9dda895  vmovaps [rsp+0x90], xmm10
000076c1d9dda89e  vmovaps [rsp+0xA0], xmm11
000076c1d9dda8a7  vmovaps [rsp+0xB0], xmm12
000076c1d9dda8b0  vmovaps [rsp+0xC0], xmm13
000076c1d9dda8b9  vmovaps [rsp+0xD0], xmm14
000076c1d9dda8c2  vmovaps [rsp+0xE0], xmm15
000076c1d9dda8cb  sub rsp, 0x30
000076c1d9dda8cf  movaps [rsp], xmm7
000076c1d9dda8d3  movaps [rsp+0x10], xmm11
000076c1d9dda8d9  movaps [rsp+0x20], xmm9
000076c1d9dda8df  lea rdi, [rsp]
000076c1d9dda8e3  mov esi, 0x00
000076c1d9dda8e8  mov rax, 0x5EA58B9E0530
000076c1d9dda8f2  call rax
000076c1d9dda8f4  movaps xmm7, [rsp]
000076c1d9dda8f8  add rsp, 0x30
000076c1d9dda8fc  vmovaps xmm0, [rsp]
000076c1d9dda901  vmovaps xmm1, [rsp+0x10]
000076c1d9dda907  vmovaps xmm2, [rsp+0x20]
000076c1d9dda90d  vmovaps xmm3, [rsp+0x30]
000076c1d9dda913  vmovaps xmm4, [rsp+0x40]
000076c1d9dda919  vmovaps xmm5, [rsp+0x50]
000076c1d9dda91f  vmovaps xmm6, [rsp+0x60]
000076c1d9dda925  vmovaps xmm8, [rsp+0x70]
000076c1d9dda92b  vmovaps xmm9, [rsp+0x80]
000076c1d9dda934  vmovaps xmm10, [rsp+0x90]
000076c1d9dda93d  vmovaps xmm11, [rsp+0xA0]
000076c1d9dda946  vmovaps xmm12, [rsp+0xB0]
000076c1d9dda94f  vmovaps xmm13, [rsp+0xC0]
000076c1d9dda958  vmovaps xmm14, [rsp+0xD0]
000076c1d9dda961  vmovaps xmm15, [rsp+0xE0]
000076c1d9dda96a  add rsp, 0xF0
000076c1d9dda971  pop r11
000076c1d9dda973  pop r10
000076c1d9dda975  pop r9
000076c1d9dda977  pop r8
000076c1d9dda979  pop rsi
000076c1d9dda97a  pop rdi
000076c1d9dda97b  pop rdx
000076c1d9dda97c  pop rcx
000076c1d9dda97d  pop rax
000076c1d9dda97e  add rsp, 0x08
000076c1d9dda982  jmp 0x000076C1D9DD64D2
000076c1d9dda987  sub rsp, 0x08
000076c1d9dda98b  push rax
000076c1d9dda98c  push rcx
000076c1d9dda98d  push rdx
000076c1d9dda98e  push rdi
000076c1d9dda98f  push rsi
000076c1d9dda990  push r8
000076c1d9dda992  push r9
000076c1d9dda994  push r10
000076c1d9dda996  push r11
000076c1d9dda998  sub rsp, 0xF0
000076c1d9dda99f  vmovaps [rsp], xmm0
000076c1d9dda9a4  vmovaps [rsp+0x10], xmm1
000076c1d9dda9aa  vmovaps [rsp+0x20], xmm2
000076c1d9dda9b0  vmovaps [rsp+0x30], xmm3
000076c1d9dda9b6  vmovaps [rsp+0x40], xmm4
000076c1d9dda9bc  vmovaps [rsp+0x50], xmm5
000076c1d9dda9c2  vmovaps [rsp+0x60], xmm6
000076c1d9dda9c8  vmovaps [rsp+0x70], xmm7
000076c1d9dda9ce  vmovaps [rsp+0x80], xmm8
000076c1d9dda9d7  vmovaps [rsp+0x90], xmm9
000076c1d9dda9e0  vmovaps [rsp+0xA0], xmm10
000076c1d9dda9e9  vmovaps [rsp+0xB0], xmm12
000076c1d9dda9f2  vmovaps [rsp+0xC0], xmm13
000076c1d9dda9fb  vmovaps [rsp+0xD0], xmm14
000076c1d9ddaa04  vmovaps [rsp+0xE0], xmm15
000076c1d9ddaa0d  sub rsp, 0x30
000076c1d9ddaa11  movaps [rsp], xmm11
000076c1d9ddaa16  movaps [rsp+0x10], xmm10
000076c1d9ddaa1c  movaps [rsp+0x20], xmm14
000076c1d9ddaa22  lea rdi, [rsp]
000076c1d9ddaa26  mov esi, 0x00
000076c1d9ddaa2b  mov rax, 0x5EA58B9E0530
000076c1d9ddaa35  call rax
000076c1d9ddaa37  movaps xmm11, [rsp]
000076c1d9ddaa3c  add rsp, 0x30
000076c1d9ddaa40  vmovaps xmm0, [rsp]
000076c1d9ddaa45  vmovaps xmm1, [rsp+0x10]
000076c1d9ddaa4b  vmovaps xmm2, [rsp+0x20]
000076c1d9ddaa51  vmovaps xmm3, [rsp+0x30]
000076c1d9ddaa57  vmovaps xmm4, [rsp+0x40]
000076c1d9ddaa5d  vmovaps xmm5, [rsp+0x50]
000076c1d9ddaa63  vmovaps xmm6, [rsp+0x60]
000076c1d9ddaa69  vmovaps xmm7, [rsp+0x70]
000076c1d9ddaa6f  vmovaps xmm8, [rsp+0x80]
000076c1d9ddaa78  vmovaps xmm9, [rsp+0x90]
000076c1d9ddaa81  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddaa8a  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddaa93  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddaa9c  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddaaa5  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddaaae  add rsp, 0xF0
000076c1d9ddaab5  pop r11
000076c1d9ddaab7  pop r10
000076c1d9ddaab9  pop r9
000076c1d9ddaabb  pop r8
000076c1d9ddaabd  pop rsi
000076c1d9ddaabe  pop rdi
000076c1d9ddaabf  pop rdx
000076c1d9ddaac0  pop rcx
000076c1d9ddaac1  pop rax
000076c1d9ddaac2  add rsp, 0x08
000076c1d9ddaac6  jmp 0x000076C1D9DD64ED
000076c1d9ddaacb  call 0x000076C1D9CE45A0
000076c1d9ddaad0  jmp 0x000076C1D9DD64F7
000076c1d9ddaad5  sub rsp, 0x08
000076c1d9ddaad9  push rax
000076c1d9ddaada  push rcx
000076c1d9ddaadb  push rdx
000076c1d9ddaadc  push rdi
000076c1d9ddaadd  push rsi
000076c1d9ddaade  push r8
000076c1d9ddaae0  push r9
000076c1d9ddaae2  push r10
000076c1d9ddaae4  push r11
000076c1d9ddaae6  sub rsp, 0xF0
000076c1d9ddaaed  vmovaps [rsp], xmm0
000076c1d9ddaaf2  vmovaps [rsp+0x10], xmm1
000076c1d9ddaaf8  vmovaps [rsp+0x20], xmm2
000076c1d9ddaafe  vmovaps [rsp+0x30], xmm3
000076c1d9ddab04  vmovaps [rsp+0x40], xmm4
000076c1d9ddab0a  vmovaps [rsp+0x50], xmm5
000076c1d9ddab10  vmovaps [rsp+0x60], xmm6
000076c1d9ddab16  vmovaps [rsp+0x70], xmm7
000076c1d9ddab1c  vmovaps [rsp+0x80], xmm8
000076c1d9ddab25  vmovaps [rsp+0x90], xmm9
000076c1d9ddab2e  vmovaps [rsp+0xA0], xmm11
000076c1d9ddab37  vmovaps [rsp+0xB0], xmm12
000076c1d9ddab40  vmovaps [rsp+0xC0], xmm13
000076c1d9ddab49  vmovaps [rsp+0xD0], xmm14
000076c1d9ddab52  vmovaps [rsp+0xE0], xmm15
000076c1d9ddab5b  sub rsp, 0x30
000076c1d9ddab5f  movaps [rsp], xmm10
000076c1d9ddab64  movaps [rsp+0x10], xmm1
000076c1d9ddab69  movaps [rsp+0x20], xmm12
000076c1d9ddab6f  lea rdi, [rsp]
000076c1d9ddab73  mov esi, 0x00
000076c1d9ddab78  mov rax, 0x5EA58B9E0530
000076c1d9ddab82  call rax
000076c1d9ddab84  movaps xmm10, [rsp]
000076c1d9ddab89  add rsp, 0x30
000076c1d9ddab8d  vmovaps xmm0, [rsp]
000076c1d9ddab92  vmovaps xmm1, [rsp+0x10]
000076c1d9ddab98  vmovaps xmm2, [rsp+0x20]
000076c1d9ddab9e  vmovaps xmm3, [rsp+0x30]
000076c1d9ddaba4  vmovaps xmm4, [rsp+0x40]
000076c1d9ddabaa  vmovaps xmm5, [rsp+0x50]
000076c1d9ddabb0  vmovaps xmm6, [rsp+0x60]
000076c1d9ddabb6  vmovaps xmm7, [rsp+0x70]
000076c1d9ddabbc  vmovaps xmm8, [rsp+0x80]
000076c1d9ddabc5  vmovaps xmm9, [rsp+0x90]
000076c1d9ddabce  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddabd7  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddabe0  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddabe9  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddabf2  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddabfb  add rsp, 0xF0
000076c1d9ddac02  pop r11
000076c1d9ddac04  pop r10
000076c1d9ddac06  pop r9
000076c1d9ddac08  pop r8
000076c1d9ddac0a  pop rsi
000076c1d9ddac0b  pop rdi
000076c1d9ddac0c  pop rdx
000076c1d9ddac0d  pop rcx
000076c1d9ddac0e  pop rax
000076c1d9ddac0f  add rsp, 0x08
000076c1d9ddac13  jmp 0x000076C1D9DD651A
000076c1d9ddac18  sub rsp, 0x08
000076c1d9ddac1c  push rax
000076c1d9ddac1d  push rcx
000076c1d9ddac1e  push rdx
000076c1d9ddac1f  push rdi
000076c1d9ddac20  push rsi
000076c1d9ddac21  push r8
000076c1d9ddac23  push r9
000076c1d9ddac25  push r10
000076c1d9ddac27  push r11
000076c1d9ddac29  sub rsp, 0xF0
000076c1d9ddac30  vmovaps [rsp], xmm0
000076c1d9ddac35  vmovaps [rsp+0x10], xmm1
000076c1d9ddac3b  vmovaps [rsp+0x20], xmm2
000076c1d9ddac41  vmovaps [rsp+0x30], xmm3
000076c1d9ddac47  vmovaps [rsp+0x40], xmm4
000076c1d9ddac4d  vmovaps [rsp+0x50], xmm5
000076c1d9ddac53  vmovaps [rsp+0x60], xmm6
000076c1d9ddac59  vmovaps [rsp+0x70], xmm7
000076c1d9ddac5f  vmovaps [rsp+0x80], xmm8
000076c1d9ddac68  vmovaps [rsp+0x90], xmm9
000076c1d9ddac71  vmovaps [rsp+0xA0], xmm10
000076c1d9ddac7a  vmovaps [rsp+0xB0], xmm11
000076c1d9ddac83  vmovaps [rsp+0xC0], xmm13
000076c1d9ddac8c  vmovaps [rsp+0xD0], xmm14
000076c1d9ddac95  vmovaps [rsp+0xE0], xmm15
000076c1d9ddac9e  sub rsp, 0x30
000076c1d9ddaca2  movaps [rsp], xmm12
000076c1d9ddaca7  movaps [rsp+0x10], xmm14
000076c1d9ddacad  movaps [rsp+0x20], xmm1
000076c1d9ddacb2  lea rdi, [rsp]
000076c1d9ddacb6  mov esi, 0x00
000076c1d9ddacbb  mov rax, 0x5EA58B9E0530
000076c1d9ddacc5  call rax
000076c1d9ddacc7  movaps xmm12, [rsp]
000076c1d9ddaccc  add rsp, 0x30
000076c1d9ddacd0  vmovaps xmm0, [rsp]
000076c1d9ddacd5  vmovaps xmm1, [rsp+0x10]
000076c1d9ddacdb  vmovaps xmm2, [rsp+0x20]
000076c1d9ddace1  vmovaps xmm3, [rsp+0x30]
000076c1d9ddace7  vmovaps xmm4, [rsp+0x40]
000076c1d9ddaced  vmovaps xmm5, [rsp+0x50]
000076c1d9ddacf3  vmovaps xmm6, [rsp+0x60]
000076c1d9ddacf9  vmovaps xmm7, [rsp+0x70]
000076c1d9ddacff  vmovaps xmm8, [rsp+0x80]
000076c1d9ddad08  vmovaps xmm9, [rsp+0x90]
000076c1d9ddad11  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddad1a  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddad23  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddad2c  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddad35  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddad3e  add rsp, 0xF0
000076c1d9ddad45  pop r11
000076c1d9ddad47  pop r10
000076c1d9ddad49  pop r9
000076c1d9ddad4b  pop r8
000076c1d9ddad4d  pop rsi
000076c1d9ddad4e  pop rdi
000076c1d9ddad4f  pop rdx
000076c1d9ddad50  pop rcx
000076c1d9ddad51  pop rax
000076c1d9ddad52  add rsp, 0x08
000076c1d9ddad56  jmp 0x000076C1D9DD6549
000076c1d9ddad5b  sub rsp, 0x08
000076c1d9ddad5f  push rax
000076c1d9ddad60  push rcx
000076c1d9ddad61  push rdx
000076c1d9ddad62  push rdi
000076c1d9ddad63  push rsi
000076c1d9ddad64  push r8
000076c1d9ddad66  push r9
000076c1d9ddad68  push r10
000076c1d9ddad6a  push r11
000076c1d9ddad6c  sub rsp, 0xF0
000076c1d9ddad73  vmovaps [rsp], xmm0
000076c1d9ddad78  vmovaps [rsp+0x10], xmm1
000076c1d9ddad7e  vmovaps [rsp+0x20], xmm2
000076c1d9ddad84  vmovaps [rsp+0x30], xmm3
000076c1d9ddad8a  vmovaps [rsp+0x40], xmm4
000076c1d9ddad90  vmovaps [rsp+0x50], xmm5
000076c1d9ddad96  vmovaps [rsp+0x60], xmm6
000076c1d9ddad9c  vmovaps [rsp+0x70], xmm7
000076c1d9ddada2  vmovaps [rsp+0x80], xmm8
000076c1d9ddadab  vmovaps [rsp+0x90], xmm9
000076c1d9ddadb4  vmovaps [rsp+0xA0], xmm10
000076c1d9ddadbd  vmovaps [rsp+0xB0], xmm11
000076c1d9ddadc6  vmovaps [rsp+0xC0], xmm12
000076c1d9ddadcf  vmovaps [rsp+0xD0], xmm13
000076c1d9ddadd8  vmovaps [rsp+0xE0], xmm15
000076c1d9ddade1  sub rsp, 0x30
000076c1d9ddade5  movaps [rsp], xmm14
000076c1d9ddadea  movaps [rsp+0x10], xmm9
000076c1d9ddadf0  movaps [rsp+0x20], xmm1
000076c1d9ddadf5  lea rdi, [rsp]
000076c1d9ddadf9  mov esi, 0x00
000076c1d9ddadfe  mov rax, 0x5EA58B9E0530
000076c1d9ddae08  call rax
000076c1d9ddae0a  movaps xmm14, [rsp]
000076c1d9ddae0f  add rsp, 0x30
000076c1d9ddae13  vmovaps xmm0, [rsp]
000076c1d9ddae18  vmovaps xmm1, [rsp+0x10]
000076c1d9ddae1e  vmovaps xmm2, [rsp+0x20]
000076c1d9ddae24  vmovaps xmm3, [rsp+0x30]
000076c1d9ddae2a  vmovaps xmm4, [rsp+0x40]
000076c1d9ddae30  vmovaps xmm5, [rsp+0x50]
000076c1d9ddae36  vmovaps xmm6, [rsp+0x60]
000076c1d9ddae3c  vmovaps xmm7, [rsp+0x70]
000076c1d9ddae42  vmovaps xmm8, [rsp+0x80]
000076c1d9ddae4b  vmovaps xmm9, [rsp+0x90]
000076c1d9ddae54  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddae5d  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddae66  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddae6f  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddae78  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddae81  add rsp, 0xF0
000076c1d9ddae88  pop r11
000076c1d9ddae8a  pop r10
000076c1d9ddae8c  pop r9
000076c1d9ddae8e  pop r8
000076c1d9ddae90  pop rsi
000076c1d9ddae91  pop rdi
000076c1d9ddae92  pop rdx
000076c1d9ddae93  pop rcx
000076c1d9ddae94  pop rax
000076c1d9ddae95  add rsp, 0x08
000076c1d9ddae99  jmp 0x000076C1D9DD6578
000076c1d9ddae9e  sub rsp, 0x08
000076c1d9ddaea2  push rax
000076c1d9ddaea3  push rcx
000076c1d9ddaea4  push rdx
000076c1d9ddaea5  push rdi
000076c1d9ddaea6  push rsi
000076c1d9ddaea7  push r8
000076c1d9ddaea9  push r9
000076c1d9ddaeab  push r10
000076c1d9ddaead  push r11
000076c1d9ddaeaf  sub rsp, 0xF0
000076c1d9ddaeb6  vmovaps [rsp], xmm0
000076c1d9ddaebb  vmovaps [rsp+0x10], xmm2
000076c1d9ddaec1  vmovaps [rsp+0x20], xmm3
000076c1d9ddaec7  vmovaps [rsp+0x30], xmm4
000076c1d9ddaecd  vmovaps [rsp+0x40], xmm5
000076c1d9ddaed3  vmovaps [rsp+0x50], xmm6
000076c1d9ddaed9  vmovaps [rsp+0x60], xmm7
000076c1d9ddaedf  vmovaps [rsp+0x70], xmm8
000076c1d9ddaee5  vmovaps [rsp+0x80], xmm9
000076c1d9ddaeee  vmovaps [rsp+0x90], xmm10
000076c1d9ddaef7  vmovaps [rsp+0xA0], xmm11
000076c1d9ddaf00  vmovaps [rsp+0xB0], xmm12
000076c1d9ddaf09  vmovaps [rsp+0xC0], xmm13
000076c1d9ddaf12  vmovaps [rsp+0xD0], xmm14
000076c1d9ddaf1b  vmovaps [rsp+0xE0], xmm15
000076c1d9ddaf24  sub rsp, 0x30
000076c1d9ddaf28  movaps [rsp], xmm1
000076c1d9ddaf2c  movaps [rsp+0x10], xmm13
000076c1d9ddaf32  movaps [rsp+0x20], xmm8
000076c1d9ddaf38  lea rdi, [rsp]
000076c1d9ddaf3c  mov esi, 0x00
000076c1d9ddaf41  mov rax, 0x5EA58B9E0530
000076c1d9ddaf4b  call rax
000076c1d9ddaf4d  movaps xmm1, [rsp]
000076c1d9ddaf51  add rsp, 0x30
000076c1d9ddaf55  vmovaps xmm0, [rsp]
000076c1d9ddaf5a  vmovaps xmm2, [rsp+0x10]
000076c1d9ddaf60  vmovaps xmm3, [rsp+0x20]
000076c1d9ddaf66  vmovaps xmm4, [rsp+0x30]
000076c1d9ddaf6c  vmovaps xmm5, [rsp+0x40]
000076c1d9ddaf72  vmovaps xmm6, [rsp+0x50]
000076c1d9ddaf78  vmovaps xmm7, [rsp+0x60]
000076c1d9ddaf7e  vmovaps xmm8, [rsp+0x70]
000076c1d9ddaf84  vmovaps xmm9, [rsp+0x80]
000076c1d9ddaf8d  vmovaps xmm10, [rsp+0x90]
000076c1d9ddaf96  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddaf9f  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddafa8  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddafb1  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddafba  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddafc3  add rsp, 0xF0
000076c1d9ddafca  pop r11
000076c1d9ddafcc  pop r10
000076c1d9ddafce  pop r9
000076c1d9ddafd0  pop r8
000076c1d9ddafd2  pop rsi
000076c1d9ddafd3  pop rdi
000076c1d9ddafd4  pop rdx
000076c1d9ddafd5  pop rcx
000076c1d9ddafd6  pop rax
000076c1d9ddafd7  add rsp, 0x08
000076c1d9ddafdb  jmp 0x000076C1D9DD659A
000076c1d9ddafe0  call 0x000076C1D9C0C260
000076c1d9ddafe5  jmp 0x000076C1D9DD65A8
000076c1d9ddafea  call 0x000076C1D9CDE950
000076c1d9ddafef  jmp 0x000076C1D9DD65B2
000076c1d9ddaff4  sub rsp, 0x08
000076c1d9ddaff8  push rax
000076c1d9ddaff9  push rcx
000076c1d9ddaffa  push rdx
000076c1d9ddaffb  push rdi
000076c1d9ddaffc  push rsi
000076c1d9ddaffd  push r8
000076c1d9ddafff  push r9
000076c1d9ddb001  push r10
000076c1d9ddb003  push r11
000076c1d9ddb005  sub rsp, 0xF0
000076c1d9ddb00c  vmovaps [rsp], xmm0
000076c1d9ddb011  vmovaps [rsp+0x10], xmm1
000076c1d9ddb017  vmovaps [rsp+0x20], xmm2
000076c1d9ddb01d  vmovaps [rsp+0x30], xmm3
000076c1d9ddb023  vmovaps [rsp+0x40], xmm4
000076c1d9ddb029  vmovaps [rsp+0x50], xmm5
000076c1d9ddb02f  vmovaps [rsp+0x60], xmm6
000076c1d9ddb035  vmovaps [rsp+0x70], xmm7
000076c1d9ddb03b  vmovaps [rsp+0x80], xmm9
000076c1d9ddb044  vmovaps [rsp+0x90], xmm10
000076c1d9ddb04d  vmovaps [rsp+0xA0], xmm11
000076c1d9ddb056  vmovaps [rsp+0xB0], xmm12
000076c1d9ddb05f  vmovaps [rsp+0xC0], xmm13
000076c1d9ddb068  vmovaps [rsp+0xD0], xmm14
000076c1d9ddb071  vmovaps [rsp+0xE0], xmm15
000076c1d9ddb07a  sub rsp, 0x30
000076c1d9ddb07e  movaps [rsp], xmm8
000076c1d9ddb083  movaps [rsp+0x10], xmm15
000076c1d9ddb089  movaps [rsp+0x20], xmm7
000076c1d9ddb08e  lea rdi, [rsp]
000076c1d9ddb092  mov esi, 0x00
000076c1d9ddb097  mov rax, 0x5EA58B9E0530
000076c1d9ddb0a1  call rax
000076c1d9ddb0a3  movaps xmm8, [rsp]
000076c1d9ddb0a8  add rsp, 0x30
000076c1d9ddb0ac  vmovaps xmm0, [rsp]
000076c1d9ddb0b1  vmovaps xmm1, [rsp+0x10]
000076c1d9ddb0b7  vmovaps xmm2, [rsp+0x20]
000076c1d9ddb0bd  vmovaps xmm3, [rsp+0x30]
000076c1d9ddb0c3  vmovaps xmm4, [rsp+0x40]
000076c1d9ddb0c9  vmovaps xmm5, [rsp+0x50]
000076c1d9ddb0cf  vmovaps xmm6, [rsp+0x60]
000076c1d9ddb0d5  vmovaps xmm7, [rsp+0x70]
000076c1d9ddb0db  vmovaps xmm9, [rsp+0x80]
000076c1d9ddb0e4  vmovaps xmm10, [rsp+0x90]
000076c1d9ddb0ed  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddb0f6  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddb0ff  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddb108  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddb111  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddb11a  add rsp, 0xF0
000076c1d9ddb121  pop r11
000076c1d9ddb123  pop r10
000076c1d9ddb125  pop r9
000076c1d9ddb127  pop r8
000076c1d9ddb129  pop rsi
000076c1d9ddb12a  pop rdi
000076c1d9ddb12b  pop rdx
000076c1d9ddb12c  pop rcx
000076c1d9ddb12d  pop rax
000076c1d9ddb12e  add rsp, 0x08
000076c1d9ddb132  jmp 0x000076C1D9DD65D4
000076c1d9ddb137  sub rsp, 0x08
000076c1d9ddb13b  push rax
000076c1d9ddb13c  push rcx
000076c1d9ddb13d  push rdx
000076c1d9ddb13e  push rdi
000076c1d9ddb13f  push rsi
000076c1d9ddb140  push r8
000076c1d9ddb142  push r9
000076c1d9ddb144  push r10
000076c1d9ddb146  push r11
000076c1d9ddb148  sub rsp, 0xF0
000076c1d9ddb14f  vmovaps [rsp], xmm0
000076c1d9ddb154  vmovaps [rsp+0x10], xmm1
000076c1d9ddb15a  vmovaps [rsp+0x20], xmm2
000076c1d9ddb160  vmovaps [rsp+0x30], xmm3
000076c1d9ddb166  vmovaps [rsp+0x40], xmm4
000076c1d9ddb16c  vmovaps [rsp+0x50], xmm5
000076c1d9ddb172  vmovaps [rsp+0x60], xmm6
000076c1d9ddb178  vmovaps [rsp+0x70], xmm8
000076c1d9ddb17e  vmovaps [rsp+0x80], xmm9
000076c1d9ddb187  vmovaps [rsp+0x90], xmm10
000076c1d9ddb190  vmovaps [rsp+0xA0], xmm11
000076c1d9ddb199  vmovaps [rsp+0xB0], xmm12
000076c1d9ddb1a2  vmovaps [rsp+0xC0], xmm13
000076c1d9ddb1ab  vmovaps [rsp+0xD0], xmm14
000076c1d9ddb1b4  vmovaps [rsp+0xE0], xmm15
000076c1d9ddb1bd  sub rsp, 0x30
000076c1d9ddb1c1  movaps [rsp], xmm7
000076c1d9ddb1c5  movaps [rsp+0x10], xmm9
000076c1d9ddb1cb  movaps [rsp+0x20], xmm15
000076c1d9ddb1d1  lea rdi, [rsp]
000076c1d9ddb1d5  mov esi, 0x00
000076c1d9ddb1da  mov rax, 0x5EA58B9E0530
000076c1d9ddb1e4  call rax
000076c1d9ddb1e6  movaps xmm7, [rsp]
000076c1d9ddb1ea  add rsp, 0x30
000076c1d9ddb1ee  vmovaps xmm0, [rsp]
000076c1d9ddb1f3  vmovaps xmm1, [rsp+0x10]
000076c1d9ddb1f9  vmovaps xmm2, [rsp+0x20]
000076c1d9ddb1ff  vmovaps xmm3, [rsp+0x30]
000076c1d9ddb205  vmovaps xmm4, [rsp+0x40]
000076c1d9ddb20b  vmovaps xmm5, [rsp+0x50]
000076c1d9ddb211  vmovaps xmm6, [rsp+0x60]
000076c1d9ddb217  vmovaps xmm8, [rsp+0x70]
000076c1d9ddb21d  vmovaps xmm9, [rsp+0x80]
000076c1d9ddb226  vmovaps xmm10, [rsp+0x90]
000076c1d9ddb22f  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddb238  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddb241  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddb24a  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddb253  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddb25c  add rsp, 0xF0
000076c1d9ddb263  pop r11
000076c1d9ddb265  pop r10
000076c1d9ddb267  pop r9
000076c1d9ddb269  pop r8
000076c1d9ddb26b  pop rsi
000076c1d9ddb26c  pop rdi
000076c1d9ddb26d  pop rdx
000076c1d9ddb26e  pop rcx
000076c1d9ddb26f  pop rax
000076c1d9ddb270  add rsp, 0x08
000076c1d9ddb274  jmp 0x000076C1D9DD6601
000076c1d9ddb279  sub rsp, 0x08
000076c1d9ddb27d  push rax
000076c1d9ddb27e  push rcx
000076c1d9ddb27f  push rdx
000076c1d9ddb280  push rdi
000076c1d9ddb281  push rsi
000076c1d9ddb282  push r8
000076c1d9ddb284  push r9
000076c1d9ddb286  push r10
000076c1d9ddb288  push r11
000076c1d9ddb28a  sub rsp, 0xF0
000076c1d9ddb291  vmovaps [rsp], xmm0
000076c1d9ddb296  vmovaps [rsp+0x10], xmm1
000076c1d9ddb29c  vmovaps [rsp+0x20], xmm2
000076c1d9ddb2a2  vmovaps [rsp+0x30], xmm3
000076c1d9ddb2a8  vmovaps [rsp+0x40], xmm4
000076c1d9ddb2ae  vmovaps [rsp+0x50], xmm5
000076c1d9ddb2b4  vmovaps [rsp+0x60], xmm6
000076c1d9ddb2ba  vmovaps [rsp+0x70], xmm7
000076c1d9ddb2c0  vmovaps [rsp+0x80], xmm8
000076c1d9ddb2c9  vmovaps [rsp+0x90], xmm10
000076c1d9ddb2d2  vmovaps [rsp+0xA0], xmm11
000076c1d9ddb2db  vmovaps [rsp+0xB0], xmm12
000076c1d9ddb2e4  vmovaps [rsp+0xC0], xmm13
000076c1d9ddb2ed  vmovaps [rsp+0xD0], xmm14
000076c1d9ddb2f6  vmovaps [rsp+0xE0], xmm15
000076c1d9ddb2ff  sub rsp, 0x30
000076c1d9ddb303  movaps [rsp], xmm9
000076c1d9ddb308  movaps [rsp+0x10], xmm13
000076c1d9ddb30e  movaps [rsp+0x20], xmm15
000076c1d9ddb314  lea rdi, [rsp]
000076c1d9ddb318  mov esi, 0x00
000076c1d9ddb31d  mov rax, 0x5EA58B9E0530
000076c1d9ddb327  call rax
000076c1d9ddb329  movaps xmm9, [rsp]
000076c1d9ddb32e  add rsp, 0x30
000076c1d9ddb332  vmovaps xmm0, [rsp]
000076c1d9ddb337  vmovaps xmm1, [rsp+0x10]
000076c1d9ddb33d  vmovaps xmm2, [rsp+0x20]
000076c1d9ddb343  vmovaps xmm3, [rsp+0x30]
000076c1d9ddb349  vmovaps xmm4, [rsp+0x40]
000076c1d9ddb34f  vmovaps xmm5, [rsp+0x50]
000076c1d9ddb355  vmovaps xmm6, [rsp+0x60]
000076c1d9ddb35b  vmovaps xmm7, [rsp+0x70]
000076c1d9ddb361  vmovaps xmm8, [rsp+0x80]
000076c1d9ddb36a  vmovaps xmm10, [rsp+0x90]
000076c1d9ddb373  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddb37c  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddb385  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddb38e  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddb397  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddb3a0  add rsp, 0xF0
000076c1d9ddb3a7  pop r11
000076c1d9ddb3a9  pop r10
000076c1d9ddb3ab  pop r9
000076c1d9ddb3ad  pop r8
000076c1d9ddb3af  pop rsi
000076c1d9ddb3b0  pop rdi
000076c1d9ddb3b1  pop rdx
000076c1d9ddb3b2  pop rcx
000076c1d9ddb3b3  pop rax
000076c1d9ddb3b4  add rsp, 0x08
000076c1d9ddb3b8  jmp 0x000076C1D9DD662F
000076c1d9ddb3bd  sub rsp, 0x08
000076c1d9ddb3c1  push rax
000076c1d9ddb3c2  push rcx
000076c1d9ddb3c3  push rdx
000076c1d9ddb3c4  push rdi
000076c1d9ddb3c5  push rsi
000076c1d9ddb3c6  push r8
000076c1d9ddb3c8  push r9
000076c1d9ddb3ca  push r10
000076c1d9ddb3cc  push r11
000076c1d9ddb3ce  sub rsp, 0xF0
000076c1d9ddb3d5  vmovaps [rsp], xmm0
000076c1d9ddb3da  vmovaps [rsp+0x10], xmm1
000076c1d9ddb3e0  vmovaps [rsp+0x20], xmm2
000076c1d9ddb3e6  vmovaps [rsp+0x30], xmm3
000076c1d9ddb3ec  vmovaps [rsp+0x40], xmm4
000076c1d9ddb3f2  vmovaps [rsp+0x50], xmm5
000076c1d9ddb3f8  vmovaps [rsp+0x60], xmm6
000076c1d9ddb3fe  vmovaps [rsp+0x70], xmm7
000076c1d9ddb404  vmovaps [rsp+0x80], xmm8
000076c1d9ddb40d  vmovaps [rsp+0x90], xmm9
000076c1d9ddb416  vmovaps [rsp+0xA0], xmm10
000076c1d9ddb41f  vmovaps [rsp+0xB0], xmm11
000076c1d9ddb428  vmovaps [rsp+0xC0], xmm12
000076c1d9ddb431  vmovaps [rsp+0xD0], xmm13
000076c1d9ddb43a  vmovaps [rsp+0xE0], xmm14
000076c1d9ddb443  sub rsp, 0x30
000076c1d9ddb447  movaps [rsp], xmm15
000076c1d9ddb44c  movaps [rsp+0x10], xmm11
000076c1d9ddb452  movaps [rsp+0x20], xmm12
000076c1d9ddb458  lea rdi, [rsp]
000076c1d9ddb45c  mov esi, 0x00
000076c1d9ddb461  mov rax, 0x5EA58B9E0530
000076c1d9ddb46b  call rax
000076c1d9ddb46d  movaps xmm15, [rsp]
000076c1d9ddb472  add rsp, 0x30
000076c1d9ddb476  vmovaps xmm0, [rsp]
000076c1d9ddb47b  vmovaps xmm1, [rsp+0x10]
000076c1d9ddb481  vmovaps xmm2, [rsp+0x20]
000076c1d9ddb487  vmovaps xmm3, [rsp+0x30]
000076c1d9ddb48d  vmovaps xmm4, [rsp+0x40]
000076c1d9ddb493  vmovaps xmm5, [rsp+0x50]
000076c1d9ddb499  vmovaps xmm6, [rsp+0x60]
000076c1d9ddb49f  vmovaps xmm7, [rsp+0x70]
000076c1d9ddb4a5  vmovaps xmm8, [rsp+0x80]
000076c1d9ddb4ae  vmovaps xmm9, [rsp+0x90]
000076c1d9ddb4b7  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddb4c0  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddb4c9  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddb4d2  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddb4db  vmovaps xmm14, [rsp+0xE0]
000076c1d9ddb4e4  add rsp, 0xF0
000076c1d9ddb4eb  pop r11
000076c1d9ddb4ed  pop r10
000076c1d9ddb4ef  pop r9
000076c1d9ddb4f1  pop r8
000076c1d9ddb4f3  pop rsi
000076c1d9ddb4f4  pop rdi
000076c1d9ddb4f5  pop rdx
000076c1d9ddb4f6  pop rcx
000076c1d9ddb4f7  pop rax
000076c1d9ddb4f8  add rsp, 0x08
000076c1d9ddb4fc  jmp 0x000076C1D9DD664A
000076c1d9ddb501  sub rsp, 0x08
000076c1d9ddb505  push rax
000076c1d9ddb506  push rcx
000076c1d9ddb507  push rdx
000076c1d9ddb508  push rdi
000076c1d9ddb509  push rsi
000076c1d9ddb50a  push r8
000076c1d9ddb50c  push r9
000076c1d9ddb50e  push r10
000076c1d9ddb510  push r11
000076c1d9ddb512  sub rsp, 0xF0
000076c1d9ddb519  vmovaps [rsp], xmm0
000076c1d9ddb51e  vmovaps [rsp+0x10], xmm1
000076c1d9ddb524  vmovaps [rsp+0x20], xmm2
000076c1d9ddb52a  vmovaps [rsp+0x30], xmm3
000076c1d9ddb530  vmovaps [rsp+0x40], xmm4
000076c1d9ddb536  vmovaps [rsp+0x50], xmm5
000076c1d9ddb53c  vmovaps [rsp+0x60], xmm6
000076c1d9ddb542  vmovaps [rsp+0x70], xmm7
000076c1d9ddb548  vmovaps [rsp+0x80], xmm8
000076c1d9ddb551  vmovaps [rsp+0x90], xmm9
000076c1d9ddb55a  vmovaps [rsp+0xA0], xmm10
000076c1d9ddb563  vmovaps [rsp+0xB0], xmm11
000076c1d9ddb56c  vmovaps [rsp+0xC0], xmm12
000076c1d9ddb575  vmovaps [rsp+0xD0], xmm14
000076c1d9ddb57e  vmovaps [rsp+0xE0], xmm15
000076c1d9ddb587  sub rsp, 0x30
000076c1d9ddb58b  movaps [rsp], xmm13
000076c1d9ddb590  movaps [rsp+0x10], xmm10
000076c1d9ddb596  movaps [rsp+0x20], xmm14
000076c1d9ddb59c  lea rdi, [rsp]
000076c1d9ddb5a0  mov esi, 0x00
000076c1d9ddb5a5  mov rax, 0x5EA58B9E0530
000076c1d9ddb5af  call rax
000076c1d9ddb5b1  movaps xmm13, [rsp]
000076c1d9ddb5b6  add rsp, 0x30
000076c1d9ddb5ba  vmovaps xmm0, [rsp]
000076c1d9ddb5bf  vmovaps xmm1, [rsp+0x10]
000076c1d9ddb5c5  vmovaps xmm2, [rsp+0x20]
000076c1d9ddb5cb  vmovaps xmm3, [rsp+0x30]
000076c1d9ddb5d1  vmovaps xmm4, [rsp+0x40]
000076c1d9ddb5d7  vmovaps xmm5, [rsp+0x50]
000076c1d9ddb5dd  vmovaps xmm6, [rsp+0x60]
000076c1d9ddb5e3  vmovaps xmm7, [rsp+0x70]
000076c1d9ddb5e9  vmovaps xmm8, [rsp+0x80]
000076c1d9ddb5f2  vmovaps xmm9, [rsp+0x90]
000076c1d9ddb5fb  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddb604  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddb60d  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddb616  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddb61f  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddb628  add rsp, 0xF0
000076c1d9ddb62f  pop r11
000076c1d9ddb631  pop r10
000076c1d9ddb633  pop r9
000076c1d9ddb635  pop r8
000076c1d9ddb637  pop rsi
000076c1d9ddb638  pop rdi
000076c1d9ddb639  pop rdx
000076c1d9ddb63a  pop rcx
000076c1d9ddb63b  pop rax
000076c1d9ddb63c  add rsp, 0x08
000076c1d9ddb640  jmp 0x000076C1D9DD666D
000076c1d9ddb645  sub rsp, 0x08
000076c1d9ddb649  push rax
000076c1d9ddb64a  push rcx
000076c1d9ddb64b  push rdx
000076c1d9ddb64c  push rdi
000076c1d9ddb64d  push rsi
000076c1d9ddb64e  push r8
000076c1d9ddb650  push r9
000076c1d9ddb652  push r10
000076c1d9ddb654  push r11
000076c1d9ddb656  sub rsp, 0xF0
000076c1d9ddb65d  vmovaps [rsp], xmm0
000076c1d9ddb662  vmovaps [rsp+0x10], xmm1
000076c1d9ddb668  vmovaps [rsp+0x20], xmm2
000076c1d9ddb66e  vmovaps [rsp+0x30], xmm3
000076c1d9ddb674  vmovaps [rsp+0x40], xmm4
000076c1d9ddb67a  vmovaps [rsp+0x50], xmm5
000076c1d9ddb680  vmovaps [rsp+0x60], xmm6
000076c1d9ddb686  vmovaps [rsp+0x70], xmm7
000076c1d9ddb68c  vmovaps [rsp+0x80], xmm8
000076c1d9ddb695  vmovaps [rsp+0x90], xmm9
000076c1d9ddb69e  vmovaps [rsp+0xA0], xmm10
000076c1d9ddb6a7  vmovaps [rsp+0xB0], xmm11
000076c1d9ddb6b0  vmovaps [rsp+0xC0], xmm12
000076c1d9ddb6b9  vmovaps [rsp+0xD0], xmm13
000076c1d9ddb6c2  vmovaps [rsp+0xE0], xmm15
000076c1d9ddb6cb  sub rsp, 0x30
000076c1d9ddb6cf  movaps [rsp], xmm14
000076c1d9ddb6d4  movaps [rsp+0x10], xmm1
000076c1d9ddb6d9  movaps [rsp+0x20], xmm7
000076c1d9ddb6de  lea rdi, [rsp]
000076c1d9ddb6e2  mov esi, 0x00
000076c1d9ddb6e7  mov rax, 0x5EA58B9E0530
000076c1d9ddb6f1  call rax
000076c1d9ddb6f3  movaps xmm14, [rsp]
000076c1d9ddb6f8  add rsp, 0x30
000076c1d9ddb6fc  vmovaps xmm0, [rsp]
000076c1d9ddb701  vmovaps xmm1, [rsp+0x10]
000076c1d9ddb707  vmovaps xmm2, [rsp+0x20]
000076c1d9ddb70d  vmovaps xmm3, [rsp+0x30]
000076c1d9ddb713  vmovaps xmm4, [rsp+0x40]
000076c1d9ddb719  vmovaps xmm5, [rsp+0x50]
000076c1d9ddb71f  vmovaps xmm6, [rsp+0x60]
000076c1d9ddb725  vmovaps xmm7, [rsp+0x70]
000076c1d9ddb72b  vmovaps xmm8, [rsp+0x80]
000076c1d9ddb734  vmovaps xmm9, [rsp+0x90]
000076c1d9ddb73d  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddb746  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddb74f  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddb758  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddb761  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddb76a  add rsp, 0xF0
000076c1d9ddb771  pop r11
000076c1d9ddb773  pop r10
000076c1d9ddb775  pop r9
000076c1d9ddb777  pop r8
000076c1d9ddb779  pop rsi
000076c1d9ddb77a  pop rdi
000076c1d9ddb77b  pop rdx
000076c1d9ddb77c  pop rcx
000076c1d9ddb77d  pop rax
000076c1d9ddb77e  add rsp, 0x08
000076c1d9ddb782  jmp 0x000076C1D9DD6690
000076c1d9ddb787  sub rsp, 0x08
000076c1d9ddb78b  push rax
000076c1d9ddb78c  push rcx
000076c1d9ddb78d  push rdx
000076c1d9ddb78e  push rdi
000076c1d9ddb78f  push rsi
000076c1d9ddb790  push r8
000076c1d9ddb792  push r9
000076c1d9ddb794  push r10
000076c1d9ddb796  push r11
000076c1d9ddb798  sub rsp, 0xF0
000076c1d9ddb79f  vmovaps [rsp], xmm0
000076c1d9ddb7a4  vmovaps [rsp+0x10], xmm2
000076c1d9ddb7aa  vmovaps [rsp+0x20], xmm3
000076c1d9ddb7b0  vmovaps [rsp+0x30], xmm4
000076c1d9ddb7b6  vmovaps [rsp+0x40], xmm5
000076c1d9ddb7bc  vmovaps [rsp+0x50], xmm6
000076c1d9ddb7c2  vmovaps [rsp+0x60], xmm7
000076c1d9ddb7c8  vmovaps [rsp+0x70], xmm8
000076c1d9ddb7ce  vmovaps [rsp+0x80], xmm9
000076c1d9ddb7d7  vmovaps [rsp+0x90], xmm10
000076c1d9ddb7e0  vmovaps [rsp+0xA0], xmm11
000076c1d9ddb7e9  vmovaps [rsp+0xB0], xmm12
000076c1d9ddb7f2  vmovaps [rsp+0xC0], xmm13
000076c1d9ddb7fb  vmovaps [rsp+0xD0], xmm14
000076c1d9ddb804  vmovaps [rsp+0xE0], xmm15
000076c1d9ddb80d  sub rsp, 0x30
000076c1d9ddb811  movaps [rsp], xmm1
000076c1d9ddb815  movaps [rsp+0x10], xmm8
000076c1d9ddb81b  movaps [rsp+0x20], xmm9
000076c1d9ddb821  lea rdi, [rsp]
000076c1d9ddb825  mov esi, 0x00
000076c1d9ddb82a  mov rax, 0x5EA58B9E0530
000076c1d9ddb834  call rax
000076c1d9ddb836  movaps xmm1, [rsp]
000076c1d9ddb83a  add rsp, 0x30
000076c1d9ddb83e  vmovaps xmm0, [rsp]
000076c1d9ddb843  vmovaps xmm2, [rsp+0x10]
000076c1d9ddb849  vmovaps xmm3, [rsp+0x20]
000076c1d9ddb84f  vmovaps xmm4, [rsp+0x30]
000076c1d9ddb855  vmovaps xmm5, [rsp+0x40]
000076c1d9ddb85b  vmovaps xmm6, [rsp+0x50]
000076c1d9ddb861  vmovaps xmm7, [rsp+0x60]
000076c1d9ddb867  vmovaps xmm8, [rsp+0x70]
000076c1d9ddb86d  vmovaps xmm9, [rsp+0x80]
000076c1d9ddb876  vmovaps xmm10, [rsp+0x90]
000076c1d9ddb87f  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddb888  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddb891  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddb89a  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddb8a3  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddb8ac  add rsp, 0xF0
000076c1d9ddb8b3  pop r11
000076c1d9ddb8b5  pop r10
000076c1d9ddb8b7  pop r9
000076c1d9ddb8b9  pop r8
000076c1d9ddb8bb  pop rsi
000076c1d9ddb8bc  pop rdi
000076c1d9ddb8bd  pop rdx
000076c1d9ddb8be  pop rcx
000076c1d9ddb8bf  pop rax
000076c1d9ddb8c0  add rsp, 0x08
000076c1d9ddb8c4  jmp 0x000076C1D9DD66B2
000076c1d9ddb8c9  call 0x000076C1D9CB3E40
000076c1d9ddb8ce  jmp 0x000076C1D9DD66C0
000076c1d9ddb8d3  call 0x000076C1D9C0C380
000076c1d9ddb8d8  jmp 0x000076C1D9DD66CA
000076c1d9ddb8dd  call 0x000076C1D9C0D600
000076c1d9ddb8e2  jmp 0x000076C1D9DD66D4
000076c1d9ddb8e7  call 0x000076C1D9BFF540
000076c1d9ddb8ec  jmp 0x000076C1D9DD66DE
000076c1d9ddb8f1  int3
000076c1d9ddb8f2  nop [rax+rax*1], ax
000076c1d9ddb8fb  nop [rax+rax*1], eax
000076c1d9ddb900  mov eax, [r15+0x48]
000076c1d9ddb904  lea r14d, [eax+0x01]
000076c1d9ddb909  mov [rsp+0x10], r14d
000076c1d9ddb90e  mov r14d, r14d
000076c1d9ddb911  mov [r15+0x48], r14
000076c1d9ddb915  xor eax, eax
000076c1d9ddb917  mov r14d, [rsp+0x10]
000076c1d9ddb91c  cmp r14d, 0x1F4
000076c1d9ddb923  cmc
000076c1d9ddb924  lahf
000076c1d9ddb925  seto al
000076c1d9ddb928  mov [r15+0x108], eax
000076c1d9ddb92f  mov eax, [r15+0x108]
000076c1d9ddb936  sahf
000076c1d9ddb937  jnz 0x000076C1D9DDB969
000076c1d9ddb939  cmp dword ptr [r15+0x318], 0x00
000076c1d9ddb941  jz 0x000076C1D9DE1AB0
000076c1d9ddb947  nop [rax+rax*1], ax
000076c1d9ddb950  nop [rax+rax*1], eax
000076c1d9ddb958  mov eax, 0x410450
000076c1d9ddb95d  mov [r15+0x100], rax
000076c1d9ddb964  jmp 0x000076C1D9BFE110
000076c1d9ddb969  cmp dword ptr [r15+0x318], 0x00
000076c1d9ddb971  jz 0x000076C1D9DDB9A0
000076c1d9ddb977  nop [rax+rax*1], ax
000076c1d9ddb980  nop [rax+rax*1], eax
000076c1d9ddb988  mov eax, 0x410274
000076c1d9ddb98d  mov [r15+0x100], rax
000076c1d9ddb994  jmp 0x000076C1D9BFE110
000076c1d9ddb999  int3
000076c1d9ddb99a  int3
000076c1d9ddb99b  nop [rax+rax*1], eax
000076c1d9ddb9a0  mov rax, [r15+0x40]
000076c1d9ddb9a4  movaps xmm1, [r15+0x1D0]
000076c1d9ddb9ac  vmovaps [rsp+0x10], xmm1
000076c1d9ddb9b2  vmovaps xmm15, [rsp+0x10]
000076c1d9ddb9b8  por xmm1, xmm15
000076c1d9ddb9bd  movaps xmm14, [r15+0x1A0]
000076c1d9ddb9c5  vmovaps [rsp+0x10], xmm14
000076c1d9ddb9cb  vmovaps xmm13, [rsp+0x10]
000076c1d9ddb9d1  por xmm14, xmm13
000076c1d9ddb9d6  lea r14, [rax+0x30]
000076c1d9ddb9da  mov r12, [r13+r14*1]
000076c1d9ddb9df  lea r14, [rax+0x38]
000076c1d9ddb9e3  mov r11, [r13+r14*1]
000076c1d9ddb9e8  movq xmm13, r12
000076c1d9ddb9ed  movq xmm12, r11
000076c1d9ddb9f2  movq xmm13, xmm13
000076c1d9ddb9f7  vmovaps [rsp+0x10], xmm13
000076c1d9ddb9fd  movq xmm13, xmm13
000076c1d9ddba02  movaps [r15+0x130], xmm13
000076c1d9ddba0a  movq xmm12, xmm12
000076c1d9ddba0f  vmovaps [rsp+0x20], xmm12
000076c1d9ddba15  movq xmm12, xmm12
000076c1d9ddba1a  movaps [r15+0x280], xmm12
000076c1d9ddba22  movaps xmm13, [r15+0x270]
000076c1d9ddba2a  vmovaps [rsp+0x30], xmm13
000076c1d9ddba30  vmovaps xmm12, [rsp+0x30]
000076c1d9ddba36  por xmm13, xmm12
000076c1d9ddba3b  lea r14, [rax+0x20]
000076c1d9ddba3f  mov r12, [r13+r14*1]
000076c1d9ddba44  lea r14, [rax+0x28]
000076c1d9ddba48  mov r11, [r13+r14*1]
000076c1d9ddba4d  movq xmm12, r12
000076c1d9ddba52  movq xmm11, r11
000076c1d9ddba57  movq xmm12, xmm12
000076c1d9ddba5c  vmovaps [rsp+0x30], xmm12
000076c1d9ddba62  movq xmm12, xmm12
000076c1d9ddba67  movaps [r15+0x150], xmm12
000076c1d9ddba6f  movq xmm11, xmm11
000076c1d9ddba74  vmovaps [rsp+0x40], xmm11
000076c1d9ddba7a  movq xmm11, xmm11
000076c1d9ddba7f  movaps [r15+0x140], xmm11
000076c1d9ddba87  lea r14, [rax+0x10]
000076c1d9ddba8b  mov r12, [r13+r14*1]
000076c1d9ddba90  lea r14, [rax+0x18]
000076c1d9ddba94  mov r11, [r13+r14*1]
000076c1d9ddba99  movq xmm12, r12
000076c1d9ddba9e  movq xmm11, r11
000076c1d9ddbaa3  movq xmm12, xmm12
000076c1d9ddbaa8  vmovaps [rsp+0x50], xmm12
000076c1d9ddbaae  movq xmm12, xmm12
000076c1d9ddbab3  movaps [r15+0x170], xmm12
000076c1d9ddbabb  movq xmm11, xmm11
000076c1d9ddbac0  vmovaps [rsp+0x60], xmm11
000076c1d9ddbac6  movq xmm11, xmm11
000076c1d9ddbacb  movaps [r15+0x160], xmm11
000076c1d9ddbad3  mov r14, [r13+rax*1]
000076c1d9ddbad8  vmovq xmm12, r14
000076c1d9ddbadd  vpbroadcastq xmm12, xmm12
000076c1d9ddbae2  lea r14, [rax+0x08]
000076c1d9ddbae6  mov rax, [r13+r14*1]
000076c1d9ddbaeb  movq xmm11, rax
000076c1d9ddbaf0  movaps [r15+0x230], xmm11
000076c1d9ddbaf8  mov rax, [r15+0xF8]
000076c1d9ddbaff  lea r14, [rax+0x50]
000076c1d9ddbb03  movups xmm11, [r13+r14*1]
000076c1d9ddbb09  lea r14, [rax+0x60]
000076c1d9ddbb0d  movups xmm10, [r13+r14*1]
000076c1d9ddbb13  lea r14, [rax+0x30]
000076c1d9ddbb17  movups xmm9, [r13+r14*1]
000076c1d9ddbb1d  mov r14, [r15+0x50]
000076c1d9ddbb21  mov [r15+0x60], r14
000076c1d9ddbb25  mov qword ptr [r15+0x58], 0x40
000076c1d9ddbb2d  movaps xmm8, xmm12
000076c1d9ddbb31  mulpd xmm8, xmm15
000076c1d9ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000076c1d9ddbb3c  ptest xmm7, xmm7
000076c1d9ddbb41  jnz 0x000076C1D9DDC96A
000076c1d9ddbb47  movq xmm15, qword ptr [r15+0x230]
000076c1d9ddbb50  vmovaps [rsp+0x70], xmm15
000076c1d9ddbb56  vpermilpd xmm15, xmm15, 0x00
000076c1d9ddbb5c  movaps xmm7, xmm9
000076c1d9ddbb60  mulpd xmm7, xmm15
000076c1d9ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000076c1d9ddbb6a  ptest xmm6, xmm6
000076c1d9ddbb6f  jnz 0x000076C1D9DDCAAE
000076c1d9ddbb75  vxorps xmm15, xmm15, xmm15
000076c1d9ddbb7a  vpbroadcastq xmm15, xmm15
000076c1d9ddbb7f  movaps xmm9, xmm12
000076c1d9ddbb83  mulpd xmm9, xmm10
000076c1d9ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000076c1d9ddbb8e  ptest xmm6, xmm6
000076c1d9ddbb93  jnz 0x000076C1D9DDCBF0
000076c1d9ddbb99  movaps xmm10, xmm12
000076c1d9ddbb9d  mulpd xmm10, xmm11
000076c1d9ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000076c1d9ddbba8  ptest xmm6, xmm6
000076c1d9ddbbad  jnz 0x000076C1D9DDCD34
000076c1d9ddbbb3  movaps xmm11, [r15+0x1F0]
000076c1d9ddbbbb  movaps xmm6, xmm12
000076c1d9ddbbbf  mulpd xmm6, xmm11
000076c1d9ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000076c1d9ddbbc9  ptest xmm5, xmm5
000076c1d9ddbbce  jnz 0x000076C1D9DDCE78
000076c1d9ddbbd4  movaps xmm12, [r15+0x2A0]
000076c1d9ddbbdc  vmovaps [rsp+0x80], xmm12
000076c1d9ddbbe5  vmovaps xmm11, [rsp+0x80]
000076c1d9ddbbee  por xmm12, xmm11
000076c1d9ddbbf3  movaps xmm11, [r15+0x250]
000076c1d9ddbbfb  vmovaps [rsp+0x80], xmm11
000076c1d9ddbc04  vmovaps xmm5, [rsp+0x80]
000076c1d9ddbc0d  por xmm11, xmm5
000076c1d9ddbc12  vmovaps xmm4, [rsp+0x70]
000076c1d9ddbc18  vpermilpd xmm4, xmm4, 0x00
000076c1d9ddbc1e  movaps xmm3, xmm5
000076c1d9ddbc21  mulpd xmm3, xmm4
000076c1d9ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000076c1d9ddbc2a  ptest xmm2, xmm2
000076c1d9ddbc2f  jnz 0x000076C1D9DDCFBA
000076c1d9ddbc35  mov [rsp+0x80], rax
000076c1d9ddbc3d  xor eax, eax
000076c1d9ddbc3f  mov r12d, 0x40
000076c1d9ddbc45  mov r11d, 0x200
000076c1d9ddbc4b  cmp r12, r11
000076c1d9ddbc4e  cmc
000076c1d9ddbc4f  lahf
000076c1d9ddbc50  seto al
000076c1d9ddbc53  mov [r15+0x108], eax
000076c1d9ddbc5a  movaps xmm5, xmm8
000076c1d9ddbc5e  addpd xmm5, xmm15
000076c1d9ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000076c1d9ddbc68  ptest xmm4, xmm4
000076c1d9ddbc6d  jnz 0x000076C1D9DDD0FA
000076c1d9ddbc73  movaps xmm8, [r15+0x1B0]
000076c1d9ddbc7b  movaps xmm4, xmm9
000076c1d9ddbc7f  addpd xmm4, xmm8
000076c1d9ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000076c1d9ddbc89  ptest xmm2, xmm2
000076c1d9ddbc8e  jnz 0x000076C1D9DDD23C
000076c1d9ddbc94  movaps xmm9, xmm10
000076c1d9ddbc98  addpd xmm9, xmm8
000076c1d9ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000076c1d9ddbca3  ptest xmm2, xmm2
000076c1d9ddbca8  jnz 0x000076C1D9DDD37E
000076c1d9ddbcae  movaps xmm10, [r15+0x2F0]
000076c1d9ddbcb6  vmovaps [rsp+0x90], xmm10
000076c1d9ddbcbf  vmovaps xmm8, [rsp+0x90]
000076c1d9ddbcc8  por xmm10, xmm8
000076c1d9ddbccd  movaps xmm8, [r15+0x2E0]
000076c1d9ddbcd5  vmovaps [rsp+0x90], xmm8
000076c1d9ddbcde  vmovaps xmm2, [rsp+0x90]
000076c1d9ddbce7  por xmm8, xmm2
000076c1d9ddbcec  movaps xmm2, [r15+0x2D0]
000076c1d9ddbcf4  vmovaps [rsp+0x90], xmm2
000076c1d9ddbcfd  vmovaps [rsp+0xA0], xmm1
000076c1d9ddbd06  vmovaps xmm1, [rsp+0x90]
000076c1d9ddbd0f  por xmm2, xmm1
000076c1d9ddbd13  movaps xmm1, [r15+0x200]
000076c1d9ddbd1b  vmovaps [rsp+0x90], xmm1
000076c1d9ddbd24  vmovaps [rsp+0xB0], xmm15
000076c1d9ddbd2d  vmovaps xmm15, [rsp+0x90]
000076c1d9ddbd36  por xmm1, xmm15
000076c1d9ddbd3b  movaps xmm15, [r15+0x1C0]
000076c1d9ddbd43  vmovaps [rsp+0x90], xmm15
000076c1d9ddbd4c  vmovaps [rsp+0xC0], xmm1
000076c1d9ddbd55  vmovaps xmm1, [rsp+0x90]
000076c1d9ddbd5e  por xmm15, xmm1
000076c1d9ddbd63  movaps xmm1, [r15+0x190]
000076c1d9ddbd6b  vmovaps [rsp+0x90], xmm1
000076c1d9ddbd74  vmovaps [rsp+0xD0], xmm15
000076c1d9ddbd7d  vmovaps xmm15, [rsp+0x90]
000076c1d9ddbd86  por xmm1, xmm15
000076c1d9ddbd8b  movaps xmm15, [r15+0x300]
000076c1d9ddbd93  vmovaps [rsp+0x90], xmm15
000076c1d9ddbd9c  vmovaps [rsp+0xE0], xmm1
000076c1d9ddbda5  vmovaps xmm1, [rsp+0x90]
000076c1d9ddbdae  por xmm15, xmm1
000076c1d9ddbdb3  mov rax, [rsp+0x80]
000076c1d9ddbdbb  lea r12, [rax+0xA0]
000076c1d9ddbdc2  movups xmm1, [r13+r12*1]
000076c1d9ddbdc8  lea r12, [rax+0xB0]
000076c1d9ddbdcf  vmovaps [rsp+0x80], xmm1
000076c1d9ddbdd8  movups xmm1, [r13+r12*1]
000076c1d9ddbdde  vmovaps [rsp+0x90], xmm1
000076c1d9ddbde7  vmovaps [rsp+0xF0], xmm15
000076c1d9ddbdf0  vmovaps xmm15, [rsp+0xB0]
000076c1d9ddbdf9  vmovaps [rsp+0xB0], xmm14
000076c1d9ddbe02  movaps xmm1, xmm6
000076c1d9ddbe05  addpd xmm1, xmm15
000076c1d9ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000076c1d9ddbe0f  ptest xmm14, xmm14
000076c1d9ddbe15  jnz 0x000076C1D9DDD4D6
000076c1d9ddbe1b  lea r12, [rax+0xF0]
000076c1d9ddbe22  movups xmm15, [r13+r12*1]
000076c1d9ddbe28  movaps xmm14, xmm4
000076c1d9ddbe2c  addpd xmm14, xmm3
000076c1d9ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000076c1d9ddbe37  ptest xmm6, xmm6
000076c1d9ddbe3c  jnz 0x000076C1D9DDD621
000076c1d9ddbe42  movaps xmm6, xmm9
000076c1d9ddbe46  addpd xmm6, xmm7
000076c1d9ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000076c1d9ddbe4f  ptest xmm4, xmm4
000076c1d9ddbe54  jnz 0x000076C1D9DDD763
000076c1d9ddbe5a  vmovaps xmm9, [rsp+0x70]
000076c1d9ddbe60  vpermilpd xmm9, xmm9, 0x00
000076c1d9ddbe66  vmovaps xmm4, [rsp+0x90]
000076c1d9ddbe6f  movaps xmm7, xmm4
000076c1d9ddbe72  mulpd xmm7, xmm9
000076c1d9ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000076c1d9ddbe7c  ptest xmm3, xmm3
000076c1d9ddbe81  jnz 0x000076C1D9DDD8A4
000076c1d9ddbe87  vmovaps xmm9, [rsp+0x50]
000076c1d9ddbe8d  vpermilpd xmm9, xmm9, 0x00
000076c1d9ddbe93  movaps xmm4, xmm15
000076c1d9ddbe97  mulpd xmm4, xmm9
000076c1d9ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000076c1d9ddbea1  ptest xmm3, xmm3
000076c1d9ddbea6  jnz 0x000076C1D9DDD9E5
000076c1d9ddbeac  lea r12, [rax+0xE0]
000076c1d9ddbeb3  movups xmm15, [r13+r12*1]
000076c1d9ddbeb9  vmovaps xmm9, [rsp+0x70]
000076c1d9ddbebf  vpermilpd xmm9, xmm9, 0x00
000076c1d9ddbec5  vmovaps [rsp+0x70], xmm1
000076c1d9ddbecb  vmovaps xmm1, [rsp+0x80]
000076c1d9ddbed4  vmovaps [rsp+0x80], xmm15
000076c1d9ddbedd  movaps xmm3, xmm1
000076c1d9ddbee0  mulpd xmm3, xmm9
000076c1d9ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000076c1d9ddbeea  ptest xmm15, xmm15
000076c1d9ddbef0  jnz 0x000076C1D9DDDB31
000076c1d9ddbef6  vmovaps xmm1, [rsp+0xF0]
000076c1d9ddbeff  vmovaps xmm15, [rsp+0xF0]
000076c1d9ddbf08  por xmm1, xmm15
000076c1d9ddbf0d  movaps [r15+0x300], xmm1
000076c1d9ddbf15  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddbf1e  vmovaps xmm9, [rsp+0xE0]
000076c1d9ddbf27  por xmm15, xmm9
000076c1d9ddbf2c  movaps [r15+0x190], xmm15
000076c1d9ddbf34  vmovaps xmm9, [rsp+0x50]
000076c1d9ddbf3a  vpermilpd xmm9, xmm9, 0x00
000076c1d9ddbf40  vmovaps [rsp+0x90], xmm1
000076c1d9ddbf49  vmovaps [rsp+0xE0], xmm15
000076c1d9ddbf52  vmovaps xmm15, [rsp+0x80]
000076c1d9ddbf5b  vmovaps [rsp+0x80], xmm14
000076c1d9ddbf64  movaps xmm1, xmm15
000076c1d9ddbf68  mulpd xmm1, xmm9
000076c1d9ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000076c1d9ddbf72  ptest xmm14, xmm14
000076c1d9ddbf78  jnz 0x000076C1D9DDDC72
000076c1d9ddbf7e  lea r12, [rax+0x90]
000076c1d9ddbf85  movups xmm15, [r13+r12*1]
000076c1d9ddbf8b  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddbf94  vmovaps xmm9, [rsp+0xD0]
000076c1d9ddbf9d  por xmm14, xmm9
000076c1d9ddbfa2  movaps [r15+0x1C0], xmm14
000076c1d9ddbfaa  vmovaps xmm9, [rsp+0xC0]
000076c1d9ddbfb3  vmovaps [rsp+0xD0], xmm1
000076c1d9ddbfbc  vmovaps xmm1, [rsp+0xC0]
000076c1d9ddbfc5  por xmm9, xmm1
000076c1d9ddbfca  movaps [r15+0x200], xmm9
000076c1d9ddbfd2  vmovaps [rsp+0xC0], xmm2
000076c1d9ddbfdb  vmovaps xmm1, [rsp+0xC0]
000076c1d9ddbfe4  por xmm2, xmm1
000076c1d9ddbfe8  movaps [r15+0x2D0], xmm2
000076c1d9ddbff0  vmovaps [rsp+0xC0], xmm8
000076c1d9ddbff9  vmovaps xmm1, [rsp+0xC0]
000076c1d9ddc002  por xmm8, xmm1
000076c1d9ddc007  movaps [r15+0x2E0], xmm8
000076c1d9ddc00f  vmovaps [rsp+0xC0], xmm15
000076c1d9ddc018  movaps xmm1, xmm5
000076c1d9ddc01b  addpd xmm1, xmm7
000076c1d9ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000076c1d9ddc024  ptest xmm15, xmm15
000076c1d9ddc02a  jnz 0x000076C1D9DDDDBE
000076c1d9ddc030  vmovaps xmm15, [rsp+0x50]
000076c1d9ddc036  vpermilpd xmm15, xmm15, 0x00
000076c1d9ddc03c  vmovaps xmm5, [rsp+0xC0]
000076c1d9ddc045  vmovaps [rsp+0xC0], xmm1
000076c1d9ddc04e  movaps xmm7, xmm5
000076c1d9ddc051  mulpd xmm7, xmm15
000076c1d9ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000076c1d9ddc05b  ptest xmm1, xmm1
000076c1d9ddc060  jnz 0x000076C1D9DDDEFE
000076c1d9ddc066  lea r12, [rax+0x80]
000076c1d9ddc06d  movups xmm1, [r13+r12*1]
000076c1d9ddc073  vmovaps xmm5, [rsp+0x70]
000076c1d9ddc079  vmovaps [rsp+0x70], xmm1
000076c1d9ddc07f  movaps xmm15, xmm5
000076c1d9ddc083  addpd xmm15, xmm3
000076c1d9ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000076c1d9ddc08e  ptest xmm1, xmm1
000076c1d9ddc093  jnz 0x000076C1D9DDE049
000076c1d9ddc099  vmovaps xmm5, [rsp+0x80]
000076c1d9ddc0a2  movaps xmm1, xmm5
000076c1d9ddc0a5  addpd xmm1, xmm4
000076c1d9ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000076c1d9ddc0ae  ptest xmm3, xmm3
000076c1d9ddc0b3  jnz 0x000076C1D9DDE18B
000076c1d9ddc0b9  vmovaps [rsp+0x80], xmm10
000076c1d9ddc0c2  vmovaps xmm5, [rsp+0x80]
000076c1d9ddc0cb  por xmm10, xmm5
000076c1d9ddc0d0  movaps [r15+0x2F0], xmm10
000076c1d9ddc0d8  vmovaps xmm5, [rsp+0x50]
000076c1d9ddc0de  vpermilpd xmm5, xmm5, 0x00
000076c1d9ddc0e4  vmovaps xmm3, [rsp+0x70]
000076c1d9ddc0ea  vmovaps [rsp+0x50], xmm1
000076c1d9ddc0f0  movaps xmm4, xmm3
000076c1d9ddc0f3  mulpd xmm4, xmm5
000076c1d9ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000076c1d9ddc0fc  ptest xmm1, xmm1
000076c1d9ddc101  jnz 0x000076C1D9DDE2CB
000076c1d9ddc107  lea r12, [rax+0xD0]
000076c1d9ddc10e  movups xmm1, [r13+r12*1]
000076c1d9ddc114  vmovaps xmm3, [rsp+0xD0]
000076c1d9ddc11d  vmovaps [rsp+0x70], xmm1
000076c1d9ddc123  movaps xmm5, xmm6
000076c1d9ddc126  addpd xmm5, xmm3
000076c1d9ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000076c1d9ddc12f  ptest xmm1, xmm1
000076c1d9ddc134  jnz 0x000076C1D9DDE415
000076c1d9ddc13a  vmovaps xmm1, [rsp+0x60]
000076c1d9ddc140  vpermilpd xmm1, xmm1, 0x00
000076c1d9ddc146  movaps xmm6, xmm9
000076c1d9ddc14a  mulpd xmm6, xmm1
000076c1d9ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000076c1d9ddc153  ptest xmm3, xmm3
000076c1d9ddc158  jnz 0x000076C1D9DDE555
000076c1d9ddc15e  movaps [r15+0x260], xmm6
000076c1d9ddc166  vxorps xmm1, xmm1, xmm1
000076c1d9ddc16a  vpbroadcastq xmm1, xmm1
000076c1d9ddc16f  movaps [r15+0x1B0], xmm1
000076c1d9ddc177  vmovaps xmm1, [rsp+0x60]
000076c1d9ddc17d  vpermilpd xmm1, xmm1, 0x00
000076c1d9ddc183  vmovaps xmm3, [rsp+0x70]
000076c1d9ddc189  vmovaps [rsp+0x70], xmm15
000076c1d9ddc18f  movaps xmm9, xmm3
000076c1d9ddc193  mulpd xmm9, xmm1
000076c1d9ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000076c1d9ddc19e  ptest xmm15, xmm15
000076c1d9ddc1a4  jnz 0x000076C1D9DDE696
000076c1d9ddc1aa  lea r12, [rax+0xC0]
000076c1d9ddc1b1  movups xmm1, [r13+r12*1]
000076c1d9ddc1b7  vmovaps xmm3, [rsp+0xC0]
000076c1d9ddc1c0  vmovaps [rsp+0x80], xmm1
000076c1d9ddc1c9  movaps xmm15, xmm3
000076c1d9ddc1cd  addpd xmm15, xmm7
000076c1d9ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000076c1d9ddc1d8  ptest xmm1, xmm1
000076c1d9ddc1dd  jnz 0x000076C1D9DDE7E2
000076c1d9ddc1e3  vmovaps [rsp+0xC0], xmm13
000076c1d9ddc1ec  vmovaps xmm1, [rsp+0xC0]
000076c1d9ddc1f5  por xmm13, xmm1
000076c1d9ddc1fa  movaps [r15+0x270], xmm13
000076c1d9ddc202  vmovaps xmm1, [rsp+0xB0]
000076c1d9ddc20b  vmovaps xmm7, [rsp+0xB0]
000076c1d9ddc214  por xmm1, xmm7
000076c1d9ddc218  movaps [r15+0x1A0], xmm1
000076c1d9ddc220  vmovaps xmm1, [rsp+0x60]
000076c1d9ddc226  vpermilpd xmm1, xmm1, 0x00
000076c1d9ddc22c  vmovaps [rsp+0xB0], xmm1
000076c1d9ddc235  vmovaps xmm1, [rsp+0x80]
000076c1d9ddc23e  vmovaps [rsp+0x80], xmm15
000076c1d9ddc247  vmovaps xmm15, [rsp+0xB0]
000076c1d9ddc250  vmovaps [rsp+0xB0], xmm14
000076c1d9ddc259  movaps xmm3, xmm1
000076c1d9ddc25c  mulpd xmm3, xmm15
000076c1d9ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000076c1d9ddc266  ptest xmm14, xmm14
000076c1d9ddc26c  jnz 0x000076C1D9DDE924
000076c1d9ddc272  lea r12, [rax+0x20]
000076c1d9ddc276  movups xmm1, [r13+r12*1]
000076c1d9ddc27c  movaps [r15+0x110], xmm1
000076c1d9ddc284  vmovaps xmm14, [rsp+0x70]
000076c1d9ddc28a  vmovaps [rsp+0x70], xmm1
000076c1d9ddc290  movaps xmm15, xmm14
000076c1d9ddc294  addpd xmm15, xmm4
000076c1d9ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000076c1d9ddc29f  ptest xmm1, xmm1
000076c1d9ddc2a4  jnz 0x000076C1D9DDEA6F
000076c1d9ddc2aa  vmovaps xmm1, [rsp+0x60]
000076c1d9ddc2b0  vpermilpd xmm1, xmm1, 0x00
000076c1d9ddc2b6  movaps xmm14, xmm2
000076c1d9ddc2ba  mulpd xmm14, xmm1
000076c1d9ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000076c1d9ddc2c5  ptest xmm4, xmm4
000076c1d9ddc2ca  jnz 0x000076C1D9DDEBB2
000076c1d9ddc2d0  vmovaps xmm4, [rsp+0x50]
000076c1d9ddc2d6  movaps xmm1, xmm4
000076c1d9ddc2d9  addpd xmm1, xmm9
000076c1d9ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000076c1d9ddc2e3  ptest xmm2, xmm2
000076c1d9ddc2e8  jnz 0x000076C1D9DDECF4
000076c1d9ddc2ee  vmovaps xmm9, [rsp+0x30]
000076c1d9ddc2f4  vpermilpd xmm9, xmm9, 0x00
000076c1d9ddc2fa  vmovaps xmm2, [rsp+0x70]
000076c1d9ddc300  vmovaps [rsp+0x50], xmm1
000076c1d9ddc306  movaps xmm4, xmm2
000076c1d9ddc309  mulpd xmm4, xmm9
000076c1d9ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000076c1d9ddc313  ptest xmm1, xmm1
000076c1d9ddc318  jnz 0x000076C1D9DDEE35
000076c1d9ddc31e  vmovaps xmm1, [rsp+0x30]
000076c1d9ddc324  vpermilpd xmm1, xmm1, 0x00
000076c1d9ddc32a  vmovaps xmm2, [rsp+0x90]
000076c1d9ddc333  vmovaps [rsp+0x60], xmm15
000076c1d9ddc339  movaps xmm9, xmm2
000076c1d9ddc33d  mulpd xmm9, xmm1
000076c1d9ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000076c1d9ddc348  ptest xmm15, xmm15
000076c1d9ddc34e  jnz 0x000076C1D9DDEF76
000076c1d9ddc354  vmovaps xmm15, [rsp+0x80]
000076c1d9ddc35d  movaps xmm1, xmm15
000076c1d9ddc361  addpd xmm1, xmm6
000076c1d9ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000076c1d9ddc36a  ptest xmm2, xmm2
000076c1d9ddc36f  jnz 0x000076C1D9DDF0B8
000076c1d9ddc375  movaps xmm15, xmm5
000076c1d9ddc379  addpd xmm15, xmm3
000076c1d9ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000076c1d9ddc384  ptest xmm6, xmm6
000076c1d9ddc389  jnz 0x000076C1D9DDF1F9
000076c1d9ddc38f  vmovaps xmm6, [rsp+0x30]
000076c1d9ddc395  vpermilpd xmm6, xmm6, 0x00
000076c1d9ddc39b  movaps xmm5, xmm8
000076c1d9ddc39f  mulpd xmm5, xmm6
000076c1d9ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000076c1d9ddc3a8  ptest xmm3, xmm3
000076c1d9ddc3ad  jnz 0x000076C1D9DDF33B
000076c1d9ddc3b3  vmovaps xmm8, [rsp+0x30]
000076c1d9ddc3b9  vpermilpd xmm8, xmm8, 0x00
000076c1d9ddc3bf  movaps xmm6, xmm10
000076c1d9ddc3c3  mulpd xmm6, xmm8
000076c1d9ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000076c1d9ddc3cd  ptest xmm3, xmm3
000076c1d9ddc3d2  jnz 0x000076C1D9DDF47C
000076c1d9ddc3d8  vmovaps xmm8, [rsp+0x60]
000076c1d9ddc3de  movaps xmm10, xmm8
000076c1d9ddc3e2  addpd xmm10, xmm14
000076c1d9ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000076c1d9ddc3ed  ptest xmm3, xmm3
000076c1d9ddc3f2  jnz 0x000076C1D9DDF5BE
000076c1d9ddc3f8  vmovaps xmm8, [rsp+0x50]
000076c1d9ddc3fe  movaps xmm14, xmm8
000076c1d9ddc402  addpd xmm14, xmm4
000076c1d9ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000076c1d9ddc40d  ptest xmm3, xmm3
000076c1d9ddc412  jnz 0x000076C1D9DDF702
000076c1d9ddc418  vmovaps xmm8, [rsp+0x40]
000076c1d9ddc41e  vpermilpd xmm8, xmm8, 0x00
000076c1d9ddc424  movaps xmm4, xmm13
000076c1d9ddc428  mulpd xmm4, xmm8
000076c1d9ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000076c1d9ddc432  ptest xmm3, xmm3
000076c1d9ddc437  jnz 0x000076C1D9DDF845
000076c1d9ddc43d  movaps xmm13, xmm15
000076c1d9ddc441  addpd xmm13, xmm9
000076c1d9ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000076c1d9ddc44c  ptest xmm8, xmm8
000076c1d9ddc452  jnz 0x000076C1D9DDF987
000076c1d9ddc458  movaps xmm15, xmm1
000076c1d9ddc45c  addpd xmm15, xmm5
000076c1d9ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000076c1d9ddc467  ptest xmm9, xmm9
000076c1d9ddc46d  jnz 0x000076C1D9DDFACB
000076c1d9ddc473  vmovaps [rsp+0x30], xmm11
000076c1d9ddc479  vmovaps xmm1, [rsp+0x30]
000076c1d9ddc47f  por xmm11, xmm1
000076c1d9ddc484  movaps [r15+0x250], xmm11
000076c1d9ddc48c  vmovaps [rsp+0x30], xmm12
000076c1d9ddc492  vmovaps xmm1, [rsp+0x30]
000076c1d9ddc498  por xmm12, xmm1
000076c1d9ddc49d  movaps [r15+0x2A0], xmm12
000076c1d9ddc4a5  vmovaps xmm1, [rsp+0xA0]
000076c1d9ddc4ae  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddc4b7  por xmm1, xmm11
000076c1d9ddc4bc  movaps [r15+0x1D0], xmm1
000076c1d9ddc4c4  lea r12, [rax+0x40]
000076c1d9ddc4c8  movups xmm1, [r13+r12*1]
000076c1d9ddc4ce  movaps [r15+0x2C0], xmm1
000076c1d9ddc4d6  vmovaps xmm11, [rsp+0x40]
000076c1d9ddc4dc  vpermilpd xmm11, xmm11, 0x00
000076c1d9ddc4e2  vmovaps xmm8, [rsp+0xE0]
000076c1d9ddc4eb  movaps xmm9, xmm8
000076c1d9ddc4ef  mulpd xmm9, xmm11
000076c1d9ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000076c1d9ddc4fa  ptest xmm5, xmm5
000076c1d9ddc4ff  jnz 0x000076C1D9DDFC17
000076c1d9ddc505  movaps xmm11, xmm10
000076c1d9ddc509  addpd xmm11, xmm6
000076c1d9ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000076c1d9ddc514  ptest xmm8, xmm8
000076c1d9ddc51a  jnz 0x000076C1D9DDFD5B
000076c1d9ddc520  movaps xmm10, xmm14
000076c1d9ddc524  addpd xmm10, xmm4
000076c1d9ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000076c1d9ddc52f  ptest xmm8, xmm8
000076c1d9ddc535  jnz 0x000076C1D9DDFE9E
000076c1d9ddc53b  vmovaps xmm14, [rsp+0x40]
000076c1d9ddc541  vpermilpd xmm14, xmm14, 0x00
000076c1d9ddc547  movaps xmm8, xmm1
000076c1d9ddc54b  mulpd xmm8, xmm14
000076c1d9ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000076c1d9ddc556  ptest xmm6, xmm6
000076c1d9ddc55b  jnz 0x000076C1D9DDFFE1
000076c1d9ddc561  movaps xmm1, [r15+0x2B0]
000076c1d9ddc569  vmovaps xmm14, [rsp+0x40]
000076c1d9ddc56f  vpermilpd xmm14, xmm14, 0x00
000076c1d9ddc575  movaps xmm6, xmm1
000076c1d9ddc578  mulpd xmm6, xmm14
000076c1d9ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000076c1d9ddc582  ptest xmm5, xmm5
000076c1d9ddc587  jnz 0x000076C1D9DE0124
000076c1d9ddc58d  vmovaps xmm1, [rsp+0x10]
000076c1d9ddc593  vpermilpd xmm1, xmm1, 0x00
000076c1d9ddc599  movaps xmm14, xmm12
000076c1d9ddc59d  mulpd xmm14, xmm1
000076c1d9ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000076c1d9ddc5a8  ptest xmm5, xmm5
000076c1d9ddc5ad  jnz 0x000076C1D9DE0265
000076c1d9ddc5b3  movaps xmm1, xmm13
000076c1d9ddc5b7  addpd xmm1, xmm9
000076c1d9ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000076c1d9ddc5c1  ptest xmm12, xmm12
000076c1d9ddc5c7  jnz 0x000076C1D9DE03A8
000076c1d9ddc5cd  vmovaps xmm13, [rsp+0x10]
000076c1d9ddc5d3  vpermilpd xmm13, xmm13, 0x00
000076c1d9ddc5d9  movaps xmm12, xmm7
000076c1d9ddc5dd  mulpd xmm12, xmm13
000076c1d9ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000076c1d9ddc5e8  ptest xmm9, xmm9
000076c1d9ddc5ee  jnz 0x000076C1D9DE04EA
000076c1d9ddc5f4  movaps xmm13, xmm15
000076c1d9ddc5f8  addpd xmm13, xmm8
000076c1d9ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000076c1d9ddc603  ptest xmm9, xmm9
000076c1d9ddc609  jnz 0x000076C1D9DE062D
000076c1d9ddc60f  movaps xmm15, [r15+0x290]
000076c1d9ddc617  vmovaps xmm9, [rsp+0x10]
000076c1d9ddc61d  vpermilpd xmm9, xmm9, 0x00
000076c1d9ddc623  movaps xmm8, xmm15
000076c1d9ddc627  mulpd xmm8, xmm9
000076c1d9ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000076c1d9ddc632  ptest xmm7, xmm7
000076c1d9ddc637  jnz 0x000076C1D9DE0771
000076c1d9ddc63d  movaps xmm15, xmm11
000076c1d9ddc641  addpd xmm15, xmm6
000076c1d9ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000076c1d9ddc64c  ptest xmm9, xmm9
000076c1d9ddc652  jnz 0x000076C1D9DE08B5
000076c1d9ddc658  movaps xmm11, [r15+0x1E0]
000076c1d9ddc660  vmovaps xmm9, [rsp+0x10]
000076c1d9ddc666  vpermilpd xmm9, xmm9, 0x00
000076c1d9ddc66c  movaps xmm7, xmm11
000076c1d9ddc670  mulpd xmm7, xmm9
000076c1d9ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000076c1d9ddc67a  ptest xmm6, xmm6
000076c1d9ddc67f  jnz 0x000076C1D9DE09F8
000076c1d9ddc685  movaps xmm11, xmm10
000076c1d9ddc689  addpd xmm11, xmm14
000076c1d9ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000076c1d9ddc694  ptest xmm9, xmm9
000076c1d9ddc69a  jnz 0x000076C1D9DE0B3A
000076c1d9ddc6a0  lea r12, [rax+0x70]
000076c1d9ddc6a4  movups xmm14, [r13+r12*1]
000076c1d9ddc6aa  movaps [r15+0x240], xmm14
000076c1d9ddc6b2  movaps xmm10, xmm1
000076c1d9ddc6b6  addpd xmm10, xmm12
000076c1d9ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000076c1d9ddc6c1  ptest xmm9, xmm9
000076c1d9ddc6c7  jnz 0x000076C1D9DE0C88
000076c1d9ddc6cd  movaps [r15+0x170], xmm10
000076c1d9ddc6d5  vmovaps xmm1, [rsp+0x20]
000076c1d9ddc6db  vpermilpd xmm1, xmm1, 0x00
000076c1d9ddc6e1  movaps xmm12, xmm14
000076c1d9ddc6e5  mulpd xmm12, xmm1
000076c1d9ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000076c1d9ddc6f0  ptest xmm9, xmm9
000076c1d9ddc6f6  jnz 0x000076C1D9DE0DCB
000076c1d9ddc6fc  vmovaps xmm1, [rsp+0x20]
000076c1d9ddc702  vpermilpd xmm1, xmm1, 0x00
000076c1d9ddc708  vmovaps xmm9, [rsp+0xB0]
000076c1d9ddc711  movaps xmm14, xmm9
000076c1d9ddc715  mulpd xmm14, xmm1
000076c1d9ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000076c1d9ddc720  ptest xmm6, xmm6
000076c1d9ddc725  jnz 0x000076C1D9DE0F0E
000076c1d9ddc72b  movaps [r15+0x180], xmm14
000076c1d9ddc733  movaps xmm1, xmm13
000076c1d9ddc737  addpd xmm1, xmm8
000076c1d9ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000076c1d9ddc741  ptest xmm9, xmm9
000076c1d9ddc747  jnz 0x000076C1D9DE1051
000076c1d9ddc74d  movaps [r15+0x210], xmm1
000076c1d9ddc755  movups xmm13, [r13+rax*1]
000076c1d9ddc75b  lea r12, [rax+0x10]
000076c1d9ddc75f  movups xmm9, [r13+r12*1]
000076c1d9ddc765  movaps [r15+0x230], xmm9
000076c1d9ddc76d  movaps xmm8, xmm15
000076c1d9ddc771  addpd xmm8, xmm7
000076c1d9ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000076c1d9ddc77c  ptest xmm6, xmm6
000076c1d9ddc781  jnz 0x000076C1D9DE11A7
000076c1d9ddc787  movaps [r15+0x130], xmm8
000076c1d9ddc78f  vmovaps xmm15, [rsp+0x20]
000076c1d9ddc795  vpermilpd xmm15, xmm15, 0x00
000076c1d9ddc79b  movaps xmm7, xmm9
000076c1d9ddc79f  mulpd xmm7, xmm15
000076c1d9ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000076c1d9ddc7a9  ptest xmm6, xmm6
000076c1d9ddc7ae  jnz 0x000076C1D9DE12EA
000076c1d9ddc7b4  movaps [r15+0x220], xmm7
000076c1d9ddc7bc  vmovaps xmm15, [rsp+0x20]
000076c1d9ddc7c2  vpermilpd xmm15, xmm15, 0x00
000076c1d9ddc7c8  movaps xmm9, xmm13
000076c1d9ddc7cc  mulpd xmm9, xmm15
000076c1d9ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000076c1d9ddc7d7  ptest xmm6, xmm6
000076c1d9ddc7dc  jnz 0x000076C1D9DE142C
000076c1d9ddc7e2  movaps xmm15, xmm11
000076c1d9ddc7e6  addpd xmm15, xmm12
000076c1d9ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000076c1d9ddc7f1  ptest xmm13, xmm13
000076c1d9ddc7f7  jnz 0x000076C1D9DE1570
000076c1d9ddc7fd  movaps [r15+0x140], xmm15
000076c1d9ddc805  movaps xmm13, xmm10
000076c1d9ddc809  addpd xmm13, xmm14
000076c1d9ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000076c1d9ddc814  ptest xmm12, xmm12
000076c1d9ddc81a  jnz 0x000076C1D9DE16B4
000076c1d9ddc820  movaps [r15+0x150], xmm13
000076c1d9ddc828  movaps xmm14, xmm1
000076c1d9ddc82c  addpd xmm14, xmm7
000076c1d9ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000076c1d9ddc837  ptest xmm12, xmm12
000076c1d9ddc83d  jnz 0x000076C1D9DE17F8
000076c1d9ddc843  movaps [r15+0x160], xmm14
000076c1d9ddc84b  movaps xmm1, xmm8
000076c1d9ddc84f  addpd xmm1, xmm9
000076c1d9ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000076c1d9ddc859  ptest xmm12, xmm12
000076c1d9ddc85f  jnz 0x000076C1D9DE193A
000076c1d9ddc865  movaps [r15+0x120], xmm1
000076c1d9ddc86d  movups [r13+r14*1], xmm15
000076c1d9ddc873  lea rax, [r14+0x10]
000076c1d9ddc877  movups [r13+rax*1], xmm13
000076c1d9ddc87d  lea rax, [r14+0x20]
000076c1d9ddc881  movups [r13+rax*1], xmm14
000076c1d9ddc887  lea rax, [r14+0x30]
000076c1d9ddc88b  movups [r13+rax*1], xmm1
000076c1d9ddc891  mov eax, [r15+0x108]
000076c1d9ddc898  sahf
000076c1d9ddc899  jnz 0x000076C1D9DDC8CB
000076c1d9ddc89b  cmp dword ptr [r15+0x318], 0x00
000076c1d9ddc8a3  jz 0x000076C1D9DDB900
000076c1d9ddc8a9  nop [rax+rax*1], ax
000076c1d9ddc8b2  nop [rax+rax*1], eax
000076c1d9ddc8ba  mov eax, 0x410444
000076c1d9ddc8bf  mov [r15+0x100], rax
000076c1d9ddc8c6  jmp 0x000076C1D9BFE110
000076c1d9ddc8cb  cmp dword ptr [r15+0x318], 0x00
000076c1d9ddc8d3  jz 0x000076C1D9DD57E0
000076c1d9ddc8d9  nop [rax+rax*1], ax
000076c1d9ddc8e2  nop [rax+rax*1], eax
000076c1d9ddc8ea  mov eax, 0x410278
000076c1d9ddc8ef  mov [r15+0x100], rax
000076c1d9ddc8f6  jmp 0x000076C1D9BFE110
000076c1d9ddc8fb  int3
000076c1d9ddc8fc  call 0x000076C1D9CE27E0
000076c1d9ddc901  jmp 0x000076C1D9DDB9DF
000076c1d9ddc906  call 0x000076C1D9CE1570
000076c1d9ddc90b  jmp 0x000076C1D9DDB9E8
000076c1d9ddc910  call 0x000076C1D9CE27E0
000076c1d9ddc915  jmp 0x000076C1D9DDBA44
000076c1d9ddc91a  call 0x000076C1D9CE1570
000076c1d9ddc91f  jmp 0x000076C1D9DDBA4D
000076c1d9ddc924  call 0x000076C1D9CE27E0
000076c1d9ddc929  jmp 0x000076C1D9DDBA90
000076c1d9ddc92e  call 0x000076C1D9CE1570
000076c1d9ddc933  jmp 0x000076C1D9DDBA99
000076c1d9ddc938  call 0x000076C1D9C0DC20
000076c1d9ddc93d  jmp 0x000076C1D9DDBAD8
000076c1d9ddc942  call 0x000076C1D9CD59C0
000076c1d9ddc947  jmp 0x000076C1D9DDBAEB
000076c1d9ddc94c  call 0x000076C1D9CE0E30
000076c1d9ddc951  jmp 0x000076C1D9DDBB09
000076c1d9ddc956  call 0x000076C1D9CDFBC0
000076c1d9ddc95b  jmp 0x000076C1D9DDBB13
000076c1d9ddc960  call 0x000076C1D9CDE950
000076c1d9ddc965  jmp 0x000076C1D9DDBB1D
000076c1d9ddc96a  sub rsp, 0x08
000076c1d9ddc96e  push rax
000076c1d9ddc96f  push rcx
000076c1d9ddc970  push rdx
000076c1d9ddc971  push rdi
000076c1d9ddc972  push rsi
000076c1d9ddc973  push r8
000076c1d9ddc975  push r9
000076c1d9ddc977  push r10
000076c1d9ddc979  push r11
000076c1d9ddc97b  sub rsp, 0xF0
000076c1d9ddc982  vmovaps [rsp], xmm0
000076c1d9ddc987  vmovaps [rsp+0x10], xmm1
000076c1d9ddc98d  vmovaps [rsp+0x20], xmm2
000076c1d9ddc993  vmovaps [rsp+0x30], xmm3
000076c1d9ddc999  vmovaps [rsp+0x40], xmm4
000076c1d9ddc99f  vmovaps [rsp+0x50], xmm5
000076c1d9ddc9a5  vmovaps [rsp+0x60], xmm6
000076c1d9ddc9ab  vmovaps [rsp+0x70], xmm7
000076c1d9ddc9b1  vmovaps [rsp+0x80], xmm9
000076c1d9ddc9ba  vmovaps [rsp+0x90], xmm10
000076c1d9ddc9c3  vmovaps [rsp+0xA0], xmm11
000076c1d9ddc9cc  vmovaps [rsp+0xB0], xmm12
000076c1d9ddc9d5  vmovaps [rsp+0xC0], xmm13
000076c1d9ddc9de  vmovaps [rsp+0xD0], xmm14
000076c1d9ddc9e7  vmovaps [rsp+0xE0], xmm15
000076c1d9ddc9f0  sub rsp, 0x30
000076c1d9ddc9f4  movaps [rsp], xmm8
000076c1d9ddc9f9  movaps [rsp+0x10], xmm12
000076c1d9ddc9ff  movaps [rsp+0x20], xmm15
000076c1d9ddca05  lea rdi, [rsp]
000076c1d9ddca09  mov esi, 0x00
000076c1d9ddca0e  mov rax, 0x5EA58B9E0530
000076c1d9ddca18  call rax
000076c1d9ddca1a  movaps xmm8, [rsp]
000076c1d9ddca1f  add rsp, 0x30
000076c1d9ddca23  vmovaps xmm0, [rsp]
000076c1d9ddca28  vmovaps xmm1, [rsp+0x10]
000076c1d9ddca2e  vmovaps xmm2, [rsp+0x20]
000076c1d9ddca34  vmovaps xmm3, [rsp+0x30]
000076c1d9ddca3a  vmovaps xmm4, [rsp+0x40]
000076c1d9ddca40  vmovaps xmm5, [rsp+0x50]
000076c1d9ddca46  vmovaps xmm6, [rsp+0x60]
000076c1d9ddca4c  vmovaps xmm7, [rsp+0x70]
000076c1d9ddca52  vmovaps xmm9, [rsp+0x80]
000076c1d9ddca5b  vmovaps xmm10, [rsp+0x90]
000076c1d9ddca64  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddca6d  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddca76  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddca7f  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddca88  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddca91  add rsp, 0xF0
000076c1d9ddca98  pop r11
000076c1d9ddca9a  pop r10
000076c1d9ddca9c  pop r9
000076c1d9ddca9e  pop r8
000076c1d9ddcaa0  pop rsi
000076c1d9ddcaa1  pop rdi
000076c1d9ddcaa2  pop rdx
000076c1d9ddcaa3  pop rcx
000076c1d9ddcaa4  pop rax
000076c1d9ddcaa5  add rsp, 0x08
000076c1d9ddcaa9  jmp 0x000076C1D9DDBB47
000076c1d9ddcaae  sub rsp, 0x08
000076c1d9ddcab2  push rax
000076c1d9ddcab3  push rcx
000076c1d9ddcab4  push rdx
000076c1d9ddcab5  push rdi
000076c1d9ddcab6  push rsi
000076c1d9ddcab7  push r8
000076c1d9ddcab9  push r9
000076c1d9ddcabb  push r10
000076c1d9ddcabd  push r11
000076c1d9ddcabf  sub rsp, 0xF0
000076c1d9ddcac6  vmovaps [rsp], xmm0
000076c1d9ddcacb  vmovaps [rsp+0x10], xmm1
000076c1d9ddcad1  vmovaps [rsp+0x20], xmm2
000076c1d9ddcad7  vmovaps [rsp+0x30], xmm3
000076c1d9ddcadd  vmovaps [rsp+0x40], xmm4
000076c1d9ddcae3  vmovaps [rsp+0x50], xmm5
000076c1d9ddcae9  vmovaps [rsp+0x60], xmm6
000076c1d9ddcaef  vmovaps [rsp+0x70], xmm8
000076c1d9ddcaf5  vmovaps [rsp+0x80], xmm9
000076c1d9ddcafe  vmovaps [rsp+0x90], xmm10
000076c1d9ddcb07  vmovaps [rsp+0xA0], xmm11
000076c1d9ddcb10  vmovaps [rsp+0xB0], xmm12
000076c1d9ddcb19  vmovaps [rsp+0xC0], xmm13
000076c1d9ddcb22  vmovaps [rsp+0xD0], xmm14
000076c1d9ddcb2b  vmovaps [rsp+0xE0], xmm15
000076c1d9ddcb34  sub rsp, 0x30
000076c1d9ddcb38  movaps [rsp], xmm7
000076c1d9ddcb3c  movaps [rsp+0x10], xmm9
000076c1d9ddcb42  movaps [rsp+0x20], xmm15
000076c1d9ddcb48  lea rdi, [rsp]
000076c1d9ddcb4c  mov esi, 0x00
000076c1d9ddcb51  mov rax, 0x5EA58B9E0530
000076c1d9ddcb5b  call rax
000076c1d9ddcb5d  movaps xmm7, [rsp]
000076c1d9ddcb61  add rsp, 0x30
000076c1d9ddcb65  vmovaps xmm0, [rsp]
000076c1d9ddcb6a  vmovaps xmm1, [rsp+0x10]
000076c1d9ddcb70  vmovaps xmm2, [rsp+0x20]
000076c1d9ddcb76  vmovaps xmm3, [rsp+0x30]
000076c1d9ddcb7c  vmovaps xmm4, [rsp+0x40]
000076c1d9ddcb82  vmovaps xmm5, [rsp+0x50]
000076c1d9ddcb88  vmovaps xmm6, [rsp+0x60]
000076c1d9ddcb8e  vmovaps xmm8, [rsp+0x70]
000076c1d9ddcb94  vmovaps xmm9, [rsp+0x80]
000076c1d9ddcb9d  vmovaps xmm10, [rsp+0x90]
000076c1d9ddcba6  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddcbaf  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddcbb8  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddcbc1  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddcbca  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddcbd3  add rsp, 0xF0
000076c1d9ddcbda  pop r11
000076c1d9ddcbdc  pop r10
000076c1d9ddcbde  pop r9
000076c1d9ddcbe0  pop r8
000076c1d9ddcbe2  pop rsi
000076c1d9ddcbe3  pop rdi
000076c1d9ddcbe4  pop rdx
000076c1d9ddcbe5  pop rcx
000076c1d9ddcbe6  pop rax
000076c1d9ddcbe7  add rsp, 0x08
000076c1d9ddcbeb  jmp 0x000076C1D9DDBB75
000076c1d9ddcbf0  sub rsp, 0x08
000076c1d9ddcbf4  push rax
000076c1d9ddcbf5  push rcx
000076c1d9ddcbf6  push rdx
000076c1d9ddcbf7  push rdi
000076c1d9ddcbf8  push rsi
000076c1d9ddcbf9  push r8
000076c1d9ddcbfb  push r9
000076c1d9ddcbfd  push r10
000076c1d9ddcbff  push r11
000076c1d9ddcc01  sub rsp, 0xF0
000076c1d9ddcc08  vmovaps [rsp], xmm0
000076c1d9ddcc0d  vmovaps [rsp+0x10], xmm1
000076c1d9ddcc13  vmovaps [rsp+0x20], xmm2
000076c1d9ddcc19  vmovaps [rsp+0x30], xmm3
000076c1d9ddcc1f  vmovaps [rsp+0x40], xmm4
000076c1d9ddcc25  vmovaps [rsp+0x50], xmm5
000076c1d9ddcc2b  vmovaps [rsp+0x60], xmm6
000076c1d9ddcc31  vmovaps [rsp+0x70], xmm7
000076c1d9ddcc37  vmovaps [rsp+0x80], xmm8
000076c1d9ddcc40  vmovaps [rsp+0x90], xmm10
000076c1d9ddcc49  vmovaps [rsp+0xA0], xmm11
000076c1d9ddcc52  vmovaps [rsp+0xB0], xmm12
000076c1d9ddcc5b  vmovaps [rsp+0xC0], xmm13
000076c1d9ddcc64  vmovaps [rsp+0xD0], xmm14
000076c1d9ddcc6d  vmovaps [rsp+0xE0], xmm15
000076c1d9ddcc76  sub rsp, 0x30
000076c1d9ddcc7a  movaps [rsp], xmm9
000076c1d9ddcc7f  movaps [rsp+0x10], xmm12
000076c1d9ddcc85  movaps [rsp+0x20], xmm10
000076c1d9ddcc8b  lea rdi, [rsp]
000076c1d9ddcc8f  mov esi, 0x00
000076c1d9ddcc94  mov rax, 0x5EA58B9E0530
000076c1d9ddcc9e  call rax
000076c1d9ddcca0  movaps xmm9, [rsp]
000076c1d9ddcca5  add rsp, 0x30
000076c1d9ddcca9  vmovaps xmm0, [rsp]
000076c1d9ddccae  vmovaps xmm1, [rsp+0x10]
000076c1d9ddccb4  vmovaps xmm2, [rsp+0x20]
000076c1d9ddccba  vmovaps xmm3, [rsp+0x30]
000076c1d9ddccc0  vmovaps xmm4, [rsp+0x40]
000076c1d9ddccc6  vmovaps xmm5, [rsp+0x50]
000076c1d9ddcccc  vmovaps xmm6, [rsp+0x60]
000076c1d9ddccd2  vmovaps xmm7, [rsp+0x70]
000076c1d9ddccd8  vmovaps xmm8, [rsp+0x80]
000076c1d9ddcce1  vmovaps xmm10, [rsp+0x90]
000076c1d9ddccea  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddccf3  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddccfc  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddcd05  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddcd0e  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddcd17  add rsp, 0xF0
000076c1d9ddcd1e  pop r11
000076c1d9ddcd20  pop r10
000076c1d9ddcd22  pop r9
000076c1d9ddcd24  pop r8
000076c1d9ddcd26  pop rsi
000076c1d9ddcd27  pop rdi
000076c1d9ddcd28  pop rdx
000076c1d9ddcd29  pop rcx
000076c1d9ddcd2a  pop rax
000076c1d9ddcd2b  add rsp, 0x08
000076c1d9ddcd2f  jmp 0x000076C1D9DDBB99
000076c1d9ddcd34  sub rsp, 0x08
000076c1d9ddcd38  push rax
000076c1d9ddcd39  push rcx
000076c1d9ddcd3a  push rdx
000076c1d9ddcd3b  push rdi
000076c1d9ddcd3c  push rsi
000076c1d9ddcd3d  push r8
000076c1d9ddcd3f  push r9
000076c1d9ddcd41  push r10
000076c1d9ddcd43  push r11
000076c1d9ddcd45  sub rsp, 0xF0
000076c1d9ddcd4c  vmovaps [rsp], xmm0
000076c1d9ddcd51  vmovaps [rsp+0x10], xmm1
000076c1d9ddcd57  vmovaps [rsp+0x20], xmm2
000076c1d9ddcd5d  vmovaps [rsp+0x30], xmm3
000076c1d9ddcd63  vmovaps [rsp+0x40], xmm4
000076c1d9ddcd69  vmovaps [rsp+0x50], xmm5
000076c1d9ddcd6f  vmovaps [rsp+0x60], xmm6
000076c1d9ddcd75  vmovaps [rsp+0x70], xmm7
000076c1d9ddcd7b  vmovaps [rsp+0x80], xmm8
000076c1d9ddcd84  vmovaps [rsp+0x90], xmm9
000076c1d9ddcd8d  vmovaps [rsp+0xA0], xmm11
000076c1d9ddcd96  vmovaps [rsp+0xB0], xmm12
000076c1d9ddcd9f  vmovaps [rsp+0xC0], xmm13
000076c1d9ddcda8  vmovaps [rsp+0xD0], xmm14
000076c1d9ddcdb1  vmovaps [rsp+0xE0], xmm15
000076c1d9ddcdba  sub rsp, 0x30
000076c1d9ddcdbe  movaps [rsp], xmm10
000076c1d9ddcdc3  movaps [rsp+0x10], xmm12
000076c1d9ddcdc9  movaps [rsp+0x20], xmm11
000076c1d9ddcdcf  lea rdi, [rsp]
000076c1d9ddcdd3  mov esi, 0x00
000076c1d9ddcdd8  mov rax, 0x5EA58B9E0530
000076c1d9ddcde2  call rax
000076c1d9ddcde4  movaps xmm10, [rsp]
000076c1d9ddcde9  add rsp, 0x30
000076c1d9ddcded  vmovaps xmm0, [rsp]
000076c1d9ddcdf2  vmovaps xmm1, [rsp+0x10]
000076c1d9ddcdf8  vmovaps xmm2, [rsp+0x20]
000076c1d9ddcdfe  vmovaps xmm3, [rsp+0x30]
000076c1d9ddce04  vmovaps xmm4, [rsp+0x40]
000076c1d9ddce0a  vmovaps xmm5, [rsp+0x50]
000076c1d9ddce10  vmovaps xmm6, [rsp+0x60]
000076c1d9ddce16  vmovaps xmm7, [rsp+0x70]
000076c1d9ddce1c  vmovaps xmm8, [rsp+0x80]
000076c1d9ddce25  vmovaps xmm9, [rsp+0x90]
000076c1d9ddce2e  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddce37  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddce40  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddce49  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddce52  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddce5b  add rsp, 0xF0
000076c1d9ddce62  pop r11
000076c1d9ddce64  pop r10
000076c1d9ddce66  pop r9
000076c1d9ddce68  pop r8
000076c1d9ddce6a  pop rsi
000076c1d9ddce6b  pop rdi
000076c1d9ddce6c  pop rdx
000076c1d9ddce6d  pop rcx
000076c1d9ddce6e  pop rax
000076c1d9ddce6f  add rsp, 0x08
000076c1d9ddce73  jmp 0x000076C1D9DDBBB3
000076c1d9ddce78  sub rsp, 0x08
000076c1d9ddce7c  push rax
000076c1d9ddce7d  push rcx
000076c1d9ddce7e  push rdx
000076c1d9ddce7f  push rdi
000076c1d9ddce80  push rsi
000076c1d9ddce81  push r8
000076c1d9ddce83  push r9
000076c1d9ddce85  push r10
000076c1d9ddce87  push r11
000076c1d9ddce89  sub rsp, 0xF0
000076c1d9ddce90  vmovaps [rsp], xmm0
000076c1d9ddce95  vmovaps [rsp+0x10], xmm1
000076c1d9ddce9b  vmovaps [rsp+0x20], xmm2
000076c1d9ddcea1  vmovaps [rsp+0x30], xmm3
000076c1d9ddcea7  vmovaps [rsp+0x40], xmm4
000076c1d9ddcead  vmovaps [rsp+0x50], xmm5
000076c1d9ddceb3  vmovaps [rsp+0x60], xmm7
000076c1d9ddceb9  vmovaps [rsp+0x70], xmm8
000076c1d9ddcebf  vmovaps [rsp+0x80], xmm9
000076c1d9ddcec8  vmovaps [rsp+0x90], xmm10
000076c1d9ddced1  vmovaps [rsp+0xA0], xmm11
000076c1d9ddceda  vmovaps [rsp+0xB0], xmm12
000076c1d9ddcee3  vmovaps [rsp+0xC0], xmm13
000076c1d9ddceec  vmovaps [rsp+0xD0], xmm14
000076c1d9ddcef5  vmovaps [rsp+0xE0], xmm15
000076c1d9ddcefe  sub rsp, 0x30
000076c1d9ddcf02  movaps [rsp], xmm6
000076c1d9ddcf06  movaps [rsp+0x10], xmm12
000076c1d9ddcf0c  movaps [rsp+0x20], xmm11
000076c1d9ddcf12  lea rdi, [rsp]
000076c1d9ddcf16  mov esi, 0x00
000076c1d9ddcf1b  mov rax, 0x5EA58B9E0530
000076c1d9ddcf25  call rax
000076c1d9ddcf27  movaps xmm6, [rsp]
000076c1d9ddcf2b  add rsp, 0x30
000076c1d9ddcf2f  vmovaps xmm0, [rsp]
000076c1d9ddcf34  vmovaps xmm1, [rsp+0x10]
000076c1d9ddcf3a  vmovaps xmm2, [rsp+0x20]
000076c1d9ddcf40  vmovaps xmm3, [rsp+0x30]
000076c1d9ddcf46  vmovaps xmm4, [rsp+0x40]
000076c1d9ddcf4c  vmovaps xmm5, [rsp+0x50]
000076c1d9ddcf52  vmovaps xmm7, [rsp+0x60]
000076c1d9ddcf58  vmovaps xmm8, [rsp+0x70]
000076c1d9ddcf5e  vmovaps xmm9, [rsp+0x80]
000076c1d9ddcf67  vmovaps xmm10, [rsp+0x90]
000076c1d9ddcf70  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddcf79  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddcf82  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddcf8b  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddcf94  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddcf9d  add rsp, 0xF0
000076c1d9ddcfa4  pop r11
000076c1d9ddcfa6  pop r10
000076c1d9ddcfa8  pop r9
000076c1d9ddcfaa  pop r8
000076c1d9ddcfac  pop rsi
000076c1d9ddcfad  pop rdi
000076c1d9ddcfae  pop rdx
000076c1d9ddcfaf  pop rcx
000076c1d9ddcfb0  pop rax
000076c1d9ddcfb1  add rsp, 0x08
000076c1d9ddcfb5  jmp 0x000076C1D9DDBBD4
000076c1d9ddcfba  sub rsp, 0x08
000076c1d9ddcfbe  push rax
000076c1d9ddcfbf  push rcx
000076c1d9ddcfc0  push rdx
000076c1d9ddcfc1  push rdi
000076c1d9ddcfc2  push rsi
000076c1d9ddcfc3  push r8
000076c1d9ddcfc5  push r9
000076c1d9ddcfc7  push r10
000076c1d9ddcfc9  push r11
000076c1d9ddcfcb  sub rsp, 0xF0
000076c1d9ddcfd2  vmovaps [rsp], xmm0
000076c1d9ddcfd7  vmovaps [rsp+0x10], xmm1
000076c1d9ddcfdd  vmovaps [rsp+0x20], xmm2
000076c1d9ddcfe3  vmovaps [rsp+0x30], xmm4
000076c1d9ddcfe9  vmovaps [rsp+0x40], xmm5
000076c1d9ddcfef  vmovaps [rsp+0x50], xmm6
000076c1d9ddcff5  vmovaps [rsp+0x60], xmm7
000076c1d9ddcffb  vmovaps [rsp+0x70], xmm8
000076c1d9ddd001  vmovaps [rsp+0x80], xmm9
000076c1d9ddd00a  vmovaps [rsp+0x90], xmm10
000076c1d9ddd013  vmovaps [rsp+0xA0], xmm11
000076c1d9ddd01c  vmovaps [rsp+0xB0], xmm12
000076c1d9ddd025  vmovaps [rsp+0xC0], xmm13
000076c1d9ddd02e  vmovaps [rsp+0xD0], xmm14
000076c1d9ddd037  vmovaps [rsp+0xE0], xmm15
000076c1d9ddd040  sub rsp, 0x30
000076c1d9ddd044  movaps [rsp], xmm3
000076c1d9ddd048  movaps [rsp+0x10], xmm5
000076c1d9ddd04d  movaps [rsp+0x20], xmm4
000076c1d9ddd052  lea rdi, [rsp]
000076c1d9ddd056  mov esi, 0x00
000076c1d9ddd05b  mov rax, 0x5EA58B9E0530
000076c1d9ddd065  call rax
000076c1d9ddd067  movaps xmm3, [rsp]
000076c1d9ddd06b  add rsp, 0x30
000076c1d9ddd06f  vmovaps xmm0, [rsp]
000076c1d9ddd074  vmovaps xmm1, [rsp+0x10]
000076c1d9ddd07a  vmovaps xmm2, [rsp+0x20]
000076c1d9ddd080  vmovaps xmm4, [rsp+0x30]
000076c1d9ddd086  vmovaps xmm5, [rsp+0x40]
000076c1d9ddd08c  vmovaps xmm6, [rsp+0x50]
000076c1d9ddd092  vmovaps xmm7, [rsp+0x60]
000076c1d9ddd098  vmovaps xmm8, [rsp+0x70]
000076c1d9ddd09e  vmovaps xmm9, [rsp+0x80]
000076c1d9ddd0a7  vmovaps xmm10, [rsp+0x90]
000076c1d9ddd0b0  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddd0b9  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddd0c2  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddd0cb  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddd0d4  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddd0dd  add rsp, 0xF0
000076c1d9ddd0e4  pop r11
000076c1d9ddd0e6  pop r10
000076c1d9ddd0e8  pop r9
000076c1d9ddd0ea  pop r8
000076c1d9ddd0ec  pop rsi
000076c1d9ddd0ed  pop rdi
000076c1d9ddd0ee  pop rdx
000076c1d9ddd0ef  pop rcx
000076c1d9ddd0f0  pop rax
000076c1d9ddd0f1  add rsp, 0x08
000076c1d9ddd0f5  jmp 0x000076C1D9DDBC35
000076c1d9ddd0fa  sub rsp, 0x08
000076c1d9ddd0fe  push rax
000076c1d9ddd0ff  push rcx
000076c1d9ddd100  push rdx
000076c1d9ddd101  push rdi
000076c1d9ddd102  push rsi
000076c1d9ddd103  push r8
000076c1d9ddd105  push r9
000076c1d9ddd107  push r10
000076c1d9ddd109  push r11
000076c1d9ddd10b  sub rsp, 0xF0
000076c1d9ddd112  vmovaps [rsp], xmm0
000076c1d9ddd117  vmovaps [rsp+0x10], xmm1
000076c1d9ddd11d  vmovaps [rsp+0x20], xmm2
000076c1d9ddd123  vmovaps [rsp+0x30], xmm3
000076c1d9ddd129  vmovaps [rsp+0x40], xmm4
000076c1d9ddd12f  vmovaps [rsp+0x50], xmm6
000076c1d9ddd135  vmovaps [rsp+0x60], xmm7
000076c1d9ddd13b  vmovaps [rsp+0x70], xmm8
000076c1d9ddd141  vmovaps [rsp+0x80], xmm9
000076c1d9ddd14a  vmovaps [rsp+0x90], xmm10
000076c1d9ddd153  vmovaps [rsp+0xA0], xmm11
000076c1d9ddd15c  vmovaps [rsp+0xB0], xmm12
000076c1d9ddd165  vmovaps [rsp+0xC0], xmm13
000076c1d9ddd16e  vmovaps [rsp+0xD0], xmm14
000076c1d9ddd177  vmovaps [rsp+0xE0], xmm15
000076c1d9ddd180  sub rsp, 0x30
000076c1d9ddd184  movaps [rsp], xmm5
000076c1d9ddd188  movaps [rsp+0x10], xmm8
000076c1d9ddd18e  movaps [rsp+0x20], xmm15
000076c1d9ddd194  lea rdi, [rsp]
000076c1d9ddd198  mov esi, 0x00
000076c1d9ddd19d  mov rax, 0x5EA58B9E0530
000076c1d9ddd1a7  call rax
000076c1d9ddd1a9  movaps xmm5, [rsp]
000076c1d9ddd1ad  add rsp, 0x30
000076c1d9ddd1b1  vmovaps xmm0, [rsp]
000076c1d9ddd1b6  vmovaps xmm1, [rsp+0x10]
000076c1d9ddd1bc  vmovaps xmm2, [rsp+0x20]
000076c1d9ddd1c2  vmovaps xmm3, [rsp+0x30]
000076c1d9ddd1c8  vmovaps xmm4, [rsp+0x40]
000076c1d9ddd1ce  vmovaps xmm6, [rsp+0x50]
000076c1d9ddd1d4  vmovaps xmm7, [rsp+0x60]
000076c1d9ddd1da  vmovaps xmm8, [rsp+0x70]
000076c1d9ddd1e0  vmovaps xmm9, [rsp+0x80]
000076c1d9ddd1e9  vmovaps xmm10, [rsp+0x90]
000076c1d9ddd1f2  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddd1fb  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddd204  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddd20d  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddd216  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddd21f  add rsp, 0xF0
000076c1d9ddd226  pop r11
000076c1d9ddd228  pop r10
000076c1d9ddd22a  pop r9
000076c1d9ddd22c  pop r8
000076c1d9ddd22e  pop rsi
000076c1d9ddd22f  pop rdi
000076c1d9ddd230  pop rdx
000076c1d9ddd231  pop rcx
000076c1d9ddd232  pop rax
000076c1d9ddd233  add rsp, 0x08
000076c1d9ddd237  jmp 0x000076C1D9DDBC73
000076c1d9ddd23c  sub rsp, 0x08
000076c1d9ddd240  push rax
000076c1d9ddd241  push rcx
000076c1d9ddd242  push rdx
000076c1d9ddd243  push rdi
000076c1d9ddd244  push rsi
000076c1d9ddd245  push r8
000076c1d9ddd247  push r9
000076c1d9ddd249  push r10
000076c1d9ddd24b  push r11
000076c1d9ddd24d  sub rsp, 0xF0
000076c1d9ddd254  vmovaps [rsp], xmm0
000076c1d9ddd259  vmovaps [rsp+0x10], xmm1
000076c1d9ddd25f  vmovaps [rsp+0x20], xmm2
000076c1d9ddd265  vmovaps [rsp+0x30], xmm3
000076c1d9ddd26b  vmovaps [rsp+0x40], xmm5
000076c1d9ddd271  vmovaps [rsp+0x50], xmm6
000076c1d9ddd277  vmovaps [rsp+0x60], xmm7
000076c1d9ddd27d  vmovaps [rsp+0x70], xmm8
000076c1d9ddd283  vmovaps [rsp+0x80], xmm9
000076c1d9ddd28c  vmovaps [rsp+0x90], xmm10
000076c1d9ddd295  vmovaps [rsp+0xA0], xmm11
000076c1d9ddd29e  vmovaps [rsp+0xB0], xmm12
000076c1d9ddd2a7  vmovaps [rsp+0xC0], xmm13
000076c1d9ddd2b0  vmovaps [rsp+0xD0], xmm14
000076c1d9ddd2b9  vmovaps [rsp+0xE0], xmm15
000076c1d9ddd2c2  sub rsp, 0x30
000076c1d9ddd2c6  movaps [rsp], xmm4
000076c1d9ddd2ca  movaps [rsp+0x10], xmm9
000076c1d9ddd2d0  movaps [rsp+0x20], xmm8
000076c1d9ddd2d6  lea rdi, [rsp]
000076c1d9ddd2da  mov esi, 0x00
000076c1d9ddd2df  mov rax, 0x5EA58B9E0530
000076c1d9ddd2e9  call rax
000076c1d9ddd2eb  movaps xmm4, [rsp]
000076c1d9ddd2ef  add rsp, 0x30
000076c1d9ddd2f3  vmovaps xmm0, [rsp]
000076c1d9ddd2f8  vmovaps xmm1, [rsp+0x10]
000076c1d9ddd2fe  vmovaps xmm2, [rsp+0x20]
000076c1d9ddd304  vmovaps xmm3, [rsp+0x30]
000076c1d9ddd30a  vmovaps xmm5, [rsp+0x40]
000076c1d9ddd310  vmovaps xmm6, [rsp+0x50]
000076c1d9ddd316  vmovaps xmm7, [rsp+0x60]
000076c1d9ddd31c  vmovaps xmm8, [rsp+0x70]
000076c1d9ddd322  vmovaps xmm9, [rsp+0x80]
000076c1d9ddd32b  vmovaps xmm10, [rsp+0x90]
000076c1d9ddd334  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddd33d  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddd346  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddd34f  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddd358  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddd361  add rsp, 0xF0
000076c1d9ddd368  pop r11
000076c1d9ddd36a  pop r10
000076c1d9ddd36c  pop r9
000076c1d9ddd36e  pop r8
000076c1d9ddd370  pop rsi
000076c1d9ddd371  pop rdi
000076c1d9ddd372  pop rdx
000076c1d9ddd373  pop rcx
000076c1d9ddd374  pop rax
000076c1d9ddd375  add rsp, 0x08
000076c1d9ddd379  jmp 0x000076C1D9DDBC94
000076c1d9ddd37e  sub rsp, 0x08
000076c1d9ddd382  push rax
000076c1d9ddd383  push rcx
000076c1d9ddd384  push rdx
000076c1d9ddd385  push rdi
000076c1d9ddd386  push rsi
000076c1d9ddd387  push r8
000076c1d9ddd389  push r9
000076c1d9ddd38b  push r10
000076c1d9ddd38d  push r11
000076c1d9ddd38f  sub rsp, 0xF0
000076c1d9ddd396  vmovaps [rsp], xmm0
000076c1d9ddd39b  vmovaps [rsp+0x10], xmm1
000076c1d9ddd3a1  vmovaps [rsp+0x20], xmm2
000076c1d9ddd3a7  vmovaps [rsp+0x30], xmm3
000076c1d9ddd3ad  vmovaps [rsp+0x40], xmm4
000076c1d9ddd3b3  vmovaps [rsp+0x50], xmm5
000076c1d9ddd3b9  vmovaps [rsp+0x60], xmm6
000076c1d9ddd3bf  vmovaps [rsp+0x70], xmm7
000076c1d9ddd3c5  vmovaps [rsp+0x80], xmm8
000076c1d9ddd3ce  vmovaps [rsp+0x90], xmm10
000076c1d9ddd3d7  vmovaps [rsp+0xA0], xmm11
000076c1d9ddd3e0  vmovaps [rsp+0xB0], xmm12
000076c1d9ddd3e9  vmovaps [rsp+0xC0], xmm13
000076c1d9ddd3f2  vmovaps [rsp+0xD0], xmm14
000076c1d9ddd3fb  vmovaps [rsp+0xE0], xmm15
000076c1d9ddd404  sub rsp, 0x30
000076c1d9ddd408  movaps [rsp], xmm9
000076c1d9ddd40d  movaps [rsp+0x10], xmm10
000076c1d9ddd413  movaps [rsp+0x20], xmm8
000076c1d9ddd419  lea rdi, [rsp]
000076c1d9ddd41d  mov esi, 0x00
000076c1d9ddd422  mov rax, 0x5EA58B9E0530
000076c1d9ddd42c  call rax
000076c1d9ddd42e  movaps xmm9, [rsp]
000076c1d9ddd433  add rsp, 0x30
000076c1d9ddd437  vmovaps xmm0, [rsp]
000076c1d9ddd43c  vmovaps xmm1, [rsp+0x10]
000076c1d9ddd442  vmovaps xmm2, [rsp+0x20]
000076c1d9ddd448  vmovaps xmm3, [rsp+0x30]
000076c1d9ddd44e  vmovaps xmm4, [rsp+0x40]
000076c1d9ddd454  vmovaps xmm5, [rsp+0x50]
000076c1d9ddd45a  vmovaps xmm6, [rsp+0x60]
000076c1d9ddd460  vmovaps xmm7, [rsp+0x70]
000076c1d9ddd466  vmovaps xmm8, [rsp+0x80]
000076c1d9ddd46f  vmovaps xmm10, [rsp+0x90]
000076c1d9ddd478  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddd481  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddd48a  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddd493  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddd49c  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddd4a5  add rsp, 0xF0
000076c1d9ddd4ac  pop r11
000076c1d9ddd4ae  pop r10
000076c1d9ddd4b0  pop r9
000076c1d9ddd4b2  pop r8
000076c1d9ddd4b4  pop rsi
000076c1d9ddd4b5  pop rdi
000076c1d9ddd4b6  pop rdx
000076c1d9ddd4b7  pop rcx
000076c1d9ddd4b8  pop rax
000076c1d9ddd4b9  add rsp, 0x08
000076c1d9ddd4bd  jmp 0x000076C1D9DDBCAE
000076c1d9ddd4c2  call 0x000076C1D9CB52F0
000076c1d9ddd4c7  jmp 0x000076C1D9DDBDC8
000076c1d9ddd4cc  call 0x000076C1D9CB52F0
000076c1d9ddd4d1  jmp 0x000076C1D9DDBDDE
000076c1d9ddd4d6  sub rsp, 0x08
000076c1d9ddd4da  push rax
000076c1d9ddd4db  push rcx
000076c1d9ddd4dc  push rdx
000076c1d9ddd4dd  push rdi
000076c1d9ddd4de  push rsi
000076c1d9ddd4df  push r8
000076c1d9ddd4e1  push r9
000076c1d9ddd4e3  push r10
000076c1d9ddd4e5  push r11
000076c1d9ddd4e7  sub rsp, 0xF0
000076c1d9ddd4ee  vmovaps [rsp], xmm0
000076c1d9ddd4f3  vmovaps [rsp+0x10], xmm2
000076c1d9ddd4f9  vmovaps [rsp+0x20], xmm3
000076c1d9ddd4ff  vmovaps [rsp+0x30], xmm4
000076c1d9ddd505  vmovaps [rsp+0x40], xmm5
000076c1d9ddd50b  vmovaps [rsp+0x50], xmm6
000076c1d9ddd511  vmovaps [rsp+0x60], xmm7
000076c1d9ddd517  vmovaps [rsp+0x70], xmm8
000076c1d9ddd51d  vmovaps [rsp+0x80], xmm9
000076c1d9ddd526  vmovaps [rsp+0x90], xmm10
000076c1d9ddd52f  vmovaps [rsp+0xA0], xmm11
000076c1d9ddd538  vmovaps [rsp+0xB0], xmm12
000076c1d9ddd541  vmovaps [rsp+0xC0], xmm13
000076c1d9ddd54a  vmovaps [rsp+0xD0], xmm14
000076c1d9ddd553  vmovaps [rsp+0xE0], xmm15
000076c1d9ddd55c  sub rsp, 0x30
000076c1d9ddd560  movaps [rsp], xmm1
000076c1d9ddd564  movaps [rsp+0x10], xmm6
000076c1d9ddd569  movaps [rsp+0x20], xmm15
000076c1d9ddd56f  lea rdi, [rsp]
000076c1d9ddd573  mov esi, 0x00
000076c1d9ddd578  mov rax, 0x5EA58B9E0530
000076c1d9ddd582  call rax
000076c1d9ddd584  movaps xmm1, [rsp]
000076c1d9ddd588  add rsp, 0x30
000076c1d9ddd58c  vmovaps xmm0, [rsp]
000076c1d9ddd591  vmovaps xmm2, [rsp+0x10]
000076c1d9ddd597  vmovaps xmm3, [rsp+0x20]
000076c1d9ddd59d  vmovaps xmm4, [rsp+0x30]
000076c1d9ddd5a3  vmovaps xmm5, [rsp+0x40]
000076c1d9ddd5a9  vmovaps xmm6, [rsp+0x50]
000076c1d9ddd5af  vmovaps xmm7, [rsp+0x60]
000076c1d9ddd5b5  vmovaps xmm8, [rsp+0x70]
000076c1d9ddd5bb  vmovaps xmm9, [rsp+0x80]
000076c1d9ddd5c4  vmovaps xmm10, [rsp+0x90]
000076c1d9ddd5cd  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddd5d6  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddd5df  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddd5e8  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddd5f1  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddd5fa  add rsp, 0xF0
000076c1d9ddd601  pop r11
000076c1d9ddd603  pop r10
000076c1d9ddd605  pop r9
000076c1d9ddd607  pop r8
000076c1d9ddd609  pop rsi
000076c1d9ddd60a  pop rdi
000076c1d9ddd60b  pop rdx
000076c1d9ddd60c  pop rcx
000076c1d9ddd60d  pop rax
000076c1d9ddd60e  add rsp, 0x08
000076c1d9ddd612  jmp 0x000076C1D9DDBE1B
000076c1d9ddd617  call 0x000076C1D9CC4620
000076c1d9ddd61c  jmp 0x000076C1D9DDBE28
000076c1d9ddd621  sub rsp, 0x08
000076c1d9ddd625  push rax
000076c1d9ddd626  push rcx
000076c1d9ddd627  push rdx
000076c1d9ddd628  push rdi
000076c1d9ddd629  push rsi
000076c1d9ddd62a  push r8
000076c1d9ddd62c  push r9
000076c1d9ddd62e  push r10
000076c1d9ddd630  push r11
000076c1d9ddd632  sub rsp, 0xF0
000076c1d9ddd639  vmovaps [rsp], xmm0
000076c1d9ddd63e  vmovaps [rsp+0x10], xmm1
000076c1d9ddd644  vmovaps [rsp+0x20], xmm2
000076c1d9ddd64a  vmovaps [rsp+0x30], xmm3
000076c1d9ddd650  vmovaps [rsp+0x40], xmm4
000076c1d9ddd656  vmovaps [rsp+0x50], xmm5
000076c1d9ddd65c  vmovaps [rsp+0x60], xmm6
000076c1d9ddd662  vmovaps [rsp+0x70], xmm7
000076c1d9ddd668  vmovaps [rsp+0x80], xmm8
000076c1d9ddd671  vmovaps [rsp+0x90], xmm9
000076c1d9ddd67a  vmovaps [rsp+0xA0], xmm10
000076c1d9ddd683  vmovaps [rsp+0xB0], xmm11
000076c1d9ddd68c  vmovaps [rsp+0xC0], xmm12
000076c1d9ddd695  vmovaps [rsp+0xD0], xmm13
000076c1d9ddd69e  vmovaps [rsp+0xE0], xmm15
000076c1d9ddd6a7  sub rsp, 0x30
000076c1d9ddd6ab  movaps [rsp], xmm14
000076c1d9ddd6b0  movaps [rsp+0x10], xmm4
000076c1d9ddd6b5  movaps [rsp+0x20], xmm3
000076c1d9ddd6ba  lea rdi, [rsp]
000076c1d9ddd6be  mov esi, 0x00
000076c1d9ddd6c3  mov rax, 0x5EA58B9E0530
000076c1d9ddd6cd  call rax
000076c1d9ddd6cf  movaps xmm14, [rsp]
000076c1d9ddd6d4  add rsp, 0x30
000076c1d9ddd6d8  vmovaps xmm0, [rsp]
000076c1d9ddd6dd  vmovaps xmm1, [rsp+0x10]
000076c1d9ddd6e3  vmovaps xmm2, [rsp+0x20]
000076c1d9ddd6e9  vmovaps xmm3, [rsp+0x30]
000076c1d9ddd6ef  vmovaps xmm4, [rsp+0x40]
000076c1d9ddd6f5  vmovaps xmm5, [rsp+0x50]
000076c1d9ddd6fb  vmovaps xmm6, [rsp+0x60]
000076c1d9ddd701  vmovaps xmm7, [rsp+0x70]
000076c1d9ddd707  vmovaps xmm8, [rsp+0x80]
000076c1d9ddd710  vmovaps xmm9, [rsp+0x90]
000076c1d9ddd719  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddd722  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddd72b  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddd734  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddd73d  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddd746  add rsp, 0xF0
000076c1d9ddd74d  pop r11
000076c1d9ddd74f  pop r10
000076c1d9ddd751  pop r9
000076c1d9ddd753  pop r8
000076c1d9ddd755  pop rsi
000076c1d9ddd756  pop rdi
000076c1d9ddd757  pop rdx
000076c1d9ddd758  pop rcx
000076c1d9ddd759  pop rax
000076c1d9ddd75a  add rsp, 0x08
000076c1d9ddd75e  jmp 0x000076C1D9DDBE42
000076c1d9ddd763  sub rsp, 0x08
000076c1d9ddd767  push rax
000076c1d9ddd768  push rcx
000076c1d9ddd769  push rdx
000076c1d9ddd76a  push rdi
000076c1d9ddd76b  push rsi
000076c1d9ddd76c  push r8
000076c1d9ddd76e  push r9
000076c1d9ddd770  push r10
000076c1d9ddd772  push r11
000076c1d9ddd774  sub rsp, 0xF0
000076c1d9ddd77b  vmovaps [rsp], xmm0
000076c1d9ddd780  vmovaps [rsp+0x10], xmm1
000076c1d9ddd786  vmovaps [rsp+0x20], xmm2
000076c1d9ddd78c  vmovaps [rsp+0x30], xmm3
000076c1d9ddd792  vmovaps [rsp+0x40], xmm4
000076c1d9ddd798  vmovaps [rsp+0x50], xmm5
000076c1d9ddd79e  vmovaps [rsp+0x60], xmm7
000076c1d9ddd7a4  vmovaps [rsp+0x70], xmm8
000076c1d9ddd7aa  vmovaps [rsp+0x80], xmm9
000076c1d9ddd7b3  vmovaps [rsp+0x90], xmm10
000076c1d9ddd7bc  vmovaps [rsp+0xA0], xmm11
000076c1d9ddd7c5  vmovaps [rsp+0xB0], xmm12
000076c1d9ddd7ce  vmovaps [rsp+0xC0], xmm13
000076c1d9ddd7d7  vmovaps [rsp+0xD0], xmm14
000076c1d9ddd7e0  vmovaps [rsp+0xE0], xmm15
000076c1d9ddd7e9  sub rsp, 0x30
000076c1d9ddd7ed  movaps [rsp], xmm6
000076c1d9ddd7f1  movaps [rsp+0x10], xmm9
000076c1d9ddd7f7  movaps [rsp+0x20], xmm7
000076c1d9ddd7fc  lea rdi, [rsp]
000076c1d9ddd800  mov esi, 0x00
000076c1d9ddd805  mov rax, 0x5EA58B9E0530
000076c1d9ddd80f  call rax
000076c1d9ddd811  movaps xmm6, [rsp]
000076c1d9ddd815  add rsp, 0x30
000076c1d9ddd819  vmovaps xmm0, [rsp]
000076c1d9ddd81e  vmovaps xmm1, [rsp+0x10]
000076c1d9ddd824  vmovaps xmm2, [rsp+0x20]
000076c1d9ddd82a  vmovaps xmm3, [rsp+0x30]
000076c1d9ddd830  vmovaps xmm4, [rsp+0x40]
000076c1d9ddd836  vmovaps xmm5, [rsp+0x50]
000076c1d9ddd83c  vmovaps xmm7, [rsp+0x60]
000076c1d9ddd842  vmovaps xmm8, [rsp+0x70]
000076c1d9ddd848  vmovaps xmm9, [rsp+0x80]
000076c1d9ddd851  vmovaps xmm10, [rsp+0x90]
000076c1d9ddd85a  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddd863  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddd86c  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddd875  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddd87e  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddd887  add rsp, 0xF0
000076c1d9ddd88e  pop r11
000076c1d9ddd890  pop r10
000076c1d9ddd892  pop r9
000076c1d9ddd894  pop r8
000076c1d9ddd896  pop rsi
000076c1d9ddd897  pop rdi
000076c1d9ddd898  pop rdx
000076c1d9ddd899  pop rcx
000076c1d9ddd89a  pop rax
000076c1d9ddd89b  add rsp, 0x08
000076c1d9ddd89f  jmp 0x000076C1D9DDBE5A
000076c1d9ddd8a4  sub rsp, 0x08
000076c1d9ddd8a8  push rax
000076c1d9ddd8a9  push rcx
000076c1d9ddd8aa  push rdx
000076c1d9ddd8ab  push rdi
000076c1d9ddd8ac  push rsi
000076c1d9ddd8ad  push r8
000076c1d9ddd8af  push r9
000076c1d9ddd8b1  push r10
000076c1d9ddd8b3  push r11
000076c1d9ddd8b5  sub rsp, 0xF0
000076c1d9ddd8bc  vmovaps [rsp], xmm0
000076c1d9ddd8c1  vmovaps [rsp+0x10], xmm1
000076c1d9ddd8c7  vmovaps [rsp+0x20], xmm2
000076c1d9ddd8cd  vmovaps [rsp+0x30], xmm3
000076c1d9ddd8d3  vmovaps [rsp+0x40], xmm4
000076c1d9ddd8d9  vmovaps [rsp+0x50], xmm5
000076c1d9ddd8df  vmovaps [rsp+0x60], xmm6
000076c1d9ddd8e5  vmovaps [rsp+0x70], xmm8
000076c1d9ddd8eb  vmovaps [rsp+0x80], xmm9
000076c1d9ddd8f4  vmovaps [rsp+0x90], xmm10
000076c1d9ddd8fd  vmovaps [rsp+0xA0], xmm11
000076c1d9ddd906  vmovaps [rsp+0xB0], xmm12
000076c1d9ddd90f  vmovaps [rsp+0xC0], xmm13
000076c1d9ddd918  vmovaps [rsp+0xD0], xmm14
000076c1d9ddd921  vmovaps [rsp+0xE0], xmm15
000076c1d9ddd92a  sub rsp, 0x30
000076c1d9ddd92e  movaps [rsp], xmm7
000076c1d9ddd932  movaps [rsp+0x10], xmm4
000076c1d9ddd937  movaps [rsp+0x20], xmm9
000076c1d9ddd93d  lea rdi, [rsp]
000076c1d9ddd941  mov esi, 0x00
000076c1d9ddd946  mov rax, 0x5EA58B9E0530
000076c1d9ddd950  call rax
000076c1d9ddd952  movaps xmm7, [rsp]
000076c1d9ddd956  add rsp, 0x30
000076c1d9ddd95a  vmovaps xmm0, [rsp]
000076c1d9ddd95f  vmovaps xmm1, [rsp+0x10]
000076c1d9ddd965  vmovaps xmm2, [rsp+0x20]
000076c1d9ddd96b  vmovaps xmm3, [rsp+0x30]
000076c1d9ddd971  vmovaps xmm4, [rsp+0x40]
000076c1d9ddd977  vmovaps xmm5, [rsp+0x50]
000076c1d9ddd97d  vmovaps xmm6, [rsp+0x60]
000076c1d9ddd983  vmovaps xmm8, [rsp+0x70]
000076c1d9ddd989  vmovaps xmm9, [rsp+0x80]
000076c1d9ddd992  vmovaps xmm10, [rsp+0x90]
000076c1d9ddd99b  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddd9a4  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddd9ad  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddd9b6  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddd9bf  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddd9c8  add rsp, 0xF0
000076c1d9ddd9cf  pop r11
000076c1d9ddd9d1  pop r10
000076c1d9ddd9d3  pop r9
000076c1d9ddd9d5  pop r8
000076c1d9ddd9d7  pop rsi
000076c1d9ddd9d8  pop rdi
000076c1d9ddd9d9  pop rdx
000076c1d9ddd9da  pop rcx
000076c1d9ddd9db  pop rax
000076c1d9ddd9dc  add rsp, 0x08
000076c1d9ddd9e0  jmp 0x000076C1D9DDBE87
000076c1d9ddd9e5  sub rsp, 0x08
000076c1d9ddd9e9  push rax
000076c1d9ddd9ea  push rcx
000076c1d9ddd9eb  push rdx
000076c1d9ddd9ec  push rdi
000076c1d9ddd9ed  push rsi
000076c1d9ddd9ee  push r8
000076c1d9ddd9f0  push r9
000076c1d9ddd9f2  push r10
000076c1d9ddd9f4  push r11
000076c1d9ddd9f6  sub rsp, 0xF0
000076c1d9ddd9fd  vmovaps [rsp], xmm0
000076c1d9ddda02  vmovaps [rsp+0x10], xmm1
000076c1d9ddda08  vmovaps [rsp+0x20], xmm2
000076c1d9ddda0e  vmovaps [rsp+0x30], xmm3
000076c1d9ddda14  vmovaps [rsp+0x40], xmm5
000076c1d9ddda1a  vmovaps [rsp+0x50], xmm6
000076c1d9ddda20  vmovaps [rsp+0x60], xmm7
000076c1d9ddda26  vmovaps [rsp+0x70], xmm8
000076c1d9ddda2c  vmovaps [rsp+0x80], xmm9
000076c1d9ddda35  vmovaps [rsp+0x90], xmm10
000076c1d9ddda3e  vmovaps [rsp+0xA0], xmm11
000076c1d9ddda47  vmovaps [rsp+0xB0], xmm12
000076c1d9ddda50  vmovaps [rsp+0xC0], xmm13
000076c1d9ddda59  vmovaps [rsp+0xD0], xmm14
000076c1d9ddda62  vmovaps [rsp+0xE0], xmm15
000076c1d9ddda6b  sub rsp, 0x30
000076c1d9ddda6f  movaps [rsp], xmm4
000076c1d9ddda73  movaps [rsp+0x10], xmm15
000076c1d9ddda79  movaps [rsp+0x20], xmm9
000076c1d9ddda7f  lea rdi, [rsp]
000076c1d9ddda83  mov esi, 0x00
000076c1d9ddda88  mov rax, 0x5EA58B9E0530
000076c1d9ddda92  call rax
000076c1d9ddda94  movaps xmm4, [rsp]
000076c1d9ddda98  add rsp, 0x30
000076c1d9ddda9c  vmovaps xmm0, [rsp]
000076c1d9dddaa1  vmovaps xmm1, [rsp+0x10]
000076c1d9dddaa7  vmovaps xmm2, [rsp+0x20]
000076c1d9dddaad  vmovaps xmm3, [rsp+0x30]
000076c1d9dddab3  vmovaps xmm5, [rsp+0x40]
000076c1d9dddab9  vmovaps xmm6, [rsp+0x50]
000076c1d9dddabf  vmovaps xmm7, [rsp+0x60]
000076c1d9dddac5  vmovaps xmm8, [rsp+0x70]
000076c1d9dddacb  vmovaps xmm9, [rsp+0x80]
000076c1d9dddad4  vmovaps xmm10, [rsp+0x90]
000076c1d9dddadd  vmovaps xmm11, [rsp+0xA0]
000076c1d9dddae6  vmovaps xmm12, [rsp+0xB0]
000076c1d9dddaef  vmovaps xmm13, [rsp+0xC0]
000076c1d9dddaf8  vmovaps xmm14, [rsp+0xD0]
000076c1d9dddb01  vmovaps xmm15, [rsp+0xE0]
000076c1d9dddb0a  add rsp, 0xF0
000076c1d9dddb11  pop r11
000076c1d9dddb13  pop r10
000076c1d9dddb15  pop r9
000076c1d9dddb17  pop r8
000076c1d9dddb19  pop rsi
000076c1d9dddb1a  pop rdi
000076c1d9dddb1b  pop rdx
000076c1d9dddb1c  pop rcx
000076c1d9dddb1d  pop rax
000076c1d9dddb1e  add rsp, 0x08
000076c1d9dddb22  jmp 0x000076C1D9DDBEAC
000076c1d9dddb27  call 0x000076C1D9CC4620
000076c1d9dddb2c  jmp 0x000076C1D9DDBEB9
000076c1d9dddb31  sub rsp, 0x08
000076c1d9dddb35  push rax
000076c1d9dddb36  push rcx
000076c1d9dddb37  push rdx
000076c1d9dddb38  push rdi
000076c1d9dddb39  push rsi
000076c1d9dddb3a  push r8
000076c1d9dddb3c  push r9
000076c1d9dddb3e  push r10
000076c1d9dddb40  push r11
000076c1d9dddb42  sub rsp, 0xF0
000076c1d9dddb49  vmovaps [rsp], xmm0
000076c1d9dddb4e  vmovaps [rsp+0x10], xmm1
000076c1d9dddb54  vmovaps [rsp+0x20], xmm2
000076c1d9dddb5a  vmovaps [rsp+0x30], xmm4
000076c1d9dddb60  vmovaps [rsp+0x40], xmm5
000076c1d9dddb66  vmovaps [rsp+0x50], xmm6
000076c1d9dddb6c  vmovaps [rsp+0x60], xmm7
000076c1d9dddb72  vmovaps [rsp+0x70], xmm8
000076c1d9dddb78  vmovaps [rsp+0x80], xmm9
000076c1d9dddb81  vmovaps [rsp+0x90], xmm10
000076c1d9dddb8a  vmovaps [rsp+0xA0], xmm11
000076c1d9dddb93  vmovaps [rsp+0xB0], xmm12
000076c1d9dddb9c  vmovaps [rsp+0xC0], xmm13
000076c1d9dddba5  vmovaps [rsp+0xD0], xmm14
000076c1d9dddbae  vmovaps [rsp+0xE0], xmm15
000076c1d9dddbb7  sub rsp, 0x30
000076c1d9dddbbb  movaps [rsp], xmm3
000076c1d9dddbbf  movaps [rsp+0x10], xmm1
000076c1d9dddbc4  movaps [rsp+0x20], xmm9
000076c1d9dddbca  lea rdi, [rsp]
000076c1d9dddbce  mov esi, 0x00
000076c1d9dddbd3  mov rax, 0x5EA58B9E0530
000076c1d9dddbdd  call rax
000076c1d9dddbdf  movaps xmm3, [rsp]
000076c1d9dddbe3  add rsp, 0x30
000076c1d9dddbe7  vmovaps xmm0, [rsp]
000076c1d9dddbec  vmovaps xmm1, [rsp+0x10]
000076c1d9dddbf2  vmovaps xmm2, [rsp+0x20]
000076c1d9dddbf8  vmovaps xmm4, [rsp+0x30]
000076c1d9dddbfe  vmovaps xmm5, [rsp+0x40]
000076c1d9dddc04  vmovaps xmm6, [rsp+0x50]
000076c1d9dddc0a  vmovaps xmm7, [rsp+0x60]
000076c1d9dddc10  vmovaps xmm8, [rsp+0x70]
000076c1d9dddc16  vmovaps xmm9, [rsp+0x80]
000076c1d9dddc1f  vmovaps xmm10, [rsp+0x90]
000076c1d9dddc28  vmovaps xmm11, [rsp+0xA0]
000076c1d9dddc31  vmovaps xmm12, [rsp+0xB0]
000076c1d9dddc3a  vmovaps xmm13, [rsp+0xC0]
000076c1d9dddc43  vmovaps xmm14, [rsp+0xD0]
000076c1d9dddc4c  vmovaps xmm15, [rsp+0xE0]
000076c1d9dddc55  add rsp, 0xF0
000076c1d9dddc5c  pop r11
000076c1d9dddc5e  pop r10
000076c1d9dddc60  pop r9
000076c1d9dddc62  pop r8
000076c1d9dddc64  pop rsi
000076c1d9dddc65  pop rdi
000076c1d9dddc66  pop rdx
000076c1d9dddc67  pop rcx
000076c1d9dddc68  pop rax
000076c1d9dddc69  add rsp, 0x08
000076c1d9dddc6d  jmp 0x000076C1D9DDBEF6
000076c1d9dddc72  sub rsp, 0x08
000076c1d9dddc76  push rax
000076c1d9dddc77  push rcx
000076c1d9dddc78  push rdx
000076c1d9dddc79  push rdi
000076c1d9dddc7a  push rsi
000076c1d9dddc7b  push r8
000076c1d9dddc7d  push r9
000076c1d9dddc7f  push r10
000076c1d9dddc81  push r11
000076c1d9dddc83  sub rsp, 0xF0
000076c1d9dddc8a  vmovaps [rsp], xmm0
000076c1d9dddc8f  vmovaps [rsp+0x10], xmm2
000076c1d9dddc95  vmovaps [rsp+0x20], xmm3
000076c1d9dddc9b  vmovaps [rsp+0x30], xmm4
000076c1d9dddca1  vmovaps [rsp+0x40], xmm5
000076c1d9dddca7  vmovaps [rsp+0x50], xmm6
000076c1d9dddcad  vmovaps [rsp+0x60], xmm7
000076c1d9dddcb3  vmovaps [rsp+0x70], xmm8
000076c1d9dddcb9  vmovaps [rsp+0x80], xmm9
000076c1d9dddcc2  vmovaps [rsp+0x90], xmm10
000076c1d9dddccb  vmovaps [rsp+0xA0], xmm11
000076c1d9dddcd4  vmovaps [rsp+0xB0], xmm12
000076c1d9dddcdd  vmovaps [rsp+0xC0], xmm13
000076c1d9dddce6  vmovaps [rsp+0xD0], xmm14
000076c1d9dddcef  vmovaps [rsp+0xE0], xmm15
000076c1d9dddcf8  sub rsp, 0x30
000076c1d9dddcfc  movaps [rsp], xmm1
000076c1d9dddd00  movaps [rsp+0x10], xmm15
000076c1d9dddd06  movaps [rsp+0x20], xmm9
000076c1d9dddd0c  lea rdi, [rsp]
000076c1d9dddd10  mov esi, 0x00
000076c1d9dddd15  mov rax, 0x5EA58B9E0530
000076c1d9dddd1f  call rax
000076c1d9dddd21  movaps xmm1, [rsp]
000076c1d9dddd25  add rsp, 0x30
000076c1d9dddd29  vmovaps xmm0, [rsp]
000076c1d9dddd2e  vmovaps xmm2, [rsp+0x10]
000076c1d9dddd34  vmovaps xmm3, [rsp+0x20]
000076c1d9dddd3a  vmovaps xmm4, [rsp+0x30]
000076c1d9dddd40  vmovaps xmm5, [rsp+0x40]
000076c1d9dddd46  vmovaps xmm6, [rsp+0x50]
000076c1d9dddd4c  vmovaps xmm7, [rsp+0x60]
000076c1d9dddd52  vmovaps xmm8, [rsp+0x70]
000076c1d9dddd58  vmovaps xmm9, [rsp+0x80]
000076c1d9dddd61  vmovaps xmm10, [rsp+0x90]
000076c1d9dddd6a  vmovaps xmm11, [rsp+0xA0]
000076c1d9dddd73  vmovaps xmm12, [rsp+0xB0]
000076c1d9dddd7c  vmovaps xmm13, [rsp+0xC0]
000076c1d9dddd85  vmovaps xmm14, [rsp+0xD0]
000076c1d9dddd8e  vmovaps xmm15, [rsp+0xE0]
000076c1d9dddd97  add rsp, 0xF0
000076c1d9dddd9e  pop r11
000076c1d9dddda0  pop r10
000076c1d9dddda2  pop r9
000076c1d9dddda4  pop r8
000076c1d9dddda6  pop rsi
000076c1d9dddda7  pop rdi
000076c1d9dddda8  pop rdx
000076c1d9dddda9  pop rcx
000076c1d9ddddaa  pop rax
000076c1d9ddddab  add rsp, 0x08
000076c1d9ddddaf  jmp 0x000076C1D9DDBF7E
000076c1d9ddddb4  call 0x000076C1D9CC4620
000076c1d9ddddb9  jmp 0x000076C1D9DDBF8B
000076c1d9ddddbe  sub rsp, 0x08
000076c1d9ddddc2  push rax
000076c1d9ddddc3  push rcx
000076c1d9ddddc4  push rdx
000076c1d9ddddc5  push rdi
000076c1d9ddddc6  push rsi
000076c1d9ddddc7  push r8
000076c1d9ddddc9  push r9
000076c1d9ddddcb  push r10
000076c1d9ddddcd  push r11
000076c1d9ddddcf  sub rsp, 0xF0
000076c1d9ddddd6  vmovaps [rsp], xmm0
000076c1d9dddddb  vmovaps [rsp+0x10], xmm2
000076c1d9dddde1  vmovaps [rsp+0x20], xmm3
000076c1d9dddde7  vmovaps [rsp+0x30], xmm4
000076c1d9dddded  vmovaps [rsp+0x40], xmm5
000076c1d9ddddf3  vmovaps [rsp+0x50], xmm6
000076c1d9ddddf9  vmovaps [rsp+0x60], xmm7
000076c1d9ddddff  vmovaps [rsp+0x70], xmm8
000076c1d9ddde05  vmovaps [rsp+0x80], xmm9
000076c1d9ddde0e  vmovaps [rsp+0x90], xmm10
000076c1d9ddde17  vmovaps [rsp+0xA0], xmm11
000076c1d9ddde20  vmovaps [rsp+0xB0], xmm12
000076c1d9ddde29  vmovaps [rsp+0xC0], xmm13
000076c1d9ddde32  vmovaps [rsp+0xD0], xmm14
000076c1d9ddde3b  vmovaps [rsp+0xE0], xmm15
000076c1d9ddde44  sub rsp, 0x30
000076c1d9ddde48  movaps [rsp], xmm1
000076c1d9ddde4c  movaps [rsp+0x10], xmm5
000076c1d9ddde51  movaps [rsp+0x20], xmm7
000076c1d9ddde56  lea rdi, [rsp]
000076c1d9ddde5a  mov esi, 0x00
000076c1d9ddde5f  mov rax, 0x5EA58B9E0530
000076c1d9ddde69  call rax
000076c1d9ddde6b  movaps xmm1, [rsp]
000076c1d9ddde6f  add rsp, 0x30
000076c1d9ddde73  vmovaps xmm0, [rsp]
000076c1d9ddde78  vmovaps xmm2, [rsp+0x10]
000076c1d9ddde7e  vmovaps xmm3, [rsp+0x20]
000076c1d9ddde84  vmovaps xmm4, [rsp+0x30]
000076c1d9ddde8a  vmovaps xmm5, [rsp+0x40]
000076c1d9ddde90  vmovaps xmm6, [rsp+0x50]
000076c1d9ddde96  vmovaps xmm7, [rsp+0x60]
000076c1d9ddde9c  vmovaps xmm8, [rsp+0x70]
000076c1d9dddea2  vmovaps xmm9, [rsp+0x80]
000076c1d9dddeab  vmovaps xmm10, [rsp+0x90]
000076c1d9dddeb4  vmovaps xmm11, [rsp+0xA0]
000076c1d9dddebd  vmovaps xmm12, [rsp+0xB0]
000076c1d9dddec6  vmovaps xmm13, [rsp+0xC0]
000076c1d9dddecf  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddded8  vmovaps xmm15, [rsp+0xE0]
000076c1d9dddee1  add rsp, 0xF0
000076c1d9dddee8  pop r11
000076c1d9dddeea  pop r10
000076c1d9dddeec  pop r9
000076c1d9dddeee  pop r8
000076c1d9dddef0  pop rsi
000076c1d9dddef1  pop rdi
000076c1d9dddef2  pop rdx
000076c1d9dddef3  pop rcx
000076c1d9dddef4  pop rax
000076c1d9dddef5  add rsp, 0x08
000076c1d9dddef9  jmp 0x000076C1D9DDC030
000076c1d9dddefe  sub rsp, 0x08
000076c1d9dddf02  push rax
000076c1d9dddf03  push rcx
000076c1d9dddf04  push rdx
000076c1d9dddf05  push rdi
000076c1d9dddf06  push rsi
000076c1d9dddf07  push r8
000076c1d9dddf09  push r9
000076c1d9dddf0b  push r10
000076c1d9dddf0d  push r11
000076c1d9dddf0f  sub rsp, 0xF0
000076c1d9dddf16  vmovaps [rsp], xmm0
000076c1d9dddf1b  vmovaps [rsp+0x10], xmm1
000076c1d9dddf21  vmovaps [rsp+0x20], xmm2
000076c1d9dddf27  vmovaps [rsp+0x30], xmm3
000076c1d9dddf2d  vmovaps [rsp+0x40], xmm4
000076c1d9dddf33  vmovaps [rsp+0x50], xmm5
000076c1d9dddf39  vmovaps [rsp+0x60], xmm6
000076c1d9dddf3f  vmovaps [rsp+0x70], xmm8
000076c1d9dddf45  vmovaps [rsp+0x80], xmm9
000076c1d9dddf4e  vmovaps [rsp+0x90], xmm10
000076c1d9dddf57  vmovaps [rsp+0xA0], xmm11
000076c1d9dddf60  vmovaps [rsp+0xB0], xmm12
000076c1d9dddf69  vmovaps [rsp+0xC0], xmm13
000076c1d9dddf72  vmovaps [rsp+0xD0], xmm14
000076c1d9dddf7b  vmovaps [rsp+0xE0], xmm15
000076c1d9dddf84  sub rsp, 0x30
000076c1d9dddf88  movaps [rsp], xmm7
000076c1d9dddf8c  movaps [rsp+0x10], xmm5
000076c1d9dddf91  movaps [rsp+0x20], xmm15
000076c1d9dddf97  lea rdi, [rsp]
000076c1d9dddf9b  mov esi, 0x00
000076c1d9dddfa0  mov rax, 0x5EA58B9E0530
000076c1d9dddfaa  call rax
000076c1d9dddfac  movaps xmm7, [rsp]
000076c1d9dddfb0  add rsp, 0x30
000076c1d9dddfb4  vmovaps xmm0, [rsp]
000076c1d9dddfb9  vmovaps xmm1, [rsp+0x10]
000076c1d9dddfbf  vmovaps xmm2, [rsp+0x20]
000076c1d9dddfc5  vmovaps xmm3, [rsp+0x30]
000076c1d9dddfcb  vmovaps xmm4, [rsp+0x40]
000076c1d9dddfd1  vmovaps xmm5, [rsp+0x50]
000076c1d9dddfd7  vmovaps xmm6, [rsp+0x60]
000076c1d9dddfdd  vmovaps xmm8, [rsp+0x70]
000076c1d9dddfe3  vmovaps xmm9, [rsp+0x80]
000076c1d9dddfec  vmovaps xmm10, [rsp+0x90]
000076c1d9dddff5  vmovaps xmm11, [rsp+0xA0]
000076c1d9dddffe  vmovaps xmm12, [rsp+0xB0]
000076c1d9dde007  vmovaps xmm13, [rsp+0xC0]
000076c1d9dde010  vmovaps xmm14, [rsp+0xD0]
000076c1d9dde019  vmovaps xmm15, [rsp+0xE0]
000076c1d9dde022  add rsp, 0xF0
000076c1d9dde029  pop r11
000076c1d9dde02b  pop r10
000076c1d9dde02d  pop r9
000076c1d9dde02f  pop r8
000076c1d9dde031  pop rsi
000076c1d9dde032  pop rdi
000076c1d9dde033  pop rdx
000076c1d9dde034  pop rcx
000076c1d9dde035  pop rax
000076c1d9dde036  add rsp, 0x08
000076c1d9dde03a  jmp 0x000076C1D9DDC066
000076c1d9dde03f  call 0x000076C1D9CB52F0
000076c1d9dde044  jmp 0x000076C1D9DDC073
000076c1d9dde049  sub rsp, 0x08
000076c1d9dde04d  push rax
000076c1d9dde04e  push rcx
000076c1d9dde04f  push rdx
000076c1d9dde050  push rdi
000076c1d9dde051  push rsi
000076c1d9dde052  push r8
000076c1d9dde054  push r9
000076c1d9dde056  push r10
000076c1d9dde058  push r11
000076c1d9dde05a  sub rsp, 0xF0
000076c1d9dde061  vmovaps [rsp], xmm0
000076c1d9dde066  vmovaps [rsp+0x10], xmm1
000076c1d9dde06c  vmovaps [rsp+0x20], xmm2
000076c1d9dde072  vmovaps [rsp+0x30], xmm3
000076c1d9dde078  vmovaps [rsp+0x40], xmm4
000076c1d9dde07e  vmovaps [rsp+0x50], xmm5
000076c1d9dde084  vmovaps [rsp+0x60], xmm6
000076c1d9dde08a  vmovaps [rsp+0x70], xmm7
000076c1d9dde090  vmovaps [rsp+0x80], xmm8
000076c1d9dde099  vmovaps [rsp+0x90], xmm9
000076c1d9dde0a2  vmovaps [rsp+0xA0], xmm10
000076c1d9dde0ab  vmovaps [rsp+0xB0], xmm11
000076c1d9dde0b4  vmovaps [rsp+0xC0], xmm12
000076c1d9dde0bd  vmovaps [rsp+0xD0], xmm13
000076c1d9dde0c6  vmovaps [rsp+0xE0], xmm14
000076c1d9dde0cf  sub rsp, 0x30
000076c1d9dde0d3  movaps [rsp], xmm15
000076c1d9dde0d8  movaps [rsp+0x10], xmm5
000076c1d9dde0dd  movaps [rsp+0x20], xmm3
000076c1d9dde0e2  lea rdi, [rsp]
000076c1d9dde0e6  mov esi, 0x00
000076c1d9dde0eb  mov rax, 0x5EA58B9E0530
000076c1d9dde0f5  call rax
000076c1d9dde0f7  movaps xmm15, [rsp]
000076c1d9dde0fc  add rsp, 0x30
000076c1d9dde100  vmovaps xmm0, [rsp]
000076c1d9dde105  vmovaps xmm1, [rsp+0x10]
000076c1d9dde10b  vmovaps xmm2, [rsp+0x20]
000076c1d9dde111  vmovaps xmm3, [rsp+0x30]
000076c1d9dde117  vmovaps xmm4, [rsp+0x40]
000076c1d9dde11d  vmovaps xmm5, [rsp+0x50]
000076c1d9dde123  vmovaps xmm6, [rsp+0x60]
000076c1d9dde129  vmovaps xmm7, [rsp+0x70]
000076c1d9dde12f  vmovaps xmm8, [rsp+0x80]
000076c1d9dde138  vmovaps xmm9, [rsp+0x90]
000076c1d9dde141  vmovaps xmm10, [rsp+0xA0]
000076c1d9dde14a  vmovaps xmm11, [rsp+0xB0]
000076c1d9dde153  vmovaps xmm12, [rsp+0xC0]
000076c1d9dde15c  vmovaps xmm13, [rsp+0xD0]
000076c1d9dde165  vmovaps xmm14, [rsp+0xE0]
000076c1d9dde16e  add rsp, 0xF0
000076c1d9dde175  pop r11
000076c1d9dde177  pop r10
000076c1d9dde179  pop r9
000076c1d9dde17b  pop r8
000076c1d9dde17d  pop rsi
000076c1d9dde17e  pop rdi
000076c1d9dde17f  pop rdx
000076c1d9dde180  pop rcx
000076c1d9dde181  pop rax
000076c1d9dde182  add rsp, 0x08
000076c1d9dde186  jmp 0x000076C1D9DDC099
000076c1d9dde18b  sub rsp, 0x08
000076c1d9dde18f  push rax
000076c1d9dde190  push rcx
000076c1d9dde191  push rdx
000076c1d9dde192  push rdi
000076c1d9dde193  push rsi
000076c1d9dde194  push r8
000076c1d9dde196  push r9
000076c1d9dde198  push r10
000076c1d9dde19a  push r11
000076c1d9dde19c  sub rsp, 0xF0
000076c1d9dde1a3  vmovaps [rsp], xmm0
000076c1d9dde1a8  vmovaps [rsp+0x10], xmm2
000076c1d9dde1ae  vmovaps [rsp+0x20], xmm3
000076c1d9dde1b4  vmovaps [rsp+0x30], xmm4
000076c1d9dde1ba  vmovaps [rsp+0x40], xmm5
000076c1d9dde1c0  vmovaps [rsp+0x50], xmm6
000076c1d9dde1c6  vmovaps [rsp+0x60], xmm7
000076c1d9dde1cc  vmovaps [rsp+0x70], xmm8
000076c1d9dde1d2  vmovaps [rsp+0x80], xmm9
000076c1d9dde1db  vmovaps [rsp+0x90], xmm10
000076c1d9dde1e4  vmovaps [rsp+0xA0], xmm11
000076c1d9dde1ed  vmovaps [rsp+0xB0], xmm12
000076c1d9dde1f6  vmovaps [rsp+0xC0], xmm13
000076c1d9dde1ff  vmovaps [rsp+0xD0], xmm14
000076c1d9dde208  vmovaps [rsp+0xE0], xmm15
000076c1d9dde211  sub rsp, 0x30
000076c1d9dde215  movaps [rsp], xmm1
000076c1d9dde219  movaps [rsp+0x10], xmm5
000076c1d9dde21e  movaps [rsp+0x20], xmm4
000076c1d9dde223  lea rdi, [rsp]
000076c1d9dde227  mov esi, 0x00
000076c1d9dde22c  mov rax, 0x5EA58B9E0530
000076c1d9dde236  call rax
000076c1d9dde238  movaps xmm1, [rsp]
000076c1d9dde23c  add rsp, 0x30
000076c1d9dde240  vmovaps xmm0, [rsp]
000076c1d9dde245  vmovaps xmm2, [rsp+0x10]
000076c1d9dde24b  vmovaps xmm3, [rsp+0x20]
000076c1d9dde251  vmovaps xmm4, [rsp+0x30]
000076c1d9dde257  vmovaps xmm5, [rsp+0x40]
000076c1d9dde25d  vmovaps xmm6, [rsp+0x50]
000076c1d9dde263  vmovaps xmm7, [rsp+0x60]
000076c1d9dde269  vmovaps xmm8, [rsp+0x70]
000076c1d9dde26f  vmovaps xmm9, [rsp+0x80]
000076c1d9dde278  vmovaps xmm10, [rsp+0x90]
000076c1d9dde281  vmovaps xmm11, [rsp+0xA0]
000076c1d9dde28a  vmovaps xmm12, [rsp+0xB0]
000076c1d9dde293  vmovaps xmm13, [rsp+0xC0]
000076c1d9dde29c  vmovaps xmm14, [rsp+0xD0]
000076c1d9dde2a5  vmovaps xmm15, [rsp+0xE0]
000076c1d9dde2ae  add rsp, 0xF0
000076c1d9dde2b5  pop r11
000076c1d9dde2b7  pop r10
000076c1d9dde2b9  pop r9
000076c1d9dde2bb  pop r8
000076c1d9dde2bd  pop rsi
000076c1d9dde2be  pop rdi
000076c1d9dde2bf  pop rdx
000076c1d9dde2c0  pop rcx
000076c1d9dde2c1  pop rax
000076c1d9dde2c2  add rsp, 0x08
000076c1d9dde2c6  jmp 0x000076C1D9DDC0B9
000076c1d9dde2cb  sub rsp, 0x08
000076c1d9dde2cf  push rax
000076c1d9dde2d0  push rcx
000076c1d9dde2d1  push rdx
000076c1d9dde2d2  push rdi
000076c1d9dde2d3  push rsi
000076c1d9dde2d4  push r8
000076c1d9dde2d6  push r9
000076c1d9dde2d8  push r10
000076c1d9dde2da  push r11
000076c1d9dde2dc  sub rsp, 0xF0
000076c1d9dde2e3  vmovaps [rsp], xmm0
000076c1d9dde2e8  vmovaps [rsp+0x10], xmm1
000076c1d9dde2ee  vmovaps [rsp+0x20], xmm2
000076c1d9dde2f4  vmovaps [rsp+0x30], xmm3
000076c1d9dde2fa  vmovaps [rsp+0x40], xmm5
000076c1d9dde300  vmovaps [rsp+0x50], xmm6
000076c1d9dde306  vmovaps [rsp+0x60], xmm7
000076c1d9dde30c  vmovaps [rsp+0x70], xmm8
000076c1d9dde312  vmovaps [rsp+0x80], xmm9
000076c1d9dde31b  vmovaps [rsp+0x90], xmm10
000076c1d9dde324  vmovaps [rsp+0xA0], xmm11
000076c1d9dde32d  vmovaps [rsp+0xB0], xmm12
000076c1d9dde336  vmovaps [rsp+0xC0], xmm13
000076c1d9dde33f  vmovaps [rsp+0xD0], xmm14
000076c1d9dde348  vmovaps [rsp+0xE0], xmm15
000076c1d9dde351  sub rsp, 0x30
000076c1d9dde355  movaps [rsp], xmm4
000076c1d9dde359  movaps [rsp+0x10], xmm3
000076c1d9dde35e  movaps [rsp+0x20], xmm5
000076c1d9dde363  lea rdi, [rsp]
000076c1d9dde367  mov esi, 0x00
000076c1d9dde36c  mov rax, 0x5EA58B9E0530
000076c1d9dde376  call rax
000076c1d9dde378  movaps xmm4, [rsp]
000076c1d9dde37c  add rsp, 0x30
000076c1d9dde380  vmovaps xmm0, [rsp]
000076c1d9dde385  vmovaps xmm1, [rsp+0x10]
000076c1d9dde38b  vmovaps xmm2, [rsp+0x20]
000076c1d9dde391  vmovaps xmm3, [rsp+0x30]
000076c1d9dde397  vmovaps xmm5, [rsp+0x40]
000076c1d9dde39d  vmovaps xmm6, [rsp+0x50]
000076c1d9dde3a3  vmovaps xmm7, [rsp+0x60]
000076c1d9dde3a9  vmovaps xmm8, [rsp+0x70]
000076c1d9dde3af  vmovaps xmm9, [rsp+0x80]
000076c1d9dde3b8  vmovaps xmm10, [rsp+0x90]
000076c1d9dde3c1  vmovaps xmm11, [rsp+0xA0]
000076c1d9dde3ca  vmovaps xmm12, [rsp+0xB0]
000076c1d9dde3d3  vmovaps xmm13, [rsp+0xC0]
000076c1d9dde3dc  vmovaps xmm14, [rsp+0xD0]
000076c1d9dde3e5  vmovaps xmm15, [rsp+0xE0]
000076c1d9dde3ee  add rsp, 0xF0
000076c1d9dde3f5  pop r11
000076c1d9dde3f7  pop r10
000076c1d9dde3f9  pop r9
000076c1d9dde3fb  pop r8
000076c1d9dde3fd  pop rsi
000076c1d9dde3fe  pop rdi
000076c1d9dde3ff  pop rdx
000076c1d9dde400  pop rcx
000076c1d9dde401  pop rax
000076c1d9dde402  add rsp, 0x08
000076c1d9dde406  jmp 0x000076C1D9DDC107
000076c1d9dde40b  call 0x000076C1D9CB52F0
000076c1d9dde410  jmp 0x000076C1D9DDC114
000076c1d9dde415  sub rsp, 0x08
000076c1d9dde419  push rax
000076c1d9dde41a  push rcx
000076c1d9dde41b  push rdx
000076c1d9dde41c  push rdi
000076c1d9dde41d  push rsi
000076c1d9dde41e  push r8
000076c1d9dde420  push r9
000076c1d9dde422  push r10
000076c1d9dde424  push r11
000076c1d9dde426  sub rsp, 0xF0
000076c1d9dde42d  vmovaps [rsp], xmm0
000076c1d9dde432  vmovaps [rsp+0x10], xmm1
000076c1d9dde438  vmovaps [rsp+0x20], xmm2
000076c1d9dde43e  vmovaps [rsp+0x30], xmm3
000076c1d9dde444  vmovaps [rsp+0x40], xmm4
000076c1d9dde44a  vmovaps [rsp+0x50], xmm6
000076c1d9dde450  vmovaps [rsp+0x60], xmm7
000076c1d9dde456  vmovaps [rsp+0x70], xmm8
000076c1d9dde45c  vmovaps [rsp+0x80], xmm9
000076c1d9dde465  vmovaps [rsp+0x90], xmm10
000076c1d9dde46e  vmovaps [rsp+0xA0], xmm11
000076c1d9dde477  vmovaps [rsp+0xB0], xmm12
000076c1d9dde480  vmovaps [rsp+0xC0], xmm13
000076c1d9dde489  vmovaps [rsp+0xD0], xmm14
000076c1d9dde492  vmovaps [rsp+0xE0], xmm15
000076c1d9dde49b  sub rsp, 0x30
000076c1d9dde49f  movaps [rsp], xmm5
000076c1d9dde4a3  movaps [rsp+0x10], xmm6
000076c1d9dde4a8  movaps [rsp+0x20], xmm3
000076c1d9dde4ad  lea rdi, [rsp]
000076c1d9dde4b1  mov esi, 0x00
000076c1d9dde4b6  mov rax, 0x5EA58B9E0530
000076c1d9dde4c0  call rax
000076c1d9dde4c2  movaps xmm5, [rsp]
000076c1d9dde4c6  add rsp, 0x30
000076c1d9dde4ca  vmovaps xmm0, [rsp]
000076c1d9dde4cf  vmovaps xmm1, [rsp+0x10]
000076c1d9dde4d5  vmovaps xmm2, [rsp+0x20]
000076c1d9dde4db  vmovaps xmm3, [rsp+0x30]
000076c1d9dde4e1  vmovaps xmm4, [rsp+0x40]
000076c1d9dde4e7  vmovaps xmm6, [rsp+0x50]
000076c1d9dde4ed  vmovaps xmm7, [rsp+0x60]
000076c1d9dde4f3  vmovaps xmm8, [rsp+0x70]
000076c1d9dde4f9  vmovaps xmm9, [rsp+0x80]
000076c1d9dde502  vmovaps xmm10, [rsp+0x90]
000076c1d9dde50b  vmovaps xmm11, [rsp+0xA0]
000076c1d9dde514  vmovaps xmm12, [rsp+0xB0]
000076c1d9dde51d  vmovaps xmm13, [rsp+0xC0]
000076c1d9dde526  vmovaps xmm14, [rsp+0xD0]
000076c1d9dde52f  vmovaps xmm15, [rsp+0xE0]
000076c1d9dde538  add rsp, 0xF0
000076c1d9dde53f  pop r11
000076c1d9dde541  pop r10
000076c1d9dde543  pop r9
000076c1d9dde545  pop r8
000076c1d9dde547  pop rsi
000076c1d9dde548  pop rdi
000076c1d9dde549  pop rdx
000076c1d9dde54a  pop rcx
000076c1d9dde54b  pop rax
000076c1d9dde54c  add rsp, 0x08
000076c1d9dde550  jmp 0x000076C1D9DDC13A
000076c1d9dde555  sub rsp, 0x08
000076c1d9dde559  push rax
000076c1d9dde55a  push rcx
000076c1d9dde55b  push rdx
000076c1d9dde55c  push rdi
000076c1d9dde55d  push rsi
000076c1d9dde55e  push r8
000076c1d9dde560  push r9
000076c1d9dde562  push r10
000076c1d9dde564  push r11
000076c1d9dde566  sub rsp, 0xF0
000076c1d9dde56d  vmovaps [rsp], xmm0
000076c1d9dde572  vmovaps [rsp+0x10], xmm1
000076c1d9dde578  vmovaps [rsp+0x20], xmm2
000076c1d9dde57e  vmovaps [rsp+0x30], xmm3
000076c1d9dde584  vmovaps [rsp+0x40], xmm4
000076c1d9dde58a  vmovaps [rsp+0x50], xmm5
000076c1d9dde590  vmovaps [rsp+0x60], xmm7
000076c1d9dde596  vmovaps [rsp+0x70], xmm8
000076c1d9dde59c  vmovaps [rsp+0x80], xmm9
000076c1d9dde5a5  vmovaps [rsp+0x90], xmm10
000076c1d9dde5ae  vmovaps [rsp+0xA0], xmm11
000076c1d9dde5b7  vmovaps [rsp+0xB0], xmm12
000076c1d9dde5c0  vmovaps [rsp+0xC0], xmm13
000076c1d9dde5c9  vmovaps [rsp+0xD0], xmm14
000076c1d9dde5d2  vmovaps [rsp+0xE0], xmm15
000076c1d9dde5db  sub rsp, 0x30
000076c1d9dde5df  movaps [rsp], xmm6
000076c1d9dde5e3  movaps [rsp+0x10], xmm9
000076c1d9dde5e9  movaps [rsp+0x20], xmm1
000076c1d9dde5ee  lea rdi, [rsp]
000076c1d9dde5f2  mov esi, 0x00
000076c1d9dde5f7  mov rax, 0x5EA58B9E0530
000076c1d9dde601  call rax
000076c1d9dde603  movaps xmm6, [rsp]
000076c1d9dde607  add rsp, 0x30
000076c1d9dde60b  vmovaps xmm0, [rsp]
000076c1d9dde610  vmovaps xmm1, [rsp+0x10]
000076c1d9dde616  vmovaps xmm2, [rsp+0x20]
000076c1d9dde61c  vmovaps xmm3, [rsp+0x30]
000076c1d9dde622  vmovaps xmm4, [rsp+0x40]
000076c1d9dde628  vmovaps xmm5, [rsp+0x50]
000076c1d9dde62e  vmovaps xmm7, [rsp+0x60]
000076c1d9dde634  vmovaps xmm8, [rsp+0x70]
000076c1d9dde63a  vmovaps xmm9, [rsp+0x80]
000076c1d9dde643  vmovaps xmm10, [rsp+0x90]
000076c1d9dde64c  vmovaps xmm11, [rsp+0xA0]
000076c1d9dde655  vmovaps xmm12, [rsp+0xB0]
000076c1d9dde65e  vmovaps xmm13, [rsp+0xC0]
000076c1d9dde667  vmovaps xmm14, [rsp+0xD0]
000076c1d9dde670  vmovaps xmm15, [rsp+0xE0]
000076c1d9dde679  add rsp, 0xF0
000076c1d9dde680  pop r11
000076c1d9dde682  pop r10
000076c1d9dde684  pop r9
000076c1d9dde686  pop r8
000076c1d9dde688  pop rsi
000076c1d9dde689  pop rdi
000076c1d9dde68a  pop rdx
000076c1d9dde68b  pop rcx
000076c1d9dde68c  pop rax
000076c1d9dde68d  add rsp, 0x08
000076c1d9dde691  jmp 0x000076C1D9DDC15E
000076c1d9dde696  sub rsp, 0x08
000076c1d9dde69a  push rax
000076c1d9dde69b  push rcx
000076c1d9dde69c  push rdx
000076c1d9dde69d  push rdi
000076c1d9dde69e  push rsi
000076c1d9dde69f  push r8
000076c1d9dde6a1  push r9
000076c1d9dde6a3  push r10
000076c1d9dde6a5  push r11
000076c1d9dde6a7  sub rsp, 0xF0
000076c1d9dde6ae  vmovaps [rsp], xmm0
000076c1d9dde6b3  vmovaps [rsp+0x10], xmm1
000076c1d9dde6b9  vmovaps [rsp+0x20], xmm2
000076c1d9dde6bf  vmovaps [rsp+0x30], xmm3
000076c1d9dde6c5  vmovaps [rsp+0x40], xmm4
000076c1d9dde6cb  vmovaps [rsp+0x50], xmm5
000076c1d9dde6d1  vmovaps [rsp+0x60], xmm6
000076c1d9dde6d7  vmovaps [rsp+0x70], xmm7
000076c1d9dde6dd  vmovaps [rsp+0x80], xmm8
000076c1d9dde6e6  vmovaps [rsp+0x90], xmm10
000076c1d9dde6ef  vmovaps [rsp+0xA0], xmm11
000076c1d9dde6f8  vmovaps [rsp+0xB0], xmm12
000076c1d9dde701  vmovaps [rsp+0xC0], xmm13
000076c1d9dde70a  vmovaps [rsp+0xD0], xmm14
000076c1d9dde713  vmovaps [rsp+0xE0], xmm15
000076c1d9dde71c  sub rsp, 0x30
000076c1d9dde720  movaps [rsp], xmm9
000076c1d9dde725  movaps [rsp+0x10], xmm3
000076c1d9dde72a  movaps [rsp+0x20], xmm1
000076c1d9dde72f  lea rdi, [rsp]
000076c1d9dde733  mov esi, 0x00
000076c1d9dde738  mov rax, 0x5EA58B9E0530
000076c1d9dde742  call rax
000076c1d9dde744  movaps xmm9, [rsp]
000076c1d9dde749  add rsp, 0x30
000076c1d9dde74d  vmovaps xmm0, [rsp]
000076c1d9dde752  vmovaps xmm1, [rsp+0x10]
000076c1d9dde758  vmovaps xmm2, [rsp+0x20]
000076c1d9dde75e  vmovaps xmm3, [rsp+0x30]
000076c1d9dde764  vmovaps xmm4, [rsp+0x40]
000076c1d9dde76a  vmovaps xmm5, [rsp+0x50]
000076c1d9dde770  vmovaps xmm6, [rsp+0x60]
000076c1d9dde776  vmovaps xmm7, [rsp+0x70]
000076c1d9dde77c  vmovaps xmm8, [rsp+0x80]
000076c1d9dde785  vmovaps xmm10, [rsp+0x90]
000076c1d9dde78e  vmovaps xmm11, [rsp+0xA0]
000076c1d9dde797  vmovaps xmm12, [rsp+0xB0]
000076c1d9dde7a0  vmovaps xmm13, [rsp+0xC0]
000076c1d9dde7a9  vmovaps xmm14, [rsp+0xD0]
000076c1d9dde7b2  vmovaps xmm15, [rsp+0xE0]
000076c1d9dde7bb  add rsp, 0xF0
000076c1d9dde7c2  pop r11
000076c1d9dde7c4  pop r10
000076c1d9dde7c6  pop r9
000076c1d9dde7c8  pop r8
000076c1d9dde7ca  pop rsi
000076c1d9dde7cb  pop rdi
000076c1d9dde7cc  pop rdx
000076c1d9dde7cd  pop rcx
000076c1d9dde7ce  pop rax
000076c1d9dde7cf  add rsp, 0x08
000076c1d9dde7d3  jmp 0x000076C1D9DDC1AA
000076c1d9dde7d8  call 0x000076C1D9CB52F0
000076c1d9dde7dd  jmp 0x000076C1D9DDC1B7
000076c1d9dde7e2  sub rsp, 0x08
000076c1d9dde7e6  push rax
000076c1d9dde7e7  push rcx
000076c1d9dde7e8  push rdx
000076c1d9dde7e9  push rdi
000076c1d9dde7ea  push rsi
000076c1d9dde7eb  push r8
000076c1d9dde7ed  push r9
000076c1d9dde7ef  push r10
000076c1d9dde7f1  push r11
000076c1d9dde7f3  sub rsp, 0xF0
000076c1d9dde7fa  vmovaps [rsp], xmm0
000076c1d9dde7ff  vmovaps [rsp+0x10], xmm1
000076c1d9dde805  vmovaps [rsp+0x20], xmm2
000076c1d9dde80b  vmovaps [rsp+0x30], xmm3
000076c1d9dde811  vmovaps [rsp+0x40], xmm4
000076c1d9dde817  vmovaps [rsp+0x50], xmm5
000076c1d9dde81d  vmovaps [rsp+0x60], xmm6
000076c1d9dde823  vmovaps [rsp+0x70], xmm7
000076c1d9dde829  vmovaps [rsp+0x80], xmm8
000076c1d9dde832  vmovaps [rsp+0x90], xmm9
000076c1d9dde83b  vmovaps [rsp+0xA0], xmm10
000076c1d9dde844  vmovaps [rsp+0xB0], xmm11
000076c1d9dde84d  vmovaps [rsp+0xC0], xmm12
000076c1d9dde856  vmovaps [rsp+0xD0], xmm13
000076c1d9dde85f  vmovaps [rsp+0xE0], xmm14
000076c1d9dde868  sub rsp, 0x30
000076c1d9dde86c  movaps [rsp], xmm15
000076c1d9dde871  movaps [rsp+0x10], xmm3
000076c1d9dde876  movaps [rsp+0x20], xmm7
000076c1d9dde87b  lea rdi, [rsp]
000076c1d9dde87f  mov esi, 0x00
000076c1d9dde884  mov rax, 0x5EA58B9E0530
000076c1d9dde88e  call rax
000076c1d9dde890  movaps xmm15, [rsp]
000076c1d9dde895  add rsp, 0x30
000076c1d9dde899  vmovaps xmm0, [rsp]
000076c1d9dde89e  vmovaps xmm1, [rsp+0x10]
000076c1d9dde8a4  vmovaps xmm2, [rsp+0x20]
000076c1d9dde8aa  vmovaps xmm3, [rsp+0x30]
000076c1d9dde8b0  vmovaps xmm4, [rsp+0x40]
000076c1d9dde8b6  vmovaps xmm5, [rsp+0x50]
000076c1d9dde8bc  vmovaps xmm6, [rsp+0x60]
000076c1d9dde8c2  vmovaps xmm7, [rsp+0x70]
000076c1d9dde8c8  vmovaps xmm8, [rsp+0x80]
000076c1d9dde8d1  vmovaps xmm9, [rsp+0x90]
000076c1d9dde8da  vmovaps xmm10, [rsp+0xA0]
000076c1d9dde8e3  vmovaps xmm11, [rsp+0xB0]
000076c1d9dde8ec  vmovaps xmm12, [rsp+0xC0]
000076c1d9dde8f5  vmovaps xmm13, [rsp+0xD0]
000076c1d9dde8fe  vmovaps xmm14, [rsp+0xE0]
000076c1d9dde907  add rsp, 0xF0
000076c1d9dde90e  pop r11
000076c1d9dde910  pop r10
000076c1d9dde912  pop r9
000076c1d9dde914  pop r8
000076c1d9dde916  pop rsi
000076c1d9dde917  pop rdi
000076c1d9dde918  pop rdx
000076c1d9dde919  pop rcx
000076c1d9dde91a  pop rax
000076c1d9dde91b  add rsp, 0x08
000076c1d9dde91f  jmp 0x000076C1D9DDC1E3
000076c1d9dde924  sub rsp, 0x08
000076c1d9dde928  push rax
000076c1d9dde929  push rcx
000076c1d9dde92a  push rdx
000076c1d9dde92b  push rdi
000076c1d9dde92c  push rsi
000076c1d9dde92d  push r8
000076c1d9dde92f  push r9
000076c1d9dde931  push r10
000076c1d9dde933  push r11
000076c1d9dde935  sub rsp, 0xF0
000076c1d9dde93c  vmovaps [rsp], xmm0
000076c1d9dde941  vmovaps [rsp+0x10], xmm1
000076c1d9dde947  vmovaps [rsp+0x20], xmm2
000076c1d9dde94d  vmovaps [rsp+0x30], xmm4
000076c1d9dde953  vmovaps [rsp+0x40], xmm5
000076c1d9dde959  vmovaps [rsp+0x50], xmm6
000076c1d9dde95f  vmovaps [rsp+0x60], xmm7
000076c1d9dde965  vmovaps [rsp+0x70], xmm8
000076c1d9dde96b  vmovaps [rsp+0x80], xmm9
000076c1d9dde974  vmovaps [rsp+0x90], xmm10
000076c1d9dde97d  vmovaps [rsp+0xA0], xmm11
000076c1d9dde986  vmovaps [rsp+0xB0], xmm12
000076c1d9dde98f  vmovaps [rsp+0xC0], xmm13
000076c1d9dde998  vmovaps [rsp+0xD0], xmm14
000076c1d9dde9a1  vmovaps [rsp+0xE0], xmm15
000076c1d9dde9aa  sub rsp, 0x30
000076c1d9dde9ae  movaps [rsp], xmm3
000076c1d9dde9b2  movaps [rsp+0x10], xmm1
000076c1d9dde9b7  movaps [rsp+0x20], xmm15
000076c1d9dde9bd  lea rdi, [rsp]
000076c1d9dde9c1  mov esi, 0x00
000076c1d9dde9c6  mov rax, 0x5EA58B9E0530
000076c1d9dde9d0  call rax
000076c1d9dde9d2  movaps xmm3, [rsp]
000076c1d9dde9d6  add rsp, 0x30
000076c1d9dde9da  vmovaps xmm0, [rsp]
000076c1d9dde9df  vmovaps xmm1, [rsp+0x10]
000076c1d9dde9e5  vmovaps xmm2, [rsp+0x20]
000076c1d9dde9eb  vmovaps xmm4, [rsp+0x30]
000076c1d9dde9f1  vmovaps xmm5, [rsp+0x40]
000076c1d9dde9f7  vmovaps xmm6, [rsp+0x50]
000076c1d9dde9fd  vmovaps xmm7, [rsp+0x60]
000076c1d9ddea03  vmovaps xmm8, [rsp+0x70]
000076c1d9ddea09  vmovaps xmm9, [rsp+0x80]
000076c1d9ddea12  vmovaps xmm10, [rsp+0x90]
000076c1d9ddea1b  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddea24  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddea2d  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddea36  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddea3f  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddea48  add rsp, 0xF0
000076c1d9ddea4f  pop r11
000076c1d9ddea51  pop r10
000076c1d9ddea53  pop r9
000076c1d9ddea55  pop r8
000076c1d9ddea57  pop rsi
000076c1d9ddea58  pop rdi
000076c1d9ddea59  pop rdx
000076c1d9ddea5a  pop rcx
000076c1d9ddea5b  pop rax
000076c1d9ddea5c  add rsp, 0x08
000076c1d9ddea60  jmp 0x000076C1D9DDC272
000076c1d9ddea65  call 0x000076C1D9CB52F0
000076c1d9ddea6a  jmp 0x000076C1D9DDC27C
000076c1d9ddea6f  sub rsp, 0x08
000076c1d9ddea73  push rax
000076c1d9ddea74  push rcx
000076c1d9ddea75  push rdx
000076c1d9ddea76  push rdi
000076c1d9ddea77  push rsi
000076c1d9ddea78  push r8
000076c1d9ddea7a  push r9
000076c1d9ddea7c  push r10
000076c1d9ddea7e  push r11
000076c1d9ddea80  sub rsp, 0xF0
000076c1d9ddea87  vmovaps [rsp], xmm0
000076c1d9ddea8c  vmovaps [rsp+0x10], xmm1
000076c1d9ddea92  vmovaps [rsp+0x20], xmm2
000076c1d9ddea98  vmovaps [rsp+0x30], xmm3
000076c1d9ddea9e  vmovaps [rsp+0x40], xmm4
000076c1d9ddeaa4  vmovaps [rsp+0x50], xmm5
000076c1d9ddeaaa  vmovaps [rsp+0x60], xmm6
000076c1d9ddeab0  vmovaps [rsp+0x70], xmm7
000076c1d9ddeab6  vmovaps [rsp+0x80], xmm8
000076c1d9ddeabf  vmovaps [rsp+0x90], xmm9
000076c1d9ddeac8  vmovaps [rsp+0xA0], xmm10
000076c1d9ddead1  vmovaps [rsp+0xB0], xmm11
000076c1d9ddeada  vmovaps [rsp+0xC0], xmm12
000076c1d9ddeae3  vmovaps [rsp+0xD0], xmm13
000076c1d9ddeaec  vmovaps [rsp+0xE0], xmm14
000076c1d9ddeaf5  sub rsp, 0x30
000076c1d9ddeaf9  movaps [rsp], xmm15
000076c1d9ddeafe  movaps [rsp+0x10], xmm14
000076c1d9ddeb04  movaps [rsp+0x20], xmm4
000076c1d9ddeb09  lea rdi, [rsp]
000076c1d9ddeb0d  mov esi, 0x00
000076c1d9ddeb12  mov rax, 0x5EA58B9E0530
000076c1d9ddeb1c  call rax
000076c1d9ddeb1e  movaps xmm15, [rsp]
000076c1d9ddeb23  add rsp, 0x30
000076c1d9ddeb27  vmovaps xmm0, [rsp]
000076c1d9ddeb2c  vmovaps xmm1, [rsp+0x10]
000076c1d9ddeb32  vmovaps xmm2, [rsp+0x20]
000076c1d9ddeb38  vmovaps xmm3, [rsp+0x30]
000076c1d9ddeb3e  vmovaps xmm4, [rsp+0x40]
000076c1d9ddeb44  vmovaps xmm5, [rsp+0x50]
000076c1d9ddeb4a  vmovaps xmm6, [rsp+0x60]
000076c1d9ddeb50  vmovaps xmm7, [rsp+0x70]
000076c1d9ddeb56  vmovaps xmm8, [rsp+0x80]
000076c1d9ddeb5f  vmovaps xmm9, [rsp+0x90]
000076c1d9ddeb68  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddeb71  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddeb7a  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddeb83  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddeb8c  vmovaps xmm14, [rsp+0xE0]
000076c1d9ddeb95  add rsp, 0xF0
000076c1d9ddeb9c  pop r11
000076c1d9ddeb9e  pop r10
000076c1d9ddeba0  pop r9
000076c1d9ddeba2  pop r8
000076c1d9ddeba4  pop rsi
000076c1d9ddeba5  pop rdi
000076c1d9ddeba6  pop rdx
000076c1d9ddeba7  pop rcx
000076c1d9ddeba8  pop rax
000076c1d9ddeba9  add rsp, 0x08
000076c1d9ddebad  jmp 0x000076C1D9DDC2AA
000076c1d9ddebb2  sub rsp, 0x08
000076c1d9ddebb6  push rax
000076c1d9ddebb7  push rcx
000076c1d9ddebb8  push rdx
000076c1d9ddebb9  push rdi
000076c1d9ddebba  push rsi
000076c1d9ddebbb  push r8
000076c1d9ddebbd  push r9
000076c1d9ddebbf  push r10
000076c1d9ddebc1  push r11
000076c1d9ddebc3  sub rsp, 0xF0
000076c1d9ddebca  vmovaps [rsp], xmm0
000076c1d9ddebcf  vmovaps [rsp+0x10], xmm1
000076c1d9ddebd5  vmovaps [rsp+0x20], xmm2
000076c1d9ddebdb  vmovaps [rsp+0x30], xmm3
000076c1d9ddebe1  vmovaps [rsp+0x40], xmm4
000076c1d9ddebe7  vmovaps [rsp+0x50], xmm5
000076c1d9ddebed  vmovaps [rsp+0x60], xmm6
000076c1d9ddebf3  vmovaps [rsp+0x70], xmm7
000076c1d9ddebf9  vmovaps [rsp+0x80], xmm8
000076c1d9ddec02  vmovaps [rsp+0x90], xmm9
000076c1d9ddec0b  vmovaps [rsp+0xA0], xmm10
000076c1d9ddec14  vmovaps [rsp+0xB0], xmm11
000076c1d9ddec1d  vmovaps [rsp+0xC0], xmm12
000076c1d9ddec26  vmovaps [rsp+0xD0], xmm13
000076c1d9ddec2f  vmovaps [rsp+0xE0], xmm15
000076c1d9ddec38  sub rsp, 0x30
000076c1d9ddec3c  movaps [rsp], xmm14
000076c1d9ddec41  movaps [rsp+0x10], xmm2
000076c1d9ddec46  movaps [rsp+0x20], xmm1
000076c1d9ddec4b  lea rdi, [rsp]
000076c1d9ddec4f  mov esi, 0x00
000076c1d9ddec54  mov rax, 0x5EA58B9E0530
000076c1d9ddec5e  call rax
000076c1d9ddec60  movaps xmm14, [rsp]
000076c1d9ddec65  add rsp, 0x30
000076c1d9ddec69  vmovaps xmm0, [rsp]
000076c1d9ddec6e  vmovaps xmm1, [rsp+0x10]
000076c1d9ddec74  vmovaps xmm2, [rsp+0x20]
000076c1d9ddec7a  vmovaps xmm3, [rsp+0x30]
000076c1d9ddec80  vmovaps xmm4, [rsp+0x40]
000076c1d9ddec86  vmovaps xmm5, [rsp+0x50]
000076c1d9ddec8c  vmovaps xmm6, [rsp+0x60]
000076c1d9ddec92  vmovaps xmm7, [rsp+0x70]
000076c1d9ddec98  vmovaps xmm8, [rsp+0x80]
000076c1d9ddeca1  vmovaps xmm9, [rsp+0x90]
000076c1d9ddecaa  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddecb3  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddecbc  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddecc5  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddecce  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddecd7  add rsp, 0xF0
000076c1d9ddecde  pop r11
000076c1d9ddece0  pop r10
000076c1d9ddece2  pop r9
000076c1d9ddece4  pop r8
000076c1d9ddece6  pop rsi
000076c1d9ddece7  pop rdi
000076c1d9ddece8  pop rdx
000076c1d9ddece9  pop rcx
000076c1d9ddecea  pop rax
000076c1d9ddeceb  add rsp, 0x08
000076c1d9ddecef  jmp 0x000076C1D9DDC2D0
000076c1d9ddecf4  sub rsp, 0x08
000076c1d9ddecf8  push rax
000076c1d9ddecf9  push rcx
000076c1d9ddecfa  push rdx
000076c1d9ddecfb  push rdi
000076c1d9ddecfc  push rsi
000076c1d9ddecfd  push r8
000076c1d9ddecff  push r9
000076c1d9dded01  push r10
000076c1d9dded03  push r11
000076c1d9dded05  sub rsp, 0xF0
000076c1d9dded0c  vmovaps [rsp], xmm0
000076c1d9dded11  vmovaps [rsp+0x10], xmm2
000076c1d9dded17  vmovaps [rsp+0x20], xmm3
000076c1d9dded1d  vmovaps [rsp+0x30], xmm4
000076c1d9dded23  vmovaps [rsp+0x40], xmm5
000076c1d9dded29  vmovaps [rsp+0x50], xmm6
000076c1d9dded2f  vmovaps [rsp+0x60], xmm7
000076c1d9dded35  vmovaps [rsp+0x70], xmm8
000076c1d9dded3b  vmovaps [rsp+0x80], xmm9
000076c1d9dded44  vmovaps [rsp+0x90], xmm10
000076c1d9dded4d  vmovaps [rsp+0xA0], xmm11
000076c1d9dded56  vmovaps [rsp+0xB0], xmm12
000076c1d9dded5f  vmovaps [rsp+0xC0], xmm13
000076c1d9dded68  vmovaps [rsp+0xD0], xmm14
000076c1d9dded71  vmovaps [rsp+0xE0], xmm15
000076c1d9dded7a  sub rsp, 0x30
000076c1d9dded7e  movaps [rsp], xmm1
000076c1d9dded82  movaps [rsp+0x10], xmm4
000076c1d9dded87  movaps [rsp+0x20], xmm9
000076c1d9dded8d  lea rdi, [rsp]
000076c1d9dded91  mov esi, 0x00
000076c1d9dded96  mov rax, 0x5EA58B9E0530
000076c1d9ddeda0  call rax
000076c1d9ddeda2  movaps xmm1, [rsp]
000076c1d9ddeda6  add rsp, 0x30
000076c1d9ddedaa  vmovaps xmm0, [rsp]
000076c1d9ddedaf  vmovaps xmm2, [rsp+0x10]
000076c1d9ddedb5  vmovaps xmm3, [rsp+0x20]
000076c1d9ddedbb  vmovaps xmm4, [rsp+0x30]
000076c1d9ddedc1  vmovaps xmm5, [rsp+0x40]
000076c1d9ddedc7  vmovaps xmm6, [rsp+0x50]
000076c1d9ddedcd  vmovaps xmm7, [rsp+0x60]
000076c1d9ddedd3  vmovaps xmm8, [rsp+0x70]
000076c1d9ddedd9  vmovaps xmm9, [rsp+0x80]
000076c1d9ddede2  vmovaps xmm10, [rsp+0x90]
000076c1d9ddedeb  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddedf4  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddedfd  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddee06  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddee0f  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddee18  add rsp, 0xF0
000076c1d9ddee1f  pop r11
000076c1d9ddee21  pop r10
000076c1d9ddee23  pop r9
000076c1d9ddee25  pop r8
000076c1d9ddee27  pop rsi
000076c1d9ddee28  pop rdi
000076c1d9ddee29  pop rdx
000076c1d9ddee2a  pop rcx
000076c1d9ddee2b  pop rax
000076c1d9ddee2c  add rsp, 0x08
000076c1d9ddee30  jmp 0x000076C1D9DDC2EE
000076c1d9ddee35  sub rsp, 0x08
000076c1d9ddee39  push rax
000076c1d9ddee3a  push rcx
000076c1d9ddee3b  push rdx
000076c1d9ddee3c  push rdi
000076c1d9ddee3d  push rsi
000076c1d9ddee3e  push r8
000076c1d9ddee40  push r9
000076c1d9ddee42  push r10
000076c1d9ddee44  push r11
000076c1d9ddee46  sub rsp, 0xF0
000076c1d9ddee4d  vmovaps [rsp], xmm0
000076c1d9ddee52  vmovaps [rsp+0x10], xmm1
000076c1d9ddee58  vmovaps [rsp+0x20], xmm2
000076c1d9ddee5e  vmovaps [rsp+0x30], xmm3
000076c1d9ddee64  vmovaps [rsp+0x40], xmm5
000076c1d9ddee6a  vmovaps [rsp+0x50], xmm6
000076c1d9ddee70  vmovaps [rsp+0x60], xmm7
000076c1d9ddee76  vmovaps [rsp+0x70], xmm8
000076c1d9ddee7c  vmovaps [rsp+0x80], xmm9
000076c1d9ddee85  vmovaps [rsp+0x90], xmm10
000076c1d9ddee8e  vmovaps [rsp+0xA0], xmm11
000076c1d9ddee97  vmovaps [rsp+0xB0], xmm12
000076c1d9ddeea0  vmovaps [rsp+0xC0], xmm13
000076c1d9ddeea9  vmovaps [rsp+0xD0], xmm14
000076c1d9ddeeb2  vmovaps [rsp+0xE0], xmm15
000076c1d9ddeebb  sub rsp, 0x30
000076c1d9ddeebf  movaps [rsp], xmm4
000076c1d9ddeec3  movaps [rsp+0x10], xmm2
000076c1d9ddeec8  movaps [rsp+0x20], xmm9
000076c1d9ddeece  lea rdi, [rsp]
000076c1d9ddeed2  mov esi, 0x00
000076c1d9ddeed7  mov rax, 0x5EA58B9E0530
000076c1d9ddeee1  call rax
000076c1d9ddeee3  movaps xmm4, [rsp]
000076c1d9ddeee7  add rsp, 0x30
000076c1d9ddeeeb  vmovaps xmm0, [rsp]
000076c1d9ddeef0  vmovaps xmm1, [rsp+0x10]
000076c1d9ddeef6  vmovaps xmm2, [rsp+0x20]
000076c1d9ddeefc  vmovaps xmm3, [rsp+0x30]
000076c1d9ddef02  vmovaps xmm5, [rsp+0x40]
000076c1d9ddef08  vmovaps xmm6, [rsp+0x50]
000076c1d9ddef0e  vmovaps xmm7, [rsp+0x60]
000076c1d9ddef14  vmovaps xmm8, [rsp+0x70]
000076c1d9ddef1a  vmovaps xmm9, [rsp+0x80]
000076c1d9ddef23  vmovaps xmm10, [rsp+0x90]
000076c1d9ddef2c  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddef35  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddef3e  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddef47  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddef50  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddef59  add rsp, 0xF0
000076c1d9ddef60  pop r11
000076c1d9ddef62  pop r10
000076c1d9ddef64  pop r9
000076c1d9ddef66  pop r8
000076c1d9ddef68  pop rsi
000076c1d9ddef69  pop rdi
000076c1d9ddef6a  pop rdx
000076c1d9ddef6b  pop rcx
000076c1d9ddef6c  pop rax
000076c1d9ddef6d  add rsp, 0x08
000076c1d9ddef71  jmp 0x000076C1D9DDC31E
000076c1d9ddef76  sub rsp, 0x08
000076c1d9ddef7a  push rax
000076c1d9ddef7b  push rcx
000076c1d9ddef7c  push rdx
000076c1d9ddef7d  push rdi
000076c1d9ddef7e  push rsi
000076c1d9ddef7f  push r8
000076c1d9ddef81  push r9
000076c1d9ddef83  push r10
000076c1d9ddef85  push r11
000076c1d9ddef87  sub rsp, 0xF0
000076c1d9ddef8e  vmovaps [rsp], xmm0
000076c1d9ddef93  vmovaps [rsp+0x10], xmm1
000076c1d9ddef99  vmovaps [rsp+0x20], xmm2
000076c1d9ddef9f  vmovaps [rsp+0x30], xmm3
000076c1d9ddefa5  vmovaps [rsp+0x40], xmm4
000076c1d9ddefab  vmovaps [rsp+0x50], xmm5
000076c1d9ddefb1  vmovaps [rsp+0x60], xmm6
000076c1d9ddefb7  vmovaps [rsp+0x70], xmm7
000076c1d9ddefbd  vmovaps [rsp+0x80], xmm8
000076c1d9ddefc6  vmovaps [rsp+0x90], xmm10
000076c1d9ddefcf  vmovaps [rsp+0xA0], xmm11
000076c1d9ddefd8  vmovaps [rsp+0xB0], xmm12
000076c1d9ddefe1  vmovaps [rsp+0xC0], xmm13
000076c1d9ddefea  vmovaps [rsp+0xD0], xmm14
000076c1d9ddeff3  vmovaps [rsp+0xE0], xmm15
000076c1d9ddeffc  sub rsp, 0x30
000076c1d9ddf000  movaps [rsp], xmm9
000076c1d9ddf005  movaps [rsp+0x10], xmm2
000076c1d9ddf00a  movaps [rsp+0x20], xmm1
000076c1d9ddf00f  lea rdi, [rsp]
000076c1d9ddf013  mov esi, 0x00
000076c1d9ddf018  mov rax, 0x5EA58B9E0530
000076c1d9ddf022  call rax
000076c1d9ddf024  movaps xmm9, [rsp]
000076c1d9ddf029  add rsp, 0x30
000076c1d9ddf02d  vmovaps xmm0, [rsp]
000076c1d9ddf032  vmovaps xmm1, [rsp+0x10]
000076c1d9ddf038  vmovaps xmm2, [rsp+0x20]
000076c1d9ddf03e  vmovaps xmm3, [rsp+0x30]
000076c1d9ddf044  vmovaps xmm4, [rsp+0x40]
000076c1d9ddf04a  vmovaps xmm5, [rsp+0x50]
000076c1d9ddf050  vmovaps xmm6, [rsp+0x60]
000076c1d9ddf056  vmovaps xmm7, [rsp+0x70]
000076c1d9ddf05c  vmovaps xmm8, [rsp+0x80]
000076c1d9ddf065  vmovaps xmm10, [rsp+0x90]
000076c1d9ddf06e  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddf077  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddf080  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddf089  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddf092  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddf09b  add rsp, 0xF0
000076c1d9ddf0a2  pop r11
000076c1d9ddf0a4  pop r10
000076c1d9ddf0a6  pop r9
000076c1d9ddf0a8  pop r8
000076c1d9ddf0aa  pop rsi
000076c1d9ddf0ab  pop rdi
000076c1d9ddf0ac  pop rdx
000076c1d9ddf0ad  pop rcx
000076c1d9ddf0ae  pop rax
000076c1d9ddf0af  add rsp, 0x08
000076c1d9ddf0b3  jmp 0x000076C1D9DDC354
000076c1d9ddf0b8  sub rsp, 0x08
000076c1d9ddf0bc  push rax
000076c1d9ddf0bd  push rcx
000076c1d9ddf0be  push rdx
000076c1d9ddf0bf  push rdi
000076c1d9ddf0c0  push rsi
000076c1d9ddf0c1  push r8
000076c1d9ddf0c3  push r9
000076c1d9ddf0c5  push r10
000076c1d9ddf0c7  push r11
000076c1d9ddf0c9  sub rsp, 0xF0
000076c1d9ddf0d0  vmovaps [rsp], xmm0
000076c1d9ddf0d5  vmovaps [rsp+0x10], xmm2
000076c1d9ddf0db  vmovaps [rsp+0x20], xmm3
000076c1d9ddf0e1  vmovaps [rsp+0x30], xmm4
000076c1d9ddf0e7  vmovaps [rsp+0x40], xmm5
000076c1d9ddf0ed  vmovaps [rsp+0x50], xmm6
000076c1d9ddf0f3  vmovaps [rsp+0x60], xmm7
000076c1d9ddf0f9  vmovaps [rsp+0x70], xmm8
000076c1d9ddf0ff  vmovaps [rsp+0x80], xmm9
000076c1d9ddf108  vmovaps [rsp+0x90], xmm10
000076c1d9ddf111  vmovaps [rsp+0xA0], xmm11
000076c1d9ddf11a  vmovaps [rsp+0xB0], xmm12
000076c1d9ddf123  vmovaps [rsp+0xC0], xmm13
000076c1d9ddf12c  vmovaps [rsp+0xD0], xmm14
000076c1d9ddf135  vmovaps [rsp+0xE0], xmm15
000076c1d9ddf13e  sub rsp, 0x30
000076c1d9ddf142  movaps [rsp], xmm1
000076c1d9ddf146  movaps [rsp+0x10], xmm15
000076c1d9ddf14c  movaps [rsp+0x20], xmm6
000076c1d9ddf151  lea rdi, [rsp]
000076c1d9ddf155  mov esi, 0x00
000076c1d9ddf15a  mov rax, 0x5EA58B9E0530
000076c1d9ddf164  call rax
000076c1d9ddf166  movaps xmm1, [rsp]
000076c1d9ddf16a  add rsp, 0x30
000076c1d9ddf16e  vmovaps xmm0, [rsp]
000076c1d9ddf173  vmovaps xmm2, [rsp+0x10]
000076c1d9ddf179  vmovaps xmm3, [rsp+0x20]
000076c1d9ddf17f  vmovaps xmm4, [rsp+0x30]
000076c1d9ddf185  vmovaps xmm5, [rsp+0x40]
000076c1d9ddf18b  vmovaps xmm6, [rsp+0x50]
000076c1d9ddf191  vmovaps xmm7, [rsp+0x60]
000076c1d9ddf197  vmovaps xmm8, [rsp+0x70]
000076c1d9ddf19d  vmovaps xmm9, [rsp+0x80]
000076c1d9ddf1a6  vmovaps xmm10, [rsp+0x90]
000076c1d9ddf1af  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddf1b8  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddf1c1  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddf1ca  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddf1d3  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddf1dc  add rsp, 0xF0
000076c1d9ddf1e3  pop r11
000076c1d9ddf1e5  pop r10
000076c1d9ddf1e7  pop r9
000076c1d9ddf1e9  pop r8
000076c1d9ddf1eb  pop rsi
000076c1d9ddf1ec  pop rdi
000076c1d9ddf1ed  pop rdx
000076c1d9ddf1ee  pop rcx
000076c1d9ddf1ef  pop rax
000076c1d9ddf1f0  add rsp, 0x08
000076c1d9ddf1f4  jmp 0x000076C1D9DDC375
000076c1d9ddf1f9  sub rsp, 0x08
000076c1d9ddf1fd  push rax
000076c1d9ddf1fe  push rcx
000076c1d9ddf1ff  push rdx
000076c1d9ddf200  push rdi
000076c1d9ddf201  push rsi
000076c1d9ddf202  push r8
000076c1d9ddf204  push r9
000076c1d9ddf206  push r10
000076c1d9ddf208  push r11
000076c1d9ddf20a  sub rsp, 0xF0
000076c1d9ddf211  vmovaps [rsp], xmm0
000076c1d9ddf216  vmovaps [rsp+0x10], xmm1
000076c1d9ddf21c  vmovaps [rsp+0x20], xmm2
000076c1d9ddf222  vmovaps [rsp+0x30], xmm3
000076c1d9ddf228  vmovaps [rsp+0x40], xmm4
000076c1d9ddf22e  vmovaps [rsp+0x50], xmm5
000076c1d9ddf234  vmovaps [rsp+0x60], xmm6
000076c1d9ddf23a  vmovaps [rsp+0x70], xmm7
000076c1d9ddf240  vmovaps [rsp+0x80], xmm8
000076c1d9ddf249  vmovaps [rsp+0x90], xmm9
000076c1d9ddf252  vmovaps [rsp+0xA0], xmm10
000076c1d9ddf25b  vmovaps [rsp+0xB0], xmm11
000076c1d9ddf264  vmovaps [rsp+0xC0], xmm12
000076c1d9ddf26d  vmovaps [rsp+0xD0], xmm13
000076c1d9ddf276  vmovaps [rsp+0xE0], xmm14
000076c1d9ddf27f  sub rsp, 0x30
000076c1d9ddf283  movaps [rsp], xmm15
000076c1d9ddf288  movaps [rsp+0x10], xmm5
000076c1d9ddf28d  movaps [rsp+0x20], xmm3
000076c1d9ddf292  lea rdi, [rsp]
000076c1d9ddf296  mov esi, 0x00
000076c1d9ddf29b  mov rax, 0x5EA58B9E0530
000076c1d9ddf2a5  call rax
000076c1d9ddf2a7  movaps xmm15, [rsp]
000076c1d9ddf2ac  add rsp, 0x30
000076c1d9ddf2b0  vmovaps xmm0, [rsp]
000076c1d9ddf2b5  vmovaps xmm1, [rsp+0x10]
000076c1d9ddf2bb  vmovaps xmm2, [rsp+0x20]
000076c1d9ddf2c1  vmovaps xmm3, [rsp+0x30]
000076c1d9ddf2c7  vmovaps xmm4, [rsp+0x40]
000076c1d9ddf2cd  vmovaps xmm5, [rsp+0x50]
000076c1d9ddf2d3  vmovaps xmm6, [rsp+0x60]
000076c1d9ddf2d9  vmovaps xmm7, [rsp+0x70]
000076c1d9ddf2df  vmovaps xmm8, [rsp+0x80]
000076c1d9ddf2e8  vmovaps xmm9, [rsp+0x90]
000076c1d9ddf2f1  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddf2fa  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddf303  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddf30c  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddf315  vmovaps xmm14, [rsp+0xE0]
000076c1d9ddf31e  add rsp, 0xF0
000076c1d9ddf325  pop r11
000076c1d9ddf327  pop r10
000076c1d9ddf329  pop r9
000076c1d9ddf32b  pop r8
000076c1d9ddf32d  pop rsi
000076c1d9ddf32e  pop rdi
000076c1d9ddf32f  pop rdx
000076c1d9ddf330  pop rcx
000076c1d9ddf331  pop rax
000076c1d9ddf332  add rsp, 0x08
000076c1d9ddf336  jmp 0x000076C1D9DDC38F
000076c1d9ddf33b  sub rsp, 0x08
000076c1d9ddf33f  push rax
000076c1d9ddf340  push rcx
000076c1d9ddf341  push rdx
000076c1d9ddf342  push rdi
000076c1d9ddf343  push rsi
000076c1d9ddf344  push r8
000076c1d9ddf346  push r9
000076c1d9ddf348  push r10
000076c1d9ddf34a  push r11
000076c1d9ddf34c  sub rsp, 0xF0
000076c1d9ddf353  vmovaps [rsp], xmm0
000076c1d9ddf358  vmovaps [rsp+0x10], xmm1
000076c1d9ddf35e  vmovaps [rsp+0x20], xmm2
000076c1d9ddf364  vmovaps [rsp+0x30], xmm3
000076c1d9ddf36a  vmovaps [rsp+0x40], xmm4
000076c1d9ddf370  vmovaps [rsp+0x50], xmm6
000076c1d9ddf376  vmovaps [rsp+0x60], xmm7
000076c1d9ddf37c  vmovaps [rsp+0x70], xmm8
000076c1d9ddf382  vmovaps [rsp+0x80], xmm9
000076c1d9ddf38b  vmovaps [rsp+0x90], xmm10
000076c1d9ddf394  vmovaps [rsp+0xA0], xmm11
000076c1d9ddf39d  vmovaps [rsp+0xB0], xmm12
000076c1d9ddf3a6  vmovaps [rsp+0xC0], xmm13
000076c1d9ddf3af  vmovaps [rsp+0xD0], xmm14
000076c1d9ddf3b8  vmovaps [rsp+0xE0], xmm15
000076c1d9ddf3c1  sub rsp, 0x30
000076c1d9ddf3c5  movaps [rsp], xmm5
000076c1d9ddf3c9  movaps [rsp+0x10], xmm8
000076c1d9ddf3cf  movaps [rsp+0x20], xmm6
000076c1d9ddf3d4  lea rdi, [rsp]
000076c1d9ddf3d8  mov esi, 0x00
000076c1d9ddf3dd  mov rax, 0x5EA58B9E0530
000076c1d9ddf3e7  call rax
000076c1d9ddf3e9  movaps xmm5, [rsp]
000076c1d9ddf3ed  add rsp, 0x30
000076c1d9ddf3f1  vmovaps xmm0, [rsp]
000076c1d9ddf3f6  vmovaps xmm1, [rsp+0x10]
000076c1d9ddf3fc  vmovaps xmm2, [rsp+0x20]
000076c1d9ddf402  vmovaps xmm3, [rsp+0x30]
000076c1d9ddf408  vmovaps xmm4, [rsp+0x40]
000076c1d9ddf40e  vmovaps xmm6, [rsp+0x50]
000076c1d9ddf414  vmovaps xmm7, [rsp+0x60]
000076c1d9ddf41a  vmovaps xmm8, [rsp+0x70]
000076c1d9ddf420  vmovaps xmm9, [rsp+0x80]
000076c1d9ddf429  vmovaps xmm10, [rsp+0x90]
000076c1d9ddf432  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddf43b  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddf444  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddf44d  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddf456  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddf45f  add rsp, 0xF0
000076c1d9ddf466  pop r11
000076c1d9ddf468  pop r10
000076c1d9ddf46a  pop r9
000076c1d9ddf46c  pop r8
000076c1d9ddf46e  pop rsi
000076c1d9ddf46f  pop rdi
000076c1d9ddf470  pop rdx
000076c1d9ddf471  pop rcx
000076c1d9ddf472  pop rax
000076c1d9ddf473  add rsp, 0x08
000076c1d9ddf477  jmp 0x000076C1D9DDC3B3
000076c1d9ddf47c  sub rsp, 0x08
000076c1d9ddf480  push rax
000076c1d9ddf481  push rcx
000076c1d9ddf482  push rdx
000076c1d9ddf483  push rdi
000076c1d9ddf484  push rsi
000076c1d9ddf485  push r8
000076c1d9ddf487  push r9
000076c1d9ddf489  push r10
000076c1d9ddf48b  push r11
000076c1d9ddf48d  sub rsp, 0xF0
000076c1d9ddf494  vmovaps [rsp], xmm0
000076c1d9ddf499  vmovaps [rsp+0x10], xmm1
000076c1d9ddf49f  vmovaps [rsp+0x20], xmm2
000076c1d9ddf4a5  vmovaps [rsp+0x30], xmm3
000076c1d9ddf4ab  vmovaps [rsp+0x40], xmm4
000076c1d9ddf4b1  vmovaps [rsp+0x50], xmm5
000076c1d9ddf4b7  vmovaps [rsp+0x60], xmm7
000076c1d9ddf4bd  vmovaps [rsp+0x70], xmm8
000076c1d9ddf4c3  vmovaps [rsp+0x80], xmm9
000076c1d9ddf4cc  vmovaps [rsp+0x90], xmm10
000076c1d9ddf4d5  vmovaps [rsp+0xA0], xmm11
000076c1d9ddf4de  vmovaps [rsp+0xB0], xmm12
000076c1d9ddf4e7  vmovaps [rsp+0xC0], xmm13
000076c1d9ddf4f0  vmovaps [rsp+0xD0], xmm14
000076c1d9ddf4f9  vmovaps [rsp+0xE0], xmm15
000076c1d9ddf502  sub rsp, 0x30
000076c1d9ddf506  movaps [rsp], xmm6
000076c1d9ddf50a  movaps [rsp+0x10], xmm10
000076c1d9ddf510  movaps [rsp+0x20], xmm8
000076c1d9ddf516  lea rdi, [rsp]
000076c1d9ddf51a  mov esi, 0x00
000076c1d9ddf51f  mov rax, 0x5EA58B9E0530
000076c1d9ddf529  call rax
000076c1d9ddf52b  movaps xmm6, [rsp]
000076c1d9ddf52f  add rsp, 0x30
000076c1d9ddf533  vmovaps xmm0, [rsp]
000076c1d9ddf538  vmovaps xmm1, [rsp+0x10]
000076c1d9ddf53e  vmovaps xmm2, [rsp+0x20]
000076c1d9ddf544  vmovaps xmm3, [rsp+0x30]
000076c1d9ddf54a  vmovaps xmm4, [rsp+0x40]
000076c1d9ddf550  vmovaps xmm5, [rsp+0x50]
000076c1d9ddf556  vmovaps xmm7, [rsp+0x60]
000076c1d9ddf55c  vmovaps xmm8, [rsp+0x70]
000076c1d9ddf562  vmovaps xmm9, [rsp+0x80]
000076c1d9ddf56b  vmovaps xmm10, [rsp+0x90]
000076c1d9ddf574  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddf57d  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddf586  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddf58f  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddf598  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddf5a1  add rsp, 0xF0
000076c1d9ddf5a8  pop r11
000076c1d9ddf5aa  pop r10
000076c1d9ddf5ac  pop r9
000076c1d9ddf5ae  pop r8
000076c1d9ddf5b0  pop rsi
000076c1d9ddf5b1  pop rdi
000076c1d9ddf5b2  pop rdx
000076c1d9ddf5b3  pop rcx
000076c1d9ddf5b4  pop rax
000076c1d9ddf5b5  add rsp, 0x08
000076c1d9ddf5b9  jmp 0x000076C1D9DDC3D8
000076c1d9ddf5be  sub rsp, 0x08
000076c1d9ddf5c2  push rax
000076c1d9ddf5c3  push rcx
000076c1d9ddf5c4  push rdx
000076c1d9ddf5c5  push rdi
000076c1d9ddf5c6  push rsi
000076c1d9ddf5c7  push r8
000076c1d9ddf5c9  push r9
000076c1d9ddf5cb  push r10
000076c1d9ddf5cd  push r11
000076c1d9ddf5cf  sub rsp, 0xF0
000076c1d9ddf5d6  vmovaps [rsp], xmm0
000076c1d9ddf5db  vmovaps [rsp+0x10], xmm1
000076c1d9ddf5e1  vmovaps [rsp+0x20], xmm2
000076c1d9ddf5e7  vmovaps [rsp+0x30], xmm3
000076c1d9ddf5ed  vmovaps [rsp+0x40], xmm4
000076c1d9ddf5f3  vmovaps [rsp+0x50], xmm5
000076c1d9ddf5f9  vmovaps [rsp+0x60], xmm6
000076c1d9ddf5ff  vmovaps [rsp+0x70], xmm7
000076c1d9ddf605  vmovaps [rsp+0x80], xmm8
000076c1d9ddf60e  vmovaps [rsp+0x90], xmm9
000076c1d9ddf617  vmovaps [rsp+0xA0], xmm11
000076c1d9ddf620  vmovaps [rsp+0xB0], xmm12
000076c1d9ddf629  vmovaps [rsp+0xC0], xmm13
000076c1d9ddf632  vmovaps [rsp+0xD0], xmm14
000076c1d9ddf63b  vmovaps [rsp+0xE0], xmm15
000076c1d9ddf644  sub rsp, 0x30
000076c1d9ddf648  movaps [rsp], xmm10
000076c1d9ddf64d  movaps [rsp+0x10], xmm8
000076c1d9ddf653  movaps [rsp+0x20], xmm14
000076c1d9ddf659  lea rdi, [rsp]
000076c1d9ddf65d  mov esi, 0x00
000076c1d9ddf662  mov rax, 0x5EA58B9E0530
000076c1d9ddf66c  call rax
000076c1d9ddf66e  movaps xmm10, [rsp]
000076c1d9ddf673  add rsp, 0x30
000076c1d9ddf677  vmovaps xmm0, [rsp]
000076c1d9ddf67c  vmovaps xmm1, [rsp+0x10]
000076c1d9ddf682  vmovaps xmm2, [rsp+0x20]
000076c1d9ddf688  vmovaps xmm3, [rsp+0x30]
000076c1d9ddf68e  vmovaps xmm4, [rsp+0x40]
000076c1d9ddf694  vmovaps xmm5, [rsp+0x50]
000076c1d9ddf69a  vmovaps xmm6, [rsp+0x60]
000076c1d9ddf6a0  vmovaps xmm7, [rsp+0x70]
000076c1d9ddf6a6  vmovaps xmm8, [rsp+0x80]
000076c1d9ddf6af  vmovaps xmm9, [rsp+0x90]
000076c1d9ddf6b8  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddf6c1  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddf6ca  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddf6d3  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddf6dc  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddf6e5  add rsp, 0xF0
000076c1d9ddf6ec  pop r11
000076c1d9ddf6ee  pop r10
000076c1d9ddf6f0  pop r9
000076c1d9ddf6f2  pop r8
000076c1d9ddf6f4  pop rsi
000076c1d9ddf6f5  pop rdi
000076c1d9ddf6f6  pop rdx
000076c1d9ddf6f7  pop rcx
000076c1d9ddf6f8  pop rax
000076c1d9ddf6f9  add rsp, 0x08
000076c1d9ddf6fd  jmp 0x000076C1D9DDC3F8
000076c1d9ddf702  sub rsp, 0x08
000076c1d9ddf706  push rax
000076c1d9ddf707  push rcx
000076c1d9ddf708  push rdx
000076c1d9ddf709  push rdi
000076c1d9ddf70a  push rsi
000076c1d9ddf70b  push r8
000076c1d9ddf70d  push r9
000076c1d9ddf70f  push r10
000076c1d9ddf711  push r11
000076c1d9ddf713  sub rsp, 0xF0
000076c1d9ddf71a  vmovaps [rsp], xmm0
000076c1d9ddf71f  vmovaps [rsp+0x10], xmm1
000076c1d9ddf725  vmovaps [rsp+0x20], xmm2
000076c1d9ddf72b  vmovaps [rsp+0x30], xmm3
000076c1d9ddf731  vmovaps [rsp+0x40], xmm4
000076c1d9ddf737  vmovaps [rsp+0x50], xmm5
000076c1d9ddf73d  vmovaps [rsp+0x60], xmm6
000076c1d9ddf743  vmovaps [rsp+0x70], xmm7
000076c1d9ddf749  vmovaps [rsp+0x80], xmm8
000076c1d9ddf752  vmovaps [rsp+0x90], xmm9
000076c1d9ddf75b  vmovaps [rsp+0xA0], xmm10
000076c1d9ddf764  vmovaps [rsp+0xB0], xmm11
000076c1d9ddf76d  vmovaps [rsp+0xC0], xmm12
000076c1d9ddf776  vmovaps [rsp+0xD0], xmm13
000076c1d9ddf77f  vmovaps [rsp+0xE0], xmm15
000076c1d9ddf788  sub rsp, 0x30
000076c1d9ddf78c  movaps [rsp], xmm14
000076c1d9ddf791  movaps [rsp+0x10], xmm8
000076c1d9ddf797  movaps [rsp+0x20], xmm4
000076c1d9ddf79c  lea rdi, [rsp]
000076c1d9ddf7a0  mov esi, 0x00
000076c1d9ddf7a5  mov rax, 0x5EA58B9E0530
000076c1d9ddf7af  call rax
000076c1d9ddf7b1  movaps xmm14, [rsp]
000076c1d9ddf7b6  add rsp, 0x30
000076c1d9ddf7ba  vmovaps xmm0, [rsp]
000076c1d9ddf7bf  vmovaps xmm1, [rsp+0x10]
000076c1d9ddf7c5  vmovaps xmm2, [rsp+0x20]
000076c1d9ddf7cb  vmovaps xmm3, [rsp+0x30]
000076c1d9ddf7d1  vmovaps xmm4, [rsp+0x40]
000076c1d9ddf7d7  vmovaps xmm5, [rsp+0x50]
000076c1d9ddf7dd  vmovaps xmm6, [rsp+0x60]
000076c1d9ddf7e3  vmovaps xmm7, [rsp+0x70]
000076c1d9ddf7e9  vmovaps xmm8, [rsp+0x80]
000076c1d9ddf7f2  vmovaps xmm9, [rsp+0x90]
000076c1d9ddf7fb  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddf804  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddf80d  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddf816  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddf81f  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddf828  add rsp, 0xF0
000076c1d9ddf82f  pop r11
000076c1d9ddf831  pop r10
000076c1d9ddf833  pop r9
000076c1d9ddf835  pop r8
000076c1d9ddf837  pop rsi
000076c1d9ddf838  pop rdi
000076c1d9ddf839  pop rdx
000076c1d9ddf83a  pop rcx
000076c1d9ddf83b  pop rax
000076c1d9ddf83c  add rsp, 0x08
000076c1d9ddf840  jmp 0x000076C1D9DDC418
000076c1d9ddf845  sub rsp, 0x08
000076c1d9ddf849  push rax
000076c1d9ddf84a  push rcx
000076c1d9ddf84b  push rdx
000076c1d9ddf84c  push rdi
000076c1d9ddf84d  push rsi
000076c1d9ddf84e  push r8
000076c1d9ddf850  push r9
000076c1d9ddf852  push r10
000076c1d9ddf854  push r11
000076c1d9ddf856  sub rsp, 0xF0
000076c1d9ddf85d  vmovaps [rsp], xmm0
000076c1d9ddf862  vmovaps [rsp+0x10], xmm1
000076c1d9ddf868  vmovaps [rsp+0x20], xmm2
000076c1d9ddf86e  vmovaps [rsp+0x30], xmm3
000076c1d9ddf874  vmovaps [rsp+0x40], xmm5
000076c1d9ddf87a  vmovaps [rsp+0x50], xmm6
000076c1d9ddf880  vmovaps [rsp+0x60], xmm7
000076c1d9ddf886  vmovaps [rsp+0x70], xmm8
000076c1d9ddf88c  vmovaps [rsp+0x80], xmm9
000076c1d9ddf895  vmovaps [rsp+0x90], xmm10
000076c1d9ddf89e  vmovaps [rsp+0xA0], xmm11
000076c1d9ddf8a7  vmovaps [rsp+0xB0], xmm12
000076c1d9ddf8b0  vmovaps [rsp+0xC0], xmm13
000076c1d9ddf8b9  vmovaps [rsp+0xD0], xmm14
000076c1d9ddf8c2  vmovaps [rsp+0xE0], xmm15
000076c1d9ddf8cb  sub rsp, 0x30
000076c1d9ddf8cf  movaps [rsp], xmm4
000076c1d9ddf8d3  movaps [rsp+0x10], xmm13
000076c1d9ddf8d9  movaps [rsp+0x20], xmm8
000076c1d9ddf8df  lea rdi, [rsp]
000076c1d9ddf8e3  mov esi, 0x00
000076c1d9ddf8e8  mov rax, 0x5EA58B9E0530
000076c1d9ddf8f2  call rax
000076c1d9ddf8f4  movaps xmm4, [rsp]
000076c1d9ddf8f8  add rsp, 0x30
000076c1d9ddf8fc  vmovaps xmm0, [rsp]
000076c1d9ddf901  vmovaps xmm1, [rsp+0x10]
000076c1d9ddf907  vmovaps xmm2, [rsp+0x20]
000076c1d9ddf90d  vmovaps xmm3, [rsp+0x30]
000076c1d9ddf913  vmovaps xmm5, [rsp+0x40]
000076c1d9ddf919  vmovaps xmm6, [rsp+0x50]
000076c1d9ddf91f  vmovaps xmm7, [rsp+0x60]
000076c1d9ddf925  vmovaps xmm8, [rsp+0x70]
000076c1d9ddf92b  vmovaps xmm9, [rsp+0x80]
000076c1d9ddf934  vmovaps xmm10, [rsp+0x90]
000076c1d9ddf93d  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddf946  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddf94f  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddf958  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddf961  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddf96a  add rsp, 0xF0
000076c1d9ddf971  pop r11
000076c1d9ddf973  pop r10
000076c1d9ddf975  pop r9
000076c1d9ddf977  pop r8
000076c1d9ddf979  pop rsi
000076c1d9ddf97a  pop rdi
000076c1d9ddf97b  pop rdx
000076c1d9ddf97c  pop rcx
000076c1d9ddf97d  pop rax
000076c1d9ddf97e  add rsp, 0x08
000076c1d9ddf982  jmp 0x000076C1D9DDC43D
000076c1d9ddf987  sub rsp, 0x08
000076c1d9ddf98b  push rax
000076c1d9ddf98c  push rcx
000076c1d9ddf98d  push rdx
000076c1d9ddf98e  push rdi
000076c1d9ddf98f  push rsi
000076c1d9ddf990  push r8
000076c1d9ddf992  push r9
000076c1d9ddf994  push r10
000076c1d9ddf996  push r11
000076c1d9ddf998  sub rsp, 0xF0
000076c1d9ddf99f  vmovaps [rsp], xmm0
000076c1d9ddf9a4  vmovaps [rsp+0x10], xmm1
000076c1d9ddf9aa  vmovaps [rsp+0x20], xmm2
000076c1d9ddf9b0  vmovaps [rsp+0x30], xmm3
000076c1d9ddf9b6  vmovaps [rsp+0x40], xmm4
000076c1d9ddf9bc  vmovaps [rsp+0x50], xmm5
000076c1d9ddf9c2  vmovaps [rsp+0x60], xmm6
000076c1d9ddf9c8  vmovaps [rsp+0x70], xmm7
000076c1d9ddf9ce  vmovaps [rsp+0x80], xmm8
000076c1d9ddf9d7  vmovaps [rsp+0x90], xmm9
000076c1d9ddf9e0  vmovaps [rsp+0xA0], xmm10
000076c1d9ddf9e9  vmovaps [rsp+0xB0], xmm11
000076c1d9ddf9f2  vmovaps [rsp+0xC0], xmm12
000076c1d9ddf9fb  vmovaps [rsp+0xD0], xmm14
000076c1d9ddfa04  vmovaps [rsp+0xE0], xmm15
000076c1d9ddfa0d  sub rsp, 0x30
000076c1d9ddfa11  movaps [rsp], xmm13
000076c1d9ddfa16  movaps [rsp+0x10], xmm15
000076c1d9ddfa1c  movaps [rsp+0x20], xmm9
000076c1d9ddfa22  lea rdi, [rsp]
000076c1d9ddfa26  mov esi, 0x00
000076c1d9ddfa2b  mov rax, 0x5EA58B9E0530
000076c1d9ddfa35  call rax
000076c1d9ddfa37  movaps xmm13, [rsp]
000076c1d9ddfa3c  add rsp, 0x30
000076c1d9ddfa40  vmovaps xmm0, [rsp]
000076c1d9ddfa45  vmovaps xmm1, [rsp+0x10]
000076c1d9ddfa4b  vmovaps xmm2, [rsp+0x20]
000076c1d9ddfa51  vmovaps xmm3, [rsp+0x30]
000076c1d9ddfa57  vmovaps xmm4, [rsp+0x40]
000076c1d9ddfa5d  vmovaps xmm5, [rsp+0x50]
000076c1d9ddfa63  vmovaps xmm6, [rsp+0x60]
000076c1d9ddfa69  vmovaps xmm7, [rsp+0x70]
000076c1d9ddfa6f  vmovaps xmm8, [rsp+0x80]
000076c1d9ddfa78  vmovaps xmm9, [rsp+0x90]
000076c1d9ddfa81  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddfa8a  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddfa93  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddfa9c  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddfaa5  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddfaae  add rsp, 0xF0
000076c1d9ddfab5  pop r11
000076c1d9ddfab7  pop r10
000076c1d9ddfab9  pop r9
000076c1d9ddfabb  pop r8
000076c1d9ddfabd  pop rsi
000076c1d9ddfabe  pop rdi
000076c1d9ddfabf  pop rdx
000076c1d9ddfac0  pop rcx
000076c1d9ddfac1  pop rax
000076c1d9ddfac2  add rsp, 0x08
000076c1d9ddfac6  jmp 0x000076C1D9DDC458
000076c1d9ddfacb  sub rsp, 0x08
000076c1d9ddfacf  push rax
000076c1d9ddfad0  push rcx
000076c1d9ddfad1  push rdx
000076c1d9ddfad2  push rdi
000076c1d9ddfad3  push rsi
000076c1d9ddfad4  push r8
000076c1d9ddfad6  push r9
000076c1d9ddfad8  push r10
000076c1d9ddfada  push r11
000076c1d9ddfadc  sub rsp, 0xF0
000076c1d9ddfae3  vmovaps [rsp], xmm0
000076c1d9ddfae8  vmovaps [rsp+0x10], xmm1
000076c1d9ddfaee  vmovaps [rsp+0x20], xmm2
000076c1d9ddfaf4  vmovaps [rsp+0x30], xmm3
000076c1d9ddfafa  vmovaps [rsp+0x40], xmm4
000076c1d9ddfb00  vmovaps [rsp+0x50], xmm5
000076c1d9ddfb06  vmovaps [rsp+0x60], xmm6
000076c1d9ddfb0c  vmovaps [rsp+0x70], xmm7
000076c1d9ddfb12  vmovaps [rsp+0x80], xmm8
000076c1d9ddfb1b  vmovaps [rsp+0x90], xmm9
000076c1d9ddfb24  vmovaps [rsp+0xA0], xmm10
000076c1d9ddfb2d  vmovaps [rsp+0xB0], xmm11
000076c1d9ddfb36  vmovaps [rsp+0xC0], xmm12
000076c1d9ddfb3f  vmovaps [rsp+0xD0], xmm13
000076c1d9ddfb48  vmovaps [rsp+0xE0], xmm14
000076c1d9ddfb51  sub rsp, 0x30
000076c1d9ddfb55  movaps [rsp], xmm15
000076c1d9ddfb5a  movaps [rsp+0x10], xmm1
000076c1d9ddfb5f  movaps [rsp+0x20], xmm5
000076c1d9ddfb64  lea rdi, [rsp]
000076c1d9ddfb68  mov esi, 0x00
000076c1d9ddfb6d  mov rax, 0x5EA58B9E0530
000076c1d9ddfb77  call rax
000076c1d9ddfb79  movaps xmm15, [rsp]
000076c1d9ddfb7e  add rsp, 0x30
000076c1d9ddfb82  vmovaps xmm0, [rsp]
000076c1d9ddfb87  vmovaps xmm1, [rsp+0x10]
000076c1d9ddfb8d  vmovaps xmm2, [rsp+0x20]
000076c1d9ddfb93  vmovaps xmm3, [rsp+0x30]
000076c1d9ddfb99  vmovaps xmm4, [rsp+0x40]
000076c1d9ddfb9f  vmovaps xmm5, [rsp+0x50]
000076c1d9ddfba5  vmovaps xmm6, [rsp+0x60]
000076c1d9ddfbab  vmovaps xmm7, [rsp+0x70]
000076c1d9ddfbb1  vmovaps xmm8, [rsp+0x80]
000076c1d9ddfbba  vmovaps xmm9, [rsp+0x90]
000076c1d9ddfbc3  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddfbcc  vmovaps xmm11, [rsp+0xB0]
000076c1d9ddfbd5  vmovaps xmm12, [rsp+0xC0]
000076c1d9ddfbde  vmovaps xmm13, [rsp+0xD0]
000076c1d9ddfbe7  vmovaps xmm14, [rsp+0xE0]
000076c1d9ddfbf0  add rsp, 0xF0
000076c1d9ddfbf7  pop r11
000076c1d9ddfbf9  pop r10
000076c1d9ddfbfb  pop r9
000076c1d9ddfbfd  pop r8
000076c1d9ddfbff  pop rsi
000076c1d9ddfc00  pop rdi
000076c1d9ddfc01  pop rdx
000076c1d9ddfc02  pop rcx
000076c1d9ddfc03  pop rax
000076c1d9ddfc04  add rsp, 0x08
000076c1d9ddfc08  jmp 0x000076C1D9DDC473
000076c1d9ddfc0d  call 0x000076C1D9CB52F0
000076c1d9ddfc12  jmp 0x000076C1D9DDC4CE
000076c1d9ddfc17  sub rsp, 0x08
000076c1d9ddfc1b  push rax
000076c1d9ddfc1c  push rcx
000076c1d9ddfc1d  push rdx
000076c1d9ddfc1e  push rdi
000076c1d9ddfc1f  push rsi
000076c1d9ddfc20  push r8
000076c1d9ddfc22  push r9
000076c1d9ddfc24  push r10
000076c1d9ddfc26  push r11
000076c1d9ddfc28  sub rsp, 0xF0
000076c1d9ddfc2f  vmovaps [rsp], xmm0
000076c1d9ddfc34  vmovaps [rsp+0x10], xmm1
000076c1d9ddfc3a  vmovaps [rsp+0x20], xmm2
000076c1d9ddfc40  vmovaps [rsp+0x30], xmm3
000076c1d9ddfc46  vmovaps [rsp+0x40], xmm4
000076c1d9ddfc4c  vmovaps [rsp+0x50], xmm5
000076c1d9ddfc52  vmovaps [rsp+0x60], xmm6
000076c1d9ddfc58  vmovaps [rsp+0x70], xmm7
000076c1d9ddfc5e  vmovaps [rsp+0x80], xmm8
000076c1d9ddfc67  vmovaps [rsp+0x90], xmm10
000076c1d9ddfc70  vmovaps [rsp+0xA0], xmm11
000076c1d9ddfc79  vmovaps [rsp+0xB0], xmm12
000076c1d9ddfc82  vmovaps [rsp+0xC0], xmm13
000076c1d9ddfc8b  vmovaps [rsp+0xD0], xmm14
000076c1d9ddfc94  vmovaps [rsp+0xE0], xmm15
000076c1d9ddfc9d  sub rsp, 0x30
000076c1d9ddfca1  movaps [rsp], xmm9
000076c1d9ddfca6  movaps [rsp+0x10], xmm8
000076c1d9ddfcac  movaps [rsp+0x20], xmm11
000076c1d9ddfcb2  lea rdi, [rsp]
000076c1d9ddfcb6  mov esi, 0x00
000076c1d9ddfcbb  mov rax, 0x5EA58B9E0530
000076c1d9ddfcc5  call rax
000076c1d9ddfcc7  movaps xmm9, [rsp]
000076c1d9ddfccc  add rsp, 0x30
000076c1d9ddfcd0  vmovaps xmm0, [rsp]
000076c1d9ddfcd5  vmovaps xmm1, [rsp+0x10]
000076c1d9ddfcdb  vmovaps xmm2, [rsp+0x20]
000076c1d9ddfce1  vmovaps xmm3, [rsp+0x30]
000076c1d9ddfce7  vmovaps xmm4, [rsp+0x40]
000076c1d9ddfced  vmovaps xmm5, [rsp+0x50]
000076c1d9ddfcf3  vmovaps xmm6, [rsp+0x60]
000076c1d9ddfcf9  vmovaps xmm7, [rsp+0x70]
000076c1d9ddfcff  vmovaps xmm8, [rsp+0x80]
000076c1d9ddfd08  vmovaps xmm10, [rsp+0x90]
000076c1d9ddfd11  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddfd1a  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddfd23  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddfd2c  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddfd35  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddfd3e  add rsp, 0xF0
000076c1d9ddfd45  pop r11
000076c1d9ddfd47  pop r10
000076c1d9ddfd49  pop r9
000076c1d9ddfd4b  pop r8
000076c1d9ddfd4d  pop rsi
000076c1d9ddfd4e  pop rdi
000076c1d9ddfd4f  pop rdx
000076c1d9ddfd50  pop rcx
000076c1d9ddfd51  pop rax
000076c1d9ddfd52  add rsp, 0x08
000076c1d9ddfd56  jmp 0x000076C1D9DDC505
000076c1d9ddfd5b  sub rsp, 0x08
000076c1d9ddfd5f  push rax
000076c1d9ddfd60  push rcx
000076c1d9ddfd61  push rdx
000076c1d9ddfd62  push rdi
000076c1d9ddfd63  push rsi
000076c1d9ddfd64  push r8
000076c1d9ddfd66  push r9
000076c1d9ddfd68  push r10
000076c1d9ddfd6a  push r11
000076c1d9ddfd6c  sub rsp, 0xF0
000076c1d9ddfd73  vmovaps [rsp], xmm0
000076c1d9ddfd78  vmovaps [rsp+0x10], xmm1
000076c1d9ddfd7e  vmovaps [rsp+0x20], xmm2
000076c1d9ddfd84  vmovaps [rsp+0x30], xmm3
000076c1d9ddfd8a  vmovaps [rsp+0x40], xmm4
000076c1d9ddfd90  vmovaps [rsp+0x50], xmm5
000076c1d9ddfd96  vmovaps [rsp+0x60], xmm6
000076c1d9ddfd9c  vmovaps [rsp+0x70], xmm7
000076c1d9ddfda2  vmovaps [rsp+0x80], xmm8
000076c1d9ddfdab  vmovaps [rsp+0x90], xmm9
000076c1d9ddfdb4  vmovaps [rsp+0xA0], xmm10
000076c1d9ddfdbd  vmovaps [rsp+0xB0], xmm12
000076c1d9ddfdc6  vmovaps [rsp+0xC0], xmm13
000076c1d9ddfdcf  vmovaps [rsp+0xD0], xmm14
000076c1d9ddfdd8  vmovaps [rsp+0xE0], xmm15
000076c1d9ddfde1  sub rsp, 0x30
000076c1d9ddfde5  movaps [rsp], xmm11
000076c1d9ddfdea  movaps [rsp+0x10], xmm10
000076c1d9ddfdf0  movaps [rsp+0x20], xmm6
000076c1d9ddfdf5  lea rdi, [rsp]
000076c1d9ddfdf9  mov esi, 0x00
000076c1d9ddfdfe  mov rax, 0x5EA58B9E0530
000076c1d9ddfe08  call rax
000076c1d9ddfe0a  movaps xmm11, [rsp]
000076c1d9ddfe0f  add rsp, 0x30
000076c1d9ddfe13  vmovaps xmm0, [rsp]
000076c1d9ddfe18  vmovaps xmm1, [rsp+0x10]
000076c1d9ddfe1e  vmovaps xmm2, [rsp+0x20]
000076c1d9ddfe24  vmovaps xmm3, [rsp+0x30]
000076c1d9ddfe2a  vmovaps xmm4, [rsp+0x40]
000076c1d9ddfe30  vmovaps xmm5, [rsp+0x50]
000076c1d9ddfe36  vmovaps xmm6, [rsp+0x60]
000076c1d9ddfe3c  vmovaps xmm7, [rsp+0x70]
000076c1d9ddfe42  vmovaps xmm8, [rsp+0x80]
000076c1d9ddfe4b  vmovaps xmm9, [rsp+0x90]
000076c1d9ddfe54  vmovaps xmm10, [rsp+0xA0]
000076c1d9ddfe5d  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddfe66  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddfe6f  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddfe78  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddfe81  add rsp, 0xF0
000076c1d9ddfe88  pop r11
000076c1d9ddfe8a  pop r10
000076c1d9ddfe8c  pop r9
000076c1d9ddfe8e  pop r8
000076c1d9ddfe90  pop rsi
000076c1d9ddfe91  pop rdi
000076c1d9ddfe92  pop rdx
000076c1d9ddfe93  pop rcx
000076c1d9ddfe94  pop rax
000076c1d9ddfe95  add rsp, 0x08
000076c1d9ddfe99  jmp 0x000076C1D9DDC520
000076c1d9ddfe9e  sub rsp, 0x08
000076c1d9ddfea2  push rax
000076c1d9ddfea3  push rcx
000076c1d9ddfea4  push rdx
000076c1d9ddfea5  push rdi
000076c1d9ddfea6  push rsi
000076c1d9ddfea7  push r8
000076c1d9ddfea9  push r9
000076c1d9ddfeab  push r10
000076c1d9ddfead  push r11
000076c1d9ddfeaf  sub rsp, 0xF0
000076c1d9ddfeb6  vmovaps [rsp], xmm0
000076c1d9ddfebb  vmovaps [rsp+0x10], xmm1
000076c1d9ddfec1  vmovaps [rsp+0x20], xmm2
000076c1d9ddfec7  vmovaps [rsp+0x30], xmm3
000076c1d9ddfecd  vmovaps [rsp+0x40], xmm4
000076c1d9ddfed3  vmovaps [rsp+0x50], xmm5
000076c1d9ddfed9  vmovaps [rsp+0x60], xmm6
000076c1d9ddfedf  vmovaps [rsp+0x70], xmm7
000076c1d9ddfee5  vmovaps [rsp+0x80], xmm8
000076c1d9ddfeee  vmovaps [rsp+0x90], xmm9
000076c1d9ddfef7  vmovaps [rsp+0xA0], xmm11
000076c1d9ddff00  vmovaps [rsp+0xB0], xmm12
000076c1d9ddff09  vmovaps [rsp+0xC0], xmm13
000076c1d9ddff12  vmovaps [rsp+0xD0], xmm14
000076c1d9ddff1b  vmovaps [rsp+0xE0], xmm15
000076c1d9ddff24  sub rsp, 0x30
000076c1d9ddff28  movaps [rsp], xmm10
000076c1d9ddff2d  movaps [rsp+0x10], xmm14
000076c1d9ddff33  movaps [rsp+0x20], xmm4
000076c1d9ddff38  lea rdi, [rsp]
000076c1d9ddff3c  mov esi, 0x00
000076c1d9ddff41  mov rax, 0x5EA58B9E0530
000076c1d9ddff4b  call rax
000076c1d9ddff4d  movaps xmm10, [rsp]
000076c1d9ddff52  add rsp, 0x30
000076c1d9ddff56  vmovaps xmm0, [rsp]
000076c1d9ddff5b  vmovaps xmm1, [rsp+0x10]
000076c1d9ddff61  vmovaps xmm2, [rsp+0x20]
000076c1d9ddff67  vmovaps xmm3, [rsp+0x30]
000076c1d9ddff6d  vmovaps xmm4, [rsp+0x40]
000076c1d9ddff73  vmovaps xmm5, [rsp+0x50]
000076c1d9ddff79  vmovaps xmm6, [rsp+0x60]
000076c1d9ddff7f  vmovaps xmm7, [rsp+0x70]
000076c1d9ddff85  vmovaps xmm8, [rsp+0x80]
000076c1d9ddff8e  vmovaps xmm9, [rsp+0x90]
000076c1d9ddff97  vmovaps xmm11, [rsp+0xA0]
000076c1d9ddffa0  vmovaps xmm12, [rsp+0xB0]
000076c1d9ddffa9  vmovaps xmm13, [rsp+0xC0]
000076c1d9ddffb2  vmovaps xmm14, [rsp+0xD0]
000076c1d9ddffbb  vmovaps xmm15, [rsp+0xE0]
000076c1d9ddffc4  add rsp, 0xF0
000076c1d9ddffcb  pop r11
000076c1d9ddffcd  pop r10
000076c1d9ddffcf  pop r9
000076c1d9ddffd1  pop r8
000076c1d9ddffd3  pop rsi
000076c1d9ddffd4  pop rdi
000076c1d9ddffd5  pop rdx
000076c1d9ddffd6  pop rcx
000076c1d9ddffd7  pop rax
000076c1d9ddffd8  add rsp, 0x08
000076c1d9ddffdc  jmp 0x000076C1D9DDC53B
000076c1d9ddffe1  sub rsp, 0x08
000076c1d9ddffe5  push rax
000076c1d9ddffe6  push rcx
000076c1d9ddffe7  push rdx
000076c1d9ddffe8  push rdi
000076c1d9ddffe9  push rsi
000076c1d9ddffea  push r8
000076c1d9ddffec  push r9
000076c1d9ddffee  push r10
000076c1d9ddfff0  push r11
000076c1d9ddfff2  sub rsp, 0xF0
000076c1d9ddfff9  vmovaps [rsp], xmm0
000076c1d9ddfffe  vmovaps [rsp+0x10], xmm1
000076c1d9de0004  vmovaps [rsp+0x20], xmm2
000076c1d9de000a  vmovaps [rsp+0x30], xmm3
000076c1d9de0010  vmovaps [rsp+0x40], xmm4
000076c1d9de0016  vmovaps [rsp+0x50], xmm5
000076c1d9de001c  vmovaps [rsp+0x60], xmm6
000076c1d9de0022  vmovaps [rsp+0x70], xmm7
000076c1d9de0028  vmovaps [rsp+0x80], xmm9
000076c1d9de0031  vmovaps [rsp+0x90], xmm10
000076c1d9de003a  vmovaps [rsp+0xA0], xmm11
000076c1d9de0043  vmovaps [rsp+0xB0], xmm12
000076c1d9de004c  vmovaps [rsp+0xC0], xmm13
000076c1d9de0055  vmovaps [rsp+0xD0], xmm14
000076c1d9de005e  vmovaps [rsp+0xE0], xmm15
000076c1d9de0067  sub rsp, 0x30
000076c1d9de006b  movaps [rsp], xmm8
000076c1d9de0070  movaps [rsp+0x10], xmm1
000076c1d9de0075  movaps [rsp+0x20], xmm14
000076c1d9de007b  lea rdi, [rsp]
000076c1d9de007f  mov esi, 0x00
000076c1d9de0084  mov rax, 0x5EA58B9E0530
000076c1d9de008e  call rax
000076c1d9de0090  movaps xmm8, [rsp]
000076c1d9de0095  add rsp, 0x30
000076c1d9de0099  vmovaps xmm0, [rsp]
000076c1d9de009e  vmovaps xmm1, [rsp+0x10]
000076c1d9de00a4  vmovaps xmm2, [rsp+0x20]
000076c1d9de00aa  vmovaps xmm3, [rsp+0x30]
000076c1d9de00b0  vmovaps xmm4, [rsp+0x40]
000076c1d9de00b6  vmovaps xmm5, [rsp+0x50]
000076c1d9de00bc  vmovaps xmm6, [rsp+0x60]
000076c1d9de00c2  vmovaps xmm7, [rsp+0x70]
000076c1d9de00c8  vmovaps xmm9, [rsp+0x80]
000076c1d9de00d1  vmovaps xmm10, [rsp+0x90]
000076c1d9de00da  vmovaps xmm11, [rsp+0xA0]
000076c1d9de00e3  vmovaps xmm12, [rsp+0xB0]
000076c1d9de00ec  vmovaps xmm13, [rsp+0xC0]
000076c1d9de00f5  vmovaps xmm14, [rsp+0xD0]
000076c1d9de00fe  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0107  add rsp, 0xF0
000076c1d9de010e  pop r11
000076c1d9de0110  pop r10
000076c1d9de0112  pop r9
000076c1d9de0114  pop r8
000076c1d9de0116  pop rsi
000076c1d9de0117  pop rdi
000076c1d9de0118  pop rdx
000076c1d9de0119  pop rcx
000076c1d9de011a  pop rax
000076c1d9de011b  add rsp, 0x08
000076c1d9de011f  jmp 0x000076C1D9DDC561
000076c1d9de0124  sub rsp, 0x08
000076c1d9de0128  push rax
000076c1d9de0129  push rcx
000076c1d9de012a  push rdx
000076c1d9de012b  push rdi
000076c1d9de012c  push rsi
000076c1d9de012d  push r8
000076c1d9de012f  push r9
000076c1d9de0131  push r10
000076c1d9de0133  push r11
000076c1d9de0135  sub rsp, 0xF0
000076c1d9de013c  vmovaps [rsp], xmm0
000076c1d9de0141  vmovaps [rsp+0x10], xmm1
000076c1d9de0147  vmovaps [rsp+0x20], xmm2
000076c1d9de014d  vmovaps [rsp+0x30], xmm3
000076c1d9de0153  vmovaps [rsp+0x40], xmm4
000076c1d9de0159  vmovaps [rsp+0x50], xmm5
000076c1d9de015f  vmovaps [rsp+0x60], xmm7
000076c1d9de0165  vmovaps [rsp+0x70], xmm8
000076c1d9de016b  vmovaps [rsp+0x80], xmm9
000076c1d9de0174  vmovaps [rsp+0x90], xmm10
000076c1d9de017d  vmovaps [rsp+0xA0], xmm11
000076c1d9de0186  vmovaps [rsp+0xB0], xmm12
000076c1d9de018f  vmovaps [rsp+0xC0], xmm13
000076c1d9de0198  vmovaps [rsp+0xD0], xmm14
000076c1d9de01a1  vmovaps [rsp+0xE0], xmm15
000076c1d9de01aa  sub rsp, 0x30
000076c1d9de01ae  movaps [rsp], xmm6
000076c1d9de01b2  movaps [rsp+0x10], xmm1
000076c1d9de01b7  movaps [rsp+0x20], xmm14
000076c1d9de01bd  lea rdi, [rsp]
000076c1d9de01c1  mov esi, 0x00
000076c1d9de01c6  mov rax, 0x5EA58B9E0530
000076c1d9de01d0  call rax
000076c1d9de01d2  movaps xmm6, [rsp]
000076c1d9de01d6  add rsp, 0x30
000076c1d9de01da  vmovaps xmm0, [rsp]
000076c1d9de01df  vmovaps xmm1, [rsp+0x10]
000076c1d9de01e5  vmovaps xmm2, [rsp+0x20]
000076c1d9de01eb  vmovaps xmm3, [rsp+0x30]
000076c1d9de01f1  vmovaps xmm4, [rsp+0x40]
000076c1d9de01f7  vmovaps xmm5, [rsp+0x50]
000076c1d9de01fd  vmovaps xmm7, [rsp+0x60]
000076c1d9de0203  vmovaps xmm8, [rsp+0x70]
000076c1d9de0209  vmovaps xmm9, [rsp+0x80]
000076c1d9de0212  vmovaps xmm10, [rsp+0x90]
000076c1d9de021b  vmovaps xmm11, [rsp+0xA0]
000076c1d9de0224  vmovaps xmm12, [rsp+0xB0]
000076c1d9de022d  vmovaps xmm13, [rsp+0xC0]
000076c1d9de0236  vmovaps xmm14, [rsp+0xD0]
000076c1d9de023f  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0248  add rsp, 0xF0
000076c1d9de024f  pop r11
000076c1d9de0251  pop r10
000076c1d9de0253  pop r9
000076c1d9de0255  pop r8
000076c1d9de0257  pop rsi
000076c1d9de0258  pop rdi
000076c1d9de0259  pop rdx
000076c1d9de025a  pop rcx
000076c1d9de025b  pop rax
000076c1d9de025c  add rsp, 0x08
000076c1d9de0260  jmp 0x000076C1D9DDC58D
000076c1d9de0265  sub rsp, 0x08
000076c1d9de0269  push rax
000076c1d9de026a  push rcx
000076c1d9de026b  push rdx
000076c1d9de026c  push rdi
000076c1d9de026d  push rsi
000076c1d9de026e  push r8
000076c1d9de0270  push r9
000076c1d9de0272  push r10
000076c1d9de0274  push r11
000076c1d9de0276  sub rsp, 0xF0
000076c1d9de027d  vmovaps [rsp], xmm0
000076c1d9de0282  vmovaps [rsp+0x10], xmm1
000076c1d9de0288  vmovaps [rsp+0x20], xmm2
000076c1d9de028e  vmovaps [rsp+0x30], xmm3
000076c1d9de0294  vmovaps [rsp+0x40], xmm4
000076c1d9de029a  vmovaps [rsp+0x50], xmm5
000076c1d9de02a0  vmovaps [rsp+0x60], xmm6
000076c1d9de02a6  vmovaps [rsp+0x70], xmm7
000076c1d9de02ac  vmovaps [rsp+0x80], xmm8
000076c1d9de02b5  vmovaps [rsp+0x90], xmm9
000076c1d9de02be  vmovaps [rsp+0xA0], xmm10
000076c1d9de02c7  vmovaps [rsp+0xB0], xmm11
000076c1d9de02d0  vmovaps [rsp+0xC0], xmm12
000076c1d9de02d9  vmovaps [rsp+0xD0], xmm13
000076c1d9de02e2  vmovaps [rsp+0xE0], xmm15
000076c1d9de02eb  sub rsp, 0x30
000076c1d9de02ef  movaps [rsp], xmm14
000076c1d9de02f4  movaps [rsp+0x10], xmm12
000076c1d9de02fa  movaps [rsp+0x20], xmm1
000076c1d9de02ff  lea rdi, [rsp]
000076c1d9de0303  mov esi, 0x00
000076c1d9de0308  mov rax, 0x5EA58B9E0530
000076c1d9de0312  call rax
000076c1d9de0314  movaps xmm14, [rsp]
000076c1d9de0319  add rsp, 0x30
000076c1d9de031d  vmovaps xmm0, [rsp]
000076c1d9de0322  vmovaps xmm1, [rsp+0x10]
000076c1d9de0328  vmovaps xmm2, [rsp+0x20]
000076c1d9de032e  vmovaps xmm3, [rsp+0x30]
000076c1d9de0334  vmovaps xmm4, [rsp+0x40]
000076c1d9de033a  vmovaps xmm5, [rsp+0x50]
000076c1d9de0340  vmovaps xmm6, [rsp+0x60]
000076c1d9de0346  vmovaps xmm7, [rsp+0x70]
000076c1d9de034c  vmovaps xmm8, [rsp+0x80]
000076c1d9de0355  vmovaps xmm9, [rsp+0x90]
000076c1d9de035e  vmovaps xmm10, [rsp+0xA0]
000076c1d9de0367  vmovaps xmm11, [rsp+0xB0]
000076c1d9de0370  vmovaps xmm12, [rsp+0xC0]
000076c1d9de0379  vmovaps xmm13, [rsp+0xD0]
000076c1d9de0382  vmovaps xmm15, [rsp+0xE0]
000076c1d9de038b  add rsp, 0xF0
000076c1d9de0392  pop r11
000076c1d9de0394  pop r10
000076c1d9de0396  pop r9
000076c1d9de0398  pop r8
000076c1d9de039a  pop rsi
000076c1d9de039b  pop rdi
000076c1d9de039c  pop rdx
000076c1d9de039d  pop rcx
000076c1d9de039e  pop rax
000076c1d9de039f  add rsp, 0x08
000076c1d9de03a3  jmp 0x000076C1D9DDC5B3
000076c1d9de03a8  sub rsp, 0x08
000076c1d9de03ac  push rax
000076c1d9de03ad  push rcx
000076c1d9de03ae  push rdx
000076c1d9de03af  push rdi
000076c1d9de03b0  push rsi
000076c1d9de03b1  push r8
000076c1d9de03b3  push r9
000076c1d9de03b5  push r10
000076c1d9de03b7  push r11
000076c1d9de03b9  sub rsp, 0xF0
000076c1d9de03c0  vmovaps [rsp], xmm0
000076c1d9de03c5  vmovaps [rsp+0x10], xmm2
000076c1d9de03cb  vmovaps [rsp+0x20], xmm3
000076c1d9de03d1  vmovaps [rsp+0x30], xmm4
000076c1d9de03d7  vmovaps [rsp+0x40], xmm5
000076c1d9de03dd  vmovaps [rsp+0x50], xmm6
000076c1d9de03e3  vmovaps [rsp+0x60], xmm7
000076c1d9de03e9  vmovaps [rsp+0x70], xmm8
000076c1d9de03ef  vmovaps [rsp+0x80], xmm9
000076c1d9de03f8  vmovaps [rsp+0x90], xmm10
000076c1d9de0401  vmovaps [rsp+0xA0], xmm11
000076c1d9de040a  vmovaps [rsp+0xB0], xmm12
000076c1d9de0413  vmovaps [rsp+0xC0], xmm13
000076c1d9de041c  vmovaps [rsp+0xD0], xmm14
000076c1d9de0425  vmovaps [rsp+0xE0], xmm15
000076c1d9de042e  sub rsp, 0x30
000076c1d9de0432  movaps [rsp], xmm1
000076c1d9de0436  movaps [rsp+0x10], xmm13
000076c1d9de043c  movaps [rsp+0x20], xmm9
000076c1d9de0442  lea rdi, [rsp]
000076c1d9de0446  mov esi, 0x00
000076c1d9de044b  mov rax, 0x5EA58B9E0530
000076c1d9de0455  call rax
000076c1d9de0457  movaps xmm1, [rsp]
000076c1d9de045b  add rsp, 0x30
000076c1d9de045f  vmovaps xmm0, [rsp]
000076c1d9de0464  vmovaps xmm2, [rsp+0x10]
000076c1d9de046a  vmovaps xmm3, [rsp+0x20]
000076c1d9de0470  vmovaps xmm4, [rsp+0x30]
000076c1d9de0476  vmovaps xmm5, [rsp+0x40]
000076c1d9de047c  vmovaps xmm6, [rsp+0x50]
000076c1d9de0482  vmovaps xmm7, [rsp+0x60]
000076c1d9de0488  vmovaps xmm8, [rsp+0x70]
000076c1d9de048e  vmovaps xmm9, [rsp+0x80]
000076c1d9de0497  vmovaps xmm10, [rsp+0x90]
000076c1d9de04a0  vmovaps xmm11, [rsp+0xA0]
000076c1d9de04a9  vmovaps xmm12, [rsp+0xB0]
000076c1d9de04b2  vmovaps xmm13, [rsp+0xC0]
000076c1d9de04bb  vmovaps xmm14, [rsp+0xD0]
000076c1d9de04c4  vmovaps xmm15, [rsp+0xE0]
000076c1d9de04cd  add rsp, 0xF0
000076c1d9de04d4  pop r11
000076c1d9de04d6  pop r10
000076c1d9de04d8  pop r9
000076c1d9de04da  pop r8
000076c1d9de04dc  pop rsi
000076c1d9de04dd  pop rdi
000076c1d9de04de  pop rdx
000076c1d9de04df  pop rcx
000076c1d9de04e0  pop rax
000076c1d9de04e1  add rsp, 0x08
000076c1d9de04e5  jmp 0x000076C1D9DDC5CD
000076c1d9de04ea  sub rsp, 0x08
000076c1d9de04ee  push rax
000076c1d9de04ef  push rcx
000076c1d9de04f0  push rdx
000076c1d9de04f1  push rdi
000076c1d9de04f2  push rsi
000076c1d9de04f3  push r8
000076c1d9de04f5  push r9
000076c1d9de04f7  push r10
000076c1d9de04f9  push r11
000076c1d9de04fb  sub rsp, 0xF0
000076c1d9de0502  vmovaps [rsp], xmm0
000076c1d9de0507  vmovaps [rsp+0x10], xmm1
000076c1d9de050d  vmovaps [rsp+0x20], xmm2
000076c1d9de0513  vmovaps [rsp+0x30], xmm3
000076c1d9de0519  vmovaps [rsp+0x40], xmm4
000076c1d9de051f  vmovaps [rsp+0x50], xmm5
000076c1d9de0525  vmovaps [rsp+0x60], xmm6
000076c1d9de052b  vmovaps [rsp+0x70], xmm7
000076c1d9de0531  vmovaps [rsp+0x80], xmm8
000076c1d9de053a  vmovaps [rsp+0x90], xmm9
000076c1d9de0543  vmovaps [rsp+0xA0], xmm10
000076c1d9de054c  vmovaps [rsp+0xB0], xmm11
000076c1d9de0555  vmovaps [rsp+0xC0], xmm13
000076c1d9de055e  vmovaps [rsp+0xD0], xmm14
000076c1d9de0567  vmovaps [rsp+0xE0], xmm15
000076c1d9de0570  sub rsp, 0x30
000076c1d9de0574  movaps [rsp], xmm12
000076c1d9de0579  movaps [rsp+0x10], xmm7
000076c1d9de057e  movaps [rsp+0x20], xmm13
000076c1d9de0584  lea rdi, [rsp]
000076c1d9de0588  mov esi, 0x00
000076c1d9de058d  mov rax, 0x5EA58B9E0530
000076c1d9de0597  call rax
000076c1d9de0599  movaps xmm12, [rsp]
000076c1d9de059e  add rsp, 0x30
000076c1d9de05a2  vmovaps xmm0, [rsp]
000076c1d9de05a7  vmovaps xmm1, [rsp+0x10]
000076c1d9de05ad  vmovaps xmm2, [rsp+0x20]
000076c1d9de05b3  vmovaps xmm3, [rsp+0x30]
000076c1d9de05b9  vmovaps xmm4, [rsp+0x40]
000076c1d9de05bf  vmovaps xmm5, [rsp+0x50]
000076c1d9de05c5  vmovaps xmm6, [rsp+0x60]
000076c1d9de05cb  vmovaps xmm7, [rsp+0x70]
000076c1d9de05d1  vmovaps xmm8, [rsp+0x80]
000076c1d9de05da  vmovaps xmm9, [rsp+0x90]
000076c1d9de05e3  vmovaps xmm10, [rsp+0xA0]
000076c1d9de05ec  vmovaps xmm11, [rsp+0xB0]
000076c1d9de05f5  vmovaps xmm13, [rsp+0xC0]
000076c1d9de05fe  vmovaps xmm14, [rsp+0xD0]
000076c1d9de0607  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0610  add rsp, 0xF0
000076c1d9de0617  pop r11
000076c1d9de0619  pop r10
000076c1d9de061b  pop r9
000076c1d9de061d  pop r8
000076c1d9de061f  pop rsi
000076c1d9de0620  pop rdi
000076c1d9de0621  pop rdx
000076c1d9de0622  pop rcx
000076c1d9de0623  pop rax
000076c1d9de0624  add rsp, 0x08
000076c1d9de0628  jmp 0x000076C1D9DDC5F4
000076c1d9de062d  sub rsp, 0x08
000076c1d9de0631  push rax
000076c1d9de0632  push rcx
000076c1d9de0633  push rdx
000076c1d9de0634  push rdi
000076c1d9de0635  push rsi
000076c1d9de0636  push r8
000076c1d9de0638  push r9
000076c1d9de063a  push r10
000076c1d9de063c  push r11
000076c1d9de063e  sub rsp, 0xF0
000076c1d9de0645  vmovaps [rsp], xmm0
000076c1d9de064a  vmovaps [rsp+0x10], xmm1
000076c1d9de0650  vmovaps [rsp+0x20], xmm2
000076c1d9de0656  vmovaps [rsp+0x30], xmm3
000076c1d9de065c  vmovaps [rsp+0x40], xmm4
000076c1d9de0662  vmovaps [rsp+0x50], xmm5
000076c1d9de0668  vmovaps [rsp+0x60], xmm6
000076c1d9de066e  vmovaps [rsp+0x70], xmm7
000076c1d9de0674  vmovaps [rsp+0x80], xmm8
000076c1d9de067d  vmovaps [rsp+0x90], xmm9
000076c1d9de0686  vmovaps [rsp+0xA0], xmm10
000076c1d9de068f  vmovaps [rsp+0xB0], xmm11
000076c1d9de0698  vmovaps [rsp+0xC0], xmm12
000076c1d9de06a1  vmovaps [rsp+0xD0], xmm14
000076c1d9de06aa  vmovaps [rsp+0xE0], xmm15
000076c1d9de06b3  sub rsp, 0x30
000076c1d9de06b7  movaps [rsp], xmm13
000076c1d9de06bc  movaps [rsp+0x10], xmm15
000076c1d9de06c2  movaps [rsp+0x20], xmm8
000076c1d9de06c8  lea rdi, [rsp]
000076c1d9de06cc  mov esi, 0x00
000076c1d9de06d1  mov rax, 0x5EA58B9E0530
000076c1d9de06db  call rax
000076c1d9de06dd  movaps xmm13, [rsp]
000076c1d9de06e2  add rsp, 0x30
000076c1d9de06e6  vmovaps xmm0, [rsp]
000076c1d9de06eb  vmovaps xmm1, [rsp+0x10]
000076c1d9de06f1  vmovaps xmm2, [rsp+0x20]
000076c1d9de06f7  vmovaps xmm3, [rsp+0x30]
000076c1d9de06fd  vmovaps xmm4, [rsp+0x40]
000076c1d9de0703  vmovaps xmm5, [rsp+0x50]
000076c1d9de0709  vmovaps xmm6, [rsp+0x60]
000076c1d9de070f  vmovaps xmm7, [rsp+0x70]
000076c1d9de0715  vmovaps xmm8, [rsp+0x80]
000076c1d9de071e  vmovaps xmm9, [rsp+0x90]
000076c1d9de0727  vmovaps xmm10, [rsp+0xA0]
000076c1d9de0730  vmovaps xmm11, [rsp+0xB0]
000076c1d9de0739  vmovaps xmm12, [rsp+0xC0]
000076c1d9de0742  vmovaps xmm14, [rsp+0xD0]
000076c1d9de074b  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0754  add rsp, 0xF0
000076c1d9de075b  pop r11
000076c1d9de075d  pop r10
000076c1d9de075f  pop r9
000076c1d9de0761  pop r8
000076c1d9de0763  pop rsi
000076c1d9de0764  pop rdi
000076c1d9de0765  pop rdx
000076c1d9de0766  pop rcx
000076c1d9de0767  pop rax
000076c1d9de0768  add rsp, 0x08
000076c1d9de076c  jmp 0x000076C1D9DDC60F
000076c1d9de0771  sub rsp, 0x08
000076c1d9de0775  push rax
000076c1d9de0776  push rcx
000076c1d9de0777  push rdx
000076c1d9de0778  push rdi
000076c1d9de0779  push rsi
000076c1d9de077a  push r8
000076c1d9de077c  push r9
000076c1d9de077e  push r10
000076c1d9de0780  push r11
000076c1d9de0782  sub rsp, 0xF0
000076c1d9de0789  vmovaps [rsp], xmm0
000076c1d9de078e  vmovaps [rsp+0x10], xmm1
000076c1d9de0794  vmovaps [rsp+0x20], xmm2
000076c1d9de079a  vmovaps [rsp+0x30], xmm3
000076c1d9de07a0  vmovaps [rsp+0x40], xmm4
000076c1d9de07a6  vmovaps [rsp+0x50], xmm5
000076c1d9de07ac  vmovaps [rsp+0x60], xmm6
000076c1d9de07b2  vmovaps [rsp+0x70], xmm7
000076c1d9de07b8  vmovaps [rsp+0x80], xmm9
000076c1d9de07c1  vmovaps [rsp+0x90], xmm10
000076c1d9de07ca  vmovaps [rsp+0xA0], xmm11
000076c1d9de07d3  vmovaps [rsp+0xB0], xmm12
000076c1d9de07dc  vmovaps [rsp+0xC0], xmm13
000076c1d9de07e5  vmovaps [rsp+0xD0], xmm14
000076c1d9de07ee  vmovaps [rsp+0xE0], xmm15
000076c1d9de07f7  sub rsp, 0x30
000076c1d9de07fb  movaps [rsp], xmm8
000076c1d9de0800  movaps [rsp+0x10], xmm15
000076c1d9de0806  movaps [rsp+0x20], xmm9
000076c1d9de080c  lea rdi, [rsp]
000076c1d9de0810  mov esi, 0x00
000076c1d9de0815  mov rax, 0x5EA58B9E0530
000076c1d9de081f  call rax
000076c1d9de0821  movaps xmm8, [rsp]
000076c1d9de0826  add rsp, 0x30
000076c1d9de082a  vmovaps xmm0, [rsp]
000076c1d9de082f  vmovaps xmm1, [rsp+0x10]
000076c1d9de0835  vmovaps xmm2, [rsp+0x20]
000076c1d9de083b  vmovaps xmm3, [rsp+0x30]
000076c1d9de0841  vmovaps xmm4, [rsp+0x40]
000076c1d9de0847  vmovaps xmm5, [rsp+0x50]
000076c1d9de084d  vmovaps xmm6, [rsp+0x60]
000076c1d9de0853  vmovaps xmm7, [rsp+0x70]
000076c1d9de0859  vmovaps xmm9, [rsp+0x80]
000076c1d9de0862  vmovaps xmm10, [rsp+0x90]
000076c1d9de086b  vmovaps xmm11, [rsp+0xA0]
000076c1d9de0874  vmovaps xmm12, [rsp+0xB0]
000076c1d9de087d  vmovaps xmm13, [rsp+0xC0]
000076c1d9de0886  vmovaps xmm14, [rsp+0xD0]
000076c1d9de088f  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0898  add rsp, 0xF0
000076c1d9de089f  pop r11
000076c1d9de08a1  pop r10
000076c1d9de08a3  pop r9
000076c1d9de08a5  pop r8
000076c1d9de08a7  pop rsi
000076c1d9de08a8  pop rdi
000076c1d9de08a9  pop rdx
000076c1d9de08aa  pop rcx
000076c1d9de08ab  pop rax
000076c1d9de08ac  add rsp, 0x08
000076c1d9de08b0  jmp 0x000076C1D9DDC63D
000076c1d9de08b5  sub rsp, 0x08
000076c1d9de08b9  push rax
000076c1d9de08ba  push rcx
000076c1d9de08bb  push rdx
000076c1d9de08bc  push rdi
000076c1d9de08bd  push rsi
000076c1d9de08be  push r8
000076c1d9de08c0  push r9
000076c1d9de08c2  push r10
000076c1d9de08c4  push r11
000076c1d9de08c6  sub rsp, 0xF0
000076c1d9de08cd  vmovaps [rsp], xmm0
000076c1d9de08d2  vmovaps [rsp+0x10], xmm1
000076c1d9de08d8  vmovaps [rsp+0x20], xmm2
000076c1d9de08de  vmovaps [rsp+0x30], xmm3
000076c1d9de08e4  vmovaps [rsp+0x40], xmm4
000076c1d9de08ea  vmovaps [rsp+0x50], xmm5
000076c1d9de08f0  vmovaps [rsp+0x60], xmm6
000076c1d9de08f6  vmovaps [rsp+0x70], xmm7
000076c1d9de08fc  vmovaps [rsp+0x80], xmm8
000076c1d9de0905  vmovaps [rsp+0x90], xmm9
000076c1d9de090e  vmovaps [rsp+0xA0], xmm10
000076c1d9de0917  vmovaps [rsp+0xB0], xmm11
000076c1d9de0920  vmovaps [rsp+0xC0], xmm12
000076c1d9de0929  vmovaps [rsp+0xD0], xmm13
000076c1d9de0932  vmovaps [rsp+0xE0], xmm14
000076c1d9de093b  sub rsp, 0x30
000076c1d9de093f  movaps [rsp], xmm15
000076c1d9de0944  movaps [rsp+0x10], xmm11
000076c1d9de094a  movaps [rsp+0x20], xmm6
000076c1d9de094f  lea rdi, [rsp]
000076c1d9de0953  mov esi, 0x00
000076c1d9de0958  mov rax, 0x5EA58B9E0530
000076c1d9de0962  call rax
000076c1d9de0964  movaps xmm15, [rsp]
000076c1d9de0969  add rsp, 0x30
000076c1d9de096d  vmovaps xmm0, [rsp]
000076c1d9de0972  vmovaps xmm1, [rsp+0x10]
000076c1d9de0978  vmovaps xmm2, [rsp+0x20]
000076c1d9de097e  vmovaps xmm3, [rsp+0x30]
000076c1d9de0984  vmovaps xmm4, [rsp+0x40]
000076c1d9de098a  vmovaps xmm5, [rsp+0x50]
000076c1d9de0990  vmovaps xmm6, [rsp+0x60]
000076c1d9de0996  vmovaps xmm7, [rsp+0x70]
000076c1d9de099c  vmovaps xmm8, [rsp+0x80]
000076c1d9de09a5  vmovaps xmm9, [rsp+0x90]
000076c1d9de09ae  vmovaps xmm10, [rsp+0xA0]
000076c1d9de09b7  vmovaps xmm11, [rsp+0xB0]
000076c1d9de09c0  vmovaps xmm12, [rsp+0xC0]
000076c1d9de09c9  vmovaps xmm13, [rsp+0xD0]
000076c1d9de09d2  vmovaps xmm14, [rsp+0xE0]
000076c1d9de09db  add rsp, 0xF0
000076c1d9de09e2  pop r11
000076c1d9de09e4  pop r10
000076c1d9de09e6  pop r9
000076c1d9de09e8  pop r8
000076c1d9de09ea  pop rsi
000076c1d9de09eb  pop rdi
000076c1d9de09ec  pop rdx
000076c1d9de09ed  pop rcx
000076c1d9de09ee  pop rax
000076c1d9de09ef  add rsp, 0x08
000076c1d9de09f3  jmp 0x000076C1D9DDC658
000076c1d9de09f8  sub rsp, 0x08
000076c1d9de09fc  push rax
000076c1d9de09fd  push rcx
000076c1d9de09fe  push rdx
000076c1d9de09ff  push rdi
000076c1d9de0a00  push rsi
000076c1d9de0a01  push r8
000076c1d9de0a03  push r9
000076c1d9de0a05  push r10
000076c1d9de0a07  push r11
000076c1d9de0a09  sub rsp, 0xF0
000076c1d9de0a10  vmovaps [rsp], xmm0
000076c1d9de0a15  vmovaps [rsp+0x10], xmm1
000076c1d9de0a1b  vmovaps [rsp+0x20], xmm2
000076c1d9de0a21  vmovaps [rsp+0x30], xmm3
000076c1d9de0a27  vmovaps [rsp+0x40], xmm4
000076c1d9de0a2d  vmovaps [rsp+0x50], xmm5
000076c1d9de0a33  vmovaps [rsp+0x60], xmm6
000076c1d9de0a39  vmovaps [rsp+0x70], xmm8
000076c1d9de0a3f  vmovaps [rsp+0x80], xmm9
000076c1d9de0a48  vmovaps [rsp+0x90], xmm10
000076c1d9de0a51  vmovaps [rsp+0xA0], xmm11
000076c1d9de0a5a  vmovaps [rsp+0xB0], xmm12
000076c1d9de0a63  vmovaps [rsp+0xC0], xmm13
000076c1d9de0a6c  vmovaps [rsp+0xD0], xmm14
000076c1d9de0a75  vmovaps [rsp+0xE0], xmm15
000076c1d9de0a7e  sub rsp, 0x30
000076c1d9de0a82  movaps [rsp], xmm7
000076c1d9de0a86  movaps [rsp+0x10], xmm11
000076c1d9de0a8c  movaps [rsp+0x20], xmm9
000076c1d9de0a92  lea rdi, [rsp]
000076c1d9de0a96  mov esi, 0x00
000076c1d9de0a9b  mov rax, 0x5EA58B9E0530
000076c1d9de0aa5  call rax
000076c1d9de0aa7  movaps xmm7, [rsp]
000076c1d9de0aab  add rsp, 0x30
000076c1d9de0aaf  vmovaps xmm0, [rsp]
000076c1d9de0ab4  vmovaps xmm1, [rsp+0x10]
000076c1d9de0aba  vmovaps xmm2, [rsp+0x20]
000076c1d9de0ac0  vmovaps xmm3, [rsp+0x30]
000076c1d9de0ac6  vmovaps xmm4, [rsp+0x40]
000076c1d9de0acc  vmovaps xmm5, [rsp+0x50]
000076c1d9de0ad2  vmovaps xmm6, [rsp+0x60]
000076c1d9de0ad8  vmovaps xmm8, [rsp+0x70]
000076c1d9de0ade  vmovaps xmm9, [rsp+0x80]
000076c1d9de0ae7  vmovaps xmm10, [rsp+0x90]
000076c1d9de0af0  vmovaps xmm11, [rsp+0xA0]
000076c1d9de0af9  vmovaps xmm12, [rsp+0xB0]
000076c1d9de0b02  vmovaps xmm13, [rsp+0xC0]
000076c1d9de0b0b  vmovaps xmm14, [rsp+0xD0]
000076c1d9de0b14  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0b1d  add rsp, 0xF0
000076c1d9de0b24  pop r11
000076c1d9de0b26  pop r10
000076c1d9de0b28  pop r9
000076c1d9de0b2a  pop r8
000076c1d9de0b2c  pop rsi
000076c1d9de0b2d  pop rdi
000076c1d9de0b2e  pop rdx
000076c1d9de0b2f  pop rcx
000076c1d9de0b30  pop rax
000076c1d9de0b31  add rsp, 0x08
000076c1d9de0b35  jmp 0x000076C1D9DDC685
000076c1d9de0b3a  sub rsp, 0x08
000076c1d9de0b3e  push rax
000076c1d9de0b3f  push rcx
000076c1d9de0b40  push rdx
000076c1d9de0b41  push rdi
000076c1d9de0b42  push rsi
000076c1d9de0b43  push r8
000076c1d9de0b45  push r9
000076c1d9de0b47  push r10
000076c1d9de0b49  push r11
000076c1d9de0b4b  sub rsp, 0xF0
000076c1d9de0b52  vmovaps [rsp], xmm0
000076c1d9de0b57  vmovaps [rsp+0x10], xmm1
000076c1d9de0b5d  vmovaps [rsp+0x20], xmm2
000076c1d9de0b63  vmovaps [rsp+0x30], xmm3
000076c1d9de0b69  vmovaps [rsp+0x40], xmm4
000076c1d9de0b6f  vmovaps [rsp+0x50], xmm5
000076c1d9de0b75  vmovaps [rsp+0x60], xmm6
000076c1d9de0b7b  vmovaps [rsp+0x70], xmm7
000076c1d9de0b81  vmovaps [rsp+0x80], xmm8
000076c1d9de0b8a  vmovaps [rsp+0x90], xmm9
000076c1d9de0b93  vmovaps [rsp+0xA0], xmm10
000076c1d9de0b9c  vmovaps [rsp+0xB0], xmm12
000076c1d9de0ba5  vmovaps [rsp+0xC0], xmm13
000076c1d9de0bae  vmovaps [rsp+0xD0], xmm14
000076c1d9de0bb7  vmovaps [rsp+0xE0], xmm15
000076c1d9de0bc0  sub rsp, 0x30
000076c1d9de0bc4  movaps [rsp], xmm11
000076c1d9de0bc9  movaps [rsp+0x10], xmm10
000076c1d9de0bcf  movaps [rsp+0x20], xmm14
000076c1d9de0bd5  lea rdi, [rsp]
000076c1d9de0bd9  mov esi, 0x00
000076c1d9de0bde  mov rax, 0x5EA58B9E0530
000076c1d9de0be8  call rax
000076c1d9de0bea  movaps xmm11, [rsp]
000076c1d9de0bef  add rsp, 0x30
000076c1d9de0bf3  vmovaps xmm0, [rsp]
000076c1d9de0bf8  vmovaps xmm1, [rsp+0x10]
000076c1d9de0bfe  vmovaps xmm2, [rsp+0x20]
000076c1d9de0c04  vmovaps xmm3, [rsp+0x30]
000076c1d9de0c0a  vmovaps xmm4, [rsp+0x40]
000076c1d9de0c10  vmovaps xmm5, [rsp+0x50]
000076c1d9de0c16  vmovaps xmm6, [rsp+0x60]
000076c1d9de0c1c  vmovaps xmm7, [rsp+0x70]
000076c1d9de0c22  vmovaps xmm8, [rsp+0x80]
000076c1d9de0c2b  vmovaps xmm9, [rsp+0x90]
000076c1d9de0c34  vmovaps xmm10, [rsp+0xA0]
000076c1d9de0c3d  vmovaps xmm12, [rsp+0xB0]
000076c1d9de0c46  vmovaps xmm13, [rsp+0xC0]
000076c1d9de0c4f  vmovaps xmm14, [rsp+0xD0]
000076c1d9de0c58  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0c61  add rsp, 0xF0
000076c1d9de0c68  pop r11
000076c1d9de0c6a  pop r10
000076c1d9de0c6c  pop r9
000076c1d9de0c6e  pop r8
000076c1d9de0c70  pop rsi
000076c1d9de0c71  pop rdi
000076c1d9de0c72  pop rdx
000076c1d9de0c73  pop rcx
000076c1d9de0c74  pop rax
000076c1d9de0c75  add rsp, 0x08
000076c1d9de0c79  jmp 0x000076C1D9DDC6A0
000076c1d9de0c7e  call 0x000076C1D9CC33A0
000076c1d9de0c83  jmp 0x000076C1D9DDC6AA
000076c1d9de0c88  sub rsp, 0x08
000076c1d9de0c8c  push rax
000076c1d9de0c8d  push rcx
000076c1d9de0c8e  push rdx
000076c1d9de0c8f  push rdi
000076c1d9de0c90  push rsi
000076c1d9de0c91  push r8
000076c1d9de0c93  push r9
000076c1d9de0c95  push r10
000076c1d9de0c97  push r11
000076c1d9de0c99  sub rsp, 0xF0
000076c1d9de0ca0  vmovaps [rsp], xmm0
000076c1d9de0ca5  vmovaps [rsp+0x10], xmm1
000076c1d9de0cab  vmovaps [rsp+0x20], xmm2
000076c1d9de0cb1  vmovaps [rsp+0x30], xmm3
000076c1d9de0cb7  vmovaps [rsp+0x40], xmm4
000076c1d9de0cbd  vmovaps [rsp+0x50], xmm5
000076c1d9de0cc3  vmovaps [rsp+0x60], xmm6
000076c1d9de0cc9  vmovaps [rsp+0x70], xmm7
000076c1d9de0ccf  vmovaps [rsp+0x80], xmm8
000076c1d9de0cd8  vmovaps [rsp+0x90], xmm9
000076c1d9de0ce1  vmovaps [rsp+0xA0], xmm11
000076c1d9de0cea  vmovaps [rsp+0xB0], xmm12
000076c1d9de0cf3  vmovaps [rsp+0xC0], xmm13
000076c1d9de0cfc  vmovaps [rsp+0xD0], xmm14
000076c1d9de0d05  vmovaps [rsp+0xE0], xmm15
000076c1d9de0d0e  sub rsp, 0x30
000076c1d9de0d12  movaps [rsp], xmm10
000076c1d9de0d17  movaps [rsp+0x10], xmm1
000076c1d9de0d1c  movaps [rsp+0x20], xmm12
000076c1d9de0d22  lea rdi, [rsp]
000076c1d9de0d26  mov esi, 0x00
000076c1d9de0d2b  mov rax, 0x5EA58B9E0530
000076c1d9de0d35  call rax
000076c1d9de0d37  movaps xmm10, [rsp]
000076c1d9de0d3c  add rsp, 0x30
000076c1d9de0d40  vmovaps xmm0, [rsp]
000076c1d9de0d45  vmovaps xmm1, [rsp+0x10]
000076c1d9de0d4b  vmovaps xmm2, [rsp+0x20]
000076c1d9de0d51  vmovaps xmm3, [rsp+0x30]
000076c1d9de0d57  vmovaps xmm4, [rsp+0x40]
000076c1d9de0d5d  vmovaps xmm5, [rsp+0x50]
000076c1d9de0d63  vmovaps xmm6, [rsp+0x60]
000076c1d9de0d69  vmovaps xmm7, [rsp+0x70]
000076c1d9de0d6f  vmovaps xmm8, [rsp+0x80]
000076c1d9de0d78  vmovaps xmm9, [rsp+0x90]
000076c1d9de0d81  vmovaps xmm11, [rsp+0xA0]
000076c1d9de0d8a  vmovaps xmm12, [rsp+0xB0]
000076c1d9de0d93  vmovaps xmm13, [rsp+0xC0]
000076c1d9de0d9c  vmovaps xmm14, [rsp+0xD0]
000076c1d9de0da5  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0dae  add rsp, 0xF0
000076c1d9de0db5  pop r11
000076c1d9de0db7  pop r10
000076c1d9de0db9  pop r9
000076c1d9de0dbb  pop r8
000076c1d9de0dbd  pop rsi
000076c1d9de0dbe  pop rdi
000076c1d9de0dbf  pop rdx
000076c1d9de0dc0  pop rcx
000076c1d9de0dc1  pop rax
000076c1d9de0dc2  add rsp, 0x08
000076c1d9de0dc6  jmp 0x000076C1D9DDC6CD
000076c1d9de0dcb  sub rsp, 0x08
000076c1d9de0dcf  push rax
000076c1d9de0dd0  push rcx
000076c1d9de0dd1  push rdx
000076c1d9de0dd2  push rdi
000076c1d9de0dd3  push rsi
000076c1d9de0dd4  push r8
000076c1d9de0dd6  push r9
000076c1d9de0dd8  push r10
000076c1d9de0dda  push r11
000076c1d9de0ddc  sub rsp, 0xF0
000076c1d9de0de3  vmovaps [rsp], xmm0
000076c1d9de0de8  vmovaps [rsp+0x10], xmm1
000076c1d9de0dee  vmovaps [rsp+0x20], xmm2
000076c1d9de0df4  vmovaps [rsp+0x30], xmm3
000076c1d9de0dfa  vmovaps [rsp+0x40], xmm4
000076c1d9de0e00  vmovaps [rsp+0x50], xmm5
000076c1d9de0e06  vmovaps [rsp+0x60], xmm6
000076c1d9de0e0c  vmovaps [rsp+0x70], xmm7
000076c1d9de0e12  vmovaps [rsp+0x80], xmm8
000076c1d9de0e1b  vmovaps [rsp+0x90], xmm9
000076c1d9de0e24  vmovaps [rsp+0xA0], xmm10
000076c1d9de0e2d  vmovaps [rsp+0xB0], xmm11
000076c1d9de0e36  vmovaps [rsp+0xC0], xmm13
000076c1d9de0e3f  vmovaps [rsp+0xD0], xmm14
000076c1d9de0e48  vmovaps [rsp+0xE0], xmm15
000076c1d9de0e51  sub rsp, 0x30
000076c1d9de0e55  movaps [rsp], xmm12
000076c1d9de0e5a  movaps [rsp+0x10], xmm14
000076c1d9de0e60  movaps [rsp+0x20], xmm1
000076c1d9de0e65  lea rdi, [rsp]
000076c1d9de0e69  mov esi, 0x00
000076c1d9de0e6e  mov rax, 0x5EA58B9E0530
000076c1d9de0e78  call rax
000076c1d9de0e7a  movaps xmm12, [rsp]
000076c1d9de0e7f  add rsp, 0x30
000076c1d9de0e83  vmovaps xmm0, [rsp]
000076c1d9de0e88  vmovaps xmm1, [rsp+0x10]
000076c1d9de0e8e  vmovaps xmm2, [rsp+0x20]
000076c1d9de0e94  vmovaps xmm3, [rsp+0x30]
000076c1d9de0e9a  vmovaps xmm4, [rsp+0x40]
000076c1d9de0ea0  vmovaps xmm5, [rsp+0x50]
000076c1d9de0ea6  vmovaps xmm6, [rsp+0x60]
000076c1d9de0eac  vmovaps xmm7, [rsp+0x70]
000076c1d9de0eb2  vmovaps xmm8, [rsp+0x80]
000076c1d9de0ebb  vmovaps xmm9, [rsp+0x90]
000076c1d9de0ec4  vmovaps xmm10, [rsp+0xA0]
000076c1d9de0ecd  vmovaps xmm11, [rsp+0xB0]
000076c1d9de0ed6  vmovaps xmm13, [rsp+0xC0]
000076c1d9de0edf  vmovaps xmm14, [rsp+0xD0]
000076c1d9de0ee8  vmovaps xmm15, [rsp+0xE0]
000076c1d9de0ef1  add rsp, 0xF0
000076c1d9de0ef8  pop r11
000076c1d9de0efa  pop r10
000076c1d9de0efc  pop r9
000076c1d9de0efe  pop r8
000076c1d9de0f00  pop rsi
000076c1d9de0f01  pop rdi
000076c1d9de0f02  pop rdx
000076c1d9de0f03  pop rcx
000076c1d9de0f04  pop rax
000076c1d9de0f05  add rsp, 0x08
000076c1d9de0f09  jmp 0x000076C1D9DDC6FC
000076c1d9de0f0e  sub rsp, 0x08
000076c1d9de0f12  push rax
000076c1d9de0f13  push rcx
000076c1d9de0f14  push rdx
000076c1d9de0f15  push rdi
000076c1d9de0f16  push rsi
000076c1d9de0f17  push r8
000076c1d9de0f19  push r9
000076c1d9de0f1b  push r10
000076c1d9de0f1d  push r11
000076c1d9de0f1f  sub rsp, 0xF0
000076c1d9de0f26  vmovaps [rsp], xmm0
000076c1d9de0f2b  vmovaps [rsp+0x10], xmm1
000076c1d9de0f31  vmovaps [rsp+0x20], xmm2
000076c1d9de0f37  vmovaps [rsp+0x30], xmm3
000076c1d9de0f3d  vmovaps [rsp+0x40], xmm4
000076c1d9de0f43  vmovaps [rsp+0x50], xmm5
000076c1d9de0f49  vmovaps [rsp+0x60], xmm6
000076c1d9de0f4f  vmovaps [rsp+0x70], xmm7
000076c1d9de0f55  vmovaps [rsp+0x80], xmm8
000076c1d9de0f5e  vmovaps [rsp+0x90], xmm9
000076c1d9de0f67  vmovaps [rsp+0xA0], xmm10
000076c1d9de0f70  vmovaps [rsp+0xB0], xmm11
000076c1d9de0f79  vmovaps [rsp+0xC0], xmm12
000076c1d9de0f82  vmovaps [rsp+0xD0], xmm13
000076c1d9de0f8b  vmovaps [rsp+0xE0], xmm15
000076c1d9de0f94  sub rsp, 0x30
000076c1d9de0f98  movaps [rsp], xmm14
000076c1d9de0f9d  movaps [rsp+0x10], xmm9
000076c1d9de0fa3  movaps [rsp+0x20], xmm1
000076c1d9de0fa8  lea rdi, [rsp]
000076c1d9de0fac  mov esi, 0x00
000076c1d9de0fb1  mov rax, 0x5EA58B9E0530
000076c1d9de0fbb  call rax
000076c1d9de0fbd  movaps xmm14, [rsp]
000076c1d9de0fc2  add rsp, 0x30
000076c1d9de0fc6  vmovaps xmm0, [rsp]
000076c1d9de0fcb  vmovaps xmm1, [rsp+0x10]
000076c1d9de0fd1  vmovaps xmm2, [rsp+0x20]
000076c1d9de0fd7  vmovaps xmm3, [rsp+0x30]
000076c1d9de0fdd  vmovaps xmm4, [rsp+0x40]
000076c1d9de0fe3  vmovaps xmm5, [rsp+0x50]
000076c1d9de0fe9  vmovaps xmm6, [rsp+0x60]
000076c1d9de0fef  vmovaps xmm7, [rsp+0x70]
000076c1d9de0ff5  vmovaps xmm8, [rsp+0x80]
000076c1d9de0ffe  vmovaps xmm9, [rsp+0x90]
000076c1d9de1007  vmovaps xmm10, [rsp+0xA0]
000076c1d9de1010  vmovaps xmm11, [rsp+0xB0]
000076c1d9de1019  vmovaps xmm12, [rsp+0xC0]
000076c1d9de1022  vmovaps xmm13, [rsp+0xD0]
000076c1d9de102b  vmovaps xmm15, [rsp+0xE0]
000076c1d9de1034  add rsp, 0xF0
000076c1d9de103b  pop r11
000076c1d9de103d  pop r10
000076c1d9de103f  pop r9
000076c1d9de1041  pop r8
000076c1d9de1043  pop rsi
000076c1d9de1044  pop rdi
000076c1d9de1045  pop rdx
000076c1d9de1046  pop rcx
000076c1d9de1047  pop rax
000076c1d9de1048  add rsp, 0x08
000076c1d9de104c  jmp 0x000076C1D9DDC72B
000076c1d9de1051  sub rsp, 0x08
000076c1d9de1055  push rax
000076c1d9de1056  push rcx
000076c1d9de1057  push rdx
000076c1d9de1058  push rdi
000076c1d9de1059  push rsi
000076c1d9de105a  push r8
000076c1d9de105c  push r9
000076c1d9de105e  push r10
000076c1d9de1060  push r11
000076c1d9de1062  sub rsp, 0xF0
000076c1d9de1069  vmovaps [rsp], xmm0
000076c1d9de106e  vmovaps [rsp+0x10], xmm2
000076c1d9de1074  vmovaps [rsp+0x20], xmm3
000076c1d9de107a  vmovaps [rsp+0x30], xmm4
000076c1d9de1080  vmovaps [rsp+0x40], xmm5
000076c1d9de1086  vmovaps [rsp+0x50], xmm6
000076c1d9de108c  vmovaps [rsp+0x60], xmm7
000076c1d9de1092  vmovaps [rsp+0x70], xmm8
000076c1d9de1098  vmovaps [rsp+0x80], xmm9
000076c1d9de10a1  vmovaps [rsp+0x90], xmm10
000076c1d9de10aa  vmovaps [rsp+0xA0], xmm11
000076c1d9de10b3  vmovaps [rsp+0xB0], xmm12
000076c1d9de10bc  vmovaps [rsp+0xC0], xmm13
000076c1d9de10c5  vmovaps [rsp+0xD0], xmm14
000076c1d9de10ce  vmovaps [rsp+0xE0], xmm15
000076c1d9de10d7  sub rsp, 0x30
000076c1d9de10db  movaps [rsp], xmm1
000076c1d9de10df  movaps [rsp+0x10], xmm13
000076c1d9de10e5  movaps [rsp+0x20], xmm8
000076c1d9de10eb  lea rdi, [rsp]
000076c1d9de10ef  mov esi, 0x00
000076c1d9de10f4  mov rax, 0x5EA58B9E0530
000076c1d9de10fe  call rax
000076c1d9de1100  movaps xmm1, [rsp]
000076c1d9de1104  add rsp, 0x30
000076c1d9de1108  vmovaps xmm0, [rsp]
000076c1d9de110d  vmovaps xmm2, [rsp+0x10]
000076c1d9de1113  vmovaps xmm3, [rsp+0x20]
000076c1d9de1119  vmovaps xmm4, [rsp+0x30]
000076c1d9de111f  vmovaps xmm5, [rsp+0x40]
000076c1d9de1125  vmovaps xmm6, [rsp+0x50]
000076c1d9de112b  vmovaps xmm7, [rsp+0x60]
000076c1d9de1131  vmovaps xmm8, [rsp+0x70]
000076c1d9de1137  vmovaps xmm9, [rsp+0x80]
000076c1d9de1140  vmovaps xmm10, [rsp+0x90]
000076c1d9de1149  vmovaps xmm11, [rsp+0xA0]
000076c1d9de1152  vmovaps xmm12, [rsp+0xB0]
000076c1d9de115b  vmovaps xmm13, [rsp+0xC0]
000076c1d9de1164  vmovaps xmm14, [rsp+0xD0]
000076c1d9de116d  vmovaps xmm15, [rsp+0xE0]
000076c1d9de1176  add rsp, 0xF0
000076c1d9de117d  pop r11
000076c1d9de117f  pop r10
000076c1d9de1181  pop r9
000076c1d9de1183  pop r8
000076c1d9de1185  pop rsi
000076c1d9de1186  pop rdi
000076c1d9de1187  pop rdx
000076c1d9de1188  pop rcx
000076c1d9de1189  pop rax
000076c1d9de118a  add rsp, 0x08
000076c1d9de118e  jmp 0x000076C1D9DDC74D
000076c1d9de1193  call 0x000076C1D9C0C260
000076c1d9de1198  jmp 0x000076C1D9DDC75B
000076c1d9de119d  call 0x000076C1D9CBD750
000076c1d9de11a2  jmp 0x000076C1D9DDC765
000076c1d9de11a7  sub rsp, 0x08
000076c1d9de11ab  push rax
000076c1d9de11ac  push rcx
000076c1d9de11ad  push rdx
000076c1d9de11ae  push rdi
000076c1d9de11af  push rsi
000076c1d9de11b0  push r8
000076c1d9de11b2  push r9
000076c1d9de11b4  push r10
000076c1d9de11b6  push r11
000076c1d9de11b8  sub rsp, 0xF0
000076c1d9de11bf  vmovaps [rsp], xmm0
000076c1d9de11c4  vmovaps [rsp+0x10], xmm1
000076c1d9de11ca  vmovaps [rsp+0x20], xmm2
000076c1d9de11d0  vmovaps [rsp+0x30], xmm3
000076c1d9de11d6  vmovaps [rsp+0x40], xmm4
000076c1d9de11dc  vmovaps [rsp+0x50], xmm5
000076c1d9de11e2  vmovaps [rsp+0x60], xmm6
000076c1d9de11e8  vmovaps [rsp+0x70], xmm7
000076c1d9de11ee  vmovaps [rsp+0x80], xmm9
000076c1d9de11f7  vmovaps [rsp+0x90], xmm10
000076c1d9de1200  vmovaps [rsp+0xA0], xmm11
000076c1d9de1209  vmovaps [rsp+0xB0], xmm12
000076c1d9de1212  vmovaps [rsp+0xC0], xmm13
000076c1d9de121b  vmovaps [rsp+0xD0], xmm14
000076c1d9de1224  vmovaps [rsp+0xE0], xmm15
000076c1d9de122d  sub rsp, 0x30
000076c1d9de1231  movaps [rsp], xmm8
000076c1d9de1236  movaps [rsp+0x10], xmm15
000076c1d9de123c  movaps [rsp+0x20], xmm7
000076c1d9de1241  lea rdi, [rsp]
000076c1d9de1245  mov esi, 0x00
000076c1d9de124a  mov rax, 0x5EA58B9E0530
000076c1d9de1254  call rax
000076c1d9de1256  movaps xmm8, [rsp]
000076c1d9de125b  add rsp, 0x30
000076c1d9de125f  vmovaps xmm0, [rsp]
000076c1d9de1264  vmovaps xmm1, [rsp+0x10]
000076c1d9de126a  vmovaps xmm2, [rsp+0x20]
000076c1d9de1270  vmovaps xmm3, [rsp+0x30]
000076c1d9de1276  vmovaps xmm4, [rsp+0x40]
000076c1d9de127c  vmovaps xmm5, [rsp+0x50]
000076c1d9de1282  vmovaps xmm6, [rsp+0x60]
000076c1d9de1288  vmovaps xmm7, [rsp+0x70]
000076c1d9de128e  vmovaps xmm9, [rsp+0x80]
000076c1d9de1297  vmovaps xmm10, [rsp+0x90]
000076c1d9de12a0  vmovaps xmm11, [rsp+0xA0]
000076c1d9de12a9  vmovaps xmm12, [rsp+0xB0]
000076c1d9de12b2  vmovaps xmm13, [rsp+0xC0]
000076c1d9de12bb  vmovaps xmm14, [rsp+0xD0]
000076c1d9de12c4  vmovaps xmm15, [rsp+0xE0]
000076c1d9de12cd  add rsp, 0xF0
000076c1d9de12d4  pop r11
000076c1d9de12d6  pop r10
000076c1d9de12d8  pop r9
000076c1d9de12da  pop r8
000076c1d9de12dc  pop rsi
000076c1d9de12dd  pop rdi
000076c1d9de12de  pop rdx
000076c1d9de12df  pop rcx
000076c1d9de12e0  pop rax
000076c1d9de12e1  add rsp, 0x08
000076c1d9de12e5  jmp 0x000076C1D9DDC787
000076c1d9de12ea  sub rsp, 0x08
000076c1d9de12ee  push rax
000076c1d9de12ef  push rcx
000076c1d9de12f0  push rdx
000076c1d9de12f1  push rdi
000076c1d9de12f2  push rsi
000076c1d9de12f3  push r8
000076c1d9de12f5  push r9
000076c1d9de12f7  push r10
000076c1d9de12f9  push r11
000076c1d9de12fb  sub rsp, 0xF0
000076c1d9de1302  vmovaps [rsp], xmm0
000076c1d9de1307  vmovaps [rsp+0x10], xmm1
000076c1d9de130d  vmovaps [rsp+0x20], xmm2
000076c1d9de1313  vmovaps [rsp+0x30], xmm3
000076c1d9de1319  vmovaps [rsp+0x40], xmm4
000076c1d9de131f  vmovaps [rsp+0x50], xmm5
000076c1d9de1325  vmovaps [rsp+0x60], xmm6
000076c1d9de132b  vmovaps [rsp+0x70], xmm8
000076c1d9de1331  vmovaps [rsp+0x80], xmm9
000076c1d9de133a  vmovaps [rsp+0x90], xmm10
000076c1d9de1343  vmovaps [rsp+0xA0], xmm11
000076c1d9de134c  vmovaps [rsp+0xB0], xmm12
000076c1d9de1355  vmovaps [rsp+0xC0], xmm13
000076c1d9de135e  vmovaps [rsp+0xD0], xmm14
000076c1d9de1367  vmovaps [rsp+0xE0], xmm15
000076c1d9de1370  sub rsp, 0x30
000076c1d9de1374  movaps [rsp], xmm7
000076c1d9de1378  movaps [rsp+0x10], xmm9
000076c1d9de137e  movaps [rsp+0x20], xmm15
000076c1d9de1384  lea rdi, [rsp]
000076c1d9de1388  mov esi, 0x00
000076c1d9de138d  mov rax, 0x5EA58B9E0530
000076c1d9de1397  call rax
000076c1d9de1399  movaps xmm7, [rsp]
000076c1d9de139d  add rsp, 0x30
000076c1d9de13a1  vmovaps xmm0, [rsp]
000076c1d9de13a6  vmovaps xmm1, [rsp+0x10]
000076c1d9de13ac  vmovaps xmm2, [rsp+0x20]
000076c1d9de13b2  vmovaps xmm3, [rsp+0x30]
000076c1d9de13b8  vmovaps xmm4, [rsp+0x40]
000076c1d9de13be  vmovaps xmm5, [rsp+0x50]
000076c1d9de13c4  vmovaps xmm6, [rsp+0x60]
000076c1d9de13ca  vmovaps xmm8, [rsp+0x70]
000076c1d9de13d0  vmovaps xmm9, [rsp+0x80]
000076c1d9de13d9  vmovaps xmm10, [rsp+0x90]
000076c1d9de13e2  vmovaps xmm11, [rsp+0xA0]
000076c1d9de13eb  vmovaps xmm12, [rsp+0xB0]
000076c1d9de13f4  vmovaps xmm13, [rsp+0xC0]
000076c1d9de13fd  vmovaps xmm14, [rsp+0xD0]
000076c1d9de1406  vmovaps xmm15, [rsp+0xE0]
000076c1d9de140f  add rsp, 0xF0
000076c1d9de1416  pop r11
000076c1d9de1418  pop r10
000076c1d9de141a  pop r9
000076c1d9de141c  pop r8
000076c1d9de141e  pop rsi
000076c1d9de141f  pop rdi
000076c1d9de1420  pop rdx
000076c1d9de1421  pop rcx
000076c1d9de1422  pop rax
000076c1d9de1423  add rsp, 0x08
000076c1d9de1427  jmp 0x000076C1D9DDC7B4
000076c1d9de142c  sub rsp, 0x08
000076c1d9de1430  push rax
000076c1d9de1431  push rcx
000076c1d9de1432  push rdx
000076c1d9de1433  push rdi
000076c1d9de1434  push rsi
000076c1d9de1435  push r8
000076c1d9de1437  push r9
000076c1d9de1439  push r10
000076c1d9de143b  push r11
000076c1d9de143d  sub rsp, 0xF0
000076c1d9de1444  vmovaps [rsp], xmm0
000076c1d9de1449  vmovaps [rsp+0x10], xmm1
000076c1d9de144f  vmovaps [rsp+0x20], xmm2
000076c1d9de1455  vmovaps [rsp+0x30], xmm3
000076c1d9de145b  vmovaps [rsp+0x40], xmm4
000076c1d9de1461  vmovaps [rsp+0x50], xmm5
000076c1d9de1467  vmovaps [rsp+0x60], xmm6
000076c1d9de146d  vmovaps [rsp+0x70], xmm7
000076c1d9de1473  vmovaps [rsp+0x80], xmm8
000076c1d9de147c  vmovaps [rsp+0x90], xmm10
000076c1d9de1485  vmovaps [rsp+0xA0], xmm11
000076c1d9de148e  vmovaps [rsp+0xB0], xmm12
000076c1d9de1497  vmovaps [rsp+0xC0], xmm13
000076c1d9de14a0  vmovaps [rsp+0xD0], xmm14
000076c1d9de14a9  vmovaps [rsp+0xE0], xmm15
000076c1d9de14b2  sub rsp, 0x30
000076c1d9de14b6  movaps [rsp], xmm9
000076c1d9de14bb  movaps [rsp+0x10], xmm13
000076c1d9de14c1  movaps [rsp+0x20], xmm15
000076c1d9de14c7  lea rdi, [rsp]
000076c1d9de14cb  mov esi, 0x00
000076c1d9de14d0  mov rax, 0x5EA58B9E0530
000076c1d9de14da  call rax
000076c1d9de14dc  movaps xmm9, [rsp]
000076c1d9de14e1  add rsp, 0x30
000076c1d9de14e5  vmovaps xmm0, [rsp]
000076c1d9de14ea  vmovaps xmm1, [rsp+0x10]
000076c1d9de14f0  vmovaps xmm2, [rsp+0x20]
000076c1d9de14f6  vmovaps xmm3, [rsp+0x30]
000076c1d9de14fc  vmovaps xmm4, [rsp+0x40]
000076c1d9de1502  vmovaps xmm5, [rsp+0x50]
000076c1d9de1508  vmovaps xmm6, [rsp+0x60]
000076c1d9de150e  vmovaps xmm7, [rsp+0x70]
000076c1d9de1514  vmovaps xmm8, [rsp+0x80]
000076c1d9de151d  vmovaps xmm10, [rsp+0x90]
000076c1d9de1526  vmovaps xmm11, [rsp+0xA0]
000076c1d9de152f  vmovaps xmm12, [rsp+0xB0]
000076c1d9de1538  vmovaps xmm13, [rsp+0xC0]
000076c1d9de1541  vmovaps xmm14, [rsp+0xD0]
000076c1d9de154a  vmovaps xmm15, [rsp+0xE0]
000076c1d9de1553  add rsp, 0xF0
000076c1d9de155a  pop r11
000076c1d9de155c  pop r10
000076c1d9de155e  pop r9
000076c1d9de1560  pop r8
000076c1d9de1562  pop rsi
000076c1d9de1563  pop rdi
000076c1d9de1564  pop rdx
000076c1d9de1565  pop rcx
000076c1d9de1566  pop rax
000076c1d9de1567  add rsp, 0x08
000076c1d9de156b  jmp 0x000076C1D9DDC7E2
000076c1d9de1570  sub rsp, 0x08
000076c1d9de1574  push rax
000076c1d9de1575  push rcx
000076c1d9de1576  push rdx
000076c1d9de1577  push rdi
000076c1d9de1578  push rsi
000076c1d9de1579  push r8
000076c1d9de157b  push r9
000076c1d9de157d  push r10
000076c1d9de157f  push r11
000076c1d9de1581  sub rsp, 0xF0
000076c1d9de1588  vmovaps [rsp], xmm0
000076c1d9de158d  vmovaps [rsp+0x10], xmm1
000076c1d9de1593  vmovaps [rsp+0x20], xmm2
000076c1d9de1599  vmovaps [rsp+0x30], xmm3
000076c1d9de159f  vmovaps [rsp+0x40], xmm4
000076c1d9de15a5  vmovaps [rsp+0x50], xmm5
000076c1d9de15ab  vmovaps [rsp+0x60], xmm6
000076c1d9de15b1  vmovaps [rsp+0x70], xmm7
000076c1d9de15b7  vmovaps [rsp+0x80], xmm8
000076c1d9de15c0  vmovaps [rsp+0x90], xmm9
000076c1d9de15c9  vmovaps [rsp+0xA0], xmm10
000076c1d9de15d2  vmovaps [rsp+0xB0], xmm11
000076c1d9de15db  vmovaps [rsp+0xC0], xmm12
000076c1d9de15e4  vmovaps [rsp+0xD0], xmm13
000076c1d9de15ed  vmovaps [rsp+0xE0], xmm14
000076c1d9de15f6  sub rsp, 0x30
000076c1d9de15fa  movaps [rsp], xmm15
000076c1d9de15ff  movaps [rsp+0x10], xmm11
000076c1d9de1605  movaps [rsp+0x20], xmm12
000076c1d9de160b  lea rdi, [rsp]
000076c1d9de160f  mov esi, 0x00
000076c1d9de1614  mov rax, 0x5EA58B9E0530
000076c1d9de161e  call rax
000076c1d9de1620  movaps xmm15, [rsp]
000076c1d9de1625  add rsp, 0x30
000076c1d9de1629  vmovaps xmm0, [rsp]
000076c1d9de162e  vmovaps xmm1, [rsp+0x10]
000076c1d9de1634  vmovaps xmm2, [rsp+0x20]
000076c1d9de163a  vmovaps xmm3, [rsp+0x30]
000076c1d9de1640  vmovaps xmm4, [rsp+0x40]
000076c1d9de1646  vmovaps xmm5, [rsp+0x50]
000076c1d9de164c  vmovaps xmm6, [rsp+0x60]
000076c1d9de1652  vmovaps xmm7, [rsp+0x70]
000076c1d9de1658  vmovaps xmm8, [rsp+0x80]
000076c1d9de1661  vmovaps xmm9, [rsp+0x90]
000076c1d9de166a  vmovaps xmm10, [rsp+0xA0]
000076c1d9de1673  vmovaps xmm11, [rsp+0xB0]
000076c1d9de167c  vmovaps xmm12, [rsp+0xC0]
000076c1d9de1685  vmovaps xmm13, [rsp+0xD0]
000076c1d9de168e  vmovaps xmm14, [rsp+0xE0]
000076c1d9de1697  add rsp, 0xF0
000076c1d9de169e  pop r11
000076c1d9de16a0  pop r10
000076c1d9de16a2  pop r9
000076c1d9de16a4  pop r8
000076c1d9de16a6  pop rsi
000076c1d9de16a7  pop rdi
000076c1d9de16a8  pop rdx
000076c1d9de16a9  pop rcx
000076c1d9de16aa  pop rax
000076c1d9de16ab  add rsp, 0x08
000076c1d9de16af  jmp 0x000076C1D9DDC7FD
000076c1d9de16b4  sub rsp, 0x08
000076c1d9de16b8  push rax
000076c1d9de16b9  push rcx
000076c1d9de16ba  push rdx
000076c1d9de16bb  push rdi
000076c1d9de16bc  push rsi
000076c1d9de16bd  push r8
000076c1d9de16bf  push r9
000076c1d9de16c1  push r10
000076c1d9de16c3  push r11
000076c1d9de16c5  sub rsp, 0xF0
000076c1d9de16cc  vmovaps [rsp], xmm0
000076c1d9de16d1  vmovaps [rsp+0x10], xmm1
000076c1d9de16d7  vmovaps [rsp+0x20], xmm2
000076c1d9de16dd  vmovaps [rsp+0x30], xmm3
000076c1d9de16e3  vmovaps [rsp+0x40], xmm4
000076c1d9de16e9  vmovaps [rsp+0x50], xmm5
000076c1d9de16ef  vmovaps [rsp+0x60], xmm6
000076c1d9de16f5  vmovaps [rsp+0x70], xmm7
000076c1d9de16fb  vmovaps [rsp+0x80], xmm8
000076c1d9de1704  vmovaps [rsp+0x90], xmm9
000076c1d9de170d  vmovaps [rsp+0xA0], xmm10
000076c1d9de1716  vmovaps [rsp+0xB0], xmm11
000076c1d9de171f  vmovaps [rsp+0xC0], xmm12
000076c1d9de1728  vmovaps [rsp+0xD0], xmm14
000076c1d9de1731  vmovaps [rsp+0xE0], xmm15
000076c1d9de173a  sub rsp, 0x30
000076c1d9de173e  movaps [rsp], xmm13
000076c1d9de1743  movaps [rsp+0x10], xmm10
000076c1d9de1749  movaps [rsp+0x20], xmm14
000076c1d9de174f  lea rdi, [rsp]
000076c1d9de1753  mov esi, 0x00
000076c1d9de1758  mov rax, 0x5EA58B9E0530
000076c1d9de1762  call rax
000076c1d9de1764  movaps xmm13, [rsp]
000076c1d9de1769  add rsp, 0x30
000076c1d9de176d  vmovaps xmm0, [rsp]
000076c1d9de1772  vmovaps xmm1, [rsp+0x10]
000076c1d9de1778  vmovaps xmm2, [rsp+0x20]
000076c1d9de177e  vmovaps xmm3, [rsp+0x30]
000076c1d9de1784  vmovaps xmm4, [rsp+0x40]
000076c1d9de178a  vmovaps xmm5, [rsp+0x50]
000076c1d9de1790  vmovaps xmm6, [rsp+0x60]
000076c1d9de1796  vmovaps xmm7, [rsp+0x70]
000076c1d9de179c  vmovaps xmm8, [rsp+0x80]
000076c1d9de17a5  vmovaps xmm9, [rsp+0x90]
000076c1d9de17ae  vmovaps xmm10, [rsp+0xA0]
000076c1d9de17b7  vmovaps xmm11, [rsp+0xB0]
000076c1d9de17c0  vmovaps xmm12, [rsp+0xC0]
000076c1d9de17c9  vmovaps xmm14, [rsp+0xD0]
000076c1d9de17d2  vmovaps xmm15, [rsp+0xE0]
000076c1d9de17db  add rsp, 0xF0
000076c1d9de17e2  pop r11
000076c1d9de17e4  pop r10
000076c1d9de17e6  pop r9
000076c1d9de17e8  pop r8
000076c1d9de17ea  pop rsi
000076c1d9de17eb  pop rdi
000076c1d9de17ec  pop rdx
000076c1d9de17ed  pop rcx
000076c1d9de17ee  pop rax
000076c1d9de17ef  add rsp, 0x08
000076c1d9de17f3  jmp 0x000076C1D9DDC820
000076c1d9de17f8  sub rsp, 0x08
000076c1d9de17fc  push rax
000076c1d9de17fd  push rcx
000076c1d9de17fe  push rdx
000076c1d9de17ff  push rdi
000076c1d9de1800  push rsi
000076c1d9de1801  push r8
000076c1d9de1803  push r9
000076c1d9de1805  push r10
000076c1d9de1807  push r11
000076c1d9de1809  sub rsp, 0xF0
000076c1d9de1810  vmovaps [rsp], xmm0
000076c1d9de1815  vmovaps [rsp+0x10], xmm1
000076c1d9de181b  vmovaps [rsp+0x20], xmm2
000076c1d9de1821  vmovaps [rsp+0x30], xmm3
000076c1d9de1827  vmovaps [rsp+0x40], xmm4
000076c1d9de182d  vmovaps [rsp+0x50], xmm5
000076c1d9de1833  vmovaps [rsp+0x60], xmm6
000076c1d9de1839  vmovaps [rsp+0x70], xmm7
000076c1d9de183f  vmovaps [rsp+0x80], xmm8
000076c1d9de1848  vmovaps [rsp+0x90], xmm9
000076c1d9de1851  vmovaps [rsp+0xA0], xmm10
000076c1d9de185a  vmovaps [rsp+0xB0], xmm11
000076c1d9de1863  vmovaps [rsp+0xC0], xmm12
000076c1d9de186c  vmovaps [rsp+0xD0], xmm13
000076c1d9de1875  vmovaps [rsp+0xE0], xmm15
000076c1d9de187e  sub rsp, 0x30
000076c1d9de1882  movaps [rsp], xmm14
000076c1d9de1887  movaps [rsp+0x10], xmm1
000076c1d9de188c  movaps [rsp+0x20], xmm7
000076c1d9de1891  lea rdi, [rsp]
000076c1d9de1895  mov esi, 0x00
000076c1d9de189a  mov rax, 0x5EA58B9E0530
000076c1d9de18a4  call rax
000076c1d9de18a6  movaps xmm14, [rsp]
000076c1d9de18ab  add rsp, 0x30
000076c1d9de18af  vmovaps xmm0, [rsp]
000076c1d9de18b4  vmovaps xmm1, [rsp+0x10]
000076c1d9de18ba  vmovaps xmm2, [rsp+0x20]
000076c1d9de18c0  vmovaps xmm3, [rsp+0x30]
000076c1d9de18c6  vmovaps xmm4, [rsp+0x40]
000076c1d9de18cc  vmovaps xmm5, [rsp+0x50]
000076c1d9de18d2  vmovaps xmm6, [rsp+0x60]
000076c1d9de18d8  vmovaps xmm7, [rsp+0x70]
000076c1d9de18de  vmovaps xmm8, [rsp+0x80]
000076c1d9de18e7  vmovaps xmm9, [rsp+0x90]
000076c1d9de18f0  vmovaps xmm10, [rsp+0xA0]
000076c1d9de18f9  vmovaps xmm11, [rsp+0xB0]
000076c1d9de1902  vmovaps xmm12, [rsp+0xC0]
000076c1d9de190b  vmovaps xmm13, [rsp+0xD0]
000076c1d9de1914  vmovaps xmm15, [rsp+0xE0]
000076c1d9de191d  add rsp, 0xF0
000076c1d9de1924  pop r11
000076c1d9de1926  pop r10
000076c1d9de1928  pop r9
000076c1d9de192a  pop r8
000076c1d9de192c  pop rsi
000076c1d9de192d  pop rdi
000076c1d9de192e  pop rdx
000076c1d9de192f  pop rcx
000076c1d9de1930  pop rax
000076c1d9de1931  add rsp, 0x08
000076c1d9de1935  jmp 0x000076C1D9DDC843
000076c1d9de193a  sub rsp, 0x08
000076c1d9de193e  push rax
000076c1d9de193f  push rcx
000076c1d9de1940  push rdx
000076c1d9de1941  push rdi
000076c1d9de1942  push rsi
000076c1d9de1943  push r8
000076c1d9de1945  push r9
000076c1d9de1947  push r10
000076c1d9de1949  push r11
000076c1d9de194b  sub rsp, 0xF0
000076c1d9de1952  vmovaps [rsp], xmm0
000076c1d9de1957  vmovaps [rsp+0x10], xmm2
000076c1d9de195d  vmovaps [rsp+0x20], xmm3
000076c1d9de1963  vmovaps [rsp+0x30], xmm4
000076c1d9de1969  vmovaps [rsp+0x40], xmm5
000076c1d9de196f  vmovaps [rsp+0x50], xmm6
000076c1d9de1975  vmovaps [rsp+0x60], xmm7
000076c1d9de197b  vmovaps [rsp+0x70], xmm8
000076c1d9de1981  vmovaps [rsp+0x80], xmm9
000076c1d9de198a  vmovaps [rsp+0x90], xmm10
000076c1d9de1993  vmovaps [rsp+0xA0], xmm11
000076c1d9de199c  vmovaps [rsp+0xB0], xmm12
000076c1d9de19a5  vmovaps [rsp+0xC0], xmm13
000076c1d9de19ae  vmovaps [rsp+0xD0], xmm14
000076c1d9de19b7  vmovaps [rsp+0xE0], xmm15
000076c1d9de19c0  sub rsp, 0x30
000076c1d9de19c4  movaps [rsp], xmm1
000076c1d9de19c8  movaps [rsp+0x10], xmm8
000076c1d9de19ce  movaps [rsp+0x20], xmm9
000076c1d9de19d4  lea rdi, [rsp]
000076c1d9de19d8  mov esi, 0x00
000076c1d9de19dd  mov rax, 0x5EA58B9E0530
000076c1d9de19e7  call rax
000076c1d9de19e9  movaps xmm1, [rsp]
000076c1d9de19ed  add rsp, 0x30
000076c1d9de19f1  vmovaps xmm0, [rsp]
000076c1d9de19f6  vmovaps xmm2, [rsp+0x10]
000076c1d9de19fc  vmovaps xmm3, [rsp+0x20]
000076c1d9de1a02  vmovaps xmm4, [rsp+0x30]
000076c1d9de1a08  vmovaps xmm5, [rsp+0x40]
000076c1d9de1a0e  vmovaps xmm6, [rsp+0x50]
000076c1d9de1a14  vmovaps xmm7, [rsp+0x60]
000076c1d9de1a1a  vmovaps xmm8, [rsp+0x70]
000076c1d9de1a20  vmovaps xmm9, [rsp+0x80]
000076c1d9de1a29  vmovaps xmm10, [rsp+0x90]
000076c1d9de1a32  vmovaps xmm11, [rsp+0xA0]
000076c1d9de1a3b  vmovaps xmm12, [rsp+0xB0]
000076c1d9de1a44  vmovaps xmm13, [rsp+0xC0]
000076c1d9de1a4d  vmovaps xmm14, [rsp+0xD0]
000076c1d9de1a56  vmovaps xmm15, [rsp+0xE0]
000076c1d9de1a5f  add rsp, 0xF0
000076c1d9de1a66  pop r11
000076c1d9de1a68  pop r10
000076c1d9de1a6a  pop r9
000076c1d9de1a6c  pop r8
000076c1d9de1a6e  pop rsi
000076c1d9de1a6f  pop rdi
000076c1d9de1a70  pop rdx
000076c1d9de1a71  pop rcx
000076c1d9de1a72  pop rax
000076c1d9de1a73  add rsp, 0x08
000076c1d9de1a77  jmp 0x000076C1D9DDC865
000076c1d9de1a7c  call 0x000076C1D9CE5940
000076c1d9de1a81  jmp 0x000076C1D9DDC873
000076c1d9de1a86  call 0x000076C1D9C0C380
000076c1d9de1a8b  jmp 0x000076C1D9DDC87D
000076c1d9de1a90  call 0x000076C1D9C0D600
000076c1d9de1a95  jmp 0x000076C1D9DDC887
000076c1d9de1a9a  call 0x000076C1D9BFF540
000076c1d9de1a9f  jmp 0x000076C1D9DDC891
000076c1d9de1aa4  int3
000076c1d9de1aa5  nop [rax+rax*1], ax
000076c1d9de1aae  nop
000076c1d9de1ab0  mov rax, [r15+0xF8]
000076c1d9de1ab7  lea r14, [rax+0x140]
000076c1d9de1abe  mov r12, [r13+r14*1]
000076c1d9de1ac3  mov [r15+0xE8], r12
000076c1d9de1aca  lea r14, [rax+0x130]
000076c1d9de1ad1  mov r12, [r13+r14*1]
000076c1d9de1ad6  lea r14, [rax+0x138]
000076c1d9de1add  mov r11, [r13+r14*1]
000076c1d9de1ae2  movq xmm1, r12
000076c1d9de1ae7  movq xmm15, r11
000076c1d9de1aec  movq xmm1, xmm1
000076c1d9de1af0  movq xmm1, xmm1
000076c1d9de1af4  movaps [r15+0x1A0], xmm1
000076c1d9de1afc  movq xmm15, xmm15
000076c1d9de1b01  movq xmm15, xmm15
000076c1d9de1b06  movaps [r15+0x190], xmm15
000076c1d9de1b0e  lea r14, [rax+0x120]
000076c1d9de1b15  mov r12, [r13+r14*1]
000076c1d9de1b1a  lea r14, [rax+0x128]
000076c1d9de1b21  mov r11, [r13+r14*1]
000076c1d9de1b26  movq xmm1, r12
000076c1d9de1b2b  movq xmm15, r11
000076c1d9de1b30  movq xmm1, xmm1
000076c1d9de1b34  movq xmm1, xmm1
000076c1d9de1b38  movaps [r15+0x1C0], xmm1
000076c1d9de1b40  movq xmm15, xmm15
000076c1d9de1b45  movq xmm15, xmm15
000076c1d9de1b4a  movaps [r15+0x1B0], xmm15
000076c1d9de1b52  lea r14, [rax+0x110]
000076c1d9de1b59  mov r12, [r13+r14*1]
000076c1d9de1b5e  lea r14, [rax+0x118]
000076c1d9de1b65  mov r11, [r13+r14*1]
000076c1d9de1b6a  movq xmm1, r12
000076c1d9de1b6f  movq xmm15, r11
000076c1d9de1b74  movq xmm1, xmm1
000076c1d9de1b78  movq xmm1, xmm1
000076c1d9de1b7c  movaps [r15+0x1E0], xmm1
000076c1d9de1b84  movq xmm15, xmm15
000076c1d9de1b89  movq xmm15, xmm15
000076c1d9de1b8e  movaps [r15+0x1D0], xmm15
000076c1d9de1b96  lea r14, [rax+0x100]
000076c1d9de1b9d  mov r12, [r13+r14*1]
000076c1d9de1ba2  lea r14, [rax+0x108]
000076c1d9de1ba9  mov r11, [r13+r14*1]
000076c1d9de1bae  movq xmm1, r12
000076c1d9de1bb3  movq xmm15, r11
000076c1d9de1bb8  movq xmm1, xmm1
000076c1d9de1bbc  movq xmm1, xmm1
000076c1d9de1bc0  movaps [r15+0x200], xmm1
000076c1d9de1bc8  movq xmm15, xmm15
000076c1d9de1bcd  movq xmm15, xmm15
000076c1d9de1bd2  movaps [r15+0x1F0], xmm15
000076c1d9de1bda  mov qword ptr [r15+0x40], 0x430000
000076c1d9de1be2  mov r14d, 0x430510
000076c1d9de1be8  mov r12, [r13+r14*1]
000076c1d9de1bed  movq xmm1, r12
000076c1d9de1bf2  lea r14, [rax+0x150]
000076c1d9de1bf9  mov [r15+0xF8], r14
000076c1d9de1c00  mov rax, [r15+0x50]
000076c1d9de1c04  movups xmm15, [r13+rax*1]
000076c1d9de1c0a  movaps [r15+0x120], xmm15
000076c1d9de1c12  mov qword ptr [r15+0x48], 0x10
000076c1d9de1c1a  xor eax, eax
000076c1d9de1c1c  mov r14d, 0x10
000076c1d9de1c22  mov r12d, 0x200
000076c1d9de1c28  cmp r14, r12
000076c1d9de1c2b  cmc
000076c1d9de1c2c  lahf
000076c1d9de1c2d  seto al
000076c1d9de1c30  mov [r15+0x108], eax
000076c1d9de1c37  pextrq rax, xmm15, 0x01
000076c1d9de1c3e  movq xmm14, rax
000076c1d9de1c43  movaps [r15+0x130], xmm14
000076c1d9de1c4b  movq rax, xmm1
000076c1d9de1c50  movq r14, xmm15
000076c1d9de1c55  vmovq xmm1, rax
000076c1d9de1c5a  vmovq xmm15, r14
000076c1d9de1c5f  movaps xmm13, xmm1
000076c1d9de1c63  addsd xmm13, xmm15
000076c1d9de1c68  ucomisd xmm13, xmm13
000076c1d9de1c6d  jp 0x000076C1D9DE1D86
000076c1d9de1c73  movq xmm13, xmm13
000076c1d9de1c78  movq rax, xmm13
000076c1d9de1c7d  movq r14, xmm14
000076c1d9de1c82  vmovq xmm1, rax
000076c1d9de1c87  vmovq xmm15, r14
000076c1d9de1c8c  movaps xmm14, xmm1
000076c1d9de1c90  addsd xmm14, xmm15
000076c1d9de1c95  ucomisd xmm14, xmm14
000076c1d9de1c9a  jp 0x000076C1D9DE1DCE
000076c1d9de1ca0  movq xmm14, xmm14
000076c1d9de1ca5  movaps [r15+0x110], xmm14
000076c1d9de1cad  mov eax, [r15+0x108]
000076c1d9de1cb4  sahf
000076c1d9de1cb5  jnz 0x000076C1D9DE1CE7
000076c1d9de1cb7  cmp dword ptr [r15+0x318], 0x00
000076c1d9de1cbf  jz 0x000076C1D9DE1FE0
000076c1d9de1cc5  nop [rax+rax*1], ax
000076c1d9de1cce  nop [rax+rax*1], eax
000076c1d9de1cd6  mov eax, 0x410490
000076c1d9de1cdb  mov [r15+0x100], rax
000076c1d9de1ce2  jmp 0x000076C1D9BFE110
000076c1d9de1ce7  cmp dword ptr [r15+0x318], 0x00
000076c1d9de1cef  jz 0x000076C1D9DE1E20
000076c1d9de1cf5  nop [rax+rax*1], ax
000076c1d9de1cfe  nop [rax+rax*1], eax
000076c1d9de1d06  mov eax, 0x410474
000076c1d9de1d0b  mov [r15+0x100], rax
000076c1d9de1d12  jmp 0x000076C1D9BFE110
000076c1d9de1d17  int3
000076c1d9de1d18  call 0x000076C1D9CE27E0
000076c1d9de1d1d  jmp 0x000076C1D9DE1AC3
000076c1d9de1d22  call 0x000076C1D9CE27E0
000076c1d9de1d27  jmp 0x000076C1D9DE1AD6
000076c1d9de1d2c  call 0x000076C1D9CE1570
000076c1d9de1d31  jmp 0x000076C1D9DE1AE2
000076c1d9de1d36  call 0x000076C1D9CE27E0
000076c1d9de1d3b  jmp 0x000076C1D9DE1B1A
000076c1d9de1d40  call 0x000076C1D9CE1570
000076c1d9de1d45  jmp 0x000076C1D9DE1B26
000076c1d9de1d4a  call 0x000076C1D9CE27E0
000076c1d9de1d4f  jmp 0x000076C1D9DE1B5E
000076c1d9de1d54  call 0x000076C1D9CE1570
000076c1d9de1d59  jmp 0x000076C1D9DE1B6A
000076c1d9de1d5e  call 0x000076C1D9CE27E0
000076c1d9de1d63  jmp 0x000076C1D9DE1BA2
000076c1d9de1d68  call 0x000076C1D9CE1570
000076c1d9de1d6d  jmp 0x000076C1D9DE1BAE
000076c1d9de1d72  call 0x000076C1D9CE27E0
000076c1d9de1d77  jmp 0x000076C1D9DE1BED
000076c1d9de1d7c  call 0x000076C1D9C0E760
000076c1d9de1d81  jmp 0x000076C1D9DE1C0A
000076c1d9de1d86  ucomisd xmm1, xmm15
000076c1d9de1d8b  jp 0x000076C1D9DE1D9A
000076c1d9de1d8d  movaps xmm13, [0x000076C1D99FE060]
000076c1d9de1d95  jmp 0x000076C1D9DE1C73
000076c1d9de1d9a  vxorps xmm0, xmm1, xmm15
000076c1d9de1d9f  pextrw eax, xmm0, 0x03
000076c1d9de1da4  and eax, 0x7FF8
000076c1d9de1da9  cmp eax, 0x08
000076c1d9de1dac  jnz 0x000076C1D9DE1C73
000076c1d9de1db2  movq rax, xmm15
000076c1d9de1db7  shl rax, 0x0D
000076c1d9de1dbb  jbe 0x000076C1D9DE1C73
000076c1d9de1dc1  vorps xmm13, xmm15, [0x000076C1D99FE070]
000076c1d9de1dc9  jmp 0x000076C1D9DE1C73
000076c1d9de1dce  ucomisd xmm1, xmm15
000076c1d9de1dd3  jp 0x000076C1D9DE1DE2
000076c1d9de1dd5  movaps xmm14, [0x000076C1D99FE060]
000076c1d9de1ddd  jmp 0x000076C1D9DE1CA0
000076c1d9de1de2  vxorps xmm0, xmm1, xmm15
000076c1d9de1de7  pextrw eax, xmm0, 0x03
000076c1d9de1dec  and eax, 0x7FF8
000076c1d9de1df1  cmp eax, 0x08
000076c1d9de1df4  jnz 0x000076C1D9DE1CA0
000076c1d9de1dfa  movq rax, xmm15
000076c1d9de1dff  shl rax, 0x0D
000076c1d9de1e03  jbe 0x000076C1D9DE1CA0
000076c1d9de1e09  vorps xmm14, xmm15, [0x000076C1D99FE070]
000076c1d9de1e11  jmp 0x000076C1D9DE1CA0
000076c1d9de1e16  int3
000076c1d9de1e17  nop [rax+rax*1], ax
000076c1d9de1e20  mov rax, [r15+0x48]
000076c1d9de1e24  mov r14, [r15+0x50]
000076c1d9de1e28  lea r12, [r14+rax*1]
000076c1d9de1e2c  movups xmm1, [r13+r12*1]
000076c1d9de1e32  movaps [r15+0x120], xmm1
000076c1d9de1e3a  lea r14, [rax+0x10]
000076c1d9de1e3e  mov [r15+0x48], r14
000076c1d9de1e42  xor eax, eax
000076c1d9de1e44  mov r12d, 0x200
000076c1d9de1e4a  cmp r14, r12
000076c1d9de1e4d  cmc
000076c1d9de1e4e  lahf
000076c1d9de1e4f  seto al
000076c1d9de1e52  mov [r15+0x108], eax
000076c1d9de1e59  pextrq rax, xmm1, 0x01
000076c1d9de1e60  movq xmm15, rax
000076c1d9de1e65  movaps [r15+0x130], xmm15
000076c1d9de1e6d  movaps xmm14, [r15+0x110]
000076c1d9de1e75  movq rax, xmm14
000076c1d9de1e7a  movq r14, xmm1
000076c1d9de1e7f  vmovq xmm1, rax
000076c1d9de1e84  vmovq xmm14, r14
000076c1d9de1e89  movaps xmm13, xmm1
000076c1d9de1e8d  addsd xmm13, xmm14
000076c1d9de1e92  ucomisd xmm13, xmm13
000076c1d9de1e97  jp 0x000076C1D9DE1F4C
000076c1d9de1e9d  movq xmm13, xmm13
000076c1d9de1ea2  movq rax, xmm13
000076c1d9de1ea7  movq r14, xmm15
000076c1d9de1eac  vmovq xmm1, rax
000076c1d9de1eb1  vmovq xmm15, r14
000076c1d9de1eb6  movaps xmm14, xmm1
000076c1d9de1eba  addsd xmm14, xmm15
000076c1d9de1ebf  ucomisd xmm14, xmm14
000076c1d9de1ec4  jp 0x000076C1D9DE1F94
000076c1d9de1eca  movq xmm14, xmm14
000076c1d9de1ecf  movaps [r15+0x110], xmm14
000076c1d9de1ed7  mov eax, [r15+0x108]
000076c1d9de1ede  sahf
000076c1d9de1edf  jnz 0x000076C1D9DE1F11
000076c1d9de1ee1  cmp dword ptr [r15+0x318], 0x00
000076c1d9de1ee9  jz 0x000076C1D9DE1FE0
000076c1d9de1eef  nop [rax+rax*1], ax
000076c1d9de1ef8  nop [rax+rax*1], eax
000076c1d9de1f00  mov eax, 0x410490
000076c1d9de1f05  mov [r15+0x100], rax
000076c1d9de1f0c  jmp 0x000076C1D9BFE110
000076c1d9de1f11  cmp dword ptr [r15+0x318], 0x00
000076c1d9de1f19  jz 0x000076C1D9DE1E20
000076c1d9de1f1f  nop [rax+rax*1], ax
000076c1d9de1f28  nop [rax+rax*1], eax
000076c1d9de1f30  mov eax, 0x410474
000076c1d9de1f35  mov [r15+0x100], rax
000076c1d9de1f3c  jmp 0x000076C1D9BFE110
000076c1d9de1f41  int3
000076c1d9de1f42  call 0x000076C1D9CB52F0
000076c1d9de1f47  jmp 0x000076C1D9DE1E32
000076c1d9de1f4c  ucomisd xmm1, xmm14
000076c1d9de1f51  jp 0x000076C1D9DE1F60
000076c1d9de1f53  movaps xmm13, [0x000076C1D99FE060]
000076c1d9de1f5b  jmp 0x000076C1D9DE1E9D
000076c1d9de1f60  vxorps xmm0, xmm1, xmm14
000076c1d9de1f65  pextrw eax, xmm0, 0x03
000076c1d9de1f6a  and eax, 0x7FF8
000076c1d9de1f6f  cmp eax, 0x08
000076c1d9de1f72  jnz 0x000076C1D9DE1E9D
000076c1d9de1f78  movq rax, xmm14
000076c1d9de1f7d  shl rax, 0x0D
000076c1d9de1f81  jbe 0x000076C1D9DE1E9D
000076c1d9de1f87  vorps xmm13, xmm14, [0x000076C1D99FE070]
000076c1d9de1f8f  jmp 0x000076C1D9DE1E9D
000076c1d9de1f94  ucomisd xmm1, xmm15
000076c1d9de1f99  jp 0x000076C1D9DE1FA8
000076c1d9de1f9b  movaps xmm14, [0x000076C1D99FE060]
000076c1d9de1fa3  jmp 0x000076C1D9DE1ECA
000076c1d9de1fa8  vxorps xmm0, xmm1, xmm15
000076c1d9de1fad  pextrw eax, xmm0, 0x03
000076c1d9de1fb2  and eax, 0x7FF8
000076c1d9de1fb7  cmp eax, 0x08
000076c1d9de1fba  jnz 0x000076C1D9DE1ECA
000076c1d9de1fc0  movq rax, xmm15
000076c1d9de1fc5  shl rax, 0x0D
000076c1d9de1fc9  jbe 0x000076C1D9DE1ECA
000076c1d9de1fcf  vorps xmm14, xmm15, [0x000076C1D99FE070]
000076c1d9de1fd7  jmp 0x000076C1D9DE1ECA
000076c1d9de1fdc  int3
000076c1d9de1fdd  nop [rax], eax
000076c1d9de1fe0  mov rax, [r15+0x40]
000076c1d9de1fe4  lea r14, [rax+0x510]
000076c1d9de1feb  movaps xmm1, [r15+0x110]
000076c1d9de1ff3  movq rax, xmm1
000076c1d9de1ff8  mov [r13+r14*1], rax
000076c1d9de1ffd  mov rax, [r15+0xF0]
000076c1d9de2004  mov [r15+0x100], rax
000076c1d9de200b  jmp 0x000076C1D9DCE5C0
000076c1d9de2010  int3
000076c1d9de2011  call 0x000076C1D9CD5EB0
000076c1d9de2016  jmp 0x000076C1D9DE1FFD
000076c1d9de201b  int3
000076c1d9de201c  nop [rax], eax
000076c1d9de2020  mov qword ptr [r15+0x100], 0x04
000076c1d9de202b  mov esi, 0x00
000076c1d9de2030  mov edx, 0x09
000076c1d9de2035  mov rdi, 0x7FFEAEC3D090
000076c1d9de203f  mov rax, 0x5EA58B873970
000076c1d9de2049  call rax
000076c1d9de204b  cmp dword ptr [r15+0x318], 0x00
000076c1d9de2053  jnz 0x000076C1D9BFE110
000076c1d9de2059  jmp 0x000076C1D9BFE0A0
000076c1d9de205e  int3
000076c1d9de205f  int3
